/*===========================================================================*/
/*   (Cfa/tvector.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct tvec
  {
     struct type *item_type_130;
  }
    *tvec_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;

typedef struct isfun
  {
     struct node *original_body_40;
     obj_t recursive_calls_44;
  }
     *isfun_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
extern obj_t _long__149_type_cache;
static obj_t method_init_76_cfa_tvector();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t _optim__89_engine_param;
static obj_t _patch_vector_set__187_cfa_tvector(obj_t);
extern obj_t tvector_optimization__143_cfa_tvector();
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static bool_t show_tvector_204_cfa_tvector(obj_t);
extern obj_t type_type_type;
extern obj_t box_ref_242_ast_node;
static obj_t _vector__tvector__184_cfa_tvector(obj_t, obj_t);
extern obj_t patch_vector_set__231_cfa_tvector();
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static obj_t patch__227_cfa_tvector(node_t);
static obj_t _get_vector_item_type2899_116_cfa_tvector(obj_t, obj_t);
extern obj_t closure_ast_node;
extern obj_t create_struct(obj_t, long);
static obj_t _patch__default2169_94_cfa_tvector(obj_t, obj_t);
extern obj_t tvec_tvector_tvector;
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
static obj_t _add_make_vector_2898_151_cfa_tvector(obj_t, obj_t);
extern obj_t globalize_walk__63_globalize_walk(obj_t, obj_t);
static obj_t _patch_2900_188_cfa_tvector(obj_t, obj_t);
extern obj_t vector__tvector__205_cfa_tvector(obj_t);
extern obj_t vector_ref_app_195_cfa_info;
static obj_t patch___72_cfa_tvector(obj_t);
extern bool_t stack_optimization__133_cfa_stack();
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern type_t get_default_type_181_type_cache();
extern obj_t module_initialization_70_cfa_tvector(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_type(long, char *);
extern obj_t module_initialization_70_module_pragma(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_tvector_tvector(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_build(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_set(long, char *);
extern obj_t module_initialization_70_cfa_type(long, char *);
extern obj_t module_initialization_70_cfa_stack(long, char *);
extern obj_t module_initialization_70_globalize_walk(long, char *);
extern obj_t module_initialization_70_inline_inline(long, char *);
extern obj_t module_initialization_70_inline_walk(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static obj_t _unpatch_vector_set__250_cfa_tvector(obj_t);
extern bool_t sub_type__174_type_env(type_t, type_t);
static obj_t _make_vector_list__231_cfa_tvector = BUNSPEC;
extern obj_t tvector_finalizer_246_module_type();
static obj_t declare_tvectors_117_cfa_tvector(obj_t);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_cfa_tvector();
static obj_t patch_vector__list__149_cfa_tvector(app_t);
static obj_t patch_vector_length__86_cfa_tvector(app_t);
extern obj_t app_ly_162_ast_node;
extern obj_t cfun_ast_var;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t patch_fun__141_cfa_tvector(obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_cfa_tvector();
extern obj_t get_approx_type_210_cfa_type(approx_t);
extern node_t inline_node_218_inline_inline(node_t, long, obj_t);
extern obj_t make_vector_app_205_cfa_info;
extern approx_t cfa__102_cfa_cfa(node_t);
extern obj_t unpatch_vector_set__139_cfa_tvector();
extern node_t node_heap__stack__239_cfa_stack(app_t, bool_t);
extern obj_t set_default_type__106_type_cache(type_t);
extern obj_t kwote_node_102_cfa_info;
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_cfa_tvector();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t vector_set__app_21_cfa_info;
extern obj_t kwote_ast_node;
extern obj_t sfun_ast_var;
static obj_t patch__default2169_106_cfa_tvector(node_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static obj_t _tvector_optimization__242_cfa_tvector(obj_t);
static bool_t patch_tree__164_cfa_tvector(obj_t);
extern obj_t create_vector_app_150_cfa_info;
static obj_t _get_vector_item_type_default2166_210_cfa_tvector(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t build_ast_sans_remove_93_ast_build(obj_t);
static obj_t patch_vector___0_cfa_tvector(app_t);
extern obj_t _classes__134___object;
static obj_t get_tvectors_38_cfa_tvector();
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t pragma_finalizer_170_module_pragma();
extern obj_t inline_setup__219_inline_walk(obj_t);
extern type_t get_vector_item_type_88_cfa_tvector(app_t);
static obj_t get_vector_item_type_default2166_143_cfa_tvector(app_t);
extern obj_t _lib_mode__85_engine_param;
extern obj_t add_make_vector__104_cfa_tvector(node_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_cfa_tvector = BUNSPEC;
extern obj_t _vector__240_type_cache;
extern obj_t conditional_ast_node;
extern obj_t class_super_145___object(obj_t);
extern obj_t type_parser_173_module_type(obj_t, obj_t);
static obj_t cnst_init_137_cfa_tvector();
extern obj_t _bool__149_type_cache;
static obj_t __cnst[22];

DEFINE_EXPORT_PROCEDURE(add_make_vector__env_5_cfa_tvector, _add_make_vector_2898_151_cfa_tvector2913, _add_make_vector_2898_151_cfa_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvector_optimization__env_42_cfa_tvector, _tvector_optimization__242_cfa_tvector2914, _tvector_optimization__242_cfa_tvector, 0L, 0);
DEFINE_STATIC_PROCEDURE(patch__default2169_env_17_cfa_tvector, _patch__default2169_94_cfa_tvector2915, _patch__default2169_94_cfa_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(patch_vector_set__env_198_cfa_tvector, _patch_vector_set__187_cfa_tvector2916, _patch_vector_set__187_cfa_tvector, 0L, 0);
DEFINE_STATIC_GENERIC(patch__env_129_cfa_tvector, _patch_2900_188_cfa_tvector2917, _patch_2900_188_cfa_tvector, 0L, 1);
DEFINE_STRING(string2907_cfa_tvector, string2907_cfa_tvector2918, "PATCH!-DEFAULT2169 -SET! -REF ALLOCATE- MAKE- __R4_VECTORS_6_8 VECTOR->LIST C-VECTOR-LENGTH A-TVECTOR GET-VECTOR-ITEM-TYPE-DEFAULT2166 ->LIST VALUE -LENGTH DONE NO-REMOVE UNIT TVECTOR TV-OF- ALL VECTOR? C-VECTOR? (VECTOR-SET! C-VECTOR-SET! VECTOR-SET-UR!) ", 256);
DEFINE_STRING(string2906_cfa_tvector, string2906_cfa_tvector2919, "Unexpected closure", 18);
DEFINE_STRING(string2905_cfa_tvector, string2905_cfa_tvector2920, "patch!", 6);
DEFINE_STRING(string2904_cfa_tvector, string2904_cfa_tvector2921, "No method for this object", 25);
DEFINE_STRING(string2903_cfa_tvector, string2903_cfa_tvector2922, "        vector of ", 18);
DEFINE_STRING(string2902_cfa_tvector, string2902_cfa_tvector2923, " -> vector of ", 14);
DEFINE_STRING(string2901_cfa_tvector, string2901_cfa_tvector2924, "   . Vector -> Tvector", 22);
DEFINE_STATIC_PROCEDURE(get_vector_item_type_default2166_env_42_cfa_tvector, _get_vector_item_type_default2166_210_cfa_tvector2925, _get_vector_item_type_default2166_210_cfa_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(vector__tvector__env_76_cfa_tvector, _vector__tvector__184_cfa_tvector2926, _vector__tvector__184_cfa_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(unpatch_vector_set__env_116_cfa_tvector, _unpatch_vector_set__250_cfa_tvector2927, _unpatch_vector_set__250_cfa_tvector, 0L, 0);
DEFINE_EXPORT_GENERIC(get_vector_item_type_env_168_cfa_tvector, _get_vector_item_type2899_116_cfa_tvector2928, _get_vector_item_type2899_116_cfa_tvector, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_cfa_tvector(long checksum_4465, char *from_4466)
{
   if (CBOOL(require_initialization_114_cfa_tvector))
     {
	require_initialization_114_cfa_tvector = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_tvector();
	cnst_init_137_cfa_tvector();
	imported_modules_init_94_cfa_tvector();
	method_init_76_cfa_tvector();
	toplevel_init_63_cfa_tvector();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_tvector()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "CFA_TVECTOR");
   module_initialization_70___object(((long) 0), "CFA_TVECTOR");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_TVECTOR");
   module_initialization_70___reader(((long) 0), "CFA_TVECTOR");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_tvector()
{
   {
      obj_t cnst_port_138_4457;
      cnst_port_138_4457 = open_input_string(string2907_cfa_tvector);
      {
	 long i_4458;
	 i_4458 = ((long) 21);
       loop_4459:
	 {
	    bool_t test2908_4460;
	    test2908_4460 = (i_4458 == ((long) -1));
	    if (test2908_4460)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2909_4461;
		    {
		       obj_t list2910_4462;
		       {
			  obj_t arg2911_4463;
			  arg2911_4463 = BNIL;
			  list2910_4462 = MAKE_PAIR(cnst_port_138_4457, arg2911_4463);
		       }
		       arg2909_4461 = read___reader(list2910_4462);
		    }
		    CNST_TABLE_SET(i_4458, arg2909_4461);
		 }
		 {
		    int aux_4464;
		    {
		       long aux_4485;
		       aux_4485 = (i_4458 - ((long) 1));
		       aux_4464 = (int) (aux_4485);
		    }
		    {
		       long i_4488;
		       i_4488 = (long) (aux_4464);
		       i_4458 = i_4488;
		       goto loop_4459;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_tvector()
{
   _make_vector_list__231_cfa_tvector = BNIL;
   return BUNSPEC;
}


/* tvector-optimization? */ obj_t 
tvector_optimization__143_cfa_tvector()
{
   {
      bool_t _andtest_2115_2306;
      {
	 long n1_3654;
	 n1_3654 = (long) CINT(_optim__89_engine_param);
	 _andtest_2115_2306 = (n1_3654 >= ((long) 3));
      }
      if (_andtest_2115_2306)
	{
	   if (CBOOL(_lib_mode__85_engine_param))
	     {
		return BFALSE;
	     }
	   else
	     {
		return BTRUE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _tvector-optimization? */ obj_t 
_tvector_optimization__242_cfa_tvector(obj_t env_4440)
{
   return tvector_optimization__143_cfa_tvector();
}


/* patch-vector-set! */ obj_t 
patch_vector_set__231_cfa_tvector()
{
   {
      bool_t test_4496;
      {
	 obj_t aux_4497;
	 aux_4497 = tvector_optimization__143_cfa_tvector();
	 test_4496 = CBOOL(aux_4497);
      }
      if (test_4496)
	{
	   {
	      obj_t l2116_2308;
	      l2116_2308 = CNST_TABLE_REF(((long) 0));
	    lname2117_2309:
	      if (PAIRP(l2116_2308))
		{
		   {
		      obj_t g_2313;
		      g_2313 = find_global_223_ast_env(CAR(l2116_2308), BNIL);
		      {
			 bool_t test2234_2314;
			 test2234_2314 = is_a__118___object(g_2313, global_ast_var);
			 if (test2234_2314)
			   {
			      value_t fun_2315;
			      {
				 global_t obj_3659;
				 obj_3659 = (global_t) (g_2313);
				 fun_2315 = (((global_t) CREF(obj_3659))->value);
			      }
			      {
				 bool_t test2235_2316;
				 test2235_2316 = is_a__118___object((obj_t) (fun_2315), cfun_ast_var);
				 if (test2235_2316)
				   {
				      {
					 obj_t arg2236_2317;
					 type_t arg2237_2318;
					 {
					    obj_t aux_4511;
					    {
					       obj_t aux_4512;
					       {
						  cfun_t obj_3661;
						  obj_3661 = (cfun_t) (fun_2315);
						  aux_4512 = (((cfun_t) CREF(obj_3661))->args_type_205);
					       }
					       aux_4511 = CDR(aux_4512);
					    }
					    arg2236_2317 = CDR(aux_4511);
					 }
					 arg2237_2318 = get_default_type_181_type_cache();
					 {
					    obj_t aux_4518;
					    aux_4518 = (obj_t) (arg2237_2318);
					    SET_CAR(arg2236_2317, aux_4518);
					 }
				      }
				   }
				 else
				   {
				      bool_t test2239_2320;
				      test2239_2320 = is_a__118___object((obj_t) (fun_2315), sfun_ast_var);
				      if (test2239_2320)
					{
					   {
					      obj_t arg2240_2321;
					      type_t arg2241_2322;
					      {
						 obj_t aux_4524;
						 {
						    obj_t aux_4525;
						    {
						       obj_t aux_4526;
						       {
							  sfun_t obj_3669;
							  obj_3669 = (sfun_t) (fun_2315);
							  aux_4526 = (((sfun_t) CREF(obj_3669))->args);
						       }
						       aux_4525 = CDR(aux_4526);
						    }
						    aux_4524 = CDR(aux_4525);
						 }
						 arg2240_2321 = CAR(aux_4524);
					      }
					      arg2241_2322 = get_default_type_181_type_cache();
					      {
						 local_t obj_3676;
						 obj_3676 = (local_t) (arg2240_2321);
						 ((((local_t) CREF(obj_3676))->type) = ((type_t) arg2241_2322), BUNSPEC);
					      }
					   }
					}
				      else
					{
					   BFALSE;
					}
				   }
			      }
			   }
			 else
			   {
			      BUNSPEC;
			   }
		      }
		   }
		   {
		      obj_t l2116_4535;
		      l2116_4535 = CDR(l2116_2308);
		      l2116_2308 = l2116_4535;
		      goto lname2117_2309;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   {
	      obj_t g_2326;
	      g_2326 = find_global_223_ast_env(CNST_TABLE_REF(((long) 1)), BNIL);
	      {
		 bool_t test2247_2327;
		 test2247_2327 = is_a__118___object(g_2326, global_ast_var);
		 if (test2247_2327)
		   {
		      obj_t arg2248_2329;
		      type_t arg2250_2330;
		      {
			 cfun_t obj_3681;
			 {
			    value_t aux_4542;
			    {
			       global_t obj_3680;
			       obj_3680 = (global_t) (g_2326);
			       aux_4542 = (((global_t) CREF(obj_3680))->value);
			    }
			    obj_3681 = (cfun_t) (aux_4542);
			 }
			 arg2248_2329 = (((cfun_t) CREF(obj_3681))->args_type_205);
		      }
		      arg2250_2330 = get_default_type_181_type_cache();
		      {
			 obj_t aux_4548;
			 aux_4548 = (obj_t) (arg2250_2330);
			 SET_CAR(arg2248_2329, aux_4548);
		      }
		   }
		 else
		   {
		      BUNSPEC;
		   }
	      }
	   }
	   {
	      obj_t g_2333;
	      g_2333 = find_global_223_ast_env(CNST_TABLE_REF(((long) 2)), BNIL);
	      {
		 bool_t test2254_2334;
		 test2254_2334 = is_a__118___object(g_2333, global_ast_var);
		 if (test2254_2334)
		   {
		      obj_t arg2256_2336;
		      type_t arg2257_2337;
		      {
			 obj_t aux_4555;
			 {
			    sfun_t obj_3686;
			    {
			       value_t aux_4556;
			       {
				  global_t obj_3685;
				  obj_3685 = (global_t) (g_2333);
				  aux_4556 = (((global_t) CREF(obj_3685))->value);
			       }
			       obj_3686 = (sfun_t) (aux_4556);
			    }
			    aux_4555 = (((sfun_t) CREF(obj_3686))->args);
			 }
			 arg2256_2336 = CAR(aux_4555);
		      }
		      arg2257_2337 = get_default_type_181_type_cache();
		      {
			 local_t obj_3688;
			 obj_3688 = (local_t) (arg2256_2336);
			 return ((((local_t) CREF(obj_3688))->type) = ((type_t) arg2257_2337), BUNSPEC);
		      }
		   }
		 else
		   {
		      return BUNSPEC;
		   }
	      }
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _patch-vector-set! */ obj_t 
_patch_vector_set__187_cfa_tvector(obj_t env_4441)
{
   return patch_vector_set__231_cfa_tvector();
}


/* unpatch-vector-set! */ obj_t 
unpatch_vector_set__139_cfa_tvector()
{
   {
      bool_t test_4566;
      {
	 obj_t aux_4567;
	 aux_4567 = tvector_optimization__143_cfa_tvector();
	 test_4566 = CBOOL(aux_4567);
      }
      if (test_4566)
	{
	   {
	      obj_t l2118_2342;
	      l2118_2342 = CNST_TABLE_REF(((long) 0));
	    lname2119_2343:
	      if (PAIRP(l2118_2342))
		{
		   {
		      obj_t g_2347;
		      g_2347 = find_global_223_ast_env(CAR(l2118_2342), BNIL);
		      {
			 bool_t test2265_2348;
			 test2265_2348 = is_a__118___object(g_2347, global_ast_var);
			 if (test2265_2348)
			   {
			      value_t fun_2349;
			      {
				 global_t obj_3693;
				 obj_3693 = (global_t) (g_2347);
				 fun_2349 = (((global_t) CREF(obj_3693))->value);
			      }
			      {
				 bool_t test2266_2350;
				 test2266_2350 = is_a__118___object((obj_t) (fun_2349), cfun_ast_var);
				 if (test2266_2350)
				   {
				      {
					 obj_t obj_3701;
					 obj_3701 = _obj__252_type_cache;
					 {
					    obj_t aux_4581;
					    {
					       obj_t aux_4582;
					       {
						  obj_t aux_4583;
						  {
						     cfun_t obj_3695;
						     obj_3695 = (cfun_t) (fun_2349);
						     aux_4583 = (((cfun_t) CREF(obj_3695))->args_type_205);
						  }
						  aux_4582 = CDR(aux_4583);
					       }
					       aux_4581 = CDR(aux_4582);
					    }
					    SET_CAR(aux_4581, obj_3701);
					 }
				      }
				   }
				 else
				   {
				      bool_t test2269_2353;
				      test2269_2353 = is_a__118___object((obj_t) (fun_2349), sfun_ast_var);
				      if (test2269_2353)
					{
					   {
					      local_t obj_3710;
					      type_t val1160_3711;
					      {
						 obj_t aux_4592;
						 {
						    obj_t aux_4593;
						    {
						       obj_t aux_4594;
						       {
							  obj_t aux_4595;
							  {
							     sfun_t obj_3703;
							     obj_3703 = (sfun_t) (fun_2349);
							     aux_4595 = (((sfun_t) CREF(obj_3703))->args);
							  }
							  aux_4594 = CDR(aux_4595);
						       }
						       aux_4593 = CDR(aux_4594);
						    }
						    aux_4592 = CAR(aux_4593);
						 }
						 obj_3710 = (local_t) (aux_4592);
					      }
					      val1160_3711 = (type_t) (_obj__252_type_cache);
					      ((((local_t) CREF(obj_3710))->type) = ((type_t) val1160_3711), BUNSPEC);
					   }
					}
				      else
					{
					   BFALSE;
					}
				   }
			      }
			   }
			 else
			   {
			      BUNSPEC;
			   }
		      }
		   }
		   {
		      obj_t l2118_4604;
		      l2118_4604 = CDR(l2118_2342);
		      l2118_2342 = l2118_4604;
		      goto lname2119_2343;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   {
	      obj_t g_2358;
	      g_2358 = find_global_223_ast_env(CNST_TABLE_REF(((long) 1)), BNIL);
	      {
		 bool_t test2274_2359;
		 test2274_2359 = is_a__118___object(g_2358, global_ast_var);
		 if (test2274_2359)
		   {
		      obj_t obj_3717;
		      obj_3717 = _obj__252_type_cache;
		      {
			 obj_t aux_4611;
			 {
			    cfun_t obj_3715;
			    {
			       value_t aux_4612;
			       {
				  global_t obj_3714;
				  obj_3714 = (global_t) (g_2358);
				  aux_4612 = (((global_t) CREF(obj_3714))->value);
			       }
			       obj_3715 = (cfun_t) (aux_4612);
			    }
			    aux_4611 = (((cfun_t) CREF(obj_3715))->args_type_205);
			 }
			 SET_CAR(aux_4611, obj_3717);
		      }
		   }
		 else
		   {
		      BUNSPEC;
		   }
	      }
	   }
	   {
	      obj_t g_2364;
	      g_2364 = find_global_223_ast_env(CNST_TABLE_REF(((long) 2)), BNIL);
	      {
		 bool_t test2278_2365;
		 test2278_2365 = is_a__118___object(g_2364, global_ast_var);
		 if (test2278_2365)
		   {
		      local_t obj_3722;
		      type_t val1160_3723;
		      {
			 obj_t aux_4622;
			 {
			    obj_t aux_4623;
			    {
			       sfun_t obj_3720;
			       {
				  value_t aux_4624;
				  {
				     global_t obj_3719;
				     obj_3719 = (global_t) (g_2364);
				     aux_4624 = (((global_t) CREF(obj_3719))->value);
				  }
				  obj_3720 = (sfun_t) (aux_4624);
			       }
			       aux_4623 = (((sfun_t) CREF(obj_3720))->args);
			    }
			    aux_4622 = CAR(aux_4623);
			 }
			 obj_3722 = (local_t) (aux_4622);
		      }
		      val1160_3723 = (type_t) (_obj__252_type_cache);
		      return ((((local_t) CREF(obj_3722))->type) = ((type_t) val1160_3723), BUNSPEC);
		   }
		 else
		   {
		      return BUNSPEC;
		   }
	      }
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _unpatch-vector-set! */ obj_t 
_unpatch_vector_set__250_cfa_tvector(obj_t env_4442)
{
   return unpatch_vector_set__139_cfa_tvector();
}


/* vector->tvector! */ obj_t 
vector__tvector__205_cfa_tvector(obj_t globals_29)
{
   {
      bool_t test_4634;
      {
	 obj_t aux_4635;
	 aux_4635 = tvector_optimization__143_cfa_tvector();
	 test_4634 = CBOOL(aux_4635);
      }
      if (test_4634)
	{
	   inline_setup__219_inline_walk(CNST_TABLE_REF(((long) 3)));
	   {
	      obj_t tvectors_2373;
	      tvectors_2373 = get_tvectors_38_cfa_tvector();
	      show_tvector_204_cfa_tvector(tvectors_2373);
	      if (PAIRP(tvectors_2373))
		{
		   obj_t add_tree_17_2375;
		   add_tree_17_2375 = declare_tvectors_117_cfa_tvector(tvectors_2373);
		   patch_tree__164_cfa_tvector(globals_29);
		   return add_tree_17_2375;
		}
	      else
		{
		   return BNIL;
		}
	   }
	}
      else
	{
	   return BNIL;
	}
   }
}


/* _vector->tvector! */ obj_t 
_vector__tvector__184_cfa_tvector(obj_t env_4443, obj_t globals_4444)
{
   return vector__tvector__205_cfa_tvector(globals_4444);
}


/* add-make-vector! */ obj_t 
add_make_vector__104_cfa_tvector(node_t node_30)
{
   {
      bool_t test_4647;
      {
	 obj_t aux_4648;
	 aux_4648 = tvector_optimization__143_cfa_tvector();
	 test_4647 = CBOOL(aux_4648);
      }
      if (test_4647)
	{
	   obj_t obj2_3726;
	   obj2_3726 = _make_vector_list__231_cfa_tvector;
	   {
	      obj_t aux_4651;
	      aux_4651 = (obj_t) (node_30);
	      return (_make_vector_list__231_cfa_tvector = MAKE_PAIR(aux_4651, obj2_3726),
		 BUNSPEC);
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _add-make-vector!2898 */ obj_t 
_add_make_vector_2898_151_cfa_tvector(obj_t env_4445, obj_t node_4446)
{
   return add_make_vector__104_cfa_tvector((node_t) (node_4446));
}


/* get-tvectors */ obj_t 
get_tvectors_38_cfa_tvector()
{
   {
      obj_t apps_2377;
      obj_t tvectors_2378;
      apps_2377 = _make_vector_list__231_cfa_tvector;
      tvectors_2378 = BNIL;
    loop_2379:
      if (NULLP(apps_2377))
	{
	   return tvectors_2378;
	}
      else
	{
	   obj_t app_2382;
	   app_2382 = CAR(apps_2377);
	   {
	      type_t type_2383;
	      type_2383 = get_vector_item_type_88_cfa_tvector((app_t) (app_2382));
	      {
		 {
		    bool_t test2289_2384;
		    {
		       bool_t test2294_2388;
		       {
			  obj_t obj2_3730;
			  obj2_3730 = ____74_type_cache;
			  {
			     obj_t aux_4661;
			     aux_4661 = (obj_t) (type_2383);
			     test2294_2388 = (aux_4661 == obj2_3730);
			  }
		       }
		       if (test2294_2388)
			 {
			    test2289_2384 = ((bool_t) 0);
			 }
		       else
			 {
			    bool_t test2295_2389;
			    test2295_2389 = sub_type__174_type_env(type_2383, (type_t) (_obj__252_type_cache));
			    if (test2295_2389)
			      {
				 test2289_2384 = ((bool_t) 0);
			      }
			    else
			      {
				 test2289_2384 = ((bool_t) 1);
			      }
			 }
		    }
		    if (test2289_2384)
		      {
			 obj_t arg2291_2385;
			 obj_t arg2292_2386;
			 arg2291_2385 = CDR(apps_2377);
			 arg2292_2386 = MAKE_PAIR(app_2382, tvectors_2378);
			 {
			    obj_t tvectors_4672;
			    obj_t apps_4671;
			    apps_4671 = arg2291_2385;
			    tvectors_4672 = arg2292_2386;
			    tvectors_2378 = tvectors_4672;
			    apps_2377 = apps_4671;
			    goto loop_2379;
			 }
		      }
		    else
		      {
			 obj_t apps_4673;
			 apps_4673 = CDR(apps_2377);
			 apps_2377 = apps_4673;
			 goto loop_2379;
		      }
		 }
	      }
	   }
	}
   }
}


/* show-tvector */ bool_t 
show_tvector_204_cfa_tvector(obj_t tvector_35)
{
   {
      obj_t list2296_2390;
      {
	 obj_t arg2298_2392;
	 {
	    obj_t aux_4675;
	    aux_4675 = BCHAR(((unsigned char) '\n'));
	    arg2298_2392 = MAKE_PAIR(aux_4675, BNIL);
	 }
	 list2296_2390 = MAKE_PAIR(string2901_cfa_tvector, arg2298_2392);
      }
      verbose_tools_speek(BINT(((long) 1)), list2296_2390);
   }
   {
      obj_t l2122_2394;
      l2122_2394 = tvector_35;
    lname2123_2395:
      if (PAIRP(l2122_2394))
	{
	   {
	      obj_t arg2303_2400;
	      obj_t arg2305_2402;
	      arg2303_2400 = shape_tools_shape(_obj__252_type_cache);
	      {
		 type_t arg2312_2409;
		 {
		    app_t aux_4684;
		    {
		       obj_t aux_4685;
		       aux_4685 = CAR(l2122_2394);
		       aux_4684 = (app_t) (aux_4685);
		    }
		    arg2312_2409 = get_vector_item_type_88_cfa_tvector(aux_4684);
		 }
		 arg2305_2402 = shape_tools_shape((obj_t) (arg2312_2409));
	      }
	      {
		 obj_t list2306_2403;
		 {
		    obj_t arg2307_2404;
		    {
		       obj_t arg2308_2405;
		       {
			  obj_t arg2309_2406;
			  {
			     obj_t arg2310_2407;
			     {
				obj_t aux_4691;
				aux_4691 = BCHAR(((unsigned char) '\n'));
				arg2310_2407 = MAKE_PAIR(aux_4691, BNIL);
			     }
			     arg2309_2406 = MAKE_PAIR(arg2305_2402, arg2310_2407);
			  }
			  arg2308_2405 = MAKE_PAIR(string2902_cfa_tvector, arg2309_2406);
		       }
		       arg2307_2404 = MAKE_PAIR(arg2303_2400, arg2308_2405);
		    }
		    list2306_2403 = MAKE_PAIR(string2903_cfa_tvector, arg2307_2404);
		 }
		 verbose_tools_speek(BINT(((long) 2)), list2306_2403);
	      }
	   }
	   {
	      obj_t l2122_4700;
	      l2122_4700 = CDR(l2122_2394);
	      l2122_2394 = l2122_4700;
	      goto lname2123_2395;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* declare-tvectors */ obj_t 
declare_tvectors_117_cfa_tvector(obj_t tvector_36)
{
   {
      obj_t l2124_2411;
      l2124_2411 = tvector_36;
    lname2125_2412:
      if (PAIRP(l2124_2411))
	{
	   {
	      type_t type_2415;
	      {
		 app_t aux_4704;
		 {
		    obj_t aux_4705;
		    aux_4705 = CAR(l2124_2411);
		    aux_4704 = (app_t) (aux_4705);
		 }
		 type_2415 = get_vector_item_type_88_cfa_tvector(aux_4704);
	      }
	      {
		 bool_t test2318_2417;
		 test2318_2417 = is_a__118___object((((type_t) CREF(type_2415))->tvector), type_type_type);
		 if (test2318_2417)
		   {
		      BUNSPEC;
		   }
		 else
		   {
		      obj_t tv_id_119_2418;
		      {
			 obj_t arg2334_2433;
			 arg2334_2433 = CNST_TABLE_REF(((long) 4));
			 {
			    obj_t list2336_2435;
			    {
			       obj_t arg2337_2436;
			       {
				  obj_t aux_4713;
				  aux_4713 = (((type_t) CREF(type_2415))->id);
				  arg2337_2436 = MAKE_PAIR(aux_4713, BNIL);
			       }
			       list2336_2435 = MAKE_PAIR(arg2334_2433, arg2337_2436);
			    }
			    tv_id_119_2418 = symbol_append_197___r4_symbols_6_4(list2336_2435);
			 }
		      }
		      {
			 obj_t arg2319_2419;
			 {
			    obj_t arg2320_2420;
			    {
			       obj_t arg2323_2422;
			       obj_t arg2324_2423;
			       arg2323_2422 = CNST_TABLE_REF(((long) 5));
			       {
				  obj_t arg2330_2429;
				  arg2330_2429 = (((type_t) CREF(type_2415))->id);
				  {
				     obj_t list2332_2431;
				     list2332_2431 = MAKE_PAIR(BNIL, BNIL);
				     arg2324_2423 = cons__138___r4_pairs_and_lists_6_3(arg2330_2429, list2332_2431);
				  }
			       }
			       {
				  obj_t list2326_2425;
				  {
				     obj_t arg2327_2426;
				     {
					obj_t arg2328_2427;
					arg2328_2427 = MAKE_PAIR(BNIL, BNIL);
					arg2327_2426 = MAKE_PAIR(arg2324_2423, arg2328_2427);
				     }
				     list2326_2425 = MAKE_PAIR(tv_id_119_2418, arg2327_2426);
				  }
				  arg2320_2420 = cons__138___r4_pairs_and_lists_6_3(arg2323_2422, list2326_2425);
			       }
			    }
			    arg2319_2419 = type_parser_173_module_type(arg2320_2420, BNIL);
			 }
			 ((((type_t) CREF(type_2415))->tvector) = ((obj_t) arg2319_2419), BUNSPEC);
		      }
		   }
	      }
	   }
	   {
	      obj_t l2124_4728;
	      l2124_4728 = CDR(l2124_2411);
	      l2124_2411 = l2124_4728;
	      goto lname2125_2412;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      type_t old_default_type_182_2440;
      old_default_type_182_2440 = get_default_type_181_type_cache();
      set_default_type__106_type_cache((type_t) (_obj__252_type_cache));
      {
	 obj_t tvector_unit_55_2441;
	 tvector_unit_55_2441 = tvector_finalizer_246_module_type();
	 pragma_finalizer_170_module_pragma();
	 {
	    obj_t res_2442;
	    {
	       bool_t test_4735;
	       if (STRUCTP(tvector_unit_55_2441))
		 {
		    obj_t aux_4740;
		    obj_t aux_4738;
		    aux_4740 = CNST_TABLE_REF(((long) 6));
		    aux_4738 = STRUCT_KEY(tvector_unit_55_2441);
		    test_4735 = (aux_4738 == aux_4740);
		 }
	       else
		 {
		    test_4735 = ((bool_t) 0);
		 }
	       if (test_4735)
		 {
		    obj_t arg2342_2444;
		    obj_t arg2343_2445;
		    {
		       obj_t arg2344_2446;
		       {
			  obj_t list2345_2447;
			  list2345_2447 = MAKE_PAIR(tvector_unit_55_2441, BNIL);
			  arg2344_2446 = list2345_2447;
		       }
		       arg2342_2444 = build_ast_sans_remove_93_ast_build(arg2344_2446);
		    }
		    arg2343_2445 = CNST_TABLE_REF(((long) 7));
		    res_2442 = globalize_walk__63_globalize_walk(arg2342_2444, arg2343_2445);
		 }
	       else
		 {
		    res_2442 = BNIL;
		 }
	    }
	    set_default_type__106_type_cache(old_default_type_182_2440);
	    return res_2442;
	 }
      }
   }
}


/* patch-tree! */ bool_t 
patch_tree__164_cfa_tvector(obj_t globals_37)
{
   {
      obj_t l2127_2449;
      l2127_2449 = globals_37;
    lname2128_2450:
      if (PAIRP(l2127_2449))
	{
	   patch_fun__141_cfa_tvector(CAR(l2127_2449));
	   {
	      obj_t l2127_4752;
	      l2127_4752 = CDR(l2127_2449);
	      l2127_2449 = l2127_4752;
	      goto lname2128_2450;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* patch-fun! */ obj_t 
patch_fun__141_cfa_tvector(obj_t variable_38)
{
   {
      value_t fun_2454;
      {
	 variable_t obj_3759;
	 obj_3759 = (variable_t) (variable_38);
	 fun_2454 = (((variable_t) CREF(obj_3759))->value);
      }
      {
	 obj_t arg2350_2455;
	 {
	    node_t aux_4756;
	    {
	       obj_t aux_4757;
	       {
		  sfun_t obj_3760;
		  obj_3760 = (sfun_t) (fun_2454);
		  aux_4757 = (((sfun_t) CREF(obj_3760))->body);
	       }
	       aux_4756 = (node_t) (aux_4757);
	    }
	    arg2350_2455 = patch__227_cfa_tvector(aux_4756);
	 }
	 {
	    sfun_t obj_3761;
	    obj_3761 = (sfun_t) (fun_2454);
	    return ((((sfun_t) CREF(obj_3761))->body) = ((obj_t) arg2350_2455), BUNSPEC);
	 }
      }
   }
}


/* patch*! */ obj_t 
patch___72_cfa_tvector(obj_t node__221_62)
{
   {
      obj_t node__221_2457;
      node__221_2457 = node__221_62;
    loop_2458:
      if (NULLP(node__221_2457))
	{
	   return CNST_TABLE_REF(((long) 8));
	}
      else
	{
	   {
	      obj_t arg2353_2460;
	      {
		 node_t aux_4767;
		 {
		    obj_t aux_4768;
		    aux_4768 = CAR(node__221_2457);
		    aux_4767 = (node_t) (aux_4768);
		 }
		 arg2353_2460 = patch__227_cfa_tvector(aux_4767);
	      }
	      SET_CAR(node__221_2457, arg2353_2460);
	   }
	   {
	      obj_t node__221_4773;
	      node__221_4773 = CDR(node__221_2457);
	      node__221_2457 = node__221_4773;
	      goto loop_2458;
	   }
	}
   }
}


/* patch-vector-length! */ obj_t 
patch_vector_length__86_cfa_tvector(app_t node_64)
{
   patch___72_cfa_tvector((((app_t) CREF(node_64))->args));
   {
      approx_t approx_2465;
      {
	 node_t aux_4777;
	 {
	    obj_t aux_4778;
	    {
	       obj_t aux_4779;
	       aux_4779 = (((app_t) CREF(node_64))->args);
	       aux_4778 = CAR(aux_4779);
	    }
	    aux_4777 = (node_t) (aux_4778);
	 }
	 approx_2465 = cfa__102_cfa_cfa(aux_4777);
      }
      {
	 obj_t tv_2466;
	 tv_2466 = get_approx_type_210_cfa_type(approx_2465);
	 {
	    {
	       bool_t test2357_2467;
	       test2357_2467 = is_a__118___object(tv_2466, tvec_tvector_tvector);
	       if (test2357_2467)
		 {
		    obj_t length_tv_142_2468;
		    {
		       obj_t arg2372_2483;
		       {
			  type_t obj_3772;
			  obj_3772 = (type_t) (tv_2466);
			  arg2372_2483 = (((type_t) CREF(obj_3772))->id);
		       }
		       {
			  obj_t list2374_2485;
			  {
			     obj_t arg2375_2486;
			     {
				obj_t aux_4789;
				aux_4789 = CNST_TABLE_REF(((long) 9));
				arg2375_2486 = MAKE_PAIR(aux_4789, BNIL);
			     }
			     list2374_2485 = MAKE_PAIR(arg2372_2483, arg2375_2486);
			  }
			  length_tv_142_2468 = symbol_append_197___r4_symbols_6_4(list2374_2485);
		       }
		    }
		    {
		       node_t new_node_11_2469;
		       {
			  obj_t arg2360_2472;
			  obj_t arg2363_2474;
			  obj_t arg2364_2475;
			  {
			     obj_t arg2365_2476;
			     {
				obj_t arg2368_2479;
				obj_t arg2369_2480;
				arg2368_2479 = (((app_t) CREF(node_64))->args);
				arg2369_2480 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				arg2365_2476 = append_2_18___r4_pairs_and_lists_6_3(arg2368_2479, arg2369_2480);
			     }
			     {
				obj_t list2366_2477;
				list2366_2477 = MAKE_PAIR(arg2365_2476, BNIL);
				arg2360_2472 = cons__138___r4_pairs_and_lists_6_3(length_tv_142_2468, list2366_2477);
			     }
			  }
			  arg2363_2474 = (((app_t) CREF(node_64))->loc);
			  arg2364_2475 = CNST_TABLE_REF(((long) 10));
			  new_node_11_2469 = sexp__node_235_ast_sexp(arg2360_2472, BNIL, arg2363_2474, arg2364_2475);
		       }
		       {
			  {
			     type_t val1254_3776;
			     val1254_3776 = (type_t) (_long__149_type_cache);
			     ((((node_t) CREF(new_node_11_2469))->type) = ((type_t) val1254_3776), BUNSPEC);
			  }
			  {
			     node_t aux_4804;
			     aux_4804 = inline_node_218_inline_inline(new_node_11_2469, ((long) 1), BNIL);
			     return (obj_t) (aux_4804);
			  }
		       }
		    }
		 }
	       else
		 {
		    return (obj_t) (node_64);
		 }
	    }
	 }
      }
   }
}


/* patch-vector?! */ obj_t 
patch_vector___0_cfa_tvector(app_t node_65)
{
   patch___72_cfa_tvector((((app_t) CREF(node_65))->args));
   {
      approx_t approx_2492;
      {
	 node_t aux_4810;
	 {
	    obj_t aux_4811;
	    {
	       obj_t aux_4812;
	       aux_4812 = (((app_t) CREF(node_65))->args);
	       aux_4811 = CAR(aux_4812);
	    }
	    aux_4810 = (node_t) (aux_4811);
	 }
	 approx_2492 = cfa__102_cfa_cfa(aux_4810);
      }
      {
	 {
	    bool_t test2380_2494;
	    {
	       obj_t obj2_3782;
	       obj2_3782 = _vector__240_type_cache;
	       {
		  obj_t aux_4817;
		  {
		     type_t aux_4818;
		     aux_4818 = (((approx_t) CREF(approx_2492))->type);
		     aux_4817 = (obj_t) (aux_4818);
		  }
		  test2380_2494 = (aux_4817 == obj2_3782);
	       }
	    }
	    if (test2380_2494)
	      {
		 obj_t arg2381_2495;
		 obj_t arg2383_2496;
		 arg2381_2495 = (((app_t) CREF(node_65))->loc);
		 arg2383_2496 = _bool__149_type_cache;
		 {
		    atom_t res2894_3794;
		    {
		       type_t type_3785;
		       obj_t value_3786;
		       type_3785 = (type_t) (arg2383_2496);
		       value_3786 = BTRUE;
		       {
			  atom_t new1266_3787;
			  new1266_3787 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
			  {
			     long arg2625_3788;
			     arg2625_3788 = class_num_218___object(atom_ast_node);
			     {
				obj_t obj_3792;
				obj_3792 = (obj_t) (new1266_3787);
				(((obj_t) CREF(obj_3792))->header = MAKE_HEADER(arg2625_3788, 0), BUNSPEC);
			     }
			  }
			  {
			     object_t aux_4829;
			     aux_4829 = (object_t) (new1266_3787);
			     OBJECT_WIDENING_SET(aux_4829, BFALSE);
			  }
			  ((((atom_t) CREF(new1266_3787))->loc) = ((obj_t) arg2381_2495), BUNSPEC);
			  ((((atom_t) CREF(new1266_3787))->type) = ((type_t) type_3785), BUNSPEC);
			  ((((atom_t) CREF(new1266_3787))->value) = ((obj_t) value_3786), BUNSPEC);
			  res2894_3794 = new1266_3787;
		       }
		    }
		    return (obj_t) (res2894_3794);
		 }
	      }
	    else
	      {
		 return (obj_t) (node_65);
	      }
	 }
      }
   }
}


/* patch-vector->list! */ obj_t 
patch_vector__list__149_cfa_tvector(app_t node_66)
{
   patch___72_cfa_tvector((((app_t) CREF(node_66))->args));
   {
      approx_t approx_2502;
      {
	 node_t aux_4839;
	 {
	    obj_t aux_4840;
	    {
	       obj_t aux_4841;
	       aux_4841 = (((app_t) CREF(node_66))->args);
	       aux_4840 = CAR(aux_4841);
	    }
	    aux_4839 = (node_t) (aux_4840);
	 }
	 approx_2502 = cfa__102_cfa_cfa(aux_4839);
      }
      {
	 obj_t tv_2503;
	 tv_2503 = get_approx_type_210_cfa_type(approx_2502);
	 {
	    {
	       bool_t test2388_2504;
	       test2388_2504 = is_a__118___object(tv_2503, tvec_tvector_tvector);
	       if (test2388_2504)
		 {
		    obj_t tv__list_235_2505;
		    {
		       obj_t arg2407_2519;
		       {
			  type_t obj_3799;
			  obj_3799 = (type_t) (tv_2503);
			  arg2407_2519 = (((type_t) CREF(obj_3799))->id);
		       }
		       {
			  obj_t list2409_2521;
			  {
			     obj_t arg2410_2522;
			     {
				obj_t aux_4851;
				aux_4851 = CNST_TABLE_REF(((long) 11));
				arg2410_2522 = MAKE_PAIR(aux_4851, BNIL);
			     }
			     list2409_2521 = MAKE_PAIR(arg2407_2519, arg2410_2522);
			  }
			  tv__list_235_2505 = symbol_append_197___r4_symbols_6_4(list2409_2521);
		       }
		    }
		    {
		       node_t new_node_11_2506;
		       {
			  obj_t arg2392_2508;
			  obj_t arg2396_2510;
			  obj_t arg2399_2511;
			  {
			     obj_t arg2400_2512;
			     {
				obj_t arg2403_2515;
				obj_t arg2404_2516;
				arg2403_2515 = (((app_t) CREF(node_66))->args);
				arg2404_2516 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				arg2400_2512 = append_2_18___r4_pairs_and_lists_6_3(arg2403_2515, arg2404_2516);
			     }
			     {
				obj_t list2401_2513;
				list2401_2513 = MAKE_PAIR(arg2400_2512, BNIL);
				arg2392_2508 = cons__138___r4_pairs_and_lists_6_3(tv__list_235_2505, list2401_2513);
			     }
			  }
			  arg2396_2510 = (((app_t) CREF(node_66))->loc);
			  arg2399_2511 = CNST_TABLE_REF(((long) 10));
			  new_node_11_2506 = sexp__node_235_ast_sexp(arg2392_2508, BNIL, arg2396_2510, arg2399_2511);
		       }
		       {
			  {
			     type_t arg2390_2507;
			     {
				node_t obj_3802;
				obj_3802 = (node_t) (node_66);
				arg2390_2507 = (((node_t) CREF(obj_3802))->type);
			     }
			     ((((node_t) CREF(new_node_11_2506))->type) = ((type_t) arg2390_2507), BUNSPEC);
			  }
			  return (obj_t) (new_node_11_2506);
		       }
		    }
		 }
	       else
		 {
		    return (obj_t) (node_66);
		 }
	    }
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_cfa_tvector()
{
   add_generic__110___object(get_vector_item_type_env_168_cfa_tvector, get_vector_item_type_default2166_env_42_cfa_tvector);
   add_inlined_method__244___object(get_vector_item_type_env_168_cfa_tvector, make_vector_app_205_cfa_info, ((long) 0));
   add_inlined_method__244___object(get_vector_item_type_env_168_cfa_tvector, create_vector_app_150_cfa_info, ((long) 1));
   add_generic__110___object(patch__env_129_cfa_tvector, patch__default2169_env_17_cfa_tvector);
   add_inlined_method__244___object(patch__env_129_cfa_tvector, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, kwote_node_102_cfa_info, ((long) 2));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, var_ast_node, ((long) 3));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, closure_ast_node, ((long) 4));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, sequence_ast_node, ((long) 5));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, select_ast_node, ((long) 13));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, box_set__221_ast_node, ((long) 19));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, box_ref_242_ast_node, ((long) 20));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, app_ast_node, ((long) 21));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, make_vector_app_205_cfa_info, ((long) 22));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, create_vector_app_150_cfa_info, ((long) 23));
   add_inlined_method__244___object(patch__env_129_cfa_tvector, vector_ref_app_195_cfa_info, ((long) 24));
   {
      long aux_4898;
      aux_4898 = add_inlined_method__244___object(patch__env_129_cfa_tvector, vector_set__app_21_cfa_info, ((long) 25));
      return BINT(aux_4898);
   }
}


/* get-vector-item-type */ type_t 
get_vector_item_type_88_cfa_tvector(app_t app_31)
{
   {
      obj_t method2871_3590;
      obj_t class2876_3591;
      {
	 obj_t arg2879_3588;
	 obj_t arg2880_3589;
	 {
	    object_t obj_4173;
	    obj_4173 = (object_t) (app_31);
	    {
	       obj_t pre_method_105_4174;
	       pre_method_105_4174 = PROCEDURE_REF(get_vector_item_type_env_168_cfa_tvector, ((long) 2));
	       if (INTEGERP(pre_method_105_4174))
		 {
		    PROCEDURE_SET(get_vector_item_type_env_168_cfa_tvector, ((long) 2), BUNSPEC);
		    arg2879_3588 = pre_method_105_4174;
		 }
	       else
		 {
		    long obj_class_num_177_4179;
		    obj_class_num_177_4179 = TYPE(obj_4173);
		    {
		       obj_t arg1177_4180;
		       arg1177_4180 = PROCEDURE_REF(get_vector_item_type_env_168_cfa_tvector, ((long) 1));
		       {
			  long arg1178_4184;
			  {
			     long arg1179_4185;
			     arg1179_4185 = OBJECT_TYPE;
			     arg1178_4184 = (obj_class_num_177_4179 - arg1179_4185);
			  }
			  arg2879_3588 = VECTOR_REF(arg1177_4180, arg1178_4184);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_4190;
	    object_4190 = (object_t) (app_31);
	    {
	       long arg1180_4191;
	       {
		  long arg1181_4192;
		  long arg1182_4193;
		  arg1181_4192 = TYPE(object_4190);
		  arg1182_4193 = OBJECT_TYPE;
		  arg1180_4191 = (arg1181_4192 - arg1182_4193);
	       }
	       {
		  obj_t vector_4197;
		  vector_4197 = _classes__134___object;
		  arg2880_3589 = VECTOR_REF(vector_4197, arg1180_4191);
	       }
	    }
	 }
	 {
	    obj_t aux_4916;
	    method2871_3590 = arg2879_3588;
	    class2876_3591 = arg2880_3589;
	    {
	       if (INTEGERP(method2871_3590))
		 {
		    switch ((long) CINT(method2871_3590))
		      {
		      case ((long) 0):
			 {
			    make_vector_app_205_t app_3597;
			    app_3597 = (make_vector_app_205_t) (app_31);
			    {
			       bool_t test_4920;
			       {
				  obj_t aux_4921;
				  {
				     object_t aux_4922;
				     aux_4922 = (object_t) (app_3597);
				     aux_4921 = OBJECT_WIDENING(aux_4922);
				  }
				  test_4920 = (((make_vector_app_205_t) CREF(aux_4921))->seen__39);
			       }
			       if (test_4920)
				 {
				    approx_t arg2884_3600;
				    {
				       obj_t aux_4926;
				       {
					  object_t aux_4927;
					  aux_4927 = (object_t) (app_3597);
					  aux_4926 = OBJECT_WIDENING(aux_4927);
				       }
				       arg2884_3600 = (((make_vector_app_205_t) CREF(aux_4926))->value_approx_19);
				    }
				    {
				       type_t aux_4931;
				       aux_4931 = (((approx_t) CREF(arg2884_3600))->type);
				       aux_4916 = (obj_t) (aux_4931);
				    }
				 }
			       else
				 {
				    aux_4916 = _vector__240_type_cache;
				 }
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    create_vector_app_150_t app_3601;
			    app_3601 = (create_vector_app_150_t) (app_31);
			    {
			       bool_t test_4935;
			       {
				  obj_t aux_4936;
				  {
				     object_t aux_4937;
				     aux_4937 = (object_t) (app_3601);
				     aux_4936 = OBJECT_WIDENING(aux_4937);
				  }
				  test_4935 = (((create_vector_app_150_t) CREF(aux_4936))->seen__39);
			       }
			       if (test_4935)
				 {
				    approx_t arg2886_3604;
				    {
				       obj_t aux_4941;
				       {
					  object_t aux_4942;
					  aux_4942 = (object_t) (app_3601);
					  aux_4941 = OBJECT_WIDENING(aux_4942);
				       }
				       arg2886_3604 = (((create_vector_app_150_t) CREF(aux_4941))->value_approx_19);
				    }
				    {
				       type_t aux_4946;
				       aux_4946 = (((approx_t) CREF(arg2886_3604))->type);
				       aux_4916 = (obj_t) (aux_4946);
				    }
				 }
			       else
				 {
				    aux_4916 = _vector__240_type_cache;
				 }
			    }
			 }
			 break;
		      default:
		       case_else2877_3594:
			 if (PROCEDUREP(method2871_3590))
			   {
			      aux_4916 = PROCEDURE_ENTRY(method2871_3590) (method2871_3590, (obj_t) (app_31), BEOA);
			   }
			 else
			   {
			      obj_t fun2659_3296;
			      fun2659_3296 = PROCEDURE_REF(get_vector_item_type_env_168_cfa_tvector, ((long) 0));
			      aux_4916 = PROCEDURE_ENTRY(fun2659_3296) (fun2659_3296, (obj_t) (app_31), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else2877_3594;
		 }
	    }
	    return (type_t) (aux_4916);
	 }
      }
   }
}


/* _get-vector-item-type2899 */ obj_t 
_get_vector_item_type2899_116_cfa_tvector(obj_t env_4447, obj_t app_4448)
{
   {
      type_t aux_4961;
      aux_4961 = get_vector_item_type_88_cfa_tvector((app_t) (app_4448));
      return (obj_t) (aux_4961);
   }
}


/* get-vector-item-type-default2166 */ obj_t 
get_vector_item_type_default2166_143_cfa_tvector(app_t app_32)
{
   FAILURE(CNST_TABLE_REF(((long) 12)), string2904_cfa_tvector, (obj_t) (app_32));
}


/* _get-vector-item-type-default2166 */ obj_t 
_get_vector_item_type_default2166_210_cfa_tvector(obj_t env_4449, obj_t app_4450)
{
   return get_vector_item_type_default2166_143_cfa_tvector((app_t) (app_4450));
}


/* patch! */ obj_t 
patch__227_cfa_tvector(node_t node_39)
{
   {
      obj_t method2665_3305;
      obj_t class2670_3306;
      {
	 obj_t arg2673_3303;
	 obj_t arg2675_3304;
	 {
	    object_t obj_4212;
	    obj_4212 = (object_t) (node_39);
	    {
	       obj_t pre_method_105_4213;
	       pre_method_105_4213 = PROCEDURE_REF(patch__env_129_cfa_tvector, ((long) 2));
	       if (INTEGERP(pre_method_105_4213))
		 {
		    PROCEDURE_SET(patch__env_129_cfa_tvector, ((long) 2), BUNSPEC);
		    arg2673_3303 = pre_method_105_4213;
		 }
	       else
		 {
		    long obj_class_num_177_4218;
		    obj_class_num_177_4218 = TYPE(obj_4212);
		    {
		       obj_t arg1177_4219;
		       arg1177_4219 = PROCEDURE_REF(patch__env_129_cfa_tvector, ((long) 1));
		       {
			  long arg1178_4223;
			  {
			     long arg1179_4224;
			     arg1179_4224 = OBJECT_TYPE;
			     arg1178_4223 = (obj_class_num_177_4218 - arg1179_4224);
			  }
			  arg2673_3303 = VECTOR_REF(arg1177_4219, arg1178_4223);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_4229;
	    object_4229 = (object_t) (node_39);
	    {
	       long arg1180_4230;
	       {
		  long arg1181_4231;
		  long arg1182_4232;
		  arg1181_4231 = TYPE(object_4229);
		  arg1182_4232 = OBJECT_TYPE;
		  arg1180_4230 = (arg1181_4231 - arg1182_4232);
	       }
	       {
		  obj_t vector_4236;
		  vector_4236 = _classes__134___object;
		  arg2675_3304 = VECTOR_REF(vector_4236, arg1180_4230);
	       }
	    }
	 }
	 method2665_3305 = arg2673_3303;
	 class2670_3306 = arg2675_3304;
	 {
	    if (INTEGERP(method2665_3305))
	      {
		 switch ((long) CINT(method2665_3305))
		   {
		   case ((long) 0):
		      {
			 atom_t aux_4987;
			 aux_4987 = (atom_t) (node_39);
			 return (obj_t) (aux_4987);
		      }
		      break;
		   case ((long) 1):
		      {
			 kwote_t aux_4990;
			 aux_4990 = (kwote_t) (node_39);
			 return (obj_t) (aux_4990);
		      }
		      break;
		   case ((long) 2):
		      {
			 kwote_node_102_t knode_3314;
			 knode_3314 = (kwote_node_102_t) (node_39);
			 {
			    approx_t approx_3316;
			    {
			       node_t aux_4994;
			       {
				  obj_t aux_4995;
				  {
				     object_t aux_4996;
				     aux_4996 = (object_t) (knode_3314);
				     aux_4995 = OBJECT_WIDENING(aux_4996);
				  }
				  aux_4994 = (((kwote_node_102_t) CREF(aux_4995))->node);
			       }
			       approx_3316 = cfa__102_cfa_cfa(aux_4994);
			    }
			    {
			       obj_t tv_3317;
			       tv_3317 = get_approx_type_210_cfa_type(approx_3316);
			       {
				  {
				     bool_t test2678_3318;
				     test2678_3318 = is_a__118___object(tv_3317, tvec_tvector_tvector);
				     if (test2678_3318)
				       {
					  kwote_node_102_t knode_3319;
					  {
					     long arg2684_3327;
					     {
						obj_t arg2685_3328;
						{
						   obj_t arg2687_3329;
						   {
						      object_t object_4240;
						      object_4240 = (object_t) (knode_3314);
						      {
							 long arg1180_4241;
							 {
							    long arg1181_4242;
							    long arg1182_4243;
							    arg1181_4242 = TYPE(object_4240);
							    arg1182_4243 = OBJECT_TYPE;
							    arg1180_4241 = (arg1181_4242 - arg1182_4243);
							 }
							 {
							    obj_t vector_4247;
							    vector_4247 = _classes__134___object;
							    arg2687_3329 = VECTOR_REF(vector_4247, arg1180_4241);
							 }
						      }
						   }
						   arg2685_3328 = class_super_145___object(arg2687_3329);
						}
						arg2684_3327 = class_num_218___object(arg2685_3328);
					     }
					     {
						obj_t obj_4249;
						obj_4249 = (obj_t) (knode_3314);
						(((obj_t) CREF(obj_4249))->header = MAKE_HEADER(arg2684_3327, 0), BUNSPEC);
					     }
					  }
					  {
					     object_t aux_5013;
					     aux_5013 = (object_t) (knode_3314);
					     OBJECT_WIDENING_SET(aux_5013, BFALSE);
					  }
					  knode_3319 = knode_3314;
					  {
					     kwote_t duplicated2131_3320;
					     duplicated2131_3320 = (kwote_t) (knode_3319);
					     {
						kwote_t new2132_3321;
						{
						   obj_t arg2679_3322;
						   type_t arg2680_3323;
						   obj_t arg2681_3324;
						   arg2679_3322 = (((kwote_t) CREF(duplicated2131_3320))->loc);
						   arg2680_3323 = (((kwote_t) CREF(duplicated2131_3320))->type);
						   {
						      obj_t arg2683_3325;
						      {
							 kwote_t obj_4253;
							 obj_4253 = (kwote_t) (knode_3314);
							 arg2683_3325 = (((kwote_t) CREF(obj_4253))->value);
						      }
						      {
							 obj_t new_4256;
							 {
							    obj_t aux_5021;
							    aux_5021 = CNST_TABLE_REF(((long) 13));
							    new_4256 = create_struct(aux_5021, ((long) 2));
							 }
							 STRUCT_SET(new_4256, ((long) 1), arg2683_3325);
							 STRUCT_SET(new_4256, ((long) 0), tv_3317);
							 arg2681_3324 = new_4256;
						      }
						   }
						   {
						      kwote_t res2896_4279;
						      {
							 kwote_t new1290_4272;
							 new1290_4272 = ((kwote_t) BREF(GC_MALLOC(sizeof(struct kwote))));
							 {
							    long arg2619_4273;
							    arg2619_4273 = class_num_218___object(kwote_ast_node);
							    {
							       obj_t obj_4277;
							       obj_4277 = (obj_t) (new1290_4272);
							       (((obj_t) CREF(obj_4277))->header = MAKE_HEADER(arg2619_4273, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_5030;
							    aux_5030 = (object_t) (new1290_4272);
							    OBJECT_WIDENING_SET(aux_5030, BFALSE);
							 }
							 ((((kwote_t) CREF(new1290_4272))->loc) = ((obj_t) arg2679_3322), BUNSPEC);
							 ((((kwote_t) CREF(new1290_4272))->type) = ((type_t) arg2680_3323), BUNSPEC);
							 ((((kwote_t) CREF(new1290_4272))->value) = ((obj_t) arg2681_3324), BUNSPEC);
							 res2896_4279 = new1290_4272;
						      }
						      new2132_3321 = res2896_4279;
						   }
						}
						{
						   return (obj_t) (new2132_3321);
						}
					     }
					  }
				       }
				     else
				       {
					  {
					     long arg2688_3331;
					     {
						obj_t arg2689_3332;
						{
						   obj_t arg2690_3333;
						   {
						      object_t object_4280;
						      object_4280 = (object_t) (knode_3314);
						      {
							 long arg1180_4281;
							 {
							    long arg1181_4282;
							    long arg1182_4283;
							    arg1181_4282 = TYPE(object_4280);
							    arg1182_4283 = OBJECT_TYPE;
							    arg1180_4281 = (arg1181_4282 - arg1182_4283);
							 }
							 {
							    obj_t vector_4287;
							    vector_4287 = _classes__134___object;
							    arg2690_3333 = VECTOR_REF(vector_4287, arg1180_4281);
							 }
						      }
						   }
						   arg2689_3332 = class_super_145___object(arg2690_3333);
						}
						arg2688_3331 = class_num_218___object(arg2689_3332);
					     }
					     {
						obj_t obj_4289;
						obj_4289 = (obj_t) (knode_3314);
						(((obj_t) CREF(obj_4289))->header = MAKE_HEADER(arg2688_3331, 0), BUNSPEC);
					     }
					  }
					  {
					     object_t aux_5046;
					     aux_5046 = (object_t) (knode_3314);
					     OBJECT_WIDENING_SET(aux_5046, BFALSE);
					  }
					  return (obj_t) (knode_3314);
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 var_t aux_5050;
			 aux_5050 = (var_t) (node_39);
			 return (obj_t) (aux_5050);
		      }
		      break;
		   case ((long) 4):
		      {
			 obj_t arg2694_3339;
			 {
			    obj_t aux_5053;
			    {
			       closure_t aux_5054;
			       aux_5054 = (closure_t) (node_39);
			       aux_5053 = (obj_t) (aux_5054);
			    }
			    arg2694_3339 = shape_tools_shape(aux_5053);
			 }
			 return internal_error_43_tools_error(string2905_cfa_tvector, string2906_cfa_tvector, arg2694_3339);
		      }
		      break;
		   case ((long) 5):
		      {
			 sequence_t node_3340;
			 node_3340 = (sequence_t) (node_39);
			 patch___72_cfa_tvector((((sequence_t) CREF(node_3340))->nodes));
			 return (obj_t) (node_3340);
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_3343;
			 node_3343 = (app_ly_162_t) (node_39);
			 {
			    obj_t arg2696_3345;
			    arg2696_3345 = patch__227_cfa_tvector((((app_ly_162_t) CREF(node_3343))->fun));
			    {
			       node_t val1331_4294;
			       val1331_4294 = (node_t) (arg2696_3345);
			       ((((app_ly_162_t) CREF(node_3343))->fun) = ((node_t) val1331_4294), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2698_3347;
			    arg2698_3347 = patch__227_cfa_tvector((((app_ly_162_t) CREF(node_3343))->arg));
			    {
			       node_t val1332_4297;
			       val1332_4297 = (node_t) (arg2698_3347);
			       ((((app_ly_162_t) CREF(node_3343))->arg) = ((node_t) val1332_4297), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3343);
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_3349;
			 node_3349 = (funcall_t) (node_39);
			 {
			    obj_t arg2700_3351;
			    arg2700_3351 = patch__227_cfa_tvector((((funcall_t) CREF(node_3349))->fun));
			    {
			       node_t val1342_4300;
			       val1342_4300 = (node_t) (arg2700_3351);
			       ((((funcall_t) CREF(node_3349))->fun) = ((node_t) val1342_4300), BUNSPEC);
			    }
			 }
			 patch___72_cfa_tvector((((funcall_t) CREF(node_3349))->args));
			 return (obj_t) (node_3349);
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_3354;
			 node_3354 = (pragma_t) (node_39);
			 patch___72_cfa_tvector((((pragma_t) CREF(node_3354))->args));
			 return (obj_t) (node_3354);
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_3357;
			 node_3357 = (cast_t) (node_39);
			 patch__227_cfa_tvector((((cast_t) CREF(node_3357))->arg));
			 return (obj_t) (node_3357);
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_3360;
			 node_3360 = (setq_t) (node_39);
			 {
			    obj_t arg2705_3362;
			    arg2705_3362 = patch__227_cfa_tvector((((setq_t) CREF(node_3360))->value));
			    {
			       node_t val1375_4306;
			       val1375_4306 = (node_t) (arg2705_3362);
			       ((((setq_t) CREF(node_3360))->value) = ((node_t) val1375_4306), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2707_3364;
			    {
			       node_t aux_5094;
			       {
				  var_t aux_5095;
				  aux_5095 = (((setq_t) CREF(node_3360))->var);
				  aux_5094 = (node_t) (aux_5095);
			       }
			       arg2707_3364 = patch__227_cfa_tvector(aux_5094);
			    }
			    {
			       var_t val1374_4309;
			       val1374_4309 = (var_t) (arg2707_3364);
			       ((((setq_t) CREF(node_3360))->var) = ((var_t) val1374_4309), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3360);
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_3366;
			 node_3366 = (conditional_t) (node_39);
			 {
			    obj_t arg2709_3368;
			    arg2709_3368 = patch__227_cfa_tvector((((conditional_t) CREF(node_3366))->test));
			    {
			       node_t val1389_4312;
			       val1389_4312 = (node_t) (arg2709_3368);
			       ((((conditional_t) CREF(node_3366))->test) = ((node_t) val1389_4312), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2711_3370;
			    arg2711_3370 = patch__227_cfa_tvector((((conditional_t) CREF(node_3366))->true));
			    {
			       node_t val1390_4315;
			       val1390_4315 = (node_t) (arg2711_3370);
			       ((((conditional_t) CREF(node_3366))->true) = ((node_t) val1390_4315), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2713_3372;
			    arg2713_3372 = patch__227_cfa_tvector((((conditional_t) CREF(node_3366))->false));
			    {
			       node_t val1391_4318;
			       val1391_4318 = (node_t) (arg2713_3372);
			       ((((conditional_t) CREF(node_3366))->false) = ((node_t) val1391_4318), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3366);
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_3374;
			 node_3374 = (fail_t) (node_39);
			 {
			    obj_t arg2715_3376;
			    arg2715_3376 = patch__227_cfa_tvector((((fail_t) CREF(node_3374))->proc));
			    {
			       node_t val1401_4321;
			       val1401_4321 = (node_t) (arg2715_3376);
			       ((((fail_t) CREF(node_3374))->proc) = ((node_t) val1401_4321), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2717_3378;
			    arg2717_3378 = patch__227_cfa_tvector((((fail_t) CREF(node_3374))->msg));
			    {
			       node_t val1402_4324;
			       val1402_4324 = (node_t) (arg2717_3378);
			       ((((fail_t) CREF(node_3374))->msg) = ((node_t) val1402_4324), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2720_3380;
			    arg2720_3380 = patch__227_cfa_tvector((((fail_t) CREF(node_3374))->obj));
			    {
			       node_t val1403_4327;
			       val1403_4327 = (node_t) (arg2720_3380);
			       ((((fail_t) CREF(node_3374))->obj) = ((node_t) val1403_4327), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3374);
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_3382;
			 node_3382 = (select_t) (node_39);
			 {
			    obj_t arg2722_3384;
			    arg2722_3384 = patch__227_cfa_tvector((((select_t) CREF(node_3382))->test));
			    {
			       node_t val1417_4330;
			       val1417_4330 = (node_t) (arg2722_3384);
			       ((((select_t) CREF(node_3382))->test) = ((node_t) val1417_4330), BUNSPEC);
			    }
			 }
			 {
			    obj_t l2143_3386;
			    l2143_3386 = (((select_t) CREF(node_3382))->clauses);
			  lname2144_3387:
			    if (PAIRP(l2143_3386))
			      {
				 {
				    obj_t clause_3390;
				    clause_3390 = CAR(l2143_3386);
				    {
				       obj_t arg2727_3391;
				       {
					  node_t aux_5138;
					  {
					     obj_t aux_5139;
					     aux_5139 = CDR(clause_3390);
					     aux_5138 = (node_t) (aux_5139);
					  }
					  arg2727_3391 = patch__227_cfa_tvector(aux_5138);
				       }
				       SET_CDR(clause_3390, arg2727_3391);
				    }
				 }
				 {
				    obj_t l2143_5144;
				    l2143_5144 = CDR(l2143_3386);
				    l2143_3386 = l2143_5144;
				    goto lname2144_3387;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 return (obj_t) (node_3382);
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_3394;
			 node_3394 = (let_fun_218_t) (node_39);
			 {
			    obj_t l2146_3396;
			    l2146_3396 = (((let_fun_218_t) CREF(node_3394))->locals);
			  lname2147_3397:
			    if (PAIRP(l2146_3396))
			      {
				 patch_fun__141_cfa_tvector(CAR(l2146_3396));
				 {
				    obj_t l2146_5153;
				    l2146_5153 = CDR(l2146_3396);
				    l2146_3396 = l2146_5153;
				    goto lname2147_3397;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    obj_t arg2734_3402;
			    arg2734_3402 = patch__227_cfa_tvector((((let_fun_218_t) CREF(node_3394))->body));
			    {
			       node_t val1431_4344;
			       val1431_4344 = (node_t) (arg2734_3402);
			       ((((let_fun_218_t) CREF(node_3394))->body) = ((node_t) val1431_4344), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3394);
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_3404;
			 node_3404 = (let_var_6_t) (node_39);
			 {
			    obj_t l2149_3406;
			    l2149_3406 = (((let_var_6_t) CREF(node_3404))->bindings);
			  lname2150_3407:
			    if (PAIRP(l2149_3406))
			      {
				 {
				    obj_t binding_3410;
				    binding_3410 = CAR(l2149_3406);
				    {
				       obj_t arg2738_3412;
				       {
					  node_t aux_5165;
					  {
					     obj_t aux_5166;
					     aux_5166 = CDR(binding_3410);
					     aux_5165 = (node_t) (aux_5166);
					  }
					  arg2738_3412 = patch__227_cfa_tvector(aux_5165);
				       }
				       SET_CDR(binding_3410, arg2738_3412);
				    }
				 }
				 {
				    obj_t l2149_5171;
				    l2149_5171 = CDR(l2149_3406);
				    l2149_3406 = l2149_5171;
				    goto lname2150_3407;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    obj_t arg2740_3414;
			    arg2740_3414 = patch__227_cfa_tvector((((let_var_6_t) CREF(node_3404))->body));
			    {
			       node_t val1446_4354;
			       val1446_4354 = (node_t) (arg2740_3414);
			       ((((let_var_6_t) CREF(node_3404))->body) = ((node_t) val1446_4354), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3404);
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_3416;
			 node_3416 = (set_ex_it_116_t) (node_39);
			 {
			    obj_t arg2742_3418;
			    arg2742_3418 = patch__227_cfa_tvector((((set_ex_it_116_t) CREF(node_3416))->body));
			    {
			       node_t val1457_4357;
			       val1457_4357 = (node_t) (arg2742_3418);
			       ((((set_ex_it_116_t) CREF(node_3416))->body) = ((node_t) val1457_4357), BUNSPEC);
			    }
			 }
			 {
			    node_t aux_5184;
			    {
			       var_t aux_5185;
			       aux_5185 = (((set_ex_it_116_t) CREF(node_3416))->var);
			       aux_5184 = (node_t) (aux_5185);
			    }
			    patch__227_cfa_tvector(aux_5184);
			 }
			 return (obj_t) (node_3416);
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_3421;
			 node_3421 = (jump_ex_it_184_t) (node_39);
			 {
			    obj_t arg2745_3423;
			    arg2745_3423 = patch__227_cfa_tvector((((jump_ex_it_184_t) CREF(node_3421))->exit));
			    {
			       node_t val1466_4361;
			       val1466_4361 = (node_t) (arg2745_3423);
			       ((((jump_ex_it_184_t) CREF(node_3421))->exit) = ((node_t) val1466_4361), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2747_3425;
			    arg2747_3425 = patch__227_cfa_tvector((((jump_ex_it_184_t) CREF(node_3421))->value));
			    {
			       node_t val1467_4364;
			       val1467_4364 = (node_t) (arg2747_3425);
			       ((((jump_ex_it_184_t) CREF(node_3421))->value) = ((node_t) val1467_4364), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3421);
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_3427;
			 node_3427 = (make_box_202_t) (node_39);
			 {
			    obj_t arg2749_3429;
			    arg2749_3429 = patch__227_cfa_tvector((((make_box_202_t) CREF(node_3427))->value));
			    {
			       node_t val1479_4367;
			       val1479_4367 = (node_t) (arg2749_3429);
			       ((((make_box_202_t) CREF(node_3427))->value) = ((node_t) val1479_4367), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3427);
		      }
		      break;
		   case ((long) 19):
		      {
			 box_set__221_t node_3431;
			 node_3431 = (box_set__221_t) (node_39);
			 {
			    obj_t arg2751_3433;
			    {
			       node_t aux_5207;
			       {
				  var_t aux_5208;
				  aux_5208 = (((box_set__221_t) CREF(node_3431))->var);
				  aux_5207 = (node_t) (aux_5208);
			       }
			       arg2751_3433 = patch__227_cfa_tvector(aux_5207);
			    }
			    {
			       var_t val1500_4370;
			       val1500_4370 = (var_t) (arg2751_3433);
			       ((((box_set__221_t) CREF(node_3431))->var) = ((var_t) val1500_4370), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2753_3435;
			    arg2753_3435 = patch__227_cfa_tvector((((box_set__221_t) CREF(node_3431))->value));
			    {
			       node_t val1501_4373;
			       val1501_4373 = (node_t) (arg2753_3435);
			       ((((box_set__221_t) CREF(node_3431))->value) = ((node_t) val1501_4373), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3431);
		      }
		      break;
		   case ((long) 20):
		      {
			 box_ref_242_t node_3437;
			 node_3437 = (box_ref_242_t) (node_39);
			 {
			    obj_t arg2755_3439;
			    {
			       node_t aux_5220;
			       {
				  var_t aux_5221;
				  aux_5221 = (((box_ref_242_t) CREF(node_3437))->var);
				  aux_5220 = (node_t) (aux_5221);
			       }
			       arg2755_3439 = patch__227_cfa_tvector(aux_5220);
			    }
			    {
			       var_t val1491_4376;
			       val1491_4376 = (var_t) (arg2755_3439);
			       ((((box_ref_242_t) CREF(node_3437))->var) = ((var_t) val1491_4376), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_3437);
		      }
		      break;
		   case ((long) 21):
		      {
			 app_t node_3441;
			 node_3441 = (app_t) (node_39);
			 patch___72_cfa_tvector((((app_t) CREF(node_3441))->args));
			 {
			    obj_t arg2758_3444;
			    {
			       node_t aux_5231;
			       {
				  var_t aux_5232;
				  aux_5232 = (((app_t) CREF(node_3441))->fun);
				  aux_5231 = (node_t) (aux_5232);
			       }
			       arg2758_3444 = patch__227_cfa_tvector(aux_5231);
			    }
			    {
			       var_t val1320_4380;
			       val1320_4380 = (var_t) (arg2758_3444);
			       ((((app_t) CREF(node_3441))->fun) = ((var_t) val1320_4380), BUNSPEC);
			    }
			 }
			 {
			    variable_t v_3446;
			    {
			       var_t arg2773_3461;
			       arg2773_3461 = (((app_t) CREF(node_3441))->fun);
			       v_3446 = (((var_t) CREF(arg2773_3461))->variable);
			    }
			    {
			       bool_t test2760_3447;
			       test2760_3447 = is_a__118___object((obj_t) (v_3446), global_ast_var);
			       if (test2760_3447)
				 {
				    bool_t test2761_3448;
				    {
				       obj_t aux_5243;
				       {
					  value_t aux_5244;
					  aux_5244 = (((variable_t) CREF(v_3446))->value);
					  aux_5243 = (obj_t) (aux_5244);
				       }
				       test2761_3448 = is_a__118___object(aux_5243, cfun_ast_var);
				    }
				    if (test2761_3448)
				      {
					 obj_t case_value_58_3449;
					 {
					    global_t obj_4386;
					    obj_4386 = (global_t) (v_3446);
					    case_value_58_3449 = (((global_t) CREF(obj_4386))->id);
					 }
					 {
					    bool_t test_5251;
					    {
					       obj_t aux_5252;
					       aux_5252 = CNST_TABLE_REF(((long) 14));
					       test_5251 = (case_value_58_3449 == aux_5252);
					    }
					    if (test_5251)
					      {
						 return patch_vector_length__86_cfa_tvector(node_3441);
					      }
					    else
					      {
						 bool_t test_5256;
						 {
						    obj_t aux_5257;
						    aux_5257 = CNST_TABLE_REF(((long) 1));
						    test_5256 = (case_value_58_3449 == aux_5257);
						 }
						 if (test_5256)
						   {
						      return patch_vector___0_cfa_tvector(node_3441);
						   }
						 else
						   {
						      return (obj_t) (node_3441);
						   }
					      }
					 }
				      }
				    else
				      {
					 bool_t test_5262;
					 {
					    bool_t test_5263;
					    {
					       obj_t aux_5267;
					       obj_t aux_5264;
					       aux_5267 = CNST_TABLE_REF(((long) 15));
					       {
						  global_t obj_4391;
						  obj_4391 = (global_t) (v_3446);
						  aux_5264 = (((global_t) CREF(obj_4391))->id);
					       }
					       test_5263 = (aux_5264 == aux_5267);
					    }
					    if (test_5263)
					      {
						 obj_t aux_5273;
						 obj_t aux_5270;
						 aux_5273 = CNST_TABLE_REF(((long) 16));
						 {
						    global_t obj_4394;
						    obj_4394 = (global_t) (v_3446);
						    aux_5270 = (((global_t) CREF(obj_4394))->module);
						 }
						 test_5262 = (aux_5270 == aux_5273);
					      }
					    else
					      {
						 test_5262 = ((bool_t) 0);
					      }
					 }
					 if (test_5262)
					   {
					      return patch_vector__list__149_cfa_tvector(node_3441);
					   }
					 else
					   {
					      return (obj_t) (node_3441);
					   }
				      }
				 }
			       else
				 {
				    return (obj_t) (node_3441);
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 22):
		      {
			 make_vector_app_205_t node_3462;
			 node_3462 = (make_vector_app_205_t) (node_39);
			 {
			    obj_t aux_5280;
			    {
			       app_t obj_4397;
			       obj_4397 = (app_t) (node_3462);
			       aux_5280 = (((app_t) CREF(obj_4397))->args);
			    }
			    patch___72_cfa_tvector(aux_5280);
			 }
			 {
			    type_t type_3465;
			    {
			       approx_t arg2797_3491;
			       {
				  obj_t aux_5284;
				  {
				     object_t aux_5285;
				     aux_5285 = (object_t) (node_3462);
				     aux_5284 = OBJECT_WIDENING(aux_5285);
				  }
				  arg2797_3491 = (((make_vector_app_205_t) CREF(aux_5284))->value_approx_19);
			       }
			       type_3465 = (((approx_t) CREF(arg2797_3491))->type);
			    }
			    {
			       obj_t tv_3466;
			       tv_3466 = (((type_t) CREF(type_3465))->tvector);
			       {
				  {
				     bool_t test2775_3467;
				     test2775_3467 = is_a__118___object(tv_3466, type_type_type);
				     if (test2775_3467)
				       {
					  obj_t make_tv_69_3468;
					  {
					     obj_t arg2792_3486;
					     arg2792_3486 = CNST_TABLE_REF(((long) 17));
					     {
						obj_t list2794_3488;
						{
						   obj_t arg2795_3489;
						   {
						      obj_t aux_5294;
						      {
							 type_t obj_4402;
							 obj_4402 = (type_t) (tv_3466);
							 aux_5294 = (((type_t) CREF(obj_4402))->id);
						      }
						      arg2795_3489 = MAKE_PAIR(aux_5294, BNIL);
						   }
						   list2794_3488 = MAKE_PAIR(arg2792_3486, arg2795_3489);
						}
						make_tv_69_3468 = symbol_append_197___r4_symbols_6_4(list2794_3488);
					     }
					  }
					  {
					     node_t new_node_11_3469;
					     {
						obj_t arg2781_3475;
						obj_t arg2783_3477;
						obj_t arg2784_3478;
						{
						   obj_t arg2785_3479;
						   {
						      obj_t arg2788_3482;
						      obj_t arg2789_3483;
						      {
							 app_t obj_4403;
							 obj_4403 = (app_t) (node_3462);
							 arg2788_3482 = (((app_t) CREF(obj_4403))->args);
						      }
						      arg2789_3483 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						      arg2785_3479 = append_2_18___r4_pairs_and_lists_6_3(arg2788_3482, arg2789_3483);
						   }
						   {
						      obj_t list2786_3480;
						      list2786_3480 = MAKE_PAIR(arg2785_3479, BNIL);
						      arg2781_3475 = cons__138___r4_pairs_and_lists_6_3(make_tv_69_3468, list2786_3480);
						   }
						}
						{
						   app_t obj_4404;
						   obj_4404 = (app_t) (node_3462);
						   arg2783_3477 = (((app_t) CREF(obj_4404))->loc);
						}
						arg2784_3478 = CNST_TABLE_REF(((long) 10));
						new_node_11_3469 = sexp__node_235_ast_sexp(arg2781_3475, BNIL, arg2783_3477, arg2784_3478);
					     }
					     {
						{
						   type_t val1254_4406;
						   val1254_4406 = (type_t) (tv_3466);
						   ((((node_t) CREF(new_node_11_3469))->type) = ((type_t) val1254_4406), BUNSPEC);
						}
						{
						   node_t arg2776_3470;
						   {
						      bool_t test2779_3473;
						      test2779_3473 = stack_optimization__133_cfa_stack();
						      if (test2779_3473)
							{
							   bool_t aux_5314;
							   {
							      obj_t aux_5316;
							      {
								 object_t aux_5317;
								 aux_5317 = (object_t) (node_3462);
								 aux_5316 = OBJECT_WIDENING(aux_5317);
							      }
							      aux_5314 = (((make_vector_app_205_t) CREF(aux_5316))->stackable__42);
							   }
							   arg2776_3470 = node_heap__stack__239_cfa_stack((app_t) (new_node_11_3469), aux_5314);
							}
						      else
							{
							   arg2776_3470 = new_node_11_3469;
							}
						   }
						   {
						      node_t aux_5322;
						      aux_5322 = inline_node_218_inline_inline(arg2776_3470, ((long) 1), BNIL);
						      return (obj_t) (aux_5322);
						   }
						}
					     }
					  }
				       }
				     else
				       {
					  return (obj_t) (node_3462);
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 23):
		      {
			 create_vector_app_150_t node_3492;
			 node_3492 = (create_vector_app_150_t) (node_39);
			 {
			    obj_t aux_5327;
			    {
			       app_t obj_4408;
			       obj_4408 = (app_t) (node_3492);
			       aux_5327 = (((app_t) CREF(obj_4408))->args);
			    }
			    patch___72_cfa_tvector(aux_5327);
			 }
			 {
			    type_t type_3495;
			    {
			       approx_t arg2821_3521;
			       {
				  obj_t aux_5331;
				  {
				     object_t aux_5332;
				     aux_5332 = (object_t) (node_3492);
				     aux_5331 = OBJECT_WIDENING(aux_5332);
				  }
				  arg2821_3521 = (((create_vector_app_150_t) CREF(aux_5331))->value_approx_19);
			       }
			       type_3495 = (((approx_t) CREF(arg2821_3521))->type);
			    }
			    {
			       obj_t tv_3496;
			       tv_3496 = (((type_t) CREF(type_3495))->tvector);
			       {
				  {
				     bool_t test2799_3497;
				     test2799_3497 = is_a__118___object(tv_3496, type_type_type);
				     if (test2799_3497)
				       {
					  obj_t create_tv_3_3498;
					  {
					     obj_t arg2816_3516;
					     arg2816_3516 = CNST_TABLE_REF(((long) 18));
					     {
						obj_t list2818_3518;
						{
						   obj_t arg2819_3519;
						   {
						      obj_t aux_5341;
						      {
							 type_t obj_4413;
							 obj_4413 = (type_t) (tv_3496);
							 aux_5341 = (((type_t) CREF(obj_4413))->id);
						      }
						      arg2819_3519 = MAKE_PAIR(aux_5341, BNIL);
						   }
						   list2818_3518 = MAKE_PAIR(arg2816_3516, arg2819_3519);
						}
						create_tv_3_3498 = symbol_append_197___r4_symbols_6_4(list2818_3518);
					     }
					  }
					  {
					     node_t new_node_11_3499;
					     {
						obj_t arg2805_3505;
						obj_t arg2807_3507;
						obj_t arg2808_3508;
						{
						   obj_t arg2809_3509;
						   {
						      obj_t arg2812_3512;
						      obj_t arg2813_3513;
						      {
							 app_t obj_4414;
							 obj_4414 = (app_t) (node_3492);
							 arg2812_3512 = (((app_t) CREF(obj_4414))->args);
						      }
						      arg2813_3513 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						      arg2809_3509 = append_2_18___r4_pairs_and_lists_6_3(arg2812_3512, arg2813_3513);
						   }
						   {
						      obj_t list2810_3510;
						      list2810_3510 = MAKE_PAIR(arg2809_3509, BNIL);
						      arg2805_3505 = cons__138___r4_pairs_and_lists_6_3(create_tv_3_3498, list2810_3510);
						   }
						}
						{
						   app_t obj_4415;
						   obj_4415 = (app_t) (node_3492);
						   arg2807_3507 = (((app_t) CREF(obj_4415))->loc);
						}
						arg2808_3508 = CNST_TABLE_REF(((long) 10));
						new_node_11_3499 = sexp__node_235_ast_sexp(arg2805_3505, BNIL, arg2807_3507, arg2808_3508);
					     }
					     {
						{
						   type_t val1254_4417;
						   val1254_4417 = (type_t) (tv_3496);
						   ((((node_t) CREF(new_node_11_3499))->type) = ((type_t) val1254_4417), BUNSPEC);
						}
						{
						   node_t arg2800_3500;
						   {
						      bool_t test2803_3503;
						      test2803_3503 = stack_optimization__133_cfa_stack();
						      if (test2803_3503)
							{
							   bool_t aux_5361;
							   {
							      obj_t aux_5363;
							      {
								 object_t aux_5364;
								 aux_5364 = (object_t) (node_3492);
								 aux_5363 = OBJECT_WIDENING(aux_5364);
							      }
							      aux_5361 = (((create_vector_app_150_t) CREF(aux_5363))->stackable__42);
							   }
							   arg2800_3500 = node_heap__stack__239_cfa_stack((app_t) (new_node_11_3499), aux_5361);
							}
						      else
							{
							   arg2800_3500 = new_node_11_3499;
							}
						   }
						   {
						      node_t aux_5369;
						      aux_5369 = inline_node_218_inline_inline(arg2800_3500, ((long) 1), BNIL);
						      return (obj_t) (aux_5369);
						   }
						}
					     }
					  }
				       }
				     else
				       {
					  return (obj_t) (node_3492);
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 24):
		      {
			 vector_ref_app_195_t node_3522;
			 node_3522 = (vector_ref_app_195_t) (node_39);
			 {
			    obj_t aux_5374;
			    {
			       app_t obj_4419;
			       obj_4419 = (app_t) (node_3522);
			       aux_5374 = (((app_t) CREF(obj_4419))->args);
			    }
			    patch___72_cfa_tvector(aux_5374);
			 }
			 {
			    approx_t vec_approx_215_3525;
			    {
			       node_t aux_5378;
			       {
				  obj_t aux_5379;
				  {
				     obj_t aux_5380;
				     {
					app_t obj_4420;
					obj_4420 = (app_t) (node_3522);
					aux_5380 = (((app_t) CREF(obj_4420))->args);
				     }
				     aux_5379 = CAR(aux_5380);
				  }
				  aux_5378 = (node_t) (aux_5379);
			       }
			       vec_approx_215_3525 = cfa__102_cfa_cfa(aux_5378);
			    }
			    {
			       obj_t tv_3526;
			       tv_3526 = get_approx_type_210_cfa_type(vec_approx_215_3525);
			       {
				  {
				     bool_t test2823_3527;
				     test2823_3527 = is_a__118___object(tv_3526, tvec_tvector_tvector);
				     if (test2823_3527)
				       {
					  obj_t tv_ref_74_3528;
					  {
					     obj_t arg2837_3543;
					     {
						type_t obj_4423;
						obj_4423 = (type_t) (tv_3526);
						arg2837_3543 = (((type_t) CREF(obj_4423))->id);
					     }
					     {
						obj_t list2839_3545;
						{
						   obj_t arg2840_3546;
						   {
						      obj_t aux_5391;
						      aux_5391 = CNST_TABLE_REF(((long) 19));
						      arg2840_3546 = MAKE_PAIR(aux_5391, BNIL);
						   }
						   list2839_3545 = MAKE_PAIR(arg2837_3543, arg2840_3546);
						}
						tv_ref_74_3528 = symbol_append_197___r4_symbols_6_4(list2839_3545);
					     }
					  }
					  {
					     node_t new_node_11_3529;
					     {
						obj_t arg2826_3532;
						obj_t arg2828_3534;
						obj_t arg2829_3535;
						{
						   obj_t arg2830_3536;
						   {
						      obj_t arg2833_3539;
						      obj_t arg2834_3540;
						      {
							 app_t obj_4424;
							 obj_4424 = (app_t) (node_3522);
							 arg2833_3539 = (((app_t) CREF(obj_4424))->args);
						      }
						      arg2834_3540 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						      arg2830_3536 = append_2_18___r4_pairs_and_lists_6_3(arg2833_3539, arg2834_3540);
						   }
						   {
						      obj_t list2831_3537;
						      list2831_3537 = MAKE_PAIR(arg2830_3536, BNIL);
						      arg2826_3532 = cons__138___r4_pairs_and_lists_6_3(tv_ref_74_3528, list2831_3537);
						   }
						}
						{
						   app_t obj_4425;
						   obj_4425 = (app_t) (node_3522);
						   arg2828_3534 = (((app_t) CREF(obj_4425))->loc);
						}
						arg2829_3535 = CNST_TABLE_REF(((long) 10));
						new_node_11_3529 = sexp__node_235_ast_sexp(arg2826_3532, BNIL, arg2828_3534, arg2829_3535);
					     }
					     {
						{
						   node_t aux_5406;
						   aux_5406 = inline_node_218_inline_inline(new_node_11_3529, ((long) 1), BNIL);
						   return (obj_t) (aux_5406);
						}
					     }
					  }
				       }
				     else
				       {
					  return (obj_t) (node_3522);
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 25):
		      {
			 vector_set__app_21_t node_3550;
			 node_3550 = (vector_set__app_21_t) (node_39);
			 {
			    obj_t aux_5411;
			    {
			       app_t obj_4426;
			       obj_4426 = (app_t) (node_3550);
			       aux_5411 = (((app_t) CREF(obj_4426))->args);
			    }
			    patch___72_cfa_tvector(aux_5411);
			 }
			 {
			    approx_t vec_approx_215_3553;
			    {
			       node_t aux_5415;
			       {
				  obj_t aux_5416;
				  {
				     obj_t aux_5417;
				     {
					app_t obj_4427;
					obj_4427 = (app_t) (node_3550);
					aux_5417 = (((app_t) CREF(obj_4427))->args);
				     }
				     aux_5416 = CAR(aux_5417);
				  }
				  aux_5415 = (node_t) (aux_5416);
			       }
			       vec_approx_215_3553 = cfa__102_cfa_cfa(aux_5415);
			    }
			    {
			       obj_t tv_3554;
			       tv_3554 = get_approx_type_210_cfa_type(vec_approx_215_3553);
			       {
				  {
				     bool_t test2845_3555;
				     test2845_3555 = is_a__118___object(tv_3554, tvec_tvector_tvector);
				     if (test2845_3555)
				       {
					  obj_t tv_set__238_3556;
					  {
					     obj_t arg2859_3571;
					     {
						type_t obj_4430;
						obj_4430 = (type_t) (tv_3554);
						arg2859_3571 = (((type_t) CREF(obj_4430))->id);
					     }
					     {
						obj_t list2861_3573;
						{
						   obj_t arg2862_3574;
						   {
						      obj_t aux_5428;
						      aux_5428 = CNST_TABLE_REF(((long) 20));
						      arg2862_3574 = MAKE_PAIR(aux_5428, BNIL);
						   }
						   list2861_3573 = MAKE_PAIR(arg2859_3571, arg2862_3574);
						}
						tv_set__238_3556 = symbol_append_197___r4_symbols_6_4(list2861_3573);
					     }
					  }
					  {
					     node_t new_node_11_3557;
					     {
						obj_t arg2848_3560;
						obj_t arg2850_3562;
						obj_t arg2851_3563;
						{
						   obj_t arg2852_3564;
						   {
						      obj_t arg2855_3567;
						      obj_t arg2856_3568;
						      {
							 app_t obj_4431;
							 obj_4431 = (app_t) (node_3550);
							 arg2855_3567 = (((app_t) CREF(obj_4431))->args);
						      }
						      arg2856_3568 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						      arg2852_3564 = append_2_18___r4_pairs_and_lists_6_3(arg2855_3567, arg2856_3568);
						   }
						   {
						      obj_t list2853_3565;
						      list2853_3565 = MAKE_PAIR(arg2852_3564, BNIL);
						      arg2848_3560 = cons__138___r4_pairs_and_lists_6_3(tv_set__238_3556, list2853_3565);
						   }
						}
						{
						   app_t obj_4432;
						   obj_4432 = (app_t) (node_3550);
						   arg2850_3562 = (((app_t) CREF(obj_4432))->loc);
						}
						arg2851_3563 = CNST_TABLE_REF(((long) 10));
						new_node_11_3557 = sexp__node_235_ast_sexp(arg2848_3560, BNIL, arg2850_3562, arg2851_3563);
					     }
					     {
						{
						   node_t aux_5443;
						   aux_5443 = inline_node_218_inline_inline(new_node_11_3557, ((long) 1), BNIL);
						   return (obj_t) (aux_5443);
						}
					     }
					  }
				       }
				     else
				       {
					  return (obj_t) (node_3550);
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   default:
		    case_else2671_3309:
		      if (PROCEDUREP(method2665_3305))
			{
			   return PROCEDURE_ENTRY(method2665_3305) (method2665_3305, (obj_t) (node_39), BEOA);
			}
		      else
			{
			   obj_t fun2662_3299;
			   fun2662_3299 = PROCEDURE_REF(patch__env_129_cfa_tvector, ((long) 0));
			   return PROCEDURE_ENTRY(fun2662_3299) (fun2662_3299, (obj_t) (node_39), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2671_3309;
	      }
	 }
      }
   }
}


/* _patch!2900 */ obj_t 
_patch_2900_188_cfa_tvector(obj_t env_4451, obj_t node_4452)
{
   return patch__227_cfa_tvector((node_t) (node_4452));
}


/* patch!-default2169 */ obj_t 
patch__default2169_106_cfa_tvector(node_t node_40)
{
   FAILURE(CNST_TABLE_REF(((long) 21)), string2904_cfa_tvector, (obj_t) (node_40));
}


/* _patch!-default2169 */ obj_t 
_patch__default2169_94_cfa_tvector(obj_t env_4453, obj_t node_4454)
{
   return patch__default2169_106_cfa_tvector((node_t) (node_4454));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_tvector()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_TVECTOR");
   module_initialization_70_engine_param(((long) 0), "CFA_TVECTOR");
   module_initialization_70_module_type(((long) 0), "CFA_TVECTOR");
   module_initialization_70_module_pragma(((long) 0), "CFA_TVECTOR");
   module_initialization_70_type_type(((long) 0), "CFA_TVECTOR");
   module_initialization_70_type_cache(((long) 0), "CFA_TVECTOR");
   module_initialization_70_type_env(((long) 0), "CFA_TVECTOR");
   module_initialization_70_tvector_tvector(((long) 0), "CFA_TVECTOR");
   module_initialization_70_tools_shape(((long) 0), "CFA_TVECTOR");
   module_initialization_70_tools_speek(((long) 0), "CFA_TVECTOR");
   module_initialization_70_tools_error(((long) 0), "CFA_TVECTOR");
   module_initialization_70_ast_var(((long) 0), "CFA_TVECTOR");
   module_initialization_70_ast_node(((long) 0), "CFA_TVECTOR");
   module_initialization_70_ast_build(((long) 0), "CFA_TVECTOR");
   module_initialization_70_ast_sexp(((long) 0), "CFA_TVECTOR");
   module_initialization_70_ast_env(((long) 0), "CFA_TVECTOR");
   module_initialization_70_cfa_info(((long) 0), "CFA_TVECTOR");
   module_initialization_70_cfa_cfa(((long) 0), "CFA_TVECTOR");
   module_initialization_70_cfa_approx(((long) 0), "CFA_TVECTOR");
   module_initialization_70_cfa_set(((long) 0), "CFA_TVECTOR");
   module_initialization_70_cfa_type(((long) 0), "CFA_TVECTOR");
   module_initialization_70_cfa_stack(((long) 0), "CFA_TVECTOR");
   module_initialization_70_globalize_walk(((long) 0), "CFA_TVECTOR");
   module_initialization_70_inline_inline(((long) 0), "CFA_TVECTOR");
   return module_initialization_70_inline_walk(((long) 0), "CFA_TVECTOR");
}
