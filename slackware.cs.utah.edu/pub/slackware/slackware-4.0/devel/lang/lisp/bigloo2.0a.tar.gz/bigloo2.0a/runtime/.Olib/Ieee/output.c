/*===========================================================================*/
/*   (Ieee/output.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>


/* Object type definitions */

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
extern obj_t object_write_132___object(object_t, obj_t);
static obj_t method_init_76___r4_output_6_10_3();
extern obj_t string_to_symbol(char *);
static obj_t rhandler1007___r4_output_6_10_3(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t write_display_tvector_50___r4_output_6_10_3(obj_t, obj_t, bool_t);
extern obj_t current_output_port;
static obj_t _set_printer_1406_212___r4_output_6_10_3(obj_t, obj_t);
extern obj_t display__75___r4_output_6_10_3(obj_t);
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t body1009___r4_output_6_10_3(obj_t);
extern obj_t set_printer__238___r4_output_6_10_3(obj_t);
extern obj_t display_fixnum(obj_t, obj_t);
extern obj_t exitd_top;
static obj_t _print___r4_output_6_10_3(obj_t, obj_t);
static obj_t toplevel_init_63___r4_output_6_10_3();
extern obj_t display_ucs2(obj_t, obj_t);
extern obj_t tvector_id_255___tvector(obj_t);
extern obj_t write__14___r4_output_6_10_3(obj_t);
static obj_t _write_char1403_219___r4_output_6_10_3(obj_t, obj_t, obj_t);
extern obj_t ill_char_rep(unsigned char);
extern obj_t print___r4_output_6_10_3(obj_t);
static obj_t native_display_62___r4_output_6_10_3(obj_t, obj_t);
extern obj_t native_printer_249___r4_output_6_10_3();
static obj_t write_display_pair_103___r4_output_6_10_3(obj_t, obj_t, bool_t);
static obj_t _get_write_length_196___r4_output_6_10_3(obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _c_debugging_print_109___r4_output_6_10_3(obj_t, obj_t);
static obj_t _write__154___r4_output_6_10_3(obj_t, obj_t);
static obj_t write_display_159___r4_output_6_10_3(obj_t, obj_t, bool_t);
extern obj_t display_string(obj_t, obj_t);
extern obj_t display_char(obj_t, obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t _displayed__5___r4_output_6_10_3 = BUNSPEC;
extern obj_t ucs2_string_to_utf8_string(obj_t);
extern obj_t object_display_243___object(object_t, obj_t);
extern obj_t dprint(obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _fprint1405___r4_output_6_10_3(obj_t, obj_t, obj_t);
extern obj_t display_ucs2string(obj_t, obj_t);
extern obj_t illegal_char_rep_197___r4_output_6_10_3(unsigned char);
static obj_t handling_function1033___r4_output_6_10_3(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
static obj_t _current_printer__39___r4_output_6_10_3 = BUNSPEC;
extern long get_write_length_193___r4_output_6_10_3();
extern obj_t write_ucs2(obj_t, obj_t);
extern obj_t tvector_ref_208___tvector(obj_t);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t arg1035___r4_output_6_10_3(obj_t);
static obj_t arg1034___r4_output_6_10_3(obj_t);
extern obj_t remove_error_handler__102___error();
extern obj_t write_utf8string(obj_t, obj_t);
static obj_t _illegal_char_rep1404_60___r4_output_6_10_3(obj_t, obj_t);
static obj_t symbol2395___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2394___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2393___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2392___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2391___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2389___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2390___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2388___r4_output_6_10_3 = BUNSPEC;
static obj_t _set_write_length_1402_158___r4_output_6_10_3(obj_t, obj_t);
static obj_t symbol2387___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2386___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2385___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2383___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2381___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2379___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2380___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2375___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2370___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2367___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2356___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2355___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2354___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2352___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2351___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2349___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2350___r4_output_6_10_3 = BUNSPEC;
extern obj_t write_string(obj_t, obj_t);
static obj_t symbol2347___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2346___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2345___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2344___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2343___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2339___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2338___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2335___r4_output_6_10_3 = BUNSPEC;
static obj_t _write___r4_output_6_10_3(obj_t, obj_t, obj_t);
static obj_t symbol2334___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2331___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2329___r4_output_6_10_3 = BUNSPEC;
static obj_t symbol2330___r4_output_6_10_3 = BUNSPEC;
static obj_t write_display_structure_107___r4_output_6_10_3(obj_t, obj_t, bool_t);
extern obj_t display_flonum(obj_t, obj_t);
extern obj_t write_object(obj_t, obj_t);
static obj_t list2378___r4_output_6_10_3 = BUNSPEC;
static obj_t list2342___r4_output_6_10_3 = BUNSPEC;
static obj_t _display___r4_output_6_10_3(obj_t, obj_t, obj_t);
extern obj_t write___r4_output_6_10_3(obj_t, obj_t);
static obj_t escape___r4_output_6_10_3(obj_t, obj_t);
static obj_t _newline___r4_output_6_10_3(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_output_6_10_3();
static obj_t _native_display_199___r4_output_6_10_3(obj_t, obj_t, obj_t);
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t _native_printer_193___r4_output_6_10_3(obj_t);
extern obj_t set_write_length__244___r4_output_6_10_3(long);
static obj_t require_initialization_114___r4_output_6_10_3 = BUNSPEC;
static obj_t _max_length_write__149___r4_output_6_10_3 = BUNSPEC;
extern obj_t write_char(obj_t, obj_t);
extern obj_t string_for_read(obj_t);
static obj_t _display__37___r4_output_6_10_3(obj_t, obj_t);
extern obj_t write_char_165___r4_output_6_10_3(unsigned char, obj_t);
static obj_t cnst_init_137___r4_output_6_10_3();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t write_display_vector_76___r4_output_6_10_3(obj_t, obj_t, bool_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( set_write_length__env_212___r4_output_6_10_3, _set_write_length_1402_158___r4_output_6_10_32397, _set_write_length_1402_158___r4_output_6_10_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( display_env_131___r4_output_6_10_3, _display___r4_output_6_10_32398, va_generic_entry, _display___r4_output_6_10_3, -2 );
DEFINE_EXPORT_PROCEDURE( newline_env_143___r4_output_6_10_3, _newline___r4_output_6_10_32399, va_generic_entry, _newline___r4_output_6_10_3, -1 );
DEFINE_STATIC_PROCEDURE( native_display_env_3___r4_output_6_10_3, _native_display_199___r4_output_6_10_32400, va_generic_entry, _native_display_199___r4_output_6_10_3, -2 );
DEFINE_EXPORT_PROCEDURE( write_char_env_35___r4_output_6_10_3, _write_char1403_219___r4_output_6_10_32401, va_generic_entry, _write_char1403_219___r4_output_6_10_3, -2 );
DEFINE_EXPORT_PROCEDURE( get_write_length_env_149___r4_output_6_10_3, _get_write_length_196___r4_output_6_10_32402, _get_write_length_196___r4_output_6_10_3, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( write_env_37___r4_output_6_10_3, _write___r4_output_6_10_32403, va_generic_entry, _write___r4_output_6_10_3, -2 );
DEFINE_STRING( string2384___r4_output_6_10_3, string2384___r4_output_6_10_32404, " . ... )", 8 );
DEFINE_STRING( string2382___r4_output_6_10_3, string2382___r4_output_6_10_32405, "...)", 4 );
DEFINE_STRING( string2377___r4_output_6_10_3, string2377___r4_output_6_10_32406, "WRITE/DISPLAY-TVECTOR:Wrong number of arguments", 47 );
DEFINE_STRING( string2376___r4_output_6_10_3, string2376___r4_output_6_10_32407, "TVECTOR", 7 );
DEFINE_STRING( string2374___r4_output_6_10_3, string2374___r4_output_6_10_32408, "index out of range", 18 );
DEFINE_STRING( string2373___r4_output_6_10_3, string2373___r4_output_6_10_32409, "vector-ref", 10 );
DEFINE_STRING( string2372___r4_output_6_10_3, string2372___r4_output_6_10_32410, "... )", 5 );
DEFINE_STRING( string2371___r4_output_6_10_3, string2371___r4_output_6_10_32411, "VECTOR", 6 );
DEFINE_STRING( string2369___r4_output_6_10_3, string2369___r4_output_6_10_32412, "... }", 5 );
DEFINE_STRING( string2368___r4_output_6_10_3, string2368___r4_output_6_10_32413, "STRUCT", 6 );
DEFINE_STRING( string2366___r4_output_6_10_3, string2366___r4_output_6_10_32414, "UCS2STRING", 10 );
DEFINE_STRING( string2365___r4_output_6_10_3, string2365___r4_output_6_10_32415, "OBJECT", 6 );
DEFINE_STRING( string2364___r4_output_6_10_3, string2364___r4_output_6_10_32416, ">", 1 );
DEFINE_STRING( string2363___r4_output_6_10_3, string2363___r4_output_6_10_32417, "#<cell:", 7 );
DEFINE_STRING( string2362___r4_output_6_10_3, string2362___r4_output_6_10_32418, "REAL", 4 );
DEFINE_EXPORT_PROCEDURE( write__env_225___r4_output_6_10_3, _write__154___r4_output_6_10_32419, va_generic_entry, _write__154___r4_output_6_10_3, -1 );
DEFINE_STRING( string2361___r4_output_6_10_3, string2361___r4_output_6_10_32420, "BSTRING", 7 );
DEFINE_STRING( string2359___r4_output_6_10_3, string2359___r4_output_6_10_32421, "BCHAR", 5 );
DEFINE_STRING( string2360___r4_output_6_10_3, string2360___r4_output_6_10_32422, "BUCS2", 5 );
DEFINE_STRING( string2358___r4_output_6_10_3, string2358___r4_output_6_10_32423, "BLONG", 5 );
DEFINE_STRING( string2357___r4_output_6_10_3, string2357___r4_output_6_10_32424, "...", 3 );
DEFINE_STRING( string2353___r4_output_6_10_3, string2353___r4_output_6_10_32425, "UCHAR", 5 );
DEFINE_STRING( string2348___r4_output_6_10_3, string2348___r4_output_6_10_32426, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string2341___r4_output_6_10_3, string2341___r4_output_6_10_32427, "BODY1009:Wrong number of arguments", 34 );
DEFINE_STRING( string2340___r4_output_6_10_3, string2340___r4_output_6_10_32428, "PROCEDURE", 9 );
DEFINE_STRING( string2337___r4_output_6_10_3, string2337___r4_output_6_10_32429, "OUTPUT-PORT", 11 );
DEFINE_STRING( string2336___r4_output_6_10_3, string2336___r4_output_6_10_32430, "PAIR", 4 );
DEFINE_STRING( string2333___r4_output_6_10_3, string2333___r4_output_6_10_32431, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/output.scm", 59 );
DEFINE_EXPORT_PROCEDURE( fprint_env_249___r4_output_6_10_3, _fprint1405___r4_output_6_10_32432, va_generic_entry, _fprint1405___r4_output_6_10_3, -2 );
DEFINE_STRING( string2332___r4_output_6_10_3, string2332___r4_output_6_10_32433, "LONG", 4 );
DEFINE_EXPORT_PROCEDURE( native_printer_env_215___r4_output_6_10_3, _native_printer_193___r4_output_6_10_32434, _native_printer_193___r4_output_6_10_3, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( c_debugging_print_env_230___r4_output_6_10_3, _c_debugging_print_109___r4_output_6_10_32435, _c_debugging_print_109___r4_output_6_10_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( print_env_243___r4_output_6_10_3, _print___r4_output_6_10_32436, va_generic_entry, _print___r4_output_6_10_3, -1 );
DEFINE_EXPORT_PROCEDURE( illegal_char_rep_env_244___r4_output_6_10_3, _illegal_char_rep1404_60___r4_output_6_10_32437, _illegal_char_rep1404_60___r4_output_6_10_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( set_printer__env_75___r4_output_6_10_3, _set_printer_1406_212___r4_output_6_10_32438, _set_printer_1406_212___r4_output_6_10_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( display__env_163___r4_output_6_10_3, _display__37___r4_output_6_10_32439, va_generic_entry, _display__37___r4_output_6_10_3, -1 );


/* module-initialization */obj_t module_initialization_70___r4_output_6_10_3(long checksum_1943, char * from_1944)
{
if(CBOOL(require_initialization_114___r4_output_6_10_3)){
require_initialization_114___r4_output_6_10_3 = BBOOL(((bool_t)0));
cnst_init_137___r4_output_6_10_3();
imported_modules_init_94___r4_output_6_10_3();
method_init_76___r4_output_6_10_3();
toplevel_init_63___r4_output_6_10_3();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_output_6_10_3()
{
symbol2329___r4_output_6_10_3 = string_to_symbol("TOPLEVEL-INIT");
symbol2330___r4_output_6_10_3 = string_to_symbol("SET-WRITE-LENGTH!");
symbol2331___r4_output_6_10_3 = string_to_symbol("_SET-WRITE-LENGTH!1402");
symbol2334___r4_output_6_10_3 = string_to_symbol("GET-WRITE-LENGTH");
symbol2335___r4_output_6_10_3 = string_to_symbol("NEWLINE");
symbol2338___r4_output_6_10_3 = string_to_symbol("DISPLAY");
symbol2339___r4_output_6_10_3 = string_to_symbol("BODY1009");
symbol2343___r4_output_6_10_3 = string_to_symbol("FUNCALL");
symbol2344___r4_output_6_10_3 = string_to_symbol("*current-printer*");
symbol2345___r4_output_6_10_3 = string_to_symbol("obj");
symbol2346___r4_output_6_10_3 = string_to_symbol("arg1042");
{
obj_t aux_1963;
{
obj_t aux_1964;
{
obj_t aux_1965;
{
obj_t aux_1966;
aux_1966 = MAKE_PAIR(symbol2346___r4_output_6_10_3, BNIL);
aux_1965 = MAKE_PAIR(symbol2345___r4_output_6_10_3, aux_1966);
}
aux_1964 = MAKE_PAIR(symbol2344___r4_output_6_10_3, aux_1965);
}
aux_1963 = MAKE_PAIR(symbol2344___r4_output_6_10_3, aux_1964);
}
list2342___r4_output_6_10_3 = MAKE_PAIR(symbol2343___r4_output_6_10_3, aux_1963);
}
symbol2347___r4_output_6_10_3 = string_to_symbol("_");
symbol2349___r4_output_6_10_3 = string_to_symbol("NATIVE-DISPLAY");
symbol2350___r4_output_6_10_3 = string_to_symbol("WRITE");
symbol2351___r4_output_6_10_3 = string_to_symbol("WRITE-CHAR");
symbol2352___r4_output_6_10_3 = string_to_symbol("_WRITE-CHAR1403");
symbol2354___r4_output_6_10_3 = string_to_symbol("ILLEGAL-CHAR-REP");
symbol2355___r4_output_6_10_3 = string_to_symbol("_ILLEGAL-CHAR-REP1404");
symbol2356___r4_output_6_10_3 = string_to_symbol("WRITE/DISPLAY");
symbol2367___r4_output_6_10_3 = string_to_symbol("WRITE/DISPLAY-STRUCTURE");
symbol2370___r4_output_6_10_3 = string_to_symbol("WRITE/DISPLAY-VECTOR");
symbol2375___r4_output_6_10_3 = string_to_symbol("WRITE/DISPLAY-TVECTOR");
symbol2379___r4_output_6_10_3 = string_to_symbol("tvector-ref");
symbol2380___r4_output_6_10_3 = string_to_symbol("tvec");
symbol2381___r4_output_6_10_3 = string_to_symbol("i");
{
obj_t aux_1986;
{
obj_t aux_1987;
{
obj_t aux_1988;
{
obj_t aux_1989;
aux_1989 = MAKE_PAIR(symbol2381___r4_output_6_10_3, BNIL);
aux_1988 = MAKE_PAIR(symbol2380___r4_output_6_10_3, aux_1989);
}
aux_1987 = MAKE_PAIR(symbol2379___r4_output_6_10_3, aux_1988);
}
aux_1986 = MAKE_PAIR(symbol2379___r4_output_6_10_3, aux_1987);
}
list2378___r4_output_6_10_3 = MAKE_PAIR(symbol2343___r4_output_6_10_3, aux_1986);
}
symbol2383___r4_output_6_10_3 = string_to_symbol("WRITE/DISPLAY-PAIR");
symbol2385___r4_output_6_10_3 = string_to_symbol("PRINT");
symbol2386___r4_output_6_10_3 = string_to_symbol("DISPLAY*");
symbol2387___r4_output_6_10_3 = string_to_symbol("WRITE*");
symbol2388___r4_output_6_10_3 = string_to_symbol("FPRINT");
symbol2389___r4_output_6_10_3 = string_to_symbol("_FPRINT1405");
symbol2390___r4_output_6_10_3 = string_to_symbol("SET-PRINTER!");
symbol2391___r4_output_6_10_3 = string_to_symbol("_SET-PRINTER!1406");
symbol2392___r4_output_6_10_3 = string_to_symbol("NATIVE-PRINTER");
symbol2393___r4_output_6_10_3 = string_to_symbol("C-DEBUGGING-PRINT");
symbol2394___r4_output_6_10_3 = string_to_symbol("METHOD-INIT");
return (symbol2395___r4_output_6_10_3 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___r4_output_6_10_3()
{
{
obj_t symbol1357_1028;
symbol1357_1028 = symbol2329___r4_output_6_10_3;
{
PUSH_TRACE(symbol1357_1028);
BUNSPEC;
{
obj_t aux1356_1029;
_max_length_write__149___r4_output_6_10_3 = BINT(((long)-1));
_displayed__5___r4_output_6_10_3 = BINT(((long)0));
_current_printer__39___r4_output_6_10_3 = BUNSPEC;
aux1356_1029 = (_current_printer__39___r4_output_6_10_3 = native_display_env_3___r4_output_6_10_3,
BUNSPEC);
POP_TRACE();
return aux1356_1029;
}
}
}
}


/* set-write-length! */obj_t set_write_length__244___r4_output_6_10_3(long length_1)
{
{
obj_t symbol1359_1030;
symbol1359_1030 = symbol2330___r4_output_6_10_3;
{
PUSH_TRACE(symbol1359_1030);
BUNSPEC;
{
obj_t aux1358_1031;
aux1358_1031 = (_max_length_write__149___r4_output_6_10_3 = BINT(length_1),
BUNSPEC);
POP_TRACE();
return aux1358_1031;
}
}
}
}


/* _set-write-length!1402 */obj_t _set_write_length_1402_158___r4_output_6_10_3(obj_t env_1077, obj_t length_1078)
{
{
long aux_2014;
{
obj_t aux_2015;
if(INTEGERP(length_1078)){
aux_2015 = length_1078;
}
 else {
bigloo_type_error_location_103___error(symbol2331___r4_output_6_10_3, string2332___r4_output_6_10_3, length_1078, string2333___r4_output_6_10_3, BINT(((long)5384)));
exit( -1 );}
aux_2014 = (long)CINT(aux_2015);
}
return set_write_length__244___r4_output_6_10_3(aux_2014);
}
}


/* get-write-length */long get_write_length_193___r4_output_6_10_3()
{
{
obj_t symbol1361_1032;
symbol1361_1032 = symbol2334___r4_output_6_10_3;
{
PUSH_TRACE(symbol1361_1032);
BUNSPEC;
{
long aux1360_1033;
{
bool_t test1021_440;
{
obj_t obj_813;
obj_813 = _max_length_write__149___r4_output_6_10_3;
test1021_440 = INTEGERP(obj_813);
}
if(test1021_440){
obj_t aux_2026;
{
obj_t aux1415_1143;
aux1415_1143 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux1415_1143)){
aux_2026 = aux1415_1143;
}
 else {
bigloo_type_error_location_103___error(symbol2334___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1415_1143, string2333___r4_output_6_10_3, BINT(((long)5709)));
exit( -1 );}
}
aux1360_1033 = (long)CINT(aux_2026);
}
 else {
aux1360_1033 = ((long)-1);
}
}
POP_TRACE();
return aux1360_1033;
}
}
}
}


/* _get-write-length */obj_t _get_write_length_196___r4_output_6_10_3(obj_t env_1079)
{
{
long aux_2034;
aux_2034 = get_write_length_193___r4_output_6_10_3();
return BINT(aux_2034);
}
}


/* newline */obj_t newline___r4_output_6_10_3(obj_t port_2)
{
{
obj_t symbol1363_1034;
symbol1363_1034 = symbol2335___r4_output_6_10_3;
{
PUSH_TRACE(symbol1363_1034);
BUNSPEC;
{
obj_t aux1362_1035;
{
obj_t arg1022_441;
{
bool_t test1023_442;
{
bool_t test1024_443;
test1024_443 = PAIRP(port_2);
if(test1024_443){
bool_t test1025_444;
{
obj_t arg1026_445;
{
obj_t pair_815;
if(test1024_443){
pair_815 = port_2;
}
 else {
bigloo_type_error_location_103___error(symbol2335___r4_output_6_10_3, string2336___r4_output_6_10_3, port_2, string2333___r4_output_6_10_3, BINT(((long)6116)));
exit( -1 );}
arg1026_445 = CAR(pair_815);
}
test1025_444 = OUTPUT_PORTP(arg1026_445);
}
if(test1025_444){
test1023_442 = ((bool_t)0);
}
 else {
test1023_442 = ((bool_t)1);
}
}
 else {
test1023_442 = ((bool_t)1);
}
}
if(test1023_442){
arg1022_441 = current_output_port;
}
 else {
obj_t pair_817;
if(PAIRP(port_2)){
pair_817 = port_2;
}
 else {
bigloo_type_error_location_103___error(symbol2335___r4_output_6_10_3, string2336___r4_output_6_10_3, port_2, string2333___r4_output_6_10_3, BINT(((long)6166)));
exit( -1 );}
arg1022_441 = CAR(pair_817);
}
}
{
unsigned char aux_2054;
{
obj_t aux_2055;
if(OUTPUT_PORTP(arg1022_441)){
aux_2055 = arg1022_441;
}
 else {
bigloo_type_error_location_103___error(symbol2335___r4_output_6_10_3, string2337___r4_output_6_10_3, arg1022_441, string2333___r4_output_6_10_3, BINT(((long)6038)));
exit( -1 );}
aux_2054 = WRITE_CHAR(((unsigned char)'\n'), aux_2055);
}
aux1362_1035 = BCHAR(aux_2054);
}
}
POP_TRACE();
return aux1362_1035;
}
}
}
}


/* _newline */obj_t _newline___r4_output_6_10_3(obj_t env_1080, obj_t port_1081)
{
return newline___r4_output_6_10_3(port_1081);
}


/* display */obj_t display___r4_output_6_10_3(obj_t obj_3, obj_t port_4)
{
{
obj_t symbol1365_1036;
symbol1365_1036 = symbol2338___r4_output_6_10_3;
{
PUSH_TRACE(symbol1365_1036);
BUNSPEC;
{
obj_t aux1364_1037;
_displayed__5___r4_output_6_10_3 = BINT(((long)0));
{
bool_t test1027_446;
{
bool_t test1047_488;
{
obj_t obj1_818;
obj1_818 = _current_printer__39___r4_output_6_10_3;
test1047_488 = (obj1_818==native_display_env_3___r4_output_6_10_3);
}
if(test1047_488){
test1027_446 = ((bool_t)1);
}
 else {
bool_t test1048_489;
{
obj_t obj_819;
obj_819 = _current_printer__39___r4_output_6_10_3;
test1048_489 = PROCEDUREP(obj_819);
}
if(test1048_489){
test1027_446 = ((bool_t)0);
}
 else {
test1027_446 = ((bool_t)1);
}
}
}
if(test1027_446){
obj_t arg1028_447;
{
bool_t test1029_448;
{
bool_t test1030_449;
test1030_449 = PAIRP(port_4);
if(test1030_449){
bool_t test1031_450;
{
obj_t arg1032_451;
{
obj_t pair_821;
if(test1030_449){
pair_821 = port_4;
}
 else {
bigloo_type_error_location_103___error(symbol2338___r4_output_6_10_3, string2336___r4_output_6_10_3, port_4, string2333___r4_output_6_10_3, BINT(((long)6637)));
exit( -1 );}
arg1032_451 = CAR(pair_821);
}
test1031_450 = OUTPUT_PORTP(arg1032_451);
}
if(test1031_450){
test1029_448 = ((bool_t)0);
}
 else {
test1029_448 = ((bool_t)1);
}
}
 else {
test1029_448 = ((bool_t)1);
}
}
if(test1029_448){
arg1028_447 = current_output_port;
}
 else {
obj_t pair_823;
if(PAIRP(port_4)){
pair_823 = port_4;
}
 else {
bigloo_type_error_location_103___error(symbol2338___r4_output_6_10_3, string2336___r4_output_6_10_3, port_4, string2333___r4_output_6_10_3, BINT(((long)6683)));
exit( -1 );}
arg1028_447 = CAR(pair_823);
}
}
aux1364_1037 = write_display_159___r4_output_6_10_3(obj_3, arg1028_447, ((bool_t)1));
}
 else {
obj_t armed1010_452;
armed1010_452 = MAKE_CELL(BUNSPEC);
{
obj_t body1009_1083;
obj_t rhandler1007_1085;
body1009_1083 = make_fx_procedure(body1009___r4_output_6_10_3, ((long)0), ((long)2));
rhandler1007_1085 = make_fx_procedure(rhandler1007___r4_output_6_10_3, ((long)4), ((long)1));
PROCEDURE_SET(body1009_1083, ((long)0), port_4);
PROCEDURE_SET(body1009_1083, ((long)1), obj_3);
PROCEDURE_SET(rhandler1007_1085, ((long)0), armed1010_452);
CELL_SET(armed1010_452, BTRUE);
aux1364_1037 = handling_function1033___r4_output_6_10_3(body1009_1083, rhandler1007_1085, armed1010_452);
}
}
}
POP_TRACE();
return aux1364_1037;
}
}
}
}


/* handling_function1033 */obj_t handling_function1033___r4_output_6_10_3(obj_t body1009_1136, obj_t rhandler1007_1135, obj_t armed1010_1134)
{
jmp_buf jmpbuf;
obj_t an_exit1011_457;
if( SET_EXIT(an_exit1011_457) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1011_457 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1011_457, ((bool_t)1));
{
obj_t an_exitd1012_458;
an_exitd1012_458 = exitd_top;
{
obj_t escape_1084;
escape_1084 = make_fx_procedure(escape___r4_output_6_10_3, ((long)1), ((long)1));
PROCEDURE_SET(escape_1084, ((long)0), an_exitd1012_458);
{
obj_t res1014_461;
{
obj_t arg1035_1082;
obj_t arg1034_1086;
arg1035_1082 = make_fx_procedure(arg1035___r4_output_6_10_3, ((long)0), ((long)1));
arg1034_1086 = make_fx_procedure(arg1034___r4_output_6_10_3, ((long)0), ((long)4));
PROCEDURE_SET(arg1035_1082, ((long)0), armed1010_1134);
PROCEDURE_SET(arg1034_1086, ((long)0), an_exitd1012_458);
PROCEDURE_SET(arg1034_1086, ((long)1), armed1010_1134);
PROCEDURE_SET(arg1034_1086, ((long)2), rhandler1007_1135);
PROCEDURE_SET(arg1034_1086, ((long)3), escape_1084);
res1014_461 = dynamic_wind_31___r4_control_features_6_9(arg1034_1086, body1009_1136, arg1035_1082);
}
POP_EXIT();
return res1014_461;
}
}
}
}
}
}


/* _display */obj_t _display___r4_output_6_10_3(obj_t env_1087, obj_t obj_1088, obj_t port_1089)
{
return display___r4_output_6_10_3(obj_1088, port_1089);
}


/* arg1035 */obj_t arg1035___r4_output_6_10_3(obj_t env_1090)
{
{
obj_t armed1010_1091;
armed1010_1091 = PROCEDURE_REF(env_1090, ((long)0));
{
{
bool_t test_2112;
{
obj_t aux_2113;
aux_2113 = CELL_REF(armed1010_1091);
test_2112 = CBOOL(aux_2113);
}
if(test_2112){
CELL_SET(armed1010_1091, BFALSE);
return remove_error_handler__102___error();
}
 else {
return BUNSPEC;
}
}
}
}
}


/* body1009 */obj_t body1009___r4_output_6_10_3(obj_t env_1093)
{
{
obj_t port_1094;
obj_t obj_1095;
port_1094 = PROCEDURE_REF(env_1093, ((long)0));
obj_1095 = PROCEDURE_REF(env_1093, ((long)1));
{
{
obj_t arg1042_480;
{
bool_t test1043_481;
{
bool_t test1044_482;
test1044_482 = PAIRP(port_1094);
if(test1044_482){
bool_t test1045_483;
{
obj_t arg1046_484;
{
obj_t pair_841;
if(test1044_482){
pair_841 = port_1094;
}
 else {
bigloo_type_error_location_103___error(symbol2339___r4_output_6_10_3, string2336___r4_output_6_10_3, port_1094, string2333___r4_output_6_10_3, BINT(((long)6809)));
exit( -1 );}
arg1046_484 = CAR(pair_841);
}
test1045_483 = OUTPUT_PORTP(arg1046_484);
}
if(test1045_483){
test1043_481 = ((bool_t)0);
}
 else {
test1043_481 = ((bool_t)1);
}
}
 else {
test1043_481 = ((bool_t)1);
}
}
if(test1043_481){
arg1042_480 = current_output_port;
}
 else {
obj_t pair_843;
if(PAIRP(port_1094)){
pair_843 = port_1094;
}
 else {
bigloo_type_error_location_103___error(symbol2339___r4_output_6_10_3, string2336___r4_output_6_10_3, port_1094, string2333___r4_output_6_10_3, BINT(((long)6859)));
exit( -1 );}
arg1042_480 = CAR(pair_843);
}
}
{
obj_t fun_1197;
{
obj_t aux1477_1191;
aux1477_1191 = _current_printer__39___r4_output_6_10_3;
if(PROCEDUREP(aux1477_1191)){
fun_1197 = aux1477_1191;
}
 else {
bigloo_type_error_location_103___error(symbol2339___r4_output_6_10_3, string2340___r4_output_6_10_3, aux1477_1191, string2333___r4_output_6_10_3, BINT(((long)6718)));
exit( -1 );}
}
{
bool_t test1490_1204;
test1490_1204 = PROCEDURE_CORRECT_ARITYP(fun_1197, ((long)2));
if(test1490_1204){
return PROCEDURE_ENTRY(fun_1197)(_current_printer__39___r4_output_6_10_3, obj_1095, arg1042_480, BEOA);
}
 else {
error_location_112___error(string2341___r4_output_6_10_3, list2342___r4_output_6_10_3, fun_1197, string2333___r4_output_6_10_3, BINT(((long)6718)));
FAILURE(symbol2347___r4_output_6_10_3,symbol2347___r4_output_6_10_3,symbol2347___r4_output_6_10_3);}
}
}
}
}
}
}


/* arg1034 */obj_t arg1034___r4_output_6_10_3(obj_t env_1096)
{
{
obj_t rhandler1007_1099;
obj_t escape_1100;
rhandler1007_1099 = PROCEDURE_REF(env_1096, ((long)2));
escape_1100 = PROCEDURE_REF(env_1096, ((long)3));
{
return add_error_handler__155___error(rhandler1007_1099, escape_1100);
}
}
}


/* escape */obj_t escape___r4_output_6_10_3(obj_t env_1101, obj_t val1013_1103)
{
{
obj_t an_exitd1012_1102;
an_exitd1012_1102 = PROCEDURE_REF(env_1101, ((long)0));
{
obj_t val1013_459;
val1013_459 = val1013_1103;
return unwind_until__178___bexit(an_exitd1012_1102, val1013_459);
}
}
}


/* rhandler1007 */obj_t rhandler1007___r4_output_6_10_3(obj_t env_1104, obj_t esc_1106, obj_t obj_1107, obj_t proc_1108, obj_t msg_1109)
{
{
obj_t armed1010_1105;
armed1010_1105 = PROCEDURE_REF(env_1104, ((long)0));
{
obj_t esc_474;
obj_t obj_475;
obj_t proc_476;
obj_t msg_477;
esc_474 = esc_1106;
obj_475 = obj_1107;
proc_476 = proc_1108;
msg_477 = msg_1109;
CELL_SET(armed1010_1105, BFALSE);
remove_error_handler__102___error();
_current_printer__39___r4_output_6_10_3 = native_display_env_3___r4_output_6_10_3;
return debug_error_location_199___error(obj_475, proc_476, msg_477, string2348___r4_output_6_10_3, BINT(((long)7610)));
}
}
}


/* native-display */obj_t native_display_62___r4_output_6_10_3(obj_t obj_5, obj_t port_6)
{
{
obj_t symbol1367_1038;
symbol1367_1038 = symbol2349___r4_output_6_10_3;
{
PUSH_TRACE(symbol1367_1038);
BUNSPEC;
{
obj_t aux1366_1039;
_displayed__5___r4_output_6_10_3 = BINT(((long)0));
{
obj_t arg1049_490;
{
bool_t test1050_491;
{
bool_t test1051_492;
test1051_492 = PAIRP(port_6);
if(test1051_492){
bool_t test1052_493;
{
obj_t arg1053_494;
{
obj_t pair_845;
if(test1051_492){
pair_845 = port_6;
}
 else {
bigloo_type_error_location_103___error(symbol2349___r4_output_6_10_3, string2336___r4_output_6_10_3, port_6, string2333___r4_output_6_10_3, BINT(((long)7332)));
exit( -1 );}
arg1053_494 = CAR(pair_845);
}
test1052_493 = OUTPUT_PORTP(arg1053_494);
}
if(test1052_493){
test1050_491 = ((bool_t)0);
}
 else {
test1050_491 = ((bool_t)1);
}
}
 else {
test1050_491 = ((bool_t)1);
}
}
if(test1050_491){
arg1049_490 = current_output_port;
}
 else {
obj_t pair_847;
if(PAIRP(port_6)){
pair_847 = port_6;
}
 else {
bigloo_type_error_location_103___error(symbol2349___r4_output_6_10_3, string2336___r4_output_6_10_3, port_6, string2333___r4_output_6_10_3, BINT(((long)7384)));
exit( -1 );}
arg1049_490 = CAR(pair_847);
}
}
aux1366_1039 = write_display_159___r4_output_6_10_3(obj_5, arg1049_490, ((bool_t)1));
}
POP_TRACE();
return aux1366_1039;
}
}
}
}


/* _native-display */obj_t _native_display_199___r4_output_6_10_3(obj_t env_1074, obj_t obj_1075, obj_t port_1076)
{
return native_display_62___r4_output_6_10_3(obj_1075, port_1076);
}


/* write */obj_t write___r4_output_6_10_3(obj_t obj_7, obj_t port_8)
{
{
obj_t symbol1369_1040;
symbol1369_1040 = symbol2350___r4_output_6_10_3;
{
PUSH_TRACE(symbol1369_1040);
BUNSPEC;
{
obj_t aux1368_1041;
_displayed__5___r4_output_6_10_3 = BINT(((long)0));
{
obj_t arg1054_495;
{
bool_t test1055_496;
{
bool_t test1056_497;
test1056_497 = PAIRP(port_8);
if(test1056_497){
bool_t test1057_498;
{
obj_t arg1058_499;
{
obj_t pair_849;
if(test1056_497){
pair_849 = port_8;
}
 else {
bigloo_type_error_location_103___error(symbol2350___r4_output_6_10_3, string2336___r4_output_6_10_3, port_8, string2333___r4_output_6_10_3, BINT(((long)7756)));
exit( -1 );}
arg1058_499 = CAR(pair_849);
}
test1057_498 = OUTPUT_PORTP(arg1058_499);
}
if(test1057_498){
test1055_496 = ((bool_t)0);
}
 else {
test1055_496 = ((bool_t)1);
}
}
 else {
test1055_496 = ((bool_t)1);
}
}
if(test1055_496){
arg1054_495 = current_output_port;
}
 else {
obj_t pair_851;
if(PAIRP(port_8)){
pair_851 = port_8;
}
 else {
bigloo_type_error_location_103___error(symbol2350___r4_output_6_10_3, string2336___r4_output_6_10_3, port_8, string2333___r4_output_6_10_3, BINT(((long)7808)));
exit( -1 );}
arg1054_495 = CAR(pair_851);
}
}
aux1368_1041 = write_display_159___r4_output_6_10_3(obj_7, arg1054_495, ((bool_t)0));
}
POP_TRACE();
return aux1368_1041;
}
}
}
}


/* _write */obj_t _write___r4_output_6_10_3(obj_t env_1112, obj_t obj_1113, obj_t port_1114)
{
return write___r4_output_6_10_3(obj_1113, port_1114);
}


/* write-char */obj_t write_char_165___r4_output_6_10_3(unsigned char char_9, obj_t port_10)
{
{
obj_t symbol1371_1042;
symbol1371_1042 = symbol2351___r4_output_6_10_3;
{
PUSH_TRACE(symbol1371_1042);
BUNSPEC;
{
obj_t aux1370_1043;
{
obj_t arg1059_500;
{
bool_t test1060_501;
{
bool_t test1061_502;
test1061_502 = PAIRP(port_10);
if(test1061_502){
bool_t test1062_503;
{
obj_t arg1063_504;
{
obj_t pair_853;
if(test1061_502){
pair_853 = port_10;
}
 else {
bigloo_type_error_location_103___error(symbol2351___r4_output_6_10_3, string2336___r4_output_6_10_3, port_10, string2333___r4_output_6_10_3, BINT(((long)8160)));
exit( -1 );}
arg1063_504 = CAR(pair_853);
}
test1062_503 = OUTPUT_PORTP(arg1063_504);
}
if(test1062_503){
test1060_501 = ((bool_t)0);
}
 else {
test1060_501 = ((bool_t)1);
}
}
 else {
test1060_501 = ((bool_t)1);
}
}
if(test1060_501){
arg1059_500 = current_output_port;
}
 else {
obj_t pair_855;
if(PAIRP(port_10)){
pair_855 = port_10;
}
 else {
bigloo_type_error_location_103___error(symbol2351___r4_output_6_10_3, string2336___r4_output_6_10_3, port_10, string2333___r4_output_6_10_3, BINT(((long)8210)));
exit( -1 );}
arg1059_500 = CAR(pair_855);
}
}
{
unsigned char aux_2214;
{
obj_t aux_2215;
if(OUTPUT_PORTP(arg1059_500)){
aux_2215 = arg1059_500;
}
 else {
bigloo_type_error_location_103___error(symbol2351___r4_output_6_10_3, string2337___r4_output_6_10_3, arg1059_500, string2333___r4_output_6_10_3, BINT(((long)8087)));
exit( -1 );}
aux_2214 = WRITE_CHAR(char_9, aux_2215);
}
aux1370_1043 = BCHAR(aux_2214);
}
}
POP_TRACE();
return aux1370_1043;
}
}
}
}


/* _write-char1403 */obj_t _write_char1403_219___r4_output_6_10_3(obj_t env_1115, obj_t char_1116, obj_t port_1117)
{
{
unsigned char aux_2224;
{
obj_t aux_2225;
if(CHARP(char_1116)){
aux_2225 = char_1116;
}
 else {
bigloo_type_error_location_103___error(symbol2352___r4_output_6_10_3, string2353___r4_output_6_10_3, char_1116, string2333___r4_output_6_10_3, BINT(((long)8051)));
exit( -1 );}
aux_2224 = (unsigned char)CCHAR(aux_2225);
}
return write_char_165___r4_output_6_10_3(aux_2224, port_1117);
}
}


/* illegal-char-rep */obj_t illegal_char_rep_197___r4_output_6_10_3(unsigned char char_11)
{
{
obj_t symbol1373_1044;
symbol1373_1044 = symbol2354___r4_output_6_10_3;
{
PUSH_TRACE(symbol1373_1044);
BUNSPEC;
{
obj_t aux1372_1045;
aux1372_1045 = ill_char_rep(char_11);
POP_TRACE();
return aux1372_1045;
}
}
}
}


/* _illegal-char-rep1404 */obj_t _illegal_char_rep1404_60___r4_output_6_10_3(obj_t env_1118, obj_t char_1119)
{
{
unsigned char aux_2236;
{
obj_t aux_2237;
if(CHARP(char_1119)){
aux_2237 = char_1119;
}
 else {
bigloo_type_error_location_103___error(symbol2355___r4_output_6_10_3, string2353___r4_output_6_10_3, char_1119, string2333___r4_output_6_10_3, BINT(((long)8446)));
exit( -1 );}
aux_2236 = (unsigned char)CCHAR(aux_2237);
}
return illegal_char_rep_197___r4_output_6_10_3(aux_2236);
}
}


/* write/display */obj_t write_display_159___r4_output_6_10_3(obj_t obj_12, obj_t port_13, bool_t flag_14)
{
{
obj_t symbol1375_1046;
symbol1375_1046 = symbol2356___r4_output_6_10_3;
{
PUSH_TRACE(symbol1375_1046);
BUNSPEC;
{
obj_t aux1374_1047;
{
long z2_857;
{
obj_t aux_2246;
{
obj_t aux1556_1259;
aux1556_1259 = _displayed__5___r4_output_6_10_3;
if(INTEGERP(aux1556_1259)){
aux_2246 = aux1556_1259;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1556_1259, string2333___r4_output_6_10_3, BINT(((long)9302)));
exit( -1 );}
}
z2_857 = (long)CINT(aux_2246);
}
{
long aux_2253;
aux_2253 = (((long)1)+z2_857);
_displayed__5___r4_output_6_10_3 = BINT(aux_2253);
}
}
{
bool_t test1064_505;
{
bool_t test1080_521;
{
obj_t obj_858;
obj_858 = _max_length_write__149___r4_output_6_10_3;
test1080_521 = INTEGERP(obj_858);
}
if(test1080_521){
bool_t test1081_522;
{
long n1_859;
{
obj_t aux_2258;
{
obj_t aux1562_1265;
aux1562_1265 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux1562_1265)){
aux_2258 = aux1562_1265;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1562_1265, string2333___r4_output_6_10_3, BINT(((long)9379)));
exit( -1 );}
}
n1_859 = (long)CINT(aux_2258);
}
test1081_522 = (n1_859>((long)0));
}
if(test1081_522){
long n1_861;
long n2_862;
{
obj_t aux_2267;
{
obj_t aux1569_1271;
aux1569_1271 = _displayed__5___r4_output_6_10_3;
if(INTEGERP(aux1569_1271)){
aux_2267 = aux1569_1271;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1569_1271, string2333___r4_output_6_10_3, BINT(((long)9411)));
exit( -1 );}
}
n1_861 = (long)CINT(aux_2267);
}
{
obj_t aux_2274;
{
obj_t aux1579_1277;
aux1579_1277 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux1579_1277)){
aux_2274 = aux1579_1277;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1579_1277, string2333___r4_output_6_10_3, BINT(((long)9416)));
exit( -1 );}
}
n2_862 = (long)CINT(aux_2274);
}
test1064_505 = (n1_861>=n2_862);
}
 else {
test1064_505 = ((bool_t)0);
}
}
 else {
test1064_505 = ((bool_t)0);
}
}
if(test1064_505){
{
obj_t aux_2283;
if(OUTPUT_PORTP(port_13)){
aux_2283 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)9473)));
exit( -1 );}
display_string(string2357___r4_output_6_10_3, aux_2283);
}
}
 else {
bool_t test1065_506;
test1065_506 = INTEGERP(obj_12);
if(test1065_506){
{
obj_t aux_2297;
obj_t aux_2292;
if(OUTPUT_PORTP(port_13)){
aux_2297 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)9530)));
exit( -1 );}
if(test1065_506){
aux_2292 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2358___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)9515)));
exit( -1 );}
display_fixnum(aux_2292, aux_2297);
}
}
 else {
bool_t test1066_507;
test1066_507 = CHARP(obj_12);
if(test1066_507){
if(flag_14){
obj_t aux_2312;
obj_t aux_2307;
if(OUTPUT_PORTP(port_13)){
aux_2312 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)9595)));
exit( -1 );}
if(test1066_507){
aux_2307 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2359___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)9582)));
exit( -1 );}
display_char(aux_2307, aux_2312);
}
 else {
obj_t aux_2324;
obj_t aux_2319;
if(OUTPUT_PORTP(port_13)){
aux_2324 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)9623)));
exit( -1 );}
if(test1066_507){
aux_2319 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2359___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)9610)));
exit( -1 );}
write_char(aux_2319, aux_2324);
}
}
 else {
bool_t test1067_508;
test1067_508 = UCS2P(obj_12);
if(test1067_508){
if(flag_14){
obj_t aux_2339;
obj_t aux_2334;
if(OUTPUT_PORTP(port_13)){
aux_2339 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)9689)));
exit( -1 );}
if(test1067_508){
aux_2334 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2360___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)9676)));
exit( -1 );}
display_ucs2(aux_2334, aux_2339);
}
 else {
obj_t aux_2351;
obj_t aux_2346;
if(OUTPUT_PORTP(port_13)){
aux_2351 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)9717)));
exit( -1 );}
if(test1067_508){
aux_2346 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2360___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)9704)));
exit( -1 );}
write_ucs2(aux_2346, aux_2351);
}
}
 else {
bool_t test1068_509;
test1068_509 = STRINGP(obj_12);
if(test1068_509){
if(flag_14){
obj_t aux_2366;
obj_t aux_2361;
if(OUTPUT_PORTP(port_13)){
aux_2366 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)9787)));
exit( -1 );}
if(test1068_509){
aux_2361 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2361___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)9772)));
exit( -1 );}
display_string(aux_2361, aux_2366);
}
 else {
obj_t arg1069_510;
{
obj_t string_867;
if(test1068_509){
string_867 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2361___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)9816)));
exit( -1 );}
arg1069_510 = string_for_read(string_867);
}
{
obj_t aux_2378;
if(OUTPUT_PORTP(port_13)){
aux_2378 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)9801)));
exit( -1 );}
write_string(arg1069_510, aux_2378);
}
}
}
 else {
if(VECTORP(obj_12)){
write_display_vector_76___r4_output_6_10_3(obj_12, port_13, flag_14);
}
 else {
if(PAIRP(obj_12)){
write_display_pair_103___r4_output_6_10_3(obj_12, port_13, flag_14);
}
 else {
bool_t test1072_513;
test1072_513 = REALP(obj_12);
if(test1072_513){
{
obj_t aux_2398;
obj_t aux_2393;
if(OUTPUT_PORTP(port_13)){
aux_2398 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)10017)));
exit( -1 );}
if(test1072_513){
aux_2393 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2362___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)10002)));
exit( -1 );}
display_flonum(aux_2393, aux_2398);
}
}
 else {
if(CELLP(obj_12)){
{
obj_t aux_2407;
if(OUTPUT_PORTP(port_13)){
aux_2407 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)10804)));
exit( -1 );}
display_string(string2363___r4_output_6_10_3, aux_2407);
}
{
obj_t arg1082_874;
arg1082_874 = CELL_REF(obj_12);
write_display_159___r4_output_6_10_3(arg1082_874, port_13, flag_14);
}
{
obj_t aux_2416;
if(OUTPUT_PORTP(port_13)){
aux_2416 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)10883)));
exit( -1 );}
display_string(string2364___r4_output_6_10_3, aux_2416);
}
}
 else {
if(STRUCTP(obj_12)){
write_display_structure_107___r4_output_6_10_3(obj_12, port_13, flag_14);
}
 else {
if(TVECTORP(obj_12)){
write_display_tvector_50___r4_output_6_10_3(obj_12, port_13, flag_14);
}
 else {
bool_t test1076_517;
test1076_517 = (POINTERP( obj_12 ) && (TYPE( obj_12 ) >= OBJECT_TYPE));
if(test1076_517){
if(flag_14){
obj_t list1123_881;
list1123_881 = MAKE_PAIR(port_13, BNIL);
{
object_t aux_2433;
{
bool_t test1722_1398;
{
obj_t obj_1941;
obj_1941 = obj_12;
test1722_1398 = (POINTERP( obj_1941 ) && (TYPE( obj_1941 ) >= OBJECT_TYPE));
}
if(test1722_1398){
aux_2433 = (object_t)(obj_12);
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2365___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)14278)));
exit( -1 );}
}
object_display_243___object(aux_2433, list1123_881);
}
}
 else {
obj_t list1125_883;
list1125_883 = MAKE_PAIR(port_13, BNIL);
{
object_t aux_2442;
{
bool_t test1728_1404;
{
obj_t obj_1942;
obj_1942 = obj_12;
test1728_1404 = (POINTERP( obj_1942 ) && (TYPE( obj_1942 ) >= OBJECT_TYPE));
}
if(test1728_1404){
aux_2442 = (object_t)(obj_12);
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2365___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)14311)));
exit( -1 );}
}
object_write_132___object(aux_2442, list1125_883);
}
}
}
 else {
bool_t test1077_518;
test1077_518 = UCS2_STRINGP(obj_12);
if(test1077_518){
if(flag_14){
obj_t aux_2458;
obj_t aux_2453;
if(OUTPUT_PORTP(port_13)){
aux_2458 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)10359)));
exit( -1 );}
if(test1077_518){
aux_2453 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2366___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)10340)));
exit( -1 );}
display_ucs2string(aux_2453, aux_2458);
}
 else {
obj_t arg1078_519;
{
obj_t arg1079_520;
{
obj_t ucs2_886;
if(test1077_518){
ucs2_886 = obj_12;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2366___r4_output_6_10_3, obj_12, string2333___r4_output_6_10_3, BINT(((long)10410)));
exit( -1 );}
arg1079_520 = ucs2_string_to_utf8_string(ucs2_886);
}
arg1078_519 = string_for_read(arg1079_520);
}
{
obj_t aux_2471;
if(OUTPUT_PORTP(port_13)){
aux_2471 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)10374)));
exit( -1 );}
write_utf8string(arg1078_519, aux_2471);
}
}
}
 else {
{
obj_t aux_2478;
if(OUTPUT_PORTP(port_13)){
aux_2478 = port_13;
}
 else {
bigloo_type_error_location_103___error(symbol2356___r4_output_6_10_3, string2337___r4_output_6_10_3, port_13, string2333___r4_output_6_10_3, BINT(((long)10490)));
exit( -1 );}
write_object(obj_12, aux_2478);
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
aux1374_1047 = BUNSPEC;
POP_TRACE();
return aux1374_1047;
}
}
}
}


/* write/display-structure */obj_t write_display_structure_107___r4_output_6_10_3(obj_t obj_18, obj_t port_19, bool_t flag_20)
{
{
obj_t symbol1377_1048;
symbol1377_1048 = symbol2367___r4_output_6_10_3;
{
PUSH_TRACE(symbol1377_1048);
BUNSPEC;
{
obj_t aux1376_1049;
{
obj_t aux_2487;
if(OUTPUT_PORTP(port_19)){
aux_2487 = port_19;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2337___r4_output_6_10_3, port_19, string2333___r4_output_6_10_3, BINT(((long)11182)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'#'), aux_2487);
}
{
obj_t aux_2494;
if(OUTPUT_PORTP(port_19)){
aux_2494 = port_19;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2337___r4_output_6_10_3, port_19, string2333___r4_output_6_10_3, BINT(((long)11209)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'{'), aux_2494);
}
{
obj_t arg1083_524;
{
obj_t s_889;
if(STRUCTP(obj_18)){
s_889 = obj_18;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2368___r4_output_6_10_3, obj_18, string2333___r4_output_6_10_3, BINT(((long)11237)));
exit( -1 );}
arg1083_524 = STRUCT_KEY(s_889);
}
{
obj_t aux_2507;
if(OUTPUT_PORTP(port_19)){
aux_2507 = port_19;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2337___r4_output_6_10_3, port_19, string2333___r4_output_6_10_3, BINT(((long)11222)));
exit( -1 );}
write_object(arg1083_524, aux_2507);
}
}
{
bool_t test1084_525;
{
long arg1095_539;
{
obj_t s_890;
if(STRUCTP(obj_18)){
s_890 = obj_18;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2368___r4_output_6_10_3, obj_18, string2333___r4_output_6_10_3, BINT(((long)11274)));
exit( -1 );}
arg1095_539 = STRUCT_LENGTH(s_890);
}
test1084_525 = (((long)0)==arg1095_539);
}
if(test1084_525){
unsigned char aux_2522;
{
obj_t aux_2523;
if(OUTPUT_PORTP(port_19)){
aux_2523 = port_19;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2337___r4_output_6_10_3, port_19, string2333___r4_output_6_10_3, BINT(((long)11315)));
exit( -1 );}
aux_2522 = WRITE_CHAR(((unsigned char)'}'), aux_2523);
}
aux1376_1049 = BCHAR(aux_2522);
}
 else {
long len_526;
{
long arg1092_536;
{
obj_t s_893;
if(STRUCTP(obj_18)){
s_893 = obj_18;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2368___r4_output_6_10_3, obj_18, string2333___r4_output_6_10_3, BINT(((long)11349)));
exit( -1 );}
arg1092_536 = STRUCT_LENGTH(s_893);
}
len_526 = (arg1092_536-((long)1));
}
{
obj_t aux_2538;
if(OUTPUT_PORTP(port_19)){
aux_2538 = port_19;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2337___r4_output_6_10_3, port_19, string2333___r4_output_6_10_3, BINT(((long)11390)));
exit( -1 );}
WRITE_CHAR(((unsigned char)' '), aux_2538);
}
{
long i_527;
i_527 = ((long)0);
loop_528:
{
bool_t test1085_529;
{
bool_t test1090_534;
{
obj_t obj_896;
obj_896 = _max_length_write__149___r4_output_6_10_3;
test1090_534 = INTEGERP(obj_896);
}
if(test1090_534){
bool_t test1091_535;
{
long n1_897;
{
obj_t aux_2547;
{
obj_t aux1831_1487;
aux1831_1487 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux1831_1487)){
aux_2547 = aux1831_1487;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1831_1487, string2333___r4_output_6_10_3, BINT(((long)11483)));
exit( -1 );}
}
n1_897 = (long)CINT(aux_2547);
}
test1091_535 = (n1_897>((long)0));
}
if(test1091_535){
long n1_899;
long n2_900;
{
obj_t aux_2556;
{
obj_t aux1837_1493;
aux1837_1493 = _displayed__5___r4_output_6_10_3;
if(INTEGERP(aux1837_1493)){
aux_2556 = aux1837_1493;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1837_1493, string2333___r4_output_6_10_3, BINT(((long)11518)));
exit( -1 );}
}
n1_899 = (long)CINT(aux_2556);
}
{
obj_t aux_2563;
{
obj_t aux1848_1499;
aux1848_1499 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux1848_1499)){
aux_2563 = aux1848_1499;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1848_1499, string2333___r4_output_6_10_3, BINT(((long)11522)));
exit( -1 );}
}
n2_900 = (long)CINT(aux_2563);
}
test1085_529 = (n1_899>n2_900);
}
 else {
test1085_529 = ((bool_t)0);
}
}
 else {
test1085_529 = ((bool_t)0);
}
}
if(test1085_529){
{
obj_t aux_2572;
if(OUTPUT_PORTP(port_19)){
aux_2572 = port_19;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2337___r4_output_6_10_3, port_19, string2333___r4_output_6_10_3, BINT(((long)11572)));
exit( -1 );}
aux1376_1049 = write_object(string2369___r4_output_6_10_3, aux_2572);
}
}
 else {
if((i_527==len_526)){
{
obj_t arg1087_531;
{
obj_t s_903;
if(STRUCTP(obj_18)){
s_903 = obj_18;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2368___r4_output_6_10_3, obj_18, string2333___r4_output_6_10_3, BINT(((long)11621)));
exit( -1 );}
arg1087_531 = STRUCT_REF(s_903, i_527);
}
write_display_159___r4_output_6_10_3(arg1087_531, port_19, flag_20);
}
{
unsigned char aux_2588;
{
obj_t aux_2589;
if(OUTPUT_PORTP(port_19)){
aux_2589 = port_19;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2337___r4_output_6_10_3, port_19, string2333___r4_output_6_10_3, BINT(((long)11667)));
exit( -1 );}
aux_2588 = WRITE_CHAR(((unsigned char)'}'), aux_2589);
}
aux1376_1049 = BCHAR(aux_2588);
}
}
 else {
{
obj_t arg1088_532;
{
obj_t s_905;
if(STRUCTP(obj_18)){
s_905 = obj_18;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2368___r4_output_6_10_3, obj_18, string2333___r4_output_6_10_3, BINT(((long)11705)));
exit( -1 );}
arg1088_532 = STRUCT_REF(s_905, i_527);
}
write_display_159___r4_output_6_10_3(arg1088_532, port_19, flag_20);
}
{
obj_t aux_2604;
if(OUTPUT_PORTP(port_19)){
aux_2604 = port_19;
}
 else {
bigloo_type_error_location_103___error(symbol2367___r4_output_6_10_3, string2337___r4_output_6_10_3, port_19, string2333___r4_output_6_10_3, BINT(((long)11751)));
exit( -1 );}
WRITE_CHAR(((unsigned char)' '), aux_2604);
}
{
long i_2611;
i_2611 = (((long)1)+i_527);
i_527 = i_2611;
goto loop_528;
}
}
}
}
}
}
}
POP_TRACE();
return aux1376_1049;
}
}
}
}


/* write/display-vector */obj_t write_display_vector_76___r4_output_6_10_3(obj_t obj_21, obj_t port_22, bool_t flag_23)
{
{
obj_t symbol1379_1050;
symbol1379_1050 = symbol2370___r4_output_6_10_3;
{
PUSH_TRACE(symbol1379_1050);
BUNSPEC;
{
obj_t aux1378_1051;
{
obj_t aux_2615;
if(OUTPUT_PORTP(port_22)){
aux_2615 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12076)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'#'), aux_2615);
}
{
long tag_540;
{
obj_t vector_909;
if(VECTORP(obj_21)){
vector_909 = obj_21;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2371___r4_output_6_10_3, obj_21, string2333___r4_output_6_10_3, BINT(((long)12101)));
exit( -1 );}
tag_540 = VECTOR_TAG(vector_909);
}
if((tag_540>((long)0))){
if((tag_540>=((long)100))){
obj_t aux_2634;
obj_t aux_2632;
if(OUTPUT_PORTP(port_22)){
aux_2634 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12193)));
exit( -1 );}
aux_2632 = BINT(tag_540);
write_object(aux_2632, aux_2634);
}
 else {
{
obj_t aux_2641;
if(OUTPUT_PORTP(port_22)){
aux_2641 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12233)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'0'), aux_2641);
}
if((tag_540>=((long)10))){
obj_t aux_2652;
obj_t aux_2650;
if(OUTPUT_PORTP(port_22)){
aux_2652 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12284)));
exit( -1 );}
aux_2650 = BINT(tag_540);
write_object(aux_2650, aux_2652);
}
 else {
{
obj_t aux_2659;
if(OUTPUT_PORTP(port_22)){
aux_2659 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12324)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'0'), aux_2659);
}
{
obj_t aux_2668;
obj_t aux_2666;
if(OUTPUT_PORTP(port_22)){
aux_2668 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12354)));
exit( -1 );}
aux_2666 = BINT(tag_540);
write_object(aux_2666, aux_2668);
}
}
}
}
 else {
BUNSPEC;
}
}
{
obj_t aux_2675;
if(OUTPUT_PORTP(port_22)){
aux_2675 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12388)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'('), aux_2675);
}
{
bool_t test1099_544;
{
long arg1110_558;
{
obj_t vector_916;
if(VECTORP(obj_21)){
vector_916 = obj_21;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2371___r4_output_6_10_3, obj_21, string2333___r4_output_6_10_3, BINT(((long)12413)));
exit( -1 );}
arg1110_558 = VECTOR_LENGTH(vector_916);
}
test1099_544 = (((long)0)==arg1110_558);
}
if(test1099_544){
unsigned char aux_2690;
{
obj_t aux_2691;
if(OUTPUT_PORTP(port_22)){
aux_2691 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12454)));
exit( -1 );}
aux_2690 = WRITE_CHAR(((unsigned char)')'), aux_2691);
}
aux1378_1051 = BCHAR(aux_2690);
}
 else {
long len_545;
{
long arg1107_555;
{
obj_t vector_919;
if(VECTORP(obj_21)){
vector_919 = obj_21;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2371___r4_output_6_10_3, obj_21, string2333___r4_output_6_10_3, BINT(((long)12488)));
exit( -1 );}
arg1107_555 = VECTOR_LENGTH(vector_919);
}
len_545 = (arg1107_555-((long)1));
}
{
long i_546;
i_546 = ((long)0);
loop_547:
{
bool_t test1100_548;
{
bool_t test1105_553;
{
obj_t obj_922;
obj_922 = _max_length_write__149___r4_output_6_10_3;
test1105_553 = INTEGERP(obj_922);
}
if(test1105_553){
bool_t test1106_554;
{
long n1_923;
{
obj_t aux_2708;
{
obj_t aux1958_1601;
aux1958_1601 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux1958_1601)){
aux_2708 = aux1958_1601;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1958_1601, string2333___r4_output_6_10_3, BINT(((long)12591)));
exit( -1 );}
}
n1_923 = (long)CINT(aux_2708);
}
test1106_554 = (n1_923>((long)0));
}
if(test1106_554){
long n1_925;
long n2_926;
{
obj_t aux_2717;
{
obj_t aux1964_1607;
aux1964_1607 = _displayed__5___r4_output_6_10_3;
if(INTEGERP(aux1964_1607)){
aux_2717 = aux1964_1607;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1964_1607, string2333___r4_output_6_10_3, BINT(((long)12626)));
exit( -1 );}
}
n1_925 = (long)CINT(aux_2717);
}
{
obj_t aux_2724;
{
obj_t aux1973_1613;
aux1973_1613 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux1973_1613)){
aux_2724 = aux1973_1613;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2332___r4_output_6_10_3, aux1973_1613, string2333___r4_output_6_10_3, BINT(((long)12631)));
exit( -1 );}
}
n2_926 = (long)CINT(aux_2724);
}
test1100_548 = (n1_925>=n2_926);
}
 else {
test1100_548 = ((bool_t)0);
}
}
 else {
test1100_548 = ((bool_t)0);
}
}
if(test1100_548){
{
obj_t aux_2733;
if(OUTPUT_PORTP(port_22)){
aux_2733 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12681)));
exit( -1 );}
aux1378_1051 = write_object(string2372___r4_output_6_10_3, aux_2733);
}
}
 else {
if((i_546==len_545)){
{
obj_t arg1102_550;
{
obj_t vector_929;
if(VECTORP(obj_21)){
vector_929 = obj_21;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2371___r4_output_6_10_3, obj_21, string2333___r4_output_6_10_3, BINT(((long)12729)));
exit( -1 );}
{
bool_t test1249_931;
{
long aux_2747;
aux_2747 = VECTOR_LENGTH(vector_929);
test1249_931 = BOUND_CHECK(i_546, aux_2747);
}
if(test1249_931){
arg1102_550 = VECTOR_REF(vector_929, i_546);
}
 else {
arg1102_550 = debug_error_location_199___error(string2373___r4_output_6_10_3, string2374___r4_output_6_10_3, BINT(i_546), string2348___r4_output_6_10_3, BINT(((long)7610)));
}
}
}
write_display_159___r4_output_6_10_3(arg1102_550, port_22, flag_23);
}
{
unsigned char aux_2756;
{
obj_t aux_2757;
if(OUTPUT_PORTP(port_22)){
aux_2757 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12776)));
exit( -1 );}
aux_2756 = WRITE_CHAR(((unsigned char)')'), aux_2757);
}
aux1378_1051 = BCHAR(aux_2756);
}
}
 else {
{
obj_t arg1103_551;
{
obj_t vector_937;
if(VECTORP(obj_21)){
vector_937 = obj_21;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2371___r4_output_6_10_3, obj_21, string2333___r4_output_6_10_3, BINT(((long)12813)));
exit( -1 );}
{
bool_t test1249_939;
{
long aux_2770;
aux_2770 = VECTOR_LENGTH(vector_937);
test1249_939 = BOUND_CHECK(i_546, aux_2770);
}
if(test1249_939){
arg1103_551 = VECTOR_REF(vector_937, i_546);
}
 else {
arg1103_551 = debug_error_location_199___error(string2373___r4_output_6_10_3, string2374___r4_output_6_10_3, BINT(i_546), string2348___r4_output_6_10_3, BINT(((long)7610)));
}
}
}
write_display_159___r4_output_6_10_3(arg1103_551, port_22, flag_23);
}
{
obj_t aux_2779;
if(OUTPUT_PORTP(port_22)){
aux_2779 = port_22;
}
 else {
bigloo_type_error_location_103___error(symbol2370___r4_output_6_10_3, string2337___r4_output_6_10_3, port_22, string2333___r4_output_6_10_3, BINT(((long)12860)));
exit( -1 );}
WRITE_CHAR(((unsigned char)' '), aux_2779);
}
{
long i_2786;
i_2786 = (((long)1)+i_546);
i_546 = i_2786;
goto loop_547;
}
}
}
}
}
}
}
POP_TRACE();
return aux1378_1051;
}
}
}
}


/* write/display-tvector */obj_t write_display_tvector_50___r4_output_6_10_3(obj_t tvec_24, obj_t port_25, bool_t flag_26)
{
{
obj_t symbol1381_1052;
symbol1381_1052 = symbol2375___r4_output_6_10_3;
{
PUSH_TRACE(symbol1381_1052);
BUNSPEC;
{
obj_t aux1380_1053;
{
obj_t tvector_ref_208_559;
obj_t id_560;
{
obj_t aux_2790;
if(TVECTORP(tvec_24)){
aux_2790 = tvec_24;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2376___r4_output_6_10_3, tvec_24, string2333___r4_output_6_10_3, BINT(((long)13194)));
exit( -1 );}
tvector_ref_208_559 = tvector_ref_208___tvector(aux_2790);
}
{
obj_t aux_2797;
if(TVECTORP(tvec_24)){
aux_2797 = tvec_24;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2376___r4_output_6_10_3, tvec_24, string2333___r4_output_6_10_3, BINT(((long)13229)));
exit( -1 );}
id_560 = tvector_id_255___tvector(aux_2797);
}
{
obj_t aux_2804;
if(OUTPUT_PORTP(port_25)){
aux_2804 = port_25;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2337___r4_output_6_10_3, port_25, string2333___r4_output_6_10_3, BINT(((long)13268)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'#'), aux_2804);
}
{
obj_t aux_2811;
if(OUTPUT_PORTP(port_25)){
aux_2811 = port_25;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2337___r4_output_6_10_3, port_25, string2333___r4_output_6_10_3, BINT(((long)13298)));
exit( -1 );}
write_object(id_560, aux_2811);
}
{
obj_t aux_2818;
if(OUTPUT_PORTP(port_25)){
aux_2818 = port_25;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2337___r4_output_6_10_3, port_25, string2333___r4_output_6_10_3, BINT(((long)13327)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'('), aux_2818);
}
if(CBOOL(tvector_ref_208_559)){
{
bool_t test1111_561;
{
long arg1122_575;
{
obj_t obj_947;
if(TVECTORP(tvec_24)){
obj_947 = tvec_24;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2376___r4_output_6_10_3, tvec_24, string2333___r4_output_6_10_3, BINT(((long)13448)));
exit( -1 );}
arg1122_575 = TVECTOR_LENGTH(obj_947);
}
test1111_561 = (((long)0)==arg1122_575);
}
if(test1111_561){
unsigned char aux_2835;
{
obj_t aux_2836;
if(OUTPUT_PORTP(port_25)){
aux_2836 = port_25;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2337___r4_output_6_10_3, port_25, string2333___r4_output_6_10_3, BINT(((long)13487)));
exit( -1 );}
aux_2835 = WRITE_CHAR(((unsigned char)')'), aux_2836);
}
aux1380_1053 = BCHAR(aux_2835);
}
 else {
long len_562;
{
long arg1119_572;
{
obj_t obj_950;
if(TVECTORP(tvec_24)){
obj_950 = tvec_24;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2376___r4_output_6_10_3, tvec_24, string2333___r4_output_6_10_3, BINT(((long)13517)));
exit( -1 );}
arg1119_572 = TVECTOR_LENGTH(obj_950);
}
len_562 = (arg1119_572-((long)1));
}
{
long i_563;
i_563 = ((long)0);
loop_564:
{
bool_t test1112_565;
{
bool_t test1117_570;
{
obj_t obj_953;
obj_953 = _max_length_write__149___r4_output_6_10_3;
test1117_570 = INTEGERP(obj_953);
}
if(test1117_570){
bool_t test1118_571;
{
long n1_954;
{
obj_t aux_2853;
{
obj_t aux2065_1697;
aux2065_1697 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux2065_1697)){
aux_2853 = aux2065_1697;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2332___r4_output_6_10_3, aux2065_1697, string2333___r4_output_6_10_3, BINT(((long)13627)));
exit( -1 );}
}
n1_954 = (long)CINT(aux_2853);
}
test1118_571 = (n1_954>((long)0));
}
if(test1118_571){
long n1_956;
long n2_957;
{
obj_t aux_2862;
{
obj_t aux2071_1703;
aux2071_1703 = _displayed__5___r4_output_6_10_3;
if(INTEGERP(aux2071_1703)){
aux_2862 = aux2071_1703;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2332___r4_output_6_10_3, aux2071_1703, string2333___r4_output_6_10_3, BINT(((long)13658)));
exit( -1 );}
}
n1_956 = (long)CINT(aux_2862);
}
{
obj_t aux_2869;
{
obj_t aux2077_1709;
aux2077_1709 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux2077_1709)){
aux_2869 = aux2077_1709;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2332___r4_output_6_10_3, aux2077_1709, string2333___r4_output_6_10_3, BINT(((long)13663)));
exit( -1 );}
}
n2_957 = (long)CINT(aux_2869);
}
test1112_565 = (n1_956>=n2_957);
}
 else {
test1112_565 = ((bool_t)0);
}
}
 else {
test1112_565 = ((bool_t)0);
}
}
if(test1112_565){
{
obj_t aux_2878;
if(OUTPUT_PORTP(port_25)){
aux_2878 = port_25;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2337___r4_output_6_10_3, port_25, string2333___r4_output_6_10_3, BINT(((long)13716)));
exit( -1 );}
aux1380_1053 = write_object(string2372___r4_output_6_10_3, aux_2878);
}
}
 else {
if((i_563==len_562)){
{
obj_t arg1114_567;
{
obj_t fun_1727;
if(PROCEDUREP(tvector_ref_208_559)){
fun_1727 = tvector_ref_208_559;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2340___r4_output_6_10_3, tvector_ref_208_559, string2333___r4_output_6_10_3, BINT(((long)13770)));
exit( -1 );}
{
bool_t test2101_1734;
test2101_1734 = PROCEDURE_CORRECT_ARITYP(fun_1727, ((long)2));
if(test2101_1734){
arg1114_567 = PROCEDURE_ENTRY(fun_1727)(tvector_ref_208_559, tvec_24, BINT(i_563), BEOA);
}
 else {
error_location_112___error(string2377___r4_output_6_10_3, list2378___r4_output_6_10_3, fun_1727, string2333___r4_output_6_10_3, BINT(((long)13770)));
FAILURE(symbol2347___r4_output_6_10_3,symbol2347___r4_output_6_10_3,symbol2347___r4_output_6_10_3);}
}
}
write_display_159___r4_output_6_10_3(arg1114_567, port_25, flag_26);
}
{
unsigned char aux_2901;
{
obj_t aux_2902;
if(OUTPUT_PORTP(port_25)){
aux_2902 = port_25;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2337___r4_output_6_10_3, port_25, string2333___r4_output_6_10_3, BINT(((long)13836)));
exit( -1 );}
aux_2901 = WRITE_CHAR(((unsigned char)')'), aux_2902);
}
aux1380_1053 = BCHAR(aux_2901);
}
}
 else {
{
obj_t arg1115_568;
{
obj_t fun_1747;
if(PROCEDUREP(tvector_ref_208_559)){
fun_1747 = tvector_ref_208_559;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2340___r4_output_6_10_3, tvector_ref_208_559, string2333___r4_output_6_10_3, BINT(((long)13879)));
exit( -1 );}
{
bool_t test2123_1754;
test2123_1754 = PROCEDURE_CORRECT_ARITYP(fun_1747, ((long)2));
if(test2123_1754){
arg1115_568 = PROCEDURE_ENTRY(fun_1747)(tvector_ref_208_559, tvec_24, BINT(i_563), BEOA);
}
 else {
error_location_112___error(string2377___r4_output_6_10_3, list2378___r4_output_6_10_3, fun_1747, string2333___r4_output_6_10_3, BINT(((long)13879)));
FAILURE(symbol2347___r4_output_6_10_3,symbol2347___r4_output_6_10_3,symbol2347___r4_output_6_10_3);}
}
}
write_display_159___r4_output_6_10_3(arg1115_568, port_25, flag_26);
}
{
obj_t aux_2924;
if(OUTPUT_PORTP(port_25)){
aux_2924 = port_25;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2337___r4_output_6_10_3, port_25, string2333___r4_output_6_10_3, BINT(((long)13945)));
exit( -1 );}
WRITE_CHAR(((unsigned char)' '), aux_2924);
}
{
long i_2931;
i_2931 = (((long)1)+i_563);
i_563 = i_2931;
goto loop_564;
}
}
}
}
}
}
}
}
 else {
{
obj_t aux_2933;
if(OUTPUT_PORTP(port_25)){
aux_2933 = port_25;
}
 else {
bigloo_type_error_location_103___error(symbol2375___r4_output_6_10_3, string2337___r4_output_6_10_3, port_25, string2333___r4_output_6_10_3, BINT(((long)13395)));
exit( -1 );}
write_object(string2382___r4_output_6_10_3, aux_2933);
}
aux1380_1053 = tvec_24;
}
}
POP_TRACE();
return aux1380_1053;
}
}
}
}


/* write/display-pair */obj_t write_display_pair_103___r4_output_6_10_3(obj_t obj_30, obj_t port_31, bool_t flag_32)
{
{
obj_t symbol1383_1054;
symbol1383_1054 = symbol2383___r4_output_6_10_3;
{
PUSH_TRACE(symbol1383_1054);
BUNSPEC;
{
obj_t aux1382_1055;
{
obj_t aux_2942;
if(OUTPUT_PORTP(port_31)){
aux_2942 = port_31;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2337___r4_output_6_10_3, port_31, string2333___r4_output_6_10_3, BINT(((long)14620)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'('), aux_2942);
}
{
obj_t l_580;
l_580 = obj_30;
loop_581:
{
bool_t test1127_582;
{
obj_t arg1139_593;
{
obj_t pair_966;
if(PAIRP(l_580)){
pair_966 = l_580;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2336___r4_output_6_10_3, l_580, string2333___r4_output_6_10_3, BINT(((long)14676)));
exit( -1 );}
arg1139_593 = CDR(pair_966);
}
test1127_582 = NULLP(arg1139_593);
}
if(test1127_582){
{
obj_t arg1128_583;
{
obj_t pair_968;
if(PAIRP(l_580)){
pair_968 = l_580;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2336___r4_output_6_10_3, l_580, string2333___r4_output_6_10_3, BINT(((long)14703)));
exit( -1 );}
arg1128_583 = CAR(pair_968);
}
write_display_159___r4_output_6_10_3(arg1128_583, port_31, flag_32);
}
{
unsigned char aux_2964;
{
obj_t aux_2965;
if(OUTPUT_PORTP(port_31)){
aux_2965 = port_31;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2337___r4_output_6_10_3, port_31, string2333___r4_output_6_10_3, BINT(((long)14738)));
exit( -1 );}
aux_2964 = WRITE_CHAR(((unsigned char)')'), aux_2965);
}
aux1382_1055 = BCHAR(aux_2964);
}
}
 else {
bool_t test1129_584;
{
bool_t test1136_591;
{
obj_t obj_969;
obj_969 = _max_length_write__149___r4_output_6_10_3;
test1136_591 = INTEGERP(obj_969);
}
if(test1136_591){
bool_t test1137_592;
{
long n1_970;
{
obj_t aux_2975;
{
obj_t aux2164_1791;
aux2164_1791 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux2164_1791)){
aux_2975 = aux2164_1791;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2332___r4_output_6_10_3, aux2164_1791, string2333___r4_output_6_10_3, BINT(((long)14795)));
exit( -1 );}
}
n1_970 = (long)CINT(aux_2975);
}
test1137_592 = (n1_970>((long)0));
}
if(test1137_592){
long n1_972;
long n2_973;
{
obj_t aux_2984;
{
obj_t aux2171_1797;
aux2171_1797 = _displayed__5___r4_output_6_10_3;
if(INTEGERP(aux2171_1797)){
aux_2984 = aux2171_1797;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2332___r4_output_6_10_3, aux2171_1797, string2333___r4_output_6_10_3, BINT(((long)14830)));
exit( -1 );}
}
n1_972 = (long)CINT(aux_2984);
}
{
obj_t aux_2991;
{
obj_t aux2177_1803;
aux2177_1803 = _max_length_write__149___r4_output_6_10_3;
if(INTEGERP(aux2177_1803)){
aux_2991 = aux2177_1803;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2332___r4_output_6_10_3, aux2177_1803, string2333___r4_output_6_10_3, BINT(((long)14835)));
exit( -1 );}
}
n2_973 = (long)CINT(aux_2991);
}
test1129_584 = (n1_972>=n2_973);
}
 else {
test1129_584 = ((bool_t)0);
}
}
 else {
test1129_584 = ((bool_t)0);
}
}
if(test1129_584){
{
obj_t aux_3000;
if(OUTPUT_PORTP(port_31)){
aux_3000 = port_31;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2337___r4_output_6_10_3, port_31, string2333___r4_output_6_10_3, BINT(((long)14885)));
exit( -1 );}
aux1382_1055 = write_object(string2384___r4_output_6_10_3, aux_3000);
}
}
 else {
bool_t test1130_585;
{
obj_t arg1135_590;
{
obj_t pair_974;
if(PAIRP(l_580)){
pair_974 = l_580;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2336___r4_output_6_10_3, l_580, string2333___r4_output_6_10_3, BINT(((long)14919)));
exit( -1 );}
arg1135_590 = CDR(pair_974);
}
test1130_585 = PAIRP(arg1135_590);
}
if(test1130_585){
{
obj_t arg1131_586;
{
obj_t pair_976;
if(PAIRP(l_580)){
pair_976 = l_580;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2336___r4_output_6_10_3, l_580, string2333___r4_output_6_10_3, BINT(((long)15146)));
exit( -1 );}
arg1131_586 = CAR(pair_976);
}
write_display_159___r4_output_6_10_3(arg1131_586, port_31, flag_32);
}
{
obj_t aux_3022;
if(OUTPUT_PORTP(port_31)){
aux_3022 = port_31;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2337___r4_output_6_10_3, port_31, string2333___r4_output_6_10_3, BINT(((long)15181)));
exit( -1 );}
WRITE_CHAR(((unsigned char)' '), aux_3022);
}
{
obj_t arg1132_587;
{
obj_t pair_977;
if(PAIRP(l_580)){
pair_977 = l_580;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2336___r4_output_6_10_3, l_580, string2333___r4_output_6_10_3, BINT(((long)15205)));
exit( -1 );}
arg1132_587 = CDR(pair_977);
}
{
obj_t l_3035;
l_3035 = arg1132_587;
l_580 = l_3035;
goto loop_581;
}
}
}
 else {
{
obj_t arg1133_588;
{
obj_t pair_978;
if(PAIRP(l_580)){
pair_978 = l_580;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2336___r4_output_6_10_3, l_580, string2333___r4_output_6_10_3, BINT(((long)14947)));
exit( -1 );}
arg1133_588 = CAR(pair_978);
}
write_display_159___r4_output_6_10_3(arg1133_588, port_31, flag_32);
}
{
obj_t aux_3043;
if(OUTPUT_PORTP(port_31)){
aux_3043 = port_31;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2337___r4_output_6_10_3, port_31, string2333___r4_output_6_10_3, BINT(((long)14982)));
exit( -1 );}
WRITE_CHAR(((unsigned char)' '), aux_3043);
}
{
obj_t aux_3050;
if(OUTPUT_PORTP(port_31)){
aux_3050 = port_31;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2337___r4_output_6_10_3, port_31, string2333___r4_output_6_10_3, BINT(((long)15013)));
exit( -1 );}
WRITE_CHAR(((unsigned char)'.'), aux_3050);
}
{
obj_t aux_3057;
if(OUTPUT_PORTP(port_31)){
aux_3057 = port_31;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2337___r4_output_6_10_3, port_31, string2333___r4_output_6_10_3, BINT(((long)15040)));
exit( -1 );}
WRITE_CHAR(((unsigned char)' '), aux_3057);
}
{
obj_t arg1134_589;
{
obj_t pair_979;
if(PAIRP(l_580)){
pair_979 = l_580;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2336___r4_output_6_10_3, l_580, string2333___r4_output_6_10_3, BINT(((long)15073)));
exit( -1 );}
arg1134_589 = CDR(pair_979);
}
write_display_159___r4_output_6_10_3(arg1134_589, port_31, flag_32);
}
{
unsigned char aux_3071;
{
obj_t aux_3072;
if(OUTPUT_PORTP(port_31)){
aux_3072 = port_31;
}
 else {
bigloo_type_error_location_103___error(symbol2383___r4_output_6_10_3, string2337___r4_output_6_10_3, port_31, string2333___r4_output_6_10_3, BINT(((long)15108)));
exit( -1 );}
aux_3071 = WRITE_CHAR(((unsigned char)')'), aux_3072);
}
aux1382_1055 = BCHAR(aux_3071);
}
}
}
}
}
}
POP_TRACE();
return aux1382_1055;
}
}
}
}


/* print */obj_t print___r4_output_6_10_3(obj_t obj_33)
{
{
obj_t symbol1385_1056;
symbol1385_1056 = symbol2385___r4_output_6_10_3;
{
PUSH_TRACE(symbol1385_1056);
BUNSPEC;
{
obj_t aux1384_1057;
_displayed__5___r4_output_6_10_3 = BINT(((long)0));
{
obj_t l_595;
obj_t res_596;
l_595 = obj_33;
res_596 = BNIL;
loop_597:
if(NULLP(l_595)){
WRITE_CHAR(((unsigned char)'\n'), current_output_port);
aux1384_1057 = res_596;
}
 else {
obj_t v_600;
{
obj_t pair_981;
if(PAIRP(l_595)){
pair_981 = l_595;
}
 else {
bigloo_type_error_location_103___error(symbol2385___r4_output_6_10_3, string2336___r4_output_6_10_3, l_595, string2333___r4_output_6_10_3, BINT(((long)15873)));
exit( -1 );}
v_600 = CAR(pair_981);
}
write_display_159___r4_output_6_10_3(v_600, current_output_port, ((bool_t)1));
{
obj_t arg1142_601;
{
obj_t pair_982;
if(PAIRP(l_595)){
pair_982 = l_595;
}
 else {
bigloo_type_error_location_103___error(symbol2385___r4_output_6_10_3, string2336___r4_output_6_10_3, l_595, string2333___r4_output_6_10_3, BINT(((long)15919)));
exit( -1 );}
arg1142_601 = CDR(pair_982);
}
{
obj_t res_3100;
obj_t l_3099;
l_3099 = arg1142_601;
res_3100 = v_600;
res_596 = res_3100;
l_595 = l_3099;
goto loop_597;
}
}
}
}
POP_TRACE();
return aux1384_1057;
}
}
}
}


/* _print */obj_t _print___r4_output_6_10_3(obj_t env_1120, obj_t obj_1121)
{
return print___r4_output_6_10_3(obj_1121);
}


/* display* */obj_t display__75___r4_output_6_10_3(obj_t obj_34)
{
{
obj_t symbol1387_1058;
symbol1387_1058 = symbol2386___r4_output_6_10_3;
{
PUSH_TRACE(symbol1387_1058);
BUNSPEC;
{
obj_t aux1386_1059;
_displayed__5___r4_output_6_10_3 = BINT(((long)0));
{
obj_t l_603;
l_603 = obj_34;
loop_604:
if(NULLP(l_603)){
aux1386_1059 = BUNSPEC;
}
 else {
{
obj_t arg1144_607;
{
obj_t pair_985;
if(PAIRP(l_603)){
pair_985 = l_603;
}
 else {
bigloo_type_error_location_103___error(symbol2386___r4_output_6_10_3, string2336___r4_output_6_10_3, l_603, string2333___r4_output_6_10_3, BINT(((long)16343)));
exit( -1 );}
arg1144_607 = CAR(pair_985);
}
{
obj_t list1145_608;
list1145_608 = MAKE_PAIR(current_output_port, BNIL);
display___r4_output_6_10_3(arg1144_607, list1145_608);
}
}
{
obj_t arg1147_610;
{
obj_t pair_986;
if(PAIRP(l_603)){
pair_986 = l_603;
}
 else {
bigloo_type_error_location_103___error(symbol2386___r4_output_6_10_3, string2336___r4_output_6_10_3, l_603, string2333___r4_output_6_10_3, BINT(((long)16365)));
exit( -1 );}
arg1147_610 = CDR(pair_986);
}
{
obj_t l_3121;
l_3121 = arg1147_610;
l_603 = l_3121;
goto loop_604;
}
}
}
}
POP_TRACE();
return aux1386_1059;
}
}
}
}


/* _display* */obj_t _display__37___r4_output_6_10_3(obj_t env_1122, obj_t obj_1123)
{
return display__75___r4_output_6_10_3(obj_1123);
}


/* write* */obj_t write__14___r4_output_6_10_3(obj_t obj_35)
{
{
obj_t symbol1389_1060;
symbol1389_1060 = symbol2387___r4_output_6_10_3;
{
PUSH_TRACE(symbol1389_1060);
BUNSPEC;
{
obj_t aux1388_1061;
_displayed__5___r4_output_6_10_3 = BINT(((long)0));
{
obj_t l_612;
l_612 = obj_35;
loop_613:
if(NULLP(l_612)){
aux1388_1061 = BUNSPEC;
}
 else {
{
obj_t arg1150_616;
{
obj_t pair_989;
if(PAIRP(l_612)){
pair_989 = l_612;
}
 else {
bigloo_type_error_location_103___error(symbol2387___r4_output_6_10_3, string2336___r4_output_6_10_3, l_612, string2333___r4_output_6_10_3, BINT(((long)16791)));
exit( -1 );}
arg1150_616 = CAR(pair_989);
}
write_display_159___r4_output_6_10_3(arg1150_616, current_output_port, ((bool_t)0));
}
{
obj_t arg1151_617;
{
obj_t pair_990;
if(PAIRP(l_612)){
pair_990 = l_612;
}
 else {
bigloo_type_error_location_103___error(symbol2387___r4_output_6_10_3, string2336___r4_output_6_10_3, l_612, string2333___r4_output_6_10_3, BINT(((long)16816)));
exit( -1 );}
arg1151_617 = CDR(pair_990);
}
{
obj_t l_3141;
l_3141 = arg1151_617;
l_612 = l_3141;
goto loop_613;
}
}
}
}
POP_TRACE();
return aux1388_1061;
}
}
}
}


/* _write* */obj_t _write__154___r4_output_6_10_3(obj_t env_1124, obj_t obj_1125)
{
return write__14___r4_output_6_10_3(obj_1125);
}


/* fprint */obj_t fprint___r4_output_6_10_3(obj_t port_36, obj_t obj_37)
{
{
obj_t symbol1391_1062;
symbol1391_1062 = symbol2388___r4_output_6_10_3;
{
PUSH_TRACE(symbol1391_1062);
BUNSPEC;
{
obj_t aux1390_1063;
_displayed__5___r4_output_6_10_3 = BINT(((long)0));
{
obj_t l_618;
obj_t res_619;
l_618 = obj_37;
res_619 = BNIL;
loop_620:
if(NULLP(l_618)){
WRITE_CHAR(((unsigned char)'\n'), port_36);
aux1390_1063 = res_619;
}
 else {
obj_t v_623;
{
obj_t pair_992;
if(PAIRP(l_618)){
pair_992 = l_618;
}
 else {
bigloo_type_error_location_103___error(symbol2388___r4_output_6_10_3, string2336___r4_output_6_10_3, l_618, string2333___r4_output_6_10_3, BINT(((long)17237)));
exit( -1 );}
v_623 = CAR(pair_992);
}
{
obj_t arg1154_624;
{
obj_t pair_993;
if(PAIRP(l_618)){
pair_993 = l_618;
}
 else {
bigloo_type_error_location_103___error(symbol2388___r4_output_6_10_3, string2336___r4_output_6_10_3, l_618, string2333___r4_output_6_10_3, BINT(((long)17268)));
exit( -1 );}
arg1154_624 = CAR(pair_993);
}
write_display_159___r4_output_6_10_3(arg1154_624, port_36, ((bool_t)1));
}
{
obj_t arg1155_625;
{
obj_t pair_994;
if(PAIRP(l_618)){
pair_994 = l_618;
}
 else {
bigloo_type_error_location_103___error(symbol2388___r4_output_6_10_3, string2336___r4_output_6_10_3, l_618, string2333___r4_output_6_10_3, BINT(((long)17297)));
exit( -1 );}
arg1155_625 = CDR(pair_994);
}
{
obj_t res_3169;
obj_t l_3168;
l_3168 = arg1155_625;
res_3169 = v_623;
res_619 = res_3169;
l_618 = l_3168;
goto loop_620;
}
}
}
}
POP_TRACE();
return aux1390_1063;
}
}
}
}


/* _fprint1405 */obj_t _fprint1405___r4_output_6_10_3(obj_t env_1126, obj_t port_1127, obj_t obj_1128)
{
{
obj_t aux_3171;
if(OUTPUT_PORTP(port_1127)){
aux_3171 = port_1127;
}
 else {
bigloo_type_error_location_103___error(symbol2389___r4_output_6_10_3, string2337___r4_output_6_10_3, port_1127, string2333___r4_output_6_10_3, BINT(((long)17052)));
exit( -1 );}
return fprint___r4_output_6_10_3(aux_3171, obj_1128);
}
}


/* set-printer! */obj_t set_printer__238___r4_output_6_10_3(obj_t f_38)
{
{
obj_t symbol1393_1064;
symbol1393_1064 = symbol2390___r4_output_6_10_3;
{
PUSH_TRACE(symbol1393_1064);
BUNSPEC;
{
obj_t aux1392_1065;
aux1392_1065 = (_current_printer__39___r4_output_6_10_3 = f_38,
BUNSPEC);
POP_TRACE();
return aux1392_1065;
}
}
}
}


/* _set-printer!1406 */obj_t _set_printer_1406_212___r4_output_6_10_3(obj_t env_1129, obj_t f_1130)
{
{
obj_t aux_3180;
if(PROCEDUREP(f_1130)){
aux_3180 = f_1130;
}
 else {
bigloo_type_error_location_103___error(symbol2391___r4_output_6_10_3, string2340___r4_output_6_10_3, f_1130, string2333___r4_output_6_10_3, BINT(((long)18135)));
exit( -1 );}
return set_printer__238___r4_output_6_10_3(aux_3180);
}
}


/* native-printer */obj_t native_printer_249___r4_output_6_10_3()
{
{
obj_t symbol1395_1066;
symbol1395_1066 = symbol2392___r4_output_6_10_3;
{
PUSH_TRACE(symbol1395_1066);
BUNSPEC;
POP_TRACE();
return native_display_env_3___r4_output_6_10_3;
}
}
}


/* _native-printer */obj_t _native_printer_193___r4_output_6_10_3(obj_t env_1131)
{
return native_printer_249___r4_output_6_10_3();
}


/* c-debugging-print */obj_t dprint(obj_t obj_39)
{
{
obj_t symbol1397_1068;
symbol1397_1068 = symbol2393___r4_output_6_10_3;
{
PUSH_TRACE(symbol1397_1068);
BUNSPEC;
{
obj_t aux1396_1069;
_displayed__5___r4_output_6_10_3 = BINT(((long)0));
write_display_159___r4_output_6_10_3(obj_39, current_output_port, ((bool_t)1));
WRITE_CHAR(((unsigned char)'\n'), current_output_port);
aux1396_1069 = obj_39;
POP_TRACE();
return aux1396_1069;
}
}
}
}


/* _c-debugging-print */obj_t _c_debugging_print_109___r4_output_6_10_3(obj_t env_1132, obj_t obj_1133)
{
return dprint(obj_1133);
}


/* method-init */obj_t method_init_76___r4_output_6_10_3()
{
{
obj_t symbol1399_1070;
symbol1399_1070 = symbol2394___r4_output_6_10_3;
{
PUSH_TRACE(symbol1399_1070);
BUNSPEC;
POP_TRACE();
return BUNSPEC;
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_output_6_10_3()
{
{
obj_t symbol1401_1072;
symbol1401_1072 = symbol2395___r4_output_6_10_3;
{
PUSH_TRACE(symbol1401_1072);
BUNSPEC;
{
obj_t aux1400_1073;
module_initialization_70___error(((long)0), "__R4_OUTPUT_6_10_3");
module_initialization_70___bexit(((long)0), "__R4_OUTPUT_6_10_3");
aux1400_1073 = module_initialization_70___r4_ports_6_10_1(((long)0), "__R4_OUTPUT_6_10_3");
POP_TRACE();
return aux1400_1073;
}
}
}
}

