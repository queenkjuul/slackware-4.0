/*===========================================================================*/
/*   (Module/pragma.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern obj_t ccomp_module_module;
extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_module_pragma();
extern obj_t warning___error(obj_t);
extern obj_t global_ast_var;
static obj_t _make_pragma_compiler_94_module_pragma(obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t pragma_producer_255_module_pragma(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_module_pragma(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern long class_num_218___object(obj_t);
extern obj_t remove_var_from__148_ast_remove(obj_t, variable_t);
extern obj_t fun_ast_var;
static obj_t imported_modules_init_94_module_pragma();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t make_pragma_compiler_150_module_pragma();
static obj_t pragma_parser_198_module_pragma(obj_t, obj_t, obj_t);
static obj_t _pragma_list__157_module_pragma = BUNSPEC;
static obj_t library_modules_init_112_module_pragma();
extern obj_t _optim_stack___57_engine_param;
static bool_t set_pragma_properties__114_module_pragma(obj_t, obj_t, obj_t);
extern type_t use_type__231_type_env(obj_t);
static obj_t toplevel_init_63_module_pragma();
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
static obj_t lambda1208_module_pragma(obj_t, obj_t);
static obj_t _pragma_finalizer_19_module_pragma(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t arg1202_module_pragma(obj_t, obj_t, obj_t);
static obj_t arg1200_module_pragma(obj_t, obj_t, obj_t);
extern obj_t _module__166_module_module;
static obj_t set_pragma_property__180_module_pragma(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t pragma_finalizer_170_module_pragma();
static obj_t require_initialization_114_module_pragma = BUNSPEC;
static obj_t cnst_init_137_module_pragma();
static obj_t __cnst[11];

DEFINE_EXPORT_PROCEDURE(make_pragma_compiler_env_9_module_pragma, _make_pragma_compiler_94_module_pragma1445, _make_pragma_compiler_94_module_pragma, 0L, 0);
DEFINE_EXPORT_PROCEDURE(pragma_finalizer_env_89_module_pragma, _pragma_finalizer_19_module_pragma1446, _pragma_finalizer_19_module_pragma, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1424_module_pragma, arg1200_module_pragma1447, arg1200_module_pragma, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1423_module_pragma, arg1202_module_pragma1448, arg1202_module_pragma, 0L, 2);
DEFINE_STRING(string1437_module_pragma, string1437_module_pragma1449, "CFA STACK-ALLOC COERCE PREDICATE-OF NO-TRACE NO-CFA-TOP SIDE-EFFECT-FREE VOID @ FOREIGN PRAGMA ", 95);
DEFINE_STRING(string1436_module_pragma, string1436_module_pragma1450, "Can't find stack allocator", 26);
DEFINE_STRING(string1435_module_pragma, string1435_module_pragma1451, "alloctor is not a function", 26);
DEFINE_STRING(string1434_module_pragma, string1434_module_pragma1452, "predicate is not associated to a function", 41);
DEFINE_STRING(string1433_module_pragma, string1433_module_pragma1453, "Illegal `pragma' form", 21);
DEFINE_STRING(string1432_module_pragma, string1432_module_pragma1454, "property is not concerning a sfunction", 38);
DEFINE_STRING(string1431_module_pragma, string1431_module_pragma1455, "property is not concerning a function", 37);
DEFINE_STRING(string1429_module_pragma, string1429_module_pragma1456, "Illegal `pragma' finalizer form", 31);
DEFINE_STRING(string1430_module_pragma, string1430_module_pragma1457, "pragma", 6);
DEFINE_STRING(string1428_module_pragma, string1428_module_pragma1458, "pragma-finalizer", 16);
DEFINE_STRING(string1427_module_pragma, string1427_module_pragma1459, "Can't find global variable -- ", 30);
DEFINE_STRING(string1426_module_pragma, string1426_module_pragma1460, "Parse error", 11);
DEFINE_STRING(string1425_module_pragma, string1425_module_pragma1461, "Illegal `pragma' clause", 23);


/* module-initialization */ obj_t 
module_initialization_70_module_pragma(long checksum_792, char *from_793)
{
   if (CBOOL(require_initialization_114_module_pragma))
     {
	require_initialization_114_module_pragma = BBOOL(((bool_t) 0));
	library_modules_init_112_module_pragma();
	cnst_init_137_module_pragma();
	imported_modules_init_94_module_pragma();
	method_init_76_module_pragma();
	toplevel_init_63_module_pragma();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_pragma()
{
   module_initialization_70___error(((long) 0), "MODULE_PRAGMA");
   module_initialization_70___object(((long) 0), "MODULE_PRAGMA");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_PRAGMA");
   module_initialization_70___reader(((long) 0), "MODULE_PRAGMA");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_PRAGMA");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_pragma()
{
   {
      obj_t cnst_port_138_784;
      cnst_port_138_784 = open_input_string(string1437_module_pragma);
      {
	 long i_785;
	 i_785 = ((long) 10);
       loop_786:
	 {
	    bool_t test1438_787;
	    test1438_787 = (i_785 == ((long) -1));
	    if (test1438_787)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1440_788;
		    {
		       obj_t list1441_789;
		       {
			  obj_t arg1443_790;
			  arg1443_790 = BNIL;
			  list1441_789 = MAKE_PAIR(cnst_port_138_784, arg1443_790);
		       }
		       arg1440_788 = read___reader(list1441_789);
		    }
		    CNST_TABLE_SET(i_785, arg1440_788);
		 }
		 {
		    int aux_791;
		    {
		       long aux_813;
		       aux_813 = (i_785 - ((long) 1));
		       aux_791 = (int) (aux_813);
		    }
		    {
		       long i_816;
		       i_816 = (long) (aux_791);
		       i_785 = i_816;
		       goto loop_786;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_pragma()
{
   return (_pragma_list__157_module_pragma = BNIL,
      BUNSPEC);
}


/* make-pragma-compiler */ obj_t 
make_pragma_compiler_150_module_pragma()
{
   {
      obj_t arg1197_322;
      obj_t arg1199_323;
      arg1197_322 = CNST_TABLE_REF(((long) 0));
      arg1199_323 = pragma_producer_255_module_pragma(_module__166_module_module);
      {
	 obj_t arg1202_770;
	 obj_t arg1200_771;
	 arg1202_770 = proc1423_module_pragma;
	 arg1200_771 = proc1424_module_pragma;
	 {
	    ccomp_t res1422_675;
	    {
	       ccomp_t new1002_666;
	       new1002_666 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1421_667;
		  arg1421_667 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_673;
		     obj_673 = (obj_t) (new1002_666);
		     (((obj_t) CREF(obj_673))->header = MAKE_HEADER(arg1421_667, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_824;
		  aux_824 = (object_t) (new1002_666);
		  OBJECT_WIDENING_SET(aux_824, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_666))->id) = ((obj_t) arg1197_322), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_666))->producer) = ((obj_t) arg1199_323), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_666))->consumer) = ((obj_t) arg1200_771), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_666))->finalizer) = ((obj_t) pragma_finalizer_env_89_module_pragma), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_666))->checksummer) = ((obj_t) arg1202_770), BUNSPEC);
	       res1422_675 = new1002_666;
	    }
	    return (obj_t) (res1422_675);
	 }
      }
   }
}


/* _make-pragma-compiler */ obj_t 
_make_pragma_compiler_94_module_pragma(obj_t env_772)
{
   return make_pragma_compiler_150_module_pragma();
}


/* arg1202 */ obj_t 
arg1202_module_pragma(obj_t env_773, obj_t m_774, obj_t c_775)
{
   {
      obj_t m_331;
      obj_t c_332;
      m_331 = m_774;
      c_332 = c_775;
      return c_332;
   }
}


/* arg1200 */ obj_t 
arg1200_module_pragma(obj_t env_776, obj_t m_777, obj_t c_778)
{
   {
      obj_t m_327;
      obj_t c_328;
      m_327 = m_777;
      c_328 = c_778;
      {
	 obj_t fun1206_676;
	 fun1206_676 = pragma_producer_255_module_pragma(m_327);
	 return PROCEDURE_ENTRY(fun1206_676) (fun1206_676, c_328, BEOA);
      }
   }
}


/* pragma-producer */ obj_t 
pragma_producer_255_module_pragma(obj_t module_1)
{
   {
      obj_t lambda1208_780;
      lambda1208_780 = make_fx_procedure(lambda1208_module_pragma, ((long) 1), ((long) 1));
      PROCEDURE_SET(lambda1208_780, ((long) 0), module_1);
      return lambda1208_780;
   }
}


/* lambda1208 */ obj_t 
lambda1208_module_pragma(obj_t env_781, obj_t clause_783)
{
   {
      obj_t module_782;
      module_782 = PROCEDURE_REF(env_781, ((long) 0));
      {
	 obj_t clause_336;
	 clause_336 = clause_783;
	 {
	    obj_t protos_338;
	    if (PAIRP(clause_336))
	      {
		 protos_338 = CDR(clause_336);
		 {
		    obj_t l1191_344;
		    l1191_344 = protos_338;
		  lname1192_345:
		    if (PAIRP(l1191_344))
		      {
			 pragma_parser_198_module_pragma(CAR(l1191_344), module_782, clause_336);
			 {
			    obj_t l1191_846;
			    l1191_846 = CDR(l1191_344);
			    l1191_344 = l1191_846;
			    goto lname1192_345;
			 }
		      }
		    else
		      {
			 ((bool_t) 1);
		      }
		 }
		 return BNIL;
	      }
	    else
	      {
		 {
		    obj_t arg1216_350;
		    {
		       obj_t list1222_354;
		       list1222_354 = MAKE_PAIR(string1425_module_pragma, BNIL);
		       arg1216_350 = string_append_106___r4_strings_6_7(list1222_354);
		    }
		    {
		       obj_t list1220_352;
		       list1220_352 = MAKE_PAIR(BNIL, BNIL);
		       return user_error_151_tools_error(string1426_module_pragma, arg1216_350, clause_336, list1220_352);
		    }
		 }
	      }
	 }
      }
   }
}


/* pragma-parser */ obj_t 
pragma_parser_198_module_pragma(obj_t proto_2, obj_t module_3, obj_t clause_4)
{
   {
      obj_t id_357;
      obj_t prop_358;
      if (PAIRP(proto_2))
	{
	   obj_t car_116_203_363;
	   car_116_203_363 = CAR(proto_2);
	   if (SYMBOLP(car_116_203_363))
	     {
		id_357 = car_116_203_363;
		prop_358 = CDR(proto_2);
		{
		   obj_t arg1231_366;
		   {
		      obj_t list1232_367;
		      {
			 obj_t arg1233_368;
			 {
			    obj_t arg1234_369;
			    {
			       obj_t arg1235_370;
			       arg1235_370 = MAKE_PAIR(clause_4, BNIL);
			       arg1234_369 = MAKE_PAIR(prop_358, arg1235_370);
			    }
			    arg1233_368 = MAKE_PAIR(module_3, arg1234_369);
			 }
			 list1232_367 = MAKE_PAIR(id_357, arg1233_368);
		      }
		      arg1231_366 = list1232_367;
		   }
		   {
		      obj_t obj2_688;
		      obj2_688 = _pragma_list__157_module_pragma;
		      return (_pragma_list__157_module_pragma = MAKE_PAIR(arg1231_366, obj2_688),
			 BUNSPEC);
		   }
		}
	     }
	   else
	     {
	      tag_110_179_360:
		{
		   obj_t list1242_375;
		   list1242_375 = MAKE_PAIR(BNIL, BNIL);
		   return user_error_151_tools_error(string1426_module_pragma, string1425_module_pragma, clause_4, list1242_375);
		}
	     }
	}
      else
	{
	   goto tag_110_179_360;
	}
   }
}


/* pragma-finalizer */ obj_t 
pragma_finalizer_170_module_pragma()
{
   {
      obj_t l1193_377;
      l1193_377 = _pragma_list__157_module_pragma;
    lname1194_378:
      if (PAIRP(l1193_377))
	{
	   {
	      obj_t pragma_380;
	      pragma_380 = CAR(l1193_377);
	      {
		 obj_t id_381;
		 obj_t module_382;
		 obj_t prop__131_383;
		 obj_t clause_384;
		 if (PAIRP(pragma_380))
		   {
		      obj_t cdr_133_55_389;
		      cdr_133_55_389 = CDR(pragma_380);
		      if (PAIRP(cdr_133_55_389))
			{
			   obj_t cdr_139_72_391;
			   cdr_139_72_391 = CDR(cdr_133_55_389);
			   if (PAIRP(cdr_139_72_391))
			     {
				obj_t cdr_144_157_393;
				cdr_144_157_393 = CDR(cdr_139_72_391);
				if (PAIRP(cdr_144_157_393))
				  {
				     bool_t test_880;
				     {
					obj_t aux_881;
					aux_881 = CDR(cdr_144_157_393);
					test_880 = (aux_881 == BNIL);
				     }
				     if (test_880)
				       {
					  id_381 = CAR(pragma_380);
					  module_382 = CAR(cdr_133_55_389);
					  prop__131_383 = CAR(cdr_139_72_391);
					  clause_384 = CAR(cdr_144_157_393);
					  {
					     obj_t global_402;
					     {
						obj_t global_417;
						{
						   obj_t list1282_422;
						   list1282_422 = MAKE_PAIR(module_382, BNIL);
						   global_417 = find_global_223_ast_env(id_381, list1282_422);
						}
						{
						   bool_t test1274_418;
						   test1274_418 = is_a__118___object(global_417, global_ast_var);
						   if (test1274_418)
						     {
							global_402 = global_417;
						     }
						   else
						     {
							obj_t list1278_420;
							{
							   obj_t aux_888;
							   aux_888 = CNST_TABLE_REF(((long) 1));
							   list1278_420 = MAKE_PAIR(aux_888, BNIL);
							}
							global_402 = find_global_223_ast_env(id_381, list1278_420);
						     }
						}
					     }
					     {
						bool_t test1256_403;
						test1256_403 = is_a__118___object(global_402, global_ast_var);
						if (test1256_403)
						  {
						     bool_t aux_894;
						     aux_894 = set_pragma_properties__114_module_pragma(global_402, prop__131_383, clause_384);
						     BBOOL(aux_894);
						  }
						else
						  {
						     obj_t arg1259_406;
						     {
							obj_t arg1267_411;
							arg1267_411 = CNST_TABLE_REF(((long) 2));
							{
							   obj_t list1269_413;
							   {
							      obj_t arg1270_414;
							      {
								 obj_t arg1272_415;
								 arg1272_415 = MAKE_PAIR(BNIL, BNIL);
								 arg1270_414 = MAKE_PAIR(module_382, arg1272_415);
							      }
							      list1269_413 = MAKE_PAIR(id_381, arg1270_414);
							   }
							   arg1259_406 = cons__138___r4_pairs_and_lists_6_3(arg1267_411, list1269_413);
							}
						     }
						     {
							obj_t list1260_407;
							{
							   obj_t arg1262_408;
							   {
							      obj_t arg1263_409;
							      arg1263_409 = MAKE_PAIR(arg1259_406, BNIL);
							      arg1262_408 = MAKE_PAIR(string1427_module_pragma, arg1263_409);
							   }
							   list1260_407 = MAKE_PAIR(string1428_module_pragma, arg1262_408);
							}
							warning___error(list1260_407);
						     }
						  }
					     }
					  }
				       }
				     else
				       {
					tag_122_225_386:
					  internal_error_43_tools_error(string1428_module_pragma, string1429_module_pragma, pragma_380);
				       }
				  }
				else
				  {
				     goto tag_122_225_386;
				  }
			     }
			   else
			     {
				goto tag_122_225_386;
			     }
			}
		      else
			{
			   goto tag_122_225_386;
			}
		   }
		 else
		   {
		      goto tag_122_225_386;
		   }
	      }
	   }
	   {
	      obj_t l1193_911;
	      l1193_911 = CDR(l1193_377);
	      l1193_377 = l1193_911;
	      goto lname1194_378;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   _pragma_list__157_module_pragma = BNIL;
   return CNST_TABLE_REF(((long) 3));
}


/* _pragma-finalizer */ obj_t 
_pragma_finalizer_19_module_pragma(obj_t env_779)
{
   return pragma_finalizer_170_module_pragma();
}


/* set-pragma-properties! */ bool_t 
set_pragma_properties__114_module_pragma(obj_t global_5, obj_t prop__131_6, obj_t clause_7)
{
   {
      obj_t l1195_425;
      l1195_425 = prop__131_6;
    lname1196_426:
      if (PAIRP(l1195_425))
	{
	   set_pragma_property__180_module_pragma(global_5, CAR(l1195_425), clause_7);
	   {
	      obj_t l1195_919;
	      l1195_919 = CDR(l1195_425);
	      l1195_425 = l1195_919;
	      goto lname1196_426;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* set-pragma-property! */ obj_t 
set_pragma_property__180_module_pragma(obj_t global_8, obj_t prop_9, obj_t clause_10)
{
   {
      obj_t key_431;
      obj_t value_432;
      if (SYMBOLP(prop_9))
	{
	   {
	      bool_t test_923;
	      {
		 obj_t aux_924;
		 aux_924 = CNST_TABLE_REF(((long) 4));
		 test_923 = (prop_9 == aux_924);
	      }
	      if (test_923)
		{
		   value_t value_449;
		   {
		      global_t obj_724;
		      obj_724 = (global_t) (global_8);
		      value_449 = (((global_t) CREF(obj_724))->value);
		   }
		   {
		      bool_t test1297_450;
		      test1297_450 = is_a__118___object((obj_t) (value_449), fun_ast_var);
		      if (test1297_450)
			{
			   fun_t obj_726;
			   obj_t val1116_727;
			   obj_726 = (fun_t) (value_449);
			   val1116_727 = BFALSE;
			   return ((((fun_t) CREF(obj_726))->side_effect__165) = ((obj_t) val1116_727), BUNSPEC);
			}
		      else
			{
			   obj_t list1301_454;
			   list1301_454 = MAKE_PAIR(BNIL, BNIL);
			   return user_error_151_tools_error(string1430_module_pragma, string1431_module_pragma, prop_9, list1301_454);
			}
		   }
		}
	      else
		{
		   bool_t test_936;
		   {
		      obj_t aux_937;
		      aux_937 = CNST_TABLE_REF(((long) 5));
		      test_936 = (prop_9 == aux_937);
		   }
		   if (test_936)
		     {
			value_t value_457;
			{
			   global_t obj_730;
			   obj_730 = (global_t) (global_8);
			   value_457 = (((global_t) CREF(obj_730))->value);
			}
			{
			   bool_t test1304_458;
			   test1304_458 = is_a__118___object((obj_t) (value_457), fun_ast_var);
			   if (test1304_458)
			     {
				fun_t obj_732;
				obj_732 = (fun_t) (value_457);
				return ((((fun_t) CREF(obj_732))->top__138) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			     }
			   else
			     {
				obj_t list1310_462;
				list1310_462 = MAKE_PAIR(BNIL, BNIL);
				return user_error_151_tools_error(string1430_module_pragma, string1431_module_pragma, prop_9, list1310_462);
			     }
			}
		     }
		   else
		     {
			bool_t test_949;
			{
			   obj_t aux_950;
			   aux_950 = CNST_TABLE_REF(((long) 6));
			   test_949 = (prop_9 == aux_950);
			}
			if (test_949)
			  {
			     value_t value_465;
			     {
				global_t obj_736;
				obj_736 = (global_t) (global_8);
				value_465 = (((global_t) CREF(obj_736))->value);
			     }
			     {
				bool_t test1313_466;
				test1313_466 = is_a__118___object((obj_t) (value_465), sfun_ast_var);
				if (test1313_466)
				  {
				     obj_t arg1315_467;
				     {
					obj_t aux_958;
					{
					   sfun_t obj_738;
					   obj_738 = (sfun_t) (value_465);
					   aux_958 = (((sfun_t) CREF(obj_738))->property);
					}
					arg1315_467 = MAKE_PAIR(prop_9, aux_958);
				     }
				     {
					sfun_t obj_741;
					obj_741 = (sfun_t) (value_465);
					return ((((sfun_t) CREF(obj_741))->property) = ((obj_t) arg1315_467), BUNSPEC);
				     }
				  }
				else
				  {
				     obj_t list1323_472;
				     list1323_472 = MAKE_PAIR(BNIL, BNIL);
				     return user_error_151_tools_error(string1430_module_pragma, string1432_module_pragma, prop_9, list1323_472);
				  }
			     }
			  }
			else
			  {
			     obj_t list1329_477;
			     list1329_477 = MAKE_PAIR(BNIL, BNIL);
			     return user_error_151_tools_error(string1426_module_pragma, string1433_module_pragma, clause_10, list1329_477);
			  }
		     }
		}
	   }
	}
      else
	{
	   if (PAIRP(prop_9))
	     {
		obj_t car_160_190_438;
		obj_t cdr_161_14_439;
		car_160_190_438 = CAR(prop_9);
		cdr_161_14_439 = CDR(prop_9);
		if (SYMBOLP(car_160_190_438))
		  {
		     if (PAIRP(cdr_161_14_439))
		       {
			  obj_t car_166_211_442;
			  car_166_211_442 = CAR(cdr_161_14_439);
			  if (SYMBOLP(car_166_211_442))
			    {
			       bool_t test_979;
			       {
				  obj_t aux_980;
				  aux_980 = CDR(cdr_161_14_439);
				  test_979 = (aux_980 == BNIL);
			       }
			       if (test_979)
				 {
				    key_431 = car_160_190_438;
				    value_432 = car_166_211_442;
				    {
				       bool_t test_983;
				       {
					  obj_t aux_984;
					  aux_984 = CNST_TABLE_REF(((long) 7));
					  test_983 = (key_431 == aux_984);
				       }
				       if (test_983)
					 {
					    type_t type_484;
					    value_t value_485;
					    type_484 = use_type__231_type_env(value_432);
					    {
					       global_t obj_745;
					       obj_745 = (global_t) (global_8);
					       value_485 = (((global_t) CREF(obj_745))->value);
					    }
					    {
					       bool_t test1335_486;
					       test1335_486 = is_a__118___object((obj_t) (value_485), fun_ast_var);
					       if (test1335_486)
						 {
						    {
						       fun_t obj_747;
						       obj_t val1117_748;
						       obj_747 = (fun_t) (value_485);
						       val1117_748 = (obj_t) (type_484);
						       ((((fun_t) CREF(obj_747))->predicate_of_78) = ((obj_t) val1117_748), BUNSPEC);
						    }
						    remove_var_from__148_ast_remove(CNST_TABLE_REF(((long) 8)), (variable_t) (global_8));
						    {
						       fun_t obj_749;
						       obj_t val1116_750;
						       obj_749 = (fun_t) (value_485);
						       val1116_750 = BFALSE;
						       return ((((fun_t) CREF(obj_749))->side_effect__165) = ((obj_t) val1116_750), BUNSPEC);
						    }
						 }
					       else
						 {
						    obj_t list1343_491;
						    list1343_491 = MAKE_PAIR(BNIL, BNIL);
						    return user_error_151_tools_error(string1430_module_pragma, string1434_module_pragma, prop_9, list1343_491);
						 }
					    }
					 }
				       else
					 {
					    bool_t test_1003;
					    {
					       obj_t aux_1004;
					       aux_1004 = CNST_TABLE_REF(((long) 9));
					       test_1003 = (key_431 == aux_1004);
					    }
					    if (test_1003)
					      {
						 obj_t stack_alloc_52_494;
						 {
						    obj_t list1368_511;
						    {
						       obj_t aux_1007;
						       {
							  global_t obj_753;
							  obj_753 = (global_t) (global_8);
							  aux_1007 = (((global_t) CREF(obj_753))->module);
						       }
						       list1368_511 = MAKE_PAIR(aux_1007, BNIL);
						    }
						    stack_alloc_52_494 = find_global_223_ast_env(value_432, list1368_511);
						 }
						 {
						    bool_t test1346_495;
						    test1346_495 = is_a__118___object(stack_alloc_52_494, global_ast_var);
						    if (test1346_495)
						      {
							 bool_t test1347_496;
							 {
							    obj_t aux_1014;
							    {
							       value_t aux_1015;
							       {
								  global_t obj_755;
								  obj_755 = (global_t) (global_8);
								  aux_1015 = (((global_t) CREF(obj_755))->value);
							       }
							       aux_1014 = (obj_t) (aux_1015);
							    }
							    test1347_496 = is_a__118___object(aux_1014, fun_ast_var);
							 }
							 if (test1347_496)
							   {
							      if (CBOOL(_optim_stack___57_engine_param))
								{
								   remove_var_from__148_ast_remove(CNST_TABLE_REF(((long) 10)), (variable_t) (stack_alloc_52_494));
								}
							      else
								{
								   BUNSPEC;
								}
							      {
								 fun_t obj_758;
								 {
								    value_t aux_1026;
								    {
								       global_t obj_757;
								       obj_757 = (global_t) (global_8);
								       aux_1026 = (((global_t) CREF(obj_757))->value);
								    }
								    obj_758 = (fun_t) (aux_1026);
								 }
								 return ((((fun_t) CREF(obj_758))->stack_allocator_172) = ((obj_t) stack_alloc_52_494), BUNSPEC);
							      }
							   }
							 else
							   {
							      {
								 obj_t list1354_502;
								 list1354_502 = MAKE_PAIR(BNIL, BNIL);
								 return user_error_151_tools_error(string1430_module_pragma, string1435_module_pragma, prop_9, list1354_502);
							      }
							   }
						      }
						    else
						      {
							 {
							    obj_t list1364_508;
							    list1364_508 = MAKE_PAIR(BNIL, BNIL);
							    return user_error_151_tools_error(string1430_module_pragma, string1436_module_pragma, prop_9, list1364_508);
							 }
						      }
						 }
					      }
					    else
					      {
						 obj_t list1374_516;
						 list1374_516 = MAKE_PAIR(BNIL, BNIL);
						 return user_error_151_tools_error(string1426_module_pragma, string1433_module_pragma, prop_9, list1374_516);
					      }
					 }
				    }
				 }
			       else
				 {
				  tag_152_149_434:
				    {
				       obj_t arg1384_522;
				       if (PAIRP(prop_9))
					 {
					    arg1384_522 = prop_9;
					 }
				       else
					 {
					    arg1384_522 = clause_10;
					 }
				       {
					  obj_t list1386_524;
					  list1386_524 = MAKE_PAIR(BNIL, BNIL);
					  return user_error_151_tools_error(string1426_module_pragma, string1433_module_pragma, arg1384_522, list1386_524);
				       }
				    }
				 }
			    }
			  else
			    {
			       goto tag_152_149_434;
			    }
		       }
		     else
		       {
			  goto tag_152_149_434;
		       }
		  }
		else
		  {
		     goto tag_152_149_434;
		  }
	     }
	   else
	     {
		goto tag_152_149_434;
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_module_pragma()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_pragma()
{
   module_initialization_70_module_module(((long) 0), "MODULE_PRAGMA");
   module_initialization_70_tools_error(((long) 0), "MODULE_PRAGMA");
   module_initialization_70_type_type(((long) 0), "MODULE_PRAGMA");
   module_initialization_70_engine_param(((long) 0), "MODULE_PRAGMA");
   module_initialization_70_ast_var(((long) 0), "MODULE_PRAGMA");
   module_initialization_70_ast_env(((long) 0), "MODULE_PRAGMA");
   module_initialization_70_ast_remove(((long) 0), "MODULE_PRAGMA");
   return module_initialization_70_type_env(((long) 0), "MODULE_PRAGMA");
}
