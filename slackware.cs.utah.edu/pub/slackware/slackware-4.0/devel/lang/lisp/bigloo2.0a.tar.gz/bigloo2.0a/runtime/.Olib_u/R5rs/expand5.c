/*===========================================================================*/
/*   (R5rs/expand5.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t denotation_of_if_234___r5_syntax_syntaxenv;
static obj_t m_letrec_syntax_194___r5_syntax_expand(obj_t, obj_t);
extern obj_t desugar_definitions_207___r5_syntax_expand(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t set_1_241___r5_syntax_prefs;
extern obj_t denotation_of_letrec_syntax_163___r5_syntax_syntaxenv;
extern obj_t identifier_name_131___r5_syntax_syntaxenv(obj_t);
extern obj_t undefined1___r5_syntax_prefs;
extern obj_t exitd_top;
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t syntactic_extend_18___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
obj_t m_quit_227___r5_syntax_expand = BUNSPEC;
static obj_t toplevel_init_63___r5_syntax_expand();
extern obj_t m_strip_59___r5_syntax_syntaxenv(obj_t);
extern obj_t syntactic_alias_206___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
static obj_t desugar_definition_216___r5_syntax_expand(obj_t, obj_t, obj_t);
extern obj_t lambda1___r5_syntax_prefs;
extern obj_t lambda0___r5_syntax_syntaxenv;
extern obj_t global_syntactic_environment_190___r5_syntax_syntaxenv;
extern obj_t m_bug_88___r5_syntax_misc(obj_t, obj_t);
extern obj_t rename_vars_186___r5_syntax_syntaxenv(obj_t);
extern obj_t m_compile_transformer_spec_209___r5_syntax_syntaxrules(obj_t, obj_t);
extern obj_t internal_expand_syntax_49___r5_syntax_expand(obj_t);
static obj_t m_quote_31___r5_syntax_expand(obj_t);
static obj_t _internal_expand_syntax_242___r5_syntax_expand(obj_t, obj_t);
extern obj_t ident__144___r5_syntax_syntaxenv(obj_t);
extern obj_t m_transcribe_36___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t arg1762___r5_syntax_expand(obj_t, obj_t, obj_t);
static obj_t arg1749___r5_syntax_expand(obj_t, obj_t);
extern obj_t define1___r5_syntax_prefs;
extern obj_t every1__242___r5_syntax_misc(obj_t, obj_t);
static obj_t arg1680___r5_syntax_expand(obj_t, obj_t);
static obj_t redefinition___r5_syntax_expand(obj_t);
static obj_t m_begin_21___r5_syntax_expand(obj_t, obj_t);
static obj_t loop___r5_syntax_expand(obj_t, obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
static obj_t lambda1114___r5_syntax_expand(obj_t, obj_t);
static obj_t lambda1099___r5_syntax_expand(obj_t, obj_t);
static obj_t m_if_22___r5_syntax_expand(obj_t, obj_t);
extern obj_t begin1___r5_syntax_prefs;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t denotation_class_62___r5_syntax_syntaxenv;
extern obj_t syntactic_bind_globally__231___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t quote1___r5_syntax_prefs;
static obj_t handling_function1115___r5_syntax_expand(obj_t);
extern obj_t syntactic_rename_48___r5_syntax_syntaxenv(obj_t, obj_t);
static obj_t _desugar_definitions_232___r5_syntax_expand(obj_t, obj_t, obj_t);
static obj_t arg1339___r5_syntax_expand(obj_t, obj_t, obj_t);
static obj_t m_lambda_201___r5_syntax_expand(obj_t, obj_t);
extern obj_t denotation_of_set__245___r5_syntax_syntaxenv;
static obj_t m_define_syntax_61___r5_syntax_expand(obj_t, obj_t);
extern obj_t module_initialization_70___r5_syntax_expand(long, char *);
extern obj_t denotation_of_define_syntax_255___r5_syntax_syntaxenv;
static obj_t m_expand_161___r5_syntax_expand(obj_t, obj_t);
extern obj_t rename_formals_228___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t safe_length_235___r5_syntax_misc(obj_t);
extern obj_t denotation_of_quote_40___r5_syntax_syntaxenv;
extern obj_t make_null_terminated_173___r5_syntax_misc(obj_t);
static obj_t m_set_184___r5_syntax_expand(obj_t, obj_t);
extern bool_t positive__57___r4_numbers_6_5(obj_t);
extern obj_t syntactic_lookup_76___r5_syntax_syntaxenv(obj_t, obj_t);
static obj_t finalize_body_219___r5_syntax_expand(obj_t, obj_t, obj_t);
extern long list_length(obj_t);
extern obj_t denotation_of_let_syntax_71___r5_syntax_syntaxenv;
extern obj_t denotation_of_lambda_93___r5_syntax_syntaxenv;
extern obj_t syntactic_assign__111___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
extern obj_t denotation_of_define_166___r5_syntax_syntaxenv;
obj_t define_syntax_scope_173___r5_syntax_expand = BUNSPEC;
extern obj_t m_error_176___r5_syntax_misc(obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t m_body_102___r5_syntax_expand(obj_t, obj_t);
extern obj_t if1___r5_syntax_prefs;
extern obj_t denotation_of_begin_249___r5_syntax_syntaxenv;
extern obj_t m_warn_132___r5_syntax_misc(obj_t, obj_t);
extern obj_t syntactic_copy_24___r5_syntax_syntaxenv(obj_t);
static obj_t symbol1948___r5_syntax_expand = BUNSPEC;
static obj_t symbol1947___r5_syntax_expand = BUNSPEC;
static obj_t symbol1939___r5_syntax_expand = BUNSPEC;
static obj_t symbol1940___r5_syntax_expand = BUNSPEC;
static obj_t symbol1938___r5_syntax_expand = BUNSPEC;
static obj_t symbol1937___r5_syntax_expand = BUNSPEC;
static obj_t symbol1928___r5_syntax_expand = BUNSPEC;
static obj_t symbol1926___r5_syntax_expand = BUNSPEC;
static obj_t symbol1923___r5_syntax_expand = BUNSPEC;
static obj_t symbol1917___r5_syntax_expand = BUNSPEC;
static obj_t symbol1916___r5_syntax_expand = BUNSPEC;
static obj_t symbol1913___r5_syntax_expand = BUNSPEC;
extern obj_t make_identifier_denotation_27___r5_syntax_syntaxenv(obj_t);
extern obj_t renaming_counter_100___r5_syntax_syntaxenv;
static obj_t m_atom_20___r5_syntax_expand(obj_t, obj_t);
static obj_t list1946___r5_syntax_expand = BUNSPEC;
static obj_t list1945___r5_syntax_expand = BUNSPEC;
static obj_t list1936___r5_syntax_expand = BUNSPEC;
static obj_t list1929___r5_syntax_expand = BUNSPEC;
static obj_t require_initialization_114___r5_syntax_expand = BUNSPEC;
static obj_t list1915___r5_syntax_expand = BUNSPEC;
extern obj_t standard_syntactic_environment_195___r5_syntax_syntaxenv;
static obj_t m_let_syntax_139___r5_syntax_expand(obj_t, obj_t);
static obj_t k___r5_syntax_expand(obj_t, obj_t);
static obj_t cnst_init_137___r5_syntax_expand();
static obj_t loop_1912___r5_syntax_expand(obj_t, obj_t);
static obj_t m_define_syntax1_27___r5_syntax_expand(obj_t, obj_t, obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( desugar_definitions_env_8___r5_syntax_expand, _desugar_definitions_232___r5_syntax_expand1954, _desugar_definitions_232___r5_syntax_expand, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1952___r5_syntax_expand, arg1749___r5_syntax_expand1955, arg1749___r5_syntax_expand, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1950___r5_syntax_expand, arg1680___r5_syntax_expand1956, arg1680___r5_syntax_expand, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1927___r5_syntax_expand, arg1762___r5_syntax_expand1957, arg1762___r5_syntax_expand, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1914___r5_syntax_expand, lambda1114___r5_syntax_expand1958, lambda1114___r5_syntax_expand, 0L, 1 );
DEFINE_STRING( string1951___r5_syntax_expand, string1951___r5_syntax_expand1959, "Malformed let-syntax", 20 );
DEFINE_STRING( string1949___r5_syntax_expand, string1949___r5_syntax_expand1960, "Weird scope", 11 );
DEFINE_STRING( string1944___r5_syntax_expand, string1944___r5_syntax_expand1961, "Malformed define-syntax", 23 );
DEFINE_STRING( string1943___r5_syntax_expand, string1943___r5_syntax_expand1962, "Malformed begin expression", 26 );
DEFINE_STRING( string1942___r5_syntax_expand, string1942___r5_syntax_expand1963, "Malformed assignment", 20 );
DEFINE_STRING( string1941___r5_syntax_expand, string1941___r5_syntax_expand1964, "Malformed if expression", 23 );
DEFINE_STRING( string1935___r5_syntax_expand, string1935___r5_syntax_expand1965, "Bug detected in m-body", 22 );
DEFINE_STRING( string1934___r5_syntax_expand, string1934___r5_syntax_expand1966, "Empty body", 10 );
DEFINE_STRING( string1933___r5_syntax_expand, string1933___r5_syntax_expand1967, "Malformed lambda expression", 27 );
DEFINE_STRING( string1932___r5_syntax_expand, string1932___r5_syntax_expand1968, "Malformed quoted constant", 25 );
DEFINE_STRING( string1931___r5_syntax_expand, string1931___r5_syntax_expand1969, "Bug detected by m-atom", 22 );
DEFINE_STRING( string1930___r5_syntax_expand, string1930___r5_syntax_expand1970, "Syntactic keyword used as a variable", 36 );
DEFINE_STRING( string1925___r5_syntax_expand, string1925___r5_syntax_expand1971, "Bug detected in m-expand", 24 );
DEFINE_STRING( string1924___r5_syntax_expand, string1924___r5_syntax_expand1972, "Definition out of context", 25 );
DEFINE_STRING( string1922___r5_syntax_expand, string1922___r5_syntax_expand1973, "Malformed variable or keyword", 29 );
DEFINE_STRING( string1921___r5_syntax_expand, string1921___r5_syntax_expand1974, "Redefining keyword", 18 );
DEFINE_STRING( string1919___r5_syntax_expand, string1919___r5_syntax_expand1975, "Too many arguments passed to define-syntax-scope", 48 );
DEFINE_STRING( string1920___r5_syntax_expand, string1920___r5_syntax_expand1976, "Malformed definition", 20 );
DEFINE_STRING( string1918___r5_syntax_expand, string1918___r5_syntax_expand1977, "Unrecognized argument to define-syntax-scope", 44 );
DEFINE_EXPORT_PROCEDURE( internal_expand_syntax_env_110___r5_syntax_expand, _internal_expand_syntax_242___r5_syntax_expand1978, _internal_expand_syntax_242___r5_syntax_expand, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r5_syntax_expand(long checksum_2593, char * from_2594)
{
if(CBOOL(require_initialization_114___r5_syntax_expand)){
require_initialization_114___r5_syntax_expand = BBOOL(((bool_t)0));
cnst_init_137___r5_syntax_expand();
toplevel_init_63___r5_syntax_expand();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r5_syntax_expand()
{
symbol1913___r5_syntax_expand = string_to_symbol("LETREC");
symbol1916___r5_syntax_expand = string_to_symbol("LETREC*");
symbol1917___r5_syntax_expand = string_to_symbol("LET*");
{
obj_t aux_2603;
{
obj_t aux_2604;
aux_2604 = MAKE_PAIR(symbol1917___r5_syntax_expand, BNIL);
aux_2603 = MAKE_PAIR(symbol1916___r5_syntax_expand, aux_2604);
}
list1915___r5_syntax_expand = MAKE_PAIR(symbol1913___r5_syntax_expand, aux_2603);
}
symbol1923___r5_syntax_expand = string_to_symbol("SPECIAL");
symbol1926___r5_syntax_expand = string_to_symbol("MACRO");
symbol1928___r5_syntax_expand = string_to_symbol("IDENTIFIER");
{
obj_t aux_2611;
aux_2611 = MAKE_PAIR(symbol1926___r5_syntax_expand, BNIL);
list1929___r5_syntax_expand = MAKE_PAIR(symbol1923___r5_syntax_expand, aux_2611);
}
symbol1937___r5_syntax_expand = string_to_symbol("QUOTE");
symbol1938___r5_syntax_expand = string_to_symbol("LAMBDA");
symbol1939___r5_syntax_expand = string_to_symbol("SET!");
{
obj_t aux_2617;
{
obj_t aux_2618;
aux_2618 = MAKE_PAIR(symbol1939___r5_syntax_expand, BNIL);
aux_2617 = MAKE_PAIR(symbol1938___r5_syntax_expand, aux_2618);
}
list1936___r5_syntax_expand = MAKE_PAIR(symbol1937___r5_syntax_expand, aux_2617);
}
symbol1940___r5_syntax_expand = string_to_symbol("UNSPECIFIED");
symbol1947___r5_syntax_expand = string_to_symbol("FAKE");
symbol1948___r5_syntax_expand = string_to_symbol("DENOTATION");
{
obj_t aux_2625;
aux_2625 = MAKE_PAIR(symbol1948___r5_syntax_expand, BNIL);
list1946___r5_syntax_expand = MAKE_PAIR(symbol1947___r5_syntax_expand, aux_2625);
}
return (list1945___r5_syntax_expand = MAKE_PAIR(list1946___r5_syntax_expand, BNIL),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___r5_syntax_expand()
{
{
obj_t flag_354;
flag_354 = MAKE_CELL(symbol1913___r5_syntax_expand);
{
obj_t lambda1099_2550;
lambda1099_2550 = make_va_procedure(lambda1099___r5_syntax_expand, ((long)-1), ((long)1));
PROCEDURE_SET(lambda1099_2550, ((long)0), flag_354);
define_syntax_scope_173___r5_syntax_expand = lambda1099_2550;
}
}
{
obj_t lambda1114_2549;
lambda1114_2549 = proc1914___r5_syntax_expand;
return (m_quit_227___r5_syntax_expand = lambda1114_2549,
BUNSPEC);
}
}


/* lambda1114 */obj_t lambda1114___r5_syntax_expand(obj_t env_2551, obj_t v_2552)
{
{
obj_t v_2587;
v_2587 = v_2552;
return v_2587;
}
}


/* lambda1099 */obj_t lambda1099___r5_syntax_expand(obj_t env_2553, obj_t args_2555)
{
{
obj_t flag_2554;
flag_2554 = PROCEDURE_REF(env_2553, ((long)0));
{
obj_t args_355;
args_355 = args_2555;
if(NULLP(args_355)){
return CELL_REF(flag_2554);
}
 else {
bool_t test_2634;
{
obj_t aux_2635;
aux_2635 = CDR(args_355);
test_2634 = NULLP(aux_2635);
}
if(test_2634){
bool_t test_2638;
{
obj_t aux_2639;
aux_2639 = memq___r4_pairs_and_lists_6_3(CAR(args_355), list1915___r5_syntax_expand);
test_2638 = CBOOL(aux_2639);
}
if(test_2638){
return CELL_SET(flag_2554, CAR(args_355));
}
 else {
{
obj_t list1105_362;
{
obj_t aux_2644;
aux_2644 = CAR(args_355);
list1105_362 = MAKE_PAIR(aux_2644, BNIL);
}
return m_warn_132___r5_syntax_misc(string1918___r5_syntax_expand, list1105_362);
}
}
}
 else {
{
obj_t runner1112_369;
{
obj_t list1109_366;
list1109_366 = MAKE_PAIR(args_355, BNIL);
runner1112_369 = cons__138___r4_pairs_and_lists_6_3(string1919___r5_syntax_expand, list1109_366);
}
{
obj_t aux1111_368;
{
obj_t pair_1239;
pair_1239 = runner1112_369;
aux1111_368 = CAR(pair_1239);
}
{
obj_t pair_1240;
pair_1240 = runner1112_369;
runner1112_369 = CDR(pair_1240);
}
return m_warn_132___r5_syntax_misc(aux1111_368, runner1112_369);
}
}
}
}
}
}
}


/* internal-expand-syntax */obj_t internal_expand_syntax_49___r5_syntax_expand(obj_t def_or_exp_158_1)
{
return handling_function1115___r5_syntax_expand(def_or_exp_158_1);
}


/* handling_function1115 */obj_t handling_function1115___r5_syntax_expand(obj_t def_or_exp_158_2586)
{
jmp_buf jmpbuf;
obj_t an_exit1002_374;
if( SET_EXIT(an_exit1002_374) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1002_374 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1002_374, ((bool_t)1));
{
obj_t an_exitd1003_375;
an_exitd1003_375 = exitd_top;
{
obj_t k_2557;
k_2557 = make_fx_procedure(k___r5_syntax_expand, ((long)1), ((long)1));
PROCEDURE_SET(k_2557, ((long)0), an_exitd1003_375);
{
obj_t res1005_378;
m_quit_227___r5_syntax_expand = k_2557;
renaming_counter_100___r5_syntax_syntaxenv = BINT(((long)0));
res1005_378 = desugar_definitions_207___r5_syntax_expand(def_or_exp_158_2586, global_syntactic_environment_190___r5_syntax_syntaxenv);
POP_EXIT();
return res1005_378;
}
}
}
}
}
}


/* _internal-expand-syntax */obj_t _internal_expand_syntax_242___r5_syntax_expand(obj_t env_2558, obj_t def_or_exp_158_2559)
{
{
obj_t def_or_exp_158_2588;
def_or_exp_158_2588 = def_or_exp_158_2559;
return handling_function1115___r5_syntax_expand(def_or_exp_158_2588);
}
}


/* k */obj_t k___r5_syntax_expand(obj_t env_2560, obj_t val1004_2562)
{
{
obj_t an_exitd1003_2561;
an_exitd1003_2561 = PROCEDURE_REF(env_2560, ((long)0));
{
obj_t val1004_376;
val1004_376 = val1004_2562;
return unwind_until__178___bexit(an_exitd1003_2561, val1004_376);
}
}
}


/* desugar-definitions */obj_t desugar_definitions_207___r5_syntax_expand(obj_t exp_2, obj_t env_3)
{
{
obj_t exp_385;
obj_t rest_386;
obj_t first_387;
obj_t exp_439;
obj_t env_440;
obj_t exp_489;
obj_t rest_490;
exp_385 = exp_2;
rest_386 = BNIL;
first_387 = BNIL;
define_loop_151_539:
{
bool_t test1119_389;
if(PAIRP(exp_385)){
bool_t test1158_435;
{
obj_t arg1161_437;
arg1161_437 = syntactic_lookup_76___r5_syntax_syntaxenv(env_3, CAR(exp_385));
{
obj_t obj2_1244;
obj2_1244 = denotation_of_begin_249___r5_syntax_syntaxenv;
test1158_435 = (arg1161_437==obj2_1244);
}
}
if(test1158_435){
obj_t aux_2671;
aux_2671 = CDR(exp_385);
test1119_389 = PAIRP(aux_2671);
}
 else {
test1119_389 = ((bool_t)0);
}
}
 else {
test1119_389 = ((bool_t)0);
}
if(test1119_389){
{
obj_t rest_2679;
obj_t exp_2675;
{
obj_t aux_2676;
aux_2676 = CDR(exp_385);
exp_2675 = CAR(aux_2676);
}
{
obj_t aux_2680;
{
obj_t aux_2681;
aux_2681 = CDR(exp_385);
aux_2680 = CDR(aux_2681);
}
rest_2679 = append_2_18___r4_pairs_and_lists_6_3(aux_2680, rest_386);
}
rest_386 = rest_2679;
exp_385 = exp_2675;
goto define_loop_151_539;
}
}
 else {
bool_t test1123_393;
if(PAIRP(exp_385)){
obj_t arg1155_432;
arg1155_432 = syntactic_lookup_76___r5_syntax_syntaxenv(env_3, CAR(exp_385));
{
obj_t obj2_1258;
obj2_1258 = denotation_of_define_166___r5_syntax_syntaxenv;
test1123_393 = (arg1155_432==obj2_1258);
}
}
 else {
test1123_393 = ((bool_t)0);
}
if(test1123_393){
{
obj_t exp_394;
exp_439 = exp_385;
env_440 = env_3;
desugar_define_89_538:
{
bool_t test_2691;
{
obj_t aux_2692;
aux_2692 = CDR(exp_439);
test_2691 = NULLP(aux_2692);
}
if(test_2691){
{
obj_t list1165_443;
list1165_443 = MAKE_PAIR(exp_439, BNIL);
exp_394 = m_error_176___r5_syntax_misc(string1920___r5_syntax_expand, list1165_443);
}
}
 else {
bool_t test_2697;
{
obj_t aux_2698;
{
obj_t aux_2699;
aux_2699 = CDR(exp_439);
aux_2698 = CDR(aux_2699);
}
test_2697 = NULLP(aux_2698);
}
if(test_2697){
{
obj_t id_446;
{
obj_t aux_2703;
aux_2703 = CDR(exp_439);
id_446 = CAR(aux_2703);
}
redefinition___r5_syntax_expand(id_446);
{
obj_t arg1168_447;
arg1168_447 = make_identifier_denotation_27___r5_syntax_syntaxenv(id_446);
syntactic_bind_globally__231___r5_syntax_syntaxenv(id_446, arg1168_447);
}
{
obj_t list1169_448;
{
obj_t arg1170_449;
{
obj_t arg1171_450;
arg1171_450 = MAKE_PAIR(undefined1___r5_syntax_prefs, BNIL);
arg1170_449 = MAKE_PAIR(id_446, arg1171_450);
}
list1169_448 = MAKE_PAIR(define1___r5_syntax_prefs, arg1170_449);
}
exp_394 = list1169_448;
}
}
}
 else {
bool_t test_2712;
{
obj_t aux_2713;
{
obj_t aux_2714;
aux_2714 = CDR(exp_439);
aux_2713 = CAR(aux_2714);
}
test_2712 = PAIRP(aux_2713);
}
if(test_2712){
{
obj_t arg1174_453;
{
obj_t arg1175_454;
obj_t arg1176_455;
{
obj_t aux_2718;
{
obj_t aux_2719;
aux_2719 = CDR(exp_439);
aux_2718 = CAR(aux_2719);
}
arg1175_454 = CAR(aux_2718);
}
{
obj_t arg1183_462;
obj_t arg1184_463;
{
obj_t aux_2723;
{
obj_t aux_2724;
aux_2724 = CDR(exp_439);
aux_2723 = CAR(aux_2724);
}
arg1183_462 = CDR(aux_2723);
}
{
obj_t arg1189_468;
obj_t arg1190_469;
{
obj_t aux_2728;
aux_2728 = CDR(exp_439);
arg1189_468 = CDR(aux_2728);
}
arg1190_469 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1184_463 = append_2_18___r4_pairs_and_lists_6_3(arg1189_468, arg1190_469);
}
{
obj_t list1185_464;
{
obj_t arg1186_465;
arg1186_465 = MAKE_PAIR(arg1184_463, BNIL);
list1185_464 = MAKE_PAIR(arg1183_462, arg1186_465);
}
arg1176_455 = cons__138___r4_pairs_and_lists_6_3(lambda0___r5_syntax_syntaxenv, list1185_464);
}
}
{
obj_t list1178_457;
{
obj_t arg1179_458;
{
obj_t arg1180_459;
arg1180_459 = MAKE_PAIR(BNIL, BNIL);
arg1179_458 = MAKE_PAIR(arg1176_455, arg1180_459);
}
list1178_457 = MAKE_PAIR(arg1175_454, arg1179_458);
}
arg1174_453 = cons__138___r4_pairs_and_lists_6_3(define1___r5_syntax_prefs, list1178_457);
}
}
{
obj_t exp_2740;
exp_2740 = arg1174_453;
exp_439 = exp_2740;
goto desugar_define_89_538;
}
}
}
 else {
bool_t test_2741;
{
obj_t aux_2742;
{
long aux_2743;
aux_2743 = list_length(exp_439);
aux_2742 = BINT(aux_2743);
}
test_2741 = _2__206___r4_numbers_6_5(aux_2742, BINT(((long)3)));
}
if(test_2741){
{
obj_t list1194_473;
list1194_473 = MAKE_PAIR(exp_439, BNIL);
exp_394 = m_error_176___r5_syntax_misc(string1920___r5_syntax_expand, list1194_473);
}
}
 else {
{
obj_t id_475;
{
obj_t aux_2750;
aux_2750 = CDR(exp_439);
id_475 = CAR(aux_2750);
}
redefinition___r5_syntax_expand(id_475);
{
obj_t arg1196_476;
arg1196_476 = make_identifier_denotation_27___r5_syntax_syntaxenv(id_475);
syntactic_bind_globally__231___r5_syntax_syntaxenv(id_475, arg1196_476);
}
{
obj_t arg1197_477;
{
obj_t aux_2756;
{
obj_t aux_2757;
{
obj_t aux_2758;
aux_2758 = CDR(exp_439);
aux_2757 = CDR(aux_2758);
}
aux_2756 = CAR(aux_2757);
}
arg1197_477 = m_expand_161___r5_syntax_expand(aux_2756, env_440);
}
{
obj_t list1200_479;
{
obj_t arg1201_480;
{
obj_t arg1202_481;
arg1202_481 = MAKE_PAIR(BNIL, BNIL);
arg1201_480 = MAKE_PAIR(arg1197_477, arg1202_481);
}
list1200_479 = MAKE_PAIR(id_475, arg1201_480);
}
exp_394 = cons__138___r4_pairs_and_lists_6_3(define1___r5_syntax_prefs, list1200_479);
}
}
}
}
}
}
}
}
{
bool_t test_2767;
if(NULLP(first_387)){
test_2767 = NULLP(rest_386);
}
 else {
test_2767 = ((bool_t)0);
}
if(test_2767){
return exp_394;
}
 else {
if(NULLP(rest_386)){
{
obj_t arg1126_397;
{
obj_t arg1127_398;
arg1127_398 = MAKE_PAIR(exp_394, first_387);
arg1126_397 = reverse___r4_pairs_and_lists_6_3(arg1127_398);
}
{
obj_t obj1_1264;
obj1_1264 = begin1___r5_syntax_prefs;
return MAKE_PAIR(obj1_1264, arg1126_397);
}
}
}
 else {
{
obj_t arg1128_399;
obj_t arg1129_400;
obj_t arg1130_401;
arg1128_399 = CAR(rest_386);
arg1129_400 = CDR(rest_386);
arg1130_401 = MAKE_PAIR(exp_394, first_387);
{
obj_t first_2781;
obj_t rest_2780;
obj_t exp_2779;
exp_2779 = arg1128_399;
rest_2780 = arg1129_400;
first_2781 = arg1130_401;
first_387 = first_2781;
rest_386 = rest_2780;
exp_385 = exp_2779;
goto define_loop_151_539;
}
}
}
}
}
}
}
 else {
bool_t test1132_403;
if(PAIRP(exp_385)){
bool_t test1151_428;
{
obj_t arg1152_429;
arg1152_429 = syntactic_lookup_76___r5_syntax_syntaxenv(env_3, CAR(exp_385));
{
obj_t obj2_1273;
obj2_1273 = denotation_of_define_syntax_255___r5_syntax_syntaxenv;
test1151_428 = (arg1152_429==obj2_1273);
}
}
if(test1151_428){
test1132_403 = NULLP(first_387);
}
 else {
test1132_403 = ((bool_t)0);
}
}
 else {
test1132_403 = ((bool_t)0);
}
if(test1132_403){
exp_489 = exp_385;
rest_490 = rest_386;
define_syntax_loop_39_537:
{
bool_t test1212_492;
if(PAIRP(exp_489)){
bool_t test1242_523;
{
obj_t arg1244_525;
arg1244_525 = syntactic_lookup_76___r5_syntax_syntaxenv(env_3, CAR(exp_489));
{
obj_t obj2_1386;
obj2_1386 = denotation_of_begin_249___r5_syntax_syntaxenv;
test1242_523 = (arg1244_525==obj2_1386);
}
}
if(test1242_523){
obj_t aux_2796;
aux_2796 = CDR(exp_489);
test1212_492 = PAIRP(aux_2796);
}
 else {
test1212_492 = ((bool_t)0);
}
}
 else {
test1212_492 = ((bool_t)0);
}
if(test1212_492){
{
obj_t rest_2804;
obj_t exp_2800;
{
obj_t aux_2801;
aux_2801 = CDR(exp_489);
exp_2800 = CAR(aux_2801);
}
{
obj_t aux_2805;
{
obj_t aux_2806;
aux_2806 = CDR(exp_489);
aux_2805 = CDR(aux_2806);
}
rest_2804 = append_2_18___r4_pairs_and_lists_6_3(aux_2805, rest_490);
}
rest_490 = rest_2804;
exp_489 = exp_2800;
goto define_syntax_loop_39_537;
}
}
 else {
bool_t test1217_496;
if(PAIRP(exp_489)){
obj_t arg1238_520;
arg1238_520 = syntactic_lookup_76___r5_syntax_syntaxenv(env_3, CAR(exp_489));
{
obj_t obj2_1400;
obj2_1400 = denotation_of_define_syntax_255___r5_syntax_syntaxenv;
test1217_496 = (arg1238_520==obj2_1400);
}
}
 else {
test1217_496 = ((bool_t)0);
}
if(test1217_496){
{
bool_t test_2816;
{
obj_t aux_2817;
aux_2817 = CDR(exp_489);
test_2816 = PAIRP(aux_2817);
}
if(test_2816){
obj_t aux_2820;
{
obj_t aux_2821;
aux_2821 = CDR(exp_489);
aux_2820 = CAR(aux_2821);
}
redefinition___r5_syntax_expand(aux_2820);
}
 else {
BUNSPEC;
}
}
if(NULLP(rest_490)){
return m_define_syntax_61___r5_syntax_expand(exp_489, env_3);
}
 else {
m_define_syntax_61___r5_syntax_expand(exp_489, env_3);
{
obj_t rest_2831;
obj_t exp_2829;
exp_2829 = CAR(rest_490);
rest_2831 = CDR(rest_490);
rest_490 = rest_2831;
exp_489 = exp_2829;
goto define_syntax_loop_39_537;
}
}
}
 else {
if(NULLP(rest_490)){
return m_expand_161___r5_syntax_expand(exp_489, env_3);
}
 else {
{
obj_t arg1226_504;
{
obj_t l1011_505;
l1011_505 = MAKE_PAIR(exp_489, rest_490);
{
obj_t head1013_507;
head1013_507 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1011_1417;
obj_t tail1014_1418;
l1011_1417 = l1011_505;
tail1014_1418 = head1013_507;
lname1012_1416:
if(NULLP(l1011_1417)){
arg1226_504 = CDR(head1013_507);
}
 else {
obj_t newtail1015_1426;
{
obj_t arg1232_1427;
arg1232_1427 = m_expand_161___r5_syntax_expand(CAR(l1011_1417), env_3);
newtail1015_1426 = MAKE_PAIR(arg1232_1427, BNIL);
}
SET_CDR(tail1014_1418, newtail1015_1426);
{
obj_t tail1014_2847;
obj_t l1011_2845;
l1011_2845 = CDR(l1011_1417);
tail1014_2847 = newtail1015_1426;
tail1014_1418 = tail1014_2847;
l1011_1417 = l1011_2845;
goto lname1012_1416;
}
}
}
}
}
{
obj_t obj1_1469;
obj1_1469 = begin1___r5_syntax_prefs;
return MAKE_PAIR(obj1_1469, arg1226_504);
}
}
}
}
}
}
}
 else {
bool_t test_2849;
if(NULLP(first_387)){
test_2849 = NULLP(rest_386);
}
 else {
test_2849 = ((bool_t)0);
}
if(test_2849){
return m_expand_161___r5_syntax_expand(exp_385, env_3);
}
 else {
if(NULLP(rest_386)){
{
obj_t arg1135_406;
{
obj_t arg1136_407;
{
obj_t arg1137_408;
arg1137_408 = m_expand_161___r5_syntax_expand(exp_385, env_3);
arg1136_407 = MAKE_PAIR(arg1137_408, first_387);
}
arg1135_406 = reverse___r4_pairs_and_lists_6_3(arg1136_407);
}
{
obj_t obj1_1280;
obj1_1280 = begin1___r5_syntax_prefs;
return MAKE_PAIR(obj1_1280, arg1135_406);
}
}
}
 else {
{
obj_t arg1139_409;
{
obj_t arg1140_410;
obj_t arg1141_411;
arg1140_410 = reverse___r4_pairs_and_lists_6_3(first_387);
{
obj_t l1006_412;
l1006_412 = MAKE_PAIR(exp_385, rest_386);
{
obj_t head1008_414;
head1008_414 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1006_1288;
obj_t tail1009_1289;
l1006_1288 = l1006_412;
tail1009_1289 = head1008_414;
lname1007_1287:
if(NULLP(l1006_1288)){
arg1141_411 = CDR(head1008_414);
}
 else {
obj_t newtail1010_1297;
{
obj_t arg1145_1298;
arg1145_1298 = m_expand_161___r5_syntax_expand(CAR(l1006_1288), env_3);
newtail1010_1297 = MAKE_PAIR(arg1145_1298, BNIL);
}
SET_CDR(tail1009_1289, newtail1010_1297);
{
obj_t tail1009_2872;
obj_t l1006_2870;
l1006_2870 = CDR(l1006_1288);
tail1009_2872 = newtail1010_1297;
tail1009_1289 = tail1009_2872;
l1006_1288 = l1006_2870;
goto lname1007_1287;
}
}
}
}
}
arg1139_409 = append_2_18___r4_pairs_and_lists_6_3(arg1140_410, arg1141_411);
}
{
obj_t obj1_1340;
obj1_1340 = begin1___r5_syntax_prefs;
return MAKE_PAIR(obj1_1340, arg1139_409);
}
}
}
}
}
}
}
}
}
}


/* redefinition */obj_t redefinition___r5_syntax_expand(obj_t id_527)
{
if(SYMBOLP(id_527)){
bool_t test1248_530;
{
obj_t arg1251_533;
arg1251_533 = syntactic_lookup_76___r5_syntax_syntaxenv(global_syntactic_environment_190___r5_syntax_syntaxenv, id_527);
{
obj_t aux_2878;
aux_2878 = ident__144___r5_syntax_syntaxenv(arg1251_533);
test1248_530 = CBOOL(aux_2878);
}
}
if(test1248_530){
return BUNSPEC;
}
 else {
obj_t list1249_531;
list1249_531 = MAKE_PAIR(id_527, BNIL);
return m_warn_132___r5_syntax_misc(string1921___r5_syntax_expand, list1249_531);
}
}
 else {
obj_t list1252_534;
list1252_534 = MAKE_PAIR(id_527, BNIL);
return m_error_176___r5_syntax_misc(string1922___r5_syntax_expand, list1252_534);
}
}


/* _desugar-definitions */obj_t _desugar_definitions_232___r5_syntax_expand(obj_t env_2563, obj_t exp_2564, obj_t env_2565)
{
return desugar_definitions_207___r5_syntax_expand(exp_2564, env_2565);
}


/* m-expand */obj_t m_expand_161___r5_syntax_expand(obj_t exp_4, obj_t env_5)
{
if(PAIRP(exp_4)){
obj_t keyword_541;
keyword_541 = syntactic_lookup_76___r5_syntax_syntaxenv(env_5, CAR(exp_4));
{
obj_t case_value_58_542;
case_value_58_542 = PROCEDURE_ENTRY(denotation_class_62___r5_syntax_syntaxenv)(denotation_class_62___r5_syntax_syntaxenv, keyword_541, BEOA);
if((case_value_58_542==symbol1923___r5_syntax_expand)){
bool_t test1256_544;
{
obj_t obj2_1477;
obj2_1477 = denotation_of_quote_40___r5_syntax_syntaxenv;
test1256_544 = (keyword_541==obj2_1477);
}
if(test1256_544){
return m_quote_31___r5_syntax_expand(exp_4);
}
 else {
bool_t test1257_545;
{
obj_t obj2_1479;
obj2_1479 = denotation_of_lambda_93___r5_syntax_syntaxenv;
test1257_545 = (keyword_541==obj2_1479);
}
if(test1257_545){
return m_lambda_201___r5_syntax_expand(exp_4, env_5);
}
 else {
bool_t test1258_546;
{
obj_t obj2_1481;
obj2_1481 = denotation_of_if_234___r5_syntax_syntaxenv;
test1258_546 = (keyword_541==obj2_1481);
}
if(test1258_546){
return m_if_22___r5_syntax_expand(exp_4, env_5);
}
 else {
bool_t test1259_547;
{
obj_t obj2_1483;
obj2_1483 = denotation_of_set__245___r5_syntax_syntaxenv;
test1259_547 = (keyword_541==obj2_1483);
}
if(test1259_547){
return m_set_184___r5_syntax_expand(exp_4, env_5);
}
 else {
bool_t test1260_548;
{
obj_t obj2_1485;
obj2_1485 = denotation_of_begin_249___r5_syntax_syntaxenv;
test1260_548 = (keyword_541==obj2_1485);
}
if(test1260_548){
return m_begin_21___r5_syntax_expand(exp_4, env_5);
}
 else {
bool_t test1261_549;
{
obj_t obj2_1487;
obj2_1487 = denotation_of_let_syntax_71___r5_syntax_syntaxenv;
test1261_549 = (keyword_541==obj2_1487);
}
if(test1261_549){
return m_let_syntax_139___r5_syntax_expand(exp_4, env_5);
}
 else {
bool_t test1262_550;
{
obj_t obj2_1489;
obj2_1489 = denotation_of_letrec_syntax_163___r5_syntax_syntaxenv;
test1262_550 = (keyword_541==obj2_1489);
}
if(test1262_550){
return m_letrec_syntax_194___r5_syntax_expand(exp_4, env_5);
}
 else {
bool_t test1263_551;
{
bool_t test1269_557;
{
obj_t obj2_1491;
obj2_1491 = denotation_of_define_166___r5_syntax_syntaxenv;
test1269_557 = (keyword_541==obj2_1491);
}
if(test1269_557){
test1263_551 = ((bool_t)1);
}
 else {
obj_t obj2_1493;
obj2_1493 = denotation_of_define_syntax_255___r5_syntax_syntaxenv;
test1263_551 = (keyword_541==obj2_1493);
}
}
if(test1263_551){
{
obj_t list1264_552;
list1264_552 = MAKE_PAIR(exp_4, BNIL);
return m_error_176___r5_syntax_misc(string1924___r5_syntax_expand, list1264_552);
}
}
 else {
{
obj_t list1266_554;
{
obj_t arg1267_555;
arg1267_555 = MAKE_PAIR(env_5, BNIL);
list1266_554 = MAKE_PAIR(exp_4, arg1267_555);
}
return m_bug_88___r5_syntax_misc(string1925___r5_syntax_expand, list1266_554);
}
}
}
}
}
}
}
}
}
}
 else {
if((case_value_58_542==symbol1926___r5_syntax_expand)){
obj_t arg1762_2566;
arg1762_2566 = proc1927___r5_syntax_expand;
return m_transcribe_36___r5_syntax_syntaxrules(exp_4, env_5, arg1762_2566);
}
 else {
if((case_value_58_542==symbol1928___r5_syntax_expand)){
obj_t exp_2589;
obj_t env_2590;
exp_2589 = exp_4;
env_2590 = env_5;
return loop_1912___r5_syntax_expand(env_2590, exp_2589);
}
 else {
obj_t list1272_560;
{
obj_t arg1273_561;
arg1273_561 = MAKE_PAIR(env_5, BNIL);
list1272_560 = MAKE_PAIR(exp_4, arg1273_561);
}
return m_bug_88___r5_syntax_misc(string1925___r5_syntax_expand, list1272_560);
}
}
}
}
}
 else {
return m_atom_20___r5_syntax_expand(exp_4, env_5);
}
}


/* arg1762 */obj_t arg1762___r5_syntax_expand(obj_t env_2567, obj_t exp_2568, obj_t env_2569)
{
{
obj_t exp_2591;
obj_t env_2592;
exp_2591 = exp_2568;
env_2592 = env_2569;
return m_expand_161___r5_syntax_expand(exp_2591, env_2592);
}
}


/* m-atom */obj_t m_atom_20___r5_syntax_expand(obj_t exp_6, obj_t env_7)
{
if(SYMBOLP(exp_6)){
{
obj_t denotation_568;
denotation_568 = syntactic_lookup_76___r5_syntax_syntaxenv(env_7, exp_6);
{
obj_t case_value_58_569;
case_value_58_569 = PROCEDURE_ENTRY(denotation_class_62___r5_syntax_syntaxenv)(denotation_class_62___r5_syntax_syntaxenv, denotation_568, BEOA);
{
bool_t test_2941;
{
obj_t aux_2942;
aux_2942 = memq___r4_pairs_and_lists_6_3(case_value_58_569, list1929___r5_syntax_expand);
test_2941 = CBOOL(aux_2942);
}
if(test_2941){
obj_t list1285_571;
{
obj_t arg1286_572;
arg1286_572 = MAKE_PAIR(env_7, BNIL);
list1285_571 = MAKE_PAIR(exp_6, arg1286_572);
}
return m_error_176___r5_syntax_misc(string1930___r5_syntax_expand, list1285_571);
}
 else {
if((case_value_58_569==symbol1928___r5_syntax_expand)){
return identifier_name_131___r5_syntax_syntaxenv(denotation_568);
}
 else {
obj_t list1289_575;
{
obj_t arg1290_576;
arg1290_576 = MAKE_PAIR(env_7, BNIL);
list1289_575 = MAKE_PAIR(exp_6, arg1290_576);
}
return m_bug_88___r5_syntax_misc(string1931___r5_syntax_expand, list1289_575);
}
}
}
}
}
}
 else {
return exp_6;
}
}


/* m-quote */obj_t m_quote_31___r5_syntax_expand(obj_t exp_8)
{
{
bool_t test1295_580;
{
obj_t arg1303_588;
arg1303_588 = safe_length_235___r5_syntax_misc(exp_8);
test1295_580 = _2__95___r4_numbers_6_5(arg1303_588, BINT(((long)2)));
}
if(test1295_580){
obj_t arg1296_581;
{
obj_t aux_2958;
{
obj_t aux_2959;
aux_2959 = CDR(exp_8);
aux_2958 = CAR(aux_2959);
}
arg1296_581 = m_strip_59___r5_syntax_syntaxenv(aux_2958);
}
{
obj_t list1297_582;
{
obj_t arg1298_583;
arg1298_583 = MAKE_PAIR(arg1296_581, BNIL);
list1297_582 = MAKE_PAIR(quote1___r5_syntax_prefs, arg1298_583);
}
return list1297_582;
}
}
 else {
obj_t list1301_586;
list1301_586 = MAKE_PAIR(exp_8, BNIL);
return m_error_176___r5_syntax_misc(string1932___r5_syntax_expand, list1301_586);
}
}
}


/* m-lambda */obj_t m_lambda_201___r5_syntax_expand(obj_t exp_9, obj_t env_10)
{
{
bool_t test1305_590;
{
obj_t arg1321_604;
arg1321_604 = safe_length_235___r5_syntax_misc(exp_9);
test1305_590 = _2__206___r4_numbers_6_5(arg1321_604, BINT(((long)2)));
}
if(test1305_590){
obj_t formals_591;
{
obj_t aux_2971;
aux_2971 = CDR(exp_9);
formals_591 = CAR(aux_2971);
}
{
obj_t alist_592;
{
obj_t arg1315_601;
arg1315_601 = make_null_terminated_173___r5_syntax_misc(formals_591);
alist_592 = rename_vars_186___r5_syntax_syntaxenv(arg1315_601);
}
{
obj_t env_593;
env_593 = syntactic_rename_48___r5_syntax_syntaxenv(env_10, alist_592);
{
{
obj_t arg1307_595;
obj_t arg1308_596;
arg1307_595 = rename_formals_228___r5_syntax_syntaxenv(formals_591, alist_592);
{
obj_t aux_2978;
{
obj_t aux_2979;
aux_2979 = CDR(exp_9);
aux_2978 = CDR(aux_2979);
}
arg1308_596 = m_body_102___r5_syntax_expand(aux_2978, env_593);
}
{
obj_t list1309_597;
{
obj_t arg1310_598;
{
obj_t arg1311_599;
arg1311_599 = MAKE_PAIR(arg1308_596, BNIL);
arg1310_598 = MAKE_PAIR(arg1307_595, arg1311_599);
}
list1309_597 = MAKE_PAIR(lambda1___r5_syntax_prefs, arg1310_598);
}
return list1309_597;
}
}
}
}
}
}
 else {
obj_t list1316_602;
list1316_602 = MAKE_PAIR(exp_9, BNIL);
return m_error_176___r5_syntax_misc(string1933___r5_syntax_expand, list1316_602);
}
}
}


/* m-body */obj_t m_body_102___r5_syntax_expand(obj_t body_11, obj_t env_12)
{
return loop___r5_syntax_expand(body_11, env_12, BNIL);
}


/* loop */obj_t loop___r5_syntax_expand(obj_t body_608, obj_t env_609, obj_t defs_610)
{
loop___r5_syntax_expand:
if(NULLP(body_608)){
m_error_176___r5_syntax_misc(string1934___r5_syntax_expand, BNIL);
}
 else {
BUNSPEC;
}
{
obj_t exp_614;
exp_614 = CAR(body_608);
{
bool_t test_2993;
if(PAIRP(exp_614)){
obj_t aux_2996;
aux_2996 = CAR(exp_614);
test_2993 = SYMBOLP(aux_2996);
}
 else {
test_2993 = ((bool_t)0);
}
if(test_2993){
obj_t denotation_616;
denotation_616 = syntactic_lookup_76___r5_syntax_syntaxenv(env_609, CAR(exp_614));
{
obj_t case_value_58_617;
case_value_58_617 = PROCEDURE_ENTRY(denotation_class_62___r5_syntax_syntaxenv)(denotation_class_62___r5_syntax_syntaxenv, denotation_616, BEOA);
if((case_value_58_617==symbol1923___r5_syntax_expand)){
bool_t test1329_619;
{
obj_t obj2_1529;
obj2_1529 = denotation_of_begin_249___r5_syntax_syntaxenv;
test1329_619 = (denotation_616==obj2_1529);
}
if(test1329_619){
{
obj_t body_3007;
body_3007 = append_2_18___r4_pairs_and_lists_6_3(CDR(exp_614), CDR(body_608));
body_608 = body_3007;
goto loop___r5_syntax_expand;
}
}
 else {
bool_t test1333_623;
{
obj_t obj2_1533;
obj2_1533 = denotation_of_define_166___r5_syntax_syntaxenv;
test1333_623 = (denotation_616==obj2_1533);
}
if(test1333_623){
{
obj_t arg1334_624;
obj_t arg1337_625;
arg1334_624 = CDR(body_608);
arg1337_625 = MAKE_PAIR(exp_614, defs_610);
{
obj_t defs_3016;
obj_t body_3015;
body_3015 = arg1334_624;
defs_3016 = arg1337_625;
defs_610 = defs_3016;
body_608 = body_3015;
goto loop___r5_syntax_expand;
}
}
}
 else {
return finalize_body_219___r5_syntax_expand(body_608, env_609, defs_610);
}
}
}
 else {
if((case_value_58_617==symbol1926___r5_syntax_expand)){
obj_t arg1339_2570;
arg1339_2570 = make_fx_procedure(arg1339___r5_syntax_expand, ((long)2), ((long)2));
PROCEDURE_SET(arg1339_2570, ((long)0), body_608);
PROCEDURE_SET(arg1339_2570, ((long)1), defs_610);
return m_transcribe_36___r5_syntax_syntaxrules(exp_614, env_609, arg1339_2570);
}
 else {
if((case_value_58_617==symbol1928___r5_syntax_expand)){
return finalize_body_219___r5_syntax_expand(body_608, env_609, defs_610);
}
 else {
obj_t list1345_635;
{
obj_t arg1347_636;
arg1347_636 = MAKE_PAIR(env_609, BNIL);
list1345_635 = MAKE_PAIR(body_608, arg1347_636);
}
return m_bug_88___r5_syntax_misc(string1935___r5_syntax_expand, list1345_635);
}
}
}
}
}
 else {
return finalize_body_219___r5_syntax_expand(body_608, env_609, defs_610);
}
}
}
}


/* arg1339 */obj_t arg1339___r5_syntax_expand(obj_t env_2572, obj_t exp_2575, obj_t env_2576)
{
{
obj_t body_2573;
obj_t defs_2574;
body_2573 = PROCEDURE_REF(env_2572, ((long)0));
defs_2574 = PROCEDURE_REF(env_2572, ((long)1));
{
obj_t exp_628;
obj_t env_629;
exp_628 = exp_2575;
env_629 = env_2576;
{
obj_t arg1342_1539;
{
obj_t aux_3033;
aux_3033 = CDR(body_2573);
arg1342_1539 = MAKE_PAIR(exp_628, aux_3033);
}
return loop___r5_syntax_expand(arg1342_1539, env_629, defs_2574);
}
}
}
}


/* finalize-body */obj_t finalize_body_219___r5_syntax_expand(obj_t body_13, obj_t env_14, obj_t defs_15)
{
if(NULLP(defs_15)){
obj_t body_646;
if(NULLP(body_13)){
body_646 = BNIL;
}
 else {
obj_t head1018_651;
head1018_651 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1016_1551;
obj_t tail1019_1552;
l1016_1551 = body_13;
tail1019_1552 = head1018_651;
lname1017_1550:
if(NULLP(l1016_1551)){
body_646 = CDR(head1018_651);
}
 else {
obj_t newtail1020_1560;
{
obj_t arg1365_1561;
arg1365_1561 = m_expand_161___r5_syntax_expand(CAR(l1016_1551), env_14);
newtail1020_1560 = MAKE_PAIR(arg1365_1561, BNIL);
}
SET_CDR(tail1019_1552, newtail1020_1560);
{
obj_t tail1019_3051;
obj_t l1016_3049;
l1016_3049 = CDR(l1016_1551);
tail1019_3051 = newtail1020_1560;
tail1019_1552 = tail1019_3051;
l1016_1551 = l1016_3049;
goto lname1017_1550;
}
}
}
}
{
bool_t test_3052;
{
obj_t aux_3053;
aux_3053 = CDR(body_646);
test_3052 = NULLP(aux_3053);
}
if(test_3052){
return CAR(body_646);
}
 else {
obj_t obj1_1606;
obj1_1606 = begin1___r5_syntax_prefs;
return MAKE_PAIR(obj1_1606, body_646);
}
}
}
 else {
obj_t alist_663;
alist_663 = rename_vars_186___r5_syntax_syntaxenv(list1936___r5_syntax_expand);
{
obj_t env_664;
env_664 = syntactic_alias_206___r5_syntax_syntaxenv(env_14, alist_663, standard_syntactic_environment_195___r5_syntax_syntaxenv);
{
obj_t new_quote_212_665;
{
obj_t aux_3060;
aux_3060 = assq___r4_pairs_and_lists_6_3(symbol1937___r5_syntax_expand, alist_663);
new_quote_212_665 = CDR(aux_3060);
}
{
obj_t new_lambda_89_666;
{
obj_t aux_3063;
aux_3063 = assq___r4_pairs_and_lists_6_3(symbol1938___r5_syntax_expand, alist_663);
new_lambda_89_666 = CDR(aux_3063);
}
{
obj_t new_set__202_667;
{
obj_t aux_3066;
aux_3066 = assq___r4_pairs_and_lists_6_3(symbol1939___r5_syntax_expand, alist_663);
new_set__202_667 = CDR(aux_3066);
}
{
{
obj_t bindings_688;
obj_t body_689;
{
obj_t arg1370_670;
{
obj_t arg1372_671;
{
obj_t l1036_672;
l1036_672 = reverse___r4_pairs_and_lists_6_3(defs_15);
if(NULLP(l1036_672)){
arg1372_671 = BNIL;
}
 else {
obj_t head1038_674;
{
obj_t arg1384_685;
arg1384_685 = desugar_definition_216___r5_syntax_expand(new_lambda_89_666, env_664, CAR(l1036_672));
head1038_674 = MAKE_PAIR(arg1384_685, BNIL);
}
{
obj_t l1036_1617;
obj_t tail1039_1618;
l1036_1617 = CDR(l1036_672);
tail1039_1618 = head1038_674;
lname1037_1616:
if(NULLP(l1036_1617)){
arg1372_671 = head1038_674;
}
 else {
obj_t newtail1040_1626;
{
obj_t arg1379_1627;
arg1379_1627 = desugar_definition_216___r5_syntax_expand(new_lambda_89_666, env_664, CAR(l1036_1617));
newtail1040_1626 = MAKE_PAIR(arg1379_1627, BNIL);
}
SET_CDR(tail1039_1618, newtail1040_1626);
{
obj_t tail1039_3083;
obj_t l1036_3081;
l1036_3081 = CDR(l1036_1617);
tail1039_3083 = newtail1040_1626;
tail1039_1618 = tail1039_3083;
l1036_1617 = l1036_3081;
goto lname1037_1616;
}
}
}
}
}
bindings_688 = arg1372_671;
body_689 = body_13;
{
obj_t arg1389_691;
obj_t arg1390_692;
{
obj_t arg1393_695;
obj_t arg1395_696;
if(NULLP(bindings_688)){
arg1393_695 = BNIL;
}
 else {
obj_t head1023_702;
{
obj_t aux_3087;
{
obj_t aux_3088;
aux_3088 = CAR(bindings_688);
aux_3087 = CAR(aux_3088);
}
head1023_702 = MAKE_PAIR(aux_3087, BNIL);
}
{
obj_t l1021_1673;
obj_t tail1024_1674;
l1021_1673 = CDR(bindings_688);
tail1024_1674 = head1023_702;
lname1022_1672:
if(NULLP(l1021_1673)){
arg1393_695 = head1023_702;
}
 else {
obj_t newtail1025_1682;
{
obj_t aux_3094;
{
obj_t aux_3095;
aux_3095 = CAR(l1021_1673);
aux_3094 = CAR(aux_3095);
}
newtail1025_1682 = MAKE_PAIR(aux_3094, BNIL);
}
SET_CDR(tail1024_1674, newtail1025_1682);
{
obj_t tail1024_3102;
obj_t l1021_3100;
l1021_3100 = CDR(l1021_1673);
tail1024_3102 = newtail1025_1682;
tail1024_1674 = tail1024_3102;
l1021_1673 = l1021_3100;
goto lname1022_1672;
}
}
}
}
{
obj_t arg1414_716;
obj_t arg1415_717;
if(NULLP(bindings_688)){
arg1414_716 = BNIL;
}
 else {
obj_t head1028_720;
head1028_720 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1026_721;
obj_t tail1029_722;
l1026_721 = bindings_688;
tail1029_722 = head1028_720;
lname1027_723:
if(NULLP(l1026_721)){
arg1414_716 = CDR(head1028_720);
}
 else {
obj_t newtail1030_725;
{
obj_t arg1419_727;
{
obj_t binding_729;
binding_729 = CAR(l1026_721);
{
obj_t arg1423_730;
obj_t arg1426_731;
arg1423_730 = CAR(binding_729);
{
obj_t aux_3112;
aux_3112 = CDR(binding_729);
arg1426_731 = CAR(aux_3112);
}
{
obj_t list1428_733;
{
obj_t arg1431_734;
{
obj_t arg1432_735;
arg1432_735 = MAKE_PAIR(BNIL, BNIL);
arg1431_734 = MAKE_PAIR(arg1426_731, arg1432_735);
}
list1428_733 = MAKE_PAIR(arg1423_730, arg1431_734);
}
arg1419_727 = cons__138___r4_pairs_and_lists_6_3(new_set__202_667, list1428_733);
}
}
}
newtail1030_725 = MAKE_PAIR(arg1419_727, BNIL);
}
SET_CDR(tail1029_722, newtail1030_725);
{
obj_t tail1029_3123;
obj_t l1026_3121;
l1026_3121 = CDR(l1026_721);
tail1029_3123 = newtail1030_725;
tail1029_722 = tail1029_3123;
l1026_721 = l1026_3121;
goto lname1027_723;
}
}
}
}
{
obj_t arg1438_739;
{
obj_t arg1440_741;
arg1440_741 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1438_739 = append_2_18___r4_pairs_and_lists_6_3(body_689, arg1440_741);
}
arg1415_717 = cons__138___r4_pairs_and_lists_6_3(arg1438_739, BNIL);
}
arg1395_696 = append_2_18___r4_pairs_and_lists_6_3(arg1414_716, arg1415_717);
}
{
obj_t list1396_697;
{
obj_t arg1397_698;
arg1397_698 = MAKE_PAIR(arg1395_696, BNIL);
list1396_697 = MAKE_PAIR(arg1393_695, arg1397_698);
}
arg1389_691 = cons__138___r4_pairs_and_lists_6_3(new_lambda_89_666, list1396_697);
}
}
{
obj_t arg1443_744;
obj_t arg1444_745;
if(NULLP(bindings_688)){
arg1443_744 = BNIL;
}
 else {
obj_t head1033_748;
head1033_748 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1031_749;
obj_t tail1034_750;
l1031_749 = bindings_688;
tail1034_750 = head1033_748;
lname1032_751:
if(NULLP(l1031_749)){
arg1443_744 = CDR(head1033_748);
}
 else {
obj_t newtail1035_753;
{
obj_t arg1449_755;
{
obj_t arg1453_758;
arg1453_758 = symbol1940___r5_syntax_expand;
{
obj_t list1455_760;
{
obj_t arg1456_761;
arg1456_761 = MAKE_PAIR(BNIL, BNIL);
list1455_760 = MAKE_PAIR(arg1453_758, arg1456_761);
}
arg1449_755 = cons__138___r4_pairs_and_lists_6_3(new_quote_212_665, list1455_760);
}
}
newtail1035_753 = MAKE_PAIR(arg1449_755, BNIL);
}
SET_CDR(tail1034_750, newtail1035_753);
{
obj_t tail1034_3144;
obj_t l1031_3142;
l1031_3142 = CDR(l1031_749);
tail1034_3144 = newtail1035_753;
tail1034_750 = tail1034_3144;
l1031_749 = l1031_3142;
goto lname1032_751;
}
}
}
}
arg1444_745 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1390_692 = append_2_18___r4_pairs_and_lists_6_3(arg1443_744, arg1444_745);
}
{
obj_t list1391_693;
list1391_693 = MAKE_PAIR(arg1390_692, BNIL);
arg1370_670 = cons__138___r4_pairs_and_lists_6_3(arg1389_691, list1391_693);
}
}
}
return m_expand_161___r5_syntax_expand(arg1370_670, env_664);
}
}
}
}
}
}
}
}
}


/* desugar-definition */obj_t desugar_definition_216___r5_syntax_expand(obj_t new_lambda_89_2585, obj_t env_2584, obj_t def_767)
{
desugar_definition_216___r5_syntax_expand:
{
bool_t test1466_769;
{
obj_t arg1503_801;
arg1503_801 = safe_length_235___r5_syntax_misc(def_767);
test1466_769 = _2__206___r4_numbers_6_5(arg1503_801, BINT(((long)2)));
}
if(test1466_769){
bool_t test_3154;
{
obj_t aux_3155;
{
obj_t aux_3156;
aux_3156 = CDR(def_767);
aux_3155 = CAR(aux_3156);
}
test_3154 = PAIRP(aux_3155);
}
if(test_3154){
{
obj_t arg1468_771;
{
obj_t arg1469_772;
obj_t arg1470_773;
obj_t arg1471_774;
arg1469_772 = CAR(def_767);
{
obj_t aux_3161;
{
obj_t aux_3162;
aux_3162 = CDR(def_767);
aux_3161 = CAR(aux_3162);
}
arg1470_773 = CAR(aux_3161);
}
{
obj_t arg1479_781;
obj_t arg1480_782;
{
obj_t aux_3166;
{
obj_t aux_3167;
aux_3167 = CDR(def_767);
aux_3166 = CAR(aux_3167);
}
arg1479_781 = CDR(aux_3166);
}
{
obj_t arg1486_787;
obj_t arg1487_788;
{
obj_t aux_3171;
aux_3171 = CDR(def_767);
arg1486_787 = CDR(aux_3171);
}
arg1487_788 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1480_782 = append_2_18___r4_pairs_and_lists_6_3(arg1486_787, arg1487_788);
}
{
obj_t list1481_783;
{
obj_t arg1483_784;
arg1483_784 = MAKE_PAIR(arg1480_782, BNIL);
list1481_783 = MAKE_PAIR(arg1479_781, arg1483_784);
}
arg1471_774 = cons__138___r4_pairs_and_lists_6_3(new_lambda_89_2585, list1481_783);
}
}
{
obj_t list1474_776;
{
obj_t arg1475_777;
{
obj_t arg1476_778;
arg1476_778 = MAKE_PAIR(BNIL, BNIL);
arg1475_777 = MAKE_PAIR(arg1471_774, arg1476_778);
}
list1474_776 = MAKE_PAIR(arg1470_773, arg1475_777);
}
arg1468_771 = cons__138___r4_pairs_and_lists_6_3(arg1469_772, list1474_776);
}
}
{
obj_t def_3183;
def_3183 = arg1468_771;
def_767 = def_3183;
goto desugar_definition_216___r5_syntax_expand;
}
}
}
 else {
bool_t test_3184;
{
obj_t aux_3185;
{
long aux_3186;
aux_3186 = list_length(def_767);
aux_3185 = BINT(aux_3186);
}
test_3184 = _2__95___r4_numbers_6_5(aux_3185, BINT(((long)3)));
}
if(test_3184){
return CDR(def_767);
}
 else {
{
obj_t list1491_792;
{
obj_t arg1494_793;
arg1494_793 = MAKE_PAIR(env_2584, BNIL);
list1491_792 = MAKE_PAIR(def_767, arg1494_793);
}
return m_error_176___r5_syntax_misc(string1920___r5_syntax_expand, list1491_792);
}
}
}
}
 else {
obj_t list1500_798;
{
obj_t arg1501_799;
arg1501_799 = MAKE_PAIR(env_2584, BNIL);
list1500_798 = MAKE_PAIR(def_767, arg1501_799);
}
return m_error_176___r5_syntax_misc(string1920___r5_syntax_expand, list1500_798);
}
}
}


/* m-if */obj_t m_if_22___r5_syntax_expand(obj_t exp_16, obj_t env_17)
{
{
obj_t n_812;
n_812 = safe_length_235___r5_syntax_misc(exp_16);
{
bool_t test_3199;
if(_2__95___r4_numbers_6_5(n_812, BINT(((long)3)))){
test_3199 = ((bool_t)1);
}
 else {
test_3199 = _2__95___r4_numbers_6_5(n_812, BINT(((long)4)));
}
if(test_3199){
obj_t arg1517_814;
{
obj_t l1041_815;
l1041_815 = CDR(exp_16);
if(NULLP(l1041_815)){
arg1517_814 = BNIL;
}
 else {
obj_t head1043_817;
head1043_817 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1041_1778;
obj_t tail1044_1779;
l1041_1778 = l1041_815;
tail1044_1779 = head1043_817;
lname1042_1777:
if(NULLP(l1041_1778)){
arg1517_814 = CDR(head1043_817);
}
 else {
obj_t newtail1045_1787;
{
obj_t arg1524_1788;
arg1524_1788 = m_expand_161___r5_syntax_expand(CAR(l1041_1778), env_17);
newtail1045_1787 = MAKE_PAIR(arg1524_1788, BNIL);
}
SET_CDR(tail1044_1779, newtail1045_1787);
{
obj_t tail1044_3218;
obj_t l1041_3216;
l1041_3216 = CDR(l1041_1778);
tail1044_3218 = newtail1045_1787;
tail1044_1779 = tail1044_3218;
l1041_1778 = l1041_3216;
goto lname1042_1777;
}
}
}
}
}
{
obj_t obj1_1830;
obj1_1830 = if1___r5_syntax_prefs;
return MAKE_PAIR(obj1_1830, arg1517_814);
}
}
 else {
obj_t list1528_829;
{
obj_t arg1529_830;
arg1529_830 = MAKE_PAIR(env_17, BNIL);
list1528_829 = MAKE_PAIR(exp_16, arg1529_830);
}
return m_error_176___r5_syntax_misc(string1941___r5_syntax_expand, list1528_829);
}
}
}
}


/* m-set */obj_t m_set_184___r5_syntax_expand(obj_t exp_18, obj_t env_19)
{
{
bool_t test1532_833;
{
obj_t arg1550_846;
arg1550_846 = safe_length_235___r5_syntax_misc(exp_18);
test1532_833 = _2__95___r4_numbers_6_5(arg1550_846, BINT(((long)3)));
}
if(test1532_833){
obj_t arg1533_834;
obj_t arg1534_835;
{
obj_t aux_3227;
{
obj_t aux_3228;
aux_3228 = CDR(exp_18);
aux_3227 = CAR(aux_3228);
}
arg1533_834 = m_expand_161___r5_syntax_expand(aux_3227, env_19);
}
{
obj_t aux_3232;
{
obj_t aux_3233;
{
obj_t aux_3234;
aux_3234 = CDR(exp_18);
aux_3233 = CDR(aux_3234);
}
aux_3232 = CAR(aux_3233);
}
arg1534_835 = m_expand_161___r5_syntax_expand(aux_3232, env_19);
}
{
obj_t list1536_837;
{
obj_t arg1537_838;
{
obj_t arg1539_839;
arg1539_839 = MAKE_PAIR(BNIL, BNIL);
arg1537_838 = MAKE_PAIR(arg1534_835, arg1539_839);
}
list1536_837 = MAKE_PAIR(arg1533_834, arg1537_838);
}
return cons__138___r4_pairs_and_lists_6_3(set_1_241___r5_syntax_prefs, list1536_837);
}
}
 else {
obj_t list1546_843;
{
obj_t arg1548_844;
arg1548_844 = MAKE_PAIR(env_19, BNIL);
list1546_843 = MAKE_PAIR(exp_18, arg1548_844);
}
return m_error_176___r5_syntax_misc(string1942___r5_syntax_expand, list1546_843);
}
}
}


/* m-begin */obj_t m_begin_21___r5_syntax_expand(obj_t exp_20, obj_t env_21)
{
{
bool_t test1553_848;
{
obj_t arg1572_873;
arg1572_873 = safe_length_235___r5_syntax_misc(exp_20);
test1553_848 = positive__57___r4_numbers_6_5(arg1572_873);
}
if(test1553_848){
obj_t arg1554_849;
{
obj_t arg1557_852;
obj_t arg1558_853;
{
obj_t l1046_854;
l1046_854 = CDR(exp_20);
if(NULLP(l1046_854)){
arg1557_852 = BNIL;
}
 else {
obj_t head1048_856;
head1048_856 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1046_1847;
obj_t tail1049_1848;
l1046_1847 = l1046_854;
tail1049_1848 = head1048_856;
lname1047_1846:
if(NULLP(l1046_1847)){
arg1557_852 = CDR(head1048_856);
}
 else {
obj_t newtail1050_1856;
{
obj_t arg1562_1857;
arg1562_1857 = m_expand_161___r5_syntax_expand(CAR(l1046_1847), env_21);
newtail1050_1856 = MAKE_PAIR(arg1562_1857, BNIL);
}
SET_CDR(tail1049_1848, newtail1050_1856);
{
obj_t tail1049_3262;
obj_t l1046_3260;
l1046_3260 = CDR(l1046_1847);
tail1049_3262 = newtail1050_1856;
tail1049_1848 = tail1049_3262;
l1046_1847 = l1046_3260;
goto lname1047_1846;
}
}
}
}
}
arg1558_853 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1554_849 = append_2_18___r4_pairs_and_lists_6_3(arg1557_852, arg1558_853);
}
{
obj_t list1555_850;
list1555_850 = MAKE_PAIR(arg1554_849, BNIL);
return cons__138___r4_pairs_and_lists_6_3(begin1___r5_syntax_prefs, list1555_850);
}
}
 else {
obj_t list1568_870;
{
obj_t arg1569_871;
arg1569_871 = MAKE_PAIR(env_21, BNIL);
list1568_870 = MAKE_PAIR(exp_20, arg1569_871);
}
return m_error_176___r5_syntax_misc(string1943___r5_syntax_expand, list1568_870);
}
}
}


/* loop_1912 */obj_t loop_1912___r5_syntax_expand(obj_t env_2583, obj_t exp_874)
{
if(NULLP(exp_874)){
return BNIL;
}
 else {
if(PAIRP(exp_874)){
{
obj_t arg1575_878;
arg1575_878 = m_expand_161___r5_syntax_expand(CAR(exp_874), env_2583);
SET_CAR(exp_874, arg1575_878);
}
{
obj_t arg1580_880;
arg1580_880 = loop_1912___r5_syntax_expand(env_2583, CDR(exp_874));
SET_CDR(exp_874, arg1580_880);
}
return exp_874;
}
 else {
return exp_874;
}
}
}


/* m-define-syntax */obj_t m_define_syntax_61___r5_syntax_expand(obj_t exp_24, obj_t env_25)
{
{
bool_t test1582_882;
{
bool_t test1606_900;
{
obj_t arg1608_902;
arg1608_902 = safe_length_235___r5_syntax_misc(exp_24);
test1606_900 = _2__95___r4_numbers_6_5(arg1608_902, BINT(((long)3)));
}
if(test1606_900){
obj_t aux_3284;
{
obj_t aux_3285;
aux_3285 = CDR(exp_24);
aux_3284 = CAR(aux_3285);
}
test1582_882 = SYMBOLP(aux_3284);
}
 else {
test1582_882 = ((bool_t)0);
}
}
if(test1582_882){
{
obj_t arg1585_885;
arg1585_885 = PROCEDURE_ENTRY(define_syntax_scope_173___r5_syntax_expand)(define_syntax_scope_173___r5_syntax_expand, BEOA);
{
obj_t aux_3296;
obj_t aux_3292;
{
obj_t aux_3297;
{
obj_t aux_3298;
aux_3298 = CDR(exp_24);
aux_3297 = CDR(aux_3298);
}
aux_3296 = CAR(aux_3297);
}
{
obj_t aux_3293;
aux_3293 = CDR(exp_24);
aux_3292 = CAR(aux_3293);
}
return m_define_syntax1_27___r5_syntax_expand(aux_3292, aux_3296, env_25, arg1585_885);
}
}
}
 else {
bool_t test1586_886;
{
bool_t test1594_893;
{
obj_t arg1603_898;
arg1603_898 = safe_length_235___r5_syntax_misc(exp_24);
test1594_893 = _2__95___r4_numbers_6_5(arg1603_898, BINT(((long)4)));
}
if(test1594_893){
bool_t test_3307;
{
obj_t aux_3308;
{
obj_t aux_3309;
aux_3309 = CDR(exp_24);
aux_3308 = CAR(aux_3309);
}
test_3307 = SYMBOLP(aux_3308);
}
if(test_3307){
obj_t aux_3313;
{
obj_t aux_3314;
{
obj_t aux_3315;
{
obj_t aux_3316;
aux_3316 = CDR(exp_24);
aux_3315 = CDR(aux_3316);
}
aux_3314 = CAR(aux_3315);
}
aux_3313 = memq___r4_pairs_and_lists_6_3(aux_3314, list1915___r5_syntax_expand);
}
test1586_886 = CBOOL(aux_3313);
}
 else {
test1586_886 = ((bool_t)0);
}
}
 else {
test1586_886 = ((bool_t)0);
}
}
if(test1586_886){
{
obj_t aux_3335;
obj_t aux_3327;
obj_t aux_3323;
{
obj_t aux_3336;
{
obj_t aux_3337;
aux_3337 = CDR(exp_24);
aux_3336 = CDR(aux_3337);
}
aux_3335 = CAR(aux_3336);
}
{
obj_t aux_3328;
{
obj_t aux_3329;
{
obj_t aux_3330;
aux_3330 = CDR(exp_24);
aux_3329 = CDR(aux_3330);
}
aux_3328 = CDR(aux_3329);
}
aux_3327 = CAR(aux_3328);
}
{
obj_t aux_3324;
aux_3324 = CDR(exp_24);
aux_3323 = CAR(aux_3324);
}
return m_define_syntax1_27___r5_syntax_expand(aux_3323, aux_3327, env_25, aux_3335);
}
}
 else {
{
obj_t list1590_890;
{
obj_t arg1592_891;
arg1592_891 = MAKE_PAIR(env_25, BNIL);
list1590_890 = MAKE_PAIR(exp_24, arg1592_891);
}
return m_error_176___r5_syntax_misc(string1944___r5_syntax_expand, list1590_890);
}
}
}
}
}


/* m-define-syntax1 */obj_t m_define_syntax1_27___r5_syntax_expand(obj_t keyword_26, obj_t spec_27, obj_t env_28, obj_t scope_29)
{
if((scope_29==symbol1913___r5_syntax_expand)){
obj_t arg1624_1956;
arg1624_1956 = m_compile_transformer_spec_209___r5_syntax_syntaxrules(spec_27, env_28);
syntactic_bind_globally__231___r5_syntax_syntaxenv(keyword_26, arg1624_1956);
}
 else {
if((scope_29==symbol1916___r5_syntax_expand)){
obj_t env_1962;
{
obj_t arg1625_1963;
obj_t arg1627_1964;
obj_t arg1628_1965;
arg1625_1963 = syntactic_copy_24___r5_syntax_syntaxenv(env_28);
{
obj_t list1629_1966;
list1629_1966 = MAKE_PAIR(keyword_26, BNIL);
arg1627_1964 = list1629_1966;
}
arg1628_1965 = list1945___r5_syntax_expand;
env_1962 = syntactic_extend_18___r5_syntax_syntaxenv(arg1625_1963, arg1627_1964, arg1628_1965);
}
{
obj_t transformer_1968;
transformer_1968 = m_compile_transformer_spec_209___r5_syntax_syntaxrules(spec_27, env_1962);
{
syntactic_assign__111___r5_syntax_syntaxenv(env_1962, keyword_26, transformer_1968);
syntactic_bind_globally__231___r5_syntax_syntaxenv(keyword_26, transformer_1968);
}
}
}
 else {
if((scope_29==symbol1917___r5_syntax_expand)){
obj_t arg1632_1975;
{
obj_t arg1633_1976;
arg1633_1976 = syntactic_copy_24___r5_syntax_syntaxenv(env_28);
arg1632_1975 = m_compile_transformer_spec_209___r5_syntax_syntaxrules(spec_27, arg1633_1976);
}
syntactic_bind_globally__231___r5_syntax_syntaxenv(keyword_26, arg1632_1975);
}
 else {
obj_t list1613_908;
list1613_908 = MAKE_PAIR(scope_29, BNIL);
m_bug_88___r5_syntax_misc(string1949___r5_syntax_expand, list1613_908);
}
}
}
{
obj_t list1621_913;
{
obj_t arg1622_914;
arg1622_914 = MAKE_PAIR(keyword_26, BNIL);
list1621_913 = MAKE_PAIR(quote1___r5_syntax_prefs, arg1622_914);
}
return list1621_913;
}
}


/* m-let-syntax */obj_t m_let_syntax_139___r5_syntax_expand(obj_t exp_39, obj_t env_40)
{
{
bool_t test1634_926;
{
bool_t test1679_980;
{
obj_t arg1686_992;
arg1686_992 = safe_length_235___r5_syntax_misc(exp_39);
test1679_980 = _2__206___r4_numbers_6_5(arg1686_992, BINT(((long)2)));
}
if(test1679_980){
obj_t arg1681_982;
{
obj_t aux_3370;
aux_3370 = CDR(exp_39);
arg1681_982 = CAR(aux_3370);
}
{
obj_t arg1680_2577;
arg1680_2577 = proc1950___r5_syntax_expand;
{
obj_t aux_3373;
aux_3373 = every1__242___r5_syntax_misc(arg1680_2577, arg1681_982);
test1634_926 = CBOOL(aux_3373);
}
}
}
 else {
test1634_926 = ((bool_t)0);
}
}
if(test1634_926){
obj_t arg1636_927;
obj_t arg1638_928;
{
obj_t aux_3377;
aux_3377 = CDR(exp_39);
arg1636_927 = CDR(aux_3377);
}
{
obj_t arg1639_929;
obj_t arg1640_930;
{
obj_t l1054_931;
{
obj_t aux_3380;
aux_3380 = CDR(exp_39);
l1054_931 = CAR(aux_3380);
}
if(NULLP(l1054_931)){
arg1639_929 = BNIL;
}
 else {
obj_t head1056_933;
{
obj_t aux_3385;
{
obj_t aux_3386;
aux_3386 = CAR(l1054_931);
aux_3385 = CAR(aux_3386);
}
head1056_933 = MAKE_PAIR(aux_3385, BNIL);
}
{
obj_t l1054_2018;
obj_t tail1057_2019;
l1054_2018 = CDR(l1054_931);
tail1057_2019 = head1056_933;
lname1055_2017:
if(NULLP(l1054_2018)){
arg1639_929 = head1056_933;
}
 else {
obj_t newtail1058_2027;
{
obj_t aux_3392;
{
obj_t aux_3393;
aux_3393 = CAR(l1054_2018);
aux_3392 = CAR(aux_3393);
}
newtail1058_2027 = MAKE_PAIR(aux_3392, BNIL);
}
SET_CDR(tail1057_2019, newtail1058_2027);
{
obj_t tail1057_3400;
obj_t l1054_3398;
l1054_3398 = CDR(l1054_2018);
tail1057_3400 = newtail1058_2027;
tail1057_2019 = tail1057_3400;
l1054_2018 = l1054_3398;
goto lname1055_2017;
}
}
}
}
}
{
obj_t l1059_947;
{
obj_t l1064_961;
{
obj_t aux_3402;
aux_3402 = CDR(exp_39);
l1064_961 = CAR(aux_3402);
}
if(NULLP(l1064_961)){
l1059_947 = BNIL;
}
 else {
obj_t head1066_963;
{
obj_t aux_3407;
{
obj_t aux_3408;
{
obj_t aux_3409;
aux_3409 = CAR(l1064_961);
aux_3408 = CDR(aux_3409);
}
aux_3407 = CAR(aux_3408);
}
head1066_963 = MAKE_PAIR(aux_3407, BNIL);
}
{
obj_t l1064_2084;
obj_t tail1067_2085;
l1064_2084 = CDR(l1064_961);
tail1067_2085 = head1066_963;
lname1065_2083:
if(NULLP(l1064_2084)){
l1059_947 = head1066_963;
}
 else {
obj_t newtail1068_2093;
{
obj_t aux_3416;
{
obj_t aux_3417;
{
obj_t aux_3418;
aux_3418 = CAR(l1064_2084);
aux_3417 = CDR(aux_3418);
}
aux_3416 = CAR(aux_3417);
}
newtail1068_2093 = MAKE_PAIR(aux_3416, BNIL);
}
SET_CDR(tail1067_2085, newtail1068_2093);
{
obj_t tail1067_3426;
obj_t l1064_3424;
l1064_3424 = CDR(l1064_2084);
tail1067_3426 = newtail1068_2093;
tail1067_2085 = tail1067_3426;
l1064_2084 = l1064_3424;
goto lname1065_2083;
}
}
}
}
}
if(NULLP(l1059_947)){
arg1640_930 = BNIL;
}
 else {
obj_t head1061_949;
head1061_949 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1059_2149;
obj_t tail1062_2150;
l1059_2149 = l1059_947;
tail1062_2150 = head1061_949;
lname1060_2148:
if(NULLP(l1059_2149)){
arg1640_930 = CDR(head1061_949);
}
 else {
obj_t newtail1063_2158;
{
obj_t arg1658_2159;
arg1658_2159 = m_compile_transformer_spec_209___r5_syntax_syntaxrules(CAR(l1059_2149), env_40);
newtail1063_2158 = MAKE_PAIR(arg1658_2159, BNIL);
}
SET_CDR(tail1062_2150, newtail1063_2158);
{
obj_t tail1062_3440;
obj_t l1059_3438;
l1059_3438 = CDR(l1059_2149);
tail1062_3440 = newtail1063_2158;
tail1062_2150 = tail1062_3440;
l1059_2149 = l1059_3438;
goto lname1060_2148;
}
}
}
}
}
arg1638_928 = syntactic_extend_18___r5_syntax_syntaxenv(env_40, arg1639_929, arg1640_930);
}
return m_body_102___r5_syntax_expand(arg1636_927, arg1638_928);
}
 else {
obj_t list1676_977;
{
obj_t arg1677_978;
arg1677_978 = MAKE_PAIR(env_40, BNIL);
list1676_977 = MAKE_PAIR(exp_39, arg1677_978);
}
return m_error_176___r5_syntax_misc(string1951___r5_syntax_expand, list1676_977);
}
}
}


/* arg1680 */obj_t arg1680___r5_syntax_expand(obj_t env_2578, obj_t binding_2579)
{
{
obj_t binding_983;
{
bool_t aux_3446;
binding_983 = binding_2579;
if(PAIRP(binding_983)){
bool_t test_3449;
{
obj_t aux_3450;
aux_3450 = CAR(binding_983);
test_3449 = SYMBOLP(aux_3450);
}
if(test_3449){
bool_t test_3453;
{
obj_t aux_3454;
aux_3454 = CDR(binding_983);
test_3453 = PAIRP(aux_3454);
}
if(test_3453){
obj_t aux_3457;
{
obj_t aux_3458;
aux_3458 = CDR(binding_983);
aux_3457 = CDR(aux_3458);
}
aux_3446 = NULLP(aux_3457);
}
 else {
aux_3446 = ((bool_t)0);
}
}
 else {
aux_3446 = ((bool_t)0);
}
}
 else {
aux_3446 = ((bool_t)0);
}
return BBOOL(aux_3446);
}
}
}


/* m-letrec-syntax */obj_t m_letrec_syntax_194___r5_syntax_expand(obj_t exp_41, obj_t env_42)
{
{
bool_t test1689_994;
{
bool_t test1748_1075;
{
obj_t arg1760_1087;
arg1760_1087 = safe_length_235___r5_syntax_misc(exp_41);
test1748_1075 = _2__206___r4_numbers_6_5(arg1760_1087, BINT(((long)2)));
}
if(test1748_1075){
obj_t arg1753_1077;
{
obj_t aux_3467;
aux_3467 = CDR(exp_41);
arg1753_1077 = CAR(aux_3467);
}
{
obj_t arg1749_2580;
arg1749_2580 = proc1952___r5_syntax_expand;
{
obj_t aux_3470;
aux_3470 = every1__242___r5_syntax_misc(arg1749_2580, arg1753_1077);
test1689_994 = CBOOL(aux_3470);
}
}
}
 else {
test1689_994 = ((bool_t)0);
}
}
if(test1689_994){
obj_t env_995;
{
obj_t arg1721_1040;
obj_t arg1722_1041;
{
obj_t l1072_1042;
{
obj_t aux_3474;
aux_3474 = CDR(exp_41);
l1072_1042 = CAR(aux_3474);
}
if(NULLP(l1072_1042)){
arg1721_1040 = BNIL;
}
 else {
obj_t head1074_1044;
{
obj_t aux_3479;
{
obj_t aux_3480;
aux_3480 = CAR(l1072_1042);
aux_3479 = CAR(aux_3480);
}
head1074_1044 = MAKE_PAIR(aux_3479, BNIL);
}
{
obj_t l1072_2226;
obj_t tail1075_2227;
l1072_2226 = CDR(l1072_1042);
tail1075_2227 = head1074_1044;
lname1073_2225:
if(NULLP(l1072_2226)){
arg1721_1040 = head1074_1044;
}
 else {
obj_t newtail1076_2235;
{
obj_t aux_3486;
{
obj_t aux_3487;
aux_3487 = CAR(l1072_2226);
aux_3486 = CAR(aux_3487);
}
newtail1076_2235 = MAKE_PAIR(aux_3486, BNIL);
}
SET_CDR(tail1075_2227, newtail1076_2235);
{
obj_t tail1075_3494;
obj_t l1072_3492;
l1072_3492 = CDR(l1072_2226);
tail1075_3494 = newtail1076_2235;
tail1075_2227 = tail1075_3494;
l1072_2226 = l1072_3492;
goto lname1073_2225;
}
}
}
}
}
{
obj_t l1077_1058;
{
obj_t aux_3496;
aux_3496 = CDR(exp_41);
l1077_1058 = CAR(aux_3496);
}
if(NULLP(l1077_1058)){
arg1722_1041 = BNIL;
}
 else {
obj_t head1079_1060;
head1079_1060 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1077_2286;
obj_t tail1080_2287;
l1077_2286 = l1077_1058;
tail1080_2287 = head1079_1060;
lname1078_2285:
if(NULLP(l1077_2286)){
arg1722_1041 = CDR(head1079_1060);
}
 else {
obj_t newtail1081_2295;
newtail1081_2295 = MAKE_PAIR(list1946___r5_syntax_expand, BNIL);
SET_CDR(tail1080_2287, newtail1081_2295);
{
obj_t tail1080_3509;
obj_t l1077_3507;
l1077_3507 = CDR(l1077_2286);
tail1080_3509 = newtail1081_2295;
tail1080_2287 = tail1080_3509;
l1077_2286 = l1077_3507;
goto lname1078_2285;
}
}
}
}
}
env_995 = syntactic_extend_18___r5_syntax_syntaxenv(env_42, arg1721_1040, arg1722_1041);
}
{
obj_t arg1691_999;
obj_t arg1692_1000;
{
obj_t l1085_1001;
{
obj_t aux_3511;
aux_3511 = CDR(exp_41);
l1085_1001 = CAR(aux_3511);
}
if(NULLP(l1085_1001)){
arg1691_999 = BNIL;
}
 else {
obj_t head1087_1003;
{
obj_t aux_3516;
{
obj_t aux_3517;
aux_3517 = CAR(l1085_1001);
aux_3516 = CAR(aux_3517);
}
head1087_1003 = MAKE_PAIR(aux_3516, BNIL);
}
{
obj_t l1085_2349;
obj_t tail1088_2350;
l1085_2349 = CDR(l1085_1001);
tail1088_2350 = head1087_1003;
lname1086_2348:
if(NULLP(l1085_2349)){
arg1691_999 = head1087_1003;
}
 else {
obj_t newtail1089_2358;
{
obj_t aux_3523;
{
obj_t aux_3524;
aux_3524 = CAR(l1085_2349);
aux_3523 = CAR(aux_3524);
}
newtail1089_2358 = MAKE_PAIR(aux_3523, BNIL);
}
SET_CDR(tail1088_2350, newtail1089_2358);
{
obj_t tail1088_3531;
obj_t l1085_3529;
l1085_3529 = CDR(l1085_2349);
tail1088_3531 = newtail1089_2358;
tail1088_2350 = tail1088_3531;
l1085_2349 = l1085_3529;
goto lname1086_2348;
}
}
}
}
}
{
obj_t l1090_1017;
{
obj_t aux_3533;
aux_3533 = CDR(exp_41);
l1090_1017 = CAR(aux_3533);
}
if(NULLP(l1090_1017)){
arg1692_1000 = BNIL;
}
 else {
obj_t head1092_1019;
{
obj_t aux_3538;
{
obj_t aux_3539;
{
obj_t aux_3540;
aux_3540 = CAR(l1090_1017);
aux_3539 = CDR(aux_3540);
}
aux_3538 = CAR(aux_3539);
}
head1092_1019 = MAKE_PAIR(aux_3538, BNIL);
}
{
obj_t l1090_2415;
obj_t tail1093_2416;
l1090_2415 = CDR(l1090_1017);
tail1093_2416 = head1092_1019;
lname1091_2414:
if(NULLP(l1090_2415)){
arg1692_1000 = head1092_1019;
}
 else {
obj_t newtail1094_2424;
{
obj_t aux_3547;
{
obj_t aux_3548;
{
obj_t aux_3549;
aux_3549 = CAR(l1090_2415);
aux_3548 = CDR(aux_3549);
}
aux_3547 = CAR(aux_3548);
}
newtail1094_2424 = MAKE_PAIR(aux_3547, BNIL);
}
SET_CDR(tail1093_2416, newtail1094_2424);
{
obj_t tail1093_3557;
obj_t l1090_3555;
l1090_3555 = CDR(l1090_2415);
tail1093_3557 = newtail1094_2424;
tail1093_2416 = tail1093_3557;
l1090_2415 = l1090_3555;
goto lname1091_2414;
}
}
}
}
}
{
obj_t ll1082_2477;
obj_t ll1083_2478;
ll1082_2477 = arg1691_999;
ll1083_2478 = arg1692_1000;
lname1084_2476:
if(NULLP(ll1082_2477)){
((bool_t)1);
}
 else {
{
obj_t id_2486;
id_2486 = CAR(ll1082_2477);
{
obj_t arg1716_2488;
arg1716_2488 = m_compile_transformer_spec_209___r5_syntax_syntaxrules(CAR(ll1083_2478), env_995);
syntactic_assign__111___r5_syntax_syntaxenv(env_995, id_2486, arg1716_2488);
}
}
{
obj_t ll1083_3567;
obj_t ll1082_3565;
ll1082_3565 = CDR(ll1082_2477);
ll1083_3567 = CDR(ll1083_2478);
ll1083_2478 = ll1083_3567;
ll1082_2477 = ll1082_3565;
goto lname1084_2476;
}
}
}
}
{
obj_t aux_3569;
{
obj_t aux_3570;
aux_3570 = CDR(exp_41);
aux_3569 = CDR(aux_3570);
}
return m_body_102___r5_syntax_expand(aux_3569, env_995);
}
}
 else {
obj_t list1745_1072;
{
obj_t arg1746_1073;
arg1746_1073 = MAKE_PAIR(env_42, BNIL);
list1745_1072 = MAKE_PAIR(exp_41, arg1746_1073);
}
return m_error_176___r5_syntax_misc(string1951___r5_syntax_expand, list1745_1072);
}
}
}


/* arg1749 */obj_t arg1749___r5_syntax_expand(obj_t env_2581, obj_t binding_2582)
{
{
obj_t binding_1078;
{
bool_t aux_3577;
binding_1078 = binding_2582;
if(PAIRP(binding_1078)){
bool_t test_3580;
{
obj_t aux_3581;
aux_3581 = CAR(binding_1078);
test_3580 = SYMBOLP(aux_3581);
}
if(test_3580){
bool_t test_3584;
{
obj_t aux_3585;
aux_3585 = CDR(binding_1078);
test_3584 = PAIRP(aux_3585);
}
if(test_3584){
obj_t aux_3588;
{
obj_t aux_3589;
aux_3589 = CDR(binding_1078);
aux_3588 = CDR(aux_3589);
}
aux_3577 = NULLP(aux_3588);
}
 else {
aux_3577 = ((bool_t)0);
}
}
 else {
aux_3577 = ((bool_t)0);
}
}
 else {
aux_3577 = ((bool_t)0);
}
return BBOOL(aux_3577);
}
}
}

