/*===========================================================================*/
/*   (Foreign/cstruct.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct calias
  {
     bool_t array__248;
  }
      *calias_t;

typedef struct cenum
  {
     struct type *btype;
     obj_t literals;
  }
     *cenum_t;

typedef struct cfunction
  {
     struct type *btype;
     long arity;
     struct type *type_res_48;
     obj_t type_args_244;
  }
         *cfunction_t;

typedef struct cptr
  {
     struct type *btype;
     struct type *point_to_164;
     bool_t array__248;
  }
    *cptr_t;

typedef struct cstruct
  {
     bool_t struct__46;
     obj_t fields;
     obj_t cstruct__170;
  }
       *cstruct_t;

typedef struct cstruct__170
  {
     struct type *btype;
     struct cstruct *cstruct;
  }
            *cstruct__170_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


static obj_t method_init_76_foreign_cstruct();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t cstruct__170_foreign_ctype;
extern obj_t string_append(obj_t, obj_t);
extern obj_t string_sans___40_type_tools(obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _make_ctype_accesses_1854_186_foreign_access(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_foreign_cstruct(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_foreign_ctype(long, char *);
extern obj_t module_initialization_70_foreign_access(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t imported_modules_init_94_foreign_cstruct();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t cstruct_foreign_ctype;
extern obj_t produce_module_clause__172_module_module(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_foreign_cstruct();
extern type_t use_type__231_type_env(obj_t);
static obj_t toplevel_init_63_foreign_cstruct();
extern obj_t open_input_string(obj_t);
extern obj_t string_to_bstring(char *);
extern type_t get_aliased_type_1_type_type(type_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t make_ctype_accesses__cstruct_205_foreign_cstruct(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_foreign_cstruct = BUNSPEC;
static obj_t cnst_init_137_foreign_cstruct();
static obj_t make_ctype_accesses__cstruct__52_foreign_cstruct(obj_t, obj_t, obj_t);
static obj_t __cnst[31];

DEFINE_STATIC_PROCEDURE(proc1856_foreign_cstruct, make_ctype_accesses__cstruct__52_foreign_cstruct1879, make_ctype_accesses__cstruct__52_foreign_cstruct, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1855_foreign_cstruct, make_ctype_accesses__cstruct_205_foreign_cstruct1880, make_ctype_accesses__cstruct_205_foreign_cstruct, 0L, 2);
DEFINE_STRING(string1873_foreign_cstruct, string1873_foreign_cstruct1881, "PREDICATE-OF INLINE STATIC FOREIGN SYMBOL MACRO QUOTE FOREIGN-ID EQ? FOREIGN? IF O::OBJ O2 O1 = PRAGMA::BOOL -NULL?::BOOL MAKE- LET NEW V ::OBJ PRAGMA O DEFINE-INLINE * -SET! - ::BOOL ? -> ", 189);
DEFINE_STRING(string1872_foreign_cstruct, string1872_foreign_cstruct1882, "cobj_to_foreign", 15);
DEFINE_STRING(string1871_foreign_cstruct, string1871_foreign_cstruct1883, ")FOREIGN_TO_COBJ", 16);
DEFINE_STRING(string1869_foreign_cstruct, string1869_foreign_cstruct1884, "($1 == (", 8);
DEFINE_STRING(string1870_foreign_cstruct, string1870_foreign_cstruct1885, "($1 == $2)", 10);
DEFINE_STRING(string1868_foreign_cstruct, string1868_foreign_cstruct1886, ")0L)", 4);
DEFINE_STRING(string1867_foreign_cstruct, string1867_foreign_cstruct1887, "(", 1);
DEFINE_STRING(string1866_foreign_cstruct, string1866_foreign_cstruct1888, ")GC_MALLOC( sizeof( ", 20);
DEFINE_STRING(string1865_foreign_cstruct, string1865_foreign_cstruct1889, " ) )", 4);
DEFINE_STRING(string1864_foreign_cstruct, string1864_foreign_cstruct1890, "((((", 4);
DEFINE_STRING(string1863_foreign_cstruct, string1863_foreign_cstruct1891, "(((", 3);
DEFINE_STRING(string1862_foreign_cstruct, string1862_foreign_cstruct1892, ")", 1);
DEFINE_STRING(string1861_foreign_cstruct, string1861_foreign_cstruct1893, "&((((", 5);
DEFINE_STRING(string1859_foreign_cstruct, string1859_foreign_cstruct1894, "))", 2);
DEFINE_STRING(string1860_foreign_cstruct, string1860_foreign_cstruct1895, ")$1)->", 6);
DEFINE_STRING(string1858_foreign_cstruct, string1858_foreign_cstruct1896, "*((", 3);
DEFINE_STRING(string1857_foreign_cstruct, string1857_foreign_cstruct1897, ") 0)", 4);
extern obj_t make_ctype_accesses__env_11_foreign_access;


/* module-initialization */ obj_t 
module_initialization_70_foreign_cstruct(long checksum_1174, char *from_1175)
{
   if (CBOOL(require_initialization_114_foreign_cstruct))
     {
	require_initialization_114_foreign_cstruct = BBOOL(((bool_t) 0));
	library_modules_init_112_foreign_cstruct();
	cnst_init_137_foreign_cstruct();
	imported_modules_init_94_foreign_cstruct();
	method_init_76_foreign_cstruct();
	toplevel_init_63_foreign_cstruct();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_foreign_cstruct()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70___object(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70___r4_strings_6_7(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70___reader(((long) 0), "FOREIGN_CSTRUCT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_foreign_cstruct()
{
   {
      obj_t cnst_port_138_1166;
      cnst_port_138_1166 = open_input_string(string1873_foreign_cstruct);
      {
	 long i_1167;
	 i_1167 = ((long) 30);
       loop_1168:
	 {
	    bool_t test1874_1169;
	    test1874_1169 = (i_1167 == ((long) -1));
	    if (test1874_1169)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1875_1170;
		    {
		       obj_t list1876_1171;
		       {
			  obj_t arg1877_1172;
			  arg1877_1172 = BNIL;
			  list1876_1171 = MAKE_PAIR(cnst_port_138_1166, arg1877_1172);
		       }
		       arg1875_1170 = read___reader(list1876_1171);
		    }
		    CNST_TABLE_SET(i_1167, arg1875_1170);
		 }
		 {
		    int aux_1173;
		    {
		       long aux_1195;
		       aux_1195 = (i_1167 - ((long) 1));
		       aux_1173 = (int) (aux_1195);
		    }
		    {
		       long i_1198;
		       i_1198 = (long) (aux_1173);
		       i_1167 = i_1198;
		       goto loop_1168;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_foreign_cstruct()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_foreign_cstruct()
{
   {
      obj_t make_ctype_accesses__cstruct_205_1156;
      make_ctype_accesses__cstruct_205_1156 = proc1855_foreign_cstruct;
      add_method__1___object(make_ctype_accesses__env_11_foreign_access, cstruct_foreign_ctype, make_ctype_accesses__cstruct_205_1156);
   }
   {
      obj_t make_ctype_accesses__cstruct__52_1155;
      make_ctype_accesses__cstruct__52_1155 = proc1856_foreign_cstruct;
      return add_method__1___object(make_ctype_accesses__env_11_foreign_access, cstruct__170_foreign_ctype, make_ctype_accesses__cstruct__52_1155);
   }
}


/* make-ctype-accesses!-cstruct* */ obj_t 
make_ctype_accesses__cstruct__52_foreign_cstruct(obj_t env_1157, obj_t what_1158, obj_t who_1159)
{
   {
      cstruct__170_t what_482;
      type_t who_483;
      what_482 = (cstruct__170_t) (what_1158);
      who_483 = (type_t) (who_1159);
      {
	 type_t btype_486;
	 {
	    obj_t aux_1202;
	    {
	       object_t aux_1203;
	       aux_1203 = (object_t) (what_482);
	       aux_1202 = OBJECT_WIDENING(aux_1203);
	    }
	    btype_486 = (((cstruct__170_t) CREF(aux_1202))->btype);
	 }
	 {
	    obj_t id_487;
	    id_487 = (((type_t) CREF(who_483))->id);
	    {
	       obj_t wid_488;
	       {
		  type_t obj_1100;
		  obj_1100 = (type_t) (what_482);
		  wid_488 = (((type_t) CREF(obj_1100))->id);
	       }
	       {
		  obj_t bid_489;
		  bid_489 = (((type_t) CREF(btype_486))->id);
		  {
		     obj_t id__bid_132_490;
		     {
			obj_t arg1842_1054;
			arg1842_1054 = CNST_TABLE_REF(((long) 0));
			{
			   obj_t list1843_1055;
			   {
			      obj_t arg1847_1056;
			      {
				 obj_t arg1848_1057;
				 arg1848_1057 = MAKE_PAIR(bid_489, BNIL);
				 arg1847_1056 = MAKE_PAIR(arg1842_1054, arg1848_1057);
			      }
			      list1843_1055 = MAKE_PAIR(id_487, arg1847_1056);
			   }
			   id__bid_132_490 = symbol_append_197___r4_symbols_6_4(list1843_1055);
			}
		     }
		     {
			obj_t bid__id_105_491;
			{
			   obj_t arg1835_1049;
			   arg1835_1049 = CNST_TABLE_REF(((long) 0));
			   {
			      obj_t list1836_1050;
			      {
				 obj_t arg1837_1051;
				 {
				    obj_t arg1838_1052;
				    arg1838_1052 = MAKE_PAIR(id_487, BNIL);
				    arg1837_1051 = MAKE_PAIR(arg1835_1049, arg1838_1052);
				 }
				 list1836_1050 = MAKE_PAIR(bid_489, arg1837_1051);
			      }
			      bid__id_105_491 = symbol_append_197___r4_symbols_6_4(list1836_1050);
			   }
			}
			{
			   obj_t bid__101_492;
			   {
			      obj_t list1832_1046;
			      {
				 obj_t arg1833_1047;
				 {
				    obj_t aux_1221;
				    aux_1221 = CNST_TABLE_REF(((long) 1));
				    arg1833_1047 = MAKE_PAIR(aux_1221, BNIL);
				 }
				 list1832_1046 = MAKE_PAIR(id_487, arg1833_1047);
			      }
			      bid__101_492 = symbol_append_197___r4_symbols_6_4(list1832_1046);
			   }
			   {
			      obj_t bid__bool_159_493;
			      {
				 obj_t list1827_1042;
				 {
				    obj_t arg1829_1043;
				    {
				       obj_t aux_1226;
				       aux_1226 = CNST_TABLE_REF(((long) 2));
				       arg1829_1043 = MAKE_PAIR(aux_1226, BNIL);
				    }
				    list1827_1042 = MAKE_PAIR(bid__101_492, arg1829_1043);
				 }
				 bid__bool_159_493 = symbol_append_197___r4_symbols_6_4(list1827_1042);
			      }
			      {
				 obj_t name_sans___18_495;
				 name_sans___18_495 = string_sans___40_type_tools((((type_t) CREF(who_483))->name));
				 {
				    cstruct_t cstruct_496;
				    {
				       obj_t aux_1233;
				       {
					  object_t aux_1234;
					  aux_1234 = (object_t) (what_482);
					  aux_1233 = OBJECT_WIDENING(aux_1234);
				       }
				       cstruct_496 = (((cstruct__170_t) CREF(aux_1233))->cstruct);
				    }
				    {
				       obj_t cstruct_fields_109_497;
				       {
					  obj_t aux_1238;
					  {
					     object_t aux_1239;
					     aux_1239 = (object_t) (cstruct_496);
					     aux_1238 = OBJECT_WIDENING(aux_1239);
					  }
					  cstruct_fields_109_497 = (((cstruct_t) CREF(aux_1238))->fields);
				       }
				       {
					  obj_t sizeof_498;
					  {
					     obj_t list1818_1035;
					     {
						obj_t arg1821_1037;
						{
						   obj_t arg1822_1038;
						   arg1822_1038 = MAKE_PAIR(string1857_foreign_cstruct, BNIL);
						   arg1821_1037 = MAKE_PAIR(name_sans___18_495, arg1822_1038);
						}
						list1818_1035 = MAKE_PAIR(string1858_foreign_cstruct, arg1821_1037);
					     }
					     sizeof_498 = string_append_106___r4_strings_6_7(list1818_1035);
					  }
					  {
					     {
						obj_t field_570;
						{
						   obj_t arg1211_508;
						   {
						      obj_t arg1213_509;
						      obj_t arg1214_510;
						      obj_t arg1216_511;
						      arg1213_509 = CNST_TABLE_REF(((long) 27));
						      {
							 obj_t arg1803_1011;
							 obj_t arg1804_1012;
							 arg1803_1011 = CNST_TABLE_REF(((long) 25));
							 {
							    obj_t arg1813_1021;
							    arg1813_1021 = CNST_TABLE_REF(((long) 26));
							    {
							       obj_t list1815_1023;
							       {
								  obj_t arg1816_1024;
								  arg1816_1024 = MAKE_PAIR(BNIL, BNIL);
								  list1815_1023 = MAKE_PAIR(id_487, arg1816_1024);
							       }
							       arg1804_1012 = cons__138___r4_pairs_and_lists_6_3(arg1813_1021, list1815_1023);
							    }
							 }
							 {
							    obj_t list1807_1015;
							    {
							       obj_t arg1808_1016;
							       {
								  obj_t arg1809_1017;
								  {
								     obj_t arg1810_1018;
								     {
									obj_t arg1811_1019;
									arg1811_1019 = MAKE_PAIR(BNIL, BNIL);
									arg1810_1018 = MAKE_PAIR(string1872_foreign_cstruct, arg1811_1019);
								     }
								     arg1809_1017 = MAKE_PAIR(arg1804_1012, arg1810_1018);
								  }
								  arg1808_1016 = MAKE_PAIR(id__bid_132_490, arg1809_1017);
							       }
							       list1807_1015 = MAKE_PAIR(bid_489, arg1808_1016);
							    }
							    arg1214_510 = cons__138___r4_pairs_and_lists_6_3(arg1803_1011, list1807_1015);
							 }
						      }
						      {
							 obj_t mname_991;
							 {
							    obj_t list1794_1004;
							    {
							       obj_t arg1796_1006;
							       {
								  obj_t arg1797_1007;
								  arg1797_1007 = MAKE_PAIR(string1871_foreign_cstruct, BNIL);
								  arg1796_1006 = MAKE_PAIR(name_sans___18_495, arg1797_1007);
							       }
							       list1794_1004 = MAKE_PAIR(string1867_foreign_cstruct, arg1796_1006);
							    }
							    mname_991 = string_append_106___r4_strings_6_7(list1794_1004);
							 }
							 {
							    obj_t arg1779_992;
							    obj_t arg1780_993;
							    arg1779_992 = CNST_TABLE_REF(((long) 25));
							    {
							       obj_t list1792_1002;
							       list1792_1002 = MAKE_PAIR(BNIL, BNIL);
							       arg1780_993 = cons__138___r4_pairs_and_lists_6_3(bid_489, list1792_1002);
							    }
							    {
							       obj_t list1782_995;
							       {
								  obj_t arg1783_996;
								  {
								     obj_t arg1786_997;
								     {
									obj_t arg1788_998;
									{
									   obj_t arg1789_999;
									   arg1789_999 = MAKE_PAIR(BNIL, BNIL);
									   arg1788_998 = MAKE_PAIR(mname_991, arg1789_999);
									}
									arg1786_997 = MAKE_PAIR(arg1780_993, arg1788_998);
								     }
								     arg1783_996 = MAKE_PAIR(bid__id_105_491, arg1786_997);
								  }
								  list1782_995 = MAKE_PAIR(id_487, arg1783_996);
							       }
							       arg1216_511 = cons__138___r4_pairs_and_lists_6_3(arg1779_992, list1782_995);
							    }
							 }
						      }
						      {
							 obj_t list1220_513;
							 {
							    obj_t arg1221_514;
							    {
							       obj_t arg1222_515;
							       arg1222_515 = MAKE_PAIR(BNIL, BNIL);
							       arg1221_514 = MAKE_PAIR(arg1216_511, arg1222_515);
							    }
							    list1220_513 = MAKE_PAIR(arg1214_510, arg1221_514);
							 }
							 arg1211_508 = cons__138___r4_pairs_and_lists_6_3(arg1213_509, list1220_513);
						      }
						   }
						   produce_module_clause__172_module_module(arg1211_508);
						}
						{
						   obj_t arg1225_517;
						   {
						      obj_t arg1226_518;
						      obj_t arg1228_519;
						      arg1226_518 = CNST_TABLE_REF(((long) 28));
						      {
							 obj_t arg1235_524;
							 obj_t arg1236_525;
							 arg1235_524 = CNST_TABLE_REF(((long) 29));
							 arg1236_525 = CNST_TABLE_REF(((long) 9));
							 {
							    obj_t list1239_527;
							    {
							       obj_t arg1240_528;
							       {
								  obj_t arg1241_529;
								  arg1241_529 = MAKE_PAIR(BNIL, BNIL);
								  arg1240_528 = MAKE_PAIR(arg1236_525, arg1241_529);
							       }
							       list1239_527 = MAKE_PAIR(bid__bool_159_493, arg1240_528);
							    }
							    arg1228_519 = cons__138___r4_pairs_and_lists_6_3(arg1235_524, list1239_527);
							 }
						      }
						      {
							 obj_t list1232_521;
							 {
							    obj_t arg1233_522;
							    arg1233_522 = MAKE_PAIR(BNIL, BNIL);
							    list1232_521 = MAKE_PAIR(arg1228_519, arg1233_522);
							 }
							 arg1225_517 = cons__138___r4_pairs_and_lists_6_3(arg1226_518, list1232_521);
						      }
						   }
						   produce_module_clause__172_module_module(arg1225_517);
						}
						{
						   obj_t arg1244_531;
						   {
						      obj_t arg1245_532;
						      obj_t arg1247_533;
						      arg1245_532 = CNST_TABLE_REF(((long) 8));
						      {
							 obj_t arg1252_538;
							 {
							    obj_t arg1257_543;
							    arg1257_543 = CNST_TABLE_REF(((long) 30));
							    {
							       obj_t list1259_545;
							       {
								  obj_t arg1260_546;
								  arg1260_546 = MAKE_PAIR(BNIL, BNIL);
								  list1259_545 = MAKE_PAIR(wid_488, arg1260_546);
							       }
							       arg1252_538 = cons__138___r4_pairs_and_lists_6_3(arg1257_543, list1259_545);
							    }
							 }
							 {
							    obj_t list1254_540;
							    {
							       obj_t arg1255_541;
							       arg1255_541 = MAKE_PAIR(BNIL, BNIL);
							       list1254_540 = MAKE_PAIR(arg1252_538, arg1255_541);
							    }
							    arg1247_533 = cons__138___r4_pairs_and_lists_6_3(bid__101_492, list1254_540);
							 }
						      }
						      {
							 obj_t list1249_535;
							 {
							    obj_t arg1250_536;
							    arg1250_536 = MAKE_PAIR(BNIL, BNIL);
							    list1249_535 = MAKE_PAIR(arg1247_533, arg1250_536);
							 }
							 arg1244_531 = cons__138___r4_pairs_and_lists_6_3(arg1245_532, list1249_535);
						      }
						   }
						   produce_module_clause__172_module_module(arg1244_531);
						}
						{
						   obj_t arg1263_548;
						   obj_t arg1265_549;
						   obj_t arg1267_550;
						   obj_t arg1268_551;
						   obj_t arg1269_552;
						   obj_t arg1270_553;
						   {
						      obj_t arg1566_823;
						      obj_t arg1568_824;
						      obj_t arg1569_825;
						      arg1566_823 = CNST_TABLE_REF(((long) 6));
						      {
							 obj_t arg1578_831;
							 {
							    obj_t arg1583_835;
							    arg1583_835 = CNST_TABLE_REF(((long) 13));
							    {
							       obj_t list1584_836;
							       {
								  obj_t arg1585_837;
								  {
								     obj_t arg1586_838;
								     {
									obj_t arg1587_839;
									arg1587_839 = MAKE_PAIR(id_487, BNIL);
									arg1586_838 = MAKE_PAIR(_4dots_199_tools_misc, arg1587_839);
								     }
								     arg1585_837 = MAKE_PAIR(id_487, arg1586_838);
								  }
								  list1584_836 = MAKE_PAIR(arg1583_835, arg1585_837);
							       }
							       arg1578_831 = symbol_append_197___r4_symbols_6_4(list1584_836);
							    }
							 }
							 {
							    obj_t list1581_833;
							    list1581_833 = MAKE_PAIR(BNIL, BNIL);
							    arg1568_824 = cons__138___r4_pairs_and_lists_6_3(arg1578_831, list1581_833);
							 }
						      }
						      {
							 obj_t arg1589_841;
							 obj_t arg1592_842;
							 {
							    obj_t arg1600_847;
							    arg1600_847 = CNST_TABLE_REF(((long) 8));
							    {
							       obj_t list1601_848;
							       {
								  obj_t arg1602_849;
								  {
								     obj_t arg1603_850;
								     arg1603_850 = MAKE_PAIR(id_487, BNIL);
								     arg1602_849 = MAKE_PAIR(_4dots_199_tools_misc, arg1603_850);
								  }
								  list1601_848 = MAKE_PAIR(arg1600_847, arg1602_849);
							       }
							       arg1589_841 = symbol_append_197___r4_symbols_6_4(list1601_848);
							    }
							 }
							 {
							    obj_t list1606_852;
							    {
							       obj_t arg1608_854;
							       {
								  obj_t arg1609_855;
								  {
								     obj_t arg1612_857;
								     {
									obj_t arg1613_858;
									arg1613_858 = MAKE_PAIR(string1865_foreign_cstruct, BNIL);
									arg1612_857 = MAKE_PAIR(sizeof_498, arg1613_858);
								     }
								     arg1609_855 = MAKE_PAIR(string1866_foreign_cstruct, arg1612_857);
								  }
								  arg1608_854 = MAKE_PAIR(name_sans___18_495, arg1609_855);
							       }
							       list1606_852 = MAKE_PAIR(string1867_foreign_cstruct, arg1608_854);
							    }
							    arg1592_842 = string_append_106___r4_strings_6_7(list1606_852);
							 }
							 {
							    obj_t list1594_844;
							    {
							       obj_t arg1595_845;
							       arg1595_845 = MAKE_PAIR(BNIL, BNIL);
							       list1594_844 = MAKE_PAIR(arg1592_842, arg1595_845);
							    }
							    arg1569_825 = cons__138___r4_pairs_and_lists_6_3(arg1589_841, list1594_844);
							 }
						      }
						      {
							 obj_t list1571_827;
							 {
							    obj_t arg1572_828;
							    {
							       obj_t arg1573_829;
							       arg1573_829 = MAKE_PAIR(BNIL, BNIL);
							       arg1572_828 = MAKE_PAIR(arg1569_825, arg1573_829);
							    }
							    list1571_827 = MAKE_PAIR(arg1568_824, arg1572_828);
							 }
							 arg1263_548 = cons__138___r4_pairs_and_lists_6_3(arg1566_823, list1571_827);
						      }
						   }
						   {
						      obj_t formals_typed_6_710;
						      obj_t new_711;
						      if (NULLP(cstruct_fields_109_497))
							{
							   formals_typed_6_710 = BNIL;
							}
						      else
							{
							   obj_t head1157_794;
							   head1157_794 = MAKE_PAIR(BNIL, BNIL);
							   {
							      obj_t l1155_795;
							      obj_t tail1158_796;
							      l1155_795 = cstruct_fields_109_497;
							      tail1158_796 = head1157_794;
							    lname1156_797:
							      if (NULLP(l1155_795))
								{
								   formals_typed_6_710 = CDR(head1157_794);
								}
							      else
								{
								   obj_t newtail1159_799;
								   {
								      obj_t arg1549_801;
								      {
									 obj_t f_803;
									 f_803 = CAR(l1155_795);
									 {
									    obj_t f_id_254_804;
									    {
									       obj_t aux_1334;
									       aux_1334 = CDR(f_803);
									       f_id_254_804 = CAR(aux_1334);
									    }
									    {
									       obj_t f_type_id_57_805;
									       f_type_id_57_805 = CAR(f_803);
									       {
										  type_t f_type_179_806;
										  f_type_179_806 = use_type__231_type_env(f_type_id_57_805);
										  {
										     type_t af_type_215_807;
										     af_type_215_807 = get_aliased_type_1_type_type(f_type_179_806);
										     {
											{
											   bool_t test1551_808;
											   test1551_808 = is_a__118___object((obj_t) (af_type_215_807), cstruct_foreign_ctype);
											   if (test1551_808)
											     {
												obj_t list1553_810;
												{
												   obj_t arg1554_811;
												   {
												      obj_t arg1555_812;
												      {
													 obj_t arg1556_813;
													 {
													    obj_t aux_1343;
													    aux_1343 = CNST_TABLE_REF(((long) 5));
													    arg1556_813 = MAKE_PAIR(aux_1343, BNIL);
													 }
													 arg1555_812 = MAKE_PAIR(f_type_id_57_805, arg1556_813);
												      }
												      arg1554_811 = MAKE_PAIR(_4dots_199_tools_misc, arg1555_812);
												   }
												   list1553_810 = MAKE_PAIR(f_id_254_804, arg1554_811);
												}
												arg1549_801 = symbol_append_197___r4_symbols_6_4(list1553_810);
											     }
											   else
											     {
												obj_t list1558_815;
												{
												   obj_t arg1559_816;
												   {
												      obj_t arg1560_817;
												      arg1560_817 = MAKE_PAIR(f_type_id_57_805, BNIL);
												      arg1559_816 = MAKE_PAIR(_4dots_199_tools_misc, arg1560_817);
												   }
												   list1558_815 = MAKE_PAIR(f_id_254_804, arg1559_816);
												}
												arg1549_801 = symbol_append_197___r4_symbols_6_4(list1558_815);
											     }
											}
										     }
										  }
									       }
									    }
									 }
								      }
								      newtail1159_799 = MAKE_PAIR(arg1549_801, BNIL);
								   }
								   SET_CDR(tail1158_796, newtail1159_799);
								   {
								      obj_t tail1158_1358;
								      obj_t l1155_1356;
								      l1155_1356 = CDR(l1155_795);
								      tail1158_1358 = newtail1159_799;
								      tail1158_796 = tail1158_1358;
								      l1155_795 = l1155_1356;
								      goto lname1156_797;
								   }
								}
							   }
							}
						      new_711 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 11)), BEOA);
						      {
							 obj_t arg1460_712;
							 obj_t arg1461_713;
							 obj_t arg1463_714;
							 arg1460_712 = CNST_TABLE_REF(((long) 6));
							 {
							    obj_t arg1469_720;
							    obj_t arg1470_721;
							    {
							       obj_t list1474_724;
							       {
								  obj_t arg1475_725;
								  {
								     obj_t arg1476_726;
								     arg1476_726 = MAKE_PAIR(id_487, BNIL);
								     arg1475_725 = MAKE_PAIR(_4dots_199_tools_misc, arg1476_726);
								  }
								  list1474_724 = MAKE_PAIR(id_487, arg1475_725);
							       }
							       arg1469_720 = symbol_append_197___r4_symbols_6_4(list1474_724);
							    }
							    {
							       obj_t arg1478_728;
							       arg1478_728 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							       arg1470_721 = append_2_18___r4_pairs_and_lists_6_3(formals_typed_6_710, arg1478_728);
							    }
							    {
							       obj_t list1471_722;
							       list1471_722 = MAKE_PAIR(arg1470_721, BNIL);
							       arg1461_713 = cons__138___r4_pairs_and_lists_6_3(arg1469_720, list1471_722);
							    }
							 }
							 {
							    obj_t arg1481_731;
							    obj_t arg1483_732;
							    obj_t arg1484_733;
							    arg1481_731 = CNST_TABLE_REF(((long) 12));
							    {
							       obj_t arg1488_737;
							       {
								  obj_t arg1494_741;
								  obj_t arg1496_742;
								  {
								     obj_t list1501_747;
								     {
									obj_t arg1502_748;
									{
									   obj_t arg1503_749;
									   arg1503_749 = MAKE_PAIR(id_487, BNIL);
									   arg1502_748 = MAKE_PAIR(_4dots_199_tools_misc, arg1503_749);
									}
									list1501_747 = MAKE_PAIR(new_711, arg1502_748);
								     }
								     arg1494_741 = symbol_append_197___r4_symbols_6_4(list1501_747);
								  }
								  {
								     obj_t arg1505_751;
								     {
									obj_t arg1511_755;
									arg1511_755 = CNST_TABLE_REF(((long) 13));
									{
									   obj_t list1512_756;
									   {
									      obj_t arg1513_757;
									      arg1513_757 = MAKE_PAIR(id_487, BNIL);
									      list1512_756 = MAKE_PAIR(arg1511_755, arg1513_757);
									   }
									   arg1505_751 = symbol_append_197___r4_symbols_6_4(list1512_756);
									}
								     }
								     {
									obj_t list1508_753;
									list1508_753 = MAKE_PAIR(BNIL, BNIL);
									arg1496_742 = cons__138___r4_pairs_and_lists_6_3(arg1505_751, list1508_753);
								     }
								  }
								  {
								     obj_t list1498_744;
								     {
									obj_t arg1499_745;
									arg1499_745 = MAKE_PAIR(BNIL, BNIL);
									list1498_744 = MAKE_PAIR(arg1496_742, arg1499_745);
								     }
								     arg1488_737 = cons__138___r4_pairs_and_lists_6_3(arg1494_741, list1498_744);
								  }
							       }
							       {
								  obj_t list1490_739;
								  list1490_739 = MAKE_PAIR(BNIL, BNIL);
								  arg1483_732 = cons__138___r4_pairs_and_lists_6_3(arg1488_737, list1490_739);
							       }
							    }
							    {
							       obj_t arg1515_759;
							       obj_t arg1516_760;
							       if (NULLP(cstruct_fields_109_497))
								 {
								    arg1515_759 = BNIL;
								 }
							       else
								 {
								    obj_t head1162_763;
								    head1162_763 = MAKE_PAIR(BNIL, BNIL);
								    {
								       obj_t l1160_764;
								       obj_t tail1163_765;
								       l1160_764 = cstruct_fields_109_497;
								       tail1163_765 = head1162_763;
								     lname1161_766:
								       if (NULLP(l1160_764))
									 {
									    arg1515_759 = CDR(head1162_763);
									 }
								       else
									 {
									    obj_t newtail1164_768;
									    {
									       obj_t arg1522_770;
									       {
										  obj_t f_id_254_773;
										  {
										     obj_t aux_1393;
										     {
											obj_t aux_1394;
											aux_1394 = CAR(l1160_764);
											aux_1393 = CDR(aux_1394);
										     }
										     f_id_254_773 = CAR(aux_1393);
										  }
										  {
										     obj_t arg1525_774;
										     {
											obj_t arg1531_780;
											arg1531_780 = CNST_TABLE_REF(((long) 3));
											{
											   obj_t list1533_782;
											   {
											      obj_t arg1534_783;
											      {
												 obj_t arg1535_784;
												 {
												    obj_t arg1536_785;
												    {
												       obj_t aux_1399;
												       aux_1399 = CNST_TABLE_REF(((long) 4));
												       arg1536_785 = MAKE_PAIR(aux_1399, BNIL);
												    }
												    arg1535_784 = MAKE_PAIR(f_id_254_773, arg1536_785);
												 }
												 arg1534_783 = MAKE_PAIR(arg1531_780, arg1535_784);
											      }
											      list1533_782 = MAKE_PAIR(id_487, arg1534_783);
											   }
											   arg1525_774 = symbol_append_197___r4_symbols_6_4(list1533_782);
											}
										     }
										     {
											obj_t list1527_776;
											{
											   obj_t arg1528_777;
											   {
											      obj_t arg1529_778;
											      arg1529_778 = MAKE_PAIR(BNIL, BNIL);
											      arg1528_777 = MAKE_PAIR(f_id_254_773, arg1529_778);
											   }
											   list1527_776 = MAKE_PAIR(new_711, arg1528_777);
											}
											arg1522_770 = cons__138___r4_pairs_and_lists_6_3(arg1525_774, list1527_776);
										     }
										  }
									       }
									       newtail1164_768 = MAKE_PAIR(arg1522_770, BNIL);
									    }
									    SET_CDR(tail1163_765, newtail1164_768);
									    {
									       obj_t tail1163_1414;
									       obj_t l1160_1412;
									       l1160_1412 = CDR(l1160_764);
									       tail1163_1414 = newtail1164_768;
									       tail1163_765 = tail1163_1414;
									       l1160_764 = l1160_1412;
									       goto lname1161_766;
									    }
									 }
								    }
								 }
							       {
								  obj_t list1543_790;
								  list1543_790 = MAKE_PAIR(BNIL, BNIL);
								  arg1516_760 = cons__138___r4_pairs_and_lists_6_3(new_711, list1543_790);
							       }
							       arg1484_733 = append_2_18___r4_pairs_and_lists_6_3(arg1515_759, arg1516_760);
							    }
							    {
							       obj_t list1485_734;
							       {
								  obj_t arg1486_735;
								  arg1486_735 = MAKE_PAIR(arg1484_733, BNIL);
								  list1485_734 = MAKE_PAIR(arg1483_732, arg1486_735);
							       }
							       arg1463_714 = cons__138___r4_pairs_and_lists_6_3(arg1481_731, list1485_734);
							    }
							 }
							 {
							    obj_t list1465_716;
							    {
							       obj_t arg1466_717;
							       {
								  obj_t arg1467_718;
								  arg1467_718 = MAKE_PAIR(BNIL, BNIL);
								  arg1466_717 = MAKE_PAIR(arg1463_714, arg1467_718);
							       }
							       list1465_716 = MAKE_PAIR(arg1461_713, arg1466_717);
							    }
							    arg1265_549 = cons__138___r4_pairs_and_lists_6_3(arg1460_712, list1465_716);
							 }
						      }
						   }
						   {
						      obj_t arg1669_900;
						      obj_t arg1670_901;
						      obj_t arg1672_902;
						      arg1669_900 = CNST_TABLE_REF(((long) 6));
						      {
							 obj_t arg1678_908;
							 obj_t arg1679_909;
							 obj_t arg1680_910;
							 {
							    obj_t arg1686_916;
							    arg1686_916 = CNST_TABLE_REF(((long) 16));
							    {
							       obj_t list1689_918;
							       {
								  obj_t arg1691_919;
								  {
								     obj_t arg1692_920;
								     {
									obj_t aux_1427;
									aux_1427 = CNST_TABLE_REF(((long) 2));
									arg1692_920 = MAKE_PAIR(aux_1427, BNIL);
								     }
								     arg1691_919 = MAKE_PAIR(id_487, arg1692_920);
								  }
								  list1689_918 = MAKE_PAIR(arg1686_916, arg1691_919);
							       }
							       arg1678_908 = symbol_append_197___r4_symbols_6_4(list1689_918);
							    }
							 }
							 {
							    obj_t arg1694_922;
							    arg1694_922 = CNST_TABLE_REF(((long) 17));
							    {
							       obj_t list1695_923;
							       {
								  obj_t arg1697_924;
								  {
								     obj_t arg1698_925;
								     arg1698_925 = MAKE_PAIR(id_487, BNIL);
								     arg1697_924 = MAKE_PAIR(_4dots_199_tools_misc, arg1698_925);
								  }
								  list1695_923 = MAKE_PAIR(arg1694_922, arg1697_924);
							       }
							       arg1679_909 = symbol_append_197___r4_symbols_6_4(list1695_923);
							    }
							 }
							 {
							    obj_t arg1700_927;
							    arg1700_927 = CNST_TABLE_REF(((long) 18));
							    {
							       obj_t list1701_928;
							       {
								  obj_t arg1702_929;
								  {
								     obj_t arg1703_930;
								     arg1703_930 = MAKE_PAIR(id_487, BNIL);
								     arg1702_929 = MAKE_PAIR(_4dots_199_tools_misc, arg1703_930);
								  }
								  list1701_928 = MAKE_PAIR(arg1700_927, arg1702_929);
							       }
							       arg1680_910 = symbol_append_197___r4_symbols_6_4(list1701_928);
							    }
							 }
							 {
							    obj_t list1682_912;
							    {
							       obj_t arg1683_913;
							       {
								  obj_t arg1684_914;
								  arg1684_914 = MAKE_PAIR(BNIL, BNIL);
								  arg1683_913 = MAKE_PAIR(arg1680_910, arg1684_914);
							       }
							       list1682_912 = MAKE_PAIR(arg1679_909, arg1683_913);
							    }
							    arg1670_901 = cons__138___r4_pairs_and_lists_6_3(arg1678_908, list1682_912);
							 }
						      }
						      {
							 obj_t arg1705_932;
							 obj_t arg1707_934;
							 obj_t arg1708_935;
							 arg1705_932 = CNST_TABLE_REF(((long) 15));
							 arg1707_934 = CNST_TABLE_REF(((long) 17));
							 arg1708_935 = CNST_TABLE_REF(((long) 18));
							 {
							    obj_t list1710_937;
							    {
							       obj_t arg1711_938;
							       {
								  obj_t arg1712_939;
								  {
								     obj_t arg1713_940;
								     arg1713_940 = MAKE_PAIR(BNIL, BNIL);
								     arg1712_939 = MAKE_PAIR(arg1708_935, arg1713_940);
								  }
								  arg1711_938 = MAKE_PAIR(arg1707_934, arg1712_939);
							       }
							       list1710_937 = MAKE_PAIR(string1870_foreign_cstruct, arg1711_938);
							    }
							    arg1672_902 = cons__138___r4_pairs_and_lists_6_3(arg1705_932, list1710_937);
							 }
						      }
						      {
							 obj_t list1674_904;
							 {
							    obj_t arg1675_905;
							    {
							       obj_t arg1676_906;
							       arg1676_906 = MAKE_PAIR(BNIL, BNIL);
							       arg1675_905 = MAKE_PAIR(arg1672_902, arg1676_906);
							    }
							    list1674_904 = MAKE_PAIR(arg1670_901, arg1675_905);
							 }
							 arg1267_550 = cons__138___r4_pairs_and_lists_6_3(arg1669_900, list1674_904);
						      }
						   }
						   {
						      obj_t arg1620_862;
						      obj_t arg1621_863;
						      obj_t arg1622_864;
						      arg1620_862 = CNST_TABLE_REF(((long) 6));
						      {
							 obj_t arg1630_870;
							 obj_t arg1632_871;
							 {
							    obj_t list1640_877;
							    {
							       obj_t arg1641_878;
							       {
								  obj_t aux_1460;
								  aux_1460 = CNST_TABLE_REF(((long) 14));
								  arg1641_878 = MAKE_PAIR(aux_1460, BNIL);
							       }
							       list1640_877 = MAKE_PAIR(id_487, arg1641_878);
							    }
							    arg1630_870 = symbol_append_197___r4_symbols_6_4(list1640_877);
							 }
							 {
							    obj_t arg1646_880;
							    arg1646_880 = CNST_TABLE_REF(((long) 7));
							    {
							       obj_t list1647_881;
							       {
								  obj_t arg1648_882;
								  {
								     obj_t arg1649_883;
								     arg1649_883 = MAKE_PAIR(id_487, BNIL);
								     arg1648_882 = MAKE_PAIR(_4dots_199_tools_misc, arg1649_883);
								  }
								  list1647_881 = MAKE_PAIR(arg1646_880, arg1648_882);
							       }
							       arg1632_871 = symbol_append_197___r4_symbols_6_4(list1647_881);
							    }
							 }
							 {
							    obj_t list1634_873;
							    {
							       obj_t arg1636_874;
							       arg1636_874 = MAKE_PAIR(BNIL, BNIL);
							       list1634_873 = MAKE_PAIR(arg1632_871, arg1636_874);
							    }
							    arg1621_863 = cons__138___r4_pairs_and_lists_6_3(arg1630_870, list1634_873);
							 }
						      }
						      {
							 obj_t arg1652_885;
							 obj_t arg1653_886;
							 obj_t arg1654_887;
							 arg1652_885 = CNST_TABLE_REF(((long) 15));
							 {
							    obj_t list1660_893;
							    {
							       obj_t arg1663_895;
							       {
								  obj_t arg1665_896;
								  arg1665_896 = MAKE_PAIR(string1868_foreign_cstruct, BNIL);
								  arg1663_895 = MAKE_PAIR(name_sans___18_495, arg1665_896);
							       }
							       list1660_893 = MAKE_PAIR(string1869_foreign_cstruct, arg1663_895);
							    }
							    arg1653_886 = string_append_106___r4_strings_6_7(list1660_893);
							 }
							 arg1654_887 = CNST_TABLE_REF(((long) 7));
							 {
							    obj_t list1656_889;
							    {
							       obj_t arg1657_890;
							       {
								  obj_t arg1658_891;
								  arg1658_891 = MAKE_PAIR(BNIL, BNIL);
								  arg1657_890 = MAKE_PAIR(arg1654_887, arg1658_891);
							       }
							       list1656_889 = MAKE_PAIR(arg1653_886, arg1657_890);
							    }
							    arg1622_864 = cons__138___r4_pairs_and_lists_6_3(arg1652_885, list1656_889);
							 }
						      }
						      {
							 obj_t list1624_866;
							 {
							    obj_t arg1625_867;
							    {
							       obj_t arg1627_868;
							       arg1627_868 = MAKE_PAIR(BNIL, BNIL);
							       arg1625_867 = MAKE_PAIR(arg1622_864, arg1627_868);
							    }
							    list1624_866 = MAKE_PAIR(arg1621_863, arg1625_867);
							 }
							 arg1268_551 = cons__138___r4_pairs_and_lists_6_3(arg1620_862, list1624_866);
						      }
						   }
						   {
						      obj_t arg1716_943;
						      obj_t arg1717_944;
						      obj_t arg1718_945;
						      arg1716_943 = CNST_TABLE_REF(((long) 6));
						      {
							 obj_t arg1725_951;
							 arg1725_951 = CNST_TABLE_REF(((long) 19));
							 {
							    obj_t list1727_953;
							    {
							       obj_t arg1728_954;
							       arg1728_954 = MAKE_PAIR(BNIL, BNIL);
							       list1727_953 = MAKE_PAIR(arg1725_951, arg1728_954);
							    }
							    arg1717_944 = cons__138___r4_pairs_and_lists_6_3(bid__bool_159_493, list1727_953);
							 }
						      }
						      {
							 obj_t arg1730_956;
							 obj_t arg1731_957;
							 obj_t arg1732_958;
							 arg1730_956 = CNST_TABLE_REF(((long) 20));
							 {
							    obj_t arg1744_965;
							    obj_t arg1745_966;
							    arg1744_965 = CNST_TABLE_REF(((long) 21));
							    arg1745_966 = CNST_TABLE_REF(((long) 7));
							    {
							       obj_t list1747_968;
							       {
								  obj_t arg1748_969;
								  arg1748_969 = MAKE_PAIR(BNIL, BNIL);
								  list1747_968 = MAKE_PAIR(arg1745_966, arg1748_969);
							       }
							       arg1731_957 = cons__138___r4_pairs_and_lists_6_3(arg1744_965, list1747_968);
							    }
							 }
							 {
							    obj_t arg1753_971;
							    obj_t arg1755_972;
							    obj_t arg1758_973;
							    arg1753_971 = CNST_TABLE_REF(((long) 22));
							    {
							       obj_t arg1766_979;
							       obj_t arg1767_980;
							       arg1766_979 = CNST_TABLE_REF(((long) 23));
							       arg1767_980 = CNST_TABLE_REF(((long) 7));
							       {
								  obj_t list1769_982;
								  {
								     obj_t arg1770_983;
								     arg1770_983 = MAKE_PAIR(BNIL, BNIL);
								     list1769_982 = MAKE_PAIR(arg1767_980, arg1770_983);
								  }
								  arg1755_972 = cons__138___r4_pairs_and_lists_6_3(arg1766_979, list1769_982);
							       }
							    }
							    {
							       obj_t arg1772_985;
							       arg1772_985 = CNST_TABLE_REF(((long) 24));
							       {
								  obj_t list1774_987;
								  {
								     obj_t arg1776_988;
								     arg1776_988 = MAKE_PAIR(BNIL, BNIL);
								     list1774_987 = MAKE_PAIR(bid_489, arg1776_988);
								  }
								  arg1758_973 = cons__138___r4_pairs_and_lists_6_3(arg1772_985, list1774_987);
							       }
							    }
							    {
							       obj_t list1760_975;
							       {
								  obj_t arg1761_976;
								  {
								     obj_t arg1762_977;
								     arg1762_977 = MAKE_PAIR(BNIL, BNIL);
								     arg1761_976 = MAKE_PAIR(arg1758_973, arg1762_977);
								  }
								  list1760_975 = MAKE_PAIR(arg1755_972, arg1761_976);
							       }
							       arg1732_958 = cons__138___r4_pairs_and_lists_6_3(arg1753_971, list1760_975);
							    }
							 }
							 {
							    obj_t list1734_960;
							    {
							       obj_t arg1738_961;
							       {
								  obj_t arg1739_962;
								  {
								     obj_t arg1740_963;
								     arg1740_963 = MAKE_PAIR(BNIL, BNIL);
								     arg1739_962 = MAKE_PAIR(BFALSE, arg1740_963);
								  }
								  arg1738_961 = MAKE_PAIR(arg1732_958, arg1739_962);
							       }
							       list1734_960 = MAKE_PAIR(arg1731_957, arg1738_961);
							    }
							    arg1718_945 = cons__138___r4_pairs_and_lists_6_3(arg1730_956, list1734_960);
							 }
						      }
						      {
							 obj_t list1721_947;
							 {
							    obj_t arg1722_948;
							    {
							       obj_t arg1723_949;
							       arg1723_949 = MAKE_PAIR(BNIL, BNIL);
							       arg1722_948 = MAKE_PAIR(arg1718_945, arg1723_949);
							    }
							    list1721_947 = MAKE_PAIR(arg1717_944, arg1722_948);
							 }
							 arg1269_552 = cons__138___r4_pairs_and_lists_6_3(arg1716_943, list1721_947);
						      }
						   }
						   {
						      obj_t fields_561;
						      obj_t res_562;
						      fields_561 = cstruct_fields_109_497;
						      res_562 = BNIL;
						    loop_563:
						      if (NULLP(fields_561))
							{
							   arg1270_553 = res_562;
							}
						      else
							{
							   obj_t arg1283_566;
							   obj_t arg1284_567;
							   arg1283_566 = CDR(fields_561);
							   {
							      obj_t arg1285_568;
							      field_570 = CAR(fields_561);
							      {
								 obj_t f_type_id_57_572;
								 f_type_id_57_572 = CAR(field_570);
								 {
								    type_t f_type_179_573;
								    f_type_179_573 = use_type__231_type_env(f_type_id_57_572);
								    {
								       type_t af_type_215_574;
								       af_type_215_574 = get_aliased_type_1_type_type(f_type_179_573);
								       {
									  obj_t f_id_254_575;
									  {
									     obj_t aux_1527;
									     aux_1527 = CDR(field_570);
									     f_id_254_575 = CAR(aux_1527);
									  }
									  {
									     obj_t f_name_115_576;
									     {
										obj_t aux_1530;
										{
										   obj_t aux_1531;
										   aux_1531 = CDR(field_570);
										   aux_1530 = CDR(aux_1531);
										}
										f_name_115_576 = CAR(aux_1530);
									     }
									     {
										obj_t get_name_201_577;
										{
										   obj_t arg1453_704;
										   arg1453_704 = CNST_TABLE_REF(((long) 3));
										   {
										      obj_t list1454_705;
										      {
											 obj_t arg1455_706;
											 {
											    obj_t arg1456_707;
											    arg1456_707 = MAKE_PAIR(f_id_254_575, BNIL);
											    arg1455_706 = MAKE_PAIR(arg1453_704, arg1456_707);
											 }
											 list1454_705 = MAKE_PAIR(id_487, arg1455_706);
										      }
										      get_name_201_577 = symbol_append_197___r4_symbols_6_4(list1454_705);
										   }
										}
										{
										   obj_t set_name_147_578;
										   {
										      obj_t arg1443_697;
										      arg1443_697 = CNST_TABLE_REF(((long) 3));
										      {
											 obj_t list1445_699;
											 {
											    obj_t arg1446_700;
											    {
											       obj_t arg1448_701;
											       {
												  obj_t arg1449_702;
												  {
												     obj_t aux_1541;
												     aux_1541 = CNST_TABLE_REF(((long) 4));
												     arg1449_702 = MAKE_PAIR(aux_1541, BNIL);
												  }
												  arg1448_701 = MAKE_PAIR(f_id_254_575, arg1449_702);
											       }
											       arg1446_700 = MAKE_PAIR(arg1443_697, arg1448_701);
											    }
											    list1445_699 = MAKE_PAIR(id_487, arg1446_700);
											 }
											 set_name_147_578 = symbol_append_197___r4_symbols_6_4(list1445_699);
										      }
										   }
										   {
										      obj_t get_type_id_186_579;
										      {
											 bool_t test1437_692;
											 test1437_692 = is_a__118___object((obj_t) (af_type_215_574), cstruct_foreign_ctype);
											 if (test1437_692)
											   {
											      obj_t list1439_694;
											      {
												 obj_t arg1440_695;
												 {
												    obj_t aux_1551;
												    aux_1551 = CNST_TABLE_REF(((long) 5));
												    arg1440_695 = MAKE_PAIR(aux_1551, BNIL);
												 }
												 list1439_694 = MAKE_PAIR(f_type_id_57_572, arg1440_695);
											      }
											      get_type_id_186_579 = symbol_append_197___r4_symbols_6_4(list1439_694);
											   }
											 else
											   {
											      get_type_id_186_579 = f_type_id_57_572;
											   }
										      }
										      {
											 obj_t struct_ref_fmt_196_580;
											 {
											    bool_t test1411_673;
											    test1411_673 = is_a__118___object((obj_t) (af_type_215_574), cstruct_foreign_ctype);
											    if (test1411_673)
											      {
												 obj_t list1412_674;
												 {
												    obj_t arg1414_676;
												    {
												       obj_t arg1415_677;
												       {
													  obj_t arg1417_679;
													  {
													     obj_t arg1418_680;
													     arg1418_680 = MAKE_PAIR(string1859_foreign_cstruct, BNIL);
													     arg1417_679 = MAKE_PAIR(f_name_115_576, arg1418_680);
													  }
													  arg1415_677 = MAKE_PAIR(string1860_foreign_cstruct, arg1417_679);
												       }
												       arg1414_676 = MAKE_PAIR(name_sans___18_495, arg1415_677);
												    }
												    list1412_674 = MAKE_PAIR(string1861_foreign_cstruct, arg1414_676);
												 }
												 struct_ref_fmt_196_580 = string_append_106___r4_strings_6_7(list1412_674);
											      }
											    else
											      {
												 obj_t list1422_683;
												 {
												    obj_t arg1426_685;
												    {
												       obj_t arg1427_686;
												       {
													  obj_t arg1431_688;
													  {
													     obj_t arg1432_689;
													     arg1432_689 = MAKE_PAIR(string1862_foreign_cstruct, BNIL);
													     arg1431_688 = MAKE_PAIR(f_name_115_576, arg1432_689);
													  }
													  arg1427_686 = MAKE_PAIR(string1860_foreign_cstruct, arg1431_688);
												       }
												       arg1426_685 = MAKE_PAIR(name_sans___18_495, arg1427_686);
												    }
												    list1422_683 = MAKE_PAIR(string1863_foreign_cstruct, arg1426_685);
												 }
												 struct_ref_fmt_196_580 = string_append_106___r4_strings_6_7(list1422_683);
											      }
											 }
											 {
											    obj_t struct_set_fmt_62_581;
											    {
											       obj_t list1398_664;
											       {
												  obj_t arg1401_666;
												  {
												     obj_t arg1402_667;
												     {
													obj_t arg1405_669;
													{
													   obj_t arg1407_670;
													   arg1407_670 = MAKE_PAIR(string1862_foreign_cstruct, BNIL);
													   arg1405_669 = MAKE_PAIR(f_name_115_576, arg1407_670);
													}
													arg1402_667 = MAKE_PAIR(string1860_foreign_cstruct, arg1405_669);
												     }
												     arg1401_666 = MAKE_PAIR(name_sans___18_495, arg1402_667);
												  }
												  list1398_664 = MAKE_PAIR(string1864_foreign_cstruct, arg1401_666);
											       }
											       struct_set_fmt_62_581 = string_append_106___r4_strings_6_7(list1398_664);
											    }
											    {
											       char *struct_setv_fmt_62_582;
											       {
												  bool_t test1397_663;
												  test1397_663 = is_a__118___object((obj_t) (af_type_215_574), cstruct_foreign_ctype);
												  if (test1397_663)
												    {
												       struct_setv_fmt_62_582 = " = (*($2)), BUNSPEC)";
												    }
												  else
												    {
												       struct_setv_fmt_62_582 = " = ($2), BUNSPEC)";
												    }
											       }
											       {
												  {
												     obj_t arg1288_583;
												     obj_t arg1290_584;
												     {
													obj_t arg1295_588;
													obj_t arg1296_589;
													obj_t arg1297_590;
													arg1295_588 = CNST_TABLE_REF(((long) 6));
													{
													   obj_t arg1303_596;
													   obj_t arg1304_597;
													   {
													      obj_t list1311_602;
													      {
														 obj_t arg1313_603;
														 {
														    obj_t arg1315_604;
														    arg1315_604 = MAKE_PAIR(get_type_id_186_579, BNIL);
														    arg1313_603 = MAKE_PAIR(_4dots_199_tools_misc, arg1315_604);
														 }
														 list1311_602 = MAKE_PAIR(get_name_201_577, arg1313_603);
													      }
													      arg1303_596 = symbol_append_197___r4_symbols_6_4(list1311_602);
													   }
													   {
													      obj_t arg1319_606;
													      arg1319_606 = CNST_TABLE_REF(((long) 7));
													      {
														 obj_t list1320_607;
														 {
														    obj_t arg1321_608;
														    {
														       obj_t arg1322_609;
														       arg1322_609 = MAKE_PAIR(id_487, BNIL);
														       arg1321_608 = MAKE_PAIR(_4dots_199_tools_misc, arg1322_609);
														    }
														    list1320_607 = MAKE_PAIR(arg1319_606, arg1321_608);
														 }
														 arg1304_597 = symbol_append_197___r4_symbols_6_4(list1320_607);
													      }
													   }
													   {
													      obj_t list1308_599;
													      {
														 obj_t arg1309_600;
														 arg1309_600 = MAKE_PAIR(BNIL, BNIL);
														 list1308_599 = MAKE_PAIR(arg1304_597, arg1309_600);
													      }
													      arg1296_589 = cons__138___r4_pairs_and_lists_6_3(arg1303_596, list1308_599);
													   }
													}
													{
													   obj_t arg1324_611;
													   obj_t arg1325_612;
													   {
													      obj_t arg1332_618;
													      arg1332_618 = CNST_TABLE_REF(((long) 8));
													      {
														 obj_t list1333_619;
														 {
														    obj_t arg1334_620;
														    {
														       obj_t arg1337_621;
														       arg1337_621 = MAKE_PAIR(get_type_id_186_579, BNIL);
														       arg1334_620 = MAKE_PAIR(_4dots_199_tools_misc, arg1337_621);
														    }
														    list1333_619 = MAKE_PAIR(arg1332_618, arg1334_620);
														 }
														 arg1324_611 = symbol_append_197___r4_symbols_6_4(list1333_619);
													      }
													   }
													   arg1325_612 = CNST_TABLE_REF(((long) 7));
													   {
													      obj_t list1327_614;
													      {
														 obj_t arg1328_615;
														 {
														    obj_t arg1330_616;
														    arg1330_616 = MAKE_PAIR(BNIL, BNIL);
														    arg1328_615 = MAKE_PAIR(arg1325_612, arg1330_616);
														 }
														 list1327_614 = MAKE_PAIR(struct_ref_fmt_196_580, arg1328_615);
													      }
													      arg1297_590 = cons__138___r4_pairs_and_lists_6_3(arg1324_611, list1327_614);
													   }
													}
													{
													   obj_t list1299_592;
													   {
													      obj_t arg1300_593;
													      {
														 obj_t arg1301_594;
														 arg1301_594 = MAKE_PAIR(BNIL, BNIL);
														 arg1300_593 = MAKE_PAIR(arg1297_590, arg1301_594);
													      }
													      list1299_592 = MAKE_PAIR(arg1296_589, arg1300_593);
													   }
													   arg1288_583 = cons__138___r4_pairs_and_lists_6_3(arg1295_588, list1299_592);
													}
												     }
												     {
													obj_t arg1340_623;
													obj_t arg1342_624;
													obj_t arg1343_625;
													arg1340_623 = CNST_TABLE_REF(((long) 6));
													{
													   obj_t arg1351_631;
													   obj_t arg1352_632;
													   obj_t arg1353_633;
													   {
													      obj_t list1365_640;
													      {
														 obj_t arg1367_641;
														 {
														    obj_t aux_1608;
														    aux_1608 = CNST_TABLE_REF(((long) 9));
														    arg1367_641 = MAKE_PAIR(aux_1608, BNIL);
														 }
														 list1365_640 = MAKE_PAIR(set_name_147_578, arg1367_641);
													      }
													      arg1351_631 = symbol_append_197___r4_symbols_6_4(list1365_640);
													   }
													   {
													      obj_t arg1369_643;
													      arg1369_643 = CNST_TABLE_REF(((long) 7));
													      {
														 obj_t list1370_644;
														 {
														    obj_t arg1372_645;
														    {
														       obj_t arg1373_646;
														       arg1373_646 = MAKE_PAIR(id_487, BNIL);
														       arg1372_645 = MAKE_PAIR(_4dots_199_tools_misc, arg1373_646);
														    }
														    list1370_644 = MAKE_PAIR(arg1369_643, arg1372_645);
														 }
														 arg1352_632 = symbol_append_197___r4_symbols_6_4(list1370_644);
													      }
													   }
													   {
													      obj_t arg1378_648;
													      arg1378_648 = CNST_TABLE_REF(((long) 10));
													      {
														 obj_t list1379_649;
														 {
														    obj_t arg1381_650;
														    {
														       obj_t arg1383_651;
														       arg1383_651 = MAKE_PAIR(get_type_id_186_579, BNIL);
														       arg1381_650 = MAKE_PAIR(_4dots_199_tools_misc, arg1383_651);
														    }
														    list1379_649 = MAKE_PAIR(arg1378_648, arg1381_650);
														 }
														 arg1353_633 = symbol_append_197___r4_symbols_6_4(list1379_649);
													      }
													   }
													   {
													      obj_t list1356_635;
													      {
														 obj_t arg1357_636;
														 {
														    obj_t arg1361_637;
														    arg1361_637 = MAKE_PAIR(BNIL, BNIL);
														    arg1357_636 = MAKE_PAIR(arg1353_633, arg1361_637);
														 }
														 list1356_635 = MAKE_PAIR(arg1352_632, arg1357_636);
													      }
													      arg1342_624 = cons__138___r4_pairs_and_lists_6_3(arg1351_631, list1356_635);
													   }
													}
													{
													   obj_t arg1385_653;
													   obj_t arg1387_654;
													   obj_t arg1388_655;
													   obj_t arg1389_656;
													   arg1385_653 = CNST_TABLE_REF(((long) 8));
													   {
													      obj_t aux_1628;
													      aux_1628 = string_to_bstring(struct_setv_fmt_62_582);
													      arg1387_654 = string_append(struct_set_fmt_62_581, aux_1628);
													   }
													   arg1388_655 = CNST_TABLE_REF(((long) 7));
													   arg1389_656 = CNST_TABLE_REF(((long) 10));
													   {
													      obj_t list1391_658;
													      {
														 obj_t arg1392_659;
														 {
														    obj_t arg1393_660;
														    {
														       obj_t arg1395_661;
														       arg1395_661 = MAKE_PAIR(BNIL, BNIL);
														       arg1393_660 = MAKE_PAIR(arg1389_656, arg1395_661);
														    }
														    arg1392_659 = MAKE_PAIR(arg1388_655, arg1393_660);
														 }
														 list1391_658 = MAKE_PAIR(arg1387_654, arg1392_659);
													      }
													      arg1343_625 = cons__138___r4_pairs_and_lists_6_3(arg1385_653, list1391_658);
													   }
													}
													{
													   obj_t list1345_627;
													   {
													      obj_t arg1347_628;
													      {
														 obj_t arg1349_629;
														 arg1349_629 = MAKE_PAIR(BNIL, BNIL);
														 arg1347_628 = MAKE_PAIR(arg1343_625, arg1349_629);
													      }
													      list1345_627 = MAKE_PAIR(arg1342_624, arg1347_628);
													   }
													   arg1290_584 = cons__138___r4_pairs_and_lists_6_3(arg1340_623, list1345_627);
													}
												     }
												     {
													obj_t list1291_585;
													{
													   obj_t arg1292_586;
													   arg1292_586 = MAKE_PAIR(arg1290_584, BNIL);
													   list1291_585 = MAKE_PAIR(arg1288_583, arg1292_586);
													}
													arg1285_568 = list1291_585;
												     }
												  }
											       }
											    }
											 }
										      }
										   }
										}
									     }
									  }
								       }
								    }
								 }
							      }
							      arg1284_567 = append_2_18___r4_pairs_and_lists_6_3(arg1285_568, res_562);
							   }
							   {
							      obj_t res_1647;
							      obj_t fields_1646;
							      fields_1646 = arg1283_566;
							      res_1647 = arg1284_567;
							      res_562 = res_1647;
							      fields_561 = fields_1646;
							      goto loop_563;
							   }
							}
						   }
						   {
						      obj_t list1271_554;
						      {
							 obj_t arg1272_555;
							 {
							    obj_t arg1273_556;
							    {
							       obj_t arg1274_557;
							       {
								  obj_t arg1277_558;
								  arg1277_558 = MAKE_PAIR(arg1270_553, BNIL);
								  arg1274_557 = MAKE_PAIR(arg1269_552, arg1277_558);
							       }
							       arg1273_556 = MAKE_PAIR(arg1268_551, arg1274_557);
							    }
							    arg1272_555 = MAKE_PAIR(arg1267_550, arg1273_556);
							 }
							 list1271_554 = MAKE_PAIR(arg1265_549, arg1272_555);
						      }
						      return cons__138___r4_pairs_and_lists_6_3(arg1263_548, list1271_554);
						   }
						}
					     }
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* make-ctype-accesses!-cstruct */ obj_t 
make_ctype_accesses__cstruct_205_foreign_cstruct(obj_t env_1160, obj_t what_1161, obj_t who_1162)
{
   {
      cstruct_t what_476;
      type_t who_477;
      what_476 = (cstruct_t) (what_1161);
      who_477 = (type_t) (who_1162);
      return BNIL;
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_foreign_cstruct()
{
   module_initialization_70_tools_trace(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70_type_tools(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70_type_type(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70_type_env(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70_tools_shape(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70_tools_misc(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70_foreign_ctype(((long) 0), "FOREIGN_CSTRUCT");
   module_initialization_70_foreign_access(((long) 0), "FOREIGN_CSTRUCT");
   return module_initialization_70_module_module(((long) 0), "FOREIGN_CSTRUCT");
}
