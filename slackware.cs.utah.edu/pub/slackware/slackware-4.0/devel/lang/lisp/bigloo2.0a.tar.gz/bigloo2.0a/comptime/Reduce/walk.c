/*===========================================================================*/
/*   (Reduce/walk.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_reduce_walk();
static obj_t _reduce_walk__13_reduce_walk(obj_t, obj_t);
extern obj_t _optim__89_engine_param;
extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t reduce_copy__103_reduce_copy(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_reduce_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_reduce_copy(long, char *);
extern obj_t module_initialization_70_reduce_cse(long, char *);
extern obj_t module_initialization_70_reduce_cond(long, char *);
extern obj_t module_initialization_70_reduce_typec(long, char *);
extern obj_t module_initialization_70_reduce_1occ(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t reduce_1occ__237_reduce_1occ(obj_t);
static obj_t imported_modules_init_94_reduce_walk();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t library_modules_init_112_reduce_walk();
extern obj_t reduce_conditional__50_reduce_cond(obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t reduce_walk__148_reduce_walk(obj_t);
extern obj_t remove_var_123_ast_remove(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t reduce_type_check__95_reduce_typec(obj_t);
extern obj_t reduce_cse__211_reduce_cse(obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_reduce_walk = BUNSPEC;
static obj_t cnst_init_137_reduce_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(reduce_walk__env_82_reduce_walk, _reduce_walk__13_reduce_walk1586, _reduce_walk__13_reduce_walk, 0L, 1);
DEFINE_STRING(string1579_reduce_walk, string1579_reduce_walk1587, "failure during postlude hook", 28);
DEFINE_STRING(string1580_reduce_walk, string1580_reduce_walk1588, "REDUCE PASS-STARTED ", 20);
DEFINE_STRING(string1578_reduce_walk, string1578_reduce_walk1589, " error", 6);
DEFINE_STRING(string1577_reduce_walk, string1577_reduce_walk1590, " occured, ending ...", 20);
DEFINE_STRING(string1576_reduce_walk, string1576_reduce_walk1591, "failure during prelude hook", 27);
DEFINE_STRING(string1575_reduce_walk, string1575_reduce_walk1592, "   . ", 5);
DEFINE_STRING(string1574_reduce_walk, string1574_reduce_walk1593, "Reduction", 9);


/* module-initialization */ obj_t 
module_initialization_70_reduce_walk(long checksum_1095, char *from_1096)
{
   if (CBOOL(require_initialization_114_reduce_walk))
     {
	require_initialization_114_reduce_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_reduce_walk();
	cnst_init_137_reduce_walk();
	imported_modules_init_94_reduce_walk();
	method_init_76_reduce_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_reduce_walk()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "REDUCE_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "REDUCE_WALK");
   module_initialization_70___reader(((long) 0), "REDUCE_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_reduce_walk()
{
   {
      obj_t cnst_port_138_1087;
      cnst_port_138_1087 = open_input_string(string1580_reduce_walk);
      {
	 long i_1088;
	 i_1088 = ((long) 1);
       loop_1089:
	 {
	    bool_t test1581_1090;
	    test1581_1090 = (i_1088 == ((long) -1));
	    if (test1581_1090)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1582_1091;
		    {
		       obj_t list1583_1092;
		       {
			  obj_t arg1584_1093;
			  arg1584_1093 = BNIL;
			  list1583_1092 = MAKE_PAIR(cnst_port_138_1087, arg1584_1093);
		       }
		       arg1582_1091 = read___reader(list1583_1092);
		    }
		    CNST_TABLE_SET(i_1088, arg1582_1091);
		 }
		 {
		    int aux_1094;
		    {
		       long aux_1113;
		       aux_1113 = (i_1088 - ((long) 1));
		       aux_1094 = (int) (aux_1113);
		    }
		    {
		       long i_1116;
		       i_1116 = (long) (aux_1094);
		       i_1088 = i_1116;
		       goto loop_1089;
		    }
		 }
	      }
	 }
      }
   }
}


/* reduce-walk! */ obj_t 
reduce_walk__148_reduce_walk(obj_t globals_1)
{
   {
      obj_t list1435_693;
      {
	 obj_t arg1437_695;
	 {
	    obj_t arg1440_697;
	    {
	       obj_t aux_1118;
	       aux_1118 = BCHAR(((unsigned char) '\n'));
	       arg1440_697 = MAKE_PAIR(aux_1118, BNIL);
	    }
	    arg1437_695 = MAKE_PAIR(string1574_reduce_walk, arg1440_697);
	 }
	 list1435_693 = MAKE_PAIR(string1575_reduce_walk, arg1437_695);
      }
      verbose_tools_speek(BINT(((long) 1)), list1435_693);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1574_reduce_walk;
   {
      obj_t hooks_699;
      obj_t hnames_700;
      hooks_699 = BNIL;
      hnames_700 = BNIL;
    loop_701:
      if (NULLP(hooks_699))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1447_706;
	   {
	      obj_t fun1455_712;
	      fun1455_712 = CAR(hooks_699);
	      {
		 obj_t aux_1130;
		 aux_1130 = PROCEDURE_ENTRY(fun1455_712) (fun1455_712, BEOA);
		 test1447_706 = CBOOL(aux_1130);
	      }
	   }
	   if (test1447_706)
	     {
		{
		   obj_t hnames_1137;
		   obj_t hooks_1135;
		   hooks_1135 = CDR(hooks_699);
		   hnames_1137 = CDR(hnames_700);
		   hnames_700 = hnames_1137;
		   hooks_699 = hooks_1135;
		   goto loop_701;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1574_reduce_walk, string1576_reduce_walk, CAR(hnames_700));
	     }
	}
   }
   reduce_copy__103_reduce_copy(globals_1);
   {
      bool_t test1456_713;
      {
	 long n1_1072;
	 n1_1072 = (long) CINT(_optim__89_engine_param);
	 test1456_713 = (n1_1072 >= ((long) 2));
      }
      if (test1456_713)
	{
	   reduce_cse__211_reduce_cse(globals_1);
	}
      else
	{
	   BUNSPEC;
	}
   }
   reduce_type_check__95_reduce_typec(globals_1);
   reduce_copy__103_reduce_copy(globals_1);
   reduce_conditional__50_reduce_cond(globals_1);
   reduce_1occ__237_reduce_1occ(globals_1);
   {
      obj_t value_714;
      value_714 = remove_var_123_ast_remove(CNST_TABLE_REF(((long) 1)), globals_1);
      {
	 bool_t test1457_715;
	 {
	    long n1_1074;
	    n1_1074 = (long) CINT(_nb_error_on_pass__70_tools_error);
	    test1457_715 = (n1_1074 > ((long) 0));
	 }
	 if (test1457_715)
	   {
	      {
		 char *arg1461_718;
		 {
		    bool_t test1469_725;
		    {
		       bool_t test1470_726;
		       {
			  obj_t obj_1076;
			  obj_1076 = _nb_error_on_pass__70_tools_error;
			  test1470_726 = INTEGERP(obj_1076);
		       }
		       if (test1470_726)
			 {
			    test1469_725 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
			 }
		       else
			 {
			    test1469_725 = ((bool_t) 0);
			 }
		    }
		    if (test1469_725)
		      {
			 arg1461_718 = "s";
		      }
		    else
		      {
			 arg1461_718 = "";
		      }
		 }
		 {
		    obj_t list1464_720;
		    {
		       obj_t arg1465_721;
		       {
			  obj_t arg1466_722;
			  {
			     obj_t arg1467_723;
			     arg1467_723 = MAKE_PAIR(string1577_reduce_walk, BNIL);
			     {
				obj_t aux_1161;
				aux_1161 = string_to_bstring(arg1461_718);
				arg1466_722 = MAKE_PAIR(aux_1161, arg1467_723);
			     }
			  }
			  arg1465_721 = MAKE_PAIR(string1578_reduce_walk, arg1466_722);
		       }
		       list1464_720 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1465_721);
		    }
		    fprint___r4_output_6_10_3(current_error_port, list1464_720);
		 }
	      }
	      {
		 obj_t res1573_1078;
		 exit(((long) -1));
		 res1573_1078 = BINT(((long) -1));
		 return res1573_1078;
	      }
	   }
	 else
	   {
	      obj_t hooks_727;
	      obj_t hnames_728;
	      hooks_727 = BNIL;
	      hnames_728 = BNIL;
	    loop_729:
	      if (NULLP(hooks_727))
		{
		   return value_714;
		}
	      else
		{
		   bool_t test1476_734;
		   {
		      obj_t fun1481_739;
		      fun1481_739 = CAR(hooks_727);
		      {
			 obj_t aux_1172;
			 aux_1172 = PROCEDURE_ENTRY(fun1481_739) (fun1481_739, BEOA);
			 test1476_734 = CBOOL(aux_1172);
		      }
		   }
		   if (test1476_734)
		     {
			{
			   obj_t hnames_1179;
			   obj_t hooks_1177;
			   hooks_1177 = CDR(hooks_727);
			   hnames_1179 = CDR(hnames_728);
			   hnames_728 = hnames_1179;
			   hooks_727 = hooks_1177;
			   goto loop_729;
			}
		     }
		   else
		     {
			return internal_error_43_tools_error(_current_pass__25_engine_pass, string1579_reduce_walk, CAR(hnames_728));
		     }
		}
	   }
      }
   }
}


/* _reduce-walk! */ obj_t 
_reduce_walk__13_reduce_walk(obj_t env_1085, obj_t globals_1086)
{
   return reduce_walk__148_reduce_walk(globals_1086);
}


/* method-init */ obj_t 
method_init_76_reduce_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_reduce_walk()
{
   module_initialization_70_tools_speek(((long) 0), "REDUCE_WALK");
   module_initialization_70_tools_error(((long) 0), "REDUCE_WALK");
   module_initialization_70_engine_pass(((long) 0), "REDUCE_WALK");
   module_initialization_70_tools_shape(((long) 0), "REDUCE_WALK");
   module_initialization_70_engine_param(((long) 0), "REDUCE_WALK");
   module_initialization_70_type_type(((long) 0), "REDUCE_WALK");
   module_initialization_70_ast_var(((long) 0), "REDUCE_WALK");
   module_initialization_70_ast_node(((long) 0), "REDUCE_WALK");
   module_initialization_70_reduce_copy(((long) 0), "REDUCE_WALK");
   module_initialization_70_reduce_cse(((long) 0), "REDUCE_WALK");
   module_initialization_70_reduce_cond(((long) 0), "REDUCE_WALK");
   module_initialization_70_reduce_typec(((long) 0), "REDUCE_WALK");
   module_initialization_70_reduce_1occ(((long) 0), "REDUCE_WALK");
   return module_initialization_70_ast_remove(((long) 0), "REDUCE_WALK");
}
