/*===========================================================================*/
/*   (Cfa/struct.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_struct();
static obj_t node_setup__pre_struct_ref_app_157_cfa_struct(obj_t, obj_t);
extern obj_t pre_struct_set__app_116_cfa_info;
extern obj_t pre_make_struct_app_218_cfa_info;
static obj_t node_setup__pre_struct_set__app_230_cfa_struct(obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t _obj__252_type_cache;
extern approx_t make_type_approx_184_cfa_approx(type_t);
static obj_t node_setup__pre_make_struct_app_238_cfa_struct(obj_t, obj_t);
extern approx_t make_empty_approx_131_cfa_approx();
extern obj_t struct_set__app_162_cfa_info;
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t stack_loose_alloc__make_struct_app_85_cfa_struct(obj_t, obj_t, obj_t);
extern obj_t _unspec__87_type_cache;
extern obj_t make_struct_app_214_cfa_info;
extern obj_t module_initialization_70_cfa_struct(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_cfa_setup(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_stack(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t pre_struct_ref_app_207_cfa_info;
extern approx_t union_approx__241_cfa_approx(approx_t, approx_t);
extern long class_num_218___object(obj_t);
static obj_t cfa__struct_ref_app_92_cfa_struct(obj_t, obj_t);
extern obj_t node_setup___185_cfa_setup(obj_t);
static obj_t _stack_loose_alloc_2464_8_cfa_loose(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_cfa_struct();
static obj_t _loose_alloc_2457_139_cfa_loose(obj_t, obj_t);
extern obj_t stack_loose_alloc__95_cfa_loose(node_t, obj_t);
extern obj_t stack___129_cfa_stack(obj_t);
extern obj_t approx_set_top__187_cfa_approx(approx_t);
static obj_t library_modules_init_112_cfa_struct();
extern approx_t cfa__102_cfa_cfa(node_t);
extern node_t node_heap__stack__239_cfa_stack(app_t, bool_t);
static obj_t _node_setup_2459_167_cfa_setup(obj_t, obj_t);
static obj_t arg2440_cfa_struct(obj_t, obj_t);
static obj_t arg2436_cfa_struct(obj_t, obj_t);
static obj_t arg2417_cfa_struct(obj_t, obj_t);
extern obj_t for_each_approx_alloc_83_cfa_approx(obj_t, approx_t);
static obj_t arg2402_cfa_struct(obj_t, obj_t);
static obj_t toplevel_init_63_cfa_struct();
extern obj_t open_input_string(obj_t);
static obj_t loose_alloc__make_struct_app_81_cfa_struct(obj_t, obj_t);
extern obj_t struct_ref_app_73_cfa_info;
static obj_t _cfa_2461_210_cfa_cfa(obj_t, obj_t);
extern obj_t approx_set_type__239_cfa_approx(approx_t, type_t);
extern obj_t variable_ast_var;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t cfa__struct_set__app_51_cfa_struct(obj_t, obj_t);
static obj_t cfa__make_struct_app_189_cfa_struct(obj_t, obj_t);
static obj_t _stack_2466_33_cfa_stack(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
extern obj_t _cfa_stamp__16_cfa_iterate;
static obj_t require_initialization_114_cfa_struct = BUNSPEC;
extern approx_t make_type_alloc_approx_134_cfa_approx(type_t, node_t);
extern approx_t loose__226_cfa_loose(approx_t, obj_t);
extern obj_t class_super_145___object(obj_t);
static obj_t stack__make_struct_app_69_cfa_struct(obj_t, obj_t);
extern obj_t _struct__183_type_cache;
static obj_t cnst_init_137_cfa_struct();
static obj_t __cnst[1];

extern obj_t loose_alloc__env_83_cfa_loose;
DEFINE_STATIC_PROCEDURE(proc2476_cfa_struct, arg2436_cfa_struct2483, arg2436_cfa_struct, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2475_cfa_struct, stack__make_struct_app_69_cfa_struct2484, stack__make_struct_app_69_cfa_struct, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2474_cfa_struct, stack_loose_alloc__make_struct_app_85_cfa_struct2485, stack_loose_alloc__make_struct_app_85_cfa_struct, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2473_cfa_struct, loose_alloc__make_struct_app_81_cfa_struct2486, loose_alloc__make_struct_app_81_cfa_struct, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2472_cfa_struct, cfa__struct_set__app_51_cfa_struct2487, cfa__struct_set__app_51_cfa_struct, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2471_cfa_struct, cfa__struct_ref_app_92_cfa_struct2488, cfa__struct_ref_app_92_cfa_struct, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2469_cfa_struct, node_setup__pre_struct_set__app_230_cfa_struct2489, node_setup__pre_struct_set__app_230_cfa_struct, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2470_cfa_struct, cfa__make_struct_app_189_cfa_struct2490, cfa__make_struct_app_189_cfa_struct, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2468_cfa_struct, node_setup__pre_struct_ref_app_157_cfa_struct2491, node_setup__pre_struct_ref_app_157_cfa_struct, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2467_cfa_struct, node_setup__pre_make_struct_app_238_cfa_struct2492, node_setup__pre_make_struct_app_238_cfa_struct, 0L, 1);
extern obj_t cfa__env_153_cfa_cfa;
extern obj_t stack_loose_alloc__env_147_cfa_loose;
DEFINE_STRING(string2477_cfa_struct, string2477_cfa_struct2493, "ALL ", 4);
extern obj_t node_setup__env_214_cfa_setup;
extern obj_t stack__env_104_cfa_stack;


/* module-initialization */ obj_t 
module_initialization_70_cfa_struct(long checksum_3572, char *from_3573)
{
   if (CBOOL(require_initialization_114_cfa_struct))
     {
	require_initialization_114_cfa_struct = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_struct();
	cnst_init_137_cfa_struct();
	imported_modules_init_94_cfa_struct();
	method_init_76_cfa_struct();
	toplevel_init_63_cfa_struct();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_struct()
{
   module_initialization_70___object(((long) 0), "CFA_STRUCT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_STRUCT");
   module_initialization_70___reader(((long) 0), "CFA_STRUCT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_struct()
{
   {
      obj_t cnst_port_138_3564;
      cnst_port_138_3564 = open_input_string(string2477_cfa_struct);
      {
	 long i_3565;
	 i_3565 = ((long) 0);
       loop_3566:
	 {
	    bool_t test2478_3567;
	    test2478_3567 = (i_3565 == ((long) -1));
	    if (test2478_3567)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2479_3568;
		    {
		       obj_t list2480_3569;
		       {
			  obj_t arg2481_3570;
			  arg2481_3570 = BNIL;
			  list2480_3569 = MAKE_PAIR(cnst_port_138_3564, arg2481_3570);
		       }
		       arg2479_3568 = read___reader(list2480_3569);
		    }
		    CNST_TABLE_SET(i_3565, arg2479_3568);
		 }
		 {
		    int aux_3571;
		    {
		       long aux_3591;
		       aux_3591 = (i_3565 - ((long) 1));
		       aux_3571 = (int) (aux_3591);
		    }
		    {
		       long i_3594;
		       i_3594 = (long) (aux_3571);
		       i_3565 = i_3594;
		       goto loop_3566;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_struct()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_cfa_struct()
{
   {
      obj_t node_setup__pre_make_struct_app_238_3524;
      node_setup__pre_make_struct_app_238_3524 = proc2467_cfa_struct;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_make_struct_app_218_cfa_info, node_setup__pre_make_struct_app_238_3524);
   }
   {
      obj_t node_setup__pre_struct_ref_app_157_3523;
      node_setup__pre_struct_ref_app_157_3523 = proc2468_cfa_struct;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_struct_ref_app_207_cfa_info, node_setup__pre_struct_ref_app_157_3523);
   }
   {
      obj_t node_setup__pre_struct_set__app_230_3522;
      node_setup__pre_struct_set__app_230_3522 = proc2469_cfa_struct;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_struct_set__app_116_cfa_info, node_setup__pre_struct_set__app_230_3522);
   }
   {
      obj_t cfa__make_struct_app_189_3521;
      cfa__make_struct_app_189_3521 = proc2470_cfa_struct;
      add_method__1___object(cfa__env_153_cfa_cfa, make_struct_app_214_cfa_info, cfa__make_struct_app_189_3521);
   }
   {
      obj_t cfa__struct_ref_app_92_3520;
      cfa__struct_ref_app_92_3520 = proc2471_cfa_struct;
      add_method__1___object(cfa__env_153_cfa_cfa, struct_ref_app_73_cfa_info, cfa__struct_ref_app_92_3520);
   }
   {
      obj_t cfa__struct_set__app_51_3518;
      cfa__struct_set__app_51_3518 = proc2472_cfa_struct;
      add_method__1___object(cfa__env_153_cfa_cfa, struct_set__app_162_cfa_info, cfa__struct_set__app_51_3518);
   }
   {
      obj_t loose_alloc__make_struct_app_81_3514;
      loose_alloc__make_struct_app_81_3514 = proc2473_cfa_struct;
      add_method__1___object(loose_alloc__env_83_cfa_loose, make_struct_app_214_cfa_info, loose_alloc__make_struct_app_81_3514);
   }
   {
      obj_t stack_loose_alloc__make_struct_app_85_3513;
      stack_loose_alloc__make_struct_app_85_3513 = proc2474_cfa_struct;
      add_method__1___object(stack_loose_alloc__env_147_cfa_loose, make_struct_app_214_cfa_info, stack_loose_alloc__make_struct_app_85_3513);
   }
   {
      obj_t stack__make_struct_app_69_3510;
      stack__make_struct_app_69_3510 = proc2475_cfa_struct;
      return add_method__1___object(stack__env_104_cfa_stack, make_struct_app_214_cfa_info, stack__make_struct_app_69_3510);
   }
}


/* stack!-make-struct-app */ obj_t 
stack__make_struct_app_69_cfa_struct(obj_t env_3525, obj_t node_3526)
{
   {
      make_struct_app_214_t node_3011;
      {
	 node_t aux_3605;
	 node_3011 = (make_struct_app_214_t) (node_3526);
	 {
	    obj_t aux_3606;
	    {
	       app_t obj_3505;
	       obj_3505 = (app_t) (node_3011);
	       aux_3606 = (((app_t) CREF(obj_3505))->args);
	    }
	    stack___129_cfa_stack(aux_3606);
	 }
	 {
	    bool_t aux_3610;
	    {
	       bool_t test_3612;
	       {
		  long aux_3613;
		  {
		     obj_t aux_3614;
		     {
			object_t aux_3615;
			aux_3615 = (object_t) (node_3011);
			aux_3614 = OBJECT_WIDENING(aux_3615);
		     }
		     aux_3613 = (((make_struct_app_214_t) CREF(aux_3614))->lost_stamp_114);
		  }
		  test_3612 = (aux_3613 == ((long) -1));
	       }
	       if (test_3612)
		 {
		    obj_t aux_3620;
		    {
		       object_t aux_3621;
		       aux_3621 = (object_t) (node_3011);
		       aux_3620 = OBJECT_WIDENING(aux_3621);
		    }
		    aux_3610 = (((make_struct_app_214_t) CREF(aux_3620))->stackable__42);
		 }
	       else
		 {
		    aux_3610 = ((bool_t) 0);
		 }
	    }
	    aux_3605 = node_heap__stack__239_cfa_stack((app_t) (node_3011), aux_3610);
	 }
	 return (obj_t) (aux_3605);
      }
   }
}


/* stack-loose-alloc!-make-struct-app */ obj_t 
stack_loose_alloc__make_struct_app_85_cfa_struct(obj_t env_3527, obj_t alloc_3528, obj_t cowner_3529)
{
   {
      make_struct_app_214_t alloc_2985;
      obj_t cowner_2986;
      alloc_2985 = (make_struct_app_214_t) (alloc_3528);
      cowner_2986 = cowner_3529;
      {
	 bool_t test_3628;
	 {
	    bool_t test_3629;
	    {
	       obj_t aux_3630;
	       {
		  object_t aux_3631;
		  aux_3631 = (object_t) (alloc_2985);
		  aux_3630 = OBJECT_WIDENING(aux_3631);
	       }
	       test_3629 = (((make_struct_app_214_t) CREF(aux_3630))->stackable__42);
	    }
	    if (test_3629)
	      {
		 obj_t aux_3635;
		 {
		    obj_t aux_3636;
		    {
		       obj_t aux_3637;
		       {
			  object_t aux_3638;
			  aux_3638 = (object_t) (alloc_2985);
			  aux_3637 = OBJECT_WIDENING(aux_3638);
		       }
		       aux_3636 = (((make_struct_app_214_t) CREF(aux_3637))->stack_stamp_31);
		    }
		    aux_3635 = memq___r4_pairs_and_lists_6_3(cowner_2986, aux_3636);
		 }
		 test_3628 = CBOOL(aux_3635);
	      }
	    else
	      {
		 test_3628 = ((bool_t) 1);
	      }
	 }
	 if (test_3628)
	   {
	      return BUNSPEC;
	   }
	 else
	   {
	      {
		 obj_t arg2433_2991;
		 {
		    obj_t aux_3644;
		    {
		       obj_t aux_3645;
		       {
			  object_t aux_3646;
			  aux_3646 = (object_t) (alloc_2985);
			  aux_3645 = OBJECT_WIDENING(aux_3646);
		       }
		       aux_3644 = (((make_struct_app_214_t) CREF(aux_3645))->stack_stamp_31);
		    }
		    arg2433_2991 = MAKE_PAIR(cowner_2986, aux_3644);
		 }
		 {
		    obj_t aux_3651;
		    {
		       object_t aux_3652;
		       aux_3652 = (object_t) (alloc_2985);
		       aux_3651 = OBJECT_WIDENING(aux_3652);
		    }
		    ((((make_struct_app_214_t) CREF(aux_3651))->stack_stamp_31) = ((obj_t) arg2433_2991), BUNSPEC);
		 }
	      }
	      {
		 bool_t test2435_2993;
		 {
		    bool_t test2443_3005;
		    test2443_3005 = is_a__118___object(cowner_2986, variable_ast_var);
		    if (test2443_3005)
		      {
			 obj_t aux_3658;
			 {
			    variable_t aux_3659;
			    {
			       obj_t aux_3660;
			       {
				  object_t aux_3661;
				  aux_3661 = (object_t) (alloc_2985);
				  aux_3660 = OBJECT_WIDENING(aux_3661);
			       }
			       aux_3659 = (((make_struct_app_214_t) CREF(aux_3660))->owner);
			    }
			    aux_3658 = (obj_t) (aux_3659);
			 }
			 test2435_2993 = (aux_3658 == cowner_2986);
		      }
		    else
		      {
			 test2435_2993 = ((bool_t) 1);
		      }
		 }
		 if (test2435_2993)
		   {
		      {
			 obj_t aux_3668;
			 {
			    object_t aux_3669;
			    aux_3669 = (object_t) (alloc_2985);
			    aux_3668 = OBJECT_WIDENING(aux_3669);
			 }
			 ((((make_struct_app_214_t) CREF(aux_3668))->stackable__42) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		      }
		      {
			 approx_t arg2437_2995;
			 {
			    obj_t aux_3673;
			    {
			       object_t aux_3674;
			       aux_3674 = (object_t) (alloc_2985);
			       aux_3673 = OBJECT_WIDENING(aux_3674);
			    }
			    arg2437_2995 = (((make_struct_app_214_t) CREF(aux_3673))->value_approx_19);
			 }
			 {
			    obj_t arg2436_3511;
			    arg2436_3511 = proc2476_cfa_struct;
			    return for_each_approx_alloc_83_cfa_approx(arg2436_3511, arg2437_2995);
			 }
		      }
		   }
		 else
		   {
		      approx_t arg2441_3001;
		      {
			 obj_t aux_3679;
			 {
			    object_t aux_3680;
			    aux_3680 = (object_t) (alloc_2985);
			    aux_3679 = OBJECT_WIDENING(aux_3680);
			 }
			 arg2441_3001 = (((make_struct_app_214_t) CREF(aux_3679))->value_approx_19);
		      }
		      {
			 obj_t arg2440_3512;
			 arg2440_3512 = make_fx_procedure(arg2440_cfa_struct, ((long) 1), ((long) 1));
			 PROCEDURE_SET(arg2440_3512, ((long) 0), cowner_2986);
			 return for_each_approx_alloc_83_cfa_approx(arg2440_3512, arg2441_3001);
		      }
		   }
	      }
	   }
      }
   }
}


/* arg2436 */ obj_t 
arg2436_cfa_struct(obj_t env_3530, obj_t alloc_3531)
{
   {
      obj_t alloc_2996;
      alloc_2996 = alloc_3531;
      return stack_loose_alloc__95_cfa_loose((node_t) (alloc_2996), CNST_TABLE_REF(((long) 0)));
   }
}


/* arg2440 */ obj_t 
arg2440_cfa_struct(obj_t env_3532, obj_t alloc_3534)
{
   {
      obj_t cowner_3533;
      cowner_3533 = PROCEDURE_REF(env_3532, ((long) 0));
      {
	 obj_t alloc_3002;
	 alloc_3002 = alloc_3534;
	 return stack_loose_alloc__95_cfa_loose((node_t) (alloc_3002), cowner_3533);
      }
   }
}


/* loose-alloc!-make-struct-app */ obj_t 
loose_alloc__make_struct_app_81_cfa_struct(obj_t env_3535, obj_t alloc_3536)
{
   {
      make_struct_app_214_t alloc_2974;
      alloc_2974 = (make_struct_app_214_t) (alloc_3536);
      {
	 bool_t test2426_2978;
	 {
	    long arg2430_2982;
	    {
	       obj_t aux_3694;
	       {
		  object_t aux_3695;
		  aux_3695 = (object_t) (alloc_2974);
		  aux_3694 = OBJECT_WIDENING(aux_3695);
	       }
	       arg2430_2982 = (((make_struct_app_214_t) CREF(aux_3694))->lost_stamp_114);
	    }
	    {
	       long n2_3481;
	       n2_3481 = (long) CINT(_cfa_stamp__16_cfa_iterate);
	       test2426_2978 = (arg2430_2982 == n2_3481);
	    }
	 }
	 if (test2426_2978)
	   {
	      return BUNSPEC;
	   }
	 else
	   {
	      {
		 long val2049_3483;
		 val2049_3483 = (long) CINT(_cfa_stamp__16_cfa_iterate);
		 {
		    obj_t aux_3703;
		    {
		       object_t aux_3704;
		       aux_3704 = (object_t) (alloc_2974);
		       aux_3703 = OBJECT_WIDENING(aux_3704);
		    }
		    ((((make_struct_app_214_t) CREF(aux_3703))->lost_stamp_114) = ((long) val2049_3483), BUNSPEC);
		 }
	      }
	      {
		 obj_t aux_3708;
		 {
		    object_t aux_3709;
		    aux_3709 = (object_t) (alloc_2974);
		    aux_3708 = OBJECT_WIDENING(aux_3709);
		 }
		 ((((make_struct_app_214_t) CREF(aux_3708))->stackable__42) = ((bool_t) ((bool_t) 0)), BUNSPEC);
	      }
	      {
		 approx_t aux_3713;
		 {
		    obj_t aux_3714;
		    {
		       object_t aux_3715;
		       aux_3715 = (object_t) (alloc_2974);
		       aux_3714 = OBJECT_WIDENING(aux_3715);
		    }
		    aux_3713 = (((make_struct_app_214_t) CREF(aux_3714))->value_approx_19);
		 }
		 for_each_approx_alloc_83_cfa_approx(loose_alloc__env_83_cfa_loose, aux_3713);
	      }
	      {
		 approx_t aux_3720;
		 {
		    obj_t aux_3721;
		    {
		       object_t aux_3722;
		       aux_3722 = (object_t) (alloc_2974);
		       aux_3721 = OBJECT_WIDENING(aux_3722);
		    }
		    aux_3720 = (((make_struct_app_214_t) CREF(aux_3721))->value_approx_19);
		 }
		 approx_set_type__239_cfa_approx(aux_3720, (type_t) (_obj__252_type_cache));
	      }
	      {
		 approx_t aux_3728;
		 {
		    obj_t aux_3729;
		    {
		       object_t aux_3730;
		       aux_3730 = (object_t) (alloc_2974);
		       aux_3729 = OBJECT_WIDENING(aux_3730);
		    }
		    aux_3728 = (((make_struct_app_214_t) CREF(aux_3729))->value_approx_19);
		 }
		 return approx_set_top__187_cfa_approx(aux_3728);
	      }
	   }
      }
   }
}


/* cfa!-struct-set!-app */ obj_t 
cfa__struct_set__app_51_cfa_struct(obj_t env_3537, obj_t node_3538)
{
   {
      struct_set__app_162_t node_2951;
      {
	 approx_t aux_3736;
	 node_2951 = (struct_set__app_162_t) (node_3538);
	 {
	    node_t aux_3737;
	    {
	       obj_t aux_3738;
	       {
		  obj_t aux_3739;
		  {
		     obj_t aux_3740;
		     {
			app_t obj_3461;
			obj_3461 = (app_t) (node_2951);
			aux_3740 = (((app_t) CREF(obj_3461))->args);
		     }
		     aux_3739 = CDR(aux_3740);
		  }
		  aux_3738 = CAR(aux_3739);
	       }
	       aux_3737 = (node_t) (aux_3738);
	    }
	    cfa__102_cfa_cfa(aux_3737);
	 }
	 {
	    approx_t struct_approx_51_2957;
	    approx_t val_approx_22_2958;
	    {
	       node_t aux_3747;
	       {
		  obj_t aux_3748;
		  {
		     obj_t aux_3749;
		     {
			app_t obj_3466;
			obj_3466 = (app_t) (node_2951);
			aux_3749 = (((app_t) CREF(obj_3466))->args);
		     }
		     aux_3748 = CAR(aux_3749);
		  }
		  aux_3747 = (node_t) (aux_3748);
	       }
	       struct_approx_51_2957 = cfa__102_cfa_cfa(aux_3747);
	    }
	    {
	       node_t aux_3755;
	       {
		  obj_t aux_3756;
		  {
		     obj_t aux_3757;
		     {
			obj_t aux_3758;
			{
			   obj_t aux_3759;
			   {
			      app_t obj_3468;
			      obj_3468 = (app_t) (node_2951);
			      aux_3759 = (((app_t) CREF(obj_3468))->args);
			   }
			   aux_3758 = CDR(aux_3759);
			}
			aux_3757 = CDR(aux_3758);
		     }
		     aux_3756 = CAR(aux_3757);
		  }
		  aux_3755 = (node_t) (aux_3756);
	       }
	       val_approx_22_2958 = cfa__102_cfa_cfa(aux_3755);
	    }
	    if ((((approx_t) CREF(struct_approx_51_2957))->top__138))
	      {
		 approx_t aux_3769;
		 aux_3769 = loose__226_cfa_loose(val_approx_22_2958, CNST_TABLE_REF(((long) 0)));
		 (obj_t) (aux_3769);
	      }
	    else
	      {
		 obj_t arg2417_3517;
		 arg2417_3517 = make_fx_procedure(arg2417_cfa_struct, ((long) 1), ((long) 1));
		 {
		    obj_t aux_3774;
		    aux_3774 = (obj_t) (val_approx_22_2958);
		    PROCEDURE_SET(arg2417_3517, ((long) 0), aux_3774);
		 }
		 for_each_approx_alloc_83_cfa_approx(arg2417_3517, struct_approx_51_2957);
	      }
	 }
	 {
	    obj_t aux_3778;
	    {
	       object_t aux_3779;
	       aux_3779 = (object_t) (node_2951);
	       aux_3778 = OBJECT_WIDENING(aux_3779);
	    }
	    aux_3736 = (((struct_set__app_162_t) CREF(aux_3778))->approx);
	 }
	 return (obj_t) (aux_3736);
      }
   }
}


/* arg2417 */ obj_t 
arg2417_cfa_struct(obj_t env_3539, obj_t app_3541)
{
   {
      obj_t val_approx_22_3540;
      val_approx_22_3540 = PROCEDURE_REF(env_3539, ((long) 0));
      {
	 obj_t app_2962;
	 app_2962 = app_3541;
	 {
	    bool_t test2419_2964;
	    test2419_2964 = is_a__118___object(app_2962, make_struct_app_214_cfa_info);
	    if (test2419_2964)
	      {
		 approx_t aux_3788;
		 {
		    approx_t aux_3789;
		    {
		       make_struct_app_214_t obj_3477;
		       obj_3477 = (make_struct_app_214_t) (app_2962);
		       {
			  obj_t aux_3791;
			  {
			     object_t aux_3792;
			     aux_3792 = (object_t) (obj_3477);
			     aux_3791 = OBJECT_WIDENING(aux_3792);
			  }
			  aux_3789 = (((make_struct_app_214_t) CREF(aux_3791))->value_approx_19);
		       }
		    }
		    aux_3788 = union_approx__241_cfa_approx(aux_3789, (approx_t) (val_approx_22_3540));
		 }
		 return (obj_t) (aux_3788);
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* cfa!-struct-ref-app */ obj_t 
cfa__struct_ref_app_92_cfa_struct(obj_t env_3542, obj_t node_3543)
{
   {
      struct_ref_app_73_t node_2927;
      {
	 approx_t aux_3799;
	 node_2927 = (struct_ref_app_73_t) (node_3543);
	 {
	    node_t aux_3800;
	    {
	       obj_t aux_3801;
	       {
		  obj_t aux_3802;
		  {
		     obj_t aux_3803;
		     {
			app_t obj_3445;
			obj_3445 = (app_t) (node_2927);
			aux_3803 = (((app_t) CREF(obj_3445))->args);
		     }
		     aux_3802 = CDR(aux_3803);
		  }
		  aux_3801 = CAR(aux_3802);
	       }
	       aux_3800 = (node_t) (aux_3801);
	    }
	    cfa__102_cfa_cfa(aux_3800);
	 }
	 {
	    approx_t struct_approx_51_2933;
	    {
	       node_t aux_3810;
	       {
		  obj_t aux_3811;
		  {
		     obj_t aux_3812;
		     {
			app_t obj_3450;
			obj_3450 = (app_t) (node_2927);
			aux_3812 = (((app_t) CREF(obj_3450))->args);
		     }
		     aux_3811 = CAR(aux_3812);
		  }
		  aux_3810 = (node_t) (aux_3811);
	       }
	       struct_approx_51_2933 = cfa__102_cfa_cfa(aux_3810);
	    }
	    if ((((approx_t) CREF(struct_approx_51_2933))->top__138))
	      {
		 approx_t aux_3820;
		 {
		    obj_t aux_3821;
		    {
		       object_t aux_3822;
		       aux_3822 = (object_t) (node_2927);
		       aux_3821 = OBJECT_WIDENING(aux_3822);
		    }
		    aux_3820 = (((struct_ref_app_73_t) CREF(aux_3821))->approx);
		 }
		 approx_set_top__187_cfa_approx(aux_3820);
	      }
	    else
	      {
		 BUNSPEC;
	      }
	    {
	       obj_t arg2402_3519;
	       arg2402_3519 = make_fx_procedure(arg2402_cfa_struct, ((long) 1), ((long) 1));
	       {
		  obj_t aux_3828;
		  aux_3828 = (obj_t) (node_2927);
		  PROCEDURE_SET(arg2402_3519, ((long) 0), aux_3828);
	       }
	       for_each_approx_alloc_83_cfa_approx(arg2402_3519, struct_approx_51_2933);
	    }
	 }
	 {
	    obj_t aux_3832;
	    {
	       object_t aux_3833;
	       aux_3833 = (object_t) (node_2927);
	       aux_3832 = OBJECT_WIDENING(aux_3833);
	    }
	    aux_3799 = (((struct_ref_app_73_t) CREF(aux_3832))->approx);
	 }
	 return (obj_t) (aux_3799);
      }
   }
}


/* arg2402 */ obj_t 
arg2402_cfa_struct(obj_t env_3544, obj_t app_3546)
{
   {
      obj_t instance2087_3545;
      instance2087_3545 = PROCEDURE_REF(env_3544, ((long) 0));
      {
	 obj_t app_2937;
	 app_2937 = app_3546;
	 {
	    bool_t test2404_2939;
	    test2404_2939 = is_a__118___object(app_2937, make_struct_app_214_cfa_info);
	    if (test2404_2939)
	      {
		 {
		    approx_t aux_3849;
		    approx_t aux_3842;
		    {
		       make_struct_app_214_t obj_3456;
		       obj_3456 = (make_struct_app_214_t) (app_2937);
		       {
			  obj_t aux_3851;
			  {
			     object_t aux_3852;
			     aux_3852 = (object_t) (obj_3456);
			     aux_3851 = OBJECT_WIDENING(aux_3852);
			  }
			  aux_3849 = (((make_struct_app_214_t) CREF(aux_3851))->value_approx_19);
		       }
		    }
		    {
		       struct_ref_app_73_t obj_3455;
		       obj_3455 = (struct_ref_app_73_t) (instance2087_3545);
		       {
			  obj_t aux_3844;
			  {
			     object_t aux_3845;
			     aux_3845 = (object_t) (obj_3455);
			     aux_3844 = OBJECT_WIDENING(aux_3845);
			  }
			  aux_3842 = (((struct_ref_app_73_t) CREF(aux_3844))->approx);
		       }
		    }
		    union_approx__241_cfa_approx(aux_3842, aux_3849);
		 }
		 {
		    type_t aux_3864;
		    approx_t aux_3857;
		    {
		       approx_t arg2409_2945;
		       {
			  struct_ref_app_73_t obj_3458;
			  obj_3458 = (struct_ref_app_73_t) (instance2087_3545);
			  {
			     obj_t aux_3866;
			     {
				object_t aux_3867;
				aux_3867 = (object_t) (obj_3458);
				aux_3866 = OBJECT_WIDENING(aux_3867);
			     }
			     arg2409_2945 = (((struct_ref_app_73_t) CREF(aux_3866))->approx);
			  }
		       }
		       aux_3864 = (((approx_t) CREF(arg2409_2945))->type);
		    }
		    {
		       make_struct_app_214_t obj_3457;
		       obj_3457 = (make_struct_app_214_t) (app_2937);
		       {
			  obj_t aux_3859;
			  {
			     object_t aux_3860;
			     aux_3860 = (object_t) (obj_3457);
			     aux_3859 = OBJECT_WIDENING(aux_3860);
			  }
			  aux_3857 = (((make_struct_app_214_t) CREF(aux_3859))->value_approx_19);
		       }
		    }
		    return approx_set_type__239_cfa_approx(aux_3857, aux_3864);
		 }
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* cfa!-make-struct-app */ obj_t 
cfa__make_struct_app_189_cfa_struct(obj_t env_3547, obj_t node_3548)
{
   {
      make_struct_app_214_t node_2915;
      {
	 approx_t aux_3873;
	 node_2915 = (make_struct_app_214_t) (node_3548);
	 {
	    node_t aux_3874;
	    {
	       obj_t aux_3875;
	       {
		  obj_t aux_3876;
		  {
		     app_t obj_3436;
		     obj_3436 = (app_t) (node_2915);
		     aux_3876 = (((app_t) CREF(obj_3436))->args);
		  }
		  aux_3875 = CAR(aux_3876);
	       }
	       aux_3874 = (node_t) (aux_3875);
	    }
	    cfa__102_cfa_cfa(aux_3874);
	 }
	 {
	    approx_t init_value_approx_9_2921;
	    {
	       node_t aux_3882;
	       {
		  obj_t aux_3883;
		  {
		     obj_t aux_3884;
		     {
			obj_t aux_3885;
			{
			   app_t obj_3438;
			   obj_3438 = (app_t) (node_2915);
			   aux_3885 = (((app_t) CREF(obj_3438))->args);
			}
			aux_3884 = CDR(aux_3885);
		     }
		     aux_3883 = CAR(aux_3884);
		  }
		  aux_3882 = (node_t) (aux_3883);
	       }
	       init_value_approx_9_2921 = cfa__102_cfa_cfa(aux_3882);
	    }
	    {
	       approx_t aux_3892;
	       {
		  obj_t aux_3893;
		  {
		     object_t aux_3894;
		     aux_3894 = (object_t) (node_2915);
		     aux_3893 = OBJECT_WIDENING(aux_3894);
		  }
		  aux_3892 = (((make_struct_app_214_t) CREF(aux_3893))->value_approx_19);
	       }
	       union_approx__241_cfa_approx(aux_3892, init_value_approx_9_2921);
	    }
	    {
	       obj_t aux_3899;
	       {
		  object_t aux_3900;
		  aux_3900 = (object_t) (node_2915);
		  aux_3899 = OBJECT_WIDENING(aux_3900);
	       }
	       aux_3873 = (((make_struct_app_214_t) CREF(aux_3899))->approx);
	    }
	 }
	 return (obj_t) (aux_3873);
      }
   }
}


/* node-setup!-pre-struct-set!-app */ obj_t 
node_setup__pre_struct_set__app_230_cfa_struct(obj_t env_3549, obj_t node_3550)
{
   {
      pre_struct_set__app_116_t node_2899;
      {
	 struct_set__app_162_t aux_3906;
	 node_2899 = (pre_struct_set__app_116_t) (node_3550);
	 {
	    obj_t aux_3907;
	    {
	       app_t obj_3418;
	       obj_3418 = (app_t) (node_2899);
	       aux_3907 = (((app_t) CREF(obj_3418))->args);
	    }
	    node_setup___185_cfa_setup(aux_3907);
	 }
	 {
	    pre_struct_set__app_116_t node_2904;
	    {
	       long arg2383_2910;
	       {
		  obj_t arg2384_2911;
		  {
		     obj_t arg2385_2912;
		     {
			object_t object_3419;
			object_3419 = (object_t) (node_2899);
			{
			   long arg1180_3420;
			   {
			      long arg1181_3421;
			      long arg1182_3422;
			      arg1181_3421 = TYPE(object_3419);
			      arg1182_3422 = OBJECT_TYPE;
			      arg1180_3420 = (arg1181_3421 - arg1182_3422);
			   }
			   {
			      obj_t vector_3426;
			      vector_3426 = _classes__134___object;
			      arg2385_2912 = VECTOR_REF(vector_3426, arg1180_3420);
			   }
			}
		     }
		     arg2384_2911 = class_super_145___object(arg2385_2912);
		  }
		  arg2383_2910 = class_num_218___object(arg2384_2911);
	       }
	       {
		  obj_t obj_3428;
		  obj_3428 = (obj_t) (node_2899);
		  (((obj_t) CREF(obj_3428))->header = MAKE_HEADER(arg2383_2910, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3920;
	       aux_3920 = (object_t) (node_2899);
	       OBJECT_WIDENING_SET(aux_3920, BFALSE);
	    }
	    node_2904 = node_2899;
	    {
	       struct_set__app_162_t obj2085_2905;
	       obj2085_2905 = ((struct_set__app_162_t) (node_2904));
	       {
		  struct_set__app_162_t arg2379_2906;
		  {
		     approx_t arg2380_2907;
		     arg2380_2907 = make_type_approx_184_cfa_approx((type_t) (_unspec__87_type_cache));
		     {
			struct_set__app_162_t res2455_3433;
			{
			   struct_set__app_162_t new2065_3431;
			   new2065_3431 = ((struct_set__app_162_t) BREF(GC_MALLOC(sizeof(struct struct_set__app_162))));
			   ((((struct_set__app_162_t) CREF(new2065_3431))->approx) = ((approx_t) arg2380_2907), BUNSPEC);
			   res2455_3433 = new2065_3431;
			}
			arg2379_2906 = res2455_3433;
		     }
		  }
		  {
		     obj_t aux_3930;
		     object_t aux_3928;
		     aux_3930 = (obj_t) (arg2379_2906);
		     aux_3928 = (object_t) (obj2085_2905);
		     OBJECT_WIDENING_SET(aux_3928, aux_3930);
		  }
	       }
	       {
		  long arg2381_2908;
		  arg2381_2908 = class_num_218___object(struct_set__app_162_cfa_info);
		  {
		     obj_t obj_3434;
		     obj_3434 = (obj_t) (obj2085_2905);
		     (((obj_t) CREF(obj_3434))->header = MAKE_HEADER(arg2381_2908, 0), BUNSPEC);
		  }
	       }
	       aux_3906 = obj2085_2905;
	    }
	 }
	 return (obj_t) (aux_3906);
      }
   }
}


/* node-setup!-pre-struct-ref-app */ obj_t 
node_setup__pre_struct_ref_app_157_cfa_struct(obj_t env_3551, obj_t node_3552)
{
   {
      pre_struct_ref_app_207_t node_2883;
      {
	 struct_ref_app_73_t aux_3938;
	 node_2883 = (pre_struct_ref_app_207_t) (node_3552);
	 {
	    obj_t aux_3939;
	    {
	       app_t obj_3400;
	       obj_3400 = (app_t) (node_2883);
	       aux_3939 = (((app_t) CREF(obj_3400))->args);
	    }
	    node_setup___185_cfa_setup(aux_3939);
	 }
	 {
	    pre_struct_ref_app_207_t node_2888;
	    {
	       long arg2374_2894;
	       {
		  obj_t arg2375_2895;
		  {
		     obj_t arg2376_2896;
		     {
			object_t object_3401;
			object_3401 = (object_t) (node_2883);
			{
			   long arg1180_3402;
			   {
			      long arg1181_3403;
			      long arg1182_3404;
			      arg1181_3403 = TYPE(object_3401);
			      arg1182_3404 = OBJECT_TYPE;
			      arg1180_3402 = (arg1181_3403 - arg1182_3404);
			   }
			   {
			      obj_t vector_3408;
			      vector_3408 = _classes__134___object;
			      arg2376_2896 = VECTOR_REF(vector_3408, arg1180_3402);
			   }
			}
		     }
		     arg2375_2895 = class_super_145___object(arg2376_2896);
		  }
		  arg2374_2894 = class_num_218___object(arg2375_2895);
	       }
	       {
		  obj_t obj_3410;
		  obj_3410 = (obj_t) (node_2883);
		  (((obj_t) CREF(obj_3410))->header = MAKE_HEADER(arg2374_2894, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3952;
	       aux_3952 = (object_t) (node_2883);
	       OBJECT_WIDENING_SET(aux_3952, BFALSE);
	    }
	    node_2888 = node_2883;
	    {
	       struct_ref_app_73_t obj2082_2889;
	       obj2082_2889 = ((struct_ref_app_73_t) (node_2888));
	       {
		  struct_ref_app_73_t arg2371_2890;
		  {
		     approx_t arg2372_2891;
		     arg2372_2891 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
		     {
			struct_ref_app_73_t res2454_3415;
			{
			   struct_ref_app_73_t new2053_3413;
			   new2053_3413 = ((struct_ref_app_73_t) BREF(GC_MALLOC(sizeof(struct struct_ref_app_73))));
			   ((((struct_ref_app_73_t) CREF(new2053_3413))->approx) = ((approx_t) arg2372_2891), BUNSPEC);
			   res2454_3415 = new2053_3413;
			}
			arg2371_2890 = res2454_3415;
		     }
		  }
		  {
		     obj_t aux_3962;
		     object_t aux_3960;
		     aux_3962 = (obj_t) (arg2371_2890);
		     aux_3960 = (object_t) (obj2082_2889);
		     OBJECT_WIDENING_SET(aux_3960, aux_3962);
		  }
	       }
	       {
		  long arg2373_2892;
		  arg2373_2892 = class_num_218___object(struct_ref_app_73_cfa_info);
		  {
		     obj_t obj_3416;
		     obj_3416 = (obj_t) (obj2082_2889);
		     (((obj_t) CREF(obj_3416))->header = MAKE_HEADER(arg2373_2892, 0), BUNSPEC);
		  }
	       }
	       aux_3938 = obj2082_2889;
	    }
	 }
	 return (obj_t) (aux_3938);
      }
   }
}


/* node-setup!-pre-make-struct-app */ obj_t 
node_setup__pre_make_struct_app_238_cfa_struct(obj_t env_3553, obj_t node_3554)
{
   {
      pre_make_struct_app_218_t node_2860;
      node_2860 = (pre_make_struct_app_218_t) (node_3554);
      {
	 obj_t aux_3970;
	 {
	    app_t obj_3369;
	    obj_3369 = (app_t) (node_2860);
	    aux_3970 = (((app_t) CREF(obj_3369))->args);
	 }
	 node_setup___185_cfa_setup(aux_3970);
      }
      {
	 variable_t owner_2865;
	 {
	    obj_t aux_3974;
	    {
	       object_t aux_3975;
	       aux_3975 = (object_t) (node_2860);
	       aux_3974 = OBJECT_WIDENING(aux_3975);
	    }
	    owner_2865 = (((pre_make_struct_app_218_t) CREF(aux_3974))->owner);
	 }
	 {
	    pre_make_struct_app_218_t node_2866;
	    {
	       long arg2366_2878;
	       {
		  obj_t arg2367_2879;
		  {
		     obj_t arg2368_2880;
		     {
			object_t object_3371;
			object_3371 = (object_t) (node_2860);
			{
			   long arg1180_3372;
			   {
			      long arg1181_3373;
			      long arg1182_3374;
			      arg1181_3373 = TYPE(object_3371);
			      arg1182_3374 = OBJECT_TYPE;
			      arg1180_3372 = (arg1181_3373 - arg1182_3374);
			   }
			   {
			      obj_t vector_3378;
			      vector_3378 = _classes__134___object;
			      arg2368_2880 = VECTOR_REF(vector_3378, arg1180_3372);
			   }
			}
		     }
		     arg2367_2879 = class_super_145___object(arg2368_2880);
		  }
		  arg2366_2878 = class_num_218___object(arg2367_2879);
	       }
	       {
		  obj_t obj_3380;
		  obj_3380 = (obj_t) (node_2860);
		  (((obj_t) CREF(obj_3380))->header = MAKE_HEADER(arg2366_2878, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3988;
	       aux_3988 = (object_t) (node_2860);
	       OBJECT_WIDENING_SET(aux_3988, BFALSE);
	    }
	    node_2866 = node_2860;
	    {
	       {
		  make_struct_app_214_t wnode_2867;
		  {
		     make_struct_app_214_t obj2079_2869;
		     obj2079_2869 = ((make_struct_app_214_t) (node_2866));
		     {
			make_struct_app_214_t arg2358_2870;
			{
			   approx_t arg2359_2871;
			   approx_t arg2360_2872;
			   arg2359_2871 = make_empty_approx_131_cfa_approx();
			   arg2360_2872 = make_empty_approx_131_cfa_approx();
			   {
			      make_struct_app_214_t res2453_3395;
			      {
				 make_struct_app_214_t new2032_3388;
				 new2032_3388 = ((make_struct_app_214_t) BREF(GC_MALLOC(sizeof(struct make_struct_app_214))));
				 ((((make_struct_app_214_t) CREF(new2032_3388))->approx) = ((approx_t) arg2359_2871), BUNSPEC);
				 ((((make_struct_app_214_t) CREF(new2032_3388))->value_approx_19) = ((approx_t) arg2360_2872), BUNSPEC);
				 ((((make_struct_app_214_t) CREF(new2032_3388))->lost_stamp_114) = ((long) ((long) -1)), BUNSPEC);
				 ((((make_struct_app_214_t) CREF(new2032_3388))->owner) = ((variable_t) owner_2865), BUNSPEC);
				 ((((make_struct_app_214_t) CREF(new2032_3388))->stackable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				 ((((make_struct_app_214_t) CREF(new2032_3388))->stack_stamp_31) = ((obj_t) BNIL), BUNSPEC);
				 res2453_3395 = new2032_3388;
			      }
			      arg2358_2870 = res2453_3395;
			   }
			}
			{
			   obj_t aux_4003;
			   object_t aux_4001;
			   aux_4003 = (obj_t) (arg2358_2870);
			   aux_4001 = (object_t) (obj2079_2869);
			   OBJECT_WIDENING_SET(aux_4001, aux_4003);
			}
		     }
		     {
			long arg2365_2876;
			arg2365_2876 = class_num_218___object(make_struct_app_214_cfa_info);
			{
			   obj_t obj_3396;
			   obj_3396 = (obj_t) (obj2079_2869);
			   (((obj_t) CREF(obj_3396))->header = MAKE_HEADER(arg2365_2876, 0), BUNSPEC);
			}
		     }
		     wnode_2867 = obj2079_2869;
		  }
		  {
		     approx_t arg2357_2868;
		     arg2357_2868 = make_type_alloc_approx_134_cfa_approx((type_t) (_struct__183_type_cache), (node_t) (node_2866));
		     {
			obj_t aux_4012;
			{
			   object_t aux_4013;
			   aux_4013 = (object_t) (wnode_2867);
			   aux_4012 = OBJECT_WIDENING(aux_4013);
			}
			return ((((make_struct_app_214_t) CREF(aux_4012))->approx) = ((approx_t) arg2357_2868), BUNSPEC);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_struct()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_STRUCT");
   module_initialization_70_tools_error(((long) 0), "CFA_STRUCT");
   module_initialization_70_tools_shape(((long) 0), "CFA_STRUCT");
   module_initialization_70_type_type(((long) 0), "CFA_STRUCT");
   module_initialization_70_type_cache(((long) 0), "CFA_STRUCT");
   module_initialization_70_ast_var(((long) 0), "CFA_STRUCT");
   module_initialization_70_ast_node(((long) 0), "CFA_STRUCT");
   module_initialization_70_cfa_info(((long) 0), "CFA_STRUCT");
   module_initialization_70_cfa_loose(((long) 0), "CFA_STRUCT");
   module_initialization_70_cfa_iterate(((long) 0), "CFA_STRUCT");
   module_initialization_70_cfa_cfa(((long) 0), "CFA_STRUCT");
   module_initialization_70_cfa_setup(((long) 0), "CFA_STRUCT");
   module_initialization_70_cfa_approx(((long) 0), "CFA_STRUCT");
   return module_initialization_70_cfa_stack(((long) 0), "CFA_STRUCT");
}
