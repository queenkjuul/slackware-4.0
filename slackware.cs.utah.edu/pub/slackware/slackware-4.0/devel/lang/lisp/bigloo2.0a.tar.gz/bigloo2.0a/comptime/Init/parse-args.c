/*===========================================================================*/
/*   (Init/parse-args.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t _additional_traces__2_engine_param;
extern obj_t _src_files__222_engine_param;
static obj_t method_init_76_init_parse_args_215();
extern obj_t string_to_symbol(char *);
extern obj_t _profile_library__193_engine_param;
extern obj_t _cc__215_engine_param;
extern obj_t _auto_mode__185_engine_param;
extern obj_t _optim__89_engine_param;
static obj_t body1041_init_parse_args_215(obj_t);
extern obj_t _optim_unroll_loop___80_engine_param;
extern obj_t string_append(obj_t, obj_t);
extern obj_t exitd_top;
extern obj_t _verbose__1_engine_param;
extern obj_t _type_shape___78_engine_param;
extern obj_t _load_path__54___eval;
extern obj_t _rm_c_files__192_engine_param;
extern obj_t _reflection___104_engine_param;
extern obj_t bigloo_license_175_tools_license();
extern obj_t _stdc__25_engine_param;
extern obj_t _shared_cnst___67_engine_param;
extern obj_t _unsafe_library__118_engine_param;
extern obj_t warning___error(obj_t);
extern obj_t _access_shape___50_engine_param;
extern obj_t _bdb_debug__1_engine_param;
extern obj_t _reader__83_engine_param;
extern obj_t parse_args_143_init_parse_args_215(obj_t);
extern obj_t _nil__217___eval;
static obj_t parse_unsafe_args_57_init_parse_args_215(obj_t);
extern obj_t _additional_bigloo_libraries__50_engine_param;
static long _trace_level__157_init_parse_args_215;
static obj_t handling_function1216_init_parse_args_215(obj_t, obj_t, obj_t, obj_t);
extern obj_t _unsafe_struct__195_engine_param;
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _bigloo_user_lib__33_engine_param;
extern obj_t _genericity__47_engine_param;
extern obj_t suffix___os(obj_t);
extern obj_t assoc___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t module_initialization_70_init_parse_args_215(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70_init_extend(long, char *);
extern obj_t module_initialization_70_init_setrc(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_alibrary(long, char *);
extern obj_t module_initialization_70_write_version(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_license(long, char *);
extern obj_t module_initialization_70_read_access(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___r5_macro_4_3_init(long, char *);
extern obj_t _warning__61___error;
extern obj_t _default_lib_dir__128_engine_param;
extern obj_t _module_checksum_object___74_engine_param;
extern obj_t _unsafe_arity__240_engine_param;
static obj_t _o3__35_init_parse_args_215();
static obj_t _o2__218_init_parse_args_215();
extern obj_t _strip__173_engine_param;
extern obj_t _heap_name__135_engine_param;
extern obj_t version_write_version();
extern obj_t _unsafe_version__81_engine_param;
extern obj_t exit_bigloo_229_init_main(obj_t);
extern obj_t _module_shape___145_engine_param;
static obj_t imported_modules_init_94_init_parse_args_215();
extern obj_t _bigloo_lib__121_engine_param;
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t _hygien___100___r5_macro_4_3_init;
extern obj_t _optim_o_macro___96_engine_param;
extern obj_t _dest__217_engine_param;
extern obj_t _cc_options__252_engine_param;
extern obj_t string_upcase_71___r4_strings_6_7(obj_t);
extern bool_t bigloo_strcmp(obj_t, obj_t);
extern obj_t _optim_inline_method___30_engine_param;
static obj_t _parse_args_194_init_parse_args_215(obj_t, obj_t);
static obj_t rhandler1040_init_parse_args_215(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _rest_args__8_engine_param;
static obj_t library_modules_init_112_init_parse_args_215();
extern obj_t _user_heap_size__225_engine_param;
extern obj_t newline___r4_output_6_10_3(obj_t);
extern obj_t _optim_stack___57_engine_param;
static obj_t query_init_parse_args_215();
extern obj_t revision_write_version();
extern obj_t _o_files__27_engine_param;
extern obj_t _key_shape___172_engine_param;
static obj_t toplevel_init_63_init_parse_args_215();
extern obj_t _unsafe_type__146_engine_param;
extern bool_t _fx_24___r4_numbers_6_5_fixnum(long, long);
extern obj_t _inlining___224_engine_param;
extern obj_t _call_cc___102_engine_param;
extern obj_t open_input_string(obj_t);
static obj_t usage_init_parse_args_215(obj_t, long, bool_t);
extern obj_t add_access__140_read_access(obj_t, obj_t);
extern obj_t print___r4_output_6_10_3(obj_t);
extern obj_t _bigloo_licensing___64_engine_param;
extern obj_t _interpreter__140_engine_param;
extern obj_t _lib_dir__34_engine_param;
extern obj_t _bigloo_args__103_engine_param;
extern obj_t load_extend_232_init_extend(obj_t);
extern obj_t _access_file__194_engine_param;
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t _init_mode__183_engine_param;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _location_shape___48_engine_param;
extern obj_t _compiler_debug__134_engine_param;
extern obj_t _static_bigloo___233_engine_param;
extern obj_t _include_foreign__253_engine_param;
extern obj_t make_string(long, unsigned char);
extern obj_t _optim_loop_inlining___30_engine_param;
extern obj_t _additional_heap_name__223_engine_param;
extern obj_t c_substring(obj_t, long, long);
extern obj_t short_version_52_write_version();
static obj_t parse_optim_args_175_init_parse_args_215(obj_t);
static obj_t arg1220_init_parse_args_215(obj_t);
static obj_t arg1219_init_parse_args_215(obj_t);
extern obj_t setup_library_values_14_init_setrc(obj_t);
static obj_t parse_shape_args_80_init_parse_args_215(obj_t);
static bool_t _extended_done___215_init_parse_args_215;
extern obj_t remove_error_handler__102___error();
extern obj_t bigloo_variables_usage_232_engine_param(bool_t);
extern obj_t eval___eval(obj_t, obj_t);
extern obj_t _unsafe_range__218_engine_param;
extern obj_t read___reader(obj_t);
extern obj_t _profile_mode__105_engine_param;
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _bigloo_cmd_name__60_engine_param;
extern obj_t _ld_options__88_engine_param;
extern obj_t _user_shape___227_engine_param;
extern obj_t _c_debug__136_engine_param;
extern long string__integer_39___r4_numbers_6_5_fixnum(char *, obj_t);
static obj_t args_parse_usage_117_init_parse_args_215(obj_t, obj_t);
static obj_t escape_init_parse_args_215(obj_t, obj_t);
extern obj_t _lib_mode__85_engine_param;
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t _library_init__55_init_parse_args_215 = BUNSPEC;
static obj_t do_parse_args_215_init_parse_args_215(obj_t);
extern obj_t _hello__249_engine_param;
static obj_t require_initialization_114_init_parse_args_215 = BUNSPEC;
extern obj_t _additional_heap_names__104_engine_param;
extern obj_t _src_suffix__192_engine_param;
extern obj_t _obj_suffix__189_engine_param;
extern obj_t start_trace_17_tools_trace(obj_t, obj_t);
extern obj_t make_library_name_119_module_alibrary(obj_t);
extern obj_t _pass__125_engine_param;
extern obj_t _main__152_module_module;
static obj_t cnst_init_137_init_parse_args_215();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t _extend_entry__7_engine_param;
static obj_t __cnst[46];

DEFINE_EXPORT_PROCEDURE(parse_args_env_42_init_parse_args_215, _parse_args_194_init_parse_args_2151881, _parse_args_194_init_parse_args_215, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1719_init_parse_args_215, args_parse_usage_117_init_parse_args_2151882, args_parse_usage_117_init_parse_args_215, 0L, 1);
DEFINE_STRING(string1875_init_parse_args_215, string1875_init_parse_args_2151883, "(SET! *RGC-OPTIM* #t) SECTION ((\"-fread-plain\" . \"Read source from plain text file\") (\"-fread-internal\" . \"Read source from binary interned file\") (\"-addheap <name>\" . \"Specify an additional heap file\") (\"-heap <name>\" . \"Specify an heap file (or #f to not load heap)\") (\"-LICENSE\" . \"Add the license to the generated C files\") (\"-mkdistrib\" . \"Compile a main file for a distribution\") (\"-mkaddheap\" . \"Build an additional heap file\") (\"-mkheap\" . \"Build an heap file\") (\"-mkaddlib\" . \"Compile an additional library module\") (\"-mklib\" . \"Compile a library module\") (SECTION . \"Bootstrap and setup\") (\"-init-<lib/read/intern>\" . \"Constants initialization mode\") (SECTION . \"Constant initialization\") (\"-mco\" . \"Stop after .mco production\") (\"-indent\" . \"Produce an indented .c file\") (\"-cgen\" . \"Do not C compile and produce a .c file\") (\"-hgen\" . \"Produce a C header file with class definitions\") (\"-integrate\" . \"Stop after the integration stage\") (\"-cns"
   "t\" . \"Stop after the constant allocation\") (\"-bdb\" . \"Stop after the Bdb code production\") (\"-recovery\" . \"Stop after the type recovery stage\") (\"-globalize\" . \"Stop after the globalization stage\") (\"-cfa\" . \"Stop after the cfa stage\") (\"-assert\" . \"Stop after the assertions stage\") (\"-reduce\" . \"Stop after the reduction optimizations stage\") (\"-effect\" . \"Stop after the effect stage\") (\"-coerce\" . \"Stop after the type coercing stage\") (\"-user\" . \"Stop after the user pass\") (\"-fuse\" . \"Stop after the fuse stage\") (\"-fail\" . \"Stop after the failure replacement stage\") (\"-inline+\" . \"Stop after the 2nd inlining stage\") (\"-inline\" . \"Stop after the inlining stage\") (\"-bivalue\" . \"Stop after the bivaluation stage\") (\"-callcc\" . \"Stop after the callcc pass\") (\"-trace\" . \"Stop after the trace pass\") (\"-bdb-spread-obj\" . \"Stop after the bdb obj spread stage\") (\"-ast\" . \"Stop after the ast construction stage\") (\"-expand\" . \"Stop after the p"
   "reprocessing stage\") (\"-syntax\" . \"Stop after the syntax stage (see -hygien)\") (SECTION . \"Compilation stages\") (\"-shape[mktalu]\" . \"Some debugging tools (private)\") (\"+t<pass>\" . \"Force pass to be traced\") (\"-t[2|3|4]\" . \"Generate a trace file (*)\") (SECTION . \"Traces\") (\"-l<library>\" . \"Link with host library\") (\"-static-bigloo\" . \"Link with the static bigloo library\") (\"-ldopt <string>\" . \"Invoke ld with <string>\") (\"-copt <string>\" . \"Invoke cc with <string>\") (\"-stdc\" . \"Generate strict ISO C code\") (\"-cc <compiler>\" . \"Specify the C compiler\") (SECTION . \"Back-end and link\") (\"-Wall\" . \"warn about all possible type errors\") (\"-w\" . \"Inhibit all warning messages\") (\"-no-hello\" . \"Dont' say hello even in verbose mode\") (\"-v[23]\" . \"Be verbose\") (\"-s\" . \"Be silent\") (SECTION . \"Verbosity\") (\"-farithmetic\" . \"Suppress genericity of arithmetic operators\") (\"+fno-reflection\" . \"Enable reflection code production\") (\"-fno-reflection\""
   " . \"Disable reflection code production\") (\"-hygien\" . \"Enable r5rs macros\") (\"-call/cc\" . \"Enable call/cc function\") (\"-nil\" . \"Evaluate '() as #f in `if' expression\") (SECTION . \"Dialect\") (\"-L <name>\" . \"Set additional library path\") (\"-lib-dir <name>\" . \"Set lib-path to <name>\") (\"-I <name>\" . \"Add <name> to the load path\") (\"-eval <string>\" . \"Evaluate <string>\") (\"-q\" . \"Do not load any rc file\") (\"-query\" . \"Dump the current configuration\") (\"-revision\" . \"The current release (short format)\") (\"-version\" . \"The current release\") (SECTION . \"Configuration and path\") (\"-pg\" . \"Compile files with profiling option (+)\") (\"-p[2]\" . \"Compile files for profiling (+)\") (SECTION . \"Profiling\") (\"-gbdb[2]\" . \"Compile with bdb debug informations\") (\"-cg\" . \"Compile C files with debug option\") (\"-g[234]\" . \"Produce Bigloo debug informations\") (SECTION . \"Debug\") (\"-unsafe[atrsvl]\" . \"Don't check [type/arity/range/struct/version]\") (SECTIO"
   "N . \"Safety\") (\"-fmco\" . \"Produce an .mco file\") (\"-fno-sharing\" . \"Do not attempt to share constant data\") (\"-fsharing\" . \"Attempt to share constant data\") (\"-extend <name>\" . \"Extend the compiler\") (\"<-/+>rm\" . \"Don't or force removing C file\") (SECTION . \"Compilation modes\") (\"-fno-O-macro\" . \"Disable Optimization macro\") (\"-fO-macro\" . \"Enable Optimization macro (default)\") (\"-fno-inlining\" . \"Disable inline optimization\") (\"-floop-inlining\" . \"Enable loop inlining (default)\") (\"-fno-loop-inlining\" . \"Disable loop inlining\") (\"-fno-unroll-loop\" . \"Disable loop unrolling\") (\"-funroll-loop\" . \"Enable loop unrolling (enabled from -O3)\") (\"-fno-inline-method\" . \"Disable methods inlining\") (\"-finline-method\" . \"Enable methods inlining (enabled from -O3)\") (\"-fno-stack\" . \"Disable Heap->stack optimization\") (\"-fstack\" . \"Enable Heap->stack optimization\") (\"-O[2..6]\" . \"Optimization modes\") (\"-Obench\" . \"Benchmarking mode (also consider -"
   "fstack option)\") (SECTION . \"Optimization\") (\"-heapsize <size>\" . \"Set the initial heap size value (in megabyte)\") (\"-library <library>\" . \"Compile (and link) with additional library\") (\"-main <fun>\" . \"Set the main function\") (\"-access <module> <file>\" . \"Set access between module and file\") (\"-afile <file>\" . \"Set name of the access file\") (\"-i\" . \"Don't compile but interprete a src-file\") (\"-suffix <suffix>\" . \"Recognize suffix as Scheme source\") (\"-c\" . \"Suppress linking and produce a .o file\") (\"--to-stdout\" . \"Write C code on current output channel\") (\"-o <dst>\" . \"Name the output file <dst>\") (\"-help-manual\" . \"The help message formatted for the manual\") (\"-help2\" . \"The exhaustive help message\") (\"-help\" . \"This help message\") (\"-\" . \"Read source code on current input channel\") (SECTION . \"Misc\")) ((\"TMPDIR\" . #\"tmp directory (default \\\"/tmp\\\")\") (\"BIGLOOLIB\" . \"libraries' directory\") (\"BIGLOOHEAP\" . \"the initial heap size in "
   "megabytes (4 Mo by default)\") (\"BIGLOOSTACKDEPTH\" . \"the error stack depth printing\")) IGNORE PLAIN DISTRIB MAKE-ADD-HEAP MAKE-HEAP INTERN READ LIB MCO CINDENT CGEN HGEN INTEGRATE CNST BDB RECOVERY GLOBALIZE CFA ASSERT REDUCE EFFECT COERCE USER FUSE FAIL INLINE+ INLINE BIVALUE CALLCC TRACE BDB-SPREAD-OBJ AST EXPAND SYNTAX DONE NOTHING-TO-DO (\"-O5\" \"-unsafe\" \"-copt\" \"-O3\" \"-static-bigloo\") CC --TO-STDOUT STDIN USAGE-DONE PARSING-DONE ", 6126);
DEFINE_STRING(string1874_init_parse_args_215, string1874_init_parse_args_2151884, "or use the -help2 option.", 25);
DEFINE_STRING(string1873_init_parse_args_215, string1873_init_parse_args_2151885, "Too see all variables enter the interpreter", 43);
DEFINE_STRING(string1872_init_parse_args_215, string1872_init_parse_args_2151886, "*heap-name*            : ", 25);
DEFINE_STRING(string1871_init_parse_args_215, string1871_init_parse_args_2151887, "*include-foreign*      : ", 25);
DEFINE_STRING(string1869_init_parse_args_215, string1869_init_parse_args_2151888, "*default-lib-dir*      : ", 25);
DEFINE_STRING(string1870_init_parse_args_215, string1870_init_parse_args_2151889, "*lib-dir*              : ", 25);
DEFINE_STRING(string1868_init_parse_args_215, string1868_init_parse_args_2151890, "*bigloo-user-lib*      : ", 25);
DEFINE_STRING(string1867_init_parse_args_215, string1867_init_parse_args_2151891, "*bigloo-lib*           : ", 25);
DEFINE_STRING(string1866_init_parse_args_215, string1866_init_parse_args_2151892, "*ld-options*           : ", 25);
DEFINE_STRING(string1865_init_parse_args_215, string1865_init_parse_args_2151893, "*cc-options*           : ", 25);
DEFINE_STRING(string1864_init_parse_args_215, string1864_init_parse_args_2151894, "*cc*                   : ", 25);
DEFINE_STRING(string1863_init_parse_args_215, string1863_init_parse_args_2151895, "setups:", 7);
DEFINE_STRING(string1862_init_parse_args_215, string1862_init_parse_args_2151896, " -O2", 4);
DEFINE_STRING(string1861_init_parse_args_215, string1861_init_parse_args_2151897, " -O", 3);
DEFINE_STRING(string1859_init_parse_args_215, string1859_init_parse_args_2151898, "Illegal -unsafe option", 22);
DEFINE_STRING(string1860_init_parse_args_215, string1860_init_parse_args_2151899, "Illegal -O option", 17);
DEFINE_STRING(string1858_init_parse_args_215, string1858_init_parse_args_2151900, "Illegal -shape option", 21);
DEFINE_STRING(string1857_init_parse_args_215, string1857_init_parse_args_2151901, "parse-arg", 9);
DEFINE_STRING(string1856_init_parse_args_215, string1856_init_parse_args_2151902, " --  ", 5);
DEFINE_STRING(string1855_init_parse_args_215, string1855_init_parse_args_2151903, "      ", 6);
DEFINE_STRING(string1854_init_parse_args_215, string1854_init_parse_args_2151904, "   ", 3);
DEFINE_STRING(string1853_init_parse_args_215, string1853_init_parse_args_2151905, ":", 1);
DEFINE_STRING(string1852_init_parse_args_215, string1852_init_parse_args_2151906, "Bigloo Control Variables:", 25);
DEFINE_STRING(string1851_init_parse_args_215, string1851_init_parse_args_2151907, " . : option enabled from -O3 mode", 33);
DEFINE_STRING(string1849_init_parse_args_215, string1849_init_parse_args_2151908, " * : only available in developing mode", 38);
DEFINE_STRING(string1850_init_parse_args_215, string1850_init_parse_args_2151909, " + : not always available", 25);
DEFINE_STRING(string1848_init_parse_args_215, string1848_init_parse_args_2151910, "usage: bigloo [options] [name.suf]", 34);
DEFINE_STRING(string1847_init_parse_args_215, string1847_init_parse_args_2151911, "   - ~/.bigloorc", 16);
DEFINE_STRING(string1846_init_parse_args_215, string1846_init_parse_args_2151912, "Runtime Command file:", 21);
DEFINE_STRING(string1845_init_parse_args_215, string1845_init_parse_args_2151913, ": ", 2);
DEFINE_STRING(string1844_init_parse_args_215, string1844_init_parse_args_2151914, "     ", 5);
DEFINE_STRING(string1843_init_parse_args_215, string1843_init_parse_args_2151915, "   - ", 5);
DEFINE_STRING(string1842_init_parse_args_215, string1842_init_parse_args_2151916, "Shell Variables:", 16);
DEFINE_STRING(string1841_init_parse_args_215, string1841_init_parse_args_2151917, "-fread-plain", 12);
DEFINE_STRING(string1839_init_parse_args_215, string1839_init_parse_args_2151918, "-addheap", 8);
DEFINE_STRING(string1840_init_parse_args_215, string1840_init_parse_args_2151919, "-fread-internal", 15);
DEFINE_STRING(string1838_init_parse_args_215, string1838_init_parse_args_2151920, "-heap", 5);
DEFINE_STRING(string1837_init_parse_args_215, string1837_init_parse_args_2151921, "-LICENSE", 8);
DEFINE_STRING(string1836_init_parse_args_215, string1836_init_parse_args_2151922, "-mkdistrib", 10);
DEFINE_STRING(string1835_init_parse_args_215, string1835_init_parse_args_2151923, "-mkaddheap", 10);
DEFINE_STRING(string1834_init_parse_args_215, string1834_init_parse_args_2151924, "-mkheap", 7);
DEFINE_STRING(string1833_init_parse_args_215, string1833_init_parse_args_2151925, "-mkaddlib", 9);
DEFINE_STRING(string1832_init_parse_args_215, string1832_init_parse_args_2151926, "-mklib", 6);
DEFINE_STRING(string1831_init_parse_args_215, string1831_init_parse_args_2151927, "-init-intern", 12);
DEFINE_STRING(string1829_init_parse_args_215, string1829_init_parse_args_2151928, "-init-lib", 9);
DEFINE_STRING(string1830_init_parse_args_215, string1830_init_parse_args_2151929, "-init-read", 10);
DEFINE_STRING(string1828_init_parse_args_215, string1828_init_parse_args_2151930, "-mco", 4);
DEFINE_STRING(string1827_init_parse_args_215, string1827_init_parse_args_2151931, "-indent", 7);
DEFINE_STRING(string1826_init_parse_args_215, string1826_init_parse_args_2151932, "-cgen", 5);
DEFINE_STRING(string1825_init_parse_args_215, string1825_init_parse_args_2151933, "-hgen", 5);
DEFINE_STRING(string1824_init_parse_args_215, string1824_init_parse_args_2151934, "-integrate", 10);
DEFINE_STRING(string1823_init_parse_args_215, string1823_init_parse_args_2151935, "-cnst", 5);
DEFINE_STRING(string1822_init_parse_args_215, string1822_init_parse_args_2151936, "-bdb", 4);
DEFINE_STRING(string1821_init_parse_args_215, string1821_init_parse_args_2151937, "-recovery", 9);
DEFINE_STRING(string1819_init_parse_args_215, string1819_init_parse_args_2151938, "-cfa", 4);
DEFINE_STRING(string1820_init_parse_args_215, string1820_init_parse_args_2151939, "-globalize", 10);
DEFINE_STRING(string1818_init_parse_args_215, string1818_init_parse_args_2151940, "-assert", 7);
DEFINE_STRING(string1817_init_parse_args_215, string1817_init_parse_args_2151941, "-reduce", 7);
DEFINE_STRING(string1816_init_parse_args_215, string1816_init_parse_args_2151942, "-effect", 7);
DEFINE_STRING(string1815_init_parse_args_215, string1815_init_parse_args_2151943, "-coerce", 7);
DEFINE_STRING(string1814_init_parse_args_215, string1814_init_parse_args_2151944, "-user", 5);
DEFINE_STRING(string1813_init_parse_args_215, string1813_init_parse_args_2151945, "-fuse", 5);
DEFINE_STRING(string1812_init_parse_args_215, string1812_init_parse_args_2151946, "-fail", 5);
DEFINE_STRING(string1811_init_parse_args_215, string1811_init_parse_args_2151947, "-inline+", 8);
DEFINE_STRING(string1799_init_parse_args_215, string1799_init_parse_args_2151948, "-t3", 3);
DEFINE_STRING(string1809_init_parse_args_215, string1809_init_parse_args_2151949, "-bivalue", 8);
DEFINE_STRING(string1810_init_parse_args_215, string1810_init_parse_args_2151950, "-inline", 7);
DEFINE_STRING(string1798_init_parse_args_215, string1798_init_parse_args_2151951, "-t2", 3);
DEFINE_STRING(string1808_init_parse_args_215, string1808_init_parse_args_2151952, "-callcc", 7);
DEFINE_STRING(string1797_init_parse_args_215, string1797_init_parse_args_2151953, "-t", 2);
DEFINE_STRING(string1807_init_parse_args_215, string1807_init_parse_args_2151954, "-trace", 6);
DEFINE_STRING(string1796_init_parse_args_215, string1796_init_parse_args_2151955, "-l", 2);
DEFINE_STRING(string1806_init_parse_args_215, string1806_init_parse_args_2151956, "-bdb-spread-obj", 15);
DEFINE_STRING(string1795_init_parse_args_215, string1795_init_parse_args_2151957, "-ldopt", 6);
DEFINE_STRING(string1805_init_parse_args_215, string1805_init_parse_args_2151958, "-ast", 4);
DEFINE_STRING(string1794_init_parse_args_215, string1794_init_parse_args_2151959, " ", 1);
DEFINE_STRING(string1804_init_parse_args_215, string1804_init_parse_args_2151960, "-expand", 7);
DEFINE_STRING(string1793_init_parse_args_215, string1793_init_parse_args_2151961, "-copt", 5);
DEFINE_STRING(string1803_init_parse_args_215, string1803_init_parse_args_2151962, "-syntax", 7);
DEFINE_STRING(string1792_init_parse_args_215, string1792_init_parse_args_2151963, "-stdc", 5);
DEFINE_STRING(string1802_init_parse_args_215, string1802_init_parse_args_2151964, "-shape", 6);
DEFINE_STRING(string1791_init_parse_args_215, string1791_init_parse_args_2151965, "-cc", 3);
DEFINE_STRING(string1801_init_parse_args_215, string1801_init_parse_args_2151966, "+t", 2);
DEFINE_STRING(string1789_init_parse_args_215, string1789_init_parse_args_2151967, "-w", 2);
DEFINE_STRING(string1790_init_parse_args_215, string1790_init_parse_args_2151968, "-Wall", 5);
DEFINE_STRING(string1800_init_parse_args_215, string1800_init_parse_args_2151969, "-t4", 3);
DEFINE_STRING(string1788_init_parse_args_215, string1788_init_parse_args_2151970, "-no-hello", 9);
DEFINE_STRING(string1787_init_parse_args_215, string1787_init_parse_args_2151971, "-v3", 3);
DEFINE_STRING(string1786_init_parse_args_215, string1786_init_parse_args_2151972, "-v2", 3);
DEFINE_STRING(string1785_init_parse_args_215, string1785_init_parse_args_2151973, "-v", 2);
DEFINE_STRING(string1784_init_parse_args_215, string1784_init_parse_args_2151974, "-s", 2);
DEFINE_STRING(string1783_init_parse_args_215, string1783_init_parse_args_2151975, "-farithmetic", 12);
DEFINE_STRING(string1782_init_parse_args_215, string1782_init_parse_args_2151976, "+fno-reflection", 15);
DEFINE_STRING(string1781_init_parse_args_215, string1781_init_parse_args_2151977, "-fno-reflection", 15);
DEFINE_STRING(string1779_init_parse_args_215, string1779_init_parse_args_2151978, "-call/cc", 8);
DEFINE_STRING(string1780_init_parse_args_215, string1780_init_parse_args_2151979, "-hygien", 7);
DEFINE_STRING(string1778_init_parse_args_215, string1778_init_parse_args_2151980, "-nil", 4);
DEFINE_STRING(string1777_init_parse_args_215, string1777_init_parse_args_2151981, "-L", 2);
DEFINE_STRING(string1776_init_parse_args_215, string1776_init_parse_args_2151982, "-lib-dir", 8);
DEFINE_STRING(string1775_init_parse_args_215, string1775_init_parse_args_2151983, "-I", 2);
DEFINE_STRING(string1774_init_parse_args_215, string1774_init_parse_args_2151984, "-eval", 5);
DEFINE_STRING(string1773_init_parse_args_215, string1773_init_parse_args_2151985, "-q", 2);
DEFINE_STRING(string1772_init_parse_args_215, string1772_init_parse_args_2151986, "-query", 6);
DEFINE_STRING(string1771_init_parse_args_215, string1771_init_parse_args_2151987, "-revision", 9);
DEFINE_STRING(string1769_init_parse_args_215, string1769_init_parse_args_2151988, "-pg", 3);
DEFINE_STRING(string1770_init_parse_args_215, string1770_init_parse_args_2151989, "-version", 8);
DEFINE_STRING(string1768_init_parse_args_215, string1768_init_parse_args_2151990, "-static-bigloo", 14);
DEFINE_STRING(string1767_init_parse_args_215, string1767_init_parse_args_2151991, "-p2", 3);
DEFINE_STRING(string1766_init_parse_args_215, string1766_init_parse_args_2151992, " -pg", 4);
DEFINE_STRING(string1765_init_parse_args_215, string1765_init_parse_args_2151993, "-p", 2);
DEFINE_STRING(string1764_init_parse_args_215, string1764_init_parse_args_2151994, "-gbdb2", 6);
DEFINE_STRING(string1763_init_parse_args_215, string1763_init_parse_args_2151995, "bdb.heap", 8);
DEFINE_STRING(string1762_init_parse_args_215, string1762_init_parse_args_2151996, "-gbdb", 5);
DEFINE_STRING(string1761_init_parse_args_215, string1761_init_parse_args_2151997, "-cg", 3);
DEFINE_STRING(string1759_init_parse_args_215, string1759_init_parse_args_2151998, "-g3", 3);
DEFINE_STRING(string1760_init_parse_args_215, string1760_init_parse_args_2151999, "-g4", 3);
DEFINE_STRING(string1758_init_parse_args_215, string1758_init_parse_args_2152000, "-g2", 3);
DEFINE_STRING(string1757_init_parse_args_215, string1757_init_parse_args_2152001, "-g", 2);
DEFINE_STRING(string1756_init_parse_args_215, string1756_init_parse_args_2152002, "-unsafe", 7);
DEFINE_STRING(string1755_init_parse_args_215, string1755_init_parse_args_2152003, "-fmco", 5);
DEFINE_STRING(string1754_init_parse_args_215, string1754_init_parse_args_2152004, "-fno-sharing", 12);
DEFINE_STRING(string1753_init_parse_args_215, string1753_init_parse_args_2152005, "-fsharing", 9);
DEFINE_STRING(string1752_init_parse_args_215, string1752_init_parse_args_2152006, "+rm", 3);
DEFINE_STRING(string1751_init_parse_args_215, string1751_init_parse_args_2152007, "-rm", 3);
DEFINE_STRING(string1749_init_parse_args_215, string1749_init_parse_args_2152008, "-fO-macro", 9);
DEFINE_STRING(string1750_init_parse_args_215, string1750_init_parse_args_2152009, "-fno-O-macro", 12);
DEFINE_STRING(string1748_init_parse_args_215, string1748_init_parse_args_2152010, "-fno-inlining", 13);
DEFINE_STRING(string1747_init_parse_args_215, string1747_init_parse_args_2152011, "-floop-inlining", 15);
DEFINE_STRING(string1746_init_parse_args_215, string1746_init_parse_args_2152012, "-fno-loop-inlining", 18);
DEFINE_STRING(string1745_init_parse_args_215, string1745_init_parse_args_2152013, "-fno-unroll-loop", 16);
DEFINE_STRING(string1744_init_parse_args_215, string1744_init_parse_args_2152014, "-funroll-loop", 13);
DEFINE_STRING(string1743_init_parse_args_215, string1743_init_parse_args_2152015, "-fno-inline-method", 18);
DEFINE_STRING(string1742_init_parse_args_215, string1742_init_parse_args_2152016, "-finline-method", 15);
DEFINE_STRING(string1741_init_parse_args_215, string1741_init_parse_args_2152017, "-fno-stack", 10);
DEFINE_STRING(string1739_init_parse_args_215, string1739_init_parse_args_2152018, "-O", 2);
DEFINE_STRING(string1740_init_parse_args_215, string1740_init_parse_args_2152019, "-fstack", 7);
DEFINE_STRING(string1738_init_parse_args_215, string1738_init_parse_args_2152020, "-Obench", 7);
DEFINE_STRING(string1737_init_parse_args_215, string1737_init_parse_args_2152021, "-heapsize", 9);
DEFINE_STRING(string1736_init_parse_args_215, string1736_init_parse_args_2152022, ".heap", 5);
DEFINE_STRING(string1735_init_parse_args_215, string1735_init_parse_args_2152023, "-library", 8);
DEFINE_STRING(string1734_init_parse_args_215, string1734_init_parse_args_2152024, "-main", 5);
DEFINE_STRING(string1733_init_parse_args_215, string1733_init_parse_args_2152025, "-access", 7);
DEFINE_STRING(string1732_init_parse_args_215, string1732_init_parse_args_2152026, "-afile", 6);
DEFINE_STRING(string1731_init_parse_args_215, string1731_init_parse_args_2152027, "-i", 2);
DEFINE_STRING(string1729_init_parse_args_215, string1729_init_parse_args_2152028, "-c", 2);
DEFINE_STRING(string1730_init_parse_args_215, string1730_init_parse_args_2152029, "-suffix", 7);
DEFINE_STRING(string1728_init_parse_args_215, string1728_init_parse_args_2152030, "--to-stdout", 11);
DEFINE_STRING(string1727_init_parse_args_215, string1727_init_parse_args_2152031, "-o", 2);
DEFINE_STRING(string1726_init_parse_args_215, string1726_init_parse_args_2152032, "-help-manual", 12);
DEFINE_STRING(string1725_init_parse_args_215, string1725_init_parse_args_2152033, "-help2", 6);
DEFINE_STRING(string1724_init_parse_args_215, string1724_init_parse_args_2152034, "-help", 5);
DEFINE_STRING(string1723_init_parse_args_215, string1723_init_parse_args_2152035, "?", 1);
DEFINE_STRING(string1722_init_parse_args_215, string1722_init_parse_args_2152036, "-", 1);
DEFINE_STRING(string1721_init_parse_args_215, string1721_init_parse_args_2152037, "see `-help' option", 18);
DEFINE_STRING(string1720_init_parse_args_215, string1720_init_parse_args_2152038, "Illegal option", 14);
DEFINE_STRING(string1718_init_parse_args_215, string1718_init_parse_args_2152039, "parse-args", 10);
DEFINE_STRING(string1717_init_parse_args_215, string1717_init_parse_args_2152040, "No trace for this pass -- ", 26);
DEFINE_STRING(string1716_init_parse_args_215, string1716_init_parse_args_2152041, "Incompatible options", 20);
DEFINE_STRING(string1715_init_parse_args_215, string1715_init_parse_args_2152042, "-O / -gbdb", 10);
DEFINE_STRING(string1714_init_parse_args_215, string1714_init_parse_args_2152043, "disabling debug", 15);
DEFINE_STRING(string1713_init_parse_args_215, string1713_init_parse_args_2152044, "-extend", 7);


/* module-initialization */ obj_t 
module_initialization_70_init_parse_args_215(long checksum_1645, char *from_1646)
{
   if (CBOOL(require_initialization_114_init_parse_args_215))
     {
	require_initialization_114_init_parse_args_215 = BBOOL(((bool_t) 0));
	library_modules_init_112_init_parse_args_215();
	cnst_init_137_init_parse_args_215();
	imported_modules_init_94_init_parse_args_215();
	method_init_76_init_parse_args_215();
	toplevel_init_63_init_parse_args_215();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_init_parse_args_215()
{
   module_initialization_70___bexit(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___eval(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___error(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___os(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___r4_strings_6_7(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___r5_macro_4_3_init(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___r4_output_6_10_3(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___r4_control_features_6_9(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70___reader(((long) 0), "INIT_PARSE-ARGS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_init_parse_args_215()
{
   {
      obj_t cnst_port_138_1637;
      cnst_port_138_1637 = open_input_string(string1875_init_parse_args_215);
      {
	 long i_1638;
	 i_1638 = ((long) 45);
       loop_1639:
	 {
	    bool_t test1876_1640;
	    test1876_1640 = (i_1638 == ((long) -1));
	    if (test1876_1640)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1877_1641;
		    {
		       obj_t list1878_1642;
		       {
			  obj_t arg1879_1643;
			  arg1879_1643 = BNIL;
			  list1878_1642 = MAKE_PAIR(cnst_port_138_1637, arg1879_1643);
		       }
		       arg1877_1641 = read___reader(list1878_1642);
		    }
		    CNST_TABLE_SET(i_1638, arg1877_1641);
		 }
		 {
		    int aux_1644;
		    {
		       long aux_1672;
		       aux_1672 = (i_1638 - ((long) 1));
		       aux_1644 = (int) (aux_1672);
		    }
		    {
		       long i_1675;
		       i_1675 = (long) (aux_1644);
		       i_1638 = i_1675;
		       goto loop_1639;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_init_parse_args_215()
{
   _extended_done___215_init_parse_args_215 = ((bool_t) 0);
   _library_init__55_init_parse_args_215 = BNIL;
   return (_trace_level__157_init_parse_args_215 = ((long) 0),
      BUNSPEC);
}


/* parse-args */ obj_t 
parse_args_143_init_parse_args_215(obj_t args_1)
{
   _bigloo_cmd_name__60_engine_param = CAR(args_1);
   _bigloo_args__103_engine_param = args_1;
   do_parse_args_215_init_parse_args_215(CDR(args_1));
   {
      obj_t pres_18;
      if (_extended_done___215_init_parse_args_215)
	{
	   pres_18 = BTRUE;
	}
      else
	{
	   obj_t auto_mode_58_57;
	   {
	      obj_t sfiles_68;
	      sfiles_68 = _src_files__222_engine_param;
	    loop_69:
	      if (NULLP(sfiles_68))
		{
		   auto_mode_58_57 = BFALSE;
		}
	      else
		{
		   obj_t cell_71;
		   {
		      bool_t test_1683;
		      {
			 obj_t aux_1684;
			 aux_1684 = CAR(sfiles_68);
			 test_1683 = STRINGP(aux_1684);
		      }
		      if (test_1683)
			{
			   obj_t arg1211_75;
			   arg1211_75 = suffix___os(CAR(sfiles_68));
			   cell_71 = assoc___r4_pairs_and_lists_6_3(arg1211_75, _auto_mode__185_engine_param);
			}
		      else
			{
			   cell_71 = BFALSE;
			}
		   }
		   if (PAIRP(cell_71))
		     {
			auto_mode_58_57 = CDR(cell_71);
		     }
		   else
		     {
			obj_t sfiles_1693;
			sfiles_1693 = CDR(sfiles_68);
			sfiles_68 = sfiles_1693;
			goto loop_69;
		     }
		}
	   }
	   if (CBOOL(auto_mode_58_57))
	     {
		_src_files__222_engine_param = BNIL;
		{
		   obj_t arg1197_58;
		   {
		      obj_t arg1200_60;
		      {
			 obj_t arg1204_64;
			 obj_t arg1205_65;
			 arg1204_64 = CDR(args_1);
			 arg1205_65 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
			 arg1200_60 = append_2_18___r4_pairs_and_lists_6_3(arg1204_64, arg1205_65);
		      }
		      {
			 obj_t list1201_61;
			 {
			    obj_t arg1202_62;
			    arg1202_62 = MAKE_PAIR(arg1200_60, BNIL);
			    list1201_61 = MAKE_PAIR(auto_mode_58_57, arg1202_62);
			 }
			 arg1197_58 = cons__138___r4_pairs_and_lists_6_3(string1713_init_parse_args_215, list1201_61);
		      }
		   }
		   pres_18 = do_parse_args_215_init_parse_args_215(arg1197_58);
		}
	     }
	   else
	     {
		pres_18 = BTRUE;
	     }
	}
      _src_files__222_engine_param = reverse__39___r4_pairs_and_lists_6_3(_src_files__222_engine_param);
      _o_files__27_engine_param = reverse__39___r4_pairs_and_lists_6_3(_o_files__27_engine_param);
      _load_path__54___eval = reverse__39___r4_pairs_and_lists_6_3(_load_path__54___eval);
      _bigloo_user_lib__33_engine_param = reverse__39___r4_pairs_and_lists_6_3(_bigloo_user_lib__33_engine_param);
      _rest_args__8_engine_param = reverse__39___r4_pairs_and_lists_6_3(_rest_args__8_engine_param);
      _lib_dir__34_engine_param = reverse__39___r4_pairs_and_lists_6_3(_lib_dir__34_engine_param);
      {
	 bool_t test1054_19;
	 {
	    obj_t obj_973;
	    obj_973 = _optim_stack___57_engine_param;
	    test1054_19 = BOOLEANP(obj_973);
	 }
	 if (test1054_19)
	   {
	      BUNSPEC;
	   }
	 else
	   {
	      _optim_stack___57_engine_param = BFALSE;
	   }
      }
      {
	 bool_t test1067_20;
	 {
	    obj_t obj_974;
	    obj_974 = _optim_unroll_loop___80_engine_param;
	    test1067_20 = BOOLEANP(obj_974);
	 }
	 if (test1067_20)
	   {
	      BUNSPEC;
	   }
	 else
	   {
	      _optim_unroll_loop___80_engine_param = BFALSE;
	   }
      }
      {
	 bool_t test1068_21;
	 {
	    obj_t obj_975;
	    obj_975 = _optim_inline_method___30_engine_param;
	    test1068_21 = BOOLEANP(obj_975);
	 }
	 if (test1068_21)
	   {
	      BUNSPEC;
	   }
	 else
	   {
	      _optim_inline_method___30_engine_param = BFALSE;
	   }
      }
      {
	 bool_t test1069_22;
	 {
	    long n1_976;
	    n1_976 = (long) CINT(_bdb_debug__1_engine_param);
	    test1069_22 = (n1_976 > ((long) 0));
	 }
	 if (test1069_22)
	   {
	      _inlining___224_engine_param = BFALSE;
	      {
		 bool_t test1070_23;
		 {
		    long n1_978;
		    n1_978 = (long) CINT(_optim__89_engine_param);
		    test1070_23 = (n1_978 > ((long) 0));
		 }
		 if (test1070_23)
		   {
		      {
			 obj_t list1071_24;
			 {
			    obj_t arg1137_26;
			    {
			       obj_t arg1144_28;
			       arg1144_28 = MAKE_PAIR(string1714_init_parse_args_215, BNIL);
			       arg1137_26 = MAKE_PAIR(string1715_init_parse_args_215, arg1144_28);
			    }
			    list1071_24 = MAKE_PAIR(string1716_init_parse_args_215, arg1137_26);
			 }
			 warning___error(list1071_24);
		      }
		      _bdb_debug__1_engine_param = BINT(((long) 0));
		   }
		 else
		   {
		      BUNSPEC;
		   }
	      }
	   }
	 else
	   {
	      BUNSPEC;
	   }
      }
      {
	 bool_t test1151_31;
	 {
	    long n1_980;
	    n1_980 = _trace_level__157_init_parse_args_215;
	    test1151_31 = (n1_980 > ((long) 0));
	 }
	 if (test1151_31)
	   {
	      {
		 bool_t test1152_33;
		 {
		    obj_t aux_1729;
		    aux_1729 = memq___r4_pairs_and_lists_6_3(_pass__125_engine_param, BUNSPEC);
		    test1152_33 = CBOOL(aux_1729);
		 }
		 if (test1152_33)
		   {
		      start_trace_17_tools_trace(BINT(_trace_level__157_init_parse_args_215), _pass__125_engine_param);
		   }
		 else
		   {
		      obj_t list1153_34;
		      {
			 obj_t arg1161_36;
			 {
			    obj_t arg1175_38;
			    arg1175_38 = MAKE_PAIR(_pass__125_engine_param, BNIL);
			    arg1161_36 = MAKE_PAIR(string1717_init_parse_args_215, arg1175_38);
			 }
			 list1153_34 = MAKE_PAIR(string1718_init_parse_args_215, arg1161_36);
		      }
		      warning___error(list1153_34);
		   }
	      }
	      {
		 obj_t l1017_40;
		 {
		    bool_t aux_1739;
		    l1017_40 = _additional_traces__2_engine_param;
		  lname1018_41:
		    if (PAIRP(l1017_40))
		      {
			 {
			    obj_t pass_43;
			    pass_43 = CAR(l1017_40);
			    {
			       bool_t test_1743;
			       {
				  obj_t aux_1744;
				  aux_1744 = memq___r4_pairs_and_lists_6_3(pass_43, BUNSPEC);
				  test_1743 = CBOOL(aux_1744);
			       }
			       if (test_1743)
				 {
				    BUNSPEC;
				 }
			       else
				 {
				    obj_t list1179_45;
				    {
				       obj_t arg1188_47;
				       {
					  obj_t arg1191_49;
					  arg1191_49 = MAKE_PAIR(pass_43, BNIL);
					  arg1188_47 = MAKE_PAIR(string1717_init_parse_args_215, arg1191_49);
				       }
				       list1179_45 = MAKE_PAIR(string1718_init_parse_args_215, arg1188_47);
				    }
				    warning___error(list1179_45);
				 }
			    }
			 }
			 {
			    obj_t l1017_1751;
			    l1017_1751 = CDR(l1017_40);
			    l1017_40 = l1017_1751;
			    goto lname1018_41;
			 }
		      }
		    else
		      {
			 aux_1739 = ((bool_t) 1);
		      }
		    BBOOL(aux_1739);
		 }
	      }
	   }
	 else
	   {
	      BUNSPEC;
	   }
      }
      {
	 obj_t l1019_52;
	 l1019_52 = _library_init__55_init_parse_args_215;
       lname1020_53:
	 if (PAIRP(l1019_52))
	   {
	      setup_library_values_14_init_setrc(CAR(l1019_52));
	      {
		 obj_t l1019_1758;
		 l1019_1758 = CDR(l1019_52);
		 l1019_52 = l1019_1758;
		 goto lname1020_53;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      return pres_18;
   }
}


/* _parse-args */ obj_t 
_parse_args_194_init_parse_args_215(obj_t env_1597, obj_t args_1598)
{
   return parse_args_143_init_parse_args_215(args_1598);
}


/* do-parse-args */ obj_t 
do_parse_args_215_init_parse_args_215(obj_t args_2)
{
   {
      obj_t args_parse_usage_117_1600;
      args_parse_usage_117_1600 = proc1719_init_parse_args_215;
      {
	 {
	    bool_t test_1761;
	    if (PAIRP(args_2))
	      {
		 test_1761 = ((bool_t) 0);
	      }
	    else
	      {
		 if (NULLP(args_2))
		   {
		      test_1761 = ((bool_t) 0);
		   }
		 else
		   {
		      test_1761 = ((bool_t) 1);
		   }
	      }
	    if (test_1761)
	      {
		 FAILURE(string1720_init_parse_args_215, string1721_init_parse_args_215, args_2);
	      }
	    else
	      {
		 {
		    obj_t arg1032_84;
		    arg1032_84 = MAKE_CELL(args_2);
		    {
		       obj_t armed1042_85;
		       armed1042_85 = MAKE_CELL(BUNSPEC);
		       {
			  obj_t body1041_1601;
			  obj_t rhandler1040_1603;
			  body1041_1601 = make_fx_procedure(body1041_init_parse_args_215, ((long) 0), ((long) 3));
			  rhandler1040_1603 = make_fx_procedure(rhandler1040_init_parse_args_215, ((long) 4), ((long) 2));
			  PROCEDURE_SET(body1041_1601, ((long) 0), arg1032_84);
			  PROCEDURE_SET(body1041_1601, ((long) 1), args_parse_usage_117_1600);
			  PROCEDURE_SET(body1041_1601, ((long) 2), args_2);
			  PROCEDURE_SET(rhandler1040_1603, ((long) 0), armed1042_85);
			  PROCEDURE_SET(rhandler1040_1603, ((long) 1), arg1032_84);
			  CELL_SET(armed1042_85, BTRUE);
			  return handling_function1216_init_parse_args_215(body1041_1601, rhandler1040_1603, arg1032_84, armed1042_85);
		       }
		    }
		 }
	      }
	 }
      }
   }
}


/* handling_function1216 */ obj_t 
handling_function1216_init_parse_args_215(obj_t body1041_1636, obj_t rhandler1040_1635, obj_t arg1032_1634, obj_t armed1042_1633)
{
   jmp_buf jmpbuf;
   obj_t an_exit1043_90;
   if (SET_EXIT(an_exit1043_90))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1043_90 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1043_90, ((bool_t) 1));
	   {
	      obj_t an_exitd1044_91;
	      an_exitd1044_91 = exitd_top;
	      {
		 obj_t escape_1602;
		 escape_1602 = make_fx_procedure(escape_init_parse_args_215, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_1602, ((long) 0), an_exitd1044_91);
		 {
		    obj_t res1046_94;
		    {
		       obj_t arg1220_1599;
		       obj_t arg1219_1604;
		       arg1220_1599 = make_fx_procedure(arg1220_init_parse_args_215, ((long) 0), ((long) 1));
		       arg1219_1604 = make_fx_procedure(arg1219_init_parse_args_215, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1220_1599, ((long) 0), armed1042_1633);
		       PROCEDURE_SET(arg1219_1604, ((long) 0), an_exitd1044_91);
		       PROCEDURE_SET(arg1219_1604, ((long) 1), armed1042_1633);
		       PROCEDURE_SET(arg1219_1604, ((long) 2), arg1032_1634);
		       PROCEDURE_SET(arg1219_1604, ((long) 3), rhandler1040_1635);
		       PROCEDURE_SET(arg1219_1604, ((long) 4), escape_1602);
		       res1046_94 = dynamic_wind_31___r4_control_features_6_9(arg1219_1604, body1041_1636, arg1220_1599);
		    }
		    POP_EXIT();
		    return res1046_94;
		 }
	      }
	   }
	}
     }
}


/* arg1220 */ obj_t 
arg1220_init_parse_args_215(obj_t env_1605)
{
   {
      obj_t armed1042_1606;
      armed1042_1606 = PROCEDURE_REF(env_1605, ((long) 0));
      {
	 {
	    bool_t test_1791;
	    {
	       obj_t aux_1792;
	       aux_1792 = CELL_REF(armed1042_1606);
	       test_1791 = CBOOL(aux_1792);
	    }
	    if (test_1791)
	      {
		 CELL_SET(armed1042_1606, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1041 */ obj_t 
body1041_init_parse_args_215(obj_t env_1608)
{
   {
      obj_t arg1032_1609;
      obj_t args_parse_usage_117_1610;
      obj_t argv1023_1611;
      arg1032_1609 = PROCEDURE_REF(env_1608, ((long) 0));
      args_parse_usage_117_1610 = PROCEDURE_REF(env_1608, ((long) 1));
      argv1023_1611 = PROCEDURE_REF(env_1608, ((long) 2));
      {
	 {
	    obj_t runner1024_112;
	    obj_t done1034_113;
	    runner1024_112 = argv1023_1611;
	    done1034_113 = BFALSE;
	  loop1033_114:
	    if (NULLP(runner1024_112))
	      {
		 return CNST_TABLE_REF(((long) 0));
	      }
	    else
	      {
		 bool_t test_1801;
		 {
		    obj_t aux_1802;
		    aux_1802 = CNST_TABLE_REF(((long) 1));
		    test_1801 = (done1034_113 == aux_1802);
		 }
		 if (test_1801)
		   {
		      return done1034_113;
		   }
		 else
		   {
		      if (PAIRP(runner1024_112))
			{
			   {
			      obj_t arg1025_118;
			      arg1025_118 = CAR(runner1024_112);
			      {
				 CELL_SET(arg1032_1609, runner1024_112);
				 {
				    bool_t test1229_120;
				    test1229_120 = bigloo_strcmp(arg1025_118, string1722_init_parse_args_215);
				    if (test1229_120)
				      {
					 {
					    obj_t the_remaining_args_132_122;
					    the_remaining_args_132_122 = CDR(runner1024_112);
					    {
					       obj_t action_123;
					       {
						  obj_t obj2_1011;
						  obj2_1011 = _src_files__222_engine_param;
						  {
						     obj_t aux_1811;
						     aux_1811 = CNST_TABLE_REF(((long) 2));
						     action_123 = (_src_files__222_engine_param = MAKE_PAIR(aux_1811, obj2_1011),
							BUNSPEC);
						  }
					       }
					       {
						  {
						     obj_t done1034_1815;
						     obj_t runner1024_1814;
						     runner1024_1814 = the_remaining_args_132_122;
						     done1034_1815 = action_123;
						     done1034_113 = done1034_1815;
						     runner1024_112 = runner1024_1814;
						     goto loop1033_114;
						  }
					       }
					    }
					 }
				      }
				    else
				      {
					 bool_t test1232_125;
					 test1232_125 = bigloo_strcmp(arg1025_118, string1723_init_parse_args_215);
					 if (test1232_125)
					   {
					      {
						 obj_t the_remaining_args_132_127;
						 the_remaining_args_132_127 = CDR(runner1024_112);
						 {
						    obj_t action_128;
						    action_128 = usage_init_parse_args_215(args_parse_usage_117_1610, ((long) 1), ((bool_t) 0));
						    {
						       {
							  obj_t done1034_1821;
							  obj_t runner1024_1820;
							  runner1024_1820 = the_remaining_args_132_127;
							  done1034_1821 = action_128;
							  done1034_113 = done1034_1821;
							  runner1024_112 = runner1024_1820;
							  goto loop1033_114;
						       }
						    }
						 }
					      }
					   }
					 else
					   {
					      bool_t test1233_129;
					      test1233_129 = bigloo_strcmp(arg1025_118, string1724_init_parse_args_215);
					      if (test1233_129)
						{
						   {
						      obj_t the_remaining_args_132_131;
						      the_remaining_args_132_131 = CDR(runner1024_112);
						      {
							 obj_t action_132;
							 action_132 = usage_init_parse_args_215(args_parse_usage_117_1610, ((long) 1), ((bool_t) 0));
							 {
							    {
							       obj_t done1034_1827;
							       obj_t runner1024_1826;
							       runner1024_1826 = the_remaining_args_132_131;
							       done1034_1827 = action_132;
							       done1034_113 = done1034_1827;
							       runner1024_112 = runner1024_1826;
							       goto loop1033_114;
							    }
							 }
						      }
						   }
						}
					      else
						{
						   bool_t test1234_133;
						   test1234_133 = bigloo_strcmp(arg1025_118, string1725_init_parse_args_215);
						   if (test1234_133)
						     {
							{
							   obj_t the_remaining_args_132_135;
							   the_remaining_args_132_135 = CDR(runner1024_112);
							   {
							      obj_t action_136;
							      action_136 = usage_init_parse_args_215(args_parse_usage_117_1610, ((long) 2), ((bool_t) 0));
							      {
								 {
								    obj_t done1034_1833;
								    obj_t runner1024_1832;
								    runner1024_1832 = the_remaining_args_132_135;
								    done1034_1833 = action_136;
								    done1034_113 = done1034_1833;
								    runner1024_112 = runner1024_1832;
								    goto loop1033_114;
								 }
							      }
							   }
							}
						     }
						   else
						     {
							bool_t test1235_137;
							test1235_137 = bigloo_strcmp(arg1025_118, string1726_init_parse_args_215);
							if (test1235_137)
							  {
							     {
								obj_t the_remaining_args_132_139;
								the_remaining_args_132_139 = CDR(runner1024_112);
								{
								   obj_t action_140;
								   action_140 = usage_init_parse_args_215(args_parse_usage_117_1610, ((long) 2), ((bool_t) 1));
								   {
								      {
									 obj_t done1034_1839;
									 obj_t runner1024_1838;
									 runner1024_1838 = the_remaining_args_132_139;
									 done1034_1839 = action_140;
									 done1034_113 = done1034_1839;
									 runner1024_112 = runner1024_1838;
									 goto loop1033_114;
								      }
								   }
								}
							     }
							  }
							else
							  {
							     bool_t test1236_141;
							     test1236_141 = bigloo_strcmp(arg1025_118, string1727_init_parse_args_215);
							     if (test1236_141)
							       {
								  {
								     obj_t action_145;
								     {
									obj_t aux_1842;
									aux_1842 = CDR(runner1024_112);
									action_145 = (_dest__217_engine_param = CAR(aux_1842),
									   BUNSPEC);
								     }
								     {
									{
									   obj_t done1034_1849;
									   obj_t runner1024_1845;
									   {
									      obj_t aux_1846;
									      aux_1846 = CDR(runner1024_112);
									      runner1024_1845 = CDR(aux_1846);
									   }
									   done1034_1849 = action_145;
									   done1034_113 = done1034_1849;
									   runner1024_112 = runner1024_1845;
									   goto loop1033_114;
									}
								     }
								  }
							       }
							     else
							       {
								  bool_t test1241_148;
								  test1241_148 = bigloo_strcmp(arg1025_118, string1728_init_parse_args_215);
								  if (test1241_148)
								    {
								       {
									  obj_t action_151;
									  _verbose__1_engine_param = BINT(((long) -1));
									  action_151 = (_dest__217_engine_param = CNST_TABLE_REF(((long) 3)),
									     BUNSPEC);
									  {
									     {
										obj_t done1034_1856;
										obj_t runner1024_1854;
										runner1024_1854 = CDR(runner1024_112);
										done1034_1856 = action_151;
										done1034_113 = done1034_1856;
										runner1024_112 = runner1024_1854;
										goto loop1033_114;
									     }
									  }
								       }
								    }
								  else
								    {
								       bool_t test1242_152;
								       test1242_152 = bigloo_strcmp(arg1025_118, string1729_init_parse_args_215);
								       if (test1242_152)
									 {
									    {
									       obj_t action_155;
									       action_155 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 4)),
										  BUNSPEC);
									       {
										  {
										     obj_t done1034_1862;
										     obj_t runner1024_1860;
										     runner1024_1860 = CDR(runner1024_112);
										     done1034_1862 = action_155;
										     done1034_113 = done1034_1862;
										     runner1024_112 = runner1024_1860;
										     goto loop1033_114;
										  }
									       }
									    }
									 }
								       else
									 {
									    bool_t test1243_156;
									    test1243_156 = bigloo_strcmp(arg1025_118, string1730_init_parse_args_215);
									    if (test1243_156)
									      {
										 {
										    obj_t the_remaining_args_132_159;
										    {
										       obj_t aux_1865;
										       aux_1865 = CDR(runner1024_112);
										       the_remaining_args_132_159 = CDR(aux_1865);
										    }
										    {
										       obj_t action_160;
										       {
											  obj_t obj2_1043;
											  obj2_1043 = _src_suffix__192_engine_param;
											  {
											     obj_t aux_1868;
											     {
												obj_t aux_1869;
												aux_1869 = CDR(runner1024_112);
												aux_1868 = CAR(aux_1869);
											     }
											     action_160 = (_src_suffix__192_engine_param = MAKE_PAIR(aux_1868, obj2_1043),
												BUNSPEC);
											  }
										       }
										       {
											  {
											     obj_t done1034_1874;
											     obj_t runner1024_1873;
											     runner1024_1873 = the_remaining_args_132_159;
											     done1034_1874 = action_160;
											     done1034_113 = done1034_1874;
											     runner1024_112 = runner1024_1873;
											     goto loop1033_114;
											  }
										       }
										    }
										 }
									      }
									    else
									      {
										 bool_t test1246_163;
										 test1246_163 = bigloo_strcmp(arg1025_118, string1731_init_parse_args_215);
										 if (test1246_163)
										   {
										      {
											 obj_t action_166;
											 action_166 = (_interpreter__140_engine_param = BTRUE,
											    BUNSPEC);
											 {
											    {
											       obj_t done1034_1879;
											       obj_t runner1024_1877;
											       runner1024_1877 = CDR(runner1024_112);
											       done1034_1879 = action_166;
											       done1034_113 = done1034_1879;
											       runner1024_112 = runner1024_1877;
											       goto loop1033_114;
											    }
											 }
										      }
										   }
										 else
										   {
										      bool_t test1247_167;
										      test1247_167 = bigloo_strcmp(arg1025_118, string1732_init_parse_args_215);
										      if (test1247_167)
											{
											   {
											      obj_t action_171;
											      {
												 obj_t aux_1882;
												 aux_1882 = CDR(runner1024_112);
												 action_171 = (_access_file__194_engine_param = CAR(aux_1882),
												    BUNSPEC);
											      }
											      {
												 {
												    obj_t done1034_1889;
												    obj_t runner1024_1885;
												    {
												       obj_t aux_1886;
												       aux_1886 = CDR(runner1024_112);
												       runner1024_1885 = CDR(aux_1886);
												    }
												    done1034_1889 = action_171;
												    done1034_113 = done1034_1889;
												    runner1024_112 = runner1024_1885;
												    goto loop1033_114;
												 }
											      }
											   }
											}
										      else
											{
											   bool_t test1251_174;
											   test1251_174 = bigloo_strcmp(arg1025_118, string1733_init_parse_args_215);
											   if (test1251_174)
											     {
												{
												   obj_t the_remaining_args_132_178;
												   {
												      obj_t aux_1892;
												      {
													 obj_t aux_1893;
													 aux_1893 = CDR(runner1024_112);
													 aux_1892 = CDR(aux_1893);
												      }
												      the_remaining_args_132_178 = CDR(aux_1892);
												   }
												   {
												      obj_t action_179;
												      {
													 obj_t arg1252_180;
													 obj_t arg1253_181;
													 {
													    obj_t arg1254_182;
													    {
													       obj_t aux_1897;
													       {
														  obj_t aux_1898;
														  aux_1898 = CDR(runner1024_112);
														  aux_1897 = CAR(aux_1898);
													       }
													       arg1254_182 = string_upcase_71___r4_strings_6_7(aux_1897);
													    }
													    {
													       char *aux_1902;
													       aux_1902 = BSTRING_TO_STRING(arg1254_182);
													       arg1252_180 = string_to_symbol(aux_1902);
													    }
													 }
													 {
													    obj_t list1255_183;
													    {
													       obj_t aux_1905;
													       {
														  obj_t aux_1906;
														  {
														     obj_t aux_1907;
														     aux_1907 = CDR(runner1024_112);
														     aux_1906 = CDR(aux_1907);
														  }
														  aux_1905 = CAR(aux_1906);
													       }
													       list1255_183 = MAKE_PAIR(aux_1905, BNIL);
													    }
													    arg1253_181 = list1255_183;
													 }
													 action_179 = add_access__140_read_access(arg1252_180, arg1253_181);
												      }
												      {
													 {
													    obj_t done1034_1914;
													    obj_t runner1024_1913;
													    runner1024_1913 = the_remaining_args_132_178;
													    done1034_1914 = action_179;
													    done1034_113 = done1034_1914;
													    runner1024_112 = runner1024_1913;
													    goto loop1033_114;
													 }
												      }
												   }
												}
											     }
											   else
											     {
												bool_t test1263_190;
												test1263_190 = bigloo_strcmp(arg1025_118, string1734_init_parse_args_215);
												if (test1263_190)
												  {
												     {
													obj_t the_remaining_args_132_193;
													{
													   obj_t aux_1917;
													   aux_1917 = CDR(runner1024_112);
													   the_remaining_args_132_193 = CDR(aux_1917);
													}
													{
													   obj_t action_194;
													   {
													      obj_t arg1265_195;
													      {
														 obj_t aux_1920;
														 {
														    obj_t aux_1921;
														    aux_1921 = CDR(runner1024_112);
														    aux_1920 = CAR(aux_1921);
														 }
														 arg1265_195 = string_upcase_71___r4_strings_6_7(aux_1920);
													      }
													      {
														 char *aux_1925;
														 aux_1925 = BSTRING_TO_STRING(arg1265_195);
														 action_194 = (_main__152_module_module = string_to_symbol(aux_1925),
														    BUNSPEC);
													      }
													   }
													   {
													      {
														 obj_t done1034_1929;
														 obj_t runner1024_1928;
														 runner1024_1928 = the_remaining_args_132_193;
														 done1034_1929 = action_194;
														 done1034_113 = done1034_1929;
														 runner1024_112 = runner1024_1928;
														 goto loop1033_114;
													      }
													   }
													}
												     }
												  }
												else
												  {
												     bool_t test1269_198;
												     test1269_198 = bigloo_strcmp(arg1025_118, string1735_init_parse_args_215);
												     if (test1269_198)
												       {
													  {
													     obj_t library_199;
													     {
														obj_t aux_1932;
														aux_1932 = CDR(runner1024_112);
														library_199 = CAR(aux_1932);
													     }
													     {
														obj_t the_remaining_args_132_201;
														{
														   obj_t aux_1935;
														   aux_1935 = CDR(runner1024_112);
														   the_remaining_args_132_201 = CDR(aux_1935);
														}
														{
														   obj_t action_202;
														   {
														      obj_t lib_name_97_203;
														      lib_name_97_203 = make_library_name_119_module_alibrary(library_199);
														      {
															 obj_t heap_name_210_204;
															 heap_name_210_204 = string_append(lib_name_97_203, string1736_init_parse_args_215);
															 {
															    {
															       obj_t obj2_1079;
															       obj2_1079 = _library_init__55_init_parse_args_215;
															       _library_init__55_init_parse_args_215 = MAKE_PAIR(library_199, obj2_1079);
															    }
															    {
															       obj_t obj2_1081;
															       obj2_1081 = _additional_bigloo_libraries__50_engine_param;
															       _additional_bigloo_libraries__50_engine_param = MAKE_PAIR(lib_name_97_203, obj2_1081);
															    }
															    {
															       obj_t obj2_1083;
															       obj2_1083 = _additional_heap_names__104_engine_param;
															       action_202 = (_additional_heap_names__104_engine_param = MAKE_PAIR(heap_name_210_204, obj2_1083),
																  BUNSPEC);
															    }
															 }
														      }
														   }
														   {
														      {
															 obj_t done1034_1944;
															 obj_t runner1024_1943;
															 runner1024_1943 = the_remaining_args_132_201;
															 done1034_1944 = action_202;
															 done1034_113 = done1034_1944;
															 runner1024_112 = runner1024_1943;
															 goto loop1033_114;
														      }
														   }
														}
													     }
													  }
												       }
												     else
												       {
													  bool_t test1273_207;
													  test1273_207 = bigloo_strcmp(arg1025_118, string1737_init_parse_args_215);
													  if (test1273_207)
													    {
													       {
														  obj_t action_211;
														  {
														     long aux_1947;
														     {
															char *aux_1948;
															{
															   obj_t aux_1949;
															   {
															      obj_t aux_1950;
															      aux_1950 = CDR(runner1024_112);
															      aux_1949 = CAR(aux_1950);
															   }
															   aux_1948 = BSTRING_TO_STRING(aux_1949);
															}
															aux_1947 = string__integer_39___r4_numbers_6_5_fixnum(aux_1948, BNIL);
														     }
														     action_211 = (_user_heap_size__225_engine_param = BINT(aux_1947),
															BUNSPEC);
														  }
														  {
														     {
															obj_t done1034_1960;
															obj_t runner1024_1956;
															{
															   obj_t aux_1957;
															   aux_1957 = CDR(runner1024_112);
															   runner1024_1956 = CDR(aux_1957);
															}
															done1034_1960 = action_211;
															done1034_113 = done1034_1960;
															runner1024_112 = runner1024_1956;
															goto loop1033_114;
														     }
														  }
													       }
													    }
													  else
													    {
													       bool_t test1279_215;
													       test1279_215 = bigloo_strcmp(arg1025_118, string1738_init_parse_args_215);
													       if (test1279_215)
														 {
														    {
														       obj_t the_remaining_args_132_217;
														       the_remaining_args_132_217 = CDR(runner1024_112);
														       {
															  obj_t action_218;
															  action_218 = (the_remaining_args_132_217 = append_2_18___r4_pairs_and_lists_6_3(CNST_TABLE_REF(((long) 5)), the_remaining_args_132_217),
															     BUNSPEC);
															  {
															     {
																obj_t done1034_1967;
																obj_t runner1024_1966;
																runner1024_1966 = the_remaining_args_132_217;
																done1034_1967 = action_218;
																done1034_113 = done1034_1967;
																runner1024_112 = runner1024_1966;
																goto loop1033_114;
															     }
															  }
														       }
														    }
														 }
													       else
														 {
														    bool_t test1282_220;
														    {
														       bool_t test_1968;
														       {
															  long aux_1969;
															  aux_1969 = STRING_LENGTH(arg1025_118);
															  test_1968 = (aux_1969 >= ((long) 2));
														       }
														       if (test_1968)
															 {
															    obj_t arg1504_743;
															    arg1504_743 = c_substring(arg1025_118, ((long) 0), ((long) 2));
															    test1282_220 = bigloo_strcmp(arg1504_743, string1739_init_parse_args_215);
															 }
														       else
															 {
															    test1282_220 = ((bool_t) 0);
															 }
														    }
														    if (test1282_220)
														      {
															 {
															    obj_t opt_221;
															    {
															       long aux_1975;
															       aux_1975 = STRING_LENGTH(arg1025_118);
															       opt_221 = c_substring(arg1025_118, ((long) 2), aux_1975);
															    }
															    {
															       obj_t the_remaining_args_132_223;
															       the_remaining_args_132_223 = CDR(runner1024_112);
															       {
																  obj_t action_224;
																  action_224 = parse_optim_args_175_init_parse_args_215(opt_221);
																  {
																     {
																	obj_t done1034_1981;
																	obj_t runner1024_1980;
																	runner1024_1980 = the_remaining_args_132_223;
																	done1034_1981 = action_224;
																	done1034_113 = done1034_1981;
																	runner1024_112 = runner1024_1980;
																	goto loop1033_114;
																     }
																  }
															       }
															    }
															 }
														      }
														    else
														      {
															 bool_t test1285_227;
															 test1285_227 = bigloo_strcmp(arg1025_118, string1740_init_parse_args_215);
															 if (test1285_227)
															   {
															      {
																 obj_t action_230;
																 action_230 = (_optim_stack___57_engine_param = BTRUE,
																    BUNSPEC);
																 {
																    {
																       obj_t done1034_1986;
																       obj_t runner1024_1984;
																       runner1024_1984 = CDR(runner1024_112);
																       done1034_1986 = action_230;
																       done1034_113 = done1034_1986;
																       runner1024_112 = runner1024_1984;
																       goto loop1033_114;
																    }
																 }
															      }
															   }
															 else
															   {
															      bool_t test1286_231;
															      test1286_231 = bigloo_strcmp(arg1025_118, string1741_init_parse_args_215);
															      if (test1286_231)
																{
																   {
																      obj_t action_234;
																      action_234 = (_optim_stack___57_engine_param = BFALSE,
																	 BUNSPEC);
																      {
																	 {
																	    obj_t done1034_1991;
																	    obj_t runner1024_1989;
																	    runner1024_1989 = CDR(runner1024_112);
																	    done1034_1991 = action_234;
																	    done1034_113 = done1034_1991;
																	    runner1024_112 = runner1024_1989;
																	    goto loop1033_114;
																	 }
																      }
																   }
																}
															      else
																{
																   bool_t test1287_235;
																   test1287_235 = bigloo_strcmp(arg1025_118, string1742_init_parse_args_215);
																   if (test1287_235)
																     {
																	{
																	   obj_t action_238;
																	   action_238 = (_optim_inline_method___30_engine_param = BTRUE,
																	      BUNSPEC);
																	   {
																	      {
																		 obj_t done1034_1996;
																		 obj_t runner1024_1994;
																		 runner1024_1994 = CDR(runner1024_112);
																		 done1034_1996 = action_238;
																		 done1034_113 = done1034_1996;
																		 runner1024_112 = runner1024_1994;
																		 goto loop1033_114;
																	      }
																	   }
																	}
																     }
																   else
																     {
																	bool_t test1288_239;
																	test1288_239 = bigloo_strcmp(arg1025_118, string1743_init_parse_args_215);
																	if (test1288_239)
																	  {
																	     {
																		obj_t action_242;
																		action_242 = (_optim_inline_method___30_engine_param = BFALSE,
																		   BUNSPEC);
																		{
																		   {
																		      obj_t done1034_2001;
																		      obj_t runner1024_1999;
																		      runner1024_1999 = CDR(runner1024_112);
																		      done1034_2001 = action_242;
																		      done1034_113 = done1034_2001;
																		      runner1024_112 = runner1024_1999;
																		      goto loop1033_114;
																		   }
																		}
																	     }
																	  }
																	else
																	  {
																	     bool_t test1289_243;
																	     test1289_243 = bigloo_strcmp(arg1025_118, string1744_init_parse_args_215);
																	     if (test1289_243)
																	       {
																		  {
																		     obj_t action_246;
																		     action_246 = (_optim_unroll_loop___80_engine_param = BTRUE,
																			BUNSPEC);
																		     {
																			{
																			   obj_t done1034_2006;
																			   obj_t runner1024_2004;
																			   runner1024_2004 = CDR(runner1024_112);
																			   done1034_2006 = action_246;
																			   done1034_113 = done1034_2006;
																			   runner1024_112 = runner1024_2004;
																			   goto loop1033_114;
																			}
																		     }
																		  }
																	       }
																	     else
																	       {
																		  bool_t test1290_247;
																		  test1290_247 = bigloo_strcmp(arg1025_118, string1745_init_parse_args_215);
																		  if (test1290_247)
																		    {
																		       {
																			  obj_t action_250;
																			  action_250 = (_optim_unroll_loop___80_engine_param = BFALSE,
																			     BUNSPEC);
																			  {
																			     {
																				obj_t done1034_2011;
																				obj_t runner1024_2009;
																				runner1024_2009 = CDR(runner1024_112);
																				done1034_2011 = action_250;
																				done1034_113 = done1034_2011;
																				runner1024_112 = runner1024_2009;
																				goto loop1033_114;
																			     }
																			  }
																		       }
																		    }
																		  else
																		    {
																		       bool_t test1291_251;
																		       test1291_251 = bigloo_strcmp(arg1025_118, string1746_init_parse_args_215);
																		       if (test1291_251)
																			 {
																			    {
																			       obj_t action_254;
																			       action_254 = (_optim_loop_inlining___30_engine_param = BFALSE,
																				  BUNSPEC);
																			       {
																				  {
																				     obj_t done1034_2016;
																				     obj_t runner1024_2014;
																				     runner1024_2014 = CDR(runner1024_112);
																				     done1034_2016 = action_254;
																				     done1034_113 = done1034_2016;
																				     runner1024_112 = runner1024_2014;
																				     goto loop1033_114;
																				  }
																			       }
																			    }
																			 }
																		       else
																			 {
																			    bool_t test1292_255;
																			    test1292_255 = bigloo_strcmp(arg1025_118, string1747_init_parse_args_215);
																			    if (test1292_255)
																			      {
																				 {
																				    obj_t action_258;
																				    action_258 = (_optim_loop_inlining___30_engine_param = BTRUE,
																				       BUNSPEC);
																				    {
																				       {
																					  obj_t done1034_2021;
																					  obj_t runner1024_2019;
																					  runner1024_2019 = CDR(runner1024_112);
																					  done1034_2021 = action_258;
																					  done1034_113 = done1034_2021;
																					  runner1024_112 = runner1024_2019;
																					  goto loop1033_114;
																				       }
																				    }
																				 }
																			      }
																			    else
																			      {
																				 bool_t test1293_259;
																				 test1293_259 = bigloo_strcmp(arg1025_118, string1748_init_parse_args_215);
																				 if (test1293_259)
																				   {
																				      {
																					 obj_t action_262;
																					 action_262 = (_inlining___224_engine_param = BFALSE,
																					    BUNSPEC);
																					 {
																					    {
																					       obj_t done1034_2026;
																					       obj_t runner1024_2024;
																					       runner1024_2024 = CDR(runner1024_112);
																					       done1034_2026 = action_262;
																					       done1034_113 = done1034_2026;
																					       runner1024_112 = runner1024_2024;
																					       goto loop1033_114;
																					    }
																					 }
																				      }
																				   }
																				 else
																				   {
																				      bool_t test1294_263;
																				      test1294_263 = bigloo_strcmp(arg1025_118, string1749_init_parse_args_215);
																				      if (test1294_263)
																					{
																					   {
																					      obj_t action_266;
																					      action_266 = (_optim_o_macro___96_engine_param = BTRUE,
																						 BUNSPEC);
																					      {
																						 {
																						    obj_t done1034_2031;
																						    obj_t runner1024_2029;
																						    runner1024_2029 = CDR(runner1024_112);
																						    done1034_2031 = action_266;
																						    done1034_113 = done1034_2031;
																						    runner1024_112 = runner1024_2029;
																						    goto loop1033_114;
																						 }
																					      }
																					   }
																					}
																				      else
																					{
																					   bool_t test1295_267;
																					   test1295_267 = bigloo_strcmp(arg1025_118, string1750_init_parse_args_215);
																					   if (test1295_267)
																					     {
																						{
																						   obj_t action_270;
																						   action_270 = (_optim_o_macro___96_engine_param = BFALSE,
																						      BUNSPEC);
																						   {
																						      {
																							 obj_t done1034_2036;
																							 obj_t runner1024_2034;
																							 runner1024_2034 = CDR(runner1024_112);
																							 done1034_2036 = action_270;
																							 done1034_113 = done1034_2036;
																							 runner1024_112 = runner1024_2034;
																							 goto loop1033_114;
																						      }
																						   }
																						}
																					     }
																					   else
																					     {
																						bool_t test1296_271;
																						test1296_271 = bigloo_strcmp(arg1025_118, string1751_init_parse_args_215);
																						if (test1296_271)
																						  {
																						     {
																							obj_t action_274;
																							action_274 = (_rm_c_files__192_engine_param = BFALSE,
																							   BUNSPEC);
																							{
																							   {
																							      obj_t done1034_2041;
																							      obj_t runner1024_2039;
																							      runner1024_2039 = CDR(runner1024_112);
																							      done1034_2041 = action_274;
																							      done1034_113 = done1034_2041;
																							      runner1024_112 = runner1024_2039;
																							      goto loop1033_114;
																							   }
																							}
																						     }
																						  }
																						else
																						  {
																						     bool_t test1297_275;
																						     test1297_275 = bigloo_strcmp(arg1025_118, string1752_init_parse_args_215);
																						     if (test1297_275)
																						       {
																							  {
																							     obj_t action_278;
																							     action_278 = (_rm_c_files__192_engine_param = BTRUE,
																								BUNSPEC);
																							     {
																								{
																								   obj_t done1034_2046;
																								   obj_t runner1024_2044;
																								   runner1024_2044 = CDR(runner1024_112);
																								   done1034_2046 = action_278;
																								   done1034_113 = done1034_2046;
																								   runner1024_112 = runner1024_2044;
																								   goto loop1033_114;
																								}
																							     }
																							  }
																						       }
																						     else
																						       {
																							  bool_t test1298_279;
																							  test1298_279 = bigloo_strcmp(arg1025_118, string1713_init_parse_args_215);
																							  if (test1298_279)
																							    {
																							       {
																								  obj_t the_remaining_args_132_282;
																								  {
																								     obj_t aux_2049;
																								     aux_2049 = CDR(runner1024_112);
																								     the_remaining_args_132_282 = CDR(aux_2049);
																								  }
																								  {
																								     obj_t action_283;
																								     _extended_done___215_init_parse_args_215 = ((bool_t) 1);
																								     {
																									obj_t aux_2052;
																									{
																									   obj_t aux_2053;
																									   aux_2053 = CDR(runner1024_112);
																									   aux_2052 = CAR(aux_2053);
																									}
																									load_extend_232_init_extend(aux_2052);
																								     }
																								     {
																									bool_t test1299_284;
																									{
																									   obj_t obj_1151;
																									   obj_1151 = _extend_entry__7_engine_param;
																									   test1299_284 = PROCEDUREP(obj_1151);
																									}
																									if (test1299_284)
																									  {
																									     action_283 = (the_remaining_args_132_282 = PROCEDURE_ENTRY(_extend_entry__7_engine_param) (_extend_entry__7_engine_param, the_remaining_args_132_282, BEOA),
																										BUNSPEC);
																									  }
																									else
																									  {
																									     action_283 = BUNSPEC;
																									  }
																								     }
																								     {
																									{
																									   obj_t done1034_2062;
																									   obj_t runner1024_2061;
																									   runner1024_2061 = the_remaining_args_132_282;
																									   done1034_2062 = action_283;
																									   done1034_113 = done1034_2062;
																									   runner1024_112 = runner1024_2061;
																									   goto loop1033_114;
																									}
																								     }
																								  }
																							       }
																							    }
																							  else
																							    {
																							       bool_t test1302_287;
																							       test1302_287 = bigloo_strcmp(arg1025_118, string1753_init_parse_args_215);
																							       if (test1302_287)
																								 {
																								    {
																								       obj_t action_290;
																								       action_290 = (_shared_cnst___67_engine_param = BTRUE,
																									  BUNSPEC);
																								       {
																									  {
																									     obj_t done1034_2067;
																									     obj_t runner1024_2065;
																									     runner1024_2065 = CDR(runner1024_112);
																									     done1034_2067 = action_290;
																									     done1034_113 = done1034_2067;
																									     runner1024_112 = runner1024_2065;
																									     goto loop1033_114;
																									  }
																								       }
																								    }
																								 }
																							       else
																								 {
																								    bool_t test1303_291;
																								    test1303_291 = bigloo_strcmp(arg1025_118, string1754_init_parse_args_215);
																								    if (test1303_291)
																								      {
																									 {
																									    obj_t action_294;
																									    action_294 = (_shared_cnst___67_engine_param = BFALSE,
																									       BUNSPEC);
																									    {
																									       {
																										  obj_t done1034_2072;
																										  obj_t runner1024_2070;
																										  runner1024_2070 = CDR(runner1024_112);
																										  done1034_2072 = action_294;
																										  done1034_113 = done1034_2072;
																										  runner1024_112 = runner1024_2070;
																										  goto loop1033_114;
																									       }
																									    }
																									 }
																								      }
																								    else
																								      {
																									 bool_t test1304_295;
																									 test1304_295 = bigloo_strcmp(arg1025_118, string1755_init_parse_args_215);
																									 if (test1304_295)
																									   {
																									      {
																										 obj_t action_298;
																										 action_298 = (_module_checksum_object___74_engine_param = BTRUE,
																										    BUNSPEC);
																										 {
																										    {
																										       obj_t done1034_2077;
																										       obj_t runner1024_2075;
																										       runner1024_2075 = CDR(runner1024_112);
																										       done1034_2077 = action_298;
																										       done1034_113 = done1034_2077;
																										       runner1024_112 = runner1024_2075;
																										       goto loop1033_114;
																										    }
																										 }
																									      }
																									   }
																									 else
																									   {
																									      bool_t test1305_299;
																									      {
																										 bool_t test_2078;
																										 {
																										    long aux_2079;
																										    aux_2079 = STRING_LENGTH(arg1025_118);
																										    test_2078 = (aux_2079 >= ((long) 7));
																										 }
																										 if (test_2078)
																										   {
																										      obj_t arg1499_738;
																										      arg1499_738 = c_substring(arg1025_118, ((long) 0), ((long) 7));
																										      test1305_299 = bigloo_strcmp(arg1499_738, string1756_init_parse_args_215);
																										   }
																										 else
																										   {
																										      test1305_299 = ((bool_t) 0);
																										   }
																									      }
																									      if (test1305_299)
																										{
																										   {
																										      obj_t opt_300;
																										      {
																											 long aux_2085;
																											 aux_2085 = STRING_LENGTH(arg1025_118);
																											 opt_300 = c_substring(arg1025_118, ((long) 7), aux_2085);
																										      }
																										      {
																											 obj_t the_remaining_args_132_302;
																											 the_remaining_args_132_302 = CDR(runner1024_112);
																											 {
																											    obj_t action_303;
																											    action_303 = parse_unsafe_args_57_init_parse_args_215(opt_300);
																											    {
																											       {
																												  obj_t done1034_2091;
																												  obj_t runner1024_2090;
																												  runner1024_2090 = the_remaining_args_132_302;
																												  done1034_2091 = action_303;
																												  done1034_113 = done1034_2091;
																												  runner1024_112 = runner1024_2090;
																												  goto loop1033_114;
																											       }
																											    }
																											 }
																										      }
																										   }
																										}
																									      else
																										{
																										   bool_t test1309_306;
																										   test1309_306 = bigloo_strcmp(arg1025_118, string1757_init_parse_args_215);
																										   if (test1309_306)
																										     {
																											{
																											   obj_t action_309;
																											   action_309 = (_compiler_debug__134_engine_param = BINT(((long) 1)),
																											      BUNSPEC);
																											   {
																											      {
																												 obj_t done1034_2097;
																												 obj_t runner1024_2095;
																												 runner1024_2095 = CDR(runner1024_112);
																												 done1034_2097 = action_309;
																												 done1034_113 = done1034_2097;
																												 runner1024_112 = runner1024_2095;
																												 goto loop1033_114;
																											      }
																											   }
																											}
																										     }
																										   else
																										     {
																											bool_t test1310_310;
																											test1310_310 = bigloo_strcmp(arg1025_118, string1758_init_parse_args_215);
																											if (test1310_310)
																											  {
																											     {
																												obj_t action_313;
																												action_313 = (_compiler_debug__134_engine_param = BINT(((long) 2)),
																												   BUNSPEC);
																												{
																												   {
																												      obj_t done1034_2103;
																												      obj_t runner1024_2101;
																												      runner1024_2101 = CDR(runner1024_112);
																												      done1034_2103 = action_313;
																												      done1034_113 = done1034_2103;
																												      runner1024_112 = runner1024_2101;
																												      goto loop1033_114;
																												   }
																												}
																											     }
																											  }
																											else
																											  {
																											     bool_t test1311_314;
																											     test1311_314 = bigloo_strcmp(arg1025_118, string1759_init_parse_args_215);
																											     if (test1311_314)
																											       {
																												  {
																												     obj_t the_remaining_args_132_316;
																												     the_remaining_args_132_316 = CDR(runner1024_112);
																												     {
																													obj_t action_317;
																													if (CBOOL(_call_cc___102_engine_param))
																													  {
																													     action_317 = BUNSPEC;
																													  }
																													else
																													  {
																													     action_317 = (_compiler_debug__134_engine_param = BINT(((long) 3)),
																														BUNSPEC);
																													  }
																													{
																													   {
																													      obj_t done1034_2111;
																													      obj_t runner1024_2110;
																													      runner1024_2110 = the_remaining_args_132_316;
																													      done1034_2111 = action_317;
																													      done1034_113 = done1034_2111;
																													      runner1024_112 = runner1024_2110;
																													      goto loop1033_114;
																													   }
																													}
																												     }
																												  }
																											       }
																											     else
																											       {
																												  bool_t test1312_318;
																												  test1312_318 = bigloo_strcmp(arg1025_118, string1760_init_parse_args_215);
																												  if (test1312_318)
																												    {
																												       {
																													  obj_t action_321;
																													  action_321 = (_compiler_debug__134_engine_param = BINT(((long) 4)),
																													     BUNSPEC);
																													  {
																													     {
																														obj_t done1034_2117;
																														obj_t runner1024_2115;
																														runner1024_2115 = CDR(runner1024_112);
																														done1034_2117 = action_321;
																														done1034_113 = done1034_2117;
																														runner1024_112 = runner1024_2115;
																														goto loop1033_114;
																													     }
																													  }
																												       }
																												    }
																												  else
																												    {
																												       bool_t test1313_322;
																												       test1313_322 = bigloo_strcmp(arg1025_118, string1761_init_parse_args_215);
																												       if (test1313_322)
																													 {
																													    {
																													       obj_t action_325;
																													       _rm_c_files__192_engine_param = BFALSE;
																													       _c_debug__136_engine_param = BTRUE;
																													       action_325 = (_strip__173_engine_param = BFALSE,
																														  BUNSPEC);
																													       {
																														  {
																														     obj_t done1034_2122;
																														     obj_t runner1024_2120;
																														     runner1024_2120 = CDR(runner1024_112);
																														     done1034_2122 = action_325;
																														     done1034_113 = done1034_2122;
																														     runner1024_112 = runner1024_2120;
																														     goto loop1033_114;
																														  }
																													       }
																													    }
																													 }
																												       else
																													 {
																													    bool_t test1314_326;
																													    test1314_326 = bigloo_strcmp(arg1025_118, string1762_init_parse_args_215);
																													    if (test1314_326)
																													      {
																														 {
																														    obj_t the_remaining_args_132_328;
																														    the_remaining_args_132_328 = CDR(runner1024_112);
																														    {
																														       obj_t action_329;
																														       {
																															  obj_t obj2_1193;
																															  obj2_1193 = _additional_heap_names__104_engine_param;
																															  _additional_heap_names__104_engine_param = MAKE_PAIR(string1763_init_parse_args_215, obj2_1193);
																														       }
																														       _user_heap_size__225_engine_param = BINT(((long) 1));
																														       action_329 = (_bdb_debug__1_engine_param = BINT(((long) 1)),
																															  BUNSPEC);
																														       {
																															  {
																															     obj_t done1034_2130;
																															     obj_t runner1024_2129;
																															     runner1024_2129 = the_remaining_args_132_328;
																															     done1034_2130 = action_329;
																															     done1034_113 = done1034_2130;
																															     runner1024_112 = runner1024_2129;
																															     goto loop1033_114;
																															  }
																														       }
																														    }
																														 }
																													      }
																													    else
																													      {
																														 bool_t test1315_330;
																														 test1315_330 = bigloo_strcmp(arg1025_118, string1764_init_parse_args_215);
																														 if (test1315_330)
																														   {
																														      {
																															 obj_t the_remaining_args_132_332;
																															 the_remaining_args_132_332 = CDR(runner1024_112);
																															 {
																															    obj_t action_333;
																															    {
																															       obj_t obj2_1198;
																															       obj2_1198 = _additional_heap_names__104_engine_param;
																															       _additional_heap_names__104_engine_param = MAKE_PAIR(string1763_init_parse_args_215, obj2_1198);
																															    }
																															    _user_heap_size__225_engine_param = BINT(((long) 1));
																															    action_333 = (_bdb_debug__1_engine_param = BINT(((long) 2)),
																															       BUNSPEC);
																															    {
																															       {
																																  obj_t done1034_2138;
																																  obj_t runner1024_2137;
																																  runner1024_2137 = the_remaining_args_132_332;
																																  done1034_2138 = action_333;
																																  done1034_113 = done1034_2138;
																																  runner1024_112 = runner1024_2137;
																																  goto loop1033_114;
																															       }
																															    }
																															 }
																														      }
																														   }
																														 else
																														   {
																														      bool_t test1316_334;
																														      test1316_334 = bigloo_strcmp(arg1025_118, string1765_init_parse_args_215);
																														      if (test1316_334)
																															{
																															   {
																															      obj_t the_remaining_args_132_336;
																															      the_remaining_args_132_336 = CDR(runner1024_112);
																															      {
																																 obj_t action_337;
																																 _strip__173_engine_param = BFALSE;
																																 _cc_options__252_engine_param = string_append(_cc_options__252_engine_param, string1766_init_parse_args_215);
																																 action_337 = (_profile_mode__105_engine_param = BINT(((long) 1)),
																																    BUNSPEC);
																																 {
																																    {
																																       obj_t done1034_2145;
																																       obj_t runner1024_2144;
																																       runner1024_2144 = the_remaining_args_132_336;
																																       done1034_2145 = action_337;
																																       done1034_113 = done1034_2145;
																																       runner1024_112 = runner1024_2144;
																																       goto loop1033_114;
																																    }
																																 }
																															      }
																															   }
																															}
																														      else
																															{
																															   bool_t test1317_338;
																															   test1317_338 = bigloo_strcmp(arg1025_118, string1767_init_parse_args_215);
																															   if (test1317_338)
																															     {
																																{
																																   obj_t the_remaining_args_132_340;
																																   the_remaining_args_132_340 = CDR(runner1024_112);
																																   {
																																      obj_t action_341;
																																      _strip__173_engine_param = BFALSE;
																																      _profile_library__193_engine_param = BTRUE;
																																      _cc_options__252_engine_param = string_append(_cc_options__252_engine_param, string1766_init_parse_args_215);
																																      _profile_mode__105_engine_param = BINT(((long) 1));
																																      {
																																	 obj_t obj2_1206;
																																	 obj2_1206 = the_remaining_args_132_340;
																																	 action_341 = (the_remaining_args_132_340 = MAKE_PAIR(string1768_init_parse_args_215, obj2_1206),
																																	    BUNSPEC);
																																      }
																																      {
																																	 {
																																	    obj_t done1034_2153;
																																	    obj_t runner1024_2152;
																																	    runner1024_2152 = the_remaining_args_132_340;
																																	    done1034_2153 = action_341;
																																	    done1034_113 = done1034_2153;
																																	    runner1024_112 = runner1024_2152;
																																	    goto loop1033_114;
																																	 }
																																      }
																																   }
																																}
																															     }
																															   else
																															     {
																																bool_t test1318_342;
																																test1318_342 = bigloo_strcmp(arg1025_118, string1769_init_parse_args_215);
																																if (test1318_342)
																																  {
																																     {
																																	obj_t the_remaining_args_132_344;
																																	the_remaining_args_132_344 = CDR(runner1024_112);
																																	{
																																	   obj_t action_345;
																																	   _strip__173_engine_param = BFALSE;
																																	   _profile_library__193_engine_param = BTRUE;
																																	   action_345 = (_cc_options__252_engine_param = string_append(_cc_options__252_engine_param, string1766_init_parse_args_215),
																																	      BUNSPEC);
																																	   {
																																	      {
																																		 obj_t done1034_2159;
																																		 obj_t runner1024_2158;
																																		 runner1024_2158 = the_remaining_args_132_344;
																																		 done1034_2159 = action_345;
																																		 done1034_113 = done1034_2159;
																																		 runner1024_112 = runner1024_2158;
																																		 goto loop1033_114;
																																	      }
																																	   }
																																	}
																																     }
																																  }
																																else
																																  {
																																     bool_t test1319_346;
																																     test1319_346 = bigloo_strcmp(arg1025_118, string1770_init_parse_args_215);
																																     if (test1319_346)
																																       {
																																	  {
																																	     obj_t the_remaining_args_132_348;
																																	     the_remaining_args_132_348 = CDR(runner1024_112);
																																	     {
																																		obj_t action_349;
																																		short_version_52_write_version();
																																		action_349 = exit_bigloo_229_init_main(BINT(((long) 0)));
																																		{
																																		   {
																																		      obj_t done1034_2167;
																																		      obj_t runner1024_2166;
																																		      runner1024_2166 = the_remaining_args_132_348;
																																		      done1034_2167 = action_349;
																																		      done1034_113 = done1034_2167;
																																		      runner1024_112 = runner1024_2166;
																																		      goto loop1033_114;
																																		   }
																																		}
																																	     }
																																	  }
																																       }
																																     else
																																       {
																																	  bool_t test1320_350;
																																	  test1320_350 = bigloo_strcmp(arg1025_118, string1771_init_parse_args_215);
																																	  if (test1320_350)
																																	    {
																																	       {
																																		  obj_t the_remaining_args_132_352;
																																		  the_remaining_args_132_352 = CDR(runner1024_112);
																																		  {
																																		     obj_t action_353;
																																		     revision_write_version();
																																		     action_353 = exit_bigloo_229_init_main(BINT(((long) 0)));
																																		     {
																																			{
																																			   obj_t done1034_2175;
																																			   obj_t runner1024_2174;
																																			   runner1024_2174 = the_remaining_args_132_352;
																																			   done1034_2175 = action_353;
																																			   done1034_113 = done1034_2175;
																																			   runner1024_112 = runner1024_2174;
																																			   goto loop1033_114;
																																			}
																																		     }
																																		  }
																																	       }
																																	    }
																																	  else
																																	    {
																																	       bool_t test1321_354;
																																	       test1321_354 = bigloo_strcmp(arg1025_118, string1772_init_parse_args_215);
																																	       if (test1321_354)
																																		 {
																																		    {
																																		       obj_t the_remaining_args_132_356;
																																		       the_remaining_args_132_356 = CDR(runner1024_112);
																																		       {
																																			  obj_t action_357;
																																			  action_357 = query_init_parse_args_215();
																																			  {
																																			     {
																																				obj_t done1034_2181;
																																				obj_t runner1024_2180;
																																				runner1024_2180 = the_remaining_args_132_356;
																																				done1034_2181 = action_357;
																																				done1034_113 = done1034_2181;
																																				runner1024_112 = runner1024_2180;
																																				goto loop1033_114;
																																			     }
																																			  }
																																		       }
																																		    }
																																		 }
																																	       else
																																		 {
																																		    bool_t test1322_358;
																																		    test1322_358 = bigloo_strcmp(arg1025_118, string1773_init_parse_args_215);
																																		    if (test1322_358)
																																		      {
																																			 {
																																			    {
																																			       obj_t done1034_2186;
																																			       obj_t runner1024_2184;
																																			       runner1024_2184 = CDR(runner1024_112);
																																			       done1034_2186 = CNST_TABLE_REF(((long) 6));
																																			       done1034_113 = done1034_2186;
																																			       runner1024_112 = runner1024_2184;
																																			       goto loop1033_114;
																																			    }
																																			 }
																																		      }
																																		    else
																																		      {
																																			 bool_t test1323_362;
																																			 test1323_362 = bigloo_strcmp(arg1025_118, string1774_init_parse_args_215);
																																			 if (test1323_362)
																																			   {
																																			      {
																																				 obj_t the_remaining_args_132_365;
																																				 {
																																				    obj_t aux_2190;
																																				    aux_2190 = CDR(runner1024_112);
																																				    the_remaining_args_132_365 = CDR(aux_2190);
																																				 }
																																				 {
																																				    obj_t action_366;
																																				    {
																																				       obj_t port_367;
																																				       {
																																					  obj_t aux_2193;
																																					  {
																																					     obj_t aux_2194;
																																					     aux_2194 = CDR(runner1024_112);
																																					     aux_2193 = CAR(aux_2194);
																																					  }
																																					  port_367 = open_input_string(aux_2193);
																																				       }
																																				       {
																																					  obj_t exp_368;
																																					  {
																																					     obj_t arg1324_370;
																																					     {
																																						obj_t list1325_371;
																																						list1325_371 = MAKE_PAIR(port_367, BNIL);
																																						arg1324_370 = read___reader(list1325_371);
																																					     }
																																					     exp_368 = arg1324_370;
																																					   laap_369:
																																					     {
																																						bool_t test1327_373;
																																						test1327_373 = EOF_OBJECTP(exp_368);
																																						if (test1327_373)
																																						  {
																																						     action_366 = CNST_TABLE_REF(((long) 7));
																																						  }
																																						else
																																						  {
																																						     eval___eval(exp_368, BNIL);
																																						     {
																																							obj_t arg1330_375;
																																							{
																																							   obj_t list1331_376;
																																							   list1331_376 = MAKE_PAIR(port_367, BNIL);
																																							   arg1330_375 = read___reader(list1331_376);
																																							}
																																							{
																																							   obj_t exp_2206;
																																							   exp_2206 = arg1330_375;
																																							   exp_368 = exp_2206;
																																							   goto laap_369;
																																							}
																																						     }
																																						  }
																																					     }
																																					  }
																																				       }
																																				    }
																																				    {
																																				       {
																																					  obj_t done1034_2208;
																																					  obj_t runner1024_2207;
																																					  runner1024_2207 = the_remaining_args_132_365;
																																					  done1034_2208 = action_366;
																																					  done1034_113 = done1034_2208;
																																					  runner1024_112 = runner1024_2207;
																																					  goto loop1033_114;
																																				       }
																																				    }
																																				 }
																																			      }
																																			   }
																																			 else
																																			   {
																																			      bool_t test1335_380;
																																			      test1335_380 = bigloo_strcmp(arg1025_118, string1775_init_parse_args_215);
																																			      if (test1335_380)
																																				{
																																				   {
																																				      obj_t the_remaining_args_132_383;
																																				      {
																																					 obj_t aux_2211;
																																					 aux_2211 = CDR(runner1024_112);
																																					 the_remaining_args_132_383 = CDR(aux_2211);
																																				      }
																																				      {
																																					 obj_t action_384;
																																					 {
																																					    obj_t obj2_1237;
																																					    obj2_1237 = _load_path__54___eval;
																																					    {
																																					       obj_t aux_2214;
																																					       {
																																						  obj_t aux_2215;
																																						  aux_2215 = CDR(runner1024_112);
																																						  aux_2214 = CAR(aux_2215);
																																					       }
																																					       action_384 = (_load_path__54___eval = MAKE_PAIR(aux_2214, obj2_1237),
																																						  BUNSPEC);
																																					    }
																																					 }
																																					 {
																																					    {
																																					       obj_t done1034_2220;
																																					       obj_t runner1024_2219;
																																					       runner1024_2219 = the_remaining_args_132_383;
																																					       done1034_2220 = action_384;
																																					       done1034_113 = done1034_2220;
																																					       runner1024_112 = runner1024_2219;
																																					       goto loop1033_114;
																																					    }
																																					 }
																																				      }
																																				   }
																																				}
																																			      else
																																				{
																																				   bool_t test1340_387;
																																				   test1340_387 = bigloo_strcmp(arg1025_118, string1776_init_parse_args_215);
																																				   if (test1340_387)
																																				     {
																																					{
																																					   obj_t the_remaining_args_132_390;
																																					   {
																																					      obj_t aux_2223;
																																					      aux_2223 = CDR(runner1024_112);
																																					      the_remaining_args_132_390 = CDR(aux_2223);
																																					   }
																																					   {
																																					      obj_t action_391;
																																					      {
																																						 obj_t list1341_392;
																																						 {
																																						    obj_t aux_2226;
																																						    {
																																						       obj_t aux_2227;
																																						       aux_2227 = CDR(runner1024_112);
																																						       aux_2226 = CAR(aux_2227);
																																						    }
																																						    list1341_392 = MAKE_PAIR(aux_2226, BNIL);
																																						 }
																																						 action_391 = (_lib_dir__34_engine_param = list1341_392,
																																						    BUNSPEC);
																																					      }
																																					      {
																																						 {
																																						    obj_t done1034_2232;
																																						    obj_t runner1024_2231;
																																						    runner1024_2231 = the_remaining_args_132_390;
																																						    done1034_2232 = action_391;
																																						    done1034_113 = done1034_2232;
																																						    runner1024_112 = runner1024_2231;
																																						    goto loop1033_114;
																																						 }
																																					      }
																																					   }
																																					}
																																				     }
																																				   else
																																				     {
																																					bool_t test1345_396;
																																					test1345_396 = bigloo_strcmp(arg1025_118, string1777_init_parse_args_215);
																																					if (test1345_396)
																																					  {
																																					     {
																																						obj_t the_remaining_args_132_399;
																																						{
																																						   obj_t aux_2235;
																																						   aux_2235 = CDR(runner1024_112);
																																						   the_remaining_args_132_399 = CDR(aux_2235);
																																						}
																																						{
																																						   obj_t action_400;
																																						   {
																																						      obj_t obj2_1252;
																																						      obj2_1252 = _lib_dir__34_engine_param;
																																						      {
																																							 obj_t aux_2238;
																																							 {
																																							    obj_t aux_2239;
																																							    aux_2239 = CDR(runner1024_112);
																																							    aux_2238 = CAR(aux_2239);
																																							 }
																																							 action_400 = (_lib_dir__34_engine_param = MAKE_PAIR(aux_2238, obj2_1252),
																																							    BUNSPEC);
																																						      }
																																						   }
																																						   {
																																						      {
																																							 obj_t done1034_2244;
																																							 obj_t runner1024_2243;
																																							 runner1024_2243 = the_remaining_args_132_399;
																																							 done1034_2244 = action_400;
																																							 done1034_113 = done1034_2244;
																																							 runner1024_112 = runner1024_2243;
																																							 goto loop1033_114;
																																						      }
																																						   }
																																						}
																																					     }
																																					  }
																																					else
																																					  {
																																					     bool_t test1350_403;
																																					     test1350_403 = bigloo_strcmp(arg1025_118, string1778_init_parse_args_215);
																																					     if (test1350_403)
																																					       {
																																						  {
																																						     obj_t action_406;
																																						     action_406 = (_nil__217___eval = BFALSE,
																																							BUNSPEC);
																																						     {
																																							{
																																							   obj_t done1034_2249;
																																							   obj_t runner1024_2247;
																																							   runner1024_2247 = CDR(runner1024_112);
																																							   done1034_2249 = action_406;
																																							   done1034_113 = done1034_2249;
																																							   runner1024_112 = runner1024_2247;
																																							   goto loop1033_114;
																																							}
																																						     }
																																						  }
																																					       }
																																					     else
																																					       {
																																						  bool_t test1351_407;
																																						  test1351_407 = bigloo_strcmp(arg1025_118, string1779_init_parse_args_215);
																																						  if (test1351_407)
																																						    {
																																						       {
																																							  obj_t the_remaining_args_132_409;
																																							  the_remaining_args_132_409 = CDR(runner1024_112);
																																							  {
																																							     obj_t action_410;
																																							     {
																																								bool_t test1352_411;
																																								{
																																								   long n1_1259;
																																								   n1_1259 = (long) CINT(_compiler_debug__134_engine_param);
																																								   test1352_411 = (n1_1259 > ((long) 2));
																																								}
																																								if (test1352_411)
																																								  {
																																								     _compiler_debug__134_engine_param = BINT(((long) 2));
																																								  }
																																								else
																																								  {
																																								     BUNSPEC;
																																								  }
																																							     }
																																							     action_410 = (_call_cc___102_engine_param = BTRUE,
																																								BUNSPEC);
																																							     {
																																								{
																																								   obj_t done1034_2258;
																																								   obj_t runner1024_2257;
																																								   runner1024_2257 = the_remaining_args_132_409;
																																								   done1034_2258 = action_410;
																																								   done1034_113 = done1034_2258;
																																								   runner1024_112 = runner1024_2257;
																																								   goto loop1033_114;
																																								}
																																							     }
																																							  }
																																						       }
																																						    }
																																						  else
																																						    {
																																						       bool_t test1353_412;
																																						       test1353_412 = bigloo_strcmp(arg1025_118, string1780_init_parse_args_215);
																																						       if (test1353_412)
																																							 {
																																							    {
																																							       obj_t action_415;
																																							       action_415 = (_hygien___100___r5_macro_4_3_init = BTRUE,
																																								  BUNSPEC);
																																							       {
																																								  {
																																								     obj_t done1034_2263;
																																								     obj_t runner1024_2261;
																																								     runner1024_2261 = CDR(runner1024_112);
																																								     done1034_2263 = action_415;
																																								     done1034_113 = done1034_2263;
																																								     runner1024_112 = runner1024_2261;
																																								     goto loop1033_114;
																																								  }
																																							       }
																																							    }
																																							 }
																																						       else
																																							 {
																																							    bool_t test1354_416;
																																							    test1354_416 = bigloo_strcmp(arg1025_118, string1781_init_parse_args_215);
																																							    if (test1354_416)
																																							      {
																																								 {
																																								    obj_t action_419;
																																								    action_419 = (_reflection___104_engine_param = BFALSE,
																																								       BUNSPEC);
																																								    {
																																								       {
																																									  obj_t done1034_2268;
																																									  obj_t runner1024_2266;
																																									  runner1024_2266 = CDR(runner1024_112);
																																									  done1034_2268 = action_419;
																																									  done1034_113 = done1034_2268;
																																									  runner1024_112 = runner1024_2266;
																																									  goto loop1033_114;
																																								       }
																																								    }
																																								 }
																																							      }
																																							    else
																																							      {
																																								 bool_t test1355_420;
																																								 test1355_420 = bigloo_strcmp(arg1025_118, string1782_init_parse_args_215);
																																								 if (test1355_420)
																																								   {
																																								      {
																																									 obj_t action_423;
																																									 action_423 = (_reflection___104_engine_param = BTRUE,
																																									    BUNSPEC);
																																									 {
																																									    {
																																									       obj_t done1034_2273;
																																									       obj_t runner1024_2271;
																																									       runner1024_2271 = CDR(runner1024_112);
																																									       done1034_2273 = action_423;
																																									       done1034_113 = done1034_2273;
																																									       runner1024_112 = runner1024_2271;
																																									       goto loop1033_114;
																																									    }
																																									 }
																																								      }
																																								   }
																																								 else
																																								   {
																																								      bool_t test1356_424;
																																								      test1356_424 = bigloo_strcmp(arg1025_118, string1783_init_parse_args_215);
																																								      if (test1356_424)
																																									{
																																									   {
																																									      obj_t action_427;
																																									      action_427 = (_genericity__47_engine_param = BFALSE,
																																										 BUNSPEC);
																																									      {
																																										 {
																																										    obj_t done1034_2278;
																																										    obj_t runner1024_2276;
																																										    runner1024_2276 = CDR(runner1024_112);
																																										    done1034_2278 = action_427;
																																										    done1034_113 = done1034_2278;
																																										    runner1024_112 = runner1024_2276;
																																										    goto loop1033_114;
																																										 }
																																									      }
																																									   }
																																									}
																																								      else
																																									{
																																									   bool_t test1357_428;
																																									   test1357_428 = bigloo_strcmp(arg1025_118, string1784_init_parse_args_215);
																																									   if (test1357_428)
																																									     {
																																										{
																																										   obj_t action_431;
																																										   action_431 = (_verbose__1_engine_param = BINT(((long) -1)),
																																										      BUNSPEC);
																																										   {
																																										      {
																																											 obj_t done1034_2284;
																																											 obj_t runner1024_2282;
																																											 runner1024_2282 = CDR(runner1024_112);
																																											 done1034_2284 = action_431;
																																											 done1034_113 = done1034_2284;
																																											 runner1024_112 = runner1024_2282;
																																											 goto loop1033_114;
																																										      }
																																										   }
																																										}
																																									     }
																																									   else
																																									     {
																																										bool_t test1358_432;
																																										test1358_432 = bigloo_strcmp(arg1025_118, string1785_init_parse_args_215);
																																										if (test1358_432)
																																										  {
																																										     {
																																											obj_t action_435;
																																											action_435 = (_verbose__1_engine_param = BINT(((long) 1)),
																																											   BUNSPEC);
																																											{
																																											   {
																																											      obj_t done1034_2290;
																																											      obj_t runner1024_2288;
																																											      runner1024_2288 = CDR(runner1024_112);
																																											      done1034_2290 = action_435;
																																											      done1034_113 = done1034_2290;
																																											      runner1024_112 = runner1024_2288;
																																											      goto loop1033_114;
																																											   }
																																											}
																																										     }
																																										  }
																																										else
																																										  {
																																										     bool_t test1359_436;
																																										     test1359_436 = bigloo_strcmp(arg1025_118, string1786_init_parse_args_215);
																																										     if (test1359_436)
																																										       {
																																											  {
																																											     obj_t action_439;
																																											     action_439 = (_verbose__1_engine_param = BINT(((long) 2)),
																																												BUNSPEC);
																																											     {
																																												{
																																												   obj_t done1034_2296;
																																												   obj_t runner1024_2294;
																																												   runner1024_2294 = CDR(runner1024_112);
																																												   done1034_2296 = action_439;
																																												   done1034_113 = done1034_2296;
																																												   runner1024_112 = runner1024_2294;
																																												   goto loop1033_114;
																																												}
																																											     }
																																											  }
																																										       }
																																										     else
																																										       {
																																											  bool_t test1360_440;
																																											  test1360_440 = bigloo_strcmp(arg1025_118, string1787_init_parse_args_215);
																																											  if (test1360_440)
																																											    {
																																											       {
																																												  obj_t action_443;
																																												  action_443 = (_verbose__1_engine_param = BINT(((long) 3)),
																																												     BUNSPEC);
																																												  {
																																												     {
																																													obj_t done1034_2302;
																																													obj_t runner1024_2300;
																																													runner1024_2300 = CDR(runner1024_112);
																																													done1034_2302 = action_443;
																																													done1034_113 = done1034_2302;
																																													runner1024_112 = runner1024_2300;
																																													goto loop1033_114;
																																												     }
																																												  }
																																											       }
																																											    }
																																											  else
																																											    {
																																											       bool_t test1361_444;
																																											       test1361_444 = bigloo_strcmp(arg1025_118, string1788_init_parse_args_215);
																																											       if (test1361_444)
																																												 {
																																												    {
																																												       obj_t action_447;
																																												       action_447 = (_hello__249_engine_param = BFALSE,
																																													  BUNSPEC);
																																												       {
																																													  {
																																													     obj_t done1034_2307;
																																													     obj_t runner1024_2305;
																																													     runner1024_2305 = CDR(runner1024_112);
																																													     done1034_2307 = action_447;
																																													     done1034_113 = done1034_2307;
																																													     runner1024_112 = runner1024_2305;
																																													     goto loop1033_114;
																																													  }
																																												       }
																																												    }
																																												 }
																																											       else
																																												 {
																																												    bool_t test1362_448;
																																												    test1362_448 = bigloo_strcmp(arg1025_118, string1789_init_parse_args_215);
																																												    if (test1362_448)
																																												      {
																																													 {
																																													    obj_t action_451;
																																													    action_451 = (_warning__61___error = BFALSE,
																																													       BUNSPEC);
																																													    {
																																													       {
																																														  obj_t done1034_2312;
																																														  obj_t runner1024_2310;
																																														  runner1024_2310 = CDR(runner1024_112);
																																														  done1034_2312 = action_451;
																																														  done1034_113 = done1034_2312;
																																														  runner1024_112 = runner1024_2310;
																																														  goto loop1033_114;
																																													       }
																																													    }
																																													 }
																																												      }
																																												    else
																																												      {
																																													 bool_t test1363_452;
																																													 test1363_452 = bigloo_strcmp(arg1025_118, string1790_init_parse_args_215);
																																													 if (test1363_452)
																																													   {
																																													      {
																																														 obj_t action_455;
																																														 action_455 = (_warning__61___error = BINT(((long) 2)),
																																														    BUNSPEC);
																																														 {
																																														    {
																																														       obj_t done1034_2318;
																																														       obj_t runner1024_2316;
																																														       runner1024_2316 = CDR(runner1024_112);
																																														       done1034_2318 = action_455;
																																														       done1034_113 = done1034_2318;
																																														       runner1024_112 = runner1024_2316;
																																														       goto loop1033_114;
																																														    }
																																														 }
																																													      }
																																													   }
																																													 else
																																													   {
																																													      bool_t test1364_456;
																																													      test1364_456 = bigloo_strcmp(arg1025_118, string1791_init_parse_args_215);
																																													      if (test1364_456)
																																														{
																																														   {
																																														      obj_t action_460;
																																														      {
																																															 obj_t aux_2321;
																																															 aux_2321 = CDR(runner1024_112);
																																															 action_460 = (_cc__215_engine_param = CAR(aux_2321),
																																															    BUNSPEC);
																																														      }
																																														      {
																																															 {
																																															    obj_t done1034_2328;
																																															    obj_t runner1024_2324;
																																															    {
																																															       obj_t aux_2325;
																																															       aux_2325 = CDR(runner1024_112);
																																															       runner1024_2324 = CDR(aux_2325);
																																															    }
																																															    done1034_2328 = action_460;
																																															    done1034_113 = done1034_2328;
																																															    runner1024_112 = runner1024_2324;
																																															    goto loop1033_114;
																																															 }
																																														      }
																																														   }
																																														}
																																													      else
																																														{
																																														   bool_t test1368_463;
																																														   test1368_463 = bigloo_strcmp(arg1025_118, string1792_init_parse_args_215);
																																														   if (test1368_463)
																																														     {
																																															{
																																															   obj_t action_466;
																																															   action_466 = (_stdc__25_engine_param = BTRUE,
																																															      BUNSPEC);
																																															   {
																																															      {
																																																 obj_t done1034_2333;
																																																 obj_t runner1024_2331;
																																																 runner1024_2331 = CDR(runner1024_112);
																																																 done1034_2333 = action_466;
																																																 done1034_113 = done1034_2333;
																																																 runner1024_112 = runner1024_2331;
																																																 goto loop1033_114;
																																															      }
																																															   }
																																															}
																																														     }
																																														   else
																																														     {
																																															bool_t test1369_467;
																																															test1369_467 = bigloo_strcmp(arg1025_118, string1793_init_parse_args_215);
																																															if (test1369_467)
																																															  {
																																															     {
																																																obj_t the_remaining_args_132_470;
																																																{
																																																   obj_t aux_2336;
																																																   aux_2336 = CDR(runner1024_112);
																																																   the_remaining_args_132_470 = CDR(aux_2336);
																																																}
																																																{
																																																   obj_t action_471;
																																																   {
																																																      obj_t list1370_472;
																																																      {
																																																	 obj_t arg1372_473;
																																																	 {
																																																	    obj_t arg1375_475;
																																																	    {
																																																	       obj_t aux_2339;
																																																	       {
																																																		  obj_t aux_2340;
																																																		  aux_2340 = CDR(runner1024_112);
																																																		  aux_2339 = CAR(aux_2340);
																																																	       }
																																																	       arg1375_475 = MAKE_PAIR(aux_2339, BNIL);
																																																	    }
																																																	    arg1372_473 = MAKE_PAIR(string1794_init_parse_args_215, arg1375_475);
																																																	 }
																																																	 list1370_472 = MAKE_PAIR(_cc_options__252_engine_param, arg1372_473);
																																																      }
																																																      action_471 = (_cc_options__252_engine_param = string_append_106___r4_strings_6_7(list1370_472),
																																																	 BUNSPEC);
																																																   }
																																																   {
																																																      {
																																																	 obj_t done1034_2348;
																																																	 obj_t runner1024_2347;
																																																	 runner1024_2347 = the_remaining_args_132_470;
																																																	 done1034_2348 = action_471;
																																																	 done1034_113 = done1034_2348;
																																																	 runner1024_112 = runner1024_2347;
																																																	 goto loop1033_114;
																																																      }
																																																   }
																																																}
																																															     }
																																															  }
																																															else
																																															  {
																																															     bool_t test1382_479;
																																															     test1382_479 = bigloo_strcmp(arg1025_118, string1795_init_parse_args_215);
																																															     if (test1382_479)
																																															       {
																																																  {
																																																     obj_t string_480;
																																																     {
																																																	obj_t aux_2351;
																																																	aux_2351 = CDR(runner1024_112);
																																																	string_480 = CAR(aux_2351);
																																																     }
																																																     {
																																																	obj_t the_remaining_args_132_482;
																																																	{
																																																	   obj_t aux_2354;
																																																	   aux_2354 = CDR(runner1024_112);
																																																	   the_remaining_args_132_482 = CDR(aux_2354);
																																																	}
																																																	{
																																																	   obj_t action_483;
																																																	   {
																																																	      obj_t list1383_484;
																																																	      {
																																																		 obj_t arg1384_485;
																																																		 {
																																																		    obj_t arg1387_487;
																																																		    arg1387_487 = MAKE_PAIR(_ld_options__88_engine_param, BNIL);
																																																		    arg1384_485 = MAKE_PAIR(string1794_init_parse_args_215, arg1387_487);
																																																		 }
																																																		 list1383_484 = MAKE_PAIR(string_480, arg1384_485);
																																																	      }
																																																	      action_483 = (_ld_options__88_engine_param = string_append_106___r4_strings_6_7(list1383_484),
																																																		 BUNSPEC);
																																																	   }
																																																	   {
																																																	      {
																																																		 obj_t done1034_2362;
																																																		 obj_t runner1024_2361;
																																																		 runner1024_2361 = the_remaining_args_132_482;
																																																		 done1034_2362 = action_483;
																																																		 done1034_113 = done1034_2362;
																																																		 runner1024_112 = runner1024_2361;
																																																		 goto loop1033_114;
																																																	      }
																																																	   }
																																																	}
																																																     }
																																																  }
																																															       }
																																															     else
																																															       {
																																																  bool_t test1391_491;
																																																  test1391_491 = bigloo_strcmp(arg1025_118, string1768_init_parse_args_215);
																																																  if (test1391_491)
																																																    {
																																																       {
																																																	  obj_t action_494;
																																																	  action_494 = (_static_bigloo___233_engine_param = BTRUE,
																																																	     BUNSPEC);
																																																	  {
																																																	     {
																																																		obj_t done1034_2367;
																																																		obj_t runner1024_2365;
																																																		runner1024_2365 = CDR(runner1024_112);
																																																		done1034_2367 = action_494;
																																																		done1034_113 = done1034_2367;
																																																		runner1024_112 = runner1024_2365;
																																																		goto loop1033_114;
																																																	     }
																																																	  }
																																																       }
																																																    }
																																																  else
																																																    {
																																																       bool_t test1392_495;
																																																       {
																																																	  bool_t test_2368;
																																																	  {
																																																	     long aux_2369;
																																																	     aux_2369 = STRING_LENGTH(arg1025_118);
																																																	     test_2368 = (aux_2369 >= ((long) 2));
																																																	  }
																																																	  if (test_2368)
																																																	    {
																																																	       obj_t arg1491_733;
																																																	       arg1491_733 = c_substring(arg1025_118, ((long) 0), ((long) 2));
																																																	       test1392_495 = bigloo_strcmp(arg1491_733, string1796_init_parse_args_215);
																																																	    }
																																																	  else
																																																	    {
																																																	       test1392_495 = ((bool_t) 0);
																																																	    }
																																																       }
																																																       if (test1392_495)
																																																	 {
																																																	    {
																																																	       obj_t library_496;
																																																	       {
																																																		  long aux_2375;
																																																		  aux_2375 = STRING_LENGTH(arg1025_118);
																																																		  library_496 = c_substring(arg1025_118, ((long) 2), aux_2375);
																																																	       }
																																																	       {
																																																		  obj_t the_remaining_args_132_498;
																																																		  the_remaining_args_132_498 = CDR(runner1024_112);
																																																		  {
																																																		     obj_t action_499;
																																																		     {
																																																			obj_t arg1393_500;
																																																			arg1393_500 = string_append(string1796_init_parse_args_215, library_496);
																																																			{
																																																			   obj_t obj2_1332;
																																																			   obj2_1332 = _bigloo_user_lib__33_engine_param;
																																																			   action_499 = (_bigloo_user_lib__33_engine_param = MAKE_PAIR(arg1393_500, obj2_1332),
																																																			      BUNSPEC);
																																																			}
																																																		     }
																																																		     {
																																																			{
																																																			   obj_t done1034_2382;
																																																			   obj_t runner1024_2381;
																																																			   runner1024_2381 = the_remaining_args_132_498;
																																																			   done1034_2382 = action_499;
																																																			   done1034_113 = done1034_2382;
																																																			   runner1024_112 = runner1024_2381;
																																																			   goto loop1033_114;
																																																			}
																																																		     }
																																																		  }
																																																	       }
																																																	    }
																																																	 }
																																																       else
																																																	 {
																																																	    bool_t test1397_503;
																																																	    test1397_503 = bigloo_strcmp(arg1025_118, string1797_init_parse_args_215);
																																																	    if (test1397_503)
																																																	      {
																																																		 {
																																																		    obj_t action_506;
																																																		    action_506 = (_trace_level__157_init_parse_args_215 = ((long) 1),
																																																		       BUNSPEC);
																																																		    {
																																																		       {
																																																			  obj_t done1034_2387;
																																																			  obj_t runner1024_2385;
																																																			  runner1024_2385 = CDR(runner1024_112);
																																																			  done1034_2387 = action_506;
																																																			  done1034_113 = done1034_2387;
																																																			  runner1024_112 = runner1024_2385;
																																																			  goto loop1033_114;
																																																		       }
																																																		    }
																																																		 }
																																																	      }
																																																	    else
																																																	      {
																																																		 bool_t test1398_507;
																																																		 test1398_507 = bigloo_strcmp(arg1025_118, string1798_init_parse_args_215);
																																																		 if (test1398_507)
																																																		   {
																																																		      {
																																																			 obj_t action_510;
																																																			 action_510 = (_trace_level__157_init_parse_args_215 = ((long) 2),
																																																			    BUNSPEC);
																																																			 {
																																																			    {
																																																			       obj_t done1034_2392;
																																																			       obj_t runner1024_2390;
																																																			       runner1024_2390 = CDR(runner1024_112);
																																																			       done1034_2392 = action_510;
																																																			       done1034_113 = done1034_2392;
																																																			       runner1024_112 = runner1024_2390;
																																																			       goto loop1033_114;
																																																			    }
																																																			 }
																																																		      }
																																																		   }
																																																		 else
																																																		   {
																																																		      bool_t test1399_511;
																																																		      test1399_511 = bigloo_strcmp(arg1025_118, string1799_init_parse_args_215);
																																																		      if (test1399_511)
																																																			{
																																																			   {
																																																			      obj_t action_514;
																																																			      action_514 = (_trace_level__157_init_parse_args_215 = ((long) 3),
																																																				 BUNSPEC);
																																																			      {
																																																				 {
																																																				    obj_t done1034_2397;
																																																				    obj_t runner1024_2395;
																																																				    runner1024_2395 = CDR(runner1024_112);
																																																				    done1034_2397 = action_514;
																																																				    done1034_113 = done1034_2397;
																																																				    runner1024_112 = runner1024_2395;
																																																				    goto loop1033_114;
																																																				 }
																																																			      }
																																																			   }
																																																			}
																																																		      else
																																																			{
																																																			   bool_t test1400_515;
																																																			   test1400_515 = bigloo_strcmp(arg1025_118, string1800_init_parse_args_215);
																																																			   if (test1400_515)
																																																			     {
																																																				{
																																																				   obj_t action_518;
																																																				   action_518 = (_trace_level__157_init_parse_args_215 = ((long) 4),
																																																				      BUNSPEC);
																																																				   {
																																																				      {
																																																					 obj_t done1034_2402;
																																																					 obj_t runner1024_2400;
																																																					 runner1024_2400 = CDR(runner1024_112);
																																																					 done1034_2402 = action_518;
																																																					 done1034_113 = done1034_2402;
																																																					 runner1024_112 = runner1024_2400;
																																																					 goto loop1033_114;
																																																				      }
																																																				   }
																																																				}
																																																			     }
																																																			   else
																																																			     {
																																																				bool_t test1401_519;
																																																				{
																																																				   bool_t test_2403;
																																																				   {
																																																				      long aux_2404;
																																																				      aux_2404 = STRING_LENGTH(arg1025_118);
																																																				      test_2403 = (aux_2404 >= ((long) 2));
																																																				   }
																																																				   if (test_2403)
																																																				     {
																																																					obj_t arg1486_728;
																																																					arg1486_728 = c_substring(arg1025_118, ((long) 0), ((long) 2));
																																																					test1401_519 = bigloo_strcmp(arg1486_728, string1801_init_parse_args_215);
																																																				     }
																																																				   else
																																																				     {
																																																					test1401_519 = ((bool_t) 0);
																																																				     }
																																																				}
																																																				if (test1401_519)
																																																				  {
																																																				     {
																																																					obj_t pass_520;
																																																					{
																																																					   long aux_2410;
																																																					   aux_2410 = STRING_LENGTH(arg1025_118);
																																																					   pass_520 = c_substring(arg1025_118, ((long) 2), aux_2410);
																																																					}
																																																					{
																																																					   obj_t the_remaining_args_132_522;
																																																					   the_remaining_args_132_522 = CDR(runner1024_112);
																																																					   {
																																																					      obj_t action_523;
																																																					      {
																																																						 obj_t arg1402_524;
																																																						 {
																																																						    obj_t arg1403_525;
																																																						    arg1403_525 = string_upcase_71___r4_strings_6_7(pass_520);
																																																						    {
																																																						       char *aux_2415;
																																																						       aux_2415 = BSTRING_TO_STRING(arg1403_525);
																																																						       arg1402_524 = string_to_symbol(aux_2415);
																																																						    }
																																																						 }
																																																						 {
																																																						    obj_t obj2_1360;
																																																						    obj2_1360 = _additional_traces__2_engine_param;
																																																						    action_523 = (_additional_traces__2_engine_param = MAKE_PAIR(arg1402_524, obj2_1360),
																																																						       BUNSPEC);
																																																						 }
																																																					      }
																																																					      {
																																																						 {
																																																						    obj_t done1034_2420;
																																																						    obj_t runner1024_2419;
																																																						    runner1024_2419 = the_remaining_args_132_522;
																																																						    done1034_2420 = action_523;
																																																						    done1034_113 = done1034_2420;
																																																						    runner1024_112 = runner1024_2419;
																																																						    goto loop1033_114;
																																																						 }
																																																					      }
																																																					   }
																																																					}
																																																				     }
																																																				  }
																																																				else
																																																				  {
																																																				     bool_t test1408_528;
																																																				     {
																																																					bool_t test_2421;
																																																					{
																																																					   long aux_2422;
																																																					   aux_2422 = STRING_LENGTH(arg1025_118);
																																																					   test_2421 = (aux_2422 >= ((long) 6));
																																																					}
																																																					if (test_2421)
																																																					  {
																																																					     obj_t arg1480_723;
																																																					     arg1480_723 = c_substring(arg1025_118, ((long) 0), ((long) 6));
																																																					     test1408_528 = bigloo_strcmp(arg1480_723, string1802_init_parse_args_215);
																																																					  }
																																																					else
																																																					  {
																																																					     test1408_528 = ((bool_t) 0);
																																																					  }
																																																				     }
																																																				     if (test1408_528)
																																																				       {
																																																					  {
																																																					     obj_t opt_529;
																																																					     {
																																																						long aux_2428;
																																																						aux_2428 = STRING_LENGTH(arg1025_118);
																																																						opt_529 = c_substring(arg1025_118, ((long) 6), aux_2428);
																																																					     }
																																																					     {
																																																						obj_t the_remaining_args_132_531;
																																																						the_remaining_args_132_531 = CDR(runner1024_112);
																																																						{
																																																						   obj_t action_532;
																																																						   action_532 = parse_shape_args_80_init_parse_args_215(opt_529);
																																																						   {
																																																						      {
																																																							 obj_t done1034_2434;
																																																							 obj_t runner1024_2433;
																																																							 runner1024_2433 = the_remaining_args_132_531;
																																																							 done1034_2434 = action_532;
																																																							 done1034_113 = done1034_2434;
																																																							 runner1024_112 = runner1024_2433;
																																																							 goto loop1033_114;
																																																						      }
																																																						   }
																																																						}
																																																					     }
																																																					  }
																																																				       }
																																																				     else
																																																				       {
																																																					  bool_t test1412_535;
																																																					  test1412_535 = bigloo_strcmp(arg1025_118, string1803_init_parse_args_215);
																																																					  if (test1412_535)
																																																					    {
																																																					       {
																																																						  obj_t action_538;
																																																						  action_538 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 8)),
																																																						     BUNSPEC);
																																																						  {
																																																						     {
																																																							obj_t done1034_2440;
																																																							obj_t runner1024_2438;
																																																							runner1024_2438 = CDR(runner1024_112);
																																																							done1034_2440 = action_538;
																																																							done1034_113 = done1034_2440;
																																																							runner1024_112 = runner1024_2438;
																																																							goto loop1033_114;
																																																						     }
																																																						  }
																																																					       }
																																																					    }
																																																					  else
																																																					    {
																																																					       bool_t test1413_539;
																																																					       test1413_539 = bigloo_strcmp(arg1025_118, string1804_init_parse_args_215);
																																																					       if (test1413_539)
																																																						 {
																																																						    {
																																																						       obj_t action_542;
																																																						       action_542 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 9)),
																																																							  BUNSPEC);
																																																						       {
																																																							  {
																																																							     obj_t done1034_2446;
																																																							     obj_t runner1024_2444;
																																																							     runner1024_2444 = CDR(runner1024_112);
																																																							     done1034_2446 = action_542;
																																																							     done1034_113 = done1034_2446;
																																																							     runner1024_112 = runner1024_2444;
																																																							     goto loop1033_114;
																																																							  }
																																																						       }
																																																						    }
																																																						 }
																																																					       else
																																																						 {
																																																						    bool_t test1414_543;
																																																						    test1414_543 = bigloo_strcmp(arg1025_118, string1805_init_parse_args_215);
																																																						    if (test1414_543)
																																																						      {
																																																							 {
																																																							    obj_t action_546;
																																																							    action_546 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 10)),
																																																							       BUNSPEC);
																																																							    {
																																																							       {
																																																								  obj_t done1034_2452;
																																																								  obj_t runner1024_2450;
																																																								  runner1024_2450 = CDR(runner1024_112);
																																																								  done1034_2452 = action_546;
																																																								  done1034_113 = done1034_2452;
																																																								  runner1024_112 = runner1024_2450;
																																																								  goto loop1033_114;
																																																							       }
																																																							    }
																																																							 }
																																																						      }
																																																						    else
																																																						      {
																																																							 bool_t test1415_547;
																																																							 test1415_547 = bigloo_strcmp(arg1025_118, string1806_init_parse_args_215);
																																																							 if (test1415_547)
																																																							   {
																																																							      {
																																																								 obj_t action_550;
																																																								 action_550 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 11)),
																																																								    BUNSPEC);
																																																								 {
																																																								    {
																																																								       obj_t done1034_2458;
																																																								       obj_t runner1024_2456;
																																																								       runner1024_2456 = CDR(runner1024_112);
																																																								       done1034_2458 = action_550;
																																																								       done1034_113 = done1034_2458;
																																																								       runner1024_112 = runner1024_2456;
																																																								       goto loop1033_114;
																																																								    }
																																																								 }
																																																							      }
																																																							   }
																																																							 else
																																																							   {
																																																							      bool_t test1416_551;
																																																							      test1416_551 = bigloo_strcmp(arg1025_118, string1807_init_parse_args_215);
																																																							      if (test1416_551)
																																																								{
																																																								   {
																																																								      obj_t action_554;
																																																								      action_554 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 12)),
																																																									 BUNSPEC);
																																																								      {
																																																									 {
																																																									    obj_t done1034_2464;
																																																									    obj_t runner1024_2462;
																																																									    runner1024_2462 = CDR(runner1024_112);
																																																									    done1034_2464 = action_554;
																																																									    done1034_113 = done1034_2464;
																																																									    runner1024_112 = runner1024_2462;
																																																									    goto loop1033_114;
																																																									 }
																																																								      }
																																																								   }
																																																								}
																																																							      else
																																																								{
																																																								   bool_t test1417_555;
																																																								   test1417_555 = bigloo_strcmp(arg1025_118, string1808_init_parse_args_215);
																																																								   if (test1417_555)
																																																								     {
																																																									{
																																																									   obj_t action_558;
																																																									   action_558 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 13)),
																																																									      BUNSPEC);
																																																									   {
																																																									      {
																																																										 obj_t done1034_2470;
																																																										 obj_t runner1024_2468;
																																																										 runner1024_2468 = CDR(runner1024_112);
																																																										 done1034_2470 = action_558;
																																																										 done1034_113 = done1034_2470;
																																																										 runner1024_112 = runner1024_2468;
																																																										 goto loop1033_114;
																																																									      }
																																																									   }
																																																									}
																																																								     }
																																																								   else
																																																								     {
																																																									bool_t test1418_559;
																																																									test1418_559 = bigloo_strcmp(arg1025_118, string1809_init_parse_args_215);
																																																									if (test1418_559)
																																																									  {
																																																									     {
																																																										obj_t action_562;
																																																										action_562 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 14)),
																																																										   BUNSPEC);
																																																										{
																																																										   {
																																																										      obj_t done1034_2476;
																																																										      obj_t runner1024_2474;
																																																										      runner1024_2474 = CDR(runner1024_112);
																																																										      done1034_2476 = action_562;
																																																										      done1034_113 = done1034_2476;
																																																										      runner1024_112 = runner1024_2474;
																																																										      goto loop1033_114;
																																																										   }
																																																										}
																																																									     }
																																																									  }
																																																									else
																																																									  {
																																																									     bool_t test1419_563;
																																																									     test1419_563 = bigloo_strcmp(arg1025_118, string1810_init_parse_args_215);
																																																									     if (test1419_563)
																																																									       {
																																																										  {
																																																										     obj_t action_566;
																																																										     action_566 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 15)),
																																																											BUNSPEC);
																																																										     {
																																																											{
																																																											   obj_t done1034_2482;
																																																											   obj_t runner1024_2480;
																																																											   runner1024_2480 = CDR(runner1024_112);
																																																											   done1034_2482 = action_566;
																																																											   done1034_113 = done1034_2482;
																																																											   runner1024_112 = runner1024_2480;
																																																											   goto loop1033_114;
																																																											}
																																																										     }
																																																										  }
																																																									       }
																																																									     else
																																																									       {
																																																										  bool_t test1420_567;
																																																										  test1420_567 = bigloo_strcmp(arg1025_118, string1811_init_parse_args_215);
																																																										  if (test1420_567)
																																																										    {
																																																										       {
																																																											  obj_t action_570;
																																																											  action_570 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 16)),
																																																											     BUNSPEC);
																																																											  {
																																																											     {
																																																												obj_t done1034_2488;
																																																												obj_t runner1024_2486;
																																																												runner1024_2486 = CDR(runner1024_112);
																																																												done1034_2488 = action_570;
																																																												done1034_113 = done1034_2488;
																																																												runner1024_112 = runner1024_2486;
																																																												goto loop1033_114;
																																																											     }
																																																											  }
																																																										       }
																																																										    }
																																																										  else
																																																										    {
																																																										       bool_t test1421_571;
																																																										       test1421_571 = bigloo_strcmp(arg1025_118, string1812_init_parse_args_215);
																																																										       if (test1421_571)
																																																											 {
																																																											    {
																																																											       obj_t action_574;
																																																											       action_574 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 17)),
																																																												  BUNSPEC);
																																																											       {
																																																												  {
																																																												     obj_t done1034_2494;
																																																												     obj_t runner1024_2492;
																																																												     runner1024_2492 = CDR(runner1024_112);
																																																												     done1034_2494 = action_574;
																																																												     done1034_113 = done1034_2494;
																																																												     runner1024_112 = runner1024_2492;
																																																												     goto loop1033_114;
																																																												  }
																																																											       }
																																																											    }
																																																											 }
																																																										       else
																																																											 {
																																																											    bool_t test1422_575;
																																																											    test1422_575 = bigloo_strcmp(arg1025_118, string1813_init_parse_args_215);
																																																											    if (test1422_575)
																																																											      {
																																																												 {
																																																												    obj_t action_578;
																																																												    action_578 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 18)),
																																																												       BUNSPEC);
																																																												    {
																																																												       {
																																																													  obj_t done1034_2500;
																																																													  obj_t runner1024_2498;
																																																													  runner1024_2498 = CDR(runner1024_112);
																																																													  done1034_2500 = action_578;
																																																													  done1034_113 = done1034_2500;
																																																													  runner1024_112 = runner1024_2498;
																																																													  goto loop1033_114;
																																																												       }
																																																												    }
																																																												 }
																																																											      }
																																																											    else
																																																											      {
																																																												 bool_t test1423_579;
																																																												 test1423_579 = bigloo_strcmp(arg1025_118, string1814_init_parse_args_215);
																																																												 if (test1423_579)
																																																												   {
																																																												      {
																																																													 obj_t action_582;
																																																													 action_582 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 19)),
																																																													    BUNSPEC);
																																																													 {
																																																													    {
																																																													       obj_t done1034_2506;
																																																													       obj_t runner1024_2504;
																																																													       runner1024_2504 = CDR(runner1024_112);
																																																													       done1034_2506 = action_582;
																																																													       done1034_113 = done1034_2506;
																																																													       runner1024_112 = runner1024_2504;
																																																													       goto loop1033_114;
																																																													    }
																																																													 }
																																																												      }
																																																												   }
																																																												 else
																																																												   {
																																																												      bool_t test1424_583;
																																																												      test1424_583 = bigloo_strcmp(arg1025_118, string1815_init_parse_args_215);
																																																												      if (test1424_583)
																																																													{
																																																													   {
																																																													      obj_t action_586;
																																																													      action_586 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 20)),
																																																														 BUNSPEC);
																																																													      {
																																																														 {
																																																														    obj_t done1034_2512;
																																																														    obj_t runner1024_2510;
																																																														    runner1024_2510 = CDR(runner1024_112);
																																																														    done1034_2512 = action_586;
																																																														    done1034_113 = done1034_2512;
																																																														    runner1024_112 = runner1024_2510;
																																																														    goto loop1033_114;
																																																														 }
																																																													      }
																																																													   }
																																																													}
																																																												      else
																																																													{
																																																													   bool_t test1425_587;
																																																													   test1425_587 = bigloo_strcmp(arg1025_118, string1816_init_parse_args_215);
																																																													   if (test1425_587)
																																																													     {
																																																														{
																																																														   obj_t action_590;
																																																														   action_590 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 21)),
																																																														      BUNSPEC);
																																																														   {
																																																														      {
																																																															 obj_t done1034_2518;
																																																															 obj_t runner1024_2516;
																																																															 runner1024_2516 = CDR(runner1024_112);
																																																															 done1034_2518 = action_590;
																																																															 done1034_113 = done1034_2518;
																																																															 runner1024_112 = runner1024_2516;
																																																															 goto loop1033_114;
																																																														      }
																																																														   }
																																																														}
																																																													     }
																																																													   else
																																																													     {
																																																														bool_t test1426_591;
																																																														test1426_591 = bigloo_strcmp(arg1025_118, string1817_init_parse_args_215);
																																																														if (test1426_591)
																																																														  {
																																																														     {
																																																															obj_t action_594;
																																																															action_594 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 22)),
																																																															   BUNSPEC);
																																																															{
																																																															   {
																																																															      obj_t done1034_2524;
																																																															      obj_t runner1024_2522;
																																																															      runner1024_2522 = CDR(runner1024_112);
																																																															      done1034_2524 = action_594;
																																																															      done1034_113 = done1034_2524;
																																																															      runner1024_112 = runner1024_2522;
																																																															      goto loop1033_114;
																																																															   }
																																																															}
																																																														     }
																																																														  }
																																																														else
																																																														  {
																																																														     bool_t test1427_595;
																																																														     test1427_595 = bigloo_strcmp(arg1025_118, string1818_init_parse_args_215);
																																																														     if (test1427_595)
																																																														       {
																																																															  {
																																																															     obj_t action_598;
																																																															     action_598 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 23)),
																																																																BUNSPEC);
																																																															     {
																																																																{
																																																																   obj_t done1034_2530;
																																																																   obj_t runner1024_2528;
																																																																   runner1024_2528 = CDR(runner1024_112);
																																																																   done1034_2530 = action_598;
																																																																   done1034_113 = done1034_2530;
																																																																   runner1024_112 = runner1024_2528;
																																																																   goto loop1033_114;
																																																																}
																																																															     }
																																																															  }
																																																														       }
																																																														     else
																																																														       {
																																																															  bool_t test1428_599;
																																																															  test1428_599 = bigloo_strcmp(arg1025_118, string1819_init_parse_args_215);
																																																															  if (test1428_599)
																																																															    {
																																																															       {
																																																																  obj_t action_602;
																																																																  action_602 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 24)),
																																																																     BUNSPEC);
																																																																  {
																																																																     {
																																																																	obj_t done1034_2536;
																																																																	obj_t runner1024_2534;
																																																																	runner1024_2534 = CDR(runner1024_112);
																																																																	done1034_2536 = action_602;
																																																																	done1034_113 = done1034_2536;
																																																																	runner1024_112 = runner1024_2534;
																																																																	goto loop1033_114;
																																																																     }
																																																																  }
																																																															       }
																																																															    }
																																																															  else
																																																															    {
																																																															       bool_t test1429_603;
																																																															       test1429_603 = bigloo_strcmp(arg1025_118, string1820_init_parse_args_215);
																																																															       if (test1429_603)
																																																																 {
																																																																    {
																																																																       obj_t action_606;
																																																																       action_606 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 25)),
																																																																	  BUNSPEC);
																																																																       {
																																																																	  {
																																																																	     obj_t done1034_2542;
																																																																	     obj_t runner1024_2540;
																																																																	     runner1024_2540 = CDR(runner1024_112);
																																																																	     done1034_2542 = action_606;
																																																																	     done1034_113 = done1034_2542;
																																																																	     runner1024_112 = runner1024_2540;
																																																																	     goto loop1033_114;
																																																																	  }
																																																																       }
																																																																    }
																																																																 }
																																																															       else
																																																																 {
																																																																    bool_t test1430_607;
																																																																    test1430_607 = bigloo_strcmp(arg1025_118, string1821_init_parse_args_215);
																																																																    if (test1430_607)
																																																																      {
																																																																	 {
																																																																	    obj_t action_610;
																																																																	    action_610 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 26)),
																																																																	       BUNSPEC);
																																																																	    {
																																																																	       {
																																																																		  obj_t done1034_2548;
																																																																		  obj_t runner1024_2546;
																																																																		  runner1024_2546 = CDR(runner1024_112);
																																																																		  done1034_2548 = action_610;
																																																																		  done1034_113 = done1034_2548;
																																																																		  runner1024_112 = runner1024_2546;
																																																																		  goto loop1033_114;
																																																																	       }
																																																																	    }
																																																																	 }
																																																																      }
																																																																    else
																																																																      {
																																																																	 bool_t test1431_611;
																																																																	 test1431_611 = bigloo_strcmp(arg1025_118, string1822_init_parse_args_215);
																																																																	 if (test1431_611)
																																																																	   {
																																																																	      {
																																																																		 obj_t action_614;
																																																																		 action_614 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 27)),
																																																																		    BUNSPEC);
																																																																		 {
																																																																		    {
																																																																		       obj_t done1034_2554;
																																																																		       obj_t runner1024_2552;
																																																																		       runner1024_2552 = CDR(runner1024_112);
																																																																		       done1034_2554 = action_614;
																																																																		       done1034_113 = done1034_2554;
																																																																		       runner1024_112 = runner1024_2552;
																																																																		       goto loop1033_114;
																																																																		    }
																																																																		 }
																																																																	      }
																																																																	   }
																																																																	 else
																																																																	   {
																																																																	      bool_t test1432_615;
																																																																	      test1432_615 = bigloo_strcmp(arg1025_118, string1823_init_parse_args_215);
																																																																	      if (test1432_615)
																																																																		{
																																																																		   {
																																																																		      obj_t action_618;
																																																																		      action_618 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 28)),
																																																																			 BUNSPEC);
																																																																		      {
																																																																			 {
																																																																			    obj_t done1034_2560;
																																																																			    obj_t runner1024_2558;
																																																																			    runner1024_2558 = CDR(runner1024_112);
																																																																			    done1034_2560 = action_618;
																																																																			    done1034_113 = done1034_2560;
																																																																			    runner1024_112 = runner1024_2558;
																																																																			    goto loop1033_114;
																																																																			 }
																																																																		      }
																																																																		   }
																																																																		}
																																																																	      else
																																																																		{
																																																																		   bool_t test1433_619;
																																																																		   test1433_619 = bigloo_strcmp(arg1025_118, string1824_init_parse_args_215);
																																																																		   if (test1433_619)
																																																																		     {
																																																																			{
																																																																			   obj_t action_622;
																																																																			   action_622 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 29)),
																																																																			      BUNSPEC);
																																																																			   {
																																																																			      {
																																																																				 obj_t done1034_2566;
																																																																				 obj_t runner1024_2564;
																																																																				 runner1024_2564 = CDR(runner1024_112);
																																																																				 done1034_2566 = action_622;
																																																																				 done1034_113 = done1034_2566;
																																																																				 runner1024_112 = runner1024_2564;
																																																																				 goto loop1033_114;
																																																																			      }
																																																																			   }
																																																																			}
																																																																		     }
																																																																		   else
																																																																		     {
																																																																			bool_t test1434_623;
																																																																			test1434_623 = bigloo_strcmp(arg1025_118, string1825_init_parse_args_215);
																																																																			if (test1434_623)
																																																																			  {
																																																																			     {
																																																																				obj_t action_626;
																																																																				action_626 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 30)),
																																																																				   BUNSPEC);
																																																																				{
																																																																				   {
																																																																				      obj_t done1034_2572;
																																																																				      obj_t runner1024_2570;
																																																																				      runner1024_2570 = CDR(runner1024_112);
																																																																				      done1034_2572 = action_626;
																																																																				      done1034_113 = done1034_2572;
																																																																				      runner1024_112 = runner1024_2570;
																																																																				      goto loop1033_114;
																																																																				   }
																																																																				}
																																																																			     }
																																																																			  }
																																																																			else
																																																																			  {
																																																																			     bool_t test1435_627;
																																																																			     test1435_627 = bigloo_strcmp(arg1025_118, string1826_init_parse_args_215);
																																																																			     if (test1435_627)
																																																																			       {
																																																																				  {
																																																																				     obj_t action_630;
																																																																				     action_630 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 31)),
																																																																					BUNSPEC);
																																																																				     {
																																																																					{
																																																																					   obj_t done1034_2578;
																																																																					   obj_t runner1024_2576;
																																																																					   runner1024_2576 = CDR(runner1024_112);
																																																																					   done1034_2578 = action_630;
																																																																					   done1034_113 = done1034_2578;
																																																																					   runner1024_112 = runner1024_2576;
																																																																					   goto loop1033_114;
																																																																					}
																																																																				     }
																																																																				  }
																																																																			       }
																																																																			     else
																																																																			       {
																																																																				  bool_t test1436_631;
																																																																				  test1436_631 = bigloo_strcmp(arg1025_118, string1827_init_parse_args_215);
																																																																				  if (test1436_631)
																																																																				    {
																																																																				       {
																																																																					  obj_t action_634;
																																																																					  action_634 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 32)),
																																																																					     BUNSPEC);
																																																																					  {
																																																																					     {
																																																																						obj_t done1034_2584;
																																																																						obj_t runner1024_2582;
																																																																						runner1024_2582 = CDR(runner1024_112);
																																																																						done1034_2584 = action_634;
																																																																						done1034_113 = done1034_2584;
																																																																						runner1024_112 = runner1024_2582;
																																																																						goto loop1033_114;
																																																																					     }
																																																																					  }
																																																																				       }
																																																																				    }
																																																																				  else
																																																																				    {
																																																																				       bool_t test1437_635;
																																																																				       test1437_635 = bigloo_strcmp(arg1025_118, string1828_init_parse_args_215);
																																																																				       if (test1437_635)
																																																																					 {
																																																																					    {
																																																																					       obj_t action_638;
																																																																					       _module_checksum_object___74_engine_param = BTRUE;
																																																																					       action_638 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 33)),
																																																																						  BUNSPEC);
																																																																					       {
																																																																						  {
																																																																						     obj_t done1034_2590;
																																																																						     obj_t runner1024_2588;
																																																																						     runner1024_2588 = CDR(runner1024_112);
																																																																						     done1034_2590 = action_638;
																																																																						     done1034_113 = done1034_2590;
																																																																						     runner1024_112 = runner1024_2588;
																																																																						     goto loop1033_114;
																																																																						  }
																																																																					       }
																																																																					    }
																																																																					 }
																																																																				       else
																																																																					 {
																																																																					    bool_t test1438_639;
																																																																					    test1438_639 = bigloo_strcmp(arg1025_118, string1829_init_parse_args_215);
																																																																					    if (test1438_639)
																																																																					      {
																																																																						 {
																																																																						    obj_t action_642;
																																																																						    action_642 = (_init_mode__183_engine_param = CNST_TABLE_REF(((long) 34)),
																																																																						       BUNSPEC);
																																																																						    {
																																																																						       {
																																																																							  obj_t done1034_2596;
																																																																							  obj_t runner1024_2594;
																																																																							  runner1024_2594 = CDR(runner1024_112);
																																																																							  done1034_2596 = action_642;
																																																																							  done1034_113 = done1034_2596;
																																																																							  runner1024_112 = runner1024_2594;
																																																																							  goto loop1033_114;
																																																																						       }
																																																																						    }
																																																																						 }
																																																																					      }
																																																																					    else
																																																																					      {
																																																																						 bool_t test1439_643;
																																																																						 test1439_643 = bigloo_strcmp(arg1025_118, string1830_init_parse_args_215);
																																																																						 if (test1439_643)
																																																																						   {
																																																																						      {
																																																																							 obj_t action_646;
																																																																							 action_646 = (_init_mode__183_engine_param = CNST_TABLE_REF(((long) 35)),
																																																																							    BUNSPEC);
																																																																							 {
																																																																							    {
																																																																							       obj_t done1034_2602;
																																																																							       obj_t runner1024_2600;
																																																																							       runner1024_2600 = CDR(runner1024_112);
																																																																							       done1034_2602 = action_646;
																																																																							       done1034_113 = done1034_2602;
																																																																							       runner1024_112 = runner1024_2600;
																																																																							       goto loop1033_114;
																																																																							    }
																																																																							 }
																																																																						      }
																																																																						   }
																																																																						 else
																																																																						   {
																																																																						      bool_t test1440_647;
																																																																						      test1440_647 = bigloo_strcmp(arg1025_118, string1831_init_parse_args_215);
																																																																						      if (test1440_647)
																																																																							{
																																																																							   {
																																																																							      obj_t action_650;
																																																																							      action_650 = (_init_mode__183_engine_param = CNST_TABLE_REF(((long) 36)),
																																																																								 BUNSPEC);
																																																																							      {
																																																																								 {
																																																																								    obj_t done1034_2608;
																																																																								    obj_t runner1024_2606;
																																																																								    runner1024_2606 = CDR(runner1024_112);
																																																																								    done1034_2608 = action_650;
																																																																								    done1034_113 = done1034_2608;
																																																																								    runner1024_112 = runner1024_2606;
																																																																								    goto loop1033_114;
																																																																								 }
																																																																							      }
																																																																							   }
																																																																							}
																																																																						      else
																																																																							{
																																																																							   bool_t test1441_651;
																																																																							   test1441_651 = bigloo_strcmp(arg1025_118, string1832_init_parse_args_215);
																																																																							   if (test1441_651)
																																																																							     {
																																																																								{
																																																																								   obj_t action_654;
																																																																								   _lib_mode__85_engine_param = BTRUE;
																																																																								   action_654 = (_init_mode__183_engine_param = CNST_TABLE_REF(((long) 34)),
																																																																								      BUNSPEC);
																																																																								   {
																																																																								      {
																																																																									 obj_t done1034_2614;
																																																																									 obj_t runner1024_2612;
																																																																									 runner1024_2612 = CDR(runner1024_112);
																																																																									 done1034_2614 = action_654;
																																																																									 done1034_113 = done1034_2614;
																																																																									 runner1024_112 = runner1024_2612;
																																																																									 goto loop1033_114;
																																																																								      }
																																																																								   }
																																																																								}
																																																																							     }
																																																																							   else
																																																																							     {
																																																																								bool_t test1442_655;
																																																																								test1442_655 = bigloo_strcmp(arg1025_118, string1833_init_parse_args_215);
																																																																								if (test1442_655)
																																																																								  {
																																																																								     {
																																																																									obj_t action_658;
																																																																									action_658 = (_init_mode__183_engine_param = CNST_TABLE_REF(((long) 34)),
																																																																									   BUNSPEC);
																																																																									{
																																																																									   {
																																																																									      obj_t done1034_2620;
																																																																									      obj_t runner1024_2618;
																																																																									      runner1024_2618 = CDR(runner1024_112);
																																																																									      done1034_2620 = action_658;
																																																																									      done1034_113 = done1034_2620;
																																																																									      runner1024_112 = runner1024_2618;
																																																																									      goto loop1033_114;
																																																																									   }
																																																																									}
																																																																								     }
																																																																								  }
																																																																								else
																																																																								  {
																																																																								     bool_t test1443_659;
																																																																								     test1443_659 = bigloo_strcmp(arg1025_118, string1834_init_parse_args_215);
																																																																								     if (test1443_659)
																																																																								       {
																																																																									  {
																																																																									     obj_t action_662;
																																																																									     action_662 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 37)),
																																																																										BUNSPEC);
																																																																									     {
																																																																										{
																																																																										   obj_t done1034_2626;
																																																																										   obj_t runner1024_2624;
																																																																										   runner1024_2624 = CDR(runner1024_112);
																																																																										   done1034_2626 = action_662;
																																																																										   done1034_113 = done1034_2626;
																																																																										   runner1024_112 = runner1024_2624;
																																																																										   goto loop1033_114;
																																																																										}
																																																																									     }
																																																																									  }
																																																																								       }
																																																																								     else
																																																																								       {
																																																																									  bool_t test1444_663;
																																																																									  test1444_663 = bigloo_strcmp(arg1025_118, string1835_init_parse_args_215);
																																																																									  if (test1444_663)
																																																																									    {
																																																																									       {
																																																																										  obj_t action_666;
																																																																										  action_666 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 38)),
																																																																										     BUNSPEC);
																																																																										  {
																																																																										     {
																																																																											obj_t done1034_2632;
																																																																											obj_t runner1024_2630;
																																																																											runner1024_2630 = CDR(runner1024_112);
																																																																											done1034_2632 = action_666;
																																																																											done1034_113 = done1034_2632;
																																																																											runner1024_112 = runner1024_2630;
																																																																											goto loop1033_114;
																																																																										     }
																																																																										  }
																																																																									       }
																																																																									    }
																																																																									  else
																																																																									    {
																																																																									       bool_t test1445_667;
																																																																									       test1445_667 = bigloo_strcmp(arg1025_118, string1836_init_parse_args_215);
																																																																									       if (test1445_667)
																																																																										 {
																																																																										    {
																																																																										       obj_t action_670;
																																																																										       action_670 = (_pass__125_engine_param = CNST_TABLE_REF(((long) 39)),
																																																																											  BUNSPEC);
																																																																										       {
																																																																											  {
																																																																											     obj_t done1034_2638;
																																																																											     obj_t runner1024_2636;
																																																																											     runner1024_2636 = CDR(runner1024_112);
																																																																											     done1034_2638 = action_670;
																																																																											     done1034_113 = done1034_2638;
																																																																											     runner1024_112 = runner1024_2636;
																																																																											     goto loop1033_114;
																																																																											  }
																																																																										       }
																																																																										    }
																																																																										 }
																																																																									       else
																																																																										 {
																																																																										    bool_t test1446_671;
																																																																										    test1446_671 = bigloo_strcmp(arg1025_118, string1837_init_parse_args_215);
																																																																										    if (test1446_671)
																																																																										      {
																																																																											 {
																																																																											    obj_t action_674;
																																																																											    action_674 = (_bigloo_licensing___64_engine_param = BTRUE,
																																																																											       BUNSPEC);
																																																																											    {
																																																																											       {
																																																																												  obj_t done1034_2643;
																																																																												  obj_t runner1024_2641;
																																																																												  runner1024_2641 = CDR(runner1024_112);
																																																																												  done1034_2643 = action_674;
																																																																												  done1034_113 = done1034_2643;
																																																																												  runner1024_112 = runner1024_2641;
																																																																												  goto loop1033_114;
																																																																											       }
																																																																											    }
																																																																											 }
																																																																										      }
																																																																										    else
																																																																										      {
																																																																											 bool_t test1447_675;
																																																																											 test1447_675 = bigloo_strcmp(arg1025_118, string1838_init_parse_args_215);
																																																																											 if (test1447_675)
																																																																											   {
																																																																											      {
																																																																												 obj_t action_679;
																																																																												 {
																																																																												    obj_t aux_2646;
																																																																												    aux_2646 = CDR(runner1024_112);
																																																																												    action_679 = (_heap_name__135_engine_param = CAR(aux_2646),
																																																																												       BUNSPEC);
																																																																												 }
																																																																												 {
																																																																												    {
																																																																												       obj_t done1034_2653;
																																																																												       obj_t runner1024_2649;
																																																																												       {
																																																																													  obj_t aux_2650;
																																																																													  aux_2650 = CDR(runner1024_112);
																																																																													  runner1024_2649 = CDR(aux_2650);
																																																																												       }
																																																																												       done1034_2653 = action_679;
																																																																												       done1034_113 = done1034_2653;
																																																																												       runner1024_112 = runner1024_2649;
																																																																												       goto loop1033_114;
																																																																												    }
																																																																												 }
																																																																											      }
																																																																											   }
																																																																											 else
																																																																											   {
																																																																											      bool_t test1450_682;
																																																																											      test1450_682 = bigloo_strcmp(arg1025_118, string1839_init_parse_args_215);
																																																																											      if (test1450_682)
																																																																												{
																																																																												   {
																																																																												      obj_t action_686;
																																																																												      {
																																																																													 obj_t aux_2656;
																																																																													 aux_2656 = CDR(runner1024_112);
																																																																													 action_686 = (_additional_heap_name__223_engine_param = CAR(aux_2656),
																																																																													    BUNSPEC);
																																																																												      }
																																																																												      {
																																																																													 {
																																																																													    obj_t done1034_2663;
																																																																													    obj_t runner1024_2659;
																																																																													    {
																																																																													       obj_t aux_2660;
																																																																													       aux_2660 = CDR(runner1024_112);
																																																																													       runner1024_2659 = CDR(aux_2660);
																																																																													    }
																																																																													    done1034_2663 = action_686;
																																																																													    done1034_113 = done1034_2663;
																																																																													    runner1024_112 = runner1024_2659;
																																																																													    goto loop1033_114;
																																																																													 }
																																																																												      }
																																																																												   }
																																																																												}
																																																																											      else
																																																																												{
																																																																												   bool_t test1455_689;
																																																																												   test1455_689 = bigloo_strcmp(arg1025_118, string1840_init_parse_args_215);
																																																																												   if (test1455_689)
																																																																												     {
																																																																													{
																																																																													   obj_t action_692;
																																																																													   action_692 = (_reader__83_engine_param = CNST_TABLE_REF(((long) 36)),
																																																																													      BUNSPEC);
																																																																													   {
																																																																													      {
																																																																														 obj_t done1034_2669;
																																																																														 obj_t runner1024_2667;
																																																																														 runner1024_2667 = CDR(runner1024_112);
																																																																														 done1034_2669 = action_692;
																																																																														 done1034_113 = done1034_2669;
																																																																														 runner1024_112 = runner1024_2667;
																																																																														 goto loop1033_114;
																																																																													      }
																																																																													   }
																																																																													}
																																																																												     }
																																																																												   else
																																																																												     {
																																																																													bool_t test1456_693;
																																																																													test1456_693 = bigloo_strcmp(arg1025_118, string1841_init_parse_args_215);
																																																																													if (test1456_693)
																																																																													  {
																																																																													     {
																																																																														obj_t action_696;
																																																																														action_696 = (_reader__83_engine_param = CNST_TABLE_REF(((long) 40)),
																																																																														   BUNSPEC);
																																																																														{
																																																																														   {
																																																																														      obj_t done1034_2675;
																																																																														      obj_t runner1024_2673;
																																																																														      runner1024_2673 = CDR(runner1024_112);
																																																																														      done1034_2675 = action_696;
																																																																														      done1034_113 = done1034_2675;
																																																																														      runner1024_112 = runner1024_2673;
																																																																														      goto loop1033_114;
																																																																														   }
																																																																														}
																																																																													     }
																																																																													  }
																																																																													else
																																																																													  {
																																																																													     bool_t test1457_697;
																																																																													     {
																																																																														bool_t test_2676;
																																																																														{
																																																																														   long aux_2677;
																																																																														   aux_2677 = STRING_LENGTH(arg1025_118);
																																																																														   test_2676 = (aux_2677 >= ((long) 1));
																																																																														}
																																																																														if (test_2676)
																																																																														  {
																																																																														     obj_t arg1475_718;
																																																																														     arg1475_718 = c_substring(arg1025_118, ((long) 0), ((long) 1));
																																																																														     test1457_697 = bigloo_strcmp(arg1475_718, string1722_init_parse_args_215);
																																																																														  }
																																																																														else
																																																																														  {
																																																																														     test1457_697 = ((bool_t) 0);
																																																																														  }
																																																																													     }
																																																																													     if (test1457_697)
																																																																													       {
																																																																														  {
																																																																														     obj_t dummy_698;
																																																																														     {
																																																																															long aux_2683;
																																																																															aux_2683 = STRING_LENGTH(arg1025_118);
																																																																															dummy_698 = c_substring(arg1025_118, ((long) 1), aux_2683);
																																																																														     }
																																																																														     {
																																																																															obj_t the_remaining_args_132_700;
																																																																															the_remaining_args_132_700 = CDR(runner1024_112);
																																																																															{
																																																																															   obj_t action_701;
																																																																															   {
																																																																															      obj_t obj2_1511;
																																																																															      obj2_1511 = _rest_args__8_engine_param;
																																																																															      action_701 = (_rest_args__8_engine_param = MAKE_PAIR(arg1025_118, obj2_1511),
																																																																																 BUNSPEC);
																																																																															   }
																																																																															   {
																																																																															      {
																																																																																 obj_t done1034_2689;
																																																																																 obj_t runner1024_2688;
																																																																																 runner1024_2688 = the_remaining_args_132_700;
																																																																																 done1034_2689 = action_701;
																																																																																 done1034_113 = done1034_2689;
																																																																																 runner1024_112 = runner1024_2688;
																																																																																 goto loop1033_114;
																																																																															      }
																																																																															   }
																																																																															}
																																																																														     }
																																																																														  }
																																																																													       }
																																																																													     else
																																																																													       {
																																																																														  {
																																																																														     obj_t arg1461_705;
																																																																														     obj_t arg1463_706;
																																																																														     arg1461_705 = CDR(runner1024_112);
																																																																														     {
																																																																															obj_t suf_707;
																																																																															suf_707 = suffix___os(arg1025_118);
																																																																															{
																																																																															   bool_t test1464_708;
																																																																															   {
																																																																															      bool_t test_2692;
																																																																															      {
																																																																																 long aux_2693;
																																																																																 aux_2693 = STRING_LENGTH(suf_707);
																																																																																 test_2692 = (aux_2693 == ((long) 0));
																																																																															      }
																																																																															      if (test_2692)
																																																																																{
																																																																																   obj_t obj_1517;
																																																																																   obj_1517 = _src_files__222_engine_param;
																																																																																   test1464_708 = NULLP(obj_1517);
																																																																																}
																																																																															      else
																																																																																{
																																																																																   test1464_708 = ((bool_t) 0);
																																																																																}
																																																																															   }
																																																																															   if (test1464_708)
																																																																															     {
																																																																																{
																																																																																   obj_t list1465_709;
																																																																																   list1465_709 = MAKE_PAIR(arg1025_118, BNIL);
																																																																																   arg1463_706 = (_src_files__222_engine_param = list1465_709,
																																																																																      BUNSPEC);
																																																																																}
																																																																															     }
																																																																															   else
																																																																															     {
																																																																																bool_t test1467_711;
																																																																																{
																																																																																   obj_t aux_2699;
																																																																																   aux_2699 = member___r4_pairs_and_lists_6_3(suf_707, _src_suffix__192_engine_param);
																																																																																   test1467_711 = CBOOL(aux_2699);
																																																																																}
																																																																																if (test1467_711)
																																																																																  {
																																																																																     {
																																																																																	obj_t obj2_1520;
																																																																																	obj2_1520 = _src_files__222_engine_param;
																																																																																	arg1463_706 = (_src_files__222_engine_param = MAKE_PAIR(arg1025_118, obj2_1520),
																																																																																	   BUNSPEC);
																																																																																     }
																																																																																  }
																																																																																else
																																																																																  {
																																																																																     if (CBOOL(_interpreter__140_engine_param))
																																																																																       {
																																																																																	  arg1463_706 = CNST_TABLE_REF(((long) 41));
																																																																																       }
																																																																																     else
																																																																																       {
																																																																																	  bool_t test1468_712;
																																																																																	  {
																																																																																	     obj_t aux_2707;
																																																																																	     aux_2707 = member___r4_pairs_and_lists_6_3(suf_707, _obj_suffix__189_engine_param);
																																																																																	     test1468_712 = CBOOL(aux_2707);
																																																																																	  }
																																																																																	  if (test1468_712)
																																																																																	    {
																																																																																	       {
																																																																																		  obj_t obj2_1522;
																																																																																		  obj2_1522 = _o_files__27_engine_param;
																																																																																		  arg1463_706 = (_o_files__27_engine_param = MAKE_PAIR(arg1025_118, obj2_1522),
																																																																																		     BUNSPEC);
																																																																																	       }
																																																																																	    }
																																																																																	  else
																																																																																	    {
																																																																																	       {
																																																																																		  obj_t obj2_1524;
																																																																																		  obj2_1524 = _rest_args__8_engine_param;
																																																																																		  arg1463_706 = (_rest_args__8_engine_param = MAKE_PAIR(arg1025_118, obj2_1524),
																																																																																		     BUNSPEC);
																																																																																	       }
																																																																																	    }
																																																																																       }
																																																																																  }
																																																																															     }
																																																																															}
																																																																														     }
																																																																														     {
																																																																															obj_t done1034_2714;
																																																																															obj_t runner1024_2713;
																																																																															runner1024_2713 = arg1461_705;
																																																																															done1034_2714 = arg1463_706;
																																																																															done1034_113 = done1034_2714;
																																																																															runner1024_112 = runner1024_2713;
																																																																															goto loop1033_114;
																																																																														     }
																																																																														  }
																																																																													       }
																																																																													  }
																																																																												     }
																																																																												}
																																																																											   }
																																																																										      }
																																																																										 }
																																																																									    }
																																																																								       }
																																																																								  }
																																																																							     }
																																																																							}
																																																																						   }
																																																																					      }
																																																																					 }
																																																																				    }
																																																																			       }
																																																																			  }
																																																																		     }
																																																																		}
																																																																	   }
																																																																      }
																																																																 }
																																																															    }
																																																														       }
																																																														  }
																																																													     }
																																																													}
																																																												   }
																																																											      }
																																																											 }
																																																										    }
																																																									       }
																																																									  }
																																																								     }
																																																								}
																																																							   }
																																																						      }
																																																						 }
																																																					    }
																																																				       }
																																																				  }
																																																			     }
																																																			}
																																																		   }
																																																	      }
																																																	 }
																																																    }
																																															       }
																																															  }
																																														     }
																																														}
																																													   }
																																												      }
																																												 }
																																											    }
																																										       }
																																										  }
																																									     }
																																									}
																																								   }
																																							      }
																																							 }
																																						    }
																																					       }
																																					  }
																																				     }
																																				}
																																			   }
																																		      }
																																		 }
																																	    }
																																       }
																																  }
																															     }
																															}
																														   }
																													      }
																													 }
																												    }
																											       }
																											  }
																										     }
																										}
																									   }
																								      }
																								 }
																							    }
																						       }
																						  }
																					     }
																					}
																				   }
																			      }
																			 }
																		    }
																	       }
																	  }
																     }
																}
															   }
														      }
														 }
													    }
												       }
												  }
											     }
											}
										   }
									      }
									 }
								    }
							       }
							  }
						     }
						}
					   }
				      }
				 }
			      }
			   }
			}
		      else
			{
			   FAILURE(string1720_init_parse_args_215, string1721_init_parse_args_215, runner1024_112);
			}
		   }
	      }
	 }
      }
   }
}


/* usage */ obj_t 
usage_init_parse_args_215(obj_t args_parse_usage_117_801, long level_802, bool_t manual__151_803)
{
   {
      bool_t manual__151_831;
      version_write_version();
      {
	 obj_t list1559_805;
	 list1559_805 = MAKE_PAIR(string1848_init_parse_args_215, BNIL);
	 print___r4_output_6_10_3(list1559_805);
      }
      newline___r4_output_6_10_3(BNIL);
      PROCEDURE_ENTRY(args_parse_usage_117_801) (args_parse_usage_117_801, BBOOL(manual__151_803), BEOA);
      newline___r4_output_6_10_3(BNIL);
      {
	 obj_t list1564_810;
	 list1564_810 = MAKE_PAIR(string1849_init_parse_args_215, BNIL);
	 print___r4_output_6_10_3(list1564_810);
      }
      {
	 obj_t list1567_813;
	 list1567_813 = MAKE_PAIR(string1850_init_parse_args_215, BNIL);
	 print___r4_output_6_10_3(list1567_813);
      }
      {
	 obj_t list1570_816;
	 list1570_816 = MAKE_PAIR(string1851_init_parse_args_215, BNIL);
	 print___r4_output_6_10_3(list1570_816);
      }
      newline___r4_output_6_10_3(BNIL);
      newline___r4_output_6_10_3(BNIL);
      manual__151_831 = manual__151_803;
      {
	 obj_t list1588_833;
	 list1588_833 = MAKE_PAIR(string1842_init_parse_args_215, BNIL);
	 print___r4_output_6_10_3(list1588_833);
      }
      newline___r4_output_6_10_3(BNIL);
      {
	 obj_t l1021_837;
	 l1021_837 = CNST_TABLE_REF(((long) 42));
       lname1022_838:
	 if (PAIRP(l1021_837))
	   {
	      {
		 obj_t var_841;
		 var_841 = CAR(l1021_837);
		 if (manual__151_831)
		   {
		      {
			 obj_t list1601_844;
			 {
			    obj_t arg1602_845;
			    {
			       obj_t aux_2739;
			       aux_2739 = CAR(var_841);
			       arg1602_845 = MAKE_PAIR(aux_2739, BNIL);
			    }
			    list1601_844 = MAKE_PAIR(string1843_init_parse_args_215, arg1602_845);
			 }
			 print___r4_output_6_10_3(list1601_844);
		      }
		      {
			 obj_t list1607_849;
			 {
			    obj_t arg1608_850;
			    {
			       obj_t aux_2744;
			       aux_2744 = CDR(var_841);
			       arg1608_850 = MAKE_PAIR(aux_2744, BNIL);
			    }
			    list1607_849 = MAKE_PAIR(string1844_init_parse_args_215, arg1608_850);
			 }
			 print___r4_output_6_10_3(list1607_849);
		      }
		   }
		 else
		   {
		      obj_t arg1612_853;
		      arg1612_853 = CAR(var_841);
		      {
			 obj_t list1616_856;
			 {
			    obj_t arg1617_857;
			    {
			       obj_t arg1618_858;
			       {
				  obj_t arg1620_859;
				  {
				     obj_t aux_2750;
				     aux_2750 = CDR(var_841);
				     arg1620_859 = MAKE_PAIR(aux_2750, BNIL);
				  }
				  arg1618_858 = MAKE_PAIR(string1845_init_parse_args_215, arg1620_859);
			       }
			       arg1617_857 = MAKE_PAIR(arg1612_853, arg1618_858);
			    }
			    list1616_856 = MAKE_PAIR(string1843_init_parse_args_215, arg1617_857);
			 }
			 print___r4_output_6_10_3(list1616_856);
		      }
		   }
	      }
	      {
		 obj_t l1021_2757;
		 l1021_2757 = CDR(l1021_837);
		 l1021_837 = l1021_2757;
		 goto lname1022_838;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      newline___r4_output_6_10_3(BNIL);
      {
	 obj_t list1624_863;
	 list1624_863 = MAKE_PAIR(string1846_init_parse_args_215, BNIL);
	 print___r4_output_6_10_3(list1624_863);
      }
      {
	 obj_t list1628_866;
	 list1628_866 = MAKE_PAIR(string1847_init_parse_args_215, BNIL);
	 print___r4_output_6_10_3(list1628_866);
      }
      if (_fx_24___r4_numbers_6_5_fixnum(level_802, ((long) 1)))
	{
	   newline___r4_output_6_10_3(BNIL);
	   {
	      obj_t list1578_823;
	      list1578_823 = MAKE_PAIR(string1852_init_parse_args_215, BNIL);
	      print___r4_output_6_10_3(list1578_823);
	   }
	   bigloo_variables_usage_232_engine_param(manual__151_803);
	}
      else
	{
	   BUNSPEC;
	}
      if (CBOOL(_bigloo_licensing___64_engine_param))
	{
	   newline___r4_output_6_10_3(BNIL);
	   newline___r4_output_6_10_3(BNIL);
	   {
	      obj_t arg1584_828;
	      arg1584_828 = bigloo_license_175_tools_license();
	      {
		 obj_t list1585_829;
		 list1585_829 = MAKE_PAIR(arg1584_828, BNIL);
		 print___r4_output_6_10_3(list1585_829);
	      }
	   }
	}
      else
	{
	   BUNSPEC;
	}
      return exit_bigloo_229_init_main(BINT(((long) 0)));
   }
}


/* arg1219 */ obj_t 
arg1219_init_parse_args_215(obj_t env_1613)
{
   {
      obj_t rhandler1040_1617;
      obj_t escape_1618;
      rhandler1040_1617 = PROCEDURE_REF(env_1613, ((long) 3));
      escape_1618 = PROCEDURE_REF(env_1613, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1040_1617, escape_1618);
      }
   }
}


/* escape */ obj_t 
escape_init_parse_args_215(obj_t env_1619, obj_t val1045_1621)
{
   {
      obj_t an_exitd1044_1620;
      an_exitd1044_1620 = PROCEDURE_REF(env_1619, ((long) 0));
      {
	 obj_t val1045_92;
	 val1045_92 = val1045_1621;
	 return unwind_until__178___bexit(an_exitd1044_1620, val1045_92);
      }
   }
}


/* rhandler1040 */ obj_t 
rhandler1040_init_parse_args_215(obj_t env_1622, obj_t esc_1625, obj_t obj_1626, obj_t proc_1627, obj_t msg_1628)
{
   {
      obj_t armed1042_1623;
      obj_t arg1032_1624;
      armed1042_1623 = PROCEDURE_REF(env_1622, ((long) 0));
      arg1032_1624 = PROCEDURE_REF(env_1622, ((long) 1));
      {
	 obj_t esc_106;
	 obj_t obj_107;
	 obj_t proc_108;
	 obj_t msg_109;
	 esc_106 = esc_1625;
	 obj_107 = obj_1626;
	 proc_108 = proc_1627;
	 msg_109 = msg_1628;
	 {
	    obj_t culprit_798;
	    CELL_SET(armed1042_1623, BFALSE);
	    remove_error_handler__102___error();
	    culprit_798 = CELL_REF(arg1032_1624);
	    FAILURE(string1720_init_parse_args_215, string1721_init_parse_args_215, culprit_798);
	 }
      }
   }
}


/* args-parse-usage */ obj_t 
args_parse_usage_117_init_parse_args_215(obj_t env_1630, obj_t manual__151_1631)
{
   {
      obj_t manual__151_753;
      manual__151_753 = manual__151_1631;
      {
	 obj_t descrs_755;
	 descrs_755 = reverse__39___r4_pairs_and_lists_6_3(CNST_TABLE_REF(((long) 43)));
	 {
	    obj_t l1037_756;
	    l1037_756 = descrs_755;
	  lname1038_757:
	    if (PAIRP(l1037_756))
	      {
		 {
		    obj_t opt_759;
		    opt_759 = CAR(l1037_756);
		    {
		       obj_t name_760;
		       name_760 = CAR(opt_759);
		       if (STRINGP(name_760))
			 {
			    {
			       obj_t desc_764;
			       desc_764 = CDR(opt_759);
			       {
				  obj_t tab_765;
				  {
				     long arg1539_784;
				     {
					long aux_2798;
					aux_2798 = STRING_LENGTH(name_760);
					arg1539_784 = (((long) 23) - aux_2798);
				     }
				     {
					obj_t list1540_785;
					{
					   obj_t aux_2801;
					   aux_2801 = BCHAR(((unsigned char) ' '));
					   list1540_785 = MAKE_PAIR(aux_2801, BNIL);
					}
					{
					   obj_t res1712_1544;
					   {
					      unsigned char aux_2808;
					      long aux_2804;
					      {
						 obj_t aux_2809;
						 aux_2809 = CAR(list1540_785);
						 aux_2808 = (unsigned char) CCHAR(aux_2809);
					      }
					      {
						 int aux_2805;
						 aux_2805 = (int) (arg1539_784);
						 aux_2804 = (long) (aux_2805);
					      }
					      res1712_1544 = make_string(aux_2804, aux_2808);
					   }
					   tab_765 = res1712_1544;
					}
				     }
				  }
				  {
				     if (CBOOL(manual__151_753))
				       {
					  {
					     obj_t list1517_766;
					     {
						obj_t arg1519_768;
						{
						   obj_t arg1522_769;
						   arg1522_769 = MAKE_PAIR(string1853_init_parse_args_215, BNIL);
						   arg1519_768 = MAKE_PAIR(name_760, arg1522_769);
						}
						list1517_766 = MAKE_PAIR(string1854_init_parse_args_215, arg1519_768);
					     }
					     print___r4_output_6_10_3(list1517_766);
					  }
					  {
					     obj_t list1526_772;
					     {
						obj_t arg1528_774;
						arg1528_774 = MAKE_PAIR(desc_764, BNIL);
						list1526_772 = MAKE_PAIR(string1855_init_parse_args_215, arg1528_774);
					     }
					     print___r4_output_6_10_3(list1526_772);
					  }
				       }
				     else
				       {
					  obj_t list1530_776;
					  {
					     obj_t arg1532_778;
					     {
						obj_t arg1533_779;
						{
						   obj_t arg1534_780;
						   {
						      obj_t arg1536_782;
						      arg1536_782 = MAKE_PAIR(desc_764, BNIL);
						      arg1534_780 = MAKE_PAIR(string1856_init_parse_args_215, arg1536_782);
						   }
						   arg1533_779 = MAKE_PAIR(tab_765, arg1534_780);
						}
						arg1532_778 = MAKE_PAIR(name_760, arg1533_779);
					     }
					     list1530_776 = MAKE_PAIR(string1854_init_parse_args_215, arg1532_778);
					  }
					  print___r4_output_6_10_3(list1530_776);
				       }
				  }
			       }
			    }
			 }
		       else
			 {
			    bool_t test_2828;
			    {
			       obj_t aux_2829;
			       aux_2829 = CNST_TABLE_REF(((long) 44));
			       test_2828 = (name_760 == aux_2829);
			    }
			    if (test_2828)
			      {
				 {
				    obj_t arg1545_788;
				    arg1545_788 = CDR(opt_759);
				    {
				       obj_t list1549_790;
				       {
					  obj_t arg1550_791;
					  {
					     obj_t arg1552_792;
					     arg1552_792 = MAKE_PAIR(string1853_init_parse_args_215, BNIL);
					     arg1550_791 = MAKE_PAIR(arg1545_788, arg1552_792);
					  }
					  {
					     obj_t aux_2835;
					     aux_2835 = BCHAR(((unsigned char) '\n'));
					     list1549_790 = MAKE_PAIR(aux_2835, arg1550_791);
					  }
				       }
				       print___r4_output_6_10_3(list1549_790);
				    }
				 }
			      }
			    else
			      {
				 BFALSE;
			      }
			 }
		    }
		 }
		 {
		    obj_t l1037_2839;
		    l1037_2839 = CDR(l1037_756);
		    l1037_756 = l1037_2839;
		    goto lname1038_757;
		 }
	      }
	    else
	      {
		 ((bool_t) 1);
	      }
	 }
	 return CNST_TABLE_REF(((long) 1));
      }
   }
}


/* parse-shape-args */ obj_t 
parse_shape_args_80_init_parse_args_215(obj_t string_3)
{
   {
      long len_871;
      len_871 = STRING_LENGTH(string_3);
      if ((len_871 == ((long) 0)))
	{
	   _module_shape___145_engine_param = BTRUE;
	   _key_shape___172_engine_param = BTRUE;
	   _type_shape___78_engine_param = BTRUE;
	   _access_shape___50_engine_param = BTRUE;
	   _location_shape___48_engine_param = BTRUE;
	   return (_user_shape___227_engine_param = BTRUE,
	      BUNSPEC);
	}
      else
	{
	   long i_873;
	   i_873 = ((long) 0);
	 liip_874:
	   if ((i_873 == len_871))
	     {
		return CNST_TABLE_REF(((long) 7));
	     }
	   else
	     {
		{
		   switch (STRING_REF(string_3, i_873))
		     {
		     case ((unsigned char) 'm'):
			_module_shape___145_engine_param = BTRUE;
			break;
		     case ((unsigned char) 'k'):
			_key_shape___172_engine_param = BTRUE;
			break;
		     case ((unsigned char) 't'):
			_type_shape___78_engine_param = BTRUE;
			break;
		     case ((unsigned char) 'a'):
			_access_shape___50_engine_param = BTRUE;
			break;
		     case ((unsigned char) 'l'):
			_location_shape___48_engine_param = BTRUE;
			break;
		     case ((unsigned char) 'u'):
			_user_shape___227_engine_param = BTRUE;
			break;
		     default:
			FAILURE(string1857_init_parse_args_215, string1858_init_parse_args_215, string_3);
		     }
		}
		{
		   long i_2851;
		   i_2851 = (i_873 + ((long) 1));
		   i_873 = i_2851;
		   goto liip_874;
		}
	     }
	}
   }
}


/* parse-unsafe-args */ obj_t 
parse_unsafe_args_57_init_parse_args_215(obj_t string_4)
{
   {
      long len_880;
      len_880 = STRING_LENGTH(string_4);
      if ((len_880 == ((long) 0)))
	{
	   _unsafe_library__118_engine_param = BTRUE;
	   _unsafe_arity__240_engine_param = BTRUE;
	   _unsafe_type__146_engine_param = BTRUE;
	   _unsafe_struct__195_engine_param = BTRUE;
	   _unsafe_range__218_engine_param = BTRUE;
	   return (_unsafe_version__81_engine_param = BTRUE,
	      BUNSPEC);
	}
      else
	{
	   long i_882;
	   i_882 = ((long) 0);
	 liip_883:
	   if ((i_882 == len_880))
	     {
		return CNST_TABLE_REF(((long) 7));
	     }
	   else
	     {
		{
		   switch (STRING_REF(string_4, i_882))
		     {
		     case ((unsigned char) 'r'):
			_unsafe_range__218_engine_param = BTRUE;
			break;
		     case ((unsigned char) 'a'):
			_unsafe_arity__240_engine_param = BTRUE;
			break;
		     case ((unsigned char) 't'):
			_unsafe_type__146_engine_param = BTRUE;
			break;
		     case ((unsigned char) 's'):
			_unsafe_struct__195_engine_param = BTRUE;
			break;
		     case ((unsigned char) 'v'):
			_unsafe_version__81_engine_param = BTRUE;
			break;
		     case ((unsigned char) 'l'):
			_unsafe_library__118_engine_param = BTRUE;
			break;
		     default:
			FAILURE(string1857_init_parse_args_215, string1859_init_parse_args_215, string_4);
		     }
		}
		{
		   long i_2862;
		   i_2862 = (i_882 + ((long) 1));
		   i_882 = i_2862;
		   goto liip_883;
		}
	     }
	}
   }
}


/* parse-optim-args */ obj_t 
parse_optim_args_175_init_parse_args_215(obj_t string_5)
{
   _optim__89_engine_param = BINT(((long) 1));
   if (_fx_24___r4_numbers_6_5_fixnum(STRING_LENGTH(string_5), ((long) 0)))
     {
	switch (STRING_REF(string_5, ((long) 0)))
	  {
	  case ((unsigned char) '2'):
	     _o2__218_init_parse_args_215();
	     return (_optim__89_engine_param = BINT(((long) 2)),
		BUNSPEC);
	     break;
	  case ((unsigned char) '3'):
	     _o3__35_init_parse_args_215();
	     return (_optim__89_engine_param = BINT(((long) 3)),
		BUNSPEC);
	     break;
	  case ((unsigned char) '4'):
	  case ((unsigned char) '5'):
	  case ((unsigned char) '6'):
	     _o3__35_init_parse_args_215();
	     {
		long aux_2873;
		{
		   long aux_2878;
		   long aux_2874;
		   aux_2878 = (((unsigned char) '0'));
		   {
		      unsigned char aux_2875;
		      aux_2875 = STRING_REF(string_5, ((long) 0));
		      aux_2874 = (aux_2875);
		   }
		   aux_2873 = (aux_2874 - aux_2878);
		}
		return (_optim__89_engine_param = BINT(aux_2873),
		   BUNSPEC);
	     }
	     break;
	  default:
	     FAILURE(string1857_init_parse_args_215, string1860_init_parse_args_215, string_5);
	  }
     }
   else
     {
	if (CBOOL(_c_debug__136_engine_param))
	  {
	     return BUNSPEC;
	  }
	else
	  {
	     return (_cc_options__252_engine_param = string_append(_cc_options__252_engine_param, string1861_init_parse_args_215),
		BUNSPEC);
	  }
     }
}


/* -o2! */ obj_t 
_o2__218_init_parse_args_215()
{
   if (CBOOL(_c_debug__136_engine_param))
     {
	BUNSPEC;
     }
   else
     {
	_cc_options__252_engine_param = string_append(_cc_options__252_engine_param, string1862_init_parse_args_215);
     }
   return CNST_TABLE_REF(((long) 45));
}


/* -o3! */ obj_t 
_o3__35_init_parse_args_215()
{
   _o2__218_init_parse_args_215();
   {
      bool_t test1651_901;
      {
	 obj_t obj_1595;
	 obj_1595 = _optim_inline_method___30_engine_param;
	 test1651_901 = BOOLEANP(obj_1595);
      }
      if (test1651_901)
	{
	   BUNSPEC;
	}
      else
	{
	   _optim_inline_method___30_engine_param = BTRUE;
	}
   }
   {
      bool_t test1652_902;
      {
	 obj_t obj_1596;
	 obj_1596 = _optim_unroll_loop___80_engine_param;
	 test1652_902 = BOOLEANP(obj_1596);
      }
      if (test1652_902)
	{
	   return BUNSPEC;
	}
      else
	{
	   return (_optim_unroll_loop___80_engine_param = BTRUE,
	      BUNSPEC);
	}
   }
}


/* query */ obj_t 
query_init_parse_args_215()
{
   version_write_version();
   newline___r4_output_6_10_3(BNIL);
   {
      obj_t list1655_907;
      list1655_907 = MAKE_PAIR(string1863_init_parse_args_215, BNIL);
      print___r4_output_6_10_3(list1655_907);
   }
   newline___r4_output_6_10_3(BNIL);
   {
      obj_t list1659_911;
      {
	 obj_t arg1663_913;
	 arg1663_913 = MAKE_PAIR(_cc__215_engine_param, BNIL);
	 list1659_911 = MAKE_PAIR(string1864_init_parse_args_215, arg1663_913);
      }
      print___r4_output_6_10_3(list1659_911);
   }
   {
      obj_t list1666_915;
      {
	 obj_t arg1668_917;
	 arg1668_917 = MAKE_PAIR(_cc_options__252_engine_param, BNIL);
	 list1666_915 = MAKE_PAIR(string1865_init_parse_args_215, arg1668_917);
      }
      print___r4_output_6_10_3(list1666_915);
   }
   {
      obj_t list1670_919;
      {
	 obj_t arg1673_921;
	 arg1673_921 = MAKE_PAIR(_ld_options__88_engine_param, BNIL);
	 list1670_919 = MAKE_PAIR(string1866_init_parse_args_215, arg1673_921);
      }
      print___r4_output_6_10_3(list1670_919);
   }
   {
      obj_t list1676_923;
      {
	 obj_t arg1678_925;
	 arg1678_925 = MAKE_PAIR(_bigloo_lib__121_engine_param, BNIL);
	 list1676_923 = MAKE_PAIR(string1867_init_parse_args_215, arg1678_925);
      }
      print___r4_output_6_10_3(list1676_923);
   }
   {
      obj_t list1680_927;
      {
	 obj_t arg1682_929;
	 arg1682_929 = MAKE_PAIR(_bigloo_user_lib__33_engine_param, BNIL);
	 list1680_927 = MAKE_PAIR(string1868_init_parse_args_215, arg1682_929);
      }
      print___r4_output_6_10_3(list1680_927);
   }
   {
      obj_t list1684_931;
      {
	 obj_t arg1686_933;
	 arg1686_933 = MAKE_PAIR(_default_lib_dir__128_engine_param, BNIL);
	 list1684_931 = MAKE_PAIR(string1869_init_parse_args_215, arg1686_933);
      }
      print___r4_output_6_10_3(list1684_931);
   }
   {
      obj_t list1689_935;
      {
	 obj_t arg1692_937;
	 arg1692_937 = MAKE_PAIR(_lib_dir__34_engine_param, BNIL);
	 list1689_935 = MAKE_PAIR(string1870_init_parse_args_215, arg1692_937);
      }
      print___r4_output_6_10_3(list1689_935);
   }
   {
      obj_t list1694_939;
      {
	 obj_t arg1697_941;
	 arg1697_941 = MAKE_PAIR(_include_foreign__253_engine_param, BNIL);
	 list1694_939 = MAKE_PAIR(string1871_init_parse_args_215, arg1697_941);
      }
      print___r4_output_6_10_3(list1694_939);
   }
   {
      obj_t list1699_943;
      {
	 obj_t arg1701_945;
	 arg1701_945 = MAKE_PAIR(_heap_name__135_engine_param, BNIL);
	 list1699_943 = MAKE_PAIR(string1872_init_parse_args_215, arg1701_945);
      }
      print___r4_output_6_10_3(list1699_943);
   }
   newline___r4_output_6_10_3(BNIL);
   {
      obj_t list1704_948;
      list1704_948 = MAKE_PAIR(string1873_init_parse_args_215, BNIL);
      print___r4_output_6_10_3(list1704_948);
   }
   {
      obj_t list1707_951;
      list1707_951 = MAKE_PAIR(string1874_init_parse_args_215, BNIL);
      print___r4_output_6_10_3(list1707_951);
   }
   return exit_bigloo_229_init_main(BINT(((long) 0)));
}


/* method-init */ obj_t 
method_init_76_init_parse_args_215()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_init_parse_args_215()
{
   module_initialization_70_tools_trace(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70_engine_param(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70_init_main(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70_init_extend(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70_init_setrc(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70_module_module(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70_module_alibrary(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70_write_version(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70_tools_speek(((long) 0), "INIT_PARSE-ARGS");
   module_initialization_70_tools_license(((long) 0), "INIT_PARSE-ARGS");
   return module_initialization_70_read_access(((long) 0), "INIT_PARSE-ARGS");
}
