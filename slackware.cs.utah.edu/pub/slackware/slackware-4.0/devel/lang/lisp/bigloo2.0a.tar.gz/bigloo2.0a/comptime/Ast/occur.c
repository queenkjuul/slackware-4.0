/*===========================================================================*/
/*   (Ast/occur.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_ast_occur();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t pragma_ast_node;
static obj_t _occur_node_in_1684_187_ast_occur(obj_t, obj_t, obj_t);
extern obj_t set_ex_it_116_ast_node;
static obj_t _occur_node_1685_123_ast_occur(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_ast_occur(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t scnst_ast_var;
extern obj_t node_ast_node;
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_ast_occur();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t _global__68_ast_occur = BUNSPEC;
extern obj_t app_ast_node;
static obj_t _occur_node__default1462_91_ast_occur(obj_t, obj_t);
static obj_t library_modules_init_112_ast_occur();
extern obj_t occur_var_108_ast_occur(obj_t);
extern obj_t occur_node_in__115_ast_occur(node_t, global_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_ast_occur();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static bool_t occur_node___69_ast_occur(obj_t);
static obj_t arg1483_ast_occur(obj_t, obj_t);
extern obj_t for_each_global__88_ast_env(obj_t);
static obj_t occur_node__249_ast_occur(node_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t _occur_var_46_ast_occur(obj_t, obj_t);
static obj_t require_initialization_114_ast_occur = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_ast_occur();
static obj_t occur_node__default1462_48_ast_occur(node_t);
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(occur_node_in__env_172_ast_occur, _occur_node_in_1684_187_ast_occur1693, _occur_node_in_1684_187_ast_occur, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1686_ast_occur, arg1483_ast_occur1694, arg1483_ast_occur, 0L, 1);
DEFINE_STATIC_PROCEDURE(occur_node__default1462_env_164_ast_occur, _occur_node__default1462_91_ast_occur1695, _occur_node__default1462_91_ast_occur, 0L, 1);
DEFINE_STATIC_GENERIC(occur_node__env_215_ast_occur, _occur_node_1685_123_ast_occur1696, _occur_node_1685_123_ast_occur, 0L, 1);
DEFINE_EXPORT_PROCEDURE(occur_var_env_26_ast_occur, _occur_var_46_ast_occur1697, _occur_var_46_ast_occur, 0L, 1);
DEFINE_STRING(string1687_ast_occur, string1687_ast_occur1698, "DONE ", 5);


/* module-initialization */ obj_t 
module_initialization_70_ast_occur(long checksum_1324, char *from_1325)
{
   if (CBOOL(require_initialization_114_ast_occur))
     {
	require_initialization_114_ast_occur = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_occur();
	cnst_init_137_ast_occur();
	imported_modules_init_94_ast_occur();
	method_init_76_ast_occur();
	toplevel_init_63_ast_occur();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_occur()
{
   module_initialization_70___object(((long) 0), "AST_OCCUR");
   module_initialization_70___reader(((long) 0), "AST_OCCUR");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_occur()
{
   {
      obj_t cnst_port_138_1316;
      cnst_port_138_1316 = open_input_string(string1687_ast_occur);
      {
	 long i_1317;
	 i_1317 = ((long) 0);
       loop_1318:
	 {
	    bool_t test1688_1319;
	    test1688_1319 = (i_1317 == ((long) -1));
	    if (test1688_1319)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1689_1320;
		    {
		       obj_t list1690_1321;
		       {
			  obj_t arg1691_1322;
			  arg1691_1322 = BNIL;
			  list1690_1321 = MAKE_PAIR(cnst_port_138_1316, arg1691_1322);
		       }
		       arg1689_1320 = read___reader(list1690_1321);
		    }
		    CNST_TABLE_SET(i_1317, arg1689_1320);
		 }
		 {
		    int aux_1323;
		    {
		       long aux_1342;
		       aux_1342 = (i_1317 - ((long) 1));
		       aux_1323 = (int) (aux_1342);
		    }
		    {
		       long i_1345;
		       i_1345 = (long) (aux_1323);
		       i_1317 = i_1345;
		       goto loop_1318;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_occur()
{
   _global__68_ast_occur = BUNSPEC;
   return BUNSPEC;
}


/* occur-var */ obj_t 
occur_var_108_ast_occur(obj_t globals_1)
{
   {
      obj_t arg1483_1304;
      arg1483_1304 = proc1686_ast_occur;
      for_each_global__88_ast_env(arg1483_1304);
   }
   {
      obj_t l1435_720;
      {
	 bool_t aux_1348;
	 l1435_720 = globals_1;
       lname1436_721:
	 if (PAIRP(l1435_720))
	   {
	      {
		 obj_t global_723;
		 global_723 = CAR(l1435_720);
		 {
		    global_t aux_1352;
		    aux_1352 = (global_t) (global_723);
		    _global__68_ast_occur = (obj_t) (aux_1352);
		 }
		 {
		    node_t aux_1355;
		    {
		       obj_t aux_1356;
		       {
			  sfun_t obj_1190;
			  {
			     value_t aux_1357;
			     {
				global_t obj_1189;
				obj_1189 = (global_t) (global_723);
				aux_1357 = (((global_t) CREF(obj_1189))->value);
			     }
			     obj_1190 = (sfun_t) (aux_1357);
			  }
			  aux_1356 = (((sfun_t) CREF(obj_1190))->body);
		       }
		       aux_1355 = (node_t) (aux_1356);
		    }
		    occur_node__249_ast_occur(aux_1355);
		 }
	      }
	      {
		 obj_t l1435_1364;
		 l1435_1364 = CDR(l1435_720);
		 l1435_720 = l1435_1364;
		 goto lname1436_721;
	      }
	   }
	 else
	   {
	      aux_1348 = ((bool_t) 1);
	   }
	 return BBOOL(aux_1348);
      }
   }
}


/* _occur-var */ obj_t 
_occur_var_46_ast_occur(obj_t env_1305, obj_t globals_1306)
{
   return occur_var_108_ast_occur(globals_1306);
}


/* arg1483 */ obj_t 
arg1483_ast_occur(obj_t env_1307, obj_t global_1308)
{
   {
      obj_t global_717;
      global_717 = global_1308;
      {
	 global_t obj_1185;
	 obj_1185 = (global_t) (global_717);
	 return ((((global_t) CREF(obj_1185))->occurrence) = ((long) ((long) 0)), BUNSPEC);
      }
   }
}


/* occur-node-in! */ obj_t 
occur_node_in__115_ast_occur(node_t node_2, global_t global_3)
{
   _global__68_ast_occur = (obj_t) (global_3);
   return occur_node__249_ast_occur(node_2);
}


/* _occur-node-in!1684 */ obj_t 
_occur_node_in_1684_187_ast_occur(obj_t env_1309, obj_t node_1310, obj_t global_1311)
{
   return occur_node_in__115_ast_occur((node_t) (node_1310), (global_t) (global_1311));
}


/* occur-node*! */ bool_t 
occur_node___69_ast_occur(obj_t node__221_24)
{
   {
      obj_t l1459_727;
      l1459_727 = node__221_24;
    lname1460_728:
      if (PAIRP(l1459_727))
	{
	   {
	      node_t aux_1377;
	      {
		 obj_t aux_1378;
		 aux_1378 = CAR(l1459_727);
		 aux_1377 = (node_t) (aux_1378);
	      }
	      occur_node__249_ast_occur(aux_1377);
	   }
	   {
	      obj_t l1459_1382;
	      l1459_1382 = CDR(l1459_727);
	      l1459_727 = l1459_1382;
	      goto lname1460_728;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* method-init */ obj_t 
method_init_76_ast_occur()
{
   add_generic__110___object(occur_node__env_215_ast_occur, occur_node__default1462_env_164_ast_occur);
   add_inlined_method__244___object(occur_node__env_215_ast_occur, var_ast_node, ((long) 0));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, sequence_ast_node, ((long) 1));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, app_ast_node, ((long) 2));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, app_ly_162_ast_node, ((long) 3));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, funcall_ast_node, ((long) 4));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, pragma_ast_node, ((long) 5));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, cast_ast_node, ((long) 6));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, setq_ast_node, ((long) 7));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, conditional_ast_node, ((long) 8));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, fail_ast_node, ((long) 9));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, select_ast_node, ((long) 10));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, let_fun_218_ast_node, ((long) 11));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, let_var_6_ast_node, ((long) 12));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, set_ex_it_116_ast_node, ((long) 13));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, jump_ex_it_184_ast_node, ((long) 14));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, make_box_202_ast_node, ((long) 15));
   add_inlined_method__244___object(occur_node__env_215_ast_occur, box_ref_242_ast_node, ((long) 16));
   {
      long aux_1402;
      aux_1402 = add_inlined_method__244___object(occur_node__env_215_ast_occur, box_set__221_ast_node, ((long) 17));
      return BINT(aux_1402);
   }
}


/* occur-node! */ obj_t 
occur_node__249_ast_occur(node_t node_4)
{
 occur_node__249_ast_occur:
   {
      obj_t method1587_1061;
      obj_t class1592_1062;
      {
	 obj_t arg1595_1059;
	 obj_t arg1598_1060;
	 {
	    object_t obj_1197;
	    obj_1197 = (object_t) (node_4);
	    {
	       obj_t pre_method_105_1198;
	       pre_method_105_1198 = PROCEDURE_REF(occur_node__env_215_ast_occur, ((long) 2));
	       if (INTEGERP(pre_method_105_1198))
		 {
		    PROCEDURE_SET(occur_node__env_215_ast_occur, ((long) 2), BUNSPEC);
		    arg1595_1059 = pre_method_105_1198;
		 }
	       else
		 {
		    long obj_class_num_177_1203;
		    obj_class_num_177_1203 = TYPE(obj_1197);
		    {
		       obj_t arg1177_1204;
		       arg1177_1204 = PROCEDURE_REF(occur_node__env_215_ast_occur, ((long) 1));
		       {
			  long arg1178_1208;
			  {
			     long arg1179_1209;
			     arg1179_1209 = OBJECT_TYPE;
			     arg1178_1208 = (obj_class_num_177_1203 - arg1179_1209);
			  }
			  arg1595_1059 = VECTOR_REF(arg1177_1204, arg1178_1208);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1214;
	    object_1214 = (object_t) (node_4);
	    {
	       long arg1180_1215;
	       {
		  long arg1181_1216;
		  long arg1182_1217;
		  arg1181_1216 = TYPE(object_1214);
		  arg1182_1217 = OBJECT_TYPE;
		  arg1180_1215 = (arg1181_1216 - arg1182_1217);
	       }
	       {
		  obj_t vector_1221;
		  vector_1221 = _classes__134___object;
		  arg1598_1060 = VECTOR_REF(vector_1221, arg1180_1215);
	       }
	    }
	 }
	 method1587_1061 = arg1595_1059;
	 class1592_1062 = arg1598_1060;
	 {
	    if (INTEGERP(method1587_1061))
	      {
		 switch ((long) CINT(method1587_1061))
		   {
		   case ((long) 0):
		      {
			 var_t node_1068;
			 node_1068 = (var_t) (node_4);
			 {
			    variable_t v_1069;
			    v_1069 = (((var_t) CREF(node_1068))->variable);
			    {
			       value_t value_1070;
			       value_1070 = (((variable_t) CREF(v_1069))->value);
			       {
				  bool_t test1601_1071;
				  {
				     bool_t test1603_1073;
				     test1603_1073 = is_a__118___object((obj_t) (value_1070), scnst_ast_var);
				     if (test1603_1073)
				       {
					  obj_t aux_1428;
					  {
					     scnst_t obj_1226;
					     obj_1226 = (scnst_t) (value_1070);
					     aux_1428 = (((scnst_t) CREF(obj_1226))->node);
					  }
					  test1601_1071 = is_a__118___object(aux_1428, node_ast_node);
				       }
				     else
				       {
					  test1601_1071 = ((bool_t) 0);
				       }
				  }
				  if (test1601_1071)
				    {
				       node_t aux_1433;
				       {
					  obj_t aux_1434;
					  {
					     scnst_t obj_1228;
					     obj_1228 = (scnst_t) (value_1070);
					     aux_1434 = (((scnst_t) CREF(obj_1228))->node);
					  }
					  aux_1433 = (node_t) (aux_1434);
				       }
				       occur_node__249_ast_occur(aux_1433);
				    }
				  else
				    {
				       BUNSPEC;
				    }
			       }
			    }
			    {
			       bool_t test1606_1075;
			       {
				  obj_t obj2_1230;
				  obj2_1230 = _global__68_ast_occur;
				  {
				     obj_t aux_1439;
				     aux_1439 = (obj_t) (v_1069);
				     test1606_1075 = (aux_1439 == obj2_1230);
				  }
			       }
			       if (test1606_1075)
				 {
				    return BUNSPEC;
				 }
			       else
				 {
				    long arg1607_1076;
				    {
				       long aux_1443;
				       aux_1443 = (((variable_t) CREF(v_1069))->occurrence);
				       arg1607_1076 = (aux_1443 + ((long) 1));
				    }
				    return ((((variable_t) CREF(v_1069))->occurrence) = ((long) arg1607_1076), BUNSPEC);
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 sequence_t node_1079;
			 node_1079 = (sequence_t) (node_4);
			 {
			    bool_t aux_1448;
			    aux_1448 = occur_node___69_ast_occur((((sequence_t) CREF(node_1079))->nodes));
			    return BBOOL(aux_1448);
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 app_t node_1081;
			 node_1081 = (app_t) (node_4);
			 {
			    node_t aux_1453;
			    {
			       var_t aux_1454;
			       aux_1454 = (((app_t) CREF(node_1081))->fun);
			       aux_1453 = (node_t) (aux_1454);
			    }
			    occur_node__249_ast_occur(aux_1453);
			 }
			 {
			    bool_t aux_1458;
			    aux_1458 = occur_node___69_ast_occur((((app_t) CREF(node_1081))->args));
			    return BBOOL(aux_1458);
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 app_ly_162_t node_1085;
			 node_1085 = (app_ly_162_t) (node_4);
			 occur_node__249_ast_occur((((app_ly_162_t) CREF(node_1085))->fun));
			 {
			    node_t node_1465;
			    node_1465 = (((app_ly_162_t) CREF(node_1085))->arg);
			    node_4 = node_1465;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 funcall_t node_1089;
			 node_1089 = (funcall_t) (node_4);
			 occur_node__249_ast_occur((((funcall_t) CREF(node_1089))->fun));
			 {
			    bool_t aux_1470;
			    aux_1470 = occur_node___69_ast_occur((((funcall_t) CREF(node_1089))->args));
			    return BBOOL(aux_1470);
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 pragma_t node_1093;
			 node_1093 = (pragma_t) (node_4);
			 {
			    bool_t aux_1475;
			    aux_1475 = occur_node___69_ast_occur((((pragma_t) CREF(node_1093))->args));
			    return BBOOL(aux_1475);
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 cast_t node_1095;
			 node_1095 = (cast_t) (node_4);
			 {
			    node_t node_1480;
			    node_1480 = (((cast_t) CREF(node_1095))->arg);
			    node_4 = node_1480;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 setq_t node_1097;
			 node_1097 = (setq_t) (node_4);
			 {
			    node_t aux_1483;
			    {
			       var_t aux_1484;
			       aux_1484 = (((setq_t) CREF(node_1097))->var);
			       aux_1483 = (node_t) (aux_1484);
			    }
			    occur_node__249_ast_occur(aux_1483);
			 }
			 {
			    node_t node_1488;
			    node_1488 = (((setq_t) CREF(node_1097))->value);
			    node_4 = node_1488;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 conditional_t node_1101;
			 node_1101 = (conditional_t) (node_4);
			 occur_node__249_ast_occur((((conditional_t) CREF(node_1101))->test));
			 occur_node__249_ast_occur((((conditional_t) CREF(node_1101))->true));
			 {
			    node_t node_1495;
			    node_1495 = (((conditional_t) CREF(node_1101))->false);
			    node_4 = node_1495;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 fail_t node_1106;
			 node_1106 = (fail_t) (node_4);
			 occur_node__249_ast_occur((((fail_t) CREF(node_1106))->proc));
			 occur_node__249_ast_occur((((fail_t) CREF(node_1106))->msg));
			 {
			    node_t node_1502;
			    node_1502 = (((fail_t) CREF(node_1106))->obj);
			    node_4 = node_1502;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 select_t node_1111;
			 node_1111 = (select_t) (node_4);
			 occur_node__249_ast_occur((((select_t) CREF(node_1111))->test));
			 {
			    obj_t l1444_1114;
			    {
			       bool_t aux_1507;
			       l1444_1114 = (((select_t) CREF(node_1111))->clauses);
			     lname1445_1115:
			       if (PAIRP(l1444_1114))
				 {
				    {
				       node_t aux_1510;
				       {
					  obj_t aux_1511;
					  {
					     obj_t aux_1512;
					     aux_1512 = CAR(l1444_1114);
					     aux_1511 = CDR(aux_1512);
					  }
					  aux_1510 = (node_t) (aux_1511);
				       }
				       occur_node__249_ast_occur(aux_1510);
				    }
				    {
				       obj_t l1444_1517;
				       l1444_1517 = CDR(l1444_1114);
				       l1444_1114 = l1444_1517;
				       goto lname1445_1115;
				    }
				 }
			       else
				 {
				    aux_1507 = ((bool_t) 1);
				 }
			       return BBOOL(aux_1507);
			    }
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 let_fun_218_t node_1121;
			 node_1121 = (let_fun_218_t) (node_4);
			 {
			    obj_t l1447_1123;
			    l1447_1123 = (((let_fun_218_t) CREF(node_1121))->locals);
			  lname1448_1124:
			    if (PAIRP(l1447_1123))
			      {
				 {
				    obj_t local_1127;
				    local_1127 = CAR(l1447_1123);
				    {
				       local_t obj_1262;
				       obj_1262 = (local_t) (local_1127);
				       ((((local_t) CREF(obj_1262))->occurrence) = ((long) ((long) 0)), BUNSPEC);
				    }
				    {
				       obj_t l1449_1128;
				       {
					  sfun_t obj_1265;
					  {
					     value_t aux_1535;
					     {
						local_t obj_1264;
						obj_1264 = (local_t) (local_1127);
						aux_1535 = (((local_t) CREF(obj_1264))->value);
					     }
					     obj_1265 = (sfun_t) (aux_1535);
					  }
					  l1449_1128 = (((sfun_t) CREF(obj_1265))->args);
				       }
				     lname1450_1129:
				       if (PAIRP(l1449_1128))
					 {
					    {
					       local_t obj_1268;
					       {
						  obj_t aux_1529;
						  aux_1529 = CAR(l1449_1128);
						  obj_1268 = (local_t) (aux_1529);
					       }
					       ((((local_t) CREF(obj_1268))->occurrence) = ((long) ((long) 1)), BUNSPEC);
					    }
					    {
					       obj_t l1449_1533;
					       l1449_1533 = CDR(l1449_1128);
					       l1449_1128 = l1449_1533;
					       goto lname1450_1129;
					    }
					 }
				       else
					 {
					    ((bool_t) 1);
					 }
				    }
				 }
				 {
				    obj_t l1447_1540;
				    l1447_1540 = CDR(l1447_1123);
				    l1447_1123 = l1447_1540;
				    goto lname1448_1124;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    obj_t l1451_1136;
			    l1451_1136 = (((let_fun_218_t) CREF(node_1121))->locals);
			  lname1452_1137:
			    if (PAIRP(l1451_1136))
			      {
				 {
				    obj_t local_1140;
				    local_1140 = CAR(l1451_1136);
				    {
				       long old_1141;
				       {
					  local_t obj_1275;
					  obj_1275 = (local_t) (local_1140);
					  old_1141 = (((local_t) CREF(obj_1275))->occurrence);
				       }
				       {
					  node_t aux_1548;
					  {
					     obj_t aux_1549;
					     {
						sfun_t obj_1277;
						{
						   value_t aux_1550;
						   {
						      local_t obj_1276;
						      obj_1276 = (local_t) (local_1140);
						      aux_1550 = (((local_t) CREF(obj_1276))->value);
						   }
						   obj_1277 = (sfun_t) (aux_1550);
						}
						aux_1549 = (((sfun_t) CREF(obj_1277))->body);
					     }
					     aux_1548 = (node_t) (aux_1549);
					  }
					  occur_node__249_ast_occur(aux_1548);
				       }
				       {
					  local_t obj_1278;
					  obj_1278 = (local_t) (local_1140);
					  ((((local_t) CREF(obj_1278))->occurrence) = ((long) old_1141), BUNSPEC);
				       }
				    }
				 }
				 {
				    obj_t l1451_1559;
				    l1451_1559 = CDR(l1451_1136);
				    l1451_1136 = l1451_1559;
				    goto lname1452_1137;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1562;
			    node_1562 = (((let_fun_218_t) CREF(node_1121))->body);
			    node_4 = node_1562;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 let_var_6_t node_1146;
			 node_1146 = (let_var_6_t) (node_4);
			 {
			    obj_t l1454_1148;
			    l1454_1148 = (((let_var_6_t) CREF(node_1146))->bindings);
			  lname1455_1149:
			    if (PAIRP(l1454_1148))
			      {
				 {
				    obj_t binding_1152;
				    binding_1152 = CAR(l1454_1148);
				    {
				       local_t obj_1286;
				       {
					  obj_t aux_1568;
					  aux_1568 = CAR(binding_1152);
					  obj_1286 = (local_t) (aux_1568);
				       }
				       ((((local_t) CREF(obj_1286))->occurrence) = ((long) ((long) 0)), BUNSPEC);
				    }
				    {
				       node_t aux_1572;
				       {
					  obj_t aux_1573;
					  aux_1573 = CDR(binding_1152);
					  aux_1572 = (node_t) (aux_1573);
				       }
				       occur_node__249_ast_occur(aux_1572);
				    }
				 }
				 {
				    obj_t l1454_1577;
				    l1454_1577 = CDR(l1454_1148);
				    l1454_1148 = l1454_1577;
				    goto lname1455_1149;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1580;
			    node_1580 = (((let_var_6_t) CREF(node_1146))->body);
			    node_4 = node_1580;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 set_ex_it_116_t node_1158;
			 node_1158 = (set_ex_it_116_t) (node_4);
			 {
			    local_t obj_1293;
			    {
			       variable_t aux_1583;
			       {
				  var_t arg1668_1162;
				  arg1668_1162 = (((set_ex_it_116_t) CREF(node_1158))->var);
				  aux_1583 = (((var_t) CREF(arg1668_1162))->variable);
			       }
			       obj_1293 = (local_t) (aux_1583);
			    }
			    ((((local_t) CREF(obj_1293))->occurrence) = ((long) ((long) 0)), BUNSPEC);
			 }
			 {
			    node_t node_1588;
			    node_1588 = (((set_ex_it_116_t) CREF(node_1158))->body);
			    node_4 = node_1588;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 jump_ex_it_184_t node_1164;
			 node_1164 = (jump_ex_it_184_t) (node_4);
			 occur_node__249_ast_occur((((jump_ex_it_184_t) CREF(node_1164))->exit));
			 {
			    node_t node_1593;
			    node_1593 = (((jump_ex_it_184_t) CREF(node_1164))->value);
			    node_4 = node_1593;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 make_box_202_t node_1168;
			 node_1168 = (make_box_202_t) (node_4);
			 {
			    node_t node_1596;
			    node_1596 = (((make_box_202_t) CREF(node_1168))->value);
			    node_4 = node_1596;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 box_ref_242_t node_1170;
			 node_1170 = (box_ref_242_t) (node_4);
			 {
			    node_t node_1599;
			    {
			       var_t aux_1600;
			       aux_1600 = (((box_ref_242_t) CREF(node_1170))->var);
			       node_1599 = (node_t) (aux_1600);
			    }
			    node_4 = node_1599;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 box_set__221_t node_1172;
			 node_1172 = (box_set__221_t) (node_4);
			 {
			    node_t aux_1604;
			    {
			       var_t aux_1605;
			       aux_1605 = (((box_set__221_t) CREF(node_1172))->var);
			       aux_1604 = (node_t) (aux_1605);
			    }
			    occur_node__249_ast_occur(aux_1604);
			 }
			 {
			    node_t node_1609;
			    node_1609 = (((box_set__221_t) CREF(node_1172))->value);
			    node_4 = node_1609;
			    goto occur_node__249_ast_occur;
			 }
		      }
		      break;
		   default:
		    case_else1593_1065:
		      if (PROCEDUREP(method1587_1061))
			{
			   return PROCEDURE_ENTRY(method1587_1061) (method1587_1061, (obj_t) (node_4), BEOA);
			}
		      else
			{
			   obj_t fun1586_1057;
			   fun1586_1057 = PROCEDURE_REF(occur_node__env_215_ast_occur, ((long) 0));
			   return PROCEDURE_ENTRY(fun1586_1057) (fun1586_1057, (obj_t) (node_4), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1593_1065;
	      }
	 }
      }
   }
}


/* _occur-node!1685 */ obj_t 
_occur_node_1685_123_ast_occur(obj_t env_1312, obj_t node_1313)
{
   return occur_node__249_ast_occur((node_t) (node_1313));
}


/* occur-node!-default1462 */ obj_t 
occur_node__default1462_48_ast_occur(node_t node_5)
{
   return CNST_TABLE_REF(((long) 0));
}


/* _occur-node!-default1462 */ obj_t 
_occur_node__default1462_91_ast_occur(obj_t env_1314, obj_t node_1315)
{
   return occur_node__default1462_48_ast_occur((node_t) (node_1315));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_occur()
{
   module_initialization_70_type_type(((long) 0), "AST_OCCUR");
   module_initialization_70_ast_var(((long) 0), "AST_OCCUR");
   module_initialization_70_ast_node(((long) 0), "AST_OCCUR");
   module_initialization_70_tools_error(((long) 0), "AST_OCCUR");
   module_initialization_70_tools_shape(((long) 0), "AST_OCCUR");
   module_initialization_70_ast_sexp(((long) 0), "AST_OCCUR");
   module_initialization_70_ast_env(((long) 0), "AST_OCCUR");
   return module_initialization_70_ast_local(((long) 0), "AST_OCCUR");
}
