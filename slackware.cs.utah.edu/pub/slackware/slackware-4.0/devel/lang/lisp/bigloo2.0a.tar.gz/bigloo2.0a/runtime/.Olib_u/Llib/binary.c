/*===========================================================================*/
/*   (Llib/binary.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t output_obj_57___binary(obj_t, obj_t);
static obj_t _open_output_binary_file1145_0___binary(obj_t, obj_t);
extern obj_t append_output_binary_file(obj_t);
static obj_t _open_input_binary_file1147_203___binary(obj_t, obj_t);
extern obj_t input_obj(obj_t);
extern obj_t output_obj(obj_t, obj_t);
extern obj_t input_obj_79___binary(obj_t);
extern bool_t binary_port__84___binary(obj_t);
extern obj_t output_char_229___binary(obj_t, char);
static obj_t _append_output_binary_file1146_213___binary(obj_t, obj_t);
extern obj_t open_output_binary_file_193___binary(obj_t);
extern obj_t close_binary_port(obj_t);
extern obj_t open_input_binary_file_64___binary(obj_t);
static obj_t _close_binary_port1148_210___binary(obj_t, obj_t);
static obj_t _input_obj1149_78___binary(obj_t, obj_t);
extern obj_t open_output_binary_file(obj_t);
static obj_t _output_obj1150_238___binary(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___binary(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t open_input_binary_file(obj_t);
extern obj_t append_output_binary_file_44___binary(obj_t);
static obj_t _input_char1152_164___binary(obj_t, obj_t);
extern obj_t close_binary_port_18___binary(obj_t);
static obj_t _binary_port__90___binary(obj_t, obj_t);
extern obj_t input_char_4___binary(obj_t);
static obj_t imported_modules_init_94___binary();
static obj_t require_initialization_114___binary = BUNSPEC;
static obj_t _output_char1151_239___binary(obj_t, obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( output_char_env_218___binary, _output_char1151_239___binary1154, _output_char1151_239___binary, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( binary_port__env_72___binary, _binary_port__90___binary1155, _binary_port__90___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( open_input_binary_file_env_41___binary, _open_input_binary_file1147_203___binary1156, _open_input_binary_file1147_203___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( open_output_binary_file_env_149___binary, _open_output_binary_file1145_0___binary1157, _open_output_binary_file1145_0___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( append_output_binary_file_env_43___binary, _append_output_binary_file1146_213___binary1158, _append_output_binary_file1146_213___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( output_obj_env_240___binary, _output_obj1150_238___binary1159, _output_obj1150_238___binary, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( input_char_env_235___binary, _input_char1152_164___binary1160, _input_char1152_164___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( close_binary_port_env_90___binary, _close_binary_port1148_210___binary1161, _close_binary_port1148_210___binary, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( input_obj_env_141___binary, _input_obj1149_78___binary1162, _input_obj1149_78___binary, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___binary(long checksum_519, char * from_520)
{
if(CBOOL(require_initialization_114___binary)){
require_initialization_114___binary = BBOOL(((bool_t)0));
imported_modules_init_94___binary();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* binary-port? */bool_t binary_port__84___binary(obj_t obj_1)
{
return BINARY_PORTP(obj_1);
}


/* _binary-port? */obj_t _binary_port__90___binary(obj_t env_482, obj_t obj_483)
{
{
bool_t aux_526;
{
obj_t obj_502;
obj_502 = obj_483;
aux_526 = BINARY_PORTP(obj_502);
}
return BBOOL(aux_526);
}
}


/* open-output-binary-file */obj_t open_output_binary_file_193___binary(obj_t str_2)
{
return open_output_binary_file(str_2);
}


/* _open-output-binary-file1145 */obj_t _open_output_binary_file1145_0___binary(obj_t env_484, obj_t str_485)
{
{
obj_t str_503;
str_503 = str_485;
return open_output_binary_file(str_503);
}
}


/* append-output-binary-file */obj_t append_output_binary_file_44___binary(obj_t str_3)
{
return append_output_binary_file(str_3);
}


/* _append-output-binary-file1146 */obj_t _append_output_binary_file1146_213___binary(obj_t env_486, obj_t str_487)
{
{
obj_t str_504;
str_504 = str_487;
return append_output_binary_file(str_504);
}
}


/* open-input-binary-file */obj_t open_input_binary_file_64___binary(obj_t str_4)
{
return open_input_binary_file(str_4);
}


/* _open-input-binary-file1147 */obj_t _open_input_binary_file1147_203___binary(obj_t env_488, obj_t str_489)
{
{
obj_t str_505;
str_505 = str_489;
return open_input_binary_file(str_505);
}
}


/* close-binary-port */obj_t close_binary_port_18___binary(obj_t port_5)
{
return close_binary_port(port_5);
}


/* _close-binary-port1148 */obj_t _close_binary_port1148_210___binary(obj_t env_490, obj_t port_491)
{
{
obj_t port_506;
port_506 = port_491;
return close_binary_port(port_506);
}
}


/* input-obj */obj_t input_obj_79___binary(obj_t port_6)
{
return input_obj(port_6);
}


/* _input-obj1149 */obj_t _input_obj1149_78___binary(obj_t env_492, obj_t port_493)
{
{
obj_t port_507;
port_507 = port_493;
return input_obj(port_507);
}
}


/* output-obj */obj_t output_obj_57___binary(obj_t port_7, obj_t obj_8)
{
return output_obj(port_7, obj_8);
}


/* _output-obj1150 */obj_t _output_obj1150_238___binary(obj_t env_494, obj_t port_495, obj_t obj_496)
{
{
obj_t port_508;
obj_t obj_509;
port_508 = port_495;
obj_509 = obj_496;
return output_obj(port_508, obj_509);
}
}


/* output-char */obj_t output_char_229___binary(obj_t port_9, char char_10)
{
return (fputc( char_10, BINARY_PORT( port_9 ).file ), BUNSPEC);
}


/* _output-char1151 */obj_t _output_char1151_239___binary(obj_t env_497, obj_t port_498, obj_t char_499)
{
{
obj_t port_510;
char char_166_511;
port_510 = port_498;
char_166_511 = CCHAR(char_499);
return (fputc( char_166_511, BINARY_PORT( port_510 ).file ), BUNSPEC);
}
}


/* input-char */obj_t input_char_4___binary(obj_t port_11)
{
{
int char_512;
char_512 = (fgetc( BINARY_PORT( port_11 ).file ));
{
bool_t test1006_513;
{
int arg1007_514;
arg1007_514 = EOF;
{
long aux_548;
long aux_546;
aux_548 = (long)(arg1007_514);
aux_546 = (long)(char_512);
test1006_513 = (aux_546==aux_548);
}
}
if(test1006_513){
return BEOF;
}
 else {
unsigned char aux_552;
{
long aux_553;
aux_553 = (long)(char_512);
aux_552 = (aux_553);
}
return BCHAR(aux_552);
}
}
}
}


/* _input-char1152 */obj_t _input_char1152_164___binary(obj_t env_500, obj_t port_501)
{
{
obj_t port_515;
port_515 = port_501;
{
int char_516;
char_516 = (fgetc( BINARY_PORT( port_515 ).file ));
{
bool_t test1006_517;
{
int arg1007_518;
arg1007_518 = EOF;
{
long aux_561;
long aux_559;
aux_561 = (long)(arg1007_518);
aux_559 = (long)(char_516);
test1006_517 = (aux_559==aux_561);
}
}
if(test1006_517){
return BEOF;
}
 else {
unsigned char aux_565;
{
long aux_566;
aux_566 = (long)(char_516);
aux_565 = (aux_566);
}
return BCHAR(aux_565);
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___binary()
{
return module_initialization_70___error(((long)0), "__BINARY");
}

