/*===========================================================================*/
/*   (Ast/hrtype.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_ast_hrtype();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t hrtype_node__16_ast_hrtype(node_t);
extern obj_t type_type_type;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_ast_hrtype(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t _hrtype_node__default1461_209_ast_hrtype(obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
extern type_t find_type_26_type_env(obj_t);
static obj_t imported_modules_init_94_ast_hrtype();
static obj_t hrtype_node__default1461_66_ast_hrtype(node_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_ast_hrtype();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_ast_hrtype();
static obj_t _hrtype_node_1683_229_ast_hrtype(obj_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t local_ast_var;
extern obj_t shape_tools_shape(obj_t);
static bool_t hrtype_node___80_ast_hrtype(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t restore_variable_type__109_ast_hrtype(variable_t);
static obj_t require_initialization_114_ast_hrtype = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_ast_hrtype();
static obj_t __cnst[1];

DEFINE_EXPORT_GENERIC(hrtype_node__env_165_ast_hrtype, _hrtype_node_1683_229_ast_hrtype1695, _hrtype_node_1683_229_ast_hrtype, 0L, 1);
DEFINE_STATIC_PROCEDURE(hrtype_node__default1461_env_86_ast_hrtype, _hrtype_node__default1461_209_ast_hrtype1696, _hrtype_node__default1461_209_ast_hrtype, 0L, 1);
DEFINE_STRING(string1688_ast_hrtype, string1688_ast_hrtype1697, "HRTYPE-NODE!-DEFAULT1461 ", 25);
DEFINE_STRING(string1687_ast_hrtype, string1687_ast_hrtype1698, "No method for this object", 25);
DEFINE_STRING(string1686_ast_hrtype, string1686_ast_hrtype1699, "Illegal argument", 16);
DEFINE_STRING(string1685_ast_hrtype, string1685_ast_hrtype1700, "Unexpected closure", 18);
DEFINE_STRING(string1684_ast_hrtype, string1684_ast_hrtype1701, "hrtype-node!", 12);


/* module-initialization */ obj_t 
module_initialization_70_ast_hrtype(long checksum_1301, char *from_1302)
{
   if (CBOOL(require_initialization_114_ast_hrtype))
     {
	require_initialization_114_ast_hrtype = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_hrtype();
	cnst_init_137_ast_hrtype();
	imported_modules_init_94_ast_hrtype();
	method_init_76_ast_hrtype();
	toplevel_init_63_ast_hrtype();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_hrtype()
{
   module_initialization_70___object(((long) 0), "AST_HRTYPE");
   module_initialization_70___reader(((long) 0), "AST_HRTYPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_hrtype()
{
   {
      obj_t cnst_port_138_1293;
      cnst_port_138_1293 = open_input_string(string1688_ast_hrtype);
      {
	 long i_1294;
	 i_1294 = ((long) 0);
       loop_1295:
	 {
	    bool_t test1689_1296;
	    test1689_1296 = (i_1294 == ((long) -1));
	    if (test1689_1296)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1691_1297;
		    {
		       obj_t list1692_1298;
		       {
			  obj_t arg1693_1299;
			  arg1693_1299 = BNIL;
			  list1692_1298 = MAKE_PAIR(cnst_port_138_1293, arg1693_1299);
		       }
		       arg1691_1297 = read___reader(list1692_1298);
		    }
		    CNST_TABLE_SET(i_1294, arg1691_1297);
		 }
		 {
		    int aux_1300;
		    {
		       long aux_1319;
		       aux_1319 = (i_1294 - ((long) 1));
		       aux_1300 = (int) (aux_1319);
		    }
		    {
		       long i_1322;
		       i_1322 = (long) (aux_1300);
		       i_1294 = i_1322;
		       goto loop_1295;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_hrtype()
{
   return BUNSPEC;
}


/* hrtype-node*! */ bool_t 
hrtype_node___80_ast_hrtype(obj_t node__221_24)
{
   {
      obj_t l1458_717;
      l1458_717 = node__221_24;
    lname1459_718:
      if (PAIRP(l1458_717))
	{
	   {
	      node_t aux_1326;
	      {
		 obj_t aux_1327;
		 aux_1327 = CAR(l1458_717);
		 aux_1326 = (node_t) (aux_1327);
	      }
	      hrtype_node__16_ast_hrtype(aux_1326);
	   }
	   {
	      obj_t l1458_1331;
	      l1458_1331 = CDR(l1458_717);
	      l1458_717 = l1458_1331;
	      goto lname1459_718;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* restore-variable-type! */ obj_t 
restore_variable_type__109_ast_hrtype(variable_t variable_25)
{
   {
      type_t type_722;
      type_722 = (((variable_t) CREF(variable_25))->type);
      {
	 bool_t test1488_723;
	 test1488_723 = is_a__118___object((obj_t) (type_722), type_type_type);
	 if (test1488_723)
	   {
	      type_t arg1489_724;
	      arg1489_724 = find_type_26_type_env((((type_t) CREF(type_722))->id));
	      return ((((variable_t) CREF(variable_25))->type) = ((type_t) arg1489_724), BUNSPEC);
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_ast_hrtype()
{
   add_generic__110___object(hrtype_node__env_165_ast_hrtype, hrtype_node__default1461_env_86_ast_hrtype);
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, var_ast_node, ((long) 2));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, app_ast_node, ((long) 5));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, select_ast_node, ((long) 13));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, box_set__221_ast_node, ((long) 19));
   {
      long aux_1361;
      aux_1361 = add_inlined_method__244___object(hrtype_node__env_165_ast_hrtype, box_ref_242_ast_node, ((long) 20));
      return BINT(aux_1361);
   }
}


/* hrtype-node! */ obj_t 
hrtype_node__16_ast_hrtype(node_t node_1)
{
 hrtype_node__16_ast_hrtype:
   {
      obj_t method1587_1057;
      obj_t class1592_1058;
      {
	 obj_t arg1595_1055;
	 obj_t arg1598_1056;
	 {
	    object_t obj_1192;
	    obj_1192 = (object_t) (node_1);
	    {
	       obj_t pre_method_105_1193;
	       pre_method_105_1193 = PROCEDURE_REF(hrtype_node__env_165_ast_hrtype, ((long) 2));
	       if (INTEGERP(pre_method_105_1193))
		 {
		    PROCEDURE_SET(hrtype_node__env_165_ast_hrtype, ((long) 2), BUNSPEC);
		    arg1595_1055 = pre_method_105_1193;
		 }
	       else
		 {
		    long obj_class_num_177_1198;
		    obj_class_num_177_1198 = TYPE(obj_1192);
		    {
		       obj_t arg1177_1199;
		       arg1177_1199 = PROCEDURE_REF(hrtype_node__env_165_ast_hrtype, ((long) 1));
		       {
			  long arg1178_1203;
			  {
			     long arg1179_1204;
			     arg1179_1204 = OBJECT_TYPE;
			     arg1178_1203 = (obj_class_num_177_1198 - arg1179_1204);
			  }
			  arg1595_1055 = VECTOR_REF(arg1177_1199, arg1178_1203);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1209;
	    object_1209 = (object_t) (node_1);
	    {
	       long arg1180_1210;
	       {
		  long arg1181_1211;
		  long arg1182_1212;
		  arg1181_1211 = TYPE(object_1209);
		  arg1182_1212 = OBJECT_TYPE;
		  arg1180_1210 = (arg1181_1211 - arg1182_1212);
	       }
	       {
		  obj_t vector_1216;
		  vector_1216 = _classes__134___object;
		  arg1598_1056 = VECTOR_REF(vector_1216, arg1180_1210);
	       }
	    }
	 }
	 method1587_1057 = arg1595_1055;
	 class1592_1058 = arg1598_1056;
	 {
	    if (INTEGERP(method1587_1057))
	      {
		 switch ((long) CINT(method1587_1057))
		   {
		   case ((long) 0):
		      return BUNSPEC;
		      break;
		   case ((long) 1):
		      return BUNSPEC;
		      break;
		   case ((long) 2):
		      return BUNSPEC;
		      break;
		   case ((long) 3):
		      {
			 obj_t arg1605_1070;
			 {
			    obj_t aux_1381;
			    {
			       closure_t aux_1382;
			       aux_1382 = (closure_t) (node_1);
			       aux_1381 = (obj_t) (aux_1382);
			    }
			    arg1605_1070 = shape_tools_shape(aux_1381);
			 }
			 return internal_error_43_tools_error(string1684_ast_hrtype, string1685_ast_hrtype, arg1605_1070);
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1071;
			 node_1071 = (sequence_t) (node_1);
			 {
			    bool_t aux_1388;
			    aux_1388 = hrtype_node___80_ast_hrtype((((sequence_t) CREF(node_1071))->nodes));
			    return BBOOL(aux_1388);
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_t node_1074;
			 node_1074 = (app_t) (node_1);
			 {
			    bool_t aux_1393;
			    aux_1393 = hrtype_node___80_ast_hrtype((((app_t) CREF(node_1074))->args));
			    return BBOOL(aux_1393);
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_1077;
			 node_1077 = (app_ly_162_t) (node_1);
			 hrtype_node__16_ast_hrtype((((app_ly_162_t) CREF(node_1077))->fun));
			 {
			    node_t node_1400;
			    node_1400 = (((app_ly_162_t) CREF(node_1077))->arg);
			    node_1 = node_1400;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_1081;
			 node_1081 = (funcall_t) (node_1);
			 hrtype_node__16_ast_hrtype((((funcall_t) CREF(node_1081))->fun));
			 {
			    bool_t aux_1405;
			    aux_1405 = hrtype_node___80_ast_hrtype((((funcall_t) CREF(node_1081))->args));
			    return BBOOL(aux_1405);
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_1085;
			 node_1085 = (pragma_t) (node_1);
			 {
			    bool_t test1613_1087;
			    {
			       obj_t aux_1410;
			       {
				  type_t aux_1411;
				  aux_1411 = (((pragma_t) CREF(node_1085))->type);
				  aux_1410 = (obj_t) (aux_1411);
			       }
			       test1613_1087 = is_a__118___object(aux_1410, type_type_type);
			    }
			    if (test1613_1087)
			      {
				 type_t arg1615_1088;
				 {
				    obj_t aux_1416;
				    {
				       type_t arg1618_1090;
				       arg1618_1090 = (((pragma_t) CREF(node_1085))->type);
				       aux_1416 = (((type_t) CREF(arg1618_1090))->id);
				    }
				    arg1615_1088 = find_type_26_type_env(aux_1416);
				 }
				 ((((pragma_t) CREF(node_1085))->type) = ((type_t) arg1615_1088), BUNSPEC);
			      }
			    else
			      {
				 BUNSPEC;
			      }
			 }
			 {
			    bool_t aux_1421;
			    aux_1421 = hrtype_node___80_ast_hrtype((((pragma_t) CREF(node_1085))->args));
			    return BBOOL(aux_1421);
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_1093;
			 node_1093 = (cast_t) (node_1);
			 {
			    node_t node_1426;
			    node_1426 = (((cast_t) CREF(node_1093))->arg);
			    node_1 = node_1426;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_1096;
			 node_1096 = (setq_t) (node_1);
			 hrtype_node__16_ast_hrtype((((setq_t) CREF(node_1096))->value));
			 {
			    node_t node_1431;
			    {
			       var_t aux_1432;
			       aux_1432 = (((setq_t) CREF(node_1096))->var);
			       node_1431 = (node_t) (aux_1432);
			    }
			    node_1 = node_1431;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_1100;
			 node_1100 = (conditional_t) (node_1);
			 hrtype_node__16_ast_hrtype((((conditional_t) CREF(node_1100))->test));
			 hrtype_node__16_ast_hrtype((((conditional_t) CREF(node_1100))->true));
			 {
			    node_t node_1440;
			    node_1440 = (((conditional_t) CREF(node_1100))->false);
			    node_1 = node_1440;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_1105;
			 node_1105 = (fail_t) (node_1);
			 hrtype_node__16_ast_hrtype((((fail_t) CREF(node_1105))->proc));
			 hrtype_node__16_ast_hrtype((((fail_t) CREF(node_1105))->msg));
			 {
			    node_t node_1447;
			    node_1447 = (((fail_t) CREF(node_1105))->obj);
			    node_1 = node_1447;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_1110;
			 node_1110 = (select_t) (node_1);
			 hrtype_node__16_ast_hrtype((((select_t) CREF(node_1110))->test));
			 {
			    obj_t l1445_1113;
			    {
			       bool_t aux_1452;
			       l1445_1113 = (((select_t) CREF(node_1110))->clauses);
			     lname1446_1114:
			       if (PAIRP(l1445_1113))
				 {
				    {
				       node_t aux_1455;
				       {
					  obj_t aux_1456;
					  {
					     obj_t aux_1457;
					     aux_1457 = CAR(l1445_1113);
					     aux_1456 = CDR(aux_1457);
					  }
					  aux_1455 = (node_t) (aux_1456);
				       }
				       hrtype_node__16_ast_hrtype(aux_1455);
				    }
				    {
				       obj_t l1445_1462;
				       l1445_1462 = CDR(l1445_1113);
				       l1445_1113 = l1445_1462;
				       goto lname1446_1114;
				    }
				 }
			       else
				 {
				    aux_1452 = ((bool_t) 1);
				 }
			       return BBOOL(aux_1452);
			    }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_1120;
			 node_1120 = (let_fun_218_t) (node_1);
			 {
			    obj_t l1448_1122;
			    l1448_1122 = (((let_fun_218_t) CREF(node_1120))->locals);
			  lname1449_1123:
			    if (PAIRP(l1448_1122))
			      {
				 {
				    obj_t local_1126;
				    local_1126 = CAR(l1448_1122);
				    {
				       value_t sfun_1127;
				       {
					  local_t obj_1249;
					  obj_1249 = (local_t) (local_1126);
					  sfun_1127 = (((local_t) CREF(obj_1249))->value);
				       }
				       {
					  obj_t args_1128;
					  {
					     sfun_t obj_1250;
					     obj_1250 = (sfun_t) (sfun_1127);
					     args_1128 = (((sfun_t) CREF(obj_1250))->args);
					  }
					loop_1129:
					  if (PAIRP(args_1128))
					    {
					       obj_t arg_1132;
					       arg_1132 = CAR(args_1128);
					       {
						  bool_t test1647_1133;
						  test1647_1133 = is_a__118___object(arg_1132, type_type_type);
						  if (test1647_1133)
						    {
						       {
							  type_t arg1648_1134;
							  {
							     obj_t aux_1477;
							     {
								type_t obj_1254;
								obj_1254 = (type_t) (arg_1132);
								aux_1477 = (((type_t) CREF(obj_1254))->id);
							     }
							     arg1648_1134 = find_type_26_type_env(aux_1477);
							  }
							  {
							     obj_t aux_1481;
							     aux_1481 = (obj_t) (arg1648_1134);
							     SET_CAR(args_1128, aux_1481);
							  }
						       }
						    }
						  else
						    {
						       bool_t test1650_1136;
						       test1650_1136 = is_a__118___object(arg_1132, local_ast_var);
						       if (test1650_1136)
							 {
							    restore_variable_type__109_ast_hrtype((variable_t) (arg_1132));
							 }
						       else
							 {
							    {
							       obj_t arg1654_1139;
							       arg1654_1139 = shape_tools_shape(arg_1132);
							       FAILURE(string1684_ast_hrtype, string1686_ast_hrtype, arg1654_1139);
							    }
							 }
						    }
					       }
					       {
						  obj_t args_1490;
						  args_1490 = CDR(args_1128);
						  args_1128 = args_1490;
						  goto loop_1129;
					       }
					    }
					  else
					    {
					       BUNSPEC;
					    }
				       }
				       restore_variable_type__109_ast_hrtype((variable_t) (local_1126));
				       {
					  node_t aux_1496;
					  {
					     obj_t aux_1497;
					     {
						sfun_t obj_1262;
						obj_1262 = (sfun_t) (sfun_1127);
						aux_1497 = (((sfun_t) CREF(obj_1262))->body);
					     }
					     aux_1496 = (node_t) (aux_1497);
					  }
					  hrtype_node__16_ast_hrtype(aux_1496);
				       }
				    }
				 }
				 {
				    obj_t l1448_1502;
				    l1448_1502 = CDR(l1448_1122);
				    l1448_1122 = l1448_1502;
				    goto lname1449_1123;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1505;
			    node_1505 = (((let_fun_218_t) CREF(node_1120))->body);
			    node_1 = node_1505;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_1144;
			 node_1144 = (let_var_6_t) (node_1);
			 {
			    obj_t l1451_1146;
			    l1451_1146 = (((let_var_6_t) CREF(node_1144))->bindings);
			  lname1452_1147:
			    if (PAIRP(l1451_1146))
			      {
				 {
				    obj_t binding_1150;
				    binding_1150 = CAR(l1451_1146);
				    {
				       obj_t var_1151;
				       var_1151 = CAR(binding_1150);
				       {
					  node_t aux_1512;
					  {
					     obj_t aux_1513;
					     aux_1513 = CDR(binding_1150);
					     aux_1512 = (node_t) (aux_1513);
					  }
					  hrtype_node__16_ast_hrtype(aux_1512);
				       }
				       restore_variable_type__109_ast_hrtype((variable_t) (var_1151));
				    }
				 }
				 {
				    obj_t l1451_1519;
				    l1451_1519 = CDR(l1451_1146);
				    l1451_1146 = l1451_1519;
				    goto lname1452_1147;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1522;
			    node_1522 = (((let_var_6_t) CREF(node_1144))->body);
			    node_1 = node_1522;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_1155;
			 node_1155 = (set_ex_it_116_t) (node_1);
			 {
			    variable_t aux_1525;
			    {
			       var_t arg1666_1158;
			       arg1666_1158 = (((set_ex_it_116_t) CREF(node_1155))->var);
			       aux_1525 = (((var_t) CREF(arg1666_1158))->variable);
			    }
			    restore_variable_type__109_ast_hrtype(aux_1525);
			 }
			 hrtype_node__16_ast_hrtype((((set_ex_it_116_t) CREF(node_1155))->body));
			 {
			    node_t node_1531;
			    {
			       var_t aux_1532;
			       aux_1532 = (((set_ex_it_116_t) CREF(node_1155))->var);
			       node_1531 = (node_t) (aux_1532);
			    }
			    node_1 = node_1531;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_1161;
			 node_1161 = (jump_ex_it_184_t) (node_1);
			 hrtype_node__16_ast_hrtype((((jump_ex_it_184_t) CREF(node_1161))->exit));
			 {
			    node_t node_1538;
			    node_1538 = (((jump_ex_it_184_t) CREF(node_1161))->value);
			    node_1 = node_1538;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_1165;
			 node_1165 = (make_box_202_t) (node_1);
			 {
			    node_t node_1541;
			    node_1541 = (((make_box_202_t) CREF(node_1165))->value);
			    node_1 = node_1541;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 19):
		      {
			 box_set__221_t node_1168;
			 node_1168 = (box_set__221_t) (node_1);
			 {
			    node_t aux_1544;
			    {
			       var_t aux_1545;
			       aux_1545 = (((box_set__221_t) CREF(node_1168))->var);
			       aux_1544 = (node_t) (aux_1545);
			    }
			    hrtype_node__16_ast_hrtype(aux_1544);
			 }
			 {
			    node_t node_1549;
			    node_1549 = (((box_set__221_t) CREF(node_1168))->value);
			    node_1 = node_1549;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   case ((long) 20):
		      {
			 box_ref_242_t node_1172;
			 node_1172 = (box_ref_242_t) (node_1);
			 {
			    node_t node_1552;
			    {
			       var_t aux_1553;
			       aux_1553 = (((box_ref_242_t) CREF(node_1172))->var);
			       node_1552 = (node_t) (aux_1553);
			    }
			    node_1 = node_1552;
			    goto hrtype_node__16_ast_hrtype;
			 }
		      }
		      break;
		   default:
		    case_else1593_1061:
		      if (PROCEDUREP(method1587_1057))
			{
			   return PROCEDURE_ENTRY(method1587_1057) (method1587_1057, (obj_t) (node_1), BEOA);
			}
		      else
			{
			   obj_t fun1584_1051;
			   fun1584_1051 = PROCEDURE_REF(hrtype_node__env_165_ast_hrtype, ((long) 0));
			   return PROCEDURE_ENTRY(fun1584_1051) (fun1584_1051, (obj_t) (node_1), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1593_1061;
	      }
	 }
      }
   }
}


/* _hrtype-node!1683 */ obj_t 
_hrtype_node_1683_229_ast_hrtype(obj_t env_1289, obj_t node_1290)
{
   return hrtype_node__16_ast_hrtype((node_t) (node_1290));
}


/* hrtype-node!-default1461 */ obj_t 
hrtype_node__default1461_66_ast_hrtype(node_t node_2)
{
   FAILURE(CNST_TABLE_REF(((long) 0)), string1687_ast_hrtype, (obj_t) (node_2));
}


/* _hrtype-node!-default1461 */ obj_t 
_hrtype_node__default1461_209_ast_hrtype(obj_t env_1291, obj_t node_1292)
{
   return hrtype_node__default1461_66_ast_hrtype((node_t) (node_1292));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_hrtype()
{
   module_initialization_70_type_type(((long) 0), "AST_HRTYPE");
   module_initialization_70_type_env(((long) 0), "AST_HRTYPE");
   module_initialization_70_tools_shape(((long) 0), "AST_HRTYPE");
   module_initialization_70_tools_error(((long) 0), "AST_HRTYPE");
   module_initialization_70_coerce_typeof(((long) 0), "AST_HRTYPE");
   module_initialization_70_ast_var(((long) 0), "AST_HRTYPE");
   return module_initialization_70_ast_node(((long) 0), "AST_HRTYPE");
}
