/*===========================================================================*/
/*   (Llib/process.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_keyword(char *);
extern obj_t process_exit_status_63___process(obj_t);
extern bool_t process_wait_122___process(obj_t);
static obj_t symbol1447___process = BUNSPEC;
static obj_t symbol1446___process = BUNSPEC;
static obj_t symbol1445___process = BUNSPEC;
static obj_t symbol1443___process = BUNSPEC;
static obj_t symbol1429___process = BUNSPEC;
static obj_t symbol1430___process = BUNSPEC;
static obj_t symbol1428___process = BUNSPEC;
static obj_t symbol1427___process = BUNSPEC;
static obj_t symbol1426___process = BUNSPEC;
static obj_t symbol1425___process = BUNSPEC;
static obj_t symbol1424___process = BUNSPEC;
static obj_t symbol1423___process = BUNSPEC;
static obj_t symbol1421___process = BUNSPEC;
static obj_t symbol1419___process = BUNSPEC;
static obj_t symbol1420___process = BUNSPEC;
static obj_t symbol1418___process = BUNSPEC;
static obj_t symbol1417___process = BUNSPEC;
static obj_t symbol1416___process = BUNSPEC;
static obj_t symbol1415___process = BUNSPEC;
extern obj_t string_to_symbol(char *);
static obj_t symbol1414___process = BUNSPEC;
static obj_t symbol1413___process = BUNSPEC;
static obj_t symbol1412___process = BUNSPEC;
static obj_t symbol1411___process = BUNSPEC;
static obj_t symbol1409___process = BUNSPEC;
static obj_t symbol1410___process = BUNSPEC;
static obj_t symbol1408___process = BUNSPEC;
static obj_t symbol1405___process = BUNSPEC;
static obj_t symbol1404___process = BUNSPEC;
extern obj_t process_input_port_25___process(obj_t);
static obj_t symbol1403___process = BUNSPEC;
extern obj_t process_output_port_86___process(obj_t);
static obj_t _process__54___process(obj_t, obj_t);
extern obj_t process_continue_186___process(obj_t);
static obj_t _process_input_port_248___process(obj_t, obj_t);
static obj_t _process_list_8___process(obj_t);
static obj_t _process_send_signal_25___process(obj_t, obj_t, obj_t);
extern bool_t process_alive__25___process(obj_t);
extern bool_t process__75___process(obj_t);
static obj_t _process_stop_38___process(obj_t, obj_t);
static obj_t keyword1442___process = BUNSPEC;
static obj_t keyword1441___process = BUNSPEC;
static obj_t keyword1439___process = BUNSPEC;
static obj_t keyword1440___process = BUNSPEC;
static obj_t keyword1438___process = BUNSPEC;
static obj_t keyword1437___process = BUNSPEC;
static obj_t keyword1433___process = BUNSPEC;
extern obj_t c_process_continue(obj_t);
extern obj_t c_process_list();
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t c_process_stop(obj_t);
extern obj_t c_process_send_signal(obj_t, int);
static obj_t _process_exit_status_230___process(obj_t, obj_t);
static obj_t _process_kill_194___process(obj_t, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___process(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _process_output_port_146___process(obj_t, obj_t);
extern obj_t process_list_172___process();
static obj_t _process_wait_128___process(obj_t, obj_t);
static obj_t _run_process_4___process(obj_t, obj_t, obj_t);
extern obj_t process_stop_113___process(obj_t);
extern obj_t process_send_signal_117___process(obj_t, int);
extern obj_t c_unregister_process(obj_t);
extern obj_t c_process_alivep(obj_t);
static obj_t _process_pid_113___process(obj_t, obj_t);
extern obj_t c_process_kill(obj_t);
extern obj_t run_process_29___process(obj_t, obj_t);
static obj_t _process_alive__232___process(obj_t, obj_t);
extern obj_t unregister_process_179___process(obj_t);
extern obj_t process_error_port_133___process(obj_t);
extern obj_t c_process_wait(obj_t);
static obj_t _process_continue_223___process(obj_t, obj_t);
extern obj_t c_process_xstatus(obj_t);
static obj_t imported_modules_init_94___process();
static obj_t _unregister_process_206___process(obj_t, obj_t);
extern obj_t c_run_process(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _process_error_port_135___process(obj_t, obj_t);
static obj_t require_initialization_114___process = BUNSPEC;
extern int process_pid_210___process(obj_t);
extern obj_t process_kill_93___process(obj_t);
static obj_t cnst_init_137___process();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( process_stop_env_39___process, _process_stop_38___process1449, _process_stop_38___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process__env_163___process, _process__54___process1450, _process__54___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_send_signal_env_135___process, _process_send_signal_25___process1451, _process_send_signal_25___process, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( process_kill_env_209___process, _process_kill_194___process1452, _process_kill_194___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_error_port_env_248___process, _process_error_port_135___process1453, _process_error_port_135___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_list_env_224___process, _process_list_8___process1454, _process_list_8___process, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( process_alive__env_47___process, _process_alive__232___process1455, _process_alive__232___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_output_port_env_138___process, _process_output_port_146___process1456, _process_output_port_146___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( run_process_env_117___process, _run_process_4___process1457, va_generic_entry, _run_process_4___process, -2 );
DEFINE_EXPORT_PROCEDURE( process_pid_env_38___process, _process_pid_113___process1458, _process_pid_113___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( unregister_process_env_112___process, _unregister_process_206___process1459, _unregister_process_206___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_continue_env_196___process, _process_continue_223___process1460, _process_continue_223___process, 0L, 1 );
DEFINE_STRING( string1444___process, string1444___process1461, "BSTRING", 7 );
DEFINE_STRING( string1436___process, string1436___process1462, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1435___process, string1435___process1463, "Illegal argument", 16 );
DEFINE_STRING( string1434___process, string1434___process1464, "run-process", 11 );
DEFINE_STRING( string1432___process, string1432___process1465, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/pair-list.scm", 62 );
DEFINE_STRING( string1431___process, string1431___process1466, "PAIR", 4 );
DEFINE_STRING( string1422___process, string1422___process1467, "INT", 3 );
DEFINE_EXPORT_PROCEDURE( process_wait_env_238___process, _process_wait_128___process1468, _process_wait_128___process, 0L, 1 );
DEFINE_STRING( string1407___process, string1407___process1469, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/process.scm", 60 );
DEFINE_STRING( string1406___process, string1406___process1470, "PROCESS", 7 );
DEFINE_EXPORT_PROCEDURE( process_input_port_env_47___process, _process_input_port_248___process1471, _process_input_port_248___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_exit_status_env_111___process, _process_exit_status_230___process1472, _process_exit_status_230___process, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___process(long checksum_825, char * from_826)
{
if(CBOOL(require_initialization_114___process)){
require_initialization_114___process = BBOOL(((bool_t)0));
cnst_init_137___process();
imported_modules_init_94___process();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___process()
{
symbol1403___process = string_to_symbol("PROCESS?");
symbol1404___process = string_to_symbol("PROCESS-PID");
symbol1405___process = string_to_symbol("_PROCESS-PID");
symbol1408___process = string_to_symbol("PROCESS-OUTPUT-PORT");
symbol1409___process = string_to_symbol("_PROCESS-OUTPUT-PORT");
symbol1410___process = string_to_symbol("PROCESS-INPUT-PORT");
symbol1411___process = string_to_symbol("_PROCESS-INPUT-PORT");
symbol1412___process = string_to_symbol("PROCESS-ERROR-PORT");
symbol1413___process = string_to_symbol("_PROCESS-ERROR-PORT");
symbol1414___process = string_to_symbol("PROCESS-ALIVE?");
symbol1415___process = string_to_symbol("_PROCESS-ALIVE?");
symbol1416___process = string_to_symbol("PROCESS-WAIT");
symbol1417___process = string_to_symbol("_PROCESS-WAIT");
symbol1418___process = string_to_symbol("PROCESS-EXIT-STATUS");
symbol1419___process = string_to_symbol("_PROCESS-EXIT-STATUS");
symbol1420___process = string_to_symbol("PROCESS-SEND-SIGNAL");
symbol1421___process = string_to_symbol("_PROCESS-SEND-SIGNAL");
symbol1423___process = string_to_symbol("PROCESS-KILL");
symbol1424___process = string_to_symbol("_PROCESS-KILL");
symbol1425___process = string_to_symbol("PROCESS-STOP");
symbol1426___process = string_to_symbol("_PROCESS-STOP");
symbol1427___process = string_to_symbol("PROCESS-CONTINUE");
symbol1428___process = string_to_symbol("_PROCESS-CONTINUE");
symbol1429___process = string_to_symbol("PROCESS-LIST");
symbol1430___process = string_to_symbol("RUN-PROCESS");
keyword1433___process = string_to_keyword("WAIT:");
keyword1437___process = string_to_keyword("FORK:");
keyword1438___process = string_to_keyword("INPUT:");
keyword1439___process = string_to_keyword("PIPE:");
keyword1440___process = string_to_keyword("OUTPUT:");
keyword1441___process = string_to_keyword("ERROR:");
keyword1442___process = string_to_keyword("HOST:");
symbol1443___process = string_to_symbol("_RUN-PROCESS");
symbol1445___process = string_to_symbol("UNREGISTER-PROCESS");
symbol1446___process = string_to_symbol("_UNREGISTER-PROCESS");
return (symbol1447___process = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* process? */bool_t process__75___process(obj_t obj_1)
{
{
obj_t symbol1179_755;
symbol1179_755 = symbol1403___process;
{
PUSH_TRACE(symbol1179_755);
BUNSPEC;
{
bool_t aux1178_756;
aux1178_756 = PROCESSP(obj_1);
POP_TRACE();
return aux1178_756;
}
}
}
}


/* _process? */obj_t _process__54___process(obj_t env_574, obj_t obj_575)
{
{
bool_t aux_871;
{
obj_t obj_757;
obj_757 = obj_575;
{
obj_t symbol1179_758;
symbol1179_758 = symbol1403___process;
{
PUSH_TRACE(symbol1179_758);
BUNSPEC;
{
bool_t aux1178_759;
aux1178_759 = PROCESSP(obj_757);
POP_TRACE();
aux_871 = aux1178_759;
}
}
}
}
return BBOOL(aux_871);
}
}


/* process-pid */int process_pid_210___process(obj_t proc_2)
{
{
obj_t symbol1181_760;
symbol1181_760 = symbol1404___process;
{
PUSH_TRACE(symbol1181_760);
BUNSPEC;
{
int aux1180_761;
aux1180_761 = PROCESS_PID(proc_2);
POP_TRACE();
return aux1180_761;
}
}
}
}


/* _process-pid */obj_t _process_pid_113___process(obj_t env_576, obj_t proc_577)
{
{
int aux_879;
{
obj_t proc_762;
{
bool_t test1211_606;
test1211_606 = PROCESSP(proc_577);
if(test1211_606){
proc_762 = proc_577;
}
 else {
bigloo_type_error_location_103___error(symbol1405___process, string1406___process, proc_577, string1407___process, BINT(((long)4170)));
exit( -1 );}
}
{
obj_t symbol1181_763;
symbol1181_763 = symbol1404___process;
{
PUSH_TRACE(symbol1181_763);
BUNSPEC;
{
int aux1180_764;
aux1180_764 = PROCESS_PID(proc_762);
POP_TRACE();
aux_879 = aux1180_764;
}
}
}
}
return BINT(aux_879);
}
}


/* process-output-port */obj_t process_output_port_86___process(obj_t proc_3)
{
{
obj_t symbol1183_765;
symbol1183_765 = symbol1408___process;
{
PUSH_TRACE(symbol1183_765);
BUNSPEC;
{
obj_t aux1182_766;
aux1182_766 = PROCESS_OUTPUT_PORT(proc_3);
POP_TRACE();
return aux1182_766;
}
}
}
}


/* _process-output-port */obj_t _process_output_port_146___process(obj_t env_578, obj_t proc_579)
{
{
obj_t proc_767;
{
bool_t test1221_612;
test1221_612 = PROCESSP(proc_579);
if(test1221_612){
proc_767 = proc_579;
}
 else {
bigloo_type_error_location_103___error(symbol1409___process, string1406___process, proc_579, string1407___process, BINT(((long)4452)));
exit( -1 );}
}
{
obj_t symbol1183_768;
symbol1183_768 = symbol1408___process;
{
PUSH_TRACE(symbol1183_768);
BUNSPEC;
{
obj_t aux1182_769;
aux1182_769 = PROCESS_OUTPUT_PORT(proc_767);
POP_TRACE();
return aux1182_769;
}
}
}
}
}


/* process-input-port */obj_t process_input_port_25___process(obj_t proc_4)
{
{
obj_t symbol1185_770;
symbol1185_770 = symbol1410___process;
{
PUSH_TRACE(symbol1185_770);
BUNSPEC;
{
obj_t aux1184_771;
aux1184_771 = PROCESS_INPUT_PORT(proc_4);
POP_TRACE();
return aux1184_771;
}
}
}
}


/* _process-input-port */obj_t _process_input_port_248___process(obj_t env_580, obj_t proc_581)
{
{
obj_t proc_772;
{
bool_t test1228_618;
test1228_618 = PROCESSP(proc_581);
if(test1228_618){
proc_772 = proc_581;
}
 else {
bigloo_type_error_location_103___error(symbol1411___process, string1406___process, proc_581, string1407___process, BINT(((long)4750)));
exit( -1 );}
}
{
obj_t symbol1185_773;
symbol1185_773 = symbol1410___process;
{
PUSH_TRACE(symbol1185_773);
BUNSPEC;
{
obj_t aux1184_774;
aux1184_774 = PROCESS_INPUT_PORT(proc_772);
POP_TRACE();
return aux1184_774;
}
}
}
}
}


/* process-error-port */obj_t process_error_port_133___process(obj_t proc_5)
{
{
obj_t symbol1187_775;
symbol1187_775 = symbol1412___process;
{
PUSH_TRACE(symbol1187_775);
BUNSPEC;
{
obj_t aux1186_776;
aux1186_776 = PROCESS_ERROR_PORT(proc_5);
POP_TRACE();
return aux1186_776;
}
}
}
}


/* _process-error-port */obj_t _process_error_port_135___process(obj_t env_582, obj_t proc_583)
{
{
obj_t proc_777;
{
bool_t test1236_624;
test1236_624 = PROCESSP(proc_583);
if(test1236_624){
proc_777 = proc_583;
}
 else {
bigloo_type_error_location_103___error(symbol1413___process, string1406___process, proc_583, string1407___process, BINT(((long)5046)));
exit( -1 );}
}
{
obj_t symbol1187_778;
symbol1187_778 = symbol1412___process;
{
PUSH_TRACE(symbol1187_778);
BUNSPEC;
{
obj_t aux1186_779;
aux1186_779 = PROCESS_ERROR_PORT(proc_777);
POP_TRACE();
return aux1186_779;
}
}
}
}
}


/* process-alive? */bool_t process_alive__25___process(obj_t proc_6)
{
{
obj_t symbol1189_780;
symbol1189_780 = symbol1414___process;
{
PUSH_TRACE(symbol1189_780);
BUNSPEC;
{
bool_t aux1188_781;
{
obj_t aux_923;
aux_923 = c_process_alivep(proc_6);
aux1188_781 = CBOOL(aux_923);
}
POP_TRACE();
return aux1188_781;
}
}
}
}


/* _process-alive? */obj_t _process_alive__232___process(obj_t env_584, obj_t proc_585)
{
{
bool_t aux_927;
{
obj_t proc_782;
{
bool_t test1245_630;
test1245_630 = PROCESSP(proc_585);
if(test1245_630){
proc_782 = proc_585;
}
 else {
bigloo_type_error_location_103___error(symbol1415___process, string1406___process, proc_585, string1407___process, BINT(((long)5342)));
exit( -1 );}
}
{
obj_t symbol1189_783;
symbol1189_783 = symbol1414___process;
{
PUSH_TRACE(symbol1189_783);
BUNSPEC;
{
bool_t aux1188_784;
{
obj_t aux_934;
aux_934 = c_process_alivep(proc_782);
aux1188_784 = CBOOL(aux_934);
}
POP_TRACE();
aux_927 = aux1188_784;
}
}
}
}
return BBOOL(aux_927);
}
}


/* process-wait */bool_t process_wait_122___process(obj_t proc_7)
{
{
obj_t symbol1191_785;
symbol1191_785 = symbol1416___process;
{
PUSH_TRACE(symbol1191_785);
BUNSPEC;
{
bool_t aux1190_786;
{
obj_t aux_940;
aux_940 = c_process_wait(proc_7);
aux1190_786 = CBOOL(aux_940);
}
POP_TRACE();
return aux1190_786;
}
}
}
}


/* _process-wait */obj_t _process_wait_128___process(obj_t env_586, obj_t proc_587)
{
{
bool_t aux_944;
{
obj_t proc_787;
{
bool_t test1253_636;
test1253_636 = PROCESSP(proc_587);
if(test1253_636){
proc_787 = proc_587;
}
 else {
bigloo_type_error_location_103___error(symbol1417___process, string1406___process, proc_587, string1407___process, BINT(((long)5630)));
exit( -1 );}
}
{
obj_t symbol1191_788;
symbol1191_788 = symbol1416___process;
{
PUSH_TRACE(symbol1191_788);
BUNSPEC;
{
bool_t aux1190_789;
{
obj_t aux_951;
aux_951 = c_process_wait(proc_787);
aux1190_789 = CBOOL(aux_951);
}
POP_TRACE();
aux_944 = aux1190_789;
}
}
}
}
return BBOOL(aux_944);
}
}


/* process-exit-status */obj_t process_exit_status_63___process(obj_t proc_8)
{
{
obj_t symbol1193_790;
symbol1193_790 = symbol1418___process;
{
PUSH_TRACE(symbol1193_790);
BUNSPEC;
{
obj_t aux1192_791;
aux1192_791 = c_process_xstatus(proc_8);
POP_TRACE();
return aux1192_791;
}
}
}
}


/* _process-exit-status */obj_t _process_exit_status_230___process(obj_t env_588, obj_t proc_589)
{
{
obj_t proc_792;
{
bool_t test1260_642;
test1260_642 = PROCESSP(proc_589);
if(test1260_642){
proc_792 = proc_589;
}
 else {
bigloo_type_error_location_103___error(symbol1419___process, string1406___process, proc_589, string1407___process, BINT(((long)5914)));
exit( -1 );}
}
{
obj_t symbol1193_793;
symbol1193_793 = symbol1418___process;
{
PUSH_TRACE(symbol1193_793);
BUNSPEC;
{
obj_t aux1192_794;
aux1192_794 = c_process_xstatus(proc_792);
POP_TRACE();
return aux1192_794;
}
}
}
}
}


/* process-send-signal */obj_t process_send_signal_117___process(obj_t proc_9, int signal_10)
{
{
obj_t symbol1195_795;
symbol1195_795 = symbol1420___process;
{
PUSH_TRACE(symbol1195_795);
BUNSPEC;
{
obj_t aux1194_796;
aux1194_796 = c_process_send_signal(proc_9, signal_10);
POP_TRACE();
return aux1194_796;
}
}
}
}


/* _process-send-signal */obj_t _process_send_signal_25___process(obj_t env_590, obj_t proc_591, obj_t signal_592)
{
{
obj_t proc_797;
int signal_798;
{
bool_t test1269_648;
test1269_648 = PROCESSP(proc_591);
if(test1269_648){
proc_797 = proc_591;
}
 else {
bigloo_type_error_location_103___error(symbol1421___process, string1406___process, proc_591, string1407___process, BINT(((long)6212)));
exit( -1 );}
}
{
obj_t aux_975;
if(INTEGERP(signal_592)){
aux_975 = signal_592;
}
 else {
bigloo_type_error_location_103___error(symbol1421___process, string1422___process, signal_592, string1407___process, BINT(((long)6212)));
exit( -1 );}
signal_798 = CINT(aux_975);
}
{
obj_t symbol1195_799;
symbol1195_799 = symbol1420___process;
{
PUSH_TRACE(symbol1195_799);
BUNSPEC;
{
obj_t aux1194_800;
aux1194_800 = c_process_send_signal(proc_797, signal_798);
POP_TRACE();
return aux1194_800;
}
}
}
}
}


/* process-kill */obj_t process_kill_93___process(obj_t proc_11)
{
{
obj_t symbol1197_801;
symbol1197_801 = symbol1423___process;
{
PUSH_TRACE(symbol1197_801);
BUNSPEC;
{
obj_t aux1196_802;
aux1196_802 = c_process_kill(proc_11);
POP_TRACE();
return aux1196_802;
}
}
}
}


/* _process-kill */obj_t _process_kill_194___process(obj_t env_593, obj_t proc_594)
{
{
obj_t proc_803;
{
bool_t test1284_660;
test1284_660 = PROCESSP(proc_594);
if(test1284_660){
proc_803 = proc_594;
}
 else {
bigloo_type_error_location_103___error(symbol1424___process, string1406___process, proc_594, string1407___process, BINT(((long)6524)));
exit( -1 );}
}
{
obj_t symbol1197_804;
symbol1197_804 = symbol1423___process;
{
PUSH_TRACE(symbol1197_804);
BUNSPEC;
{
obj_t aux1196_805;
aux1196_805 = c_process_kill(proc_803);
POP_TRACE();
return aux1196_805;
}
}
}
}
}


/* process-stop */obj_t process_stop_113___process(obj_t proc_12)
{
{
obj_t symbol1199_806;
symbol1199_806 = symbol1425___process;
{
PUSH_TRACE(symbol1199_806);
BUNSPEC;
{
obj_t aux1198_807;
aux1198_807 = c_process_stop(proc_12);
POP_TRACE();
return aux1198_807;
}
}
}
}


/* _process-stop */obj_t _process_stop_38___process(obj_t env_595, obj_t proc_596)
{
{
obj_t proc_808;
{
bool_t test1290_666;
test1290_666 = PROCESSP(proc_596);
if(test1290_666){
proc_808 = proc_596;
}
 else {
bigloo_type_error_location_103___error(symbol1426___process, string1406___process, proc_596, string1407___process, BINT(((long)6808)));
exit( -1 );}
}
{
obj_t symbol1199_809;
symbol1199_809 = symbol1425___process;
{
PUSH_TRACE(symbol1199_809);
BUNSPEC;
{
obj_t aux1198_810;
aux1198_810 = c_process_stop(proc_808);
POP_TRACE();
return aux1198_810;
}
}
}
}
}


/* process-continue */obj_t process_continue_186___process(obj_t proc_13)
{
{
obj_t symbol1201_811;
symbol1201_811 = symbol1427___process;
{
PUSH_TRACE(symbol1201_811);
BUNSPEC;
{
obj_t aux1200_812;
aux1200_812 = c_process_continue(proc_13);
POP_TRACE();
return aux1200_812;
}
}
}
}


/* _process-continue */obj_t _process_continue_223___process(obj_t env_597, obj_t proc_598)
{
{
obj_t proc_813;
{
bool_t test1297_672;
test1297_672 = PROCESSP(proc_598);
if(test1297_672){
proc_813 = proc_598;
}
 else {
bigloo_type_error_location_103___error(symbol1428___process, string1406___process, proc_598, string1407___process, BINT(((long)7092)));
exit( -1 );}
}
{
obj_t symbol1201_814;
symbol1201_814 = symbol1427___process;
{
PUSH_TRACE(symbol1201_814);
BUNSPEC;
{
obj_t aux1200_815;
aux1200_815 = c_process_continue(proc_813);
POP_TRACE();
return aux1200_815;
}
}
}
}
}


/* process-list */obj_t process_list_172___process()
{
{
obj_t symbol1203_816;
symbol1203_816 = symbol1429___process;
{
PUSH_TRACE(symbol1203_816);
BUNSPEC;
{
obj_t aux1202_817;
aux1202_817 = c_process_list();
POP_TRACE();
return aux1202_817;
}
}
}
}


/* _process-list */obj_t _process_list_8___process(obj_t env_599)
{
{
obj_t symbol1203_818;
symbol1203_818 = symbol1429___process;
{
PUSH_TRACE(symbol1203_818);
BUNSPEC;
{
obj_t aux1202_819;
aux1202_819 = c_process_list();
POP_TRACE();
return aux1202_819;
}
}
}
}


/* run-process */obj_t run_process_29___process(obj_t command_14, obj_t rest_15)
{
{
obj_t symbol1205_568;
symbol1205_568 = symbol1430___process;
{
PUSH_TRACE(symbol1205_568);
BUNSPEC;
{
obj_t aux1204_569;
{
obj_t fork_279;
obj_t wait_280;
obj_t input_281;
obj_t output_282;
obj_t error_283;
obj_t host_284;
obj_t args_285;
fork_279 = BTRUE;
wait_280 = BFALSE;
input_281 = BUNSPEC;
output_282 = BUNSPEC;
error_283 = BUNSPEC;
host_284 = BUNSPEC;
args_285 = BNIL;
{
obj_t rest_287;
{
obj_t aux1382_737;
rest_287 = rest_15;
loop_288:
if(NULLP(rest_287)){
{
obj_t arg1007_290;
arg1007_290 = reverse__39___r4_pairs_and_lists_6_3(args_285);
aux1382_737 = c_run_process(host_284, fork_279, wait_280, input_281, output_282, error_283, command_14, arg1007_290);
}
}
 else {
bool_t test1008_291;
{
bool_t test1040_324;
{
obj_t arg1042_326;
{
obj_t pair_463;
if(PAIRP(rest_287)){
pair_463 = rest_287;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, rest_287, string1407___process, BINT(((long)8323)));
exit( -1 );}
arg1042_326 = CAR(pair_463);
}
test1040_324 = KEYWORDP(arg1042_326);
}
if(test1040_324){
obj_t arg1041_325;
{
obj_t pair_465;
if(PAIRP(rest_287)){
pair_465 = rest_287;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, rest_287, string1407___process, BINT(((long)8342)));
exit( -1 );}
arg1041_325 = CDR(pair_465);
}
test1008_291 = PAIRP(arg1041_325);
}
 else {
test1008_291 = ((bool_t)0);
}
}
if(test1008_291){
{
obj_t val_292;
{
obj_t pair_467;
if(PAIRP(rest_287)){
pair_467 = rest_287;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, rest_287, string1407___process, BINT(((long)8372)));
exit( -1 );}
{
obj_t arg1141_468;
arg1141_468 = CDR(pair_467);
{
obj_t pair_470;
if(PAIRP(arg1141_468)){
pair_470 = arg1141_468;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, arg1141_468, string1432___process, BINT(((long)7991)));
exit( -1 );}
val_292 = CAR(pair_470);
}
}
}
{
obj_t case_value_58_293;
{
obj_t pair_471;
if(PAIRP(rest_287)){
pair_471 = rest_287;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, rest_287, string1407___process, BINT(((long)8394)));
exit( -1 );}
case_value_58_293 = CAR(pair_471);
}
if((case_value_58_293==keyword1433___process)){
if(BOOLEANP(val_292)){
wait_280 = val_292;
}
 else {
debug_error_location_199___error(string1434___process, string1435___process, rest_287, string1436___process, BINT(((long)7610)));
}
}
 else {
if((case_value_58_293==keyword1437___process)){
if(BOOLEANP(val_292)){
fork_279 = val_292;
}
 else {
debug_error_location_199___error(string1434___process, string1435___process, rest_287, string1436___process, BINT(((long)7610)));
}
}
 else {
if((case_value_58_293==keyword1438___process)){
bool_t test_1077;
if(STRINGP(val_292)){
test_1077 = ((bool_t)1);
}
 else {
test_1077 = (val_292==keyword1439___process);
}
if(test_1077){
input_281 = val_292;
}
 else {
debug_error_location_199___error(string1434___process, string1435___process, rest_287, string1436___process, BINT(((long)7610)));
}
}
 else {
if((case_value_58_293==keyword1440___process)){
bool_t test_1085;
if(STRINGP(val_292)){
test_1085 = ((bool_t)1);
}
 else {
test_1085 = (val_292==keyword1439___process);
}
if(test_1085){
output_282 = val_292;
}
 else {
debug_error_location_199___error(string1434___process, string1435___process, rest_287, string1436___process, BINT(((long)7610)));
}
}
 else {
if((case_value_58_293==keyword1441___process)){
bool_t test_1093;
if(STRINGP(val_292)){
test_1093 = ((bool_t)1);
}
 else {
test_1093 = (val_292==keyword1439___process);
}
if(test_1093){
error_283 = val_292;
}
 else {
debug_error_location_199___error(string1434___process, string1435___process, rest_287, string1436___process, BINT(((long)7610)));
}
}
 else {
if((case_value_58_293==keyword1442___process)){
if(STRINGP(val_292)){
host_284 = val_292;
}
 else {
debug_error_location_199___error(string1434___process, string1435___process, rest_287, string1436___process, BINT(((long)7610)));
}
}
 else {
debug_error_location_199___error(string1434___process, string1435___process, rest_287, string1436___process, BINT(((long)7610)));
}
}
}
}
}
}
}
{
obj_t arg1034_318;
{
obj_t arg1035_319;
{
obj_t pair_524;
if(PAIRP(rest_287)){
pair_524 = rest_287;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, rest_287, string1407___process, BINT(((long)9004)));
exit( -1 );}
arg1035_319 = CDR(pair_524);
}
{
obj_t pair_525;
if(PAIRP(arg1035_319)){
pair_525 = arg1035_319;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, arg1035_319, string1407___process, BINT(((long)8998)));
exit( -1 );}
arg1034_318 = CDR(pair_525);
}
}
{
obj_t rest_1119;
rest_1119 = arg1034_318;
rest_287 = rest_1119;
goto loop_288;
}
}
}
}
 else {
bool_t test1036_320;
{
obj_t arg1039_323;
{
obj_t pair_526;
if(PAIRP(rest_287)){
pair_526 = rest_287;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, rest_287, string1407___process, BINT(((long)9034)));
exit( -1 );}
arg1039_323 = CAR(pair_526);
}
test1036_320 = STRINGP(arg1039_323);
}
if(test1036_320){
{
obj_t arg1037_321;
{
obj_t pair_528;
if(PAIRP(rest_287)){
pair_528 = rest_287;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, rest_287, string1407___process, BINT(((long)9069)));
exit( -1 );}
arg1037_321 = CAR(pair_528);
}
{
obj_t obj2_530;
obj2_530 = args_285;
args_285 = MAKE_PAIR(arg1037_321, obj2_530);
}
}
{
obj_t arg1038_322;
{
obj_t pair_531;
if(PAIRP(rest_287)){
pair_531 = rest_287;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1431___process, rest_287, string1407___process, BINT(((long)9099)));
exit( -1 );}
arg1038_322 = CDR(pair_531);
}
{
obj_t rest_1141;
rest_1141 = arg1038_322;
rest_287 = rest_1141;
goto loop_288;
}
}
}
 else {
aux1382_737 = debug_error_location_199___error(string1434___process, string1435___process, rest_287, string1436___process, BINT(((long)7610)));
}
}
}
{
bool_t test1383_738;
test1383_738 = PROCESSP(aux1382_737);
if(test1383_738){
aux1204_569 = aux1382_737;
}
 else {
bigloo_type_error_location_103___error(symbol1430___process, string1406___process, aux1382_737, string1407___process, BINT(((long)8155)));
exit( -1 );}
}
}
}
}
POP_TRACE();
return aux1204_569;
}
}
}
}


/* _run-process */obj_t _run_process_4___process(obj_t env_600, obj_t command_601, obj_t rest_602)
{
{
obj_t aux_1150;
if(STRINGP(command_601)){
aux_1150 = command_601;
}
 else {
bigloo_type_error_location_103___error(symbol1443___process, string1444___process, command_601, string1407___process, BINT(((long)7880)));
exit( -1 );}
return run_process_29___process(aux_1150, rest_602);
}
}


/* unregister-process */obj_t unregister_process_179___process(obj_t proc_16)
{
{
obj_t symbol1207_820;
symbol1207_820 = symbol1445___process;
{
PUSH_TRACE(symbol1207_820);
BUNSPEC;
{
obj_t aux1206_821;
aux1206_821 = c_unregister_process(proc_16);
POP_TRACE();
return aux1206_821;
}
}
}
}


/* _unregister-process */obj_t _unregister_process_206___process(obj_t env_603, obj_t proc_604)
{
{
obj_t proc_822;
{
bool_t test1397_750;
test1397_750 = PROCESSP(proc_604);
if(test1397_750){
proc_822 = proc_604;
}
 else {
bigloo_type_error_location_103___error(symbol1446___process, string1406___process, proc_604, string1407___process, BINT(((long)9373)));
exit( -1 );}
}
{
obj_t symbol1207_823;
symbol1207_823 = symbol1445___process;
{
PUSH_TRACE(symbol1207_823);
BUNSPEC;
{
obj_t aux1206_824;
aux1206_824 = c_unregister_process(proc_822);
POP_TRACE();
return aux1206_824;
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___process()
{
{
obj_t symbol1209_572;
symbol1209_572 = symbol1447___process;
{
PUSH_TRACE(symbol1209_572);
BUNSPEC;
{
obj_t aux1208_573;
aux1208_573 = module_initialization_70___error(((long)0), "__PROCESS");
POP_TRACE();
return aux1208_573;
}
}
}
}

