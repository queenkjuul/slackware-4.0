/*===========================================================================*/
/*   (Globalize/node.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
static let_var_6_t make_escaping_bindings_69_globalize_node(obj_t, node_t, variable_t);
static obj_t method_init_76_globalize_node();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static obj_t glo___241_globalize_node(obj_t, variable_t);
extern obj_t box_ref_242_ast_node;
extern obj_t the_closure_238_globalize_free(variable_t, obj_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_node(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_globalize_free(long, char *);
extern obj_t module_initialization_70_globalize_local__global_194(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static app_t a_make_procedure_166_globalize_node(local_t);
extern long list_length(obj_t);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
static obj_t make_sets_85_globalize_node(obj_t, obj_t, obj_t, variable_t);
extern obj_t let_fun_218_ast_node;
extern node_t node_globalize__229_globalize_node(node_t, variable_t, obj_t);
static obj_t imported_modules_init_94_globalize_node();
static bool_t celled__113_globalize_node(variable_t);
static obj_t celled_bindings_3_globalize_node(obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_globalize_node();
extern obj_t svar_ginfo_131_globalize_ginfo;
static obj_t _glo_2192_233_globalize_node(obj_t, obj_t, obj_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_globalize_node();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static make_box_202_t a_make_cell_117_globalize_node(node_t, variable_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static node_t glo__115_globalize_node(node_t, variable_t);
static app_t a_procedure_set__174_globalize_node(obj_t, obj_t, long, obj_t, variable_t);
extern obj_t local_ast_var;
static obj_t cell_formals_12_globalize_node(obj_t, node_t);
extern global_t the_global_201_globalize_local__global_194(local_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _node_globalize_2191_150_globalize_node(obj_t, obj_t, obj_t, obj_t);
static obj_t _glo__default1624_46_globalize_node(obj_t, obj_t, obj_t);
extern obj_t _procedure__226_type_cache;
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static node_t glo__default1624_187_globalize_node(node_t, variable_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_globalize_node = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t globalize_local_fun__50_globalize_node(local_t, variable_t);
static obj_t cnst_init_137_globalize_node();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[9];

DEFINE_STATIC_GENERIC(glo__env_172_globalize_node, _glo_2192_233_globalize_node2200, _glo_2192_233_globalize_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(node_globalize__env_218_globalize_node, _node_globalize_2191_150_globalize_node2201, _node_globalize_2191_150_globalize_node, 0L, 3);
DEFINE_STATIC_PROCEDURE(glo__default1624_env_151_globalize_node, _glo__default1624_46_globalize_node2202, _glo__default1624_46_globalize_node, 0L, 2);
DEFINE_STRING(string2194_globalize_node, string2194_globalize_node2203, "GLO!-DEFAULT1624 AUX PROCEDURE-SET! FOREIGN MAKE-VA-PROCEDURE MAKE-FX-PROCEDURE DONE (WRITE CELL-GLOBALIZE) CELL-GLOBALIZE ", 123);
DEFINE_STRING(string2193_globalize_node, string2193_globalize_node2204, "No method for this object", 25);


/* module-initialization */ obj_t 
module_initialization_70_globalize_node(long checksum_2846, char *from_2847)
{
   if (CBOOL(require_initialization_114_globalize_node))
     {
	require_initialization_114_globalize_node = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_node();
	cnst_init_137_globalize_node();
	imported_modules_init_94_globalize_node();
	method_init_76_globalize_node();
	toplevel_init_63_globalize_node();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_node()
{
   module_initialization_70___object(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_NODE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_node()
{
   {
      obj_t cnst_port_138_2838;
      cnst_port_138_2838 = open_input_string(string2194_globalize_node);
      {
	 long i_2839;
	 i_2839 = ((long) 8);
       loop_2840:
	 {
	    bool_t test2195_2841;
	    test2195_2841 = (i_2839 == ((long) -1));
	    if (test2195_2841)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2196_2842;
		    {
		       obj_t list2197_2843;
		       {
			  obj_t arg2198_2844;
			  arg2198_2844 = BNIL;
			  list2197_2843 = MAKE_PAIR(cnst_port_138_2838, arg2198_2844);
		       }
		       arg2196_2842 = read___reader(list2197_2843);
		    }
		    CNST_TABLE_SET(i_2839, arg2196_2842);
		 }
		 {
		    int aux_2845;
		    {
		       long aux_2865;
		       aux_2865 = (i_2839 - ((long) 1));
		       aux_2845 = (int) (aux_2865);
		    }
		    {
		       long i_2868;
		       i_2868 = (long) (aux_2845);
		       i_2839 = i_2868;
		       goto loop_2840;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_globalize_node()
{
   return BUNSPEC;
}


/* node-globalize! */ node_t 
node_globalize__229_globalize_node(node_t node_1, variable_t integrator_2, obj_t what_by__117_3)
{
   {
      obj_t celled_1063;
      {
	 obj_t aux_2870;
	 {
	    sfun_t obj_1964;
	    {
	       value_t aux_2871;
	       aux_2871 = (((variable_t) CREF(integrator_2))->value);
	       obj_1964 = (sfun_t) (aux_2871);
	    }
	    aux_2870 = (((sfun_t) CREF(obj_1964))->args);
	 }
	 celled_1063 = celled_bindings_3_globalize_node(aux_2870);
      }
      {
	 obj_t what_by__117_1064;
	 what_by__117_1064 = append_2_18___r4_pairs_and_lists_6_3(celled_1063, what_by__117_3);
	 {
	    {
	       obj_t l1557_1065;
	       l1557_1065 = what_by__117_1064;
	     lname1558_1066:
	       if (PAIRP(l1557_1065))
		 {
		    {
		       obj_t w_b_127_1068;
		       w_b_127_1068 = CAR(l1557_1065);
		       {
			  obj_t arg1666_1070;
			  arg1666_1070 = CDR(w_b_127_1068);
			  {
			     local_t obj_1969;
			     {
				obj_t aux_2881;
				aux_2881 = CAR(w_b_127_1068);
				obj_1969 = (local_t) (aux_2881);
			     }
			     ((((local_t) CREF(obj_1969))->fast_alpha_7) = ((obj_t) arg1666_1070), BUNSPEC);
			  }
		       }
		    }
		    {
		       obj_t l1557_2885;
		       l1557_2885 = CDR(l1557_1065);
		       l1557_1065 = l1557_2885;
		       goto lname1558_1066;
		    }
		 }
	       else
		 {
		    ((bool_t) 1);
		 }
	    }
	    {
	       obj_t res_1072;
	       {
		  node_t arg1672_1079;
		  arg1672_1079 = glo__115_globalize_node(node_1, integrator_2);
		  res_1072 = cell_formals_12_globalize_node(celled_1063, arg1672_1079);
	       }
	       {
		  obj_t l1559_1073;
		  l1559_1073 = what_by__117_1064;
		lname1560_1074:
		  if (PAIRP(l1559_1073))
		    {
		       {
			  local_t obj_1975;
			  {
			     obj_t aux_2891;
			     {
				obj_t aux_2892;
				aux_2892 = CAR(l1559_1073);
				aux_2891 = CAR(aux_2892);
			     }
			     obj_1975 = (local_t) (aux_2891);
			  }
			  ((((local_t) CREF(obj_1975))->fast_alpha_7) = ((obj_t) BUNSPEC), BUNSPEC);
		       }
		       {
			  obj_t l1559_2897;
			  l1559_2897 = CDR(l1559_1073);
			  l1559_1073 = l1559_2897;
			  goto lname1560_1074;
		       }
		    }
		  else
		    {
		       ((bool_t) 1);
		    }
	       }
	       return (node_t) (res_1072);
	    }
	 }
      }
   }
}


/* _node-globalize!2191 */ obj_t 
_node_globalize_2191_150_globalize_node(obj_t env_2828, obj_t node_2829, obj_t integrator_2830, obj_t what_by__117_2831)
{
   {
      node_t aux_2900;
      aux_2900 = node_globalize__229_globalize_node((node_t) (node_2829), (variable_t) (integrator_2830), what_by__117_2831);
      return (obj_t) (aux_2900);
   }
}


/* celled-bindings */ obj_t 
celled_bindings_3_globalize_node(obj_t formals_4)
{
   {
      obj_t celled_1081;
      obj_t formals_1082;
      celled_1081 = BNIL;
      formals_1082 = formals_4;
    loop_1083:
      if (NULLP(formals_1082))
	{
	   return celled_1081;
	}
      else
	{
	   bool_t test_2907;
	   {
	      variable_t aux_2908;
	      {
		 obj_t aux_2909;
		 aux_2909 = CAR(formals_1082);
		 aux_2908 = (variable_t) (aux_2909);
	      }
	      test_2907 = celled__113_globalize_node(aux_2908);
	   }
	   if (test_2907)
	     {
		{
		   local_t var_1087;
		   {
		      obj_t aux_2913;
		      {
			 local_t obj_1981;
			 {
			    obj_t aux_2914;
			    aux_2914 = CAR(formals_1082);
			    obj_1981 = (local_t) (aux_2914);
			 }
			 aux_2913 = (((local_t) CREF(obj_1981))->id);
		      }
		      var_1087 = make_local_svar_140_ast_local(aux_2913, (type_t) (_obj__252_type_cache));
		   }
		   {
		      obj_t o_n_168_1088;
		      {
			 obj_t aux_2922;
			 obj_t aux_2920;
			 aux_2922 = (obj_t) (var_1087);
			 aux_2920 = CAR(formals_1082);
			 o_n_168_1088 = MAKE_PAIR(aux_2920, aux_2922);
		      }
		      {
			 {
			    obj_t arg1678_1089;
			    arg1678_1089 = CNST_TABLE_REF(((long) 0));
			    ((((local_t) CREF(var_1087))->access) = ((obj_t) arg1678_1089), BUNSPEC);
			 }
			 {
			    bool_t arg1679_1090;
			    {
			       local_t obj_1988;
			       {
				  obj_t aux_2927;
				  aux_2927 = CAR(formals_1082);
				  obj_1988 = (local_t) (aux_2927);
			       }
			       arg1679_1090 = (((local_t) CREF(obj_1988))->user__32);
			    }
			    ((((local_t) CREF(var_1087))->user__32) = ((bool_t) arg1679_1090), BUNSPEC);
			 }
			 {
			    svar_ginfo_131_t obj1561_1092;
			    obj1561_1092 = ((svar_ginfo_131_t) ((((local_t) CREF(var_1087))->value)));
			    {
			       svar_ginfo_131_t arg1681_1093;
			       {
				  svar_ginfo_131_t res2164_2001;
				  {
				     svar_ginfo_131_t new1492_1996;
				     new1492_1996 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
				     ((((svar_ginfo_131_t) CREF(new1492_1996))->kaptured__204) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				     ((((svar_ginfo_131_t) CREF(new1492_1996))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
				     ((((svar_ginfo_131_t) CREF(new1492_1996))->mark) = ((long) ((long) -10)), BUNSPEC);
				     ((((svar_ginfo_131_t) CREF(new1492_1996))->celled__113) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				     res2164_2001 = new1492_1996;
				  }
				  arg1681_1093 = res2164_2001;
			       }
			       {
				  obj_t aux_2941;
				  object_t aux_2939;
				  aux_2941 = (obj_t) (arg1681_1093);
				  aux_2939 = (object_t) (obj1561_1092);
				  OBJECT_WIDENING_SET(aux_2939, aux_2941);
			       }
			    }
			    {
			       long arg1686_1098;
			       arg1686_1098 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
			       {
				  obj_t obj_2002;
				  obj_2002 = (obj_t) (obj1561_1092);
				  (((obj_t) CREF(obj_2002))->header = MAKE_HEADER(arg1686_1098, 0), BUNSPEC);
			       }
			    }
			    obj1561_1092;
			 }
			 {
			    obj_t arg1688_1099;
			    obj_t arg1689_1100;
			    arg1688_1099 = MAKE_PAIR(o_n_168_1088, celled_1081);
			    arg1689_1100 = CDR(formals_1082);
			    {
			       obj_t formals_2950;
			       obj_t celled_2949;
			       celled_2949 = arg1688_1099;
			       formals_2950 = arg1689_1100;
			       formals_1082 = formals_2950;
			       celled_1081 = celled_2949;
			       goto loop_1083;
			    }
			 }
		      }
		   }
		}
	     }
	   else
	     {
		{
		   obj_t formals_2951;
		   formals_2951 = CDR(formals_1082);
		   formals_1082 = formals_2951;
		   goto loop_1083;
		}
	     }
	}
   }
}


/* cell-formals */ obj_t 
cell_formals_12_globalize_node(obj_t celled_5, node_t body_6)
{
   {
      bool_t test1696_1106;
      test1696_1106 = NULLP(celled_5);
      if (test1696_1106)
	{
	   return (obj_t) (body_6);
	}
      else
	{
	   obj_t loc_1107;
	   loc_1107 = (((node_t) CREF(body_6))->loc);
	   {
	      obj_t arg1698_1109;
	      obj_t arg1700_1111;
	      arg1698_1109 = ____74_type_cache;
	      if (test1696_1106)
		{
		   arg1700_1111 = BNIL;
		}
	      else
		{
		   obj_t head1565_1115;
		   head1565_1115 = MAKE_PAIR(BNIL, BNIL);
		   {
		      obj_t l1563_1116;
		      obj_t tail1566_1117;
		      l1563_1116 = celled_5;
		      tail1566_1117 = head1565_1115;
		    lname1564_1118:
		      if (NULLP(l1563_1116))
			{
			   arg1700_1111 = CDR(head1565_1115);
			}
		      else
			{
			   obj_t newtail1567_1120;
			   {
			      obj_t arg1705_1122;
			      {
				 obj_t o_n_168_1124;
				 o_n_168_1124 = CAR(l1563_1116);
				 {
				    obj_t arg1707_1125;
				    make_box_202_t arg1708_1126;
				    arg1707_1125 = CDR(o_n_168_1124);
				    {
				       var_t arg1709_1127;
				       obj_t arg1710_1128;
				       {
					  obj_t arg1712_1130;
					  arg1712_1130 = ____74_type_cache;
					  {
					     var_t res2165_2028;
					     {
						type_t type_2019;
						variable_t variable_2020;
						type_2019 = (type_t) (arg1712_1130);
						{
						   obj_t aux_2965;
						   aux_2965 = CAR(o_n_168_1124);
						   variable_2020 = (variable_t) (aux_2965);
						}
						{
						   var_t new1211_2021;
						   new1211_2021 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						   {
						      long arg1933_2022;
						      arg1933_2022 = class_num_218___object(var_ast_node);
						      {
							 obj_t obj_2026;
							 obj_2026 = (obj_t) (new1211_2021);
							 (((obj_t) CREF(obj_2026))->header = MAKE_HEADER(arg1933_2022, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_2972;
						      aux_2972 = (object_t) (new1211_2021);
						      OBJECT_WIDENING_SET(aux_2972, BFALSE);
						   }
						   ((((var_t) CREF(new1211_2021))->loc) = ((obj_t) loc_1107), BUNSPEC);
						   ((((var_t) CREF(new1211_2021))->type) = ((type_t) type_2019), BUNSPEC);
						   ((((var_t) CREF(new1211_2021))->variable) = ((variable_t) variable_2020), BUNSPEC);
						   res2165_2028 = new1211_2021;
						}
					     }
					     arg1709_1127 = res2165_2028;
					  }
				       }
				       arg1710_1128 = CAR(o_n_168_1124);
				       arg1708_1126 = a_make_cell_117_globalize_node((node_t) (arg1709_1127), (variable_t) (arg1710_1128));
				    }
				    {
				       obj_t aux_2982;
				       aux_2982 = (obj_t) (arg1708_1126);
				       arg1705_1122 = MAKE_PAIR(arg1707_1125, aux_2982);
				    }
				 }
			      }
			      newtail1567_1120 = MAKE_PAIR(arg1705_1122, BNIL);
			   }
			   SET_CDR(tail1566_1117, newtail1567_1120);
			   {
			      obj_t tail1566_2989;
			      obj_t l1563_2987;
			      l1563_2987 = CDR(l1563_1116);
			      tail1566_2989 = newtail1567_1120;
			      tail1566_1117 = tail1566_2989;
			      l1563_1116 = l1563_2987;
			      goto lname1564_1118;
			   }
			}
		   }
		}
	      {
		 let_var_6_t res2166_2055;
		 {
		    type_t type_2038;
		    obj_t key_2040;
		    type_2038 = (type_t) (arg1698_1109);
		    key_2040 = BINT(((long) -1));
		    {
		       let_var_6_t new1370_2044;
		       new1370_2044 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
		       {
			  long arg1901_2045;
			  arg1901_2045 = class_num_218___object(let_var_6_ast_node);
			  {
			     obj_t obj_2053;
			     obj_2053 = (obj_t) (new1370_2044);
			     (((obj_t) CREF(obj_2053))->header = MAKE_HEADER(arg1901_2045, 0), BUNSPEC);
			  }
		       }
		       {
			  object_t aux_2996;
			  aux_2996 = (object_t) (new1370_2044);
			  OBJECT_WIDENING_SET(aux_2996, BFALSE);
		       }
		       ((((let_var_6_t) CREF(new1370_2044))->loc) = ((obj_t) loc_1107), BUNSPEC);
		       ((((let_var_6_t) CREF(new1370_2044))->type) = ((type_t) type_2038), BUNSPEC);
		       ((((let_var_6_t) CREF(new1370_2044))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		       ((((let_var_6_t) CREF(new1370_2044))->key) = ((obj_t) key_2040), BUNSPEC);
		       ((((let_var_6_t) CREF(new1370_2044))->bindings) = ((obj_t) arg1700_1111), BUNSPEC);
		       ((((let_var_6_t) CREF(new1370_2044))->body) = ((node_t) body_6), BUNSPEC);
		       ((((let_var_6_t) CREF(new1370_2044))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		       res2166_2055 = new1370_2044;
		    }
		 }
		 return (obj_t) (res2166_2055);
	      }
	   }
	}
   }
}


/* a-make-cell */ make_box_202_t 
a_make_cell_117_globalize_node(node_t node_7, variable_t variable_8)
{
   {
      obj_t arg1717_1135;
      arg1717_1135 = CNST_TABLE_REF(((long) 0));
      {
	 local_t obj_2056;
	 obj_2056 = (local_t) (variable_8);
	 ((((local_t) CREF(obj_2056))->access) = ((obj_t) arg1717_1135), BUNSPEC);
      }
   }
   {
      svar_ginfo_131_t obj_2059;
      {
	 value_t aux_3010;
	 aux_3010 = (((variable_t) CREF(variable_8))->value);
	 obj_2059 = (svar_ginfo_131_t) (aux_3010);
      }
      {
	 obj_t aux_3013;
	 {
	    object_t aux_3014;
	    aux_3014 = (object_t) (obj_2059);
	    aux_3013 = OBJECT_WIDENING(aux_3014);
	 }
	 ((((svar_ginfo_131_t) CREF(aux_3013))->celled__113) = ((bool_t) ((bool_t) 1)), BUNSPEC);
      }
   }
   {
      obj_t arg1720_1137;
      obj_t arg1721_1138;
      arg1720_1137 = (((node_t) CREF(node_7))->loc);
      arg1721_1138 = ____74_type_cache;
      {
	 make_box_202_t res2167_2076;
	 {
	    type_t type_2063;
	    obj_t key_2065;
	    type_2063 = (type_t) (arg1721_1138);
	    key_2065 = BINT(((long) -1));
	    {
	       make_box_202_t new1406_2067;
	       new1406_2067 = ((make_box_202_t) BREF(GC_MALLOC(sizeof(struct make_box_202))));
	       {
		  long arg1895_2068;
		  arg1895_2068 = class_num_218___object(make_box_202_ast_node);
		  {
		     obj_t obj_2074;
		     obj_2074 = (obj_t) (new1406_2067);
		     (((obj_t) CREF(obj_2074))->header = MAKE_HEADER(arg1895_2068, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_3025;
		  aux_3025 = (object_t) (new1406_2067);
		  OBJECT_WIDENING_SET(aux_3025, BFALSE);
	       }
	       ((((make_box_202_t) CREF(new1406_2067))->loc) = ((obj_t) arg1720_1137), BUNSPEC);
	       ((((make_box_202_t) CREF(new1406_2067))->type) = ((type_t) type_2063), BUNSPEC);
	       ((((make_box_202_t) CREF(new1406_2067))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
	       ((((make_box_202_t) CREF(new1406_2067))->key) = ((obj_t) key_2065), BUNSPEC);
	       ((((make_box_202_t) CREF(new1406_2067))->value) = ((node_t) node_7), BUNSPEC);
	       res2167_2076 = new1406_2067;
	    }
	 }
	 return res2167_2076;
      }
   }
}


/* celled? */ bool_t 
celled__113_globalize_node(variable_t variable_9)
{
   {
      bool_t _andtest_1571_1141;
      _andtest_1571_1141 = is_a__118___object((obj_t) (variable_9), local_ast_var);
      if (_andtest_1571_1141)
	{
	   bool_t _andtest_1572_1142;
	   {
	      obj_t aux_3036;
	      {
		 value_t aux_3037;
		 aux_3037 = (((variable_t) CREF(variable_9))->value);
		 aux_3036 = (obj_t) (aux_3037);
	      }
	      _andtest_1572_1142 = is_a__118___object(aux_3036, svar_ginfo_131_globalize_ginfo);
	   }
	   if (_andtest_1572_1142)
	     {
		bool_t _ortest_1573_1143;
		{
		   svar_ginfo_131_t obj_2081;
		   {
		      value_t aux_3042;
		      aux_3042 = (((variable_t) CREF(variable_9))->value);
		      obj_2081 = (svar_ginfo_131_t) (aux_3042);
		   }
		   {
		      obj_t aux_3045;
		      {
			 object_t aux_3046;
			 aux_3046 = (object_t) (obj_2081);
			 aux_3045 = OBJECT_WIDENING(aux_3046);
		      }
		      _ortest_1573_1143 = (((svar_ginfo_131_t) CREF(aux_3045))->celled__113);
		   }
		}
		if (_ortest_1573_1143)
		  {
		     return _ortest_1573_1143;
		  }
		else
		  {
		     bool_t test_3051;
		     {
			obj_t aux_3052;
			aux_3052 = memq___r4_pairs_and_lists_6_3((((variable_t) CREF(variable_9))->access), CNST_TABLE_REF(((long) 1)));
			test_3051 = CBOOL(aux_3052);
		     }
		     if (test_3051)
		       {
			  svar_ginfo_131_t obj_2084;
			  {
			     value_t aux_3057;
			     aux_3057 = (((variable_t) CREF(variable_9))->value);
			     obj_2084 = (svar_ginfo_131_t) (aux_3057);
			  }
			  {
			     obj_t aux_3060;
			     {
				object_t aux_3061;
				aux_3061 = (object_t) (obj_2084);
				aux_3060 = OBJECT_WIDENING(aux_3061);
			     }
			     return (((svar_ginfo_131_t) CREF(aux_3060))->kaptured__204);
			  }
		       }
		     else
		       {
			  return ((bool_t) 0);
		       }
		  }
	     }
	   else
	     {
		return ((bool_t) 0);
	     }
	}
      else
	{
	   return ((bool_t) 0);
	}
   }
}


/* glo*! */ obj_t 
glo___241_globalize_node(obj_t node__221_56, variable_t integrator_57)
{
   {
      obj_t node__221_1150;
      node__221_1150 = node__221_56;
    loop_1151:
      if (NULLP(node__221_1150))
	{
	   return CNST_TABLE_REF(((long) 2));
	}
      else
	{
	   {
	      node_t arg1730_1153;
	      {
		 node_t aux_3068;
		 {
		    obj_t aux_3069;
		    aux_3069 = CAR(node__221_1150);
		    aux_3068 = (node_t) (aux_3069);
		 }
		 arg1730_1153 = glo__115_globalize_node(aux_3068, integrator_57);
	      }
	      {
		 obj_t aux_3073;
		 aux_3073 = (obj_t) (arg1730_1153);
		 SET_CAR(node__221_1150, aux_3073);
	      }
	   }
	   {
	      obj_t node__221_3076;
	      node__221_3076 = CDR(node__221_1150);
	      node__221_1150 = node__221_3076;
	      goto loop_1151;
	   }
	}
   }
}


/* make-escaping-bindings */ let_var_6_t 
make_escaping_bindings_69_globalize_node(obj_t ebindings_58, node_t node_59, variable_t integrator_60)
{
   {
      obj_t ebindings_1156;
      obj_t bindings_1157;
      obj_t sets_1158;
      ebindings_1156 = ebindings_58;
      bindings_1157 = BNIL;
      sets_1158 = BNIL;
    loop_1159:
      if (NULLP(ebindings_1156))
	{
	   obj_t arg1740_1163;
	   obj_t arg1743_1164;
	   obj_t arg1746_1167;
	   arg1740_1163 = (((node_t) CREF(node_59))->loc);
	   arg1743_1164 = ____74_type_cache;
	   if (NULLP(sets_1158))
	     {
		arg1746_1167 = (obj_t) (node_59);
	     }
	   else
	     {
		obj_t arg1748_1169;
		obj_t arg1749_1170;
		obj_t arg1755_1172;
		arg1748_1169 = (((node_t) CREF(node_59))->loc);
		arg1749_1170 = ____74_type_cache;
		{
		   obj_t arg1758_1173;
		   {
		      obj_t list1759_1174;
		      {
			 obj_t aux_3085;
			 aux_3085 = (obj_t) (node_59);
			 list1759_1174 = MAKE_PAIR(aux_3085, BNIL);
		      }
		      arg1758_1173 = list1759_1174;
		   }
		   arg1755_1172 = append_2_18___r4_pairs_and_lists_6_3(sets_1158, arg1758_1173);
		}
		{
		   sequence_t res2168_2109;
		   {
		      type_t type_2096;
		      obj_t key_2098;
		      type_2096 = (type_t) (arg1749_1170);
		      key_2098 = BINT(((long) -1));
		      {
			 sequence_t new1234_2100;
			 new1234_2100 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
			 {
			    long arg1927_2101;
			    arg1927_2101 = class_num_218___object(sequence_ast_node);
			    {
			       obj_t obj_2107;
			       obj_2107 = (obj_t) (new1234_2100);
			       (((obj_t) CREF(obj_2107))->header = MAKE_HEADER(arg1927_2101, 0), BUNSPEC);
			    }
			 }
			 {
			    object_t aux_3095;
			    aux_3095 = (object_t) (new1234_2100);
			    OBJECT_WIDENING_SET(aux_3095, BFALSE);
			 }
			 ((((sequence_t) CREF(new1234_2100))->loc) = ((obj_t) arg1748_1169), BUNSPEC);
			 ((((sequence_t) CREF(new1234_2100))->type) = ((type_t) type_2096), BUNSPEC);
			 ((((sequence_t) CREF(new1234_2100))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
			 ((((sequence_t) CREF(new1234_2100))->key) = ((obj_t) key_2098), BUNSPEC);
			 ((((sequence_t) CREF(new1234_2100))->nodes) = ((obj_t) arg1755_1172), BUNSPEC);
			 res2168_2109 = new1234_2100;
		      }
		   }
		   arg1746_1167 = (obj_t) (res2168_2109);
		}
	     }
	   {
	      let_var_6_t res2169_2128;
	      {
		 type_t type_2111;
		 obj_t key_2113;
		 node_t body_2115;
		 type_2111 = (type_t) (arg1743_1164);
		 key_2113 = BINT(((long) -1));
		 body_2115 = (node_t) (arg1746_1167);
		 {
		    let_var_6_t new1370_2117;
		    new1370_2117 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
		    {
		       long arg1901_2118;
		       arg1901_2118 = class_num_218___object(let_var_6_ast_node);
		       {
			  obj_t obj_2126;
			  obj_2126 = (obj_t) (new1370_2117);
			  (((obj_t) CREF(obj_2126))->header = MAKE_HEADER(arg1901_2118, 0), BUNSPEC);
		       }
		    }
		    {
		       object_t aux_3111;
		       aux_3111 = (object_t) (new1370_2117);
		       OBJECT_WIDENING_SET(aux_3111, BFALSE);
		    }
		    ((((let_var_6_t) CREF(new1370_2117))->loc) = ((obj_t) arg1740_1163), BUNSPEC);
		    ((((let_var_6_t) CREF(new1370_2117))->type) = ((type_t) type_2111), BUNSPEC);
		    ((((let_var_6_t) CREF(new1370_2117))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		    ((((let_var_6_t) CREF(new1370_2117))->key) = ((obj_t) key_2113), BUNSPEC);
		    ((((let_var_6_t) CREF(new1370_2117))->bindings) = ((obj_t) bindings_1157), BUNSPEC);
		    ((((let_var_6_t) CREF(new1370_2117))->body) = ((node_t) body_2115), BUNSPEC);
		    ((((let_var_6_t) CREF(new1370_2117))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		    res2169_2128 = new1370_2117;
		 }
	      }
	      return res2169_2128;
	   }
	}
      else
	{
	   obj_t local_1176;
	   local_1176 = CAR(ebindings_1156);
	   {
	      obj_t new_1177;
	      new_1177 = the_closure_238_globalize_free((variable_t) (local_1176), (((node_t) CREF(node_59))->loc));
	      {
		 obj_t nsets_1178;
		 {
		    obj_t aux_3125;
		    {
		       sfun_ginfo_98_t obj_2133;
		       {
			  value_t aux_3127;
			  {
			     local_t obj_2132;
			     obj_2132 = (local_t) (local_1176);
			     aux_3127 = (((local_t) CREF(obj_2132))->value);
			  }
			  obj_2133 = (sfun_ginfo_98_t) (aux_3127);
		       }
		       {
			  obj_t aux_3131;
			  {
			     object_t aux_3132;
			     aux_3132 = (object_t) (obj_2133);
			     aux_3131 = OBJECT_WIDENING(aux_3132);
			  }
			  aux_3125 = (((sfun_ginfo_98_t) CREF(aux_3131))->kaptured);
		       }
		    }
		    nsets_1178 = make_sets_85_globalize_node(new_1177, (((node_t) CREF(node_59))->loc), aux_3125, integrator_60);
		 }
		 {
		    {
		       obj_t arg1761_1179;
		       obj_t arg1762_1180;
		       obj_t arg1765_1181;
		       arg1761_1179 = CDR(ebindings_1156);
		       {
			  obj_t arg1766_1182;
			  {
			     app_t arg1767_1183;
			     arg1767_1183 = a_make_procedure_166_globalize_node((local_t) (local_1176));
			     {
				obj_t aux_3140;
				aux_3140 = (obj_t) (arg1767_1183);
				arg1766_1182 = MAKE_PAIR(new_1177, aux_3140);
			     }
			  }
			  arg1762_1180 = MAKE_PAIR(arg1766_1182, bindings_1157);
		       }
		       if (NULLP(nsets_1178))
			 {
			    arg1765_1181 = sets_1158;
			 }
		       else
			 {
			    arg1765_1181 = MAKE_PAIR(nsets_1178, sets_1158);
			 }
		       {
			  obj_t sets_3149;
			  obj_t bindings_3148;
			  obj_t ebindings_3147;
			  ebindings_3147 = arg1761_1179;
			  bindings_3148 = arg1762_1180;
			  sets_3149 = arg1765_1181;
			  sets_1158 = sets_3149;
			  bindings_1157 = bindings_3148;
			  ebindings_1156 = ebindings_3147;
			  goto loop_1159;
		       }
		    }
		 }
	      }
	   }
	}
   }
}


/* globalize-local-fun! */ obj_t 
globalize_local_fun__50_globalize_node(local_t local_61, variable_t integrator_62)
{
   {
      value_t fun_1189;
      fun_1189 = (((local_t) CREF(local_61))->value);
      {
	 obj_t obody_1190;
	 {
	    sfun_t obj_2143;
	    obj_2143 = (sfun_t) (fun_1189);
	    obody_1190 = (((sfun_t) CREF(obj_2143))->body);
	 }
	 {
	    {
	       bool_t test_3153;
	       {
		  obj_t aux_3156;
		  obj_t aux_3154;
		  aux_3156 = (obj_t) (integrator_62);
		  aux_3154 = (obj_t) (local_61);
		  test_3153 = (aux_3154 == aux_3156);
	       }
	       if (test_3153)
		 {
		    node_t arg1774_1192;
		    arg1774_1192 = glo__115_globalize_node((node_t) (obody_1190), integrator_62);
		    {
		       sfun_t obj_2146;
		       obj_t val1140_2147;
		       obj_2146 = (sfun_t) (fun_1189);
		       val1140_2147 = (obj_t) (arg1774_1192);
		       return ((((sfun_t) CREF(obj_2146))->body) = ((obj_t) val1140_2147), BUNSPEC);
		    }
		 }
	       else
		 {
		    obj_t celled_1193;
		    {
		       obj_t aux_3164;
		       {
			  sfun_t obj_2148;
			  obj_2148 = (sfun_t) (fun_1189);
			  aux_3164 = (((sfun_t) CREF(obj_2148))->args);
		       }
		       celled_1193 = celled_bindings_3_globalize_node(aux_3164);
		    }
		    {
		       obj_t l1609_1194;
		       l1609_1194 = celled_1193;
		     lname1610_1195:
		       if (PAIRP(l1609_1194))
			 {
			    {
			       obj_t w_b_127_1197;
			       w_b_127_1197 = CAR(l1609_1194);
			       {
				  obj_t arg1777_1199;
				  arg1777_1199 = CDR(w_b_127_1197);
				  {
				     local_t obj_2153;
				     {
					obj_t aux_3172;
					aux_3172 = CAR(w_b_127_1197);
					obj_2153 = (local_t) (aux_3172);
				     }
				     ((((local_t) CREF(obj_2153))->fast_alpha_7) = ((obj_t) arg1777_1199), BUNSPEC);
				  }
			       }
			    }
			    {
			       obj_t l1609_3176;
			       l1609_3176 = CDR(l1609_1194);
			       l1609_1194 = l1609_3176;
			       goto lname1610_1195;
			    }
			 }
		       else
			 {
			    ((bool_t) 1);
			 }
		    }
		    {
		       node_t nbody1_1201;
		       nbody1_1201 = glo__115_globalize_node((node_t) (obody_1190), integrator_62);
		       {
			  obj_t nbody2_1202;
			  nbody2_1202 = cell_formals_12_globalize_node(celled_1193, nbody1_1201);
			  {
			     {
				obj_t l1611_1203;
				l1611_1203 = celled_1193;
			      lname1612_1204:
				if (PAIRP(l1611_1203))
				  {
				     {
					local_t obj_2159;
					{
					   obj_t aux_3183;
					   {
					      obj_t aux_3184;
					      aux_3184 = CAR(l1611_1203);
					      aux_3183 = CAR(aux_3184);
					   }
					   obj_2159 = (local_t) (aux_3183);
					}
					((((local_t) CREF(obj_2159))->fast_alpha_7) = ((obj_t) BUNSPEC), BUNSPEC);
				     }
				     {
					obj_t l1611_3189;
					l1611_3189 = CDR(l1611_1203);
					l1611_1203 = l1611_3189;
					goto lname1612_1204;
				     }
				  }
				else
				  {
				     ((bool_t) 1);
				  }
			     }
			     {
				sfun_t obj_2162;
				obj_2162 = (sfun_t) (fun_1189);
				return ((((sfun_t) CREF(obj_2162))->body) = ((obj_t) nbody2_1202), BUNSPEC);
			     }
			  }
		       }
		    }
		 }
	    }
	 }
      }
   }
}


/* a-make-procedure */ app_t 
a_make_procedure_166_globalize_node(local_t local_63)
{
   {
      long arity_1211;
      {
	 sfun_t obj_2165;
	 {
	    value_t aux_3193;
	    aux_3193 = (((local_t) CREF(local_63))->value);
	    obj_2165 = (sfun_t) (aux_3193);
	 }
	 arity_1211 = (((sfun_t) CREF(obj_2165))->arity);
      }
      {
	 obj_t make_p_144_1214;
	 if ((arity_1211 >= ((long) 0)))
	   {
	      make_p_144_1214 = CNST_TABLE_REF(((long) 3));
	   }
	 else
	   {
	      make_p_144_1214 = CNST_TABLE_REF(((long) 4));
	   }
	 {
	    {
	       obj_t arg1788_1216;
	       var_t arg1790_1218;
	       obj_t arg1791_1219;
	       arg1788_1216 = ____74_type_cache;
	       {
		  obj_t arg1793_1221;
		  obj_t arg1794_1222;
		  arg1793_1221 = ____74_type_cache;
		  {
		     obj_t list1796_1224;
		     {
			obj_t aux_3201;
			aux_3201 = CNST_TABLE_REF(((long) 5));
			list1796_1224 = MAKE_PAIR(aux_3201, BNIL);
		     }
		     arg1794_1222 = find_global_223_ast_env(make_p_144_1214, list1796_1224);
		  }
		  {
		     var_t res2170_2180;
		     {
			type_t type_2171;
			variable_t variable_2172;
			type_2171 = (type_t) (arg1793_1221);
			variable_2172 = (variable_t) (arg1794_1222);
			{
			   var_t new1211_2173;
			   new1211_2173 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			   {
			      long arg1933_2174;
			      arg1933_2174 = class_num_218___object(var_ast_node);
			      {
				 obj_t obj_2178;
				 obj_2178 = (obj_t) (new1211_2173);
				 (((obj_t) CREF(obj_2178))->header = MAKE_HEADER(arg1933_2174, 0), BUNSPEC);
			      }
			   }
			   {
			      object_t aux_3211;
			      aux_3211 = (object_t) (new1211_2173);
			      OBJECT_WIDENING_SET(aux_3211, BFALSE);
			   }
			   ((((var_t) CREF(new1211_2173))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
			   ((((var_t) CREF(new1211_2173))->type) = ((type_t) type_2171), BUNSPEC);
			   ((((var_t) CREF(new1211_2173))->variable) = ((variable_t) variable_2172), BUNSPEC);
			   res2170_2180 = new1211_2173;
			}
		     }
		     arg1790_1218 = res2170_2180;
		  }
	       }
	       {
		  var_t arg1799_1226;
		  atom_t arg1800_1227;
		  atom_t arg1802_1228;
		  {
		     obj_t arg1808_1234;
		     global_t arg1809_1235;
		     arg1808_1234 = ____74_type_cache;
		     arg1809_1235 = the_global_201_globalize_local__global_194(local_63);
		     {
			var_t res2171_2191;
			{
			   type_t type_2182;
			   variable_t variable_2183;
			   type_2182 = (type_t) (arg1808_1234);
			   variable_2183 = (variable_t) (arg1809_1235);
			   {
			      var_t new1211_2184;
			      new1211_2184 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			      {
				 long arg1933_2185;
				 arg1933_2185 = class_num_218___object(var_ast_node);
				 {
				    obj_t obj_2189;
				    obj_2189 = (obj_t) (new1211_2184);
				    (((obj_t) CREF(obj_2189))->header = MAKE_HEADER(arg1933_2185, 0), BUNSPEC);
				 }
			      }
			      {
				 object_t aux_3224;
				 aux_3224 = (object_t) (new1211_2184);
				 OBJECT_WIDENING_SET(aux_3224, BFALSE);
			      }
			      ((((var_t) CREF(new1211_2184))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
			      ((((var_t) CREF(new1211_2184))->type) = ((type_t) type_2182), BUNSPEC);
			      ((((var_t) CREF(new1211_2184))->variable) = ((variable_t) variable_2183), BUNSPEC);
			      res2171_2191 = new1211_2184;
			   }
			}
			arg1799_1226 = res2171_2191;
		     }
		  }
		  {
		     obj_t arg1811_1237;
		     arg1811_1237 = ____74_type_cache;
		     {
			atom_t res2172_2202;
			{
			   type_t type_2193;
			   obj_t value_2194;
			   type_2193 = (type_t) (arg1811_1237);
			   value_2194 = BINT(arity_1211);
			   {
			      atom_t new1203_2195;
			      new1203_2195 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
			      {
				 long arg1935_2196;
				 arg1935_2196 = class_num_218___object(atom_ast_node);
				 {
				    obj_t obj_2200;
				    obj_2200 = (obj_t) (new1203_2195);
				    (((obj_t) CREF(obj_2200))->header = MAKE_HEADER(arg1935_2196, 0), BUNSPEC);
				 }
			      }
			      {
				 object_t aux_3236;
				 aux_3236 = (object_t) (new1203_2195);
				 OBJECT_WIDENING_SET(aux_3236, BFALSE);
			      }
			      ((((atom_t) CREF(new1203_2195))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
			      ((((atom_t) CREF(new1203_2195))->type) = ((type_t) type_2193), BUNSPEC);
			      ((((atom_t) CREF(new1203_2195))->value) = ((obj_t) value_2194), BUNSPEC);
			      res2172_2202 = new1203_2195;
			   }
			}
			arg1800_1227 = res2172_2202;
		     }
		  }
		  {
		     obj_t arg1814_1240;
		     arg1814_1240 = ____74_type_cache;
		     {
			atom_t res2173_2213;
			{
			   type_t type_2204;
			   obj_t value_2205;
			   type_2204 = (type_t) (arg1814_1240);
			   {
			      long aux_3243;
			      {
				 obj_t aux_3244;
				 {
				    sfun_ginfo_98_t obj_2167;
				    {
				       value_t aux_3245;
				       aux_3245 = (((local_t) CREF(local_63))->value);
				       obj_2167 = (sfun_ginfo_98_t) (aux_3245);
				    }
				    {
				       obj_t aux_3248;
				       {
					  object_t aux_3249;
					  aux_3249 = (object_t) (obj_2167);
					  aux_3248 = OBJECT_WIDENING(aux_3249);
				       }
				       aux_3244 = (((sfun_ginfo_98_t) CREF(aux_3248))->kaptured);
				    }
				 }
				 aux_3243 = list_length(aux_3244);
			      }
			      value_2205 = BINT(aux_3243);
			   }
			   {
			      atom_t new1203_2206;
			      new1203_2206 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
			      {
				 long arg1935_2207;
				 arg1935_2207 = class_num_218___object(atom_ast_node);
				 {
				    obj_t obj_2211;
				    obj_2211 = (obj_t) (new1203_2206);
				    (((obj_t) CREF(obj_2211))->header = MAKE_HEADER(arg1935_2207, 0), BUNSPEC);
				 }
			      }
			      {
				 object_t aux_3259;
				 aux_3259 = (object_t) (new1203_2206);
				 OBJECT_WIDENING_SET(aux_3259, BFALSE);
			      }
			      ((((atom_t) CREF(new1203_2206))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
			      ((((atom_t) CREF(new1203_2206))->type) = ((type_t) type_2204), BUNSPEC);
			      ((((atom_t) CREF(new1203_2206))->value) = ((obj_t) value_2205), BUNSPEC);
			      res2173_2213 = new1203_2206;
			   }
			}
			arg1802_1228 = res2173_2213;
		     }
		  }
		  {
		     obj_t list1803_1229;
		     {
			obj_t arg1804_1230;
			{
			   obj_t arg1805_1231;
			   {
			      obj_t aux_3265;
			      aux_3265 = (obj_t) (arg1802_1228);
			      arg1805_1231 = MAKE_PAIR(aux_3265, BNIL);
			   }
			   {
			      obj_t aux_3268;
			      aux_3268 = (obj_t) (arg1800_1227);
			      arg1804_1230 = MAKE_PAIR(aux_3268, arg1805_1231);
			   }
			}
			{
			   obj_t aux_3271;
			   aux_3271 = (obj_t) (arg1799_1226);
			   list1803_1229 = MAKE_PAIR(aux_3271, arg1804_1230);
			}
		     }
		     arg1791_1219 = list1803_1229;
		  }
	       }
	       {
		  app_t res2174_2233;
		  {
		     type_t type_2216;
		     obj_t key_2218;
		     type_2216 = (type_t) (arg1788_1216);
		     key_2218 = BINT(((long) -1));
		     {
			app_t new1245_2222;
			new1245_2222 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
			{
			   long arg1924_2223;
			   arg1924_2223 = class_num_218___object(app_ast_node);
			   {
			      obj_t obj_2231;
			      obj_2231 = (obj_t) (new1245_2222);
			      (((obj_t) CREF(obj_2231))->header = MAKE_HEADER(arg1924_2223, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_3280;
			   aux_3280 = (object_t) (new1245_2222);
			   OBJECT_WIDENING_SET(aux_3280, BFALSE);
			}
			((((app_t) CREF(new1245_2222))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
			((((app_t) CREF(new1245_2222))->type) = ((type_t) type_2216), BUNSPEC);
			((((app_t) CREF(new1245_2222))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
			((((app_t) CREF(new1245_2222))->key) = ((obj_t) key_2218), BUNSPEC);
			((((app_t) CREF(new1245_2222))->fun) = ((var_t) arg1790_1218), BUNSPEC);
			((((app_t) CREF(new1245_2222))->args) = ((obj_t) arg1791_1219), BUNSPEC);
			((((app_t) CREF(new1245_2222))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
			res2174_2233 = new1245_2222;
		     }
		  }
		  return res2174_2233;
	       }
	    }
	 }
      }
   }
}


/* make-sets */ obj_t 
make_sets_85_globalize_node(obj_t new_64, obj_t loc_65, obj_t kaptured_66, variable_t integrator_67)
{
   if (NULLP(kaptured_66))
     {
	return BNIL;
     }
   else
     {
	obj_t arg1821_1246;
	obj_t arg1823_1248;
	arg1821_1246 = ____74_type_cache;
	{
	   obj_t kaptured_1249;
	   long indice_1250;
	   obj_t sets_1251;
	   kaptured_1249 = kaptured_66;
	   indice_1250 = ((long) 0);
	   sets_1251 = BNIL;
	 loop_1252:
	   if (NULLP(kaptured_1249))
	     {
		arg1823_1248 = reverse__39___r4_pairs_and_lists_6_3(sets_1251);
	     }
	   else
	     {
		obj_t arg1829_1256;
		long arg1830_1257;
		obj_t arg1831_1258;
		arg1829_1256 = CDR(kaptured_1249);
		arg1830_1257 = (indice_1250 + ((long) 1));
		{
		   app_t arg1832_1259;
		   arg1832_1259 = a_procedure_set__174_globalize_node(loc_65, new_64, indice_1250, CAR(kaptured_1249), integrator_67);
		   {
		      obj_t aux_3299;
		      aux_3299 = (obj_t) (arg1832_1259);
		      arg1831_1258 = MAKE_PAIR(aux_3299, sets_1251);
		   }
		}
		{
		   obj_t sets_3304;
		   long indice_3303;
		   obj_t kaptured_3302;
		   kaptured_3302 = arg1829_1256;
		   indice_3303 = arg1830_1257;
		   sets_3304 = arg1831_1258;
		   sets_1251 = sets_3304;
		   indice_1250 = indice_3303;
		   kaptured_1249 = kaptured_3302;
		   goto loop_1252;
		}
	     }
	}
	{
	   sequence_t res2175_2256;
	   {
	      type_t type_2243;
	      obj_t key_2245;
	      type_2243 = (type_t) (arg1821_1246);
	      key_2245 = BINT(((long) -1));
	      {
		 sequence_t new1234_2247;
		 new1234_2247 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
		 {
		    long arg1927_2248;
		    arg1927_2248 = class_num_218___object(sequence_ast_node);
		    {
		       obj_t obj_2254;
		       obj_2254 = (obj_t) (new1234_2247);
		       (((obj_t) CREF(obj_2254))->header = MAKE_HEADER(arg1927_2248, 0), BUNSPEC);
		    }
		 }
		 {
		    object_t aux_3311;
		    aux_3311 = (object_t) (new1234_2247);
		    OBJECT_WIDENING_SET(aux_3311, BFALSE);
		 }
		 ((((sequence_t) CREF(new1234_2247))->loc) = ((obj_t) loc_65), BUNSPEC);
		 ((((sequence_t) CREF(new1234_2247))->type) = ((type_t) type_2243), BUNSPEC);
		 ((((sequence_t) CREF(new1234_2247))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		 ((((sequence_t) CREF(new1234_2247))->key) = ((obj_t) key_2245), BUNSPEC);
		 ((((sequence_t) CREF(new1234_2247))->nodes) = ((obj_t) arg1823_1248), BUNSPEC);
		 res2175_2256 = new1234_2247;
	      }
	   }
	   return (obj_t) (res2175_2256);
	}
     }
}


/* a-procedure-set! */ app_t 
a_procedure_set__174_globalize_node(obj_t loc_68, obj_t new_69, long indice_70, obj_t kaptured_71, variable_t integrator_72)
{
   {
      obj_t var_1290;
      {
	 obj_t arg1835_1263;
	 var_t arg1837_1265;
	 obj_t arg1838_1266;
	 arg1835_1263 = ____74_type_cache;
	 {
	    obj_t arg1842_1268;
	    obj_t arg1843_1269;
	    arg1842_1268 = ____74_type_cache;
	    {
	       obj_t arg1847_1270;
	       arg1847_1270 = CNST_TABLE_REF(((long) 6));
	       {
		  obj_t list1849_1272;
		  {
		     obj_t aux_3321;
		     aux_3321 = CNST_TABLE_REF(((long) 5));
		     list1849_1272 = MAKE_PAIR(aux_3321, BNIL);
		  }
		  arg1843_1269 = find_global_223_ast_env(arg1847_1270, list1849_1272);
	       }
	    }
	    {
	       var_t res2176_2267;
	       {
		  type_t type_2258;
		  variable_t variable_2259;
		  type_2258 = (type_t) (arg1842_1268);
		  variable_2259 = (variable_t) (arg1843_1269);
		  {
		     var_t new1211_2260;
		     new1211_2260 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
		     {
			long arg1933_2261;
			arg1933_2261 = class_num_218___object(var_ast_node);
			{
			   obj_t obj_2265;
			   obj_2265 = (obj_t) (new1211_2260);
			   (((obj_t) CREF(obj_2265))->header = MAKE_HEADER(arg1933_2261, 0), BUNSPEC);
			}
		     }
		     {
			object_t aux_3331;
			aux_3331 = (object_t) (new1211_2260);
			OBJECT_WIDENING_SET(aux_3331, BFALSE);
		     }
		     ((((var_t) CREF(new1211_2260))->loc) = ((obj_t) loc_68), BUNSPEC);
		     ((((var_t) CREF(new1211_2260))->type) = ((type_t) type_2258), BUNSPEC);
		     ((((var_t) CREF(new1211_2260))->variable) = ((variable_t) variable_2259), BUNSPEC);
		     res2176_2267 = new1211_2260;
		  }
	       }
	       arg1837_1265 = res2176_2267;
	    }
	 }
	 {
	    var_t arg1851_1274;
	    atom_t arg1852_1275;
	    var_t arg1853_1276;
	    {
	       obj_t arg1860_1282;
	       arg1860_1282 = ____74_type_cache;
	       {
		  var_t res2177_2278;
		  {
		     type_t type_2269;
		     variable_t variable_2270;
		     type_2269 = (type_t) (arg1860_1282);
		     variable_2270 = (variable_t) (new_69);
		     {
			var_t new1211_2271;
			new1211_2271 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			{
			   long arg1933_2272;
			   arg1933_2272 = class_num_218___object(var_ast_node);
			   {
			      obj_t obj_2276;
			      obj_2276 = (obj_t) (new1211_2271);
			      (((obj_t) CREF(obj_2276))->header = MAKE_HEADER(arg1933_2272, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_3343;
			   aux_3343 = (object_t) (new1211_2271);
			   OBJECT_WIDENING_SET(aux_3343, BFALSE);
			}
			((((var_t) CREF(new1211_2271))->loc) = ((obj_t) loc_68), BUNSPEC);
			((((var_t) CREF(new1211_2271))->type) = ((type_t) type_2269), BUNSPEC);
			((((var_t) CREF(new1211_2271))->variable) = ((variable_t) variable_2270), BUNSPEC);
			res2177_2278 = new1211_2271;
		     }
		  }
		  arg1851_1274 = res2177_2278;
	       }
	    }
	    {
	       obj_t arg1863_1285;
	       arg1863_1285 = ____74_type_cache;
	       {
		  atom_t res2178_2289;
		  {
		     type_t type_2280;
		     obj_t value_2281;
		     type_2280 = (type_t) (arg1863_1285);
		     value_2281 = BINT(indice_70);
		     {
			atom_t new1203_2282;
			new1203_2282 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
			{
			   long arg1935_2283;
			   arg1935_2283 = class_num_218___object(atom_ast_node);
			   {
			      obj_t obj_2287;
			      obj_2287 = (obj_t) (new1203_2282);
			      (((obj_t) CREF(obj_2287))->header = MAKE_HEADER(arg1935_2283, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_3355;
			   aux_3355 = (object_t) (new1203_2282);
			   OBJECT_WIDENING_SET(aux_3355, BFALSE);
			}
			((((atom_t) CREF(new1203_2282))->loc) = ((obj_t) loc_68), BUNSPEC);
			((((atom_t) CREF(new1203_2282))->type) = ((type_t) type_2280), BUNSPEC);
			((((atom_t) CREF(new1203_2282))->value) = ((obj_t) value_2281), BUNSPEC);
			res2178_2289 = new1203_2282;
		     }
		  }
		  arg1852_1275 = res2178_2289;
	       }
	    }
	    {
	       obj_t arg1866_1288;
	       arg1866_1288 = ____74_type_cache;
	       {
		  var_t res2179_2300;
		  {
		     type_t type_2291;
		     variable_t variable_2292;
		     type_2291 = (type_t) (arg1866_1288);
		     {
			obj_t aux_3362;
			var_1290 = kaptured_71;
		      alpha_convert_60_1294:
			{
			   obj_t alpha_1292;
			   {
			      variable_t obj_2321;
			      obj_2321 = (variable_t) (var_1290);
			      alpha_1292 = (((variable_t) CREF(obj_2321))->fast_alpha_7);
			   }
			   {
			      bool_t test1869_1293;
			      test1869_1293 = is_a__118___object(alpha_1292, local_ast_var);
			      if (test1869_1293)
				{
				   obj_t var_3367;
				   var_3367 = alpha_1292;
				   var_1290 = var_3367;
				   goto alpha_convert_60_1294;
				}
			      else
				{
				   aux_3362 = var_1290;
				}
			   }
			}
			variable_2292 = (variable_t) (aux_3362);
		     }
		     {
			var_t new1211_2293;
			new1211_2293 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			{
			   long arg1933_2294;
			   arg1933_2294 = class_num_218___object(var_ast_node);
			   {
			      obj_t obj_2298;
			      obj_2298 = (obj_t) (new1211_2293);
			      (((obj_t) CREF(obj_2298))->header = MAKE_HEADER(arg1933_2294, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_3373;
			   aux_3373 = (object_t) (new1211_2293);
			   OBJECT_WIDENING_SET(aux_3373, BFALSE);
			}
			((((var_t) CREF(new1211_2293))->loc) = ((obj_t) loc_68), BUNSPEC);
			((((var_t) CREF(new1211_2293))->type) = ((type_t) type_2291), BUNSPEC);
			((((var_t) CREF(new1211_2293))->variable) = ((variable_t) variable_2292), BUNSPEC);
			res2179_2300 = new1211_2293;
		     }
		  }
		  arg1853_1276 = res2179_2300;
	       }
	    }
	    {
	       obj_t list1854_1277;
	       {
		  obj_t arg1856_1278;
		  {
		     obj_t arg1857_1279;
		     {
			obj_t aux_3379;
			aux_3379 = (obj_t) (arg1853_1276);
			arg1857_1279 = MAKE_PAIR(aux_3379, BNIL);
		     }
		     {
			obj_t aux_3382;
			aux_3382 = (obj_t) (arg1852_1275);
			arg1856_1278 = MAKE_PAIR(aux_3382, arg1857_1279);
		     }
		  }
		  {
		     obj_t aux_3385;
		     aux_3385 = (obj_t) (arg1851_1274);
		     list1854_1277 = MAKE_PAIR(aux_3385, arg1856_1278);
		  }
	       }
	       arg1838_1266 = list1854_1277;
	    }
	 }
	 {
	    app_t res2180_2320;
	    {
	       type_t type_2303;
	       obj_t key_2305;
	       type_2303 = (type_t) (arg1835_1263);
	       key_2305 = BINT(((long) -1));
	       {
		  app_t new1245_2309;
		  new1245_2309 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
		  {
		     long arg1924_2310;
		     arg1924_2310 = class_num_218___object(app_ast_node);
		     {
			obj_t obj_2318;
			obj_2318 = (obj_t) (new1245_2309);
			(((obj_t) CREF(obj_2318))->header = MAKE_HEADER(arg1924_2310, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_3394;
		     aux_3394 = (object_t) (new1245_2309);
		     OBJECT_WIDENING_SET(aux_3394, BFALSE);
		  }
		  ((((app_t) CREF(new1245_2309))->loc) = ((obj_t) loc_68), BUNSPEC);
		  ((((app_t) CREF(new1245_2309))->type) = ((type_t) type_2303), BUNSPEC);
		  ((((app_t) CREF(new1245_2309))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		  ((((app_t) CREF(new1245_2309))->key) = ((obj_t) key_2305), BUNSPEC);
		  ((((app_t) CREF(new1245_2309))->fun) = ((var_t) arg1837_1265), BUNSPEC);
		  ((((app_t) CREF(new1245_2309))->args) = ((obj_t) arg1838_1266), BUNSPEC);
		  ((((app_t) CREF(new1245_2309))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
		  res2180_2320 = new1245_2309;
	       }
	    }
	    return res2180_2320;
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_globalize_node()
{
   add_generic__110___object(glo__env_172_globalize_node, glo__default1624_env_151_globalize_node);
   add_inlined_method__244___object(glo__env_172_globalize_node, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(glo__env_172_globalize_node, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(glo__env_172_globalize_node, var_ast_node, ((long) 2));
   add_inlined_method__244___object(glo__env_172_globalize_node, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(glo__env_172_globalize_node, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(glo__env_172_globalize_node, app_ast_node, ((long) 5));
   add_inlined_method__244___object(glo__env_172_globalize_node, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(glo__env_172_globalize_node, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(glo__env_172_globalize_node, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(glo__env_172_globalize_node, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(glo__env_172_globalize_node, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(glo__env_172_globalize_node, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(glo__env_172_globalize_node, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(glo__env_172_globalize_node, select_ast_node, ((long) 13));
   add_inlined_method__244___object(glo__env_172_globalize_node, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(glo__env_172_globalize_node, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(glo__env_172_globalize_node, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(glo__env_172_globalize_node, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(glo__env_172_globalize_node, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(glo__env_172_globalize_node, box_ref_242_ast_node, ((long) 19));
   {
      long aux_3425;
      aux_3425 = add_inlined_method__244___object(glo__env_172_globalize_node, box_set__221_ast_node, ((long) 20));
      return BINT(aux_3425);
   }
}


/* glo! */ node_t 
glo__115_globalize_node(node_t node_10, variable_t integrator_11)
{
   {
      obj_t method1971_1690;
      obj_t class1976_1691;
      {
	 obj_t arg1979_1688;
	 obj_t arg1980_1689;
	 {
	    object_t obj_2488;
	    obj_2488 = (object_t) (node_10);
	    {
	       obj_t pre_method_105_2489;
	       pre_method_105_2489 = PROCEDURE_REF(glo__env_172_globalize_node, ((long) 2));
	       if (INTEGERP(pre_method_105_2489))
		 {
		    PROCEDURE_SET(glo__env_172_globalize_node, ((long) 2), BUNSPEC);
		    arg1979_1688 = pre_method_105_2489;
		 }
	       else
		 {
		    long obj_class_num_177_2494;
		    obj_class_num_177_2494 = TYPE(obj_2488);
		    {
		       obj_t arg1177_2495;
		       arg1177_2495 = PROCEDURE_REF(glo__env_172_globalize_node, ((long) 1));
		       {
			  long arg1178_2499;
			  {
			     long arg1179_2500;
			     arg1179_2500 = OBJECT_TYPE;
			     arg1178_2499 = (obj_class_num_177_2494 - arg1179_2500);
			  }
			  arg1979_1688 = VECTOR_REF(arg1177_2495, arg1178_2499);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_2505;
	    object_2505 = (object_t) (node_10);
	    {
	       long arg1180_2506;
	       {
		  long arg1181_2507;
		  long arg1182_2508;
		  arg1181_2507 = TYPE(object_2505);
		  arg1182_2508 = OBJECT_TYPE;
		  arg1180_2506 = (arg1181_2507 - arg1182_2508);
	       }
	       {
		  obj_t vector_2512;
		  vector_2512 = _classes__134___object;
		  arg1980_1689 = VECTOR_REF(vector_2512, arg1180_2506);
	       }
	    }
	 }
	 {
	    obj_t aux_3443;
	    method1971_1690 = arg1979_1688;
	    class1976_1691 = arg1980_1689;
	    {
	       if (INTEGERP(method1971_1690))
		 {
		    switch ((long) CINT(method1971_1690))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_3446;
			    aux_3446 = (atom_t) (node_10);
			    aux_3443 = (obj_t) (aux_3446);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_3449;
			    aux_3449 = (kwote_t) (node_10);
			    aux_3443 = (obj_t) (aux_3449);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t node_1701;
			    node_1701 = (var_t) (node_10);
			    {
			       variable_t var_1703;
			       var_1703 = (((var_t) CREF(node_1701))->variable);
			       {
				  obj_t alpha_1704;
				  alpha_1704 = (((variable_t) CREF(var_1703))->fast_alpha_7);
				  {
				     {
					bool_t test1983_1705;
					test1983_1705 = is_a__118___object(alpha_1704, local_ast_var);
					if (test1983_1705)
					  {
					     {
						variable_t val1217_2518;
						val1217_2518 = (variable_t) (alpha_1704);
						((((var_t) CREF(node_1701))->variable) = ((variable_t) val1217_2518), BUNSPEC);
					     }
					     {
						node_t aux_3459;
						aux_3459 = glo__115_globalize_node((node_t) (node_1701), integrator_11);
						aux_3443 = (obj_t) (aux_3459);
					     }
					  }
					else
					  {
					     bool_t test1984_1706;
					     test1984_1706 = is_a__118___object((obj_t) (var_1703), global_ast_var);
					     if (test1984_1706)
					       {
						  aux_3443 = (obj_t) (node_1701);
					       }
					     else
					       {
						  if (celled__113_globalize_node(var_1703))
						    {
						       {
							  obj_t arg1986_1708;
							  arg1986_1708 = CNST_TABLE_REF(((long) 0));
							  {
							     local_t obj_2520;
							     obj_2520 = (local_t) (var_1703);
							     ((((local_t) CREF(obj_2520))->access) = ((obj_t) arg1986_1708), BUNSPEC);
							  }
						       }
						       {
							  obj_t arg1987_1709;
							  type_t arg1988_1710;
							  {
							     node_t obj_2522;
							     obj_2522 = (node_t) (node_1701);
							     arg1987_1709 = (((node_t) CREF(obj_2522))->loc);
							  }
							  {
							     node_t obj_2523;
							     obj_2523 = (node_t) (node_1701);
							     arg1988_1710 = (((node_t) CREF(obj_2523))->type);
							  }
							  {
							     box_ref_242_t res2181_2538;
							     {
								obj_t key_2527;
								key_2527 = BINT(((long) -1));
								{
								   box_ref_242_t new1418_2529;
								   new1418_2529 = ((box_ref_242_t) BREF(GC_MALLOC(sizeof(struct box_ref_242))));
								   {
								      long arg1893_2530;
								      arg1893_2530 = class_num_218___object(box_ref_242_ast_node);
								      {
									 obj_t obj_2536;
									 obj_2536 = (obj_t) (new1418_2529);
									 (((obj_t) CREF(obj_2536))->header = MAKE_HEADER(arg1893_2530, 0), BUNSPEC);
								      }
								   }
								   {
								      object_t aux_3481;
								      aux_3481 = (object_t) (new1418_2529);
								      OBJECT_WIDENING_SET(aux_3481, BFALSE);
								   }
								   ((((box_ref_242_t) CREF(new1418_2529))->loc) = ((obj_t) arg1987_1709), BUNSPEC);
								   ((((box_ref_242_t) CREF(new1418_2529))->type) = ((type_t) arg1988_1710), BUNSPEC);
								   ((((box_ref_242_t) CREF(new1418_2529))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
								   ((((box_ref_242_t) CREF(new1418_2529))->key) = ((obj_t) key_2527), BUNSPEC);
								   ((((box_ref_242_t) CREF(new1418_2529))->var) = ((var_t) node_1701), BUNSPEC);
								   res2181_2538 = new1418_2529;
								}
							     }
							     aux_3443 = (obj_t) (res2181_2538);
							  }
						       }
						    }
						  else
						    {
						       aux_3443 = (obj_t) (node_1701);
						    }
					       }
					  }
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    closure_t node_1713;
			    node_1713 = (closure_t) (node_10);
			    {
			       var_t arg1991_1716;
			       {
				  obj_t arg1992_1717;
				  obj_t arg1993_1718;
				  obj_t arg1994_1719;
				  arg1992_1717 = (((closure_t) CREF(node_1713))->loc);
				  arg1993_1718 = _procedure__226_type_cache;
				  arg1994_1719 = the_closure_238_globalize_free((((closure_t) CREF(node_1713))->variable), (((closure_t) CREF(node_1713))->loc));
				  {
				     var_t res2182_2552;
				     {
					type_t type_2543;
					variable_t variable_2544;
					type_2543 = (type_t) (arg1993_1718);
					variable_2544 = (variable_t) (arg1994_1719);
					{
					   var_t new1211_2545;
					   new1211_2545 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
					   {
					      long arg1933_2546;
					      arg1933_2546 = class_num_218___object(var_ast_node);
					      {
						 obj_t obj_2550;
						 obj_2550 = (obj_t) (new1211_2545);
						 (((obj_t) CREF(obj_2550))->header = MAKE_HEADER(arg1933_2546, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_3502;
					      aux_3502 = (object_t) (new1211_2545);
					      OBJECT_WIDENING_SET(aux_3502, BFALSE);
					   }
					   ((((var_t) CREF(new1211_2545))->loc) = ((obj_t) arg1992_1717), BUNSPEC);
					   ((((var_t) CREF(new1211_2545))->type) = ((type_t) type_2543), BUNSPEC);
					   ((((var_t) CREF(new1211_2545))->variable) = ((variable_t) variable_2544), BUNSPEC);
					   res2182_2552 = new1211_2545;
					}
				     }
				     arg1991_1716 = res2182_2552;
				  }
			       }
			       {
				  node_t aux_3508;
				  aux_3508 = glo__115_globalize_node((node_t) (arg1991_1716), integrator_11);
				  aux_3443 = (obj_t) (aux_3508);
			       }
			    }
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1722;
			    node_1722 = (sequence_t) (node_10);
			    glo___241_globalize_node((((sequence_t) CREF(node_1722))->nodes), integrator_11);
			    aux_3443 = (obj_t) (node_1722);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_t node_1726;
			    node_1726 = (app_t) (node_10);
			    {
			       variable_t fun_1729;
			       {
				  var_t arg2041_1776;
				  arg2041_1776 = (((app_t) CREF(node_1726))->fun);
				  fun_1729 = (((var_t) CREF(arg2041_1776))->variable);
			       }
			       {
				  value_t info_1730;
				  info_1730 = (((variable_t) CREF(fun_1729))->value);
				  {
				     {
					bool_t test2001_1731;
					{
					   bool_t test2007_1736;
					   test2007_1736 = is_a__118___object((obj_t) (fun_1729), local_ast_var);
					   if (test2007_1736)
					     {
						bool_t test_3523;
						{
						   bool_t test_3524;
						   {
						      obj_t aux_3527;
						      obj_t aux_3525;
						      aux_3527 = (obj_t) (integrator_11);
						      aux_3525 = (obj_t) (fun_1729);
						      test_3524 = (aux_3525 == aux_3527);
						   }
						   if (test_3524)
						     {
							bool_t test_3530;
							{
							   local_ginfo_108_t obj_2560;
							   obj_2560 = (local_ginfo_108_t) (fun_1729);
							   {
							      obj_t aux_3532;
							      {
								 object_t aux_3533;
								 aux_3533 = (object_t) (obj_2560);
								 aux_3532 = OBJECT_WIDENING(aux_3533);
							      }
							      test_3530 = (((local_ginfo_108_t) CREF(aux_3532))->escape__117);
							   }
							}
							if (test_3530)
							  {
							     test_3523 = ((bool_t) 0);
							  }
							else
							  {
							     test_3523 = ((bool_t) 1);
							  }
						     }
						   else
						     {
							test_3523 = ((bool_t) 1);
						     }
						}
						if (test_3523)
						  {
						     sfun_ginfo_98_t obj_2561;
						     obj_2561 = (sfun_ginfo_98_t) (info_1730);
						     {
							obj_t aux_3538;
							{
							   object_t aux_3539;
							   aux_3539 = (object_t) (obj_2561);
							   aux_3538 = OBJECT_WIDENING(aux_3539);
							}
							test2001_1731 = (((sfun_ginfo_98_t) CREF(aux_3538))->g__219);
						     }
						  }
						else
						  {
						     test2001_1731 = ((bool_t) 0);
						  }
					     }
					   else
					     {
						test2001_1731 = ((bool_t) 0);
					     }
					}
					if (test2001_1731)
					  {
					     var_t arg2002_1732;
					     {
						obj_t arg2003_1733;
						type_t arg2004_1734;
						global_t arg2006_1735;
						arg2003_1733 = (((app_t) CREF(node_1726))->loc);
						arg2004_1734 = (((app_t) CREF(node_1726))->type);
						arg2006_1735 = the_global_201_globalize_local__global_194((local_t) (fun_1729));
						{
						   var_t res2183_2574;
						   {
						      variable_t variable_2566;
						      variable_2566 = (variable_t) (arg2006_1735);
						      {
							 var_t new1211_2567;
							 new1211_2567 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							 {
							    long arg1933_2568;
							    arg1933_2568 = class_num_218___object(var_ast_node);
							    {
							       obj_t obj_2572;
							       obj_2572 = (obj_t) (new1211_2567);
							       (((obj_t) CREF(obj_2572))->header = MAKE_HEADER(arg1933_2568, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_3553;
							    aux_3553 = (object_t) (new1211_2567);
							    OBJECT_WIDENING_SET(aux_3553, BFALSE);
							 }
							 ((((var_t) CREF(new1211_2567))->loc) = ((obj_t) arg2003_1733), BUNSPEC);
							 ((((var_t) CREF(new1211_2567))->type) = ((type_t) arg2004_1734), BUNSPEC);
							 ((((var_t) CREF(new1211_2567))->variable) = ((variable_t) variable_2566), BUNSPEC);
							 res2183_2574 = new1211_2567;
						      }
						   }
						   arg2002_1732 = res2183_2574;
						}
					     }
					     ((((app_t) CREF(node_1726))->fun) = ((var_t) arg2002_1732), BUNSPEC);
					  }
					else
					  {
					     BUNSPEC;
					  }
				     }
				     {
					obj_t nodes_1740;
					nodes_1740 = (((app_t) CREF(node_1726))->args);
				      liip_1741:
					if (NULLP(nodes_1740))
					  {
					     CNST_TABLE_REF(((long) 2));
					  }
					else
					  {
					     {
						node_t arg2013_1744;
						{
						   node_t aux_3563;
						   {
						      obj_t aux_3564;
						      aux_3564 = CAR(nodes_1740);
						      aux_3563 = (node_t) (aux_3564);
						   }
						   arg2013_1744 = glo__115_globalize_node(aux_3563, integrator_11);
						}
						{
						   obj_t aux_3568;
						   aux_3568 = (obj_t) (arg2013_1744);
						   SET_CAR(nodes_1740, aux_3568);
						}
					     }
					     {
						obj_t nodes_3571;
						nodes_3571 = CDR(nodes_1740);
						nodes_1740 = nodes_3571;
						goto liip_1741;
					     }
					  }
				     }
				     {
					bool_t test2016_1747;
					{
					   bool_t test2039_1773;
					   test2039_1773 = is_a__118___object((obj_t) (fun_1729), global_ast_var);
					   if (test2039_1773)
					     {
						test2016_1747 = ((bool_t) 1);
					     }
					   else
					     {
						bool_t test_3577;
						{
						   sfun_ginfo_98_t obj_2584;
						   obj_2584 = (sfun_ginfo_98_t) (info_1730);
						   {
						      obj_t aux_3579;
						      {
							 object_t aux_3580;
							 aux_3580 = (object_t) (obj_2584);
							 aux_3579 = OBJECT_WIDENING(aux_3580);
						      }
						      test_3577 = (((sfun_ginfo_98_t) CREF(aux_3579))->g__219);
						   }
						}
						if (test_3577)
						  {
						     bool_t test_3584;
						     {
							obj_t aux_3587;
							obj_t aux_3585;
							aux_3587 = (obj_t) (integrator_11);
							aux_3585 = (obj_t) (fun_1729);
							test_3584 = (aux_3585 == aux_3587);
						     }
						     if (test_3584)
						       {
							  local_ginfo_108_t obj_2587;
							  obj_2587 = (local_ginfo_108_t) (fun_1729);
							  {
							     obj_t aux_3591;
							     {
								object_t aux_3592;
								aux_3592 = (object_t) (obj_2587);
								aux_3591 = OBJECT_WIDENING(aux_3592);
							     }
							     test2016_1747 = (((local_ginfo_108_t) CREF(aux_3591))->escape__117);
							  }
						       }
						     else
						       {
							  test2016_1747 = ((bool_t) 0);
						       }
						  }
						else
						  {
						     test2016_1747 = ((bool_t) 1);
						  }
					     }
					}
					if (test2016_1747)
					  {
					     CNST_TABLE_REF(((long) 2));
					  }
					else
					  {
					     bool_t test_3598;
					     {
						local_ginfo_108_t obj_2588;
						obj_2588 = (local_ginfo_108_t) (fun_1729);
						{
						   obj_t aux_3600;
						   {
						      object_t aux_3601;
						      aux_3601 = (object_t) (obj_2588);
						      aux_3600 = OBJECT_WIDENING(aux_3601);
						   }
						   test_3598 = (((local_ginfo_108_t) CREF(aux_3600))->escape__117);
						}
					     }
					     if (test_3598)
					       {
						  {
						     obj_t arg2018_1749;
						     {
							node_t arg2019_1750;
							obj_t arg2020_1751;
							{
							   var_t arg2021_1752;
							   {
							      obj_t arg2022_1753;
							      obj_t arg2023_1754;
							      obj_t arg2024_1755;
							      arg2022_1753 = (((app_t) CREF(node_1726))->loc);
							      arg2023_1754 = ____74_type_cache;
							      arg2024_1755 = the_closure_238_globalize_free(fun_1729, (((app_t) CREF(node_1726))->loc));
							      {
								 var_t res2184_2601;
								 {
								    type_t type_2592;
								    variable_t variable_2593;
								    type_2592 = (type_t) (arg2023_1754);
								    variable_2593 = (variable_t) (arg2024_1755);
								    {
								       var_t new1211_2594;
								       new1211_2594 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								       {
									  long arg1933_2595;
									  arg1933_2595 = class_num_218___object(var_ast_node);
									  {
									     obj_t obj_2599;
									     obj_2599 = (obj_t) (new1211_2594);
									     (((obj_t) CREF(obj_2599))->header = MAKE_HEADER(arg1933_2595, 0), BUNSPEC);
									  }
								       }
								       {
									  object_t aux_3614;
									  aux_3614 = (object_t) (new1211_2594);
									  OBJECT_WIDENING_SET(aux_3614, BFALSE);
								       }
								       ((((var_t) CREF(new1211_2594))->loc) = ((obj_t) arg2022_1753), BUNSPEC);
								       ((((var_t) CREF(new1211_2594))->type) = ((type_t) type_2592), BUNSPEC);
								       ((((var_t) CREF(new1211_2594))->variable) = ((variable_t) variable_2593), BUNSPEC);
								       res2184_2601 = new1211_2594;
								    }
								 }
								 arg2021_1752 = res2184_2601;
							      }
							   }
							   arg2019_1750 = glo__115_globalize_node((node_t) (arg2021_1752), integrator_11);
							}
							arg2020_1751 = (((app_t) CREF(node_1726))->args);
							{
							   obj_t aux_3623;
							   aux_3623 = (obj_t) (arg2019_1750);
							   arg2018_1749 = MAKE_PAIR(aux_3623, arg2020_1751);
							}
						     }
						     ((((app_t) CREF(node_1726))->args) = ((obj_t) arg2018_1749), BUNSPEC);
						  }
					       }
					     else
					       {
						  {
						     obj_t new_actuals_73_1757;
						     obj_t kaptured_1758;
						     new_actuals_73_1757 = (((app_t) CREF(node_1726))->args);
						     {
							sfun_ginfo_98_t obj_2608;
							obj_2608 = (sfun_ginfo_98_t) (info_1730);
							{
							   obj_t aux_3656;
							   {
							      object_t aux_3657;
							      aux_3657 = (object_t) (obj_2608);
							      aux_3656 = OBJECT_WIDENING(aux_3657);
							   }
							   kaptured_1758 = (((sfun_ginfo_98_t) CREF(aux_3656))->kaptured);
							}
						     }
						   loop_1759:
						     if (NULLP(kaptured_1758))
						       {
							  ((((app_t) CREF(node_1726))->args) = ((obj_t) new_actuals_73_1757), BUNSPEC);
						       }
						     else
						       {
							  obj_t kap_1763;
							  kap_1763 = CAR(kaptured_1758);
							  {
							     obj_t alpha_1764;
							     {
								local_t obj_2613;
								obj_2613 = (local_t) (kap_1763);
								alpha_1764 = (((local_t) CREF(obj_2613))->fast_alpha_7);
							     }
							     {
								obj_t var_1765;
								{
								   bool_t test2038_1772;
								   test2038_1772 = is_a__118___object(alpha_1764, local_ast_var);
								   if (test2038_1772)
								     {
									var_1765 = alpha_1764;
								     }
								   else
								     {
									var_1765 = kap_1763;
								     }
								}
								{
								   {
								      obj_t arg2030_1766;
								      obj_t arg2031_1767;
								      {
									 var_t arg2032_1768;
									 {
									    obj_t arg2033_1769;
									    obj_t arg2035_1770;
									    arg2033_1769 = (((app_t) CREF(node_1726))->loc);
									    arg2035_1770 = ____74_type_cache;
									    {
									       var_t res2185_2626;
									       {
										  type_t type_2617;
										  variable_t variable_2618;
										  type_2617 = (type_t) (arg2035_1770);
										  variable_2618 = (variable_t) (var_1765);
										  {
										     var_t new1211_2619;
										     new1211_2619 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
										     {
											long arg1933_2620;
											arg1933_2620 = class_num_218___object(var_ast_node);
											{
											   obj_t obj_2624;
											   obj_2624 = (obj_t) (new1211_2619);
											   (((obj_t) CREF(obj_2624))->header = MAKE_HEADER(arg1933_2620, 0), BUNSPEC);
											}
										     }
										     {
											object_t aux_3642;
											aux_3642 = (object_t) (new1211_2619);
											OBJECT_WIDENING_SET(aux_3642, BFALSE);
										     }
										     ((((var_t) CREF(new1211_2619))->loc) = ((obj_t) arg2033_1769), BUNSPEC);
										     ((((var_t) CREF(new1211_2619))->type) = ((type_t) type_2617), BUNSPEC);
										     ((((var_t) CREF(new1211_2619))->variable) = ((variable_t) variable_2618), BUNSPEC);
										     res2185_2626 = new1211_2619;
										  }
									       }
									       arg2032_1768 = res2185_2626;
									    }
									 }
									 {
									    obj_t aux_3648;
									    aux_3648 = (obj_t) (arg2032_1768);
									    arg2030_1766 = MAKE_PAIR(aux_3648, new_actuals_73_1757);
									 }
								      }
								      arg2031_1767 = CDR(kaptured_1758);
								      {
									 obj_t kaptured_3653;
									 obj_t new_actuals_73_3652;
									 new_actuals_73_3652 = arg2030_1766;
									 kaptured_3653 = arg2031_1767;
									 kaptured_1758 = kaptured_3653;
									 new_actuals_73_1757 = new_actuals_73_3652;
									 goto loop_1759;
								      }
								   }
								}
							     }
							  }
						       }
						  }
					       }
					  }
				     }
				     aux_3443 = (obj_t) (node_1726);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    app_ly_162_t node_1777;
			    node_1777 = (app_ly_162_t) (node_10);
			    {
			       node_t arg2042_1780;
			       arg2042_1780 = glo__115_globalize_node((((app_ly_162_t) CREF(node_1777))->fun), integrator_11);
			       ((((app_ly_162_t) CREF(node_1777))->fun) = ((node_t) arg2042_1780), BUNSPEC);
			    }
			    {
			       node_t arg2044_1782;
			       arg2044_1782 = glo__115_globalize_node((((app_ly_162_t) CREF(node_1777))->arg), integrator_11);
			       ((((app_ly_162_t) CREF(node_1777))->arg) = ((node_t) arg2044_1782), BUNSPEC);
			    }
			    aux_3443 = (obj_t) (node_1777);
			 }
			 break;
		      case ((long) 7):
			 {
			    funcall_t node_1784;
			    node_1784 = (funcall_t) (node_10);
			    {
			       node_t arg2046_1787;
			       arg2046_1787 = glo__115_globalize_node((((funcall_t) CREF(node_1784))->fun), integrator_11);
			       ((((funcall_t) CREF(node_1784))->fun) = ((node_t) arg2046_1787), BUNSPEC);
			    }
			    glo___241_globalize_node((((funcall_t) CREF(node_1784))->args), integrator_11);
			    aux_3443 = (obj_t) (node_1784);
			 }
			 break;
		      case ((long) 8):
			 {
			    pragma_t node_1790;
			    node_1790 = (pragma_t) (node_10);
			    glo___241_globalize_node((((pragma_t) CREF(node_1790))->args), integrator_11);
			    aux_3443 = (obj_t) (node_1790);
			 }
			 break;
		      case ((long) 9):
			 {
			    cast_t node_1794;
			    node_1794 = (cast_t) (node_10);
			    glo__115_globalize_node((((cast_t) CREF(node_1794))->arg), integrator_11);
			    aux_3443 = (obj_t) (node_1794);
			 }
			 break;
		      case ((long) 10):
			 {
			    setq_t node_1798;
			    node_1798 = (setq_t) (node_10);
			    {
			       node_t arg2051_1801;
			       arg2051_1801 = glo__115_globalize_node((((setq_t) CREF(node_1798))->value), integrator_11);
			       ((((setq_t) CREF(node_1798))->value) = ((node_t) arg2051_1801), BUNSPEC);
			    }
			    {
			       variable_t var_1803;
			       {
				  var_t arg2085_1842;
				  arg2085_1842 = (((setq_t) CREF(node_1798))->var);
				  var_1803 = (((var_t) CREF(arg2085_1842))->variable);
			       }
			       {
				  obj_t var_1804;
				  obj_t alpha_1805;
				  var_1804 = (obj_t) (var_1803);
				  alpha_1805 = (((variable_t) CREF(var_1803))->fast_alpha_7);
				loop_1806:
				  {
				     bool_t test2054_1808;
				     test2054_1808 = is_a__118___object(alpha_1805, local_ast_var);
				     if (test2054_1808)
				       {
					  {
					     var_t arg2055_1809;
					     arg2055_1809 = (((setq_t) CREF(node_1798))->var);
					     {
						variable_t val1217_2651;
						val1217_2651 = (variable_t) (alpha_1805);
						((((var_t) CREF(arg2055_1809))->variable) = ((variable_t) val1217_2651), BUNSPEC);
					     }
					  }
					  {
					     obj_t alpha_3697;
					     obj_t var_3696;
					     var_3696 = alpha_1805;
					     {
						variable_t obj_2652;
						obj_2652 = (variable_t) (alpha_1805);
						alpha_3697 = (((variable_t) CREF(obj_2652))->fast_alpha_7);
					     }
					     alpha_1805 = alpha_3697;
					     var_1804 = var_3696;
					     goto loop_1806;
					  }
				       }
				     else
				       {
					  variable_t var_1811;
					  {
					     var_t arg2084_1841;
					     arg2084_1841 = (((setq_t) CREF(node_1798))->var);
					     var_1811 = (((var_t) CREF(arg2084_1841))->variable);
					  }
					  {
					     bool_t test2057_1812;
					     {
						bool_t test2083_1840;
						test2083_1840 = is_a__118___object((obj_t) (var_1811), local_ast_var);
						if (test2083_1840)
						  {
						     test2057_1812 = celled__113_globalize_node(var_1811);
						  }
						else
						  {
						     test2057_1812 = ((bool_t) 0);
						  }
					     }
					     if (test2057_1812)
					       {
						  local_t a_var_30_1813;
						  obj_t loc_1814;
						  a_var_30_1813 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 7)), (type_t) (_obj__252_type_cache));
						  {
						     node_t obj_2656;
						     obj_2656 = (node_t) (node_1798);
						     loc_1814 = (((node_t) CREF(obj_2656))->loc);
						  }
						  {
						     obj_t arg2058_1815;
						     arg2058_1815 = CNST_TABLE_REF(((long) 0));
						     {
							local_t obj_2657;
							obj_2657 = (local_t) (var_1811);
							((((local_t) CREF(obj_2657))->access) = ((obj_t) arg2058_1815), BUNSPEC);
						     }
						  }
						  {
						     bool_t arg2059_1816;
						     {
							local_t obj_2659;
							obj_2659 = (local_t) (var_1811);
							arg2059_1816 = (((local_t) CREF(obj_2659))->user__32);
						     }
						     ((((local_t) CREF(a_var_30_1813))->user__32) = ((bool_t) arg2059_1816), BUNSPEC);
						  }
						  {
						     svar_ginfo_131_t obj1589_1817;
						     obj1589_1817 = ((svar_ginfo_131_t) ((((local_t) CREF(a_var_30_1813))->value)));
						     {
							svar_ginfo_131_t arg2060_1818;
							{
							   svar_ginfo_131_t res2186_2672;
							   {
							      svar_ginfo_131_t new1492_2667;
							      new1492_2667 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
							      ((((svar_ginfo_131_t) CREF(new1492_2667))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							      ((((svar_ginfo_131_t) CREF(new1492_2667))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
							      ((((svar_ginfo_131_t) CREF(new1492_2667))->mark) = ((long) ((long) -10)), BUNSPEC);
							      ((((svar_ginfo_131_t) CREF(new1492_2667))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							      res2186_2672 = new1492_2667;
							   }
							   arg2060_1818 = res2186_2672;
							}
							{
							   obj_t aux_3727;
							   object_t aux_3725;
							   aux_3727 = (obj_t) (arg2060_1818);
							   aux_3725 = (object_t) (obj1589_1817);
							   OBJECT_WIDENING_SET(aux_3725, aux_3727);
							}
						     }
						     {
							long arg2064_1822;
							arg2064_1822 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
							{
							   obj_t obj_2673;
							   obj_2673 = (obj_t) (obj1589_1817);
							   (((obj_t) CREF(obj_2673))->header = MAKE_HEADER(arg2064_1822, 0), BUNSPEC);
							}
						     }
						     obj1589_1817;
						  }
						  {
						     obj_t arg2067_1824;
						     obj_t arg2069_1826;
						     box_set__221_t arg2070_1827;
						     arg2067_1824 = ____74_type_cache;
						     {
							obj_t arg2071_1828;
							{
							   obj_t aux_3735;
							   obj_t aux_3733;
							   {
							      node_t aux_3736;
							      aux_3736 = (((setq_t) CREF(node_1798))->value);
							      aux_3735 = (obj_t) (aux_3736);
							   }
							   aux_3733 = (obj_t) (a_var_30_1813);
							   arg2071_1828 = MAKE_PAIR(aux_3733, aux_3735);
							}
							{
							   obj_t list2072_1829;
							   list2072_1829 = MAKE_PAIR(arg2071_1828, BNIL);
							   arg2069_1826 = list2072_1829;
							}
						     }
						     {
							obj_t arg2076_1833;
							var_t arg2077_1834;
							var_t arg2078_1835;
							arg2076_1833 = ____74_type_cache;
							arg2077_1834 = (((setq_t) CREF(node_1798))->var);
							{
							   obj_t arg2080_1837;
							   arg2080_1837 = ____74_type_cache;
							   {
							      var_t res2187_2690;
							      {
								 type_t type_2681;
								 variable_t variable_2682;
								 type_2681 = (type_t) (arg2080_1837);
								 variable_2682 = (variable_t) (a_var_30_1813);
								 {
								    var_t new1211_2683;
								    new1211_2683 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								    {
								       long arg1933_2684;
								       arg1933_2684 = class_num_218___object(var_ast_node);
								       {
									  obj_t obj_2688;
									  obj_2688 = (obj_t) (new1211_2683);
									  (((obj_t) CREF(obj_2688))->header = MAKE_HEADER(arg1933_2684, 0), BUNSPEC);
								       }
								    }
								    {
								       object_t aux_3748;
								       aux_3748 = (object_t) (new1211_2683);
								       OBJECT_WIDENING_SET(aux_3748, BFALSE);
								    }
								    ((((var_t) CREF(new1211_2683))->loc) = ((obj_t) loc_1814), BUNSPEC);
								    ((((var_t) CREF(new1211_2683))->type) = ((type_t) type_2681), BUNSPEC);
								    ((((var_t) CREF(new1211_2683))->variable) = ((variable_t) variable_2682), BUNSPEC);
								    res2187_2690 = new1211_2683;
								 }
							      }
							      arg2078_1835 = res2187_2690;
							   }
							}
							{
							   box_set__221_t res2188_2703;
							   {
							      type_t type_2692;
							      node_t value_2694;
							      type_2692 = (type_t) (arg2076_1833);
							      value_2694 = (node_t) (arg2078_1835);
							      {
								 box_set__221_t new1430_2695;
								 new1430_2695 = ((box_set__221_t) BREF(GC_MALLOC(sizeof(struct box_set__221))));
								 {
								    long arg1890_2696;
								    arg1890_2696 = class_num_218___object(box_set__221_ast_node);
								    {
								       obj_t obj_2701;
								       obj_2701 = (obj_t) (new1430_2695);
								       (((obj_t) CREF(obj_2701))->header = MAKE_HEADER(arg1890_2696, 0), BUNSPEC);
								    }
								 }
								 {
								    object_t aux_3760;
								    aux_3760 = (object_t) (new1430_2695);
								    OBJECT_WIDENING_SET(aux_3760, BFALSE);
								 }
								 ((((box_set__221_t) CREF(new1430_2695))->loc) = ((obj_t) loc_1814), BUNSPEC);
								 ((((box_set__221_t) CREF(new1430_2695))->type) = ((type_t) type_2692), BUNSPEC);
								 ((((box_set__221_t) CREF(new1430_2695))->var) = ((var_t) arg2077_1834), BUNSPEC);
								 ((((box_set__221_t) CREF(new1430_2695))->value) = ((node_t) value_2694), BUNSPEC);
								 res2188_2703 = new1430_2695;
							      }
							   }
							   arg2070_1827 = res2188_2703;
							}
						     }
						     {
							let_var_6_t res2189_2722;
							{
							   type_t type_2705;
							   obj_t key_2707;
							   node_t body_2709;
							   type_2705 = (type_t) (arg2067_1824);
							   key_2707 = BINT(((long) -1));
							   body_2709 = (node_t) (arg2070_1827);
							   {
							      let_var_6_t new1370_2711;
							      new1370_2711 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
							      {
								 long arg1901_2712;
								 arg1901_2712 = class_num_218___object(let_var_6_ast_node);
								 {
								    obj_t obj_2720;
								    obj_2720 = (obj_t) (new1370_2711);
								    (((obj_t) CREF(obj_2720))->header = MAKE_HEADER(arg1901_2712, 0), BUNSPEC);
								 }
							      }
							      {
								 object_t aux_3774;
								 aux_3774 = (object_t) (new1370_2711);
								 OBJECT_WIDENING_SET(aux_3774, BFALSE);
							      }
							      ((((let_var_6_t) CREF(new1370_2711))->loc) = ((obj_t) loc_1814), BUNSPEC);
							      ((((let_var_6_t) CREF(new1370_2711))->type) = ((type_t) type_2705), BUNSPEC);
							      ((((let_var_6_t) CREF(new1370_2711))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
							      ((((let_var_6_t) CREF(new1370_2711))->key) = ((obj_t) key_2707), BUNSPEC);
							      ((((let_var_6_t) CREF(new1370_2711))->bindings) = ((obj_t) arg2069_1826), BUNSPEC);
							      ((((let_var_6_t) CREF(new1370_2711))->body) = ((node_t) body_2709), BUNSPEC);
							      ((((let_var_6_t) CREF(new1370_2711))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
							      res2189_2722 = new1370_2711;
							   }
							}
							aux_3443 = (obj_t) (res2189_2722);
						     }
						  }
					       }
					     else
					       {
						  aux_3443 = (obj_t) (node_1798);
					       }
					  }
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    conditional_t node_1843;
			    node_1843 = (conditional_t) (node_10);
			    {
			       node_t arg2086_1846;
			       arg2086_1846 = glo__115_globalize_node((((conditional_t) CREF(node_1843))->test), integrator_11);
			       ((((conditional_t) CREF(node_1843))->test) = ((node_t) arg2086_1846), BUNSPEC);
			    }
			    {
			       node_t arg2088_1848;
			       arg2088_1848 = glo__115_globalize_node((((conditional_t) CREF(node_1843))->true), integrator_11);
			       ((((conditional_t) CREF(node_1843))->true) = ((node_t) arg2088_1848), BUNSPEC);
			    }
			    {
			       node_t arg2090_1850;
			       arg2090_1850 = glo__115_globalize_node((((conditional_t) CREF(node_1843))->false), integrator_11);
			       ((((conditional_t) CREF(node_1843))->false) = ((node_t) arg2090_1850), BUNSPEC);
			    }
			    aux_3443 = (obj_t) (node_1843);
			 }
			 break;
		      case ((long) 12):
			 {
			    fail_t node_1852;
			    node_1852 = (fail_t) (node_10);
			    {
			       node_t arg2092_1855;
			       arg2092_1855 = glo__115_globalize_node((((fail_t) CREF(node_1852))->proc), integrator_11);
			       ((((fail_t) CREF(node_1852))->proc) = ((node_t) arg2092_1855), BUNSPEC);
			    }
			    {
			       node_t arg2094_1857;
			       arg2094_1857 = glo__115_globalize_node((((fail_t) CREF(node_1852))->msg), integrator_11);
			       ((((fail_t) CREF(node_1852))->msg) = ((node_t) arg2094_1857), BUNSPEC);
			    }
			    {
			       node_t arg2096_1859;
			       arg2096_1859 = glo__115_globalize_node((((fail_t) CREF(node_1852))->obj), integrator_11);
			       ((((fail_t) CREF(node_1852))->obj) = ((node_t) arg2096_1859), BUNSPEC);
			    }
			    aux_3443 = (obj_t) (node_1852);
			 }
			 break;
		      case ((long) 13):
			 {
			    select_t node_1861;
			    node_1861 = (select_t) (node_10);
			    {
			       node_t arg2098_1864;
			       arg2098_1864 = glo__115_globalize_node((((select_t) CREF(node_1861))->test), integrator_11);
			       ((((select_t) CREF(node_1861))->test) = ((node_t) arg2098_1864), BUNSPEC);
			    }
			    {
			       obj_t l1596_1866;
			       l1596_1866 = (((select_t) CREF(node_1861))->clauses);
			     lname1597_1867:
			       if (PAIRP(l1596_1866))
				 {
				    {
				       obj_t clause_1870;
				       clause_1870 = CAR(l1596_1866);
				       {
					  node_t arg2102_1871;
					  {
					     node_t aux_3817;
					     {
						obj_t aux_3818;
						aux_3818 = CDR(clause_1870);
						aux_3817 = (node_t) (aux_3818);
					     }
					     arg2102_1871 = glo__115_globalize_node(aux_3817, integrator_11);
					  }
					  {
					     obj_t aux_3822;
					     aux_3822 = (obj_t) (arg2102_1871);
					     SET_CDR(clause_1870, aux_3822);
					  }
				       }
				    }
				    {
				       obj_t l1596_3825;
				       l1596_3825 = CDR(l1596_1866);
				       l1596_1866 = l1596_3825;
				       goto lname1597_1867;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_3443 = (obj_t) (node_1861);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_fun_218_t node_1874;
			    node_1874 = (let_fun_218_t) (node_10);
			    {
			       node_t arg2106_1877;
			       arg2106_1877 = glo__115_globalize_node((((let_fun_218_t) CREF(node_1874))->body), integrator_11);
			       ((((let_fun_218_t) CREF(node_1874))->body) = ((node_t) arg2106_1877), BUNSPEC);
			    }
			    {
			       obj_t obindings_1879;
			       obj_t nbindings_1880;
			       obj_t ebindings_1881;
			       obindings_1879 = (((let_fun_218_t) CREF(node_1874))->locals);
			       nbindings_1880 = BNIL;
			       ebindings_1881 = BNIL;
			     liip_1882:
			       if (NULLP(obindings_1879))
				 {
				    ((((let_fun_218_t) CREF(node_1874))->locals) = ((obj_t) nbindings_1880), BUNSPEC);
				    if (NULLP(ebindings_1881))
				      {
					 aux_3443 = (obj_t) (node_1874);
				      }
				    else
				      {
					 let_var_6_t aux_3839;
					 aux_3839 = make_escaping_bindings_69_globalize_node(ebindings_1881, (node_t) (node_1874), integrator_11);
					 aux_3443 = (obj_t) (aux_3839);
				      }
				 }
			       else
				 {
				    bool_t test_3843;
				    {
				       bool_t test_3844;
				       {
					  obj_t aux_3847;
					  obj_t aux_3845;
					  aux_3847 = (obj_t) (integrator_11);
					  aux_3845 = CAR(obindings_1879);
					  test_3844 = (aux_3845 == aux_3847);
				       }
				       if (test_3844)
					 {
					    test_3843 = ((bool_t) 0);
					 }
				       else
					 {
					    local_ginfo_108_t obj_2764;
					    {
					       obj_t aux_3850;
					       aux_3850 = CAR(obindings_1879);
					       obj_2764 = (local_ginfo_108_t) (aux_3850);
					    }
					    {
					       obj_t aux_3853;
					       {
						  object_t aux_3854;
						  aux_3854 = (object_t) (obj_2764);
						  aux_3853 = OBJECT_WIDENING(aux_3854);
					       }
					       test_3843 = (((local_ginfo_108_t) CREF(aux_3853))->escape__117);
					    }
					 }
				    }
				    if (test_3843)
				      {
					 {
					    obj_t arg2116_1890;
					    obj_t arg2117_1891;
					    arg2116_1890 = CDR(obindings_1879);
					    {
					       obj_t aux_3859;
					       aux_3859 = CAR(obindings_1879);
					       arg2117_1891 = MAKE_PAIR(aux_3859, ebindings_1881);
					    }
					    {
					       obj_t ebindings_3863;
					       obj_t obindings_3862;
					       obindings_3862 = arg2116_1890;
					       ebindings_3863 = arg2117_1891;
					       ebindings_1881 = ebindings_3863;
					       obindings_1879 = obindings_3862;
					       goto liip_1882;
					    }
					 }
				      }
				    else
				      {
					 {
					    obj_t local_1893;
					    local_1893 = CAR(obindings_1879);
					    globalize_local_fun__50_globalize_node((local_t) (local_1893), integrator_11);
					    {
					       obj_t arg2121_1894;
					       obj_t arg2122_1895;
					       arg2121_1894 = CDR(obindings_1879);
					       arg2122_1895 = MAKE_PAIR(local_1893, nbindings_1880);
					       {
						  obj_t nbindings_3870;
						  obj_t obindings_3869;
						  obindings_3869 = arg2121_1894;
						  nbindings_3870 = arg2122_1895;
						  nbindings_1880 = nbindings_3870;
						  obindings_1879 = obindings_3869;
						  goto liip_1882;
					       }
					    }
					 }
				      }
				 }
			    }
			 }
			 break;
		      case ((long) 15):
			 {
			    let_var_6_t node_1899;
			    node_1899 = (let_var_6_t) (node_10);
			    {
			       obj_t l1600_1902;
			       l1600_1902 = (((let_var_6_t) CREF(node_1899))->bindings);
			     lname1601_1903:
			       if (PAIRP(l1600_1902))
				 {
				    {
				       obj_t binding_1906;
				       binding_1906 = CAR(l1600_1902);
				       {
					  obj_t var_1907;
					  var_1907 = CAR(binding_1906);
					  {
					     node_t arg2129_1909;
					     {
						node_t aux_3877;
						{
						   obj_t aux_3878;
						   aux_3878 = CDR(binding_1906);
						   aux_3877 = (node_t) (aux_3878);
						}
						arg2129_1909 = glo__115_globalize_node(aux_3877, integrator_11);
					     }
					     {
						obj_t aux_3882;
						aux_3882 = (obj_t) (arg2129_1909);
						SET_CDR(binding_1906, aux_3882);
					     }
					  }
					  if (celled__113_globalize_node((variable_t) (var_1907)))
					    {
					       {
						  local_t obj_2780;
						  type_t val1097_2781;
						  obj_2780 = (local_t) (var_1907);
						  val1097_2781 = (type_t) (_obj__252_type_cache);
						  ((((local_t) CREF(obj_2780))->type) = ((type_t) val1097_2781), BUNSPEC);
					       }
					       {
						  make_box_202_t arg2131_1911;
						  {
						     node_t aux_3891;
						     {
							obj_t aux_3892;
							aux_3892 = CDR(binding_1906);
							aux_3891 = (node_t) (aux_3892);
						     }
						     arg2131_1911 = a_make_cell_117_globalize_node(aux_3891, (variable_t) (var_1907));
						  }
						  {
						     obj_t aux_3897;
						     aux_3897 = (obj_t) (arg2131_1911);
						     SET_CDR(binding_1906, aux_3897);
						  }
					       }
					    }
					  else
					    {
					       BUNSPEC;
					    }
				       }
				    }
				    {
				       obj_t l1600_3900;
				       l1600_3900 = CDR(l1600_1902);
				       l1600_1902 = l1600_3900;
				       goto lname1601_1903;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg2134_1914;
			       arg2134_1914 = glo__115_globalize_node((((let_var_6_t) CREF(node_1899))->body), integrator_11);
			       ((((let_var_6_t) CREF(node_1899))->body) = ((node_t) arg2134_1914), BUNSPEC);
			    }
			    aux_3443 = (obj_t) (node_1899);
			 }
			 break;
		      case ((long) 16):
			 {
			    set_ex_it_116_t node_1916;
			    node_1916 = (set_ex_it_116_t) (node_10);
			    {
			       bool_t test_3908;
			       {
				  sfun_ginfo_98_t obj_2794;
				  {
				     value_t aux_3909;
				     {
					local_t obj_2793;
					{
					   obj_t aux_3910;
					   {
					      sexit_t obj_2792;
					      {
						 value_t aux_3911;
						 {
						    local_t obj_2791;
						    {
						       variable_t aux_3912;
						       {
							  var_t arg2146_1929;
							  arg2146_1929 = (((set_ex_it_116_t) CREF(node_1916))->var);
							  aux_3912 = (((var_t) CREF(arg2146_1929))->variable);
						       }
						       obj_2791 = (local_t) (aux_3912);
						    }
						    aux_3911 = (((local_t) CREF(obj_2791))->value);
						 }
						 obj_2792 = (sexit_t) (aux_3911);
					      }
					      aux_3910 = (((sexit_t) CREF(obj_2792))->handler);
					   }
					   obj_2793 = (local_t) (aux_3910);
					}
					aux_3909 = (((local_t) CREF(obj_2793))->value);
				     }
				     obj_2794 = (sfun_ginfo_98_t) (aux_3909);
				  }
				  {
				     obj_t aux_3922;
				     {
					object_t aux_3923;
					aux_3923 = (object_t) (obj_2794);
					aux_3922 = OBJECT_WIDENING(aux_3923);
				     }
				     test_3908 = (((sfun_ginfo_98_t) CREF(aux_3922))->g__219);
				  }
			       }
			       if (test_3908)
				 {
				    sexit_t obj_2798;
				    {
				       value_t aux_3927;
				       {
					  local_t obj_2797;
					  {
					     variable_t aux_3928;
					     {
						var_t arg2139_1923;
						arg2139_1923 = (((set_ex_it_116_t) CREF(node_1916))->var);
						aux_3928 = (((var_t) CREF(arg2139_1923))->variable);
					     }
					     obj_2797 = (local_t) (aux_3928);
					  }
					  aux_3927 = (((local_t) CREF(obj_2797))->value);
				       }
				       obj_2798 = (sexit_t) (aux_3927);
				    }
				    ((((sexit_t) CREF(obj_2798))->detached__120) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    {
			       node_t arg2141_1925;
			       arg2141_1925 = glo__115_globalize_node((((set_ex_it_116_t) CREF(node_1916))->body), integrator_11);
			       ((((set_ex_it_116_t) CREF(node_1916))->body) = ((node_t) arg2141_1925), BUNSPEC);
			    }
			    aux_3443 = (obj_t) (node_1916);
			 }
			 break;
		      case ((long) 17):
			 {
			    jump_ex_it_184_t node_1930;
			    node_1930 = (jump_ex_it_184_t) (node_10);
			    {
			       node_t arg2147_1933;
			       arg2147_1933 = glo__115_globalize_node((((jump_ex_it_184_t) CREF(node_1930))->exit), integrator_11);
			       ((((jump_ex_it_184_t) CREF(node_1930))->exit) = ((node_t) arg2147_1933), BUNSPEC);
			    }
			    {
			       node_t arg2149_1935;
			       arg2149_1935 = glo__115_globalize_node((((jump_ex_it_184_t) CREF(node_1930))->value), integrator_11);
			       ((((jump_ex_it_184_t) CREF(node_1930))->value) = ((node_t) arg2149_1935), BUNSPEC);
			    }
			    aux_3443 = (obj_t) (node_1930);
			 }
			 break;
		      case ((long) 18):
			 {
			    make_box_202_t node_1937;
			    node_1937 = (make_box_202_t) (node_10);
			    {
			       node_t arg2151_1940;
			       arg2151_1940 = glo__115_globalize_node((((make_box_202_t) CREF(node_1937))->value), integrator_11);
			       ((((make_box_202_t) CREF(node_1937))->value) = ((node_t) arg2151_1940), BUNSPEC);
			    }
			    aux_3443 = (obj_t) (node_1937);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_ref_242_t node_1942;
			    node_1942 = (box_ref_242_t) (node_10);
			    {
			       node_t arg2153_1945;
			       {
				  node_t aux_3953;
				  {
				     var_t aux_3954;
				     aux_3954 = (((box_ref_242_t) CREF(node_1942))->var);
				     aux_3953 = (node_t) (aux_3954);
				  }
				  arg2153_1945 = glo__115_globalize_node(aux_3953, integrator_11);
			       }
			       {
				  var_t val1428_2814;
				  val1428_2814 = (var_t) (arg2153_1945);
				  ((((box_ref_242_t) CREF(node_1942))->var) = ((var_t) val1428_2814), BUNSPEC);
			       }
			    }
			    aux_3443 = (obj_t) (node_1942);
			 }
			 break;
		      case ((long) 20):
			 {
			    box_set__221_t node_1947;
			    node_1947 = (box_set__221_t) (node_10);
			    {
			       node_t arg2155_1950;
			       {
				  node_t aux_3962;
				  {
				     var_t aux_3963;
				     aux_3963 = (((box_set__221_t) CREF(node_1947))->var);
				     aux_3962 = (node_t) (aux_3963);
				  }
				  arg2155_1950 = glo__115_globalize_node(aux_3962, integrator_11);
			       }
			       {
				  var_t val1437_2817;
				  val1437_2817 = (var_t) (arg2155_1950);
				  ((((box_set__221_t) CREF(node_1947))->var) = ((var_t) val1437_2817), BUNSPEC);
			       }
			    }
			    {
			       node_t arg2157_1952;
			       arg2157_1952 = glo__115_globalize_node((((box_set__221_t) CREF(node_1947))->value), integrator_11);
			       ((((box_set__221_t) CREF(node_1947))->value) = ((node_t) arg2157_1952), BUNSPEC);
			    }
			    aux_3443 = (obj_t) (node_1947);
			 }
			 break;
		      default:
		       case_else1977_1694:
			 if (PROCEDUREP(method1971_1690))
			   {
			      aux_3443 = PROCEDURE_ENTRY(method1971_1690) (method1971_1690, (obj_t) (node_10), (obj_t) (integrator_11), BEOA);
			   }
			 else
			   {
			      obj_t fun1966_1684;
			      fun1966_1684 = PROCEDURE_REF(glo__env_172_globalize_node, ((long) 0));
			      aux_3443 = PROCEDURE_ENTRY(fun1966_1684) (fun1966_1684, (obj_t) (node_10), (obj_t) (integrator_11), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1977_1694;
		 }
	    }
	    return (node_t) (aux_3443);
	 }
      }
   }
}


/* _glo!2192 */ obj_t 
_glo_2192_233_globalize_node(obj_t env_2832, obj_t node_2833, obj_t integrator_2834)
{
   {
      node_t aux_3987;
      aux_3987 = glo__115_globalize_node((node_t) (node_2833), (variable_t) (integrator_2834));
      return (obj_t) (aux_3987);
   }
}


/* glo!-default1624 */ node_t 
glo__default1624_187_globalize_node(node_t node_12, variable_t integrator_13)
{
   FAILURE(CNST_TABLE_REF(((long) 8)), string2193_globalize_node, (obj_t) (node_12));
}


/* _glo!-default1624 */ obj_t 
_glo__default1624_46_globalize_node(obj_t env_2835, obj_t node_2836, obj_t integrator_2837)
{
   {
      node_t aux_3995;
      aux_3995 = glo__default1624_187_globalize_node((node_t) (node_2836), (variable_t) (integrator_2837));
      return (obj_t) (aux_3995);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_node()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_type_cache(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_ast_sexp(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_ast_env(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_ast_local(((long) 0), "GLOBALIZE_NODE");
   module_initialization_70_globalize_free(((long) 0), "GLOBALIZE_NODE");
   return module_initialization_70_globalize_local__global_194(((long) 0), "GLOBALIZE_NODE");
}
