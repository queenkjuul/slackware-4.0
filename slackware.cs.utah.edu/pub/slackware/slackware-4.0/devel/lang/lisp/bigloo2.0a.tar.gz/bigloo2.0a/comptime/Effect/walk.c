/*===========================================================================*/
/*   (Effect/walk.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct local_from_91
  {
     obj_t from;
  }
             *local_from_91_t;

typedef struct global_from_205
  {
     obj_t from;
  }
               *global_from_205_t;


static obj_t method_init_76_effect_walk();
extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_effect_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_effect_cgraph(long, char *);
extern obj_t module_initialization_70_effect_spread(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t local_from_91_effect_cgraph;
extern obj_t get_var_all_239_effect_cgraph();
extern bool_t spread_side_effect__136_effect_spread(node_t);
static obj_t iterate_to_fix_point__167_effect_walk(obj_t);
static obj_t imported_modules_init_94_effect_walk();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t effect_walk__175_effect_walk(obj_t);
static obj_t library_modules_init_112_effect_walk();
extern obj_t fun_call_graph__231_effect_cgraph(variable_t);
extern obj_t open_input_string(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t global_from_205_effect_cgraph;
static obj_t _effect_walk__96_effect_walk(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_effect_walk = BUNSPEC;
extern obj_t get_var_side_effect_0_effect_cgraph();
static obj_t cnst_init_137_effect_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(effect_walk__env_176_effect_walk, _effect_walk__96_effect_walk1667, _effect_walk__96_effect_walk, 0L, 1);
DEFINE_STRING(string1661_effect_walk, string1661_effect_walk1668, "DONE PASS-STARTED ", 18);
DEFINE_STRING(string1659_effect_walk, string1659_effect_walk1669, " error", 6);
DEFINE_STRING(string1660_effect_walk, string1660_effect_walk1670, "failure during postlude hook", 28);
DEFINE_STRING(string1658_effect_walk, string1658_effect_walk1671, " occured, ending ...", 20);
DEFINE_STRING(string1657_effect_walk, string1657_effect_walk1672, "failure during prelude hook", 27);
DEFINE_STRING(string1656_effect_walk, string1656_effect_walk1673, "   . ", 5);
DEFINE_STRING(string1655_effect_walk, string1655_effect_walk1674, "Effect", 6);


/* module-initialization */ obj_t 
module_initialization_70_effect_walk(long checksum_1313, char *from_1314)
{
   if (CBOOL(require_initialization_114_effect_walk))
     {
	require_initialization_114_effect_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_effect_walk();
	cnst_init_137_effect_walk();
	imported_modules_init_94_effect_walk();
	method_init_76_effect_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_effect_walk()
{
   module_initialization_70___object(((long) 0), "EFFECT_WALK");
   module_initialization_70___r4_output_6_10_3(((long) 0), "EFFECT_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "EFFECT_WALK");
   module_initialization_70___reader(((long) 0), "EFFECT_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_effect_walk()
{
   {
      obj_t cnst_port_138_1305;
      cnst_port_138_1305 = open_input_string(string1661_effect_walk);
      {
	 long i_1306;
	 i_1306 = ((long) 1);
       loop_1307:
	 {
	    bool_t test1662_1308;
	    test1662_1308 = (i_1306 == ((long) -1));
	    if (test1662_1308)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1663_1309;
		    {
		       obj_t list1664_1310;
		       {
			  obj_t arg1665_1311;
			  arg1665_1311 = BNIL;
			  list1664_1310 = MAKE_PAIR(cnst_port_138_1305, arg1665_1311);
		       }
		       arg1663_1309 = read___reader(list1664_1310);
		    }
		    CNST_TABLE_SET(i_1306, arg1663_1309);
		 }
		 {
		    int aux_1312;
		    {
		       long aux_1332;
		       aux_1332 = (i_1306 - ((long) 1));
		       aux_1312 = (int) (aux_1332);
		    }
		    {
		       long i_1335;
		       i_1335 = (long) (aux_1312);
		       i_1306 = i_1335;
		       goto loop_1307;
		    }
		 }
	      }
	 }
      }
   }
}


/* effect-walk! */ obj_t 
effect_walk__175_effect_walk(obj_t globals_1)
{
   {
      obj_t list1479_796;
      {
	 obj_t arg1481_798;
	 {
	    obj_t arg1484_800;
	    {
	       obj_t aux_1337;
	       aux_1337 = BCHAR(((unsigned char) '\n'));
	       arg1484_800 = MAKE_PAIR(aux_1337, BNIL);
	    }
	    arg1481_798 = MAKE_PAIR(string1655_effect_walk, arg1484_800);
	 }
	 list1479_796 = MAKE_PAIR(string1656_effect_walk, arg1481_798);
      }
      verbose_tools_speek(BINT(((long) 1)), list1479_796);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1655_effect_walk;
   {
      obj_t hooks_802;
      obj_t hnames_803;
      hooks_802 = BNIL;
      hnames_803 = BNIL;
    loop_804:
      if (NULLP(hooks_802))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1490_809;
	   {
	      obj_t fun1499_815;
	      fun1499_815 = CAR(hooks_802);
	      {
		 obj_t aux_1349;
		 aux_1349 = PROCEDURE_ENTRY(fun1499_815) (fun1499_815, BEOA);
		 test1490_809 = CBOOL(aux_1349);
	      }
	   }
	   if (test1490_809)
	     {
		{
		   obj_t hnames_1356;
		   obj_t hooks_1354;
		   hooks_1354 = CDR(hooks_802);
		   hnames_1356 = CDR(hnames_803);
		   hnames_803 = hnames_1356;
		   hooks_802 = hooks_1354;
		   goto loop_804;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1655_effect_walk, string1657_effect_walk, CAR(hnames_803));
	     }
	}
   }
   {
      obj_t l1471_816;
      l1471_816 = globals_1;
    lname1472_817:
      if (PAIRP(l1471_816))
	{
	   {
	      variable_t aux_1362;
	      {
		 obj_t aux_1363;
		 aux_1363 = CAR(l1471_816);
		 aux_1362 = (variable_t) (aux_1363);
	      }
	      fun_call_graph__231_effect_cgraph(aux_1362);
	   }
	   {
	      obj_t l1471_1367;
	      l1471_1367 = CDR(l1471_816);
	      l1471_816 = l1471_1367;
	      goto lname1472_817;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t arg1502_821;
      arg1502_821 = get_var_side_effect_0_effect_cgraph();
      iterate_to_fix_point__167_effect_walk(arg1502_821);
   }
   {
      obj_t l1473_822;
      {
	 obj_t arg1503_824;
	 arg1503_824 = get_var_all_239_effect_cgraph();
	 l1473_822 = arg1503_824;
       lname1474_823:
	 if (PAIRP(l1473_822))
	   {
	      {
		 value_t fun_827;
		 {
		    variable_t obj_1229;
		    {
		       obj_t aux_1374;
		       aux_1374 = CAR(l1473_822);
		       obj_1229 = (variable_t) (aux_1374);
		    }
		    fun_827 = (((variable_t) CREF(obj_1229))->value);
		 }
		 {
		    bool_t test_1378;
		    {
		       obj_t aux_1379;
		       {
			  fun_t obj_1230;
			  obj_1230 = (fun_t) (fun_827);
			  aux_1379 = (((fun_t) CREF(obj_1230))->side_effect__165);
		       }
		       test_1378 = (aux_1379 == BUNSPEC);
		    }
		    if (test_1378)
		      {
			 fun_t obj_1233;
			 obj_t val1110_1234;
			 obj_1233 = (fun_t) (fun_827);
			 val1110_1234 = BFALSE;
			 ((((fun_t) CREF(obj_1233))->side_effect__165) = ((obj_t) val1110_1234), BUNSPEC);
		      }
		    else
		      {
			 BUNSPEC;
		      }
		 }
	      }
	      {
		 obj_t l1473_1385;
		 l1473_1385 = CDR(l1473_822);
		 l1473_822 = l1473_1385;
		 goto lname1474_823;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
   }
   {
      obj_t l1475_831;
      l1475_831 = globals_1;
    lname1476_832:
      if (PAIRP(l1475_831))
	{
	   {
	      node_t aux_1389;
	      {
		 obj_t aux_1390;
		 {
		    sfun_t obj_1239;
		    {
		       value_t aux_1391;
		       {
			  global_t obj_1238;
			  {
			     obj_t aux_1392;
			     aux_1392 = CAR(l1475_831);
			     obj_1238 = (global_t) (aux_1392);
			  }
			  aux_1391 = (((global_t) CREF(obj_1238))->value);
		       }
		       obj_1239 = (sfun_t) (aux_1391);
		    }
		    aux_1390 = (((sfun_t) CREF(obj_1239))->body);
		 }
		 aux_1389 = (node_t) (aux_1390);
	      }
	      spread_side_effect__136_effect_spread(aux_1389);
	   }
	   {
	      obj_t l1475_1400;
	      l1475_1400 = CDR(l1475_831);
	      l1475_831 = l1475_1400;
	      goto lname1476_832;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      bool_t test1516_839;
      {
	 long n1_1241;
	 n1_1241 = (long) CINT(_nb_error_on_pass__70_tools_error);
	 test1516_839 = (n1_1241 > ((long) 0));
      }
      if (test1516_839)
	{
	   {
	      char *arg1519_842;
	      {
		 bool_t test1528_849;
		 {
		    bool_t test1529_850;
		    {
		       obj_t obj_1243;
		       obj_1243 = _nb_error_on_pass__70_tools_error;
		       test1529_850 = INTEGERP(obj_1243);
		    }
		    if (test1529_850)
		      {
			 test1528_849 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
		      }
		    else
		      {
			 test1528_849 = ((bool_t) 0);
		      }
		 }
		 if (test1528_849)
		   {
		      arg1519_842 = "s";
		   }
		 else
		   {
		      arg1519_842 = "";
		   }
	      }
	      {
		 obj_t list1523_844;
		 {
		    obj_t arg1524_845;
		    {
		       obj_t arg1525_846;
		       {
			  obj_t arg1526_847;
			  arg1526_847 = MAKE_PAIR(string1658_effect_walk, BNIL);
			  {
			     obj_t aux_1411;
			     aux_1411 = string_to_bstring(arg1519_842);
			     arg1525_846 = MAKE_PAIR(aux_1411, arg1526_847);
			  }
		       }
		       arg1524_845 = MAKE_PAIR(string1659_effect_walk, arg1525_846);
		    }
		    list1523_844 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1524_845);
		 }
		 fprint___r4_output_6_10_3(current_error_port, list1523_844);
	      }
	   }
	   {
	      obj_t res1654_1245;
	      exit(((long) -1));
	      res1654_1245 = BINT(((long) -1));
	      return res1654_1245;
	   }
	}
      else
	{
	   obj_t hooks_851;
	   obj_t hnames_852;
	   hooks_851 = BNIL;
	   hnames_852 = BNIL;
	 loop_853:
	   if (NULLP(hooks_851))
	     {
		return globals_1;
	     }
	   else
	     {
		bool_t test1534_858;
		{
		   obj_t fun1540_863;
		   fun1540_863 = CAR(hooks_851);
		   {
		      obj_t aux_1422;
		      aux_1422 = PROCEDURE_ENTRY(fun1540_863) (fun1540_863, BEOA);
		      test1534_858 = CBOOL(aux_1422);
		   }
		}
		if (test1534_858)
		  {
		     {
			obj_t hnames_1429;
			obj_t hooks_1427;
			hooks_1427 = CDR(hooks_851);
			hnames_1429 = CDR(hnames_852);
			hnames_852 = hnames_1429;
			hooks_851 = hooks_1427;
			goto loop_853;
		     }
		  }
		else
		  {
		     return internal_error_43_tools_error(_current_pass__25_engine_pass, string1660_effect_walk, CAR(hnames_852));
		  }
	     }
	}
   }
}


/* _effect-walk! */ obj_t 
_effect_walk__96_effect_walk(obj_t env_1303, obj_t globals_1304)
{
   return effect_walk__175_effect_walk(globals_1304);
}


/* iterate-to-fix-point! */ obj_t 
iterate_to_fix_point__167_effect_walk(obj_t w_2)
{
   if (NULLP(w_2))
     {
	return CNST_TABLE_REF(((long) 1));
     }
   else
     {
	obj_t l1477_865;
	{
	   bool_t aux_1437;
	   l1477_865 = w_2;
	 lname1478_866:
	   if (PAIRP(l1477_865))
	     {
		{
		   obj_t var_868;
		   var_868 = CAR(l1477_865);
		   {
		      value_t fun_869;
		      {
			 variable_t obj_1255;
			 obj_1255 = (variable_t) (var_868);
			 fun_869 = (((variable_t) CREF(obj_1255))->value);
		      }
		      {
			 bool_t test_1443;
			 {
			    obj_t aux_1444;
			    {
			       fun_t obj_1256;
			       obj_1256 = (fun_t) (fun_869);
			       aux_1444 = (((fun_t) CREF(obj_1256))->side_effect__165);
			    }
			    test_1443 = (aux_1444 == BTRUE);
			 }
			 if (test_1443)
			   {
			      BUNSPEC;
			   }
			 else
			   {
			      {
				 fun_t obj_1259;
				 obj_t val1110_1260;
				 obj_1259 = (fun_t) (fun_869);
				 val1110_1260 = BTRUE;
				 ((((fun_t) CREF(obj_1259))->side_effect__165) = ((obj_t) val1110_1260), BUNSPEC);
			      }
			      {
				 bool_t test1544_871;
				 test1544_871 = is_a__118___object(var_868, local_from_91_effect_cgraph);
				 if (test1544_871)
				   {
				      {
					 obj_t aux_1452;
					 {
					    local_from_91_t obj_1262;
					    obj_1262 = (local_from_91_t) (var_868);
					    {
					       obj_t aux_1454;
					       {
						  object_t aux_1455;
						  aux_1455 = (object_t) (obj_1262);
						  aux_1454 = OBJECT_WIDENING(aux_1455);
					       }
					       aux_1452 = (((local_from_91_t) CREF(aux_1454))->from);
					    }
					 }
					 iterate_to_fix_point__167_effect_walk(aux_1452);
				      }
				   }
				 else
				   {
				      bool_t test1546_873;
				      test1546_873 = is_a__118___object(var_868, global_from_205_effect_cgraph);
				      if (test1546_873)
					{
					   {
					      obj_t aux_1462;
					      {
						 global_from_205_t obj_1264;
						 obj_1264 = (global_from_205_t) (var_868);
						 {
						    obj_t aux_1464;
						    {
						       object_t aux_1465;
						       aux_1465 = (object_t) (obj_1264);
						       aux_1464 = OBJECT_WIDENING(aux_1465);
						    }
						    aux_1462 = (((global_from_205_t) CREF(aux_1464))->from);
						 }
					      }
					      iterate_to_fix_point__167_effect_walk(aux_1462);
					   }
					}
				      else
					{
					   BFALSE;
					}
				   }
			      }
			   }
		      }
		   }
		}
		{
		   obj_t l1477_1470;
		   l1477_1470 = CDR(l1477_865);
		   l1477_865 = l1477_1470;
		   goto lname1478_866;
		}
	     }
	   else
	     {
		aux_1437 = ((bool_t) 1);
	     }
	   return BBOOL(aux_1437);
	}
     }
}


/* method-init */ obj_t 
method_init_76_effect_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_effect_walk()
{
   module_initialization_70_tools_speek(((long) 0), "EFFECT_WALK");
   module_initialization_70_tools_error(((long) 0), "EFFECT_WALK");
   module_initialization_70_engine_pass(((long) 0), "EFFECT_WALK");
   module_initialization_70_tools_trace(((long) 0), "EFFECT_WALK");
   module_initialization_70_type_type(((long) 0), "EFFECT_WALK");
   module_initialization_70_ast_var(((long) 0), "EFFECT_WALK");
   module_initialization_70_ast_node(((long) 0), "EFFECT_WALK");
   module_initialization_70_effect_cgraph(((long) 0), "EFFECT_WALK");
   return module_initialization_70_effect_spread(((long) 0), "EFFECT_WALK");
}
