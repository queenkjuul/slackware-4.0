/*===========================================================================*/
/*   (Eval/progn.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _replace__98___progn(obj_t, obj_t, obj_t);
static obj_t symbol1224___progn = BUNSPEC;
extern obj_t replace__160___progn(obj_t, obj_t);
static obj_t loop_1223___progn(obj_t);
static obj_t _normalize_progn_158___progn(obj_t, obj_t);
static obj_t loop___progn(obj_t);
static obj_t _normalize_body_17___progn(obj_t, obj_t);
extern obj_t module_initialization_70___progn(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t imported_modules_init_94___progn();
static obj_t require_initialization_114___progn = BUNSPEC;
extern obj_t normalize_body_95___progn(obj_t);
extern obj_t normalize_progn_143___progn(obj_t);
static obj_t cnst_init_137___progn();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( normalize_progn_env_42___progn, _normalize_progn_158___progn1228, _normalize_progn_158___progn, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( normalize_body_env_147___progn, _normalize_body_17___progn1229, _normalize_body_17___progn, 0L, 1 );
DEFINE_STRING( string1226___progn, string1226___progn1230, "Type `extended pair' expected for expression", 44 );
DEFINE_STRING( string1225___progn, string1225___progn1231, "cer", 3 );
DEFINE_EXPORT_PROCEDURE( replace__env_157___progn, _replace__98___progn1232, _replace__98___progn, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___progn(long checksum_631, char * from_632)
{
if(CBOOL(require_initialization_114___progn)){
require_initialization_114___progn = BBOOL(((bool_t)0));
cnst_init_137___progn();
imported_modules_init_94___progn();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___progn()
{
return (symbol1224___progn = string_to_symbol("BEGIN"),
BUNSPEC);
}


/* normalize-progn */obj_t normalize_progn_143___progn(obj_t body_1)
{
if(PAIRP(body_1)){
{
obj_t res_321;
{
obj_t arg1014_329;
obj_t arg1015_330;
arg1014_329 = symbol1224___progn;
{
obj_t arg1018_333;
obj_t arg1019_334;
{
obj_t aux_641;
{
bool_t test_642;
{
obj_t aux_643;
aux_643 = CAR(body_1);
test_642 = (aux_643==symbol1224___progn);
}
if(test_642){
aux_641 = CDR(body_1);
}
 else {
aux_641 = body_1;
}
}
arg1018_333 = loop_1223___progn(aux_641);
}
arg1019_334 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1015_330 = append_2_18___r4_pairs_and_lists_6_3(arg1018_333, arg1019_334);
}
{
obj_t list1016_331;
list1016_331 = MAKE_PAIR(arg1015_330, BNIL);
res_321 = cons__138___r4_pairs_and_lists_6_3(arg1014_329, list1016_331);
}
}
{
bool_t test1007_322;
test1007_322 = EXTENDED_PAIRP(body_1);
if(test1007_322){
return replace__160___progn(body_1, res_321);
}
 else {
bool_t test1008_323;
{
obj_t aux_655;
aux_655 = CAR(body_1);
test1008_323 = EXTENDED_PAIRP(aux_655);
}
if(test1008_323){
{
obj_t arg1009_324;
obj_t arg1010_325;
obj_t arg1011_326;
arg1009_324 = CAR(res_321);
arg1010_325 = CDR(res_321);
{
obj_t arg1012_327;
arg1012_327 = CAR(body_1);
{
bool_t test1173_568;
test1173_568 = EXTENDED_PAIRP(arg1012_327);
if(test1173_568){
arg1011_326 = CER(arg1012_327);
}
 else {
FAILURE(string1225___progn,string1226___progn,arg1012_327);}
}
}
return MAKE_EXTENDED_PAIR(arg1009_324, arg1010_325, arg1011_326);
}
}
 else {
return res_321;
}
}
}
}
}
 else {
{
obj_t arg1037_354;
arg1037_354 = symbol1224___progn;
{
obj_t list1039_356;
{
obj_t arg1040_357;
arg1040_357 = MAKE_PAIR(BNIL, BNIL);
list1039_356 = MAKE_PAIR(body_1, arg1040_357);
}
return cons__138___r4_pairs_and_lists_6_3(arg1037_354, list1039_356);
}
}
}
}


/* loop_1223 */obj_t loop_1223___progn(obj_t body_335)
{
if(NULLP(body_335)){
return BNIL;
}
 else {
obj_t expr_342;
expr_342 = CAR(body_335);
{
bool_t test_673;
if(PAIRP(expr_342)){
obj_t aux_676;
aux_676 = CAR(expr_342);
test_673 = (aux_676==symbol1224___progn);
}
 else {
test_673 = ((bool_t)0);
}
if(test_673){
obj_t arg1026_344;
obj_t arg1027_345;
arg1026_344 = CDR(expr_342);
arg1027_345 = loop_1223___progn(CDR(body_335));
return append_2_18___r4_pairs_and_lists_6_3(arg1026_344, arg1027_345);
}
 else {
obj_t arg1029_347;
arg1029_347 = loop_1223___progn(CDR(body_335));
return MAKE_PAIR(expr_342, arg1029_347);
}
}
}
}


/* _normalize-progn */obj_t _normalize_progn_158___progn(obj_t env_624, obj_t body_625)
{
return normalize_progn_143___progn(body_625);
}


/* normalize-body */obj_t normalize_body_95___progn(obj_t body_2)
{
if(PAIRP(body_2)){
{
obj_t res_360;
{
obj_t arg1049_367;
obj_t arg1050_368;
arg1049_367 = symbol1224___progn;
{
obj_t arg1054_371;
obj_t arg1055_372;
{
obj_t aux_689;
{
bool_t test_690;
{
obj_t aux_691;
aux_691 = CAR(body_2);
test_690 = (aux_691==symbol1224___progn);
}
if(test_690){
aux_689 = CDR(body_2);
}
 else {
aux_689 = body_2;
}
}
arg1054_371 = loop___progn(aux_689);
}
arg1055_372 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1050_368 = append_2_18___r4_pairs_and_lists_6_3(arg1054_371, arg1055_372);
}
{
obj_t list1051_369;
list1051_369 = MAKE_PAIR(arg1050_368, BNIL);
res_360 = cons__138___r4_pairs_and_lists_6_3(arg1049_367, list1051_369);
}
}
{
bool_t test1043_361;
{
obj_t aux_700;
aux_700 = CAR(body_2);
test1043_361 = EXTENDED_PAIRP(aux_700);
}
if(test1043_361){
{
obj_t arg1044_362;
obj_t arg1045_363;
obj_t arg1046_364;
arg1044_362 = CAR(res_360);
arg1045_363 = CDR(res_360);
{
obj_t arg1047_365;
arg1047_365 = CAR(body_2);
{
bool_t test1173_598;
test1173_598 = EXTENDED_PAIRP(arg1047_365);
if(test1173_598){
arg1046_364 = CER(arg1047_365);
}
 else {
FAILURE(string1225___progn,string1226___progn,arg1047_365);}
}
}
return MAKE_EXTENDED_PAIR(arg1044_362, arg1045_363, arg1046_364);
}
}
 else {
return res_360;
}
}
}
}
 else {
{
obj_t arg1076_392;
arg1076_392 = symbol1224___progn;
{
obj_t list1078_394;
{
obj_t arg1079_395;
arg1079_395 = MAKE_PAIR(BNIL, BNIL);
list1078_394 = MAKE_PAIR(body_2, arg1079_395);
}
return cons__138___r4_pairs_and_lists_6_3(arg1076_392, list1078_394);
}
}
}
}


/* loop */obj_t loop___progn(obj_t body_373)
{
if(NULLP(body_373)){
return BNIL;
}
 else {
obj_t expr_380;
expr_380 = CAR(body_373);
{
bool_t test_718;
if(PAIRP(expr_380)){
obj_t aux_721;
aux_721 = CAR(expr_380);
test_718 = (aux_721==symbol1224___progn);
}
 else {
test_718 = ((bool_t)0);
}
if(test_718){
obj_t arg1062_382;
obj_t arg1063_383;
arg1062_382 = CDR(expr_380);
arg1063_383 = loop___progn(CDR(body_373));
return append_2_18___r4_pairs_and_lists_6_3(arg1062_382, arg1063_383);
}
 else {
obj_t arg1066_385;
arg1066_385 = loop___progn(CDR(body_373));
return MAKE_PAIR(expr_380, arg1066_385);
}
}
}
}


/* _normalize-body */obj_t _normalize_body_17___progn(obj_t env_626, obj_t body_627)
{
return normalize_body_95___progn(body_627);
}


/* replace! */obj_t replace__160___progn(obj_t p1_3, obj_t p2_4)
{
{
bool_t test1081_397;
if(PAIRP(p1_3)){
if(PAIRP(p2_4)){
bool_t test1086_402;
test1086_402 = EXTENDED_PAIRP(p2_4);
if(test1086_402){
test1081_397 = ((bool_t)0);
}
 else {
test1081_397 = ((bool_t)1);
}
}
 else {
test1081_397 = ((bool_t)0);
}
}
 else {
test1081_397 = ((bool_t)0);
}
if(test1081_397){
{
obj_t aux_739;
aux_739 = CAR(p2_4);
SET_CAR(p1_3, aux_739);
}
{
obj_t aux_742;
aux_742 = CDR(p2_4);
SET_CDR(p1_3, aux_742);
}
return p1_3;
}
 else {
return p2_4;
}
}
}


/* _replace! */obj_t _replace__98___progn(obj_t env_628, obj_t p1_629, obj_t p2_630)
{
return replace__160___progn(p1_629, p2_630);
}


/* imported-modules-init */obj_t imported_modules_init_94___progn()
{
module_initialization_70___error(((long)0), "__PROGN");
module_initialization_70___bigloo(((long)0), "__PROGN");
module_initialization_70___tvector(((long)0), "__PROGN");
module_initialization_70___structure(((long)0), "__PROGN");
module_initialization_70___bexit(((long)0), "__PROGN");
module_initialization_70___r4_numbers_6_5(((long)0), "__PROGN");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__PROGN");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__PROGN");
module_initialization_70___r4_characters_6_6(((long)0), "__PROGN");
module_initialization_70___r4_equivalence_6_2(((long)0), "__PROGN");
module_initialization_70___r4_booleans_6_1(((long)0), "__PROGN");
module_initialization_70___r4_symbols_6_4(((long)0), "__PROGN");
module_initialization_70___r4_strings_6_7(((long)0), "__PROGN");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__PROGN");
module_initialization_70___r4_input_6_10_2(((long)0), "__PROGN");
module_initialization_70___r4_control_features_6_9(((long)0), "__PROGN");
module_initialization_70___r4_vectors_6_8(((long)0), "__PROGN");
module_initialization_70___r4_ports_6_10_1(((long)0), "__PROGN");
return module_initialization_70___r4_output_6_10_3(((long)0), "__PROGN");
}

