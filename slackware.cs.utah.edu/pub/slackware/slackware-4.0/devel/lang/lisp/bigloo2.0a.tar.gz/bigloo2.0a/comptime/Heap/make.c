/*===========================================================================*/
/*   (Heap/make.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern obj_t set_obj_string_mode__22___intext(obj_t);
static obj_t method_init_76_heap_make();
extern obj_t get_tenv_245_type_env();
extern obj_t output_obj(obj_t, obj_t);
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t make_add_heap_195_heap_make();
static obj_t _prepare_additional_globals__38_heap_make(obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_heap_make(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___intext(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t unbind_global__45_ast_env(obj_t, obj_t);
extern obj_t _heap_name__135_engine_param;
extern obj_t get_genv_41_ast_env();
extern obj_t make_heap_12_heap_make();
static obj_t imported_modules_init_94_heap_make();
extern obj_t _additional_include_foreign__44_engine_param;
static obj_t library_modules_init_112_heap_make();
static bool_t prepare_additional_globals__227_heap_make();
extern obj_t create_vector(long);
extern obj_t open_input_string(obj_t);
static obj_t _make_add_heap_150_heap_make(obj_t);
extern obj_t close_binary_port(obj_t);
extern obj_t _lib_dir__34_engine_param;
static obj_t _make_heap_207_heap_make(obj_t);
extern obj_t for_each_global__88_ast_env(obj_t);
extern obj_t open_output_binary_file(obj_t);
extern obj_t _additional_heap_name__223_engine_param;
static obj_t arg1259_heap_make(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _prepare_globals__42_heap_make(obj_t);
static obj_t arg1216_heap_make(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static bool_t prepare_globals__191_heap_make();
static obj_t require_initialization_114_heap_make = BUNSPEC;
extern obj_t make_file_name_203___os(obj_t, obj_t);
static obj_t cnst_init_137_heap_make();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[7];

DEFINE_EXPORT_PROCEDURE(make_add_heap_env_57_heap_make, _make_add_heap_150_heap_make1321, _make_add_heap_150_heap_make, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_heap_env_74_heap_make, _make_heap_207_heap_make1322, _make_heap_207_heap_make, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1313_heap_make, arg1259_heap_make1323, arg1259_heap_make, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1309_heap_make, arg1216_heap_make1324, arg1216_heap_make, 0L, 1);
DEFINE_STATIC_PROCEDURE(prepare_additional_globals__env_129_heap_make, _prepare_additional_globals__38_heap_make1325, _prepare_additional_globals__38_heap_make, 0L, 0);
DEFINE_STATIC_PROCEDURE(prepare_globals__env_2_heap_make, _prepare_globals__42_heap_make1326, _prepare_globals__42_heap_make, 0L, 0);
DEFINE_STRING(string1314_heap_make, string1314_heap_make1327, "(PREPARE-ADDITIONAL-GLOBALS!) IMPORT EXPORT STATIC PAIR (PREPARE-GLOBALS!) PASS-STARTED ", 88);
DEFINE_STRING(string1312_heap_make, string1312_heap_make1328, "make-add-heap", 13);
DEFINE_STRING(string1311_heap_make, string1311_heap_make1329, "make-addd-heap", 14);
DEFINE_STRING(string1310_heap_make, string1310_heap_make1330, "Library heap", 12);
DEFINE_STRING(string1308_heap_make, string1308_heap_make1331, "Illegal heap's name", 19);
DEFINE_STRING(string1307_heap_make, string1307_heap_make1332, "Can't open output port", 22);
DEFINE_STRING(string1306_heap_make, string1306_heap_make1333, "make-heap", 9);
DEFINE_STRING(string1305_heap_make, string1305_heap_make1334, "failure during prelude hook", 27);
DEFINE_STRING(string1304_heap_make, string1304_heap_make1335, "   . ", 5);
DEFINE_STRING(string1303_heap_make, string1303_heap_make1336, "Heap", 4);


/* module-initialization */ obj_t 
module_initialization_70_heap_make(long checksum_604, char *from_605)
{
   if (CBOOL(require_initialization_114_heap_make))
     {
	require_initialization_114_heap_make = BBOOL(((bool_t) 0));
	library_modules_init_112_heap_make();
	cnst_init_137_heap_make();
	imported_modules_init_94_heap_make();
	method_init_76_heap_make();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_heap_make()
{
   module_initialization_70___intext(((long) 0), "HEAP_MAKE");
   module_initialization_70___reader(((long) 0), "HEAP_MAKE");
   module_initialization_70___os(((long) 0), "HEAP_MAKE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_heap_make()
{
   {
      obj_t cnst_port_138_596;
      cnst_port_138_596 = open_input_string(string1314_heap_make);
      {
	 long i_597;
	 i_597 = ((long) 6);
       loop_598:
	 {
	    bool_t test1315_599;
	    test1315_599 = (i_597 == ((long) -1));
	    if (test1315_599)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1316_600;
		    {
		       obj_t list1317_601;
		       {
			  obj_t arg1319_602;
			  arg1319_602 = BNIL;
			  list1317_601 = MAKE_PAIR(cnst_port_138_596, arg1319_602);
		       }
		       arg1316_600 = read___reader(list1317_601);
		    }
		    CNST_TABLE_SET(i_597, arg1316_600);
		 }
		 {
		    int aux_603;
		    {
		       long aux_622;
		       aux_622 = (i_597 - ((long) 1));
		       aux_603 = (int) (aux_622);
		    }
		    {
		       long i_625;
		       i_625 = (long) (aux_603);
		       i_597 = i_625;
		       goto loop_598;
		    }
		 }
	      }
	 }
      }
   }
}


/* make-heap */ obj_t 
make_heap_12_heap_make()
{
   {
      obj_t list1183_301;
      {
	 obj_t arg1188_303;
	 {
	    obj_t arg1191_305;
	    {
	       obj_t aux_627;
	       aux_627 = BCHAR(((unsigned char) '\n'));
	       arg1191_305 = MAKE_PAIR(aux_627, BNIL);
	    }
	    arg1188_303 = MAKE_PAIR(string1303_heap_make, arg1191_305);
	 }
	 list1183_301 = MAKE_PAIR(string1304_heap_make, arg1188_303);
      }
      verbose_tools_speek(BINT(((long) 1)), list1183_301);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1303_heap_make;
   {
      obj_t hooks_307;
      obj_t hnames_308;
      {
	 obj_t arg1193_310;
	 obj_t arg1194_311;
	 {
	    obj_t list1195_312;
	    list1195_312 = MAKE_PAIR(prepare_globals__env_2_heap_make, BNIL);
	    arg1193_310 = list1195_312;
	 }
	 arg1194_311 = CNST_TABLE_REF(((long) 1));
	 hooks_307 = arg1193_310;
	 hnames_308 = arg1194_311;
       loop_309:
	 if (NULLP(hooks_307))
	   {
	      CNST_TABLE_REF(((long) 0));
	   }
	 else
	   {
	      bool_t test1198_315;
	      {
		 obj_t fun1206_321;
		 fun1206_321 = CAR(hooks_307);
		 {
		    obj_t aux_641;
		    aux_641 = PROCEDURE_ENTRY(fun1206_321) (fun1206_321, BEOA);
		    test1198_315 = CBOOL(aux_641);
		 }
	      }
	      if (test1198_315)
		{
		   {
		      obj_t hnames_648;
		      obj_t hooks_646;
		      hooks_646 = CDR(hooks_307);
		      hnames_648 = CDR(hnames_308);
		      hnames_308 = hnames_648;
		      hooks_307 = hooks_646;
		      goto loop_309;
		   }
		}
	      else
		{
		   internal_error_43_tools_error(string1303_heap_make, string1305_heap_make, CAR(hnames_308));
		}
	   }
      }
   }
   set_obj_string_mode__22___intext(CNST_TABLE_REF(((long) 2)));
   {
      bool_t test1208_323;
      {
	 obj_t obj_525;
	 obj_525 = _heap_name__135_engine_param;
	 test1208_323 = STRINGP(obj_525);
      }
      if (test1208_323)
	{
	   obj_t hname_324;
	   {
	      obj_t arg1214_330;
	      {
		 obj_t pair_526;
		 pair_526 = _lib_dir__34_engine_param;
		 arg1214_330 = CAR(pair_526);
	      }
	      hname_324 = make_file_name_203___os(arg1214_330, _heap_name__135_engine_param);
	   }
	   {
	      obj_t port_325;
	      port_325 = open_output_binary_file(hname_324);
	      if (BINARY_PORTP(port_325))
		{
		   {
		      obj_t arg1210_327;
		      {
			 obj_t arg1211_328;
			 obj_t arg1213_329;
			 arg1211_328 = get_genv_41_ast_env();
			 arg1213_329 = get_tenv_245_type_env();
			 arg1210_327 = MAKE_PAIR(arg1211_328, arg1213_329);
		      }
		      output_obj(port_325, arg1210_327);
		   }
		   return close_binary_port(port_325);
		}
	      else
		{
		   FAILURE(string1306_heap_make, string1307_heap_make, hname_324);
		}
	   }
	}
      else
	{
	   return user_error_151_tools_error(string1306_heap_make, string1308_heap_make, _heap_name__135_engine_param, BNIL);
	}
   }
}


/* _make-heap */ obj_t 
_make_heap_207_heap_make(obj_t env_586)
{
   return make_heap_12_heap_make();
}


/* prepare-globals! */ bool_t 
prepare_globals__191_heap_make()
{
   {
      obj_t arg1216_588;
      arg1216_588 = proc1309_heap_make;
      for_each_global__88_ast_env(arg1216_588);
   }
   return ((bool_t) 1);
}


/* _prepare-globals! */ obj_t 
_prepare_globals__42_heap_make(obj_t env_587)
{
   {
      bool_t aux_670;
      aux_670 = prepare_globals__191_heap_make();
      return BBOOL(aux_670);
   }
}


/* arg1216 */ obj_t 
arg1216_heap_make(obj_t env_589, obj_t g_590)
{
   {
      obj_t g_333;
      g_333 = g_590;
      {
	 bool_t test_673;
	 {
	    obj_t aux_677;
	    obj_t aux_674;
	    aux_677 = CNST_TABLE_REF(((long) 3));
	    {
	       global_t obj_537;
	       obj_537 = (global_t) (g_333);
	       aux_674 = (((global_t) CREF(obj_537))->import);
	    }
	    test_673 = (aux_674 == aux_677);
	 }
	 if (test_673)
	   {
	      {
		 obj_t aux_683;
		 obj_t aux_680;
		 {
		    global_t obj_541;
		    obj_541 = (global_t) (g_333);
		    aux_683 = (((global_t) CREF(obj_541))->module);
		 }
		 {
		    global_t obj_540;
		    obj_540 = (global_t) (g_333);
		    aux_680 = (((global_t) CREF(obj_540))->id);
		 }
		 unbind_global__45_ast_env(aux_680, aux_683);
	      }
	   }
	 else
	   {
	      bool_t test_687;
	      {
		 obj_t aux_691;
		 obj_t aux_688;
		 aux_691 = CNST_TABLE_REF(((long) 4));
		 {
		    global_t obj_542;
		    obj_542 = (global_t) (g_333);
		    aux_688 = (((global_t) CREF(obj_542))->import);
		 }
		 test_687 = (aux_688 == aux_691);
	      }
	      if (test_687)
		{
		   {
		      obj_t arg1222_339;
		      arg1222_339 = CNST_TABLE_REF(((long) 5));
		      {
			 global_t obj_545;
			 obj_545 = (global_t) (g_333);
			 ((((global_t) CREF(obj_545))->import) = ((obj_t) arg1222_339), BUNSPEC);
		      }
		   }
		}
	      else
		{
		   BUNSPEC;
		}
	   }
      }
      {
	 global_t obj_547;
	 obj_547 = (global_t) (g_333);
	 return ((((global_t) CREF(obj_547))->occurrence) = ((long) ((long) 0)), BUNSPEC);
      }
   }
}


/* make-add-heap */ obj_t 
make_add_heap_195_heap_make()
{
   {
      obj_t list1229_345;
      {
	 obj_t arg1232_347;
	 {
	    obj_t arg1234_349;
	    {
	       obj_t aux_699;
	       aux_699 = BCHAR(((unsigned char) '\n'));
	       arg1234_349 = MAKE_PAIR(aux_699, BNIL);
	    }
	    arg1232_347 = MAKE_PAIR(string1310_heap_make, arg1234_349);
	 }
	 list1229_345 = MAKE_PAIR(string1304_heap_make, arg1232_347);
      }
      verbose_tools_speek(BINT(((long) 1)), list1229_345);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1310_heap_make;
   {
      obj_t hooks_351;
      obj_t hnames_352;
      {
	 obj_t arg1236_354;
	 obj_t arg1238_355;
	 {
	    obj_t list1239_356;
	    list1239_356 = MAKE_PAIR(prepare_additional_globals__env_129_heap_make, BNIL);
	    arg1236_354 = list1239_356;
	 }
	 arg1238_355 = CNST_TABLE_REF(((long) 6));
	 hooks_351 = arg1236_354;
	 hnames_352 = arg1238_355;
       loop_353:
	 if (NULLP(hooks_351))
	   {
	      CNST_TABLE_REF(((long) 0));
	   }
	 else
	   {
	      bool_t test1242_359;
	      {
		 obj_t fun1249_365;
		 fun1249_365 = CAR(hooks_351);
		 {
		    obj_t aux_713;
		    aux_713 = PROCEDURE_ENTRY(fun1249_365) (fun1249_365, BEOA);
		    test1242_359 = CBOOL(aux_713);
		 }
	      }
	      if (test1242_359)
		{
		   {
		      obj_t hnames_720;
		      obj_t hooks_718;
		      hooks_718 = CDR(hooks_351);
		      hnames_720 = CDR(hnames_352);
		      hnames_352 = hnames_720;
		      hooks_351 = hooks_718;
		      goto loop_353;
		   }
		}
	      else
		{
		   internal_error_43_tools_error(string1310_heap_make, string1305_heap_make, CAR(hnames_352));
		}
	   }
      }
   }
   set_obj_string_mode__22___intext(CNST_TABLE_REF(((long) 2)));
   {
      bool_t test1251_367;
      {
	 obj_t obj_555;
	 obj_555 = _additional_heap_name__223_engine_param;
	 test1251_367 = STRINGP(obj_555);
      }
      if (test1251_367)
	{
	   obj_t hname_368;
	   hname_368 = _additional_heap_name__223_engine_param;
	   {
	      obj_t port_369;
	      port_369 = open_output_binary_file(hname_368);
	      if (BINARY_PORTP(port_369))
		{
		   {
		      obj_t arg1253_371;
		      {
			 obj_t v1182_372;
			 v1182_372 = create_vector(((long) 3));
			 {
			    obj_t obj_560;
			    obj_560 = _additional_include_foreign__44_engine_param;
			    VECTOR_SET(v1182_372, ((long) 2), obj_560);
			 }
			 {
			    obj_t arg1255_374;
			    arg1255_374 = get_tenv_245_type_env();
			    VECTOR_SET(v1182_372, ((long) 1), arg1255_374);
			 }
			 {
			    obj_t arg1257_376;
			    arg1257_376 = get_genv_41_ast_env();
			    VECTOR_SET(v1182_372, ((long) 0), arg1257_376);
			 }
			 arg1253_371 = v1182_372;
		      }
		      output_obj(port_369, arg1253_371);
		   }
		   return close_binary_port(port_369);
		}
	      else
		{
		   FAILURE(string1311_heap_make, string1307_heap_make, hname_368);
		}
	   }
	}
      else
	{
	   return user_error_151_tools_error(string1312_heap_make, string1308_heap_make, _additional_heap_name__223_engine_param, BNIL);
	}
   }
}


/* _make-add-heap */ obj_t 
_make_add_heap_150_heap_make(obj_t env_591)
{
   return make_add_heap_195_heap_make();
}


/* prepare-additional-globals! */ bool_t 
prepare_additional_globals__227_heap_make()
{
   {
      obj_t arg1259_593;
      arg1259_593 = proc1313_heap_make;
      for_each_global__88_ast_env(arg1259_593);
   }
   return ((bool_t) 1);
}


/* _prepare-additional-globals! */ obj_t 
_prepare_additional_globals__38_heap_make(obj_t env_592)
{
   {
      bool_t aux_743;
      aux_743 = prepare_additional_globals__227_heap_make();
      return BBOOL(aux_743);
   }
}


/* arg1259 */ obj_t 
arg1259_heap_make(obj_t env_594, obj_t g_595)
{
   {
      obj_t g_379;
      g_379 = g_595;
      {
	 bool_t test_746;
	 {
	    bool_t test_747;
	    {
	       obj_t aux_751;
	       obj_t aux_748;
	       aux_751 = CNST_TABLE_REF(((long) 3));
	       {
		  global_t obj_573;
		  obj_573 = (global_t) (g_379);
		  aux_748 = (((global_t) CREF(obj_573))->import);
	       }
	       test_747 = (aux_748 == aux_751);
	    }
	    if (test_747)
	      {
		 test_746 = ((bool_t) 1);
	      }
	    else
	      {
		 global_t obj_576;
		 obj_576 = (global_t) (g_379);
		 test_746 = (((global_t) CREF(obj_576))->library__255);
	      }
	 }
	 if (test_746)
	   {
	      {
		 obj_t aux_759;
		 obj_t aux_756;
		 {
		    global_t obj_578;
		    obj_578 = (global_t) (g_379);
		    aux_759 = (((global_t) CREF(obj_578))->module);
		 }
		 {
		    global_t obj_577;
		    obj_577 = (global_t) (g_379);
		    aux_756 = (((global_t) CREF(obj_577))->id);
		 }
		 unbind_global__45_ast_env(aux_756, aux_759);
	      }
	   }
	 else
	   {
	      bool_t test_763;
	      {
		 obj_t aux_767;
		 obj_t aux_764;
		 aux_767 = CNST_TABLE_REF(((long) 4));
		 {
		    global_t obj_579;
		    obj_579 = (global_t) (g_379);
		    aux_764 = (((global_t) CREF(obj_579))->import);
		 }
		 test_763 = (aux_764 == aux_767);
	      }
	      if (test_763)
		{
		   {
		      obj_t arg1265_385;
		      arg1265_385 = CNST_TABLE_REF(((long) 5));
		      {
			 global_t obj_582;
			 obj_582 = (global_t) (g_379);
			 ((((global_t) CREF(obj_582))->import) = ((obj_t) arg1265_385), BUNSPEC);
		      }
		   }
		}
	      else
		{
		   BUNSPEC;
		}
	   }
      }
      {
	 global_t obj_584;
	 obj_584 = (global_t) (g_379);
	 return ((((global_t) CREF(obj_584))->occurrence) = ((long) ((long) 0)), BUNSPEC);
      }
   }
}


/* method-init */ obj_t 
method_init_76_heap_make()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_heap_make()
{
   module_initialization_70_tools_speek(((long) 0), "HEAP_MAKE");
   module_initialization_70_tools_error(((long) 0), "HEAP_MAKE");
   module_initialization_70_engine_pass(((long) 0), "HEAP_MAKE");
   module_initialization_70_engine_param(((long) 0), "HEAP_MAKE");
   module_initialization_70_type_type(((long) 0), "HEAP_MAKE");
   module_initialization_70_type_env(((long) 0), "HEAP_MAKE");
   module_initialization_70_ast_var(((long) 0), "HEAP_MAKE");
   module_initialization_70_ast_env(((long) 0), "HEAP_MAKE");
   return module_initialization_70_tools_shape(((long) 0), "HEAP_MAKE");
}
