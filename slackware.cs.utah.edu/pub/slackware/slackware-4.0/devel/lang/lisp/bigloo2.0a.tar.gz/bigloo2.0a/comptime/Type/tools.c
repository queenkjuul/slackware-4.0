/*===========================================================================*/
/*   (Type/tools.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_type_tools();
static obj_t ___name_1214_200_type_tools(obj_t, obj_t);
extern obj_t string_append(obj_t, obj_t);
extern obj_t string_sans___40_type_tools(obj_t);
extern obj_t make_typed_declaration_180_type_tools(type_t, obj_t);
static obj_t ___in_name_1213_82_type_tools(obj_t, obj_t);
extern obj_t type_name_sans___47_type_tools(type_t);
extern obj_t __in_name__215_type_tools(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t _make_pointer_to_name1217_101_type_tools(obj_t, obj_t);
static obj_t imported_modules_init_94_type_tools();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t _string_sans__1211_227_type_tools(obj_t, obj_t);
extern obj_t replace___96_type_tools(obj_t, obj_t);
static obj_t _make_typed_declaration1216_49_type_tools(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_type_tools();
extern obj_t __name__83_type_tools(obj_t);
extern obj_t make_string(long, unsigned char);
static obj_t _type_name_sans__1212_6_type_tools(obj_t, obj_t);
extern obj_t make_pointer_to_name_76_type_tools(type_t);
static obj_t _replace__1215_93_type_tools(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_type_tools = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(make_typed_declaration_env_154_type_tools, _make_typed_declaration1216_49_type_tools1222, _make_typed_declaration1216_49_type_tools, 0L, 2);
DEFINE_EXPORT_PROCEDURE(__name__env_245_type_tools, ___name_1214_200_type_tools1223, ___name_1214_200_type_tools, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_name_sans___env_61_type_tools, _type_name_sans__1212_6_type_tools1224, _type_name_sans__1212_6_type_tools, 0L, 1);
DEFINE_EXPORT_PROCEDURE(__in_name__env_167_type_tools, ___in_name_1213_82_type_tools1225, ___in_name_1213_82_type_tools, 0L, 1);
DEFINE_EXPORT_PROCEDURE(replace___env_158_type_tools, _replace__1215_93_type_tools1226, _replace__1215_93_type_tools, 0L, 2);
DEFINE_EXPORT_PROCEDURE(string_sans___env_170_type_tools, _string_sans__1211_227_type_tools1227, _string_sans__1211_227_type_tools, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_pointer_to_name_env_22_type_tools, _make_pointer_to_name1217_101_type_tools1228, _make_pointer_to_name1217_101_type_tools, 0L, 1);
DEFINE_STRING(string1219_type_tools, string1219_type_tools1229, "(*)", 3);
DEFINE_STRING(string1220_type_tools, string1220_type_tools1230, " *", 2);
DEFINE_STRING(string1218_type_tools, string1218_type_tools1231, " ", 1);


/* module-initialization */ obj_t 
module_initialization_70_type_tools(long checksum_230, char *from_231)
{
   if (CBOOL(require_initialization_114_type_tools))
     {
	require_initialization_114_type_tools = BBOOL(((bool_t) 0));
	library_modules_init_112_type_tools();
	imported_modules_init_94_type_tools();
	method_init_76_type_tools();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_type_tools()
{
   module_initialization_70___r4_strings_6_7(((long) 0), "TYPE_TOOLS");
   return BUNSPEC;
}


/* string-sans-$ */ obj_t 
string_sans___40_type_tools(obj_t string_1)
{
   {
      obj_t new_57;
      {
	 char *aux_239;
	 aux_239 = BSTRING_TO_STRING(string_1);
	 new_57 = string_to_bstring(aux_239);
      }
      {
	 long i_58;
	 {
	    long aux_253;
	    aux_253 = STRING_LENGTH(new_57);
	    i_58 = (aux_253 - ((long) 1));
	 }
       loop_59:
	 if ((i_58 == ((long) -1)))
	   {
	      return new_57;
	   }
	 else
	   {
	      bool_t test_244;
	      {
		 unsigned char aux_245;
		 aux_245 = STRING_REF(new_57, i_58);
		 test_244 = (aux_245 == ((unsigned char) '$'));
	      }
	      if (test_244)
		{
		   STRING_SET(new_57, i_58, ((unsigned char) ' '));
		   {
		      long i_249;
		      i_249 = (i_58 - ((long) 1));
		      i_58 = i_249;
		      goto loop_59;
		   }
		}
	      else
		{
		   {
		      long i_251;
		      i_251 = (i_58 - ((long) 1));
		      i_58 = i_251;
		      goto loop_59;
		   }
		}
	   }
      }
   }
}


/* _string-sans-$1211 */ obj_t 
_string_sans__1211_227_type_tools(obj_t env_214, obj_t string_215)
{
   return string_sans___40_type_tools(string_215);
}


/* type-name-sans-$ */ obj_t 
type_name_sans___47_type_tools(type_t type_2)
{
   {
      obj_t tname_68;
      tname_68 = (((type_t) CREF(type_2))->name);
      {
	 bool_t test_258;
	 {
	    obj_t aux_259;
	    aux_259 = (((type_t) CREF(type_2))->__57);
	    test_258 = CBOOL(aux_259);
	 }
	 if (test_258)
	   {
	      return string_sans___40_type_tools(tname_68);
	   }
	 else
	   {
	      return tname_68;
	   }
      }
   }
}


/* _type-name-sans-$1212 */ obj_t 
_type_name_sans__1212_6_type_tools(obj_t env_216, obj_t type_217)
{
   return type_name_sans___47_type_tools((type_t) (type_217));
}


/* $-in-name? */ obj_t 
__in_name__215_type_tools(obj_t name_3)
{
   {
      long i_70;
      {
	 bool_t aux_265;
	 {
	    long aux_274;
	    aux_274 = STRING_LENGTH(name_3);
	    i_70 = (aux_274 - ((long) 1));
	 }
       loop_71:
	 if ((i_70 == ((long) -1)))
	   {
	      aux_265 = ((bool_t) 0);
	   }
	 else
	   {
	      bool_t test_268;
	      {
		 unsigned char aux_269;
		 aux_269 = STRING_REF(name_3, i_70);
		 test_268 = (aux_269 == ((unsigned char) '$'));
	      }
	      if (test_268)
		{
		   aux_265 = ((bool_t) 1);
		}
	      else
		{
		   {
		      long i_272;
		      i_272 = (i_70 - ((long) 1));
		      i_70 = i_272;
		      goto loop_71;
		   }
		}
	   }
	 return BBOOL(aux_265);
      }
   }
}


/* _$-in-name?1213 */ obj_t 
___in_name_1213_82_type_tools(obj_t env_218, obj_t name_219)
{
   return __in_name__215_type_tools(name_219);
}


/* *-name? */ obj_t 
__name__83_type_tools(obj_t name_4)
{
   {
      bool_t aux_279;
      {
	 unsigned char aux_280;
	 {
	    long aux_281;
	    {
	       long aux_282;
	       aux_282 = STRING_LENGTH(name_4);
	       aux_281 = (aux_282 - ((long) 1));
	    }
	    aux_280 = STRING_REF(name_4, aux_281);
	 }
	 aux_279 = (aux_280 == ((unsigned char) '*'));
      }
      return BBOOL(aux_279);
   }
}


/* _*-name?1214 */ obj_t 
___name_1214_200_type_tools(obj_t env_220, obj_t name_221)
{
   return __name__83_type_tools(name_221);
}


/* replace-$ */ obj_t 
replace___96_type_tools(obj_t string_5, obj_t rplac_6)
{
   {
      long len_string_99_83;
      len_string_99_83 = STRING_LENGTH(string_5);
      {
	 long len_rplac_81_84;
	 len_rplac_81_84 = STRING_LENGTH(rplac_6);
	 {
	    obj_t new_86;
	    {
	       obj_t res1210_181;
	       {
		  long aux_291;
		  {
		     int aux_292;
		     {
			long aux_293;
			{
			   long aux_294;
			   aux_294 = (len_string_99_83 + len_rplac_81_84);
			   aux_293 = (aux_294 - ((long) 1));
			}
			aux_292 = (int) (aux_293);
		     }
		     aux_291 = (long) (aux_292);
		  }
		  res1210_181 = make_string(aux_291, ((unsigned char) ' '));
	       }
	       new_86 = res1210_181;
	    }
	    {
	       {
		  long r_87;
		  long w_88;
		  r_87 = ((long) 0);
		  w_88 = ((long) 0);
		loop_89:
		  if ((r_87 == len_string_99_83))
		    {
		       return new_86;
		    }
		  else
		    {
		       bool_t test_302;
		       {
			  unsigned char aux_303;
			  aux_303 = STRING_REF(string_5, r_87);
			  test_302 = (aux_303 == ((unsigned char) '$'));
		       }
		       if (test_302)
			 {
			    {
			       long w_92;
			       long rr_93;
			       w_92 = w_88;
			       rr_93 = ((long) 0);
			     liip_94:
			       if ((rr_93 == len_rplac_81_84))
				 {
				    long w_310;
				    long r_308;
				    r_308 = (r_87 + ((long) 1));
				    w_310 = w_92;
				    w_88 = w_310;
				    r_87 = r_308;
				    goto loop_89;
				 }
			       else
				 {
				    {
				       unsigned char aux_311;
				       aux_311 = STRING_REF(rplac_6, rr_93);
				       STRING_SET(new_86, w_92, aux_311);
				    }
				    {
				       long rr_316;
				       long w_314;
				       w_314 = (w_92 + ((long) 1));
				       rr_316 = (rr_93 + ((long) 1));
				       rr_93 = rr_316;
				       w_92 = w_314;
				       goto liip_94;
				    }
				 }
			    }
			 }
		       else
			 {
			    {
			       unsigned char aux_318;
			       aux_318 = STRING_REF(string_5, r_87);
			       STRING_SET(new_86, w_88, aux_318);
			    }
			    {
			       long w_323;
			       long r_321;
			       r_321 = (r_87 + ((long) 1));
			       w_323 = (w_88 + ((long) 1));
			       w_88 = w_323;
			       r_87 = r_321;
			       goto loop_89;
			    }
			 }
		    }
	       }
	    }
	 }
      }
   }
}


/* _replace-$1215 */ obj_t 
_replace__1215_93_type_tools(obj_t env_222, obj_t string_223, obj_t rplac_224)
{
   return replace___96_type_tools(string_223, rplac_224);
}


/* make-typed-declaration */ obj_t 
make_typed_declaration_180_type_tools(type_t type_7, obj_t id_8)
{
   {
      obj_t tname_107;
      tname_107 = (((type_t) CREF(type_7))->name);
      {
	 bool_t test_327;
	 {
	    obj_t aux_328;
	    aux_328 = (((type_t) CREF(type_7))->__57);
	    test_327 = CBOOL(aux_328);
	 }
	 if (test_327)
	   {
	      return replace___96_type_tools(tname_107, id_8);
	   }
	 else
	   {
	      {
		 obj_t list1201_109;
		 {
		    obj_t arg1202_110;
		    {
		       obj_t arg1204_112;
		       arg1204_112 = MAKE_PAIR(id_8, BNIL);
		       arg1202_110 = MAKE_PAIR(string1218_type_tools, arg1204_112);
		    }
		    list1201_109 = MAKE_PAIR(tname_107, arg1202_110);
		 }
		 return string_append_106___r4_strings_6_7(list1201_109);
	      }
	   }
      }
   }
}


/* _make-typed-declaration1216 */ obj_t 
_make_typed_declaration1216_49_type_tools(obj_t env_225, obj_t type_226, obj_t id_227)
{
   return make_typed_declaration_180_type_tools((type_t) (type_226), id_227);
}


/* make-pointer-to-name */ obj_t 
make_pointer_to_name_76_type_tools(type_t type_9)
{
   {
      obj_t tname_114;
      tname_114 = (((type_t) CREF(type_9))->name);
      {
	 bool_t test_339;
	 {
	    obj_t aux_340;
	    aux_340 = (((type_t) CREF(type_9))->__57);
	    test_339 = CBOOL(aux_340);
	 }
	 if (test_339)
	   {
	      return replace___96_type_tools(tname_114, string1219_type_tools);
	   }
	 else
	   {
	      return string_append(tname_114, string1220_type_tools);
	   }
      }
   }
}


/* _make-pointer-to-name1217 */ obj_t 
_make_pointer_to_name1217_101_type_tools(obj_t env_228, obj_t type_229)
{
   return make_pointer_to_name_76_type_tools((type_t) (type_229));
}


/* method-init */ obj_t 
method_init_76_type_tools()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_type_tools()
{
   return module_initialization_70_type_type(((long) 0), "TYPE_TOOLS");
}
