/*===========================================================================*/
/*   (Object/plain-access.scm)                                               */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t append___r4_pairs_and_lists_6_3(obj_t);
static obj_t method_init_76_object_plain_access_186();
extern obj_t type_type_type;
extern obj_t make_class_makes__132_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static bool_t correct_plain_class__49_object_plain_access_186(type_t, obj_t);
extern obj_t make_struct__object_35_object_struct(obj_t, type_t, obj_t, obj_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t make_class_pred__174_object_access(obj_t, class_t, obj_t, obj_t);
extern obj_t make_class_slots_205_object_slots(obj_t, obj_t, obj_t);
extern obj_t make_class_coercers_236_object_access(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_object_plain_access_186(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_object_struct(long, char *);
extern obj_t module_initialization_70_object_slots(long, char *);
extern obj_t module_initialization_70_object_tools(long, char *);
extern obj_t module_initialization_70_object_access(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_impuse(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern bool_t wide_class__100_object_class(obj_t);
static obj_t _make_plain_class_accessors__116_object_plain_access_186(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_class_slots_access__80_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_object_plain_access_186();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t make_coercion_clause_209_object_access(obj_t, obj_t);
static obj_t _import_plain_class_accessors__22_object_plain_access_186(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_object__struct_189_object_struct(obj_t, type_t, obj_t, obj_t, obj_t);
extern obj_t produce_module_clause__172_module_module(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_object_plain_access_186();
extern obj_t import_class_slots_access__39_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_object_plain_access_186();
extern obj_t open_input_string(obj_t);
extern obj_t import_class_pred__91_object_access(obj_t, class_t, obj_t, obj_t);
extern obj_t class_object_class;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t make_plain_class_accessors__206_object_plain_access_186(obj_t, type_t, obj_t, obj_t);
extern obj_t import_plain_class_accessors__109_object_plain_access_186(obj_t, type_t, obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _module__166_module_module;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t import_class_makes__192_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_class_allocate__44_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_object_plain_access_186 = BUNSPEC;
extern bool_t final_class__126_object_class(obj_t);
static obj_t cnst_init_137_object_plain_access_186();
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(make_plain_class_accessors__env_227_object_plain_access_186, _make_plain_class_accessors__116_object_plain_access_1861393, _make_plain_class_accessors__116_object_plain_access_186, 0L, 4);
DEFINE_EXPORT_PROCEDURE(import_plain_class_accessors__env_45_object_plain_access_186, _import_plain_class_accessors__22_object_plain_access_1861394, _import_plain_class_accessors__22_object_plain_access_186, 0L, 4);
DEFINE_STRING(string1387_object_plain_access_186, string1387_object_plain_access_1861395, "MAKE FOREIGN STATIC (EXPORT STATIC) ", 36);
DEFINE_STRING(string1386_object_plain_access_186, string1386_object_plain_access_1861396, "Only wide classes can inherit of final classes", 46);
DEFINE_STRING(string1385_object_plain_access_186, string1385_object_plain_access_1861397, "' is a wide class", 17);
DEFINE_STRING(string1384_object_plain_access_186, string1384_object_plain_access_1861398, "Should not be able to see a wide class here", 43);
DEFINE_STRING(string1383_object_plain_access_186, string1383_object_plain_access_1861399, "make-class-accesses!", 20);
DEFINE_STRING(string1382_object_plain_access_186, string1382_object_plain_access_1861400, "super of `", 10);
DEFINE_STRING(string1381_object_plain_access_186, string1381_object_plain_access_1861401, "' is not a class", 16);


/* module-initialization */ obj_t 
module_initialization_70_object_plain_access_186(long checksum_846, char *from_847)
{
   if (CBOOL(require_initialization_114_object_plain_access_186))
     {
	require_initialization_114_object_plain_access_186 = BBOOL(((bool_t) 0));
	library_modules_init_112_object_plain_access_186();
	cnst_init_137_object_plain_access_186();
	imported_modules_init_94_object_plain_access_186();
	method_init_76_object_plain_access_186();
	toplevel_init_63_object_plain_access_186();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_plain_access_186()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70___object(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70___r4_strings_6_7(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70___reader(((long) 0), "OBJECT_PLAIN-ACCESS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_plain_access_186()
{
   {
      obj_t cnst_port_138_838;
      cnst_port_138_838 = open_input_string(string1387_object_plain_access_186);
      {
	 long i_839;
	 i_839 = ((long) 3);
       loop_840:
	 {
	    bool_t test1388_841;
	    test1388_841 = (i_839 == ((long) -1));
	    if (test1388_841)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1389_842;
		    {
		       obj_t list1390_843;
		       {
			  obj_t arg1391_844;
			  arg1391_844 = BNIL;
			  list1390_843 = MAKE_PAIR(cnst_port_138_838, arg1391_844);
		       }
		       arg1389_842 = read___reader(list1390_843);
		    }
		    CNST_TABLE_SET(i_839, arg1389_842);
		 }
		 {
		    int aux_845;
		    {
		       long aux_866;
		       aux_866 = (i_839 - ((long) 1));
		       aux_845 = (int) (aux_866);
		    }
		    {
		       long i_869;
		       i_869 = (long) (aux_845);
		       i_839 = i_869;
		       goto loop_840;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_object_plain_access_186()
{
   return BUNSPEC;
}


/* make-plain-class-accessors! */ obj_t 
make_plain_class_accessors__206_object_plain_access_186(obj_t class_def_12_63, type_t class_64, obj_t src_def_101_65, obj_t import_66)
{
   {
      bool_t test1237_475;
      test1237_475 = correct_plain_class__49_object_plain_access_186(class_64, src_def_101_65);
      if (test1237_475)
	{
	   obj_t super_476;
	   {
	      class_t obj_766;
	      obj_766 = (class_t) (class_64);
	      {
		 obj_t aux_874;
		 {
		    object_t aux_875;
		    aux_875 = (object_t) (obj_766);
		    aux_874 = OBJECT_WIDENING(aux_875);
		 }
		 super_476 = (((class_t) CREF(aux_874))->its_super_214);
	      }
	   }
	   {
	      obj_t domestic__170_477;
	      domestic__170_477 = memq___r4_pairs_and_lists_6_3(import_66, CNST_TABLE_REF(((long) 0)));
	      {
		 obj_t cslots_479;
		 {
		    obj_t aux_885;
		    obj_t aux_881;
		    {
		       bool_t test_886;
		       {
			  obj_t aux_887;
			  aux_887 = (obj_t) (class_64);
			  test_886 = (super_476 == aux_887);
		       }
		       if (test_886)
			 {
			    aux_885 = BFALSE;
			 }
		       else
			 {
			    aux_885 = super_476;
			 }
		    }
		    {
		       obj_t aux_882;
		       aux_882 = CDR(class_def_12_63);
		       aux_881 = CDR(aux_882);
		    }
		    cslots_479 = make_class_slots_205_object_slots(aux_881, aux_885, src_def_101_65);
		 }
		 {
		    obj_t class_id_86_480;
		    class_id_86_480 = (((type_t) CREF(class_64))->id);
		    {
		       global_t holder_482;
		       {
			  class_t obj_775;
			  obj_775 = (class_t) (class_64);
			  {
			     obj_t aux_893;
			     {
				object_t aux_894;
				aux_894 = (object_t) (obj_775);
				aux_893 = OBJECT_WIDENING(aux_894);
			     }
			     holder_482 = (((class_t) CREF(aux_893))->holder);
			  }
		       }
		       {
			  obj_t import_483;
			  if (CBOOL(domestic__170_477))
			    {
			       import_483 = import_66;
			    }
			  else
			    {
			       import_483 = CNST_TABLE_REF(((long) 1));
			    }
			  {
			     {
				obj_t arg1238_484;
				arg1238_484 = make_coercion_clause_209_object_access(class_id_86_480, super_476);
				produce_module_clause__172_module_module(arg1238_484);
			     }
			     {
				class_t obj_776;
				obj_776 = (class_t) (class_64);
				{
				   obj_t aux_904;
				   {
				      object_t aux_905;
				      aux_905 = (object_t) (obj_776);
				      aux_904 = OBJECT_WIDENING(aux_905);
				   }
				   ((((class_t) CREF(aux_904))->slots) = ((obj_t) cslots_479), BUNSPEC);
				}
			     }
			     {
				obj_t arg1240_485;
				{
				   obj_t arg1241_486;
				   obj_t arg1243_487;
				   arg1241_486 = CNST_TABLE_REF(((long) 2));
				   {
				      obj_t arg1247_490;
				      obj_t arg1248_491;
				      arg1247_490 = make_class_coercers_236_object_access((obj_t) (class_64));
				      arg1248_491 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1243_487 = append_2_18___r4_pairs_and_lists_6_3(arg1247_490, arg1248_491);
				   }
				   {
				      obj_t list1244_488;
				      list1244_488 = MAKE_PAIR(arg1243_487, BNIL);
				      arg1240_485 = cons__138___r4_pairs_and_lists_6_3(arg1241_486, list1244_488);
				   }
				}
				produce_module_clause__172_module_module(arg1240_485);
			     }
			     {
				obj_t accs_494;
				{
				   obj_t arg1262_504;
				   obj_t arg1263_505;
				   obj_t arg1265_506;
				   arg1262_504 = make_class_pred__174_object_access(class_id_86_480, (class_t) (class_64), src_def_101_65, import_483);
				   arg1263_505 = make_class_makes__132_object_access(CNST_TABLE_REF(((long) 3)), CNST_TABLE_REF(((long) 3)), class_id_86_480, (obj_t) (class_64), cslots_479, src_def_101_65, import_483);
				   arg1265_506 = make_class_slots_access__80_object_access(class_id_86_480, (obj_t) (class_64), cslots_479, BFALSE, src_def_101_65, import_483);
				   {
				      obj_t list1266_507;
				      {
					 obj_t arg1267_508;
					 {
					    obj_t arg1268_509;
					    arg1268_509 = MAKE_PAIR(arg1265_506, BNIL);
					    arg1267_508 = MAKE_PAIR(arg1263_505, arg1268_509);
					 }
					 list1266_507 = MAKE_PAIR(arg1262_504, arg1267_508);
				      }
				      accs_494 = append___r4_pairs_and_lists_6_3(list1266_507);
				   }
				}
				{
				   obj_t arg1252_495;
				   obj_t arg1253_496;
				   arg1252_495 = make_class_allocate__44_object_access(class_id_86_480, (obj_t) (class_64), (obj_t) (holder_482), src_def_101_65, import_483);
				   {
				      bool_t test1254_497;
				      {
					 obj_t aux_932;
					 {
					    class_t obj_778;
					    obj_778 = (class_t) (class_64);
					    {
					       obj_t aux_934;
					       {
						  object_t aux_935;
						  aux_935 = (object_t) (obj_778);
						  aux_934 = OBJECT_WIDENING(aux_935);
					       }
					       aux_932 = (((class_t) CREF(aux_934))->its_super_214);
					    }
					 }
					 test1254_497 = is_a__118___object(aux_932, type_type_type);
				      }
				      if (test1254_497)
					{
					   if (CBOOL(domestic__170_477))
					     {
						obj_t arg1255_498;
						obj_t arg1256_499;
						arg1255_498 = make_object__struct_189_object_struct(class_id_86_480, class_64, _module__166_module_module, cslots_479, src_def_101_65);
						arg1256_499 = make_struct__object_35_object_struct(class_id_86_480, class_64, _module__166_module_module, cslots_479, src_def_101_65);
						{
						   obj_t list1257_500;
						   {
						      obj_t arg1258_501;
						      arg1258_501 = MAKE_PAIR(accs_494, BNIL);
						      list1257_500 = MAKE_PAIR(arg1256_499, arg1258_501);
						   }
						   arg1253_496 = cons__138___r4_pairs_and_lists_6_3(arg1255_498, list1257_500);
						}
					     }
					   else
					     {
						arg1253_496 = accs_494;
					     }
					}
				      else
					{
					   arg1253_496 = accs_494;
					}
				   }
				   return MAKE_PAIR(arg1252_495, arg1253_496);
				}
			     }
			  }
		       }
		    }
		 }
	      }
	   }
	}
      else
	{
	   return BNIL;
	}
   }
}


/* _make-plain-class-accessors! */ obj_t 
_make_plain_class_accessors__116_object_plain_access_186(obj_t env_827, obj_t class_def_12_828, obj_t class_829, obj_t src_def_101_830, obj_t import_831)
{
   return make_plain_class_accessors__206_object_plain_access_186(class_def_12_828, (type_t) (class_829), src_def_101_830, import_831);
}


/* import-plain-class-accessors! */ obj_t 
import_plain_class_accessors__109_object_plain_access_186(obj_t class_def_12_67, type_t class_68, obj_t src_def_101_69, obj_t module_70)
{
   {
      bool_t test1278_516;
      test1278_516 = correct_plain_class__49_object_plain_access_186(class_68, src_def_101_69);
      if (test1278_516)
	{
	   obj_t super_517;
	   {
	      class_t obj_782;
	      obj_782 = (class_t) (class_68);
	      {
		 obj_t aux_954;
		 {
		    object_t aux_955;
		    aux_955 = (object_t) (obj_782);
		    aux_954 = OBJECT_WIDENING(aux_955);
		 }
		 super_517 = (((class_t) CREF(aux_954))->its_super_214);
	      }
	   }
	   {
	      obj_t cslots_519;
	      {
		 obj_t aux_963;
		 obj_t aux_959;
		 {
		    bool_t test_964;
		    {
		       obj_t aux_965;
		       aux_965 = (obj_t) (class_68);
		       test_964 = (super_517 == aux_965);
		    }
		    if (test_964)
		      {
			 aux_963 = BFALSE;
		      }
		    else
		      {
			 aux_963 = super_517;
		      }
		 }
		 {
		    obj_t aux_960;
		    aux_960 = CDR(class_def_12_67);
		    aux_959 = CDR(aux_960);
		 }
		 cslots_519 = make_class_slots_205_object_slots(aux_959, aux_963, src_def_101_69);
	      }
	      {
		 obj_t class_id_86_520;
		 class_id_86_520 = (((type_t) CREF(class_68))->id);
		 {
		    {
		       obj_t arg1281_523;
		       arg1281_523 = make_coercion_clause_209_object_access(class_id_86_520, super_517);
		       produce_module_clause__172_module_module(arg1281_523);
		    }
		    {
		       class_t obj_792;
		       obj_792 = (class_t) (class_68);
		       {
			  obj_t aux_973;
			  {
			     object_t aux_974;
			     aux_974 = (object_t) (obj_792);
			     aux_973 = OBJECT_WIDENING(aux_974);
			  }
			  ((((class_t) CREF(aux_973))->slots) = ((obj_t) cslots_519), BUNSPEC);
		       }
		    }
		    {
		       obj_t arg1282_524;
		       {
			  obj_t arg1283_525;
			  obj_t arg1284_526;
			  arg1283_525 = CNST_TABLE_REF(((long) 2));
			  {
			     obj_t arg1287_529;
			     obj_t arg1288_530;
			     arg1287_529 = make_class_coercers_236_object_access((obj_t) (class_68));
			     arg1288_530 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
			     arg1284_526 = append_2_18___r4_pairs_and_lists_6_3(arg1287_529, arg1288_530);
			  }
			  {
			     obj_t list1285_527;
			     list1285_527 = MAKE_PAIR(arg1284_526, BNIL);
			     arg1282_524 = cons__138___r4_pairs_and_lists_6_3(arg1283_525, list1285_527);
			  }
		       }
		       produce_module_clause__172_module_module(arg1282_524);
		    }
		    import_class_pred__91_object_access(class_id_86_520, (class_t) (class_68), src_def_101_69, module_70);
		    import_class_makes__192_object_access(CNST_TABLE_REF(((long) 3)), class_id_86_520, (obj_t) (class_68), cslots_519, src_def_101_69, module_70);
		    import_class_slots_access__39_object_access(class_id_86_520, (obj_t) (class_68), cslots_519, src_def_101_69, module_70);
		 }
	      }
	   }
	}
      else
	{
	   BUNSPEC;
	}
   }
   return BNIL;
}


/* _import-plain-class-accessors! */ obj_t 
_import_plain_class_accessors__22_object_plain_access_186(obj_t env_832, obj_t class_def_12_833, obj_t class_834, obj_t src_def_101_835, obj_t module_836)
{
   return import_plain_class_accessors__109_object_plain_access_186(class_def_12_833, (type_t) (class_834), src_def_101_835, module_836);
}


/* correct-plain-class? */ bool_t 
correct_plain_class__49_object_plain_access_186(type_t class_71, obj_t src_def_101_72)
{
   {
      obj_t super_536;
      obj_t class_id_86_537;
      {
	 class_t obj_794;
	 obj_794 = (class_t) (class_71);
	 {
	    obj_t aux_996;
	    {
	       object_t aux_997;
	       aux_997 = (object_t) (obj_794);
	       aux_996 = OBJECT_WIDENING(aux_997);
	    }
	    super_536 = (((class_t) CREF(aux_996))->its_super_214);
	 }
      }
      class_id_86_537 = (((type_t) CREF(class_71))->id);
      {
	 bool_t test1296_538;
	 {
	    bool_t test1334_568;
	    test1334_568 = is_a__118___object(super_536, type_type_type);
	    if (test1334_568)
	      {
		 bool_t test1335_569;
		 test1335_569 = is_a__118___object(super_536, class_object_class);
		 if (test1335_569)
		   {
		      test1296_538 = ((bool_t) 0);
		   }
		 else
		   {
		      test1296_538 = ((bool_t) 1);
		   }
	      }
	    else
	      {
		 test1296_538 = ((bool_t) 0);
	      }
	 }
	 if (test1296_538)
	   {
	      {
		 obj_t arg1297_539;
		 obj_t arg1298_540;
		 {
		    type_t obj_798;
		    obj_798 = (type_t) (super_536);
		    arg1297_539 = (((type_t) CREF(obj_798))->id);
		 }
		 {
		    obj_t arg1302_544;
		    arg1302_544 = SYMBOL_TO_STRING(class_id_86_537);
		    {
		       obj_t list1304_546;
		       {
			  obj_t arg1307_547;
			  {
			     obj_t arg1308_548;
			     arg1308_548 = MAKE_PAIR(string1381_object_plain_access_186, BNIL);
			     arg1307_547 = MAKE_PAIR(arg1302_544, arg1308_548);
			  }
			  list1304_546 = MAKE_PAIR(string1382_object_plain_access_186, arg1307_547);
		       }
		       arg1298_540 = string_append_106___r4_strings_6_7(list1304_546);
		    }
		 }
		 {
		    obj_t list1299_541;
		    list1299_541 = MAKE_PAIR(type_type_type, BNIL);
		    user_error_151_tools_error(arg1297_539, arg1298_540, src_def_101_72, list1299_541);
		 }
	      }
	      return ((bool_t) 0);
	   }
	 else
	   {
	      bool_t test1310_550;
	      test1310_550 = wide_class__100_object_class((obj_t) (class_71));
	      if (test1310_550)
		{
		   internal_error_43_tools_error(string1383_object_plain_access_186, string1384_object_plain_access_186, src_def_101_72);
		   return ((bool_t) 0);
		}
	      else
		{
		   bool_t test1311_551;
		   test1311_551 = wide_class__100_object_class(super_536);
		   if (test1311_551)
		     {
			{
			   obj_t arg1313_552;
			   obj_t arg1315_553;
			   {
			      type_t obj_800;
			      obj_800 = (type_t) (super_536);
			      arg1313_552 = (((type_t) CREF(obj_800))->id);
			   }
			   {
			      obj_t arg1322_557;
			      arg1322_557 = SYMBOL_TO_STRING(class_id_86_537);
			      {
				 obj_t list1324_559;
				 {
				    obj_t arg1325_560;
				    {
				       obj_t arg1326_561;
				       arg1326_561 = MAKE_PAIR(string1385_object_plain_access_186, BNIL);
				       arg1325_560 = MAKE_PAIR(arg1322_557, arg1326_561);
				    }
				    list1324_559 = MAKE_PAIR(string1382_object_plain_access_186, arg1325_560);
				 }
				 arg1315_553 = string_append_106___r4_strings_6_7(list1324_559);
			      }
			   }
			   {
			      obj_t list1316_554;
			      list1316_554 = MAKE_PAIR(type_type_type, BNIL);
			      user_error_151_tools_error(arg1313_552, arg1315_553, src_def_101_72, list1316_554);
			   }
			}
			return ((bool_t) 0);
		     }
		   else
		     {
			bool_t test1329_563;
			test1329_563 = final_class__126_object_class(super_536);
			if (test1329_563)
			  {
			     {
				obj_t arg1330_564;
				{
				   type_t obj_802;
				   obj_802 = (type_t) (super_536);
				   arg1330_564 = (((type_t) CREF(obj_802))->id);
				}
				{
				   obj_t list1332_566;
				   list1332_566 = MAKE_PAIR(type_type_type, BNIL);
				   user_error_151_tools_error(arg1330_564, string1386_object_plain_access_186, src_def_101_72, list1332_566);
				}
			     }
			     return ((bool_t) 0);
			  }
			else
			  {
			     return ((bool_t) 1);
			  }
		     }
		}
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_object_plain_access_186()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_plain_access_186()
{
   module_initialization_70_tools_trace(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_tools_error(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_tools_misc(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_type_type(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_type_env(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_type_tools(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_type_cache(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_ast_var(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_ast_ident(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_object_class(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_object_struct(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_object_slots(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_object_tools(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_object_access(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_module_module(((long) 0), "OBJECT_PLAIN-ACCESS");
   module_initialization_70_module_impuse(((long) 0), "OBJECT_PLAIN-ACCESS");
   return module_initialization_70_engine_param(((long) 0), "OBJECT_PLAIN-ACCESS");
}
