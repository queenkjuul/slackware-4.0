/*===========================================================================*/
/*   (Rgc/rgc.scm)                                                           */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _rgc_match_fail1170_121___rgc(obj_t, obj_t);
static obj_t _rgc_buffer_flonum1165_193___rgc(obj_t, obj_t);
static obj_t _rgc_the_submatch_165___rgc(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern long rgc_buffer_fixnum(obj_t);
static obj_t _rgc_fill_buffer_if_empty_96___rgc(obj_t, obj_t);
extern obj_t rgc_buffer_substring(obj_t, int, int);
static obj_t _rgc_buffer_symbol1166_59___rgc(obj_t, obj_t);
static obj_t _rgc_stop_match_1173_178___rgc(obj_t, obj_t);
static obj_t _rgc_buffer_length1163_14___rgc(obj_t, obj_t);
static obj_t _rgc_buffer_keyword1167_21___rgc(obj_t, obj_t);
static obj_t symbol1182___rgc = BUNSPEC;
static obj_t symbol1181___rgc = BUNSPEC;
static obj_t symbol1180___rgc = BUNSPEC;
extern obj_t make_real(double);
extern obj_t rgc_buffer_keyword_150___rgc(obj_t);
extern long rgc_buffer_fixnum_121___rgc(obj_t);
static obj_t _rgc_failing_char1171_169___rgc(obj_t, obj_t);
extern bool_t rgc_buffer_eol_p(obj_t);
static obj_t _rgc_buffer_get_char1160_213___rgc(obj_t, obj_t);
extern bool_t rgc_buffer_eof_p(obj_t);
extern obj_t rgc_buffer_keyword(obj_t);
static obj_t _rgc_matchstop1169_184___rgc(obj_t, obj_t);
extern obj_t rgc_the_submatch_107___rgc(obj_t, int, int, int);
extern bool_t rgc_buffer_bol_p(obj_t);
extern obj_t _res1__155___r5_control_features_6_4;
extern bool_t rgc_buffer_bof_p(obj_t);
extern bool_t rgc_fill_buffer(obj_t);
static obj_t _rgc_buffer_eof_1179_124___rgc(obj_t, obj_t);
static obj_t _rgc_buffer_eol_1177_203___rgc(obj_t, obj_t);
static obj_t _rgc_buffer_empty_1174_119___rgc(obj_t, obj_t);
extern obj_t rgc_buffer_symbol(obj_t);
extern bool_t rgc_fill_buffer_if_empty_97___rgc(obj_t);
extern int rgc_buffer_unget_char_93___rgc(obj_t, int);
extern int rgc_start_match__23___rgc(obj_t);
extern obj_t rgc_buffer_symbol_254___rgc(obj_t);
extern int rgc_buffer_get_char_122___rgc(obj_t);
extern int rgc_match_fail_97___rgc(obj_t);
extern obj_t module_initialization_70___rgc(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t _res_number__75___r5_control_features_6_4;
static obj_t _rgc_buffer_substring1162_173___rgc(obj_t, obj_t, obj_t, obj_t);
static obj_t _rgc_buffer_bof_1178_21___rgc(obj_t, obj_t);
static obj_t _rgc_buffer_bol_1176_177___rgc(obj_t, obj_t);
extern obj_t rgc_buffer_substring_161___rgc(obj_t, int, int);
extern double rgc_buffer_flonum(obj_t);
extern long rgc_buffer_position_28___rgc(obj_t);
extern int rgc_buffer_unget_char(obj_t, int);
extern int rgc_failing_char_45___rgc(obj_t);
static obj_t _rgc_buffer_position1168_112___rgc(obj_t, obj_t);
extern double rgc_buffer_flonum_43___rgc(obj_t);
extern bool_t rgc_buffer_eol__219___rgc(obj_t);
extern bool_t rgc_buffer_empty__127___rgc(obj_t);
extern bool_t rgc_buffer_eof__127___rgc(obj_t);
static obj_t _rgc_fill_buffer1175_148___rgc(obj_t, obj_t);
static obj_t _rgc_buffer_fixnum1164_255___rgc(obj_t, obj_t);
extern long rgc_buffer_length_14___rgc(obj_t);
extern bool_t rgc_buffer_bol__129___rgc(obj_t);
extern bool_t rgc_buffer_bof__103___rgc(obj_t);
static obj_t imported_modules_init_94___rgc();
static obj_t _rgc_buffer_unget_char1161_204___rgc(obj_t, obj_t, obj_t);
static obj_t _rgc_start_match_1172_119___rgc(obj_t, obj_t);
extern bool_t rgc_fill_buffer_151___rgc(obj_t);
static obj_t require_initialization_114___rgc = BUNSPEC;
extern long rgc_matchstop_124___rgc(obj_t);
extern int rgc_stop_match__158___rgc(obj_t);
static obj_t cnst_init_137___rgc();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( rgc_buffer_fixnum_env_100___rgc, _rgc_buffer_fixnum1164_255___rgc1184, _rgc_buffer_fixnum1164_255___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_position_env_131___rgc, _rgc_buffer_position1168_112___rgc1185, _rgc_buffer_position1168_112___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_stop_match__env_48___rgc, _rgc_stop_match_1173_178___rgc1186, _rgc_stop_match_1173_178___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_failing_char_env_125___rgc, _rgc_failing_char1171_169___rgc1187, _rgc_failing_char1171_169___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_flonum_env_37___rgc, _rgc_buffer_flonum1165_193___rgc1188, _rgc_buffer_flonum1165_193___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_eof__env_254___rgc, _rgc_buffer_eof_1179_124___rgc1189, _rgc_buffer_eof_1179_124___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_eol__env_11___rgc, _rgc_buffer_eol_1177_203___rgc1190, _rgc_buffer_eol_1177_203___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_unget_char_env_209___rgc, _rgc_buffer_unget_char1161_204___rgc1191, _rgc_buffer_unget_char1161_204___rgc, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_symbol_env_85___rgc, _rgc_buffer_symbol1166_59___rgc1192, _rgc_buffer_symbol1166_59___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_length_env_225___rgc, _rgc_buffer_length1163_14___rgc1193, _rgc_buffer_length1163_14___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_substring_env_53___rgc, _rgc_buffer_substring1162_173___rgc1194, _rgc_buffer_substring1162_173___rgc, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( rgc_match_fail_env_247___rgc, _rgc_match_fail1170_121___rgc1195, _rgc_match_fail1170_121___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_bof__env_21___rgc, _rgc_buffer_bof_1178_21___rgc1196, _rgc_buffer_bof_1178_21___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_keyword_env_9___rgc, _rgc_buffer_keyword1167_21___rgc1197, _rgc_buffer_keyword1167_21___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_bol__env_10___rgc, _rgc_buffer_bol_1176_177___rgc1198, _rgc_buffer_bol_1176_177___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_get_char_env_238___rgc, _rgc_buffer_get_char1160_213___rgc1199, _rgc_buffer_get_char1160_213___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_buffer_empty__env_254___rgc, _rgc_buffer_empty_1174_119___rgc1200, _rgc_buffer_empty_1174_119___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_fill_buffer_if_empty_env_247___rgc, _rgc_fill_buffer_if_empty_96___rgc1201, _rgc_fill_buffer_if_empty_96___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_fill_buffer_env_101___rgc, _rgc_fill_buffer1175_148___rgc1202, _rgc_fill_buffer1175_148___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_matchstop_env_55___rgc, _rgc_matchstop1169_184___rgc1203, _rgc_matchstop1169_184___rgc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_the_submatch_env_23___rgc, _rgc_the_submatch_165___rgc1204, _rgc_the_submatch_165___rgc, 0L, 4 );
DEFINE_EXPORT_PROCEDURE( rgc_start_match__env_241___rgc, _rgc_start_match_1172_119___rgc1205, _rgc_start_match_1172_119___rgc, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___rgc(long checksum_618, char * from_619)
{
if(CBOOL(require_initialization_114___rgc)){
require_initialization_114___rgc = BBOOL(((bool_t)0));
cnst_init_137___rgc();
imported_modules_init_94___rgc();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___rgc()
{
symbol1180___rgc = string_to_symbol("STOP");
symbol1181___rgc = string_to_symbol("START");
return (symbol1182___rgc = string_to_symbol("START*"),
BUNSPEC);
}


/* rgc-buffer-get-char */int rgc_buffer_get_char_122___rgc(obj_t input_port_219_1)
{
return RGC_BUFFER_GET_CHAR(input_port_219_1);
}


/* _rgc-buffer-get-char1160 */obj_t _rgc_buffer_get_char1160_213___rgc(obj_t env_542, obj_t input_port_219_543)
{
{
int aux_629;
{
obj_t input_port_219_592;
input_port_219_592 = input_port_219_543;
aux_629 = RGC_BUFFER_GET_CHAR(input_port_219_592);
}
return BINT(aux_629);
}
}


/* rgc-buffer-unget-char */int rgc_buffer_unget_char_93___rgc(obj_t input_port_219_2, int char_3)
{
return rgc_buffer_unget_char(input_port_219_2, char_3);
}


/* _rgc-buffer-unget-char1161 */obj_t _rgc_buffer_unget_char1161_204___rgc(obj_t env_544, obj_t input_port_219_545, obj_t char_546)
{
{
int aux_633;
{
obj_t input_port_219_593;
int char_166_594;
input_port_219_593 = input_port_219_545;
char_166_594 = CINT(char_546);
aux_633 = rgc_buffer_unget_char(input_port_219_593, char_166_594);
}
return BINT(aux_633);
}
}


/* rgc-buffer-substring */obj_t rgc_buffer_substring_161___rgc(obj_t input_port_219_4, int start_5, int stop_6)
{
return rgc_buffer_substring(input_port_219_4, start_5, stop_6);
}


/* _rgc-buffer-substring1162 */obj_t _rgc_buffer_substring1162_173___rgc(obj_t env_547, obj_t input_port_219_548, obj_t start_549, obj_t stop_550)
{
{
obj_t input_port_219_595;
int start_596;
int stop_597;
input_port_219_595 = input_port_219_548;
start_596 = CINT(start_549);
stop_597 = CINT(stop_550);
return rgc_buffer_substring(input_port_219_595, start_596, stop_597);
}
}


/* rgc-buffer-length */long rgc_buffer_length_14___rgc(obj_t input_port_219_7)
{
return RGC_BUFFER_LENGTH(input_port_219_7);
}


/* _rgc-buffer-length1163 */obj_t _rgc_buffer_length1163_14___rgc(obj_t env_551, obj_t input_port_219_552)
{
{
long aux_642;
{
obj_t input_port_219_598;
input_port_219_598 = input_port_219_552;
aux_642 = RGC_BUFFER_LENGTH(input_port_219_598);
}
return BINT(aux_642);
}
}


/* rgc-buffer-fixnum */long rgc_buffer_fixnum_121___rgc(obj_t input_port_219_8)
{
return rgc_buffer_fixnum(input_port_219_8);
}


/* _rgc-buffer-fixnum1164 */obj_t _rgc_buffer_fixnum1164_255___rgc(obj_t env_553, obj_t input_port_219_554)
{
{
long aux_646;
{
obj_t input_port_219_599;
input_port_219_599 = input_port_219_554;
aux_646 = rgc_buffer_fixnum(input_port_219_599);
}
return BINT(aux_646);
}
}


/* rgc-buffer-flonum */double rgc_buffer_flonum_43___rgc(obj_t input_port_219_9)
{
return rgc_buffer_flonum(input_port_219_9);
}


/* _rgc-buffer-flonum1165 */obj_t _rgc_buffer_flonum1165_193___rgc(obj_t env_555, obj_t input_port_219_556)
{
{
double aux_650;
{
obj_t input_port_219_600;
input_port_219_600 = input_port_219_556;
aux_650 = rgc_buffer_flonum(input_port_219_600);
}
return make_real(aux_650);
}
}


/* rgc-buffer-symbol */obj_t rgc_buffer_symbol_254___rgc(obj_t input_port_219_10)
{
return rgc_buffer_symbol(input_port_219_10);
}


/* _rgc-buffer-symbol1166 */obj_t _rgc_buffer_symbol1166_59___rgc(obj_t env_557, obj_t input_port_219_558)
{
{
obj_t input_port_219_601;
input_port_219_601 = input_port_219_558;
return rgc_buffer_symbol(input_port_219_601);
}
}


/* rgc-buffer-keyword */obj_t rgc_buffer_keyword_150___rgc(obj_t input_port_219_11)
{
return rgc_buffer_keyword(input_port_219_11);
}


/* _rgc-buffer-keyword1167 */obj_t _rgc_buffer_keyword1167_21___rgc(obj_t env_559, obj_t input_port_219_560)
{
{
obj_t input_port_219_602;
input_port_219_602 = input_port_219_560;
return rgc_buffer_keyword(input_port_219_602);
}
}


/* rgc-buffer-position */long rgc_buffer_position_28___rgc(obj_t input_port_219_12)
{
return RGC_BUFFER_POSITION(input_port_219_12);
}


/* _rgc-buffer-position1168 */obj_t _rgc_buffer_position1168_112___rgc(obj_t env_561, obj_t input_port_219_562)
{
{
long aux_658;
{
obj_t input_port_219_603;
input_port_219_603 = input_port_219_562;
aux_658 = RGC_BUFFER_POSITION(input_port_219_603);
}
return BINT(aux_658);
}
}


/* rgc-matchstop */long rgc_matchstop_124___rgc(obj_t input_port_219_13)
{
return RGC_MATCHSTOP(input_port_219_13);
}


/* _rgc-matchstop1169 */obj_t _rgc_matchstop1169_184___rgc(obj_t env_563, obj_t input_port_219_564)
{
{
long aux_662;
{
obj_t input_port_219_604;
input_port_219_604 = input_port_219_564;
aux_662 = RGC_MATCHSTOP(input_port_219_604);
}
return BINT(aux_662);
}
}


/* rgc-match-fail */int rgc_match_fail_97___rgc(obj_t input_port_219_14)
{
return RGC_MATCH_FAIL(input_port_219_14);
}


/* _rgc-match-fail1170 */obj_t _rgc_match_fail1170_121___rgc(obj_t env_565, obj_t input_port_219_566)
{
{
int aux_666;
{
obj_t input_port_219_605;
input_port_219_605 = input_port_219_566;
aux_666 = RGC_MATCH_FAIL(input_port_219_605);
}
return BINT(aux_666);
}
}


/* rgc-failing-char */int rgc_failing_char_45___rgc(obj_t input_port_219_15)
{
return RGC_FAILING_CHAR(input_port_219_15);
}


/* _rgc-failing-char1171 */obj_t _rgc_failing_char1171_169___rgc(obj_t env_567, obj_t input_port_219_568)
{
{
int aux_670;
{
obj_t input_port_219_606;
input_port_219_606 = input_port_219_568;
aux_670 = RGC_FAILING_CHAR(input_port_219_606);
}
return BINT(aux_670);
}
}


/* rgc-start-match! */int rgc_start_match__23___rgc(obj_t input_port_219_16)
{
return RGC_START_MATCH(input_port_219_16);
}


/* _rgc-start-match!1172 */obj_t _rgc_start_match_1172_119___rgc(obj_t env_569, obj_t input_port_219_570)
{
{
int aux_674;
{
obj_t input_port_219_607;
input_port_219_607 = input_port_219_570;
aux_674 = RGC_START_MATCH(input_port_219_607);
}
return BINT(aux_674);
}
}


/* rgc-stop-match! */int rgc_stop_match__158___rgc(obj_t input_port_219_17)
{
return RGC_STOP_MATCH(input_port_219_17);
}


/* _rgc-stop-match!1173 */obj_t _rgc_stop_match_1173_178___rgc(obj_t env_571, obj_t input_port_219_572)
{
{
int aux_678;
{
obj_t input_port_219_608;
input_port_219_608 = input_port_219_572;
aux_678 = RGC_STOP_MATCH(input_port_219_608);
}
return BINT(aux_678);
}
}


/* rgc-buffer-empty? */bool_t rgc_buffer_empty__127___rgc(obj_t input_port_219_18)
{
return RGC_BUFFER_EMPTY(input_port_219_18);
}


/* _rgc-buffer-empty?1174 */obj_t _rgc_buffer_empty_1174_119___rgc(obj_t env_573, obj_t input_port_219_574)
{
{
bool_t aux_682;
{
obj_t input_port_219_609;
input_port_219_609 = input_port_219_574;
aux_682 = RGC_BUFFER_EMPTY(input_port_219_609);
}
return BBOOL(aux_682);
}
}


/* rgc-fill-buffer */bool_t rgc_fill_buffer_151___rgc(obj_t input_port_219_19)
{
return rgc_fill_buffer(input_port_219_19);
}


/* _rgc-fill-buffer1175 */obj_t _rgc_fill_buffer1175_148___rgc(obj_t env_575, obj_t input_port_219_576)
{
{
bool_t aux_686;
{
obj_t input_port_219_610;
input_port_219_610 = input_port_219_576;
aux_686 = rgc_fill_buffer(input_port_219_610);
}
return BBOOL(aux_686);
}
}


/* rgc-fill-buffer-if-empty */bool_t rgc_fill_buffer_if_empty_97___rgc(obj_t input_port_219_20)
{
{
bool_t _andtest_1002_611;
_andtest_1002_611 = RGC_BUFFER_EMPTY(input_port_219_20);
if(_andtest_1002_611){
return rgc_fill_buffer(input_port_219_20);
}
 else {
return ((bool_t)0);
}
}
}


/* _rgc-fill-buffer-if-empty */obj_t _rgc_fill_buffer_if_empty_96___rgc(obj_t env_577, obj_t input_port_219_578)
{
{
bool_t aux_692;
{
obj_t input_port_219_612;
input_port_219_612 = input_port_219_578;
{
bool_t _andtest_1002_613;
_andtest_1002_613 = RGC_BUFFER_EMPTY(input_port_219_612);
if(_andtest_1002_613){
aux_692 = rgc_fill_buffer(input_port_219_612);
}
 else {
aux_692 = ((bool_t)0);
}
}
}
return BBOOL(aux_692);
}
}


/* rgc-buffer-bol? */bool_t rgc_buffer_bol__129___rgc(obj_t input_port_219_21)
{
return rgc_buffer_bol_p(input_port_219_21);
}


/* _rgc-buffer-bol?1176 */obj_t _rgc_buffer_bol_1176_177___rgc(obj_t env_579, obj_t input_port_219_580)
{
{
bool_t aux_698;
{
obj_t input_port_219_614;
input_port_219_614 = input_port_219_580;
aux_698 = rgc_buffer_bol_p(input_port_219_614);
}
return BBOOL(aux_698);
}
}


/* rgc-buffer-eol? */bool_t rgc_buffer_eol__219___rgc(obj_t input_port_219_22)
{
return rgc_buffer_eol_p(input_port_219_22);
}


/* _rgc-buffer-eol?1177 */obj_t _rgc_buffer_eol_1177_203___rgc(obj_t env_581, obj_t input_port_219_582)
{
{
bool_t aux_702;
{
obj_t input_port_219_615;
input_port_219_615 = input_port_219_582;
aux_702 = rgc_buffer_eol_p(input_port_219_615);
}
return BBOOL(aux_702);
}
}


/* rgc-buffer-bof? */bool_t rgc_buffer_bof__103___rgc(obj_t input_port_219_23)
{
return rgc_buffer_bof_p(input_port_219_23);
}


/* _rgc-buffer-bof?1178 */obj_t _rgc_buffer_bof_1178_21___rgc(obj_t env_583, obj_t input_port_219_584)
{
{
bool_t aux_706;
{
obj_t input_port_219_616;
input_port_219_616 = input_port_219_584;
aux_706 = rgc_buffer_bof_p(input_port_219_616);
}
return BBOOL(aux_706);
}
}


/* rgc-buffer-eof? */bool_t rgc_buffer_eof__127___rgc(obj_t input_port_219_24)
{
return rgc_buffer_eof_p(input_port_219_24);
}


/* _rgc-buffer-eof?1179 */obj_t _rgc_buffer_eof_1179_124___rgc(obj_t env_585, obj_t input_port_219_586)
{
{
bool_t aux_710;
{
obj_t input_port_219_617;
input_port_219_617 = input_port_219_586;
aux_710 = rgc_buffer_eof_p(input_port_219_617);
}
return BBOOL(aux_710);
}
}


/* rgc-the-submatch */obj_t rgc_the_submatch_107___rgc(obj_t rgc_submatches_142_25, int pos_26, int match_27, int submatch_28)
{
{
obj_t submatches_339;
obj_t start_340;
obj_t stop_341;
submatches_339 = rgc_submatches_142_25;
start_340 = BINT(((long)-1));
stop_341 = BINT(((long)-1));
loop_342:
if(NULLP(submatches_339)){
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = stop_341;
return start_340;
}
 else {
obj_t mv_346;
mv_346 = CAR(submatches_339);
{
obj_t sp_349;
sp_349 = VECTOR_REF(mv_346, ((long)2));
{
obj_t what_350;
what_350 = VECTOR_REF(mv_346, ((long)3));
{
{
bool_t test_719;
{
bool_t test_720;
{
long aux_725;
long aux_721;
aux_725 = (long)(match_27);
{
obj_t aux_722;
aux_722 = VECTOR_REF(mv_346, ((long)0));
aux_721 = (long)CINT(aux_722);
}
test_720 = (aux_721==aux_725);
}
if(test_720){
bool_t test_728;
{
long aux_733;
long aux_729;
aux_733 = (long)(submatch_28);
{
obj_t aux_730;
aux_730 = VECTOR_REF(mv_346, ((long)1));
aux_729 = (long)CINT(aux_730);
}
test_728 = (aux_729==aux_733);
}
if(test_728){
long aux_738;
long aux_736;
aux_738 = (long)(pos_26);
aux_736 = (long)CINT(sp_349);
test_719 = (aux_736<=aux_738);
}
 else {
test_719 = ((bool_t)0);
}
}
 else {
test_719 = ((bool_t)0);
}
}
if(test_719){
if((what_350==symbol1180___rgc)){
bool_t test_743;
{
long aux_744;
aux_744 = (long)CINT(stop_341);
test_743 = (aux_744<((long)0));
}
if(test_743){
obj_t stop_749;
obj_t submatches_747;
submatches_747 = CDR(submatches_339);
stop_749 = sp_349;
stop_341 = stop_749;
submatches_339 = submatches_747;
goto loop_342;
}
 else {
obj_t submatches_750;
submatches_750 = CDR(submatches_339);
submatches_339 = submatches_750;
goto loop_342;
}
}
 else {
if((what_350==symbol1181___rgc)){
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = stop_341;
return sp_349;
}
 else {
if((what_350==symbol1182___rgc)){
obj_t start_759;
obj_t submatches_757;
submatches_757 = CDR(submatches_339);
start_759 = sp_349;
start_340 = start_759;
submatches_339 = submatches_757;
goto loop_342;
}
 else {
return BFALSE;
}
}
}
}
 else {
obj_t submatches_760;
submatches_760 = CDR(submatches_339);
submatches_339 = submatches_760;
goto loop_342;
}
}
}
}
}
}
}
}


/* _rgc-the-submatch */obj_t _rgc_the_submatch_165___rgc(obj_t env_587, obj_t rgc_submatches_142_588, obj_t pos_589, obj_t match_590, obj_t submatch_591)
{
return rgc_the_submatch_107___rgc(rgc_submatches_142_588, CINT(pos_589), CINT(match_590), CINT(submatch_591));
}


/* imported-modules-init */obj_t imported_modules_init_94___rgc()
{
return module_initialization_70___error(((long)0), "__RGC");
}

