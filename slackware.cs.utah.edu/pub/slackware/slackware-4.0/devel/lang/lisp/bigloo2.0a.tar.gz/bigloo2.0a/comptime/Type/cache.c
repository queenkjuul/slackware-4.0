/*===========================================================================*/
/*   (Type/cache.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


obj_t _long__149_type_cache = BUNSPEC;
static obj_t method_init_76_type_cache();
obj_t _symbol__163_type_cache = BUNSPEC;
obj_t _bint__73_type_cache = BUNSPEC;
extern obj_t type_type_type;
obj_t _void__134_type_cache = BUNSPEC;
static obj_t _object__253_type_cache = BUNSPEC;
static obj_t _get_default_type_60_type_cache(obj_t);
static obj_t _default_type__236_type_cache = BUNSPEC;
obj_t _pair__244_type_cache = BUNSPEC;
obj_t _obj__252_type_cache = BUNSPEC;
extern obj_t get_object_type_154_type_cache();
obj_t _cell__121_type_cache = BUNSPEC;
obj_t _magic__144_type_cache = BUNSPEC;
extern bool_t is_a__118___object(obj_t, obj_t);
obj_t _unspec__87_type_cache = BUNSPEC;
extern type_t get_default_type_181_type_cache();
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
obj_t _bnil__15_type_cache = BUNSPEC;
static obj_t _install_type_cache__49_type_cache(obj_t);
static obj_t _get_object_type_254_type_cache(obj_t);
extern type_t find_type_26_type_env(obj_t);
obj_t _real__144_type_cache = BUNSPEC;
static obj_t imported_modules_init_94_type_cache();
obj_t _keyword__63_type_cache = BUNSPEC;
extern bool_t type_exists__12_type_env(obj_t);
static obj_t library_modules_init_112_type_cache();
extern obj_t install_type_cache__77_type_cache();
extern obj_t set_default_type__106_type_cache(type_t);
extern type_t use_type__231_type_env(obj_t);
static obj_t toplevel_init_63_type_cache();
extern obj_t open_input_string(obj_t);
static obj_t _set_default_type_1177_6_type_cache(obj_t, obj_t);
obj_t _cobj__54_type_cache = BUNSPEC;
obj_t _bbool__55_type_cache = BUNSPEC;
obj_t _bstring__127_type_cache = BUNSPEC;
obj_t _exit__255_type_cache = BUNSPEC;
obj_t _procedure__226_type_cache = BUNSPEC;
extern obj_t read___reader(obj_t);
obj_t _char__84_type_cache = BUNSPEC;
obj_t _string__3_type_cache = BUNSPEC;
obj_t ____74_type_cache = BUNSPEC;
static obj_t require_initialization_114_type_cache = BUNSPEC;
obj_t _vector__240_type_cache = BUNSPEC;
obj_t _struct__183_type_cache = BUNSPEC;
static obj_t cnst_init_137_type_cache();
obj_t _int__35_type_cache = BUNSPEC;
obj_t _bool__149_type_cache = BUNSPEC;
static obj_t __cnst[26];

DEFINE_EXPORT_PROCEDURE(set_default_type__env_17_type_cache, _set_default_type_1177_6_type_cache1192, _set_default_type_1177_6_type_cache, 0L, 1);
DEFINE_EXPORT_PROCEDURE(get_default_type_env_60_type_cache, _get_default_type_60_type_cache1193, _get_default_type_60_type_cache, 0L, 0);
DEFINE_EXPORT_PROCEDURE(get_object_type_env_58_type_cache, _get_object_type_254_type_cache1194, _get_object_type_254_type_cache, 0L, 0);
DEFINE_EXPORT_PROCEDURE(install_type_cache__env_169_type_cache, _install_type_cache__49_type_cache1195, _install_type_cache__49_type_cache, 0L, 0);
DEFINE_STRING(string1178_type_cache, string1178_type_cache1196, "_ OBJECT EXIT UNSPECIFIED PROCEDURE STRUCT VECTOR KEYWORD SYMBOL BSTRING STRING NIL PAIR UCHAR DOUBLE BBOOL BOOL LONG INT BINT VOID MAGIC CELL COBJ OBJ NO-TYPE-YET ", 164);


/* module-initialization */ obj_t 
module_initialization_70_type_cache(long checksum_108, char *from_109)
{
   if (CBOOL(require_initialization_114_type_cache))
     {
	require_initialization_114_type_cache = BBOOL(((bool_t) 0));
	library_modules_init_112_type_cache();
	cnst_init_137_type_cache();
	imported_modules_init_94_type_cache();
	method_init_76_type_cache();
	toplevel_init_63_type_cache();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_type_cache()
{
   module_initialization_70___object(((long) 0), "TYPE_CACHE");
   module_initialization_70___reader(((long) 0), "TYPE_CACHE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_type_cache()
{
   {
      obj_t cnst_port_138_100;
      cnst_port_138_100 = open_input_string(string1178_type_cache);
      {
	 long i_101;
	 i_101 = ((long) 25);
       loop_102:
	 {
	    bool_t test1179_103;
	    test1179_103 = (i_101 == ((long) -1));
	    if (test1179_103)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1187_104;
		    {
		       obj_t list1188_105;
		       {
			  obj_t arg1190_106;
			  arg1190_106 = BNIL;
			  list1188_105 = MAKE_PAIR(cnst_port_138_100, arg1190_106);
		       }
		       arg1187_104 = read___reader(list1188_105);
		    }
		    CNST_TABLE_SET(i_101, arg1187_104);
		 }
		 {
		    int aux_107;
		    {
		       long aux_126;
		       aux_126 = (i_101 - ((long) 1));
		       aux_107 = (int) (aux_126);
		    }
		    {
		       long i_129;
		       i_129 = (long) (aux_107);
		       i_101 = i_129;
		       goto loop_102;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_type_cache()
{
   _obj__252_type_cache = CNST_TABLE_REF(((long) 0));
   _cobj__54_type_cache = CNST_TABLE_REF(((long) 0));
   _cell__121_type_cache = CNST_TABLE_REF(((long) 0));
   _magic__144_type_cache = CNST_TABLE_REF(((long) 0));
   _void__134_type_cache = CNST_TABLE_REF(((long) 0));
   _bint__73_type_cache = CNST_TABLE_REF(((long) 0));
   _int__35_type_cache = CNST_TABLE_REF(((long) 0));
   _long__149_type_cache = CNST_TABLE_REF(((long) 0));
   _bool__149_type_cache = CNST_TABLE_REF(((long) 0));
   _bbool__55_type_cache = CNST_TABLE_REF(((long) 0));
   _real__144_type_cache = CNST_TABLE_REF(((long) 0));
   _char__84_type_cache = CNST_TABLE_REF(((long) 0));
   _string__3_type_cache = CNST_TABLE_REF(((long) 0));
   _bstring__127_type_cache = CNST_TABLE_REF(((long) 0));
   _symbol__163_type_cache = CNST_TABLE_REF(((long) 0));
   _keyword__63_type_cache = CNST_TABLE_REF(((long) 0));
   _pair__244_type_cache = CNST_TABLE_REF(((long) 0));
   _bnil__15_type_cache = CNST_TABLE_REF(((long) 0));
   _vector__240_type_cache = CNST_TABLE_REF(((long) 0));
   _struct__183_type_cache = CNST_TABLE_REF(((long) 0));
   _procedure__226_type_cache = CNST_TABLE_REF(((long) 0));
   _unspec__87_type_cache = CNST_TABLE_REF(((long) 0));
   _exit__255_type_cache = CNST_TABLE_REF(((long) 0));
   _object__253_type_cache = CNST_TABLE_REF(((long) 0));
   ____74_type_cache = CNST_TABLE_REF(((long) 0));
   return (_default_type__236_type_cache = CNST_TABLE_REF(((long) 0)),
      BUNSPEC);
}


/* install-type-cache! */ obj_t 
install_type_cache__77_type_cache()
{
   {
      type_t aux_157;
      aux_157 = use_type__231_type_env(CNST_TABLE_REF(((long) 1)));
      _obj__252_type_cache = (obj_t) (aux_157);
   }
   {
      type_t aux_161;
      aux_161 = use_type__231_type_env(CNST_TABLE_REF(((long) 2)));
      _cobj__54_type_cache = (obj_t) (aux_161);
   }
   {
      type_t aux_165;
      aux_165 = use_type__231_type_env(CNST_TABLE_REF(((long) 3)));
      _cell__121_type_cache = (obj_t) (aux_165);
   }
   {
      type_t aux_169;
      aux_169 = use_type__231_type_env(CNST_TABLE_REF(((long) 4)));
      _magic__144_type_cache = (obj_t) (aux_169);
   }
   {
      type_t aux_173;
      aux_173 = use_type__231_type_env(CNST_TABLE_REF(((long) 5)));
      _void__134_type_cache = (obj_t) (aux_173);
   }
   {
      type_t aux_177;
      aux_177 = use_type__231_type_env(CNST_TABLE_REF(((long) 6)));
      _bint__73_type_cache = (obj_t) (aux_177);
   }
   {
      type_t aux_181;
      aux_181 = use_type__231_type_env(CNST_TABLE_REF(((long) 7)));
      _int__35_type_cache = (obj_t) (aux_181);
   }
   {
      type_t aux_185;
      aux_185 = use_type__231_type_env(CNST_TABLE_REF(((long) 8)));
      _long__149_type_cache = (obj_t) (aux_185);
   }
   {
      type_t aux_189;
      aux_189 = use_type__231_type_env(CNST_TABLE_REF(((long) 9)));
      _bool__149_type_cache = (obj_t) (aux_189);
   }
   {
      type_t aux_193;
      aux_193 = use_type__231_type_env(CNST_TABLE_REF(((long) 10)));
      _bbool__55_type_cache = (obj_t) (aux_193);
   }
   {
      type_t aux_197;
      aux_197 = use_type__231_type_env(CNST_TABLE_REF(((long) 11)));
      _real__144_type_cache = (obj_t) (aux_197);
   }
   {
      type_t aux_201;
      aux_201 = use_type__231_type_env(CNST_TABLE_REF(((long) 12)));
      _char__84_type_cache = (obj_t) (aux_201);
   }
   {
      type_t aux_205;
      aux_205 = use_type__231_type_env(CNST_TABLE_REF(((long) 13)));
      _pair__244_type_cache = (obj_t) (aux_205);
   }
   {
      type_t aux_209;
      aux_209 = use_type__231_type_env(CNST_TABLE_REF(((long) 14)));
      _bnil__15_type_cache = (obj_t) (aux_209);
   }
   {
      type_t aux_213;
      aux_213 = use_type__231_type_env(CNST_TABLE_REF(((long) 15)));
      _string__3_type_cache = (obj_t) (aux_213);
   }
   {
      type_t aux_217;
      aux_217 = use_type__231_type_env(CNST_TABLE_REF(((long) 16)));
      _bstring__127_type_cache = (obj_t) (aux_217);
   }
   {
      type_t aux_221;
      aux_221 = use_type__231_type_env(CNST_TABLE_REF(((long) 17)));
      _symbol__163_type_cache = (obj_t) (aux_221);
   }
   {
      type_t aux_225;
      aux_225 = use_type__231_type_env(CNST_TABLE_REF(((long) 18)));
      _keyword__63_type_cache = (obj_t) (aux_225);
   }
   {
      type_t aux_229;
      aux_229 = use_type__231_type_env(CNST_TABLE_REF(((long) 19)));
      _vector__240_type_cache = (obj_t) (aux_229);
   }
   {
      type_t aux_233;
      aux_233 = use_type__231_type_env(CNST_TABLE_REF(((long) 20)));
      _struct__183_type_cache = (obj_t) (aux_233);
   }
   {
      type_t aux_237;
      aux_237 = use_type__231_type_env(CNST_TABLE_REF(((long) 21)));
      _procedure__226_type_cache = (obj_t) (aux_237);
   }
   {
      type_t aux_241;
      aux_241 = use_type__231_type_env(CNST_TABLE_REF(((long) 22)));
      _unspec__87_type_cache = (obj_t) (aux_241);
   }
   {
      type_t aux_245;
      aux_245 = use_type__231_type_env(CNST_TABLE_REF(((long) 23)));
      _exit__255_type_cache = (obj_t) (aux_245);
   }
   {
      bool_t test1146_72;
      test1146_72 = type_exists__12_type_env(CNST_TABLE_REF(((long) 24)));
      if (test1146_72)
	{
	   type_t aux_252;
	   aux_252 = find_type_26_type_env(CNST_TABLE_REF(((long) 24)));
	   _object__253_type_cache = (obj_t) (aux_252);
	}
      else
	{
	   _object__253_type_cache = BFALSE;
	}
   }
   {
      type_t aux_256;
      aux_256 = use_type__231_type_env(CNST_TABLE_REF(((long) 25)));
      ____74_type_cache = (obj_t) (aux_256);
   }
   return (_default_type__236_type_cache = ____74_type_cache,
      BUNSPEC);
}


/* _install-type-cache! */ obj_t 
_install_type_cache__49_type_cache(obj_t env_95)
{
   return install_type_cache__77_type_cache();
}


/* get-default-type */ type_t 
get_default_type_181_type_cache()
{
   return (type_t) (_default_type__236_type_cache);
}


/* _get-default-type */ obj_t 
_get_default_type_60_type_cache(obj_t env_96)
{
   {
      type_t aux_262;
      aux_262 = get_default_type_181_type_cache();
      return (obj_t) (aux_262);
   }
}


/* set-default-type! */ obj_t 
set_default_type__106_type_cache(type_t type_1)
{
   return (_default_type__236_type_cache = (obj_t) (type_1),
      BUNSPEC);
}


/* _set-default-type!1177 */ obj_t 
_set_default_type_1177_6_type_cache(obj_t env_97, obj_t type_98)
{
   return set_default_type__106_type_cache((type_t) (type_98));
}


/* get-object-type */ obj_t 
get_object_type_154_type_cache()
{
   {
      bool_t test1162_76;
      {
	 obj_t obj_94;
	 obj_94 = _object__253_type_cache;
	 test1162_76 = is_a__118___object(obj_94, type_type_type);
      }
      if (test1162_76)
	{
	   return _object__253_type_cache;
	}
      else
	{
	   {
	      type_t aux_270;
	      aux_270 = find_type_26_type_env(CNST_TABLE_REF(((long) 24)));
	      _object__253_type_cache = (obj_t) (aux_270);
	   }
	   return _object__253_type_cache;
	}
   }
}


/* _get-object-type */ obj_t 
_get_object_type_254_type_cache(obj_t env_99)
{
   return get_object_type_154_type_cache();
}


/* method-init */ obj_t 
method_init_76_type_cache()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_type_cache()
{
   module_initialization_70_type_type(((long) 0), "TYPE_CACHE");
   return module_initialization_70_type_env(((long) 0), "TYPE_CACHE");
}
