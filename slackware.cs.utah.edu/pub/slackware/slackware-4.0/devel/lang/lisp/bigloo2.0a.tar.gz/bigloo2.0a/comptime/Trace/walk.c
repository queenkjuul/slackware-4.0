/*===========================================================================*/
/*   (Trace/walk.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_trace_walk();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static node_t trace_node_95_trace_walk(node_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t current_error_port;
extern obj_t fail_ast_node;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t box_ref_242_ast_node;
extern obj_t leave_function_170_tools_error();
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t verbose_tools_speek(obj_t, obj_t);
static obj_t _trace_walk__101_trace_walk(obj_t, obj_t);
extern obj_t module_initialization_70_trace_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t trace_fun__23_trace_walk(obj_t);
static let_var_6_t make_traced_node_44_trace_walk(node_t, type_t, obj_t);
extern obj_t trace_walk__65_trace_walk(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_trace_walk();
extern obj_t app_ly_162_ast_node;
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t _trace_node_default1453_177_trace_walk(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_trace_walk();
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_trace_walk();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t string_to_bstring(char *);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _compiler_debug__134_engine_param;
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _trace_node1814_213_trace_walk(obj_t, obj_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_trace_walk = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t trace_node___31_trace_walk(obj_t);
static obj_t cnst_init_137_trace_walk();
extern obj_t _current_pass__25_engine_pass;
static node_t trace_node_default1453_157_trace_walk(node_t);
static obj_t __cnst[11];

DEFINE_STATIC_PROCEDURE(trace_node_default1453_env_24_trace_walk, _trace_node_default1453_177_trace_walk1828, _trace_node_default1453_177_trace_walk, 0L, 1);
DEFINE_STATIC_GENERIC(trace_node_env_147_trace_walk, _trace_node1814_213_trace_walk1829, _trace_node1814_213_trace_walk, 0L, 1);
DEFINE_EXPORT_PROCEDURE(trace_walk__env_32_trace_walk, _trace_walk__101_trace_walk1830, _trace_walk__101_trace_walk, 0L, 1);
DEFINE_STRING(string1821_trace_walk, string1821_trace_walk1831, "DONE VALUE C-POP-TRACE SET! C-PUSH-TRACE QUOTE LET SYMBOL AUX NO-TRACE PASS-STARTED ", 84);
DEFINE_STRING(string1819_trace_walk, string1819_trace_walk1832, " error", 6);
DEFINE_STRING(string1820_trace_walk, string1820_trace_walk1833, "failure during postlude hook", 28);
DEFINE_STRING(string1818_trace_walk, string1818_trace_walk1834, " occured, ending ...", 20);
DEFINE_STRING(string1817_trace_walk, string1817_trace_walk1835, "failure during prelude hook", 27);
DEFINE_STRING(string1816_trace_walk, string1816_trace_walk1836, "   . ", 5);
DEFINE_STRING(string1815_trace_walk, string1815_trace_walk1837, "Trace", 5);


/* module-initialization */ obj_t 
module_initialization_70_trace_walk(long checksum_1469, char *from_1470)
{
   if (CBOOL(require_initialization_114_trace_walk))
     {
	require_initialization_114_trace_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_trace_walk();
	cnst_init_137_trace_walk();
	imported_modules_init_94_trace_walk();
	method_init_76_trace_walk();
	toplevel_init_63_trace_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_trace_walk()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "TRACE_WALK");
   module_initialization_70___object(((long) 0), "TRACE_WALK");
   module_initialization_70___r4_output_6_10_3(((long) 0), "TRACE_WALK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "TRACE_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "TRACE_WALK");
   module_initialization_70___reader(((long) 0), "TRACE_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_trace_walk()
{
   {
      obj_t cnst_port_138_1461;
      cnst_port_138_1461 = open_input_string(string1821_trace_walk);
      {
	 long i_1462;
	 i_1462 = ((long) 10);
       loop_1463:
	 {
	    bool_t test1822_1464;
	    test1822_1464 = (i_1462 == ((long) -1));
	    if (test1822_1464)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1823_1465;
		    {
		       obj_t list1824_1466;
		       {
			  obj_t arg1826_1467;
			  arg1826_1467 = BNIL;
			  list1824_1466 = MAKE_PAIR(cnst_port_138_1461, arg1826_1467);
		       }
		       arg1823_1465 = read___reader(list1824_1466);
		    }
		    CNST_TABLE_SET(i_1462, arg1823_1465);
		 }
		 {
		    int aux_1468;
		    {
		       long aux_1491;
		       aux_1491 = (i_1462 - ((long) 1));
		       aux_1468 = (int) (aux_1491);
		    }
		    {
		       long i_1494;
		       i_1494 = (long) (aux_1468);
		       i_1462 = i_1494;
		       goto loop_1463;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_trace_walk()
{
   return BUNSPEC;
}


/* trace-walk! */ obj_t 
trace_walk__65_trace_walk(obj_t globals_1)
{
   {
      obj_t list1471_717;
      {
	 obj_t arg1474_719;
	 {
	    obj_t arg1476_721;
	    {
	       obj_t aux_1496;
	       aux_1496 = BCHAR(((unsigned char) '\n'));
	       arg1476_721 = MAKE_PAIR(aux_1496, BNIL);
	    }
	    arg1474_719 = MAKE_PAIR(string1815_trace_walk, arg1476_721);
	 }
	 list1471_717 = MAKE_PAIR(string1816_trace_walk, arg1474_719);
      }
      verbose_tools_speek(BINT(((long) 1)), list1471_717);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1815_trace_walk;
   {
      obj_t hooks_723;
      obj_t hnames_724;
      hooks_723 = BNIL;
      hnames_724 = BNIL;
    loop_725:
      if (NULLP(hooks_723))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1482_730;
	   {
	      obj_t fun1489_736;
	      fun1489_736 = CAR(hooks_723);
	      {
		 obj_t aux_1508;
		 aux_1508 = PROCEDURE_ENTRY(fun1489_736) (fun1489_736, BEOA);
		 test1482_730 = CBOOL(aux_1508);
	      }
	   }
	   if (test1482_730)
	     {
		{
		   obj_t hnames_1515;
		   obj_t hooks_1513;
		   hooks_1513 = CDR(hooks_723);
		   hnames_1515 = CDR(hnames_724);
		   hnames_724 = hnames_1515;
		   hooks_723 = hooks_1513;
		   goto loop_725;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1815_trace_walk, string1817_trace_walk, CAR(hnames_724));
	     }
	}
   }
   {
      obj_t l1435_737;
      l1435_737 = globals_1;
    lname1436_738:
      if (PAIRP(l1435_737))
	{
	   trace_fun__23_trace_walk(CAR(l1435_737));
	   {
	      obj_t l1435_1523;
	      l1435_1523 = CDR(l1435_737);
	      l1435_737 = l1435_1523;
	      goto lname1436_738;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      bool_t test1495_743;
      {
	 long n1_1313;
	 n1_1313 = (long) CINT(_nb_error_on_pass__70_tools_error);
	 test1495_743 = (n1_1313 > ((long) 0));
      }
      if (test1495_743)
	{
	   {
	      char *arg1498_746;
	      {
		 bool_t test1505_753;
		 {
		    bool_t test1506_754;
		    {
		       obj_t obj_1315;
		       obj_1315 = _nb_error_on_pass__70_tools_error;
		       test1506_754 = INTEGERP(obj_1315);
		    }
		    if (test1506_754)
		      {
			 test1505_753 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
		      }
		    else
		      {
			 test1505_753 = ((bool_t) 0);
		      }
		 }
		 if (test1505_753)
		   {
		      arg1498_746 = "s";
		   }
		 else
		   {
		      arg1498_746 = "";
		   }
	      }
	      {
		 obj_t list1500_748;
		 {
		    obj_t arg1501_749;
		    {
		       obj_t arg1502_750;
		       {
			  obj_t arg1503_751;
			  arg1503_751 = MAKE_PAIR(string1818_trace_walk, BNIL);
			  {
			     obj_t aux_1534;
			     aux_1534 = string_to_bstring(arg1498_746);
			     arg1502_750 = MAKE_PAIR(aux_1534, arg1503_751);
			  }
		       }
		       arg1501_749 = MAKE_PAIR(string1819_trace_walk, arg1502_750);
		    }
		    list1500_748 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1501_749);
		 }
		 fprint___r4_output_6_10_3(current_error_port, list1500_748);
	      }
	   }
	   {
	      obj_t res1812_1317;
	      exit(((long) -1));
	      res1812_1317 = BINT(((long) -1));
	      return res1812_1317;
	   }
	}
      else
	{
	   obj_t hooks_755;
	   obj_t hnames_756;
	   hooks_755 = BNIL;
	   hnames_756 = BNIL;
	 loop_757:
	   if (NULLP(hooks_755))
	     {
		return globals_1;
	     }
	   else
	     {
		bool_t test1513_762;
		{
		   obj_t fun1518_767;
		   fun1518_767 = CAR(hooks_755);
		   {
		      obj_t aux_1545;
		      aux_1545 = PROCEDURE_ENTRY(fun1518_767) (fun1518_767, BEOA);
		      test1513_762 = CBOOL(aux_1545);
		   }
		}
		if (test1513_762)
		  {
		     {
			obj_t hnames_1552;
			obj_t hooks_1550;
			hooks_1550 = CDR(hooks_755);
			hnames_1552 = CDR(hnames_756);
			hnames_756 = hnames_1552;
			hooks_755 = hooks_1550;
			goto loop_757;
		     }
		  }
		else
		  {
		     return internal_error_43_tools_error(_current_pass__25_engine_pass, string1820_trace_walk, CAR(hnames_756));
		  }
	     }
	}
   }
}


/* _trace-walk! */ obj_t 
_trace_walk__101_trace_walk(obj_t env_1455, obj_t globals_1456)
{
   return trace_walk__65_trace_walk(globals_1456);
}


/* trace-fun! */ obj_t 
trace_fun__23_trace_walk(obj_t var_2)
{
   {
      value_t fun_768;
      {
	 variable_t obj_1324;
	 obj_1324 = (variable_t) (var_2);
	 fun_768 = (((variable_t) CREF(obj_1324))->value);
      }
      {
	 obj_t body_769;
	 {
	    sfun_t obj_1325;
	    obj_1325 = (sfun_t) (fun_768);
	    body_769 = (((sfun_t) CREF(obj_1325))->body);
	 }
	 {
	    type_t type_770;
	    {
	       variable_t obj_1326;
	       obj_1326 = (variable_t) (var_2);
	       type_770 = (((variable_t) CREF(obj_1326))->type);
	    }
	    {
	       {
		  bool_t test_1563;
		  {
		     bool_t test_1564;
		     {
			fun_t obj_1327;
			obj_1327 = (fun_t) (fun_768);
			{
			   obj_t aux_1566;
			   aux_1566 = (((fun_t) CREF(obj_1327))->predicate_of_78);
			   test_1564 = CBOOL(aux_1566);
			}
		     }
		     if (test_1564)
		       {
			  test_1563 = ((bool_t) 0);
		       }
		     else
		       {
			  bool_t test_1569;
			  {
			     obj_t aux_1570;
			     {
				obj_t aux_1571;
				{
				   sfun_t obj_1328;
				   obj_1328 = (sfun_t) (fun_768);
				   aux_1571 = (((sfun_t) CREF(obj_1328))->property);
				}
				aux_1570 = memq___r4_pairs_and_lists_6_3(CNST_TABLE_REF(((long) 1)), aux_1571);
			     }
			     test_1569 = CBOOL(aux_1570);
			  }
			  if (test_1569)
			    {
			       test_1563 = ((bool_t) 0);
			    }
			  else
			    {
			       test_1563 = ((bool_t) 1);
			    }
		       }
		  }
		  if (test_1563)
		    {
		       {
			  obj_t aux_1577;
			  {
			     variable_t obj_1329;
			     obj_1329 = (variable_t) (var_2);
			     aux_1577 = (((variable_t) CREF(obj_1329))->id);
			  }
			  enter_function_81_tools_error(aux_1577);
		       }
		       {
			  obj_t new_body_215_773;
			  {
			     bool_t test1525_776;
			     {
				long n1_1330;
				n1_1330 = (long) CINT(_compiler_debug__134_engine_param);
				test1525_776 = (n1_1330 >= ((long) 2));
			     }
			     if (test1525_776)
			       {
				  node_t aux_1584;
				  aux_1584 = trace_node_95_trace_walk((node_t) (body_769));
				  new_body_215_773 = (obj_t) (aux_1584);
			       }
			     else
			       {
				  new_body_215_773 = body_769;
			       }
			  }
			  {
			     let_var_6_t new2_body_172_774;
			     {
				obj_t aux_1588;
				{
				   variable_t obj_1332;
				   obj_1332 = (variable_t) (var_2);
				   aux_1588 = (((variable_t) CREF(obj_1332))->id);
				}
				new2_body_172_774 = make_traced_node_44_trace_walk((node_t) (new_body_215_773), type_770, aux_1588);
			     }
			     {
				{
				   sfun_t obj_1333;
				   obj_t val1135_1334;
				   obj_1333 = (sfun_t) (fun_768);
				   val1135_1334 = (obj_t) (new2_body_172_774);
				   ((((sfun_t) CREF(obj_1333))->body) = ((obj_t) val1135_1334), BUNSPEC);
				}
				return leave_function_170_tools_error();
			     }
			  }
		       }
		    }
		  else
		    {
		       return BUNSPEC;
		    }
	       }
	    }
	 }
      }
   }
}


/* make-traced-node */ let_var_6_t 
make_traced_node_44_trace_walk(node_t node_3, type_t type_4, obj_t symbol_5)
{
   {
      obj_t loc_781;
      loc_781 = (((node_t) CREF(node_3))->loc);
      {
	 obj_t aux_782;
	 aux_782 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
	 {
	    obj_t taux_783;
	    {
	       obj_t list1619_857;
	       {
		  obj_t arg1620_858;
		  {
		     obj_t arg1621_859;
		     {
			obj_t aux_1601;
			aux_1601 = (((type_t) CREF(type_4))->id);
			arg1621_859 = MAKE_PAIR(aux_1601, BNIL);
		     }
		     arg1620_858 = MAKE_PAIR(_4dots_199_tools_misc, arg1621_859);
		  }
		  list1619_857 = MAKE_PAIR(aux_782, arg1620_858);
	       }
	       taux_783 = symbol_append_197___r4_symbols_6_4(list1619_857);
	    }
	    {
	       obj_t sym_784;
	       sym_784 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 3)), BEOA);
	       {
		  obj_t exp_785;
		  {
		     obj_t arg1532_789;
		     obj_t arg1533_790;
		     obj_t arg1534_791;
		     arg1532_789 = CNST_TABLE_REF(((long) 4));
		     {
			obj_t arg1542_797;
			{
			   obj_t arg1549_801;
			   {
			      obj_t arg1554_806;
			      arg1554_806 = CNST_TABLE_REF(((long) 5));
			      {
				 obj_t list1556_808;
				 {
				    obj_t arg1557_809;
				    arg1557_809 = MAKE_PAIR(BNIL, BNIL);
				    list1556_808 = MAKE_PAIR(symbol_5, arg1557_809);
				 }
				 arg1549_801 = cons__138___r4_pairs_and_lists_6_3(arg1554_806, list1556_808);
			      }
			   }
			   {
			      obj_t list1551_803;
			      {
				 obj_t arg1552_804;
				 arg1552_804 = MAKE_PAIR(BNIL, BNIL);
				 list1551_803 = MAKE_PAIR(arg1549_801, arg1552_804);
			      }
			      arg1542_797 = cons__138___r4_pairs_and_lists_6_3(sym_784, list1551_803);
			   }
			}
			{
			   obj_t list1546_799;
			   list1546_799 = MAKE_PAIR(BNIL, BNIL);
			   arg1533_790 = cons__138___r4_pairs_and_lists_6_3(arg1542_797, list1546_799);
			}
		     }
		     {
			obj_t arg1559_811;
			obj_t arg1561_813;
			obj_t arg1562_814;
			obj_t arg1563_815;
			arg1559_811 = CNST_TABLE_REF(((long) 4));
			{
			   obj_t arg1573_823;
			   arg1573_823 = CNST_TABLE_REF(((long) 6));
			   {
			      obj_t list1576_825;
			      {
				 obj_t arg1578_826;
				 arg1578_826 = MAKE_PAIR(BNIL, BNIL);
				 list1576_825 = MAKE_PAIR(sym_784, arg1578_826);
			      }
			      arg1561_813 = cons__138___r4_pairs_and_lists_6_3(arg1573_823, list1576_825);
			   }
			}
			{
			   obj_t arg1581_828;
			   arg1581_828 = CNST_TABLE_REF(((long) 7));
			   {
			      obj_t list1583_830;
			      {
				 obj_t arg1584_831;
				 {
				    obj_t arg1585_832;
				    arg1585_832 = MAKE_PAIR(BNIL, BNIL);
				    arg1584_831 = MAKE_PAIR(sym_784, arg1585_832);
				 }
				 list1583_830 = MAKE_PAIR(sym_784, arg1584_831);
			      }
			      arg1562_814 = cons__138___r4_pairs_and_lists_6_3(arg1581_828, list1583_830);
			   }
			}
			{
			   obj_t arg1587_834;
			   obj_t arg1588_835;
			   obj_t arg1589_836;
			   arg1587_834 = CNST_TABLE_REF(((long) 4));
			   {
			      obj_t arg1602_843;
			      {
				 obj_t list1607_848;
				 {
				    obj_t arg1608_849;
				    arg1608_849 = MAKE_PAIR(BNIL, BNIL);
				    {
				       obj_t aux_1632;
				       aux_1632 = (obj_t) (node_3);
				       list1607_848 = MAKE_PAIR(aux_1632, arg1608_849);
				    }
				 }
				 arg1602_843 = cons__138___r4_pairs_and_lists_6_3(taux_783, list1607_848);
			      }
			      {
				 obj_t list1604_845;
				 list1604_845 = MAKE_PAIR(BNIL, BNIL);
				 arg1588_835 = cons__138___r4_pairs_and_lists_6_3(arg1602_843, list1604_845);
			      }
			   }
			   {
			      obj_t arg1610_851;
			      arg1610_851 = CNST_TABLE_REF(((long) 8));
			      {
				 obj_t list1613_853;
				 list1613_853 = MAKE_PAIR(BNIL, BNIL);
				 arg1589_836 = cons__138___r4_pairs_and_lists_6_3(arg1610_851, list1613_853);
			      }
			   }
			   {
			      obj_t list1593_838;
			      {
				 obj_t arg1594_839;
				 {
				    obj_t arg1595_840;
				    {
				       obj_t arg1598_841;
				       arg1598_841 = MAKE_PAIR(BNIL, BNIL);
				       arg1595_840 = MAKE_PAIR(aux_782, arg1598_841);
				    }
				    arg1594_839 = MAKE_PAIR(arg1589_836, arg1595_840);
				 }
				 list1593_838 = MAKE_PAIR(arg1588_835, arg1594_839);
			      }
			      arg1563_815 = cons__138___r4_pairs_and_lists_6_3(arg1587_834, list1593_838);
			   }
			}
			{
			   obj_t list1565_817;
			   {
			      obj_t arg1566_818;
			      {
				 obj_t arg1568_819;
				 {
				    obj_t arg1569_820;
				    {
				       obj_t arg1570_821;
				       arg1570_821 = MAKE_PAIR(BNIL, BNIL);
				       arg1569_820 = MAKE_PAIR(arg1563_815, arg1570_821);
				    }
				    arg1568_819 = MAKE_PAIR(arg1562_814, arg1569_820);
				 }
				 arg1566_818 = MAKE_PAIR(arg1561_813, arg1568_819);
			      }
			      list1565_817 = MAKE_PAIR(BNIL, arg1566_818);
			   }
			   arg1534_791 = cons__138___r4_pairs_and_lists_6_3(arg1559_811, list1565_817);
			}
		     }
		     {
			obj_t list1536_793;
			{
			   obj_t arg1537_794;
			   {
			      obj_t arg1539_795;
			      arg1539_795 = MAKE_PAIR(BNIL, BNIL);
			      arg1537_794 = MAKE_PAIR(arg1534_791, arg1539_795);
			   }
			   list1536_793 = MAKE_PAIR(arg1533_790, arg1537_794);
			}
			exp_785 = cons__138___r4_pairs_and_lists_6_3(arg1532_789, list1536_793);
		     }
		  }
		  {
		     node_t node_786;
		     node_786 = sexp__node_235_ast_sexp(exp_785, BNIL, loc_781, CNST_TABLE_REF(((long) 9)));
		     {
			{
			   let_var_6_t obj_1337;
			   obj_1337 = (let_var_6_t) (node_786);
			   ((((let_var_6_t) CREF(obj_1337))->removable__42) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			}
			return (let_var_6_t) (node_786);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* trace-node*! */ obj_t 
trace_node___31_trace_walk(obj_t node__221_25)
{
 trace_node___31_trace_walk:
   if (NULLP(node__221_25))
     {
	return CNST_TABLE_REF(((long) 10));
     }
   else
     {
	{
	   node_t arg1625_863;
	   {
	      node_t aux_1664;
	      {
		 obj_t aux_1665;
		 aux_1665 = CAR(node__221_25);
		 aux_1664 = (node_t) (aux_1665);
	      }
	      arg1625_863 = trace_node_95_trace_walk(aux_1664);
	   }
	   {
	      obj_t aux_1669;
	      aux_1669 = (obj_t) (arg1625_863);
	      SET_CAR(node__221_25, aux_1669);
	   }
	}
	{
	   obj_t node__221_1672;
	   node__221_1672 = CDR(node__221_25);
	   node__221_25 = node__221_1672;
	   goto trace_node___31_trace_walk;
	}
     }
}


/* method-init */ obj_t 
method_init_76_trace_walk()
{
   add_generic__110___object(trace_node_env_147_trace_walk, trace_node_default1453_env_24_trace_walk);
   add_inlined_method__244___object(trace_node_env_147_trace_walk, sequence_ast_node, ((long) 0));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, app_ast_node, ((long) 1));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, app_ly_162_ast_node, ((long) 2));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, funcall_ast_node, ((long) 3));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, pragma_ast_node, ((long) 4));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, cast_ast_node, ((long) 5));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, setq_ast_node, ((long) 6));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, conditional_ast_node, ((long) 7));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, fail_ast_node, ((long) 8));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, select_ast_node, ((long) 9));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, let_fun_218_ast_node, ((long) 10));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, let_var_6_ast_node, ((long) 11));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, set_ex_it_116_ast_node, ((long) 12));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, jump_ex_it_184_ast_node, ((long) 13));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, make_box_202_ast_node, ((long) 14));
   add_inlined_method__244___object(trace_node_env_147_trace_walk, box_ref_242_ast_node, ((long) 15));
   {
      long aux_1691;
      aux_1691 = add_inlined_method__244___object(trace_node_env_147_trace_walk, box_set__221_ast_node, ((long) 16));
      return BINT(aux_1691);
   }
}


/* trace-node */ node_t 
trace_node_95_trace_walk(node_t node_6)
{
   {
      obj_t method1716_1195;
      obj_t class1721_1196;
      {
	 obj_t arg1724_1193;
	 obj_t arg1725_1194;
	 {
	    object_t obj_1344;
	    obj_1344 = (object_t) (node_6);
	    {
	       obj_t pre_method_105_1345;
	       pre_method_105_1345 = PROCEDURE_REF(trace_node_env_147_trace_walk, ((long) 2));
	       if (INTEGERP(pre_method_105_1345))
		 {
		    PROCEDURE_SET(trace_node_env_147_trace_walk, ((long) 2), BUNSPEC);
		    arg1724_1193 = pre_method_105_1345;
		 }
	       else
		 {
		    long obj_class_num_177_1350;
		    obj_class_num_177_1350 = TYPE(obj_1344);
		    {
		       obj_t arg1177_1351;
		       arg1177_1351 = PROCEDURE_REF(trace_node_env_147_trace_walk, ((long) 1));
		       {
			  long arg1178_1355;
			  {
			     long arg1179_1356;
			     arg1179_1356 = OBJECT_TYPE;
			     arg1178_1355 = (obj_class_num_177_1350 - arg1179_1356);
			  }
			  arg1724_1193 = VECTOR_REF(arg1177_1351, arg1178_1355);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1361;
	    object_1361 = (object_t) (node_6);
	    {
	       long arg1180_1362;
	       {
		  long arg1181_1363;
		  long arg1182_1364;
		  arg1181_1363 = TYPE(object_1361);
		  arg1182_1364 = OBJECT_TYPE;
		  arg1180_1362 = (arg1181_1363 - arg1182_1364);
	       }
	       {
		  obj_t vector_1368;
		  vector_1368 = _classes__134___object;
		  arg1725_1194 = VECTOR_REF(vector_1368, arg1180_1362);
	       }
	    }
	 }
	 {
	    obj_t aux_1709;
	    method1716_1195 = arg1724_1193;
	    class1721_1196 = arg1725_1194;
	    {
	       if (INTEGERP(method1716_1195))
		 {
		    switch ((long) CINT(method1716_1195))
		      {
		      case ((long) 0):
			 {
			    sequence_t node_1202;
			    node_1202 = (sequence_t) (node_6);
			    trace_node___31_trace_walk((((sequence_t) CREF(node_1202))->nodes));
			    aux_1709 = (obj_t) (node_1202);
			 }
			 break;
		      case ((long) 1):
			 {
			    app_t node_1204;
			    node_1204 = (app_t) (node_6);
			    trace_node___31_trace_walk((((app_t) CREF(node_1204))->args));
			    aux_1709 = (obj_t) (node_1204);
			 }
			 break;
		      case ((long) 2):
			 {
			    app_ly_162_t node_1206;
			    node_1206 = (app_ly_162_t) (node_6);
			    {
			       node_t arg1730_1208;
			       arg1730_1208 = trace_node_95_trace_walk((((app_ly_162_t) CREF(node_1206))->fun));
			       ((((app_ly_162_t) CREF(node_1206))->fun) = ((node_t) arg1730_1208), BUNSPEC);
			    }
			    {
			       node_t arg1732_1210;
			       arg1732_1210 = trace_node_95_trace_walk((((app_ly_162_t) CREF(node_1206))->arg));
			       ((((app_ly_162_t) CREF(node_1206))->arg) = ((node_t) arg1732_1210), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1206);
			 }
			 break;
		      case ((long) 3):
			 {
			    funcall_t node_1212;
			    node_1212 = (funcall_t) (node_6);
			    {
			       node_t arg1738_1214;
			       arg1738_1214 = trace_node_95_trace_walk((((funcall_t) CREF(node_1212))->fun));
			       ((((funcall_t) CREF(node_1212))->fun) = ((node_t) arg1738_1214), BUNSPEC);
			    }
			    trace_node___31_trace_walk((((funcall_t) CREF(node_1212))->args));
			    aux_1709 = (obj_t) (node_1212);
			 }
			 break;
		      case ((long) 4):
			 {
			    pragma_t node_1217;
			    node_1217 = (pragma_t) (node_6);
			    trace_node___31_trace_walk((((pragma_t) CREF(node_1217))->args));
			    aux_1709 = (obj_t) (node_1217);
			 }
			 break;
		      case ((long) 5):
			 {
			    cast_t node_1219;
			    node_1219 = (cast_t) (node_6);
			    trace_node_95_trace_walk((((cast_t) CREF(node_1219))->arg));
			    aux_1709 = (obj_t) (node_1219);
			 }
			 break;
		      case ((long) 6):
			 {
			    setq_t node_1221;
			    node_1221 = (setq_t) (node_6);
			    {
			       node_t arg1745_1222;
			       arg1745_1222 = trace_node_95_trace_walk((((setq_t) CREF(node_1221))->value));
			       ((((setq_t) CREF(node_1221))->value) = ((node_t) arg1745_1222), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1221);
			 }
			 break;
		      case ((long) 7):
			 {
			    conditional_t node_1224;
			    node_1224 = (conditional_t) (node_6);
			    {
			       node_t arg1747_1226;
			       arg1747_1226 = trace_node_95_trace_walk((((conditional_t) CREF(node_1224))->test));
			       ((((conditional_t) CREF(node_1224))->test) = ((node_t) arg1747_1226), BUNSPEC);
			    }
			    {
			       node_t arg1749_1228;
			       arg1749_1228 = trace_node_95_trace_walk((((conditional_t) CREF(node_1224))->true));
			       ((((conditional_t) CREF(node_1224))->true) = ((node_t) arg1749_1228), BUNSPEC);
			    }
			    {
			       node_t arg1755_1230;
			       arg1755_1230 = trace_node_95_trace_walk((((conditional_t) CREF(node_1224))->false));
			       ((((conditional_t) CREF(node_1224))->false) = ((node_t) arg1755_1230), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1224);
			 }
			 break;
		      case ((long) 8):
			 {
			    fail_t node_1232;
			    node_1232 = (fail_t) (node_6);
			    {
			       node_t arg1759_1234;
			       arg1759_1234 = trace_node_95_trace_walk((((fail_t) CREF(node_1232))->proc));
			       ((((fail_t) CREF(node_1232))->proc) = ((node_t) arg1759_1234), BUNSPEC);
			    }
			    {
			       node_t arg1761_1236;
			       arg1761_1236 = trace_node_95_trace_walk((((fail_t) CREF(node_1232))->msg));
			       ((((fail_t) CREF(node_1232))->msg) = ((node_t) arg1761_1236), BUNSPEC);
			    }
			    {
			       node_t arg1765_1238;
			       arg1765_1238 = trace_node_95_trace_walk((((fail_t) CREF(node_1232))->obj));
			       ((((fail_t) CREF(node_1232))->obj) = ((node_t) arg1765_1238), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1232);
			 }
			 break;
		      case ((long) 9):
			 {
			    select_t node_1240;
			    node_1240 = (select_t) (node_6);
			    {
			       node_t arg1767_1242;
			       arg1767_1242 = trace_node_95_trace_walk((((select_t) CREF(node_1240))->test));
			       ((((select_t) CREF(node_1240))->test) = ((node_t) arg1767_1242), BUNSPEC);
			    }
			    {
			       obj_t l1442_1244;
			       l1442_1244 = (((select_t) CREF(node_1240))->clauses);
			     lname1443_1245:
			       if (PAIRP(l1442_1244))
				 {
				    {
				       obj_t clause_1248;
				       clause_1248 = CAR(l1442_1244);
				       {
					  node_t arg1771_1249;
					  {
					     node_t aux_1777;
					     {
						obj_t aux_1778;
						aux_1778 = CDR(clause_1248);
						aux_1777 = (node_t) (aux_1778);
					     }
					     arg1771_1249 = trace_node_95_trace_walk(aux_1777);
					  }
					  {
					     obj_t aux_1782;
					     aux_1782 = (obj_t) (arg1771_1249);
					     SET_CDR(clause_1248, aux_1782);
					  }
				       }
				    }
				    {
				       obj_t l1442_1785;
				       l1442_1785 = CDR(l1442_1244);
				       l1442_1244 = l1442_1785;
				       goto lname1443_1245;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_1709 = (obj_t) (node_1240);
			 }
			 break;
		      case ((long) 10):
			 {
			    let_fun_218_t node_1252;
			    node_1252 = (let_fun_218_t) (node_6);
			    {
			       obj_t l1445_1254;
			       l1445_1254 = (((let_fun_218_t) CREF(node_1252))->locals);
			     lname1446_1255:
			       if (PAIRP(l1445_1254))
				 {
				    trace_fun__23_trace_walk(CAR(l1445_1254));
				    {
				       obj_t l1445_1794;
				       l1445_1794 = CDR(l1445_1254);
				       l1445_1254 = l1445_1794;
				       goto lname1446_1255;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1778_1260;
			       arg1778_1260 = trace_node_95_trace_walk((((let_fun_218_t) CREF(node_1252))->body));
			       ((((let_fun_218_t) CREF(node_1252))->body) = ((node_t) arg1778_1260), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1252);
			 }
			 break;
		      case ((long) 11):
			 {
			    let_var_6_t node_1262;
			    node_1262 = (let_var_6_t) (node_6);
			    {
			       obj_t l1448_1264;
			       l1448_1264 = (((let_var_6_t) CREF(node_1262))->bindings);
			     lname1449_1265:
			       if (PAIRP(l1448_1264))
				 {
				    {
				       obj_t binding_1268;
				       binding_1268 = CAR(l1448_1264);
				       {
					  node_t arg1783_1269;
					  {
					     node_t aux_1805;
					     {
						obj_t aux_1806;
						aux_1806 = CDR(binding_1268);
						aux_1805 = (node_t) (aux_1806);
					     }
					     arg1783_1269 = trace_node_95_trace_walk(aux_1805);
					  }
					  {
					     obj_t aux_1810;
					     aux_1810 = (obj_t) (arg1783_1269);
					     SET_CDR(binding_1268, aux_1810);
					  }
				       }
				    }
				    {
				       obj_t l1448_1813;
				       l1448_1813 = CDR(l1448_1264);
				       l1448_1264 = l1448_1813;
				       goto lname1449_1265;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1789_1272;
			       arg1789_1272 = trace_node_95_trace_walk((((let_var_6_t) CREF(node_1262))->body));
			       ((((let_var_6_t) CREF(node_1262))->body) = ((node_t) arg1789_1272), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1262);
			 }
			 break;
		      case ((long) 12):
			 {
			    set_ex_it_116_t node_1274;
			    node_1274 = (set_ex_it_116_t) (node_6);
			    {
			       node_t arg1791_1275;
			       arg1791_1275 = trace_node_95_trace_walk((((set_ex_it_116_t) CREF(node_1274))->body));
			       ((((set_ex_it_116_t) CREF(node_1274))->body) = ((node_t) arg1791_1275), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1274);
			 }
			 break;
		      case ((long) 13):
			 {
			    jump_ex_it_184_t node_1277;
			    node_1277 = (jump_ex_it_184_t) (node_6);
			    {
			       node_t arg1793_1279;
			       arg1793_1279 = trace_node_95_trace_walk((((jump_ex_it_184_t) CREF(node_1277))->exit));
			       ((((jump_ex_it_184_t) CREF(node_1277))->exit) = ((node_t) arg1793_1279), BUNSPEC);
			    }
			    {
			       node_t arg1795_1281;
			       arg1795_1281 = trace_node_95_trace_walk((((jump_ex_it_184_t) CREF(node_1277))->value));
			       ((((jump_ex_it_184_t) CREF(node_1277))->value) = ((node_t) arg1795_1281), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1277);
			 }
			 break;
		      case ((long) 14):
			 {
			    make_box_202_t node_1283;
			    node_1283 = (make_box_202_t) (node_6);
			    {
			       node_t arg1797_1284;
			       arg1797_1284 = trace_node_95_trace_walk((((make_box_202_t) CREF(node_1283))->value));
			       ((((make_box_202_t) CREF(node_1283))->value) = ((node_t) arg1797_1284), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1283);
			 }
			 break;
		      case ((long) 15):
			 {
			    box_ref_242_t node_1286;
			    node_1286 = (box_ref_242_t) (node_6);
			    {
			       node_t arg1800_1287;
			       {
				  node_t aux_1839;
				  {
				     var_t aux_1840;
				     aux_1840 = (((box_ref_242_t) CREF(node_1286))->var);
				     aux_1839 = (node_t) (aux_1840);
				  }
				  arg1800_1287 = trace_node_95_trace_walk(aux_1839);
			       }
			       {
				  var_t val1423_1446;
				  val1423_1446 = (var_t) (arg1800_1287);
				  ((((box_ref_242_t) CREF(node_1286))->var) = ((var_t) val1423_1446), BUNSPEC);
			       }
			    }
			    aux_1709 = (obj_t) (node_1286);
			 }
			 break;
		      case ((long) 16):
			 {
			    box_set__221_t node_1289;
			    node_1289 = (box_set__221_t) (node_6);
			    {
			       node_t arg1803_1291;
			       {
				  node_t aux_1848;
				  {
				     var_t aux_1849;
				     aux_1849 = (((box_set__221_t) CREF(node_1289))->var);
				     aux_1848 = (node_t) (aux_1849);
				  }
				  arg1803_1291 = trace_node_95_trace_walk(aux_1848);
			       }
			       {
				  var_t val1432_1449;
				  val1432_1449 = (var_t) (arg1803_1291);
				  ((((box_set__221_t) CREF(node_1289))->var) = ((var_t) val1432_1449), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1805_1293;
			       arg1805_1293 = trace_node_95_trace_walk((((box_set__221_t) CREF(node_1289))->value));
			       ((((box_set__221_t) CREF(node_1289))->value) = ((node_t) arg1805_1293), BUNSPEC);
			    }
			    aux_1709 = (obj_t) (node_1289);
			 }
			 break;
		      default:
		       case_else1722_1199:
			 if (PROCEDUREP(method1716_1195))
			   {
			      aux_1709 = PROCEDURE_ENTRY(method1716_1195) (method1716_1195, (obj_t) (node_6), BEOA);
			   }
			 else
			   {
			      obj_t fun1715_1191;
			      fun1715_1191 = PROCEDURE_REF(trace_node_env_147_trace_walk, ((long) 0));
			      aux_1709 = PROCEDURE_ENTRY(fun1715_1191) (fun1715_1191, (obj_t) (node_6), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1722_1199;
		 }
	    }
	    return (node_t) (aux_1709);
	 }
      }
   }
}


/* _trace-node1814 */ obj_t 
_trace_node1814_213_trace_walk(obj_t env_1457, obj_t node_1458)
{
   {
      node_t aux_1871;
      aux_1871 = trace_node_95_trace_walk((node_t) (node_1458));
      return (obj_t) (aux_1871);
   }
}


/* trace-node-default1453 */ node_t 
trace_node_default1453_157_trace_walk(node_t node_7)
{
   return node_7;
}


/* _trace-node-default1453 */ obj_t 
_trace_node_default1453_177_trace_walk(obj_t env_1459, obj_t node_1460)
{
   {
      node_t aux_1875;
      aux_1875 = trace_node_default1453_157_trace_walk((node_t) (node_1460));
      return (obj_t) (aux_1875);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_trace_walk()
{
   module_initialization_70_tools_speek(((long) 0), "TRACE_WALK");
   module_initialization_70_tools_error(((long) 0), "TRACE_WALK");
   module_initialization_70_engine_pass(((long) 0), "TRACE_WALK");
   module_initialization_70_type_type(((long) 0), "TRACE_WALK");
   module_initialization_70_ast_var(((long) 0), "TRACE_WALK");
   module_initialization_70_ast_node(((long) 0), "TRACE_WALK");
   module_initialization_70_tools_shape(((long) 0), "TRACE_WALK");
   module_initialization_70_tools_misc(((long) 0), "TRACE_WALK");
   module_initialization_70_type_env(((long) 0), "TRACE_WALK");
   module_initialization_70_ast_sexp(((long) 0), "TRACE_WALK");
   return module_initialization_70_engine_param(((long) 0), "TRACE_WALK");
}
