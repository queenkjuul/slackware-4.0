/*===========================================================================*/
/*   (Foreign/cfun.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct calias
  {
     bool_t array__248;
  }
      *calias_t;

typedef struct cenum
  {
     struct type *btype;
     obj_t literals;
  }
     *cenum_t;

typedef struct cfunction
  {
     struct type *btype;
     long arity;
     struct type *type_res_48;
     obj_t type_args_244;
  }
         *cfunction_t;

typedef struct cptr
  {
     struct type *btype;
     struct type *point_to_164;
     bool_t array__248;
  }
    *cptr_t;

typedef struct cstruct
  {
     bool_t struct__46;
     obj_t fields;
     obj_t cstruct__170;
  }
       *cstruct_t;

typedef struct cstruct__170
  {
     struct type *btype;
     struct cstruct *cstruct;
  }
            *cstruct__170_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


static obj_t method_init_76_foreign_cfunction();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t string_append(obj_t, obj_t);
extern obj_t _max_c_foreign_arity__143_engine_param;
static obj_t make_ctype_accesses__cfunction_25_foreign_cfunction(obj_t, obj_t, obj_t);
extern obj_t string_sans___40_type_tools(obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_foreign_cfunction(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_foreign_ctype(long, char *);
extern obj_t module_initialization_70_foreign_access(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t _make_ctype_accesses_1607_16_foreign_access(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_foreign_cfunction();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t produce_module_clause__172_module_module(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_foreign_cfunction();
static obj_t toplevel_init_63_foreign_cfunction();
extern obj_t open_input_string(obj_t);
extern obj_t cfunction_foreign_ctype;
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t _4dots_199_tools_misc;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_foreign_cfunction = BUNSPEC;
static obj_t cnst_init_137_foreign_cfunction();
static obj_t __cnst[26];

DEFINE_STATIC_PROCEDURE(proc1608_foreign_cfunction, make_ctype_accesses__cfunction_25_foreign_cfunction1625, make_ctype_accesses__cfunction_25_foreign_cfunction, 0L, 2);
extern obj_t make_ctype_accesses__env_11_foreign_access;
DEFINE_STRING(string1619_foreign_cfunction, string1619_foreign_cfunction1626, "PREDICATE-OF PRAGMA ::OBJ INLINE STATIC FOREIGN SYMBOL QUOTE FOREIGN-ID EQ? O FOREIGN? IF O::OBJ PRAGMA::BOOL O2 O1 = MACRO F DEFINE-INLINE C- ::BOOL ? -> -CALL ", 161);
DEFINE_STRING(string1618_foreign_cfunction, string1618_foreign_cfunction1627, "cobj_to_foreign", 15);
DEFINE_STRING(string1617_foreign_cfunction, string1617_foreign_cfunction1628, "(", 1);
DEFINE_STRING(string1616_foreign_cfunction, string1616_foreign_cfunction1629, ")FOREIGN_TO_COBJ", 16);
DEFINE_STRING(string1615_foreign_cfunction, string1615_foreign_cfunction1630, "($1 == $2)", 10);
DEFINE_STRING(string1614_foreign_cfunction, string1614_foreign_cfunction1631, "C_FUNCTION_CALL_", 16);
DEFINE_STRING(string1613_foreign_cfunction, string1613_foreign_cfunction1632, "Can't manage pointers on C multiple arity function", 50);
DEFINE_STRING(string1612_foreign_cfunction, string1612_foreign_cfunction1633, "bigloo", 6);
DEFINE_STRING(string1611_foreign_cfunction, string1611_foreign_cfunction1634, " args provided", 14);
DEFINE_STRING(string1609_foreign_cfunction, string1609_foreign_cfunction1635, ")", 1);
DEFINE_STRING(string1610_foreign_cfunction, string1610_foreign_cfunction1636, "Too large arity for a foreign function (max", 43);


/* module-initialization */ obj_t 
module_initialization_70_foreign_cfunction(long checksum_977, char *from_978)
{
   if (CBOOL(require_initialization_114_foreign_cfunction))
     {
	require_initialization_114_foreign_cfunction = BBOOL(((bool_t) 0));
	library_modules_init_112_foreign_cfunction();
	cnst_init_137_foreign_cfunction();
	imported_modules_init_94_foreign_cfunction();
	method_init_76_foreign_cfunction();
	toplevel_init_63_foreign_cfunction();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_foreign_cfunction()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70___object(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70___r4_strings_6_7(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70___reader(((long) 0), "FOREIGN_CFUNCTION");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_foreign_cfunction()
{
   {
      obj_t cnst_port_138_969;
      cnst_port_138_969 = open_input_string(string1619_foreign_cfunction);
      {
	 long i_970;
	 i_970 = ((long) 25);
       loop_971:
	 {
	    bool_t test1620_972;
	    test1620_972 = (i_970 == ((long) -1));
	    if (test1620_972)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1621_973;
		    {
		       obj_t list1622_974;
		       {
			  obj_t arg1623_975;
			  arg1623_975 = BNIL;
			  list1622_974 = MAKE_PAIR(cnst_port_138_969, arg1623_975);
		       }
		       arg1621_973 = read___reader(list1622_974);
		    }
		    CNST_TABLE_SET(i_970, arg1621_973);
		 }
		 {
		    int aux_976;
		    {
		       long aux_999;
		       aux_999 = (i_970 - ((long) 1));
		       aux_976 = (int) (aux_999);
		    }
		    {
		       long i_1002;
		       i_1002 = (long) (aux_976);
		       i_970 = i_1002;
		       goto loop_971;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_foreign_cfunction()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_foreign_cfunction()
{
   {
      obj_t make_ctype_accesses__cfunction_25_962;
      make_ctype_accesses__cfunction_25_962 = proc1608_foreign_cfunction;
      return add_method__1___object(make_ctype_accesses__env_11_foreign_access, cfunction_foreign_ctype, make_ctype_accesses__cfunction_25_962);
   }
}


/* make-ctype-accesses!-cfunction */ obj_t 
make_ctype_accesses__cfunction_25_foreign_cfunction(obj_t env_963, obj_t what_964, obj_t who_965)
{
   {
      cfunction_t what_474;
      type_t who_475;
      what_474 = (cfunction_t) (what_964);
      who_475 = (type_t) (who_965);
      {
	 type_t btype_478;
	 {
	    obj_t aux_1005;
	    {
	       object_t aux_1006;
	       aux_1006 = (object_t) (what_474);
	       aux_1005 = OBJECT_WIDENING(aux_1006);
	    }
	    btype_478 = (((cfunction_t) CREF(aux_1005))->btype);
	 }
	 {
	    obj_t id_479;
	    id_479 = (((type_t) CREF(who_475))->id);
	    {
	       obj_t wid_480;
	       {
		  type_t obj_894;
		  obj_894 = (type_t) (what_474);
		  wid_480 = (((type_t) CREF(obj_894))->id);
	       }
	       {
		  obj_t bid_481;
		  bid_481 = (((type_t) CREF(btype_478))->id);
		  {
		     obj_t call_id_67_482;
		     {
			obj_t list1601_850;
			{
			   obj_t arg1602_851;
			   {
			      obj_t aux_1014;
			      aux_1014 = CNST_TABLE_REF(((long) 0));
			      arg1602_851 = MAKE_PAIR(aux_1014, BNIL);
			   }
			   list1601_850 = MAKE_PAIR(id_479, arg1602_851);
			}
			call_id_67_482 = symbol_append_197___r4_symbols_6_4(list1601_850);
		     }
		     {
			obj_t id__bid_132_483;
			{
			   obj_t arg1592_844;
			   arg1592_844 = CNST_TABLE_REF(((long) 1));
			   {
			      obj_t list1593_845;
			      {
				 obj_t arg1594_846;
				 {
				    obj_t arg1595_847;
				    arg1595_847 = MAKE_PAIR(bid_481, BNIL);
				    arg1594_846 = MAKE_PAIR(arg1592_844, arg1595_847);
				 }
				 list1593_845 = MAKE_PAIR(id_479, arg1594_846);
			      }
			      id__bid_132_483 = symbol_append_197___r4_symbols_6_4(list1593_845);
			   }
			}
			{
			   obj_t bid__id_105_484;
			   {
			      obj_t arg1585_839;
			      arg1585_839 = CNST_TABLE_REF(((long) 1));
			      {
				 obj_t list1586_840;
				 {
				    obj_t arg1587_841;
				    {
				       obj_t arg1588_842;
				       arg1588_842 = MAKE_PAIR(id_479, BNIL);
				       arg1587_841 = MAKE_PAIR(arg1585_839, arg1588_842);
				    }
				    list1586_840 = MAKE_PAIR(bid_481, arg1587_841);
				 }
				 bid__id_105_484 = symbol_append_197___r4_symbols_6_4(list1586_840);
			      }
			   }
			   {
			      obj_t bid__101_485;
			      {
				 obj_t list1582_836;
				 {
				    obj_t arg1583_837;
				    {
				       obj_t aux_1029;
				       aux_1029 = CNST_TABLE_REF(((long) 2));
				       arg1583_837 = MAKE_PAIR(aux_1029, BNIL);
				    }
				    list1582_836 = MAKE_PAIR(id_479, arg1583_837);
				 }
				 bid__101_485 = symbol_append_197___r4_symbols_6_4(list1582_836);
			      }
			      {
				 obj_t bid__bool_159_486;
				 {
				    obj_t list1576_832;
				    {
				       obj_t arg1578_833;
				       {
					  obj_t aux_1034;
					  aux_1034 = CNST_TABLE_REF(((long) 3));
					  arg1578_833 = MAKE_PAIR(aux_1034, BNIL);
				       }
				       list1576_832 = MAKE_PAIR(bid__101_485, arg1578_833);
				    }
				    bid__bool_159_486 = symbol_append_197___r4_symbols_6_4(list1576_832);
				 }
				 {
				    obj_t name_sans___18_488;
				    name_sans___18_488 = string_sans___40_type_tools((((type_t) CREF(who_475))->name));
				    {
				       type_t type_res_48_489;
				       {
					  obj_t aux_1041;
					  {
					     object_t aux_1042;
					     aux_1042 = (object_t) (what_474);
					     aux_1041 = OBJECT_WIDENING(aux_1042);
					  }
					  type_res_48_489 = (((cfunction_t) CREF(aux_1041))->type_res_48);
				       }
				       {
					  obj_t type_args_244_490;
					  {
					     obj_t aux_1046;
					     {
						object_t aux_1047;
						aux_1047 = (object_t) (what_474);
						aux_1046 = OBJECT_WIDENING(aux_1047);
					     }
					     type_args_244_490 = (((cfunction_t) CREF(aux_1046))->type_args_244);
					  }
					  {
					     long arity_491;
					     {
						obj_t aux_1051;
						{
						   object_t aux_1052;
						   aux_1052 = (object_t) (what_474);
						   aux_1051 = OBJECT_WIDENING(aux_1052);
						}
						arity_491 = (((cfunction_t) CREF(aux_1051))->arity);
					     }
					     {
						char *nb_args_51_492;
						nb_args_51_492 = integer__string_135___r4_numbers_6_5_fixnum(arity_491, BNIL);
						{
						   {
						      {
							 obj_t arg1213_500;
							 {
							    obj_t arg1214_501;
							    obj_t arg1216_502;
							    obj_t arg1219_503;
							    obj_t arg1220_504;
							    arg1214_501 = CNST_TABLE_REF(((long) 20));
							    {
							       obj_t arg1557_808;
							       obj_t arg1558_809;
							       arg1557_808 = CNST_TABLE_REF(((long) 7));
							       {
								  obj_t arg1568_818;
								  arg1568_818 = CNST_TABLE_REF(((long) 19));
								  {
								     obj_t list1570_820;
								     {
									obj_t arg1572_821;
									arg1572_821 = MAKE_PAIR(BNIL, BNIL);
									list1570_820 = MAKE_PAIR(id_479, arg1572_821);
								     }
								     arg1558_809 = cons__138___r4_pairs_and_lists_6_3(arg1568_818, list1570_820);
								  }
							       }
							       {
								  obj_t list1561_812;
								  {
								     obj_t arg1562_813;
								     {
									obj_t arg1563_814;
									{
									   obj_t arg1564_815;
									   {
									      obj_t arg1565_816;
									      arg1565_816 = MAKE_PAIR(BNIL, BNIL);
									      arg1564_815 = MAKE_PAIR(string1618_foreign_cfunction, arg1565_816);
									   }
									   arg1563_814 = MAKE_PAIR(arg1558_809, arg1564_815);
									}
									arg1562_813 = MAKE_PAIR(id__bid_132_483, arg1563_814);
								     }
								     list1561_812 = MAKE_PAIR(bid_481, arg1562_813);
								  }
								  arg1216_502 = cons__138___r4_pairs_and_lists_6_3(arg1557_808, list1561_812);
							       }
							    }
							    {
							       obj_t mname_788;
							       {
								  obj_t list1549_801;
								  {
								     obj_t arg1552_803;
								     {
									obj_t arg1553_804;
									arg1553_804 = MAKE_PAIR(string1616_foreign_cfunction, BNIL);
									arg1552_803 = MAKE_PAIR(name_sans___18_488, arg1553_804);
								     }
								     list1549_801 = MAKE_PAIR(string1617_foreign_cfunction, arg1552_803);
								  }
								  mname_788 = string_append_106___r4_strings_6_7(list1549_801);
							       }
							       {
								  obj_t arg1532_789;
								  obj_t arg1533_790;
								  arg1532_789 = CNST_TABLE_REF(((long) 7));
								  {
								     obj_t list1546_799;
								     list1546_799 = MAKE_PAIR(BNIL, BNIL);
								     arg1533_790 = cons__138___r4_pairs_and_lists_6_3(bid_481, list1546_799);
								  }
								  {
								     obj_t list1535_792;
								     {
									obj_t arg1536_793;
									{
									   obj_t arg1537_794;
									   {
									      obj_t arg1539_795;
									      {
										 obj_t arg1540_796;
										 arg1540_796 = MAKE_PAIR(BNIL, BNIL);
										 arg1539_795 = MAKE_PAIR(mname_788, arg1540_796);
									      }
									      arg1537_794 = MAKE_PAIR(arg1533_790, arg1539_795);
									   }
									   arg1536_793 = MAKE_PAIR(bid__id_105_484, arg1537_794);
									}
									list1535_792 = MAKE_PAIR(id_479, arg1536_793);
								     }
								     arg1219_503 = cons__138___r4_pairs_and_lists_6_3(arg1532_789, list1535_792);
								  }
							       }
							    }
							    {
							       obj_t tres_id_18_663;
							       tres_id_18_663 = (((type_t) CREF(type_res_48_489))->id);
							       {
								  obj_t targs_id_78_664;
								  if (NULLP(type_args_244_490))
								    {
								       targs_id_78_664 = BNIL;
								    }
								  else
								    {
								       obj_t head1157_682;
								       {
									  obj_t aux_1085;
									  {
									     type_t obj_948;
									     {
										obj_t aux_1086;
										aux_1086 = CAR(type_args_244_490);
										obj_948 = (type_t) (aux_1086);
									     }
									     aux_1085 = (((type_t) CREF(obj_948))->id);
									  }
									  head1157_682 = MAKE_PAIR(aux_1085, BNIL);
								       }
								       {
									  obj_t l1155_683;
									  obj_t tail1158_684;
									  l1155_683 = CDR(type_args_244_490);
									  tail1158_684 = head1157_682;
									lname1156_685:
									  if (NULLP(l1155_683))
									    {
									       targs_id_78_664 = head1157_682;
									    }
									  else
									    {
									       obj_t newtail1159_688;
									       {
										  obj_t aux_1093;
										  {
										     type_t obj_954;
										     {
											obj_t aux_1094;
											aux_1094 = CAR(l1155_683);
											obj_954 = (type_t) (aux_1094);
										     }
										     aux_1093 = (((type_t) CREF(obj_954))->id);
										  }
										  newtail1159_688 = MAKE_PAIR(aux_1093, BNIL);
									       }
									       SET_CDR(tail1158_684, newtail1159_688);
									       {
										  obj_t tail1158_1102;
										  obj_t l1155_1100;
										  l1155_1100 = CDR(l1155_683);
										  tail1158_1102 = newtail1159_688;
										  tail1158_684 = tail1158_1102;
										  l1155_683 = l1155_1100;
										  goto lname1156_685;
									       }
									    }
								       }
								    }
								  {
								     obj_t caller_name_114_665;
								     {
									obj_t aux_1104;
									aux_1104 = string_to_bstring(nb_args_51_492);
									caller_name_114_665 = string_append(string1614_foreign_cfunction, aux_1104);
								     }
								     {
									obj_t c_call_id_131_666;
									{
									   obj_t arg1399_676;
									   arg1399_676 = CNST_TABLE_REF(((long) 4));
									   {
									      obj_t list1400_677;
									      {
										 obj_t arg1401_678;
										 arg1401_678 = MAKE_PAIR(call_id_67_482, BNIL);
										 list1400_677 = MAKE_PAIR(arg1399_676, arg1401_678);
									      }
									      c_call_id_131_666 = symbol_append_197___r4_symbols_6_4(list1400_677);
									   }
									}
									{
									   {
									      obj_t arg1389_667;
									      obj_t arg1390_668;
									      arg1389_667 = CNST_TABLE_REF(((long) 7));
									      arg1390_668 = MAKE_PAIR(id_479, targs_id_78_664);
									      {
										 obj_t list1392_670;
										 {
										    obj_t arg1393_671;
										    {
										       obj_t arg1395_672;
										       {
											  obj_t arg1396_673;
											  {
											     obj_t arg1397_674;
											     arg1397_674 = MAKE_PAIR(BNIL, BNIL);
											     arg1396_673 = MAKE_PAIR(caller_name_114_665, arg1397_674);
											  }
											  arg1395_672 = MAKE_PAIR(arg1390_668, arg1396_673);
										       }
										       arg1393_671 = MAKE_PAIR(c_call_id_131_666, arg1395_672);
										    }
										    list1392_670 = MAKE_PAIR(tres_id_18_663, arg1393_671);
										 }
										 arg1220_504 = cons__138___r4_pairs_and_lists_6_3(arg1389_667, list1392_670);
									      }
									   }
									}
								     }
								  }
							       }
							    }
							    {
							       obj_t list1222_506;
							       {
								  obj_t arg1224_507;
								  {
								     obj_t arg1225_508;
								     {
									obj_t arg1226_509;
									arg1226_509 = MAKE_PAIR(BNIL, BNIL);
									arg1225_508 = MAKE_PAIR(arg1220_504, arg1226_509);
								     }
								     arg1224_507 = MAKE_PAIR(arg1219_503, arg1225_508);
								  }
								  list1222_506 = MAKE_PAIR(arg1216_502, arg1224_507);
							       }
							       arg1213_500 = cons__138___r4_pairs_and_lists_6_3(arg1214_501, list1222_506);
							    }
							 }
							 produce_module_clause__172_module_module(arg1213_500);
						      }
						      {
							 obj_t arg1231_511;
							 {
							    obj_t arg1232_512;
							    obj_t arg1233_513;
							    arg1232_512 = CNST_TABLE_REF(((long) 21));
							    {
							       obj_t arg1240_518;
							       obj_t arg1241_519;
							       arg1240_518 = CNST_TABLE_REF(((long) 22));
							       arg1241_519 = CNST_TABLE_REF(((long) 23));
							       {
								  obj_t list1244_521;
								  {
								     obj_t arg1245_522;
								     {
									obj_t arg1247_523;
									arg1247_523 = MAKE_PAIR(BNIL, BNIL);
									arg1245_522 = MAKE_PAIR(arg1241_519, arg1247_523);
								     }
								     list1244_521 = MAKE_PAIR(bid__bool_159_486, arg1245_522);
								  }
								  arg1233_513 = cons__138___r4_pairs_and_lists_6_3(arg1240_518, list1244_521);
							       }
							    }
							    {
							       obj_t list1235_515;
							       {
								  obj_t arg1236_516;
								  arg1236_516 = MAKE_PAIR(BNIL, BNIL);
								  list1235_515 = MAKE_PAIR(arg1233_513, arg1236_516);
							       }
							       arg1231_511 = cons__138___r4_pairs_and_lists_6_3(arg1232_512, list1235_515);
							    }
							 }
							 produce_module_clause__172_module_module(arg1231_511);
						      }
						      {
							 obj_t arg1250_525;
							 {
							    obj_t arg1251_526;
							    obj_t arg1252_527;
							    arg1251_526 = CNST_TABLE_REF(((long) 24));
							    {
							       obj_t arg1257_532;
							       {
								  obj_t arg1263_537;
								  arg1263_537 = CNST_TABLE_REF(((long) 25));
								  {
								     obj_t list1266_539;
								     {
									obj_t arg1267_540;
									arg1267_540 = MAKE_PAIR(BNIL, BNIL);
									list1266_539 = MAKE_PAIR(wid_480, arg1267_540);
								     }
								     arg1257_532 = cons__138___r4_pairs_and_lists_6_3(arg1263_537, list1266_539);
								  }
							       }
							       {
								  obj_t list1259_534;
								  {
								     obj_t arg1260_535;
								     arg1260_535 = MAKE_PAIR(BNIL, BNIL);
								     list1259_534 = MAKE_PAIR(arg1257_532, arg1260_535);
								  }
								  arg1252_527 = cons__138___r4_pairs_and_lists_6_3(bid__101_485, list1259_534);
							       }
							    }
							    {
							       obj_t list1254_529;
							       {
								  obj_t arg1255_530;
								  arg1255_530 = MAKE_PAIR(BNIL, BNIL);
								  list1254_529 = MAKE_PAIR(arg1252_527, arg1255_530);
							       }
							       arg1250_525 = cons__138___r4_pairs_and_lists_6_3(arg1251_526, list1254_529);
							    }
							 }
							 produce_module_clause__172_module_module(arg1250_525);
						      }
						      {
							 obj_t arg1269_542;
							 obj_t arg1270_543;
							 obj_t arg1272_544;
							 {
							    obj_t arg1475_740;
							    obj_t arg1476_741;
							    obj_t arg1477_742;
							    arg1475_740 = CNST_TABLE_REF(((long) 5));
							    {
							       obj_t arg1484_748;
							       arg1484_748 = CNST_TABLE_REF(((long) 12));
							       {
								  obj_t list1486_750;
								  {
								     obj_t arg1487_751;
								     arg1487_751 = MAKE_PAIR(BNIL, BNIL);
								     list1486_750 = MAKE_PAIR(arg1484_748, arg1487_751);
								  }
								  arg1476_741 = cons__138___r4_pairs_and_lists_6_3(bid__bool_159_486, list1486_750);
							       }
							    }
							    {
							       obj_t arg1489_753;
							       obj_t arg1490_754;
							       obj_t arg1491_755;
							       arg1489_753 = CNST_TABLE_REF(((long) 13));
							       {
								  obj_t arg1500_762;
								  obj_t arg1501_763;
								  arg1500_762 = CNST_TABLE_REF(((long) 14));
								  arg1501_763 = CNST_TABLE_REF(((long) 15));
								  {
								     obj_t list1503_765;
								     {
									obj_t arg1504_766;
									arg1504_766 = MAKE_PAIR(BNIL, BNIL);
									list1503_765 = MAKE_PAIR(arg1501_763, arg1504_766);
								     }
								     arg1490_754 = cons__138___r4_pairs_and_lists_6_3(arg1500_762, list1503_765);
								  }
							       }
							       {
								  obj_t arg1507_768;
								  obj_t arg1510_769;
								  obj_t arg1511_770;
								  arg1507_768 = CNST_TABLE_REF(((long) 16));
								  {
								     obj_t arg1518_776;
								     obj_t arg1519_777;
								     arg1518_776 = CNST_TABLE_REF(((long) 17));
								     arg1519_777 = CNST_TABLE_REF(((long) 15));
								     {
									obj_t list1523_779;
									{
									   obj_t arg1524_780;
									   arg1524_780 = MAKE_PAIR(BNIL, BNIL);
									   list1523_779 = MAKE_PAIR(arg1519_777, arg1524_780);
									}
									arg1510_769 = cons__138___r4_pairs_and_lists_6_3(arg1518_776, list1523_779);
								     }
								  }
								  {
								     obj_t arg1526_782;
								     arg1526_782 = CNST_TABLE_REF(((long) 18));
								     {
									obj_t list1528_784;
									{
									   obj_t arg1529_785;
									   arg1529_785 = MAKE_PAIR(BNIL, BNIL);
									   list1528_784 = MAKE_PAIR(bid_481, arg1529_785);
									}
									arg1511_770 = cons__138___r4_pairs_and_lists_6_3(arg1526_782, list1528_784);
								     }
								  }
								  {
								     obj_t list1514_772;
								     {
									obj_t arg1515_773;
									{
									   obj_t arg1516_774;
									   arg1516_774 = MAKE_PAIR(BNIL, BNIL);
									   arg1515_773 = MAKE_PAIR(arg1511_770, arg1516_774);
									}
									list1514_772 = MAKE_PAIR(arg1510_769, arg1515_773);
								     }
								     arg1491_755 = cons__138___r4_pairs_and_lists_6_3(arg1507_768, list1514_772);
								  }
							       }
							       {
								  obj_t list1495_757;
								  {
								     obj_t arg1496_758;
								     {
									obj_t arg1497_759;
									{
									   obj_t arg1498_760;
									   arg1498_760 = MAKE_PAIR(BNIL, BNIL);
									   arg1497_759 = MAKE_PAIR(BFALSE, arg1498_760);
									}
									arg1496_758 = MAKE_PAIR(arg1491_755, arg1497_759);
								     }
								     list1495_757 = MAKE_PAIR(arg1490_754, arg1496_758);
								  }
								  arg1477_742 = cons__138___r4_pairs_and_lists_6_3(arg1489_753, list1495_757);
							       }
							    }
							    {
							       obj_t list1479_744;
							       {
								  obj_t arg1480_745;
								  {
								     obj_t arg1481_746;
								     arg1481_746 = MAKE_PAIR(BNIL, BNIL);
								     arg1480_745 = MAKE_PAIR(arg1477_742, arg1481_746);
								  }
								  list1479_744 = MAKE_PAIR(arg1476_741, arg1480_745);
							       }
							       arg1269_542 = cons__138___r4_pairs_and_lists_6_3(arg1475_740, list1479_744);
							    }
							 }
							 {
							    obj_t arg1417_697;
							    obj_t arg1418_698;
							    obj_t arg1419_699;
							    arg1417_697 = CNST_TABLE_REF(((long) 5));
							    {
							       obj_t arg1428_705;
							       obj_t arg1431_706;
							       obj_t arg1432_707;
							       {
								  obj_t arg1440_713;
								  arg1440_713 = CNST_TABLE_REF(((long) 8));
								  {
								     obj_t list1442_715;
								     {
									obj_t arg1443_716;
									{
									   obj_t arg1444_717;
									   {
									      obj_t aux_1184;
									      aux_1184 = CNST_TABLE_REF(((long) 3));
									      arg1444_717 = MAKE_PAIR(aux_1184, BNIL);
									   }
									   arg1443_716 = MAKE_PAIR(id_479, arg1444_717);
									}
									list1442_715 = MAKE_PAIR(arg1440_713, arg1443_716);
								     }
								     arg1428_705 = symbol_append_197___r4_symbols_6_4(list1442_715);
								  }
							       }
							       {
								  obj_t arg1448_719;
								  arg1448_719 = CNST_TABLE_REF(((long) 9));
								  {
								     obj_t list1449_720;
								     {
									obj_t arg1450_721;
									{
									   obj_t arg1453_722;
									   arg1453_722 = MAKE_PAIR(id_479, BNIL);
									   arg1450_721 = MAKE_PAIR(_4dots_199_tools_misc, arg1453_722);
									}
									list1449_720 = MAKE_PAIR(arg1448_719, arg1450_721);
								     }
								     arg1431_706 = symbol_append_197___r4_symbols_6_4(list1449_720);
								  }
							       }
							       {
								  obj_t arg1455_724;
								  arg1455_724 = CNST_TABLE_REF(((long) 10));
								  {
								     obj_t list1456_725;
								     {
									obj_t arg1458_726;
									{
									   obj_t arg1460_727;
									   arg1460_727 = MAKE_PAIR(id_479, BNIL);
									   arg1458_726 = MAKE_PAIR(_4dots_199_tools_misc, arg1460_727);
									}
									list1456_725 = MAKE_PAIR(arg1455_724, arg1458_726);
								     }
								     arg1432_707 = symbol_append_197___r4_symbols_6_4(list1456_725);
								  }
							       }
							       {
								  obj_t list1434_709;
								  {
								     obj_t arg1436_710;
								     {
									obj_t arg1437_711;
									arg1437_711 = MAKE_PAIR(BNIL, BNIL);
									arg1436_710 = MAKE_PAIR(arg1432_707, arg1437_711);
								     }
								     list1434_709 = MAKE_PAIR(arg1431_706, arg1436_710);
								  }
								  arg1418_698 = cons__138___r4_pairs_and_lists_6_3(arg1428_705, list1434_709);
							       }
							    }
							    {
							       obj_t arg1463_729;
							       obj_t arg1465_731;
							       obj_t arg1466_732;
							       arg1463_729 = CNST_TABLE_REF(((long) 11));
							       arg1465_731 = CNST_TABLE_REF(((long) 9));
							       arg1466_732 = CNST_TABLE_REF(((long) 10));
							       {
								  obj_t list1468_734;
								  {
								     obj_t arg1469_735;
								     {
									obj_t arg1470_736;
									{
									   obj_t arg1471_737;
									   arg1471_737 = MAKE_PAIR(BNIL, BNIL);
									   arg1470_736 = MAKE_PAIR(arg1466_732, arg1471_737);
									}
									arg1469_735 = MAKE_PAIR(arg1465_731, arg1470_736);
								     }
								     list1468_734 = MAKE_PAIR(string1615_foreign_cfunction, arg1469_735);
								  }
								  arg1419_699 = cons__138___r4_pairs_and_lists_6_3(arg1463_729, list1468_734);
							       }
							    }
							    {
							       obj_t list1422_701;
							       {
								  obj_t arg1423_702;
								  {
								     obj_t arg1426_703;
								     arg1426_703 = MAKE_PAIR(BNIL, BNIL);
								     arg1423_702 = MAKE_PAIR(arg1419_699, arg1426_703);
								  }
								  list1422_701 = MAKE_PAIR(arg1418_698, arg1423_702);
							       }
							       arg1270_543 = cons__138___r4_pairs_and_lists_6_3(arg1417_697, list1422_701);
							    }
							 }
							 {
							    bool_t test1371_648;
							    {
							       long n2_942;
							       n2_942 = (long) CINT(_max_c_foreign_arity__143_engine_param);
							       test1371_648 = (arity_491 >= n2_942);
							    }
							    if (test1371_648)
							      {
								 {
								    obj_t arg1372_649;
								    obj_t arg1373_650;
								    {
								       char *arg1378_653;
								       arg1378_653 = integer__string_135___r4_numbers_6_5_fixnum((long) CINT(_max_c_foreign_arity__143_engine_param), BNIL);
								       {
									  obj_t list1380_655;
									  {
									     obj_t arg1381_656;
									     {
										obj_t arg1383_657;
										arg1383_657 = MAKE_PAIR(string1609_foreign_cfunction, BNIL);
										{
										   obj_t aux_1222;
										   aux_1222 = string_to_bstring(arg1378_653);
										   arg1381_656 = MAKE_PAIR(aux_1222, arg1383_657);
										}
									     }
									     list1380_655 = MAKE_PAIR(string1610_foreign_cfunction, arg1381_656);
									  }
									  arg1372_649 = string_append_106___r4_strings_6_7(list1380_655);
								       }
								    }
								    {
								       obj_t aux_1227;
								       aux_1227 = string_to_bstring(nb_args_51_492);
								       arg1373_650 = string_append(aux_1227, string1611_foreign_cfunction);
								    }
								    arg1272_544 = user_error_151_tools_error(id_479, arg1372_649, arg1373_650, BNIL);
								 }
							      }
							    else
							      {
								 if ((arity_491 >= ((long) 0)))
								   {
								      {
									 obj_t tres_id_18_550;
									 tres_id_18_550 = (((type_t) CREF(type_res_48_489))->id);
									 {
									    obj_t targs_id_78_551;
									    if (NULLP(type_args_244_490))
									      {
										 targs_id_78_551 = BNIL;
									      }
									    else
									      {
										 obj_t head1162_633;
										 {
										    obj_t aux_1236;
										    {
										       type_t obj_904;
										       {
											  obj_t aux_1237;
											  aux_1237 = CAR(type_args_244_490);
											  obj_904 = (type_t) (aux_1237);
										       }
										       aux_1236 = (((type_t) CREF(obj_904))->id);
										    }
										    head1162_633 = MAKE_PAIR(aux_1236, BNIL);
										 }
										 {
										    obj_t l1160_634;
										    obj_t tail1163_635;
										    l1160_634 = CDR(type_args_244_490);
										    tail1163_635 = head1162_633;
										  lname1161_636:
										    if (NULLP(l1160_634))
										      {
											 targs_id_78_551 = head1162_633;
										      }
										    else
										      {
											 obj_t newtail1164_639;
											 {
											    obj_t aux_1244;
											    {
											       type_t obj_910;
											       {
												  obj_t aux_1245;
												  aux_1245 = CAR(l1160_634);
												  obj_910 = (type_t) (aux_1245);
											       }
											       aux_1244 = (((type_t) CREF(obj_910))->id);
											    }
											    newtail1164_639 = MAKE_PAIR(aux_1244, BNIL);
											 }
											 SET_CDR(tail1163_635, newtail1164_639);
											 {
											    obj_t tail1163_1253;
											    obj_t l1160_1251;
											    l1160_1251 = CDR(l1160_634);
											    tail1163_1253 = newtail1164_639;
											    tail1163_635 = tail1163_1253;
											    l1160_634 = l1160_1251;
											    goto lname1161_636;
											 }
										      }
										 }
									      }
									    {
									       obj_t args_552;
									       if (NULLP(targs_id_78_551))
										 {
										    args_552 = BNIL;
										 }
									       else
										 {
										    obj_t head1167_617;
										    {
										       obj_t arg1352_628;
										       arg1352_628 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CAR(targs_id_78_551), BEOA);
										       head1167_617 = MAKE_PAIR(arg1352_628, BNIL);
										    }
										    {
										       obj_t l1165_618;
										       obj_t tail1168_619;
										       l1165_618 = CDR(targs_id_78_551);
										       tail1168_619 = head1167_617;
										     lname1166_620:
										       if (NULLP(l1165_618))
											 {
											    args_552 = head1167_617;
											 }
										       else
											 {
											    obj_t newtail1169_623;
											    {
											       obj_t arg1349_625;
											       arg1349_625 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CAR(l1165_618), BEOA);
											       newtail1169_623 = MAKE_PAIR(arg1349_625, BNIL);
											    }
											    SET_CDR(tail1168_619, newtail1169_623);
											    {
											       obj_t tail1168_1270;
											       obj_t l1165_1268;
											       l1165_1268 = CDR(l1165_618);
											       tail1168_1270 = newtail1169_623;
											       tail1168_619 = tail1168_1270;
											       l1165_618 = l1165_1268;
											       goto lname1166_620;
											    }
											 }
										    }
										 }
									       {
										  obj_t c_call_id_131_553;
										  {
										     obj_t arg1339_611;
										     arg1339_611 = CNST_TABLE_REF(((long) 4));
										     {
											obj_t list1340_612;
											{
											   obj_t arg1342_613;
											   arg1342_613 = MAKE_PAIR(call_id_67_482, BNIL);
											   list1340_612 = MAKE_PAIR(arg1339_611, arg1342_613);
											}
											c_call_id_131_553 = symbol_append_197___r4_symbols_6_4(list1340_612);
										     }
										  }
										  {
										     {
											obj_t arg1281_554;
											obj_t arg1282_555;
											obj_t arg1283_556;
											arg1281_554 = CNST_TABLE_REF(((long) 5));
											{
											   obj_t arg1290_562;
											   obj_t arg1291_563;
											   obj_t arg1292_564;
											   {
											      obj_t list1296_568;
											      {
												 obj_t arg1297_569;
												 {
												    obj_t arg1298_570;
												    arg1298_570 = MAKE_PAIR(tres_id_18_550, BNIL);
												    arg1297_569 = MAKE_PAIR(_4dots_199_tools_misc, arg1298_570);
												 }
												 list1296_568 = MAKE_PAIR(call_id_67_482, arg1297_569);
											      }
											      arg1290_562 = symbol_append_197___r4_symbols_6_4(list1296_568);
											   }
											   {
											      obj_t arg1300_572;
											      arg1300_572 = CNST_TABLE_REF(((long) 6));
											      {
												 obj_t list1301_573;
												 {
												    obj_t arg1302_574;
												    {
												       obj_t arg1303_575;
												       arg1303_575 = MAKE_PAIR(id_479, BNIL);
												       arg1302_574 = MAKE_PAIR(_4dots_199_tools_misc, arg1303_575);
												    }
												    list1301_573 = MAKE_PAIR(arg1300_572, arg1302_574);
												 }
												 arg1291_563 = symbol_append_197___r4_symbols_6_4(list1301_573);
											      }
											   }
											   {
											      obj_t arg1307_577;
											      obj_t arg1308_578;
											      if (NULLP(args_552))
												{
												   arg1307_577 = BNIL;
												}
											      else
												{
												   obj_t head1172_582;
												   head1172_582 = MAKE_PAIR(BNIL, BNIL);
												   {
												      obj_t ll1170_583;
												      obj_t ll1171_584;
												      obj_t tail1173_585;
												      ll1170_583 = args_552;
												      ll1171_584 = targs_id_78_551;
												      tail1173_585 = head1172_582;
												    lname1175_586:
												      if (NULLP(ll1170_583))
													{
													   arg1307_577 = CDR(head1172_582);
													}
												      else
													{
													   obj_t newtail1174_588;
													   {
													      obj_t arg1315_591;
													      {
														 obj_t arg_593;
														 arg_593 = CAR(ll1170_583);
														 {
														    obj_t list1317_595;
														    {
														       obj_t arg1319_596;
														       {
															  obj_t arg1321_597;
															  {
															     obj_t aux_1293;
															     aux_1293 = CAR(ll1171_584);
															     arg1321_597 = MAKE_PAIR(aux_1293, BNIL);
															  }
															  arg1319_596 = MAKE_PAIR(_4dots_199_tools_misc, arg1321_597);
														       }
														       list1317_595 = MAKE_PAIR(arg_593, arg1319_596);
														    }
														    arg1315_591 = symbol_append_197___r4_symbols_6_4(list1317_595);
														 }
													      }
													      newtail1174_588 = MAKE_PAIR(arg1315_591, BNIL);
													   }
													   SET_CDR(tail1173_585, newtail1174_588);
													   {
													      obj_t tail1173_1305;
													      obj_t ll1171_1303;
													      obj_t ll1170_1301;
													      ll1170_1301 = CDR(ll1170_583);
													      ll1171_1303 = CDR(ll1171_584);
													      tail1173_1305 = newtail1174_588;
													      tail1173_585 = tail1173_1305;
													      ll1171_584 = ll1171_1303;
													      ll1170_583 = ll1170_1301;
													      goto lname1175_586;
													   }
													}
												   }
												}
											      arg1308_578 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
											      arg1292_564 = append_2_18___r4_pairs_and_lists_6_3(arg1307_577, arg1308_578);
											   }
											   {
											      obj_t list1293_565;
											      {
												 obj_t arg1294_566;
												 arg1294_566 = MAKE_PAIR(arg1292_564, BNIL);
												 list1293_565 = MAKE_PAIR(arg1291_563, arg1294_566);
											      }
											      arg1282_555 = cons__138___r4_pairs_and_lists_6_3(arg1290_562, list1293_565);
											   }
											}
											{
											   obj_t arg1328_603;
											   obj_t arg1330_604;
											   arg1328_603 = CNST_TABLE_REF(((long) 6));
											   {
											      obj_t arg1334_608;
											      arg1334_608 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
											      arg1330_604 = append_2_18___r4_pairs_and_lists_6_3(args_552, arg1334_608);
											   }
											   {
											      obj_t list1331_605;
											      {
												 obj_t arg1332_606;
												 arg1332_606 = MAKE_PAIR(arg1330_604, BNIL);
												 list1331_605 = MAKE_PAIR(arg1328_603, arg1332_606);
											      }
											      arg1283_556 = cons__138___r4_pairs_and_lists_6_3(c_call_id_131_553, list1331_605);
											   }
											}
											{
											   obj_t list1285_558;
											   {
											      obj_t arg1286_559;
											      {
												 obj_t arg1287_560;
												 arg1287_560 = MAKE_PAIR(BNIL, BNIL);
												 arg1286_559 = MAKE_PAIR(arg1283_556, arg1287_560);
											      }
											      list1285_558 = MAKE_PAIR(arg1282_555, arg1286_559);
											   }
											   arg1272_544 = cons__138___r4_pairs_and_lists_6_3(arg1281_554, list1285_558);
											}
										     }
										  }
									       }
									    }
									 }
								      }
								   }
								 else
								   {
								      arg1272_544 = user_error_151_tools_error(string1612_foreign_cfunction, string1613_foreign_cfunction, id_479, BNIL);
								   }
							      }
							 }
							 {
							    obj_t list1273_545;
							    {
							       obj_t arg1274_546;
							       {
								  obj_t arg1277_547;
								  arg1277_547 = MAKE_PAIR(arg1272_544, BNIL);
								  arg1274_546 = MAKE_PAIR(arg1270_543, arg1277_547);
							       }
							       list1273_545 = MAKE_PAIR(arg1269_542, arg1274_546);
							    }
							    return list1273_545;
							 }
						      }
						   }
						}
					     }
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_foreign_cfunction()
{
   module_initialization_70_tools_error(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70_tools_misc(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70_type_tools(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70_type_type(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70_foreign_ctype(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70_foreign_access(((long) 0), "FOREIGN_CFUNCTION");
   module_initialization_70_module_module(((long) 0), "FOREIGN_CFUNCTION");
   return module_initialization_70_engine_param(((long) 0), "FOREIGN_CFUNCTION");
}
