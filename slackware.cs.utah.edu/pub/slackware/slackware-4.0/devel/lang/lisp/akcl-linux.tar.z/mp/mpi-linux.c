
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*~									~*/
/*~		       OPERATIONS DE BASE (NOYAU)			~*/
/*~									~*/
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/* MODIFIED by M. Frigo (7 Mar 1993) to work with the akcl port
 * of linux.
 */

#ifdef linux
# include "genpari.h"

/* +2147483648 */

ulong ABS_MOST_NEGS[3]={0x01ff0003, 0x01000003,1<<31};
#define adecaler(x,tetpil,anavma) (RAVYZARC=(GEN)(x),((RAVYZARC>=(GEN)anavma)&&(RAVYZARC<(GEN)tetpil)))

GEN   mulsi(x,y)
     long x;
     GEN y;
{
  long s=signe(y),ly=lgef(y),i;
  GEN z;
  
  if((!x)||(!s)) return gzero;
  if(x<0) {s= -s;x= -x;}
  z=cgeti(ly+1);hiremainder=0;
  for(i=ly-1;i>=2;i--) z[i+1]=addmul(x,y[i]);
  if(hiremainder) {z[2]=hiremainder;setlgef(z,ly+1);}
  else {avma+=4;z[1]=z[0]-1;z++;setlgef(z,ly);}
  setsigne(z,s);return z;
}

GEN stoi(x)
     long x;
{
  GEN y;
  
  if(!x) return gzero;
  y=cgeti(3);
  if(x>0) {y[1]=0x1000003;y[2]=x;}
  else{y[1]=0xff000003;y[2]= -x;}
  return y;
}

GEN cgetg(x,y)
     long x,y;
{
  unsigned long p1;
  GEN z;
  
  p1=avma-(((unsigned short)x)<<2);if(p1<bot) err(errpile);
  avma=p1;z=(GEN)p1;z[0]=0x10000+x+(y<<24);
  return z;
}

GEN cgeti(x)
     long x;
{
  unsigned long p1;
  GEN z;
  
  p1=avma-4*x;if(p1<bot) err(errpile);
  avma=p1;z=(GEN)p1;z[0]=0x1010000+x;
  return z;
}

GEN cgetr(x)
     long x;
{
  unsigned long p1;
  GEN z;
  
  p1=avma-4*x;if(p1<bot) err(errpile);
  avma=p1;z=(GEN)p1;z[0]=0x2010000+x;
  return z;
}

GEN icopy(x)
     GEN x;
{
  GEN y;
  long lx=lgef(x),i;
  
  y=cgeti(lx);
  for(i=1;i<lx;i++) y[i]=x[i];
  return y;
}

GEN rcopy(x)
     GEN x;
{
  GEN y;
  long lx=lg(x),i;
  
  y=cgetr(lx);
  for(i=1;i<lx;i++) y[i]=x[i];
  return y;
}


GEN negi(x)
     GEN x;
{
  long s=signe(x);
  GEN y;
  
  if(!s) return gzero;
  y=icopy(x);setsigne(y,-s);
  return y;
}

GEN negr(x)
     GEN x;
{
  GEN y;
  
  y=rcopy(x);setsigne(y,-signe(x));
  return y;
}


GEN absi(x)
     GEN x;
{
  GEN y;
  long s=signe(x);
  
  if(!s) return gzero;
  y=icopy(x);setsigne(y,1);return y;
}

GEN absr(x)
     GEN x;
{
  GEN y;
  long s=signe(x);
  
  y=rcopy(x);
  if(s) setsigne(y,1);
  return y;
}

int expi(x)
     GEN x;
{
  long lx=x[1]&0xffff;
  
  return lx==2 ? -8388608 : ((lx-2)<<5)-bfffo(x[2])-1;
}

long itos(x)
     GEN x;
{
  long s=signe(x),p2;
  unsigned long p1;
  
  if(!s) return 0;
  if(lgef(x)>3) err(affer2);
  p1=x[2];if(p1>=0x80000000) err(affer2);
  p2=(s>0)?p1:(-((long)p1));return p2;
}

void mpaff(x,y)
     GEN x,y;
{
  long tx=typ(x),ty=typ(y);
  if(tx==1)
    {
      if(ty==1) affii(x,y);else affir(x,y);
    }
  else
    {
      if(ty==1) affri(x,y);else affrr(x,y);
    }
}

void affsi(s,x)
     long s;
     GEN x;
{
  long lx;
  
  if(!s) {x[1]=2;return;}
  lx=lg(x);if(lx<3) err(affer1);
  if(s>0) {x[1]=0x1000003;x[2]=s;}
  else {x[1]=0xff000003;x[2]= -s;}
}

void affsr(s,x)
     long s;
     GEN x;
{
  long l,i,d;
  
  if(!s)
    {
      l=((x[0]&0xffff)-2)<<5;x[1]=0x800000-l;x[2]=0;
    }
  else
    {
      d=1;if(s<0) {d= -1;s= -s;}
      l=bfffo(s);setexpo(x,31-l);setsigne(x,d);
      x[2]=(s<<l);for(i=3;i<lg(x);i++) x[i]=0;
    }
}

void affii(x,y)
     GEN x,y;
{
  long lx=lgef(x),i;
  
  if(x==y) return;
  if(lg(y)<lx) err(affer3);
  for(i=1;i<lx;i++) y[i]=x[i];
}

void affir(x,y)
     GEN x,y;
{
  long lx=lgef(x),ly=lg(y),s,i,l,k;
  
  s=signe(x);
  if(!s)
    {
      y[1]=0x800000-((ly-2)<<5);y[2]=0;
    }
  else
    {
      setsigne(y,s);l=((x[1]&0xffff)-2)<<5;s=bfffo(x[2]);
      if(s)
	{
	  setexpo(y,l-s-1);
	  if(lx<=ly)
	    {
	      for(i=lx;i<ly;i++) y[i]=0;k=0;
	      for(i=lx-1;i>=2;i--) {y[i]=shiftl(x[i],s)+k;k=hiremainder;}
	    }
	  else
	    {
	      shiftl(x[ly],s);k=hiremainder;
	      for(i=ly-1;i>=2;i--) {y[i]=shiftl(x[i],s)+k;k=hiremainder;}
	    }
	}
      else
	{
	  setexpo(y,l-1);
	  if(lx<=ly)
	    {
	      for(i=lx;i<ly;i++) y[i]=0;
	      for(i=lx-1;i>=2;i--) y[i]=x[i];
	    }
	  else for(i=ly-1;i>=2;i--) y[i]=x[i];
	}
    }
}

void affrr(x,y)
     GEN x,y;
{
  long lx=lg(x),ly=lg(y),i;
  
  if(x==y) return;
  y[1]=x[1];
  if(!(x[1]&0xff000000)) y[2]=0;
  else
    {
      if(lx<=ly)
	{
	  for(i=2;i<lx;i++) y[i]=x[i];
	  for(i=lx;i<ly;i++) y[i]=0;
	}
      else for(i=2;i<ly;i++) y[i]=x[i];
    }
}

GEN shifts(x,y)
     long x,y;
{
  long t[3];
  
  if(!x) return gzero;
  t[0]=0x1010003;
  if(x>0) {t[1]=0x1000003;t[2]=x;}
  else {t[1]=0xff000003;t[2]= -x;}
  return shifti(t,y);
}

GEN shifti(x,n)
     GEN x;
     long n;
{
  long lx=lgef(x),i,s=signe(x),d,m,p1,p2,k;
  GEN y;
  
  if(!s) return gzero;
  if(!n) return icopy(x);
  if(n>0)
    {
      d=n>>5;m=n&31;
      if(m)
	{
	  p1=shiftl(x[2],m);p2=hiremainder;k=0;
	  if(p2)
	    {
	      y=cgeti(lx+d+1);for(i=lx+1;i<=lx+d;i++) y[i]=0;
	      for(i=lx;i>=4;i--) {y[i]=shiftl(x[i-1],m)+k;k=hiremainder;}
	      y[3]=p1+k;y[2]=p2;
	    }
	  else
	    {
	      y=cgeti(lx+d);for(i=lx;i<lx+d;i++) y[i]=0;
	      for(i=lx-1;i>=3;i--) {y[i]=shiftl(x[i],m)+k;k=hiremainder;}
	      y[2]=p1+k;
	    }
	}
      else
	{
	  y=cgeti(lx+d);for(i=lx;i<lx+d;i++) y[i]=0;
	  for(i=lx-1;i>=2;i--) y[i]=x[i];
	}
    }
  else
    {
      n= -n;d=n>>5;m=n&31;if(lx<d+3) return gzero;
      if(!m)
	{
	  y=cgeti(lx-d);for(i=2;i<lx-d;i++) y[i]=x[i];
	}
      else 
	{
	  m=32-m;d++;
	  p1=shiftl(x[2],m);
	  if(hiremainder)
	    {
	      y=cgeti(lx-d+1);y[2]=hiremainder;
	      for(i=3;i<=lx-d;i++)
		{
		  p2=shiftl(x[i],m);y[i]=p1+hiremainder;p1=p2;
		}
	    }
	  else
	    {
	      if(lx==d+2) return gzero;
	      y=cgeti(lx-d);
	      for(i=3;i<=lx-d;i++) 
		{
		  p2=shiftl(x[i],m);y[i-1]=p1+hiremainder;p1=p2;
		}
	    }
	}
    }   
  y[1]=y[0];setsigne(y,s);return y;
}

GEN shiftr(x,n)
     GEN x;
     long n;
{
  long l;
  GEN y;
  
  y=rcopy(x);l=expo(x)+n;
  if(l>0x7fffff||l<-0x800000) err(shier2);
  setexpo(y,l);return y;
}

GEN mptrunc(x)
     GEN x;
{
  long e,i,s,lx=lg(x),p1,p2,m;
  unsigned long d;
  GEN y;
  
  if(typ(x)==1) return icopy(x);
  s=signe(x);if(!s) return gzero;
  e=expo(x);if(e<0) return gzero;
  d=e>>5;m=e&31;if(d>=lx-2) err(truer2);
  y=cgeti(d+3);y[1]=y[0];setsigne(y,s);
  if(m==31) for(i=2;i<=d+2;i++) y[i]=x[i];
  else
    {
      m++;p1=0;
      for(i=2;i<=d+2;i++)
	{
	  p2=shiftl(x[i],m);y[i]=hiremainder+p1;p1=p2;
	}
    }
  return y;
}

GEN mpent(x)
     GEN x;
{
  long e,i,lx=lg(x),m,f,p1,p2;
  unsigned long d;
  GEN y,z;
  
  if(typ(x)==1) return icopy(x);
  if(signe(x)>=0) return mptrunc(x);
  e=expo(x);if(e<0) {y=cgeti(3);y[2]=1;y[1]=0xff000003;return y;}
  d=e>>5;m=e&31;if(d>=lx-2) err(truer2);
  y=cgeti(d+3);y[1]=0xff000003+d;
  if(m==31) 
    {
      for(i=2;i<=d+2;i++) y[i]=x[i];
      while((i<lx)&&(!x[i])) i++;
      f=(i<lx);
    }    
  else
    {
      m++;p1=0;
      for(i=2;i<=d+2;i++)
	{
	  p2=shiftl(x[i],m);y[i]=hiremainder+p1;p1=p2;
	}
      if(p1) f=1;
      else
	{
	  while((i<lx)&&(!x[i])) i++;
	  f=(i<lx);
	}
    }
  if(f)
    {
      for(i=d+2;(i>=2)&&(y[i]==0xffffffff);i--) y[i]=0;
      if(i>=2) y[i]++;
      else
	{
	  z=y;y=cgeti(1);*y=(*z)+1;y[1]=z[1]+1;
	}
    }
  return y;
}

int mpcmp(x,y)
     GEN x,y;
{
  if(typ(x)==1) return (typ(y)==1) ? cmpii(x,y) : cmpir(x,y);
  return (typ(y)==1) ? -cmpir(y,x) : cmprr(x,y);
}

int cmpsi(x,y)
     long x;
     GEN y;
{
  ulong p;
  
  if(!x) return -signe(y);
  if(x>0)
    {
      if(signe(y)<=0) return 1;
      if(lgef(y)>3) return -1;
      p=y[2];if(p==x) return 0;
      return (p<(ulong)x) ? 1 : -1;
    }
  else
    {
      if(signe(y)>=0) return -1;
      if(lgef(y)>3) return 1;
      p=y[2];if(p== -x) return 0;
      return (p<(ulong)(-x)) ? -1 : 1;
    }
}

int cmpsr(x,y)
     long x;
     GEN y;      
{
  int p;
  long av;
  GEN z;
  
  if(!x) return -signe(y);
  av=avma;z=cgetr(3);affsr(x,z);
  p=cmprr(z,y);avma=av;return p;
}	

int cmpii(x,y)
     GEN x,y;
{
  long sx=signe(x),sy=signe(y),lx,ly,i;
  
  if(sx<sy) return -1;
  if(sx>sy) return 1;
  if(!sx) return 0;
  lx=lgef(x);ly=lgef(y);
  if(lx>ly) return sx;
  if(lx<ly) return -sx;
  for(i=2;(i<lx)&&(x[i]==y[i]);i++);
  if(i==lx) return 0;
  return ((ulong)x[i]>(ulong)y[i]) ? sx : -sx;
}

int cmpir(x,y)
     GEN x,y;
{
  long av=avma;
  int p;
  GEN z;
  
  if(!signe(x)) return -signe(y);
  z=cgetr(lg(y));affir(x,z);
  p=cmprr(z,y);avma=av;return p;
}

int cmprr(x,y)
     GEN x,y;
{
  long sx=signe(x),sy=signe(y),ex,ey,lx,ly,lz,i;
  
  if(sx<sy) return -1;
  if(sx>sy) return 1;
  if(!sx) return 0;
  ex=expo(x);ey=expo(y);
  if(ex>ey) return sx;
  if(ex<ey) return -sx;
  lx=lg(x);ly=lg(y);lz=(lx<ly)?lx:ly;
  for(i=2;(i<lz)&&(x[i]==y[i]);i++);
  if(i<lz) return ((ulong)x[i]>(ulong)y[i]) ? sx : -sx;
  if(lx>=ly)
    {
      while((i<lx)&(!x[i])) i++;
      return (i==lx) ? 0 : sx;
    }
  else
    {
      while((i<ly)&(!y[i])) i++;
      return (i==ly) ? 0 : -sx;
    }
}    

GEN mpadd(x,y)
     GEN x,y;
{
  if(typ(x)==1) return (typ(y)==1) ? addii(x,y) : addir(x,y);
  return (typ(y)==1) ? addir(y,x) : addrr(x,y);
}

GEN addss(x,y)
     long x,y;
{
  long t[3];
  
  if(!x) return stoi(y);
  t[0]=0x1010003;
  if(x>0) {t[1]=0x1000003;t[2]=x;} else {t[1]=0xff000003;t[2]= -x;}
  return addsi(y,t);
}


GEN addsi(x,y)
     long x;
     GEN y;
{
  long sx,sy,ly,p,i;
  GEN z;
  
  if(!x) return icopy(y);
  sy=signe(y);if(!sy) return stoi(x);
  if(x<0) {sx= -1;x= -x;} else sx=1;
  ly=lgef(y);
  if(sx==sy)
    {
      p=addll(x,y[ly-1]);
      if(overflow)
	{
	  z=cgeti(ly+1);z[ly]=p;
	  for(i=ly-1;(i>2)&&(y[i-1]==0xffffffff);i--) z[i]=0;
	  if(i>2)
	    {
	      z[i]=y[i-1]+1;i--;while(i>=3) {z[i]=y[i-1];i--;}
	      z[2]=z[1]=z[0]-1;z++;avma+=4;
	    }
	  else {z[2]=1;z[1]=z[0];}
	}
      else
	{
	  z=cgeti(ly);z[ly-1]=p;for(i=1;i<ly-1;i++) z[i]=y[i];
	}
      setsigne(z,sx);
    }
  else
    {
      if(ly==3)
	{
	  if((ulong)y[2]>(ulong)x)
	    {
	      z=cgeti(3);z[1]=(sy<<24)+3;z[2]=y[2]-x;return z;
	    }
	  if(y[2]==x) return gzero;
	  z=cgeti(3);z[1]=((-sy)<<24)+3;z[2]=x-y[2];return z;
	}
      p=subll(y[ly-1],x);
      if(overflow)
	{
	  z=cgeti(ly);z[ly-1]=p;
	  for(i=ly-2;!(y[i]);i--) z[i]=0xffffffff;
	  z[i]=y[i]-1;
	  if((i>2)||z[i]) {i--;for(;i>=1;i--) z[i]=y[i];}
	  else
	    {
	      z[2]=z[1]=z[0]-1;z++;avma+=4;setsigne(z,sy);
	    }
	}
      else
	{
	  z=cgeti(ly);z[ly-1]=p;for(i=1;i<ly-1;i++) z[i]=y[i];
	}    
    }
  return z;
}

GEN addii(x,y)
     GEN x,y;
{
  long sx=signe(x),sy=signe(y),sz,lx=lgef(x),ly=lgef(y),i,j,p;
  GEN z;
  
  if(!sx) return icopy(y);
  if(!sy) return icopy(x);
  if(lx<ly) {z=x;x=y;y=z;sz=sx;sx=sy;sy=sz;sz=lx;lx=ly;ly=sz;}
  if(sx==sy)
    {
      z=cgeti(lx+1);overflow=0;
      for(i=ly-1,j=lx-1;i>=2;i--,j--) z[j+1]=addllx(x[j],y[i]);
      if(overflow)
	{
	  for(;(j>=2)&&(x[j]==0xffffffff);j--) z[j+1]=0;
	  if(j>=2)
	    {
	      z[j+1]=x[j]+1;j--;
	      for(;j>=2;j--) z[j+1]=x[j];
	      z[1]=z[0]-1;z[2]=x[1];z++;avma+=4;
	    }
	  else {z[2]=1;z[1]=x[1]+1;}
	}
      else
	{
	  for(;j>=2;j--) z[j+1]=x[j];
	  z[1]=z[0]-1;z[2]=x[1];z++;avma+=4;
	}
    }
  else
    {
      if(lx==ly)
	{
	  setsigne(y,1);setsigne(x,1);p=cmpii(x,y);
	  setsigne(y,sy);setsigne(x,sx);if(!p) return gzero;
	  if(p<0) {z=x;x=y;y=z;sz=sx;sx=sy;sy=sz;}
	}
      z=cgeti(lx);overflow=0;
      for(i=ly-1,j=lx-1;i>=2;i--,j--) z[j]=subllx(x[j],y[i]);
      if(overflow)
	{
	  for(;!(x[j]);j--) z[j]=0xffffffff;
	  z[j]=x[j]-1;j--;
	  for(;j>=2;j--) z[j]=x[j];
	}
      else
	{
	  for(;j>=2;j--) z[j]=x[j];
	}
      if(z[2]) z[1]=x[1];
      else
	{
	  for(j=3;(j<lx)&&(!z[j]);j++);
	  i=j-2;z[i+1]=z[i]=z[0]-i;z+=i;avma+=(i<<2);setsigne(z,sx);
	}
    }
  return z;
}      

GEN addsr(x,y)
     long x;
     GEN y;
{
  long p[3];
  
  if(!x) return rcopy(y);
  p[0]=0x1010003;
  if(x>0) {p[1]=0x1000003;p[2]=x;} else {p[1]=0xff000003;p[2]= -x;}
  return addir(p,y);
}

GEN addir(x,y)
     GEN x,y;
{
  long l,e,ly,av,i,l1;
  GEN z;
  
  if(!signe(x)) return rcopy(y);
  if(!signe(y))
    {
      l=lgef(x)-(expo(y)>>5);if((l<3)||(l>32767)) err(adder3);
      z=cgetr(l);affir(x,z);return z;
    }
  else
    {
      e=expo(y)-expi(x);ly=lg(y);
      if(e>0)
	{
	  l=ly-(e>>5);if(l<=2) return rcopy(y);
	}
      else
	{ 
	  l=ly+((-e)>>5)+1;if(l>32767) err(adder3);
	}
      av=avma;z=cgetr(l);affir(x,z);l1=av-avma;l=l1>>2;
      z=addrr(z,y);
      for(i=lg(z)-1;i>=0;i--) z[i+l]=z[i];z+=l;avma+=l1;
    }
  return z;
}

GEN addrr(x,y)
     GEN x,y;
{
  long sx=signe(x),sy=signe(y),lx=lg(x),ly=lg(y),lz,ex=expo(x),ey=expo(y),sz;
  long av0=avma,e,l,i,d,m,flag,lp1,lp2,av,k,j,cex,f2;
  GEN z,p1,p2;
  
  if(!sy)
    {
      if(!sx) {e=(ex>=ey)?ex:ey;z=cgetr(3);z[2]=0;z[1]=e+0x800000;return z;}
      e=ex-ey;
      if(e<=0) {z=cgetr(3);z[2]=0;z[1]=ey+0x800000;return z;}
      l=(e>>5)+3;if(l>lx) l=lx;z=cgetr(l);
      for(i=1;i<l;i++) z[i]=x[i];return z;
    }
  e=ey-ex;
  if(!sx)
    {
      if(e<=0) {z=cgetr(3);z[2]=0;z[1]=ex+0x800000;return z;}
      l=(e>>5)+3;if(l>ly) l=ly;z=cgetr(l);
      for(i=1;i<l;i++) z[i]=y[i];return z;
    }
  if(e)
    {
      if(e<0) {z=x;x=y;y=z;lz=lx;lx=ly;ly=lz;ey=ex;e= -e;sz=sx;sx=sy;sy=sz;}
      d=e>>5;m=e&31;
      if(d>=ly-2) return rcopy(y);
      l=d+lx;
      if(l>=ly)
	{
	  flag=1;p1=cgetr(ly);lp1=ly;lp2=ly-d;
	}
      else
	{
	  flag=0;p1=cgetr(l+1);lp2=lx+1;lp1=l+1;
	}
      av=avma;
      if(m)
	{
	  p2=cgetr(lp2);m=32-m;
	  if(flag) {shiftl(x[lp2-1],m);k=hiremainder;}
	  else k=0;
	  for(i=lp2-1;i>=3;i--) 
	    {
	      p2[i]=shiftl(x[i-1],m)+k;k=hiremainder;
	    }
	  p2[2]=k;
	}
      else p2=x;
    }
  else
    {
      l=(lx>ly)?ly:lx;p1=cgetr(l);av=avma;lp2=lp1=l;flag=2;p2=x;m=0;
    }
  if(sx==sy)
    {
      overflow=0;
      if(m+flag) for(i=lp1-1,j=lp2-1;j>=2;i--,j--) p1[i]=addllx(p2[j],y[i]);
      else 
	{
	  p1[lp1-1]=y[lp1-1];
	  for(i=lp1-2,j=lp2-2;j>=2;i--,j--) p1[i]=addllx(p2[j],y[i]);
	}
      if(overflow)
	{
	  for(;(i>=2)&&(y[i]==0xffffffff);i--) p1[i]=0;
	  if(i>=2) {cex=0;p1[i]=y[i]+1;while(i>=3) {i--;p1[i]=y[i];}}
	  else 
	    {
	      cex=1;k=0x80000000;if(ey==0x7fffff) err(adder4);
	      for(i=2;i<lp1;i++) {p1[i]=shiftlr(p1[i],1)+k;k=hiremainder;}
	    }
	}
      else {cex=0;for(;i>=2;i--) p1[i]=y[i];}
      p1[1]=(sx<<24)+ey+cex+0x800000;
      avma=av;return p1;
    }
  else 
    {
      if(!e) 
	{
	  for(i=2;(i<l)&&(p2[i]==y[i]);i++);
	  if(i==l)
	    {
	      e=ex-((l-2)<<5)+0x800000;if(e<0) err(adder5);
	      if(e>=0x1000000) err(adder4);
	      avma=av0;z=cgetr(3);z[2]=0;z[1]=e;return z;
	    }
	  else
	    {
	      f2=(((ulong)y[i])>((ulong)p2[i]))?1:0;
	    }
	}
      else f2=1;
      if(f2)
	{
	  overflow=0;
	  if(m+flag) for(i=lp1-1,j=lp2-1;j>=2;i--,j--) p1[i]=subllx(y[i],p2[j]);
	  else 
	    {
	      p1[lp1-1]=y[lp1-1];
	      for(i=lp1-2,j=lp2-2;j>=2;i--,j--) p1[i]=subllx(y[i],p2[j]);
	    }
	  if(overflow)
	    {
	      for(;(i>=2)&&(!y[i]);i--) p1[i]=0xffffffff;
	      p1[i]=y[i]-1;while(i>=3) {i--;p1[i]=y[i];}
	    }
	  else for(;i>=2;i--) p1[i]=y[i];
	}
      else
	{
	  overflow=0;
	  if(m+flag) for(i=lp1-1;i>=2;i--) p1[i]=subllx(p2[i],y[i]);
	  else 
	    {
	      p1[lp1-1]=subllx(0,y[lp1-1]);
	      for(i=lp1-2;i>=2;i--) p1[i]=subllx(p2[i],y[i]);
	    }
	}
      for(i=2;!p1[i];i++);j=i-2;avma=av+(j<<2);p1[j]=p1[0]-j;p1+=j;
      m=bfffo(p1[2]);e=ey-(j<<5)-m+0x800000;
      if(e<0) err(adder5);
      p1[1]=f2 ? (sy<<24)+e : (sx<<24)+e;
      if(m)
	{
	  k=0;for(i=lp1-1-j;i>=2;i--) {p1[i]=shiftl(p1[i],m)+k;k=hiremainder;}
	}
      return p1;
    }
}

GEN mpsub(x,y)
     GEN x,y;
{
  if(typ(x)==1) return (typ(y)==1) ? subii(x,y) : subir(x,y);
  return (typ(y)==1) ? subri(x,y) : subrr(x,y);
}

GEN subii(x,y)
     GEN x,y;
{
  long s=signe(y);
  GEN z;
  
  if(x==y) return gzero;
  setsigne(y,-s);z=addii(x,y);setsigne(y,s);
  return z;
}

GEN subrr(x,y)
     GEN x,y;
{
  long s=signe(y);
  GEN z;
  
  if(x==y)
    {
      z=cgetr(3);z[2]=0;z[1]=0x800000-(lg(x)<<5);return z;
    }
  setsigne(y,-s);z=addrr(x,y);setsigne(y,s);return z;
}

GEN subsi(x,y)
     long x;
     GEN y;
{
  long s=signe(y);
  GEN z;
  
  setsigne(y,-s);z=addsi(x,y);setsigne(y,s);return z;
}

GEN subsr(x,y)
     long x;
     GEN y;
{
  long s=signe(y);
  GEN z;
  
  setsigne(y,-s);z=addsr(x,y);setsigne(y,s);return z;
}

GEN subss(x,y)
     long x,y;
{
  return addss(-y,x);
}


GEN subir(x,y)
     GEN x,y;
{
  long s=signe(y);
  GEN z;
  
  setsigne(y,-s);z=addir(x,y);setsigne(y,s);return z;
}

GEN subri(x,y)
     GEN x,y;
{
  long s=signe(y);
  GEN z;
  
  setsigne(y,-s);z=addir(y,x);setsigne(y,s);return z;
}

GEN mpmul(x,y)
     GEN x,y;
{
  if(typ(x)==1) return (typ(y)==1) ? mulii(x,y) : mulir(x,y);
  return (typ(y)==1) ? mulir(y,x) : mulrr(x,y);
}

GEN mulss(x,y)
     long x,y;
{
  long s,p1;
  GEN z;
  
  if((!x)||(!y)) return gzero;
  s=1;if(x<0) {s= -1;x= -x;} if(y<0) {s= -s;y= -y;}
  p1=mulll(x,y);
  if(hiremainder) {z=cgeti(4);z[2]=hiremainder;z[3]=p1;}
  else {z=cgeti(3);z[2]=p1;}
  z[1]=z[0];setsigne(z,s);return z;
}

GEN mulsr(x,y)
     long x;
     GEN y;
{
  long lx,i,k,s,p1,p2,e;
  GEN z;
  
  if(!x) return gzero;
  s=signe(y);if(x<0) {s= -s;x= -x;}
  if(!s)
    {
      p1=bfffo(x);e=y[1]+31-p1;if(e>=0x1000000) err(muler2);
      z=cgetr(3);z[1]=e;z[2]=0;
    }
  else
    {
      if(x==1) {z=rcopy(y);setsigne(z,s);return z;}
      lx=lg(y);z=cgetr(lx);setsigne(z,s);
      p2=mulll(x,y[lx-1]);
      for(i=lx-2;i>=2;i--) z[i+1]=addmul(x,y[i]);
      z[2]=hiremainder;p1=bfffo(hiremainder);
      if(p1)
	{
	  shiftl(p2,p1);k=hiremainder;
	  for(i=lx-1;i>=2;i--)
	    {
	      z[i]=shiftl(z[i],p1)+k;k=hiremainder;
	    }
	}
      e=32-p1+expo(y);if(e>=0x800000) err(muler2);
      setexpo(z,e);
    }  
  return z;
}

GEN mulii(x,y)
     GEN x,y;
{
  long i,j,lx=lgef(x),ly=lgef(y),sx,sy,lz,p1,p2;
  GEN z;
  
  sx=signe(x);if(!sx) return gzero;
  sy=signe(y);if(!sy) return gzero;
  if(sy<0) sx= -sx;
  if(lx>ly) {z=x;x=y;y=z;lz=lx;lx=ly;ly=lz;}
  lz=lx+ly-2;if(lz>=0x10000) err(muler1);
  z=cgeti(lz);z[1]=z[0];setsigne(z,sx);
  p1=x[lx-1];hiremainder=0;
  for(i=ly-1;i>=2;i--) z[lx+i-2]=addmul(p1,y[i]);
  z[lx-1]=hiremainder;
  for(j=lx-2;j>=2;j--)
    {
      p1=x[j];hiremainder=0;
      for(i=ly-1;i>=2;i--)
	{
	  p2=addmul(p1,y[i]);
	  z[i+j-1]=addll(p2,z[i+j-1]);hiremainder+=overflow;
	}
      z[j]=hiremainder;
    }
  if(!(z[2]))
    {
      z[2]=z[1]-1;z[1]=z[0]-1;z++;avma+=4;
    }
  return z;
}

GEN mulrr(x,y)
     GEN x,y;
{
  long i,j,lx=lg(x),ly=lg(y),sx=signe(x),sy=signe(y),ex=expo(x),ey=expo(y);
  long e,flag,garde,p1,p2,lz;
  GEN z;
  
  e=ex+ey+0x800000;if(e>=0xffffff) err(muler4);
  if(e<0) err(muler5);
  if((!sx)||(!sy)) {z=cgetr(3);z[2]=0;z[1]=e;return z;}
  if(sy<0) sx= -sx;
  if(lx>ly) {lz=ly;z=x;x=y;y=z;flag=1;} else {lz=lx;flag=(lx!=ly);}
  z=cgetr(lz);z[1]=(sx<<24)+e;
  if(flag) mulll(x[2],y[lz]);else hiremainder=0;
  if(lz==3)
    {
      garde=flag ? addmul(x[2],y[2]) : mulll(x[2],y[2]);
      if((long)hiremainder<0) {z[2]=hiremainder;z[1]++;}
      else {z[2]=(garde<0)?(hiremainder<<1)+1:(hiremainder<<1);}
      return z;
    }
  p1=x[lz-1];garde=hiremainder;
  if(p1)
    {
      mulll(p1,y[3]);p2=addmul(p1,y[2]);
      garde=addll(p2,garde);z[lz-1]=overflow+hiremainder;
    }
  else z[lz-1]=0;
  for(j=lz-2;j>=3;j--)
    {
      p1=x[j];
      if(p1)
	{
	  mulll(p1,y[lz+2-j]);
	  p2=addmul(p1,y[lz+1-j]);
	  garde=addll(p2,garde);hiremainder+=overflow;
	  for(i=lz-j;i>=2;i--)
	    {
	      p2=addmul(p1,y[i]);
	      z[i+j-1]=addll(p2,z[i+j-1]);hiremainder+=overflow;
	    }
	  z[j]=hiremainder;
	}
      else z[j]=0;
    }
  p1=x[2];p2=mulll(p1,y[lz-1]);
  garde=addll(p2,garde);hiremainder+=overflow;
  for(i=lz-2;i>=2;i--)
    {
      p2=addmul(p1,y[i]);
      z[i+1]=addll(p2,z[i+1]);hiremainder+=overflow;
    }
  z[2]=hiremainder;
  if((long)hiremainder>0)
    {
      overflow=(garde<0)?1:0;
      for(i=lz-1;i>=2;i--) {p1=z[i];z[i]=addllx(p1,p1);}
    }
  else z[1]++;
  return z;
}

GEN mulir(x,y)
     GEN x,y;
{
  long sx=signe(x),sy,av,lz,ey,e,garde,p1,p2,i,j;
  GEN z,temp;
  
  if(!sx) return gzero;
  sy=signe(y);ey=expo(y);
  if(!sy)
    {
      z=cgetr(3);z[2]=0;e=expi(x)+ey+0x800000;if(e>=0x1000000) err(muler6);
      z[1]=e;return z;
    }
  lz=lg(y);if(sy<0) sx= -sx;
  z=cgetr(lz);setsigne(z,sx);av=avma;
  temp=cgetr(lz+1);affir(x,temp);x=y;y=temp;
  e=expo(y)+ey+0x800000;if(e>=0xffffff) err(muler4);
  if(e<0) err(muler5);
  z[1]=(sx<<24)+e;
  mulll(x[2],y[lz]);
  if(lz==3)
    {
      garde=addmul(x[2],y[2]);
      if((long)hiremainder<0) {z[2]=hiremainder;z[1]++;}
      else {z[2]=(garde<0)?(hiremainder<<1)+1:(hiremainder<<1);}
      avma=av;return z;
    }
  garde=hiremainder;
  p1=x[lz-1];mulll(p1,y[3]);p2=addmul(p1,y[2]);
  garde=addll(p2,garde);z[lz-1]=overflow+hiremainder;
  for(j=lz-2;j>=3;j--)
    {
      p1=x[j];mulll(p1,y[lz+2-j]);
      p2=addmul(p1,y[lz+1-j]);
      garde=addll(p2,garde);hiremainder+=overflow;
      for(i=lz-j;i>=2;i--)
	{
	  p2=addmul(p1,y[i]);
	  z[i+j-1]=addll(p2,z[i+j-1]);hiremainder+=overflow;
	}
      z[j]=hiremainder;
    }
  p1=x[2];p2=mulll(p1,y[lz-1]);
  garde=addll(p2,garde);hiremainder+=overflow;
  for(i=lz-2;i>=2;i--)
    {
      p2=addmul(p1,y[i]);
      z[i+1]=addll(p2,z[i+1]);hiremainder+=overflow;
    }
  z[2]=hiremainder;
  if((long)hiremainder>0)
    {
      overflow=(garde<0)?1:0;
      for(i=lz-1;i>=2;i--) {p1=z[i];z[i]=addllx(p1,p1);}
    }
  else z[1]++;
  avma=av;return z;
}

GEN convi(x)
     GEN x;
{
  long lx,av=avma,lz;
  GEN z,p1,p2;  
  
  if(!signe(x))
    {
      z=cgeti(3);z[1]= -1;z[2]=0;avma=av;return z+3;
    }
  p1=absi(x);lx=lgef(p1);lz=((lx-2)*15)/14+3;z=cgeti(lz);z[1]= -1;
  for(p2=z+2;signe(p1);p2++) *p2=divisii(p1,1000000000,p1);
  avma=av;return p2;
}

GEN confrac(x)
     GEN x;
{
  long lx=lg(x),ex= -expo(x)-1,ex1,av=avma,ly,ey;
  long lr,nbdec,k,i,j;
  GEN y,res;
  
  ey=((lx-2)<<5)+ex;ly=(ey+63)>>5;y=cgeti(ly);ex1=ex>>5; /* 95 dans mp.s faux? */
  for(i=0;i<ex1;i++) y[i]=0;
  ex&=31;
  if(!ex) for(j=2;j<lx;j++) y[i++]=x[j];
  else
    {
      k=0;
      for(j=2;j<lx;j++) {y[i++]=shiftlr(x[j],ex)+k;k=hiremainder;}
      y[ly-2]=k;
    }
  y[ly-1]=0;
  nbdec=ey*0.30103+1;lr=(nbdec+17)/9;res=cgeti(lr);
  *res=nbdec;
  for(j=1;j<lr;j++)
    {
      hiremainder=0;
      for(i=ly-1;i>=0;i--) y[i]=addmul(y[i],1000000000);
      res[j]=hiremainder;
    }
  avma=av;return res;
}

void mulsii(x,y,z)
     long x;
     GEN y,z;
{
  long av=avma;
  GEN p1;
  
  p1=mulsi(x,y);affii(p1,z);avma=av;
}

void addsii(x,y,z)
     long x;
     GEN y,z;
{
  long av=avma;
  GEN p1;
  
  p1=addsi(x,y);affii(p1,z);avma=av;
}

long divisii(x,y,z)
     long y;
     GEN x,z;
{
  long av=avma,k;
  GEN p1;
  
  p1=divis(x,y);affii(p1,z);avma=av;
  k=hiremainder;return k;
}

long vals(x)
     long x;
{
  unsigned short int y,z;
  int s;

  if(!x) return -1;
  y=x;if(!y) {s=16;y=((ulong)x)>>16;} else s=0;
  z=y&255;if(!z) {s+=8;z=y>>8;}
  y=z&15;if(!y) {s+=4;y=z>>4;}
  z=y&3;if(!z) {s+=2;z=y>>2;}
  return (z&1) ? s : s+1;
}

long vali(x)
     GEN x;
{
  long i,lx=lgef(x);
  
  if(!signe(x)) return -1;
  for(i=lx-1;(i>=2)&&(!x[i]);i--);
  return ((lx-1-i)<<5)+vals(x[i]);
}

GEN mpdiv(x,y)
     GEN x,y;
{
  if(typ(x)==1) return (typ(y)==1) ? divii(x,y) : divir(x,y);
  return (typ(y)==1) ? divri(x,y) : divrr(x,y);
}

GEN divss(x,y)
     long x,y;
{
  long p1;
  
  if(!y) err(diver1);
  hiremainder=0;p1=divll((ulong)abs(x),(ulong)abs(y));
  if(y<0) {hiremainder= -((long)hiremainder);p1= -p1;}
  if(x<0) p1= -p1;
  return stoi(p1);
}

GEN modss(x,y)
     long x,y;
{
  long y1;
  
  if(!y) err(moder1);
  hiremainder=0;divll(abs(x),y1=abs(y));
  if(!hiremainder) return gzero;
  return (((long)hiremainder)<0) ? stoi(y1-hiremainder) : stoi(hiremainder);
}

GEN resss(x,y)
     long x,y;
{
  if(!y) err(reser1);
  hiremainder=0;divll(abs(x),abs(y));
  return (y<0) ? stoi(-((long)hiremainder)) : stoi(hiremainder);
}

GEN dvmdss(x,y,z)
     long x,y;
     GEN *z;
{
  GEN p1;

  p1=divss(x,y);*z=stoi(hiremainder);
  return p1;
}

void dvmdssz(x,y,z,t)
     long x,y;
     GEN z,t;
{
  long av=avma;
  GEN p1;

  p1=divss(x,y);affsi(hiremainder,t);
  mpaff(p1,z);avma=av;
}

GEN dvmdsi(x,y,z)
     long x;
     GEN y,*z;
{
  GEN p1;
  p1=divsi(x,y);*z=stoi(hiremainder);
  return p1;
}

void dvmdsiz(x,y,z,t)
     long x;
     GEN t,y,z;
{
  long av=avma;
  GEN p1;
  
  p1=divsi(x,y);affsi(hiremainder,t);
  mpaff(p1,z);avma=av;
}

GEN dvmdis(x,y,z)
     long y;
     GEN x,*z;
{
  GEN p1;
  p1=divis(x,y);*z=stoi(hiremainder);
  return p1;
}

void dvmdisz(x,y,z,t)
     long y;
     GEN x,t,z;
{
  long av=avma;
  GEN p1;
  
  p1=divis(x,y);affsi(hiremainder,t);
  mpaff(p1,z);avma=av;
}

void dvmdiiz(x,y,z,t)
     GEN x,y,z,t;
{
  long av=avma;
  GEN p1,p2;

  p1=dvmdii(x,y,&p2);mpaff(p1,z);mpaff(p2,t);
  avma=av;
}

GEN divsi(x,y)
     long x;
     GEN y;
{
  long s=signe(y),ly=lgef(y),p1;

  if(!s) err(diver2);
  if((!x)||(ly>3)||(y[2]<0)) {hiremainder=x;return gzero;}
  hiremainder=0;p1=divll(abs(x),y[2]);
  if(signe(y)<0) {hiremainder= -((long)hiremainder);p1= -p1;}
  if(x<0) p1= -p1;
  return stoi(p1);
}

GEN ressi(x,y)
     long x;
     GEN y;
{
  divsi(x,y);return stoi(hiremainder);
}

GEN modsi(x,y)
     long x;
     GEN y;
{
  long s;
  GEN p1;
  
  divsi(x,y);
  if(!hiremainder) return gzero;
  if(x>0) return stoi(hiremainder);
  else
    {
      s=signe(y);setsigne(y,1);p1=addsi(hiremainder,y);
      setsigne(y,s);return p1;
    }
}

GEN divis(y,x)
     long x;
     GEN y;
{
  long s=signe(y),ly=lgef(y),i,d;
  GEN z;
  
  if(!x) err(diver4);
  if(!s) {hiremainder=0;return gzero;}
  if(x<0) {s= -s;x= -x;} 
  if((ulong)x>(ulong)y[2])
    {
      if(ly==3) {hiremainder=itos(y);return gzero;}
      else {z=cgeti(ly-1);d=1;hiremainder=y[2];}
    }
  else {z=cgeti(ly);d=0;hiremainder=0;}
  for(i=d+2;i<ly;i++) z[i-d]=divll(y[i],x);
  z[1]=z[0];setsigne(z,s);if(s<0) hiremainder= -((long)hiremainder);
  return z;
}

GEN modis(x,y)
     long y;
     GEN x;
{
  divis(x,y);if(!hiremainder) return gzero;
  return (signe(x)>0) ? stoi(hiremainder) : stoi(abs(y)+hiremainder);
}

GEN resis(x,y)
     long y;
     GEN x;
{
  divis(x,y);return stoi(hiremainder);
}
     
GEN divir(x,y)
     GEN x,y;
{
  GEN xr,z;
  long av,ly;
  
  if(!signe(y)) err(diver5);
  if(!signe(x)) return gzero;
  ly=lg(y);z=cgetr(ly);av=avma;affir(x,xr=cgetr(ly+1));
  xr=divrr(xr,y);affrr(xr,z);avma=av;return z;
}

GEN divri(x,y)
     GEN x,y;

{
  GEN yr,z;
  long av,lx,ex,s=signe(y);

  if(!s) err(diver8);
  if(!signe(x))
  {
    ex=expo(x)-expi(y)+0x800000;
    if(ex<0) err(diver12);
    z=cgetr(3);z[1]=ex;z[2]=0;return z;
  }
  if((lg(y)==3)&&(y[2]>0)) return (s>0) ? divrs(x,y[2]) : divrs(x,-y[2]);
  lx=lg(x);z=cgetr(lx);av=avma;affir(y,yr=cgetr(lx+1));
  yr=divrr(x,yr);affrr(yr,z);avma=av;return z;
}

void diviiz(x,y,z)
     GEN x,y,z;
{
  long av=avma,lz;
  GEN p1,p2;
  
  if(typ(z)==1) {p1=divii(x,y);affii(p1,z);avma=av;}
  else
    {
      lz=lg(z);p1=cgetr(lz);p2=cgetr(lz);affir(x,p1);affir(y,p2);
      p1=divrr(p1,p2);affrr(p1,z);avma=av;
    }
}
     
void divrrz(x,y,z)
     GEN x,y,z;
{
  long av=avma;
  GEN p1;

  p1=divrr(x,y);mpaff(p1,z);avma=av;
}

void mpdivz(x,y,z)
     GEN x,y,z;
{
  long av=avma,lz;
  GEN p1,p2;

  if(typ(z)==1)
    {
      if(typ(x)==2||typ(y)==2) err(divzer1);
      p1=divii(x,y);affii(p1,z);avma=av;
    }
  else
    {
      if(typ(x)==1)
	{
	  if(typ(y)==2) {p1=divir(x,y);mpaff(p1,z);avma=av;}
	  else
	    {
	      lz=lg(z);p1=cgetr(lz);p2=cgetr(lz);affir(x,p1);affir(y,p2);
	      p1=divrr(p1,p2);affrr(p1,z);avma=av;
	    }
	}
      else
	{
	  if(typ(y)==2) {p1=divrr(x,y);affrr(p1,z);avma=av;}
	  else {p1=divri(x,y);affrr(p1,z);avma=av;}
	}
    }
}

GEN divsr(x,y)
     long x;
     GEN y;
{
  long av,ly;
  GEN p1,z;

  if(!signe(y)) err(diver3);
  if(!x) return gzero;
  ly=lg(y);z=cgetr(ly);av=avma;p1=cgetr(ly+1);affsr(x,p1);p1=divrr(p1,y);
  affrr(p1,z);avma=av;return z;
}

GEN modii(x,y)
     GEN x,y;
{
  long av=avma,tetpil;
  GEN p1;

  p1=dvmdii(x,y,-1);
  if(signe(p1)>=0) return p1;
  tetpil=avma;p1=(signe(y)>0) ? addii(p1,y) : subii(p1,y);
  return gerepile(av,tetpil,p1);
}

void modiiz(x,y,z)
     GEN x,y,z;
{
  long av=avma;
  GEN p1;

  p1=modii(x,y);affii(p1,z);avma=av;
}

void resiiz(x,y,z)
     GEN x,y,z;
{
  long av=avma;
  GEN p1;

  p1=resii(x,y);affii(p1,z);avma=av;
}

GEN divrs(x,y)
     long y;
     GEN x;
{
  long i,k,lx,ex,garde,sh,s=signe(x);
  GEN z;

  if(!y) err(diver6);
  if(!s)
    {
      z=cgetr(3);z[2]=0;z[1]=x[1]-31+bfffo(y);
      if(z[1]<0) err(diver7);return z;
    }
  if(y<0) {s= -s;y= -y;}
  if(y==1) {z=rcopy(x);setsigne(z,s);return z;}
  z=cgetr(lx=lg(x));setsigne(z,s);hiremainder=0;
  for(i=2;i<lx;i++) z[i]=divll(x[i],y);
  garde=divll(0,y);sh=bfffo(z[2]);ex=expo(x)-sh;if((-ex)>0x800000) err(diver7);
  setexpo(z,ex);shiftl(garde,sh);k=hiremainder;
  for(i=lx-1;i>=2;i--) {z[i]=shiftl(z[i],sh)+k;k=hiremainder;}
  return z;
}

mpdivis(x,y,z)
     GEN x,y,z;
{
  long av=avma;
  GEN p1,p2;

  p1=dvmdii(x,y,&p2);
  if(signe(p2)) {avma=av;return 0;}
  affii(p1,z);avma=av;return 1;
}

divise(x,y)
     GEN x,y;
{
  long av=avma;
  GEN p1;

  p1=dvmdii(x,y,-1);avma=av;
  return signe(p1) ? 0 : 1;
}


GEN dvmdii(x,y,z)
     GEN x,y,*z;
{
  long av,av2,lx,ly,lz,i,j,dec,sh,k,k1,sx=signe(x),sy=signe(y);
  long saux,k3,k4,av1,flk4;
  ulong si,qp;
  GEN p1,p2,p3,p4;
  
  if(!sy) err(dvmer1);
  if(!sx)
    {
      if(((long)z==0xffffffff)||((long)z==0)) return gzero;
      *z=gzero;return gzero;
    }
  lx=lgef(x);ly=lgef(y);lz=lx-ly;
  if(lz<0)
    {
      if((long)z==0xffffffff) return icopy(x);
      if(z==0) return gzero;
      *z=icopy(x);return gzero;
    }
  av=avma;if(sx<0) sy= -sy;
  if(ly==3)
    {
      si=y[2];
      if(si>(ulong)x[2]) {p1=cgeti(lx-1);hiremainder=x[2];dec=1;}
      else {p1=cgeti(lx);hiremainder=0;dec=0;}
      for(i=2+dec;i<lx;i++) p1[i-dec]=divll(x[i],si);
      if((long)z==0xffffffff)
	{
	  avma=av;if(!hiremainder) return gzero;
	  p2=cgeti(3);p2[1]=(sx<<24)+3;p2[2]=hiremainder;return p2;
	}
      if(lx!=(dec+2)) {p1[1]=p1[0];setsigne(p1,sy);} else {avma=av;p1=gzero;}
      if(z==0) return p1;
      if(!hiremainder) *z=gzero;
      else {p2=cgeti(3);p2[1]=(sx<<24)+3;p2[2]=hiremainder;*z=p2;}
      return p1;
    }
  else
    {
      p1=cgeti(lx);
      sh=bfffo(y[2]);
      if(sh)
	{
	  p2=cgeti(ly);k=shiftl(y[2],sh);
	  for(i=3;i<ly;i++) 
	    {
	      k1=shiftl(y[i],sh);p2[i-1]=k+hiremainder;k=k1;
	    }
	  p2[ly-1]=k;k=0;
	  for(i=2;i<lx;i++)
	    {
	      k1=shiftl(x[i],sh);p1[i-1]=k+hiremainder;k=k1;
	    }
	  p1[lx-1]=k;
	}
      else {p1[1]=0;for(j=2;j<lx;j++) p1[j]=x[j];p2=y;}
      si=p2[2];saux=p2[3];
      for(i=1;i<=lz+1;i++)
	{
	  if(p1[i]==si) 
	    {
	      qp=0xffffffff;k=addll(si,p1[i+1]);
	    }
	  else
	    {
	      hiremainder=p1[i];qp=divll(p1[i+1],si);
	      overflow=0;k=hiremainder;
	    }
	  if(!overflow)
	    {
	      k1=mulll(qp,saux);k3=subll(k1,p1[i+2]);k+=overflow;
	      flk4=((ulong)hiremainder>(ulong)k);k4=subll(hiremainder,k);
	      while(flk4) {qp--;k3=subll(k3,saux);k4-=overflow;flk4=((ulong)k4>(ulong)si);k4=subll(k4,si);}
	    }
	  hiremainder=0;
	  for(j=ly-1;j>=2;j--)
	    {
	      k1=addmul(qp,p2[j]);
	      p1[i+j-1]=subll(p1[i+j-1],k1);hiremainder+=overflow;
	    }
	  if((ulong)p1[i]<(ulong)hiremainder)
	    {
	      overflow=0;qp--;
	      for(j=ly-1;j>=2;j--) p1[i+j-1]=addllx(p1[i+j-1],p2[j]);
	    }
	  p1[i]=qp;
	}
      av1=avma;
      if((long)z!=0xffffffff)
	{
	  if(p1[1])
	    {
	      p3=cgeti(lz+3);for(j=2;j<=lz+2;j++) p3[j]=p1[j-1];
	    }
	  else
	    {
	      p3=cgeti(lz+2);
	      if(!lz) sy=0;else for(j=2;j<=lz+1;j++) p3[j]=p1[j];
	    }
	  if(lg(p3)<3) p3[1]=2;else {p3[1]=p3[0];setsigne(p3,sy);}
	}
      if(z!=0)
	{
	  for(j=lz+2;(j<lx)&&(!p1[j]);j++);
	  if(j==lx) p4=gzero;
	  else
	    {
	      p4=cgeti(lx-j+2);p4[1]=p4[0];
	      if(!sh) for(i=2;j<lx;j++,i++) p4[i]=p1[j];
	      else
		{
		  hiremainder=0;k1=shiftlr(p1[j++],sh);k=hiremainder;
		  if(k1) {p4[2]=k1;dec=1;} else {p4[1]=p4[0]-1;p4++;avma+=4;p4[1]=p4[0];dec=0;}
		  for(i=2+dec;j<lx;j++,i++)
		    {
		      p4[i]=shiftlr(p1[j],sh)+k;k=hiremainder;
		    }
		}
	      setsigne(p4,sx);
	    }
	}
      if((long)z==0xffffffff) return gerepile(av,av1,p4);
      if((long)z==0) return gerepile(av,av1,p3);
      av2=avma;dec=lpile(av,av1,0)>>2;*z=adecaler(p4,av1,av2)?p4+dec:p4;
      return adecaler(p3,av1,av2)?p3+dec:p3;
    }
}

GEN divrr(x,y)
     GEN x,y;
{
  long sx=signe(x),sy=signe(y),lx,ly,lz,ex,ex1,i,z0;
  long ldif,y0,y1,si,saux,qp,k,k1,k3,k4,j,flk4;
  GEN z;
  
  if(!sy) err(diver9);
  ex=expo(x)-expo(y)+0x800000;
  if(ex<=0) err(diver10);
  if(ex>=0x1000000) err(diver11);
  if(!sx)
    {
      z=cgetr(3);z[1]=ex;z[2]=0;return z;
    }
  lx=lg(x);ly=lg(y);lz=(lx<=ly)?lx:ly;
  z=cgetr(lz);if(sy<0) sx= -sx;
  ex1=(sx<<24)+ex;
  if(ly==3)
    {
      i=x[2];si=(lx>3)?x[3]:0;
      if((ulong)i<(ulong)y[2])
	{
	  hiremainder=i;z[2]=divll(si,y[2]);
	  z[1]=ex1-1;return z;
	}
      else
	{
	  hiremainder=((ulong)i)>>1;
	  z[2]=(i&1)?divll((((ulong)si)>>1)|(0x80000000),y[2]):divll(((ulong)si)>>1,y[2]);
	  z[1]=ex1;return z;
	}
    }
  z0= *z;*z=0;
  for(i=2;i<=lz-1;i++) z[i-1]=x[i];
  z[lz-1]=(lx>lz) ? x[lz] : 0;
  ldif=ly-lz;if(!ldif) {y0=y[lz];y[lz]=0;}
  if(ldif<=1) {y1=y[lz+1];y[lz+1]=0;}
  si=y[2];saux=y[3];
  for(i=0;i<lz-1;i++)
    {
      if(z[i]==si) 
	{
	  qp=0xffffffff;k=addll(si,z[i+1]);
	}
      else
	{
	  hiremainder=z[i];qp=divll(z[i+1],si);
	  overflow=0;k=hiremainder;
	}
      if(!overflow)
	{
	  k1=mulll(qp,saux);k3=subll(k1,z[i+2]);k+=overflow;
	  flk4=((ulong)hiremainder>(ulong)k);k4=subll(hiremainder,k);
	  while(flk4) {qp--;k3=subll(k3,saux);k4-=overflow;flk4=((ulong)k4>(ulong)si);k4=subll(k4,si);}
	}
      mulll(qp,y[lz+1-i]);
      for(j=lz-i;j>=2;j--)
	{
	  k1=addmul(qp,y[j]);
	  z[i+j-1]=subll(z[i+j-1],k1);hiremainder+=overflow;
	}
      if((ulong)z[i]<(ulong)hiremainder)
	{
	  overflow=0;qp--;
	  for(j=lz-i;j>=2;j--) z[i+j-1]=addllx(z[i+j-1],y[j]);
	}
      z[i]=qp;
    }
  if(!ldif) y[lz]=y0;if(ldif<=1) y[lz+1]=y1;
  for(j=lz-1;j>=2;j--) z[j]=z[j-1];
  if(*z)
    {
      k=0x80000000;
      for(j=2;j<lz;j++) {z[j]=shiftlr(z[j],1)+k;k=hiremainder;}
    }
  else ex1--;
  z[1]=ex1;*z=z0;return z;
}

  
GEN gerepile(l,p,q)
	GEN l,p,q;

{
  long av,declg,tl;
  GEN ll,pp,l1,l2,l3;

  declg=(long)l-(long)p;if(declg<=0) return q;
  for(ll=l,pp=p;pp>(GEN)avma;) *--ll= *--pp;
  av=(long)ll;
  while((ll<l)||((ll==l)&&(long)q))
  {
    l2=ll+lontyp[tl=typ(ll)];
    if(tl==10) {l3=ll+lgef(ll);ll+=lg(ll);if(l3>ll) l3=l2;}
    else {ll+=lg(ll);l3=ll;} 
    for(;l2<l3;l2++) 
/*    for(;l2<ll;l2++) */
      {
	l1=(GEN)(*l2);
	if((l1<l)&&(l1>=(GEN)avma))
	  {
	    if(l1<p) *l2+=declg;
	    else
	      if(ll<=l) err(gerper);
	  }
      }
  }
  if((!((long)q))||((q<p)&&(q>=(GEN)avma)))
  {
    avma=av;return q+(declg>>2);
  }
  else {avma=av;return q;}
}

void cgiv(x)
     GEN x;
{
  long p;

  if((p=pere(x))==255) return;
  if((x!=(GEN)avma)||(p>1)) {setpere(x,p-1);return;}
  do x+=lg(x);while(!pere(x));
  avma=(long)x;
  return;
}

ulong overflow,hiremainder;

int addll(x,y)
     int x,y;
{
  int z;

  z=x+y;
  if((x>=0)&&(y>=0)) {overflow=0;return z;}
  if((x<0)&&(y<0)) {overflow=1;return z;}
  overflow=(z>=0)?1:0; return z;
}

int addllx(x,y)
     int x,y;
{
  int z;

  z=x+y+overflow;
  if((x>=0)&&(y>=0)) {overflow=0;return z;}
  if((x<0)&&(y<0)) {overflow=1;return z;}
  overflow=(z>=0)?1:0; return z;
}

int subll(x,y)
     int x,y;
{
  int z;

  z=x-y;
  if((x>=0)&&(y<0)) {overflow=1;return z;}
  if((x<0)&&(y>=0)) {overflow=0;return z;}
  overflow=(z>=0)?0:1; return z;
}

int subllx(x,y)
     int x,y;
{
  int z;

  z=x-y-overflow;
  if((x>=0)&&(y<0)) {overflow=1;return z;}
  if((x<0)&&(y>=0)) {overflow=0;return z;}
  overflow=(z>=0)?0:1; return z;
}

int shiftl(x,y)
     ulong x,y;
{
  hiremainder=x>>(32-y);return (x<<y);
}

int shiftlr(x,y)
     ulong x,y;
{
  hiremainder=x<<(32-y);return (x>>y);
}

int bfffo(x)
     ulong x;
{
  int sc;
  static int tabshi[16]={4,3,2,2,1,1,1,1,0,0,0,0,0,0,0,0};

  if(x&(0xffff0000)) sc=0;else {sc=16;x<<=16;}
  if(!(x&(0xff000000))) {sc+=8;x<<=8;}
  if(x&(0xf0000000)) x>>=28;else {sc+=4;x>>=24;}
  sc+=tabshi[x];return sc;
}

int mulll(x,y)
     ulong x,y;
{
  ulong xlo,xhi,ylo,yhi;
  ulong z;

  xlo=x&65535;xhi=x>>16;ylo=y&65535;yhi=y>>16;
  z=addll(xlo*yhi,xhi*ylo);
  hiremainder=(overflow)?xhi*yhi+65536+(z>>16):xhi*yhi+(z>>16);
  z=addll(xlo*ylo,(z<<16));hiremainder+=overflow;
  return z;
}

int addmul(x,y)
     ulong x,y;
{
  ulong xlo,xhi,ylo,yhi;
  ulong z,z2;

  xlo=x&65535;xhi=x>>16;ylo=y&65535;yhi=y>>16;
  z=addll(xlo*yhi,xhi*ylo);
  z2=(overflow)?xhi*yhi+65536+(z>>16):xhi*yhi+(z>>16);
  z=addll(xlo*ylo,(z<<16));z2+=overflow;
  z=addll(z,hiremainder);hiremainder=z2+overflow;
  return z;
}

/* Ancienne version de divll, en generale plus lente sauf si le processeur flottant
est tres rapide

int divll(x,y)
     ulong x,y;
{
  ulong p,p1,p2;
  long p3,p4;
  double dbl;

  if((ulong)hiremainder>=y) err(divller1);
  p1=hiremainder;dbl=(C4*p1+x)/y;
  if(dbl < C4/2) p=(ulong)dbl;
  else
    {
      if(dbl>C4-1) p=0xffffffff;
      else{dbl-=(C4/2);p=(ulong)dbl;p|=0x80000000;}
    }
  p2=mulll(p,y);p3=x-p2;
  if(x<p2) hiremainder++;
  if((p1==(ulong)hiremainder)&&((ulong)p3<y))
    {hiremainder=p3;return p;}
  if(p1<(ulong)hiremainder) {hiremainder=p3+y;return p-1;}
  hiremainder=p3-y;return p+1;
}

*/

int divll(x,y)
     ulong x,y;
{
#define HIBIT 0x80000000
#define HIMASK 0xffff0000
#define LOMASK 0xffff
#define HIWORD(a) (a >> 16)
/* si le compilateur est bugge, il faut mettre (a >> 16) & LOMASK) */
#define LOWORD(a) (a & LOMASK)
#define GLUE(hi, lo) ((hi << 16) + lo)
#define SPLIT(a, b, c) b = HIWORD(a); c = LOWORD(a)

    ulong v1, v2, u3, u4, q1, q2, aux, aux1, aux2;
    int k;
    
    for(k = 0; !(y & HIBIT); k++)
        {
            hiremainder <<= 1;
            if (x & HIBIT) hiremainder++;
            x <<= 1;
            y <<= 1;
        }
        
    SPLIT(y, v1, v2);
    SPLIT(x, u3, u4);
    
    q1 = hiremainder / v1; if (q1 & HIMASK) q1 = LOMASK;
    hiremainder -= q1 * v1;
    aux = v2 * q1;
again:
    SPLIT(aux, aux1, aux2);
    if (aux2 > u3) aux1++;
    if (aux1 > hiremainder) {q1--; hiremainder += v1; aux -= v2; goto again;}
    u3 -= aux2;
    hiremainder -= aux1;
    hiremainder <<= 16; hiremainder += u3 & LOMASK;
    
    q2 = hiremainder / v1; if (q2 & HIMASK) q2 = LOMASK;
    hiremainder -= q2 * v1;
    aux = v2 * q2;
again2:
    SPLIT(aux, aux1, aux2);
    if (aux2 > u4) aux1++;
    if (aux1 > hiremainder) {q2--; hiremainder += v1; aux -= v2; goto again2;}
    u4 -= aux2;
    hiremainder -= aux1;
    hiremainder <<= 16; hiremainder += u4 & LOMASK;
    hiremainder >>= k;
    return GLUE(q1, q2);
}

long mulmodll(a,b,c)
     ulong a,b,c;
{
  divll(mulll(a,b),c);
  return hiremainder;
}

#endif
