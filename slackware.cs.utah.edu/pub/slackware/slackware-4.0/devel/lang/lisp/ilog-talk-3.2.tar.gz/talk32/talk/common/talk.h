/*****************************************************************************

 talk.h: Talk header file for K&R C, ISO-C, and C++ external code

 Please refer to ILOG Talk 3.2 Reference Manual, chapter 10.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1994-1996 by ILOG
 ----------------------------------------------------------------------

******************************************************************************/

/*

You'll find below:

- signature for runtime licensing
- a session example
- the source code for that example

*/

/*

  RUNTIME LICENSING
  
  when you want to set runtime licenses for Ilog Talk or products
  above Talk (such as Ilog Power Classes), pass the runtime license
  string to IltRegisterLicense().  See ILM Reference Manual for
  details. 

*/

#if defined(__cplusplus)
extern "C" {
#endif

#if defined(__STDC__) || defined(__cplusplus)
extern void IltRegisterLicense (char *runtime_key) ;
#else
extern void IltRegisterLicense () ;
#endif

#if defined(__cplusplus)
}
#endif

/*

________________________________________________

SESSION EXAMPLE on sun4 (sun4's cc is not iso-C)
________________________________________________


? (analyze-program-unit 'iotae 'buildp t)
= #f"iotae.o"

? ; using a K&R C compiler, everything is C-ish
? (system "cc -c iotac.c ; nm iotac.o")
00000000 t   _cons
00000114 T   _iota
00000098 t   _iota_aux
         U   _ilt_check_in_roots
         U   _ilt_string2symbol
= ()
? ; a small test
? (load-program-unit 'iotae)
= iotae
? (iota 5)
= (1 2 3 4 5)

? ; using a C++ compiler, entry points for Talk and to Talk are C-ish
? (system "CC -c iotac.c ; nm iotac.o")
00000000 t   _cons__FPvT1
00000124 T   _iota
000000a0 t   _iota_aux__FlT1
         U   _ilt_check_in_roots
         U   _ilt_string2symbol
= ()
? ; a small test
? (load-program-unit 'iotae)
= iotae
? (iota 5)
= (1 2 3 4 5)

________________________________________________

EXAMPLE SOURCES
________________________________________________


iotac.c


	#include "talk.h"
	
	/ * Implementation of iota: list of arg numbers, form 0  * /
	
	/ * The __STDC__ conditionals of this program garanty protability to
	   all systems, even those non ISO-C conformant (eg cc on SunOS4).
	   Usually, one wouldn't bother flagging until portability actually
	   becomes an issue * /
	
	static ILT_DEFINTERN(cons, "cons",2)   / * note: no space before 2 * /
	
	#if defined(__STDC__)
	static void *iota_aux(long left, long right)
	#else
	static void *iota_aux(left, right)
	long left;
	long right;
	#endif
	{ if (right>0)
	    return cons(ILT_CLONG2TINT(left+1), iota_aux(left+1, right-1));
	  else
	    return 0; }
	
	/ * the following function iota is called from Talk using defextern --
	   therefore it must be defined as C function, not C++ * /
	
	#if defined(__cplusplus)
	extern "C" {
	#endif
	
	#if defined(__STDC__)
	void *iota(void *a)
	#else
	void *iota(a)
	void *a;
	#endif
	{ return(iota_aux(0, ILT_TINT2CLONG(a))); }
	
	#if defined(__cplusplus)
	}
	#endif

	
	
iotae.td

        type        module
	name        iotae
	externals   (iotac)
	export      ((iotae (function iota)))	            
	files       (iotae)

	
iotae.t

	(defextern iota (pointer) pointer)
*/


/* new syntax */
#define ilt_check_in_roots(root, size, type) ll_check_in_roots(root, size, type)
#define ilt_check_out_roots(ticket) ll_check_out_roots(ticket)

/* C long <-> Talk fix convertors. Signatures:
   void *ILT_CLONG2TINT(long i);
   long ILT_TINT2CLONG(void *ti); */

/* pointer size */
#define ILT_LOG_SIZEOF_POINTER	(sizeof(void*)==4?2:sizeof(void*)==8?3:99999999)

#define ILT_CLONG2TINT(i)						\
        ((void*)(((i)*sizeof(void*))|(sizeof(void*)-1)))
#define ILT_TINT2CLONG(f)						\
        (((long)(f))>>ILT_LOG_SIZEOF_POINTER)
#define ILT_CLONG2TCHAR(i)						\
        ((void*)(((i)*sizeof(void*))|(sizeof(void*)-2)))
#define ILT_TCHAR2CLONG(f)						\
        ((unsigned char)((long)(f)>>ILT_LOG_SIZEOF_POINTER))

/* the following Talk primitives (called by DEFINTERN expansion) are C
   functions -- their prototype must me nested in extern "C" if we're
   compiling C++ code, so that C calling and naming protocol is obeyed */

#if defined(__cplusplus)
extern "C" {
#endif

/* root registration */

#define ILT_PUB		1
#define ILT_PRIV	0
#define ILT_CODE	4
#define ILT_BSS		2
#define ILT_DATA	0    

#if defined(__STDC__) || defined(__cplusplus)
extern long ll_check_in_roots(void **root, long l, int type) ;
extern void ll_check_out_roots(long ticket) ;
#else
extern long ll_check_in_roots() ;
extern void ll_check_out_roots() ;
#endif

/* C string -> Talk symbol converter. Parse packages */
#if defined(__STDC__) || defined(__cplusplus)
extern void* ilt_string2symbol(char *string) ;
#else
extern void* ilt_string2symbol() ;
#endif

/* A combination of ll_check_in_roots() and ilt_string2symbol(). */
#if defined(__STDC__) || defined(__cplusplus)
extern void ilt_retrieve_symbol(void **symbol_storage, char *symbol_name) ;
#else
extern void ilt_retrieve_symbol() ;
#endif

#if defined(__cplusplus)
}
#endif

/* types for defintern exclusive use */

#if defined(__STDC__) || defined(__cplusplus)
typedef void *ilt_fn0 (void *, long  );
typedef void *ilt_fn1 (void *, long  , void *);
typedef void *ilt_fn2 (void *, long  , void *, void *);
typedef void *ilt_fn3 (void *, long  , void *, void *, void *);
typedef void *ilt_fn4 (void *, long  , void *, void *, void *, void *);
typedef void *ilt_fn5 (void *, long  , void *, void *, void *, void *, void *);
typedef void *ilt_fn6 (void *, long  , void *, void *, void *, void *, void *,
                      void *);
typedef void *ilt_fn7 (void *, long  , void *, void *, void *, void *, void *,
                      void *, void *);
typedef void *ilt_fn8 (void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *);
typedef void *ilt_fn9 (void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *);
typedef void *ilt_fn10(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *);
typedef void *ilt_fn11(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *);
typedef void *ilt_fn12(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *, void *);
typedef void *ilt_fn13(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *, void *,
                      void *);
typedef void *ilt_fn14(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *, void *,
                      void *, void *);
typedef void *ilt_fn15(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *, void *,
                      void *, void *, void *);
typedef void *ilt_fn16(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *, void *,
                      void *, void *, void *, void *);
typedef void *ilt_fn17(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *);
typedef void *ilt_fn18(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *);
typedef void *ilt_fn19(void *, long  , void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *, void *,
                      void *, void *, void *, void *, void *, void *, void *);
#else
typedef void *ilt_fn0 ();
typedef void *ilt_fn1 ();
typedef void *ilt_fn2 ();
typedef void *ilt_fn3 ();
typedef void *ilt_fn4 ();
typedef void *ilt_fn5 ();
typedef void *ilt_fn6 ();
typedef void *ilt_fn7 ();
typedef void *ilt_fn8 ();
typedef void *ilt_fn9 ();
typedef void *ilt_fn10();
typedef void *ilt_fn11();
typedef void *ilt_fn12();
typedef void *ilt_fn13();
typedef void *ilt_fn14();
typedef void *ilt_fn15();
typedef void *ilt_fn16();
typedef void *ilt_fn17();
typedef void *ilt_fn18();
typedef void *ilt_fn19();
#endif

/* macros to create C function calling Talk functions. First argument
   is the C function id, the second argument is a string representing
   the Talk symbol, third is function arity (without leading space).
   usage:   static ILT_DEFINTERN(cons, "cons",2); */

#if defined(__STDC__) || defined(__cplusplus)

#define ILT_DEFINTERN0(c_fn_id,symb_string)			\
void *c_fn_id()							\
{ static ilt_fn0 ***symb = 0 ;					\
  if (!symb)							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],0)); }

#define ILT_DEFINTERN1(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1)					\
{ static ilt_fn1 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],1,arg1)); }

#define ILT_DEFINTERN2(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2)				\
{ static ilt_fn2 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],2,arg1,arg2)); }

#define ILT_DEFINTERN3(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3)			\
{ static ilt_fn3 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],3,arg1,arg2,arg3)); }

#define ILT_DEFINTERN4(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4)							\
{ static ilt_fn4 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],4,arg1,arg2,arg3,arg4)); }

#define ILT_DEFINTERN5(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5)					\
{ static ilt_fn5 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],5,arg1,arg2,arg3,arg4,	\
      arg5)); }

#define ILT_DEFINTERN6(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6)				\
{ static ilt_fn6 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],6,arg1,arg2,arg3,arg4,	\
      arg5,arg6)); }

#define ILT_DEFINTERN7(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7)			\
{ static ilt_fn7 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],7,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7)); }

#define ILT_DEFINTERN8(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8)							\
{ static ilt_fn8 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],8,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8)); }

#define ILT_DEFINTERN9(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9)					\
{ static ilt_fn9 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],9,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9)); }

#define ILT_DEFINTERN10(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10)				\
{ static ilt_fn10 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],10,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10)); }

#define ILT_DEFINTERN11(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10,void *arg11)		\
{ static ilt_fn11 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],11,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11)); }

#define ILT_DEFINTERN12(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10,void *arg11,		\
  void *arg12)							\
{ static ilt_fn12 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],12,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12)); }

#define ILT_DEFINTERN13(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10,void *arg11,		\
  void *arg12,void *arg13)					\
{ static ilt_fn13 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],13,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13)); }

#define ILT_DEFINTERN14(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10,void *arg11,		\
  void *arg12,void *arg13,void *arg14)				\
{ static ilt_fn14 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],14,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14)); }

#define ILT_DEFINTERN15(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10,void *arg11,		\
  void *arg12,void *arg13,void *arg14,				\
  void *arg15)							\
{ static ilt_fn15 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],15,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15)); }

#define ILT_DEFINTERN16(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10,void *arg11,		\
  void *arg12,void *arg13,void *arg14,				\
  void *arg15,void *arg16)					\
{ static ilt_fn16 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],16,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15,arg16)); }

#define ILT_DEFINTERN17(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10,void *arg11,		\
  void *arg12,void *arg13,void *arg14,				\
  void *arg15,void *arg16,void *arg17)				\
{ static ilt_fn17 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],17,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15,arg16,arg17)); }

#define ILT_DEFINTERN18(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3		,	\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10,void *arg11,		\
  void *arg12,void *arg13,void *arg14,				\
  void *arg15,void *arg16,void *arg17,				\
  void *arg18)							\
{ static ilt_fn18 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],18,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15,arg16,arg17,arg18)); }

#define ILT_DEFINTERN19(c_fn_id,symb_string)			\
void *c_fn_id(void *arg1,void *arg2,void *arg3,			\
  void *arg4,void *arg5,void *arg6,void *arg7,			\
  void *arg8,void *arg9,void *arg10,void *arg11,		\
  void *arg12,void *arg13,void *arg14,				\
  void *arg15,void *arg16,void *arg17,				\
  void *arg18,void *arg19)				 	\
{ static ilt_fn19 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],19,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15,arg16,arg17,arg18,arg19)); }

#else

#define ILT_DEFINTERN0(c_fn_id,symb_string)			\
void *c_fn_id()							\
{ static ilt_fn0 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],0)); }

#define ILT_DEFINTERN1(c_fn_id,symb_string)			\
void *c_fn_id(arg1)						\
void *arg1;							\
{ static ilt_fn1 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],1,arg1)); }

#define ILT_DEFINTERN2(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2)					\
void *arg1;							\
void *arg2;							\
{ static ilt_fn2 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],2,arg1,arg2)); }

#define ILT_DEFINTERN3(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3)					\
void *arg1;							\
void *arg2;							\
void *arg3;							\
{ static ilt_fn3 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],3,arg1,arg2,arg3)); }

#define ILT_DEFINTERN4(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4)								\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
{ static ilt_fn4 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],4,arg1,arg2,arg3,arg4)); }

#define ILT_DEFINTERN5(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5)							\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
{ static ilt_fn5 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],5,arg1,arg2,arg3,arg4,	\
      arg5)); }

#define ILT_DEFINTERN6(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6)						\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
{ static ilt_fn6 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],6,arg1,arg2,arg3,arg4,	\
      arg5,arg6)); }

#define ILT_DEFINTERN7(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7)						\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
{ static ilt_fn7 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],7,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7)); }

#define ILT_DEFINTERN8(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8)								\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
{ static ilt_fn8 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],8,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8)); }

#define ILT_DEFINTERN9(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9)							\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
{ static ilt_fn9 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],9,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9)); }

#define ILT_DEFINTERN10(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10)						\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
{ static ilt_fn10 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],10,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10)); }

#define ILT_DEFINTERN11(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10,arg11)					\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
void *arg11;							\
{ static ilt_fn11 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],11,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11)); }

#define ILT_DEFINTERN12(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10,arg11,					\
  arg12)							\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
void *arg11;							\
void *arg12;							\
{ static ilt_fn12 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],12,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12)); }

#define ILT_DEFINTERN13(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10,arg11,					\
  arg12,arg13)							\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
void *arg11;							\
void *arg12;							\
void *arg13;							\
{ static ilt_fn13 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],13,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13)); }

#define ILT_DEFINTERN14(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10,arg11,					\
  arg12,arg13,arg14)						\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
void *arg11;							\
void *arg12;							\
void *arg13;							\
void *arg14;							\
{ static ilt_fn14 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],14,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14)); }

#define ILT_DEFINTERN15(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10,arg11,					\
  arg12,arg13,arg14,						\
  arg15)							\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
void *arg11;							\
void *arg12;							\
void *arg13;							\
void *arg14;							\
void *arg15;							\
{ static ilt_fn15 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],15,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15)); }

#define ILT_DEFINTERN16(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10,arg11,					\
  arg12,arg13,arg14,						\
  arg15,arg16)							\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
void *arg11;							\
void *arg12;							\
void *arg13;							\
void *arg14;							\
void *arg15;							\
void *arg16;							\
{ static ilt_fn16 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],16,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15,arg16)); }

#define ILT_DEFINTERN17(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10,arg11,					\
  arg12,arg13,arg14,						\
  arg15,arg16,arg17)						\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
void *arg11;							\
void *arg12;							\
void *arg13;							\
void *arg14;							\
void *arg15;							\
void *arg16;							\
void *arg17;							\
{ static ilt_fn17 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],17,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15,arg16,arg17)); }

#define ILT_DEFINTERN18(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3		,			\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10,arg11,					\
  arg12,arg13,arg14,						\
  arg15,arg16,arg17,						\
  arg18)							\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
void *arg11;							\
void *arg12;							\
void *arg13;							\
void *arg14;							\
void *arg15;							\
void *arg16;							\
void *arg17;							\
void *arg18;							\
{ static ilt_fn18 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],18,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15,arg16,arg17,arg18)); }

#define ILT_DEFINTERN19(c_fn_id,symb_string)			\
void *c_fn_id(arg1,arg2,arg3,					\
  arg4,arg5,arg6,arg7,						\
  arg8,arg9,arg10,arg11,					\
  arg12,arg13,arg14,						\
  arg15,arg16,arg17,						\
  arg18,arg19)				 			\
void *arg1;							\
void *arg2;							\
void *arg3;							\
void *arg4;							\
void *arg5;							\
void *arg6;							\
void *arg7;							\
void *arg8;							\
void *arg9;							\
void *arg10;							\
void *arg11;							\
void *arg12;							\
void *arg13;							\
void *arg14;							\
void *arg15;							\
void *arg16;							\
void *arg17;							\
void *arg18;							\
void *arg19;							\
{ static ilt_fn19 ***symb = 0 ;					\
  if (!symb) 							\
    ilt_retrieve_symbol((void**)&symb,symb_string);		\
  return(symb[1][0]((void*)symb[1],19,arg1,arg2,arg3,arg4,	\
      arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,		\
      arg14,arg15,arg16,arg17,arg18,arg19)); }

#endif


/* please set *no* space between   "," and argc, otherwise your code
   won't compile on non-Ansi C compilers */

#if defined(__STDC__) || defined(__cplusplus)
#define ILT_DEFINTERN(intern_function_name,intern_symbol_string,argc)	\
        ILT_DEFINTERN##argc(intern_function_name,intern_symbol_string)
#else /* K&R C token pasting */
#define ILT_DEFINTERN(intern_function_name,intern_symbol_string,argc)   \
        ILT_DEFINTERN/**/argc(intern_function_name,intern_symbol_string)
#endif
