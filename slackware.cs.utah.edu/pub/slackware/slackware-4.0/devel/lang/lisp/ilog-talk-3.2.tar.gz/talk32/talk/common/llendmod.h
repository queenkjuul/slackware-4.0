/*****************************************************************************

 llendmod.h: header file prior after having included any external interface
  	     for the current module or an imported module.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llendmod.h,v 3.3 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

#undef LL_EXTERNAL_STATIC
#undef LL_EXTERNAL_STATIC_INIT
#undef LL_EXTERNAL_STATIC_DIM
#undef LL_EXTERNAL_STATIC_DIM_INIT
#undef LL_EXTERNAL_FUNCTION
#undef LL_COMMONRT_EXTERNAL
