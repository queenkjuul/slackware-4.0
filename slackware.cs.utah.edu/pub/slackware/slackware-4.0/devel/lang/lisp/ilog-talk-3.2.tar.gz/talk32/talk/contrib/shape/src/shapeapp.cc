/*****************************************************************************

 shapeapp.cc:  A little C++ application using the shape library.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1993-1996 by ILOG
 $Header: /nfs/talk/work/talk/contrib/shape/src/RCS/shapeapp.cc,v 1.2 1996/01/13 14:09:55 v16admin Exp $
 ----------------------------------------------------------------------
******************************************************************************/

#include <shape.h>
#include <stream.h>

int main()
{
  initSystem("d1", "title");
  Point* scenter = new Point(100, 100);
  Point* ccenter = new Point(50, 50);
  Square* s1 = new Square(10, scenter);
  Circle* c1 = new Circle(20, ccenter);
  s1->draw();
  c1->draw();
  s1->move(5, 5);
  s1->draw();
  Point dp(12, 12);
  c1->move(dp);
  c1->draw();
  c1->scale(5.2);
  c1->draw();
  Boolean cexact, sexact;
  Rect* c1bb = c1->findBBox(cexact);
  Rect* s1bb = s1->findBBox(sexact);
  if (c1bb->intersects(*s1bb))
    cout << "They intersect";
  else
    cout << "They don't intersect";
  if (cexact && sexact)
    cout << " exactly";
  else
    cout << " inexactly";
  cout << endl;
}
