/*

 llempty.c:  An empty file, used by recload on some systems.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llempty.c,v 1.4 1996/01/12 21:49:16 v16admin Exp $
 ----------------------------------------------------------------------
*/

/* Dummy elaboration function */

void ll_empty(dummy0, dummy1)
     void *dummy0, *dummy1;
{
}
