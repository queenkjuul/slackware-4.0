/*****************************************************************************

 llexportmod.h: header file prior to including any external interface
  	        for the current module.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llexportmod.h,v 3.8 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

/*
 * For external variables used outside commonrt. No initialization is
 * allowed because of SunOS restriction on shared libraries disallowing
 * the exportation of initialized data from a shared library.
 */

#if defined(ILT_OS_WIN32)

#define LL_EXTERNAL_STATIC(var)			var
#define LL_EXTERNAL_STATIC_INIT(var,init)	var = init
#define LL_EXTERNAL_STATIC_DIM(var,dim)		var dim
#define LL_EXTERNAL_STATIC_DIM_INIT(var,dim,init) var dim = init
#define LL_COMMONRT_EXTERNAL(var)		__declspec(dllexport) var

#else /* defined(ILT_OS_WIN32) */

#define LL_EXTERNAL_STATIC(var)			var
#define LL_EXTERNAL_STATIC_INIT(var,init)	var = init
#define LL_EXTERNAL_STATIC_DIM(var,dim)		var dim
#define LL_EXTERNAL_STATIC_DIM_INIT(var,dim,init)	var dim = init
#define LL_COMMONRT_EXTERNAL(var)		var

#endif /* defined(ILT_OS_WIN32) */

#define LL_EXTERNAL_FUNCTION(fn,args)		fn ()
