/*

 llstanda.c:  Entry point for standalone applications

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 ----------------------------------------------------------------------
*/

#include <iltsystem.h>

#ifdef __cplusplus

extern "C" int IltInit  (int argc, char **argv, char **envp);
extern "C" void IltFinish  ();

int main (int argc, char **argv, char **envp)
{
  int status = IltInit(argc, argv, envp);
  IltFinish();
  return status;
}

#else

extern int IltInit();
extern void IltFinish();

int main (argc, argv, envp)
int argc; char **argv, **envp;
{
  int status = IltInit(argc, argv, envp);
  IltFinish(); 
  return status;
}

#endif
