/**********************************************************************
 *
 * Definitions for Unix port family.
 *
 **********************************************************************/

/**********************************************************************
 *
 * C and C++ compiler paths and license files
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX_SOLARIS)
#		define ILT_FLEXLM_LICENSE_FILE	/nfs/talk/licenses/license.dat:/opt/SUNWspro/SunTech_License/bin/license.dat:/nfs/ishare/Licenses/license.dat:
#	if defined(ILT_CPP_SUNCC_SOLARIS_3_0) && defined(ILT_ARC_I386)
#		define ILT_CC_PATH		/opt/SUNWspro/SC2.0.1:/opt/SUNWspro/bin:/usr/ccs/bin
#		define ILT_CPP_PATH		/opt/SUNWspro/SC2.0.1
#	endif
#	if defined(ILT_CPP_SUNCC_SOLARIS_3_0) && defined(ILT_ARC_SPARC)
#		define ILT_CC_PATH		/opt/SUNWspro/SC2.0.1:/usr/ccs/bin
#		define ILT_CPP_PATH		/opt/SUNWspro/SC2.0.1
#	endif
#	if defined(ILT_CPP_SUNCC_SOLARIS_4_0)
#		define ILT_CC_PATH		/opt/SUNWspro/SC3.0.1/bin:/usr/ccs/bin
#		define ILT_CPP_PATH		/opt/SUNWspro/SC3.0.1/bin
#	endif
#	if defined(ILT_CC_GCC)
		/* gcc is looked up here */
#		define ILT_CC_PATH		/usr/local/ibin
#	endif
#	if defined(ILT_CPP_GCC)
		/* g++ is looked up here */
#		define ILT_CPP_PATH		/usr/local/ibin
#	endif
#endif

#if defined(ILT_OS_UNIX_SUNOS)
#		define ILT_FLEXLM_LICENSE_FILE	/nfs/talk/licenses/license.dat:/nfs/ishare/Licenses/license.dat:
#	if defined(ILT_CPP_SUNCC_SUNOS_2_1)
#		define ILT_CPP_PATH		/nfs/ishare/compilers/SunC++2.1/SC1.0
/*
#		define ILT_CPP_LIBPATH		/nfs/ishare/compilers/SunC++2.1/SC1.0
*/
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_3_0)
#		define ILT_CPP_PATH		/nfs/ishare/compilers/SunC++3.0.1/SC2.0.1
/*
#		define ILT_CPP_LIBPATH		/nfs/ishare/compilers/SunC++3.0.1/SC2.0.1
*/
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_4_0)
#		define ILT_CPP_PATH		/nfs/ishare/compilers/SunC++4.0.1/SC3.0.1/bin
/*
#		define ILT_CPP_LIBPATH		/nfs/ishare/compilers/SunC++4.0.1/SC3.0.1/lib
*/
#	endif
#	if defined(ILT_CC_GCC)
		/* gcc is looked up here */
#		define ILT_CC_PATH		/usr/local/ibin
#	endif
#	if defined(ILT_CPP_GCC)
		/* g++ is looked up here */
#		define ILT_CPP_PATH		/usr/local/ibin
#	endif
#endif

#if defined(ILT_OS_UNIX_OSF)
#	if defined(ILT_CPP_AXPCC)
#		define ILT_CPP_PATH		/lib/cmplrs/cxx
#		define ILT_CPP_LIBPATH		/lib/cmplrs/cxx
#	endif
#	if defined(ILT_CC_GCC)
		/* gcc is looked up here */
#		define ILT_CC_PATH		/nfs/talk/work/install/bin/alpha
#	endif
#	if defined(ILT_CPP_GCC)
		/* g++ is looked up here */
#		define ILT_CPP_PATH		/nfs/talk/work/install/bin/alpha
#	endif
#endif


/**********************************************************************
 * 
 * C compiler flags:
 *
 * 	ILT_CC_CMD
 * 	ILT_CC_CMD_DEBUG
 * 	ILT_CC_CMD_OPTIM
 *	ILT_CC_CMD_CNO_WARNINGS
 *	ILT_CC_CMD_PIC
 *	ILT_CC_CMD_FLAGS
 *	ILT_CC_CMD_LINKFLAGS
 *
 **********************************************************************/

#define ILT_CC_CMD_DEBUG			-g
#define ILT_CC_CMD_NO_WARNINGS			-w

#if defined(ILT_CC_SUNCC_SUNOS)
#	define ILT_CC_CMD			cc
#	define ILT_CC_CMD_OPTIM			-O4
#	define ILT_CC_CMD_PIC			-PIC
#	define ILT_CC_CMD_FLAGS			-dalign
#	define ILT_CC_CMD_LINKFLAGS
#endif

#if defined(ILT_CC_SUNCC_SOLARIS)
#	define ILT_CC_CMD			cc
#	define ILT_CC_CMD_STRING		"cc"
#if defined(ILT_CPP_SUNCC_SOLARIS_3_0)
/* cc cannot compile iltdebuge.c with -xO2 or higher optimization. */
#	define ILT_CC_CMD_OPTIM			-xO1
#endif
#if defined(ILT_CPP_SUNCC_SOLARIS_4_0)
#	define ILT_CC_CMD_OPTIM			-xO3
#endif
#	define ILT_CC_CMD_PIC			-KPIC
#if defined(ILT_ARC_SPARC)
#	define ILT_CC_CMD_FLAGS			-dalign
#	define ILT_CC_CMD_LINKFLAGS
#endif
#if defined(ILT_ARC_I386)
#	define ILT_CC_CMD_FLAGS
#	define ILT_CC_CMD_LINKFLAGS
#endif
#endif

#if defined(ILT_CC_HPCC)
#	define ILT_CC_CMD			cc
#	if defined(ILT_CC_HPCC_10)
		/* produce code which runs on both HP-PA 1.0 (hp8xx) and HP-PA 1.1 (hp7xx) */
#		define ILT_CC_CMD_OPTIM		+O2 +DA1.0
#	else
#		define ILT_CC_CMD_OPTIM		+O2
#	endif
#	define ILT_CC_CMD_PIC			+Z
#	define ILT_CC_CMD_FLAGS
#	define ILT_CC_CMD_LINKFLAGS
#endif

#if defined(ILT_CC_XLC)
#	define ILT_CC_CMD			cc
#	define ILT_CC_CMD_OPTIM			-O
#	define ILT_CC_CMD_PIC
#	define ILT_CC_CMD_FLAGS
#	define ILT_CC_CMD_LINKFLAGS
#endif

#if defined(ILT_CC_SGICC)
#	if defined(ILT_TALK_PORT_SGI_5_2_3)
#	define ILT_CC_CMD			cc
#	endif
#	if defined(ILT_TALK_PORT_SGI_5_3_4) || defined(ILT_TALK_PORT_SGI_6_2_6_2)
#	define ILT_CC_CMD			cc -32
#	endif
#	if defined(ILT_TALK_PORT_SGI64_6_2_6_2)
#	define ILT_CC_CMD			cc -64
#	endif
#	define ILT_CC_CMD_OPTIM			-O
#	define ILT_CC_CMD_PIC			-KPIC
#	define ILT_CC_CMD_FLAGS			-cckr
#	define ILT_CC_CMD_LINKFLAGS
#endif

#if defined(ILT_CC_AXPCC)
#	define ILT_CC_CMD			cc
#	define ILT_CC_CMD_OPTIM			-O
#	define ILT_CC_CMD_PIC
/* We want IEEE compliant floating-point behaviour, i.e. (f/ 0. 0.) => NaN.
 * See the ieee(3) and cc(1) man pages for explanations. */
#	define ILT_CC_CMD_FLAGS			-resumption_safe -ieee_with_no_inexact
#	define ILT_CC_CMD_LINKFLAGS
#endif

#if defined(ILT_CC_GCC)
#	define ILT_CC_CMD			gcc
#	define ILT_CC_CMD_STRING		"gcc"
#	define ILT_CC_CMD_OPTIM			-O
#	undef ILT_CC_CMD_DEBUG
#	define ILT_CC_CMD_DEBUG			-O -g
#	define ILT_CC_CMD_PIC			-fPIC
#	define ILT_CC_CMD_FLAGS
#	define ILT_CC_CMD_LINKFLAGS
#endif


/**********************************************************************
 * 
 * C++ compiler flags:
 *
 * 	ILT_CPP_CMD
 * 	ILT_CPP_CMD_DEBUG
 * 	ILT_CPP_CMD_OPTIM
 *	ILT_CPP_CMD_NO_WARNINGS
 *	ILT_CPP_CMD_PIC
 * 	ILT_CPP_CMD_S
 * 	ILT_CPP_PREP_CMD_S
 * 
 **********************************************************************/

#define ILT_CPP_CMD_DEBUG			-g
#define ILT_CPP_CMD_NO_WARNINGS			-w

#if defined(ILT_CPP_SUNCC_SUNOS)
#	define ILT_CPP_CMD			CC
#	define ILT_CPP_CMD_OPTIM		-O4
#	define ILT_CPP_CMD_PIC			-PIC
#	define ILT_CPP_CMD_FLAGS		-dalign
#	define ILT_CPP_CMD_S			"CC"
#	define ILT_CPP_PREP_CMD_S		"CC -E"
#endif

#if defined(ILT_CPP_SUNCC_SOLARIS)
#	define ILT_CPP_CMD			CC
#	define ILT_CPP_CMD_OPTIM		-O
#	define ILT_CPP_CMD_PIC			-PIC
#if defined(ILT_ARC_SPARC)
#	define ILT_CPP_CMD_FLAGS		-dalign
#endif
#if defined(ILT_ARC_I386)
#	define ILT_CPP_CMD_FLAGS
#endif
#	define ILT_CPP_CMD_S			"CC"
#	define ILT_CPP_PREP_CMD_S		"CC -E"
#endif

#if defined(ILT_CPP_HPCC)
#	define ILT_CPP_CMD			CC
#	if defined(ILT_CPP_HPCC_10)
		/* produce code which runs on both HP-PA 1.0 (hp8xx) and HP-PA 1.1 (hp7xx) */
#		define ILT_CPP_CMD_OPTIM	+O2 +DA1.0
#	else
#		define ILT_CPP_CMD_OPTIM	+O2
#	endif
#	define ILT_CPP_CMD_PIC			+Z
#	define ILT_CPP_CMD_FLAGS
#	define ILT_CPP_CMD_S			"CC"
#	define ILT_CPP_PREP_CMD_S		"CC -E"
#endif

#if defined(ILT_CPP_XLC)
#	define ILT_CPP_CMD			xlC
#	define ILT_CPP_CMD_OPTIM		-O
#	define ILT_CPP_CMD_PIC
#	define ILT_CPP_CMD_FLAGS		-+
#	define ILT_CPP_CMD_S			"xlC"
#	define ILT_CPP_PREP_CMD_S		"xlC -E"
#endif

#if defined(ILT_CPP_SGICC)
#	if defined(ILT_TALK_PORT_SGI_5_2_3)
#	define ILT_CPP_CMD			CC
#	define ILT_CPP_CMD_S			"CC"
#	define ILT_CPP_PREP_CMD_S		"CC -E"
#	endif
#	if defined(ILT_TALK_PORT_SGI_5_3_4) || defined(ILT_TALK_PORT_SGI_6_2_6_2)
#	define ILT_CPP_CMD			CC -32
#	define ILT_CPP_CMD_S			"CC -32"
#	define ILT_CPP_PREP_CMD_S		"CC -32 -E"
#	endif
#	if defined(ILT_TALK_PORT_SGI64_6_2_6_2)
#	define ILT_CPP_CMD			CC -64
#	define ILT_CPP_CMD_S			"CC -64"
#	define ILT_CPP_PREP_CMD_S		"CC -64 -E"
#	endif
#	define ILT_CPP_CMD_OPTIM		-O
#	define ILT_CPP_CMD_PIC			-KPIC
#	define ILT_CPP_CMD_FLAGS
#endif

#if defined(ILT_CPP_AXPCC)
#	define ILT_CPP_CMD			cxx
#	define ILT_CPP_CMD_OPTIM		-O
#	define ILT_CPP_CMD_PIC
#	define ILT_CPP_CMD_FLAGS
#	define ILT_CPP_CMD_S			"cxx"
#	define ILT_CPP_PREP_CMD_S		"cxx -E"
#endif

#if defined(ILT_CPP_GCC)
#	define ILT_CPP_CMD			g++
#	define ILT_CPP_CMD_OPTIM		-O
#	undef ILT_CPP_CMD_DEBUG
#	define ILT_CPP_CMD_DEBUG		-O -g
#	define ILT_CPP_CMD_PIC			-fPIC
#	define ILT_CPP_CMD_FLAGS
#	define ILT_CPP_CMD_S			"g++"
#	define ILT_CPP_PREP_CMD_S		"g++ -E"
#endif


/**********************************************************************
 *
 * Link libraries ILT_LD_CMD_LIBS
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX_SUNOS)
#	define ILT_LD_CMD_LIBS			-lc -lm -ldl
#endif

#if defined(ILT_OS_UNIX_SOLARIS)
#	define ILT_LD_CMD_LIBS			-lsocket -lnsl -lm -ldl
#endif

#if defined(ILT_OS_UNIX_HPUX)
#	define ILT_LD_CMD_LIBS			-lc -lm -ldld
#endif

#if defined(ILT_OS_UNIX_AIX)
#	define ILT_LD_CMD_LIBS			-lc -lm
#endif

#if defined(ILT_OS_UNIX_IRIX)
#	define ILT_LD_CMD_LIBS			-lm
#endif

#if defined(ILT_OS_UNIX_OSF)
#	define ILT_LD_CMD_LIBS			-lc -lm
#endif

#if defined(ILT_OS_UNIX_LINUX)
/* The effect of -lieee is that 0.0/0.0 gives a NaN instead of an exception. */
#	define ILT_LD_CMD_LIBS			-lm -lieee -ldl
#endif


/**********************************************************************
 * 
 * Path variable ILT_LIBPATHVAR
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX_SUNOS)
#	define ILT_LIBPATHVAR			LD_LIBRARY_PATH
#endif

#if defined(ILT_OS_UNIX_SOLARIS)
#	define ILT_LIBPATHVAR			LD_LIBRARY_PATH
#endif

#if defined(ILT_OS_UNIX_HPUX)
#	define ILT_LIBPATHVAR			SHLIB_PATH
#endif

#if defined(ILT_OS_UNIX_IRIX)
#	define ILT_LIBPATHVAR			LD_LIBRARY_PATH
#endif

#if defined(ILT_OS_UNIX_OSF)
#	define ILT_LIBPATHVAR			LD_LIBRARY_PATH
#endif

#if defined(ILT_OS_UNIX_AIX)
#	define ILT_LIBPATHVAR			LIBPATH
#endif

#if defined(ILT_OS_UNIX_LINUX)
#	define ILT_LIBPATHVAR			LD_LIBRARY_PATH
#endif

