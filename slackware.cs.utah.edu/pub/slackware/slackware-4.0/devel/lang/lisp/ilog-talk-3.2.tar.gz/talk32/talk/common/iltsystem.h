/**********************************************************************
 *
 * System macros.
 *
 **********************************************************************/

#if !defined(_ILT_ILTSYSTEM_INCL)
#define _ILT_ILTSYSTEM_INCL

#include <iltlevel.h>
#include <iltproduct.h>
#include <iltportdef.h>

/*
 * NOTE:
 * No trailing spaces and no comments after the values of the macros, please!
 * Otherwise spaces may end up in the replacements. Not good.
 */

/**********************************************************************
 *
 * Name of the TALK base directory variable:
 *
 * 	ILT_DIR_VAR
 *
 **********************************************************************/

#define ILT_DIR_VAR				ILT_DIR


/**********************************************************************
 *
 * ILOG usual root directory:
 *
 * 	ILT_ILOG_DIRECTORY
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	define ILT_ILOG_DIRECTORY		/usr/ilog
#endif

#if defined(ILT_OS_WIN32)
#	define ILT_ILOG_DIRECTORY		\\usr\\ilog
#endif


/**********************************************************************
 *
 * Port directories, names and servers:
 *
 *	ILT_OS_NAME
 *	ILT_XEMACS_PORT
 * 	ILT_VIEWS_PORT
 * 	ILT_TALK_PORT
 * 	ILT_TALK_PORT_S
 * 	ILT_TALK_PORT_FAMILY_S
 *	ILT_PORT_SERVER
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX_SUNOS_4_1_3_U1)
#	define ILT_XEMACS1911_PORT		sparc-sun-sunos4.1.3
#	define ILT_XEMACS1913_PORT		sparc-sun-sunos4.1.3
#	if defined(ILT_CPP_SUNCC_SUNOS_2_1)
#		define ILT_VIEWS_PORT		sparc_4_2.1
#		define ILT_TALK_PORT		sparc_4_2.1
#		define ILT_TALK_PORT_SPARC_4_2_1
#		define ILT_TALK_PORT_S		"sparc_4_2.1"
#		define ILT_PORT_SERVER		reaumur
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_3_0) /* Was sun4 */
#		define ILT_VIEWS_PORT		sparc_4_3.0
#		define ILT_TALK_PORT		sparc_4_3.0
#		define ILT_TALK_PORT_SPARC_4_3_0
#		define ILT_TALK_PORT_S		"sparc_4_3.0"
#		define ILT_PORT_SERVER		reaumur
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_4_0)
#		define ILT_VIEWS_PORT		sparc_4_4.0
#		define ILT_TALK_PORT		sparc_4_4.0
#		define ILT_TALK_PORT_SPARC_4_4_0
#		define ILT_TALK_PORT_S		"sparc_4_4.0"
#		define ILT_PORT_SERVER		reaumur
#	endif
#	if defined(ILT_CPP_GCC)
#		define ILT_VIEWS_PORT		sparc_4_gnu
#		define ILT_TALK_PORT		sparc_4_gnu
#		define ILT_TALK_PORT_SPARC_4_GNU
#		define ILT_TALK_PORT_S		"sparc_4_gnu"
#		define ILT_PORT_SERVER		reaumur
#	endif
#endif

#if defined(ILT_OS_UNIX_SOLARIS_5_4) && defined(ILT_ARC_SPARC)
#	define ILT_XEMACS1911_PORT		sparc-sun-solaris2.3
                                             /* sparc-sun-solaris2.4 as well */
#	define ILT_XEMACS1913_PORT		sparc-sun-solaris2.4
#	if defined(ILT_CPP_SUNCC_SOLARIS_3_0)
#		define ILT_VIEWS_PORT		sparc_5_3.0
#		define ILT_TALK_PORT		sparc_5_3.0
#		define ILT_TALK_PORT_SPARC_5_3_0
#		define ILT_TALK_PORT_S		"sparc_5_3.0"
#		define ILT_PORT_SERVER		halles
#	endif
#	if defined(ILT_CPP_SUNCC_SOLARIS_4_0) /* Was solaris */
#		define ILT_VIEWS_PORT		sparc_5_4.0
#		define ILT_TALK_PORT		sparc_5_4.0
#		define ILT_TALK_PORT_SPARC_5_4_0
#		define ILT_TALK_PORT_S		"sparc_5_4.0"
#		define ILT_PORT_SERVER		halles
#	endif
#	if defined(ILT_CPP_GCC)
#		define ILT_VIEWS_PORT		sparc_5_gnu
#		define ILT_TALK_PORT		sparc_5_gnu
#		define ILT_TALK_PORT_SPARC_5_GNU
#		define ILT_TALK_PORT_S		"sparc_5_gnu"
#		define ILT_PORT_SERVER		halles
#	endif
#endif

#if defined(ILT_OS_UNIX_SOLARIS_5_4) && defined(ILT_ARC_I386)
#	define ILT_XEMACS1911_PORT		i486-pc-solaris2.1
#	define ILT_XEMACS1913_PORT		i386-unknown-solaris2.4
#	if defined(ILT_CPP_SUNCC_SOLARIS_3_0)
#		define ILT_VIEWS_PORT		i86_sunos5_3.0
#		define ILT_TALK_PORT		i86_sunos5_3.0
#		define ILT_TALK_PORT_I86_SUNOS5_3_0
#		define ILT_TALK_PORT_S		"i86_sunos5_3.0"
#		define ILT_PORT_SERVER		rivoli
#	endif
#	if defined(ILT_CPP_SUNCC_SOLARIS_4_0)
#		define ILT_VIEWS_PORT		i86_sunos5_4.0
#		define ILT_TALK_PORT		i86_sunos5_4.0
#		define ILT_TALK_PORT_I86_SUNOS5_4_0
#		define ILT_TALK_PORT_S		"i86_sunos5_4.0"
#		define ILT_PORT_SERVER		rivoli
#	endif
#endif

#if defined(ILT_OS_UNIX_HPUX_09_05)
#	define ILT_XEMACS1911_PORT		hppa1.1-hp-hpux9
#	define ILT_XEMACS1913_PORT		hppa1.1-hp-hpux9.05
#	define ILT_VIEWS_PORT			hp700
#	define ILT_TALK_PORT			hp700
#	define ILT_TALK_PORT_HP700
#	define ILT_TALK_PORT_S			"hp700"
#	define ILT_PORT_SERVER			issy
#endif

#if defined(ILT_OS_UNIX_HPUX_10_01)
#	define ILT_XEMACS1911_PORT		hppa1.1-hp-hpux9
#	define ILT_XEMACS1913_PORT		hppa1.0-hp-hpux10.00
#	define ILT_VIEWS_PORT			hp_10
#	define ILT_TALK_PORT			hp_10
#	define ILT_TALK_PORT_HP_10
#	define ILT_TALK_PORT_S			"hp_10"
#	define ILT_PORT_SERVER			pantin
#endif

#if defined(ILT_OS_UNIX_AIX_3_2)
#	define ILT_XEMACS1911_PORT		rs6000-ibm-aix3.2
#	define ILT_XEMACS1912_PORT		rs6000-ibm-aix3.2.5
#	define ILT_XEMACS1913_PORT		rs6000-ibm-aix3.2.5
#	define ILT_VIEWS_PORT			rs6000
#	define ILT_TALK_PORT			rs6000
#	define ILT_TALK_PORT_RS6000
#	define ILT_TALK_PORT_S			"rs6000"
#	define ILT_PORT_SERVER			courcelles
#endif
#if defined(ILT_OS_UNIX_AIX_4_1)
#	define ILT_XEMACS1911_PORT		rs6000-ibm-aix3.2
#	define ILT_XEMACS1912_PORT		rs6000-ibm-aix4.1.1
#	define ILT_XEMACS1913_PORT		rs6000-ibm-aix4.1.1
#	define ILT_VIEWS_PORT			rs6000
#	define ILT_TALK_PORT			rs6000
#	define ILT_TALK_PORT_RS6000
#	define ILT_TALK_PORT_S			"rs6000"
#	define ILT_PORT_SERVER			courcelles
#endif

#if defined(ILT_OS_UNIX_IRIX_5_2)
#	define ILT_XEMACS1911_PORT		mips-sgi-irix5.2
#	define ILT_XEMACS1913_PORT		mips-sgi-irix5.2
#	define ILT_VIEWS_PORT			sgi_5.2_3
#	define ILT_TALK_PORT			sgi_5.2_3
#	define ILT_TALK_PORT_SGI_5_2_3
#	define ILT_TALK_PORT_S			"sgi_5.2_3"
#	define ILT_PORT_SERVER			iena
#endif

#if defined(ILT_OS_UNIX_IRIX_5_3)
#	define ILT_XEMACS1911_PORT		mips-sgi-irix5.2
#	define ILT_XEMACS1913_PORT		mips-sgi-irix5.3
#	define ILT_VIEWS_PORT			sgi_5.3_4
#	define ILT_TALK_PORT			sgi_5.3_4
#	define ILT_TALK_PORT_SGI_5_3_4
#	define ILT_TALK_PORT_S			"sgi_5.3_4"
#	define ILT_PORT_SERVER			diderot
#endif

#if defined(ILT_OS_UNIX_IRIX_6_2)
#	define ILT_XEMACS1911_PORT		mips-sgi-irix5.2
#	define ILT_XEMACS1913_PORT		mips-sgi-irix5.3
#	if defined(ILT_ARC_MIPS64)
#		define ILT_VIEWS_PORT		sgi64_6.2_6.2
#		define ILT_TALK_PORT		sgi64_6.2_6.2
#		define ILT_TALK_PORT_SGI64_6_2_6_2
#		define ILT_TALK_PORT_S		"sgi64_6.2_6.2"
#	else /* 32-bit executables */
#		define ILT_VIEWS_PORT		sgi_6.2_6.2
#		define ILT_TALK_PORT		sgi_6.2_6.2
#		define ILT_TALK_PORT_SGI_6_2_6_2
#		define ILT_TALK_PORT_S		"sgi_6.2_6.2"
#	endif
#	define ILT_PORT_SERVER			molitor
#endif

#if defined(ILT_OS_UNIX_OSF_3_0)
#	define ILT_XEMACS1911_PORT		alpha-dec-osf2.1
#	define ILT_XEMACS1913_PORT		alpha-dec-osf3.2
#	if defined(ILT_CC_AXPCC)
#		define ILT_VIEWS_PORT		alpha_3
#		define ILT_TALK_PORT		alpha_3
#		define ILT_TALK_PORT_ALPHA_3
#		define ILT_TALK_PORT_S		"alpha_3"
#		define ILT_PORT_SERVER		villiers
#	endif
#	if defined(ILT_CC_GCC)
#		define ILT_VIEWS_PORT		alpha_3_gnu
#		define ILT_TALK_PORT		alpha_3_gnu
#		define ILT_TALK_PORT_ALPHA_3_GNU
#		define ILT_TALK_PORT_S		"alpha_3_gnu"
#		define ILT_PORT_SERVER		villiers
#	endif
#endif

#if defined(ILT_OS_UNIX_LINUX_1_2)
#	define ILT_XEMACS1913_PORT		i486-unknown-linuxelf
#	define ILT_VIEWS_PORT			i86_linux1.2_gnu2.7
#	define ILT_TALK_PORT			i86_linux1.2_gnu2.7
#	define ILT_TALK_PORT_I86_LINUX1_2_GNU2_7
#	define ILT_TALK_PORT_S			"i86_linux1.2_gnu2.7"
#	define ILT_PORT_SERVER			maubourg
#endif

#if defined(ILT_OS_WIN32_WINNT_3_5)
#	if defined(ILT_CC_MSVC_2)
#		define ILT_VIEWS_PORT		msvc32
#		define ILT_TALK_PORT		msvc32
#		define ILT_TALK_PORT_MSVC32
#		define ILT_TALK_PORT_S		"msvc32"
#	endif
#	if defined(ILT_CC_MSVC_4)
#		define ILT_VIEWS_PORT		msvc4
#		define ILT_TALK_PORT		msvc4
#		define ILT_TALK_PORT_MSVC4
#		define ILT_TALK_PORT_S		"msvc4"
#	endif
#	define ILT_PORT_SERVER			maubourg
#endif

#if defined(ILT_OS_UNIX)
#		define ILT_TALK_PORT_FAMILY_S	"unix"
#endif

#if defined(ILT_OS_WIN32)
#		define ILT_TALK_PORT_FAMILY_S	"win32"
#endif

#define ILT_XEMACS_PORT				ILT_XEMACS1913_PORT


/**********************************************************************
 *
 * Architecture names:
 *
 * 	ILT_ARC_NAME
 *
 **********************************************************************/

#if defined(ILT_ARC_SPARC)
#		define ILT_ARC_NAME		sparc
#endif

#if defined(ILT_ARC_ALPHA)
#		define ILT_ARC_NAME		DEC/alpha
#endif

#if defined(ILT_ARC_HP_PREC)
#		define ILT_ARC_NAME		HP-PA
#endif

#if defined(ILT_ARC_I386)
#		define ILT_ARC_NAME		i386
#endif

#if defined(ILT_ARC_RS6000)
#		define ILT_ARC_NAME		rs6000
#endif

#if defined(ILT_ARC_MIPS)
#		define ILT_ARC_NAME		mips
#endif


/**********************************************************************
 *
 * OS names:
 *
 * 	ILT_OS_NAME
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX_SUNOS_4_1_3_U1)
#	define ILT_OS_NAME			SunOS 4.1.3_U1
#endif

#if defined(ILT_OS_UNIX_SOLARIS_5_4)
#	define ILT_OS_NAME			SunOS 5.3 or 5.4 (Solaris 2.3 or 2.4)
#endif

#if defined(ILT_OS_UNIX_HPUX_09_05)
#	define ILT_OS_NAME			HP-UX A.09.05
#endif

#if defined(ILT_OS_UNIX_HPUX_10_01)
#	define ILT_OS_NAME			HP-UX B.10.01
#endif

#if defined(ILT_OS_UNIX_AIX_3_2)
#	define ILT_OS_NAME			AIX 3.2
#endif
#if defined(ILT_OS_UNIX_AIX_4_1)
#	define ILT_OS_NAME			AIX 4.1
#endif

#if defined(ILT_OS_UNIX_IRIX_5_2)
#	define ILT_OS_NAME			IRIX 5.2
#endif

#if defined(ILT_OS_UNIX_IRIX_5_3)
#	define ILT_OS_NAME			IRIX 5.3
#endif

#if defined(ILT_OS_UNIX_IRIX_6_2)
#	define ILT_OS_NAME			IRIX 6.2
#endif

#if defined(ILT_OS_UNIX_OSF_3_0)
#	define ILT_OS_NAME			OSF1 V3.0
#endif

#if defined(ILT_OS_UNIX_LINUX_1_2)
#	define ILT_OS_NAME			Linux 1.2
#endif

#if defined(ILT_OS_WIN32_WINNT_3_5)
#	define ILT_OS_NAME			Windows NT 3.5
#endif


/**********************************************************************
 *
 * Make name:
 *
 * 	ILT_MAKE_NAME
 *
 **********************************************************************/

#if defined(ILT_OS_WIN32)
#	define	ILT_MAKE_NAME			nmake
#else
#	define	ILT_MAKE_NAME			make
#endif


/**********************************************************************
 *
 * C compiler names:
 *
 * 	ILT_CC_NAME
 *
 **********************************************************************/

#if defined(ILT_CC_SUNCC_SUNOS)
#	define ILT_CC_NAME			Bundled C compiler
#endif

#if defined(ILT_CC_SUNCC_SOLARIS_3_0)
#	define ILT_CC_NAME			Sun C 3.0
#endif

#if defined(ILT_CC_SUNCC_SOLARIS_4_0)
#	define ILT_CC_NAME			Sun C 4.0
#endif

#if defined(ILT_CC_HPCC_09_73)
#	define ILT_CC_NAME			HP C 9.73
#endif

#if defined(ILT_CC_HPCC_10_11)
#	define ILT_CC_NAME			HP C 10.11
#endif

#if defined(ILT_CC_XLC_1_3)
#	define ILT_CC_NAME			xlc 1.3
#endif
#if defined(ILT_CC_XLC_2_1)
#	define ILT_CC_NAME			xlc 2.1
#endif

#if defined(ILT_CC_SGICC_3_2)
#	define ILT_CC_NAME			C 3.2
#endif

#if defined(ILT_CC_SGICC_4)
#	define ILT_CC_NAME			C 4
#endif

#if defined(ILT_CC_SGICC_6_2)
#	define ILT_CC_NAME			C 6.2
#endif

#if defined(ILT_CC_AXPCC)
#	define ILT_CC_NAME			DEC C
#endif

#if defined(ILT_CC_GCC)
#	define ILT_CC_NAME			GNU C
#endif

#if defined(ILT_CC_MSVC_2_0)
#	define ILT_CC_NAME			MSVC 2.0
#endif

#if defined(ILT_CC_MSVC_4_0)
#	define ILT_CC_NAME			MSVC 4.0
#endif


/**********************************************************************
 *
 * C++ compiler names:
 *
 * 	ILT_CPP_NAME
 *
 **********************************************************************/

#if defined(ILT_CPP_SUNCC_SUNOS_2_1)
#	define ILT_CPP_NAME			SunCC 2.1
#endif

#if defined(ILT_CPP_SUNCC_SUNOS_3_0)
#	define ILT_CPP_NAME			SunCC 3.0
#endif

#if defined(ILT_CPP_SUNCC_SUNOS_4_0)
#	define ILT_CPP_NAME			SunCC 4.0
#endif

#if defined(ILT_CPP_SUNCC_SOLARIS_3_0)
#	define ILT_CPP_NAME			SunCC 3.0
#endif

#if defined(ILT_CPP_SUNCC_SOLARIS_4_0)
#	define ILT_CPP_NAME			SunCC 4.0
#endif

#if defined(ILT_CPP_HPCC_03_65)
#	define ILT_CPP_NAME			HP C++ 3.65
#endif

#if defined(ILT_CPP_HPCC_10_01)
#	define ILT_CPP_NAME			HP C++ 10.01
#endif

#if defined(ILT_CPP_XLC_2_1)
#	define ILT_CPP_NAME			xlC 2.1
#endif

#if defined(ILT_CPP_SGICC_3_2)
#	define ILT_CPP_NAME			CC 3.2
#endif

#if defined(ILT_CPP_SGICC_4)
#	define ILT_CPP_NAME			CC 4
#endif

#if defined(ILT_CPP_SGICC_6_2)
#	define ILT_CPP_NAME			CC 6.2
#endif

#if defined(ILT_CPP_AXPCC)
#	define ILT_CPP_NAME			DEC C++ 1.47
#endif

#if defined(ILT_CPP_GCC)
#	if defined(ILT_CPP_GCC_2_7)
#		define ILT_CPP_NAME		GNU C++ 2.7.x
#	else
#		define ILT_CPP_NAME		GNU C++
#	endif
#endif

#if defined(ILT_CPP_MSVC_2_0)
#	define ILT_CPP_NAME			MSVC 2.0
#endif

#if defined(ILT_CPP_MSVC_4_0)
#	define ILT_CPP_NAME			MSVC 4.0
#endif



/**********************************************************************
 *
 * Object file extensions:
 *
 * 	ILT_OS_O_EXT
 * 	ILT_OS_O_EXT_S
 * 	ILT_OS_SO_EXT
 * 	ILT_OS_SO_EXT_S
 * 	ILT_OS_EXE_EXT
 * 	ILT_OS_EXE_EXT_S
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	define ILT_OS_EXE_EXT
#	define ILT_OS_EXE_EXT_S			""
#	define ILT_OS_O_EXT			.o
#	define ILT_OS_O_EXT_S			".o"
#	if defined(ILT_OS_UNIX_SUNOS)
#		define ILT_OS_SO_EXT		.so.1.0
#		define ILT_OS_SO_EXT_S		".so.1.0"
#	endif
#	if defined(ILT_OS_UNIX_SOLARIS)
#		define ILT_OS_SO_EXT		.so
#		define ILT_OS_SO_EXT_S		".so"
#	endif
#	if defined(ILT_OS_UNIX_HPUX)
#		define ILT_OS_SO_EXT		.sl
#		define ILT_OS_SO_EXT_S		".sl"
#	endif
#	if defined(ILT_OS_UNIX_AIX)
#		define ILT_OS_SO_EXT		.o
#		define ILT_OS_SO_EXT_S		".o"
#	endif
#	if defined(ILT_OS_UNIX_IRIX)
#		define ILT_OS_SO_EXT		.so
#		define ILT_OS_SO_EXT_S		".so"
#	endif
#	if defined(ILT_OS_UNIX_OSF)
#		define	ILT_OS_SO_EXT		.so
#		define	ILT_OS_SO_EXT_S		".so"
#	endif
#	if defined(ILT_OS_UNIX_LINUX)
#		define ILT_OS_SO_EXT		.so.1.0
#		define ILT_OS_SO_EXT_S		".so.1.0"
#	endif
#endif

#if defined(ILT_OS_WIN32)
#	define ILT_OS_EXE_EXT			.exe
#	define ILT_OS_EXE_EXT_S			".exe"
#	define ILT_OS_O_EXT			.obj
#	define ILT_OS_O_EXT_S			".obj"
#	define ILT_OS_SO_EXT			.dll
#	define ILT_OS_SO_EXT_S			".dll"
#endif


/**********************************************************************
 *
 * Architecture-dependent derived flags
 *
 **********************************************************************/

/*
 * ILT_ARC_BIGENDIAN.
 * Set this if the CPU is *not* big endian.
 */

#if defined(ILT_ARC_I386) || defined(ILT_ARC_ALPHA)
#	define ILT_ARC_BIGENDIAN
#endif


/**********************************************************************
 *
 * System-dependent derived flags
 *
 **********************************************************************/

/*
 * ILT_OS_UNIX_BSD.
 */

#if defined(ILT_OS_UNIX_SUNOS)
#	define ILT_OS_UNIX_BSD
#endif


/*
 * ILT_HAS_NDBM.
 */

#define ILT_HAS_NDBM


/*
 * ILT_HAS_MEMMOVE.
 */

#if !defined(ILT_OS_UNIX_BSD)
#	define ILT_HAS_MEMMOVE
#endif


/*
 * ILT_UNDERSCORE_SETJMP.
 */

#if defined(ILT_OS_UNIX_SUNOS)
#	define ILT_USE_UNDERSCORE_SETJMP
#endif


/*
 * ILT_OS_HAS_NO_VFORK.
 */

#if !defined(ILT_OS_UNIX) \
    || defined(ILT_OS_UNIX_AIX) \
    || defined(ILT_OS_UNIX_IRIX)
#	define ILT_OS_HAS_NO_VFORK
#endif


/*
 * ILT_DATA_BASE.
 */

#if defined(ILT_OS_UNIX_OSF)
#       define ILT_DATA_BASE 0x140000000
#endif

#if defined(ILT_OS_UNIX_SUNOS)
#       define ILT_DATA_BASE 0x0
#endif

#if defined(ILT_OS_UNIX_SOLARIS) && defined(ILT_ARC_SPARC)
#       define ILT_DATA_BASE 0x0
#endif

#if defined(ILT_OS_UNIX_SOLARIS) && defined(ILT_ARC_I386)
#	define ILT_DATA_BASE 0x08000000
#endif

#if defined(ILT_OS_UNIX_HPUX)
#       define ILT_DATA_BASE 0x40000000
#endif

#if defined(ILT_OS_UNIX_IRIX)
#       define ILT_DATA_BASE 0x10000000
#endif

#if defined(ILT_OS_UNIX_AIX)
#       define ILT_DATA_BASE 0x20050000
#endif

#if defined(ILT_OS_UNIX_LINUX)
	/* 0x0 for a.out executables, 0x08000000 for ELF executables. */
#	define ILT_DATA_BASE 0x08000000
#endif

#if defined(ILT_OS_WIN32_WINNT)
#       define ILT_DATA_BASE 0x0
#endif


/**********************************************************************
 *
 * Compiler-dependent derived flags
 *
 **********************************************************************/

/*
 * ILT_CC_HAS_NO_VOLATILE.
 */

#if defined(ILT_CC_SUNCC_SUNOS)
#	define ILT_CC_HAS_NO_VOLATILE
#endif


/*
 * ILT_CC_HAS_ANSI_VOLATILE.
 */

#if defined(ILT_CC_AXPCC) || defined(ILT_CC_GCC)
#	define ILT_CC_HAS_ANSI_VOLATILE
#endif


/*
 * ILT_CC_HAS_CONST.
 */

#if !defined(ILT_CC_SUNCC_SUNOS) && !defined(ILT_CC_HPCC)
#	define ILT_CC_HAS_CONST
#endif


/*
 * ILT_CC_SHARP_GLUE.
 */

#if defined(__STDC__) || defined(ILT_CC_MSVC) || defined(ILT_CC_SUNCC_SOLARIS)
#	define ILT_CC_SHARP_GLUE
#endif


/*
 * ILT_CPP_SHARP_STRING.
 */

#if !defined(ILT_CPP_SUNCC_SUNOS_2_1)
#	define ILT_CPP_SHARP_STRING
#endif


/*
 * ILT_CPP_BOOL.
 * Define this if the C++ compiler has the `bool' type built-in.
 */

#if defined(__GNUG__)
#	if (__GNUG__ * 1000 + __GNUC_MINOR__ >= 2006) /* g++ 2.6.0 and newer */
#		define ILT_CPP_BOOL
#	endif
#endif


/*
 * ILT_OS_REMOVABLE_EXECUTABLE
 */

#if !defined(ILT_OS_WIN32) && !defined(ILT_OS_UNIX_HPUX)
#	define ILT_OS_REMOVABLE_EXECUTABLE
#endif

#if !defined(ILT_OS_WIN32)
#	define ILT_OS_RENAMABLE_EXECUTABLE
#endif



/**********************************************************************
 *
 * Build command:
 *
 * 	ILT_PORT_BUILD_CMD
 * 	ILT_PORT_DISTCLEAN_CMD
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	define ILT_PORT_BUILD_CMD	<$ILT_ROOT_DIR$>/<$ILT_PRODUCT_DIR$>/<$ILT_TALK_PORT$>/build
#endif

#if defined(ILT_OS_WIN32)
#	define ILT_PORT_BUILD_CMD
#endif

#if defined(ILT_LEV_DISTRIB)
#	define ILT_PORT_DISTCLEAN_CMD	<$ILT_ROOT_DIR$>/<$ILT_PRODUCT_DIR$>/<$ILT_TALK_PORT$>/distclean
#else
#	define ILT_PORT_DISTCLEAN_CMD
#endif


/**********************************************************************
 *
 * Include directories
 *
 * 	ILT_PORT_INCLUDES
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	define ILT_PORT_INCLUDES	-I$<$ILT_DIR_VAR$>/talk/common \
    					-I$<$ILT_DIR_VAR$>/talk/<$ILT_TALK_PORT$>
#endif

#if defined(ILT_OS_WIN32)
#	define ILT_PORT_INCLUDES	/I%<$ILT_DIR_VAR$>%\\\\talk\\\\common \
    					/I%<$ILT_DIR_VAR$>%\\\\talk\\\\<$ILT_TALK_PORT$>
#endif


/**********************************************************************
 *
 * Include os-family specific macros
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	include <iltsys.unix.h>
#endif

#if defined(ILT_OS_WIN32)
#	include <iltsys.win32.h>
#endif

#endif /* defined(_ILT_ILTSYSTEM_INCL) */

/**********************************************************************
 *
 * ILM flag
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX_SUNOS_4_1_3_U1)
#	if defined(ILT_CPP_SUNCC_SUNOS_2_1)
#		define IL_SUNCC2_1
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_3_0)
#		define SPARC_4_3_0 /* obsolete */
#		define IL_SPARC4
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_4_0)
#		define SPARC_4_4_0 /* obsolete */
#		define IL_SPARC4
#	endif
#	if defined(ILT_CPP_GCC)
#		define IL_SPARC4
#	endif
#endif

#if defined(ILT_OS_UNIX_SOLARIS_5_4) && defined(ILT_ARC_SPARC)
#	if defined(ILT_CPP_SUNCC_SOLARIS_3_0)
#		define SPARC_5_3_0 /* obsolete */
#		define IL_SPARC5
#	endif
#	if defined(ILT_CPP_SUNCC_SOLARIS_4_0) /* Was solaris */
#		define SPARC_5_4_0 /* obsolete */
#		define IL_SPARC5
#	endif
#	if defined(ILT_CPP_GCC)
#		define IL_SPARC5
#	endif
#endif

#if defined(ILT_OS_WIN32_WINNT_3_5)
#	if defined(ILT_CC_MSVC)
#		define VISUALC
#		define WIN32
#		define Windows
#	endif
#endif

