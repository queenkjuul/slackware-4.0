#include <stdio.h>
#include "ratio.h"

/********/
/* demo */
/********/

static void ratiotest()
/* A test, showing that rational arithmetic is EXACT */
{
  int intervals = 10;
  ratio step = ratio(1, intervals);
  ratio min = 0;
  ratio max = 1;
  ratio i;

  int loop = 0;
  printf("\nLooping in [0,1) by 1/%d using rational arithmetic:\n", intervals);
  for (i = min; i < max; i+=step)
    printf("%2d i=%f   precisely: i=%s\n", ++loop, (double)i, (char*)i); 
  if (loop!=intervals)
    printf("** %d too many loops!\n", loop-intervals);

  loop = 0;
  printf("\nLooping in [0,1] by 1/%d using rational arithmetic:\n", intervals);
  for (i = min; i <= max; i+=step)
    printf("%2d i=%f   precisely: i=%s\n", ++loop, (double)i, (char*)i); 
  if (loop!=intervals+1)
    printf("** missing %d loop(s)!\n", (intervals+1)-loop);

  fflush(stdout);
}

static void floattest()
/* A test, showing that double arithmetic is APPROXIMATE */
{
  int intervals = 10;
  double step = 1.0 / intervals;
  double min = 0;
  double max = 1;
  double i;

  int loop = 0;
  printf("\nLooping in [0,1) by 1/%d using double arithmetic:\n", intervals);
  for (i=min; i<max; i+=step)
    printf("%2d i=%f\n", ++loop, i);
  if (loop!=intervals)
    printf("** %d too many loops!\n", loop-intervals);

  loop = 0;
  printf("\nLooping in [0,1] by 1/%d using double arithmetic:\n", intervals);
  for (i=min; i<=max; i+=step)
    printf("%2d i=%f\n", ++loop, i);
  if (loop!=intervals+1)
    printf("** missing %d loop(s)!\n", (intervals+1)-loop);

  fflush(stdout);
}

int main(int argc, char** argv, char** envp)
{
  ratio_init(argc, argv, envp);
  ratiotest();
  floattest();
  return 0;
}
