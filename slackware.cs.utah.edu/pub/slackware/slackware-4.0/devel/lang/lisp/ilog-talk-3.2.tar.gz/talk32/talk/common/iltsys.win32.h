/**********************************************************************
 *
 * Definition for Win32 port family.
 *
 **********************************************************************/

/**********************************************************************
 * 
 * C compiler flags:
 *
 * 	ILT_CC_CMD_DEBUG
 * 	ILT_CC_CMD_OPTIM
 *
 **********************************************************************/

#define ILT_CC_CMD			cl

#define ILT_CC_CMD_DEBUG		/Od /Z7

#define ILT_CC_CMD_OPTIM		/O1

#define ILT_CC_CMD_DEFS			/DWIN32 /D_CONSOLE /D_POSIX_

#define ILT_CRT_LIBS			%ILT_DIR%\\\\sdbm\\\\libsdbm.lib \
					oldnames.lib wsock32.lib \
					kernel32.lib user32.lib

#define ILT_LD_CMD			link

#define ILT_LD_CMD_FLAGS		/nologo /debug /pdb:none /nodefaultlib:libc

/* The /MD and /nodefaultlib:libc belong together. Change both or none. */

#define ILT_CC_CMD_FLAGS		/nologo /G4 /W0 /MD

#define ILT_CPP_CMD			cl

#define ILT_CPP_CMD_FLAGS		/nologo /G4 /W0 /MD

#define ILT_CPP_CMD_S			"cl"

#define ILT_CPP_PREP_CMD_S		"cl /E"
