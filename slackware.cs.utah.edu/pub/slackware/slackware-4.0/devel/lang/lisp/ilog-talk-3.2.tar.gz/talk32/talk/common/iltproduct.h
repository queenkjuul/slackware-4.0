/**********************************************************************
 *
 * Definition for products.
 *
 **********************************************************************/

#if !defined(_ILT_ILTPRODUCT_INCL)
#define _ILT_ILTPRODUCT_INCL

#include <iltlevel.h>
#include <iltproductdef.h>

#define ILT_PRODUCT_ALL_PORTS			sparc_4_2.1 \
						sparc_4_3.0 \
						sparc_4_4.0 \
						sparc_4_gnu \
						sparc_5_3.0 \
						sparc_5_4.0 \
						sparc_5_gnu \
						hp700 \
						hp_10 \
						rs6000 \
						sgi_5.2_3 \
						sgi_5.3_4 \
						sgi_6.2_6.2 \
						msvc4 \
						alpha_3 \
						i86_linux1.2_gnu2.7 \
						i86_sunos5_3.0 \
						i86_sunos5_4.0

/* machines for i86_sunos5_4.0 are currently not up. */
#define ILT_PRODUCT_TALK_PORTS			sparc_4_2.1 \
						sparc_4_3.0 \
						sparc_4_4.0 \
						sparc_4_gnu \
						sparc_5_3.0 \
						sparc_5_4.0 \
						sparc_5_gnu \
						hp700 \
						hp_10 \
						rs6000 \
						sgi_5.2_3 \
						sgi_5.3_4 \
						sgi_6.2_6.2 \
						msvc4 \
						alpha_3 \
						i86_linux1.2_gnu2.7 \
						i86_sunos5_3.0 \
						i86_sunos5_4.0

#if defined(ILT_PROD_TALK)
#	define ILT_PRODUCT_DIR			talk
#	define ILT_PRODUCT_LIBS			libiltcrt libiltrt \
						libilteval libiltdev \
						libiltcpb libiltcpp \
						libiltcpm
#	define ILT_PRODUCT_PORTS		ILT_PRODUCT_TALK_PORTS
#endif

#if defined(ILT_PROD_CPPPARSE)
#	define ILT_PRODUCT_DIR			cppparse
#	define ILT_PRODUCT_LIBS
#	define ILT_PRODUCT_PORTS		ILT_PRODUCT_TALK_PORTS
#endif

#if defined(ILT_PROD_ILTCPLIB)
#	define ILT_PRODUCT_DIR			iltcplib
#	define ILT_PRODUCT_LIBS			libiltcplibe libiltcplibm
#	define ILT_PRODUCT_PORTS		ILT_PRODUCT_TALK_PORTS
#endif

#if defined(ILT_PROD_ILTVIEWS)
#	define ILT_PRODUCT_DIR			iltviews
#	define ILT_PRODUCT_LIBS			libiltviewse libiltviewsm \
						winviews views ilvedit ilvvar
#	define ILT_PRODUCT_PORTS		sparc_4_2.1 \
						sparc_4_3.0 \
						sparc_4_4.0 \
						sparc_4_gnu \
						sparc_5_3.0 \
						sparc_5_4.0 \
						sparc_5_gnu \
						hp700 \
						hp_10 \
						rs6000 \
						sgi_5.2_3 \
						sgi_5.3_4 \
						msvc4 \
						alpha_3 \
						i86_linux1.2_gnu2.7 \
						i86_sunos5_4.0
#endif

/*
 * Build command
 */

#if defined(ILT_PROD_TALK)
#	if defined(ILT_LEV_WORK)
#		define ILT_PROD_BUILD_CMD	<$ILT_ROOT_DIR$>/<$ILT_PRODUCT_DIR$>/bin/build
#	else
#		define ILT_PROD_BUILD_CMD
#	endif
#else
#	define ILT_PROD_BUILD_CMD
#endif /* defined(ILT_PROD_TALK) */

#if defined(ILT_PROD_TALK)
#	if defined(ILT_LEV_DISTRIB)
#		define ILT_PROD_DISTCLEAN_CMD	<$ILT_ROOT_DIR$>/<$ILT_PRODUCT_DIR$>/bin/distclean
#	else
#		define ILT_PROD_DISTCLEAN_CMD
#	endif
#else
#	define ILT_PROD_DISTCLEAN_CMD
#endif /* defined(ILT_PROD_TALK) */

#endif /* !defined(_ILT_ILTPRODUCT_INCL) */
