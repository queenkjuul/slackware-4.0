/***************************/
/* C++ Rational arithmetic */
/***************************/

/*

  USAGE:
  
  Call ratio_init once before using the rational number.
  
  Use the class "ratio" for rational arithmetic, where the rational
  arithmetic (+ - / * < > =) and its derivates (++ += unary- etc) are
  defined; other operators on type "int" (<< >> | & etc) are not
  defined.
  
  */

void ratio_init(int argc, char** argv, char** envp);

/* RATIO class */

class ratio {
private:
  void *_r;
  ratio(void* iR) { _r = iR; }
public:
  ratio();
  ratio(long);
  ratio(int);
  ratio(ratio, ratio);
  ratio(const ratio&);
  operator double();
  operator char*();
  int operator<(ratio);
  int operator>(ratio);
  int operator<=(ratio);
  int operator>=(ratio);
  int operator==(ratio);
  ratio operator+();
  ratio operator-();
  ratio operator+(ratio);
  ratio operator-(ratio);
  ratio operator*(ratio);
  ratio operator/(ratio);
  ratio operator+=(ratio);
  ratio operator-=(ratio);
  ratio operator*=(ratio);
  ratio operator/=(ratio);
};

/* wild combinaison with C++ integer types (long was not enough,
   because 0 is an int, requirering a conversion to long */

ratio operator+(ratio, long );
ratio operator+(long , ratio);
ratio operator+(ratio, int  );
ratio operator+(int  , ratio);
ratio operator-(ratio, long );
ratio operator-(long , ratio);
ratio operator-(ratio, int  );
ratio operator-(int  , ratio);
ratio operator*(ratio, long );
ratio operator*(long , ratio);
ratio operator*(ratio, int  );
ratio operator*(int  , ratio);
ratio operator/(ratio, long );
ratio operator/(long , ratio);
ratio operator/(ratio, int  );
ratio operator/(int  , ratio);
ratio operator+=(ratio&, long);
ratio operator+=(ratio&, int );
ratio operator-=(ratio&, long);
ratio operator-=(ratio&, int );
ratio operator*=(ratio&, long);
ratio operator*=(ratio&, int );
ratio operator/=(ratio&, long);
ratio operator/=(ratio&, int );
ratio operator++(ratio&);
ratio operator--(ratio&);
