/*  Abeille (rev 2.000000) object code for module iltrune (level standard)  */
/*  Generated Thu Jun 06 00:33:05 1996 MET DST on sparc_5_4.0 by ILOG Talk  */
#define ABEILLE_VERSION 20

/*  Include files                                                           */
#include "llincludes.h"

/*  Talk literal handling                                                   */
static LL_vector o_llo_iltrune_v;
static LL_object llo_iltrune_v_code_init_fn();

/*  Module Definitions                                                      */
extern LL_object llo_iltrune_elaborate_iltrune();
#define lls_elaborate_iltrune_001 LL_LSYMBOL(llo_iltrune_v[0])
static LL_object llo_iltrune_015();
static LL_object llo_iltrune_end_016();

/*  External Definitions                                                    */

/*  Imported definitions                                                    */
#define lls_llo_eval_loop LL_LSYMBOL(llo_iltrune_v[1])
#define lls_llo_debug LL_LSYMBOL(llo_iltrune_v[2])
#define lls_llo_system8configuration_flag LL_LSYMBOL(llo_iltrune_v[3])
#define lls_llo_initialize_talk LL_LSYMBOL(llo_iltrune_v[4])

/*  Talk definitions                                                        */
static LL_object llo_iltrune_015() { return(ll_nil); }

/*  Talk module elaboration                                                 */

extern LL_object  llo_iltrune_elaborate_iltrune(llo_fnobj_003, llo_nb_args_004)
LL_object  llo_fnobj_003;
int  llo_nb_args_004;
{
 LL_object  llo_0prog10res00_019;
 LL_object  abc_tag__018;
 LLJMP_BUF  abc_jump_buffer__017;
 LL_object  llo_internal80or0tmp01_014;
 LL_object  llo_internal80or0tmp00_013;
 LL_object  llo_form_input_mode_p_012;
 LL_object  llo_debugp_011;
 LL_object  llo_welcome_message_010;
 LL_object  llo_result_prompt_009;
 LL_object  llo_prompt_008;
 LL_object  llo_init_file_007;
 LL_object  llo_no_init_file_p_006;
 LL_object  llo_silentp_005;
 LL_vector llo_iltrune_v= o_llo_iltrune_v;
 LL_DCL

 if ((llo_nb_args_004 > 0))
  llabc_argument_fault(llo_iltrune_v[0], 0, 0, llo_nb_args_004);

 {
 llo_register_object(o_llo_iltrune_v);
 
   {
   LL_object  arg_020;
   
   arg_020= llo_iltrune_v_code_init_fn();
   
   o_llo_iltrune_v= ll_decode_literals(arg_020);
   };
 
   llo_iltrune_v= o_llo_iltrune_v;
 
  {
   if (LLSETJMP(abc_jump_buffer__017))
   {
    return(ll_last_throw_value());}
   else 
   {
    {
     abc_tag__018= llo_iltrune_v[5];
    ll_push_catch_frame(abc_tag__018, abc_jump_buffer__017);
    
     
      {
      ;
      
       
	llo_silentp_005= LO_SFUNCALL(lls_llo_system8configuration_flag, (LL_FVAL(lls_llo_system8configuration_flag), 1,llo_iltrune_v[6]));
	
	llo_no_init_file_p_006= LO_SFUNCALL(lls_llo_system8configuration_flag, (LL_FVAL(lls_llo_system8configuration_flag), 1,llo_iltrune_v[7]));
	
	llo_init_file_007= LO_SFUNCALL(lls_llo_system8configuration_flag, (LL_FVAL(lls_llo_system8configuration_flag), 1,llo_iltrune_v[8]));
	
	
	 llo_internal80or0tmp00_013= LO_SFUNCALL(lls_llo_system8configuration_flag, (LL_FVAL(lls_llo_system8configuration_flag), 1,llo_iltrune_v[9]));
	 
	 {
	  if (ll_nil != llo_internal80or0tmp00_013)
	  {
	   llo_prompt_008= llo_internal80or0tmp00_013;}
	  else 
	  {       llo_prompt_008= llo_iltrune_v[10];};};
	
	
	 llo_internal80or0tmp01_014= LO_SFUNCALL(lls_llo_system8configuration_flag, (LL_FVAL(lls_llo_system8configuration_flag), 1,llo_iltrune_v[11]));
	 
	 {
	  if (ll_nil != llo_internal80or0tmp01_014)
	  {
	   llo_result_prompt_009= llo_internal80or0tmp01_014;}
	  else 
	  {       llo_result_prompt_009= llo_iltrune_v[12];};};
	
	llo_welcome_message_010= LO_SFUNCALL(lls_llo_system8configuration_flag, (LL_FVAL(lls_llo_system8configuration_flag), 1,llo_iltrune_v[13]));
	
	llo_debugp_011= LO_SFUNCALL(lls_llo_system8configuration_flag, (LL_FVAL(lls_llo_system8configuration_flag), 1,llo_iltrune_v[14]));
	
	llo_form_input_mode_p_012= LO_SFUNCALL(lls_llo_system8configuration_flag, (LL_FVAL(lls_llo_system8configuration_flag), 1,llo_iltrune_v[15]));
	
	{
	
	 {
	  if (ll_nil != llo_debugp_011)
	  {LO_SFUNCALL(lls_llo_debug, (LL_FVAL(lls_llo_debug), 1,llo_iltrune_v[16]));}
	  else 
	  {       ll_nil;};};
	LO_SFUNCALL(lls_llo_initialize_talk, (LL_FVAL(lls_llo_initialize_talk), 12,llo_iltrune_v[17], llo_iltrune_v[16], llo_iltrune_v[18], 
llo_silentp_005, llo_iltrune_v[19], llo_no_init_file_p_006, llo_iltrune_v[20], llo_init_file_007, llo_iltrune_v[21], llo_welcome_message_010, 
	 llo_iltrune_v[22], llo_form_input_mode_p_012));
	
	 {
	  if (ll_nil != llo_silentp_005)
	  {LO_SFUNCALL(lls_llo_eval_loop, (LL_FVAL(lls_llo_eval_loop), 4,llo_iltrune_v[23], llo_iltrune_v[24], ll_nil, llo_silentp_005));}
	  else 
	  {LO_SFUNCALL(lls_llo_eval_loop, (LL_FVAL(lls_llo_eval_loop), 4,llo_prompt_008, llo_result_prompt_009, ll_nil, llo_silentp_005));};};
	};
      
       ll_register_module_level(llo_iltrune_v[25], (char *)llo_iltrune_end_016-(char *)llo_iltrune_015, llo_iltrune_v[26]);
;
      
       llo_0prog10res00_019= LL_LISP_OBJECT(llo_iltrune_v);
      };
      
      {
      ll_pop_catch_frame();
      
       return(llo_0prog10res00_019);
      };
    };};};
 };
}

static LL_object llo_iltrune_v_code_init_fn()
{ static LLCONST char* llo_iltrune_v_code[1] =
{
"0 [\0773 Qelaborate-iltrune\0773 Ieval-loop\0773 Edebug@\0773\
 Fsystem3 Rconfiguration-flag\0773 Oinitialize-talk@\077\
3 Hinternal3 K*error-tag*3 Fsilent3 Lno-init-file3\
 Iinit-file3 Fprompt3 B\077 3 Mresult-prompt3 B= 3 Ow\
elcome-message3 Edebug3 Oform-input-mode\0773 At< A3 \
Phandle-signals-p< A3 Gsilentp< A3 Nno-init-file-p\
< A3 Iinit-file< A3 Owelcome-message< A3 Qform-inp\
ut-mode-p3 @3 @\0773 Giltrune\0773 Hstandard!"}
;
  return (LL_object )llo_iltrune_v_code; }
static LL_object llo_iltrune_end_016() { return(ll_nil); }


/*  End of AbeilleC object code for module iltrune.                         */
