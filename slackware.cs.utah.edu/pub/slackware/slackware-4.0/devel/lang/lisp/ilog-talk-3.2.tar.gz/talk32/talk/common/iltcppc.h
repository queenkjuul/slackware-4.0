/*****************************************************************************

 ILTCPPC.H:  Include file for generated C++ files

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1994-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/iltcppc.h,v 1.3 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
*****************************************************************************/

// This header file is included inside an extern "C",  so we don't
// need to do it here.

#include <talk.h>

// Needed for stubs.
extern double *ll_make_float_copying_c(double);
extern void *ilt_put_hash_table_eq(void*, void*, void*);
extern void (**ilt_find_callback(void*, int))(void*, long, ...);
extern void (**ilt_find_compiled_callback(void*))(void*, long, ...);
