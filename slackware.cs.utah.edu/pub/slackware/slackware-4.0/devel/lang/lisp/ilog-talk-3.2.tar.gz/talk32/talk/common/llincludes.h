/**********************************************************************
 *
 * System macros.
 *
 **********************************************************************/

#if !defined(_ILT_ILTSYSTEM_INCL)
#define _ILT_ILTSYSTEM_INCL

#include <iltlevel.h>
#include <iltproduct.h>
#include <iltportdef.h>

/*
 * NOTE:
 * No trailing spaces and no comments after the values of the macros, please!
 * Otherwise spaces may end up in the replacements. Not good.
 */

/**********************************************************************
 *
 * Name of the TALK base directory variable:
 *
 * 	ILT_DIR_VAR
 *
 **********************************************************************/

#define ILT_DIR_VAR				ILT_DIR


/**********************************************************************
 *
 * ILOG usual root directory:
 *
 * 	ILT_ILOG_DIRECTORY
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	define ILT_ILOG_DIRECTORY		/usr/ilog
#endif

#if defined(ILT_OS_WIN32)
#	define ILT_ILOG_DIRECTORY		\\usr\\ilog
#endif


/**********************************************************************
 *
 * Port directories, names and servers:
 *
 *	ILT_OS_NAME
 *	ILT_XEMACS_PORT
 * 	ILT_VIEWS_PORT
 * 	ILT_TALK_PORT
 * 	ILT_TALK_PORT_S
 * 	ILT_TALK_PORT_FAMILY_S
 *	ILT_PORT_SERVER
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX_SUNOS_4_1_3_U1)
#	define ILT_XEMACS1911_PORT		sparc-sun-sunos4.1.3
#	define ILT_XEMACS1913_PORT		sparc-sun-sunos4.1.3
#	if defined(ILT_CPP_SUNCC_SUNOS_2_1)
#		define ILT_VIEWS_PORT		sparc_4_2.1
#		define ILT_TALK_PORT		sparc_4_2.1
#		define ILT_TALK_PORT_SPARC_4_2_1
#		define ILT_TALK_PORT_S		"sparc_4_2.1"
#		define ILT_PORT_SERVER		reaumur
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_3_0) /* Was sun4 */
#		define ILT_VIEWS_PORT		sparc_4_3.0
#		define ILT_TALK_PORT		sparc_4_3.0
#		define ILT_TALK_PORT_SPARC_4_3_0
#		define ILT_TALK_PORT_S		"sparc_4_3.0"
#		define ILT_PORT_SERVER		reaumur
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_4_0)
#		define ILT_VIEWS_PORT		sparc_4_4.0
#		define ILT_TALK_PORT		sparc_4_4.0
#		define ILT_TALK_PORT_SPARC_4_4_0
#		define ILT_TALK_PORT_S		"sparc_4_4.0"
#		define ILT_PORT_SERVER		reaumur
#	endif
#	if defined(ILT_CPP_GCC)
#		define ILT_VIEWS_PORT		sparc_4_gnu
#		define ILT_TALK_PORT		sparc_4_gnu
#		define ILT_TALK_PORT_SPARC_4_GNU
#		define ILT_TALK_PORT_S		"sparc_4_gnu"
#		define ILT_PORT_SERVER		reaumur
#	endif
#endif

#if defined(ILT_OS_UNIX_SOLARIS_5_4) && defined(ILT_ARC_SPARC)
#	define ILT_XEMACS1911_PORT		sparc-sun-solaris2.3
                                             /* sparc-sun-solaris2.4 as well */
#	define ILT_XEMACS1913_PORT		sparc-sun-solaris2.4
#	if defined(ILT_CPP_SUNCC_SOLARIS_3_0)
#		define ILT_VIEWS_PORT		sparc_5_3.0
#		define ILT_TALK_PORT		sparc_5_3.0
#		define ILT_TALK_PORT_SPARC_5_3_0
#		define ILT_TALK_PORT_S		"sparc_5_3.0"
#		define ILT_PORT_SERVER		halles
#	endif
#	if defined(ILT_CPP_SUNCC_SOLARIS_4_0) /* Was solaris */
#		define ILT_VIEWS_PORT		sparc_5_4.0
#		define ILT_TALK_PORT		sparc_5_4.0
#		define ILT_TALK_PORT_SPARC_5_4_0
#		define ILT_TALK_PORT_S		"sparc_5_4.0"
#		define ILT_PORT_SERVER		halles
#	endif
#	if defined(ILT_CPP_GCC)
#		define ILT_VIEWS_PORT		sparc_5_gnu
#		define ILT_TALK_PORT		sparc_5_gnu
#		define ILT_TALK_PORT_SPARC_5_GNU
#		define ILT_TALK_PORT_S		"sparc_5_gnu"
#		define ILT_PORT_SERVER		halles
#	endif
#endif

#if defined(ILT_OS_UNIX_SOLARIS_5_4) && defined(ILT_ARC_I386)
#	define ILT_XEMACS1911_PORT		i486-pc-solaris2.1
#	define ILT_XEMACS1913_PORT		i386-unknown-solaris2.4
#	if defined(ILT_CPP_SUNCC_SOLARIS_3_0)
#		define ILT_VIEWS_PORT		i86_sunos5_3.0
#		define ILT_TALK_PORT		i86_sunos5_3.0
#		define ILT_TALK_PORT_I86_SUNOS5_3_0
#		define ILT_TALK_PORT_S		"i86_sunos5_3.0"
#		define ILT_PORT_SERVER		rivoli
#	endif
#	if defined(ILT_CPP_SUNCC_SOLARIS_4_0)
#		define ILT_VIEWS_PORT		i86_sunos5_4.0
#		define ILT_TALK_PORT		i86_sunos5_4.0
#		define ILT_TALK_PORT_I86_SUNOS5_4_0
#		define ILT_TALK_PORT_S		"i86_sunos5_4.0"
#		define ILT_PORT_SERVER		rivoli
#	endif
#endif

#if defined(ILT_OS_UNIX_HPUX_09_05)
#	define ILT_XEMACS1911_PORT		hppa1.1-hp-hpux9
#	define ILT_XEMACS1913_PORT		hppa1.1-hp-hpux9.05
#	define ILT_VIEWS_PORT			hp700
#	define ILT_TALK_PORT			hp700
#	define ILT_TALK_PORT_HP700
#	define ILT_TALK_PORT_S			"hp700"
#	define ILT_PORT_SERVER			issy
#endif

#if defined(ILT_OS_UNIX_HPUX_10_01)
#	define ILT_XEMACS1911_PORT		hppa1.1-hp-hpux9
#	define ILT_XEMACS1913_PORT		hppa1.0-hp-hpux10.00
#	define ILT_VIEWS_PORT			hp_10
#	define ILT_TALK_PORT			hp_10
#	define ILT_TALK_PORT_HP_10
#	define ILT_TALK_PORT_S			"hp_10"
#	define ILT_PORT_SERVER			pantin
#endif

#if defined(ILT_OS_UNIX_AIX_3_2)
#	define ILT_XEMACS1911_PORT		rs6000-ibm-aix3.2
#	define ILT_XEMACS1912_PORT		rs6000-ibm-aix3.2.5
#	define ILT_XEMACS1913_PORT		rs6000-ibm-aix3.2.5
#	define ILT_VIEWS_PORT			rs6000
#	define ILT_TALK_PORT			rs6000
#	define ILT_TALK_PORT_RS6000
#	define ILT_TALK_PORT_S			"rs6000"
#	define ILT_PORT_SERVER			courcelles
#endif
#if defined(ILT_OS_UNIX_AIX_4_1)
#	define ILT_XEMACS1911_PORT		rs6000-ibm-aix3.2
#	define ILT_XEMACS1912_PORT		rs6000-ibm-aix4.1.1
#	define ILT_XEMACS1913_PORT		rs6000-ibm-aix4.1.1
#	define ILT_VIEWS_PORT			rs6000
#	define ILT_TALK_PORT			rs6000
#	define ILT_TALK_PORT_RS6000
#	define ILT_TALK_PORT_S			"rs6000"
#	define ILT_PORT_SERVER			courcelles
#endif

#if defined(ILT_OS_UNIX_IRIX_5_2)
#	define ILT_XEMACS1911_PORT		mips-sgi-irix5.2
#	define ILT_XEMACS1913_PORT		mips-sgi-irix5.2
#	define ILT_VIEWS_PORT			sgi_5.2_3
#	define ILT_TALK_PORT			sgi_5.2_3
#	define ILT_TALK_PORT_SGI_5_2_3
#	define ILT_TALK_PORT_S			"sgi_5.2_3"
#	define ILT_PORT_SERVER			iena
#endif

#if defined(ILT_OS_UNIX_IRIX_5_3)
#	define ILT_XEMACS1911_PORT		mips-sgi-irix5.2
#	define ILT_XEMACS1913_PORT		mips-sgi-irix5.3
#	define ILT_VIEWS_PORT			sgi_5.3_4
#	define ILT_TALK_PORT			sgi_5.3_4
#	define ILT_TALK_PORT_SGI_5_3_4
#	define ILT_TALK_PORT_S			"sgi_5.3_4"
#	define ILT_PORT_SERVER			diderot
#endif

#if defined(ILT_OS_UNIX_IRIX_6_2)
#	define ILT_XEMACS1911_PORT		mips-sgi-irix5.2
#	define ILT_XEMACS1913_PORT		mips-sgi-irix5.3
#	if defined(ILT_ARC_MIPS64)
#		define ILT_VIEWS_PORT		sgi64_6.2_6.2
#		define ILT_TALK_PORT		sgi64_6.2_6.2
#		define ILT_TALK_PORT_SGI64_6_2_6_2
#		define ILT_TALK_PORT_S		"sgi64_6.2_6.2"
#	else /* 32-bit executables */
#		define ILT_VIEWS_PORT		sgi_6.2_6.2
#		define ILT_TALK_PORT		sgi_6.2_6.2
#		define ILT_TALK_PORT_SGI_6_2_6_2
#		define ILT_TALK_PORT_S		"sgi_6.2_6.2"
#	endif
#	define ILT_PORT_SERVER			molitor
#endif

#if defined(ILT_OS_UNIX_OSF_3_0)
#	define ILT_XEMACS1911_PORT		alpha-dec-osf2.1
#	define ILT_XEMACS1913_PORT		alpha-dec-osf3.2
#	if defined(ILT_CC_AXPCC)
#		define ILT_VIEWS_PORT		alpha_3
#		define ILT_TALK_PORT		alpha_3
#		define ILT_TALK_PORT_ALPHA_3
#		define ILT_TALK_PORT_S		"alpha_3"
#		define ILT_PORT_SERVER		villiers
#	endif
#	if defined(ILT_CC_GCC)
#		define ILT_VIEWS_PORT		alpha_3_gnu
#		define ILT_TALK_PORT		alpha_3_gnu
#		define ILT_TALK_PORT_ALPHA_3_GNU
#		define ILT_TALK_PORT_S		"alpha_3_gnu"
#		define ILT_PORT_SERVER		villiers
#	endif
#endif

#if defined(ILT_OS_UNIX_LINUX_1_2)
#	define ILT_XEMACS1913_PORT		i486-unknown-linuxelf
#	define ILT_VIEWS_PORT			i86_linux1.2_gnu2.7
#	define ILT_TALK_PORT			i86_linux1.2_gnu2.7
#	define ILT_TALK_PORT_I86_LINUX1_2_GNU2_7
#	define ILT_TALK_PORT_S			"i86_linux1.2_gnu2.7"
#	define ILT_PORT_SERVER			maubourg
#endif

#if defined(ILT_OS_WIN32_WINNT_3_5)
#	if defined(ILT_CC_MSVC_2)
#		define ILT_VIEWS_PORT		msvc32
#		define ILT_TALK_PORT		msvc32
#		define ILT_TALK_PORT_MSVC32
#		define ILT_TALK_PORT_S		"msvc32"
#	endif
#	if defined(ILT_CC_MSVC_4)
#		define ILT_VIEWS_PORT		msvc4
#		define ILT_TALK_PORT		msvc4
#		define ILT_TALK_PORT_MSVC4
#		define ILT_TALK_PORT_S		"msvc4"
#	endif
#	define ILT_PORT_SERVER			maubourg
#endif

#if defined(ILT_OS_UNIX)
#		define ILT_TALK_PORT_FAMILY_S	"unix"
#endif

#if defined(ILT_OS_WIN32)
#		define ILT_TALK_PORT_FAMILY_S	"win32"
#endif

#define ILT_XEMACS_PORT				ILT_XEMACS1913_PORT


/**********************************************************************
 *
 * Architecture names:
 *
 * 	ILT_ARC_NAME
 *
 **********************************************************************/

#if defined(ILT_ARC_SPARC)
#		define ILT_ARC_NAME		sparc
#endif

#if defined(ILT_ARC_ALPHA)
#		define ILT_ARC_NAME		DEC/alpha
#endif

#if defined(ILT_ARC_HP_PREC)
#		define ILT_ARC_NAME		HP-PA
#endif

#if defined(ILT_ARC_I386)
#		define ILT_ARC_NAME		i386
#endif

#if defined(ILT_ARC_RS6000)
#		define ILT_ARC_NAME		rs6000
#endif

#if defined(ILT_ARC_MIPS)
#		define ILT_ARC_NAME		mips
#endif


/**********************************************************************
 *
 * OS names:
 *
 * 	ILT_OS_NAME
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX_SUNOS_4_1_3_U1)
#	define ILT_OS_NAME			SunOS 4.1.3_U1
#endif

#if defined(ILT_OS_UNIX_SOLARIS_5_4)
#	define ILT_OS_NAME			SunOS 5.3 or 5.4 (Solaris 2.3 or 2.4)
#endif

#if defined(ILT_OS_UNIX_HPUX_09_05)
#	define ILT_OS_NAME			HP-UX A.09.05
#endif

#if defined(ILT_OS_UNIX_HPUX_10_01)
#	define ILT_OS_NAME			HP-UX B.10.01
#endif

#if defined(ILT_OS_UNIX_AIX_3_2)
#	define ILT_OS_NAME			AIX 3.2
#endif
#if defined(ILT_OS_UNIX_AIX_4_1)
#	define ILT_OS_NAME			AIX 4.1
#endif

#if defined(ILT_OS_UNIX_IRIX_5_2)
#	define ILT_OS_NAME			IRIX 5.2
#endif

#if defined(ILT_OS_UNIX_IRIX_5_3)
#	define ILT_OS_NAME			IRIX 5.3
#endif

#if defined(ILT_OS_UNIX_IRIX_6_2)
#	define ILT_OS_NAME			IRIX 6.2
#endif

#if defined(ILT_OS_UNIX_OSF_3_0)
#	define ILT_OS_NAME			OSF1 V3.0
#endif

#if defined(ILT_OS_UNIX_LINUX_1_2)
#	define ILT_OS_NAME			Linux 1.2
#endif

#if defined(ILT_OS_WIN32_WINNT_3_5)
#	define ILT_OS_NAME			Windows NT 3.5
#endif


/**********************************************************************
 *
 * Make name:
 *
 * 	ILT_MAKE_NAME
 *
 **********************************************************************/

#if defined(ILT_OS_WIN32)
#	define	ILT_MAKE_NAME			nmake
#else
#	define	ILT_MAKE_NAME			make
#endif


/**********************************************************************
 *
 * C compiler names:
 *
 * 	ILT_CC_NAME
 *
 **********************************************************************/

#if defined(ILT_CC_SUNCC_SUNOS)
#	define ILT_CC_NAME			Bundled C compiler
#endif

#if defined(ILT_CC_SUNCC_SOLARIS_3_0)
#	define ILT_CC_NAME			Sun C 3.0
#endif

#if defined(ILT_CC_SUNCC_SOLARIS_4_0)
#	define ILT_CC_NAME			Sun C 4.0
#endif

#if defined(ILT_CC_HPCC_09_73)
#	define ILT_CC_NAME			HP C 9.73
#endif

#if defined(ILT_CC_HPCC_10_11)
#	define ILT_CC_NAME			HP C 10.11
#endif

#if defined(ILT_CC_XLC_1_3)
#	define ILT_CC_NAME			xlc 1.3
#endif
#if defined(ILT_CC_XLC_2_1)
#	define ILT_CC_NAME			xlc 2.1
#endif

#if defined(ILT_CC_SGICC_3_2)
#	define ILT_CC_NAME			C 3.2
#endif

#if defined(ILT_CC_SGICC_4)
#	define ILT_CC_NAME			C 4
#endif

#if defined(ILT_CC_SGICC_6_2)
#	define ILT_CC_NAME			C 6.2
#endif

#if defined(ILT_CC_AXPCC)
#	define ILT_CC_NAME			DEC C
#endif

#if defined(ILT_CC_GCC)
#	define ILT_CC_NAME			GNU C
#endif

#if defined(ILT_CC_MSVC_2_0)
#	define ILT_CC_NAME			MSVC 2.0
#endif

#if defined(ILT_CC_MSVC_4_0)
#	define ILT_CC_NAME			MSVC 4.0
#endif


/**********************************************************************
 *
 * C++ compiler names:
 *
 * 	ILT_CPP_NAME
 *
 **********************************************************************/

#if defined(ILT_CPP_SUNCC_SUNOS_2_1)
#	define ILT_CPP_NAME			SunCC 2.1
#endif

#if defined(ILT_CPP_SUNCC_SUNOS_3_0)
#	define ILT_CPP_NAME			SunCC 3.0
#endif

#if defined(ILT_CPP_SUNCC_SUNOS_4_0)
#	define ILT_CPP_NAME			SunCC 4.0
#endif

#if defined(ILT_CPP_SUNCC_SOLARIS_3_0)
#	define ILT_CPP_NAME			SunCC 3.0
#endif

#if defined(ILT_CPP_SUNCC_SOLARIS_4_0)
#	define ILT_CPP_NAME			SunCC 4.0
#endif

#if defined(ILT_CPP_HPCC_03_65)
#	define ILT_CPP_NAME			HP C++ 3.65
#endif

#if defined(ILT_CPP_HPCC_10_01)
#	define ILT_CPP_NAME			HP C++ 10.01
#endif

#if defined(ILT_CPP_XLC_2_1)
#	define ILT_CPP_NAME			xlC 2.1
#endif

#if defined(ILT_CPP_SGICC_3_2)
#	define ILT_CPP_NAME			CC 3.2
#endif

#if defined(ILT_CPP_SGICC_4)
#	define ILT_CPP_NAME			CC 4
#endif

#if defined(ILT_CPP_SGICC_6_2)
#	define ILT_CPP_NAME			CC 6.2
#endif

#if defined(ILT_CPP_AXPCC)
#	define ILT_CPP_NAME			DEC C++ 1.47
#endif

#if defined(ILT_CPP_GCC)
#	if defined(ILT_CPP_GCC_2_7)
#		define ILT_CPP_NAME		GNU C++ 2.7.x
#	else
#		define ILT_CPP_NAME		GNU C++
#	endif
#endif

#if defined(ILT_CPP_MSVC_2_0)
#	define ILT_CPP_NAME			MSVC 2.0
#endif

#if defined(ILT_CPP_MSVC_4_0)
#	define ILT_CPP_NAME			MSVC 4.0
#endif



/**********************************************************************
 *
 * Object file extensions:
 *
 * 	ILT_OS_O_EXT
 * 	ILT_OS_O_EXT_S
 * 	ILT_OS_SO_EXT
 * 	ILT_OS_SO_EXT_S
 * 	ILT_OS_EXE_EXT
 * 	ILT_OS_EXE_EXT_S
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	define ILT_OS_EXE_EXT
#	define ILT_OS_EXE_EXT_S			""
#	define ILT_OS_O_EXT			.o
#	define ILT_OS_O_EXT_S			".o"
#	if defined(ILT_OS_UNIX_SUNOS)
#		define ILT_OS_SO_EXT		.so.1.0
#		define ILT_OS_SO_EXT_S		".so.1.0"
#	endif
#	if defined(ILT_OS_UNIX_SOLARIS)
#		define ILT_OS_SO_EXT		.so
#		define ILT_OS_SO_EXT_S		".so"
#	endif
#	if defined(ILT_OS_UNIX_HPUX)
#		define ILT_OS_SO_EXT		.sl
#		define ILT_OS_SO_EXT_S		".sl"
#	endif
#	if defined(ILT_OS_UNIX_AIX)
#		define ILT_OS_SO_EXT		.o
#		define ILT_OS_SO_EXT_S		".o"
#	endif
#	if defined(ILT_OS_UNIX_IRIX)
#		define ILT_OS_SO_EXT		.so
#		define ILT_OS_SO_EXT_S		".so"
#	endif
#	if defined(ILT_OS_UNIX_OSF)
#		define	ILT_OS_SO_EXT		.so
#		define	ILT_OS_SO_EXT_S		".so"
#	endif
#	if defined(ILT_OS_UNIX_LINUX)
#		define ILT_OS_SO_EXT		.so.1.0
#		define ILT_OS_SO_EXT_S		".so.1.0"
#	endif
#endif

#if defined(ILT_OS_WIN32)
#	define ILT_OS_EXE_EXT			.exe
#	define ILT_OS_EXE_EXT_S			".exe"
#	define ILT_OS_O_EXT			.obj
#	define ILT_OS_O_EXT_S			".obj"
#	define ILT_OS_SO_EXT			.dll
#	define ILT_OS_SO_EXT_S			".dll"
#endif


/**********************************************************************
 *
 * Architecture-dependent derived flags
 *
 **********************************************************************/

/*
 * ILT_ARC_BIGENDIAN.
 * Set this if the CPU is *not* big endian.
 */

#if defined(ILT_ARC_I386) || defined(ILT_ARC_ALPHA)
#	define ILT_ARC_BIGENDIAN
#endif


/**********************************************************************
 *
 * System-dependent derived flags
 *
 **********************************************************************/

/*
 * ILT_OS_UNIX_BSD.
 */

#if defined(ILT_OS_UNIX_SUNOS)
#	define ILT_OS_UNIX_BSD
#endif


/*
 * ILT_HAS_NDBM.
 */

#define ILT_HAS_NDBM


/*
 * ILT_HAS_MEMMOVE.
 */

#if !defined(ILT_OS_UNIX_BSD)
#	define ILT_HAS_MEMMOVE
#endif


/*
 * ILT_UNDERSCORE_SETJMP.
 */

#if defined(ILT_OS_UNIX_SUNOS)
#	define ILT_USE_UNDERSCORE_SETJMP
#endif


/*
 * ILT_OS_HAS_NO_VFORK.
 */

#if !defined(ILT_OS_UNIX) \
    || defined(ILT_OS_UNIX_AIX) \
    || defined(ILT_OS_UNIX_IRIX)
#	define ILT_OS_HAS_NO_VFORK
#endif


/*
 * ILT_DATA_BASE.
 */

#if defined(ILT_OS_UNIX_OSF)
#       define ILT_DATA_BASE 0x140000000
#endif

#if defined(ILT_OS_UNIX_SUNOS)
#       define ILT_DATA_BASE 0x0
#endif

#if defined(ILT_OS_UNIX_SOLARIS) && defined(ILT_ARC_SPARC)
#       define ILT_DATA_BASE 0x0
#endif

#if defined(ILT_OS_UNIX_SOLARIS) && defined(ILT_ARC_I386)
#	define ILT_DATA_BASE 0x08000000
#endif

#if defined(ILT_OS_UNIX_HPUX)
#       define ILT_DATA_BASE 0x40000000
#endif

#if defined(ILT_OS_UNIX_IRIX)
#       define ILT_DATA_BASE 0x10000000
#endif

#if defined(ILT_OS_UNIX_AIX)
#       define ILT_DATA_BASE 0x20050000
#endif

#if defined(ILT_OS_UNIX_LINUX)
	/* 0x0 for a.out executables, 0x08000000 for ELF executables. */
#	define ILT_DATA_BASE 0x08000000
#endif

#if defined(ILT_OS_WIN32_WINNT)
#       define ILT_DATA_BASE 0x0
#endif


/**********************************************************************
 *
 * Compiler-dependent derived flags
 *
 **********************************************************************/

/*
 * ILT_CC_HAS_NO_VOLATILE.
 */

#if defined(ILT_CC_SUNCC_SUNOS)
#	define ILT_CC_HAS_NO_VOLATILE
#endif


/*
 * ILT_CC_HAS_ANSI_VOLATILE.
 */

#if defined(ILT_CC_AXPCC) || defined(ILT_CC_GCC)
#	define ILT_CC_HAS_ANSI_VOLATILE
#endif


/*
 * ILT_CC_HAS_CONST.
 */

#if !defined(ILT_CC_SUNCC_SUNOS) && !defined(ILT_CC_HPCC)
#	define ILT_CC_HAS_CONST
#endif


/*
 * ILT_CC_SHARP_GLUE.
 */

#if defined(__STDC__) || defined(ILT_CC_MSVC) || defined(ILT_CC_SUNCC_SOLARIS)
#	define ILT_CC_SHARP_GLUE
#endif


/*
 * ILT_CPP_SHARP_STRING.
 */

#if !defined(ILT_CPP_SUNCC_SUNOS_2_1)
#	define ILT_CPP_SHARP_STRING
#endif


/*
 * ILT_CPP_BOOL.
 * Define this if the C++ compiler has the `bool' type built-in.
 */

#if defined(__GNUG__)
#	if (__GNUG__ * 1000 + __GNUC_MINOR__ >= 2006) /* g++ 2.6.0 and newer */
#		define ILT_CPP_BOOL
#	endif
#endif


/*
 * ILT_OS_REMOVABLE_EXECUTABLE
 */

#if !defined(ILT_OS_WIN32) && !defined(ILT_OS_UNIX_HPUX)
#	define ILT_OS_REMOVABLE_EXECUTABLE
#endif

#if !defined(ILT_OS_WIN32)
#	define ILT_OS_RENAMABLE_EXECUTABLE
#endif



/**********************************************************************
 *
 * Build command:
 *
 * 	ILT_PORT_BUILD_CMD
 * 	ILT_PORT_DISTCLEAN_CMD
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	define ILT_PORT_BUILD_CMD	<$ILT_ROOT_DIR$>/<$ILT_PRODUCT_DIR$>/<$ILT_TALK_PORT$>/build
#endif

#if defined(ILT_OS_WIN32)
#	define ILT_PORT_BUILD_CMD
#endif

#if defined(ILT_LEV_DISTRIB)
#	define ILT_PORT_DISTCLEAN_CMD	<$ILT_ROOT_DIR$>/<$ILT_PRODUCT_DIR$>/<$ILT_TALK_PORT$>/distclean
#else
#	define ILT_PORT_DISTCLEAN_CMD
#endif


/**********************************************************************
 *
 * Include directories
 *
 * 	ILT_PORT_INCLUDES
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	define ILT_PORT_INCLUDES	-I$<$ILT_DIR_VAR$>/talk/common \
    					-I$<$ILT_DIR_VAR$>/talk/<$ILT_TALK_PORT$>
#endif

#if defined(ILT_OS_WIN32)
#	define ILT_PORT_INCLUDES	/I%<$ILT_DIR_VAR$>%\\\\talk\\\\common \
    					/I%<$ILT_DIR_VAR$>%\\\\talk\\\\<$ILT_TALK_PORT$>
#endif


/**********************************************************************
 *
 * Include os-family specific macros
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX)
#	include <iltsys.unix.h>
#endif

#if defined(ILT_OS_WIN32)
#	include <iltsys.win32.h>
#endif

#endif /* defined(_ILT_ILTSYSTEM_INCL) */

/**********************************************************************
 *
 * ILM flag
 *
 **********************************************************************/

#if defined(ILT_OS_UNIX_SUNOS_4_1_3_U1)
#	if defined(ILT_CPP_SUNCC_SUNOS_2_1)
#		define IL_SUNCC2_1
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_3_0)
#		define SPARC_4_3_0 /* obsolete */
#		define IL_SPARC4
#	endif
#	if defined(ILT_CPP_SUNCC_SUNOS_4_0)
#		define SPARC_4_4_0 /* obsolete */
#		define IL_SPARC4
#	endif
#	if defined(ILT_CPP_GCC)
#		define IL_SPARC4
#	endif
#endif

#if defined(ILT_OS_UNIX_SOLARIS_5_4) && defined(ILT_ARC_SPARC)
#	if defined(ILT_CPP_SUNCC_SOLARIS_3_0)
#		define SPARC_5_3_0 /* obsolete */
#		define IL_SPARC5
#	endif
#	if defined(ILT_CPP_SUNCC_SOLARIS_4_0) /* Was solaris */
#		define SPARC_5_4_0 /* obsolete */
#		define IL_SPARC5
#	endif
#	if defined(ILT_CPP_GCC)
#		define IL_SPARC5
#	endif
#endif

#if defined(ILT_OS_WIN32_WINNT_3_5)
#	if defined(ILT_CC_MSVC)
#		define VISUALC
#		define WIN32
#		define Windows
#	endif
#endif

/*****************************************************************************

 talk.h: Standard C-level definitions

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llheader.h,v 1.3 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------

 This file is a merger of many others.

******************************************************************************/
/*****************************************************************************

 llimportmod.h: header file needed prior to including any external interface
                of other current modules.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llimportmod.h,v 3.8 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

/* For external variables used outside commonrt */

#if defined(ILT_OS_WIN32)

#define LL_EXTERNAL_STATIC(var)			extern var
#define LL_EXTERNAL_STATIC_INIT(var,init)	extern var
#define LL_EXTERNAL_STATIC_DIM(var,dim)		extern var[]
#define LL_EXTERNAL_STATIC_DIM_INIT(var,dim,init) extern var[]
#define LL_COMMONRT_EXTERNAL(var)		__declspec(dllimport) var

#else /* defined(ILT_OS_WIN32) */

#define LL_EXTERNAL_STATIC(var)			extern var
#define LL_EXTERNAL_STATIC_INIT(var,init)	extern var
#define LL_EXTERNAL_STATIC_DIM(var,dim)		extern var[]
#define LL_EXTERNAL_STATIC_DIM_INIT(var,dim,init)	extern var[]
#define LL_COMMONRT_EXTERNAL(var)		extern var

#endif /* defined(ILT_OS_WIN32) */

#define LL_EXTERNAL_FUNCTION(fn,args)		fn ()
/*****************************************************************************

 lldebug.h:  debugging aid

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/lldebug.h,v 3.32 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
******************************************************************************/

/* basic C types definition */
/* \\ this section should be hosted in a distinct include file */

/* integer type having the same size as void* (theoretically we just
   need the smaller integer type representing void* without information
   loss, but practicaly there is always a type of identical size, which
   makes coding much simpler) */

#define VSLONG			 unsigned long

/* sometimes you want to code the address info signed (usefull when
dealing with (signed) fix arithmetics). */

#define SVSLONG			 long

/* optimal integer for bitvector operations in validity bitmap -- which are:
   - mapping over bits (therefore asks for big integers)
   - direct access (therefore fast 1<<) */

#define BLONG			 VSLONG

/* end -f basic C types definition */



/* HOW TO USE THIS:
   
   -----------------------------
   
   in all .c files, use the LL_WHEN_DEBUGGING constructs for debugging
   actions.
   
   Syntax:	LL_WHEN_DEBUGGING(<int>,<instruction>) ;
   Semantics:	equivalent to if (<int> & ll_current_debug) <instruction> ;
   Usage:	<int> is an or of some of the constants below,
   .		<instruction> is one instructions or an instruction bloc
   .		(several instructions surrounded with braces) -- it usually
   .		ends up in writing something to stdout, sdterr or some
   .		trace-file.
   Example:	LL_WHEN_DEBUGGING(LL_TRACE_SYMBOL|LL_TRACE_ALLOC|LL_TRACE_FASL,writetdsfile()) ;
   
   There is a short-hand for printf-ing: trace. See last line of this file.
   
   Example:	LL_TRACE(LL_TRACE_SYMBOL,("Just allocated symbol %s.\n",sym->pname));
   
   -----------------------------
   
   in the present file, define up to 32 elementatry flags (1<<k), and
   as many composites flags as you want (or'ing other flags).
   (0<<i) is the idiom to reserve and inhibit debug flag i.

   Also define LL_LEGAL_DEBUG constant in this file (LL_TRACE_ALL, unless you want
   to sacrifice some debugging aid for the sake of speed -- see below).

   -----------------------------
   
   During debugging, adjust the value of ll_current_debug to obtain the
   information you find usefull. Eg: under adb: _ll_current_debug/W5 means:
   from now on, perform actions and display message meant to help with
   any combinaision of (1<<0) and (1<<2) -- of which the meaning was
   defined in debug.h.
   
   Raising an illegal flag (ie a flag that isn't raised in LL_LEGAL_DEBUG)
   has no effect. The value of LL_LEGAL_DEBUG is made available in the
   static LL_LEGAL_DEBUG -- just for reading, modifying it has no effect.
   
   -----------------------------

   A restrictive LL_LEGAL_DEBUG (ie other than LL_TRACE_ALL) will allow the compiler
   to prune all LL_WHEN_DEBUGGING that never could be legally called.

   During debugging, use the default for LL_LEGAL_DEBUG (LL_TRACE_ALL). During
   debugging, also adjust ll_current_debug initial value default in debug.c,
   or under adb, or by program, to meet your needs (begin with LL_TRACE_ALL).

   When delivering, set ll_current_debug initial value to 0, and adjust
   LL_LEGAL_DEBUG to balance your needs for easy maintenance (eg "set
   ll_current_debug to LL_TRACE_ALL, and tell me what are the last ten lines printed
   before your crash") and good performance (eg make illegal debug
   message-passing).

   -----------------------------
   
   Enjoy. */

/*****************************************************************************/

/* Maintain the flags below.  Comment what the exact semantic for each
   is, ie when is the programmer supposed to use it, ie what kind of
   problem he's got. */


/* fasl reading, ie from fasl-file to core */
#define LL_TRACE_FASL		(1<<1)
#define LL_TRACE_FASL_CODE	(1<<10)	/* binary code itself (wordy) */

/* calls from Talk to C, and calls from c to Talk */
#define LL_TRACE_LNC		(1<<2)

/* leaks due to random foreign pointer */
#define LL_TRACE_MM_BAD_ROW	(1<<2)

/* memory management. This is just the hefty trace  routine. */
#define LL_TRACE_MM_TRACE	(1<<12)

/* memory management. This is just the clever sweep (incremental and so). */
#define LL_TRACE_MM_SWEEP	(1<<13)

/* memory management. This is just the Talk allocators in heap space. */
#define LL_TRACE_MM_MAKE	(1<<14)

/* memory management. This is just malloc to extend heap space. */
#define LL_TRACE_MM_MALLOC	(1<<15)

/* garbage collection. This doesn't include all memory management aspect */
#define LL_TRACE_MM_GC		(LL_TRACE_MM_SWEEP|LL_TRACE_MM_TRACE)

/* information to help out the user to resize the necklaces. Mostly,
   it tells which necklaces cause GC or Malloc. This should be no longer
   usefull when the GC tuning module is ready. */
#define LL_TRACE_MM_STRATEGY	(1<<18)

/* memory management */
#define LL_TRACE_MM		(LL_TRACE_MM_SWEEP|LL_TRACE_MM_TRACE|LL_TRACE_MM_MAKE|LL_TRACE_MM_MALLOC)

/* interupt management, except those aspects addressed by LL_TRACE_IT_HDLG) */
#define LL_TRACE_IT_MGT		(1<<4)

/* critical parts of interrupt management, that one rarely wants to
   trace because of their dependency on response time (typically
   interrupt handlers) */
#define LL_TRACE_IT_CRIT	(1<<5)

/* interrupt management */
#define LL_TRACE_IT		(LL_TRACE_IT_MGT|LL_TRACE_IT_CRIT)

/* input/output */
#define LL_TRACE_IO		(1<<6)

/* world initialization */
#define LL_TRACE_INIT		(1<<7)

/* compiler */
#define LL_TRACE_CMPLR		(1<<8)

/* lap loader */
#define LL_TRACE_LAP		(1<<9)

/* static variable lookup */
#define LL_TRACE_STATIC		(1<<11)

/* literal decoding */
#define LL_TRACE_LITERAL_DECODING	(1<<16)

/* literal coding */
#define  LL_TRACE_DYNAMIC_FRAMES (1<<17)

/* dynamic loading */
#define  LL_TRACE_CLOAD		(1<<19)

/* tracing memory damage */
#define LL_TRACE_MEMORY_DOUBT	(1<<20)

/* verify stack consistency without printing anything */
#define LL_VERIFY_STACK		(1<<21)

/* module elaboration */
#define LL_TRACE_ELABORATION	(1<<22)

/* execore optimal image sizing */
#define LL_TRACE_EXECORE_SIZE	(1<<23)

/* view arguments passed to the command */
#define LL_TRACE_COMMAND_ARGS	(1<<24)

/* access right */
#define LL_TRACE_ACCESS		(1<<25)

/* view arguments passed to the command */
#define LL_TRACE_COMMAND_ARGS_FINE	(1<<26)

/* canon table */
#define LL_TRACE_CANON		(1<<27)

/* image relocation when library moves */
#define LL_TRACE_RELOCATION	(1<<28)

/* hash table */
#define LL_TRACE_HASH           (1<<29)

/* set of all the flags that can trigger some trace,
   given that it is set in ll_current_debug initially or at runtime */
/* Extreme legal debug value: 31 bits set (drop 32nd bit to avoid cc warnings) */
#define LL_TRACE_ALL 0x7fffffff
#define LL_TRACE_NONE ((VSLONG)0)
/* Suggested legal debug value */
#define LL_TRACE_MAX (~(LL_TRACE_MM_TRACE|LL_TRACE_MM_SWEEP))
/* Suggested legal delivery value */
#define LL_TRACE_MIN (LL_TRACE_MM_STRATEGY|LL_TRACE_COMMAND_ARGS_FINE|LL_TRACE_EXECORE_SIZE|LL_TRACE_COMMAND_ARGS|LL_TRACE_ELABORATION|LL_TRACE_CLOAD|LL_TRACE_RELOCATION)

/* default trace */
#define LL_TRACE_DEFAULT	(0)

/* default legal setting */
#ifndef LL_LEGAL_DEBUG
#if defined(ILT_LEV_WORK)
#define LL_LEGAL_DEBUG LL_TRACE_MAX
#else
#define LL_LEGAL_DEBUG LL_TRACE_MIN
#endif
#endif

/*****************************************************************************/
/* you don't need looking below this line. */

LL_EXTERNAL_STATIC_INIT(VSLONG ll_current_debug, LL_TRACE_DEFAULT) ;
LL_EXTERNAL_STATIC_INIT(VSLONG ll_legal_debug, LL_LEGAL_DEBUG) ;


/* clever coding: "cc -O" will resolve the first "if" and generate
   only the second "if" and <action> if legal, or generate nothing (not
   even a bras) if illegal. */

/* Hack note: the " { ... } -1 " is totally disgusting, but I see no
   other way to enforce not using " LL_WHEN_DEBUGGING(...) ; " as a single
   statement inside an if/else statement ("else" would be cought by
   LL_WHEN_DEBUGGING's "if"). Eg " if a trace(b,c) ; else { trace(d,e) ; foo
   ; } " should be replaced with " if a { trace(b,c) ; } else {
   trace(d,e) ; foo ; } ". This mad {};-1 sequence ensures the compiler
   will choke on the first form, and accept the second, and still demand
   a trailing ";" when commonsense demands it. */

#define LL_WHEN_DEBUGGING(flags,action) { if ((flags) & LL_LEGAL_DEBUG) if ((flags) & ll_current_debug) action ; } -1
	
#define LL_TRACE(flags,printf_args) LL_WHEN_DEBUGGING(flags,{(void)printf printf_args;(void)fflush(stdout);})

#define LL_TRACE_OBJECT(flags,object) LL_WHEN_DEBUGGING(flags,{ll_print_object (object);})

#define LL_TRACE_ENABLE(flag) 	(ll_current_debug |= (flag))
#define LL_TRACE_DISABLE(flag)	(ll_current_debug &= ~(flag))

#define LLO_LL_TRACE_MM_STRATEGY()	((LL_object) ll_trace_mm_strategy())
LL_EXTERNAL_FUNCTION(void	*ll_trace_mm_strategy,	()) ;

/*****************************************************************************

 clan.h: Clan manager

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llclan.h,v 3.25 1996/03/19 15:45:31 v16admin Exp $
 ----------------------------------------------------------------------
 ***************************************************************************/

/* immediate clans */

/* cf. macro LLO_IMMEDIATE_CLAN() */
#define LL_NIL_CLAN		(LL_INT2FIX( 0))
#define LL_CHAR_CLAN		(LL_INT2FIX( LL_CHAR_TAG ))
#define LL_FIX_CLAN		(LL_INT2FIX( LL_FIX_TAG ))

/* We reserve the clans 0..7 for the immediate objects.
   (For the 64-bit ports, which have a 3-bit TAG field. */

/* basic row clans */

#define LL_SYMBOL_CLAN		(LL_INT2FIX( 9))
#define LL_KEYWORD_CLAN		(LL_INT2FIX(10))
#define LL_FILENAME_CLAN	(LL_INT2FIX(11))
#define LL_STREGION_CLAN	(LL_INT2FIX(12))
#define LL_FLOAT_CLAN		(LL_INT2FIX(17))
#define LL_STRING_CLAN		(LL_INT2FIX(18))
#define LL_VECTOR_CLAN		(LL_INT2FIX(19))
#define LL_CONS_CLAN		(LL_INT2FIX(22))
#define LL_MODULE_CLAN          (LL_INT2FIX(23))
#define LL_HT1_CLAN		(LL_INT2FIX(24))
#define LL_HT2_CLAN		(LL_INT2FIX(25))
#define LL_HT3_CLAN		(LL_INT2FIX(26))
#define LL_HS1_CLAN		(LL_INT2FIX(28))
#define LL_HS2_CLAN		(LL_INT2FIX(29))
#define LL_FUNCTION_CLAN	(LL_INT2FIX(32))
#define LL_BIGINT_CLAN		(LL_INT2FIX(33))
#define LL_RATIONAL_CLAN	(LL_INT2FIX(34))
#define LL_HASHVECTOR_CLAN	(LL_INT2FIX(35))
#define LL_HOBO_CLAN		(LL_INT2FIX(48))  /* ptr, not a Talk object */
#define LL_LONER_CLAN		(LL_INT2FIX(49))
#define LL_CHUNK_CLAN		(LL_INT2FIX(50))
#define LL_NECKLACE_CLAN	(LL_INT2FIX(51))
#define LL_ARRAY_DEFAULT_CLAN	(LL_INT2FIX(64))
#define LL_FREE_ARRAY_CLAN	(LL_INT2FIX(65))
#define LL_HTABLE_EQ_CLAN	(LL_INT2FIX(70))
#define LL_HTABLE_EQSTRING_CLAN	(LL_INT2FIX(71))
#define LL_HTABLE_GEN_CLAN	(LL_INT2FIX(72))
#define LL_HTABLE_EQN_CLAN	(LL_INT2FIX(73))
#define LL_UNDEF_CLAN		(LL_INT2FIX(76))
#define LL_UNDEF_FN_CLAN	(LL_INT2FIX(77))
#define LL_ADDRESS_CLAN		(LL_INT2FIX(98))

LL_EXTERNAL_FUNCTION (void	ll_init_symbol,	(void)) ;

/* For use as primitives, see ilttypem.t. */
#define ILT_HTABLE_EQ_CLAN()		LL_HTABLE_EQ_CLAN
#define ILT_HTABLE_EQSTRING_CLAN()	LL_HTABLE_EQSTRING_CLAN
#define ILT_HTABLE_GEN_CLAN()		LL_HTABLE_GEN_CLAN
#define ILT_HTABLE_EQN_CLAN()		LL_HTABLE_EQN_CLAN
#define ILT_UNDEF_CLAN()		LL_UNDEF_CLAN
#define ILT_UNDEF_FN_CLAN()		LL_UNDEF_FN_CLAN
#define ILT_NULL_CLAN()			LL_NIL_CLAN
#define ILT_SYMBOL_CLAN()		LL_SYMBOL_CLAN
#define ILT_KEYWORD_CLAN()		LL_KEYWORD_CLAN
#define ILT_FILENAME_CLAN()		LL_FILENAME_CLAN
#define ILT_CHAR_CLAN()			LL_CHAR_CLAN
#define ILT_FIX_CLAN()			LL_FIX_CLAN
#define ILT_FLOAT_CLAN()		LL_FLOAT_CLAN
#define ILT_STRING_CLAN()		LL_STRING_CLAN
#define ILT_VECTOR_CLAN()		LL_VECTOR_CLAN
#define ILT_CONS_CLAN()			LL_CONS_CLAN
#define ILT_MODULE_CLAN()		LL_MODULE_CLAN
#define ILT_FUNCTION_CLAN()		LL_FUNCTION_CLAN
#define ILT_BIGINT_CLAN()		LL_BIGINT_CLAN
#define ILT_RATIONAL_CLAN()		LL_RATIONAL_CLAN
#define ILT_HOBO_CLAN()			LL_HOBO_CLAN
#define ILT_LONER_CLAN()		LL_LONER_CLAN
#define ILT_CHUNK_CLAN()		LL_CHUNK_CLAN
#define ILT_NECKLACE_CLAN()		LL_NECKLACE_CLAN
#define ILT_ADDRESS_CLAN()		LL_ADDRESS_CLAN
#define ILT_ROW_DEFAULT_CLAN()		LL_ROW_DEFAULT_CLAN
/*****************************************************************************

 llmm.h: Talk memory manager, including the garbage collector

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llmm.h,v 3.65 1996/06/19 12:49:08 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

/********** machine word constants ************/

/* rockbottom values */

/* long size. The cpp portable trick used here works only for long.
   IRIX5 cpp and WindowsNT MSVC are buggy: their longs are 64b whereas
   C's are 32b, so we MUST predefine LOG_BYTES_PER_LONG there (-D) */

#if defined(ILT_OS_WIN32)
/* in MS-Win, everything is so bizarre... */
#define LOG_BYTES_PER_LONG	2
#endif
#if defined(ILT_OS_UNIX_IRIX)
#if defined(ILT_ARC_MIPS64)
#define LOG_BYTES_PER_LONG	3
#else
#define LOG_BYTES_PER_LONG	2
#endif
#endif
#ifndef LOG_BYTES_PER_LONG
#if ((1L<<16)==1) || ((1L<<16)==0)
#define LOG_BYTES_PER_LONG	1
#else
#if ((1L<<32)==1) || ((1L<<32)==0)
#define LOG_BYTES_PER_LONG	2
#else
#if ((1L<<48)==1) || ((1L<<48)==0)
#define LOG_BYTES_PER_LONG	9999999999999
#else
#if ((1L<<64)==1) || ((1L<<64)==0)
#define LOG_BYTES_PER_LONG	3
#else
#define LOG_BYTES_PER_LONG	9999999999999
#endif
#endif
#endif
#endif
#endif

#define LOG_BYTES_PER_FLOAT	3
#define BYTES_PER_FLOAT		(1<<LOG_BYTES_PER_FLOAT)

/* Data address (aka Talk pointer): void* */
/* So far, sizeof(long) == sizeof(void*), so we do the following.
   Otherwise we'd have to pass a flag when compiling include <llincludes.h>,
   even for the casual user handwritten C code (berk) */

#define LOG_BYTES_PER_VOIDSTAR	 LOG_BYTES_PER_LONG

#define LOG_BYTES_PER_BLONG	 LOG_BYTES_PER_VOIDSTAR

/* You can use
   #define BLONG			 char
   #define LOG_BYTES_PER_BLONG	 0
   but then set LLI_MAX_SIZE to 2, 3 or 4 (otherwise the mask may contain
   no bit, and the chunk sweeps no array) */

#define LOG_BYTES_PER_CHARACTER	 0
#define LOG_BITS_PER_BYTE	 3

/* derived constants */

#define LOG_BITS_PER_CHARACTER	(LOG_BITS_PER_BYTE+LOG_BYTES_PER_CHARACTER)
#define BYTES_PER_CHARACTER	(1<<LOG_BYTES_PER_CHARACTER)

#define BITS_PER_BYTE		(1<<LOG_BITS_PER_BYTE)

#define LOG_BITS_PER_VOIDSTAR	(LOG_BITS_PER_BYTE+LOG_BYTES_PER_VOIDSTAR)
#define BYTES_PER_VOIDSTAR	(1<<LOG_BYTES_PER_VOIDSTAR)
#define BITS_PER_VOIDSTAR	(1<<LOG_BITS_PER_VOIDSTAR)

#define LOG_BITS_PER_BLONG	(LOG_BITS_PER_BYTE+LOG_BYTES_PER_BLONG)
#define BYTES_PER_BLONG		(1<<LOG_BYTES_PER_BLONG)
#define BITS_PER_BLONG		(1<<LOG_BITS_PER_BLONG)

/******** Memory manager ***********/

#define LLO_LL_GC()	((LL_object) ll_gc())
#define LLO_LL_ROCKBOTTOM_GC()	((LL_object) ll_rockbottom_gc())
#define LLO_LL_SET_BEFORE_GC_DEMON(f)	(ll_set_before_gc_demon(f))
#define LLO_LL_SET_AFTER_GC_DEMON(f)	(ll_set_after_gc_demon(f))
#define LLO_SWEEP_ALL_ARRAYS()	((LL_object) sweep_all_arrays())
#define LLO_LL_FREE_ROW(t)	(ll_free_row(t))
#define LLO_LL_TRACE_MM_STRATEGY()	((LL_object) ll_trace_mm_strategy())
#define LLO_LL_GCINFO()	((LL_object) ll_gcinfo())
#define LLO_LLI_GCINFO_CLANGTH_DENSITY(i,v1,v2,v3)	((LL_object) lli_gcinfo_clangth_density(i,v1,v2,v3))
#define LLO_LLI_GCINFOC_CLAN_DENSITY(i,v1,v2)	((LL_object) lli_gcinfoc_clan_density(i,v1,v2))
#define LLO_LLI_GCINFOL_LENGTH_DENSITY(i,v)	((LL_object) lli_gcinfol_length_density(i,v))
#define LLO_LLI_GCINFO_HEAP_LENGTH()	((LL_object) lli_gcinfo_heap_length())
#define LLO_LLI_ALLOC_GC_TIME(i)	((LL_object) lli_alloc_gc_time(i))
#define LLO_LLI_USER_GC_TIME()		((LL_object) lli_user_gc_time())
#define LLO_LLI_TOTAL_GC_TIME()		((LL_object) lli_total_gc_time())
#define LLO_LLI_NUMBER_OF_USER_GC()	((LL_object) lli_number_of_user_gc())
#define LLO_LLI_NUMBER_OF_ALLOC_GC(i)	((LL_object) lli_number_of_alloc_gc(i))
#define LLO_LLI_TOTAL_OF_ALLOC_GC()	((LL_object) lli_total_of_alloc_gc())
#define LLO_LL_ACTUAL_DATA_BASE()	((LL_object) ll_actual_data_base())
#define LLO_LL_OPTIMAL_DATA_BASE()	((LL_object) ll_optimal_data_base())
#define LLO_LLI_NUMBER_OF_ARRAYS_SWEPT_FOR_LENGTH(i)	((LL_object) lli_number_of_arrays_swept_for_length(i))
#define LLO_LLI_SET_MINIMUM_BYTE_ALLOCATION_SPEED(i)	((LL_object) lli_set_minimum_byte_allocation_speed(i))
#define LLO_LLI_GET_MINIMUM_BYTE_ALLOCATION_SPEED()	((LL_object) lli_get_minimum_byte_allocation_speed())
#define LLO_LLI_DEFAULT_MINIMUM_BYTE_ALLOCATION_SPEED()	((LL_object) lli_default_minimum_byte_allocation_speed())
#define LLO_LL_RECTIFY_LENGTHS()	((LL_object) ll_rectify_lengths())
#define LLO_LL_PREVIOUS_ARRAY(t)	((LL_object) ll_previous_array(t))
#define LLO_LL_MAP_ALL_ARRAYS(t)	((LL_object) ll_map_all_arrays(t))
#define LLO_LL_MAP_MEMORY_MORSELS(t)	((LL_object) ll_map_memory_morsels(t))
#define LLO_LL_BEGIN_MEMORY_DELTA(i,v1,v2,v3,v4)	((LL_object) ll_begin_memory_delta(i,v1,v2,v3,v4))
#define LLO_LL_END_MEMORY_DELTA()	((LL_object) ll_end_memory_delta())
#define LLO_LL_MEMORY_DELTA_P()	((LL_object) ll_memory_delta_p())
#define LLO_LL_HEAP_MALLOC_ENABLE_P()	(ll_heap_malloc_enabled_pred()?llsym_t:ll_nil)


/* The type of all Talk objects! */

typedef void	*LL_object ;


#define LL_pointer		LL_object

typedef LL_object		LL_fix ;


/* All heap-allocated objects (non-immediates) have this _in_front_ of them: */

typedef struct { VSLONG length;
		 LL_fix clan;		/* class number */
	 }			*LL_header;

#define LLI_LENGTH_INDEX	(((VSLONG)(&(((LL_header)0)[-1].length)))>>LOG_BYTES_PER_VOIDSTAR)
#define LLI_CLAN_INDEX		(((VSLONG)(&(((LL_header)0)[-1].clan)))>>LOG_BYTES_PER_VOIDSTAR)
#define LLO_LENGTH_INDEX	((LL_object)LL_INT2FIX(LLI_LENGTH_INDEX))
#define LLO_CLAN_INDEX		((LL_object)LL_INT2FIX(LLI_CLAN_INDEX))

#define LLI_ARRAY_LENGTH(object)	(((LL_header)(object))[-1].length)
#define LL_ARRAY_CLAN(object)		(((LL_header)(object))[-1].clan)
#define LLO_ARRAY_CLAN(object)		((LL_object)(((LL_header)(object))[-1].clan))


/* Modifying the length and clan of a heap-allocated object. */

/* Hacker's corner --- you may need a few explanations for the next two lines.
   1--  some C-compilers don't accept LHS casting, thus intermediate variable
   2--  {..} is a statement, but we want set_xxx to be used as an expr, thus "do"
   3--  hopefully, neat compilers will remove the intermediate variable.       */
#define LLI_SET_LENGTH(obj,ln)	{LL_header hdr;hdr=(LL_header)(obj);hdr[-1].length=(ln);}-1
#define LL_SET_CLAN(obj,tb)	{LL_header hdr;hdr=(LL_header)(obj);hdr[-1].clan=(tb);}-1
#define LLO_SET_ARRAY_LENGTH(obj,cln)	(LLO_VSET(obj,LLO_LENGTH_INDEX,cln))
#define LLO_SET_ARRAY_CLAN(obj,cln)	(LLO_VSET(obj,LLO_CLAN_INDEX,cln))


/* Test whether a ptr is a valid pointer to a heap-allocated object. */
LL_EXTERNAL_FUNCTION (VSLONG	ll_pred_arrayp,	(LL_object o)) ;
#define LLO_PRED_ARRAYP(o)	ll_pred_arrayp(o)
#define LLO_PRED_ARRAYP_INLINE(o)	((VSLONG)(LL_PRED_ARRAYP(o)))

/* Free a heap-allocated object. */

LL_EXTERNAL_FUNCTION(LL_object	ll_free_row,	(LL_object obj)) ;


/* Test whether a ptr is a valid Talk object. */
LL_EXTERNAL_FUNCTION (VSLONG	ll_pred_objectp,	(void *thing)) ;
#define LLO_PRED_OBJECTP(thing)	ll_pred_objectp(thing)
#define LLO_PRED_OBJECTP_INLINE(o)	\
  (LLO_PRED_NON_NULL_IMMEDIATE_P(o) || LLO_PRED_ARRAYP_INLINE(o) || ((o)==ll_nil))

/* Return the clan of a valid Talk object. */
LL_EXTERNAL_FUNCTION(LL_fix	ll_object_clan,	(LL_object obj)) ;
#define LLO_OBJECT_CLAN(object)		((LL_object)ll_object_clan(object))
#define LLO_OBJECT_CLAN_INLINE(o)	\
  (LLO_PRED_NON_NULL_IMMEDIATE_P(o) ? LLO_IMMEDIATE_CLAN(o) : \
   (o)==ll_nil                      ? (LL_object)LL_NIL_CLAN \
   /* it dumps core here */         : LLO_ARRAY_CLAN(o))

/* Test whether a ptr is a valid Talk object, and set a variable to its clan.
   Returns nonzero if not a valid Talk object. */
#define LLO_PTR_CLAN_INLINE(th,clan)  \
  ((LL_object)(VSLONG) \
    (LLO_PRED_NON_NULL_IMMEDIATE_P(th) ? (clan = LLO_IMMEDIATE_CLAN(th), 0) : \
     LLO_PRED_ARRAYP_INLINE(th)        ? (clan = LLO_ARRAY_CLAN(th), 0) : \
     (clan = (LL_object)LL_NIL_CLAN, (th)!=ll_nil)))


/* Type for variables which must be declared volatile because of
   setjmp/lonjgmp register restoration problems */

#if defined(ILT_CC_HAS_NO_VOLATILE)

typedef LL_object		LL_object_volatile;
#define ILT_VOLATILE

#else

#define ILT_VOLATILE		volatile

#if defined(ILT_CC_HAS_ANSI_VOLATILE)

typedef void			 *volatile LL_object_volatile;

#else

#define LL_object_volatile	  volatile LL_object

#endif
#endif


/* Type for const variables */

#if defined(ILT_CC_HAS_CONST)
#	define LLCONST const
#else
#	define LLCONST
#endif



LL_EXTERNAL_FUNCTION (VSLONG	lli_total_heap_length,		(void)) ;
LL_EXTERNAL_FUNCTION (VSLONG	lli_max_total_heap_length,	(void)) ;
LL_EXTERNAL_FUNCTION (VSLONG	lli_ideal_max_static_heap_size,	(void)) ;
LL_EXTERNAL_FUNCTION (VSLONG	lli_static_heap_reserve,	(void)) ;

LL_EXTERNAL_FUNCTION (LL_object	llo_print_object,	(LL_object object)) ;
LL_EXTERNAL_FUNCTION (LL_object	llo_prin_object,	(LL_object object)) ;
LL_EXTERNAL_FUNCTION (LL_object	llo_dump_object,	(LL_object object)) ;
LL_EXTERNAL_FUNCTION (void	ll_init_mm,	(void)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_gc,		(void)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_set_before_gc_demon,		(LL_object fn)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_set_after_gc_demon,		(LL_object fn)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_gc_enable_p,		(void)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_gc_enable,		(LL_object flag)) ;
#define LLO_LL_GC_ENABLE(f)	ll_gc_enable(f)
#define LLO_LL_GC_ENABLE_P()	ll_gc_enable_p()
LL_EXTERNAL_FUNCTION (void	ll_add_roots,		(LL_object *rootp,
							 VSLONG number_of_roots)) ;
LL_EXTERNAL_FUNCTION (VSLONG	ll_next_check_in_result,	()) ;
LL_EXTERNAL_FUNCTION (char *	malloc_forced,	(VSLONG, VSLONG));
LL_EXTERNAL_FUNCTION (void	ll_print_object,	(LL_object object)) ;
LL_EXTERNAL_FUNCTION (void	ll_prin_object,	(LL_object object)) ;
LL_EXTERNAL_FUNCTION (void	ll_dump_object,	(LL_object object)) ;
LL_EXTERNAL_FUNCTION (LL_object	lli_make_array,	(VSLONG l, void *clan)) ;

LL_EXTERNAL_FUNCTION (void	ilt_remember_stack_orientation,	()) ;

#define LLO_MAKE_ROW(len, clan)	(lli_make_array(LL_FIX2INT(len), clan))

#define LLO_MAKE_PTR_ROW(len, clan)	(lli_make_array(LL_FIX2VOS(len), clan))

#define LLO_MAKE_ARRAY(len)	(LL_MAKE_ARRAY((LL_fix)LL_THE_OBJECT(len)))
#define LL_MAKE_ARRAY(len)	(lli_make_array(LL_FIX2INT(LL_THE_FIX(len)), LL_STRING_CLAN))

LL_EXTERNAL_FUNCTION (void	with_all_registers_flushed, (void (*f)())) ;

LL_EXTERNAL_FUNCTION (void	ll_map_memory_morcels,	(LL_function fct)) ;

/*****************************************************************************

 llmminner.h: Talk memory manager. Inner aspects.

 ****************************************************************************/

/********************************************* PARAMETERS */

/* These values can be changed, nothing should break */

/* Typical values to change are:
 *   LOG_BYTES_PER_HEAP   when the application requires at least twice
 *                        more (or less) memory to run than it used to.
 * These values are typically specified in `llsystem`/cpp.Make.
 */

/* The next two parameters are unusually changed */

#define LOG_VOIDSTARS_PER_QUANTUM	 2

#ifndef OPTIMUM_CHUNK_SIZE
#define OPTIMUM_CHUNK_SIZE	0x2000 /* 8KB */
#endif

/********************************************* end of PARAMETERS */

/* unit     usual value  usage
                    1<<
   heap       16MB   24  virtual memory ever used for the heap
   quantum      8B    4  alignment of objects
   void*        4B    2  size of a Talk pointer (ie void*)
   byte         1B    0  unit of length, unit of address

   constraints:
   All are powers of two.
   heap>=quantum>=void*>=byte
   byte==1==2**0
*/

/* Headers size don't have to be powers of 2.
   Currently, they're 8byte-long, since they hold length and clan in
   one void* each.
*/

/* The memory occupation of an object is :
   size(object) = ((length(object)+bytes_per_header-1)/bytes_per_quanta)+1
*/

#define BYTES_PER_HEADER	((VSLONG)(&((LL_header)0)[1]))

/* size is the occupation in quanta (hdr included) */
/* length is the used length in bytes (hdr not included) */
#define LENGTH_TO_SIZE(l)	((((VSLONG)(l))+BYTES_PER_HEADER+BYTES_PER_QUANTUM-1) >>LOG_BYTES_PER_QUANTUM)
#define SIZE_TO_LENGTH(s)	((((VSLONG)(s))<<LOG_BYTES_PER_QUANTUM)-BYTES_PER_HEADER)
			   

/* trace constants */

#define LOG_INVALID_FLAG	0
#define LOG_TRACED_FLAG		1
#define LOG_FLAGS_PER_QUANTUM	1
#define INVALID_FLAG		(1<<LOG_INVALID_FLAG)
#define TRACED_FLAG		(1<<LOG_TRACED_FLAG)
#define LOG_QUANTA_PER_PAGE	(LOG_BITS_PER_BLONG    -LOG_FLAGS_PER_QUANTUM)
/* all flags about all quanta of one page must fit in one blong
   (a blong could be different than a void*) */

/* derived constants */
#define LOG_BYTES_PER_QUANTUM	(LOG_BYTES_PER_VOIDSTAR   +LOG_VOIDSTARS_PER_QUANTUM)
#define LOG_BYTES_PER_PAGE	(LOG_BYTES_PER_QUANTUM+LOG_QUANTA_PER_PAGE)

/* non-constants */
#define LOG_BYTES_PER_HEAP	log_bytes_per_heap

/* derived values */
#define LOG_VOIDSTARS_PER_HEAP	log_voidstars_per_heap
                          /* == (LOG_BYTES_PER_HEAP   -LOG_BYTES_PER_VOIDSTAR) */
#define LOG_QUANTA_PER_HEAP	log_quanta_per_heap
                          /* == (LOG_BYTES_PER_HEAP   -LOG_BYTES_PER_QUANTUM) */
#define LOG_PAGES_PER_HEAP	log_pages_per_heap
                          /* == (LOG_BYTES_PER_HEAP   -LOG_BYTES_PER_PAGE) */

#define VOIDSTARS_PER_QUANTUM	(1<<LOG_VOIDSTARS_PER_QUANTUM)
#define BYTES_PER_QUANTUM	(1<<LOG_BYTES_PER_QUANTUM)
#define QUANTA_PER_PAGE		(1<<LOG_QUANTA_PER_PAGE)
#define BYTES_PER_PAGE		(1<<LOG_BYTES_PER_PAGE)
#define FLAGS_PER_QUANTUM	(1<<LOG_FLAGS_PER_QUANTUM)
#define BYTES_PER_HEAP		bytes_per_heap     /* (1<<LOG_BYTES_PER_HEAP) */
#define VOIDSTARS_PER_HEAP	voidstars_per_heap /* (1<<LOG_VOIDSTARS_PER_HEAP) */
#define QUANTA_PER_HEAP		quanta_per_heap    /* (1<<LOG_QUANTA_PER_HEAP) */
#define PAGES_PER_HEAP		pages_per_heap     /* (1<<LOG_PAGES_PER_HEAP) */

/*************** ALLOC structures ****/

/* There are a few classes dedicated to the MM. For each of them there
   is a corresponding clan the MM knows about, and (except for the
   classes array, fix and hobo) a mirror struct. */

/* Those classes are:
   array	the type of a newly created object
   loner	one for each array mallocated
   chunk	one for each area of similar size arrays
   necklace	one for each ring of chunks of similar size arrays
   fix		the class of the fix numbers
   hobo		the class of the neither fix, heither valid pointers
   */

/* BYTES_PER_xxx is the number of bytes for an instance of the
   structure --- therefore the size of header of the corresponding Talk 
   object is NOT included. */

/* * * * * * * *
 * * * * * * * *
 * * MACROSS * *
 * * * * * * * *
 * * * * * * * */

/* rotate of D bits leftwards the blong W filled
   with R-bit-long identical records. R>D. */
/* this is the same as: return the blong after W in the sequence of
   endlessly repeated R-bit-long identical records. To ease up
   computation, D is provided, with D=32%R. */
/* 12312312 31231231 23123123 12312312 31231231 23123123
   rotate(31231231,3,2)->23123123 */
/*
#define ROTATE(w,r,d)	((((BLONG)(w))<<(d))|(((BLONG)(w))>>((r)-(d))))
*/

/* this is the same as: return the blong after W in the sequence of
   endlessly repeated R-bit-long identical records. */
/* eg: 12312312 31231231 23123123 12312312 31231231 23123123
   NEXT_IN_FESTOON(31231231,3,2)->23123123 */
/*
#define NEXT_IN_FESTOON(w,r)	((((BLONG)(w))<<((BITS_PER_BLONG%(r))))|(((BLONG)(w))>>((r)-((BITS_PER_BLONG%(r))))))
*/

/* this is the same as: return the mirror of the blong after the mirror
   of W in the sequence of endlessly repeated R-bit-long identical
   records.*/
/* eg: 
   festoon:	32132132 13213213 21321321 32132132 13213213 21321321
   mirror(fest)	23123123 31231231 12312312 23123123 31231231 12312312
   NEXT_IN_FESTOON(31231231,3)->12312312 */
#define NEXT_IN_FESTOON(w,r)	ROTATE(w,r,(BITS_PER_BLONG%(r)))

/* rotate of D bits rightwards the blong W filled
   with R-bit-long identical records. R>D. */
#define ROTATE(w,r,d)	((((BLONG)(w))>>(d))|(((BLONG)(w))<<((r)-(d))))

#define BYTES_PER_CHUNK		((VSLONG)(&((LL_chunk)0)[1]))
#define BYTES_PER_NECKLACE	((VLSONG)(&((LL_necklace)0)[1]))
#define BYTES_PER_LONER		((VSLONG)(&((LL_loner)0)[1]))

/********** TRACE *************/

/* HEAP_BASE must be alligned at least on BYTES_PER_PAGE. 
   For optimal code, 0 low half is even better. */
#define HEAP_BASE		(ILT_DATA_BASE & -0x10000)
#define ARRAY_MISALIGNED(o)	(ARRAY_MISALIGNED_MASK & (((VSLONG)o)-HEAP_BASE))
#define ARRAY_MISALIGNED_MASK	array_misaligned_mask /* == (BYTES_PER_QUANTUM-(BYTES_PER_HEAP+1)) */
/* constraint: thing MUST be a simple expression (typically a variable) */
#define LL_PRED_ARRAYP(thing)  (!ARRAY_MISALIGNED(thing) && !(pinvalid_traced[GET_PAGE(thing)] & ((BLONG)INVALID_FLAG << GET_OFFSET(thing))))


/* Use of ARRAY_MISALIGNED assumes arrays are all in the range of the
   bitmap. This unsually cannot include the stack */

/* a void*-ILT_DATA_BASE is composed of:
   .                         type   xxxxxxxx xxxxx xx0 000
   sign extension                   ^^^^^^^^
   page field                VSLONG          ^^^^^
   offset field              int                   ^^^ 
   log bytes par quanta 0's  int                       ^^^ 
   */

#define BITS_PER_PAGE_FIELD	(BITS_PER_VOIDSTAR-LOG_BYTES_PER_PAGE)
#define BITS_PER_OFFSET_FIELD	(LOG_QUANTA_PER_PAGE+LOG_FLAGS_PER_QUANTUM)
#define BITS_PER_ZEROES_FIELD	(LOG_BYTES_PER_QUANTUM-LOG_FLAGS_PER_QUANTUM)
/* using bit fields is not portable to bigendian machines, eg MIPS */
#define GET_PAGE(o)		((((VSLONG)o)-HEAP_BASE)>>(BITS_PER_OFFSET_FIELD+BITS_PER_ZEROES_FIELD))
#define GET_OFFSET(o)		(((((VSLONG)o)-HEAP_BASE)<<BITS_PER_PAGE_FIELD)>>(BITS_PER_PAGE_FIELD+BITS_PER_ZEROES_FIELD))
#define FIRST_ADDR_OF_PAGE(o)	((((VSLONG)o)<<(BITS_PER_OFFSET_FIELD+BITS_PER_ZEROES_FIELD))+HEAP_BASE)

#define DYNAMIC_TRACE_STACK_UNDERFLOW	(&(dynamic_trace_stack[-1]))
#define DYNAMIC_TRACE_STACK_OVERFLOW	(&(dynamic_trace_stack[desired_dynamic_trace_stack_size]))

/* * * * * * *
 * * * * * * *
 * * TYPES * *
 * * * * * * *
 * * * * * * */

/* Like loners, chunks are afore the objects it allows to allocate.
   A chunks allow for many objects to trail, whereas a loner allows for
   only one. All the trailing object must roughly be of the same size. */

typedef struct
	ChunkS { struct ChunkS *next;
		 char *malloc;		/* what malloc returned */
		 VSLONG size;     /* what was asked to malloc */
		 VSLONG population;/* nb of arrays that can fit in */
		 VSLONG flags_per_array;
		 BLONG current_mask;
		 VSLONG current_page;
		 BLONG first_mask;
		 BLONG full_first_mask;
		 BLONG second_mask;
		 VSLONG first_page;
		 VSLONG last_page;
		 BLONG mask_rotate;
		 LL_object first_array_plus_1 ;
		 LL_object last_array_plus_1 ;
		 VSLONG requests ;/* nb of requests for a new array */
		 VSLONG births ;	/* nb of succeding requests */
		 VSLONG sweeps ;	/* nb of sweeps started here */
	 }				*LL_chunk ;

typedef struct
	NecklaceS { LL_chunk current_chunk;	/* the chunk the last
						   array was born in */
		    LL_chunk last_gc_current_chunk; /* current_chunk then */
		    VSLONG number_of_arrays_swept;
		    VSLONG number_of_arrays_swept_upon_last_gc;
		    VSLONG minimum_of_arrays_swept_per_gc;
		    VSLONG number_of_alloc_gc;		/* due to alloc here */
		    LL_object freelist ;	/* chain of swept yet 
						   unused arrays */
		    VSLONG alloc_gc_time;	/* time spent in gc trigered here */
	    }				LL_necklace ;

#define NEXT_FREE	0	/* could also be -2 -- ie type field */
/* \\ NEXT_FREE==0 and LOG_VOIDSTARS_PER_QUANTUM==1or0 will die for empty objects */
/* NEXT_FREE==-2 kills gcinfo */
/* NEXT_FREE==-1 kills gc */

#define LLI_MIN_SIZE		1 /* never 0! */
#define LLI_MAX_SIZE		10 /* \\ normally 6 */

typedef struct
	LonerS { struct LonerS *next;
		 char *malloc;		/* what malloc returned */
		 VSLONG sweeps;		/* nb of sweeps attempted here */
		 VSLONG length;   /* how mauch room malloc was asked for */
	 }				*LL_loner ;

/* * * * * * * * *
 * * * * * * * * *
 * * FUNCTIONS * *
 * * * * * * * * *
 * * * * * * * * */

LL_EXTERNAL_FUNCTION (LL_object	make_array_in_loner,	(VSLONG l)) ;
LL_EXTERNAL_FUNCTION (LL_chunk	make_chunk,	(VSLONG malloc_length,
					    VSLONG array_length)) ;

/* * * * * * * *
 * * * * * * * *
 * * STATICS * *
 * * * * * * * *
 * * * * * * * */

/* dynamic trace stack */
#define LL_TRACE_STACK_DEFAULT_SIZE 0x1000
#define LL_TRACE_STACK_GROWTH_RATE 1.5
LL_EXTERNAL_STATIC_INIT(LL_object *dynamic_trace_stack, (LL_object *)NULL) ;
LL_EXTERNAL_STATIC_INIT(VSLONG	desired_dynamic_trace_stack_size,	LL_TRACE_STACK_DEFAULT_SIZE) ;
LL_EXTERNAL_STATIC_INIT(VSLONG	actual_dynamic_trace_stack_size, 0) ;

/*************** ALLOC variables ****/
LL_EXTERNAL_STATIC_INIT(LL_loner	first_loner,	NULL) ;

/**********************/
/* inlined allocators */
/**********************/

/* an optimal row is one which has the maximum legal length in its
   necklace, ie 8, 24, 40, etc */

/* length:	a constant expression	# of bytes		VSLONG
   clan:	an expression		clan to write in header	LL_fix
   row:		a variable		created object		LL_object */

#define MAKE_RAW_ROW(length,clan,result1)			\
{ void *row1;							\
  if (!necklace[LENGTH_TO_SIZE(length)].freelist)		\
	  sweep_some_arrays_sizing(LENGTH_TO_SIZE(length)) ;	\
  row1 = necklace[LENGTH_TO_SIZE(length)].freelist ;		\
  /* pop first element */					\
  necklace[LENGTH_TO_SIZE(length)].freelist			\
	  = ((LL_vector)row1)[NEXT_FREE] ;			\
  LL_SET_CLAN(row1,clan) ;					\
  result1 = row1; }-1

#define MAKE_RAW_OPTIMAL_ROW(length,clan,result2)		\
{ void *row2;							\
  VSLONG q ;							\
  q = LENGTH_TO_SIZE(length);					\
  if (SIZE_TO_LENGTH(q) != length)				\
    ll_runtime_error("Error: %d is suboptimal.",length);	\
  if (q > LLI_MAX_SIZE)						\
    ll_runtime_error("** ERROR: %d is loner.",length);		\
  MAKE_RAW_ROW(length,clan,row2);				\
  result2 = row2;}-1

#define MAKE_RAW_SUBOPTIMAL_ROW(length,clan,result2)		\
{ void *row2;							\
  VSLONG q ;							\
  q = LENGTH_TO_SIZE(length);					\
  if (SIZE_TO_LENGTH(q) == length)				\
    ll_runtime_error("Warning: %d is optimal.",length);		\
  if (q > LLI_MAX_SIZE)						\
    ll_runtime_error("** ERROR: %d is loner.",length);		\
  MAKE_RAW_ROW(length,clan,row2);				\
  LLI_SET_LENGTH(row2,length);					\
  result2 = row2;}-1

#define MAKE_RAW_LONER_ROW(length, clan, result)		\
{ void *row;							\
  row = lli_make_array(length, clan);				\
  result = row;}-1

#if ( LOG_BYTES_PER_FLOAT == 1 + LOG_BYTES_PER_VOIDSTAR )

/* 2 void* to a double: usual 32 bit system port */

#define LL_MAKE_FLOAT_ROW_1(clan,f0,result)			\
{ void *row;							\
  MAKE_RAW_OPTIMAL_ROW(1<<LOG_BYTES_PER_FLOAT,clan,row);	\
  ((LL_float)row)[0]=f0;					\
  result = row;}-1

#else

#if ( LOG_BYTES_PER_FLOAT == LOG_BYTES_PER_VOIDSTAR )

/* 2 void* to a double: usual 64 bit system port */

#define LL_MAKE_FLOAT_ROW_1(clan,f0,result)			\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(1<<LOG_BYTES_PER_FLOAT,clan,row);	\
  ((LL_float)row)[0]=f0;					\
  result = row;}-1

#else

/* gasp, unknown set up */
%%%%UNKNOWN%%%%

#endif

#endif

#define LL_MAKE_POINTER_ROW_0(clan,result)			\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(0<<LOG_BYTES_PER_VOIDSTAR,clan,row);	\
  result = row;}-1

#define LL_MAKE_POINTER_ROW_1(clan,f0,result)			\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(1<<LOG_BYTES_PER_VOIDSTAR,clan,row);	\
  ((LL_vector)row)[0]=f0;					\
  result = row;}-1

#define LL_MAKE_POINTER_ROW_2(clan,f0,f1,result)		\
{ void *row;							\
  MAKE_RAW_OPTIMAL_ROW(2<<LOG_BYTES_PER_VOIDSTAR,clan,row);	\
  ((LL_vector)row)[0]=f0;					\
  ((LL_vector)row)[1]=f1;					\
  result = row;}-1

#define LL_MAKE_POINTER_ROW_3(clan,f0,f1,f2,result)		\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(3<<LOG_BYTES_PER_VOIDSTAR,clan,row);	\
  ((LL_vector)row)[0]=f0;					\
  ((LL_vector)row)[1]=f1;					\
  ((LL_vector)row)[2]=f2;					\
  result = row;}-1

#define LL_MAKE_POINTER_ROW_4(clan,f0,f1,f2,f3,result)		\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(4<<LOG_BYTES_PER_VOIDSTAR,clan,row);	\
  ((LL_vector)row)[0]=f0;					\
  ((LL_vector)row)[1]=f1;					\
  ((LL_vector)row)[2]=f2;					\
  ((LL_vector)row)[3]=f3;					\
  result = row;}-1

#define LL_MAKE_POINTER_ROW_5(clan,f0,f1,f2,f3,f4,result)	\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(5<<LOG_BYTES_PER_VOIDSTAR,clan,row);	\
  ((LL_vector)row)[0]=f0;					\
  ((LL_vector)row)[1]=f1;					\
  ((LL_vector)row)[2]=f2;					\
  ((LL_vector)row)[3]=f3;					\
  ((LL_vector)row)[4]=f4;					\
  result = row;}-1

#define LL_MAKE_POINTER_ROW_6(clan,f0,f1,f2,f3,f4,f5,result)	\
{ void *row;							\
  MAKE_RAW_OPTIMAL_ROW(6<<LOG_BYTES_PER_VOIDSTAR,clan,row);	\
  ((LL_vector)row)[0]=f0;					\
  ((LL_vector)row)[1]=f1;					\
  ((LL_vector)row)[2]=f2;					\
  ((LL_vector)row)[3]=f3;					\
  ((LL_vector)row)[4]=f4;					\
  ((LL_vector)row)[5]=f5;					\
  result = row;}-1

#define LL_MAKE_BYTE_ROW_0(clan,result)				\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(0,clan,row);				\
  result = row;}-1

#define LL_MAKE_BYTE_ROW_1(clan,f0,result)			\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(1,clan,row);				\
  ((char*)row)[0]=f0;						\
  result = row;}-1

#define LL_MAKE_BYTE_ROW_2(clan,f0,f1,result)			\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(2,clan,row);				\
  ((char*)row)[0]=f0;						\
  ((char*)row)[1]=f1;						\
  result = row;}-1

#define LL_MAKE_BYTE_ROW_3(clan,f0,f1,f2,result)		\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(3,clan,row);				\
  ((char*)row)[0]=f0;						\
  ((char*)row)[1]=f1;						\
  ((char*)row)[2]=f2;						\
  result = row;}-1

#define LL_MAKE_BYTE_ROW_4(clan,f0,f1,f2,f3,result)		\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(4,clan,row);				\
  ((char*)row)[0]=f0;						\
  ((char*)row)[1]=f1;						\
  ((char*)row)[2]=f2;						\
  ((char*)row)[3]=f3;						\
  result = row;}-1

#define LL_MAKE_BYTE_ROW_5(clan,f0,f1,f2,f3,f4,result)		\
{ void *row;							\
  MAKE_RAW_SUBOPTIMAL_ROW(5,clan,row);				\
  ((char*)row)[0]=f0;						\
  ((char*)row)[1]=f1;						\
  ((char*)row)[2]=f2;						\
  ((char*)row)[3]=f3;						\
  ((char*)row)[4]=f4;						\
  result = row;}-1

#define LL_MAKE_BYTE_ROW_6(clan,f0,f1,f2,f3,f4,f5,result)	\
{ void *row;							\
  MAKE_RAW_OPTIMAL_ROW(6,clan,row);				\
  ((char*)row)[0]=f0;						\
  ((char*)row)[1]=f1;						\
  ((char*)row)[2]=f2;						\
  ((char*)row)[3]=f3;						\
  ((char*)row)[4]=f4;						\
  ((char*)row)[5]=f5;						\
  result = row;}-1

#define LONER_ALLOC_LENGTH(row_length)				\
	(  BYTES_PER_HEADER		/* loner's header */	\
	 + ((  BYTES_PER_LONER		/* loner's body */	\
	     + BYTES_PER_HEADER		/* row's header */	\
	     + BYTES_PER_QUANTUM-1)				\
	    & (0-BYTES_PER_QUANTUM))	/* realign */		\
	 + row_length			/* row's body */	\
	 + BYTES_PER_QUANTUM-1)		/* align buffer */

/* smaller than this can never be used to host a loner */
#define MINIMUM_LONER_ALLOC_LENGTH()	LONER_ALLOC_LENGTH(SIZE_TO_LENGTH(LLI_MAX_SIZE)+1)
/* smaller than this can never be used to host a chunk -- at least 3 pages */
#define MINIMUM_CHUNK_ALLOC_LENGTH()	(BYTES_PER_CHUNK+BYTES_PER_QUANTUM+3*BYTES_PER_PAGE)

#define ILT_DATA  0
#define ILT_CODE  4
#define ILT_BSS   2
#define ILT_STACK 6
#define ILT_PRIV  0
#define ILT_PUB   1
#define ILT_TYPES 8

LL_EXTERNAL_FUNCTION(char *ilt_segment_type_name, (int type));

LL_EXTERNAL_FUNCTION(int sweep_some_arrays_sizing, (int q));

#define LL_CHECK_IN_ROOTS(root,type)	ll_check_in_roots(root,sizeof(root)>>LOG_BYTES_PER_VOIDSTAR,type)
LL_EXTERNAL_FUNCTION (VSLONG	ll_check_in_roots,	(void **root, VSLONG l, int type)) ;

#define LL_DCL



/* the global iltcrtbss structure, which holds all global variables.
   We put all of them into a single structure because the reference to
   a global address is very costly in PIC code, so we want to minimize them.
   Declarations can be rearranged to accomodate access locality.
   NOTE: Each time you change this structure you have to recompile _all_
   of libiltcrt and every module of libiltrt/libilteval/libiltdev/...
   which references `iltcrtbss' (because the offsets within the structure
   change). On _all_ ports. Like this:

     cd /nfs/talk/work/talk
     for f in `cd $ILT_PORT/o ; for f in *.o ; do if nm $f | grep iltcrtbss > /dev/null ; then echo $f ; fi ; done`
     do
       /bin/rm *?/o/$f
     done

   References to iltcrtbss from Talk code come from the use of:
   [C] the macro LLO_PTR_CLAN_INLINE
   [Talk] the macros `object-clan', `telos.%class-of', `%type-of'.
   These should never be used by customers! 
 */


/* borrowed from llfunction.h */
typedef LL_object	(* LL_code) () ;

typedef struct { LL_code	code ;
		 /* add your favorite fields here */
		 LL_object	*user_field ; /* f->user_field == &(f->system_field[nsf]) */
		 LL_object	system_field[4] ; /* some random value, for cc not to cry */
	 } *LL_function ;

/* borrowed from llsymbol.h */
#define ILT_FAKE_NAME_SLEN 8

typedef struct LL_symbolS { LL_object          cval;
			    LL_function        fval;
			    struct LL_symbolS *pkgc;
			    unsigned char      name[ILT_FAKE_NAME_SLEN];
		    } *LL_symbol;

typedef struct LL_keywordS { void	      *rfu1;
			     LL_symbol	       symbol;
		    } *LL_keyword;


typedef struct {

  /* We put the (big) arrays last in order to have small offsets
     for most elements of this structure. */

  /* llmain */
  LL_symbol _llsym_catch;
  LL_symbol _llsym_dynamic_let;
  LL_symbol _llsym_error;
  LL_symbol _llsym_errudv;
  LL_symbol _llsym_errudg;
  LL_symbol _llsym_clan_type;
  LL_symbol _llsym_errorwna;
  LL_symbol _llsym_system_break;
  LL_symbol _llsym_system_clock;
  LL_symbol _llsym_system_merro;
  LL_symbol _llsym_unwind_protect;
  LL_symbol _llsym_compiled;
  LL_symbol _llsym_emergency_exit_tag;
  LL_symbol _llsym_stack_bottom_gc;
  LL_symbol _llsym_rockbottom_gc;
  int _ilt_building_image;
  
  /* llmm */
  LL_object *_ll_stack_bottom;
  long _log_bytes_per_heap;
  long _log_voidstars_per_heap;
  long _log_quanta_per_heap;
  long _log_pages_per_heap;
  long _bytes_per_heap;
  long _voidstars_per_heap;
  long _quanta_per_heap;
  long _pages_per_heap;
  long _array_misaligned_mask;
  BLONG *_pinvalid_traced;
  LL_necklace _necklace[LLI_MAX_SIZE+1];

  /* Arrays */

  /* llmain */
  /* Path absolu du binaire lelispbin */
#define LLBINDIM 256
  char _lelispbin[LLBINDIM] ;
  char _realbin[LLBINDIM] ;

  } iltcrtbss_struct;

LL_COMMONRT_EXTERNAL(iltcrtbss_struct iltcrtbss);

/* for readability, we use the following shorthands */

#define llsym_catch               iltcrtbss._llsym_catch
#define llsym_dynamic_let         iltcrtbss._llsym_dynamic_let
#define llsym_error               iltcrtbss._llsym_error
#define llsym_errudv              iltcrtbss._llsym_errudv
#define llsym_errudg              iltcrtbss._llsym_errudg
#define llsym_clan_type           iltcrtbss._llsym_clan_type
#define llsym_errorwna            iltcrtbss._llsym_errorwna
#define llsym_system_break        iltcrtbss._llsym_system_break
#define llsym_system_clock        iltcrtbss._llsym_system_clock
#define llsym_system_merro        iltcrtbss._llsym_system_merro
#define llsym_unwind_protect      iltcrtbss._llsym_unwind_protect
#define llsym_compiled            iltcrtbss._llsym_compiled
#define llsym_emergency_exit_tag  iltcrtbss._llsym_emergency_exit_tag
#define llsym_stack_bottom_gc     iltcrtbss._llsym_stack_bottom_gc
#define llsym_rockbottom_gc       iltcrtbss._llsym_rockbottom_gc
#define ilt_building_image        iltcrtbss._ilt_building_image
#define ll_stack_bottom           iltcrtbss._ll_stack_bottom
#define log_bytes_per_heap        iltcrtbss._log_bytes_per_heap
#define log_voidstars_per_heap    iltcrtbss._log_voidstars_per_heap
#define log_quanta_per_heap       iltcrtbss._log_quanta_per_heap
#define log_pages_per_heap        iltcrtbss._log_pages_per_heap
#define bytes_per_heap            iltcrtbss._bytes_per_heap
#define voidstars_per_heap        iltcrtbss._voidstars_per_heap
#define quanta_per_heap           iltcrtbss._quanta_per_heap
#define pages_per_heap            iltcrtbss._pages_per_heap
#define array_misaligned_mask     iltcrtbss._array_misaligned_mask
#define pinvalid_traced           iltcrtbss._pinvalid_traced
#define necklace                  iltcrtbss._necklace
#define lelispbin                 iltcrtbss._lelispbin
#define realbin                   iltcrtbss._realbin

/* intentionally empty */
/*****************************************************************************

 fix.h: Fix manager

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llfix.h,v 3.21 1996/06/19 12:49:08 v16admin Exp $
 ----------------------------------------------------------------------
 ***************************************************************************/

LL_EXTERNAL_FUNCTION (void	ll_init_fix,	(void)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_fixp,	(LL_object object)) ;


/* General stuff about Object representation. */

/* We put the tag bits into the low bits. */
#define LL_LOW_TAG 1

/* to optimize conversion from low-tagged fix to pointer row offset,
   we decide to have as many tag bits as there are 0 bits in a pointer
   row offset (a Lisp pointer is a void* in C) */
#define LL_BITS_PER_TAG		LOG_BYTES_PER_VOIDSTAR

/* Number of remaining bits. */
#define LL_BITS_PER_FIX 	(BITS_PER_VOIDSTAR - LL_BITS_PER_TAG)

/* Macros which get, set and manipulate the tag bits. */
#define LL_TAG_MASK		((1<<LL_BITS_PER_TAG)-1)
#define LL_PTR_TAG(x)		(((VSLONG)(x))&LL_TAG_MASK)
#define LL_DROP_TAG(x)		(((SVSLONG)(x))>>LL_BITS_PER_TAG)
#define LL_SET_PTR_TAG(x,tag)	LL_ADD_TAG((x)<<LL_BITS_PER_TAG,tag)
#define LL_ADD_TAG(x,tag)	(((VSLONG)(x))+tag)
#define LL_SUB_TAG(x,tag)	(((VSLONG)(x))-tag)
#define LL_CLEAR_TAG(x)		(((VSLONG)(x))&(-1-LL_TAG_MASK))
#define LL_FILL_TAG(x)		(((VSLONG)(x))|LL_TAG_MASK)

/* List of predefined tags */
#define LL_FIX_TAG		LL_TAG_MASK
#define LL_CHAR_TAG		LL_TAG_MASK-1
#define LL_MIN_NON_NULL_TAG	LL_TAG_MASK-1

/* Get the clan of an immediate object. */
#define LLO_IMMEDIATE_CLAN(x)	LL_INT2OBJ(LL_PTR_TAG(x))
/* Test whether an object is a non-null immediate. */
#define LLO_PRED_NON_NULL_IMMEDIATE_P(x)	(LL_PTR_TAG(x)>=LL_MIN_NON_NULL_TAG)


/* Fixnums */

#define LL_ADD_FIX_TAG(x)	LL_ADD_TAG(x,LL_FIX_TAG)
#define LL_SUB_FIX_TAG(x)	LL_SUB_TAG(x,LL_FIX_TAG)
#define LL_SET_FIX_TAG(x)	LL_SET_PTR_TAG(x,LL_FIX_TAG)
/* we know fix tag is -1, so we can force it  easily */
#define LL_FORCE_FIX_TAG(x)	LL_FILL_TAG(x)

#define LLO_NUMB(n)		(ll_remember_id(n),ll_nil)
#define LLO_SUBB(n)		(ll_forget_id(n),ll_nil)

#define LLO_BIGGESTFIX()	((LL_object)LL_BIGGESTFIX())
#define LL_BIGGESTFIX()		(LL_INT2FIX(LLI_BIGGESTFIX()))
#define LLI_BIGGESTFIX()	((1L<<(LL_BITS_PER_FIX-1))-1)

#define LLO_SMALLESTFIX()	((LL_object)LL_SMALLESTFIX())
#define LL_SMALLESTFIX()	(LL_INT2FIX(LLI_SMALLESTFIX()))
#define LLI_SMALLESTFIX()	(-1-LLI_BIGGESTFIX())

#define LLO_FIXP(object)	ll_fixp(LL_THE_OBJECT(object))

#define LLO_PRED_FIXP(object)	LL_PRED_FIXP(LL_THE_OBJECT(object))
#define LL_PRED_FIXP(object)	(LL_PTR_TAG(object)==LL_FIX_TAG)

#define LLO_FIX2INT(object)	LL_FIX2INT((LL_fix)LL_THE_OBJECT(object))
#define LLO_INT2FIX(integer)	((LL_object)LL_INT2FIX(LL_THE_OBJECT(integer)))

#define LL_INT2OBJ(integer)	((LL_object)LL_INT2FIX(LL_THE_INT(integer)))
#define LL_OBJ2INT(o)		(LL_FIX2INT((VSLONG)LL_THE_OBJECT(o)))
#define LL_FIX2INT(fix)		((VSLONG)LL_DROP_TAG(LL_THE_FIX(fix)))
#define LL_INT2FIX(i)		((LL_object)LL_SET_FIX_TAG(LL_THE_INT(i)))

#define LLO_BINARY(op,i,j)	((LL_object)op((LL_fix)LL_THE_OBJECT(i),(LL_fix)LL_THE_OBJECT(j)))
#define LL_BINARY(op,i,j)	(LL_INT2FIX(op((VSLONG)LL_FIX2INT(LL_THE_FIX(i)),(VSLONG)LL_FIX2INT(LL_THE_FIX(j)))))
#define LL_SIGNED_BINARY(op,i,j)	(LL_INT2FIX(op((SVSLONG)LL_FIX2INT(LL_THE_FIX(i)),(SVSLONG)LL_FIX2INT(LL_THE_FIX(j)))))
#define LLI_BINARY(op,i,j)	((LL_THE_INT(i)) op (LL_THE_INT(j)))


/* \\ should be optimized: a+b-3 in fix30l, ll_int2fix(a+b) in fix31h */
#define LLO_ADD(i,j)		LLO_BINARY(LL_ADD,i,j)
/* #define LL_ADD(i,j)		LL_BINARY(LLI_ADD,i,j) */
/* optimized into: (-tag is better than &, because cc optimizes 
   if one arg is a constant) */
#define LL_ADD(i,j)		((LL_fix)LL_SUB_FIX_TAG((VSLONG)(i)+(VSLONG)(j)))
#define LLI_ADD(i,j)		LLI_BINARY(+,i,j)

#define LLO_SUB(i,j)		LLO_BINARY(LL_SUB,i,j)
/* #define LL_SUB(i,j)		LL_BINARY(LLI_SUB,i,j) */
/* optimized into: (+tag is better than |, because cc optimizes 
   if one arg is a constant) */
#define LL_SUB(i,j)		((LL_fix)LL_ADD_FIX_TAG((VSLONG)(i)-(VSLONG)(j)))
#define LLI_SUB(i,j)		LLI_BINARY(-,i,j)

/* \\ should be optimized: a*ll_fix2int(b) in fix30l, ll_int2fix(a*b) in fix31h */
#define LLO_MUL(i,j)		LLO_BINARY(LL_MUL,i,j)
/* #define LL_MUL(i,j)		LL_BINARY(LLI_MUL,i,j) */
/* optimized, non-symetric (dunno which side is best) into: */
#define LL_MUL(i,j)		((LL_fix)LL_ADD_FIX_TAG(LL_SUB_FIX_TAG(i)*LL_DROP_TAG(j)))
#define LLI_MUL(i,j)		LLI_BINARY(*,i,j)

#define LLO_DIV(i,j)		LLO_BINARY(LL_DIV,i,j)
#define LL_DIV(i,j)		LL_SIGNED_BINARY(LLI_DIV,i,j)
#define LLI_DIV(i,j)		LLI_BINARY(/,i,j)

#define LLO_REM(i,j)		LLO_BINARY(LL_REM,i,j)
#define LL_REM(i,j)		LL_SIGNED_BINARY(LLI_REM,i,j)
#define LLI_REM(i,j)		LLI_BINARY(%,i,j)

#define LLO_LOGOR(i,j)		LLO_BINARY(LL_LOGOR,i,j)
/* #define LL_LOGOR(i,j)		LL_BINARY(LLI_LOGOR,i,j) */
/* optimized into: */
#define LL_LOGOR(i,j)		((LL_fix)(((VSLONG)(i))|((VSLONG)(j))))
#define LLI_LOGOR(i,j)		LLI_BINARY(|,i,j)

#define LLO_LOGXOR(i,j)		LLO_BINARY(LL_LOGXOR,i,j)
/* #define LL_LOGXOR(i,j)		LL_BINARY(LLI_LOGXOR,i,j) */
/* optimized, non-symetric (dunno which side is best) into: */
#define LL_LOGXOR(i,j)		((LL_fix)(((VSLONG)(i))^LL_CLEAR_TAG(j)))
#define LLI_LOGXOR(i,j)		LLI_BINARY(^,i,j)

#define LLO_LOGAND(i,j)		LLO_BINARY(LL_LOGAND,i,j)
/* #define LL_LOGAND(i,j)		LL_BINARY(LLI_LOGAND,i,j) */
/* optimized into: */
#define LL_LOGAND(i,j)		((LL_fix)(((VSLONG)(i))&((VSLONG)(j))))
#define LLI_LOGAND(i,j)		LLI_BINARY(&,i,j)

#define LLO_LOGSHIFT_R(i,j)	LLO_BINARY(LL_LOGSHIFT_R,i,j)
#define LL_LOGSHIFT_R(i,j)	LL_SIGNED_BINARY(LLI_LOGSHIFT_R,i,j)
#define LLI_LOGSHIFT_R(i,j)	LLI_BINARY(>>,i,j)

#define LLO_LOGSHIFT_L(i,j)	LLO_BINARY(LL_LOGSHIFT_L,i,j)
#define LL_LOGSHIFT_L(i,j)	LL_BINARY(LLI_LOGSHIFT_L,i,j)
#define LLI_LOGSHIFT_L(i,j)	LLI_BINARY(<<,i,j)

#define LLO_PRED_COMPARISON(op,i,j)	op(LL_THE_OBJECT(i),LL_THE_OBJECT(j))
/* #define LL_PRED_COMPARISON(op,i,j)	op(LL_FIX2INT(LL_THE_FIX(i)),LL_FIX2INT(LL_THE_FIX(j))) */
/* optimized into: */
#define LL_PRED_COMPARISON(op,i,j)	op(LL_THE_FIX(i), LL_THE_FIX(j))
#define LLI_PRED_SIGNED_COMPARISON(op,i,j)	(((SVSLONG)LL_THE_INT(i)) op ((SVSLONG)LL_THE_INT(j)))

#define LLO_PRED_GE(i,j)	LLO_PRED_COMPARISON(LL_PRED_GE,i,j)
#define LL_PRED_GE(i,j)		LL_PRED_COMPARISON(LLI_PRED_GE,i,j)
#define LLI_PRED_GE(i,j)	LLI_PRED_SIGNED_COMPARISON(>=,i,j)

#define LLO_PRED_GT(i,j)	LLO_PRED_COMPARISON(LL_PRED_GT,i,j)
#define LL_PRED_GT(i,j)		LL_PRED_COMPARISON(LLI_PRED_GT,i,j)
#define LLI_PRED_GT(i,j)	LLI_PRED_SIGNED_COMPARISON(>,i,j)

#define LLO_PRED_LE(i,j)	LLO_PRED_COMPARISON(LL_PRED_LE,i,j)
#define LL_PRED_LE(i,j)		LL_PRED_COMPARISON(LLI_PRED_LE,i,j)
#define LLI_PRED_LE(i,j)	LLI_PRED_SIGNED_COMPARISON(<=,i,j)

#define LLO_PRED_LT(i,j)	LLO_PRED_COMPARISON(LL_PRED_LT,i,j)
#define LL_PRED_LT(i,j)		LL_PRED_COMPARISON(LLI_PRED_LT,i,j)
#define LLI_PRED_LT(i,j)	LLI_PRED_SIGNED_COMPARISON(<,i,j)

#define LLO_PRED_EQN(i,j)	LLO_PRED_COMPARISON(LL_PRED_EQN,i,j)
#define LL_PRED_EQN(i,j)	LL_PRED_COMPARISON(LLI_PRED_EQN,i,j)
#define LLI_PRED_EQN(i,j)	LLI_PRED_SIGNED_COMPARISON(==,i,j)

#define LLO_PRED_NEQN(i,j)	LLO_PRED_COMPARISON(LL_PRED_NEQN,i,j)
#define LL_PRED_NEQN(i,j)	LL_PRED_COMPARISON(LLI_PRED_NEQN,i,j)
#define LLI_PRED_NEQN(i,j)	LLI_PRED_SIGNED_COMPARISON(!=,i,j)

#define LLO_UNARY(op,i)		((LL_object)(op((VSLONG)LL_THE_OBJECT(i))))
#define LL_UNARY(op,i)		(LL_INT2FIX(op(LL_FIX2INT(LL_THE_FIX(i)))))
#define LLI_UNARY(op,i)		((LL_THE_INT(i) op))

#define LLO_ADD1(i)		LLO_UNARY(LL_ADD1,i)
/* #define LL_ADD1(i)		LL_UNARY(LLI_ADD1,i) */
/* optimized into: */
#define LL_ADD1(i)		LL_ADD(i,LL_INT2FIX(1))
#define LLI_ADD1(i)		LLI_UNARY(+1,i)

#define LLO_SUB1(i)		LLO_UNARY(LL_SUB1,i)
/* #define LL_SUB1(i)		LL_UNARY(LLI_SUB1,i) */
/* optimized into: */
#define LL_SUB1(i)		LL_SUB(i,LL_INT2FIX(1))
#define LLI_SUB1(i)		LLI_UNARY(-1,i)

#define LLO_ABSN(i)		LLO_UNARY(LL_ABSN,i)
#define LL_ABSN(i)		LL_UNARY(LLI_ABSN,i)
/* could be optimized to mask|abs(i-mask), wins just one instruction
   over mask+abs(i>>2)<<2) */
#if defined(ILT_OS_UNIX_BSD)
/* BSD is not posix!! */
#define LLI_ABSN(i)		abs(LL_THE_INT(i))
#else
#define LLI_ABSN(i)		labs(LL_THE_INT(i))
#endif

#define LLO_LOGNOT(i)		LLO_UNARY(LL_LOGNOT,i)
/* #define LL_LOGNOT(i)		LL_UNARY(LLI_LOGNOT,i) */
/* optimized, (mind the asymetry of LOGXOR optimization) into: */
#define LL_LOGNOT(i)		LL_LOGXOR(i,LL_INT2FIX(-1))
#define LLI_LOGNOT(i)		(~(LL_THE_INT(i)))

LL_EXTERNAL_FUNCTION (void* ilt_btoi_gen,	(void* a));
LL_EXTERNAL_FUNCTION (void* ilt_ftoi_gen,	(void* a));
LL_EXTERNAL_FUNCTION (void* ilt_longtoi_gen,	(long l));
LL_EXTERNAL_FUNCTION (void* ilt_make_rational,	(void* a, void* b));

LL_EXTERNAL_FUNCTION (unsigned long ilt_btoulong, (void* a));

LL_EXTERNAL_FUNCTION (long ilt_bzerop,	(void* a));

LL_EXTERNAL_FUNCTION (void* ilt_iadd_gen,	(void* a, void* b));
LL_EXTERNAL_FUNCTION (void* ilt_isub_gen,	(void* a, void* b));
LL_EXTERNAL_FUNCTION (void* ilt_imul_gen,	(void* a, void* b));
LL_EXTERNAL_FUNCTION (void* ilt_idiv_gen,	(void* a, void* b));

LL_EXTERNAL_FUNCTION (void* ilt_badd_gen,	(void* a, void* b));
LL_EXTERNAL_FUNCTION (void* ilt_bsub_gen,	(void* a, void* b));
LL_EXTERNAL_FUNCTION (void* ilt_bmul_gen,	(void* a, void* b));
LL_EXTERNAL_FUNCTION (void* ilt_bdiv_gen,	(void* a, void* b));
LL_EXTERNAL_FUNCTION (void* ilt_bmod_gen,	(void* a, void* b));

/* characters */

#define LLO_PRED_CHARP(object)	LL_PRED_CHARP(LL_THE_OBJECT(object))
#define LL_PRED_CHARP(object)	(LL_PTR_TAG(object)==LL_CHAR_TAG)

/* fix2char conservatively masks ff */
#define LLO_FIX2CHAR(fix)	((void*)LL_ADD_TAG(((long)LL_INT2FIX(0xFF))&((long)LL_CLEAR_TAG(fix)),LL_CHAR_TAG))
#define LLO_CHAR2FIX(char)	((void*)LL_ADD_TAG(LL_CLEAR_TAG(char),LL_FIX_TAG))

/* is char in ISO 8859? reminder: in Talk, all character codes are positive */
#define LLO_PRED_CHAR_CODE_P(fix)	(((unsigned long)LLO_FIX2INT(fix))<256)

/* NEW STYLE CONVERTORS */
/* excerpt from talk.h */

/* C long <-> Talk fix convertors. Signatures:
   void *ILT_CLONG2TINT(long i);
   long ILT_TINT2CLONG(void *ti); */


/* long size. The cpp portable trick used here works only for long.
   IRIX5 cpp is buggy: its long are 64b whereas C's are 32b, so we
   MUST predefine ILT_LOG_SIZEOF_LONG there (-D) */

#ifndef ILT_LOG_SIZEOF_LONG
#if ((1L<<16)==1) || ((1L<<16)==0)
#define ILT_LOG_SIZEOF_LONG	1
#else
#if ((1L<<32)==1) || ((1L<<32)==0) || (defined(ILT_OS_UNIX_IRIX) && !defined(ILT_ARC_MIPS64))
#define ILT_LOG_SIZEOF_LONG	2
#else
#if ((1L<<48)==1) || ((1L<<48)==0)
#define ILT_LOG_SIZEOF_LONG	9999999999999
#else
#if ((1L<<64)==1) || ((1L<<64)==0)
#define ILT_LOG_SIZEOF_LONG	3
#else
#define ILT_LOG_SIZEOF_LONG	9999999999999
#endif
#endif
#endif
#endif
#endif

#define ILT_CLONG2TINT(i)						\
        ((void*)(((i)*sizeof(void*))|(sizeof(void*)-1)))
#define ILT_TINT2CLONG(f)						\
        (((long)(f))>>ILT_LOG_SIZEOF_LONG)
#define ILT_CLONG2TCHAR(i)						\
        ((void*)(((i)*sizeof(void*))|(sizeof(void*)-2)))
#define ILT_TCHAR2CLONG(f)						\
        ((unsigned char)((long)(f)>>ILT_LOG_SIZEOF_LONG))
/*****************************************************************************

 llcons.h: List cell managment

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llcons.h,v 3.9 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ***************************************************************************/

typedef struct
{
  LL_object car;
  LL_object cdr;
} *LL_cons;

#define LLO_CONSP(object)		ll_consp(LL_THE_OBJECT(object))
#define LLO_PRED_CONSP(object)		LL_PRED_CONSP(LL_THE_OBJECT(object))
#define LLO_MAKE_CONS(car,cdr)		\
	((LL_object)(ll_make_cons(LL_THE_OBJECT(car), LL_THE_OBJECT(cdr))))

/* inlined cons allocator */
#define LLO_MAKE_CONS_IN(car, cdr, cons)	\
	LL_MAKE_POINTER_ROW_2(LL_CONS_CLAN, car, cdr, cons)

#define LLO_CAR(o)	(((LL_cons)(o))->car)
#define LLO_CDR(o)	(((LL_cons)(o))->cdr)
#define LLO_CAAR(o)	(LLO_CAR(LLO_CAR(o)))
#define LLO_CADR(o)	(LLO_CAR(LLO_CDR(o)))
#define LLO_CDAR(o)	(LLO_CDR(LLO_CAR(o)))
#define LLO_CDDR(o)	(LLO_CDR(LLO_CDR(o)))
#define LLO_CAAAR(o)	(LLO_CAR(LLO_CAAR(o)))
#define LLO_CAADR(o)	(LLO_CAR(LLO_CADR(o)))
#define LLO_CADAR(o)	(LLO_CAR(LLO_CDAR(o)))
#define LLO_CADDR(o)	(LLO_CAR(LLO_CDDR(o)))
#define LLO_CDAAR(o)	(LLO_CDR(LLO_CAAR(o)))
#define LLO_CDADR(o)	(LLO_CDR(LLO_CADR(o)))
#define LLO_CDDAR(o)	(LLO_CDR(LLO_CDAR(o)))
#define LLO_CDDDR(o)	(LLO_CDR(LLO_CDDR(o)))
#define LLO_CAAAAR(o)	(LLO_CAR(LLO_CAAAR(o)))
#define LLO_CAAADR(o)	(LLO_CAR(LLO_CAADR(o)))
#define LLO_CAADAR(o)	(LLO_CAR(LLO_CADAR(o)))
#define LLO_CAADDR(o)	(LLO_CAR(LLO_CADDR(o)))
#define LLO_CADAAR(o)	(LLO_CAR(LLO_CDAAR(o)))
#define LLO_CADADR(o)	(LLO_CAR(LLO_CDADR(o)))
#define LLO_CADDAR(o)	(LLO_CAR(LLO_CDDAR(o)))
#define LLO_CADDDR(o)	(LLO_CAR(LLO_CDDDR(o)))
#define LLO_CDAAAR(o)	(LLO_CDR(LLO_CAAAR(o)))
#define LLO_CDAADR(o)	(LLO_CDR(LLO_CAADR(o)))
#define LLO_CDADAR(o)	(LLO_CDR(LLO_CADAR(o)))
#define LLO_CDADDR(o)	(LLO_CDR(LLO_CADDR(o)))
#define LLO_CDDAAR(o)	(LLO_CDR(LLO_CDAAR(o)))
#define LLO_CDDADR(o)	(LLO_CDR(LLO_CDADR(o)))
#define LLO_CDDDAR(o)	(LLO_CDR(LLO_CDDAR(o)))
#define LLO_CDDDDR(o)	(LLO_CDR(LLO_CDDDR(o)))

#define LL_PRED_CONSP(o) (LL_CONS_CLAN==ll_object_clan(LL_THE_OBJECT(o)))
#define LL_CAR(c)	 ((LL_THE_CONS(c))->car)
#define LL_CDR(c)	 ((LL_THE_CONS(c))->cdr)
#define LL_SET_CAR(c,o)	 (((LL_THE_CONS(c))->car=LL_THE_OBJECT(o)))
#define LL_SET_CDR(c,o)	 (((LL_THE_CONS(c))->cdr=LL_THE_OBJECT(o)))
#define LLO_SET_CAR(c,o) (LL_SET_CAR((LL_cons)c,o))
#define LLO_SET_CDR(c,o) (LL_SET_CDR((LL_cons)c,o))

LL_EXTERNAL_FUNCTION (void*	ll_free_list, (void* list));
LL_EXTERNAL_FUNCTION (LL_cons	ll_make_cons, (LL_object car, LL_object cdr));
LL_EXTERNAL_FUNCTION (LL_object	ll_consp,     (LL_object object));
LL_EXTERNAL_FUNCTION (void	ll_init_cons, (void));

/*****************************************************************************

 llnil.h: experimental nil managment

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llnil.h,v 3.7 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

/* This ought to be called LLO_NIL. */
#define ll_nil			((LL_object)0)

/* nil used as a symbol */
#define LL_NIL_S		((LL_symbol) ll_nil)
/* nil used as a cons */
#define LL_NIL_C		((LL_cons) ll_nil)

#define LL_PRED_NULL(x)		(x==ll_nil)
#define LLO_PRED_NULL(x)	LL_PRED_NULL(LL_THE_OBJECT(x))

#define LL_PRED_NOT(x)		(x==ll_nil)
#define LLO_PRED_NOT(x)		LL_PRED_NOT(LL_THE_OBJECT(x))

LL_EXTERNAL_FUNCTION (void	ll_init_nil,	(void)) ;

/*****************************************************************************

 llt.h: The 't' symbol managment

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llt.h,v 3.7 1996/03/19 15:18:54 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

LL_COMMONRT_EXTERNAL(LL_object llsym_t);

LL_EXTERNAL_FUNCTION (void	ll_init_t		,(void)) ;

#define LLO_EQ(i,j)		((LL_object)LL_EQ((LL_object)(i),(LL_object)(j)))
#define LLO_PRED_EQ(i,j)	(LL_PRED_EQ(i,j))
#define LL_EQ(i,j)		(LL_PRED_EQ(i,j)?llsym_t:ll_nil)
#define LL_PRED_EQ(i,j)		((i)==(j))

#define LLO_NEQ(i,j)		((LL_object)LL_NEQ((LL_object)(i),(LL_object)(j)))
#define LLO_PRED_NEQ(i,j)	(LL_PRED_NEQ(i,j))
#define LL_NEQ(i,j)		(LL_PRED_NEQ(i,j)?llsym_t:ll_nil)
#define LL_PRED_NEQ(i,j)	((i)!=(j))
/*****************************************************************************

 llundef.h: undefined object managment

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llundef.h,v 3.3 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

LL_COMMONRT_EXTERNAL (LL_object	ll_undef);

LL_EXTERNAL_FUNCTION (void	ll_init_undef,	(void)) ;

#define LLO_UNDEF()	((LL_object)LL_UNDEF())
#define LL_UNDEF()	ll_undef
/*****************************************************************************

 vector.h: experimental vector managment

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llvector.h,v 3.9 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ******************************************************************************/

typedef LL_object			*LL_vector;
#define LL_pointer_row	LL_vector
typedef VSLONG				LL_vos ; /* vector offset */
#define LL_INT2VOS(i)		(LL_THE_INT(i)<<LOG_BYTES_PER_VOIDSTAR)
#define LL_VOS2INT(i)		(LL_THE_VOS(i)>>LOG_BYTES_PER_VOIDSTAR)
/* #define LL_FIX2VOS(i)		(LL_THE_FIX(i)<<LOG_BYTES_PER_VOIDSTAR) */
#if (LL_LOW_TAG && (LL_BITS_PER_TAG == LOG_BYTES_PER_VOIDSTAR))
/* lowtag with optimized indexing */
#define LL_FIX2VOS(i)		((LL_vos)LL_SUB_FIX_TAG(i))
#define LL_VOS2FIX(i)		((LL_fix)LL_FORCE_FIX_TAG(i))
#else
#if LL_HIGH_TAG
/* hightag */
#define LL_FIX2VOS(i)		(LL_INT2VOS(LL_FIX2INT(i)))
#define LL_VOS2FIX(i)		((LL_THE_VOS(i)>>LOG_BYTES_PER_VOIDSTAR)|~(((VSLONG)-1)>>1))
#else
ARgl!!! This is unseen so far... (LL_LOW_TAG && (LL_BITS_PER_TAG == LOG_BYTES_PER_VOIDSTAR))
#endif
#endif

#define LL_PRED_VECTORP(o)	(LL_VECTOR_CLAN==ll_object_clan(LL_THE_OBJECT(o)))
#define LLO_PRED_VECTORP(o)	(LL_VECTOR_CLAN==ll_object_clan(LL_THE_OBJECT(o)))
#define LLO_MAKE_VECTOR(len,ob)	((LL_object)llv_make_vector(LL_FIX2VOS((LL_fix)LL_THE_OBJECT(len)),LL_THE_OBJECT(ob)))
#define LL_MAKE_VECTOR(len,ob)	(llv_make_vector(LL_FIX2VOS(LL_THE_FIX(len)),LL_THE_OBJECT(ob)))
#define LLI_MAKE_VECTOR(len,ob)	(llv_make_vector(LL_INT2VOS(LL_THE_INT(len)),LL_THE_OBJECT(ob)))
LL_EXTERNAL_FUNCTION (LL_vector	llv_make_vector,	(LL_vos byte_length,
							 LL_object object)) ;

/* just like make vector, except the contents random */
#define LLO_MAKE_THING_ARRAY(len)	((LL_object)LLV_MAKE_THING_ARRAY(LL_FIX2VOS((LL_fix)LL_THE_OBJECT(len))))
#define LL_MAKE_THING_ARRAY(len)	(LLV_MAKE_THING_ARRAY(LL_FIX2VOS(LL_THE_FIX(len))))
#define LLI_MAKE_THING_ARRAY(len)	(LLV_MAKE_THING_ARRAY(LL_INT2VOS(LL_THE_INT(len))))
#define LLV_MAKE_THING_ARRAY(len)	(lli_make_array(LL_THE_VOS(len), LL_VECTOR_CLAN))

#define LLV_VLEN(v)		(LLI_ARRAY_LENGTH((LL_object)LL_THE_VECTOR(v)))
#define LLI_VLEN(v)		(LL_VOS2INT(LLV_VLEN(LL_THE_VECTOR(v))))
#define LL_VLEN(v)		(LL_VOS2FIX(LLV_VLEN(LL_THE_VECTOR(v))))
#define LLO_VLEN(v)		((LL_object)(LL_VLEN((LL_vector)LL_THE_OBJECT(v))))

#define LLV_VREF(v,i)		(*((LL_object*)(((VSLONG)LL_THE_VECTOR(v))+(LL_THE_VOS(i)))))
#define LLI_VREF(v,i)		(LLV_VREF(v,LL_INT2VOS(LL_THE_INT(i))))
#define LL_VREF(v,i)		(LLV_VREF(v,LL_FIX2VOS(LL_THE_FIX(i))))
#define LLO_VREF(v,i)		(LL_VREF(v,(LL_fix)(LL_THE_OBJECT(i))))

#define LLV_VSET(v,i,o)		(*((LL_object*)(((VSLONG)LL_THE_VECTOR(v))+(LL_THE_VOS(i))))=o)
#define LLI_VSET(v,i,o)		(LLV_VSET(v,LL_INT2VOS(LL_THE_INT(i)),o))
#define LL_VSET(v,i,o)		(LLV_VSET(v,LL_FIX2VOS(LL_THE_FIX(i)),o))
#define LLO_VSET(v,i,o)		(LL_VSET(v,(LL_fix)(LL_THE_OBJECT(i)),o))

/* If the CC used is permissive, we should expand LL_SET(v,i,o) into:
   ((LL_vector)(((VSLONG)v)+LL_FIX2VOS(i))=o, which is more optimizable by
   CC, esp. on RISC processors. */

LL_EXTERNAL_FUNCTION (void	ll_init_vector,		(void)) ;
LL_EXTERNAL_FUNCTION (LL_object	llo_vset_kludge,	(LL_object v,
							 LL_object i,
							 LL_object o)) ;
/*****************************************************************************

 llhash.h: boot hash table and friends

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llhash.h,v 3.10 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/


typedef LL_cons LL_boot_hash_table ;

LL_EXTERNAL_FUNCTION (LL_boot_hash_table	ll_make_boot_hash_table,	(void)) ;
LL_EXTERNAL_FUNCTION (LL_boot_hash_table	ll_make_boot_eqstring_hash_table,	(void)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_get_boot_hash,	(LL_object key,
							 LL_boot_hash_table at,
							 LL_object default)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_get_boot_hash_key,	(LL_object val,
							 LL_boot_hash_table at,
							 LL_object default)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_put_boot_hash,	(LL_object key,
							 LL_boot_hash_table at,
							 LL_object value)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_map_boot_hash,	(LL_function f,
							 LL_boot_hash_table at)) ;


/*****************************************************************************

 newllhash.h: The old new hash tables.  Like the Pont Neuf.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
  $Header: /nfs/talk/work/talk/common/RCS/newllhash.h,v 1.14 1996/01/13 11:21:08 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/



/*
 * Hash table representation. We use open adressing linear probing with double
 * hashing and a bucket size of 1. See Knuth Vol. 3.
 */

typedef void *ht_value;		/* Type of a hash table value */
typedef void *ht_key;		/* Type of a hash table key */

typedef struct
{
     LL_object hash_fn;		/* Hashing function (Talk fn) */
     LL_object compare_fn;	/* Comparison function (Talk fn) */
     VSLONG initial_size;	/* Initial size (a power of 2) */
     VSLONG size;		/* Current size (a power of 2) */
     VSLONG mask;		/* Cache for mask used in hash functions */
     LL_vector table;		/* A vector of size 2*size */
} *LL_htable;

#define HT_NULL ((ht_value)4)	/* Marker for null keys and values, so it */
				/* it can't be used as a legal key or value. */


/*
 * Hashing macros.
 */

#define HASH_MASK(size) ((size-1)<<1) /* Mask for fast modulo */

/* Macros for EQ hash tables */
#define LOST_BITS 	5	/* Insignificant bits in addresses */
#define HASH_ADDRESS(addr, mask)	(((VSLONG)(addr)>>LOST_BITS)&(mask))

/* Macros for EQN hash tables */
#define HASH_FIX(fix, mask)		((LLO_FIX2INT(fix))&(mask))

/* Rehashing macros */
#define HASH_INCREMENT(index)		(index|2)
#define REHASH(index, incr, mask)	((index+incr)&(mask))

/* For in-pattern-table */
#if 0 /* Can someone please explain to me why there are two macros
       * ILT_TINT2CLONG and LL_FIX2INT for the same purpose?
       */
#define PT_VREF(pt, index)		((pt)->table[(ILT_TINT2CLONG(index))])
#define PT_NENTRIES(pt)			(ILT_CLONG2TINT(((pt)->size)*2))
#else
#define PT_VREF(pt, index) (((LL_htable)pt)->table[(LL_FIX2INT(index))])
#define PT_NENTRIES(pt)	   (LL_INT2FIX((((LL_htable)pt)->size)*2))
#endif
#define PT_NULL()	   (4)
#define LLO_PT_NULL()	((LL_object)PT_NULL())


/*
 * Exported functions
 */

LL_EXTERNAL_FUNCTION (LL_htable ll_make_hash_table, (ht_type, VSLONG));
LL_EXTERNAL_FUNCTION (LL_htable ll_make_hash_table_eq, (VSLONG));
LL_EXTERNAL_FUNCTION (LL_htable ll_make_hash_table_eqstring, (VSLONG));
LL_EXTERNAL_FUNCTION (LL_htable ll_make_hash_table_gen,
		      (VSLONG, LL_object, LL_object));
LL_EXTERNAL_FUNCTION (ht_value ll_gethash, (ht_key, LL_htable, ht_value));
LL_EXTERNAL_FUNCTION (ht_value ll_puthash, (ht_key, LL_htable, ht_value));
LL_EXTERNAL_FUNCTION (VSLONG ll_remhash, (ht_key, LL_htable));
LL_EXTERNAL_FUNCTION (LL_htable ll_clrhash, (LL_htable));

LL_EXTERNAL_FUNCTION (void ll_maphash, (LL_htable, void (*fun)(), void *));
LL_EXTERNAL_FUNCTION (void ll_maphash_lisp, (LL_htable, LL_object));
LL_EXTERNAL_FUNCTION (VSLONG ll_hash_table_count, (LL_htable));
#if 0 /* avoid error in `ilthe' */
LL_EXTERNAL_FUNCTION (VSLONG ll_hash_string, (char *));
#endif
LL_EXTERNAL_FUNCTION (LL_object ll_hash_table_hash_fn, (LL_htable));
LL_EXTERNAL_FUNCTION (LL_object ll_hash_table_compare_fn, (LL_htable));
LL_EXTERNAL_FUNCTION (LL_vector ll_hash_table_values, (LL_htable));

/*
 * Primitives
 */

#define LLO_GETHASH(key, ht, deft) \
((LL_object)ll_gethash((ht_key)(key), (LL_htable)(ht), (ht_value)(deft)))

#define LLO_PUTHASH(key, ht, value) \
     ((LL_object)ll_puthash((ht_key)(key), (LL_htable)(ht), (ht_value)(value)))

#define LLO_REMHASH(key, ht) \
     ((LL_object)((ll_remhash((ht_key)(key), (LL_htable)(ht)))?llsym_t:ll_nil))

#define LLO_CLRHASH(ht) \
     ((LL_object)ll_clrhash((LL_htable)(ht)))

/*****************************************************************************

 llstring.h: string managment

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llstring.h,v 3.19 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ***************************************************************************/

#include <iltsystem.h>

typedef unsigned char			LL_char;
typedef LL_char				*LL_string;
#define LL_char_row	LL_string
typedef VSLONG				LL_sos ; /* string offset */
typedef VSLONG				LL_bos ; /* byte array offset */
#define LL_INT2SOS(i)		((LL_sos)(LL_THE_INT(i)))
#define LL_SOS2INT(i)		((VSLONG)(LL_THE_SOS(i)))
#define LL_INT2BOS(i)		((LL_bos)(LL_THE_INT(i)))
#define LL_BOS2INT(i)		((VSLONG)(LL_THE_BOS(i)))
#define LL_FIX2SOS(i)		((LL_sos)(LL_FIX2INT(i)))
#define LL_SOS2FIX(i)		(LL_INT2FIX((VSLONG)(i)))
#define LL_FIX2BOS(i)		((LL_bos)(LL_FIX2INT(i)))
#define LL_BOS2FIX(i)		(LL_INT2FIX((VSLONG)(i)))

/* #define LLO_STRINGP(object)		ll_stringp(LL_THE_OBJECT(object)) */
#define LLO_PRED_STRINGP(object)	LL_PRED_STRINGP(LL_THE_OBJECT(object))
#define LL_PRED_STRINGP(o)		(LL_STRING_CLAN==ll_object_clan(LL_THE_OBJECT(o)))

#define LLI_PRED_EQSTRING(s1,s2)		(lli_eqstring((char*)LL_THE_STRING(s1),(char*)LL_THE_STRING(s2)))
#define LL_PRED_EQSTRING(s1,s2)		(lli_eqstring((char*)LL_THE_STRING(s1),(char*)LL_THE_STRING(s2)))
#define LLO_PRED_EQSTRING(s1,s2)	(LL_PRED_EQSTRING((LL_string)LL_THE_STRING(s1),(LL_string)LL_THE_STRING(s2)))
/* #define LLO_EQSTRING(s1,s2)		((LL_object)ll_eqstring((LL_string)LL_THE_OBJECT(s1),(LL_string)LL_THE_OBJECT(s2))) */

#define LLO_MAKE_STRING(len,ch)		((LL_object)(LL_MAKE_STRING((LL_fix)LL_THE_OBJECT(len),(LL_fix)LL_THE_OBJECT(ch))))
#define LLO_MAKE_STRING_COPYING_C(stg)	((LL_object)(ll_make_string_copying_c(LL_THE_STRING(stg))))
#define LL_MAKE_STRING(len,ch)		(lli_make_string(LL_FIX2INT(LL_THE_FIX(len)),LL_FIX2INT(LL_THE_FIX(ch))))

/* just like make string, except the contents random */
#define LLO_MAKE_CHARACTER_ARRAY(len)	((LL_object)LLS_MAKE_CHARACTER_ARRAY(LL_FIX2SOS((LL_fix)LL_THE_OBJECT(len))))
#define LL_MAKE_CHARACTER_ARRAY(len)	(LLS_MAKE_CHARACTER_ARRAY(LL_FIX2SOS(LL_THE_FIX(len))))
#define LLI_MAKE_CHARACTER_ARRAY(len)	(LLS_MAKE_CHARACTER_ARRAY(LL_INT2SOS(LL_THE_INT(len))))
#define LLS_MAKE_CHARACTER_ARRAY(len)	(lli_make_array(LL_THE_SOS(len), LL_STRING_CLAN))

#define LLO_BLEN(s)		((LL_object)LL_BLEN(s))
#define LL_BLEN(s)		LL_INT2FIX(LLI_ARRAY_LENGTH(s))

#define LLS_SLEN(s)		(LLI_ARRAY_LENGTH((LL_object)LL_THE_STRING(s))-BYTES_PER_CHARACTER)
#define LLI_SLEN(s)		(LL_SOS2INT(LLS_SLEN(s)))
#define LL_SLEN(s)		(LL_SOS2FIX(LLS_SLEN(s)))

#define LLO_SLEN(s)		((LL_object)(LL_SLEN((LL_string)(s))))

#define LLS_SREF(s,i)		((VSLONG)(*((LL_char*)(((VSLONG)LL_THE_STRING(s))+(LL_THE_SOS(i))))))
#define LLI_SREF(s,i)		(LLS_SREF(s,LL_INT2SOS(LL_THE_INT(i))))
#define LL_SREF(s,i)		(LLO_FIX2CHAR(LL_INT2FIX(LLS_SREF(s,LL_FIX2SOS(LL_THE_FIX(i))))))

#define LLO_SREF(s,i)		((LL_object)LL_THE_FIX(LL_SREF(s,(LL_fix)LL_THE_OBJECT(i))))


/* Reference to a byte array */
#define LLB_BREF(s,i)		((VSLONG)(*((LL_char*)(((VSLONG)LL_THE_VECTOR(s))+(LL_THE_BOS(i))))))
#define LLI_BREF(s,i)		(LLB_BREF(s,LL_INT2BOS(LL_THE_INT(i))))
#define LL_BREF(s,i)		(LL_INT2FIX(LLB_BREF(s,LL_FIX2BOS(LL_THE_FIX(i)))))
#define LLO_BREF(s,i)		((LL_object)LL_THE_FIX(LL_BREF(s,(LL_fix)LL_THE_OBJECT(i))))

/* Modification of a byte array */
LL_EXTERNAL_FUNCTION (VSLONG	lli_bset,	(LL_vector s,
						 VSLONG i,
						 VSLONG c)) ;
#define LL_BSET(s,i,c)		(lli_bset(LL_THE_VECTOR(s),LL_FIX2INT(LL_THE_FIX(i)),LL_FIX2INT(LL_THE_FIX(c))))
#define LLO_BSET(s,i,c)		((LL_object)LL_INT2FIX(LL_BSET((LL_vector)LL_THE_OBJECT(s),(LL_fix)LL_THE_OBJECT(i),(LL_fix)LL_THE_OBJECT(c))))



LL_EXTERNAL_FUNCTION (LL_char	lli_sset,	(LL_string s,
						 VSLONG i,
						 VSLONG c)) ;
/* #define LL_SSET(s,i,c)		(lli_sset(LL_THE_STRING(s),LL_FIX2INT(LL_THE_FIX(i)),(LL_char)LL_FIX2INT(LL_THE_FIX(c)))) */
#define LL_SSET(s,i,c)		(lli_sset(LL_THE_STRING(s),LL_FIX2INT(LL_THE_FIX(i)),LL_FIX2INT(LLO_CHAR2FIX(c))))
#define LLO_SSET(s,i,c)		(LLO_FIX2CHAR(LL_INT2FIX(LL_SSET((LL_string)LL_THE_OBJECT(s),(LL_fix)LL_THE_OBJECT(i),(LL_fix)LL_THE_OBJECT(c)))))

LL_EXTERNAL_FUNCTION (LL_string	ll_make_string_copying_c,	(char *c_string));
LL_EXTERNAL_FUNCTION (LL_string	ll_make_substring_copying_c,	(char *c_string, 
								 VSLONG length));
LL_EXTERNAL_FUNCTION (LL_string	lli_make_string,	(VSLONG length,
							 VSLONG init_char));
LL_EXTERNAL_FUNCTION (LL_object	ll_stringp,	(LL_object object));
LL_EXTERNAL_FUNCTION (LL_object	ll_eqstring,	(LL_string s1,
						 LL_string s2));
LL_EXTERNAL_FUNCTION (void	ll_init_string,	(void)) ;

#define LL_MAX_STRING_LENGTH 		32767

#define LLO_MAX_STRING_LENGTH() 		LL_INT2OBJ(LL_MAX_STRING_LENGTH)


#define LLO_MAX_CHARACTER_CODE() 		LL_INT2OBJ(255)

#define LLI_STRING_COPY(d,ds,dl,s,ss,m)	((LL_object)(lli_string_copy(LL_THE_STRING(d),LL_THE_INT(ds),LL_THE_INT(dl),LL_THE_STRING(s),LL_THE_INT(ss),LL_THE_INT(m))))

#define LL_STRING_COPY(d,ds,dl,s,ss,m)	((LL_object)LL_THE_STRING(LLI_STRING_COPY(LL_THE_STRING(d),LL_FIX2INT(LL_THE_FIX(ds)),LL_FIX2INT(LL_THE_FIX(dl)),LL_THE_STRING(s),LL_FIX2INT(LL_THE_FIX(ss)),LL_FIX2INT(LL_THE_FIX(m)))))

#define LLO_STRING_COPY(d,ds,dl,s,ss,m)	((LL_object)LL_THE_STRING(LL_STRING_COPY((LL_string)LL_THE_OBJECT(d),(LL_fix)LL_THE_OBJECT(ds),\
(LL_fix)LL_THE_OBJECT(dl),(LL_string)LL_THE_OBJECT(s),(LL_fix)LL_THE_OBJECT(ss),(LL_fix)LL_THE_OBJECT(m))))


#define LLI_STRING_CATENATE(result,s1,l1,s2,l2)	((LL_object)(lli_string_catenate(LL_THE_STRING(result),LL_THE_STRING(s1),LL_THE_INT(l1),LL_THE_STRING(s2),LL_THE_INT(l2))))

#define LL_STRING_CATENATE(result,s1,l1,s2,l2)	((LL_object)LL_THE_STRING(LLI_STRING_CATENATE(LL_THE_STRING(result),LL_THE_STRING(s1),LL_FIX2INT(LL_THE_FIX(l1)),LL_THE_STRING(s2),LL_FIX2INT(LL_THE_FIX(l2)))))

#define LLO_STRING_CATENATE(result,s1,l1,s2,l2)	((LL_object)LL_THE_STRING(LL_STRING_CATENATE((LL_string)LL_THE_OBJECT(result),(LL_string)LL_THE_OBJECT(s1),(LL_fix)LL_THE_OBJECT(l1),(LL_string)LL_THE_OBJECT(s2),(LL_fix)LL_THE_OBJECT(l2))))





#define LLI_PRED_CHARACTERP(c)		(((int)LL_THE_OBJECT(c) >= 0) && ((int)LL_THE_OBJECT(c) < 256))

#define LL_PRED_CHARACTERP(c)		LLI_PRED_CHARACTERP(LL_FIX2INT(LL_THE_FIX(c)))
#define LLO_PRED_CHARACTERP(c)		LL_PRED_CHARACTERP((LL_fix)LL_THE_OBJECT(c))


/* fast string creation, still zeroing the last pointer to allow for fast string comparison and hashing */
#define LLI_MAKE_RAW_STRING(length, result)	\
{ result = (unsigned char *)lli_make_array	\
     ((length+1)<<LOG_BYTES_PER_CHARACTER,	\
      LL_STRING_CLAN);	\
 ((void **)result)				\
     [length>>(LOG_BYTES_PER_VOIDSTAR-LOG_BYTES_PER_CHARACTER)]=0;}

LL_EXTERNAL_FUNCTION (int lli_eqstring, (char *s1, char *s2));
LL_EXTERNAL_FUNCTION (void* lli_make_raw_string, (long i));

#if defined(ILT_HAS_MEMMOVE)
#define ILT_BCOPY(src,dst,length)	(void)memmove(dst,src,length)
#else
#define ILT_BCOPY(src,dst,length)	(void)bcopy(src,dst,length)
#endif
/*****************************************************************************

 llfunction.h: functional objects

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llfunction.h,v 3.11 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

/* The definition of  struct { ... } * LL_function;  is now in llmm.h. */

#define LL_FUNCTION_CODE(f)			((LL_THE_FUNCTION(f))->code)
#define LL_FUNCTION_USER_FIELD(f,i)		((LL_THE_FUNCTION(f))->user_field[LL_FIX2INT(i)])
#define LL_FUNCTION_SYSTEM_FIELD(f,i)		((LL_THE_FUNCTION(f))->system_field[LL_FIX2INT(i)])
#define LL_SET_FUNCTION_CODE(f,c)		((void)((LL_THE_FUNCTION(f))->code=(c)))
#define LL_SET_FUNCTION_USER_FIELD(f,i,v)	((void)((LL_THE_FUNCTION(f))->user_field[LL_FIX2INT(i)]=(v)))
#define LL_SET_FUNCTION_SYSTEM_FIELD(f,i,v)	((void)((LL_THE_FUNCTION(f))->system_field[LL_FIX2INT(i)]=(v)))
#define LL_PRED_FUNCTIONP(o)			(LL_FUNCTION_CLAN==ll_object_clan(LL_THE_OBJECT(o)))
#define LL_MAKE_FUNCTION(code,nsf,nuf)		(lli_make_function(code,LL_FIX2INT(nsf),LL_FIX2INT(nuf)))
#define LL_LEN_FUNCTION_USER_FIELDS(f)		(LL_VOS2FIX(llv_len_function_user_fields(LL_THE_FUNCTION(f))))
#define LL_LEN_FUNCTION_SYSTEM_FIELDS(f)	(LL_VOS2FIX(llv_len_function_system_fields(LL_THE_FUNCTION(f))))

#define LLV_FUNCTION_USER_FIELD(f,i)		((LL_THE_FUNCTION(f))->user_field[LL_VOS2INT(i)])
#define LLV_FUNCTION_SYSTEM_FIELD(f,i)		((LL_THE_FUNCTION(f))->system_field[LL_VOS2INT(i)])
#define LLV_SET_FUNCTION_USER_FIELD(f,i,v)	((void)((LL_THE_FUNCTION(f))->user_field[LL_VOS2INT(i)]=(v)))
#define LLV_SET_FUNCTION_SYSTEM_FIELD(f,i,v)	((void)((LL_THE_FUNCTION(f))->system_field[LL_VOS2INT(i)]=(v)))

#define LLI_FUNCTION_USER_FIELD(f,i)		((LL_THE_FUNCTION(f))->user_field[LL_THE_INT(i)])
#define LLI_FUNCTION_SYSTEM_FIELD(f,i)		((LL_THE_FUNCTION(f))->system_field[LL_THE_INT(i)])
#define LLI_SET_FUNCTION_USER_FIELD(f,i,v)	((void)((LL_THE_FUNCTION(f))->user_field[LL_THE_INT(i)]=(v)))
#define LLI_SET_FUNCTION_SYSTEM_FIELD(f,i,v)	((void)((LL_THE_FUNCTION(f))->system_field[LL_THE_INT(i)]=(v)))
#define LLI_LEN_FUNCTION_USER_FIELDS(f)		(LL_VOS2INT(llv_len_function_user_fields(LL_THE_FUNCTION(f))))
#define LLI_LEN_FUNCTION_SYSTEM_FIELDS(f)	(LL_VOS2INT(llv_len_function_system_fields(LL_THE_FUNCTION(f))))

#define LLO_FUNCTION_CODE(f)			((LL_object)LL_FUNCTION_CODE((LL_function)(f)))
#define LLO_FUNCTION_USER_FIELD(f,i)		((LL_object)LL_FUNCTION_USER_FIELD((LL_function)(f),(LL_fix)(i)))
#define LLO_FUNCTION_SYSTEM_FIELD(f,i)		((LL_object)LL_FUNCTION_SYSTEM_FIELD((LL_function)(f),(LL_fix)(i)))
#define LLO_SET_FUNCTION_CODE(f,c)		(LL_SET_FUNCTION_CODE((LL_function)(f),(LL_code)(c)),ll_nil)
#define LLO_SET_FUNCTION_USER_FIELD(f,i,v)	(LL_SET_FUNCTION_USER_FIELD((LL_function)(f),(LL_fix)(i),(LL_object)(v)),ll_nil)
#define LLO_SET_FUNCTION_SYSTEM_FIELD(f,i,v)	(LL_SET_FUNCTION_SYSTEM_FIELD((LL_function)(f),(LL_fix)(i),(LL_object)(v)),ll_nil)
#define LLO_PRED_FUNCTIONP(o)			(LL_FUNCTION_CLAN==ll_object_clan(LL_THE_OBJECT(o)))
#define LLO_MAKE_FUNCTION(code,nsf,nuf)		((LL_object)LL_MAKE_FUNCTION((LL_code)(code),(LL_fix)(nsf),(LL_fix)(nuf)))
#define LLO_LEN_FUNCTION_USER_FIELDS(f)		((LL_object)LL_LEN_FUNCTION_USER_FIELDS((LL_function)LL_THE_OBJECT(f)))
#define LLO_LEN_FUNCTION_SYSTEM_FIELDS(f)	((LL_object)LL_LEN_FUNCTION_SYSTEM_FIELDS((LL_function)LL_THE_OBJECT(f)))
#define LLO_UNDEFINED_FUNCTION()		((LL_object)ll_undefined_function)
#define LLO_SET_UNDEFINED_FUNCTION(f)		(ll_set_undefined_function((LL_function)f),(LL_object)ll_nil)

#define LL_FBOUNDP(s)	(LL_ARRAY_CLAN((LL_symbol)s->fval) != LL_UNDEF_FN_CLAN)

LL_EXTERNAL_FUNCTION (LL_function	lli_make_function,	(LL_code code,
								 VSLONG nsf,
								 VSLONG nuf)) ;

LL_EXTERNAL_FUNCTION (LL_function	lli_make_initialized_function,	(LL_code code,
								 VSLONG nsf,
								 VSLONG nuf)) ;

LL_EXTERNAL_FUNCTION (LL_function	lli_make_initialized_function_aux,	(LL_code code,
								 VSLONG nsf,
								 VSLONG nuf)) ;

LL_EXTERNAL_FUNCTION (LL_vos	llv_len_function_user_fields,	(LL_function f));

LL_EXTERNAL_FUNCTION (LL_vos	llv_len_function_system_fields,	(LL_function f));

LL_EXTERNAL_FUNCTION (void	ll_init_function,	(void)) ;

LL_COMMONRT_EXTERNAL (LL_function	ll_undefined_function) ;

/* Hash Tables */

/*
 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1993-1996 by ILOG
 ----------------------------------------------------------------------
 */

#include <iltsystem.h>

/* entry type for fixed arity code (mind the padding!) */
typedef struct { void *key0; 
		 void *val; } ht1e;
typedef struct { void *key0; 
		 void *key1; 
		 void *val;
		 void *pad1; } ht2e;

/* if hte.key[0]==ILT_EMPTY_HTE, the entry hte is empty */
/* We don't want 0, as it means (), which is a useful key. We don't
   wan't -1 or 3, it is a fix. We don't want 1 or 2, they may become some
   valid immediate (char?) someday. 4 is nice, because it is not a legal
   immediate, nor row */
#define ILT_EMPTY_HTE ((void*)4)
#define ilt_empty_ht_entry()	ILT_EMPTY_HTE

#define LL_LOG_BYTES_PER_HT1E (LOG_BYTES_PER_LONG+1)
#define LL_LOG_BYTES_PER_HT2E (LOG_BYTES_PER_LONG+2)
#define LL_LOG_BYTES_PER_HT3E (LOG_BYTES_PER_LONG+2)

typedef struct { long shiftr;
		 long type; } keydesc;

/* can't have an array of 0 elts */
#define ILT_DUMARITY 1

#define NRFU 0

typedef struct {
  /* 0: address of trailing hte, which is allways empty, after extra */
  void **null_hte; 
  /* 1: log of main nb of hte (mapped by hashcode) */
  long log_main_entries; 
  /* 2: nb of overflow hte (no hashcode), after main */
  long extra_entries; 
  /* 3: when value_p, call when fail */
  LL_function not_found; 
  /* 4: size of key tuple */
  long arity; 
  /* 5: closest power of 2 of (arity+value_p)*sizeof(void*) */
  long bytes_per_hte; 
  /* most intensively accessed section (get) */
  /* 6: =0 for set, =1 for table */
  long valuep; 
  /* 7: first hte */
  void **hte; 
  /* 8: mask for byte offset (hascode computation) */
  long mask; 
  /* 9: callback when hash-table is increased */
  LL_function after_growth;
  /* 10: value are already cyphered */
  long cyphered;
  /* 11: minimum density * 100 */
  long min_density;
  /* 12: maximum cluster, unless below minimum density */
  long max_cluster;
  /* 13: number of busy entries */
  long active_entries;
  /* 14: number of entries, busy or not, is 1<<log_main_entries
     + extra_entries */
  long potential_entries;
  /* 15: number of entries required before considering extending the table */
  long min_active_entries_for_expand;
  /* for each key item, type (ptr, fix, row) 
     and size of shiftr (hashcode computation) */
  keydesc kd[ILT_DUMARITY]; } hthdr;

#define ilt_hash_arity(h)	LL_INT2FIX(((hthdr*)h)->arity)
#define ilt_hash_not_found(h)	(((hthdr*)h)->not_found)
#define ilt_hash_not_found_set(h,f)	((((hthdr*)h)->not_found)=f)

#define sizeof_hthdr(arity) (sizeof(hthdr)+(arity-ILT_DUMARITY)*sizeof(keydesc))

/* Find entry with key (k0) in hash-table-eq ht, and store the value
   in result_var. If not found, stores defolt in result_value.  CAVEAT:
   in one function body, the identifier result_var must be different upon
   each call to ilt_get_hash_table_eq_1 -- otherwise an obscure
   multiple-definition error will occur. */

#define ilt_get_hash_table_eq_1(ht, k0, result_var)			\
{ result_var = ilt_get_hash_table_eq_1_fn(ht, k0); }

#define ilt_get_hash_table_eq_2(ht, k0, k1, result_var)			\
{ result_var = ilt_get_hash_table_eq_2_fn(ht, k0, k1); }

/* two-third full linear hash table has an average of 5 probes, good enough */
/* we divide by two to allow resizing */
#define ILT_DEFAULT_MIN_DENSITY 33
/* to round up to next quantum, max_cluster is better be 4*k+2 */
#define ILT_DEFAULT_MAX_CLUSTER 3

#define ilt_make_row_hash_table(ar,nf)	ilt_make_row_hash(ar,nf,1,ILT_DEFAULT_MIN_DENSITY,ILT_DEFAULT_MAX_CLUSTER)
#define ilt_make_row_hash_set(ar)	ilt_make_row_hash(ar,0,0,ILT_DEFAULT_MIN_DENSITY,ILT_DEFAULT_MAX_CLUSTER)

LL_EXTERNAL_FUNCTION (void*	ilt_hash_table_statistics	,(LL_function nf, long t0)) ;

LL_EXTERNAL_FUNCTION (void*	ilt_make_hash_table_eq	,(LL_function nf, long t0)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_make_row_hash	,(void *arity, LL_function nf, long valuep, long min_density, long max_density)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_put_hash_table_eq	,(void *ht, ...)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_put_hash_table_eq_1_fn ,(void *ht, void *k0, void *val)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_put_hash_table_eq_2_fn ,(void *ht, void *k0, void *k1, void *k2)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_get_hash_table_eq	,(void *ht, ...)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_get_hash_table_eq_1_fn ,(void *ht, void *k0)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_get_hash_table_eq_2_fn ,(void *ht, void *k0, void *k1)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_rem_hash_table_eq	,(void *ht, ...)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_clr_hash_table_eq	,(void *ht)) ;

LL_EXTERNAL_FUNCTION (void*	ilt_clear_hash_table	,(void *ht)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_clear_hash_set	,(void *ht)) ;

LL_EXTERNAL_FUNCTION (void*	ilt_ht_fn	,(void* hash)) ;
LL_EXTERNAL_FUNCTION (void*	ilt_hash_table_key_type	,(void* hash)) ;

#define ilt_ht1_clan()	LL_HT1_CLAN
#define ilt_hs1_clan()	LL_HS1_CLAN

/* iteration over hash-table and hash-set */

#define NEXT_HTE(hte) hte = (void**)(((char*)hte)+bytes_per_hte)
#define PREV_HTE(hte) hte = (void**)(((char*)hte)-bytes_per_hte)

#define ILT_MAKE_HASH_ITERATOR_INTO(h, result5)				\
{ hthdr *lh = h;							\
  long bytes_per_hte = lh->bytes_per_hte;				\
  void **current_hte = lh->null_hte;					\
  void **first_hte = lh->null_hte;					\
  PREV_HTE(current_hte);						\
  while (current_hte[0] == ILT_EMPTY_HTE)				\
    PREV_HTE(current_hte);						\
  result5 = current_hte; }
  
#define ILT_PRED_HASH_ITERATOR_EMPTY(h, hit)				\
  (((long)(((hthdr*)(h))->hte)) > (long)hit)

#define ILT_POP_HASH_ITERATOR_INTO(h, hit)				\
{ hthdr *lh = h;							\
  long bytes_per_hte = lh->bytes_per_hte;				\
  void **current_hte = hit;						\
  void **first_hte = lh->null_hte;					\
  PREV_HTE(current_hte);						\
  while (current_hte[0] == ILT_EMPTY_HTE)				\
    PREV_HTE(current_hte);						\
  hit = current_hte; }
/* Canon Tables */

/*
 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1994-1996 by ILOG
 ----------------------------------------------------------------------
 */

#define LL_STRONGCANONTABLE_CLAN LL_VECTOR_CLAN
#define LL_WEAKCANONTABLE_CLAN LL_VECTOR_CLAN
#define LL_CVECTOR_CLAN LL_VECTOR_CLAN

typedef struct {
  /* 0: cvector */
  unsigned long **cvector;
  /* 1: number of bytes to ignore, usually 0 */
  long unsignificant_bytes;
 } ILT_canon_table_struct;

typedef ILT_canon_table_struct *ILT_canon_table;

#define LL_STRONGFTABLE_CLAN LL_VECTOR_CLAN
#define LL_WEAKFTABLE_CLAN LL_CONS_CLAN
#define LL_FVECTOR_CLAN LL_VECTOR_CLAN

typedef struct {
  /* 0: cvector */
  unsigned long **cvector;
  /* 1: first key offset */
  long first_key_offset;
  /* 2: second key offset */
  /* 3: etc... */
 } ILT_f_table_struct;

typedef ILT_f_table_struct *ILT_f_table;

LL_EXTERNAL_FUNCTION (ILT_canon_table_struct*	ilt_make_canon_table,	(long skip, long weakp));
LL_EXTERNAL_FUNCTION (void*	ilt_canonize,	(ILT_canon_table_struct* ct, unsigned long * searched_key, long freep));
LL_EXTERNAL_FUNCTION (void*	ilt_ctrem,	(ILT_canon_table_struct* ct, unsigned long * searched_key));

#define LLO_MAKE_CANON_TABLE(skip,weakp) \
	((LL_object)ilt_make_canon_table((long)(skip),(long)(weakp)))
#define LLO_CANONIZE(ct,sk,freep) \
	((LL_object)ilt_canonize((ILT_canon_table_struct*)(ct),(unsigned long *)(sk),(long)(freep)))
#define LLO_CTREM(ct,sk) \
	((LL_object)ilt_ctrem((ILT_canon_table_struct*)(ct),(unsigned long *)(sk)))

/*****************************************************************************

 llsymbol.h: symbol management

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llsymbol.h,v 3.27 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

/* The definitions of
     struct LL_symbolS { ... } * LL_symbol;
   and
     struct LL_keywordS { ... } * LL_keyword;
   are now in llmm.h.
 */

#define LLI_SYMBOL_SKIP LLI_PKGC_INDEX
#define LLI_KEYWORD_SKIP LLI_KEYW_SYMB_INDEX
#define LLI_CVAL_INDEX (((VSLONG)(&(((LL_symbol)0)->cval)))>>LOG_BYTES_PER_VOIDSTAR)
#define LLI_FVAL_INDEX (((VSLONG)(&(((LL_symbol)0)->fval)))>>LOG_BYTES_PER_VOIDSTAR)
#define LLI_PKGC_INDEX (((VSLONG)(&(((LL_symbol)0)->pkgc)))>>LOG_BYTES_PER_VOIDSTAR)
#define LLI_KEYW_SYMB_INDEX (((VSLONG)(&(((LL_keyword)0)->symbol)))>>LOG_BYTES_PER_VOIDSTAR)
#define LLO_CVAL_INDEX ((LL_object)LL_INT2FIX(LLI_CVAL_INDEX))
#define LLO_FVAL_INDEX ((LL_object)LL_INT2FIX(LLI_FVAL_INDEX))
#define LLO_PKGC_INDEX ((LL_object)LL_INT2FIX(LLI_PKGC_INDEX))

#define LLO_FVAL_INDEX_FN() LLO_FVAL_INDEX
#define LLO_CVAL_INDEX_FN() LLO_CVAL_INDEX

#define LLO_PRED_SANE_SYMBOLP(o)   (LL_SYMBOL_CLAN==ll_object_clan(LL_THE_OBJECT(o)))

#define LLO_PRED_KEYWORDP(o) (LL_KEYWORD_CLAN==ll_object_clan(LL_THE_OBJECT(o)))

LL_EXTERNAL_FUNCTION (void *ll_symbol,	(void *package, void *pname)) ;
LL_EXTERNAL_FUNCTION (void *ilt_keyword,(void *package, void *pname)) ;

LL_EXTERNAL_FUNCTION (void	ll_init_symbol,	(void)) ;

LL_EXTERNAL_FUNCTION (LL_symbol	ilt_string2symbol,(char *pname)) ;

LL_EXTERNAL_FUNCTION (void      ilt_retrieve_symbol, (void **symbol_storage, char *symbol_name)) ;

#define LLO_CVAL(s)	((LL_object)(((LL_symbol)LL_THE_OBJECT(s))->cval))
#define LLO_FVAL(s)	((LL_object)(((LL_symbol)LL_THE_OBJECT(s))->fval))
#define LLO_PKGC(s)	((LL_object)(((LL_symbol)LL_THE_OBJECT(s))->pkgc))
#define LLO_PNAME(s)	ilt_id_name(s)

#define LLO_SET_CVAL(s,v)	(LLO_VSET(s,LLO_CVAL_INDEX,v))
#define LLO_SET_FVAL(s,v)	(LLO_VSET(s,LLO_FVAL_INDEX,v))
#define LLO_SET_PKGC(s,v)	(LLO_VSET(s,LLO_PKGC_INDEX,v))

/* ----------------------- */

LL_EXTERNAL_FUNCTION (void* ilt_id_package, (void* id));
LL_EXTERNAL_FUNCTION (void* ilt_symbol, (void* package, void* name));

/* new symbols! */

#define ILT_ID_PKG(id) ((LL_object)ilt_id_package((void*)(id)))
#define ILT_SYMBOL_NAME_PTR(s)	(((LL_symbol)(s))->name)
#define ILT_I_SYMBOL_NAME_SLEN(s) (LLI_SLEN(s)+1-((long)ILT_SYMBOL_NAME_PTR(0)))
#define ILT_SYMBOL_NAME_SLEN(s) LL_INT2FIX(ILT_I_SYMBOL_NAME_SLEN(s))
#define ILT_ID_NAM(id)  ((LL_object)ilt_id_name(id))
#define ILT_SYMBOL(p,n) ((LL_object)ilt_symbol((void*)(p),(void*)(n)))

/*****************************************************************************

 lltypecheck.h: optional static type checking 

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/lltypecheck.h,v 3.2 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

/* setting CHECKTYPES to a non-null value when compiling any .c file
   will make cc complain whenever the arguments passed to a macro are of
   the wrong static type. The drawback is that the resulting code is
   significantly slower than it should be. Therefore,  CHECKTYPE should be
   used only when debugging. */

#ifndef CHECKTYPES
#define CHECKTYPES 0
#endif

#if CHECKTYPES

LL_EXTERNAL_STATIC (int		lltype_int_v);
LL_EXTERNAL_STATIC (LL_fos	lltype_fos_v);
LL_EXTERNAL_STATIC (LL_vos	lltype_vos_v);
LL_EXTERNAL_STATIC (LL_sos	lltype_sos_v);
LL_EXTERNAL_STATIC (LL_bos	lltype_bos_v);
LL_EXTERNAL_STATIC (LL_object	lltype_object_v);
LL_EXTERNAL_STATIC (LL_fix	lltype_fix_v);
LL_EXTERNAL_STATIC (LL_char	lltype_char_v);
LL_EXTERNAL_STATIC (LL_function	lltype_function_v);
LL_EXTERNAL_STATIC (LL_symbol	lltype_symbol_v);
LL_EXTERNAL_STATIC (LL_string	lltype_string_v);
LL_EXTERNAL_STATIC (LL_vector	lltype_vector_v);
LL_EXTERNAL_STATIC (LL_cons	lltype_cons_v);
LL_EXTERNAL_STATIC (LL_float	lltype_float_v);

LL_EXTERNAL_FUNCTION (int	lltype_int,	(int arg));
LL_EXTERNAL_FUNCTION (LL_fos	lltype_fos,	(LL_fos arg));
LL_EXTERNAL_FUNCTION (LL_vos	lltype_vos,	(LL_vos arg));
LL_EXTERNAL_FUNCTION (LL_sos	lltype_sos,	(LL_sos arg));
LL_EXTERNAL_FUNCTION (LL_bos	lltype_bos,	(LL_bos arg));
LL_EXTERNAL_FUNCTION (LL_object	lltype_object,	(LL_object arg));
LL_EXTERNAL_FUNCTION (LL_fix	lltype_fix,	(LL_fix arg));
LL_EXTERNAL_FUNCTION (LL_char	lltype_char,	(LL_char arg));
LL_EXTERNAL_FUNCTION (LL_function	lltype_function,	(LL_function arg));
LL_EXTERNAL_FUNCTION (LL_symbol	lltype_symbol,	(LL_symbol arg));
LL_EXTERNAL_FUNCTION (LL_string	lltype_string,	(LL_string arg));
LL_EXTERNAL_FUNCTION (LL_vector	lltype_vector,	(LL_vector arg));
LL_EXTERNAL_FUNCTION (LL_cons	lltype_cons,	(LL_cons arg));
LL_EXTERNAL_FUNCTION (LL_float	lltype_float,	(LL_float arg));

#define LL_THE_INT(i)		(lltype_int(lltype_int_v=(i)))
#define LL_THE_UNSIGNED(i)	(lltype_unsigned(lltype_unsigned_v=(i)))
#define LL_THE_FOS(v)		(lltype_fos(lltype_fos_v=(v)))
#define LL_THE_VOS(v)		(lltype_vos(lltype_vos_v=(v)))
#define LL_THE_SOS(v)		(lltype_sos(lltype_sos_v=(v)))
#define LL_THE_BOS(v)		(lltype_bos(lltype_bos_v=(v)))
#define LL_THE_OBJECT(o)	(lltype_object(lltype_object_v=(o)))
#define LL_THE_FIX(f)		(lltype_fix(lltype_fix_v=(f)))
#define LL_THE_CHAR(c)		(lltype_char(lltype_char_v=(c)))
#define LL_THE_FUNCTION(f)	(lltype_function(lltype_function_v=(f)))
#define LL_THE_SYMBOL(s)	(lltype_symbol(lltype_symbol_v=(s)))
#define LL_THE_STRING(s)	(lltype_string(lltype_string_v=(s)))
#define LL_THE_VECTOR(v)	(lltype_vector(lltype_vector_v=(v)))
#define LL_THE_CONS(c)		(lltype_cons(lltype_cons_v=(c)))
#define LL_THE_FLOAT(c)		(lltype_float(lltype_float_v=(c)))

#else /* CHECKTYPES */

/* In attempting to prevent yacc overflows (?), this correct code
#define LL_THE_INT(i)		(i)
#define LL_THE_UNSIGNED(i)	(i)
#define LL_THE_FOS(v)		(v)
#define LL_THE_VOS(v)		(v)
#define LL_THE_SOS(v)		(v)
#define LL_THE_BOS(v)		(v)
#define LL_THE_OBJECT(o)	(o)
#define LL_THE_FIX(f)		(f)
#define LL_THE_CHAR(c)		(c)
#define LL_THE_FUNCTION(f)	(f)
#define LL_THE_SYMBOL(s)	(s)
#define LL_THE_STRING(s)	(s)
#define LL_THE_VECTOR(v)	(v)
#define LL_THE_CONS(c)		(c)
#define LL_THE_FLOAT(c)		(c)
 is replaced with the shorter, yet unsafe following code */

/* warning: expansion results in a non-parened expresion! */

#define LL_THE_INT(i)		i
#define LL_THE_UNSIGNED(i)	i
#define LL_THE_FOS(v)		v
#define LL_THE_VOS(v)		v
#define LL_THE_SOS(v)		v
#define LL_THE_BOS(v)		v
#define LL_THE_OBJECT(o)	o
#define LL_THE_FIX(f)		f
#define LL_THE_CHAR(c)		c
#define LL_THE_FUNCTION(f)	f
#define LL_THE_SYMBOL(s)	s
#define LL_THE_STRING(s)	s
#define LL_THE_VECTOR(v)	v
#define LL_THE_CONS(c)		c
#define LL_THE_FLOAT(c)		c

#endif /* CHECKTYPES */
/*****************************************************************************

 llmain.h: modular interface for Talk system's interface with basic
 Unix services.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llmain.h,v 3.48 1996/03/27 14:18:15 v16admin Exp $
 ----------------------------------------------------------------------
 ***************************************************************************/



LL_EXTERNAL_FUNCTION (LL_object ll_an_error_occured,	()) ;
LL_EXTERNAL_FUNCTION (LL_object ll_a_warning_occured,	()) ;
LL_EXTERNAL_FUNCTION (void IltFinish,	()) ;
LL_EXTERNAL_FUNCTION (VSLONG ll_with_lisp_running,	(VSLONG (*call_me) ())) ;
LL_COMMONRT_EXTERNAL (LL_symbol llsym_errudf);

LL_EXTERNAL_FUNCTION (VSLONG ll_application_main,
		      (VSLONG use_image,
		       VSLONG image_length,
		       Image *image,
		       void (*appli_init)(),
		       void (*appli_run)(),
		       VSLONG argc,
		       char **argv,
		       char **envp,
		       VSLONG liblocc,
		       LL_library_locator *liblocv,
		       VSLONG pre_static_heap_buffer_size, 
		       VSLONG post_static_heap_buffer_size));

LL_EXTERNAL_FUNCTION (void ll_out, (VSLONG));
LL_EXTERNAL_FUNCTION (int ilt_abort, (char *));



/* The mark that allows us to find the image space in the executable file */
/* \\ The mark MUST NOT contain a repetition of any of its prefixes */
/* \\ because of the (efficient) searching algorithm we use */
#define BYTES_PER_MARK 28
#define VOIDSTARS_PER_MARK (((BYTES_PER_MARK-1) >> LOG_BYTES_PER_VOIDSTAR)+1)
#define IMAGE_MARK "Here begins the image space"

typedef struct {
	/* save the rootset address vector */
	LL_object	**first_root;
	/* save the rootset size vector */
	VSLONG		 *number_of_roots;
	/* save the rootset type vector */
	VSLONG		 *root_type;
	/* save the rootset vector length */
	VSLONG		  next_root_ticket;
	/* save the  rootset value vector, to restore them */
	LL_vector	  root_value; }	Rootset;

typedef void (*ll_fun_address)();

#define LL_BYTES_PER_SHADOW_IMAGE 4
#define LL_MAX_SEGMENT_LOCATION 1000

/* begin and end are the values when core was saved. growth is the
   shift observed when restoring the image */

/* elaboration function type, also called to fetch 
   library first and last addresses */
typedef LL_object (*LL_library_locator)();

#define LL_SEG_NAME_LEN 32

typedef struct
{ char *begin;
  char *end;
  char *aa; /* a sample likely to be at the begining */
  char *zz; /* a sample likely to be at the end */
  char *stretched_aa;
  char *stretched_zz;
  VSLONG growth;
  VSLONG type; /* ILT_PUB or ILT_PRIV | ILT_CODE or ILT_DATA or ILT_BSS */
  char name[LL_SEG_NAME_LEN]; } LL_segment_location;

#if defined(ILT_OS_UNIX_AIX)
#define PRE_STATIC_HEAP_BUFFER_SIZE 0x100000
#define POST_STATIC_HEAP_BUFFER_SIZE 0x100000
#else
#define PRE_STATIC_HEAP_BUFFER_SIZE sizeof(long)
#define POST_STATIC_HEAP_BUFFER_SIZE sizeof(long)
#endif

/* flags for init_status */
#define LL_IS_ERROR	(1<<0)
#define LL_IS_WARN	(1<<1)

typedef struct Simage {
	/* Mark, used to fetch image in the executable file */
	void		 *mark[VOIDSTARS_PER_MARK];
	/* image indicator (1). Used to tell if execore was saved */
	VSLONG		 present;
	/* tell if image building triggered a Lisp error, a warning... */
	VSLONG		 init_status;
	/* save the address of the image, it must be the same when restored */
	struct Simage	*location;
	/* save many segment descriptors, to be able to detect their 
	   shifting, and be able to reloacte pointers (both moving
	   roots and moving function code */
	LL_segment_location segment_location[LL_MAX_SEGMENT_LOCATION];
	/* pointer to the list of non-simple function clans,
	   to know which row to relocate the first field upon image restore */
	LL_cons		non_simple_function_clans;
	/* rootset, to allow for its value's retoration */
	Rootset		rootset;
	/* the heap surrounded with its shift buffer -- just  a few megabytes! */
	char		  static_heap[LL_BYTES_PER_SHADOW_IMAGE];
} Image;

#define LL_BYTES_PER_IMAGE_HEADER ((VSLONG)(((Image*)0)[0].static_heap))

/* to know if some operation are legal, read that flag */

LL_EXTERNAL_STATIC_INIT (VSLONG ll_image_to_save, 1);
#define LL_PRED_IMAGE_TO_SAVE()	(ll_image_to_save)

LL_EXTERNAL_STATIC_INIT (long current_binary_mtime, 0);

LL_EXTERNAL_FUNCTION (void ilt_proclaim_elaborating_library_pointer, (void *pointer,
								      int type));
LL_EXTERNAL_FUNCTION (void ilt_print_typed_pointer_error_message, (void));
LL_EXTERNAL_FUNCTION (int ilt_typed_pointer_status, (void));
#define ILT_TP_UNMAPPED 0
#define ILT_TP_MAPPED 1
#define ILT_TP_ERROR 2
LL_EXTERNAL_FUNCTION (char *ilt_reloc_pointer, (char *ptr, int type));
LL_EXTERNAL_FUNCTION (void  ilt_assert_started, (void));
/*****************************************************************************

 lowunix.h: interface for Talk's interface with basic Unix services. 

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/lllowunix.h,v 3.37 1996/05/31 09:58:37 v16admin Exp $
 ----------------------------------------------------------------------
 ***************************************************************************/

#include <sys/stat.h>


#define LLO_LL_INTON()	((LL_object) ll_inton())
#define LLO_GETGLOBA(string)	((LL_object) getgloba(string))

LL_EXTERNAL_FUNCTION (char *ilt_sys_getenv, (void));
LL_EXTERNAL_FUNCTION (long ilt_runtime, (void));
LL_EXTERNAL_FUNCTION (long ilt_clock_ticks, (void));

LL_EXTERNAL_FUNCTION (void oupps, (VSLONG n));

LL_EXTERNAL_FUNCTION (void init_signal,(void)) ;

LL_EXTERNAL_FUNCTION (void int_ign, (void));
LL_EXTERNAL_FUNCTION (void int_std, (void));
#if 0 /* avoid compilation errors for `iltconfige' and `iltitmane' */
LL_EXTERNAL_FUNCTION (void ll_inton, (void));
#endif
LL_EXTERNAL_FUNCTION (VSLONG ll_intoff, (void));

LL_EXTERNAL_FUNCTION (void ilt_set_system_error, (void)) ;
LL_EXTERNAL_FUNCTION (void ilt_init_system_error, (void)) ;

#define LLO_NBSYST()	((LL_object)LL_INT2FIX(NBSYST))

#define LLO_GETGLOBAL_THING(name)	LL_GETGLOBAL_THING((LL_string)LL_THE_OBJECT(name))
#define LL_GETGLOBAL_THING(name)	getgloba(LL_THE_STRING(name))

#define LLO_OUT(n)	(ll_out(LL_FIX2INT((LL_fix)(n))), (LL_object)ll_nil)


/* Posix constants made into <int>-ified macros. */

#include <sys/stat.h>
#if defined(ILT_OS_WIN32)
#include <io.h>
#else
#include <unistd.h>
#endif

#if defined(ILT_OS_WIN32)

/* Windows, FAT model (RW for all). We ignore NTFS marvels, FAT is
   non-unix-ish enough, having two models would drive the user
   nuts. */

#define ILT_S_IRUSR _S_IREAD
#define ILT_S_IWUSR _S_IWRITE
#define ILT_S_IXUSR _S_IREAD
#define ILT_S_IRGRP _S_IREAD
#define ILT_S_IWGRP _S_IWRITE
#define ILT_S_IXGRP _S_IREAD
#define ILT_S_IROTH _S_IREAD
#define ILT_S_IWOTH _S_IWRITE
#define ILT_S_IXOTH _S_IREAD

#define ILT_I_R_OK _S_IREAD
#define ILT_I_W_OK _S_IWRITE
#define ILT_I_X_OK _S_IREAD
#define ILT_I_F_OK 0

#else

/* Unix */

#define ILT_S_IRUSR S_IRUSR
#define ILT_S_IWUSR S_IWUSR
#define ILT_S_IXUSR S_IXUSR
#define ILT_S_IRGRP S_IRGRP
#define ILT_S_IWGRP S_IWGRP
#define ILT_S_IXGRP S_IXGRP
#define ILT_S_IROTH S_IROTH
#define ILT_S_IWOTH S_IWOTH
#define ILT_S_IXOTH S_IXOTH

#define ILT_I_R_OK R_OK
#define ILT_I_W_OK W_OK
#define ILT_I_X_OK X_OK
#define ILT_I_F_OK F_OK

#endif

#define ILT_RUSR() (LLO_INT2FIX(ILT_S_IRUSR))
#define ILT_WUSR() (LLO_INT2FIX(ILT_S_IWUSR))
#define ILT_XUSR() (LLO_INT2FIX(ILT_S_IXUSR))
#define ILT_RGRP() (LLO_INT2FIX(ILT_S_IRGRP))
#define ILT_WGRP() (LLO_INT2FIX(ILT_S_IWGRP))
#define ILT_XGRP() (LLO_INT2FIX(ILT_S_IXGRP))
#define ILT_ROTH() (LLO_INT2FIX(ILT_S_IROTH))
#define ILT_WOTH() (LLO_INT2FIX(ILT_S_IWOTH))
#define ILT_XOTH() (LLO_INT2FIX(ILT_S_IXOTH))

#define ILT_R_OK() (LLO_INT2FIX(ILT_I_R_OK))
#define ILT_W_OK() (LLO_INT2FIX(ILT_I_W_OK))
#define ILT_X_OK() (LLO_INT2FIX(ILT_I_X_OK))
#define ILT_F_OK() (LLO_INT2FIX(ILT_I_F_OK))

/**********************************************************************
 *
 * Handy macro to set the system error
 * -----------------------------------
 *
 **********************************************************************/

LL_EXTERNAL_FUNCTION (char* ilt_strerror, (char*, int));
#define ILT_SYSERROR(caller) \
		ilt_set_system_error(ilt_strerror(caller, ilt_errno()))

#if defined(ILT_OS_WIN32)
LL_EXTERNAL_FUNCTION (char* ilt_win_strerror, (char*, int));
#	define ILT_WINERROR(caller) \
		ilt_set_system_error(ilt_win_strerror(caller, GetLastError()))
#endif

#if defined(ILT_OS_WIN32)
#	define ILT_RUNCTIME(var) var = clock()
#else
#	define ILT_RUNCTIME(var) { struct tms timebuffer; \
			    	   times(&timebuffer); \
			    	   var = timebuffer.tms_utime; }
#endif
/*****************************************************************************

 llthing.c: ptr manager. Ptrs (aka things) are random 32-bit pointers

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llthing.h,v 3.10 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

/********* PTR **********/

/* a ptr (usually 32-bit) is expressed in Talk with two ints (usually
   30-bit): highfix and lowfix, both signed.
   ptr = highfix * 2^BITS_PER_FIX + lowfix
   Usually, highfix is null (ie ptr is in
   [-2^(BITS_PER_FIX-1)..2^(BITS_PER_FIX-1)[ ) so that most of the
    time, a single int is enough to represent a ptr.
   The sign issue is tricky, as VSLONG is (unsually) unsigned. */

/* make the ptr: highfix * 2^BITS_PER_FIX + lowfix */
#define LLO_HIGHLOW(h,l)	(LL_HIGHLOW((LL_fix)(LL_THE_OBJECT(h)),(LL_fix)(LL_THE_OBJECT(l))))
#define LL_HIGHLOW(h,l)		(LLI_HIGHLOW(LL_FIX2INT(LL_THE_FIX(h)),LL_FIX2INT(LL_THE_FIX(l))))
#define LLI_HIGHLOW(h,l)	((LL_object)(((LL_THE_INT(h))<<LL_BITS_PER_FIX)+LL_THE_INT(l)))

/* extract lowfix from thing */
#define LLO_LOW(o)		((LL_object)(LL_LOW(LL_THE_OBJECT(o))))
#define LL_LOW(o)		(LL_INT2FIX(LLI_LOW(LL_THE_OBJECT(o))))
#define LLI_LOW(o)		((((SVSLONG)(LL_THE_OBJECT(o)))<<(BITS_PER_VOIDSTAR-LL_BITS_PER_FIX))>>(BITS_PER_VOIDSTAR-LL_BITS_PER_FIX))

/* extract highfix from thing */
#define LLO_HIGH(o)		((LL_object)(LL_HIGH(LL_THE_OBJECT(o))))
#define LL_HIGH(o)		(LL_INT2FIX(LLI_HIGH(LL_THE_OBJECT(o))))
#define LLI_HIGH(o)		((((SVSLONG)(LL_THE_OBJECT(o)))+(1L<<(LL_BITS_PER_FIX-1)))>>LL_BITS_PER_FIX)

#define LLO_THING_AND(i,j)	((LL_object)LL_THING_AND((VSLONG)LL_THE_OBJECT(i),(VSLONG)LL_THE_OBJECT(j)))
#define LL_THING_AND(i,j)	LLI_UNSIGNED_BINARY(&,i,j)

#define LLO_THING_OR(i,j)	((LL_object)LL_THING_OR((VSLONG)LL_THE_OBJECT(i),(VSLONG)LL_THE_OBJECT(j)))
#define LL_THING_OR(i,j)	LLI_UNSIGNED_BINARY(|,i,j)

#define LLO_THING_NOT(i)	((LL_object)LL_THING_NOT((VSLONG)LL_THE_OBJECT(i)))
#define LL_THING_NOT(i)		LLI_UNSIGNED_UNARY(~,i)

#define LLO_THING_ADD(i,j)	((LL_object)LL_THING_ADD((VSLONG)LL_THE_OBJECT(i),(VSLONG)LL_THE_OBJECT(j)))
#define LL_THING_ADD(i,j)	LLI_UNSIGNED_BINARY(+,i,j)

#define LLO_THING_SUB(i,j)	((LL_object)LL_THING_SUB((VSLONG)LL_THE_OBJECT(i),(VSLONG)LL_THE_OBJECT(j)))
#define LL_THING_SUB(i,j)	LLI_UNSIGNED_BINARY(-,i,j)

#define LLO_THING_SHIFTR(i,j)	((LL_object)LLI_THING_SHIFTR((VSLONG)LL_THE_OBJECT(i),LL_OBJ2INT(j)))
#define LLI_THING_SHIFTR(i,j)	LLI_UNSIGNED_BINARY(>>,i,j)

#define LLO_THING_SHIFTL(i,j)	((LL_object)LLI_THING_SHIFTL((VSLONG)LL_THE_OBJECT(i),LL_OBJ2INT(j)))
#define LLI_THING_SHIFTL(i,j)	LLI_UNSIGNED_BINARY(<<,i,j)

#define LLO_PRED_UNSIGNED_COMPARISON(op,i,j)	(op((LL_fix)LL_THE_OBJECT(i),(LL_fix)LL_THE_OBJECT(j)))
#define LLI_PRED_UNSIGNED_COMPARISON(op,i,j)	(LL_THE_UNSIGNED(i) op LL_THE_UNSIGNED(j))

#define LLO_UNSIGNED_BINARY(op,i,j)	((LL_object)op((LL_fix)LL_THE_OBJECT(i),(LL_fix)LL_THE_OBJECT(j)))
#define LL_UNSIGNED_BINARY(op,i,j)	(LL_INT2FIX(op(LL_FIX2INT(LL_THE_FIX(i)),LL_FIX2INT(LL_THE_FIX(j)))))
#define LLI_UNSIGNED_BINARY(op,i,j)	(((VSLONG)(LL_THE_INT(i)) op ((VSLONG)LL_THE_INT(j))))

#define LLO_UNSIGNED_UNARY(op,i)	((LL_object)op((LL_fix)LL_THE_OBJECT(i)))
#define LL_UNSIGNED_UNARY(op,i)		(LL_INT2FIX(op(LL_FIX2INT(LL_THE_FIX(i)))))
#define LLI_UNSIGNED_UNARY(op,i)	((VSLONG)(op ((VSLONG)LL_THE_INT(i))))

#define LLO_PRED_THING_GE(i,j)	LL_PRED_THING_GE((VSLONG)LL_THE_OBJECT(i),(VSLONG)LL_THE_OBJECT(j))
#define LL_PRED_THING_GE(i,j)	LLI_PRED_UNSIGNED_COMPARISON(>=,i,j)

#define LLO_PRED_THING_GT(i,j)	LL_PRED_THING_GT((VSLONG)LL_THE_OBJECT(i),(VSLONG)LL_THE_OBJECT(j))
#define LL_PRED_THING_GT(i,j)	LLI_PRED_UNSIGNED_COMPARISON(>,i,j)

#define LLO_PRED_THING_LE(i,j)	LL_PRED_THING_LE((VSLONG)LL_THE_OBJECT(i),(VSLONG)LL_THE_OBJECT(j))
#define LL_PRED_THING_LE(i,j)	LLI_PRED_UNSIGNED_COMPARISON(<=,i,j)

#define LLO_PRED_THING_LT(i,j)	LL_PRED_THING_LT((VSLONG)LL_THE_OBJECT(i),(VSLONG)LL_THE_OBJECT(j))
#define LL_PRED_THING_LT(i,j)	LLI_PRED_UNSIGNED_COMPARISON(<,i,j)

#define LLO_SET_THING_IN_MEMORY(w,c)	LLO_VSET(w,(LL_object)LL_INT2FIX(0),c)
#define LL_SET_THING_IN_MEMORY(w,c)	((LL_object)(*((LL_object*)w)=LL_THE_OBJECT(c)))

#define LLO_GET_THING_IN_MEMORY(w)	LL_GET_THING_IN_MEMORY(LL_THE_OBJECT(w))
#define LL_GET_THING_IN_MEMORY(w)	(*((LL_object*)LL_THE_OBJECT(w)))

/*

 iltreadc.h: the reader

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/iltreadc.h,v 1.5 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
*/

LL_EXTERNAL_FUNCTION (int ilt_input_stream_ready_p, (void *));
LL_EXTERNAL_FUNCTION (void* define_sharp_function, (void* ch, LL_function fn));
LL_EXTERNAL_FUNCTION (void* ilt_read_char, (struct ilt_stream_struct * st, void* eosval));
LL_EXTERNAL_FUNCTION (void* ilt_peek_char, (struct ilt_stream_struct * st, void* eosval));
LL_EXTERNAL_FUNCTION (void* ilt_read_line, (struct ilt_stream_struct * st, void* eosval));
LL_EXTERNAL_FUNCTION (void* ilt_read, (struct ilt_stream_struct * st, void* eosval, void* regionht, void* topregionp));
LL_EXTERNAL_FUNCTION (void* ilt_skip_parens, (struct ilt_stream_struct * st));

#define ILT_DEFINE_SHARP_FUNCTION(ch,fn)  \
	((LL_object)define_sharp_function((void*)(ch),(LL_function)(fn)))
#define ILT_READ_CHAR(st,eosval)  \
	((LL_object)ilt_read_char((struct ilt_stream_struct *)(st),(void*)(eosval)))
#define ILT_PEEK_CHAR(st,eosval)  \
	((LL_object)ilt_peek_char((struct ilt_stream_struct *)(st),(void*)(eosval)))
#define ILT_READ_LINE(st,eosval)  \
	((LL_object)ilt_read_line((struct ilt_stream_struct *)(st),(void*)(eosval)))
#define ILT_READ(st,eosval,r,t)  \
	((LL_object)ilt_read((struct ilt_stream_struct *)(st),(void*)(eosval),(void*)(r),(void*)(t)))
#define ILT_SKIP_PARENS(st)  \
	((LL_object)ilt_skip_parens((struct ilt_stream_struct *)(st)))

/*****************************************************************************

 llbignum.h:  Interface to the DEC/INRIA BigNum library

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1995-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llbignum.h,v 1.2 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
******************************************************************************/


typedef struct IltBigZStruct * 		IltBigZ;

LL_EXTERNAL_FUNCTION (IltBigZ BzAdd, (IltBigZ y, IltBigZ z));
LL_EXTERNAL_FUNCTION (IltBigZ BzSubtract, (IltBigZ y, IltBigZ z));
LL_EXTERNAL_FUNCTION (IltBigZ BzMultiply, (IltBigZ y, IltBigZ z));
LL_EXTERNAL_FUNCTION (IltBigZ BzAbs, (IltBigZ y));
LL_EXTERNAL_FUNCTION (long BzCompare, (IltBigZ y, IltBigZ z));
LL_EXTERNAL_FUNCTION (IltBigZ BzFromInteger, (long x));

#define ILT_BZ_ADD(y,z)  ((LL_object)BzAdd((IltBigZ)(y),(IltBigZ)(z)))
#define ILT_BZ_SUBTRACT(y,z)  ((LL_object)BzSubtract((IltBigZ)(y),(IltBigZ)(z)))
#define ILT_BZ_MULTIPLY(y,z)  ((LL_object)BzMultiply((IltBigZ)(y),(IltBigZ)(z)))
#define ILT_BZ_ABS(y)  ((LL_object)BzAbs((IltBigZ)(y)))
#define ILT_BZ_COMPARE(y,z)  ((LL_object)BzCompare((IltBigZ)(y),(IltBigZ)(z)))
#define ILT_BZ_FROM_INTEGER(x)  ((LL_object)BzFromInteger((long)(x)))

/*****************************************************************************

 llfloat.h:  Macros for llfloat

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llfloat.h,v 3.17 1996/06/19 12:54:09 v16admin Exp $
 ----------------------------------------------------------------------
******************************************************************************/

#include <math.h>

#define LL_PRED_FLOATP(o)   (LL_FLOAT_CLAN==ll_object_clan(LL_THE_OBJECT(o)))
#define LLO_PRED_FLOATP(o)  (LL_FLOAT_CLAN==ll_object_clan(LL_THE_OBJECT(o)))

typedef double					*LL_float ;
typedef VSLONG				LL_fos ; /* float offset */
#define LL_INT2FOS(i)		(LL_THE_INT(i)<<LOG_BYTES_PER_FLOAT)
#define LL_FOS2INT(i)		(LL_THE_FOS(i)>>LOG_BYTES_PER_FLOAT)
#define LL_FIX2FOS(i)		(LL_THE_FIX(i)<<LOG_BYTES_PER_FLOAT)
#define LL_FOS2FIX(i)		((LL_THE_FOS(i)>>LOG_BYTES_PER_FLOAT)|~(((VSLO~NG)-1)>>1))

#define LLO_MAKE_FLOAT()	((LL_object)LL_MAKE_FLOAT())
#define LL_MAKE_FLOAT()		(ll_make_float())
LL_EXTERNAL_FUNCTION (LL_float	ll_make_float,	(void)) ;
LL_EXTERNAL_FUNCTION (LL_float	ll_make_float_copying_c,	(double d)) ;

/* inlined float allocator */
#define LLO_MAKE_FLOAT_IN(dbl,var)	LL_MAKE_FLOAT_ROW_1(LL_FLOAT_CLAN,dbl,var)

LL_EXTERNAL_FUNCTION (LL_object	ll_finitep,	(LL_float f)) ;

#define LLO_FLOAT2STRING(f,s)	((LL_object)LL_FLOAT2STRING((LL_float)f,(LL_string)s))
#define LL_FLOAT2STRING(f,s)		(LL_INT2FIX(ll_cvftoa(LL_THE_FLOAT(f),LL_THE_STRING(s))))
LL_EXTERNAL_FUNCTION (VSLONG	ll_cvftoa,	(LL_float f, LL_string s)) ;

#define LLO_STRING2FLOAT(s)	((LL_object)LL_STRING2FLOAT((LL_string)s))
#define LL_STRING2FLOAT(s)		(ll_cvatof(LL_THE_STRING(s)))
LL_EXTERNAL_FUNCTION (LL_float	ll_cvatof,	(LL_string s)) ;

LL_EXTERNAL_FUNCTION (LL_object	llo_make_fadd,	(LL_object x, LL_object y)) ;
LL_EXTERNAL_FUNCTION (LL_object	llo_make_fsub,	(LL_object x, LL_object y)) ;
LL_EXTERNAL_FUNCTION (LL_object	llo_make_fmul,	(LL_object x, LL_object y)) ;
LL_EXTERNAL_FUNCTION (LL_object	llo_make_fdiv,	(LL_object x, LL_object y)) ;

#define LLO_FMOV(x,result)	(*((LL_float)(result))=(*((LL_float)(x))),ll_nil)

#define LLO_FADD(x,y,result)	(*((LL_float)(result))=(*((LL_float)(x))) + (*((LL_float)(y))),ll_nil)

#define LLO_FSUB(x,y,result)	(*((LL_float)(result))=(*((LL_float)(x))) - (*((LL_float)(y))),ll_nil)

#define LLO_FMUL(x,y,result)	(*((LL_float)(result))=(*((LL_float)(x))) * (*((LL_float)(y))),ll_nil)

#define LLO_FDIV(x,y,result)	(*((LL_float)(result))=(*((LL_float)(x))) / (*((LL_float)(y))),ll_nil)

#if defined(ILT_OS_WIN32) || defined(ILT_TALK_PORT_SGI64_6_2_6_2) || defined(ILT_TALK_PORT_I86_SUNOS5_3_0) || defined(ILT_TALK_PORT_I86_SUNOS5_4_0)
/* The platforms `msvc4' and `sgi64' have buggy NaN comparisons. Try `llfloat_nan_test.c'. */
/* The Solaris i386 compiler simplifies (f= x x) to true when f= is inlined. Buggy. */
#define ILT_BUGGY_NAN_COMPARISONS
#endif

LL_EXTERNAL_FUNCTION (int ilt_pred_fbeq, (LL_float x, LL_float y));
LL_EXTERNAL_FUNCTION (int ilt_pred_fbne, (LL_float x, LL_float y));
LL_EXTERNAL_FUNCTION (int ilt_pred_fble, (LL_float x, LL_float y));
LL_EXTERNAL_FUNCTION (int ilt_pred_fblt, (LL_float x, LL_float y));
LL_EXTERNAL_FUNCTION (int ilt_pred_fbge, (LL_float x, LL_float y));
LL_EXTERNAL_FUNCTION (int ilt_pred_fbgt, (LL_float x, LL_float y));

#if defined(ILT_BUGGY_NAN_COMPARISONS)

#define LLO_PRED_FBEQ(x,y)	ilt_pred_fbeq((LL_float)(x),(LL_float)(y))
#define LLO_PRED_FBNE(x,y)	ilt_pred_fbne((LL_float)(x),(LL_float)(y))
#define LLO_PRED_FBLE(x,y)	ilt_pred_fble((LL_float)(x),(LL_float)(y))
#define LLO_PRED_FBLT(x,y)	ilt_pred_fblt((LL_float)(x),(LL_float)(y))
#define LLO_PRED_FBGE(x,y)	ilt_pred_fbge((LL_float)(x),(LL_float)(y))
#define LLO_PRED_FBGT(x,y)	ilt_pred_fbgt((LL_float)(x),(LL_float)(y))

#else

#define LLO_PRED_FBEQ(x,y)	(*((LL_float)(x)) == (*((LL_float)(y))))
#define LLO_PRED_FBNE(x,y)	(*((LL_float)(x)) != (*((LL_float)(y))))
#define LLO_PRED_FBLE(x,y)	(*((LL_float)(x)) <= (*((LL_float)(y))))
#define LLO_PRED_FBLT(x,y)	(*((LL_float)(x)) < (*((LL_float)(y))))
#define LLO_PRED_FBGE(x,y)	(*((LL_float)(x)) >= (*((LL_float)(y))))
#define LLO_PRED_FBGT(x,y)	(*((LL_float)(x)) > (*((LL_float)(y))))

#endif

/* Les fonctions de conversion */

#define LLO_FIX2FLOAT(n,f)	((LL_object)LL_FIX2FLOAT((LL_fix)n,(LL_float)f))
#define LL_FIX2FLOAT(n,f)	(LL_INT2FLOAT(LL_FIX2INT(LL_THE_FIX(n)), LL_THE_FLOAT(f)))
#define LL_INT2FLOAT(n,f)	(ll_floatc(LL_THE_INT(n), LL_THE_FLOAT(f)))
LL_EXTERNAL_FUNCTION (LL_float	ll_floatc,	(VSLONG n, LL_float f)) ;

#define LLO_FLOAT2FIX(f)	((LL_object)LL_FLOAT2FIX((LL_float)(f)))
#define LL_FLOAT2FIX(f)		(LL_INT2FIX(LL_FLOAT2INT(LL_THE_FLOAT(f))))
#define LL_FLOAT2INT(f)		(fixc((LL_THE_FLOAT(f))))
/* \\ maybe (VSLONG)LL_THE_FLOAT(f) would do, which would be much more efficient */
LL_EXTERNAL_FUNCTION (VSLONG	fixc,	(LL_float f)) ;

/* Les fonctions circulaires et mathematiques doubles */

#define LLO_FSIN(x,result)	(*((LL_float)(result))=sin(*((LL_float)(x))),ll_nil)

#define LLO_FCOS(x,result)	(*((LL_float)(result))=cos(*((LL_float)(x))),ll_nil)

#define LLO_FASIN(x,result)	(*((LL_float)(result))=asin(*((LL_float)(x))),ll_nil)

#define LLO_FACOS(x,result)	(*((LL_float)(result))=acos(*((LL_float)(x))),ll_nil)

#define LLO_FATAN(x,result)	(*((LL_float)(result))=atan(*((LL_float)(x))),ll_nil)

#define LLO_FEXP(x,result)	(*((LL_float)(result))=exp(*((LL_float)(x))),ll_nil)

#define LLO_FLOG(x,result)	(*((LL_float)(result))=log(*((LL_float)(x))),ll_nil)

#define LLO_FLOG10(x,result)	(*((LL_float)(result))=log10(*((LL_float)(x))),ll_nil)

#define LLO_FPOWER(x,y,result)	(*((LL_float)(result))=pow(*((LL_float)(x)),*((LL_float)(y))),ll_nil)

#define LLO_FCOMPOUND(x,y,result) (*((LL_float)(result))=compound(*((LL_float)(x)),*((LL_float)(y))),ll_nil)

#define LLO_FANNUITY(x,y,result) (*((LL_float)(result))=annuity(*((LL_float)(x)),*((LL_float)(y))),ll_nil)

#define LLO_FSQRT(x,result)	(*((LL_float)(result))=sqrt(*((LL_float)(x))),ll_nil)

/*****************************************************************************

 lldfxtest.h:  exports for testing defextern

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/lldfxtest.h,v 3.5 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
******************************************************************************/

/* \\ until defextern's signature is handled (void inclusive) */
#define LLVOID VSLONG

/*
LL_EXTERNAL_FUNCTION (LLVOID	store_fix,	(VSLONG x)) ;
LL_EXTERNAL_FUNCTION (LLVOID	store_rfloat,	(double * x)) ;
LL_EXTERNAL_FUNCTION (LLVOID	store_string,	(char *x)) ;
LL_EXTERNAL_FUNCTION (LLVOID	store_vector,	(LL_object *x)) ;
LL_EXTERNAL_FUNCTION (LLVOID	store_t,	(LL_object x)) ;
LL_EXTERNAL_FUNCTION (LLVOID	store_external,	(void *x)) ;
LL_EXTERNAL_FUNCTION (LLVOID	store_boolean,	(VSLONG x)) ;
LL_EXTERNAL_FUNCTION (LLVOID	store_address,	(void *x)) ;

LL_EXTERNAL_FUNCTION (VSLONG	recall_fix,	(void)) ;
LL_EXTERNAL_FUNCTION (double*	recall_rfloat,	(void)) ;
LL_EXTERNAL_FUNCTION (char*	recall_string,	(void)) ;
LL_EXTERNAL_FUNCTION (LL_object*	recall_vector,	(void)) ;
LL_EXTERNAL_FUNCTION (LL_object	recall_t,	(void)) ;
LL_EXTERNAL_FUNCTION (void*	recall_external,	(void)) ;
LL_EXTERNAL_FUNCTION (VSLONG	recall_boolean,	(void)) ;
LL_EXTERNAL_FUNCTION (void*	recall_address,	(void)) ;
*/
/**********************************************************************
  
 llstack.h:  Run-time for the Talk stack

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llstack.h,v 3.27 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 **********************************************************************/


#include <setjmp.h>
#include <iltsystem.h>

/*
 * setjmp/longjmp operations
 */

#if defined(ILT_USE_UNDERSCORE_SETJMP)
#	define LLSETJMP		_setjmp
#	define LLLONGJMP	_longjmp
#	define LLJMP_BUF	jmp_buf
#else
#	define LLSETJMP		setjmp
#	define LLLONGJMP	longjmp
#	define LLJMP_BUF	jmp_buf
#endif

#if defined(ILT_OS_WIN32_WINNT)
#else
#	define ILT_OS_HAS_SIGJMP
#endif

#if defined(ILT_OS_HAS_SIGJMP)
/* restore signal mask, of course! */
#	define ILT_SIGSETJMP(env)	sigsetjmp(env, 1)
#	define ILT_SIGLONGJMP		siglongjmp
#	define ILT_SIGJMP_BUF		sigjmp_buf
#else
#	define ILT_SIGSETJMP		LLSETJMP
#	define ILT_SIGLONGJMP		LLLONGJMP
#	define ILT_SIGJMP_BUF		LLJMP_BUF
#endif

/*
 * Stack frame types. See comments in structure definitions.
 */

typedef enum
{
     LL_DYNAMIC_FRAME_TYPE,
     LL_FUNCTION_CALL_FRAME_TYPE,
     LL_MULTIPLE_FRAME_TYPE,
     LL_VECTOR_END_FRAME_TYPE,
     LL_CALL_FRAME_TYPE,
     LL_PROTECT_FRAME_TYPE,
     LL_UNWIND_FRAME_TYPE,
     LL_LEXICAL_FRAME_TYPE,
     LL_CATCH_FRAME_TYPE,
     LL_VECTOR_BEGIN_FRAME_TYPE,
     LL_SMALL_VECTOR_FRAME_TYPE,
     LL_NODE_FRAME_TYPE,
     LL_BOTTOM_FRAME_TYPE,
     LL_INTERPRETATION_FRAME_TYPE
} LL_frame_type;


/*
 * This must be (sizeof(biggest stack frame)/sizeof(LL_object) - 1),
 * i.e, the number of fields of the biggest stack frame minus 1.
 */

#define LL_SMALL_VECTOR_SIZE	3


/*
 * For dynamic variables shallow binding management.
 */

typedef struct LL_dynamic_frame_struct
{
     LL_frame_type type; /* LL_DYNAMIC_FRAME_TYPE */
     LL_object symbol;		/* The symbol being bound */
     LL_object previous_value;	/* Its previous value for restoration */
} *LL_dynamic_frame;


/*
 * For lexical variables shallow binding management in the interpreter.
 */

typedef struct LL_lexical_frame_struct
{
     LL_frame_type type; /* LL_LEXICAL_FRAME_TYPE */
     LL_object binding;		/* The lexical binding being boud */
     LL_object previous_value;	/* Its previous value for restoration */
} *LL_lexical_frame;


/*
 * Function call frames for use in the debugger.
 */

typedef struct LL_function_call_frame_struct
{
     LL_frame_type type; /* LL_FUNCTION_CALL_FRAME_TYPE */
     LL_object function;	/* The functional object being called */
     VSLONG number_of_arguments; /* The actual number of arguments */
     LL_object *arguments;	/* A C vector containing the arguments */
} *LL_function_call_frame;


/*
 * Used to store in the stack vectors of objects, used as additional
 * information for such frames as multiple frames or function call
 * frames which need to hold variable-length information.
 */


          /* For at most LL_SMALL_VECTOR_SIZE objects */

typedef struct LL_small_vector_frame_struct
{
     LL_frame_type type; /* LL_SMALL_VECTOR_FRAME_TYPE */
     LL_object vector[LL_SMALL_VECTOR_SIZE];
} *LL_small_vector_frame;


         /* For more than LL_SMALL_VECTOR_SIZE objects, we use one frame to
            mark the beginning of the vector, and one frame to mark the end. */

typedef struct LL_vector_begin_frame_struct
{
     LL_frame_type type; /* LL_VECTOR_BEGIN_FRAME_TYPE */
     void *next_frame;		/* First frame after the end frame */
} *LL_vector_begin_frame;

typedef struct LL_vector_end_frame_struct
{
     LL_frame_type type; /* LL_VECTOR_END_FRAME_TYPE */
     void *prev_frame;		/* First frame before the begin frame */
} *LL_vector_end_frame;


/*
 * Frames for &multiple arguments.
 */

typedef struct LL_multiple_frame_struct
{
     LL_frame_type type; /* LL_MULTIPLE_FRAME_TYPE */
     VSLONG number_of_values;	/* Number of values */
     LL_object *value_vector;	/* C vector of values */
} *LL_multiple_frame;


/*
 * Frames for catch managemement in deep binding.
 *
 * \\ Because of the function ll_catch_to_node, don't change the order
 * \\ nor the types of the three first fields of catch frames without
 * \\ changing also node frames, and vice versa.
 */

typedef struct LL_catch_frame_struct
{
     LL_frame_type type; /* LL_CATCH_FRAME_TYPE */
     LL_object tag;		/* The tag */
     LLJMP_BUF *continuation;	/* Setjmp here to exit the catch form. */
} *LL_catch_frame;


/*
 * Frames to store interpreted nodes in the stack, for debug purposes.
 *
 * \\ See the remark for catch frames.
 */

typedef struct LL_node_frame_struct
{
     LL_frame_type type; /* LL_NODE_FRAME_TYPE */
     LL_object node;		/* The interpreted node. */
     LLJMP_BUF *continuation;	/* Setjmp here to short-cut the */
				/* interpreration. */
     LL_object break_flag;	/* An information for breakpoints. */
} *LL_node_frame;


/*
 * Frames for management of unwind-protect.
 */

typedef struct LL_protect_frame_struct
{
     LL_frame_type type; /* LL_PROTECT_FRAME_TYPE */
     LLJMP_BUF *cleanup_form;	/* Setjmp here to execute the cleanup form. */
} *LL_protect_frame;

typedef struct LL_unwind_frame_struct
{
     LL_frame_type type; /* LL_UNWIND_FRAME_TYPE */
     LL_catch_frame destination;/* The frame to escape to */
     LL_object value;		/* Value of the throw */
} *LL_unwind_frame;


/*
 * Frames to mark the logical bottom of the stack, used by the debugger
 * to manage nested break loops.
 */
 
typedef struct LL_bottom_frame_struct
{
     LL_frame_type type; /* LL_BOTTOM_FRAME_TYPE */
} *LL_bottom_frame;


/*
 * Frame pushed by the interpreted to mark the beginning of the
 * interpretation of a new "toplevel" expression, such as the body
 * of a function.
 */

typedef struct LL_interpretation_frame_struct
{
     LL_frame_type type; /* LL_INTERPRETATION_FRAME_TYPE */
     LL_object node;   /* The node being evaluated */
     LL_object fun;    /* The function entered in, or () */
} *LL_interpretation_frame;




#define LLO_LL_DYNAMIC_VALUE(t)	((LL_object) ll_dynamic_value(t))
#define LLO_LL_SET(t1,t2)	((LL_object) ll_set(t1,t2))
#define LLO_LL_GLOBAL_SET(t1,t2)	((LL_object) ll_global_set(t1,t2))
#define LLO_LL_PUSH_MULTIPLE_FRAME(fix)	((LL_object) ll_push_multiple_frame(fix))
#define LLO_LL_POP_MULTIPLE_FRAME(t)	((LL_object) ll_pop_multiple_frame(t))
#define LLO_LL_SET_MULTIPLE_NTH(t1,t2,t3)	((LL_object) ll_set_multiple_nth(t1,t2,t3))
#define LLO_LL_MULTIPLE_NTH(t1,t2)	((LL_object) ll_multiple_nth(t1,t2))
#define LLO_LL_STATIC_ADDR(t)	((LL_object) ll_static_addr(t))
#define LLO_LL_STACK_TRACE()	((LL_object) ll_stack_trace())

#define LLO_MULTIPLE_NTH(mf,f)	(ll_multiple_nth(mf,((LL_fix)LL_THE_OBJECT(f))))
#define LLO_SET_MULTIPLE_NTH(mf,f,v)	(ll_multiple_nth(mf,((LL_fix)LL_THE_OBJECT(f)),LL_THE_OBJECT(v)))
#define LLO_MULTIPLE_LENGTH(mf)	((LL_object)ll_multiple_length(mf))



/* Stack frame operations */

LL_EXTERNAL_FUNCTION(void ll_init_stack,
		     (void));
LL_EXTERNAL_FUNCTION(void ll_deactivate_stack,
		     (void));
LL_EXTERNAL_FUNCTION(void ll_activate_stack,
		     (void));
LL_EXTERNAL_FUNCTION(void ll_set_stack_pointer,
		     (LL_dynamic_frame new_sp));
LL_EXTERNAL_FUNCTION(void ll_emergency_exit,
		     (void));

/*  Dynamic bindings */

LL_EXTERNAL_FUNCTION(LL_dynamic_frame ll_push_dynamic_binding,
		     (LL_object symbol,
		      LL_object value));


LL_EXTERNAL_FUNCTION(LL_dynamic_frame ll_push_progv_bindings,
		     (LL_object symbols,
		      LL_object values));

LL_EXTERNAL_FUNCTION(LL_dynamic_frame ll_pop_dynamic_binding,
		     (void));

LL_EXTERNAL_FUNCTION(LL_object ll_dynamic_value,
		     (LL_object symbol));

LL_EXTERNAL_FUNCTION(LL_object ll_global_set,
		     (LL_object symbol,
		      LL_object value));

LL_EXTERNAL_FUNCTION(LL_object ll_set,
		     (LL_object symbol,
		      LL_object value));

/* Catch frames */

LL_EXTERNAL_FUNCTION(void ll_push_catch_frame,
		     (LL_object tag,
		      LLJMP_BUF jump_buffer));
LL_EXTERNAL_FUNCTION(void ll_pop_catch_frame,
		     (void));
LL_EXTERNAL_FUNCTION(LL_catch_frame ll_lookup_catch_tag,
		     (LL_object tag));
LL_EXTERNAL_FUNCTION(LL_object ll_throw,
		     (LL_catch_frame catch)
		     (LL_object value));
LL_EXTERNAL_FUNCTION(LL_object ll_last_throw_value,
		     (void));

/* Unwind protect frames */

LL_EXTERNAL_FUNCTION(LL_dynamic_frame ll_push_protect_frame,
		     (LLJMP_BUF cleanup_form));
LL_EXTERNAL_FUNCTION(void ll_pop_protect_frame,
		     ());
LL_EXTERNAL_FUNCTION(void ll_continue_unwinding,
		     ());
LL_EXTERNAL_FUNCTION(void ll_run_protect,
		     (LL_protect_frame protect_frame));

/* Multiple frames */

LL_EXTERNAL_FUNCTION(LL_multiple_frame	ll_push_multiple_frame,	(VSLONG nv)) ;

LL_EXTERNAL_FUNCTION(VSLONG ll_pop_multiple_frame,
		     (LL_multiple_frame mf));

LL_EXTERNAL_FUNCTION(LL_object ll_multiple_nth,
		     (LL_multiple_frame mf, LL_fix i)) ;

LL_EXTERNAL_FUNCTION(VSLONG ll_set_multiple_nth,
		     (LL_multiple_frame mf, LL_fix f, LL_object v));

LL_EXTERNAL_FUNCTION(LL_fix ll_multiple_length,
		     (LL_multiple_frame mf));

/* Debug functions */

LL_EXTERNAL_FUNCTION(LL_symbol ll_debug_check_function,
		     (LL_symbol sym));

LL_EXTERNAL_FUNCTION(LL_function_call_frame ll_debug_push_frame,
		     ());

LL_EXTERNAL_FUNCTION(LL_object ll_debug_pop_frame,
		     (LL_object value));
/*****************************************************************************

 llflag.h: flag management

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/home/parquier/c16/talk/common/RCS/llflag.h,v 3.14 1996/02/28 15:27:16 parquier Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

LL_EXTERNAL_FUNCTION (LL_object	ll_set_flag,		(LL_object f, 
							 LL_object v)) ;
LL_EXTERNAL_FUNCTION (LL_object	ll_get_flag,		(LL_object s)) ;
LL_EXTERNAL_FUNCTION (void	ll_init_flag,	(void)) ;
LL_EXTERNAL_FUNCTION (void	ll_parse_args,	(int argc,
						 char **argv)) ;

#define LLO_LL_GET_FLAG(string)	((LL_object) ll_get_flag(string))
#define LLO_LL_SET_FLAG(string,t)	((LL_object) ll_set_flag(string,t))

#define DATAMOVED (1<<0)
#define NEWEXEC   (1<<1)
#define NEWIFLAG  (1<<2)
#define NOTSAVED  (1<<3)
#define FORCE     (1<<4)
#define ANYERR    (-1^FORCE)

/*
 * Configuration flags
 */

LL_EXTERNAL_STATIC_INIT (VSLONG		ll_saveimagewhen, NOTSAVED|DATAMOVED);
LL_EXTERNAL_STATIC (char*		ll_image_path);
LL_EXTERNAL_STATIC_INIT (char*		ilt_before_saving_message,
			 "Saving image...\n");
LL_EXTERNAL_STATIC_INIT (char*		ilt_after_saving_message,
			 "...image is saved.\n");
LL_EXTERNAL_STATIC_INIT (VSLONG		ll_norun, 0);
LL_EXTERNAL_STATIC_INIT (VSLONG		ilt_pretend_saving_p, 0);
LL_EXTERNAL_STATIC_INIT (VSLONG		ll_freerow, 1);
LL_EXTERNAL_STATIC_INIT (VSLONG		ll_gcmod, 0);
LL_EXTERNAL_STATIC (VSLONG		ll_show_access);
LL_EXTERNAL_STATIC_INIT (VSLONG		ll_flag_lllim, 0);
LL_EXTERNAL_STATIC_INIT (VSLONG		ll_flag_renamable_executable, 0);
LL_EXTERNAL_STATIC_INIT (VSLONG		ll_flag_removable_executable, 0);

/* obsolete */

LL_EXTERNAL_STATIC (VSLONG		ll_debug);
LL_EXTERNAL_STATIC (VSLONG		ll_verbose);
/*

 llmodule.h:  Module loading.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llmodule.h,v 3.4 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
                                                                             */

typedef struct LL_moduleS { LL_symbol name; /* name of the module */
			    LL_symbol level; /* debug level */
			    LL_fix code_size; /* compiled code size in bytes */
			    LL_symbol state; /* compiled or not */
			    LL_symbol node; /* interpreted def */
			    LL_fix load_date; /* date this module was loaded */
			    long binary_mtime; /* date of module binary */
		    } *LL_module;

LL_EXTERNAL_FUNCTION (LL_module	ll_make_module,	(LL_symbol name,
						 LL_symbol level,
						 LL_fix code_size,
						 LL_symbol state,
						 LL_fix load_date,
						 long binary_mtime)) ;



/*
  
 abclib.h:  Unix run-time for Talk code compiled with Abeille
  
 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llabclib.h,v 1.31 1996/04/15 14:05:02 v16admin Exp $
 ----------------------------------------------------------------------
                                                                             */

/* Each object file contains the version.  This file is included after
   the per-file definition. */
#include <iltsystem.h>
#include <setjmp.h>
#include <varargs.h>

#if !defined(NULL)
#define NULL 0
#endif /* !defined(NULL) */

/* This is the type of fields of Talk objects.  It is used only to
   cast RHS's */
typedef char *LL_memory;

LL_EXTERNAL_FUNCTION(void	ll_runtime_error,	(char* message));

LL_EXTERNAL_FUNCTION(void ll_lisp_error, ());


LL_EXTERNAL_FUNCTION(LL_symbol ll_symbol_from_strings, (char *package,
						       char *name));


/* Maximum number of arguments to an applied function */

#define LL_MAX_APPLY_ARGS	60

LL_EXTERNAL_FUNCTION(LL_object ll_array_apply, (LL_function funobj, VSLONG nargs,
						LL_object *args));

LL_EXTERNAL_FUNCTION(LL_object ll_multiple_apply, (LL_function funobj, 
						   LL_multiple_frame multiple));

LL_EXTERNAL_FUNCTION(LL_object ll_multiple_apply1, (LL_function funobj, 
						    LL_object arg1,
						   LL_multiple_frame multiple));

LL_EXTERNAL_FUNCTION(LL_object ll_multiple_apply2, (LL_function funobj, 
						    LL_object arg1,
						    LL_object arg2,
						   LL_multiple_frame multiple));

LL_EXTERNAL_FUNCTION(LL_object ll_multiple_apply3, (LL_function funobj, 
						    LL_object arg1,
						    LL_object arg2,
						    LL_object arg3,
						   LL_multiple_frame multiple));

LL_EXTERNAL_FUNCTION(LL_object ll_multiple_apply4, (LL_function funobj, 
						    LL_object arg1,
						    LL_object arg2,
						    LL_object arg3,
						    LL_object arg4,
						   LL_multiple_frame multiple));

LL_EXTERNAL_FUNCTION(LL_object ll_multiple_apply5, (LL_function funobj, 
						    LL_object arg1,
						    LL_object arg2,
						    LL_object arg3,
						    LL_object arg4,
						    LL_object arg5,
						   LL_multiple_frame multiple));


/* literal creation */
LL_EXTERNAL_FUNCTION(LL_vector ll_decode_literals,
		     (char* code));


#define llo_register_object(obj)ll_check_in_module_root(&(obj))




/* C null testing */
#define LL_C_NULL(x) x== NULL

/* interface functions */
LL_EXTERNAL_FUNCTION(LL_object ll_user_error,
		     (LL_object where)
		     (LL_object error)
		     (LL_object error_args));

#define REQUIRE_END (void) -1	/* Just to require a semi after the macro */

/* Casting to Talk object */
	
#define LL_LISP_OBJECT(obj)((LL_object) obj)

/* Cast to a symbol, but legally for lvalues */
#define LL_LSYMBOL(loc) (*((LL_symbol*)(&(loc))))

/* Representation information that does not belong in this file */

/* was: #define LLABC_OFENTRY(lisp_symbol_var, lisp_symbol, codeaddr, ncvars) lisp_symbol_var = (LL_symbol) lisp_symbol; lisp_symbol_var->fval = (LL_function) lli_make_function(&(lisp_symbol), codeaddr, LL_OBJ2INT(ncvars), 0); */

#define LLABC_OFENTRY(lisp_symbol_var, lisp_symbol, codeaddr, ncvars) lisp_symbol_var = (LL_symbol) lisp_symbol; ilt_make_relocatable_ofentry(lisp_symbol, codeaddr, ncvars);

#define LLABC_OENTRY(location, codeaddr, ncvars) location = (LL_object) lli_make_initialized_function(codeaddr, ncvars, 0);

#define LLABC_IENTRY(location, function) location = function
#define LLABC_SENTRY(symbol_var, symbol, function)  symbol_var = (LL_symbol) symbol; symbol_var->fval = (LL_function) function

/* Function call in debug mode */

#define LO_DSFUNCALL(sym,args)(ll_debug_check_function(sym), ll_debug_push_frame args, ll_debug_pop_frame((LL_SYMBOL_CODE(sym))args))

#define LO_DFUNCALL(loc,args) (ll_debug_push_frame args, ll_debug_pop_frame(LO_FUNCALL(loc,args)))

/* For old code compatibility */

#define LO_SSFUNCALL(sym,args)(((sym)->fval == ll_undefined_function) ? ll_user_error((LL_object)sym, llsym_errudf, ll_nil) : LO_SFUNCALL(sym,args))

/* Function call in standard mode */

#define LO_SFUNCALL(sym,args)(LL_SYMBOL_CODE(sym))args

#define LO_FUNCALL(loc,args)((((LL_function) loc)->code)args)


#define LL_FUNCALL0(fn)\
   LO_FUNCALL(fn,(fn,0))
#define LL_FUNCALL1(fn,a1)\
   LO_FUNCALL(fn,(fn,1,a1))
#define LL_FUNCALL2(fn,a1,a2)\
   LO_FUNCALL(fn,(fn,2,a1,a2))
#define LL_FUNCALL3(fn,a1,a2,a3)\
   LO_FUNCALL(fn,(fn,3,a1,a2,a3))
#define LL_FUNCALL4(fn,a1,a2,a3,a4)\
   LO_FUNCALL(fn,(fn,4,a1,a2,a3,a4))
#define LL_FUNCALL5(fn,a1,a2,a3,a4,a5)\
   LO_FUNCALL(fn,(fn,5,a1,a2,a3,a4,a5))
#define LL_FUNCALL6(fn,a1,a2,a3,a4,a5,a6)\
   LO_FUNCALL(fn,(fn,6,a1,a2,a3,a4,a5,a6))
#define LL_FUNCALL7(fn,a1,a2,a3,a4,a5,a6,a7)\
   LO_FUNCALL(fn,(fn,7,a1,a2,a3,a4,a5,a6,a7))
#define LL_FUNCALL8(fn,a1,a2,a3,a4,a5,a6,a7,a8)\
   LO_FUNCALL(fn,(fn,8,a1,a2,a3,a4,a5,a6,a7,a8))
#define LL_FUNCALL9(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9)\
   LO_FUNCALL(fn,(fn,9,a1,a2,a3,a4,a5,a6,a7,a8,a9))
#define LL_FUNCALL10(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10)\
   LO_FUNCALL(fn,(fn,10,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10))
#define LL_FUNCALL11(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11)\
   LO_FUNCALL(fn,(fn,11,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11))
#define LL_FUNCALL12(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12)\
   LO_FUNCALL(fn,(fn,12,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12))
#define LL_FUNCALL13(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13)\
   LO_FUNCALL(fn,(fn,13,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13))
#define LL_FUNCALL14(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14)\
   LO_FUNCALL(fn,(fn,14,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14))
#define LL_FUNCALL15(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15)\
   LO_FUNCALL(fn,(fn,15,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15))
#define LL_FUNCALL16(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16)\
   LO_FUNCALL(fn,(fn,16,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16))
#define LL_FUNCALL17(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17)\
   LO_FUNCALL(fn,(fn,17,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17))
#define LL_FUNCALL18(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18)\
   LO_FUNCALL(fn,(fn,18,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18))
#define LL_FUNCALL19(fn,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19)\
   LO_FUNCALL(fn,(fn,19,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19))

#define LL_SFUNCALL0(symb)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,0))
#define LL_SFUNCALL1(symb,a1)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,1,a1))
#define LL_SFUNCALL2(symb,a1,a2)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,2,a1,a2))
#define LL_SFUNCALL3(symb,a1,a2,a3)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,3,a1,a2,a3))
#define LL_SFUNCALL4(symb,a1,a2,a3,a4)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,4,a1,a2,a3,a4))
#define LL_SFUNCALL5(symb,a1,a2,a3,a4,a5)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,5,a1,a2,a3,a4,a5))
#define LL_SFUNCALL6(symb,a1,a2,a3,a4,a5,a6)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,6,a1,a2,a3,a4,a5,a6))
#define LL_SFUNCALL7(symb,a1,a2,a3,a4,a5,a6,a7)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,7,a1,a2,a3,a4,a5,a6,a7))
#define LL_SFUNCALL8(symb,a1,a2,a3,a4,a5,a6,a7,a8)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,8,a1,a2,a3,a4,a5,a6,a7,a8))
#define LL_SFUNCALL9(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,9,a1,a2,a3,a4,a5,a6,a7,a8,a9))
#define LL_SFUNCALL10(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,10,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10))
#define LL_SFUNCALL11(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,11,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11))
#define LL_SFUNCALL12(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,12,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12))
#define LL_SFUNCALL13(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,13,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13))
#define LL_SFUNCALL14(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,14,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14))
#define LL_SFUNCALL15(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,15,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15))
#define LL_SFUNCALL16(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,16,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16))
#define LL_SFUNCALL17(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,17,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17))
#define LL_SFUNCALL18(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,18,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18))
#define LL_SFUNCALL19(symb,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19)\
   LO_FUNCALL(((LL_symbol)symb)->fval,\
             (((LL_symbol)symb)->fval,19,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19))

/* a little explantation about symbol checking-in:

   1- we never check in the symbol during image building, as we have
   no clue which library we are elaborating (reminder: when checking
   in a root, we asume it belongs to the elaborating library, and use
   that info to properly relocate it when restoring the image). The
   static variable reference to the symbol will therefore go
   unnoticed; but that's ok, since we asume the symbol defines a
   function, therefore is not GC-able.

   2- naturally, the first call after image restoration will retrieve
   the symbol for the second time (since static = 0 is then in effect
   again).

   3- When we no longer build an image, we may be developping. And
   then we may (unlikely today) end up undefining a function. To
   prevent the GC from collecting that symbol (and then having a
   random reference in the heap), we register that symbol. Of course,
   if someday it is definite that there is no way to undef a symbol,
   we may drop that checking in business. */

/* call the Talk function if defined, or return a predefined value if not */
#define LL_DEFINTERN0_IFDEF(intern_function_name,intern_symbol_string, ifndefval)	\
LL_object intern_function_name()					\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  if (intern_symbol->fval != ll_undefined_function)			\
	  return(LL_SFUNCALL0(intern_symbol));				\
  else    return ifndefval;}

#define LL_DEFINTERN0(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name()					\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL0(intern_symbol)); }

#define LL_DEFINTERN1(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1)					\
LL_object arg1;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL1(intern_symbol,arg1)); }

#define LL_DEFINTERN2(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2)					\
LL_object arg1,arg2;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL2(intern_symbol,arg1,arg2)); }

#define LL_DEFINTERN3(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3)					\
LL_object arg1,arg2,arg3;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL3(intern_symbol,arg1,arg2,arg3)); }

#define LL_DEFINTERN4(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4)					\
LL_object arg1,arg2,arg3,arg4;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL4(intern_symbol,arg1,arg2,arg3,arg4)); }

#define LL_DEFINTERN5(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5)					\
LL_object arg1,arg2,arg3,arg4,arg5;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL5(intern_symbol,arg1,arg2,arg3,arg4,arg5)); }

#define LL_DEFINTERN6(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL6(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6)); }

#define LL_DEFINTERN7(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL7(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7)); }

#define LL_DEFINTERN8(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL8(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8)); }

#define LL_DEFINTERN9(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL9(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9)); }

#define LL_DEFINTERN10(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL10(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10)); }

#define LL_DEFINTERN11(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL11(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11)); }

#define LL_DEFINTERN12(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL12(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12)); }

#define LL_DEFINTERN13(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL13(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13)); }

#define LL_DEFINTERN14(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL14(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14)); }

#define LL_DEFINTERN15(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL15(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15)); }

#define LL_DEFINTERN16(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL16(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16)); }

#define LL_DEFINTERN17(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16,arg17)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16,arg17;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL17(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16,arg17)); }

#define LL_DEFINTERN18(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16,arg17,arg18)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16,arg17,arg18;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL18(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16,arg17,arg18)); }

#define LL_DEFINTERN19(intern_function_name,intern_symbol_string)	\
LL_object intern_function_name(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16,arg17,arg18,arg19)					\
LL_object arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16,arg17,arg18,arg19;								\
{ static LL_symbol intern_symbol = 0 ;					\
  if (!intern_symbol) {							\
	  if (!ilt_building_image)					\
	  (void)LL_CHECK_IN_ROOTS(&intern_symbol,ILT_DATA|ILT_PRIV);	\
	  intern_symbol = ilt_string2symbol(intern_symbol_string);}	\
  return(LL_SFUNCALL19(intern_symbol,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,arg13,arg14,arg15,arg16,arg17,arg18,arg19)); }

#if defined(ILT_CC_SHARP_GLUE)
#define LL_DEFINTERN(intern_function_name,intern_symbol_string,argc)	\
        LL_DEFINTERN##argc(intern_function_name,intern_symbol_string)
#else
/* No space allowed at the beginning of argc ! */
#define LL_DEFINTERN(intern_function_name,intern_symbol_string,argc)    \
        LL_DEFINTERN/**/argc(intern_function_name,intern_symbol_string)
#endif

#define LL_FVAL(sym)((sym)->fval)

/* \\ should become LLO , or quit casting */	
#define LL_SYMBOL_CODE(sym)(((sym)->fval)->code)

				/* parameter handling */

#define LL_POP_ARG(type)va_arg(argument_vector, type);

#define LL_MAKE_REST(i,ltemp,nb_var,formal){ltemp=make_raw_list(nb_var);formal=(LL_object)ltemp;	for (i= nb_var; i > 0; i--){LL_SET_CAR(ltemp,va_arg(argument_vector, LL_object));ltemp= (LL_cons)LL_CDR(ltemp);}}

#define LL_MAKE_MULTIPLE(i,nb_var,formal){formal=ll_push_multiple_frame(nb_var); for (i= 0; i < nb_var; i++){ll_set_multiple_nth(formal, LL_INT2FIX(i), va_arg(argument_vector, LL_object));}}

LL_EXTERNAL_FUNCTION(LL_cons  make_raw_list,
		     (VSLONG length));


/* debugging information */

				/* closure handling */

				/* until pp creates binding, use cons */
#define LLABC_CREATE_BINDING(name) name=LLO_MAKE_CONS(name, ll_nil)
#define LLABC_CREATE_UNINITIALIZED_BINDING(name) name=LLO_MAKE_CONS(LLO_UNDEF(), ll_nil)
				/* var <- nth_binding(fnobj,index) */
#define LLABC_GET_BINDING(var,fnobj,index) var= LLI_FUNCTION_SYSTEM_FIELD((LL_function)fnobj,index)
#define LLABC_PUT_BINDING(var,fnobj,index) LLI_SET_FUNCTION_SYSTEM_FIELD((LL_function)fnobj,index,var)
#define LLABC_CVAR(binding)LLO_CAR(binding)
#define LLABC_COPY_FUNCTION(function)abc_copy_function((LL_function) function)
LL_EXTERNAL_FUNCTION(LL_object  abc_copy_function,
		     (LL_function template));

#define LLABC_STATIC_INIT(symbol,binding_pointer) binding_pointer=(LL_object)ll_static_addr(symbol)
#define LLABC_STATIC(binding_pointer) *((LL_object *)(binding_pointer))
#define LLABC_DSTATIC(binding_pointer) *((LL_object *)ilt_check_static(binding_pointer))
LL_EXTERNAL_FUNCTION(LL_object ll_static_addr, (LL_object symbol));

/* \\ For compatibility with old code */

#define LLABC_SVAR(binding_pointer)*(binding_pointer)
#define LLABC_SET_STATIC_ADDR(symbol, binding_pointer) (LL_CHECK_IN_ROOTS(&binding_pointer),binding_pointer= (LL_object *)ll_static_addr(symbol))

/* ---------------------------------- */

LL_EXTERNAL_FUNCTION(LL_object *ilt_check_static, ((LL_object *) binding_ptr));

#define LLO_COPY_STRING_TO_FLOAT(s,f)	(ll_copy_string_to_float(s,f),ll_nil)
#define LLO_COPY_FLOAT_TO_STRING(f,s)	(ll_copy_float_to_string(f,s),ll_nil)


#define LLO_CALLEXTERN_0(code_address)\
   (((LL_object (*)())code_address)())
#define LLO_CALLEXTERN_1(code_address,a1)\
   (((LL_object (*)())code_address) (a1))
#define LLO_CALLEXTERN_2(code_address,a1,a2)\
   (((LL_object (*)())code_address)(a1,a2))
#define LLO_CALLEXTERN_3(code_address,a1,a2,a3)\
   (((LL_object (*)())code_address)(a1,a2,a3))
#define LLO_CALLEXTERN_4(code_address,a1,a2,a3,a4)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4))
#define LLO_CALLEXTERN_5(code_address,a1,a2,a3,a4,a5)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5))
#define LLO_CALLEXTERN_6(code_address,a1,a2,a3,a4,a5,a6)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6))
#define LLO_CALLEXTERN_7(code_address,a1,a2,a3,a4,a5,a6,a7)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7))
#define LLO_CALLEXTERN_8(code_address,a1,a2,a3,a4,a5,a6,a7,a8)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8))
#define LLO_CALLEXTERN_9(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9))
#define LLO_CALLEXTERN_10(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10))
#define LLO_CALLEXTERN_11(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11))
#define LLO_CALLEXTERN_12(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12))
#define LLO_CALLEXTERN_13(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13))
#define LLO_CALLEXTERN_14(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14))
#define LLO_CALLEXTERN_15(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15))
#define LLO_CALLEXTERN_16(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16))
#define LLO_CALLEXTERN_17(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17))
#define LLO_CALLEXTERN_18(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18))
#define LLO_CALLEXTERN_19(code_address,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19)\
   (((LL_object (*)())code_address)(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19))




/*******************************************************************

 llndbm.h: macro for defextern hfile functions.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llndbm.h,v 1.4 1996/01/12 21:16:43 v16admin Exp $
 ---------------------------------------------------------------------

*********************************************************************/

#define LLO_LL_DBM_CREATE(s)	((LL_object) ll_dbm_create((char *) (s)))
#define LLO_LL_DBM_OPEN_WRITE(s)	((LL_object) ll_dbm_open_write(s))
#define LLO_LL_DBM_OPEN_READ(s)	((LL_object) ll_dbm_open_read(s))
#define LLO_LL_DBM_CLOSE(p)	((LL_object) ll_dbm_close(p))
#define LLO_LL_DBM_INSERT_VALUE(p,sk,sv)	((LL_object) ll_dbm_insert_value(p,sk,sv))
#define LLO_LL_DBM_REPLACE_VALUE(p,sk,sv)	((LL_object) ll_dbm_replace_value(p,sk,sv))
#define LLO_LL_DBM_FETCH(p,sk)	((LL_object) ll_dbm_fetch(p,sk))
#define LLO_LL_DBM_DELETE(p,sk)	((LL_object) ll_dbm_delete(p,sk))
#define LLO_LL_DBM_MAP(p,f)	((LL_object) ll_dbm_map(p,f))
/*********************************************************************

 lldataloc.h: macro for locators

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/lldataloc.h,v 1.10 1996/01/12 21:16:43 v16admin Exp $
 ---------------------------------------------------------------------

************************************************************************/

typedef struct {
	long version;
	char *private_bss;
	char *exported_bss;
	char *private_data;
	char *exported_data;
	char *private_text;
	char *exported_text;
	char *name; } LL_library_location;

/* each library L must be linked with (first) aaL.o and (last) zzL.o,
   defining ll_L_begin_locator and ll_L_end_locator using the macro
   locator below */

/* split up for the use of commonrt */

#define locator1(locator_fn, locator_name, locator_private_bss, locator_exported_bss, locator_private_data, locator_exported_data, locator_private_text, locator_exported_text)			\
static long locator_private_bss;				\
LL_EXTERNAL_STATIC(long locator_exported_bss);		\
static long locator_private_data = 1;			\
LL_EXTERNAL_STATIC_INIT(long locator_exported_data, 1);	\
static void locator_private_text () {}			\
void locator_exported_text () {}

#define locator2(locator_fn, locator_name, locator_private_bss, locator_exported_bss, locator_private_data, locator_exported_data, locator_private_text, locator_exported_text)			\
void locator_fn (at)					\
LL_library_location *at;				\
{ at->version       = 0;				\
  at->private_bss   = (char *)&locator_private_bss;	\
  at->exported_bss  = (char *)&locator_exported_bss;	\
  at->private_data  = (char *)&locator_private_data;	\
  at->exported_data = (char *)&locator_exported_data;	\
  at->private_text  = (char *)locator_private_text;	\
  at->exported_text = (char *)locator_exported_text;	\
  at->name          = locator_name; }

#define locator(locator_fn, locator_name, locator_private_bss, locator_exported_bss, locator_private_data, locator_exported_data, locator_private_text, locator_exported_text)			\
locator1(locator_fn, locator_name, locator_private_bss, locator_exported_bss, locator_private_data, locator_exported_data, locator_private_text, locator_exported_text)			\
locator2(locator_fn, locator_name, locator_private_bss, locator_exported_bss, locator_private_data, locator_exported_data, locator_private_text, locator_exported_text)

/* flagto pass as second argument to elaboration function to make them
   call begin&end locator functions */
#define LL_CALL_LOCATORS 0x123
/*****************************************************************************

 llcpp.h: Talk interface for C++ objects

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work.haible/talk/common/RCS/llcpp.h,v 1.5 1996/03/04 20:47:11 haible Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

extern void (**ilt_find_callback())();
extern void (**ilt_find_compiled_callback())();
extern LL_object ilt_callextern_multiple();

#define LLO_CALLEXTERN_MULTIPLE(f,n,aiv,acv,ri,rc,m)  \
  (ilt_callextern_multiple((LL_function)(f),(LL_object)(n),(LL_object*)(aiv),(LL_object*)(acv),(LL_object)(ri),(LL_object)(rc),(LL_multiple_frame)(m)))

/*****************************************************************************

 llendmod.h: header file prior after having included any external interface
  	     for the current module or an imported module.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1989-1996 by ILOG
 $Header: /nfs/talk/work/talk/common/RCS/llendmod.h,v 3.3 1996/01/12 21:16:43 v16admin Exp $
 ----------------------------------------------------------------------
 ****************************************************************************/

#undef LL_EXTERNAL_STATIC
#undef LL_EXTERNAL_STATIC_INIT
#undef LL_EXTERNAL_STATIC_DIM
#undef LL_EXTERNAL_STATIC_DIM_INIT
#undef LL_EXTERNAL_FUNCTION
#undef LL_COMMONRT_EXTERNAL
