# Setup for ILOG TALK
# -------------------
#
# Operating system: Linux 1.2
# Hardware:         i386
# C compiler:       GNU C
# C++ compiler:     GNU C++ 2.7.x
#
# This file can be either included in your .profile, or
# read at the shell prompt with:
#
#		$ . iltsetup.sh
#
# NOTE: This file may require some changes before using it.
#       Please read carefuly the following comments.

# Change the next line to match your local installation
# directory for ILOG TALK.
ILT_DIR=/usr/ilog/talk32

# If you don't have ILOG VIEWS, or if the ILVHOME variable
# is already set by your .profile, remove the next line.
# Otherwise, change it to match your local installation directory
# for ILOG VIEWS.
ILVHOME=/usr/ilog/views

# If you already have an Emacs in your PATH and you don't
# want to use the one provided with ILOG TALK, remove the
# next line.
PATH=$ILT_DIR/../xemacs13/bin/i486-unknown-linuxelf:"$PATH"

# The rest of this file doesn't have to be changed.
PATH=$ILT_DIR/talk/i86_linux1.2_gnu2.7:"$PATH"
LD_LIBRARY_PATH=$ILT_DIR/lib/i86_linux1.2_gnu2.7:"$LD_LIBRARY_PATH"
if [ "$ILVHOME" != "" ]
then
  LD_LIBRARY_PATH=$ILVHOME/lib/i86_linux1.2_gnu2.7:"$LD_LIBRARY_PATH"
fi
export ILT_DIR ILVHOME PATH LD_LIBRARY_PATH

