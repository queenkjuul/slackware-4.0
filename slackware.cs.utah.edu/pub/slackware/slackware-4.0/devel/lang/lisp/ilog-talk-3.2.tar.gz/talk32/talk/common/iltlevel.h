/**********************************************************************
 *
 * Definitions for distribution levels.
 *
 **********************************************************************/

/*
 * After modifying this file, do:
 * $ ilt-install-all -l work          if it affects work
 * $ ilt-bind-cplib                   if it affects iltcplib
 * $ ilt-bind-views                   if it affects iltviews
 */


#if !defined(_ILT_ILTLEVEL_INCL)
#define _ILT_ILTLEVEL_INCL

#include <iltleveldef.h>

/*
 * Product versions
 */

#define ILT_VIEWS_VERSION		2.21

#define ILT_XEMACS_VERSION		19.11

/* Talk version */
#define ILT_VERSION_DIR			talk32
#define ILT_VERSION_N			3.2
#define ILT_VERSION_S			"ILOG Talk version 3.2"
/* Also change talk/src/iltprodae.t and recompile it. */


/*
 * Root directory for Views
 */

#define ILT_VIEWS_ROOT_DIR		/usr/ilog/views
#define ILT_WIN_VIEWS_ROOT_DIR		c:\\usr\\ilog\\views

/* Current root directory for Views ($ILVHOME), at ILOG only */

#define ILT_LOCAL_VIEWS_ROOT_DIR	/nfs/views/distrib2.21
#define ILT_WIN_SH_VIEWS_ROOT_DIR	z:\\\\nfs\\\\views\\\\distrib2.21

/* Current root directory for Views' AIX libraries. */

#if !defined(ILT_LEV_DISTRIB)
/* In this directory we keep local copies of lib/rs6000/?* and shared libs. */
#define ILT_LOCAL_AIX_VIEWS_ROOT_DIR	<$ILT_ROOT_DIR$>/iltviews/views
#else
/* During distrib we make a symbolic link on the rs6000 machine. */
#define ILT_LOCAL_AIX_VIEWS_ROOT_DIR	<$ILT_VIEWS_ROOT_DIR$>
#endif


/*
 * Root directory for Talk
 */

#define ILT_WORK_ROOT_DIR		/nfs/talk/work.${LOGNAME-$USER}
#define ILT_WIN_WORK_ROOT_DIR		t:\\work
#define ILT_WIN_SH_WORK_ROOT_DIR	t:\\\\work

#define ILT_CURRENT_ROOT_DIR		/nfs/talk/current/<$ILT_VERSION_DIR$>
#define ILT_WIN_CURRENT_ROOT_DIR	t:\\current\\<$ILT_VERSION_DIR$>
#define ILT_WIN_SH_CURRENT_ROOT_DIR	t:\\\\current\\\\<$ILT_VERSION_DIR$>

#define ILT_DISTRIB_ROOT_DIR		/usr/ilog/<$ILT_VERSION_DIR$>
#define ILT_WIN_DISTRIB_ROOT_DIR	t:\\distribution\\<$ILT_VERSION_DIR$>
#define ILT_WIN_SH_DISTRIB_ROOT_DIR	t:\\\\distribution\\\\<$ILT_VERSION_DIR$>

/* Current distrib directory for Talk, at ILOG only */
#define ILT_LOCAL_DISTRIB_ROOT_DIR	/nfs/talk/distribution/<$ILT_VERSION_DIR$>
#define ILT_TAR_ROOT_DIR		/nfs/talk/distribution.tar/<$ILT_VERSION_DIR$>

#if defined(ILT_LEV_WORK)
#	define	ILT_ROOT_DIR		ILT_WORK_ROOT_DIR
#	define	ILT_WIN_ROOT_DIR	ILT_WIN_WORK_ROOT_DIR
#	define	ILT_WIN_SH_ROOT_DIR	ILT_WIN_SH_WORK_ROOT_DIR
#	define  ILT_LEV_DIR		work
#	define	ILT_LEV_PREV
#endif

#if defined(ILT_LEV_CURRENT)
#	define	ILT_ROOT_DIR		ILT_CURRENT_ROOT_DIR
#	define	ILT_WIN_ROOT_DIR	ILT_WIN_CURRENT_ROOT_DIR
#	define	ILT_WIN_SH_ROOT_DIR	ILT_WIN_SH_CURRENT_ROOT_DIR
#	define  ILT_LEV_DIR		current
#	define	ILT_LEV_PREV		work
#endif

#if defined(ILT_LEV_DISTRIB)
#	define	ILT_ROOT_DIR		ILT_DISTRIB_ROOT_DIR
#	define	ILT_WIN_ROOT_DIR	ILT_WIN_DISTRIB_ROOT_DIR
#	define	ILT_WIN_SH_ROOT_DIR	ILT_WIN_SH_DISTRIB_ROOT_DIR
#	define  ILT_LEV_DIR		distrib
#	define	ILT_LEV_PREV		current
#endif


/*
 * Product list
 */

#define ILT_LEV_PRODUCTS		talk cppparse iltcplib iltviews


/*
 * Build command
 */

#define ILT_LEVEL_BUILD_CMD		<$ILT_ROOT_DIR$>/bin/build
#if defined(ILT_LEV_DISTRIB)
#define ILT_LEVEL_DISTCLEAN_CMD		<$ILT_ROOT_DIR$>/bin/distclean
#else
#define ILT_LEVEL_DISTCLEAN_CMD
#endif

#endif /* !defined(_ILT_ILTLEVEL_INCL) */
