/*****************************************************************************

 shape.h: Header file for the shape example.

 ----------------------------------------------------------------------
 This file is part of ILOG Talk.
 Inquiries to ILOG S.A.
              9 rue de Verdun, BP 85,
              94253 Gentilly Cedex, France.

 Copyright (c) 1993-1996 by ILOG
 $Header: /nfs/talk/work/talk/contrib/shape/include/RCS/shape.h,v 1.3 1996/07/15 16:09:46 v16admin Exp $
 ----------------------------------------------------------------------
******************************************************************************/

// missing:
//   typedef foo* NewType;
//   overload on int & long

typedef void (*Callback)(void*);
typedef short Delta;
enum Color { Black, White, Red, Green, Blue };
typedef int Boolean;
#define True 1
#define False 0

class Point
{
private:
  int _x;
  int _y;
public:
  int x() const { return _x; }
  void x(int newx) { _x = newx; }
  int y() const { return _y; }
  void y(int newy) { _y = newy; }
  Point(int x = 0, int y = 0) : _x(x), _y(y) {}
};

class Rect
{
private:
  Point upper_left;
  Point lower_right;
public:
  Point& upperLeft() { return upper_left; }
  Point& lowerRight() { return lower_right; }
  Boolean intersects(Rect& r);
  Rect(Point& ul, Point& lr);
  Rect(int ulx, int uly, int lrx, int lry);
};

class Shape
{
private:
  void* client_data;
public:
  // public data.
  Point* center;
  Color color;

  // dynamic typing.
  virtual const char* typeOf() = 0;

  // geometry functions.
  virtual void draw() = 0;
  void move(Delta dx, Delta dy);
  void move(const Point& p);
  virtual Rect* findBBox(Boolean& exact) = 0;
  virtual void scale(double factor) = 0;

  // manage callback & client data.
  void setClientData(void* data) { client_data = data; }
  void* getClientData() { return client_data; }
  void activate(Callback cb) { cb(client_data); }

  // create and destroy.
  Shape(Point* ctr, Color clr = Black) : center(ctr), color(clr) {}
  ~Shape() { delete center; }
};

class Square : public Shape
{
public:
  int sideLen;
  virtual const char* typeOf() { return "Square"; }
  virtual void draw();
  virtual Rect* findBBox(Boolean& exact);
  virtual void scale(double factor);
  Square(int len, Point* c, Color a = Black)
   : Shape(c, a), sideLen(len) {}
};

class Circle : public Shape
{
public:
  int diameter;
  virtual const char* typeOf() { return "Circle"; }
  virtual void draw();
  virtual Rect* findBBox(Boolean& exact);
  virtual void scale(double factor);
  Circle(int diam, Point* c, Color a = Black)
   : Shape(c, a), diameter(diam) {}
};

extern Shape *hilightedShape;

void initSystem(char* display, char* title = 0);
