// ----------------------------------------------------------------------
// This file is part of ILOG Talk.
// Inquiries to ILOG S.A.
//              9 rue de Verdun, BP 85,
//              94253 Gentilly Cedex, France.
//
// Copyright (c) 1995-1996 by ILOG
// ----------------------------------------------------------------------
//

#if !defined(ILT_BINDING_TIME)

#include <iltsystem.h>

// Later on, we do the binding with the real <iostream.h>.

#include <iostream.h>

#if defined(ILT_CPP_MSVC)
// MSVC: 8+3 character filename braindamage
#include <strstrea.h>
#else
#include <strstream.h>
#endif

#else // defined(ILT_BINDING_TIME)

// At binding time, we use only a portable subset of <iostream.h>.
// This helps keep the applications portable.


// Based on "The C++ Programming Language, 2nd edition".

class istream;
class ostream;

// 10.4.3, p. 349

typedef long streampos;
typedef long streamoff;

// 10.4.1, p. 337

class ios {
public:
	ostream* tie (ostream* s);
	ostream* tie ();
	int width (int w);
	int width () const;
	char fill (char);
	char fill () const;
	long flags (long f);
	long flags () const;
	long setf (long setbits, long field);
	long setf (long);
	long unsetf (long);
	int precision (int);
	int precision () const;
	int rdstate () const;
	int eof () const;
	int fail () const;
	int bad () const;
	int good () const;
	void clear (int i = 0);
	// 10.4.3, p. 349
	enum seek_dir { beg=0, cur=1, end=2 };
private:
	// Constructor, destructor, copy constructor, assignment are not public.
	ios ();
	~ios ();
	ios (const ios&);
	ios& operator = (const ios&);
};

// 10.3.1, p. 330

class istream : public virtual ios {
public:
	istream& operator>> (char*);
//	istream& operator>> (signed char *);
	istream& operator>> (unsigned char *);
	istream& operator>> (char&);
//	istream& operator>> (signed char &);
	istream& operator>> (unsigned char &);
	istream& operator>> (short&);
	istream& operator>> (unsigned short &);
	istream& operator>> (int&);
	istream& operator>> (unsigned int &);
	istream& operator>> (long&);
	istream& operator>> (unsigned long &);
	istream& operator>> (float&);
	istream& operator>> (double&);
	// 10.4.4, p. 350
	int peek ();
	istream& putback (char);
	istream& seekg (streampos);
	istream& seekg (streamoff, seek_dir);
	streampos tellg ();
private:
	// Constructor, destructor, copy constructor, assignment are not public.
//	istream ();
//	~istream ();
//	istream (const istream&);
//	istream& operator = (const istream&);
};

// 10.2.1, p. 328

class ostream : public virtual ios {
public:
	ostream& operator<< (const char *);
	ostream& operator<< (char);
	ostream& operator<< (short);
	ostream& operator<< (int);
	ostream& operator<< (long);
	ostream& operator<< (double);
	ostream& operator<< (const void *);
	// 10.4.3, p. 349
	ostream& flush ();
	ostream& seekp (streampos);
	ostream& seekp (streamoff, seek_dir);
	streampos tellp ();
private:
	// Constructor, destructor, copy constructor, assignment are not public.
//	ostream ();
//	~ostream ();
//	ostream (const ostream&);
//	ostream& operator = (const ostream&);
};

// 10.5.3, p. 354

class streambuf {
public:
private:
	// Constructor, destructor, copy constructor, assignment are not public.
	streambuf ();
	~streambuf ();
	streambuf (const streambuf&);
	streambuf operator = (const streambuf&);
};

// 10.5.2, p. 353

class istrstream : public istream {
public:
	istrstream (char *);
	istrstream (char *, int);
	istrstream (const char *);
	istrstream (const char *, int);
};

class ostrstream : public ostream {
public:
	ostrstream (char *, int);
};

#endif // defined(ILT_BINDING_TIME)

