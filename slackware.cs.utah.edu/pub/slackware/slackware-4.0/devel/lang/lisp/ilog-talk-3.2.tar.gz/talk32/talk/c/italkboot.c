#include <llincludes.h>

#ifdef ILT_TALK_PORT_SPARC_5_3_0
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_SPARC_5_4_0
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_SPARC_5_GNU
#define IMAGE_LENGTH 1840000
#else
#ifdef ILT_TALK_PORT_SPARC_4_2_1
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_SPARC_4_3_0
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_SPARC_4_4_0
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_SPARC_4_GNU
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_RS6000
#define IMAGE_LENGTH 1910000
#else
#ifdef ILT_TALK_PORT_HP700
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_HP_10
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_ALPHA_3
#define IMAGE_LENGTH 3780000
#else
#ifdef ILT_TALK_PORT_SGI_5_2_3
#define IMAGE_LENGTH 1830000
#else
#ifdef ILT_TALK_PORT_SGI_5_3_4
#define IMAGE_LENGTH 1830000
#else
#ifdef ILT_TALK_PORT_I86_LINUX1_2_GNU2_7
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_I86_SUNOS5_3_0
#define IMAGE_LENGTH 1770000
#else
#ifdef ILT_TALK_PORT_MSVC32
#define IMAGE_LENGTH 1910000
#else
#ifdef ILT_TALK_PORT_MSVC4
#define IMAGE_LENGTH 1910000
#else
#define IMAGE_LENGTH 1770000
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#define USE_IMAGE 1

LL_object  llo_libiltrt_elaborate_libiltrt();
LL_object  llo_libilteval_elaborate_libilteval();
LL_object  llo_libiltdev_elaborate_libiltdev();
static LL_object  ll_initapp()
{
  elaborate_one_module ("libiltrt", llo_libiltrt_elaborate_libiltrt, 0x31bf7d02);
  elaborate_one_module ("libilteval", llo_libilteval_elaborate_libilteval, 0x31bf7d0d);
  elaborate_one_module ("libiltdev", llo_libiltdev_elaborate_libiltdev, 0x31bf7d17);
  return 0;
}

LL_object  llo_iltrune_elaborate_iltrune();
static LL_object  ll_runapp()
{
  elaborate_one_module ("iltrune", llo_iltrune_elaborate_iltrune, 0x31bf7d54);
  return 0;
}
static char *message="Welcome to ILOG Talk.";
LL_object llo_libiltcrt_elaborate_libiltcrt();
/* This is the memory image vector touched to make image. */
#if defined(ILT_OS_WIN32)
static union
       { char as_a_string [IMAGE_LENGTH
                           + PRE_STATIC_HEAP_BUFFER_SIZE
                           + POST_STATIC_HEAP_BUFFER_SIZE];
         long for_alignment;
       }
  image
#if USE_IMAGE
  = { IMAGE_MARK } ;
#else
/* No need to initialize; this will make the executable file smaller */
  ;
#endif
#else
static struct
       { long for_alignment;
         char as_a_string [IMAGE_LENGTH
                           + PRE_STATIC_HEAP_BUFFER_SIZE
                           + POST_STATIC_HEAP_BUFFER_SIZE];
       }
  image
#if USE_IMAGE
  = { 0, IMAGE_MARK } ;
#else
/* No need to initialize; this will make the executable file smaller */
  ;
#endif
#endif

#define LL_LIBLOCC 4
int IltInit (argc, argv, envp)
  int argc; char **argv, **envp;
{
  int ll_liblocc=0;
  /* ll_liblocv can't be initialized statically, because this
     raises an obscure error with SunOS 4.1 linker. */
  LL_library_locator ll_liblocv[LL_LIBLOCC+1];
  /* +1 to avoid size zero */
  ll_liblocv[ll_liblocc++]=llo_libiltcrt_elaborate_libiltcrt;
  ll_liblocv[ll_liblocc++]=llo_libiltrt_elaborate_libiltrt;
  ll_liblocv[ll_liblocc++]=llo_libilteval_elaborate_libilteval;
  ll_liblocv[ll_liblocc++]=llo_libiltdev_elaborate_libiltdev;
  return ll_application_main (USE_IMAGE, IMAGE_LENGTH
                              + PRE_STATIC_HEAP_BUFFER_SIZE
                              + POST_STATIC_HEAP_BUFFER_SIZE,
                              (Image *)image.as_a_string,
                              ll_initapp, ll_runapp, message,
                              argc, argv, envp,
                              ll_liblocc, ll_liblocv,
                              PRE_STATIC_HEAP_BUFFER_SIZE,
                              POST_STATIC_HEAP_BUFFER_SIZE);
}

