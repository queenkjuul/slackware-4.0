/* sizes.h -- constants defining the numeric base for Intercal variations */

extern int Base;
extern int Small_digits;
extern int Large_digits;
extern unsigned int Max_small;
extern unsigned int Max_large;

/* sizes.h ends here */
