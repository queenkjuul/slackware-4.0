
                       Tix Documentation Master Index
                                      
     _________________________________________________________________
                                      
     LICENSE TERMS PLEASE READ THE FILE [1]license.terms BEFORE YOU DO
                                  ANYTHING
                                      
     _________________________________________________________________
                                      
   Some HTML documentation files are currently missing. Please bear with
   this 
   
  Table of Contents
  
    1. [2]What is Tix?
    2. [3]About This File 
    3. [4]Index of Tix Documentation 
       
     _________________________________________________________________
                                      
  What is Tix? Tix is a programming library for the TK toolkit. A Brief
  description of the Tix library is in the file [5]ABOUT.html.
    ________________________________________________________________________
                                        
  About This File This file is the master index of all the off-line
  documentation included in this package. For the on-line documentation of Tix
  served in the World Wide Web, please visit the Tix Home Page at
  [6]http://www.xpi.com/tix/ .
  
  The file README.html is in HTML format and can be read in a HTML browser. If
  you do not have an HTML browser, each HTML document included in this package
  has a plain text version. For example, the plain text version of README.html
  is [7]README.txt.
  
    ________________________________________________________________________
                                        
  Index of Tix Documentation
     * A brief descriptions of what Tix can be found in the file
       [8]ABOUT.html.
     * The version number of this Tix release is in the file [9]Version.
     * Release Notes on this particular release version of Tix are in the
       file [10]docs/Release.html.
     * The Installation Notes in the file [11]docs/Install.html helps you
       get started with the Tix software. It also tells you what are the
       [12]requirements for this version of Tix.
     * The Frequent Asked Questions about Tix are in the file
       [13]docs/FAQ.html.
     * Changes made to Tix are recorded in the file
       [14]docs/Changes.html.
     * The Tix package include some useful tools. They are described in
       the file [15]tools/README.html.
     * Tix manual pages in HTML format can be found in the file
       [16]docs/ManPages.html.
     * Some notes about porting Tix to various platforms from various
       contributors are in [17]docs/Porting.html.
         _____________________________________________________________
                                        
     * Files Relevant to the Development of Tix 
          + A list of things that need to be done, plus bug reports from
            Tix users are in the file [18]docs/ToDo.html .
          + Bugs that has been fixed are in: [19]docs/BugsFixed.html .
       
    ________________________________________________________________________
                                        
  Last modified Apr 23 23:04 

References

   1. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/license.terms
   2. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/README.html#whatis
   3. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/README.html#about
   4. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/README.html#index
   5. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/ABOUT.html
   6. http://www.xpi.com/tix/
   7. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/README.txt
   8. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/ABOUT.html
   9. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/Version
  10. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/docs/Release.html
  11. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/docs/Install.html
  12. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/docs/Install.html#requirements
  13. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/docs/FAQ.html
  14. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/docs/Changes.html
  15. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/tools/README.html
  16. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/docs/ManPages.html
  17. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/docs/Porting.html
  18. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/docs/ToDo.html
  19. file://localhost/mnt/vfs/ioi/src/Tix4.1a3/docs/BugsFixed.html
