************************************************************************
           Welcome to Irie Pascal for Linux Version 1.00
************************************************************************

Please make sure that you have the following files:

Documentation:
--------------
readme.txt    - This file
user.txt      - The Irie Pascal User's Guide
progref.txt   - The Irie Pascal Programmer's Reference Manual
orderus.txt   - The Order Form for US dollar Registrations
orderca.txt   - The Order Form for Canadian dollar Registrations
orderuk.txt   - The Order Form for UK pound Registrations
shareware.txt - Describes the shareware concept (derived from documentation
                produced by the Association of Shareware Professionals (ASP)).
                NOTE: I am not a member of this association.

Programs:
---------
ipc       - Irie Pascal Compiler for Linux
ivm       - Irie Virtual Machine Interpreter for Linux

Sample programs:
----------------
add.pas         - A simple program that computes and displays the sum
                        of the command-line arguments passed to it.
append.pas      - Appends two files together, writting the appended files
                  out to a third file.
args.pas        - Displays the number of command-line arguments passed to it.
ascii.pas       - This program displays the ASCII table.
bad.pas         - This program is referred to in the Users Guide to
                  illustrate how the Compiler handles error messages.
batch.pas       - A very primitive command processor.
calc.pas        - A desktop calculator.
cat.pas         - Concatenates one or more files to the standard output
date.pas        - Displays the system date and day.
dirpas.pas      - A simple program which lists all the *.pas files in
                  the current directory.
hello.pas       - The classic hello world program.
hex.pas         - Dsiplays the contents of a file in hexadecimal
lines.pas       - Counts the number of lines in one or more text files
lowname.pas     - Converts a file's name to lowercase
notstric.pas    - A simple program that illustrates the dangers of
                  turning strict checking off.
primes.pas      - A simple prime number generating program. I used this
                  program to help me get an idea of how much slower
                  Irie Pascal programs are than native code programs.
prime2.pas      - Another simple prime number generating program. The
                  interesting thing about this program is that is uses
                  the built-in 'list' type.
rename.pas      - Renames a file
strange.pas     - A non-sensical program referred to in the Users Guide
                  to illustrate how program parameters are handled.
type.pas        - A simple program which behaves like the 'type' command
                  (i.e. it echoes a file to the screen).
type2.pas       - A simple program which behaves like the 'type' command
                  (i.e. it echoes a file to the screen).
vowels.pas      - A simple vowel counting program which illustrates one
                  method of handling program arguments using Irie Pascal.

The sample programs are provided mostly to help you veryify that
Irie Pascal has been installed correctly. You may however find a few of
the sample programs like split.pas, lines.pas, calc.pas or ascii.pas useful.
Irie Pascal comes with the following sample programs.
