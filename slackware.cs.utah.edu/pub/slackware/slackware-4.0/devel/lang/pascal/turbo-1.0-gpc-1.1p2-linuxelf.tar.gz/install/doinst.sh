( cd usr/bin ; rm -rf pc )
( cd usr/bin ; ln -sf gpc pc )
