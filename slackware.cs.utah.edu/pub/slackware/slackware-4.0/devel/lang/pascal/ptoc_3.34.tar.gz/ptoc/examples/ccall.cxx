#include "ptoc.h"

typedef array<1,64,char> smallstr;

extern "C" void foo(integer* x, char*  a);  



extern "C" void sprintf1(char*  s,
                      char* format); 


void main1(conf_array<char> a)
{
   integer i;
   smallstr s;

   const int lo = a.low;
   const int hi = a.high;
   foo(&i, a.body());
   sprintf1(s.body(), lpsz(a), i);
   sprintf1("s", "a", i);
}

