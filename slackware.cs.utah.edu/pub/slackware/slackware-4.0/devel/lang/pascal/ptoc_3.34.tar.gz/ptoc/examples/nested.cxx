#include "ptoc.h"

integer f1();
static integer f2();

static void f3()
{
   f3();
   f2();
}    /* f3 */


static char f4()
{
   char f4_result;
   f4();
   f2();
   return f4_result;
}    /* f4 */


static integer f2()

{
   integer f2_result;
   f1();
   f3();
   f4();
   return f2_result;
}    /* f2 */

integer f1()

{
   integer f1_result;
   f2();
   return f1_result;
}    /* f1 */
