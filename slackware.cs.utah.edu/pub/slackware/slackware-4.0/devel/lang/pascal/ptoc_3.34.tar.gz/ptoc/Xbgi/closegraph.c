/*
 * $Id: closegraph.c,v 0.1 1993/12/10 00:10:55 king Exp king $
 * Shuts down the graphics system.
 *
 * $Log: closegraph.c,v $
 * Revision 0.1  1993/12/10  00:10:55  king
 * Initial version.
 *
 */
#include "graphics.h"

void closegraph(void)
{
        free(vga_palette);
        free(pages - visual_page);	/* check this for memory leaks */
        XFreeGC(dpy, gc);
        XFreeGC(dpy, fill_gc);
        XDestroyWindow(dpy, window);
        XCloseDisplay(dpy);
}
