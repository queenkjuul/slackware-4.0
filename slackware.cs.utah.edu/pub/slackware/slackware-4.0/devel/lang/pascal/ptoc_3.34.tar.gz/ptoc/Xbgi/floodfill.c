/*
 * $Id: floodfill.c,v 0.1 1993/12/10 00:13:14 king Exp king $
 * Flood-fills a bounded region.
 *
 * $Log: floodfill.c,v $
 * Revision 0.1  1993/12/10  00:13:14  king
 * Initial version.
 *
 */
#include "graphics.h"

void floodfill(int x, int y, int border)
{
/* 
 * This function is not currently implemented due to insufficient knowledge of
 * how floodfill works exactly.
 */
}
