#include "ptoc.h"

typedef char smallstr[64];

extern void foo(integer* x, smallstr const a);  



extern void sprintf1(smallstr s,
                     char* format); 


void main1(const integer lo, const integer hi, char const* a)
{
   integer i;
   smallstr s;

   foo(&i, a);
   sprintf1(s, lpsz(lo, hi, a), i);
   sprintf1("s", "a", i);
}

