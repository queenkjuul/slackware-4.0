#include "ptoc.h"

void modify(conf_array<char> a)
{
   const int lo = a.low;
   const int hi = a.high;
   a[lo] = a[hi];
}

void f(conf_array<char> a, conf_array<char> b)
{
   const int lo = a.low;
   const int hi = a.high;
   copy_conformant_array(a);
   copy_conformant_array(b);
   output << a[lo] << NL;
   output << b[lo] << NL;
   if (a[lo] != '2') 
   {
      a[lo] = '1';
      b[lo] = '2';
      a = b;
      f(a, b);
      modify(a);
   }
}

void g(conf_array<char> a, conf_array<char> b)
{ 
   const int lo = a.low;
   const int hi = a.high;
   output << a[lo] << NL;
   output << b[lo] << NL;
   if (a[lo] == '0') 
   {
      a[lo] = '3';
      b[lo] = '4';
      a = b;
      f(a, b);
      g(a, b);
   }
}

array<1,100,char> a, b;
int main()
{ 
   a[1] = '0';
   b[1] = '0';
   f(a, b);
   g(a, b);
   f(a, b);
   output << a[1] << NL;
   return EXIT_SUCCESS;
}

