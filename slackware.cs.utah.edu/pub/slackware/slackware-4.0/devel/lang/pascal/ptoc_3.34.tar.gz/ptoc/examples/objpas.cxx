#include "ptoc.h"


class class_ {
public:
  integer y;
};
class t : public class_ {
public:
  integer x;
  void f1();
  virtual void f2(); 
  integer  f3(); 
  virtual integer  f4(integer i) ; 
  t* init(integer i);
  t*  remove(); 
};     
typedef t* pt;
pt obj;
void t::f1()
{
   x = y;
}

void t::f2()
{;
}

integer t::f3() 
{
        integer f3_result;
        f3_result = x;
        return f3_result;
}
integer  t::f4(integer i)
{
        integer f4_result;
        x = i;
        f4_result = 0; 
        this->x = 0;
        i = this->f3();
        return f4_result;
} 

t* t::init(integer i)
{
        x = i;
        return this;
}

t*  t::remove()
{;
 return this;
} 

int main()
{
    obj = new t;		
    obj = new t;		 
    obj = new t;
    obj = (new t)->init(1);		
    obj->f1();
    obj->f2();
    obj->f4(1);
    delete obj;
    delete obj->remove();
    return EXIT_SUCCESS;
}
