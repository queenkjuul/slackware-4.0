
EXTERN text lst;
