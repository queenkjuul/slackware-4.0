#define SF 		1	 	/* Start function */
#define EF 		2 		/* End function */
#define OPAREN	3		/* Opening parenthesis */
#define CPAREN 4		/* Closing parenthesis */
#define CALL	5		/* Call to a subroutine */
#define NTEXT	6		/* Normal program */
#define INC		7		/* Included file */
#define FINC	8		/* Included file */
#define OUT		9		/* Block out */
#define STOP	10		/* End blockout */

