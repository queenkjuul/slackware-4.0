
extern int sbl_eval(char *); /* Evaluate a string as an sbl program */
extern int popn(void); /* Pop a number */
extern int pops(char *); /* Pop a string */
extern int pushn(int); /* Push a number */
extern int pushs(char *); /* Push a string */
extern int addvar(char *, char *); /* Add a variable */
extern int getvar(char *, char *); /* Get a variable */
