#include <stdio.h>
#include <string.h>

#define HS 32 /* Size of hash */

extern int lcount; /* For errors */

/* Obsolete: left in for sake of history */
struct list {
	struct list	*next;	/* Next element  */
	unsigned char *prog;				/* The actual macro/function */
	unsigned char *name;				/* The name of the function */
};
struct list *macs[20]; /* The function tree(and strings, too) */

struct tree {
	struct tree *left;
	struct tree *right;
	unsigned char *val;
	unsigned char *name;
} *vars[HS]; /* Subscripts are because of hash */

void addvar(char *func, char *name) { /* Look! No recursion! */
	struct tree *flip; /* One to flip through on */

	flip = vars[hash(name)]; /* Initialize code */

	if(flip == NULL) { /* No variables yet */
		flip = (struct tree *)mmalloc(sizeof(struct tree)); /* Macro? */
		flip->name = strdup(name);
		flip->val = strdup(func);
		flip->right = 0; /* Clear */
		flip->left = 0;
		vars[hash(name)] = flip; /* Set it */
		return;
	}
	for(;;) {
		if(flip == NULL) {
			fprintf(stderr, "Fatal sbl error: bailing out\n");
			exit(1);
		}
		if(strcmp(name, flip->name) == 0) { /* Already in table */
			if(strlen(func) <= strlen(flip->val))
				strcpy(flip->val, func); /* Already malloced enough */
			else {
				mfree(flip->val); /* Make broken code segfault */
				flip->val = strdup(func); /* Or not. */
			}
			return; /* Easy */
		} else if(strcmp(name, flip->name) < 0) { /* Left node */
			if(flip->left == NULL) { /* Our place */
				flip->left = (struct tree *)mmalloc(sizeof(struct tree));
				flip->left->name = strdup(name);
				flip->left->val = strdup(func);
				flip->left->left = 0;
				flip->left->right = 0;
				return;
			} else
				flip = flip->left; /* Follow tree */
		} else if(strcmp(name, flip->name) > 0) { /* Right node */
			if(flip->right == NULL) { /* Found it */
				flip->right = (struct tree *)mmalloc(sizeof(struct tree));
				flip->right->name = strdup(name);
				flip->right->val = strdup(func);
				flip->right->left = 0;
				flip->right->right = 0;
				return;
			} else
				flip = flip->right;
		}
	}
	return; /* This will never be reached */
}

void getvar(char *func, char *name) {
	struct tree *flip;

	flip = vars[hash(name)]; /* Hash function speeds things up lots */

	for(;;) {
		if(flip == NULL) { /* Not found */
			fprintf(stderr, "Error: line %d: bad var '%s'\n", lcount, name);
			exit(1);
			return;
		}
		if(strcmp(flip->name, name) == 0) { /* Got it */
			strcpy(func, flip->val); /* Set return */
			return;
		} else if(strcmp(flip->name, name) > 0) { /* Note all's backwards */
			flip = flip->left;
		} else if(strcmp(flip->name, name) < 0) {
			flip = flip->right;
		}
	}
	return; /* Not reached */
}

long int getref(char *name) {
	struct tree *flip;

	flip = vars[hash(name)]; /* Hash function speeds things up lots */

	for(;;) {
		if(flip == NULL) { /* Not found */
			fprintf(stderr, "Error: line %d: bad var '%s'\n", lcount, name);
			exit(1);
			return;
		}
		if(strcmp(flip->name, name) == 0) { /* Got it */
			return (long int)flip->val; /* Return address */
		} else if(strcmp(flip->name, name) > 0) { /* Note all's backwards */
			flip = flip->left;
		} else if(strcmp(flip->name, name) < 0) {
			flip = flip->right;
		}
	}
	return; /* Not reached */
}


hash (unsigned char *code) {
	long int c = 0; /* Avoid magically changing hashes */
	for(;;) {
		c += *code;
		if(*code == 0)
			break;
		code++;
	}
	return c % HS;
}
