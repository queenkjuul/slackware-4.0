#include <stdio.h>
#include <string.h>

/* Vanilla linked list. Tree would be much better, though. */
struct list {
	char *key;
	char *val;
	struct list *next;
};

void *newhash(void) { /* Newhash: return a pointer to a hash */
	struct list *new;
	new = (struct list *)mmalloc(sizeof(struct list));
	/* Create a default entry */
	new->key = strdup("");
	new->val = strdup("");
	new->next = NULL; 
	return new; /* Return the address to our new entry: don't free it! */
}

void hashadd(char *val, char *key, void *hash) {
	struct list *new;
	struct list *old;
	old = hash; /* Set up variable */

	/* First, we create the new entry */
	new = (struct list *)mmalloc(sizeof(struct list));
	new->key = strdup(key);
	new->val = strdup(val);
	new->next = NULL;
	/* Now, find the last element of old */
	for(;;) {
		if(old->next == NULL)
			break; /* Got it */
		if(!strcmp(old->key, key)) { /* On the off chance it exists.... */
			old->val = strdup(val);
			mfree(new);
			return;
		}
		old = old->next; /* Advance to next function */
	}
	/*                                      .                  */
	/* Now, we know the old->next == NULL, . . old is the last */
	old->next = new; /* Set the next */
	return;
}

void hashget(char *name, void *ptr) {
	struct list *flip;
	flip = ptr;
	for(;;) {
		if(!flip) {
			strcpy(name, ""); /* Null it */
			return;
		}
		if(!strcmp(name, flip->key)) { /* Got it! */
			strcpy(name, flip->val); /* Set return */
			return;
		}
		flip = flip->next;
	}
}

void hashkeys(void *list) { /* keys: return every key to a hash */
	struct list *flip;
	int a = 0;

	flip = list;
	for(;;) {
		if(!flip)
			break;
		if(strcmp(flip->key, ""))
			pushs(flip->key), ++a;
		flip = flip->next;
	}
	pushn(a);
}

void llat(char *item, int pos, void *list) { /* llat: append at point */
	struct list *flip, *old, *new;
	int cnt, op1;
	flip = list; /* Go to point */
	for(cnt = 0; cnt < pos; cnt++)
		flip = flip->next; /* Flip through to proper position */
	new = (struct list *)mmalloc(sizeof(struct list));
	new->val = strdup(item); /* Add it in */
	/* Now, we begin the insertion process */
	old = flip->next; /* Inserting new between flip and old */
	flip->next = new; /* Insert new */
	new->next = old; /* Reform list */
}

void lladd(char *item, void *list) { /* lladd: add to end of list */
	struct list *new, *flip;
	/* First, set up new entry */
	new = (struct list *)mmalloc(sizeof(struct list)); /* Allocate */
	new->val = strdup(item);
	new->next = NULL; /* Make sure list terminates */
	flip = list; /* Assign flip */
	for(;;) {
		if(flip->next == NULL)
			break; /* We're at the end */
		flip = flip->next;
	}
	flip->next = new; /* Assign new element */
}

void llpop(char *item, void *list) { /* llpop: pop an element off a list */
	struct list *old, *flip;
	flip = list;
	for(;;) {
		if(flip->next->next == NULL)
			break; /* Next element is terminator */
		flip = flip->next;
	}
	strcpy(item, flip->next->val); /* Get data */
	mfree(flip->next); /* Evade mem leaks */
	flip->next = 0; /* Segfaults too */
}

int llelem(void *list) { /* Return size of list */
	struct list *flip;
	int a = 0;
	flip = list; /* Do not use magic */
	for(;;) {
		if(!flip)	
			return a - 1; /* Hay siempre el primero */
		a++;
		flip = flip->next;
	}
	return -1; /* Something badly wrong */
}

int lllook(char *place, int num, void *list) {
	struct list *flip;
	int cnt;
	flip = list;
	for(cnt = 0; cnt < num; cnt++)
		flip = flip->next;
	strcpy(place, flip->val);
}

int llset(char *val, int num, void *list) {
	int cnt;
	struct list *flip;
	for(cnt = 0; cnt < num; cnt++)
		flip = flip->next;
	mfree(flip->val);
	flip->val = strdup(val); /* Reset it w/o memory leak */
}

int llshift(char *val, void *list) {
	struct list *flip, *new;
	flip = list;
	new = (struct list *)mmalloc(sizeof(struct list));
	new->val = strdup(val);
	new->next = flip->next;
	flip->next = new;
}

void *llrev(void *list) { /* llrev: reverse a list in order */
	struct list *flip, *new, *tmp;
	char buf[1024];
	int cnt, max;
	flip = list;
	max = llelem(flip); /* Don't let it crash */
	new = newhash(); /* Create the new one */
	for(cnt = 0; cnt < max; cnt++) {
		llpop(buf, flip);
		lladd(buf, new);
	}
	return new;
}

int llunroll(void *list) { /* llunroll: unroll a list */
	struct list *flip;
	int cnt = 0;
	flip = list;
	flip = flip->next;
	for(;;) {
		if(!flip) {
			pushn(cnt);
			return 0;
		}
		pushs(flip->val); /* Ya sabemos existe */
		flip = flip->next;
		++cnt;
	}
}

void *lldup(void *list) { /* llrev: reverse a list in order */
	struct list *flip, *new, *tmp;
	char buf[1024];
	flip = list;
	new = newhash(); /* Create the new one */
	tmp = new; /* To flip through other */
	for(;;) {
		flip = flip->next;
		if(!flip)
			break;
		tmp->next = (struct list *)mmalloc(sizeof(struct list));
		tmp->next->val = strdup(flip->val);
		tmp = tmp->next;
	}
	return new;
}

void *llcat(void *first, void *second) {
	struct list *flip, *f, *s;
	flip = first;
	for(;;) {
		if(!flip->next)
			break;
		flip = flip->next;
	}
	s = second;
	s = s->next; /* Skip null */
	flip->next = s; /* Do the append */
	return first; /* Has been appended to first */
}

void lldel(int pos, void *list) {
	struct list *flip, *old;
	int cnt;

	flip = list;
	--pos; /* We want to get one before the specified node */
	for(cnt = 0; cnt < pos; cnt++)
		flip = flip->next;
	old = flip->next; /* Old is the targeted element */
	flip->next = old->next; /* Set it to following element */
	mfree(old->val); /* String */
	mfree(old); /* Pointer */
}
