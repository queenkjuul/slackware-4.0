/* token.h - tokens for the sbl parser. This is just a bunch of defs used to
 * either interpret code or store it in parsed form for later use in an array
 * of characters. */

/* To begin with, we'll have some basic operators for stack and math */
#define PLUS 	45 /* a + b */  /* Note strange numbering. ``By design!'' */
#define MINUS 	2  /* a - b */
#define TIMES 	3  /* a * b */
#define OVER 	4  /* a / b */
#define MOD 	5  /* a % b */
#define TO 		6  /* a ^ b */
#define OUT 	7  /* Output text/number */
#define IN 		8  /* Input text/number  */ /**/
#define NUM		9  /* A number           */ 
#define END		10 /* Exit program			*/
#define DROP	11 /* Drop one from stack */
#define DUP		12 /* Duplicate current level */
#define PICK	13 /* Pick from a certain level of stack */
#define TEXT	14 /* Self-explanatory, don't you think? */
#define sOUT	15 /* Output string */
#define sIN		16 /* Input string  */
#define sCHOMP	17 /* Chop string   */
#define tSTR	18 /* Convert number->string */
#define tNUM	19 /* Convert string->number */
#define sCAT	20 /* Concatenate strings */
/* Now, we have some placeholder ops that aren't eval'ed */
#define OBRACE 21 /* Opening brace */
#define CBRACE 22 /* Closing brace */
/* Assorted junk, including the boolean stuff */
#define SKIP	23 /* Skip next block */ /**/
#define ATIME	24	/* Format time in ASCII */
#define AND		25 /* Boolean AND */
#define OR		26 /* Boolean OR */
#define NOT		27 /* Boolean NOT */
#define EQUALS	28	/* Numerical equality */
#define MORE	29 /* Greater than */
#define LESS	30 /* Less than */
#define NEQ		31 /* Not equal to */
/* A bit of stack manipulation */
#define sDROP	32 /* Drop a string */
#define sDUP 	33 /* Duplicate a string */
#define sPICK	34 /* Pick a string */
#define IF		35 /* If statement! */
#define SWAP	36	/* Swap x and y */
#define UC		37	/* To uppercase */
#define LC		38	/* To lowercase */
#define sSWAP	39	/* Swap two values */
/* Control structures */
#define WHILE	40	/* While type loop */ /**/
#define SUB		41 /* Start a subroutine */
#define REPEAT	42	/* Repeat compiled code n times */
#define CALL	43 /* Execute precompiled code */
#define SEQ		44 /* String equality */
/* String functions */
#define FORMAT	46 /* Map using format */
#define SPLIT	47 /* Split by character */ /**/
#define TRD		49 /* Delete character */
#define CHR		50 /* int->character */
#define ASC		51 /* character->int */
/* File IO */
#define OPENO	52 /* Open output */
#define OPENI	53	/* Open input */
#define RESTOREI	54	/* Restore input */
#define RESTOREO	55	/* Restore output */
#define NEOF		56	/* End-of-file marker */
#define PROMPT		57 /* Issue statement directly to stderr */
#define dIN			58	/* Input directly from stdin */
/* The pseudorandom number functions */
#define RAND		59 /* Get a random number */
#define SRAND		60 /* Set random number seed */
#define TIME		61 /* Return system time */
#define VREF		62	/* Return a reference to a variable */
/* Some more stack/control stuff */
#define STC			63 /* Store counter */
#define RCC			64 /* Recall counter */
#define DEPTH		65	/* Depth of nums stack */ /**/
#define sDEPTH		66 /* Depth of string stack */ /**/
/* Now, the basic string functions */
#define TR			67 /* Translate letters */
#define sLEN		68 /* String length */
#define sLEFT		69 /* Grab n characters from left */ /* Could compress */
#define sRIGHT		70 /* Grab n charcters from right */ /* both into one  */
#define SYSTEM		71	/* Run in UNIX shell */
#define SNEXT		72	/* Set next level to act on */
#define RENAME		73	/* Rename files */ 
#define STO			74 /* Store variable */
#define GET			75 /* Get from variable */
#define MRE			76 /* Match regex */ /**/
#define SRE			77 /* Set regex */ /**/
#define PIPEI		78 /* Open input pipe */
#define PIPEO		79 /* Open output pipe */
#define PIPEIC		80 /* Close input pipe */
#define PIPEOC		81 /* Close output pipe */
#define SQRT		82 /* Square root */
#define SIN			83 /* Sine */
#define BTEXT		84 /* Unformattable text */
#define GETC		85 /* Get character */
#define FORF		86 /* Do X for every file */
#define FORK		87 /* Fork two instances */
#define sSUB		88 /* Substitute string */ /**/
#define sPOS		89 /* Position in string */
#define JUMP 		90 /* Jump to new position */
#define SLEEP		91	/* Sleep n seconds */
#define COS			92	/* adjacent / hippopotamus */
#define TAN			93	/* opposite / adjacent */
#define LOG10		94	/* Base-ten logarithm */
#define LOGE		95	/* Base-e logarithm */
#define SIGNAL		96	/* Set signal */
#define SUBSTR		97	/* Substring */
#define LLREV		98	/* Reverse a linked list */
#define RSIG		99	/* Restore signal function */
#define EVAL		100	/* Evaluate string */
#define REFS		101	/* Store a reference */
#define REFG		102	/* Get reference address */
#define HASHA		103	/* Add a key/element to a hash */
#define HASHL		104	/* Look up a key in a named hash */
#define HASHN		105	/* Create a new hash */
#define HASHK		106	/* Keys for a hash table */
#define LLAT		107	/* Add at position */
#define LLADD		108	/* Add at end */
#define LLLENGTH	109	/* Return length of ll */
#define LLLOOK		110	/* Look up element */
#define SUBC		111	/* Subroutine */
#define VLOOK		112	/* Lookup */
#define OPENA		113	/* Open to append */
#define ALARM		114	/* Same as sys call */
#define WAITING	115	/* Number of waiting characters */
#define FOREVER	116	/* As implies */
#define EXT			117	/* Call as extension */
#define KILL		118	/* Kill a process */
#define BREAK		119	/* Break out of forever loop */
#define EXTC		120	/* Call an extension */
#define STAT		121	/* stat(2) */
#define CHMOD		122	/* chmod(2) */
#define UNLINK		123	/* system call */
#define GETENV		124	/* get environment */
#define SETENV		125	/* Set environment */
#define IDER		126	/* Deference an integer reference */
#define IREF		127	/* Make an integer reference */
#define SDER		128	/* Get a string reference */
#define SREF		129	/* Make a string reference */
#define BAND		130	/* Bitwise AND */
#define BOR			131	/* Bitwise OR */
#define BNOT		132	/* Bitwise NOT */
#define SETC		133	/* Set a character in a string */ /**/
#define RDIR		134	/* Read dir */
#define LLUSHIFT	135	/* Unshift from array */
#define TEST		136	/* The standard file test operators */
#define FLOAT		137	/* Floating point number */
#define tFLOAT		138	/* String to float - use format for other way */
#define D2F			139	/* Decimal to float */
#define F2D			140	/* Float to decimal */
#define LLUNROLL	141	/* Unroll a list  */
#define S			142	/* The single-character glob ops: substitute */
#define M			143	/* The single-character glob ops: match */
#define P			144	/* The single-character glob ops: split */
#define DUP2		145	/* Dup number twice */ /**/
#define USE			146	/* Use a file */
#define REVERSE	147	/* Reverse a string */
#define LLAMA		148	/* Hint: not the animal */
#define LLPOP		149	/* Pop off list */
#define LLSET		150	/* Set linked list item */
#define CHDIR		151	/* Change directory */
#define RLOOK		152	/* Look up reference */
#define FOUT		153	/* Formatted output */
#define tLIST		154	/* Make values into list */
#define VSET		155	/* Set svar */
#define ISET		156	/* Set ivar */
#define LLCAT		157	/* Cat LL's */
#define LLDUP		158	/* Dup an ll */
#define GFILE		159	/* Get file descriptor */
#define SFILE		160	/* Set file descriptor */
#define FSET		161	/* Set fdesc */
#define FGET		162	/* Get fdesc */
#define SORT		163	/* Sort integers from stack */
#define sSORT		164	/* Sort strings from stack */
#define RE			165	/* Regular expression text */
#define TICK		166	/* Backquotes: shell */
#define LLDEL		167	/* Delete from linked list */
#define RVAL		168	/* Return value */
#define ELSE		169	/* Else statement */
#define GLABEL		170	/* Goto label */
#define GOTO		171	/* Goto */
#define QMATCH		172	/* Quick match */
#define QSUB		173	/* Quick substitute */
