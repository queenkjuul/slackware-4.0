#include <stdlib.h>
#include <stdio.h>
/* sym.c: symbol table for function calls */

struct list {
	struct list	*next;	/* Next element  */
	char *prog;				/* The actual macro/function */
	char *name;				/* The name of the function */
};

struct list *macs; /* The symbol table */

void addfunc(char *func, char *name) { /* addfunc: add function to lookup table */
	struct list *new;
	new = (struct list *)malloc(sizeof(struct list));
	new->prog = malloc(strlen(func) + 2);
	new->name = malloc(strlen(name) + 2);
	strcpy(new->prog, func); /* Copy  the name and value of the current */
	strcpy(new->name, name); /* macro/function in the new entry         */
	new->next = macs;
	macs = new; /* Actually enter it */
}

int getfunc(char *func, char *name) { /* getfunc: get value of function */
	struct list *mac;
	mac = macs; /* Get some temporary workspace */
	if(mac == 0) {
		strcpy(func, name);
		return 0;
	}
	for(;;) {
		if(!strcmp(mac->name, name)) {
			strcpy(func, mac->prog);
			return 0;
		}
		if(mac->next == 0) {
			strcpy(func, name);
			return 0;
		}
		mac = mac->next;
	}
}

int dumpfunc(void) {
	struct list *mac;
	mac = macs; /* See above function for explanation */
	for(;;) {
		fprintf(stderr, "FDUMP: %s => <<%s>>\n", mac->name, mac->prog);
		if(mac->next == 0)
			return 0;
		mac = mac->next;
	}
	return 0;
}
