/*
 * bitflip.[co]: this is a sample routine that will return a variety of different string
 * things: for example, it can create strings with patterns, fill strings, and interleave
 * them. Its main purpose is as a demonstration for sbl's dynamic linking capabilities.
 */

tile(void) { /* Over: tile string x x times */
	int times;
	int cnt;
	char str[1024];
	char tile[64];
	bzero(str, sizeof(str));
	times = popn();
	pops(&tile);
	for(cnt = 0; cnt < times; cnt++)
		strcat(str, tile);
	pushs(str);
}

fill(void) { /* Fill: fill a string with a character */
	int cnt, chr;
	char str[1024];
	chr = popn();
	pops(&str);
	for(cnt = 0; cnt < strlen(str); ++cnt)
		str[cnt] = chr;
	pushs(str);
}

interleave(void) { /* Interleave: assemble two strings into one */
	char final[1024], *fptr;
	char one[1024], two[1024], *onep, *twop;

	pops(two);
	pops(one);

	/*
	 * Initialize pointers.
	 */
	fptr = final;
	onep = one;
	twop = two;
	
	bzero(final, sizeof(final));

	for(;;) {
		*fptr = *onep;
		fptr++;
		onep++;
		*fptr = *twop;
		twop++;
		if(*twop == '\0' || *onep == '\0')
			break;
		fptr++;
	}
	pushs(final);
}
