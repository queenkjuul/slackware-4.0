#include "token.h"
#include <stdio.h>
long int yyval;
int brace = 0; /* Brace count */
extern int state; /* Set this. It's important */
int lcount = 1;
int debug = 0; /* Global debug flag */
extern int warn; /* Print warnings on suspicious behaviour */
extern char *ptr;
char *ceval; /* Current string being evaluated */
int evalf = 0; /* Flag indicating what's being evall'ed */
FILE *min; /* (M)y (In)put - not (Min)imum */
extern char* yytext;
FILE *mout; /* (M)y (Out)put */
extern FILE *yyin;

main (int argc, char** argv) {
	int ret; /* hundred tokens off the command line */
	int tc = 100;
	int mv = 2;
	FILE *f;
	char junk[100]; /* Some junk to use the first line on */
	min = stdin;
	mout = stdout;
	for(ret = 1; ret < argc; ret++) { /* For each option */
		if(argv[ret][0] == '-') { /* We're handling it */
			if(argv[ret][1] == '-')
				break; /* End of arguments */
			else if(argv[ret][1] == 'd')
				debug = 1;
			else if(argv[ret][1] == 'w')
				warn = 1;
			else {
				fprintf(stderr, "Error: bad option -%c\n", argv[ret][1]);
				exit(1);
			}
		} else {
			yyin = fopen(argv[ret], "r");
			if(!yyin) {
				fprintf(stderr, "Error: can't open '%s'\n", argv[ret]);
				exit(1);
			}
			fgets(junk, sizeof(junk), yyin); /* Discard shebang */
			lcount++; /* We've read one line, so we must increment the linecounter */
			tc = toks(argv[ret]);
			break; /* No more options */
		}
	}
	ret++; /* Step off filename */
	pushs("EOF--EOF~~EOF--EOF");  /* Put marker */
	for(;ret < argc; ret++) /* Finish the loop */
		pushs(argv[ret]);


	if(isatty(0)) /* Is it running on a tty? */
		addvar("1", "tty");
	else
		addvar("0", "tty");
	sprintf(junk, "%d", getpid()); /* PID */
	addvar(junk, "pid");
	sprintf(junk, "%d", getppid()); /* Parent's PID */
	addvar(junk, "ppid");
	sprintf(junk, "%d", getuid()); /* UID */
	addvar(junk, "uid");
	sprintf(junk, "%d", getgid()); /* GID */
	addvar(junk, "gid");
	
	sprintf(junk, "%d", geteuid()); /* Effective UID */
	addvar(junk, "euid");
	sprintf(junk, "%d", getegid()); /* Effective GID */
	addvar(junk, "egid");
	addvar("50", "lines"); /* Assume fifty line pages if unspeced */

	pushn(0); /* Make emtpy stack == 0 */
	compilep(tc);

}

minput(char *buf, int ms) {
	int n;
	if(evalf == 0) {
		n = getc(yyin);
		if(n == EOF) 
			return 0;
	} else {
		n = *ceval;
		ceval++;
		if(n == 0)
			return 0;
	}
	buf[0] = n;
	return 1;
}

int other(char *text) {
	fprintf(stderr, "Error: line %d: bad token %s\n", lcount, text);
	exit(1);
}

ext_sbl(char *str) {
	fprintf(stderr, "Error: line %d: not running embedded sbl: can't resolve %s\n", lcount, str);
	exit(1);
}
