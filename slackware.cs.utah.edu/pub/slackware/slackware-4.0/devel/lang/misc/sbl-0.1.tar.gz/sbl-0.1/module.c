#include <dlfcn.h> /* Presumably dynamic linking will become important */
#include <stdio.h>

/* From sbl.l or main.c: standard returns for yylex() */
extern char *yytext;
extern long yyval; 
extern FILE *yyin;
extern int lcount;

int (*dyn[256])(void); /* The functions to call */
int maxdyn = 0; /* Maximum dynamic function in use */

int processf(char *file) { /* processf: process a file */
	FILE *reading, *save;
	int ret;
	char buff[100];
	int lines; /* Number of lines */
	reading = fopen(file, "r");
	if(!reading) { /* Try for public directory */
		sprintf(buff, "/usr/local/lib/sbl/%s", file);
		reading = fopen(buff, "r");
	}
	if(!reading) { /* Can't find it, then */
		fprintf(stderr, "Fatal error opening '%s': bailing out\n", file);
		exit(1);
	}
	lines = lcount;
	save = yyin; /* store fd */
	yyin = reading; /* set to file */
	while(cone())
		; /* Compile hasta la fin */
	fclose(yyin);
	yyin = save; /* restore input */
	lcount = lines; /* Undo lexer's damage */
}


externf(char *mfile) {
	FILE *reading;
	void *handle; /* Current file, as handled by dlopen */
	char *olderr, buff[100], func[100], name[100], file[100]; /* Stored error */
	int lc = 0;

	reading = fopen(mfile, "r");
	if(!reading) { /* Try for public directory */
		sprintf(buff, "/usr/local/lib/sbl/%s", mfile);
		reading = fopen(buff, "r");
	}
	if(!reading) { /* Can't find it, then */
		fprintf(stderr, "Fatal error opening '%s': bailing out\n", mfile);
		exit(1);
	}
	while(fgets(buff, sizeof(buff), reading)) {
		++lc; /* Increment linecounter */
		buff[strlen(buff) - 1] = 0; /* Clear newline */
		if(buff[0] == '\0' || buff[0] == '#')
			continue; /* Skip blank/commented lines */
		if(sscanf(buff, "%s %s %s", file, func, name) != 3) { /* Error! */
			fprintf(stderr, "Error: included file %s: bad line %d\n", mfile, lc);
			exit(1); /* This is serious */
		}
		handle = dlopen(file, RTLD_LAZY);
		if(!handle) {
			/* Give dl library's error message */
			fprintf(stderr, "Error: file %s, line %d: %s on dlopen\n", mfile, lc, dlerror());
			exit(1);
		}
		if(maxdyn > 255) {
			fprintf(stderr, "Error: out of extern function descriptors\n");
			exit(1);
		}
		dyn[maxdyn] = dlsym(handle, func);
		if((olderr = dlerror()) != NULL) {
			fprintf(stderr, "Error: file %s, line %d: %s on open %s\n", mfile, lc, olderr, func);
			exit(1);
		}
		sprintf(buff, "%d", maxdyn); /* For variable */
		sprintf(func, "dl_%s", name); /* For var name */
		addvar(buff, func); /* Add the variables as expected */
		/*
		 * Note here that I am specifically _not_ dlclosing my files. This would be bad, since
		 * when a library is dlclosed, everything has a tendency to disappear rather suddenly.
		 */
		++maxdyn; /* Augment number of dynamic loads in use */
	}
	return 0;
}

docall(void) {
	int cn;
	cn = popn();
	(*dyn[cn])(); /* Call subroutine */
}

