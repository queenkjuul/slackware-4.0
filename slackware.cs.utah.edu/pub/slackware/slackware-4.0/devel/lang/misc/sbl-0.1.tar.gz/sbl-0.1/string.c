#include <string.h>
#include <stdio.h>
#include <stdlib.h>

extern int lcount;
extern FILE *mout; /* For the formatter */
extern unsigned char nmode;

double popf(void); /* To appease compiler */
int octn(char);
int hexn(char);

int linecount = 0; /* The current linenumber on the format page */

void fix (char *str) { /* fix: take string with quotes and do all manipulation */
	char *ptr; /* Pointer to scroll through */
	char add[10]; /* Special sequences to add */
	char mstr[128]; /* String to interpolate */
	char *final;  /* String to ultimately return */
	char seq;     /* Character indicating which sequence it is */
#ifdef DEBUG
	printf("Got string <<%s>>\n", str);
#endif
	final = (char *)mmalloc(strlen(str) + 128); /* Grab space for result */
#ifdef DEBUG	
	printf("Length %d\n", strlen(str));
#endif
	memset(final, 0, sizeof(final)); /* Avoid catastrophes with pointers */
	ptr = str; /* Set the pointer */
#ifdef DEBUG
	printf("Just set pointer\n");
#endif
	for(;;) {
		ptr++; /* Dumb trick to avoid first quote */
		if(*ptr == 0) 
			break; /* Ack! */
#ifdef DEBUG
		printf("Pointer %c\n", *ptr);
#endif
		if(*ptr == '\\') { /* Beginning escape sequence! */
#ifdef DEBUG
			printf("Got escape sequence!\n");
#endif
			ptr++;
			seq = *ptr;
			if(seq == 'n') 
				strcat(final, "\n"); /* Tack on a newline */
			else if(seq == 'r')
				strcat(final, "\r"); /* Tack on a mac-newline */
			else if(seq == '\\')
				strcat(final, "\\"); /* Tack on a slash */
			else if(seq == 't')
				strcat(final, "	"); /* Tack on a tab */
			else if(seq == 'p') { /* Stack pop */
				pops(mstr);
				strcat(final, mstr);
			} else if(seq == 's') { /* Num pop */
				if(nmode == 1) /* MINT */
					sprintf(mstr, "%d", popn());
				else
					sprintf(mstr, "%f", popf());
				strcat(final, str);
			} else if(seq == '\'')
				strcat(final, "\""); /* Tack on a quote */
			else
				strcat(final, "\\"); /* Take a wild guess */
		} else { /* Not an escape; just a character */
			add[0] = *ptr;
			add[1] = 0;
#ifdef DEBUG
			printf("Adding string %s\n", add);
#endif 
			strcat(final, add);
		}
	}
	final[strlen(final) - 1] = 0; /* Clear out final quote */
#ifdef DEBUG
	printf("Now at <<%s>>\n", final);
#endif
	strcpy(str, final);
	mfree(final); /* Plug memory leak */
#ifdef DEBUG
	printf("Returning from function now\n");
#endif
}

void format (char *passed) { /* format: printf-ish format statement */
	char frm[1024]; /* Sling huge buffers */
	char cstr[512]; /* String we're interpolating */
	int num; /* Number just read */
	int cnt; /* Count */
	frm[0] = 0; /* Avoid memory surprises */
	for(cnt = 0; ; cnt++) {
		if(passed[cnt] != '%') { /* In the tradition of printf */
			cstr[0] = passed[cnt];
			cstr[1] = 0;
			strcat(frm, cstr); /* Tack it on */
		} else {
			cnt++;
			switch(passed[cnt]) {
				case '%': strcat(frm, "%"); break; 
				case 'd':
					sprintf(cstr, "%d", popn());
					strcat(frm, cstr);
					break;
				case 'f':
					sprintf(cstr, "%f", popf());
					strcat(frm, cstr);
					break;
				case 'X':
					sprintf(cstr, "%X", popn());
					break;
				case 'x':
					sprintf(cstr, "%x", popn());
					break;
				case 's':
					pops(&cstr);
					strcat(frm, cstr);
					break;
				case 'c':
					cstr[0] = popn();
					cstr[1] = 0;
					strcat(frm, cstr);
					break;
				default:
					cstr[0] = passed[cnt];
					cstr[1] = 0;
					strcat(frm, cstr);
					break;
			}
		}
		if(passed[cnt] == 0)
			break;
	}
	strcpy(passed, frm);
}

split(char *str, char *del) { /* split: split up string by delimiter */
	char string[1024]; /* Output */
	char small[3]; /* Tiny thing to cat onto string */
	int count = 0;
	int nmatch = 0;
	string[0] = 0;

	for(;;) {
		if(str[count] == del[0]) {
			string[count] = 0;
			pushs(string);
			string[0] = 0;
			nmatch++;
		} else {
			small[0] = str[count];
			small[1] = 0;
			strcat(string, small);
		}
		if(str[count] == 0)
			break;
		count++;
	}
	pushn(nmatch + 1);
	pushs(string);
}

zap (char *str, char chr) { /* zap: take a certain character out of existence */
	int c;
	char out[1024];
	char small[2];
	out[0] = 0;
	for(c = 0;;c++) {
		if(str[c] != chr) {
			small[0] = str[c];
			small[1] = 0;
			strcat(out, small);
		}
		if(str[c] == 0)
			break;
	}
	strcpy(str, out);
}

tr (char *str, char *old, char *new) { /* tr: change one charcter for another */
	char *mp, *ret; /* Pointer to string, return value for strchr */
	mp = str;
	for(;;) {
		if(*mp == '\0') /* Hit end of string? */
			break;
		if(ret = strchr(old, *mp)) /* Exists in old? */
			*mp = new[ret - old]; /* Set to equivalent in new */
		mp++;
	}		
}



void fix2 (char *str) { /* fix: take string with quotes and do all manipulation */
	char *ptr; /* Pointer to scroll through */
	char add[10]; /* Special sequences to add */
	char *final;  /* String to ultimately return */
	char seq;     /* Character indicating which sequence it is */
#ifdef DEBUG
	printf("Got string <<%s>>\n", str);
#endif
	final = (char *)mmalloc(strlen(str)); /* Grab space for result */
#ifdef DEBUG	
	printf("Length %d\n", strlen(str));
#endif
	memset(final, 0, sizeof(final)); /* Avoid catastrophes with pointers */
	ptr = str; /* Set the pointer */
#ifdef DEBUG
	printf("Just set pointer\n");
#endif
	for(;;) {
		ptr++; /* Dumb trick to avoid first quote */
		if(*ptr == 0) 
			break; /* Ack! */
#ifdef DEBUG
		printf("Pointer %c\n", *ptr);
#endif
		add[0] = *ptr;
		add[1] = 0;
#ifdef DEBUG
			printf("Adding string %s\n", add);
#endif 
		strcat(final, add);
	}
	final[strlen(final) - 1] = 0; /* Clear out final quote */
#ifdef DEBUG
	printf("Now at <<%s>>\n", final);
#endif
	strcpy(str, final);
	mfree(str); /* As before: fix memory leak */
#ifdef DEBUG
	printf("Returning from function now\n");
#endif
}

reverse (char *str) { /* reverse: use old trick to reverse string in place */
	int c;
	int b;
	char t;
	for(c = 0, b = strlen(str) - 1; c <= b; c++, b--) {
		t = str[c];
		str[c] = str[b];
		str[b] = t;
	}
	/* Done */
}

uc (char *str) { /* uc: uppercase string in place */
	char *p;
	p = str;
	for(;;) {
		if(*p == 0)
			break;
		*p = toupper(*p);
		p++;
	}
}

lc (char *str) { /* uc: uppercase string in place */
	char *p;
	p = str;
	for(;;) {
		if(*p == 0)
			break;
		*p = tolower(*p);
		p++;
	}
}

int unhex(char *str) { /* An exorcism */
	int total = 0, current = 1;
	char *ptr;
	ptr = str;
	ptr += 2; /* Skip over the 0x part */
	reverse(ptr); /* Turn it around so lsb's are first */
	while(*ptr == ' ' || *ptr == '\t' || *ptr == '\n')
		ptr++; /* Skip leading whitespace */
	for(;;) {
		total += hexd(*ptr) * current;
		current *= 16; /* Increase place value to 16^i */
		ptr++;
		if(*ptr == '\0')
			break;
	}
	return total;
}

int hexd(char d) {
	switch(d) {
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
			return d - '0';
			break;
		case 'A': case 'B': case 'C': case 'D': case 'E':
		case 'F':
			return 10 + (d - 'A');
			break;
		case '\n': case ' ': case '\t':
			return 0; /* Null */
			break;
		default:
			fprintf(stderr, "Error: line %d: bad hexd '%c'\n", lcount, d);
			exit(1);
			break;
	}
}

int unoct(char *str) { /* An exorcism */
	int total = 0, current = 1;
	char *ptr;
	ptr = str;
	ptr += 1; /* Skip over the 0 part */
	reverse(ptr); /* Turn it around so lsb's are first */
	while(*ptr == ' ' || *ptr == '\t' || *ptr == '\n')
		ptr++; /* Skip leading whitespace */
	for(;;) {
		total += octd(*ptr) * current;
		current *= 8; /* Increase place value to 8^i */
		ptr++;
		if(*ptr == '\0')
			break;
	}
	return total;
}

int octd(char d) {
	switch(d) {
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': /* 8, 9 not octal */
			return d - '0';
			break;
		case '\n': case ' ': case '\t':
			return 0; /* Null */
			break;
		default:
			fprintf(stderr, "Error: line %d: bad octd '%c'\n", lcount, d);
			exit(1);
			break;
	}
}

/*
 * Now, we have one of the weirder features of sbl: perlish formats. They can
 * be used for anything awk or printf would be used for, but they're better. At
 * least I hope so.
 */

int fout(char *name) { /* No other args needed: popx called to format */
	/* As I said: sling huge buffers */
	char fline[1024];
	char ftop[1024];
	char fout[1024];
	char line[80];
	char *ptr, *skip, type, tget;
	int lc_max, cnt, tmp, diff;

	if(linecount == 0) { /* Either first time or new page */
		sprintf(line, "%s_top", name);
		getvar(ftop, line);
		fprintf(mout, "%s", ftop);
	}

	sprintf(line, "%s_for", name);
	getvar(fout, line);

	getvar(fline, "lines");
	lc_max = atoi(fline); /* Think page length could overflow int */

	ptr = fout;

	for(;;) {
		if(*ptr == '@' || *ptr == '^') { /* Now, we start formatting */
			tget = *ptr; /* Store the character */
			cnt = 0;
			type = ptr[1]; /* Set type to character to indicate what to do */
			while(*ptr != ';') {
				ptr++;
				cnt++;
			}
			/* Now, we process it */
			if(tget == '@') /* Straight pop */
				pops(fline); /* Get a line */
			else {
				pops(line); /* Var name */
				getvar(fline, line); /* Retrieve */
				if(strlen(fline) > cnt) { /* We take a section */
					skip = fline; /* Set the pointer */
					skip += cnt; /* As many lines as possible */
					while(*skip != ' ' && *skip != '	' && *skip != '\n')
						--skip; /* Go back until we hit whitespace */
					*skip = '\0'; /* Null-terminate fline now */
					skip++;
					addvar(skip, line); /* Reset var */
				}
			}
			if(strlen(fline) >= cnt) { /* Bigger or even, so no justification done */
				fline[cnt] = 0; /* Truncate */
				fprintf(mout, "%s", fline); /* Add */
			} else { /* This now depends entirely on what type is */
				diff = cnt - strlen(fline); /* tmp is amt. of whitespace needed */
				++diff; /* Increase by one: avoid weirdness */
				if(type == '<') { /* Left justify */
					fprintf(mout, "%s", fline); /* Now we can output our string */
					for(tmp = 0; tmp < diff; tmp++)
						fputc(' ', mout); /* Output blanks after */
				} else if(type == '>') {
					for(tmp = 0; tmp < diff; tmp++)
						fputc(' ', mout); /* Output blanks ahead of time */
					fprintf(mout, "%s", fline); /* Now we can output our string */
				} else if(type == '|') { /* Centre */
					if(diff % 2 != 0) { /* Bad split */
						fputc(' ', mout);
						diff--; /* Problem solved */
					}
					diff /= 2; /* Halves */
					for(tmp = 0; tmp < diff; tmp++)
						fputc(' ', mout); /* Output blanks ahead of time */
					fprintf(mout, "%s", fline); /* Now we can output our string */
					for(tmp = 0; tmp < diff; tmp++)
						fputc(' ', mout); /* Output blanks after string */
				} else {
					fprintf(stderr, "Error: line %d: unknown directive '%c'\n", lcount, type);
					exit(1);
				}
			}
		} else {
			fputc(*ptr, mout);
		}
		ptr++;
		if(*ptr == '\0')
			break;
	}
	linecount++;
	if(linecount >= lc_max) { /* Next page */
		linecount = 0; /* Reset everything */
	}
}

int erange(char *string) { /* erange: expand ASCII ranges like A-Z to characters */
	char *source, *rs, *dest;
	int cnt, start, stop;

	rs = strdup(string); /* Make local copy */
	source = rs; /* Set pointer */

	dest = string; /* Set other pointer */

	for(;;) {
		if(*source == '\0') {
			*dest = '\0'; /* Null-terminate */
			break;
		}
		if(source[1] == '-') { /* This is therefore a range */
			start = source[0]; /* Character before */
			stop = source[2]; /* Character after */
			if(start > stop) { /* Bad range? */
				fprintf(stderr, "Error: line %d: bad range in tr %c-%c\n", lcount, start, stop);
				exit(1);
			}
			for(cnt = start; cnt < stop + 1; cnt++) /* Inclusive */
				*(dest++) = cnt; /* Set the character */
			source += 2; /* Skip over start and dash, leave stop for later */
		} else
			*dest = *source;
		dest++;
		source++;
	}
	mfree(rs); /* Free the memory allocated for source */
}
