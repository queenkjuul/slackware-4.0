#include <stdio.h>

extern int lcount; /* Current line number */
extern int debug; /* Not current line number */

unsigned char *ptr;

struct llist {
	struct 	llist	*next;	/* Next element in linked list */
	long int	num;				/* The  whole purpose of the list */	
};

struct slist {
	struct 	slist	*next;	/* Next element in linked list */
	unsigned char		*str;				/* For storing string data	*/
};

struct flist {
	struct flist	*next;	/* Next element */
	double 			num;		/* Number */
};

long int sbl_count; /* Counter 'variable' for sbl */
long int stackn; /* IF set(this) THEN take from(stack) don't(pop) */

struct llist *stack; /* Start up the stack */
struct slist *sstack;/* Stack of strings */
struct slist *pstack;/* Stack of programs */
struct llist *cstack;/* Stack of program counters */
struct llist *jstack;/* Jump table position before/after calls */
struct llist *rstack;/* Stack of counters(rcc/stc) */
struct flist *fstack;/* Note different structure */

int pushn (long int data) {
	struct llist *new;
	long int count;
	if ( stackn != 0 ) {
		new = stack;
		for(count = 0; count < stackn; count++) {
			if(new->next == 0) {
				fprintf(stderr, "Error: line %d: too high snext %d\n", lcount, stackn);
				exit(1);
				stackn = 0;
				return 1;
			}
			new = new->next;
		}
		new->num = data;
		stackn = 0;
		return 0;
	}
	new = (struct llist *)mmalloc(sizeof(struct llist)); /* Allocate space */
	new->num = data; /* Set the data */
	new->next = stack;
	stack = new;
#ifdef DEBUG
	printf("Pushed a %d\n", data);
#endif
	return 0;
}

int pushj (long int data) {
	struct llist *new;
	long int count;
	new = (struct llist *)mmalloc(sizeof(struct llist)); /* Allocate space */
	new->num = data; /* Set the data */
	new->next = jstack;
	jstack = new;
#ifdef DEBUG
	printf("Pushed a %d\n", data);
#endif
	return 0;
}

int pushr (long int data) {
	struct llist *new;
	long int count;
	new = (struct llist *)mmalloc(sizeof(struct llist)); /* Allocate space */
	new->num = data; /* Set the data */
	new->next = rstack;
	rstack = new;
#ifdef DEBUG
	printf("Pushed a %d\n", data);
#endif
	return 0;
}

int pushc (long int data) {
	struct llist *new;
	long int count;
	new = (struct llist *)mmalloc(sizeof(struct llist)); /* Allocate space */
	new->num = data; /* Set the data */
	new->next = cstack;
	cstack = new;
#ifdef DEBUG
	printf("Pushed a %d\n", data);
#endif
	return 0;
}

int pushs (unsigned char *string) {
	struct slist *new;
	unsigned char			 *str;
	long int		 count;
#ifdef DEBUG
	printf("Entered pushs function\n");
#endif
	if ( stackn != 0 ) {
		new = sstack;
		for(count = 0; count < stackn; count++) {
			if(new->next == 0) {
				fprintf(stderr, "Error: line %d: too high snext %d\n", lcount, stackn);
				exit(1);
				stackn = 0;
				return 1;
			}
			new = new->next;
		}
		str = (unsigned char *)mmalloc(strlen(string) + 2);
		strcpy(str, string);
		new->str = str;
		stackn = 0;
		return 0;
	}
	new = (struct slist *)mmalloc(sizeof(struct slist)); /* Allocate space */
	str = (unsigned char *)mmalloc(strlen(string) + 2);
	memset(str, 0, strlen(string) + 2);
#ifdef DEBUG
	printf("Allocated/zeroed memory\n");
#endif
	strcpy(str, string);
#ifdef DEBUG
	printf("Did strcpy\n");
#endif
	new->str = str;
	new->next = sstack;
	sstack = new;
#ifdef DEBUG
	printf("Pushed a %s\n", sstack->str);
#endif
	return 0;
}

long int popn (void) {
	struct llist *iptr;
	long int data;				  /* What we pop */
	if(stack == 0)
		return 0;
	data = stack->num;		/* Actually get data */
	iptr = stack;				/* Save reference */
	if(stack->next != 0)  {
		stack = stack->next; 	/* Move pointer to next */
		mfree(iptr);
	}

	return data;
}

long int popr (void) {
	struct llist *iptr;
	long int data;				  /* What we pop */
	if(rstack == 0)
		return 0;
	data = rstack->num;		/* Actually get data */
	iptr = rstack;
	if(rstack->next != 0) 
		rstack = rstack->next; 	/* Move pointer to next */
	mfree(iptr);	
	return data;
}

long int popj (void) {
	struct llist *iptr;
	long int data;				  /* What we pop */
	if(jstack == 0)
		return 0;
	data = jstack->num;		/* Actually get data */
	iptr = jstack;
	if(jstack->next != 0) 
		jstack = jstack->next; 	/* Move pointer to next */
	mfree(iptr);	
	return data;
}

long int popc (void) {
	struct llist *iptr;
	long int data;				  /* What we pop */
	if(cstack == 0)
		return 0;
	data = cstack->num;		/* Actually get data */
	iptr = cstack;
	if(cstack->next != 0) 
		cstack = cstack->next; 	/* Move pointer to next */
	mfree(iptr);	
	return data;
}

int pops (unsigned char *or) {
	struct slist *iptr;
	if(sstack == 0) {
		fprintf(stderr, "Error: line %d: empty string stack\n", lcount);
		exit(1);
	}
#ifdef DEBUG
	printf("Popping %s\n", sstack->str);
#endif
	strcpy(or, sstack->str);
	iptr = sstack;
	if(sstack->next != 0)
		sstack = sstack->next;
	else
		sstack = 0; /* Set stack to friendly NULL pointer */
	mfree(iptr->str); /* Free string */
	mfree(iptr); 
}

long int pickn (int lev) {
	struct llist *loop; /* One to loop through on */
	int count = 0;	     /* Straightforward counter */

	loop = stack; /* Load up some temporary workspace */
	if(loop == 0)
		return 0;
	for(count = 0; count < lev; count++) {
		if (loop->next != 0) { 
			loop = loop->next;
		} else {
			if(!debug) {
				fprintf(stderr, "Error: pick with too high offset\n");
				exit(1);
			}
			return 0;
		}
	}

	return loop->num;
}
		

int picks (int lev) {
	struct slist *loop; /* One to loop through on */
	int count = 0;	     /* Straightforward counter */

	loop = sstack; /* Load up some temporary workspace */
	if(loop == 0)
		return 0;
	for(count = 0; count < lev; count++) {
		if (loop->next != 0) { 
			loop = loop->next;
		} else {
			if(!debug) {
				fprintf(stderr, "Error: pick with too high offset\n");
				exit(1);
				return 0;
			} else {
				return 0;
			}
		}
	}
	ptr = (unsigned char *)mmalloc(strlen(loop->str) + 2);
	strcpy(ptr, loop->str);
}

void stc (long int a) {
	sbl_count = a;
}

long int rcc (void) {
	return sbl_count;
}

int depthn (void) {
	struct llist *loop;
	int count = 0;
	loop = stack;
	if(loop == 0)
		return 0;
	for(;;) {
		if(loop->next == 0)
			return count + 1;
		loop = loop->next;
		count++;
	}
	return 1024; /* Trust me. This won't happen. */
}


int depths (void) {
	struct slist *loop;
	int count = 0;
	loop = sstack;
	if(loop == 0)
		return 0;
	for(;;) {
		if(loop->next == 0)
			return count + 1;
		loop = loop->next;
		count++;
	}
	return 1024; /* Trust me. This won't happen. */
}

int ststack (int a) { /* ststack: set next position. Goody found on both stacks */
	stackn = a - 1;
	return 0;
}




int pushf (double data) { /* Push a double(floating point) */
	struct flist *new;
	long int count;
	if ( stackn != 0 ) {
		new = fstack;
		for(count = 0; count < stackn; count++) {
			if(new->next == 0) {
				fprintf(stderr, "Error: line %d: too high snext %d\n", lcount, stackn);
				exit(1);
				stackn = 0;
				return 1;
			}
			new = new->next;
		}
		new->num = data;
		stackn = 0;
		return 0;
	}
	new = (struct flist *)mmalloc(sizeof(struct flist)); /* Allocate space */
	new->num = data; /* Set the data */
	new->next = fstack;
	fstack = new;
#ifdef DEBUG
	printf("Pushed a %f\n", data);
#endif
	return 0;
}

double popf (void) {
	struct flist *iptr;
	double data;				  /* What we pop */
	if(fstack == 0)
		return 0;
	data = fstack->num;		/* Actually get data */
	iptr = fstack;				/* Save reference */
	if(fstack->next != 0)  {
		fstack = fstack->next; 	/* Move pointer to next */
		mfree(iptr);
	}
	return data;
}
