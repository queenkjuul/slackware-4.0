#include <stdio.h>
#include <unistd.h>
#include <stdlib.h> /* For atof */
#include <math.h> /* I actually do have decimals. See docs for info */
#include <time.h> /* You weren't expecting this? */
#include <string.h> /* Avoid problems with strdup() */
#include <dlfcn.h> /* For dynamic loading */
#include <regex.h> /* Regular expressions are straight GNU */
#include <signal.h> /* For sighandlers */
#include <sys/ioctl.h> /* For WAITING op */
#include <sys/stat.h> /* For STAT op */
#include <sys/types.h> /* For CHMOD op */
#include "token.h"

#define LEX  0	/* Reading from lexer, so below is pointless */
#define COMPILED 1 /* Reading from array */
#define SIZE 1024 /* Largest string allowed: 1023 characters */
#define JMPS 20 /* Twenty jumps allowed */

#define MFLOAT 0  /* FP mode */
#define MINT	1	/* Integer mode */

extern int brace; /* Brace count */
extern char *ptr; /* I can't get it to work any other way! */
extern int yyval; /* Value from lexer */
extern char *yytext; /* Text from lexer */
extern int lcount; /* Current line number: used in reporting exceptions */
extern int debug; /* Debug flag */
extern FILE *min; /* My Input */
extern FILE *mout; /* My Output */
extern int evalf; /* Where to parse from */
extern char *ceval; /* Current eval strings */

extern int pc; /* The program counter: twiddle it a bit if we want */
extern struct {
	short int op;
	char *text;
	short int line;
} *sbl;

unsigned char nmode = MINT; /* Start out working with ints */

void sighandler(int);
int strpostq(char, char*);
char *mmalloc(int);
void mfree(void *);
extern double popf(void);
extern int pushf(double); /* To avoid strange things */
int icmp(const int *, const int *); /* For sorting */
int scmp(const char**, const char**); /* For sorting */

int state = LEX; /* Current state - lexer or bytecode */
int sigs[30]; /* How many signals does your system have? */

struct fh {
	FILE 	*desc;	/* The file descriptor */
	char	*name;	/* The descriptor name */
	char	flag;		/* Input/Output */
} handles[256]; /* Once again, to be changed if you want. */

long int rval = 0; /* Return value */

eval (int inst, char *text) {
	time_t now; /* Needed for the gettime routines */
	void *handle; /* Dynamic library */
	struct tm *ntime; /* Ditto */
	struct stat sted; /* For stat routine */
	register long int op1; /* It's used most */
	long int  op2, op3, op4, op5, *iptr; /* Operands for when doing math */
	double fop1, fop2, fop3, fop4, fop5; /* and for floating point */
	int count;			 /* Counter when messing with whiles */
	char *toprint;		 /* String to print */
	unsigned char inp[SIZE];	 	 /* Que acabo de leer */
	unsigned char inp2[SIZE];		 /* Another input */
	unsigned char inp3[SIZE];		 /* Another input */
	unsigned char *sptr;				 /* Standard string pointer */
	unsigned char **tsort;			 /* Pointer to stuff I'm sorting */
	FILE	*cf, *caf; /* Current file in forf, workspace in fhandle */

	lcount = sbl[pc].line; /* For debugging reasons */

#ifndef SMALL
	if(debug)
		printinst(inst); /* If we're debugging print out the op */
#endif /* SMALL */
	/* Hints to speed up common operations */
	if(inst == sOUT)
		goto lsOUT;
	else if(inst == NUM)
		goto lNUM;
	else if(inst == TEXT)
		goto lTEXT;
	else if(inst == DUP)
		goto lDUP;
	else if(inst == sDUP)
		goto lsDUP;
	else if(inst == DROP)
		goto lDROP;
	else if(inst == sDROP)
		goto lsDROP;
	else if(inst == IF)
		goto lIF;
	else if(inst == CBRACE || inst == OBRACE || inst == GLABEL)
		return 0;

	/* Note that this is one giant switch statement */
	switch (inst) {
	case MINUS: /* 2 */
		if(nmode == MINT) {
			op2 = popn();	
			op1 = popn();
			pushn(op1 - op2);
		} else {
			fop2 = popf();
			fop1 = popf();
			pushf(fop1 - fop2);
		}
		break;
	case TIMES: /* 3 */
		if(nmode == MINT) 
			pushn(popn() * popn());
		else
			pushf(popf() * popf());
		break;
	case OVER: /* 4 */
		if(nmode == MINT) {
			op2 = popn();
			op1 = popn();
			if (op2 != 0) 
				pushn(op1 / op2);
			else {
				fprintf(stderr, "Error: line %d: divide %d by zero.\n", lcount, op1);
				exit(1);
			}
		} else {
			fop2 = popf();
			fop1 = popf();
			if (fop2 != 0)
				pushf(fop1 / fop2);
		}
		break;
	case MOD: /* 5 */
		if(nmode == MINT) {
			op2 = popn();
			op1 = popn();
			if (op2 != 0) 
				pushn(op1 % op2);
			else {
				fprintf(stderr, "Error: line %d: mod %d by zero.\n", lcount, op1);
				exit(1);
			}
		} else { 
			fop2 = popf();
			fop1 = popf();
			if(fop2 == 0) {
				fprintf(stderr, "Error: line %d: mod %f by zero.\n", lcount, fop1);
				exit(1);
			}
			/* At this point, I apply myself to some semifunctional code because
			 * whoever wrote the ANSI standard didn't see fit to include double
			 * modulus.
			 */
			 while(fop1 >= fop2)
				fop1 -= fop2; /* Use a looping solution */
			 pushf(fop1);
		}
		break;
	case TO: /* 6 */
		fop1 = popf();
		fop2 = popf();
		fop3 = pow(fop2, fop1);
		pushf(fop3);
		break;
	case OUT: /* 7 */
		if(nmode == MINT) {	
			op1 = popn();
			rval = fprintf(mout, "%d", op1);
		} else {
			fop1 = popf();
			rval = fprintf(mout, "%f", fop1);
		}
		fflush(mout);
		break;
	case IN: /* 8 */
		fgets(inp, sizeof(inp), min);
		if(nmode == MINT) {
			op1 = atoi(inp);
			pushn(op1);
		} else {
			fop1 = atof(inp);
			pushf(fop1);
		}
		break;
lNUM:
	case NUM: /* 9 */
		if(nmode == MINT) {
			strcpy(inp, text); /* Make copy */
			if(inp[0] == '0' && inp[1] == 'x')
				op1 = unhex(inp);
			else if(inp[0] == '0' && inp[1] == '\0')
				op1 = 0; /* Special case */
			else if(inp[0] == '0')
				op1 = unoct(inp);
			else
				op1 = atol(inp);
			pushn(op1);
		} else
			pushf((double)atof(text)); /* Do appropriate cast */
			break;
	case END: /* 10 */
#ifndef LIB
		exit(popn());
#endif
		break;
lDROP:
	case DROP: /* 11 */
		if(nmode == MINT) 
			popn();
		else
			popf();
		break;
lDUP:
	case DUP: /* 12 */
		if(nmode == MINT) {
			op1 = popn();	
			pushn(op1);
			pushn(op1);
		} else {
			fop1 = popf();
			pushf(fop1);
			pushf(fop1);
		}
		break;
	case PICK: /* 13 */
		op1 = popn() - 1;
		pushn(pickn(op1));
		break;
lTEXT:
	case TEXT: /* 14 */
		strcpy(inp, text);
		fix(inp);
		pushs(inp);
		break;
lsOUT:
	case sOUT: /* 15 */
		pops(&inp);
		rval = fprintf(mout, "%s", inp); /* Using fprintf for return value */
		fflush(stdout);
		break;
	case sIN: /* 16 */
		if(debug)
			printf("** IN\n");
		if(fgets(inp, sizeof(inp), min)) 
			pushs(inp);
		else
			pushs("EOF--EOF~~EOF--EOF"); /* Think anyone'd use this in a file */
		break;
	case sCHOMP: /* 17 */
		pops(&inp);
		inp[strlen(inp) - 1] = 0;
		pushs(inp);
		break;
	case tSTR: /* 18 */
		op1 = popn();
		sprintf(inp, "%d", op1);
		pushs(inp);
		break;
	case tNUM: /* 19 */
		pops(&inp);
		if(inp[0] == '0' && inp[1] == 'x')
			op1 = unhex(inp);
		else if(inp[0] == '0' && inp[1] == '\0')
			op1 = 0; /* Special case */
		else if(inp[0] == '0')
			op1 = unoct(inp);
		else
			op1 = atol(inp);
		pushn(op1);
		break;
	case sCAT: /* 20 */
		pops(&inp);
		pops(&inp2);
		strcat(inp2, inp);
		pushs(inp2);
		break;
	case OBRACE: /* 21 */
	case CBRACE: /* 22 */
		1;
		break;
	case SKIP: /* 23, actually unless */
 		op1 = brace; /* Store old value of brace counter */
		if(!popn()) { /* Do the mini-eval to avoid knocking out loops */
			pc++; /* Inifinite recursion is really not very good */
			for(;;) {
				if(sbl[pc].op == CBRACE) {
						break;
				} else {
					strcpy(inp, sbl[pc].text);
					eval(sbl[pc].op, inp);
				}
				pc++;
			}
			if(sbl[pc + 1].op != ELSE) /* As long as there's no else */
				return 0; /* It's true, so we can disregard it */
			++pc; /* Skip onto the else */
		}
		op1 = 0; /* Set bracket count to 0 */
		++pc; /* Skip over the else/if */
		for(;;) {
			if(sbl[pc].op == OBRACE)
				op1++;
			else if(sbl[pc].op == CBRACE)
				op1--;
			if(op1 == 0) /* At end */
				break;
			pc++; /* next */
		}
		if(sbl[pc + 1].op == ELSE) { /* Still something to do then */
			pc += 2; /* Skip over both else and if */
			for(;;) {
				if(sbl[pc].op == CBRACE) {
						break;
				} else {
					strcpy(inp, sbl[pc].text);
					eval(sbl[pc].op, inp);
				}
				pc++;
			}
		}
		break;
	case ATIME: /* 24 */
		op2 = popn();
		strcpy(inp, ctime((time_t *)&op2));
		pushs(inp);
		break;
	case AND: /* 25 */
		op1 = popn();
		op2 = popn();
		if(op1 && op2)
			pushn(1);
		else
			pushn(0);
		break;
	case OR: /* 26 */
		op1 = popn();
		op2 = popn();
		if(op1 || op2) 
			pushn(1);
		else
			pushn(0);
		break;
	case NOT: /* 27 */
		op1 = popn();
		pushn(!op1);
		break;
	case EQUALS: /* 28 */
		if(nmode == MINT) {
			op1 = popn();
			op2 = popn();
			if(op1 == op2)
				pushn(1);
			else
				pushn(0);
		} else 
			pushn(popf() == popf()); /* Abbreviated version */
		break;
	case MORE: /* 29 */
		if(nmode == MINT) {
			op1 = popn();
			op2 = popn();
			if(op2 > op1)
				pushn(1);
			else
				pushn(0);
		} else {
			fop1 = popf();
			fop2 = popf();
			pushn(fop2 > fop1);
		}
		break;
	case LESS: /* 30 */
		if(nmode == MINT) {
			op1 = popn();
			op2 = popn();
			if(op2 < op1)
				pushn(1);
			else
				pushn(0);
		} else {
			fop1 = popf();
			fop2 = popf();
			pushn(fop2 < fop1);
		}
		break;
	case NEQ: /* 31 */
		if(nmode == MINT) {
			op1 = popn();
			op2 = popn();
			if(op1 == op2) 
				pushn(0);
			else
				pushn(1);
		} else
			pushn(popf() != popf());
		break;
lsDROP:
	case sDROP: /* 32 */
		pops(&inp);
		break;
lsDUP:
	case sDUP: /* 33 */
		pops(&inp);
		pushs(inp);
		pushs(inp);
		break;
	case sPICK: /* 34 */
		op1 = popn() - 1;
		picks(op1);
		pushs(ptr);
		break;
lIF:
	case IF: /* 35 */
 		op1 = brace; /* Store old value of brace counter */
		if(popn()) { /* Do the mini-eval to avoid knocking out loops */
			pc++; /* Inifinite recursion is really not very good */
			for(;;) {
				if(sbl[pc].op == CBRACE) {
						break;
				} else {
					strcpy(inp, sbl[pc].text);
					eval(sbl[pc].op, inp);
				}
				pc++;
			}
			if(sbl[pc + 1].op != ELSE) /* As long as there's no else */
				return 0; /* It's true, so we can disregard it */
			++pc; /* Skip onto the else */
		}
		op1 = 0; /* Set bracket count to 0 */
		++pc; /* Skip over the else/if */
		for(;;) {
			if(sbl[pc].op == OBRACE)
				op1++;
			else if(sbl[pc].op == CBRACE)
				op1--;
			if(op1 == 0) /* At end */
				break;
			pc++; /* next */
		}
		if(sbl[pc + 1].op == ELSE) { /* Still something to do then */
			pc += 2; /* Skip over both else and if */
			for(;;) {
				if(sbl[pc].op == CBRACE) {
						break;
				} else {
					strcpy(inp, sbl[pc].text);
					eval(sbl[pc].op, inp);
				}
				pc++;
			}
		}
		break;
	case SWAP: /* 36 */
		op1 = popn();
		op2 = popn();
		pushn(op1);
		pushn(op2);
		break;
	case UC: /* 37 */
		pops(&inp);
		uc(&inp);
		pushs(inp);
		break;
	case LC: /* 38 */
		pops(&inp);
		lc(&inp);
		pushs(inp);
		break;
	case sSWAP: /* 39 */
		pops(&inp);
		pops(&inp2);
		pushs(inp);
		pushs(inp2);
		break;
	case WHILE: /* 40 */
		pc++; /* Skip WHILE */
		op1 = pc; /* Store position to jump */

		for(;;) {
			if(sbl[pc].op == CBRACE) {
				if(popn())
					pc = op1;
				else
					break;
			} else {
				strcpy(inp, sbl[pc].text);
				eval(sbl[pc].op, inp);
			}
			pc++;
		}
		break;
	case SUB: /* 41 */
		pushn(pc + 1); /* Let the jump be for one after */
		op1 = 0; /* Set bracket count to 0 */
		++pc; /* Skip over the sub */
		for(;;) {
			if(sbl[pc].op == OBRACE)
				op1++;
			else if(sbl[pc].op == CBRACE)
				op1--;
			if(op1 == 0) /* At end */
				break;
			pc++; /* next */
		}
		break;
	case REPEAT: /* 42 */
		pushr(rcc());
		op1 = popn(); /* Iterations */
		if(op1 == 0) { /* Special case */
			op1 = 0; /* Set bracket count to 0 */
			++pc; /* Skip over the if */
			for(;;) {
				if(sbl[pc].op == OBRACE)
					op1++;
				else if(sbl[pc].op == CBRACE)
					op1--;
				if(op1 == 0) /* At end */
					break;
				pc++; /* next */
			}
			return 0; /* Done with it */
		}
		pc++; /* Next instruction */
		op2 = pc; /* To jump back to... */
		for(op3 = 0; op3 < op1; /* Handled below */) {
			if(sbl[pc].op == CBRACE) {
				op3++; /* One count */
				stc(op3); /* Update counter */
				if(!(op3 < op1))
					break; /* done */
				else
					pc = op2; /* Reset that */
			} else {
				strcpy(inp, sbl[pc].text);
				eval(sbl[pc].op, inp);
			}
			pc++; /* Next instruction */
		}
		stc(popr());
		break;
	case CALL: /* 43 */
		op1 = pc; /* Store it */
		pc = popn(); 
		for(;;) {
			if(sbl[pc].op == CBRACE) {
				break;
			} else {
				strcpy(inp, sbl[pc].text);
				eval(sbl[pc].op, inp);
			}
			pc++;
		}
		pc = op1; /* Restore at previous location */
		break;
	case SEQ: /* 44 */
		pops(&inp);
		pops(&inp2);
		if(!strcmp(inp, inp2)) 
			pushn(1);
		else
			pushn(0);
		break;
	case PLUS: /* 45 */
		if(nmode == MINT)
			pushn(popn() + popn());
		else
			pushf(popf() + popf()); /* Don't worry about order */
		break;
	case FORMAT: /* 46 */
		pops(&inp);
		format(&inp);
		pushs(inp);
		break;
	case SPLIT: /* 47 */
		pops(&inp2);
		pops(&inp);
		split(inp, inp2);
	/* No 48 */
		break;
	case TRD: /* 49 */
		pops(&inp2);
		pops(&inp);
		erange(inp2); /* Expand ranges */
		for(op1 = 0; ;) {
			zap(&inp, inp2[op1]);
			op1++;
			if(inp2[op1] == 0)
				break;
		} 
		pushs(&inp);
		break;
	case CHR: /* 50 */
		inp[0] = popn();
		inp[1] = 0;
		pushs(inp);
		break;
	case ASC: /* 51 */
		pops(&inp);
		pushn((long)inp[0]);
		break;
	case OPENO: /* 52 */
		pops(&inp);
		mout = fopen(inp, "w");
		rval = (long int)mout;
		break;
	case OPENI: /*3 */
		pops(&inp);
		min = fopen(inp, "r");
		rval = (long int)min;
		break;
	case RESTOREI: /*4 */
		rval = fclose(min);
		min = stdin;
		break;
	case RESTOREO: /*5 */
		rval = fclose(min);
		mout = stdout;
		break;
	case NEOF: /*6 */
		pushs("EOF--EOF~~EOF--EOF"); 
		break;
	case PROMPT:  /* 57 */
		pops(&inp);
		rval = fprintf(stderr, "%s", inp);
		break;
	case dIN: /*8 */
		fgets(inp, sizeof(inp), stdin);
		if(!strcmp(inp, "quienes\n"))
			printf("SBL 0.2 (c) 1997, Jonathan Westhues\n");
		pushs(inp);
		break;
	case RAND: /*9 */
		pushf(rand() / (double)RAND_MAX); /* Now, between 0 and 1 */
		break;
	case SRAND: /*0 */
		srand(popn());
		break;
	case TIME: /*1 */
		time(&now);
		pushn(now);
		break;
	case VREF: /*2 */
		pops(&inp);
		op1 = getref(inp);
		pushn(op1); /* We now have the memory location of the var inp */
		break;
	case STC: /*3 */
		stc(popn());
		break;
	case RCC: /*4 */
		pushn(rcc());	
		break;
	case DEPTH: /*5 */
		pushn(depthn());
		break;
	case sDEPTH: /*6 */
		pushn(depths());
		break;
	case TR: /*7 */
		pops(&inp3);
		pops(&inp2);
		pops(&inp);
		/* Expand ranges before length check */
		erange(inp2);
		erange(inp3);
		if(strlen(inp3) != strlen(inp2)) {
			fprintf(stderr, "Error: line %d: tr with different lengths\n", lcount);
			exit(1);
			return 0;
		}
		tr(&inp, inp2, inp3);
		pushs(inp);
		break;
	case sLEN: /*8 */
		pops(&inp);
		pushn(strlen(inp));
		break;
	case sLEFT: /*9 */
		op1 = popn();
		pops(&inp);
		inp[op1] = 0;
		pushs(inp);
		break;
	case sRIGHT: /*0 */
		op1 = popn();
		pops(&inp);
		op1 = strlen(inp) - op1;
		toprint = inp;
		for(op2 = 0; op2 < op1; op2++)
			toprint++;
		pushs(toprint);
		break;
	case SYSTEM: /*1 */
		pops(&inp);
		rval = system(inp); /* Handle exit status */
		break;
	case SNEXT: /*2 */
		ststack(popn());
		break;
	case RENAME: /*3 */
		pops(inp); /* new */
		pops(inp2); /* old */
		rval = rename(inp2, inp);
		break;
	case STO: /*4 */
		pops(&inp2);
		pops(&inp);
		addvar(&inp, &inp2);
		break;
	case GET: /*5 */
		pops(&inp);
		getvar(&inp2, &inp);
		pushs(&inp2);
		break;
	case MRE: /*6 */
		pops(&inp);
		pushn(re_exec(inp));
		break;
	case SRE: /*7 */
		pops(&inp);
		re_comp(inp);
		break;
	case PIPEI: /*8 */
		pops(&inp);
		min = popen(inp, "r");
		pushn(min);
		break;
	case PIPEO: /*9 */
		pops(&inp);
		mout = popen(inp, "w");
		pushn(mout);
		break;
	case PIPEIC:  /* 80 */
		rval = pclose(min);
		break;
	case PIPEOC: /*1 */
		rval = pclose(mout);
		break;
	case SQRT: /*2 */
		op1 = popn();
		op2 = (long int)(sqrt(op1) * 1000);
		pushn(op2);
		break;
	case SIN: /*3 */
		fop1 = popf();
		fop2 = sin(fop1);
		pushf(fop2);
		break;
	case BTEXT: /*4 */
		fprintf(stderr, "Formats unsupported. It was a dumb idea anyways\n");
		break;
	case GETC: /*5 */
		op1 = getc(min);
		pushn(op1);
		break;
	case FORF: /* For files */ /* 86 */
		pops(&inp); /* inp is first file */
		cf = min; /* Save it */
		++pc;
		op1 = pc; /* Store position */

		if(!strcmp("EOF--EOF~~EOF--EOF", inp)) { /* Do an stdin loop */
			if(!fgets(inp2, sizeof(inp2), min))
				return 0; /* First one's a fail */
			pushs(inp2);
			for(;;) {
				if(sbl[pc].op == CBRACE) {
					if(fgets(inp2, sizeof(inp2), min)) {
						pc = op1;
						pushs(inp2);
					} else
						break;
				} else {
					strcpy(inp, sbl[pc].text);
					eval(sbl[pc].op, inp);
				}
				pc++;
			}
		} else { /* Files, then */
			cf = min;
			op1 = pc; /* Store position to jump */
			for(;;) {
				if(!strcmp("EOF--EOF~~EOF--EOF", inp))
					break; /* Done! */
				min = fopen(inp, "r"); /* Open the file */
				pc = op1; /* Reset */
				fgets(inp2, sizeof(inp2), min);
				pushs(inp2); /* Prep it */
				for(;;) {
					if(sbl[pc].op == CBRACE) {
						if(fgets(inp2, sizeof(inp2), min)) {
							pc = op1;
							pushs(inp2);
						} else
							break;
					} else {
						strcpy(inp, sbl[pc].text);
						eval(sbl[pc].op, inp);
					}
					pc++;
				}
				pops(inp);
			}
			min = cf; /* As before */
		}
		break;
	case FORK: /*7 */
		op1 = fork(); 
		pushn(op1);
		break;
	case sSUB: /*8 */
		pops(&inp); /* New string */
		pops(&inp2); /* Old string */
		pops(&inp3); /* String to tamper with */
		sub(inp2, inp, &inp3);
		pushs(inp3);
		break;
	case sPOS: /*9 */
		op1 = popn();
		pops(&inp);
		op2 = strpostq(op1, inp);
		pushn(op2);
		break;
	case SLEEP: /*0 */
		sleep(popn());
		break;
	case COS: /*2 */
		fop1 = popn();
		fop2 = cos(fop1);
		pushf(fop2);
		break;
	case TAN: /*3 */
		fop1 = popf();
		fop2 = tan(fop1);
		pushf(fop2);
		break;
	case LOGE: /*5 */
		fop1 = popf();
		fop2 = log(fop1);
		pushf(fop2);
		break;
	case LOG10: /*4 */
		fop1 = popf();
		fop2 = log10(fop1);
		pushf(fop2);
		break;
	case SIGNAL: /*6 */
		pops(inp); /* Signal */
		op2 = popn(); /* Sub */
		if(!strcmp(inp, "INT"))
			op1 = SIGINT;
		else if(!strcmp(inp, "HUP"))
			op1 = SIGHUP;
		else if(!strcmp(inp, "QUIT"))
			op1 = SIGQUIT;
		else if(!strcmp(inp, "PIPE"))
			op1 = SIGPIPE;
		else if(!strcmp(inp, "ALRM"))
			op1 = SIGALRM;
		else if(!strcmp(inp, "TERM"))
			op1 = SIGTERM;
		else if(!strcmp(inp, "CHLD"))
			op1 = SIGCHLD;
		else if(!strcmp(inp, "USR1"))
			op1 = SIGUSR1;
		else if(!strcmp(inp, "USR2"))
			op1 = SIGUSR2;
		else
			op1 = atoi(inp);
		sigs[op1] = op2; /* Set it up */
		signal(op1, sighandler);
		break;
	case RSIG: /*9 */
		pops(inp);
		if(!strcmp(inp, "INT"))
			op1 = SIGINT;
		else if(!strcmp(inp, "HUP"))
			op1 = SIGHUP;
		else if(!strcmp(inp, "QUIT"))
			op1 = SIGQUIT;
		else if(!strcmp(inp, "PIPE"))
			op1 = SIGPIPE;
		else if(!strcmp(inp, "ALRM"))
			op1 = SIGALRM;
		else if(!strcmp(inp, "TERM"))
			op1 = SIGTERM;
		else if(!strcmp(inp, "CHLD"))
			op1 = SIGCHLD;
		else if(!strcmp(inp, "USR1"))
			op1 = SIGUSR1;
		else if(!strcmp(inp, "USR2"))
			op1 = SIGUSR2;
		else
			op1 = atoi(inp);
		signal(op1, sighandler);
		break;
	case SUBSTR: /*7 */
		pops(inp);
		op1 = popn(); /* Length */
		op2 = popn(); /* Offset */
		ptr = inp;
		ptr += op2;
		ptr[op1] = 0; /* Truncate if needed */
		pushs(ptr);
		printf("Test\n");
		break;
	case LLREV: /*8 */
		pushn((long int)llrev((void *)popn()));
	/* 100 free */
		break;
	case REFS: /*01 */
		pops(&inp); /* Name */
		op1 = popn(); /* Ref */
		addref(op1, inp);
		break;
	case REFG: /*02 */
		pops(&inp);
		pushn((long int)seeref(inp));
		break;
	case HASHA: /*03 */
		pops(&inp); /* Key */
		pops(&inp2); /* Value */
		op1 = popn(); /* Hash reference */
		hashadd(inp2, inp, op1); /* Call it */
		break;
	case HASHL: /*04 */
		pops(&inp); /* Key */
		op1 = popn(); /* Value */
		hashget(&inp, op1); /* Do it */
		pushs(inp); /* hashlook scribbles over inp */
		break;
	case HASHN: /*05 */
		pushn((long int)newhash());
		break;
	case HASHK: /*06 */
		hashkeys(popn());
		break;
	case LLAT: /*07 */
		op1 = popn(); /* Position */
		pops(&inp); /* Value */
		llat(inp, op1, (void *)popn()); /* Call to hash.c */
		break;
	case LLADD: /*08 */
		pops(&inp); /* Value */
		lladd(inp, (void *)popn()); /* Add element */
		break;
	case LLLENGTH: /*09 */
		pushn(llelem((void *)popn()));
		break;
	case LLLOOK: /*10 */
		op1 = popn(); /* Place */
		lllook(inp, op1, (void *)popn()); /* Make the lookup */
		pushs(inp);
		break;
	case SUBC: /*11 */
		pushr(rcc());
		toprint = text;
		toprint++; /* Ditch the ampersand */
		op2 = seeref(toprint); /* Get value */
		/* Now, we do that actual call */
		op1 = pc; /* Store it */
		pc = op2;  /* From reference */
		for(;;) {
			if(sbl[pc].op == CBRACE) {
				break;
			} else {
				strcpy(inp, sbl[pc].text);
				eval(sbl[pc].op, inp);
			}
			pc++;
		}
		pc = op1; /* Restore at previous location */
		break;
	case VLOOK: /*12 */
		toprint = text; 
		toprint++; /* Ditch colon */
		getvar(&inp, toprint);
		pushs(inp);
		break;
	case OPENA: /*13 */
		pops(&inp);
		mout = fopen(inp, "a");
		rval = (long int)mout;
		break;
	case ALARM: /*14 */
		rval = alarm(popn());
		break;
	case WAITING: /*15 */
		rval = ioctl(0, FIONREAD, &op2);
		pushn(op2);
		break;
	case FOREVER: /*16 */
		pc++;
		op1 = pc; /* Store position to jump back to */
		for(;;) {
			if(sbl[pc].op == CBRACE)
				pc = op1;
			strcpy(inp, sbl[pc].text); /* Some routines scribble on strings */
			eval(sbl[pc].op, inp);
			pc++; /* Next inst */
		}
		break;
	case EXT: /* 117 */
		pops(&inp);
		ext_sbl(inp);
		break;
	case KILL: /*18 */
		pops(op1);
		pops(op2);
		rval = kill(op2, op1); /* First one's a signal, next one's a pid */
	/* 119 is break */
		break;
	case EXTC: /*20 */
		toprint = text;
		toprint++; /* Ditch slash */
		ext_sbl(toprint);
		break;
	case STAT: /*21 */
		pops(&inp);
		rval = stat(inp, &sted); /* Stat it */
		sprintf(inp, "%d", sted.st_dev); addvar(inp, "dev"); pushn(sted.st_dev);
		sprintf(inp, "%d", sted.st_ino); addvar(inp, "ino"); pushn(sted.st_ino);
		sprintf(inp, "%d", sted.st_mode); addvar(inp, "mode"); pushn(sted.st_mode);
		sprintf(inp, "%d", sted.st_nlink); addvar(inp, "nlink"); pushn(sted.st_nlink);
		sprintf(inp, "%d", sted.st_uid); addvar(inp, "uid"); pushn(sted.st_uid);
		sprintf(inp, "%d", sted.st_gid); addvar(inp, "gid"); pushn(sted.st_gid);
		sprintf(inp, "%d", sted.st_rdev); addvar(inp, "rdev"); pushn(sted.st_rdev);
		sprintf(inp, "%d", sted.st_size); addvar(inp, "size"); pushn(sted.st_size);
		sprintf(inp, "%d", sted.st_blksize); addvar(inp, "blksize"); pushn(sted.st_blksize);
		sprintf(inp, "%d", sted.st_blocks); addvar(inp, "blocks"); pushn(sted.st_blocks);
		sprintf(inp, "%d", sted.st_atime); addvar(inp, "atime"); pushn(sted.st_atime);
		sprintf(inp, "%d", sted.st_mtime); addvar(inp, "mtime"); pushn(sted.st_mtime);
		sprintf(inp, "%d", sted.st_ctime); addvar(inp, "ctime"); pushn(sted.st_ctime);
		break;
	case CHMOD: /*22 */
		pops(&inp);
		op1 = popn();
		rval = chmod(inp, op1);
		break;
	case UNLINK: /*23 */
		pops(&inp);
		rval = unlink(inp);
		break;
	case GETENV: /*24 */
		pops(&inp);
		toprint = getenv(inp);
		if(toprint == 0) { /* Null */
			rval = -1;
			pushs("");
		} else {
			pushs(toprint);
			rval = 0;
		}
		break;
	case SETENV: /* 125 */
		pops(&inp);
		pops(&inp2);
		rval = setenv(inp, strdup(inp2), 1); /* Always overwrite */
		break;
	case SREF: /*26 */
		pops(&inp); /* Array */
		pushn((long int)strdup(inp)); /* Push a reference to a copy */
		break;
	case IREF: /*29 */
		iptr = (long int *)mmalloc(sizeof(long int)); /* Allocate some space */
		*iptr = popn(); /* Set it to something */
		pushn((long int)iptr); /* We assume longs are as big as int *'s */
		break;
	case IDER: /*28 */
		iptr = (long int *)popn(); /* Reference is on the stack */
		pushn(*iptr); /* Add the actual value to the stack */
		break;
	case SDER: /*27 */
		sptr = (unsigned char *)popn(); /* Load in the address */
		strcpy(inp, sptr); /* No idea why I'm doing this */
		pushs(inp);
		break;
	case SETC: /*33 */
		pops(&inp);
		op1 = popn(); /* New value */
		inp[popn()] = op1;
		pushs(inp);
		break;
	case BOR: /*31 */
		pushn(popn() | popn());
		break;
	case BAND: /*30 */
		pushn(popn() & popn());
		break;
	case BNOT: /*32 */
		pushn(~popn());
		break;
	case RDIR: /*34 */
		pops(&inp);
		sprintf(inp2, "sh -c 'echo %s'", inp); /* Prepare command */
		cf = popen(inp2, "r");
		fgets(inp, sizeof(inp), cf); /* Get line */
		inp[strlen(inp) - 1] = 0;
		pclose(cf); /* Close pipe */
		ptr = inp;
		for(;;) { 
			if(*ptr == '\0')
				break;
			if(*ptr == ' ')
				*ptr = '\0';
			ptr++;
		}
		ptr[1] = 0; /* Double the nulls for EOF */
		ptr = inp;
		op1 = 0;
		pushs("EOF--EOF~~EOF--EOF"); 
		for(;;) {
			pushs(ptr); /* Push portion */
			op1++; /* One down */
			while(*ptr != '\0') 
				ptr++; /* Skip over string */
			ptr++;
			if(*ptr == 0)
				break;
		}
		pushn(op1);
		break;
	case LLUSHIFT: /*35 */
		pops(inp);
		llshift(inp, (void *)popn());
		break;
	case TEST: /*36 */
		op1 = text[1]; /* Switch on value of letter */
		pops(&inp);
		op2 = stat(inp, &sted); /* Stat it, with op2 = -1 if !exist */
		switch(op1) {
			case 'e':
				pushn(!op2); /* op2 is -1 if fails so ~op2 if false */
				break;
			case 'z':
				if(sted.st_size == 0)
					pushn(1);
				else
					pushn(0);
				break;
			case 's':
				pushn(sted.st_size); /* False if 0 */
				break;
			case 'M':
				op1 = time((time_t *)NULL); /* Get time */
				op1 -= sted.st_mtime; /* Get difference */
				fop1 = op1 / 86400.0; /* Convert to days */
				if(nmode == MINT)
					pushn((int)fop1);
				else
					pushf(fop1);
				break;
			case 'A':
				op1 = time((time_t *)NULL); /* Get time */
				op1 -= sted.st_atime; /* Get difference */
				fop1 = op1 / 86400.0; /* Convert to days */
				if(nmode == MINT)
					pushn((int)fop1);
				else
					pushf(fop1);
				break;
			case 'C':
				op1 = time((time_t *)NULL); /* Get time */
				op1 -= sted.st_atime; /* Get difference */
				fop1 = op1 / 86400.0; /* Convert to days */
				if(nmode == MINT)
					pushn((int)fop1);
				else
					pushf(fop1);
				break;
			case 'f':
				if(sted.st_mode & S_IFREG)
					pushn(1);
				else
					pushn(0);
				break;
			case 'd':
				pushn(sted.st_mode & S_IFDIR);
				break;
			case 'l':
				pushn(sted.st_mode & S_IFLNK);
				break;
			case 'p':
				pushn(sted.st_mode & S_IFIFO);
				break;
			case 'S':
				pushn(sted.st_mode & S_IFSOCK);
				break;
			case 'b':
				pushn(sted.st_mode & S_IFBLK);
				break;
			case 'c':
				pushn(sted.st_mode & S_IFCHR);
				break;
			case 'u':
				pushn(sted.st_mode & S_ISUID);
				break;
			case 'g':
				pushn(sted.st_mode & S_ISGID);
				break;
			case 'k':
				pushn(sted.st_mode & S_ISVTX);
				break;
			case 'r':
				if(geteuid() == sted.st_uid && (sted.st_mode & S_IRUSR))
					pushn(1);
				else if(getegid() == sted.st_gid && (sted.st_mode & S_IRGRP))
					pushn(1);
				else if(sted.st_mode & S_IROTH)
					pushn(1);
				else
					pushn(0); /* Failed */
				break;
			case 'w':
				if(geteuid() == sted.st_uid && (sted.st_mode & S_IWUSR))
					pushn(1);
				else if(getegid() == sted.st_gid && (sted.st_mode & S_IWGRP))
					pushn(1);
				else if(sted.st_mode & S_IWOTH)
					pushn(1);
				else
					pushn(0); /* Failed */
				break;
			case 'x':
				if(geteuid() == sted.st_uid && (sted.st_mode & S_IXUSR))
					pushn(1);
				else if(getegid() == sted.st_gid && (sted.st_mode & S_IXGRP))
					pushn(1);
				else if(sted.st_mode & S_IXOTH)
					pushn(1);
				else
					pushn(0); /* Failed */
				break;
			case 'R':
				if(getuid() == sted.st_uid && (sted.st_mode & S_IRUSR))
					pushn(1);
				else if(getgid() == sted.st_gid && (sted.st_mode & S_IRGRP))
					pushn(1);
				else if(sted.st_mode & S_IROTH)
					pushn(1);
				else
					pushn(0); /* Failed */
				break;
			case 'W':
				if(getuid() == sted.st_uid && (sted.st_mode & S_IWUSR))
					pushn(1);
				else if(getgid() == sted.st_gid && (sted.st_mode & S_IWGRP))
					pushn(1);
				else if(sted.st_mode & S_IWOTH)
					pushn(1);
				else
					pushn(0); /* Failed */
				break;
			case 'X':
				if(getuid() == sted.st_uid && (sted.st_mode & S_IXUSR))
					pushn(1);
				else if(getgid() == sted.st_gid && (sted.st_mode & S_IXGRP))
					pushn(1);
				else if(sted.st_mode & S_IXOTH)
					pushn(1);
				else
					pushn(0); /* Failed */
				break;
			case 'o':
				pushn(sted.st_uid == geteuid());
				break;
			case 'O':
				pushn(sted.st_uid == getuid());
				break;
			default:
				fprintf(stderr, "Error: line %d: bad file test %c\n", lcount, op1);
				exit(1);
		}
		break;
	case FLOAT: /*37 */
		fop1 = atof(yytext);
		pushf(fop1);
		break;
	case tFLOAT: /*38 */
		pops(&inp);
		pushf(atof(inp));
		break;
	case D2F: /*39 */
		op1 = popn();
		pushf((double)op1);
		break;
	case F2D: /*40 */
		fop1 = popf();
		pushn((int)fop1);
		break;
	case LLUNROLL: /*41 */
		llunroll((void *)popn());
		break;
	case S: /*42 */
		pops(&inp); /* New */
		pops(&inp2); /* Old */
		pops(&inp3); /* String */
		if(text[1] == 'g')
			while(sglob(inp3, inp2, inp)); /* Do until pat not found */
		else
			sglob(inp3, inp2, inp); /* Do a single iteration */
		pushs(inp3); /* Either way, I have to add it */
		break;
	case M: /*43 */
		pops(&inp); /* Pattern */
		pops(&inp2); /* String */
		pushn(aglob(inp2, inp)); /* Push result */
		break;
	case P: /*44 */
		pops(&inp); /* Pattern */
		pops(&inp2); /* String */
		pglob(inp2, inp); /* let pglob do the rest */
		break;
	case DUP2: /*45 */
		if(nmode == MINT) { /* Integer */
			op1 = popn();
			op2 = popn();
			pushn(op2);
			pushn(op1);
			pushn(op2);
			pushn(op1);
		} else {
			fop1 = popf();
			fop2 = popf();
			pushf(fop2);
			pushf(fop1);
			pushf(fop2);
			pushf(fop1);
		}
		break;
	case USE: /*46 */
#ifndef LIB
		pops(&inp);
		/* First, we check to see if it's a special directive */
		if(!strcmp(inp, "float")) {
			nmode = MFLOAT;
			return 0;
		} else if(!strcmp(inp, "int")) {
			nmode = MINT;
			return 0;
		}
		if(!strchr(inp, '.')) /* Check to see if it's a package or a file */
			strcat(inp, ".sbl"); /* Assume library */

		if(inp[strlen(inp) - 1] == 'l') /* .sbl: sbl routines */
			processf(inp); /* Just eval it */
		else
			externf(inp); /* Load in routines from library */
#endif
		break;
	case REVERSE: /*47 */
		pops(&inp);
		reverse(&inp); /* All the work is in string.c */
		pushs(inp);
		break;
	case LLAMA: /*48 */
#ifndef LIB
		docall(); /* Make a call: look in module.c for details */
#endif /* LIB */
		break;
	case LLPOP: /*49 */
		llpop(inp, (void *)popn());
		pushs(inp); /* Return value */
		break;
	case LLSET: /*50 */
		op1 = popn();
		pops(inp);
		llset(inp, op1, (void *)popn());
		break;
	case CHDIR: /*51 */
		pops(inp);
		rval = chdir(inp);
		break;
	case RLOOK: /*52 */
		ptr = text;
		ptr++;
		pushn((long int)seeref(ptr));
		break;
	case FOUT: /*53 */
		pops(inp);
		fout(inp);
		break;
	case tLIST: /*54 */
		op1 = popn(); /* Number of iterations */
		op2 = newhash(); /* Create the list */
		for(op3 = 0; op3 < op1 ;op3++) { /* Specified # of times */
			pops(inp);
			lladd(inp, (void *)op2); /* Add it */
		}
		pushn(op2); /* Finally, push the list */
		break;
	case VSET: /*55 */
		ptr = text;
		ptr++; /* Skip the = */
		pops(inp);
		addvar(inp, ptr); /* Do it */
		break;
	case ISET: /*56 */
		ptr = text;
		ptr++; /* Skip the bracket */
		addref(popn(), ptr);
		break;
	case LLCAT: /*57 */
		op1 = popn();
		pushn(llcat(op1, popn()));
		break;
	case LLDUP: /*58 */
		pushn(lldup(popn()));
		break;
	case GFILE: /*59 */
		pops(inp); /* String */
		for(op1 = 0; op1 < 256; op1++) {
			if(!strcmp(inp, handles[op1].name))
				break; /* Got it */
		}
		if(op1 >= 255) {
			fprintf(stderr, "Error: line %d: bad filehandle '%s'\n", lcount, inp);
			exit(1);
		}
		if(handles[op1].flag == 'r' || handles[op1].flag == 'R')
			min = handles[op1].desc;
		else
			mout = handles[op1].desc;
		break;
	case SFILE: /*60 */
		pops(inp);
		op2 = popn();
		for(op1 = 0; op1 < 256; op1++) {
			if(!handles[op1].name)
				break;
		}
		if(op1 >= 255) {
			fprintf(stderr, "Error: line %d: out of filehandles", lcount, inp);
			exit(1);
		}
		handles[op1].name = strdup(inp); /* Name it */
		if(op2 == 'r' || op2 == 'R')
			handles[op1].desc = min;
		else
			handles[op1].desc = mout;
		handles[op1].flag = op2;
		break;
	case FGET: /*61 */
		strcpy(inp, text); /* Copy */
		inp[strlen(inp) - 1] = '\0'; /* Clear out the > */
		/* Following stuff same as before */
		for(op1 = 0; op1 < 256; op1++) {
			if(!strcmp(inp, handles[op1].name))
				break; /* Got it */
		}
		if(op1 >= 255) {
			fprintf(stderr, "Error: line %d: bad filehandle '%s'\n", lcount, inp);
			exit(1);
		}
		if(handles[op1].flag == 'r' || handles[op1].flag == 'R')
			min = handles[op1].desc;
		else
			mout = handles[op1].desc;
		break;
	case FSET: /*62 */
		strcpy(inp, text + 1); /* Skip > */
		/* Following stuff identical to SFILE */
		op2 = popn();
		for(op1 = 0; op1 < 256; op1++) {
			if(!handles[op1].name)
				break;
		}
		if(op1 >= 255) {
			fprintf(stderr, "Error: line %d: out of filehandles", lcount, inp);
			exit(1);
		}
		handles[op1].name = strdup(inp); /* Name it */
		if(op2 == 'r' || op2 == 'R')
			handles[op1].desc = min;
		else
			handles[op1].desc = mout;
		handles[op1].flag = op2;
		break;
	case SORT: /*63 */
		op1 = popn(); /* Number of elements */
		iptr = (long *)mmalloc(op1 * sizeof(long)); /* Allocate */
		for(op2 = 0; op2 < op1; op2++)
			iptr[op2] = popn(); /* Assign */
		qsort(iptr, op1, sizeof(int), icmp); /* Call qsort for the sort */
		for(op2 = 0; op2 < op1; op2++)
			pushn(iptr[op2]);
		mfree(iptr);
		break;
	case sSORT: /*64 */
		op1 = popn(); /* No. of elements */
		tsort = (char **)mmalloc(op1 * sizeof(char *)); /* Allocate */
		for(op2 = 0; op2 < op1; op2++) {
			pops(inp);
			tsort[op2] = strdup(inp); /* Make a copy */
		}
		qsort(tsort, op1, sizeof(char *), scmp); /* Quicksort */
		for(op2 = 0; op2 < op1; op2++) {
			pushs(tsort[op2]);
			mfree(tsort[op2]); /* Free up the string */
		}
		mfree(tsort); /* Free the array */
		break;
	case RE: /*65 */
		ptr = text;
		ptr += 2; /* Skip leading ~/ */
		ptr[strlen(ptr) - 1] = 0; /* Skip trailing */
		pushs(ptr); /* Done */
		break;
	case TICK: /*66 */
		ptr = text;
		ptr++;
		ptr[strlen(ptr) - 1] = 0; /* Skip trailing ` */
		op1 = 0;
		cf = popen(ptr, "r");
		while(fgets(inp, sizeof(inp), cf))
			pushs(inp), op1++;
		pushn(op1);
		pclose(cf);
		break;
	case LLDEL: /*67 */
		op1 = popn(); /* Element */
		lldel(op1, (void *)popn());
		break;
	case RVAL: /*68 */
		pushn(rval);
		break;
	case ELSE: /*69 */
		/* If we tried to eval an else, something's quite wrong */
		fprintf(stderr, "Error: line %d: dangling else clause\n", lcount);
		exit(1);
		break;
	case GLABEL: /* 170 */
		/* Goto label */
		break;
	case GOTO: /* 171 */
		pops(inp); /* The label */
		for(pc = 0;; pc++) {
			if(!strcmp(sbl[pc].text, inp))
				break; /* At the label */
		}
		break;
	case QMATCH: /* 172 */
		ptr = text;
		ptr += 2; /* Skip m and slash */
		ptr[strlen(ptr) - 1] = '\0'; /* Skip trailing slash */
		pops(inp);
		strcpy(inp2, ptr);
		pushn(aglob(inp, inp2)); /* Do the match */
		break;
	case QSUB: /* 173 */
		ptr = text;
		ptr += 2; /* Skip the slash and s */
		toprint = strchr(ptr, '/'); /* Find division */
		*toprint = '\0'; /* Now, ptr is the old text */
		toprint++;
		if(toprint[strlen(toprint) - 1] == '/')
			op1 = 0, toprint[strlen(toprint) - 1] = '\0'; /* toprint is the new */
		else
			op1 = 1, toprint[strlen(toprint) - 2] = '\0'; /* global */
		pops(inp);
		strcpy(inp2, ptr);
		strcpy(inp3, toprint);
		while(sglob(inp, inp2, inp3) && op1)
			; /* Do nothing */
		pushs(inp);
		break;
	}
}

int pcopy (char *dest, char *source) { /* pcopy: copy strings byte-for-byte */
	int c;
	for(c = 0; c < SIZE; c++) { /* I can get away with this because strings are */
		dest[c] = source[c]; /* all going to be 1k bytes */
		if(source[c] == 0)
			break;
	}
}

char *mmalloc(int size) { /* mmalloc: do malloc with safety check */
	char *ptr;
	ptr = (char *)malloc(size);
	if(ptr == 0) {
		fprintf(stderr, "Error: line %d: out of memory\n", lcount);
		exit(1);
	}
	return ptr;
}

void mfree(void *space) { /* Debugging version of free */
	free(space);
}

int strpostq (char mc, char *str) { /* strpostq: find position of string */
	char *ptr;
	int c = 0;
	ptr = str;

	for(;;) {
		c++;
		if(*ptr == mc)
			return c;
		if(*ptr == 0)
			return 0;
		ptr++;
	}
}

int sub(char *old, char *new, char *tamper) { 
	char *ptr;
	char *ptr2;
	char small[2];
	char *work;
	int pos, cnt;

	work = (char *)mmalloc(strlen(tamper) + 2); /* Get stringspace */
	strcpy(work, tamper);

	ptr = work; /* Load start */
	for(;;) {
		pos = cnt = 0;
		if(ptr == 0) 
			return 0;
		ptr2 = ptr;
		for(;;) {
			if(old[cnt] == 0) {
				pos = 1;
				break;
			}
			if(*ptr2 != old[cnt])
				break;
			ptr2++;
			cnt++;
		}
		if(pos == 1) 
			break;
		ptr++;
	}
	pos = ptr - work;
	cnt = 0;
	tamper[0] = 0; /* Clear the string */
	for(;;) {
		if(cnt != pos) {
			small[0] = work[cnt];
			small[1] = 0;
			strcat(tamper, small);
			cnt++;
		} else {
			strcat(tamper, new);
			cnt += strlen(old);
		}
		if(work[cnt] == 0)
			break;
	}
	mfree(work);
	return 0;
}

void sighandler(int signal) {
	int op1;
	char inp[1024];
	op1 = pc; /* Store it */
	pc = sigs[signal]; /* Load to appropriate point */
	for(;;) {
		if(sbl[pc].op == CBRACE) {
			break;
		} else {
			strcpy(inp, sbl[pc].text);
			eval(sbl[pc].op, inp);
		}
		pc++;
	}
	pc = op1; /* Restore at previous location */
}

int icmp(const int *a, const int *b) {
	if(*a < *b)
		return 1;
	else if(*a == *b)
		return 0;
	else
		return -1;
}

int scmp(const char **a, const char **b) {
	return strcmp(*b, *a); /* Note swap: keeps ordering consistent */
}
