#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "token.h"

extern int lcount; /* Linecount */

int pc = 0; /* Program counter */

struct prog {
	short int op; /* The opcode, for faster lookup */
	char *text; /* Full text of command, for TEXT and friends */
	short int line; /* Line number */
};

struct prog *sbl; /* Define the program */
extern char *yytext;
extern long yyval;

int compilep(int howmany) { /* compile: read in a program, compiling as we go */
	int count = 0, ret;
	char *ptr;
	sbl = malloc(howmany * sizeof(struct prog)); /* Get as many toks as needed */
	while(cone())
		; /* Do nothing */
	pc = 0; /* Start over */
	for(;;) {
		if(sbl[pc].op == 0)
			break;
		lcount = sbl[pc].line;
		eval(sbl[pc].op, sbl[pc].text);
		pc++; /* Next instruction */
	}
	return 0;
}


int cone(void) {
	int ret;
	char *ptr;

	ret = yylex();
	if(ret == USE && yytext[0] == 'U') {
		yylex(); /* Discard return value */
		ptr = yytext;
		if(*ptr == '&')
			ptr++;
		else if(*ptr == '"') {
			ptr++;
			ptr[strlen(ptr) - 1] = 0;
		}
		if(ptr[strlen(ptr) - 1] == 'l')
			processf(ptr);
		else
			externf(ptr);
		--pc; /* Compensate for no addtion */
	} else {
		sbl[pc].op = ret;
		sbl[pc].text = strdup(yytext);
		sbl[pc].line = lcount;
	}
	if(ret == 0) {
		return 0; /* Done! */
	}
	pc++;
	return 1;
}

toks(char *file) { /* toks: return approximate number of tokens in a file */
	char *ptr;
	char line[100];
	int total = 0;
	FILE *f;
	f = fopen(file, "r"); /* Already know it's good */
	while(fgets(line, sizeof(line), f)) {
		ptr = line;
		if(strstr(line, "Use"))
			total += 100; /* Jump wildly */
		for(;;) {
			while(*ptr == ' ' || *ptr == '\t' || *ptr == '\n')
				break;
			if(*ptr == '\0')
				break;
			total++;
			while(*ptr != ' ' && *ptr != '\t' && *ptr != '\n')
				break;
			if(*ptr == '\0')
				break;
			ptr++;
		}
	}
	return total + 10; /* Allow a bit of leeway */
}
