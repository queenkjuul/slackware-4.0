
/* Generated source code from mkdebug.sb */

int printinst(int inst) {
	if(inst == 45)
		printf("** INST PLUS\n");
	else if(inst == 2)
		printf("** INST MINUS\n");
	else if(inst == 3)
		printf("** INST TIMES\n");
	else if(inst == 4)
		printf("** INST OVER\n");
	else if(inst == 5)
		printf("** INST MOD\n");
	else if(inst == 6)
		printf("** INST TO\n");
	else if(inst == 7)
		printf("** INST OUT\n");
	else if(inst == 8)
		printf("** INST IN\n");
	else if(inst == 9)
		printf("** INST NUM\n");
	else if(inst == 10)
		printf("** INST END\n");
	else if(inst == 11)
		printf("** INST DROP\n");
	else if(inst == 12)
		printf("** INST DUP\n");
	else if(inst == 13)
		printf("** INST PICK\n");
	else if(inst == 14)
		printf("** INST TEXT\n");
	else if(inst == 15)
		printf("** INST sOUT\n");
	else if(inst == 16)
		printf("** INST sIN\n");
	else if(inst == 17)
		printf("** INST sCHOMP\n");
	else if(inst == 18)
		printf("** INST tSTR\n");
	else if(inst == 19)
		printf("** INST tNUM\n");
	else if(inst == 20)
		printf("** INST sCAT\n");
	else if(inst == 21)
		printf("** INST OBRACE\n");
	else if(inst == 22)
		printf("** INST CBRACE\n");
	else if(inst == 23)
		printf("** INST SKIP\n");
	else if(inst == 24)
		printf("** INST ATIME\n");
	else if(inst == 25)
		printf("** INST AND\n");
	else if(inst == 26)
		printf("** INST OR\n");
	else if(inst == 27)
		printf("** INST NOT\n");
	else if(inst == 28)
		printf("** INST EQUALS\n");
	else if(inst == 29)
		printf("** INST MORE\n");
	else if(inst == 30)
		printf("** INST LESS\n");
	else if(inst == 31)
		printf("** INST NEQ\n");
	else if(inst == 32)
		printf("** INST sDROP\n");
	else if(inst == 33)
		printf("** INST sDUP\n");
	else if(inst == 34)
		printf("** INST sPICK\n");
	else if(inst == 35)
		printf("** INST IF\n");
	else if(inst == 36)
		printf("** INST SWAP\n");
	else if(inst == 37)
		printf("** INST UC\n");
	else if(inst == 38)
		printf("** INST LC\n");
	else if(inst == 39)
		printf("** INST sSWAP\n");
	else if(inst == 40)
		printf("** INST WHILE\n");
	else if(inst == 41)
		printf("** INST SUB\n");
	else if(inst == 42)
		printf("** INST REPEAT\n");
	else if(inst == 43)
		printf("** INST CALL\n");
	else if(inst == 44)
		printf("** INST SEQ\n");
	else if(inst == 46)
		printf("** INST FORMAT\n");
	else if(inst == 47)
		printf("** INST SPLIT\n");
	else if(inst == 49)
		printf("** INST TRD\n");
	else if(inst == 50)
		printf("** INST CHR\n");
	else if(inst == 51)
		printf("** INST ASC\n");
	else if(inst == 52)
		printf("** INST OPENO\n");
	else if(inst == 53)
		printf("** INST OPENI\n");
	else if(inst == 54)
		printf("** INST RESTOREI\n");
	else if(inst == 55)
		printf("** INST RESTOREO\n");
	else if(inst == 56)
		printf("** INST NEOF\n");
	else if(inst == 57)
		printf("** INST PROMPT\n");
	else if(inst == 58)
		printf("** INST dIN\n");
	else if(inst == 59)
		printf("** INST RAND\n");
	else if(inst == 60)
		printf("** INST SRAND\n");
	else if(inst == 61)
		printf("** INST TIME\n");
	else if(inst == 62)
		printf("** INST VREF\n");
	else if(inst == 63)
		printf("** INST STC\n");
	else if(inst == 64)
		printf("** INST RCC\n");
	else if(inst == 65)
		printf("** INST DEPTH\n");
	else if(inst == 66)
		printf("** INST sDEPTH\n");
	else if(inst == 67)
		printf("** INST TR\n");
	else if(inst == 68)
		printf("** INST sLEN\n");
	else if(inst == 69)
		printf("** INST sLEFT\n");
	else if(inst == 70)
		printf("** INST sRIGHT\n");
	else if(inst == 71)
		printf("** INST SYSTEM\n");
	else if(inst == 72)
		printf("** INST SNEXT\n");
	else if(inst == 73)
		printf("** INST RENAME\n");
	else if(inst == 74)
		printf("** INST STO\n");
	else if(inst == 75)
		printf("** INST GET\n");
	else if(inst == 76)
		printf("** INST MRE\n");
	else if(inst == 77)
		printf("** INST SRE\n");
	else if(inst == 78)
		printf("** INST PIPEI\n");
	else if(inst == 79)
		printf("** INST PIPEO\n");
	else if(inst == 80)
		printf("** INST PIPEIC\n");
	else if(inst == 81)
		printf("** INST PIPEOC\n");
	else if(inst == 82)
		printf("** INST SQRT\n");
	else if(inst == 83)
		printf("** INST SIN\n");
	else if(inst == 84)
		printf("** INST BTEXT\n");
	else if(inst == 85)
		printf("** INST GETC\n");
	else if(inst == 86)
		printf("** INST FORF\n");
	else if(inst == 87)
		printf("** INST FORK\n");
	else if(inst == 88)
		printf("** INST sSUB\n");
	else if(inst == 89)
		printf("** INST sPOS\n");
	else if(inst == 90)
		printf("** INST JUMP\n");
	else if(inst == 91)
		printf("** INST SLEEP\n");
	else if(inst == 92)
		printf("** INST COS\n");
	else if(inst == 93)
		printf("** INST TAN\n");
	else if(inst == 94)
		printf("** INST LOG10\n");
	else if(inst == 95)
		printf("** INST LOGE\n");
	else if(inst == 96)
		printf("** INST SIGNAL\n");
	else if(inst == 97)
		printf("** INST SUBSTR\n");
	else if(inst == 98)
		printf("** INST LLREV\n");
	else if(inst == 99)
		printf("** INST RSIG\n");
	else if(inst == 100)
		printf("** INST EVAL\n");
	else if(inst == 101)
		printf("** INST REFS\n");
	else if(inst == 102)
		printf("** INST REFG\n");
	else if(inst == 103)
		printf("** INST HASHA\n");
	else if(inst == 104)
		printf("** INST HASHL\n");
	else if(inst == 105)
		printf("** INST HASHN\n");
	else if(inst == 106)
		printf("** INST HASHK\n");
	else if(inst == 107)
		printf("** INST LLAT\n");
	else if(inst == 108)
		printf("** INST LLADD\n");
	else if(inst == 109)
		printf("** INST LLLENGTH\n");
	else if(inst == 110)
		printf("** INST LLLOOK\n");
	else if(inst == 111)
		printf("** INST SUBC\n");
	else if(inst == 112)
		printf("** INST VLOOK\n");
	else if(inst == 113)
		printf("** INST OPENA\n");
	else if(inst == 114)
		printf("** INST ALARM\n");
	else if(inst == 115)
		printf("** INST WAITING\n");
	else if(inst == 116)
		printf("** INST FOREVER\n");
	else if(inst == 117)
		printf("** INST EXT\n");
	else if(inst == 118)
		printf("** INST KILL\n");
	else if(inst == 119)
		printf("** INST BREAK\n");
	else if(inst == 120)
		printf("** INST EXTC\n");
	else if(inst == 121)
		printf("** INST STAT\n");
	else if(inst == 122)
		printf("** INST CHMOD\n");
	else if(inst == 123)
		printf("** INST UNLINK\n");
	else if(inst == 124)
		printf("** INST GETENV\n");
	else if(inst == 125)
		printf("** INST SETENV\n");
	else if(inst == 126)
		printf("** INST IDER\n");
	else if(inst == 127)
		printf("** INST IREF\n");
	else if(inst == 128)
		printf("** INST SDER\n");
	else if(inst == 129)
		printf("** INST SREF\n");
	else if(inst == 130)
		printf("** INST BAND\n");
	else if(inst == 131)
		printf("** INST BOR\n");
	else if(inst == 132)
		printf("** INST BNOT\n");
	else if(inst == 133)
		printf("** INST SETC\n");
	else if(inst == 134)
		printf("** INST RDIR\n");
	else if(inst == 135)
		printf("** INST LLUSHIFT\n");
	else if(inst == 136)
		printf("** INST TEST\n");
	else if(inst == 137)
		printf("** INST FLOAT\n");
	else if(inst == 138)
		printf("** INST tFLOAT\n");
	else if(inst == 139)
		printf("** INST D2F\n");
	else if(inst == 140)
		printf("** INST F2D\n");
	else if(inst == 141)
		printf("** INST LLUNROLL\n");
	else if(inst == 142)
		printf("** INST S\n");
	else if(inst == 143)
		printf("** INST M\n");
	else if(inst == 144)
		printf("** INST P\n");
	else if(inst == 145)
		printf("** INST DUP2\n");
	else if(inst == 146)
		printf("** INST USE\n");
	else if(inst == 147)
		printf("** INST REVERSE\n");
	else if(inst == 148)
		printf("** INST LLAMA\n");
	else if(inst == 149)
		printf("** INST LLPOP\n");
	else if(inst == 150)
		printf("** INST LLSET\n");
	else if(inst == 151)
		printf("** INST CHDIR\n");
	else if(inst == 152)
		printf("** INST RLOOK\n");
	else if(inst == 153)
		printf("** INST FOUT\n");
	else if(inst == 154)
		printf("** INST tLIST\n");
	else if(inst == 155)
		printf("** INST VSET\n");
	else if(inst == 156)
		printf("** INST ISET\n");
	else if(inst == 157)
		printf("** INST LLCAT\n");
	else if(inst == 158)
		printf("** INST LLDUP\n");
	else if(inst == 159)
		printf("** INST GFILE\n");
	else if(inst == 160)
		printf("** INST SFILE\n");
	else if(inst == 161)
		printf("** INST FSET\n");
	else if(inst == 162)
		printf("** INST FGET\n");
	else if(inst == 163)
		printf("** INST SORT\n");
	else if(inst == 164)
		printf("** INST sSORT\n");
	else if(inst == 165)
		printf("** INST RE\n");
	else if(inst == 166)
		printf("** INST TICK\n");
	else if(inst == 167)
		printf("** INST LLDEL\n");
	else if(inst == 168)
		printf("** INST RVAL\n");
	else if(inst == 169)
		printf("** INST ELSE\n");
	else if(inst == 170)
		printf("** INST GLABEL\n");
	else if(inst == 171)
		printf("** INST GOTO\n");
}
