
echo -n "Command: "
read OP
echo -n "Description: "
read DESC
echo "&HEAD" > "$OP.sbd"
echo $OP >> "$OP.sbd"
echo "&SYN" >> "$OP.sbd"
echo "$OP : $DESC" >> "$OP.sbd"
echo "&D" >> "$OP.sbd"
echo Paramaters follow:
cat >> "$OP.sbd"
echo "&" >> "$OP.sbd"
echo >> "$OP.sbd"
echo Text:
cat >> "$OP.sbd"
echo -n "See also: "
read SEE
echo "&SEE" >> "$OP.sbd"
echo $SEE >> "$OP.sbd"
