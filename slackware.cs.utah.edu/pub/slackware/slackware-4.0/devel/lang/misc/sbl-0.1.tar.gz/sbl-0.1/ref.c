#include <stdio.h>
#include <string.h>

#define HS 32 /* Size of hash */

extern int lcount; /* For errors */

struct tree {
	struct tree *left;
	struct tree *right;
	void *val; /* Heaven only knows what this could point to */
	unsigned char *name;
} *vars[HS]; /* Subscripts are because of hash */

void addref(void *ref, char *name) { /* Look! No recursion! */
	struct tree *flip; /* One to flip through on */

	flip = vars[hash(name)]; /* Initialize code */

	if(flip == NULL) { /* No variables yet */
		flip = (struct tree *)mmalloc(sizeof(struct tree)); /* Macro? */
		flip->name = strdup(name);
		flip->val = ref;
		flip->right = 0; /* Clear */
		flip->left = 0;
		vars[hash(name)] = flip; /* Set it */
		return;
	}
	for(;;) {
		if(flip == NULL) {
			fprintf(stderr, "Fatal sbl error: bailing out\n");
			exit(1);
		}
		if(strcmp(name, flip->name) == 0) { /* Already in table */
			flip->val = ref;
			return; /* Easy */
		} else if(strcmp(name, flip->name) < 0) { /* Left node */
			if(flip->left == NULL) { /* Our place */
				flip->left = (struct tree *)mmalloc(sizeof(struct tree));
				flip->left->name = strdup(name);
				flip->left->val = ref;
				flip->left->left = 0;
				flip->left->right = 0;
				return;
			} else
				flip = flip->left; /* Follow tree */
		} else if(strcmp(name, flip->name) > 0) { /* Right node */
			if(flip->right == NULL) { /* Found it */
				flip->right = (struct tree *)mmalloc(sizeof(struct tree));
				flip->right->name = strdup(name);
				flip->right->val = ref;
				flip->right->left = 0;
				flip->right->right = 0;
				return;
			} else
				flip = flip->right;
		}
	}
	return; /* This will never be reached */
}

void *seeref(char *name) { /* getref: return a reference */
	struct tree *flip;

	flip = vars[hash(name)]; /* Hash function speeds things up lots */

	for(;;) {
		if(flip == NULL) { /* Not found */
			fprintf(stderr, "Error: line %d: bad ivar '%s'\n", lcount, name);
			fprintf(stderr, "	Maybe an incorrectly spelt commmand?\n"); 
			exit(1);
			return;
		}
		if(strcmp(flip->name, name) == 0) { /* Got it */
			return flip->val;
		} else if(strcmp(flip->name, name) > 0) { /* Note all's backwards */
			flip = flip->left;
		} else if(strcmp(flip->name, name) < 0) {
			flip = flip->right;
		}
	}
	return; /* Not reached */
}

int isintree(char *name) { /* isintree: return true if variable exists */
	struct tree *flip;
	flip = vars[hash(name)]; /* For speed */
	for(;;) {
		if(flip == NULL)
			return 0; /* Doesn't exist */
		if(strcmp(flip->name, name) == 0)
			return 1; /* Found */
		else if(strcmp(flip->name, name) > 0)
			flip = flip->left;
		else if(strcmp(flip->name, name) < 0)
			flip = flip->right;
	}
	return -1; /* Error */
}
