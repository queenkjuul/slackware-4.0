#include "regexp.h" /* Using local, as of yet untouched, re's */
#include <stdio.h>
#include <string.h>

extern int lcount; /* Line counter */

int aglob(char *string, char *pattern) {
	regexp *mr; /* My regular expression */
	char sub[128], small[2] = {0, 0}; /* Substring */
	int res, c;

	rfix(pattern); /* Change extensions to normal */
	mr = regcomp(pattern); /* Compile */
	rcheck(mr);
	res = regexec(mr, string); /* Compute and return */
	for(c = 0; c < 10; ++c) { /* For each substring */
		small[0] = c + '0'; /* Quick convert */
		if(mr->startp[c] && mr->endp[c]) { /* Sanity check */
			strcpy(sub, mr->startp[c]); 
			sub[mr->endp[c] - mr->startp[c]] = 0; /* Truncate as instructed */
			addvar(sub, small); /* Make the note */
		} else
			addvar("", small);
	}
	free(mr);
	return res;
}

sglob(char *string, char *old, char *new) {
	regexp *mr; /* As implied */
	char buf[1024], stored;

	rfix(old); /* Fix it */
	mr = regcomp(old);
	rcheck(mr);
	if(!regexec(mr, string))
		return 0;
	trans(new, mr); /* Translate \x escapes to text before wiping stuff out */
	mr->startp[0][0] = '\0'; /* We now null-terminate that one */
	strcpy(buf, string); /* Add the new-and-improved version without trailing junk */
	strcat(buf, new); /* Add it on */
	strcat(buf, mr->endp[0]); /* Add on the rest */
	strcpy(string, buf); /* Now, the return is set */
	free(mr);
	return 1; /* If we're doing globals */
}

pglob(char *string, char *pat) {
	int cnt = 1; /* Always one element */
	char *sptr;
	regexp *mr;

	rfix(pat); /* Make changes necessary */
	mr = regcomp(pat); /* Compile the pattern */
	rcheck(mr);
	sptr = string;
	while(regexec(mr, sptr)) { /* While something matches */
		++cnt; /* Augment */
		mr->startp[0][0] = '\0'; /* Null-terminate */
		pushs(sptr); /* Add it */
		sptr = mr->endp[0]; /* Set it to next possibility */
	}
	pushs(sptr); /* Add the final element */
	pushn(cnt); /* Total # matched */
	free(mr);
}

rcheck(void *p) {
	if(!p) {
		fprintf(stderr, "Error: line %d: bad regexp\n", lcount);
		exit(1);
	}
}

regerror(char *str) {
	fprintf(stderr, "Error: line %d: regexp: %s\n", lcount, str);
}

rfix(char *str) { /* rfix: translate re extensions to standard ones */
	char *dest, *rs, *source, *ptr;
	char buf[128];
	int cnt;
	rs = strdup(str);
	source = rs; /* Store that */
	dest = str; /* Initialize */

	for(;;) {
		if(*source == '\0')
			break;
		if(*source == '\\') { /* Meaning a specialized class */
			source++;
			switch (*source) {
				case 's':
					mapp(dest, "[ \t\n]");
					dest += 5; /* Advance */
					break;
				case 'S':
					mapp(dest, "[^ \t\n]");
					dest += 6;
					break;
				case 'd':
					mapp(dest, "[0-9]");
					dest += 5;
					break;
				case 'D':
					mapp(dest, "[^0-9]");
					dest += 6;
					break;
				case 'w':
					mapp(dest, "[A-Za-z_0-9]");
					dest += 12;
					break;
				case 'W':
					mapp(dest, "[^A-Za-z_0-9]");
					dest += 015; /* Avoid hex */
					break;
				case 'p':
					pops(buf); /* Buffer */
					mapp(dest, buf);
					dest += strlen(buf);
					break;
				case 'n':
					*dest = '\n';
					dest++;
					break;
				case 'r':
					*dest = '\r';
					dest++;
					break;
				case '\\':
					*dest = '\\';
					dest++;
					break;
			}
		} else {
			*dest = *source;
			dest++;
		}
		source++;
	}
	*dest = '\0'; /* Null terminate it */
	mfree(rs);
}

int mapp(char *ptr, char *str) { /* Memory append */
	int cnt;
	for(cnt = 0; cnt < strlen(str); cnt++)
		*(ptr++) = str[cnt]; /* Transfer */
}

int trans(char *str, void *r) {
	regexp *mr;
	char small[2] = {0, 0};
	char *ptr, *source, *rs, st, storedc;

	rs = strdup(str);
	source = rs;
	bzero(str, 1024);
	mr = r; /* Get regexp */

	for(;;) {
		if(*source == '\0')
			break;
		if(*source == '\\') {
			source++;
			st = *source - '0'; /* Store the number */
			storedc = mr->endp[st][0];
			mr->endp[st][0] = '\0'; /* Null-terminate */
			strcat(str, mr->startp[st]); /* Add string */
			mr->endp[st][0] = storedc;
		} else {
			small[0] = *source;
			strcat(str, small);
		}
		source++;
	}
	mfree(rs);
}
