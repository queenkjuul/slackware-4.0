#!/usr/bin/env python
## -*- mode: Python; TAB: 4 -*-
###############################################################################
## Copyright � 1997-99 Klaus Alexander Seistrup @ Magnetic Ink, Copenhagen, DK.
##
## QTime -- display time as English sentence.
##
## Author  : 1997 Klaus Alexander Seistrup <kseis@magnetic-ink.dk>
## Created : Wednesday, 15th January 1997
## @(#) $Id: qtime.py,v 1.3 1999/01/29 11:51:57 kseis Exp $
##
## This program is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by the Free
## Software Foundation; either version 2 of the License, or (at your option)
## any later version.
##
## This program is distributed in the hope that it will be useful, but with-
## out any warranty; without even the implied warranty of merchantability or
## fitness for a particular purpose.  See the GNU General Public License for
## more details.
##
## You should have received a copy of the GNU General Public License along
## with this program; if not, write to the Free Software Foundation, Inc.,
## 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
##
## You can obtain a copy of Python from <URL:http://www.python.org/>.
###############################################################################
"""QTime - display time as English sentence"""

__RCSid__ = \
__MAGIC__ = "@(#) $Id: qtime.py,v 1.3 1999/01/29 11:51:57 kseis Exp $\0"

import time

UP = ("to ", "", "past ")

NY = ("nearly ", "almost ", "", "just after ", "after ")

MN = ("", "five ", "ten ", "a quarter ", "twenty ", "twenty-five ", "half ")

HR = ("twelve", "one", "two", "three", "four", "five", "six", "seven",
      "eight", "nine", "ten", "eleven")

def secs_since_midnight ():
	tm = time.localtime (time.time ())
	return (tm[3] * 60 + tm[4]) * 60 + tm[5]
# end def get_sys_secs

def qt ():
	adj_mins = (secs_since_midnight () + 30) / 60 + 27
	hours, minutes = divmod (adj_mins, 60)
	divisions, almost = divmod (minutes, 5)
	to_past_idx = cmp (divisions, 5) + 1
	divisions = abs (divisions - 5)
	now = "It's " + NY[almost] + MN[divisions] + UP[to_past_idx] + HR[hours%12]
	if not divisions:
		return now + " o'clock"
	# end if
	return now
# end def qt

def qtime ():
	print qt () + "."
# end def main

main = qtime

if __name__ == "__main__":
	main ()
# end if

## EOF ########################################################################
