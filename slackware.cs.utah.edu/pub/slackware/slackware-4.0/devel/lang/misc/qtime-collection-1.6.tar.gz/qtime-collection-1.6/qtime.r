; -*- mode: Rebol; TAB: 4 -*-
;-----------------------------------------------------------------------------
;     File: qtime.r
;  Subject: Display time as English sentence.
;   Author: Klaus Alexander Seistrup <kseis@magnetic-ink.dk>
;     Date: Thursday, 21st January 1999
; @(#) $Id: qtime.r,v 1.3 1999/01/29 11:51:57 kseis Exp $
;-----------------------------------------------------------------------------
; Copyright � 1999 Klaus Alexander Seistrup @ Magnetic Ink, Copenhagen, DK.
;
; This program is free software; you can redistribute it and/or modify it
; under the terms of the GNU General Public License as published by the Free
; Software Foundation; either version 2 of the License, or (at your option)
; any later version.
;
; This program is distributed in the hope that it will be useful, but with-
; out any warranty; without even the implied warranty of merchantability or
; fitness for a particular purpose.  See the GNU General Public License for
; more details.
;
; You should have received a copy of the GNU General Public License along
; with this program; if not, write to the Free Software Foundation, Inc.,
; 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
;
; You can find REBOL at <URL:http://www.rebol.com/>.
;-----------------------------------------------------------------------------

REBOL [
	Title:		"QTime"
	Date:		21-Jan-1999
	File:		%qtime.r
	Version:	"$Id: qtime.r,v 1.3 1999/01/29 11:51:57 kseis Exp $"
	Author:		kseis@magnetic-ink.dk ("Klaus Alexander Seistrup")
	Rights:		"The Choice of a GNU Generation: GNU GPL"
	Purpose:	"Display time as English sentence."
	Comments:	{
		My first attempt of programming in REBOL. :-)
		See URL <http://www.magnetic-ink.dk/download/> for a collection
		of QTime written in other programming languages.
	}
]
;---------------------------------------------------------------------------

UP: [ "to " "" "past " ]
NY: [ "nearly " "almost " "" "just after " "after " ]
MN: [ "" "five " "ten " "a quarter " "twenty " "twenty-five " "half " ]
HR: [ "twelve" "one" "two" "three" "four" "five" "six" "seven" "eight" "nine" "ten" "eleven" ]

qtime: func [] [
	hms: fourth now
	hh: first hms
	mm: second hms
	ss: third hms
	ssm: (hh * 60 + mm) * 60 + ss
	adm: 27 + make integer! ((ssm + 30) / 60)
	hours: (make integer! (adm / 60)) // 12
	minutes: adm // 60
	almost: minutes // 5
	divisions: (make integer! (minutes / 5)) - 5
	to_past_idx: 0
	if divisions < 0 [
		divisions: negate divisions
		to_past_idx: -1
	] else [ if divisions > 0 [	to_past_idx: 1 ] ]
	prin "It's "
	prin pick NY (almost + 1)
	prin pick MN (divisions + 1)
	prin pick UP (to_past_idx + 2)
	prin pick HR (hours + 1)
	if not divisions [
		prin " o'clock"
	]
	print "."
]

if REBOL/interactive [
	print "Type qtime at the REBOL prompt for the time."
]

;-- EOF
