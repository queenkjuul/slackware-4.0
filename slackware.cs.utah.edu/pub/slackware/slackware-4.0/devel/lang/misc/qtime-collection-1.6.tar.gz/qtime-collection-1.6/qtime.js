#!/usr/bin/env js

/*****************************************************************************
 * Copyright � 1998-99 Klaus Alexander Seistrup @ Magnetic Ink, Copenhagen, DK
 *
 * QTime -- display time as English sentence.
 *
 * Author  : 1998 Klaus Alexander Seistrup <kseis@magnetic-ink.dk>
 * Created : Sometime during summer 1998 (WHAT summer???).
 * @(#) $Id: qtime.js,v 1.3 1999/01/29 11:51:57 kseis Exp $
 *
 * My first program in JavaScript/ECMAScript. :-)
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but with-
 * out any warranty; without even the implied warranty of merchantability or
 * fitness for a particular purpose.  See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 * NGS JavaScript can be found at <URL:http://www.ngs.fi/js/>.
 *****************************************************************************/

HR = new Array ("twelve", "one", "two",	"three", "four", "five",
		"six", "seven",	"eight", "nine", "ten",	"eleven");

MN = new Array ("", "five ", "ten ", "a quarter ",
		"twenty ", "twenty-five ", "half ");

NY = new Array ("nearly ", "almost ", "", "just after ", "after ");

UP = new Array ("to ", "", "past ");

function qtime ()
{
  var now   = "It's ";
  var today = new Date ();
  var secs  = (today.getHours () * 60 + today.getMinutes ()) * 60 + today.getSeconds ();

  if (secs < 30 || secs > 86370)
    now += "midnight";
  else if (secs > 43170 && secs < 43230)
    now += "noon";
  else
    {
      var adj_mins    = int (((secs + 30) / 60) + 27);
      var hours	      = int (adj_mins / 60);
      var minutes     = int (adj_mins % 60);
      var divisions   = int (minutes / 5);
      var almost      = int (minutes % 5);
      var to_past_idx = (divisions > 5 ? 1 : (divisions == 5 ? 0 : -1)) + 1;

      if ((divisions -= 5) < 0)
	divisions = -divisions;

      now += (NY[int(almost)] + MN[int(divisions)] + UP[int(to_past_idx)] + HR[int(hours % 12)]);

      if (divisions == 0)
	now += " o'clock";
    }
  return now + ".";
}

function main ()
{
  System.stdout.writeln (qtime ());
}

main ();

// EoF
