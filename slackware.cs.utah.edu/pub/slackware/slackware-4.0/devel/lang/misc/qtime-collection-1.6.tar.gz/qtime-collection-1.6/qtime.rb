#!/usr/bin/env ruby
## -*- mode: Ruby; TAB: 4 -*-
###############################################################################
## Copyright � 1998-99 Klaus Alexander Seistrup @ Magnetic Ink, Copenhagen, DK.
##
## QTime -- Display time as English sentence.
##
## Author  : 1998 Klaus Alexander Seistrup <kseis@magnetic-ink.dk>
## Created : Sunday, 20th December 1998
## @(#) $Id: qtime.rb,v 1.3 1999/01/29 11:51:57 kseis Exp $
##
## My first program in Ruby. :-)
##
## This program is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by the Free
## Software Foundation; either version 2 of the License, or (at your option)
## any later version.
##
## This program is distributed in the hope that it will be useful, but with-
## out any warranty; without even the implied warranty of merchantability or
## fitness for a particular purpose.  See the GNU General Public License for
## more details.
##
## You should have received a copy of the GNU General Public License along
## with this program; if not, write to the Free Software Foundation, Inc.,
## 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
##
## Ruby is available from <ftp://ftp.netlab.co.jp/pub/lang/ruby/>
##                   and <http://www.netlab.co.jp/ruby/>
###############################################################################

def secs_since_midnight
    now = Time.now
	return (now.hour * 60 + now.min) * 60 + now.sec
end

def qt
	@hr = [ "twelve", "one", "two", "three", "four", "five",
			"six", "seven", "eight", "nine", "ten", "eleven" ]
	@mn = [ "", "five ", "ten ", "a quarter ",
			"twenty ", "twenty-five ", "half " ]
	@ny = [ "nearly ", "almost ", "", "just after ", "after " ]
	@up = [ "to ", "", "past " ]
	adj_mins	= (secs_since_midnight () + 30) / 60 + 27
	hours		= (adj_mins / 60) % 12
	minutes		=  adj_mins % 60
	almost		=  minutes % 5
	divisions	= (minutes / 5) - 5
	to_past_idx	= 1 + if divisions > 0 then 1 elsif divisions < 0 then -1 else 0 end
	tid = "It's " + @ny[almost] + @mn[divisions.abs] + @up[to_past_idx] + @hr[hours]
	if divisions == 0 then tid += " o'clock" end
	return tid + "."
end

def qtime
    print (qt (), "\n")
end

if __FILE__ == $0
	qtime ()
end

## Soli Deo Gloria ############################################################
