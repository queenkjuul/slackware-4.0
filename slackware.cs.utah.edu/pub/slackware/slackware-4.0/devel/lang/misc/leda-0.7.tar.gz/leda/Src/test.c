# include <stdio.h>
# include "memory.h"
void main() 
{

printf("size pointer %d size int %d size real %d\n", 
	sizeof(struct ledaValue *),
	sizeof(int), sizeof(double));
}
