# include "stdio.h"
# define U(x) ((x)&0377)
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin ={stdin}, *yyout ={stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
/* 
	lexical analyzer for Leda revision August 26, 1993 
*/

int		linenumber = 1;
char *		fileName = "no file";

extern double atof(char *);

struct inputSources {
	FILE * fd;
	struct inputSources * next;
	int linesave;
	char * filenamesave;
	};

struct inputSources * inputSource = 0;

void openInputFile(char * name)
{
	struct inputSources * p;
	p = (struct inputSources *) malloc(sizeof(struct inputSources));
	if (p == 0)
		yyerror("out of memory");
	p->linesave = linenumber;
	p->filenamesave = fileName;
	p->next = inputSource;
	p->fd = fopen(name, "r");
	if (p->fd != NULL) {
		inputSource = p;
		linenumber = 1;
		fileName = name;
		}
	else
		yyserror("cannot open input file named %s", name);
	yyin = inputSource->fd;
}


int yywrap() 
{ 
	/* should execution continue? */
	if (inputSource == 0)
		return 1;
	linenumber = inputSource->linesave;
	fileName = inputSource->filenamesave;
	inputSource = inputSource->next;
	if (inputSource == 0)
		return 1;
	yyin = inputSource->fd;
	return 0; 
}

/*
	this is a silly hack to save space until we get real garbage
	collection -- intended to ensure we have only one copy of
	any string
*/
static char * strTable[1000];
static int strTop = 0;

char * newString(char * c)
{
	int i;
	char * p;

	for (i = 0; i < strTop; i++)
		if (strcmp(c, strTable[i]) == 0)
			return strTable[i];

	/* not found, make a new copy */
	p = (char *) malloc(strlen(c) + 1);
	if (p == 0)
		yyerror("out of memory for string");
	strcpy(p, c);
	strTable[strTop++] = p;
	if (strTop >= 1000)
		yyerror("too many strings");
	/*printf("created new string %s\n", c);*/
	return p;
}

char * newTextString(char * c)
{
	char * p = c;
	char * q;
	char * buffer;

		/* skip leading quote mark */
	if (p) p++;

		/* remove ending quote mark */
	p[strlen(p)-1] = '\0';

		/* make new string */
	return newString(p);
}

char * readLiteralString()
{
	char buffer[256];
	char * p = buffer;
	int c;

	while (c = input()) {
		switch(c) {
			case '\"': *p = '\0'; 
				return newString(buffer);
			
			case '\n':
				yyerror("unterminated literal string");

			case '\\':
				switch(c = input()) {
					case 'n': c = '\n'; break;
					case 't': c = '\t'; break;
					case 'b': c = '\b'; break;
					/* default drops into next case */
				}

			default:
				*p++ = c;
		}
	}
	yyerror("unterminated literal string");
}

static void skipComment()
{
	while(1)
		switch(input()) {
			case EOF: yyerror("unexpected eof in comment");
			case '\n': linenumber++; break;
			case '{': yyerror("nested comment");
			case '}': return;
			}
}

# define lexreturn(x) /*printf("token %s:%s\n", yytext, #x);*/ return(x)

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
	linenumber++;
break;
case 2:
/* white space, do nothing */;
break;
case 3:
	{skipComment(); /* do nothing */ }
break;
case 4:
	{yylval.c = readLiteralString(); lexreturn(SCONSTANT);}
break;
case 5:
	{lexreturn(BEGINkw);}
break;
case 6:
{lexreturn(BYNAME);}
break;
case 7:
	{lexreturn(BYREF);}
break;
case 8:
{lexreturn(CFUNCTIONkw);}
break;
case 9:
	{lexreturn(CLASSkw);}
break;
case 10:
	{lexreturn(CONSTkw);}
break;
case 11:
{lexreturn(DEFINEDkw);}
break;
case 12:
	{lexreturn(DOkw);}
break;
case 13:
	{lexreturn(ELSEkw);}
break;
case 14:
	{lexreturn(ENDkw);}
break;
case 15:
	{yylval.i = linenumber; lexreturn(FORkw);}
break;
case 16:
{lexreturn(FUNCTIONkw);}
break;
case 17:
	{yylval.i = linenumber; lexreturn(IFkw);}
break;
case 18:
{lexreturn(INCLUDEkw);}
break;
case 19:
	{lexreturn(ISkw);}
break;
case 20:
	{lexreturn(OFkw);}
break;
case 21:
{yylval.i = linenumber; lexreturn(RETURNkw);}
break;
case 22:
	{lexreturn(THENkw);}
break;
case 23:
	{lexreturn(TOkw);}
break;
case 24:
	{lexreturn(TYPEkw);}
break;
case 25:
	{lexreturn(VARkw);}
break;
case 26:
	{yylval.i = linenumber; lexreturn(WHILEkw);}
break;
case 27:
	{yylval.c = newString(yytext); lexreturn(ID);}
break;
case 28:
{yylval.i = atoi(yytext); lexreturn(ICONSTANT);}
break;
case 29:
{yylval.r = atof(yytext); lexreturn(RCONSTANT);}
break;
case 30:
	{lexreturn(COLON);}
break;
case 31:
	{lexreturn(SEMI);}
break;
case 32:
	{lexreturn(PERIOD);}
break;
case 33:
	{lexreturn(ASSIGN);}
break;
case 34:
	{lexreturn(COMMA);}
break;
case 35:
	{lexreturn(ARROW);}
break;
case 36:
	{lexreturn(LEFTARROW);}
break;
case 37:
	{yylval.c = "less"; lexreturn(RELATIONALOP);}
break;
case 38:
	{yylval.c = "lessEqual"; lexreturn(RELATIONALOP);}
break;
case 39:
	{yylval.c = "greater"; lexreturn(RELATIONALOP);}
break;
case 40:
	{yylval.c = "greaterEqual"; lexreturn(RELATIONALOP);}
break;
case 41:
	{lexreturn(LEFTBRACK);}
break;
case 42:
	{lexreturn(RIGHTBRACK);}
break;
case 43:
	{lexreturn(LEFTPAREN);}
break;
case 44:
	{lexreturn(RIGHTPAREN);}
break;
case 45:
	{yylval.c = "equals"; lexreturn(RELATIONALOP);}
break;
case 46:
	{yylval.c = "notEquals"; lexreturn(RELATIONALOP);}
break;
case 47:
	{yylval.c = "sameAs"; lexreturn(RELATIONALOP);}
break;
case 48:
	{yylval.c = "notSameAs"; lexreturn(RELATIONALOP);}
break;
case 49:
	{yylval.c = "plus"; lexreturn(PLUSop);}
break;
case 50:
	{yylval.c = "minus"; lexreturn(MINUSop);}
break;
case 51:
	{yylval.c = "times"; lexreturn(TIMESop);}
break;
case 52:
	{yylval.c = "divide"; lexreturn(TIMESop);}
break;
case 53:
	{yylval.c = "remainder"; lexreturn(TIMESop);}
break;
case 54:
	{lexreturn(NOT);}
break;
case 55:
	{yylval.c = "and"; lexreturn(ANDop);}
break;
case 56:
	{yylval.c = "or"; lexreturn(ORop);}
break;
case 57:
	{fprintf(stderr,"character %c %d\n", yytext[0], yytext[0]);
			yyerror("unknown character"); }
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
int yyvstop[] ={
0,

57,
0,

2,
57,
0,

1,
0,

4,
57,
0,

53,
57,
0,

55,
57,
0,

43,
57,
0,

44,
57,
0,

51,
57,
0,

49,
57,
0,

34,
57,
0,

50,
57,
0,

32,
57,
0,

52,
57,
0,

28,
57,
0,

30,
57,
0,

31,
57,
0,

37,
57,
0,

45,
57,
0,

39,
57,
0,

27,
57,
0,

41,
57,
0,

42,
57,
0,

27,
57,
0,

27,
57,
0,

27,
57,
0,

27,
57,
0,

27,
57,
0,

27,
57,
0,

27,
57,
0,

27,
57,
0,

27,
57,
0,

27,
57,
0,

27,
57,
0,

3,
57,
0,

56,
57,
0,

54,
57,
0,

2,
0,

35,
0,

28,
0,

33,
0,

36,
0,

38,
0,

46,
0,

47,
0,

40,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

12,
27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

17,
27,
0,

27,
0,

19,
27,
0,

20,
27,
0,

27,
0,

27,
0,

23,
27,
0,

27,
0,

27,
0,

27,
0,

48,
0,

29,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

14,
27,
0,

15,
27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

25,
27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

13,
27,
0,

27,
0,

27,
0,

27,
0,

22,
27,
0,

24,
27,
0,

27,
0,

5,
27,
0,

27,
0,

7,
27,
0,

27,
0,

9,
27,
0,

10,
27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

26,
27,
0,

6,
27,
0,

27,
0,

27,
0,

27,
0,

27,
0,

21,
27,
0,

27,
0,

11,
27,
0,

27,
0,

18,
27,
0,

27,
0,

16,
27,
0,

8,
27,
0,
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } yycrank[] ={
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,4,	1,5,	
0,0,	4,40,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	1,6,	
4,40,	0,0,	1,7,	1,8,	
0,0,	1,9,	1,10,	1,11,	
1,12,	1,13,	1,14,	1,15,	
1,16,	1,17,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	1,18,	
1,19,	1,20,	1,21,	1,22,	
14,41,	17,42,	1,23,	17,43,	
17,43,	17,43,	17,43,	17,43,	
17,43,	17,43,	17,43,	17,43,	
17,43,	18,44,	21,48,	20,45,	
22,49,	39,72,	42,73,	42,73,	
42,73,	42,73,	42,73,	42,73,	
42,73,	42,73,	42,73,	42,73,	
1,24,	52,75,	1,25,	20,46,	
20,47,	52,76,	0,0,	1,26,	
1,27,	1,28,	1,29,	1,30,	
35,70,	54,78,	1,31,	59,82,	
26,51,	32,65,	33,66,	28,56,	
1,32,	36,71,	51,74,	1,33,	
29,58,	1,34,	29,59,	1,35,	
1,36,	28,57,	55,79,	56,80,	
1,37,	1,38,	2,6,	1,39,	
26,52,	2,7,	2,8,	53,77,	
2,9,	2,10,	2,11,	2,12,	
2,13,	2,14,	2,15,	2,16,	
27,53,	30,60,	58,81,	60,83,	
61,84,	63,85,	27,54,	30,61,	
31,62,	27,55,	2,18,	2,19,	
2,20,	2,21,	2,22,	34,67,	
31,63,	66,86,	67,87,	69,88,	
70,89,	31,64,	34,68,	71,90,	
74,91,	75,92,	76,93,	77,94,	
78,95,	79,96,	80,97,	81,98,	
34,69,	84,99,	85,100,	86,101,	
87,102,	88,103,	90,104,	91,105,	
92,106,	93,107,	94,108,	2,24,	
95,109,	2,25,	96,110,	97,111,	
99,112,	100,113,	2,26,	2,27,	
2,28,	2,29,	2,30,	101,114,	
104,115,	2,31,	106,116,	108,117,	
111,118,	112,119,	113,120,	2,32,	
114,121,	117,122,	2,33,	118,123,	
2,34,	119,124,	2,35,	2,36,	
120,125,	122,126,	124,127,	2,37,	
2,38,	126,128,	2,39,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	0,0,	0,0,	
0,0,	0,0,	23,50,	0,0,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	23,50,	23,50,	
23,50,	23,50,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] ={
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-92,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+4,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+6,
yycrank+0,	0,		yyvstop+8,
yycrank+0,	0,		yyvstop+11,
yycrank+0,	0,		yyvstop+14,
yycrank+0,	0,		yyvstop+17,
yycrank+0,	0,		yyvstop+20,
yycrank+0,	0,		yyvstop+23,
yycrank+0,	0,		yyvstop+26,
yycrank+0,	0,		yyvstop+29,
yycrank+2,	0,		yyvstop+32,
yycrank+0,	0,		yyvstop+35,
yycrank+0,	0,		yyvstop+38,
yycrank+19,	0,		yyvstop+41,
yycrank+16,	0,		yyvstop+44,
yycrank+0,	0,		yyvstop+47,
yycrank+34,	0,		yyvstop+50,
yycrank+17,	0,		yyvstop+53,
yycrank+19,	0,		yyvstop+56,
yycrank+171,	0,		yyvstop+59,
yycrank+0,	0,		yyvstop+62,
yycrank+0,	0,		yyvstop+65,
yycrank+7,	yysvec+23,	yyvstop+68,
yycrank+38,	yysvec+23,	yyvstop+71,
yycrank+10,	yysvec+23,	yyvstop+74,
yycrank+8,	yysvec+23,	yyvstop+77,
yycrank+30,	yysvec+23,	yyvstop+80,
yycrank+46,	yysvec+23,	yyvstop+83,
yycrank+7,	yysvec+23,	yyvstop+86,
yycrank+9,	yysvec+23,	yyvstop+89,
yycrank+51,	yysvec+23,	yyvstop+92,
yycrank+7,	yysvec+23,	yyvstop+95,
yycrank+9,	yysvec+23,	yyvstop+98,
yycrank+0,	0,		yyvstop+101,
yycrank+0,	0,		yyvstop+104,
yycrank+20,	0,		yyvstop+107,
yycrank+0,	yysvec+4,	yyvstop+110,
yycrank+0,	0,		yyvstop+112,
yycrank+34,	0,		0,	
yycrank+0,	yysvec+17,	yyvstop+114,
yycrank+0,	0,		yyvstop+116,
yycrank+0,	0,		yyvstop+118,
yycrank+0,	0,		yyvstop+120,
yycrank+0,	0,		yyvstop+122,
yycrank+0,	0,		yyvstop+124,
yycrank+0,	0,		yyvstop+126,
yycrank+0,	yysvec+23,	yyvstop+128,
yycrank+11,	yysvec+23,	yyvstop+130,
yycrank+15,	yysvec+23,	yyvstop+132,
yycrank+14,	yysvec+23,	yyvstop+134,
yycrank+8,	yysvec+23,	yyvstop+136,
yycrank+12,	yysvec+23,	yyvstop+138,
yycrank+21,	yysvec+23,	yyvstop+140,
yycrank+0,	yysvec+23,	yyvstop+142,
yycrank+27,	yysvec+23,	yyvstop+145,
yycrank+7,	yysvec+23,	yyvstop+147,
yycrank+29,	yysvec+23,	yyvstop+149,
yycrank+34,	yysvec+23,	yyvstop+151,
yycrank+0,	yysvec+23,	yyvstop+153,
yycrank+46,	yysvec+23,	yyvstop+156,
yycrank+0,	yysvec+23,	yyvstop+158,
yycrank+0,	yysvec+23,	yyvstop+161,
yycrank+41,	yysvec+23,	yyvstop+164,
yycrank+57,	yysvec+23,	yyvstop+166,
yycrank+0,	yysvec+23,	yyvstop+168,
yycrank+47,	yysvec+23,	yyvstop+171,
yycrank+46,	yysvec+23,	yyvstop+173,
yycrank+58,	yysvec+23,	yyvstop+175,
yycrank+0,	0,		yyvstop+177,
yycrank+0,	yysvec+42,	yyvstop+179,
yycrank+59,	yysvec+23,	yyvstop+181,
yycrank+68,	yysvec+23,	yyvstop+183,
yycrank+65,	yysvec+23,	yyvstop+185,
yycrank+57,	yysvec+23,	yyvstop+187,
yycrank+53,	yysvec+23,	yyvstop+189,
yycrank+54,	yysvec+23,	yyvstop+191,
yycrank+65,	yysvec+23,	yyvstop+193,
yycrank+70,	yysvec+23,	yyvstop+195,
yycrank+0,	yysvec+23,	yyvstop+197,
yycrank+0,	yysvec+23,	yyvstop+200,
yycrank+74,	yysvec+23,	yyvstop+203,
yycrank+66,	yysvec+23,	yyvstop+205,
yycrank+58,	yysvec+23,	yyvstop+207,
yycrank+66,	yysvec+23,	yyvstop+209,
yycrank+76,	yysvec+23,	yyvstop+211,
yycrank+0,	yysvec+23,	yyvstop+213,
yycrank+70,	yysvec+23,	yyvstop+216,
yycrank+69,	yysvec+23,	yyvstop+218,
yycrank+71,	yysvec+23,	yyvstop+220,
yycrank+79,	yysvec+23,	yyvstop+222,
yycrank+83,	yysvec+23,	yyvstop+224,
yycrank+69,	yysvec+23,	yyvstop+226,
yycrank+70,	yysvec+23,	yyvstop+228,
yycrank+77,	yysvec+23,	yyvstop+230,
yycrank+0,	yysvec+23,	yyvstop+232,
yycrank+72,	yysvec+23,	yyvstop+235,
yycrank+72,	yysvec+23,	yyvstop+237,
yycrank+81,	yysvec+23,	yyvstop+239,
yycrank+0,	yysvec+23,	yyvstop+241,
yycrank+0,	yysvec+23,	yyvstop+244,
yycrank+95,	yysvec+23,	yyvstop+247,
yycrank+0,	yysvec+23,	yyvstop+249,
yycrank+97,	yysvec+23,	yyvstop+252,
yycrank+0,	yysvec+23,	yyvstop+254,
yycrank+83,	yysvec+23,	yyvstop+257,
yycrank+0,	yysvec+23,	yyvstop+259,
yycrank+0,	yysvec+23,	yyvstop+262,
yycrank+99,	yysvec+23,	yyvstop+265,
yycrank+96,	yysvec+23,	yyvstop+267,
yycrank+102,	yysvec+23,	yyvstop+269,
yycrank+94,	yysvec+23,	yyvstop+271,
yycrank+0,	yysvec+23,	yyvstop+273,
yycrank+0,	yysvec+23,	yyvstop+276,
yycrank+100,	yysvec+23,	yyvstop+279,
yycrank+107,	yysvec+23,	yyvstop+281,
yycrank+98,	yysvec+23,	yyvstop+283,
yycrank+111,	yysvec+23,	yyvstop+285,
yycrank+0,	yysvec+23,	yyvstop+287,
yycrank+102,	yysvec+23,	yyvstop+290,
yycrank+0,	yysvec+23,	yyvstop+292,
yycrank+104,	yysvec+23,	yyvstop+295,
yycrank+0,	yysvec+23,	yyvstop+297,
yycrank+107,	yysvec+23,	yyvstop+300,
yycrank+0,	yysvec+23,	yyvstop+302,
yycrank+0,	yysvec+23,	yyvstop+305,
0,	0,	0};
struct yywork *yytop = yycrank+293;
struct yysvf *yybgin = yysvec+1;
char yymatch[] ={
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,'A' ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] ={
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*	ncform	4.1	83/08/11	*/

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank){		/* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"unsigned char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
