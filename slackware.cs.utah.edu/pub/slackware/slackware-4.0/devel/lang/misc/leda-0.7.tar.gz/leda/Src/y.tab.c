# define INCLUDEkw 257
# define DEFINEDkw 258
# define CONSTkw 259
# define VARkw 260
# define TYPEkw 261
# define CLASSkw 262
# define FUNCTIONkw 263
# define OFkw 264
# define BYNAME 265
# define BYREF 266
# define BEGINkw 267
# define ENDkw 268
# define RETURNkw 269
# define IFkw 270
# define THENkw 271
# define ELSEkw 272
# define WHILEkw 273
# define DOkw 274
# define ISkw 275
# define FORkw 276
# define TOkw 277
# define BINARYOP 278
# define PLUSop 279
# define MINUSop 280
# define TIMESop 281
# define ANDop 282
# define ORop 283
# define NOT 284
# define RELATIONALOP 285
# define LEFTARROW 286
# define ID 287
# define CONSTANT 288
# define CFUNCTIONkw 289
# define RCONSTANT 290
# define ICONSTANT 291
# define SCONSTANT 292
# define COLON 293
# define SEMI 294
# define ASSIGN 295
# define COMMA 296
# define ARROW 297
# define PERIOD 298
# define LEFTPAREN 299
# define RIGHTPAREN 300
# define LEFTBRACK 301
# define RIGHTBRACK 302

# line 20 "gram.y"

# define VERSION "beta leda version 0.7 (22 Feb 1994)\n"

# include "lc.h"
# include "interp.h"

struct symbolTableRecord * syms = 0;
struct symbolTableRecord * globalSyms = 0;

int justParse = 0;

void doInclude(char *);


# line 35 "gram.y"
typedef union  {
	char *				c;
	struct expressionRecord *	e;
	enum forms			f;
	int				i;
	struct list *			l;
	double				r;
	struct statementRecord * 	s;
	struct typeRecord *		t;
	struct symbolRecord *		y;
	struct {
		struct statementRecord * first;
		struct statementRecord * last;
		}			sp;
	} YYSTYPE;
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern short yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256

# line 524 "gram.y"

# include "lex.yy.c"

void yyserror(char * pattern, char * name)
{ 
 	fprintf(stderr,"%s:%d:[%s] ", fileName, linenumber, yytext);
	fprintf(stderr, pattern, name);
 	fprintf(stderr, "\n");
	exit(1);
}

int yyerror(char * s)
{
 	fprintf(stderr,"%s:%d:[%s] %s\n",
 		fileName, linenumber, yytext, s);
	exit(1);
}

static char * includeDirectories[10];
static int includeDirTop = 0;

static int testInclude(char * name)
{
	FILE * fid;

	fid = fopen(name, "r");
	if (fid != NULL) {
		fclose(fid);
		openInputFile(name);
		return 1;
		}
	fclose(fid);
	return 0;
}

void doInclude(char * name)
{
	int i;
	char namebuffer[256];

	if (testInclude(name)) return;
	for (i = 0; i < includeDirTop; i++) {
		strcpy(namebuffer, includeDirectories[i]);
		strcat(namebuffer, "/");
		strcat(namebuffer, name);
		if (testInclude(namebuffer)) return;
		}
	yyserror("unable to open include file %s", name);
}

int main(int argc, char ** argv)
{
	int i;
	extern int displayStatements;
	extern int displayOperators;
	extern int displayFunctions;

	/* default values for memory management */
	int initialMemorySize = 25000;
	int initialStaticMemorySize =  800;


	for (i = 1; i < argc; i++) {
		if (strcmp(argv[i], "-df") == 0) {
			displayFunctions = 1;
			}
		else if (strcmp(argv[i], "-ds") == 0) {
			displayFunctions = 1;
			displayStatements = 1;
			}
		else if (strcmp(argv[i], "-do") == 0) {
			displayFunctions = 1;
			displayStatements = 1;
			displayOperators = 1;
			}
		else if (strcmp(argv[i], "-v") == 0) {
			printf(VERSION);
			exit(0);
			}
		else if (strcmp(argv[i], "-p") == 0) {
			justParse = 1;
			}
		else if ((argv[i][0] == '-') && (argv[i][1] == 'I')) {
			if (argv[i][2])
				includeDirectories[includeDirTop++] = 
					&argv[i][2];
			else
				includeDirectories[includeDirTop++] = argv[++i];
			}
		else if ((argv[i][0] == '-') && (argv[i][1] == 'm')) {
			initialMemorySize = atoi(argv[++i]);
			}
		else if ((argv[i][0] == '-') && (argv[i][1] == 's')) {
			initialStaticMemorySize = atoi(argv[++i]);
			}
		else if (argv[i][0] == '-') {
			yyserror("unknown option %s", argv[i]);
			}
		else {
			openInputFile(argv[i]);
			gcinit(initialStaticMemorySize,initialMemorySize);
			/* create global symbol table */
			globalSyms = syms = initialCreation();

			/* parse program */
			yyparse();
			exit(0);
			}
	}
	yyerror("no input file specified");
}
short yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
-1, 197,
	298, 110,
	299, 110,
	-2, 106,
	};
# define YYNPROD 124
# define YYLAST 642
short yyact[]={

  34, 199, 199, 113, 114,  41, 212, 249, 234,  25,
 208,  24,  26, 199, 166,  27, 153, 169,  28, 200,
 171, 236, 154, 101, 170, 113, 114, 256, 230,  30,
 194,  32,  37,  35,  36,  34,  61, 121, 228, 121,
  41,  38,  89,  40,  25, 162,  24,  26, 199, 213,
  27, 166, 251,  28, 202, 167, 151,  87, 128, 109,
 110, 197,  87,  86,  30, 196,  32,  37,  35,  36,
  34, 181, 147,  56,  90,  41,  38, 227,  40,  25,
 135,  24,  26, 254, 210,  27, 101, 101,  28, 124,
 100, 153,  58, 101, 216,  98,  66, 257, 255,  30,
 125,  32,  37,  35,  36,  34, 103, 124, 121, 246,
  41,  38, 241,  40,  25,  80,  24,  26, 125, 205,
  27, 207,  57,  28, 206, 204,  85, 140, 164, 163,
 160, 119, 118,  96,  30,  65,  32,  37,  35,  36,
  34,  42, 143,  49, 174,  41,  38, 158,  40,  25,
  63,  24,  26, 146, 131,  27, 124, 115,  28,  52,
  45,  88,  62,  59, 127, 122, 142, 125, 121,  30,
 127,  32,  37,  35,  36,  34, 244, 126, 132, 245,
  41,  38, 265,  40,  25, 121,  24,  26, 138, 272,
  27, 139, 149,  28, 266, 267, 215, 121, 121, 113,
 114, 121, 263, 121,  30,  34,  32,  37,  35,  36,
  41, 121, 243, 242, 187, 240,  38, 188,  40, 136,
 189, 121, 225, 190, 224, 121, 108,  48, 121, 148,
  75, 121, 137, 121,  30,  34,  32,  37,  35,  36,
  41, 121, 129, 130, 187, 218,  38, 188,  40, 112,
 189,  77, 107, 190, 112, 111,  39, 104,  29,  55,
  16,  68,  14,  50,  30,  34,  32,  37,  35,  36,
  41,  46,  73,  43, 187,   9,  38, 188,  40,   8,
 189,  34,  22, 190,  69,   7,  41,  34,   6,   5,
   4,  51,  41,   1,  30, 217,  32,  37,  35,  36,
  34,  95,  44,  78,  64,  41,  38,  71,  40,  78,
  30,  60,  76,  37,  35,  36,  30, 117,  76,  37,
  35,  36,  38,  72,  40,  47,  94,  23,  38,  30,
  40,  76,  37,  35,  36,  74, 144,  21, 185,  31,
 168,  38, 102,  40,  15,  23,  97,  17, 155,  23,
 152,  67,  84,  81,  82,  83, 123,  31, 177, 209,
 145,  31,  64,  79,  10,  91,  11,  12,  13,  20,
  18, 116,  99,  19,  10, 106,  11,  12,  13,  20,
  18, 179, 180, 172, 105,  10, 141,  11,  12,  13,
  20,  18, 231, 120,   2,   3, 195, 191, 175, 176,
 211,  93, 134,  23,  33,  70,   0, 173,   0,  53,
  54,   0,   0,   0, 133,  31,   0, 150,   0, 183,
 184,   0,   0,   0, 226, 156, 229,   0,   0,  23,
   0,   0,   0,   0,  92,   0,   0, 232,   0,   0,
 235,  31,   0, 161,  64,   0, 191,   0,   0, 134,
 134, 134,   0, 134, 134,   0, 134, 252,   0,   0,
  23,  23, 186, 252,   0, 178, 192, 193, 182,   0,
   0,   0,  31,  31,  31,   0, 191,   0,   0,   0,
 203,   0,   0, 191, 198,  23,   0, 157,   0,   0,
 159,   0,   0,   0,   0,   0, 165,  31, 237,   0,
   0, 191, 191, 191,   0,   0,   0,   0,   0,   0,
   0, 186,   0,   0, 223, 220, 221, 222, 214,   0,
   0,   0,   0,  31, 191, 191, 219,   0,   0,   0,
   0, 191,   0,   0,   0,   0, 201,   0,   0,  23,
   0, 186,   0, 238,   0,   0, 268,   0, 186,   0,
   0,  31, 248,  31,   0,   0, 239,   0,   0,   0,
  31,   0,   0, 247,   0,   0, 186, 186, 186,   0,
   0,   0, 261, 262,   0,   0,   0,   0,  31,  31,
  31, 258, 259, 260,   0,   0,   0,  23,   0, 186,
 186,   0,   0,   0, 271,   0, 186, 233,   0,  31,
   0,  31,  31,   0, 269, 270,   0,   0,  31,   0,
   0, 273,   0,   0, 250,   0,   0,   0, 253,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0, 264 };
short yypact[]={

-1000,-1000, 128, -83,-1000,-1000,-1000,-1000,-1000,-1000,
-151,-127,-144,-128,-1000,-1000,-226,-172,-124,-265,
-125,-118,-159,-199,  23,-153,  23,  23,  23,-1000,
-167,-236,-126,-259,-225,-1000,-1000,-1000,  23,-1000,
  23,-226,-161,-127,-1000,-200,-144,-1000,-203,-1000,
-128,-1000,-187, 117, 107,-238,-240,-1000,-130,-265,
-1000, -66,-1000,-162,-163,-1000,  23,-115,-117,-1000,
-1000,  23,-119,-108,-241, -37,-133,-103,  42,-188,
-1000, -52, -42, -86,-168,-121,  23,-134,-227, -66,
  23,-244, 117,-280,-115,-238,-1000,-1000,  23,-1000,
-121,-140,-1000,-121,-164,-223,-165,-166,-1000,-121,
-1000,-245,-144,-1000,-1000,-277,-1000,-282,-1000,-1000,
-115,  23,  23,-1000,-143,  29,  29,  29,  23,  29,
  29,-228,  42,-241,-1000,-1000, -83, -83,   7,  23,
  23,-1000,-271,-234,-239,-205,-1000,  23,-283,-121,
-246,-1000,-1000,  23,-1000,-169,-175,-170,-1000,-173,
-1000,-258,-1000,-1000,-1000,-1000, -66,-1000,-209,-1000,
 -66,-1000,-117,-1000,-293,-114,-114, -37,-251,-103,
-103,  23,-241, -76,-1000,-1000,-201, -23,  23,  23,
  23,-1000, -50, -55, -66,-220,-262,-1000,-272, -66,
-1000,-1000,-1000,-115,-1000,-1000,-1000,-1000,-1000,-144,
-121,-294,-144,-1000,-279, -83,  23, -53,-1000,-182,
 -58, -62, -98,-186,   7,  23,-295,-121,-1000,-248,
-238,-121,-210,-1000,-196,-273,-238,-1000,-115,-197,
-1000,-1000,   7,   7,   7,  23,  23,-1000, -72,-1000,
-1000,-1000,-1000,-1000,-121,-1000,-1000,-1000, -90,-1000,
-1000, -80, -82, -83,-1000,   7,   7,  23,-1000,-1000,
-1000, -85,   7,-1000 };
short yypgo[]={

   0, 326, 405, 404, 261, 284, 272, 335, 258, 323,
 230, 251, 192, 227, 229, 396, 255, 336, 360, 311,
 259, 257, 386, 252, 226, 373, 347, 344, 282, 337,
 338, 295, 293, 394, 290, 289, 288, 285, 279, 275,
 273, 302, 271, 325, 263, 291, 262, 260, 256 };
short yyr1[]={

   0,  32,  33,  33,  34,  34,  34,  34,  34,  34,
  35,  40,  40,  41,  36,  42,  42,  43,  13,  13,
  37,  44,  44,  45,  22,  22,  22,  22,  15,  15,
  14,  14,  38,  46,  47,  19,  19,  16,  16,  12,
  12,  12,  20,  20,  23,  23,  24,  39,  27,  27,
  27,  26,  25,  21,  21,  29,  29,  31,  31,  28,
  28,  28,  28,  28,  28,  28,  28,  28,  28,  28,
  28,  28,  30,  30,  30,  30,  30,  30,  30,  30,
  30,  30,  30,  17,  17,  18,  18,   1,   1,   4,
   4,   5,   5,   5,   5,   2,   2,   2,   6,   6,
  10,  10,  10,  11,  11,  11,   8,   8,   7,   7,
   7,   7,   3,   3,   3,   3,   3,   3,   3,   3,
   9,   9,   9,  48 };
short yyr2[]={

   0,   5,   0,   2,   1,   1,   1,   1,   1,   3,
   2,   1,   2,   4,   2,   1,   2,   4,   1,   3,
   2,   1,   2,   4,   1,   4,   2,   4,   2,   3,
   2,   4,   4,   4,   3,   0,   3,   4,   6,   0,
   1,   1,   2,   3,   0,   1,   2,   4,   2,   4,
   7,   2,   2,   3,   2,   2,   3,   2,   3,   3,
   1,   2,   3,   2,   4,   6,   4,   4,   6,   8,
   1,   0,   3,   3,   2,   4,   6,   4,   4,   6,
   8,   1,   0,   0,   1,   1,   3,   1,   3,   1,
   3,   1,   2,   6,   3,   1,   3,   3,   1,   3,
   1,   3,   3,   1,   3,   2,   4,   5,   1,   4,
   4,   6,   1,   1,   1,   1,   3,   3,   4,   3,
   1,   3,   3,   4 };
short yychk[]={

-1000, -32, -33, 267, -34, -35, -36, -37, -38, -39,
 257, 259, 260, 261, -46, -27, -47, -26, 263, -25,
 262, -29, -28,  -9, 269, 267, 270, 273, 276,  -8,
 287,  -7, 289,  -3, 258, 291, 292, 290, 299, -48,
 301, 263, 292, -40, -41, 287, -42, -43, -13, 287,
 -44, -45, 287, -33, -33, -20, 299, 294, 264, 287,
 -19, 301, 287, 268, -28, 294, 295,  -1,  -4,  -5,
  -2, 284,  -9,  -6,  -7, -10, 289, -11, 280, -29,
 268,  -1,  -1,  -1,  -9, 293, 299, 298, 287, 301,
 299,  -1, -33, -18,  -1, -20, 294, -41, 295, -43,
 293, 296, -45, 293, -21, 267, 268, -23, -24, 297,
 300, -16, -12, 265, 266, 287, -19, -16, 294, 294,
  -1, 283, 282,  -5, 275, 286, 285, 278, 299, 279,
 280, 287, 281,  -7,  -9, 268, 271, 274, 274, 277,
 295, -22, 287, 263, -17, -18, 287, 299, -14, -12,
  -1, 300, -21, 296, 302, -23,  -1, -22, 287, -22,
 294, -29, 268, 294, 294, -22, 296, 300, -13, 294,
 301, 302,  -4,  -5, 287,  -6,  -6, -10, -17, -11,
 -11, 299,  -7, -28, -28, -30,  -9, 267, 270, 273,
 276,  -8,  -1,  -1, 301, -15, 299, 300, -17, 296,
 302, -22, 300,  -1, 294, 294, 294, 294, 268, -12,
 293, -14, 299, 300, -17, 272, 295, -31, 268, -30,
  -1,  -1,  -1,  -9, 274, 277, -14, 297, 300, -14,
 300, -12, -13, -22, 302, -13, 300, -28,  -1, -30,
 268, 294, 271, 274, 274, 277, 295, -30,  -1, 302,
 -22, 300, -24, -22, 293, 294, 300, 294, -30, -30,
 -30,  -1,  -1, 274, -22, 272, 274, 277, -28, -30,
 -30,  -1, 274, -30 };
short yydef[]={

   2,  -2,   0,  71,   3,   4,   5,   6,   7,   8,
   0,   0,   0,   0,   2,   2,   0,   0,   0,  35,
   0,  71,   0, 112,  60,  71,   0,   0,   0,  70,
 120,   0,   0, 108,   0, 113, 114, 115,   0,   2,
   0,   0,   0,  10,  11,   0,  14,  15,   0,  18,
  20,  21,   0,   0,   0,  44,  39,  48,   0,  35,
  51,  39,  52,   0,   0,  55,   0,  61,  87,  89,
  91,   0, 112,  95, 103,  98,   0, 100,   0,  71,
  63,   0,   0,   0, 112,   0,  83,   0,   0,  39,
   0,   0,   0,   0,  85,  44,   9,  12,   0,  16,
   0,   0,  22,   0,   0,  71,   0,   0,  45,   0,
  42,   0,   0,  40,  41,   0,  34,   0,   1,  56,
  59,   0,   0,  92,   0,   0,   0,   0,  83,   0,
   0,   0,   0, 105, 112,  62,  71,  71,  82,   0,
   0, 121,  24,   0,   0,  84, 122,  83,   0,   0,
   0, 116, 117,   0, 119,   0,   0,   0,  19,   0,
  32,  71,  54,  47,  33,  46,  39,  43,   0,  49,
  39,  36,  88,  90,  94,  97,  96,  99,   0, 101,
 102,  83, 104,  64,  66,  67, 112,  82,   0,   0,
   0,  81,   0,   0,  39,  26,  39,  -2,   0,  39,
 118,  30, 109,  86, 123,  13,  17,  23,  53,   0,
   0,   0,   0, 110,   0,  71,   0,  82,  74,   0,
   0,   0,   0, 112,  82,   0,   0,   0,  28,   0,
 107,   0,   0,  37,   0,   0,   0,  65,  72,   0,
  73,  57,  82,  82,  82,   0,   0,  68,   0,  25,
  27,  29, 111,  31,   0,  50,  93,  58,  75,  77,
  78,   0,   0,  71,  38,  82,  82,   0,  69,  76,
  79,   0,  82,  80 };
#ifndef lint
static char yaccpar_sccsid[] = "@(#)yaccpar	4.1	(Berkeley)	2/11/83";
#endif

#
# define YYFLAG -1000
# define YYERROR goto yyerrlab
# define YYACCEPT return(0)
# define YYABORT return(1)

/*	parser for yacc output	*/

#ifdef YYDEBUG
int yydebug = 0; /* 1 for debugging */
#endif
YYSTYPE yyv[YYMAXDEPTH]; /* where the values are stored */
int yychar = -1; /* current input token number */
int yynerrs = 0;  /* number of errors */
short yyerrflag = 0;  /* error recovery flag */

yyparse() {

	short yys[YYMAXDEPTH];
	short yyj, yym;
	register YYSTYPE *yypvt;
	register short yystate, *yyps, yyn;
	register YYSTYPE *yypv;
	register short *yyxi;

	yystate = 0;
	yychar = -1;
	yynerrs = 0;
	yyerrflag = 0;
	yyps= &yys[-1];
	yypv= &yyv[-1];

 yystack:    /* put a state and value onto the stack */

#ifdef YYDEBUG
	if( yydebug  ) printf( "state %d, char 0%o\n", yystate, yychar );
#endif
		if( ++yyps> &yys[YYMAXDEPTH] ) { yyerror( "yacc stack overflow" ); return(1); }
		*yyps = yystate;
		++yypv;
		*yypv = yyval;

 yynewstate:

	yyn = yypact[yystate];

	if( yyn<= YYFLAG ) goto yydefault; /* simple state */

	if( yychar<0 ) if( (yychar=yylex())<0 ) yychar=0;
	if( (yyn += yychar)<0 || yyn >= YYLAST ) goto yydefault;

	if( yychk[ yyn=yyact[ yyn ] ] == yychar ){ /* valid shift */
		yychar = -1;
		yyval = yylval;
		yystate = yyn;
		if( yyerrflag > 0 ) --yyerrflag;
		goto yystack;
		}

 yydefault:
	/* default state action */

	if( (yyn=yydef[yystate]) == -2 ) {
		if( yychar<0 ) if( (yychar=yylex())<0 ) yychar = 0;
		/* look through exception table */

		for( yyxi=yyexca; (*yyxi!= (-1)) || (yyxi[1]!=yystate) ; yyxi += 2 ) ; /* VOID */

		while( *(yyxi+=2) >= 0 ){
			if( *yyxi == yychar ) break;
			}
		if( (yyn = yyxi[1]) < 0 ) return(0);   /* accept */
		}

	if( yyn == 0 ){ /* error */
		/* error ... attempt to resume parsing */

		switch( yyerrflag ){

		case 0:   /* brand new error */

			yyerror( "syntax error" );
		yyerrlab:
			++yynerrs;

		case 1:
		case 2: /* incompletely recovered error ... try again */

			yyerrflag = 3;

			/* find a state where "error" is a legal shift action */

			while ( yyps >= yys ) {
			   yyn = yypact[*yyps] + YYERRCODE;
			   if( yyn>= 0 && yyn < YYLAST && yychk[yyact[yyn]] == YYERRCODE ){
			      yystate = yyact[yyn];  /* simulate a shift of "error" */
			      goto yystack;
			      }
			   yyn = yypact[*yyps];

			   /* the current yyps has no shift onn "error", pop stack */

#ifdef YYDEBUG
			   if( yydebug ) printf( "error recovery pops state %d, uncovers %d\n", *yyps, yyps[-1] );
#endif
			   --yyps;
			   --yypv;
			   }

			/* there is no state on the stack with an error shift ... abort */

	yyabort:
			return(1);


		case 3:  /* no shift yet; clobber input char */

#ifdef YYDEBUG
			if( yydebug ) printf( "error recovery discards char %d\n", yychar );
#endif

			if( yychar == 0 ) goto yyabort; /* don't discard EOF, quit */
			yychar = -1;
			goto yynewstate;   /* try again in the same state */

			}

		}

	/* reduction by production yyn */

#ifdef YYDEBUG
		if( yydebug ) printf("reduce %d\n",yyn);
#endif
		yyps -= yyr2[yyn];
		yypvt = yypv;
		yypv -= yyr2[yyn];
		yyval = yypv[1];
		yym=yyn;
			/* consult goto table to find next state */
		yyn = yyr1[yyn];
		yyj = yypgo[yyn] + *yyps + 1;
		if( yyj>=YYLAST || yychk[ yystate = yyact[yyj] ] != -yyn ) yystate = yyact[yypgo[yyn]];
		switch(yym){
			
case 1:
# line 73 "gram.y"
{ if (justParse == 0) 
			beginInterpreter(syms, genBody(syms, yypvt[-2].sp.first)); } break;
case 9:
# line 89 "gram.y"
{ doInclude(yypvt[-1].c); } break;
case 13:
# line 103 "gram.y"
{ addConstant(syms, yypvt[-3].c, yypvt[-1].e); } break;
case 17:
# line 117 "gram.y"
{ struct list * p;
		for (p = yypvt[-3].l; p; p = p->next)
			addVariable(syms, p->value, yypvt[-1].t); } break;
case 18:
# line 124 "gram.y"
{ yyval.l = newList(yypvt[-0].c, 0); } break;
case 19:
# line 126 "gram.y"
{ yyval.l = newList(yypvt[-0].c, yypvt[-2].l); } break;
case 23:
# line 140 "gram.y"
{ addTypeDeclaration(syms, yypvt[-3].c, yypvt[-1].t); } break;
case 24:
# line 145 "gram.y"
{ yyval.t = checkType(lookupSymbol(syms, yypvt[-0].c)); } break;
case 25:
# line 147 "gram.y"
{ yyval.t = checkQualifications(checkType(lookupSymbol(syms, yypvt[-3].c)),
					yypvt[-1].l); } break;
case 26:
# line 150 "gram.y"
{ yyval.t = newFunctionType(yypvt[-0].l, 0); } break;
case 27:
# line 152 "gram.y"
{ yyval.t = newFunctionType(yypvt[-2].l, yypvt[-0].t); } break;
case 28:
# line 157 "gram.y"
{ yyval.l = 0; } break;
case 29:
# line 159 "gram.y"
{ yyval.l = yypvt[-1].l; } break;
case 30:
# line 164 "gram.y"
{ yyval.l = newTypelist(yypvt[-0].t, yypvt[-1].f, 0); } break;
case 31:
# line 166 "gram.y"
{ yyval.l = newTypelist(yypvt[-0].t, yypvt[-1].f, yypvt[-3].l); } break;
case 32:
# line 171 "gram.y"
{(syms->u.f.theFunctionSymbol)->u.f.code->next = 
			genBody(syms, yypvt[-1].s); 
		 syms = syms->surroundingContext; } break;
case 33:
# line 178 "gram.y"
{ addFunctionArguments(syms, yypvt[-2].l, yypvt[-1].t); } break;
case 34:
# line 183 "gram.y"
{ syms = addFunctionSymbol(syms, yypvt[-1].c, yypvt[-0].l); } break;
case 35:
# line 188 "gram.y"
{ yyval.l = 0; } break;
case 36:
# line 190 "gram.y"
{ yyval.l = yypvt[-1].l; } break;
case 37:
# line 195 "gram.y"
{ yyval.l = buildArgumentList(yypvt[-2].l, yypvt[-3].f, yypvt[-0].t, 0); } break;
case 38:
# line 197 "gram.y"
{ yyval.l = buildArgumentList(yypvt[-2].l, yypvt[-3].f, yypvt[-0].t, yypvt[-5].l); } break;
case 39:
# line 202 "gram.y"
{yyval.f = byValue; } break;
case 40:
# line 204 "gram.y"
{yyval.f = byName; } break;
case 41:
# line 206 "gram.y"
{yyval.f = byReference; } break;
case 42:
# line 211 "gram.y"
{ yyval.l = 0; } break;
case 43:
# line 213 "gram.y"
{ yyval.l = yypvt[-1].l; } break;
case 44:
# line 218 "gram.y"
{ yyval.t = 0; } break;
case 45:
# line 220 "gram.y"
{ yyval.t = yypvt[-0].t; } break;
case 46:
# line 225 "gram.y"
{ yyval.t = yypvt[-0].t; } break;
case 47:
# line 230 "gram.y"
{ buildClassTable(yypvt[-3].y);
		syms = syms->surroundingContext; } break;
case 48:
# line 236 "gram.y"
{struct typeRecord * t = 
			checkType(lookupSymbol(syms, "object"));
		 if (checkClass(t) == 0)
			yyerror("unable to find class `object'");
		yyval.y = yypvt[-1].y; 
		fillInParent(syms->definingType, t, 0); } break;
case 49:
# line 243 "gram.y"
{struct typeRecord * t = checkType(lookupSymbol(syms, yypvt[-1].c));
		 if (checkClass(t) == 0)
			yyserror("non class identifier %s used where class expected", yypvt[-1].c); 
		yyval.y = yypvt[-3].y; 
		fillInParent(syms->definingType, t, 0); } break;
case 50:
# line 249 "gram.y"
{struct typeRecord * t = checkType(lookupSymbol(syms, yypvt[-4].c));
		 if (checkClass(t) == 0)
			yyserror("non class identifier %s used where class expected", yypvt[-4].c); 
		yyval.y = yypvt[-6].y; 
		fillInParent(syms->definingType, t, yypvt[-2].l); } break;
case 51:
# line 258 "gram.y"
{yyval.y = yypvt[-1].y;
		 if (yypvt[-0].l != 0)
		 	yyval.y->u.c.typ = newQualifiedType(syms, yypvt[-0].l, yypvt[-1].y->u.c.typ);} break;
case 52:
# line 265 "gram.y"
{yyval.y = newClassSymbol(syms, globalSyms, yypvt[-0].c); 
		syms = yyval.y->u.c.typ->u.c.symbols; } break;
case 53:
# line 271 "gram.y"
{ yyval.s = yypvt[-1].sp.first; } break;
case 54:
# line 273 "gram.y"
{ yyval.s = newStatement(nullStatement); } break;
case 55:
# line 278 "gram.y"
{yyval.sp = yypvt[-1].sp;} break;
case 56:
# line 280 "gram.y"
{ yyval.sp.first = yypvt[-2].sp.first; yyval.sp.last = yypvt[-1].sp.last; 
		  yypvt[-2].sp.last->next = yypvt[-1].sp.first; } break;
case 57:
# line 286 "gram.y"
{yyval.sp = yypvt[-1].sp;} break;
case 58:
# line 288 "gram.y"
{ yyval.sp.first = yypvt[-2].sp.first; yyval.sp.last = yypvt[-1].sp.last; 
		  yypvt[-2].sp.last->next = yypvt[-1].sp.first; } break;
case 59:
# line 294 "gram.y"
{ yyval.sp.first = yyval.sp.last = genAssignmentStatement(yypvt[-2].e, yypvt[-0].e); } break;
case 60:
# line 296 "gram.y"
{ yyval.sp.first = yyval.sp.last = genReturnStatement(syms, 0); } break;
case 61:
# line 298 "gram.y"
{ yyval.sp.first = yyval.sp.last = genReturnStatement(syms, yypvt[-0].e); } break;
case 62:
# line 300 "gram.y"
{ yyval.sp.first = yypvt[-1].sp.first; 
		  yyval.sp.last = yypvt[-1].sp.last;} break;
case 63:
# line 303 "gram.y"
{ yyval.sp.first = yyval.sp.last = newStatement(nullStatement);} break;
case 64:
# line 305 "gram.y"
{yyval.sp.last = newStatement(nullStatement);
		 yyval.sp.first = genConditionalStatement(yypvt[-3].i, 
			booleanCheck(syms, yypvt[-2].e), 
			yypvt[-0].sp.first, yypvt[-0].sp.last, 0, 0, yyval.sp.last); } break;
case 65:
# line 310 "gram.y"
{yyval.sp.last = newStatement(nullStatement);
		 yyval.sp.first = genConditionalStatement(yypvt[-5].i, 
				booleanCheck(syms, yypvt[-4].e), 
				yypvt[-2].sp.first, yypvt[-2].sp.last, 
				yypvt[-0].sp.first, yypvt[-0].sp.last, yyval.sp.last); } break;
case 66:
# line 316 "gram.y"
{yyval.sp.last = newStatement(nullStatement);
		 yyval.sp.first = genWhileStatement(yypvt[-3].i, 
				booleanCheck(syms, yypvt[-2].e), yypvt[-0].sp.first, yypvt[-0].sp.last, 
					yyval.sp.last);} break;
case 67:
# line 321 "gram.y"
{yyval.sp.first = yyval.sp.last =
			genExpressionStatement(
				generateForRelation(syms, yypvt[-2].e, 0, yypvt[-0].sp.first,
					yypvt[-0].sp.last)); } break;
case 68:
# line 326 "gram.y"
{yyval.sp.first = yyval.sp.last =
			genExpressionStatement(
				generateForRelation(syms, yypvt[-4].e, yypvt[-2].e, yypvt[-0].sp.first,
					yypvt[-0].sp.last)); } break;
case 69:
# line 332 "gram.y"
{yyval.sp.last = newStatement(nullStatement);
		 yyval.sp.first = generateArithmeticForStatement(yypvt[-7].i, syms,
			yypvt[-6].e, yypvt[-4].e, yypvt[-2].e, yypvt[-0].sp.first, yypvt[-0].sp.last, yyval.sp.last); } break;
case 70:
# line 336 "gram.y"
{ yyval.sp.first = yyval.sp.last = genExpressionStatement(yypvt[-0].e);} break;
case 71:
# line 338 "gram.y"
{ yyval.sp.first = yyval.sp.last = newStatement(nullStatement); } break;
case 72:
# line 343 "gram.y"
{ yyval.sp.first = yyval.sp.last = genAssignmentStatement(yypvt[-2].e, yypvt[-0].e); } break;
case 73:
# line 345 "gram.y"
{ yyval.sp.first = yypvt[-1].sp.first; 
		  yyval.sp.last = yypvt[-1].sp.last;} break;
case 74:
# line 348 "gram.y"
{ yyval.sp.first = yyval.sp.last = newStatement(nullStatement);} break;
case 75:
# line 350 "gram.y"
{yyval.sp.last = newStatement(nullStatement);
		 yyval.sp.first = genConditionalStatement(yypvt[-3].i, 
			booleanCheck(syms, yypvt[-2].e), 
			yypvt[-0].sp.first, yypvt[-0].sp.last, 0, 0, yyval.sp.last); } break;
case 76:
# line 355 "gram.y"
{yyval.sp.last = newStatement(nullStatement);
		 yyval.sp.first = genConditionalStatement(yypvt[-5].i, 
				booleanCheck(syms, yypvt[-4].e), 
				yypvt[-2].sp.first, yypvt[-2].sp.last, 
				yypvt[-0].sp.first, yypvt[-0].sp.last, yyval.sp.last); } break;
case 77:
# line 361 "gram.y"
{yyval.sp.last = newStatement(nullStatement);
		 yyval.sp.first = genWhileStatement(yypvt[-3].i, 
				booleanCheck(syms, yypvt[-2].e), yypvt[-0].sp.first, yypvt[-0].sp.last, 
					yyval.sp.last);} break;
case 78:
# line 366 "gram.y"
{yyval.sp.first = yyval.sp.last =
			genExpressionStatement(
				generateForRelation(syms, yypvt[-2].e, 0, yypvt[-0].sp.first,
					yypvt[-0].sp.last)); } break;
case 79:
# line 371 "gram.y"
{yyval.sp.first = yyval.sp.last =
			genExpressionStatement(
				generateForRelation(syms, yypvt[-4].e, yypvt[-2].e, yypvt[-0].sp.first,
					yypvt[-0].sp.last)); } break;
case 80:
# line 377 "gram.y"
{yyval.sp.last = newStatement(nullStatement);
		 yyval.sp.first = generateArithmeticForStatement(yypvt[-7].i, syms,
			yypvt[-6].e, yypvt[-4].e, yypvt[-2].e, yypvt[-0].sp.first, yypvt[-0].sp.last, yyval.sp.last); } break;
case 81:
# line 381 "gram.y"
{ yyval.sp.first = yyval.sp.last = genExpressionStatement(yypvt[-0].e);} break;
case 82:
# line 383 "gram.y"
{ yyval.sp.first = yyval.sp.last = newStatement(nullStatement); } break;
case 83:
# line 388 "gram.y"
{ yyval.l = 0; } break;
case 84:
# line 390 "gram.y"
{ yyval.l = yypvt[-0].l; } break;
case 85:
# line 395 "gram.y"
{ yyval.l = newList((char *) yypvt[-0].e, 0); } break;
case 86:
# line 397 "gram.y"
{ yyval.l = newList((char *) yypvt[-0].e, yypvt[-2].l); } break;
case 87:
# line 402 "gram.y"
{ yyval.e = yypvt[-0].e; } break;
case 88:
# line 404 "gram.y"
{yyval.e = generateBinaryOperator(syms, yypvt[-1].c, yypvt[-2].e, yypvt[-0].e);} break;
case 89:
# line 409 "gram.y"
{ yyval.e = yypvt[-0].e; } break;
case 90:
# line 411 "gram.y"
{yyval.e = generateBinaryOperator(syms, yypvt[-1].c, yypvt[-2].e, yypvt[-0].e);} break;
case 91:
# line 416 "gram.y"
{ yyval.e = yypvt[-0].e; } break;
case 92:
# line 418 "gram.y"
{ yyval.e = generateUnaryOperator(syms, "not", yypvt[-0].e); } break;
case 93:
# line 420 "gram.y"
{ yyval.e = genPatternMatch(syms, yypvt[-5].e, 
			lookupIdentifier(syms, yypvt[-3].c), yypvt[-1].l); } break;
case 94:
# line 423 "gram.y"
{ yyval.e = genPatternMatch(syms, yypvt[-2].e, 
			lookupIdentifier(syms, yypvt[-0].c), 0); } break;
case 95:
# line 429 "gram.y"
{yyval.e = yypvt[-0].e;} break;
case 96:
# line 431 "gram.y"
{yyval.e = generateBinaryOperator(syms, yypvt[-1].c, yypvt[-2].e, yypvt[-0].e);} break;
case 97:
# line 433 "gram.y"
{yyval.e = generateLeftArrow(syms, yypvt[-2].e, yypvt[-0].e); } break;
case 98:
# line 438 "gram.y"
{yyval.e = yypvt[-0].e;} break;
case 99:
# line 440 "gram.y"
{yyval.e = generateBinaryOperator(syms, yypvt[-1].c, yypvt[-2].e, yypvt[-0].e);} break;
case 100:
# line 445 "gram.y"
{yyval.e = yypvt[-0].e;} break;
case 101:
# line 447 "gram.y"
{yyval.e = generateBinaryOperator(syms, yypvt[-1].c, yypvt[-2].e, yypvt[-0].e);} break;
case 102:
# line 449 "gram.y"
{yyval.e = generateBinaryOperator(syms, yypvt[-1].c, yypvt[-2].e, yypvt[-0].e);} break;
case 103:
# line 454 "gram.y"
{yyval.e = yypvt[-0].e;} break;
case 104:
# line 456 "gram.y"
{yyval.e = generateBinaryOperator(syms, yypvt[-1].c, yypvt[-2].e, yypvt[-0].e);} break;
case 105:
# line 458 "gram.y"
{ yyval.e = generateUnaryOperator(syms, "negation", yypvt[-0].e); } break;
case 106:
# line 463 "gram.y"
{yyval.e = generateFunctionCall(syms, yypvt[-3].e, yypvt[-1].l, 0); } break;
case 107:
# line 465 "gram.y"
{yyval.e = generateCFunctionCall(yypvt[-3].c, yypvt[-1].l, 0);} break;
case 108:
# line 470 "gram.y"
{yyval.e = yypvt[-0].e; } break;
case 109:
# line 472 "gram.y"
{yyval.e = newExpression(doSpecialCall);
		 yyval.e->u.c.index = 22;
		 yyval.e->u.c.args = newList((char *) yypvt[-1].e, 0);
		 yyval.e->resultType = booleanType;} break;
case 110:
# line 477 "gram.y"
{yyval.e = generateFunctionCall(syms, yypvt[-3].e, yypvt[-1].l, 1); } break;
case 111:
# line 479 "gram.y"
{yyval.e = generateCFunctionCall(yypvt[-4].c, yypvt[-2].l, yypvt[-0].t);} break;
case 112:
# line 484 "gram.y"
{yyval.e = yypvt[-0].e; } break;
case 113:
# line 486 "gram.y"
{yyval.e = integerConstant(yypvt[-0].i);} break;
case 114:
# line 488 "gram.y"
{yyval.e = stringConstant(yypvt[-0].c);} break;
case 115:
# line 490 "gram.y"
{yyval.e = realConstant(yypvt[-0].r); } break;
case 116:
# line 492 "gram.y"
{yyval.e = yypvt[-1].e;} break;
case 117:
# line 494 "gram.y"
{yyval.e = newExpression(makeClosure);
		 yyval.e->u.l.context = newExpression(getCurrentContext); 
		 yyval.e->u.l.code = genBody(syms, yypvt[-0].s);
		 yyval.e->resultType = syms->definingType;
		 syms = syms->surroundingContext; } break;
case 118:
# line 500 "gram.y"
{yyval.e = yypvt[-3].e; 
		 yyval.e->resultType = checkQualifications(yyval.e->resultType, yypvt[-1].l);} break;
case 119:
# line 503 "gram.y"
{yyval.e = generateArrayLiteral(syms, yypvt[-1].l);} break;
case 120:
# line 508 "gram.y"
{yyval.e = lookupIdentifier(syms, yypvt[-0].c); } break;
case 121:
# line 510 "gram.y"
{addVariable(syms, yypvt[-2].c, yypvt[-0].t); 
		 yyval.e = lookupIdentifier(syms, yypvt[-2].c); } break;
case 122:
# line 513 "gram.y"
{yyval.e = lookupField(yypvt[-2].e, yypvt[-2].e->resultType, yypvt[-0].c);
		if (yyval.e == 0)
			yyserror("unknown field name used: %s", yypvt[-0].c);
		} break;
case 123:
# line 521 "gram.y"
{syms = generateFunctionExpression(syms, yypvt[-2].l, yypvt[-1].t);} break; 
		}
		goto yystack;  /* stack new state and value */

	}
