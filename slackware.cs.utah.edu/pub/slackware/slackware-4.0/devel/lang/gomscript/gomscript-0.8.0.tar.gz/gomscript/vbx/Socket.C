
#include "Socket.h"


/* ---------------------------------------------------------------------------
   Function prototypes
   --------------------------------------------------------------------------- */


/* ---------------------------------------------------------------------------
   Function list and entry point
   --------------------------------------------------------------------------- */

static FuncDescr functions[]={
  /* name               address      num of parms    parm types                */
  /* --------           ---------    ------------    ----------                */
    0
};





typedef Expr* (NativeInstance::* MethPtr)(Elist&);



NativeInstance* MakeSocket(Elist& args) {
    Socket* retval=new Socket(args);
    return retval->IsValid() ? retval : 0;
}



MethodDescr Socket_methods[]={
  {"Write", (MethPtr)&Socket::Write,    0, 0},
  {"Read", (MethPtr)&Socket::ReadToken, 0, 0},
  {"Close", (MethPtr)&Socket::Close,    0, 0},
  0
};




static ClassDescr classes[]={
  {"Socket", 0, MakeSocket, Socket_methods}, 
  0
  };


static void LoadFunction()   {}
static void UnLoadFunction() {}


static Contents contents={0, (ClassDescr*)classes, 
			  LoadFunction, UnLoadFunction};

Contents* EntryPoint() {return &contents;}


