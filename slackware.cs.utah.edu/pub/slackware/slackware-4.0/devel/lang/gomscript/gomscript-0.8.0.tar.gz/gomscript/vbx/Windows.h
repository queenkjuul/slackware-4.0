#ifndef WINDOWS_H
#define WINDOWS_H

#include <v/vapp.h>     // We are derived from vApp
#include <v/vawinfo.h>  // Need for app info
#include <v/vcmdwin.h>  // So we can use vCmdWindow
#include <v/vmenu.h>
#include <v/vkeys.h>


class GomWindow : public vCmdWindow {
  friend int AppMain(int, char**);        // allow AppMain access
  vMenuPane* myMenu;              // For the menu bar
public: 
  GomWindow(char*, int, int);
  virtual ~GomWindow();      
  virtual void WindowCommand(ItemVal id,ItemVal val,CmdType cType);
  virtual void KeyIn(vKey keysym, unsigned int shift);
  
private: 
  // vMenuPane* myMenu;              // For the menu bar
  // tCanvasPane* myCanvas;          // For the canvas
  // vStatusPane* myStatus;          // For the status bar
  // vCommandPane* myCmdPane;        // for the command pane  
  // tDialog* sampleDialog;
  // tModalDialog* sampleModalDialog;
};



class GomApp : public vApp {
  friend int AppMain(int, char**); // allow AppMain access
  
public:

  GomApp(char* name) : vApp(name) {}      // just call vApp
  virtual ~GomApp() {}
  
  // Routines from vApp that are normally overridden
  
  virtual vWindow* NewAppWin(vWindow* win, char* name, int h, int w,
			     vAppWinInfo* winInfo);
  virtual void Exit(void);
  virtual void CloseAppWin(vWindow* win);
  virtual void AppCommand(vWindow* win, ItemVal id,
			  ItemVal val, CmdType cType);
  virtual void KeyIn(vWindow* win, vKey key,
		     unsigned int shift);
  void initialize(int& argc, char** argv);
  void doEventLoop();

};

#endif


