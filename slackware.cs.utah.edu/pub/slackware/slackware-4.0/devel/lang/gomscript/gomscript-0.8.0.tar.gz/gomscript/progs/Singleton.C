#include <stdio.h>
#include <iostream.h>
#include "Input.h"


int main(int argc, char* argv[]) {
    
    Input* a=Input::Create();
    Input* b=Input::Create();
    Input* c=Input::Create();

    return 0;
}
