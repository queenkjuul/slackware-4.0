
#include "defs.h"

/* ---------------------------------------------------------------------------
   Function prototypes
   --------------------------------------------------------------------------- */


/* ---------------------------------------------------------------------------
   Function list and entry point
   --------------------------------------------------------------------------- */

static FuncDescr functions[]={
  /* name               address           num of parms   parm types                    */
  /* --------           ---------         ------------   ----------                    */
  {"Fibonacci",         0,                  0,           0},
  0
};

static Contents contents={functions, 0, 0, 0};

Contents* EntryPoint() {
  return &contents;
}




