#include <stdio.h>
#include <iostream.h>
#include <v/vwindow.h>


int AppMain(int argc, char* argv[]) {
    vWindow* win=new vWindow();
    return 0;
}
