// always use these ifdef's for include-files that are possibly included more than once.

#ifndef  CLASS_valueAccess_DEF
#define  CLASS_valueAccess_DEF

#include	<stream.h>
#include        <unistd.h>
#include	<errno.h>
#include	<fcntl.h>
#include	<stdlib.h>

extern	int errno;
//extern	char *sys_errlist[];

#define		BUFFERSIZE	2048
#define		ERROR		-1
#ifdef __linux__
#define         TRUE            1
#define         FALSE           0
#endif

#ifndef PARSFILT_WHITESPACE
#define PARSFILT_WHITESPACE " \t"
#endif

#define SKIP_WS(PP) (*(PP)) += strspn(*(PP), PARSFILT_WHITESPACE);

class valueAccess {
public:

  // obtain values from underlying resource via command (systemcall or shell-script)
 
  valueAccess () {} 
  ~valueAccess () {}
  int doCall (char *cmd);
  char *getBuf (void) {return buf;}
private:
  char buf[BUFFERSIZE];
  int readPipe (int fd, char *ptr);
};

class activity {
public:

  // determine activiy ASN.1 construct from buffer contents

  activity () {activityString[0] = '\0';}
  ~activity () {}
  void parseActivity (char *ss);
  char *getActivity (void) {return activityString;}
  void putActivityString (char *s) {strcpy (activityString, s); }
private:
  char activityString[BUFFERSIZE];
}; 

#endif 
