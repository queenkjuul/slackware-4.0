#ifndef CONTACT_H
#define CONTACT_H

short SendUsageToServer(char* progname="<unknown program>", 
			char* msg=0, int server_port=1717);


#endif
