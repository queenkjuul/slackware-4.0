#ifndef INPUT_H
#define INPUT_H

#include <stdio.h>
#include <iostream.h>
#include "CL_List.h"


/* Implementation as a singleton */

class InputSource;
typedef CL_List<InputSource*> InputStack;

class Input {
    int            _nesting_level;
    static Input*  _inp;
                   Input();             // don't allocate on the stack !
    InputStack     _stack;
public:
                   ~Input();
    static         Input* GetInput();   // only way to create Inputs !
    char           GetChar();
    void           Push(istream& is);
    void           Push(FILE* fp);
    void           Push(char* str);
    void           Pop();
    bool           IsEmpty();
    void           IncrNestingLevel();
};


#endif
