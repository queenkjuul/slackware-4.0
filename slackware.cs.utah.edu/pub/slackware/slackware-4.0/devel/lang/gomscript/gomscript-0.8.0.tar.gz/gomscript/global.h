#ifndef GLOBAL_H
#define GLOBAL_H

#define START_DEL " <START> "
#define END_DEL   " <END> "

enum Operator     {op_plus, op_minus, op_mult, op_div, op_mod};
enum CompOperator {lt=0, lteq, gt, gteq, eq, not_eq};
enum BoolOperator {and_op=0, or_op=1, not_op};
enum BType         {UNDEFINED=-1, INT_TYPE=1, STRING_TYPE, BOOL_TYPE, LIST_TYPE, STRUCT_TYPE,
		    FUNC_TYPE, NATIVE_FUNC_TYPE, METHOD_TYPE, NATIVE_METHOD_TYPE, IDENT_TYPE, 
		    UNARY_TYPE, BIN_TYPE, LITERAL_TYPE, FUNC_CALL_TYPE, METHOD_CALL_TYPE, 
		    CLASS_TYPE, NATIVE_CLASS_TYPE, INST_TYPE, NATIVE_INST_TYPE, CREATION_TYPE,
		    PAIR_TYPE, NILVAL_TYPE};
enum StmtType     {NORMAL=0, RET_STMT=1, WHILE_STMT, BREAK_STMT, IF_STMT, FOR_STMT, VARS_STMT};


#endif
