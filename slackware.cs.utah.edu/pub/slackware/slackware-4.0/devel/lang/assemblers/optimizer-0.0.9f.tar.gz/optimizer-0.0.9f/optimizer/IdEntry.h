/*
  Optimizer
  IdEntry header file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#ifndef _IDENTRY_H_
#define _IDENTRY_H_

typedef class IdEntry *PIdEntry;

//
//	Class name : IdEntry
//
//	Description :
//
class IdEntry {
  friend Holder;
private:
  char *name;
  char *label;
  char *align;
  PIdEntry next;                    // Pointer to the next global id
public:
  IdEntry(char *s1,char *s2);       // Constructor
  ~IdEntry();                       // Destructor

  char *getname(void);              // Returns the name
  void setlabel(char *s);           // Sets the label
  char *getlabel(void);             // Returns the label
  unsigned int getsize(void);       // Returns the size
  void setalign(char *s);           // Sets the alignment
  char *getalign(void);             // Gets the alignment
  void convert(void);               // Converts the name string

  void print(void);                 // Print the entry
};

#endif
