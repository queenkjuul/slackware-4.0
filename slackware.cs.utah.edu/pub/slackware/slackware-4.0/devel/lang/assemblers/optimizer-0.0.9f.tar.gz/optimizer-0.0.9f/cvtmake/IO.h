/*
  Optimizer
  GAS header file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#ifndef _GAS_H_
#define _GAS_H_

#include "Global.h"
#include "Holder.h"
#include "Entry.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <fstream.h>
#include <string.h>

extern FILE *in;
extern FILE *out;

//
//	Method name : loadFile
//
//	Description : Loads the source-file into a buffer
//	Input : ---
//	Output : ---
//
void Holder::loadFile(void) {
 char str[MaxSize];

 rewind(in);
 while (!feof(in)) {
   strcpy(str,"");
   fgets(str,MaxSize-1,in);
   this->insert(str);
 }
}

//
//	Method name : saveFile
//
//	Description : Saves the buffer to the dest-file
//	Input : ---
//	Output : ---
//
void Holder::saveFile(void) {
  PEntry tmp;

  tmp = this->firstEntry;
  while (tmp != NULL) {
    fputs(tmp->getstr(), out);
    tmp = tmp->next;
  }
}


#endif
