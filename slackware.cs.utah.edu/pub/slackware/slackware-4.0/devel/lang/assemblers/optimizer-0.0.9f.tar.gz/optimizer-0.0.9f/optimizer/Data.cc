/*
  Optimizer
  Data C++ file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#include "Data.h"
#include "Misc.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <string.h>

//
//	Method name : Data
//
//	Description : Constructor to Data
//	Input : ---
//	Output : ---
//
Data::Data(char *s) {
  unsigned int length;

  this->next = (PData) NULL;
  if (strcmp(s,"")) {
    length = strlen(s) + 1;
    this->name = new char[length];
    if (!this->name) alloc_error();
    strcpy(this->name,s);
  } else {
    length = 1;
    this->name = new char[length];
    if (!this->name) alloc_error();
    strcpy(this->name,"");
  }
}


//
//	Method name : ~Data
//
//	Description : Destructor to Data
//	Input : ---
//	Output : ---
//
Data::~Data() {
  delete[] this->name; 
}

//
//	Method name : getname
//
//	Description : Gets the name
//	Input : ---
//	Output : The name
//
char *Data::getname(void) {
  return this->name; 
}

//
//	Method name : print
//
//	Description : Prints the Data
//	Input : ---
//	Output : ---
//
void Data::print(void) {
  cout << "\tData value  : " << this->name << "\n";
}




