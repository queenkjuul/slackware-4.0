/*
  cvtmake
  Entry header file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#ifndef _ENTRY_H_
#define _ENTRY_H_

typedef class Holder *PHolder;
typedef class Entry *PEntry;


//
//	Class name : Entry
//
//	Description : Entry in Holder
//
class Entry {
  friend class Holder;
private:
  char *str;
  PEntry next;                                 // Next pointer
public:
  Entry(char *curEntry);                       // Constructor
  ~Entry();                                    // Destructor
  char *getstr(void);                          // Returns the string
  void print(void);                            // Prints the entry
};

#endif
