/*
  Optimizer
  NASM header file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#ifndef _NASM_H_
#define _NASM_H_

#include "Global.h"
#include "Holder.h"
#include "Entry.h"
#include "IdEntry.h"
#include "optimizer.tab.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <string.h>

//
//	Method name : optP5
//
//	Description : Optimize to Pentium
//	Input : ---
//	Output : ---
//
void Holder::optP5(void){

}


//
//	Method name : optP6
//
//	Description : Optimize to Pentium Pro
//	Input : ---
//	Output : ---
//
void Holder::optP6(void){

}


//
//	Method name : optMMX
//
//	Description : Optimize with MMX support
//	Input : ---
//	Output : ---
//
void Holder::optMMX(void){

}

#endif
