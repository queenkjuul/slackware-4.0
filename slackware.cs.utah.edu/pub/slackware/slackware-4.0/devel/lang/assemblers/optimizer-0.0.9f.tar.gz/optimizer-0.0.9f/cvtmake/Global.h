/*
  cvtmake
  Global Header file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#ifndef _GLOBAL_H_
#define _GLOBAL_H_

// Version number
#define VERSION "0.1c"

// Global constants
#define MaxSize     256

// Processor Defines
#define I486          0
#define PENTIUM       1   
#define PENTIUMMMX    2
#define PENTIUMPRO    4
#define PENTIUMII     8

// Assemblers
#define GNU           0
#define NASM          1

// Optimizer call
#define I486str       "optimizer -n -I486 "
#define P5str         "optimizer -n -P5 "
#define P5MMXstr      "optimizer -n -P5MMX "
#define P6str         "optimizer -n -P6 "
#define PIIstr        "optimizer -n -PII "

#endif

