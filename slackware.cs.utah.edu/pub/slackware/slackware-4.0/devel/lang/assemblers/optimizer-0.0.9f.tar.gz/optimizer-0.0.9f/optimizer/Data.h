/*
  Optimizer
  Data header file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#ifndef _DATA_H_
#define _DATA_H_

typedef class Data *PData;
typedef class GloblEntry *PGloblEntry;

//
//	Class name : Data
//
//	Description :
//
class Data {
  friend GloblEntry;
private:
  char *name;
  PData next;                       // Pointer to the next data id
public:
  Data(char *s);                    // Constructor
  ~Data();                          // Destructor

  char *getname(void);              // Gets the name

  void print(void);                 // Print the entry
};

#endif
