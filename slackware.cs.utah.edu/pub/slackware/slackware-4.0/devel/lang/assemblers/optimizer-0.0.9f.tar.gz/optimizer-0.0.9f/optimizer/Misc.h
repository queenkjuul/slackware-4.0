/*
  Optimizer
  Misc header file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#ifndef _MISC_H_
#define _MISC_H_

#include <stdio.h>
#include <iostream.h>
#include <string.h>
#include "Global.h"
#include "Holder.h"
#include "Entry.h"
#include "IdEntry.h"

void alloc_error(void);                    // Memory allocation error

void strdel(char **s1,char *s2, char *s3); // Deletes a substring and inserts another instead
void strdel(char **s1,unsigned int from);  // Deletes a substring (OVERLOADED)

bool chkreg(char *s);                      // Returns true if s contains a register 

unsigned int isReg(char *s);               // 

char *cleanreg(char *s);                   // Cleans the reg-name for "(" and ")"

bool chknum(char *s);                      // Returns true if s contains a number

int findnum(char *s);                      // Return the index to the number

bool isLocalLabel(char *s);                // Returns true if its a local label

#endif
