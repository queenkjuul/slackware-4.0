/*
  cvtmake
  Misc header file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#ifndef _MISC_H_
#define _MISC_H_

//
//	Method name : error
//
//	Description : Writes a error message 
//	Input : The error message
//	Output : Error code
//
int error(char *s) {
  cerr << "cvtmake v" << VERSION << " ERROR : " << s << "\n\n";
  exit(1);
}

#endif
