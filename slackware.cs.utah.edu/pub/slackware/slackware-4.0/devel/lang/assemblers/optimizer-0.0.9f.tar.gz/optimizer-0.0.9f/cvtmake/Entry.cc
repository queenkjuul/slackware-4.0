/*
  cvtmake
  Entry C++ file
*/

/*
 *  Copyright (C) 1997,1998  Jesper Pedersen <jews@imada.ou.dk>
 *  This code is released under GNU GPL version 2 or later
 */

#include <stdio.h>
#include <iostream.h>
#include <string.h>
#include "Global.h"
#include "Holder.h"
#include "Entry.h"

//
//	Method name : Entry
//
//	Description : Constructor to Entry
//	Input : The information for the entry
//	Output : ---
//
Entry::Entry(char *curEntry) {
  int length;

  length = strlen(curEntry) + 1;
  this->str = new char[length];
  strcpy(this->str,curEntry);

  this->next = NULL;
}

//
//	Method name : ~Entry
//
//	Description : Destructor to Entry
//	Input : ---
//	Output : ---
//
Entry::~Entry(void) {
  delete this->str;
}

//
//	Method name : getstr
//
//	Description : Returns the string
//	Input : ---
//	Output : The string
//
char *Entry::getstr(void){
  return this->str;
}

//
//	Method name : print
//
//	Description : Prints the entry
//	Input : ---
//	Output : ---
//
void Entry::print(void){
  cout << "Str     : " << this->str;
}
