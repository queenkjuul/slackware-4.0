/*
 * AS-Portierung 
 *
 * AS-Codegeneratormodul fuer die Texas Instruments TMS320C2x-Familie
 *
 * 19.08.96: Erstellung
 */

extern void code3202x_init(void);
