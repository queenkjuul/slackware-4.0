/*
 * AS-Portierung 
 *
 * AS-Codegeneratormodul fuer die Texas Instruments TMS320C5x-Familie
 *
 * 19.08.96: Erstellung
 */

extern void code3205x_init(void);
