/* asmmessages.h */
/*****************************************************************************/
/* AS-Portierung                                                             */
/*                                                                           */
/* Einlesen und Verwalten von Meldungs-Strings                               */
/*                                                                           */
/* Historie: 13. 8.1997 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern char *getmessage(int Num);

extern void asmmessages_init(char *File, char *Path);
