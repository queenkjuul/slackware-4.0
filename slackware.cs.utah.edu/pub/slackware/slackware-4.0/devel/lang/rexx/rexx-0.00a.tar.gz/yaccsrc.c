
/*  A Bison parser, made from yaccsrc.y  */

#define YYBISON 1  /* Identify Bison output.  */

#define	ADDRESS	258
#define	ARG	259
#define	COMMAND	260
#define	CALL	261
#define	DO	262
#define	TO	263
#define	BY	264
#define	FOR	265
#define	WHILE	266
#define	UNTIL	267
#define	EXIT	268
#define	IF	269
#define	THEN	270
#define	ELSE	271
#define	ITERATE	272
#define	INTERPRET	273
#define	LEAVE	274
#define	NOP	275
#define	NUMERIC	276
#define	PARSE	277
#define	EXTERNAL	278
#define	SOURCE	279
#define	VAR	280
#define	VALUE	281
#define	WITH	282
#define	PROCEDURE	283
#define	EXPOSE	284
#define	PULL	285
#define	PUSH	286
#define	QUEUE	287
#define	RETURN	288
#define	SAY	289
#define	SELECT	290
#define	WHEN	291
#define	DROP	292
#define	OTHERWISE	293
#define	SIGNAL	294
#define	ON	295
#define	OFF	296
#define	ERROR	297
#define	SYNTAX	298
#define	HALT	299
#define	NOVALUE	300
#define	TRACE	301
#define	END	302
#define	NULLSTRING	303
#define	UPPER	304
#define	INTERMEDIATES	305
#define	LABELS	306
#define	ASSIGNMENTVARIABLE	307
#define	STATSEP	308
#define	FOREVER	309
#define	ALL	310
#define	COMMANDS	311
#define	ERRORS	312
#define	NORMAL	313
#define	NEGATIVE	314
#define	RESULTS	315
#define	SCAN	316
#define	DIGITS	317
#define	FORM	318
#define	FUZZ	319
#define	SCIENTIFIC	320
#define	ENGINEERING	321
#define	BANGBANG	322
#define	BANGWHAT	323
#define	BANG	324
#define	WHATBANG	325
#define	WHATWHAT	326
#define	WHAT	327
#define	NOT	328
#define	CONCATENATE	329
#define	MODULUS	330
#define	GTE	331
#define	GT	332
#define	LTE	333
#define	LT	334
#define	DIFFERENT	335
#define	EQUALEQUAL	336
#define	NOTEQUALEQUAL	337
#define	OFFSET	338
#define	SPACE	339
#define	EXP	340
#define	XOR	341
#define	PLACEHOLDER	342
#define	CONSYMBOL	343
#define	SIMSYMBOL	344
#define	EXFUNCNAME	345
#define	INFUNCNAME	346
#define	LABEL	347
#define	DOVARIABLE	348
#define	SYMBOL	349
#define	HEXSTRING	350
#define	STRING	351
#define	VERSION	352
#define	LINEIN	353
#define	WHATEVER	354
#define	CCAT	355
#define	UMINUS	356
#define	UPLUSS	357



#ifndef lint
static char *RCSid = "$Id: yaccsrc.y,v 1.10 1992/04/05 20:37:15 anders Exp anders $";
#endif

/*
 * Copyright (C) 1992 Anders Christensen <anders@solan.unit.no>
 * Read file README for more information on copying
 */

/*
 * $Log: yaccsrc.y,v $
 * Revision 1.10  1992/04/05  20:37:15  anders
 * Added copyright notice
 * Made changes to DROP, ADDRESS and TRACE
 *
 * Revision 1.9  1992/03/22  18:58:46  anders
 * Made strings allocated through stralloc() allign to 8 byte
 *    boundaries.
 *
 * Revision 1.8  1992/03/22  00:42:40  anders
 * Added #include <stdio.h> as this is not done in rexx.h any more.
 * Added #include <alloca.h> for use on SGI
 * Removed %expect 7 directive, which is not compatible with yacc
 *
 * Revision 1.7  1992/03/01  19:29:33  anders
 * Changed the support for templates, to fix a bug.
 *
 * Revision 1.6  1990/12/11  00:35:33  anders
 * Removed (another) bug related to line numbers (probably the last
 *     one!). Just an expression (used for external commands) does not
 *     have a 'reserved' word, and a special dummy rule had to be
 *     inserted.
 *
 * Revision 1.4  90/12/11  00:00:15  anders
 * Removed bug that assigned wrong line/character number to the 
 *     leave statement. There might still be some trouble with getting 
 *     the linenumbers of the statements correct.
 * 
 * Revision 1.3  90/12/10  18:41:09  anders
 * Removed bug: the linenumbers of the nop-statement were shifted one
 *     line up. The tline/tchar variables used instead of next{line,char}
 * 
 * Revision 1.2  90/12/10  04:10:45  anders
 * Removed bug which set linenumbers to incorrect values. They got 
 *     the (integer) value of a pointer.
 * 
 * Revision 1.1  90/08/08  02:28:52  anders
 * Initial revision
 * 
 * Revision 1.1  90/08/08  02:23:11  anders
 * Initial revision
 * 
 */

#include "rexx.h"
#if defined(SGI)
#include <alloca.h>
#endif
#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>


#define YYSTYPE nodeptr

extern nodeptr rootnode ;
extern char retvalue[] ;
extern int nextstart, nextline, tline, tstart ;

nodeptr makenode( int type, int numb, ... ) ;
char *stralloc( char *ptr ) ;
void checkdosyntax( nodeptr this ) ;
void newlabel( nodeptr this ) ;

 
#define YYDEBUG 0

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#include <stdio.h>

#ifndef __STDC__
#define const
#endif



#define	YYFINAL		343
#define	YYFLAG		-32768
#define	YYNTBASE	116

#define YYTRANSLATE(x) ((unsigned)(x) <= 357 ? yytranslate[x] : 209)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,   110,   101,     2,   114,
   115,   108,   106,   113,   107,     2,   109,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,   104,
   102,   103,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,   100,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
    66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
    76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
    86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
    96,    97,    98,    99,   105,   111,   112
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     3,     5,     8,    10,    12,    13,    15,    16,    19,
    21,    23,    25,    27,    29,    31,    33,    35,    37,    39,
    41,    43,    45,    47,    49,    51,    53,    55,    57,    59,
    61,    63,    65,    67,    69,    71,    73,    75,    77,    79,
    81,    83,    85,    87,    89,    91,    93,    95,    97,    99,
   101,   103,   105,   107,   109,   111,   113,   115,   117,   119,
   121,   123,   125,   127,   132,   134,   139,   141,   143,   147,
   153,   155,   157,   158,   159,   163,   166,   174,   181,   183,
   185,   186,   188,   191,   194,   197,   198,   201,   204,   205,
   209,   213,   220,   230,   234,   238,   241,   244,   246,   250,
   253,   256,   261,   266,   271,   273,   275,   276,   281,   287,
   292,   298,   302,   304,   306,   308,   310,   312,   314,   316,
   319,   323,   326,   331,   335,   339,   343,   347,   351,   358,
   361,   363,   370,   374,   375,   380,   384,   389,   391,   393,
   395,   397,   399,   401,   403,   405,   410,   414,   416,   420,
   424,   426,   430,   433,   437,   441,   445,   449,   453,   457,
   461,   465,   469,   473,   477,   481,   485,   489,   493,   497,
   501,   505,   509,   511,   513,   515,   517,   519,   522,   525,
   529,   533,   537,   541,   543,   545,   549,   551,   554,   557,
   559,   563,   565,   567,   569,   572,   575,   576,   580,   582,
   584,   585,   588,   590,   592,   594
};

#endif

static const short yyrhs[] = {   119,
   117,     0,   119,     0,   121,   117,     0,   121,     0,   117,
     0,     0,   120,     0,     0,    53,   120,     0,    53,     0,
   149,     0,   155,     0,   151,     0,   152,     0,   157,     0,
   162,     0,   163,     0,   164,     0,   165,     0,   166,     0,
   167,     0,   169,     0,   170,     0,   171,     0,   173,     0,
   176,     0,   177,     0,   178,     0,   179,     0,   180,     0,
   181,     0,   182,     0,   186,     0,   190,     0,   192,     0,
   193,     0,     6,     0,     7,     0,    13,     0,    14,     0,
    17,     0,    19,     0,    33,     0,    34,     0,    39,     0,
     3,     0,     4,     0,    37,     0,    18,     0,    92,     0,
    20,     0,    21,     0,    22,     0,    28,     0,    30,     0,
    31,     0,    32,     0,    35,     0,    39,     0,    36,     0,
    38,     0,    46,     0,    49,     0,   131,    26,   195,   120,
     0,   131,     0,   131,   150,   205,   120,     0,   207,     0,
   202,     0,   132,   174,   120,     0,   122,   187,   153,   204,
   120,     0,    84,     0,   105,     0,     0,     0,   154,   195,
   120,     0,    47,   208,     0,   123,   158,   161,   120,   118,
   156,   120,     0,   159,   102,   195,   160,   160,   160,     0,
    54,     0,   195,     0,     0,    93,     0,     8,   195,     0,
    10,   195,     0,     9,   195,     0,     0,    11,   195,     0,
    12,   195,     0,     0,   133,   206,   120,     0,   124,   205,
   120,     0,   125,   195,   119,    15,   119,   121,     0,   125,
   195,   119,    15,   119,   121,    16,   119,   121,     0,   134,
   195,   120,     0,   126,   207,   120,     0,   126,   120,     0,
   168,   119,     0,   135,     0,   127,   207,   120,     0,   127,
   120,     0,   136,   120,     0,   137,    62,   205,   120,     0,
   137,    63,   172,   120,     0,   137,    64,   205,   120,     0,
    65,     0,    66,     0,     0,   138,   175,   199,   120,     0,
   138,    49,   175,   199,   120,     0,   138,     4,   174,   120,
     0,   138,    49,     4,   174,   120,     0,   199,   113,   174,
     0,   199,     0,    98,     0,    23,     0,    21,     0,    97,
     0,    30,     0,    24,     0,    25,   207,     0,    26,   205,
    27,     0,   139,   120,     0,   139,    29,   206,   120,     0,
   140,   199,   120,     0,   141,   205,   120,     0,   142,   205,
   120,     0,   128,   205,   120,     0,   129,   205,   120,     0,
   143,   120,   183,   185,    47,   120,     0,   184,   183,     0,
   184,     0,   145,   195,   119,    15,   119,   121,     0,   146,
   119,   118,     0,     0,   144,    26,   195,   120,     0,   130,
   187,   120,     0,   144,   188,   189,   120,     0,    88,     0,
    89,     0,    40,     0,    41,     0,    42,     0,    44,     0,
    45,     0,    43,     0,   147,    26,   195,   120,     0,   147,
   191,   120,     0,    99,     0,   148,   206,   120,     0,   194,
   195,   120,     0,    52,     0,   114,   195,   115,     0,    73,
   195,     0,   195,   106,   195,     0,   195,   102,   195,     0,
   195,   107,   195,     0,   195,   108,   195,     0,   195,   109,
   195,     0,   195,   110,   195,     0,   195,   100,   195,     0,
   195,   101,   195,     0,   195,    86,   195,     0,   195,    85,
   195,     0,   195,    84,   195,     0,   195,    76,   195,     0,
   195,    78,   195,     0,   195,    77,   195,     0,   195,    75,
   195,     0,   195,    79,   195,     0,   195,    80,   195,     0,
   195,    81,   195,     0,   195,    82,   195,     0,   207,     0,
    88,     0,    95,     0,    96,     0,   196,     0,   106,   195,
     0,   107,   195,     0,   195,    74,   195,     0,   195,   105,
   195,     0,   198,   204,   115,     0,   197,   204,   115,     0,
    91,     0,    90,     0,   203,   200,   199,     0,   203,     0,
   107,   201,     0,   106,   201,     0,   201,     0,   114,   207,
   115,     0,   202,     0,    83,     0,    96,     0,    87,   203,
     0,   207,   203,     0,     0,   205,   113,   204,     0,   205,
     0,   195,     0,     0,   207,   206,     0,   207,     0,    89,
     0,   207,     0,     0
};

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   109,   110,   114,   115,   118,   119,   122,   123,   126,   127,
   130,   131,   132,   133,   134,   135,   136,   137,   138,   139,
   140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
   150,   151,   152,   153,   154,   155,   158,   161,   164,   167,
   170,   173,   176,   179,   182,   185,   188,   191,   194,   197,
   200,   203,   206,   209,   212,   215,   218,   221,   224,   227,
   230,   233,   236,   240,   243,   245,   251,   252,   255,   259,
   264,   265,   266,   269,   274,   278,   283,   297,   301,   302,
   304,   307,   310,   311,   312,   313,   316,   317,   318,   321,
   325,   329,   333,   340,   345,   347,   350,   354,   358,   360,
   363,   367,   371,   375,   380,   381,   382,   385,   390,   395,
   398,   404,   405,   408,   409,   410,   411,   412,   413,   414,
   416,   419,   420,   424,   428,   432,   436,   440,   444,   450,
   451,   454,   460,   463,   467,   470,   472,   479,   480,   483,
   484,   487,   488,   489,   490,   494,   496,   500,   504,   508,
   512,   519,   520,   521,   522,   523,   524,   525,   526,   527,
   528,   529,   530,   531,   532,   533,   534,   535,   536,   537,
   538,   539,   540,   542,   544,   546,   548,   549,   550,   551,
   552,   555,   557,   561,   564,   567,   568,   571,   573,   575,
   577,   579,   583,   586,   589,   590,   592,   595,   598,   603,
   604,   607,   609,   613,   616,   617
};

static const char * const yytname[] = {   "$","error","$illegal.","ADDRESS",
"ARG","COMMAND","CALL","DO","TO","BY","FOR","WHILE","UNTIL","EXIT","IF","THEN",
"ELSE","ITERATE","INTERPRET","LEAVE","NOP","NUMERIC","PARSE","EXTERNAL","SOURCE",
"VAR","VALUE","WITH","PROCEDURE","EXPOSE","PULL","PUSH","QUEUE","RETURN","SAY",
"SELECT","WHEN","DROP","OTHERWISE","SIGNAL","ON","OFF","ERROR","SYNTAX","HALT",
"NOVALUE","TRACE","END","NULLSTRING","UPPER","INTERMEDIATES","LABELS","ASSIGNMENTVARIABLE",
"STATSEP","FOREVER","ALL","COMMANDS","ERRORS","NORMAL","NEGATIVE","RESULTS",
"SCAN","DIGITS","FORM","FUZZ","SCIENTIFIC","ENGINEERING","BANGBANG","BANGWHAT",
"BANG","WHATBANG","WHATWHAT","WHAT","NOT","CONCATENATE","MODULUS","GTE","GT",
"LTE","LT","DIFFERENT","EQUALEQUAL","NOTEQUALEQUAL","OFFSET","SPACE","EXP","XOR",
"PLACEHOLDER","CONSYMBOL","SIMSYMBOL","EXFUNCNAME","INFUNCNAME","LABEL","DOVARIABLE",
"SYMBOL","HEXSTRING","STRING","VERSION","LINEIN","WHATEVER","'|'","'&'","'='",
"'>'","'<'","CCAT","'+'","'-'","'*'","'/'","'%'","UMINUS","UPLUSS","','","'('",
"')'","prog","stats","nstats","nseps","seps","statement","call","do","exit",
"if","iterate","leave","return","say","signal_lab","address","arg","drop","interpret",
"label","nop","numeric","parse","proc","pull","push","queue","select","signal",
"when","otherwise","trace","upper","address_stat","asym","arg_stat","call_stat",
"whitespace","nothing","expr_stat","end","do_stat","repetitor","dovar","tobyfor",
"conditional","drop_stat","exit_stat","if_stat","ipret_stat","iterate_stat",
"label_stat","labelname","leave_stat","nop_stat","numeric_stat","form_expr",
"parse_stat","templs","parse_param","proc_stat","pull_stat","push_stat","queue_stat",
"return_stat","say_stat","select_stat","when_stats","when_stat","otherwise_stat",
"signal_stat","asymbol","on_off","s_action","trace_stat","whatever","upper_stat",
"assignment","ass_part","expr","function","intfunc","extfunc","template","solid",
"offset","string","pv","exprs","nexpr","vars","simsymb","nsimsymb",""
};
#endif

static const short yyr1[] = {     0,
   116,   116,   117,   117,   118,   118,   119,   119,   120,   120,
   121,   121,   121,   121,   121,   121,   121,   121,   121,   121,
   121,   121,   121,   121,   121,   121,   121,   121,   121,   121,
   121,   121,   121,   121,   121,   121,   122,   123,   124,   125,
   126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
   136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
   146,   147,   148,   149,   149,   149,   150,   150,   151,   152,
   153,   153,   153,   154,   155,   156,   157,   158,   158,   158,
   158,   159,   160,   160,   160,   160,   161,   161,   161,   162,
   163,   164,   164,   165,   166,   166,   167,   168,   169,   169,
   170,   171,   171,   171,   172,   172,   172,   173,   173,   173,
   173,   174,   174,   175,   175,   175,   175,   175,   175,   175,
   175,   176,   176,   177,   178,   179,   180,   181,   182,   183,
   183,   184,   185,   185,   186,   186,   186,   187,   187,   188,
   188,   189,   189,   189,   189,   190,   190,   191,   192,   193,
   194,   195,   195,   195,   195,   195,   195,   195,   195,   195,
   195,   195,   195,   195,   195,   195,   195,   195,   195,   195,
   195,   195,   195,   195,   195,   195,   195,   195,   195,   195,
   195,   196,   196,   197,   198,   199,   199,   200,   200,   200,
   200,   200,   201,   202,   203,   203,   203,   204,   204,   205,
   205,   206,   206,   207,   208,   208
};

static const short yyr2[] = {     0,
     2,     1,     2,     1,     1,     0,     1,     0,     2,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     4,     1,     4,     1,     1,     3,     5,
     1,     1,     0,     0,     3,     2,     7,     6,     1,     1,
     0,     1,     2,     2,     2,     0,     2,     2,     0,     3,
     3,     6,     9,     3,     3,     2,     2,     1,     3,     2,
     2,     4,     4,     4,     1,     1,     0,     4,     5,     4,
     5,     3,     1,     1,     1,     1,     1,     1,     1,     2,
     3,     2,     4,     3,     3,     3,     3,     3,     6,     2,
     1,     6,     3,     0,     4,     3,     4,     1,     1,     1,
     1,     1,     1,     1,     1,     4,     3,     1,     3,     3,
     1,     3,     2,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     1,     1,     1,     1,     1,     2,     2,     3,
     3,     3,     3,     1,     1,     3,     1,     2,     2,     1,
     3,     1,     1,     1,     2,     2,     0,     3,     1,     1,
     0,     2,     1,     1,     1,     0
};

static const short yydefact[] = {     8,
    10,    74,     7,     9,    46,    47,    37,    38,    39,    40,
    41,    49,    42,    51,    52,    53,    54,    55,    56,    57,
    43,    44,    58,    48,    59,    62,    63,   151,    50,     1,
    74,     0,    81,   201,     0,     0,     0,   201,   201,     0,
    65,   197,     0,     0,    98,     0,     0,     0,     0,   197,
   201,   201,     0,     0,     0,     0,    11,    13,    14,     0,
    12,    15,    16,    17,    18,    19,    20,    21,     8,    22,
    23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
    33,    34,    35,    36,     0,     3,   138,   139,    73,    79,
     0,   174,   204,   185,   184,    82,   175,   176,     0,     0,
     0,    89,     0,    80,   177,   201,   201,   173,   200,     0,
     8,    96,     0,   100,     0,     0,     0,     0,     0,   194,
   201,    68,    67,   197,     0,   113,   187,   197,     0,   203,
     0,   101,   201,   107,   201,   197,   116,   115,   119,     0,
   201,   118,     0,   117,   114,   197,     0,   122,     0,     0,
     0,     0,     0,   140,   141,     0,     0,   148,     0,     0,
     0,    97,     0,    71,    72,   201,   153,   178,   179,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   199,     0,    91,     0,
    95,    99,   127,   128,   136,     0,     0,   195,    69,   197,
   193,     0,     0,     0,   197,   190,   192,   196,    90,   202,
    94,     0,   105,   106,     0,     0,     0,   120,     0,   197,
   197,     0,     0,   124,   125,   126,    60,     0,   134,   131,
     0,   142,   145,   143,   144,     0,     0,   147,   149,    75,
   150,     0,   152,    87,    88,    74,    86,   180,   168,   165,
   167,   166,   169,   170,   171,   172,   164,   163,   162,   160,
   161,   155,   181,   154,   156,   157,   158,   159,   183,   201,
   182,     8,    64,    66,   112,   189,   188,     0,   186,   102,
   103,   104,   110,   121,     0,     0,   108,   123,     8,    61,
     8,     0,   130,   135,   137,   146,    70,     5,     0,     0,
     0,     0,    86,   198,    74,   191,   111,   109,     0,    74,
     0,   206,     0,    83,    85,    84,    86,    92,     8,   133,
   129,   205,    76,    77,    78,     8,    74,    74,   132,    93,
     0,     0,     0
};

static const short yydefgoto[] = {   341,
   308,   309,     2,     3,    31,    32,    33,    34,    35,    36,
    37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,   238,   301,
    55,    56,    57,   121,    58,    59,   166,    60,    61,   323,
    62,   102,   103,   313,   173,    63,    64,    65,    66,    67,
    68,    69,    70,    71,    72,   225,    73,   125,   146,    74,
    75,    76,    77,    78,    79,    80,   239,   240,   302,    81,
    89,   156,   246,    82,   159,    83,    84,    85,   109,   105,
   106,   107,   126,   215,   216,   122,   127,   196,   197,   129,
   108,   333
};

static const short yypact[] = {   -42,
   -42,   386,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,   -12,-32768,-32768,-32768,-32768,-32768,
   296,    19,   127,   501,   501,   -40,   -40,   501,   501,    19,
   -16,   -70,   -75,   501,-32768,   -42,    89,     2,   -11,   -70,
   501,   501,   -42,    17,   -17,   -75,-32768,-32768,-32768,   501,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   -42,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,   501,-32768,-32768,-32768,   -68,-32768,
   501,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   501,   501,
   501,   111,   -78,   542,-32768,   501,   501,-32768,   542,   -42,
   458,-32768,   -42,-32768,   -42,   -42,   -42,   -42,   501,-32768,
   501,-32768,-32768,   -70,   -42,   -83,   -52,   -70,   -42,   -75,
   458,-32768,   501,    66,   501,   -70,-32768,-32768,-32768,   -75,
   501,-32768,    42,-32768,-32768,   -70,   -75,-32768,   -42,   -42,
   -42,    14,   501,-32768,-32768,    43,   501,-32768,   -42,   -42,
   458,-32768,   458,-32768,-32768,   501,-32768,-32768,-32768,   471,
   501,   501,   -42,   501,   501,   501,   501,   501,   501,   501,
   501,   501,   501,   501,   501,   501,   501,   501,   501,   501,
   501,   501,   501,   501,   501,   -59,   -54,   -46,-32768,    59,
-32768,-32768,-32768,-32768,-32768,   458,   -42,-32768,-32768,   -70,
-32768,    -2,    -2,   -75,   -70,-32768,-32768,-32768,-32768,-32768,
-32768,   -42,-32768,-32768,   -42,   -42,   -42,-32768,    57,   -70,
   -70,   -42,   -42,-32768,-32768,-32768,-32768,   501,    51,    14,
   458,-32768,-32768,-32768,-32768,   -42,   458,-32768,-32768,-32768,
-32768,   -42,-32768,   542,   542,   423,   275,   -15,    18,   592,
   592,   592,   592,   592,   592,   592,   -15,-32768,   555,   555,
   604,   592,   -15,    26,    26,    18,    18,    18,-32768,   501,
-32768,   -42,-32768,-32768,-32768,-32768,-32768,     4,-32768,-32768,
-32768,-32768,-32768,-32768,   -42,   -42,-32768,-32768,   458,-32768,
   -42,    79,-32768,-32768,-32768,-32768,-32768,-32768,    91,   501,
   501,   501,   146,-32768,   470,-32768,-32768,-32768,    98,   423,
   -42,   -75,   -42,   542,   542,   542,   146,   130,   -42,-32768,
-32768,-32768,-32768,-32768,-32768,   -42,   470,   470,-32768,-32768,
   147,   157,-32768
};

static const short yypgoto[] = {-32768,
    10,  -159,   -47,    -1,  -232,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,  -298,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,  -132,    20,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   -76,-32768,-32768,-32768,
   125,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    85,-32768,
-32768,-32768,   -49,-32768,   -71,    40,   -53,  -105,   -31,   -51,
    -3,-32768
};


#define	YYLAST		714


static const short yytable[] = {     4,
   149,   198,   110,   227,   160,   136,   116,   117,   157,   119,
     1,    30,     1,    93,   327,   164,   124,   147,    93,   150,
   151,   162,   137,   174,   138,   139,   140,   141,   335,   210,
   211,   142,   113,   115,   112,   114,   165,   123,   128,   130,
    86,     1,   153,   120,   132,   230,   128,   148,    93,   237,
   143,   152,   130,   212,   213,   279,   154,   155,   280,   176,
   252,   214,   137,   200,   138,   139,   140,   141,   281,   185,
   208,   142,    93,   282,   218,   -45,   -45,   285,   220,   120,
   211,   158,   328,   294,   242,   243,   244,   245,   300,   207,
   191,   192,   193,   194,   195,   233,   232,   295,   144,   145,
   176,   222,   185,   226,   339,   340,    87,    88,   199,   229,
   185,   201,   329,   202,   203,   204,   205,   104,   316,   111,
   128,   171,   172,   209,   128,   321,   130,   219,   131,   221,
   223,   224,   128,   193,   194,   195,   228,   322,   144,   145,
   286,   287,   128,   130,   161,   336,   342,   234,   235,   236,
   133,   134,   135,   310,   311,   312,   343,   248,   249,   250,
   330,   251,   231,   303,   118,   289,   217,     0,     0,   163,
     0,   256,     0,     0,   314,   167,     0,     0,     0,     0,
    90,   296,     0,   168,   169,   170,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    91,
     0,     0,     0,   206,   283,   284,   128,     0,     0,     0,
   288,   128,     0,     0,    92,    93,    94,    95,     0,    96,
   290,    97,    98,   291,   292,   293,   128,   128,     0,     0,
   297,   298,    99,   100,   315,     0,     0,   241,     0,   304,
   101,   247,     0,     0,   305,   306,     0,     0,     0,     0,
   307,   319,     0,   320,     0,   254,   255,     0,   257,   258,
   259,   260,   261,   262,   263,   264,   265,   266,   267,   268,
   269,   270,   271,   272,   273,   274,   275,   276,   277,   278,
     0,   337,   310,   311,   312,     0,     0,     0,   338,     0,
     0,     0,     0,   317,   318,    -4,     0,     0,     5,     6,
     0,     7,     8,     0,     0,     0,     0,     0,     9,    10,
     0,     0,    11,    12,    13,    14,    15,    16,   332,   331,
     0,   334,   299,    17,     0,    18,    19,    20,    21,    22,
    23,     0,    24,     0,    25,     0,     0,     0,     0,     0,
     0,    26,    -4,     0,    27,     0,     0,    28,   175,   176,
   177,   178,   179,   180,   181,   182,   183,     0,   184,   185,
   186,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   187,   188,   189,     0,     0,   190,
   191,   192,   193,   194,   195,    -2,     0,    29,     5,     6,
     0,     7,     8,     0,   324,   325,   326,     0,     9,    10,
     0,     0,    11,    12,    13,    14,    15,    16,     0,     0,
     0,     0,     0,    17,     0,    18,    19,    20,    21,    22,
    23,     0,    24,     0,    25,     5,     6,     0,     7,     8,
     0,    26,     0,     0,    27,     9,    10,    28,     0,    11,
    12,    13,    14,    15,    16,     0,     0,     0,     0,     0,
    17,     0,    18,    19,    20,    21,    22,    23,     0,    24,
     0,    25,     0,     0,     0,     0,     0,     0,    26,    -6,
     0,    27,     5,     6,    28,     7,     8,    29,     0,     0,
     0,     0,     9,    10,     0,     0,    11,    12,    13,    14,
    15,    16,     0,     0,     0,     0,     0,    17,     0,    18,
    19,    20,    21,    22,    23,     0,    24,     0,    25,     0,
     1,     0,     0,     0,    29,    26,     0,     0,    27,     0,
     0,    28,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   175,   176,   177,   178,   179,   180,   181,   182,   183,
     0,   184,   185,   186,   175,   176,   177,   178,   179,   180,
   181,   182,   183,     0,   184,   185,   186,   187,   188,   189,
     0,    29,   190,   191,   192,   193,   194,   195,     0,     0,
   187,   188,   189,    91,     0,   190,   191,   192,   193,   194,
   195,     0,     0,     0,     0,   253,     0,     0,    92,    93,
    94,    95,     0,     0,     0,    97,    98,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    99,   100,     0,     0,
     0,     0,     0,     0,   101,   175,   176,   177,   178,   179,
   180,   181,   182,   183,     0,   184,   185,   186,   175,   176,
   177,   178,   179,   180,   181,   182,   183,     0,   184,   185,
     0,   187,   188,   189,     0,     0,   190,   191,   192,   193,
   194,   195,     0,     0,     0,   188,   189,     0,     0,   190,
   191,   192,   193,   194,   195,   175,   176,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,     0,   184,   185,   175,   176,   177,
   178,   179,   180,   181,   182,   183,     0,   184,   185,     0,
     0,     0,     0,-32768,     0,     0,   190,   191,   192,   193,
   194,   195,     0,     0,     0,   189,     0,     0,   190,   191,
   192,   193,   194,   195
};

static const short yycheck[] = {     1,
    50,   107,    34,   136,    56,     4,    38,    39,    26,    26,
    53,     2,    53,    89,   313,    84,    87,    29,    89,    51,
    52,    69,    21,   102,    23,    24,    25,    26,   327,   113,
    83,    30,    36,    37,    36,    37,   105,    41,    42,    43,
    31,    53,    26,    96,    46,     4,    50,    49,    89,    36,
    49,    53,    56,   106,   107,   115,    40,    41,   113,    75,
   166,   114,    21,   111,    23,    24,    25,    26,   115,    85,
   124,    30,    89,    15,   128,    88,    89,   210,   130,    96,
    83,    99,   315,    27,    42,    43,    44,    45,    38,   121,
   106,   107,   108,   109,   110,   147,   146,   230,    97,    98,
    75,   133,    85,   135,   337,   338,    88,    89,   110,   141,
    85,   113,    15,   115,   116,   117,   118,    33,   115,    35,
   124,    11,    12,   125,   128,    47,   130,   129,    44,   131,
    65,    66,   136,   108,   109,   110,   140,    47,    97,    98,
   212,   213,   146,   147,    60,    16,     0,   149,   150,   151,
    62,    63,    64,     8,     9,    10,     0,   159,   160,   161,
   320,   163,   143,   240,    40,   215,   127,    -1,    -1,    85,
    -1,   173,    -1,    -1,   280,    91,    -1,    -1,    -1,    -1,
    54,   231,    -1,    99,   100,   101,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    73,
    -1,    -1,    -1,   119,   206,   207,   210,    -1,    -1,    -1,
   214,   215,    -1,    -1,    88,    89,    90,    91,    -1,    93,
   222,    95,    96,   225,   226,   227,   230,   231,    -1,    -1,
   232,   233,   106,   107,   282,    -1,    -1,   153,    -1,   241,
   114,   157,    -1,    -1,   246,   247,    -1,    -1,    -1,    -1,
   252,   299,    -1,   301,    -1,   171,   172,    -1,   174,   175,
   176,   177,   178,   179,   180,   181,   182,   183,   184,   185,
   186,   187,   188,   189,   190,   191,   192,   193,   194,   195,
    -1,   329,     8,     9,    10,    -1,    -1,    -1,   336,    -1,
    -1,    -1,    -1,   295,   296,     0,    -1,    -1,     3,     4,
    -1,     6,     7,    -1,    -1,    -1,    -1,    -1,    13,    14,
    -1,    -1,    17,    18,    19,    20,    21,    22,   322,   321,
    -1,   323,   238,    28,    -1,    30,    31,    32,    33,    34,
    35,    -1,    37,    -1,    39,    -1,    -1,    -1,    -1,    -1,
    -1,    46,    47,    -1,    49,    -1,    -1,    52,    74,    75,
    76,    77,    78,    79,    80,    81,    82,    -1,    84,    85,
    86,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   100,   101,   102,    -1,    -1,   105,
   106,   107,   108,   109,   110,     0,    -1,    92,     3,     4,
    -1,     6,     7,    -1,   310,   311,   312,    -1,    13,    14,
    -1,    -1,    17,    18,    19,    20,    21,    22,    -1,    -1,
    -1,    -1,    -1,    28,    -1,    30,    31,    32,    33,    34,
    35,    -1,    37,    -1,    39,     3,     4,    -1,     6,     7,
    -1,    46,    -1,    -1,    49,    13,    14,    52,    -1,    17,
    18,    19,    20,    21,    22,    -1,    -1,    -1,    -1,    -1,
    28,    -1,    30,    31,    32,    33,    34,    35,    -1,    37,
    -1,    39,    -1,    -1,    -1,    -1,    -1,    -1,    46,    47,
    -1,    49,     3,     4,    52,     6,     7,    92,    -1,    -1,
    -1,    -1,    13,    14,    -1,    -1,    17,    18,    19,    20,
    21,    22,    -1,    -1,    -1,    -1,    -1,    28,    -1,    30,
    31,    32,    33,    34,    35,    -1,    37,    -1,    39,    -1,
    53,    -1,    -1,    -1,    92,    46,    -1,    -1,    49,    -1,
    -1,    52,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    74,    75,    76,    77,    78,    79,    80,    81,    82,
    -1,    84,    85,    86,    74,    75,    76,    77,    78,    79,
    80,    81,    82,    -1,    84,    85,    86,   100,   101,   102,
    -1,    92,   105,   106,   107,   108,   109,   110,    -1,    -1,
   100,   101,   102,    73,    -1,   105,   106,   107,   108,   109,
   110,    -1,    -1,    -1,    -1,   115,    -1,    -1,    88,    89,
    90,    91,    -1,    -1,    -1,    95,    96,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   106,   107,    -1,    -1,
    -1,    -1,    -1,    -1,   114,    74,    75,    76,    77,    78,
    79,    80,    81,    82,    -1,    84,    85,    86,    74,    75,
    76,    77,    78,    79,    80,    81,    82,    -1,    84,    85,
    -1,   100,   101,   102,    -1,    -1,   105,   106,   107,   108,
   109,   110,    -1,    -1,    -1,   101,   102,    -1,    -1,   105,
   106,   107,   108,   109,   110,    74,    75,    76,    77,    78,
    79,    80,    81,    82,    -1,    84,    85,    74,    75,    76,
    77,    78,    79,    80,    81,    82,    -1,    84,    85,    -1,
    -1,    -1,    -1,   102,    -1,    -1,   105,   106,   107,   108,
   109,   110,    -1,    -1,    -1,   102,    -1,    -1,   105,   106,
   107,   108,   109,   110
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */


/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif


int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
#ifdef YYLSP_NEEDED
		 &yyls1, size * sizeof (*yylsp),
#endif
		 &yystacksize);

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symboles being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
{ rootnode = makenode(X_PROGRAM,1,yyvsp[0]);;
    break;}
case 2:
{ rootnode = NULL ; ;
    break;}
case 3:
{ yyval = makenode(X_STATS,2,yyvsp[-1],yyvsp[0]) ; ;
    break;}
case 4:
{ yyval = makenode(X_STATS,2,NULL,yyvsp[0]) ; ;
    break;}
case 5:
{ yyval = yyvsp[0] ; ;
    break;}
case 6:
{ yyval = NULL ; ;
    break;}
case 37:
{ yyval = makenode(X_CALL,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 38:
{ yyval = makenode(X_DO,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 39:
{ yyval = makenode(X_EXIT,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 40:
{ yyval = makenode(X_IF,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 41:
{ yyval = makenode(X_ITERATE,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 42:
{ yyval = makenode(X_LEAVE,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 43:
{ yyval = makenode(X_RETURN,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 44:
{ yyval = makenode(X_SAY,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 45:
{ yyval = makenode(X_SIG_LAB,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 46:
{ yyval = makenode(X_ADDR_N,0) ;
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 47:
{ yyval = makenode(X_PARSE_ARG_U,0) ;
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 48:
{ yyval = makenode(X_DROP,0) ;
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 49:
{ yyval = makenode(X_IPRET,0) ;
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 50:
{ yyval = makenode(X_LABEL,0) ;
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 51:
{ yyval = makenode(X_NULL,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 52:
{ yyval = makenode(0,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 53:
{ yyval = makenode(0,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 54:
{ yyval = makenode(X_PROC,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 55:
{ yyval = makenode(X_PULL,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 56:
{ yyval = makenode(X_PUSH,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 57:
{ yyval = makenode(X_QUEUE,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 58:
{ yyval = makenode(X_SELECT,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 59:
{ yyval = makenode(X_SIG_LAB,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 60:
{ yyval = makenode(X_WHEN,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 61:
{ yyval = makenode(X_OTHERWISE,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 62:
{ yyval = makenode(X_TRACE,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 63:
{ yyval = makenode(X_UPPER_VAR,0) ; 
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 64:
{ yyval = yyvsp[-3] ;
                                         yyval->type = X_ADDR_V ;
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 65:
{ yyval = yyvsp[0] ;
                                         yyval->type = X_ADDR_S ; ;
    break;}
case 66:
{ yyval = yyvsp[-3] ;
                                         yyval->type = X_ADDR_N ;
                                         yyval->p[0] = yyvsp[-1] ;
                                         yyval->name = (char *)yyvsp[-2] ; ;
    break;}
case 69:
{ yyval = yyvsp[-2] ;
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 70:
{ yyval = yyvsp[-4] ;
                                         yyval->p[0] = yyvsp[-1] ;
                                         yyval->name = (char *) yyvsp[-3] ; ;
    break;}
case 74:
{ yyval = makenode(X_COMMAND,0) ; 
                                         yyval->charnr = tstart ; 
				         yyval->lineno = tline ; ;
    break;}
case 75:
{ yyvsp[-2]->p[0] = yyvsp[-1] ; 
                                         yyval = yyvsp[-2] ; ;
    break;}
case 76:
{ yyval = makenode(X_END,0) ;
                                         yyval->name = (char*)(yyvsp[0]) ;
                                         yyval->lineno = tline ;
                                         yyval->charnr = tstart ; ;
    break;}
case 77:
{ yyval = yyvsp[-6] ;
                                         yyval->p[0] = yyvsp[-5] ;
                                         yyval->p[1] = yyvsp[-4] ;
                                         yyval->p[2] = yyvsp[-2] ; 
                                         yyval->p[3] = yyvsp[-1] ; 
                                         if ((yyval->p[0])&&(yyval->p[0]->name)&&
					     (yyval->p[3]->name)&&
                                      (strcmp(yyval->p[3]->name,yyval->p[0]->name)))
                                           exiterror( ERR_UNMATCHED_END ) ;
                                       ;
    break;}
case 78:
{ yyval =makenode(X_REP,4,yyvsp[-3],yyvsp[-2],yyvsp[-1],yyvsp[0]) ;
                                         yyval->name = (char *)yyvsp[-5] ; 
                                         checkdosyntax(yyval) ; ;
    break;}
case 79:
{ yyval = makenode(X_REP_FOREVER,0) ; ;
    break;}
case 80:
{ yyvsp[0] = makenode(X_DO_FOR,1,yyvsp[0]) ;
                                         yyval = makenode(X_REP,2,NULL,yyvsp[0]) ; ;
    break;}
case 81:
{ yyval = NULL ; ;
    break;}
case 82:
{ yyval = (nodeptr)stralloc(retvalue) ; ;
    break;}
case 83:
{ yyval = makenode(X_DO_TO,1,yyvsp[0]) ; ;
    break;}
case 84:
{ yyval = makenode(X_DO_FOR,1,yyvsp[0]) ; ;
    break;}
case 85:
{ yyval = makenode(X_DO_BY,1,yyvsp[0]) ; ;
    break;}
case 86:
{ yyval = NULL ; ;
    break;}
case 87:
{ yyval = makenode(X_WHILE,1,yyvsp[0]) ; ;
    break;}
case 88:
{ yyval = makenode(X_UNTIL,1,yyvsp[0]) ; ;
    break;}
case 89:
{ yyval = NULL ; ;
    break;}
case 90:
{ yyval = yyvsp[-2] ;
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 91:
{ yyval = yyvsp[-2] ;
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 92:
{ yyval = yyvsp[-5] ;
                                         yyval->p[0] = yyvsp[-4] ;
                                         yyval->p[1] = yyvsp[0] ; ;
    break;}
case 93:
{ yyval = yyvsp[-8] ;
                                         yyval->p[0] = yyvsp[-7] ;
                                         yyval->p[1] = yyvsp[-3] ;
                                         yyval->p[2] = yyvsp[0] ; ;
    break;}
case 94:
{ yyval = yyvsp[-2] ;
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 95:
{ yyval = yyvsp[-2] ; 
                                         yyval->name = (char *) yyvsp[-1] ; ;
    break;}
case 96:
{ yyval = yyvsp[-1] ; ;
    break;}
case 97:
{ yyval = yyvsp[-1] ; 
                                         newlabel( yyvsp[-1] ) ; ;
    break;}
case 98:
{ yyval = yyvsp[0] ;
                                         yyval->name = stralloc(retvalue) ; ;
    break;}
case 99:
{ yyval = yyvsp[-2] ;
                                         yyval->name = (char *) yyvsp[-1] ; ;
    break;}
case 100:
{ yyval = yyvsp[-1] ; ;
    break;}
case 101:
{ yyval = yyvsp[-1] ; ;
    break;}
case 102:
{ yyval = yyvsp[-3] ;
                                         yyval->type = X_NUM_D ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 103:
{ yyval = yyvsp[-3] ;
                                         yyval->type = X_NUM_F ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 104:
{ yyval = yyvsp[-3] ;
                                         yyval->type = X_NUM_FUZZ ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 105:
{ yyval = makenode(X_NUM_SCI,0) ; ;
    break;}
case 106:
{ yyval = makenode(X_NUM_ENG,0) ; ;
    break;}
case 107:
{ yyval = NULL ; ;
    break;}
case 108:
{ yyval = yyvsp[-3] ;
                                         yyval->type = X_PARSE ; 
                                         yyval->p[0] = yyvsp[-2] ;
                                         yyval->p[1] = yyvsp[-1] ; ;
    break;}
case 109:
{ yyval = yyvsp[-4] ;
                                         yyval->type = X_PARSE_U ; 
                                         yyval->p[0] = yyvsp[-2] ;
                                         yyval->p[1] = yyvsp[-1] ; ;
    break;}
case 110:
{ yyval = yyvsp[-3] ;
                                         yyval->type = X_PARSE_ARG ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 111:
{ yyval = yyvsp[-4] ;
                                         yyval->type = X_PARSE_ARG_U ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 112:
{ yyval = makenode(X_TMPLS,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 113:
{ yyval = yyvsp[0] ; ;
    break;}
case 114:
{ yyval = makenode(X_PARSE_EXT,0) ; ;
    break;}
case 115:
{ yyval = makenode(X_PARSE_EXT,0) ; ;
    break;}
case 116:
{ yyval = makenode(X_PARSE_NUM,0) ; ;
    break;}
case 117:
{ yyval = makenode(X_PARSE_VER,0) ; ;
    break;}
case 118:
{ yyval = makenode(X_PARSE_PULL,0) ; ;
    break;}
case 119:
{ yyval = makenode(X_PARSE_SRC,0) ; ;
    break;}
case 120:
{ yyval = makenode(X_PARSE_VAR,0) ; 
                                         yyval->name = (char *) yyvsp[0] ; ;
    break;}
case 121:
{ yyval = makenode(X_PARSE_VAL,1,yyvsp[-1]) ; ;
    break;}
case 122:
{ yyval = yyvsp[-1] ; ;
    break;}
case 123:
{ yyval = yyvsp[-3] ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 124:
{ yyval = yyvsp[-2] ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 125:
{ yyval = yyvsp[-2] ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 126:
{ yyval = yyvsp[-2] ;
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 127:
{ yyval = yyvsp[-2] ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 128:
{ yyval = yyvsp[-2] ;
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 129:
{ yyval = yyvsp[-5] ;
                                         yyval->p[0] = yyvsp[-3] ;
                                         yyval->p[1] = yyvsp[-2] ; ;
    break;}
case 130:
{ yyval = makenode(X_WHENS,2,yyvsp[-1],yyvsp[0]) ; ;
    break;}
case 131:
{ yyval = makenode(X_WHENS,1,yyvsp[0]) ; ;
    break;}
case 132:
{
                                         yyval = yyvsp[-5] ;
                                         yyval->p[0] = yyvsp[-4] ;
                                         yyval->p[1] = yyvsp[0] ; ;
    break;}
case 133:
{
                                         yyval = yyvsp[-2] ; 
                                         yyval->p[0] = yyvsp[0] ; ;
    break;}
case 134:
{ yyval = NULL ; ;
    break;}
case 135:
{ yyval = yyvsp[-3] ;
                                         yyval->type = X_SIG_VAL ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 136:
{ yyval = yyvsp[-2] ;
                                         yyval->name = (char *)yyvsp[-1] ; ;
    break;}
case 137:
{ yyval = yyvsp[-3] ;
                                         yyval->type = X_SIG_SET ;
                                         yyval->p[0] = yyvsp[-2] ;
                                         yyval->p[1] = yyvsp[-1] ; ;
    break;}
case 138:
{ yyval = (nodeptr)stralloc(retvalue) ; ;
    break;}
case 139:
{ yyval = (nodeptr)stralloc(retvalue) ; ;
    break;}
case 140:
{ yyval = makenode(X_ON,0) ; ;
    break;}
case 141:
{ yyval = makenode(X_OFF,0) ; ;
    break;}
case 142:
{ yyval = makenode(X_S_ERROR,0) ; ;
    break;}
case 143:
{ yyval = makenode(X_S_HALT,0) ; ;
    break;}
case 144:
{ yyval = makenode(X_S_NOVALUE,0) ; ;
    break;}
case 145:
{ yyval = makenode(X_S_SYNTAX,0) ; ;
    break;}
case 146:
{ yyval = yyvsp[-3] ;
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 147:
{ yyval = yyvsp[-2] ; 
                                         yyval->name = (char *) yyvsp[-1] ; ;
    break;}
case 148:
{ yyval = (nodeptr)stralloc(retvalue) ; ;
    break;}
case 149:
{ yyval = yyvsp[-2] ; 
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 150:
{ yyval = yyvsp[-2] ;
                                         yyval->p[0] = yyvsp[-1] ; ;
    break;}
case 151:
{ yyval = makenode(X_ASSIGN,0) ; 
                                         yyval->charnr = tstart ;
                                         yyval->lineno = tline ;
                                         yyval->name = stralloc(retvalue) ; ;
    break;}
case 152:
{ yyval = yyvsp[-1] ; ;
    break;}
case 153:
{ yyval = makenode(X_LOG_NOT,1,yyvsp[0]) ; ;
    break;}
case 154:
{ yyval = makenode(X_PLUSS,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 155:
{ yyval = makenode(X_EQUAL,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 156:
{ yyval = makenode(X_MINUS,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 157:
{ yyval = makenode(X_MULT,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 158:
{ yyval = makenode(X_DEVIDE,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 159:
{ yyval = makenode(X_INTDIV,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 160:
{ yyval = makenode(X_LOG_OR,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 161:
{ yyval = makenode(X_LOG_AND,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 162:
{ yyval = makenode(X_LOG_XOR,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 163:
{ yyval = makenode(X_EXP,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 164:
{ yyval = makenode(X_SPACE,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 165:
{ yyval = makenode(X_GTE,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 166:
{ yyval = makenode(X_LTE,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 167:
{ yyval = makenode(X_GT,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 168:
{ yyval = makenode(X_MODULUS,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 169:
{ yyval = makenode(X_LT,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 170:
{ yyval = makenode(X_DIFF,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 171:
{ yyval = makenode(X_S_EQUAL,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 172:
{ yyval = makenode(X_S_DIFF,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 173:
{ yyval = makenode(X_SIM_SYMBOL,0) ;
                                         yyval->name = (char *) yyvsp[0] ; ;
    break;}
case 174:
{ yyval = makenode(X_CON_SYMBOL,0) ;
                                         yyval->name = stralloc(retvalue) ; ;
    break;}
case 175:
{ yyval = makenode(X_STRING,0) ;
                                         yyval->name = stralloc(retvalue) ; ;
    break;}
case 176:
{ yyval = makenode(X_STRING,0) ; 
                                         yyval->name = stralloc(retvalue) ; ;
    break;}
case 177:
{ yyval = yyvsp[0] ; ;
    break;}
case 178:
{ yyval = yyvsp[0] ; ;
    break;}
case 179:
{ yyval = makenode(X_U_MINUS,1,yyvsp[0]) ; ;
    break;}
case 180:
{ yyval = makenode(X_CONCAT,2,yyvsp[-2],yyvsp[0]) ; ;
    break;}
case 181:
{ yyval = makenode(X_CONCAT,2,yyvsp[-2],yyvsp[-1]) ; ;
    break;}
case 182:
{ yyval = makenode(X_EX_FUNC,1,yyvsp[-1]) ; 
                                         yyval->name = (char *)yyvsp[-2] ; ;
    break;}
case 183:
{ yyval = makenode(X_IN_FUNC,1,yyvsp[-1]) ; 
                                         yyval->name = (char *)yyvsp[-2] ; ;
    break;}
case 184:
{ yyval = (nodeptr)stralloc(retvalue) ; ;
    break;}
case 185:
{ yyval = (nodeptr)stralloc(retvalue) ; ;
    break;}
case 186:
{ yyval =makenode(X_TPL_SOLID,3,yyvsp[-2],yyvsp[-1],yyvsp[0]);;
    break;}
case 187:
{ yyval =makenode(X_TPL_SOLID,1,yyvsp[0]) ; ;
    break;}
case 188:
{ yyval = makenode(X_NEG_OFFS,0) ; 
                                         yyval->name = (char *) yyvsp[0] ; ;
    break;}
case 189:
{ yyval = makenode(X_POS_OFFS,0) ;
                                         yyval->name = (char *) yyvsp[0] ; ;
    break;}
case 190:
{ yyval = makenode(X_ABS_OFFS,0) ;
                                         yyval->name = (char *) yyvsp[0] ; ;
    break;}
case 191:
{ yyval = makenode(X_TPL_VAR,0) ;
                                         yyval->name = (char *) yyvsp[-1] ; ;
    break;}
case 192:
{ yyval = makenode(X_TPL_MVE,0) ;
                                         yyval->name = (char *) yyvsp[0] ; ;
    break;}
case 193:
{ yyval = (nodeptr)stralloc(retvalue) ; ;
    break;}
case 194:
{ yyval = (nodeptr) stralloc(retvalue) ; ;
    break;}
case 195:
{ yyval = makenode(X_TPL_POINT,1,yyvsp[0]) ; ;
    break;}
case 196:
{ yyval = makenode(X_TPL_SYMBOL,1,yyvsp[0]) ; 
                                         yyval->name = (char *)yyvsp[-1] ; ;
    break;}
case 197:
{ yyval = NULL ; ;
    break;}
case 198:
{ yyval = makenode(X_EXPRLIST,2,yyvsp[-2],yyvsp[0]) ; 
					 if (yyvsp[-2]==NULL)
					    yyval->p[0] = makenode(X_NULL,0) ; ;
    break;}
case 199:
{ yyval = makenode(X_EXPRLIST,1,yyvsp[0]) ; 
					 if (yyvsp[0]==NULL)
					    yyval->p[0] = makenode(X_NULL,0) ; ;
    break;}
case 200:
{ yyval = yyvsp[0] ; ;
    break;}
case 201:
{ yyval = NULL ; ;
    break;}
case 202:
{ yyval = makenode(X_SIM_SYMBOL,1,yyvsp[0]) ; 
                                         yyval->name = (char *) yyvsp[-1] ; ;
    break;}
case 203:
{ yyval = makenode(X_SIM_SYMBOL,0) ; 
                                         yyval->name = (char *) yyvsp[0] ; ;
    break;}
case 204:
{ yyval = (treenode *) stralloc(retvalue);;
    break;}
case 205:
{ yyval = yyvsp[0] ; ;
    break;}
case 206:
{ yyval = NULL ; ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */


  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}


char *stralloc( char *ptr )
{
   static char strspc[STRINGSPACE] ;
   static int strptr = 0 ;
   int i ;

   i = strptr ;
   if ((strptr+=((8+strlen(ptr))&(~7)))>=STRINGSPACE)
      exiterror(5) ;   /* too easy, allocate more space .... */
   strcpy(&strspc[i],ptr) ;

#ifdef REXXDEBUG
   printf("Stralloc: request to allocate %d bytes for //%s//\n",strptr-i,ptr);
#endif /* REXXDEBUG */

   return( &strspc[i] ) ;   
}


nodeptr makenode( int type, int numb, ... ) 
{
   nodeptr thisleave ;
   va_list argptr ;
   int i ;

#ifdef REXXDEBUG
   printf("makenode: making new node, type: %d\n",type) ;
#endif /* REXXDEBUG */ 

   thisleave=(nodeptr)Malloc(sizeof(*thisleave)) ;

   for (i=0;i!=5;i++) 
      thisleave->p[i] = NULL ;

   va_start( argptr, numb ) ;
   thisleave->type = type ;
   thisleave->lineno = -1 ;
   thisleave->now = 0 ;
   thisleave->unow = 0 ;
   thisleave->sec = 0 ;
   thisleave->usec = 0 ;
   thisleave->value = NULL ;
   thisleave->charnr = -1 ;
   thisleave->name = NULL ;
   for (i=0;i!=numb;i++) 
      thisleave->p[i]=va_arg(argptr, nodeptr) ; 

   va_end( argptr ) ;
   return( thisleave ) ;
}


void checkdosyntax( nodeptr this ) 
{
   if ((this->p[1]!=NULL)&&(this->p[2]!=NULL))
      if ((this->p[1]->type)==(this->p[2]->type))
         exiterror(27) ;
   if ((this->p[2]!=NULL)&&(this->p[3]!=NULL))
      if ((this->p[2]->type)==(this->p[3]->type))
         exiterror(27) ;
   if ((this->p[1]!=NULL)&&(this->p[3]!=NULL))
      if ((this->p[1]->type)==(this->p[3]->type))
         exiterror(27) ;
   return ;
}


void newlabel( nodeptr this ) 
{
   extern proclevel mainlevel ;
   labelboxptr new ;

   new = (labelboxptr)Malloc(sizeof(labelbox)) ;

   new->next = NULL ;
   new->entry = this ;
   if (mainlevel->last!=NULL)
      mainlevel->last->next = new ;
   mainlevel->last = new ;
   if (mainlevel->first==NULL)
      mainlevel->first = new ;
}
 
