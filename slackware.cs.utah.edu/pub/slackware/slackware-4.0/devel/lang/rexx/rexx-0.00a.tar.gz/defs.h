/*
 * Copyright (C) 1992 Anders Christensen <anders@solan.unit.no>
 * Read file README for more information on copying
 */

/*
 * $Id: defs.h,v 1.6 1992/04/05 20:25:52 anders Exp anders $
 *
 * $Log: defs.h,v $
 * Revision 1.6  1992/04/05  20:25:52  anders
 * Added coppyright notice
 * Added some definitions that reflect changes in other modules.
 *
 * Revision 1.5  1992/03/22  00:58:18  anders
 * Added constants for more errormessages
 * Added constants for options to list_leaked()
 * Added constants for options to allocated()
 *
 * Revision 1.4  1992/03/01  03:53:08  anders
 * Added definitions for more tracing of lost memory
 *
 * Revision 1.3  1990/08/11  00:38:58  anders
 * Added more values to support marking of memory allocated to stack
 *
 * Revision 1.2  90/08/09  04:03:25  anders
 * Made more TRC_* macros
 * Put '#ifdef TRACEMEM' around all TRC_* macros
 * 
 * Revision 1.1  90/08/08  02:04:17  anders
 * Initial revision
 * 
 */

#define X_NULL		1
#define X_PROGRAM	2
#define X_STATS		3
#define X_COMMAND	4
#define X_ADDR_V	5
#define X_ADDR_N	6
#define X_ADDR_S	7
#define X_CALL		8
#define X_DO		9
#define X_REP		10
#define X_REP_FOREVER	11
#define X_REP_COUNT	12
#define X_DO_TO		13
#define X_DO_BY		14
#define X_DO_FOR	15
#define X_WHILE		16
#define X_UNTIL		17
#define X_DROP		18
#define X_EXIT		19
#define X_IF		20
#define X_IPRET		21
#define X_ITERATE	22
#define X_LABEL		23
#define X_LEAVE		24
#define X_NUM_D		25
#define X_NUM_F		26
#define X_NUM_FUZZ	27
#define X_NUM_SCI	28
#define X_NUM_ENG	29
#define X_PARSE		30
#define X_PARSE_U	31
#define X_PARSE_ARG	32
#define X_PARSE_EXT	33
#define X_PARSE_NUM	34
#define X_PARSE_PULL	35
#define X_PARSE_SRC	36
#define X_PARSE_VAR	37
#define X_PARSE_VAL	38
#define X_PARSE_VER	39
#define X_PARSE_ARG_U	40
#define X_PROC		41
#define X_PULL		42
#define X_PUSH		43
#define X_QUEUE		44
#define X_RETURN	45
#define X_SAY		46
#define X_SELECT	47
#define X_WHENS		48
#define X_WHEN		49
#define X_OTHERWISE	50
#define X_SIG_VAL	51
#define X_SIG_LAB	52
#define X_SIG_SET	53
#define X_ON		54
#define X_OFF		55
#define X_S_ERROR	56
#define X_S_HALT	57
#define X_S_NOVALUE	58
#define X_S_SYNTAX	59
#define X_TRACE		60
#define X_T_ALL		61
#define X_T_COMM	62
#define X_T_ERR		63
#define X_T_INTER	64
#define X_T_LABEL	65
#define X_T_NORMAL	66
#define X_T_OFF		67
#define X_T_RESULT	68
#define X_T_SCAN	69
#define X_WHAT_BB	70
#define X_WHAT_BW	71
#define X_WHAT_B	72
#define X_WHAT_WB	73
#define X_WHAT_WW	74
#define X_WHAT_W	75
#define X_UPPER_VAR	76
#define X_ASSIGN	77
#define X_LOG_NOT	78
#define X_PLUSS		79
#define X_EQUAL		80
#define X_MINUS		81
#define X_MULT		82
#define X_DEVIDE	83
#define X_MODULUS	84
#define X_LOG_OR	85
#define X_LOG_AND	86
#define X_LOG_XOR	87
#define X_EXP		88
#define X_CONCAT	89
#define X_SPACE		90
#define X_GTE		91
#define X_LTE		92
#define X_GT		93
#define X_LT		94
#define X_DIFF		95
#define X_SIM_SYMBOL	96
#define X_CON_SYMBOL	97
#define X_HEX_STR	98
#define X_STRING	99
#define X_FUNC		100
#define X_U_MINUS	101
#define X_S_EQUAL	102
#define X_S_DIFF	103
#define X_SIMSYMB	104
#define X_INTDIV	105
#define X_EX_FUNC	106
#define X_IN_FUNC	107
#define X_TPL_SOLID	108
#define X_TPL_MVE	109
#define X_TPL_VAR	110
#define X_TPL_TO	111
#define X_TPL_SYMBOL	112
#define X_TPL_SPACE	113
#define X_TPL_POINT	114
#define X_TMPLS		115
#define X_TPL_OFF	116
#define X_TPL_PATT	117
#define X_POS_OFFS	118
#define X_NEG_OFFS	119
#define X_ABS_OFFS	120
#define X_EXPRLIST	121
#define X_SYMBOLS	122
#define X_SYMBOL	123
#define X_ARG		124
#define X_END           125


/* The three first two numbers have not errortext attched to them */
#define ERR_PROG_UNREADABLE	3
#define ERR_PROG_INTERRUPT	4
#define ERR_STORAGE_EXHAUSTED	5
#define ERR_UNMATCHED_QUOTE	6
#define ERR_WHEN_EXCEPTED	7
#define ERR_THEN_UNEXCEPTED	8
#define ERR_WHEN_UNCEPTED	9
#define ERR_UNMATCHED_END	10
#define ERR_FULL_CTRL_STACK	11
#define ERR_TOO_LONG_LINE	12
#define ERR_INVALID_CHAR	13
#define ERR_INCOMPLETE_STRUCT	14
#define ERR_INVALID_HEX_CONST	15
#define ERR_UNEXISTENT_LABEL	16
#define ERR_UNEXPECTED_PROC	17
#define ERR_THEN_EXPECTED	18
#define ERR_STRING_EXPECTED	19
#define ERR_SYMBOL_EXPECTED	20
#define ERR_EXTRAD_DATA		21
/* The next to number have not been assigned an errortext */
#define ERR_INVALID_TRACE	24
#define ERR_INV_SUBKEYWORD	25
#define ERR_INVALID_INTEGER	26
#define ERR_INVALID_DO_SYNTAX	27
#define ERR_INVALID_LEAVE	28
#define ERR_ENVIRON_TOO_LONG	29
#define ERR_TOO_LONG_STRING	30
#define ERR_INVALID_START	31
#define ERR_INVALID_STEM	32
#define ERR_INVALID_RESULT	33
#define ERR_UNLOGICAL_VALUE	34
#define ERR_INVALID_EXPRESSION	35
#define ERR_UNMATCHED_PARAN	36
#define ERR_UNEXPECTED_PARAN	37
#define ERR_INVALID_TEMPLATE	38
#define ERR_STACK_OVERFLOW	39
#define ERR_INCORRECT_CALL	40
#define ERR_BAD_ARITHMETRIC	41
#define ERR_ARITH_OVERFLOW	42
#define ERR_ROUTINE_NOT_FOUND	43
#define ERR_NO_DATA_RETURNED	44
#define ERR_DATA_NOT_SPEC	45
/* No errortexts have not been defined to the next to numbers */
#define ERR_SYSTEM_FAILURE	48
#define ERR_INTERPRETER_FAILURE	49

#define ERR_CANT_REWIND         60
#define ERR_IMPROPER_SEEK       61
#define ERR_BUFFER_TOO_SMALL    62
#define ERR_NO_SUCH_FILE        63

#define ENV_BOURNE_SH	0
#define ENV_C_SHELL	1
#define ENV_COMMAND     2
#define ENV_PATH        3
#define ENV_SYSTEM      4


#ifdef TRACEMEM
/*
 * NOTE: There is a close correspondance between these and the char
 *       array alloc in memory.c
 */
# define TRC_LEAKED	0
# define TRC_HASHTAB	1
# define TRC_PROCBOX	2
# define TRC_SOURCE	3
# define TRC_SOURCEL	4
# define TRC_TREENODE	5
# define TRC_VARVALUE   6
# define TRC_VARNAME    7
# define TRC_VARBOX     8
# define TRC_STACKBOX   9
# define TRC_STACKLINE 10
# define TRC_SYSINFO   11
# define TRC_FILEPTR   12
# define TRC_PROCARG   13
# define TRC_LABEL     14

# define MEMTRC_NONE    0
# define MEMTRC_ALL     1
# define MEMTRC_LEAKED  2

# define MEM_ALLOC      0
# define MEM_CURRENT    1
# define MEM_LEAKED     2
#endif /* TRACEMEM */
