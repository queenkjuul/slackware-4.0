#ifndef lint
static char *RCSid = "$Id: rexxext.c,v 1.4 1992/04/05 20:08:40 anders Exp anders $";
#endif

/*
 * Copyright (C) 1992 Anders Christensen <anders@solan.unit.no>
 * Read file README for more information on copying
 */

/*
 * $Log: rexxext.c,v $
 * Revision 1.4  1992/04/05  20:08:40  anders
 * Added copyright notice.
 * Removed call to cuserid() to get something POSIX
 *
 * Revision 1.3  1992/03/22  18:56:22  anders
 * Added support for CRAY
 *
 * Revision 1.2  1992/03/22  01:15:38  anders
 * #include'd stdio.h
 * explicitly defined cuserid() since it is not defined in ANSI C
 *    under ultrix
 *
 * Revision 1.1  1990/08/08  02:12:26  anders
 * Initial revision
 *
 */

#include "rexx.h"
#include <stdio.h>
#include <unistd.h>
#include <pwd.h>

char *rex_userid( paramboxptr parms ) 
{
   checkparam( parms, 0, 0 ) ;
   return(cpy(getpwuid(getuid())->pw_name)) ;
}
