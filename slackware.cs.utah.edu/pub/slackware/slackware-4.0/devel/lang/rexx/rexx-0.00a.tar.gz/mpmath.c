#ifndef lint
static char *RCSid = "$Id: mpmath.c,v 1.2 1992/04/05 20:13:44 anders Exp anders $";
#endif

/*
 * Copyright (C) 1992 Anders Christensen <anders@solan.unit.no>
 * Read file README for more information on copying
 */

/*
 * $Log: mpmath.c,v $
 * Revision 1.2  1992/04/05  20:13:44  anders
 * Added copyright notice
 *
 * Revision 1.1  1990/08/08  02:11:32  anders
 * Initial revision
 *
 */

