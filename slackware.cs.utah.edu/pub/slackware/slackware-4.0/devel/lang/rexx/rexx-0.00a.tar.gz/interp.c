#ifndef lint
static char *RCSid = "$Id: interp.c,v 1.4 1992/04/05 20:18:41 anders Exp anders $";
#endif

/*
 * Copyright (C) 1992 Anders Christensen <anders@solan.unit.no>
 * Read file README for more information on copying
 */

/*
 * $Log: interp.c,v $
 * Revision 1.4  1992/04/05  20:18:41  anders
 * Added copyright notice
 *
 * Revision 1.3  1992/03/22  01:12:09  anders
 * #include'd stdio.h and ctype.h, which is not included in
 *    rexx.h anymore
 *
 * Revision 1.2  1990/12/10  18:39:04  anders
 * Removed bug: the returncode from yyparse() was not checked, so
 *     interactive commands and interpret-statements that contained an
 *     parse error, reexecuted the main program.
 *
 * Revision 1.1  90/08/08  02:10:09  anders
 * Initial revision
 * 
 */

#include "rexx.h"
#include <stdio.h>
#include <ctype.h>

void dointerpret( char *string ) 
{
   treenode *tmp_swap ;
   extern treenode *rootnode ;   

   initinterpret( string ) ;
   tmp_swap = rootnode ;
   if (!yyparse()) {
      interpret(rootnode) ;
/*    destroytree(roottree) ; */   }
   rootnode = tmp_swap ; 
}


/* actually, this is rather useless .... */
char *dovalue( char *string ) 
{
   treenode *tmp_swap ;
   extern treenode *rootnode ;   
   char *tstr ;

   initvalue( string ) ;
   tmp_swap = rootnode ;
   yyparse() ;
   tstr = evaluate(rootnode->p[0]->p[1]->p[0]) ;
/* destroytree(roottree) ; */
   rootnode = tmp_swap ;
   return tstr ;
}


