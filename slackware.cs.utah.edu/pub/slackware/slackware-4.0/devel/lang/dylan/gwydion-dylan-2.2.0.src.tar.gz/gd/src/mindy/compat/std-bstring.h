extern void	bcopy _ANSI_ARGS_((const void *, void *, size_t));
extern int	bcmp _ANSI_ARGS_((const void *, const void *, size_t));
extern void	bzero _ANSI_ARGS_((void *, size_t));
extern void	blkclr _ANSI_ARGS_((void *, int));
