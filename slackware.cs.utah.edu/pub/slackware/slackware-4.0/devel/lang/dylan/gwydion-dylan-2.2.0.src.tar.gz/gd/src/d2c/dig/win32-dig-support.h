extern void ignore_interrupts (void);
