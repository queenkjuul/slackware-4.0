typedef char **arg_vector;

extern int process_id;
void mutant_fd_exec(char *command, int *toprog, int *fromprog);
