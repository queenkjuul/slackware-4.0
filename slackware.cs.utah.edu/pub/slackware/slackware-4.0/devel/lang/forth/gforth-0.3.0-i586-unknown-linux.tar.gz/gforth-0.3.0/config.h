/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if `sys_siglist' is declared by <signal.h>.  */
#define SYS_SIGLIST_DECLARED 1

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef WORDS_BIGENDIAN */

/* Define if you want to force a direct threaded code implementation
   (does not work on all machines */
#ifndef DIRECT_THREADED
/* #undef DIRECT_THREADED */
#endif

/* Define if you want to force an indirect threaded code implementation */
#ifndef INDIRECT_THREADED
/* #undef INDIRECT_THREADED */
#endif

/* Define if you want to use explicit register declarations for better
   performance or for more convenient CODE words (does not work with
   all GCC versions on all machines) */
#ifndef FORCE_REG
#define FORCE_REG 1
#endif

/* an integer type that is as long as a pointer */
#define CELL_TYPE int

/* an integer type that is twice as long as a pointer */
#define DOUBLE_CELL_TYPE long long

/* a path separator character */
#define PATHSEP ':'

/* define this if there is no working DOUBLE_CELL_TYPE on your machine */
/* #undef BUGGY_LONG_LONG */

/* The number of bytes in a char *.  */
#define SIZEOF_CHAR_P 4

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 4

/* The number of bytes in a long long.  */
#define SIZEOF_LONG_LONG 8

/* The number of bytes in a short.  */
#define SIZEOF_SHORT 2

/* Define if you have the atanh function.  */
#define HAVE_ATANH 1

/* Define if you have the ecvt function.  */
#define HAVE_ECVT 1

/* Define if you have the expm1 function.  */
#define HAVE_EXPM1 1

/* Define if you have the getpagesize function.  */
#define HAVE_GETPAGESIZE 1

/* Define if you have the log1p function.  */
#define HAVE_LOG1P 1

/* Define if you have the memmove function.  */
#define HAVE_MEMMOVE 1

/* Define if you have the mmap function.  */
#define HAVE_MMAP 1

/* Define if you have the pow10 function.  */
#define HAVE_POW10 1

/* Define if you have the rint function.  */
#define HAVE_RINT 1

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the strsignal function.  */
#define HAVE_STRSIGNAL 1

/* Define if you have the strtoul function.  */
#define HAVE_STRTOUL 1

/* Define if you have the sys_siglist function.  */
#define HAVE_SYS_SIGLIST 1

/* Define if you have the sysconf function.  */
#define HAVE_SYSCONF 1

/* Define if you have the <sys/mman.h> header file.  */
#define HAVE_SYS_MMAN_H 1

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1
/* Of course, sys_siglist is a variable, not a function */
