
hex

$30
dup constant wpshd 1 +
dup constant up 2 +
dup constant >tib 2 +
dup constant #tib 2 +
dup constant tibstack 2 +
dup constant >in 2 +
drop
