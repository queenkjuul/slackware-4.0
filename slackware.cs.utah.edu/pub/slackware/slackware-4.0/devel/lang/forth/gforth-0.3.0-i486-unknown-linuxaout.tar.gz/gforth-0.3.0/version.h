static char gforth_version[]="0.3.0" ;
