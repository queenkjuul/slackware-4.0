#include <stdlib.h>

#include <CNCL/Double.h>


int main() {
    CNDouble alpha;
    CNDouble beta(1.5);	
    CNDouble gamma(beta); 
    CNDouble delta = beta;
    CNDouble epsilon = 0.02;

    cout << "alpha[0.0] = " << alpha << endl;
    cout << "beta[1.5] = " << beta << endl;
    cout << "gamma[1.5] = " << gamma << endl;
    cout << "delta[1.5] = " << delta << endl;
    cout << "epsilon[0.02] = " << epsilon << endl;
    
    alpha = epsilon;
    delta = gamma + beta;
    beta = gamma + 5.32;
    gamma = gamma - 1.05;
    epsilon = 2.2 * beta;

    cout << "alpha[0.02] = " << alpha << endl;
    cout << "beta[6.82] = " << beta << endl;
    cout << "gamma[0.45] = " << gamma << endl;
    cout << "delta[3.0] = " << delta << endl;
    cout << "epsilon[15.004] = " << epsilon << endl;

    int hallo = int( gamma );
    double hello = double( long(alpha) );

    cout << "hallo[0] = " << hallo << endl;
    cout << "hello[0.0] = " << hello << endl;

    delta += 78.2;
    epsilon *= 3.03;

    cout << "delta[81.2] = " << delta << endl;
    cout << "epsilon[45.46212] = " << epsilon << endl;
    
    epsilon = alpha;

    if (alpha == epsilon) cout << "comparison' equal' ok" << endl;
    if (alpha != beta) cout << "'nonequal' comparison ok" << endl;
    if (gamma < beta) cout << "'less than' comparison ok" << endl;
    if (delta > 2) cout << "comparison 'greater than constant' ok" << endl;
    if (delta == 81.2) cout << "comparison 'equal to constant' ok" << endl;
 
    alpha += beta;
    beta -= gamma;
    gamma *= epsilon;
    delta /= epsilon;

    cout << "alpha[6.84] = " << alpha << endl;
    cout << "beta[6.37] = " << beta << endl;
    cout << "gamma[.009] = " << gamma << endl;
    cout << "delta[4060] = " << delta << endl;
    cout << "epsilon[0.02] = " << epsilon << endl;

    exit(0);
}

 
