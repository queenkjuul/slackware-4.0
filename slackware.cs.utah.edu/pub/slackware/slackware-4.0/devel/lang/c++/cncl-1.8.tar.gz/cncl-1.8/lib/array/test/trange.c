// -*- C++ -*-

#include <CNCL/ArrayInt.h>



void exit_handler()
{
    cerr << "trange: exit_function()" << endl;
}



main()
{
    int i;
    
    // Error handling
    CNCL::set_exit_handler(exit_handler);

    CNArrayInt a(5);
    
    // Should yield index error except for i=0..4
    for(i=-2; i<8; i++)
	a.put(i, 999);

    cout << a << endl;
    
    // Reset error handling
    CNCL::set_exit_handler(CNCL::default_exit_handler);
    
    // Index error and abort
    a[10] = 111;

    /**NOT REACHED**/
    return 0;
}

