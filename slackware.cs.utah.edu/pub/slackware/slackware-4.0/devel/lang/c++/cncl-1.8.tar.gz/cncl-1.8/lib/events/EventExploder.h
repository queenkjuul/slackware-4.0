//   -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * $Id: EventExploder.h,v 0.30 1996-08-07 17:56:26+02 steppler Exp $
 *
 * Class: CNEventExploder --- send CNEvents to many CNEventHandlers
 *
 *****************************************************************************
 * Copyright (C) 1992-1996   Communication Networks
 *                           Aachen University of Technology
 *                           D-52056 Aachen
 *                           Germany
 *                           Email: cncl-adm@comnets.rwth-aachen.de
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 *****************************************************************************/

#ifndef __CNEventExploder_h
#define __CNEventExploder_h


#include <CNCL/EventHandler.h>		// Base class

#include <CNCL/DLList.h>

extern CNClassDesc CN_EVENTEXPLODER;	// Class CNEventExploder description


/*
 * The class CNEventExploder
 */

class CNEventExploder : public CNEventHandler
{
  public:	/***** Constructors ******************************************/
    CNEventExploder() {}				// Default constructor
    CNEventExploder(CNParam *) {}			// CNParam constructor

  public:	/***** Public interface **************************************/
    virtual void add_handler(CNEventHandler *eh);
    virtual void rem_handler(CNEventHandler *eh);
    virtual void event_handler(const CNEvent *ev);

  private:	/***** Internal private members ******************************/
    CNDLList handlers;
/***
    void process_event(CNEventScheduler *sched,
		       const CNSimTime t, const CNEvent *ev);
***/

  public:	/***** Member functions required by CNCL *********************/
    virtual CNClassDesc class_desc() const	// CNClass description
    { return CN_EVENTEXPLODER; }
            
    virtual bool is_a(CNClassDesc desc) const	// Type checking
    { return desc == CN_EVENTEXPLODER ? TRUE : CNEventHandler::is_a(desc); }
        
    static CNEventExploder *cast_from_object(CNObject *obj) // Safe type cast
    {
#   ifdef NO_TYPE_CHECK
	return (CNEventExploder *)obj;
#   else
	return (CNEventExploder *)( !obj || obj->is_a(CN_EVENTEXPLODER)
	       ? obj : fatal_type(obj->class_desc(), CN_EVENTEXPLODER) );
#   endif
    }
    
    static CNObject *new_object(CNParam *param = NIL) // Object creation
    { return param ? new CNEventExploder(param) : new CNEventExploder; }
    
    // Print/debug output
    virtual void print(ostream &strm = cout) const;
    virtual void dump (ostream &strm = cout) const;
};

#endif /**__CNEventExploder_h**/





