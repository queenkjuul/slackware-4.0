// -*- C++ -*-

#include <iostream.h>

#include <CNCL/MomentsTime.h>


main()
{
    CNMomentsTime stat("tCNMomentsTime");

    stat.put(1.0, 1.0);
    stat.put(2.0, 2.0);
    stat.put(3.0, 3.0);
    
    cout << stat;
}
