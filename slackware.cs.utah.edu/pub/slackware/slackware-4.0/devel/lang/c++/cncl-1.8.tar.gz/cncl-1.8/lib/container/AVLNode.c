//   -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * $Id: AVLNode.c,v 0.30 1996-08-07 17:54:51+02 steppler Exp $
 *
 * Class: CNAVLNode --- Node for CNAVLTree
 *
 *****************************************************************************
 * Copyright (C) 1992-1996   Communication Networks
 *                           Aachen University of Technology
 *                           D-52056 Aachen
 *                           Germany
 *                           Email: cncl-adm@comnets.rwth-aachen.de
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 *****************************************************************************/

#include "AVLNode.h"

CNAVLNode::CNAVLNode(): l(NIL), r(NIL), bal(0) {};

CNAVLNode::CNAVLNode(CNParam*): l(NIL), r(NIL), bal(0) {};

CNAVLNode::~CNAVLNode() {
    if (l) {
	delete l;
	l = NIL;
    };
    if (r) {
	delete r;
	r = NIL;
    };
    bal = 0;
};

void CNAVLNode::print_tree(ostream &strm, int depth) const {
    if (l) l->print_tree(strm,depth+1);
    for (int i = depth; i; i--) strm << "  ";
    print(strm);
    if (r) r->print_tree(strm,depth+1);
};

void CNAVLNode::dump_tree(ostream &strm, int depth) const {
    if (l) l->dump_tree(strm,depth+1);
    for (int i = depth; i; i--) strm << "  ";
    dump(strm);
    if (r) r->dump_tree(strm,depth+1);
};


/***** Default I/O member function for CNCL classes **************************/

// Normal output
void CNAVLNode::print(ostream &strm) const
{
    strm <<   "this=" << hex << (unsigned long)this
	 <<  " left=" << hex << (unsigned long)l
	 << " right=" << hex << (unsigned long)r << dec << endl;

}

// Debug output
void CNAVLNode::dump(ostream &strm) const
{
    strm << "CNAVLNode { $Revision: 0.30 $" << endl
	 <<   "this=" << hex << (unsigned long)this
	 <<  " left=" << hex << (unsigned long)l
	 << " right=" << hex << (unsigned long)r << dec
	 <<   " bal=" << bal
	 << " }" << endl;
}



/***** CNCL stuff for type information ***************************************/

// Describing object for class CNAVLNode
static CNClass CNAVLNode_desc("CNAVLNode", "$Revision: 0.30 $", NIL);

// "Type" for type checking functions
CNClassDesc CN_AVLNODE = &CNAVLNode_desc;
