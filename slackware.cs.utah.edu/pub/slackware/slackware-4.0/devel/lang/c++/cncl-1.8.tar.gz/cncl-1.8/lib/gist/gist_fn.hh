// -*- C++ -*-

#ifndef gist_fn_h
#define gist_fn_h

void pre_filename(char *fn);
void post_filename(char *fn, long id);

#endif
