//  -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * $Id: ptest.c,v 1.2 1996-08-07 18:00:22+02 steppler Exp $
 *
 * CNClass: Test --- Test class for tDL test
 *
 * $Log: ptest.c,v $
 * Revision 1.2  1996-08-07 18:00:22+02  steppler
 * Cosmetical changes only.
 * Updated headers.
 *
 * Revision 1.1  1995-08-09 19:17:50+02  steppler
 * Initial revision
 *
 *****************************************************************************
 * Copyright (C) 1992-1996   Communication Networks
 *                           Aachen University of Technology
 *                           D-52056 Aachen
 *                           Germany
 *                           Email: cncl-adm@comnets.rwth-aachen.de
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 *****************************************************************************/

#include "ptest.h"

ptest::ptest(CNPstream& strm):CNPObjectID()
{
    strm >> n;
}

int ptest::storer(CNPstream& strm){
   strm << n;
   return 0;
}


/***** Default I/O member function for CNCL classes **************************/

// ***** Change this for your class *****

// CNNormal output
void ptest::print(ostream &strm) const
{
    // ... insert your own stuff here ...
    strm << "n=" << n << endl;
}

// Debug output
void ptest::dump(ostream &strm) const
{
    // ... insert your own stuff here ...
    strm << "Test { "
	 << "n=" << n
	 << " }" << endl;
}



/***** CNCL stuff for type information and exemplar objects ******************/

// Describing object for class Test
static CNClass ptest_desc("ptest", "$Revision: 1.2 $", ptest::new_object);

// "Type" for type checking functions
CNClassDesc CN_PTEST = &ptest_desc;

// Registering the reader function in the reader table 
static CNReaderTbl ptest_reader_entry("ptest", (Reader_ptr) ptest::reader);



/***** Safe type casts *******************************************************/

/*ptest *ptest::cast_from_object(CNObject *obj)
{
    if(!test_flag(type_check))
	return (ptest *)obj;
    if(obj->is_a(CN_PTEST))
	return (ptest *)obj;
    else
    {
	fatal(NIL, "Invalid type cast: ", obj->class_desc()->name(),
	      " -> Test");
	return NIL;
    }
}

*/

/***** CNObject creation *******************************************************/

CNObject *ptest::new_object(CNParam *param)
{
    return param ? new ptest(param) : new ptest;
}
