// -*- C++ -*-

#include "gist_fn.hh"
#include <stdio.h>

extern "C" int getuid();

void pre_filename(char *fn) {
    sprintf(fn, "/tmp/gist_pre%d", getuid());
};

void post_filename(char *fn, long id) {
    sprintf(fn, "/tmp/gist_post%d.%ld", getuid(), id);
};
