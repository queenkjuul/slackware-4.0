// -*- C++ -*-
#include <CNCL/String.h>
#include <CNCL/FormFloat.h>

main()
{
    double x;
    char m;
    int y;
    

    CNFormFloat b(1.234000,20,'.', CNFormFloat::left,7);
    cout<<b;
    cout<<"value"<<endl;
    cin>>x;
    b.set_value(x);
    cout<<b;
    
    cout<<"width"<<endl;
    cin>>y;
    b.set_width(y);
    cout<<b;
    
    cout<<"precision"<<endl;
    cin>>y;
    b.precision(y);
    cout<<b;
    
    cout<<"fill"<<endl;
    cin>>m;
    b.set_fill(m);
    cout<<b;

    b.set_format(CNFormFloat::right);
    cout<<b;

    b.set_format(CNFormFloat::right|CNFormFloat::scientific);
    cout<<b;

    b.set_format(CNFormFloat::left|CNFormFloat::scientific);
    cout<<b;

    b.set_format(CNFormFloat::right|CNFormFloat::showpoint);
    cout<<b;

    b.set_format(CNFormFloat::left|CNFormFloat::showpoint);
    cout<<b;

    b.set_format(CNFormFloat::left);
    cout<<b;

    b.set_width(10);
    cout<<b;
}



