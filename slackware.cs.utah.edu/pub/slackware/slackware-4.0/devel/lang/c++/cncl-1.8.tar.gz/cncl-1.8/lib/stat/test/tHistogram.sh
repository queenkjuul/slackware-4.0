#!/bin/sh
tHistogram > tHistogram.result
tHistogram tHistogram.dat histo.dat 0 0.25 20 -c 13 >> tHistogram.result
tHistogram tHistogram.dat histo.dat 0 0.25 20 -c 9 >> tHistogram.result
cat histo.dat >> tHistogram.result
rm histo.dat
tHistogram tHistogram.dat histo.dat 0 0.25 20 -c >> tHistogram.result
cat histo.dat >> tHistogram.result 
rm histo.dat
if diff tHistogram.result tHistogram.ref; then
	echo "Test of Histogram o.k.!"
	rm tHistogram.result
	exit 0
else
	echo "Test of Histogram failed!"
	exit 0
fi
