//-*-c++-*-

#include <CNCL/String.h>


main()
{
    CNString b;
    CNString d(20);
    CNString e("e",20);
    CNString a("erster");
    CNString c(a);
    
    int i;
    char ch;
    char* cs = "dritt";
    b = "zweiter";
    cout << " CNString 1 ist : "<<a<<", "<<a.capacity()<<", "<<a.length()<<endl;
    cout<<" CNString 2 ist : "<<b<<", "<<b.capacity()<<", "<<b.length()<<endl;
    c = b;
    c += a;
    i = c.downsearch(a);
    if (b.length() != ((unsigned long)i)) cout<<"E R R O R"<<endl;
    c.to_lower();
    cout<<c<<" ";
    c.to_upper();
    cout<<c<<" ";
    c.capitalize();
    cout<<c<<endl;
    cout<<" ----------"<<endl;
   
    ch = '1';
    i = 4;
    
    c = a.after(i);
    cout<<c<< " ";
    c = a.before(i);
    cout<<c<<endl;
    b.add(ch);
    ch = a[i];
    cout <<b<<endl;
    a.replace(ch,a(i-1));
    cout<<" "<<a<<endl;
    i = a.upsearch(a(i-1));
    a.replace(ch,i);

    cout<<" ----------"<<endl;

    c = 'd';
    cout<<c<<endl;
    c +="ritter";
    a.insert(c);
    cout<<a<<" , "<<c<<" , "<<b<<endl;
    a.insert('x',2);
    cout<<a<<endl;
    a.del(2);
    a.insert("test",4);
    cout<<a<<endl;
    cout<<" ----------"<<endl;
    a.del(4,4);
    a.replace(c,b);
    cout<<a<<endl;
    c.replace(b,0,1);
    cout<<c<<endl;
    cout<<" ----------"<<endl;
    
    if ( c.matches(cs) ) cout<<"matches1"<<endl;
    else cout<<"doesn't match"<<endl;
    b = c.after(1,3);
    if ( c.matches(b,1) ) cout<<"matches2"<<endl;
    cout<<" ----------"<<endl;
    cout<<"Bitte 1. CNString eingeben : "<<endl;
    cin>>d;
    cout<<"Bitte 2. CNString eingeben : "<<endl;
    cin>>e;
    cout<<"Bitte 3. CNString eingeben : "<<endl;
    cin>>c;
    cout<<d<<" , "<<e<<" , "<<c<<endl;
    if (d > e) cout<<d<<" > "<<e<<endl;
    if (d < e) cout<<d<<" < "<<e<<endl;
    if (e >= c) cout<<e<<" >= "<<c<<endl;
    if (e <= c) cout<<e<<" <= "<<c<<endl;
    if (d == c) cout<<d<<" == "<<c<<endl;
    if (d != c) cout<<d<<" != "<<c<<endl;
    
    
}





