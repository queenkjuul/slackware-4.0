// -*- C++ -*-

/*
 * Test program for random number generators
 */

#include <string.h>

#include <CNCL/Moments.h>

#include <CNCL/RNG.h>
#include <CNCL/FiboG.h>

#include <CNCL/RndInt.h>


enum { NRANDOM = 20, NVAL = 100000 };


char buffer[128];



main()
{
    CNRNG *gen = new CNFiboG;
    CNRndInt rng(0, 10, gen);
    int j;

    gen = new CNFiboG;
    
    rng.dump();
	
    strcpy(buffer, rng.class_desc()->name());
    strcat(buffer, " ");
    strcat(buffer, rng.class_desc()->version());
	
    CNMoments stat(buffer);
	    
    for(j=0; j<NVAL; j++)
	stat.put(rng());
	    
    cout << stat;
}
