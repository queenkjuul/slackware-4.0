// -*- C++ -*-

#include <iostream.h>

#include <CNCL/Moments.h>


main()
{
    double x;
    CNMoments stat("tCNMoments", "Moments evaluation of numbers you entered");
    
    for(;;)
    {
	cin >> x;
	if(!cin.good())
	    break;
	stat.put(x);
    }
    cout << "Name: " << stat.get_name() << endl;
    cout << "Desc: " << stat.get_desc() << endl << endl;
    cout << stat;
}
