//   -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * $Id: QueueSPT.c,v 0.31 1996-08-07 17:55:40+02 steppler Exp $
 *
 * Class: CNQueueSPT --- ...
 *
 *****************************************************************************
 * Copyright (C) 1992-1996   Communication Networks
 *                           Aachen University of Technology
 *                           D-52056 Aachen
 *                           Germany
 *                           Email: cncl-adm@comnets.rwth-aachen.de
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 * 
 * As an exception to this rule you may use this template to generate
 * your own classes. This does not cause these classes to be covered by
 * the GNU Library General Public License. This exception does not
 * however invalidate any other reasons why the resulting program must be
 * covered by the GNU Library General Public License.
 *****************************************************************************/

#include <CNCL/Class.h>

#include "QueueSPT.h"


bool CNQueueSPT::empty() const
{
    return n == 0;
}



bool CNQueueSPT::full() const
{
    return FALSE;
}



int CNQueueSPT::length() const
{
    return n;
}



void CNQueueSPT::put(CNObject *obj)
{
    if (!obj->is_a(CN_JOB))
        fatal("CNQueueSPT::put", 
              " only CNJobs are accepted in this queue-type");
 
    CNJob *job = CNJob::cast_from_object(obj);
    CNDLObject *pos = list.first();
    
    while(pos)
    {
        CNJob *ojob = CNJob::cast_from_object(pos->object());
        if (job->length < ojob->length)
        {
            list.insert_before(pos, job);
            break;                   // either there is a longer job than
        }                            // this one so it can be inserted before
        pos = pos->next();           // or it has to be appended at the end.
    }                                // this also works with an empty list.
    if (!pos) list.append(job);      // (olly)

    n++;
}



CNObject *CNQueueSPT::get()
{
    CNDLObject *pos;
    CNObject *obj;
    
    pos = list.first();
    if(pos)
    {
        obj = pos->object();
        list.delete_object(pos);
        n--;
    }
    else
        obj = NIL;
    
    return obj;
}

CNObject *CNQueueSPT::peek()
{
    CNDLObject *pos;
    
    pos = list.first();
    if(pos)
        return pos->object();
    
    return NIL;
}



void CNQueueSPT::delete_all()
{
    list.delete_all();
    n = 0;
}




/***** Default I/O member function for CNCL classes **************************/

// Normal output
void CNQueueSPT::print(ostream &strm) const
{
    strm << "length=" << n << endl;
    list.print(strm);
}

// Debug output
void CNQueueSPT::dump(ostream &strm) const
{
    strm << "CNQueueSPT { $Revision: 0.31 $ ..." << endl
	 << "length=" << n << endl;
    list.dump(strm);
    strm << " }" << endl;
}

// IOStream operator <<
ostream &operator << (ostream &strm, const CNQueueSPT &obj)
{
    obj.print(strm);
    return strm;
}

ostream &operator << (ostream &strm, const CNQueueSPT *obj)
{
    if(obj)
	obj->print(strm);
    else
	strm << "(NIL)";
    return strm;
}



/***** CNCL stuff for type information ***************************************/

// Describing object for class CNQueueSPT
static CNClass CNQueueSPT_desc("CNQueueSPT", "$Revision: 0.31 $",
			    CNQueueSPT::new_object);

// "Type" for type checking functions
CNClassDesc CN_QUEUESPT = &CNQueueSPT_desc;
