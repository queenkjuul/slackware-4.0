#!/bin/sh
tParseArgs -o outfile infile > tParseArgs.result
tParseArgs -ooutfile infile  >> tParseArgs.result
tParseArgs infile outfile -r 47.11 >> tParseArgs.result

if diff tParseArgs.result tParseArgs.ref; then
	echo "Test of ParseArgs o.k.!"
	rm tParseArgs.result
	exit 0
else
	echo "Test of ParseArgs failed!"
	exit 0
fi
