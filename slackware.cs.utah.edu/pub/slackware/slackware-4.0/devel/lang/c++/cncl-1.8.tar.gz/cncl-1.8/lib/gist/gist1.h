// -*- C++ -*-


// GIST -- Graphical Interactive Simulation result Tool

//   CNCL interface classes

//   1992-94 Martin Horneffer

#ifndef gist1_h
#define gist1_h

#include <CNCL/World.h>
#include <CNCL/MovingObject.h>
#include <CNCL/ColorfulObject.h>
#include <CNCL/TextObject.h>
#include <CNCL/ValueObject.h>
#include <CNCL/DiagObject.h>
#include <CNCL/PolyLine.h>

#endif
