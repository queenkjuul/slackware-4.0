// -*- C++ -*-

#include <fstream.h>

#include <CNCL/Piostream.h>
#include <CNCL/PDLList.h>
#include <CNCL/DLIterator.h>
#include <CNCL/PString.h>


int main()
{
    CNPDLList list;
    fstream ostrm("persiDLList.dat", ios::out);
    CNPiostream out(ostrm);
    CNPString a = "111.0";
    CNPString b = "222.0";
    CNPString c = "333.0";
    CNPString d = "444.0";
    CNPString e = "555.0";
    CNPString f = "666.0";
    CNPString g = "777.0";
    CNPString h = "888.0";
    CNPString i = "999.0";
    
    
    list.append(a); // 111
    list.append(b); // 222
    list.append(a); // 111
    list.append(d); // 444
    list.append(e); // 555 
    list.append(f); // 666
    list.append(g); // 777
    list.append(c); // 333
    list.append(i); // 999
    list.append(e); // 555
    list.append(f); // 666
    list.append(g); // 777
    list.append(h); // 888
    list.append(a); // 111
    list.append(b); // 222
    list.append(a); // 111
    list.append(d); // 444
    list.append(e); // 555
    list.append(f); // 666
    list.append(g); // 777
    list.append(h); // 888
    list.append(i); // 999
    list.append(e); // 555
    list.append(f); // 666
    list.append(g); // 777
    list.append(h); // 888

    
    list.store_on(out);

    fstream istream("persiDLList.dat", ios::in);
    CNPiostream in(istream);

    CNPDLList *list2;
    list2 = CNPDLList::read_from(in);
     
    CNDLIterator trav(list2);
    CNObject *p;

    while((p = trav++))
	cout << *p << endl;


    // Delete all items
    list.delete_all();
    list.ok();
}







