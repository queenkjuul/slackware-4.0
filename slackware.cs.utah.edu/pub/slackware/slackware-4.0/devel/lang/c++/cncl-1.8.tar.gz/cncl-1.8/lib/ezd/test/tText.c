// -*- C++ -*-

#include <unistd.h>

#include <CNCL/String.h>

#include <CNCL/FiboG.h>
#include <CNCL/RndInt.h>

#include <CNCL/EZD.h>
#include <CNCL/EZDWindow.h>
#include <CNCL/EZDDrawing.h>

#include <CNCL/EZDTextWin.h>


extern "C" int usleep(unsigned);


int main()
{
    EZDWindow win(400, 400);
    EZDDrawing draw;
    CNString in; 
    CNFiboG *g = new CNFiboG;
    CNRndInt rnd(0, 23, g);
    int i, v;
	
    win.overlay(&draw);

    EZD::draw_fill_rectangle(50,150,300,50, "Green");

    EZDTextWin diag("textwin", "EZDTextWin Test", 24, 75);
    
    for(i=0; i<400; i++)
    {
	v = rnd();
	
	diag.add(v, 3*v, "abc");
	EZD::draw_fill_rectangle(v*5, v*5, 10, 10, "Red");

	usleep(100000);
    }
    

    cin >> in;
    
}
