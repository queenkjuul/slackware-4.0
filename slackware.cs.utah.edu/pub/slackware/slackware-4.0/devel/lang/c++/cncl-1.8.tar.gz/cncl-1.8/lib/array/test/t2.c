// -*- C++ -*-


#include <CNCL/Array2Int.h>


void exit_handler()
{
    cerr << "t2: exit_function()" << endl;
}



int main()
{
    int i, j;
    
    // Error handling
    CNCL::set_exit_handler(exit_handler);

    CNArray2Int a(5, 10, 1);

    a[2][2] = 2;
    a[4][4] = 3;
    a[0][5] = 4;
    a[1][6] = 5;
    a[2][7] = 6;
    a[3][8] = 7;
    a[4][9] = 8;
    
    cout << a;

    a.size(6, 6);
    cout << a;
    
    a.size(3, 15);
    cout << a;

    CNArray2Int b(a);
    CNArray2Int c;
    
    c = b;
    
    a.dump();
    b.dump();
    c.dump();

    // Should yield index error except for i=0..2
    for(i=-2; i<8; i++)
	a.put(i, 0, 999);

    for(i=-1; i<4; i++)
	    a[i];
    for(i=0; i<3; i++)
	for(j=-1; j<16; j++)
	    a[i][j];
    
}

    
