// -*- C++ -*-

#include <CNCL/CNCL.h>
#include <math.h>


main()
{
    // Error handling
    CNCL::set_error(CNCL::err_warning);

    // Create matherrs
    sqrt(-1.0);
    log(0.0);
    log10(0.0);
    exp(1000.0);
    atan2(0.0, 0.0);
    exp(-1000.0);
    
    return 0;
}
