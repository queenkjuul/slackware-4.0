// -*- C++ -*-

#include <CNCL/FNumTriangle.h>

#define FNum CNFNumTriangle


int main()
{
    FNum a, b, c;
    
    a = FNum(10, 1, 2);
    b = FNum(20, 2, 3);
    
    cout << a << b;

    c = -a;
    cout << c;
    c = +a;
    cout << c;

    c = a + b;
    cout << c;
    c = a - b;
    cout << c;

}


