// -*- C++ -*-


#include <CNCL/IniFile.h>


int main()
{
    CNIniFile ini("test.ini");
    CNString s;
    
//    cout << ini;
    ini.set_section("Test");
    cout << "[Test] display = " << ini.get_entry("display") << endl;
    cout << "[Test] string  = " << ini.get_entry("string") << endl;
    cout << "[Test] abc     = " << ini.get_entry("abc") << endl;

    ini.set_section("Blub");
    for(s=ini.get_entry("test", TRUE);
	s!="FALSE";
	s=ini.get_entry("test", FALSE))
	cout << "[Blub] test = " << s << endl;
    
//    ini.write("testnew.ini");
}
