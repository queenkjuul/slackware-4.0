// -*- C++ -*-


#include <CNCL/String.h>
#include <CNCL/Select.h>


int main()
{
    CNSelect sel;
    CNString s;
    bool val;
    
    sel.add_read(0);
    
    cout << "Press <Return> ... ";
    cout.flush();
    val = sel.select();
    cout << ( val ? "O.K." : "Error" ) << endl;
    cin  >> s;
    
    cout << "Press <Return> within 5 secs ... ";
    cout.flush();
    val = sel.select(5, 0);

    if(val)
    {
	cout << "You pressed <Return>" << endl;
	cin >> s;
    }
    else
	cout << endl << "You did not press <Return>" << endl;
}



