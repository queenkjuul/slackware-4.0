// -*- C++ -*-

#include <iostream.h>
#include <fstream.h>

#include <CNCL/Piostream.h>
#include <CNCL/PDLList.h>
#include <CNCL/DLIterator.h>
#include <CNCL/ReaderTbl.h>
#include "ptest.h"


int main()
{
   cout << "Beginn der Datenspeicherung\n";
   fstream ostrm("persidatenDL.dat", ios::out);
   CNPiostream out(ostrm);
   
   
   CNPDLList list;
   
   ptest a(111);
   
   list.append(a);
   list.append(a);
   
   list.append(new ptest(111));
   list.append(new ptest(222));
   list.append(new ptest(333));
   list.append(new ptest(444));
   list.append(new ptest(555));
   list.append(new ptest(666));
   list.append(new ptest(777));
   list.append(new ptest(888));
   list.append(new ptest(999));
   
   list.store_on(out);
 
    CNReaderTbl::reset_id_tbl(); 
    
   cout << "Einlesebegin.\n";
   fstream istream("persidatenDL.dat", ios::in);
   CNPiostream in(istream);
  
   CNPDLList *list2;
   
   list2 = CNPDLList::read_from(in);
   
    CNDLIterator trav(list2);
    CNObject *p;

    // Output original list
    cout << "----------" << endl;
    while((p = trav++))
	cout << *p;
       






    // Delete all items
    list.delete_all();
    list.ok();
//    list.dump();

}







