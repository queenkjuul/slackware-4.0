//   -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * $Id: PDLList.c,v 0.30 1996-08-07 17:59:54+02 steppler Exp $
 *
 * Class: CNPDLList --- class persistent CNDLList
 *
 *****************************************************************************
 * Copyright (C) 1992-1996   Communication Networks
 *                           Aachen University of Technology
 *                           D-52056 Aachen
 *                           Germany
 *                           Email: cncl-adm@comnets.rwth-aachen.de
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 *****************************************************************************/

#include "PDLList.h"
#include <CNCL/DLIterator.h>


CNPDLList::CNPDLList(CNPstream& strm) :CNPObjectID(){
    long l;
    strm >> l ;
    CNObject *p;
    while(l-- > 0)
    {
	p = CNPIO::read_object(strm);
	append(p);
    }
}

int CNPDLList::storer(CNPstream& strm){
    strm << (long) length();
    CNDLIterator trav(this);
    CNObject *p;
    while( (p = trav++) )
    {
	CNPIO::store_object(strm, *p);
    }
    
    return 0;
}

/***** CNCL stuff for type information ***************************************/

// Describing object for class CNPDLList
static CNClass CNPDLList_desc("CNPDLList", "$Revision: 0.30 $",
			    CNPDLList::new_object);

// "Type" for type checking functions
CNClassDesc CN_PDLLIST = &CNPDLList_desc;


// Registering the reader function in the reader table 
static CNReaderTbl CNPDLList_reader_entry("CNPDLList", (Reader_ptr) CNPDLList::reader);

