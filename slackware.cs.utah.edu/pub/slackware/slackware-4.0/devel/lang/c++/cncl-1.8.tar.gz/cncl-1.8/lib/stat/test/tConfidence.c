// -*- C++ -*-

#include <iostream.h>
#include <CNCL/FiboG.h>
#include <CNCL/Uniform.h>
#include <CNCL/Confidence.h>

main()
{
  CNFiboG rng;
  CNUniform a_uniform_random(0.0,1.0,&rng);
  CNConfidence stat("tCNConfidence", 
		    "Event probability and confidence interval "
		    "(of uniform [0;1] distribution");
  
  for(int i=0;i<10;i++)
    {
      stat.put(a_uniform_random());
    }
  cout << "Name: " << stat.get_name() << endl;
  cout << "Desc: " << stat.get_desc() << endl << endl;
  cout << stat;
  stat.reset();
  for(int i=0;i<100;i++)
    {
      stat.put(a_uniform_random());
    }
  cout << "Name: " << stat.get_name() << endl;
  cout << "Desc: " << stat.get_desc() << endl << endl;
  cout << stat;
  stat.reset();
  for(int i=0;i<1000;i++)
    {
      stat.put(a_uniform_random());
    }
  cout << "Name: " << stat.get_name() << endl;
  cout << "Desc: " << stat.get_desc() << endl << endl;
  cout << stat;
  stat.reset();
  for(int i=0;i<10000;i++)
    {
      stat.put(a_uniform_random());
    }
  cout << "Name: " << stat.get_name() << endl;
  cout << "Desc: " << stat.get_desc() << endl << endl;
  cout << stat;
  stat.reset();
  for(int i=0;i<100000;i++)
    {
      stat.put(a_uniform_random());
    }
  cout << "Name: " << stat.get_name() << endl;
  cout << "Desc: " << stat.get_desc() << endl << endl;
  cout << stat;
}
