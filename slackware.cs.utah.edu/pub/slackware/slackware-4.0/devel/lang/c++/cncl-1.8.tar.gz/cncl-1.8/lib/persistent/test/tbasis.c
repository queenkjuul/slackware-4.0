//-*-C++-*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 *****************************************************************************
 * Copyright (C)      1994   Hans Georg Rese 
 *               1992/1993   Communication Networks
 *                           Aachen University of Technology
 *                           D-52056 Aachen
 *                           Germany
 *                           Email: cncl-adm@comnets.rwth-aachen.de
 ****************************************************************************/

#include <fstream.h>

#include <CNCL/PInt.h>
#include <CNCL/PDouble.h>
#include <CNCL/Piostream.h>
#include <CNCL/PString.h>

int main(){


/****************************************************************************
 * Testprogramm zur Erzeugung einiger persistenter Objekte                  *
 ****************************************************************************/
    fstream ostrm("persidaten.dat", ios::out);
    CNPiostream out(ostrm);
    CNPInt a1=1;
    CNPInt b1=2;
    CNPInt c1=3;
    CNPDouble x1=111.0;
    CNPDouble y1=222.0;
    CNPDouble z1=333.0;
    
    CNPString q1 = "Hallo";
    
    cout << "Beginn der Datenspeicherung"<<endl;
    a1.store_on(out, TRUE);
    x1.store_on(out, TRUE);
    b1.store_on(out, TRUE);
    y1.store_on(out, TRUE);



/****************************************************************************
 * Testprogramm zum Wiedereinlesen der persistenten Objekte                  *
 ****************************************************************************/

   cout << "Einlesebegin.\n";
   fstream istream("persidaten.dat", ios::in);
   CNPiostream in(istream);
   CNPInt *a,*b,*c;
   CNPDouble *x,*y,*z;
   CNObject *q, *p;
   
   a = CNPInt::read_from(in);
   x = CNPDouble::read_from(in);
   b = CNPInt::read_from(in);
   y = CNPDouble::read_from(in);
    cout << "Beginn der Datenspeicherung"<<endl;
   c1.store_on(out);
   z1.store_on(out);
    q1.store_on(out, TRUE);
   q1.store_on(out);
   cout << "Einlesebegin.\n";
   c = CNPInt::read_from(in);
   z = CNPDouble::read_from(in);

   q = CNPString::read_from(in);
   p = CNPString::read_from(in);
  
    
   cout<<*a<<endl<<*b<<endl<<*c<<endl;
   cout<<*x<<endl<<*y<<endl<<*z<<endl;
   cout<<*q<<endl;
    cout<<*p<<endl;
  
//   test = CNPInt::read_from(in);   // error testing
//   exit (1);
}



