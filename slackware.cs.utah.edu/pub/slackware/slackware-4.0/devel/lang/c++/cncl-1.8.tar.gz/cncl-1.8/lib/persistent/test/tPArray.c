// -*- C++ -*-

#include <fstream.h>

#include <CNCL/PArrayObject.h>
#include <CNCL/PString.h>
#include <CNCL/Piostream.h>




main()
{
    cout << "Beginn der Datenspeicherung\n";
   fstream ostrm("persidatenAR.dat", ios::out);
//    ostrm.unsetf(ios::skipws);
    
   CNPiostream out(ostrm);
   CNPArrayObject a(10);
    CNPArrayObject *b;
    
    CNPString c1("Hallo");
    CNPString c2("Hallo Leute");
    CNPString c3("Hallo Leute wie");
    CNPString c4("Hallo Leute wie gehts");
    CNPString c5("Hallo Leute wie gehts Euch");
    CNPString c6("Hallo Leute wie gehts Euch denn");
    CNPString c7("Hallo Leute wie gehts Euch denn heute");

    a.put(0, &c1);
    a.put(1, &c2);
    a.put(2, &c3);
    a.put(3, &c4); 
    a.put(4, &c5);
    a.put(5, &c6);
    a.put(6, &c7);
    a.put(7, &c1);
    a.put(8, &c5);
    a.put(9, &c3);

    cout << a << endl;


    a.store_on(out);
    
    cout << " Beginn des Einlesevorgangs\n";
   fstream istream("persidatenAR.dat", ios::in);
    
    CNPiostream in(istream);
    
    b = CNPArrayObject::read_from(in);

    cout << b[0]<<endl;
    
    return 0;
}






