// -*- C++ -*-
#include <fstream.h>

#include <CNCL/Piostream.h>
#include <CNCL/PDLList.h>
#include <CNCL/DLIterator.h>
#include <CNCL/ReaderTbl.h>
#include <CNCL/PString.h>
#include <CNCL/PInt.h>
#include <CNCL/PDouble.h>


int main()
{
    CNPDLList list;
    
   cout << "Beginn der Datenspeicherung\n";
   fstream ostrm("persidatenDL.dat", ios::out);
   CNPiostream out(ostrm);
   CNPString a = "111.0";
   CNPString b = "222.0";
   CNPString c = "333.0";
   CNPString d = "444.0";
   CNPString e = "555.0";
   CNPString f = "666.0";
   CNPString g = "777.0";
   CNPString h = "888.0";
   CNPString i = "999.0";
   CNPInt j1=1234;
   CNPInt k1=2;
   CNPInt l1=3;
   CNPDouble x1=111.0;
   CNPDouble y1=222.0;
   CNPDouble z1=333.0;
  
   
   list.append(a); // 111
   list.append(b); // 222
   list.append(a); // 111
   list.append(d); // 444
   list.append(e); // 555 
   list.append(f); // 666
   list.append(g); // 777
   list.append(c); // 333
   list.append(i); // 999
   list.append(e); // 555
   list.append(f); // 666
   list.append(g); // 777
   list.append(h); // 888
   list.append(a); // 111
   list.append(b); // 222
   list.append(a); // 111
   list.append(d); // 444
   list.append(e); // 555
   list.append(f); // 666
   list.append(g); // 777
   list.append(h); // 888
   list.append(i); // 999
   list.append(e); // 555
   list.append(f); // 666
   list.append(g); // 777
    list.append(h); // 888

    CNDLIterator trav1(list);
    CNObject *p1;

    cout << "----------" << endl;
    cout << j1 << endl;
    
    while(p1 = trav1++)
	{
	    cout << *p1;
	    cout<< "   " ;
	    cout<< p1->object_id();
	    cout<< endl;
	}
    j1.store_on(out);
    
    a.store_on(out);
    
   list.store_on(out);
    CNReaderTbl::reset_id_tbl(); 
    
    cout << "Einlesebegin.\n";
    fstream istream("persidatenDL.dat", ios::in);
    CNPiostream in(istream);
    CNString *a2;
    CNPInt *j2;
//    CNPInt *k2;
//    CNPInt *l2;
//    CNPDouble *x2;
//    CNPDouble *y2;
//    CNPDouble *z2;
  
    
    CNPDLList *list2;
    j2 = CNPInt::read_from(in); 
    a2 = CNPString::read_from(in); 
    list2 = CNPDLList::read_from(in);
     
    CNDLIterator trav(*list2);
    CNObject *p;

    cout << "----------" << endl;
    cout << *j2 << endl;
    cout << *a2 << endl;
    
    while(p = trav++)
	cout << *p << "   " << p->object_id() << endl;


    // Delete all items
   list.delete_all();
   list.ok();
}







