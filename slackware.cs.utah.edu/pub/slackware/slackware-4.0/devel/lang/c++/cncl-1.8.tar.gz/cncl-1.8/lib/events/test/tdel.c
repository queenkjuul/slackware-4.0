// -*- C++ -*-

#include <iostream.h>

#include <CNCL/EventScheduler.h>



class TestEH : public CNEventHandler
{
  public:
    TestEH(char *n) : CNEventHandler(n) {}

    virtual void event_handler(const CNEvent *) {}
};




main()
{
    CNEventScheduler sched;
    TestEH *a, *b;

    a = new TestEH("-a-");
    b = new TestEH("-b-");
    
    sched.send_event(new CNEvent(0, a, 10));
    sched.send_event(new CNEvent(0, a, 20));
    sched.send_event(new CNEvent(0, a, 30));
    
    sched.send_event(new CNEvent(0, b, 11));
    sched.send_event(new CNEvent(0, b, 22));
    sched.send_event(new CNEvent(0, b, 33));

    sched.dump();

    sched.delete_events(a);
    
    cout << "---------------------------------------" << endl;
    
    sched.dump();
}
