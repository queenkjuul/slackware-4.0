#include <iostream.h>

#include <CNCL/SimTime.h>


int main()
{
    CNSimTime t;

    t = 10.123;

    cout << "t=" << t << endl;
    cout << "(t == 10)=" << (t == 10) << endl;

    t = 0.0001105;
    double x = t;
    
    cout << "t=" << t << endl;
    cout << "(t == 0)=" << (t == 0) << endl;
    cout << "(t == 0.)=" << (t == 0.) << endl;
    cout << "x=" << x << endl;
    cout << "(x == 0)=" << (x == 0) << endl;
}
