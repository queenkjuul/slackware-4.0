// Dialogs

#ifndef DIALOG_H
#define DIALOG_H

#include "lge.h"

class TDialog : public TWindow
{
  public:
    int     Modal;

    TDialog(int x, int y, int sizex, int sizey, char *title, int modal);
    virtual ~TDialog() {};

    virtual void Draw();
    virtual int  HandleEvent(int key);
    virtual void GetSize(int *X, int *Y);

  private:
    void	 Move();
};

typedef TDialog *PDialog;

#endif
