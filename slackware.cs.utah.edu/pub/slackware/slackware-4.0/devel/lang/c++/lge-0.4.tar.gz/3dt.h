#include<stdlib.h>
#include<stdio.h>
#include<math.h>

#include "video.h"

#ifndef TDT_H
#define TDT_H

#define zcf 220
#define cx  1
#define cy  1
#define fact_zoom 1
#define ang_mx 512 

#undef blur

typedef struct obj_3d {
  unsigned int pnbr;
  unsigned int fnbr;
        
  int rx;       
  int ry;
  int rz;
        
  int tx;
  int ty;

  float *dotx;
  float *doty;
  float *dotz;
        
  int *dotxo;
  int *dotyo;
  int *dotzo;
        
  int *dotfA;
  int *dotfB;
  int *dotfC;

  int *XNvect;
  int *YNvect;
  int *ZNvect;

  int *XNVdot;
  int *YNVdot;
  int *ZNVdot;

  int *ZiLight;
} obj_3d;

extern unsigned char    *Zcol, *Zblur;
extern int              maxX, maxY;

#ifdef __cplusplus
extern "C"
{
#endif

int  Init_3d(int ang_max); 
void Close_3d(); 
int  Mk_obj(obj_3d *obj, char name[40]);        
void Free_obj(obj_3d *obj); 
void Rotate3d(obj_3d *obj, int rx, int ry, int rz); 
void Translate(obj_3d *obj, int tx, int ty); 
void Init_buf();
void Line_GZbuf(int x1, int x2, int y, int z1, int z2, int i1, int i2); 
void Fill_GZpol(int xa, int ya, int za, int ia,
                int xb, int yb, int zb, int ib,
                int xc, int yc, int zc, int ic); 
void Mk_Nvect(obj_3d *obj);
int  Mk_NVdot(obj_3d *obj);
void Obj_size(obj_3d *obj,float fz);

#ifdef __cplusplus
}
#endif

#endif
