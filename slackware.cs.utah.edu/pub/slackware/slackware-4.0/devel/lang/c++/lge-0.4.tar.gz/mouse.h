// some useful functions from the svgalib to use the mouse

#ifndef __LGE_MOUSE_H__
#define __LGE_MOUSE_H__

#define MOUSE_LEFTBUTTON        0x01
#define MOUSE_RIGHTBUTTON       0x02
#define MOUSE_MIDDLEBUTTON      0x04
#define MOUSE_BUTTON            0x07
#define MOUSE_MOVE              0x08

extern volatile int block_mouse;

int     mouse_init();
void    mouse_close();

void    mouse_setxrange(int x1, int x2);
void    mouse_setyrange(int y1, int y2);
void    mouse_setposition(int x, int y);

int     mouse_getbutton();
int     mouse_getx();
int     mouse_gety();
int     mouse_update();

void    mouse_unblock();
void    mouse_block();

#endif


