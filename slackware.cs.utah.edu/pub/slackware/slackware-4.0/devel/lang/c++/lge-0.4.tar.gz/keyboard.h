/* Gere le clavier en mode raw */

#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <stdio.h>
#include "vgakeyboard.h"

#define NOK     '\0'

extern int      fshift, falt, fctrl, caps;

int  InitKey(char *name);
char GetChar();
int  update_key();
void CloseKey();

#endif
