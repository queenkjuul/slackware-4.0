/* Definition des routines d'affichage des elements visuels */

#ifndef VISUAL_H
#define VISUAL_H

#include "video.h"

#define FALSE 0
#define TRUE  1

extern  FontPtr SystemFont, SmallFont;

void InitVisual();
int  StrWidth(FontPtr font, char *Chaine);
void DrawButton(int x, int y, int xsize, int ysize, char *Title, int Pressed, int Actif, FontPtr font, int style, int handle);
void DrawWindow(int x, int y, int xsize, int ysize, char *Title, int Actif, int BackG, int handle);
void DrawDialog(int x, int y, int xsize, int ysize, char *Title, int Actif, int handle);
void DrawZone(int x, int y, int xsize, int ysize, int color, int handle);
void DrawRndZone(int x, int y, int color, int handle);
void DrawBlock(int x, int y, int xsize, int ysize, int handle);

#endif
