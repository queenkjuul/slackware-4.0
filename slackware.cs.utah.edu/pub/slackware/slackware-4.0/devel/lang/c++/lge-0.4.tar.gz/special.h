// Here are defined LGE's special objects such as canvas or 3d world

#ifndef SPECIAL_H
#define SPECIAL_H

#include "control.h"
#include "3dt.h"

// T3d : 3d world

class T3d : public TObject
{
  public:
    obj_3d      obj;

    T3d(int x, int y, int sizex, int sizey, int backcol, char *name, float fact);
    ~T3d();

    virtual void Zoom(float fact);
    virtual void Draw();
    virtual int  HandleEvent(int key);
    virtual void DoTask();
    
  private:
    int         SizeX, SizeY, BackColor;
};

typedef T3d     *P3d;

#endif
