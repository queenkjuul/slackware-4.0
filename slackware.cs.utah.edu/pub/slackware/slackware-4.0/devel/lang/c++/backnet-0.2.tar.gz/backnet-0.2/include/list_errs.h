/* list_errs.h

   Errors for the ListManagement.
   (Derived from the testversion of net_errs.h.)

   Author: Marko Meyer
   Date:   10.05.1995 (creation)
           10.05.1995 (last modification)

   This file belongs to the library BACKNET.
   It is Copyright (C) 1995 Marko Meyer.
   Please read the files README, doc/LICENSE and doc/DISCLAIMER.
   If you miss one of these files, please contact me:

   Email: mme@pub.th-zwickau.de
   Ordinary Mail: Marko Meyer
                  Teichstrasse 27
				  D-08289 Schneeberg
				  Germany


*/

#ifndef _LIST_ERRORS_
#define _LIST_ERRORS_

#define NO_ERROR 0    /*No error.*/
#define NO_LIST  1    /*No list.*/
#define NO_ELEM  2    /*No element.*/
#define ERR_MEMORY_LIST 3  /* Not enough memory to handle.*/
#define LIST_EXISTS 4  /* List exists.*/
#define ELEM_EXISTS 5  /* Element exists.*/
#define ERR_NOELEM_LIST 6  /* Specified element doesn't exist.*/
#define ERR_OVERFL_LIST 7  /* No more free listnodes.*/
#define ERR_LNOTEX_LIST 8 /*List was broken.*/
#define ERR_INPVAL_LIST 9 /* Wrong input value in call to ArrMan func. */
#define ERR_NOPERM_LIST 10 /* Wrong permissions for desired action. */

#endif /*_LIST_ERRORS_*/
