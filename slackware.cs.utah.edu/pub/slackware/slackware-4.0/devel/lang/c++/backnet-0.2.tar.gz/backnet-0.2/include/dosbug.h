/* dosbug.h 
   
   Author: Marko Meyer
   Date:   95/11/30 (creation)
   Time-stamp: <95/11/30 14:24:27 mme>

   This is just for converting some x.y includes to 8.3 ones.

	BACKNET - A library for simulating neural BACKPROPAGATION-Networks
    Copyright (C) 1995	Marko Meyer

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


	If you have any suggestions, ideas or comments regarding this library
	feel free to contact me:

	Email:	mme@pub.th-zwickau.de
	Ordinary Mail:	Marko Meyer
					Teichstrasse 27
					D-08289 Schneeberg
                    Germany

	History:
	
	95/11/30 -- Marko Meyer: created this header; 
                inspired by Carsten Dinkelmann (din@pub.th-zwickau.de)
                Thanks!

*/

#ifndef _DOSBUG_H_
#define _DOSBUG_H_

#ifdef __BORLANDC__
#define __LISTMAN__ <listman-.h>
#define __MM_L_AA__ <l_autoas.h>
#define __MM_N_AA__ <n_autoas.h>
#define __MM_NNAA__ <nn_autoa.h>
#define __RS_N_AA__ <neuron_a.h>
#define __NN_FAST__ <nnet_fas.h>
#define __LIST_ER__ <list_err.h>
#else
#define __LISTMAN__ <listman-t.h>
#define __MM_L_AA__ <l_autoass.h>
#define __MM_N_AA__ <n_autoass.h>
#define __MM_NNAA__ <nn_autoass.h>
#define __RS_N_AA__ <neuron_aa.h>
#define __NN_FAST__ <nnet_fast.h>
#define __LIST_ER__ <list_errs.h>
#endif /* __BORLANDC__ */
#endif /* _DOSBUG_H_*/

