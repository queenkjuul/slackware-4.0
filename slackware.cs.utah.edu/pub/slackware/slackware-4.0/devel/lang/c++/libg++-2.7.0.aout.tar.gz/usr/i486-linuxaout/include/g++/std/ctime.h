// The -*- C++ -*- time header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CTIME__
#define __CTIME__
#include <time.h>
#endif
