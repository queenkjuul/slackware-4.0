// The -*- C++ -*- ISO 646 header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CISO646__
#define __CISO646__
#include <iso646.h>
#endif
