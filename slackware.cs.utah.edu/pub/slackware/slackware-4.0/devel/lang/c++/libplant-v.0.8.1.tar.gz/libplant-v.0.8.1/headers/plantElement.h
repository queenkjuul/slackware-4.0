#ifndef _PLANTELEMENT_H
#define _PLANTELEMENT_H
#define PLANTELMNAME "plantElement"
#define PLANTELMVERS "v.0.8.1"
#define PLANTELMAUTH "a.cella (cella@marvin.conecta.it)"
#define PLANTELMDATE "25 jun 96"

#include <iostream.h>
#include <String.h>

class plantElement
{
 public:
  plantElement(String name="no name",int id=0) { if(id) elementID=id; if(name) elementName=name;};
  virtual ~plantElement() {};
  
  virtual String getVersion()=0;
  virtual int getID() { return elementID; };
  virtual String getName() { return elementName; };

  virtual double power()=0;

 protected:
  int elementID;
  String elementName;
};
#endif

