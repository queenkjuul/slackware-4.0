#ifndef __COMPRESS_H
#define __COMPRESS_H
#define COMPRNAME "compressor"
#define COMPRVERS "v.0.8.1"
#define COMPRDATE "25 jun 96"
#define COMPRAUTH "a.cella (cella@marvin.conecta.it)"

#ifndef _TURBOMAC_H
#include "turbomac.h"
#endif

#include <String.h>

class compressor : 
public turbomac 
{
public:
  compressor(String name="default compressor", int id=0);
  ~compressor() {};
  double power();
  double getOutletT();

  String getVersion();

private:
  double estimOutletT(double T1, double K);
  double estimMm1OverM(double T1, double T2);
};

#endif

