#ifndef _TURBINE_H
#define _TURBINE_H
#define TURBINNAME "turbine"
#define TURBINVERS "v.0.8.1"
#define TURBINDATE "25 jun 96"
#define TURBINAUTH "a.cella (cella@marvin.conecta.it)"

#ifndef _TURBOMAC_H
#include "turbomac.h"
#endif

#include <String.h>

class turbine : 
public turbomac 
{
public:
  turbine(String name="default turbine", int id=0);
  ~turbine() {};
  double power();
  double getOutletT();

  String getVersion();

private:
  double estimOutletT(double T1, double K);
  double estimMm1OverM(double T1, double T2);
};

#endif


