// Multiplexor.cpp
#if defined (ACE_HAS_THREADS)

#define ACE_BUILD_DLL
#include "ace/Multiplexor.h"

#if !defined (__ACE_INLINE__)
#include "ace/Multiplexor.i"
#endif /* __ACE_INLINE__ */

#endif /* ACE_HAS_THREADS */
