// Method_Object.cpp
#define ACE_BUILD_DLL
#include "ace/Method_Object.h"

ACE_Method_Object::ACE_Method_Object (void) 
{
}

ACE_Method_Object::~ACE_Method_Object (void)
{
}

