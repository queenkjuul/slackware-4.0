// SOCK_Stream.cpp
#define ACE_BUILD_DLL
#include "ace/SOCK_Stream.h"

ACE_ALLOC_HOOK_DEFINE(ACE_SOCK_Stream)

void
ACE_SOCK_Stream::dump (void) const
{
  ACE_TRACE ("ACE_SOCK_Stream::dump");
}



