#include "ace/OS.h"

static const char *rendezvous = ACE_DEFAULT_RENDEZVOUS;
