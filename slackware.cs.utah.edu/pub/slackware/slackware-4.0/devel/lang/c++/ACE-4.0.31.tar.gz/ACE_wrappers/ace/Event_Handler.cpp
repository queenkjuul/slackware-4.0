// Event_Handler.cpp
#define ACE_BUILD_DLL
#include "ace/Event_Handler.h"
#include "ace/Message_Block.h"

#if !defined (__ACE_INLINE__)
#include "ace/Event_Handler.i"
#endif /* __ACE_INLINE__ */

