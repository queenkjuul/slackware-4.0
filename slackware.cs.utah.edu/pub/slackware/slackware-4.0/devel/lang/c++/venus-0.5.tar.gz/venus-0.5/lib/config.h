/*
 * config.h
 *
 * Copyright (C) 1996 Sergio Sigala <ssigala@globalnet.it>
 *
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation.
 *
 * SERGIO SIGALA DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL SERGIO SIGALA BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF
 * USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
 * OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <stdio.h>

#define CONFIG_MAXLEN	128

class Config
{
protected:
	FILE *stream;
public:
	Config();
	virtual ~Config();
	virtual int getField(char *section, char *field, char *value,
		int &line);
	virtual int getFlag(char *section, char *field, int *flag);
	virtual int getInt(char *section, char *field, int *num);
	virtual int getStr(char *section, char *field, char *str);
	virtual int getToken(char *buf, int &line);
	virtual void openConfig(char *fname);
};

#endif
