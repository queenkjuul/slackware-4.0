This directory contains contributions from V users.
Because of system limitations, I have not been able
to personally verify that these contributions work
as advertised. Generally, each contribution will
include a .txt file that will describe it. Some
contributions may be tarred. To date, this
directory contains the following:

------------------------------------------------------------
msvc.tar is a tar of the /v/msvc directory.  It contains makefiles to
build the library and test apps for MSVC 2.0. It should be portable
on NT platforms using NMAKE and MSVC.

Mike
mike@cs.pdx.edu
------------------------------------------------------------

