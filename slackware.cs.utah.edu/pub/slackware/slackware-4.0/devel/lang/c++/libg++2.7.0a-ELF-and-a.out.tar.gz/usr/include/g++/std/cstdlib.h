// The -*- C++ -*- standard library header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CSTDLIB__
#define __CSTDLIB__
#include <stdlib.h>
#endif
