// The -*- C++ -*- ISO 646 header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CISO646__
#define __CISO646__
#include <iso646.h>

#if 0
// once g++ treats these as keywords...
#undef and
#undef and_eq
#undef bitand
#undef bitor
#undef compl
#undef not_eq
#undef not
#undef or
#undef or_eq
#undef xor
#undef xor_eq
#endif

#endif
