// The -*- C++ -*- integral type limits header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CLIMITS__
#define __CLIMITS__
#include <limits.h>
#endif
