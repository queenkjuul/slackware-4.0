// The -*- C++ -*- math functions header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CMATH__
#define __CMATH__
#include <math.h>
#endif
