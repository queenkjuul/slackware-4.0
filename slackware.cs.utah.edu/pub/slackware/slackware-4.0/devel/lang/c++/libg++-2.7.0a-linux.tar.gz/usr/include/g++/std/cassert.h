// The -*- C++ -*- assertions header.
// This file is part of the GNU ANSI C++ Library.

#include <assert.h>
