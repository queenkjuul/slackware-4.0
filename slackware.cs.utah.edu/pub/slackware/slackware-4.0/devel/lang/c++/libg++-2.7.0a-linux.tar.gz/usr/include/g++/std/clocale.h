// The -*- C++ -*- locale support header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CLOCALE__
#define __CLOCALE__
#include <locale.h>
#endif
