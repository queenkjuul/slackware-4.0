/*
 *	fhist - file history and comparison tools
 *	Copyright (C) 1993, 1994, 1998 Peter Miller;
 *	All rights reserved.
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111, USA.
 *
 * MANIFEST: interface definition for fmerge/work.c
 */

#ifndef WORK_H
#define WORK_H

#include <main.h>

extern long conflicts;		/* number of conflicts */
extern long failcount;		/* maximum conflicts allowable */
extern long unchangecount;	/* maximum unchanged lines to output */
extern short ignoreflag;	/* ignore conflicts */

void fmerge _((char *base_name, char *nameA, char *nameB));
void dumpmergedfile _((char *outname));
void dumpconflicts _((char *outname));
void convertconflicts _((char *inname, char *outname));

#endif /* WORK_H */
