#!/bin/sh
#
#	fhist - file history and comparison tools
#	Copyright (C) 1994, 1998 Peter Miller;
#	All rights reserved.
#
#	This program is free software; you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation; either version 2 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program; if not, write to the Free Software
#	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111, USA.
#
# MANIFEST: Test the fhist -cr -u functionality
#

work=/tmp/$$
PAGER=cat
export PAGER

fail()
{
	set +x
	echo FAILED test of the fhist -cr -u functionality 1>&2
	cd $here
	rm -rf $work
	exit 1
}
pass()
{
	set +x
	echo PASSED 1>&2
	cd $here
	rm -rf $work
	exit 0
}
trap "fail" 1 2 3 15

here=`pwd`
if test $? -ne 0 ; then exit 1; fi
mkdir $work
if test $? -ne 0 ; then exit 1; fi
cd $work
if test $? -ne 0 ; then fail; fi

if [ "$1" != "" ]; then bin=$here/$1/bin; else bin=$here/bin; fi

#
# create the history storage directory
#
mkdir FHIST
if test $? -ne 0 ; then fail; fi

#
# create a file to chew on
#
cat > fred << 'fubar'
This is just a test
fubar

#
# create the history
#
$bin/fhist fred -cr -u -v 0 -rem
if test $? -ne 0 ; then fail; fi

#
# now do another rev
#
cat > fred << 'fubar'
This is just a test
to see if
fubar

#
# add to the history
#
$bin/fhist fred -u -cr -v 0 -rem
if test $? -ne 0 ; then fail; fi

#
# list the history
#
$bin/fhist fred -list 2>&1 | sed -e 's/:.*/:/' > test.out
if test $? -ne 0 ; then fail; fi

cat > test.ok << 'fubar'
Module "fred":
Edit 2:

Edit 1:
fubar
if test $? -ne 0 ; then fail; fi

diff test.ok test.out
if test $? -ne 0 ; then fail; fi

#
# Only definite negatives are possible.
# The functionality exercised by this test appears to work,
# no other guarantees are made.
#
pass
