/*
 *	fhist - file history and comparison tools
 *	Copyright (C) 1998 Peter Miller;
 *	All rights reserved.
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111, USA.
 *
 * MANIFEST: functions to implement missing ANSI C functions
 */

#include <ac/unistd.h>


#ifndef HAVE_RENAME

/*
 * Routine to rename files using link and unlink.
 * Returns -1 on failure.
 */

int
rename(oldname, newname)
	char	*oldname;		/* old file name */
	char	*newname;		/* new file name */
{
	if (link(oldname, newname) < 0)
		return -1;
	if (unlink(oldname) < 0) {
		unlink(newname);
		return -1;
	}
	return 0;
}

#endif
