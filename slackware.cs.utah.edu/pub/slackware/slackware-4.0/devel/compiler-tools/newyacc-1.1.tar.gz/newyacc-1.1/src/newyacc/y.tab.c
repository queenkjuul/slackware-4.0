#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 2 "newyacc.y"

#include <stdio.h>
#include "nymem.h"

#define YYMAXDEPTH 250
#define LONGALLONES -1

extern char *malloc();
extern FILE *ny_out;

struct ny_displayitem {
  struct ny_displayitem *left,*right;
  char *tok;
  long mask;
};

typedef enum { ny_assign, ny_concat } ny_AssignType;
typedef enum { ny_empty, ny_terminal, ny_nonTerminal } ny_TokenType;
typedef enum { ny_passThru, ny_newMask } ny_TraversalType;
typedef enum {
	ny_normal = 0,
	ny_readunion = 1,
	ny_readdefs = 2,
	ny_readaction = 3,
	ny_readtail = 4
} ny_LexModeType;
typedef enum { ny_selective=0, ny_openr=1 } ny_TreeType;

ny_LexModeType ny_mode=ny_normal;
int ny_rhscount;
char ny_bounce=1, ny_action=0, ny_codeFound=0, ny_white=0, ny_displays=0;
long ny_curdisplay=0, ny_curmask=0, ny_gdisplay=1, ny_inasg=0, ny_incall=0;
long sf_incall[YYMAXDEPTH],sf_incallp=0;
long ny_nargs[YYMAXDEPTH],ny_nargsp=0;
ny_TreeType ny_ptype=ny_openr;
char *ny_ritem,*ny_callp;
ny_AssignType ny_asg=ny_assign;
ny_TraversalType ny_nmask=ny_passThru;

#line 56 "newyacc.y"
typedef union {
	char *str;
	int num;
} YYSTYPE;
#line 57 "y.tab.c"
#define IDENTIFIER 257
#define C_IDENTIFIER 258
#define START 259
#define UNION 260
#define LCURL 261
#define RCURL 262
#define TOKEN 263
#define TAG 264
#define TAB 265
#define TABINC 266
#define TABDEC 267
#define RWORD 268
#define NUMBER 269
#define CONCAT 270
#define ASSIGN 271
#define LSQUIGGLY 272
#define RSQUIGGLY 273
#define STAR 274
#define MARK 275
#define PREC 276
#define ERROR 277
#define LITERAL 278
#define VBAR 279
#define SEMICOLON 280
#define IF 281
#define THEN 282
#define ELSE 283
#define EQUAL 284
#define NOTEQUAL 285
#define ANDAND 286
#define OROR 287
#define NOT 288
#define STRING 289
#define DEFSBODY 290
#define TAILBODY 291
#define ACTIONBODY 292
#define UNIONBODY 293
#define SELECTIVEITEM 294
#define OPENITEM 295
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    9,    0,   10,   11,   10,    7,    7,   12,   13,   14,
   12,   15,   16,   12,   12,   17,   17,   17,   18,   18,
   19,   19,   19,   20,   20,   20,   20,   22,    8,    8,
   25,   24,   26,   24,   21,   27,   21,   28,   21,   29,
   21,   21,   31,   32,   30,   33,   33,   36,   34,    6,
    6,   35,   37,   37,   39,   39,   41,   39,   38,   38,
   38,   38,   38,   43,   43,   46,   47,   44,   48,   45,
   49,   45,   45,   50,   52,   42,   53,   54,   42,   51,
   55,   51,   40,   56,   40,   40,   40,   40,    1,    3,
    4,    4,    4,    4,    2,    2,    2,    5,    5,   23,
   23,   23,   23,
};
short yylen[] = {                                         2,
    0,    5,    0,    0,    3,    0,    2,    2,    0,    0,
    6,    0,    0,    5,    3,    1,    1,    1,    0,    3,
    1,    2,    3,    1,    1,    1,    2,    0,    4,    2,
    0,    4,    0,    4,    0,    0,    3,    0,    3,    0,
    3,    2,    0,    0,    5,    0,    2,    0,    5,    0,
    3,    2,    0,    3,    0,    1,    0,    4,    0,    4,
    2,    2,    2,    1,    5,    0,    0,    8,    0,    4,
    0,    4,    3,    0,    0,    5,    0,    0,    5,    1,
    0,    4,    1,    0,    5,    1,    1,    1,    2,    2,
    1,    1,    4,    4,    0,    1,    1,    1,    3,    1,
    1,    3,    2,
};
short yydefred[] = {                                      0,
    0,    0,   12,   16,   17,   18,    0,    0,    0,    0,
    8,    9,    0,    1,    7,    0,    0,    0,   13,    0,
    0,    0,   24,   25,   15,    0,   10,    0,   28,    0,
   20,   27,    0,   22,    0,   14,   35,   31,    4,   33,
    2,   30,   23,   11,    0,   35,    0,   35,   43,    0,
    0,    0,    0,    0,   42,    0,    0,    5,    0,    0,
   46,  103,   37,   39,   41,    0,   47,    0,    0,   44,
    0,    0,   48,    0,   98,   96,    0,    0,   53,   45,
   51,    0,    0,    0,   99,   49,    0,    0,   54,   84,
   53,   66,   83,    0,    0,    0,    0,    0,   87,   86,
   63,   61,   62,    0,    0,    0,    0,    0,    0,   89,
   90,    0,    0,    0,    0,   60,    0,   88,    0,   67,
    0,    0,   75,   78,   53,    0,   56,    0,   69,   71,
    0,   93,   94,    0,    0,    0,   57,   85,   73,    0,
    0,    0,   80,    0,    0,   65,    0,   70,   72,   53,
   81,   58,    0,    0,   68,   82,
};
short yydgoto[] = {                                       7,
  118,   77,   99,  100,   78,   73,    8,   30,   20,   41,
   47,    9,   18,   35,   13,   28,   10,   17,   25,   26,
   45,   37,   51,   42,   46,   48,   52,   53,   54,   55,
   60,   74,   56,   67,   83,   79,   84,   88,  126,  119,
  147,  102,  103,  104,  120,  107,  131,  140,  141,  112,
  144,  134,  113,  135,  154,  105,
};
short yysindex[] = {                                   -157,
 -236, -239,    0,    0,    0,    0,    0, -230, -157,  -20,
    0,    0, -233,    0,    0, -206, -246, -232,    0, -200,
    6, -207,    0,    0,    0,  -38,    0, -197,    0, -238,
    0,    0, -246,    0, -204,    0,    0,    0,    0,    0,
    0,    0,    0,    0, -258,    0, -221,    0,    0, -201,
 -208, -183, -203, -213,    0,  -13, -258,    0, -258, -211,
    0,    0,    0,    0,    0,   42,    0, -208, -208,    0,
  -13, -244,    0, -190,    0,    0,   43,   44,    0,    0,
    0, -166,   15,   60,    0,    0, -161,  141,    0,    0,
    0,    0,    0,   59,   65, -148, -256,    0,    0,    0,
    0,    0,    0, -173,   72, -160,  -40, -244, -244,    0,
    0, -156, -154, -158,  -48,    0,  -40,    0, -235,    0,
   76,   78,    0,    0,    0,  -19,    0,   79,    0,    0,
 -159,    0,    0,  -48,  -48, -152,    0,    0,    0,  -48,
  -48, -150,    0,   81,   81,    0,  -48,    0,    0,    0,
    0,    0, -147,  -48,    0,    0,
};
short yyrindex[] = {                                   -145,
    0,    0,    0,    0,    0,    0,    0,    0, -145, -242,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  -39,    0,    0,    0, -174,    0,    0,    0,  125,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    1,    0,    0,    0,    0,    3,
   19,    0,    0,    0,    0,    9,    1,    0,    1,    0,
    0,    0,    0,    0,    0,  -29,    0,   27,   28,    0,
   12,   86,    0,    0,    0,    0,    0,   90,    0,    0,
    0,    0,    0,   84,    0,    0,    0,  -91,    0,    0,
    0,    0,    0,   36,   54,    0,    0,   80,    0,    0,
    0,    0,    0,   87,    0,    0,    0,   86,   86,    0,
    0,    0,    0,    0,  -18,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  114,  134,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,
};
short yygindex[] = {                                      0,
   45,  -53,    0,   35,    0,    0,  126,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  -16,    0,
  -17,    0,  -11,    0,    0,    0,    0,    0,    0,   88,
    0,    0,   73,    0,  -83,    0,    0,    0,    0,  -81,
    0,    0,    0,    0,   20,    0,    0,    0,    0,    0,
    4,    0,    0,    0,    0,    0,
};
#define YYTABLESIZE 436
short yytable[] = {                                     117,
   46,   52,  101,   50,   26,   33,  101,  106,  100,   34,
   22,  102,   75,   49,   19,   96,   43,   50,   29,   38,
   11,  138,   55,   96,  137,   55,   32,   34,   57,   76,
   59,   23,   12,  127,   50,   19,   39,   94,   95,   16,
   40,  136,   24,   97,   14,   68,   19,   69,  129,  130,
   21,   97,  143,  143,  121,  122,   19,   29,  148,  149,
   27,   32,   50,   50,   36,  152,  153,   31,   44,   58,
   49,   62,  156,   63,   64,   65,   91,   66,   91,   91,
   70,   72,   80,   81,   21,   21,   21,   82,   21,   21,
   85,   46,   87,   21,   92,   89,   92,   92,  108,   91,
   21,    1,    2,    3,  109,    4,    5,   86,  110,  114,
    6,  115,  116,  125,  123,  124,  132,   92,  133,  139,
  146,  150,  142,  151,    3,  155,   95,   91,   91,    6,
   97,  111,   98,   71,   15,    0,  128,   61,  145,    0,
    0,    0,    0,   88,    0,   92,   92,   59,    0,    0,
   64,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,   88,   88,    0,    0,   59,   59,   76,   64,   64,
    0,   52,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,   79,    0,    0,
    0,    0,    0,    0,   96,   76,   76,    0,   90,    0,
    0,    0,    0,    0,    0,    0,   90,   26,   22,   26,
   26,   26,    0,   26,   26,   79,   79,   50,   26,    0,
    0,    0,   97,    0,    0,   26,    0,    0,   26,   23,
   93,    0,   50,    0,    0,   94,   95,    0,   93,   26,
   24,   50,    0,   94,   95,    0,    0,   36,   46,   50,
  101,    0,    0,    0,   50,   50,  100,    0,    0,  102,
    0,    0,    0,    0,    0,   46,   29,  101,   38,   46,
   46,  101,  101,  100,   32,   34,  102,  100,  100,   40,
  102,  102,   91,   29,    0,    0,    0,   29,    0,    0,
    0,   32,   34,    0,    0,   32,   34,   91,   91,    0,
   92,    0,    0,    0,    0,    0,   91,   91,    0,   91,
   91,    0,    0,    0,   91,   92,   92,    0,    0,   91,
   91,    0,    0,    0,   92,   92,   88,   92,   92,    0,
   59,    0,   92,   64,    0,    0,    0,   92,   92,   77,
   74,   88,   88,    0,    0,   59,   59,    0,   64,   64,
   88,    0,    0,    0,   59,    0,    0,   64,   88,    0,
   76,    0,   59,   88,   88,   64,    0,   59,   59,    0,
   64,   64,    0,    0,    0,   76,   76,    0,    0,    0,
   79,    0,    0,    0,   76,    0,    0,   90,    0,    0,
    0,    0,   76,    0,    0,   79,   79,   76,   76,    0,
    0,    0,   91,    0,   79,    0,    0,    0,    0,    0,
    0,   92,   79,    0,    0,    0,    0,   79,   79,   93,
    0,    0,    0,    0,   94,   95,
};
short yycheck[] = {                                      40,
    0,   93,    0,   33,   44,   44,   88,   91,    0,   26,
  257,    0,  257,  272,  257,   64,   33,  276,    0,  258,
  257,   41,   41,   64,   44,   44,    0,    0,   46,  274,
   48,  278,  272,  115,   64,  278,  275,  294,  295,   60,
  279,  125,  289,   92,  275,   57,  289,   59,  284,  285,
  257,   92,  134,  135,  108,  109,  290,  258,  140,  141,
  293,  269,   92,   93,  262,  147,  150,   62,  273,  291,
  272,  280,  154,  257,  278,  289,   41,   91,   43,   44,
  292,   40,  273,   41,  259,  260,  261,   44,  263,  264,
  257,   91,   33,  268,   41,  257,   43,   44,   40,   64,
  275,  259,  260,  261,   40,  263,  264,   93,  257,  283,
  268,   40,  273,  272,  271,  270,   41,   64,   41,   41,
  273,  272,  282,   43,    0,  273,   41,   92,   93,  275,
   41,   97,   88,   61,    9,   -1,  117,   50,  135,   -1,
   -1,   -1,   -1,   64,   -1,   92,   93,   64,   -1,   -1,
   64,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   92,   93,   -1,   -1,   92,   93,   64,   92,   93,
   -1,  273,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   64,   -1,   -1,
   -1,   -1,   -1,   -1,   64,   92,   93,   -1,  257,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  257,  257,  257,  259,
  260,  261,   -1,  263,  264,   92,   93,  257,  268,   -1,
   -1,   -1,   92,   -1,   -1,  275,   -1,   -1,  278,  278,
  289,   -1,  272,   -1,   -1,  294,  295,   -1,  289,  289,
  289,  281,   -1,  294,  295,   -1,   -1,  257,  258,  289,
  258,   -1,   -1,   -1,  294,  295,  258,   -1,   -1,  258,
   -1,   -1,   -1,   -1,   -1,  275,  258,  275,  278,  279,
  280,  279,  280,  275,  258,  258,  275,  279,  280,  289,
  279,  280,  257,  275,   -1,   -1,   -1,  279,   -1,   -1,
   -1,  275,  275,   -1,   -1,  279,  279,  272,  273,   -1,
  257,   -1,   -1,   -1,   -1,   -1,  281,  282,   -1,  284,
  285,   -1,   -1,   -1,  289,  272,  273,   -1,   -1,  294,
  295,   -1,   -1,   -1,  281,  282,  257,  284,  285,   -1,
  257,   -1,  289,  257,   -1,   -1,   -1,  294,  295,  270,
  271,  272,  273,   -1,   -1,  272,  273,   -1,  272,  273,
  281,   -1,   -1,   -1,  281,   -1,   -1,  281,  289,   -1,
  257,   -1,  289,  294,  295,  289,   -1,  294,  295,   -1,
  294,  295,   -1,   -1,   -1,  272,  273,   -1,   -1,   -1,
  257,   -1,   -1,   -1,  281,   -1,   -1,  257,   -1,   -1,
   -1,   -1,  289,   -1,   -1,  272,  273,  294,  295,   -1,
   -1,   -1,  272,   -1,  281,   -1,   -1,   -1,   -1,   -1,
   -1,  281,  289,   -1,   -1,   -1,   -1,  294,  295,  289,
   -1,   -1,   -1,   -1,  294,  295,
};
#define YYFINAL 7
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 295
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
"'!'",0,0,0,0,0,0,"'('","')'",0,"'+'","','",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'<'",
0,"'>'",0,"'@'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'['",
"'\\\\'","']'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,"IDENTIFIER","C_IDENTIFIER","START","UNION","LCURL",
"RCURL","TOKEN","TAG","TAB","TABINC","TABDEC","RWORD","NUMBER","CONCAT",
"ASSIGN","LSQUIGGLY","RSQUIGGLY","STAR","MARK","PREC","ERROR","LITERAL","VBAR",
"SEMICOLON","IF","THEN","ELSE","EQUAL","NOTEQUAL","ANDAND","OROR","NOT",
"STRING","DEFSBODY","TAILBODY","ACTIONBODY","UNIONBODY","SELECTIVEITEM",
"OPENITEM",
};
char *yyrule[] = {
"$accept : spec",
"$$1 :",
"spec : defs MARK $$1 rules tail",
"tail :",
"$$2 :",
"tail : MARK $$2 TAILBODY",
"defs :",
"defs : def defs",
"def : START IDENTIFIER",
"$$3 :",
"$$4 :",
"def : UNION LSQUIGGLY $$3 UNIONBODY $$4 RSQUIGGLY",
"$$5 :",
"$$6 :",
"def : LCURL $$5 DEFSBODY $$6 RCURL",
"def : rword tag nlist",
"rword : TOKEN",
"rword : TAG",
"rword : RWORD",
"tag :",
"tag : '<' IDENTIFIER '>'",
"nlist : nmno",
"nlist : nmno nlist",
"nlist : nmno ',' nlist",
"nmno : LITERAL",
"nmno : STRING",
"nmno : IDENTIFIER",
"nmno : IDENTIFIER NUMBER",
"$$7 :",
"rules : C_IDENTIFIER $$7 rbody prec",
"rules : rules rule",
"$$8 :",
"rule : C_IDENTIFIER $$8 rbody prec",
"$$9 :",
"rule : VBAR $$9 rbody prec",
"rbody :",
"$$10 :",
"rbody : rbody $$10 IDENTIFIER",
"$$11 :",
"rbody : rbody $$11 LITERAL",
"$$12 :",
"rbody : rbody $$12 STRING",
"rbody : rbody act",
"$$13 :",
"$$14 :",
"act : LSQUIGGLY $$13 ACTIONBODY $$14 RSQUIGGLY",
"transl :",
"transl : transl trans",
"$$15 :",
"trans : '[' display $$15 scope ']'",
"display :",
"display : '(' masks ')'",
"scope : odecls tbody",
"odecls :",
"odecls : odecls '!' IDENTIFIER",
"argl :",
"argl : tbitem",
"$$16 :",
"argl : argl ',' $$16 tbitem",
"tbody :",
"tbody : tbody LSQUIGGLY scope RSQUIGGLY",
"tbody : tbody assign",
"tbody : tbody cond",
"tbody : tbody tbitem",
"cond : ifpref",
"cond : ifpref ELSE LSQUIGGLY scope RSQUIGGLY",
"$$17 :",
"$$18 :",
"ifpref : IF $$17 bexp $$18 THEN LSQUIGGLY scope RSQUIGGLY",
"$$19 :",
"bexp : tbitem EQUAL $$19 tbitem",
"$$20 :",
"bexp : tbitem NOTEQUAL $$20 tbitem",
"bexp : '(' bexp ')'",
"$$21 :",
"$$22 :",
"assign : refitem $$21 ASSIGN $$22 exp",
"$$23 :",
"$$24 :",
"assign : refitem $$23 CONCAT $$24 exp",
"exp : tbitem",
"$$25 :",
"exp : exp '+' $$25 tbitem",
"tbitem : STRING",
"$$26 :",
"tbitem : IDENTIFIER $$26 '(' argl ')'",
"tbitem : sitem",
"tbitem : fitem",
"tbitem : refitem",
"refitem : '@' IDENTIFIER",
"fitem : '\\\\' sitem",
"sitem : SELECTIVEITEM",
"sitem : OPENITEM",
"sitem : SELECTIVEITEM '(' masks ')'",
"sitem : OPENITEM '(' masks ')'",
"masks :",
"masks : STAR",
"masks : maskl",
"maskl : IDENTIFIER",
"maskl : maskl ',' IDENTIFIER",
"prec : transl",
"prec : PREC",
"prec : PREC act transl",
"prec : prec SEMICOLON",
};
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 333 "newyacc.y"

#include "headerlex.yy.c"
#define	TRUE	1
#define	FALSE	0

yylex()
{
  switch(ny_mode) {
    case ny_normal: return(headeryylex()); break;
    case ny_readunion:
      if (ny__echo("}","{")) return(UNIONBODY); break;
    case ny_readdefs:
      if (ny__echo("%}",NULL)) return(DEFSBODY); break;
    case ny_readaction:
      if (ny__echo("}","{")) return(ACTIONBODY); break;
    case ny_readtail:
      if (ny__echo(NULL,NULL)) return(TAILBODY); break;
    default: return(ERROR);
  }
  return(ERROR);
}

int ny_seen = 0;
int ny_level = 0;
ny__ilookahead(str)
char *str;
{
  char c;

  if(str == NULL) return(0);
  if(str[0] == '\0') return(1);
  if(((c = input()) != EOF) && (c == str[0])) {
    if(ny__ilookahead(str+1)) {
      unput(c); return(1);
    } else unput(c); ny_seen++; return(0);
  } else if(c != EOF) {
    unput(c); ny_seen++; return(0);
  } else return(0);
}

ny__lookahead(c,str)
char c;
char *str;
{
  if(str == NULL) return(0);
  if(str[0] == '\0') return(1);
  if(ny_seen > 0) {
    ny_seen--; return(0);
  }
  if(c == str[0]) {
    return(ny__ilookahead(str+1));
  }
  return(0);
}

ny__echo(str,bal)
char *str,*bal;
{
  char ch,escapeon=FALSE,quoteon=FALSE,comment=FALSE,ans=FALSE;

  if((str != NULL) && (str[0] == '\0')) return(1);
  while((ch = input()) != 0) {
    ans = FALSE;
    if(!quoteon && !comment && (bal != NULL) && (ch == bal[0])) {
      ny_level++;
    }
    if(!quoteon && !comment && (ans = ny__lookahead(ch,str)) && (ny_level == 0)) {
      unput(ch); break;
    } else if(ans) {
      ny_level--;
    }
    if(escapeon) {
      escapeon = FALSE; fputc(ch,ny_out);
    } else if(str != NULL) {
      switch(ch) {
	case '/':
          if(!quoteon && !comment) {
            if((ch = input()) == '*') {
              comment = TRUE; fputc('/',ny_out);
            } else { unput(ch); ch = '/'; }
          }
          fputc(ch,ny_out);
          break;
        case '*':
          if(!quoteon && comment) {
            if((ch = input()) == '/') {
              comment = FALSE; fputc('*',ny_out);
            } else { unput(ch); ch = '*'; }
          }
          fputc(ch,ny_out);
          break;
        case '\\':
          if(quoteon && !comment) escapeon = TRUE;
          fputc(ch,ny_out);
          break;
        case '\"':
          if(!comment) quoteon = !quoteon;
          fputc(ch,ny_out);
          break;
        default: fputc(ch,ny_out);
      }
    } else fputc(ch,ny_out);
  }
  if(ch == 0 && str != NULL) return(0);
  return(1);
}

yyerror()
{
  /* fprintf(stderr,"newyacc: syntax error on line %d\n", yylineno); */
  fprintf(stderr,"newyacc: syntax error on line \n");
  exit(1);
}

struct ny_displayitem *ny_displaytree = NULL;

ny_AddDisplay(s,f)
char *s;
int f;
{
  int r;
  struct ny_displayitem *t,*l;

  t=ny_displaytree;l=ny_displaytree;
  fprintf(stderr,"Adding display tag %s\n",s);
  while(t != NULL && (r = strcmp(s,t->tok))) {
    l=t;
    if(r < 0) t = t->left;
    else t = t->right;
  }
  if(t == NULL) {
    t = (struct ny_displayitem *)malloc(sizeof(struct ny_displayitem));
    if((t->tok = malloc(strlen(s)+1)) == NULL) {
      fprintf(stderr,"can't allocate token space - abort!\n");
      return;
    }
    t->right=NULL;t->left=NULL;
    strcpy(t->tok,s);
    t->mask=ny_gdisplay; if(f > 0) t->mask |= 1;
    ny_gdisplay <<= 1;
    if(r < 0 && l != NULL) l->left=t;
    else if(l != NULL) l->right=t;
    else ny_displaytree=t;
  }
}

long
ny_GetDisplay(s)
char *s;
{
  int r;
  struct ny_displayitem *t;

  for(t=ny_displaytree;t != NULL && (r = strcmp(s,t->tok));
    t= (r < 0) ? t->left : t->right);
  if(t==NULL) return(0);
  else return(t->mask);
}

ny_PrintDisplays()
{
  FILE *f;

  if((f=fopen("./nytags.h","w+")) == NULL) return(-1);
  ny_TraverseDisplays(f,ny_displaytree);
  fprintf(f,"#define NY_OPEN 1\n#define NY_SELECT 0\n");
  fprintf(f,"#define NY_FSTR 1\n#define NY_NORMAL 0\n");
  fclose(f);
}

ny_TraverseDisplays(f,t)
FILE *f;
struct ny_displayitem *t;
{
  if(t != NULL) {
    ny_TraverseDisplays(f,t->left);
    fprintf(f,"#define %s %ld\n",t->tok,t->mask);
    ny_TraverseDisplays(f,t->right);
  }
}
#line 618 "y.tab.c"
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 69 "newyacc.y"
{ if(!ny_codeFound) {
		    fprintf(ny_out,"%%{\n\ntypedef enum {ny_empty,ny_terminal");
		    fprintf(ny_out,",ny_nonTerminal} ny_TokenType;\n\n%%}\n\n"); }
		  fprintf(ny_out,"%%%%"); }
break;
case 4:
#line 78 "newyacc.y"
{ fprintf(ny_out,"%%%%");
		  ny_mode = ny_readtail; }
break;
case 5:
#line 81 "newyacc.y"
{ ny_PrintDisplays(); YYACCEPT; }
break;
case 7:
#line 85 "newyacc.y"
{ ny_bounce = FALSE; }
break;
case 9:
#line 89 "newyacc.y"
{ fprintf(ny_out,"{"); ny_mode = ny_readunion; }
break;
case 10:
#line 90 "newyacc.y"
{ ny_mode = ny_normal; }
break;
case 11:
#line 91 "newyacc.y"
{ fprintf(ny_out,"}"); }
break;
case 12:
#line 93 "newyacc.y"
{ fprintf(ny_out,"%%{\n\ntypedef enum {ny_empty,ny_terminal");
		  fprintf(ny_out,",ny_nonTerminal} ny_TokenType;\n\n");
		  ny_mode = ny_readdefs; }
break;
case 13:
#line 96 "newyacc.y"
{ ny_mode = ny_normal; }
break;
case 14:
#line 97 "newyacc.y"
{ ny_codeFound=TRUE; fprintf(ny_out,"%%}"); }
break;
case 15:
#line 99 "newyacc.y"
{ ny_displays=FALSE; }
break;
case 17:
#line 103 "newyacc.y"
{ ny_displays = TRUE; }
break;
case 24:
#line 117 "newyacc.y"
{ fprintf(ny_out,"%s'",yyvsp[0].str); }
break;
case 25:
#line 119 "newyacc.y"
{ fprintf(ny_out,"\"%s\"",yyvsp[0].str); }
break;
case 28:
#line 125 "newyacc.y"
{ ny_rhscount = 0;
		  fprintf(ny_out,"%s",yyvsp[0].str);
		}
break;
case 31:
#line 133 "newyacc.y"
{ fprintf(ny_out,"%s",yyvsp[0].str); }
break;
case 33:
#line 136 "newyacc.y"
{ if(!ny_action) { ny_action = TRUE; fprintf(ny_out," { "); }
		  fprintf(ny_out," ny__squish(%d,%d); } |",ny_rhscount,ny_white); ny_white = FALSE;
		  ny_action = FALSE; ny_rhscount = 0;
		}
break;
case 36:
#line 145 "newyacc.y"
{ if(ny_action) { fprintf(ny_out," } "); ny_action = FALSE; }
		  ny_rhscount++;
		}
break;
case 37:
#line 149 "newyacc.y"
{ fprintf(ny_out,"%s",yyvsp[0].str); }
break;
case 38:
#line 151 "newyacc.y"
{ if(ny_action) { fprintf(ny_out," } "); ny_action = FALSE; }
		  ny_rhscount++;
		}
break;
case 39:
#line 155 "newyacc.y"
{ fprintf(ny_out,"%s'",yyvsp[0].str); }
break;
case 40:
#line 157 "newyacc.y"
{ if(ny_action) { fprintf(ny_out," } "); ny_action = FALSE; }
		  ny_rhscount++;
		}
break;
case 41:
#line 161 "newyacc.y"
{ fprintf(ny_out,"\"%s\"",yyvsp[0].str); }
break;
case 43:
#line 166 "newyacc.y"
{ fprintf(ny_out,"{"); ny_mode = ny_readaction; }
break;
case 44:
#line 168 "newyacc.y"
{ ny_mode = ny_normal; }
break;
case 45:
#line 170 "newyacc.y"
{ ny_action = TRUE; }
break;
case 46:
#line 174 "newyacc.y"
{ if(!ny_action) fprintf(ny_out," { ");
		  ny_action = TRUE;
		}
break;
case 48:
#line 181 "newyacc.y"
{ if(!ny_action) fprintf(ny_out," { ");
		  ny_action = TRUE; ny_curmask = yyvsp[0].num;
		  fprintf(ny_out," ny__trans(%d);",ny_curmask);
		}
break;
case 50:
#line 189 "newyacc.y"
{ ny_white = TRUE; yyval.num = 0; }
break;
case 51:
#line 191 "newyacc.y"
{ if(yyvsp[-1].num == 0) ny_white = TRUE; yyval.num = yyvsp[-1].num; }
break;
case 52:
#line 195 "newyacc.y"
{ fprintf(ny_out," ny__end(); "); }
break;
case 53:
#line 199 "newyacc.y"
{ fprintf(ny_out," ny__beg(); "); }
break;
case 54:
#line 201 "newyacc.y"
{ fprintf(ny_out," ny__decl(&%s); ",yyvsp[0].str); }
break;
case 56:
#line 205 "newyacc.y"
{ ny_nargs[ny_nargsp]++; }
break;
case 57:
#line 206 "newyacc.y"
{ fprintf(ny_out," ny__comma(); "); }
break;
case 58:
#line 206 "newyacc.y"
{ ny_nargs[ny_nargsp]++; }
break;
case 64:
#line 217 "newyacc.y"
{ fprintf(ny_out," ny__endcond(); "); }
break;
case 65:
#line 219 "newyacc.y"
{ fprintf(ny_out," ny__endelse (); ny__endcond(); "); }
break;
case 66:
#line 223 "newyacc.y"
{ fprintf(ny_out," ny__cond(); "); }
break;
case 67:
#line 225 "newyacc.y"
{ fprintf(ny_out," ny__then(); "); }
break;
case 68:
#line 227 "newyacc.y"
{ fprintf(ny_out," ny__endthen(); "); }
break;
case 69:
#line 231 "newyacc.y"
{ fprintf(ny_out, "ny__begbexp(0); "); }
break;
case 70:
#line 233 "newyacc.y"
{ fprintf(ny_out, "ny__endbexp(); "); }
break;
case 71:
#line 235 "newyacc.y"
{ fprintf(ny_out, "ny__begbexp(1); "); }
break;
case 72:
#line 237 "newyacc.y"
{ fprintf(ny_out, "ny__endbexp(); "); }
break;
case 74:
#line 251 "newyacc.y"
{ ny_ritem = yyvsp[0].str; }
break;
case 75:
#line 252 "newyacc.y"
{ ny_inasg = TRUE; ny_callp = " ny__assign"; }
break;
case 76:
#line 253 "newyacc.y"
{ ny_inasg = FALSE; }
break;
case 77:
#line 254 "newyacc.y"
{ ny_ritem = yyvsp[0].str; }
break;
case 78:
#line 255 "newyacc.y"
{ ny_inasg = TRUE; ny_callp = " ny__concat"; }
break;
case 79:
#line 256 "newyacc.y"
{ ny_inasg = FALSE; }
break;
case 81:
#line 260 "newyacc.y"
{ ny_callp = " ny__concat"; }
break;
case 83:
#line 264 "newyacc.y"
{ if(ny_inasg && !ny_incall) fprintf(ny_out,"%ss(&%s,\"%s\"); ",ny_callp,ny_ritem,yyvsp[0].str);
		  else fprintf(ny_out,"ny__orders(\"%s\"); ",yyvsp[0].str); }
break;
case 84:
#line 267 "newyacc.y"
{ ny_nargs[++ny_nargsp] = 0;
		  sf_incall[sf_incallp++] = ny_incall;
		  fprintf(ny_out," ny__begf(); "); ny_incall = TRUE; }
break;
case 85:
#line 271 "newyacc.y"
{ ny_incall = sf_incall[--sf_incallp];
		  if(ny_inasg && !ny_incall)
		    fprintf(ny_out,"%sf(%d,&%s,%s); ",ny_callp,ny_nargs[ny_nargsp],ny_ritem,yyvsp[-4].str);
		  else fprintf(ny_out,"ny__orderf(%d,%s); ",ny_nargs[ny_nargsp],yyvsp[-4].str);
		  ny_nargsp--;
		}
break;
case 86:
#line 278 "newyacc.y"
{ if(ny_inasg && !ny_incall) fprintf(ny_out,"%sp(&%s,%d,%d,%d,%d,0); ",
		    ny_callp,ny_ritem,yyvsp[0].num,ny_curdisplay,ny_nmask,ny_ptype);
		  else fprintf(ny_out,"ny__orderp(%d,%d,%d,%d,0); ",
		    yyvsp[0].num,ny_curdisplay,ny_nmask,ny_ptype); }
break;
case 87:
#line 283 "newyacc.y"
{ if(ny_inasg && !ny_incall) fprintf(ny_out,"%sp(&%s,%d,%d,%d,%d,1); ",
		    ny_callp,ny_ritem,yyvsp[0].num,ny_curdisplay,ny_nmask,ny_ptype);
                  else fprintf(ny_out,"ny__orderp(%d,%d,%d,%d,1); ",
		    yyvsp[0].num,ny_curdisplay,ny_nmask,ny_ptype); }
break;
case 88:
#line 288 "newyacc.y"
{ if(ny_inasg && !ny_incall) fprintf(ny_out,"%sr(&%s,&%s); ",ny_callp,ny_ritem,yyvsp[0].str);
		  else fprintf(ny_out," ny__refer(&%s); ",yyvsp[0].str); }
break;
case 89:
#line 293 "newyacc.y"
{ yyval.str = yyvsp[0].str; }
break;
case 90:
#line 297 "newyacc.y"
{ yyval.num = yyvsp[0].num; }
break;
case 91:
#line 301 "newyacc.y"
{ yyval.num = yyvsp[0].num; ny_curdisplay = 0; ny_nmask = ny_passThru;
		  ny_ptype = ny_selective; }
break;
case 92:
#line 304 "newyacc.y"
{ yyval.num = yyvsp[0].num; ny_curdisplay = 0; ny_nmask = ny_passThru; ny_ptype = ny_openr; }
break;
case 93:
#line 306 "newyacc.y"
{ yyval.num = yyvsp[-3].num; ny_curdisplay = yyvsp[-1].num; ny_nmask = ny_newMask;
		  ny_ptype = ny_selective; }
break;
case 94:
#line 309 "newyacc.y"
{ yyval.num = yyvsp[-3].num; ny_curdisplay = yyvsp[-1].num; ny_nmask = ny_newMask; ny_ptype = ny_openr; }
break;
case 95:
#line 312 "newyacc.y"
{ yyval.num = 0; }
break;
case 96:
#line 313 "newyacc.y"
{ yyval.num = LONGALLONES; }
break;
case 97:
#line 314 "newyacc.y"
{ yyval.num = yyvsp[0].num; }
break;
case 98:
#line 317 "newyacc.y"
{ yyval.num = ny_GetDisplay(yyvsp[0].str); }
break;
case 99:
#line 319 "newyacc.y"
{ yyval.num = ny_GetDisplay(yyvsp[0].str) | yyvsp[-2].num; }
break;
case 103:
#line 326 "newyacc.y"
{ if(!ny_action) { ny_action = TRUE; fprintf(ny_out," { "); }
		  fprintf(ny_out," ny__squish(%d,%d); } ;",ny_rhscount,ny_white);
		  ny_white = FALSE; ny_action = FALSE; ny_rhscount = 0;
		}
break;
#line 1081 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
