long yylineno=1,yycharno=0,yytok=0,yybline=0;
