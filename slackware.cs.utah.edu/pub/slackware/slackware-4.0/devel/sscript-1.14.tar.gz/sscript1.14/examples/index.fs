# section 1 means that a directory named '1' must be created here
# file README means a file named 'README' must be in this dir
# a file index.fs must be in all 4 directories defined here
section 1 - Various textes
section 2 - Multimedia
file README - Latest files added
section 3 - Unix applications
section 4 - Windows stuff
file information.txt - Information about this service
end end end end end end end end
