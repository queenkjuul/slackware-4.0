#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/nameser.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <resolv.h>

main()
{
 HEADER *hp;
 char answer[255], name[1024];
 strcpy(name,"att.net");
 res_init();
 res_query(name, C_IN, T_MX, answer, sizeof(answer));
 hp = (HEADER *) answer;
 if(hp->rcode == 0 && hp->ancount > 0)
 {
 printf("%d\n",hp->rcode);
 printf("%s\n",answer);
 p_query(answer);
 if(!hp->aa) printf("Answer not authoritative\n");
 }
 else printf("error\n");
}
