/*
(C) 1998 Patrick Lambert <drow@fastethernet.net>

This program is free software. You can use, distribute and modify it if
you let this legal note in all future versions, and if the program made
stays under free software. (see sscript.doc)

This program is distributed without ANY WARRANTY, without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   
PURPOSE.

Latest version of Socket Script is always available from
http://devplanet.fastethernet.net/sscript.html
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/file.h>
#include <signal.h>
#include "sscript.h"  

utils_cl(int sockfd, char in[1024][512])
{
 time_t lt;
 char salt[3],temp6[255];
 salt[0]='z';
 salt[1]='0';
 salt[2]='\0';
 if(!strcasecmp(lindex(temp,2),"perl"))
 {
  sprintf(temp6,"%s -le '%s' > .perl.results",PERL_BIN,in[atoi(lindex(temp,3))]);
  system(temp6);
 }
 if(!strcasecmp(lindex(temp,2),"crypt"))
 {
#ifdef USE_CRYPT
  strcpy(in[atoi(lindex(temp,4))],crypt(lindex2(in[atoi(lindex(temp,3))],0),salt));
#endif
 }
 if(!strcasecmp(lindex(temp,2),"localhost"))
 {
  strcpy(temp6,"");
  gethostname(temp6,sizeof(temp6));
  strcpy(in[atoi(lindex(temp,3))],temp6);
 }
 if(!strcasecmp(lindex(temp,2),"unixtime"))
 {
  lt=atol(in[atoi(lindex(temp,3))]);
  strcpy(in[atoi(lindex(temp,4))],(char *)ctime(&lt));
 }
}
