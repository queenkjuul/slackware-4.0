/* This is obsolete code from when Socket Script didn't support GTK yet.
Most of it is (C) Patrick Lambert (see sscript.doc for license) */

#include <malloc.h>
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Box.h> 
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Sme.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/Cardinals.h> 
#include <X11/Xaw/Simple.h> 
#include <X11/Xaw/SmeLine.h>
#define SetArg(which, val)      XtSetArg(args[nargs], (which),\
                                         (XtArgVal) (val)); nargs++

Widget  toplevel, top, top6, top3, top4, top5;
Screen  *screen;
Display *display[7];
XtAppContext ac, ac2, ac3, ac4, ac5, ac6;
XEvent event, qevent;
int displayed=0;

static Widget msgwidget, textbox, last, entrybox, mainbox, dialog1,
okbutton, quitbutton, continuebutton, viewbox;
static Widget form, widgets[3], choicebutton[10], form, menu,
menubutton1, menubutton2, menubutton3, menubutton4, menubutton5,
menubutton6, menubutton7, menubutton8, menubutton9, menubutton10, entry;

/* GUI resource file */
static String sscript_resources[] = {
    "*resizeGravity: NorthWest",
    "*beNiceToColormap: false",
    "*topShadowContrast: 20",
    "*bottomShadowContrast: 40",
#ifdef RES_COLORFUL
    "*textbox*background: #503080",
    "*textbox*foreground: #FFAAFF",
    "*textbox*shadowWidth: 2",
    "*viewbox*shadowWidth: 2",
    "*dialog1*font: *-*-bold-i-*-*-14-*-*-*-*-*-*-*",
    "*text*font: *-*-bold-*-*-*-12-*-*-*-*-*-*-*",
    "*foreground: #AA2050",
    "*background: LightGray",  
    "*viewbox*foreground: #000050",
    "*viewbox*background: #FFFFFF",
    "*Label*foreground: #050505",
#endif
#ifdef RES_STANDARD
    "*textbox*shadowWidth: 0",
    "*viewbox*shadowWidth: 0",
    "*foreground: #000000",
    "*background: #FFFFFF",
#endif
#ifdef RES_3D
    "*textbox*foreground: #503080",
    "*textbox*shadowWidth: 2",
    "*viewbox*shadowWidth: 2",   
    "*dialog1*font: *-*-bold-i-*-*-12-*-*-*-*-*-*-*",
    "*foreground: NavyBlue",
    "*background: LightGray", 
    "*viewbox*foreground: #000000",
    "*viewbox*background: #FFFFFF",
    "*Label*foreground: #050505",
#endif
    NULL
};

 /* initialization for GUI functions. This is a workaround, don't base
  * yourself on this.
  * Now here I tried lots of ways, like only 1 ac, or ac's destroyed and
  * recreated every time, but this is the only way I can get it without
  * a bunch of BadCursor on X_CreateWidget. Any other idea? mail me
  * about it.*/
 toplevel = XtAppInitialize(&ac2, "SScript", NULL, 0, &argc,
argv,sscript_reso$
 if(toplevel<0) lasterror=102;
 display[2] = XtDisplay(toplevel);
 screen = XtScreen(toplevel);
 top = XtVaAppInitialize(&ac, "SScript", NULL, 0, &argc, argv,
sscript_resources, XtNtitle, "Socket Script", NULL);
 display[1] = XtDisplay(top);
 top6 = XtVaAppInitialize(&ac6, "SScript", NULL, 0, &argc, argv,
sscript_resources, XtNtitle, "Socket Script", NULL);
 display[6] = XtDisplay(top6);
 top3 = XtVaAppInitialize(&ac3, "SScript", NULL, 0, &argc,
argv,sscript_resources, XtNtitle, "Socket Script", NULL);
 display[3] = XtDisplay(top3);
 top4 = XtVaAppInitialize(&ac4, "SScript", NULL, 0, &argc, argv,
sscript_resources, XtNtitle, "Socket Script", NULL);
 display[4] = XtDisplay(top4);
 top5 = XtVaAppInitialize(&ac5, "SScript", NULL, 0, &argc, argv,
sscript_resources, XtNtitle, "Socket Script", NULL);
 display[5] = XtDisplay(top5);

void closebox() {
 XtDestroyWidget(msgwidget);
 displayed=0;
}  
   
int msgbox(char *type, char *textstring, int len)
{/* based on xmsg by Willy Tarreau, under GPL */
 Arg args[20];
 char blah[255];
 register int nargs, nwidgets;
 int width;
 XtCallbackRec button1[2];
 if (displayed) return;
 displayed=1;
 if(lang==0)
 { 
  if(!strcasecmp(type,"header")) strcpy(blah,"Starting...");
  else if(!strcasecmp(type,"info")) strcpy(blah,"Information:");
  else if(!strcasecmp(type,"error")) strcpy(blah,"ERROR:");
 }
 else if(lang==1)
 {
  if(!strcasecmp(type,"header")) strcpy(blah,"Demarrer...");
  else if(!strcasecmp(type,"info")) strcpy(blah,"Information:");
  else if(!strcasecmp(type,"error")) strcpy(blah,"ERREUR:");
 }
 else if(lang==2)
 {
  if(!strcasecmp(type,"header")) strcpy(blah,"Iniciando...");   
  else if(!strcasecmp(type,"info")) strcpy(blah,"Informacion:");
  else if(!strcasecmp(type,"error")) strcpy(blah,"ERROR:");
 }
 bzero(button1, sizeof(button1));
 button1[0].callback = closebox;
 button1[0].closure = (caddr_t) 0;
 nargs = 0;
 SetArg(XtNx, 10);
 SetArg(XtNy, 10);
 SetArg(XtNtitle, "Socket Script");
 SetArg(XtNmaxHeight, 130);
 SetArg(XtNminHeight, 120);
 SetArg(XtNmaxWidth, (len+25)*8);
 SetArg(XtNminWidth, (len+20)*8);
 msgwidget=XtCreateWidget("window", applicationShellWidgetClass,
toplevel, args, nargs);
 nargs = 0;
 form = XtCreateWidget("box", boxWidgetClass, msgwidget, args, nargs);
 XtManageChild(form);
 nargs = 0;
 SetArg(XtNlabel,blah);   
 SetArg("borderWidth", 0);
 SetArg(XtNjustify,XtJustifyCenter);
 SetArg(XtNwidth,(len+20)*8);
 SetArg(XtNheight,15);
 XtManageChild(last=XtCreateWidget("label", labelWidgetClass, form,
args, nargs));
 nargs = 0;
 SetArg(XtNlabel, textstring);
 SetArg(XtNborderWidth, 1);
 SetArg(XtNjustify,XtJustifyCenter);
 SetArg(XtNfromVert,last);   
 SetArg(XtNwidth,(len+20)*8);
 SetArg(XtNheight,60);
 XtManageChild(textbox=XtCreateWidget("textbox", labelWidgetClass, form,
args, nargs));
 nwidgets = 0;
 nargs = 0;   
 SetArg(XtNcallback, button1);
 SetArg(XtNfromVert, textbox);
 SetArg(XtNhighlightThickness, -1);
 SetArg(XtNwidth, (len+20)*8);
 widgets[nwidgets++] = XtCreateWidget("OK", commandWidgetClass, form,
args, nargs);
 XtManageChild(form);
 XtManageChildren(widgets, nwidgets);
 XtRealizeWidget(msgwidget);
 XtPopup(msgwidget, XtGrabExclusive);
 while(displayed) {
  XtAppNextEvent(ac2, &event);
  XtDispatchEvent(&event);
 }
 XFlush(display[2]);
}

int queryOk(Widget result, XtPointer p1, XtPointer p2)
{
 strcpy(queryGlVar,XawDialogGetValueString(dialog1));
 XtDestroyWidget(mainbox);
 XtUnrealizeWidget(top);
 displayed = 0;
}
  
int queryOk2(Widget result, XtPointer p1, XtPointer p2)
{
 strcpy(queryGlVar,XawDialogGetValueString(dialog1));
 XtDestroyWidget(mainbox);
 XtUnrealizeWidget(top4);
 displayed = 0;
}
 
int ContinueIt(Widget result, XtPointer p1, XtPointer p2)
{
 XtDestroyWidget(mainbox);
 XtUnrealizeWidget(top3);
 displayed = 0;
}
 
int queryQuit(Widget result, XtPointer p1, XtPointer p2)
{
 XtDestroyWidget(mainbox);
 exit(0);
}
 
int query(char *string, int argc1, char *argv1[])
{
 if(displayed) return 0;
 displayed = 1;
 mainbox = XtVaCreateManagedWidget("mainbox", boxWidgetClass, top,
XtNmaxWidth, (strlen(string)+25)*8, XtNminWidth, (strlen(string)+20)*8,
XtNx, 10, XtNy, 10, XtNmaxHeight, 130, XtNminHeight, 120, NULL);
 dialog1 = XtVaCreateManagedWidget("dialog1", dialogWidgetClass,
mainbox, XtNlabel, string, XtNvalue, "", XtNwidth,
(strlen(string)+20)*8, NULL);
 okbutton = XtVaCreateManagedWidget("OK", commandWidgetClass, dialog1,
NULL);
 if(lang==0)
 quitbutton = XtVaCreateManagedWidget("Quit", commandWidgetClass,
dialog1, NULL);  
 else if(lang==1)
 quitbutton = XtVaCreateManagedWidget("Quitter", commandWidgetClass,
dialog1, NULL);  
 else if(lang==2)
 quitbutton = XtVaCreateManagedWidget("Salida", commandWidgetClass,
dialog1, NULL);
 XtAddCallback(okbutton, XtNcallback, (XtPointer)queryOk, NULL);
 XtAddCallback(quitbutton, XtNcallback, (XtPointer)queryQuit, NULL);
 XtRealizeWidget(top);
 while(displayed) {
  XtAppNextEvent(ac, &qevent);
  XtDispatchEvent(&qevent);
 }
 XFlush(display[1]);
}
 
int TextDone(Widget result, XtPointer p1, XtPointer p2)
{
 XawAsciiSaveAsFile(XawTextGetSource(viewbox), GlFile);
 XtDestroyWidget(mainbox);
 XtUnrealizeWidget(top6);
 displayed = 0;
}
  
int textview(char *file, int argc1, char *argv1[])
{
 if(displayed) return 0;
 displayed = 1;
 strcpy(GlFile,file);
 mainbox = XtVaCreateManagedWidget("mainbox", boxWidgetClass, top6,
NULL);
 continuebutton = XtVaCreateManagedWidget("Done", commandWidgetClass,
mainbox, NULL);
 viewbox = XtVaCreateManagedWidget("viewbox", asciiTextWidgetClass,
mainbox, XtNheight, 300, XtNwidth, 600, XtNscrollVertical,
XawtextScrollAlways, XtNscrollHorizontal, XawtextScrollAlways,
XtNeditType, XawtextEdit, NULL);
 XtAddCallback(continuebutton, XtNcallback, (XtPointer)TextDone, NULL);
 XtRealizeWidget(top6); 
 while(displayed)
 {
  XtAppNextEvent(ac6, &qevent);
  XtDispatchEvent(&qevent);
 }
 XFlush(display[6]);
}

int viewfile(char *file, int argc1, char *argv1[])
{
 FILE *fd;
 char *file_buf; 
 off_t len;
 struct stat stat_buf;
 if(displayed) return 0;   
 displayed = 1;
 mainbox = XtVaCreateManagedWidget("mainbox", boxWidgetClass, top3,
NULL);
 continuebutton =
XtVaCreateManagedWidget("Continue",commandWidgetClass,mainbox,NULL);
 viewbox = XtVaCreateManagedWidget("viewbox", asciiTextWidgetClass,
mainbox, XtNheight, 300, XtNwidth, 600, XtNscrollVertical,
XawtextScrollWhenNeeded, XtNscrollHorizontal, XawtextScrollWhenNeeded,
NULL);
 XtAddCallback(continuebutton, XtNcallback, (XtPointer)ContinueIt, NULL);
 if((fd=fopen(file,"ro"))==NULL)
 {
  if(lang==0)
  XtVaSetValues(viewbox, XtNstring, "\nCan't open that file\n\n", NULL);
  else if(lang==1)
  XtVaSetValues(viewbox, XtNstring, "\nNe peut ouvrir ce fichier\n\n",
NULL);
  else if(lang==2)
  XtVaSetValues(viewbox, XtNstring, "\nNo se puede abrir el
archivo\n\n", NULL);
 }
 else
 {
  fstat(fileno(fd), &stat_buf);
  len = stat_buf.st_size;
  file_buf = malloc(len * sizeof(char) +1);
  fread(file_buf, 1, len, fd);
  file_buf[len] = '\0';
  XtVaSetValues(viewbox, XtNstring, file_buf, NULL);
  free(file_buf);
  fclose(fd);
 }
 XtRealizeWidget(top3);
 while(displayed) {
  XtAppNextEvent(ac3, &qevent);
  XtDispatchEvent(&qevent);
 }
 XFlush(display[3]);
}
  
int view_n_query(char *file, char *string, int argc1, char *argv1[])
{
 FILE *fd;
 char *file_buf;
 off_t len;
 struct stat stat_buf;
 if(displayed) return 0;   
 displayed = 1;
 mainbox = XtVaCreateManagedWidget("mainbox", boxWidgetClass, top4,
NULL);
 dialog1 = XtVaCreateManagedWidget("dialog1", dialogWidgetClass,
mainbox, XtNlabel, string, XtNvalue, "", NULL);
 continuebutton =
XtVaCreateManagedWidget("Continue",commandWidgetClass,mainbox,NULL);
 viewbox = XtVaCreateManagedWidget("viewbox", asciiTextWidgetClass,
mainbox, XtNheight, 300, XtNwidth, 500, XtNscrollVertical,
XawtextScrollWhenNeeded, XtNscrollHorizontal, XawtextScrollWhenNeeded,
NULL);
 XtAddCallback(continuebutton, XtNcallback, (XtPointer)queryOk2, NULL);
 if((fd=fopen(file,"ro"))==NULL)
  XtVaSetValues(viewbox, XtNstring, "\nCan't open that file\n\n", NULL);
 else
 {
  fstat(fileno(fd), &stat_buf);
  len = stat_buf.st_size;
  file_buf = malloc(len * sizeof(char) +1);
  fread(file_buf, 1, len, fd);
  file_buf[len] = '\0';
  XtVaSetValues(viewbox, XtNstring, file_buf, NULL);
  free(file_buf);
  fclose(fd);
 }
 XtRealizeWidget(top4);
 while(displayed) {
  XtAppNextEvent(ac4, &qevent);
  XtDispatchEvent(&qevent);
 }
 XFlush(display[4]);
}

int gui_help(char *help_string, int argc, char *argv[])
{
 if(displayed) return 0;
 displayed = 1;
 mainbox = XtVaCreateManagedWidget("mainbox", boxWidgetClass, top, NULL);
 continuebutton =
XtVaCreateManagedWidget("Quit",commandWidgetClass,mainbox,NULL);
 viewbox = XtVaCreateManagedWidget("viewbox", asciiTextWidgetClass,
mainbox, XtNheight, 300, XtNwidth, 600, XtNscrollVertical,
XawtextScrollWhenNeeded, XtNscrollHorizontal, XawtextScrollWhenNeeded,
NULL);
 XtAddCallback(continuebutton, XtNcallback, (XtPointer)ContinueIt, NULL);
 XtVaSetValues(viewbox, XtNstring, help_string, NULL);
 XtRealizeWidget(top);
 while(displayed)
 {
  XtAppNextEvent(ac, &qevent);
  XtDispatchEvent(&qevent);
 }
}

int ComposerSave(Widget result, XtPointer p1, XtPointer p2)
{
 XawAsciiSaveAsFile(XawTextGetSource(viewbox), GlFile);
}
 
int ComposerAddServer(Widget result, XtPointer p1, XtPointer p2)
{
 char data[255];
 XawTextBlock text;
 static XawTextPosition pos;
 strcpy(data,"\n# server <ip>\nserver 127.0.0.1 ;\n");
 pos = XawTextGetInsertionPoint(viewbox);
 text.length = strlen(data);
 text.ptr = data;
 text.firstPos = 0;
 text.format = FMT8BIT;
 XawTextReplace(viewbox, pos, pos, &text);
 pos += text.length;
 XawTextSetInsertionPoint(viewbox, pos);
}
 
int ComposerAdd(Widget result, XtPointer p1, XtPointer p2)
{
 char data[255];
 XawTextBlock text;
 static XawTextPosition pos;
 strcpy(data,p1);
 if(!strcasecmp(data,"server"))
 strcpy(data,"\n# server <ip>\nserver 127.0.0.1 ;\n");
 else if(!strcasecmp(data,"port"))
 strcpy(data,"\n# port <port>\nport 80 ;\n");
 else if(!strcasecmp(data,"debug"))
 strcpy(data,"\n# debug <0|1>\ndebug 0 ;\n");
 else if(!strcasecmp(data,"virtual"))
 strcpy(data,"\n# virtual <0|1>\nvirtual 0 ;\n");
 else if(!strcasecmp(data,"chop"))
 strcpy(data,"\n# chop <0|1>\nchop 0 ;\n");
 else if(!strcasecmp(data,"rread"))
 strcpy(data,"\n# rread <variable number> ;\nrread 100 ;\n");
 else if(!strcasecmp(data,"rwrite"))
 strcpy(data,"\n# rwrite <variable number> ;\nset 100 hello !\nrwrite 100
;\n");
 else if(!strcasecmp(data,"rdisconnect"))
 strcpy(data,"\n# rdisconnect ;\nrdisconnect ;\n");
 else if(!strcasecmp(data,"include"))
 strcpy(data,"\n# include <name> <cl bin> ;\ninclude hello hello ;\n");
 else if(!strcasecmp(data,"setuserhost"))
 strcpy(data,"\n# setuserhost ;\nsetuserhost ;\n");
 else if(!strcasecmp(data,"setstrictcheck"))
 strcpy(data,"\n# setstrictcheck ;\nsetstrictcheck ;\n");
 else if(!strcasecmp(data,"setstrictwrite"))
 strcpy(data,"\n# setstrictwrite ;\nsetstrictwrite ;\n");
 else if(!strcasecmp(data,"settrace"))
 strcpy(data,"\n# settrace ;\nsettrace ;\n");
 else if(!strcasecmp(data,"setreversechop"))
 strcpy(data,"\n# setreversechop ;\nsetreversechop ;\n");
 else if(!strcasecmp(data,"setservice"))
 strcpy(data,"\n# setservice ;\nsetservice ;\n");
 else if(!strcasecmp(data,"setwindows"))
 strcpy(data,"\n# setwindows ;\nsetwindows ;\n");
 else if(!strcasecmp(data,"setsignalsoff"))
 strcpy(data,"\n# setsignalsoff ;\nsetsignalsoff ;\n");
 else if(!strcasecmp(data,"setremoteecho"))
 strcpy(data,"\n# setremoteecho ;\nsetremoteecho ;\n");
 else if(!strcasecmp(data,"require"))
 strcpy(data,"\n# require <version> ;\nrequire 18 ;\n");
 else if(!strcasecmp(data,"require-gui"))
 strcpy(data,"\n# require-gui ;\nrequire-gui ;\n");
 else if(!strcasecmp(data,"version"))
 strcpy(data,"\n# version ;\nversion ;\n");
 else if(!strcasecmp(data,"run"))
 strcpy(data,"\n# run <variable number> ;\nset 100 my.sh\nrun 100 ;\n");
 else if(!strcasecmp(data,"goto"))
 strcpy(data,"\n# goto <sub name> ;\ngoto my_sub ;\n");
 else if(!strcasecmp(data,"read"))
 strcpy(data,"\n# read <variable number> ;\nread 100 ;\n");
 else if(!strcasecmp(data,"write"))
 strcpy(data,"\n# write <string> ;\nwrite Hi $word 100 0 !\n");
 else if(!strcasecmp(data,"print"))
 strcpy(data,"\n# print <string> ;\nprint Thank you for using
SScript\n");
 else if(!strcasecmp(data,"save"))
 strcpy(data,"\n# save <variable number> <file> ;\nsave 100 log.file
;\n");
 else if(!strcasecmp(data,"append"))
 strcpy(data,"\n# append <variable number> <file> ;\nappend 101 log.file
;\n");
 else if(!strcasecmp(data,"rementry"))
 strcpy(data,"\n# rementry <variable number> <file> ;\nrementry 100
database.file ;\n");
 else if(!strcasecmp(data,"remove"))
 strcpy(data,"\n# remove <vairable number> <file> ;\nremove 100
database.file ;\n");
 else if(!strcasecmp(data,"ping"))
 strcpy(data,"\n# ping <remote ip> ;\nping 127.0.0.1 ;\n");
 else if(!strcasecmp(data,"test"))
 strcpy(data,"\n# test <variable number> ;\nset 100 127.0.0.1 80 ;\ntest
100 ;\n");
 else if(!strcasecmp(data,"parse"))
 strcpy(data,"\n# parse [<,<<,>>,>,!,_>,<_] <variable number> <char>
;\nparse < 100 @ ;\n");
 else if(!strcasecmp(data,"dump"))  
 strcpy(data,"\n# dump <variable number> ;\nset 100 my.file ;\ndump 100
;\n");
 else if(!strcasecmp(data,"setmaster"))
 strcpy(data,"\n# setmaster <file containing: <masked nick!user@host> ;>
;\nsetmaster masters.list ;\n"); 
 else if(!strcasecmp(data,"set"))
 strcpy(data,"\n# set <variable number> <string>\nset 100 hi !\n");
 else if(!strcasecmp(data,"setlogfile"))
 strcpy(data,"\n# setlogfile <filename> ;\nsetlogfile my.log ;\n");
 else if(!strcasecmp(data,"exit"))   
 strcpy(data,"\n# exit ;\nexit ;\n");
 else if(!strcasecmp(data,"saveall"))
 strcpy(data,"\n# saveall <filename> ;\nsaveall file.txt ;\n");
 else if(!strcasecmp(data,"addlog"))   
 strcpy(data,"\n# addlog <variable number> ;\nset 100 Starting sub
24\naddlog 100 ;\n");
 else if(!strcasecmp(data,"file"))
 strcpy(data,"\n# file exist <variable 1> <variable 2> ;\nset 100
my.file\nfile exist 100 101 ;\n");
 else if(!strcasecmp(data,"icmplisten"))
 strcpy(data,"\n# icmplisten <variable number> ;\nicmplisten 100 ;\n");
 else if(!strcasecmp(data,"cl"))
 strcpy(data,"\n# cl <library> <command> <args> ... ;\ncl util crypt 100
101 ;\n");
 else if(!strcasecmp(data,"command"))
 strcpy(data,"\n# command <variable number> ;\nset 100 addlog 101
;\ncommand 100 ;\n");
 else if(!strcasecmp(data,"background"))
 strcpy(data,"\n# background ;\nbackground ;\n");
 else if(!strcasecmp(data,"rconnect"))
 strcpy(data,"\n# rconnect <variable number> ;\nset 100 127.0.0.1 23
;\nrconnect 100 ;\n");
 else if(!strcasecmp(data,"endfor"))
 strcpy(data,"\n# endfor <for number> ;\nendfor 1 ;\n");
 else if(!strcasecmp(data,"ask"))
 strcpy(data,"\n# ask <variable number> ;\nask 105 ;\n");
 else if(!strcasecmp(data,"ifmatch"))
 strcpy(data,"\n# ifmatch <variable number> <masked word> <string>
;\nifmatch 100 *user@*.host QUIT : $nick asked me to.\n");
 else if(!strcasecmp(data,"loop"))
 strcpy(data,"\n# loop [start|end] <loop number> ;\nloop start 1 ;\nloop
end 1 ;\n");
 else if(!strcasecmp(data,"for"))
 strcpy(data,"\n# for <for number> <start number> to <end number> ;\nfor
1 1 to 100 do\n");
 else if(!strcasecmp(data,"ifword"))
 strcpy(data,"\n# ifword <variable number> <word number> <word>
<string>\nifword 100 0 help Here is my help: none.\n");
 else if(!strcasecmp(data,"ifword2"))
 strcpy(data,"\n# ifword2 <variable number> <word number> <word> <word
number 2> <word 2> <string>\nifword2 100 0 help 1 commands There is no
command available yet.\n");
 else if(!strcasecmp(data,"ifmaster"))
 strcpy(data,"\n# ifmaster <variable number> <word number> <word>
<string>\nifmaster 100 3 :raw PRIVMSG $nick :raw is not available\n");
 else if(!strcasecmp(data,"ifmaster2"))
 strcpy(data,"\n# ifmaster2 <variable number> <word number> <word> <word
number 2> <word 2> <string>\nifmaster2 100 3 :password 4 ScrtPass
PRIVMSG $nick :Auth failed.\n");
 else if(!strcasecmp(data,"?compare"))
 strcpy(data,"\n# ?compare <variable number 1> <variable number 2> <sub
name> ;\n?compare 100 101 my_sub ;\n");
 else if(!strcasecmp(data,"?match"))
 strcpy(data,"\n# ?match <variable number 1> <variable number 2> <sub
name> ;\n?match 100 101 my_sub ;\n");
 else if(!strcasecmp(data,"if"))
 strcpy(data,"\n# if <variable number 1> [<,>,=] <variable number 2>
<sub name> ;\nif 100 = 101 my_sub ;\n");
 else if(!strcasecmp(data,"resolve"))
 strcpy(data,"\n# resolve [ip,host] <variable number 1> <variable number
2> ;\nresolve host 100 101 ;\n"); 
 else if(!strcasecmp(data,"cron"))
 strcpy(data,"\n# cron <command line>\ncron /usr/bin/who\n");
 else if(!strcasecmp(data,"random"))
 strcpy(data,"\n# random <variable number> <max> ;\nrandom 100 6 ;\n");
 else if(!strcasecmp(data,"udpsend"))
 strcpy(data,"\n# udpsend <variable number> ;\nset 100 127.0.0.1 2000
Hi, this is the sender\nudpsend 100 ;\n");
 else if(!strcasecmp(data,"udplisten")) 
 strcpy(data,"\n# udplisten <variable number> <port number> ;\nudplisten
100 2000\n");
 else if(!strcasecmp(data,"raw"))
 strcpy(data,"\n# raw <variable number 1> <number of loops> <variable
number 2> ;\nraw 100 1 101 ;\n");
 else if(!strcasecmp(data,"viewfile"))
 strcpy(data,"\n# viewfile <file name> [-query <variable number>]
;\nviewfile test.txt -query 100 ;\n");
 else if(!strcasecmp(data,"devstat"))
 strcpy(data,"\n# devstat <device> <variable number> ;\ndevstat eth0 100
;\n");
 else if(!strcasecmp(data,"getenv"))
 strcpy(data,"\n# getenv <word> <variable number> ;\ngetenv HOME 100
;\n");
 else if(!strcasecmp(data,"query"))
 strcpy(data,"\n# query <variable number 1> <variable number 2> ;\nquery
100 101 ;\n");
 else if(!strcasecmp(data,"choicebox"))
 strcpy(data,"\n# choicebox <variable number> <button 1> <button 2> ...
| <label>\nchoicebox Yes No Quit | Are you sure ?\n");
 else if(!strcasecmp(data,"msgbox"))
 strcpy(data,"\n# msgbox <variable number> ;\nset 100 Welcome !\nmsgbox
100 ;\n");
 else strcpy(data,"\n# Command not in list. Try sscript -help
<command>\n");
 pos = XawTextGetInsertionPoint(viewbox);
 text.length = strlen(data);
 text.ptr = data;  
 text.firstPos = 0;
 text.format = FMT8BIT;
 XawTextReplace(viewbox, pos, pos, &text);
 pos += text.length;
 XawTextSetInsertionPoint(viewbox, pos);
}

int composer(char *file, int argc1, char *argv1[])
{
 FILE *fd;
 char *file_buf, tmp[255];
 off_t len;
 struct stat stat_buf; 
 if(displayed) return 0;
 displayed = 1;
 strcpy(GlFile, file);
 if(lang==0)
 sprintf(file,"Filename: %s", GlFile);
 else if(lang==1)
 sprintf(file,"Nom de fichier: %s", GlFile);
 else if(lang==2)
 sprintf(file,"Archivo: %s", GlFile);
 mainbox = XtVaCreateManagedWidget("mainbox", boxWidgetClass, top, NULL);
 menubutton1 = XtVaCreateManagedWidget("menubutton1",
menuButtonWidgetClass, mainbox, XtNlabel, "File", XtNborderWidth, 2,
NULL);
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass, menubutton1,
XtNlabel, "Composer functions", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu,
NULL);
 entry = XtVaCreateManagedWidget("savebutton", smeBSBObjectClass, menu,
XtNlabel, "Save file", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerSave, NULL);
 entry = XtVaCreateManagedWidget("quitbutton", smeBSBObjectClass, menu,
XtNlabel, "Quit", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)queryQuit, NULL);
 menubutton2 = XtVaCreateManagedWidget("menubutton2",
menuButtonWidgetClass, mainbox, XtNlabel, "Header", XtNborderWidth, 2,
NULL);  
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass, menubutton2,
XtNlabel, "Add header commands", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu, NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Server", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "server");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Port", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "port");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Debug", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "debug");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Chop", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "chop");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Virtual", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "virtual");
 menubutton3 = XtVaCreateManagedWidget("menubutton3",
menuButtonWidgetClass, mainbox, XtNlabel, "Version", XtNborderWidth, 2,
NULL); 
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass, menubutton3,
XtNlabel, "Add version-related commands", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu, NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Version", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "version");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Require", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "require");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Require-GUI", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"require-gui");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Include", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "include");
 menubutton4 = XtVaCreateManagedWidget("menubutton4",
menuButtonWidgetClass, mainbox, XtNlabel, "Networking", XtNborderWidth,
2, NULL);
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass, menubutton4,
XtNlabel, "Add networking commands", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu, NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Read", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "read");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Write", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "write");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Ping", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "ping");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Test", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "test");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Dump", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "dump");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Rconnect", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "rconnect");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Rread", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "rread");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Rwrite", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "rwrite");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Rdisconnect", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"rdisconnect");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "UDP send", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "udpsend");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "UDP listen", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "udplisten");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Raw", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "raw");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "ICMPlisten", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "icmplisten");
 menubutton5 = XtVaCreateManagedWidget("menubutton5",
menuButtonWidgetClass, mainbox, XtNlabel, "I/O", XtNborderWidth, 2,
NULL);
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass, menubutton5,
XtNlabel, "Add file and screen commands", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu, NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Print", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "print");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Ask", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "ask");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Save", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "save");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Append", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "append");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Remove", NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Rementry", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "rementry");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Save All", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "saveall");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "File", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "file");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Add log", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "addlog");
 menubutton6 = XtVaCreateManagedWidget("menubutton6",
menuButtonWidgetClass, mainbox, XtNlabel, "Parse", XtNborderWidth, 2,
NULL);   
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass, menubutton6,
XtNlabel, "Add parsing commands", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu,
NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Parse", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "parse");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "set");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "If match", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "ifmatch");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "If word", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "ifword");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "If word 2", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "ifword2");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "If master", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "ifmaster");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "If master 2", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "ifmaster2");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "? compare", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "?compare");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "? match", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "?match");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "If", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "if");
 menubutton7 = XtVaCreateManagedWidget("menubutton7",
menuButtonWidgetClass, mainbox, XtNlabel, "Loops", XtNborderWidth, 2,
NULL);   
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass, menubutton7,
XtNlabel, "Add loops commands", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu, NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "For", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "for");   
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "End for", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "endfor");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Loop", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "loop");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Go to", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "goto");
 menubutton8 = XtVaCreateManagedWidget("menubutton8",
menuButtonWidgetClass, mainbox, XtNlabel, "GUI", XtNborderWidth, 2,
NULL);
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass, menubutton8,
XtNlabel, "Add GUI commands", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu,
NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Msg box", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "msgbox");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Choice box", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "choicebox");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Query", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "query");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Viewfile", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "viewfile");
 menubutton9 = XtVaCreateManagedWidget("menubutton9",
menuButtonWidgetClass, mainbox, XtNlabel, "Settings", XtNborderWidth, 2,
NULL);
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass, menubutton9,
XtNlabel, "Add setting options", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu,
NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set master", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "setmaster");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set log file", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"setlogfile");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set Windows compatibility", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"setwindows");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set signals off", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"setsignalsoff");   
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set remote echo", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"setremoteecho");   
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set user@host", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"setuserhost");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set as service", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "setservice");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set reverse chop", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"setreversechop");  
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set strict-check", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"setstrictcheck");  
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set strict-write", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd,
"setstrictwrite");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Set trace", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "settrace");
 menubutton10 = XtVaCreateManagedWidget("menubutton10",
menuButtonWidgetClass, mainbox, XtNlabel, "Misc", XtNborderWidth, 2,
NULL);
 menu = XtVaCreatePopupShell("menu", simpleMenuWidgetClass,
menubutton10, XtNlabel, "Add other commands", NULL);
 entry = XtVaCreateManagedWidget("line", smeLineObjectClass, menu,
NULL);
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Resolve", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "resolve");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Cron", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "cron");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Random", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "random");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Dev stats", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "devstat");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Get env", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "getenv");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Run", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "run");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Command", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "command");
 entry = XtVaCreateManagedWidget("entry", smeBSBObjectClass, menu,
XtNlabel, "Background", NULL);
 XtAddCallback(entry, XtNcallback, (XtPointer)ComposerAdd, "background");
 if(lang==0) sprintf(tmp,"Filename: %s",GlFile);
 if(lang==1) sprintf(tmp,"Fichier: %s",GlFile);
 if(lang==2) sprintf(tmp,"Archivo: %s",GlFile);
 last = XtVaCreateManagedWidget("label", labelWidgetClass, mainbox,
XtNlabel, tmp, "borderWidth", 0, NULL);
 viewbox = XtVaCreateManagedWidget("viewbox", asciiTextWidgetClass,
mainbox, XtNheight, 300, XtNwidth, 600, XtNscrollVertical,
XawtextScrollAlways, XtNscrollHorizontal, XawtextScrollAlways,
XtNeditType, XawtextEdit, NULL);  
 if((fd=fopen(GlFile,"ro"))==NULL)
 {
  if(lang==0)
  XtVaSetValues(viewbox, XtNstring, "\nCan't open that file\n\n", NULL);
  else if(lang==1)
  XtVaSetValues(viewbox, XtNstring, "\nNe peut ouvrir ce fichier\n\n",
NULL);
  else if(lang==2)
  XtVaSetValues(viewbox, XtNstring, "\nNo se puede abrir el
archivo\n\n", NULL);
 }   
 else
 {
  fstat(fileno(fd), &stat_buf);
  len = stat_buf.st_size;
  file_buf = malloc(len * sizeof(char) +1);
  fread(file_buf, 1, len, fd);
  file_buf[len] = '\0';
  XtVaSetValues(viewbox, XtNstring, file_buf, NULL);
  free(file_buf);
  fclose(fd);
 }   
 XtRealizeWidget(top);
 while(displayed) {
  XtAppNextEvent(ac, &qevent); 
  XtDispatchEvent(&qevent);
 }
}
  
int choiceHdl(Widget result, XtPointer p1, XtPointer p2)
{
 if(result==choicebutton[0]) strcpy(queryGlVar,"1");
 else if(result==choicebutton[1]) strcpy(queryGlVar,"2");
 else if(result==choicebutton[2]) strcpy(queryGlVar,"3");
 else if(result==choicebutton[3]) strcpy(queryGlVar,"4");
 else if(result==choicebutton[4]) strcpy(queryGlVar,"5");
 else if(result==choicebutton[5]) strcpy(queryGlVar,"6");
 else if(result==choicebutton[6]) strcpy(queryGlVar,"7");
 else if(result==choicebutton[7]) strcpy(queryGlVar,"8");
 else if(result==choicebutton[8]) strcpy(queryGlVar,"9");
 else if(result==choicebutton[9]) strcpy(queryGlVar,"10");
 else strcpy(queryGlVar,"-1");
 XtDestroyWidget(mainbox);
 XtUnrealizeWidget(top5);
 displayed = 0;
}
 
int choicebox(int argc1, char *argv1[])
{
 int i;
 if(displayed) return 0;
 displayed = 1;
 mainbox = XtVaCreateManagedWidget("mainbox", boxWidgetClass, top5,
NULL);
 for(i=0;lindex(temp,i)!=NULL;i++)
 {
  if(!strcasecmp(lindex(temp,i),"|"))
  {
   last = XtVaCreateManagedWidget("label", labelWidgetClass, mainbox,
XtNlabel, lrange(temp,i+1), "borderWidth", 0, NULL);
   break;
  }
 }   
 i=0;
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl, NULL);
 i++;
 }
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl, NULL);
 i++;
 }
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl, NULL);
 i++;
 }
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl, NULL);
 i++;
 }
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl, NULL);
 i++;
 }
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl, NULL);
 i++;
 }
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl,
NULL);
 i++;
 }
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl, NULL);
 i++;
 }
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl, NULL);
 i++;
 }
 if(lindex(temp,i+2)!=NULL && *lindex(temp,i+2)!='|')
 {
 choicebutton[i] = XtVaCreateManagedWidget(lindex(temp,i+2),
commandWidgetClass, mainbox, NULL);
 XtAddCallback(choicebutton[i], XtNcallback, (XtPointer)choiceHdl, NULL);
 i++;
 }
 XtRealizeWidget(top5);
 while(displayed) {
  XtAppNextEvent(ac5, &qevent);
  XtDispatchEvent(&qevent);
 }
 XFlush(display[5]);
}

