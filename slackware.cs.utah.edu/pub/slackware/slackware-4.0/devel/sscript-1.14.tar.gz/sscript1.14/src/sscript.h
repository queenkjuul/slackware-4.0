#define NO_LOG_ENTRY /* no startup log entry, allowing you to setlogfile */
#define USE_CRYPT /* crypt() function */
#define GTK_HELP_COLORS /* neat colors in GTK -help */
#define PASSWORD /* password command */
#define PASS_LENGHT 8 /* password command lenght */
#define STARTUP_SCREEN /* startup screen in GUI/GTK screen */
#define DEV_STAT /* undef this if Solaris can't find if.h */

#include "config.h"
short bool_val;
char GlFile[255];
char *timeread(int sockfd, int timeout);
char *if_setup(char *device);
char *constat(char *option, int sockfd);
char *lindex(char *input_string, int word_number);
char *lindex2(char *input_string, int word_number);
char *lrange(char *input_string, int starting_at);
char *get_ip(char *host);
char *type(int i);
#ifdef USE_LIBZ
char *unzip_string(char *file);
#endif
char cron[255];
char global_var[512];
char logfilename[255];
char temp[255];
char queryGlVar[512];
char TMP_DIR[50];
int set_signals_off, pid, lang, lasterror, continous;
#ifdef USE_CURSES
#include <curses.h>
WINDOW *main_win;
#endif
#ifdef USE_NCURSES
#include <ncurses.h>
WINDOW *main_win;
#endif
#ifdef USE_SOCKS
#include <socks.h>
#endif
#ifdef SOLARIS
#include <sys/fcntl.h>
#include <sys/sockio.h>
#endif
#ifdef USE_SERIAL
FILE *sd;
char *serial_read();
#endif
#ifdef DB
#include <gdbm.h>
GDBM_FILE dbf;
datum db_data;
datum db_key;
#endif
char *procinfo();
struct proc_cpuinfo {
 int cpu;
 char model[20];
 char vendor[20];
 int fpu;
};
struct proc_meminfo {
 unsigned long free_mem;
 unsigned long total_mem;
 unsigned long free_swap;
 unsigned long total_swap;
};
