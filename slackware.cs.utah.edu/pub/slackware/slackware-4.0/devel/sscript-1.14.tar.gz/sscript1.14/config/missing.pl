#!/usr/bin/perl
# missing.pl - part of the SScript package
#
# This scans the system to see if all required include files are there
#
$includes[0] = "../src/sscript.h";
$includes[1] = "/usr/include/sys/types.h";
$includes[2] = "/usr/include/errno.h";
$includes[3] = "/usr/include/sys/socket.h";
$includes[4] = "/usr/include/sys/time.h";
$includes[5] = "/usr/include/sys/ioctl.h";
$includes[6] = "/usr/include/net/if.h";
$includes[7] = "/usr/include/netinet/in.h";
$includes[8] = "/usr/include/stdio.h";
$includes[9] = "/usr/include/stdlib.h";
$includes[10] = "/usr/include/strings.h";
$includes[11] = "/usr/include/sys/file.h";
$includes[12] = "/usr/include/signal.h";
$includes[13] = "/usr/include/errno.h";
$includes[14] = "/usr/include/unistd.h";
$includes[15] = "/usr/include/netdb.h";
$includes[16] = "/usr/include/arpa/inet.h";
$includes[17] = "/usr/include/sys/stat.h";
$includes[18] = "/usr/include/malloc.h";
$includes[19] = "/usr/X11R6/include/X11/StringDefs.h";
$includes[20] = "/usr/X11R6/include/X11/Intrinsic.h";
$includes[21] = "/usr/X11R6/include/X11/Shell.h";
$includes[22] = "/usr/X11R6/include/X11/Xaw/SimpleMenu.h";
$includes[23] = "/usr/X11R6/include/X11/Xaw/Command.h";
$includes[24] = "/usr/X11R6/include/X11/Xaw/Box.h";
$includes[25] = "/usr/X11R6/include/X11/Xaw/Form.h";
$includes[26] = "/usr/X11R6/include/X11/Xaw/Dialog.h";
$includes[27] = "/usr/X11R6/include/X11/Xaw/AsciiText.h";
$includes[28] = "/usr/X11R6/include/X11/Xaw/Label.h";
$includes[29] = "/usr/X11R6/include/X11/Xaw/Sme.h";
$includes[30] = "/usr/X11R6/include/X11/Xaw/SmeBSB.h";
$includes[31] = "/usr/X11R6/include/X11/Xaw/MenuButton.h";
$includes[32] = "/usr/X11R6/include/X11/Xaw/SimpleMenu.h";
$includes[33] = "/usr/X11R6/include/X11/Xaw/Cardinals.h";
$includes[34] = "/usr/X11R6/include/X11/Xaw/Simple.h";
$includes[35] = "/usr/X11R6/include/X11/Xaw/SmeLine.h";

$total = 35;
$position = 0;

print "Checking files...\n";
while($position < ($total+1)) {
open(FILE, $includes[$position]) || print "missing: $includes[$position]\n";
$position = $position + 1;
}
