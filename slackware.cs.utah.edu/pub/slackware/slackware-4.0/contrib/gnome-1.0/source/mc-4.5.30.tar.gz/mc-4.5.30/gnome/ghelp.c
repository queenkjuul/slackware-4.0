/*
 * GNU Midnight Commander/GNOME edition: Help support
 * (C) 1997 The Free Software Foundation
 *
 * Author: Miguel de Icaza (miguel@gnu.org)
 */

void
x_interactive_display ()
{
}
