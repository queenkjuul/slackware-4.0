/*
 * gtree: utility routines to use the GtkDTree widget in gmc.
 *
 * Miguel de Icaza
 */
#include <config.h>
#include <sys/types.h>
#include <gnome.h>
#include "gtree.h"

void
sync_tree (char *path)
{
}
