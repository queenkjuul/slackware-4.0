#ifndef __GPREFS_H__
#define __GPREFS_H__

void gnome_configure_box (GtkWidget *widget, WPanel *panel);


#endif
