#include <config.h>
#include "../src/global.h"

#include "../src/tty.h"		/* enable/disable interrupt key */
#include "../src/main.h"
