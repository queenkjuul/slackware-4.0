#ifndef GCACHE_H
#define GCACHE_H

void          image_cache_destroy ();
GdkImlibImage *image_cache_load_image (char *file);

#endif
