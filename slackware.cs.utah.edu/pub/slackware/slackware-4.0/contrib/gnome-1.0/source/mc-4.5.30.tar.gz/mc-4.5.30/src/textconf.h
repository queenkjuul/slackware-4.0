/* Defines what features are to be includes in the text mode edition */

#define COMPUTE_FORMAT_ALLOCATIONS    1
#define PORT_WIDGET_WANTS_HISTORY     1
#define PORT_NEEDS_CHANGE_SCREEN_SIZE 1
#define x_flush_events()
#define port_shutdown_extra_fds()
