#ifndef GDESKTOP_INIT_H
#define GDESKTOP_INIT_H

void gdesktop_init (void);

#endif
