void drive_cmd_a(WPanel *);
void drive_cmd_b(WPanel *);
void drive_chg(WPanel *panel);

