/* Printing support for the Midnight Commander
 *
 * Copyright (C) 1998-1999 The Free Software Foundation
 *
 * Author: Miguel de Icaza <miguel@nuclecu.unam.mx>
 */

#ifndef GPRINT_H
#define GPRINT_H


void gprint_setup_devices (void);


#endif
