#ifndef __GWIDGET_H
#define __GWIDGET_H

char *stock_from_text (char *text);

#endif /* __GWIDGET_H */
