#ifdef USE_PLUGIN

#ifndef	PLUGIN_H
#define PLUGIN_H

#define	MODULE_IFACE_VER	2

#define	XP_CALLBACK(x)	( (int (*) (void *, void *, void *, void *, void *, char) ) x )

#define	XP_USERCOMMAND	0
#define XP_PRIVMSG	1
#define XP_CHANACTION	2
#define XP_CHANMSG	3
#define XP_CHANGENICK	4
#define XP_JOIN		5
#define XP_CHANSETKEY	6
#define XP_CHANSETLIMIT	7
#define	XP_CHANOP	8
#define	XP_CHANVOICE	9
#define XP_CHANBAN	10
#define XP_CHANRMKEY	11
#define	XP_CHANRMLIMIT	12
#define	XP_CHANDEOP	13
#define	XP_CHANDEVOICE	14
#define	XP_CHANUNBAN	15
#define XP_INBOUND	16
#define	NUM_XP		17

#define	EMIT_SIGNAL(s, a, b, c, d, e, f) (sighandler[s] != NULL && sighandler[s] (a, b, c, d, e, f)) 
#define	XP_CALLNEXT(s, a, b, c, d, e, f)  if (s != NULL) return s(a, b, c, d, e, f); return 0;
#define XP_CALLNEXT_ANDSET(s, a, b, c, d, e, f) if (s != NULL) s(a, b, c, d, e, f); return 1;

struct	module	{
	void	*handle;
	char	*name, *desc;
	struct	module	*next, *last;
};

struct	xp_signal {
	int	signal;
	int	(**naddr)   (void *, void *, void *, void *, void *, char);
	int	(*callback) (void *, void *, void *, void *, void *, char);
	struct	module	*mod;
	struct	xp_signal	*next, *last;
};

struct	module_cmd_set	{
	struct	module	*mod;
	struct	commands	*cmds;
	struct	module_cmd_set	*next, *last;
};

#ifndef	PLUGIN_C
	extern	int	(*sighandler[NUM_XP])	(void *, void *, void *, void *, void *, char);
#endif

#endif

#else

#define	EMIT_SIGNAL(s, a, b, c, d, e, f) 0
#endif
