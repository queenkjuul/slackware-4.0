/*
 * All colors start with \003 followed by a color number 0-15.
 *
 * To revert to default color "\003 " is used (a space after \003).
 *
 * \002 can be used to turn bold on and off.
 */

/*#define STARTON "\0034�\003 �\0034�\003 "
#define STARTOFF "\0033�\003 �\0033�\003 "*/

#define STARTON "\0034*\003 *\0034*\003 "
#define STARTOFF "\0033*\003 *\0033*\003 "

#define PRIVMSG_TEXT "\00312*\00313%s\00312* \003 %s\n"
#define ACTION_TEXT "\00313* \003 %s %s\n"
#define CHANNEL_MSG_FROM_USER "\0036<\003 %s\0036> \003 %s\n"
#define CHANNEL_MSG_WITH_NICK "\0032<\002\0038%s\002\0032> \003 %s\n"
#define CHANNEL_MSG "\0032<\003 %s\0032> \003 %s\n"
#define CHANNEL_MSG_COLOR "<\003%d%s\003 > %s\n"
#define ACTION_TEXT_COLOR "* \003%d%s\003  %s\n"
