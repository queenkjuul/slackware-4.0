
void gtkutil_file_req(char *title, void *callback, void *userdata, void *userdata2, int write);
GtkWidget *gtkutil_window_new(char *title, int x, int y, void *callback, gpointer userdata);
void gtkutil_destroy(GtkWidget *igad, GtkWidget *dgad);
GtkWidget *gtkutil_simpledialog(char *msg);
GtkWidget *gtkutil_button_new(char *label, int width, int height, void *callback, gpointer userdata, GtkWidget *box);
void gtkutil_label_new(char *text, GtkWidget *box);
GtkWidget *gtkutil_entry_new(int max, GtkWidget *box, void *callback, gpointer userdata);
GtkWidget *gtkutil_clist_new(int columns, char *titles[],
			     GtkWidget *box, int policy,
			     void *select_callback, gpointer select_userdata,
			     void *unselect_callback, gpointer unselect_userdata);
GtkWidget *gtkutil_stock_button(GtkWidget *win, char *stock, char *labeltext,
				void *callback, gpointer userdata,
				GtkWidget *box);
int gtkutil_clist_selection(GtkWidget *clist);
