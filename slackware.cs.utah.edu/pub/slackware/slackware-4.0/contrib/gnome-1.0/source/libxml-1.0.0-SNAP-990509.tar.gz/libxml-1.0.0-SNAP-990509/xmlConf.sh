#
# Configuration file for using the XML library in GNOME applications
#
XML_LIBDIR="-L/usr/lib"
XML_LIBS="-lxml -lz"
XML_INCLUDEDIR="-I/usr/include"