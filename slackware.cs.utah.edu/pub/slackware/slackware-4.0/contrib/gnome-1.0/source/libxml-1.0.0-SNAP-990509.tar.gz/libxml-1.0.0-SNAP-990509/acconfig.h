#undef PACKAGE
#undef VERSION
#undef HAVE_LIBZ
