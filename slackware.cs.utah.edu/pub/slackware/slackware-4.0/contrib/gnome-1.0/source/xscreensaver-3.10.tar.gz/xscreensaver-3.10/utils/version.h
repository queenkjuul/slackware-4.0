static const char screensaver_id[] =
	"@(#)xscreensaver 3.10 (27-Apr-99), by Jamie Zawinski (jwz@jwz.org)";
