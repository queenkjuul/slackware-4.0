/*
 *   c-auto.h
 *
 *   This file is part of the ttf2pk package.
 *
 *   Copyright 1997-1998 by
 *     Frederic Loyer <loyer@ensta.fr>
 *     Werner Lemberg <wl@gnu.org>
 */

#ifndef C_AUTO_H
#define C_AUTO_H

/*
 *   We need to get kpathsea's configuration file.
 */

#include "kpathsea/c-auto.h"

#endif /* C_AUTO_H */


/* end */
