#ifndef _MesaMWorkstationP_h
#define _MesaMWorkstationP_h

#define __GLX_MOTIF

#include "MesaWorkstationP.h"

#endif
