/* MesaMDrawingAreaP.h */


#ifndef MESAMDRAWINGAREAP_H
#define MESAMDRAWINGAREAP_H


#define __GLX_MOTIF 1

#include "MesaDrawingAreaP.h"


#endif
