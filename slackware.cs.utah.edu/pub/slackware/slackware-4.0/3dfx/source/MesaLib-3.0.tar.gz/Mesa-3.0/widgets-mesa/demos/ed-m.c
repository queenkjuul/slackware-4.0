
#define __GLX_MOTIF

#include "ed.c"
