
#define __GLX_MOTIF

#include "mcube.c"
