
#ifndef _LINUTIL_H_
#define _LINUTIL_H_

extern int lin_kbhit();
extern char lin_getch();

#define kbhit lin_kbhit
#define getch lin_getch

#endif
