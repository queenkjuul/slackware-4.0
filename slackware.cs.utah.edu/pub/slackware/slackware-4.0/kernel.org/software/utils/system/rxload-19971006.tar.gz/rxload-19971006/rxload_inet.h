/* ----------------------------------------------------------------------- *
 *   
 *   Copyright 1997 H. Peter Anvin - All Rights Reserved
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, Inc., 675 Mass Ave, Cambridge MA 02139,
 *   USA; either version 2 of the License, or (at your option) any later
 *   version.
 *   
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 * ----------------------------------------------------------------------- */

/* rxload_inet.h - common definitions for inet protocol family */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#define DEFAULT_SERVICE     "loadavg" /* Default service name */
#define DEFAULT_PORT        8216      /* Port number if service unknown */

#define SOCK_TRIES           2        /* Outer-trial loop (new socket) */
#define DGRAM_TRIES          3        /* Inner-trial loop (same socket) */
#define DGRAM_TIMEOUT        5	      /* Time between requests */
