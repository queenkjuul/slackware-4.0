/* Separate to keep compilation of protocols.c simpler */
extern void ipx_proto_init(struct net_proto *pro);
