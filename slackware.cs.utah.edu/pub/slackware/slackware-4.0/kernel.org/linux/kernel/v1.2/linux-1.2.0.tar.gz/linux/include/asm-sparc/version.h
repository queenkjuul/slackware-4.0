#define WHO_COMPILED_ME "someone@somewhere.domain"
