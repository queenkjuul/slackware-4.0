#ifndef _ASMAXP_SIGNAL_H
#define _ASMAXP_SIGNAL_H

struct sigcontext_struct {
	/*
	 * what should we have here? I'd probably better use the same
	 * stack layout as OSF/1, just in case we ever want to try
	 * running their binaries.. 
	 */
};

#endif
