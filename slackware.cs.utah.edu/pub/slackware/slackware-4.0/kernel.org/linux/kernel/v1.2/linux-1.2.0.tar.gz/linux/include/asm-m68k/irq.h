#ifndef _M68K_IRQ_H_
#define _M68K_IRQ_H_

/* dummy for m68k */

#endif /* _M68K_IRQ_H_ */
