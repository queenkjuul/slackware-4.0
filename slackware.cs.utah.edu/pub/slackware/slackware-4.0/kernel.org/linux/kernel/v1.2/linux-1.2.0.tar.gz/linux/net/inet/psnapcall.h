/* Separate to keep compilation of Space.c simpler */
extern void snap_proto_init(struct net_proto *);
