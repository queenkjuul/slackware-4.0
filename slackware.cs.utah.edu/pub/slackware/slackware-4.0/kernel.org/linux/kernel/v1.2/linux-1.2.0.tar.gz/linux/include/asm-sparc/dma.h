/*
 * include/asm-sparc/dma.h
 *
 * Don't even ask, I am figuring out how this crap works
 * on the Sparc. It may end up being real hairy to plug
 * into this code, maybe not, we'll see.
 *
 * Copyright (C) David S. Miller (davem@caip.rutgers.edu)
 */

#include <asm/vac-ops.h>  /* for invalidate's, etc. */

#define MAX_DMA_CHANNELS 8
#define MAX_DMA_ADDRESS  0x0

#ifndef _ASM_SPARC_DMA_H
#define _ASM_SPARC_DMA_H


#endif /* !(_ASM_SPARC_DMA_H) */
