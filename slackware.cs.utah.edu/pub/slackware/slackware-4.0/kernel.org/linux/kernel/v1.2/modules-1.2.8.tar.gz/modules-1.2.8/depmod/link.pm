/* alloctxt.c 28/05/95 17.43.48 */
/* config.c 28/05/95 17.43.06 */
/* config1.c 20/05/95 04.41.38 */
/* depmod.c 28/05/95 17.45.18 */
/* error.c 28/05/95 18.01.38 */
/* fgets.c 19/01/95 00.19.24 */
/* main.c 28/05/95 17.47.30 */
/* modprobe.c 28/05/95 17.42.26 */
PUBLIC NODE::NODE (const char *_str, NODE *_next);
PUBLIC NODE::~NODE (void);
PUBLIC NODE *NODE::lookup (const char *name);
PUBLIC DEPEND::DEPEND (void);
PUBLIC DEPEND::~DEPEND (void);
PUBLIC int DEPEND::readcur (void);
PUBLIC int DEPEND::read (const char *cfgfile);
PUBLIC int DEPEND::insmod (const char *mod,
	 NODE **newin_kernel,
	 char *options[]);
PUBLIC int DEPEND::unload (const char *mod);
/* module.c 28/05/95 17.46.56 */
PUBLIC MODULES::MODULES (void);
PRIVATE void MODULES::setmod (MODULE *mod,
	 SYMBOL *tbpub[],
	 int nbpub,
	 SYMBOL *tbext[],
	 int nbext,
	 int module_requis);
PUBLIC MODULE *MODULES::setdummy (const char *name);
PUBLIC int MODULES::loadobj (SYMBOLS&syms, const char *objname);
PUBLIC int MODULES::loadlib (SYMBOLS&syms, const char *libname);
PUBLIC int MODULES::multipass (void);
PUBLIC void MODULES::showundef (SYMBOL *undef, FILE *fout);
PUBLIC int MODULES::findundef (FILE *fout);
PUBLIC int MODULES::showload (FILE *fout);
PUBLIC void MODULES::showall (FILE *fout);
/* module2.c 28/05/95 17.49.36 */
PUBLIC void MODULES::prtdepend (FILE *fout,
	 const char *dontcare,
	 int verbose,
	 int showerror);
/* str.c 28/05/95 17.49.54 */
/* symbol.c 14/07/94 09.21.48 */
PUBLIC SYMBOLS::SYMBOLS (void);
PROTECTED void SYMBOLS::allocsym (void);
PUBLIC SYMBOL *SYMBOLS::add (const char *name,
	 MODULE *module,
	 SYM_STATUS status,
	 int &module_requis,
	 int is_common);
PUBLIC int SYMBOLS::findforce (char **tb, int maxtb);
PUBLIC void SYMBOLS::dump (FILE *fout);
