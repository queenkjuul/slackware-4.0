#ifndef _LINUX_VFS_H
#define _LINUX_VFS_H

#include <asm/statfs.h>

#endif
