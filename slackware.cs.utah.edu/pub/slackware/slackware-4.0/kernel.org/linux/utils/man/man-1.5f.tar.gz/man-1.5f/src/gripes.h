#include "gripedefs.h"

void gripe (int n, ...);
void fatal (int n, ...);

