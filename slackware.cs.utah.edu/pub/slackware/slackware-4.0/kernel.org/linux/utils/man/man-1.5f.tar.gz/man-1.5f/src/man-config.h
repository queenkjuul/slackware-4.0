char *getval (char *);
char *get_expander (char *);
void read_config_file (char *cf);

extern struct dirs cfdirlist;
extern char *configuration_file;
