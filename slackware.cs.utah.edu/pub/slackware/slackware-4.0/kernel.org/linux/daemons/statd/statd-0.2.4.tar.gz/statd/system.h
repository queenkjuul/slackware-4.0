/*
 * System-dependent declarations
 *
 * $Id: system.h,v 2.1 1997/01/29 04:11:12 juphoff Exp $
 */

#ifdef FD_SETSIZE
# define FD_SET_TYPE	fd_set
# define SVC_FDSET	svc_fdset
#else
# define FD_SET_TYPE	int
# define SVC_FDSET	svc_fds
#endif
