#define STATD_RELEASE "0.2.4"
