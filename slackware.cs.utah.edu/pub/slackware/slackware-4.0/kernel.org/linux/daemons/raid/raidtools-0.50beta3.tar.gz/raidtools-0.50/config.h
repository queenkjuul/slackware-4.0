/*
 * config.h : Utility for the Linux Multiple Devices driver
 *            Copyright (C) 1997 Ingo Molnar, Miguel de Icaza, Gadi Oxman
 *            Copyright (C) 1998 Erik Troan
 *
 * These are the configuration structures, to be filled out by the parser, to
 * be analyzed/used by the superblock stuff.
 *
 * This source is covered by the GNU GPL, the same as all Linux kernel
 * sources.
 */

