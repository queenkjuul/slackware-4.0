/*
 * parser.h : Utility for the Linux Multiple Devices driver
 *            Copyright (C) 1997 Ingo Molnar, Miguel de Icaza, Gadi Oxman
 *
 * Parser externally visible interface.
 *
 * This source is covered by the GNU GPL, the same as all Linux kernel
 * sources.
 */

extern int parse_config (FILE *fp);

extern char *parity_algorithm_table[];


