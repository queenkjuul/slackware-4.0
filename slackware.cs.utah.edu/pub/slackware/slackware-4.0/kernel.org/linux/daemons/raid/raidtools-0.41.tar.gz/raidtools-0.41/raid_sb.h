/*
 * raid_sb.h : Utility for the Linux Multiple Devices driver
 *             Copyright (C) 1997 Ingo Molnar, Miguel de Icaza, Gadi Oxman
 *
 * Externaly visible RAID superblock operations interface.
 *
 * This source is covered by the GNU GPL, the same as all Linux kernel
 * sources.
 */

extern void print_sb (md_superblock_t *sb);
extern int analyze_sb (void);
extern int init_set (void);
extern int write_sb (int old);


