/*
 * mkraid.c : Utility for the Linux Multiple Devices driver
 *            Copyright (C) 1997 Ingo Molnar, Miguel de Icaza, Gadi Oxman
 *            Copyright (C) 1998 Erik Troan
 *
 * This utility reads a Linux MD raid1/4/5 configuration file, writes a
 * raid superblock on the devices in the raid set, and initializes the
 * set for first time use, depending on command line switches and
 * configuration file settings.
 *
 * This source is covered by the GNU GPL, the same as all Linux kernel
 * sources.
 */

#include "common.h"
#include "parser.h"
#include "raid_io.h"
#include "popt.h"

md_cfg_entry_t *cfg_head = NULL, *cfg = NULL;
int do_quiet_flag = 0;

void usage (void) {
    printf("usage: mkraid [--configfile] [--version] [--only-superblock] [--force]\n");
    printf("       [--force] [-acfhov] </dev/md?>*\n");
}

static int makeOneRaid(md_cfg_entry_t * cfg, int force, int dontClear) {
    if (cfg->sb.level < 1) {
	fprintf(stderr, "mkraid is only relevant for RAID 1, 4, "
			"and 5 devices\n");
	return 1;
    }

    if (analyze_sb(cfg, force))
	return 1;
    if (check_active(cfg)) 
	return 1;

    if (!dontClear && init_set(cfg))
	return 1;

    if (write_sb(cfg, 0))
	return 1;
}

int main (int argc, char *argv[])
{
    FILE *fp = NULL;
    int name_index;
    md_cfg_entry_t *p;
    int exit_status=0;
    int version = 0, help = 0, all = 0;
    char * configFile = RAID_CONFIG;
    int force_flag = 0;
    int no_clear_flag = 0;
    char ** args;
    poptContext optCon;
    int i;
    struct poptOption optionsTable[] = {
	{ "configfile", 'c', POPT_ARG_STRING, &configFile, 0 },
	{ "force", 'f', 0, &force_flag, 0 },
	{ "help", 'h', 0, &help, 0 },
	{ "only-superblock", 'o', 0, &no_clear_flag, 0 },
	{ "version", 'V', 0, &version, 0 },
	{ NULL, 0, 0, NULL, 0 }
    } ;

    optCon = poptGetContext("mkraid", argc, argv, optionsTable, 0);
    if ((i = poptGetNextOpt(optCon)) < -1) {
	fprintf(stderr, "%s: %s\n", 
		poptBadOption(optCon, POPT_BADOPTION_NOALIAS),
		poptStrerror(i));
	usage();
	return EXIT_FAILURE;
    }

    if (help) {
	usage();
	return EXIT_FAILURE;
    } else if (version) {
	printf("mkraid version %d.%d.%d\n", MKRAID_MAJOR_VERSION, 
	       MKRAID_MINOR_VERSION, MKRAID_PATCHLEVEL_VERSION);
	return EXIT_VERSION;
    }

    fp = fopen(configFile, "r");
    if (fp == NULL) {
	fprintf(stderr, "Couldn't open %s -- %s\n", configFile, 
	        strerror(errno));
	goto abort;
    }

    srand((unsigned int) time(NULL));
    if (parse_config(fp))
	goto abort;

    args = poptGetArgs(optCon);
    if (!args) {
	fprintf(stderr, "nothing to do!\n");
	return EXIT_FAILURE;
    }

    while (*args) {
	for (p = cfg_head; p; p = p->next) {
	    if (strcmp(p->md_name, *args)) continue;
	    if (makeOneRaid(p, force_flag, no_clear_flag))
		goto abort;
	    break;
	}
	if (!p) {
	    fprintf(stderr, "device %s is not described in config file\n", *args);
	    exit_status++;
	}
	args++;
    }

    fclose(fp);
    return 0;

abort:
    fprintf(stderr, "mkraid: aborted\n");
    exit_status = 1;
    if (fp)
	fclose(fp);
    return exit_status;
}
