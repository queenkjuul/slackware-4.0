
/*
   raidadd.c : Multiple Devices tools for Linux
               Copyright (C) 1994-96 Marc ZYNGIER
	       <zyngier@ufr-info-p7.ibp.fr> or
	       <maz@gloups.fdn.fr>
	       Copyright (C) 1998 Erik Troan
	       <ewt@redhat.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.
   
   You should have received a copy of the GNU General Public License
   (for example /usr/src/linux/COPYING); if not, write to the Free
   Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  
*/

#include "common.h"
#include "parser.h"
#include "popt.h"

#include <asm/page.h>
#include <string.h>

#define MDADD_VERSION "v0.3d"

static save_errno = 0;

md_cfg_entry_t *cfg_head = NULL, *cfg = NULL;
int do_quiet_flag = 0;

enum raidaddFunc {add, start, stop, stop_ro };

static int open_or_die (char *file)
{
  int fd;
  
  if ((fd=open (file, O_RDONLY))==-1)
  {
    perror (file);
    exit (EXIT_FAILURE);
  }

  return fd;
}

/*
 * converts a size in bytes to 'factor' metrics, which is a
 * kernel-internal way of dealing with chunk sizes and stuff.
 * It's the number of pages within the given number.
 */
static int s2f (int bytes)
{
    int factor, c, i;
    int kbytes;

    if (bytes % 1024) {
	fprintf (stderr, "chunk_size must be an integral number of k\n");
	return 0;
    }
    kbytes = bytes >> 10;
    
    factor = kbytes >> (PAGE_SHIFT - 10);
    for (i=1, c=0; i<kbytes; i*=2)
	if (factor & i) c++;
    
    if ((kbytes*MD_BLK_SIZ) % PAGE_SIZE || c!=1) {
	fprintf (stderr, "Cannot handle %dk chunks. Defaulting to %dk\n",
		 kbytes, 1 << (PAGE_SHIFT-10));
	return (0);
    }

    for (i=0; !(factor & (1 << i)); i++);
    return (i);
}

static int do_mdadd (int fd, char *dev)
{
	struct stat s;

	save_errno = 0; /* for possible exit status for floppy */

	if (stat (dev, &s)) {
		save_errno = errno;
		perror (dev);
		errno = save_errno;
		return 1;
	}

	if (MAJOR (s.st_rdev)==FLOPPY_MAJOR) {
		fprintf (stderr, "%s : warning, md cannot use floppies\n", dev);
		save_errno=EPERM; /* used in case of valid return */
	}
  
	if (ioctl (fd, REGISTER_DEV, s.st_rdev)) {
		save_errno = errno;
		if (errno == EEXIST)
			fprintf (stderr, "%s : device already added\n", dev);
		else
			perror(dev);
		errno = save_errno;
		return 2;
	}
	errno = save_errno;
	return 0;
}

static int do_mdstart (int fd, char *dev, int pers)
{
  if (ioctl (fd, START_MD, pers)) {
    save_errno=errno;
    perror (dev);
    errno=save_errno;
    return 1;
  }
  return 0;
}

static int do_mdstop (int fd, char *dev, int ro)
{
	int func = STOP_MD;

	if (ro)
		func = STOP_MD_RO;

	if (ioctl (fd, func, 0)) {
		save_errno = errno;
		switch (save_errno) {
			case ENXIO:
				fprintf(stderr,"%s: already stopped\n",dev);
				break;
			case EINVAL:
				if (func == STOP_MD_RO) {
					fprintf(stderr,"%s: old kernel!\n",dev);
					break;
				}
				/* fall through */
			default:
				perror (dev);
		}
		errno = save_errno;
		return 1;
	}
	return 0;
}

void usage(unsigned char *arg) {
    printf("usage: %s [--all] [--configfile] [--help] [--version] [-achv] </dev/md?>*\n", arg);
}

static int handleOneConfig(enum raidaddFunc func, md_cfg_entry_t * cfg) {
    int rc = 0;
    int fd;
    int i;
    int pers;

    switch (func) {
      case add:
	fd = open_or_die(cfg->md_name);
	for (i = 0; i < MD_SB_DISKS; i++) {
	    if (!cfg->device_name[i]) continue;
	    if (do_mdadd(fd, cfg->device_name[i])) rc++;
	}

	close(fd);
	break;

      case start:
	switch (cfg->sb.level) {
	  case -1: pers=LINEAR; break;
	  case 0:  pers=RAID0;  break;
	  case 1:  pers=RAID1;  break;
	  case 4:
	  case 5:  pers=RAID5;  break;
	  default: exit (EXIT_FAILURE);
	}

	if (cfg->sb.level < 4)
	    if (cfg->sb.chunk_size)
		pers |= s2f(cfg->sb.chunk_size);

	fd = open_or_die(cfg->md_name);
	if (do_mdstart (fd, cfg->md_name, pers)) rc++;
	break;

      case stop:
	fd = open_or_die(cfg->md_name);
	if (do_mdstop (fd, cfg->md_name, 0)) rc++;
	break;

      case stop_ro:
	fd = open_or_die(cfg->md_name);
	if (do_mdstop (fd, cfg->md_name, 1)) rc++;
	break;
    }

    return rc;
}

int main (int argc, char *argv[]) {
    int i, j, fd, all=0, readonly=0, flag, pers=-1,
	 exit_status=0, version = 0, help = 0;
    unsigned char factor=0, fault=0;
    char *namestart=argv[0];
    md_cfg_entry_t *p;
    char ** args;
    enum raidaddFunc func;
    FILE * fp;
    poptContext optCon;
    char * configFile = RAID_CONFIG;
    struct poptOption optionsTable[] = {
	{ "all", 'a', 0, &all, 0 },
	{ "configfile", 'c', POPT_ARG_STRING, &configFile, 0 },
	{ "readonly", 'r', 0, &readonly, 0 },
	{ "help", 'h', 0, &help, 0 },
	{ "version", 'V', 0, &version, 0 },
	{ NULL, 0, 0, NULL, 0 }
    } ;

    namestart = strrchr(argv[0], '/');
    if (!namestart)
	namestart = argv[0];
    else
	namestart++;

    if (!strcmp (namestart, "raidadd"))
	func=add;
    else if (!strcmp (namestart, "raidrun"))
	func=start;
    else if (!strcmp (namestart, "raidstop"))
	func=stop;
    else {
	fprintf (stderr, "Unknown command %s\n", argv[0]);
	usage(namestart);
	return (EXIT_FAILURE);
    }

    optCon = poptGetContext(namestart, argc, argv, optionsTable, 0);
    if ((i = poptGetNextOpt(optCon)) < -1) {
	fprintf(stderr, "%s: %s\n", 
		poptBadOption(optCon, POPT_BADOPTION_NOALIAS),
		poptStrerror(i));
	usage(namestart);
	return EXIT_FAILURE;
    }

    if (help) {
	usage(namestart);
	return(EXIT_USAGE);
    } else if (version) {
	printf ("%s " MDADD_VERSION " compiled for md " MD_VERSION "\n",
		argv[0]);
	return (EXIT_VERSION);
    }

    fp = fopen(configFile, "r");
    if (fp == NULL) {
        fprintf(stderr, "Couldn't open %s -- %s\n", configFile, strerror(errno));
        exit(EXIT_FAILURE);
    }

    if (parse_config(fp))
	exit(EXIT_FAILURE);

    if (readonly) {
         if (func != stop) {
	    fprintf(stderr, "Can do --readonly only with mdstop!\n");
	    return EXIT_FAILURE;
         }
         func = stop_ro;
    }
	

    if (all) {
	for (p = cfg_head; p; p = p->next)
	    exit_status += handleOneConfig(func, p);
    } else {
	args = poptGetArgs(optCon);
	if (!args) {
	    fprintf(stderr, "nothing to do!\n");
	    return EXIT_FAILURE;
	}

	while (*args) {
	    for (p = cfg_head; p; p = p->next) {
		if (strcmp(p->md_name, *args)) continue;
		exit_status += handleOneConfig(func, p);
		break;
	    }
	    if (!p) {
		fprintf(stderr, "device %s is not described in config file\n", *args);
		exit_status++;
	    }
	    args++;
	}
    }

    poptFreeContext(optCon);

    return (exit_status);
}

