#ifndef _SYS_SOCKET_H
#include <socket/sys/socket.h>

/* Now define the internal interfaces.  */
extern int __socket __P ((int __domain, int __type, int __protocol));
#endif
