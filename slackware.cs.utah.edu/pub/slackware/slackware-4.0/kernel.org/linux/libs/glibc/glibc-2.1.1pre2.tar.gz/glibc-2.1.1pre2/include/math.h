#ifndef	_MATH_H

#include <math/math.h>

/* Now define the internal interfaces.  */
extern int __matherr __P ((struct exception *__exc));

#endif
