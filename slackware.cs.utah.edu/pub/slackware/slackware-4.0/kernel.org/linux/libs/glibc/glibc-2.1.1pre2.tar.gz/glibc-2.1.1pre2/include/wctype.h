#ifndef _WCTYPE_H

#include <wctype/wctype.h>

extern int __iswspace __P ((wint_t __wc));

#endif
