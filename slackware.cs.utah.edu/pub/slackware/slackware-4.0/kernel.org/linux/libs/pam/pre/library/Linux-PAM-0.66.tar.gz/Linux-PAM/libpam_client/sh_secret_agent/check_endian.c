#include <unistd.h>
#include <endian.h>

void main()
{
    exit(__BYTE_ORDER == __LITTLE_ENDIAN);
}
