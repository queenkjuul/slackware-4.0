if [ ! -r etc/named.conf ]; then
  mv etc/named.conf-sample etc/named.conf
fi
