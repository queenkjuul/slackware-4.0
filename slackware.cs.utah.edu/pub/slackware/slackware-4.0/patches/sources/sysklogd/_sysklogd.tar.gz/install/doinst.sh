if [ -r var/log/debug ]; then
  rm var/log/debug.in
else
  mv var/log/debug.in var/log/debug
fi
if [ -r var/log/messages ]; then
  rm var/log/messages.in
else
  mv var/log/messages.in var/log/messages
fi
if [ -r var/log/syslog ]; then
  rm var/log/syslog.in
else
  mv var/log/syslog.in var/log/syslog
fi
( cd usr/man/man8 ; rm -rf syslogd.8.gz )
( cd usr/man/man8 ; ln -sf sysklogd.8.gz syslogd.8.gz )
