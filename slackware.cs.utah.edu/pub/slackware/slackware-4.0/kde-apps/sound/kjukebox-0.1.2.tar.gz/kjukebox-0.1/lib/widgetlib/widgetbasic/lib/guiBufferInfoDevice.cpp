/*
  gui part shows the audioBuffer fillgrade
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <guiBufferInfoDevice.h>




GuiBufferInfoDevice::GuiBufferInfoDevice(QWidget *parent=0, 
			       const char *name=0):GuiDevice( parent, name ) {
  streamInfoDevice=new StreamInfoDevice();
  streamInfoDevice->setEventMask(_STREAMINFO_BUFFERFILL_CHANGE);
  setDevice(streamInfoDevice);
  setMinimumSize( sizeHint() );
  currentFillgrade=0;
}


GuiBufferInfoDevice::~GuiBufferInfoDevice() {
  delete streamInfoDevice;
}


void GuiBufferInfoDevice::processEvent(char eventId) {
  if (getFillgrade() <= 97) {
    update();
  } else {
    if (currentFillgrade != 100) {
      update();
    }
  }
 
}


int GuiBufferInfoDevice::getFillgrade() {
  AudioBuffer* audioBuffer=streamInfoDevice->getAudioBuffer();
  int percent=(int)(100.0*audioBuffer->getMainBufferFillgrade());
  return percent;
}


QSize GuiBufferInfoDevice::sizeHint () {
  return QSize(10,15);
}


void GuiBufferInfoDevice::paintEvent ( QPaintEvent * paintEvent ) {
  QPainter paint;
  char zahl[10];

  currentFillgrade=getFillgrade();
  // avoid flicker between fillgrade 100 and 99
  // this give 3% more speed gain for my Xserver (P166)
  if (currentFillgrade >= 97) {
    currentFillgrade=100;
  }

  snprintf((char*)&zahl,10,"%d",currentFillgrade);

  paint.begin( this );
  paint.drawText(0,10,zahl);
  paint.end();  

  clearNotifyBit();
}
