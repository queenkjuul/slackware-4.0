

#ifndef __YAF_CONTROL_H
#define __YAF_CONTROL_H


extern "C++" {

#include <yafcore/inputInterface.h>
#include <yafcore/outputInterface.h>
#include <yafxplayer/inputDecoderXPlayer.h>
#include <yafcore/parser.h>
#include <stdiostream.h>
}


#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>



// prototypes

//extern "C" void control_xplayer();
void yaf_control(InputInterface* input,
		     OutputInterface* output,
		     InputDecoder* decoder);

#endif
