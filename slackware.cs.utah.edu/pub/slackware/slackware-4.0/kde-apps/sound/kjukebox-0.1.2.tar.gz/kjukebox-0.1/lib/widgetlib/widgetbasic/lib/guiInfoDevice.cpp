/*
  gui part for the info device (very simple)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <guiInfoDevice.h>




GuiInfoDevice::GuiInfoDevice(QWidget *parent=0, 
			       const char *name=0):GuiDevice( parent, name ) {

  infoString=new Buffer(10);

  setMinimumSize( sizeHint() );
  streamInfoDevice=new StreamInfoDevice();
  streamInfoDevice->setEventMask(_STREAMINFO_MUSIC_CHANGE|
				 _STREAMINFO_ID3_CHANGE);
  setDevice(streamInfoDevice);

  infoDeviceConfig=new InfoDeviceConfig("InfoDeviceConfig",getPreferences());
  getPreferences()->setCaption(streamInfoDevice->getNodeName());
  getPreferences()->addTab(infoDeviceConfig,infoDeviceConfig->getGroupName());
  insertMenu("Configure",this,SLOT(configure()));
  connect(infoDeviceConfig,SIGNAL(applyEvent()), this, SLOT(apply()));

}


GuiInfoDevice::~GuiInfoDevice() {
  delete infoString;
  delete streamInfoDevice;
}



void GuiInfoDevice::configure() {
  getPreferences()->show();
  apply();
}


void GuiInfoDevice::apply() {
  processEvent(_STREAMINFO_ID3_CHANGE);
}


void GuiInfoDevice::mousePressEvent ( QMouseEvent* mouseEvent) {
  if (mouseEvent->button() ==  RightButton) {
    cout << "RightButton"<<endl;
    KPopupMenu* popupMenu=createPopupMenu();
    popupMenu->move(mapToGlobal(QPoint(mouseEvent->x(),mouseEvent->y())));
    popupMenu->exec();
    delete popupMenu;
  }
}



void GuiInfoDevice::processEvent(char eventId) {
  cout <<"GuiInfoDevice::processEvent"<<endl;
  repaint(false);
}


char* GuiInfoDevice::getInfoString() {
  infoDeviceConfig->translate(streamInfoDevice->getMusicInfo(),
			      streamInfoDevice->getID3Info(),
			      infoString);
  return infoString->getData();
}


char* GuiInfoDevice::getName() {
  MusicInfo* musicInfo=streamInfoDevice->getMusicInfo();
  return musicInfo->getName();
}


int GuiInfoDevice::getLen() {
  MusicInfo* musicInfo=streamInfoDevice->getMusicInfo();
  return musicInfo->getLen();
}


QSize GuiInfoDevice::sizeHint () {
  return QSize(140,40);
}


void GuiInfoDevice::paintEvent ( QPaintEvent * paintEvent ) {
  QPainter paint;

  erase(0,0,width(),height());
  paint.begin( this );
  paint.drawText(0,10,getInfoString());
  paint.end();  

  clearNotifyBit();
}



