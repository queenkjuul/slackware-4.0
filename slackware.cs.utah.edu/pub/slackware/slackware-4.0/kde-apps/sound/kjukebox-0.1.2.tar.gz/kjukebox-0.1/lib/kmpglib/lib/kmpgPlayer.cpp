/*
  a basic player
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include "kmpgPlayer.h"



KmpgPlayer::KmpgPlayer(Playlist* playlist,QWidget *parent, const char *name) :
  QWidget(parent,name) { 

  this->playlist=playlist;
  filename=new Buffer(40);
  connect(playlist,SIGNAL(playSongEvent(int)),this,SLOT(playSongEvent(int)));
  setBackgroundColor (QColor(0,0,0));
  buildGUI();
}


KmpgPlayer::~KmpgPlayer() {
  // Every device in the tree must be deleted seperatley:
  if (aDecoder != NULL) {
    delete aDecoder;
  }
  delete multicastDevice;
  delete filename;
} 




/*
  The yafDecoder cannot be handled like an ordinary
  device (on this level).
*/
void KmpgPlayer::setGenericPlayer(GenericPlayer* aDecoder) {

  this->aDecoder=aDecoder;

  MetaPlayer::setGenericPlayer(aDecoder);
  
  if (aDecoder != NULL) {
  connect(aDecoder->getEventQueue(),SIGNAL(processEvent(char)),
	  this,SLOT(processEvent(char)));
  }
  guiJumpDevice->setGenericPlayer(aDecoder);
}



void KmpgPlayer::processEvent(char eventId) {
  switch(eventId) {
  case _GS_SIGNAL_PLAYING_READY: {
    playNext();
    break;
  }
  case _GS_SIGNAL_GENERATOR_CRASHED: {
    decoderCrash();
    break;
  }
  }
  if (aDecoder != NULL) {
    (aDecoder->getEventQueue())->clearNotifyBit();
  }

}
 


OutputDevice* KmpgPlayer::getInternalDeviceTree() {
  // this method is used by the metaPlayer. It return
  // the root node of the devicetree.
  return multicastDevice;
}


void KmpgPlayer::addListener(NodeDevice* listener) {
  multicastDevice->addListener(listener);
}


void KmpgPlayer::playSongEvent(int index) {
  Song* song=playlist->at(index);
  if (song != NULL) {
    KURL* url=song->getSong();
    filename->setData((char*)url->path());
    MetaPlayer::open(filename->getData());
  }
}

void KmpgPlayer::play() {
  if (filename->len() == 0) {
    PlaylistOperation::playCurrent(playlist);
  } else {
    MetaPlayer::play();
  }
}


void KmpgPlayer::pause() {
  MetaPlayer::pause();
}

  
void KmpgPlayer::stop() {
  MetaPlayer::close();
}

void KmpgPlayer::playNext() {
  PlaylistOperation::playNext(playlist);
}


void KmpgPlayer::playPrev() {
  PlaylistOperation::playPrev(playlist);
}


void KmpgPlayer::decoderCrash() {
  Buffer* msg=new Buffer(50);
  msg->setData("Your decoder takes a trip to nirvana!\n\n");
  msg->append( "song: ");
  msg->append( filename->getData());
  msg->append("\n\ncrashprotection(tm)+autorestart(tm) v1.0");

  KMsgBox::message(this,"nirvana warning",msg->getData());
  delete msg;

  // Start a new one.
  GenericPlayer* aDecoder=getGenericPlayer();
  DataGenerator* generator=aDecoder->getDataGenerator();
  int id=generator->getDecoderId();
  setGenericPlayer(NULL);
  delete aDecoder;
  aDecoder=Amplifier::createPlayer(id);
  setGenericPlayer(aDecoder);
  
  playNext();
}


void KmpgPlayer::buildGUI() {
  OutputDevice* outputDevice;

  QBoxLayout* topLayout = new QVBoxLayout( this, 1 );

  QBoxLayout* b = new QHBoxLayout();

  topLayout->addLayout(b);


  multicastDevice = new MulticastDevice();

  
  guiSpectrumAnalyser = new GuiSpectrumAnalyser(this);
  outputDevice=guiSpectrumAnalyser->getDevice();
  b->addWidget(guiSpectrumAnalyser);
  multicastDevice->addListener(outputDevice);

  
  statusWidget = new StatusWidget(this);
  outputDevice=statusWidget->getDevice();
  b->addWidget(statusWidget);
  multicastDevice->addListener(outputDevice);
  

  timerWidget = new TimerWidget(this);
  outputDevice=timerWidget->getDevice();
  b->addWidget(timerWidget);
  multicastDevice->addListener(outputDevice);

  QBoxLayout* b3 = new QVBoxLayout();
  b->addLayout(b3);

  
  volumeWidget = new VolumeWidget(this);
  volumeWidget->buildGui();
  outputDevice=volumeWidget->getDevice();
  b3->addWidget(volumeWidget);
  multicastDevice->addListener(outputDevice);
  

  guiBalanceDevice = new GuiBalanceDevice(-100,100,1,0,
					  KSlider::Horizontal,this);
  guiBalanceDevice->setBalance(volumeWidget->getBalance());
  b3->addWidget(guiBalanceDevice);
  connect(guiBalanceDevice,SIGNAL(balanceChange(int)),
	  volumeWidget,SLOT(setBalance(int)));

  

  QBoxLayout* b1 = new QVBoxLayout();
  topLayout->addLayout(b1);


  infoWidget = new InfoWidget(this);
  outputDevice=infoWidget->getDevice();
  b1->addWidget(infoWidget);
  multicastDevice->addListener(outputDevice);



  guiJumpDevice = new GuiJumpDevice(this);
  outputDevice=guiJumpDevice->getDevice();
  guiJumpDevice->buildGui();
  b1->addWidget(guiJumpDevice);
  multicastDevice->addListener(outputDevice);
  

  QBoxLayout* b2 = new QHBoxLayout();
  topLayout->addLayout(b2);

  controlWidget = new ControlWidget(this); 
  connect(controlWidget,SIGNAL(playNextEvent()),this,SLOT(playNext()));
  connect(controlWidget,SIGNAL(playPrevEvent()),this,SLOT(playPrev()));
  connect(controlWidget,SIGNAL(playCurrentEvent()),this,SLOT(play()));
  connect(controlWidget,SIGNAL(playPauseEvent()),this,SLOT(pause()));
  connect(controlWidget,SIGNAL(playStopEvent()),this,SLOT(stop()));
  controlWidget->buildGui();
  b2->addWidget(controlWidget);

  QBoxLayout* b4 = new QVBoxLayout();
  QBoxLayout* b5 = new QHBoxLayout();
  QBoxLayout* b6 = new QHBoxLayout();
  
  b2->addLayout(b4);
  b4->addLayout(b5);
  b4->addLayout(b6);
  

  guiBufferInfoDevice = new GuiBufferInfoDevice(this);
  outputDevice=guiBufferInfoDevice->getDevice();
  b5->addWidget(guiBufferInfoDevice);
  multicastDevice->addListener(outputDevice);

  guiShuffle = new GuiShuffle("Rnd:",this);
  b5->addWidget(guiShuffle);
  guiShuffle->setChecked(playlist->getShuffle());
  connect(guiShuffle,SIGNAL(setShuffleEvent(int)),
	  playlist,SLOT(setShuffle(int)));
  connect(playlist,SIGNAL(setShuffleEvent(int)),
	  guiShuffle,SLOT(setShuffle(int)));
  
  guiRepeat = new GuiRepeat("Cnt:",this);
  b5->addWidget(guiRepeat);
  guiRepeat->setChecked(playlist->getRepeat());
  connect(guiRepeat,SIGNAL(setRepeatEvent(int)),
	  playlist,SLOT(setRepeat(int)));
  connect(playlist,SIGNAL(setRepeatEvent(int)),
	  guiRepeat,SLOT(setRepeat(int)));


  guiStereoDevice = new GuiStereoDevice(this);
  outputDevice=guiStereoDevice->getDevice();
  b6->addWidget(guiStereoDevice);
  multicastDevice->addListener(outputDevice);


  guiFreqDevice = new GuiFreqDevice(this);
  outputDevice=guiFreqDevice->getDevice();
  b6->addWidget(guiFreqDevice);
  multicastDevice->addListener(outputDevice);


  guiBPSDevice = new GuiBPSDevice(this);
  outputDevice=guiBPSDevice->getDevice();
  b6->addWidget(guiBPSDevice);
  multicastDevice->addListener(outputDevice);

    
}

 


