/*
  a view for a pathMapperList.
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <pathMapperListView1.h>


PathMapperListView1::PathMapperListView1( PathMapperList* pathMapperList,
					  QWidget * parent=0, 
					  const char * name=0) 
  :  QListBox( parent, name) {

  this->pathMapperList=pathMapperList;
  connect(pathMapperList,SIGNAL(addPathMapperEvent(PathMapper*)),
	  this,SLOT(addPathMapperEvent(PathMapper*)));
  connect(pathMapperList,SIGNAL(removePathMapperEvent(int)),
	  this,SLOT(removePathMapperEvent(int)));
  connect(pathMapperList,SIGNAL(setCurrentPosEvent(int)),
	  this,SLOT(setCurrentPosEvent(int)));
  connect(this,SIGNAL(selected(int)),this,SLOT(selected(int)));
  connect(this,SIGNAL(highlighted(int)),this,SLOT(highlighted(int)));
  connect(pathMapperList,SIGNAL(pathMapperUpdateEvent(PathMapper*,int)),
	  this,SLOT(update()));
}


  
PathMapperListView1::~PathMapperListView1() {
}


void PathMapperListView1::addPathMapperEvent(PathMapper* pathMapper) {
  PathMapperView1* pathMapperView1=new PathMapperView1(pathMapper);
  cout << "addPathMapperEvent:"<<endl;
  insertItem(pathMapperView1);
}


void PathMapperListView1::removePathMapperEvent(int index) {
  removeItem(index);
}


void PathMapperListView1::highlighted(int index) {
  cout << "highlighted"<<index<<endl;
  pathMapperList->setCurrentPos(index);
}


void PathMapperListView1::selected(int index) {
  cout << "selected"<<index<<endl;
  pathMapperList->setCurrentPos(index);
}


void PathMapperListView1::setCurrentPosEvent(int index) {
  int pos=currentItem();
  if (pos != index) {
    setCurrentItem(index);
  }
}







