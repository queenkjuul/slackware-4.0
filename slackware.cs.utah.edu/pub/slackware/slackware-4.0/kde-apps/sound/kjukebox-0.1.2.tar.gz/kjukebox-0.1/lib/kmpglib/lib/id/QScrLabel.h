/* Copyright 1997, lvoge@cs.vu.nl */
#ifndef QSCRLABEL_H
#define QSCRLABEL_H

#include <qlabel.h>

class QString;
class QTimer;

class QScrLabel : public QLabel {
	Q_OBJECT
 public:
	QScrLabel(QWidget* parent=0, const char* name=0, WFlags f=0);
	QScrLabel(const char* text, QWidget* parent=0, const char* name=0, WFlags f=0);
	virtual ~QScrLabel(void);
 public slots:
	void setLabel(const char *);
 private slots:
	void scroll();
 private:
	int maxscroll, dir, pos;
	QString *string;
	QTimer *timer;
};

#endif
