/*
  works together with the deviceConfigServer <-> producer Interface
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <devices/genericPlayer.h>

static int producerCounter=0;

static void *writerThread(void *arg){
  ((GenericPlayer*)arg)->writeloop();
  return NULL;
}   




GenericPlayer::GenericPlayer() {
  config=new DeviceConfig();
  
  lExit=false;
  lGeneratorEnter=false;
  instanz=producerCounter;
  producerCounter++;
  lastFileName=new Buffer(40);
  getEventQueue()->setNotifyMode(_NOTIFY_ALL);
  pthread_create(&tr,NULL,writerThread,this);
}


GenericPlayer::~GenericPlayer() {
  void* ret;
  writeOutLock();
  lExit=true;
  writeOutUnlock();
  pthread_join(tr,&ret);
  if (generator != NULL) {
    delete generator;
  }
  delete lastFileName;
  delete config;
}



char* GenericPlayer::getNodeName() {
  return "GenericPlayer";
}


int GenericPlayer::open(char* filename ) {
  if (generator != NULL) {
    generator->open(filename);
    lastFileName->clear();
    lastFileName->append(filename);
  }
  return true;
}

int GenericPlayer::close() {
  if (generator != NULL) {
    generator->close();
  }
  return true;
}


int GenericPlayer::play() {
  if (generator != NULL) {
    // this implements a common interface behaviour.
    // if we are stopped and we click "play"
    // we play the last file we have already played
    if (getStreamState() == _STATUS_STOPPED) {
      generator->open(lastFileName->getData());
    } else {
      generator->play();
    }
  }
  return true;
}


int GenericPlayer::pause() {
  if (generator != NULL) {

    if (getStreamState() == _STATUS_STOPPED) {
      return true;
    }
    // This is a common interface behaviour.
    // If we are paused and we hit "pause" again
    // we try a "play"
    if (getStreamState() == _STATUS_PAUSED) {
      generator->play();
    } else {
      generator->pause();
    }
  }
  return true;
}


int GenericPlayer::jump(int sec) {
  if (generator != NULL) {
    generator->jump(sec);
  }
  return true;
}

/**
   The streamState is the value int the statutInfo of the stream.
   Not the status of the thread!
*/
int GenericPlayer::getStreamState() {
  int back;
  
  StatusInfo* statusInfo=config->getStatusInfo();
  back=statusInfo->getStatus();
  return back; 
}


void GenericPlayer::setDataGenerator(DataGenerator* generator) {
  writeOutLock();
  this->generator=generator;
  generator->setThreadNotifier(this);
  writeOutUnlock();
}


DataGenerator* GenericPlayer::getDataGenerator() {
  return generator;
}


//
// ThreadNotifer Interface [START]
//


void GenericPlayer::sendSyncMessage(int msg) {
  writeOutLock();
  switch(msg) {
  case _ALLOW_GENERATOR_ENTER: {
    this->lGeneratorEnter=true;
    break;
  }
  case _NOT_ALLOW_GENERATOR_ENTER: {
    this->lGeneratorEnter=false;
    break;
  }
  case _GENERATOR_CRASHED: {
    getEventQueue()->sendEvent(_GS_SIGNAL_GENERATOR_CRASHED); 
    break;
  }
  default:
    cout << "unknown msg: "<<msg<<" in sendSyncMessage"<<endl;
  }
  writeOutUnlock();
}



//
// ThreadNotifier Interface [END]
//


/**
   The writeloop method is a single thread. It must be sure that
   the thread never blocks in the function below this.
   This is the only method where the thread can sleep.

   The thread delivers two different informations.
   One information is a statusInformation. If it delivers
   this no other info in the deviceConfig class is new.
   (no new audio pcm sample, no new musictitle etc,...)
   Only the status _change_ is delivered.

   If there is no status change to deliver, the thread
   delivers the things with minor priority. eg. pcm samples,...

*/

void GenericPlayer::writeloop() {
  DeviceConfigArray* configArray=new DeviceConfigArray();
  AudioBuffer* audioBuffer=config->getAudioBuffer();
  MemChunk* memChunk;
  MemChunk* emptyChunk=new MemChunk(0);
  int deliverMode;
  int last=false;

  config->setStreamProducer(this);
  pthread_mutex_lock(&deliverMut);

  while(lExit==false) {
    deliverMode=getDeliverMode();
    if (pthread_mutex_trylock(&changeMut) == EBUSY) {
      cout << "change request -s"<<endl;
      pthread_cond_wait(&deliverCond,&deliverMut);
      cout << "change request -e"<<endl;
      continue;
    }
    waitForUnblock(); 
    pthread_mutex_unlock(&changeMut);


    if (deliverMode==_STREAMPRODUCER_DELIVERS_SINGLE) {
      getEventQueue()->sendEvent(_STREAMPRODUCER_DELIVERS_SINGLE);
      cout << "deliverMode == single. Thread goes sleeping"<<endl;
      setRunCredit(0);
      pthread_cond_wait(&deliverCond,&deliverMut);
      cout << "writeloop continues change request ready"
	   << "instanz:"<<instanz<<"name:"<<lastFileName->getData()<<endl;
      if (getRunCredit() == 0) {
	continue;
      }
    }   

    
    // Now two possibilities:
    // 1. we have _no_ thread state to deliver (then we deliver data)
    // 2. wa have a thread state. (then we deliver it)
    
    if (hasAsyncMessage() == true) {
      StatusInfo* statusInfo=config->getStatusInfo();
      AudioBuffer* audioBuffer=config->getAudioBuffer();
      int msg=getAsyncMessage();
      int state;
      // now a mapping from async thread message to stream messages
      switch(msg) {
      case _STOP_WORKING: {
	state=_STATUS_STOPPED;
	break;
      } 
      case _PAUSE_WORKING: {
	state=_STATUS_PAUSED;
	break;
      }
      case _START_WORKING: {
	state=_STATUS_PLAYING;
	break;
      }
      case _STOP_WORKING_BECAUSE_EOF: {
	getEventQueue()->sendEvent(_GS_SIGNAL_PLAYING_READY); //send to gui
	continue; // do not deliver this one
      }
      default:
	cout << "unknown threadstate -> streamState mapping (ignored)"<<endl;
	continue;
      }
      statusInfo->setStatus(state);
      audioBuffer->setMemChunk(emptyChunk);
    } else {
      if (lGeneratorEnter== false) {
	pthread_cond_wait(&deliverCond,&deliverMut);
	continue;
      }       
      last=generator->updateDeviceConfig(config);
    }
    // ok now we have read data. Make sure this is
    // delivered to the device.
    if ( hasListener() ) {
      configArray->clear();
      configArray->setDeviceConfigAt(0,config);
      configArray->setEntries(1);
      config->setStreamProducer(this);
      memChunk=audioBuffer->getMemChunk();
      memChunk->addLock();
      writeOut(configArray);
      config->setChangeToAll(false);
      memChunk->removeLock();

      pthread_mutex_unlock(&deliverMut);
      if (last == true) {
	sendAsyncMessage(_STOP_WORKING_BECAUSE_EOF);
	sendAsyncMessage(_STATUS_STOPPED);
      }
      pthread_mutex_lock(&changeMut);
      pthread_mutex_lock(&deliverMut);
      pthread_mutex_unlock(&changeMut);
      if (last == true) {
	lGeneratorEnter=false;
	last=false;
      }
     } else {
      pthread_cond_wait(&deliverCond,&deliverMut);
    }
  }
  pthread_mutex_unlock(&deliverMut);
  delete configArray;
  delete emptyChunk;
}
  


 
void GenericPlayer::writeOut(DeviceConfigArray* buf) {
  int i;
  int j;
  NodeDevice* nodeDevice;
  DeviceConfig* config;
  int m=buf->getEntries();
  Edges* edges=getListeners();
  int n=edges->getElements();

  for(j=0;j<m;j++) {
    config=buf->getDeviceConfigAt(j);
    for(i=0;i<n;i++) {
      nodeDevice=edges->getNodeDevice(i);
      nodeDevice->writeInLock();
      nodeDevice->writeIn(this,config);
      nodeDevice->writeInUnlock();
    }
  }
}



