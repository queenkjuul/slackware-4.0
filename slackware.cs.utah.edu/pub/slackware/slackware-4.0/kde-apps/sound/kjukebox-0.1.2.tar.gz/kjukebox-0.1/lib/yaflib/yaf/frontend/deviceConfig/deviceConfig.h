/*
  stores deviceConfig data
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __DEVICECONFIG_H
#define __DEVICECONFIG_H

#include <iostream.h>
#include <deviceConfig/audioInfo.h>
#include <deviceConfig/volumeInfo.h>
#include <deviceConfig/musicInfo.h>
#include <deviceConfig/statusInfo.h>
#include <deviceConfig/audioBuffer.h>
#include <deviceConfig/videoInfo.h>
#include <deviceConfig/timeInfo.h>
#include <deviceConfig/id3Info.h>
#include <deviceConfig/mp3Info.h>

#define _DEFAULT_BUFFERSIZE 4096


/**
  DeviceConfig stores all the data which may be useful for a device.
  It stores the PCM data. The samplespeed (44.1KHz) etc...
  <p>
  A device can handle stream data (audio,video). But not
  every device is interested in all data. An audioDevice
  for example only is interested in the speed/sampleSize/stereo
  and a multicast device is not interested in the data at all.
  <p>
  But not all configuration options should be in the 
  device config. Only these which are important for the 
  stream data (the meta data) is in the deviceConfig.
  For example a spectrumAnalyser device has the configuartion
  options: -number of bands.
  <p>
  This is not important for the stream. Thus this data
  is stored not in this structure.

*/


class DeviceConfig {


  friend class Info;

  AudioInfo* audioInfo;
  VolumeInfo* volumeInfo;
  MusicInfo* musicInfo;
  StatusInfo* statusInfo;
  AudioBuffer* audioBuffer;
  VideoInfo* videoInfo;
  TimeInfo* timeInfo;
  MP3Info* mp3Info;
  ID3Info* id3Info;
  void* streamProducer;
  
 public:
  DeviceConfig();
  ~DeviceConfig();

  void copyTo(DeviceConfig* aConfig);
  void setChangeToAll(int change);

  void setAudioInfo(AudioInfo* audioInfo); 
  AudioInfo* getAudioInfo(); 

  void setVolumeInfo(VolumeInfo* volumeInfo); 
  VolumeInfo* getVolumeInfo(); 
  
  void setMusicInfo(MusicInfo* musicInfo);
  MusicInfo* getMusicInfo();

  
  void setStatusInfo(StatusInfo* statusInfo);
  StatusInfo* getStatusInfo();

  void setAudioBuffer(AudioBuffer* aBuffer); 
  AudioBuffer* getAudioBuffer(); 
 
  void setVideoInfo(VideoInfo* videoInfo);
  VideoInfo* getVideoInfo();

  void setTimeInfo(TimeInfo* timeInfo);
  TimeInfo* getTimeInfo();

  void setID3Info(ID3Info* aID3Info);
  ID3Info* getID3Info();

  void setMP3Info(MP3Info* aMP3Info);
  MP3Info* getMP3Info();

  // streamProducer are stored as a void pointer because
  // of a recursive inclusion!
  // you should safley cast it where you need it.
  void* getStreamProducer();
  void setStreamProducer(void* streamProducer);

  void print();

};



#endif
