/*
  root window for kmpg (menu and all this stuff)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __KMPGROOTWINDOW_H
#define __KMPGROOTWINDOW_H

// QT include files
#include <qpopmenu.h>
#include <qaccel.h>

// Player include files:
#include <kmpgPlayer.h>
#include <pathMapperConfig.h>

// KDE include files
#include <kapp.h>
#include <kmenubar.h>
#include <ktmainwindow.h>


#include <playlistView2.h>
#include <id/playlistView3.h>
#include <playlistOperation.h>
#include <preferences.h>
#include <mixerConfig.h>
#include <iostream.h>


class KmpgRootWindow : public KTMainWindow {
  Q_OBJECT
 public:
  KmpgRootWindow(QWidget *parent=0, const char *name=0);
  ~KmpgRootWindow();

  void setPlayer(KmpgPlayer* player);
  KmpgPlayer* getPlayer();

  Playlist* getPlaylist();
  Preferences* getPreferences();
  
  
 signals:
  void open(KURL* url);

 public slots:
  void openFileSelector();
  void onDrop( KDNDDropZone* );


 private:
  void buildMenuBar();

  KmpgPlayer* player;
  Playlist* playlist;
  KDNDDropZone* dropZone;
  PlaylistView2* playlistView2;
  Preferences* preferences;
  MixerConfig* mixerConfig;
  PathMapperConfig* pathMapperConfig;
  PlaylistView3* playlistView3;

};
#endif
