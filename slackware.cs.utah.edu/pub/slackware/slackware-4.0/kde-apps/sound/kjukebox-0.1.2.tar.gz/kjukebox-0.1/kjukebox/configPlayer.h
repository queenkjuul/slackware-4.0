/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#ifndef CONFIGPLAYER_H
#define CONFIGPLAYER_H

#include <kapp.h>
#include <kconfig.h>
#include <qwidget.h>
#include <qgrpbox.h>
#include <qchkbox.h>
#include <qframe.h>
#include <qcombobox.h>
#include <klined.h>
#include <kconfig.h>
#include <qlabel.h>
#include "configfolder.h"
#include "kjukebox.h"

class ConfigPlayer : public QWidget{
  Q_OBJECT
 private:
  KConfig   *config;
  QGroupBox *boxTime;
  QGroupBox *boxDevice;
  QGroupBox *boxPriority;

  QCheckBox *enableDefaultTime;
  QCheckBox *enableFadeOut;
  QCheckBox *enableMixing;
  KLined *firstSecBox;
  KLined *lastSecBox;
  KLined *audioDevBox;
  QLabel *firstSecBoxLabel;
  QLabel *lastSecBoxLabel;
  QLabel *audioDevBoxLabel;
  QLabel *mixingLabel;

  QComboBox *priorityPlayerBox;
  QLabel    *priorityPlayerLabel;

  bool    defaultTime;
  bool    fadeOut;
  bool    mixing;
  int     priorityPlayer;
  int     firstSeconds;
  int     lastSeconds;
  QString audioDevice;

 protected:
  void resizeEvent(QResizeEvent *);
 public:
  ConfigPlayer( QWidget *parent=0,  const char *name=0 );
  
  public slots:
    void setDefaultTime();
  void cancel();
  void accept();
  
};

#endif
