/*
  abstract filter class
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */

 

#include <filter/filter.h>


static Accelerator* acc=new Accelerator();


Filter::Filter() {
}


Filter::~Filter() {
}


// usefull for the algorithms in the filter
Accelerator* Filter::getAccelerator() {
  return acc;
}

void Filter::transform(DeviceConfigArray* input,DeviceConfig* output) {
  cout << "not implemented"<<endl;
}

void Filter::transform(DeviceConfig* input,DeviceConfig* output) {
  cout << "not implemented"<<endl;
}


