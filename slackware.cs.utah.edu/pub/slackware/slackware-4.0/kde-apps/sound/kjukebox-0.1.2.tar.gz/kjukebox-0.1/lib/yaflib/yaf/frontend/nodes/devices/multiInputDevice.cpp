/*
  stores input sources and delivers them simultaneously (abstract class) 
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <devices/multiInputDevice.h>

MultiInputDevice::MultiInputDevice() {
  multiQueueFifo=new MultiQueueFifo();
  configArray=new DeviceConfigArray();
  fifo=new DeviceConfigFifo();
}


MultiInputDevice::~MultiInputDevice() {
  delete multiQueueFifo;
}



char* MultiInputDevice::getNodeName() {
  return "MultiInputDevice";
}



void MultiInputDevice::writeIn(NodeDevice* source,DeviceConfig* config) {
  StreamProducer* producer; 
  
  /**
       How to do a correct multiInputDevice? I think a good
       solutions would be to make it a derived class of streamProducer.
       Then multiInputDevice has its own thread.
       This should give better perfomance.
    */
    

  producer=(StreamProducer*)config->getStreamProducer();
  multiQueueFifo->enqueue(producer,config);
  if (multiQueueFifo->canSimultaneousDequeue()) {
    DeviceConfigArray* buf=multiQueueFifo->multiDequeue();
    writeOut(buf);
    multiQueueFifo->multiForward();
  }
}


void MultiInputDevice::writeOut(DeviceConfigArray* buf) {
  
}


