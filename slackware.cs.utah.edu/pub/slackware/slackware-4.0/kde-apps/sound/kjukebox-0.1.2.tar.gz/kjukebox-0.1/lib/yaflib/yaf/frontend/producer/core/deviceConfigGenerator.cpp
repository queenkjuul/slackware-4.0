/*
  a generic data producer for deviceConfig entries
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <producer/core/deviceConfigGenerator.h>


DeviceConfigGenerator::DeviceConfigGenerator() {
  threadNotifier=NULL;
}


DeviceConfigGenerator::~DeviceConfigGenerator() {
}


void DeviceConfigGenerator::setThreadNotifier(ThreadNotifier* threadNotifier) {
  this->threadNotifier=threadNotifier;
}


ThreadNotifier* DeviceConfigGenerator::getThreadNotifier() {
  return threadNotifier;
}


int DeviceConfigGenerator::updateDeviceConfig(DeviceConfig* newConfig) {
  return true;
}





