/*
  a view for a playlist.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <playlistView2.h>

#define CAPTION(file) QString( klocale->translate("Playlist Editor: ") )+file

PlaylistView2::PlaylistView2(Playlist* playlist):QDialog() {

  buttonPanel = new QWidget( this );
  dropZone = new KDNDDropZone( buttonPanel, DndURL );
  connect( dropZone, SIGNAL( dropAction( KDNDDropZone* )),
	    SLOT( slotDrop( KDNDDropZone*)));
  this->playlist=playlist;
  playlistView1 = new PlaylistView1( playlist,this, "Playlist");
  setCaption( CAPTION("<noname>") );
  
  QPushButton *pb1 = new QPushButton(klocale->translate("Close"),buttonPanel);
  pb1->setGeometry( 10, 5, 80, 25 );
  QPushButton *pb2 = new QPushButton( klocale->translate("Load playlist"),
				      buttonPanel );
  pb2->setGeometry( 10, 40, 80, 25 );
  QPushButton *pb3 = new QPushButton( klocale->translate("Save playlist"), 
				      buttonPanel );
  pb3->setGeometry( 10, 65, 80, 25 );
  QPushButton *pb4 = new QPushButton( klocale->translate("Add playlist"), 
				      buttonPanel );
  pb4->setGeometry( 10, 100, 80, 25 );
  QPushButton *pb5 = new QPushButton( klocale->translate("Add MPEG"), 
				      buttonPanel );
  pb5->setGeometry( 10, 125, 80, 25 );
  QPushButton *pb6 = new QPushButton( "up", buttonPanel );
  pb6->setGeometry( 10, 160, 80, 12 );
  QPushButton *pb7 = new QPushButton( "dn", buttonPanel );
  pb7->setGeometry( 10, 172, 80, 12 );
  QPushButton *pb8 = new QPushButton( klocale->translate("Del MPEG"), 
				      buttonPanel );
  pb8->setGeometry( 10, 194, 80, 25 );
  QPushButton *pb9 = new QPushButton( klocale->translate("Clear list"), 
				      buttonPanel );
  pb9->setGeometry( 10, 219, 80, 25 );
  
  QPixmap pix;
  KIconLoader *loader = KApplication::getKApplication()->getIconLoader();
  pix = loader->loadIcon("up.xpm");
  pb6->setPixmap( pix );
  pix = loader->loadIcon("down.xpm");
  pb7->setPixmap( pix );

  connect( pb1, SIGNAL(clicked()), SLOT(hide()) );
  connect( pb2, SIGNAL(clicked()), SLOT(slotLoadPlaylist()) );
  connect( pb3, SIGNAL(clicked()), SLOT(slotSavePlaylist()) );
  connect( pb4, SIGNAL(clicked()), SLOT(slotAddPlaylist()) );
  connect( pb5, SIGNAL(clicked()), SLOT(slotAddMPEG()) );
  connect( pb6, SIGNAL(clicked()), SLOT(slotUp()) );
  connect( pb7, SIGNAL(clicked()), SLOT(slotDown()) );
  connect( pb8, SIGNAL(clicked()), SLOT(slotDelMPEG()) );
  connect( pb9, SIGNAL(clicked()), playlist, SLOT(clear()) );
  connect(playlist,SIGNAL(setNameEvent(char*)),this,SLOT(setNameEvent(char*)));
  
  setMinimumSize( 350, 250 );
  resize( 350, 250 ); // Use the smallest size by default
  KWM::setWmCommand( handle(), "" ); // Disable SM for this window
}

PlaylistView2::~PlaylistView2() {
}


void PlaylistView2::resizeEvent( QResizeEvent* ) {
  playlistView1->setGeometry( 5, 5, width()-105, height()-10 );
  buttonPanel->setGeometry( width()-100, 0, 100, height() );
}

void PlaylistView2::slotLoadPlaylist() {
  Playlist* newList;
  newList=PlaylistOperation::readPlaylist();
  if (newList != NULL) {
    playlist->clear();
    playlist->setName(newList->getName());
    PlaylistOperation::insert(newList,playlist);
  }
}

void PlaylistView2::slotSavePlaylist() {
  if (PlaylistOperation::writePlaylist(playlist)) {
  }
}


void PlaylistView2::slotAddPlaylist() {
  Playlist* newList;
  newList=PlaylistOperation::readPlaylist();
  if (newList != NULL) {
    playlist->setName(newList->getName());
    PlaylistOperation::insert(newList,playlist);
  }
}


void PlaylistView2::slotAddMPEG() {
  PlaylistOperation::loadSong(playlist);
}


void PlaylistView2::slotUp() {
  playlistView1->slotUp();
}


void PlaylistView2::slotDown() {
  playlistView1->slotDown();
}


void PlaylistView2::slotDelMPEG() {
  playlistView1->slotDelMPEG();
}

void PlaylistView2::slotDrop( KDNDDropZone* zone ) {
  PlaylistOperation::insert(zone,playlist);
}


void PlaylistView2::setNameEvent(char* name) {
  cout <<"setNameEvent::"<<name<<endl;
  setCaption( CAPTION(name) );

}



