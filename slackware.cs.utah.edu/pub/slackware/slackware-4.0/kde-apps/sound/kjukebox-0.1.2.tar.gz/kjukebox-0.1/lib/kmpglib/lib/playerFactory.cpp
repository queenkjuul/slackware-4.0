/*
  a default standalone player.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <playerFactory.h>


static int instanz=0;


PlayerFactory::PlayerFactory() {
}


PlayerFactory::~PlayerFactory() {
}


KmpgRootWindow* PlayerFactory::createKmpgRootWindow(int playerType) {
  GenericPlayer* decoder;
  KmpgRootWindow* rootWindow;
  KmpgPlayer* player;
  Playlist* playlist;
 
  // The question who owns these pointers is not decided yet!
  // memory leak!
  decoder=Amplifier::createPlayer(_MP3_DECODER);
  rootWindow=new KmpgRootWindow();
  playlist=rootWindow->getPlaylist();
  player=new KmpgPlayer(playlist,rootWindow);

  // here the gui part: (1st player)
  rootWindow->setGeometry(100+20*instanz,100+20*instanz,280,125);
  rootWindow->setPlayer(player);

  player->setGenericPlayer(decoder);

  instanz++;

  return rootWindow;
}



