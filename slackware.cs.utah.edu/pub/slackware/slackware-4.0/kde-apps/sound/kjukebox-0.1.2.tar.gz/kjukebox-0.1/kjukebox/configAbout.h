#ifndef CONFIGABOUT_H
#define CONFIGABOUT_H

#include <kconfig.h>
#include <qwidget.h>
#include <qlabel.h>
#include <qstring.h>
#include <qpixmap.h>
#include <qgroupbox.h>
#include "configfolder.h"

class ConfigAbout: public QWidget
{
    Q_OBJECT
 public:
  ConfigAbout(QWidget *parent=0, const char *name=0);
 protected:
  void resizeEvent (QResizeEvent *);
 private:  
  QGroupBox *box;
  QLabel    *label;
  QLabel    *hometext;
  QString    labelstring;
  QString    homestring;
  QPixmap    pix;
  QLabel    *logo;
  QString    version;

 public slots:
  void cancel();
  void accept();
};

#endif // EINSTELLUNGEN_H

