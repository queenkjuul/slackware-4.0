/*
  abstract preferences tab
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __PREFMODULE_H
#define __PREFMODULE_H

#include <qwidget.h>
#include <iostream.h>


class PrefConfig : public QWidget {
 Q_OBJECT

 public:
  PrefConfig(QWidget * parent=0, const char * name=0 );
  ~PrefConfig();

 public slots:
  virtual char* getGroupName();
  virtual void load();
  virtual void save();
  virtual void apply();

};
#endif
