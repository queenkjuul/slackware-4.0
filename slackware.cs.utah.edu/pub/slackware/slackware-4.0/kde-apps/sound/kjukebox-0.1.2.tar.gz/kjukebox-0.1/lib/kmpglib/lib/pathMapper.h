/*
  stores dos drivesnames and the unix path to it.
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __PATHMAPPER_H
#define __PATHMAPPER_H

#include <qstring.h> 
#include <iostream.h>
#include <qobject.h>
#include <yafcore/buffer.h>



class PathMapper : public QObject {
 Q_OBJECT

  Buffer* drive;
  Buffer* subst;
  Buffer* asString;
  Buffer* asFormat;
  
 public:
   PathMapper(char* format);
   ~PathMapper();

   char* getDrive();
   void setDrive(char* drive);

   char* getSubst();
   void setSubst(char* subst);

   char* toString();
   char* toFormat();

 signals:
   void pathMapperUpdateEvent(PathMapper* pathMapper);
};
#endif

