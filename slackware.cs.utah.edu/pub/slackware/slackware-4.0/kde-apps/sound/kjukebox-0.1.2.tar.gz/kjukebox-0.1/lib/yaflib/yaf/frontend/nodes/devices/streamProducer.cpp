/*
  produces data and sends them through the device graph
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <devices/streamProducer.h>


StreamProducer::StreamProducer()  {
  DaisyChain* daisyChain=(DaisyChain*)getDaisyChain();
  nBlockCounter=0;
  mode=_STREAMPRODUCER_DELIVERS_CONTINOUS;
  runCredit=0;
  daisyChain->addElement(this);
  pthread_mutex_init(&changeMut,NULL);
  pthread_mutex_init(&deliverMut,NULL);
  pthread_mutex_init(&counterMut,NULL);

  pthread_cond_init(&deliverCond,NULL);
  pthread_cond_init(&counterCond,NULL);
}



StreamProducer::~StreamProducer() {
  DaisyChain* daisyChain=(DaisyChain*)getDaisyChain();

  daisyChain->removeElement(this);
}


void StreamProducer::incBlockCounter() {
  pthread_mutex_lock(&counterMut);
  nBlockCounter++;
  pthread_cond_signal(&counterCond);
  pthread_mutex_unlock(&counterMut);
}


void StreamProducer::decBlockCounter() {
  pthread_mutex_lock(&counterMut);
  nBlockCounter--;
  pthread_cond_signal(&counterCond);
  pthread_mutex_unlock(&counterMut);
}
 


void StreamProducer::writeOutLock() {
  pthread_mutex_lock(&changeMut);
  pthread_mutex_lock(&deliverMut);
}


void StreamProducer::writeOutUnlock() {
  pthread_cond_signal(&deliverCond);
  pthread_mutex_unlock(&changeMut);
  pthread_mutex_unlock(&deliverMut);
}


void StreamProducer::waitForUnblock() {
  pthread_mutex_lock(&counterMut);
  writeOutUnlock();
  while(nBlockCounter>0) {
    pthread_cond_wait(&counterCond,&counterMut);
  }
  writeOutLock();
  pthread_mutex_unlock(&counterMut);
}
  
 
void StreamProducer::setDeliverMode(int mode) {
  writeOutLock();
  this->mode=mode;
  writeOutUnlock();
}

  
void StreamProducer::wakeup() {
  writeOutLock();
  runCredit=1;
  writeOutUnlock();
}


int StreamProducer::getDeliverMode() {
  return mode;
}
  
 

int StreamProducer::getRunCredit() {
  return runCredit;
}
  

void StreamProducer::setRunCredit(int value) {
  runCredit=value;
}









