/*
  a nicer widget for the timer.The default yaf widget are (supposed) to be ugly
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */






#ifndef __TIMERWIDGET_H
#define __TIMERWIDGET_H

#include <guiTimerDevice.h>
#include "led.h"

/**
   This widget show how you can add your own look and feel.
   Simple overwrite the paint method.

*/

class TimerWidget : public GuiTimerDevice {

  LED* led;

 public:
   TimerWidget( QWidget *parent=0, const char *name=0 );
  ~TimerWidget();


  QSize sizeHint ();
  void paintEvent ( QPaintEvent * paintEvent );
 

};
#endif
