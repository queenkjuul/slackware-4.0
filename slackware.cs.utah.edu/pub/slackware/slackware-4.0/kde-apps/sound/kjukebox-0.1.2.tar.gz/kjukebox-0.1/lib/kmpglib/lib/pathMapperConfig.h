/*
  converts dos path to unix hierarchical file
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __PATHMAPPERCONFIG_H
#define __PATHMAPPERCONFIG_H


#include <prefConfig.h>


#include <kconfig.h>
#include <kapp.h>

#include <qlabel.h>
#include <qpushbt.h>
#include <qbttngrp.h>
#include <qradiobt.h>
#include <qchkbox.h>
#include <qlined.h>
#include <qtabdlg.h>
#include <qlayout.h>
#include <qlistbox.h>
#include <qlineedit.h> 
#include <qregexp.h>
#include <pathMapperList.h>
#include <pathMapperListView1.h>
#include <kmsgbox.h>


class PathMapperConfig : public PrefConfig {
 Q_OBJECT
   
   KConfig* config;
   char* configGroup;
   int mode;

 public:
  PathMapperConfig(QWidget * parent=0, const char * name=0 );
  ~PathMapperConfig();

 public slots:
  char* getGroupName();
  void load();
  void save();
  void apply();
  void resizeEvent( QResizeEvent* );
  void deleteEvent();
  void addEvent();
  void setCurrentPosEvent(int index);
  void translate(char* filename,Buffer* target);


 private:
  PathMapperList* pathMapperList;
  PathMapper* currentEdit;

  QWidget *buttonPanel;
  QWidget *editPanel;
  PathMapperListView1* pathMapperListView1;
  QLineEdit* driveEdit;
  QLineEdit* substEdit;
  


};

#endif
