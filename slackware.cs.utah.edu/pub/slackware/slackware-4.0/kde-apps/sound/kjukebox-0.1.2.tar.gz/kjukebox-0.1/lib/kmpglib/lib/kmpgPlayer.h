/*
  a basic player
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */





#ifndef _PLAYER_H
#define _PLAYER_H


#include <qlayout.h>

#include <amplifier/amplifier.h>
#include <amplifier/metaPlayer.h>
#include <devices/multicastDevice.h>

#include <guiBufferInfoDevice.h>
#include <guiSpectrumAnalyser.h>
#include <guiJumpDevice.h>
#include <guiBalanceDevice.h>
#include <guiShuffle.h>
#include <guiRepeat.h>
#include <guiStereoDevice.h>
#include <guiFreqDevice.h>
#include <guiBPSDevice.h>
#include <yafcore/buffer.h>

#include "timerWidget.h"
#include "statusWidget.h"
#include "infoWidget.h"
#include "controlWidget.h"
#include "volumeWidget.h"
#include "song.h"

#include <playlistOperation.h>
#include <kmsgbox.h>


class KmpgPlayer : public QWidget , public MetaPlayer  {
  Q_OBJECT

 public:
  KmpgPlayer( Playlist* playlist,QWidget *parent=0, const char *name=0 );
  ~KmpgPlayer();

 public slots:
  void setGenericPlayer(GenericPlayer* aDecoder);
  void addListener(NodeDevice* listener);
  void processEvent(char eventId);

 protected:
  OutputDevice* getInternalDeviceTree();
  void buildGUI();

 private slots:
   void playSongEvent(int index);

   void play();
   void pause();
   void stop();
   void playNext();
   void playPrev();
   void decoderCrash();

 private: 
  QBoxLayout* topLayout;

  MulticastDevice* multicastDevice;
  GuiSpectrumAnalyser* guiSpectrumAnalyser;
  TimerWidget* timerWidget;
  StatusWidget* statusWidget;
  InfoWidget* infoWidget;
  GuiInfoDevice* guiInfoDevice;
  ControlWidget* controlWidget;
  VolumeWidget* volumeWidget;
  GuiBalanceDevice* guiBalanceDevice;
  GuiShuffle* guiShuffle;
  GuiRepeat* guiRepeat;
  GuiStereoDevice* guiStereoDevice;
  GuiFreqDevice* guiFreqDevice;
  GuiBPSDevice* guiBPSDevice;
  GuiJumpDevice* guiJumpDevice;
  GuiBufferInfoDevice* guiBufferInfoDevice;
  
  Playlist* playlist;
  Buffer* filename;
  GenericPlayer* aDecoder;
};

#endif


  
