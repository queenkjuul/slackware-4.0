/*
  stores deviceConfigFifos (each streamProducer in a seperate column)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <deviceConfig/multiQueueFifo.h>



MultiQueueFifo::MultiQueueFifo() {
  int i;

  confArray=new DeviceConfigArray();
  for(i=0;i<_MAX_QUEUE_ENTRIES;i++) {
    fifoQueue[i]=new DeviceConfigFifo();
  }
    
}


MultiQueueFifo::~MultiQueueFifo() {
  int i;

  for(i=0;i<_MAX_QUEUE_ENTRIES;i++) {
    delete fifoQueue[i];
  }
  delete confArray;
}


void MultiQueueFifo::enqueue(StreamProducer* producer,DeviceConfig* config) {
  DeviceConfigFifo* fifo=requestQueue(producer);
  fifo->enqueue(config);
}


int MultiQueueFifo::canSimultaneousDequeue() {
  int i;
  int back=true;
  int fillgrade;

  for(i=0;i<_MAX_QUEUE_ENTRIES;i++) { 
    if (fifoQueue[i]->getValid() == true) {
      fillgrade=fifoQueue[i]->getFillgrade();
      if (fillgrade > 0) {
	continue;
      }
      if (fifoQueue[i]->getStatus() == _STATUS_STOPPED) {
	if (fifoQueue[i]->getWaitForStoppedSource() == false) {
	  continue;
	}
      }
      if (fifoQueue[i]->getStatus() == _STATUS_PAUSED) {
	if (fifoQueue[i]->getWaitForPausedSource() == false) {
	  continue;
	}
      }

      return false;
    }
  }
  return back;
}


DeviceConfigFifo* MultiQueueFifo::requestQueue(StreamProducer* producer) {
  int pos;

  pos = findQueue(producer);
  if (pos >= 0) {
    return fifoQueue[pos];
  }
  pos = findEmpty();
  if (pos == -1) {
    cout << "fatal error source overflow->MultiQueueFifo::requestQueue"<<endl;
    exit(-1);
  }
  fifoQueue[pos]->setStreamProducer(producer);
  fifoQueue[pos]->setValid(true);
  return fifoQueue[pos];
}




DeviceConfigArray* MultiQueueFifo::multiDequeue() {
  int i;
  DeviceConfigFifo* fifo;
  int fillgrade;
  int entries=0;

  confArray->clear();

  for(i=0;i<_MAX_QUEUE_ENTRIES;i++) { 
    if (fifoQueue[i]->getValid() == true) {
      fifo=fifoQueue[i];
      fillgrade=fifo->getFillgrade();
      if (fillgrade > 0) {
	confArray->setDeviceConfigAt(entries,fifo->dequeue());
	entries++;
      }
    }
  }
  confArray->setEntries(entries);
  return confArray;
}


void MultiQueueFifo::multiForward() {
  int i;
  DeviceConfigFifo* fifo;

  for(i=0;i<_MAX_QUEUE_ENTRIES;i++) { 
    if (fifoQueue[i]->getValid() == true) {
      if (fifoQueue[i]->getDequeue() == true) {
	fifo=fifoQueue[i];
	fifo->forwardQueue();
	if (fifo->getStatus() == _STATUS_STOPPED) {
	  fifo->setValid(false);
	}
      }
    }
  }  
}


int MultiQueueFifo::findQueue(StreamProducer* producer) {
  int i;
  
  for(i=0;i<_MAX_QUEUE_ENTRIES;i++) { 
    if (fifoQueue[i]->getValid() == true) {
      if (fifoQueue[i]->getStreamProducer() == producer) {
	return i;
      }
    }
  }
  return -1;
}


int MultiQueueFifo::findEmpty() {
  int i;

  for(i=0;i<_MAX_QUEUE_ENTRIES;i++) { 
    if (fifoQueue[i]->getValid() == false) {
      return i;
    }
  }
  return -1; 
}




