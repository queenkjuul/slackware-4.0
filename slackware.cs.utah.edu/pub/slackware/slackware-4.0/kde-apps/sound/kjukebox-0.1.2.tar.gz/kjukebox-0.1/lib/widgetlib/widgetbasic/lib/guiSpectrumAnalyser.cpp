/*
  a GUI for a spectrum analyser
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <guiSpectrumAnalyser.h>




GuiSpectrumAnalyser::GuiSpectrumAnalyser( QWidget *parent=0, 
		     const char *name=0):GuiDevice(parent,name) {
  spaHeight=22;
  updateFreq=2;

  setBackgroundColor (QColor(0,0,0));


  device=new SpectrumAnalyserDevice();
  device->setAnalyseFreq(2);

  spectrumImage= new SpectrumImage(spaHeight);
  bands=device->getBands();

  pixMap=new QPixmap(bands,spaHeight);
  currentPeaks=new int[bands];

  width=bands;
  height=spaHeight;
  pixMap=new QPixmap(bands,spaHeight);
  setMinimumSize( width, height );
  setMaximumSize( width, height );

  setDevice(device);
  counter=0;

  insertMenu("stop",this,SLOT(stopAnalyse()));
  insertMenu("start",this,SLOT(startAnalyse()));

   
}


GuiSpectrumAnalyser::~GuiSpectrumAnalyser() {
  delete device;
  delete spectrumImage;
}



void GuiSpectrumAnalyser::mousePressEvent ( QMouseEvent* mouseEvent) {
  if (mouseEvent->button() ==  RightButton) {
    cout << "RightButton"<<endl;
    KPopupMenu* popupMenu=createPopupMenu();
    popupMenu->move(mapToGlobal(QPoint(mouseEvent->x(),mouseEvent->y())));
    popupMenu->exec();
    delete popupMenu;
  }
}




void GuiSpectrumAnalyser::stopAnalyse() {
  device->setAnalyse(false);
}


void GuiSpectrumAnalyser::startAnalyse() {
  device->setAnalyse(true);
}


OutputDevice* GuiSpectrumAnalyser::getDevice() {
  return device;
}


void GuiSpectrumAnalyser::timeEvent() {
  if (getNotifyBit()) {
    repaint(false);
  }
}

void GuiSpectrumAnalyser::processEvent(char eventId) {
  repaint(false);
}


QSize GuiSpectrumAnalyser::sizeHint() {
  QSize size(70,30);
  return size;
}



void GuiSpectrumAnalyser::paintEvent ( QPaintEvent * paintEvent ) {
  int i;
  int* bandPtr;
  int bands;
  int value;
  QPixmap* peakMap;

  counter++;
  if (counter < updateFreq) {
    clearNotifyBit();
    return;
  }
  counter=0;
  bandPtr=device->getBandPtr();
  bands=device->getBands();
  peakMap=spectrumImage->getPixmap();

  QPainter p;                             // our painter
  p.begin( pixMap );                     // start painting pixmap

  for (i=0;i<bands;i++) {
    value=bandPtr[i];
    // if the peak is less we prefer the higher one
    if (currentPeaks[i] < value) {
      currentPeaks[i]=value;
    } else {
      // if is less than 50 % decrement  this value by another 10%
      if (value < 50) {
	currentPeaks[i]=currentPeaks[i]-
	  (int)(((float)currentPeaks[i]*0.25))-1;
      } else {
	currentPeaks[i]=value;
      }
    }
    if (currentPeaks[i] < 0) {
      currentPeaks[i]=0;
    }
    if (currentPeaks[i] > spaHeight) {
      currentPeaks[i]=spaHeight;
    }    
    // and we emphasize the peak. We draw two peak columns
    // if we hav a peak
    if ((currentPeaks[i] > spaHeight-2) && (i > 1)) {
      p.drawPixmap(i-1,0,(*peakMap),currentPeaks[i],0,1,spaHeight);
    }    
    p.drawPixmap(i,0,(*peakMap),currentPeaks[i],0,1,spaHeight);
  } 

  p.end();                                // painting done
  bitBlt( this, 0,0, pixMap,5,0 );        
    

  clearNotifyBit();
}


  





