/*
  encapsulates the configuration for a yafAmplifier
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */







#ifndef __AMPLIFIERCONFIG_H
#define __AMPLIFIERCONFIG_H

#include <iostream.h>


#define _MP3_DECODER 1
#define _MP3_DECODER_REALLY_BAD 2

#define _IMAGE_VIEWER 3

/**
   stores configuration data for a backend player.
*/

class AmplifierConfig {
  
 public:

  AmplifierConfig();
  ~AmplifierConfig();

  // Note: return is  NULL-terminated Array of Strings
  char** getExecutable(int decoderTyp);

};
  
  

#endif
