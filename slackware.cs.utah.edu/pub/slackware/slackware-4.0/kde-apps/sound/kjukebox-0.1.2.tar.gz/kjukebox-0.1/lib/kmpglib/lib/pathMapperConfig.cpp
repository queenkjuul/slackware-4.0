/*
  converts dos path to unix hierarchical file
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <pathMapperConfig.h>



PathMapperConfig::PathMapperConfig(QWidget * parent=0, const char * name=0 )
                     : PrefConfig(parent,name) {

  pathMapperList=new PathMapperList();
  currentEdit=NULL;
  config = kapp->getConfig();
  configGroup="PathMapper";


  buttonPanel = new QWidget( this );
  editPanel = new QWidget( this );
  pathMapperListView1= new PathMapperListView1(pathMapperList,this,"config");
  load();


 
  QPushButton *pb1 = new QPushButton(klocale->translate("Add"),buttonPanel);
  pb1->setGeometry( 10, 5, 80, 25 );

  QPushButton *pb2 = new QPushButton( klocale->translate("Delete"),
				      buttonPanel );
  pb2->setGeometry( 10, 40, 80, 25 );
 
  QLabel* label = 
    new QLabel("Configure the replacement for dos playlists",editPanel);
  label->setGeometry(10,0,320,20);
 

  label = new QLabel("Map dos drive:",editPanel);
  label->setGeometry(10,25,80,20);

  driveEdit=new QLineEdit(editPanel,"driveEdit");
  driveEdit->setGeometry( 10, 45, 80, 25 );
  driveEdit->setMaxLength(1);
  label = new QLabel("To mount point:",editPanel);
  label->setGeometry(110,25,90,20);

  substEdit=new QLineEdit(editPanel,"substEdit");
  substEdit->setGeometry( 110, 45, 120, 25 );

  

  setMinimumSize( 350, 250 );
  resize( 350, 250 ); // Use the smallest size by default
  connect( pb1, SIGNAL(clicked()), SLOT(addEvent()) );
  connect( pb2, SIGNAL(clicked()), SLOT(deleteEvent()) ); 
  connect(pathMapperList , SIGNAL(setCurrentPosEvent(int)), this,
	  SLOT(setCurrentPosEvent(int))); 
  
}


PathMapperConfig::~PathMapperConfig() {
}


void PathMapperConfig::resizeEvent( QResizeEvent* ) {
  pathMapperListView1->setGeometry( 5, 5, width()-105, height()-110 );
  buttonPanel->setGeometry( width()-100, 0, 100, height() );
  editPanel->setGeometry( 5, height()-100,width(),height());
}


char* PathMapperConfig::getGroupName() {
  return "Mount";
}


void PathMapperConfig::load() {
  config->setGroup(configGroup);
  QStrList list;
  char* s1="(C;/mnt/diskC)";
  char* s2="(D;/mnt/diskD)";
  char* s3="(E;/mnt/diskE)";
  char* s4="(F;/mnt/diskF)";
  char* s5="(G;/mnt/diskG)";
  char* s6="(H;/mnt/diskH)";

  config->readListEntry("mapList",list);
  // if empty insert a few defaults

  if (list.count() == 0) {
    list.append(s1);
    list.append(s2);
    list.append(s3);
    list.append(s4);
    list.append(s5);
    list.append(s6);
    list.at(0);
  }
    

  char* str;
  for( str=list.first(); str!=0; str=list.next() ){
    pathMapperList->addPathMapper(new PathMapper(str));
  }
}


void PathMapperConfig::save() {
  config->setGroup(configGroup);
  int i;
  int n=pathMapperList->count();
  QStrList list;

  for(i=0;i<n;i++) {
    char* string;
    PathMapper* pathMapper=pathMapperList->at(i);
    string=pathMapper->toFormat();
    list.append(string);
  }
  config->writeEntry("mapList",list);
}


void PathMapperConfig::apply() {
  if (currentEdit != NULL) {
    char* drive=(char*)driveEdit->text();
    char* subst=(char*)substEdit->text();
    if ((strlen(drive) == 1) && (strlen(subst) >= 1)) {
      if (('a' < drive[0]) && (drive[0] < 'z')) {
	drive[0]='A'+drive[0]-'a';
      }
      if (!(('A' < drive[0]) && (drive[0] < 'Z'))) {
	drive[0]='A';
	KMsgBox::message(this,"error","not a valid dos drive letter");
	return;
      }    
      if (subst[0] != '/') {
	KMsgBox::message(this,"error","path does not start with /");
	return;
      }
      currentEdit->setDrive(drive);
      currentEdit->setSubst(subst);
    }
  }
  save();
}




void PathMapperConfig::deleteEvent() {
  currentEdit=NULL;
  pathMapperList->delPathMapper();
}


void PathMapperConfig::addEvent() {
  char* string="(X;/mnt/diskX)";
  PathMapper* pathMapper=new PathMapper(string);
  pathMapperList->addPathMapper(pathMapper);
}


void PathMapperConfig::setCurrentPosEvent(int index) {
  currentEdit=pathMapperList->at(index);
  if (currentEdit != NULL) {
    char* drive=currentEdit->getDrive();
    char* subst=currentEdit->getSubst();
    driveEdit->setText(drive);
    substEdit->setText(subst);
  }
}


void PathMapperConfig::translate(char* filename,Buffer* target) {
}

      
      

  

