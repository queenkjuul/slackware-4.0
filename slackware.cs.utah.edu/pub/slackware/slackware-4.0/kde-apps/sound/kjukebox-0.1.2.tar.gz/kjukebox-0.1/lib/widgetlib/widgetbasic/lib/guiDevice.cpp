/*
  start of a generic gui Device
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <guiDevice.h>



GuiDevice::GuiDevice( QWidget *parent=0, 
 		      const char *name=0 ) : GuiDeviceCore(parent,name) {

  menuDescription=new MenuDescription("empty Menu");
  preferences=new Preferences();

}


GuiDevice::~GuiDevice() {
  delete menuDescription;
}

void GuiDevice::insertMenu(char* text,QObject* receiver,const char* signal) {
  menuDescription->insertMenu(text,receiver,signal);
}


void GuiDevice::setDevice(OutputDevice* device) {
  menuDescription->setTitle(device->getNodeName());
  GuiDeviceCore::setDevice(device);
}


Preferences* GuiDevice::getPreferences() {
  return preferences;
}


KPopupMenu* GuiDevice::createPopupMenu() {
  return menuDescription->createPopupMenu();
}


    



 

