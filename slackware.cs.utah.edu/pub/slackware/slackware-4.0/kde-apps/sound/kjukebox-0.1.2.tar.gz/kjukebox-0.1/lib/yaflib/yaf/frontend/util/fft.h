/*
  a FFT class
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#ifndef __FFT_H
#define __FFT_H

#include <math.h>
#include <stdlib.h>
#include <stdio.h>


class FFT {

 public:
  FFT();
  ~FFT();

  void fft( float data[], int N, int isign );
  void rfft( float data[], int N, int isign );

 private:
  long double sqr( long double arg );
  void swap( float &a, float &b );

};




#endif

