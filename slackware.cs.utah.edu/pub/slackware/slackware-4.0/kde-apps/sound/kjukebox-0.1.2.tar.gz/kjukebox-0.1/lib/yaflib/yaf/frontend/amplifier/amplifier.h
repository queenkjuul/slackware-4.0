/*
  this class controls the different decoders.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */






#ifndef __YAFAMPLIFIER_H
#define __YAFAMPLIFIER_H

#include <producer/yaf/yafGenerator.h>
#include <producer/image/imageGenerator.h>

#include <devices/genericPlayer.h>
#include <util/ptrArray.h>
#include <amplifier/amplifierConfig.h>


/**
   A factory for GenericPlayers.
*/

class Amplifier  {

 public:
  Amplifier();
  ~Amplifier();
 
  // returns the id for the decoder. types defined in AmplifierConfig.h
  static GenericPlayer* createPlayer(int playerTyp);

 private:
  static YafGenerator* createYafGenerator(int playerType);

};

#endif

