/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#ifndef TIMER_H
#define TIMER_H


#include <qpainter.h>
#include <qpushbt.h>
#include <qtimer.h> 


#include <devices/streamInfoDevice.h>
#include <yafcore/buffer.h>
#include "devices/volumeDevice.h"

#include <guiDevice.h>

#include "led.h"

#include <guiDeviceCore.h>
#include <preferences.h>

#define _TIMEMODE_PLAYED             100
#define _TIMEMODE_REMAIN             101     

class Timer : public GuiDeviceCore {
  Q_OBJECT
 private:
  LED    *led;
  Buffer *timeString;
  int     alarmTime;
  int     mode_cfg;
  StreamInfoDevice *streamInfoDevice;
  int     volume;
  int     fadeSpeed;
  bool    fadeOut;
  VolumeDevice     *volumeDevice;
  QSize sizeHint();
  char* getTimeString();
  void  getFormatDec(int played,int len,Buffer* dest);
  bool  playerStopped;

 public:
  Timer(QWidget *parent=0, const char *name=0);
  ~Timer();
  void setDevice(OutputDevice* device);
  void translate(TimeInfo* timeInfo,MusicInfo* musicInfo,Buffer* dest);
  int  getTimeMode();
  void checkAlarmTime();
  void setVolumeDevice(VolumeDevice *);
  void setVolume(int );
  void setFadeSpeed(int );
  void setFadeOut(bool );

 protected:
  void mousePressEvent ( QMouseEvent* mouseEvent);
  void paintEvent(class QPaintEvent *);

 signals:
  void alarm();
  void stopPlayer();

  public slots:
  void setTimeMode(int mode);
  void setAlarmTime(int seconds);
  void clearAlarmTime();

  private slots:
    void playerStatusChanged(char );
};


#endif TIMER_H
