/*
  radiobutton to select shuffle play
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */






#ifndef __GUISHUFFLE_H
#define __GUISHUFFLE_H

#include <qpainter.h>
#include <qpushbt.h>
#include <qradiobutton.h> 
#include <qlayout.h>
#include <kslider.h>
#include <menuDescription.h>
#include <kpopmenu.h>


#include <iostream.h>




class GuiShuffle : public QRadioButton  {
  Q_OBJECT


 public:
  GuiShuffle(char* text, QWidget *parent=0, const char *name=0 );
  ~GuiShuffle();

 public slots:
   void setShuffle(int);

 private slots:
   void processShuffle(bool);

 signals:
   void setShuffleEvent(int);

};


#endif

