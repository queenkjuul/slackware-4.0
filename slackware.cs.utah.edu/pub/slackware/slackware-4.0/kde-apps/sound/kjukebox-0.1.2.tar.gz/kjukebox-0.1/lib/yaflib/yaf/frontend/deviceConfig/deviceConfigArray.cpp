/*
  stores deviceConfigs.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <deviceConfig/deviceConfigArray.h>


DeviceConfigArray::DeviceConfigArray() {
  entries=0;
}


DeviceConfigArray::~DeviceConfigArray() {
}



void DeviceConfigArray::clear() {
  entries=0;
}



int DeviceConfigArray::getEntries() {
  return entries;
}

void DeviceConfigArray::setEntries(int entries) {
  this->entries=entries;
}


DeviceConfig* DeviceConfigArray::getDeviceConfigAt(int pos) {
  return confArray[pos];
}


void DeviceConfigArray::setDeviceConfigAt(int pos,DeviceConfig* buf) {
  confArray[pos]=buf;
}


int DeviceConfigArray::getMaximumMemChunkLen() {
  AudioBuffer* audioBuffer;
  MemChunk* memChunk;
  DeviceConfig* config;
  int i;
  int maxLen=0;

  for(i=0;i<entries;i++) {
    config=getDeviceConfigAt(i);
    audioBuffer=config->getAudioBuffer();
    memChunk=audioBuffer->getMemChunk();
    if (memChunk->getLen() > maxLen) {
      maxLen=memChunk->getLen();
    }
  }
  return maxLen;
}


float DeviceConfigArray::getRightVolumeSum() {
  VolumeInfo* info;
  DeviceConfig* config;
  float volSum=0;
  int i;

  for(i=0;i<entries;i++) {
    config=getDeviceConfigAt(i);
    info=config->getVolumeInfo();
    volSum=volSum+info->getRightVolume();

  }
  return volSum;
}


float DeviceConfigArray::getLeftVolumeSum() {
  VolumeInfo* info;
  DeviceConfig* config;
  float volSum=0;
  int i;

  for(i=0;i<entries;i++) {
    config=getDeviceConfigAt(i);
    info=config->getVolumeInfo();
    volSum=volSum+info->getLeftVolume();

  }
  return volSum;
}


int DeviceConfigArray::getMaximumMemChunkPos() {
  AudioBuffer* audioBuffer;
  MemChunk* memChunk;
  DeviceConfig* config;
  int i;
  int maxPos=0;
  int maxLen=0;

  for(i=0;i<entries;i++) {
    config=getDeviceConfigAt(i);
    audioBuffer=config->getAudioBuffer();
    memChunk=audioBuffer->getMemChunk();

    if (memChunk->getLen() > maxLen) {
      maxPos=i;
      maxLen=memChunk->getLen();
    }
  }
  return maxPos;
}


