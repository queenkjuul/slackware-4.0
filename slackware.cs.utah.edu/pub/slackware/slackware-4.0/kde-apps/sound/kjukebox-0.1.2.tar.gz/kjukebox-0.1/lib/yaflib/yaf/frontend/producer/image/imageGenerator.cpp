/*
  A simple producer for images.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <producer/image/imageGenerator.h>

ImageGenerator::ImageGenerator() {
  internal=new QPixmap();
  current=new QPixmap();
  cache=new QPixmap();
}


ImageGenerator::~ImageGenerator() {
  delete internal;
  delete current;
  delete cache;
}


int ImageGenerator::updateDeviceConfig(DeviceConfig* newConfig) {
  VideoInfo* videoInfo;
  MemChunk* memChunk;

  videoInfo=newConfig->getVideoInfo();
  memChunk=videoInfo->getMemChunk();
  memChunk->waitForUnlock();



  /**
     Here starts a hack to simulate a video stream out of 
     an image.
     We simply scroll the image one pixel to the left
  */

  bitBlt( current, 0,0, 
	  cache,scrollPos,0 ,width-scrollPos,height);   
  bitBlt( current,width-scrollPos ,0, 
	  cache, 0 ,0,scrollPos,height);   

  scrollPos++;
  if (scrollPos > width) {
    scrollPos=0;
  }
  videoInfo->setPixmap(current);

  usleep(500);
  return false;
}


int ImageGenerator::open(char* filename ) {
  setThreadState(_STOP_WORKING);
  cout << "ImageGenerator -------- open"<<endl;
  internal->load(filename);
  cache->load(filename);
  cache=internal;
  current->resize(internal->size());
  scrollPos=0;
  width=internal->width();
  height=internal->height();
  setThreadState(_START_WORKING);
  jump(percent);
  return true;
}

/**
   The way we use the images this must stop
   the deliver thread.
   A more powerfull image handling system may change this.
   But the whole image stuff is demo only.
*/
int ImageGenerator::jump(int percent) {
  setThreadState(_STOP_WORKING);
  this->percent=percent;
  int copyYPos=(int)((float)percent/100.0*(float)height);
  /*
  cout << "copyYPos:"<<copyYPos<<"height:"<<height
       <<"h-y:"<<height-copyYPos<<endl;
  Is this a bug?
  Why I cannot scroll up down ?     

  */


  bitBlt( cache, 0,0, 
	  internal,0,copyYPos);
  bitBlt( cache,0,height-copyYPos,
	  internal,0,0);
  
  setThreadState(_START_WORKING);
  return true;
}



void ImageGenerator::setThreadState(int msg) {
  ThreadNotifier* client;
  client=getThreadNotifier();     // our "phone" to the thread :-)

  client->sendSyncMessage(_NOT_ALLOW_GENERATOR_ENTER);
  
  cout << "setThreadState:"<<msg<<endl;


  
  if (msg==_START_WORKING) {
    client->sendAsyncMessage(msg);
    client->sendSyncMessage(_ALLOW_GENERATOR_ENTER);
  }
  if (msg==_PAUSE_WORKING) {
    client->sendAsyncMessage(msg);
    client->sendSyncMessage(_NOT_ALLOW_GENERATOR_ENTER);
  }  
  if (msg==_STOP_WORKING) {
    client->sendAsyncMessage(msg);
    client->sendSyncMessage(_NOT_ALLOW_GENERATOR_ENTER);
  }  
}



