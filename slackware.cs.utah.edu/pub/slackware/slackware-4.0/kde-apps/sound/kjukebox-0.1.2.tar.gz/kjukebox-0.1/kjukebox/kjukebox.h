/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#ifndef KJUKEBOX_H
#define KJUKEBOX_H

#include <qstring.h>
#include <vector.h>
#include <set.h>
#include "song.h"

typedef vector<Song>::iterator SongIterator;
typedef vector<Song> Songs;


class QStringCmp{
 public:
  bool operator() (const QString a, const QString b) const{
    return ((strcmp(a,b)<0));
  }
};   
                  
typedef set<QString,QStringCmp>::iterator StringListIterator;
typedef set<QString,QStringCmp> StringListe;

typedef set<QString,QStringCmp>::iterator GenreIterator; 
typedef set<QString,QStringCmp> Genre; 


#define GENRE_ALL "ALL"

/* Comment Field to save some Information */
#define MP3_COMMENT_FIELD "FS:%3d LS:%3d" 

/* KConfig Names */
#define KCONFIG_FILE    "File Options"
#define KCONFIG_FILE_IMPORTFORMAT     "importFormat"
#define KCONFIG_FILE_IMPORTSEPERATOR  "importSeperator"
#define KCONFIG_FILE_MP3COMMENT       "useMP3CommentField"

#define KCONFIG_PLAYER  "Player Options"
#define KCONFIG_PLAYER_DEFAULTTIME    "defaultTime"
#define KCONFIG_PLAYER_MIXING         "mixing"
#define KCONFIG_PLAYER_DEVICE         "audioDevice"
#define KCONFIG_PLAYER_LASTSECONDS    "lastSeconds"
#define KCONFIG_PLAYER_FIRSTSECONDS   "firstSeconds"
#define KCONFIG_PLAYER_PRIORITY       "priority"
#define KCONFIG_PLAYER_FADEOUT        "fadeOut"

#define KCONFIG_GENERAL "General Options"
#define KCONFIG_GENERAL_STATUSBAR     "statusBar"
#define KCONFIG_GENERAL_SOUNDTOOLBAR  "soundToolBar"
#define KCONFIG_GENERAL_MAINTOOLBAR   "mainToolbar"
#define KCONFIG_GENERAL_WIDTH         "width"
#define KCONFIG_GENERAL_HEIGHT        "height"
#define KCONFIG_GENERAL_SHUFFLE       "shufflePlaying"

#endif // KJUKEBOX_H





