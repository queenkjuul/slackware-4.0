/*
  gui part for the balance device (very simple)
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */





#ifndef __GUIBALANCEDEVICE_H
#define __GUIBALANCEDEVICE_H

#include <qpainter.h>
#include <qpushbt.h>
#include <qlayout.h>
#include <kslider.h>
#include <menuDescription.h>
#include <kpopmenu.h>


#include <iostream.h>

/**
   This class uses a shared device. This means it gets the device
   from somewhere else and that it does not own the device.
   (do not deletee when this object is destroyed.)
   <p>
   For what is this good for.
   The Balance is set in a volumeDevice. It is clear that
   you only want one volume/Balance for one stream.
   Because of performance reasons the volumeDevice is shared
   with this Gui for a BalanceDevice. 
*/
   



class GuiBalanceDevice : public KSlider {
  Q_OBJECT

  int balance;  
  MenuDescription* menuDescription;

 public:
  GuiBalanceDevice(int minValue, int maxValue, int step, int value, 
		   Orientation orient, QWidget *parent=0, const char *name=0 );
  ~GuiBalanceDevice();
  void mousePressEvent ( QMouseEvent* mouseEvent);

  QSize sizeHint ();
  //  void paintEvent ( QPaintEvent * paintEvent );
 
 signals:
   void balanceChange(int balance); 

 public slots:
  // -100 : full left zero right
  //  100 : zero left full right
  
  void centerBalance();  
  void setBalance(int range);
  int getBalance();

};


#endif
