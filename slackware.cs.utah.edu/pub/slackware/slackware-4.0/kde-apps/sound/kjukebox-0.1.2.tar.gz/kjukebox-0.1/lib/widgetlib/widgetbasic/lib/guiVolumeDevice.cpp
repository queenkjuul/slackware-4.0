/*
  gui part for the volume device (very simple)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <guiVolumeDevice.h>




GuiVolumeDevice::GuiVolumeDevice(QWidget *parent=0, 
			       const char *name=0):GuiDevice( parent, name ) {

  volumeDevice=new VolumeDevice();
  setDevice(volumeDevice);
}


GuiVolumeDevice::~GuiVolumeDevice() {
  delete volumeDevice;
}


int GuiVolumeDevice::getVolume() {
  return volumeDevice->getVolume();
}



void GuiVolumeDevice::setBalance(int value) {
  volumeDevice->setBalance(value);
}


int GuiVolumeDevice::getBalance() {
  return volumeDevice->getBalance();
}


void GuiVolumeDevice::buildGui() {
  sb = new QSlider(0,100,1,100,QSlider::Horizontal,this,"Slider");
  sb->setTickmarks( QSlider::Below );
  sb->setTickInterval( 10 );
  sb->setValue(getVolume());
  setMinimumSize( sizeHint() );
  setMaximumSize( sizeHint() );
  
  connect( sb, SIGNAL(valueChanged(int)),this,SLOT(setVolume(int)) );
}



void GuiVolumeDevice::setVolume(int percent) {
  volumeDevice->setVolume(percent);
}


QSize GuiVolumeDevice::sizeHint () {
  return QSize(80,28);
}

 
void GuiVolumeDevice::paintEvent ( QPaintEvent * paintEvent ) {
}



