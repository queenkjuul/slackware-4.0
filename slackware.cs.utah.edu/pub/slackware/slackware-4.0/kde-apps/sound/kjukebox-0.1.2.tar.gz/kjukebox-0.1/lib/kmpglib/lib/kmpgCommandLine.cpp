/*
  parses kmpg commandLine options and performs necessary commands
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <kmpgCommandLine.h>

static Playlist* playlist=NULL;
static int argMode=_IPC_NOARGUMENT_PLAY;

KmpgCommandLine::KmpgCommandLine() {
}


KmpgCommandLine::~KmpgCommandLine() {
}


void KmpgCommandLine::usage() {
  cout << "kmpg-" VERSION " is a mp3 player for the K Desktop Environment"<<endl;
  cout << "Usage : kmpg [-ah] file1 file2 ..."<<endl;
  cout << endl;
  cout << "-a : appends files to playlist."<<endl;
  cout << "-h : this message"<<endl;
  cout << "<no options> : plays file1 and append the rest" \
       << " to the playlist"<<endl;
  cout << endl;
  cout << "THIS SOFTWARE COMES WITH ABSOLUTELY NO WARRANTY! " \
       << "USE AT YOUR OWN RISK!"<<endl;
  cout << endl;
}

void KmpgCommandLine::setPlaylist(Playlist* aPlaylist) {
  playlist=aPlaylist;
}


void KmpgCommandLine::setArgMode(int mode) {
  argMode=mode;
}


/**
   The IPC communtication cannot use getopt, because getopt uses a static
   variable, which cannot be reset from the outside. Continous
   getopt calls then leads to sigsev. This is the reason why there
   must be an own parse function!
*/
 
void KmpgCommandLine::parseIPC(CommandLineCreator* commandLineCreator) {
  int insertMode=argMode;
  int i=1;
  int nargs=commandLineCreator->getNArgs();
  char** args=commandLineCreator->getArgs();
  QStrList strList;
  
  // Parse command arguments
  if (nargs >= 2) {
    if (strncmp(args[1],"-a",2) == 0) {
      insertMode=_IPC_NOARGUMENT_APPEND;
      i++;
    }
  }


  if (insertMode == _IPC_NOARGUMENT_IGNORE) {
    return;
  }

  while(i<nargs) {
    cout << "args[i]:"<<args[i]<<endl;
    strList.append(args[i]);
    i++;
  }
  int count=playlist->count();
  int pos=playlist->getCurrentPos();
  if (insertMode == _IPC_NOARGUMENT_APPEND) {
    PlaylistOperation::insert(&strList,playlist,count);
    playlist->setCurrentPos(pos);
  }
  if (insertMode == _IPC_NOARGUMENT_PLAY) {
    PlaylistOperation::insert(&strList,playlist,count);
    playlist->setCurrentPos(count);
    PlaylistOperation::playCurrent(playlist);
  }

  delete commandLineCreator;
}


void KmpgCommandLine::parse(int nargs,char** args) {
  int c;
  int lPlay=true;
  int i=1;
  QStrList strList;

  while(1) { 
    c = getopt (nargs, args, "a");
    if (c == -1) break;
    i++;
    switch(c) {
    case 'a': {    
      lPlay=false;
      break;
    }
    case 'h': {
      usage();
      exit(0);
    }
    default:
      printf ("?? getopt returned character code 0%o ??\n", c);
      usage();
      exit(-1);
    }
  }
  while(i<nargs) {
    strList.append(args[i]);
    i++;
  }

  int count=playlist->count();
  int pos=playlist->getCurrentPos();
  if (lPlay == false) {
    playlist->setCurrentPos(count);
  }
  PlaylistOperation::insert(&strList,playlist);

  if (lPlay == false) {
    playlist->setCurrentPos(pos);
  }
  if (lPlay == true) {
    PlaylistOperation::playCurrent(playlist);
  }

}


