#include <kapp.h>
#include <qstring.h>
#include <ktablistbox.h> 
#include <time.h>
#include "kjukebox.h"
#include "songList.h"


SongList::SongList(QString bName, QWidget *parent, const char *name) 
  :QWidget(parent,name){                                    
  setupSurface(bName);
}
SongList::SongList(QWidget *parent, const char *name) 
  :QWidget(parent,name){                                    
  setupSurface("");
}

void SongList::setupSurface(QString bName){
  srand(time(NULL));
  genreToDisplay = GENRE_ALL;
  titleWidth = artistWidth=40; // 40% , 40%
  timeWidth = 20;
  selectedIndex = -1;
  setMinimumSize(50,100);

  if (strcmp(bName,"") == 0)
    box = new QGroupBox(this,"box");
  else 
    box = new QGroupBox(bName,this,"box");

  table = new KTabListBox(this,"table",3);
  table->setColumn(0, i18n("Artist"));
  table->setColumn(1, i18n("Title"));
  table->setColumn(2, i18n("Time"));
  table->setSeparator('|');
  table->setTableFlags(Tbl_vScrollBar|Tbl_hScrollBar);
  table->setAutoUpdate(true);

  /* Bei einem Doppelklick auf einen Eintrag */
  connect(table,SIGNAL(selected(int,int)),SLOT(doubleClick(int,int)));
  /* Bei wechseln der Selection */
  connect(table,SIGNAL(highlighted(int,int)),SLOT(selectionChanged(int,int)));
}

void SongList::selectionChanged(int index,int){
  selectedIndex = index;
  emit selectionChanged();
}

void SongList::clearSelection(){
  selectedIndex = -1;
  table->unmarkAll();
}

void SongList::doubleClick(int index, int column){
  emit doubleClick();
}
  

void SongList::addSong(Song newSong){
  Songs newSongs;
  newSongs.push_back(newSong);
  addSongs(newSongs);
  checkGenre();
}

void SongList::addSongs(Songs newSongs){
  SongIterator lauf;

  if(selectedIndex == -1) 
    for(lauf=newSongs.begin(); lauf!=newSongs.end(); lauf++){
      lauf->setPlayed(false);
      songs.push_back(*lauf);
    }
  else 
    for(lauf=newSongs.begin(); lauf != newSongs.end(); lauf++){
      lauf->setPlayed(false);
      songs.insert(songs.begin()+selectedIndex,*lauf);  
    }

  refreshDisplay();
  checkGenre();
}


Songs SongList::getSongs(){
  Songs newList;
  SongIterator lauf;
  int tmp = 0;
  if (selectedIndex != -1 ) {
    for(lauf=songs.begin(); lauf != songs.end(); lauf++){
      if(!((strcmp(genreToDisplay, GENRE_ALL))&&
	   (strcmp(genreToDisplay,lauf->getGenre()))))
	{
	  if(tmp == selectedIndex)  newList.push_back(*lauf);
	  tmp++;
	}
    }
  }
  return newList;
}

Songs SongList::getAllSongs(){
  return songs;
}

void SongList::removePlayedSongs(){
  SongIterator lauf;
  if(songs.size() == 0) return;
  lauf = songs.begin();
  while ( lauf != songs.end() ){
    if(lauf->getPlayed()){ 
      songs.erase(lauf);
      lauf = songs.begin();
    }
    else 
      lauf++;
  }
  refreshDisplay();
}

Songs SongList::getRandomListOfSongsToPlay(){
  Songs randomSongList;
  SongIterator lauf;
  SongIterator orig;
  int index;
  
  if(songs.empty()) return randomSongList;

  index = rand() % songs.size();
  lauf = songs.begin() + index;
  orig = lauf;

  while(1){
    if(!(lauf->getPlayed())) break;
    lauf++;
    if(lauf == songs.end()) lauf = songs.begin();
    if(lauf == orig) break;
  }
  if(lauf->getPlayed()) return randomSongList;

  lauf->setPlayed(true);
  randomSongList.push_back(*lauf);
  refreshDisplay();
  return randomSongList;
}

Songs SongList::getFirstSongsToPlay(){
  Songs newList;
  SongIterator lauf;

  if(songs.empty()) return newList;
  if (selectedIndex==-1)lauf=songs.begin();
  else lauf = songs.begin() + selectedIndex;

  while( (lauf->getPlayed()==true) && (lauf != songs.end()) ){  
    lauf++; 
  }
  if (lauf==songs.end()) {
    return newList;
  }
    
  lauf->setPlayed(true);
  newList.push_back( *lauf );
  refreshDisplay();
  return newList;
}

void SongList::removeAllSongs(){
  clearSelection();
  songs.clear();
  table->clear();
  table->repaint();
  checkGenre();
}

void SongList::removeSong(){
  if(selectedIndex == -1) return;
  songs.erase(songs.begin()+selectedIndex);
  refreshDisplay();
}
 
void SongList::refreshDisplay(){
  QColor color("red");
  SongIterator lauf;
  int i=0;
  unsigned int selection = selectedIndex;
  table->setAutoUpdate(false);
  table->clear();
  for(lauf=songs.begin(); lauf != songs.end(); lauf++){
    if(!((strcmp(genreToDisplay, GENRE_ALL))&&
	 (strcmp(genreToDisplay, lauf->getGenre())))){
	 table->insertItem(songAsString(*lauf));
	 if(lauf->getPlayed()) table->changeItemColor(color,i);
	 i++;
       }
  }
  table->setAutoUpdate(true);
  table->repaint();
  if(table->count() > selection) table->markItem(selection);
  else selectedIndex = -1;
}

void SongList::checkGenre(){
  Genre kompletteListe;
  SongIterator lauf;
  for(lauf=songs.begin(); lauf!=songs.end(); lauf++){
    kompletteListe.insert(lauf->getGenre());
  }
  if (kompletteListe != genreList){
    genreList = kompletteListe;
    emit genreChanged(genreList);
  }
}

QString SongList::songAsString(Song song){
  QString helpstring(1000);
  helpstring.sprintf("%s%c%s%c%d:%02d", 
		     (const char*)song.getArtist(), table->separator(),
		     (const char*)song.getTitle(),  table->separator(), 
		     (song.getSeconds() / 60),
		     (song.getSeconds() % 60));
  return helpstring;
}
	  

void SongList::setGenre(QString genre){
  genreToDisplay = genre;
  refreshDisplay();
}


void SongList::resizeEvent(QResizeEvent *){
  int xOffSet = 20;
  int y;
  box->setGeometry(0,0,width()-2, height());
  if(strcmp(box->title(),"") == 0) xOffSet = 5;
  y = box->width()-2-10;
  table->setColumnWidth(0,((y*artistWidth)/100)-2);
  table->setColumnWidth(1,((y*titleWidth)/100)-2);
  table->setColumnWidth(2,( y-(2.0*(y*titleWidth)/100) - 5));
  table->setGeometry(5,xOffSet,box->width()-10,box->height()-25);
}


