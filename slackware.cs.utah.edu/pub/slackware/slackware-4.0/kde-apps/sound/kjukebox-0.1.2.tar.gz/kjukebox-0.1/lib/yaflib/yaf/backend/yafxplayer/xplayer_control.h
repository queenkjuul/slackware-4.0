

#ifndef __XPLAYER_CONTROL_H
#define __XPLAYER_CONTROL_H


extern "C++" {

#include <yafcore/inputInterface.h>
#include <yafcore/outputInterface.h>
#include <yafxplayer/inputDecoderXPlayer.h>
#include <yafcore/parser.h>
#include <stdiostream.h>
}

#include <yafcore/yaf_control.h>

#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>



// prototypes


#endif
