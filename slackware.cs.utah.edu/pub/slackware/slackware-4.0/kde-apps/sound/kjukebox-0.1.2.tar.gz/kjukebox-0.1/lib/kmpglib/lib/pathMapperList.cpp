/*
  model for the pathmapper
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <pathMapperList.h>


PathMapperList::PathMapperList() {
}


PathMapperList::~PathMapperList() {
}


int PathMapperList::getCurrentPos() {
  return mapList.at();
}


PathMapper* PathMapperList::at(int index) {
  PathMapper* back;
  int pos=getCurrentPos();
  back=mapList.at(index);
  mapList.at(pos);
  return back;
}


int PathMapperList::count() {
  return mapList.count();
}


void PathMapperList::addPathMapper(PathMapper* pathMapper) {
  mapList.append(pathMapper);
  emit(addPathMapperEvent(pathMapper));
  connect(pathMapper,SIGNAL(pathMapperUpdateEvent(PathMapper*)),
	  this,SLOT(pathMapperUpdate(PathMapper*)));
			    
}


void PathMapperList::delPathMapper() {
  int index=getCurrentPos();
  mapList.remove();
  emit(removePathMapperEvent(index));
}


void PathMapperList::setCurrentPos(int pos) {
  cout <<"setCurrentPos:"<<pos<<endl;
  if (mapList.at(pos) != NULL) {
    emit(setCurrentPosEvent(pos));
  }
}


int PathMapperList::find(PathMapper* pathMapper) {
  int currentPos=getCurrentPos();
  int back=mapList.find(pathMapper);
  mapList.at(currentPos);
  return back;
}



void PathMapperList::pathMapperUpdate(PathMapper* pathMapper) {
  int index=find(pathMapper);
  if (index >=0) {
    emit(pathMapperUpdateEvent(pathMapper,index));
  }
}


