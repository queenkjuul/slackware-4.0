/*
  this device analyses the spectrum and sends notify messages.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <devices/spectrumAnalyserDevice.h>



SpectrumAnalyserDevice::SpectrumAnalyserDevice() {
  realFFTFilter= new RealFFTFilter();

  points=realFFTFilter->getPoints();
  bands=points/2;
  /* Why "showBands".
     
     The high frequency are not interessting in typical music.
     The fft analyse them but if you show all frequencies
     it looks ugly. 
 */
  calcBands=(int)(0.6*(float)bands);  
  showBands=calcBands;

  percentArray=new int[showBands];
  fftArray=new int[bands];
  volumeArray=new float[bands];
  //analyseFreq=40;
  analyseFreq=0;
  getEventQueue()->setNotifyMode(_NOTIFY_ALL);
  counter=0;
  lAnalyse=true;

}
 

SpectrumAnalyserDevice::~SpectrumAnalyserDevice() {
 delete realFFTFilter;
 delete percentArray;
 delete fftArray;
}


char* SpectrumAnalyserDevice::getNodeName() {
  return "SpectrumAnalyserDevice";
}


void SpectrumAnalyserDevice::setAnalyse(int lAnalyse) {
  this->lAnalyse=lAnalyse;
}


int SpectrumAnalyserDevice::getBands() {
  return showBands;
}


int* SpectrumAnalyserDevice::getBandPtr() {
  return percentArray;
}

void SpectrumAnalyserDevice::setAnalyseFreq(int analyseFreq) {
  this->analyseFreq=analyseFreq;
}

/*
  Elements in the spectrumArray describe the percent value
  by a band

*/

void SpectrumAnalyserDevice::writeIn(NodeDevice* source,DeviceConfig* buf) {
  int i;
  int j;
  int re;
  int im;
  int tmp;
  short* fftPtr;
  char* ptr;
  int* bitReversed;
  if (lAnalyse == false) {
    return;
  }
  
  counter++;
  if (counter < analyseFreq) {
    getEventQueue()->sendEvent(_OUTPUT_GENERAL_EVENT);
    return;
  }
  counter=0;

  AudioBuffer* audioBuffer=buf->getAudioBuffer();
  MemChunk* memChunk=audioBuffer->getMemChunk();

  ptr=memChunk->getPtr();
  if (ptr == NULL) return;


  realFFTFilter->fft16(buf,(short*)(ptr));
  j=0;
  float avg=0;
  fftPtr=realFFTFilter->getPointPtr();
  bitReversed=realFFTFilter->getBitReversed();
  for (i=0;i<calcBands;i++) {
    re=(int)fftPtr[bitReversed[j]];
    im=(int)fftPtr[bitReversed[j]+1];
    tmp=re*re+im*im;  
    fftArray[i]=(int)sqrt(sqrt(tmp));
    avg+=fftArray[i];
    j++;
  }
  

  avg=0.65*avg/(float)calcBands;
  // The following term make the spectrum analyser look nice
  // ****dont ask how long I have tested until I found out
  //     that this _might_ be the way winamp does the SPA****
  // Is there any good book about this ????????????? -> email me!
  int x;

  for (i=0;i<calcBands-1;i++) {
    x=(int)(fftArray[i]-avg);
    percentArray[i]=x;
  }
  getEventQueue()->sendEvent(_OUTPUT_GENERAL_EVENT);
}




