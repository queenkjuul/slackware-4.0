/*
  info about mp3 stream/file
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <deviceConfig/mp3Info.h>




MP3Info::MP3Info() {
  bps=0;
}


MP3Info::~MP3Info() {
}


int MP3Info::getBPS() {
  return bps;
}


void MP3Info::setBPS(int bps) {
  this->bps=bps;
  setChange(true);
}


void MP3Info::copyTo(MP3Info* dest) {
  dest->setBPS(getBPS());
}


void MP3Info::print() {
  cout << "MP3Info Start"<<endl;
  cout << "BPS:"<<getBPS()<<"**"<<endl;
  cout << "MP3Info End"<<endl;
}

