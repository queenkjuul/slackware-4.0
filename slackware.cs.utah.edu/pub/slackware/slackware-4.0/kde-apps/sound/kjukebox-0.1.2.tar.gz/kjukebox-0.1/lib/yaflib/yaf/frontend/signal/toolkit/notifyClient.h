/*
  wrapper class for a toolkit signal mechanism
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __NOTIFYCLIENT_H
#define __NOTIFYCLIENT_H

/**
   This class is a callback class from a gui signal mechanism
   to the yaf library.

*/

class NotifyClient {

 public:
  NotifyClient();
  virtual ~NotifyClient();

  virtual void processEvent(char msgId);

};
#endif
