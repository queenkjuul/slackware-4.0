/*
  defines methods which are called the yaf Protocol
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __CONTROL_CHANNEL_H
#define __CONTROL_CHANNEL_H


#include <iostream.h>

/**
   This class makes the processRuntime/Returncode handling
   more easy. It encapsulates these functions in an abstract
   class from which a class can derive from and then
   register it as a listener to these control messages.

*/


class ControlChannel {


 public:
  ControlChannel();
  virtual ~ControlChannel();

  virtual void processRuntimeCommand(int command,char* args);
  virtual void processReturnCommand(int cmdNr,int cmdId,char* ret,char* args);

};

#endif

