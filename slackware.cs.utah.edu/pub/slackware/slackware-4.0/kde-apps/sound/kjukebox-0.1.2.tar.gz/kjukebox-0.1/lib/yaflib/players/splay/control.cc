#include "mpegsound.h"
#include "splay.h"
#include <string.h>
#include <sys/stat.h>
#include <iostream.h>
#include "rawtoemusic.h"
#include <pthread.h>
#include <time.h>

static Soundinputstream *loader = NULL;
static Rawtoemusic	 *player = NULL;
static Mpegtoraw	 *server = NULL;

static char *song_path;

static int pcmperframe, frequency;

static int lDecoderLoop;
static int lCreatorLoop;
static int linDecoderLoop;
static int lDecode;
static int eof;

static int downSampleFlag=0;
static int monoFlag=0;

static pthread_t tr;
static pthread_mutex_t decoderMut; 
static pthread_mutex_t changeMut; 
static pthread_cond_t decoderCond;

/**
   The idea of this implementation:
   The decoding engine is a single thread. This thread is controlled
   by "a controller".
   The controller is a single thread and all calls to pause,play,open etc..
   are made by the controller.
   The controller calls contruct/destruct as well.
*/


void decoderLock() {
  pthread_mutex_lock(&changeMut);
  pthread_mutex_lock(&decoderMut);
}

void decoderUnlock() {
  pthread_cond_signal(&decoderCond);
  pthread_mutex_unlock(&changeMut);
  pthread_mutex_unlock(&decoderMut);
}


void splay_seek(int second) {
  decoderLock();
  int frame;

  frame = second * frequency / pcmperframe;
  server->clearbuffer();
  server->setframe(frame);
  decoderUnlock();
}

void decoder_loop() {
  char zahl[10];
  player = new Rawtoemusic;
  player->initialize(NULL);
  server = new Mpegtoraw(loader, player);
  server->initialize(song_path);

  server->setdownfrequency(downSampleFlag);
  server->setforcetomono(monoFlag);
  server->run(-1);

  cout << "Command:0 Msg:id3Info-Start"<<endl;
  cout << "Command:0 Msg:id3Name "<<server->getname()<<endl;
  cout << "Command:0 Msg:id3Artist "<<server->getartist()<<endl;
  cout << "Command:0 Msg:id3Album "<<server->getalbum()<<endl;
  cout << "Command:0 Msg:id3Year "<<server->getyear()<<endl;
  cout << "Command:0 Msg:id3Comment "<<server->getcomment()<<endl;
  snprintf((char*)&zahl,10,"%d",server->getgenre());
  cout << "Command:0 Msg:id3Genre "<<zahl<<endl;
  cout << "Command:0 Msg:id3Info-End"<<endl;
  
  cout << "Command:0 Msg:mp3Info-Start"<<endl;
  snprintf((char*)&zahl,10,"%d",server->getbitrate());
  cout << "Command:0 Msg:mp3BitsPerSec "<<zahl<<endl;
  cout << "Command:0 Msg:mp3Info-End"<<endl;

  
  
  frequency = server->getfrequency();
  pcmperframe = server->getpcmperframe();

  while(lDecoderLoop && lCreatorLoop) {
    if (pthread_mutex_trylock(&changeMut) == EBUSY) {
      pthread_cond_wait(&decoderCond,&decoderMut);
      continue;
    }
    pthread_mutex_unlock(&changeMut);

    if (lDecode) {
      if (!server->run(5) && (server->geterrorcode() == SOUND_ERROR_FINISH)) {
	lDecoderLoop=false;
	eof=true;
      }
    } else {
      pthread_cond_wait(&decoderCond,&decoderMut);
   }
  }
  server->clearbuffer();
  delete server;
  delete player;
  server = NULL;
  player = NULL;
}



int splay_open(char *path) {
  decoderLock();
  int err;
  loader = Soundinputstream::hopen(path, &err);
  if (!loader) {
    decoderUnlock();
    return 0;
  }
  song_path = path;
  lDecoderLoop=true;
  lDecode=false;
  eof=false;
  decoderUnlock();
  while(linDecoderLoop==true) {
    usleep(500);
  }
  return 1; 
}

void splay_close() {
  decoderLock();
  lDecode=false;
  lDecoderLoop=false;
  decoderUnlock();
  while(linDecoderLoop==false) {
    usleep(500);
  }
  if (loader != NULL) {
    delete loader;
    loader =NULL;
  }
}
  

void splay_pause(void){
  decoderLock();
  lDecode=false;
  decoderUnlock();
  
}

void splay_play(){
  decoderLock();
  lDecode=true;
  decoderUnlock();
}


void splay_getModuleInfo(char *id, char *version, char *copyright) {
   strcpy(id, "splay");
   strcpy(version, "0.8.2");
   strcpy(copyright, "1998 Woo-jae Jung");
}



void splay_getMusicInfo(struct playlist_item *song) {
   float len;
   struct stat mp3stat;
   stat(song->path, &mp3stat);
   len = mp3stat.st_size / 418.12;
   len = (int)(len / 16) * 16;
   song->length = (int)(rint(len/38.28));
   song->tag.genre = -1;
   if (song->tag.genre == -1)
      strcpy(song->name, strrchr(song->path,'/') + 1);
   else
      strcpy(song->name, song->tag.song);
}

void splay_config(char *left, char *right) {
  if (strcmp(left,"-m")==0) {
    monoFlag=true;
  }
  if (strcmp(left,"-2")==0) {
    downSampleFlag=true;
  }
  
}



int splay_getStreamState() {
  if (eof) {
    return _STREAM_STATE_EOF;
  } 
  return _STREAM_STATE_NOT_EOF;
}





void* splay_thread(void* arg) {
  pthread_mutex_lock(&decoderMut);
  while(lCreatorLoop) {
    linDecoderLoop=true;
    if (pthread_mutex_trylock(&changeMut) == EBUSY) {
      pthread_cond_wait(&decoderCond,&decoderMut);
      continue;
    }
    pthread_mutex_unlock(&changeMut);
    if (lDecoderLoop) {
      linDecoderLoop=false;
      decoder_loop();
    } else {
      pthread_cond_wait(&decoderCond,&decoderMut);
    }
  }
  pthread_mutex_unlock(&decoderMut);
  return NULL;
}

   

void splay_construct() {
  pthread_cond_init(&decoderCond,NULL);

  pthread_mutex_init(&changeMut,NULL);
  pthread_mutex_init(&decoderMut,NULL);
  loader =NULL;
  server =NULL;
  player =NULL;
  lCreatorLoop=true;
  lDecoderLoop=false;
  linDecoderLoop=false;
  pthread_create(&tr,NULL,splay_thread,NULL);
}


void splay_destruct() {
  void* ret;
  decoderLock();
  lDecoderLoop=false;
  lCreatorLoop=false;
  lDecode=false;
  pthread_join(tr,&ret);
  decoderUnlock();
}
