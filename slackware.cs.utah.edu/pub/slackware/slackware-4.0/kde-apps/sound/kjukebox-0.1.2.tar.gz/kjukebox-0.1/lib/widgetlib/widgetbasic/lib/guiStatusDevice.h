/*
  gui part for the status device (very simple)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __GUISTATUSDEVICE_H
#define __GUISTATUSDEVICE_H

#include <qpainter.h>
#include <qpushbt.h>
#include <qlayout.h>
#include <qslider.h>


#include <devices/streamInfoDevice.h>
#include <yafcore/buffer.h>

#include <guiDevice.h>





class GuiStatusDevice : public GuiDevice {
  Q_OBJECT

  StreamInfoDevice* streamInfoDevice;

 public:
  GuiStatusDevice( QWidget *parent=0, const char *name=0 );
  ~GuiStatusDevice();


  int getStatus();

  QSize sizeHint ();
  void paintEvent ( QPaintEvent * paintEvent );

 protected:
  void processEvent(char eventId);

};


#endif
