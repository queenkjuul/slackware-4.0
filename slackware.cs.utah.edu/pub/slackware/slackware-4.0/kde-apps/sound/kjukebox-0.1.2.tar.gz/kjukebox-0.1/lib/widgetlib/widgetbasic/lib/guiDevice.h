/*
  start of a generic gui Device
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __GUIDEVICE_H
#define __GUIDEVICE_H


#include <guiDeviceCore.h>

#include <menuDescription.h>
#include <kpopmenu.h>
#include <preferences.h>


/**
  This add decoration stuff to the core gui device.<p>
  - popupmenus<p>
  - configuration options<p>
  - icons etc.....<p>


*/



class GuiDevice : public GuiDeviceCore  {
  Q_OBJECT

  Preferences* preferences;
  
 public:
  GuiDevice( QWidget *parent=0, const char *name=0 );
  ~GuiDevice();

  void insertMenu(char* text,QObject* receiver,const char* signal);
  void setDevice(OutputDevice* device);
  Preferences* getPreferences();
  KPopupMenu* createPopupMenu();

  
 private:
  MenuDescription* menuDescription;

};


#endif



    
