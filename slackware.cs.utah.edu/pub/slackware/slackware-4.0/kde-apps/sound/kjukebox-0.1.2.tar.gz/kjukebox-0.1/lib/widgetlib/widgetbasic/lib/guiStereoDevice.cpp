/*
  show if stream is stero or not
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <guiStereoDevice.h>




GuiStereoDevice::GuiStereoDevice(QWidget *parent=0, 
			       const char *name=0):GuiDevice( parent, name ) {
  streamInfoDevice=new StreamInfoDevice();
  streamInfoDevice->setEventMask(_STREAMINFO_AUDIO_CHANGE);
  setDevice(streamInfoDevice);
  setMinimumSize( sizeHint() );
}


GuiStereoDevice::~GuiStereoDevice() {
  delete streamInfoDevice;
}


void GuiStereoDevice::processEvent(char eventId) {
  repaint(false);
}


int GuiStereoDevice::getStereo() {
  AudioInfo* audioInfo=streamInfoDevice->getAudioInfo();
  return audioInfo->getStereo();
}


QSize GuiStereoDevice::sizeHint () {
  return QSize(20,10);
}


void GuiStereoDevice::paintEvent ( QPaintEvent * paintEvent ) {
  int stereo;
  QPainter paint;

  erase(0,0,width(),height());
  stereo=getStereo();
  if (stereo == true) {
    paint.begin( this );
    paint.drawText(0,10,"stereo");
    paint.end();  
  } else {
    paint.begin( this );
    paint.drawText(0,10,"mono");
    paint.end();  
  }
  clearNotifyBit();
}
