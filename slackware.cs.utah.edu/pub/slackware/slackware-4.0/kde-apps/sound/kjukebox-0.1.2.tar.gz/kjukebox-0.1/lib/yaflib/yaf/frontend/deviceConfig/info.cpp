/*
  mechanism for easy (fast) detection if an object has changed internally
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <deviceConfig/info.h>



Info::Info() {
  change=false;
  valid=true;
}


Info::~Info() {
}


int Info::getValid() {
  return valid;
}


void Info::setValid(int valid) {
  this->valid=valid;
}


void Info::setChange(int lChange) {
  change=lChange;
}


int Info::getChange() {
  return change;
}

