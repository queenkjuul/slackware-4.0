
#ifdef __cplusplus
extern "C" {
#endif	
#include "../common.h"
#include <stdlib.h>



/*
  These are the C functions which really implement the 
  plugin behaviour.

  They are defined in: control.cc

*/

void splay_seek(int second);
int splay_open(char *path);
void splay_close();
void splay_pause(void);
void splay_play();
void splay_getModuleInfo(char *id, char *version, char *copyright);
void splay_getMusicInfo(struct playlist_item *song);
void splay_config(char *left, char *right);
void splay_construct();
void splay_destruct();
int splay_getStreamState();




struct player_plugin *splay_plugin(void);
#ifdef __cplusplus
}
#endif
