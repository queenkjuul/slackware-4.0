/*
  start of a generic gui Device
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <guiDeviceCore.h>



GuiDeviceCore::GuiDeviceCore( QWidget *parent=0, 
 		      const char *name=0 ) : QWidget(parent,name) {
  device=NULL;
  timer=new QTimer(this);
  connect( timer, SIGNAL(timeout()), this, SLOT(timeEvent()) );
}



GuiDeviceCore::~GuiDeviceCore() {
}


int GuiDeviceCore::startTimer ( int msec, bool sshot = false ) {
  int back;
  back=timer->start(msec,sshot);
  return back;
}

void GuiDeviceCore::stopTimer() {
  timer->stop();
}


OutputDevice* GuiDeviceCore::getDevice() {
  return device;
}


void GuiDeviceCore::setDevice(OutputDevice* device) {
  EventQueue* evenQueue=device->getEventQueue();
  connect(evenQueue,SIGNAL(processEvent(char)),this,SLOT(processEvent(char)));
  this->device=device;
}


void GuiDeviceCore::clearNotifyBit() {
  if (device != NULL) {
    EventQueue* eventQueue=device->getEventQueue();
    eventQueue->clearNotifyBit();
  }  
}

int GuiDeviceCore::getNotifyBit() {
  int back=false;

  if (device != NULL) {
    EventQueue* eventQueue=device->getEventQueue();
    eventQueue->getNotifyBit();
  }
  return back;
}


void GuiDeviceCore::processEvent(char eventId) {
}

void GuiDeviceCore::timeEvent() {
  repaint(false);
}

void GuiDeviceCore::setNotifyMode(int id) {
  cout <<"GuiDeviceCore::setNotifyMode"<<endl;
  if (device != NULL) {
    EventQueue* eventQueue=device->getEventQueue();
    eventQueue->setNotifyMode(id);
  }  
}  


void GuiDeviceCore::paintEvent ( QPaintEvent * paintEvent ) {
}


