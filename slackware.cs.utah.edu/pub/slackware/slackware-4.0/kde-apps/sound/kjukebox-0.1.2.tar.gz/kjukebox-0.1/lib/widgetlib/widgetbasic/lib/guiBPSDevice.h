/*
  show the bits per second in the stream
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __GUIBPSDEVICE_H
#define __GUIBPSQDEVICE_H

#include <qpainter.h>
#include <qpushbt.h>
#include <qlayout.h>
#include <qslider.h>


#include <devices/streamInfoDevice.h>
#include <yafcore/buffer.h>

#include <guiDevice.h>





class GuiBPSDevice : public GuiDevice {
  Q_OBJECT

  StreamInfoDevice* streamInfoDevice;

 public:
  GuiBPSDevice( QWidget *parent=0, const char *name=0 );
  ~GuiBPSDevice();


  int getBPS();

  QSize sizeHint ();
  void paintEvent ( QPaintEvent * paintEvent );

 protected:
  void processEvent(char eventId);

};


#endif
