/*
  stores deviceConfigFifos (each streamProducer in a seperate column)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef _MULTIQUEUEFIFO_H
#define _MULTIQUEUEFIFO_H

#include <deviceConfig/deviceConfigArray.h>
#include <deviceConfig/deviceConfigFifo.h>
#include <devices/nodeDevice.h>

/**
  This class can manage a deviceConfigFifo for each source.
  With this class it is possible that multiple sources
  write their DeviceConfig into the queue and if all of
  them have at least one entry you can simultaneously dequeue 
  the entry and pass them to a mixer device.
  <p>
  This class internally has switches for dequeing, but there
  are currently no public methods because the used
  algorithms work all in realtime.(At least on my cpu)

*/




#define _MAX_QUEUE_ENTRIES    5


class MultiQueueFifo {

  DeviceConfigFifo* fifoQueue[_MAX_QUEUE_ENTRIES];
  DeviceConfigArray* confArray;

 public:
  MultiQueueFifo();
  ~MultiQueueFifo();

  int canSimultaneousDequeue();
  void enqueue(StreamProducer* producer,DeviceConfig* config);
  
  DeviceConfigArray* multiDequeue();
  void multiForward();

 private:
  // returns position in Array with this source (or -1 if not found)
  int findQueue(StreamProducer* source);
  // returns position which is empty. (or -1 if non is empty)
  int findEmpty();
  DeviceConfigFifo* requestQueue(StreamProducer* producer);
  
};

#endif
