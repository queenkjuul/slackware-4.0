/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#include "mainwidget.h"

#include <qpopmenu.h>
#include <qkeycode.h>
#include <qlabel.h>
#include <kapp.h>
#include <qfile.h>
#include <kfiledialog.h>
#include <kmsgbox.h>
#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <qsplitter.h>


MainWidget::MainWidget(QWidget *parent,const char *name) 
  :QWidget(parent,name){

  genre = GENRE_ALL;
  
  splitter = new QSplitter(QSplitter::Horizontal,this, "splitter");
  //  splitter->setOpaqueResize (true);
  
  datalist = new SongTree(i18n("DataBase"),  splitter,"datalist");
  playlist = new SongList(i18n("Play List"), splitter,"playlist");
  //  datalist = new SongTree(splitter,"datalist");
  //  playlist = new SongList(splitter,"playlist");

  connect(datalist,SIGNAL(selectionChanged()),playlist,SLOT(clearSelection()));
  connect(datalist,SIGNAL(doubleClick()),this,SLOT(showMP3Info()));
  connect(playlist,SIGNAL(selectionChanged()),datalist,SLOT(clearSelection()));
  connect(playlist,SIGNAL(doubleClick()),this,SLOT(showMP3Info()));

  dropZone = new KDNDDropZone( datalist, DndURL );
  connect(dropZone,SIGNAL(dropAction(KDNDDropZone*)), SIGNAL(dropAction(KDNDDropZone *)));
  mp3Info = new SongInfo();

}


void MainWidget::showMP3Info(){
  Songs  tmpSongs;
  Song  *tmpSong;
  if (mp3Info == NULL) mp3Info = new SongInfo();
  tmpSong = datalist->getSelectedSongReference();
  if(tmpSong != NULL) mp3Info->showMP3Song(tmpSong);
  tmpSongs = playlist->getSongs();
  if(tmpSongs.size() != 0) mp3Info->showMP3Song(*(tmpSongs.begin()));
}  

void MainWidget::copySongIntoPlayList(){
  playlist->addSongs(datalist->getSongs());
}

void MainWidget::copyAllSongsIntoPlayList(){
  playlist->addSongs(datalist->getAllSongs());
}

void MainWidget::addSong(Song newSong){
  allSongs.push_back(newSong);
  genreAll.insert(newSong.getGenre());
  if ((strcmp(genre, newSong.getGenre())==0)||
      (strcmp(genre, GENRE_ALL)==0))
    datalist->addSong(newSong);
  emit genreChanged(genreAll);
  emit databaseChanged();
}

void MainWidget::addSongs(Songs newSongs){
  SongIterator lauf;
  for(lauf=newSongs.begin(); lauf!=newSongs.end(); lauf++){
    allSongs.push_back(*lauf);
    genreAll.insert(lauf->getGenre());
    if ((strcmp(genre, lauf->getGenre())==0)||
	(strcmp(genre, GENRE_ALL)==0))
      datalist->addSong(*lauf);
  }
  emit genreChanged(genreAll);
  emit databaseChanged();
}

void MainWidget::setGenre(QString newGenre){
  SongIterator lauf;
  Songs newList;
  genre = newGenre;
  for(lauf=allSongs.begin(); lauf!=allSongs.end(); lauf++){
    if ((strcmp(genre, lauf->getGenre())==0)||
	(strcmp(genre, GENRE_ALL)==0)){
      newList.push_back(*lauf);
    }
  }
  datalist->removeAllSongs();
  datalist->addSongs(newList);
}

Songs MainWidget::getSongs(){
  Songs tmp;
  tmp = datalist->getSongs();
  if(tmp.size() != 0) return (tmp);
  return (playlist->getSongs());
}

void MainWidget::removeSong(){
  datalist->removeSong();
  playlist->removeSong();
  emit databaseChanged();
}

void MainWidget::clearDataList(){
  datalist->removeAllSongs();
}

Songs MainWidget::getAllSongs(){
  return datalist->getAllSongs();
}

void MainWidget::removePlayedSongs(){
  playlist->removePlayedSongs();
}

void MainWidget::clearPlayList(){
  playlist->removeAllSongs();
}

Songs MainWidget::getFirstSongsToPlay(){
  return playlist->getFirstSongsToPlay();
}

Songs MainWidget::getRandomListOfSongsToPlay(){
 return playlist->getRandomListOfSongsToPlay();
}

void MainWidget::resizeEvent( QResizeEvent *tmp ){  
  QWidget::resizeEvent(tmp);
  splitter->setGeometry(5,1,width()-5,height()-1);
  //  datalist->setGeometry(5,  20, dataBaseBox->width()-10, dataBaseBox->height()-25);
  //  playlist->setGeometry(5, 20, playListBox->width()-10, playListBox->height()-25);
  
}


