/*
  abstract preferences tab
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <prefConfig.h>


PrefConfig::PrefConfig(QWidget * parent=0, const char * name=0) 
  :QWidget(parent,name) {
  
}


PrefConfig::~PrefConfig() {
}


char* PrefConfig::getGroupName() {
  return "";
}



void PrefConfig::load() {
}


void PrefConfig::save() {
}


void PrefConfig::apply() {
}






