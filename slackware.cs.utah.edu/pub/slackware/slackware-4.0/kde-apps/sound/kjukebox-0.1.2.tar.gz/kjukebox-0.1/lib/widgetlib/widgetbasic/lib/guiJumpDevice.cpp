/*
  This jumps in the stream. 
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */





#include <guiJumpDevice.h>




GuiJumpDevice::GuiJumpDevice(QWidget *parent=0, 
			       const char *name=0):GuiDevice( parent, name ) {
  player=NULL;
  streamInfoDevice=new StreamInfoDevice();
  updateSlider=false;
  setDevice(streamInfoDevice);
  sliderWidth=280;
  streamInfoDevice->setEventMask(_STREAMINFO_MUSIC_CHANGE |
				 _STREAMINFO_TIME_CHANGE  |
				 _STREAMINFO_STATUS_CHANGE );
}


GuiJumpDevice::~GuiJumpDevice() {
  delete streamInfoDevice;
}


void GuiJumpDevice::processEvent(char eventId) {

  switch (eventId) {
  case _STREAMINFO_TIME_CHANGE : {
    TimeInfo* timeInfo=streamInfoDevice->getTimeInfo();
    if (updateSlider) {
      int val=(int)((float)sliderWidth*
		    ((float)timeInfo->getTotalSec()/(float)len));
      if (val != sb->value()) {
	sb->setValue(val);
      }
    }
    break;
  }    
  case _STREAMINFO_STATUS_CHANGE : {
    StatusInfo* statusInfo=streamInfoDevice->getStatusInfo();
    status=statusInfo->getStatus();
    break;
  }
  case _STREAMINFO_MUSIC_CHANGE : {
    MusicInfo* musicInfo=streamInfoDevice->getMusicInfo();
    len=musicInfo->getLen();
    break;
  }
  }

  updateSlider=false;
  if ((status == _STATUS_PLAYING) && (len > 0)) {
    updateSlider=true;
  }
  if (status == _STATUS_STOPPED) {
    sb->setValue(0);
  }
  if (len <= 0) {
    sb->setValue(0);
  }
    

}
    


void GuiJumpDevice::buildGui() {
  sb = new QSlider(QSlider::Horizontal, this);
  sb->setRange(0,sliderWidth);
  sb->setValue( 0 );
  sb->setMinimumSize( sizeHint() );
  connect(sb,SIGNAL(sliderPressed()),SLOT(sliderPressed()));
  connect(sb,SIGNAL(sliderReleased()),SLOT(sliderReleased()));
}


void GuiJumpDevice::sliderPressed() {
  if (updateSlider) {
    streamInfoDevice->setEventMask(0);
  }
}


void GuiJumpDevice::sliderReleased() {
  if (player != NULL) {
    int val=sb->value();
    int sec=(int)((float)val/(float)sliderWidth*(float)len);
    if (updateSlider) {
      player->jump(sec);
    }
  }
  streamInfoDevice->setEventMask(_STREAMINFO_STATUS_CHANGE |
				 _STREAMINFO_MUSIC_CHANGE |
				 _STREAMINFO_TIME_CHANGE);
}

void GuiJumpDevice::setGenericPlayer(GenericPlayer* player) {
  this->player=player;
}

 
QSize GuiJumpDevice::sizeHint () {
  return QSize(sliderWidth,15);
}

 
void GuiJumpDevice::paintEvent ( QPaintEvent * paintEvent ) {
}



