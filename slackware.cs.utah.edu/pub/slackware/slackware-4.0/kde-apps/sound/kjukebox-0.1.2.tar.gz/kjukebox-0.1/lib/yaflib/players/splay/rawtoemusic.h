

#ifndef __RAWTOEMUSIC_H
#define __RAWTOEMUSIC_H

#include "mpegsound.h"







class Rawtoemusic : public Soundplayer
{
public:
  ~Rawtoemusic();
  void abort(void);
  bool initialize(char *filename);
  bool setsoundtype(int stereo,int samplesize,int speed);
  bool putblock(void *buffer,int size);
private:
  int rawstereo,rawsamplesize,rawspeed; 
};       

#endif
