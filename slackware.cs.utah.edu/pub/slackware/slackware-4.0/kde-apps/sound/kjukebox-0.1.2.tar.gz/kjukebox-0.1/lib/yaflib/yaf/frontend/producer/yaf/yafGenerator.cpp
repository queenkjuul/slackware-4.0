/*
  the yaf generator interface works together with yaf backend players
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <producer/yaf/yafGenerator.h>



static int instance=0;

YafGenerator::YafGenerator() {
  config=new DeviceConfig();
  tmp=new Buffer(100);

  musicInfo=config->getMusicInfo();
  audioInfo=config->getAudioInfo();
  statusInfo=config->getStatusInfo();
  audioBuffer=config->getAudioBuffer();
  timeInfo=config->getTimeInfo();
  mp3Info=config->getMP3Info();
  id3Info=config->getID3Info();
  
  audioBuffer->setPreferredFillGrade(4096);
  control=new YafXPlayerControl();
  stream=new YafStream(this);

  control->addYafListener(this);

  lClearRequest=false;
  pauseCmdNr=-1;
  fullUpdate=false;
  eofBytes=-1;

  instanceCnt=instance;
  instance++;
}


YafGenerator::~YafGenerator() {
  stream->close();
  control->send("quit\n");
  delete stream;
  control->addYafListener(NULL);
  delete control;
  delete config;
  delete tmp;
}


int YafGenerator::updateDeviceConfig(DeviceConfig* newConfig) {
  AudioBuffer* newAudioBuffer=newConfig->getAudioBuffer();
  AudioInfo* newAudioInfo=newConfig->getAudioInfo();
  TimeInfo* timeInfo=newConfig->getTimeInfo();
  int bytes;

  if (fullUpdate) {
    config->copyTo(newConfig);
    fullUpdate=false;
  }

  stream->fillBuffer(newAudioBuffer);
  bytes=newAudioBuffer->getReadBytes();
  newAudioInfo->setPlayedBytes(bytes);
  timeInfo->setSec(newAudioInfo->getTime());


  // if we read all bytes we make sure that the next
  // statusmessage is "stopped"
  if ((eofBytes > -1) && (bytes >= eofBytes)) {
    cout << "readBytes == eofBytes: "<<eofBytes<<endl;
    eofBytes=-1;
    return true;
  }
  return false;

}


int YafGenerator::open(char* filename ) {
  int back;
  close();
  back=control->open(filename);
  control->send("musicinfo\n");
  play();
  return back;
}


int YafGenerator::close() {
  pause();
  control->close();
  timeInfo->setTimeOffset(0);
  clearStream();
  statusInfo->setStatus(_STATUS_STOPPED);
  setThreadState(_STOP_WORKING);
  return true;
}


int YafGenerator::play() {
  control->play();
  statusInfo->setStatus(_STATUS_PLAYING);
  dataUpdate();
  return true;
}


int YafGenerator::pause() {
  statusInfo->setStatus(_STATUS_PAUSED);
  setThreadState(_PAUSE_WORKING);
  control->pause();
  return true;
}


int YafGenerator::jump(int sec) {
  pause();
  clearStream();
  timeInfo->setTimeOffset(sec);
  control->jump(sec);
  play();
  return true;
}


void YafGenerator::processRuntimeCommand(int cmd,char* args) {
  int val;
  int point;
 

  if (cmd == _PLAYER_RUN_STREAMINFO_START) {
    audioInfo->setValid(false);
    dataUpdate();
  }
  if (cmd == _PLAYER_RUN_STREAMINFO_CHANNELS) {
    sscanf(args,"%d %d",&val,&point);
    audioInfo->setStereo(0);
    if (val == 2) {
      audioInfo->setStereo(1);
    }
  }
  if (cmd == _PLAYER_RUN_STREAMINFO_SAMPLESIZE) {
    sscanf(args,"%d %d",&val,&point);
    audioInfo->setSampleSize(val);
  }
  if (cmd == _PLAYER_RUN_STREAMINFO_SPEED) {
    sscanf(args,"%d %d",&val,&point);
    audioInfo->setSpeed(val);
  }
  if (cmd == _PLAYER_RUN_STREAMINFO_END) {
    audioInfo->setValid(true);
    dataUpdate();
  }


  if (cmd == _PLAYER_RUN_MUSICINFO_START) {
    musicInfo->setValid(false);
    dataUpdate();
  }
  if (cmd == _PLAYER_RUN_MUSICINFO_SONG_NAME) {
    musicInfo->setName(args);
  }
  if (cmd == _PLAYER_RUN_MUSICINFO_SONG_LEN) {
    sscanf(args,"%d",&val);
    musicInfo->setLen(val);
  }
  if (cmd == _PLAYER_RUN_MUSICINFO_END) {
    musicInfo->setValid(true);
    dataUpdate();
  }
    

  if (cmd == _PLAYER_RUN_MP3_INFO_START) {
    mp3Info->setValid(false);
    dataUpdate();
  }
  if (cmd == _PLAYER_RUN_MP3_BPS) {
    sscanf(args,"%d",&val);
    mp3Info->setBPS(val);
  }
  if (cmd == _PLAYER_RUN_MP3_INFO_END) {
    mp3Info->setValid(true);
    dataUpdate();
  }

  if (cmd == _PLAYER_RUN_ID3_INFO_START) {
    id3Info->setValid(false);
    dataUpdate();
  }
  if (cmd == _PLAYER_RUN_ID3_NAME) {
    id3Info->setName(args);
  }
  if (cmd == _PLAYER_RUN_ID3_ARTIST) {
    id3Info->setArtist(args);
  }
  if (cmd == _PLAYER_RUN_ID3_ALBUM) {
    id3Info->setAlbum(args);
  }
  if (cmd == _PLAYER_RUN_ID3_YEAR) {
    id3Info->setYear(args);
  }
  if (cmd == _PLAYER_RUN_ID3_COMMENT) {
    id3Info->setComment(args);
  }
  if (cmd == _PLAYER_RUN_ID3_GENRE) {
    sscanf(args,"%d",&val);
    id3Info->setGenre(val);
  }
  if (cmd == _PLAYER_RUN_ID3_INFO_END) {
    id3Info->setValid(true);
    dataUpdate();
  }


  if (cmd == _PLAYER_RUN_FILEOPEN) {
    if (strcmp(args,"after")==0) {
     cout <<"::::::::::::::::::::::::.fifo Kralle ::::::::::::::"<<endl;
     control->setOnline(true);
    }
  }
  if (cmd == _PLAYER_RUN_PLAYER_STATUS) {
    if (strlen(args) >= 3) {
      if ( strncmp("off",args,3) == 0 ) {
	long allWrite;
	sscanf(args,"off %ld %ld",&eofBytes,&allWrite);
	cout << "****eofPos:"<<eofBytes<<" allWrite:"<<allWrite<<endl;
      } else {
	eofBytes=-1;
      }
    }
  }

  if (cmd == _YAF_RUN_EXIT) {
    setThreadState(_GENERATOR_CRASHED);
  }
    


}

void YafGenerator::processReturnCommand(int cmdNr,int cmdId,
				       char* ret,char* args) {
  if (cmdNr == pauseCmdNr){
    pauseCmdNr=-1;
    stream->clear();
    stream->setWriteRing(true);
    eofBytes=-1;
    control->setOnline(true);
    lClearRequest=false;
  }

}


void YafGenerator::addArgument(char* arg) {
  control->addArgument(arg);
}


void YafGenerator::startDecoder() {

  control->startDecoder();
  stream->setWriteRing(false);     // do not write in RingBuffer
  stream->clear();                 // clear RingBuffer
  
  control->send(stream->getFifoCommand());
  control->setOnline(false);

}

void YafGenerator::bufferFilledNotify(int filled) {
  audioBuffer->setBufferFilled(filled);
  dataUpdate();
}



// If this method is called it must be sure
// that the thread is at leased "paused"

void YafGenerator::clearStream() {
  if (lClearRequest == false) {
    audioBuffer->setBufferFilled(false);
    lClearRequest=true;
    pauseCmdNr=control->send("pause\n");
    stream->setWriteRing(false);
    stream->clear();
    control->setOnline(false);  // buffer following commands
  }
}




void YafGenerator::dataUpdate() {
  int lNotify=true;
  
  if (audioBuffer->getBufferFilled() == false) {
    lNotify=false;
  }
  if (audioInfo->getValid() == false) {
    lNotify=false;
  }
  if (musicInfo->getValid() == false) {
    lNotify=false;
  }

  if (lNotify) {
    if (lClearRequest == false) {
      if (statusInfo->getStatus() == _STATUS_PLAYING) {
	setThreadState(_START_WORKING);
      }
    }
  }
}



void YafGenerator::setThreadState(int msg) {
  ThreadNotifier* client;
  client=getThreadNotifier();
  client->sendSyncMessage(_NOT_ALLOW_GENERATOR_ENTER);

  
  if (msg==_START_WORKING) {
    client->sendAsyncMessage(msg);
    client->sendSyncMessage(_ALLOW_GENERATOR_ENTER);
  }
  if (msg==_PAUSE_WORKING) {
    client->sendAsyncMessage(msg);
    client->sendSyncMessage(_NOT_ALLOW_GENERATOR_ENTER);
  }  
  if ((msg==_STOP_WORKING) || (msg ==_STOP_WORKING_BECAUSE_EOF)) {
    audioInfo->setValid(false);
    musicInfo->setValid(false);
    audioBuffer->setBufferFilled(false);
    client->sendAsyncMessage(msg);
    client->sendSyncMessage(_NOT_ALLOW_GENERATOR_ENTER);
  }  
  if (msg==_GENERATOR_CRASHED) {
    setThreadState(_STOP_WORKING);
    client->sendSyncMessage(msg);
  }  


  fullUpdate=true;
}
    


