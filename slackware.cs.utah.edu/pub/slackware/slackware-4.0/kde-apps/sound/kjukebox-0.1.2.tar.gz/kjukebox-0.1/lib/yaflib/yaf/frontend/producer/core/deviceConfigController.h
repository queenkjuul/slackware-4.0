/*
  generic for open/close/jump methods
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */





#ifndef __DEVICECONFIGCONTROLLER_H
#define __DEVICECONFIGCONTROLLER_H

/**
  This class is an abstract for the user commands.
*/

class DeviceConfigController {


 public:
  DeviceConfigController();
  virtual ~DeviceConfigController();

  virtual int open(char* filename );
  virtual int close();
  virtual int play();
  virtual int pause();
  virtual int jump(int sec);

};

#endif
