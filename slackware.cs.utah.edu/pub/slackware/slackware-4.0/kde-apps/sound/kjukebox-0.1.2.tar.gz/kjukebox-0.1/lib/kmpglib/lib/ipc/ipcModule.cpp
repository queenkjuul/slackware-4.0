/*
  whole ipc stuff in one class
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <ipc/ipcModule.h>


IPCModule::IPCModule() {

  ipcCom=NULL;
  sd=::socket(AF_UNIX,SOCK_STREAM,0);
  if (sd < 0) {
    perror("socket-IPCModule");exit(1);
  }

  // create data directory if necessary
  QString p = getenv( "HOME" );
  QString rcDir = p + "/.kde/share/apps/kmpg";
  if ( access( rcDir, F_OK ) ) {
    mkdir( rcDir, 0740 );
  }
  

  QString ipcfile = p + "/.kde/share/apps/kmpg/kmpg.ipc";
  QString lockfile = p + "/.kde/share/apps/kmpg/kmpg.lck";
  char* data=ipcfile.data();
  int fd=open(lockfile.data(),O_RDONLY|O_CREAT);
  if (fd < 0) {
    perror("open");exit(1);
  }
  if (chmod(lockfile.data(),S_IRUSR|S_IWUSR) < 0) {
     perror("chmod");exit(1);
  }
  
  if (flock(fd,LOCK_EX|LOCK_NB) < 0) {
    cout << "First is false"<<endl;
    lFirst=false;
  } else {
    cout << "First is true"<<endl;
    unlink(data);
    if (fcntl(fd,F_SETFD,true) < 0) {
      perror("lockfile");exit(1);
    }
 
    lFirst=true;
  }
  
  unsigned int i=0;
  sockad.sun_family=AF_UNIX;

  while(i<strlen(data)) {
        sockad.sun_path[i]=data[i];
        i++;
  }
  sockad.sun_path[i]=0;
  if (lFirst) {
    if (bind(sd,(sockaddr*)&sockad,strlen(data)+2)<0) {
      perror("bind");exit(1);
    }
    if (listen(sd,1) < 0) {
      perror("listen");exit(1);
    }
    if (fcntl(sd,F_SETFD,true) < 0) {
      perror("fcntl socket");exit(1);
    }

    ipcCom=new IPCCom(sd,&sockad);
    connect(ipcCom,SIGNAL(processCommandLine(CommandLineCreator*)),
	    this,SLOT(processCommandLine(CommandLineCreator*)));
  }

  
}


IPCModule::~IPCModule() {
  if (ipcCom != NULL) {
    delete ipcCom;
  }
}


int IPCModule::isFirst() {
  return lFirst;
}


void IPCModule::send(int nargs,char** args) {
  IPCElement* ipcElement;

  if (::connect(sd,(sockaddr*)&sockad,strlen((char*)&sockad.sun_path)+2)<0) {
    perror("IPCModule::send connect");exit(1);
  }

  ipcElement=new IPCElement(sd);
  
  ipcElement->send(__IPC_ID_START,"");
  ipcElement->send(__IPC_ID_INT_DATA,nargs);
  int i;
  for(i=0;i<nargs;i++) {
    ipcElement->send(__IPC_ID_CHAR_DATA,args[i]);
  }
  ipcElement->send(__IPC_ID_END,"");
  ipcElement->receive();

  if (close(sd) < 0) {
    perror("close");exit(1);
  }
}




void IPCModule::processCommandLine(CommandLineCreator* commandLineCreator) {
  KmpgCommandLine::parseIPC(commandLineCreator);
}
  
