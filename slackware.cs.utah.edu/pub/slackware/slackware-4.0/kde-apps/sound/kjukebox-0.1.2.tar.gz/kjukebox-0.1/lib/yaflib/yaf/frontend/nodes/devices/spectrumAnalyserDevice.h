/*
  this device analyses the spectrum and sends notify messages.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __SPECTRUMANALYSERDEVICE_H
#define __SPECTRUMANALYSERDEVICE_H

#include <devices/outputDevice.h>
#include <filter/realFFTFilter.h>
#include <filter/fftFilter.h>

/**
  This spectrum analyser devices make a few nasty things with
  the frequency spectrum because it should look nicer.
  <p>
  The idea is to increase the higer frequency values
  (because they are otherwise to small on the scrren)

*/


class SpectrumAnalyserDevice : public OutputDevice {

  RealFFTFilter* realFFTFilter;
  FFTFilter* fftFilter;
  int bands;
  int showBands;   // 2/3 of bands. (the bands we show)
  int calcBands;
  int* fftArray;
  int* percentArray;
  float* volumeArray;
  int points;

  int analyseFreq;
  int counter;
  int lAnalyse;
 public:

  SpectrumAnalyserDevice();
  ~SpectrumAnalyserDevice();
  char* getNodeName();

  int getBands();
  int* getBandPtr();

  void setAnalyseFreq(int analyseFreq);
  void setAnalyse(int lAnalyse);    // sets spectrum analyse on/of

  void writeIn(NodeDevice* source,DeviceConfig* buf);

 protected:
  int hasData();

};
#endif


