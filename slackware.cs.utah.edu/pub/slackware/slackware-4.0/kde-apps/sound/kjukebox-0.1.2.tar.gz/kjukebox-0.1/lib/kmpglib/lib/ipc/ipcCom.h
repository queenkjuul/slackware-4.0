/*
  sends/receive commandline
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __IPCCOM_H
#define __IPCCOM_H


#include <signal/toolkit/eventQueue.h>
#include <ipc/commandLineCreator.h>
#include <ipc/ipcElement.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <sys/un.h>
#include <iostream.h>

class IPCCom : public QObject {
 Q_OBJECT

  pthread_t tr;
  int lRun;
  int socket;
  EventQueue* eventQueue;
  CommandLineCreator* commandLineCreator;
  int lBusy;
  struct sockaddr_un* sockad;

 public:
  IPCCom(int socket,struct sockaddr_un* sockad);
  ~IPCCom();

  void readloop();

 signals:
   void processCommandLine(CommandLineCreator* cmdLine);

 private slots:
   void hasCommandLine(char eventId);
  

};


#endif
