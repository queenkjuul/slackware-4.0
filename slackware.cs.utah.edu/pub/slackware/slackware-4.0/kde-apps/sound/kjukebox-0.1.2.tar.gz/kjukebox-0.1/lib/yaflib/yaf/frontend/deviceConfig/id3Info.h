/*
  stores id3 tags
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __ID3INFO_H
#define __ID3INFO_H

#include <deviceConfig/info.h>
#include <iostream.h>
#include <stdio.h>

/**
   This class make an AllTrim(x) on all setOperations. This
   means that you cannot insert leading/ending spaces.
*/


class ID3Info : public Info {

  char name   [30+1];
  char artist [30+1];
  char album  [30+1];
  char year   [ 4+1];
  char comment[30+1];
  unsigned char genre;

 public:

  ID3Info();
  ~ID3Info();

  char* getName();
  char* getArtist();
  char* getAlbum();
  char* getYear();
  char* getComment();
  unsigned char getGenre();

  void setName(char* name);
  void setArtist(char* artist);
  void setAlbum(char* album);
  void setYear(char* year);
  void setComment(char* comment);
  void setGenre(unsigned char genre);
 

  void copyTo(ID3Info* dest);
  void print();

 private:
  void alltrimcpy(char* dest,char* src,int max);

};
#endif
