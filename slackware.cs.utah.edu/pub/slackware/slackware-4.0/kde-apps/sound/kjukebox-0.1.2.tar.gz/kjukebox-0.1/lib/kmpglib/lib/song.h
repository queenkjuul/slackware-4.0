/*
  The song class. An element in a modell.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __SONG_H
#define __SONG_H
	
#include <deviceConfig/musicInfo.h>
#include <deviceConfig/id3Info.h>
#include <deviceConfig/mp3Info.h>
#include <id/tag.h>
#include <id/layer.h>

#include <kurl.h>
#include <qobject.h>
#include <qpainter.h>

#include <iostream.h>

/**
   The url you set with setUrl is then owned by this class.
*/
	
class Song : public QObject{
 Q_OBJECT
 
   KURL* kurl;
   int lPlayed;
   ID3Info* id3Info;
   MusicInfo* musicInfo;
   MP3Info* mp3Info;
   int lShufflePlay;
   int lCorrupt;

 public:
  Song(char* url);
  ~Song();

 public slots: 
  void setID3Info(ID3Info* id3Info);
  ID3Info* getID3Info();

  void setMusicInfo(MusicInfo* musicInfo);
  MusicInfo* getMusicInfo();

  MP3Info* getMP3Info();
  void setMP3Info(MP3Info* mp3Info);

  KURL* getSong();
  void setPlayed(int lPlayed);
  int getPlayed();

  void setShufflePlay(int lShufflePlay);
  int getShufflePlay();

  int getCorrupt();
  void setCorrupt(int lCorrupt);

  /** 
      Conversion functions from kmp3te to the yaf classes
  */
  void transformTag2Yaf(Tag* tag);
  void transformLayer2Yaf(Layer* layer);
  


  void print();
 signals:
  void songUpdateEvent(Song* song);
};
#endif




