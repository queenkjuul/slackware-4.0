/*
  streams data from one source to n listeners
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */

#include <devices/outputDevice.h>


#ifndef __MULTICASTDEVICE_H
#define __MULTICASTDEVICE_H


class MulticastDevice : public OutputDevice {


 public:

  MulticastDevice();
  ~MulticastDevice();
  char* getNodeName();
  

  /** 
      called by sources
      <p>
      Note: in a Streambuffer we have the Sender/Source of this buffer piece
  */
  void writeIn(NodeDevice* source,DeviceConfig* buf);
};


#endif

