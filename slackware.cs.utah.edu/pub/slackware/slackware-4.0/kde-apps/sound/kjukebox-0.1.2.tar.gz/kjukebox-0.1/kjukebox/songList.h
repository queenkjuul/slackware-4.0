#ifndef SONGLIST_H
#define SONGLIST_H
#include <qwidget.h>
#include <ktablistbox.h> 
#include <kpopmenu.h>
#include <qstring.h>
#include "kjukebox.h"
#include <qgroupbox.h>

class SongList : public QWidget{
  Q_OBJECT
 private:
  int          artistWidth;
  int          titleWidth;
  int          timeWidth;
  KTabListBox *table;
  int          selectedIndex;
  Songs        songs;
  SongIterator iterator;
  QString      genreToDisplay;
  Genre        genreList;
  QString      songAsString(Song);
  QGroupBox   *box;
  void refreshDisplay();
  void setupSurface(QString);

 public:
  SongList(QString, QWidget *parent=0, const char *name=0);
  SongList(QWidget *parent=0, const char *name=0);
  Songs getSongs();
  Songs getAllSongs();
  Songs  getFirstSongsToPlay();
  Songs getRandomListOfSongsToPlay();
  void  removePlayedSongs();
  void  checkGenre();
  void  removeAllSongs();
  
 protected:
  void resizeEvent(QResizeEvent *);
  
 signals:
  void selectionChanged();
  void doubleClick();
  void genreChanged(Genre );

  private slots:
    void selectionChanged(int,int);
  void doubleClick(int,int);
  
  public slots:
    void clearSelection();
  void addSong(Song);
  void addSongs(Songs);
  void removeSong();
  void setGenre(QString );

};
  
#endif
