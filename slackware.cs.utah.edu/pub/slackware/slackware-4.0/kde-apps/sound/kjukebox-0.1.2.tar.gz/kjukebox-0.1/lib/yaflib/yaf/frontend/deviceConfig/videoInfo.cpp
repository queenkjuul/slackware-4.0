/*
  Video data for yaf. Still experimental!
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <deviceConfig/videoInfo.h>



VideoInfo::VideoInfo() {
  memChunk=new MemChunk(0);
}


VideoInfo::~VideoInfo() {
  delete memChunk;
}


QPixmap* VideoInfo::getPixmap() {
  return pixmap;
}


void VideoInfo::setPixmap(QPixmap* pixmap) {
  this->pixmap=pixmap;
}


void VideoInfo::copyTo(VideoInfo* videoInfo) {
  videoInfo->setPixmap(getPixmap());
}


MemChunk* VideoInfo::getMemChunk() {
  return memChunk;
}


  
