/*
  The song class. An element in a modell.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <song.h>


Song::Song(char* aurl) {
  QString string(aurl);
  Tag* tag=new Tag();
  Layer* layer= new Layer();

  KURL::decodeURL(string);
  kurl=new KURL(string.data());
  lPlayed=false;
  lShufflePlay=false;
  lCorrupt=false;

  id3Info=new ID3Info();
  musicInfo=new MusicInfo();
  mp3Info=new MP3Info();

  musicInfo->setName((char*)kurl->filename());
  transformTag2Yaf(tag);
  transformLayer2Yaf(layer);
  delete layer;
  delete tag;
}


Song::~Song() {
  delete kurl;
  delete id3Info;
  delete musicInfo;
  delete mp3Info;

}


void Song::setID3Info(ID3Info* aInfo) {
  aInfo->copyTo(id3Info);
}


void Song::setMusicInfo(MusicInfo* aInfo) {
  aInfo->copyTo(musicInfo);
}


ID3Info* Song::getID3Info() {
  return id3Info;
}


MusicInfo* Song::getMusicInfo() {
  return musicInfo;
}


MP3Info* Song::getMP3Info() {
  return mp3Info;
}


void Song::setMP3Info(MP3Info* aInfo) {
  aInfo->copyTo(mp3Info);
}


KURL* Song::getSong() {
  return kurl;
}

void Song::setPlayed(int lPlayed) {
  this->lPlayed=lPlayed;
  emit(songUpdateEvent(this));
}


int Song::getPlayed() {
  return lPlayed;
}


void Song::transformTag2Yaf(Tag* tag) {
  if (tag->get((char*)kurl->path()) == true) {
    id3Info->setName(tag->getTitle());
    id3Info->setArtist(tag->getArtist());
    id3Info->setAlbum(tag->getAlbum());
    id3Info->setYear(tag->getYear());
    id3Info->setComment(tag->getComment());
    id3Info->setGenre((unsigned char)tag->getGenreNum());
    emit(songUpdateEvent(this));
  } else {
    setCorrupt(true);
  }
}


void Song::transformLayer2Yaf(Layer* layer) {
  if (layer->get((char*)kurl->path()) == true) {
    musicInfo->setLen(layer->length());
    mp3Info->setBPS(layer->bitrate());
    emit(songUpdateEvent(this));
  } else {
    setCorrupt(true);
  }
}
  
 
  
void Song::print() {
  cout << kurl->filename()<<endl;
}


void Song::setShufflePlay(int lShufflePlay) {
  if (this->lShufflePlay != lShufflePlay) {
    this->lShufflePlay=lShufflePlay;
    emit(songUpdateEvent(this));
  }
}


int Song::getShufflePlay() {
  return lShufflePlay;
}


int Song::getCorrupt() {
  return lCorrupt;
}


void Song::setCorrupt(int lCorrupt) {
  this->lCorrupt=lCorrupt;
}

