/*
  whole ipc stuff in one class
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */





#ifndef __IPCMODULE_H
#define __IPCMODULE_H

#include <ipc/ipcElement.h>
#include <ipc/ipcCom.h>

#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/file.h>

#include <errno.h>
#include <qstring.h>
#include <qobject.h>
#include <kmpgCommandLine.h>

class IPCModule: public QObject {
 Q_OBJECT

   int sd;
   struct sockaddr_un sockad;
   struct sockaddr_un partn_ad;
   char* path;
   int lFirst;
   IPCCom* ipcCom;
 
 public:
  IPCModule();
  ~IPCModule();
  
  int isFirst();
  void send(int nargs,char** args);

 public slots:
  void processCommandLine(CommandLineCreator* cmdLine);

};
#endif
