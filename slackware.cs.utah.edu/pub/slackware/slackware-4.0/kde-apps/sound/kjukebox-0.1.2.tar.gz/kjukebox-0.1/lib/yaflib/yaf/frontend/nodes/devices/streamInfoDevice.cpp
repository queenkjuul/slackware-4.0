/*
  delivers general status/info messages of the stream
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <devices/streamInfoDevice.h>


StreamInfoDevice::StreamInfoDevice() {
  statusInfo=new StatusInfo();
  musicInfo=new MusicInfo();
  timeInfo=new TimeInfo();
  id3Info=new ID3Info();
  mp3Info=new MP3Info();
  audioInfo=new AudioInfo();
  audioBuffer=new AudioBuffer();

  eventMask=_STREAMINFO_STATUS_CHANGE |
            _STREAMINFO_MUSIC_CHANGE |
            _STREAMINFO_TIME_CHANGE |
            _STREAMINFO_ID3_CHANGE |
            _STREAMINFO_MP3_CHANGE |
            _STREAMINFO_BUFFERFILL_CHANGE |
            _STREAMINFO_AUDIO_CHANGE ;
            
  // no "drops" of events allowed!
  getEventQueue()->setNotifyMode(_NOTIFY_ALL);
}


StreamInfoDevice::~StreamInfoDevice() {
  delete statusInfo;
  delete musicInfo;
  delete timeInfo;
  delete mp3Info;
  delete id3Info;
  delete audioInfo;
  delete audioBuffer;
}


char* StreamInfoDevice::getNodeName() {
  return "StreamInfoDevice";
}


StatusInfo* StreamInfoDevice::getStatusInfo() {
  return statusInfo;
}


MusicInfo* StreamInfoDevice::getMusicInfo() {
  return musicInfo;
}


TimeInfo* StreamInfoDevice::getTimeInfo() {
  return timeInfo;
}

MP3Info* StreamInfoDevice::getMP3Info() {
  return mp3Info;
}


ID3Info* StreamInfoDevice::getID3Info() {
  return id3Info;
}


AudioInfo* StreamInfoDevice::getAudioInfo() {
  return audioInfo;
}


AudioBuffer* StreamInfoDevice::getAudioBuffer() {
  return audioBuffer;
}


void StreamInfoDevice::setEventMask(int mask) {
  eventMask=mask;
}


int StreamInfoDevice::getEventMask() {
  return eventMask;
}


void StreamInfoDevice::writeIn(NodeDevice* source,DeviceConfig* buf) {
  StatusInfo* statusInfoStream=buf->getStatusInfo();
  MusicInfo* musicInfoStream=buf->getMusicInfo();
  TimeInfo* timeInfoStream=buf->getTimeInfo();
  MP3Info* mp3InfoStream=buf->getMP3Info();
  ID3Info* id3InfoStream=buf->getID3Info();
  AudioInfo* audioInfoStream=buf->getAudioInfo();
  AudioBuffer* audioBufferStream=buf->getAudioBuffer();
  
  if (eventMask & _STREAMINFO_BUFFERFILL_CHANGE) {
    if (audioBufferStream->getChange()) {
      audioBufferStream->copyTo(audioBuffer);
      getEventQueue()->sendEvent(_STREAMINFO_BUFFERFILL_CHANGE);
    }
  }
  if (eventMask & _STREAMINFO_MP3_CHANGE) {
    if (mp3InfoStream->getChange()) {
      mp3InfoStream->copyTo(mp3Info);
      getEventQueue()->sendEvent(_STREAMINFO_MP3_CHANGE);
    }
  }
  if (eventMask & _STREAMINFO_ID3_CHANGE) {
    if (id3InfoStream->getChange()) {
      id3InfoStream->copyTo(id3Info);
      getEventQueue()->sendEvent(_STREAMINFO_ID3_CHANGE);
    }
  }

  if (eventMask & _STREAMINFO_TIME_CHANGE) {
    if (timeInfoStream->getChange()) {
      timeInfoStream->copyTo(timeInfo);
      getEventQueue()->sendEvent(_STREAMINFO_TIME_CHANGE);
    }
  }

  if (eventMask & _STREAMINFO_MUSIC_CHANGE) {
    if (musicInfoStream->getChange()) {
      musicInfoStream->copyTo(musicInfo);
      getEventQueue()->sendEvent(_STREAMINFO_MUSIC_CHANGE);
    }
  }

  if (eventMask & _STREAMINFO_STATUS_CHANGE) {
    if (statusInfoStream->getChange()) {
      statusInfoStream->copyTo(statusInfo);
      getEventQueue()->sendEvent(_STREAMINFO_STATUS_CHANGE);
    }
  }

  if (eventMask & _STREAMINFO_AUDIO_CHANGE) {
    if (audioInfoStream->getChange()) {
      audioInfoStream->copyTo(audioInfo);
      getEventQueue()->sendEvent(_STREAMINFO_AUDIO_CHANGE);
    }
  }
}


