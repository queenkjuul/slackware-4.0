/*
  a nicer widget for the volume.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include "volumeWidget.h"




VolumeWidget::VolumeWidget( QWidget *parent=0, const char *name=0 ):
             GuiVolumeDevice( parent, name ) {

}


VolumeWidget::~VolumeWidget() {
}


void VolumeWidget::buildGui() {
  slider = new KSlider(0,100,5,100,KSlider::Horizontal,this,"Slider");

  slider->setTickmarks( QSlider::NoMarks );
  slider->setValue(getVolume());

  connect( slider, SIGNAL(valueChanged(int)),this,SLOT(setVolume(int)) );
}


QSize VolumeWidget::sizeHint () {
  QSize size(100,28);
  return size;
}




 
