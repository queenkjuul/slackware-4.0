/*
  Configuration Dialog for ipcModule
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <ipcConfig.h>



IPCConfig::IPCConfig(QWidget * parent=0, const char * name=0 )
                     : PrefConfig(parent,name) {
  config = kapp->getConfig();
  configGroup="IPC";
  load();

 
  QButtonGroup *bg = new QButtonGroup( "playlist received", this );
  QVBoxLayout *vbox = new QVBoxLayout(bg, 5);
  vbox->addSpacing( bg->fontMetrics().height() );
  QRadioButton* rb1 = new QRadioButton( "direct play" ,bg );
  bg->insert(rb1,_IPC_NOARGUMENT_PLAY);
  rb1->setMinimumSize( rb1->sizeHint() );

  QRadioButton* rb2 = new QRadioButton( "insert last" ,bg );
  rb2->setMinimumSize( rb2->sizeHint() );
  bg->insert(rb2,_IPC_NOARGUMENT_APPEND);
 

  QRadioButton* rb3 = new QRadioButton( "ignore" ,bg );
  rb3->setMinimumSize( rb3->sizeHint() );
  bg->insert(rb3,_IPC_NOARGUMENT_IGNORE);
  

  vbox->addWidget(rb1);
  vbox->addWidget(rb2);
  vbox->addWidget(rb3);

  bg->setButton(mode);
  setNoArgMode(mode);
  bg->setGeometry(20, 40, 300, 120 );

  QLabel* lineLable = new QLabel(this);
  lineLable->setGeometry(20,180,300,50);
  lineLable->setText("This defines the behaviour of new instances of kmpg.");

  connect(bg,SIGNAL(pressed (int)),SLOT(setNoArgMode(int)));
}


IPCConfig::~IPCConfig() {
}


char* IPCConfig::getGroupName() {
  return "IPC";
}


void IPCConfig::load() {
  config->setGroup(configGroup);
  mode=config->readNumEntry( "noArgumentMode", _IPC_NOARGUMENT_PLAY);
 
}


void IPCConfig::save() {
  config->setGroup(configGroup);
  config->writeEntry("noArgumentMode",mode);
}


void IPCConfig::apply() {
  save();
}


void IPCConfig::setNoArgMode(int mode) {
  this->mode=mode;
  KmpgCommandLine::setArgMode(mode);
}
