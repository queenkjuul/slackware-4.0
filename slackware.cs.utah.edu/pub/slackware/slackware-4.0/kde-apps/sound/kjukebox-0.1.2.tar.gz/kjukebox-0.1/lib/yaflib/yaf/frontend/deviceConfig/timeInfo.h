/*
  stores the time of the current stream
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __TIMEINFO_H
#define __TIMEINFO_H


#include <deviceConfig/info.h>
#include <iostream.h>

class TimeInfo : public Info {
  
 public:
  TimeInfo();
  ~TimeInfo();

  void setSec(int secs);
  int getSec();

  int getTotalSec();
  
  void setTimeOffset(int sec);
  int getTimeOffset();

  void copyTo(TimeInfo* dest);
  void print();

 private:

   int secs; 
   int offset;
};


#endif
