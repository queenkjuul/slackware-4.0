/*
  Configuration Dialog for playlistView1
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __PLAYLISTVIEW1CONFIG_H
#define __PLAYLISTVIEW1CONFIG_H

#include <prefConfig.h>
#include <playlistOperation.h>


#include <kconfig.h>
#include <kapp.h>

#include <qlabel.h>
#include <qpushbt.h>
#include <qbttngrp.h>
#include <qradiobt.h>
#include <qchkbox.h>
#include <qlined.h>
#include <qtabdlg.h>
#include <qlayout.h>



#define _PLV1_SMART_DROP 1
#define _PLV1_AT_END     2



class PlaylistView1Config : public PrefConfig {
 Q_OBJECT
   
   KConfig* config;
   char* configGroup;
   int dropMode_cfg;

 public:
  PlaylistView1Config(QWidget * parent=0, const char * name=0 );
  ~PlaylistView1Config();

  char* getGroupName();
  void load();
  void save();
  void apply();

 public slots:
   void setDropMode(int mode);
   int getDropMode();
};
#endif
