/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include "../config.h"
#include "songList.h"
#include "songTree.h"
#include "configfolder.h"
#include "ioaccess.h"
#include "songInfo.h"

#include <ktmainwindow.h>
#include <kmenubar.h>
#include <kstatusbar.h>
#include <drag.h>
#include <qstring.h>
#include <qscrollbar.h>
#include <qsplitter.h>

class MainWidget: public QWidget{
  Q_OBJECT
 private:
  SongTree     *datalist;
  SongList     *playlist;
  SongInfo     *mp3Info;
  KDNDDropZone *dropZone;
  Songs         allSongs;
  QString       genre;  
  Genre         genreAll;
  QSplitter    *splitter;

 protected:
  void resizeEvent (QResizeEvent *);
 public:
  MainWidget(QWidget *parent=0, const char *name=0);
  void  clearDataList();
  Songs getAllSongs();
  Songs getSongs();
  void  addSongs(Songs);
  void  removePlayedSongs();
  Songs getFirstSongsToPlay();
  Songs getRandomListOfSongsToPlay();
  void  clearPlayList();

 signals:
  void genreChanged(Genre);
  void dropAction(KDNDDropZone *);
  void databaseChanged();
 public slots:
  void showMP3Info();
  void addSong(Song);
  void setGenre(QString);
  void copySongIntoPlayList();
  void copyAllSongsIntoPlayList();
  void removeSong();
};

#endif //MAINWIDGET_H
