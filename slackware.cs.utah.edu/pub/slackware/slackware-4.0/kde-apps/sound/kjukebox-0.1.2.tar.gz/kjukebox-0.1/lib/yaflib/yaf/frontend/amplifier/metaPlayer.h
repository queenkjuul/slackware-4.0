/*
  a metaPlayer stores a device tree and can change internally the yafPlayer
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __METAPLAYER_H
#define __METAPLAYER_H



#include <util/controlChannel.h>
#include <devices/genericPlayer.h>
#include <iostream.h>





/** 
   The MetaPlayer class is the class from which a GUI should
   derive from. You can see the MetaPlayer as an "empty"
   hifi-player. It has buttons for open,close,... and
   it constructs the internally devices like timeDisplay
   and the spectrumAnalyser (or more) and stores these devices
   forever. But what is missing in this class ist the
   "mechanik parts" which make the musik. This is done
   by a genericPlayer who does not now about the
   devices in the MetaPlayer. You can attach a GenericPlayer
   to a MetaPlayer. The MetaPlayer then connect its
   device tree to the GenericPlayer and waits for input (like play).
   <p>
   Then on another command (the User selects the next item
   out of the playlist) The MetaPlayer stays on the screen,
   But this time we need a GenericPlayer which does not decode
   mp3 files but midi. Thus we remove the GenericPlayer
   from the MetaPlayer and insert a GenericPlayer who
   knows hot to play midi files. 
   You see: The internal device tree stays the same,
   we only switch the "decoding engine".
   <p>
   In general the MetaPlayer has the task to store the devices,
   because these stay the same or can be removed, switched on/off,
   or the user can add new device (like a device which writes
   the pcm data to a wav file). This device tree is in the MetaPlayer,
   or better said in a derived class. Because the MetaPlayer is an
   abstract class.


*/



class MetaPlayer  {

  GenericPlayer* player;


 public:
  MetaPlayer();
  virtual ~MetaPlayer();

  virtual int open(char* filename );
  int close();
  int pause();
  int play();
  int jump(int sec);

  virtual void setGenericPlayer(GenericPlayer* player);
  GenericPlayer* getGenericPlayer();


 protected:
  virtual OutputDevice* getInternalDeviceTree()=0;
  

};

#endif




   
