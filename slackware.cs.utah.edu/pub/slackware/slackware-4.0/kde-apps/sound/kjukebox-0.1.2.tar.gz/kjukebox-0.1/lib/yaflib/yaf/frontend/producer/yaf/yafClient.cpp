/*
  starts a new yafclient and stores the stdout,stdin,sterr channels
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <producer/yaf/yafClient.h>



    
YafClient::YafClient()  {
  pthread_mutex_init(&mut,NULL);

  multicaster=new YafMulticaster();

  // block writeStdin and buffer until we have started the subprocess
  lSending=true;
  outputDecoder=new OutputDecoderBridge(this);
  yafProcess = new YafProcess();
  inLineStack = new LineStack();
  outLineStack = new LineStack();
  tmpBuffer=new Buffer(2000);
  msgBuffer=new Buffer(2000);
  parser=new Parser();
  cmdNr=100;       // we must start with a nr > 40 <= is resevered!
}


void YafClient::addArgument(char* arg) {
  (*yafProcess) << arg;
}



void YafClient::startDecoder() {
  char* msg="protocol\n";
  int writeStatus;
  connect( yafProcess, SIGNAL(processExited(YafProcess*)),
	   SLOT(processExited(YafProcess*)));

  connect( yafProcess, SIGNAL(receivedStdout(YafProcess*, char*, int)),
	   SLOT(receivedStdout(YafProcess*, char*, int)));

  connect( yafProcess, SIGNAL(receivedStderr(YafProcess*, char*, int)),
	   SLOT(receivedStderr(YafProcess*, char*, int)));
  connect( yafProcess, SIGNAL(wroteStdin(YafProcess* )),
	            SLOT(  wroteStdin(YafProcess* )) );

  yafProcess->start(YafProcess::NotifyOnExit,YafProcess::All);
  // Ok after we have started the client we set him in raw-protocol-state
  lSending=true;
  writeStatus=yafProcess->writeStdin(msg,strlen(msg));
}



YafClient::~YafClient() {

  disconnect(yafProcess);
  disconnect(this);

  if (yafProcess->isRunning()) {
    yafProcess->kill();
  }
  

  delete parser;
  delete inLineStack;
  delete outLineStack;
  delete tmpBuffer;
  delete yafProcess;
  delete msgBuffer;
}


int YafClient::createCommand(char* msg, Buffer* cmd) { 
  int back=cmdNr;

  QString number;
  number=number.setNum(cmdNr);
  cmdNr++;

  cmd->clear();

  cmd->append("Command:");
  cmd->append(number.data());
  cmd->append(" Msg:");
  cmd->append(msg);

  return back;
}


int YafClient::send(char* msg) {
  int back;
  back=createCommand(msg,msgBuffer);
  rawSend(msgBuffer->getData());
  return back;
}




/*
  The return code is the number which is atteched to this command msg
*/
void YafClient::rawSend(char* msg) {
  pthread_mutex_lock(&mut);
  if (lSending == false){
    lSending=true;
    writeStdinToProcess(msg,strlen(msg));
  } else {
    inLineStack->appendBottom(msg,strlen(msg));
  }
  pthread_mutex_unlock(&mut);
}
  

void YafClient::writeStdinToProcess(char* buf,int len) {
  int success;
  success=yafProcess->writeStdin(buf,len);
#ifdef _DEBUG_WRITE_STDIN
  ofstream infile("writeStdin.dbg",ios::app);
  Buffer myOut(80);
  myOut.append(buf,len);
  infile << "Success:"<<success<< "msg:"<<myOut.getData() <<endl;
#endif
}


void YafClient::wroteStdin(YafProcess *proc) {
  pthread_mutex_lock(&mut);
  if (inLineStack->hasLine()) {
    lSending=true;
    inLineStack->nextLine(tmpBuffer);
    tmpBuffer->append("\n");
    writeStdinToProcess(tmpBuffer->getData(),tmpBuffer->len());
  } else {
    lSending=false;
  }
  pthread_mutex_unlock(&mut);

}
  

void YafClient::receivedStdout(YafProcess* proc, char* buffer, int buflen) {
  QString msg(buffer,buflen);
  CommandLine* commandLine;
  outLineStack->appendBottom(buffer,buflen);
#ifdef _DEBUG_STDOUT
  ofstream infile("receivedStdout.dbg",ios::app);
  Buffer myOut(80);
  myOut.append(buffer,buflen);
  infile << myOut.getData() <<endl;
#endif
  while(outLineStack->hasLine()) {
    outLineStack->nextLine(tmpBuffer);
    parser->setParseString(tmpBuffer->getData());
    parser->parse();
    
    if (parser->isOK()){
      commandLine=parser->getCommandLine();
      outputDecoder->processCommandLine(commandLine);  // Outputdecoder

    }
  }
}

void YafClient::receivedStderr(YafProcess* proc, char* buffer, int buflen) {
  QString msg(buffer,buflen);
  //cout << "Stderr: "<<msg<<endl;
}

void YafClient::processExited(YafProcess* proc) {

  if (proc->isRunning() == false) {
    processRuntimeCommand(_YAF_RUN_EXIT,"decoder terminated");
  }
  cout << "******      ERROR *******************************"<<endl;
  cout << "* - splay-yaf decoder not found "<<endl;
  cout << "* - decoder crashed"<<endl;
  cout << "* - you dont have splay-yaf in the search path!"<<endl;
  cout << "*"<<endl;
  cout << "*************************************************"<<endl;
    
}


//
//  Bridge to fix compiler bug (?) [START]
//


int YafClient::processRuntimeCommand(int command,char* args) {
  multicaster->multicastRuntimeCommand(command,args);
  return 1;
}



int YafClient::processReturnCommand(int cmdNr,int cmdId,
					      char* ret,char* args) {
  multicaster->multicastReturnCommand(cmdNr,cmdId,ret,args);
  return 1;
}

void YafClient::addYafListener(ControlChannel* listener) {
  multicaster->addYafListener(listener);
}


void YafClient::appendCommandTable(CommandTable* table) {
  outputDecoder->appendCommandTable(table);
}


void YafClient::appendRuntimeTable(CommandTable* table) {
  outputDecoder->appendRuntimeTable(table);
}
 

//
//  Bridge to fix compiler bug (?) [END]
//

   
