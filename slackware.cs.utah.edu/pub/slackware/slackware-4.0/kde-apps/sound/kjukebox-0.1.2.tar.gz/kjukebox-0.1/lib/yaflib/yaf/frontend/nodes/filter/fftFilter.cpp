/*
  a FFT filter with real/imagery part (can calculate inverse fft!)
  Copyright (C) 1998  Martin Vogt;Philip VanBaren, 2 September 1993

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <filter/fftFilter.h>

FFTFilter::FFTFilter() {
  int i;
  points = 512;
  data=new float[2*points];  
  window=new float[points];
  fft= new FFT();

  /* Create the window function (Blackman) */                             
  for(i=0;i<points;i++) {
    window[i]=0.42-0.5*cos(2*M_PI*i/points)+0.08*cos(4*M_PI*i/points);   
  }
}


FFTFilter::~FFTFilter() {
  delete data;
  delete fft;
  delete window;
}


int FFTFilter::getPoints() {
  return points;
}


float* FFTFilter::getPointPtr() {
  return data;
}


/*
  the array is expected to be a PCM stream (real data)
*/
void FFTFilter::fft16(DeviceConfig* input,short* aPoints) {
  int i;
  int j;

  AudioInfo* audioInfo=input->getAudioInfo();
  //AudioBuffer* audioBuffer=input->getAudioBuffer();
  //  MemChunk* memChunk=audioBuffer->getMemChunk();

  int stereo=audioInfo->getStereo();
  short* shortPtr=aPoints;


  if (stereo == 1) {
    for (i = 0, j = 0; i < points; i++, j+=2) {
      data[j] = (float)(shortPtr[j]);
      data[j+1]=0.0;
    }
    
  }
  fft->rfft(data,points*2,1);
}



void FFTFilter::inverseFFT16(float* data) {
  fft->fft(data,points*2,-1);
}


