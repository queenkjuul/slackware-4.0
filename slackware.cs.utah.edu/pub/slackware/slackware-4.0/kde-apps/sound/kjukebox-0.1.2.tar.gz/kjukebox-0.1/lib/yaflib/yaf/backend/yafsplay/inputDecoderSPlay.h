
/*
  concrete Implementation of a decoder (for splay)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __INPUTDECODERSPLAY_H
#define __INPUTDECODERSPLAY_H


#include <yafxplayer/inputDecoderXPlayer.h>


#include <yafcore/commandLine.h>
#include <yafcore/buffer.h>
#include <yafcore/buffer.h>
#include <players/common.h>
#include <pthread.h>



class InputDecoderSPlay : public InputDecoderXPlayer {

  
 public:
  InputDecoderSPlay(player_plugin* plugin);
  ~InputDecoderSPlay();

  char* processCommand(int command,char* args);
  void doSomething();

 private:

  int lFileSelected;
  player_plugin* plugin;
  struct playlist_item musicInfo;
  Buffer* songPath;
};


#endif

