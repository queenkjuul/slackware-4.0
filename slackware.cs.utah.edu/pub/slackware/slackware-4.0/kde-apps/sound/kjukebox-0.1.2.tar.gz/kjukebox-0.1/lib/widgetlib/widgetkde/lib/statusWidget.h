/*
  a nicer widget for the status.The default yaf widget is (supposed) ugly
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */






#ifndef __STATUSWIDGET_H
#define __STATUSWIDGET_H

#include <guiStatusDevice.h>
#include "led.h"

/**
   This widget show how you can add your own look and feel.
   Simple overwrite the paint method.

*/

class StatusWidget : public GuiStatusDevice {

  LED* led;

 public:
   StatusWidget( QWidget *parent=0, const char *name=0 );
  ~StatusWidget();


  QSize sizeHint ();
  void paintEvent ( QPaintEvent * paintEvent );
 

};
#endif
