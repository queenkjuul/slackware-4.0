/*
  stores deviceConfig data
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <deviceConfig/deviceConfig.h>


DeviceConfig::DeviceConfig() {
  musicInfo=new MusicInfo();
  statusInfo=new StatusInfo();
  audioInfo=new AudioInfo();
  volumeInfo=new VolumeInfo();
  audioBuffer=new AudioBuffer();
  videoInfo=new VideoInfo();
  timeInfo=new TimeInfo();
  id3Info=new ID3Info();
  mp3Info=new MP3Info();
  streamProducer=NULL;
}


DeviceConfig::~DeviceConfig() {
  delete musicInfo;
  delete statusInfo;
  delete audioInfo;
  delete volumeInfo;
  delete videoInfo;
  delete audioBuffer;
  delete timeInfo;
  delete id3Info;
  delete mp3Info;
}

void DeviceConfig::copyTo(DeviceConfig* aConfig) {
  aConfig->setAudioInfo(getAudioInfo());
  aConfig->setVolumeInfo(getVolumeInfo());
  aConfig->setMusicInfo(getMusicInfo());
  aConfig->setStatusInfo(getStatusInfo());
  aConfig->setAudioBuffer(getAudioBuffer());
  aConfig->setVideoInfo(getVideoInfo());
  aConfig->setTimeInfo(getTimeInfo());
  aConfig->setID3Info(getID3Info());
  aConfig->setMP3Info(getMP3Info());
}


void DeviceConfig::setChangeToAll(int change) {
  audioInfo->setChange(change);
  volumeInfo->setChange(change);
  videoInfo->setChange(change);
  musicInfo->setChange(change);
  statusInfo->setChange(change); 
  audioBuffer->setChange(change);
  timeInfo->setChange(change);
  id3Info->setChange(change);
  mp3Info->setChange(change);
}


void DeviceConfig::setAudioInfo(AudioInfo* audio) {
  audio->copyTo(audioInfo);
}


AudioInfo* DeviceConfig::getAudioInfo() {
  return audioInfo;
}


void DeviceConfig::setVolumeInfo(VolumeInfo* volume) {
  volume->copyTo(volumeInfo);
}


VolumeInfo* DeviceConfig::getVolumeInfo() {
  return volumeInfo;
}


void DeviceConfig::setMusicInfo(MusicInfo* music) {
  music->copyTo(musicInfo);
}


MusicInfo* DeviceConfig::getMusicInfo() {
  return musicInfo;
}


void DeviceConfig::setStatusInfo(StatusInfo* status) {
  status->copyTo(statusInfo);
}


StatusInfo* DeviceConfig::getStatusInfo() {
  return statusInfo;
}


void DeviceConfig::setAudioBuffer(AudioBuffer* aBuffer) {
  aBuffer->copyTo(audioBuffer);
}


AudioBuffer* DeviceConfig::getAudioBuffer() {
  return audioBuffer;
}

void* DeviceConfig::getStreamProducer() {
  return streamProducer;
}


void DeviceConfig::setStreamProducer(void* streamProducer) {
  this->streamProducer=streamProducer;
}


void DeviceConfig::setID3Info(ID3Info* aID3Info) {
  aID3Info->copyTo(id3Info);
}


ID3Info* DeviceConfig::getID3Info() {
  return id3Info;
}



void DeviceConfig::setMP3Info(MP3Info* aMP3Info) {
  aMP3Info->copyTo(mp3Info);
}


MP3Info* DeviceConfig::getMP3Info() {
  return mp3Info;
}

void DeviceConfig::print() {
  statusInfo->print();
  audioBuffer->print();
  musicInfo->print();
  audioInfo->print();
  volumeInfo->print();
  
}


void DeviceConfig::setVideoInfo(VideoInfo* aVideoInfo) {
  aVideoInfo->copyTo(videoInfo);
}

  
VideoInfo* DeviceConfig::getVideoInfo() {
  return videoInfo;
}

 
void DeviceConfig::setTimeInfo(TimeInfo* time) {
  time->copyTo(timeInfo);
}

TimeInfo* DeviceConfig::getTimeInfo() {
  return timeInfo;
}

