/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#include <kapp.h>
#include <kurl.h>
#include <qstring.h>
#include <stdio.h>
#include "song.h"
#include <iostream.h>
#include "kjukebox.h"

Song::Song(){
  played = false;
  lastplayed = 0;
  size=0;
  bitrate = 0;
  samplerate=0;
  year=0;
  seconds=0;
  firstSeconds=0;
  lastSeconds=0;
}

QString Song::asQString(unsigned int value){
  char tmp[1000];
  sprintf(tmp,"%d",value);
  return ((QString)tmp);
}

QString Song::asString(){
  return asString(saveLoadFormat,saveLoadTrennzeichen);
}



QString Song::asString(QString format, QString trennzeichen){
  int startFormat;
  QString tmp;
  QString output = "";
  bool first = true;

  startFormat = -1;
  
  while(1){  
    if(!first) {
      output += trennzeichen;
      startFormat = format.find(trennzeichen,startFormat);
      if(startFormat == -1) break;
    }
    startFormat++;
    tmp = format.mid(startFormat,2);
    //    cout << "SF:" << startFormat << " tmp:" << tmp << endl;
    
    if     (strncmp(tmp,"FN",2)==0) output += filename;
    else if(strncmp(tmp,"TI",2)==0) output += title;
    else if(strncmp(tmp,"AR",2)==0) output += artist;
    else if(strncmp(tmp,"AL",2)==0) output += album;
    else if(strncmp(tmp,"CO",2)==0) output += comment;
    else if(strncmp(tmp,"GE",2)==0) output += genre;
    else if(strncmp(tmp,"LA",2)==0) output += layer;
    else if(strncmp(tmp,"ST",2)==0) output += stereomode;
    else if(strncmp(tmp,"BI",2)==0) output += asQString(bitrate);
    else if(strncmp(tmp,"SA",2)==0) output += asQString(samplerate);
    else if(strncmp(tmp,"SE",2)==0) output += asQString(seconds);
    else if(strncmp(tmp,"SI",2)==0) output += asQString(size);
    else if(strncmp(tmp,"YE",2)==0) output += asQString(year);
    else if(strncmp(tmp,"FS",2)==0) output += asQString(firstSeconds);
    else if(strncmp(tmp,"LS",2)==0) output += asQString(lastSeconds);

    first = false;
  }
  //  cout << output << endl;
  return output;
}


void Song::initFromString(QString text){
  initFromString(text, saveLoadFormat, saveLoadTrennzeichen);
}



void Song::initFromString(QString text, QString format, QString trennzeichen){
  int startText, endText;
  int startFormat;
  QString tmp, value;
  bool first = true;

  startText = endText = -1;
  startFormat = -1;

  while(1){  
    if(!first) {
      startFormat = format.find(trennzeichen,startFormat);
      startText   = text.find(trennzeichen,startText);
      if((startFormat == -1)||(startText == -1)) break;
    }
    startFormat++;
    tmp = format.mid(startFormat,2);

    startText++;
    endText = text.find(trennzeichen,startText);
    if(endText == -1) endText = 10000;
    value = text.mid(startText,endText-startText);

    //    cout << "tag:" << tmp << "  value:" << value << endl;

    if(strncmp(tmp,"FN",2)==0) filename = text.mid(startText,endText-startText);
    else if(strncmp(tmp,"TI",2)==0) title = text.mid(startText, endText-startText);
    else if(strncmp(tmp,"AR",2)==0) artist = text.mid(startText,endText-startText);
    else if(strncmp(tmp,"AL",2)==0) album = text.mid(startText,endText-startText);
    else if(strncmp(tmp,"CO",2)==0) comment = text.mid(startText,endText-startText);
    else if(strncmp(tmp,"GE",2)==0) genre = text.mid(startText,endText-startText);
    else if(strncmp(tmp,"LA",2)==0) layer = text.mid(startText,endText-startText);
    else if(strncmp(tmp,"ST",2)==0) stereomode = text.mid(startText,endText-startText);
    else if(strncmp(tmp,"BI",2)==0) bitrate = value.toUInt();
    else if(strncmp(tmp,"SA",2)==0) samplerate = value.toUInt();
    else if(strncmp(tmp,"SE",2)==0) seconds = value.toUInt();
    else if(strncmp(tmp,"SI",2)==0) size = value.toUInt();
    else if(strncmp(tmp,"YE",2)==0) year = value.toUInt();
    else if(strncmp(tmp,"FS",2)==0) firstSeconds = value.toInt();
    else if(strncmp(tmp,"LS",2)==0) lastSeconds  = value.toInt();
    first = false;
  }

  checkForPlausibility();
}


void Song::checkForPlausibility(){
  QString help;
  static int unkownFileCounter=0;
  help = filename;
  help.simplifyWhiteSpace();
  if(help.isEmpty()) {
    unkownFileCounter++;
    help = i18n("Unkown File");
    help.sprintf(i18n("Unkown File %d"), unkownFileCounter);
  }
  checkForPlausibility(help);
}

void Song::checkForPlausibility(QString helpFilename){
  QString help;
  int fs, ls, tmp;

  help = title;
  help.simplifyWhiteSpace();
  if(help.isEmpty()){
    KURL url(helpFilename);
    title =  url.filename();
  }
  else title = help;
  
  help = artist;
  help.simplifyWhiteSpace();
  if(help.isEmpty()) artist = i18n("Unkown");
  else artist = help;
  
  help = album;
  help.simplifyWhiteSpace();
  if(help.isEmpty()) album = i18n("Unkown");
  else album = help;
  
  help = comment;
  help.simplifyWhiteSpace();
  if(help.isEmpty()) comment = i18n("No Comment");
  else comment = help;
  
  help = genre;
  help.simplifyWhiteSpace();
  if(help.isEmpty()) genre = "Other";
  else genre = help;
  
  tmp = sscanf(comment,MP3_COMMENT_FIELD,&fs,&ls);
  if (tmp == 2){
    firstSeconds = fs;
    lastSeconds = ls;
  }
}

void Song::setTitle(QString wert){ title = wert; }
void Song::setArtist(QString wert){ artist = wert; }
void Song::setAlbum(QString wert){ album = wert; }
void Song::setComment(QString wert){ comment = wert; }
void Song::setGenre(QString wert){ genre = wert; }
void Song::setFilename(QString wert){ filename = wert; }
void Song::setStereomode(QString wert){ stereomode = wert; }
void Song::setLayer(QString wert){ layer = wert; }
void Song::setPlayed(bool wert){  played = wert; }
void Song::setLastPlayed(unsigned int  wert){  
  played = true; 
  lastplayed = wert; 
}
void Song::setSamplerate(unsigned int wert){ samplerate = wert; }
void Song::setBitrate(unsigned int wert){ bitrate = wert; }
void Song::setYear(unsigned int  wert){ year = wert; }
void Song::setSeconds(unsigned int  wert){ seconds = wert; }
void Song::setFirstSeconds(unsigned int  wert){ firstSeconds = wert; }
void Song::setLastSeconds(unsigned int  wert){ lastSeconds = wert; }
void Song::setSize(unsigned int  wert){ size = wert; }
QString Song::getTitle()   const { return  title; }
QString Song::getArtist()  const { return  artist; }
QString Song::getAlbum()   const { return  album; }
QString Song::getComment() const { return  comment; }
QString Song::getGenre()   const { return  genre; }
QString Song::getFilename() const{ return  filename; }
QString Song::getStereomode() const{return stereomode; }
QString Song::getLayer() const{return layer; }
bool   Song::getPlayed()  const { return  played; }
unsigned int Song::getLastPlayed() const {return lastplayed; }
unsigned int Song::getSamplerate() const { return  samplerate; }
unsigned int Song::getBitrate() const { return  bitrate; }
unsigned int Song::getYear() const { return  year; }
unsigned int Song::getSeconds() const { return  seconds; }
unsigned int Song::getFirstSeconds() const { return  firstSeconds; }
unsigned int Song::getLastSeconds() const { return  lastSeconds; }
unsigned int Song::getSize() const { return  size; }

bool Song::operator== (Song song){
  if (strcmp(title,song.getTitle())) return false;
  if (strcmp(artist,song.getArtist())) return false;
  if (strcmp(album,song.getAlbum())) return false;
  if (strcmp(comment,song.getComment())) return false;
  if (strcmp(genre,song.getGenre())) return false;
  if (strcmp(filename,song.getFilename())) return false;
  if (strcmp(stereomode,song.getStereomode())) return false;
  if (strcmp(layer,song.getLayer())) return false;
  if (samplerate != song.getSamplerate()) return false;
  if (bitrate != song.getBitrate()) return false;
  if (year != song.getYear()) return false;
  if (seconds != song.getSeconds()) return false;
  if (size != song.getSize()) return false;
  return true;
}
