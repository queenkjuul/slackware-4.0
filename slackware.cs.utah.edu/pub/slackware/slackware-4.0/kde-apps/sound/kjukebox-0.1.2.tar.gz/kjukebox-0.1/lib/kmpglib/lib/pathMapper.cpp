/*
  stores dos drivesnames and the unix path to it.
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <pathMapper.h>


PathMapper::PathMapper(char* format) {
  QString dummy1;
  QString dummy2;
  QString tupel(format);
  int len=tupel.length();

  drive=new Buffer(10);
  subst=new Buffer(10);
  asString=new Buffer(10);
  asFormat=new Buffer(10);
  
  if (len < 5) {
    return;
  }

  dummy1=tupel.left(2);
  dummy2=dummy1.right(1);
  drive->append(dummy2.data());

  dummy1=tupel.right(len-3);
  dummy2=dummy1.left(dummy1.length()-1);
  subst->append(dummy2.data());

  cout << "drive:"<<drive->getData()<<endl;
  cout << "subst:"<<subst->getData()<<endl;
}


PathMapper::~PathMapper() {
  delete drive;
  delete subst;
  delete asString;
  delete asFormat;
}


char* PathMapper::getDrive() {
  return drive->getData();
}


void PathMapper::setDrive(char* newDrive) {
  drive->clear();
  drive->append(newDrive);
  emit(pathMapperUpdateEvent(this));
}


char* PathMapper::getSubst() {
  return subst->getData();
}


void PathMapper::setSubst(char* newSubst) {
  subst->clear();
  subst->append(newSubst);
  emit(pathMapperUpdateEvent(this));
}


char* PathMapper::toString() {
  asString->clear();
  asString->append(drive->getData());
  asString->append(" --> ");
  asString->append(subst->getData());
  
  return asString->getData();
}



char* PathMapper::toFormat() {
  asFormat->clear();
  asFormat->append("(");
  asFormat->append(drive->getData());
  asFormat->append(";");
  asFormat->append(subst->getData());
  asFormat->append(")");
    
  return asFormat->getData();
}
