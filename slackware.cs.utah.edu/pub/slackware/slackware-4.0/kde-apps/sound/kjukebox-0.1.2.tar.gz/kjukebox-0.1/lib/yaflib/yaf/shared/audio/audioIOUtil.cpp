

#include <audio/audioIOUtil.h>


/* die - for terminal conditions prints the error message and exits */
/* can not be suppressed with -q,-quiet */
void die(char *fmt, ...)
{
        va_list ap;
        va_start(ap,fmt);
        vfprintf(stderr, fmt, ap);
        exit(-1);
}


/* warn - for warning messages. Can be suppressed by -q,-quiet                  */
void warn(char *fmt, ...)
{
        va_list ap;
        va_start(ap,fmt);
	fprintf(stderr,"Warning: ");
	vfprintf(stderr, fmt, ap);

}
