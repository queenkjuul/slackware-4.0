/*
  a metaPlayer stores a device tree and can change internally the yafPlayer
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <amplifier/metaPlayer.h>


MetaPlayer::MetaPlayer() {
  player=NULL;
}


MetaPlayer::~MetaPlayer() {
}


int MetaPlayer::open(char* filename ) {
  int back=0;
  if (player != NULL) {
    back=player->open(filename);
  }
  return back;
}


int MetaPlayer::close() {
  int back=0;
  if (player != NULL) {
    back=player->close();
  }
  return back;
}


  
int MetaPlayer::pause() {
  int back=0;
  if (player != NULL) {
    back=player->pause();
  }
  return back;
}


int MetaPlayer::play() {
  int back=0;
  if (player != NULL) {
    back=player->play();
  }
  return back;
}


int MetaPlayer::jump(int sec) {
  int back=0;
  if (player != NULL) {
    back=player->jump(sec);
  }
  return back;
}



void MetaPlayer::setGenericPlayer(GenericPlayer* sProducer) {
  OutputDevice* tree;

  if (player != NULL) {
    tree=getInternalDeviceTree();
    player->removeListener(tree);
  }
  
  player=sProducer;
  if (player != NULL) {
    tree=getInternalDeviceTree();
    player->addListener(tree);
  }
}



GenericPlayer* MetaPlayer::getGenericPlayer() {
  return player;
}






