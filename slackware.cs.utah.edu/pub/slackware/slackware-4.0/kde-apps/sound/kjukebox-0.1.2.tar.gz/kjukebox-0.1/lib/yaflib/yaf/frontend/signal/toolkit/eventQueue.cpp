/*
  this is a EventQueue. Every device has its own EventQueue.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <signal/toolkit/eventQueue.h>



EventQueue::EventQueue(char* owner) {
  ::pipe(fd);
  this->owner=owner;
  lData=false;
  ldebug=false;
  mode=_NOTIFY_IF_CLEAR;
  client=NULL;
  sn=new QSocketNotifier( fd[0], QSocketNotifier::Read, NULL );
  QObject::connect(sn,SIGNAL(activated(int)),this,SLOT(receiveEvent(int)));
  pthread_mutex_init(&dataMut,NULL);
}


EventQueue::~EventQueue() {
  disconnect(sn);
  disconnect(this);
  
  delete sn;
  close(fd[1]);
}


void EventQueue::sendEvent(char eventId) {
  pthread_mutex_lock(&dataMut);
  if (ldebug) {
    cout << "sendEvent entered:"<<owner<<" :"<<eventId<<" ";
  }
  if (mode == _NOTIFY_NO) {
    if (ldebug) {
      cout << "mode == _NOTIFY_NO exit"<<endl;
    }
    pthread_mutex_unlock(&dataMut);
    return;  
  }
  if (mode == _NOTIFY_IF_CLEAR) {
    if (ldebug) {
      cout << "mode == _NOTIFY_IF_CLEAR";
    }
    if (lData==false) {
      lData=true;
      if (ldebug) {
	cout << " lData==false ";
      }
      write(fd[1],(void*)(&eventId),1);
      if (ldebug) {
	cout << " write ready! "<<endl;
      }  
    } else {
      if (ldebug) {
	cout << " lData==true ";
      }
    }  
    pthread_mutex_unlock(&dataMut);
    return;
  }
  if (mode == _NOTIFY_ALL) {
    if (ldebug) {
      cout << "mode == _NOTIFY_ALL";
    }
    lData=true;
    write(fd[1],(void*)(&eventId),1);
    if (ldebug) {
	cout << " write ready! "<<endl;
    } 
    pthread_mutex_unlock(&dataMut);
    return;
  }
  cout << "unknown deliver mode!"<<endl;
  pthread_mutex_unlock(&dataMut);
}


void EventQueue::receiveEvent(int) {
  char dummy;
  ::read(fd[0],&dummy,1);
  if (ldebug) {
    cout << "receive event:"<<owner<<" :"<<dummy;
  }
  if (client != NULL) {
    if (ldebug) {
      cout << " forward event to client";
    }
    client->processEvent(dummy);
    if (ldebug) {
      cout << "..back from client";
    }
  }
  emit (processEvent(dummy)); 
  if (ldebug) {
    cout << " ready"<<endl;
  }
}


void EventQueue::setNotifyMode(int mode) {
  this->mode=mode;
}


void EventQueue::clearNotifyBit() {
  pthread_mutex_lock(&dataMut);
  lData=false;
  pthread_mutex_unlock(&dataMut);
}

int EventQueue::getNotifyBit() {
  return lData;
}



void EventQueue::setDebug(int flag) {
  ldebug=flag;
}


void EventQueue::addListener(NotifyClient* client) {
  this->client=client;
}

