/*
  a basic control widget
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __GUICONTROL_H
#define __GUICONTROL_H



#include <qpushbt.h>
#include <qpainter.h>
#include <qlayout.h> 



class GuiControl : public QWidget {
 Q_OBJECT

  QBoxLayout * layout;
  QPushButton* pauseButton;
  QPushButton* playButton;
  QPushButton* stopButton;
  
 public:
  GuiControl( QWidget *parent=0, const char *name=0 );
  ~GuiControl();
  QSize sizeHint ();
  void buildGui();

 signals:
   void playCurrentEvent();
   void playStopEvent();
   void playPauseEvent();
  
};


#endif

