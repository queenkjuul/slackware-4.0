/*
  management for memChunks
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <deviceConfig/memManager.h>


MemManager::MemManager() {
  pthread_mutex_init(&managerMut,NULL);
}


MemManager::~MemManager() {
}

void MemManager::lockMemManager() {
  pthread_mutex_lock(&managerMut);
}

void MemManager::unlockMemManager() {
  pthread_mutex_unlock(&managerMut);
}
 

void MemManager::lockMemChunk(MemChunk* memChunk) {
}

void MemManager::unlockMemChunk(MemChunk* memChunk) {
}


void MemManager::lockViolation(MemChunk* memChunk) {
  cout << "Your MemoryManagement Subsystem has detected";
  cout << "a lockViolation. *This cannot be ignored!*"<<endl;
  memChunk->print();
}


    
