/*
  fileoperations with the playlist model
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */





#include <playlistOperation.h>


static PathMapperConfig* pathMapperConfig=NULL;


PlaylistOperation::PlaylistOperation() {
}


PlaylistOperation::~PlaylistOperation() {
}


void PlaylistOperation::printPlaylist(Playlist* playlist) {
  Song* song;
  int i;
  int n=playlist->count();
  QString string;
  KURL* kurl;
 
  for( i=0; i<n; i++ ) {
    song=playlist->at(i);
    kurl=song->getSong();
  }
}  


int PlaylistOperation::writePlaylist(Playlist* playlist) {
  QString filename;
  QFileInfo fileInfo;
  filename = KFileDialog::getSaveFileName( 0,"*.m3u| m3u Playlist files\n"
					   "*.*| All files"  );
  if( filename.isNull() ) {
     return false;
  }  
  fileInfo.setFile(filename.data());
  if (fileInfo.extension()=="") {
    filename=filename+".m3u";
  }

  QTextStream stream;
  QFile file;
  file.setName( filename );
  if (file.open( IO_WriteOnly ) == false) {
    cout << "cannot open file"<<endl;
  }
  stream.setDevice( &file );
  Song* song;
  int i;
  int n=playlist->count();
  QString string;
  KURL* kurl;
  for( i=0; i<n; i++ ) {
    song=playlist->at(i);
    kurl=song->getSong();
    stream << kurl->path() << endl;
  }
  file.close();
  KURL kurlfile(filename);
  playlist->setName((char*)kurlfile.filename());
  return true;
}


Playlist* PlaylistOperation::readPlaylist() {
   QString filename;
   Playlist* playlist=new Playlist();
   QFileInfo fileInfo;
  
   filename = KFileDialog::getOpenFileName( 0, "*.m3u| m3u Playlist files\n"
					   "*.*| All files");

   if (filename.isNull()) {
     return NULL;
   }

   fileInfo.setFile(filename.data());
   if (fileInfo.extension() != "m3u") {
     return NULL;
   }
   KURL kurl(filename.data());

   PlaylistOperation::readPlaylist((char*)kurl.path(),playlist);
   return playlist;
}


void PlaylistOperation::insert(Playlist* src,Playlist* dest,int pos=-1) {
  int i;
  int n=src->count();
  QStrList strlist;
  Song* song;
  KURL* kurl;

  for( i=0; i<n; i++ ) {
    song=src->at(i);
    kurl=song->getSong();
    strlist.append(kurl->url());
  }
  PlaylistOperation::insert(&strlist,dest,pos);
} 


void PlaylistOperation::insert(QStrList* src,Playlist* dest,int pos=-1) {
  char* str;
  Song* song;
  Buffer* targetFilename=new Buffer(30);
  
  if (pos <= -1) {
    for( str=src->first(); str!=0; str=src->next() ){
      if (PlaylistOperation::canProcess(str,dest,targetFilename)) {
	song=new Song(targetFilename->getData());
	dest->addSong(song);
      }
    }
    delete targetFilename;
    return;
  }
  // otherwise insert at the position.
  int i=0;
  for( str=src->first(); str!=0; str=src->next() ){
    if (PlaylistOperation::canProcess(str,dest,targetFilename)) {
      song=new Song(targetFilename->getData());
      dest->addSong(song,pos+i);
      i++;
    }
  }
}



void PlaylistOperation::insert(KDNDDropZone* src,Playlist* dest,int pos=-1) {
  QStrList strlist;
  strlist = src->getURLList();
  PlaylistOperation::insert(&strlist,dest,pos);
}



int PlaylistOperation::loadSong(Playlist* playlist) {
  QString filename;
  Song* song;
  
  filename = KFileDialog::getOpenFileName( 0, "*.mp?" );
  if( filename.isNull() ) {
    return false;
  }
  song=new Song(filename.data());
  playlist->addSong(song);
  return true;
}

 
void PlaylistOperation::playNext(Playlist* playlist) {
  int play=0;
  int currentSong=playlist->getPlaySongPos();
  int count=playlist->count();
  if (playlist->getShuffle() == false) {
    if (count <= 0) {
      return;
    }
    play=currentSong+1;
    if (play >(count-1) ) {
      if (playlist->getRepeat()) {
	playlist->setCurrentPos(0);
	PlaylistOperation::playNextNotCorrupt(playlist);
      }
      return;
    }
    playlist->setCurrentPos(play);
    PlaylistOperation::playNextNotCorrupt(playlist);
    return;
  }
  PlaylistOperation::playShuffle(playlist);
}


void PlaylistOperation::playPrev(Playlist* playlist) {
  int play=0;
  int currentSong=playlist->getPlaySongPos();
  int count=playlist->count();

  if (playlist->getShuffle() == false) {
    if (count <= 0) {
      return;
    }
    play=currentSong-1;
    if (play < 0) {
      return;
    } 
    playlist->setCurrentPos(play);
    PlaylistOperation::playPrevNotCorrupt(playlist);
    return;
  }
  PlaylistOperation::playShuffle(playlist);

}


void PlaylistOperation::playCurrent(Playlist* playlist) {
  int pos=playlist->getCurrentPos();
  if (pos != -1) {
    playlist->playSong(pos);
    Song* song=playlist->at(pos);
    if (song != NULL) {
      song->setPlayed(true);
      if (playlist->getShuffle()) {
	song->setShufflePlay(true);
      }
    }
  }
}


int PlaylistOperation::getRandom(Playlist* playlist) {
  int back=-1;
  float percent=(float)random()/(float)RAND_MAX;
  float count=(float)playlist->count();
  if (count == 0.0) {
    return -1;
  }
  back=(int)(percent*count);
  return back;
}




void PlaylistOperation::playShuffle(Playlist* playlist) {
  Playlist* playlistShuffle=new Playlist();
  int i;
  Song* song;
  int n=playlist->count();

  if (n == 0) {
    return;
  }

  for(i=0;i<n;i++) {
    song=playlist->at(i);
    if (song->getShufflePlay() == false) {
      if (song->getCorrupt() == false) {
	playlistShuffle->addSong(song);
      }
    }
  }
  if (playlistShuffle->count() == 0) {
    if (playlist->getRepeat()) {
      playlist->setShuffle(false);
      playlist->setShuffle(true);
      PlaylistOperation::playShuffle(playlist);
      return;
    }
  }
  int index=PlaylistOperation::getRandom(playlistShuffle);
  if (index >= 0) {
    song=playlistShuffle->at(index);
    int indexPlaylist=playlist->find(song);
    if (song != NULL) {
      playlist->setCurrentPos(indexPlaylist);
      PlaylistOperation::playCurrent(playlist);
    }
  }
  delete playlistShuffle;
}


void PlaylistOperation::readPlaylist(char* filename,Playlist* playlist) {
  QFile file;
  QTextStream stream;
  QString string;
  QStrList strlist;

  file.setName( filename );
  if (file.open( IO_ReadOnly ) == false) {
    cout << "cannot open file:"<<filename<<endl;
    return;
  }

  stream.setDevice( &file );
  do {
    string = stream.readLine();
    strlist.append(string);
  } while(!stream.eof());
  file.close();
  PlaylistOperation::insert(&strlist,playlist);
  KURL kurl(filename);
  
  playlist->setName((char*)kurl.filename());
}



int PlaylistOperation::canProcess(char* file,Playlist* playlist,Buffer* dest){
  KURL kurl(file);
  QFileInfo fileInfo(kurl.path());
  dest->clear();

  if (fileInfo.isDir()) {
    cout << "directory drop not supported(yet)->qt-bug"<<endl;
    return false;
  }
  if (fileInfo.extension() == "m3u") {
    PlaylistOperation::readPlaylist((char*)kurl.path(),playlist);
    return false;
  }
  // Now translate dos paths
  /*
    Not for this release

  if (pathMapperConfig != NULL) {
    pathMapperConfig->translate(file,dest);
  }
  */
  // here should be a check for valid/registered file types/extensions
  // but for now... we accept everything
  dest->append((char*)kurl.path());
  return true;
}
      
    

void PlaylistOperation::setPathMapperConfig(
	      PathMapperConfig* mapperConfig){
  pathMapperConfig=mapperConfig;
}

 

void PlaylistOperation::playNextNotCorrupt(Playlist* playlist) {
  int count=playlist->count();
  int play=playlist->getCurrentPos();
  Song* song;
  for(int i=play;i<count;i++) {
    song=playlist->at(i);
    if (song->getCorrupt()) {
      continue;
    }
    playlist->setCurrentPos(i);
    PlaylistOperation::playCurrent(playlist);  
    break;
  }	
}



void PlaylistOperation::playPrevNotCorrupt(Playlist* playlist) {
  int play=playlist->getCurrentPos();
  Song* song;
  for(int i=play;i>=0;i--) {
    song=playlist->at(i);
    if (song->getCorrupt()) {
      continue;
    }
    playlist->setCurrentPos(i);
    PlaylistOperation::playCurrent(playlist);  
    break;
  }
}

 
