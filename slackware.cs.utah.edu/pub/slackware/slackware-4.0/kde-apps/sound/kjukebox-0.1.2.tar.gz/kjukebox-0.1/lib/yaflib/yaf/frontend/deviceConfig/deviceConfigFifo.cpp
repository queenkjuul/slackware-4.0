/*
  stores deviceConfig data in a fifo. (it makes a deep copy  of the data)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <deviceConfig/deviceConfigFifo.h>



DeviceConfigFifo::DeviceConfigFifo() {
  int i;

  freePos=0;
  lWaitForStoppedSource=false;
  lWaitForPausedSource=false;
  removeWhenEmpty=false;
  valid=false;
  lDequeued=false;


  for(i=0;i<_MAX_FIFO_ENTRIES;i++) {
    configQueue[i]=new DeviceConfig();
  }
}


DeviceConfigFifo::~DeviceConfigFifo() {
  int i;

  for(i=0;i<_MAX_FIFO_ENTRIES;i++) {
    delete configQueue[i];
  }
}


  

void DeviceConfigFifo::enqueue(DeviceConfig* config) {
  DeviceConfig* freePosConfig;
  MemChunk* memChunk;
  AudioBuffer* audioBuffer;
  StatusInfo* statusInfo;

  if (freePos == _MAX_FIFO_ENTRIES) {
    cout << "fifo overflow! ignore enqueue"<<endl;
    return;
  }
  freePosConfig=configQueue[freePos];
  config->copyTo(freePosConfig);
  audioBuffer=config->getAudioBuffer();
  memChunk=audioBuffer->getMemChunk();
  memChunk->addLock();
  if (freePos == 0) {
    statusInfo=config->getStatusInfo();
    status=statusInfo->getStatus();
  }

  freePos++;
  if (overflowDanger() == true) {
    DaisyChain* daisyChain=(DaisyChain*)(producer->getDaisyChain());
    daisyChain->addLock(this,producer);
  }
}


DeviceConfig* DeviceConfigFifo::dequeue() {
  MemChunk* memChunk;
  AudioBuffer* audioBuffer;

  audioBuffer=configQueue[0]->getAudioBuffer();
  memChunk=audioBuffer->getMemChunk();

  lDequeued=true;
  return configQueue[0];
}


void DeviceConfigFifo::forwardQueue() {
  int i;
  DeviceConfig* config;
  MemChunk* memChunk;
  AudioBuffer* audioBuffer;
  StatusInfo* statusInfo;

  // first we define the status of the fifo. by default a fifo
  // is active but if we forward the queue and the deviceConfig
  // say that the status is stopped the fifo gets inactive
  // it stays inactive until a deviceConfig is inserted with
  // playing status

  if (freePos == 0) return;
  
  if (lDequeued == false) {
    cout << "error forward without dequeue"<<endl;
  }
  lDequeued=false;
  config=configQueue[0];
  statusInfo=config->getStatusInfo();
  status=statusInfo->getStatus();
  audioBuffer=config->getAudioBuffer();
  memChunk=audioBuffer->getMemChunk();
  memChunk->removeLock();

  for(i=0;i<=freePos-1;i++) {
    configQueue[i]=configQueue[i+1];
  }
  configQueue[freePos]=config;

  freePos--;
  if (overflowDanger() == false) {
    DaisyChain* daisyChain=(DaisyChain*)(producer->getDaisyChain());
    daisyChain->removeLock(this,producer);
  }
}



int DeviceConfigFifo::overflowDanger() {
  return (freePos == (_MAX_FIFO_ENTRIES-2));
}

int DeviceConfigFifo::getFillgrade() {
  return freePos;
}



void DeviceConfigFifo::setValid(int valid) {
  this->valid=valid;
}


int DeviceConfigFifo::getValid() {
  return valid;
}



void DeviceConfigFifo::setStreamProducer(StreamProducer* producer) {
  this->producer=producer;
}

StreamProducer* DeviceConfigFifo::getStreamProducer() {
  return producer;
}


int DeviceConfigFifo::getWaitForStoppedSource() {
  return lWaitForStoppedSource;
}


void DeviceConfigFifo::setWaitForStoppedSource(int lWaitForStopped) {
  this->lWaitForStoppedSource=lWaitForStopped;
}


int DeviceConfigFifo::getWaitForPausedSource() {
  return lWaitForPausedSource;
}


void DeviceConfigFifo::setWaitForPausedSource(int lWaitForPaused) {
  this->lWaitForPausedSource=lWaitForPaused;
}


int DeviceConfigFifo::getDequeue() {
  return lDequeued;
}


int DeviceConfigFifo::getStatus() {
  return status;
}


