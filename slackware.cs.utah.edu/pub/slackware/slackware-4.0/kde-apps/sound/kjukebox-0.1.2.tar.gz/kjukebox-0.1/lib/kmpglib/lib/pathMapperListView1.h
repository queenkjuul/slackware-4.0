/*
  a view for a pathMapperList.
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __PATHMAPPERLISTVIEW1_H
#define __PATHMAPPERLISTVIEW1_H

#include <qlistbox.h>
#include <pathMapperList.h>
#include <pathMapperView1.h>


class PathMapperListView1 :  public QListBox {
  Q_OBJECT
    PathMapperList* pathMapperList;

 public:
  PathMapperListView1( PathMapperList* pathMapperList,
		       QWidget * parent=0, const char * name=0);

  ~PathMapperListView1();

  
 public slots:
   void addPathMapperEvent(PathMapper* pathMapper);
   void removePathMapperEvent(int index);
   void selected(int index);
   void highlighted(int index);
   void setCurrentPosEvent(int index);
};

#endif
