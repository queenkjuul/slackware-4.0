/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#ifndef SONGTREE_H
#define SONGTREE_H

#include <kapp.h>
#include <ktreelist.h> 
#include <kiconloader.h>
#include <qpixmap.h>
#include <qlistbox.h>
#include "kjukebox.h"
#include <qgroupbox.h>

class SongTree : public QWidget{
  Q_OBJECT
 private:
  int          titleWidth;
  int          timeWidth;
  KTreeList    *songTree;

  Songs        songs;
  SongIterator iterator;
  StringListe  artists;
  int          selectedIndex;
  Songs        selectedSongs;
  Song        *selectedSongReference;
  KIconLoader *icon_loader;
  QPixmap      artist_pix;
  QPixmap      song_pix;
  QGroupBox   *box;

  void refreshSongList();
  void refreshArtistList();
  void refreshAll();
  void setupSurface(QString);
  
 public:
  SongTree(QString, QWidget *parent=0, const char *name=0);
  SongTree(QWidget *parent=0, const char *name=0);
  Songs getSongs();
  Songs getAllSongs();
  Song* getSelectedSongReference();
  void clear();
  
 protected:
  void resizeEvent(QResizeEvent *);
  
 signals:
  void selectionChanged();
  void doubleClick();

  private slots:
    void selectionChanged(int);
  void doubleClick(int);

  public slots:
    void clearSelection();
  void addSong(Song);
  void addSongs(Songs);
  void removeSong();
  void removeAllSongs();

};
  
#endif
