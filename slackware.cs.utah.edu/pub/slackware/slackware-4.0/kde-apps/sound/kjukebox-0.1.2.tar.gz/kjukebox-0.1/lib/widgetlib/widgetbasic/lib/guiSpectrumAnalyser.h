/*
  a GUI for a spectrum analyser
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef _GUISPECTRUMANALYSER_H
#define _GUISPECTRUMANALYSER_H

#include <iostream.h>
#include <qapp.h>
#include <qpainter.h>
#include <qtimer.h> 
#include <qpixmap.h> 



#include <devices/spectrumAnalyserDevice.h>
#include <spectrumImage.h>
#include <guiDevice.h>
#include <math.h>


class GuiSpectrumAnalyser : public GuiDevice {
  Q_OBJECT

 public:
  GuiSpectrumAnalyser( QWidget *parent=0, const char *name=0);
  ~GuiSpectrumAnalyser();

  OutputDevice* getDevice();
  
  QSize sizeHint();
  void mousePressEvent ( QMouseEvent* mouseEvent);
  void paintEvent ( QPaintEvent * paintEvent );
  void timeEvent();

 public slots:
   void stopAnalyse();
   void startAnalyse();

 protected:
  void processEvent(char eventId);


 private:
  SpectrumImage* spectrumImage;
  SpectrumAnalyserDevice* device;
  QPixmap* pixMap;
  int* currentPeaks;
  int width;
  int height;
  int bands;
  int spaHeight;
  int updateFreq;
  int counter;
};
#endif

