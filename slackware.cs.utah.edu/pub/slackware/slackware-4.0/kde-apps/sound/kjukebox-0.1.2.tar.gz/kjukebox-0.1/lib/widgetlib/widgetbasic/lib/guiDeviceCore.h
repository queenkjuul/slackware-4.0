/*
  start of a generic gui Device
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __GUIDEVICECORE_H
#define __GUIDEVICECORE_H

#include <qpainter.h>
#include <qtimer.h> 
#include <qwidget.h>

#include <devices/outputDevice.h>



/**
  This example shows how to build a GUI interface for
  a low level device.
  I decided _not_ to derive from the Devices base class
  but instead encapsulate it. Why?
  I think that this leads to cleaner code, because
  the programmer of a GUI must decide which
  methods the GUI should offer. Because programmers
  are lazy they will keep the interface between
  the gui/device as small as possible. This is
  good. <p>
  If the GUI would derive from the device you
  have automatically much more methods and you
  have always the danger that a programm
  which uses your Gui devices "tunnels" through
  your class into the superclass and makes something
  nasty.
  <p>
  This is _impossible_ with this approach.
  Another point is that a device
  is entered by a seperate thread.
  A programmer who does not _exactly_ know
  what he does will produce race condition.
  With this approach it is as well impossible
  by a user of the gui device to do this.
  (As long as your GuiDevice is correct)
  <p>
  Thus : never implement a GuiDevice by deriving
  from the Device base class!
  <p>

  This is the start of a generic gui Device. This should be
  the base class of all higer gui interface for all low Level
  devices.
  <p>
  Currently implemented:
  <p>
  -update frequency
  -deliver mode
  -shared Devices.

  

*/



class GuiDeviceCore : public QWidget  {
  Q_OBJECT


 public:
  GuiDeviceCore( QWidget *parent=0, const char *name=0 );
  virtual ~GuiDeviceCore();

  int startTimer ( int msec, bool sshot = false ); 
  void stopTimer();

  // this method should _only_ be used to build/destroy a device-tree
  // _not to modify the device directly_
  // (believe me: you dont know what you do)
  virtual OutputDevice* getDevice();
  virtual void setDevice(OutputDevice* device);

 public slots:
  void setNotifyMode(int id);
  void clearNotifyBit();
  int getNotifyBit();

 protected slots:
  virtual void processEvent(char eventId);
  virtual void timeEvent();

 protected:
    void paintEvent ( QPaintEvent * paintEvent );
 

 private:
    int mode;

    OutputDevice* device;
    QTimer* timer;
};


#endif



    
