/*
  info about mp3 stream/file
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#ifndef __MP3INFO_H
#define __MP3INFO_H

#include <deviceConfig/info.h>
#include <iostream.h>

class MP3Info : public Info {

  int bps;

 public:
  MP3Info();
  ~MP3Info();

  int getBPS();
  void setBPS(int bps);

  void copyTo(MP3Info* dest);
  void print();

};
#endif
