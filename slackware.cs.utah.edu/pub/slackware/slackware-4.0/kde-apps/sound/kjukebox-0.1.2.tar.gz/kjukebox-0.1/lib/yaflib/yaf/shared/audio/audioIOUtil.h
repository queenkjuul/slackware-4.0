
#ifndef __AUDIOIOUTIL_H
#define __AUDIOIOUTIL_H

#include <stdio.h>
#include <stdarg.h>
#include <string.h>



void die(char *fmt, ...);
void warn(char *fmt, ...);

#endif

