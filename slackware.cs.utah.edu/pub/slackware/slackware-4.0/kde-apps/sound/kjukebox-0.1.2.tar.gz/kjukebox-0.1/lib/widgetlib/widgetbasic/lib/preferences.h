/*
  generic preferences dialog
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __PREFERENCES_H
#define __PREFERENCES_H

#include <qtabdlg.h>
#include <prefConfig.h>

class Preferences :  public QTabDialog {

 public:
  Preferences(QWidget * parent=0,const char * name=0 );
  ~Preferences();

  void addTab ( PrefConfig *, const char * );
  


};
#endif

