/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#include <stdio.h>
#include <qstring.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include "kjukebox.h"
#include "mp3.h"

MP3::MP3(){
  tag = new Tag;
  layer = new Layer;
  format = "%t|%a|%l|%y|%c|%g|%#|%v|%L|%C|%b|%F|%M|%O|%o|%m|%s|%S|%f|%i";
  hastag = true;
  haslayer = true;
  filelength = 0;
  filename[0] = 0;
  hastag = false;
  haslayer = false;
}

MP3::~MP3(){
  if (filename[0] && file) fclose(file);
}

bool MP3::initfile(bool gettag){
  if (!(layer->scan(file))) {
    haslayer = false;
    return (false);
  }
  haslayer = true;
  if (gettag)  hastag = tag->scan(file);
  return (true);
}

bool MP3::openForSave(const char *fname){
  return open(fname, true);
}

bool MP3::open(const char *fname){
  return open(fname,false);
}

bool MP3::open(const char *fname, bool forSave){
  struct stat fi;

  if (fname == NULL) fname = filename;
  if (forSave)
    file = fopen(fname, "r+");
  else 
    file = fopen(fname, "r");
  if (file == NULL) {
    perror("OPEN:");
    return (false);
  }

  tag->clear();
  fstat(fileno(file), &fi);
  filelength = fi.st_size;
  strncpy(filename, fname, FILENAME_LEN);
  return (true);
}

bool MP3::saveTags(){
  return tag->saveTags(file);
}

void MP3::close(){
  if (file) fclose(file);
  file = NULL;
}


Song MP3::getSong(){
  Song tmp;
  tmp.setTitle((QString)tag->title);
  tmp.setArtist((QString)tag->artist);
  tmp.setAlbum((QString)tag->album);;
  tmp.setComment((QString)tag->comment);
  tmp.setGenre((QString)tag->genre);
  tmp.setFilename((QString)filename);
  tmp.setStereomode((QString)layer->mode_name());
  tmp.setPlayed(0);
  tmp.setSamplerate(layer->sfreq());
  tmp.setBitrate(layer->bitrate());
  tmp.setYear(atoi(tag->year));
  tmp.setSize(filelength);
  tmp.setSeconds(filelength / (layer->bitrate() * 125) );
  tmp.setLayer((QString)layer->layer_name());
  tmp.checkForPlausibility((QString)filename);
  return tmp;
}


bool MP3::saveCommentTag(const char* fname, const char *comm){
  bool erg;
  if( openForSave(fname) ) {
    initfile();
    strncpy(tag->comment,comm,30);
    erg = saveTags();
    close();
    return erg;
  }
  return false;
}
