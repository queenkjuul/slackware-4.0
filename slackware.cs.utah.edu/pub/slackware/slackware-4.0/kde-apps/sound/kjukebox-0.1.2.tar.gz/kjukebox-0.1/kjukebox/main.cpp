/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/


#include <kapp.h>
#include "appwindow.h"


int main( int argc, char ** argv ) {
  KConfig *config;
  KApplication app( argc, argv , "kjukebox");
  ApplicationWindow * mw = new ApplicationWindow();
  app.setMainWidget(mw);
  config = app.getConfig();
  config->setGroup(KCONFIG_GENERAL);
  int w = config->readNumEntry(KCONFIG_GENERAL_WIDTH,800);
  int h = config->readNumEntry(KCONFIG_GENERAL_HEIGHT,500);          
  mw->setCaption( "KJukeBox " );
  mw->show();
  mw->resize(w,h);                           
  app.connect( &app, SIGNAL(lastWindowClosed()), &app, SLOT(quit()) );
  return app.exec();
}

