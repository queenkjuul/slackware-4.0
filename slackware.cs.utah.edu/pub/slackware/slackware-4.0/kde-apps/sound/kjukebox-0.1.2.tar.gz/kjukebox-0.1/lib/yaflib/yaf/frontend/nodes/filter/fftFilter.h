/*
  a FFT filter with real/imagery part (can calculate inverse fft!)
  Copyright (C) 1998  Martin Vogt;Philip VanBaren, 2 September 1993

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __FFTFILTER_H
#define __FFTFILTER_H



#include <filter/filter.h>
#include <util/fft.h>



  

class FFTFilter : public Filter {

  FFT* fft;
  int points;
  float* data;
  float* window;
  
 public:
  FFTFilter();
  ~FFTFilter();
  void fft16(DeviceConfig* input,short* points);
  void inverseFFT16(float* data);
  int getPoints();
  float* getPointPtr();
};


#endif
