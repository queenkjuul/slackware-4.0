/*
  generic audiodevice
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <devices/audioDevice.h>



AudioDevice::AudioDevice(char* device) {
  volumeInfo=new VolumeInfo();
  audioInfo=new AudioInfo();
  audioWrapper=new AudioWrapper();
  lneedInit=true;
}


AudioDevice::~AudioDevice() {
  delete audioWrapper;
}


char* AudioDevice::getNodeName() {
  return "AudioDevice";
}

int AudioDevice::open() {
  return audioWrapper->open();
}


int AudioDevice::isOpen() {
  return audioWrapper->isOpen();
}


int AudioDevice::close() {
  audioWrapper->close();
  return true;
}


void AudioDevice::writeIn(NodeDevice* source,DeviceConfig* buf) {
  AudioBuffer* buffer=buf->getAudioBuffer();
  MemChunk* memChunk=buffer->getMemChunk();
  StatusInfo* statusInfo=buf->getStatusInfo();
  AudioInfo* audioInfoStream=buf->getAudioInfo();
  VolumeInfo* volumeInfoStream=buf->getVolumeInfo();

  // We ignore statusChange messages, because otherwise
  // it is possible that we initialize /dev/dsp with "strange"
  // values. (Linux ignores this FreeBSD hangs)
  if (statusInfo->getChange()) {
    return;
  }

  if (!(audioInfoStream->equals(audioInfo)) || lneedInit) {
    int stereo=audioInfoStream->getStereo();
    int sampleSize=audioInfoStream->getSampleSize();
    int speed=audioInfoStream->getSpeed();
    cout << "initDSP-> stereo:" << stereo
	 << "sample:"<< sampleSize 
	 << "speed: "<< speed 
	 <<endl;
    audioWrapper->init(sampleSize,speed,stereo);
    audioInfoStream->copyTo(audioInfo);
  }
  if (volumeInfoStream->getChange() || lneedInit) {
    float leftVolume=volumeInfoStream->getLeftVolume();
    float rightVolume=volumeInfoStream->getRightVolume();
    audioWrapper->setVolume(leftVolume,rightVolume);
    volumeInfoStream->copyTo(volumeInfo);
  }
  lneedInit=false;

  if (rawWrite(memChunk->getPtr(),memChunk->getLen()) != memChunk->getLen()) {
    lneedInit=true;
  }
}
  



int AudioDevice::rawWrite(char* buf,int len) {
  return audioWrapper->write(buf,len);
}






