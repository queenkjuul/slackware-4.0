#include <kslider.h>
#include <stdlib.h>
#include "configPlayer.h"


ConfigPlayer::ConfigPlayer( QWidget *parent, const char *name )
  : QWidget( parent, name ){

  QString pp;
  
  config = (KApplication::getKApplication())->getConfig();  
  config->setGroup(KCONFIG_PLAYER);
  defaultTime    = config->readBoolEntry(KCONFIG_PLAYER_DEFAULTTIME,true);
  fadeOut        = config->readBoolEntry(KCONFIG_PLAYER_FADEOUT,true);
  mixing         = config->readBoolEntry(KCONFIG_PLAYER_MIXING,true);
  audioDevice    = config->readEntry(KCONFIG_PLAYER_DEVICE,"/dev/dsp");
  lastSeconds    = config->readNumEntry(KCONFIG_PLAYER_LASTSECONDS,7);
  firstSeconds   = config->readNumEntry(KCONFIG_PLAYER_FIRSTSECONDS,0);
  priorityPlayer = config->readNumEntry(KCONFIG_PLAYER_PRIORITY,0);

  boxTime = new QGroupBox(i18n("Skip Time"), this, "boxtime" );  

  enableMixing = new QCheckBox(i18n("enable mixing"), boxTime, "mixing");
  enableMixing->setChecked(mixing);

  enableFadeOut = new QCheckBox(i18n("enable fade out"), boxTime, "fadeOut");
  enableFadeOut->setChecked(fadeOut);

  enableDefaultTime = new QCheckBox(i18n("alway use default settings"), boxTime, "defaultTime");
  enableDefaultTime->setChecked(defaultTime);
  //  connect(enableDefaultTime,SIGNAL(clicked()),SLOT(setDefaultTime()));

  firstSecBox = new KLined( boxTime, "first");
  firstSecBoxLabel = new QLabel(firstSecBox, i18n("first seconds to skip"), boxTime);
  pp.sprintf("%d",firstSeconds);
  firstSecBox->setText(pp);

  lastSecBox = new KLined( boxTime, "last");
  lastSecBoxLabel = new QLabel(lastSecBox, i18n("last seconds to skip"), boxTime);
  pp.sprintf("%d",lastSeconds);
  lastSecBox->setText(pp);

  boxDevice = new QGroupBox(i18n("Device"), this, "boxdevice" );  
  audioDevBox = new KLined( boxDevice, "audio");
  audioDevBoxLabel = new QLabel(audioDevBox, i18n("Audio"), boxDevice);
  audioDevBox->setText(audioDevice);


  boxPriority = new QGroupBox(i18n("Process Priority"), this, "boxtime" );  
  priorityPlayerBox = new QComboBox(FALSE, boxPriority, "priority");
  for(int i=0; i<=40; i++){
    pp.sprintf("%2d",i-20);
    priorityPlayerBox->insertItem(pp,i);
  }
  priorityPlayerBox->setCurrentItem(priorityPlayer+20);
  priorityPlayerLabel = new QLabel(i18n("Set the Process Priority for the\nPlayer. (HIGH=-20,LOW=20)"),boxPriority, "bla");

}


void ConfigPlayer::setDefaultTime(){
//   defaultTime = enableDefaultTime->isChecked();
//   lastSecBox->setEnabled(defaultTime);
//   firstSecBox->setEnabled(defaultTime);
}   


void ConfigPlayer::cancel(){
  config->setGroup(KCONFIG_PLAYER);

  mixing         = config->readBoolEntry(KCONFIG_PLAYER_MIXING,true);
  fadeOut        = config->readBoolEntry(KCONFIG_PLAYER_FADEOUT,true);
  defaultTime    = config->readBoolEntry(KCONFIG_PLAYER_DEFAULTTIME,true);
  audioDevice    = config->readEntry(KCONFIG_PLAYER_DEVICE,"/dev/dsp");
  lastSeconds    = config->readNumEntry(KCONFIG_PLAYER_LASTSECONDS,3);
  firstSeconds   = config->readNumEntry(KCONFIG_PLAYER_FIRSTSECONDS,0);
  priorityPlayer = config->readNumEntry(KCONFIG_PLAYER_PRIORITY,0);

  enableMixing      ->setChecked(mixing);
  enableFadeOut->setChecked(fadeOut);
  enableDefaultTime ->setChecked(defaultTime);
  firstSecBox       ->setText((QString)firstSeconds);
  lastSecBox        ->setText((QString)lastSeconds);
  audioDevBox       ->setText(audioDevice);
  priorityPlayerBox ->setCurrentItem(priorityPlayer+20);
}

void ConfigPlayer::accept(){
  config->setGroup(KCONFIG_PLAYER);
  
  mixing         = enableMixing ->isChecked();
  fadeOut        = enableFadeOut->isChecked();
  defaultTime    = enableDefaultTime->isChecked();
  firstSeconds   = atoi(firstSecBox->text());
  if (firstSeconds < 0) firstSeconds = 0;
  lastSeconds    = atoi(lastSecBox->text());
  if (lastSeconds  < 0) lastSeconds  = 0;
  audioDevice    = audioDevBox->text();
  priorityPlayer = atoi(priorityPlayerBox->currentText());

  config->writeEntry(KCONFIG_PLAYER_MIXING,mixing);
  config->writeEntry(KCONFIG_PLAYER_FADEOUT,fadeOut);
  config->writeEntry(KCONFIG_PLAYER_DEFAULTTIME,defaultTime);
  config->writeEntry(KCONFIG_PLAYER_FIRSTSECONDS,firstSeconds);
  config->writeEntry(KCONFIG_PLAYER_LASTSECONDS,lastSeconds);
  config->writeEntry(KCONFIG_PLAYER_DEVICE,audioDevice);
  config->writeEntry(KCONFIG_PLAYER_PRIORITY,priorityPlayer);
  config->sync();
}

void ConfigPlayer::resizeEvent( QResizeEvent * ){
  boxTime  ->setGeometry(10,10,width()-20,195);
  enableMixing     ->setGeometry( 10, 20, boxTime->width()-20, 25);
  enableFadeOut    ->setGeometry( 10, 55, boxTime->width()-20, 25);
  enableDefaultTime->setGeometry( 10, 90, boxTime->width()-20, 25);
  firstSecBox      ->setGeometry( 10,125, 40, 25);
  firstSecBoxLabel ->setGeometry( 60,125,boxTime->width()-70, 25);
  lastSecBox       ->setGeometry( 10,160, 40, 25);
  lastSecBoxLabel  ->setGeometry( 60,160,boxTime->width()-70, 25);

  boxDevice        ->setGeometry( 10,215,width()-20, 55);
  audioDevBoxLabel ->setGeometry( 10, 20, 50, 25);
  audioDevBox      ->setGeometry( 70, 20,boxDevice->width()-80, 25);

  boxPriority        ->setGeometry( 10,280,width()-20,60);
  priorityPlayerLabel->setGeometry( 10, 20,200,30);
  priorityPlayerBox  ->setGeometry(210, 20,boxPriority->width()-220,25);
}





