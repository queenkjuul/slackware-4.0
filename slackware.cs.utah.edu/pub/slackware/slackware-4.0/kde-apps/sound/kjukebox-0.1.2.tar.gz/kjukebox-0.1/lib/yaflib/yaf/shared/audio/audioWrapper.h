/*
  a wrapper for the audioDevice.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef _AUDIOWRAPPER_H
#define _AUDIOWRAPPER_H

#include <audio/audioIO.h>
#include <iostream.h>


class AudioWrapper {

  int lopen;

 public:
  AudioWrapper();
  ~AudioWrapper();
  
  int open();
  int close();
  int isOpen();
  void setVolume(float leftPercent,float rightPercent);

  void init(int channel,int bits, int freq);
  int write(char* buf,int len);
};

#endif




