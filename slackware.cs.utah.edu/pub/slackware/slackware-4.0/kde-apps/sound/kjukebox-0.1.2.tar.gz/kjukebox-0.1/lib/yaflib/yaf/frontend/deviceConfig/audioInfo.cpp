/*
  defines the format of an audio stream
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <deviceConfig/audioInfo.h>



AudioInfo::AudioInfo(){
  setValid(false);
}


AudioInfo::~AudioInfo() {
}


void AudioInfo::setFormat(int stereo,int samplesize,int speed) {
  setStereo(stereo);
  setSampleSize(samplesize);
  setSpeed(speed);
}


int AudioInfo::getStereo() {
  return stereo;
}


int AudioInfo::getSampleSize() {
  return samplesize;
}


int AudioInfo::getSpeed() {
  return speed;
}

void AudioInfo::setStereo(int stereo) {
  if (this->stereo != stereo) {
    setChange(true);
  }
  this->stereo=stereo;
}


void AudioInfo::setSampleSize(int samplesize) {
  if (this->samplesize != samplesize) {
    setChange(true);
  }
  this->samplesize=samplesize;
}


void AudioInfo::setSpeed(int speed) {
  if (this->speed != speed) {
    setChange(true);
  }
  this->speed=speed;
}


float AudioInfo::getTime() {
  float time;

  time=8.0*(float)bytes/(float)(samplesize*(stereo+1));
  time=time/(float)(speed);

  return time;
}

void AudioInfo::setPlayedBytes(int bytes) {
  this->bytes=bytes;
}

int AudioInfo::getPlayedBytes() {
  return bytes;
}


int AudioInfo::equals(AudioInfo* aInfo) {
  if (aInfo == NULL) return false;

  if (aInfo->getSpeed() != speed) {
    return false;
  }
  if (aInfo->getStereo() != stereo) {
    return false;
  }
  if (aInfo->getSampleSize() != samplesize) {
    return false;
  }
  return true;
} 


void AudioInfo::copyTo(AudioInfo* aInfo) {
  if (aInfo == NULL) return;

  aInfo->setSpeed(getSpeed());
  aInfo->setStereo(getStereo());
  aInfo->setSampleSize(getSampleSize());
  aInfo->setPlayedBytes(getPlayedBytes());
} 
 


void AudioInfo::print() {
  cout << "AudioInfo-begin-"<<endl;
  cout << "stereo:"<<getStereo()<<" sampleSize:"<<getSampleSize()
       << " speed: "<<getSpeed()<<" time:"<<getTime() <<endl;

  cout << "AudioInfo-end-"<<endl;
 
}
