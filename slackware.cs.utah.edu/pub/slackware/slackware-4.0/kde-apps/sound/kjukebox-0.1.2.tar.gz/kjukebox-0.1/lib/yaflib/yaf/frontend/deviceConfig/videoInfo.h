/*
  Video data for yaf. Still experimental!
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#ifndef __VIDEOINFO_H
#define __VIDEOINFO_H


#include <deviceConfig/memChunk.h>
#include <deviceConfig/info.h>
#include <qpixmap.h> 

/**
   This is a "case study" for video integration (Experimental).
   <p>
   This is a video information. For now we use a single QImage
   for the video data. But this changes in future enhancements,
   because yaf should not depend on qt!
   <p>
   The videoInfo should use a good image toolkit? (imlib?)
*/

class VideoInfo : public Info {
  
  QPixmap* pixmap;
  MemChunk* memChunk;

 public:
  VideoInfo();  // if size == 0 then it is shared!
  ~VideoInfo();
  

  QPixmap* getPixmap();
  void setPixmap(QPixmap* image);
  void copyTo(VideoInfo* videoInfo);

  // use this to lock/unlock the current video stream
  MemChunk* getMemChunk();


};

#endif
