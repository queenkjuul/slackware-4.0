/*
  root window for kmpg (menu and all this stuff)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include "kmpgRootWindow.h"



KmpgRootWindow::KmpgRootWindow(QWidget *parent = 0, const char *name = 0 ):
  KTMainWindow( name ) {
  playlist=new Playlist();

  dropZone = new KDNDDropZone(this , DndURL );
  connect(dropZone,SIGNAL(dropAction(KDNDDropZone*)), 
	  SLOT( onDrop( KDNDDropZone*)));

  playlistView2=new PlaylistView2(playlist);
  preferences=new Preferences();

  mixerConfig=new MixerConfig(preferences);
  preferences->addTab(mixerConfig,mixerConfig->getGroupName());

  /*
    This release has not pathMapper functions.
  */
  /*
  pathMapperConfig=new PathMapperConfig(preferences);
  preferences->addTab(pathMapperConfig,pathMapperConfig->getGroupName());
  PlaylistOperation::setPathMapperConfig(pathMapperConfig);
  */

  playlistView3=new PlaylistView3(playlist);

  buildMenuBar();
}

KmpgRootWindow::~KmpgRootWindow() {
  delete playlist;
}


Preferences* KmpgRootWindow::getPreferences() {
  return preferences;
}


void KmpgRootWindow::buildMenuBar() {
  KMenuBar *mBar;
  QPopupMenu* file;
  QPopupMenu* option;
  QString aboutStr = "kmpg-" VERSION "\n\n";
  
  aboutStr +="(c) 1998 Martin Vogt (mvogt@rhrk.uni-kl.de)\n\n";
  aboutStr += klocale->translate("An MPEG audio player for the KDE " \
                                  "Desktop Environment\n" \
                                  "See Help for more information");

  mBar = menuBar();

  file = new QPopupMenu(this);
  file->insertItem( klocale->translate("Open..."), this, 
		    SLOT(openFileSelector()), CTRL+Key_O );
  file->insertSeparator();
  file->insertItem( klocale->translate("Quit"), kapp,
		    SLOT(quit()), ALT+Key_Q );

  mBar->insertItem( klocale->translate("&File"), file );


  option = new QPopupMenu(this);
  option->insertItem( klocale->translate("Playlist"), playlistView2, 
		    SLOT(show()), CTRL+Key_P );
  option->insertItem( klocale->translate("Mixer"), mixerConfig, 
		    SLOT(startExternalMixer()));
  option->insertItem( klocale->translate("Tag Editor"),playlistView3 , 
		    SLOT(show()));
  option->insertItem( klocale->translate("Preferences"), preferences, 
		    SLOT(show()));

  mBar->insertItem( klocale->translate("&Option"), option );
  mBar->insertSeparator();
  mBar->insertItem( klocale->translate("&Help"),
		    kapp->getHelpMenu(false, aboutStr) );


  
}
  



void KmpgRootWindow::setPlayer(KmpgPlayer* player) {
  this->player=player;
  setView(player);
}


KmpgPlayer* KmpgRootWindow::getPlayer() {
 return player;
}


Playlist* KmpgRootWindow::getPlaylist() {
  return playlist;
}


void KmpgRootWindow::openFileSelector() {
  // did we insert a song or has the user canceld ?
  if (PlaylistOperation::loadSong(playlist)) {
    int count=playlist->count();
    playlist->setCurrentPos(count-1);
    PlaylistOperation::playCurrent(playlist);
  }

}


void KmpgRootWindow::onDrop( KDNDDropZone* zone) {
  int count=playlist->count();

  PlaylistOperation::insert(zone,playlist);

  playlist->setCurrentPos(count);
  PlaylistOperation::playCurrent(playlist);
  
}


