/*
  generic outputdevice for yaf
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */





#include <devices/outputDevice.h>

// dynamic setting of acc-functions? would be nice
// (nice "use MMX" button in gui?)
static Filter* filter=new Filter();


OutputDevice::OutputDevice(){
  eventQueue=new EventQueue(getNodeName());
}


OutputDevice::~OutputDevice() {
  delete eventQueue;
}


char* OutputDevice::getNodeName() {
  return "OutputDevice";
}


Accelerator* OutputDevice::getAccelerator() {
  return filter->getAccelerator();
}


EventQueue* OutputDevice::getEventQueue() {
  return eventQueue;
}

