/*
  generic for open/close/jump methods
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <producer/core/deviceConfigController.h>



DeviceConfigController::DeviceConfigController() {
}


DeviceConfigController::~DeviceConfigController() {
}


int DeviceConfigController::open(char* filename ) {
  return true;
}


int DeviceConfigController::close() {
  return true;
}


int DeviceConfigController::play() {
  return true;
}


int DeviceConfigController::pause() {
  return true;
}


int DeviceConfigController::jump(int) {
  return true;
}


