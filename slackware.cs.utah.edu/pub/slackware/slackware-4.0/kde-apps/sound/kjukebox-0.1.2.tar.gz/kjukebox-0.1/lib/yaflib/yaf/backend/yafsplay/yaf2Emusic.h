/*
  functions for an interface between a yafDecoder and the GNOME-emusic Interf.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */





#ifndef __YAF2EMUSIC_H
#define __YAF2EMUSIC_H




#include <yafxplayer/xplayerCommand.defs>

extern "C" {
#include <yafcore/streamWriter.h>
#include <unistd.h>
#include <pthread.h>
	   }


#include <yafcore/inputInterface.h>

#include <players/common.h>


// These functions are called during the creation
// of the plugin
// The are the callbacks it the thread enters one of the 
// funtions above.

extern void setInputInterface(InputInterface* in);
extern void setPlugin(player_plugin* plugin);

                                                       

#endif
