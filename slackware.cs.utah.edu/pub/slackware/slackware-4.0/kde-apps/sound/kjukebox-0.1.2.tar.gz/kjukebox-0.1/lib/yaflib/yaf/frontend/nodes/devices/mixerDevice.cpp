/*
  mixes a DeviceConfigArray and delivers the result to the listeners
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <devices/mixerDevice.h>



MixerDevice::MixerDevice() {
  AudioBuffer* audioBuffer;

  pcmChunk=new MemChunk(_MAX_PCM_BUFFER);
  config=new DeviceConfig();

  audioBuffer=config->getAudioBuffer();
  audioBuffer->setMemChunk(pcmChunk);
  mixerFilter=new MixerFilter();
  volumeFilter=new VolumeFilter();
}


MixerDevice::~MixerDevice() {
  delete pcmChunk;
  delete mixerFilter;
  delete volumeFilter;
}


void MixerDevice::writeOut(DeviceConfigArray* buf) {
  NodeDevice* nodeDevice;
  Edges* edges=getListeners();
  int n=edges->getElements();
  int i;
  int elements=buf->getEntries();

  StatusInfo* statusInfo=config->getStatusInfo();

  // First we mix the volume for all inputs:
  for(i=0;i<elements;i++) {
    volumeFilter->transform(buf->getDeviceConfigAt(i));
  }


 
  mixerFilter->transform(buf,config);



  /**

     Hack START

     It is not clear how to mix "statusMessages".
     This hack sets the statusMessages to false.
  */
  statusInfo->setChange(false);
  
  //
  // Hack end
  //

  //statusInfo=buf->getDeviceConfigAt(0)->getStatusInfo();
  //statusInfo->setChange(false);
  

  for(i=0;i<n;i++) {
    nodeDevice=edges->getNodeDevice(i);
    nodeDevice->writeInLock();
    nodeDevice->writeIn(this,config);
    //nodeDevice->writeIn(this,buf->getDeviceConfigAt(0));
    nodeDevice->writeInUnlock();
  }

}


  
