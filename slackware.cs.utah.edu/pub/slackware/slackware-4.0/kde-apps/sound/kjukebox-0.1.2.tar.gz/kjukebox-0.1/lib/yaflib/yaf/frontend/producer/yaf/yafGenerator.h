/*
  the yaf generator interface works together with yaf backend players
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __YAFGENERATOR_H
#define __YAFGENERATOR_H

#include <producer/core/dataGenerator.h>
#include <deviceConfig/deviceConfig.h>
#include <util/controlChannel.h>
#include <yafxplayer/xplayerRuntime.defs>
#include <producer/yaf/yafXPlayerControl.h>
#include <producer/yaf/yafStream.h>

#include <signal/toolkit/eventQueue.h>
#include <pthread.h>



/**
  
  Note:<p>
  This generator produces data which are delivered by a yaf-protocol
  compliant <xyz>-player.
  The StreamProducer enter this class as a sperate thread and this
  yafGenerator make sure that the thread gets valid deviceConfig
  entries.
  <p>


  The yaf interface is a bit complex because it must handle
  a command line yaf-player.For simplier examples look in the
  imageGenerator.
  <p>
*/


class YafGenerator :  public DataGenerator,
		             ControlChannel,
                             NotifyClient   {
  DeviceConfig* config;
  MusicInfo* musicInfo;
  AudioInfo* audioInfo;
  StatusInfo* statusInfo;
  AudioBuffer* audioBuffer;
  TimeInfo* timeInfo;
  MP3Info* mp3Info;
  ID3Info* id3Info;
  Buffer* tmp;

  YafXPlayerControl* control;
  struct YafStream* stream;
  int instanceCnt;

 public:
  YafGenerator();
  ~YafGenerator();

  int updateDeviceConfig(DeviceConfig* newConfig);

  int open(char* filename );
  int close();
  int play();
  int pause();
  int jump(int);


  // Not a part of the Producer interface.
  // These things are special for the yafInterface:

  void processRuntimeCommand(int command,char* args);
  void processReturnCommand(int cmdNr,int cmdId,char* ret,char* args);

  void addArgument(char* arg);
  void startDecoder();

  void bufferFilledNotify(int filled);  // called by yafStream after underrun
  void setThreadState(int msg);

 private:
  void clearStream();
  void dataUpdate();

  int lClearRequest;
  int pauseCmdNr;
  int fullUpdate;


  long eofBytes;
};

#endif
