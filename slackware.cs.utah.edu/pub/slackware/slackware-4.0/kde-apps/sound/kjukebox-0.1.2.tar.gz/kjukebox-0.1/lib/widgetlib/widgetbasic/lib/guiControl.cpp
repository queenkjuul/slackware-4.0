/*
  a basic control widget
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <guiControl.h>





GuiControl::GuiControl( QWidget *parent=0, 
			      const char *name=0 ): QWidget (parent,name) {
  
  setMinimumSize( sizeHint() );
  setMaximumSize( sizeHint() );

}


GuiControl::~GuiControl() {
}



QSize GuiControl::sizeHint () {
  QSize size(100,20);
  return size;
}


void GuiControl::buildGui() {
  layout = new QBoxLayout( this, QBoxLayout::LeftToRight, 1 );

  pauseButton = new QPushButton("Pause", this ); 
  pauseButton->setMinimumSize( pauseButton->sizeHint() ); 
  connect(pauseButton , SIGNAL(clicked()), this, SIGNAL(playPauseEvent()));
  layout->addWidget(pauseButton);

  playButton = new QPushButton("Play", this ); 
  playButton->setMinimumSize( playButton->sizeHint() ); 
  connect(playButton , SIGNAL(clicked()), this, SIGNAL(playCurrentEvent()));
  layout->addWidget(playButton);

  stopButton = new QPushButton("Stop", this ); 
  stopButton->setMinimumSize( stopButton->sizeHint() ); 
  connect(stopButton , SIGNAL(clicked()), this, SIGNAL(playStopEvent()));
  layout->addWidget(stopButton);

}


