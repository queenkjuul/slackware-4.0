/*
  gui part for the balance device (very simple)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <guiBalanceDevice.h>




GuiBalanceDevice:: GuiBalanceDevice(int minValue, int maxValue, int step, 
				    int value, Orientation orient, 
				    QWidget *parent=0, const char *name=0 ) :
  KSlider(minValue,maxValue,step,value,orient,parent,name) {
 balance=0;
 setOrientation(QSlider::Horizontal);
 setTickmarks( QSlider::NoMarks );
 setValue(getBalance());
 setGeometry(0,0,140,50);
 setBackgroundColor(black);
 menuDescription=new MenuDescription("BalanceDevice");
 menuDescription->insertMenu("Center",this,SLOT(centerBalance()));

 connect( this, SIGNAL(valueChanged(int)),this,SLOT(setBalance(int)) );
}


GuiBalanceDevice::~GuiBalanceDevice() {

}


int GuiBalanceDevice::getBalance() {
  return balance;
}


void GuiBalanceDevice::setBalance(int value) {
  cout << "setBalance:"<<value<<endl;
  balance=value;
  emit(balanceChange(balance));
}


void GuiBalanceDevice::centerBalance() {
  setBalance(0);
  setValue(0);
}


void GuiBalanceDevice::mousePressEvent ( QMouseEvent* mouseEvent) {
  if (mouseEvent->button() ==  RightButton) {
    cout << "RightButton"<<endl;
    KPopupMenu* popupMenu=menuDescription->createPopupMenu();
    popupMenu->move(mapToGlobal(QPoint(mouseEvent->x(),mouseEvent->y())));
    popupMenu->exec();
    delete popupMenu;
    return;
  }
  KSlider::mousePressEvent(mouseEvent);
}




QSize GuiBalanceDevice::sizeHint () {
  return QSize(180,28);
}






/* 
void GuiBalanceDevice::paintEvent ( QPaintEvent * paintEvent ) {
  QPainter paint;


  paint.begin( this );
  paint.drawText(0,10,"Martin");
  paint.end();  

}
*/

