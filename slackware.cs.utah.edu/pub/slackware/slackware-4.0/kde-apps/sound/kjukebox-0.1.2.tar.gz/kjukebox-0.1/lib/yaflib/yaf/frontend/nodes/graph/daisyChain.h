/*
  stores StreamProducers and takes care that they work step by step
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __DAISYCHAIN_H
#define __DAISYCHAIN_H

#include <devices/nodeDevice.h>
#include <devices/streamProducer.h>


#include <pthread.h>

typedef struct {
  struct StreamProducer* element;
  int delivered;
  int valid;
} DaisyChainElement;


typedef struct {
  void* from;
  struct StreamProducer* to;
  int valid;
} LockTupel;


#define _MAX_DAISYCHAIN_ELEMENTS  10
#define _MAX_LOCKS                30


/**
  StreamProducers cannot work concurrently. All StreamProducers
  are only allowed to deliver exactly one deviceConfig.
  Then they must wait until all other StreamProducers have delivered
  their data. This is necessary because the devices should
  not be floated by one thread.
  <p>
  <p>
  Example:
  <p>
  If you have a mixer device and thread A delivers 2048 Bytes
  whereas thread B delivers 4096 Bytes would be to complex
  to handle for a device. If every device which may have multiple
  sources must deal with this problem the problem becomes too
  difficult.
  <p>
  Because:
  <p>
  It can easily come to a buffer overflow in a device, because
  Thread B deliver 4096 bytes faster because it has not the
  complex operations like thread A (e.g). Then the mixer device
  may have 1000 deliverys from thread A whereas thread B only
  delivered 1 StreamBuffer.
  Thus the daisychain takes care that every StreamProducers
  sends exactly one StreamBuffer and then waits until the other
  StreamProducers have delivered their data. Then a new deliver
  cycle begins.
  <p>
  Problems:<p>
  This approach leads to the problem that the Stream has "skips"
  on slow machines. 
  <p>
  Solution:<p>
  Ringbuffers may help where the continous delivery is very important.
  (e.g audioDevices)

*/


class DaisyChain {

  DaisyChainElement* daisyChain[_MAX_DAISYCHAIN_ELEMENTS];
  LockTupel* lockTupel[_MAX_LOCKS];

  pthread_mutex_t changeMut;

  pthread_cond_t daisyCond;
  pthread_mutex_t daisyMut;

 public:
  DaisyChain();
  ~DaisyChain();

  void addElement(struct StreamProducer* element);
  void removeElement(struct StreamProducer* element);

  void addLock(void* from,struct StreamProducer* to);
  void removeLock(void* from,struct StreamProducer* to);
  void removeAllLocks(void* from);

  void lockDaisyChain();
  void unlockDaisyChain();

  void lockStreamProducer();
  void unlockStreamProducer();


};


#endif


