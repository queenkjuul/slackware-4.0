
#include "splay.h"


struct player_plugin *splay_plugin(void)
{
   struct player_plugin *temp = malloc(sizeof(struct player_plugin));
   temp->seek = splay_seek;
   temp->open = splay_open;
   temp->close = splay_close;
   temp->pause = splay_pause;
   temp->play  = splay_play;
   temp->getModuleInfo = splay_getModuleInfo;
   temp->getMusicInfo  = splay_getMusicInfo;
   temp->config = splay_config;
   temp->construct     = splay_construct;
   temp->destruct      = splay_destruct;
   temp->getStreamState= splay_getStreamState;

   return temp;
}
