/*
  stores id3 tags
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <deviceConfig/id3Info.h>


ID3Info::ID3Info() {
  name[0]=0;
  artist[0]=0;
  album[0]=0;
  year[0]=0;
  comment[0]=0;
  genre=0;

  name[30]=0;
  artist[30]=0;
  album[30]=0;
  year[4]=0;
  comment[30]=0;
}


ID3Info::~ID3Info() {
}


char* ID3Info::getName() {
  return (char*)&name;
}


char* ID3Info::getArtist() {
  return (char*)&artist;
}


char* ID3Info::getAlbum() {
  return (char*)&album;
}


char* ID3Info::getYear(){
  return (char*)&year;
}


char* ID3Info::getComment() {
  return (char*)&comment;
}


unsigned char ID3Info::getGenre() {
  return genre;
}


void ID3Info::setName(char* name) {
  alltrimcpy(this->name, name, 30);
  setChange(true);
}


void ID3Info::setArtist(char* artist) {
  alltrimcpy(this->artist, artist, 30);
  setChange(true);
}
  

void ID3Info::setAlbum(char* album) {
  alltrimcpy(this->album, album, 30);
  setChange(true);
}


void ID3Info::setYear(char* year) {
  alltrimcpy(this->year, year, 4);
}


void ID3Info::setComment(char* comment) {
  alltrimcpy(this->comment, comment, 30);
  setChange(true);
}


void ID3Info::setGenre(unsigned char genre) {
  this->genre=genre;
  setChange(true);
}



void ID3Info::copyTo(ID3Info* dest) {
  dest->setName(getName());
  dest->setArtist(getArtist());
  dest->setAlbum(getAlbum());
  dest->setYear(getYear());
  dest->setComment(getComment());
  dest->setGenre(getGenre());
}

  
void ID3Info::print() {
  cout << "ID3Info Start"<<endl;
  cout << "Name:"<<getName()<<"**"<<endl;
  cout << "Artist:"<<getArtist()<<"**"<<endl;
  cout << "Album:"<<getAlbum()<<"**"<<endl;
  cout << "Year:"<<getYear()<<"**"<<endl;
  cout << "Comment:"<<getComment()<<"**"<<endl;
  cout << "Genre:"<<getGenre()<<"**"<<endl;
  cout << "ID3Info End"<<endl;
}


void ID3Info::alltrimcpy(char* dest,char* src,int max) {
  int pos;
  int start;
  int end;
  int i;
  int len=strlen(src);
  
  if (max == 0) {
    cout << "strange alltrim call!"<<endl;
    return;
  }

  if (len > max) {
    len=max;
  }
  
  pos=0;
  for(start=0;start<max;start++) {
    if(src[start] == 0) {
      dest[pos]=0;
      return;
    }
    if(src[start] != ' ') {
      break;
    }
  }
  // ok start is the first char != space
  
  for(end=len-1;end>start;end--) {
    if(src[end] != ' ') {
      break;
    }
  }
  for(i=start;i<=end;i++) {
    if (pos == max) break;
    dest[pos]=src[i];
    pos++;
  }
  if (pos < max) {
    dest[pos]=0;
  }
}
