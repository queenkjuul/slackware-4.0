/*
  implements a blocking file descriptor
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <util/socket.h>



Socket::Socket(char* filename) {
  buffer=new Buffer(50);
  buffer->append(filename);
  cout << "socket is:"<<filename<<endl;
  lOpen=false;
  acceptSocket=create();
  pthread_mutex_init(&acceptMut,NULL);
}


Socket::~Socket() {
  delete buffer;
}


int Socket::create() {
  int back;
  
  back=::socket(AF_UNIX,SOCK_STREAM,0);
  if (back < 0) {
    perror("socket-Socket create");exit(1);
  }
  
  unsigned int i=0;
  sockad.sun_family=AF_UNIX;

  while(i<strlen(buffer->getData())) {
        sockad.sun_path[i]=buffer->getData()[i];
        i++;
  }
  sockad.sun_path[i]=0;
  if (bind(back,(sockaddr*)&sockad,strlen(buffer->getData())+2)<0) {
    perror("bind");exit(1);
  }
  if (listen(back,1) < 0) {
    perror("listen");exit(1);
  }
  if (fcntl(back,F_SETFD,true) < 0) {
    perror("fcntl create");exit(1);
  }

  return back;
}
  
int Socket::close() {
  int ret;
  if (lOpen == false) {
    cout << "Socket already closed. call ignored"<<endl;
    return true;
  }
  ret=::close(dataSocket);
  lOpen=false;
  if (ret < 0) {
    perror("close");
  }
  return ret;
}



int Socket::kill() {
  int ret;
  int socket=::socket(AF_UNIX,SOCK_STREAM,0);

  while (pthread_mutex_trylock(&acceptMut) == EBUSY) {
    if (::connect(socket,(sockaddr*)&sockad,
		  strlen((char*)&sockad.sun_path)+2)<0) {
      perror("Socket::kill connect");
      continue;
    }
    break;
  }
  cout << "after while"<<endl;
  ::close(socket);
  ret=::close(acceptSocket);
  if (ret < 0) {
    perror("close");
  }
  acceptSocket=-2;
  pthread_mutex_unlock(&acceptMut);
  return ret;
}


int Socket::accept() {
  pthread_mutex_lock(&acceptMut);
  cout << "accepting -s "<<endl;
  if (acceptSocket > 0) {
    dataSocket=::accept(acceptSocket,(sockaddr*)&partn_ad,&partn_len);
  } else {
    cout << "error accept"<<endl;
  }
  cout << "accepting -e"<<dataSocket<<endl;
  pthread_mutex_unlock(&acceptMut);
  
  if (dataSocket > 0) {
    lOpen=true;
  } else {
    perror("accept");
  }
  return dataSocket;
}


char* Socket::getFileName() {
  return buffer->getData();
}



int Socket::read(char* buf, int max) {
  int back;

  if (lOpen == false) {
    cout << "not open"<<endl;
    return -1;
  }

  back=::recv(dataSocket,buf,max,0);

  if (back == -1) {
    printf("Socket error mit :%d fd:%d buf:%p len:%d\n",
	   errno,dataSocket,buf,max);
    if (errno == EAGAIN) {
      printf("errno:EAGAIN\n");
    }
    if (errno == EINTR) {
      printf("errno:EINTR\n");
    }
    if (errno == EIO) {
      printf("errno:EIO\n");
    }
    if (errno == EBADF) {
      printf("errno:EBADF\n");
    }    
    if (errno == EINVAL) {
      printf("errno:EINVAL\n");
    }  
    if (errno == EISDIR) {
      printf("errno:EISDIR\n");
    }  
    if (errno == EFAULT) {
      printf("errno:EFAULT\n");
    } 
  }
  return back;
}
  
 
int Socket::write(char* buf, int max) {
  return ::send(dataSocket,buf,max,0);
}


int Socket::isOpen() {
  return (lOpen);
}
  
