/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#include "appwindow.h"

#include <qpopmenu.h>
#include <qkeycode.h>
#include <qlabel.h>
#include <kapp.h>
#include <qfile.h>
#include <kfiledialog.h>
#include <kiconloader.h>
#include <kmsgbox.h>
#include <iostream.h>
#include <fstream.h>
#include <qfile.h>
#include <kurl.h>
#include <qcursor.h>

ApplicationWindow::ApplicationWindow()
    : KTMainWindow("kjukebox" )
{
  config = (KApplication::getKApplication())->getConfig();
  config->setGroup(KCONFIG_GENERAL);

  shufflePlaying = config->readBoolEntry(KCONFIG_GENERAL_SHUFFLE,true);

  playingSongName = new (QString)[3];

  // Menu Bar
  cout << "InitMenuBar " << endl;
  initMenuBar();

  //Statusleiste
  cout << "InitStatusBar " << endl;
  status = statusBar();
  enableStatusBar();
  status->message( i18n("Ready"), 2000 );
  config->setGroup(KCONFIG_GENERAL);
  if(config->readBoolEntry(KCONFIG_GENERAL_STATUSBAR,true)){
    controls->setItemChecked(sb, true);
    enableStatusBar(KStatusBar::Show);
  }
  else {
    controls->setItemChecked(sb, false);
    enableStatusBar(KStatusBar::Hide);
  }

  /*
    Initialize the Toolbars, this must be happen before initializePlayer is called.
    The reason is, that the Timers should be connected to the StreamInfoDevices
    in initialize Player but created by initSoundToolbar(int player). 
    Swap the order and it Segmentation Fault.
  */
  cout << "InitMainToolbar " << endl;
  initMainToolbar();
  cout << "Creating the Timer Array" << endl;
  timer  = (Timer **) new (Timer*)[3];
  cout << "InitSoundToolBar for Player One" << endl;
  initSoundToolbar(PLAYER1);
  cout << "InitSoundToolBar for Player Two" << endl;
  initSoundToolbar(PLAYER2);
  
  //Initialize the Player  
  cout << "InitPlayer " << endl;
  initializePlayer();

  //something more 
  cout << "Something More " << endl;
  settings=NULL;
  refresh();


  /* Main Widget */
  cout << "InitMainWidget " << endl;
  mainWidget = new MainWidget(this);
  connect(mainWidget,SIGNAL(genreChanged(Genre)),this,SLOT(setGenreMenu(Genre)));
  connect(mainWidget,SIGNAL(dropAction(KDNDDropZone*)),
	  this, SLOT(drop(KDNDDropZone *)));
  connect(mainWidget,SIGNAL(databaseChanged()),this,SLOT(databaseChanged()));

  setView(mainWidget);
  setMinimumSize( 200, 50 );
  
  resize(config->readNumEntry( KCONFIG_GENERAL_WIDTH,800),
	 config->readNumEntry( KCONFIG_GENERAL_HEIGHT,500));
  dateiName = "";
  dbChanged = false;
  setTitle();
  show();
}

ApplicationWindow::~ApplicationWindow(){

}


void ApplicationWindow::initMenuBar(){
  config->setGroup(KCONFIG_GENERAL);

  QPopupMenu *import = new QPopupMenu();
  import->insertItem( i18n("MP3 File"), this, SLOT(importMP3Datei()) );
  import->insertItem( i18n("M3u List"), this, SLOT(importM3uListe()) );
  import->insertItem( i18n("MP3 List"), this, SLOT(importMP3Liste()) );
  QPopupMenu *export = new QPopupMenu();
  export->insertItem( i18n("MP3 List"), this, SLOT(exportMP3Liste()));
  export->insertItem( i18n("M3u List"), this, SLOT(exportM3uListe()));

  QPopupMenu *datei = new QPopupMenu();
  datei -> insertItem ( i18n("&New"), this, SLOT(neu()), CTRL+Key_N);
  datei -> insertItem ( i18n("&Load"), this, SLOT(laden()), CTRL+Key_O );
  datei -> insertItem ( i18n("&Save"), this, SLOT(speichern()), CTRL+Key_S );
  datei -> insertItem ( i18n("Save as"), this, SLOT(speichernAls()), CTRL+Key_A );
  datei -> insertSeparator();
  datei -> insertItem ( i18n("&Import"), import );
  datei -> insertItem ( i18n("E&xport"), export );
  datei -> insertSeparator();
  datei -> insertItem ( i18n("Settings..."), this, SLOT(settingsOpen()) );
  datei -> insertSeparator();
  datei -> insertItem ( i18n("&Quit"), this, SLOT(quitKJukeBox()), CTRL+Key_Q );

  //  QPopupMenu *genre = new QPopupMenu();
  genre = new QPopupMenu();
  genre -> insertItem ( i18n("All") );
  connect(genre,SIGNAL(activated(int)), this, SLOT(genreChanged(int)));

  controls = new QPopupMenu();
  mtb = controls -> insertItem(i18n("Main Tool Bar"), this, SLOT(toggleMainToolBar()));
  controls->setCheckable( TRUE );
  controls->setItemChecked( mtb, TRUE );
  stb = controls -> insertItem(i18n("Sound Tool Bar"), this, SLOT(toggleSoundToolBar()));
  controls->setCheckable( TRUE );
  controls->setItemChecked( stb, TRUE );

  sb = controls -> insertItem(i18n("Status Bar"), this, SLOT(toggleStatusBar()), CTRL+Key_T);
  controls->setCheckable( TRUE );
  controls->setItemChecked( sb, TRUE );
 
  QPopupMenu *hilfe = new QPopupMenu();
  hilfe -> insertItem ( i18n("&Help"), this, SLOT(hilfe()), Key_F1);
  hilfe -> insertSeparator();
  hilfe -> insertItem ( i18n("&About KJukeBox"), this, SLOT(ueberkjukebox()) );
  hilfe -> insertItem ( i18n("About &KDE"), (KApplication::getKApplication()), SLOT(aboutKDE()) );
    
  menu = menuBar();
  menu->insertItem( i18n("&File"), datei );
  menu->insertItem( i18n("&Genre"), genre );
  menu->insertItem( i18n("&Controls"), controls );
  menu->insertItem( i18n("&Help"), hilfe );
}


void ApplicationWindow::initSoundToolbar(int player){
  QPixmap pix;
  QLabel *tmp;
  int toolBarId;
  QString text;

  if (player == PLAYER1) toolBarId = ID_SOUND1_TOOLBAR;
  else toolBarId = ID_SOUND2_TOOLBAR;

  config->setGroup(KCONFIG_GENERAL);

  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/rew.xpm");   
  toolBar(toolBarId)->insertButton(pix,ID_BACKWARD, true,i18n("Move backward"));
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/play.xpm");   
  toolBar(toolBarId)->insertButton(pix,ID_PLAY, true,i18n("Play"));         
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/pause.xpm");   
  toolBar(toolBarId)->insertButton(pix,ID_PAUSE, true,i18n("Pause"));         
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/stop.xpm");   
  toolBar(toolBarId)->insertButton(pix,ID_STOP, true,i18n("Stop"));         
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/next.xpm");   
  toolBar(toolBarId)->insertButton(pix,ID_NEXT, true,i18n("Next Song"));         
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/ff.xpm");   
  toolBar(toolBarId)->insertButton(pix,ID_FORWARD, true,i18n("Move forward"));     

  toolBar(toolBarId)->insertSeparator();

  cout << "  Initialize Timer " << player << flush;
  if (player == PLAYER1){
    timer1 = new Timer(toolBar(toolBarId),"timer1");
    toolBar(toolBarId)->insertWidget(ID_COUNTDOWN, 100, timer1);
    connect(timer1,SIGNAL(alarm()), this, SLOT(timer1Alarm()));
    connect(timer1,SIGNAL(stopPlayer()), this, SLOT(player1Stop()));
    timer[PLAYER1] = timer1;
  }
  if (player == PLAYER2){
    timer2 = new Timer(toolBar(toolBarId),"timer2");
    toolBar(toolBarId)->insertWidget(ID_COUNTDOWN, 100, timer2);
    connect(timer2,SIGNAL(alarm()), this, SLOT(timer2Alarm()));
    connect(timer2,SIGNAL(stopPlayer()), this, SLOT(player2Stop()));
    timer[PLAYER2] = timer2;
  }
  cout << " MEM:" << (timer[player]) 
       << " TIMEMODE:" << timer[player]->getTimeMode() << endl;
  
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/left.xpm");   
  toolBar(toolBarId)->insertButton(pix,ID_LEFT_ARROW, false);
  
  tmp = new QLabel(toolBar(toolBarId));
  tmp->setText("NoSong");
  tmp->setAlignment(AlignLeft|AlignVCenter);
  toolBar(toolBarId)->insertWidget(ID_PLAYER_TEXT,400,tmp);

  if (player == PLAYER1)
    connect(toolBar(toolBarId), SIGNAL(clicked(int)),
	    this, SLOT(slotSoundToolbar1Clicked(int)));    
  if (player == PLAYER2)
    connect(toolBar(toolBarId), SIGNAL(clicked(int)), 
	    this, SLOT(slotSoundToolbar2Clicked(int)));    

  if(config->readBoolEntry(KCONFIG_GENERAL_SOUNDTOOLBAR ,true)){
    controls->setItemChecked(stb, true);
    enableToolBar(KToolBar::Show,toolBarId);
  }
  else{    
    controls->setItemChecked(stb, false);
    enableToolBar(KToolBar::Hide,toolBarId);
  }     
}

void ApplicationWindow::slotSoundToolbar1Clicked(int index){
  slotSoundToolbarClicked(PLAYER1, index);
}
void ApplicationWindow::slotSoundToolbar2Clicked(int index){
  slotSoundToolbarClicked(PLAYER2, index);
}
void ApplicationWindow::slotSoundToolbarClicked(int player, int index){
  switch (index) {
  case ID_BACKWARD: skipBackward(player); break;
  case ID_PLAY:     playSongs(player); break;
  case ID_PAUSE:    playerPause(player); break;
  case ID_STOP:     playerStop(player); break;
  case ID_NEXT:     playNext(player); break;
  case ID_FORWARD:  skipForward(player); break;
  }
}

void ApplicationWindow::initMainToolbar(){
  QPixmap pix;
  KIconLoader *loader;
  loader = (KApplication::getKApplication())->getIconLoader();

  toolBar(ID_MAIN_TOOLBAR)->insertButton(loader->loadIcon("filenew.xpm"),ID_NEW, true,i18n("New Database"));         
  toolBar(ID_MAIN_TOOLBAR)->insertButton(loader->loadIcon("fileopen.xpm"),ID_OPEN, true,i18n("Open new Database"));         
  toolBar(ID_MAIN_TOOLBAR)->insertButton(loader->loadIcon("filefloppy.xpm"),ID_SAVE, true,i18n("Save Database"));         

  toolBar(ID_MAIN_TOOLBAR)->insertSeparator();
  
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/copy_selection.xpm");
  toolBar(ID_MAIN_TOOLBAR)->insertButton(pix,ID_COPYSELECTION, true,i18n("Copy selected Song"));
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/copy_all.xpm");
  toolBar(ID_MAIN_TOOLBAR)->insertButton(pix,ID_COPYALL, true,i18n("Copy all songs"));
   pix.load(KApplication::kde_datadir() + "/kjukebox/pix/remove.xpm");   
  toolBar(ID_MAIN_TOOLBAR)->insertButton(pix,ID_REMOVE, true,i18n("Remove selected Song"));
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/removeplayed.xpm");   
  toolBar(ID_MAIN_TOOLBAR)->insertButton(pix,ID_REMOVEPLAYED, true,i18n("Remove played Songs"));
  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/clearplaylist.xpm");   
  toolBar(ID_MAIN_TOOLBAR)->insertButton(pix,ID_CLEARPLAYLIST, true,i18n("Clear the Playlist"));
  
  toolBar(ID_MAIN_TOOLBAR)->insertSeparator();

  if(shufflePlaying)
    pix.load(KApplication::kde_datadir() + "/kjukebox/pix/shuffle_active.xpm");   
  else
    pix.load(KApplication::kde_datadir() + "/kjukebox/pix/shuffle.xpm");   
  toolBar(ID_MAIN_TOOLBAR)->insertButton(pix,ID_SHUFFLE, true,i18n("Toggle shuffle play"));

  connect(toolBar(ID_MAIN_TOOLBAR), SIGNAL(clicked(int)), 
	  this, SLOT(slotMainToolbarClicked(int)));    
  if(config->readBoolEntry(KCONFIG_GENERAL_SOUNDTOOLBAR,true)){
    controls->setItemChecked(mtb, true);
    enableToolBar(KToolBar::Show,ID_MAIN_TOOLBAR);
  }
  else{    
    controls->setItemChecked(mtb, false);
    enableToolBar(KToolBar::Hide,ID_MAIN_TOOLBAR);
  }     

}

void ApplicationWindow::slotMainToolbarClicked(int index){
  switch (index) {  
  case ID_NEW:           neu(); break;
  case ID_OPEN:          laden(); break;
  case ID_SAVE:          speichern(); break;
  case ID_COPYSELECTION: mainWidget->copySongIntoPlayList();  break;
  case ID_COPYALL:       mainWidget->copyAllSongsIntoPlayList();  break;
  case ID_REMOVE:        mainWidget->removeSong();  break;
  case ID_REMOVEPLAYED:  mainWidget->removePlayedSongs(); break;
  case ID_CLEARPLAYLIST: mainWidget->clearPlayList(); break;
  case ID_SHUFFLE:       toggleShufflePlaying(); break;
  }
}
 
void ApplicationWindow::toggleShufflePlaying(){
  shufflePlaying = !shufflePlaying;
  config->setGroup(KCONFIG_GENERAL);
  config->writeEntry(KCONFIG_GENERAL_SHUFFLE, shufflePlaying);
  refresh();
}

void ApplicationWindow::drop( KDNDDropZone *zone ){
  unsigned int i;
  QString file;
  QString tmp;
  QFile   fileTest;

  status = statusBar();
  status->message(i18n("Please Wait"), 2000 );
  KApplication::setOverrideCursor( waitCursor );

  for(i=0; i<(zone->getURLList()).count(); i++) {    // process dropped objects
    if (i==0) tmp = (zone->getURLList()).first();
    else tmp = (zone->getURLList()).next();
    KURL url(tmp);
    if(!strcmp(url.protocol(),"file")) {              // is this a local object ?
      file = url.path();
      //      cout << "Type is file" << endl;
      fileTest.setName(file);
      if (fileTest.exists()){
	if (file.findRev ( ".mp3", -1, false )!= -1)
	  mainWidget->addSong(ioaccess.importMP3File( file ));
	else if (file.findRev ( ".m3u", -1, false )!= -1)
	  mainWidget->addSongs(ioaccess.importM3uFileList( file  ));
	else if (file == url.directory())
	  mainWidget->addSongs(ioaccess.importDirectory(file));
	else {   
	  config->setGroup(KCONFIG_GENERAL);
	  mainWidget->addSongs(ioaccess.importMP3FileList( file ));
	}
      }
      else cout << "File " << file << " not found! I skip it." << endl;
    }
    else {
      KMsgBox::message(this,"Drop Error",
			    "Only files and Directories are accepted !!!");
    }
  }
  KApplication::restoreOverrideCursor();
  status->message( i18n("Ready"), 500 );
}

void ApplicationWindow::settingsOpen(){
  if(settings==NULL)
    settings = new Configuration();
  settings->toggleVisible();
}                    

void ApplicationWindow::settingsDestroyed(){
  cout << "Settings Destroyed" << endl;
  settings = NULL;
  settingsUp=FALSE;
}


void ApplicationWindow::hilfe(){
  kapp->invokeHTMLHelp("kjukebox/index.html","KJukeBox");
}

void ApplicationWindow::ueberkjukebox(){
  QString name;
  name = "KJukeBox v";
  name += VERSION;
  name += " MP3-Player\nBy: Rainer Maximini\nEmail:maximini@informatik.uni-kl.de\nhttp://third.informatik.uni-kl.de/~rainer/kjukebox/index.html";
  KMsgBox::message(0L,"KJukeBox",name,KMsgBox::INFORMATION); 
}


void ApplicationWindow::genreChanged(int i){
  if (i==0) mainWidget->setGenre(GENRE_ALL);
  else mainWidget->setGenre(genre->text(i));
}

void ApplicationWindow::setGenreMenu(Genre newMenu){
  GenreIterator lauf;
  genre->clear();
  genre -> insertItem ( i18n("All") );
  for(lauf = newMenu.begin(); lauf!=newMenu.end(); lauf++){
    genre -> insertItem ( *lauf );
  }
}

void ApplicationWindow::toggleStatusBar(){
  controls->setItemChecked( sb, (!controls->isItemChecked(sb)) );
  enableStatusBar();

  config->setGroup(KCONFIG_GENERAL);
  config->writeEntry(KCONFIG_GENERAL_STATUSBAR, controls->isItemChecked(sb));
  config->sync();
}

void ApplicationWindow::toggleSoundToolBar(){
  if(controls->isItemChecked(stb)){
    enableToolBar(KToolBar::Hide,ID_SOUND1_TOOLBAR);
    enableToolBar(KToolBar::Hide,ID_SOUND2_TOOLBAR);
  }
  else{
    enableToolBar(KToolBar::Show,ID_SOUND1_TOOLBAR);
    enableToolBar(KToolBar::Show,ID_SOUND2_TOOLBAR);
  }
  controls->setItemChecked( stb, (!controls->isItemChecked(stb)) );

  config->setGroup(KCONFIG_GENERAL);
  config->writeEntry(KCONFIG_GENERAL_SOUNDTOOLBAR, controls->isItemChecked(stb));
  config->sync();
}

void ApplicationWindow::toggleMainToolBar(){
  if(controls->isItemChecked(mtb))
    enableToolBar(KToolBar::Hide,ID_MAIN_TOOLBAR);
  else
    enableToolBar(KToolBar::Show,ID_MAIN_TOOLBAR);
  
  controls->setItemChecked( mtb, (!controls->isItemChecked(mtb)) );

  config->setGroup(KCONFIG_GENERAL);
  config->writeEntry(KCONFIG_GENERAL_MAINTOOLBAR, controls->isItemChecked(mtb));
  config->sync();
}


void ApplicationWindow::setStatus(int status){}
void ApplicationWindow::showError(int error){}


void ApplicationWindow::setTitle(){
  title = "KJukeBox: " + dateiName;
  setCaption(title);
}


void ApplicationWindow::refreshSoundToolBar(int player){  
  QPixmap pix_play;
  QPixmap pix_stop;
  QPixmap pix_pause;
  QPixmap pix_left;
  int toolBarId;
  QString text = "No Song ";
  QLabel *label;

  if (player == PLAYER1) toolBarId = ID_SOUND1_TOOLBAR;
  else toolBarId = ID_SOUND2_TOOLBAR;

  //  cout << "Player:"<<player<<" playing:"<<playing[player] << endl;
  //  cout << "pausing:" <<pausing[player] << endl;

  if (pausing[player]){
    pix_pause.load(KApplication::kde_datadir() + "/kjukebox/pix/pause_active.xpm");   
    pix_left.load (KApplication::kde_datadir() + "/kjukebox/pix/left_active.xpm");
    pix_play.load (KApplication::kde_datadir() + "/kjukebox/pix/play.xpm");   
    pix_stop.load (KApplication::kde_datadir() + "/kjukebox/pix/stop.xpm");   
    text = playingSongName[player];
  }
  else if (playing[player]){
    pix_play.load (KApplication::kde_datadir() + "/kjukebox/pix/play_active.xpm");   
    pix_left.load (KApplication::kde_datadir() + "/kjukebox/pix/left_active.xpm");
    pix_stop.load (KApplication::kde_datadir() + "/kjukebox/pix/stop.xpm");   
    pix_pause.load(KApplication::kde_datadir() + "/kjukebox/pix/pause.xpm"); 
    text = playingSongName[player];
  }
  else {
    pix_stop.load (KApplication::kde_datadir() + "/kjukebox/pix/stop_active.xpm");   
    pix_left.load (KApplication::kde_datadir() + "/kjukebox/pix/left.xpm");
    pix_play.load (KApplication::kde_datadir() + "/kjukebox/pix/play.xpm");   
    pix_pause.load(KApplication::kde_datadir() + "/kjukebox/pix/pause.xpm"); 
  }
  toolBar(toolBarId)->setButtonPixmap(ID_PLAY,pix_play);         
  toolBar(toolBarId)->setButtonPixmap(ID_STOP,pix_stop);         
  toolBar(toolBarId)->setButtonPixmap(ID_PAUSE,pix_pause);         
  toolBar(toolBarId)->setButtonPixmap(ID_LEFT_ARROW,pix_left);

  if(shufflePlaying)
    pix_play.load(KApplication::kde_datadir() + "/kjukebox/pix/shuffle_active.xpm");   
  else
    pix_play.load(KApplication::kde_datadir() + "/kjukebox/pix/shuffle.xpm");   
  toolBar(ID_MAIN_TOOLBAR)->setButtonPixmap(ID_SHUFFLE, pix_play);         

  label = (QLabel*)toolBar(toolBarId)->getWidget(ID_PLAYER_TEXT);
  label->setText(text);
}


void ApplicationWindow::refresh(){
  refreshSoundToolBar(PLAYER1);
  refreshSoundToolBar(PLAYER2);
}


void ApplicationWindow::resizeEvent( QResizeEvent *tmp ){
  config->setGroup(KCONFIG_GENERAL);
  config->writeEntry(KCONFIG_GENERAL_WIDTH, width());
  config->writeEntry(KCONFIG_GENERAL_HEIGHT, height()); 
  config->sync();

  KTMainWindow::resizeEvent(tmp);
  
  setTitle();
  refresh();
}


