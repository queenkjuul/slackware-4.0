/*
  a view for a pathMapper.
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <pathMapperView1.h>


PathMapperView1::PathMapperView1(PathMapper* pathMapper) {
  this->pathMapper=pathMapper;
}


PathMapperView1::~PathMapperView1() {
}


void PathMapperView1::paint( QPainter* p) {
  QFont font = p->font();
  
  QFontMetrics fm(font);
  int ypos = fm.ascent() + fm.leading()/2;
  p->save();
  p->setFont(font);
  p->drawText( 5, ypos, pathMapper->toString() );
  p->restore();   
}


int PathMapperView1::height( const QListBox* lb) const {
  return lb->fontMetrics().lineSpacing()+2;
}


int PathMapperView1::width( const QListBox* lb ) const {
  return lb->fontMetrics().width( text() )+6;
}
