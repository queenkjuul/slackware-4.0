/*
  model for the pathmapper
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __PATHMAPPERLIST_H
#define __PATHMAPPERLIST_H

#include <pathMapper.h>
#include <qlist.h>
#include <qobject.h>

class PathMapperList : public QObject {
 Q_OBJECT

  QList<PathMapper> mapList;


 public:
  PathMapperList();
  ~PathMapperList();

  int getCurrentPos();
  PathMapper* at(int index);
  int count();
  int find(PathMapper* pathMapper);

 public slots:
   void addPathMapper(PathMapper* pathMapper);
   void delPathMapper();
   void setCurrentPos(int pos);
   void pathMapperUpdate(PathMapper* pathMapper);

 signals:
   void addPathMapperEvent(PathMapper* pathMapper);
   void removePathMapperEvent(int index);
   void setCurrentPosEvent(int index);
   void pathMapperUpdateEvent(PathMapper* pathMapper,int index);

};
#endif
