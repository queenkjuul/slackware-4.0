/*
  a DataGenerator coordinates userinput and the running thread
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <producer/core/dataGenerator.h>

DataGenerator::DataGenerator() {
  id=0;
}


DataGenerator::~DataGenerator() {
}


int DataGenerator::updateDeviceConfig(DeviceConfig* newConfig) {
  return true;
}


int DataGenerator::open(char* filename ) {
  return true;
}


int DataGenerator::close() {
  return true;
}


int DataGenerator::play() {
  return true;
}


int DataGenerator::pause() {
  return true;
}


int DataGenerator::jump(int) {
  return true;
}


void DataGenerator::setDecoderId(int id) {
  this->id=id;
}


int DataGenerator::getDecoderId() {
  return id;
}

