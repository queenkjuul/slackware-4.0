/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#include <iostream.h>
#include <qstring.h>
#include <fstream.h>
#include "ioaccess.h"
#include "mp3.h"
#include "kjukebox.h"
#include <kurl.h>
#include <qdir.h>
#include <kconfig.h>
#include <kapp.h>
#include <qfile.h>

IOAccess::IOAccess(){
  progressBar = new KProgress(NULL,"progressbar");
  progressBar -> setOrientation(KProgress::Horizontal);
  progressBar -> setCaption(i18n("Please Wait"));
  progressBar -> setFixedSize(250,20);
}

Song IOAccess::loadMP3File(QString filename){
  Song tmp;
  if(  mp3.open(filename) ) {
    mp3.initfile() ;
    mp3.close();
    return mp3.getSong();
  }
  return tmp;
}
   

Songs IOAccess::load(QString filename){
  Songs songs;
  Song song;
  QFile file;
  char tmp[2000];
  QString input;
  ifstream infile(filename, ios::in);
  if (!infile) return songs;
  while(infile){
    infile.getline(tmp,2000);
    input = tmp;
    if(!input.isEmpty()){
      song.initFromString(input);
      file.setName(song.getFilename());
      if(file.exists()) songs.push_back(song);
      else cout << "File " << song.getFilename() 
		<< " not found!!! I Skip it." << endl;
    }
    *tmp = '\0';
  }
  return songs;
}
  

bool IOAccess::save(QString filename, Songs songs){
  SongIterator lauf;
  
  ofstream outfile(filename,ios::out|ios::trunc);
  if (!outfile) { return FALSE;  }

  for(lauf=songs.begin(); lauf!=songs.end(); lauf++){
    outfile << lauf->asString() << endl;
  }
  outfile.close();
  return TRUE;
}

bool IOAccess::exportMP3List(QString filename, Songs songs){
  SongIterator lauf;
  KConfig *config;
  QString format, trennzeichen;
  config = (KApplication::getKApplication())->getConfig();  
  config->setGroup(KCONFIG_FILE);
  format = config->readEntry(KCONFIG_FILE_IMPORTFORMAT,
			     "AP|TI|AR|AL|YE|CO|GE|||||BI|SA|ST|||||SE|RP|SI|FS|LS");
  trennzeichen = config->readEntry( KCONFIG_FILE_IMPORTSEPERATOR, "|");

  ofstream outfile(filename,ios::out|ios::trunc);
  if (!outfile) { return FALSE;  }

  for(lauf=songs.begin(); lauf!=songs.end(); lauf++){
    outfile << lauf->asString(format, trennzeichen) << endl;
  }
  outfile.close();
  return TRUE;
}

bool IOAccess::exportM3uList(QString filename, Songs songs){
  SongIterator lauf;
  QString pfad;

  ofstream outfile(filename,ios::out|ios::trunc);
  if (!outfile) { return FALSE;  }

  for(lauf=songs.begin(); lauf!=songs.end(); lauf++){
    KURL url(lauf->getFilename());
    cout << "Orig:" << lauf->getFilename()
	 << "File:" << url.filename() << endl;
    outfile << url.filename() << endl;
  }
  outfile.close();
  return TRUE;
}


Songs IOAccess::importMP3FileList(QString filename){
  Songs songs;
  Song song;
  int anzahl = 0;
  char tmp[2000];
  QString input;
  QFile file;

  KConfig *config;
  QString format, trennzeichen;
  config = (KApplication::getKApplication())->getConfig();  
  config->setGroup(KCONFIG_FILE);
  format = config->readEntry(KCONFIG_FILE_IMPORTFORMAT,
			     "AP|TI|AR|AL|YE|CO|GE|||||BI|SA|ST|||||SE|RP|SI|FS|LS");
  format = format.upper();
  trennzeichen = config->readEntry(KCONFIG_FILE_IMPORTSEPERATOR, "|");

  ifstream infile(filename, ios::in);
  if (!infile) return songs;
  while(infile.ignore(2000,'\n'))
    anzahl++;
  //  cout << anzahl << endl;
  infile.close();

  progressBar->setRange(1,360);
  progressBar->setSteps(1,1);
  progressBar->show();

  infile.open(filename, ios::in);
  while(infile){
    infile.getline(tmp,2000);
    input = tmp;
    if(!input.isNull()){
      progressBar->addLine();
      song.initFromString(input,format,trennzeichen);
      file.setName(song.getFilename());
      if(file.exists()) songs.push_back(song);
      else cout << "File " << song.getFilename() 
		<< " not found!!! I Skip it." << endl;
    }
  }
  infile.close();
  progressBar->hide();
  return songs;
}


Songs IOAccess::importM3uFileList(QString filename){
  Songs songs;
  Song song;
  int anzahl = 0;
  char tmp[2000];
  QString file;
  QString pfad;
  QString mp3file;
  ifstream infile(filename, ios::in);
  *tmp ='\0';
  
  if (!infile) return songs;
  while(infile.ignore(2000,'\n')) anzahl++;
  infile.close();

  progressBar->setRange(1,360);
  progressBar->setSteps(1,1);
  progressBar->show();

  KURL url(filename);
  pfad = url.directory();

  infile.open(filename, ios::in);
  while(infile){
    infile.getline(tmp,2000);
    file = tmp;
    file = file.stripWhiteSpace();
    if(!file.isEmpty()){
      progressBar->addLine();
      mp3file = pfad;
      mp3file += file;
      KURL::decodeURL(mp3file);
      if(  mp3.open(mp3file) ) {
	cout << "loading" << endl;
	mp3.initfile() ;
	mp3.close();
	songs.push_back( mp3.getSong() );   
      }
      else cout << "File " << mp3file 
		<< " not found!!! I Skip it." << endl;

      //      else cout << "Fehler beim Laden von " << mp3file << endl;
    }  
  }
  infile.close();
  progressBar->hide();
  return songs;
}

Song IOAccess::importMP3File(QString filename){
  return loadMP3File(filename);
}

Songs IOAccess::importDirectory(QString path){
  Songs        songs;
  Songs        tmpSongs;
  SongIterator tmpIterator;
  QDir         dir;
  QStrList     list;
  QString      file;
  QString      tmp;
  //  cout << "Add path:" << path << endl;
  
  dir.setPath(path);
  dir.setFilter(QDir::Dirs);
  list = *(dir.entryList());

  for (tmp=list.first(); tmp != 0; tmp=list.next() ){
    if( (strcmp(tmp,".")==0) || (strcmp(tmp,"..")==0) ) continue;
    KURL url(path+"/"+tmp);
    file = url.path();
    //    cout << "dir:" << file << endl;
    tmpSongs = importDirectory(file);
    for (tmpIterator=tmpSongs.begin(); tmpIterator!=tmpSongs.end(); tmpIterator++)
      songs.push_back(*tmpIterator);
  }

  dir.setFilter(QDir::Files);
  list = *(dir.entryList());

  for (tmp=list.first(); tmp != 0; tmp=list.next() ){
    if( (strcmp(tmp,".")==0) || (strcmp(tmp,"..")==0) ) continue;
    KURL url(path+"/"+tmp);
    file = url.path();
    //    cout << "file:" << file << endl;
    if (file.findRev ( ".mp3", -1, false )!= -1)
      songs.push_back(importMP3File( file ));
  }


  return songs;
}

