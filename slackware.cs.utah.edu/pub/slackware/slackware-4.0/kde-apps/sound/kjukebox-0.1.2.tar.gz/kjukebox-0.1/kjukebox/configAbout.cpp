#include <klined.h>
#include "configAbout.h"


ConfigAbout::ConfigAbout(QWidget *parent, const char *name)
    : QWidget (parent,name)
{
  box = new QGroupBox(this,"box");
  label = new QLabel(box,"label");
  hometext= new QLabel(box,"hometext");
  

  version = VERSION;
  labelstring.sprintf("kmp3 v%s\n",(const char *)version);
  labelstring +="Copyright (c) 1998 \n\nKerstin Faber\n"\
                 "faber@informatik.uni-kl.de\n\n"\
                 "and\n\nRainer Maximini\n"\
                 "maximini@informatik.uni-kl.de";
  label->setAlignment(AlignLeft|WordBreak);
  label->setText(labelstring.data());

  homestring = i18n("Visit the KJukeBox Homepage for bugfixes or new versions\nat http://third.informatik.uni-kl.de/~rainer/kjukebox/index.html");
  hometext->setAlignment(AlignCenter|WordBreak);
  hometext->setText(homestring.data());

  pix.load(KApplication::kde_datadir() + "/kjukebox/pix/logo.xpm");   
  logo = new QLabel(box);
  logo->setPixmap(pix);
}

void ConfigAbout::resizeEvent( QResizeEvent * ){
  box->setGeometry(10,10,width()-20,height()-20);

  logo->setGeometry(15, 30, pix.width(), pix.height());
  label->setGeometry(pix.width()+30, 30,
		     width()-(pix.width()+15+30+15), height()-120);
  hometext->setGeometry(10,height()-80,width()-40,50);
}

void ConfigAbout::cancel(){}

void ConfigAbout::accept(){}



