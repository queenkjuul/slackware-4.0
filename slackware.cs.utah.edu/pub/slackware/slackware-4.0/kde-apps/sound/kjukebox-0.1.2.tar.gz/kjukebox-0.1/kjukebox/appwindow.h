/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#ifndef MENU_H
#define MENU_H

#include "../config.h"
#include "songList.h"
#include "songTree.h"
#include "configfolder.h"
#include "ioaccess.h"
#include "songInfo.h"
#include "mainwidget.h"

#include "amplifier/amplifier.h"
#include "amplifier/metaPlayer.h"
#include "devices/multicastDevice.h"
#include "devices/mixerDevice.h"
#include "devices/audioDevice.h"
#include "devices/multicastDevice.h"
#include "devices/volumeDevice.h"
#include "deviceConfig/timeInfo.h"
//#include "timerWidget.h"

#include "timer.h"
#include <ktmainwindow.h>
#include <kmenubar.h>
#include <kstatusbar.h>
#include <drag.h>
#include <qstring.h>
#include <qscrollbar.h>

#define ID_MAIN_TOOLBAR  0
#define ID_NEW           0
#define ID_OPEN          1
#define ID_SAVE          2
#define ID_HELP          3
#define ID_COPYSELECTION 4 
#define ID_COPYALL       5 
#define ID_REMOVE        6 
#define ID_REMOVEPLAYED  7
#define ID_CLEARPLAYLIST 8
#define ID_SHUFFLE       9

#define ID_SOUND1_TOOLBAR 1
#define ID_SOUND2_TOOLBAR 2
#define ID_BACKWARD       0
#define ID_NEXT           2 
#define ID_PLAY           3 
#define ID_PAUSE          4 
#define ID_STOP           5
#define ID_FORWARD        6
#define ID_VOLUME         7 
#define ID_COUNTDOWN      8 
#define ID_LEFT_ARROW     9 
#define ID_PLAYER_TEXT   10 


#define PLAYER1 1
#define PLAYER2 2

class ApplicationWindow: public KTMainWindow{
  Q_OBJECT
 private:  
  KConfig       *config;
  KMenuBar      *menu;
  KStatusBar    *status;
  QScrollBar    *volumeBar;
  QPopupMenu    *controls;
  QPopupMenu    *genre;
  Configuration *settings;
  MainWidget    *mainWidget;
  bool           settingsUp;
  IOAccess       ioaccess;
  QPixmap       *leftArrow;
  QPixmap       *rightArrow;
  bool           dbChanged;

  AudioDevice      *audioDevice;
  MixerDevice      *mixer;  
  GenericPlayer    **decoder;
  GenericPlayer    *decoder1;
  GenericPlayer    *decoder2;
  MulticastDevice  *multicastDevice1;
  MulticastDevice  *multicastDevice2;
  StreamInfoDevice *streamInfoDevice1;
  StreamInfoDevice *streamInfoDevice2;
  StreamInfoDevice **streamInfoDevice;
  VolumeDevice     *volumeDevice1;
  VolumeDevice     *volumeDevice2;
  VolumeDevice     **volumeDevice;
  Timer            *timer1;
  Timer            *timer2;
  Timer            **timer;
 
  QString *playingSongName;
  int      playerStatus;
  int      sb, stb, mtb;
  bool    *pausing;
  bool    *playing;
  QString  title;
  QString  dateiName;  
  bool     shufflePlaying;


  void setTitle();
  void initMenuBar();
  void initSoundToolbar(int );
  void initMainToolbar();
  void initializePlayer();
  void slotSoundToolbarClicked(int, int );
  void refreshSoundToolBar(int);
 protected:
  void resizeEvent (QResizeEvent *);
 public:
  ApplicationWindow();
  ~ApplicationWindow();

 signals:
 public slots:
  void neu();
  void laden();
  void laden( const char *dateiName );
  void importMP3Datei();
  void importMP3Liste();
  void importM3uListe();
  void exportMP3Liste();
  void exportM3uListe();
  void speichern();
  void speichern(QString ); 
  void speichernAls();
  void hilfe();
  void ueberkjukebox();
  void genreChanged(int);
  void drop(KDNDDropZone *);

  void playSongs(int );
  void playNext(int );
  void skipForward(int );
  void skipBackward(int );
  void playerPause(int );
  void player1Stop();
  void player2Stop();
  void playerStop(int );

  void databaseChanged();

 private slots:
  void slotSoundToolbar1Clicked(int );
  void slotSoundToolbar2Clicked(int );
  void slotMainToolbarClicked(int );
  void toggleShufflePlaying();
  void settingsOpen();
  void settingsDestroyed();
  void setGenreMenu(Genre );
  void toggleStatusBar();
  void toggleMainToolBar();  
  void toggleSoundToolBar();  
  void setStatus(int );
  void showError(int );
  void refresh();
  void decoderStopedPlaying(int );
  void decoderCrashed(int );
  void decoder1Event(char );
  void decoder2Event(char );
  void decoderEvent(int ,char );
  void timerAlarm(int );
  void timer1Alarm();
  void timer2Alarm();
  void quitKJukeBox();
};
#endif // MENU_H


