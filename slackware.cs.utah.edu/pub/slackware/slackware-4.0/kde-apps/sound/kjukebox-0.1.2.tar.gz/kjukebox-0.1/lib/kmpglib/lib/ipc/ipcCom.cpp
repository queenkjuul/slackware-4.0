/*
  sends/receive commandline
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <ipc/ipcCom.h>


static void *readerThread(void *arg){
  ((IPCCom*)arg)->readloop();
  return NULL;
}   


IPCCom::IPCCom(int socket,struct sockaddr_un* sockad) {
  this->socket=socket;
  this->sockad=sockad;

  eventQueue=new EventQueue("IPCCom");

  connect(eventQueue,SIGNAL(processEvent(char)),
	  this,SLOT(hasCommandLine(char)));
  lRun=true;
  pthread_create(&tr,NULL,readerThread,this);
}


IPCCom::~IPCCom() {
  lRun=false;
  void* ret;
  if (::connect(socket,(sockaddr*)sockad,
		strlen((char*)sockad->sun_path)+2)<0) {
    perror("~IPCCom connect");exit(1);
  }
  close(socket);
  pthread_join(tr,&ret);


  delete eventQueue;
}


void IPCCom::readloop() {
  int sd;
  unsigned int partn_len;
  struct sockaddr_un partn_ad;
  int state;
  int narg;
  lBusy=false;

  while(lRun) {
    while(lBusy) sleep(1);
    sd=accept(socket,(sockaddr*)&partn_ad,&partn_len);
    if (lRun == false) {
      break;
    }
    if (sd > 0) {
      IPCElement* ipcElement=new IPCElement(sd);
      while(1) {
	state=ipcElement->receive();
	if (state > 0) {
	  int id=ipcElement->getID();
	  int len=ipcElement->getLen();
	  char* data=ipcElement->getData();
	  switch(id) {
	  case __IPC_ID_START:
	    lBusy=true;
	    commandLineCreator=new CommandLineCreator();
	    break;
	  case __IPC_ID_INT_DATA:
	    narg=ipcElement->getInt();
	    commandLineCreator->setNArgs(narg);
	    break;
	  case __IPC_ID_CHAR_DATA:
	    commandLineCreator->addArg(data);
	    break;
	  case __IPC_ID_END:
	    ipcElement->send(__IPC_ID_END_CONFIRM,0);
	    eventQueue->sendEvent('1');
	    if (close(sd) < 0) {
	      perror("close after child send");
	    }
	    break;
	  default:
	    cout << "receive unknown: id:"<<id<<" len:"<<len
		 <<" data:"<<data<<"***"<<endl;
	    break;
	  }
	} else {
	  break;
	}
	  
      }
    }
  }
}


void IPCCom::hasCommandLine(char eventId) {
  emit(processCommandLine(commandLineCreator));
  eventQueue->clearNotifyBit();
  lBusy=false;
}

  
