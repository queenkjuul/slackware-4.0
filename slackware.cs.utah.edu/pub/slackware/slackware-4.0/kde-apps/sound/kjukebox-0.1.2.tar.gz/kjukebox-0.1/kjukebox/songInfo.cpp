/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#include "songInfo.h"

SongInfo::SongInfo(QWidget *parent, const char *name)
    : QDialog (parent,name)
{

  config = (KApplication::getKApplication())->getConfig();

  setMinimumSize(320,470);

  boxTag       = new QGroupBox("MP3 Tags" , this, "boxtag" );  
  catTitle     = new QLabel(i18n("Title:"),boxTag,"titel");
  valueTitle   = new QLabel(boxTag,"valtitel");
  catArtist    = new QLabel(i18n("Artist:"),boxTag,"artist");
  valueArtist  = new QLabel(boxTag,"valartist");
  catAlbum     = new QLabel(i18n("Album:"),boxTag,"album");
  valueAlbum   = new QLabel(boxTag,"valalbum");
  catYear      = new QLabel(i18n("Year:"),boxTag,"Year");
  valueYear    = new QLabel(boxTag,"valyear");
  catComment   = new QLabel(i18n("Comment:"),boxTag,"Comment");
  valueComment = new QLabel(boxTag,"valcomment");
  catGenre     = new QLabel(i18n("Genre:"),boxTag,"genre");
  valueGenre   = new QLabel(boxTag,"valgenre");

  boxLayer     = new QGroupBox(i18n("MP3 Layer"), this, "boxlayer" );  
  catTime      = new QLabel(i18n("Time:"),boxLayer,"dauer");
  valueTime    = new QLabel(boxLayer,"time");
  catSize      = new QLabel(i18n("Size:"),boxLayer,"Size");
  valueSize    = new QLabel(boxLayer,"valsize");
  catFilename  = new QLabel(i18n("Filename:"),boxLayer,"filename");
  valueFilename   = new QLabel(boxLayer,"valFilename");
  catSamplerate   = new QLabel(i18n("Samplerate:"),boxLayer,"samplerate");
  valueSamplerate = new QLabel(boxLayer,"valSamplerate");
  catBitrate   = new QLabel(i18n("Bitrate:"),boxLayer,"bitrate");
  valueBitrate = new QLabel(boxLayer,"valBitrate");
  catStereo    = new QLabel(i18n("Stereo:"),boxLayer,"Stereo");
  valueStereo  = new QLabel(boxLayer,"valStereo");
  catLayer     = new QLabel(i18n("Layer:"),boxLayer,"Layer");
  valueLayer   = new QLabel(boxLayer,"valLayer");
  catPlayed    = new QLabel(i18n("Played:"),boxLayer,"Played");
  valuePlayed  = new QLabel(boxLayer,"valplayed");
  catLastPlayed   = new QLabel(i18n("Last Played:"),boxLayer,"lastplayed");
  valueLastPlayed = new QLabel(boxLayer,"valLastPlayed");

  boxPrivate = new QGroupBox(i18n("Private")  , this, "boxprivate" );  
  catFirstSeconds   = new QLabel(i18n("First Seconds"),boxPrivate,"firstsec");
  valueFirstSeconds = new KLined(boxPrivate,"vfs");
  catLastSeconds    = new QLabel(i18n("Last Seconds"), boxPrivate,"firstsec");
  valueLastSeconds  = new KLined(boxPrivate,"vls");
  
  acceptButton = new QPushButton(i18n("OK"), this, "accept");
  connect(acceptButton, SIGNAL(clicked()), this, SLOT(accept()));
  applyButton = new QPushButton(i18n("Accept"), this, "apply");
  connect(applyButton, SIGNAL(clicked()), this, SLOT(apply()));
  cancelButton = new QPushButton(i18n("Cancel"), this, "cancel");
  connect(cancelButton, SIGNAL(clicked()), this, SLOT(closeWindow()));
  setGeometry(100,100,320,470);
}

void SongInfo::showSong(){
  QString tmpS;
  //  cout << privateSong.asString()<< endl;
  tmpS  = privateSong.getArtist();
  tmpS += "(";
  tmpS += privateSong.getTitle();
  tmpS += ")";
  setCaption(tmpS);
  setMinimumSize(220,360);
  
  if(edit){
    acceptButton->show();
    applyButton->show();
  }
  else{    
    acceptButton->hide();
    applyButton->hide();
  }
  valueFirstSeconds ->setEnabled(edit);
  valueLastSeconds  ->setEnabled(edit);

 
  valueTitle      ->setText(privateSong.getTitle());
  valueArtist     ->setText(privateSong.getArtist());
  valueAlbum      ->setText(privateSong.getAlbum());
  tmpS.sprintf("%d", privateSong.getYear());
  valueYear       ->setText(tmpS);
  valueComment    ->setText(privateSong.getComment());
  valueGenre->setText(privateSong.getGenre());
  tmpS.sprintf("%d:%02d", (privateSong.getSeconds()/60),(privateSong.getSeconds()%60));
  valueTime       ->setText(tmpS);
  tmpS.sprintf("%d", privateSong.getSize());
  valueSize       ->setText(tmpS);
  valueFilename   ->setText(privateSong.getFilename());
  tmpS.sprintf("%d", privateSong.getSamplerate());
  valueSamplerate ->setText(tmpS);
  tmpS.sprintf("%d", privateSong.getBitrate());
  valueBitrate    ->setText(tmpS);
  valueStereo     ->setText(privateSong.getStereomode());
  valueLayer      ->setText(privateSong.getLayer());
  if (privateSong.getPlayed())    
    valuePlayed  ->setText("True");
  else     
    valuePlayed   ->setText("False");
  tmpS.sprintf("%d",privateSong.getLastPlayed());
  valueLastPlayed ->setText(tmpS);

  tmpS.sprintf("%d",privateSong.getFirstSeconds());
  valueFirstSeconds ->setText(tmpS);
  tmpS.sprintf("%d",privateSong.getLastSeconds());
  valueLastSeconds  ->setText(tmpS);
  if(!isVisible()) show();
}

void SongInfo::showMP3Song(Song *song){
  songReference = song;
  privateSong = *song;
  edit = true;
  showSong();
}

void SongInfo::showMP3Song(Song song){
  songReference = NULL;
  privateSong = song;
  edit = false;
  showSong();
}

void SongInfo::closeWindow(){
  hide();
}

void SongInfo::accept(){
  apply();
  closeWindow();
}

void SongInfo::apply(){
  privateSong.setFirstSeconds(atoi(valueFirstSeconds->text()));
  privateSong.setLastSeconds (atoi(valueLastSeconds ->text()));
  *songReference = privateSong;

  config->setGroup(KCONFIG_FILE);
  if( config->readBoolEntry(KCONFIG_FILE_MP3COMMENT, false) ){
    saveComment();
  }
}

bool SongInfo::saveComment(){
  QString comment;
  comment.sprintf(MP3_COMMENT_FIELD,
		  privateSong.getFirstSeconds(),
		  privateSong.getLastSeconds());
  return mp3.saveCommentTag(privateSong.getFilename(),comment);
}



void SongInfo::resizeEvent( QResizeEvent * ){
  int fb = 100;
  int fs = 110;
  boxTag->setGeometry(5,5,width()-10,140);
  catTitle   ->setGeometry( 10, 15, fb, 20);
  catArtist  ->setGeometry( 10, 35, fb, 20);
  catAlbum   ->setGeometry( 10, 55, fb, 20);
  catYear    ->setGeometry( 10, 75, fb, 20);
  catComment ->setGeometry( 10, 95, fb, 20);
  catGenre   ->setGeometry( 10,115, fb, 20);
  valueTitle   ->setGeometry(fs, 15,boxTag->width()-10-fs, 20);
  valueArtist  ->setGeometry(fs, 35,boxTag->width()-10-fs, 20);
  valueAlbum   ->setGeometry(fs, 55,boxTag->width()-10-fs, 20);
  valueYear    ->setGeometry(fs, 75,boxTag->width()-10-fs, 20);
  valueComment ->setGeometry(fs, 95,boxTag->width()-10-fs, 20);
  valueGenre   ->setGeometry(fs,115,boxTag->width()-10-fs, 20);

  boxLayer->setGeometry( 5,150,width()-10,205);
  catTime      ->setGeometry( 10, 15, fb, 20);
  catSize      ->setGeometry( 10, 35, fb, 20);
  catFilename  ->setGeometry( 10, 55, fb, 20);
  catSamplerate->setGeometry( 10, 75, fb, 20);
  catBitrate   ->setGeometry( 10, 95, fb, 20);
  catStereo    ->setGeometry( 10,115, fb, 20);
  catLayer     ->setGeometry( 10,135, fb, 20);
  catPlayed    ->setGeometry( 10,155, fb, 20);
  catLastPlayed->setGeometry( 10,175, fb, 20);
  valueTime      ->setGeometry(fs, 15,boxLayer->width()-10-fs, 20);
  valueSize      ->setGeometry(fs, 35,boxLayer->width()-10-fs, 20);
  valueFilename  ->setGeometry(fs, 55,boxLayer->width()-10-fs, 20);
  valueSamplerate->setGeometry(fs, 75,boxLayer->width()-10-fs, 20);
  valueBitrate   ->setGeometry(fs, 95,boxLayer->width()-10-fs, 20);
  valueStereo    ->setGeometry(fs,115,boxLayer->width()-10-fs, 20);
  valueLayer     ->setGeometry(fs,135,boxLayer->width()-10-fs, 20);
  valuePlayed    ->setGeometry(fs,155,boxLayer->width()-10-fs, 20);
  valueLastPlayed->setGeometry(fs,175,boxLayer->width()-10-fs, 20);

  boxPrivate->setGeometry( 5,360,width()-10, 65);
  catFirstSeconds ->setGeometry( 10, 15, fb, 20);
  catLastSeconds  ->setGeometry( 10, 35, fb, 20);
  valueFirstSeconds ->setGeometry( fs, 15, 40, 20);
  valueLastSeconds  ->setGeometry( fs, 35, 40, 20);

  acceptButton ->setGeometry(10,height()-35,80,30);
  applyButton  ->setGeometry(((width()/2)-40),height()-35,80,30);
  cancelButton ->setGeometry(width()-90,height()-35,80,30);
}






