/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#ifndef MP3_H
#define MP3_H

#include "kjukebox.h"
#include <stdio.h>
#include <stdlib.h>

#define STD_BUF_LEN 2048 
#define FILENAME_LEN 1024
/* MPEG Header Definitions - Mode Values */

#define         MPG_MD_STEREO           0
#define         MPG_MD_JOINT_STEREO     1
#define         MPG_MD_DUAL_CHANNEL     2
#define         MPG_MD_MONO             3

#define         MPG_MD_LR_LR             0
#define         MPG_MD_LR_I              1
#define         MPG_MD_MS_LR             2
#define         MPG_MD_MS_I              3

/* ID3 TAG Format, Space-filled (grr) */

typedef struct {
    char tag[3];
    char title[30];
    char artist[30];
    char album[30];
    char year[4];
    char comment[30];
    unsigned char genre;
} tag;



class Tag {
 private:
  void safecopy(char* , char* , int );
  void spacecopy(char *, char *, int );
  public:
  char title[31];
  char artist[31];
  char album[31];
  char year[5];
  char comment[31];
  char genre[31];
  int gennum;

  Tag();
  void clear();
  bool scan(FILE * file);
  bool saveTags(FILE * file);
};

class Layer {
 public:
  int version;
  int lay;
  int error_protection;
  int bitrate_index;
  int sampling_frequency;
  int padding;
  int extension;
  int mode;
  int mode_ext;
  int copyright;
  int original;
  int emphasis;
  int stereo;
  unsigned int filelength;
  unsigned int seconds;

  Layer();
  bool scan(FILE * file);
  char *mode_name();
  char *layer_name();
  int   layer();
  char *version_name();
  char *version_num();
  unsigned int bitrate();
  unsigned int sfreq();
};


class MP3 {
 private:
  Tag *tag;
  Layer *layer;
  bool hastag;
  bool haslayer;
  char *format;
  FILE *file;
  size_t filelength;
  char filename[FILENAME_LEN];
  bool open(const char *name, bool forSave);
  bool openForSave(const char *name);
 public:
  MP3(); 
  ~MP3();

  bool open(const char *name);
  bool saveTags();
  bool initfile(bool gettag=1);
  Song getSong();
  void close();
  bool saveCommentTag(const char *, const char *);
};



#endif //MP3_H
