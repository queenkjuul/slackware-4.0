/*
  a FFT filter
  Copyright (C) 1998  Martin Vogt;Philip VanBaren, 2 September 1993

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <filter/realFFTFilter.h>

RealFFTFilter::RealFFTFilter() {
  points = 256;
  data=new short[points];  
  realFFT= new RealFFT(points);
}


RealFFTFilter::~RealFFTFilter() {
  delete data;
  delete realFFT;
}


int RealFFTFilter::getPoints() {
  return points;
}


short* RealFFTFilter::getPointPtr() {
  return data;
}


/*
  the array is expected to be a PCM stream (real data)
*/
void RealFFTFilter::fft16(DeviceConfig* input,short* aPoints) {
  int i;
  int j;

  AudioInfo* audioInfo=input->getAudioInfo();

  int stereo=audioInfo->getStereo();
  short* shortPtr=aPoints;
  int mixTmp;

  if (stereo == 1) {
    for (i = 0, j = 0; i < points; i++, j+=2) {
      mixTmp=(shortPtr[j]+shortPtr[j+1])/2;
      if (mixTmp < SHRT_MIN) {
	data[i]= SHRT_MIN; 
      } else {
	if (mixTmp > SHRT_MAX) {
	  data[i] = SHRT_MAX; 
	} else {
	  data[i]=(short)mixTmp;
	}
      }
    }
  }
  realFFT->fft(data);
}



int* RealFFTFilter::getBitReversed() { 
  return realFFT->getBitReversed();
}




