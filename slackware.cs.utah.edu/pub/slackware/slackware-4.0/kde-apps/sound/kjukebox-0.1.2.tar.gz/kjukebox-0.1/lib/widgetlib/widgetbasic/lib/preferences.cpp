/*
  generic preferences dialog
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <preferences.h>



Preferences::Preferences(QWidget * parent=0,const char * name=0 )
  :QTabDialog(parent,name) {
  setApplyButton();
  setCancelButton();
  setOkButton();
  setMaximumSize(400,450);
  setMinimumSize(400,450);
  
}


Preferences::~Preferences() {
}


void Preferences::addTab(PrefConfig* prefConfig,const char* name) {
  connect(this,SIGNAL(applyButtonPressed()),
	  prefConfig,SLOT(apply()));
  QTabDialog::addTab(prefConfig,name);
}




