/*
  a nicer widget for the volume.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */






#ifndef __VOLUMEWIDGET_H
#define __VOLUMEWIDGET_H

#include <kslider.h>
#include <guiVolumeDevice.h>

/**
   This widget show how you can add your own look and feel.
   Simple overwrite the paint method.

*/

class VolumeWidget : public GuiVolumeDevice {

  KSlider *slider;

 public:
   VolumeWidget( QWidget *parent=0, const char *name=0 );
  ~VolumeWidget();

  void buildGui();
  QSize sizeHint ();

 

};
#endif
