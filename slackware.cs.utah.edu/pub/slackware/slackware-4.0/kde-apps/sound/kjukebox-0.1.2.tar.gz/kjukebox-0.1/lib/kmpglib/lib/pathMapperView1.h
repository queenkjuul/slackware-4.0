/*
  a view for a pathMapper.
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#ifndef __PATHMAPPERVIEW1_H
#define __PATHMAPPERVIEW1_H

#include <pathMapper.h>
#include <qlistbox.h>
#include <qpainter.h>


class PathMapperView1 : public QListBoxItem {

   public:
      PathMapperView1(PathMapper* pathMapper);
      ~PathMapperView1();

   protected:
      void paint( QPainter* );
      int height( const QListBox* ) const;
      int width( const QListBox* ) const;
   private:
      PathMapper* pathMapper;
};


#endif
