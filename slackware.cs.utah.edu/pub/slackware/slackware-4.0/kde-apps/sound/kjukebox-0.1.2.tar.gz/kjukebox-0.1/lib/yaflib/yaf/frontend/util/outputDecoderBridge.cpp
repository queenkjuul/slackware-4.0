/*
  compiler bug workaround
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <util/outputDecoderBridge.h>




OutputDecoderBridge::OutputDecoderBridge(struct YafClient* client) {
  this->client=client;
}


OutputDecoderBridge::~OutputDecoderBridge() {
}



int OutputDecoderBridge::processRuntimeCommand(int command,char* args) {
  client->processRuntimeCommand(command,args);
  return 1;
}



int OutputDecoderBridge::processReturnCommand(int cmdNr,int cmdId,
					      char* ret,char* args) {
  client->processReturnCommand(cmdNr,cmdId,ret,args);
  return 1;
}


