/*
  a default standalone player.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __PLAYERFACTORY_H
#define __PLAYERFACTORY_H

#include <kmpgRootWindow.h>
#include <amplifier/amplifier.h>

class PlayerFactory {


 public:
  PlayerFactory();
  ~PlayerFactory();

  static KmpgRootWindow* createKmpgRootWindow(int playerType);


};


#endif
