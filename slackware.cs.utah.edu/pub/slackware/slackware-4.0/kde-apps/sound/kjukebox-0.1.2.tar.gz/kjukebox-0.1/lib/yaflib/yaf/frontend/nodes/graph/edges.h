/*
  stores Nodedevices
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef _EDGES_H
#define _EDGES_H

#include <devices/nodeDevice.h>

#define _EDGES_MAX 20

class Edges {

  int elements;
  struct NodeDevice* nodeDeviceArray[_EDGES_MAX];
  
 public:

  Edges();
  ~Edges();

  int getElements();
  void setElements(int elements);
  void clear();

  struct NodeDevice* getNodeDevice(int element);
  void setNodeDevice(int pos,struct NodeDevice* nodeDevice);

};


#endif
