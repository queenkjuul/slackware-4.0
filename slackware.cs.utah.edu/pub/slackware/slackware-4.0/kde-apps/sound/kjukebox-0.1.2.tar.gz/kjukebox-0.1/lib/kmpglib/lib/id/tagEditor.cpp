/* tagEditor.cpp

  Created by SMF aka Antoine Laydier (laydier@usa.net)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

/*=============================================================================
  HEADERs
 =============================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

#include <qmsgbox.h>

#include <klocale.h>
#include <kapp.h>
#
#include "tagEditor.h"
//#include "tagEditor.moc"

/*=============================================================================
  #DEFINEs
=============================================================================*/
#define ktr           klocale->translate

/*=============================================================================
  GLOBALs
=============================================================================*/
extern int      errno;

/*=============================================================================
 Class : TagEditor (methods)
=============================================================================*/

/*-----------------------------------------------------------------------------
  Routine : TagEditor::TagEditor (constructor)
-----------------------------------------------------------------------------*/
TagEditor::TagEditor(QWidget *parent = 0, const char *name = 0)
        :QDialog( parent, name, FALSE)
{
  int i;
  layer =new Layer;
  tag = new Tag;
  fileList = new QStrList(TRUE);
   
  QString tmp;

  setStyle(WindowsStyle);
  setCaption( ktr("MP3 Tag Editor") );

  // Modified by SMF 10/17/98
  setFixedSize(465,300);

  // Added by SMF 10/17/98
  lFilename = new QLabel( ktr("File"), this);
  lFilename->setGeometry(15,5,100,25);

  accessDesc = new QLabel( ktr("full access:"), this);
  accessDesc->setGeometry(15,23,100,25);

  accessLabel = new QLabel( ktr("ok"), this);
  accessLabel->setGeometry(115,23,340,25);

  slFilename = new QScrLabel(this);
  slFilename->setGeometry(115,5,340,25);

  // Modified by SMF 10/17/98
  CBtitle = new QCheckBox(ktr("Title"), this);
  CBtitle->setGeometry(15,50,100,25);
  leTitle = new QLineEdit(this,"leTitle");
  leTitle->setGeometry(115,50,345,25); 
  leTitle->setMaxLength(30);

  CBartist = new QCheckBox(ktr("Artist"), this);
  CBartist->setGeometry(15,90,100,25); 
  leArtist = new QLineEdit(this,"leArtist");
  leArtist->setGeometry(115,90,345,25); 
  leArtist->setMaxLength(30);

  CBalbum = new QCheckBox(ktr("Album"), this);
  CBalbum->setGeometry(15,130,100,25);  
  leAlbum = new QLineEdit(this,"leAlbum");
  leAlbum->setGeometry(115,130,345,25); 
  leAlbum->setMaxLength(30);
 
  CByear = new QCheckBox(ktr("Year"), this);
  CByear->setGeometry(15,170,100,25);  
  leYear = new QLineEdit(this,"leYear");
  leYear->setGeometry(115,170,60,25); 
  leYear->setMaxLength(4);

  CBgenre = new QCheckBox(ktr("Genre"), this);
  CBgenre->setGeometry(210,170,100,25);  
  cbGenre = new QComboBox(FALSE, this, "cbGenre");
  cbGenre->setGeometry(305,170,150,25); 

  CBcomment = new QCheckBox(ktr("Comment"), this);
  CBcomment->setGeometry(15,210,100,25);  
  leComment = new QLineEdit(this,"leComment");
  leComment->setGeometry(115,210,345,25); 
  leComment->setMaxLength(30);

  // init GENRE Combox Box ...
  // Modified by SMF 17/10/98
  for(i=0;i<= Tag::genre_largest;i++) 
    cbGenre->insertItem(Tag::genres[i],i);
  
  // Buttons ...
  bPrev = new QPushButton(ktr("&Previous"), this, "bPrev");
  connect(bPrev, SIGNAL(clicked()), this, SLOT(bPrevActivated()));

  bNext = new QPushButton(ktr("&Next"), this, "bNext");
  connect(bNext, SIGNAL(clicked()), this, SLOT(bNextActivated()));

  bReset = new QPushButton(ktr("&Reset"), this,"bReset");
  connect(bReset,SIGNAL(clicked()), this, SLOT(bResetActivated()));

  bSet = new QPushButton(ktr("&Set"), this, "bSet");
  connect(bSet,SIGNAL(clicked()), this, SLOT(bSetActivated()));

  bClose = new QPushButton(ktr("&Close"), this, "bClose");
  connect(bClose, SIGNAL(clicked()), this, SLOT(accept()));

  // disable all widgets...
  cbGenre->setEnabled(FALSE);
  leTitle->setEnabled(FALSE);
  leArtist->setEnabled(FALSE);
  leAlbum->setEnabled(FALSE);
  leYear->setEnabled(FALSE);
  leComment->setEnabled(FALSE);
  bSet->setEnabled(FALSE);
  bReset->setEnabled(FALSE);

  bPrev->setEnabled(FALSE);
  bPrev->hide();
  bNext->setEnabled(FALSE);
  bNext->hide();

  installEventFilter(this);
  placeWidgets();
}


/*-----------------------------------------------------------------------------
  Routine : TagEditor::~TagEditor() (destructor)
	    writes back config entries (current)
-----------------------------------------------------------------------------*/
TagEditor::~TagEditor()
{  
  delete lFilename;
  delete slFilename;
  delete bReset;
  delete bSet;
  delete bClose;
  delete bNext;
  delete bPrev;
  delete CBtitle;
  delete CBartist;
  delete CBalbum;
  delete CByear;
  delete CBgenre;
  delete CBcomment;
  delete cbGenre;
  delete leTitle;
  delete leArtist;
  delete leAlbum;
  delete leComment;
  delete leYear;
  delete fileList;
  delete layer;
  delete tag;
}

/*-----------------------------------------------------------------------------
  Routine : TagEditor::placeWidgets
-----------------------------------------------------------------------------*/
void TagEditor::placeWidgets( void )
{
  int w = width();
  int h = height();

  // Button Open, Prev, Next
  bClose->setGeometry(w - 85, h -41, 75, 26);
  bSet->setGeometry(w - 165, h -41, 75, 26);
  bReset->setGeometry(w - 245, h -41, 75, 26);

  bPrev->setGeometry(10, h -41, 75, 26);
  bNext->setGeometry(85, h -41, 75, 26);

  // Tag Editor
  leTitle->resize(w-15-110,25);
  leArtist->resize(w-15-110,25);
  leAlbum->resize(w-15-110,25);
  leComment->resize(w-15-110,25);
}


/*-----------------------------------------------------------------------------
  Routine : TagEditor::resizeEvent
-----------------------------------------------------------------------------*/
void TagEditor::resizeEvent(QResizeEvent *ev)
{
  QDialog::resizeEvent(ev);

  placeWidgets();
}



/*-----------------------------------------------------------------------------
  Routine :  TagEditor::bNextActivated
-----------------------------------------------------------------------------*/
void TagEditor::bNextActivated( void )
{ 
 fileList->at(fileList->at()+1);
 bPrev->setEnabled(TRUE);
 if(fileList->at() == (int)(fileList->count()-1) )
   bNext->setEnabled(FALSE);
 open();
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::bPrevActivated
-----------------------------------------------------------------------------*/
void TagEditor::bPrevActivated( void )
{ 
 fileList->at(fileList->at()-1);
 bNext->setEnabled(TRUE);
 if(fileList->at() == 0) bPrev->setEnabled(FALSE);
 open();
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::bResetActivated
-----------------------------------------------------------------------------*/
void TagEditor::bResetActivated( void )
{ 
 Reset();
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::bSetActivated
-----------------------------------------------------------------------------*/
void TagEditor::bSetActivated( void )
{ 
 Set();
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::Reset
-----------------------------------------------------------------------------*/
void TagEditor::Reset( void )
{ 
 readTag(bSet->isEnabled());
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::Set
-----------------------------------------------------------------------------*/
int TagEditor::Set( void )
{ 
  tag->setTitle(leTitle->text());
  tag->setAlbum(leAlbum->text());
  tag->setArtist(leArtist->text());
  tag->setYear(leYear->text());
  tag->setComment(leComment->text());
  tag->setGenre(cbGenre->currentItem());
  tag->set(fileList->current());
 
  // Added by CP 10.10.1998
  if( playIndex == (uint) fileList->at() )
    emit tagChanged();

  return 0;
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::Open
-----------------------------------------------------------------------------*/
int TagEditor::open( void )
{ 
  char *  fileName;
  FILE *  fd2;
  bool    rw = TRUE;
  
  if(! fileList->isEmpty());

  fileName = fileList->current();
  accessLabel->setText("ok");
  if(!fileName) return 1; 

  fd2 = 0;
  fd2 = fopen(fileName, "r+");
  if(!fd2) {
    accessLabel->setText(sys_errlist[errno]);
    rw = FALSE;
    fd2 = fopen(fileName, "r");
    if(!fd2) {
      accessLabel->setText(sys_errlist[errno]);
      return 1;
    }
  }
  if(layer->get(fileName) == true) {
    // read Informations and Tag ...
    readTag(rw);
    // Added by SMF 10/17/98
    slFilename->setLabel(fileName);
    bSet->setEnabled(rw);
    bReset->setEnabled(TRUE);
  }
  fclose(fd2);
  return 0;
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::readTag
-----------------------------------------------------------------------------*/
void  TagEditor::readTag ( bool rw )
{
  hasTag= tag->get(fileList->current());
  cbGenre->setEnabled(rw);
  if(!CBgenre->isChecked())
    // Modified by SMF 17/10/98
    cbGenre->setCurrentItem(
      tag->getGenreNum()>=Tag::genre_largest ? 
      Tag::genre_largest : tag->getGenreNum());
  leTitle->setEnabled(TRUE);
  if(!CBtitle->isChecked())
    leTitle->setText(tag->getTitle());
  leArtist->setEnabled(TRUE);
  if(!CBartist->isChecked())
    leArtist->setText(tag->getArtist());
  leAlbum->setEnabled(TRUE);
  if(!CBalbum->isChecked())
    leAlbum->setText(tag->getAlbum());
  leYear->setEnabled(TRUE);
  if(!CByear->isChecked())
    leYear->setText(tag->getYear());
  leComment->setEnabled(TRUE);
  if(!CBcomment->isChecked())
    leComment->setText(tag->getComment());
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::setFile
-----------------------------------------------------------------------------*/
void TagEditor::setFile(const char * filename) 
{
  delete fileList;
  fileList = new QStrList(TRUE);
  fileList->append(filename);
}


/*-----------------------------------------------------------------------------
  Routine :  TagEditor::setFile
-----------------------------------------------------------------------------*/
void TagEditor::setFiles(const QStrList & filenames)
{
  delete fileList;
  fileList = new QStrList(filenames);
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::at
-----------------------------------------------------------------------------*/
void TagEditor::at(uint index)
{
  playIndex= index;
  fileList->at(index);
  open();
}

/*-----------------------------------------------------------------------------
  Routine :  TagEditor::show
-----------------------------------------------------------------------------*/
void TagEditor::show ()
{
  uint memo = fileList->at();
  if(fileList->count() > 1) {
    bPrev->show();
    if(memo > 0) bPrev->setEnabled(TRUE);
    bNext->show();
    if(memo < (fileList->count()-1)) bNext->setEnabled(TRUE);
  }
  QDialog::show();
  at(memo);
}


int TagEditor::hasValidTag(){
  return hasTag;
}
