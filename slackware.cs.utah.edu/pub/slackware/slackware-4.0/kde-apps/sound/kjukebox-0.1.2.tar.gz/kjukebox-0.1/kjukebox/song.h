/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/


#ifndef SONG_H
#define SONG_H

#include <qstring.h>

/* The Format for fromString:  */
/* Titel|Artist|Album|Year|Comment|Genre|Layer|Bitrate|... */
/*     ...Samplarate|Stereo|Time|Filename|Size|Lastplayed| */

#define saveLoadFormat "TI|AR|AL|YE|CO|GE|SE|FS|LS|BI|SA|ST|LA|SI|FN"
#define saveLoadTrennzeichen "|"


class Song {
private:    
  QString title;
  QString artist;
  QString album;
  QString comment;
  QString genre;
  QString filename;
  QString stereomode;
  QString layer;
  bool   played;
  unsigned int lastplayed;
  unsigned int samplerate;
  unsigned int bitrate;
  unsigned int year;
  unsigned int seconds;
  unsigned int firstSeconds;
  unsigned int lastSeconds;  
  unsigned int size;
  QString asQString(unsigned int );
public:
  Song();
  QString asString();
  QString asString(QString, QString);
  void initFromString(QString);
  void initFromString(QString, QString, QString);
  void checkForPlausibility();
  void checkForPlausibility(QString);
  void setTitle(QString);
  void setArtist(QString);
  void setAlbum(QString);
  void setComment(QString);
  void setGenre(QString);
  void setFilename(QString);
  void setStereomode(QString);
  void setLayer(QString);
  void setPlayed(bool );
  void setLastPlayed(unsigned int );
  void setSamplerate(unsigned int );
  void setBitrate(unsigned int );
  void setYear(unsigned int );
  void setSeconds(unsigned int );
  void setFirstSeconds(unsigned int );
  void setLastSeconds(unsigned int );
  void setSize(unsigned int );
  QString getTitle() const;
  QString getArtist() const;
  QString getAlbum() const;
  QString getComment() const;
  QString getGenre() const;
  QString getFilename() const;
  QString getStereomode() const;
  QString getLayer() const;
  bool   getPlayed() const;
  unsigned int getLastPlayed() const;
  unsigned int getSamplerate() const;
  unsigned int getBitrate() const;
  unsigned int getYear() const;
  unsigned int getSeconds() const;
  unsigned int getFirstSeconds() const;
  unsigned int getLastSeconds() const;
  unsigned int getSize() const;
  bool operator== (Song);
};


#endif 
