#ifndef __VOLUME_H
#define __VOLUME_H

#include<qobject.h>


typedef struct stereovolume{
        unsigned char left;
        unsigned char right;
} StereoVolume;


class Volume : public QObject
{
  Q_OBJECT
 
  public:
    Volume();

    int getVolume();

  public slots:
    void setVolume( int volume );


  private:
    void initVol();
    int mixerid;
};

#endif
