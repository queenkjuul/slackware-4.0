/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#include "appwindow.h"

#include <qpopmenu.h>
#include <qkeycode.h>
#include <qlabel.h>
#include <kapp.h>
#include <qfile.h>
#include <kfiledialog.h>
#include <kmsgbox.h>
#include <iostream.h>
#include <fstream.h>

void ApplicationWindow::neu(){
  int i;
  if (dbChanged){
    i = KMsgBox::yesNo(this, i18n("Warning"),i18n("The MP3 Database is not saved!\nDo you realy want to go on?"));
    if(i==2) {
      status->message( i18n("Deleting of the MP3 Database canceled"), 2000 );
      return;
    }
  }
  dbChanged = false;
  mainWidget->clearDataList();
  dateiName = "";
  setTitle();
}

void ApplicationWindow::laden(){
  int i;
  if (dbChanged){
    i = KMsgBox::yesNo(this, i18n("Warning"), i18n("The MP3 Database should be erased!\nDo you realy wan't to go on?"));
    if(i==2) {
      status->message( i18n("Loading of MP3 List aborted"), 2000 );
      return;
    }
  }
  
  mainWidget->clearDataList();    
  dateiName = KFileDialog::getOpenFileName(0,"*.jbd *.JBD",this);
  if ( !dateiName.isEmpty() ) {
    dbChanged = false;
    laden( dateiName );
  }
  else 
    status->message( i18n("Loading of MP3 File aborted"), 2000 );
}

void ApplicationWindow::laden( const char *dateiName ){
  QString s;
  ifstream file( dateiName, ios::in );
  
  if ( file )  { 
    file.close();
    mainWidget->addSongs(ioaccess.load(dateiName));
    s.sprintf(i18n("File %s loaded."), dateiName);
  }
  else {
    s.sprintf(i18n("Error while Loading the file %s !!!"), dateiName);
  }
  status->message( s, 2000 );
  setTitle();
}

void ApplicationWindow::speichern(){
  //  cout << "dateiname:" << dateiName << endl;
  if(dateiName.isEmpty()) speichernAls();
  else speichern(dateiName);
}

void ApplicationWindow::speichern(QString datei){
  QString s;

  ofstream file(datei,ios::out|ios::trunc);
  if (file) {
    if (ioaccess.save(datei,mainWidget->getAllSongs())){
      s.sprintf(i18n("File %s saved."), datei.data());  
      dbChanged = false;
    }
  }
  else 
    s.sprintf(i18n("Error at writing the file %s !!!"), datei.data() );

  file.close();  
  status->message( s, 2000 );  
}


void ApplicationWindow::speichernAls(){
  dateiName = KFileDialog::getSaveFileName(0,"*.jbd *.JBD",this);
  if ( !dateiName.isEmpty() )
    speichern( dateiName );
  else
    status->message( i18n("Writing of MP3 List aborted!"), 2000 );
  setTitle();
}

void ApplicationWindow::importMP3Datei(){
  QString fn = KFileDialog::getOpenFileName(0,"*.MP3 *.mp3",this);
  if ( !fn.isEmpty() )
      mainWidget->addSong(ioaccess.importMP3File( fn ));
  else
    status->message( i18n("Loading of MP3 List aborted!"), 2000 );
}

void ApplicationWindow::importMP3Liste(){
  QString fn = KFileDialog::getOpenFileName(0,"*",this);
  if ( !fn.isEmpty() ){    
    mainWidget->addSongs(ioaccess.importMP3FileList( fn ));
  }
  else
    status->message( i18n("Loading of MP3 List aborted!"), 2000 );
}

void ApplicationWindow::importM3uListe(){
  QString fn = KFileDialog::getOpenFileName(0,"*.m3u *.M3U",this);
  if ( !fn.isEmpty() ){    
    mainWidget->addSongs(ioaccess.importM3uFileList( fn ));
  }
  else
    status->message( i18n("Loading of MP3 List aborted!"), 2000 );
}

void ApplicationWindow::exportMP3Liste(){
  QString filename;
  filename = KFileDialog::getSaveFileName(0,"*",this);
  if ( !filename.isEmpty() )
    if(ioaccess.exportMP3List(filename, mainWidget->getAllSongs())){
      status->message( "MP3-Liste gespeichert", 2000 );
      return;
    }
  status->message( i18n("Saving of MP3 List aborted!"), 2000 );
}

void ApplicationWindow::exportM3uListe(){
  QString filename;
  filename = KFileDialog::getSaveFileName(0,"*.m3u",this);
  if ( !filename.isEmpty() )
    if(ioaccess.exportM3uList(filename, mainWidget->getAllSongs())){
      status->message( i18n("MP3 List saved"), 2000 );
      return;
    } 
  status->message( i18n("Saving of M3u List aborted!"), 2000 );
}



void ApplicationWindow::databaseChanged(){  dbChanged = true; }

void ApplicationWindow::quitKJukeBox(){
  int i;
  if (dbChanged){
    i = KMsgBox::yesNoCancel(this, i18n("Warning"),i18n("The MP3 List has been modified!\nWould you like to save it?"));
    if(i==1) speichern();
    if(i==3) {
      status->message( i18n("Loading of a new MP3 List aborted"), 2000 );
      return;
    }
  }
  (KApplication::getKApplication())->quit();
}

/*
  Ab hier kommen nur noch Funktionen fuer die Player
*/

void ApplicationWindow::initializePlayer(){
  //Setup Player and Decoder

  pausing = new bool[3];
  pausing[PLAYER1] = false;
  pausing[PLAYER2] = false;
  playing = new bool[3];
  playing[PLAYER1] = false;
  playing[PLAYER2] = false;
  
  decoder1= Amplifier::createPlayer(_MP3_DECODER);
  decoder2= Amplifier::createPlayer(_MP3_DECODER);
  decoder = new (GenericPlayer*)[3];
  decoder[PLAYER1] = decoder1;
  decoder[PLAYER2] = decoder2;

  multicastDevice1 = new MulticastDevice();
  multicastDevice2 = new MulticastDevice();

  streamInfoDevice1 = new StreamInfoDevice();
  streamInfoDevice2 = new StreamInfoDevice();
  streamInfoDevice  = new (StreamInfoDevice*)[3];
  streamInfoDevice[PLAYER1] = streamInfoDevice1;
  streamInfoDevice[PLAYER2] = streamInfoDevice2;

  multicastDevice1->addListener(streamInfoDevice1);
  multicastDevice2->addListener(streamInfoDevice2);

  cout << "PLAYER: " << PLAYER2 << "  TIMER:" << timer[PLAYER2] << endl;
  multicastDevice2->addListener(timer[PLAYER2]->getDevice());
  cout << "PLAYER: " << PLAYER1 << "  TIMER:" << timer[PLAYER1] << endl;
  multicastDevice1->addListener(timer[PLAYER1]->getDevice());


  volumeDevice = new (VolumeDevice*)[3];
  volumeDevice1 = new VolumeDevice();
  volumeDevice[PLAYER1] = volumeDevice1;
  volumeDevice2 = new VolumeDevice();
  volumeDevice[PLAYER2] = volumeDevice2;
  multicastDevice1->addListener(volumeDevice1);
  multicastDevice2->addListener(volumeDevice2);
  timer1->setVolumeDevice(volumeDevice1);
  timer2->setVolumeDevice(volumeDevice2);
  timer1->setFadeSpeed(10);
  timer2->setFadeSpeed(10);
  

  // now setup the mixer
  mixer=new MixerDevice();
  volumeDevice1->addListener(mixer);
  volumeDevice2->addListener(mixer);

  //Setup Audio Device
  config->setGroup(KCONFIG_PLAYER);
  audioDevice = new AudioDevice(config->readEntry(KCONFIG_PLAYER_DEVICE,"/dev/dsp")); 
  mixer->addListener(audioDevice);
  audioDevice->open(); 

  decoder1->addListener(multicastDevice1);
  decoder2->addListener(multicastDevice2);
  
  connect(decoder1->getEventQueue(),SIGNAL(processEvent(char)),
	  this,SLOT(decoder1Event(char)));
  connect(decoder2->getEventQueue(),SIGNAL(processEvent(char)),
	  this,SLOT(decoder2Event(char)));
}

void ApplicationWindow::playSongs(int player){
  QString text;
  Songs songs;
  Song  song;
  bool defaultTime;
  bool enableMixing;
  unsigned int firstSeconds;
  unsigned int lastSeconds;
  if ((playing[player])&&(!(pausing[player]))) return;
  if(pausing[player]) {
    playerPause(player);
    return;
  }

  config->setGroup(KCONFIG_PLAYER);
  defaultTime  = config->readBoolEntry(KCONFIG_PLAYER_DEFAULTTIME,true);
  enableMixing = config->readBoolEntry(KCONFIG_PLAYER_MIXING,true);

  if(shufflePlaying)
    songs = mainWidget->getRandomListOfSongsToPlay();
  else 
    songs = mainWidget->getFirstSongsToPlay();

  if (songs.size() >=1){
    song = *(songs.begin());
    /* Setup the Timer to start the next Song */
    /* Old code of Version 0.1.1 */
//     if (defaultTime) {
//       lastSeconds = config->readUnsignedNumEntry(KCONFIG_PLAYER_LASTSECONDS,7);
//       firstSeconds = config->readUnsignedNumEntry(KCONFIG_PLAYER_FIRSTSECONDS,0);
//     }
//     else {
//       lastSeconds = song.getLastSeconds();
//       firstSeconds = song.getFirstSeconds();
//     }
//     if((lastSeconds<0)  || (lastSeconds>=song.getSeconds()))  lastSeconds = 0;
//     if((firstSeconds<0) || (firstSeconds>=song.getSeconds())) firstSeconds = 0;


    lastSeconds = config->readUnsignedNumEntry(KCONFIG_PLAYER_LASTSECONDS,7);
    firstSeconds = config->readUnsignedNumEntry(KCONFIG_PLAYER_FIRSTSECONDS,0);
    if (!defaultTime){ // if not alway use default settings
      if(song.getLastSeconds()  != 0) lastSeconds  = song.getLastSeconds();
      if(song.getFirstSeconds() != 0) firstSeconds = song.getFirstSeconds();
    }
      
    //    cout << "LS:" << lastSeconds << "  FS:" << firstSeconds << endl;

    if((enableMixing)&&(lastSeconds != 0))
      timer[player]->setAlarmTime(song.getSeconds()- lastSeconds);
    else 
      timer[player]->clearAlarmTime();

    timer[player]->setVolume(100);
    timer[player]->setFadeOut(false);

    volumeDevice[player]->setVolume(100);
    if (config->readBoolEntry(KCONFIG_PLAYER_FADEOUT,true))
      if (lastSeconds != 0) 
	timer[player]->setFadeOut(true);
    
    decoder[player]->open(song.getFilename()); 
    if((enableMixing)&&(firstSeconds != 0))
      decoder[player]->jump(firstSeconds);
    else decoder[player]->play();
    
    /* Setup internal Variables */
    pausing[player] = false;
    playing[player] = true;


    (playingSongName[player]).sprintf("(%s) %s",
				      song.getArtist().data(),
				      song.getTitle().data());
    text.sprintf(i18n("Playing %s"), song.getFilename().data());
    status->message( text, 2000 );    
  }
  else status->message(i18n("All Files are played!!!"),2000);
  refreshSoundToolBar(player);
}


void ApplicationWindow::playerPause(int player){
  if (pausing[player]) {
    pausing[player] = false;
    playing[player] = true;
  }
  else {
    if (!playing[player])  playSongs(player);
    pausing[player] = true;
  }
  decoder[player]->pause();
  refreshSoundToolBar(player);
}

void ApplicationWindow::player1Stop(){ playerStop(PLAYER1); }
void ApplicationWindow::player2Stop(){ playerStop(PLAYER2); }
void ApplicationWindow::playerStop(int player){
  decoder[player]->close();
  pausing[player] = false;
  playing[player] = false;
  refreshSoundToolBar(player);
}
 
void ApplicationWindow::playNext(int player){
  playing[player] = false;
  pausing[player] = false;
  playSongs(player);
}

void ApplicationWindow::skipForward(int player){
  int seconds;
  seconds = streamInfoDevice[player]->getTimeInfo()->getTotalSec();
  seconds += 10;  
  if (seconds > streamInfoDevice[player]->getMusicInfo()->getLen()) {
    playNext(player);
    return;
  }
  decoder[player]->jump(seconds);    
}

void ApplicationWindow::skipBackward(int player){
  int seconds;
  seconds = streamInfoDevice[player]->getTimeInfo()->getTotalSec();
  seconds -= 10;  
  if (seconds < 0) seconds = 0;
  decoder[player]->jump(seconds);    
}


void ApplicationWindow::decoder1Event(char event){
  decoderEvent(PLAYER1,event);
}
void ApplicationWindow::decoder2Event(char event){
  decoderEvent(PLAYER2,event);
}
void ApplicationWindow::decoderEvent(int player,char event){
  if (event == _GS_SIGNAL_PLAYING_READY) decoderStopedPlaying(player);
  if (event == _GS_SIGNAL_GENERATOR_CRASHED) decoderCrashed(player);
}  

void ApplicationWindow::decoderStopedPlaying(int player){
  playing[player] = false;
  pausing[player] = false;
  cout << "Player " << player << " ready, start next song " << endl;
  if (player == PLAYER1){
    if (!playing[PLAYER2]) playNext(PLAYER2);
  }
  else {
    if (!playing[PLAYER1]) playNext(PLAYER1);
  }
  refreshSoundToolBar(player);
}

void ApplicationWindow::decoderCrashed(int player){
  QString text;
  text = "Player ";
  text += player;
  text += " crashed";
  status->message( text, 2000 );
  KMsgBox::message(this,i18n("Error, Player Crashed"),text);

}

void ApplicationWindow::timerAlarm(int player){
  QString text;
  text = i18n("Play next Song on Player ");
  text += player;
  timer[player]->clearAlarmTime();
  //  KMsgBox::message(this,i18n("Play next Song"),text);
  cout << "Player " << player << " ready, start next song " << endl;
  if (player == PLAYER1){
    if (!playing[PLAYER2]) playNext(PLAYER2);
  }
  else {
    if (!playing[PLAYER1]) playNext(PLAYER1);
  }
  refreshSoundToolBar(player);
}

void ApplicationWindow::timer1Alarm(){
  timerAlarm(PLAYER1);
}

void ApplicationWindow::timer2Alarm(){
  timerAlarm(PLAYER2);
}

 
