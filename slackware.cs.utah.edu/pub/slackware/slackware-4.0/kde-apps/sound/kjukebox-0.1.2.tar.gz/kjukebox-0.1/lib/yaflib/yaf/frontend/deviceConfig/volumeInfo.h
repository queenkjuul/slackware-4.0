/*
  stores the volume information for a stream
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __VOLUMEINFO_H
#define __VOLUMEINFO_H

#include <iostream.h>
#include <deviceConfig/info.h>


class VolumeInfo : public Info  {

  float leftVolume;
  float rightVolume;

 public:
  VolumeInfo();
  ~VolumeInfo();

  void setVolume(float percent);

  void setLeftVolume(float percent);
  float getLeftVolume();

  void setRightVolume(float percent);
  float getRightVolume();

  // returns true if both AudioInfos are the same
  int equals(VolumeInfo* aInfo);
  void copyTo(VolumeInfo* aInfo);

  void print();
  
};



#endif



