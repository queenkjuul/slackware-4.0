/*
  a FFT filter
  Copyright (C) 1998  Martin Vogt;Philip VanBaren, 2 September 1993

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __REALFFTFILTER_H
#define __REALFFTFILTER_H



#include <filter/filter.h>
#include <util/realFFT.h>



/**
  I know nothing about FFT. This thing is a hack from the source code
  of Philip VanBaren's freq5 package. 
  
  I think this spa could be improved.
  Any FFT guru out there ?
*/

  

class RealFFTFilter : public Filter {
  
  int points;
  RealFFT* realFFT;

  short* data;


 public:
  RealFFTFilter();
  ~RealFFTFilter();
  void fft16(DeviceConfig* input,short* points);
  int* getBitReversed();
  int getPoints();
  short* getPointPtr();
};


#endif
