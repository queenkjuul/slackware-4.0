/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#include "timer.h"



Timer::Timer( QWidget *parent=0, const char *name=0 ):
  GuiDeviceCore( parent, name ) {

  led=new LED();
  timeString=new Buffer(10);
  volumeDevice = NULL;
  streamInfoDevice=new StreamInfoDevice();
  streamInfoDevice->setEventMask(_STREAMINFO_STATUS_CHANGE |
				 _STREAMINFO_TIME_CHANGE   |
				 _STREAMINFO_MUSIC_CHANGE );
  //  streamInfoDevice->getEventQueue()->setNotifyMode(_NOTIFY_NO);
  //  streamInfoDevice->getEventQueue()->setNotifyMode(_NOTIFY_ALL);

  connect(streamInfoDevice->getEventQueue(),SIGNAL(processEvent(char)),
	  this,SLOT(playerStatusChanged(char)));

  setDevice(streamInfoDevice);

  setMinimumSize( sizeHint() );
  setMaximumSize( sizeHint() );

  setTimeMode(_TIMEMODE_PLAYED);
  alarmTime    = -1;
  startTimer(400);
  volume       = 100;
  fadeSpeed    =  10;
  fadeOut      = false;
  playerStopped = true;
}

Timer::~Timer(){
  delete streamInfoDevice;
  delete led;
  delete timeString;
}

void Timer::checkAlarmTime(){ 
  static float lauf=0.0;
  int time;
  if (alarmTime == -1) {
    if (!fadeOut) return;
    volume = (int)(cos(lauf)*100.0);
    lauf += (float)fadeSpeed * 0.01;
    //    cout << "Volume:" << volume << endl;
    if (volume <= 0) {
      volume = 0;    
      emit stopPlayer();
      fadeOut = false;
      lauf = 0.0;
    }       
    volumeDevice->setVolume(volume);
  }
  else {
    if (playerStopped) time = 0;
    else time = streamInfoDevice->getTimeInfo()->getTotalSec();
    if(alarmTime <= time) {
      alarmTime = -1;
      emit alarm();
    }
  }
}


void Timer::setVolume(int tmp){ 
  if (tmp > 100) volume = 100;
  else if (tmp <   0) volume = 0;
  else volume = tmp; 
}
void Timer::setFadeSpeed(int tmp){ fadeSpeed = tmp; }
void Timer::setFadeOut(bool tmp){ fadeOut = tmp; }
void Timer::setAlarmTime(int seconds){   alarmTime = seconds; }
void Timer::clearAlarmTime(){   alarmTime = -1;  }
void Timer::setTimeMode(int mode) { mode_cfg=mode; }
int  Timer::getTimeMode() {  return mode_cfg; }

void Timer::setDevice(OutputDevice* device) {
  GuiDeviceCore::setDevice(device);
}


char* Timer::getTimeString() {
  translate(streamInfoDevice->getTimeInfo(),
	    streamInfoDevice->getMusicInfo(),
	    timeString);
  return timeString->getData();
}

void Timer::translate(TimeInfo* timeInfo, MusicInfo* musicInfo,Buffer* dest) {
  if(playerStopped) 
    sprintf(dest->getData(),"0:00");
  else 
    getFormatDec(timeInfo->getTotalSec(),musicInfo->getLen(),dest);
}    

void Timer::getFormatDec(int played,int len,Buffer* dest) {
  int size=dest->getSize();
  char* format1="-%d:%d";
  char* format2="-%d:0%d";
  char* format3="%d:%d";
  char* format4="%d:0%d";
  char* format="";
  int time=played;
  int min;
  int sec;

  if (mode_cfg == _TIMEMODE_REMAIN) time=len-played;

  min=time/60;
  sec=time%60;
  if (sec < 10) {
    if ((mode_cfg == _TIMEMODE_REMAIN) && (time != 0)) format=format2; 
    else format=format4;
  } 
  else {
    if (mode_cfg == _TIMEMODE_REMAIN) format=format1;
    else format=format3;
  }
  dest->clear();
  snprintf(dest->getData(),size,format,min,sec);
}            

    
void Timer::mousePressEvent ( QMouseEvent* mouseEvent) {
  if (mouseEvent->button() ==  LeftButton) {
    if (mode_cfg == _TIMEMODE_PLAYED) mode_cfg = _TIMEMODE_REMAIN;
    else mode_cfg = _TIMEMODE_PLAYED;
    repaint(false);
    return;
  }
}

void Timer::setVolumeDevice(VolumeDevice *device){
  volumeDevice = device;
}

QSize Timer::sizeHint () {
  int w;
  int h;
  QPixmap* pixmap=led->getPixmap(_LED_DIGIT_8);
  w=pixmap->size().width();
  h=pixmap->size().height();
  QSize size(w*4+w/2,h);
  return size;
}

void Timer::playerStatusChanged(char mode){ 
  if (mode == _STREAMINFO_STATUS_CHANGE){
    if( streamInfoDevice->getStatusInfo()->getStatus() == _STATUS_STOPPED) 
      playerStopped = true;
    else 
      playerStopped = false;
  }
}

void Timer::paintEvent ( QPaintEvent * paintEvent ) {
  int i;
  QSize size=sizeHint();
  int x=size.width();
  int y=0;
  char* timeString=getTimeString();
  char currentBst;
  int len=strlen(timeString);
  QPixmap* pixmapCurrent;

  checkAlarmTime();
 
  QPainter paint;
  paint.begin( this );

  for(i=len-1;i>=0;i--) {
    currentBst=timeString[i];
    pixmapCurrent=led->getPixmap(_LED_BLANK);
    if (currentBst == '-') pixmapCurrent=led->getPixmap(_LED_MINUS);
    if (currentBst == ' ') pixmapCurrent=led->getPixmap(_LED_BLANK);
    if (('0' <= currentBst) && (currentBst<= '9')) pixmapCurrent=led->getPixmap(_LED_DIGIT_0+((int)currentBst-(int)'0'));
    if (('A' <= currentBst) && (currentBst<= 'F')) pixmapCurrent=led->getPixmap(_LED_A+((int)currentBst-(int)'A'));
    if (currentBst == ':') pixmapCurrent=led->getPixmap(_LED_DOTS);
    x=x-pixmapCurrent->width();
    paint.drawPixmap(x, y, *pixmapCurrent);
  }

  while(x > 0) {
    pixmapCurrent=led->getPixmap(_LED_COL_RIGHT);
    x=x-pixmapCurrent->width();   
    paint.drawPixmap(x, y, *pixmapCurrent);
  }

  paint.end();  
}



