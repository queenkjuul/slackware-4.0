
//
// If esd is defined compile it 
//

#ifdef SOUND_ESD
  #include <audio/audioIO_ESD.cpp>
#endif



//
// If native sound is defined compiled for that
//
 
#ifdef SOUND_NATIVE

#ifdef OS_AIX 
  #include <audio/audioIO_AIX.cpp>
#endif

#ifdef OS_Linux
  #include <audio/audioIO_Linux.cpp>
#endif

#ifdef OS_BSD
  #include <audio/audioIO_Linux.cpp>
#endif

#if defined(OS_IRIX) || defined(OS_IRIX64)
  #include <audio/audioIO_IRIX.cpp>
#endif

#ifdef OS_HPUX
  #include <audio/audioIO_HPUX.cpp>
#endif

#ifdef OS_SunOS
  #include <audio/audioIO_SunOS.cpp>
#endif

#ifdef __BEOS__
  #include <audio/audioIO_BeOS.cpp>
#endif


#endif
