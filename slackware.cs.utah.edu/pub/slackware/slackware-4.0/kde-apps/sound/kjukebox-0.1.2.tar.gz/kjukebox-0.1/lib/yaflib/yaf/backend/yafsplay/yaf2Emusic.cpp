/*
  functions for an interface between a yafDecoder and the GNOME-emusic Interf.
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */


#include <yafsplay/yaf2Emusic.h>



static InputInterface* input;
static int fd[2];
static player_plugin* plugin;


void setPlugin(player_plugin* aPlugIn) {
  plugin=aPlugIn;
}

                                         
int setup_audio(int frequency, int stereo, int sign, int big, int sixteen) {
  StreamWriter_sendStreamInfo(stereo+1,16,frequency);
  return 1;
}



void set_bitrate(int bit) {
  cout << "set_bitrate called !"<<endl;
}


void close_audio(void) {
}


void flush_audio(void) {
  if (plugin->getStreamState() == _STREAM_STATE_EOF) {
    input->write(fd[1],"off\n");
  }
}


 
int parsebool(char *data) {
  cout << "parsebool called!"<<endl;
  return 1;
}


int audio_play(char *buffer, int size) {
  StreamWriter_writeStream(buffer,size);
  return 1;
}


void setInputInterface(InputInterface* in) {
  input=in;
  ::pipe(fd);
  if (errno < 0) {
    perror("setInputInterface pipe");
    exit(0);
  }
  input->addFileDescriptor(fd[0]);
}


  
                                                

