

#ifndef __SPLAY_CONTROL_H
#define __SPLAY_CONTROL_H


#include <yafcore/inputInterface.h>
#include <yafcore/outputInterface.h>
#include <yafcore/parser.h>


#include <yafsplay/inputDecoderSPlay.h>
#include <yafsplay/yaf2Emusic.h>

#include <stdiostream.h>
#include <yafcore/yaf_control.h>

#include <players/splay/splay.h>



extern "C" {
#include <yafcore/streamWriter.h>
#include <stdio.h>
#ifndef __FreeBSD__
#include <getopt.h>
#else
#include <stdlib.h>
#endif
#include <math.h>
	   }
                              

#endif
