/*
  Copyright (C) 1999 Rainer Maximini

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package
*/

#include <kapp.h>
#include <ktreelist.h> 
#include <kiconloader.h>
#include <qpixmap.h>
#include <stdio.h>
#include "kjukebox.h"
#include "songTree.h"

SongTree::SongTree(QWidget *parent, const char *name)
  :QWidget(parent,name) {
  setupSurface("");
}

SongTree::SongTree(QString bName, QWidget *parent, const char *name)
  :QWidget(parent,name) {
  setupSurface(bName);
}

void SongTree::setupSurface(QString bName){
  selectedIndex = -1;
  setMinimumSize(50,100);
  resize(100,200);

  icon_loader = KApplication::getKApplication()->getIconLoader();                 
  artist_pix = icon_loader->loadMiniIcon("folder.xpm");
  song_pix = icon_loader->loadMiniIcon("syssound.xpm");
 
  if(strcmp(bName,"")==0)
    box = new QGroupBox(this,"box");
  else
    box = new QGroupBox(bName, this,"box");

  songTree = new KTreeList(this,"songs");
  songTree->setIndentSpacing(15);
  songTree->setFocusPolicy(QWidget::ClickFocus);
  
  connect(songTree,SIGNAL(selected(int)),SLOT(doubleClick(int)));
  connect(songTree,SIGNAL(highlighted(int)),SLOT(selectionChanged(int)));
}



void SongTree::selectionChanged(int index){
  QString artist,title;
  SongIterator lauf;

  selectedSongs.clear();
  selectedIndex = index;

  if (songTree->itemAt(index)->hasChild()){
    artist = songTree->itemAt(index)->getText();
    for(lauf=songs.begin(); lauf!=songs.end(); lauf++)
      if(strcmp(artist, lauf->getArtist())==0) {
	selectedSongs.push_back(*lauf);
	selectedSongReference = &(*lauf);
      }
  }
  else {
    artist= songTree->itemAt(index)->getParent()->getText();
    title = songTree->itemAt(index)->getText();
    for(lauf=songs.begin(); lauf!=songs.end(); lauf++)
      if((strcmp(artist, lauf->getArtist())==0) &&
	 (strcmp(title, lauf->getTitle())==0)){
	selectedSongs.push_back( *lauf);
	selectedSongReference = &(*lauf);
      }
  }

  emit selectionChanged();
}

void SongTree::clearSelection(){
  selectedIndex = -1;
  selectedSongs.clear();
  //  songTree->unmarkAll();
}

void SongTree::doubleClick(int index){
  if(songTree->itemAt(index)->hasChild())
    songTree->expandOrCollapseItem(index);
  else
    emit doubleClick();
}
  

void SongTree::addSong(Song newSong){
//   cout << "AddSong:" << newSong.getTitle() << endl;
  KPath path;
  QString spath = newSong.getArtist();
  path.push(&spath);
  songs.push_back(newSong);
  if(artists.find(newSong.getArtist()) == artists.end()){
    artists.insert(newSong.getArtist());
    songTree->insertItem(newSong.getArtist(),&artist_pix);
  }  
  //  cout << newSong.getTitle() << endl;
  songTree->addChildItem(newSong.getTitle(),&song_pix,&path);
}

void SongTree::addSongs(Songs newSongs){
  KPath path;
  QString spath;
  SongIterator lauf;  
  //  cout << "AddSongs:" << newSongs.size()<< endl;
  for(lauf=newSongs.begin(); lauf!=newSongs.end(); lauf++){
    if(artists.find(lauf->getArtist()) == artists.end()){
      artists.insert(lauf->getArtist());
      songTree->insertItem(lauf->getArtist(),&artist_pix);
    }
    spath = lauf->getArtist();
    path.push(&spath);
    //    cout << lauf->getTitle() << endl;
    songTree->addChildItem(lauf->getTitle(),&song_pix,&path);
    songs.push_back(*lauf);
    path.pop();
  }
}


Songs SongTree::getSongs(){
  return selectedSongs;
}

Song* SongTree::getSelectedSongReference(){
  if(selectedIndex == -1) return NULL;
  else return selectedSongReference;
}

Songs SongTree::getAllSongs(){
  return songs;
}


void SongTree::removeAllSongs(){
  songs.clear();
  selectedSongs.clear();
  songTree->clear();
  artists.clear();
}

void SongTree::removeSong(){
  SongIterator lauf;
  SongIterator selectionLauf;
  Song tmp;

  if(selectedIndex == -1) return;

  for(selectionLauf=selectedSongs.begin(); 
      selectionLauf!=selectedSongs.end();
      selectionLauf++){    
    lauf=songs.begin();
    while(lauf != songs.end()){
      if(*selectionLauf == *lauf) {
	songs.erase(lauf);
	break;
      }
      lauf++;
    }
  }
  songTree->removeItem(selectedIndex);
  
  clearSelection();
}


void SongTree::resizeEvent(QResizeEvent *){
  box->setGeometry(2,0,width()-2,height());
  songTree->setGeometry(5,20,box->width()-10,box->height()-25);
}
