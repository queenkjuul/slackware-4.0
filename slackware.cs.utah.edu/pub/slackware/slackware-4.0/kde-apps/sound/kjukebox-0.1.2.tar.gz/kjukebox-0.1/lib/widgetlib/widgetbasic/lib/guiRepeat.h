/*
  radiobutton to select repeat play
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */






#ifndef __GUIREPEAT_H
#define __GUIREPEATE_H

#include <qpainter.h>
#include <qpushbt.h>
#include <qradiobutton.h> 
#include <qlayout.h>
#include <kslider.h>
#include <menuDescription.h>
#include <kpopmenu.h>


#include <iostream.h>




class GuiRepeat : public QRadioButton  {
  Q_OBJECT


 public:
  GuiRepeat(char* text, QWidget *parent=0, const char *name=0 );
  ~GuiRepeat();

 public slots:
   void setRepeat(int);

 private slots:
   void processRepeat(bool);

 signals:
   void setRepeatEvent(int);


};


#endif

