/*
  Configuration Dialog for external mixer call
  Copyright (C) 1999  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#include <mixerConfig.h>



MixerConfig::MixerConfig(QWidget * parent=0, const char * name=0 ) 
                 : PrefConfig(parent,name) {

  mixerCommand_cfg=new Buffer(40);
  config = kapp->getConfig();
  configGroup="MixerConfig";
  load();


  infoBox= new QGroupBox("External Mixer",this, "infoBox" );
  infoBox->setGeometry(20, 40, 300, 220 );

  lineLable = new QLabel(infoBox);
  lineLable->setGeometry(20,20,60,25);
  lineLable->setText("Execute :");

  lineEdit = new QLineEdit(infoBox, "lineEdit");
  lineEdit->setGeometry(90,20 ,180,25);
  lineEdit->setText(mixerCommand_cfg->getData());


}


MixerConfig::~MixerConfig() {
}


char* MixerConfig::getGroupName() {
  return "Mixer";
}


void MixerConfig::load() {
  QString command;
  config->setGroup(configGroup);
  command=config->readEntry( "MixerCommand", "kmix");
  mixerCommand_cfg->clear();
  mixerCommand_cfg->append(command.data());
}


void MixerConfig::save() {
  QString command=lineEdit->text();
  
  mixerCommand_cfg->clear();
  mixerCommand_cfg->append(command.data());
  config->setGroup(configGroup);
  config->writeEntry( "MixerCommand",mixerCommand_cfg->getData());
}


void MixerConfig::apply() {
  save();
}


void MixerConfig::startExternalMixer() {
  cout <<"startExternalMixer"<<endl;
  pid_t myPid = fork();
  if ( myPid == 0 ) {
    execlp(mixerCommand_cfg->getData(),mixerCommand_cfg->getData(),0);
  }
}


