/*
  simple control gui for a device
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <guiTimerDevice.h>



GuiTimerDevice::GuiTimerDevice(QWidget *parent=0, 
			       const char *name=0):GuiDevice( parent, name ) {

  timeString=new Buffer(10);

  streamInfoDevice=new StreamInfoDevice();
  streamInfoDevice->setEventMask(_STREAMINFO_TIME_CHANGE |
				 _STREAMINFO_MUSIC_CHANGE );
  streamInfoDevice->getEventQueue()->setNotifyMode(_NOTIFY_NO);
  setDevice(streamInfoDevice);
  setMinimumSize( sizeHint() );

  timerDeviceConfig=new TimerDeviceConfig("GuiTimerDevice",getPreferences());
  

  getPreferences()->setCaption(streamInfoDevice->getNodeName());
  getPreferences()->addTab(timerDeviceConfig,
			   timerDeviceConfig->getGroupName());
  insertMenu("Configure",this,SLOT(configure()));

  startTimer(500);       // 3 updates per second
}


GuiTimerDevice::~GuiTimerDevice() {
  delete timeString;
  delete streamInfoDevice;
}


void GuiTimerDevice::configure() {
  getPreferences()->show();
}


void GuiTimerDevice::mousePressEvent ( QMouseEvent* mouseEvent) {
  if (mouseEvent->button() ==  RightButton) {
    KPopupMenu* popupMenu=createPopupMenu();
    popupMenu->move(mapToGlobal(QPoint(mouseEvent->x(),mouseEvent->y())));
    popupMenu->exec();
    delete popupMenu;
  }
  if (mouseEvent->button() ==  LeftButton) {
    int mode=timerDeviceConfig->getTimeMode();
    if (mode == _TIMEMODE_PLAYED) {
      timerDeviceConfig->setTimeMode(_TIMEMODE_REMAIN);
      repaint(false);
      return;
    }
    if (mode == _TIMEMODE_REMAIN) {
      timerDeviceConfig->setTimeMode(_TIMEMODE_PLAYED);
      repaint(false);
      return;
    }
  }
}



char* GuiTimerDevice::getTimeString() {
  TimeInfo* timeInfo=streamInfoDevice->getTimeInfo();
  MusicInfo* musicInfo=streamInfoDevice->getMusicInfo();

  timerDeviceConfig->translate(timeInfo,musicInfo,timeString);
  return timeString->getData();
}


QSize GuiTimerDevice::sizeHint () {
  return QSize(40,40);
}


void GuiTimerDevice::paintEvent ( QPaintEvent * paintEvent ) {
  QPainter paint;

  erase(0,0,width(),height());
  paint.begin( this );
  paint.drawText(0,10,getTimeString());
  paint.end();  
  
}







