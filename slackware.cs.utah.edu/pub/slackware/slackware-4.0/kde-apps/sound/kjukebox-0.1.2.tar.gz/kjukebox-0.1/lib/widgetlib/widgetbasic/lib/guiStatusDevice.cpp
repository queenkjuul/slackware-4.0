/*
  gui part for the status device (very simple)
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#include <guiStatusDevice.h>




GuiStatusDevice::GuiStatusDevice(QWidget *parent=0, 
			       const char *name=0):GuiDevice( parent, name ) {
  streamInfoDevice=new StreamInfoDevice();
  streamInfoDevice->setEventMask(_STREAMINFO_STATUS_CHANGE);
  setDevice(streamInfoDevice);
  setMinimumSize( sizeHint() );
}


GuiStatusDevice::~GuiStatusDevice() {
  delete streamInfoDevice;
}


void GuiStatusDevice::processEvent(char eventId) {
  repaint(false);
}


int GuiStatusDevice::getStatus() {
  StatusInfo* statusInfo=streamInfoDevice->getStatusInfo();
  return statusInfo->getStatus();
}


QSize GuiStatusDevice::sizeHint () {
  return QSize(100,40);
}


void GuiStatusDevice::paintEvent ( QPaintEvent * paintEvent ) {
  int status;
  QPainter paint;

  erase(0,0,width(),height());
  status=getStatus();
  if (status == _STATUS_PLAYING) {
    paint.begin( this );
    paint.drawText(0,30,"Playing");
    paint.end();  
  }
  if (status == _STATUS_STOPPED) {
    paint.begin( this );
    paint.drawText(0,30,"Stopped");
    paint.end();  
  }
  if (status == _STATUS_PAUSED) {
    paint.begin( this );
    paint.drawText(0,30,"Paused");
    paint.end();  
  }
  clearNotifyBit();
}
