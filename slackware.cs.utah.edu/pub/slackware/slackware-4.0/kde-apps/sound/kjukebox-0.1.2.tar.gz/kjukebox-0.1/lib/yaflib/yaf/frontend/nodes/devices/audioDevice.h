/*
  generic audiodevice
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */



#ifndef __AUDIODEVICE_H
#define __AUDIODEVICE_H


#include <devices/outputDevice.h>
#include <audio/audioWrapper.h>

extern "C" {
#include <stdio.h>
	   }

#define _DEFAULT_AUDIO_BUFFERSIZE 4096

class AudioDevice :public OutputDevice {

  AudioWrapper* audioWrapper;
  VolumeInfo* volumeInfo;
  AudioInfo* audioInfo;

  int lneedInit;

 public:
  AudioDevice(char* device);
  ~AudioDevice();

  virtual int open();
  virtual int close();
  virtual int isOpen();

  char* getNodeName();
  
  void writeIn(NodeDevice* source,DeviceConfig* buf);
  // Special functions for device
  
  virtual int rawWrite(char* buf,int len);

};

#endif
  
  
