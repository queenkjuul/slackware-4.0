/*
  what do you thing this class does? hm. If its name "volumefilter"
  Copyright (C) 1999 Rainer Maximini, Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




#ifndef __VOLUMEFILTER_H
#define __VOLUMEFILTER_H

#include <filter/filter.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <linux/soundcard.h>

#define _MAX_MIX_SIZE 8192
#define _MAX_MIX_ENTRIES 10


class VolumeFilter : public Filter {

  float vFactor;

 public:
  VolumeFilter();
  ~VolumeFilter();

  void transform(DeviceConfig* config);

};
#endif

