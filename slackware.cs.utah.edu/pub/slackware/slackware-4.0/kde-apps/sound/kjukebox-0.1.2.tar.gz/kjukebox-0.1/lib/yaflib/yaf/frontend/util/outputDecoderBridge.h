/*
  compiler bug workaround
  Copyright (C) 1998  Martin Vogt

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation.

  For more information look at the file COPYRIGHT in this package

 */




/**
   It seem that my compiler does not support multiple inheritance.
   Eh. It does support it by the means that he compiles
   But then it SIGSEVs
*/


#ifndef __OUTPUTDECODERBRIDGE_H
#define __OUTPUTDECODERBRIDGE_H

#include <yafcore/outputDecoder.h>
#include <producer/yaf/yafClient.h>


class OutputDecoderBridge: public OutputDecoder {
  
 struct YafClient* client; 

 public:
  OutputDecoderBridge(struct YafClient* client);
  ~OutputDecoderBridge();


  int processRuntimeCommand(int command,char* args);
  int processReturnCommand(int cmdNr,int cmdId,char* ret,char* args);
};


#endif





  
