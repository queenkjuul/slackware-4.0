#ifndef KJEWEL_H
#define KJEWEL_H

#include <playfield.h>
#include <ktopwidget.h>
#include <kmenubar.h>
#include <kconfig.h>
//#include <kkeydialog.h>
//#include <kaccel.h>
#include <klocale.h>
#include <kapp.h>

#define VERSION "0.9"
#define DATE "6.1.1999"
class KJewelMainWidget: public KTopLevelWidget{
  Q_OBJECT

  public:
    /**
     * The constructor method for class KJewelMainWidget
     */
    KJewelMainWidget(KApplication *app);
    /**
      * The destructor method for class KJewelMainWidget
      */
    Playfield *playfield;
  protected:
    void keyPressEvent(QKeyEvent *e);
    protected slots:
      static const char *about();
	/**
	 * Save the current configuration and quit
	 */
	void quitapp() ;
  private:
    KConfig *config;
    void helpmenu();
//    KAccel *accel;
    void createMenu();
    KMenuBar *menu;
    QPopupMenu *file, *options, *help;
    KApplication *app;
};
#endif
