#ifndef PREVIEWFIELD_H
#define PREVIEWFIELD_H

#include <playfield.h>
#include <qwidget.h>

class Previewfield:public QWidget{
  Q_OBJECT
 public:
  Previewfield(QWidget *,Playfield *);
  void paintEvent(QPaintEvent *);
 private:
  int *nextJewel;
  Playfield *playfield;
 public slots:
  void updateJewel();
};
#endif
