#ifndef HIGHSCORELIST_H
#define HIGHSCORELIST_H

#include <list>
#include <stdlib.h>
#include <kstring.h>
#include <qwidget.h>

class HighscoreEntry{
 public:
  HighscoreEntry();
  HighscoreEntry(QString ,int,int);
  bool operator<(HighscoreEntry &);
  bool operator==(HighscoreEntry &);
  QString Name;
  int Score;
  int Difficulty;
};

class Highscorelist:public list<HighscoreEntry>{
 public:
  Highscorelist();
  ~Highscorelist();
  void readList(char *fname="/var/games/kjewelscore");
  void writeList(char *fname="/var/games/kjewelscore");
  void addToList(int,int);
 private:
  void addToList(QString, int, int);
 public slots:
  void showList();
};
#endif
