#ifndef JEWEL_H
#define JEWEL_H
#include <qpainter.h>
#include <qcolor.h>
#include <qpixmap.h>
#include <kstring.h>

class Jewel{
  friend class Playfield;
  friend class Previewfield;
 public:
  Jewel(const short parts, const short maxcol,const QString *b);
  const Jewel &operator=(const Jewel &);
  short x(),y();
  void newJewel();
  void show(QPainter &);
  QRect topRect()const;
  QRect thisRect()const;
  void up(),down();
  void left(){
    xp--;
  };
  void right(){
    xp++;
  };
  void step();
  put(Playfield &);
 private:
  short xp,yp;
  short maxColors;
  short numParts;
  short *parts;
  static QColor colorList[8];
  QPixmap *jewelPixmaps[10];
  const QString *baseDir;
  void loadPics();
};

#endif
