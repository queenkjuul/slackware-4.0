/* -------------------------------------------------------------

   toplevel.h (part of K HTML Imager)

   (C) by Andreas Heck

   Generated with the KDE Application Generator

 ------------------------------------------------------------- */


#ifndef _TOPLEVEL_H_
#define _TOPLEVEL_H_

#include <kapp.h>
#include <ktopwidget.h>
#include <qgroupbox.h>
#include <qpushbutton.h>
#include <qlineedit.h>
#include <qstring.h>
#include <kfiledialog.h>
#include <qlabel.h>
#include <qdir.h>
#include "htmlimager.h"

class TopLevel : public KTopLevelWidget
{
  Q_OBJECT
  
public:

  TopLevel();

protected:


private slots:

  void aboutApp();
  void browseDir();
  void filterDir();

private:

  QLabel *dirLabel, *outputLabel, *filterLabel, *numFilesLabel;
  QGroupBox *optionsGroup;
  QLineEdit *dirBox, *outputFileBox;
  QPushButton *dirBrowseButton, *filterButton, *optionsButton, *aboutButton, *quitButton;
  HTMLImager *htmlimager;

};

#endif
