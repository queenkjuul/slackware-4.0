/* -------------------------------------------------------------

   htmlimager.h (part of K HTML Imager)

   (C) by Andreas Heck

 ------------------------------------------------------------- */


#ifndef _HTMLIMAGER_H_
#define _HTMLIMAGER_H_

#include <qstring.h>
#include <qdir.h>
#include <qtextstream.h>
#include <qfile.h>

class HTMLImager
{
public:

  HTMLImager();
  ~HTMLImager();
  int createHTML(const char *, const char *, bool);

protected:


private:

  const QFileInfoList * filterDir(const char *, bool) const;
  QDir *directory;

};

#endif
