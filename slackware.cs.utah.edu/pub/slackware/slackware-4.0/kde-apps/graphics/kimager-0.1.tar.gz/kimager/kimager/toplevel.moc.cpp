/****************************************************************************
** TopLevel meta object code from reading C++ file 'toplevel.h'
**
** Created: Sun Nov 15 14:35:17 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.25.2.11 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "toplevel.h"
#include <qmetaobject.h>


const char *TopLevel::className() const
{
    return "TopLevel";
}

QMetaObject *TopLevel::metaObj = 0;


#if QT_VERSION >= 200
static QMetaObjectInit init_TopLevel(&TopLevel::staticMetaObject);

#endif

void TopLevel::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(KTopLevelWidget::className(), "KTopLevelWidget") != 0 )
	badSuperclassWarning("TopLevel","KTopLevelWidget");

#if QT_VERSION >= 200
    staticMetaObject();
}

void TopLevel::staticMetaObject()
{
    if ( metaObj )
	return;
    KTopLevelWidget::staticMetaObject();
#else

    KTopLevelWidget::initMetaObject();
#endif

    typedef void(TopLevel::*m1_t0)();
    typedef void(TopLevel::*m1_t1)();
    typedef void(TopLevel::*m1_t2)();
    m1_t0 v1_0 = &TopLevel::aboutApp;
    m1_t1 v1_1 = &TopLevel::browseDir;
    m1_t2 v1_2 = &TopLevel::filterDir;
    QMetaData *slot_tbl = new QMetaData[3];
    slot_tbl[0].name = "aboutApp()";
    slot_tbl[1].name = "browseDir()";
    slot_tbl[2].name = "filterDir()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    metaObj = new QMetaObject( "TopLevel", "KTopLevelWidget",
	slot_tbl, 3,
	0, 0 );
}
