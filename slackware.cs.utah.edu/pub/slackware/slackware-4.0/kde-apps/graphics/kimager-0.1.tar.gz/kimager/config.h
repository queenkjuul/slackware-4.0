/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if the C++ compiler supports BOOL */
#define HAVE_BOOL 1

#define VERSION "0.1"

#define PACKAGE "kimager"

/* defines which to take for ksize_t */
#define ksize_t int

/* Define to 1 if NLS is requested.  */
#define ENABLE_NLS 1

#ifndef HAVE_BOOL
#define HAVE_BOOL
typedef int bool;
const bool false = 0;
const bool true = 1;
#endif
