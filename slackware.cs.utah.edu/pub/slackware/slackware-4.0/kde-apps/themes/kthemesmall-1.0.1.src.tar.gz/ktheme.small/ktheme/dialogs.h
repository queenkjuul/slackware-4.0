/*************************************************************************
 *                                                                       *
 *  KTheme                                                               *
 *                                                                       *
 * This file is part of the KTheme-Package. For detail information about *
 * this program have a look at the README-File.                          *
 *                                                                       *
 * Copyright(c) 1998 Christian Poulter.                                  *
 *                                                                       *
 * This program is free software; you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation - version 2.                             *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License in file COPYING for more details.          *
 *                                                                       *
 * You should have received a copy of the GNU General Public License     *
 * along with this program; if not, write to the Free Software           *
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.             *
 *                                                                       *
 *  On the Net at http://www.wilhelmshaven-online.de/benutzer/cpoulter   *
 *  Email to cpoulter@ebs-net.com                                        *
 *                                                                       *
 *************************************************************************/

#ifndef DIALOGS_H
#define DIALOGS_H

#include <qlabel.h>
#include <qdialog.h>
#include <qpushbt.h>
#include <klined.h>

class GetNameWindow:public QDialog{
	Q_OBJECT
public:
	GetNameWindow(QWidget *parent=0, const char *name=0, bool init=FALSE);
	~GetNameWindow();
	bool openWindow(QString title);
	void resizeEvent(QResizeEvent *);
	QString getInput();

private:
	KLined			*kl_input;
	QPushButton		*bt_ok;
	QPushButton		*bt_cancel;
};

#endif



