#include "dialogs.h"

GetNameWindow::~GetNameWindow(){
}

GetNameWindow::GetNameWindow(QWidget *parent, const char *name, bool):QDialog(parent,name,TRUE){
	kl_input=new KLined(this,"FFF");
	bt_ok=new QPushButton(this);
	bt_cancel=new QPushButton(this);

	bt_ok->setText("Ok");
	bt_cancel->setText("Cancel");

	connect(bt_ok,SIGNAL(clicked()),SLOT(accept()));
	connect(bt_cancel,SIGNAL(clicked()),SLOT(reject()));

	setMinimumWidth(300);
	setMinimumHeight(80);

	resize(300,80);
}

bool GetNameWindow::openWindow(QString title){
	setCaption(title);
	return exec();
}

void GetNameWindow::resizeEvent(QResizeEvent *){
	kl_input->setGeometry(0,0,width(),30);
	bt_ok->setGeometry(width()-160,40,70,30);
	bt_cancel->setGeometry(width()-80,40,70,30);
}

QString GetNameWindow::getInput(){
	return(kl_input->text());
}


