/***************************************************************************
                    prjoptionsdlg.h - the setup DLG for a project  
                             -------------------                                         

    version              :                                   
    begin                : 10 Aug 1998                                        
    copyright            : (C) 1998 by Sandy Meier                         
    email                : smeier@rz.uni-potsdam.de                                     
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   * 
 *                                                                         *
 ***************************************************************************/
#ifndef __PRJOPTIONSDLG_H_
#define __PRJOPTIONSDLG_H_

#include "kdevelop.h"
#include <kfiledialog.h>
#include <qbttngrp.h>
#include <qradiobt.h>
#include <qlistbox.h>
#include <qlined.h>
#include <qtabdialog.h>
#include <kapp.h>
#include <qchkbox.h>
#include <qcombo.h>
#include <qlabel.h>
#include <qpushbt.h>
#include <kmsgbox.h>
#include <klined.h>


/** the setup-dialog for a project 
  *@author Sandy Meier
  */
class PrjOptionsDlg : public QTabDialog
{
    Q_OBJECT
public:
    /**constructor*/
    PrjOptionsDlg( QWidget *parent, const char *name,KDevelop* dev,CProjectInfo* prj );
protected:
  /** a pointer to the main application*/
  KDevelop* devel;
  /** local projectinfo object*/
  CProjectInfo* prj_info; 
  // some edit stuff
  QLineEdit* email_edit;
  QLineEdit* author_edit;
  QLineEdit* version_edit;
  QLineEdit* prjname_edit;
  QLineEdit* handbook_edit;
 protected slots:
 /** is called, if the ok-button were clicked*/
 void  ok();
};

#endif
