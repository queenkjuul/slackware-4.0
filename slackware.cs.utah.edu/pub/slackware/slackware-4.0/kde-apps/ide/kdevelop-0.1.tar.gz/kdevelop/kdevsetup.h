/***************************************************************************
                     kdevsetup.h - the setup dialog for KDevelop
                             -------------------                                         

    version              :                                   
    begin                : 17 Aug 1998                                        
    copyright            : (C) 1998 by Sandy Meier                         
    email                : smeier@rz.uni-potsdam.de                                     
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   * 
 *                                                                         *
 ***************************************************************************/
#ifndef __KDEVSETUP_H_
#define __KDEVSETUP_H_
#include <qlineedit.h>
#include <qbttngrp.h>
#include <qradiobt.h>
#include <qlistbox.h>
#include <qtabdialog.h>
#include <qmlined.h>
#include <kapp.h>
#include <qcombo.h>
#include <qlabel.h>
#include <qpushbt.h>
#include <kmsgbox.h>
#include <kfiledialog.h>

/** the setup dialog for kdevelop
  *@author Sandy Meier
  */
class KDevSetup : public QTabDialog
{
    Q_OBJECT
public:
    KDevSetup( QWidget *parent=0, const char *name=0 );
private:
  KConfig* config;
  QLineEdit* kfile_edit;
  QLineEdit* kcore_edit;
  QLineEdit* kgui_edit;
  QLineEdit* khtml_edit;
  QLineEdit* qt_edit;
 private slots:
 void        ok();
  void slotQtClicked();
  void slotKCoreClicked();
  void slotKGuiClicked();
  void slotKFileClicked();
  void slotKHTMLClicked();

};

#endif
