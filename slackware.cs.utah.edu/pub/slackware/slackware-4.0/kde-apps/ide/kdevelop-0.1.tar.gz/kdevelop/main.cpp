/***************************************************************************
                     main.cpp - the main-function
                             -------------------                                         

    version              :                                   
    begin                : 20 Jul 1998                                        
    copyright            : (C) 1998 by Sandy Meier                         
    email                : smeier@rz.uni-potsdam.de                                     
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   * 
 *                                                                         *
 ***************************************************************************/
#include "kdevelop.h"

int main(int argc, char* argv[]) {
  
  KApplication a(argc,argv,"kdevelop");  
  
  if (a.isRestored()){
    RESTORE(KDevelop);
  }
  else {
    KDevelop* kdevelop = new KDevelop;
    a.setMainWidget(kdevelop);
    a.setTopWidget(kdevelop);
    kdevelop->show();
  }  
 
  return a.exec();
}
