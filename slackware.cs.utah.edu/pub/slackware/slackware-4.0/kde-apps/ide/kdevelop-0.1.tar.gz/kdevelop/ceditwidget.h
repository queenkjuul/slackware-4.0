/***************************************************************************
              ceditwidget.h  -  an abstraction layer for an editwidget   
                             -------------------                                         

    version              :                                   
    begin                : 23 Aug 1998                                        
    copyright            : (C) 1998 by Sandy Meier                         
    email                : smeier@rz.uni-potsdam.de                                     
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   * 
 *                                                                         *
 ***************************************************************************/
#ifndef CEDITWIDGET_H
#define CEDITWIDGET_H

#include <keditcl.h>
/** an abstraction layer for an editwidget
  *@author Sandy Meier
  */
class CEditWidget : public KEdit {
  Q_OBJECT
public:
  CEditWidget(KApplication* a=0,QWidget* parent=0,char* name=0);
  ~CEditWidget(){};
  void setName(QString filename);
  QString getName();
  void setText(QString text);
  void doSave();
  void doSave(QString filename);
  void gotoPos(int pos,QString text);
  void toggleModified(bool);
  void search();
  void searchAgain();
  void replace();
  void gotoLine();
  QString markedText();
  QString text();
protected:
  QString filename;
};

#endif
