/***************************************************************************
               ceditwidget.cpp  -  a abstraction layer for a editwidget   
                             -------------------                                         

    version              :                                   
    begin                : 23 Aug 1998                                        
    copyright            : (C) 1998 by Sandy Meier                         
    email                : smeier@rz.uni-potsdam.de                                     
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   * 
 *                                                                         *
 ***************************************************************************/
#include "ceditwidget.h"
#include <iostream.h>

CEditWidget::CEditWidget(KApplication* a,QWidget* parent,char* name): KEdit(a,parent,name) { 
}
void CEditWidget::setName(QString filename){
  // this->filename = filename;
    KEdit::setName(filename);
}
QString CEditWidget::getName(){
  //return filename;
  return KEdit::getName();
}
void CEditWidget::setText(QString text){
    KEdit::setText(text);
}
void CEditWidget::doSave(){
   KEdit::doSave();
}
void CEditWidget::doSave(QString filename){
   KEdit::doSave(filename);
}
void CEditWidget::gotoPos(int pos,QString text_str){  
  
  cerr << endl << "POS: " << pos;
  // calculate the line
  QString last_textpart = text_str.right(text_str.size()-pos); // the second part of the next,after the pos
   int line = text_str.contains("\n") - last_textpart.contains("\n");
   //  cerr << endl << "LINE:" << line;
   setCursorPosition(line,0);
}
void CEditWidget::toggleModified(bool mod){
  KEdit::toggleModified(mod);
}
QString CEditWidget::markedText(){
  return KEdit::markedText(); 
}
QString CEditWidget::text(){
  return KEdit::text();
}
void CEditWidget::search(){
  KEdit::Search();
}
void CEditWidget::searchAgain(){
  KEdit::repeatSearch();
}
void CEditWidget::replace(){
  KEdit::Replace();
}
void CEditWidget::gotoLine(){
  KEdit::doGotoLine();
}

