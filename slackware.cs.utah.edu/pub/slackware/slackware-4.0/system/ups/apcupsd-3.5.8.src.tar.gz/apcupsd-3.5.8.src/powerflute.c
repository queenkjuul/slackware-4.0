/*
 *  powerflute.c -- ncurses interface to apcupsd
 *
 *  Copyright (C) 1998-99 Facchetti Riccardo <fizban@tin.it>
 *
 *  apcupsd.c    -- Simple Daemon to catch power failure signals from a
 *                  BackUPS, BackUPS Pro, or SmartUPS (from APCC).
 *               -- Now SmartMode support for SmartUPS and BackUPS Pro.
 *
 *  Copyright (C) 1996-99 Andre M. Hedrick
 *                        <hedrick@astro.dyer.vanderbilt.edu>
 *  All rights reserved.
 *
 */

/*
 *                     GNU GENERAL PUBLIC LICENSE
 *                        Version 2, June 1991
 *
 *  Copyright (C) 1989, 1991 Free Software Foundation, Inc.
 *                           675 Mass Ave, Cambridge, MA 02139, USA
 *  Everyone is permitted to copy and distribute verbatim copies
 *  of this license document, but changing it is not allowed.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/*
 *  IN NO EVENT SHALL ANY AND ALL PERSONS INVOLVED IN THE DEVELOPMENT OF THIS
 *  PACKAGE, NOW REFERRED TO AS "APCUPSD-Team" BE LIABLE TO ANY PARTY FOR
 *  DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING
 *  OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF ANY OR ALL
 *  OF THE "APCUPSD-Team" HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  THE "APCUPSD-Team" SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING,
 *  BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 *  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 *  ON AN "AS IS" BASIS, AND THE "APCUPSD-Team" HAS NO OBLIGATION TO PROVIDE
 *  MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 *  THE "APCUPSD-Team" HAS ABSOLUTELY NO CONNECTION WITH THE COMPANY
 *  AMERICAN POWER CONVERSION, "APCC".  THE "APCUPSD-Team" DID NOT AND
 *  HAS NOT SIGNED ANY NON-DISCLOSURE AGREEMENTS WITH "APCC".  ANY AND ALL
 *  OF THE LOOK-A-LIKE ( UPSlink(tm) Language ) WAS DERIVED FROM THE
 *  SOURCES LISTED BELOW.
 *
 */

/*
 *  Contributed by Facchetti Riccardo <fizban@tin.it>
 */

#include <apc_version.h>

#ifndef __NO_NCURSES__

#include <stdio.h>
#include <stdarg.h>
#ifdef __CURSES__
#include <curses.h>
#include <panel.h>
#include <menu.h>
#endif /* __CURSES__ */
#ifdef __NCURSES__
#include <ncurses/curses.h>
#include <ncurses/panel.h>
#include <ncurses/menu.h>
#endif /* __NCURSES__ */
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <setjmp.h>
#include <time.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <apc_defines.h>
#include <apc_struct.h>
#include <apc_extern.h>

#define TIMER_POWERFLUTE	5
#define RESTORE_BUFFER		3

/*
 * This is needed for restart ncurses and all the circus.
 * ncurses or something other seems to have a bug that prevent it to
 * refresh correctly the screen when a wall message is received.
 */
jmp_buf env;

/*
 * Buffer to save the last 8 lines of mesgwin.
 */
char mesgbuf[8][1024];

/*
 * Menubar window and panel
 */
WINDOW *menuwin;
PANEL *menupan;
/*
 * Status window and panel
 */
WINDOW *statwin;
PANEL *statpan;
/*
 * Monitoring window and panel
 */
WINDOW *moniwin;
PANEL *monipan;
/*
 * Message window and panel
 */
WINDOW *mesgwin;
PANEL *mesgpan;

/*
 * UPS structure.
 */
UPSINFO myUPS;

extern void close_curses(void);

void init_timer(int timer, void (*fnhandler)(int)) {
	signal(SIGALRM, fnhandler);
	alarm(timer);
}

char *xlate_history(char code) {
	switch (code) {
		case 'O':
			return "Power Up";
			break;
		case 'S':
			return "Self Test";
			break;
		case 'L':
			return "Line Voltage Decrease";
			break;
		case 'H':
			return "Line Voltage Increase";
			break;
		case 'T':
			return "Power Failure";
			break;
		default :
			/*
			 * XXX
			 *
			 * The value of the 'G' query from UPS is unknown
			 * and need to be investigated. We should log to
			 * syslog the value of code.
			 */
			return "Unknown Event (see syslog)";
			break;
	}
}

void restart_curses(void) {
	close_curses();
	longjmp(env, RESTORE_BUFFER);
}

void update_all(void) {
	update_panels();
	refresh();
	doupdate();
}

void restore_mesg(void) {
	int y;

	/*
	 * Restore the buffer.
	 * Remember that the y must start at 1 to do not touch the border.
	 * The screen start at 1 but the buffer start at 0.
	 */
	for (y = 1; mesgbuf[y-1][0] != '\0' && y < 9; y++) {
		mvwprintw(mesgwin, y, 1, mesgbuf[y-1]);
	}
	wborder(mesgwin,0,0,0,0,0,0,0,0);
	update_all();
}

void write_mesg(char *fmt, ...) {
	va_list args;
	static char buffer[1024];
	int x, y;

	memset(buffer, 0, 1024);

	va_start(args, fmt);
	vsprintf(buffer, fmt, args);
	va_end(args);

	buffer[strlen(buffer)] = '\n';

	getyx(mesgwin, y, x);

	/*
	 * If we write the first line of window we must start at 1 because we
	 * do not want to touch the nice border.
	 */
	if (y == 0)
		y = 1;

	/*
	 * At the low end of the window we scroll the entire content up one
	 * line.
	 */
	if (y == 9) {
		wscrl(mesgwin, 1);
		y = 8;
	}

	mvwprintw(mesgwin, y, 1, buffer);
	wborder(mesgwin,0,0,0,0,0,0,0,0);

	/*
	 * Save the last 8 lines of buffer.
	 */
	/*
	 * If buffer full.
	 */
	if(mesgbuf[7][0]) {
		/*
		 * Scroll the buffer.
		 */
		for (y = 1; y < 8; y++) {
			strcpy(mesgbuf[y-1], mesgbuf[y]);
		}
		/*
		 * Now point to the last line of the mesgbuf.
		 */
		y = 7;
	} else {
		/*
		 * Find the first free slot.
		 */
		for (y = 0; mesgbuf[y][0]; y++)
			;
	}
	/*
	 * y now point to a free slot.
	 */
	strcpy(mesgbuf[y], buffer);
}

void update_upsdata(int sig) {
	static int power_fail = FALSE;
	static int battery_fail = FALSE;
	time_t now;
	char *t;

	read_shmarea(&myUPS);

	time(&now);
	t = ctime (&now);
	t[strlen(t)-1] = '\0';

	mvwprintw(statwin, 1, 1, "Last update: %s", t);
	mvwprintw(statwin, 2, 1, "Model      : %s", myUPS.mode.long_name);
	mvwprintw(statwin, 3, 1, "Cable      : %s", myUPS.cable.long_name);
	mvwprintw(statwin, 4, 1, "Mode       : %s", myUPS.class.long_name);
	mvwprintw(statwin, 5, 1, "AC Line    : %s",
			(myUPS.LineUp ? "failing" : "okay"));
	mvwprintw(statwin, 6, 1, "Battery    : %s",
			(myUPS.BattUp ? "failing" : "okay"));
	mvwprintw(statwin, 7, 1, "AC Level   : %s",
			(myUPS.LineLevel ?
			 ((myUPS.LineLevel == 1) ? "high" : "low")
			 : "normal"));
	mvwprintw(statwin, 8, 1, "Last event : %s",
			xlate_history(myUPS.G[0]));

	if (myUPS.LineLevel) {
		write_mesg("* [%s] warning: AC level is %s", t,
				((myUPS.LineLevel == 1) ? "high" : "low"));
	}

	if (myUPS.LineUp) {
		if (power_fail == FALSE) {
			write_mesg("* [%s] warning: power is failing", t);
			power_fail = TRUE;
		}
	} else {
		if (power_fail == TRUE) {
			write_mesg("* [%s] warning: power is returned", t);
			power_fail = FALSE;
		}
	}

	if (myUPS.BattUp) {
		if (battery_fail == FALSE) {
			write_mesg("* [%s] warning: battery is failing", t);
			power_fail = TRUE;
		}
	} else {
		if (battery_fail == TRUE) {
			write_mesg("* [%s] warning: battery is okay", t);
			battery_fail = FALSE;
		}
	}

	update_all();

	alarm(TIMER_POWERFLUTE);
}

void close_curses(void) {
	del_panel(menupan);
	del_panel(statpan);
	del_panel(monipan);
	del_panel(mesgpan);
	delwin(menuwin);
	delwin(statwin);
	delwin(moniwin);
	delwin(mesgwin);
	werase(stdscr);
	update_all();
	endwin();
	detach_ipc();
}

static int menu_virtualize(int c)
{
    if (c == '\n' || c == KEY_EXIT)
            return(MAX_COMMAND + 1);
        else if (c == 'n' || c == KEY_DOWN)
        return(REQ_NEXT_ITEM);
   else if (c == 'p' || c == KEY_UP)
            return(REQ_PREV_ITEM);
       else if (c == ' ')
        return(REQ_TOGGLE_ITEM);
    else
            return(c);
}

char * do_menu(int * pos, ITEM **it0, int pos_x) {
	ITEM **it = it0;
	MENU *mu;
	WINDOW *mw;
	WINDOW *dmw;
	static char answer[80];
	int r, c;
	int mc;

	mu = new_menu(it0);
	scale_menu(mu, &r, &c);

	mw = newwin(r+2, c+2, 2, pos_x);
	set_menu_win(mu, mw);
	keypad(mw, TRUE);
	box(mw, 0, 0);
	dmw = derwin(mw, r, c, 1, 1);
	set_menu_sub(mu, dmw);
	post_menu(mu);

	answer[0] = '\0';

	do {
		mc = wgetch(mw);
		if ((mc == KEY_UP) && (item_index(current_item(mu)) == 0)) {
			goto out_nokey;
		}
		if (mc == KEY_RIGHT) {
			*pos = (*pos+1) % 3;
			goto out_nokey;
		}
		if (mc == KEY_LEFT) {
			*pos = (*pos+2) % 3;
			goto out_nokey;
		}
	} while (menu_driver(mu, menu_virtualize(mc))
			!= E_UNKNOWN_COMMAND);

	strcpy(answer, item_name(current_item(mu)));

out_nokey:
	unpost_menu(mu);

	delwin(dmw);
	delwin(mw);
	free_menu(mu);
	for(it=it0; *it; it++)
		free_item(*it);
	
	return answer;
}

void do_file_menu(int * pos) {
	ITEM *it0[64];
	ITEM **it = it0;
	char *answer;

	*it++ = new_item("Load", "No op");
	*it++ = new_item("Save", "No op");
	*it++ = new_item("Refresh", "screen");
	*it++ = new_item("Quit", "");
	*it = NULL;

	answer = do_menu(pos, it0, 0);
	if (answer[0] == '\0')
		return;

	if (!strcmp(answer, "Refresh")) {
		restart_curses();
		/*
		 * Never reached.
		 */
	}

	if (!strcmp(answer, "Quit")) {
		close_curses();
		exit(0);
	}
}

void do_upscontrol_menu(int * pos) {
	ITEM *it0[64];
	ITEM **it = it0;
	char *answer;

	*it++ = new_item("Test battery", "No op");
	*it++ = new_item("Test leds", "No op");
	*it++ = new_item("UPS shutdown", "No op");
	*it = NULL;

	answer = do_menu(pos, it0, 14);
	if (answer[0] == '\0')
		return;
}

void do_help_menu(int * pos) {
	ITEM *it0[64];
	ITEM **it = it0;
	char *answer;

	*it++ = new_item("About powerflute", "");
	*it = NULL;

	answer = do_menu(pos, it0, 30);
	if (answer[0] == '\0')
		return;

	if (!strcmp(answer, "About powerflute")) {
		write_mesg("Powerflute, a program to monitor the UPS and "
				"control the apcupsd daemon");
		write_mesg("Written by Riccardo Facchetti <fizban@tin.it>");
	}
}

char *hm[] = {
	"File",
	"UPS",
	"Help",
	NULL
};

void display_h_menu(pos) {
	char **p=hm;

	redrawwin(menuwin);
	redrawwin(statwin);
	redrawwin(moniwin);

	mvwprintw(menuwin, 1, 2, "");

	for (p=hm; *p != NULL; p++) {
		if (pos == (p-hm)) {
			wattron(menuwin, A_REVERSE);
		}
		wprintw(menuwin, "%s\t\t", *p);
		wattroff(menuwin, A_REVERSE);
	}
	update_all();
}

int do_horiz_menu(void) {
	int pos = 0;
	int oldpos = 0;
	int true = 1;

	while (true) {

		display_h_menu(pos);

		switch (wgetch(menuwin)) {
			case KEY_LEFT:
			case 'h':
				pos = (pos+2) % 3;
				break;

			case KEY_RIGHT:
			case 'l':
				pos = (pos+1) % 3;
				break;

			case KEY_DOWN:
			case 10: /* RETURN */
change_menu:
				oldpos = pos;
				switch (pos) {
					case 0:
						do_file_menu(&pos);
						break;
					case 1:
						do_upscontrol_menu(&pos);
						break;
					case 2:
						do_help_menu(&pos);
						break;
					default:
						break;
				}
				pos = pos % 4;
				if (oldpos != pos) {
					display_h_menu(pos);
					goto change_menu;
				}
				break;

			default:
				break;
		}
	}

	return SUCCESS;
}

int init_main_screen(void) {
	/*
	 * Init ncurses subsystem
	 */
	if (initscr() == NULL)
		goto out_err;

	if (LINES < 25 || COLS < 80)
		goto out_err;

	if (cbreak() == ERR)
		goto out_err;

	if (noecho() == ERR)
		goto out_err;

	/*
	 * Invisible cursor
	 */
	curs_set(0);

	/*
	 * Build all windows and panels
	 */
	menuwin = newwin(3,0,0,0);
	keypad(menuwin, TRUE);
	menupan = new_panel(menuwin);
	wborder(menuwin,0,0,0,0,0,0,0,0);
	show_panel(menupan);

	statwin = newwin(12,40,3,0);
	statpan = new_panel(statwin);
	wborder(statwin,0,0,0,0,0,0,0,0);
	show_panel(statpan);

	moniwin = newwin(12,40,3,40);
	monipan = new_panel(moniwin);
	wborder(moniwin,0,0,0,0,0,0,0,0);
	show_panel(monipan);

	mesgwin = newwin(10,0,15,0);
	mesgpan = new_panel(mesgwin);
	wborder(mesgwin,0,0,0,0,0,0,0,0);
	show_panel(mesgpan);
	scrollok(mesgwin, TRUE);

	update_all();

	return SUCCESS;

out_err:
	close_curses();
	return FAILURE;
}

int main(void) {
	int status;
	int flag;

	/*
	 * Do not move this line below the setjmp.
	 */
	memset(mesgbuf, 0, 1024*8);

	/*
	 * For refreshing the screen in very bad situations like when
	 * someone broadcast a wall.
	 */
	flag = setjmp(env);

	status = SUCCESS;

	/*
	 * Attach daemon shared memory area.
	 */
	if (attach_ipc() != SUCCESS) {
		fprintf(stderr, "Can not attach SYSV IPC "
				 "(daemon not running ?).\n");
		status = FAILURE;
		goto out;
	}
		
	/*
	 * Init ncurses subsystem.
	 */
	if (init_main_screen() == FAILURE) {
		if (LINES < 25 || COLS < 80)
			fprintf(stderr, "You must have at least 80 columns "
					"x 25 lines.\n");
		fprintf(stderr, "Error initializing ncurses subsystem\n");
		status = FAILURE;
		goto out;
	}

	memset(&myUPS, 0, sizeof(UPSINFO));

	init_timer(TIMER_POWERFLUTE, update_upsdata);

	/*
	 * If after the longjmp we need to restore the mesg buffer, do it now.
	 */
	if (flag == RESTORE_BUFFER)
		restore_mesg();

	/*
	 * Update data immediately.
	 */
	update_upsdata(0);

	do_horiz_menu();

	close_curses();

out:
	detach_ipc();
	return status;
}
#endif /* __NO_NCURSES__ */
