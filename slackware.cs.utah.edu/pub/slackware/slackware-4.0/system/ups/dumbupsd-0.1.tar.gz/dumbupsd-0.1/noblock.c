#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>

pid_t pid;
struct termios t;
int ioption=0;
int isig;
int retstat;
int fd;
int i;
char c;

int main (int argc, char *argv[])
{
	if (argc>=3 && !strcmp(argv[1],"-i"))
	    { ioption=1; argc--; argv++; }
	if (argc<2)
	{
		printf("Usage: noblock [-i] device [program [arguments]]\n");
		exit(0);
	}
	fd=open(argv[1],O_WRONLY|O_NOCTTY|O_NDELAY);
	if (fd==-1) { perror("noblock: cannot open device"); exit(1); }
	if (fd<3) { fprintf(stderr,"noblock: "
	    "got a file descriptor less than 3. Strange\n"); exit(1); }
	if (ioption)
	{
		if (tcgetattr(fd,&t)==-1)
		    { perror("noblock: tcgetattr failed"); exit(1); }
		isig = t.c_lflag & ISIG;
		if (isig)
		{
			t.c_lflag &= ~ISIG;
			if (tcsetattr(fd,TCSANOW,&t)==-1)
			    { perror("noblock: tcsetattr failed"); exit(1); }
		}
	}
	if (dup2(fd,1)==-1 || dup2(fd,2)==-1)
	    { perror("noblock: dup2 failed"); exit(1); }
	close(fd);
	pid=fork();
	if (pid<0) { perror("noblock: fork failed"); exit(1); }
	if (pid==0)
	{
		if (argc>2)
		{
			execvp(argv[2],argv+2);
			perror("noblock: execve failed");
			exit(1);
		}
		while ((i=getchar())!=EOF) { c=(char)i; write(1,&c,1); }
		exit(0);
	}
	waitpid(pid,&retstat,0);
	if (ioption)
	{
		if (isig)
		{
			if (tcgetattr(1,&t)==-1)
			    { perror("noblock: tcgetattr failed"); exit(1); }
			t.c_lflag |= ISIG;
			if (tcsetattr(1,TCSANOW,&t)==-1)
			    { perror("noblock: tcsetattr failed"); exit(1); }
		}
		if (tcflush(1,TCIFLUSH)==-1)
		    perror("noblock: tcflush failed");
	}
	exit(WIFEXITED(retstat)?0:WEXITSTATUS(retstat));
}
