#include <unistd.h>
#include <termios.h>
#include <stdio.h>

int main (void)
{
	if (tcflush(0,TCIFLUSH)) { perror("eatinput"); return 1; }
	return 0;
}
