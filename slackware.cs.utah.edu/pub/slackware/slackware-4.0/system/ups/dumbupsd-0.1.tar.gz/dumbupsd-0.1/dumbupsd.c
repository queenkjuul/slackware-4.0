
/*-- dumbupsd v0.1,  July 16, 1998.

     Copyright (C) 1998  KOBLINGER Egmont <egmont@fazekas.hu>
     Copying: GPL.  See below or run ``dumbupsd --warranty''
--*/

#define DEFAULTDEVICE "/dev/ups"
#define DEFAULTSCRIPT "/sbin/init.d/power"

/*-- These values come from /usr/include/asm/termios.h --*/
#define PIN_LINEFAIL TIOCM_CAR
#define PIN_BATTLOW  TIOCM_CTS
#define PIN_CONNECT  TIOCM_DSR
#define PIN_PULLUP   TIOCM_DTR
#define PIN_KILLPWR  TIOCM_RTS

/*-- I hope there's nothing to edit below this line --*/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <signal.h>
#include <syslog.h>
#include <time.h>
#include <errno.h>

#define VERSION "dumbupsd v0.1"
#define COPYRIGHT "Copyright (C) 1998  KOBLINGER Egmont <egmont@fazekas.hu>"

char *help=
VERSION "\n"
COPYRIGHT "\n"
"UPS daemon for dumb ups's (see man page for the cable required)\n"
"Usage: dumbupsd [-d device] [-s script]\n"
"       dumbupsd {--help|--version|--warranty}\n";

char *version=
VERSION "\n";

char *warranty=
VERSION "\n"
COPYRIGHT "\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n";

int fd=-1;
int flags;
char temp[100];
pid_t pid, mypid;
time_t t;
int killpwr=PIN_KILLPWR;
int pullup=PIN_PULLUP;
int linefail=0, linefail_old, battlow=0, battlow_old, connected=1;
int got_usr1=0, got_pwr=0, got_int=0, got_quit=0;
char *device=DEFAULTDEVICE;
char *script=DEFAULTSCRIPT;
#define tsleep(x) usleep((x)*100000)

/*--------------------------------------------------------------------------*/

/*-- write_to_console:
       prints message to the system console, beeps the terminal
--*/
void write_to_console (const char *s)
{
	int fdc;
	char tempc[250];
	sprintf(tempc,"\adumbupsd: %s\r\n",s);
	fdc=open("/dev/console",O_WRONLY|O_NOCTTY|O_NDELAY);
	write(fdc,tempc,strlen(tempc));
	close(fdc);
	return;
}

/*--------------------------------------------------------------------------*/

/*-- send_to_syslog:
       send the message to the system logger
--*/
void send_to_syslog (const char *s, int i)
{
	openlog("dumbupsd",LOG_PID,LOG_DAEMON);
	syslog(i,s);
	closelog();
	return;
}

/*--------------------------------------------------------------------------*/

/*-- logging:
       types are
         1 = starting
         2 = exiting on sigquit
         3 = power gone or restored, got sigpwr, cable error, etc
         4 = not used
         5 = ups did't kill the power
         6 = abnormal condition, exiting
--*/
void logging (int type, const char *descr)
{
	char templ[200];
	if (type==1 || type==2)
	{
		send_to_syslog(descr,LOG_INFO);
	}
	if (type==3 || type==5)
	{
		write_to_console(descr);
		send_to_syslog(descr,LOG_ERR);
	}
	if (type==6)
	{
		sprintf(templ,"%s: %s",
			descr,sys_errlist[errno]);
		write_to_console(templ);
		write_to_console("exiting on previous error");
		send_to_syslog(templ,LOG_ERR);
		send_to_syslog("exiting on previous error",LOG_ERR);
		exit(1);
	}
	return;
}

/*--------------------------------------------------------------------------*/

/*-- mysystem:
       something similar to system(3)
--*/
int mysystem (const char *s)
{
	int pid, status;
	pid=fork();
	if (pid==-1) return -1;
	if (pid==0)
	{
		signal(SIGTERM,SIG_DFL);
		signal(SIGHUP,SIG_DFL);
		execl("/bin/sh","sh","-c",s,NULL);
		sprintf(temp,"execl: %s",sys_errlist[errno]);
		send_to_syslog(temp,LOG_ERR);
		exit(127);
	}
	do
	{
		if (waitpid(pid,&status,0)==-1)
		{
			if (errno!=EINTR)
			{
				sprintf(temp,"waitpid: %s",sys_errlist[errno]);
				write_to_console(temp);
				send_to_syslog(temp,LOG_ERR);
				return -1;
			}
		}
		else
		    return status;
	} while (1);
}

/*--------------------------------------------------------------------------*/

/*-- cable:
       argument is 0 if connection became wrong,
                   1 if connection is still wrong (called every 60 secs)
                   2 if connection established
--*/
void cable (int i)
{
	sprintf(temp,"Connection %s%s",
	    i==1 ? "still " : "",
	    i==2 ? "okay" : "WRONG");
	logging(3,temp);
	sprintf(temp,"DUMBUPSD_PID=%d CONNECTION=%d %s cable",mypid,i,script);
	mysystem(temp);
	return;
}

/*--------------------------------------------------------------------------*/

/*-- initial_state:
       called at startup
--*/
void initial_state (void)
{
	sprintf(temp,"INITIALLY%s%s%s",
	    linefail ? " LINE FAILURE" : "",
	    (linefail&&battlow) ? " and" : "",
	    battlow ? " BATTERY LOW" : "");
	if (linefail || battlow) logging(3,temp);
	sprintf(temp,"DUMBUPSD_PID=%d LINEFAIL=%d BATTLOW=%d %s init",
	    mypid,linefail,battlow,script);
	mysystem(temp);
	return;
}

/*--------------------------------------------------------------------------*/

/*-- batt_low:
       called when status of battlow line changes
--*/
void batt_low (void)
{
	sprintf(temp,"BATTERY %s (line is %s)",
	    battlow ? "DOWN" : "UP",
	    linefail ? "wrong" : "okay");
	logging(3,temp);
	sprintf(temp,"DUMBUPSD_PID=%d LINEFAIL=%d BATTLOW=%d %s battchange",
	    mypid,linefail,battlow,script);
	mysystem(temp);
	return;
}

/*--------------------------------------------------------------------------*/

/*-- line_fail:
       called when status of linefail line changes
--*/
void line_fail (void)
{
	sprintf(temp,"LINE %s (battery is %s)",
	    linefail ? "DOWN" : "UP",
	    battlow ? "low" : "okay");
	logging(3,temp);
	sprintf(temp,"DUMBUPSD_PID=%d LINEFAIL=%d BATTLOW=%d %s linechange",
	    mypid,linefail,battlow,script);
	mysystem(temp);
	return;
}

/*--------------------------------------------------------------------------*/

/*-- sigint, sigquit, sigpwr, sigusr1:
       sigquit causes dumbupsd to exit
       sigpwr kills the ups power
       sigusr1 tells us the state of lines
       sigterm and sighup are ignored
--*/

void serve_int (void)
{
	logging(2,"exiting on sigint");
	exit(0);
}

void serve_quit (void)
{
	logging(2,"exiting on sigquit");
	exit(0);
}

void serve_pwr (void)
{
	got_pwr=0;
	logging(3,"serving sigpwr, shutting down UPS");
	/*-- maybe stupid user has something mounted read-write --*/
	sync(); sync(); sync();
	ioctl(fd,TIOCMBIS,&killpwr);
	/*-- do not use sleep here --*/
	t=time(NULL);
	while (time(NULL)<=t+10);
	ioctl(fd,TIOCMBIC,&killpwr);
	while (time(NULL)<=t+12);
	logging(5,"FAILED to SHUT DOWN the UPS in 10 secs");
	return;
}

void serve_usr1 (void)
{
	char tempu[100];
	got_usr1=0;
	sprintf(tempu,"serving sigusr1: %sconnected, line is %s, batt is %s",
	    connected ? "" : "NOT ",
	    linefail ? "WRONG" : "okay",
	    battlow ? "LOW" : "okay");
	logging(3,tempu);
	sprintf(tempu,"DUMBUPSD_PID=%d CONNECTION=%d LINEFAIL=%d BATTLOW=%d %s status",
	    mypid,connected?2:0,linefail,battlow,script);
	mysystem(tempu);
	return;
}

void sigint (int dummy)
{
	signal(SIGINT,sigint);
	logging(3,"sigint caught");
	got_int=1;
	return;
}

void sigquit (int dummy)
{
	signal(SIGQUIT,sigquit);
	logging(3,"sigquit caught");
	got_quit=1;
	return;
}

void sigpwr (int dummy)
{
	signal(SIGPWR,sigpwr);
	logging(3,"sigpwr caught");
	got_pwr=1;
	return;
}

void sigusr1 (int dummy)
{
	signal(SIGUSR1,sigusr1);
	logging(3,"sigusr1 caught");
	got_usr1=1;
	return;
}

/*--------------------------------------------------------------------------*/

/*-- check_for_signal:
       call the real signal handler
--*/
void check_for_signal (void)
{
	if (got_int) serve_int();
	if (got_quit) serve_quit();
	if (got_usr1) serve_usr1();
	if (got_pwr) serve_pwr();
	return;
}

/*--------------------------------------------------------------------------*/

/*-- cable_ok:
       returns 2 if cable is okay,
       otherwise writes log and waits till cable is okay and returns 0
--*/
int cable_ok (void)
{
	int i=0;
	connected=(flags&PIN_CONNECT)!=0;
	if (connected) return 2;
	cable(0);
	while (!connected)
	{
		tsleep(10);
		check_for_signal();
		i++;
		if (i>=60) { i=0; cable(1); }
		ioctl(fd,TIOCMGET,&flags);
		connected=(flags&PIN_CONNECT)!=0;
	}
	cable(2);
	return 0;
}

/*--------------------------------------------------------------------------*/

/*-- main
--*/
int main (int argc, char *argv[])
{
	int fd0, fd1, fd2;

	if (argc<1) { printf(help); exit(0); }
	if (argc==2 && !strcmp(argv[1],"--help")) { printf(help); exit(0); }
	if (argc==2 && !strcmp(argv[1],"--version")) { printf(version); exit(0); }
	if (argc==2 && !strcmp(argv[1],"--warranty")) { printf(warranty); exit(0); }
	while (argc>1)
	{
		if (argc>2 && !strcmp(argv[1],"-d"))
		    { device=argv[2]; argc-=2; argv+=2; continue; }
		if (argc>2 && !strcmp(argv[1],"-s"))
		    { script=argv[2]; argc-=2; argv+=2; continue; }
		printf(help); exit(1);
	}

	chdir("/");
	close(0); close(1); close(2);
	fd0=open("/dev/null",O_RDONLY|O_NOCTTY);
	fd1=open("/dev/console",O_WRONLY|O_NOCTTY|O_NDELAY);
	fd2=dup(fd1);
	if (fd0!=0 || fd1!=1 || fd2!=2)
	    logging(6,"Something not okay with stdin/stdout/stderr");

	/*-- Some say opening the device pulls rts high for a moment,
	     so ups may turn off. Therefore be very very careful --*/
	sync(); sync(); sync();
	tsleep(1);
	sync(); sync(); sync();
	fd=open(device,O_RDWR|O_NOCTTY|O_NDELAY);
	if (fd==-1)
	{
		sprintf(temp,"FAILED to open %s",device);
		logging(6,temp);
	}
	if (flock(fd,LOCK_EX|LOCK_NB))
	{
		sprintf(temp,"FAILED to lock %s",device);
		logging(6,temp);
	}
	ioctl(fd,TIOCMBIS,&pullup);
	sync();
	ioctl(fd,TIOCMBIC,&killpwr);
	sync();
	/*-- Huh, survived --*/

	pid=fork();
	if (pid==-1) logging(6,"FAILED to fork");
	if (pid>0) exit(0);
	mypid=getpid();
	if (setpgrp()) logging(6,"setpgrp FAILED");
	logging(1,"started");

	signal(SIGTERM,SIG_IGN);
	signal(SIGHUP,SIG_IGN);
	signal(SIGINT,sigint);
	signal(SIGQUIT,sigquit);
	signal(SIGPWR,sigpwr);
	signal(SIGUSR1,sigusr1);

	tsleep(1);
	ioctl(fd,TIOCMGET,&flags);
	while (!cable_ok());
	{
		tsleep(2);
		ioctl(fd,TIOCMGET,&flags);
	}
	linefail=(flags&PIN_LINEFAIL)==0;
	battlow=(flags&PIN_BATTLOW)==0;
	initial_state();

	tsleep(1);
	while (1)
	{
		ioctl(fd,TIOCMGET,&flags);

		if (!cable_ok())
		{
			tsleep(2);
			continue;
		}

		check_for_signal();

		battlow_old=battlow;
		battlow=(flags&PIN_BATTLOW)==0;
		if (battlow!=battlow_old)
		{
			batt_low();
			tsleep(1);
			continue;
		}

		linefail_old=linefail;
		linefail=(flags&PIN_LINEFAIL)==0;
		if (linefail!=linefail_old)
		{
			line_fail();
			tsleep(1);
			continue;
		}

		tsleep(10);
	}
}

