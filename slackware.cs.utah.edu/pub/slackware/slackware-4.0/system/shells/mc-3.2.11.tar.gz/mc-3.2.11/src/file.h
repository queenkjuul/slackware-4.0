#ifndef __FILE_H
#define __FILE_H

enum { OP_COPY, OP_MOVE, OP_DELETE };
enum { FILE_CONT, FILE_RETRY, FILE_SKIP, FILE_ABORT };

extern int verbose;
extern int know_what_am_i_doing;

int copy_file_file (char *s, char *d, int toplevel, int ask_overwrite);
int erase_dir (char *s);
int copy_dir_dir (char *s, char *d, int toplevel, int move_over);
int move_dir_dir (char *s, char *d);

void create_op_win (int op);
void destroy_op_win (void);
void refresh_op_win (void);
int panel_operate (int op, char *thedefault);

extern int dive_into_subdirs;

#endif
