#ifndef __OPTION_H
#define __OPTION_H
void configure_box (void);
#endif 
