#ifndef __HOTLIST_H
#define __HOTLIST_H

void add2hotlist_cmd (void);
char *hotlist_cmd (int list_vfs);
void load_hotlist (void);
void save_hotlist (void);
void done_hotlist (void);

#endif
