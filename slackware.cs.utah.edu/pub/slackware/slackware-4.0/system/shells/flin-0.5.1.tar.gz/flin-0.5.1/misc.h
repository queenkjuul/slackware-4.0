#if !defined (_MISC_H)
#   define _MISC_H

void error(char *str, int line);
void *chk_alloc(size_t size);

#endif
