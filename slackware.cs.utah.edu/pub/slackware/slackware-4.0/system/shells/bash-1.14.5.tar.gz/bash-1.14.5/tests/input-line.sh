echo before calling input-line.sub
../bash ./input-line.sub
this line for input-line.sub
echo finished with input-line.sub
