/*
 * value of $KSH_VERSION (or $SH_VERSION)
 */

#include "sh.h"

const char ksh_version [] =
	"@(#)PD KSH v5.2.8 96/08/19";
