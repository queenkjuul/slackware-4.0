/************************************************************************\
|* config.c -- Configuration file for the INSANITY Shell Config Program *|
|* (c) 1997 Project INSANITY Software.  By Steve Conley.  Edit this file*|
|* to your system setup.                                                *|
\************************************************************************/

/* The filename below is the file this program should edit.  This
 * should be either .cshrc, .mycshrc, or some other scriptfile called
 * by the /etc/csh.login file.  On my system, I use .insanerc.
 * User's homedir path is prepended, just put a / before the filename
 * (ie /.cshrc or /.insanerc)
 */
char* DEF_FILE="/.insanerc";

/* This is what is automatically inserted when someone creates a
 * new file.  This should have any global vars someone would need
 * if its a .cshrc (ie path and such).  You shouldn't need anything
 * if you have your /etc/csh.login calling .mycshrc or .insanerc.
 */
char* autoinsert="";

/* Here's a sample autoinsert....
char* autoinsert=
"set path=( /usr/bin /bin /usr/local/bin . )\n"
"set prompt=\"Default Prompt\"\n";

 * Please note you have to be cautious; you need a \" if you
 * want a " in the text so as not to confuse the compiler, and
 * a \n is a newline.
*/

/* No more system definable stuff */
