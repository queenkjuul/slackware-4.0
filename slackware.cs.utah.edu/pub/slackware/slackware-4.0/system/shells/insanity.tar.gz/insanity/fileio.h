/********************************************************************\
|* fileio.h -- File Input/Output Structures and Functions           *|
|* (c) 1997 Project INSANITY Software by Steve Conley.  Do not copy *|
|* or modify without permission.                                    *|
\********************************************************************/

#ifndef _INS_FILEIO_
#define _INS_FILEIO_

struct line{
	int  len;
	int  lineno;
	char* ln;
	struct line* next;
};

void save(struct line* lines,char* filename);
void readin(char* filename,struct line* readto);
void addln(struct line* lines,char* toadd);
void rmln(struct line* lines,int linenum);
void echo(struct line* lines);

#endif
