/********************************************************************\
|* getuserpath.c -- Gets the user's path from the passwd file.      *|
|* (c) 1997 Project INSANITY Software.  By Steve Conley.  Do not    *|
|* modify/edit.                                                     *|
\********************************************************************/
#include <stdio.h>
#include <stdlib.h>

/* Note this may not work with shadowed passwords */
#define passfile "/etc/passwd"

char* getuserpath(int uid);

char* getuserpath(int uid){
	FILE* passwd;
	char* result;
	char* swap=(char*)malloc(sizeof(char));
	char  buf[256];
	char* numstr=(char*)malloc(sizeof(char)*10);
	int   num=0;
	int   id;
	int   len,len2,numlen;
	int   found=0;
	passwd=fopen(passfile,"r");
	if(!passwd){
		printf("No password file!  Possibly non-UNIX system?\n\r");
		return NULL;
	}
	while((!found)&&(!feof(passwd))){
		len=0;
		num=0;
		numlen=0;
		while(num < 2){
			fread(swap,sizeof(char),1,passwd);
			buf[len]=*swap;
			if(buf[len]==':'){
				num++;
			}
			len++;
		}
		fread(swap,sizeof(char),1,passwd); 
		while(*swap!=':'){
			numstr[numlen]=*swap;
			numlen++;
			fread(swap,sizeof(char),1,passwd);
		}
		id=atoi(numstr);
		if(id==uid){
			found=1;
		}else{
			while(*swap!='\n'){
				fread(swap,sizeof(char),1,passwd);
			}
		}
	}
	if(feof(passwd))
		return(NULL);
	result=(char*)malloc(sizeof(char)*8000);
	len=0;
	num=0;
	len2=-1;
	while((buf[len-1]!='\n')||(len==0)){
		fread(swap,sizeof(char),1,passwd);
		buf[len]=*swap;
		if(buf[len]==':')
			num++;
		len++;
		if((num==2)&&(len2==-1))
			len2=len;
	}
	num=0;
	while(buf[len2]!=':'){
		result[num]=buf[len2];
		num++;
		len2++;
	}
	return result;
}
