/*************************************************************************
** interpcom-1.2  (command interpreter)                                  **
** command.c : Some commands                                             **
**                                                                       **
** Copyright (C) 1999  Jean-Marc Drezet                                  **
**                                                                       **
**  This library is free software; you can redistribute it and/or        **
**  modify it under the terms of the GNU Library General Public          **
**  License as published by the Free Software Foundation; either         **
**  version 2 of the License, or (at your option) any later version.     **
**									 **
**  This library is distributed in the hope that it will be useful,      **
**  but WITHOUT ANY WARRANTY; without even the implied warranty of       **
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    **
**  Library General Public License for more details. 			 **
**									 **
**  You should have received a copy of the GNU Library General Public    **
**  License along with this library; if not, write to the Free		 **
**  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.   **
**                                                                       **
** Please mail any bug reports/fixes/enhancements to me at:              **
**      drezet@math.jussieu.fr                                           **
** or                                                                    **
**      Jean-Marc Drezet                                                 **
**      Institut de Mathematiques                                        **
**      Aile 45-55                                                       **
**      2, place Jussieu                                                 **
**      75251 Paris Cedex 05                                             **
**      France								 **
**                                                                       **
 *************************************************************************/

#include "interp.h"
char	h[200];



/*--------------------------------------------------------------------
    Function associated to the command 'exit'.
--------------------------------------------------------------------*/
int
exit_cmd(int argc, char *argv[])
{
    exit_prog();
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to  the command 'loopf'
--------------------------------------------------------------------*/
int 
bouclex_f(int argc, char *argv[])
{
    FILE           *stream;
    char            g[50],
                    h[150];
    int             i,
                    j,
                    inb;
    float           deb,
                    incr;

    strcpy(g, "<");
    strcpy(h, command_rep);
    strcat(h, argv[1]);
    stream = fopen(h, "w");
    if (stream == NULL) {
	err_mess(1);
	return 1;
    }
    strcat(g, argv[2]);
    inb = convert_int(argv[3]);
    deb = convert_float(argv[4]);
    incr = convert_float(argv[5]);

    for (i = 0; i < inb; i++) {
	fprintf(stream, "%s %f ", g, i * incr + deb);
	for (j = 6; j < argc; j++)
	    fprintf(stream, "%s ", argv[j]);
	fprintf(stream, "\n");
    }

    fclose(stream);
    return 0;
}
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Function associated to the command 'loop'
--------------------------------------------------------------------*/
int 
bouclex(int argc, char *argv[])
{
    FILE           *stream;
    char            g[50],
                    h[150];
    int             i,
                    j,
                    inb,
                    deb,
                    incr;

    strcpy(g, "<");
    strcpy(h, command_rep);
    strcat(h, argv[1]);
    stream = fopen(h, "w");
    if (stream == NULL) {
	err_mess(1);
	return 1;
    }
    strcat(g, argv[2]);
    inb = convert_int(argv[3]);
    deb = convert_int(argv[4]);
    incr = convert_int(argv[5]);

    for (i = 0; i < inb; i++) {
	fprintf(stream, "%s %d ", g, i * incr + deb);
	for (j = 6; j < argc; j++)
	    fprintf(stream, "%s ", argv[j]);
	fprintf(stream, "\n");
    }

    fclose(stream);
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'repete'
--------------------------------------------------------------------*/
int 
repetex(int argc, char *argv[])
{
    FILE           *stream;
    char            g[50],
                    h[150];
    int             i,
                    j,
                    inb;

    strcpy(h, command_rep);
    strcat(h, argv[1]);
    stream = fopen(h, "w");
    if (stream == NULL) {
	err_mess(1);
	return 1;
    }
    strcpy(g, "<");
    strcat(g, argv[2]);
    inb = convert_int(argv[3]);
    if (inb < 1) {
	err_mess(2);
	return 1;
    }
    if (argc < 4 + inb) {
	err_mess(0);
	return 1;
    }

    for (i = 0; i < inb; i++) {
	fprintf(stream, "%s %f ", g, convert_float(argv[4 + i]));
	for (j = 4 + inb; j < argc; j++)
	    fprintf(stream, "%s ", argv[j]);
	fprintf(stream, "\n");
    }

    fclose(stream);
    return 0;
}
/*------------------------------------------------------------------*/



/*-------------------------------------------------------------------
    Function associated to the command 'echo'
-------------------------------------------------------------------*/  
int
echo_cmd(int argc, char *argv[])
{
    int 	    i,
                    j;
    char 	    h[3];

    h[0] = 92;
    h[1] = 110;
    h[2] = 0;
    j = prlevel;
    prlevel = -1;

    for (i = 1; i < argc; i++) {
        if (comp(argv[i], h) == 1) {
	    print("\n");
	    fflush(stdout);
	}
        else {
	    print("%s ", argv[i]);
	    fflush(stdout);
	}
    }

    prlevel = j;
    return 0;
}
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Function associated to the command 'echoi'
--------------------------------------------------------------------*/
int
echo_int_cmd(int argc, char *argv[])
{
    int 	    i,
		    j,
		    k;
    char 	    h[3];

    k = prlevel;
    prlevel = -1;
    h[0] = 92;
    h[1] = 110;
    h[2] = 0;

    for (i = 1; i < argc; i++) {
        if (comp(argv[i], h) == 1) {
	    print("\n");
	    fflush(stdout);
        }
        else {
            j = convert_int(argv[i]);
	    print("%d ",j);
	    fflush(stdout);
	}
    }

    prlevel = k;
    return 0;
}
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Function associated to the command 'echof'
--------------------------------------------------------------------*/
int
echo_float_cmd(int argc, char *argv[])
{
    int 	    i,
		    j;
    float	    x;
    char 	    h[3];

    h[0] = 92;
    h[1] = 110;
    h[2] = 0;
    j = prlevel;
    prlevel = -1;

    for (i = 1; i < argc; i++) {
        if (comp(argv[i], h) == 1) {
	    print("\n");
	    fflush(stdout);
	}
        else {
            x = convert_float(argv[i]);
	    print("%f ", x);
	    fflush(stdout);
	}
    }

    prlevel = j;
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'editor'
--------------------------------------------------------------------*/
int
editeur(int argc, char *argv[])
{
    char 	    h[2000],
		    w[200];
    int 	    i,
		    ilev;
    FILE 	   *s;

    strcpy(w, command_rep);
    strcat(w, argv[1]);
    s = fopen(w, "w");
    if (s == NULL) {
	err_mess(1);
	return 0;
    }

xxx : memset(h, 0, 2000);
    fgets(h, 1999, inp[curvoice]);
    ilev = 0;
    i = 0;
    while (h[i] == 92) {
        i++;
	ilev++;
    }
    if (ilev == curvoice + 1) {
	fclose(s);
	return 1;
    }
    fputs(h, s);
    goto xxx;
}
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Function associated to the command 'delcom'
--------------------------------------------------------------------*/
int
delcom(int argc, char *argv[])
{
#ifndef _MSDOS_VERSION
    char 	    w[200];

    memset(w, 0, 200);
    strcpy(w, "rm -f ");
    strcat(w, command_rep);
    strcat(w, argv[1]);
    system(w);
#endif
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'delres'
--------------------------------------------------------------------*/
int
delres(int argc, char *argv[])
{
#ifndef _MSDOS_VERSION
    char 	    w[200];

    memset(w, 0, 200);
    strcpy(w, "rm -f ");
    strcat(w, result_rep);
    strcat(w, argv[1]);
    system(w);
#endif
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'deldat'
--------------------------------------------------------------------*/
int
deldon(int argc, char *argv[])
{
#ifndef _MSDOS_VERSION
    char 	    w[200];

    memset(w, 0, 200);
    strcpy(w, "rm -f ");
    strcat(w, data_rep);
    strcat(w, argv[1]);
    system(w);
#endif
    return 0;
}
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Function associated to the command 'si'
--------------------------------------------------------------------*/
int si_cmd(int argc, char *argv[])
{
    int		    i;

    if (argc > 2 && comp(argv[1],"non") != 1) {
	err_mess(3);
        return 1;
    }
    if (n_cond == __nbcond - 1) {
	err_mess(4);
	return 1;
    }
    n_cond++;
    memset(v_cond[n_cond], 0, 100);
    if (argc == 2) {
	s_cond[n_cond] = 1;
	i = 1;
    }
    else {
	s_cond[n_cond] = -1;
        i = 2;
    }
    strcpy(v_cond[n_cond], argv[i]);
    return 0;
}
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Function associated to the command 'is'
--------------------------------------------------------------------*/
int is_cmd(int argc, char *argv[])
{
    if (n_cond < 0)
	return 0;
    if (comp(v_cond[n_cond], argv[1]) != 1) {
        return 0;
    }
    n_cond--;
        return 0;
}
/*------------------------------------------------------------------*/




/*-------------------------------------------------------------------
    Function associated to the command 'write'
-------------------------------------------------------------------*/
int 
file_cmd(int argc, char *argv[])
{
    int		    i,
		    i0;
    char	    h[200];
    float	    x;

    i0 = -1;

    for (i = 0; i < __nss; i++) {
	if (sS[i] != NULL) {
	    if (comp(sS_nom[i], argv[1]) == 1) {
		i0 = i;
	        if (sS_i_o[i0] != 1) {
		    err_mess(29);
		    return 1;
		}
	    }
	}
    }

    if (i0 < 0) {
        for (i = 0; i < __nss; i++) {
	    if (sS[i] == NULL) {
		i0 = i;
                break;
            }
        }

        if (i0 < 0) {
	    err_mess(5);
            return 1;
        }
        memset(h, 0, 200);
        sprintf(h, "%s%s", result_rep, argv[1]);
   	sS[i0] = fopen(h, "a");
  	if (sS[i0] == NULL) {
	    err_mess(1);
	    return 1;
        }
        sS_nom[i0] = (char *) malloc( 100 * sizeof(char));
        sprintf(sS_nom[i0], "%s", argv[1]);  
	sS_i_o[i0] = 1;
    }

    if (comp(argv[2],"_ligne") == 1) {
	fprintf(sS[i0], "\n");
        return 0;
    }
    if (comp(argv[2],"-bin") == 1) {
	for (i = 3; i < argc; i++) {
	    x = convert_float(argv[i]);
            fwrite(&x, sizeof(float), 1 , sS[i0]);
        }
    }
    else {
        for (i = 2; i < argc; i++) {
            fprintf(sS[i0], "%f    ", convert_float(argv[i]));
            sS_cmpt[i0]++;
            if (sS_cmpt[i0] > 9)
	        fflush(sS[i0]);
        }
    
        fprintf(sS[i0], "\n");
    }  

    return 0;
}
/*------------------------------------------------------------------*/



/*-------------------------------------------------------------------
    Function associated to the command 'read'
-------------------------------------------------------------------*/
int 
fread_cmd(int argc, char *argv[])
{
    int		    i,
		    i0,
		    ind;
    char	    h[200];
    float	    x;

    i0 = -1;

    for (i = 0; i < __nss; i++) {
	if (sS[i] != NULL) {
	    if (comp(sS_nom[i], argv[1]) == 1) {
		i0 = i;
	        if (sS_i_o[i0] != -1) {
		    err_mess(30);
		    return 1;
		}
	    }
	}
    }

    if (i0 < 0) {
        for (i = 0; i < __nss; i++) {
	    if (sS[i] == NULL) {
		i0 = i;
                break;
            }
        }

        if (i0 < 0) {
	    err_mess(5);
            return 1;
        }
        memset(h, 0, 200);
        sprintf(h, "%s%s", result_rep, argv[1]);
   	sS[i0] = fopen(h, "r");
  	if (sS[i0] == NULL) {
	    err_mess(1);
	    return 1;
        }
        sS_nom[i0] = (char *) malloc( 100 * sizeof(char));
        sprintf(sS_nom[i0], "%s", argv[1]); 
	sS_i_o[i0] = -1; 
    }

    x = 0.0;
    if (argc <= 3 || comp(argv[2],"-bin") != 1) { 
        fscanf(sS[i0], "%f", &x);
        memset(h, 0, 200);
        ind = 0;
    }
    else {
	fread(&x, 4, 1, sS[i0]);
	ind = 1;
    }
    sprintf(h, "%s=%f", argv[2 + ind], x);
    convert_float(h);
    return 0;
}
/*------------------------------------------------------------------*/




/*-------------------------------------------------------------------
     Function associated to the command 'close'
--------------------------------------------------------------------*/
int
close_file_cmd(int argc, char *argv[])
{
    int		    i,
		    i0;

    i0 = -1;

    for (i = 0; i < __nss; i++) {
	if (sS[i] != NULL) {
	    if (comp(sS_nom[i], argv[1]) == 1)
		i0 = i;
	}
    }

    if (i0 < 0) {
	err_mess(6);
        return 1;
    }
    fclose(sS[i0]);
    sS[i0] = NULL;
    free(sS_nom[i0]);
    sS_cmpt[i0] = 0;
    sS_i_o[i0] = 0;
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'question'
--------------------------------------------------------------------*/
int
question_cmd(int argc, char *argv[])
{
    int		    ii,
		    j,
		    n_quest;
    FILE 	   *s;
    char 	    h[100],
		    k[300],
		    k2[300],
                   *v;
    float	    x;

    if (argc >= 2) {
        memset(h, 0, 100);
        strcpy(h, command_rep);
        strcat(h, argv[1]);
        s = fopen(h, "r");
        if (s == NULL) {
	    err_mess(1);
	    return 1;
        }
        if (fscanf(s, "%d", &n_quest) == EOF) {
	    err_mess(7);
	    return 1;
        }
        if (n_quest < 1) {
  	    err_mess(2);
	    return 1;
        }
        fgets(k, 299, s);

        for (j = 0; j < n_quest; j++) {
            memset(k, 0, 300);
            memset(k2, 0, 300);

  	    if (fgets(k, 299, s) == NULL) {
	        err_mess(7);
                fclose(s);
	        return 1;
            }
            if ((int) strlen(k) < 2) {
	        err_mess(7);
                fclose(s);
	        return 1;
            }
            nettoie(k);
            if (prlevel <= 0) {
                print("%s ", k);
            }
            memset(k, 0, 100);
	    if (fgets(k, 299, s) == NULL) {
	        err_mess(7);
                fclose(s);
	        return 1;
            }
            nettoie(k);
            if (k[0] != '$') {
                scanf("%f", &x);
                sprintf(k2, "%s=%f", k, x);
                convert_float(k2);
            }
            else {
	        if ((int) strlen(k) < 2) {
	            err_mess(7);
                    fclose(s);
	            return 1;
                }
                v = k + 1;
	        ii = convert_int(v);
	        if (ii < 0 || ii > __max_quest) {
	            err_mess(7);
                    fclose(s);
	            return 1;
                }
                memset(h, 0, 100);
                fgets(h, 299, inp[curvoice]);
                nettoie(h);
                if (strlen(h) > 0) {
     		    memset(ques[ii], 0, 300);
		    strcpy(ques[ii], h);
		}
            }
        }

        fclose(s);
        return 0;
    }
    else {
	read_int(&n_quest);
   	if (n_quest <= 0) {
	    err_mess(7);
	    return 1;
 	}

        for (j = 0; j < n_quest; j++) {
            memset(h, 0, 100);
            read_char(h);
	    memset(k, 0, 100);
            read_char(k);
            v = k + 1;
            ii = convert_int(v);
	    if (ii < 0 || ii > __max_quest) {
	        err_mess(7);
	        return 1;
            }
            if (strlen(h) > 0) {
     		memset(ques[ii], 0, 300);
		strcpy(ques[ii], h);
	    }
	}
    }
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'varlist'
---------------------------------------------------------------------*/
int
var_list_cmd(int argc, char *argv[])
{
    int 	    i;

    for (i = 0; i < MAXXVARS; i++) {
	if ((int) strlen(Vars[i].name) > 0) {
	    if (prlevel <= 0 && Vars[i].name[0] < 127) {
		print("%s = %f\n", Vars[i].name, (float)Vars[i].value);
            }
	}
    }

    return 0;
}
/*------------------------------------------------------------------*/




/*-------------------------------------------------------------------
    Function associated to the command 'undef'
--------------------------------------------------------------------*/
int
undef_cmd(int argc, char *argv[])
{
    int 	    i,
		    j;

    for (i = 0; i < MAXXVARS; i++) {
	if (comp(argv[1], Vars[i].name) == 1) 
	    for (j = 0; j <= XVARLEN; j++)
	 	Vars[i].name[j] = 0;

    }

    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'silence'
--------------------------------------------------------------------*/
int 
silence_cmd(int argc, char *argv[])
{
    if (convert_int(argv[1]) == 0) 
	prlevel = 1;
    else prlevel = 0;

    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'clock'
--------------------------------------------------------------------*/
int
temps(int argc, char *argv[])
{
    int             i;

    i = convert_int(argv[1]);
    horloge = 0;
    if (i != 0)
	horloge = 1;
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'proglist'
--------------------------------------------------------------------*/
int
proglist_cmd(int argc, char *argv[])
{
    int             i,
		    j,
		    l;
    char	    h[200],
		    k[20],
		   *v;

    if (prlevel > 0)
        return 0;
    if (argc == 1) {
	for (i = 0; i < nb_com; i++) {
	    print("%s\n", nom_com[i]);
        }
        return 0;
    }

    for (i = 0; i < nb_com; i++) {
	if (comp(nom_com[i], argv[1]) == 1) {
            for (j = 0; j < nb_lignes[i]; j++) {
                memset(h, 0, 200);

		for (l = 0; l < nb_label[i]; l++) 
                    if (num_label[i][l] == j) {
                        memset(k, 0, 20);
                        sprintf(k, "%d: \n", l);
                       /* strcat(h, k);*/
                        printf(k);
		    }
        
                v = ligne_com[i][j];
                if (ligne_com[i][j][0] == _GOTO) {
 		    v = ligne_com[i][j] + 1;
		    strcat(h, "goto ");
                }
                if (ligne_com[i][j][0] == _IFGT) {
 		    v = ligne_com[i][j] + 1;
		    strcat(h, "if>");
                }
                if (ligne_com[i][j][0] == _IFLT) {
 		    v = ligne_com[i][j] + 1;
		    strcat(h, "if<");
                }
                if (ligne_com[i][j][0] == _IFEQ) {
 		    v = ligne_com[i][j] + 1;
		    strcat(h, "if=");
                }
                if (ligne_com[i][j][0] == _EVAL) {
 		    v = ligne_com[i][j] + 1;
                }
                strcat(h, v);
                print("%s\n", h);
            }
            
            memset(h, 0, 200);

            for (l = 0; l < nb_label[i]; l++)
                if (num_label[i][l] >= nb_lignes[i]) {
		    memset(k, 0, 20);
                    sprintf(k, "%d: ", l);
                    strcat(h, k);
                }

            if ((int) strlen(h) > 0) {
		print("%s\n", h);
            }
            return 0;
        }
    }
    err_mess(24);
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'load'
--------------------------------------------------------------------*/
int 
load_cmd(int argc, char *argv[])
{
    char	    h[200];
    
    memset(h, 0, 200);
    strcpy(h, command_rep);
    strcat(h, argv[1]);
    charge_com(h, NULL, 0);
    traite_label();
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'shell'
--------------------------------------------------------------------*/
int 
shell_cmd(int argc, char *argv[])
{
    char	    h[300];
    int		    i;    

    memset(h, 0, 300);
    for (i = 1; i < argc; i++) {   
	strcat(h, argv[i]);
        strcat(h, " ");
    }

    system(h);
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function that shows the hidden variables of the Expr.Ev.
--------------------------------------------------------------------*/
void
init_var(void)
{
    int 	    i;
    char	    h[100],
		   *k;

    for (i = 0; i < MAXXVARS; i++) {
	if ((int) strlen(Vars[i].name) > 0) {
	    if (Vars[i].name[0] == 127) {
                memset(h, 0, 100);
	   	k = Vars[i].name + 1;
                strcpy(h, k);
                strcat(h, "=");
                strcat(h, Vars[i].name);
                convert_int(h);
            }
        }
    }
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'initvar'
--------------------------------------------------------------------*/
int
init_var_cmd(int argc, char *argv[])
{
    init_var();
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'numcom'
--------------------------------------------------------------------*/
int
num_com(int argc, char *argv[])
{
    if (convert_int(argv[1]) != 0)
	pr_com = 1;
    else
	pr_com = 0;
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'hist'
--------------------------------------------------------------------*/
int
hist_cmd(int argc, char *argv[])
{
    int		    i,
		    j;

    j = i_com + 1;

    for (i = 0; i < __n_com_prec; i++) {
	j--;
        if (j < 0)
	    j = __n_com_prec - 1;
	if (ix_com - i > 0 && prlevel <= 0) {
	    print("    %d    %s\n", ix_com - i - 1, com_prec[j]);
	}
    }

    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'mon'
--------------------------------------------------------------------*/
int
mon_cmd(int argc, char *argv[])
{
    if (Mon_File != NULL)
	fclose(Mon_File);
    Mon_File = fopen(argv[1], "w");
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'end_mon'
--------------------------------------------------------------------*/
int
fin_mon_cmd(int argc, char *argv[])
{
    if (Mon_File != NULL)
	fclose(Mon_File);
    Mon_File = NULL;
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    clone of 'printf' that prints also in a monitor file
--------------------------------------------------------------------*/
void
print(char *fo, ...)
{
    va_list 	    ap;
    int		    i,
		    i_val,
                    icmpt,
                    icmpt2,
                    n_arg,
                    len;
    float	    f_val;
    char 	   *pr,
                    h[100];
    
    va_start(ap, fo);
    pr = NULL;
    if (prlevel > 0)
	goto fin;
    len = strlen(fo);
    n_arg = 0;
    for (i = 0; i < len; i++)
	if (fo[i] == '%')
	    n_arg++;
    if (n_arg == 0) {
	pr = ch_copy(fo);
        goto impr;
    }
    pr = (char *) malloc(250 * sizeof(char));
    memset(pr, 0, 250);
    icmpt = 0;
    icmpt2 = 0;

    for (i = 0; i < n_arg; i++) {
        while (fo[icmpt] != '%') {
	    pr[icmpt2++] = fo[icmpt++];
        }

        icmpt++;
        if (icmpt > len)
	    goto fin;

        if (fo[icmpt] !=  's' && fo[icmpt] != 'd' && fo[icmpt] != 'f')
	    goto fin;
        if (fo[icmpt] == 's') {
	    memset(h, 0, 100);
            sprintf(h, "%s", va_arg(ap, char*));
        }
	if (fo[icmpt] == 'd') {
	    memset(h, 0, 100);
            i_val = va_arg(ap, int);
            sprintf(h, "%d", i_val);
        }
	if (fo[icmpt] == 'f') {
	    memset(h, 0, 100);
            f_val = va_arg(ap, double);
            sprintf(h, "%g", f_val);
        }
        icmpt++;
        strcat(pr, h);
        icmpt2 += strlen(h);
    }

    for (i = icmpt; i < len; i++) {
        pr[icmpt2] = fo[i];
	icmpt2++;
    }

impr : printf(pr);
    if (Mon_File != NULL)
	fprintf(Mon_File, pr);

fin : if (pr != NULL)
	free(pr);
    va_end(ap);
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'flush'
--------------------------------------------------------------------*/
int
flush_cmd(int argc, char *argv[])
{
    if (Mon_File != NULL)
	fflush(Mon_File);
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'greet'
--------------------------------------------------------------------*/
int
greetb_cmd(int argc, char *argv[])
{
    int 	    i;

    for (i = 0; i < i_greet; i++)
         if (prlevel <= 0)
	     printf("%s\n", greet[i]);
    return 0;
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function printing the message i
--------------------------------------------------------------------*/
void
error_mess(int i)
{
    printf("                      ; %s\n", mess[i]);
    if (Mon_File != NULL)
        fprintf(Mon_File, "                      ; %s\n", mess[i]);
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function opening a file whose name has two parts
--------------------------------------------------------------------*/
FILE
*Copen(char *debut, char *fin, char *format)
{
    memset(h, 0, 200);
    strcpy(h, debut);
    strcat(h, fin);
    return fopen(h, format);
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function opening a file whose name has three parts
--------------------------------------------------------------------*/
FILE
*CCopen(char *debut, char *milieu, char *fin, char *format)
{
    memset(h, 0, 200);
    sprintf(h, "%s%s%s", debut, milieu, fin);
    return fopen(h, format);
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function opening a file whose name is made with two character
    strings and an integer
--------------------------------------------------------------------*/
FILE
*CIopen(char *debut, char *fin, char *format, int i)
{
    memset(h, 0, 200);
    sprintf(h, "%s.%s.%d", debut, fin, i);
    return fopen(h, format);
}
/*------------------------------------------------------------------*/




/*--------------------------------------------------------------------
    Function associated to the command 'time'
--------------------------------------------------------------------*/
int
time_cmd(int argc, char *argv[])
{
    long	    i;

    if (argc > 1)
	time(&i_time_x);
    else {
        time(&i);
#ifdef _ENG_LANG
	print("Time : %d s\n", i - i_time_x);
#else
	print("Temps : %d s\n", i - i_time_x);
#endif
    }
    return 0;
}
/*------------------------------------------------------------------*/
