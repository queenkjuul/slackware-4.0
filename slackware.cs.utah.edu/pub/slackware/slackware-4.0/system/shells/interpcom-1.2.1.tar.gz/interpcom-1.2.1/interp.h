/*************************************************************************
** interpcom-1.2    (command interpreter)                                **
** interp.h      Command interpreter  	                                 **
**                                                                       **
** Copyright (C) 1999  Jean-Marc Drezet                                  **
**                                                                       **
**  This library is free software; you can redistribute it and/or        **
**  modify it under the terms of the GNU Library General Public          **
**  License as published by the Free Software Foundation; either         **
**  version 2 of the License, or (at your option) any later version.     **
**									 **
**  This library is distributed in the hope that it will be useful,      **
**  but WITHOUT ANY WARRANTY; without even the implied warranty of       **
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    **
**  Library General Public License for more details. 			 **
**									 **
**  You should have received a copy of the GNU Library General Public    **
**  License along with this library; if not, write to the Free		 **
**  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.   **
**                                                                       **
** Please mail any bug reports/fixes/enhancements to me at:              **
**      drezet@math.jussieu.fr                                           **
** or                                                                    **
**      Jean-Marc Drezet                                                 **
**      Institut de Mathematiques                                        **
**      Aile 45-55                                                       **
**      2, place Jussieu                                                 **
**      75251 Paris Cedex 05                                             **
**      France								 **
**                                                                       **
 *************************************************************************/

#ifndef _INTERPCOM
#define _INTERPCOM

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>
#include <setjmp.h>




/*--------------------------------------------------------------------
----------------------------------------------------------------------
    This is the file "ee.h" of the Expression Evaluator of Mark Morley
----------------------------------------------------------------------
--------------------------------------------------------------------*/
/* Some of you may choose to define TYPE as a "float" instead...  */
#define TYPE            double    /* Type of numbers to work with */
#define XVARLEN          15       /* Max length of variable names */
#define MAXXVARS         500      /* Max user-defined variables   */
#define TOKLEN          30        /* Max token length             */

#define XVAR             1
#define DEL             2
#define NUM             3

typedef struct
{
   char name[XVARLEN + 1];               /* Variable name */
   TYPE value;                           /* Variable value */
} XVARIABLE;

typedef struct
{
   char* name;                 /* Function name */
   int   args;                 /* Number of arguments to expect */
   TYPE  (*func)();            /* Pointer to function */
} FUNCTION;

/* The following macros are ASCII dependant, no EBCDIC here! */
#define iswhite(c)  (c == ' ' || c == '\t')
#define isnumer(c)  ((c >= '0' && c <= '9') || c == '.')
#define isalphab(c)  ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') \
                    || c == '_' || c == 127 || (c >= 'A' && c <= 'Z'))
#define isdelim(c)  (c == '+' || c == '-' || c == '*' || c == '/' || c == '%' \
                    || c == '^' || c == '(' || c == ')' || c == ',' || c == '=')

/* Codes returned from the evaluator */
#define E_OK           0        /* Successful evaluation */
#define E_SYNTAX       1        /* Syntax error */
#define E_UNBALAN      2        /* Unbalanced parenthesis */
#define E_DIVZERO      3        /* Attempted division by zero */
#define E_UNKNOWN      4        /* Reference to unknown variable */
#define E_MAXXVARS     5        /* Maximum variables exceeded */
#define E_BADFUNC      6        /* Unrecognised function */
#define E_NUMARGS      7        /* Wrong number of arguments to funtion */
#define E_NOARG        8        /* Missing an argument to a funtion */
#define E_EMPTY        9        /* Empty expression */


/********************************************************************
**                                                                  **
** PROTOTYPES FOR CUSTOM MATH FUNCTIONS                             **
**                                                                  **
 ********************************************************************/

double deg( double x );
double rad( double x );


/********************************************************************
**                                                                  **
** XVARIABLE DECLARATIONS                                           **
**                                                                  **
 ********************************************************************/

int   ERROR;            /* The error number */
char  ERTOK[TOKLEN + 1];/* The token that generated the error */
int   ERPOS;            /* The offset from the start of the expression */
char* ERANC;            /* Used to calculate ERPOS */

extern XVARIABLE Consts[];
FUNCTION *Funcs;
extern FUNCTION Funcs_interp[];
int _NBFONC;
int _NBFONC0;

XVARIABLE        Vars[MAXXVARS];  /* Array for user-defined variables */
unsigned char*  expression;       /* Pointer to the user's expression */
unsigned char   token[TOKLEN + 1];/* Holds the current token */
int             type;             /* Type of the current token */
jmp_buf         jb;               /* jmp_buf for errors */


void   		strlwr2( char* s );
/*-------- End of "ee.h" ---------------------------------------------
--------------------------------------------------------------------*/






/*--------------------------------------------------------------------
----------------------------------------------------------------------
    Definition of complex numbers
----------------------------------------------------------------------
--------------------------------------------------------------------*/
typedef struct FCOMPLEX {
    float           r,
                    i;
} fcomplex;
typedef struct DCOMPLEX {
    double          r,
                    i;
} dcomplex;
typedef struct FPOLAIRE {
    float           rm,
                    th;
} fpolaire;
typedef struct DPOLAIRE {
    double          rm,
                    th;
} dpolaire;
/*--------------------------------------------------------------------
--------------------------------------------------------------------*/





/*--------------------------------------------------------------------
----------------------------------------------------------------------
    Memory management structures
----------------------------------------------------------------------
--------------------------------------------------------------------*/
typedef struct _MEMM {
    int		       dim;
    char            ***ad;
    int                type;
    int		       prof;
} memm;

int             cmpt_mem,
                ind_mem;

typedef	  int		(*i_fonc)();
typedef   double	(*d_fonc)();
typedef   fcomplex	(*fc_fonc)();
typedef   dcomplex	(*dc_fonc)();
typedef   fpolaire	(*fp_fonc)();
typedef   dpolaire	(*dp_fonc)();

typedef struct T_FONC {
    i_fonc	F_i;
    d_fonc	F_d;
    fc_fonc	F_fc;
    dc_fonc	F_dc;
    fp_fonc	F_fp;
    dp_fonc	F_dp;
} T_fonc;

typedef struct CC_FONC {
    d_fonc	CF_d;
    d_fonc      PF_d;
} CC_fonc;

extern T_fonc T_add; 
extern T_fonc T_sub;
extern T_fonc T_mult;
extern T_fonc T_inv; 
extern T_fonc T_Rmul; 
extern T_fonc R_cnst;
extern T_fonc C_mul;
extern T_fonc C_cnst;
extern T_fonc Rpol_cnst; 
extern T_fonc Thpol_cnst;
extern T_fonc T_id;
extern T_fonc C_conjg;
extern T_fonc C_Complex;
extern T_fonc C_Polaire;
extern CC_fonc CC_Reel;
extern CC_fonc CC_R;
extern CC_fonc CC_Imag;
extern CC_fonc CC_Th;

#define TEST_ALLOC(x) null_alloc((char *)(x))
#define XFREE(x) Xfree_b((char **)(x))
#define _INITIALISE    0
#define _NONINITIALISE 1
/*--------------------------------------------------------------------
--------------------------------------------------------------------*/



#ifdef _MSDOS_VERSION
#include "unixfic.h"
#define fopen Xfopen
#endif

typedef int 	(*pfi)(int argc, char *argv[]);
typedef int 	(*pfib)(FILE *, char *);
typedef char    *argv_t[20];
typedef char 	v_c[300];





/*--------------------------------------------------------------------
----------------------------------------------------------------------
    Definition of objects and structures
----------------------------------------------------------------------
--------------------------------------------------------------------*/
typedef struct TYPE_OBJET {
    int		    type;
    int  	    nombre;
    int		    nbdim;
    char 	  **nom_dim;
    char	   *nom;
    char	   *comment;
    char	   *alias;
} obj_typ;

typedef struct _OBJET {
    obj_typ	   *typ_obj;
    char           *adresse;
    int		    occup;
    char	   *nom_obj;
    int		   *dim;
} obj;
  

typedef struct TYPE_STRUC {
    int		    nb_membres;
    int		   *type_mb;
    char	  **membre_id;
    char	   *nom;
    char	   *comment;
    int		    nombre;
} struc_typ;

typedef struct _STRUC {
    char	   *nom_struc;
    int		    occup;
    struc_typ	   *type;
    char	  **nom_mb;
} strucb;
/*--------------------------------------------------------------------
--------------------------------------------------------------------*/


      


/*--------------------------------------------------------------------
----------------------------------------------------------------------
    Function prototypes
----------------------------------------------------------------------
--------------------------------------------------------------------*/
/*
 *   com_sys.c
 */
int		lookup_b(char *);
void		execute(int i, int argc, char *argv[]);
void		charge_com(char *, char int_ini_c[], int);
void		interp_com(FILE *, char *);
int		mode_cmd(FILE *, char *);
int		greet_cmd(FILE *, char *);
int             gr_cmd(FILE *, char *, char **, int *, int);
int		func_cmd(FILE *, char *);
int             mess_cmd(FILE *, char *);
int             test_param(int, int);
int		param_cmd(FILE *, char *);
int		var_cmd(FILE *, char *);
int		init_interp_cmd(FILE *, char *);
void	        exit_sys(void);
void		exit_interp(char *);
void		err_mess(int);
void		traite_label(void);
void		extrait_argv_com(int, int *, int, char *argv_com[]); 
void		supprime_ligne_com(int, int);
void		insere_ligne_com(int, int, char *);
int		exist_com(char *);
void		ch_prem(void);
int		est_avant(int, int);
void		echange_nom(int, int);
int		delprog_cmd(int argc, char *argv[]);
char		*__Xdecode(char xg[], int, char *);
void            __perms(char *, char *);
char		__chx(int);
int		include_cmd(FILE *, char *);

/*
 *  command.c
 */
int 		bouclex(int argc, char *argv[]);
int 		bouclex_f(int argc, char *argv[]);
int		echo_cmd(int argc, char *argv[]);
int 		repetex(int argc, char *argv[]);
int 		editeur(int argc, char *argv[]);
int 		delcom(int argc, char *argv[]);
int 		deldon(int argc, char *argv[]);
int 		delres(int argc, char *argv[]);
int 		si_cmd(int argc, char *argv[]);
int 		is_cmd(int argc, char *argv[]);
int 		file_cmd(int argc, char *argv[]);
int 		close_file_cmd(int argc, char *argv[]);
int 		question_cmd(int argc, char *argv[]);
int 		var_list_cmd(int argc, char *argv[]);
int 		undef_cmd(int argc, char *argv[]);
int		echo_int_cmd(int argc, char *argv[]);
int		echo_float_cmd(int argc, char *argv[]);
int		fread_cmd(int argc, char *argv[]);
int		silence_cmd(int argc, char *argv[]);
int		rep_cmd(FILE *, char *);
int 		temps(int argc, char *argv[]);
int 		exit_cmd(int argc, char *argv[]);
int 		proglist_cmd(int argc, char *argv[]);
int 		load_cmd(int argc, char *argv[]);
int 		shell_cmd(int argc, char *argv[]);
void		init_var(void);
int		init_var_cmd(int argc, char *argv[]);
int		num_com(int argc, char *argv[]);
int		hist_cmd(int argc, char *argv[]);
int		mon_cmd(int argc, char *argv[]);
int		fin_mon_cmd(int argc, char *argv[]);
void            print(char*, ...);
int		flush_cmd(int argc, char *argv[]);
int		greetb_cmd(int argc, char *argv[]);
void		error_mess(int);
FILE           *Copen(char *, char *, char *);
FILE           *CCopen(char *, char *, char *, char *);
FILE           *CIopen(char *, char *, char *, int);
FILE           *fmemopen(void *, int, char *);
int		time_cmd(int argc, char *argv[]);

/*
 *   complex.c
 */
fcomplex        Cadd(fcomplex, fcomplex);
fcomplex        Csub(fcomplex, fcomplex);
fcomplex        Cnegat(fcomplex);
fcomplex        Cmul(fcomplex, fcomplex);
fcomplex        Complex(float, float);
fcomplex        Conjg(fcomplex);
fcomplex        Cdiv(fcomplex, fcomplex);
float           Cabs(fcomplex);
fcomplex        Csqrt(fcomplex);
fcomplex        RCmul(float, fcomplex);
fcomplex        RCdiv(fcomplex, float);
fcomplex        Cinv(fcomplex);
dcomplex        dCadd(dcomplex, dcomplex);
dcomplex        dCsub(dcomplex, dcomplex);
dcomplex        dCnegat(dcomplex);
dcomplex        dCmul(dcomplex, dcomplex);
dcomplex        dComplex(double, double);
dcomplex        dConjg(dcomplex);
dcomplex        dCdiv(dcomplex, dcomplex);
double          dCabs(dcomplex);
dcomplex        xdCsqrt(dcomplex);
dcomplex        dRCmul(double, dcomplex);
dcomplex        dRCdiv(dcomplex, double);
dcomplex        xdCinv(dcomplex);
fpolaire        Conv_ctp(fcomplex);
fcomplex        Conv_ptc(fpolaire);
dcomplex        dConv_ptc(dpolaire);
dpolaire        dConv_ctp(dcomplex);
fcomplex        Clog_p(fpolaire);
fcomplex	Clog_c(fcomplex);
fpolaire	Plog_c(fpolaire);
fcomplex        Csin_c(fcomplex);
fcomplex        Ccos_c(fcomplex);
fpolaire        Pexp_c(fcomplex);
fcomplex        Cexp_c(fcomplex);
fpolaire	Pexp_p(fpolaire);
dcomplex        dClog_p(dpolaire);
dcomplex	dClog_c(dcomplex);
dpolaire	dPlog_c(dpolaire);
dcomplex        dCsin_c(dcomplex);
dcomplex        dCcos_c(dcomplex);
dpolaire        dPexp_c(dcomplex);
dcomplex        dCexp_c(dcomplex);
dpolaire	dPexp_p(dpolaire);
fpolaire        Polaire(float, float);
dpolaire	dPolaire(double, double);
fpolaire	Padd(fpolaire, fpolaire);
fpolaire	Psub(fpolaire, fpolaire);
fpolaire	Pmul(fpolaire, fpolaire);
fpolaire	Pdiv(fpolaire, fpolaire);
fpolaire	Pconjg(fpolaire);
fpolaire	Psqrt(fpolaire);
fpolaire	Ppuis(fpolaire, float);
fcomplex	Cpuis(fcomplex, float);
fpolaire	RPmul(float, fpolaire);
fpolaire	RPdiv(fpolaire, float);
fpolaire	Pinv(fpolaire);
dpolaire	dPadd(dpolaire, dpolaire);
dpolaire	dPsub(dpolaire, dpolaire);
dpolaire	dPmul(dpolaire, dpolaire);
dpolaire	dPdiv(dpolaire, dpolaire);
dpolaire	dPconjg(dpolaire);
dpolaire	dPsqrt(dpolaire);
dpolaire	dPpuis(dpolaire, double);
dcomplex	dCpuis(dcomplex, double);
dpolaire	dRPmul(double, dpolaire);
dpolaire	dRPdiv(dpolaire, double);
dpolaire	dPinv(dpolaire);

/*
 *   ee.c
 */
int	 	SetValue(char *, double *);
int		Evaluate(char *, double *, int *);

/*
 *   interface
 */
void 		exit_prog(void);
void 		init_prog(void);
void		dest_prop(int, int);

/*
 *   interp.c
 */
void		prog_c(int argc, char *argv[], char *, char int_ini_c[], int);
void		lect_com(void);
void		extrait_arg(void);
void		execute_c(void);
int		change_lev();
void		substit(void);
void		substit2(void);
void		shell_c(int argc, char *argv[]);
int 		lookup_c(char *names[], char *, int *, int);
void		prTime(void);
double          (*fonc(char *))(double ,double);
int		convert_int(char *);
int		S_convert_int(char *);
double		convert_float(char *);
double		S_convert_float(char *);
int		eval_cmd(int argc, char *argv[]);
int 		is_alphab(char);
int		is_alphab_or_num(char);
int 		parse_com(char *, char *);
void		read_float(float *);
void 		read_int(int *);
void 		read_char(char *);
int 		parse_def(char *, int *, char *);
void		extrait_arg_s(char *, double *, int *);
dcomplex	calc_val_obj(int, double *, char *, int);
void		print_ev_error(int);

/*
 *   mem.c
 */
memm	       *memm_alloc(int *, int, int);
memm           *_M(char **);
char           *addr_eff(memm *);
char           *addr_eff_b(memm *);
void		Xfree(memm *);
void		Xfree_b(char **);
int		longueur(memm *M);
int		compare_tab(memm *, memm *);
int		compare_dim(memm *, memm *);
int            *int_alloc1(int);
int	      **int_alloc2(int, int);
int	     ***int_alloc3(int, int, int);
int	    ****int_alloc4(int, int, int, int);
float          *float_alloc1(int);
float	      **float_alloc2(int, int);
float	     ***float_alloc3(int, int, int);
float	    ****float_alloc4(int, int, int, int);
double            *double_alloc1(int);
double	      **double_alloc2(int, int);
double	     ***double_alloc3(int, int, int);
double	    ****double_alloc4(int, int, int, int);
fcomplex       *fcomplex_alloc1(int);
fcomplex      **fcomplex_alloc2(int, int);
fcomplex     ***fcomplex_alloc3(int, int, int);
fcomplex    ****fcomplex_alloc4(int, int, int, int);
dcomplex       *dcomplex_alloc1(int);
dcomplex      **dcomplex_alloc2(int, int);
dcomplex     ***dcomplex_alloc3(int, int, int);
dcomplex    ****dcomplex_alloc4(int, int, int, int);
fpolaire       *fpolaire_alloc1(int);
fpolaire      **fpolaire_alloc2(int, int);
fpolaire     ***fpolaire_alloc3(int, int, int);
fpolaire    ****fpolaire_alloc4(int, int, int, int);
dpolaire       *dpolaire_alloc1(int);
dpolaire      **dpolaire_alloc2(int, int);
dpolaire     ***dpolaire_alloc3(int, int, int);
dpolaire    ****dpolaire_alloc4(int, int, int, int);
void		manip1_tab(memm *, memm *, memm *, T_fonc *,
		double, dcomplex, int, CC_fonc*);
void		ajoute_tab(memm *, memm *, memm *);
void		soustrait_tab(memm *, memm *, memm *);
void		multiplie_tab(memm *, memm *, memm *);
void		Rmul_tab(memm *, double, memm *);
void		Cmul_tab(memm *, dcomplex, memm *);
void		Conjg_tab(memm *, memm *);
void		Module_tab(memm *, memm *);
void		Phase_tab(memm *, memm *);
void		copie_tab(memm *, memm *);
void		reel_tab(memm *, memm *);
void		imag_tab(memm *, memm *);
void		Polaire_tab(memm *, memm *, memm *);
void		Complex_tab(memm *, memm *, memm *);
void		cnst_tab(memm *, double);
void		Ccnst_tab(memm *, dcomplex);
void		RPolcnst_tab(memm *, double);
void		ThPolcnst_tab(memm *, double);
memm           *_M(char **);
int		svg_tab(FILE *, char *, int);
int		iadd(int, int);
double		dadd(double, double);
int		isub(int, int);
double		dsub(double, double);
int		i_Rmul(double, int);
double		d_mult(double, double);
fcomplex	RCmulb(double, fcomplex);
fpolaire	RPmulb(double, fpolaire);
int		i_mult(int, int);
int		i_inv(int);
double		d_inv(double);
int		i_cnst(double);
double          d_cnst(double);
fcomplex	fc_cnst(double);
dcomplex	dc_cnst(double);
fpolaire	fp_cnst(double);
dpolaire	dp_cnst(double);
fcomplex	Ccnst(dcomplex);
dcomplex	dCcnst(dcomplex);
fpolaire	Pcnst(dcomplex);
dpolaire	dPcnst(dcomplex);
int		icnst(int);
double		dcnst(double);
fcomplex	Ccnst_id(fcomplex);
fpolaire	Pcnst_id(fpolaire);
dpolaire	dPcnst_id(dpolaire);
fcomplex	Cmul_x(dcomplex, fcomplex);
fpolaire	Pmul_x(dcomplex, fpolaire);
dpolaire	dPmul_x(dcomplex, dpolaire);
fcomplex	fRPolcnst(double, fcomplex);
dcomplex	dRPolcnst(double, dcomplex);
fpolaire	PRPolcnst(double, fpolaire);
dpolaire	dPRPolcnst(double, dpolaire);
fcomplex	fThPolcnst(double, fcomplex);
dcomplex	dThPolcnst(double, dcomplex);
fpolaire	PThPolcnst(double, fpolaire);
dpolaire	dPThPolcnst(double, dpolaire);
fpolaire	PComplex(double, double);
dpolaire	dPComplex(double, double);
fcomplex	CPolaire(double, double);
dcomplex	dCPolaire(double, double);
double		Reel_dC(dcomplex);
double		Reel_dP(dpolaire);
double		Imag_dC(dcomplex);
double		Imag_dP(dpolaire);
double		R_dC(dcomplex);
double		R_dP(dpolaire);
double		Th_dC(dcomplex);
double		Th_dP(dpolaire);

/*
 * objdef.c
 */
int		objdef_cmd(FILE *, char *);
void		nettoie(char *);
void		make_com(char *, int, int *);
int		obj_create(int argc, char *argv[]);
int		test_nom_obj(char *, int);
int		detruit_obj(int argc, char *argv[]);
int		liste_obj(int argc, char *argv[]);
void		init_obj(int);
int		sketch_obj(char *, int *);
int		sketch_obj_restr(char *, int *, int);
int		sketch_obj_restr_b(char *, int *, int);
int		sketch_obj2(char *, char *, int *, int *);
int		sketch_obj3(char *, char *, char *,int *, int *, int *);
int		add_objet(int argc, char *argv[]);
int		sub_objet(int argc, char *argv[]);
int		copie_objet(int argc, char *argv[]);
int 		svg_cmd(int argc, char *argv[]);
int 		restore_cmd(int argc, char *argv[]);
int 		cnst(int argc, char *argv[]);
int		mult_objet(int argc, char *argv[]);
int		Cmult_objet(int argc, char *argv[]);
char	       *ch_copy(char *);
char	       *ch_copy_int(int);
int 		Ccnst_cmd(int argc, char *argv[]);
int 		RPolcnst(int argc, char *argv[]);
int 		ThPolcnst(int argc, char *argv[]);
int             Real_part(int argc, char *argv[]);
int             Imag_part(int argc, char *argv[]);
int             Radius_part(int argc, char *argv[]);
int             Phase_part(int argc, char *argv[]);
int             conjg_cmd(int argc, char *argv[]);
int             mkcomplex_cmd(int argc, char *argv[]);
int             mkpolaire_cmd(int argc, char *argv[]);
int		struct_cmd(FILE *, char *);
int		test_name_str(char *);
void		make_com_str(char *, int, int *);
int		test_nom_str(char *, int);
void		init_str(int);
int 		assign_membre(int argc, char *argv[]);
int 		desassign_membre(int argc, char *argv[]);
int		desc_struct(int argc, char *argv[]);
int		struc_create(int argc, char *argv[]);
int		sketch_struc(int, int, char *, int *);
/*--------------------------------------------------------------------
--------------------------------------------------------------------*/




#define comp(s1,s2) (!strcmp((s1),(s2)))

int		prlevel,
                ind_run,
 		__nbcom,
                __nblignes,
		__com_max,
		__greet_max,
		__mess_max,
                __nss,
		__nmode_fonc,
		__maxvoice,
                __nbcond,
		__nbtypmax,
		__nbstrucmax,
		__nbargmax,
                __nbfoncmax,
                __nblabelmax,
		__max_quest,
		__n_com_prec,
		ind_x_mode,
		ind_x_func,
		ind_x_param,
		ind_x_rep,
		i_func_ind;


extern	pfi    *proc[];
pfi	       *procw;
extern 	pfib	procb[];
extern	char   *namesb[];
extern char    *mess_interp[];

char	      **mess,
	      **prompt_mode,
              **greet,
              **names,
	      **nom_com,
             ***ligne_com,
              **com_prec,
	       *argv_init_interp[20];

int	        ind_com,
                i_greet,
	       *nb_label,
               *tr_label,
	      **num_label,
               *len_n,
	       *sil_com,
	      **mode_com_int,
	      **mode_com_str,
	      **mode_com_obj,
               *nb_par,
		nb_com,
               *nb_lignes,
                horloge,
		nb_mode_fonc,
                nb_commandes,
                i_message,
              **mode_com,
               *par_com,
                is_com,
                i_speed,
		curvoice,	    
               *deb_nom,
	       *fin_nom,
		ix_com,
		pr_com,
		i_com,
                i_com_cur,
		i_ligne_cur,
		i_lec_cur,
                i_init_interp,
                sil_init_interp,
		argc_init_interp,
		ind_greet_x;
long		i_time_x;

FILE	      **inp;                   /* 'voices' where the commands
					  are read. Voice 0 is stdin, 
					  the other are command files
					  successively called */ 
argv_t	       *argv_x;                
int	       *argc_x;                
  
               
/*--------------------------------------------------------------------
    Variable used by the expression evaluator
--------------------------------------------------------------------*/
char		hcom[1000];
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Running modes
--------------------------------------------------------------------*/
int             mode_fonct_;
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Variables used by conditions (commands 'si' and 'is')
--------------------------------------------------------------------*/
int		n_cond,
	       *s_cond;
v_c 	       *v_cond;
/*------------------------------------------------------------------*/



/*---- Variables used to manage files (monitor files, commands
       'read', 'write', etc...) ------------------------------------*/
FILE	      **sS,
	       *Mon_File;
int	       *sS_cmpt,
               *sS_i_o;
char	      **sS_nom;
/*-------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Variable used with question files 
---------------------------------------------------------------------*/
char	      **ques;
/*-------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Predefined directories (section '!rep')
--------------------------------------------------------------------*/
char		command_rep[80],
		data_rep[80],
		data_rep2[80],
                result_rep[80];
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Creation of objects
--------------------------------------------------------------------*/
int		nb_typ;

obj_typ	       *Obj_typ;
obj	      **Obj;
int	       *Obj_alias;
/*------------------------------------------------------------------*/



/*--------------------------------------------------------------------
    Creation of structures
--------------------------------------------------------------------*/
int		nb_struc;

struc_typ      *Struc_typ;
strucb	      **Struc;
/*------------------------------------------------------------------*/


#define _GOTO 	    5
#define _IFGT 	    6
#define _IFLT       7
#define _IFEQ       8
#define _EVAL       9
#define _PRIME_C    8803
#define _P_MULT     2743
#define _L_OBJNAME  80

#endif
