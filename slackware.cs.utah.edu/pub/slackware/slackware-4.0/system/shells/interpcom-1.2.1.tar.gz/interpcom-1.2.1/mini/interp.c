/*************************************************************************
** interpcom-1.2 (command interpreter)                                   **
** interp.c : mini-interpreter						 **
**	      Commands interpreter and functions related to the          **
**	      Expression Evaluator                                       **
**                                                                       **
** Copyright (C) 1999  Jean-Marc Drezet                                  **
**                                                                       **
**  This library is free software; you can redistribute it and/or        **
**  modify it under the terms of the GNU Library General Public          **
**  License as published by the Free Software Foundation; either         **
**  version 2 of the License, or (at your option) any later version.     **
**									 **
**  This library is distributed in the hope that it will be useful,      **
**  but WITHOUT ANY WARRANTY; without even the implied warranty of       **
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    **
**  Library General Public License for more details. 			 **
**									 **
**  You should have received a copy of the GNU Library General Public    **
**  License along with this library; if not, write to the Free		 **
**  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.   **
**                                                                       **
** Please mail any bug reports/fixes/enhancements to me at:              **
**      drezet@math.jussieu.fr                                           **
** or                                                                    **
**      Jean-Marc Drezet                                                 **
**      Institut de Mathematiques                                        **
**      Aile 45-55                                                       **
**      2, place Jussieu                                                 **
**      75251 Paris Cedex 05                                             **
**      France								 **
**                                                                       **
 *************************************************************************/

#include "interp.h"

char *version = "interpcom V1.2 01/04/98";

#define isnum(c)  (c >= '0' && c <= '9')

int 	  	    i_chlev = 0;
char		    h_ligne[300];          /* command line            */
char	 	   *argv_c[20];            /* arguments               */
char                cmdx[200];
int		    argc_c;                /* number of arguments     */
                                           
long		    I;			   /* used to stored execution 
                                              times */
extern		    char *version;
extern		    char *esp_decalage;




/*-----------------------------------------------------------------------
    Initialization of the command interpreter
-----------------------------------------------------------------------*/
void
prog_c(int argc, char *argv[], char *int_ini, char int_ini_c[], int nb_ini)
{
    int	  	    i;

/*-------------------------------------------------------------------
    Initializations 
-------------------------------------------------------------------*/
#ifdef _MSDOS_VERSION
    init_unixfic();
#endif
    nb_com = 0;        /* Nombre of programs      */
    nb_mode_fonc = -1; /* Number of running modes */
    i_speed = 0;
    i_time_x = 0;
    ind_greet_x = 0;
    nb_commandes = -1;
    i_message = -1;
    i_func_ind = -1;
    Mon_File = NULL;

    __nbargmax = 10; 
    ind_com = 0; 
    pr_com = 0;
    ix_com = 0;   
    i_init_interp = 0;  
    i_greet = -1;   
    ind_x_mode = 0;
    ind_x_func = 0;
    ind_x_param = 0;
    ind_x_rep = 0;

    charge_com(int_ini, int_ini_c, nb_ini);              /* 
				 * Reading the initialization file
                                 */
    if (ind_x_mode == 0 || ind_x_param == 0 || ind_x_rep == 0)
	exit_interp(NULL);
    ind_com = 1;
    i_com_cur = -1;

    traite_label();             /*
                                 * treatment of 'goto', 'if', 'do' in the
                                 * programs of the initialization file
                                 */
    curvoice = 0;               /* voice 0 = stdin */  
    inp[0] = stdin;
    prlevel = 0; 
    i_com = -1;
    ind_run = 0;  
    if (argc > 1) {
	inp[0] = fopen(argv[1], "r");
        if (inp[0] == NULL)
	    exit(0);
        prlevel = 1;
        ind_run = 1;
    }

    is_com = 0;  

    init_prog();		/*
				 * initializations of the program
                                 * (function supplied by the user)	
    			 	 */
    if (prlevel <= 0) {
        printf("\n");
        printf("%s\n", version);
    }
    if (i_init_interp != 0 && argc_init_interp > 0) {
        if (sil_init_interp == 0) 
	    prlevel++;
	shell_c(argc_init_interp, argv_init_interp);
        if (sil_init_interp == 0)
	    prlevel--;
    }
/*------------------------------------------------------------------*/


/*----------------------------------------------
    Printing the greeting message
----------------------------------------------*/
    if (i_init_interp == 0) {
        for (i = 0; i < i_greet; i++)
             if (prlevel <= 0)
	         printf("%s\n", greet[i]);
    }

    lect_com();      /* loop reading the instructions */
}
/*---------------------------------------------------------------------*/





/*-----------------------------------------------------------------------
    Loop reading the instructions
-----------------------------------------------------------------------*/
void
lect_com(void)
{
    int		    i,
		    j;
    char	   *c;

        if (prlevel <= 0) 
            print("%s", prompt_mode[mode_fonct_]);   
		    /* Printing the  prompt, mode_fonct_ = number of
                       the current running mode */ 
                                                   

/*-----------------------------------------------------------------
    The command line is read in voice 'curvoice', voice 0 is stdin
    and the others are the command files successively called
-----------------------------------------------------------------*/
xxx:  while (fgets(h_ligne, 299, inp[curvoice]) != NULL) {
        if (curvoice == 0 && Mon_File != NULL)
	    fprintf(Mon_File, "%s", h_ligne);
        if (h_ligne[0] == '!') {    /* Detection of a call for
				       preceeding command */
	    c = h_ligne + 1;
            nettoie(c);
	    i = convert_int(c) + 1;
            if (i >= 0 && i <= ix_com && i > ix_com - __n_com_prec) {
		i = i_com - ix_com + i;
                if (i < 0)
		    i += abs(i) * __n_com_prec;
                i = i - (i / __n_com_prec) * __n_com_prec;
		memset(h_ligne, 0, 300);
		for (j = 0; j < strlen(com_prec[i]); j++)
                    h_ligne[j] = com_prec[i][j];
                h_ligne[strlen(com_prec[i])] = '\n';
                if (prlevel <= 0) {
		    print("%s", h_ligne);
                }
            }
	}
	extrait_arg();             /* Extraction of the arguments  
                                      of the command line */
        if (curvoice == 0)
	    ix_com++;
	if (argv_c[0] == NULL) {
	    if (prlevel <= 0 && curvoice == 0) {
		if (pr_com == 0)
                    print("%s", prompt_mode[mode_fonct_]);
		else
		    print("%d %s", ix_com, prompt_mode[mode_fonct_]);
	    }
            continue;
        }

        i_com++;                  /* The command is saved because
	                             it can be recalled later */
        if (i_com == __n_com_prec)
	    i_com = 0;
        if (com_prec[i_com] != NULL)
	    free(com_prec[i_com]);
	com_prec[i_com] = ch_copy(h_ligne);

        if (argv_c[0][0] == '[') {
	    i_speed = 1;
            argc_c = 0;
        }
        if (argv_c[0][0] == ']') {
	    i_speed = 0;
            argc_c = 0;
        }

        if (argc_c > 0) {
	    if (argv_c[0][0] != ';') {  /* Detection of comments */

                substit();         /* substitution of #1,..
                                      in the arguments         */

                                   /* The command line is printed if it
				      comes from a command file */ 
                if (curvoice > 0 && prlevel <= 0) {
	            for (i = 0; i < argc_c; i++) {
	   	        print("%s ", argv_c[i]);
                    }

                    print("\n");
                }

                substit2();

                if (change_lev() == 0) /* detection and execution 
                                          of a change of voice  */
                        shell_c(argc_c, argv_c);  /* execution of the
                                                     command  */

                if (prlevel <= 0) {
		    if (pr_com == 0)
                        print("%s", prompt_mode[mode_fonct_]);
		    else 
			print("%d %s", ix_com, prompt_mode[mode_fonct_]);
		}
                memset(h_ligne, 0, 300);
	    }
            else
	        if (prlevel <= 0 && curvoice == 0) {
		    if (pr_com == 0)
                        print("%s", prompt_mode[mode_fonct_]);
		    else
			print("%d %s", ix_com, prompt_mode[mode_fonct_]);
		}
        }
        else
	    if (prlevel <= 0 && curvoice == 0)  {
		if (pr_com == 0)
                    print("%s", prompt_mode[mode_fonct_]);
		else
		    print("%d %s", ix_com, prompt_mode[mode_fonct_]);
	    }
    }

/*--------------------------------------
    Detection of the end of a
    command file
--------------------------------------*/
    if (curvoice > 0) {
 	fclose(inp[curvoice]);
	curvoice--;
	goto xxx;
    }
}
/*---------------------------------------------------------------------*/





/*-----------------------------------------------------------------------
    Extraction of the arguments of the command line 'h_ligne'.
    The number of arguments is placed in 'argc' and the arguments
    in 'argv_c'
-----------------------------------------------------------------------*/
void 
extrait_arg(void)
{
    int		    i,
		    ind,
		    j,
		    argn;
    char	    argtemp[300];

    nettoie(h_ligne);
    argn = -1;
    i = 0;
    ind = 0;
    j = 0;

    while (h_ligne[i] != 0) {
	if (h_ligne[i] != ' ') {
            ind = 1;
	    argn++;
            j = 0;
            argtemp[j] = h_ligne[i++];

            while (h_ligne[i] != ' ' && h_ligne[i] != 0) {
                argtemp[++j] = h_ligne[i++];
	    }
        }
	i++;
        if (ind == 1) {
	    if (argv_c[argn] != NULL)
		free(argv_c[argn]);
            argv_c[argn] = malloc((size_t) (j + 2) * sizeof(char));
            memcpy(argv_c[argn], argtemp, j + 1);
            argv_c[argn][j + 1] = 0;
            memset(argtemp, 0, 300);
        }
        ind = 0;
    }

    argc_c = argn + 1;
}
/*---------------------------------------------------------------------*/





/*-----------------------------------------------------------------------
    Detection and execution of a change of voice
-----------------------------------------------------------------------*/
int
change_lev(void)
{
    int		    i,
		    j;
    char	    h[300];

    if (argv_c[0] != NULL) {
	if (argv_c[0][0] == '<') {   /* If the first character is '<'
				        a new command file is opened */
	    if (curvoice == __maxvoice - 1)
		return 0;
            curvoice++;

/*------------------------------------- Determination of the name of
                                        the command file and opening */
            j = 0;
	    while (command_rep[j] != 0) {
		h[j] = command_rep[j];
                j++;
            }
            i = 1;
            while (argv_c[0][i] != 0) {
		h[j++] = argv_c[0][i++];
            }
            for (i = j; i < 300; i++)
		h[i] = 0;
            inp[curvoice] = fopen(h, "r");
            if (inp[curvoice] == NULL) {
                err_mess(20);
                argc_x[--curvoice] = 0;
                return 2;
            }
/*----------------------------------------------------------------*/


/*------------------------------------- The other arguments are kept to
					be used as arguments for the
					command file */
            for (i = 1; i < argc_x[curvoice - 1]; i++) 
		free(argv_x[curvoice - 1][i]);
            argc_x[curvoice - 1] = argc_c;
            for (i = 1; i < argc_c; i++) {
	        argv_x[curvoice - 1][i] = malloc((size_t) strlen(argv_c[i]));
                strcpy(argv_x[curvoice - 1][i], argv_c[i]);
	    }
 	}
        else
	    return 0;
    }
    return 1;
}
/*---------------------------------------------------------------------*/





/*-----------------------------------------------------------------------
    Substitution of #1,#2,#(expr.) in arguments
-----------------------------------------------------------------------*/
void
substit(void)
{
    int		    i,
		    ind,
		    j,
		    k,
		    l,
		    len,
		    nb,
		    n_com;
    float	    xb;
    char 	    h[200],
		    h1[300],
		    c;

    for (i = 1; i < argc_c; i++) {
        k = -1;
	j = 0;
        len = strlen(argv_c[i]);
        ind = 0;
        memset(h, 0, 200);

	while(j < len) { 
	    if ((argv_c[i][j] != '#' && argv_c[i][j] != '!' &&
                argv_c[i][j] != '%' && argv_c[i][j] != '$') ||
		(argv_c[i][j] == '#' && curvoice == 0)) {		    
		h[++k] = argv_c[i][j++];
	    }
	    else {
                if (argv_c[i][j] == '#' && curvoice != 0) {
		    ind = 1;
                    j++;
                    l = -1;
                    memset(h1, 0, 300);
                    n_com = 0;
		    if (j < len) {
		        if (argv_c[i][j] == '(') {
			    while (j < len && argv_c[i][j] != ')') {
			        h1[++l] = argv_c[i][j++];
		            }

                            n_com = convert_int(h1);
                            j++;
                        }
                        else {
		            while (isnum(argv_c[i][j])) {
		                h1[++l] = argv_c[i][j++];
		            }
                            if (l >= 0) 
                                n_com = convert_int(h1);
		        }
                    }
		    if (n_com <= 0 || n_com > (argc_x[curvoice - 1] - 1)) {
		        free(argv_c[i]);
                        argv_c[i] = malloc((size_t) 1 * sizeof(char));
                        argv_c[i][0] = 0;
                        ind = 0;
                        break;
                    }
                    else {
		        strcat(h, argv_x[curvoice - 1][n_com]);
                        k += strlen(argv_x[curvoice - 1][n_com]);
                    }
	        }
                else {
                    if (argv_c[i][j] == '$') {
                        c = argv_c[i][j++];
		        ind = 1;
                        if (j < len) {
		            if (argv_c[i][j] == '(')
			        j++;
		            if (j < len) {
                                nb = -1;
                                memset(h1, 0, 300);
                                l = -1;

			        while(j < len && argv_c[i][j] != ')') {
                                    h1[++l] = argv_c[i][j++];
			        }
			
			        if (l >= 0) 
                                    nb = convert_int(h1);
                                memset(h1, 0, 300);
                                if (nb >= 0 && nb <= __max_quest)
			            strcpy(h1, ques[nb]);
                                strcat(h, h1);
                                j++;
                                k += strlen(h1);
		            }
		            else
			        break;
		        }
		        else
		            break;
                   }
                    else {
                        c = argv_c[i][j++];
		        ind = 1;
                        if (j < len) {
		            if (argv_c[i][j] == '(')
			        j++;
		            if (j < len) {
                                nb = 0;
                                xb = 0.;
                                memset(h1, 0, 300);
                                l = -1;

			        while(j < len && argv_c[i][j] != ')') {
                                    h1[++l] = argv_c[i][j++];
			        }
			
			        if (l >= 0) {
                                    if (c == '!')
                                        nb = convert_int(h1);
                                    else
				        xb = convert_float(h1);
                                }
                                memset(h1, 0, 300);
                                if (c == '!')
			            sprintf(h1, "%d", nb);
                                else
				    sprintf(h1, "%f", xb);
                                strcat(h, h1);
                                j++;
                                k += strlen(h1);
		            }
		            else
			        break;
		        }
		        else
		            break;
		    }
		}
            }
	}

        if (ind == 1) {
	    free(argv_c[i]);
	    argv_c[i] = malloc((size_t) (k + 2) * sizeof(char));
            strcpy(argv_c[i], h);
            argv_c[i][k + 1] = 0;
	}
    }	
}
/*---------------------------------------------------------------------*/




/*-----------------------------------------------------------------------
    Substitution of '{'
-----------------------------------------------------------------------*/
void 
substit2(void)
{
    int		    i,
		    j;

    for (i = 1; i < argc_c; i++) {
	j = 0;

        while (argv_c[i][j] != 0) {
	    if (argv_c[i][j] == '{')
		argv_c[i][j] = '#';
	    j++;
        }
    }
}
/*---------------------------------------------------------------------*/




/*-----------------------------------------------------------------------
    Execution of a command. The number of arguments is 'argc', the
    arguments is in 'argv'
-----------------------------------------------------------------------*/
void
shell_c(int argc, char *argv[])
{
    int		    i,
		    j,
                    i_comb,
		    i_cond;
    double	    x;
    
    if (prlevel <= 0)
	time(&I);
    if (i_speed == 0) {
        i = lookup_c(names, argv[0], len_n, nb_commandes);  
			   /* i contains the number of the command
                              if it exists, -1 otherwise */

/*----------------------------------------
    Conditions 
----------------------------------------*/
        i_cond = -1;
        if (n_cond >= 0) {
            for (j = 0; j <= n_cond; j++) {
	        if (s_cond[j] == 1 && convert_float(v_cond[j]) <= 0)
		    i_cond = 0;
                if (s_cond[j] == -1 && convert_float(v_cond[j]) > 0)
	   	    i_cond = 0;
            }
        }
/*--------------------------------------*/


        if (i_cond < 0 || comp("is", argv[0]) == 1) {

/*-----------------------
     Execution of the command
-----------------------*/
  	    if (i >= 0) {
                if (mode_com[i][mode_fonct_] == 1) {   
                    if (test_param(argc, i) == 1)
	                (*(procw[i])) (argc, argv);  /* execution */
                    else 
		        err_mess(0);
                }
	        else
		    err_mess(25);
            }
/*--------------------*/


            else {
/*----------------------
    Detection and execution of programs
----------------------*/
                i = lookup_b(argv[0]);
                if (i >= 0) {
                     i_comb = i_com_cur;
                     execute(i, argc, argv); 
	             i_com_cur = i_comb;
		}
/*--------------------*/
         

	        else {
/*----------------------
    The instructions that are not commands
    or programs are send to the expression
    evaluator
----------------------*/
	            memset(cmdx, 0, 200);
	            for (j = 0; j < argc; j++) 
		        strcat(cmdx, argv[j]);
		    ERROR = 0;
	            x = convert_float(cmdx);
                    if (prlevel <= 0 && is_com == 0) {
		        print("%s%f\n", esp_decalage, (float) x);
			print_ev_error(ERROR);
                    }
	        }
	    }
        }
        prTime();
    }
    else {
        memset(cmdx, 0, 200);
        for (j = 0; j < argc; j++) 
            strcat(cmdx, argv[j]);
        convert_float(cmdx);
    }	
}
/*---------------------------------------------------------------------*/





/*-----------------------------------------------------------------------
    Function returning i if s=names[i], -1 otherwise
-----------------------------------------------------------------------*/
int
lookup_c(char *names[], char *s, int *len, int nb)
{ 
    int		    i,
		    i0;

    i0 = (int) s[0];
    if (fin_nom[i0] == -1)
	return -1;
    for (i = deb_nom[i0]; i <= fin_nom[i0]; i++)
	if (comp(names[i], s) == 1)
	    return i;

    return -1;   
}
/*---------------------------------------------------------------------*/




/*----------------------------------------------------------------------
    Function printing the execution time of a command
----------------------------------------------------------------------*/
void
prTime(void)
{
    long 	    J;
    int 	    i,
		    k,
		    h;

    if (horloge == 1) {
        time(&J);
        i = J - I;
        if (i >= 2) {
            k = i / 60;
            h = k / 60;
            i -= 60 * k;
            k -= 60 * h;

            if (h != 0 && prlevel <= 0) {
#ifdef _ENG_LANG
		print(" ; execution time : %d h  %d mn  %d s\n", 
		    h, k, i);
#else
                print(" ; temps d'execution : %d h  %d mn  %d s\n", 
		    h, k, i);
#endif
                return;
            }
            if (k != 0 && prlevel <= 0) {
#ifdef _ENG_LANG
                print(" ; execution time : %d mn  %d s\n", k, i);
#else
                print(" ; temps d'execution : %d mn  %d s\n", k, i);
#endif
                return;
            }
            if (i != 0 && prlevel <=0) {
#ifdef _ENG_LANG
                print(" ; execution time : %d s\n", i);
#else
                print(" ; temps d'execution : %d s\n", i);
#endif
            }
        }
    }
}
/*---------------------------------------------------------------------*/





char		hlec[100];


/*----------------------------------------------------------------------
    This function sends the expression 'arg' to the expression
    evaluator. The result of the evaluation is converted to an 
    integer and returned
----------------------------------------------------------------------*/
int 
convert_int(char *arg)
{
      return (int)floor(convert_float(arg));
}
/*--------------------------------------------------------------------*/





/*----------------------------------------------------------------------
    This function adds the non printable character in the beginning
    of 'arg' and sends this to the expression evaluator. The result 
    of the evaluation is converted to an integer which is returned. 
    This is used to determine or fix the value of hidden variables
----------------------------------------------------------------------*/
int
S_convert_int(char *arg)
{
    int		    i;
    char 	    h[100];

    memset(h, 0, 100);
    h[0] = 127;
    for (i = 0; i < (int) strlen(arg); i++)
	h[i + 1] = arg[i];
    return convert_int(h);
}
/*--------------------------------------------------------------------*/




/*----------------------------------------------------------------------
    This function sends the expression 'arg' to the expression
    evaluator and returns the result of the evaluation
----------------------------------------------------------------------*/
double
convert_float(char *arg)
{
    double 	    res;
    int 	    dum;
    
    if (Evaluate(arg, &res, &dum) == E_OK) 
	return res;
    return 0.0;
}
/*--------------------------------------------------------------------*/





/*----------------------------------------------------------------------
    This function adds the non printable character in the beginning
    of 'arg' and sends this to the expression evaluator. The result 
    of the evaluation is returned. This is used to determine or fix 
    the value of hidden variables
----------------------------------------------------------------------*/
double
S_convert_float(char *arg)
{
    int		    i;
    char 	    h[100];

    memset(h, 0, 100);
    h[0] = 127;
    for (i = 0; i < (int) strlen(arg); i++)
	h[i + 1] = arg[i];
    return convert_float(h);
}
/*-------------------------------------------------------------------*/





/*---------------------------------------------------------------------
    Function associated to the command 'eval'
---------------------------------------------------------------------*/
int
eval_cmd(int argc, char *argv[])
{
    double 	    x;
    int		    i;
    char	    h[100],
		    k[300];

    if (argc < 2) {
	err_mess(0);
	return 0;
	}
    memset(h, 0, 100);
    memset(k, 0, 300);
    for (i = 1; i < argc; i++)
	strcat(k, argv[i]);
    ERROR = 0;
    x = convert_float(k);
    sprintf(h, "curvar=%f", (float)x);
    convert_float(h);
    if (prlevel <= 0) {
	print("                      %f\n", x);
	print_ev_error(ERROR);
    }
    return 0;
}
/*--------------------------------------------------------------------*/



/*---------------------------------------------------------------------
    Functions used to see if a character string is "alphanumeric"
---------------------------------------------------------------------*/
int 
is_alphab(char s)
{
    if ((s >= 'A' && s <= 'Z') || (s >= 'a' && s <= 'z') || s == '_')
	return 1;
    else
	return 0;
}

int 
is_alphab_or_num(char s)
{    
    if (is_alphab(s) == 1 || (s >= '0' && s <= '9')) 
	return 1;
    else
	return 0;
}
/*--------------------------------------------------------------------*/




/*---------------------------------------------------------------------
    Function used to read real numbers from standard input or 
    programs
---------------------------------------------------------------------*/
void
read_float(float *x)
{
    memset(hlec, 0, 100);
    if (i_com_cur == -1) {
        fgets(hlec, 99, inp[curvoice]);
        nettoie(hlec);
    }
    else {
	if (i_ligne_cur < nb_lignes[i_com_cur]) {
	    i_ligne_cur++;
            i_lec_cur++;
	    strcpy(hlec, ligne_com[i_com_cur][i_ligne_cur]);
	}
    }
    x[0] = convert_float(hlec);
    if (prlevel <= 0) {
        if (Mon_File != NULL)
 	    fprintf(Mon_File, "%f\n", x[0]);
        if (i_com_cur != -1)
	    print("%f\n", x[0]);
    }
}
/*--------------------------------------------------------------------*/




/*---------------------------------------------------------------------
    Function used to read integers from standard input or programs
---------------------------------------------------------------------*/
void
read_int(int *n)
{
    memset(hlec, 0, 100);
    if (i_com_cur == -1) {
        fgets(hlec, 99, inp[curvoice]);
        nettoie(hlec);
    }
    else {
	if (i_ligne_cur < nb_lignes[i_com_cur]) {
	    i_ligne_cur++;
            i_lec_cur++;
	    strcpy(hlec, ligne_com[i_com_cur][i_ligne_cur]);
	}
    }
    n[0] = convert_float(hlec);
    if (prlevel <= 0) {
   	if (Mon_File != NULL)
 	    fprintf(Mon_File, "%d\n", n[0]);
        if (i_com_cur != -1)
	    print("%d\n", n[0]);
    }
}
/*--------------------------------------------------------------------*/




/*---------------------------------------------------------------------
    Function used to read character strings from standard input or 
    programs
---------------------------------------------------------------------*/
void
read_char(char *st)
{
    memset(hlec, 0, 100);
    if (i_com_cur == -1) {
        fgets(hlec, 99, inp[curvoice]);
        nettoie(hlec);
    }
    else {
	if (i_ligne_cur < nb_lignes[i_com_cur]) {
	    i_ligne_cur++;
            i_lec_cur++;
	    strcpy(hlec, ligne_com[i_com_cur][i_ligne_cur]);
	}
    }
    strcpy(st, hlec);
    if (prlevel <= 0) {
   	if (Mon_File != NULL)
 	    fprintf(Mon_File, "%s\n", hlec);
        if (i_com_cur != -1)
	    print("%s\n", hlec);
    }
}
/*--------------------------------------------------------------------*/





/*----------------------------------------------------------------------
    Prints error messages returned by the expression evaluator
----------------------------------------------------------------------*/
void
print_ev_error(int i0)
{
#ifdef _ENG_LANG
    switch(i0) {
	case 1 :
	    print("%s\n", "Syntax error");
	    break;
	case 2 :
	    print("%s\n", "Unbalanced parenthesis");
	    break;
	case 3 :
	    print("%s\n", "Division by zero");
	    break;
	case 4 :
	    print("%s\n", "Unknown variable");
	    break;
	case 5 :
	    print("%s\n", "Too many variables");
	    break;
	case 6 :
	    print("%s\n", "Unknown function");
	    break;
	case 7 :
	    print("%s\n", "Wrong number of arguments");
	    break;
	case 8 :
	    print("%s\n", "Missing argument");
	    break;
	default :
	    break;
    }
#else
    switch(i0) {
	case 1 :
	    print("%s\n", "Erreur de syntaxe");
	    break;
	case 2 :
	    print("%s\n", "Probleme de parenthese");
	    break;
	case 3 :
	    print("%s\n", "Division par zero");
	    break;
	case 4 :
	    print("%s\n", "Variable inconnue");
	    break;
	case 5 :
	    print("%s\n", "Trop de variables");
	    break;
	case 6 :
	    print("%s\n", "Fonction inconnue");
	    break;
	case 7 :
	    print("%s\n", "Nombre d'arguments incorrect");
	    break;
	case 8 :
	    print("%s\n", "Argument manquant");
	    break;
	default :
	    break;
    }
#endif
}
/*--------------------------------------------------------------------*/
