;/*************************************************************************
;** interpcom-1.2 (command interpreter - graph)                           **
;** graph.c : 						                  **
;** Copyright (C) 1999  Jean-Marc Drezet                                  **
;**                                                                       **
;**  This library is free software; you can redistribute it and/or        **
;**  modify it under the terms of the GNU Library General Public          **
;**  License as published by the Free Software Foundation; either         **
;**  version 2 of the License, or (at your option) any later version.     **
;**									  **
;**  This library is distributed in the hope that it will be useful,      **
;**  but WITHOUT ANY WARRANTY; without even the implied warranty of       **
;**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    **
;**  Library General Public License for more details. 			  **
;**									  **
;**  You should have received a copy of the GNU Library General Public    **
;**  License along with this library; if not, write to the Free		  **
;**  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.   **
;**                                                                       **
;** Please mail any bug reports/fixes/enhancements to me at:              **
;**      drezet@math.jussieu.fr                                           **
;** or                                                                    **
;**      Jean-Marc Drezet                                                 **
;**      Institut de Mathematiques                                        **
;**      Aile 45-55                                                       **
;**      2, place Jussieu                                                 **
;**      75251 Paris Cedex 05                                             **
;**      France								  **
;**                                                                       **
;**************************************************************************/

#include "interp.h"
#include "graph.h"


/*---------------------------------------------------------------------------
     Function called by 'init_prog()'. Sets the default size of the graphics
---------------------------------------------------------------------------*/
void
init_prog_graph(void)
{
    xinf_clip = 0.15;
    xsup_clip = 0.9;
    yinf_clip = 0.1;
    ysup_clip = 0.9;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'defgraph_X11 ...'
    This command creates a new window for graphics
---------------------------------------------------------------------------*/
int defgraph_X11_cmd(int argc, char *argv[])
{
    int 	    height_pix,
    		    width_pix,
		    i0;
    float	   *xx;
    char	   *k[3];
	
    width_pix = convert_int(argv[2]);	    
    height_pix = convert_int(argv[3]);	    
    if (height_pix < 50 || width_pix < 50) {
	error_mess(_GRAPH_MESS);
	return 1;
    }
    k[0] = ch_copy("objdef");
    k[1] = ch_copy_int(_GRAPH_X11 - 1);
    k[2] = argv[1];
    i0 = obj_create(3, k);
    if (i0 == -1) {
	error_mess(_GRAPH_MESS + 1);
	return 1;
    }
    free(k[0]);
    free(k[1]);
    sketch_obj_restr(argv[1], &i0, _GRAPH_X11);
    xx = (float *) Obj[_GRAPH_X11 - 1][i0].adresse;
    xx[0] = (float) width_pix;
    xx[1] = (float) height_pix;
    xx[2] = g2_open_X11(width_pix, height_pix);
    xx[3] = 0.;
    xx[4] = 0.;
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'defgraph_PS ...'
    This command creates a new Postscript file
---------------------------------------------------------------------------*/
int defgraph_PS_cmd(int argc, char *argv[])
{
    int 	    i0;
    char 	   *k[3];
    float	   *xx;
    char	    h[200];
    
    k[0] = ch_copy("objdef");
    k[1] = ch_copy_int(_GRAPH_PS - 1);
    k[2] = argv[1];
    i0 = obj_create(3, k);
    if (i0 == -1) {
	error_mess(_GRAPH_MESS + 1);
	return 1;
    }
    free(k[0]);
    free(k[1]);
    sketch_obj_restr(argv[1], &i0, _GRAPH_PS);
    xx = (float *) Obj[_GRAPH_PS - 1][i0].adresse;
    memset(h, 0, 200);
    sprintf(h, "%s\%s", result_rep, argv[2]);
    if (comp(argv[3], "landscape") == 1) {
        xx[0] = 650;
	xx[1] = 550;
        xx[2] = g2_open_PS(h, g2_A4, g2_PS_land);
    }
    else {
        xx[0] = 650;
	xx[1] = 550;
        xx[2] = g2_open_PS(h, g2_A4, g2_PS_port);
    }
    xx[3] = 0.;
    xx[4] = 0.;
    
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'graphplot ...' used to plot a point
    on a window or a PS-file
---------------------------------------------------------------------------*/
int graph_plot_cmd(int argc, char *argv[])
{
    int 	    i0,
    		    iw;
    float	   *xx;
		    
    iw = sketch_obj_restr(argv[1], &i0, _GRAPH_X11);
    if (iw != _GRAPH_X11) {
        iw = sketch_obj_restr(argv[1], &i0, _GRAPH_PS);
	if (iw != _GRAPH_PS) {
 	    error_mess(_GRAPH_MESS + 1);
	    return 1;
	}
    }
    xx = (float *) Obj[iw - 1][i0].adresse;
    g2_plot(xx[2], convert_float(argv[2]), convert_float(argv[3]));
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'graphline ...' used to plot a
    line on a window or a PS-file
---------------------------------------------------------------------------*/
int graph_lineto_cmd(int argc, char *argv[])
{
    int 	    i0,
    		    iw;
    float	   *xx;
		    
    iw = sketch_obj_restr(argv[1], &i0, _GRAPH_X11);
    if (iw != _GRAPH_X11) {
        iw = sketch_obj_restr(argv[1], &i0, _GRAPH_PS);
	if (iw != _GRAPH_PS) {
 	    error_mess(_GRAPH_MESS + 1);
	    return 1;
	}
    }
    xx = (float *) Obj[iw - 1][i0].adresse;
    g2_line_to(xx[2], convert_float(argv[2]), convert_float(argv[3]));
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'clear ...', used to "clear" a window
    or a PS-file
---------------------------------------------------------------------------*/
int clear_graph_cmd(int argc, char *argv[])
{
    int 	    i0,
    		    iw;
    float	   *xx;
		    
    iw = sketch_obj_restr(argv[1], &i0, _GRAPH_X11);
    if (iw != _GRAPH_X11) {
        iw = sketch_obj_restr(argv[1], &i0, _GRAPH_PS);
	if (iw != _GRAPH_PS) {
 	    error_mess(_GRAPH_MESS + 1);
	    return 1;
	}
    }
    xx = (float *) Obj[iw - 1][i0].adresse;
    g2_clear(i0);
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'color', used to set the color defined
    by a color object
---------------------------------------------------------------------------*/
int fixcolor_cmd(int argc, char *argv[])
{
    int 	    i0,
    		    iw,
    	           *Ix;
		    
    iw = sketch_obj_restr(argv[1], &i0, _GRAPH_COL);
    if (iw != _GRAPH_COL) {
 	error_mess(_GRAPH_MESS + 2);
	return 1;
    }
    Ix = (int *) Obj[iw - 1][i0].adresse;
    Ix[0] = convert_float(argv[2]);
    Ix[1] = convert_float(argv[3]);
    Ix[2] = convert_float(argv[4]);
    if (Ix[0] < 0.)
    	Ix[0] = 0.;
    if (Ix[0] > 1.)
    	Ix[0] = 1.;
    if (Ix[1] < 0.)
    	Ix[1] = 0.;
    if (Ix[1] > 1.)
    	Ix[1] = 1.;
    if (Ix[2] < 0.)
    	Ix[2] = 0.;
    if (Ix[2] > 1.)
    	Ix[2] = 1.;
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function used by the command 'setcolor', used to associate color objects
    to windows or PS-files
---------------------------------------------------------------------------*/
int setcolor_cmd(int argc, char *argv[])
{
    int 	    i0,
    		    iw,
		    i00,
		    iw0,
    	           *Ix;
    float	   *xx;
		    
    iw = sketch_obj_restr(argv[1], &i0, _GRAPH_X11);
    if (iw != _GRAPH_X11) {
        iw = sketch_obj_restr(argv[1], &i0, _GRAPH_PS);
	if (iw != _GRAPH_PS) {
 	    error_mess(_GRAPH_MESS + 1);
	    return 1;
	}
    }
    iw0 = sketch_obj_restr(argv[2], &i00, _GRAPH_COL);
    if (iw0 != _GRAPH_COL) {
 	error_mess(_GRAPH_MESS + 2);
	return 1;
    }
    Ix = (int *) Obj[iw0 - 1][i00].adresse;
    xx = (float *) Obj[iw - 1][i0].adresse;
    i0 = g2_ink(xx[2], Ix[0], Ix[1], Ix[2]);
    g2_pen(xx[2], i0);
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'frame', used to set the values of a 
    frame object
---------------------------------------------------------------------------*/
int fixframe_cmd(int argc, char *argv[])
{
    int 	    i0,
    		    iw;
    float          *Ix;
		  
    iw = sketch_obj_restr(argv[1], &i0, _GRAPH_FRAM);
    if (iw != _GRAPH_FRAM) {
 	error_mess(_GRAPH_MESS + 3);
	return 1;
    }
    Ix = (float *) Obj[iw - 1][i0].adresse;
    Ix[0] = convert_float(argv[2]);
    Ix[1] = convert_float(argv[3]);
    Ix[2] = convert_float(argv[4]);
    Ix[3] = convert_float(argv[5]);
    Ix[4] = convert_float(argv[6]);
    Ix[5] = convert_float(argv[7]);
    Ix[6] = 1.;
    if (Ix[1] <= Ix[0])
    	Ix[1] = Ix[0] + 1.;
    if (Ix[3] <= Ix[2])
    	Ix[3] = Ix[2] + 1.;
    if (Ix[4] <= 0)
    	Ix[4] = 1.;
    if (Ix[5] <= 0)
    	Ix[5] = 1.;
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'setframe', used to draw frame 
    objects on windows or PS-files
---------------------------------------------------------------------------*/
int setframe_cmd(int argc, char *argv[])
{
    int 	    i0,
    		    iw,
		    i00,
		    iw0,
		    i,
		    imin,
		    imax,
		    jmin,
		    jmax;
    float	   *xx,
    		   *xframe,
    		    x0,
		    x1,
		    y0,
		    y1,
		    ax,
		    ay,
		    bx,
		    by,
		    xw,
		    yw,
		    x,
		    y;
    double	    z[2],
    		    zz;
    char	    h[25];
		    
    iw = sketch_obj_restr(argv[1], &i0, _GRAPH_X11);
    if (iw != _GRAPH_X11) {
        iw = sketch_obj_restr(argv[1], &i0, _GRAPH_PS);
	if (iw != _GRAPH_PS) {
 	    error_mess(_GRAPH_MESS + 1);
	    return 1;
	}
    }
    iw0 = sketch_obj_restr(argv[2], &i00, _GRAPH_FRAM);
    if (iw0 != _GRAPH_FRAM) {
 	error_mess(_GRAPH_MESS + 3);
	return 1;
    }
    xframe = (float *) Obj[iw0 - 1][i00].adresse;
    if (xframe[6] < 1.) {
        error_mess(_GRAPH_MESS + 4);
	return 1;
    }
    xx = (float *) Obj[iw - 1][i0].adresse;
    x0 = xx[0] * xinf_clip;
    x1 = xx[0] * xsup_clip;
    y0 = xx[1] * yinf_clip;
    y1 = xx[1] * ysup_clip;
    g2_set_line_width(xx[2], 3.);
    g2_move(xx[2], x0 - 2, y0 - 1);
    g2_line_to(xx[2], x1 + 3, y0 - 1);
    g2_move(xx[2], x1 + 2, y0 - 2);
    g2_line_to(xx[2], x1 + 2, y1 + 2);
    g2_move(xx[2], x1 + 3, y1 + 1);
    g2_line_to(xx[2], x0 - 1, y1 + 1);
    g2_move(xx[2], x0 - 1, y1 + 2);
    g2_line_to(xx[2], x0 - 1, y0 - 1);
    g2_set_line_width(xx[2], 1.);
    z[0] = 5;
    z[1] = 5;
    zz = 0.;
    g2_set_dash(xx[2], 1, z);
    imin = (int) (xframe[0] / xframe[4]);
    imax = (int) (xframe[1] / xframe[4]);
    jmin = (int) (xframe[2] / xframe[5]);
    jmax = (int) (xframe[3] / xframe[5]);
    ax = (x0 - x1) / (xframe[0] - xframe[1]);
    bx = x0 - xframe[0] * ax;
    ay = (y0 - y1) / (xframe[2] - xframe[3]);
    by = y0 - xframe[2] * ay;

    for (i = imin; i <= imax; i++) {
        x = i * xframe[4];
	if (x < xframe[1] && x > xframe[0]) {
	    xw = ax * x + bx;
	    g2_move(xx[2], xw, y0);
	    
	    if (i == 0) {
	        g2_set_line_width(xx[2], 2.);
	        g2_set_dash(xx[2], 0, &zz);
	    }
	    g2_line_to(xx[2], xw, y1);
	    if (i == 0) {
	        g2_set_dash(xx[2], 1, z);
	        g2_set_line_width(xx[2], 1.);
	    }
	    memset(h, 0, 25);
	    sprintf(h, "%1.2e", x * 1.000001);
	    g2_draw_string(xx[2], xw - 20, y0 - 15, h);
	}
    }
    
    for (i = jmin; i <= jmax; i++) {
        y = i * xframe[5];
	if (y < xframe[3] && y > xframe[2]) {
	    yw = ay * y + by;
	    g2_move(xx[2], x0, yw);
	    if (i == 0) {
	        g2_set_line_width(xx[2], 2.);
	        g2_set_dash(xx[2], 0, &zz);
	    }
	    g2_line_to(xx[2], x1, yw);
	    if (i == 0) {
	        g2_set_dash(xx[2], 1, z);
	        g2_set_line_width(xx[2], 1.);
	    }
	    memset(h, 0, 25);
	    sprintf(h, "%1.2e", y * 1.000001);
	    g2_draw_string(xx[2], x0 - 55, yw - 5, h);
	}
    }
    
    zz = 0.;
    g2_set_dash(xx[2], 0, &zz);
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function used to draw the intersection of a segment of line with the
    square [0,1]X[0,1]. The endpoints of the segment are (x0,y0), (x1,y1).
    The function returns 0 if the intersection is empty, 1 otherwise. In
    this case the endpoints of the intersection are (X[0],Y[0]) and
    (X[1],Y[1]).
---------------------------------------------------------------------------*/
float	min_d = 0.00001;

int clip_line(float x0, float x1, float y0, float y1, float *X, float *Y)
{
    float	    x,
    		    y,
		    a,
		    b,
		    r1,
		    r2;
    
    if (fabs(x0 - x1) < min_d) {
        if (x0 < 0. || x0 > 1.)
	    return 0;
        if (y0 > y1) {
	    y = y0;
	    y0 = y1;
	    y1 = y;
	}
	if (y0 < 0.)
	    y0 = 0.;
	if (y1 > 1.)
	    y1 = 1.;
	if (y1 < y0)
	    return 0;
	X[0] = x0;
	X[1] = x0;
	Y[0] = y0;
	Y[1] = y1;
	return 1;
    }
    if (fabs(y0 - y1) < min_d) {
        if (y0 < 0. || y0 > 1.)
	    return 0;
        if (x0 > x1) {
	    x = x0;
	    x0 = x1;
	    x1 = x;
	}
	if (x0 < 0.)
	    x0 = 0.;
	if (x1 > 1.)
	    x1 = 1.;
	if (x1 < x0)
	    return 0;
	X[0] = x0;
	X[1] = x1;
	Y[0] = y0;
	Y[1] = y0;
	return 1;
    }
    if (x1 < x0) {
        x = x0;
	x0 = x1;
	x1 = x;
	y = y0;
	y0 = y1;
	y1 = y;
    }
    a = (y1 - y0) / (x1 - x0);
    b = y0 - a * x0;
    if (x0 < 0.)
        x0 = 0.;
    if (x1 > 1.)
        x1 = 1.;
    if (x0 > x1)
        return 0;
    r1 = - b / a;
    r2 = (1. - b) / a;
    if (a < 0.) {
        x = r1;
	r1 = r2;
	r2 = x;
    }
    if (x0 < r1)
        x0 = r1;
    if (x1 > r2)
        x1 = r2;
    if (x0 > x1)
        return 0;
    X[0] = x0;
    X[1] = x1;
    Y[0] = a * x0 + b;
    Y[1] = a * x1 + b;
    return 1;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'graph_plot_c ...' used to plot a
    point on a window or a PS-file with respect to a clipping rectangle
---------------------------------------------------------------------------*/
int graph_plot_c_cmd(int argc, char *argv[])
{
    int 	    i0,
    		    iw,
		    iw0,
		    i00;
    float	   *xx,
    		   *Ix,
    		    x,
		    y,
		    ax,
		    bx,
		    ay,
		    by;
		    
    iw = sketch_obj_restr(argv[1], &i0, _GRAPH_X11);
    if (iw != _GRAPH_X11) {
        iw = sketch_obj_restr(argv[1], &i0, _GRAPH_PS);
	if (iw != _GRAPH_PS) {
 	    error_mess(_GRAPH_MESS + 1);
	    return 1;
	}
    }
    iw0 = sketch_obj_restr(argv[2], &i00, _GRAPH_FRAM);
    if (iw0 != _GRAPH_FRAM) {
 	error_mess(_GRAPH_MESS + 2);
	return 1;
    }
    xx = (float *) Obj[iw - 1][i0].adresse;
    Ix = (float *) Obj[iw0 - 1][i00].adresse;
    ax = (Ix[1] - Ix[0]) / (xsup_clip - xinf_clip) / xx[0];
    bx = Ix[0] - ax * xx[0] * xinf_clip;
    ay = (Ix[3] - Ix[2]) / (ysup_clip - yinf_clip) / xx[1];
    by = Ix[2] - ay * xx[1] * yinf_clip;
    x = convert_float(argv[3]);
    y = convert_float(argv[4]);
    xx[3] = (x - bx) / ax;
    xx[4] = (y - by) / ay;
    if (xx[3] < xsup_clip * xx[0] && xx[3] > xinf_clip * xx[0] 
        && xx[4] < ysup_clip * xx[1] && xx[4] > yinf_clip * xx[1])
    	g2_plot(xx[2], (double)xx[3], (double)xx[4]);
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'graph_line_c ...' used to plot a
    line on a window or a PS-file with respect to a clipping rectangle
---------------------------------------------------------------------------*/
int graph_lineto_c_cmd(int argc, char *argv[])
{
    int 	    i0,
    		    iw,
		    i00,
		    iw0;
    float	   *xx,
    		   *Ix,
    		    x,
		    y,
		    ax,
		    bx,
		    ay,
		    by,
		    bx2,
		    by2,
		    u,
		    v,
		    xp,
		    yp,
		    x0,
		    y0,
		    x1,
		    y1,
		    X[2],
		    Y[2];
		    
    iw = sketch_obj_restr(argv[1], &i0, _GRAPH_X11);
    if (iw != _GRAPH_X11) {
        iw = sketch_obj_restr(argv[1], &i0, _GRAPH_PS);
	if (iw != _GRAPH_PS) {
 	    error_mess(_GRAPH_MESS + 1);
	    return 1;
	}
    }
    iw0 = sketch_obj_restr(argv[2], &i00, _GRAPH_FRAM);
    if (iw0 != _GRAPH_FRAM) {
 	error_mess(_GRAPH_MESS + 2);
	return 1;
    }
    xx = (float *) Obj[iw - 1][i0].adresse;
    Ix = (float *) Obj[iw0 - 1][i00].adresse;
    u = (xsup_clip - xinf_clip) * xx[0];
    v = (ysup_clip - yinf_clip) * xx[1];
    ax = (Ix[1] - Ix[0]) / u;
    bx = Ix[0] - ax * xx[0] * xinf_clip;
    ay = (Ix[3] - Ix[2]) / v;
    by = Ix[2] - ay * xx[1] * yinf_clip;
    bx2 = - xinf_clip * xx[0] / u;
    by2 = - yinf_clip * xx[1] / v;
    x = convert_float(argv[3]);
    y = convert_float(argv[4]);
    xp = (x - bx) / ax;
    yp = (y - by) / ay;
    x0 = xp / u + bx2;
    y0 = yp / v + by2;
    x1 = xx[3] / u + bx2;
    y1 = xx[4] / v + by2;
    xx[3] = xp;
    xx[4] = yp;
    if (clip_line(x0, x1, y0, y1, X, Y) == 1) {
        g2_plot(xx[2], (double) ((X[0] - bx2) * u), 
	    (double)((Y[0] - by2) * v));
        g2_line_to(xx[2], (double)((X[1] - bx2) * u), 
	    (double)((Y[1] - by2) * v));
    }
    return 0;
}
/*-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
    Function associated to the command 'setclip ...' used to define the
    "clipping region" in a window
---------------------------------------------------------------------------*/
int set_clip_cmd(int argc, char *argv[])
{
    xinf_clip = convert_float(argv[1]);
    xsup_clip = convert_float(argv[2]);
    yinf_clip = convert_float(argv[3]);
    ysup_clip = convert_float(argv[4]);
    if (xinf_clip < 0. || yinf_clip < 0. || xsup_clip > 1. || ysup_clip > 1.
        || xinf_clip >= xsup_clip || yinf_clip >= ysup_clip) {
        xinf_clip = .15;
        xsup_clip = .9;
        yinf_clip = .1;
        ysup_clip = .9;
    }
    return 0;
}
/*-------------------------------------------------------------------------*/









