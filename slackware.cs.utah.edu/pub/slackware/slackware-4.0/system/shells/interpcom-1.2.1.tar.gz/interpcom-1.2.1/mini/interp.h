/*************************************************************************
** interpcom-1.2 (command interpreter)                                   **
** interp.h      mini-interpreter	                         	 **
**                                                                       **
** Copyright (C) 1999  Jean-Marc Drezet                                  **
**                                                                       **
**  This library is free software; you can redistribute it and/or        **
**  modify it under the terms of the GNU Library General Public          **
**  License as published by the Free Software Foundation; either         **
**  version 2 of the License, or (at your option) any later version.     **
**									 **
**  This library is distributed in the hope that it will be useful,      **
**  but WITHOUT ANY WARRANTY; without even the implied warranty of       **
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    **
**  Library General Public License for more details. 			 **
**									 **
**  You should have received a copy of the GNU Library General Public    **
**  License along with this library; if not, write to the Free		 **
**  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.   **
**                                                                       **
** Please mail any bug reports/fixes/enhancements to me at:              **
**      drezet@math.jussieu.fr                                           **
** or                                                                    **
**      Jean-Marc Drezet                                                 **
**      Institut de Mathematiques                                        **
**      Aile 45-55                                                       **
**      2, place Jussieu                                                 **
**      75251 Paris Cedex 05                                             **
**      France								 **
**                                                                       **
 *************************************************************************/

#ifndef _INTERPCOM
#define _INTERPCOM

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>
#include <setjmp.h>




/*--------------------------------------------------------------------
----------------------------------------------------------------------
    This is the file "ee.h" of the Expression Evaluator of Mark Morley
----------------------------------------------------------------------
--------------------------------------------------------------------*/
/* Some of you may choose to define TYPE as a "float" instead...  */
#define TYPE            double    /* Type of numbers to work with */
#define XVARLEN          15       /* Max length of variable names */
#define MAXXVARS         500      /* Max user-defined variables   */
#define TOKLEN          30        /* Max token length */

#define XVAR             1
#define DEL             2
#define NUM             3

typedef struct
{
   char name[XVARLEN + 1];               /* Variable name */
   TYPE value;                          /* Variable value */
} XVARIABLE;

typedef struct
{
   char* name;                          /* Function name */
   int   args;                          /* Number of arguments to expect */
   TYPE  (*func)();                     /* Pointer to function */
} FUNCTION;

/* The following macros are ASCII dependant, no EBCDIC here! */
#define iswhite(c)  (c == ' ' || c == '\t')
#define isnumer(c)  ((c >= '0' && c <= '9') || c == '.')
#define isalphab(c)  ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') \
                    || c == '_' || c == 127)
#define isdelim(c)  (c == '+' || c == '-' || c == '*' || c == '/' || c == '%' \
                    || c == '^' || c == '(' || c == ')' || c == ',' || c == '=')

/* Codes returned from the evaluator */
#define E_OK           0        /* Successful evaluation */
#define E_SYNTAX       1        /* Syntax error */
#define E_UNBALAN      2        /* Unbalanced parenthesis */
#define E_DIVZERO      3        /* Attempted division by zero */
#define E_UNKNOWN      4        /* Reference to unknown variable */
#define E_MAXXVARS      5        /* Maximum variables exceeded */
#define E_BADFUNC      6        /* Unrecognised function */
#define E_NUMARGS      7        /* Wrong number of arguments to funtion */
#define E_NOARG        8        /* Missing an argument to a funtion */
#define E_EMPTY        9        /* Empty expression */


/********************************************************************
**                                                                  **
** PROTOTYPES FOR CUSTOM MATH FUNCTIONS                             **
**                                                                  **
 ********************************************************************/

double deg( double x );
double rad( double x );


/********************************************************************
**                                                                  **
** XVARIABLE DECLARATIONS                                           **
**                                                                  **
 ********************************************************************/

int   ERROR;                 /* The error number */
char  ERTOK[TOKLEN + 1];     /* The token that generated the error */
int   ERPOS;                 /* The offset from the start of the expression */
char* ERANC;                 /* Used to calculate ERPOS */

extern XVARIABLE Consts[];
extern FUNCTION *Funcs;
extern FUNCTION Funcs_interp[];
int _NBFONC;
int _NBFONC0;

XVARIABLE        Vars[MAXXVARS];       /* Array for user-defined variables */
unsigned char*  expression;          /* Pointer to the user's expression */
unsigned char   token[TOKLEN + 1];   /* Holds the current token */
int             type;                /* Type of the current token */
jmp_buf         jb;                  /* jmp_buf for errors */


void		strlwr2( char* s );
/*-------- End of "ee.h" ---------------------------------------------
--------------------------------------------------------------------*/






#ifdef _MSDOS_VERSION
#include "unixfic.h"
#define fopen Xfopen
#endif

typedef int 	(*pfi)(int argc, char *argv[]);
typedef int 	(*pfib)(FILE *, char *);
typedef char    *argv_t[20];
typedef char 	v_c[300];


      


/*--------------------------------------------------------------------
----------------------------------------------------------------------
    Function prototypes
----------------------------------------------------------------------
--------------------------------------------------------------------*/
/*
 *   com_sys.c
 */
int		lookup_b(char *);
void		execute(int i, int argc, char *argv[]);
void		charge_com(char *, char int_ini_c[], int);
void		interp_com(FILE *, char *);
int		mode_cmd(FILE *, char *);
int		greet_cmd(FILE *, char *);
int             gr_cmd(FILE *, char *, char **, int *, int);
int		func_cmd(FILE *, char *);
int             mess_cmd(FILE *, char *);
int             test_param(int, int);
int		param_cmd(FILE *, char *);
int		var_cmd(FILE *, char *);
int		init_interp_cmd(FILE *, char *);
void	        exit_sys(void);
void		exit_interp(char *);
void		err_mess(int);
void		traite_label(void);
void		extrait_argv_com(int, int *, int, char *argv_com[]); 
void		supprime_ligne_com(int, int);
void		insere_ligne_com(int, int, char *);
int		exist_com(char *);
void		ch_prem(void);
int		est_avant(int, int);
void		echange_nom(int, int);
int		delprog_cmd(int argc, char *argv[]);
char		*__Xdecode(char xg[], int, char *);
void            __perms(char *, char *);
char		__chx(int);
void		nettoie(char *); 
char *		ch_copy(char *); 
int		include_cmd(FILE *, char *);

/*
 *  command.c
 */
int 		bouclex(int argc, char *argv[]);
int 		bouclex_f(int argc, char *argv[]);
int		echo_cmd(int argc, char *argv[]);
int 		repetex(int argc, char *argv[]);
int 		editeur(int argc, char *argv[]);
int 		delcom(int argc, char *argv[]);
int 		deldon(int argc, char *argv[]);
int 		delres(int argc, char *argv[]);
int 		si_cmd(int argc, char *argv[]);
int 		is_cmd(int argc, char *argv[]);
int 		file_cmd(int argc, char *argv[]);
int 		close_file_cmd(int argc, char *argv[]);
int 		question_cmd(int argc, char *argv[]);
int 		var_list_cmd(int argc, char *argv[]);
int 		undef_cmd(int argc, char *argv[]);
int		echo_int_cmd(int argc, char *argv[]);
int		echo_float_cmd(int argc, char *argv[]);
int		fread_cmd(int argc, char *argv[]);
int		silence_cmd(int argc, char *argv[]);
int		rep_cmd(FILE *, char *);
int 		temps(int argc, char *argv[]);
int 		exit_cmd(int argc, char *argv[]);
int 		proglist_cmd(int argc, char *argv[]);
int 		load_cmd(int argc, char *argv[]);
int 		shell_cmd(int argc, char *argv[]);
void		init_var(void);
int		init_var_cmd(int argc, char *argv[]);
int		num_com(int argc, char *argv[]);
int		hist_cmd(int argc, char *argv[]);
int		mon_cmd(int argc, char *argv[]);
int		fin_mon_cmd(int argc, char *argv[]);
void            print(char*, ...);
int		flush_cmd(int argc, char *argv[]);
int		greetb_cmd(int argc, char *argv[]);
void		error_mess(int);
FILE           *Copen(char *, char *, char *);
FILE           *CCopen(char *, char *, char *, char *);
FILE           *CIopen(char *, char *, char *, int);
FILE           *fmemopen(void *, int, char *);
int		time_cmd(int argc, char *argv[]);

/*
 *   ee.c
 */
int	 	SetValue(char *, double *);
int		Evaluate(char *, double *, int *);

/*
 *   interface
 */
void 		exit_prog(void);
void 		init_prog(void);
void		dest_prop(int, int);

/*
 *   interp.c
 */
void		prog_c(int argc, char *argv[], char *, char int_ini_c[], int);
void		lect_com(void);
void		extrait_arg(void);
void		execute_c(void);
int		change_lev();
void		substit(void);
void		substit2(void);
void		shell_c(int argc, char *argv[]);
int 		lookup_c(char *names[], char *, int *, int);
void		prTime(void);
double          (*fonc(char *))(double ,double);
int		convert_int(char *);
int		S_convert_int(char *);
double		convert_float(char *);
double		S_convert_float(char *);
int		eval_cmd(int argc, char *argv[]);
int 		is_alphab(char);
int		is_alphab_or_num(char);
void		read_float(float *);
void 		read_int(int *);
void 		read_char(char *);
void		print_ev_error(int);
/*--------------------------------------------------------------------
--------------------------------------------------------------------*/





#define comp(s1,s2) (!strcmp((s1),(s2)))

int		prlevel,
                ind_run,
 		__nbcom,
                __nblignes,
		__com_max,
		__greet_max,
		__mess_max,
                __nss,
		__nmode_fonc,
		__maxvoice,
                __nbcond,
		__nbargmax,
                __nbfoncmax,
                __nblabelmax,
		__max_quest,
		__n_com_prec,
		ind_x_mode,
		ind_x_func,
		ind_x_param,
		ind_x_rep,
		i_func_ind;


extern	pfi    *proc[];
pfi	       *procw;
extern 	pfib	procb[];
extern	char   *namesb[];
extern char    *mess_interp[];

char	      **mess,
	      **prompt_mode,
              **greet,
              **names,
	      **nom_com,
             ***ligne_com,
              **com_prec,
	       *argv_init_interp[20];

int	        ind_com,
                i_greet,
	       *nb_label,
               *tr_label,
	      **num_label,
               *len_n,
	       *sil_com,
	      **mode_com_int,
               *nb_par,
		nb_com,
               *nb_lignes,
                horloge,
		nb_mode_fonc,
                nb_commandes,
                i_message,
              **mode_com,
               *par_com,
                is_com,
                i_speed,
		curvoice,	       
               *deb_nom,
	       *fin_nom,
		ix_com,
		pr_com,
		i_com,
                i_com_cur,
		i_ligne_cur,
		i_lec_cur,
                i_init_interp,
                sil_init_interp,
		argc_init_interp,
		ind_greet_x;
long		i_time_x;

FILE	      **inp;                   /* 'voices' where the commands
					  are read. Voice 0 is stdin, 
					  the other are command files
					  successively called */ 
argv_t	       *argv_x;                
int	       *argc_x;  
  
               
/*-------------------------------------------------------------------------
    Variable used by the expression evaluator
-------------------------------------------------------------------------*/
char		hcom[1000];
/*-----------------------------------------------------------------------*/



/*-------------------------------------------------------------------------
    Running modes
-------------------------------------------------------------------------*/
int             mode_fonct_;
/*-----------------------------------------------------------------------*/



/*-------------------------------------------------------------------------
    Variables used by conditions (commands 'si' and 'is')
-------------------------------------------------------------------------*/
int		n_cond,
	       *s_cond;
v_c 	       *v_cond;
/*-----------------------------------------------------------------------*/



/*---- Variables used to manage files (monitor files, commands
       'read', 'write', etc...) ------------------------------------*/
FILE	      **sS,
	       *Mon_File;
int	       *sS_cmpt,
               *sS_i_o;
char	      **sS_nom;

/*------------------------------------------------------------------------*/



/*-------------------------------------------------------------------------
    Variable used with question files 
--------------------------------------------------------------------------*/
char	      **ques;
/*------------------------------------------------------------------------*/



/*--------------------------------------------------------------------------
    Predefined directories (section '!rep')
--------------------------------------------------------------------------*/
char		command_rep[80],
		data_rep[80],
		data_rep2[80],
                result_rep[80];
/*------------------------------------------------------------------------*/



#define _GOTO 5
#define _IFGT 6
#define _IFLT 7
#define _IFEQ 8
#define _EVAL 9
#define _PRIME_C 8803
#define _P_MULT 2743

#endif
