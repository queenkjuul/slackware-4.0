;/*************************************************************************
;** interpcom-1.2 (command interpreter - graph)                           **
;** graph.h : 						                  **
;** Copyright (C) 1999  Jean-Marc Drezet                                  **
;**                                                                       **
;**  This library is free software; you can redistribute it and/or        **
;**  modify it under the terms of the GNU Library General Public          **
;**  License as published by the Free Software Foundation; either         **
;**  version 2 of the License, or (at your option) any later version.     **
;**									  **
;**  This library is distributed in the hope that it will be useful,      **
;**  but WITHOUT ANY WARRANTY; without even the implied warranty of       **
;**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    **
;**  Library General Public License for more details. 			  **
;**									  **
;**  You should have received a copy of the GNU Library General Public    **
;**  License along with this library; if not, write to the Free		  **
;**  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.   **
;**                                                                       **
;** Please mail any bug reports/fixes/enhancements to me at:              **
;**      drezet@math.jussieu.fr                                           **
;** or                                                                    **
;**      Jean-Marc Drezet                                                 **
;**      Institut de Mathematiques                                        **
;**      Aile 45-55                                                       **
;**      2, place Jussieu                                                 **
;**      75251 Paris Cedex 05                                             **
;**      France								  **
;**                                                                       **
;**************************************************************************/


#ifndef _GRAPH
#define _GRAPH

#include <g2.h>
#include <g2_PS.h>
#include <g2_X11.h>



/*-------------------------------------------------------------------------
---------------------------------------------------------------------------
    Function prototypes 
---------------------------------------------------------------------------
-------------------------------------------------------------------------*/
/*
 *   graphcmd.c
 */
int 	defgraph_X11_cmd(int argc, char *argv[]);
int 	defgraph_PS_cmd(int argc, char *argv[]);
int 	graph_plot_cmd(int argc, char *argv[]);
int 	graph_lineto_cmd(int argc, char *argv[]);
int 	clear_graph_cmd(int argc, char *argv[]);
int 	fixcolor_cmd(int argc, char *argv[]);
int 	setcolor_cmd(int argc, char *argv[]);
int 	fixframe_cmd(int argc, char *argv[]);
int 	setframe_cmd(int argc, char *argv[]);
int     clip_line(float, float, float, float, float *, float *);
int 	graph_plot_c_cmd(int argc, char *argv[]);
int 	graph_lineto_c_cmd(int argc, char *argv[]);
void    init_prog_graph(void);
int 	set_clip_cmd(int argc, char *argv[]);

/*
 * graph.c
 */
void    fixgraph_s(void);
/*-----------------------------------------------------------------------*/

extern int _GRAPH_MESS;
extern int _GRAPH_X11;
extern int _GRAPH_PS;
extern int _GRAPH_COL;
extern int _GRAPH_FRAM;
extern pfi proc_graph[];

float	xinf_clip,
	xsup_clip,
	yinf_clip,
	ysup_clip;

#endif


