/*************************************************************************
** interpcom-1.2 (command interpreter - glue)                            **
** main.c : An application of the command interpreter                    **
**                                                                       **
** Copyright (C) 1999  Jean-Marc Drezet                                  **
**                                                                       **
**  This library is free software; you can redistribute it and/or        **
**  modify it under the terms of the GNU Library General Public          **
**  License as published by the Free Software Foundation; either         **
**  version 2 of the License, or (at your option) any later version.     **
**									 **
**  This library is distributed in the hope that it will be useful,      **
**  but WITHOUT ANY WARRANTY; without even the implied warranty of       **
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    **
**  Library General Public License for more details. 			 **
**									 **
**  You should have received a copy of the GNU Library General Public    **
**  License along with this library; if not, write to the Free		 **
**  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.   **
**                                                                       **
** Please mail any bug reports/fixes/enhancements to me at:              **
**      drezet@math.jussieu.fr                                           **
** or                                                                    **
**      Jean-Marc Drezet                                                 **
**      Institut de Mathematiques                                        **
**      Aile 45-55                                                       **
**      2, place Jussieu                                                 **
**      75251 Paris Cedex 05                                             **
**      France								 **
**                                                                       **
 *************************************************************************/

#include "interp.h"
#include "funct_graph.h"

int   _XRANGE_F   = 1;   
int   _XRANGE_D   = 2;   
int   _RFUNC_F    = 3;    
int   _RFUNC_D    = 4;    
int   _CFUNC_F    = 5;    
int   _CFUNC_D    = 6;    
int   _FOUR_TR    = 7;    
int   _BESS_PAR   = 8;   
int   _FUNC_MESS  = 0;  
int   _GRAPH_MESS = 24;
int   _FUNC_GRAPH_MESS = 29;
int   _GRAPH_X11  = 9;
int   _GRAPH_PS   = 10;
int   _GRAPH_COL  = 11;
int   _GRAPH_FRAM = 12;
pfi *proc[] =
{
proc_func,
proc_graph,
proc_func_graph,
};


int
main(int argc, char *argv[])
{
    Funcs = Funcs_func;
    _NBFONC = _NBFONC_FUNC;
    prog_c(argc, argv, "glue.ini", NULL, 0);
    return 0;
}

void
init_prog()
{
    init_prog_graph();
}

void
exit_prog()
{
    exit(0);
}
 
void
dest_prop(int typ, int i0)
{
    float	   *xx;
    
    if (typ == _GRAPH_X11 - 1 || typ == _GRAPH_PS - 1) {
  	xx = (float *) Obj[typ][i0].adresse;
	g2_close((int) xx[2]);
    }
    dest_prop_func(typ, i0);
}
