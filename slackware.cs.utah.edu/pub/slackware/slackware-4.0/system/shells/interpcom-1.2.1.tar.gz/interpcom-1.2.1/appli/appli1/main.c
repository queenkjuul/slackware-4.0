/*************************************************************************
** interpcom-1.2 (command interpreter - appli1)                          **
** main.c : An application of the command interpreter                    **
**                                                                       **
** Copyright (C) 1999  Jean-Marc Drezet                                  **
**                                                                       **
**  This library is free software; you can redistribute it and/or        **
**  modify it under the terms of the GNU Library General Public          **
**  License as published by the Free Software Foundation; either         **
**  version 2 of the License, or (at your option) any later version.     **
**									 **
**  This library is distributed in the hope that it will be useful,      **
**  but WITHOUT ANY WARRANTY; without even the implied warranty of       **
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    **
**  Library General Public License for more details. 			 **
**									 **
**  You should have received a copy of the GNU Library General Public    **
**  License along with this library; if not, write to the Free		 **
**  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.   **
**                                                                       **
** Please mail any bug reports/fixes/enhancements to me at:              **
**      drezet@math.jussieu.fr                                           **
** or                                                                    **
**      Jean-Marc Drezet                                                 **
**      Institut de Mathematiques                                        **
**      Aile 45-55                                                       **
**      2, place Jussieu                                                 **
**      75251 Paris Cedex 05                                             **
**      France								 **
**                                                                       **
 *************************************************************************/

#include "interp.h"
#include "funct.h"

int   _XRANGE_F = 1;   
int   _XRANGE_D = 2;   
int   _RFUNC_F  = 3;    
int   _RFUNC_D  = 4;    
int   _CFUNC_F  = 5;    
int   _CFUNC_D  = 6;    
int   _FOUR_TR  = 7;    
int   _BESS_PAR = 8;   
int   _FUNC_MESS;  /* 0 */

pfi *proc[] =
{
proc_func,
};


int
main(int argc, char *argv[])
{
    Funcs = Funcs_func;
    _NBFONC = _NBFONC_FUNC;
    prog_c(argc, argv, "funct.ini", NULL, 0);
    return 0;
}

void
init_prog()
{
}

void
exit_prog()
{
    exit(0);
}
 
void
dest_prop(int typ, int i0)
{
    dest_prop_func(typ, i0);
}
