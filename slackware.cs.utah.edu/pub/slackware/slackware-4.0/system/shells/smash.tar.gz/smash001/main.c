/* main.c
   main of smash 
   functions: main(), initial().
*/
 
#include "smash.h"

/* global variables
*/
 
char cmdline[LLEN];
int special_sym;	/* background, pipe, redirection. */
int line_len;	/* length of input line in characters. */
char **argvect;
int argcount;		/* number of tokens on a line */

int main( int argc,char **argv )
{
  Initial();
		if(argc==2)	/* if they used an option */
			if(strcmp(argv[1],"-v")==0)
				printf("\nSMAllSHell, v%s, (c) 1992,1994 Jon Madison\n",VERSION);
	system("stty erase ");	/* for convenience's sake. */

  for(;;)
  {
		special_sym = FALSE;
    printf( "%s", PROMPT );
   	if( (line_len=getline(cmdline)) > 1 )
		{
  		ToHisTbl( cmdline, &hisrec );
  		if( (argcount = gettoken( cmdline, &argvect )) > 0 )
				Interpret( argcount, &argvect[0] );  	
		}
  }
return(0);
}

int Initial()
{
  (void)signal( SIGINT, SIG_IGN );  /* ignore signals control_C and control_D */
  (void)signal( SIGQUIT, SIG_IGN );
	(void)signal( SIGTSTP, SIG_IGN ); 	/* & CTRL-Z too. */
  hisrec.rear=hisrec.count=0;
	return(0);
}
