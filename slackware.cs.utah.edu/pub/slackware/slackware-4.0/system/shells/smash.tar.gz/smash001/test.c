#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void handler();
void doit();

main()
{
	signal(SIGTSTP, SIG_IGN); 
	doit();
}	

void handler()
{
	char string[100];
	printf("\nCTRL-Z pressed.\n");
	scanf("%s",&string);
	if(strcmp(string,"fg")==0)
	{
		printf("\nPid %d resumed.\n",getpid());
		kill(getpid(),SIGCONT);
		printf("so go ahead w/the input!: ");
	}
}

void doit()
{
	char waiting[10];
	(void)signal(SIGTSTP,handler);
	printf("\nwaiting for input, Pid= %d:  ",getpid());
	scanf("%s",&waiting);
	printf("\nYou entered %s\n",waiting);
}
