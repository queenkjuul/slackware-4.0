#if !defined(__STRING_H)
#   define __STRING_H

#define CR '\n'
#define TAB '\t'

int substr(const char *, char *, char);
int strwhite(const char *);

#endif
