/* Define the menu to load when there are no args */
#define DEFAULT_MENU "/home/guest/menu"
