#if !defined(_PARSE_H)
#   define _PARSE_H

#define MENU_TITLE	0
#define MENU_NOP	1
#define MENU_EXEC	2
#define MENU_SUB	3
#define MENU_EXIT	4

#define MENU_BEGIN	"Menu"
#define MENU_END	"EndMenu"
#define MENU_OP_TITLE	"Title"
#define MENU_OP_EXEC	"Exec"
#define MENU_OP_SUB	"SubMenu"
#define MENU_OP_NOP	"Nop"
#define MENU_OP_EXIT	"Exit"

struct menu_items {
   int type;
   char *name;
   char *args;
   struct menu_items *next, *prev;
};

struct menu {
   char *name;
   struct menu_items *data;
   struct menu *next, *prev;
};

int parsefile(struct menu **,char *);
void freemem(struct menu *,char *);

#endif
