#if !defined (_MISC_H)
#   define _MISC_H

#include "parse.h"

void exec_item(struct menu_items item, struct menu **menu);

#endif
