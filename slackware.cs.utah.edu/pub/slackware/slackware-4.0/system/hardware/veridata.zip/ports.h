/*
 * ports.h (low level acces to the io-ports)
 * Time-stamp: <04 Aug 94 (15:05:57) by pive@ruca.ua.ac.be>
 */

#define SLOW_DOWN_IO __asm__ __volatile__("jmp 1f\n1:\tjmp 1f\n1:")

void outb_p(char value, unsigned short port);
unsigned int inb_p(unsigned short port);
