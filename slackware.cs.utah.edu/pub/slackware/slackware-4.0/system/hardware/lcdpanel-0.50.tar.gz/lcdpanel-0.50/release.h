char kernel_version[] = "1.2.12";
