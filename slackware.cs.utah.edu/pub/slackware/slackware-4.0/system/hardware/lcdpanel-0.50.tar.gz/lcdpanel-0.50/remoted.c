#include <stdio.h>

void cp (char *from, char *to)
{
  FILE *Ff, *Ft;
  char c;
  
  Ff = fopen (from, "rb");
  Ft = fopen (to, "wb");

  do {
    c = (char) fgetc (Ff);
    fputc (c, Ft);
  } while (!feof (Ff));

  fclose (Ff);
  fclose (Ft);
}

void main (void)
{
  cp ("/proc/version", "/var/bw/version");

  do {
    cp ("/proc/loadavg", "/var/bw/loadavg");
    cp ("/proc/meminfo", "/var/bw/meminfo");
    cp ("/proc/uptime", "/var/bw/uptime");
    cp ("/etc/utmp", "/var/bw/utmp");
    sleep (5);
  } while (1);
}
