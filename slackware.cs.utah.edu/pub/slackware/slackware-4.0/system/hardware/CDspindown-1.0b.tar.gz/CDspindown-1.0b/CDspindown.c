/*
 * ATAPI CDROM spindown adjustment utility
 * by Ciro Cattuto
 *
 * v1.0
 * 19 May 1996
 *
 * This code is distributed under the GNU General Public License
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/cdrom.h>

char *intervals[16] = {
	"vendor specific",
	"125 ms",
	"250 ms",
	"500 ms",
	"1 s",
	"2 s",
	"4 s",
	"8 s",
	"16 s",
	"32 s",
	"1 min",
	"2 min",
	"4 min",
	"8 min",
	"16 min",
	"32 min"
	};

int main(int argc, char *argv[])
{
int fd;
char current, new;
int arg, result, verbose=1;
char *program_name = argv[0];

if ( (argc > 1) && (*argv[1] == '-') )
	{
	if ( !strcmp(argv[1], "-q") )
		{
		verbose = 0;
		argc--;
		argv++;
		}
	else
		{
		fprintf(stderr, "Unknown command-line switch.\n");
		return -1;
		}
	} 

if (verbose)
	printf("ATAPI CDROM spindown adjustment utility\n");

if (argc < 2)
	{
	int i;

	printf("usage: %s [-q] <device> <code>\n\n", program_name);
	for (i=0 ; i<16 ; i++)
		printf(" %2d - %s\n", i, intervals[i]);
	printf("\n");
	return 0;
	}

fd = open(argv[1], O_RDONLY);
if (fd == -1)
	{
	fprintf(stderr, "Error opening device (code=%d).\n", errno);
	return -1;
	}

result = ioctl(fd, CDROMGETSPINDOWN, &current);
if (result == -1)
	{
	fprintf(stderr, "CDROMGETSPINDOWN IOCTL error (code=%d).\n", errno);
	return -1;
	}
if ( (current < 0) || (current > 15) )
	{
	fprintf(stderr, "Unknown spindown setting (%d).\n", current);
	return -1;
	}
if (verbose)
	printf("current spindown setting = %s\n", intervals[current]);

if (argc == 2)
	{
	close(fd);
	return 0;
	}

arg = atoi(argv[2]);
if ( (arg < 0) || (arg > 15) )
	{
	fprintf(stderr, "Invalid spindown setting.\n");
	return -1;
	}
new = (char) arg;
result = ioctl(fd, CDROMSETSPINDOWN, &new);
if (result == -1)
	{
	fprintf(stderr, "CDROMSETSPINDOWN IOCTL error (code=%d).\n", errno);
	return -1;
	}
if (verbose)
	printf("new setting = %s\n", intervals[new]);

close(fd);
return 0;
}

