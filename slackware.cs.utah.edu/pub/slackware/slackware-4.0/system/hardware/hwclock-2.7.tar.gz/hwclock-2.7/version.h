/* This is just a dummy file.  When hwclock is packaged within another
   package, e.g. util-linux, the file in the position contains other stuff.
   When hwclock is packaged independently, the file needs to exist, but
   needn't contain anything.
*/
