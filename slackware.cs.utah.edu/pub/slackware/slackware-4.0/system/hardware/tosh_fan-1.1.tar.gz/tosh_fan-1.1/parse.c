/*-------------------------------------------------------------------------
 * Copyright (c) 1998 Kenneth W. Sodemann (stufflehead@bigfoot.com)
 *-------------------------------------------------------------------------
 * parse.c
 *
 * Routines used to parse the user inputs.
 *
 * $Log: parse.c,v $
 * Revision 1.4  1998/07/25 22:28:53  kwsodema
 * Added the -l switch and functionallity for two number on
 * the -t switch
 *
 * Revision 1.3  1998/07/22 00:16:12  kwsodema
 * Changed the default for verbose to TRUE
 * Removed the -V flag
 * Switched put ON and OFF with the proper flags
 *
 * Revision 1.2  1998/07/22 00:09:25  kwsodema
 * Changed the min time from 10 (erroneous) to 1 (correct)
 *
 * Revision 1.1  1998/07/21 23:24:34  kwsodema
 * Initial revision
 *
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *-------------------------------------------------------------------------
 */

#include <stdlib.h>
#include <ctype.h>
#include "parse.h"
#include "msgs.h"

#define LO_MINS     1
#define HI_MINS     500
#define TNUM_STRING "-t must be followed by a number from 1 to 500"

/*-------------------------------------------------------------------------
 *  parse_cmd_line
 *
 *  Parse out the command line args, and set flags accordingly.  Output
 *  any error message to stderr.
 *
 *  Inputs:
 *   argc: the arg count
 *   argv: the args
 *
 *  Outputs:
 *   parse_flags stuctured set occording to cmd line flags.  The
 *   values in this output are undefined if the function returns
 *   FALSE.
 *
 *  Returns:
 *   TRUE if everything was OK
 *   FALSE if there was an error
 *-------------------------------------------------------------------------
 */
BOOL parse_cmd_line (int argc, char *argv[], parse_flags_type *flags)
{
  BOOL valid;
  int  idx, i, len;
  char ch;
  char msg_buf[80] = "";

  /* Initialize the flags to default values. */
  flags->verbose = TRUE;
  flags->turn_on = FALSE;
  flags->turn_off = FALSE;
  flags->version = FALSE;
  flags->help = FALSE;
  flags->timed = FALSE;
  flags->logging = FALSE;
  flags->on_minutes = 0;
  flags->off_minutes = 0;
  
  /* Look for arguments */
  valid = TRUE;
  idx = 1;
  while ((idx < argc) && valid)
    {
      /* look for a dash in the first character */
      if (argv[idx][0] == '-')
	{
	  /* look for --version or --help */
	  if (!strcmp (argv[idx], "--version"))
	    {
	      flags->version = TRUE;
	    }
	  else if (!strcmp (argv[idx], "--help"))
	    {
	      flags->help = TRUE;
	    }
	  else
	    {
	      /* look for valid flags */
	      len = strlen (argv[idx]);
	      for (i = 1; i < len; i++)
		{
		  ch = argv[idx][i];
		  switch (ch)
		    {
		    case 'f':
		      flags->turn_off = TRUE;
		      break;

		    case 'n':
		      flags->turn_on = TRUE;
		      break;

		    case 'v':
		      flags->verbose = TRUE;
		      break;

		    case 'q':
		      flags->verbose = FALSE;
		      break;

                    case 'l':
                      flags->logging = TRUE;
                      break;

		    case 't':
		      /* if this is the case, it better be the only
		       * part of the argument, and it better be followed
		       * by a number.
		       */
		      if (len == 2)
			{
			  flags->timed = TRUE;
			  /* check the next argument */
			  if (++idx < argc)
			    {
			      flags->on_minutes = atoi (argv[idx]);
			      flags->off_minutes = flags->on_minutes;
			      if (flags->on_minutes < LO_MINS ||
				  flags->on_minutes > HI_MINS)
				{
				  valid = FALSE;
				  strcpy (msg_buf, TNUM_STRING);
				}
			      /* if we are still valid, and there 
			       * is another arg, see if it is a
			       * number, and if so, get it's value.
			       */
			      if (valid && ((idx + 1) < argc))
				{
				  if (isdigit(argv[idx + 1][0]))
				    {
				      flags->off_minutes = atoi(argv[++idx]);
				      if (flags->off_minutes < LO_MINS ||
					  flags->off_minutes > HI_MINS)
					{
					  valid = FALSE;
					  strcpy (msg_buf, TNUM_STRING);
					}
				    }
				}
				    
			    }
			  else
			    {
			      valid = FALSE;
		              strcpy (msg_buf, TNUM_STRING);
			    }
			}
		      else
			{
			  valid = FALSE;
			  strcpy (msg_buf, TNUM_STRING);
			}
		      break;

		    default:
		      valid = FALSE;
		    } /* end-switch */
		} /* end-for */
	    }
	}
      else
	{
	  valid = FALSE;
	  strcpy (msg_buf, argv[idx]);
	}
      ++idx;
      if (!valid)
	{
	  dump_error_msg (invld_args, msg_buf);
	}
    } /* end-while */

  return (valid);
}
