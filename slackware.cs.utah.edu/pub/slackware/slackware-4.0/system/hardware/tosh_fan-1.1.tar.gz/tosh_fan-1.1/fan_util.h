#ifndef __FAN_UTIL_H
#define __FAN_UTIL_H    1
/*-------------------------------------------------------------------------
 * Copyright (c) 1998 Kenneth W. Sodemann (stufflehead@bigfoot.com)
 *-------------------------------------------------------------------------
 * fan_util.f 
 *
 * Provide routines that will turn the fans of a Toshiba Salellite
 * Pro 465CDX laptop on and off.
 *
 * $Log: fan_util.h,v $
 * Revision 1.2  1998/07/25 03:30:20  kwsodema
 * Added logging parameters to the ON & OFF functions.
 *
 * Revision 1.1  1998/07/21 01:50:43  kwsodema
 * Initial revision
 *
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *-------------------------------------------------------------------------
 */

#include "common.h"

/*-------------------------------------------------------------------------
 * fan_is_on
 *
 * Check the current status of the fan.
 *
 * Returns TRUE if the fan is on, FALSE otherwise.
 *-------------------------------------------------------------------------
 */
BOOL fan_is_on ();


/*-------------------------------------------------------------------------
 * turn_fan_on
 *
 * Attempt to turn the fan on.  Log the attempt in the syslog if 
 * log_it is TRUE.
 *
 * Returns TRUE if the fan is successfully turned on.  Returns FALSE
 * otherwise.
 *-------------------------------------------------------------------------
 */
BOOL turn_fan_on(BOOL log_it);


/*-------------------------------------------------------------------------
 * turn_fan_off
 *
 * Attempt to turn the fan off.  Log the attempt in the syslog if
 * log_it is TRUE.
 *
 * Returns TRUE if the fan is successfully turned off.  Returns FALSE
 * otherwise.
 *-------------------------------------------------------------------------
 */
BOOL turn_fan_off(BOOL log_it);

#endif
