#ifndef __TOSH_FAN_MSGS_H
#define __TOSH_FAN_MSGS_H
/*-------------------------------------------------------------------------
 * Copyright (c) 1998 Kenneth W. Sodemann (stufflehead@bigfoot.com)
 *-------------------------------------------------------------------------
 * msgs.h
 *
 * Routines used to output messages to the user.  The idea here is
 * to centralize the output so the other routines can more easily
 * be ported into a different interface.
 *
 * $Log: msgs.h,v $
 * Revision 1.3  1998/07/24 20:24:35  kwsodema
 * Added display_fan_on and display_fan_off.  Removed display_msg.
 *
 * Revision 1.2  1998/07/22 20:36:31  kwsodema
 * Added the display_msg function.
 *
 * Revision 1.1  1998/07/21 21:45:54  kwsodema
 * Initial revision
 *
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *-------------------------------------------------------------------------
 */

#include "common.h"

/*-------------------------------------------------------------------------
 * Defined errors.
 *-------------------------------------------------------------------------
 */
typedef enum error_type
{
  io_perms,
  invld_args,
  blank_err
} error_type;

/*-------------------------------------------------------------------------
 * dump_error_msg
 *
 * Dumps the error message for a known class of error out to the 
 * error stream, appending msg to the end of the canned error message.
 *-------------------------------------------------------------------------
 */
void dump_error_msg (error_type err, char *msg);

/*-------------------------------------------------------------------------
 * display_version
 *
 * Display the version message.
 *-------------------------------------------------------------------------
 */
void display_version (void);

/*-------------------------------------------------------------------------
 * display_help
 *
 * Display the help message.
 *-------------------------------------------------------------------------
 */
void display_help (void);

/*-------------------------------------------------------------------------
 * display_fan_on
 *
 * Display the fan on message.
 *-------------------------------------------------------------------------
 */
void display_fan_on (void);

/*-------------------------------------------------------------------------
 * display_fan_off
 *
 * Display the fan off message.
 *-------------------------------------------------------------------------
 */
void display_fan_off (void);

#endif
