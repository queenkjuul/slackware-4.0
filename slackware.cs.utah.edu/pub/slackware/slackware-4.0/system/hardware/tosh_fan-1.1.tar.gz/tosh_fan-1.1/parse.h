#ifndef __PARSE_H
#define __PARSE_H
/*-------------------------------------------------------------------------
 * Copyright (c) 1998 Kenneth W. Sodemann (stufflehead@bigfoot.com)
 *-------------------------------------------------------------------------
 * parse.h
 *
 * Routines used to parse the user inputs.
 *
 * $Log: parse.h,v $
 * Revision 1.2  1998/07/25 22:29:29  kwsodema
 * Added logging and ON & OFF times.
 *
 * Revision 1.1  1998/07/21 23:24:54  kwsodema
 * Initial revision
 *
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *-------------------------------------------------------------------------
 */

#include "common.h"

typedef struct parse_flags_type
{
  BOOL verbose;     /* TRUE if verbose mode, FALSE otherwise       */
  BOOL turn_on;     /* TRUE if user wants fan on, FALSE otherwise  */
  BOOL turn_off;    /* TRUE if user wants fan off, FALSE otherwise */
  BOOL version;     /* TRUE if user wants version sent out         */
  BOOL help;        /* TRUE if the user wants the help message     */
  BOOL timed;       /* TRUE if timed mode.                         */
  BOOL logging;     /* TRUE if the user want logging turned on     */
  int  on_minutes;  /* Number of minutes the fan should be on      */
  int  off_minutes; /* Number of minutes the fan should be off     */
} parse_flags_type;

/*-------------------------------------------------------------------------
 *  parse_cmd_line
 *
 *  Parse out the command line args, and set flags accordingly.  Output
 *  any error message to stderr.
 *
 *  Inputs:
 *   argc: the arg count
 *   argv: the args
 *
 *  Outputs:
 *   parse_flags stuctured set occording to cmd line flags.  The
 *   values in this output are undefined if the function returns
 *   FALSE.
 *
 *  Returns:
 *   TRUE if everything was OK
 *   FALSE if there was an error
 *-------------------------------------------------------------------------
 */
BOOL parse_cmd_line (int argc, char *argv[], parse_flags_type *flags); 

#endif
