/*-------------------------------------------------------------------------
 * Copyright (c) 1998 Kenneth W. Sodemann (stufflehead@bigfoot.com)
 *-------------------------------------------------------------------------
 * fan_util.c 
 *
 * Provide routines that will turn the fans of a Toshiba Salellite
 * Pro 465CDX laptop on and off.
 *
 * This work is derived from fan.c, which was originally written
 * by Jonathan A. Buzzard (jab@hex.prestel.co.uk).
 *
 * $Log: fan_util.c,v $
 * Revision 1.4  1998/07/26 19:19:48  kwsodema
 * Only check lower byte of status in fan_is_on().  This fixes some
 * problems with faulty state reporting.
 *
 * Revision 1.3  1998/07/26 18:18:58  kwsodema
 * Fixed errors in the syslog messages.
 *
 * Revision 1.2  1998/07/25 03:31:51  kwsodema
 * Added logging to the ON and OFF functions.
 *
 * Revision 1.1  1998/07/21 01:51:05  kwsodema
 * Initial revision
 *
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *-------------------------------------------------------------------------
 */

#include <syslog.h>
#include "common.h"

/*-------------------------------------------------------------------------
 * fan_is_on
 *
 * Check the current status of the fan.
 *
 * Returns TRUE if the fan is on, FALSE otherwise.
 *-------------------------------------------------------------------------
 */
BOOL fan_is_on ()
{
  unsigned long status;

  asm ("pushl %%eax\n\t" \
       "pushl %%ebx\n\t" \
       "pushl %%ecx\n\t" \
       "movw $0xfefe,%%ax\n\t" \
       "movw $0x0004,%%bx\n\t" \
       "movw $0x0000,%%cx\n\t" \
       "inb $0xb2,%%al\n\t" \
       "movw %%cx,%0\n\t" \
       "popl %%ecx\n\t" \
       "popl %%ebx\n\t" \
       "popl %%eax\n\t"
       :"=m" (status) );

  if ((status & 0x000000FF) == 0x01)
    {
      return TRUE;
    }
  else
    {
      return FALSE;
    }
} /* end fan_is_on() */


/*-------------------------------------------------------------------------
 * turn_fan_on
 *
 * Attempt to turn the fan on.
 *
 * Returns TRUE if the fan is successfully turned on.  Returns FALSE
 * otherwise.
 *-------------------------------------------------------------------------
 */
BOOL turn_fan_on(BOOL log_it)
{
  BOOL success;

  asm ("pushl %eax\n\t" \
       "pushl %ebx\n\t" \
       "pushl %ecx\n\t" \
       "movw $0xffff,%ax\n\t" \
       "movw $0x0004,%bx\n\t" \
       "movw $0x0001,%cx\n\t" \
       "inb $0xb2,%al\n\t" \
       "popl %ecx\n\t" \
       "popl %ebx\n\t" \
       "popl %eax");
  success = fan_is_on();

  if (log_it && success)
    {
      syslog (LOG_INFO, "Fan turned on");
    }
  else
    {
      syslog (LOG_WARNING, "Attempt to turn fan on failed");
    }

  return success;
} /* end turn_fan_on() */

/*-------------------------------------------------------------------------
 * turn_fan_off
 *
 * Attempt to turn the fan off.
 *
 * Returns TRUE if the fan is successfully turned off.  Returns FALSE
 * otherwise.
 *-------------------------------------------------------------------------
 */
BOOL turn_fan_off(BOOL log_it)
{
  BOOL success;

  asm ("pushl %eax\n\t" \
       "pushl %ebx\n\t" \
       "pushl %ecx\n\t" \
       "movw $0xffff,%ax\n\t" \
       "movw $0x0004,%bx\n\t" \
       "movw $0x0000,%cx\n\t" \
       "inb $0xb2,%al\n\t" \
       "popl %ecx\n\t" \
       "popl %ebx\n\t" \
       "popl %eax");
  success = !fan_is_on();
  
  if (log_it && success)
    {
      syslog (LOG_INFO, "Fan turned off");
    }
  else
    {
      syslog (LOG_WARNING, "Attempt to turn fan off failed");
    }

  return success;
} /* end turn_fan_off() */
