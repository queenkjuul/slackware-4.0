#ifndef __TOSH_FAN_COMMON_H
#define __TOSH_FAN_COMMON_H
/*-------------------------------------------------------------------------
 * Copyright (c) 1998 Kenneth W. Sodemann (stufflehead@bigfoot.com)
 *-------------------------------------------------------------------------
 * common.h
 *
 * Common definitions used for the tosh_fan program.
 *
 * $Log: common.h,v $
 * Revision 1.4  1998/07/25 22:28:15  kwsodema
 * Updated the usage message and the version string.
 *
 * Revision 1.3  1998/07/22 20:26:13  kwsodema
 * Removed 'V' from the list of valid args.
 *
 * Revision 1.2  1998/07/22 19:18:11  kwsodema
 * Added common strings.
 *
 * Revision 1.1  1998/07/21 01:49:59  kwsodema
 * Initial revision
 *
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *-------------------------------------------------------------------------
 */

/* define a boolean "type" for use here */
#ifndef BOOL
#define BOOL     int
#define TRUE     1
#define FALSE    0
#endif

/* define the version string for this program */
#define VERSION "tosh_fan v1.1, Copyright (c) 1998, Kenneth W. Sodemann"
#define PROG_NAME "tosh_fan"
#define USAGE_STR "Usage: \n" \
                  "  tosh_fan [-[n|f][q|v]l] [-t number]" \
		  " [--version] [--help]\n" \
		  "    -n turns the fan on\n" \
		  "    -f turns the fan off\n" \
		  "    -q quiet mode\n" \
		  "    -v verbose moden\n" \
	          "    -l turns on system logging\n"\
		  "    -t number toggles the fan on and off every" \
		  " number seconds\n" \
		  "    --version supplies the version information\n" \
		  "    --help displays this mesage\n"


#endif
