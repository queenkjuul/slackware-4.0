/*-------------------------------------------------------------------------
 * Copyright (c) 1998 Kenneth W. Sodemann (stufflehead@bigfoot.com)
 *-------------------------------------------------------------------------
 * tosh_fan.c
 *
 * Main program file for the tosh_fan program.
 *
 * $Log: tosh_fan.c,v $
 * Revision 1.4  1998/07/26 19:30:33  kwsodema
 * Removed the infinite loop, and replaced it with a loop that will
 * exit if we are unable to turn the fan on or off as we please.
 * Added an error message to syslog if this loop ever does exit.
 *
 * Revision 1.3  1998/07/25 22:30:00  kwsodema
 * Added logging and ON & OFF times.
 *
 * Revision 1.2  1998/07/22 20:35:38  kwsodema
 * Changed to use "display_msg" instead of printf.
 *
 * Revision 1.1  1998/07/22 19:15:07  kwsodema
 * Initial revision
 *
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *-------------------------------------------------------------------------
 */

#include <unistd.h>
#include <stdio.h>
#include <syslog.h>
#include "common.h"
#include "msgs.h"
#include "fan_util.h"
#include "parse.h"

int main (int argc, char *argv[])
{
  parse_flags_type flags;
  BOOL             valid;
  int              on_time;
  int              off_time;
  unsigned int     time_left;

  /* parse the command line */
  if (!parse_cmd_line(argc, argv, &flags))
    {
      exit (-1);
    }

  /* If the user wants help, or version related information,
   * give it to them, and then exit.
   */
  if (flags.help)
    {
      display_help();
      exit (0);
    }

  if (flags.version)
    {
      display_version();
      exit (0);
    }

  /* Check for the case where the user has asked for the fan to be
   * on and off at the same time.  Give them a message, and exit
   * if that is the case.
   */
  if (flags.turn_on && flags.turn_off)
    {
      dump_error_msg (invld_args, "Cannot use -f and -n at the same time.");
      exit (-1);
    }
  
  /* Check the io perms.  Give an error message and exit if the user's 
   * are insufficient.*/
  if (ioperm(0xb2, 1, 1))
    {
      dump_error_msg (io_perms, NULL);
      exit (-1);
    }

  /* Alright, we got through all of the error stuff.  If the user
   * wanted logging, lets open the system log.
   */
  if (flags.logging)
    {
      openlog (PROG_NAME, LOG_PID, LOG_USER);
    }

  /* If the user wants to turn the fan on, do so. */
  if (flags.turn_on)
    {
      valid = turn_fan_on(flags.logging);
    }
  /* If the user wants to turn the fan off, do so. */
  else if (flags.turn_off)
    {
      valid = turn_fan_off(flags.logging);
    }

  /* If the user has requested timed mode, enter an infinite loop,
   * and toggle the fan settings every x number of minutes.
   */
  if (flags.timed)
    {
      on_time = flags.on_minutes * 60;
      off_time = flags.off_minutes * 60;
      valid = TRUE;
      /* only keep running as long as we are able to affect the 
       * fan.
       */
      while (valid)
	{
	  /* determine how long we sleep based on the 
	   * current state of the fan
	   */
	  if (fan_is_on())
	    {
	      time_left = sleep (on_time);
	      valid = turn_fan_off(flags.logging);
	    }
	  else
	    {
	      time_left = sleep (off_time);
	      valid = turn_fan_on(flags.logging);
	    }
	}
      /* if we are here, we broke out of the loop above due to an
       * error turning the fan on or off.  Better log that one
       * as an error (if logging is turned on).
       */
      if (flags.logging)
	{
	  syslog (LOG_ERR, "tosh_fan shutting down due to failure");
	}
    }

  /* If verbose, print a message stating what the fan's state is.  */
  if (flags.verbose)
    {
      if (fan_is_on())
	{
	  display_fan_on();
	}
      else
	{
	  display_fan_off ();
	}
    }

  /* Time to go.  Close the log before you leave. */
  if (flags.logging)
    {
      closelog();
    }
  return 0;
}



