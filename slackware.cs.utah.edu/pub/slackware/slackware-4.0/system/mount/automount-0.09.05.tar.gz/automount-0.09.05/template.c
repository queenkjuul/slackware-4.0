/* automount1.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */


/*****************************************************************************/


/* end of automount1.c */
