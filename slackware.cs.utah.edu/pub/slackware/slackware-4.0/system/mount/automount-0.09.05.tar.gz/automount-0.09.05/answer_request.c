/* answer_request.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#include "main.h"

/*****************************************************************************/
FLAG answer_request(char *response)
{
    /* this function answers the client request via the pipe */
    /* using its argument. The return value is the string */
    /* converted to a FLAG (ERROR/BUSY/EJECTED) */

    FLAG retval = ERROR;

#ifndef DONT_USE_SELECT
    /* send answer to client */
    /* first set signal handler */
#endif /* DONT_USE_SELECT */

    if(response == (char *)NULL)
      return(EJECTED);

    if(strcmp(response, DEVICE_BUSY) == 0)
        retval = BUSY;

    if(strcmp(response, DEVICE_NOT_MOUNTED) == 0)
        retval = ERROR;
           
    if(strcmp(response, DEVICE_UNUSABLE) == 0)
        retval = ERROR;

    if(strcmp(response, NAME_UNKNOWN) == 0)
        retval = ERROR;
           
    if(strcmp(response, DEVICE_ERROR) == 0)
        retval = ERROR;

    return(retval);
}
