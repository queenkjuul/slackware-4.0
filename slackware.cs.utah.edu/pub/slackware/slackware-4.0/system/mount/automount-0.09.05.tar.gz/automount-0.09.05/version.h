/* version.h */
/* main header for automount application */

/* Written and (C) Copyright Wolfram Saringer 1995/96/97/98/99  */
/* Documentation is available in the file $$$.dvi            */

#ifndef VERSION_H
#define VERSION_H

/*****************************************************************************/
/* daemon version */
#define AUTOMOUNT_VERSION "0.09.05"

#endif /* VERSION_H */
/* end of version.h */
