/* wfile1.c */
/* first part of the file related functions */

/* This file is part of the generic utility library */
/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file wutil.dvi */
/* adapted from wutil library */

#include "main.h"

/*****************************************************************************/
/* this functions gets the line starting at 'offset' from 'file' after       */
/* allocating a buffer of appropriate size. EVERY line must with a NEWLINE   */
/* character. The address of the buffer or ERROR in case of an error is      */
/* returned.                                                                 */
char *get_line(FILE *file, long offset)
{
   char *buffer = (char *)NULL;
   char *tmp;
   long current_size = (long)0;

   do
   {
      /* if not the first run, kill old buffer */
      if(buffer != (char *)NULL)
	 free(buffer);

      /* increase buffersize */
      current_size += BUFFERSIZE;

      /* get new buffer */
      if((buffer = malloc(current_size)) == (char *)NULL)
      {
	 PANIC("malloc() failed");
	 return((char *)ERROR);
      }

      /* set to start of line */
      if(fseek(file, offset, SEEK_SET) != 0)
      {
	 free(buffer);
	 PANIC("fseek() failed");
	 return((char *)ERROR);
      }

      /* get line */
      if(fgets(buffer, current_size, file) == (char *)NULL)
      {
	 free(buffer);
	 return((char *)NULL);
      }
   }
   /* if no newline, this is not the whole line => once again */
   /* if this is the last line (next char is EOF), this is OK */
   while(((tmp = index(buffer, NEWLINE)) == (char *)NULL) && 
	 (fgetc(file) != EOF));

   if(tmp != (char *)NULL)
   {
      /* remove newline */
      *tmp = END_OF_STR;
   }
      
   return(buffer);
}


/* end of get_line.c */
