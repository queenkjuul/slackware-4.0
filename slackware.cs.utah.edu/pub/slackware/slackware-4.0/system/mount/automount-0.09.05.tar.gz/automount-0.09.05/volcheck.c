/* volcheck.c */
/* volcheck client */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#ifndef GLOBALVARS_ENABLED
#define GLOBALVARS_ENABLED
#endif

#include "main.h"


/*****************************************************************************/
int main(int argc, char **argv)
{
   int fifo_fd;
   char *buffer;

   if((buffer = calloc(BUFFERSIZE, sizeof(char))) == NULL)
   {
     (void) fprintf(stderr, "calloc() failed");
     exit(4);
   }

   if((fifo_fd = open(FIFO_NAME, O_WRONLY)) < 0)
   {
      (void) fprintf(stderr, "%s: open fifo failed, server is maybe not active\n", argv[0]);
      exit(2);
   }

#ifdef DEBUG
   (void) printf("writing -%s- with strlen() = %d to pipe\n",
                 CHECKREQUEST, strlen(CHECKREQUEST));
#endif

   if(write(fifo_fd, CHECKREQUEST, strlen(CHECKREQUEST)) < 0)
   {
       (void) fprintf(stderr, "%s: error writing to pipe: %s\n",
                      argv[0], strerror(errno));
       exit(3);
   }

   /* close pipe */
   (void) close(fifo_fd);

   /* exit */
   return(0);
}


/* end of volcheck.c */
