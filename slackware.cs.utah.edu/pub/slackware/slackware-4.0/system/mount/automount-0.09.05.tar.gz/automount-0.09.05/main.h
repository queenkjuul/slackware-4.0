/* main.h */
/* main header for automount application */

/* Written and (C) Copyright Wolfram Saringer 1995/97 */
/* Documentation is available in the file $$$.dvi     */

#ifndef MAIN_H
#define MAIN_H

/*****************************************************************************/
/* system includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <ctype.h>
#include <time.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mount.h>
#include <sys/uio.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <sys/wait.h>

/* this file processes the compile time options */
#include "process_options.h"

/* personal includes */
#include "typedef.h"
#include "functions.h"
#include "consts.h"
#include "panic.h"
#include "global.h"
#include "log_msg.h"
#include "client_err.h"
#include "version.h"

#endif /* MAIN_H */
/* end of main.h */
