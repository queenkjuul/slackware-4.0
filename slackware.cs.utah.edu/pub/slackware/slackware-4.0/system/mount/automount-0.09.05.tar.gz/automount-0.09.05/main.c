/* main.c */
/* Automount daemon main */

/* Written and (C) Copyright Wolfram Saringer 1995/98  */
/* Documentation is available in the file $$$.dvi      */

#ifndef GLOBALVARS_ENABLED
#define GLOBALVARS_ENABLED
#endif

#include "main.h"

/*****************************************************************************/
int main(int argc, char **argv)
{
   int intervall = DEFAULT_INTERVALL;
   
   program_name = argv[0];
   fifo_fd = -1;

#ifdef USE_SYSLOGD
   /* provide header for syslogd messages */
   /* progname, use console, write PID, class daemon */
   openlog(argv[0], LOG_CONS | LOG_PID, LOG_DAEMON);
#endif /* USE_SYSLOGD */

#ifndef DEBUG
   /* AUTOMOUNT_VERSION is defined as a string */
   /* ANSI states that adjacent strings are bound together */
   LOG_MSG("Initializing automountd, Version " AUTOMOUNT_VERSION);
#endif

   if(open_fifo(&fifo_fd) == ERROR)
   {
      /* well, in case of an error this function will not return */
      /* but for the sake of future extensions... */
      PANIC("Initialization error");
   }

#ifdef DEBUG
   printf("automountd, Version %s\n", AUTOMOUNT_VERSION);
   printf("automountd: main(): fifo_fd = %d\n", fifo_fd);
#endif

   if(check_cmdline(argc, argv, &intervall) == ERROR)
   {
      /* error message already printed, exit */
      exit(1);
   }

   /* init global vars */
   mount_table = NULL;
   mount_table_size = 0;

   /* read init file */
   if(read_initfile() == ERROR)
   {
      PANIC("Init file error");
   }

   /* in debug mode run as normal program, not as a daemon */
#ifndef DEBUG
   if(daemon_init() == ERROR)
   {
      PANIC("(Unknown)");
   }
#endif

   /* install signal handlers */
   /* $$$ change to POSIX $$$ */
   /* the SIGHUP handler */
   (void) signal(SIGHUP, sighup_handler);

   /* the normal exit signals */
   (void) signal(SIGTERM, sigterm_handler);
   (void) signal(SIGINT,  sigterm_handler);
   (void) signal(SIGQUIT, sigterm_handler);
   /* when the abort() function sends SIGABRT, this case should */
   /* already registered (logged to a file) */
/*   signal(SIGABRT, sigterm_handler); */

   /* log some others */
#ifndef USE_EXTENDED_SIGARGS

#ifndef DONT_CATCH_SIGSEGV
   (void) signal(SIGSEGV, sigsegv_handler);
#endif /* DONT_CATCH_SIGSEGV */

#else

#ifndef DONT_CATCH_SIGSEGV
   /* the cast is just to calm cc and lint */
   (void) signal(SIGSEGV, (void (*)(int)) sigsegv_handler);
#endif /* DONT_CATCH_SIGSEGV */

#endif /* USE_EXTENDED_SIGARGS */

   /* ignore some others */
   (void) signal(SIGUSR1, SIG_IGN);
   (void) signal(SIGUSR2, SIG_IGN);
#ifndef DONT_USE_SELECT
   (void) signal(SIGPIPE, SIG_IGN);
#endif /* DONT_USE_SELECT */

   /* enter main loop */
   main_loop(intervall);
   /* should never return */
   /* NOTREACHED */
   return(-1);
}

/* end of main.c */
