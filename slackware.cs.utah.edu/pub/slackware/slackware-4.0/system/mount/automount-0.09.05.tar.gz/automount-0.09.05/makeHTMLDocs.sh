#!/bin/sh
#
# Create HTML Documentation from the TeX Files.
#
latex2html automount.tex

# Generate temporary filename if possible:
if [ -x /usr/bin/mktemp ]; then
  TMPFILE=`mktemp /tmp/automount-HTML-Patch-XXXXXX`
else
  TMPFILE=/tmp/automount-HTML-Patch-`date +"%d%m%y"`$$
fi

# Remember current directory:
CWD=`pwd`
# Patch the generated files so that the remote references are removed:
cd automount
for name in *.html; do
  echo "Patching $name..."
  cat $name |sed 's:SRC="[^"]*/\([^/][^/]*\)":SRC="\1":g' >$TMPFILE
  mv $TMPFILE $name
done

echo "Done."
# Change to previous directory:
cd $CWD

