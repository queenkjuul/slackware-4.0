/* s_pipe.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#include "main.h"

/*****************************************************************************/
/* provide full duplex pipes */
/* adapted from R.W. Stevens, Advanced Programming in the */
/* Unix Environment, Page 478f. */
#ifdef SVR4
int s_pipe(int fd[2])
{
    return(pipe(fd));
}

#else
int s_pipe(int fd[2])
{
    return(socketpair(AF_UNIX, SOCK_STREAM, 0, fd));
}

#endif /* SVR4 */


/***** end of s_pipe.c *****/
