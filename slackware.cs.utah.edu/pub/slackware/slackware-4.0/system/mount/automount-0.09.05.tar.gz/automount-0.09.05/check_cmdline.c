/* check_cmdline.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#include "main.h"

/*****************************************************************************/
/* ARGSUSED0 */
FLAG check_cmdline(int argc, char **argv, int *intervall)
{
/*   extern char *optarg;
   extern int optind, opterr, optopt;
*/
   /* disable getopt() error msg */
/*   opterr = 0; */
   /* by now only the -i option is supported */
   /* parse commandline */
/*   while(getopt(argc, argv, "i:") != EOF)
   {
      
   } */

   return(OK);
}

/* end of check_cmdline.c */
