/* process_options.h */
/* Header for automount application */

/* Written and (C) Copyright Wolfram Saringer 1995/98  */
/* Documentation is available in the file $$$.dvi      */

#ifndef PROCESS_OPTIONS_H
#define PROCESS_OPTIONS_H

/* NOTE: some default values are set in consts.h */
/*****************************************************************************/
/* preprocess options */

/* linux is primary platform: */
#ifdef LINUX
#ifdef SOLARIS2
#undef SOLARIS2
#endif /* SOLARIS2 */
/* linux is not considered system V compliant */
#ifdef SYSV
#undef SYSV
#endif /* SYSV */
#ifdef SVR4
#undef SVR4
#endif /* SVR4 */
#endif /* LINUX */


#ifdef SOLARIS2
#ifndef SVR4
#define SVR4
#endif /* SVR4 */
#endif /* SOLARIS2 */

/* make SYSV an alias for SVR4 */
#ifdef SYSV
#ifndef SVR4
#define SVR4
#endif /* SVR4 */
#endif /* SYSV */

/* system specific include files and definitions */
#ifdef SOLARIS2
#include <sys/cdio.h>
#define index(string, character) strchr(string, character)
#define rindex(string, character) strrchr(string, character)
#endif /* SOLARIS2 */

#ifdef LINUX
#include <linux/unistd.h>
#include <linux/config.h>
#include <linux/cdrom.h>
#include <linux/fs.h>
#ifdef CONFIG_IFS_FS
#include <linux/ifs_fs.h>
#endif /* CONFIG_IFS_FS */
#ifndef DONT_USE_SELECT
#include <sys/time.h>
#endif /* DONT_USE_SELECT */
#include <linux/mm.h>
#endif /* LINUX */

/* currently USE_EXTENDED_SIGARGS is only supported on System V */
#ifndef SVR4
#ifdef USE_EXTENDED_SIGARGS
#undef USE_EXTENDED_SIGARGS
#endif /* USE_EXTENDED_SIGARGS */
#endif /* SVR4 */

/* make sure that SA_SIGINFO is valid */
#ifdef USE_EXTENDED_SIGARGS
#ifndef SA_SIGINFO
#undef USE_EXTENDED_SIGARGS
#endif /* SA_SIGINFO */
#endif /* USE_EXTENDED_SIGARGS */

#ifdef USE_EXTENDED_SIGARGS
#include <siginfo.h>
#endif /* USE_EXTENDED_SIGARGS */

#ifdef USE_SYSLOGD
#include <syslog.h>
#endif /* USE_SYSLOGD */

/* MONITOR_MOUNT_COUNT is impossible without select() */
#ifdef MONITOR_MOUNT_COUNT
#ifdef DONT_USE_SELECT
#undef MONITOR_MOUNT_COUNT
#endif /* DONT_USE_SELECT */
#endif /* MONITOR_MOUNT_COUNT */

/* Set default for SKIP_ROUNDS */
#ifndef SKIP_ROUNDS
#define SKIP_ROUNDS 2
#endif /* SKIP_ROUNDS */

#endif /* PROCESS_OPTIONS_H */
/* end of process_options.h */
