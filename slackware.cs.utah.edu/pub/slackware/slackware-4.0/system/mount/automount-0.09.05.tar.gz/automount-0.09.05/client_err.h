/* client_err.h */
/* error messages used for answering client requests */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#ifndef CLIENT_ERR_H
#define CLIENT_ERR_H

/*****************************************************************************/
#define UNMOUNT_OK          ((char *)NULL)
#define DEVICE_BUSY         "Device is busy"
#define DEVICE_NOT_MOUNTED  "Device not currently mounted"
#define NAME_UNKNOWN        "Device name unknown"
#define DEVICE_ERROR        "Error unmounting Device"
#define DEVICE_UNUSABLE     "Device marked unusable in Server"

#endif /* CLIENT_ERR_H */
