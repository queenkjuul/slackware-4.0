/* mount_std.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995/98  */
/* Documentation is available in the file $$$.dvi   */

#include "main.h"

/*****************************************************************************/
void mount_device(struct mount_entry *device)
{
    char buffer[1];

    /* use standard function call for mounting */
    /* no subprocess => lower memory and CPU load */

    /* Try to read from device. */
    /* If this fails, the device is not ready. */
#ifdef DEBUG
    printf("Trying to read from %s...", device->device);
#endif /* DEBUG */
    if(read(device->fd, &buffer, sizeof(buffer)) != sizeof(buffer))
    {
#ifdef DEBUG
        (void) printf(" ERROR: %s\n", strerror(errno));
#endif /* DEBUG */
        return;
    }

#ifdef DEBUG
    printf(" OK.\n");
#endif /* DEBUG */
    /* try to mount the device */
#ifdef DEBUG
    (void) printf("Trying to mount -%s- on -%s-\nwith filesystem -%s- under name -%s-\n", device->device, device->mount_point, device->filesystem, device->name);
#endif
#ifdef LINUX
    if(mount(device->device, device->mount_point, device->filesystem, (unsigned long) 1, opt_nostd) != -1)

#else

        /* mount() is different on Solaris */
        /* set flags for read only access */
        if(mount(device->device, device->mount_point, MS_DATA | 1, device->filesystem, (char *)0, 0) == 0)
#endif /* LINUX */
        {
            /* mount OK */
            /* mount successful */
#ifdef DEBUG
            (void) printf("automountd: mount succeeded\n");
#endif
            device->mounted = YES;
#ifdef MONITOR_MOUNT_COUNT
            already_mounted++;
#endif /* MONITOR_MOUNT_COUNT */
        }
        else
        {
            /* an error occurred */
            /* test for fatal errors */
            switch(errno)
            {
               case EFAULT:
                   /* values should be non null =>  */
                   /* if values provided are wrong: */
                   PANIC("Internal Error (Bad mount() values)");
                   /* NOTREACHED */
                   break;
	       
	       case EIO:
		   /* FALLTHRU */
		   /* I/O Error: No CD inserted or simmilar */
               case EBUSY:
                   /* FALLTHRU */
               case EAGAIN:
                   /* dir busy or device already mounted */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: EBUSY/EAGAIN\n");
#endif
                   /* ignore this error and continue */
                   break;

               case EINVAL:
                   /* magic nr in superblock or filesystem invalid */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: EINVAL\n");
#endif
                   /* ignore this error, try again later */
                   break;

                   /* now come the errors that make an entry unusable */
               case ENAMETOOLONG:
                   /* name of path exceeds limit */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: ENAMETOOLONG\n");
#endif
                   /* FALLTHRU */

               case ENOENT:
                   /* none of the named files exists */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: ENOENT\n");
#endif
                   /* FALLTHRU */

               case ENOTBLK:
                   /* not a blockdevice */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: ENOTBLK\n");
#endif
                   /* FALLTHRU */

               case ENOTDIR:
                   /* not a directory */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: ENOTDIR\n");
#endif
                   /* FALLTHRU */

               case EREMOTE:
                   /* remote and cannot be mounted */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: EREMOTE\n");
#endif
                   /* FALLTHRU */

               case ENOLINK:
                   /* link to remote machine no longer exists */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: ENOLINK\n");
#endif
                   /* FALLTHRU */

               case ENXIO:
                   /* dev does not exist */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: ENXIO\n");
#endif
                   /* The ZIP Drive returns this error if no disk is present. */
                   /* ignore this error, try again later */
                   break;

               case ENOSPC:
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: EENOSPC\n");
#endif
                   /* FALLTHRU */

               case ENODEV:
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: ENODEV\n");
#endif
                   /* FALLTHRU */

                   /********************************************************/
                   /* this is the common handling for all preceding errors */
                   /* mark entry as unusable */
#ifdef DEBUG
                   (void) printf("automountd: main_loop.c, debug info: Marking entry as unusable\n");
#endif
                   device->mounted = ERROR;
#ifdef MONITOR_MOUNT_COUNT
                   /* unusable is as good as mounted: this entry will */
                   /* not be used again until reset */
                   already_mounted++;
#endif /* MONITOR_MOUNT_COUNT */
                   break;

               case EPERM:
                   /* eff UID is not root => fatal */
                   PANIC("effective UID is not root");
                   break;

               default:
#ifdef DEBUG
                   (void) fprintf(stderr, "errno %d/%x\n", errno, errno);
                   (void) fprintf(stderr, "   %s\n", strerror(errno));
#else
                   LOG_MSG(strerror(errno));
#endif
                   PANIC("Unknown error (bad errno)");
                   break;
            }
        }
    return;
}
      

/***** end of mount.c *****/
