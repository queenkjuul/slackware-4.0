/* consts.h */
/* Header for automount application */

/* Written and (C) Copyright Wolfram Saringer 1995/98  */
/* Documentation is available in the file $$$.dvi      */

#ifndef CONSTS_H
#define CONSTS_H

/*****************************************************************************/
#define ERROR         (-1)
#define OK              1
#define YES            OK
#define NO              0
#define EJECTED         2   /* ret val for check_fifo() */
#define BUSY            3   /* used by unmount() */

/* make default intervall 5 seconds */
#ifndef DEFAULT_INTERVALL
#define DEFAULT_INTERVALL 5
#endif /* DEFAULT_INTERVALL */

/* reject interval less than 2 */
#if (DEFAULT_INTERVALL < 2)
#undef DEFAULT_INTERVALL
#define DEFAULT_INTERVALL 5
#endif

/* initialization file */
#ifndef DEFAULT_INIT_FILE
#define DEFAULT_INIT_FILE "/etc/automountd.conf"
#endif /* DEFAULT_INIT_FILE */

/* fifo */
#ifndef FIFO_NAME
#define FIFO_NAME         "/tmp/automountd.fifo"
#endif /* FIFO_NAME */
#ifndef DONT_USE_SELECT
#ifndef REPLY_FIFO_NAME
#define REPLY_FIFO_NAME   "/tmp/automountd.reply"
#endif /* REPLY_FIFO_NAME */
#endif /* DONT_USE_SELECT */



/* default table size, can be set to nr of lines in config file */
/* if this is known in advance. Otherwise just leave it untouched */
/* this value is just used as a first guess */
#ifndef DEFAULT_TABLE_SIZE
#define DEFAULT_TABLE_SIZE 5
#endif /* DEFAULT_TABLE_SIZE */

/* The following values specify the keywords for the */
/* configuration file per-device options */
#ifndef POLLFLAG
#define POLLFLAG "NOPOLL"
#endif /* POLLFLAG */

#ifndef ROFLAG
#define ROFLAG "RO"
#endif /* ROFLAG */

#ifndef EJECTFLAG
#define EJECTFLAG "NOEJECT"
#endif /* EJECTFLAG */


#ifndef CHECKREQUEST
#define CHECKREQUEST "CHECKREQUEST"
#endif /* CHECKREQUEST */
#define CHECK YES 

#ifndef SKIPROUNDFLAG
#define SKIPROUNDFLAG "SKIPROUND"
#endif /* SKIPROUNDFLAG */

#ifndef END_OF_STR
#define END_OF_STR '\0'
#endif
#ifndef NEWLINE
#define NEWLINE '\n'
#endif

#define COMMENT_CHAR '#'

#define BUFFERSIZE 256


#endif /* CONSTS_H */
/* end of consts.h */
