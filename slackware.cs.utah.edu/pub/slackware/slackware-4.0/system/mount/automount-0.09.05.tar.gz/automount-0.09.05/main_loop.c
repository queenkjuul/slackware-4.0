/* main_loop.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995/98  */
/* Documentation is available in the file $$$.dvi      */

#include "main.h"

/*****************************************************************************/
void main_loop(int interval)
{
    /* this function goes to sleep for 'intervall' seconds */
    /* afterwards it checks the various flags if there is */
    /* some work to do. Then all volumes in mount_table are */
    /* checked if media is present (i.e. ready for being mounted) */

    int i;
    struct mount_entry *tmp;
#ifndef DONT_USE_SELECT
#ifdef DEBUG
    time_t waittime;
#endif /* DEBUG */
    fd_set readset;
    int fifo_ready;
    struct timeval interval_struct;

    /* set up timeout */
    /* this is the normal sleep period, with the difference, that */
    /* client requests are served immediately */
    interval_struct.tv_sec = interval;
    interval_struct.tv_usec = 0;

    /* set up readset for select () */
    FD_ZERO(&readset);
    FD_SET(fifo_fd, &readset);
#endif /* DONT_USE_SELECT */
#ifdef DEBUG
    printf("interval = %d, fifo fd = %d\n", interval, fifo_fd);
#endif /* DEBUG */
    
    /* CONSTCOND */
    while(1)
    {
#ifdef DEBUG
        (void) printf("/*****************************************************************************/\n");
#endif

#ifdef DONT_USE_SELECT
        (void) sleep(interval);
#else
#ifdef DEBUG
        /* check how long select blocks */
        waittime = time(NULL);
#endif /* DEBUG */
#ifdef LINUX
        /* linux seems to be 'different'... */
        /* resets values in struct timeval */
        interval_struct.tv_sec = interval;
        interval_struct.tv_usec = 0;
#endif /* LINUX */
        /* linux also resets the fd's to check (Hail thee, BSD...) */
        /* Solaris doesn't, but lets make sure... */
        FD_ZERO(&readset);
        FD_SET(fifo_fd, &readset);

#ifdef MONITOR_MOUNT_COUNT
        if( mount_table_size <= already_mounted)
        {
            /* when no more unmounted devices are avaliable */
            /* we go to sleep until we receive a signal or */
            /* a request from the eject client */
#ifdef DEBUG
            (void) printf("Waiting for signal or client request (no timeout)\n");
#endif /* DEBUG */
            fifo_ready = select(fifo_fd + 1, &readset, NULL, NULL, NULL);
        }
        else
        {
#endif /* MONITOR_MOUNT_COUNT */
            /* sleep for 'interval' seconds, but interupt sleep */
            /* when data is ready to be read from the fifo */
            fifo_ready = select(fifo_fd + 1, &readset, NULL, NULL,
                                &interval_struct);
#ifdef MONITOR_MOUNT_COUNT
        }
#endif /* MONITOR_MOUNT_COUNT */
        
#ifdef DEBUG
        waittime = time(NULL) - waittime;
        printf("select() blocked for %d secs\n", (int)waittime);
        printf("select() returned %d, errno = %d\n", fifo_ready, errno);
#endif /* DEBUG */
        /* try to catch possible error returns from select */
        /* EINTR is returned when a signal is received */
        /* this case is non fatal */
        if(fifo_ready == -1)
            if(errno != EINTR)
                PANIC("select() error");
#endif /* DONT_USE_SELECT */
#ifdef DEBUG
        /* reset errno to beautify output */
        errno = 0;
#endif /* DEBUG */
        /* now check flags */
        if(rereadinit_flag == YES)
        {
            /* sighup received => read init file */
            rereadinit_flag = NO;
#ifdef DEBUG
            (void) printf("automountd: SIGHUP received: rereading init file\n");
#else
            LOG_MSG("rereading init file");
#endif
            /* Re-read init file. This will discard old mount table: */
            if(read_initfile() == ERROR)
            {
                PANIC("Init file error");
                /* NOTREACHED */
            }
#ifdef DEBUG
#ifdef MONITOR_MOUNT_COUNT
            (void) printf("Mount Count = %d\n", already_mounted);
#endif /* MONITOR_MOUNT_COUNT */
#endif /* DEBUG */
        }

#ifndef DONT_USE_SELECT
        /* we are only interested in one fd. */
        /* therefore if one is ready, it must be the fifo */
        /* => no check for actually returned status of readset */
        if(fifo_ready == 1)
        {
#endif /* DONT_USE_SELECT */
            if(check_fifo(fifo_fd) == EJECTED)
            {
#ifdef DEBUG
#ifdef MONITOR_MOUNT_COUNT
                (void) printf("Mount Count = %d\n", already_mounted);
#endif /* MONITOR_MOUNT_COUNT */
#endif /* DEBUG */
                /* volume ejected: */
                /* for safety skip to next sleep() */
                continue;
            }
#ifdef DEBUG
#ifdef MONITOR_MOUNT_COUNT
            (void) printf("Mount Count = %d\n", already_mounted);
#endif /* MONITOR_MOUNT_COUNT */
#endif /* DEBUG */
#ifndef DONT_USE_SELECT
        }
#endif /* DONT_USE_SELECT */
        
        /* now go through mount table */
        for(i = 0; i < mount_table_size; i++)
        {
            /* read one entry and try to mount the device */
            tmp = mount_table[i];
#ifdef DEBUG
            (void) printf("automountd: main_loop.c tmp = %lx\n", (unsigned long)tmp);
#endif
            /* check for poll flag and check request */
            if((IS_NSET(tmp->opt, NOPOLL) == NO) &&
               (checkrequest_flag != CHECK))
            {
                /* goto next entry */
                continue;
            }

            /* test if entry is usable and not mounted */
            if((tmp->mounted == NO) && (tmp->skip_round == 0))
            {
                /* possible values are:
                   NO:    ready for mounting
                   YES:   already mounted;
                   ERROR: An unrecoverable error occurred on a previous
                   attempt => do not try again.
                   this can be reset only by a reread of the init file
                   (maybe through a SIGHUP) */
                mount_device(tmp);
            }
            else
            {
                if(tmp->skip_round > 0)
                {
                    /* Decrease skip_round */
                    tmp->skip_round--;
#ifdef DEBUG
                    (void) printf("automountd: main_loop.c: Skipped entry %s: Skip rounds = %d\n", tmp->device, tmp->skip_round);
#endif /* DEBUG */
                }
#ifdef DEBUG
                if(tmp->mounted == ERROR)
                {
                    (void) printf("automountd: main_loop.c: unusable entry found\n");
                    (void) printf("\t device -%s- on -%s-\n", tmp->device, tmp->mount_point);
                }
#endif /* DEBUG */
            }
        }
        /* reset checkrequest flag: */
        checkrequest_flag = NO;
    }
    /* daemon can only exit via a signal handler */
    /* NOTREACHED */
}

/* end of main_loop.c */
