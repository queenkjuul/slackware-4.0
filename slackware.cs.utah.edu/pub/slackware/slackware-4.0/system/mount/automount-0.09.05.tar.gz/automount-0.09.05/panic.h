/* panic.h */
/* Header for automount application */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#ifndef PANIC_H
#define PANIC_H

/*****************************************************************************/
void panic(char *file, int line, char *reason);
#define PANIC(_reason_) panic(__FILE__, __LINE__, _reason_)


#endif /* PANIC_H */
/* end of panic.h */
