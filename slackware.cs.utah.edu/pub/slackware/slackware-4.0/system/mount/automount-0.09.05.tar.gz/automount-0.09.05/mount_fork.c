/* mount_fork.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#include "main.h"

/*****************************************************************************/
void mount_device(struct mount_entry *device)
{
    pid_t mounterproc;
    int childret;
    int childstatus;

    /* create child that mounts the device */
    /* this is done so that in case of a abnormal termination */
    /* of the server, the lock of the device is already removed */
    /* as the mounting process already exited normally */
    if((mounterproc = fork()) == -1)
    {
        char err_string[256];
        strncpy(err_string, "Fatal Server Error: fork() failed, errno: ", sizeof(err_string));
        strncat(err_string, strerror(errno), sizeof(err_string) - strlen(err_string));
        PANIC(err_string);
        /* NOTREACHED */
        return;
    }

    if(mounterproc == 0)
    {
        /* this is the child */
        /* try to mount the device and exit with appropriate status */
#ifdef DEBUG
        (void) printf("Trying to mount -%s- on -%s-\nwith filesystem -%s- under name -%s-\n", device->device, device->mount_point, device->filesystem, device->name);
#endif
#ifdef LINUX
        if(mount(device->device, device->mount_point, device->filesystem, (unsigned long) 1, opt_nostd) != -1)

#else

            /* mount() is different on Solaris */
            /* set flags for read only access */
            if(mount(device->device, device->mount_point, MS_DATA | 1, device->filesystem, (char *)0, 0) == 0)
#endif
            {
                /* mount OK, child exits now */
                exit(0);
            }
            else
            {
                /* error while mounting device */
                /* use errno as exit code */
                exit(errno);
            }
    }
    else
    {
        /* this is the parent */
        /* wait for child termination */
        waitpid(mounterproc, &childret, 0);
        /* examine exit status */
        if(WIFEXITED(childret) > 0)
        {
            if((childstatus = WEXITSTATUS(childret)) == 0)
            {
                /* mount successful */
#ifdef DEBUG
                (void) printf("automountd: mount succeeded\n");
#endif
                device->mounted = YES;
#ifdef MONITOR_MOUNT_COUNT
                /* correct mount count */
                already_mounted++;
#endif /* MONITOR_MOUNT_COUNT */
            }
            else
            {
                /* an error occurred */
                /* test for fatal errors */
                switch(childstatus)
                {
                   case EFAULT:
                       /* values should be non null =>  */
                       /* if values provided are wrong: */
                       PANIC("Internal Error (Bad mount() values)");
                       /* NOTREACHED */
                       break;

                   case EBUSY:
                       /* FALLTHRU */
                   case EAGAIN:
                       /* dir busy or device already mounted */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: EBUSY/EAGAIN\n");
#endif
                       /* ignore this error and continue */
                       break;

                   case EINVAL:
                       /* magic nr in superblock or filesystem invalid */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: EINVAL\n");
#endif
                       /* ignore this error, try again later */
                       break;

                       /* now come the errors that make an entry unusable */
                   case ENAMETOOLONG:
                       /* name of path exceeds limit */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: ENAMETOOLONG\n");
#endif
                       /* FALLTHRU */

                   case ENOENT:
                       /* none of the named files exists */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: ENOENT\n");
#endif
                       /* FALLTHRU */

                   case ENOTBLK:
                       /* not a blockdevice */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: ENOTBLK\n");
#endif
                       /* FALLTHRU */

                   case ENOTDIR:
                       /* not a directory */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: ENOTDIR\n");
#endif
                       /* FALLTHRU */

                   case EREMOTE:
                       /* remote and cannot be mounted */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: EREMOTE\n");
#endif
                       /* FALLTHRU */

                   case ENOLINK:
                       /* link to remote machine no longer exists */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: ENOLINK\n");
#endif
                       /* FALLTHRU */

                   case ENXIO:
                       /* dev does not exist */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: ENXIO\n");
#endif
                       /* FALLTHRU */

                   case ENOSPC:
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: EENOSPC\n");
#endif
                       /* FALLTHRU */

                   case ENODEV:
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: ENODEV\n");
#endif
                       /* FALLTHRU */

                       /*******************************************************/
                       /* this is the common handling for all receding errors */
                       /* mark entry as unusable */
#ifdef DEBUG
                       (void) printf("automountd: main_loop.c, debug info: Marking entry as unusable\n");
#endif
                       device->mounted = ERROR;
#ifdef MONITOR_MOUNT_COUNT
                       /* unusable is as good as mounted: this entry will */
                       /* not be used again until reset */
                       already_mounted++;
#endif /* MONITOR_MOUNT_COUNT */
                       break;

                   case EPERM:
                       /* eff UID is not root => fatal */
                       PANIC("effective UID is not root");
                       break;

                   default:
#ifdef DEBUG
                       (void) fprintf(stderr, "errno %d/%x\n", childstatus, childstatus);
                       (void) fprintf(stderr, "   %s\n", strerror(childstatus));
#else
                       LOG_MSG(strerror(childstatus));
#endif
                       PANIC("Unknown error (bad child status)");
                       break;
                }
            }
        }
    }
    return;
}
      
	/***** end of mount.c *****/
