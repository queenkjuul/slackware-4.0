/* log_msg.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */


#include "main.h"

#ifndef USE_SYSLOGD
/*****************************************************************************/
void log_msg(char *msg1, char *msg2, char *file, int line)
{
   FILE *logfile;
   time_t curr_time;

   if((logfile = fopen(STD_LOG_FILE, "a")) == NULL)
      return;

   /* else write message to log file */
   /* print header */
   (void) fprintf(logfile, "/*****************************************************************************/\n");
   (void) fprintf(logfile, "Message logging requested in file %s, line %d\n", file, line);

   /* print date & time */
   (void) time(&curr_time);
   (void) fprintf(logfile, "%s\n", ctime(&curr_time));

   /* print message */
   (void) fprintf(logfile, "   %s\n", msg1);
   if(msg2 != (char *)NULL)
      (void) fprintf(logfile, "   %s\n", msg2);

   /* end message section */
   (void) fprintf(logfile, "\n\n");

   /* close log file */
   (void) fflush(logfile);
   (void) fclose(logfile);

   return;
}


/*****************************************************************************/
#else
/* use the syslogd facility */
void log_msg(char *msg1, char *msg2, char *file, int line)
{
   /* provide standard level: LOG_ERR */
   syslog(LOG_ERR, "%s, %d: %s: %s", file, line, msg1, (msg2 ? msg2 : ""));

   return;
}

#endif /* USE_SYSLOGD */


/* end of log_msg.c */
