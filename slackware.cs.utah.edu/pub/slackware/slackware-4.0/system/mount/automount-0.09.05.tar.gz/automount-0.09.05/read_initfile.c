/* read_initfile.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995/97/98 */
/* Documentation is available in the file $$$.dvi        */

#include "main.h"

/*****************************************************************************/
static MOUNT_ENTRY *str2mentry(char *buffer)
{
    struct mount_entry *new = NULL;
    char *debuginfo = malloc(strlen(buffer) + sizeof(END_OF_STR));
    char *comment_start;
    char *i;
    char *tmp;
    
    /* check for comment char in the line */
    /* if one is present, end line there */
    if((comment_start = index(buffer, COMMENT_CHAR)) != (char *)NULL)
    {
        /* terminate line at comment char */
        *comment_start = END_OF_STR;

        /* check wether any non-white-space chars */
        /* are before the comment char. If not, */
        /* the line is a comment as a whole */
        for(i = comment_start - 1; i > buffer; i--)
        {
            if(isspace(*i))
            {
                /* eliminate every whitespace directly before comment char */
                *i = END_OF_STR;
            }
            else
            {
                break;
            }
        }
        if(i <= buffer)
        {
            /* only whitespace before comment char => ignore line */
#ifdef DEBUG
            printf("automountd: is a comment line.\n");
/*             printf("\t-%s-\n", buffer); */
#endif
            return((struct mount_entry *)NULL);
        }
#ifdef DEBUG
        printf("truncated line (removed comment): -%s-\n", buffer);
#endif
    }

    if(debuginfo != (char *)NULL)
    {
        /* copy string for eventual error msgs */
        /* it should be save to use strcpy() as the size is */
        /* calculated just above */
        (void) strcpy(debuginfo, buffer);
    }

    /* get memory for struct to set up */
    if((new = (struct mount_entry *)malloc(sizeof(struct mount_entry)))
       == (struct mount_entry *)NULL)
    {
        PANIC("malloc failed");
    }

    /* save location of input string */
    new->buffer = buffer;

    /* now parse the string for the first non-white-space char */
    while((*buffer != END_OF_STR) && isspace((int)*buffer))
        buffer++;
    if(*buffer == END_OF_STR)
    {
#ifdef DEBUG
        printf("automountd: unexpected EOL in string -%s- at %lx\n", debuginfo, (unsigned long)buffer);
#else
        LOG_2MSG("Unexpected EOL in string:", debuginfo);
#endif
        free(new);
        free(debuginfo);
        return((struct mount_entry *)NULL);
    }

    /* here starts the device name */
    new->device = buffer;

    /* Init struct member to the default value: */
    new->skip_round = 0;
    
    /* advance past end of device name */
    while((*buffer != END_OF_STR) && !isspace((int)*buffer))
        buffer++;
    if(*buffer == END_OF_STR)
    {
#ifdef DEBUG
        (void) printf("automountd: unexpected EOL in string -%s- at %lx\n", debuginfo, (unsigned long)buffer);
#else
        LOG_2MSG("Unexpected EOL in string:", debuginfo);
#endif
        free(new);
        free(debuginfo);
        return((struct mount_entry *)NULL);
    }
    /* end string */
    *buffer++ = END_OF_STR;

    /* search for next word */
    while((*buffer != END_OF_STR) && isspace((int)*buffer))
        buffer++;
    if(*buffer == END_OF_STR)
    {
#ifdef DEBUG
        (void) printf("automountd: unexpected EOL in string -%s- at %lx\n", debuginfo, (unsigned long)buffer);
#else
        LOG_2MSG("Unexpected EOL in string:", debuginfo);
#endif
        free(new);
        free(debuginfo);
        return((struct mount_entry *)NULL);
    }
    /* this is the mountpoint */
    new->mount_point = buffer;

    /* advance past end of mount point */
    while((*buffer != END_OF_STR) && !isspace((int)*buffer))
        buffer++;
    if(*buffer == END_OF_STR)
    {
#ifdef DEBUG
        (void) printf("automountd: unexpected EOL in string -%s- at %lx\n", debuginfo, (unsigned long)buffer);
#else
        LOG_2MSG("Unexpected EOL in string:", debuginfo);
#endif
        free(new);
        free(debuginfo);
        return((struct mount_entry *)NULL);
    }
    /* end string */
    *buffer++ = END_OF_STR;

    /* search for next word */
    while((*buffer != END_OF_STR) && isspace((int)*buffer))
        buffer++;
    if(*buffer == END_OF_STR)
    {
#ifdef DEBUG
        (void) printf("automountd: unexpected EOL in string -%s- at %lx\n", debuginfo, (unsigned long)buffer);
#else
        LOG_2MSG("Unexpected EOL in string:", debuginfo);
#endif
        free(new);
        free(debuginfo);
        return((struct mount_entry *)NULL);
    }
    /* here comes the filesystem */
    new->filesystem = buffer;

    /* go past filesystemname */
    while((!isspace((int)*buffer)) && (*buffer != END_OF_STR))
        buffer++;
    if(*buffer == END_OF_STR)
    {
#ifdef DEBUG
        (void) printf("automountd: unexpected EOL in string -%s- at %lx\n", debuginfo, (unsigned long)buffer);
#else
        LOG_2MSG("Unexpected EOL in string:", debuginfo);
#endif
        free(new);
        free(debuginfo);
        return((struct mount_entry *)NULL);
    }
    /* end string */
    *buffer++ = END_OF_STR;

    /* search for next word */
    while((*buffer != END_OF_STR) && isspace((int)*buffer))
        buffer++;
    if(*buffer == END_OF_STR)
    {
#ifdef DEBUG
        (void) printf("automountd: unexpected EOL in string -%s- at %lx\n", debuginfo, (unsigned long)buffer);
#else
        LOG_2MSG("Unexpected EOL in string:", debuginfo);
#endif
        free(new);
        free(debuginfo);
        return((struct mount_entry *)NULL);
    }

    /* this is the name */
    new->name = buffer;

    /* ignore rest of line */
    /* advance past end of name */
    while((!isspace((int)*buffer)) && (*buffer != END_OF_STR))
        buffer++;
    /* end string */
    *buffer = END_OF_STR;
    buffer++;
        
    /* rest of line contains options */
    /* Initialize opt member */
    new->opt = 0;
    /* search for next word */
    while((*buffer != END_OF_STR) && isspace((int)*buffer))
        buffer++;
    if(*buffer != END_OF_STR)
    {
        /* advance past end of flags and convert to upper case */
        tmp = buffer;
/*        while((!isspace((int)*buffer)) && (*buffer != END_OF_STR)) */
        while(*buffer != END_OF_STR)
        {
            *buffer = (char) toupper((int)*buffer);
            buffer++;
        }
        /* end string */
        *buffer = END_OF_STR;

#ifdef DEBUG
            (void) printf("Options: ");
#endif /* DEBUG */

        /* check wether this is 'NOPOLL' */
        if(strstr(tmp, POLLFLAG) != NULL)
        {
            new->opt |= NOPOLL;
#ifdef DEBUG
            (void)printf("NOPOLL ");
#endif /* DEBUG */
        }
        /* else */
            /* don't set NOPOLL flag */

        /* Check for NOEJECT */
        if(strstr(tmp, EJECTFLAG) != NULL)
        {
            new->opt |= NOEJECT;
#ifdef DEBUG
            printf("NOEJECT ");
#endif /* DEBUG */
        }

        /* Check for Readonly flag */
        if(strstr(tmp, ROFLAG) != NULL)
        {
            new->opt |= READONLY;
#ifdef DEBUG
            printf("READONLY ");
#endif /* DEBUG */
        }
#ifdef DEBUG
        printf("\n");
#endif /* DEBUG */

        if(strstr(tmp, SKIPROUNDFLAG) != NULL)
        {
            new->opt |= SKIPROUND;
            /* Init struct member to the default value: */
            new->skip_round = SKIP_ROUNDS;
#ifdef DEBUG
            (void)printf("SKIPROUND ");
#endif /* DEBUG */
        }

        /* Try to open the device: */
        new->fd = open(new->device, O_RDONLY | O_NONBLOCK);
        /* See if open was sucessful: */
        if(new->fd == -1)
        {
#ifdef DEBUG
            (void) printf("Cannot access -%s-, entry ignored.\n", new->device);
#endif /* DEBUG */
            free(new);
            free(debuginfo);
            return((struct mount_entry *)NULL);
        }

    }


    /* ignore rest of line */

    /* init rest of struct mount_entry */
    /* set flag to indicate 'not currently mounted' */
    new->mounted = NO;

    free(debuginfo);
    return(new);
}

/*****************************************************************************/
FLAG read_initfile(void)
{
    int table_size = mount_table_size;
    struct mount_entry **tmptable;
    int entries;
    FILE *config_file;
    char *tmp;
    struct mount_entry *new;

    if(mount_table != NULL)
    {
        /* first we will unmount all devices */
        /* as we might loose control over mounted devices */
        unmount_all(NO);
       
        /* now it is save to destroy the old table */
        /* table_size = total amount of space in table */
        /* => decrement BEFORE using as index */
        while(--table_size)
        {
            /* free individual entry */
            /* first the strings read from file */
            free(mount_table[table_size]->buffer);
            /* now the struct itself */
            free(mount_table[table_size]);
        }
        /* free last entry */
        free(mount_table[0]->buffer);
        free(mount_table[0]);
        /* free table */
        free(mount_table);
    }

    /* now a new table can be set up */
    /* first set default table length */
    table_size = DEFAULT_TABLE_SIZE;
    /* malloc initial table */
    if((mount_table = calloc(table_size, sizeof(struct mount_entry *)))
       == NULL)
    {
        PANIC("calloc() failed");
    }

    /* open config file */
    if((config_file = fopen(DEFAULT_INIT_FILE, "r")) == NULL)
    {
        PANIC("Config file " DEFAULT_INIT_FILE " not found");
    }

    /* entries made so far */
    entries = 0;

    /* loop while there are lines to process */
    while((tmp = get_line(config_file, ftell(config_file))) != (char *)NULL)
    {
        if(tmp == (char *)ERROR)
            PANIC("(Internal Error)");

        /* test if line is comment line (starts with COMMENT_CHAR) */
        /* if so, continue with next line */
        if(*tmp == COMMENT_CHAR)
        {
            free(tmp);
            continue;
        }
        /* if line is empty, skip to next line */
        if((*tmp == NEWLINE) || (*tmp == END_OF_STR))
        {
            free(tmp);
            continue;
        }

        /* extract pointers from string */
#ifdef DEBUG
        printf("Init file: -%s-\n", tmp);
#endif
        if((new = str2mentry(tmp)) == (struct mount_entry *)NULL)
        {
#ifdef DEBUG
            (void) printf("automountd: Init file line ignored\n");
#endif
            /* ignore line */
            free(tmp);
            continue;
        }

        /* if OK, make entry in table */
        /* first test wether table is big enough to hold another entry */
        if(entries >= table_size)
        {
            /* table is full => resize it */
            /* increase size by adding default size */
            table_size =+ DEFAULT_TABLE_SIZE;
            /* then try to change table size */
            /* use another temp pointer to avoid loosing the table */
            /* in case thee realloc fails */
            if((tmptable = realloc(mount_table, table_size * sizeof(struct mount_entry *))) == NULL)
            {
                PANIC("realloc() failed");
            }
            mount_table = tmptable;
        }
      
#ifdef DEBUG
        (void) printf("trying to enter new in table\n");
#endif
        mount_table[entries] = new;
        entries++;
    }

    /* see if table is too big */
    if(entries < table_size)
    {
        /* if so, adjust size */
        /* if no valid entries were found, free table */
        if(entries == 0)
        {
            free(mount_table);
            mount_table = NULL;
        }
        else
        {
            /* use another temp pointer to avoid loosing the table */
            /* in case thee realloc fails */
            /* this should impossible here, since we are shrinking the table */
            /* but who knows... */
            if((tmptable = realloc(mount_table,
                                   entries * sizeof(struct mount_entry *)))
               == NULL)
            {
                /* realloc failed: issue warning, */
                /* but leave old table address intact */
                LOG_MSG("realloc() failed");
            }
            else
            {
                /* remember new table address */
                mount_table = tmptable;
            }
        }
    }

    /* set new table size */
    mount_table_size = entries;
    /* reset nr of mounted devices */
    already_mounted = 0;
#ifdef DEBUG
    (void) printf("automountd: read_initfile.c: table now contains -%d- entries\n", mount_table_size);
#endif

    return(OK);
}


/* end of read_initfile.c */
