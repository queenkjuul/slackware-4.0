/* panic.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#include "main.h"

/*****************************************************************************/
void panic(char *file, int line, char *reason)
{
   (void) fprintf(stderr, "%s: Panic in file %s. line %d\nReason: %s\n", program_name, file, line, reason);

   /* prepare for message logging */
   log_msg("Panic:", reason, file, line);
   
   /* close fifo: */
   if(fifo_fd > -1)
       (void) close(fifo_fd);
   /* remove it */
   (void) unlink(FIFO_NAME);

   /* exit */
   abort();
   /* NOTREACHED */
}


/* end of panic.c */
