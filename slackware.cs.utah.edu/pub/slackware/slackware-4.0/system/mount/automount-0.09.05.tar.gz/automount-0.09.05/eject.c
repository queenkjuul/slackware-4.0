/* eject.c */
/* eject client */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#ifndef GLOBALVARS_ENABLED
#define GLOBALVARS_ENABLED
#endif

#include "main.h"


/*****************************************************************************/
int main(int argc, char **argv)
{
   int fifo_fd;
   int i;
   char *buffer;
   char *tmp;

   if((buffer = calloc(BUFFERSIZE, sizeof(char))) == NULL)
   {
     (void) fprintf(stderr, "calloc() failed");
     exit(4);
   }

   if((fifo_fd = open(FIFO_NAME, O_WRONLY)) < 0)
   {
      (void) fprintf(stderr, "%s: open fifo failed, server is maybe not active\n", argv[0]);
      exit(2);
   }

   /* if no args given, default is "all" */
   if(argc < 2)
   {
      if(write(fifo_fd, "all", strlen("all")) < 0)
      {
	 (void) fprintf(stderr, "%s: error writing to pipe: %s\n", "all", strerror(errno));
	 exit(5);
      }
      exit(0);
   }

   /* else write each argument (starting at 1) in turn to the fifo */
   for(i = 1; i < argc; i++)
   {
#ifdef DEBUG
      (void) printf("writing -%s- with strlen() = %d to pipe\n", argv[i], strlen(argv[i]));
#endif

      (void) sprintf(buffer, "%s\n", argv[i]);
      /* ensure that no extra chars are in string */
      tmp = buffer;
      while(isalnum(*tmp))
	 tmp++;
      /* if non alphanum char found, end string here */
      if(!isalnum(*tmp))
	 *tmp = END_OF_STR;

      if(write(fifo_fd, buffer, strlen(buffer)) < 0)
      {
	 (void) fprintf(stderr, "%s: error writing to pipe: %s\n", argv[0], strerror(errno));
	 exit(3);
      }
   }

   /* close pipe */
   (void) close(fifo_fd);

   /* exit */
   return(0);
}


/* end of eject.c */
