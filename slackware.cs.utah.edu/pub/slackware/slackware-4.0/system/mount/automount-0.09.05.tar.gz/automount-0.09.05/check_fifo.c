/* check_fifo.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#include "main.h"

/*****************************************************************************/
FLAG open_fifo(volatile int *fifohandle)
{
    int fifo_fd;
    int o_flags = 0;

    /* setup open flags: */
    o_flags =  O_WRONLY | O_CREAT | O_EXCL;
    /* for use with select: blocking, else nonblocking */
#ifdef DONT_USE_SELECT
    o_flags = o_flags | O_NONBLOCK;
#endif
   
    /* this function creates the named pipe used for */
    /* receiving client requests */
    /* first try to open fifo: if it alrady exists, another copy of */
    /* the daemon might already be running => exit with error */
    if((fifo_fd = open(FIFO_NAME, o_flags, S_IRUSR | S_IWUSR)) == -1)
    {
        /* file exists => might be created by another automountd */
        /* PANIC("Server seems to be already running"); */
        fprintf(stderr, "Server seems to be already running");
        exit(1);
    }
    else
    {
        /* remove the created file */
        (void) close(fifo_fd);
        (void) unlink(FIFO_NAME);
    }

    /* create fifo */
    /* file mode is -rw-rw-rw */
    /*   if(mkfifo(FIFO_NAME, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH) < 0) */
    (void) umask(0111);

    /* setup open flags: */
    o_flags =  0 | O_RDWR;
    /* for use with select: blocking, else nonblocking */
#ifdef DONT_USE_SELECT
    o_flags = o_flags | O_NONBLOCK;
#endif
   
    if(mkfifo(FIFO_NAME, 0666) < 0)
    {
        PANIC("Cannot create FIFO, maybe server is already running");
    }

    if((fifo_fd = open(FIFO_NAME, o_flags)) < 0)
    {
        PANIC("Cannot open fifo");
    }

    /* everything seems to be OK */
    *fifohandle = fifo_fd;
    return(OK);
}


/*****************************************************************************/
FLAG check_fifo(int fifo)
{
    char *buffer;
    char *start;
    char *tmp;
    char *resp_str;
    FLAG retval;
    int  count;

#ifdef DEBUG
    (void) printf("automountd: checking fifo\n");
#endif

    /* alloc buffer */
    if((buffer = (char *)malloc(BUFFERSIZE)) == (char *)NULL)
    {
        PANIC("malloc failed");
    }

    /* check fifo for devicename */
    /* normally NO device name will be longer than BUFFERSIZE (=256) */
    /* as specified in the open flags, read() should not block */
    switch(count = read(fifo, buffer, BUFFERSIZE))
    {
       case 0:
           /* this is EOF */
#ifdef DEBUG
           (void) printf("automountd: data read from pipe: EOF\n");
#endif
           free(buffer);
           return(OK);
           /* NOTREACHED */
           /*break;*/

       case -1:
           free(buffer);
#ifdef LINUX
           /* under Linux read() returns -1 with errno=EAGAIN */
           if(errno == EAGAIN)
               return(OK);
#endif

           /* ERROR */
#ifdef DEBUG
           (void) printf("automountd: error reading pipe, errno: %d\n", errno);
#endif
           return(ERROR);
           /* NOTREACHED */
           /*break;*/

       default:
           /* data read from fifo */
#ifdef DEBUG
           (void) printf("automountd: data read from pipe\n");
#endif
           /* goto rest of function for processing */
           break;
    }

    /* process data */
    /* first terminate string ( 'count' is nr of bytes received) */
    if(count >= BUFFERSIZE)
        PANIC("buffersize exceeded");

    buffer[count] = END_OF_STR;
    /* find start of string (skipping whitespace) */
    start = buffer;
    while(isspace(*start) && (*start != END_OF_STR))
        start++;

    /* if no chars found: this is an error */
    if(*start == END_OF_STR)
    {
        free(buffer);
        return(ERROR);
    }

    /* remove NEWLINE */
    if((tmp = rindex(start, (int)NEWLINE)) != NULL)
    {
        *tmp = END_OF_STR;
    }

    /* now find end of string */
    tmp = start;
    while(isalnum(*tmp) && (*tmp != NEWLINE) && (!isspace(*tmp)) && (*tmp != END_OF_STR))
        tmp++;

    /* terminate string */
    tmp = END_OF_STR;

#ifdef DEBUG
    (void) printf("automountd: received device name -%s- via pipe\n", start);
#endif

    /* if device name == all, unmount all devices */
    if(strncmp(start, "all", strlen(start)) == 0)
    {
        retval = unmount_all(YES);
        free(buffer);
        return(retval);
    }

    if(strncmp(start, CHECKREQUEST, strlen(start)) == 0)
    {
        /* set checkrequest_flag */
        checkrequest_flag = CHECK;
        return(OK);
    }
    
    /* call unmounting function */
    resp_str = unmount_device(start);
    /* process return value: send string back to client */
    retval = answer_request(resp_str);
    free(buffer);
    return(retval);
}


/* end of check_fifo.c */
