/* signal_handlers.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#include "main.h"

/*****************************************************************************/
/* ARGSUSED0 */
void sighup_handler(int sig)
{
   /* upon receiving this signal the init file must be reread */
   /* this is indicated by the rereadinit flag */
   rereadinit_flag = YES;
   return;
}


/*****************************************************************************/
/* ARGSUSED0 */
void sigterm_handler(int sig)
{
#ifndef DEBUG
  static char buffer[BUFFERSIZE];
#endif /* DEBUG */

   /* this handles all exit signals */
#ifdef DEBUG
   printf("automountd: signal handler received -%d-, exiting\n", sig);
#endif /* DEBUG */

   /* close fifo: */
   if(fifo_fd > -1)
       (void) close(fifo_fd);
   /* remove it */
   (void) unlink(FIFO_NAME);

   /* unmount all devices mounted by daemon */
#ifdef EJECT_ON_EXIT
#ifdef DEBUG
   printf("automountd: unmounting and ejecting all devices\n");
#endif /* DEBUG */
   (void) unmount_all(YES);
#else
#ifdef DEBUG
   printf("automountd: unmounting all devices\n");
#endif /* DEBUG */
   (void) unmount_all(NO);
#endif /* EJECT_ON_EXIT */

   /* log shutdown */
#ifndef DEBUG
#ifdef SOLARIS2
   LOG_2MSG("automountd shutdown, Signal Nr.:", lltostr((long long)sig, buffer));
#else
   sprintf(&buffer[0], "%2d", sig);
   LOG_2MSG("automountd shutdown, Signal Nr.:", buffer);
#endif /* SOLARIS2 */
#endif /* DEBUG */

   /* exit now */
   exit(0);
   /* NOTREACHED */
}


/*****************************************************************************/
/* ARGSUSED0 */
#ifdef USE_EXTENDED_SIGARGS
void sigsegv_handler(int sig, struct siginfo *info)
#else
void sigsegv_handler(int sig)
#endif /* USE_EXTENDED_SIGARGS */
{
#ifdef USE_EXTENDED_SIGARGS
  static char buffer[BUFFERSIZE];
#endif

   /* close fifo: */
   if(fifo_fd > -1)
       (void) close(fifo_fd);
   /* remove it */
   (void) unlink(FIFO_NAME);

/*#ifndef DEBUG */
   /* just log this failure */
   LOG_MSG("SIGSEGV received, aborting");
#ifdef USE_EXTENDED_SIGARGS
   /* log faulty address */
   if(info)
      LOG_2MSG("Faulty Address: ", lltostr((long long)info->si_addr, buffer));
#endif /* USE_EXTENDED_SIGARGS */
/*#endif */ /* DEBUG */

   /* and abort */
   abort();
}


/* end of signal_handlers.c */
