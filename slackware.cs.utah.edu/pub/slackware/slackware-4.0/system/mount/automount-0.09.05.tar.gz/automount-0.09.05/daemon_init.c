/* daemon_init.c */
/* Automount daemon initialization */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#include "main.h"

/*****************************************************************************/
FLAG daemon_init(void)
{
   pid_t pid;

   if((pid = fork()) < 0)
      return(ERROR);

   if(pid != 0)
      /* the parent exits now */
      exit(0);

   /* make child session leader */
   (void) setsid();

   /* change working dir */
   (void) chdir("/");

   /* clear file creation mask */
   (void) umask(0);

   return(OK);
}


/* end of daemon_init.c */
