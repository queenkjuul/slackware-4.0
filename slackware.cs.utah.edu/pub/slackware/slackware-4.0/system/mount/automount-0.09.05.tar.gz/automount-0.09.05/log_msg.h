/* LOG_MSG.h */
/* message logging function */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#ifndef LOG_MSG_H
#define LOG_MSG_H

/*****************************************************************************/
/* this function depends on a global var named program_name */
void log_msg(char *msg1, char *msg2, char *file, int line);

#define STD_LOG_FILE "/var/adm/automountd.log"

#define LOG_2MSG(_msg1_, _msg2_) log_msg((char *)_msg1_, (char *)_msg2_, __FILE__, __LINE__)
#define LOG_MSG(_msg1_) log_msg((char *)_msg1_, (char *)NULL, __FILE__, __LINE__)


#endif /* LOG_MSG_H */
/* end of log_msg.h */
