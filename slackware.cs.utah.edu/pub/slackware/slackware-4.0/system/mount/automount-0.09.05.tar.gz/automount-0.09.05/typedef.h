/* typedef.h */
/* Header for automount application */

/* Written and (C) Copyright Wolfram Saringer 1995/98  */
/* Documentation is available in the file $$$.dvi      */

#ifndef TYPEDEF_H
#define TYPEDEF_H

/*****************************************************************************/
typedef int FLAG;

typedef enum option
{
    NOEJECT   = 1,
    READONLY  = 2,
    NOPOLL    = 4,
    SKIPROUND = 8
} OPTION;

typedef struct mount_entry
{
    char *device;        /* Device name */
    ssize_t fd;          /* File Descriptor for device */
    char *filesystem;    /* File system type */
    char *mount_point;   /* Mount point for device */
    char *name;          /* Name under which the device can be unmounted */
    int skip_round;      /* Number of rounds to skip this device. */
                         /* Used for giving additional time after ejecting */
                         /* using an ATAPI CDROM drive to get the CD out */
                         /* of the tray */
    
    FLAG mounted;        /* Currently mounted: YES/NO/ERROR */
    OPTION opt;          /* Values or'ed together from enum option */
    char *buffer;        /* Holds the buffer from reading the file. */
    /* The other pointers only point into this */
    /* buffer. */
} MOUNT_ENTRY;

#endif /* TYPEDEF_H */
/* end of typedef.h */
