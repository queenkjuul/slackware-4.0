/* functions.h */
/* automount application function prototypes */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

/*****************************************************************************/
FLAG daemon_init(void);
FLAG check_cmdline(int argc, char **argv, int *intervall);
FLAG read_initfile(void);
void main_loop(int intervall);

void sighup_handler(int sig);
void sigterm_handler(int sig);
#ifdef USE_EXTENDED_SIGARGS
void sigsegv_handler(int sig, struct siginfo *info);
#else
void sigsegv_handler(int sig);
#endif /* USE_EXTENDED_SIGARGS */
void sigusr1_handler(int sig);

char *get_line(FILE *file, long offset);
FLAG open_fifo(volatile int *fifohandle);
FLAG check_fifo(int fifo);
char *unmount_device(char *name);
FLAG eject_volume(struct mount_entry *entry);
FLAG unmount_all(FLAG eject);
void mount_device(struct mount_entry *device);
FLAG answer_request(char *response);
int s_pipe(int fd[2]);

#ifndef DONT_EJECT
int is_jaz( int fd );
int motor( int fd, int mode );
int unlockdoor( int fd );
#endif /* DONT_EJECT */

/* #ifndef LINUX */
/* char *index(char *, int); */
/* char *rindex(char *, int); */
/* #endif */

#define IS_SET(value, bit) ((value | bit) == value)
#define IS_NSET(value, bit) ((value | bit) != value)

#endif /* FUNCTIONS_H */
/* end of functions.h */
