/* signal.c */
/* signal handling routines */

/* This file is part of the generic utility library */
/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file wutil.dvi */

#include "main.h"

/*****************************************************************************/
/* this is an implimentation of the signal function that uses reliable */
/* signals via sigaction(). System calls will be restarted on signals  */
/* other than SIGALRM */
 void (*signal(int signo, void (*func)(int)))(int)
{
   struct sigaction act, oact;

   act.sa_handler = func;
   (void) sigemptyset(&act.sa_mask);
   act.sa_flags = 0;
   if(signo == SIGALRM)
   {
#ifdef SA_INTERRUPT
      act.sa_flags |= SA_INTERRUPT;
#endif
   }
   else
   {
#ifdef SA_RESTART
      act.sa_flags |= SA_RESTART;
#endif
   }

#ifdef USE_EXTENDED_SIGARGS
#ifdef SA_SIGINFO
   act.sa_flags |= SA_SIGINFO;
#endif /* SA_SIGINFO */
#endif /* USE_EXTENDED_SIGARGS */

   if(sigaction(signo, &act, &oact) < 0)
      return(SIG_ERR);

   return(oact.sa_handler);
}


/* end of signal.c */
