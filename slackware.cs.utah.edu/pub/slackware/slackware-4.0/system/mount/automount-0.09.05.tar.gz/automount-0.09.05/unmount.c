/* unmount.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995/98  */
/* Documentation is available in the file $$$.dvi      */

#include "main.h"

/*****************************************************************************/
static int find_device(char *name)
{
    /* this function scans the mount table for a device with a matching */
    /* name and returns its index */

    int i;

#ifdef DEBUG
    (void) printf("searching for device -%s-\n", name);
#endif

    for(i = 0; i < mount_table_size; i++)
    {
#ifdef DEBUG
        (void) printf("comparing: device name -%s- with argument -%s-\n", mount_table[i]->name, name);
        (void) printf("strlen returns: device name: -%d-, arg: -%d-\n", strlen(mount_table[i]->name), strlen(name));
        (void) printf("strncmp returned %d\n", strncmp(name, mount_table[i]->name, strlen(name)));
#endif

        if(strncmp(name, mount_table[i]->name, strlen(name)) == 0)
        {
            /* matching entry found => return index */
            return(i);
        }
    }

    /* if this point is reached, no matching entry was found */
    return(-1);
}


/*****************************************************************************/
char *unmount_device(char *name)
{
    /* this function unmounts the device associated with 'name' */

    int index;

   /* first search table if a matching entry exists */
    if((index = find_device(name)) == -1)
    {
        /* no such device */
#ifdef DEBUG
        (void) printf("automountd: device not found\n");
#endif
        return(NAME_UNKNOWN);
    }

    /* if one exists and automountd has mounted it, try to unmount it */
    if(mount_table[index]->mounted == YES)
    {
#ifdef DEBUG
        (void) printf("automountd: unmounting device...");
#endif

        if(umount(mount_table[index]->device) == -1)
        {
#ifdef DEBUG
            (void) printf(" failed\n");
#endif
            switch(errno)
            {
               case EBUSY:
                   /* device busy: no error */
                   return(DEVICE_BUSY);
                   /* NOTREACHED */
                   /*break;*/

               default:
                   return(DEVICE_ERROR);
            }
        }
        else
        {
#ifdef DEBUG
            (void) printf(" succeded\n");
#endif

            /* try to eject media */
            if(IS_NSET(mount_table[index]->opt, NOEJECT))
            {
                (void) unlockdoor(mount_table[index]->fd);
                (void) eject_volume(mount_table[index]);
            }
            /* reset mount info */
            mount_table[index]->mounted = NO;
            /* See if SKIPROUND option is set, */
            /* and set skip_round if it is: */
            if(IS_SET(mount_table[index]->opt, SKIPROUND))
                mount_table[index]->skip_round = SKIP_ROUNDS;
            /* decrease nr of currently mounted devices */
            already_mounted--;
            return(UNMOUNT_OK);
        }
    }
    else
    {
        if(mount_table[index]->mounted == ERROR)
        {
#ifdef DEBUG
            (void) printf("automountd: device exists, but is marked unusable\n");
#endif
            return(DEVICE_UNUSABLE);
        }
	 
        else
        {
#ifdef DEBUG
            (void) printf("automountd: device exists, but is not mounted\n");
#endif
            return(DEVICE_NOT_MOUNTED);
        }


    }

    /* NOTREACHED */
}


/*****************************************************************************/
FLAG unmount_all(FLAG eject)
{
    int i;

    /* go through entire mount table and unmount each device */
    for(i = 0; i < mount_table_size; i++)
    {
#ifndef FORCE_UNMOUNT_ON_EXIT
        /* if device mounted ... */
        if(mount_table[i]->mounted == YES)
        {
#endif /* FORCE_UNMOUNT_ON_EXIT */
            /* unmount it, ignoring errors (this is normally */
            /* called by the exit routine) */
#ifdef DEBUG
            printf("unmounting -%s-\n", mount_table[i]->device);
#endif
            if(umount(mount_table[i]->device) != (-1))
                mount_table[i]->mounted = NO;

            /* Close device */
            close(mount_table[i]->fd);
            
            if(eject == YES)
            {
                (void) eject_volume(mount_table[i]);
            }
#ifndef FORCE_UNMOUNT_ON_EXIT
        }
#endif /* FORCE_UNMOUNT_ON_EXIT */
    }
    
    /* all devices are unmounted */
    /* this function is only called when cleaning up */
    /* therefore the setting of 'already_mounted' does not */
    /* really matter. To stay consistent, it is reset. */
    already_mounted = 0;
    return(OK);
}


/* end of unmount.c */
