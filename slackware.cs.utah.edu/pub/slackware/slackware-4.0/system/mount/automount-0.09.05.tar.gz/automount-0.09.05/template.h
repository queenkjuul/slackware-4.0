/* automount.h */
/* Header for automount application */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#ifndef AUTOMOUNT_H
#define AUTOMOUNT_H

/*****************************************************************************/


#endif /* AUTOMOUNT_H */
/* end of automount.h */
