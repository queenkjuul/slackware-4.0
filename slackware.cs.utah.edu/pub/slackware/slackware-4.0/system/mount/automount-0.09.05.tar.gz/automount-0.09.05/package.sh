#!/bin/sh
# Create an ASCII-version of the documentation:
# Define the tar program to use:
if [ -x /usr/local/bin/gtar ]; then
  TAR=/usr/local/bin/gtar
else
  TAR=tar
fi

cd Doc
detex automount.tex >automount.txt
cd ..

# Create tar file containing all files necessary for source distribution.
# The Name is made up from the strings "automount-", the version nummber
# extracted from version.h and ".tgz". This extraction is done by
# the `grep ...`: it gives the value of the string defined in version.h.
# If you want to use tar, change "gtar zcf" to "tar cf".
DIR=`pwd |sed 's/.*\/\([^/]*\)$/\1/'`
cd ..
$TAR zvcf  automount-`grep AUTOMOUNT_VERSION $DIR/version.h \
 |awk -F\" '{print $2}'`.tar.gz   `find $DIR/ -name "*.c" -print` \
 `find $DIR/ -name "*.h" -print` \
 `find $DIR/ -name "?akefile" -print` \
 `find $DIR/ -name "*.sh" -print` \
 `find $DIR/ -name "*.tex" -print` \
 `find $DIR/ -name "*.fig" -print` \
 `find $DIR/ -name "*.dvi" -print` \
 `find $DIR/ -name "*.ps" -print` \
 `find $DIR/ -name "*.html" -print` \
 `find $DIR/ -name "*.css" -print` \
 $DIR/Doc/automount.txt \
 $DIR/README \
 $DIR/COPYING \
 $DIR/automountd.conf
cd $DIR

