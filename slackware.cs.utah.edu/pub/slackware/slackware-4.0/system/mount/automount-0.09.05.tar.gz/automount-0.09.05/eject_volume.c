/* eject_volume.c */
/* Automount daemon */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */
/* Portions borrowed from eject 1.5 by Jeff Tranter (jeff_tranter@pobox.com) */

#include "main.h"

/*****************************************************************************/
#ifndef DONT_EJECT

#define SCSI_IOCTL_SEND_COMMAND 1

struct sdata {
  int  inlen;
  int  outlen;
  char cmd[256];
} scsi_cmd;
/* determine if device is a jaz...returns 1 if true */
int
is_jaz( int fd )
{
  char  id[25];
  int   i;

  scsi_cmd.inlen = 0;
  scsi_cmd.outlen = 40;
  scsi_cmd.cmd[0] = 0x12;               /* inquiry */
  scsi_cmd.cmd[1] = 0;
  scsi_cmd.cmd[2] = 0;
  scsi_cmd.cmd[3] = 0;
  scsi_cmd.cmd[4] = 40;
  scsi_cmd.cmd[5] = 0;

  if (ioctl(fd,SCSI_IOCTL_SEND_COMMAND,(void *)&scsi_cmd))
    return 0;  /* if the SCSI test fails, it is certainly not a JAZ or ZIP */

  for(i=0;i<24;i++) {
    id[i] = scsi_cmd.cmd[i+8];
  }
  id[24] = 0;

  if (!strncasecmp(id,"IOMEGA  JAZ 1GB",15) || !strncasecmp(id,"IOMEGA  ZIP",11)) 
  return(1);
  else return(0);
}

/* send command to SCSI device */
int motor( int fd, int mode )
{
  scsi_cmd.inlen = 0;
  scsi_cmd.outlen = 0;
  scsi_cmd.cmd[0] = 0x1b;               /* start/stop */
  scsi_cmd.cmd[1] = 0;
  scsi_cmd.cmd[2] = 0;
  scsi_cmd.cmd[3] = 0;
  scsi_cmd.cmd[4] = mode;
  scsi_cmd.cmd[5] = 0;

  if (ioctl(fd,SCSI_IOCTL_SEND_COMMAND,(void *)&scsi_cmd))
  {
     LOG_MSG("Error on motor ioctl");
     return ERROR;
  }
  return OK;
}
/* unlock the door before ejecting */
int unlockdoor( int fd )
{
  scsi_cmd.inlen = 0;
  scsi_cmd.outlen = 0;
  scsi_cmd.cmd[0] = 0x1e;               /* prevent/allow media removal */
  scsi_cmd.cmd[1] = 0;
  scsi_cmd.cmd[2] = 0;
  scsi_cmd.cmd[3] = 0;
  scsi_cmd.cmd[4] = 0;
  scsi_cmd.cmd[5] = 0;

  if (ioctl(fd,SCSI_IOCTL_SEND_COMMAND,(void *)&scsi_cmd))
  {
     LOG_MSG("Error unlocking drive door");
     return ERROR;
  }
  return OK;
}

FLAG eject_volume(struct mount_entry *entry)
{
#ifdef DEBUG
   printf("automountd: ejecting -%s-\n", entry->name);
#endif

/*    if (ioctl(fd, CDROMEJECT)) */
/*    { */
/*       (void) close(fd); */
/*       return (ERROR); */
/*    } */
   if (is_jaz(entry->fd))
   {
       unlockdoor(entry->fd);
       motor(entry->fd,1);
       motor(entry->fd,2);
   }
   else
   {
       /* not a jaz => must be a CD */
       if(ioctl(entry->fd, CDROMEJECT) != 0)
       {
          LOG_MSG("Error ejecting CD");
          return ERROR;
       }
   }

   return (OK);
}

#else /* DONT_EJECT */

FLAG eject_volume(struct mount_entry *entry)
{
    return OK;
}

#endif /* DONT_EJECT */

/* end of eject_volume.c */
