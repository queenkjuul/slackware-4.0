/* global.h */
/* global vars */

/* Written and (C) Copyright Wolfram Saringer 1995  */
/* Documentation is available in the file $$$.dvi   */

#ifndef GLOBAL_H
#define GLOBAL_H

/*****************************************************************************/
#ifdef GLOBALVARS_ENABLED
#define GLOBALVAR
#else
#define GLOBALVAR extern
#endif

GLOBALVAR volatile sig_atomic_t rereadinit_flag;
GLOBALVAR volatile sig_atomic_t checkrequest_flag;

#ifndef DONT_USE_SELECT
GLOBALVAR volatile sig_atomic_t client_finished;
#endif /* DONT_USE_SELECT */

GLOBALVAR struct mount_entry **mount_table;
GLOBALVAR int mount_table_size; /* holds the actual number of entries */
                                /* in the table. NOT off-by-one */

#ifndef DONT_USE_SELECT
GLOBALVAR int already_mounted;  /* holds the nr of actually mounted devices */
#endif /* DONT_USE_SELECT */

GLOBALVAR volatile char *program_name;   /* name under which the program was called */

GLOBALVAR volatile int fifo_fd;          /* used within SIGTERM handler */

#ifdef LINUX
GLOBALVAR char opt_nostd[200];
#endif

#endif /* GLOBAL_H */
/* end of global.h */
