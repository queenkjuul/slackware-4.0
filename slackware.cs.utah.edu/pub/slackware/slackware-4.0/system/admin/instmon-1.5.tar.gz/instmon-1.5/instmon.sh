#!/bin/sh
#
# instmon - INSTall MONitor - an installation monitoring tool
# Copyright (C) 1998-1999 Vasilis Vasaitis (vvas@hal.csd.auth.gr)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

# initializes important variables with default values
init_data()
{
    package=""
    libdir="/usr/local/lib/instmon"
    logdir="/usr/local/share/instmon"
    search="/ /var/lib"
    exclude="/proc /tmp /var /dev /home /root /usr/src /usr/local/src"
    fstype=""
    actions=""
    listdirs=""
}

# reads the system wide and user specific configuration files
read_conf_files()
{
    exclude_tmp="$exclude"
    [ -f /etc/instmon.conf ] && . /etc/instmon.conf
    exclude_tmp="$exclude_tmp $exclude"
    [ -f $HOME/.instmonrc ] && . $HOME/.instmonrc
    exclude="$exclude_tmp $exclude"
}

# gets the arguments from the command line
parse_cmd_line()
{
    while [ $# -gt 0 ]
    do
        case "$1" in
	    -i|--include)
		search="$search $2"
		shift
		;;
	    -x|--exclude)
		exclude="$exclude $2"
		shift
		;;
	    -s|--search)
	        search="$2"
		shift
		;;
	    -g|--logdir)
		logdir="$2"
		shift
		;;
	    --libdir)
		libdir="$2"
		shift
		;;
	    --fstype)
		fstype="$fstype $2"
		shift
		;;
	    --log-path)
		actions="$actions 1logpath"
		;;
	    -l|--list)
		actions="$actions 2list"
		;;
	    --diff)
		actions="$actions 3diff"
		;;
	    --tar)
		actions="$actions 4tar"
		;;
	    --deb)
		actions="$actions 5deb"
		;;
	    --rpm)
		actions="$actions 6rpm"
		;;
	    --cleanup)
		actions="$actions 7cleanup"
		;;
	    --remove-files)
		actions="$actions 8remfiles"
		;;
	    --remove-log)
		actions="$actions 9remlog"
		;;
	    --omit-dirs)
		listdirs=omit
		;;
	    --expand-dirs)
		listdirs=expand
		;;
	    -*)
		printf "instmon: %s: unknown option\n" "$1" 1>&2
		exit 1
		;;
	    *)
		if [ -z "$package" ]
		then
		    package="$1"
		else
		    printf "instmon: %s: only one package should be specified\n" "$1" 1>&2
		    exit 1
		fi
		;;
        esac
	shift
    done
    [ -z "$package" ] && package=$(basename $(pwd))
    [ -z "$actions" ] && printf "Monitoring package %s ...\n" "$package" 1>&2
}

# clean up $search/$exclude a bit
search_exclude_normalize()
{
    for var in search exclude
    do
	eval tmp=\"\$$var\"
	tmp=$(printf " %s " "$tmp" | tr -s " /" | sed "s/\/ / /g" |
	      sed "s/  / \/ /g" | tr " " "\n" | sort -u | tr "\n" " ")
	eval $var=\"\$tmp\"
    done
}

# prepares the command line of find
setup_find_args()
{
    actionargs="-cnewer $TMPDIR/instmon.$package -print"
    excludeargs=""
    if [ -n "$fstype" ]
    then
	for type in $fstype
	do
	    excludeargs="$excludeargs -not -fstype $type"
	done
	excludeargs="$excludeargs -prune -o"
    fi
    for path in $exclude
    do
	excludeargs="$excludeargs -path $path -prune -o"
    done
}

# records the current time (as the timestamp of a file)
record()
{
    printf "Recording timestamp ... " 1>&2
    : > $TMPDIR/instmon.$package
    printf "done.\n" 1>&2
}

# detects the changes made to the file system since the recorded time
compare()
{
    printf "Detecting changes ... " 1>&2
    rm -f $TMPDIR/instmon.files.$$
    : > $TMPDIR/instmon.files.$$
    for path in $search
    do
	find $path -path $path \( $actionargs , -true \) -o $excludeargs $actionargs >> $TMPDIR/instmon.files.$$ 2> /dev/null
    done
    printf "done.\n" 1>&2
}

# tidies $TMPDIR and places the log in $logdir if possible
cleanup()
{
    rm -f $TMPDIR/instmon.$package
    rm -f $TMPDIR/instlog.$package
    sort -u $TMPDIR/instmon.files.$$ > $TMPDIR/instlog.$package
    rm -f $TMPDIR/instmon.files.$$
    mv -f $TMPDIR/instlog.$package $logdir 2> /dev/null
}

# prints a log file without the contained directories
omit_directories()
{
    while read fname
    do
	[ -d "$fname" ] || printf "%s\n" "$fname"
    done
}

# prints a log file with the directories expanded up to / (needs `sort -u')
expand_directories()
{
    printf "/\n"
    dirlist=$(cat)
    while [ "$dirlist" != "" ]
    do
	printf "%s\n" "$dirlist"
	dirlist=$(printf "%s" "$dirlist" | sed "s/\/[^/]*\$//")
    done
}

# seperates the name and the version of the package
name_version_splitup()
{
    # I had to use an external file because read-ing from a pipe is broken
    rm -f $TMPDIR/instmon.split.$$
    printf "%s\n" "$package" | sed "s/-\([0-9]\)/ \1/" > $TMPDIR/instmon.split.$$
    read pkg_name pkg_ver < $TMPDIR/instmon.split.$$
    rm -f $TMPDIR/instmon.split.$$
}

package_versions_sorted()
{
    ls $logdir/instlog.$pkg_name-[0-9]* 2> /dev/null |
      sed "s%$logdir/instlog.$pkg_name-%%" | awk -f $libdir/versort.awk |
      sed "s/^/$pkg_name-/"
}

# prints out the last element of a list
choose_last()
{
    [ $# -ne 0 ] && eval printf \"%s\" \"\$\{$#\}\"
}

# detects the package, even if only its name has been specified
find_package()
{
    [ -f $logdir/instlog.$package ] && return 0
    name_version_splitup
    [ -n "$pkg_ver" ] && return 1
    last=$(choose_last $(package_versions_sorted))
    [ -z "$last" ] && return 1
    package="$last"
    return 0
}

# compares different versions of a package
diff_versions()
{
    previous=""
    rm -f $TMPDIR/instmon.files.$$
    : > $TMPDIR/instmon.files.$$
    for package in $@
    do
	if [ -z "$previous" ]
	then
	    printf " %s:\n" "$package"
	    expand_directories < $logdir/instlog.$package | sort -u | sed 1d
	else
	    printf "\n %s -> %s:\n" "$previous" "$package"
	    expand_directories < $logdir/instlog.$previous | sort -u | sed 1d > $TMPDIR/instmon.files.$$
	    expand_directories < $logdir/instlog.$package | sort -u | sed 1d | diff -u0 $TMPDIR/instmon.files.$$ - | egrep "^[-+]/"
	fi
	previous="$package"
    done
    rm -f $TMPDIR/instmon.files.$$
}

# the main function of log manipulation mode
perform_actions()
{
    while [ $# -gt 0 ]
    do
	case "$1" in
	    1logpath)
		printf "Printing the full path of the log ... done.\n" 1>&2
		printf "%s/instlog.%s\n" "$logdir" "$package"
		;;
	    2list)
		printf "Listing log ... done.\n" 1>&2
		case "$listdirs" in
		    omit)
			cat $logdir/instlog.$package | omit_directories
			;;
		    expand)
			cat $logdir/instlog.$package | expand_directories | sort -u | sed 1d
			;;
		    *)
			cat $logdir/instlog.$package
			;;
		esac
		;;
	    3diff)
		printf "Comparing all versions of the package ... done.\n" 1>&2
		name_version_splitup
		diff_versions $(package_versions_sorted)
		;;
	    4tar)
		printf "Creating tar archive in $TMPDIR ... " 1>&2
		tar -cf $TMPDIR/$package.tar $(omit_directories < $logdir/instlog.$package) 2> /dev/null
		printf "done.\n" 1>&2
		;;
	    5deb)
		printf "Creating deb package in $TMPDIR ... " 1>&2
		rm -rf $TMPDIR/instmon.debian.$$
		mkdir $TMPDIR/instmon.debian.$$
		mkdir $TMPDIR/instmon.debian.$$/DEBIAN
		name_version_splitup
		[ -z "$pkg_ver" ] && pkg_ver=0
		exec 5> $TMPDIR/instmon.debian.$$/DEBIAN/control
		printf "Package: %s\nVersion: %s\n" "$pkg_name" "$pkg_ver" 1>&5
		printf "Architecture: %s\n" $(dpkg --print-architecture) 1>&5
		printf "Maintainer: Noone.\n" 1>&5
		printf "Description: instmon generated package.\n" 1>&5
		exec 5>&1
		cp -dP $(omit_directories < $logdir/instlog.$package) $TMPDIR/instmon.debian.$$/
		dpkg-deb --build $TMPDIR/instmon.debian.$$ $TMPDIR > /dev/null
		rm -rf $TMPDIR/instmon.debian.$$
		printf "done.\n" 1>&2
		;;
	    6rpm)
		printf "Creating rpm package in $TMPDIR ... " 1>&2
		rm -f $TMPDIR/instmon.rpmrc.$$
		exec 5> $TMPDIR/instmon.rpmrc.$$
		printf "rpmdir: $TMPDIR\n" 1>&5
		printf "rpmfilename: %%{NAME}-%%{VERSION}-%%{RELEASE}.%%{ARCH}.rpm\n" 1>&5
		name_version_splitup
		[ -z "$pkg_ver" ] && pkg_ver=0
		rm -f $TMPDIR/instmon.rpmspec.$$
		exec 5> $TMPDIR/instmon.rpmspec.$$
		printf "Name: %s\nVersion: %s\n" "$pkg_name" "$pkg_ver" 1>&5
		printf "Release: 0\nSummary: instmon generated package.\n" 1>&5
		printf "Copyright: (unknown)\nGroup: (unknown)\n" 1>&5
		if [ $(choose_last $(printf "2.5.0\n%s\n" $(rpm --version | sed "s/.* //") |
				     awk -f $libdir/versort.awk)) = "2.5.0" ]
		then
		    printf "Description:\n%%files\n" 1>&5
		else
		    printf "%%description\n%%files\n" 1>&5
		fi
		omit_directories < $logdir/instlog.$package 1>&5
		exec 5>&1
		rpm -bb --quiet --rcfile $TMPDIR/instmon.rpmrc.$$ $TMPDIR/instmon.rpmspec.$$ > /dev/null
		rm -f $TMPDIR/instmon.rpmrc.$$
		rm -f $TMPDIR/instmon.rpmspec.$$
		printf "done.\n" 1>&2
		;;
	    7cleanup)
		printf "Cleaning up previous versions ... " 1>&2
		name_version_splitup
		rm -f $TMPDIR/instmon.old.$$
		diff_versions $(package_versions_sorted) | egrep "^-/" | sed "s/^-//" > $TMPDIR/instmon.old.$$
		rm -f $(tac $TMPDIR/instmon.old.$$) 2> /dev/null
		rmdir $(tac $TMPDIR/instmon.old.$$) 2> /dev/null
		rm -f $TMPDIR/instmon.old.$$
		printf "done.\n" 1>&2
		;;
	    8remfiles)
		printf "Removing files ... " 1>&2
		rm -f $(omit_directories < $logdir/instlog.$package) 2> /dev/null
		rmdir $(expand_directories < $logdir/instlog.$package | sort -ru) 2> /dev/null
		printf "done.\n" 1>&2
		;;
	    9remlog)
		printf "Removing log ... " 1>&2
		rm -f $logdir/instlog.$package
		printf "done.\n" 1>&2
		;;
	esac
	shift
    done
}

# main program
[ -z "$TMPDIR" ] && TMPDIR=/tmp
cmdline="$*"
init_data
read_conf_files
parse_cmd_line $cmdline
if [ -n "$actions" ]
then
    if find_package
    then
	printf "Acting on package %s ...\n" "$package" 1>&2
	actions=$(printf "%s " "$actions" | tr " " "\n" | sort -u | tr "\n" " ")
	perform_actions $actions
    else
	printf "Could not find log file for package %s.\n" "$package" 1>&2
	exit 1
    fi
elif [ -e $TMPDIR/instmon.$package ]
then
    search_exclude_normalize
    setup_find_args
    compare
    cleanup
else
    record
    sleep 1
fi

exit 0
