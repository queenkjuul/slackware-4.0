
#define HostIDSet	0x1
#define HostID1	0x1
#define HostID2	0x2
#define HostID3	0x3
#define HostID4	0x4
