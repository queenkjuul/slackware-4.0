$ File hostid.m
$ How to change this for other languages ?
$ Well just edit lines starting with a # to a different language.
$ You need the catalog compiler from
$	sunsite.unc.edu /pub/Linux/nls/catalogs/catpack.tar.gz
$ Once you edited this then run the command
$ 	make hostid.cat
$ and then install hostid.cat in /etc/locale/C/hostid.cat

$set 1 #HostID

$ #1 Original message is - Hostid may only be set by the superuser\n
# Hostid may only be set by the superuser\n

$ #2 Original message is - Hostid is %u (0x%x)\n
# Hostid is %u (0x%x)\n

$ #3 - Hostid is Hostid is unset\n
# Hostid is unset\n

$ #4 - Hostid is Usage: %s hostid_number\n
# Usage: %s hostid_number\n
