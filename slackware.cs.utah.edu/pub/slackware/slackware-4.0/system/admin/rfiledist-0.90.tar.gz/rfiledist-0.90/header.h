#ifndef HEADER_H
#define HEADER_H
#include <stdio.h> /* printf's and such */
#include <stdlib.h> /* Just for good measure */
#include <sys/types.h> /* socket() */
#include <netdb.h> /* For gethostbyname() in server */
#include <sys/socket.h> /* socket() */
#include <netinet/in.h> /* socket structure */
#include <arpa/inet.h> /* Just for good measure */
#include <signal.h> /* sigaction() */
#include <string.h> /* memset() */
#include <sys/wait.h> /* waitpid */
#include <ctype.h> /* tolower() */
#include <errno.h> /* debugging */
#include <stdarg.h> /* for logging functions */
#include <unistd.h> /* close() */
#include <sys/stat.h> /* for testing files */
#include <fcntl.h>
#include <utime.h> /* for utime() function in client */
#include <dirent.h> /* to handle DIR structure */
#include <sys/sysmacros.h> /* for the major() minor() makedev() macros  */
#include <pwd.h> /* needed to set uid to root during execution */
#include <syslog.h> /* needed for logging facilities */
#include <time.h> /* needed for generating timestamps on log entries */

#ifndef INET_ADDRSTRLEN
#define INET_ADDRSTRLEN         16
#endif
#ifndef UTO /* Universal Time-Out */
#define UTO 15
#endif
#ifndef CLI_TCP_PORT
#define CLI_TCP_PORT 6789
#endif
#ifndef SERV_TCP_PORT
#define SERV_TCP_PORT 6543
#endif
#ifndef CLI
#define CLI 0 
#endif
#ifndef SRV
#define SRV 1
#endif
#ifndef MAX_IP_COUNT
#define MAX_IP_COUNT 255
#endif
#ifndef MAX_PKG_NAME
#define MAX_PKG_NAME 4096
#endif
#ifndef MAX_PKG_FILES
#define MAX_PKG_FILES 1024
#endif
#ifndef MAX_HOSTNAME_LENGTH
#define MAX_HOSTNAME_LENGTH 256
#endif
#ifndef SERVER_ROOT
#define SERVER_ROOT "/"
#endif
#ifndef PACKAGE_ROOT
#define PACKAGE_ROOT "/packages/"
#endif
#ifndef SERV_LOGFILE_LOC
#define SERV_LOGFILE_LOC "/var/log/refdis.serv"
#endif
#ifndef CLI_LOGFILE_LOC
#define CLI_LOGFILE_LOC "/var/log/refdis.cli"
#endif
#ifndef MAX_FILES
#define MAX_FILES 256
#endif
#ifndef LF
#define LF '\n'
#endif
#ifndef NULL_PACKAGE_NAME
#define NULL_PACKAGE_NAME "."
#endif
#ifndef GET_CMD
#define GET_CMD "g"
#endif
#ifndef KEEP_CMD
#define KEEP_CMD "k"
#endif
#ifndef PRE_CMD
#define PRE_CMD "pre"
#endif
#ifndef POST_CMD
#define POST_CMD "post"
#endif
#ifndef QUIT_CMD
#define QUIT_CMD "quit"
#endif
#ifndef NO_PRE
#define NO_PRE "no pre"
#endif
#ifndef NO_POST
#define NO_POST "no post"
#endif
#ifndef ACK_CHAR
#define ACK_CHAR "A"
#endif
#ifndef PRE_EXT
#define PRE_EXT ".PRE"
#endif
#ifndef POST_EXT
#define POST_EXT ".POST"
#endif
#ifndef WAIT_SCRIPT
#define WAIT_SCRIPT "wait"
#endif
#ifndef NO_WAIT_SCRIPT
#define NO_WAIT_SCRIPT "nowait"
#endif
#ifndef SMALL_BUF
#define SMALL_BUF 16
#endif
#ifndef TEMP_DIR
#define TEMP_DIR "/tmp/"
#endif
#ifndef END_DELIMITER
#define END_DELIMITER "#!@#---END_OF_SCRIPT---#@!#"
#endif
#ifndef HUGE_BUF
#define HUGE_BUF 2000000
#endif
#ifndef BIG_BUF
#define BIG_BUF 8192
#endif
#ifndef SMALL_BUF
#define SMALL_BUF 16
#endif
#ifndef ONE_CHAR
#define ONE_CHAR 2
#endif
#ifndef SPACE
#define SPACE 0x20
#endif
#ifndef TAB
#define TAB 0x09
#endif
#ifndef EOL
#define EOL 0x00
#endif
#endif
