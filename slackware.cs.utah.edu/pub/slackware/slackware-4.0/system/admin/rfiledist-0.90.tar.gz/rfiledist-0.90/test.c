#include "header.h"

main()
{
  char *securitydb;
  struct stat statbuf;
  
  securitydb = malloc(sizeof(PACKAGE_ROOT)+255);
  sprintf(securitydb,"%s/packages.secure",PACKAGE_ROOT);
  
  if (stat(securitydb,&statbuf) == 0) {
    printf("main: Found security db at %s",securitydb);
  }
  else {
    printf("main: No security db.  All packages are free & unsecured.");
  }
}

