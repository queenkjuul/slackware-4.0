#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
main()
{
  struct hostent *hostname;
  /*  char *name;*/
  long addr;
  char **pptr;
    
  /*  hostname = gethostbyaddr("192.168.1.2",4,AF_INET);*/
  hostname = gethostbyname("linux.kunz.home");
  (long)addr = (long)hostname->h_addr_list[0];
  
  printf("hostname = %s\n",hostname->h_name);
  pptr = hostname->h_addr_list;
  /*  for (;*pptr != NULL;pptr++) {
    printf("hostname = \"%s\"\n",inet_ntoa(*pptr));
  }
  
  printf("hostname = \"%s\"\n",pptr);
  */
}

  
  
