#ifndef COMM_H
#define COMM_H

#ifndef HEADER_H
#include "header.h"
#endif /* HEADER_H */
#ifndef IO_H
#include "io.h"
#endif /* IO_H */
#ifndef NODE_H
#include "node.h"
#endif /* NODE_H */

#define read_cmd(a, b, c) readstring(a, b, c)
#define read_package(a, b, c) readstring(a, b, c)
#define sendACK(a,b) writeline(a,b)

#ifndef INADDR_NONE
#define INADDR_NONE 0xffffffff
#endif

typedef struct connection 
{
  struct sockaddr_in sockaddr;
  int lst_sock;
  int acc_sock;
} conn;

int make_sock(conn *C, int port);
int send_recv(int port, char *c);
int recv_send(int port, char *c);
int tcp_open(char *host, char *service, int port);

#endif /* COMM_H */
