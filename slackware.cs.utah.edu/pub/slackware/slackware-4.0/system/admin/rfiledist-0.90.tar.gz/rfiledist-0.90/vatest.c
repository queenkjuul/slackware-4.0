#include <stdarg.h>
void foo(char *fmt, ...)
{
  va_list ap;
  int d;
  char c, *p, *s;
  char *tmp;
  char dest[80];
  
  va_start(ap, fmt);
  tmp = fmt;
  vsprintf(dest,tmp,ap);
  printf("\"%s\" is it\n",dest);
  va_end(ap);
}

void main()
{
  int item=1;
  char AA='A';
  
  printf("%d this %c\n",1,'A');
  foo("%d this %c",item,AA);
}
