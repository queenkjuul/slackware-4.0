#include "header.h"
#include "logging.h"

void log(char *msg, ...);
void log_syslog(char *msg, ...);

void main()
{
  char *t = "TEST1";
  char c ='A';
  int d=97;
  
  /*  time_t t;
  char *tmstr,array[80],array2[80];
  struct tm *bt;
  
  t = time(&t);
  tmstr = ctime(&t);*/
  /*  printf("%s",tm);
  printf("\b\b\b is tm\n");
  */
  /*  bt = localtime(&t);
  strftime(array,80,"%c",bt);
  sprintf(array2,"%s : This is a test",array); 
  printf("\"%s\" is the array\n",array2);
  */
  log(0,"this is a test of different items %s %c %d",t,c,d);
  /*  log_syslog("this is an even bigger test");*/
}

void log(char *msg, ...)
{
  va_list ap;
  va_start(ap,msg);
  
  logger(0,msg,ap);
  return;
}

void log_syslog(char *msg, ...)
{
  logger_syslog(0,msg);
  return;
}
