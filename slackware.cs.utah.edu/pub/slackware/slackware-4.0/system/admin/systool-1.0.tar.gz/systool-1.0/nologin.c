#include"systool.h"

void main(int argc, char **argv);

void main(int argc, char **argv){
	char userfile[50], date[50];
	FILE *user, *proc;
	int i;
	init();
	if(argc > 1){
		systoolv();
		exit(0);
	}
	printf("You are not allowed to login.\n");
	printf("You may be a mail, ftp, or web only user.\n");
	printf("If you have any questions, please contact the\n");
	printf("system administrator. Thank You.\n");
	sleep(10);
	printf("Good bye.\n");
	#ifdef LOG_LOGIN
		for(i=0;i!=sizeof(date);i++)
			date[i]=='\0';
		proc = popen(DATE_LOCATION,"r");
		fscanf(proc,"%1024c",&date);
		pclose(proc);
		sprintf(userfile,"/tmp/%d.%d.login",
			getuid(),geteuid());
		user=fopen(userfile,"a");
		fprintf(user,"Login attempted on: %s\n",
			date);
		fclose(user);
	#endif
	return;
}
