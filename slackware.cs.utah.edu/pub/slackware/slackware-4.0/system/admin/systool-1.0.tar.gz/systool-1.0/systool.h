/* includes */
#include<stdio.h>
#include<unistd.h>
#include<signal.h>
#include<math.h>
#include<crypt.h>
#include<time.h>

/* Prototypes */
void systoolv();
void init();
void sigseg_handle();
double sqrt( double x );

/* Defines, please set to your system. */
#define LOG_LOGIN			/* Log logins that you don't want? */
#define DATE_LOCATION "/bin/date"	/* Location of date program */

/* Maintainer defines */
#define RELEASE_VERSION "1.0"

/* Global functions */
void systoolv(){
	printf("Systool - Basic System Tools Package\n");
	printf("By Michael Tang Helmeste\n");
	printf("<little_buddha@bigfoot.com> / http://www.glassfish.net\n");
	printf("Version: v%s\n", RELEASE_VERSION);
	printf("\n\n");
	return;
}

void init(){
	signal(11,sigseg_handle);
	return;
}

void sigseg_handle(){
	fprintf(stderr,"SIGSEGV caught and held, exiting now!\n\r");
	exit(1);
	return;
}

double sqrt( double x ){
	double i;
	for(i = 0;; i++){
		if((i*i)==x)
			return i;
	}
	return -1;
}
