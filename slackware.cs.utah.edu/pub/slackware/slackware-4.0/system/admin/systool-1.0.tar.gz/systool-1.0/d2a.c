#include"systool.h"

void main(int argc, char **argv);

void main(int argc, char **argv){
	int a;
	int sread;
	init();
	for (a = 1; a != argc; a++){
		sread = (int)atoi(argv[a]);
		printf("%c",(char)sread);
	}
	return;
}
