#include "systool.h"

void main(int argc, char **argv);
void usage(char **argfoo);

void main(int argc,char **argv){
	int a, b, c, x;
	init();
	if(argc!=4){
		usage(argv);
		exit(1);
	}
	a = atoi(argv[2]);
	b = atoi(argv[3]);
	c = atoi(argv[4]);
	x = ((-1*b) + sqrt((b^2 - 4*a*c)))/(2*a);
	printf("x = %d,",x);
	x = ((-1*b) - sqrt((b^2 - 4*a*c)))/(2*a);
	printf("%d\n",x);
	return;
}

void usage(char **argfoo){
	printf("Syntax: %s [ var a ] [ var b ] [ var c ]\n",
		argfoo[0]);
	printf("The quadratic formula:\n");
	printf("\t         _  ___________\n");
	printf("\t-b [+/-]  \\/ b^2 - 4ac\n");
	printf("x=\t------------------------\n");
	printf("\t      2a\n");
	return;
}
