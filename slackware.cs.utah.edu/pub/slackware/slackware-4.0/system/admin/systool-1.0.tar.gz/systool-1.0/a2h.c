#include"systool.h"

void main(int argc, char **argv);
void usage(char **foo);

void main(int argc, char **argv){
	int a,i;
	init();
	for(a = 1; a != argc; a++){
		for(i = 0; i != (sizeof(argv[a])+1); i++)
			printf("0x%x\n",(int)argv[a][i]);
	}
	return;
}

void usage(char **foo){
	return;
}
