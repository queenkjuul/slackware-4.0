#include<stdio.h>
#include<unistd.h>

void main(int argc, char **argv){
	int a,b,i;
	char buf0[20],buf1[20];
	a = atoi(argv[1]);
	b = atoi(argv[2]);
	strncpy(buf0,argv[3],sizeof(buf0));
	for(i=a;i!=b;i++){
		sprintf(buf1,"telnet %s %d",
			argv[3],i);
		system(buf1);
	}
	return;
}
