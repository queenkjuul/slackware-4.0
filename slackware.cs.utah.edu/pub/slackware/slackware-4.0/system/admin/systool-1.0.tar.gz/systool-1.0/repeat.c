#include<stdio.h>

void main(int argc, char **argv);
void usage(char **foo);

void main(int argc, char **argv){
	int i,x;
	if(argc!=3){
		usage(argv);
		exit(1);
	}
	x = atoi(argv[1]);
	for(i=0;i!=x;i++)
		printf("%s\n",argv[2]);
	return;
}

void usage(char **foo){
	printf("Syntax: %s <number of times to repeat> <message to repeat>",
		foo[0]);
	printf("\n");
	return;
}
