/* Prototypes */
void systoolv();

/* Defines, please set to your system. */
#define LOG_LOGIN			/* Log logins that you don't want? */
#define DATE_LOCATION "/bin/date"	/* Location of date program */

/* Maintainer defines */
#define RELEASE_VERSION "1.0"

/* Global functions */
void systoolv(){
	printf("Systool - Basic System Tools Package\n");
	printf("By Michael Tang Helmeste\n");
	printf("<little_buddha@bigfoot.com> / http://www.glassfish.net\n");
	printf("Version: v%s\n", RELEASE_VERSION);
	printf("\n\n");
	return;
}
