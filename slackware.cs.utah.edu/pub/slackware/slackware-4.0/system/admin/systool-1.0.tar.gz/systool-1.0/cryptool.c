#include"systool.h"

void main(int argc, char **argv);
void usage(char **args);

void main(int argc, char **argv){
	init();
	if(argc==1 || argc > 3){
		usage(argv);
		exit(1);
	}
	if(argc==2){
		systoolv();
		exit(0);
	}
	printf("%s\n",crypt(argv[2],argv[1]));
	return;
}

void usage(char **args){
	printf("Syntax: %s [2 char salt] [string]\n",
		args[0]);
	printf("For example, to encrypt \"grw345\",\n");
	printf("with a salt of \"aa\", I would type:\n");
	printf("%s \"aa\" \"grw345\"\n",args[0]);
	printf("Please notice that the quotes are necessary\n");
	printf("to interpret your encryption string and salt\n");
	printf("if they have spaces in them.\n");
	return;
}
