#include "systool.h"
void main(int argc,char **argv);
void usage(char **arg_foo);

void main(int argc,char **argv){
	int a, b, i, x, y, j;
	init();
	a = atoi(argv[1]);
	b = atoi(argv[2]);
	if(argc!=3){
		usage(argv);
		exit(1);
	}
	if(a==0||
		b==0){
		printf("Not possible!?\n\r");
		exit(1);
	}
	for(x = (-1*b); x != b;){
		y = (int)((float)b / (float)x);
		i = x + y;
		j = x * y;
		if(i == a 
			&& j == b)
			printf("Match: %d & %d\n",x,y);
		if((-1*b) < 0)
			x++;
		if((-1*b) > 0)
			x--;
	}
	return;
}

void usage(char **arg_foo){
	printf("Syntax: %s [add up to] [multiply to]\n",arg_foo[0]);
	return;
}
