#include"systool.h"

void main(int argc, char **argv);

void main(int argc, char **argv){
	int a,i;
	init();
	for(a = 1; a != argc; a++){
		for(i = 0; i != (sizeof(argv[a])+1); i++)
			printf("%d\n",(int)argv[a][i]);
	}
	return;
}
