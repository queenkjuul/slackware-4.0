#!/bin/bash
i=0
while [ "$i" -lt "8000" ]
do
        echo $i
        logger "$1 $i"
        i=`expr $i + 1`
done
