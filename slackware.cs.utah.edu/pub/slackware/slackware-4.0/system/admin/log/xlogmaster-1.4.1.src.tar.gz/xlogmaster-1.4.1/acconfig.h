/* general */
#define PACKAGE "xlogmaster"
#define VERSION "x.x"

/* for main */
#define CONFIGFILE ".xlogmaster"
#define GTKRC "xlogmaster.gtkrc"
#define ICON_SMALL FALSE
#define WORDWRAP FALSE
#define MAXTEXT 20000
#define INTERVAL 3
/* RDBLCK determines the read block size - it is basically
   the amount of bytes that a logfile may grow within one
   tenth of a second.
   If it grows more it isn't critical, but a string that might go over
   the boundary would only be recognized if there are no
   Class1 filters for this logfile */
#define RDBLCK 3000

/* for alert */
#define XLM_FADE_STEPS 50
#define XLM_FADE_SECONDS 300
#define XLM_ALERT_COLOR "1.0-0-0"

/* for audio */
#define AUDIO FALSE
