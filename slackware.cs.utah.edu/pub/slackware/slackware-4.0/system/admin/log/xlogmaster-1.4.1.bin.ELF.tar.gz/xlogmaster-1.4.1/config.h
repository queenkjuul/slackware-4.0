/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* general */
#define PACKAGE "xlogmaster"
#define VERSION "1.4.1"

/* for main */
#define CONFIGFILE ".xlogmaster"
#define GTKRC "xlogmaster.gtkrc"
#define ICON_SMALL FALSE
#define WORDWRAP FALSE
#define MAXTEXT 20000
#define INTERVAL 3
/* RDBLCK determines the read block size - it is basically
   the amount of bytes that a logfile may grow within one
   tenth of a second.
   If it grows more it isn't critical, but a string that might go over
   the boundary would only be recognized if there are no
   Class1 filters for this logfile */
#define RDBLCK 3000

/* for alert */
#define XLM_FADE_STEPS 50
#define XLM_FADE_SECONDS 300
#define XLM_ALERT_COLOR "1.0-0-0"

/* for audio */
#define AUDIO TRUE

/* Define if you have the mlockall function.  */
#define HAVE_MLOCKALL 1

/* Define if you have the putenv function.  */
#define HAVE_PUTENV 1

/* Define if you have the <sys/mman.h> header file.  */
#define HAVE_SYS_MMAN_H 1
