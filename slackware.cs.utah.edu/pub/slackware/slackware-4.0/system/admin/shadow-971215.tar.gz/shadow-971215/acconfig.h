
/* Define to enable password aging.  */
#undef AGING

/* Define if struct passwd has pw_age.  */
#undef ATT_AGE

/* Define if struct passwd has pw_comment.  */
#undef ATT_COMMENT

/* Define if struct passwd has pw_quota.  */
#undef BSD_QUOTA

/* Define to use "old" dbm.  */
#undef DBM

/* Define to support 16-character passwords.  */
#undef DOUBLESIZE

/* Define if you want my getgrent routines.  */
#undef GETGRENT

/* Define if you want my getpwent routines.  */
#undef GETPWENT

/* Define if struct lastlog has ll_host */
#undef HAVE_LL_HOST

/* Working shadow group support in libc?  */
#undef HAVE_SHADOWGRP

/* Path for lastlog file.  */
#undef LASTLOG_FILE

/* Path for faillog file.  */
#undef FAILLOG_FILE

/* Location of system mail spool directory.  */
#undef MAIL_SPOOL_DIR

/* Name of user's mail spool file if stored in user's home directory.  */
#undef MAIL_SPOOL_FILE

/* Define if you have secure RPC.  */
#undef DES_RPC

/* Define to support the MD5-based password hashing algorithm.  */
#undef MD5_CRYPT

/* Define to use ndbm.  */
#undef NDBM

/* Define to support OPIE one-time password logins.  */
#undef OPIE

/* Define to support Pluggable Authentication Modules.  */
#undef PAM

/* Define if login should support the -r flag for rlogind.  */
#undef RLOGIN

/* Define to the ruserok() "success" return value (0 or 1).  */
#undef RUSEROK

/* Define to support the shadow password file.  */
#undef SHADOWPWD

/* Define to support the shadow group file.  */
#undef SHADOWGRP

/* Define to support S/Key logins.  */
#undef SKEY

/* Define to support SecureWare(tm) long passwords.  */
#undef SW_CRYPT

/* Define to use syslog().  */
#undef USE_SYSLOG

/* Define if you have ut_host in struct utmp.  */
#undef UT_HOST

/* Path for utmp file.  */
#undef _UTMP_FILE

/* Define to ut_name if struct utmp has ut_name (not ut_user).  */
#undef UT_USER

/* Path for wtmp file.  */
#undef _WTMP_FILE

/* Defined if you have libcrypt.  */
#undef HAVE_LIBCRYPT

/* Defined if you have libcrack.  */
#undef HAVE_LIBCRACK

/* Defined if you have the ts&szs cracklib.  */
#undef HAVE_LIBCRACK_HIST

/* Defined if it includes *Pw functions.  */
#undef HAVE_LIBCRACK_PW

/* Path to passwd program.  */
#undef PASSWD_PROGRAM

/* Define to support JFH's auth. methods.  UNTESTED.  */
#undef AUTH_METHODS

/* Define to support /etc/login.access login access control.  */
#undef LOGIN_ACCESS

/* Define to support /etc/suauth su access control.  */
#undef SU_ACCESS

/* Package name.  */
#undef PACKAGE

/* Version.  */
#undef VERSION

/* Define if the compiler understands function prototypes.  */
#undef PROTOTYPES

