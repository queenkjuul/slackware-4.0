//
// Copyright (C) 1996  Lars Berntzon
//
#include <Selectable.hh>
#include <Selecter.hh>

Selecter::Selecter(void) :
    selectable(0)
{
}

void
Selecter::registerSelectable(Selectable *p)
{
    selectable = p;
}

void
Selecter::select(const char *txt)
{
    if (selectable) {
    	selectable->select(txt);
    }
}

//
// History of changes:
// Selecter.cc,v
// Revision 1.3  1996/09/14 18:33:43  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.2  1996/03/12 19:43:20  lasse
// Checking in from remote.
//
