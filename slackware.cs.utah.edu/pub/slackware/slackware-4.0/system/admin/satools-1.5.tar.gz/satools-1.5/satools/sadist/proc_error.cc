//
// Copyright (C) 1995  Lars Berntzon
//
#include <sadblib.hh>
#include <sadist.hh>
#include <iostream.h>

//////////////////////////////////////////////////////////////////
//		P R O C _ E R R O R
//		-------------------
// Description:
//	Read entries from the database.
//
//////////////////////////////////////////////////////////////////
int
SADist::proc_error(int argc, char **argv)
{
    int i;
    char *space = "";
    Tcl_ResetResult(interp);
    for(i = 1; i < argc; i++) {
    	Tcl_AppendResult(interp, space, argv[i], 0);
    	space = " ";
    }
    skip = 1;

    return TCL_OK;
}

//
// History of changes:
// proc_error.cc,v
// Revision 1.10  1996/09/14 18:33:35  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.9  1995/09/23  13:46:08  lasse
// Imported from remote
//
// Revision 1.1.1.1  1995/09/11  09:23:07  qdtlarb
// THis is version 0.6
//
// Revision 1.8  1995/09/10  20:43:24  lasse
// Added copyright everywhere
//
// Revision 1.7  1995/09/10  19:03:42  lasse
// Corrected removed Log keyword
//
// Revision 1.1.1.1  1995/07/17  07:51:36  qdtlarb
// Original V0_3
//
// Revision 1.4  1995/07/16  13:45:48  lasse
// merged differences
//
// Revision 1.3  1995/06/08  19:20:58  lasse
// backup
//
// Revision 1.2  1995/06/07  20:29:43  lasse
// It seems as i managed to make the SADist object ok.
//
// Revision 1.1  1995/05/13  20:13:42  lasse
// backup
//
