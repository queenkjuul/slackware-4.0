//
// Copyright (C) 1996  Lars Berntzon
//
#ifndef xsadb_H
#define xsadb_H
#include <Assoc.hh>

extern Assoc<SADB> dbList;		// Array of databases.

#endif // xsadb_H
