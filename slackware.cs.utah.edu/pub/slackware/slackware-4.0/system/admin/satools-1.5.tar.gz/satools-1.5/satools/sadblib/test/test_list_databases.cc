#include <iostream.h>
#include <sadblib.hh>
static void lp(const char *txt, TextList l);
main()
{
    TextList l = SADB::list_databases();;
    lp("List of databases:", l);
}

static void lp(const char *txt, TextList l)
{
    Pix i;
    cout << txt <<endl;
    for(i = l.first(); i != 0; l.next(i))
    {
    	cout << l(i).name() << endl;
    }
}
