#include <sadblib.hh>
#include <sadbcmd.hh>
#ifdef HAVE_STRING_H
#include <string.h>
#endif // HAVE_STRING_H
//
// Copyright (C) 1995, 1997  Lars Berntzon
//
//******************************************************************
//		Q U O T E _ E S C A P E
//		-----------------------
// Description:
//	Convert a string so it wont disturb a quoted string.
//
//******************************************************************
char *
quote_escape(const char *str)
{
    static char buf[MAXNAME];
    char *p;

    for(p = buf; *str; str++)
    {
	if (*str == '"') {
	    *p++ = '"';
	}
	*p++ = *str;
    }
    *p = 0;

    return buf;
}

//
// History of changes:
// quote_escape.cc,v
// Revision 1.1  1997/03/18 20:13:55  lasse
// Created quote_escape.cc
//
//
