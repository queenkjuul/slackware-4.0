#ifndef _PATCHLEVEL_H
#define _PATCHLEVEL_H

#define PATCHLEVEL "1.5"

#endif /* _PATCHLEVEL_H */
//
// History of changes:
// patchlevel.h,v
// Revision 1.31  1997/09/15 18:26:35  lasse
// Prepare for version 1.5
//
// Revision 1.30  1997/07/18 20:20:06  lasse
// Changed patchlevel to 1.4
//
// Revision 1.29  1997/03/31 20:08:20  lasse
// Now its 1.3
//
// Revision 1.28  1997/03/18 20:15:25  lasse
// Now in beta-2
//
// Revision 1.27  1997/01/30 21:50:09  lasse
// PRE1.3
//
// Revision 1.26  1997/01/30 21:49:43  lasse
// Added diffdir
//
// Revision 1.25  1996/11/12 20:27:27  lasse
// 1.2.1b1->1.2.1
//
// Revision 1.24  1996/11/10 00:10:48  lasse
// Ops, it should be 1.2 -> 1.2.1b1
//
// Revision 1.23  1996/11/09 22:24:18  lasse
// 1.2 -> 1.2.1
//
// Revision 1.22  1996/09/14 18:33:21  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.21  1996/07/30 22:15:54  lasse
// Backup
//
// Revision 1.20  1996/07/13 19:42:15  lasse
// Stepped to version 1.1
//
// Revision 1.19  1996/05/24 20:27:38  lasse
// Stepped release to version 1.0
//
// Revision 1.18  1996/05/01 20:40:37  lasse
// backup before 0.13
//
// Revision 1.17  1996/04/22 19:39:21  lasse
// Only the patchlevel file has the version in it.
//
// Revision 1.16  1996/04/05 19:51:48  lasse
// Added sainfo
//
// Revision 1.15  1996/04/05 19:06:40  lasse
// Backup
//
// Revision 1.14  1996/03/21 19:12:58  lasse
// Before tagging to 0.10
//
// Revision 1.13  1995/11/09  21:21:49  lasse
// Release 0.9
//
// Revision 1.12  1995/09/24  17:50:42  lasse
// backup
//
// Revision 1.11  1995/09/23  13:45:55  lasse
// Imported from remote
//
// Revision 1.1.1.1  1995/09/11  09:22:55  qdtlarb
// THis is version 0.6
//
// Revision 1.10  1995/09/10  21:27:24  lasse
// Modified version
//
// Revision 1.9  1995/09/10  19:03:32  lasse
// Corrected removed Log keyword
//
// Revision 1.1.1.1  1995/07/17  07:51:23  qdtlarb
// Original V0_3
//
// Revision 1.5  1995/07/16  18:04:26  lasse
// Forgot to edit it
//
// Revision 1.4  1995/07/16  13:49:12  lasse
// Merged changes
//
// Revision 1.3  1995/07/05  19:14:49  lasse
// backup
//
// Revision 1.2  1995/05/08  11:23:19  lasse
// Added requirements
//
//
