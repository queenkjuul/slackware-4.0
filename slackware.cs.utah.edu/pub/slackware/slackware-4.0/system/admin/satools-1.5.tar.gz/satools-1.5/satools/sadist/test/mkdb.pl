#!/usr/bin/perl
sub randstr 
{
   local ($num, @strings) = @_;
   local $n = @strings;
   $num %= $n;
   return $strings[$num] . "\n";
}

foreach $h (0..20)
{
    $host = "host$h";
    print "arch $host " . &randstr($h, "sun4", "hp9000");
    print "bootserver $host false\n";
    print "consolelogin $host lasse\n";
    print "device $host audio;cpu;mem;fddi\n";
    print "diskfull $host true\n";
    print "diskless $host false\n";
    print "dns_domain $host dns.dom.org\n";
    print "domain $host nisdom\n";
    print "error $host false\n";
    print "error_text $host \n";
    print "ether $host 1:2:3:4:5:6\n";
    print "exist $host true\n";
    print "host_id $host 123456\n";
    print "ip $host 1.2.3.4\n";
    print "karch sun4m\n";
    print "kernel GENERIC\n";
    print "key $host test\n";
    print "lastlogin $host lasse;marie\n";
    print "localswap $host true\n";
    print "memory $host 40\n";
    print "model $host SPARCstation-5\n";
    print "nfsserver $host " . &randstr($h, "true", "false");
    print "nismaster $host " . &randstr($h, "true", "false");
    print "nisplusserver $host " . &randstr($h, "true", "false");
    print "nisserver $host " . &randstr($h, "true", "false");
    print "osname $host " . &randstr($h, "SunOS", "linux", "hpux");
    print "osvers $host " . &randstr($h, "4.1.4", "4.1.3", "5.4", "5.5");
    print "server $host\n";
    print "site $host acme corp.\n";
    print "subnet $host 1.2.3.0\n";
    print "updated $host 960221\n";
}
