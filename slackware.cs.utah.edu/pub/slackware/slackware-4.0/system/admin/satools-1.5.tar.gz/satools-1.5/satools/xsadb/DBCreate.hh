//
// Copyright (C) 1996  Lars Berntzon
//
#ifndef _DBCREATE_HH
#define _DBCREATE_HH
#include <Updater.hh>

class DBCreate : public Updater
{
public:
    DBCreate(Widget topshell);
    //void reset(void);
    //void setup(Widget topshell);
    void popup(void);
    void popdown(void);
    ~DBCreate();

private:
    Widget top;			// The shell top widget.
    Widget databaseNameWidget;	// The text entry for database name.
    Widget descriptionWidget;	// The text entry for key description.
    Widget topshell;		// Top shell widget of application.
    
    void ok(void);
    void cancel(void);

    static void hdl_ok(Widget, XtPointer, XtPointer);
    static void hdl_cancel(Widget, XtPointer, XtPointer);
};

#endif // _DBCREATE_HH
//
// History of changes:
// DBCreate.hh,v
// Revision 1.4  1996/09/14 18:33:42  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.3  1996/03/12 19:43:19  lasse
// Checking in from remote.
//
// Revision 1.1  1996/01/22  20:17:22  lasse
// Checking in from mobile
//
//
