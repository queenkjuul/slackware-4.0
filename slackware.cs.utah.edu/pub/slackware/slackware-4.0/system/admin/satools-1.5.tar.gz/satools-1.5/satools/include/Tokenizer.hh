//
// Copyright (C) 1995  Lars Berntzon
//

class Tokenizer {
public:
    Tokenizer(void);
    char *start(char *string, const char *separators);
    char *next(const char *separators);

private:
    char *nextChar;
};
