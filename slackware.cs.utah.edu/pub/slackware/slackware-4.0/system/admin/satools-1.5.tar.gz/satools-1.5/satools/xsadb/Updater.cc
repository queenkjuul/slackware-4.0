//
// Copyright (C) 1996  Lars Berntzon
//
#include <Updater.hh>
#include <Updateable.hh>

Updater::Updater(void) :
    updateable(0)
{
}

void
Updater::registerUpdateable(Updateable *p)
{
    updateable = p;
}

void
Updater::update(void)
{
    if (updateable) {
    	updateable->update();
    }
}

//
// History of changes:
// Updater.cc,v
// Revision 1.3  1996/09/14 18:33:44  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.2  1996/03/12 19:43:21  lasse
// Checking in from remote.
//

