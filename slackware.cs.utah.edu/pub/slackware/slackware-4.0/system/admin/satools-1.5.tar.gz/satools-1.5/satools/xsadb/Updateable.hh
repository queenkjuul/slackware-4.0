#ifndef _UPDATEABLE_HH
#define _UPDATEABLE_HH
//
// Copyright (C) 1996  Lars Berntzon
//

//
// A pure virtual class (interface if one speaks java) for an object
// than can update it self.
//
class Updateable
{
public:
    virtual void update(void) = 0;
};

//
// History of changes:
// Updateable.hh,v
// Revision 1.3  1996/09/14 18:33:44  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.2  1996/03/12 19:43:21  lasse
// Checking in from remote.
//
#endif // _UPDATEABLE_HH
