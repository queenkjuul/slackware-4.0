//
// Copyright (C) 1996 Lars Berntzon
//
#ifndef _SET_HH
#define _SET_HH
//
// A set list. An entry is added by the set operating. If it allready
// exist, return ok.
//
class Set : public TextList
{
public:
    Pix set(const char *name)
    {
    	Pix i;
    	for(i = first(); i; next(i))
    	{
    	    if (strcmp(operator()(i).name(), name) == 0) {
    	    	return i;
    	    }
    	}

	i =  append(TextEntry(name));
	return i;
    }
};
#endif
//
// History of changes:
// Set.hh,v
// Revision 1.1  1996/10/20 20:36:27  lasse
// Added
//

