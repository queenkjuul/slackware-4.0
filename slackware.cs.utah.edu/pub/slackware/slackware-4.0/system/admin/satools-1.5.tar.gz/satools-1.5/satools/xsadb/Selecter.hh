#ifndef _SELECTER_HH
#define _SELECTER_HH
//
// Copyright (C) 1996  Lars Berntzon
//

//
// A pure virtual class (interface if one speaks java) for an object
// than can tell selectable objets to select.
//
class Selectable;

class Selecter
{
public:
    Selecter(void);
    void registerSelectable(Selectable *p);

protected:
    Selectable *selectable;
    void select(const char *txt);
};

//
// History of changes:
// Selecter.hh,v
// Revision 1.3  1996/09/14 18:33:43  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.2  1996/03/12 19:43:21  lasse
// Checking in from remote.
//

#endif // _SELECTER_HH
