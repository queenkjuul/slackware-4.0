//
// Copyright (C) 1995  Lars Berntzon
//
#include <sadblib.hh>
#include <sadist.hh>
#include <iostream.h>

//////////////////////////////////////////////////////////////////
//		P R O C _ T E X T
//		-----------------
// Description:
//	Handle text statements.
//
//////////////////////////////////////////////////////////////////
int
SADist::proc_text(int argc, char **argv)
{
    int i;
    char *space = "";

    //
    // Output all arguments to output.
    //
    for(i = 1; i < argc; i++) {
    	output << space << argv[i];
    	space = " ";
    }
    output << endl;
    return TCL_OK;
}

//
// History of changes:
// proc_text.cc,v
// Revision 1.8  1996/09/14 18:33:36  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.7  1995/09/23  13:46:09  lasse
// Imported from remote
//
// Revision 1.1.1.1  1995/09/11  09:23:08  qdtlarb
// THis is version 0.6
//
// Revision 1.6  1995/09/10  20:43:25  lasse
// Added copyright everywhere
//
// Revision 1.5  1995/09/10  19:03:43  lasse
// Corrected removed Log keyword
//
// Revision 1.1.1.1  1995/07/17  07:51:36  qdtlarb
// Original V0_3
//
// Revision 1.3  1995/06/07  20:29:44  lasse
// It seems as i managed to make the SADist object ok.
//
// Revision 1.2  1995/06/06  19:04:12  lasse
// Added comment
//
// Revision 1.1  1995/06/06  19:01:19  lasse
// Added text statement
//
//
