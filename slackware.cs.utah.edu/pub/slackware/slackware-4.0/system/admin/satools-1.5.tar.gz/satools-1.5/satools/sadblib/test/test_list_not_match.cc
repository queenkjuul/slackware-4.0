#include <iostream.h>
#include <sadblib.hh>
static void lp(TextList& l);
main()
{
    SADB db("machines");
    TextList l = db.list_entries();;
    TextList o;

    db.match("^osvers", "4.1.3", l, o);
    lp(o);
}

static void lp(TextList& l)
{
    Pix i;
    for(i = l.first(); i != 0; l.next(i))
    {
    	cout << l(i).name() << endl;
    }
}
