//
// Copyright (C) 1996  Lars Berntzon
//
#include <Updater.hh>

class DBPanel;

class CreateColumn : public Updater
{
public:
    CreateColumn(Widget topshell, const char *databaseName, DBPanel *p);
    void popup(void);
    void popdown(void);
    ~CreateColumn(void);

private:
    Widget topshell;		// Application top shell widget.
    Widget top;			// The popup shell top widget.
    Widget columnNameWidget;	// The text entry for column name.
    Widget descriptionWidget;	// The text entry for key description.
    char *databaseName;
    DBPanel *panel;
    
    void ok(void);
    void cancel(void);

    static void hdl_ok(Widget, XtPointer, XtPointer);
    static void hdl_cancel(Widget, XtPointer, XtPointer);
};

//
// History of changes:
// CreateColumn.hh,v
// Revision 1.3  1996/09/14 18:33:42  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.2  1996/03/12 19:43:18  lasse
// Checking in from remote.
//
// Revision 1.1  1996/01/22  20:17:22  lasse
// Checking in from mobile
//
//
