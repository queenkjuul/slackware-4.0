#include <iostream.h>
#include <sadblib.hh>
static void lp(const char *txt, TextList l);
main()
{
    Pix i;
    TextList l;

    l.append(TextEntry("entry 1"));
    l.append(TextEntry("entry 2"));
    lp("Two entries:", l);

    cout << endl;
    i = l.first();
    l.del(i);
    lp("Removed first entry:", l);

    cout << endl;
    l.append(TextEntry("entry 3"));
    lp("Two entries again:", l);

    cout << endl;
    i = l.first();
    l.next(i);
    l.del(i);
    lp("Removed second entry:", l);
    cout << "empty = " << l.empty() << endl;

    cout << endl;
    i = l.first();
    l.del(i);
    lp("Removed first entry:", l);
    cout << "empty = " << l.empty() << endl;

}

static void lp(const char *txt, TextList l)
{
    Pix i;
    cout << txt <<endl;
    for(i = l.first(); i; l.next(i))
    {
    	cout << l(i).name() << endl;
    }
}
