//
// Copyright (C) 1995  Lars Berntzon
//
#include <sadblib.hh>
#include <sadist.hh>
#include <iostream.h>

//  G l o b a l   s t u f f .


//////////////////////////////////////////////////////////////////
//		S A D I S T _ U S A G E
//		-----------------------
//
// Description:
//	Print usage for sadist.
//
//////////////////////////////////////////////////////////////////
void
sadist_usage(void)
{
    cerr << "usage: " << prog << " [-c] [-d] [-l] [-n <max-proc>] dist[,dist...] [machine ...]\n";
    exit(1);
}

//
// History of changes:
// sadist_usage.cc,v
// Revision 1.7  1996/09/14 18:33:36  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.6  1995/09/23  13:46:11  lasse
// Imported from remote
//
// Revision 1.2  1995/09/22  19:06:00  qdtlarb
// Now runs ins parallel
//
// Revision 1.1.1.1  1995/09/11  09:23:09  qdtlarb
// THis is version 0.6
//
// Revision 1.5  1995/09/10  20:43:26  lasse
// Added copyright everywhere
//
// Revision 1.4  1995/09/10  19:03:44  lasse
// Corrected removed Log keyword
//
// Revision 1.1.1.1  1995/07/17  07:51:38  qdtlarb
// Original V0_3
//
// Revision 1.2  1995/07/16  13:45:49  lasse
// merged differences
//
// Revision 1.1  1995/05/13  21:01:28  lasse
// backup
//
//
