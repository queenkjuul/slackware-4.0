#include <iostream.h>
#include "../patchlevel.h"
int
main()
{
    cout << "This is SATOOLS version " << PATCHLEVEL << ".\n";
}

//
// History of changes:
// -------------------
// sainfo.cc,v
// Revision 1.2  1996/04/05 19:48:26  lasse
// added logging
//
//
