#include <sadblib.hh>
#include <sadbcmd.hh>
//
// Copyright (C) 1995  Lars Berntzon
//

const char *
strupper(const char *str)
{
    register char *p;
    static char buf[MAXNAME];

    for(p = buf; *str; str++)
    {
    	*p++ = toupper(*str);
    }

    *p = 0;

    return buf;
}

//
// History of changes:
// strupper.cc,v
// Revision 1.6  1996/09/14 18:33:30  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.5  1995/09/23  13:46:03  lasse
// Imported from remote
//
// Revision 1.1.1.1  1995/09/11  09:22:59  qdtlarb
// THis is version 0.6
//
// Revision 1.4  1995/09/10  20:43:17  lasse
// Added copyright everywhere
//
// Revision 1.3  1995/09/10  19:03:38  lasse
// Corrected removed Log keyword
//
