#include <iostream.h>
#include <sadblib.hh>
static void lp(const char *txt, TextList l);
main()
{
    {
	SADB db("machines");
	TextList l = db.list_entries();;
	lp("machines entries:", l);
	cout << endl;
    }
    {
	SADB db("persons");
	TextList l = db.list_entries();;
	lp("persons entries:", l);
	cout << endl;
    }
}

static void lp(const char *txt, TextList l)
{
    Pix i;
    cout << txt <<endl;
    for(i = l.first(); i != 0; l.next(i))
    {
    	cout << l(i).name() << endl;
    }
}
