#include <iostream.h>
#include <sadblib.hh>
main()
{
    SADB db("machines");

    cout << "fetching osvers for host01: " << db.fetch("host01", "osvers") << endl;
}
