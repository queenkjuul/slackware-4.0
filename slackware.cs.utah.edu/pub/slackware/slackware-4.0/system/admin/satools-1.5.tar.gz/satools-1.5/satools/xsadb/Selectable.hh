//
// Copyright (C) 1996  Lars Berntzon
//
#ifndef _SELECTABLE_HH
#define _SELECTABLE_HH

//
// A pure virtual class (interface if one speaks java) for an object
// than can select based on an string.
//
class Selectable
{
public:
    virtual void select(const char *str) = 0;
};

//
// History of changes:
// Selectable.hh,v
// Revision 1.3  1996/09/14 18:33:43  lasse
// Added some things to the TODO and added pargs
//
// Revision 1.2  1996/03/12 19:43:20  lasse
// Checking in from remote.
//
#endif // _SELECTABLE_HH
