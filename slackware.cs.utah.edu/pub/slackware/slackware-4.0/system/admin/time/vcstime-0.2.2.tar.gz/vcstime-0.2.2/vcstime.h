#ifndef _PROTOS_H
#define _PROTOS_H 1
#ifndef Prototype
#define Prototype extern
#endif !Prototype
/* vcstime.c */
Prototype void fatal(const char *, int, int);
Prototype const char *do_version(void);
Prototype void do_copyright(void);
Prototype void do_help(void);
Prototype void do_short_help(void);
Prototype void do_long_help(void);
Prototype int daemonize(void);
Prototype void number_of_columns(int);
Prototype int vcstime(int);
Prototype int main(int, char *const *);
#endif !_PROTOS_H
