/****** version.h -- version control file for vcstime ************************
 *
 * HISTORY:
 * ========
 *
 * 0.2.2  (1997/04/26)	Now listening for SIGWINCH instead of polling vcsa.
 *
 * 0.2.1  (1996/06/25)	Initial rewrite by Klaus Alexander Seistrup.
 *
 * 0.1.0  (1995/12/02)	Original version from Andries Brouwer <aeb@cwi.nl>.
 *
 *****************************************************************************/

#define VERSION	"@(#) vcstime 0.2.2 (1997/04/26)"

/*
 *  EOF
 */
