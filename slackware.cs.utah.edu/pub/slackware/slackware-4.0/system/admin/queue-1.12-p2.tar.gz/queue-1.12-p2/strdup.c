/*
Only needed if OS doesn't define.*/

	 char *
strdup( str )
	char *str;
{
	char *p = mymalloc(strlen(str)+1);
	strcpy(p,str);
	return(p);
}
