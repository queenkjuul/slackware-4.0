/* utmp.c -- routines to work with utmp file.
   Copyright (C) 1998  Stanislav Shalunov

   See README file for more information. */

#include <utmp.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <syslog.h>
#include "config.h"
#include "rcs.h"
RCS_ID("$Id: utmp.c,v 1.3 1998/06/22 11:49:08 shalunov Exp $")

/* File descriptor to utmp file. */
int utmp_fd = -1;

/* Initialize so that read_utmp() can later be used.  Return 1 on
   success, 0 on failure. */
int
open_utmp ()
{
  utmp_fd = open (UTMP_PATH, O_RDONLY);
  if (utmp_fd == -1)
    {
      syslog (LOG_ERR, "%s: %m", UTMP_PATH);
      return 0;
    }
  return 1;
}

/* Read an entry from utmp file.  Return 1 on success, 0 on failure or
   EOF. 

   If this function is called without successfull call to init_utmp()
   in advance, behaviour is undefined. */
int
read_utmp (buf)
     void* buf;
{
  if (utmp_fd < 0)
    {
      syslog (LOG_ERR, "read_utmp: no prior successfull call to open_utmp().");
      abort ();
    }

  if (read (utmp_fd, buf, (sizeof (struct utmp))) < (sizeof (struct utmp)))
    return 0;
  return 1;
}

/* Close interaction with utmp file.  Should never fail. */
int
close_utmp ()
{
  close (utmp_fd);
  return 1;
}
