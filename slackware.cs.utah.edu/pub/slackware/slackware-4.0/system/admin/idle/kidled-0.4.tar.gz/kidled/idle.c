/* idle.c -- routines to report idle time of a user.
   Copyright (C) 1998  Stanislav Shalunov

   See README file for more information. */

#include <stdio.h>
#include <time.h>
#include <sys/stat.h>
#include <unistd.h>
#include "config.h"
#include "rcs.h"
RCS_ID("$Id: idle.c,v 1.5 1998/11/12 21:25:23 shalunov Exp $")

/* Return idle time in seconds of the user on the terminal TTY.  In
   case of any error, -1 is returned. */
int
idle_time (tty)
     char *tty;
{
  struct stat st;
  char ttypath[128];
  int idle;
  int lastchange;

  snprintf (ttypath, sizeof ttypath, "%s/%s", DEV_PATH, tty);
  if (stat (ttypath, &st) == -1)
    return -1;
  if (st.st_uid == 0)
    return 0;
  lastchange = st.st_atime > st.st_ctime? st.st_atime: st.st_ctime;
  idle = time (NULL) - lastchange;
  if (idle < 0)
    idle = 0;
  return idle;
}
