/* kidled -- kick idle users off the system
   Copyright (C) 1998  Stanislav Shalunov

   See README file for more information. */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <utmp.h>
#include <syslog.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "config.h"
#include "kidled.h"
#include "rcs.h"
RCS_ID("$Id: kidled.c,v 1.13 1998/07/14 11:42:56 shalunov Exp $")

/* Kill users idle for more than this. */
int max_allowed_idle = MAX_ALLOWED_IDLE;
/* Wake up this often to see if there are users to be killed. */
int wake_interval = WAKE_INTERVAL;
/* Leave alone users whose name starts with any of these. */
char ignored_users[MAX_IGNORED][UT_NAMESIZE];
int num_ignored_users = 0;
/* Leave alone these users. */
char trusted_users[MAX_TRUSTED][UT_NAMESIZE];
int num_trusted_users = 0;
/* How long to wait between SIGHUP and SIGKILL, in seconds. */
int grace_period = 3;

/* Return 1 if START is a beginning of STRING, 0 otherwise. */
int inline
strstarts (start, string)
     char *start, *string;
{
  int i;

  for (i = 0; start[i]; i++)
    if (start[i] != string[i])
      return 0;
  return 1;
}

/* Return 1 if the user NAME is _not_ to be ignored.  Return 0 if the
   user is to be ignored. */
int inline
nonignored (name)
     char *name;
{
  int i;
  for (i = 0; i < num_ignored_users; i++)
    if (strstarts (ignored_users[i], name))
      return 0;
  for (i = 0; i < num_trusted_users; i++)
    if (strncmp (trusted_users[i], name, UT_NAMESIZE) == 0)
      return 0;
  return 1;
}

/* The main loop.  Never returns.  Process utmp every wake_interval
   seconds and look for users idle more than max_allowed_idle.  Kill
   them. */
void
main_loop ()
{
  int notfirstpass = 0;

  while (1)
    {
      struct utmp ut;

      if (! open_utmp ())
	{
	  syslog (LOG_ERR, "fatal: could not open utmp file: %m");
	  exit (1);
	}
      while (read_utmp (&ut))
	{
	  if (ut.ut_type == USER_PROCESS)
	    {
	      char line[UT_LINESIZE+1];
	      int idle;

	      line[UT_LINESIZE] = '\0';
	      strncpy (line, ut.ut_line, UT_LINESIZE);
	      idle = idle_time (line);
	      if (idle < 0)
		continue;
	      if (idle > max_allowed_idle)
		{
		  char user[UT_NAMESIZE+1];
		  char host[UT_HOSTSIZE+1];

		  user[UT_NAMESIZE] = host[UT_HOSTSIZE] = '\0';
		  strncpy (user, ut.ut_user, UT_NAMESIZE);
		  strncpy (host, ut.ut_host, UT_HOSTSIZE);
		  if (nonignored (user))
		    /* If the idle time is too large and this is not the
		       first pass over utmp file we just ignore them
		       (probably a broken utmp entry). */
		    if ((idle > max_allowed_idle + 3*wake_interval + 100)
			&& notfirstpass)
		      {
			/* Bogus idle time. */
			syslog (LOG_NOTICE, "bogus idle time %ds for %s from "
				"%s on %s, skipping", idle, user, host, line);
		      }
		    else
		      {
			/* OK, kill them. */
			kick (ut.ut_pid, line);
			syslog (LOG_INFO, "%s from %s on %s idle %d seconds", 
				user, host, line, idle);
		      }
		}
	    }
	}
      close_utmp ();
      notfirstpass = 1;
      sleep (wake_interval);
    }
}

void
usage ()
{
  fprintf (stderr, "Usage: kidled [-h] [-V] [-w#] [-m#] [-g#] "
	   "[-t user1 [-t user2]...]\n\t\t"
	   "[-i string1 [-i string2]...]\n"
	   "\t-h\tprint this message and exit\n"
	   "\t-V\tprint program version and exit successfully\n"
	   "\t-w\thow many seconds to sleep after each utmp scan\n"
	   "\t-m\tallow this many seconds to be spent idle\n"
	   "\t-g\tgive this many seconds between SIGHUP and real kill\n"
	   "\t-t\tnever log off this user\n"
	   "\t-i\tignore users whose name starts with this string\n");
  exit (1);
}

int
main (argc, argv)
     int argc;
     char **argv;
{
  extern char *optarg;
  extern optind;
  int option;

  while ((option = getopt (argc, argv, "Vhw:m:g:i:t:")) != EOF)
    switch (option)
    {
    case 'V':
      printf ("%s\n", VERSION);
      exit (0);
    case 'w':
      wake_interval = atoi (optarg);
      if (wake_interval < 10)
	{
	  fprintf (stderr, "Would have to wake too often (every %d seconds)\n",
		   wake_interval);
	  usage ();
	}
      break;
    case 'm':
      max_allowed_idle = atoi (optarg);
      if (max_allowed_idle < 60)
	{
	  fprintf (stderr, "Max allowed idle time too low (%d seconds)\n",
		   max_allowed_idle);
	  usage ();
	}
      break;
    case 'g':
      grace_period = atoi (optarg);
      if (grace_period < 2)
	{
	  fprintf (stderr, "Grace period too low (%d secs)\n", grace_period);
	  usage ();
	}
      break;
    case 'i':
      if (num_ignored_users >= MAX_IGNORED)
	{
	  fprintf (stderr, "Too many `-i' options.");
	  usage ();
	}
      strncpy (ignored_users[num_ignored_users], optarg, 
	       (sizeof ignored_users[0]) - 1);
      if (! ignored_users[num_ignored_users][0])
	usage ();
      num_ignored_users++;
      break;
    case 't':
      if (num_trusted_users >= MAX_TRUSTED)
	{
	  fprintf (stderr, "Too many `-i' options.");
	  usage ();
	}
      strncpy (trusted_users[num_trusted_users], optarg, 
	       (sizeof trusted_users[0]) - 1);
      if (! trusted_users[num_trusted_users][0])
	usage ();
      num_trusted_users++;
      break;
    default:
      usage ();
    }

  switch (fork ())
    {
    case -1:
      fprintf (stderr, "Could not fork--cannot start.\n");
      exit (1);
    case 0:
      break;
    default:
      exit (0);
    }
  setsid();
  chdir ("/");
  {
    int fd;
    struct sigaction sa;

    sa.sa_handler = SIG_IGN;
    sa.sa_flags = 0;
    sigemptyset (&sa.sa_mask);
    sigaction (SIGCHLD, &sa, NULL);

    fd = open ("/dev/null", O_RDWR, 0);
    if (fd >= 0)
      {
	dup2 (fd, 0);
	dup2 (fd, 1);
	dup2 (fd, 2);
	if (fd > 2)
	  close (fd);
      }
  }
  openlog ("kidled", LOG_PID | LOG_CONS, LOG_DAEMON);
  syslog (LOG_INFO, "Starting %s", VERSION);

  main_loop ();
  /* NOTREACHED */
  return 0;
}
