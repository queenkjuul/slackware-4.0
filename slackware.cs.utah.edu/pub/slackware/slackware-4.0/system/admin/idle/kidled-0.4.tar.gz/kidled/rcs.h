/* A way to put RCS IDs into executables.  Was used as an example
   somewhere.

   $Id: rcs.h,v 1.1.1.1 1998/06/08 18:51:02 shalunov Exp $ */

#ifndef RCS_H_INCLUDED
#define RCS_H_INCLUDED

#if !defined(lint)
#ifdef __GNUC__
#define RCS_ID(id) static char *rcs_id() { return rcs_id(id); }
#else
#define RCS_ID(id) static char *rcs_id = id;
#endif /* !__GNUC__ */
#else
#define RCS_ID(id)		/* Nothing */
#endif /* !lint */

#endif /* ! RCS_H_INCLUDED */
