/* kick.c -- routines to kick users off the system
   Copyright (C) 1998  Stanislav Shalunov

   See README file for more information. */

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <syslog.h>
#include "config.h"
#include "rcs.h"
RCS_ID("$Id: kick.c,v 1.7 1998/07/13 16:10:45 shalunov Exp $")

void write_message_of_death ();
extern int grace_period;

/* Get rid of user on TTY with shell with process ID PID.  We have to
   ensure that this user is gone. */
void
kick (pid, tty)
     pid_t pid;
     char *tty;
{
  char ttypath[128];
#ifdef FUSER_PATH
  int parent;
#endif

  snprintf (ttypath, sizeof ttypath, "%s/%s", DEV_PATH, tty);
  /* Tell them they are going to die. */
  write_message_of_death (ttypath);
  /* If we have fuser, let it do the dirty work: it shall send SIGHUP
     to all the processes. */
#ifdef FUSER_PATH
  /* First, we shall send SIGHUP to all processes attached to TTY. */
  parent = fork ();
  if (parent == 0)
    {
      /* Child. */
      execl (FUSER_PATH, "fuser", "-HUP", "-kv", ttypath, 0);
      syslog (LOG_ERR, "warning: FUSER_PATH was defined at compile time, "
	      "but I cannot execute %s: %m.  Rebiuld kidled or put "
	      "(a symlink to) fuser in place.", FUSER_PATH);
      kill (-pid, SIGHUP);
      _exit (0);
    }
#else /* ! FUSER_PATH */
  kill (-pid, SIGHUP);
  kill (pid, SIGHUP);
#endif
  sleep (grace_period);
  kill (-pid, SIGKILL);
  kill (pid, SIGKILL);
}

/* Write message to the terminal pointed by ttypath (or in fact, it
   can be any file. */
void
write_message_of_death (ttypath)
     char *ttypath;
{
  int fd;
  char msg[] = "\r\n\r\n\r\n\t\t\t----- logging you out -----\r\n\r\n"
    "Sorry, you've been idle for too long.  I'll log you out now.\r\n"
    "All the applications you might be running will be notified;\r\n"
    "they all will have a chance to exit gracefully.\r\n\r\n"
    "In general, it is always a good idea to log out when you are\r\n"
    "leaving your terminal.  Sorry for any inconvenience and goodbye.\r\n\r\n";

  fd = open (ttypath, O_RDWR | O_NOCTTY | O_APPEND);
  write (fd, &msg, sizeof msg);
  close (fd);
}
