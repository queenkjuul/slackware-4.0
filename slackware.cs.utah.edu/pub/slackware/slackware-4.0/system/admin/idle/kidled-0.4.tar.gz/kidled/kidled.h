/* kidled.h -- header file for kidled.
   Copyright (C) 1998  Stanislav Shalunov

   $Id: kidled.h,v 1.3 1998/06/22 11:49:08 shalunov Exp $ */

#ifndef KIDLED_H_INCLUDED
#define KIDLED_H_INCLUDED

int open_utmp ();
int read_utmp (void *buf);
int close_utmp ();
int idle_time (char *tty);
void kick (int pid, char *tty);

#ifndef __GNUC__
#define inline
#else /* __GNUC__ */
#define inline __inline__
#endif /* __GNUC__ */

#endif /* ! KIDLED_H_INCLUDED */
