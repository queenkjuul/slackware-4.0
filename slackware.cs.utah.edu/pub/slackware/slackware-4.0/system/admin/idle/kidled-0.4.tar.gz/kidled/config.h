/* Edit this file to reflect your system's needs. 
   Copyright (C) 1998  Stanislav Shalunov

   See README file for more information.
 
   $Id: config.h,v 1.6 1998/12/18 19:35:55 shalunov Exp $ */

/* Should be uncommented if and only if your system has a fuser
   program that supports invokation like this:

   fuser -HUP -kv /dev/tty1

   Most systems will not need to use this.  Notable exception is
   Linux. */
#define FUSER_PATH "/usr/sbin/fuser"

/* Where is your utmp file?  It might be /etc/utmp or /var/run/utmp or
   /var/adm/utmp or even /var/log/utmp. */
#define UTMP_PATH "/var/run/utmp"

/* Maximum allowed idle time, in seconds. */
#define MAX_ALLOWED_IDLE (20*60)

/* How often to check for idle users (time in seconds). */
#define WAKE_INTERVAL 120

/* How many `-i' options can be given? */
#define MAX_IGNORED 16

/* How many `-t' options can be given? */
#define MAX_TRUSTED MAX_IGNORED

/* This must point to the directory containing tty special files. */
#define DEV_PATH "/dev"

/* Program version. */
#define VERSION "Kidled 0.4"
