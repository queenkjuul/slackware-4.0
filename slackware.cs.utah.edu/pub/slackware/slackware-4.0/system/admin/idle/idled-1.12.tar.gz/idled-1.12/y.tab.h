
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
	char *sb; 
	int nb;
       } YYSTYPE;
extern YYSTYPE yylval;
# define TTY 257
# define LOGIN 258
# define GROUP 259
# define FILECOM 260
# define DEFAULT 261
# define EXEMPT 262
# define TIMEOUT 263
# define SLEEP 264
# define WARN 265
# define IDLEMETHOD 266
# define CONSWINS 267
# define SESSION 268
# define REFUSE 269
# define MULTIPLES 270
# define NUM 271
# define IDLE 272
# define MULTIPLE 273
# define NAME 274
# define ALL 275
# define THRESHOLD 276
# define NL 277
# define USERINPUT 278
# define INPUTOUTPUT 279
# define NORMAL 280
# define OFF 281
