/* Written By Mike Crider on September 18, 1994
 * Prints out the number of lines in the utmp file.
 * Use a number greater than the output number for the
 * MAXUSERS definition in idled.h.
 *
 * Written October 3, 1995
 */

/* Choose a system type */
/* #define SYSV */
/* #define BSD */

#include <sys/types.h>
#include <stdio.h>
#include <utmp.h>

#if !defined(SYSV) && !defined(BSD)
#define SYSV
#endif

/* Maybe this should always be included? */
#ifdef SYSV
#include <fcntl.h>
#endif SYSV

int main()
{
   struct utmp *uent;
   int fd, numlines;

   fd = open("/etc/utmp",O_RDONLY,0);

   uent = (struct utmp *) malloc (sizeof(struct utmp));

   numlines = 0;
   while (read(fd,uent,sizeof(struct utmp)) > 0)
      numlines++;
   
   close(fd);

   printf("Number of lines in utmp file: %d\n",numlines);

   return 0;
}
