#include <stdio.h>
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
#ifndef __cplusplus
# define output(c) (void)putc(c,yyout)
#else
# define lex_output(c) (void)putc(c,yyout)
#endif

#if defined(__cplusplus) || defined(__STDC__)

#if defined(__cplusplus) && defined(__EXTERN_C__)
extern "C" {
#endif
	int yyback(int *, int);
	int yyinput(void);
	int yylook(void);
	void yyoutput(int);
	int yyracc(int);
	int yyreject(void);
	void yyunput(int);
	int yylex(void);
#ifdef YYLEX_E
	void yywoutput(wchar_t);
	wchar_t yywinput(void);
#endif
#ifndef yyless
	void yyless(int);
#endif
#ifndef yywrap
	int yywrap(void);
#endif
#ifdef LEXDEBUG
	void allprint(char);
	void sprint(char *);
#endif
#if defined(__cplusplus) && defined(__EXTERN_C__)
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
	void exit(int);
#ifdef __cplusplus
}
#endif

#endif
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
#ifndef __cplusplus
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#else
# define lex_input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#endif
#define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;


# line 4 "scan.l"
/**************************************************************************
 *  Lex grammer to scan input file for idled                              *
 **************************************************************************/

#include <stdio.h>
#include "y.tab.h"

#define makestr(Z)	((char *)strcpy((char *)malloc(strlen(Z)+1),Z))

int linenum = 1;	/* current line number for error messages */

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
#ifdef __cplusplus
/* to avoid CC and lint complaining yyfussy not being used ...*/
static int __lex_hack = 0;
if (__lex_hack) goto yyfussy;
#endif
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:

# line 17 "scan.l"
	return ALL;
break;
case 2:

# line 18 "scan.l"
	return DEFAULT;
break;
case 3:

# line 19 "scan.l"
	return EXEMPT;
break;
case 4:

# line 20 "scan.l"
	return GROUP;
break;
case 5:

# line 21 "scan.l"
	return IDLE;
break;
case 6:

# line 22 "scan.l"
return IDLEMETHOD;
break;
case 7:

# line 23 "scan.l"
       return CONSWINS;
break;
case 8:

# line 24 "scan.l"
	return LOGIN;
break;
case 9:

# line 25 "scan.l"
return MULTIPLE;
break;
case 10:

# line 26 "scan.l"
return MULTIPLES;
break;
case 11:

# line 27 "scan.l"
	return REFUSE;
break;
case 12:

# line 28 "scan.l"
	return SESSION;
break;
case 13:

# line 29 "scan.l"
	return SLEEP;
break;
case 14:

# line 30 "scan.l"
           return WARN;
break;
case 15:

# line 31 "scan.l"
return THRESHOLD;
break;
case 16:

# line 32 "scan.l"
	return TIMEOUT;
break;
case 17:

# line 33 "scan.l"
	return TTY;
break;
case 18:

# line 34 "scan.l"
         return NORMAL;
break;
case 19:

# line 35 "scan.l"
            return OFF;
break;
case 20:

# line 36 "scan.l"
      return USERINPUT;
break;
case 21:

# line 37 "scan.l"
    return INPUTOUTPUT;
break;
case 22:

# line 38 "scan.l"
           return FILECOM;
break;
case 23:

# line 40 "scan.l"
{
				yylval.sb = makestr(yytext);
				return NAME; 
			}
break;
case 24:

# line 45 "scan.l"
		{
				yylval.nb = atoi(yytext);
				return NUM;
			}
break;
case 25:

# line 50 "scan.l"
		{
				yylval.nb = atoi(yytext);
				return NUM;
			}
break;
case 26:

# line 55 "scan.l"
		;
break;
case 27:

# line 57 "scan.l"
		{ 
				linenum++; 
				return NL;
			}
break;
case 28:

# line 61 "scan.l"
		;
break;
case 29:

# line 63 "scan.l"
		{
				static	char	errormsg[] = "Illegal character ' '.";

				errormsg[19] = yytext[0];
				yyerror(errormsg);
			}
break;
case -1:
break;
default:
(void)fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
int yyvstop[] = {
0,

28,
0,

28,
0,

29,
0,

28,
29,
0,

27,
0,

26,
29,
0,

29,
0,

23,
29,
0,

24,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

23,
29,
0,

28,
0,

26,
0,

25,
0,

23,
0,

24,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

1,
23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

19,
23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

17,
23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

22,
23,
0,

23,
0,

5,
23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

14,
23,
0,

23,
0,

23,
0,

23,
0,

4,
23,
0,

23,
0,

23,
0,

8,
23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

13,
23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

3,
23,
0,

23,
0,

23,
0,

23,
0,

18,
23,
0,

11,
23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

2,
23,
0,

23,
0,

23,
0,

23,
0,

12,
23,
0,

23,
0,

16,
23,
0,

23,
0,

7,
23,
0,

23,
0,

23,
0,

9,
23,
0,

23,
0,

23,
0,

23,
0,

23,
0,

10,
23,
0,

15,
23,
0,

20,
23,
0,

6,
23,
0,

23,
0,

21,
23,
0,
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	6,27,	0,0,	0,0,	
0,0,	0,0,	1,4,	1,5,	
4,26,	6,27,	6,0,	27,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	4,26,	
1,6,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,7,	0,0,	
1,8,	1,9,	0,0,	6,27,	
6,27,	0,0,	0,0,	0,0,	
0,0,	2,6,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	2,7,	
7,28,	7,28,	7,28,	7,28,	
7,28,	7,28,	7,28,	7,28,	
7,28,	7,28,	9,30,	9,30,	
9,30,	9,30,	9,30,	9,30,	
9,30,	9,30,	9,30,	9,30,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
1,3,	0,0,	1,10,	6,27,	
1,11,	1,12,	1,13,	1,14,	
1,15,	12,33,	1,16,	14,35,	
20,42,	1,17,	1,18,	1,19,	
1,20,	10,31,	11,32,	1,21,	
1,22,	1,23,	1,24,	2,10,	
1,25,	2,11,	2,12,	2,13,	
2,14,	2,15,	13,34,	2,16,	
15,36,	17,39,	2,17,	2,18,	
2,19,	2,20,	18,40,	19,41,	
2,21,	2,22,	2,23,	2,24,	
21,43,	2,25,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	24,49,	25,50,	31,51,	
32,52,	33,53,	34,54,	35,55,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	36,56,	37,57,	
38,58,	39,59,	8,29,	40,60,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	8,29,	8,29,	
8,29,	8,29,	16,37,	22,44,	
23,46,	23,47,	41,61,	42,62,	
43,63,	44,64,	22,45,	45,65,	
16,38,	46,66,	47,67,	48,68,	
23,48,	49,69,	50,70,	52,71,	
53,72,	54,73,	55,74,	56,75,	
57,76,	58,77,	59,78,	60,79,	
61,80,	63,81,	64,82,	65,83,	
66,84,	67,85,	69,86,	70,87,	
71,88,	72,89,	73,90,	75,91,	
76,92,	77,93,	78,94,	79,95,	
80,96,	81,97,	82,98,	83,99,	
84,100,	85,101,	86,102,	88,103,	
89,104,	90,105,	92,106,	93,107,	
95,108,	96,109,	97,110,	98,111,	
100,112,	101,113,	102,114,	103,115,	
104,116,	106,117,	107,118,	108,119,	
111,120,	112,121,	113,122,	114,123,	
115,124,	117,125,	118,126,	119,127,	
121,128,	123,129,	125,130,	126,131,	
127,132,	128,133,	129,134,	130,135,	
131,136,	136,137,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		yyvstop+1,
yycrank+-22,	yysvec+1,	yyvstop+3,
yycrank+0,	0,		yyvstop+5,
yycrank+3,	0,		yyvstop+7,
yycrank+0,	0,		yyvstop+10,
yycrank+-4,	0,		yyvstop+12,
yycrank+20,	0,		yyvstop+15,
yycrank+95,	0,		yyvstop+17,
yycrank+30,	0,		yyvstop+20,
yycrank+5,	yysvec+8,	yyvstop+23,
yycrank+3,	yysvec+8,	yyvstop+26,
yycrank+4,	yysvec+8,	yyvstop+29,
yycrank+6,	yysvec+8,	yyvstop+32,
yycrank+2,	yysvec+8,	yyvstop+35,
yycrank+14,	yysvec+8,	yyvstop+38,
yycrank+118,	yysvec+8,	yyvstop+41,
yycrank+18,	yysvec+8,	yyvstop+44,
yycrank+17,	yysvec+8,	yyvstop+47,
yycrank+24,	yysvec+8,	yyvstop+50,
yycrank+6,	yysvec+8,	yyvstop+53,
yycrank+39,	yysvec+8,	yyvstop+56,
yycrank+118,	yysvec+8,	yyvstop+59,
yycrank+116,	yysvec+8,	yyvstop+62,
yycrank+38,	yysvec+8,	yyvstop+65,
yycrank+57,	yysvec+8,	yyvstop+68,
yycrank+0,	yysvec+4,	yyvstop+71,
yycrank+-5,	yysvec+6,	yyvstop+73,
yycrank+0,	yysvec+7,	yyvstop+75,
yycrank+0,	yysvec+8,	yyvstop+77,
yycrank+0,	yysvec+9,	yyvstop+79,
yycrank+47,	yysvec+8,	yyvstop+81,
yycrank+46,	yysvec+8,	yyvstop+83,
yycrank+55,	yysvec+8,	yyvstop+85,
yycrank+57,	yysvec+8,	yyvstop+87,
yycrank+51,	yysvec+8,	yyvstop+89,
yycrank+75,	yysvec+8,	yyvstop+91,
yycrank+79,	yysvec+8,	yyvstop+93,
yycrank+76,	yysvec+8,	yyvstop+95,
yycrank+86,	yysvec+8,	yyvstop+97,
yycrank+83,	yysvec+8,	yyvstop+99,
yycrank+108,	yysvec+8,	yyvstop+101,
yycrank+121,	yysvec+8,	yyvstop+103,
yycrank+122,	yysvec+8,	yyvstop+105,
yycrank+110,	yysvec+8,	yyvstop+107,
yycrank+126,	yysvec+8,	yyvstop+109,
yycrank+115,	yysvec+8,	yyvstop+111,
yycrank+121,	yysvec+8,	yyvstop+113,
yycrank+110,	yysvec+8,	yyvstop+115,
yycrank+132,	yysvec+8,	yyvstop+117,
yycrank+120,	yysvec+8,	yyvstop+119,
yycrank+0,	yysvec+8,	yyvstop+121,
yycrank+120,	yysvec+8,	yyvstop+124,
yycrank+139,	yysvec+8,	yyvstop+126,
yycrank+128,	yysvec+8,	yyvstop+128,
yycrank+137,	yysvec+8,	yyvstop+130,
yycrank+122,	yysvec+8,	yyvstop+132,
yycrank+139,	yysvec+8,	yyvstop+134,
yycrank+124,	yysvec+8,	yyvstop+136,
yycrank+137,	yysvec+8,	yyvstop+138,
yycrank+127,	yysvec+8,	yyvstop+140,
yycrank+135,	yysvec+8,	yyvstop+142,
yycrank+0,	yysvec+8,	yyvstop+144,
yycrank+128,	yysvec+8,	yyvstop+147,
yycrank+131,	yysvec+8,	yyvstop+149,
yycrank+146,	yysvec+8,	yyvstop+151,
yycrank+147,	yysvec+8,	yyvstop+153,
yycrank+148,	yysvec+8,	yyvstop+155,
yycrank+0,	yysvec+8,	yyvstop+157,
yycrank+136,	yysvec+8,	yyvstop+160,
yycrank+141,	yysvec+8,	yyvstop+162,
yycrank+133,	yysvec+8,	yyvstop+164,
yycrank+136,	yysvec+8,	yyvstop+166,
yycrank+142,	yysvec+8,	yyvstop+168,
yycrank+0,	yysvec+8,	yyvstop+170,
yycrank+143,	yysvec+8,	yyvstop+173,
yycrank+147,	yysvec+8,	yyvstop+175,
yycrank+141,	yysvec+8,	yyvstop+178,
yycrank+148,	yysvec+8,	yyvstop+180,
yycrank+154,	yysvec+8,	yyvstop+182,
yycrank+163,	yysvec+8,	yyvstop+184,
yycrank+146,	yysvec+8,	yyvstop+186,
yycrank+157,	yysvec+8,	yyvstop+188,
yycrank+151,	yysvec+8,	yyvstop+190,
yycrank+149,	yysvec+8,	yyvstop+192,
yycrank+154,	yysvec+8,	yyvstop+194,
yycrank+161,	yysvec+8,	yyvstop+196,
yycrank+0,	yysvec+8,	yyvstop+198,
yycrank+162,	yysvec+8,	yyvstop+201,
yycrank+160,	yysvec+8,	yyvstop+203,
yycrank+153,	yysvec+8,	yyvstop+205,
yycrank+0,	yysvec+8,	yyvstop+207,
yycrank+169,	yysvec+8,	yyvstop+210,
yycrank+160,	yysvec+8,	yyvstop+212,
yycrank+0,	yysvec+8,	yyvstop+214,
yycrank+160,	yysvec+8,	yyvstop+217,
yycrank+165,	yysvec+8,	yyvstop+219,
yycrank+173,	yysvec+8,	yyvstop+221,
yycrank+164,	yysvec+8,	yyvstop+223,
yycrank+0,	yysvec+8,	yyvstop+225,
yycrank+172,	yysvec+8,	yyvstop+228,
yycrank+160,	yysvec+8,	yyvstop+230,
yycrank+168,	yysvec+8,	yyvstop+232,
yycrank+169,	yysvec+8,	yyvstop+234,
yycrank+164,	yysvec+8,	yyvstop+236,
yycrank+0,	yysvec+8,	yyvstop+238,
yycrank+165,	yysvec+8,	yyvstop+241,
yycrank+165,	yysvec+8,	yyvstop+243,
yycrank+175,	yysvec+8,	yyvstop+245,
yycrank+0,	yysvec+8,	yyvstop+247,
yycrank+0,	yysvec+8,	yyvstop+250,
yycrank+174,	yysvec+8,	yyvstop+253,
yycrank+174,	yysvec+8,	yyvstop+255,
yycrank+170,	yysvec+8,	yyvstop+257,
yycrank+175,	yysvec+8,	yyvstop+259,
yycrank+173,	yysvec+8,	yyvstop+261,
yycrank+0,	yysvec+8,	yyvstop+263,
yycrank+185,	yysvec+8,	yyvstop+266,
yycrank+174,	yysvec+8,	yyvstop+268,
yycrank+190,	yysvec+8,	yyvstop+270,
yycrank+0,	yysvec+8,	yyvstop+272,
yycrank+184,	yysvec+8,	yyvstop+275,
yycrank+0,	yysvec+8,	yyvstop+277,
yycrank+176,	yysvec+8,	yyvstop+280,
yycrank+0,	yysvec+8,	yyvstop+282,
yycrank+183,	yysvec+8,	yyvstop+285,
yycrank+183,	yysvec+8,	yyvstop+287,
yycrank+181,	yysvec+8,	yyvstop+289,
yycrank+197,	yysvec+8,	yyvstop+292,
yycrank+182,	yysvec+8,	yyvstop+294,
yycrank+199,	yysvec+8,	yyvstop+296,
yycrank+183,	yysvec+8,	yyvstop+298,
yycrank+0,	yysvec+8,	yyvstop+300,
yycrank+0,	yysvec+8,	yyvstop+303,
yycrank+0,	yysvec+8,	yyvstop+306,
yycrank+0,	yysvec+8,	yyvstop+309,
yycrank+185,	yysvec+8,	yyvstop+312,
yycrank+0,	yysvec+8,	yyvstop+314,
0,	0,	0};
struct yywork *yytop = yycrank+301;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
  0,   1,   1,   1,   1,   1,   1,   1, 
  1,   9,  10,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  9,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,  47, 
 48,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,   1,   1,   1,   1,   1,   1, 
  1,  47,  47,  47,  47,  47,  47,  47, 
 47,  47,  47,  47,  47,  47,  47,  47, 
 47,  47,  47,  47,  47,  47,  47,  47, 
 47,  47,  47,   1,   1,   1,   1,  95, 
  1,  47,  47,  47,  47,  47,  47,  47, 
 47,  47,  47,  47,  47,  47,  47,  47, 
 47,  47,  47,  47,  47,  47,  47,  47, 
 47,  47,  47,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*	Copyright (c) 1989 AT&T	*/
/*	  All Rights Reserved  	*/

/*	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T	*/
/*	The copyright notice above does not evidence any   	*/
/*	actual or intended publication of such source code.	*/

#pragma ident	"@(#)ncform	6.7	93/06/07 SMI"

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
#if defined(__cplusplus) || defined(__STDC__)
int yylook(void)
#else
yylook()
#endif
{
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
#ifndef __cplusplus
			*yylastch++ = yych = input();
#else
			*yylastch++ = yych = lex_input();
#endif
			if(yylastch > &yytext[YYLMAX]) {
				fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
				exit(1);
			}
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
#ifndef __cplusplus
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
#else
		yyprevious = yytext[0] = lex_input();
		if (yyprevious>0)
			lex_output(yyprevious);
#endif
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
#if defined(__cplusplus) || defined(__STDC__)
int yyback(int *p, int m)
#else
yyback(p, m)
	int *p;
#endif
{
	if (p==0) return(0);
	while (*p) {
		if (*p++ == m)
			return(1);
	}
	return(0);
}
	/* the following are only used in the lex library */
#if defined(__cplusplus) || defined(__STDC__)
int yyinput(void)
#else
yyinput()
#endif
{
#ifndef __cplusplus
	return(input());
#else
	return(lex_input());
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyoutput(int c)
#else
yyoutput(c)
  int c; 
#endif
{
#ifndef __cplusplus
	output(c);
#else
	lex_output(c);
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyunput(int c)
#else
yyunput(c)
   int c; 
#endif
{
	unput(c);
	}
