#include <sys/types.h>
#include <stdio.h>
#include <sys/param.h>

#define	SYSERROR	(-1)

#ifndef TRUE
#define TRUE (1==1)
#endif

#ifndef FALSE
#define FALSE !TRUE
#endif

#ifndef UTMP_FILE
#define UTMP_FILE	"/etc/utmp"	/* name of utmp file */
#endif

#define DEV		"/dev/\0"

/* Name of the console device */
#define CONSOLE_NAME    "/dev/console"


/* Keyboard and Mouse Devices to Check in Place of Console */
#define KEYBOARD_NAME   "/dev/kbd"
#define MOUSE_NAME      "/dev/mouse"
/* On an IBM compatible, the mouse may be on a serial port,
 * in which case the mouse device will be ttya or ttyb.
 * Should this be the case, be sure to change the MOUSE_NAME
 * appropriately.  This includes Solaris x86 (v2.4), at least.
 * Solaris x86 info:
 *   Mouse Mode     MOUSE_NAME
 *   ==========     ==========
 *   PS/2 style     "/dev/kdmouse"
 *   Logitech Bus   "/dev/logi"
 *   Microsft Bus   "/dev/msm"
 *   Serial         "/dev/ttya"  (or ttyb, for port 2)
 * Note that the keyboard also goes through the same device,
 * so the KEYBOARD_NAME definition is irrelevant (it will be
 * ignored if it is invalid, just be sure to leave it invalid).
 */

/* Name of the X console locking program */
#define XLOCK_NAME      "xlock"

#ifndef AIX
#if !defined(NGROUPS) && defined(NGROUPS_MAX_DEFAULT)
#   define NGROUPS NGROUPS_MAX_DEFAULT
#else
#   if !defined(NGROUPS)
#       define NGROUPS 16
#   endif
#endif
#endif /* AIX */

/* MAXUSERS in general represents approximately the maximum number of
 * users logged on at any one moment.  In reality, it represents the
 * maximum number of entries in the utmp file.  Due to the handling
 * of the utmp file on some systems, the number of users on at a time
 * may be much smaller than the number of lines in the utmp file.
 * Doing a "make utmplines" will compile a run a small test program
 * to print out the current number of lines in your utmp file.
 * MAXUSERS should be greater than this number.
 */
#define MAXUSERS	100

#define NAMELEN		8		/* length of login name */

#define IS_IDLE		0x1
#define IS_MULT		0x2
#define IS_LIMIT	0x4
#define	IS_REFU		0x8
#define IS_XLOCK	0x16

typedef	enum	{ false = 0, true = 1 }	bool;

struct user
{
	int	idle;		  /* max idle limit for this user */
	int	groups[NGROUPS];  /* gids from passwd and group files */
	bool	refuse;		  /* true is user should be refused access */
	int	session;	  /* session limit for this user */
	int	warned;		  /* if he has been warned before */
	int	exempt;		  /* what is this guy exempt from? */
	time_t	next;		  /* next time to examine this structure */
	time_t	time_on;	  /* loggin time */
	char	uid[NAMELEN + 1]; /* who is this is? */
	char	line[14];	  /* his tty in the form "/dev/ttyxx" or "/dev/pts/X" */
	char	host[16];	  /* the host this user is connecting from */
        int     pid;              /* the process number of this login */
};

/* 
** next will be cur_time+limit-idle do all we have to do is check
** the current time against the action field when the daemon comes
** around.  if >= then it's time to check the idle time again, else
** just skip him.
*/

extern	struct	user	users[];
extern	struct	user	*pusers[];

/* records that the nodes of the linked list will have pointers too */

struct item
{
	int	name_t;		/* is it a login, group, etc... */
	char	*name;		/* which login, etc */
	int	num;		/* group */
	int	flag;		/* what is the timeout/exemption ? */
};

/* necessary structures to use the system linked list stuff */

struct qelem
{
	struct	qelem	*q_forw;
	struct	qelem	*q_back;
	struct	item	*q_item;
};

/* These items are gleaned from the configuration file...	*/

extern	struct	qelem	*rules; 	/* list of idle timeout rules	*/
extern	struct	qelem	*exmpt; 	/* list of exemptions		*/
extern	struct	qelem	*refuse;	/* list of refuse rules		*/
extern	struct	qelem	*session;	/* list of session limit rules  */

extern	int	sleeptime;	/* max time to sleep between scans of utmp */
extern	int	warntime;	/* how long to allow for warnings */
extern	int	conswins_idle;	/* max idle time for wins of console user */
extern	int	conswins_sess;	/* max idle time for wins of console user */
extern	int	conswins_mult;	/* max idle time for wins of console user */
extern	int	m_threshold;	/* multiple login warning threshold */
extern	int	s_threshold;	/* session limit warning threshold */
extern	int	session_default;/* The default session limit time */
extern	int	sess_refuse_len;/* The refuse time after a session logout */
extern	int	warn_flags;	/* what warnings to make */
extern	int	mult_per_user;  /* number of multiple logins allowed per user */
extern	int	ioidle;         /* True=use i&o as idle time ; False=i only */


extern	void	logfile();
