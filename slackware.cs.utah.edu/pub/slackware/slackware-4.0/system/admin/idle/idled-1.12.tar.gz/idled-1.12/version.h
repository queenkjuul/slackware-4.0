/* Version.h for idled */

#define IDLED_VERSION "idled version 1.11"
