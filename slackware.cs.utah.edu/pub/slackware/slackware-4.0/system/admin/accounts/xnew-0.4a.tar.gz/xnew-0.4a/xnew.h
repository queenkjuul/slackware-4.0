#ifndef _XNEW_H
#define _XNEW_H

/* File   : xnew.h                                                          */
/* Purpose: Definitions and include files needed by the xnew program.       */

#include "list_func.h"  /* data_node */

/* Global variables */
char *tmp_file;
data_node result_list;
int line;

#endif  /* _XNEW_H */
