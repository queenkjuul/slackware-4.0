#ifndef _GET_KILL_H
#define _GET_KILL_H

/* File   : get_kill.h                                                    */
/* Purpose: Definitions for get_kill.c.                                   */

/* Process by which a control key is made.  Do not change unless you know */
/* you are doing.  (This should be read from a system header file.)       */
#define CTRL(ch) ((ch) & 0x1f)

/* Default kill key.  If you do not want this feature, delete the preceeding */
/* /* from the line that reads "/* #undef DEF_KILL"                          */
#define DEF_KILL CTRL('u')
/* #undef DEF_KILL /* */

/* File that is printed when help is requested.  If you do not want this */
/* feature, remove the preceeding /* from the line that reads            */
/* "/* #undef KILL_HELP"                                                 */
#define KILL_HELP "/usr/noton/xnew/text/kill_help.txt"
/* #undef KILL_HELP /* */

#endif  /* _GET_KILL_H */
