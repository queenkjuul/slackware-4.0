#ifndef _CONFIG_FUNC_H
#define _CONFIG_FUNC_H

/* File   : config_func.h                                                   */
/* Purpose: Definitions for config_func.c.                                  */


/* Data definitions */
struct config_node_t {
  char *name;
  char *value;
  struct config_list *next;
};  typedef struct config_node_t *config_node;

#endif  /* _CONFIG_FUNC_H */
