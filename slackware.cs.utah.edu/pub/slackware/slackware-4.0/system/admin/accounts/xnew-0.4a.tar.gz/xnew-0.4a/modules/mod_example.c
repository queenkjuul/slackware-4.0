/* File   : mod_example.c
 * Author : Karyl F. Stein
 * Purpose: This is an example module that can be used as a skeleton to write
 *          your own modules with.
 */

#include <stdio.h>

main(int argc, char *argv[]) {
  FILE *pipe_fp;

  /* Make sure we got at least one argument (the pipe to write to) */
  if (argc <= 1)
    exit(1);

  /* Open the pipe for writing */
  if ((pipe_fp = fopen(argv[1], "w")) == NULL) {
    fprintf(stderr, "Error: Child %s unable to access pipe\n", argv[0]);
    exit(1);
  }

  /* Do all of your processing here */

  /* Write the return data to the pipe.  For example: */
  /* fprintf(pipe_fp, "<return_data>");               */

  /* Close the pipe */
  fclose(pipe_fp);
}
