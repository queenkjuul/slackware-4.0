#ifndef _STACK_H
#define _STACK_H

/* File   : stack_func.h                                                    */
/* Purpose: Definitions and include files needed by stack_func.c.           */


/* Data types */
struct stack_node_t {
  fpos_t position;
  int line;
  struct stack_node_t *next;
};  typedef struct stack_node_t *stack_node;


/* Function prototypes */
stack_node pop(stack_node);
stack_node push(fpos_t, int, stack_node);

#endif  /* _STACK_H */
