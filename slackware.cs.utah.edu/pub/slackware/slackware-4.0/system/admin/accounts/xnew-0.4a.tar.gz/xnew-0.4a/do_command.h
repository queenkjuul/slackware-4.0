#ifndef _DO_COMMAND_H
#define _DO_COMMAND_H

/* File   : do_command.h                                                     */
/* Purpose: Definitions and include files needed by do_command.c.            */


/* Flag Definitions */
#define SYSTEM 0x01
#define EXEC   0x02
#define MODULE 0x04
#define SET    0x08


/* Function Prototypes */
char *create_command_name(char *);
char *create_tmp_file(void);
char *do_command(char *, char **);
char *strip_path(char *);
char **create_argument_list(char *[], int);

int arg_count(char *[]);
int command_type(char *);

#endif  /* _DO_COMMAND_H */
