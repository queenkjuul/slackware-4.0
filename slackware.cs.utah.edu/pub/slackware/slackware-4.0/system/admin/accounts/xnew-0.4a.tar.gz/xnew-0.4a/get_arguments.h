#ifndef _GET_ARGUMENTS_H
#define _GET_ARGUMENTS_H

/* File   : get_arguments.h                                                  */
/* Purpose: Definitions and include files needed by get_arguments.c.         */


/* Function Prototypes */
char *read_arguments(FILE *);
char **get_arguments(FILE *);

int count_arg(char *);

#endif  /* _GET_ARGUMENTS_H */
