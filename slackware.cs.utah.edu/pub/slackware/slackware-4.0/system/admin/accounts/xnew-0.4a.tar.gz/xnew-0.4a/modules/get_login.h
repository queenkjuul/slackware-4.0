#ifndef _GET_LOGIN_H
#define _GET_LOGIN_H

/* File   : get_login.h                                                     */
/* Purpose: Definitions for get_login.c.                                    */

/* Maximum length a login name can be.  The default is 8 characters.        */
#define MAXLOGINLEN 8

/* An alias file to search for the login to see if it exists as a mail      */
/* alias.  The alias file must have the login names to search for as the    */
/* first element on a line.  A trailing : character is ignored.  If you     */
/* do not have an alias file, remove the preceeding /* from the line that   */
/* reads "/* #undef ALIASFILE".                                             */
#define ALIASFILE "/etc/aliases"
/* #undef ALIASFILE /* */

/* Name of the help file to print.  If you do not want this feature, remove */
/* the preceeding /* on the line that reads "/* #undef LOGIN_HELP".         */
#define LOGIN_HELP "/usr/noton/xnew/text/login_help.txt"
/* #undef LOGIN_HELP /* */

#endif  /* _GET_LOGIN_H */
