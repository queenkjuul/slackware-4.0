#ifndef _GET_NAME_H
#define _GET_NAME_H

/* File   : get_name.h                                                     */
/* Purpose: Definitions for get_name.c.                                    */

/* Maximum length a name can be.  Default is 30.                           */
#define MAXNAMELEN 30

/* Name of help file.  If you do not want this feature, remove the         */
/* preceeding /* on the line that reads "/* #undef NAME_HELP"              */
#define NAME_HELP "/usr/noton/xnew/text/name_help.txt"
/* #undef NAME_HELP /* */

/* Name of the file containing that "invalid name" message.  If you do not */
/* want this feature, remove the preceeding /* on the line that reads      */
/* "/* #undef INVALID_NAME"                                                */
#define INVALID_NAME "/usr/noton/xnew/text/name_invalid.txt"
/* #undef INVALID_NAME /* */

#endif  /* _GET_NAME_H  */
