#ifndef _XNEW_FUNC_H
#define _XNEW_FUNC_H

/* File   : xnew_func.h                                                     */
/* Purpose: Definitions and include files needed by xnew_func.c.            */

#include <stdio.h>  /* FILE * */


/* Flag Values */
#define COMMENTS 0x01
#define SPACE    0x02
#define TO_EOL   0x04
#define WHITE    0x08


/* Function Prototypes */
char *get_command(FILE *);

int count_arg(char *);
int test_bool(char *[]);

void bind_result(char *, char *);
void signal_handler(int);
void skip(FILE *, int);
void skip_line(FILE *, int);

#endif  /* _XNEW_FUNC_H */
