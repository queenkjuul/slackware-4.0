#ifndef _GET_BACKSPACE_H
#define _GET_BACKSPACE_H

/* File   : get_backspace.h                                              */
/* Purpose: Definitions for get_backspace.c.                             */


/* File that is printed when help is requested.  If you do not want this */
/* feature, remove the preceeding /* on the line that reads              */
/* "/* #undef BS_HELP".                                                  */
#define BS_HELP "/usr/noton/xnew/text/backspace_help.txt"
/* #undef BS_HELP /* */

#endif  /* _GET_BACKSPACE_H */
