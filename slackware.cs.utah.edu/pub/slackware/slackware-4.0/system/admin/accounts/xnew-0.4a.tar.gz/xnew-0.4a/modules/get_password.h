#ifndef _GET_PASSWORD_H
#define _GET_PASSWORD_H

/* File   : get_password.h                                                 */
/* Purpose: Definitions for get_password.c.                                */

/* Maximum length a password can be.  The default is 8 characters.         */
#define MAXPASSLEN 8

/* Minimum length a password can be.  The default is 4 characters.         */
#define MINPASSLEN 5

/* Help file to print if requested.  If you do not want this feature,      */
/* remove the preceeding /* on the line that reads "/* #undef PASSWD_HELP" */
#define PASSWD_HELP "/usr/noton/xnew/text/password_help.txt"
/* #undef PASSWD_HELP /* */

#endif  /* _GET_PASSWORD_H */
