#ifndef _LIST_FUNC_H
#define _LIST_FUNC_H

/* File   : list_func.h                                                      */
/* Purpose: Definitions and include files needed by list_func.c.             */


/* Data type */
struct data_node_t {
  char *command;
  char *result;
  struct data_node_t *next;
};  typedef struct data_node_t *data_node;


/* Function Prototypes */
char *get_result(char *);
data_node search_list(char *);

#endif  /* _LIST_FUNC_H */
