/**********************************************************************

	--- Dlgedit generated file ---

	File: DefShadow.cpp
	Last generated: Tue Jul 8 07:22:16 1997

 *********************************************************************/

#include "DefShadow.h"
#include "DefShadow.moc"
#include "DefShadowData.moc"
#include "DefQuota.moc"
#include "DefQuotaData.moc"

#define Inherited DefShadowData

QString date(time_t);
time_t date(QString);


DefShadow::DefShadow(QWidget* parent, const char* name) : Inherited(parent, name)
{	QString str;

	mode=expire_mode;
	expire=def_expire;
	fixed=def_fixed;
	change=def_change;
	warn=def_warn;
	inact=def_inact;
	today=time(0)/86400;
	
	
	if(mode==0)
	{	str.setNum(expire);
		le_expire->setText(str);
		rb_period->setChecked(TRUE);
	}
	else
	{	le_expire->setText(date(expire+today));
		rb_date->setChecked(TRUE);
	}
	le_fixed->setText(str.setNum(fixed));
	le_change->setText(str.setNum(change));
	le_warn->setText(str.setNum(warn));
	le_inact->setText(str.setNum(inact));
}


DefShadow::~DefShadow()
{
}

void DefShadow::set_defaults()
{	QString str;
	bool err;
	time_t t;
	
	str=le_expire->text();
	if((t=date(str)))
	{	if(t>today) def_expire=t-today;
	}
	else
	{	t=str.toInt(&err);
		if(err) def_expire=t;
	}

	str=le_fixed->text();
	t=str.toInt(&err);
	if(err) def_fixed=t;
	
	str=le_change->text();
	t=str.toInt(&err);
	if(err) def_change=t;
	
	str=le_warn->text();
	t=str.toInt(&err);
	if(err) def_warn=t;
	
	str=le_inact->text();
	t=str.toInt(&err);
	if(err) def_inact=t;

	expire_mode=mode;
}


// slots


void DefShadow::exp_mode(int id)
{	QString str;
	bool err;
	time_t t;
	
	str=le_expire->text();
	if((t=date(str)))
	{	if(t>today) expire=t-today;
	}
	else
	{	t=str.toInt(&err);
		if(err) expire=t;
	}
	
	switch(id)
	{  case 0:	le_expire->setText(date(today+expire));
			mode=1;
			break;
	   case 1:	le_expire->setText(str.setNum(expire));
	   		mode=0;
	}
	
}
