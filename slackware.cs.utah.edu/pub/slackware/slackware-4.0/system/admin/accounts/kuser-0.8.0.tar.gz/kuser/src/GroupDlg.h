/**********************************************************************

	--- Qt Architect generated file ---

	File: GroupDlg.h
	Last generated: Sun May 24 08:42:54 1998

 *********************************************************************/

#ifndef GroupDlg_included
#define GroupDlg_included

#include "misc.h"
#include "GroupDlgData.h"
#include "UserData.h"
#include "PwdDlg.h"


class GroupDlg : public GroupDlgData
{
    	Q_OBJECT

public:

    	GroupDlg(QWidget* parent=0, const char* name=0);
    	virtual ~GroupDlg();

private:

	void init_cb_group();
	void members();
	void admins();
	int check();
	
	int mode;		// 0 -> members
					// 1 -> admins
	Group *cgrp;	// current group

protected slots:
	
	void onnew();
	void onok();
	void oncancel();
	void ondelete();
	void onpasswd();
	void onmode(int);
	void selectgroup(int id);
	void onadd();
	void onremove();
	void onclose();
};
#endif // GroupDlg_included

