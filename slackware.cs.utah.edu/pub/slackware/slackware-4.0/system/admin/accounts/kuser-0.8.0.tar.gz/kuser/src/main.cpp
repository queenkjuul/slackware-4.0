#include "main.h"


int main(int argc, char **argv)
{	ka=new KApplication(argc, argv, "kuser");
	
	//ka->setStyle(WindowsStyle);
	if(getuid())
	{	QMessageBox::warning(0, 0, "Only root allowed manage users.");
		exit(1);
	}
	
	kc=ka->getConfig();
	getdefaults();
	if(isquota)
	{	if(getquotadevice()) isquota=0;
	}
	
	Toplevel top;
	if(ka->isRestored())
	{	if(KTopLevelWidget::canBeRestored(1)) top.restore(1);
        }
	ka->setMainWidget(&top);
	top.setCaption("kuser   "KU_VERSION);
	top.show();

	return ka->exec();
}
