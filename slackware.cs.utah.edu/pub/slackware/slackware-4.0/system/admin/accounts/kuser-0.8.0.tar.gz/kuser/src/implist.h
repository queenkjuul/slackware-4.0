#ifndef inclist_included
#define inclist_included


#include "UserData.h"
#include <ctype.h>
#include <time.h>
#include <qfile.h>
#include <qtextstream.h> 
#include <qstring.h>
#include <qmsgbox.h>
#include <qregexp.h>



int implist(const char *);
int getformat(char [20][2]);
int getentry();
int putentry(QTextStream *);
int mkuname(QString *);
int getmode(QString);

#endif	// inclist_included