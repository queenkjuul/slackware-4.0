/**********************************************************************

	--- Dlgedit generated file ---

	File: DefMisc.cpp
	Last generated: Tue Aug 19 22:19:12 1997

 *********************************************************************/

#include "DefMisc.h"
#include "DefMisc.moc"
#include "DefMiscData.moc"

#define Inherited DefMiscData



DefMisc::DefMisc(QWidget* parent, const char* name) : Inherited(parent, name)
{	
	mode=createmode;
	setmode();
	le_home->setText(home=def_home);
	le_mail->setText(mail=def_mail);
	le_skel->setText(skel=def_skel);
	le_shell->setText(shell=def_shell);
	le_createscript->setText(createscript=def_createscript);
	le_deletescript->setText(deletescript=def_deletescript);
	le_ypcmd->setText(ypcmd=def_ypcmd);
	
	le_ypcmd->setEnabled((isyp==1));
	cb_delhome->setChecked(delhome==1);
	cb_delmail->setChecked(delmail==1);
}


DefMisc::~DefMisc()
{
}

void DefMisc::set_defaults()
{	def_home=le_home->text();
	def_mail=le_mail->text();
	def_skel=le_skel->text();
	def_shell=le_shell->text();
	def_createscript=le_createscript->text();
	def_deletescript=le_deletescript->text();
	def_ypcmd=le_ypcmd->text();
	createmode=mode;
	delhome=cb_delhome->isChecked()? 1: 0;
	delmail=cb_delmail->isChecked()? 1: 0;
}

void DefMisc::setmode()
{	char s[4];

	cb_m11->setText((mode&256)? "r": "-");
	cb_m12->setText((mode&128)? "w": "-");
	cb_m13->setText((mode&64)?  "x": "-");
	cb_m21->setText((mode&32)?  "r": "-");
	cb_m22->setText((mode&16)?  "w": "-");
	cb_m23->setText((mode&8)?   "x": "-");
	cb_m31->setText((mode&4)?   "r": "-");
	cb_m32->setText((mode&2)?   "w": "-");
	cb_m33->setText((mode&1)?   "x": "-");
	sprintf(s, "%03o", mode);
	lb_mode->setText(s);
}


// Slots

void DefMisc::onm11()
{	mode^=256;
	setmode();
}

void DefMisc::onm12()
{	mode^=128;
	setmode();
}

void DefMisc::onm13()
{	mode^=64;
	setmode();
}

void DefMisc::onm21()
{	mode^=32;
	setmode();
}

void DefMisc::onm22()
{	mode^=16;
	setmode();
}

void DefMisc::onm23()
{	mode^=8;
	setmode();
}

void DefMisc::onm31()
{	mode^=4;
	setmode();
}

void DefMisc::onm32()
{	mode^=2;
	setmode();
}

void DefMisc::onm33()
{	mode^=1;
	setmode();
}
