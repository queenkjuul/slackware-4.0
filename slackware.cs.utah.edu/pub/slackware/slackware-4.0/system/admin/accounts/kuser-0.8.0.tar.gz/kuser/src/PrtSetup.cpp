/**********************************************************************

	--- Qt Architect generated file ---

	File: PrtSetup.cpp
	Last generated: Sat Jul 11 17:46:28 1998

 *********************************************************************/

#include "PrtSetup.h"
#include "PrtSetup.moc"
#include "PrtSetupData.moc"

#define Inherited PrtSetupData


PrtSetup::PrtSetup(QWidget* parent, const char* name) : Inherited(parent, name)
{	setCaption("Printer Setup");
	le_name->setText(printername);
	le_command->setText(printcommand);
}


PrtSetup::~PrtSetup()
{
}


// Slots

void PrtSetup::onok()
{	printername=le_name->text();
	printcommand=le_command->text();
	done(0);
}

void PrtSetup::oncancel()
{	done(1);
}
