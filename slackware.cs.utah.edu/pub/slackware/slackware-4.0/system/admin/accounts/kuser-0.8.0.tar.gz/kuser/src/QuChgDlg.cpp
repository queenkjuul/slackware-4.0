/**********************************************************************

	--- Qt Architect generated file ---

	File: QuChgDlg.cpp
	Last generated: Mon Feb 16 21:58:32 1998

 *********************************************************************/

#include "QuChgDlg.h"
#include "QuChgDlg.moc"
#include "QuChgDlgData.moc"


#define Inherited QuChgDlgData

QuChgDlg::QuChgDlg(QWidget* parent, const char* name) :	Inherited(parent, name)
{	setCaption("Change Quota-Entries");

	cb_fsoft->setChecked(FALSE);
	cb_fhard->setChecked(FALSE);
	cb_isoft->setChecked(FALSE);
	cb_ihard->setChecked(FALSE);
	
	onfsoft(FALSE);
	onfhard(FALSE);
	onisoft(FALSE);
	onihard(FALSE);
	
	le_fsoft->setText(QString().setNum(def_fsoft));
	le_fhard->setText(QString().setNum(def_fhard));
	le_isoft->setText(QString().setNum(def_isoft));
	le_ihard->setText(QString().setNum(def_ihard));
}

QuChgDlg::~QuChgDlg()
{
}


// Slots

void QuChgDlg::onset()
{	for(int i=0; i<tbl->numRows(); ++i)
	{	if(tbl->isSelected(i))
		{	quotadata *qd;
			
			u_liste.at((int)u_index.at(i));
			u_liste.getquota(&qd);
			if(cb_fsoft->isChecked()) qd->fsoft=QString(le_fsoft->text()).toLong();
			if(cb_fhard->isChecked()) qd->fhard=QString(le_fhard->text()).toLong();
			if(cb_isoft->isChecked()) qd->isoft=QString(le_isoft->text()).toLong();
			if(cb_ihard->isChecked()) qd->ihard=QString(le_ihard->text()).toLong();
		}
	}
	
	done(0);
}

void QuChgDlg::oncancel()
{	done(1);
}

void QuChgDlg::onfsoft(bool on)
{	le_fsoft->setEnabled(on);
}

void QuChgDlg::onfhard(bool on)
{	le_fhard->setEnabled(on);
}

void QuChgDlg::onisoft(bool on)
{	le_isoft->setEnabled(on);
}

void QuChgDlg::onihard(bool on)
{	le_ihard->setEnabled(on);
}

