/**********************************************************************

	--- Qt Architect generated file ---

	File: GroupDlg.cpp
	Last generated: Sun May 24 08:42:54 1998

 *********************************************************************/

#include "GroupDlg.h"
#include "GroupDlg.moc"
#include "GroupDlgData.moc"


#define Inherited GroupDlgData


GroupDlg::GroupDlg(QWidget* parent, const char* name) :	Inherited(parent, name)
{	char gname[40];

	setCaption("Group Editor");
	mode=0;
	cb_group->clear();
	lb_user->clear();
	for(uint ix=0; ix<g_liste.count(); ++ix)
	{	int gid=g_liste.gid(ix);
		sprintf(gname, "%-15s%d", (const char *)g_liste.name(ix), gid);
		cb_group->insertItem(gname);
	}
	cgrp=g_liste.at(0);
	members();
	admins();
	for(uint ix=0; ix<u_index.count(); ++ix)
	{	u_liste.at((int)u_index.at(ix));
		lb_user->insertItem(u_liste.name());
	}
}


GroupDlg::~GroupDlg()
{
}

void GroupDlg::init_cb_group()
{	char gname[40];

	cb_group->clear();
	for(uint ix=0; ix<g_liste.count(); ++ix)
	{	int gid=g_liste.gid(ix);
		sprintf(gname, "%-15s%d", (const char *)g_liste.name(ix), gid);
		cb_group->insertItem(gname);
	}
}

void GroupDlg::members()
{	lb_members->clear();
	lb_members->insertStrList(&cgrp->members);
}

void GroupDlg::admins()
{	lb_admins->clear();
	lb_admins->insertStrList(&cgrp->admins);
}

int GroupDlg::check()
{	if(*le_group->text()==0) return 1;					// no group
	if(g_liste.getgroup(cgrp->g_name)!=0) return 2;		// group exists	
	if(*le_gid->text()==0) return 3;					// no gid
	if(g_liste.getid(cgrp->g_gid)>=0) return 4;			// gid exists
	
	return 0;
}


// Slots

void GroupDlg::selectgroup(int id)
{	cgrp=g_liste.at(id);
	members();
	admins();
}

void GroupDlg::onadd()
{	char f;
	const char *t;
	uint i, j;
	QListBox *lbptr;
	
	lbptr=(mode==0)? lb_members: lb_admins;
	for(i=0; i<lb_user->count(); ++i)
	{	if(lb_user->isSelected(i))
		{	t=lb_user->text(i);
			for(f=1, j=0; j<lbptr->count(); ++j)
			{	if(strcmp(t, lbptr->text(j))==0) {f=0; break;}
			}
			if(f)
			{	lbptr->insertItem(lb_user->text(i));
				if(mode==0) cgrp->members.append(lb_user->text(i));
				else cgrp->admins.append(lb_user->text(i));
			}
		}
	}
}

void GroupDlg::onremove()
{	uint i;
	QListBox *lbptr;
	
	lbptr=(mode==0)? lb_members: lb_admins;
	if((i=lbptr->count())>0)
	{	do
		{	--i;
			if(lbptr->isSelected(i))
			{	if(mode==0) cgrp->members.remove(i);
				else cgrp->admins.remove(i);
			}
		}
		while(i>0);
		if(mode==0) members(); else admins();
	}
}

void GroupDlg::onclose()
{	done(1);
}

void GroupDlg::onmode(int m)
{	mode=m;
	if(mode==0)
	{	lb_header->setText("Members:");
		lb_admins->hide();
		lb_members->show();
	}
	else
	{	lb_header->setText("Admins:");
		lb_members->hide();
		lb_admins->show();
	}
}

void GroupDlg::onnew()
{	QString str;
	char line[]="*:*:0:\n";
	
	cgrp=(Group *)new Group(line);
	bt_new->hide();
	bt_delete->hide();
	cb_group->hide();
	
	le_group->setText("");
	le_group->setFocus();
	le_gid->setText(str.setNum(g_liste.getfreegid()));
	lb_members->clear();
	lb_members->update();
	lb_admins->clear();
	
}

void GroupDlg::onok()
{	int id;

	cgrp->g_name=le_group->text();
	cgrp->g_gid=QString(le_gid->text()).toUInt();
	switch(check())
	{  case 1:	QMessageBox::warning(0, 0, "No Group !");
				return;
	   case 2:	QMessageBox::warning(0, 0, "Group "+QString(le_group->text())+" exists !");
				return;
	   case 3:	QMessageBox::warning(0, 0, "No Group-id !");
				return;
	   case 4:	QMessageBox::warning(0, 0, "Group-id exists !");
				return;	
	}
	
	
	g_liste.append(cgrp);
	g_liste.sort();
	init_cb_group();
	cb_group->setCurrentItem(id=g_liste.getid(cgrp->g_gid));
	selectgroup(id);
	
	bt_new->show();
	bt_delete->show();
	cb_group->show();
}

void GroupDlg::oncancel()
{	bt_new->show();
	bt_delete->show();
	cb_group->show();
	delete cgrp;
	selectgroup(cb_group->currentItem());
}

void GroupDlg::ondelete()
{	char f;
	int id, m;

	m=QMessageBox::warning(0, 0, "Delete Group: "+cgrp->g_name+"  ?",
				"Yes", "No", 0, 1, 1);
	if(m==1) return;					// cancel
	
	for(uint i=f=0; i<u_liste.count(); ++i)
		if(u_liste.gid(i)==g_liste.gid()) {f=1; break;}
	if(f)
	{	QMessageBox::critical(0, 0, "Group "+cgrp->g_name+" is not empty !",
				      "Abort");
		return;
	}
	
	id=cb_group->currentItem();
	cb_group->removeItem(id);
	g_liste.remove();
	cb_group->setCurrentItem(0);
	selectgroup(0);
}

void GroupDlg::onpasswd()
{	PwdDlg pwd;

	passwd="n";
	pwd.exec();
	
	if(passwd=="") cgrp->g_passwd="*";
	else if(passwd!="n") g_liste.setpasswd(passwd);
}
