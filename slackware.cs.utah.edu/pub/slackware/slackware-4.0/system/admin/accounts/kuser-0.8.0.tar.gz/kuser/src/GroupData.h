#ifndef GroupData_included
#define GroupData_included

#include "misc.h"
#include <stdlib.h>
#include <sys/stat.h>
#include <shadow.h>
#include <unistd.h>
#include <qfile.h>
#include <qtstream.h>
#include <qlist.h>
#include <qstring.h>
#include <qstrlist.h>
#include <qmsgbox.h>
#include <qarray.h>


#define GROUP_FILE "/etc/group"
#define GROUP_FILE_MASK S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH
#define GSHADOW_FILE "/etc/gshadow"
#define GSHADOW_FILE_MASK S_IRUSR

//extern "C" char const *pw_encrypt();


class Group
{
public:
	
	Group(char *line);
	
	QString g_name,
		g_passwd;
	uint g_gid;
	QStrList members,
		 admins;
};

class GroupListe : public QList <Group>
{
public:
	
	GroupListe();
	~GroupListe();
	
	int read();
	int write();
	void sort();
	Group * getgroup(QString str);
	QString name(int id) {return at(id)->g_name;}
	QString name() {return current()->g_name;}
	QString gidToName(uint);
	uint gid(int id) {return at(id)->g_gid;}
	uint gid() {return current()->g_gid;}
	int getid(uint);
	int getid100() {return gid100;}
	uint getfreegid();
	//QString uidToName(uint);
	//void setpasswd(QString str) {current()->g_passwd=pw_encrypt((const char *)str, 0);}
	void setpasswd(QString str) {current()->g_passwd=crypt((const char *)str, salt());}
	void deluser(QString str);
	

private:
	
	void gsdw_read();	// /etc/gshadow einlesen
	void gsdw_write();	// /etc/gshadow schreiben
	
	
	int gid100;
	
};


extern GroupListe g_liste;


#endif	// GroupData_include
