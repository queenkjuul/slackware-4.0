/**********************************************************************

	--- Qt Architect generated file ---

	File: QuChgDlg.h
	Last generated: Mon Feb 16 21:58:32 1998

 *********************************************************************/

#ifndef QuChgDlg_included
#define QuChgDlg_included

#include "QuChgDlgData.h"
#include "UserData.h"
#include "htable.h"
#include "misc.h"


class QuChgDlg : public QuChgDlgData
{
    	Q_OBJECT

public:

    	QuChgDlg(QWidget* parent=NULL, const char* name=NULL);
	virtual ~QuChgDlg();


	HTable *tbl;
	

protected slots:
	
	void onset();
	void oncancel();
	void onfsoft(bool);
	void onfhard(bool);
	void onisoft(bool);
	void onihard(bool);
	
};
#endif // QuChgDlg_included
