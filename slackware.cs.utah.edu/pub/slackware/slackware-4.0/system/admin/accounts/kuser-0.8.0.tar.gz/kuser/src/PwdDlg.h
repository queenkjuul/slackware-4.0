/**********************************************************************

	--- Dlgedit generated file ---

	File: PwdDlg.h
	Last generated: Thu Jun 26 11:41:50 1997

 *********************************************************************/

#ifndef PwdDlg_included
#define PwdDlg_included

#include "misc.h"
#include "PwdDlgData.h"


class PwdDlg : public PwdDlgData
{
    Q_OBJECT

public:

    	PwdDlg(QWidget* parent = NULL, const char* name = NULL);
	virtual ~PwdDlg();

	QString pwd;

	
protected slots:
  	void set_pwd();

};
#endif // PwdDlg_included

