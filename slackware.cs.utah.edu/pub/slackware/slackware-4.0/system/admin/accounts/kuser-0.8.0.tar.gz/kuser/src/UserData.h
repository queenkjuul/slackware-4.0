#ifndef UserData_included
#define UserData_included


#include "misc.h"
#include "GroupData.h"
#include <stdlib.h>
#include <sys/stat.h>
#include <shadow.h>
#include <unistd.h>
#include <linux/quota.h>

#include <qfile.h>
#include <qtstream.h>
#include <qlist.h>
#include <qstring.h>
#include <qmsgbox.h>


#define PASSWORD_FILE "/etc/passwd"
#define PASSWORD_FILE_MASK S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH
#define SHADOW_FILE "/etc/shadow"
#define SHADOW_FILE_MASK S_IRUSR
#define QUOTA_FILE "/home/quota.user"

//extern "C" char const *pw_encrypt();


typedef struct
{	long int fcur,
		 	 fsoft,
   	  	 	 fhard,
   		 	 icur,
    	 	 isoft,
    	 	 ihard;
    time_t   fgrace,
    		 igrace;
} quotadata;



class User
{
public:
	
	User(char *);
	User(QString, uint);
	~User();

	QString u_name,
			u_passwd,
			u_dir,
			u_shell,
			u_cname,
			u_cext1,
			u_cext2,
			u_cext3,
			u_shadow;
	
	time_t	u_lstchg,
			u_min,
			u_max,
			u_warn,
			u_inact,
			u_expire;
	
	uint	u_uid,
			u_gid;

// Quota

	quotadata qudta;
	
};


class UserListe : public QList <User>
{
public:
	UserListe();
	~UserListe();
	int read();
	int write();
	void deluser();
	void sort(int mode, bool up=TRUE);
	void buildIndex();			// build Indexlist u_index
	void getquota(quotadata **qdptr) {*qdptr=&current()->qudta;}
	User * getuser(QString str);
	int uidToId(uint ui);
	
	QString name(int id) {return at(id)->u_name;}
	QString name() {return current()->u_name;}
	QString passwd() {return current()->u_passwd;}
	uint uid(int id) {return at(id)->u_uid;}
	uint uid() {return current()->u_uid;}
	uint gid(int id) {return at(id)->u_gid;}
	uint gid() {return current()->u_gid;}
	QString dir() {return current()->u_dir;}
	QString shell() {return current()->u_shell;}
	QString cname(int id) {return at(id)->u_cname;}
	QString cname() {return current()->u_cname;}
	QString cext1() {return current()->u_cext1;}
	QString cext2() {return current()->u_cext2;}
	QString cext3() {return current()->u_cext3;}
	time_t lstchg() {return current()->u_lstchg;}
	time_t expire(int id) {return at(id)->u_expire;}
	time_t expire() {return current()->u_expire;}
	time_t min() {return current()->u_min;}
	time_t max() {return current()->u_max;}
	time_t warn() {return current()->u_warn;}
	time_t inact() {return current()->u_inact;}
	uint getfreeuid();
	
	//void setpasswd(QString str) {current()->u_passwd=pw_encrypt((const char *)str, "AB");}
	void setpasswd(QString str) {current()->u_passwd=crypt((const char *)str, salt());}
	void setgid(uint id) {current()->u_gid=id;}
	void setdir(QString str) {current()->u_dir=str;}
	void setshell(QString str) {current()->u_shell=str;}
	void setcname(QString str) {current()->u_cname=str;}
	void setcext1(QString str) {current()->u_cext1=str;}
	void setcext2(QString str) {current()->u_cext2=str;}
	void setcext3(QString str) {current()->u_cext3=str;}
	void setlstchg(time_t t) {current()->u_lstchg=t;}
	void setexpire(time_t t) {current()->u_expire=t;}
	void setmin(time_t t) {current()->u_min=t;}
	void setmax(time_t t) {current()->u_max=t;}
	void setwarn(time_t t) {current()->u_warn=t;}
	void setinact(time_t t) {current()->u_inact=t;}
	
	
private:
	
	void sdw_read();	// /etc/shadow einlesen
	void sdw_write();	// /etc/shadow schreiben
	void quota_read();	// Quota lesen
	void quota_write();	// Quota schreiben
};


extern UserListe u_liste;
extern QList <int> u_index;

#endif	// UserData_include
