#include "toplevel.h"
#include "toplevel.moc"



Toplevel::Toplevel(const char* name) : KTopLevelWidget(name)
{	mdlg=new MainDlg(this);
	QPixmap pixmap;
	KIconLoader *loader = ka->getIconLoader();
	
	pixmap=loader->loadIcon("kuser.xpm");
	setIcon(pixmap);
	setIconText("kuser");
	
	if(isquota) mdlg->setFixedSize(QSize(640, 310));
	else mdlg->setFixedSize(QSize(455, 310));
	setView(mdlg);
	setupMenu();
	setupToolBar();
	setupStatusBar();
	mdlg->load();
}

Toplevel::~Toplevel()
{	if(ischanged==1)
	{	int m;
	
		m=QMessageBox::warning(0, 0, "Database has changed - save before exit ?",
				       "Yes", "No", 0, 1, 1);
		if(m==0) save();
	}

	delete mdlg;
	delete stbar;
}

void Toplevel::setupMenu()
{	KMenuBar *menu = new KMenuBar(this);
	QPopupMenu *file = new QPopupMenu();
	
	file->insertItem("Reload Database", this, SLOT(reload()), CTRL+Key_R);
	file->insertItem("Save Database", this, SLOT(save()), CTRL+Key_S);
	file->insertItem("Update NIS", this, SLOT(ypupdate()), CTRL+Key_Y);
	file->insertSeparator();
	file->insertItem("Import List", this, SLOT(import()), CTRL+Key_L);
	file->insertSeparator();
	file->insertItem("Print", this, SLOT(print()), CTRL+Key_P);
	file->insertItem("Printer Setup...", this, SLOT(prtsetup()));
	file->insertSeparator();
	file->insertItem("Exit", this, SLOT(quit()), CTRL+Key_Q);
	
	QPopupMenu *edit = new QPopupMenu();
	edit->insertItem("New User", this, SLOT(newuser()));
	edit->insertItem("Delete User", this, SLOT(deluser()));
	edit->insertItem("Set Password", this, SLOT(passwd()));
	edit->insertSeparator();
	edit->insertItem("Set Changes", this, SLOT(setchanges()));
	edit->insertItem("Discard Changes", this, SLOT(discardchanges()));
	edit->insertSeparator();
	edit->insertItem("Group Editor...", this, SLOT(grouped()));
	edit->insertItem("List Editor...", this, SLOT(chglist()));	
	
	options = new QPopupMenu();
	options->insertItem("View...", this, SLOT(viewdlg()));
	options->insertSeparator();
	quotaID=options->insertItem("Quota-Support", this, SLOT(quotasupport()));
	options->setCheckable(TRUE);
	options->setItemChecked(quotaID, (isquota==1));
	nisID=options->insertItem("Yellow Pages", this, SLOT(nissupport()));
	options->setCheckable(TRUE);
	options->setItemChecked(nisID, (isyp==1));
	options->insertSeparator();
	options->insertItem("Defaults...", this, SLOT(defaults()));
	
	menu->insertItem("&File", file);
	menu->insertItem("&Edit", edit);
	menu->insertItem("&Options", options);
	menu->insertSeparator();
	menu->insertItem("&Help", ka->getHelpMenu(TRUE,
					 "kuser Version "KU_VERSION"\n\n"\
					 "Copyright 1998\nKlaus-Dieter M�ller\n\n"\
					 "kdm@coppernicus.se.sh.schule.de\n"));
	
	setMenu(menu);
	menu->show();
}

void Toplevel::setupToolBar()
{	KToolBar *toolbar = new KToolBar( this );
	QPixmap pixmap;
	KIconLoader *loader = ka->getIconLoader();

	pixmap=loader->loadIcon("fileopen.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
	 	SLOT(reload()), TRUE, "Reload Database");

	pixmap=loader->loadIcon("filefloppy.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
		SLOT(save()), TRUE, "Save Database");

	pixmap=loader->loadIcon("fileprint.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
		SLOT(print()), TRUE, "Print List of Users");

	pixmap=loader->loadIcon("yp.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
	 	SLOT(ypupdate()), TRUE, "Update NIS-Database");
	
	toolbar->insertSeparator();

	pixmap=loader->loadIcon("user.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
	 	SLOT(newuser()), TRUE, "New User");

	pixmap=loader->loadIcon("del_user.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
	 	SLOT(deluser()), TRUE, "Delete User");

	pixmap=loader->loadIcon("pwd_user.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
		SLOT(passwd()), TRUE, "Set Password");
	
	pixmap=loader->loadIcon("discard.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
		SLOT(discardchanges()), TRUE, "Discard Changes");

	pixmap=loader->loadIcon("set.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
		SLOT(setchanges()), TRUE, "Set Changes");
	
	toolbar->insertSeparator();

	pixmap=loader->loadIcon("list.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
		SLOT(chglist()), TRUE, "List Editor");
		
	pixmap=loader->loadIcon("group.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
		SLOT(grouped()), TRUE, "Group Editor");
	
	toolbar->insertSeparator();
	
	pixmap=loader->loadIcon("help.xpm");
	toolbar->insertButton(pixmap, 0,
		SIGNAL(clicked()), this,
	 	SLOT(help()), TRUE, "Help");

	toolbar->setBarPos(KToolBar::Top);
	int t1=addToolBar(toolbar);
	enableToolBar( KToolBar::Show, t1);
	//toolbar->show();
}

void Toplevel::setupStatusBar()
{	mdlg->stbar=stbar=new KStatusBar(this);
	setStatusBar(stbar);
	stbar->insertItem(" ", 1);
	stbar->enable(stbar->Show);
}


// Slots

void Toplevel::save()
{	u_liste.write();
	g_liste.write();
	ypupdate();
	
	kc->setGroup("Misc");
	kc->writeEntry("yp", (isyp)? "yes": "no");
	kc->writeEntry("quota", (isquota)? "yes": "no");
	kc->sync();
	ischanged=0;
}

void Toplevel::bt_save()
{	m_def->set_defaults();
	s_def->set_defaults();
	if(isquota) q_def->set_defaults();
	
	putdefaults();
}

void Toplevel::reload()
{	mdlg->reload();
}

void Toplevel::print()
{	QPrinter prt;

	prt.setOrientation(QPrinter::Landscape);
	prt.setPageSize(QPrinter::A4);
	prt.setCreator("kuser");
	prt.setPrinterName(printername);
	prt.setPrintProgram(printcommand);
	mdlg->print(&prt);
}

void Toplevel::prtsetup()
{	PrtSetup setup;

	if(setup.exec()) return;		// cancel
	
	kc->setGroup("Printer");
	kc->writeEntry("printername", printername);
	kc->writeEntry("printcommand", printcommand);
	kc->sync();
}

void Toplevel::setchanges()
{	mdlg->setchanges();
}

void Toplevel::discardchanges()
{	mdlg->discardchanges();
}

void Toplevel::grouped()
{	mdlg->grouped();
}

void Toplevel::chglist()
{	mdlg->chglist();
}

void Toplevel::newuser()
{	mdlg->newuser();
}

void Toplevel::deluser()
{	mdlg->deluser();
}

void Toplevel::viewdlg()
{	mdlg->viewdlg();
}

void Toplevel::defaults()
{	QTabDialog *tab=new QTabDialog();
	m_def=new DefMisc(tab);
	s_def=new DefShadow(tab);
	tab->setCaption("Default Settings");
	tab->setFixedSize(QSize(450, 400));
	tab->addTab(m_def, "Misc");
	tab->addTab(s_def, "Password");
	if(isquota)
	{	q_def=new DefQuota(tab);
		tab->addTab(q_def, "Quota");
	}
	tab->setOKButton();
   	tab->setCancelButton();
   	tab->show();
   	
	connect(tab, SIGNAL(applyButtonPressed()), SLOT(bt_save()));
}

void Toplevel::ypupdate()
{	if(isyp) system(def_ypcmd);
}

void Toplevel::import()
{	char *estr=0, err;
	QString fname;

	fname=QFileDialog::getOpenFileName(0, "*.lst", this);
	if(!fname.isEmpty())
	{	if((err=implist((const char *)fname)))
		{	switch(err)
			{  case 1:	estr="Error opening Input-File.";
						break;
		   	   case 2:	estr="Error opening Output-File.";
				 		break;

		       case 3:	estr="Error in Input-Formatstring.";
		   				break;

		       case 4:	estr="Error in Output-Formatstring.";
		   				break;

		       case 5:	estr="Error in global Entry.";
		   				break;
		   				
		   	   case 6:	estr="No Input-Formatstring.";
		   				break;
			}

			QMessageBox::warning(0, 0, estr);
		}
		else
		{	mdlg->init_cb_user();
			mdlg->init_cb_group();
			mdlg->selectuser();
		}
	}
}

void Toplevel::passwd()
{	PwdDlg pwd;
	pwd.exec();
}

void Toplevel::quotasupport()
{	
	if(options->isItemChecked(quotaID))
	{	options->setItemChecked(quotaID, FALSE);
		mdlg->setFixedSize(455, 310);
		isquota=0;
	}
	else
	{	if(getquotadevice())
		{	QMessageBox::warning(0, 0, "No Quota-Device found.");
			return;
		}
		
		options->setItemChecked(quotaID, TRUE);
		mdlg->setFixedSize(640, 310);
		isquota=1;
	}
	updateRects();
}

void Toplevel::nissupport()
{	if(options->isItemChecked(nisID)) 
	{	options->setItemChecked(nisID, FALSE);
		
		isyp=0;
	}
	else
	{	options->setItemChecked(nisID, TRUE);
		isyp=1;
	}
}

void Toplevel::quit()
{	ka->quit();
}

void Toplevel::help()
{	ka->invokeHTMLHelp("", "");
}
