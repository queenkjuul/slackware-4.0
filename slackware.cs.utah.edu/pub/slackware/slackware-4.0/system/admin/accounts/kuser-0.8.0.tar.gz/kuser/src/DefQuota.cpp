/**********************************************************************

	--- Dlgedit generated file ---

	File: DefQuota.cpp
	Last generated: Mon Jul 7 20:11:26 1997

 *********************************************************************/

#include "DefQuota.h"

#define Inherited DefQuotaData

DefQuota::DefQuota(QWidget* parent, const char* name) : Inherited(parent, name)
{	le_fsoft->setText(QString().setNum(fsoft=def_fsoft));
	le_fhard->setText(QString().setNum(fhard=def_fhard));
	le_fgrace->setText(QString().setNum(fgrace=def_fgrace));

	le_isoft->setText(QString().setNum(isoft=def_isoft));
	le_ihard->setText(QString().setNum(ihard=def_ihard));
	le_igrace->setText(QString().setNum(igrace=def_igrace));
}


DefQuota::~DefQuota()
{
}

void DefQuota::set_defaults()
{	bool err;
	long int l;
	
	l=QString(le_fsoft->text()).toLong(&err);
	if(err) def_fsoft=l;
	l=QString(le_fhard->text()).toLong(&err);
	if(err) def_fhard=l;
	l=QString(le_fgrace->text()).toLong(&err);
	if(err) def_fgrace=l;

	l=QString(le_isoft->text()).toLong(&err);
	if(err) def_isoft=l;
	l=QString(le_ihard->text()).toLong(&err);
	if(err) def_ihard=l;
	l=QString(le_igrace->text()).toLong(&err);
	if(err) def_igrace=l;
}
