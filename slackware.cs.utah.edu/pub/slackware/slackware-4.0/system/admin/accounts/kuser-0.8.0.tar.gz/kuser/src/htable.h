#ifndef htable_included
#define htable_included


#include <qdialog.h>
#include <qtablevw.h>
#include <qscrbar.h>
#include <qpainter.h>
#include <qrect.h>
#include <qevent.h>
#include <qbrush.h>
#include <qpopmenu.h>
#include <stdlib.h>


typedef struct
{	QString text;
	QColor fg;
	QColor bg;
	int tf;
} CellData;


class HTable;

class Header : public QTableView
{
	Q_OBJECT
	friend class HTable;

public:

	Header(int cols, QWidget *parent=0, const char *name=0);
	virtual ~Header();

	HTable *tbl;
	
public slots:

	int cellWidth(int);


protected slots:
    
    	void scrollSideways(int);
	

protected:
	
	virtual void paintCell(QPainter *, int, int);
	void mousePressEvent(QMouseEvent *e);

private:
	
	QString *title;
};




class HTable : public QTableView
{
	Q_OBJECT
	friend class Header;
	
public:

	HTable(int rows, int cols, QWidget *parent=0, const char *name=0);
	virtual ~HTable();

	void setGeometry(int x, int y, int w, int h); 
	void setCellWidth(int);
	int numCols() {return cols;}
	int numRows() {return rows;}
	void clear();
	void initCol(int col, const char *str, int width);
	int colEnabled(int col);
	void setCell(int row, int col, const char *text=0, QColor *fg=0, QColor *bg=0, int tf=AlignLeft);
	bool isSelected(int row) {return rowSelected[row];}
	
	
public slots:

	int cellWidth(int col);
	

signals:

	void rightClicked(int col);
	void hdLeftClicked(int col);
	
	
protected:

	void resizeEvent(QResizeEvent *);
	virtual void paintEvent(QPaintEvent *);
	virtual void paintCell(QPainter *, int, int);
	void mousePressEvent(QMouseEvent *e);
	void mouseReleaseEvent(QMouseEvent *e);
	void mouseMoveEvent(QMouseEvent *e);
	void timerEvent(QTimerEvent *);
	void updateRow(int row);
	void emit_hdLeftClicked(int col);
	
private:

	int idx(int row, int col) {return ((row*cols)+col);}
	

	Header 	*hd;
	bool	*rowSelected;
	int 	colselected,
	 	rows,
	    	cols,
	    	frow,
	    	prow,
		*colWidths;
	enum {UP, DOWN} scrolldir;
    	const int scroll_delay=5; 	// time delay when autoscrolling, in ms	
	bool autoscrolling;
	CellData *cell;
	QColor  background;
};	


	
#endif	// htable_include

