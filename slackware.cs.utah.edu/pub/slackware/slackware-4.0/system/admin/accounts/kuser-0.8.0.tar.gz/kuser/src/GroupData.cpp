#include "GroupData.h"


GroupListe g_liste;


Group::Group(char *line)
{	char *p;

	if((p=strchr(line, ':'))==0) return;
	
	*p=0;
	g_name=line; line=++p;
	
	p=strchr(line, ':'); *p=0;
	g_passwd=line; line=++p;
	
	p=strchr(line, ':'); *p=0;
	g_gid=0xFFFF&atoi(line); line=++p;
	
	members.setAutoDelete(TRUE);
	admins.setAutoDelete(TRUE);
	while((p=strchr(line, ',')))
	{	*p=0;
		members.append(line);
		line=++p;
	}
	p=strchr(line, '\n');
	*p=0;
	if(p>line) members.append(line);
}

GroupListe::GroupListe()
{	setAutoDelete(TRUE);
}

GroupListe::~GroupListe()
{
}

Group * GroupListe::getgroup(QString str)
{	for(int i=0; i<(int)count(); i++)
	{	if(name(i)==str) return at(i);
	}
	
	return NULL;
}

int GroupListe::read()
{	QFile file(GROUP_FILE);
    	char line[100];
    	
    	if(file.open(IO_ReadOnly) == 0) return -1;	// Fehler
	else
	{	while(file.readLine(line, 98) > 0)
		{	if(*line!='+') append(new Group(line));
			if(gid(at())==100) gid100=at();
		}
		file.close();
		gsdw_read();
	}
	
	sort();
	return 0;
}

int GroupListe::write()
{	int zidx;

	rename(GROUP_FILE".oo", GROUP_FILE".ooo");
	rename(GROUP_FILE".o", GROUP_FILE".oo");
	rename(GROUP_FILE, GROUP_FILE".o");
	QFile file(GROUP_FILE);
	QTextStream cout(&file);

	if(file.open(IO_WriteOnly) == 0) return -1;	// Fehler
	else
	{	zidx=at();
		for(int i=0; i<(int)count(); i++)
		{	int n;
			Group *group;
			
			group=at(i);
			cout << group->g_name << ':';
			cout << "*:";
			cout << group->g_gid << ':';
			
			n=(int)group->members.count();
			for(int j=0; j<n; j++)
			{	cout << group->members.at(j);
				if(j<n-1) cout << ',';
			}
			cout << '\n';
		}
		file.close();
		gsdw_write();
		at(zidx);
	}
	
	chmod(GROUP_FILE, GROUP_FILE_MASK);
	return 0;
}

void GroupListe::gsdw_read()
{	FILE *file;
	struct sgrp *sgr;
	Group *grp;

	if((file=fopen(GSHADOW_FILE, "r")) == NULL)
	{	QMessageBox::warning(0, 0, "Error opening /etc/gshadow for reading.");
		return;
  	}

	while((sgr=fgetsgent(file)))			// read a shadow group structure
	{	if((grp=getgroup(sgr->sg_name)))
		{	char **ptr;
			
			grp->g_passwd=sgr->sg_passwd;
			ptr=sgr->sg_adm;
			while(*ptr!=0) grp->admins.append(*ptr++);
			
			ptr=sgr->sg_mem;
			while(*ptr!=0)
			{	char f=1;
			
				for(uint j=0; j<grp->members.count(); ++j)
				    if(strcmp(*ptr, grp->members.at(j))==0) {f=0; break;}
				
				if(f) grp->members.append(*ptr);
				++ptr;
			}
		}
	        else
	        {	char s[100];
	        
            		sprintf(s, "No /etc/group entry for %s. Entry will be removed at the next `Save'-operation.", sgr->sg_name);
		        QMessageBox::warning(0, 0, s);
        	}
    	}

	fclose(file);
}


void GroupListe::gsdw_write()
{	FILE *file;
	struct sgrp sgr;
	Group *grp;
	QArray <char *> ar1, ar2;
	
	rename(GSHADOW_FILE".oo", GSHADOW_FILE".ooo");
	rename(GSHADOW_FILE".o", GSHADOW_FILE".oo");
	rename(GSHADOW_FILE, GSHADOW_FILE".o");
	if((file=fopen(GSHADOW_FILE, "w")) == NULL)
	{	QMessageBox::warning(0, 0, "Error opening /etc/gshadow for writing.");
		return;
  	}

	for(int i=0; i<(int)count(); i++)
	{	uint j, n;
	
		grp=at(i);
		sgr.sg_name   = qstrdup(grp->g_name);
   		sgr.sg_passwd = qstrdup(grp->g_passwd);
		
		n=grp->admins.count();
		ar1.resize(n+1);
		for(j=0; j<n; ++j) ar1[j]=grp->admins.at(j);
		ar1[j]=0;
		n=grp->members.count();
		ar2.resize(n+1);
		for(j=0; j<n; ++j) ar2[j]=grp->members.at(j);
		ar2[j]=0;

		sgr.sg_adm=ar1.data();
		sgr.sg_mem=ar2.data();
		putsgent(&sgr, file);
	}
	
	fclose(file);
	chmod(GSHADOW_FILE, GSHADOW_FILE_MASK);
}

void  GroupListe::sort()
{	int flg, i, idx, n;
	Group *grp;
	
	idx=at();
	n=count()-1;
	do					
	{	flg=1;				
		for(i=0; i<n; ++i)
		{	if(name(i) > (const char *)name(i+1))
			{	grp=take(i);
				insert(i+1, grp);
				if(i==idx) ++idx;
				else if(i==idx-1) --idx;
				flg=0;
			}
		}
	}
	while(flg==0);
	at(idx);
}

int GroupListe::getid(uint u_gid)
{	for(int i=0; i<(int)count(); i++)
	{	if(gid(i)==u_gid) return i;
	}
	
	return -1;
}

uint GroupListe::getfreegid()
{	uint id=100;

	for(int i=0; i<(int)count(); ++i) if(gid(i)==id) {i=-1; ++id;}
	return id;
}

QString GroupListe::gidToName(uint u_gid)
{	int id=getid(u_gid);

	if(id==-1) return "none";
	else return at(id)->g_name;
}

void GroupListe::deluser(QString str)
{	uint i, idx;
	Group *grp;
	
	idx=at();
	for(i=0; i<count(); ++i)					
	{	grp=at(i);
		grp->members.remove(str);
		grp->admins.remove(str);
	}
	
	at(idx);
}
