/**********************************************************************

	--- Dlgedit generated file ---

	File: ViewDlg.cpp
	Last generated: Mon Sep 15 20:40:22 1997

 *********************************************************************/

#include "ViewDlg.h"
#include "ViewDlg.moc"
#include "ViewDlgData.moc"


#define Inherited ViewDlgData

ViewDlg::ViewDlg(QWidget* parent, const char* name) : Inherited(parent, name)
{	setCaption("View ");
}

void ViewDlg::init(QStrList *list, QList <int>*grp)
{	int i, vwix;

	smode=(sortmode==2)? 2: 0;
	grpptr=grp;
	cb_view->insertStrList(list);
	vwix=vw_group;
	if(vwix>2)
	{	for(i=vwix=0; i<(int)grp->count(); ++i)
		{	if((int)grp->at(i)==vw_group) {vwix=i; break;}
		}
	}
	cb_view->setCurrentItem(vwix);
	((QRadioButton *)(bg_sort->find((smode==2)? 1: 0)))->setChecked(TRUE);
}

ViewDlg::~ViewDlg()
{
}

// slots

void ViewDlg::bg_clicked(int bt)
{	smode=(bt==1)? 2: 0;
}

void ViewDlg::dlg_ok()
{	vw_group=(int)grpptr->at(cb_view->currentItem());
	vw_grpstr=cb_view->currentText();
	sortmode=smode;
	kc->setGroup("View");
	kc->writeEntry("sortmode", sortmode);
	kc->writeEntry("group", vw_group);
	kc->sync();
	done(0);
}

void ViewDlg::dlg_cancel()
{	done(1);
}

