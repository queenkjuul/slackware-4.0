/**********************************************************************

	--- Dlgedit generated file ---

	File: MainDlg.h
	Last generated: Sat Jul 5 22:55:49 1997

 *********************************************************************/

#ifndef MainDlg_included
#define MainDlg_included



#include "UserData.h"
#include "GroupData.h"
#include "misc.h"
#include "DefShadow.h"
#include "DefQuota.h"
#include "DefMisc.h"
#include "ViewDlg.h"
#include "MainDlg.h"
#include "MainDlgData.h"
#include "GroupDlg.h"
#include "LchgDlg.h"
#include <stdlib.h>
#include <sys/stat.h>
#include <time.h>

#include <kstatusbar.h>
#include <qfile.h>
#include <qfont.h>
#include <qmsgbox.h>
#include <qtstream.h>
#include <qlist.h>
#include <qstring.h>
#include <qregexp.h>
#include <qdatetm.h>
#include <qkeycode.h>
#include <qtabdlg.h>
#undef	 GrayScale
#include <qprinter.h>
#include <qpainter.h>
#include <qrect.h>



class MainDlg : public MainDlgData
{
    Q_OBJECT

public:

    	MainDlg(QWidget* parent=0, const char* name=0);
    	virtual ~MainDlg();

	void load();
  	void reload();
  	void print(QPrinter *);
  	void selectuser(int id=-1);
  	int  setchanges();
  	void discardchanges();
  	void newuser();
  	void deluser();
  	void grouped();
  	void chglist();
  	void viewdlg();
  	void usrchanged(const char *);
  	void init_cb_user();
  	void init_cb_group();
  
  	KStatusBar *stbar;
  
private:
	
  	int createuser();
	int check();
	int notset();
	
	void title(QPainter *);
	void entry(QPainter *, int);
	
	int newusr,
	    currentuid,
	    page;
	    
	int h, t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, y;
	
	QList <int> grp;
	QStrList grplist;
};

#endif // MainDlg_included
