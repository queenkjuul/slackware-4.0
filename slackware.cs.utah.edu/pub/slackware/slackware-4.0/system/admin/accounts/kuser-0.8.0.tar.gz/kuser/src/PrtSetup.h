/**********************************************************************

	--- Qt Architect generated file ---

	File: PrtSetup.h
	Last generated: Sat Jul 11 17:46:28 1998

 *********************************************************************/

#ifndef PrtSetup_included
#define PrtSetup_included

#include "PrtSetupData.h"
#include "misc.h"


class PrtSetup : public PrtSetupData
{
    Q_OBJECT

public:

    	PrtSetup(QWidget* parent=0, const char* name=0);
	virtual ~PrtSetup();

protected slots:
	
	void onok();
	void oncancel();
	
};
#endif // PrtSetup_included
