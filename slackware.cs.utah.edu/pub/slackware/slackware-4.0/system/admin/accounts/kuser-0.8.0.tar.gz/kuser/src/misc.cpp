#include "misc.h"

#define	HOME	"/home"				// default path to home-directories
#define	MAIL	"/var/spool/mail"	// default path to mail-directories
#define	SKEL	"/etc/skel"			// default skeleton-directory
#define	SHELL	"/bin/bash"			// default shell
#define	YPCMD	"make -C /var/yp"	// Command to update NIS-Database

#define EXPIRE	730					// 2 Jahre
#define FIXED	0
#define CHANGE	730
#define	WARN	30
#define	INACT	0

#define	FSOFT	400
#define	FHARD	500
#define	FGRACE	7
#define	ISOFT	80
#define	IHARD	100
#define	IGRACE	7


QString quotadevice;
KApplication *ka;
KConfig *kc;

QString passwd;


// Default-Werte
	
	int sortmode,
	    vw_group,
	    expire_mode,	// 0 -> Period
						// 1 -> Date
	    createmode,
	    delhome,		// 1 -> delete home-dir
	    delmail,		// 1 -> delete mail-dir
	    def_expire,
	    def_fixed,
	    def_change,
	    def_warn,
	    def_inact;

	long int def_fsoft,
		 	 def_fhard,
		  	 def_fgrace,
		     def_isoft,
		     def_ihard,
		     def_igrace;

	
	QString def_home,			// path to home-directories
			def_mail,			// path to mail-directories
			def_skel,			// path to skeleton-directory
			def_shell,			// shell
			def_createscript,	// script after creating a user
			def_deletescript,	// script before deleting a user
			def_ypcmd;			// command to update nis-database

	int ischanged,				// 1 -> Database has changed
	    isquota,				// 1 -> Quota-Support
	    isyp;					// 1 -> YP-Support

	QString vw_grpstr,
			printername,
			printcommand;
		
	time_t today;
	

void getdefaults()
{	QString str;

	kc->setGroup("View");
	sortmode=kc->readNumEntry("sortmode", 0);
	vw_group=kc->readNumEntry("group", 0);

	kc->setGroup("Printer");
	printername=kc->readEntry("printername", "lp");
	printcommand=kc->readEntry("printcommand", "lpr");
	
	kc->setGroup("Misc");
	isyp=(kc->readEntry("yp")=="yes")? 1: 0;
	isquota=(kc->readEntry("quota")=="yes")? 1: 0;
	def_home=kc->readEntry("home", HOME);
	def_mail=kc->readEntry("mail", MAIL);
	def_skel=kc->readEntry("skel", SKEL);
	str=kc->readEntry("createmode", "755");
	sscanf(str, "%o", &createmode);
	def_shell=kc->readEntry("shell", SHELL);
	def_createscript=kc->readEntry("createscript");
	def_deletescript=kc->readEntry("deletescript");
	def_ypcmd=kc->readEntry("ypcmd", YPCMD);
	delhome=(kc->readEntry("delhome", "yes")=="yes")? 1: 0;
	delmail=(kc->readEntry("delmail", "yes")=="yes")? 1: 0;
	
	kc->setGroup("Shadow");
	expire_mode=kc->readNumEntry("mode");
	str=kc->readEntry("expire");
	if(str.isEmpty())
	{	expire_mode=0;
		def_expire=EXPIRE;
		def_change=CHANGE;
		def_warn=WARN;
		def_inact=INACT;
	}
	else
	{	def_expire=str.toLong();
		def_fixed=kc->readNumEntry("fixed");
		def_change=kc->readNumEntry("change");
		def_warn=kc->readNumEntry("warn");
		def_inact=kc->readNumEntry("inact");
	}
	
	kc->setGroup("Quota");
	str=kc->readEntry("fsoft");
	def_fsoft=(str.isEmpty())? FSOFT: str.toLong();
	str=kc->readEntry("fhard");
	def_fhard=(str.isEmpty())? FHARD: str.toLong();
	str=kc->readEntry("fgrace");
	def_fgrace=(str.isEmpty())? FGRACE: str.toLong();
	
	str=kc->readEntry("isoft");
	def_isoft=(str.isEmpty())? ISOFT: str.toLong();
	str=kc->readEntry("ihard");
	def_ihard=(str.isEmpty())? IHARD: str.toLong();
	str=kc->readEntry("igrace");
	def_igrace=(str.isEmpty())? IGRACE: str.toLong();
}

void putdefaults()
{	char s[4];

	kc->setGroup("Misc");
	kc->writeEntry("home", def_home);
	kc->writeEntry("mail", def_mail);
	kc->writeEntry("skel", def_skel);
	sprintf(s, "%03o", createmode);
	kc->writeEntry("createmode", s);
	kc->writeEntry("shell", def_shell);
	kc->writeEntry("createscript", def_createscript);
	kc->writeEntry("deletescript", def_deletescript);
	kc->writeEntry("ypcmd", def_ypcmd);
	kc->writeEntry("delhome", (delhome==1)? "yes": "no");
	kc->writeEntry("delmail", (delmail==1)? "yes": "no");
	
	kc->setGroup("Shadow");
	kc->writeEntry("mode", expire_mode);
	kc->writeEntry("expire", def_expire);
	kc->writeEntry("fixed", def_fixed);
	kc->writeEntry("change", def_change);
	kc->writeEntry("warn", def_warn);
	kc->writeEntry("inact", def_inact);

	kc->setGroup("Quota");
	kc->writeEntry("fsoft", QString().setNum(def_fsoft));
	kc->writeEntry("fhard", QString().setNum(def_fhard));
	kc->writeEntry("fgrace", QString().setNum(def_fgrace));

	kc->writeEntry("isoft", QString().setNum(def_isoft));
	kc->writeEntry("ihard", QString().setNum(def_ihard));
	kc->writeEntry("igrace", QString().setNum(def_igrace));

	kc->sync();
}

QString date(time_t t)
{	char str[12];
	struct tm *loctime;
	
	if(t<=1) return "";
	
	t*=86400;
	loctime=localtime(&t);
	strftime(str, 10, "%d.%m.%y", loctime);
	return QString(str);
}

time_t date(QString str)
{	char *line, *p;
	int d, m, y;
	struct tm t;
	
	line=qstrdup(str);
	if((p=strchr(line, '.'))==0) return 0;
	*p=0; d=atoi(line); line=++p;
	
	if((p=strchr(line, '.'))==0) return 0;
	*p=0; m=atoi(line); line=++p;
	y=atoi(line);
	
	if(d<1 || d>31 || m<1 || m>12 || y<0 || y>99) return 0;
	
	t.tm_sec=t.tm_min=0; t.tm_hour=12;
	t.tm_mday=d; t.tm_mon=m-1;
	t.tm_year=(y<90)? y+100: y;
	
	return mktime(&t)/86400;
}

int getquotadevice()
{	FILE *fp;
	struct mntent *mnt;
	
	fp=setmntent(MNTTAB, "r");
	while((mnt=getmntent(fp)))
	{	if(hasmntopt(mnt, MNTOPT_USRQUOTA))
		{	quotadevice=mnt->mnt_fsname;
			endmntent(fp);
			return 0;
		}
	}

	endmntent(fp);
	return 1;	// no quota-device
}

char *salt()
{	time_t now;
	static unsigned long x;
	static char result[3];

	time(&now);
	x+=now+getpid()+clock();
	result[0]=i64c(((x>>18) ^ (x>>6)) & 077);
	result[1]=i64c(((x>>12) ^ x) & 077);
	result[2]='\0';
	return result;
}

int i64c(int i)			// convert an integer to a radix 64 character
{	if(i<=0) return '.';
	if(i==1) return '/';
	if(i>=2 && i<12)  return ('0'-2+i);
	if(i>=12 && i<38) return ('A'-12+i);
	if(i>=38 && i<63) return ('a'-38+i);
	return ('z');
}
