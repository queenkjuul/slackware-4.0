/**********************************************************************

	--- Qt Architect generated file ---

	File: LchgDlg.h
	Last generated: Sat Feb 14 22:42:14 1998

 *********************************************************************/

#ifndef LchgDlg_included
#define LchgDlg_included

#include "LchgDlgData.h"
#include "PwdChgDlg.h"
#include "QuChgDlg.h"
#include "htable.h"
#include "UserData.h"
#include "GroupData.h"
#include "misc.h"
#include <qfiledialog.h>


extern UserListe u_liste;
extern GroupListe g_liste;



class LchgDlg : public LchgDlgData
{
    	Q_OBJECT

public:

   	LchgDlg(QWidget* parent=NULL, const char* name=NULL);
    	virtual ~LchgDlg();
    	

protected slots:

	void onexecute();
	void ondelete();
	void onclose();
	void hdLeftClicked(int col);
	void rightClicked(int col);
	void resizeEvent(QResizeEvent *);
	
	
private:

	void initHeader();
	void initList();
	void pwdchg();
	void quotachg();
	
	HTable *tbl;
	bool up;
};
#endif // LchgDlg_included
