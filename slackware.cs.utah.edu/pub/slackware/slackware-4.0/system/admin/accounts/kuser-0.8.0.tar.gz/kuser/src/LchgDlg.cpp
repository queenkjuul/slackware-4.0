/**********************************************************************

	--- Qt Architect generated file ---

	File: LchgDlg.cpp
	Last generated: Sat Feb 14 22:42:14 1998

 *********************************************************************/

#include "LchgDlg.h"
#include "LchgDlg.moc"
#include "LchgDlgData.moc"


#define Inherited LchgDlgData


LchgDlg::LchgDlg(QWidget* parent, const char* name) : Inherited(parent, name)
{	QString str;

	if(isquota) tbl=new HTable(u_index.count(), 14, this);
	else tbl=new HTable(u_index.count(), 6, this);
	
	setCaption("List Editor");
	str.setNum(u_index.count());
	lb_group->setText(str+" Users of:   "+vw_grpstr);
	up=TRUE;
	initHeader();
	initList();
  	tbl->repaint();
  	
  	connect(tbl, SIGNAL(hdLeftClicked(int)), this, SLOT(hdLeftClicked(int)));
  	connect(tbl, SIGNAL(rightClicked(int)), this, SLOT(rightClicked(int)));
}


LchgDlg::~LchgDlg()
{	kc->setGroup("TableView");
	kc->writeEntry("user",   tbl->colEnabled(0));
	kc->writeEntry("group",  tbl->colEnabled(1));
	kc->writeEntry("uid",    tbl->colEnabled(2));
	kc->writeEntry("gid",    tbl->colEnabled(3));
	kc->writeEntry("expire", tbl->colEnabled(4));
	
	if(isquota)
	{	kc->writeEntry("fcur",   tbl->colEnabled(5));
		kc->writeEntry("icur",   tbl->colEnabled(6));
		kc->writeEntry("fsoft",  tbl->colEnabled(7));
		kc->writeEntry("fhard",  tbl->colEnabled(8));
		kc->writeEntry("fgrace", tbl->colEnabled(9));
		kc->writeEntry("isoft",  tbl->colEnabled(10));
		kc->writeEntry("ihard",  tbl->colEnabled(11));
		kc->writeEntry("igrace", tbl->colEnabled(12));
	
		kc->writeEntry("name",   tbl->colEnabled(13));
	}
	else kc->writeEntry("name",   tbl->colEnabled(5));
	
	kc->sync();
	delete tbl;
}

void LchgDlg::initHeader()
{	kc->setGroup("TableView");

	tbl->initCol(0, "User", kc->readNumEntry("user", 1)? 80: -80);
	tbl->initCol(1, "Group", kc->readNumEntry("group", 1)? 80: -80);
	tbl->initCol(2, "Uid", kc->readNumEntry("uid", 1)? 45: -45);
	tbl->initCol(3, "Gid", kc->readNumEntry("gid", 1)? 45: -45);
	tbl->initCol(4, "Expire at", kc->readNumEntry("expire", 1)? 70: -70);
	
	if(isquota)
	{	tbl->initCol(5, "F-usage", kc->readNumEntry("fcur", 1)? 60: -60);
		tbl->initCol(6, "i-usage", kc->readNumEntry("icur", 1)? 60: -60);
		tbl->initCol(7, "F-soft", kc->readNumEntry("fsoft", 1)? 50: -50);
		tbl->initCol(8, "F-hard", kc->readNumEntry("fhard", 1)? 50: -50);
		tbl->initCol(9, "F-grace", kc->readNumEntry("fgrace", 1)? 55: -55);
		tbl->initCol(10, "i-soft", kc->readNumEntry("isoft", 1)? 50: -50);
		tbl->initCol(11, "i-hard", kc->readNumEntry("ihard", 1)? 50: -50);
		tbl->initCol(12, "i-grace", kc->readNumEntry("igrace", 1)? 55: -55);
		
		tbl->initCol(13, "Name", kc->readNumEntry("name", 1)? 180: -180);
	}
	else tbl->initCol(5, "Name", kc->readNumEntry("name", 1)? 180: -180);
}

void LchgDlg::initList()
{	QColor *fg1, *fg2;

	tbl->clear();
	for(uint ix=0; ix<u_index.count(); ++ix)
	{	u_liste.at((int)u_index.at(ix));
		fg1=(u_liste.uid()<100 || u_liste.uid()>65000)? &QColor(darkGreen): 0;
		tbl->setCell(ix, 0, u_liste.name(), fg1);
		tbl->setCell(ix, 1, g_liste.gidToName(u_liste.gid()), fg1);
		tbl->setCell(ix, 2, QString().setNum(u_liste.uid()), fg1, 0, AlignRight);
		tbl->setCell(ix, 3, QString().setNum(u_liste.gid()), fg1, 0, AlignRight);
		tbl->setCell(ix, 4, date(u_liste.expire()), fg1, 0, AlignHCenter);
		
		if(isquota)
		{	QString grace;
	
			if(u_liste.uid()>=QUIDMIN && u_liste.uid()<=QUIDMAX)
			{	quotadata *qd;
	
				u_liste.getquota(&qd);
				fg2=(qd->fcur >= qd->fsoft)? &QColor(red): fg1;
				tbl->setCell(ix, 5, QString().setNum(qd->fcur), fg2, 0, AlignRight);
				fg2=(qd->icur >= qd->isoft)? &QColor(red): fg1;
				tbl->setCell(ix, 6, QString().setNum(qd->icur), fg2, 0, AlignRight);
				tbl->setCell(ix, 7, QString().setNum(qd->fsoft), fg1, 0, AlignRight);
				tbl->setCell(ix, 8, QString().setNum(qd->fhard), fg1, 0, AlignRight);
				if(qd->fcur >= qd->fsoft)
				{	if(qd->fgrace < time(0)) grace="none";
					else grace.setNum((qd->fgrace-time(0)+43200)/86400);
				}
				else grace="";
				tbl->setCell(ix, 9, grace, &QColor(red), 0, AlignHCenter);
				tbl->setCell(ix, 10, QString().setNum(qd->isoft), fg1, 0, AlignRight);
				tbl->setCell(ix, 11, QString().setNum(qd->ihard), fg1, 0, AlignRight);
				if(qd->icur >= qd->isoft)
				{	if(qd->fgrace < time(0)) grace="none";
					else grace.setNum((qd->igrace-time(0)+43200)/86400);
				}
				else grace="";
				tbl->setCell(ix, 12, grace, &QColor(red), 0, AlignHCenter);
				tbl->setCell(ix, 13, u_liste.cname(), fg1);
			}
		}
		else tbl->setCell(ix, 5, u_liste.cname(), fg1);
	}
	
	tbl->repaint();
}

void LchgDlg::pwdchg()
{	PwdChgDlg dlg;
	
	dlg.tbl=tbl;
	if(dlg.exec()==0) initList();
}

void LchgDlg::quotachg()
{	QuChgDlg dlg;
	
	dlg.tbl=tbl;
	if(dlg.exec()==0) initList();
}


// Slots

void LchgDlg::onexecute()
{	QString fname;

	fname=QFileDialog::getOpenFileName();
	if(!fname.isEmpty())		// execute script
	{	char str[200];
		int i;
		
		for(i=0; i<tbl->numRows(); ++i)
		{	if(tbl->isSelected(i))
			{	u_liste.at((int)u_index.at(i));
				sprintf(str, "%s %s %s '%s'\n",
							(const char *)fname,
							(const char *)u_liste.name(),
							(const char *)g_liste.gidToName(u_liste.gid()),
							(const char *)u_liste.cname());
				system(str);
			}
		}
	}
}

void LchgDlg::ondelete()
{	int i, m;
	QString str;
	QList <int> sidx;
	
	str="Delete marked Users ?\n";
	if(delhome==1) str=str+"Delete Home-Directories ?\n";
	if(delmail==1) str=str+"Delete Mail-Files ?";
	m=QMessageBox::critical(0, 0, str, "Yes", "No", 0, 1, 1);
	if(m==1) return;					// cancel
	
	for(i=0; i<tbl->numRows(); ++i)
	{	if(tbl->isSelected(i))
		{	unsigned int j, l=0;

			for(j=0; j<sidx.count(); ++j)		// sort
			{	if(u_index.at(i) > sidx.at(j))
				{	sidx.insert(j, u_index.at(i));
					l=1;
					break;
				}
			}
			if(l==0) sidx.append(u_index.at(i));
		}
	}
	
	for(i=0; i<(int)sidx.count(); ++i)
	{	u_liste.at((int)sidx.at(i));
		if(u_liste.uid()<100 || u_liste.uid()>65000)
		{	m=QMessageBox::critical(0, 0, "Delete System-User "+u_liste.name()+" and Directory "+u_liste.dir()+" ?",
						"Yes", "No", 0, 1, 1);
			if(m==1) continue;
		}

		u_liste.deluser();
	}

	done(2);
}

void LchgDlg::onclose()
{	done(1);
}

void LchgDlg::hdLeftClicked(int col)
{	static int lastcol=-1;

	if(col==lastcol) up=!up;
	else
	{	up=TRUE;
		lastcol=col;
	}
	u_liste.sort(col, up);
	initList();
}

void LchgDlg::rightClicked(int col)
{	
	if(col==4) pwdchg();
	else if(isquota && col>=5 && col<=12) quotachg();
}

void LchgDlg::resizeEvent(QResizeEvent *e)
{	int w=e->size().width(),
	    h=e->size().height();

	tbl->setGeometry(15, 35, w-30, h-110);
  	tbl->repaint();
  	grb_frame->move(20, h-65);
	bt_execute->move(35, h-45);
  	bt_delete->move(155, h-45);
  	bt_close->move(w-135, h-45);
}
