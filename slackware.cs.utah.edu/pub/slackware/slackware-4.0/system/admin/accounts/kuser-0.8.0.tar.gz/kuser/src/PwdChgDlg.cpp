/**********************************************************************

	--- Qt Architect generated file ---

	File: PwdChgDlg.cpp
	Last generated: Mon Feb 16 21:58:32 1998

 *********************************************************************/

#include "PwdChgDlg.h"
#include "PwdChgDlg.moc"
#include "PwdChgDlgData.moc"


#define Inherited PwdChgDlgData

PwdChgDlg::PwdChgDlg(QWidget* parent, const char* name)	: Inherited(parent, name)
{	setCaption("Change Shadow-Entries");
	
	cb_pwd->setChecked(FALSE);
	onpwd(FALSE);
	
	le_fixed->setText(date(today+def_fixed));
	le_change->setText(date(today+def_change));
	le_warn->setText(date(today+def_change-def_warn));
	le_inact->setText(date(today+def_change+def_inact));
	le_expire->setText(date(today+def_expire));
}


PwdChgDlg::~PwdChgDlg()
{
}


// Slots

void PwdChgDlg::onpwd(bool on)
{	le_fixed->setEnabled(on);
	le_change->setEnabled(on);
	le_warn->setEnabled(on);
	le_inact->setEnabled(on);
	le_expire->setEnabled(on);

}

void PwdChgDlg::onset()
{	time_t texpire, tfixed, tchange, twarn, tinact;

	if(cb_pwd->isChecked()==FALSE) done(1);
	
	texpire=date(le_expire->text());
	if(texpire==0 || texpire<=today) texpire=today+def_expire;
	
	tchange=date(le_change->text());
	if(tchange==0 || tchange<=today) tchange=today+def_change;
	if(tchange>texpire) tchange=texpire;
	
	tfixed=date(le_fixed->text());
	if(tfixed==0 || tfixed<=today || tfixed>tchange) tfixed=today+def_fixed;
	
	twarn=date(le_warn->text());
	if(twarn==0 || twarn<=today || twarn>tchange) twarn=tchange-def_warn;
	
	tinact=date(le_inact->text());
	if(tinact==0 || tinact<tchange) tinact=tchange+def_inact;
	if(tinact>texpire) tinact=texpire;
	
	for(int i=0; i<tbl->numRows(); ++i)
	{	if(tbl->isSelected(i))
		{	u_liste.at((int)u_index.at(i));
			u_liste.setlstchg(today);
			u_liste.setexpire(texpire);
			u_liste.setmin(tfixed-today);
			u_liste.setmax(tchange-today);
			u_liste.setwarn(tchange-twarn);
			u_liste.setinact(tinact-tchange);
		}
	}

	done(0);
}

void PwdChgDlg::oncancel()
{	done(1);
}

