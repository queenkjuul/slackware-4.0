#include "UserData.h"

#define __LIBRARY__
#include <linux/unistd.h>


UserListe u_liste;
QList <int> u_index;	// Indexlist of visible entries


_syscall4(int, quotactl, int, cmd, const char *, special, int, id, caddr_t, addr);


User::User(char *line)
{	char *p;

	if((p=strchr(line, ':'))) *p=0;
	u_name=line;
	if(p==0) return;
	
	line=++p;
	if((p=strchr(line, ':'))) *p=0;
	u_passwd=line;
	if(p==0) return;
	
	line=++p;
	if((p=strchr(line, ':'))) *p=0;
	u_uid=0xFFFF&atoi(line);
	if(p==0) return;
	
	line=++p;
	if((p=strchr(line, ':'))) *p=0;
	u_gid=0xFFFF&atoi(line);
	if(p==0) return;
	
	line=++p;
	if((p=strchr(line, ':'))) *p=0;
	if(line != p)
	{	char *q;
	
		if((q=strchr(line, ','))) *q=0; 
		u_cname=line;
		if(q)
		{	line=++q;
			if((q=strchr(line, ','))) *q=0; 
			u_cext1=line;
			if(q)
			{	line=++q;
				if((q=strchr(line, ','))) *q=0; 
				u_cext2=line;
				if(q)
				{	line=++q;
					u_cext3=line;
				}
			}
		}
	}
	
	if(p==0) return;
	
	line=++p;
	if((p=strchr(line, ':'))) *p=0;
	u_dir=line;
	if(p==0) return;
	
	line=++p;
	if((p=strchr(line, '\n')))
	{	*p=0;
		u_shell=line;
	}	
}

User::User(QString usr, uint id)
{	u_name=usr;
	u_uid=id;
}

User::~User()
{
}

UserListe::UserListe()
{	setAutoDelete(TRUE);
}

UserListe::~UserListe()
{
}

User * UserListe::getuser(QString str)
{	for(int i=0; i<(int)count(); i++)
	{	if(name(i)==str) return at(i);
	}
	
	return NULL;
}

int UserListe::uidToId(uint ui)
{	for(uint id=0; id<u_index.count(); ++id) if(ui==uid((int)u_index.at(id))) return id;
	return -1;					// not found
}

int UserListe::read()
{	QFile file(PASSWORD_FILE);
    	char line[100];
    	
    	if(file.open(IO_ReadOnly) == 0) return -1;	// Fehler
	else
	{	while(file.readLine(line, 98) > 0)
			if(strchr(line, ':') && *line!='+') append(new User(line));
		
		file.close();
		sdw_read();
		if(isquota) quota_read();
	}
	
	return 0;
}

int UserListe::write() 
{	int zidx;

	rename(PASSWORD_FILE".oo", PASSWORD_FILE".ooo");
	rename(PASSWORD_FILE".o", PASSWORD_FILE".oo");
	rename(PASSWORD_FILE, PASSWORD_FILE".o");
	QFile file(PASSWORD_FILE);
	QTextStream cout(&file);

	if(file.open(IO_WriteOnly) == 0) return -1;	// Fehler
	else
	{	zidx=at();
		for(int i=0; i<(int)count(); i++)
		{	User *user;
		
			user=at(i);
			cout << user->u_name << ':';
			cout << "x:";
			cout << user->u_uid << ':';
			cout << user->u_gid << ':';
			cout << user->u_cname << ',';
			cout << user->u_cext1 << ',';
			cout << user->u_cext2 << ',';
			cout << user->u_cext3 << ':';
			cout << user->u_dir << ':';
			cout << user->u_shell << '\n';
		}
		file.close();
		sdw_write();
		if(isquota) quota_write();
		at(zidx);
	}
	
	chmod(PASSWORD_FILE, PASSWORD_FILE_MASK);
	return 0;
}

void UserListe::deluser()
{	char str[200];

	if(!def_deletescript.isEmpty())
	{	sprintf(str, "%s %s %s '%s'\n", (const char *)def_deletescript,
								    	(const char *)u_liste.name(),
								    	(const char *)g_liste.gidToName(gid()),
								    	(const char *)u_liste.cname());
		//printf("%s\n", str);
		system(str);				// execute deletescript
	}
		
	if(delhome==1)
	{	sprintf(str, "rm -r %s\n", (const char *)dir());
		system(str);				// delete home
	}
	
	if(delmail==1)
	{	sprintf(str, "rm %s/%s\n", (const char *)def_mail,
								   (const char *)name());
		system(str);				// delete mail
	}
	
	g_liste.deluser(name());
	remove();
	buildIndex();
}

void UserListe::buildIndex()
{	int idx=at();

	u_index.clear();
	for(uint i=0; i<count(); i++)
	{	switch(vw_group)
		{  case 0:	break;				// show all users
		   
		   case 1:	if(uid(i)<100 ||	// show system users
		   		   uid(i)>65000) break;
				else continue;
		   
		   case 2:	if(uid(i)>=100 &&	// show nonsytem users
		   		   uid(i)<=65500) break;
				else continue;
		   
		   default:	at(i);
		   		if(gid()!=(uint)vw_group) continue;
		}
		
		u_index.append((int *)i);
	}
	
	at(idx);
}

void UserListe::sdw_read()
{	FILE *file;
	struct spwd *spw;
	User *us;

	if((file=fopen(SHADOW_FILE, "r")) == NULL)
	{	QMessageBox::warning(0, 0, "Error opening /etc/shadow for reading.");
		return;
  	}

	while((spw=fgetspent(file)))			// read a shadow password structure
	{	if((us=getuser(spw->sp_namp)))
		{	us->u_passwd=spw->sp_pwdp;
			us->u_lstchg=spw->sp_lstchg;
			us->u_min=spw->sp_min;
			us->u_max=spw->sp_max;
			us->u_warn=spw->sp_warn;
			us->u_inact=spw->sp_inact;
			us->u_expire=spw->sp_expire;
		}
	        else
	        {	char s[100];
	        
            		sprintf(s, "No /etc/passwd entry for %s. Entry will be removed at the next `Save'-operation.", spw->sp_namp);
		        QMessageBox::warning(0, 0, s);
        	}
    	}

	fclose(file);
}


void UserListe::sdw_write()
{	FILE *file;
	struct spwd spw;
	User *us;

	rename(SHADOW_FILE".oo", SHADOW_FILE".ooo");
	rename(SHADOW_FILE".o", SHADOW_FILE".oo");
	rename(SHADOW_FILE, SHADOW_FILE".o");
	if((file=fopen(SHADOW_FILE, "w")) == NULL)
	{	QMessageBox::warning(0, 0, "Error opening /etc/shadow for writing.");
		return;
  	}

	for(int i=0; i<(int)count(); i++)
	{	us=at(i);
		spw.sp_namp   = qstrdup(us->u_name);
   		spw.sp_pwdp   = qstrdup(us->u_passwd);
		spw.sp_lstchg = us->u_lstchg;
		spw.sp_min    = us->u_min;
		spw.sp_max    = us->u_max;
		spw.sp_warn   = us->u_warn;
		spw.sp_inact  = us->u_inact;
		spw.sp_expire = us->u_expire;
		spw.sp_flag   = 0;
		putspent(&spw, file);
	}
	
	fclose(file);
	chmod(SHADOW_FILE, SHADOW_FILE_MASK);
}

uint UserListe::getfreeuid()
{	uint id=500;

	for(int i=0; i<(int)count(); ++i) if(uid(i)==id) {i=-1; ++id;}
	return id;
}

void UserListe::sort(int mode, bool up)	// mode=0 => sort by name
{	int flg, i, idx, n;					// mode=1 => sort by group
	bool mu=0, md=0;					// mode=2 => sort by uid	
										// mode=3 => sort by gid
	User *u;							// mode=4 => sort by expire
										// mode=5 => sort by fcur
	if(isquota==0 && mode>5) return;	// mode=6 => sort by icur
	if(mode==9 || mode==12)  return;	// mode=7 => sort by fsoft
										// mode=8 => sort by fhard
	sortmode=mode;						// mode=10=> sort by isoft
	idx=at();							// mode=11=> sort by ihard
	n=count()-1;						// mode=13=> sort by cname
	do					
	{	flg=1;				
		for(i=0; i<n; ++i)
		{	quotadata *qd1, *qd2;
			
			if(isquota && mode>4)
			{	at(i);   getquota(&qd1);
				at(i+1); getquota(&qd2);
			}
			switch(mode)
			{  case 0:	mu=(name(i) > (const char *)name(i+1));
					md=(name(i) < (const char *)name(i+1));
					break;
			   case 1:	mu=(g_liste.gidToName(gid(i)) > 
			   		   (const char *)g_liste.gidToName(gid(i+1)));
			   		md=(g_liste.gidToName(gid(i)) < 
			   		   (const char *)g_liste.gidToName(gid(i+1)));
					break;
			   case 2:	mu=(uid(i) > uid(i+1));
			   		md=(uid(i) < uid(i+1));
			   		break;
			   case 3:	mu=(gid(i) > gid(i+1));
			   		md=(gid(i) < gid(i+1));
			   		break;
			   case 4:	mu=(expire(i) > expire(i+1));
			   		md=(expire(i) < expire(i+1));
			   		break;
			   case 5:	mu=isquota? (qd1->fcur > qd2->fcur):
			   			    (cname(i) > (const char *)cname(i+1));
			   		md=isquota? (qd1->fcur < qd2->fcur):
			   			    (cname(i) < (const char *)cname(i+1));	    
			   		break;
			   case 6:	mu=(qd1->icur > qd2->icur);
			   		md=(qd1->icur < qd2->icur);
			   		break;
			   case 7:	mu=(qd1->fsoft > qd2->fsoft);
			   		md=(qd1->fsoft < qd2->fsoft);
			   		break;
			   case 8:	mu=(qd1->fhard > qd2->fhard);
			   		md=(qd1->fhard < qd2->fhard);
			   		break;
			   case 10:	mu=(qd1->isoft > qd2->isoft);
			   		md=(qd1->isoft < qd2->isoft);
			   		break;
			   case 11:	mu=(qd1->ihard > qd2->ihard);
			   		md=(qd1->ihard < qd2->ihard);
			   		break;		
			   case 13:	mu=(cname(i) > (const char *)cname(i+1));
			   		md=(cname(i) < (const char *)cname(i+1));
			}
			
			if(up? mu: md)
			{	u=take(i);
				insert(i+1, u);
				if(i==idx) ++idx;
				else if(i==idx-1) --idx;
				flg=0;
			}
		}
	}
	while(flg==0);
	at(idx);
	buildIndex();
}

void UserListe::quota_read()
{	User *us;
	struct dqblk dqblk;
	int qcmd;
	
	qcmd=QCMD(Q_GETQUOTA, USRQUOTA);
	quotactl(QCMD(Q_SYNC, USRQUOTA), quotadevice, 0, (caddr_t) 0);
	
	for(int i=0; i<(int)count(); i++)
	{	us=at(i);
		
		if(quotactl(qcmd, quotadevice, uid(), (caddr_t) &dqblk))
		{	QMessageBox::warning(0, 0, "Error reading Quotafile."); 
			isquota=0;
			return;
		}
	
  		us->qudta.fhard =dqblk.dqb_bhardlimit;	// in kB
		us->qudta.fsoft =dqblk.dqb_bsoftlimit;
		us->qudta.fcur  =dqblk.dqb_curblocks;
		us->qudta.fgrace=dqblk.dqb_btime;
		
		us->qudta.ihard =dqblk.dqb_ihardlimit;
		us->qudta.isoft =dqblk.dqb_isoftlimit;
		us->qudta.icur  =dqblk.dqb_curinodes;
		us->qudta.igrace=dqblk.dqb_itime;
	}
}

void UserListe::quota_write()
{	User *us;
	struct dqblk dqblk;
	int qcmd;
	
	qcmd=QCMD(Q_SETQUOTA, USRQUOTA);
	for(int i=0; i<(int)count(); i++)
	{	us=at(i);
		
		dqblk.dqb_bhardlimit=us->qudta.fhard;
		dqblk.dqb_bsoftlimit=us->qudta.fsoft;
		dqblk.dqb_curblocks =us->qudta.fcur;
		
		dqblk.dqb_ihardlimit=us->qudta.ihard;
		dqblk.dqb_isoftlimit=us->qudta.isoft;
		dqblk.dqb_curinodes =us->qudta.icur;
		
		if(quotactl(qcmd, quotadevice, uid(), (caddr_t) &dqblk))
		{	QMessageBox::warning(0, 0, "Error writing Quotafile."); 
			isquota=0;
			return;
		}
		quotactl(QCMD(Q_SETQLIM, USRQUOTA), quotadevice, uid(), (caddr_t) &dqblk);
	}
	
	dqblk.dqb_btime=def_fgrace*86400;
	dqblk.dqb_itime=def_igrace*86400;
	quotactl(QCMD(Q_SETQLIM, USRQUOTA), quotadevice, 0, (caddr_t) &dqblk);
	quotactl(QCMD(Q_SYNC, USRQUOTA), quotadevice, 0, (caddr_t) 0);
}
