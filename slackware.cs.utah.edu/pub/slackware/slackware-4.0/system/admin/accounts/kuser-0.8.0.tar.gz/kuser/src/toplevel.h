#ifndef Toplevel_included
#define Toplevel_included


#include "misc.h"
#include "implist.h"
#include "MainDlg.h"
#include "PwdDlg.h"
#include "PrtSetup.h"
#include <kapp.h>
#include <ktopwidget.h> 
#include <kmenubar.h>
#include <ktoolbar.h>
#include <kstatusbar.h>
#include <kiconloader.h>
#include <qmsgbox.h>
#include <qfiledialog.h>
#include <qprinter.h>



//extern KConfig *kc;



class Toplevel : public KTopLevelWidget
{
    Q_OBJECT

public:

    Toplevel(const char *name=NULL);
    virtual ~Toplevel();

 	DefMisc *m_def;
    DefShadow *s_def;
    DefQuota *q_def;


protected slots:
	
	void save();
	void bt_save();
	void reload();
	void print();
	void prtsetup();
	void setchanges();
	void discardchanges();
	void grouped();
	void chglist();
	void newuser();
	void deluser();
	void viewdlg();
	void defaults();
  	void ypupdate();
  	void import();
  	void passwd();
  	void quotasupport();
  	void nissupport();
	void quit();
	void help();
  	

private:

  	void setupMenu();
  	void setupToolBar();
	void setupStatusBar();

	int quotaID,
	    nisID;
	    
	MainDlg *mdlg;
	QPopupMenu *options;
	KStatusBar *stbar;
};

#endif // Toplevel_included
