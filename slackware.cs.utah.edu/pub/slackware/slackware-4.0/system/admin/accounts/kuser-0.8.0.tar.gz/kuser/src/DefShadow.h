/**********************************************************************

	--- Dlgedit generated file ---

	File: DefShadow.h
	Last generated: Tue Jul 8 07:22:16 1997

 *********************************************************************/

#ifndef DefShadow_included
#define DefShadow_included

#include <time.h>
#include "misc.h"
#include "DefShadowData.h"

class DefShadow : public DefShadowData
{
    Q_OBJECT

public:

    DefShadow
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

 	virtual ~DefShadow();
	void set_defaults();

private:
	int mode,
    	    expire,
    	    fixed,
    	    change,
    	    warn,
    	    inact;
    	    
    	time_t today;   
	
protected slots:
    	void exp_mode(int);

};
#endif // DefShadow_included
