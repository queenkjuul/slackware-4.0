/**********************************************************************

	--- Dlgedit generated file ---

	File: ViewDlg.h
	Last generated: Mon Sep 15 20:40:22 1997

 *********************************************************************/

#ifndef ViewDlg_included
#define ViewDlg_included

#include "ViewDlgData.h"
#include "misc.h"
#include <kconfig.h>
#include <qstrlist.h>
#include <qlist.h> 

class ViewDlg : public ViewDlgData
{
    	Q_OBJECT

public:
	
    	ViewDlg(QWidget* parent = NULL, const char* name = NULL);
    	virtual ~ViewDlg();
    	
    	void init(QStrList *, QList <int>*);
	

protected slots:
	void bg_clicked(int);
	void dlg_ok();
	void dlg_cancel();
	
private:
	int smode;
	QList <int> *grpptr;
	QStrList *list;
};
#endif // ViewDlg_included

