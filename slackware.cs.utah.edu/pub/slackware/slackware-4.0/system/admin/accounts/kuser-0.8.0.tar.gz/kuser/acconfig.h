/* Define if the C++ compiler supports BOOL */
#undef HAVE_BOOL

#define VERSION 0.3

#define PACKAGE kexample

/* defines if having libgif (always 1) */
#undef HAVE_LIBGIF

/* defines if having libjpeg (always 1) */
#undef HAVE_LIBJPEG

/* defines which to take for ksize_t */
#undef ksize_t

/* define if you have setenv */
#undef HAVE_FUNC_SETENV
