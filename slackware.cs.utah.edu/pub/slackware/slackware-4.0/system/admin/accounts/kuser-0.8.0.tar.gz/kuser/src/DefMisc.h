/**********************************************************************

	--- Dlgedit generated file ---

	File: DefMisc.h
	Last generated: Tue Aug 19 22:19:12 1997

 *********************************************************************/

#ifndef DefMisc_included
#define DefMisc_included

#include "misc.h"
#include "DefMiscData.h"


class DefMisc : public DefMiscData
{
    Q_OBJECT

public:

	DefMisc(QWidget* parent=NULL, const char* name=NULL);
	virtual ~DefMisc();
	void set_defaults();


protected slots:

	void onm11();
	void onm12();
	void onm13();
	void onm21();
	void onm22();
	void onm23();
	void onm31();
	void onm32();
	void onm33();
	

private:
	
	void setmode();
	
	int	mode;
	QString home,
		mail,
		skel,
	   	shell,
	   	createscript,
	   	deletescript,
	   	ypcmd;
	   	

};
#endif // DefMisc_included
