#ifndef misc_included
#define misc_included

#include <qdir.h>
#include <qlist.h>
#include <kapp.h>
#include <kconfig.h>
#include <stdlib.h>
#include <qstring.h>
#include <time.h>
#include <unistd.h>
#include <mntent.h>

#define	KU_VERSION	"0.8"
#define	QUIDMIN	100
#define QUIDMAX	16000


extern QString quotadevice;
extern KApplication *ka;
extern KConfig *kc;

extern QString passwd;


// Default-Werte

// Misc:

extern int createmode,
	   	   delhome,
	       delmail;
	   
extern QString def_home,
	           def_mail,
	           def_skel,
	           def_shell,
			   def_createscript,
	           def_deletescript,
	           def_ypcmd;


// Shadow:
	
extern int sortmode,
	   	   vw_group,
		   expire_mode,		// 0 -> Period
							// 1 -> Date
		   def_expire,
		   def_fixed,
		   def_change,
		   def_warn,
		   def_inact;

// Quota:

extern long int def_fsoft,
			   	def_fhard,
			   	def_fgrace,
			   	def_isoft,
			   	def_ihard,
			   	def_igrace;

extern int ischanged,		// 1 -> Database has changed
	       isquota,			// 1 -> Quota-Support
	       isyp;			// 1 -> YP-Support

extern QString vw_grpstr,
	       	   printername,
	           printcommand;
	       
extern time_t today;


void getdefaults();
void putdefaults();
int getquotadevice();
QString date(time_t);
time_t date(QString);
char *salt();
int i64c(int);

#endif	// misc_included
