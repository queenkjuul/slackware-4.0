/**********************************************************************

	--- Dlgedit generated file ---

	File: PwdDlg.cpp
	Last generated: Thu Jun 26 11:41:50 1997

 *********************************************************************/

#include "PwdDlg.h"
#include "PwdDlg.moc"
#include "PwdDlgData.moc"

#define Inherited PwdDlgData


PwdDlg::PwdDlg(QWidget* parent, const char* name) : Inherited(parent, name)
{	le_passwd->setText(pwd="");
	le_passwd->setFocus();
}

PwdDlg::~PwdDlg()
{
}

void PwdDlg::set_pwd()
{	if(pwd=="")
	{	if((pwd=le_passwd->text())=="") {passwd=pwd; done(0);}
	
		lb_passwd->setText("Re-Enter Password:");
		le_passwd->setText("");
	}
	else
	{	if(le_passwd->text()==pwd) {passwd=pwd; done(0);}
		
		lb_passwd->setText("Enter Password:");
		le_passwd->setText(pwd="");
	}
}
