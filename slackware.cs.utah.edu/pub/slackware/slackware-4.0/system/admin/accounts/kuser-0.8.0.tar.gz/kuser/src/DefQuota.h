/**********************************************************************

	--- Dlgedit generated file ---

	File: DefQuota.h
	Last generated: Mon Jul 7 20:11:26 1997

 *********************************************************************/

#ifndef DefQuota_included
#define DefQuota_included

#include "DefQuotaData.h"
#include "misc.h"

class DefQuota : public DefQuotaData
{
    Q_OBJECT

public:

    DefQuota
    (
	QWidget* parent = NULL,
        const char* name = NULL
    );

    	virtual ~DefQuota();
    	void set_defaults();
    	
private:
	long int fsoft,
		 fhard,
		 fgrace,
		 isoft,
		 ihard,
		 igrace;
    
};
#endif // DefQuota_included
