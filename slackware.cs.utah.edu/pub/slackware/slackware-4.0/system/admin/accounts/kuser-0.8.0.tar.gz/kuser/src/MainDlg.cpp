/**********************************************************************

	--- Dlgedit generated file ---

	File: MainDlg.cpp
	Last generated: Sat Jul 5 22:55:49 1997

 *********************************************************************/


#include "MainDlg.h"
#include "MainDlg.moc"
#include "MainDlgData.moc"


#define Inherited MainDlgData

MainDlg::MainDlg(QWidget* parent=0, const char* name=0) : Inherited(parent, name)
{	today=time(0)/86400;
}

MainDlg::~MainDlg()
{
}

void MainDlg::load()
{	ischanged=0;
	u_liste.read();
	u_liste.sort(sortmode);
	g_liste.read();
	init_cb_group();
	init_cb_user();
	selectuser(0);
}

void MainDlg::init_cb_user()
{	char uname[40];
	int idx, cbidx=0;
	QString str;
	
	idx=u_liste.at();
	cb_user->clear();
	for(uint i=0, j=0; i<u_index.count(); i++)	
	{	int ix=(int)u_index.at(i);
	
		sprintf(uname, "%-15s%d", (const char *)u_liste.name(ix), u_liste.uid(ix));
		cb_user->insertItem(uname);
		if(ix==idx) cbidx=j;
		++j;
	}
	
	str.setNum(cb_user->count());
	stbar->changeItem(str+" Users of:   "+vw_grpstr, 1);
	if(cb_user->count()==0) return;
	
	cb_user->setCurrentItem(cbidx);
	u_index.at(cbidx);
	u_liste.at(cbidx);
}

void MainDlg::init_cb_group()
{	char gname[40];   
	int vwix;
	
	cb_group->clear();
	grp.clear();
	grplist.clear();
	grp.append((int *)0);
	grp.append((int *)1);
	grp.append((int *)2);
	grplist.append("all groups");
	grplist.append("system    (uid <  100)");
	grplist.append("nonsystem (uid >= 100)");
	
	vwix=(vw_group<=2)? vw_group: 0;	
	for(int i=0; i<(int)g_liste.count(); i++)
	{	int gid;
	
		gid=g_liste.gid(i);
		sprintf(gname, "%-15s%d", (const char *)g_liste.name(i), gid);
		cb_group->insertItem(gname);
		if(gid>=100 && gid<65000)
		{	grplist.append((const char *)g_liste.name(i));
			grp.append((int *)gid);
			if(gid==vw_group) vwix=grp.at();
		}
	} 
	
	grp.at(vwix);
	vw_grpstr=grplist.at(vwix);
}

int MainDlg::check()
{	int id;

	if(*le_user->text()==0) return 1;			// no user
	if(u_liste.getuser(le_user->text())!=0)	return 2;	// user exists
	if(*le_uid->text()==0) return 3;			// no uid
	id=QString(le_uid->text()).toUInt();
	if(u_liste.uidToId(id)>=0) return 4;  		// uid exists
	if(*le_dir->text()==0) return 5;			// no home-dir
	if(*le_shell->text()==0) return 6;			// no shell
	
	return 0;
}

int MainDlg::notset()
{	int m;
	
	if(newusr==1)
	{	m=QMessageBox::critical(0, 0, "Changes not set !",
				        "Set now", "Cancel", 0, 0, 1);
		if(m==1) return 1;				// cancel
		return setchanges();
	}
		
	return 0;
}

int MainDlg::createuser()
{	char str[200];
	int e;
	QString msg;
	quotadata *qd;
	
	switch(e=check())
	{  case 1:	msg="No User !";
				break;
	   case 2:	msg=QString("User ")+le_user->text()+QString(" exists !");
	   			break;
	   case 3:	msg="No User-id !";
	   			break;
	   case 4:	msg="User-id exists !";
	   			break;
	   case 5:	msg="No Home-Directory !";
	   			break;
	   case 6:	msg="No Shell !";
	   			break;
	}
	if(e)
	{	QMessageBox::warning(0, 0, msg);
		newuser();
		return 1;
	}
	
	currentuid=QString(le_uid->text()).toUInt();
	u_liste.append(new User(QString(le_user->text()), currentuid));
	u_liste.setlstchg(today);
	u_liste.setgid(g_liste.gid(cb_group->currentItem()));
	u_liste.sort(sortmode);
	g_liste.at(cb_group->currentItem());
	
	// create home-dir
	sprintf(str, "cp -a /etc/skel/ %s\n", le_dir->text());
	system(str);

	// execute createscript
	if(!def_createscript.isEmpty())
	{	sprintf(str, "%s %s %s '%s'\n", (const char *)def_createscript,
									    (const char *)u_liste.name(),
									    (const char *)g_liste.name(),
									    le_cname->text());
		//printf("%s\n", str);
		system(str);
	}

	sprintf(str, "chmod %03o %s\n", createmode, le_dir->text());
	system(str);
	sprintf(str, "chown -R %u.%u %s\n", u_liste.uid(), g_liste.gid(), le_dir->text());
	system(str);
	
	if(isquota)
	{	u_liste.getquota(&qd);
		qd->fcur=qd->icur=0;
	}
	
	return 0;
}

void MainDlg::reload()
{	u_liste.clear();
	g_liste.clear();
	cb_user->clear();
	cb_group->clear();
	load();
}

void MainDlg::selectuser(int id)
{	if(cb_user->count()==0)
	{	le_dir->setText("");
		le_shell->setText("");
		le_cname->setText("");
		le_cext1->setText("");
		le_cext2->setText("");
		le_cext3->setText("");
	
		lb_lstchg->setText("");
		le_expire->setText("");
		le_fixed->setText("");
		le_change->setText("");
		le_warn->setText("");
		le_inact->setText("");
		cb_group->setCurrentItem(g_liste.getid((vw_group<=2)? 100: vw_group));
		
		if(isquota)
		{	lb_fusage->setText("");
			lb_iusage->setText("");
			le_fsoft->setText("");
			le_fhard->setText("");
			lb_fgrace->setText("");
			le_isoft->setText("");
			le_ihard->setText("");
			lb_igrace->setText("");
		}
		
		newusr=2;
		return;
	}
	
	if(id==-1)
	{	id=u_liste.uidToId(currentuid);
		if(id==-1) id=0;
	}
	cb_user->setCurrentItem(id);
	id=(int)u_index.at(id);
	u_liste.at(id);
	currentuid=u_liste.uid();
	cb_group->setCurrentItem(g_liste.getid(u_liste.gid()));

	le_dir->setText(u_liste.dir());
	le_shell->setText(u_liste.shell());
	le_cname->setText(u_liste.cname());
	le_cext1->setText(u_liste.cext1());
	le_cext2->setText(u_liste.cext2());
	le_cext3->setText(u_liste.cext3());
	
	if(u_liste.expire()<=1)
	{	lb_lstchg->setText("");
		lb_lstchg->setEnabled(FALSE);
		le_expire->setText("");
		le_expire->setEnabled(FALSE);
		le_fixed->setText("");
		le_fixed->setEnabled(FALSE);
		le_change->setText("");
		le_change->setEnabled(FALSE);
		le_warn->setText("");
		le_warn->setEnabled(FALSE);
		le_inact->setText("");
		le_inact->setEnabled(FALSE);
	}
	else
	{	lb_lstchg->setText(date(u_liste.lstchg()));
		lb_lstchg->setEnabled(TRUE);
		le_expire->setText(date(u_liste.expire()));
		le_expire->setEnabled(TRUE);
		le_fixed->setText(date(u_liste.lstchg()+u_liste.min()));
		le_fixed->setEnabled(TRUE);
		le_change->setText(date(u_liste.lstchg()+u_liste.max()));
		le_change->setEnabled(TRUE);
		le_warn->setText(date(u_liste.lstchg()+u_liste.max()-u_liste.warn()));
		le_warn->setEnabled(TRUE);
		le_inact->setText(date(u_liste.lstchg()+u_liste.max()+u_liste.inact()));
		le_inact->setEnabled(TRUE);
	}
	
	if(isquota)
	{	QString grace;
	
		if(u_liste.uid()>=QUIDMIN && u_liste.uid()<=QUIDMAX)
		{	quotadata *qd;
	
			u_liste.getquota(&qd);
			
			le_fsoft->setEnabled(TRUE);
			le_fhard->setEnabled(TRUE);
			le_isoft->setEnabled(TRUE);
			le_ihard->setEnabled(TRUE);

			lb_fusage->setText(QString().setNum(qd->fcur));
			lb_iusage->setText(QString().setNum(qd->icur));
			le_fsoft->setText(QString().setNum(qd->fsoft));
			le_fhard->setText(QString().setNum(qd->fhard));
			if(qd->fcur >= qd->fsoft)
			{	if(qd->fgrace < time(0)) grace="none";
				else grace.setNum((qd->fgrace-time(0)+43200)/86400);
			}
			else grace="";
			lb_fgrace->setText(grace);
			
			le_isoft->setText(QString().setNum(qd->isoft));
			le_ihard->setText(QString().setNum(qd->ihard));
			if(qd->icur >= qd->isoft)
			{	if(qd->igrace < time(0)) grace="none";
				else grace.setNum((qd->igrace-time(0)+43200)/86400);
			}
			else grace="";
			lb_igrace->setText(grace);
		}
		else
		{	le_fsoft->setEnabled(FALSE);
			le_fhard->setEnabled(FALSE);
			le_isoft->setEnabled(FALSE);
			le_ihard->setEnabled(FALSE);
		
			lb_fusage->setText("");
			lb_iusage->setText("");
			le_fsoft->setText("");
			le_fhard->setText("");
			lb_fgrace->setText("");
			le_isoft->setText("");
			le_ihard->setText("");
			lb_igrace->setText("");
		}
	}
	
	passwd="n";
	newusr=0;
}

int MainDlg::setchanges()
{	QString str;
	time_t texpire, tfixed, tchange, twarn, tinact;
	
	if(newusr==2) return 1;
	if(newusr==1) if(createuser()) return 1;
	
	u_liste.setdir(le_dir->text());
	u_liste.setshell(le_shell->text());
	u_liste.setgid(g_liste.gid(cb_group->currentItem()));
	
	str=le_cname->text();
	u_liste.setcname(str.replace(QRegExp(","), ";"));
	str=le_cext1->text();
	u_liste.setcext1(str.replace(QRegExp(","), ";"));
	str=le_cext2->text();
	u_liste.setcext2(str.replace(QRegExp(","), ";"));
	str=le_cext3->text();
	u_liste.setcext3(str.replace(QRegExp(","), ";"));
	if(passwd!="n")	u_liste.setpasswd(passwd);
	
	texpire=date(le_expire->text());
	if(texpire==0 || texpire<=today) texpire=today+def_expire;
	
	tchange=date(le_change->text());
	if(tchange==0 || tchange<=today) tchange=today+def_change;
	if(tchange>texpire) tchange=texpire;
	
	tfixed=date(le_fixed->text());
	if(tfixed==0 || tfixed<=today || tfixed>tchange) tfixed=today+def_fixed;
	
	twarn=date(le_warn->text());
	if(twarn==0 || twarn<=today || twarn>tchange) twarn=tchange-def_warn;
	
	tinact=date(le_inact->text());
	if(tinact==0 || tinact<tchange) tinact=tchange+def_inact;
	if(tinact>texpire) tinact=texpire;
	
	u_liste.setlstchg(today);
	u_liste.setexpire(texpire);
	u_liste.setmin(tfixed-today);
	u_liste.setmax(tchange-today);
	u_liste.setwarn(tchange-twarn);
	u_liste.setinact(tinact-tchange);
	
	if(isquota)
	{	quotadata *qd;
	
		u_liste.getquota(&qd);
		qd->fsoft =QString(le_fsoft->text()).toLong();
		qd->fhard =QString(le_fhard->text()).toLong();
		qd->isoft =QString(le_isoft->text()).toLong();
		qd->ihard =QString(le_ihard->text()).toLong();
	}
	
	init_cb_user();
	cb_user->show();
	selectuser();
	ischanged=1;
	return 0;
}

void MainDlg::discardchanges()
{	newusr=0;
	cb_user->show();
	selectuser();
}


void MainDlg::newuser()
{	int ix;
	QString str;

	le_user->setText("");
	le_user->setFocus();
	le_uid->setText(str.setNum(u_liste.getfreeuid()));
	ix=(vw_group<=2)? g_liste.getid100(): g_liste.getid(vw_group);
	cb_group->setCurrentItem(ix);
	le_dir->setText(def_home);
	le_shell->setText(def_shell);
	le_cname->setText("");
	le_cext1->setText("");
	le_cext2->setText("");
	le_cext3->setText("");
	
	lb_lstchg->setText(date(today));
	le_fixed->setText(date(today+def_fixed));
	le_change->setText(date(today+def_change));
	le_warn->setText(date(today+def_change-def_warn));
	le_inact->setText(date(today+def_change+def_inact));
	le_expire->setText(date(today+def_expire));
	
	if(isquota)
	{	le_fsoft->setEnabled(TRUE);
		le_fhard->setEnabled(TRUE);
		le_isoft->setEnabled(TRUE);
		le_ihard->setEnabled(TRUE);

		lb_fusage->setText("0");
		lb_iusage->setText("0");
		le_fsoft->setText(QString().setNum(def_fsoft));
		le_fhard->setText(QString().setNum(def_fhard));
		lb_fgrace->setText(QString().setNum(def_fgrace));
		le_isoft->setText(QString().setNum(def_isoft));
		le_ihard->setText(QString().setNum(def_ihard));
		lb_igrace->setText(QString().setNum(def_igrace));
	}

	cb_user->hide();
	passwd="";
	newusr=1;
}

void MainDlg::deluser()
{	int i, m=1;
	QString mailfile, str;
	
	if(notset()) return;					// changes not set
	
	mailfile=def_mail+"/"+u_liste.name();
	if(delhome==1) str="Delete Home-Directory: "+u_liste.dir()+"  ?\n";
	if(delmail==1) str=str+"Delete Mail-File: "+mailfile;
	if(delhome==1 || delmail==1)
	{	m=QMessageBox::critical(0, 0, str, "Yes", "No", "Cancel", 2, 2);
		if(m==2) return;					// cancel
	}
	
	if(m==0) u_liste.deluser();
	i=cb_user->currentItem();
	if(i==cb_user->count()-1) i=0;
	init_cb_user();
	selectuser(i);
	ischanged=1;
}

void MainDlg::grouped()
{	if(notset()) return;		// changes not set
	
	GroupDlg grpdlg;
	
	grpdlg.exec();
	init_cb_group();
	selectuser();
	ischanged=1;
}

void MainDlg::chglist()
{	if(notset()) return;		// changes not set

	LchgDlg dlg;

	dlg.exec();
	init_cb_user();
	selectuser();
	ischanged=1;
}

void MainDlg::viewdlg()
{	ViewDlg vwdlg;

	vwdlg.init(&grplist, &grp);
	if(vwdlg.exec()) return;	// cancel
	
	u_liste.sort(sortmode);
	init_cb_user();
	selectuser();
}

void MainDlg::usrchanged(const char *str)
{	le_dir->setText(def_home+'/'+str);
}

void MainDlg::print(QPrinter *prt)
{	QPainter p;

	page=1;
	h=20;
	t0=40;
	t1=t0+30;		// No.
	t2=t1+60;		// User
	t3=t2+60;		// Group
	t4=t3+160;		// Name
	t5=t4+100;		// Address
	t6=t5+45;		// Expire
	t7=t6+45;		// File usage
	t8=t7+45;		// File soft
	t9=t8+45;		// File hard
	t10=t9+45;		// iNode usage
	t11=t10+45;		// iNode soft
	t12=t11+45;		// iNode hard
	
	p.begin(prt);
	title(&p);
	for(uint ix=0; ix<u_index.count(); ++ix)
	{	if(ix%20==0 && ix>0)
		{	++page;
			prt->newPage();
			title(&p);
		}
		entry(&p, ix);
	}
	p.end();
}

void MainDlg::title(QPainter *p)
{	int h=24, h1=14, h2=10;

	QString str;
	QRect rc;
	QFont font1("times", 12, QFont::Bold);
	QFont font2("times", 10, QFont::Bold);
	QFont font3("times",  7, QFont::Bold);
	
	y=100;
	str="Users of Group :     "+vw_grpstr;
	p->setFont(QFont("times", 14, QFont::Bold));
	p->drawText(t0, 70, str);
	p->drawText(t4+5, 70, date(today));
	str="Page  "+str.setNum(page);
	p->setFont(font1);
	p->drawText(t12-60, 70, str);
	p->drawLine(t0, 75, t12, 75);
	
	rc.setRect(t0, y, t1-t0, h);
	p->setBrush(Dense2Pattern);
	p->drawRect(rc);
	rc.setLeft(t0+5);
	p->drawText(rc, AlignLeft|AlignVCenter, "No.");
	
	rc.setRect(t1, y, t2-t1, h);
	p->drawRect(rc);
	rc.setLeft(t1+5);
	p->drawText(rc, AlignLeft|AlignVCenter, "User");
	
	rc.setRect(t2, y, t3-t2, h);
	p->drawRect(rc);
	rc.setLeft(t2+5);
	p->drawText(rc, AlignLeft|AlignVCenter, "Group");
	
	rc.setRect(t3, y, t4-t3, h);
	p->drawRect(rc);
	rc.setLeft(t3+5);
	p->drawText(rc, AlignLeft|AlignVCenter, "Name");
	
	rc.setRect(t4, y, t5-t4, h);
	p->drawRect(rc);
	rc.setLeft(t4+5);
	p->drawText(rc, AlignLeft|AlignVCenter, "Address");
	
	rc.setRect(t5, y, t6-t5, h);
	p->drawRect(rc);
	rc.setLeft(t5+5);
	p->drawText(rc, AlignLeft|AlignVCenter, "Expire");
	
	if(isquota)
	{	rc.setRect(t6, y, t9-t6, h1);
		p->drawRect(rc);
		p->setFont(font2);
		p->drawText(rc, AlignCenter, "File - Quota");
		rc.setRect(t6, y+h1, t7-t6, h2);
		p->drawRect(rc);
		p->setFont(font3);
		p->drawText(rc, AlignCenter, "usage");
		rc.setRect(t7, y+h1, t8-t7, h2);
		p->drawRect(rc);
		p->drawText(rc, AlignCenter, "soft");
		rc.setRect(t8, y+h1, t9-t8, h2);
		p->drawRect(rc);
		p->drawText(rc, AlignCenter, "hard");
	
		rc.setRect(t9, y, t12-t9, h1);
		p->drawRect(rc);
		p->setFont(font2);
		p->drawText(rc, AlignCenter, "iNode - Quota");
		rc.setRect(t9, y+h1, t10-t9, h2);
		p->drawRect(rc);
		p->setFont(font3);
		p->drawText(rc, AlignCenter, "usage");
		rc.setRect(t10, y+h1, t11-t10, h2);
		p->drawRect(rc);
		p->drawText(rc, AlignCenter, "soft");
		rc.setRect(t11, y+h1, t12-t11, h2);
		p->drawRect(rc);
		p->drawText(rc, AlignCenter, "hard");
	}
	
	p->setBrush(NoBrush);
	y+=h;
}

void MainDlg::entry(QPainter *p, int ix)
{	bool b;
	int h2;
	
	QRect rc;
	QFont font1("times", 10);
	QFont font2("helvetica", 10, QFont::Bold);
	QFont font3("times", 7);
	
	h2=h/2;
	u_liste.at((int)u_index.at(ix));
	
	rc.setRect(t0, y, t1-t0, h);
	p->drawRect(rc);
	rc.setRight(t1-5);
	p->setFont(font1);
	p->drawText(rc, AlignRight|AlignVCenter, QString().setNum(ix+1));

	rc.setRect(t1, y, t2-t1, h);
	p->drawRect(rc);
	rc.setLeft(t1+5);
	p->setFont(font2);
	p->drawText(rc, AlignLeft|AlignVCenter, u_liste.name());

	rc.setRect(t2, y, t3-t2, h);
	p->drawRect(rc);
	rc.setLeft(t2+5);
	p->setFont(font1);
	p->drawText(rc, AlignLeft|AlignVCenter, g_liste.gidToName(u_liste.gid()));
	
	rc.setRect(t3, y, t4-t3, h);
	p->drawRect(rc);
	rc.setLeft(t3+5);
	p->setFont(font2);
	p->drawText(rc, AlignLeft|AlignVCenter, u_liste.cname());
	
	rc.setRect(t4, y, t5-t4, h);
	p->drawRect(rc);
	rc.setRect(t4, y, t5-t4, h2);
	rc.setLeft(t4+5);
	p->setFont(font3);
	p->drawText(rc, AlignLeft|AlignVCenter, u_liste.cext1());

	rc.setRect(t4, y+h2, t5-t4, h2);
	rc.setLeft(t4+5);
	p->setFont(font3);
	p->drawText(rc, AlignLeft|AlignVCenter, u_liste.cext2());

	rc.setRect(t5, y, t6-t5, h);
	p->drawRect(rc);
	rc.setLeft(t5+5);
	p->setFont(font1);
	p->drawText(rc, AlignLeft|AlignVCenter, date(u_liste.expire()));
	
	if(isquota)
	{	quotadata *qd;
	
		b=(u_liste.uid()>=QUIDMIN && u_liste.uid()<=QUIDMAX);
		if(b) u_liste.getquota(&qd);
		
		if(qd->fcur<qd->fsoft) p->setFont(font1); else p->setFont(font2);
		rc.setRect(t6, y, t7-t6, h);
		p->drawRect(rc);
		rc.setRight(t7-5);
		if(b) p->drawText(rc, AlignRight|AlignVCenter, QString().setNum(qd->fcur));
		rc.setRect(t7, y, t8-t7, h);
		p->drawRect(rc);
		rc.setRight(t8-5);
		if(b) p->drawText(rc, AlignRight|AlignVCenter, QString().setNum(qd->fsoft));	
		rc.setRect(t8, y, t9-t8, h);
		p->drawRect(rc);
		rc.setRight(t9-5);
		if(b) p->drawText(rc, AlignRight|AlignVCenter, QString().setNum(qd->fhard));	
		
		if(qd->icur<qd->isoft) p->setFont(font1); else p->setFont(font2);
		rc.setRect(t9, y, t10-t9, h);
		p->drawRect(rc);
		rc.setRight(t10-5);
		if(b) p->drawText(rc, AlignRight|AlignVCenter, QString().setNum(qd->icur));
		rc.setRect(t10, y, t11-t10, h);
		p->drawRect(rc);
		rc.setRight(t11-5);
		if(b) p->drawText(rc, AlignRight|AlignVCenter, QString().setNum(qd->isoft));	
		rc.setRect(t11, y, t12-t11, h);
		p->drawRect(rc);
		rc.setRight(t12-5);
		if(b) p->drawText(rc, AlignRight|AlignVCenter, QString().setNum(qd->ihard));	
	}

	y+=h;
}
