#include "implist.h"


QString line;


char informat[20][2],
	 outformat[20][2];

char flag;
int def_gid;

QString	nname, vname, user,
		dgroup, group,
		dhome, home,
		hdir,
		dshell, shell,
		dadr, adr,
		dtel, tel,
		drem, rem;

int 	dmode, mode;
long int dfsoft, fsoft,
		 dfhard, fhard,
		 disoft, isoft,
		 dihard, ihard;

time_t dtexpire, texpire,
	   dtfixed, tfixed,
	   dtchange, tchange,
	   dtwarn, twarn,
	   dtinact, tinact;


int implist(const char *fname)
{	int gid, uid;
	QString outfname(fname);
	QFile infile(fname);
	
	outfname.insert(outfname.findRev('.')+1, 'n');
	QFile outfile((const char *)outfname);
	
	if(infile.open(IO_ReadOnly) == 0) return 1;
	if(outfile.open(IO_WriteOnly) == 0) return 2;


	char str[200];
	QTextStream cin(&infile), cout(&outfile);

	informat[0][0]=outformat[0][0]=0;
	dtexpire=def_expire;
	dtchange=def_change;
	dtfixed=def_fixed;
	dtwarn=def_warn;
	dtinact=def_inact;
	
	dfsoft=def_fsoft;
	dfhard=def_fhard;
	disoft=def_isoft;
	dihard=def_ihard;
	today=time(0)/86400;

	dhome=def_home;
	dmode=createmode;
	dshell=def_shell;
	def_gid=100;
	
	while(!cin.eof())
	{	int err;

		line=cin.readLine();
		line=line.stripWhiteSpace();

		switch(line[0])
		{  case   0:
		   case '#':
		   case ';':	//cout<<line<<'\n';
		   				continue;
		   				
		   case 'g':
		   case 'G':	if(!isspace(line[1])) break;
		  
		   				line.remove(0,1);
		   				if(getentry())
						{	infile.close();
							outfile.close();
							return 5;			// error
						}
						
		   				dgroup=group;
		   				dhome=home;
		   				dshell=shell;
		   				dadr=adr;
		   				dtel=tel;
		   				drem=rem;
		   				dtexpire=texpire;
		   				dtchange=tchange;
		   				dtfixed=tfixed;
		   				dtwarn=twarn;
		   				dtinact=tinact;
		   				dfsoft=fsoft;
		   				dfhard=fhard;
		   				disoft=isoft;
		   				dihard=ihard;
		   				continue;
		   case 'i':
		   case 'I':	if(!isspace(line[1])) break;
		  
		   				if(getformat(informat))
		   				{	infile.close();
							outfile.close();
							return 3;			// error
						}
						
		   				continue;
		   case 'o':
		   case 'O':	if(!isspace(line[1])) break;

		  				if(getformat(outformat))
		   				{	infile.close();
							outfile.close();
							return 4;			// error
						}
						
		   				continue;
		}

		if(informat[0][0]==0) return 6;
		
		err=getentry();
		if(user.isEmpty()) user=nname;
		flag=(mkuname(&user))? '*': ' ';
		if(user.isEmpty()) err=1;
		if(err)
		{	cout<<"; Error:  "<<line<<'\n';
			continue;
		}

		if(group.isEmpty()) group=dgroup;
		if(group.isEmpty()) gid=def_gid;	
		else
		{	if(g_liste.getgroup(group)==NULL)	// create new group
			{	char s[]="*:*:0:\n";
				Group *grp=(Group *)new Group(s);

				g_liste.append(grp);
				grp->g_name=group;
				grp->g_gid=g_liste.getfreegid();
				g_liste.sort();
			}

			gid=g_liste.gid();
		}
		
		hdir=home+'/'+user;

		uid=u_liste.getfreeuid();
		u_liste.append(new User(user, uid));
		u_liste.setpasswd("");
		u_liste.setgid(gid);
		u_liste.setdir(hdir);
		u_liste.setshell(shell);
		u_liste.setcname(vname+' '+nname);
		u_liste.setcext1(adr);
		u_liste.setcext2(tel);
		u_liste.setcext3(rem);

		texpire+=today;
		if(texpire<=today) texpire=today+dtexpire;
		if(tchange==0 || tchange<=today) tchange=today+dtchange;
		if(tchange>texpire) tchange=texpire;
	
		if(tfixed==0 || tfixed<=today || tfixed>tchange) tfixed=today+dtfixed;
		if(twarn==0 || twarn<=today || twarn>tchange) twarn=tchange-dtwarn;
		if(tinact==0 || tinact<tchange) tinact=tchange+dtinact;
		if(tinact>texpire) tinact=texpire;
	
		u_liste.setlstchg(today);
		u_liste.setexpire(texpire);
		u_liste.setmin(tfixed-today);
		u_liste.setmax(tchange-today);
		u_liste.setwarn(tchange-twarn);
		u_liste.setinact(tinact-tchange);
		
		if(isquota)
		{	quotadata *qd;
		
			u_liste.getquota(&qd);
			qd->fcur=qd->icur=0;
			qd->fsoft =fsoft;
			qd->fhard =fhard;
			qd->isoft =isoft;
			qd->ihard =ihard;
		}

		// create home-dir
		sprintf(str, "cp -a /etc/skel/ %s\n", (const char *)hdir);
		system(str);

		// execute createscript
		if(!def_createscript.isEmpty())
		{	sprintf(str, "%s %s %s '%s'\n", (const char *)def_createscript,
									    	(const char *)u_liste.name(),
									    	(const char *)g_liste.gidToName(gid),
									    	(const char *)u_liste.cname());
			//printf("%s\n", str);
			system(str);
		}

		sprintf(str, "chmod %03o %s\n", mode, (const char *)hdir);
		system(str);
		sprintf(str, "chown -R %u.%u %s\n", uid, gid, (const char *)hdir);
		system(str);
		
		putentry(&cout);
	}

	infile.close();
	outfile.close();
	u_liste.sort(sortmode);
	ischanged=1;
	return 0;
}

int getformat(char format[20][2])
{	int i, ie, ix;

	line=line.simplifyWhiteSpace();
	if((i=line.find('"'))==-1) return 1;		// error
	if((ie=line.find('"', ++i))==-1) return 1;

	ix=0;
	while(i<ie)
	{	switch(line[i])
		{  case '*':	++i;
						format[ix][0]=1;
						break;
						
		   case 'f':	if(line.mid(i, 5)=="fsoft")
						{	i+=5;
							format[ix][0]=6;
							break;
						}
						else if(line.mid(i, 5)=="fhard")
						{	i+=5;
							format[ix][0]=7;
							break;
						}
						else if(line.mid(i, 5)=="fixed")
						{	i+=5;
							format[ix][0]=16;
						}
						else return 1;

		   case 'i':	if(line.mid(i, 5)=="isoft")
						{	i+=5;
							format[ix][0]=8;
							break;
						}
						else if(line.mid(i, 5)=="ihard")
						{	i+=5;
							format[ix][0]=9;
							break;
						}
						else if(line.mid(i, 5)=="inact")
						{	i+=5;
							format[ix][0]=19;
						}
						else return 1;
										
		   case 'n':	if(line.mid(i, 5)!="nname") return 1;
						i+=5;
						format[ix][0]=2;
						break;
						
		   case 'v':	if(line.mid(i, 5)!="vname") return 1;
						i+=5;
						format[ix][0]=3;
						break;

		   case 'u':	if(line.mid(i, 4)!="user") return 1;
						i+=4;
						format[ix][0]=4;
						break;
						
		   case 'g':	if(line.mid(i, 5)!="group") return 1;
						i+=5;
						format[ix][0]=5;
						break;

		   case 'a':	if(line.mid(i, 3)!="adr") return 1;
						i+=3;
						format[ix][0]=10;
						break;

		   case 't':	if(line.mid(i, 3)!="tel") return 1;
						i+=3;
						format[ix][0]=11;
						break;
						
		   case 'r':	if(line.mid(i, 3)!="rem") return 1;
						i+=3;
						format[ix][0]=12;
						break;
						
		   case 'h':	if(line.mid(i, 4)!="home") return 1;
						i+=4;
						format[ix][0]=13;
						break;

		   case 's':	if(line.mid(i, 5)!="shell") return 1;
						i+=5;
						format[ix][0]=14;
						break;

		   case 'e':	if(line.mid(i, 6)!="expire") return 1;
						i+=6;
						format[ix][0]=15;
						break;

		   case 'c':	if(line.mid(i, 6)!="change") return 1;
						i+=6;
						format[ix][0]=17;
						break;

		   case 'w':	if(line.mid(i, 4)!="warn") return 1;
						i+=4;
						format[ix][0]=18;
						break;
		   case 'm':	if(line.mid(i, 4)!="mode") return 1;
						i+=4;
						format[ix][0]=20;
						break;							
		}
		if(line[i]=='"') format[ix][1]='\n';
		else 
		{	format[ix][1]=line[i];
			if(line[++i]==' ') ++i;
		}
		++ix;
	}

	format[ix][0]=0;
	return 0;	
}

int getentry()
{	char entry;
	int i, i0, ix;

	i=i0=ix=0;	
	nname.resize(0);
	vname.resize(0);
	user.resize(0);
	group.resize(0);
	home=dhome;
	shell=dshell;
	adr=dadr;
	tel=dtel;
	rem=drem;
	fsoft=dfsoft;
	fhard=dfhard;
	isoft=disoft;
	ihard=dihard;
	texpire=dtexpire;
	tchange=dtchange;
	tfixed=dtfixed;
	twarn=dtwarn;
	tinact=dtinact;

	line=line.simplifyWhiteSpace();	
	//line+='\n';
	while((entry=informat[ix][0]))
	{	switch(entry)
		{  case 1:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					break;
		   case 2:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					nname=line.mid(i0, i-i0);
					break;
		   case 3:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					vname=line.mid(i0, i-i0);
					break;
		   case 4:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					user=line.mid(i0, i-i0);
					break;
		   case 5:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					group=line.mid(i0, i-i0);
					break;
		   case 6:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					fsoft=line.mid(i0, i-i0).toLong();
					break;
		   case 7:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					fhard=line.mid(i0, i-i0).toLong();
					break;
		   case 8:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					isoft=line.mid(i0, i-i0).toLong();
					break;
		   case 9:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					ihard=line.mid(i0, i-i0).toLong();
					break;
		   case 10:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					adr=line.mid(i0, i-i0);
					break;
		   case 11:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					tel=line.mid(i0, i-i0);
					break;
		   case 12:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					rem=line.mid(i0, i-i0);
					break;	
		   case 13:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					home=line.mid(i0, i-i0);
					break;
		   case 14:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					shell=line.mid(i0, i-i0);
					break;
		   case 15:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					texpire=line.mid(i0, i-i0).toLong();
					break;
		   case 16:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					tfixed=line.mid(i0, i-i0).toLong();
					break;
		   case 17:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					tchange=line.mid(i0, i-i0).toLong();
					break;
		   case 18:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					twarn=line.mid(i0, i-i0).toLong();
					break;
		   case 19:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					tinact=line.mid(i0, i-i0).toLong();
					break;
		   case 20:	if((i=line.find(informat[ix][1], i0))==-1) i=200;
					mode=getmode(line.mid(i0, i-i0));
					break;
		}

		if(i==200) break;
		
		++ix;
		i0=(line[++i]==' ')? i+1: i;
	}
	
	return 0;
}

int putentry(QTextStream *cout)
{	char entry, sep;
	int ix=0;
	QString str;

	*cout<<flag<<"  ";
	while((entry=outformat[ix][0]))
	{	if((sep=outformat[ix][1])=='\n') sep=' '; 
		switch(entry)
		{  case 2:	str=nname+sep;
		   			*cout<<str.leftJustify(14)<<' ';
					break;
		   case 3:	str=vname+sep;
		   			*cout<<str.leftJustify(14)<<' ';
					break;
		   case 4:	str=user+sep;
		   			*cout<<str.leftJustify(8)<<' ';
					break;
		   case 5:	str=group+sep;
		   			*cout<<str.leftJustify(8)<<' ';
					break;
		}

		++ix;
	}

	*cout<<'\n';
	return 0;
}

int mkuname(QString *name)
{	char c='2';
	uint len;
	QString str;

	str=name->left(8).lower();
	name->replace(QRegExp("�"), "ae");
	name->replace(QRegExp("�"), "oe");
	name->replace(QRegExp("�"), "ue");
	name->replace(QRegExp("�"), "ss");
	*name=name->left(8).lower();
	len=name->length();

	while(u_liste.getuser(*name)!=0)			// user exists
	{	if(len>4) *name=name->left(--len);
		else *name=name->left(len)+c++;
	}

	if(*name==str) return 0;					// uname=nname.lower
	else return 1;								// uname changed
}

int getmode(QString mstr)
{	
	int i, mode;

	if((mode=strtol(mstr, 0, 8))==0)
	{	if(mstr.find(QRegExp("[^r^w^x^\\-^\\x20]"))==-1)
		{	while((i=mstr.find(' '))!=-1) mstr.remove(i, 1);
			mstr.replace(QRegExp("[rwx]"), "1");
			mstr.replace(QRegExp("-"), "0");
			mode=strtol(mstr, 0, 2);
		}
		else  mode=0;
	}

	return (mode==0)? dmode: mode;
}
