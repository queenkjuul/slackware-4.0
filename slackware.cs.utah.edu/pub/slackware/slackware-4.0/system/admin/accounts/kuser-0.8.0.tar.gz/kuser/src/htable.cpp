#include "htable.h"
#include "htable.moc"



Header::Header(int cols, QWidget *parent, const char *name) : QTableView(parent, name)
{	title=new QString[cols];

	setNumRows(1);
	setNumCols(cols);
	setTableFlags(Tbl_smoothScrolling);
	setFrameStyle(Panel | Sunken);
	setBackgroundColor(lightGray);
	setCellWidth(0);
	setCellHeight(19);
	setAutoUpdate(TRUE);
}

Header::~Header()
{	delete[] title;
}

void Header::paintCell(QPainter *p, int, int col)
{	QRect rc(1, 1, cellWidth(col)-1, 17);
	QColor fg1, fg2;
	
	if(col==tbl->colselected) {fg1=black; fg2=white;}
	else {fg1=white; fg2=black;}
	p->setPen(fg1);
	p->setBrush(QBrush(lightGray));
	p->drawRect(rc);
	p->setPen(fg2);
	p->drawLine(1, 17, rc.width(), 17);
	p->lineTo(rc.width(), 1);
	p->setPen(QPen(black));
	if(col==tbl->colselected) p->drawText(6, 14, title[col]);
	else p->drawText(5, 13, title[col]);
}

void Header::mousePressEvent(QMouseEvent *e)
{	int id, ix;

	if(e->button() == RightButton)
	{	QPopupMenu menu;
		
		menu.move(mapToGlobal(e->pos()));
		menu.setCheckable(TRUE);
		for(ix=0; ix<tbl->cols; ++ix)
		{	id=menu.insertItem(title[ix]);
			menu.setItemChecked(id, (tbl->colWidths[ix]>0)); 
		}
		
		if((id=menu.exec())!=-1)
		{	ix=menu.idAt(id);
			tbl->colWidths[ix]=-tbl->colWidths[ix];
			tbl->updateTableSize();
			updateTableSize();
			tbl->repaint();
			repaint();
		}
	}
	else if(e->button() == LeftButton)
	{	tbl->colselected=findCol(e->pos().x());
		tbl->emit_hdLeftClicked(tbl->colselected);
		repaint();
	}
}


// Slots

int Header::cellWidth(int col)
{	return tbl->cellWidth(col);
}


void Header::scrollSideways(int val)
{	setXOffset(val);
}



////////////////////////////////////////////////////////////////

HTable::HTable(int rows, int cols, QWidget *parent, const char *name) : QTableView(parent, name)
{	int i;
	hd=new Header(cols, parent);
	hd->tbl=this;
	cell=new CellData[cols*rows];
	colWidths=new int[cols];
	rowSelected=new bool[rows];
	
	setNumRows(HTable::rows=rows);
	setNumCols(HTable::cols=cols);
	setTableFlags(Tbl_smoothScrolling | Tbl_autoScrollBars);
	setFrameStyle(Panel | Sunken);
	setBackgroundColor(background=QColor(240, 240, 240));
	setCellWidth(0);
	setCellHeight(15);
	setAutoUpdate(TRUE);
	((QScrollBar *)horizontalScrollBar())->setTracking(TRUE);
	
	connect(horizontalScrollBar(), SIGNAL(valueChanged(int)),
	        hd, SLOT(scrollSideways(int)));

	for(i=0; i<rows; ++i) rowSelected[i]=FALSE;
	colselected=-1;
}

HTable::~HTable()
{	delete hd;
	delete[] cell;
	delete[] colWidths;
	delete[] rowSelected;
}

void HTable::setGeometry(int x, int y, int w, int h)
{	QTableView::setGeometry(x, y+20, w, h-20);
}

void HTable::clear()
{	for(int i=0; i<cols*rows; ++i)
	{	cell[i].text="";
		cell[i].fg=QColor(black);
		cell[i].bg=background;
		cell[i].tf=AlignLeft | AlignBottom;
	}
}

void HTable::initCol(int col, const char *str, int width)
{	if(col<0 || col>=cols) return;

	hd->title[col]=str;
	colWidths[col]=width;
}

int HTable::colEnabled(int col)
{	return (colWidths[col]<0)? 0: 1;
}

void HTable::setCell(int row, int col, const char *text, QColor *fg, QColor *bg, int tf)
{	if(row<0 || row>=rows || col<0 || col>=cols) return;

	if(text!=0) cell[idx(row, col)].text=text;
	if(fg!=0) cell[idx(row, col)].fg=*fg;
	if(bg!=0) cell[idx(row, col)].bg=*bg;
	if(tf!=0) cell[idx(row, col)].tf=tf | AlignBottom;
}
void HTable::resizeEvent(QResizeEvent *)
{	QRect rc=geometry();
	
	rc.setHeight(20);
	rc.moveBy(0, -20);
	hd->setGeometry(rc);
	updateTableSize();
}

void HTable::paintEvent(QPaintEvent *e)
{	QTableView::paintEvent(e);
}

void HTable::paintCell(QPainter *p, int row, int col)
{	QColor bg;

	if(rowSelected[row]) bg=blue;
	else bg=cell[idx(row, col)].bg;
	if(col==colselected) bg=bg.dark(110);
	p->setBackgroundColor(bg);
	p->eraseRect(0, 0, cellWidth(col)-1, cellHeight(row)-1);
	p->setPen(QPen(white));
	p->drawLine(0, cellHeight(row)-1, cellWidth(col)-1, cellHeight(row)-1);
	p->lineTo(cellWidth(col)-1, 0);
	p->setPen(QPen(cell[idx(row, col)].fg));
	p->drawText(5, 1, cellWidth(col)-10, cellHeight(row)-1,
		    cell[idx(row, col)].tf, cell[idx(row, col)].text);
	p->setBackgroundColor(background);
}

void HTable::updateRow(int row)
{	for(int col=0; col<cols; col++)	updateCell(row, col);
}

void HTable::mousePressEvent(QMouseEvent *e)
{	int col, row;

	col=findCol(e->pos().x());
	row=findRow(e->pos().y());
	if(col==-1 || row==-1) return;
	
	if(e->button() == LeftButton)
	{	rowSelected[row]=!rowSelected[row];
		if(!(e->state() & ShiftButton))
		{	for(int r=0; r<rows; ++r)
			{	if(r!=row) rowSelected[r]=FALSE;
				else rowSelected[row]=TRUE;
			}
			repaint();
		}
		updateRow(frow=prow=row);
	}
	else if(e->button() == RightButton) emit rightClicked(col);
}

void HTable::mouseReleaseEvent(QMouseEvent *)
{	killTimers();
	autoscrolling=FALSE;	// no more autoscrolling
}

void HTable::mouseMoveEvent(QMouseEvent *e)
{	int row;
	
	if(e->state() == RightButton) return;
	
	row=findRow(e->pos().y());
	if(row == -1)
	{	if(!autoscrolling)
		{	scrolldir=(e->pos().y() < 5) ? UP : DOWN;
			killTimers();
			startTimer(scroll_delay);
			autoscrolling=TRUE;
		}
	}
	else
	{	killTimers();
		autoscrolling=FALSE;
		
		if(row != prow)
		{	if(abs(frow-row) > abs(frow-prow)) rowSelected[row]=TRUE;
			else
			{	rowSelected[prow]=FALSE;
				updateRow(prow);
			}
			updateRow(prow=row);
		}
	}
}

void HTable::timerEvent(QTimerEvent *)
{	if(!autoscrolling) return;
	
	if(scrolldir==UP)
	{	setYOffset(yOffset()-2);
		rowSelected[prow=topCell()]=TRUE;
    	}
    	else
    	{	int r;
    	
    		setYOffset(yOffset()+2);
    		if((r=lastRowVisible())!=-1) rowSelected[prow=r]=TRUE;
    	}
}

void HTable::setCellWidth(int width)
{	QTableView::setCellWidth(width);
}

void HTable::emit_hdLeftClicked(int col)
{	emit hdLeftClicked(col);
}


// Slots

int HTable::cellWidth(int col)
{	return (colWidths[col]<0)? 0: colWidths[col];
}

