/**********************************************************************

	--- Qt Architect generated file ---

	File: PwdChgDlg.h
	Last generated: Mon Feb 16 21:58:32 1998

 *********************************************************************/

#ifndef PwdChgDlg_included
#define PwdChgDlg_included

#include "PwdChgDlgData.h"
#include "htable.h"
#include "UserData.h"


class PwdChgDlg : public PwdChgDlgData
{
	Q_OBJECT

public:

	PwdChgDlg(QWidget* parent=NULL, const char* name=NULL);
    	virtual ~PwdChgDlg();
  

	HTable *tbl;
    	
    	
protected slots:
	
	void onset();
	void oncancel();
	void onpwd(bool);


private:


};
#endif // PwdChgDlg_included

