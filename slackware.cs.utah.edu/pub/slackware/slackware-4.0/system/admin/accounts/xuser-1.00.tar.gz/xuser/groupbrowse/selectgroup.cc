#include "../xuser.h"

void select_group(FL_OBJECT *browser, long arg)
{
    char
        buffer[80];

    if
    (
        sscanf
        (
            fl_get_browser_line
            (
                browser,
                fl_get_browser(browser)
            ),
            " %[^:]", buffer
        ) == 1
    )
    {
        fl_set_input(gid, buffer);
        set_gid();
    }

    close_gp_browser(browser, 0);
    fl_set_object_focus(f_main, gid);       // allow immediate respec.
}
