#include "forms.h"

void f_password(void)
{
    FL_OBJECT
        *obj;

    f_passwd = fl_bgn_form(FL_NO_BOX, 260, 180);

    obj = fl_add_box(FL_UP_BOX,0,0,260,180,"");
    fl_set_object_color(obj,FL_BLUE,FL_COL1);

    obj = fl_add_box(FL_UP_BOX,30,50,200,110,"");
    fl_set_object_color(obj,FL_TOP_BCOL,FL_COL1);

    pwd1group = fl_bgn_group();
        pwdinput1 = fl_add_input(FL_SECRET_INPUT,70,80,120,30, nullstring);
        obj = fl_add_text(FL_NORMAL_TEXT,40,120,180,30, "Enter Password");
        fl_set_object_color(obj,FL_TOP_BCOL,FL_COL1);
    fl_end_group();

    pwd2group = fl_bgn_group();
        pwdinput2 = fl_add_input(FL_SECRET_INPUT,70,80,120,30, nullstring);
        obj = fl_add_text(FL_NORMAL_TEXT,40,120,180,30, "Re-enter Password");
        fl_set_object_color(obj,FL_TOP_BCOL,FL_COL1);
    fl_end_group();

    cancel_passwd =
            fl_add_button(FL_NORMAL_BUTTON,10,10,50,30,"Dismiss");

    no_shadow_entry = 
            fl_add_button(FL_NORMAL_BUTTON,65,10,90,30, "No shadow entry");

    nopasswd = fl_add_button(FL_NORMAL_BUTTON,160,10,90,30,"Clear Password");

    fl_end_form();
}
