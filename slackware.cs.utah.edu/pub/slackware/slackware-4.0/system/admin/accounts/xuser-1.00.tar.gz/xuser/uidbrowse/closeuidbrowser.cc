#include "uid.h"

void close_uid_browser(FL_OBJECT *ob, long arg)
{
    fl_hide_form(f_browseuid);
    fl_set_object_focus(f_main, uid);
    fl_activate_form(f_main);
}
