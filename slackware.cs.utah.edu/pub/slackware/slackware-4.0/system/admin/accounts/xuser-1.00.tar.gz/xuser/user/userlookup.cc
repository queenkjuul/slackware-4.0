#include "user.h"

USER_ *user_lookup(char const *name)
{
    for (USER_ *tmp = user; tmp < user + nusers; tmp++)
    {
        if (!strcmp(tmp->p_name, name))         // name found ?
            return (tmp);                       // return structure's address
    }
    return (0);                                 // not found
}
