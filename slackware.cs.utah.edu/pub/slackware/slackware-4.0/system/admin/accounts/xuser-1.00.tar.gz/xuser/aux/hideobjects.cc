#include "aux.h" 

void hide_objects()
{
    if (!hidden_objects)
    {
        hidden_objects++;
        fl_hide_object(hide_group);
        fl_hide_object(button_group);
    }
}
