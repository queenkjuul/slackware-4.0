#include "../xuser.h"

void shadow_cp(USER_ *, spwd const *);      // copy fields of a shadow struct
