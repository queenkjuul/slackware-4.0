#include "cb.h"

void cb_getpw1(FL_OBJECT *ob, long arg)
{
    defstr(pwd, ob);

    fl_hide_object(pwd1group);
    fl_set_input(pwdinput2, nullstring);
    fl_show_object(pwd2group);
    fl_set_object_focus(f_passwd, pwdinput2);
}
