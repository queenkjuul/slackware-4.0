/* Form definition file generated with fdesign. */

#include "forms.h"
#include "browse.h"

FD_shellbrowser *create_form_shellbrowser(void)
{
  FL_OBJECT *obj;
  FD_shellbrowser *fdui = (FD_shellbrowser *) fl_calloc(1, sizeof(FD_shellbrowser));

  fdui->shellbrowser = fl_bgn_form(FL_NO_BOX, 240, 280);
  obj = fl_add_box(FL_UP_BOX,0,0,240,280,"");
    fl_set_object_color(obj,FL_PALEGREEN,FL_COL1);

  browserdone = fl_add_button(FL_NORMAL_BUTTON,40,10,160,40,"Dismiss");
    fl_set_object_color(obj,FL_DARKCYAN,FL_COL1);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);

  shellbrowser = fl_add_browser(FL_SELECT_BROWSER,20,60,200,160,"");
  fl_load_browser(shellbrowser, "/etc/shells");

  obj = fl_add_text(FL_NORMAL_TEXT,30,230,180,40,"Select A Shell");
    fl_set_object_color(obj,FL_PALEGREEN,FL_PALEGREEN);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);

  fl_end_form();

  return fdui;
}

