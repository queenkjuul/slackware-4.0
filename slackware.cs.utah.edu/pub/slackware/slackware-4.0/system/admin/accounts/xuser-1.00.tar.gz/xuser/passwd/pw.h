#include "../xuser.h"

passwd const *pwstruct(USER_ *up);
void    user_keep(passwd *pw);              // insert from /etc/passwd to keep
void    set_comment(USER_ *,            // set user-comment fields
                    char const *);
char    *cfield(char const *&src);      // get next comment field
