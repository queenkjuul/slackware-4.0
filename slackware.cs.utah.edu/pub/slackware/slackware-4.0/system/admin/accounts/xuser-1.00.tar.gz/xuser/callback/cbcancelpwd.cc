#include "cb.h"

void cb_cancelpwd(FL_OBJECT *ob, long arg)
{
    if (arg)
    {
        delete up->s_pwd;
        up->s_pwd = 0;
    }
    fl_hide_form(f_passwd);
    fl_activate_object(ssetpw);
}

