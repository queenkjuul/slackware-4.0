#include "aux.h"

void alert(char const *s1, char const *s2)
{
    fl_show_alert(s1, s2, nullstring, 1);
}
