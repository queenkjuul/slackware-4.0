#include "../xuser.h"
#include <sys/stat.h>
#include <unistd.h> 
#include <glob.h>

void    process(char *pattern);                 // glob dir && process entries
void    rm_dir(char *entry);
