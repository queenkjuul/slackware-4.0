#include "aux.h"

void shrink (char *&str)
{
    int
        len = strlen(str);

    if (*str == '"')
    {
        memmove(str, str + 1, len--);           // copies including asciiz
        if (str[len - 1] == '"')
            str[--len] = 0;
    }

    str = (char *)realloc(str, len + 1);
}
