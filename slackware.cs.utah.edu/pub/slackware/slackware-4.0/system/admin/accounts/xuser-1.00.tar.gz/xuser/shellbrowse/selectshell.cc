#include "shell.h"

void select_shell(FL_OBJECT *browser, long arg)
{
    fl_set_input
    (
        shell,
        fl_get_browser_line(browser,
                            fl_get_browser(browser))
    );
    set_shell();

    close_shell_browser(browser, 0);
    fl_set_object_focus(f_main, shell);
}
