#include "aux.h"

static char
    buffer[20];

char const *itoa(int x)
{
    return
    (
        x >= 0
        &&
        sprintf(buffer, "%d", x) > 0 ?
            buffer
        :
            nullstring
    );
}
