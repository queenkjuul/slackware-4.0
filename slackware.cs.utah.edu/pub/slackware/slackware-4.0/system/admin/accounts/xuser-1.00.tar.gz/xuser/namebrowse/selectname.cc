#include "name.h"

void select_name(FL_OBJECT *browser, long arg)
{
    char
        buffer[80];
    int
        dummy;

    if (!arg)
        sscanf(fl_get_browser_line(browser,
                            fl_get_browser(browser)), "%s", buffer);
    else
        sscanf(fl_get_browser_line(browser,
                            fl_get_browser(browser)), "%d - %s", &dummy,
                                                                 buffer);
    fl_set_input(name, buffer);
    uid_sort();
    close_name_browser(browser, 0);
    cb_name(name, 0);
    fl_set_object_focus(f_main, fullname);
}
