#include "sort.h"

static char
    *np;

void save_up()
{
    np =                                      // save np address if within
        (user <= up && up < user + nusers) ?    // user[]
            up->p_name
        :                                       // otherwise 0
             0;      
}

void restore_up()
{
    if (np)
        up = user_lookup(np);
}
