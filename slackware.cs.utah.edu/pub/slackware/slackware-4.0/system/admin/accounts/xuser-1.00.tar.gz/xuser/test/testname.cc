#include "test.h" 

char const *test_name()
{
    char const
        *cp;

    return
    (
        isalnum(*(cp = fl_get_input(name))) ?
            cp
        :
            0
    );
}
