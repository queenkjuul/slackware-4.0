#ifndef FD_passwd_h_
#define FD_passwd_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/



/**** Forms and Objects ****/

typedef struct {
	FL_FORM *passwd;
	void *vdata;
	long ldata;
} FD_passwd;

extern FD_passwd * create_form_passwd(void);

#endif /* FD_passwd_h_ */
