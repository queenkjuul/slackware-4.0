#include "shell.h"

int lookup_shell(char const *shell)
{
    char const
        *line;
    int
        index = 0;

    while (line = fl_get_browser_line(shellbrowser, ++index))
    {
        if (!strcmp(line, shell))
            return (index);
    }
    return (0);
}
