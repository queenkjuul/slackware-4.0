#include "../xuser.h"

void f_groupbrowser(void)
{
    FL_OBJECT
        *obj;

    f_browsegroup = fl_bgn_form(FL_NO_BOX, 310, 480);

    obj = fl_add_box(FL_UP_BOX,0,0,310,480,"");
    fl_set_object_color(obj,FL_PALEGREEN,FL_COL1);

    obj = fl_add_text(FL_NORMAL_TEXT,70,420,160,40, app_defaults.groups);
    fl_set_object_color(obj,FL_PALEGREEN,FL_PALEGREEN);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);

    leave_groupbrowser = fl_add_button(FL_NORMAL_BUTTON,50,20,210,40,"Dismiss");
    fl_set_object_color(leave_groupbrowser,FL_DARKCYAN,FL_COL1);
    fl_set_object_lsize(leave_groupbrowser,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(leave_groupbrowser,FL_TIMESBOLD_STYLE);

    groupbrowser = fl_add_browser(FL_SELECT_BROWSER,30,70,260,340,"");
    fl_load_browser(groupbrowser, app_defaults.groups);

    fl_end_form();
}
