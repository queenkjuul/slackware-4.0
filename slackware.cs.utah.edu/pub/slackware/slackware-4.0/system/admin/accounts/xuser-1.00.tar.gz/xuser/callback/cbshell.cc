#include "cb.h"

void cb_shell(FL_OBJECT *cb, long arg)
{
    set_shell();                            // redefine the shell
}
