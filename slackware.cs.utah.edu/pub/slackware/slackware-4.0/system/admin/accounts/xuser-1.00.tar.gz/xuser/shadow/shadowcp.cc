#include "shadow.h"

void shadow_cp(USER_ *up, spwd const *src)
{
    up->s_pwd    = strdup(src->sp_pwdp);        // cp the encrypted pwd

    up->sp_lstchg   = src->sp_lstchg;
    up->sp_min      = src->sp_min;
    up->sp_max      = src->sp_max;
    up->sp_warn     = src->sp_warn;
    up->sp_inact    = src->sp_inact;
    up->sp_expire   = src->sp_expire;
    up->sp_flag     = src->sp_flag;
}
