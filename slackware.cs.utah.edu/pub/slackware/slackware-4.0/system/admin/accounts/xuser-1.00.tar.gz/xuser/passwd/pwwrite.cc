#include "pw.h"

void pw_write()
{
    backup(app_defaults.passwd);

    FILE
        *f = xfopen(app_defaults.passwd, w);
    passwd const
        *pw;

    for (int index = 0; index < nusers; index++)
    {
        if (pw = pwstruct(&user[index]))
            putpwent(pw, f);
    }
    fclose(f);
}


    
