#include "cb.h"

void cb_exit(FL_OBJECT *ob, long arg)
{
    cb_save(ob, arg);
    exit (0);
}
