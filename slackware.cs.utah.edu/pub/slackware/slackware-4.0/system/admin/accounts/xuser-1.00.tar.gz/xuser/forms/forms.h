#include "../xuser.h"

void buttons_off();                     // unlight all buttons

