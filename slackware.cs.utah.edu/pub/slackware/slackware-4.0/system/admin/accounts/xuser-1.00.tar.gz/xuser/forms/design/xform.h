#ifndef FD_xuser_h_
#define FD_xuser_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/



/**** Forms and Objects ****/

typedef struct {
	FL_FORM *xuser;
	void *vdata;
	long ldata;
} FD_xuser;

extern FD_xuser * create_form_xuser(void);

#endif /* FD_xuser_h_ */
