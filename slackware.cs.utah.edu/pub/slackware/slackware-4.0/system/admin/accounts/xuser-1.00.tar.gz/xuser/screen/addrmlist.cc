#include "screen.h"

void addrmlist(char const *dir)
{
                                                    // expand rmlist
    rmlist = (char **)realloc(rmlist, (nrmlist + 1) * sizeof(char *));

    char
        *cp;

    rmlist[nrmlist] = cp = strdup(dir);             // add element

    if (cp = dir_sep_end(cp))                       // remove trailing /
        *cp = 0;

    cp = rmlist[nrmlist];                           // pointer to last element

    for (int idx = 0; idx < nrmlist; idx++)         // look for double entries
    {
        if (!strcmp(cp, rmlist[nrmlist]))           // string found
            break;                                  // stop looking further
    }

    if
    (
        !strlen(cp)                                 // path has no length
        ||
        idx < nrmlist                               // or was already listed
    )                                               
    {
        delete cp;                                  // delete new entry
        return;                                     // no addition
    }
    nrmlist++;                                      // one entry added
    return;
}
