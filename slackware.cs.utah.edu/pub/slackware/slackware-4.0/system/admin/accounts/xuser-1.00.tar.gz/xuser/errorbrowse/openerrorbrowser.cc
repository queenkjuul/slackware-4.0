#include "../xuser.h"

void open_error_browser(FL_OBJECT *button, long arg)
{
    fl_deactivate_object(save_button);
    fl_deactivate_object(accept_button);

    fl_set_form_position(f_browseerror, 0, 0);
    fl_show_form (f_browseerror, FL_PLACE_MOUSE, FL_FULLBORDER, "Error Report");
}


