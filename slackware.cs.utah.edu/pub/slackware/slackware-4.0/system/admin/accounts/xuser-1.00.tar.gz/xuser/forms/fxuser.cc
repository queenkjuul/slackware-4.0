#include "forms.h"

void f_xuser(void)
{
  FL_OBJECT
        *obj;

    f_main = fl_bgn_form(FL_NO_BOX, 470, 460);

    obj = fl_add_box(FL_UP_BOX,0,0,470,460,"");         // main box
    fl_set_object_color(obj,FL_DARKCYAN,FL_LEFT_BCOL);

                                                        // and its text
    obj = fl_add_text(FL_NORMAL_TEXT, 170, 400, 140, 40, "X-User");
    fl_set_object_color(obj, FL_DARKCYAN, FL_LEFT_BCOL);
    fl_set_object_lcol(obj, FL_LEFT_BCOL);
    fl_set_object_lsize(obj, FL_HUGE_SIZE);
    fl_set_object_lstyle(obj, FL_TIMESBOLD_STYLE+FL_ENGRAVED_STYLE);

    copyright = fl_add_text(FL_NORMAL_TEXT,10,410,270,40, release);

    fl_set_object_color(copyright,FL_DARKCYAN,FL_MCOL);

    name        = fl_add_input(FL_NORMAL_INPUT,  180,360,90,40,"");
    name_button = fl_add_button(FL_NORMAL_BUTTON,100,380,80,20,"Names [a-z]");
    fl_set_object_boxtype(name_button,FL_UP_BOX);
    fl_set_object_color(name_button,FL_PALEGREEN,FL_SPRINGGREEN);
    name_0_button = fl_add_button(FL_NORMAL_BUTTON,100,360,80,20,"Names [uid]");
    fl_set_object_boxtype(name_0_button,FL_UP_BOX);
    fl_set_object_color(name_0_button,FL_PALEGREEN,FL_SPRINGGREEN);

    hide_group = fl_bgn_group();

        fl_add_frame(FL_DOWN_FRAME,10,240,310,110,"");

        uid         = fl_add_input(FL_INT_INPUT,    60,300,50,40,"");
        uid_button = fl_add_button(FL_NORMAL_BUTTON,29,310,30,20,"UID");
        fl_set_object_boxtype(uid_button,FL_UP_BOX);
        fl_set_object_color(uid_button,FL_PALEGREEN,FL_SPRINGGREEN);

        gid         = fl_add_input(FL_NORMAL_INPUT,200,300,80,40,"");
        shell       = fl_add_input(FL_NORMAL_INPUT,60,250,80,40,"");
        dir         = fl_add_input(FL_NORMAL_INPUT,200,250,110,40,"Home dir");

        gid_button = fl_add_button(FL_NORMAL_BUTTON,159,310,40,20,"Group");
        fl_set_object_boxtype(gid_button,FL_UP_BOX);
        fl_set_object_color(gid_button,FL_PALEGREEN,FL_SPRINGGREEN);

        shell_button = fl_add_button(FL_NORMAL_BUTTON,19,260,40,20,"Shell");
        fl_set_object_boxtype(shell_button,FL_UP_BOX);
        fl_set_object_color(shell_button,FL_PALEGREEN,FL_SPRINGGREEN);


        fl_add_frame(FL_DOWN_FRAME,               10, 60,390,170,"");

        fullname  = fl_add_input(FL_NORMAL_INPUT, 85,175,230,40,"Name");
        address   = fl_add_input(FL_NORMAL_INPUT, 85,130,130,40,"Home phone");

        office1   = fl_add_input(FL_NORMAL_INPUT, 85, 85,170,40,"Office");
        obj = fl_add_text(FL_NORMAL_TEXT,         85, 65,60,20,"address");
        fl_set_object_color(obj,FL_DARKCYAN,FL_MCOL);
        office2   = fl_add_input(FL_NORMAL_INPUT,255, 85,130,40,"");
        obj = fl_add_text(FL_NORMAL_TEXT,        255, 65,60,20,"phone");
        fl_set_object_color(obj,FL_DARKCYAN,FL_MCOL);


        obj  = fl_add_box(FL_DOWN_BOX,          330,240,130,170,"");
        fl_set_object_color(obj,FL_TOP_BCOL,FL_COL1);

        spwchg = fl_add_input(FL_NORMAL_INPUT,  392,367,60,30, "last pwchg");
        fl_deactivate_object(spwchg);
        smin = fl_add_input(FL_NORMAL_INPUT,    392,337,60,30, "fixed until");
        smax = fl_add_input(FL_NORMAL_INPUT,    392,307,60,30, "chg before");
        swarn = fl_add_input(FL_NORMAL_INPUT,   392,277,60,30, "alert after");
        sinact = fl_add_input(FL_NORMAL_INPUT,  392,247,60,30,"entry until");

        ssetpw = fl_add_button(FL_NORMAL_BUTTON,330,220,130,20,"set password");
        fl_set_object_color(ssetpw,FL_PALEGREEN,FL_SPRINGGREEN);

        obj  = fl_add_box(FL_DOWN_BOX,          330,175,130,45,"");
        fl_set_object_color(obj,FL_TOP_BCOL,FL_COL1);

        sexpire = fl_add_input(FL_NORMAL_INPUT, 392,183,60,30,"expiration");


        fl_add_box(FL_UP_BOX,10,10,265,40,"");

        accept_button = fl_add_button(FL_NORMAL_BUTTON,85,15,60,30,"Accept");
        fl_set_object_color(accept_button,FL_PALEGREEN,FL_TOMATO);
        fl_set_object_lsize(accept_button,FL_MEDIUM_SIZE);
        fl_set_object_lstyle(accept_button,FL_TIMESBOLD_STYLE);

        save_button = fl_add_button(FL_NORMAL_BUTTON,150,15,50,30,"Save");
        fl_set_object_color(save_button,FL_PALEGREEN,FL_TOMATO);
        fl_set_object_lsize(save_button,FL_MEDIUM_SIZE);
        fl_set_object_lstyle(save_button,FL_TIMESBOLD_STYLE);

        exit_button = fl_add_button(FL_NORMAL_BUTTON,205,15,60,30,"& Exit");
        fl_set_object_color(exit_button,FL_PALEGREEN,FL_TOMATO);
        fl_set_object_lsize(exit_button,FL_MEDIUM_SIZE);
        fl_set_object_lstyle(exit_button,FL_TIMESBOLD_STYLE);

    fl_end_group();

    cancel_button = fl_add_button(FL_NORMAL_BUTTON,20,15,60,30,"Cancel");
    fl_set_object_color(cancel_button,FL_PALEGREEN,FL_SPRINGGREEN);
    fl_set_object_lsize(cancel_button,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(cancel_button,FL_TIMESBOLD_STYLE);

    button_group = fl_bgn_group();
        make_button = fl_add_lightbutton(FL_RADIO_BUTTON,280,30,90,20,
                                "Make home");
        fl_set_object_color(make_button,FL_COL1, FL_TOMATO);

        files_ok_button = fl_add_lightbutton(FL_RADIO_BUTTON,280,10,90,20,
                                "Home as-is");
        fl_set_object_color(files_ok_button,FL_COL1, FL_TOMATO);

        delete_button = fl_add_lightbutton(FL_RADIO_BUTTON, 370,30,90,20,
                                "Delete");
        fl_set_object_color(delete_button,FL_COL1, FL_TOMATO);

        rm_rf_button = fl_add_lightbutton(FL_RADIO_BUTTON,370,10,90,20,
                                "rm -rf");
        fl_set_object_color(rm_rf_button,FL_COL1, FL_TOMATO);
    fl_end_group();

    fl_end_form();
}
