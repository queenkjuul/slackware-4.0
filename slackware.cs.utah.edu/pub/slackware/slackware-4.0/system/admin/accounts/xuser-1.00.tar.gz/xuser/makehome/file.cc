#include "m.h"

void file(char *destination, char *entry, int mode)
{
    FILE
        *sf,
        *df;

    if (sf = fopen(entry, r))
    {
        if (df = fopen(destination, w))
        {
            int
                c;

            while ((c = fgetc(sf)) != EOF)
                fputc(c, df);

            fclose(df);
            chmod(destination, mode);
            chown(destination, up->p_uid, up->p_gid);
        }
        fclose(sf);
    }
}
