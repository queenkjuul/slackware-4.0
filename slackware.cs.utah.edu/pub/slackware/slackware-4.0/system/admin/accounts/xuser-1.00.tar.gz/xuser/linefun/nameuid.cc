#include "linefun.h"

static char
    buffer[80];

char const *nameuid(int index)
{
    sprintf(buffer, "%8s - %3d", user[index].p_name,
                                user[index].p_uid);
    return (buffer);
}

    
