#include "../xuser.h"

void close_error_browser(FL_OBJECT *ob, long arg)
{
    fl_hide_form(f_browseerror);
    fl_clear_browser(errorbrowser);

    fl_activate_object(accept_button);
    fl_activate_object(save_button);
}
