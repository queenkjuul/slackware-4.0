#include "test.h"

char const *test_dir()
{
    char const
        *sh = fl_get_input(dir);

    while (*sh && isspace(*sh))                     // skip ws
        sh++;

    return
    (
        *sh ?
            sh
        :
            0
    );
}
