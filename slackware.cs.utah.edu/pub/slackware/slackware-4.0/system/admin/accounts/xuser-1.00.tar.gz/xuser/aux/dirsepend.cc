#include "aux.h"

char *dir_sep_end(char *cp)
{
    return
    (
        (cp = strrchr(cp, '/')) && !*(cp + 1) ?     //  cp -> " ... /" ?
            cp
        :
            0
    );
}
