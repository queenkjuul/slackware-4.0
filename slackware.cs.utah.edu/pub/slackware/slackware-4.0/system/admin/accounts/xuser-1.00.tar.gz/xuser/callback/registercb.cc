#include "cb.h"

void register_cb()
{
    fl_set_object_callback(cancel_button, cb_cancel, 0);    // cancelling
    fl_set_object_callback(accept_button, cb_accept, 0);    // accept info
    fl_set_object_callback(save_button, cb_save, 0);        // save info
    fl_set_object_callback(exit_button, cb_exit, 0);        // save & exit



    fl_set_object_callback(name,  cb_name, 0);              // get the username
    fl_set_object_callback(shell, cb_shell, 0);             // get the shell
    fl_set_object_callback(gid,   cb_gid, 0);               // define group
    fl_set_object_callback(dir,   cb_dir, 0);               // define /home/dir
    fl_set_object_callback(uid,   cb_uid, 0);               // define uid

    fl_set_object_callback(fullname, cb_comment, 0);       // set comment flds
    fl_set_object_callback(office1, cb_comment, 0);
    fl_set_object_callback(office2, cb_comment, 0);
    fl_set_object_callback(address, cb_comment, 0);

    fl_set_object_callback(name_button,                     // a-z name browser
                                    open_name_browser, 0);
    fl_set_object_callback(name_0_button,                   // uid-name browser
                                    open_name_browser, 1);
    fl_set_object_callback(leave_namebrowser,               // close name-browsr
                           close_name_browser, 0);
    fl_set_object_callback(namebrowser, select_name, 0);    // select a name


    fl_set_object_callback(gid_button, open_gp_browser, 0); // open groupbrowsr
    fl_set_object_callback(leave_groupbrowser,              // close gp-browsr
                           close_gp_browser, 0);
    fl_set_object_callback(groupbrowser, select_group, 0);  // select a group

    fl_set_object_callback(uid_button, open_uid_browser, 0);// open uid browser
    fl_set_object_callback(leave_uidbrowser,                // close browser
                            close_uid_browser, 0);
    fl_set_object_callback(uidbrowser, select_uid, 0);      // select a uid

    fl_set_object_callback(leave_errorbrowser,              // close err.browsr
                            close_error_browser, 0);

    fl_set_object_callback(shell_button,                    // open shell brow.
                            open_shell_browser, 0);
    fl_set_object_callback(leave_shellbrowser,              // close it again
                            close_shell_browser, 0);
    fl_set_object_callback(shellbrowser, select_shell, 0);  // select a shell

    fl_set_object_callback(smin, cb_shadowint, u_min);      // shadow fields
    fl_set_object_callback(smax, cb_shadowint, u_max);
    fl_set_object_callback(swarn, cb_shadowint, u_warn);
    fl_set_object_callback(sinact, cb_shadowint, u_inact);
    fl_set_object_callback(sexpire, cb_shadowint, u_expire);

    fl_set_object_callback(ssetpw,  cb_openpw, 0);
    fl_set_object_callback(pwdinput1, cb_getpw1, 0);
    fl_set_object_callback(pwdinput2, cb_getpw2, 0);
    fl_set_object_callback(nopasswd, cb_nopasswd, 0);
    fl_set_object_callback(cancel_passwd, cb_cancelpwd, 0);
    fl_set_object_callback(no_shadow_entry, cb_cancelpwd, 1);
}
