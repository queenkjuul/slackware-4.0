#include "../xuser.h"

int uidcompare(void const *e1, void const *e2)
{
    return
    (
        ((USER_ *)e1)->p_uid - ((USER_ *)e2)->p_uid
    );
}
