#include "shell.h"

void open_shell_browser(FL_OBJECT *button, long arg)
{
    fl_deactivate_object(button);
    fl_set_form_position(f_browseshell, 200, 100);
    fl_show_form (f_browseshell, FL_PLACE_MOUSE, FL_FULLBORDER, "Shell Lookup");
}


