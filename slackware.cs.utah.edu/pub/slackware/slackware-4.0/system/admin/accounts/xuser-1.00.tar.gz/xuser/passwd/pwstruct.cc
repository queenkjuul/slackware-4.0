#include "pw.h"

static char
    buffer[250];
static passwd
    pw;

passwd const *pwstruct(USER_ *up)
{
    pw.pw_name      = up->p_name;
    pw.pw_passwd    = up->p_pwd;
    pw.pw_uid       = up->p_uid;
    pw.pw_gid       = up->p_gid;
    pw.pw_gecos     = buffer;
    sprintf(buffer, "%s,%s,%s,%s",
                        up->c_name,
                        up->c_office1,
                        up->c_office2,
                        up->c_address);
    pw.pw_dir       = up->p_dir;
    pw.pw_shell     = up->p_shell;

    return (&pw);
}

