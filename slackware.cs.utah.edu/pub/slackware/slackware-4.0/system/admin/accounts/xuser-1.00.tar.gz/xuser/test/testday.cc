#include "test.h"

DAY_ test_day(FL_OBJECT *ob)
{
    DAY_
        ret;
    tm
        tmp;
    char const
        *cp;
        
    
    memset(&tmp, 0, sizeof(tm));                // initialize to empty

    if
    (
        sscanf
            (
                cp = fl_get_input(ob),
                "%u/%u/%u", &tmp.tm_year, &tmp.tm_mon, &tmp.tm_mday
            )
        == 3
    )
    {
        tmp.tm_mon--;

        if (tmp.tm_year > 1900)
            tmp.tm_year -= 1900;

                                                // days beyond 70/1/1
        ret.value = (mktime(&tmp) + 24 * 3600 - 1) / (24 * 3600);
        ret.type = d_date;
    }
    else if (sscanf(cp, "%lu", &ret.value) == 1)
        ret.type = d_long;
    else
        ret.type = d_invalid;                   // illegal value

    if (ret.value > today + app_defaults.unlimited)
        ret.value = today + app_defaults.unlimited;

    return (ret);
}
