#include "cb.h"

void cb_accept(FL_OBJECT *ob, long arg)
{
    if (check_screen())                     // see if the screen is ok
        open_error_browser(ob, 0);          // show them
    else
        screen_to_memory();                 // otherwise process them
}
