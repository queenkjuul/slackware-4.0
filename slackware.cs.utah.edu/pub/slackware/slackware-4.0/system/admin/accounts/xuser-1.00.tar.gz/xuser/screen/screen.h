#include "../xuser.h"
#include <unistd.h>

void addrmlist(char const *dest);
void errline(char const *str);
void process(USER_ *up);
USER_   *userdup(USER_ *);                  // dup a user
void    useradd(USER_ *);                   // delete from database
void    userdel(USER_ *);                   // add to database
