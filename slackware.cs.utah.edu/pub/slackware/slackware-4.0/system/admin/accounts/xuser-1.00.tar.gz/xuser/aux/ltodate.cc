#include "aux.h"

static char
    buffer[14];

char const *ltodate(long days)          // days since 1/1/70
{
    tm
        *tmp;

    days *= 24 * 3600;                  // convert to seconds
    tmp = localtime(&days);

    if (tmp->tm_year >= 100)
        tmp->tm_year += 1900;

    sprintf(buffer, "%u/%2.2u/%2.2u",
                    tmp->tm_year,
                    tmp->tm_mon + 1,
                    tmp->tm_mday);

    return (buffer);
}
