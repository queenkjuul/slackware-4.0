#include "sort.h"

void uid_sort()
{                                           // sort by uid's
/*
printf("uidsort\n");

for (int index = 0; index < nusers; index++)
    if (user[index].s_pwd)
        printf("pwd for %d: %s\n", index, user[index].p_name);
*/

    save_up();                              // save info about where up points
    qsort(user, nusers, sizeof(USER_), uidcompare);
    restore_up();                           // restore up again

/*

for (index = 0; index < nusers; index++)
    if (user[index].s_pwd)
        printf("pwd for %d: %s\n", index, user[index].p_name);
*/
}

