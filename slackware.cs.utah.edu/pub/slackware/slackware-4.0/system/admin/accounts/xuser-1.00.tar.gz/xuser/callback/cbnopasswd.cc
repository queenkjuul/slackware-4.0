#include "cb.h"

void cb_nopasswd(FL_OBJECT *ob, long arg)
{
    fl_hide_form(f_passwd);
    fl_activate_object(ssetpw);

    pwchange = today;
    shadowfields();

    strredef(up->s_pwd, nullstring);
}
