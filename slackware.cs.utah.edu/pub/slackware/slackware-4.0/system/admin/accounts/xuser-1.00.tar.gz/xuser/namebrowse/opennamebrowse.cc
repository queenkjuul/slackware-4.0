#include "name.h"

void open_name_browser(FL_OBJECT *button, long arg)
{
    fl_deactivate_object(name_button);
    fl_deactivate_object(name_0_button);
    fl_set_form_position(f_browsename, 200, 100);

    fl_clear_browser(namebrowser);

    if (!arg)
        name_sort(); 
    else
        uid_sort();

    fill_browser
    (
        namebrowser, nusers,
        !arg ?
            nameuid
        :
            uidname
    );
    
    fl_show_form (f_browsename, FL_PLACE_MOUSE, FL_FULLBORDER, "Name Lookup");
}


