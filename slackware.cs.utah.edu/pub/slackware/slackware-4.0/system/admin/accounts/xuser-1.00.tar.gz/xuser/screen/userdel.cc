#include "screen.h"

void userdel(USER_ *x)
{
    nusers--;                               // remove one user
    memmove (x, x + 1, (nusers - (x - user)) * sizeof(USER_));
}
