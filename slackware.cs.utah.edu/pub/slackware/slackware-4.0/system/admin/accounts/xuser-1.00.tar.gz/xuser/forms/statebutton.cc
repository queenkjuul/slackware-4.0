#include "forms.h"

void statebutton(USERSTATE_ state)
{
    buttons_off();

    switch (state)
    {
        case st_make:
            fl_set_button(make_button, 1);
        break;

        case st_files_ok:
            fl_set_button(files_ok_button, 1);
        break;

        case st_delete:
            fl_set_button(delete_button, 1);
        break;

        case st_rm_rf:
            fl_set_button(rm_rf_button, 1);
        break;
    }
}

