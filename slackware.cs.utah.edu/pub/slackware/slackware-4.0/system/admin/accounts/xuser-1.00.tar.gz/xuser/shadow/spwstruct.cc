#include "sdw.h"

static spwd
    s;

spwd *spwstruct(USER_ *up)
{
    if (!up->s_pwd)
    {
//        printf("no shadow entry for %s\n", up->p_name);
        return (0);
    }

    s.sp_namp   = up->p_name;
    s.sp_pwdp   = up->s_pwd;
    s.sp_lstchg = up->sp_lstchg;
    s.sp_min    = up->sp_min;
    s.sp_max    = up->sp_max;
    s.sp_warn   = up->sp_warn;
    s.sp_inact  = up->sp_inact;
    s.sp_expire = up->sp_expire;
    s.sp_flag   = up->sp_flag;

    return (&s);
}
