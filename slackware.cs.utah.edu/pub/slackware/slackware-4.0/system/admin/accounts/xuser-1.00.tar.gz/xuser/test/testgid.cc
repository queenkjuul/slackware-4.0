#include "test.h"
        
int test_gid()
{

    int
        gpid;
    char const
        *group = fl_get_input(gid),
        *gpname;

    return
    (
        (gpid = lookup_gid(group)) >= 0         // name of group given
        ||                                      // or
        (sscanf(group, "%d", &gpid) == 1)       // a number specified
        &&
        gpid >= 0                               // which is positive
        &&                                      // and also
        *(gpname = lookup_group(gpid))          // the name of a group
        ?
            gpid
        :
            -1
    );
}
