#include "forms.h" 

void f_errorbrowser(void)
{
    FL_OBJECT *obj;

    f_browseerror = fl_bgn_form(FL_NO_BOX,  320, 220);

    obj = fl_add_box(FL_UP_BOX,0,0,  320, 220,"");
    fl_set_object_color(obj,FL_DOGERBLUE,FL_COL1);

    errorbrowser = fl_add_browser(FL_NORMAL_BROWSER, 20,50,280,130,"");
    fl_set_object_color(errorbrowser,FL_TOP_BCOL,FL_YELLOW);

    obj = fl_add_text(FL_NORMAL_TEXT,20,190,280,20,"Error Report");

    fl_set_object_color(obj,FL_DOGERBLUE,FL_MCOL);
    fl_set_object_lcol(obj,FL_WHITE);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);

    leave_errorbrowser = fl_add_button(FL_NORMAL_BUTTON,
                                220,10,80,30,"Dismiss");

    fl_set_object_color(leave_errorbrowser,FL_MCOL,FL_COL1);
    fl_set_object_lsize(leave_errorbrowser,FL_NORMAL_SIZE);
                                        
    fl_end_form();
}
