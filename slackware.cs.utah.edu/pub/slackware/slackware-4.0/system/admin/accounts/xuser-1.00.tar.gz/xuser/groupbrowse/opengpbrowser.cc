#include "group.h"

void open_gp_browser(FL_OBJECT *ob, long arg)
{
    fl_deactivate_object(ob);
    fl_set_form_position(f_browsegroup, 0, 0);
    fl_show_form(f_browsegroup, FL_PLACE_MOUSE, FL_FULLBORDER,
            app_defaults.groups);
}


