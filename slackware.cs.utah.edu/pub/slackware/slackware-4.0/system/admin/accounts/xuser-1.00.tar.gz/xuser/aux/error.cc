
#include <stdio.h> 
#include <stdarg.h>

void error (char *fmt, ...)
{
    va_list
    	args;
    	
    va_start (args, fmt);
    vprintf (fmt, args);
    putchar('\n');

    exit (1);
}
    
