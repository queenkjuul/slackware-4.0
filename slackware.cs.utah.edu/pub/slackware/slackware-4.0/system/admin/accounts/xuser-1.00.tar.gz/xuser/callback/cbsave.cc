#include "cb.h"

void cb_save(FL_OBJECT *ob, long arg)
{
    fl_deactivate_object(cancel_button);
    fl_deactivate_object(accept_button);
    fl_deactivate_object(save_button);
    fl_deactivate_object(exit_button);

    if
    (
        !check_screen()                         // screen not saveable
        ||
        fl_show_question("Information on the screen is incomplete.",
                "Ignore the information on the screen ?", nullstring)
    )
    {
// printf("save 0\n");
        screen_to_memory();

// printf("save 1\n");
        pw_write();                             // save the pwd info
// printf("save 2\n");
        sdw_write();                            // save the shadowinfo
// printf("save 3\n");

        rm_rf();                                // rm rmlist[] entries

        USER_
            *up;

        up = user;
        for (int index = 0; index < nusers; index++, up++)
        {
            if (up->state == st_make)
                makehome(up);
        }
    }

    fl_activate_object(cancel_button);
    fl_activate_object(accept_button);
    fl_activate_object(save_button);
    fl_activate_object(exit_button);
}
