#include "screen.h"

void  errline(char const *str)
{
    errors++;
    fl_add_browser_line(errorbrowser, str);
}
