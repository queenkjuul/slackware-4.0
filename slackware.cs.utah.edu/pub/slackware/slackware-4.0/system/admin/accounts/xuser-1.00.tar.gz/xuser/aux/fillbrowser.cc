#include "aux.h"

void fill_browser(FL_OBJECT *browser, int n, char const *(*linefun)(int line))
{
    for (int index = 0; index < n; index++)
        fl_add_browser_line(browser, linefun(index));
}

