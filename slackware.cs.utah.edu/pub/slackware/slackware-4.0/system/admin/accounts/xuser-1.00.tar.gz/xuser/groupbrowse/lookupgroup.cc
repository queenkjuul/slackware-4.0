#include "group.h"

static char 
    groupid[40];

char const *lookup_group(int gid)
{
    char const
        dummy[80],
        *line;
    int
        groupnr;
    
    for
    (
        int index = 1;
        line = fl_get_browser_line(groupbrowser, index);
        index++
    )
    {
        if (sscanf(line, "%[^:]::%d", groupid, &groupnr) != 2)
            sscanf(line, "%[^:]:%[^:]:%d", groupid, dummy, &groupnr);

        if (groupnr == gid)
            return(groupid);
    }

    return (nullstring);
}
