#include "../xuser.h"
#include <sys/stat.h>
#include <unistd.h> 
#include <glob.h>

void    cp_recursively(char *userdir);
void    directory(char *entry, char *destination);
void    file(char *dest, char *src, int mode);  // copy a file
int     makedir(char *userdir, int mode);       // make a dir for un->{uid,gid}
void    process(char *pattern, char *userdir);  // glob dir && process entries
