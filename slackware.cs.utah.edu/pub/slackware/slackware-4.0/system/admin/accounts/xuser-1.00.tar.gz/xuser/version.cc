#include "xuser.h"

char const
    release[] =
        "ICCE X-user useradd utility V " VERSION "\n"
        "Copyright (c) ICCE " YEAR ". All rights reserved.\n"
        "\n"
        "X-user by Frank B. Brokken";

