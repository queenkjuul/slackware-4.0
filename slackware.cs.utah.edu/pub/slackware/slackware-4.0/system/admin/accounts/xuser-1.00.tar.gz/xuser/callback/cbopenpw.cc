#include "cb.h"

void cb_openpw(FL_OBJECT *ob, long arg)
{
    fl_deactivate_object(ob);
    fl_set_form_position(f_passwd, 0, 0);
    fl_show_form(f_passwd, FL_PLACE_MOUSE, FL_FULLBORDER, nullstring);
    fl_set_input(pwdinput1, nullstring);
    fl_show_object(pwd1group);
    fl_hide_object(pwd2group);
}
