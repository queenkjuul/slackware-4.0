#include "aux.h"

char const *strredef(char *&dest, char const *src)
{
    delete dest;
    return (dest = strdup(src));
}
