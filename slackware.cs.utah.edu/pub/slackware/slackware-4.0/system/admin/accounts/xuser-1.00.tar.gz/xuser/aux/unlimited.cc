#include "aux.h"

long unlimited(long arg)
{
    return
    (
        arg > app_defaults.unlimited ?
            app_defaults.unlimited
        :
            arg
    );
}
