#include "uid.h"

void open_uid_browser(FL_OBJECT *button, long arg)
{
    fl_deactivate_form(f_main);
    fl_set_form_position(f_browseuid, 0, 0);

    fl_clear_browser(uidbrowser);
    fill_browser(uidbrowser, nusers, uidname);

    fl_show_form (f_browseuid, FL_PLACE_MOUSE, FL_FULLBORDER, "UID Info");
}


