#include "test.h"

char const *test_shell()
{
    char const
        *sh = fl_get_input(shell);

    while (*sh && isspace(*sh))                     // skip ws
        sh++;

    return
    (
        *sh ?
            sh
        :
            0
    );
}
