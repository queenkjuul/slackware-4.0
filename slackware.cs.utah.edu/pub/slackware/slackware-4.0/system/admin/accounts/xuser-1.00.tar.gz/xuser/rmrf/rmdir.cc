#include "rm.h"

void rm_dir(char *entry)
{
    if
    (
        strcmp(entry, ".")          // not current dir
        &&
        strcmp(entry, "..")         // and not parent dir
    )
    {
        if (!chdir(entry))              // change to destdir
        {
            process(".*");                  // process the .* entries
            process("*");                   // process the * entries
            chdir("..");                    // go back 1 level
// printf("\tback to the parent, unlinking %s/\n", entry);
            rmdir(entry);                   // remove the directory
        }
    }
}
