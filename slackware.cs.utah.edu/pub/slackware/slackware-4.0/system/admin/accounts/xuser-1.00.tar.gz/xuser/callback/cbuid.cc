
#include "cb.h"

void cb_uid(FL_OBJECT *cb, long arg)
{
    int
        idx;

    idx = test_uid();                           // test the uid

    if (idx == -2)
        alert("Not a valid uid");
    else if (name_uid_conflict(test_name(), idx))
        alert("Uid already in use" );
    else
        return;

    fl_set_input(uid, itoa(up->p_uid));
    fl_set_object_focus(f_main, uid);
}
