#include "m.h"

int makedir(char *dest, int mode)
{
    char
        *cp = dest;
    int
        ret = 1;

    while (cp = strchr(cp, '/'))                    // look for /
    {
        *cp = 0;                                    // terminate at /

        if (!mkdir(dest, mode))                     // create dir. (may fail)
            chown(dest, up->p_uid, up->p_gid);      // set proper uid/gid

        *cp = '/';                                  // restore the string
        cp++;                                       // set cp beyond /
    }

    if (!(ret = mkdir(dest, mode)))                 // create dir. 
        chown(dest, up->p_uid, up->p_gid);          // set proper uid/gid

    return (ret);                                   // directory created
}
