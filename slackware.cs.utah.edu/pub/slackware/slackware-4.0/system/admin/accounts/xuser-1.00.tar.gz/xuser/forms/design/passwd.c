/* Form definition file generated with fdesign. */

#include "forms.h"
#include "passwd.h"

FD_passwd *create_form_passwd(void)
{
  FL_OBJECT *obj;
  FD_passwd *fdui = (FD_passwd *) fl_calloc(1, sizeof(FD_passwd));

  fdui->passwd = fl_bgn_form(FL_NO_BOX, 240, 180);
  obj = fl_add_box(FL_UP_BOX,0,0,240,180,"");
    fl_set_object_color(obj,FL_BLUE,FL_COL1);
  obj = fl_add_box(FL_UP_BOX,20,50,200,110,"");
    fl_set_object_color(obj,FL_TOP_BCOL,FL_COL1);
  obj = fl_add_text(FL_NORMAL_TEXT,30,120,180,30,"Text");
    fl_set_object_color(obj,FL_TOP_BCOL,FL_MCOL);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
  obj = fl_add_input(FL_SECRET_INPUT,60,80,120,30,"");
  obj = fl_add_button(FL_NORMAL_BUTTON,130,10,90,30,"Clear Password");
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

