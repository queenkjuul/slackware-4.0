#include "set.h"

void set_gid()
{
    int
        x;

    if ((x = test_gid()) == -1)
    {
        alert("Non-existing group");
        x = up->p_gid;
        fl_set_object_focus(f_main, gid);
    }
    fl_set_input(gid, lookup_group(x));
}
