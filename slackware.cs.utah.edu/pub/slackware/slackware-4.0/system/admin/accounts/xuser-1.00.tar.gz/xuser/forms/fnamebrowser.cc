#include "../xuser.h"

void f_namebrowser(void)
{
    FL_OBJECT
        *obj;

    f_browsename = fl_bgn_form(FL_NO_BOX, 310, 480);

    obj = fl_add_box(FL_UP_BOX,0,0,310,480,"");
    fl_set_object_color(obj,FL_PALEGREEN,FL_COL1);

    obj = fl_add_text(FL_NORMAL_TEXT,70,420,160,40,"UID Info");
    fl_set_object_color(obj,FL_PALEGREEN,FL_PALEGREEN);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);

    leave_namebrowser = fl_add_button(FL_NORMAL_BUTTON,50,20,210,40,"Dismiss");
    fl_set_object_color(leave_namebrowser,FL_DARKCYAN,FL_COL1);
    fl_set_object_lsize(leave_namebrowser,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(leave_namebrowser,FL_TIMESBOLD_STYLE);

    namebrowser = fl_add_browser(FL_SELECT_BROWSER,30,70,260,340,"");

    fl_end_form();
}
