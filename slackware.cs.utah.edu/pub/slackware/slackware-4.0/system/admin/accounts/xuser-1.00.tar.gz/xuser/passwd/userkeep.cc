#include "pw.h"

void user_keep(passwd *pw)
{
                                            // new structure
    user = (USER_ *)realloc(user, ++nusers * sizeof(USER_));

    memset(&user[nusers - 1], 0, sizeof(USER_));

    user[nusers - 1].p_name    = strdup(pw->pw_name);       /* user name */
    user[nusers - 1].p_pwd     = strdup(pw->pw_passwd);     /* user password */
    user[nusers - 1].p_dir     = strdup(pw->pw_dir);        /* home directory */
    user[nusers - 1].p_shell   = strdup(pw->pw_shell);      /* shell program */
    set_comment(&user[nusers - 1], pw->pw_gecos);            // comment fields

    user[nusers - 1].p_uid     = pw->pw_uid;                /* user id */
    user[nusers - 1].p_gid     = pw->pw_gid;                /* group id */

    user[nusers - 1].state = st_files_ok;

    /*
        no shadow info as yet: all shadow-fields are empty
    */
}
