#include "linefun.h"

static char
    buffer[80];

char const *uidname(int index)
{
    sprintf(buffer, "%3d - %s", user[index].p_uid,
                                user[index].p_name);
    return (buffer);
}

    
