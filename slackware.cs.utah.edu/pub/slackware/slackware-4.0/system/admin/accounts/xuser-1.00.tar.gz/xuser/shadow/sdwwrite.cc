#include "sdw.h"

void sdw_write()
{
    backup(app_defaults.shadow);

    FILE
        *f = xfopen(app_defaults.shadow, w);
    spwd
        *spwp;
//    printf("%d users\n", nusers);

    for (int index = 0; index < nusers; index++)
    {
//        printf("%s, %s shadow entry\n", user[index].p_name, user[index].s_pwd ?
//                        "has a" : "without");
        if (spwp = spwstruct(user + index))
            putspent(spwp, f);
    }
    fclose(f);

    chmod(app_defaults.shadow, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP );
}
