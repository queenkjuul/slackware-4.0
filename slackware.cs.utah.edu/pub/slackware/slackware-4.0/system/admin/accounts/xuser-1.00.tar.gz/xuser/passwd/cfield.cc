#include "pw.h"

char *cfield(char const *&src)
{
    char const
        *sep;
    char
        *dest;
    int
        len;

    sep = strchr(src, ',');                     // find a separator

    len = 
        !sep ?                                  // no separator ?
            strlen(src)                         // then length of the string
        :
            sep - src;                          // otherwise the length to ,

    if (!len)
        return (strdup(nullstring));            // nothing there

    dest = (char *)malloc(len + 1);             // need this # of bytes   
    memcpy(dest, src, len);                     // cp one field
    dest[len] = 0;                              // terminate string

    src += len + (sep != 0);                    // src beyond ',' or at \0
    return (dest);
}
