#include "../xuser.h"
#include <time.h> 
#include <unistd.h> 
#include <new.h>

void hide_objects();                    // hide objects
void set_app_defaults();                // set initial strings: 250 chars
void options_check1();                  // check options
void options_check2();                  // check (& display) options
void shrink(char *&str);                // reduce string length, remove "-s
void handler();                         // memory handler
