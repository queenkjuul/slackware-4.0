#include "screen.h"

void useradd(USER_ *x)
{
    user = (USER_ *)realloc(user, ++nusers * sizeof(USER_));
    user[nusers - 1] = *x;
    up = &user[nusers - 1];
}
