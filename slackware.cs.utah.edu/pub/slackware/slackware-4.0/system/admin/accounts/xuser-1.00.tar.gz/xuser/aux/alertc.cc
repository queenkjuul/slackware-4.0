#include "aux.h"

void alert(char const *str)
{
    fl_show_alert(str, nullstring, nullstring, 1);
}
