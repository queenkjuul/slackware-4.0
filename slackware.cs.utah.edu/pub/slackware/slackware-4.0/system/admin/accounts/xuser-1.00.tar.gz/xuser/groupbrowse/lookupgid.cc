#include "group.h"

int lookup_gid(char const *groupname)
{
    char const
        *line,
        groupid[40],
        dummy[80];
    int
        index = 1,
        gid;

    while (line = fl_get_browser_line(groupbrowser, index++))
    {
        if (sscanf(line, "%[^:]::%d", groupid, &gid) != 2)
            sscanf(line, "%[^:]:%[^:]:%d", groupid, dummy, &gid);

        if (!strcmp(groupname, groupid))
            return (gid);
    }
    return (-1);
}
