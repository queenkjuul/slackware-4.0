#include "../xuser.h" 
#include <sys/stat.h>

spwd *spwstruct(USER_ *);
