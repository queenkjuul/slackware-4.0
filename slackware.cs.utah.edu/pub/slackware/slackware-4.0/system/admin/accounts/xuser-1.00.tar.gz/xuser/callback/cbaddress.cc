#include "cb.h"

void cb_comment(FL_OBJECT *ob, long arg)
{
    commentstr(ob);
}
