#include "../xuser.h"

int namecompare(void const *e1, void const *e2)
{
    return
    (
        strcasecmp(((USER_ *)e1)->p_name, ((USER_ *)e2)->p_name)
    );
}
