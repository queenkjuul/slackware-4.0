#include "../xuser.h"

void save_up();
void restore_up();
int uidcompare(void const *e1, void const *e2);
int namecompare(void const *e1, void const *e2);

