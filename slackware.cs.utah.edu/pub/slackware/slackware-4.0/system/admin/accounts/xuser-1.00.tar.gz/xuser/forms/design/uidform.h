#ifndef FD_uidbrowse_h_
#define FD_uidbrowse_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/



/**** Forms and Objects ****/

typedef struct {
	FL_FORM *uidbrowse;
	void *vdata;
	long ldata;
} FD_uidbrowse;

extern FD_uidbrowse * create_form_uidbrowse(void);

#endif /* FD_uidbrowse_h_ */
