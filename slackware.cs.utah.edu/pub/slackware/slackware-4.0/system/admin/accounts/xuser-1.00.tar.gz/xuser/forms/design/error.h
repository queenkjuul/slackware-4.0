#ifndef FD_diagnose_h_
#define FD_diagnose_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/



/**** Forms and Objects ****/

typedef struct {
	FL_FORM *diagnose;
	void *vdata;
	long ldata;
} FD_diagnose;

extern FD_diagnose * create_form_diagnose(void);

#endif /* FD_diagnose_h_ */
