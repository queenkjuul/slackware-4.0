#include "aux.h"

char const *commentstr(FL_OBJECT *ob)
{
    char
        *cp;

    cp = strdup(fl_get_input(ob));                   // make a copy
    for                                             // look for the ,'s
    (
        char *cp2 = cp;
        cp2 = strchr(cp, ',');
    )
        *cp2 = ';';                                 // , -> ;

    fl_set_input(ob, cp);
    delete cp;

    return (fl_get_input(ob));
}

