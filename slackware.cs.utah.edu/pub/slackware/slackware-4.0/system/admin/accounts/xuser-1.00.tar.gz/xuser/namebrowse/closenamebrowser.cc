#include "name.h"

void close_name_browser(FL_OBJECT *ob, long arg)
{
    uid_sort();
    fl_hide_form(f_browsename);
    fl_activate_object(name_button);
    fl_activate_object(name_0_button);
}
