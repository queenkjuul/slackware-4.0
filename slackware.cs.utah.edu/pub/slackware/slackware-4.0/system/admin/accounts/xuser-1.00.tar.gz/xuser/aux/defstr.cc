#include "aux.h"

void defstr(char *&cp, FL_OBJECT *ob)
{
    strredef(cp, fl_get_input(ob));
}
