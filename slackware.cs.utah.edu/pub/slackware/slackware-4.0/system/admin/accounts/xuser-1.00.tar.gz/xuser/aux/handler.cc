#include "aux.h"

void handler()
{
    fprintf(stderr, "Out of memory\n");
    exit (1);
}
