#include "../xuser.h"

void select_uid(FL_OBJECT *browser, long arg)
{
    int
        id = 999;

    if
    (
        sscanf
        (
            fl_get_browser_line
            (
                browser,
                fl_get_browser(browser)
            ),
            "%d", &id
        ) == 1
    )
    {
        USER_
            *up;

        if (up = lookup_uid(id))
        {
            while
            (
                up < user + nusers            // walk all users
                &&
                id == up->p_uid                 // increment uid
            )
            {
                up++;
                id++;
            }
        }
        fl_set_input(uid, itoa(id));           // set selected uid
    }

    close_uid_browser(browser, 0);
    fl_set_object_focus(f_main, uid);       // allow immediate respec.
}
