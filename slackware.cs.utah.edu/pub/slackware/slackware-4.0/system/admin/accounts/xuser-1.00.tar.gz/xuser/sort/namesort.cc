#include "sort.h"

void name_sort()
{                                           // sort by uid's
    save_up();                              // save info about where up points
    qsort(user, nusers, sizeof(USER_), namecompare);
    restore_up();                           // restore up again
}

