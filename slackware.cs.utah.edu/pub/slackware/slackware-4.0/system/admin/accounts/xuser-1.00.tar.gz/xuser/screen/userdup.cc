#include "screen.h"

USER_ *userdup(USER_ *src)
{
    USER_
        *tmp;

    tmp = new USER_;

    *tmp = *src;                                // straight copy
    tmp->p_name = strdup(tmp->p_name);
    tmp->p_pwd = strdup(tmp->p_pwd);
    tmp->p_dir = strdup(tmp->p_dir);
    tmp->p_shell = strdup(tmp->p_shell);
    tmp->c_name = strdup(tmp->c_name);
    tmp->c_office1 = strdup(tmp->c_office1);
    tmp->c_office2 = strdup(tmp->c_office2);
    tmp->c_address = strdup(tmp->c_address);
    tmp->s_pwd = tmp->s_pwd ? strdup(tmp->s_pwd) : 0;

    return (tmp);
}
