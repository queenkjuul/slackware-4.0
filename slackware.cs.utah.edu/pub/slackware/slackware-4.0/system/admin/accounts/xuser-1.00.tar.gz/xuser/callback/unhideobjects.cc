#include "cb.h"

void unhide_objects()
{
    if (hidden_objects)
    {
        hidden_objects--;
        fl_hide_object(copyright);
        fl_show_object(hide_group);
        fl_show_object(cancel_button);
        fl_show_object(button_group);
    }
}    
        
