#ifndef FD_shellbrowser_h_
#define FD_shellbrowser_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/



/**** Forms and Objects ****/

typedef struct {
	FL_FORM *shellbrowser;
	void *vdata;
	long ldata;
} FD_shellbrowser;

void create_form_shellbrowser(void);

#endif /* FD_shellbrowser_h_ */
