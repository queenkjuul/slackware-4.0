#include "m.h"

void directory(char *entry, char *destination)
{
    if
    (
        strcmp(entry, ".")          // not current dir
        &&
        strcmp(entry, "..")         // and not parent dir
    )
    {
        if (!chdir(entry))              // change to destdir
        {
            cp_recursively(destination);// cp recursively
            chdir("..");                // go back 1 level
        }
    }
}
