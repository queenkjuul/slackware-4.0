#include "screen.h"

int check_screen()
{
    errors = 0;

    int
        id;
    char const
        *name;

    if (!(name = test_name()))
        errline("Username not correct");

    if ((id = test_uid()) == -2)
        errline("Userid not set");
    else if (name_uid_conflict(name, id))
        errline("Username/uid conflict");

    if (test_gid() < 0)
        errline("Groupnumber invalid or not set");

    if (!test_dir())
        errline("Error in home-directory specification");

    return (errors);
}

