
#include "aux.h"

void shadowfields()
{
    fl_set_input(spwchg, ltodate(pwchange));
    fl_set_input(smin,   ltodate(pwchange + min));
    fl_set_input(smax,   ltodate(pwchange + max));
    fl_set_input(swarn,  ltodate(pwchange + max + warn));
    fl_set_input(sinact, ltodate(pwchange + max + inact));
    fl_set_input(sexpire,ltodate(expire));
}
