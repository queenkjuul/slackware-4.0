#include "user.h"

USER_ *lookup_uid(int id)
{
    for (USER_ *tmp = user; tmp < user + nusers; tmp++)
    {
        if (tmp->p_uid == id)                   // id found ?
            return (tmp);                       // return structure's address
    }

    return (0);                                 // not found
}
