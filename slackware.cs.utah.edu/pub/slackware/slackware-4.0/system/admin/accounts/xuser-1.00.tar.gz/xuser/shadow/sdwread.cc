#include "shadow.h"

void sdw_read()
{
    FILE
        *f;
    struct spwd
        *spw;
    USER_
        *up;

    f = xfopen(app_defaults.shadow, r);

    while (spw = fgetspent(f))      // read a shadow password structure
    {
//        printf("read sdw for %s\n", spw->sp_namp);

        if (up = user_lookup(spw->sp_namp))
            shadow_cp(up, spw);             // cp the shadow info
        else                                // no fl_show_fatal: no windows yet
            error("No entry for '%s' in /etc/passwd\n", spw->sp_namp);
    }

    fclose(f);
}

    
