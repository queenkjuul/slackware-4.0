#include "aux.h"

void options_check1()
{
    char
        *cp;

    shrink(app_defaults.shell);
    shrink(app_defaults.shells);
    shrink(app_defaults.groups);
    shrink(app_defaults.passwd);
    shrink(app_defaults.shadow);
    shrink(app_defaults.skeleton);
    shrink(app_defaults.backup);
    shrink(app_defaults.group);
    shrink(app_defaults.home);

    if (cp = dir_sep_end(app_defaults.skeleton))
        *cp = 0;
    if (!dir_sep_end(app_defaults.home))
        strcat(app_defaults.home, "/");
}

