#include "cb.h"

void cb_dir(FL_OBJECT *cb, long arg)
{
    if (!test_dir())
    {
        alert("Invalid home-directory");
        fl_set_input(dir, up->p_dir);               // reset to former value
        fl_set_object_focus(f_main, dir);           // allow immediate respec.
    }
}
