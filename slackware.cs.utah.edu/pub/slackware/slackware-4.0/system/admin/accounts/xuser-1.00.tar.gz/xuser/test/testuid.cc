#include "test.h"

int test_uid()
{
    USER_
        *p;
    char const
        *cp = fl_get_input(uid);
    int
        id;

    if (sscanf(cp, "%u", &id) != 1)                 // no valid number
        return (-2);

    if (!(p = lookup_uid(id)))                      // not found
        return (-1);

    return (p - user);                              // >= 0: found
}
