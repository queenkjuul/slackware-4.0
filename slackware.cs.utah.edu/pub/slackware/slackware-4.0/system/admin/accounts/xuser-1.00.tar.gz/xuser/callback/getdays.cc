#include "cb.h"

DAY_ get_days(FL_OBJECT *ob)
{
    DAY_
        value;

    if ((value = test_day(ob)).type == d_invalid)
    {
        alert("Incorrect time format:",
            "Use yyyy/mo/da or number of days");
        fl_set_object_focus(f_main, ob);
    }
    return (value);                             // # of days since 1/1/70
}
