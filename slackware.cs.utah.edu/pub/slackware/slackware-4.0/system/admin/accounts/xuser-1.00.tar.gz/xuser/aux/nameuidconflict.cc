#include "aux.h"

/*
    no conflict if:

        uid not yet in use and name is new
        uid is uid of existing name
*/

int name_uid_conflict(char const *name, int idx)    // idx > 0: existing uid
{
    USER_
        *u;

    u = user_lookup(name);                  // find the user.
    
    return
    (
        !
        (
            (!u  && idx < 0)                // no name, no known uid
            ||
            (u - user) == idx               // name known, idx of user
        )
    );
}
