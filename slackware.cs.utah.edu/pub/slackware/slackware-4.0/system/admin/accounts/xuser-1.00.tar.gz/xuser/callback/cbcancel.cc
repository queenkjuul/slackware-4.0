#include "cb.h"

void cb_cancel(FL_OBJECT *cancel, long arg)
{
    exit (1);
}
