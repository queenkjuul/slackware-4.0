#include "m.h"

// assumption: we are in the system directory to be processed,
//  the targetdir is given as 'userdir', which may have to be made.

void cp_recursively(char *userdir)
{
    struct stat
        buf;

    stat(".", &buf);                            // retrieve access permissions

    if
    (
        makedir(userdir, buf.st_mode)           // can't make destination dir
    )
        return;

    process(".*", userdir);                     // process the .* entries
    process("*", userdir);                      // process the .* entries
}
