#include "cb.h"

void cb_gid(FL_OBJECT *cb, long arg)
{
    set_gid();                              // redefine the gid
}
