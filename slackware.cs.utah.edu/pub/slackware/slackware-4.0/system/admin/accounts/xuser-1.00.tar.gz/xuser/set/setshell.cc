#include "set.h"

void set_shell()
{
    char const
        *sh;

    if (!(sh = test_shell()))                       // no valid shell ?
    {
        alert("Notice: empty shell specification");
        return;                                     // then done here.
    }

    if (!lookup_shell(sh))
        alert("Not a standard shell:", sh);

    fl_set_input(shell, sh);
}
