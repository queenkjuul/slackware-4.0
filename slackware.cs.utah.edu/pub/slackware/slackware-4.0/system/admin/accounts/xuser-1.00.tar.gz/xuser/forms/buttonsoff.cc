#include "forms.h"

void buttons_off()
{
    fl_set_button(make_button, 0);
    fl_set_button(files_ok_button, 0);
    fl_set_button(delete_button, 0);
    fl_set_button(rm_rf_button, 0);
}
