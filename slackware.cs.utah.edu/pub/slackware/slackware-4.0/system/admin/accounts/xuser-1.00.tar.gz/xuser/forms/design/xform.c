/* Form definition file generated with fdesign. */

#include "forms.h"
#include "xform.h"

FD_xuser *create_form_xuser(void)
{
  FL_OBJECT *obj;
  FD_xuser *fdui = (FD_xuser *) fl_calloc(1, sizeof(FD_xuser));

  fdui->xuser = fl_bgn_form(FL_NO_BOX, 470, 460);
  obj = fl_add_box(FL_UP_BOX,0,0,470,460,"");
    fl_set_object_color(obj,FL_DARKCYAN,FL_LEFT_BCOL);
    fl_set_object_lcol(obj,FL_WHITE);

  obj = fl_add_box(FL_DOWN_BOX,10,60,400,170,"");
    fl_set_object_color(obj,FL_DARKCYAN,FL_COL1);

  obj = fl_add_box(FL_DOWN_BOX,330,280,130,130,"");
    fl_set_object_color(obj,FL_TOP_BCOL,FL_COL1);

  obj = fl_add_box(FL_DOWN_BOX,330,190,130,90,"");
    fl_set_object_color(obj,FL_TOP_BCOL,FL_COL1);

  obj = fl_add_box(FL_UP_BOX,10,10,260,40,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,10,240,310,110,"");

  obj = fl_add_text(FL_NORMAL_TEXT,140,410,140,40,"X-User");
    fl_set_object_color(obj,FL_DARKCYAN,FL_LEFT_BCOL);
    fl_set_object_lcol(obj,FL_LEFT_BCOL);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_input(FL_NORMAL_INPUT,180,360,90,40,"Username");
  obj = fl_add_input(FL_NORMAL_INPUT,60,300,50,40,"UID");
  obj = fl_add_input(FL_NORMAL_INPUT,200,300,80,40,"Group");
  obj = fl_add_input(FL_NORMAL_INPUT,200,250,110,40,"Home");
  obj = fl_add_input(FL_NORMAL_INPUT,60,250,100,40,"Shell");
  obj = fl_add_input(FL_NORMAL_INPUT,90,180,230,40,"Name");
  obj = fl_add_input(FL_NORMAL_INPUT,90,140,150,40,"Office");
  obj = fl_add_input(FL_NORMAL_INPUT,90,70,310,40,"Home phone");
  obj = fl_add_button(FL_NORMAL_BUTTON,30,310,30,20,"UID");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_PALEGREEN,FL_SPRINGGREEN);
  obj = fl_add_button(FL_NORMAL_BUTTON,160,310,40,20,"Group");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_PALEGREEN,FL_SPRINGGREEN);
  obj = fl_add_button(FL_NORMAL_BUTTON,20,260,40,20,"Shell");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_PALEGREEN,FL_SPRINGGREEN);

  obj = fl_add_button(FL_NORMAL_BUTTON,80,10,60,30,"Accept");
    fl_set_object_color(obj,FL_PALEGREEN,FL_TOMATO);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);

  obj = fl_add_button(FL_NORMAL_BUTTON,20,10,60,30,"Cancel");
    fl_set_object_color(obj,FL_PALEGREEN,FL_SPRINGGREEN);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);
  obj = fl_add_input(FL_NORMAL_INPUT,240,140,160,40,"");
  obj = fl_add_lightbutton(FL_PUSH_BUTTON,370,10,90,20,"Button");
 fl_bgn_group();
  obj = fl_add_lightbutton(FL_RADIO_BUTTON,370,30,90,20,"Button");
    fl_set_object_color(obj,FL_YELLOW,FL_COL1);
  fl_end_group();

  obj = fl_add_button(FL_NORMAL_BUTTON,160,10,50,30,"Save");
    fl_set_object_color(obj,FL_PALEGREEN,FL_TOMATO);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);
  obj = fl_add_input(FL_NORMAL_INPUT,400,370,50,30,"last pwchg");
  obj = fl_add_input(FL_NORMAL_INPUT,400,340,50,30,"min. fixed");
  obj = fl_add_input(FL_NORMAL_INPUT,400,310,50,30,"max. fixed");
  obj = fl_add_input(FL_NORMAL_INPUT,400,280,50,30,"expir. alert");
  obj = fl_add_input(FL_NORMAL_INPUT,400,240,50,30,"extra days");
  obj = fl_add_input(FL_NORMAL_INPUT,400,210,50,30,"valid until");
  obj = fl_add_button(FL_NORMAL_BUTTON,330,180,130,20,"set passwd");
    fl_set_object_color(obj,FL_PALEGREEN,FL_COL1);
  obj = fl_add_button(FL_NORMAL_BUTTON,210,10,50,30,"Exit");
    fl_set_object_color(obj,FL_PALEGREEN,FL_TOMATO);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);
 fl_bgn_group();
  obj = fl_add_lightbutton(FL_RADIO_BUTTON,280,30,90,20,"Button");
    fl_set_object_color(obj,FL_YELLOW,FL_COL1);
  fl_end_group();

 fl_bgn_group();
  obj = fl_add_lightbutton(FL_RADIO_BUTTON,280,10,90,20,"Button");
    fl_set_object_color(obj,FL_YELLOW,FL_COL1);
  fl_end_group();

  obj = fl_add_text(FL_NORMAL_TEXT,90,120,60,20,"address");
    fl_set_object_color(obj,FL_DARKCYAN,FL_MCOL);
  obj = fl_add_text(FL_NORMAL_TEXT,240,120,60,20,"phone");
    fl_set_object_color(obj,FL_DARKCYAN,FL_MCOL);
  obj = fl_add_text(FL_NORMAL_TEXT,10,410,270,40,"ICCE X-user useradd utility V 0.90\nCopyright (c) ICCE 1995. All rights reserved.\n\nX-user by Frank B. Brokken");
    fl_set_object_color(obj,FL_DARKCYAN,FL_MCOL);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

