#include "aux.h"

void backup(char const *fname)
{
    char
        buffer[80];

    sprintf(buffer, "%s%s", fname, app_defaults.backup);
    unlink(buffer);

    if (rename(fname, buffer) == -1)
    {
        alert("Can't create backup file for", fname);
        exit (1);
    }
}
