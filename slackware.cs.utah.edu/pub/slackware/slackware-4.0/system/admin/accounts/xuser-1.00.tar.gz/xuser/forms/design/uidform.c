/* Form definition file generated with fdesign. */

#include "forms.h"
#include "uidform.h"

FD_uidbrowse *create_form_uidbrowse(void)
{
  FL_OBJECT *obj;
  FD_uidbrowse *fdui = (FD_uidbrowse *) fl_calloc(1, sizeof(FD_uidbrowse));

  fdui->uidbrowse = fl_bgn_form(FL_NO_BOX, 310, 480);
  obj = fl_add_box(FL_UP_BOX,0,0,310,480,"");
  obj = fl_add_button(FL_NORMAL_BUTTON,50,20,210,40,"Button");
  obj = fl_add_browser(FL_NORMAL_BROWSER,30,70,260,340,"");
  obj = fl_add_text(FL_NORMAL_TEXT,70,420,160,40,"Text");
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

