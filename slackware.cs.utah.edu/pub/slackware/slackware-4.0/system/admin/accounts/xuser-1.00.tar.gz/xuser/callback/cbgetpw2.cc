#include "cb.h"

void cb_getpw2(FL_OBJECT *ob, long arg)
{
    int
        result = strcmp(pwd, fl_get_input(ob));

    fl_hide_form(f_passwd);
    fl_activate_object(ssetpw);

    if (result)
        alert("Verification failed, password not set");
    else if (strlen(pwd) < app_defaults.length)
        alert("Password too short");
    else
    {
        pwchange = today;
        shadowfields();
        strredef(up->s_pwd, pw_encrypt(pwd, 0));
        return;
    }
}
