#include "shell.h"

void close_shell_browser(FL_OBJECT *ob, long arg)
{
    fl_hide_form(f_browseshell);
    fl_activate_object(shell_button);
}
