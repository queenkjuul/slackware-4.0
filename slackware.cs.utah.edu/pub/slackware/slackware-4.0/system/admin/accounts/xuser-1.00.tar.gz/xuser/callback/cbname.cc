#include "cb.h"

void cb_name(FL_OBJECT *name, long arg)
{
    char const
        *cp;

    if (!(cp = test_name()))
    {
        fl_set_input                                // clear/restore contents
        (
                name,
                up ?
                    up->p_name
                :
                    nullstring
        );                                          
        fl_set_object_focus(f_main, name);          // none specified
        alert("Username must start with an alphanumerical character");
        return;                                     // then done here.
    }

    if (up = user_lookup(cp))
        statebutton(st_files_ok);
    else
        up = u_defaults(cp);                        // or set up defaults

    unhide_objects();                               // make it all visible
    u_display(up);                                  // display info about user;
}
