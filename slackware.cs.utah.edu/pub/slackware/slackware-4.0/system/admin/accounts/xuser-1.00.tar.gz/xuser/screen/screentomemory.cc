#include "screen.h"

void screen_to_memory()
{
    defstr(up->p_name, name);

    sscanf(fl_get_input(uid), "%u", &up->p_uid);
    up->p_gid = test_gid();

    defstr(up->p_shell, shell);
    defstr(up->p_dir,   dir);

    strredef(up->c_name,    commentstr(fullname));
    strredef(up->c_office1, commentstr(office1));
    strredef(up->c_office2, commentstr(office2));
    strredef(up->c_address, commentstr(address));

    up->sp_lstchg   = pwchange;
    up->sp_min      = (int)min;
    up->sp_max      = (int)max;
    up->sp_warn     = (int)-warn;
    up->sp_inact    = (int)inact;
    up->sp_expire   = (int)expire;

    if (fl_get_button(make_button))
        up->state = st_make;
    else if (fl_get_button(files_ok_button))
        up->state = st_files_ok;
    else if (fl_get_button(delete_button))
        up->state = st_delete;
    else 
        up->state = st_rm_rf;

    process(up);
}
