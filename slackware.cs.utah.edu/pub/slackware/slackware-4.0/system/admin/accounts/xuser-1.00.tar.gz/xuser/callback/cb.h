#include "../xuser.h"
#include <time.h> 
#include <unistd.h>

extern "C"
    char const *pw_encrypt();

void    cb_comment(FL_OBJECT *, long);
void    cb_cancelpwd(FL_OBJECT *, long);
void    cb_cancel(FL_OBJECT *, long arg);       // exit(1) without changes
void    cb_accept(FL_OBJECT *ob, long arg);     // accept info as userinfo
void    cb_save(FL_OBJECT *ob, long arg);       // save the modified info
void    cb_exit(FL_OBJECT *ob, long arg);       // save and exit
void    cb_dir(FL_OBJECT *, long arg);          // get the homedir
void    cb_expire(FL_OBJECT *, long arg);       // set expiration date
void    cb_getpw1(FL_OBJECT *ob, long arg);     // get a passwd
void    cb_getpw2(FL_OBJECT *ob, long arg);     // get a passwd for verific.
void    cb_gid(FL_OBJECT *, long arg);          // get the gid
void    cb_nopasswd(FL_OBJECT *, long);         // clear the pwd
void    cb_openpw(FL_OBJECT *ob, long arg);     // open the passwd window
void    cb_shadowint(FL_OBJECT *ob,             // get all shadow int-fields
                    long u_type);
void    cb_shell(FL_OBJECT *, long arg);        // get the shell
void    cb_uid(FL_OBJECT *, long arg);          // get the uid
DAY_    get_days(FL_OBJECT *ob);                // get #days
USER_   *u_defaults(char const *name);          // default user definitions
void    u_display(USER_ const *up);             // display info about user
void    unhide_objects();                       // unhide objects
