#include "pw.h"

void pw_read()
{
    FILE
        *f;
    passwd
        *pw;

    f = xfopen(app_defaults.passwd, r);

    while (pw = fgetpwent(f))               // read a password structure
        user_keep(pw);                      // add entry to user[]

    fclose(f);

// printf("pwread()\n");

    uid_sort();                            // sort the user[] database
}


    
