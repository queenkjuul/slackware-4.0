#include "aux.h"

void set_app_defaults()
{
    FL_resource
        *rp = res;

    rp++->var = app_defaults.backup     = new char[250];
    rp++->var = app_defaults.group      = new char[250];
    rp++->var = app_defaults.groups     = new char[250];
    rp++->var = app_defaults.home       = new char[250];
    rp++->var = app_defaults.passwd     = new char[250];
    rp++->var = app_defaults.shadow     = new char[250];
    rp++->var = app_defaults.shell      = new char[250];
    rp++->var = app_defaults.shells     = new char[250];
    rp++->var = app_defaults.skeleton   = new char[250];
}
