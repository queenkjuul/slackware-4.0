
#include "aux.h"

FILE *xfopen(char const *fname, char const *mode)
{
    register FILE
	*ret;

    if (!(ret = fopen(fname, mode)))
	error("Can't open %s to %s", fname,
		*mode == 'r' ?
		    "read"
		:
		    "write");

    return (ret);
}

		
