#include "pw.h" 

void set_comment(USER_ *user, char const *src)  // set the comment fields
{
    user->c_name = cfield(src);
    user->c_office1 = cfield(src);
    user->c_office2 = cfield(src);
    user->c_address = cfield(src); 
}

