#include "group.h"

void close_gp_browser(FL_OBJECT *ob, long arg)
{
    fl_hide_form(f_browsegroup);
    fl_activate_object(gid_button);
}
