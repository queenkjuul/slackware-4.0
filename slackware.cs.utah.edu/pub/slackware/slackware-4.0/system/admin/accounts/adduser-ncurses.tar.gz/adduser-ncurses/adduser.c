/******
 **
 ** cc -O -lcrypt -lmenu -lncurses adduser.c -o adduser
 ** Use gcc if you have it... (political reasons beyond my control) (chris)
 **
 ** I've gotten this program to work with success under Linux (without
 ** shadow) and SunOS 4.1.3. I would assume it should work pretty well
 ** on any system that uses no shadow. (chris)
 **
 ** If you have no crypt() oh well :P
 ** I'm not sure how login operates with no crypt()... I guess
 ** the same way we're doing it here.
 ******/

/* Additional features added by Vinnie Marks @ MSU-Northern.
	Ncurses additions works well under slackware but may not under S.u.S.E.
	If it doesn't it's your emulation. Tough luck.
   	Menu box reads out of /etc/group and puts them in a pull down menu - Nice if you keep forgetting group ids.
   	Added color..
   	Added strange ending..
   	Fixed gets bug a little.. Ya know even though uname var was def'd
   	at 8 chars it would accept larger values. This is probably why
   	they suggest using fgets, to avoid buffer overruns? Yeah right, 
   	fgets sucks bad. So I did umm something.
	Program will actually stay running until ya hit ctrl-c..
	Changed all system() functions to popen().. Don't let the zombies
	bite.....
	Cleaned up the code a little (deleted vars that weren't used or
	had no purpose.
	That's it for now I think.. Have a nice day.
*/
   	
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <unctrl.h>
#include <pwd.h>
#include <grp.h>
#include <ctype.h>
#include <time.h>
#include <menu.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <sys/time.h>
#include <sys/stat.h>

#define PASSWD_FILE       "/etc/passwd"
#define SHADOW_FILE       "/etc/shadow"
#define GROUP_FILE        "/etc/group"
#define GRPSIZE           1000
#define GRPNUM            200
#define DEFAULT_SHELL     "/bin/bash"
#define DEFAULT_HOME      "/home"
#define DEFAULT_GROUP     100
#define FIRST_UID         500
#define DEFAULT_PERMS     0711
#define DEFAULT_MIN_PASS  0
#define DEFAULT_MAX_PASS  180	/* Was set to 10000 */
#define DEFAULT_WARN_PASS 15	/* Was set to -1 */
#define DEFAULT_USER_DIE  10	/* Was set to -1 */
#define DEFAULT_EXPIRE    "06/01/99"

int unused_uid;
char *crypt();

static int menu_virtualize(int c)
{
	if (c == '\n' || c == KEY_EXIT) return(MAX_COMMAND + 1);
	else if (c == 'n' || c == KEY_DOWN) return(REQ_NEXT_ITEM);
	else if (c == 'p' || c == KEY_UP) return(REQ_PREV_ITEM);
	else if (c == 'd' || c == KEY_NPAGE) return(REQ_SCR_DPAGE);
	else if (c == 'u' || c == KEY_PPAGE) return(REQ_SCR_UPAGE);
	else return(c);
}

static ITEM *items[GRPSIZE/sizeof(char *)];

main()
{
MENU	*m;
ITEM	**ip = items;
WINDOW	*menuwin,*funwin;
int	mrows, mcols, height=15, width=60;
char	foo[32],uname[17],fname[32],dir[32],shell[32],salt[2],line[82],temp[40];
char	*passwd;
char	*hmm[GRPNUM];
char	hmmers[GRPNUM][GRPSIZE];
char	commandbuf[80],cogusbuf[12],home[80],acct_die[20];
char	*strd(char *s) {
		char *d;
		d=(char *)malloc(strlen(s)+1);
		strcpy(d,s);
		return(d);
		}
unsigned int group,uid,pass_change_date,min_pass,max_pass,warn_pass,user_die;
int bad=0,done=0,correct=0,gets_warning=0,i=0,j=0,k=0,cnt=0,found=0,perfect=0,init_once=0;

/*
 * bad to see if the username is in /etc/passwd, or if strange stuff has
 * been typed if the user might be put in group 0
 * done allows the program to exit when a user has been added
 * correct loops until a password is found that isn't in /etc/passwd
 * gets_warning allows the fflush to be skipped for the first gets
 * so that output is still legible
 */
time_t tm;
struct passwd *pw;
FILE *passwd_file;
FILE *shadow_file;
FILE *group_file;
FILE *fp;

/* flags, in order:
/* set unused uid to FIRST_UID (#defined above) so that find_unused picks
 * a uid over FIRST_UID (assuming we do everything else right :)
 */
unused_uid = FIRST_UID;

if (geteuid()!=0) {
	printf("It seems you don't have access to add a new user.  Try\n");
	printf("logging in as root or su root to gain super-user access.\n");
	exit(1);
	}

while (!done)               /* loop until a "good" uname is chosen */
{                           /* good = not in /etc/passwd */
	while (!correct)
	{
		printf("\nLogin to add (^C to quit): ");
		if (gets_warning)	/* if the warning was already shown */
			fflush(stdout);	/* fflush stdout, otherwise set the flag */
		else gets_warning=1;
		gets(uname);
		/* what I saw here before made me think maybe I was running DOS */
		/* might this be a solution? (chris) */
		if (getpwnam(uname)!=NULL) {
			printf("That name is in use, choose another.\n");
			correct=0;
			}
		else if (strlen(uname)>sizeof(uname)) { printf("Geez..\n"); correct=0; continue; }
		else if (!strcmp(uname,"")) correct=0;
		else correct=1;
		for (i=0;i<strlen(uname);++i) if (!isalpha(uname[i])) { correct=0; break; }
		}
	correct=0;
	/* all set, get the rest of the stuff */
	printf("\nEditing information for new user [%s]\n",uname);
	printf("\nFull Name: ");
	fflush(stdout);
	gets(fname);
	if (strlen(fname)>sizeof(fname)) { printf("Get a clue.\n"); correct=0; continue; }
	if (strlen(fname)==0) strcpy(fname,uname);
	if (!(group_file=fopen(GROUP_FILE,"r"))) {
		printf("Error reading %s. Aborting...\n",GROUP_FILE);
		exit(0);
		}
	i=0; j=0; cnt=0;
	fgets(line,81,group_file);
	while (!feof(group_file)) {
		while (line[i]!=':') { temp[j]=line[i]; ++i; ++j; }
		temp[j]='\0';
		strcpy(hmmers[cnt],temp);
		hmm[cnt]=hmmers[cnt];
		fgets(line,81,group_file);
		cnt++; i=0; j=0;
		}
	hmm[cnt]=NULL;
	fclose(group_file);

	if (!init_once) {
		/* tell it we're going to play with soft keys */
		slk_init(1);

		/* we must initialize the curses data structure only once */
		initscr();

		/* Initialize color */
		if (has_colors()) start_color();
		init_once=1;
		}
	clear();
	refresh();
	cbreak();
	noecho();
	scrollok(stdscr,TRUE);
	idlok(stdscr,TRUE);
	leaveok(stdscr,TRUE);
	keypad(stdscr,TRUE);

	for (i=0;hmm[i]!=NULL;++i) *ip++ = new_item(hmm[i],"");

	*ip = (ITEM *)NULL;
	m = new_menu(items);
	scale_menu(m, &mrows, &mcols);
	menuwin = newwin(mrows + 2, mcols + 2, (LINES-height)/2, (COLS/2)-mcols);
	init_pair(1,COLOR_RED,COLOR_BLUE);
	wattrset(menuwin,COLOR_PAIR(1) | A_BOLD);
	set_menu_win(m,menuwin);
	keypad(menuwin,TRUE);
 	box(menuwin,0,0);
	set_menu_sub(m,derwin(menuwin,mrows,mcols,1,1));
	post_menu(m);
    	while (menu_driver(m,menu_virtualize(wgetch(menuwin)))!=E_UNKNOWN_COMMAND) {
		redrawwin(menuwin);
		continue;
		}
	strcpy(foo,item_name(current_item(m)));
	unpost_menu(m);
	delwin(menuwin);
	for (ip = items; *ip; ip++) free_item(*ip);
	ip=items;
	*ip=NULL;
	free_menu(m);
	/*
	 * Return to terminal mode, so we're guaranteed of being able to
	 * select terminal commands even if the capabilities are wrong.
	 */
	clear();
	refresh();
	endwin();
	doupdate();
	echo();
	if ((fp=popen("reset","w"))) pclose(fp);
	fflush(stdout);
	sprintf(temp,"%s/%s",DEFAULT_HOME,foo);
	found=1;
	sprintf(home,"%s",temp);
	if (!(group_file=fopen(GROUP_FILE,"r"))) {
		printf("Error reading %s. Aborting...\n",GROUP_FILE);
		exit(0);
		}

	i=0; j=0;
	fgets(line,81,group_file);
	while (!feof(group_file)) {
		while (line[i]!=':') {
			temp[j]=line[i]; ++i; ++j;
			}
		temp[j]='\0';
		if (!strcmp(temp,foo)) {
			j=0;
			while (!isdigit(line[i])) ++i;
			while (line[i]!=':') { temp[j]=line[i]; ++i; ++j; }
			group=atoi(temp);
			break; // Woohoo.. Hi Jay :P
			}
		fgets(line,81,group_file);
		i=0; j=0;
		}
	fclose(group_file);
	if (group==0)  /* You're not allowed to make root group users! */
		group=DEFAULT_GROUP;
        if (group==100) group=DEFAULT_GROUP;
	if (group==DEFAULT_GROUP || found==0) sprintf(home,"%s",DEFAULT_HOME);
	unused_uid = find_unused(++unused_uid);
	printf("\nUID [%d]: ",unused_uid);
	fflush(stdout);
	gets(foo);
	uid=atoi(foo);
	if (uid==0) /* this is how i detect if you just hit return. */
		uid=unused_uid;
		/* it may also disable you from making a root user, but
		 * doesn't that sound more like a feature?
		 */
	if ((pw=getpwuid(uid))!=NULL) {
		printf("\nWarning: UID [%d] is already in use, this would conflict with\n",uid);
		printf("who already owns that user ID. [%s]'s UID has been reset to\n",uname);
		printf("the last unused UID: [%d].\n",unused_uid);
		uid=unused_uid;
		}
	printf("\nHome Directory [%s/%s]: ",home,uname);
	fflush(stdout);
	gets(dir);
	if (strlen(dir)>sizeof(dir)) { printf("Darn you.\n"); correct=0; continue; }
	if (!strcmp(dir,"")) sprintf(dir,"%s/%s",home,uname);

	printf("\nShell [%s]: ",DEFAULT_SHELL);
	fflush(stdout);
	gets(shell);
	if (strlen(shell)>sizeof(shell)) { printf("Go away.\n"); correct=0; continue; }

	if (!strcmp(shell,"")) sprintf(shell,"%s",DEFAULT_SHELL);
	printf("\nDay account expires (syntax: MM/DD/YY) [%s]: ",DEFAULT_EXPIRE);
	fflush(stdout);
   	gets(acct_die);
	if (strlen(acct_die)>sizeof(acct_die)) { printf("I was unaware of that theory.\n"); correct=0; continue; }
   	if (!strcmp(acct_die,"")) strcpy(acct_die,DEFAULT_EXPIRE);

	printf("\nMin. Password Change Days [%d]: ",DEFAULT_MIN_PASS);
	fflush(stdout);
   	gets(foo);
   	min_pass = atoi(foo);
	
	if (min_pass == 0) min_pass = DEFAULT_MIN_PASS;
	printf("\nMax. Password Change Days [%d]: ",DEFAULT_MAX_PASS);
	fflush(stdout);
	gets(foo);

	if (strlen(foo) > 1) max_pass = atoi(foo);
	else max_pass = DEFAULT_MAX_PASS;
	printf("\nPassword Warning Days [%d]: ",DEFAULT_WARN_PASS);
	fflush(stdout);
	gets(foo);
	warn_pass = atoi(foo);

	if (warn_pass == 0) warn_pass = DEFAULT_WARN_PASS;
	printf("\nDays after Password Expiry for Account Locking [%d]: ",DEFAULT_USER_DIE);
	fflush(stdout);
	gets(foo);
	user_die = atoi(foo);

	if (user_die == 0) user_die = DEFAULT_USER_DIE;

	/* Set all the previously commented here */
	min_pass = DEFAULT_MIN_PASS;
	max_pass = DEFAULT_MAX_PASS;
	warn_pass = DEFAULT_WARN_PASS;
	user_die = DEFAULT_USER_DIE;

	while (!perfect) /* Sets up a loop until the password is entered correctly twice */
	{
		passwd=strd(getpass("\nPassword: "));
		if (strcmp(passwd,getpass("Re-type Password: "))) fprintf(stderr,"Sorry, passwords do not match.\n");
		else perfect=1;
		}

	if (!strcmp(passwd,"")) sprintf(passwd,"%s",uname);
	{
		time(&tm);
		salt[0] = (tm & 0x0f) +	'A';
		salt[1] = ((tm & 0xf0) >> 4) + 'a';
		}

	printf("\nInformation for new user [%s]:\n",uname);
	printf("Home directory: [%s] Shell: [%s]\n",dir,shell);
	printf("Password: [<hidden>] uid: [%d] gid: [%d]\n",uid,group);
	printf("MinPass: [%d] MaxPass: [%d] WarnPass: [%d] UserExpire: [%d]\n",min_pass,max_pass,warn_pass,user_die);
	printf("\nIs this correct? [y/N]: ");
	fflush(stdout);
	gets(foo);
	bad=perfect=(toupper(foo[0])=='Y');
	if (!bad) { printf("\nUser [%s] not added\n",uname); continue; }
	/* Calculate days since Jan 1st, 1970 for pass_change_date */
	pass_change_date=(int)((time(NULL)/86400)-1);
	printf("\nAdding login [%s] and making directory [%s]\n",uname,dir);
	mkdir(dir,DEFAULT_PERMS);

	if ((fp=popen("cp /etc/passwd /etc/passwd.OLD","w"))) pclose(fp);
	sprintf(commandbuf,"cp %s %s.OLD", SHADOW_FILE, SHADOW_FILE);
	if ((fp=popen(commandbuf,"w"))) pclose(fp);

	if (!(passwd_file=fopen(PASSWD_FILE,"a"))) {
		printf("Error reading %s. Aborting...\n",PASSWD_FILE);
		exit(0);
		}
	if (!(shadow_file=fopen(SHADOW_FILE,"a"))) {
		printf("Error reading %s. Aborting...\n",SHADOW_FILE);
		exit(0);
		}
	#ifdef NO_CRYPT
		fprintf(passwd_file,"%s:x:%d:%d:%s:%s:%s\n",uname,uid,group,fname,dir,shell);
		fprintf(shadow_file,"%s:%s:%d:%d:%d:%d:%d::\n", uname, fcrypt(passwd, salt), pass_change_date, min_pass, max_pass, warn_pass, user_die);
	#else
		fprintf(passwd_file,"%s:x:%d:%d:%s:%s:%s\n",uname,uid,group,fname,dir,shell);
		fprintf(shadow_file,"%s:%s:%d:%d:%d:%d:%d::\n", uname, crypt(passwd, salt), pass_change_date, min_pass, max_pass, warn_pass, user_die);
	#endif
	fflush(passwd_file);
	fclose(passwd_file);
	fflush(shadow_file);
	fclose(shadow_file);
	/* yes, I fixed uid and group being screwed around (chris) */

	printf("\nAdding the files from the /etc/skel directory:\n"); 
	fflush(stdout); 

	/* First, we "give" the /etc/skel directory to the new user: */

	sprintf(commandbuf,"chown --recursive %d.%d /etc/skel 2>/dev/null",uid,group);
	if ((fp=popen(commandbuf,"w"))) pclose(fp);

	/* Then, we copy the files owned by the new user into the new user's
	home directory. This way, if there are already files in the user's home
	directory (say, from a backup), the ownership of those files won't be 
	changed. Some say this is progress. ;^) */

	sprintf(commandbuf,"( cd /etc/skel ; cp -a --verbose . %s )",dir); 
	if ((fp=popen(commandbuf,"w"))) pclose(fp);
 
 	/* It's useful to give the new home directory a current
	   creation date rather than the one from /etc/skel. */

	sprintf(commandbuf,"touch %s",dir); 
	if ((fp=popen(commandbuf,"w"))) pclose(fp);

	/* Give this stuff back to root. By sure to put the uid/gid you want for
	   the default ownership of /etc/skel into the line below if 0:0 isn't good.*/
	sprintf(commandbuf,"chown --recursive 0:0 /etc/skel 2> /dev/null");
	if ((fp=popen(commandbuf,"w"))) pclose(fp);
	sprintf(commandbuf,"touch /var/spool/mail/%s",uname);
	if ((fp=popen(commandbuf,"w"))) pclose(fp);
	sprintf(commandbuf,"chown %d:mail /var/spool/mail/%s",uid,uname);
	if ((fp=popen(commandbuf,"w"))); pclose(fp);
	sprintf(commandbuf,"chmod 600 /var/spool/mail/%s",uname);
	if ((fp=popen(commandbuf,"w"))) pclose(fp);
	sprintf(commandbuf,"chmod go-r %s", dir);
	if ((fp=popen(commandbuf,"w"))) pclose(fp);
	funwin = newwin(0,0,0,0);
	init_pair(1,COLOR_YELLOW,COLOR_BLACK);
	wattrset(funwin,COLOR_PAIR(1) | A_BOLD);
	savetty();
	clear();
	refresh();
	leaveok(stdscr,TRUE);
	j=(COLS+30); k=1; line[0]='\0';

	for (i=0;i<225;i++) {
		mvwaddch(funwin,2,j,(chtype)'|');
		mvwaddch(funwin,3,j,(chtype)'|');
		mvwaddch(funwin,4,j,(chtype)'<');
		mvwaddch(funwin,5,j,(chtype)'|');
		mvwaddch(funwin,6,j,(chtype)'|');
		mvwaddch(funwin,4,j+1,(chtype)'(');
		mvwaddch(funwin,3,j+2,(chtype)'_');
		mvwaddch(funwin,5,j+2,(chtype)'~');
		mvwaddch(funwin,3,j+3,(chtype)'_');
		mvwaddch(funwin,4,j+3,(chtype)'(');
		mvwaddch(funwin,5,j+3,(chtype)'-');
		mvwaddch(funwin,2,j+4,(chtype)'.');
		mvwaddch(funwin,3,j+4,(chtype)'_');
		mvwaddch(funwin,5,j+4,(chtype)'.');
		mvwaddch(funwin,2,j+5,(chtype)'=');
		mvwaddch(funwin,3,j+5,(chtype)'_');
		mvwaddch(funwin,5,j+5,(chtype)'.');
		mvwaddch(funwin,6,j+5,(chtype)'|');
		mvwaddch(funwin,7,j+5,(chtype)'(');
		mvwaddch(funwin,2,j+6,(chtype)'=');
		mvwaddch(funwin,5,j+6,(chtype)'=');
		mvwaddch(funwin,6,j+6,(chtype)'_');
		mvwaddch(funwin,7,j+6,(chtype)'_');
		mvwaddch(funwin,2,j+7,(chtype)'=');
		mvwaddch(funwin,3,j+7,(chtype)'|');
		mvwaddch(funwin,4,j+7,(chtype)'|');
		mvwaddch(funwin,5,j+7,(chtype)'=');
		mvwaddch(funwin,6,j+7,(chtype)'/');
		mvwaddch(funwin,7,j+7,(chtype)')');
		mvwaddch(funwin,2,j+8,(chtype)'=');
		mvwaddch(funwin,3,j+8,(chtype)'_');
		mvwaddch(funwin,4,j+8,(chtype)'.');
		mvwaddch(funwin,5,j+8,(chtype)'=');
		mvwaddch(funwin,2,j+9,(chtype)'=');
		mvwaddch(funwin,5,j+9,(chtype)'=');
		mvwaddch(funwin,2,j+10,(chtype)'=');
		mvwaddch(funwin,5,j+10,(chtype)'=');
		mvwaddch(funwin,3,j+11,(chtype)'/');
		mvwaddch(funwin,5,j+11,(chtype)'=');
		mvwaddch(funwin,2,j+12,(chtype)'.');
		mvwaddch(funwin,3,j+12,(chtype)'_');
		mvwaddch(funwin,5,j+12,(chtype)'-');
		mvwaddch(funwin,2,j+13,(chtype)'_');
		mvwaddch(funwin,3,j+13,(chtype)'_');
		mvwaddch(funwin,5,j+13,(chtype)'.');
		mvwaddch(funwin,2,j+14,(chtype)'_');
		mvwaddch(funwin,3,j+14,(chtype)'_');
		mvwaddch(funwin,5,j+14,(chtype)'.');
		mvwaddch(funwin,2,j+15,(chtype)'.');
		mvwaddch(funwin,3,j+15,(chtype)'_');
		mvwaddch(funwin,5,j+15,(chtype)'.');
		mvwaddch(funwin,3,j+16,(chtype)'~');
		mvwaddch(funwin,5,j+16,(chtype)'.');
		mvwaddch(funwin,3,j+17,(chtype)'-');
		mvwaddch(funwin,5,j+17,(chtype)'-');
		mvwaddch(funwin,3,j+18,(chtype)'.');
		mvwaddch(funwin,5,j+18,(chtype)'-');
		mvwaddch(funwin,3,j+19,(chtype)'_');
		mvwaddch(funwin,5,j+19,(chtype)'-');
		mvwaddch(funwin,3,j+20,(chtype)'.');
		mvwaddch(funwin,5,j+20,(chtype)'-');
		mvwaddch(funwin,3,j+21,(chtype)'\'');
		mvwaddch(funwin,5,j+21,(chtype)'~');
		mvwaddch(funwin,2,j+22,(chtype)'/');
		mvwaddch(funwin,3,j+22,(chtype)'_');
		mvwaddch(funwin,1,j+23,(chtype)'.');
		mvwaddch(funwin,2,j+23,(chtype)'~');
		mvwaddch(funwin,3,j+23,(chtype)'_');
		mvwaddch(funwin,4,j+23,(chtype)'_');
		mvwaddch(funwin,5,j+23,(chtype)'\\');
		mvwaddch(funwin,1,j+24,(chtype)'-');
		mvwaddch(funwin,2,j+24,(chtype)'|');
		mvwaddch(funwin,3,j+24,(chtype)'|');
		mvwaddch(funwin,4,j+24,(chtype)'|');
		mvwaddch(funwin,5,j+24,(chtype)'o');
		mvwaddch(funwin,1,j+25,(chtype)'.');
		mvwaddch(funwin,3,j+25,(chtype)'_');
		mvwaddch(funwin,4,j+25,(chtype)'_');
		mvwaddch(funwin,2,j+26,(chtype)'\\');
		mvwaddch(funwin,3,j+26,(chtype)'_');
		mvwaddch(funwin,4,j+26,(chtype)'.');
		mvwaddch(funwin,3,j+27,(chtype)')');
		mvwaddch(funwin,4,j+27,(chtype)'\'');
		mvwaddch(funwin,4,j+28,(chtype)'-');
		mvwaddch(funwin,4,j+29,(chtype)'-');
		mvwaddch(funwin,4,j+30,(chtype)'-');
		mvwaddch(funwin,4,j+31,(chtype)'-');
		mvwaddch(funwin,4,j+32,(chtype)'-');
		mvwaddch(funwin,4,j+33,(chtype)'-');
		mvwaddch(funwin,4,j+34,(chtype)'-');

		if (j<COLS-35) {
			snprintf(line,k,"User %s has been deleted...I mean created.\n",uname);
			++k;
			mvwaddch(funwin,5,j+35,(chtype)'\\');
			mvwaddch(funwin,4,j+35,(chtype)'/');
			mvwaddch(funwin,6,j+36,(chtype)'\\');
			mvwaddch(funwin,3,j+36,(chtype)'/');
			mvwaddch(funwin,7,j+37,(chtype)'\\');
			mvwaddch(funwin,2,j+37,(chtype)'/');
			for (cnt=0;cnt<strlen(line);++cnt) mvwaddch(funwin,4,(j+38)+cnt,(chtype)line[cnt]);
			mvwaddch(funwin,2,(j+71)+(strlen(line)-32),(chtype)'\\');
			mvwaddch(funwin,7,(j+71)+(strlen(line)-32),(chtype)'/');
			mvwaddch(funwin,3,(j+72)+(strlen(line)-32),(chtype)'\\');
			mvwaddch(funwin,6,(j+72)+(strlen(line)-32),(chtype)'/');
			mvwaddch(funwin,4,(j+73)+(strlen(line)-32),(chtype)'\\');
			mvwaddch(funwin,5,(j+73)+(strlen(line)-32),(chtype)'/');
			for (cnt=0;cnt<strlen(line)+1;++cnt) mvwaddch(funwin,1,(j+38)+cnt,(chtype)'_');
			for (cnt=0;cnt<strlen(line)+1;++cnt) mvwaddch(funwin,7,(j+38)+cnt,(chtype)'_');
			}
		wrefresh(funwin);
		napms(50);
		wclear(funwin);
		--j;
		}
	delwin(funwin);
	resetty();
	clear();
	refresh();
	endwin();
	doupdate();
	if ((fp=popen("reset","w"))) pclose(fp);
	fflush(stdout);
	}
}

/* Here is our trade secret patented copyrighted code to find an unused UID */

find_unused(int begin)
{
	int trial;
	struct passwd *pw;
	trial = begin - 1;
	printf("\nChecking for an available UID after %d\n",FIRST_UID);
	while ((pw = getpwuid(++trial)) != NULL) ;
	printf("\nFirst unused uid is %d\n", trial);
	return(trial);
}
