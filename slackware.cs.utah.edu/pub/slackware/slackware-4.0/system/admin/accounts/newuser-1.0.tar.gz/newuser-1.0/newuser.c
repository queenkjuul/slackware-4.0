/*
 *  Newuser 1.0 
 *   
 *  Copyright (C) 1997  Allen Kukucka
 */
 
/*
 * Adduser was starting to look bad so I had
 * to do something about it.
 */ 

#include <stdio.h>
#include <unistd.h>
#include <pwd.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>
#include <fcntl.h>
#include <ctype.h>

#define version		"1.0"
#define passwdfile      "/etc/passwd"
#define default_shell   "/bin/sh"
#define homedir_perms   0755
#define mailgrp         12


#ifndef NIS
#define shadow_token	"x"
#define shadowfile	"/etc/shadow"
#endif /*NIS*/

static FILE *passwd_file;
static FILE *mail_file;

#ifndef NIS
static FILE *shadow_file;
#endif /*NIS*/

static char mail_dir[16]="/var/spool/mail";
static char default_homedir[12];

static time_t t;

static char uname[17], full_name[51], num[65], homedir[31], shell[11];
static char salt[3], *crypt_pass, buffer[81], yesno[2];
static char password[81];
static int scan, len;
static unsigned int uid, uuid, gid, proceed=1;

void main()

{

	/* Here we use getuid() v.s. geteuid() to ensure user is really
	 * root. */
	
	if(getuid()) 
 		{
		   fprintf(stderr,"You must be root to run this program\n");
			exit(0);
	}


#ifndef NIS
	fprintf(stdout,"\n\nNewuser %s by Allen Kukucka\n\n", version);
#endif
#ifdef NIS
	fprintf(stdout,"\n\nNewuser %s by Allen Kukucka (NIS, No shadow Version)\n\n", version);
#endif /*NIS*/
      while(proceed) {	
	
  /* default_homedir has to be in this while loop */

	strncpy(default_homedir, "/home", 6); 

       /* Here we check to see if Enter is pressed or if the chosen
	* username already exists */ 
                     
 	   while(strlen(uname) < 1)
		{
		fprintf(stdout,"Enter new username: ");
		fflush(stdout);
		gets(uname);
		if (getpwnam(uname) != NULL)
		    {	
	            fprintf(stderr,"That username is already in use.\n");
		    uname[0] = '\0';
		    }   
		else
		    {
		    len = strlen(uname);
		    for (scan = 0; scan < len; ++scan)
			{
			if ( (!isprint(uname[scan])) || (uname[scan] == ' ') )
			    {
			    fprintf(stderr,"Illegal characters in username.\n");
			    uname[0] = '\0';
			    }
			}
		    }
	  	}


	fprintf(stdout,"\nEnter %s's full name: ", uname);
	  gets(full_name);
          
      /* Here we find the next available UID */ 
  
	uid=500;
	while(getpwuid(++uid) !=NULL);	 
      	
	uuid=uid;
	
       fprintf(stdout,"\nEnter %s's UID [%d]: ", uname, uuid);
	gets(num);
	
      /* Lets make sure they dont try and make a Super-User! */	

	if(!(uid = (int) atoi(num))) {
       	   fprintf(stdout,"\n[Using next available uid %d]\n", uuid);
	    uid=uuid;
        }
   

     /* Better give the user someplace to belong. */ 

	gid=100;  
	fprintf(stdout,"\nEnter the group ID for %s [%d]: ", uname, gid);
	 gid = (int) atoi(gets(num)); 

	if(!strcmp(num, "")) { 
	  
	  gid=100;
	}
        fprintf(stdout,"\n[Using GID %d]\n", gid); 

	
    /* Let's make a home directory for the user. */
   
   strcat(default_homedir, "/");
	
     fprintf(stdout,"\nEnter %s's home directory [%s%s]: ", uname, default_homedir, uname);
	gets(homedir);
	
      if(!strcmp(homedir, "")) 
	strncpy(homedir, strcat(default_homedir, uname), sizeof(homedir));
      
	 fprintf(stdout,"\n[Using home directory %s]\n", homedir);


	fprintf(stdout,"\nEnter the shell you'd like %s to use [%s]: ", 
					 uname, default_shell);
	fflush(stdin);
	gets(shell);
	
	 if(!strcmp(shell, "")) strncpy(shell, default_shell, sizeof(shell));
	
	  fprintf(stdout,"\n[Using shell %s]\n", shell);


	/* Lets generate a random salt */
	
   /* Taken from adduser for now... Will come up with something better soon
    * I want one that does [a-zA-z0-9./]. */	   
	
	time(&t);
	salt[0] = (t & 0x0f) + 'A';
	salt[1] = ((t &0xf0) >> 4) + 'a';
	
   /* Now maybe we should get a password from the user */

  /* Testing for lots of stuff  
   * Changes by Allen Kukucka added 11/17/97
   */

 	for (password[0] = '\0'; password[0] == '\0';)
	    {
	    strcpy(password,getpass("\nEnter the user's password:  "));
	    if (strlen(password) < 5)
		{
		fprintf(stderr,"\nPassword must be at least 5 characters!\n");
		password[0] = '\0';
		}
	    if (password[0] != '\0')
		{
		if (strcmp(password,getpass("\nEnter password again: ")) != 0)
		    {
		    fprintf(stderr,"\nThe passwords don't match!\n");
		    password[0] = '\0';
		    }
		}
	    }
 
	crypt_pass = crypt(password, salt);
	  
	fprintf(stdout,"\n************************\n");
	  fprintf(stdout,"*User's current profile*\n");
	  fprintf(stdout,"************************\n\n");
	
	fprintf(stdout,"* Full Name = [%s]\n", full_name);
	fprintf(stdout,"* UID = [%d]\n", uid);
	fprintf(stdout,"* GID = [%d]\n", gid);
	fprintf(stdout,"* Home Directory = [%s]\n", homedir);
	fprintf(stdout,"* Shell = [%s]\n", shell);
	fprintf(stdout,"* Password = [Not Shown]\n");
     strcpy(yesno,"");
printf("\nDEBUG\n%s\nDEBUG\n", yesno);	 
	while(!strcmp(yesno, "")) {

          fprintf(stdout,"\nProceed with current profile? (y/n): ");
		gets(yesno);
	         	
           if(!(strcmp(yesno, "n")) || !(strcmp(yesno, "N"))) {  
	     fprintf(stderr,"\nUser addition declined, let's try again.\n\n");
		proceed=1; 
	    }         
         else proceed=0;

	   }
  }    


	/* Open passwd and shadow files for writing */

	if((passwd_file = (fopen(passwdfile, "a"))) ==NULL) {
	    
	     fprintf(stderr,"Unable to open passwd file, so there!\n");
		exit(1);
	}

	
#ifndef NIS
	if((shadow_file = (fopen(shadowfile, "a"))) ==NULL) {

	     fprintf(stderr,"Unable to open shadow file, so there!\n");
		exit(1);
        }
#endif /*NIS*/


#ifdef NIS
    fprintf(passwd_file, "%s:%s:%d:%d:%s:%s:%s\n", uname, crypt_pass, uid, gid,
						full_name, homedir, shell); 
#else /* notdefined NIS */
    fprintf(passwd_file, "%s:%s:%d:%d:%s:%s:%s\n", uname, shadow_token, uid, gid,
						full_name, homedir, shell);
     fprintf(shadow_file, "%s:%s::::::::\n", uname, crypt_pass); 
#endif /*NIS*/
	
#ifndef NIS
	fclose(shadow_file); 
#endif /*NIS*/

	fclose(passwd_file); 

	/* Time to do the dirty work. 
	   When ya see me com'in better killoff inetd! */
	
	  fprintf(stdout,"\n----------------------------------------------------\n");
	  fprintf(stdout,"-Making home directory...\n");
	   
	    if(mkdir(homedir, homedir_perms)) 
	      fprintf(stderr, "\nSorry, cannot make directory %s\n", homedir);
         
	  fprintf(stdout,"-Making sure permissions and ownership are correct.\n");
    
	if(chown(homedir, uid, gid))
	  fprintf(stderr, "\nSorry, cannot change ownership on directory %s.\n",
	          homedir);
  
   fprintf(stdout,"-Making user's mailfile.\n");
      
      strcat(mail_dir, "/");
      strcat(mail_dir, uname);

     if((mail_file = (fopen(mail_dir, "a"))) ==NULL)
	  fprintf(stderr,"\nSorry, cannot create %s.\n", mail_dir);
           else fclose(mail_file);
  
   fprintf(stdout,"-Setting permissions and ownership on %s.\n", mail_dir); 
  
     if(chown(mail_dir, uid, mailgrp))
	fprintf(stderr, "\nSorry, cannot change ownership on %s\n", mail_dir);
     	    
     if(chmod(mail_dir, 0660))
	fprintf(stderr, "\nSorry, cannot change file perms on %s\n", mail_dir);


    fprintf(stdout,"-Copying files from /etc/skel directory...\n\n");
     
	sprintf(buffer, "cp -rv /etc/skel/.??* %s", homedir);
	system(buffer);
        
        fprintf(stdout,"Done!\n\n");


	fprintf(stdout,"----------------------------------------------------\n");
	 fprintf(stdout,"-Fixing permissions on files.\n");
      

	sprintf(buffer, "chown %d.%d %s/.??*", uid, gid, homedir);
	  system(buffer);
	
	sprintf(buffer, "chmod 0750 %s/.??*", homedir);
	  system(buffer);



        fprintf(stdout,"\nCompleted!\n\nThanks for using Newuser %s!\n", version);  

	fprintf(stdout,"Email awacs@livecam.com on any bugs or\n");
	fprintf(stdout,"hints on how to make this program better.\n\n\n");


}
