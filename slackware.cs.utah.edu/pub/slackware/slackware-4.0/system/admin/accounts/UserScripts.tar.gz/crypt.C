/*
-----------------------------------------------------------------------------
-  This program reads a line from STDIN and encrypts it using the crypt()   -
-  function to STDOUT.                                                      -
-  Copyright : Released 1998 under the terms of the GNU GPL                 -
-  Written 1998 by Christian Ordig <chr.ordig@gmx.net>                      -
-----------------------------------------------------------------------------
*/

#include <unistd.h>
#include <iostream.h>
#include <stdlib.h>
#include <time.h>

#ident "Written 1998 by Christian Ordig <chr.ordig@gmx.net>"

void main () {
    timeval time;    
    long seed;  // start value for the random number generator
    unsigned char *salt = (unsigned char*) malloc (3);
    char* in = (char*) malloc (20); // allocate space for input
    char* out= (char*) malloc (20); // allocate space for output
    gettimeofday(&time,NULL);
    seed=time.tv_usec; // get the msec of the current time
    while (seed>255) {seed=seed-253;}
    srand(seed); // initialize the random number generator
    salt[0]=rand(); while (salt[0]>64) {salt[0]/=2;}; salt[0]+=64;
    salt[1]=rand(); while (salt[1]>64) {salt[1]/=2;}; salt[1]+=64;
    salt[2]=0;
    
    cin >> in; // read STDIN
    out = crypt (in, (char*)salt); // encrypt the password
    cout << out; // write encrypted password to STDOUT
};