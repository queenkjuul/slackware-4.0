/* The nosharing message. Set the users shell to this if they have been sharing
   their accounts.
	Syslogging done by auth.debug
Written by Ken Wilcox <wilcox@kpw104.rh.psu.edu>
*/
/* standard includes */

#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>
#include <syslog.h>
#include <sys/types.h>
#include <unistd.h>
#ifndef MAIL_FLAG
#define MAIL_FLAG sysadmin
#endif
#ifndef ADMIN_FLAG
#define ADMIN_FLAG sysadmin
#endif
#ifndef ROOM_FLAG
#define ROOM_FLAG sysadmin
#endif
/* needed variables */

int uid_user;			/* users uid */
struct passwd *get_passwd;	/* users passwd entrie */ 
char *t;			/* the tty */

main(){
/* The Syslogging */
	t = ttyname(STDIN_FILENO);
	uid_user = getuid();
	get_passwd = getpwuid(uid_user);
	openlog("nosharing",LOG_PID,LOG_AUTH);
	syslog(LOG_DEBUG, "user %s got the nosharing msg on %s", get_passwd->pw_name, t); 
	closelog();
/* The message */
	printf("\n\n\n");
	printf("You have been found to be sharing your accounts which is not allowed.\n");
	printf("Thus your account has been disabled. To see about having\n");
	printf("your account re-activated, Pleae send mail to ");
	printf(MAIL_FLAG);
	printf(" or stop and\n");
	printf("talk to ");
	printf(ADMIN_FLAG);
	printf(" in room\n");
	printf(ROOM_FLAG);
	printf(". Thank You!!\n\n\n\n");
	printf("Systems Staff\n\n\n\n");
	usleep(15*1000000);
}
