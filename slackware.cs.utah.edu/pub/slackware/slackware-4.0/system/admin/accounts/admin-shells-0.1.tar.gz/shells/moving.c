/* The moving message.  Set the Users shell to this when you move their 
   directory to somewhere else.
	Syslogging done by auth.debug
Written by Ken Wilcox <wilcox@kpw104.rh.psu.edu>
*/
/* Standard Includes */

#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>
#include <syslog.h>
#include <sys/types.h>
#include <unistd.h>
#ifndef MAIL_FLAG
#define MAIL_FLAG sysadmin
#endif
#ifndef ADMIN_FLAG
#define ADMIN_FLAG sysadmin
#endif
#ifndef ROOM_FLAG
#define ROOM_FLAG sysadmin
#endif
/* needed variables */

int uid_user;			/* users uid */	
struct passwd *get_passwd;	/* users passwd entry */
char *t;			/* the tty */

main(){
/* The Syslogging */
	t = ttyname(STDIN_FILENO);
	uid_user = getuid();
	get_passwd = getpwuid(uid_user);
	openlog("moving",LOG_PID,LOG_AUTH);
	syslog(LOG_DEBUG, "user %s got the moving msg on %s", get_passwd->pw_name, t); 
	closelog();
/* The message */
	printf("\n\n\n");
	printf("Your account is being moved. Try again later. \n\n\n");
	printf("Systems Staff\n\n\n\n");
	usleep(15*1000000);
}
