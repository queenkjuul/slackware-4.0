/* 
** adduser 1.0: add a new user account (For systems not using shadow)
** With a nice little interface and a will to do all the work for you.
**
** Craig Hagan
** hagan@opine.cs.umass.edu
**
** Modified to really work, look clean, and find unused uid by Chris Cappuccio
** chris@slinky.cs.umass.edu
**
** adduser 1.1: (11-13-98) 
** Copy the contents of /etc/skel directory to the users
** home directory, if /etc/skel exist.
** Add user to /var/spool/mail.  
**
** cc -O -o adduser adduser.c           <Compile on linux Libc5 system>
** cc -O -o adduser adduser.c -lcrypt   <Compile on linux Libc6 system>
**
** The reason for adduser 1.1 is it's very hard to find a noshadow adduser.
** Kent Robotti <krobotti@erols.com>
*/

#include <pwd.h>
#include <grp.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <sys/time.h>
#include <sys/stat.h>

#define PASSWD_FILE	"/etc/passwd"
#define DEFAULT_SHELL	"/bin/bash"
#define DEFAULT_HOME	"/home"
#define DEFAULT_GROUP	100	/* 100 is usually 'users' */
#define FIRST		500	/* First useable UID */
#define DEFAULT_PERMS	0700	/* Perms for the users home directory */

#ifndef MAXPATHLEN
#define MAXPATHLEN 128
#endif
#ifndef MAXLINE
#define MAXLINE 80
#endif

char commandbuf[80];
char passwd_path[MAXPATHLEN]=PASSWD_FILE;
char shell_path[32]=DEFAULT_SHELL;
char home_path[32]=DEFAULT_HOME;
int  init_group=DEFAULT_GROUP;
int  init_uid=FIRST;
int  init_perms=DEFAULT_PERMS;

FILE *bull;	/* Bullshit way to find a shadow password file */
int unused_uid,nag;
char *crypt();

main()
{
  char foo[32];			

  /* a user read in from /etc/passwd this */
  /* to see if the username is in use     */				
  /* also for misc. inputs and other bullshit that i fell it should be */

  char uname[9],person[32],passwd[9],dir[32],shell[32],salt[2];
  
  /* uname=user name,person=full name,passwd=password,dir=home dir,
   * shell=shell,salt=for password encryption */

  unsigned int group,uid;

  /* the group and uid of the new user */

  int bad=0,done=0,correct=0,gets_warning=0;

  /* flags, in order:
   * bad to see if the username is in /etc/passwd, or if strange stuff has
   * been typed if the user might be put in group 0
   * done allows the program to exit when a user has been added
   * correct loops until a password is found that isn't in /etc/passwd
   * gets_warning allows the fflush to be skipped for the first gets
   * so that output is still legible
   */

  time_t tm;

  struct passwd *pw;

  FILE *passwd_file;  /* Yep, it's a file allright */

  /* set unused uid to FIRST (#defined above) so that find_unused picks
   * a uid over FIRST (assuming we do everything else right :)
   */

  unused_uid = init_uid;

  /* The real program starts HERE! */

  /* Smile, it's the 2nd best thing you can do with your lips */

  /* Lesse if we know what we're doing here... */
  
  if(geteuid()!=0)
  {
     printf("It seems you don't have access to add a new user.  Try\n");
     printf("logging in as root or su root to gain super-user access.\n");
     exit(1);
  }
  
  /* We don't support shadow password files, let's check and make
   * sure we're not using em. Sure we could use filesearch or something
   * but i don't feel like it.
   */

  if((bull=fopen("/etc/shadow","r"))!=NULL) /* SYSV Shadow */
  found_shadow();

  while(!correct)		/* loop until a "good" uname is chosen */
    {				/* good = not in /etc/passwd */
      while(!done)
	{
	  printf("\nUser name to add? (^C to quit): ");

	  if(gets_warning)	/* if the warning was already shown */
	    fflush(stdout);	/* fflush stdout, otherwise set the flag */
	  else
	    gets_warning=1;

	  gets(uname);

          /* what I saw here before made me think maybe I was running DOS */
          /* might this be a solution? (chris) */
	  if(nag=getpwnam(uname) != NULL)
	    {
	      printf("That name is in use, choose another.\n");
	      done=0;
	    }
	  else done=1;
	}

      /* all set, get the rest of the stuff */

      printf("\nEditing information for new user: [%s]\n",uname);
  
      printf("\nFull name for user [%s]: ",uname);
      gets(person);
      
      printf("GID [%d]: ",init_group);
      gets(foo);
      /* Draco: comparison instead of assignment... how did it work? */
      group=atoi(foo);

      if (group==0)	/* You're not allowed to make root group users! */
	group=init_group;

      unused_uid = find_unused(++unused_uid);	/* our k-eleet unused! */

      printf("\nUID [%d]: ",unused_uid);
      gets(foo);
      uid=atoi(foo);

      if(uid==0) /* this is how i detect if you just hit return. */
        uid=unused_uid;
                 /* it may also disable you from making a root user, but
                  * doesen't that sound more like a feature?
                  */

      /* Draco: fix needed for possible next loop... */
      unused_uid--;

      if((pw=getpwuid(uid))!=NULL)	/* uhh. duhh. egh.. */
      {
        printf("\nWarning: UID [%d] is already in use, this would cause a conflict.\n",uid);
        printf("User [%s]'s UID has been reset to the last unused UID: [%d]\n",uname,unused_uid);
        uid=unused_uid;
      }
      
      fflush(stdin);
      
      printf("\nHome Directory? [%s/%s]: ",home_path,uname);
      fflush(stdout);
      gets(dir);

      if (!strcmp(dir,""))
	sprintf(dir,"%s/%s",home_path,uname);
      fflush(stdin);

      printf("\nShell? [%s]: ", shell_path);
      fflush(stdout);
      gets(shell);
      
      if (!strcmp(shell,""))
	sprintf(shell,"%s", shell_path);
      
      printf("\nPassword? [%s]: ",uname);
      fflush(stdout);
      gets(passwd);

      if (!strcmp(passwd,""))
	sprintf(passwd,"%s",uname);
      {
	time(&tm);
	salt[0] = (tm & 0x0f) +	'A';
	salt[1] = ((tm & 0xf0) >> 4) + 'a';
      }
  
      printf("\nInformation for new user: [%s]\n",uname);
      printf("Home directory: [%s]\nShell: [%s]\n",dir,shell);
      printf("Password: [%s]\nUID: [%d]\nGID: [%d]\n",passwd,uid,group);
      printf("\nIs this correct? [y/N]: ");
      fflush(stdout);
      gets(foo);

      done=bad=correct=(foo[0]=='y'||foo[0]=='Y');

      if(bad!=1)
       printf("\nUser [%s] not added ... Cancelled!\n",uname);
    }

  printf("\nAdding User [%s] to /etc/passwd file.\nMaking directory: [%s]\n",uname,dir);
  mkdir(dir, init_perms);

  system("cp /etc/passwd /etc/passwd.old"); /* Let's have safe sex */
  
  passwd_file=fopen(passwd_path,"a");

#ifdef NO_CRYPT
  fprintf(passwd_file,"%s:%s:%d:%d:%s:%s:%s\n"
  	  ,uname,fcrypt(passwd,salt),uid,group,person,dir,shell);
#else
  fprintf(passwd_file,"%s:%s:%d:%d:%s:%s:%s\n"
	  ,uname,crypt(passwd,salt),uid,group,person,dir,shell);
#endif

  fflush(passwd_file);
  fclose(passwd_file);
  /* yes, I fixed uid and group being screwed around (chris) */

  /* make sure that they own their directory -- its kinda nice :) */
  chown(dir,uid,group);

		sprintf(commandbuf, "chown --recursive %d.%d /etc/skel 2>/dev/null", uid, (int) group);
		system(commandbuf);
                printf("Copying /etc/skel contents to: [%s]\n",dir);

		sprintf(commandbuf, "( cd /etc/skel 2>/dev/null && cp -a . %s )", dir);
		system(commandbuf);

		sprintf(commandbuf, "touch %s", dir);
		system(commandbuf);

		sprintf(commandbuf, "chown --recursive 0.0 /etc/skel 2>/dev/null");
		system(commandbuf);

                printf("Adding [%s] to: /var/spool/mail\n",uname);
		sprintf(commandbuf, "touch /var/spool/mail/%s", uname);
		system(commandbuf);
		sprintf(commandbuf, "chown %d.mail /var/spool/mail/%s", uid, uname);
		system(commandbuf);
		sprintf(commandbuf, "chmod 600 /var/spool/mail/%s", uname);
		system(commandbuf);
		printf("\n");
		fflush(stdout);
		/* End SlackHacks */

}

/* Here is our trade secret patented copyrighted code to find an unused UID */

find_unused(begin)
	int begin;
{
	int trial;
	struct passwd *pw;
	trial = begin - 1;

        printf("\nChecking for an available UID after: %d\n",init_uid);

	while ((pw = getpwuid(++trial)) != NULL)
	{
		printf("%d...",trial);
	}
	
	printf("\nFirst unused UID is: %d\n", trial);

	return(trial);
}

found_shadow()
{
	printf("You have a /etc/shadow password file, this adduser program will\n");
	printf("only create non shadow passwords in /etc/passwd.\n");
	printf("Remove or rename the /etc/shadow file to use this adduser program.\n");
	fclose(bull);
	exit(1);
}


