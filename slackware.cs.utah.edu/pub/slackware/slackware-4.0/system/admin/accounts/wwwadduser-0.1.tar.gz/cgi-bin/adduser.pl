#!/usr/bin/perl
require "cgi-lib.pl";
MAIN:
{
&ReadParse(*input);
 
$salt = substr($pwd, 0 ,2);

$LOGIN = $input{"username"};
$PASSWORD = $input{"password"};
$REALNAME = $input{"realname"};
$UID = $input{"uid"};

# hardcoded GID, change as you need it.
$GID = "100";

# A hardcoded path, change to suit you system.

open(PASSWD, ">>/u/httpd/htdocs/add/$LOGIN") || die "can't open file";

print(PASSWD "$LOGIN:$PASSWORD:$UID:$GID:$REALNAME:/home/dir/$LOGIN:/bin/true\n"); 
close(PASSWD);


# Print the header
  print &PrintHeader;
  print "<html><head>\n";
  print "<title>Results</title>\n";
  print "</head>\n";
  
# Do some processing, and print some output
  ($text = $input{'text'}) =~ s/\n/\n<BR>/g; 
                                   # add <BR>'s after carriage returns
                                   # to multline input, since HTML does not
                                   # preserve line breaks
  print <<ENDOFTEXT;

<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#0000EE" VLINK="#551A8B" 
ALINK="#FF0000">
<CENTER>
<hr width=480><br>
<table border=1 width=480>
<tr><td align=left>Username</td><td align=left>Password</td><td align=left>uid</td><td align=left>gid</td><td align=left>Real Name</td><td align=left>Home Dir</td><td align=left>Shell</td></tr><br>
<tr><td align=left>$LOGIN</td><td align=left>$PASSWORD</td><td align=left>$UID</td><td align=left>$GID</td><td align=left>$REALNAME</td><td align=left>/home/pip/$LOGIN</td><td align=left>/bin/true</td></tr>
</TABLE>
ENDOFTEXT
}
# If you want, just print out a list of all of the variables.
# Close the document cleanly.
