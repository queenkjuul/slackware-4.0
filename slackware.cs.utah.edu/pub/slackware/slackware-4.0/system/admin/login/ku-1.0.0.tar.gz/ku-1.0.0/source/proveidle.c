			/* @(#) proveidle.c */

/** File: proveidle.c  - Copyright (C) 1998 Nathan Benson
 ** This program is free software; you can redistribute it and/or modify
 ** it under the terms of the GNU General Public License as published by
 ** the Free Software Foundation; version 2 of the License.
 **
 ** This program is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 ** GNU General Public License for more details.
 **/

#include <time.h>
#include <stdio.h>
#include <stdarg.h>
#include "../include/ku.h"
char	*ctime();

int	ProveIdleTime(time_t when, struct CLargs args)
{
	static	time_t	now = 0;
	time_t	secondsIdle;

	if (now == 0)
	{
		time(&now);
	}
	secondsIdle=(now - when);

	if ((secondsIdle) >= (args.i_arg * 60))
//	if ((secondsIdle) >= (args.i_arg *(60)))
	{
		return(0);
	}
	return(-1);
}
/* EOF */
