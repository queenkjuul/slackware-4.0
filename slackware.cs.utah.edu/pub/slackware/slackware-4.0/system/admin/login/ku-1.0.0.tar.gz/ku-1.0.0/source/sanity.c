			/* @(#) sanity.c */

/** File: sanity.c - Copyright (C) 1998 Nathan Benson
 ** This program is free software; you can redistribute it and/or modify
 ** it under the terms of the GNU General Public License as published by
 ** the Free Software Foundation; version 2 of the License.
 **
 ** This program is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 ** GNU General Public License for more details.
 **/

#include "../include/ku.h"

int	CheckSanity(struct CLopt opt)
{
	if (((opt.opt_v)
	||(opt.opt_h)
	||(opt.opt_p)
	||(opt.opt_m)
	||(opt.opt_b))
	&&(!opt.opt_s)
	&&(!opt.opt_g)
	&&(!opt.opt_t)
	&&(!opt.opt_u)
	&&(!opt.opt_x)
	&&(!opt.opt_i)
	&&(!opt.opt_a)
	&&(!opt.opt_T)
	&&(!opt.opt_G))
	{
		return(1);
	}
	else
	{
		return(0);
	}
	return(3);
}
/* EOF */
