#define	 VERSION "1.00.1a"
#define  COPYRIGHT "(C)opyright 1994-1995, B. Scott Burkett, All Rights Reserved"
#define  TABLE_SIZE	100

#ifndef TRUE
#define TRUE 	1
#define FALSE	!TRUE
#endif

void Init( int ac );
void Process(void);
int  CheckLogins(void);
void Guillotine(void);
int  ValidateUser(void);
void ReadCFGFile(void);
void SendFile(char *filename);
void SetSignals(void);
void suicide(int signum);
int ProcActive(int pid);

typedef struct  _cfg {
	char	_username[12];
	char 	_ttydevice[20];
} _CFG;

struct utmp	*userrec, recbuf;
FILE		*uf, *tty;
char		buf[80];
_CFG    	cfg[ TABLE_SIZE ];
_CFG		tmpcfg;
int		highentry=0;

