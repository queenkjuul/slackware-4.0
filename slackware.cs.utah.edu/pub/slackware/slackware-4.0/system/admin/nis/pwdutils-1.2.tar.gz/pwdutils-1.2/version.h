#ifndef __VERSION_H__
#define __VERSION_H__
static char version[] = "1.2";
#endif
