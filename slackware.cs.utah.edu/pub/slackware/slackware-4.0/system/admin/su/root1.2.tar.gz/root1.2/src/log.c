/* root v1.2 by interrupt request <irq@collective.org> http://www.collective.org/
   log() function - logs root uses to /var/log/rooters (LOG_FILE)
   called from main()
   
   Passed-to variables: char toSystem, the command requested by the user
   Returns: 0 (noerr)
*/

#include <stdio.h>
#include <string.h>
#include "main.h"

int log(char toSystem[256])
{
	FILE *logFile;
	char toLog[256];
	char chrint[80];
	int uid = getuid();
	logFile = fopen(LOG_FILE, "a");
	strcpy(toLog, "Executed by: ");
	sprintf(chrint, "%d", uid);
	strcat(toLog, chrint);
	strcat(toLog, " Command:");
	strcat(toLog, toSystem);
	strcat(toLog, "\n");
	fprintf(logFile, toLog);
	fclose(logFile);
	return 0;
}
