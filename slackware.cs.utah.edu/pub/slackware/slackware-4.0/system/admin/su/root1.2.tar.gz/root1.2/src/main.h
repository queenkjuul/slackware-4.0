#ifndef MAIN_H 
#define MAIN_H

int verify(int uid);
int log(char toSystem[256]);
int main(int argc, char *argv[]);

#define ROOTERS_FILE "/etc/rooters" // file containing rootable uid's
#define LOG_FILE "/var/log/rooters" // log file that contains commands executed by root
#endif
