#include "dnsconf.m"
#include <translat.h>

DICTIONARY_REQUEST;


