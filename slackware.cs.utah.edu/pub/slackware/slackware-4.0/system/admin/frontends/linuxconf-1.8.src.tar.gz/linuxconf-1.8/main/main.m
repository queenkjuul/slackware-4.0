extern const char **_dictionary_main;
#ifndef DICTIONARY_REQUEST
	#define DICTIONARY_REQUEST \
	const char **_dictionary_main;\
	TRANSLATE_SYSTEM_REQ _dictionary_req_main("main",_dictionary_main,60,1);\
	void dummy_dict_main(){}
#endif
#ifndef MSG_U
	#define MSG_U(id,m)	_dictionary_main[id]
	#define MSG_B(id,m,n)	_dictionary_main[id]
	#define MSG_R(id)	_dictionary_main[id]
	#define P_MSG_U(id,m)	new_trans_notload(_dictionary_main,id)
	#define P_MSG_B(id,m,n)	new_trans_notload(_dictionary_main,id)
	#define P_MSG_R(id)	new_trans_notload(_dictionary_main,id)
#endif
#define MNU_BASIC	0
#define MNU_BOOT	1
#define MNU_LOGS	2
#define MNU_FILESYS	3
#define MNU_GRAPH	4
#define MNU_NET	5
#define MNU_USERS	6
#define MNU_CONFIGS	7
#define MNU_DATE	8
#define MNU_CONFIG	9
#define MNU_SET	10
#define MNU_VIEW	11
#define MNU_LIST	12
#define TITLE	13
#define MNU_INTRO	14
#define ERR_BOOT	15
#define ERR_NAME	16
#define MNU_COMMANDS	17
#define E_DEMOINIT	18
#define M_RUNLEVEL	19
#define M_REBOOT	20
#define M_UPDATE	21
#define T_CONTROL	22
#define I_CONTROL	23
#define Q_SYSTASK	24
#define E_DEMO	25
#define MNU_CONTROL	26
#define N_NOJOB	27
#define F_REBOOT	28
#define F_HALT	29
#define F_DELAI	30
#define F_MESSAGE	31
#define T_SHUTDOWN	32
#define I_SHUTDOWN	33
#define MNU_MODULE	34
#define M_MODULES	35
#define M_NETLEVEL	36
#define M_RESTART	37
#define T_PRIVSHUTDOWN	38
#define T_PSYSCONTROL	39
#define P_ACTIVATECHG	40
#define P_SHUTDOWN	41
#define P_NETLEVEL	42
#define T_PACTCHG	43
#define T_PNETLEVEL	44
#define T_PVIEWLOGS	45
#define F_HTMLTIMEOUT	46
#define T_FEATURES	47
#define I_FEATURES	48
#define E_HTMLTIMEOUT	49
#define P_VIEWLOGS	50
#define M_BOOTLOGS	51
#define M_LINUXCONFLOGS	52
#define M_NORMALLOG	53
#define M_ERRORLOGS	54
#define T_SYSLOGS	55
#define I_SYSLOGS	56
#define M_FEATURES	57
#define I_HTMLINTRO	58
#define E_HTTP	59
