/* Here is what you may play with to configure the package */

#define USR_LIB_XCONF	"/usr/lib/X11/xconf"

#define DONT_TOUCH		"#This file was produced and edited by xconf\n" \
						"#It can be edited by hand, but comment won't\n" \
						"#be kept by xconf\n" \
						"\n"

