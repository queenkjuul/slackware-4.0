#include "dialog.h"


/*
	Display a message box. Program will pause and display an "OK" button
	if the parameter 'pause' is non-zero.
*/
int dialog_msgbox(
	const char *title,
	const char *prompt,
	const char *icon)
{
	DIALOG dia;
	int nof=0;
	dia.seticon (icon);
	return dia.edit (title,prompt,help_nil,nof,MENUBUT_OK);
}
