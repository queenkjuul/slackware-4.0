#include "dnsconf.h"
#include "internal.h"


/*
	Do a set of consistency check on the DNS configuration
	and interactivly prompt the user for correction.
*/
PUBLIC void DNS::check()
{
}



