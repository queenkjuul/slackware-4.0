#pragma interface
#ifndef XCONF_H
#define XCONF_H

#include "config.h"

#include <dialog.h>
#include <stdio.h>

class XCONFIG;
class COMPONENTS;
class NOTICE;
class ACTION;

#include "xconf.p"

#endif

