#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "misc.h"
#include <userconf.h>
#include "misc.m"

/*
	Copy one file.
	Check if user is allowed
	Return -1 if any error.
*/
int file_copy (const char *src, const char *dst)
{
	int ret = -1;
	if (perm_rootaccess (MSG_U(P_COPYSYSFILES,"to copy system files"))){
		if (strcmp(src,dst)==0){
			ret = 0;
		}else{
			char buf[2*PATH_MAX];
			sprintf (buf,"cp %s %s",src,dst);
			ret = system (buf);
		}
	}
	return ret;
}

