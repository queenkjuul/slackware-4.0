/* _dict.c 14/08/96 16.09.34 */
/* base64.c 16/07/96 01.22.14 */
/* buttons.c 06/10/96 22.33.34 */
PUBLIC int BUTTONS_INFO::evalwidth (void);
PUBLIC BUTTONS_INFO::BUTTONS_INFO (void);
PUBLIC void BUTTONS_INFO::setbutinfo (int id,
	 const char *title,
	 const char *icon);
PUBLIC void BUTTONS_INFO::set (int _but_options, HELP_FILE&_helpfile);
PUBLIC void BUTTONS_INFO::setup (int _y, int width);
PUBLIC void BUTTONS_INFO::setcursor (WINDOW *dialog, int button);
PUBLIC void BUTTONS_INFO::draw (WINDOW *dialog, int button);
PRIVATE void BUTTONS_INFO::help (WINDOW *win);
PUBLIC MENU_STATUS BUTTONS_INFO::dokey (WINDOW *dialog,
	 int key,
	 int &selected,
	 int other_focus);
/* checkbox.c 22/09/96 21.13.26 */
PUBLIC FIELD_CHECK_RADIO::FIELD_CHECK_RADIO (const char *_prompt,
	 char &_var,
	 const char *_title);
PUBLIC FIELD_CHECK_RADIO::~FIELD_CHECK_RADIO (void);
PUBLIC void FIELD_CHECK_RADIO::restore (void);
PUBLIC void FIELD_CHECK_RADIO::save (void);
PUBLIC void FIELD_CHECK_RADIO::setcursor (WINDOW *dialog);
PUBLIC void FIELD_CHECK_RADIO::drawtxt_check (WINDOW *dialog,
	 char openchar,
	 char closechar,
	 char selchar);
PUBLIC void FIELD_CHECK_RADIO::format_htmlkey (char *key, int nof);
PUBLIC FIELD_CHECK::FIELD_CHECK (const char *_prompt,
	 char &_var,
	 const char *_title);
PUBLIC void FIELD_CHECK::drawtxt (WINDOW *dialog);
PUBLIC void FIELD_CHECK::html_draw (int nof);
PUBLIC int FIELD_CHECK::html_validate (int nof);
PUBLIC void FIELD_CHECK::dokey (WINDOW *dialog, int key, FIELD_MSG&);
PUBLIC FIELD_CHECK *DIALOG::newf_chk (const char *prompt,
	 char &var,
	 const char *title);
PUBLIC FIELD_CHECK_MULTI::FIELD_CHECK_MULTI (const char *_prompt,
	 char &_var,
	 const char *_options[]);
PUBLIC void FIELD_CHECK_MULTI::drawtxt (WINDOW *dialog);
PUBLIC void FIELD_CHECK_MULTI::save (void);
PUBLIC void FIELD_CHECK_MULTI::restore (void);
PUBLIC void FIELD_CHECK_MULTI::html_draw (int nof);
PUBLIC int FIELD_CHECK_MULTI::html_validate (int nof);
PUBLIC void FIELD_CHECK_MULTI::dokey (WINDOW *dialog,
	 int key,
	 FIELD_MSG&);
PUBLIC FIELD_CHECK_MULTI *DIALOG::newf_chkm (const char *prompt,
	 char &var,
	 const char *title[]);
/* checklist.c 30/09/96 10.50.30 */
/* checklist1.c 26/09/96 13.54.12 */
/* cmdsock.c 06/10/96 15.47.10 */
PRIVATE void CMDSOCK::init (int port, int reuseadr);
PUBLIC CMDSOCK::CMDSOCK (const char *portname, int reuseaddr);
PUBLIC CMDSOCK::CMDSOCK (int port, int reuseaddr);
PUBLIC CMDSOCK::~CMDSOCK (void);
PUBLIC int CMDSOCK::is_ok (void);
PUBLIC void CMDSOCK::closecli (int fd);
PUBLIC void CMDSOCK::addcli (int fd, int timeout);
PUBLIC void CMDSOCK::addcli (int fd);
PUBLIC int CMDSOCK::listen (long timeout);
PUBLIC int CMDSOCK::getnbcli (void);
PUBLIC int CMDSOCK::readnext (void *buf, int size, int &cli);
/* def.c 30/03/96 00.21.00 */
/* diaetc.c 06/10/96 10.42.34 */
/* dialog.c 20/09/96 13.10.44 */
PUBLIC void DIALOG::save (void);
PUBLIC void DIALOG::restore (void);
PUBLIC void DIALOG::set_readonly (void);
PUBLIC void DIALOG::set_lastreadonly (void);
PUBLIC void DIALOG::last_noempty (void);
PUBLIC int DIALOG::was_modified (void);
PUBLIC FIELD *DIALOG::getitem (int no);
PUBLIC FIELD_MSG::FIELD_MSG (void);
PUBLIC void DIALOG::seticon (const char *_icon);
PUBLIC void DIALOG::setbutinfo (int id,
	 const char *title,
	 const char *icon);
PUBLIC void DIALOG::html_body (const char *ctl, ...);
PUBLIC void DIALOG::html_intro (const char *ctl, ...);
PUBLIC void DIALOG::html_end (const char *ctl, ...);
PUBLIC void DIALOG::set_alt_title (const char *_title);
/* fcombo.c 09/10/96 22.48.04 */
PUBLIC ELM_STR::ELM_STR (const char *_value, const char *_verbose);
PUBLIC ELM_STR::~ELM_STR (void);
PUBLIC ELM_STR *LIST_STR::getitem (int no);
PUBLIC const char *LIST_STR::getvalue (int no);
PUBLIC FIELD_COMBO::FIELD_COMBO (const char *_prompt, SSTRING&_str);
PUBLIC FIELD_LIST::FIELD_LIST (const char *_prompt, SSTRING&_str);
PUBLIC FIELD_COMBO::~FIELD_COMBO (void);
PUBLIC void FIELD_COMBO::addopt (const char *str);
PUBLIC void FIELD_COMBO::addopt (const char *value,
	 const char *verbose);
PROTECTED void FIELD_COMBO::assist (WINDOW *dialog);
PUBLIC void FIELD_COMBO::html_draw (int nof);
PUBLIC int FIELD_COMBO::html_validate (int nof);
PUBLIC FIELD_COMBO *DIALOG::newf_combo (const char *prompt,
	 SSTRING&str);
PUBLIC FIELD_LIST *DIALOG::newf_list (const char *prompt,
	 SSTRING&str);
PUBLIC VIRTUAL int FIELD_LIST::post_validate (void);
PUBLIC void FIELD_LIST::dokey (WINDOW *dialog, int , FIELD_MSG&);
PUBLIC FIELD_ENUM::FIELD_ENUM (const char *_prompt, int &_sel);
PUBLIC void FIELD_ENUM::restore (void);
PUBLIC void FIELD_ENUM::save (void);
PUBLIC void FIELD_ENUM::addopt (const char *str);
PUBLIC void FIELD_ENUM::addopt (const char *value,
	 const char *verbose);
PUBLIC FIELD_ENUM *DIALOG::newf_enum (const char *prompt, int &sel);
/* fcombom.c 30/09/96 10.52.58 */
PUBLIC ELM_STR_V::ELM_STR_V (const char *_str, char &_selected);
PUBLIC FIELD_COMBO_MANY::FIELD_COMBO_MANY (const char *_prompt,
	 SSTRING&_str);
PUBLIC void FIELD_COMBO_MANY::addopt (const char *str, char &selected);
PROTECTED void FIELD_COMBO_MANY::assist (WINDOW *dialog);
PUBLIC FIELD_COMBO_MANY *DIALOG::newf_combo_many (const char *prompt,
	 SSTRING&str);
/* field.c 26/09/96 10.15.30 */
PUBLIC FIELD::FIELD (const char *_prompt);
PUBLIC VIRTUAL FIELD::~FIELD (void);
PUBLIC VIRTUAL void FIELD::set_noempty (void);
PUBLIC VIRTUAL void FIELD::set_selectable (int _may_select);
PUBLIC VIRTUAL int FIELD::is_selectable (void);
PUBLIC VIRTUAL int FIELD::post_validate (void);
PUBLIC int FIELD::is_readonly (void);
PUBLIC void FIELD::set_readonly (void);
PROTECTED VIRTUAL void FIELD::processmsg (WINDOW *, FIELD_MSG&, int);
PROTECTED VIRTUAL int FIELD::getwidths (int []);
PROTECTED VIRTUAL void FIELD::setwidths (int , int []);
PUBLIC VIRTUAL const char *FIELD::getmenustr (void);
PUBLIC VIRTUAL void FIELD::format_htmlkey (char *key, int nof);
PRIVATE void FIELD_STRING_BASE::init (int maxsiz);
PROTECTED FIELD_STRING_BASE::FIELD_STRING_BASE (const char *_prompt,
	 const char *_str,
	 int maxsiz);
PROTECTED FIELD_STRING_BASE::FIELD_STRING_BASE (const char *_prompt,
	 int maxsiz);
PUBLIC FIELD_STRING_BASE::~FIELD_STRING_BASE (void);
PUBLIC int FIELD_STRING_BASE::is_empty (void);
PUBLIC int FIELD_STRING_BASE::post_validate (void);
PUBLIC FIELD_STRING::FIELD_STRING (const char *_prompt,
	 char *_str,
	 int maxsiz);
PUBLIC FIELD_STRING::~FIELD_STRING (void);
PUBLIC FIELD_PASSWORD::FIELD_PASSWORD (const char *_prompt,
	 SSTRING&_str);
PUBLIC void FIELD_STRING::save (void);
PUBLIC void FIELD_STRING::restore (void);
PUBLIC void FIELD_STRING_BASE::drawtxt (WINDOW *dialog);
PUBLIC void FIELD_STRING_BASE::html_draw (int nof);
PUBLIC int FIELD_STRING_BASE::html_validate (int nof);
PUBLIC void FIELD::draw (WINDOW *dialog);
PUBLIC VIRTUAL void FIELD::setcursor (WINDOW *dialog);
PUBLIC VIRTUAL void FIELD::unselect (WINDOW *);
PUBLIC void FIELD_STRING_BASE::setcursor (WINDOW *dialog);
PUBLIC void FIELD_STRING_BASE::dokey (WINDOW *dialog,
	 int key,
	 FIELD_MSG&);
PUBLIC FIELD_SSTRING::FIELD_SSTRING (const char *_prompt,
	 SSTRING&_str);
PUBLIC void FIELD_SSTRING::save (void);
PUBLIC void FIELD_SSTRING::restore (void);
PUBLIC void FIELD_SSTRING::html_draw (int nof);
PUBLIC FIELD_STRING *DIALOG::newf_str (const char *prompt,
	 char *str,
	 int maxsiz);
PUBLIC FIELD_SSTRING *DIALOG::newf_str (const char *prompt,
	 SSTRING&str);
PUBLIC FIELD_PASSWORD *DIALOG::newf_pass (const char *prompt,
	 SSTRING&str);
/* fldnum.c 04/10/96 17.00.00 */
PUBLIC FIELD_NUM::FIELD_NUM (const char *_prompt,
	 double *_dblval,
	 int *_intval,
	 int _ishex,
	 int _nbdecimals);
PROTECTED void FIELD_NUM::dokey (WINDOW *w, int key, FIELD_MSG&msg);
PUBLIC void FIELD_NUM::html_draw (int nof);
PUBLIC void FIELD_NUM::save (void);
PUBLIC void FIELD_NUM::restore (void);
PUBLIC int FIELD_NUM::post_validate (void);
PUBLIC FIELD *DIALOG::newf_num (const char *prompt, int &val);
PUBLIC FIELD *DIALOG::newf_hexnum (const char *prompt, int &val);
PUBLIC FIELD *DIALOG::newf_dbl (const char *prompt,
	 double &val,
	 int nbdecimals);
/* fstrhelp.c 01/08/96 00.01.46 */
PUBLIC FIELD_STRING_HELP::FIELD_STRING_HELP (const char *_prompt,
	 SSTRING&_str);
PUBLIC void FIELD_STRING_HELP::drawtxt (WINDOW *dialog);
PUBLIC void FIELD_STRING_HELP::dokey (WINDOW *dialog,
	 int key,
	 FIELD_MSG&msg);
/* ftitle.c 01/08/96 00.02.06 */
PUBLIC FIELD_TITLE::FIELD_TITLE (const char *_prompt,
	 const char *_str);
PUBLIC void FIELD_TITLE::drawtxt (WINDOW *win);
PUBLIC void FIELD_TITLE::html_draw (int);
PUBLIC int FIELD_TITLE::html_validate (int);
PUBLIC void DIALOG::newf_title (const char *prompt, const char *msg);
/* html.c 07/10/96 00.17.20 */
PRIVATE void DIALOG::html_draw_top (void);
PRIVATE void DIALOG::html_draw_intro (void);
PRIVATE void DIALOG::html_draw_fields (int nof);
PRIVATE void DIALOG::html_draw_form (int nof);
PRIVATE void DIALOG::html_draw_end (void);
PRIVATE void DIALOG::html_draw (DIALOG *spc, int nof);
PRIVATE void DIALOG::html_draw (int nof);
PRIVATE int DIALOG::html_validate (void);
PUBLIC void BUTTONS_INFO::html_draw (void);
PRIVATE MENU_STATUS DIALOG::edithtml (int &nof);
/* inputbox.c 30/09/96 10.52.10 */
/* internal.c 05/10/95 23.26.44 */
/* kbd.c 09/03/96 23.28.14 */
/* main.c 26/09/96 13.29.46 */
/* menubox.c 08/10/96 20.50.40 */
PUBLIC FIELD_MENU::FIELD_MENU (const char *_tag, const char *_str);
PUBLIC FIELD_MENU::~FIELD_MENU (void);
PUBLIC void FIELD_MENU::format_htmlkey (char *key, int);
PUBLIC void FIELD_MENU::setwidths (int total_width, int tb[]);
PROTECTED int FIELD_MENU::getwidths (int tb[]);
PUBLIC const char *FIELD_MENU::getmenustr (void);
PROTECTED void FIELD_MENU::save (void);
PROTECTED void FIELD_MENU::restore (void);
PROTECTED void FIELD_MENU::dokey (WINDOW *, int , FIELD_MSG&);
PUBLIC void FIELD_MENU::drawgen (WINDOW *win, int selected);
PUBLIC void FIELD_MENU::unselect (WINDOW *dialog);
PUBLIC void FIELD_MENU::setcursor (WINDOW *dialog);
PUBLIC void FIELD_MENU::drawtxt (WINDOW *dialog);
PUBLIC void FIELD_MENU::html_draw (int nof);
PUBLIC int FIELD_MENU::html_validate (int);
PRIVATE void DIALOG::fixwidth1 (void);
PUBLIC void DIALOG::new_menuline (const char *prompt1,
	 const char *prompt2,
	 int may_select);
PUBLIC void DIALOG::new_menuitem (const char *prompt1,
	 const char *prompt2);
PUBLIC void DIALOG::new_menuinfo (const char *prompt1,
	 const char *prompt2);
PUBLIC void DIALOG::new_menuitem (const char *prompt1,
	 const SSTRING&prompt2);
PUBLIC void DIALOG::new_menuitem (const SSTRING&prompt1,
	 const SSTRING&prompt2);
PUBLIC void DIALOG::new_menuitems (const char *opt[]);
PUBLIC const char *DIALOG::getmenustr (int choice);
PUBLIC void DIALOG::savewhat (const char *help);
PUBLIC void DIALOG::delwhat (const char *help);
PUBLIC void DIALOG::inswhat (const char *help);
PUBLIC void DIALOG::addwhat (const char *help);
PUBLIC MENU_STATUS DIALOG::editmenu (MENU_CONTEXT context,
	 const char *title,
	 const char *prompt,
	 HELP_FILE&helpfile,
	 int &sel,
	 int options);
PUBLIC MENU_STATUS DIALOG::editmenu (const char *title,
	 const char *prompt,
	 HELP_FILE&helpfile,
	 int &sel,
	 int options);
/* msgbox.c 26/09/96 13.31.50 */
/* multi.c 04/10/96 02.04.40 */
PRIVATE void DIALOG::setup (void);
PRIVATE void DIALOG::setoffset (int newoff);
PROTECTED void DIALOG::drawf (WINDOW *dialog);
PRIVATE void DIALOG::processmsg (WINDOW *dialog, FIELD_MSG&msg);
PRIVATE void DIALOG::draw (WINDOW *dialog);
PRIVATE void DIALOG::drawarrow_if (WINDOW *win,
	 bool condition,
	 bool&flag,
	 bool top,
	 chtype carac);
PROTECTED VIRTUAL int DIALOG::keymove (WINDOW *dialog,
	 int key,
	 int &nof);
PUBLIC DIALOG::DIALOG (void);
PUBLIC DIALOG::~DIALOG (void);
PUBLIC MENU_STATUS DIALOG::edit (const char *_title,
	 const char *_intro,
	 HELP_FILE&helpfile,
	 int &nof,
	 int but_options);
PUBLIC MENU_STATUS DIALOG::edit (const char *_title,
	 const char *intro,
	 HELP_FILE&helpfile,
	 int &nof);
PUBLIC MENU_STATUS DIALOG::edit (const char *_title,
	 const char *intro,
	 HELP_FILE&helpfile);
/* radio.c 17/09/96 00.17.44 */
PUBLIC FIELD_RADIO::FIELD_RADIO (const char *_prompt,
	 char &_var,
	 char _instance_val,
	 const char *_title);
PUBLIC FIELD_RADIO::~FIELD_RADIO (void);
PUBLIC void FIELD_RADIO::drawtxt (WINDOW *dialog);
PRIVATE FIELD_RADIO *FIELD_RADIO::locate_key (char *key);
PUBLIC void FIELD_RADIO::html_draw (int);
PUBLIC int FIELD_RADIO::html_validate (int);
PUBLIC void FIELD_RADIO::dokey (WINDOW *, int key, FIELD_MSG&msg);
PROTECTED void FIELD_RADIO::processmsg (WINDOW *dialog,
	 FIELD_MSG&msg,
	 int drawok);
PUBLIC FIELD_RADIO *DIALOG::newf_radio (const char *prompt,
	 char &var,
	 char instance_val,
	 const char *title);
/* rc.c 01/08/96 00.00.04 */
/* term.c 01/08/96 00.02.34 */
PRIVATE void DIALOG::showtimeout (WINDOW *win);
PRIVATE MENU_STATUS DIALOG::editterm (int &nof, int but_options);
/* textbox.c 26/09/96 13.24.08 */
PUBLIC FIELD_TEXTBOX::FIELD_TEXTBOX (const char *_prompt,
	 const char *_buf);
PUBLIC void FIELD_TEXTBOX::drawtxt (WINDOW *dialog);
PUBLIC void FIELD_TEXTBOX::html_draw (int);
PUBLIC int FIELD_TEXTBOX::html_validate (int);
PUBLIC DIALOG_TEXTBOX::DIALOG_TEXTBOX (void);
PROTECTED int DIALOG_TEXTBOX::keymove (WINDOW *dialog,
	 int key,
	 int &nof);
PUBLIC void DIALOG::newf_text (const char *prompt, const char *buftab);
/* varval.c 17/09/96 10.06.04 */
PUBLIC HTML_VARVAL::HTML_VARVAL (const char *key);
PUBLIC void HTML_VARVAL::add (const char *var, const char *val);
PUBLIC int HTML_VARVAL::getnb (void);
PUBLIC const char *HTML_VARVAL::getval (const char *var, int &exist);
PUBLIC const char *HTML_VARVAL::getval (int no);
PUBLIC const char *HTML_VARVAL::getvar (int no);
PUBLIC int HTML_VARVAL::exist (const char *var);
PUBLIC const char *HTML_VARVAL::getcontext (void);
PUBLIC int HTML_VARVAL::getid (void);
/* yesno.c 26/09/96 13.24.52 */
