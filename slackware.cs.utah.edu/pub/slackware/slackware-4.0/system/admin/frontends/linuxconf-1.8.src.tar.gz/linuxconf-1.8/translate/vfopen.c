#include <stdio.h>
#include "internal.h"

FILE *vfopen (const char *fname, const char *mode)
{
	return fopen (fname,mode);
}

