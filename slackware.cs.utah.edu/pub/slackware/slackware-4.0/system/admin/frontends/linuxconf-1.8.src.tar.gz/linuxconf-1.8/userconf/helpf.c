#include <misc.h>
#include "internal.h"
#include "userconf.h"
#include "../paths.h"

PUBLIC USERCONF_HELP_FILE::USERCONF_HELP_FILE (const char *fname)
	: HELP_FILE (HELP_USER,fname)
{
}

