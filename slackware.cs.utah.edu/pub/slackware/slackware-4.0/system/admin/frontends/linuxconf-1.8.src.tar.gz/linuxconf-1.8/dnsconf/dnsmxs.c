#include <stdio.h>
#include <string.h>
#include <misc.h>
#include "dnsconf.h"
#include "internal.h"
#include "../paths.h"

/*
	Edit the MXs for each domains
*/
PUBLIC void DNS::editmxs()
{
}

