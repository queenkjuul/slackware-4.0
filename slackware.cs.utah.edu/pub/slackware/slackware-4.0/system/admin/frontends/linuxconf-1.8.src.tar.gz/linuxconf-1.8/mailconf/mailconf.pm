/* _dict.c 14/08/96 15.04.54 */
/* alias.c 26/09/96 13.42.04 */
PUBLIC ALIAS::ALIAS (void);
PRIVATE void ALIAS::addoneval (const char *val);
PRIVATE void ALIAS::splitline (char *ptpt);
PUBLIC ALIAS::ALIAS (char *line);
PUBLIC const char *ALIAS::getname (void);
PUBLIC int ALIAS::filter_ok (void);
PUBLIC int ALIAS::file_ok (void);
PUBLIC void ALIAS::write (FILE *fout);
PUBLIC int ALIAS::is_valid (void);
PUBLIC int ALIAS::edit (void);
PUBLIC ALIAS *ALIASES::getitem (int no);
PRIVATE void ALIASES::addline (char *buf);
PUBLIC ALIASES::ALIASES (void);
PUBLIC int ALIASES::write (void);
PUBLIC int ALIASES::locate (const char *name);
PUBLIC void ALIASES::addnew (void);
PRIVATE int ALIASES::collect (const char **tb);
PUBLIC int ALIASES::edit (void);
/* basic.c 26/09/96 13.38.02 */
PUBLIC int MAILCONF::basicedit (void);
/* complex.c 27/09/96 14.02.26 */
PUBLIC COMPLEX_ROUTE::COMPLEX_ROUTE (const char *buf);
PUBLIC COMPLEX_ROUTE::COMPLEX_ROUTE (void);
PUBLIC int COMPLEX_ROUTE::edit (void);
PUBLIC COMPLEX_ROUTES::COMPLEX_ROUTES (void);
PUBLIC COMPLEX_ROUTE *COMPLEX_ROUTES::getitem (int no);
PUBLIC int COMPLEX_ROUTES::write (void);
PUBLIC int COMPLEX_ROUTES::edit (void);
PUBLIC int COMPLEX_ROUTE::rule0 (FILE *fout,
	 char *status,
	 SSTRINGS *aliases);
PUBLIC int COMPLEX_ROUTES::rule0 (FILE *fout, SSTRINGS&aliases);
/* confread.c 17/09/96 16.51.28 */
PUBLIC MAILCONF::MAILCONF (void);
PUBLIC int MAILCONF::write (void);
/* generate.c 27/09/96 14.01.02 */
PUBLIC MAILCONF_FILE::MAILCONF_FILE (const char *fname);
PUBLIC int MAILCONF::generate (bool);
/* helpf.c 14/08/96 15.06.34 */
PUBLIC MAILCONF_HELP_FILE::MAILCONF_HELP_FILE (const char *fname);
/* internal.c 10/09/95 01.01.22 */
/* mailconf.c 26/09/96 15.28.44 */
PUBLIC void MAILCONF::spcs_edit (void);
/* mtable.c 26/09/96 13.42.18 */
PUBLIC SPC_ROUTE::SPC_ROUTE (void);
PUBLIC void SPC_ROUTE::write (FILE *fout);
PUBLIC int SPC_ROUTE::edit (void);
PUBLIC SPC_ROUTES::SPC_ROUTES (void);
PUBLIC int SPC_ROUTES::save (void);
PUBLIC int SPC_ROUTES::build (const char *dbformat);
PUBLIC SPC_ROUTE *SPC_ROUTES::getitem (int no);
PUBLIC void SPC_ROUTES::sort (void);
PUBLIC int SPC_ROUTES::edit (void);
/* vdomain.c 19/09/96 00.33.22 */
PUBLIC VDOMAIN::VDOMAIN (const char *line);
PUBLIC VDOMAIN::VDOMAIN (void);
PUBLIC int VDOMAIN::edit (VDOMAINS&vs);
PUBLIC void VDOMAINS::sort (void);
PUBLIC VDOMAIN *VDOMAINS::getitem (int no);
PUBLIC VDOMAIN *VDOMAINS::getitem (const char *domain);
PUBLIC VDOMAINS::VDOMAINS (void);
PUBLIC int VDOMAINS::write (void);
PUBLIC MENU_STATUS VDOMAINS::select (const char *title,
	 const char *intro,
	 int mayadd,
	 int &nof);
PUBLIC int VDOMAINS::edit (void);
int FIXPERM_VDOMAIN::check (bool boottime);
PUBLIC int VDOMAINS::checkperm (bool);
