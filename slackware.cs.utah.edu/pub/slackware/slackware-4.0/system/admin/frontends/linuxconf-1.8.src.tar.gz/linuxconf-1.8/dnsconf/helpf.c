#include <misc.h>
#include "internal.h"
#include "../paths.h"

PUBLIC DNSCONF_HELP_FILE::DNSCONF_HELP_FILE (const char *fname)
	: HELP_FILE (HELP_DNSCONF,fname)
{
}

