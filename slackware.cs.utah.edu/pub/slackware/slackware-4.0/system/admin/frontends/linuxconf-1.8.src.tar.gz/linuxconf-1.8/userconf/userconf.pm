/* _dict.c 14/08/96 15.00.36 */
/* group.c 26/09/96 13.37.14 */
PRIVATE void GROUP::settbmem (char **members);
PRIVATE void GROUP::init (const char *_name,
	 const char *_passwd,
	 int _gid,
	 char **members);
PUBLIC GROUP::GROUP (const char *_name,
	 const char *_passwd,
	 int _gid,
	 char **members);
PUBLIC GROUP::GROUP (void);
PUBLIC GROUP::GROUP (struct group *p);
PUBLIC GROUP::~GROUP (void);
PUBLIC void GROUP::write (FILE *fout);
PUBLIC const char *GROUP::getname (void);
PUBLIC int GROUP::getgid (void);
PRIVATE int GROUP::check (USERS&users,
	 GROUPS&groups,
	 GROUP *realone);
PUBLIC int GROUP::edit (USERS&users, GROUPS&groups);
/* groups.c 30/09/96 23.54.06 */
PUBLIC GROUPS::GROUPS (void);
PUBLIC GROUPS::~GROUPS (void);
PUBLIC GROUP *GROUPS::getitem (int no);
PUBLIC GROUP *GROUPS::getitem (const char *name);
PUBLIC int GROUPS::getgid (const char *name);
PUBLIC int GROUPS::write (void);
PUBLIC const char *GROUPS::getdefault (void);
PUBLIC GROUP *GROUPS::getfromgid (int gid);
PUBLIC int GROUPS::getnew (void);
PUBLIC void GROUPS::sortbyname (void);
PUBLIC int GROUPS::edit (void);
PUBLIC void GROUPS::load_special (void);
/* helpf.c 14/08/96 15.01.30 */
PUBLIC USERCONF_HELP_FILE::USERCONF_HELP_FILE (const char *fname);
/* internal.c 27/08/95 12.26.28 */
/* passwd_valid.c 09/10/96 01.11.16 */
PUBLIC void PASSWD_VALID::write (void);
PUBLIC PASSWD_VALID::PASSWD_VALID (void);
PUBLIC void PASSWD_VALID::edit (void);
/* perm.c 30/09/96 10.48.50 */
/* privi.c 19/09/96 00.50.52 */
PUBLIC PRIVILEGE::PRIVILEGE (const char *_id,
	 TRANS_NOTLOAD *_title,
	 TRANS_NOTLOAD *_section);
PUBLIC PRIVILEGE::PRIVILEGE (const char *_id,
	 const char *_title,
	 const char *_section);
PUBLIC PRIVILEGE::~PRIVILEGE (void);
PUBLIC PRIVILEGE_DECLARATOR::PRIVILEGE_DECLARATOR (void (*_fct)());
PUBLIC const char *PRIVILEGE::gettitle (void);
PUBLIC const char *PRIVILEGE::getsection (void);
PUBLIC int PRIVILEGE_DATA::mustident (void);
PUBLIC int PRIVILEGE_DATA::has_priv (void);
PUBLIC PRIVILEGE_DATA_SIMPLE::PRIVILEGE_DATA_SIMPLE (const char *line);
PUBLIC PRIVILEGE_DATA_SIMPLE::PRIVILEGE_DATA_SIMPLE (void);
PUBLIC int PRIVILEGE_DATA_SIMPLE::format_ascii (char *line);
PUBLIC int PRIVILEGE_DATA_SIMPLE::validate (void);
PUBLIC void PRIVILEGE_DATA_SIMPLE::setdialog (const char *title,
	 DIALOG&dia);
PUBLIC PRIVILEGE_DATA *PRIVILEGE_DATAS::getitem (int no);
PUBLIC VIRTUAL PRIVILEGE_DATA *PRIVILEGE::getdata (const char *user);
PUBLIC VIRTUAL int PRIVILEGE::savedata (const char *user,
	 PRIVILEGE_DATA *data);
PUBLIC PRIVILEGES::PRIVILEGES (void);
PUBLIC PRIVILEGE *PRIVILEGES::getitem (int no);
PUBLIC PRIVI_FEATURE::PRIVI_FEATURE (const char *_id,
	 TRANS_NOTLOAD *_title,
	 TRANS_NOTLOAD *_section);
PUBLIC PRIVILEGE_DATA *PRIVI_FEATURE::getdata (const char *user);
PUBLIC void PRIVILEGE_DATA_FEATURE::setdialog (const char *title,
	 DIALOG&dia);
PUBLIC PRIVILEGE_DATA_FEATURE::PRIVILEGE_DATA_FEATURE (const char *line);
PUBLIC PRIVILEGE_DATA_FEATURE::PRIVILEGE_DATA_FEATURE (void);
/* shadow.c 10/10/96 22.59.46 */
PUBLIC SHADOW::SHADOW (const char *line);
PUBLIC SHADOW::SHADOW (void);
PUBLIC void SHADOW::setdialog (DIALOG&dia);
PUBLIC int SHADOW::writedef (void);
PUBLIC const char *SHADOW::getpwd (void);
PUBLIC void SHADOW::write (FILE *fout);
PUBLIC SHADOWS::SHADOWS (void);
PUBLIC SHADOW *SHADOWS::getitem (int no);
PUBLIC SHADOW *SHADOWS::getitem (const char *name);
PUBLIC int SHADOWS::write (PRIVILEGE *priv);
/* shells.c 27/09/96 10.13.48 */
/* special.c 27/09/96 10.12.42 */
/* user.c 09/10/96 23.56.38 */
PRIVATE void USER::init (const char *_name,
	 const char *_passwd,
	 int _uid,
	 int _gid,
	 const char *_gecos,
	 const char *_dir,
	 const char *_shell);
PUBLIC USER::USER (const char *_name,
	 const char *_passwd,
	 int _uid,
	 int _gid,
	 const char *_gecos,
	 const char *_dir,
	 const char *_shell);
PUBLIC USER::USER (void);
PUBLIC USER::USER (const char *line);
PUBLIC USER::USER (struct passwd *p);
PUBLIC USER::~USER (void);
PUBLIC const char *USER::getpwd (void);
PUBLIC void USER::write (FILE *fout);
PUBLIC const char *USER::getname (void);
PUBLIC const char *USER::getgecos (void);
PUBLIC int USER::getuid (void);
PUBLIC int USER::getgid (void);
PUBLIC const char *USER::getshell (void);
PUBLIC int USER::is_admin (void);
PUBLIC int USER::is_special (void);
PRIVATE int USER::check (USERS&users, GROUPS&groups, int full);
PUBLIC int USER::checkhome (char *status);
PUBLIC void USER::setname (const char *_name);
PUBLIC void USER::setgecos (const char *_gecos);
PUBLIC int USER::sethome (PRIVILEGE *priv);
PUBLIC int USER::edit (USERS&users,
	 GROUPS&groups,
	 int is_new,
	 PRIVILEGE *priv,
	 int editprivi);
PRIVATE void USER::update_passwd (const char *newp,
	 SHADOW *shadow,
	 int is_lock);
PUBLIC int USER::editpass (int lock_available,
	 SHADOW *shadow,
	 int confirm);
PUBLIC int USER::edithispass (SHADOW *shadow);
PUBLIC int USER::edithispass_notty (SHADOW *shadow);
/* user1.c 30/09/96 23.58.22 */
PUBLIC int USER::getcateg (void);
PUBLIC int USER::is_like (USER *other);
PUBLIC void USER::setlike (USER *other);
/* userconf.c 17/09/96 17.43.34 */
/* users.c 11/10/96 00.20.08 */
PRIVATE void USERS::readusers (void);
PUBLIC USERS::USERS (void);
PUBLIC USERS::USERS (CONFIG_FILE&_file,
	 const char *_home,
	 int _baseuid);
PUBLIC const char *USERS::getstdhome (void);
PRIVATE USERS::USERS (USERS *users);
PUBLIC USERS::~USERS (void);
PUBLIC USER *USERS::getitem (int no);
PUBLIC USER *USERS::getitem (const char *name, USER *exclude);
PUBLIC USER *USERS::getitem (const char *name);
PUBLIC SHADOW *USERS::getshadow (USER *usr);
PUBLIC void USERS::addshadow (SHADOW *shadow);
PUBLIC USER *USERS::getfromuid (int uid, USER *exclude);
PUBLIC USER *USERS::getfromuid (int uid);
PUBLIC int USERS::getnewuid (int);
PUBLIC int USERS::write (PRIVILEGE *priv);
PRIVATE USER *USERS::select_sorted (USER *like,
	 int may_add,
	 MENU_STATUS&code,
	 int &choice);
PUBLIC USER *USERS::select (USER *like,
	 int may_add,
	 MENU_STATUS&code,
	 int &choice);
PUBLIC int USERS::addone (USER *special,
	 const char *name,
	 GROUPS&groups,
	 const char *fullname,
	 PRIVILEGE *priv,
	 int editprivi);
PUBLIC void USERS::remove_del (USER *usr);
PUBLIC int USERS::edit (USER *special,
	 PRIVILEGE *priv,
	 int editprivi);
PUBLIC void USERS::sortbyname (void);
PUBLIC void USERS::sortbygid (void);
