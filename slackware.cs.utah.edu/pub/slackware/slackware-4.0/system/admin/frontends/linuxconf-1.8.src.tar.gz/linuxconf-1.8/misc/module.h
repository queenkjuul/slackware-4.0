#pragma interface
#ifndef MODULE_H
#define MODULE_H

class LINUXCONF_MODULE: public ARRAY_OBJ{
public:
	virtual int probe (int state, int target)=0; // see netconf/start.c
	/*~PROTOBEG~ LINUXCONF_MODULE */
public:
	LINUXCONF_MODULE (void);
	virtual int dohtml (const char *);
	virtual int domenu (MENU_CONTEXT, const char *);
	virtual int execmain (int , char *[]);
	virtual int fixperm (bool);
	virtual void setmenu (DIALOG&, MENU_CONTEXT);
	~LINUXCONF_MODULE (void);
	/*~PROTOEND~ LINUXCONF_MODULE */
};

#endif

