#include <string.h>
#include <stdlib.h>
#include "misc.h"

static char second = 0;

static int cmp_menu (const void *pt1, const void *pt2)
{
	char **p1 = (char**)pt1;
	char **p2 = (char**)pt2;
	return strcmp(p1[second],p2[second]);
}

/*
	Sort a table suitable for xconf_menu.
	sort_second allows sorting on the second item instead of the first
*/
void menuopt_sort (const char **menuopt, int nbmenu, int sort_second)
{
	second = sort_second != 0;
	qsort (menuopt,nbmenu,2*sizeof(char*),cmp_menu);
}

