#include "netconf.h"


PUBLIC PPPIPROUTE::PPPIPROUTE()
{
}
PUBLIC PPPIPROUTE::PPPIPROUTE(const char *s)
{
	s = dest.copyword (s);
	mask.copyword (s);
}


PUBLIC PPPIPROUTE *PPPIPROUTES::getitem(int no)
{
	return (PPPIPROUTE*)ARRAY::getitem(no);
}

/*
	Return != 0 if there is no routes defined
*/
PUBLIC int PPPIPROUTES::empty()
{
	int ret = 1;
	for (int r=0; r<getnb(); r++){
		PPPIPROUTE *ir = getitem(r);
		if (!ir->dest.is_empty()){
			ret = 0;
			break;
		}
	}
	return ret;
}

