#include <stdlib.h>
#include <dialog.h>
#include <userconf.h>

int xconf_edit ()
{
	if (perm_rootaccess("to configure X")){
		dialog_end();
		system ("/usr/X11R6/bin/xf86config");
		dialog_clear();
	}
	return 0;
}
int xconf_main (int , char *[])
{
	return xconf_edit();
}

