#include <misc.h>
#include "fstab.h"
#include "../paths.h"

PUBLIC FSTAB_HELP_FILE::FSTAB_HELP_FILE (const char *fname)
	: HELP_FILE (HELP_FSTAB,fname)
{
}

