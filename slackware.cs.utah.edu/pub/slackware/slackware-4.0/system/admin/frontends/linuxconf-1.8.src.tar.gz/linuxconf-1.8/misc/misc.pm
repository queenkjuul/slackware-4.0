/* _dict.c 14/08/96 14.39.06 */
/* array.c 10/10/96 01.06.44 */
PUBLIC ARRAY_OBJ::ARRAY_OBJ (void);
PUBLIC VIRTUAL ARRAY_OBJ::~ARRAY_OBJ (void);
PUBLIC void ARRAY_OBJ::rstmodified (void);
PUBLIC void ARRAY_OBJ::setmodified (void);
PUBLIC VIRTUAL int ARRAY_OBJ::was_modified (void);
PUBLIC VIRTUAL int ARRAY_OBJ::edit (void);
PUBLIC ARRAY::ARRAY (void);
PUBLIC void ARRAY::neverdelete (void);
PUBLIC void ARRAY::setgrowth (int _increm);
PUBLIC VIRTUAL ARRAY::~ARRAY (void);
PROTECTED void ARRAY::grow (void);
PUBLIC int ARRAY::remove (ARRAY_OBJ *obj);
PUBLIC int ARRAY::lookup (ARRAY_OBJ *o)const;
PUBLIC void ARRAY::moveto (ARRAY_OBJ *o, int newpos);
PUBLIC void ARRAY::remove_all (void);
PUBLIC void ARRAY::remove_del (ARRAY_OBJ *obj);
PUBLIC void ARRAY::remove_del (int no);
PUBLIC void ARRAY::delall (void);
PUBLIC int ARRAY::getnb (void)const;
PUBLIC void ARRAY::add (ARRAY_OBJ *pt);
PUBLIC void ARRAY::insert (int pos, ARRAY_OBJ *pt);
PROTECTED ARRAY_OBJ *ARRAY::getitem (int no)const;
PUBLIC void ARRAY::rstmodified (void);
PUBLIC VIRTUAL int ARRAY::was_modified (void);
PUBLIC void ARRAY::sort (int (*cmp)(const ARRAY_OBJ *, const ARRAY_OBJ *));
PUBLIC VIRTUAL int ARRAY::write (void);
PUBLIC int ARRAY::manage_edit (ARRAY_OBJ *e, int code, int insertpos);
PUBLIC int ARRAY::manage_edit (ARRAY_OBJ *e, int code);
PUBLIC int ARRAY::editone (int no);
PUBLIC int ARRAY::editone (ARRAY_OBJ *e);
/* confdb.c 04/10/96 13.48.18 */
PUBLIC CONFOBJ::CONFOBJ (const char *_key, const char *_val);
PUBLIC void CONFDB::addline (const char *buf);
PUBLIC CONFDB::CONFDB (CONFIG_FILE&_fcfg);
PUBLIC CONFDB::CONFDB (void);
PUBLIC CONFOBJ *CONFDB::getitem (int no);
PUBLIC int CONFDB::save (PRIVILEGE *priv);
PUBLIC int CONFDB::save (void);
PUBLIC const char *CONFDB::getval (const char *prefix,
	 const char *key,
	 const char *defval);
PUBLIC const char *CONFDB::getval (const char *prefix,
	 const char *key);
PUBLIC int CONFDB::getvalnum (const char *prefix,
	 const char *key,
	 int defval);
PUBLIC double CONFDB::getvalf (const char *prefix,
	 const char *key,
	 double defval);
PUBLIC int CONFDB::getall (const char *prefix,
	 const char *key,
	 SSTRINGS&lst,
	 int copy);
PUBLIC void CONFDB::removeall (const char *prefix, const char *key);
PUBLIC void CONFDB::add (const char *prefix,
	 const char *key,
	 const char *val);
PUBLIC void CONFDB::add (const char *prefix,
	 const char *key,
	 const SSTRING&val);
PUBLIC void CONFDB::add (const char *prefix,
	 const char *key,
	 int val);
PUBLIC void CONFDB::replace (const char *prefix,
	 const char *key,
	 const char *val);
PUBLIC void CONFDB::replace (const char *prefix,
	 const char *key,
	 int val);
PUBLIC void CONFDB::replace (const char *prefix,
	 const char *key,
	 double val);
PUBLIC void CONFDB::replace (const char *prefix,
	 const char *key,
	 const SSTRING&val);
PUBLIC void CONFDB::replace (const char *prefix,
	 const char *key,
	 const SSTRINGS&vals);
/* configf.c 29/10/96 14.37.56 */
PRIVATE void CONFIG_FILE::init (const char *_path,
	 int _status,
	 const char *_owner,
	 const char *_group,
	 int _perm);
PUBLIC CONFIG_FILE::CONFIG_FILE (const char *_path,
	 HELP_FILE&_helpfile,
	 int _status);
PUBLIC CONFIG_FILE::CONFIG_FILE (const char *_path,
	 HELP_FILE&_helpfile,
	 int _status,
	 const char *_owner,
	 const char *_group,
	 int _perm);
PUBLIC CONFIG_FILE::~CONFIG_FILE (void);
PUBLIC int CONFIG_FILE::setperm (const char *fpath)const;
PRIVATE void CONFIG_FILE::fixpath (void)const;
PUBLIC FILE *CONFIG_FILE::fopen_ok (const char *mode)const;
PUBLIC FILE *CONFIG_FILE::fopen (PRIVILEGE *priv,
	 const char *mode)const;
PUBLIC FILE *CONFIG_FILE::fopen (const char *mode)const;
PUBLIC FILE *CONFIG_FILE::fopen (PRIVILEGE *priv,
	 const char *temp,
	 const char *mode)const;
PUBLIC FILE *CONFIG_FILE::fopen (const char *temp,
	 const char *mode)const;
PUBLIC const char *CONFIG_FILE::getpath (void)const;
PUBLIC const char *CONFIG_FILE::getstdpath (void)const;
PUBLIC const char *CONFIG_FILE::gethelp (void)const;
PUBLIC int CONFIG_FILE::is_managed (void)const;
PUBLIC int CONFIG_FILE::is_optionnal (void)const;
PUBLIC int CONFIG_FILE::is_generated (void)const;
PUBLIC int CONFIG_FILE::is_erased (void)const;
PUBLIC int CONFIG_FILE::is_probed (void)const;
PUBLIC int CONFIG_FILE::exist (void)const;
PUBLIC long CONFIG_FILE::getdate (void)const;
PUBLIC int CONFIG_FILE::unlink (void)const;
PUBLIC void CONFIG_FILE::editpath (void);
/* dir.c 05/09/96 21.51.18 */
/* error.c 25/06/96 01.03.14 */
/* fgets.c 15/08/96 13.04.22 */
/* file.c 14/08/96 14.41.18 */
/* fopen.c 09/03/96 23.19.02 */
/* fopen1.c 06/09/96 11.45.08 */
/* helpf.c 26/09/96 16.05.00 */
PUBLIC HELP_FILE::HELP_FILE (const char *_subdir, const char *_fname);
PUBLIC const char *HELP_FILE::getpath (void);
PUBLIC void HELP_FILE::getrpath (char *rpath);
/* ipnum.c 06/10/96 15.35.14 */
/* linuxconf.c 11/10/96 00.00.58 */
/* malloc.c 14/08/96 14.40.26 */
/* menus.c 25/10/95 00.19.06 */
/* misc.c 18/02/96 14.32.16 */
/* module.c 06/10/96 14.55.48 */
PUBLIC LINUXCONF_MODULE *LINUXCONF_MODULES::getitem (int no);
PUBLIC LINUXCONF_MODULE::LINUXCONF_MODULE (void);
PUBLIC LINUXCONF_MODULE::~LINUXCONF_MODULE (void);
PUBLIC VIRTUAL void LINUXCONF_MODULE::setmenu (DIALOG&, MENU_CONTEXT);
PUBLIC VIRTUAL int LINUXCONF_MODULE::dohtml (const char *);
PUBLIC VIRTUAL int LINUXCONF_MODULE::domenu (MENU_CONTEXT, const char *);
PUBLIC VIRTUAL int LINUXCONF_MODULE::fixperm (bool);
PUBLIC VIRTUAL int LINUXCONF_MODULE::execmain (int , char *[]);
PUBLIC MODULE_INFO::MODULE_INFO (const char *buf);
PUBLIC MODULE_INFO::MODULE_INFO (void);
PUBLIC int MODULE_INFO::write (void);
PUBLIC int MODULE_INFO::locate (char realpath[PATH_MAX]);
PUBLIC MODULE_INFO *MODULE_INFOS::getitem (int no);
PUBLIC MODULE_INFOS::MODULE_INFOS (void);
PUBLIC int MODULE_INFOS::write (void);
/* popen.c 04/11/96 19.28.44 */
PUBLIC POPEN::POPEN (const char *command);
PUBLIC POPEN::~POPEN (void);
PUBLIC void POPEN::kill (void);
PUBLIC void POPEN::forget (void);
PRIVATE void POPEN::waitone (void);
PRIVATE void POPEN::waitend (void);
PUBLIC int POPEN::isok (void);
PRIVATE void POPEN::readif (struct fd_set *in, int fd, SSTRING&buf);
PRIVATE void POPEN::checksignal (void);
PUBLIC int POPEN::wait (int timeout, int otherfd);
PUBLIC int POPEN::wait (int timeout);
PUBLIC int POPEN::getstatus (void);
PRIVATE int POPEN::readline (char *line, int size, SSTRING&buf);
PUBLIC int POPEN::readerr (char *line, int size);
PUBLIC int POPEN::readout (char *line, int size);
/* sstring.c 04/10/96 13.17.34 */
PUBLIC SSTRING::SSTRING (void);
PUBLIC SSTRING::SSTRING (const char *_str);
PUBLIC SSTRING::SSTRING (const char *_str, int _maxsiz);
PUBLIC SSTRING::SSTRING (const SSTRING&_str);
PUBLIC SSTRING&SSTRING::operator = (const SSTRING&_str);
PUBLIC SSTRING::~SSTRING (void);
PUBLIC void SSTRING::copy (char *dst)const;
PUBLIC void SSTRING::copy (SSTRING&dst)const;
PUBLIC VIRTUAL void SSTRING::setfrom (const char *src);
PUBLIC void SSTRING::setfrom (const SSTRING&src);
PUBLIC void SSTRING::setfrom (int val);
PUBLIC void SSTRING::append (const char *app);
PUBLIC int SSTRING::getval (void)const;
PUBLIC double SSTRING::getvalf (void)const;
PUBLIC int SSTRING::getlen (void)const;
PUBLIC const char *SSTRING::get (void)const;
PUBLIC int SSTRING::cmp (const char *other)const;
PUBLIC int SSTRING::ncmp (const char *other, int len)const;
PUBLIC int SSTRING::icmp (const char *other)const;
PUBLIC int SSTRING::icmp (const SSTRING&other)const;
PUBLIC const char *SSTRING::strchr (char carac);
PUBLIC const char *SSTRING::strstr (const char *sub);
PUBLIC int SSTRING::cmp (const SSTRING&other)const;
PUBLIC void SSTRING::setmaxsiz (int size);
PUBLIC int SSTRING::getmaxsiz (void)const;
PUBLIC int SSTRING::is_empty (void)const;
PUBLIC void SSTRING::strip_end (void);
PUBLIC char *SSTRING::copyword (const char *line);
PUBLIC void CSSTRING::setcomment (const SSTRING&com);
/* sstrings.c 14/10/95 23.26.26 */
PUBLIC SSTRING *SSTRINGS::getitem (int no)const;
PUBLIC void SSTRINGS::sort (void);
PUBLIC int SSTRINGS::lookup (const char *str)const;
PUBLIC int SSTRINGS::lookup (const SSTRING *str)const;
/* str.c 04/11/96 11.33.20 */
/* uname.c 03/04/96 00.02.40 */
/* xconf1.c 26/09/96 13.30.14 */
/* xconf2.c 26/09/96 13.35.48 */
