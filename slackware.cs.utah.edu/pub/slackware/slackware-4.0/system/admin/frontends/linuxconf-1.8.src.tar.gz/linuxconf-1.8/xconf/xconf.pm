/* adaptor.c 06/01/95 23.11.22 */
/* component.c 12/01/95 15.28.04 */
PUBLIC COMPONENT::COMPONENT (const char *manuf_id,
	 const char *model_id,
	 XCONFIG *_xconfig,
	 NOTICE *_notice,
	 ACTION *_action);
PUBLIC COMPONENTS::COMPONENTS (void);
PUBLIC VIRTUAL COMPONENTS::~COMPONENTS (void);
PUBLIC void COMPONENTS::add (COMPONENT *comp);
PUBLIC void COMPONENTS::add (XCONFIG *xconf);
PUBLIC void COMPONENTS::add (NOTICE *notice);
PUBLIC int COMPONENTS::read (const char *fname);
PUBLIC void COMPONENTS::sort (void);
PUBLIC void COMPONENTS::print (FILE *fout);
PUBLIC int COMPONENTS::setmenu (char *tbopt2[]);
PUBLIC COMPONENT *COMPONENTS::item (int no);
/* error.c 08/01/95 21.42.08 */
/* files.c 06/01/95 23.12.18 */
/* mouse.c 08/01/95 21.43.32 */
/* notice.c 17/08/94 23.35.48 */
PUBLIC NOTICE::NOTICE (void);
PUBLIC NOTICE::~NOTICE (void);
PUBLIC void NOTICE::add (const char *str);
PUBLIC int NOTICE::print (FILE *fout, int indent)const;
PUBLIC int NOTICE::format (char *buf, int maxsiz)const;
/* screen.c 08/01/95 21.43.42 */
/* section.c 12/02/95 23.18.10 */
PUBLIC PAIRES::PAIRES (const char *keyword, const char *value);
PUBLIC VIRTUAL PAIRES::~PAIRES (void);
PUBLIC OPTION::OPTION (const char *keyword, const char *value);
PUBLIC VIRTUAL void OPTION::merge (const OPTION *src);
PUBLIC VIRTUAL OPTION *OPTION::clone (void)const;
PUBLIC VIRTUAL void OPTION::print (FILE *fout)const;
PUBLIC VIRTUAL int OPTION::validate (char *msg);
PUBLIC OPTION *OPTIONS::getitem (int no)const;
PUBLIC VIRTUAL void OPTIONS::print (FILE *fout, int indent)const;
PUBLIC SECTION::SECTION (const char *_name);
PUBLIC VIRTUAL SECTION::~SECTION (void);
PUBLIC void SECTION::print (FILE *fout, int indent)const;
PUBLIC int SECTION::validate (char *msg);
/* section1.c 12/02/95 23.18.46 */
PUBLIC VIRTUAL SECTION *SECTION::clone (void)const;
PUBLIC const char *SECTION::findarg (const char *keyw);
/* section2.c 16/01/95 22.36.26 */
PUBLIC int SECTION::readdisp (FILE *fin,
	 const char *fname,
	 int &noline,
	 SECTION_DISPATCH disp[]);
PUBLIC int KEYBOARD::read (FILE *fin,
	 const char *fname,
	 int &noline);
PUBLIC int POINTER::read (FILE *fin, const char *fname, int &noline);
PUBLIC int DEVICE::read (FILE *fin, const char *fname, int &noline);
PUBLIC int FILES::read (FILE *fin, const char *fname, int &noline);
/* stubs.c 14/03/95 23.46.08 */
/* xconf.c 16/01/95 01.00.26 */
/* xconf1.c 12/01/95 15.44.56 */
/* xconfig.c 16/01/95 22.32.48 */
PUBLIC XCONFIG::XCONFIG (void);
PUBLIC int XCONFIG::read (const char *fname);
PUBLIC void XCONFIG::sort (void);
PUBLIC int XCONFIG::print (FILE *fout, int indent);
PUBLIC COMMENTS::COMMENTS (void);
PUBLIC void COMMENTS::print (FILE *fout);
PUBLIC int XCONFIG::write (const char *fname);
PUBLIC void XCONFIG::merge (const XCONFIG *src);
PUBLIC void XCONFIG::addcomment (const char *keyw,
	 const char *manuf_id,
	 const char *model_id);
PUBLIC const char *XCONFIG::getcomment (const char *keyw);
