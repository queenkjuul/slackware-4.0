#include <misc.h>
#include "netconf.h"

PUBLIC NETCONF_HELP_FILE::NETCONF_HELP_FILE (const char *fname)
	: HELP_FILE (HELP_NETCONF,fname)
{
}

