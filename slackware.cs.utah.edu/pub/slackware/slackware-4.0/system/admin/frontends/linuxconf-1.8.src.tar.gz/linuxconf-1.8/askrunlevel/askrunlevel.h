#pragma interface
#ifndef ASKRUNLEVEL_H
#define ASKRUNLEVEL_H

struct ASK_PARM;

class CONFIG_FILE;
class HELP_FILE;

#include "askrunlevel.p"

#endif

