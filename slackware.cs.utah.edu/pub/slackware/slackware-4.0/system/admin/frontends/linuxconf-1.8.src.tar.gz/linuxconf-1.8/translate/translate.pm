/* anlparm.c 14/08/96 14.43.26 */
/* compile.c 19/02/96 00.25.34 */
/* internal.c 20/08/95 00.02.38 */
/* msgclean.c 14/08/96 14.43.38 */
/* msgcomp.c 18/04/96 15.14.58 */
/* msgscan.c 05/09/96 23.58.52 */
/* msgupd.c 18/04/96 15.34.50 */
/* notload.c 06/09/96 00.13.58 */
PUBLIC TRANS_NOTLOAD::TRANS_NOTLOAD (const char **&_table,
	 int _nomsg);
PUBLIC const char *TRANS_NOTLOAD::get (void);
/* sgml2flat.c 10/12/95 12.30.34 */
/* testtra.c 18/02/96 14.37.52 */
/* translat.c 15/08/96 01.13.18 */
PUBLIC TRANSLATE_SYSTEM_REQ::TRANSLATE_SYSTEM_REQ (const char *_sysname,
	 const char **&_global_var,
	 int _nb_expected,
	 int _version);
/* trstring.c 06/09/96 00.04.12 */
PUBLIC LANG_STRING::LANG_STRING (char _lang, const char *_str);
PUBLIC LANG_STRING *LANG_STRINGS::getitem (int no);
PUBLIC TR_STRING::TR_STRING (const char *_id);
PUBLIC const char *TR_STRING::getid (void);
PUBLIC int TR_STRING::was_changed (void);
PUBLIC void TR_STRING::reset_changed (void);
PUBLIC int TR_STRING::getnblang (void);
PUBLIC void TR_STRING::add2comment (const char *_comment);
PUBLIC SSTRING *TR_STRING::settranslation (char lang, const char *str);
PUBLIC LANG_STRING *TR_STRING::gettranslation (char lang);
PUBLIC void TR_STRING::deltranslation (char lang);
PUBLIC const char *TR_STRING::getmsg (char lang);
PUBLIC void TR_STRING::write (FILE *fout);
PUBLIC void TR_STRING::setorigin (const char *str);
PUBLIC const char *TR_STRING::getorigin (void);
PUBLIC TR_STRINGS::TR_STRINGS (void);
PUBLIC TR_STRING *TR_STRINGS::getitem (int no);
PUBLIC TR_STRING *TR_STRINGS::getitem (const char *id);
PUBLIC int TR_STRINGS::read (const char *fname);
PUBLIC int TR_STRINGS::write (const char *fname);
PUBLIC int TR_STRINGS::write_mod (const char *fname);
PUBLIC int TR_STRINGS::writeh (const char *sysname, const char *fname);
PUBLIC void TR_STRINGS::setversion (int ver);
PUBLIC int TR_STRINGS::getversion (void);
PUBLIC void TR_STRINGS::deltranslation (char lang);
PUBLIC void TR_STRINGS::showold (char deflang);
/* vfopen.c 01/03/96 23.43.20 */
