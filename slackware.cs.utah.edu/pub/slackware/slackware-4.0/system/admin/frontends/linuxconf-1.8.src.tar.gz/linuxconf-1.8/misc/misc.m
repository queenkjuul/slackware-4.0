extern const char **_dictionary_misc;
#ifndef DICTIONARY_REQUEST
	#define DICTIONARY_REQUEST \
	const char **_dictionary_misc;\
	TRANSLATE_SYSTEM_REQ _dictionary_req_misc("misc",_dictionary_misc,28,2);\
	void dummy_dict_misc(){}
#endif
#ifndef MSG_U
	#define MSG_U(id,m)	id
	#define MSG_B(id,m,n)	id
	#define MSG_R(id)	id
#endif
#define E_SETOWNER	_dictionary_misc[0]
#define E_SETGROUP	_dictionary_misc[1]
#define F_CORRPATH	_dictionary_misc[2]
#define T_MODCONFPATH	_dictionary_misc[3]
#define I_MODCONFPATH	_dictionary_misc[4]
#define T_LISTCONF	_dictionary_misc[5]
#define I_LISTCONF	_dictionary_misc[6]
#define P_MODCONF	_dictionary_misc[7]
#define P_COPYSYSFILES	_dictionary_misc[8]
#define E_CANTDO	_dictionary_misc[9]
#define E_WRITE	_dictionary_misc[10]
#define E_READ	_dictionary_misc[11]
#define E_UPDATE	_dictionary_misc[12]
#define E_OUTOFMEM	_dictionary_misc[13]
#define T_QUIT	_dictionary_misc[14]
#define I_QUIT	_dictionary_misc[15]
#define T_ERROR	_dictionary_misc[16]
#define I_ICONERROR	_dictionary_misc[17]
#define T_PLEASE	_dictionary_misc[18]
#define I_ICONNOTICE	_dictionary_misc[19]
#define T_AREYOUSURE	_dictionary_misc[20]
#define I_DELRECORD	_dictionary_misc[21]
#define F_MODPATH	_dictionary_misc[22]
#define F_MODACTIVE	_dictionary_misc[23]
#define I_EMPTYSLOT	_dictionary_misc[24]
#define T_MODLIST	_dictionary_misc[25]
#define I_MODLIST	_dictionary_misc[26]
#define E_MODNOPATH	_dictionary_misc[27]
