#pragma interface
#ifndef FCOMBO_H
#define FCOMBO_H

class ELM_STR: public ARRAY_OBJ{
public:
	char *value;
	char *verbose;
	/*~PROTOBEG~ ELM_STR */
public:
	ELM_STR (const char *_value, const char *_verbose);
	~ELM_STR (void);
	/*~PROTOEND~ ELM_STR */
};


class ELM_STR_V: public ELM_STR{
public:
	char &selected;
	/*~PROTOBEG~ ELM_STR_V */
public:
	ELM_STR_V (const char *_str, char &_selected);
	/*~PROTOEND~ ELM_STR_V */
};

class LIST_STR: public ARRAY{
	/*~PROTOBEG~ LIST_STR */
public:
	ELM_STR *getitem (int no);
	const char *getvalue (int no);
	/*~PROTOEND~ LIST_STR */
};

#endif

