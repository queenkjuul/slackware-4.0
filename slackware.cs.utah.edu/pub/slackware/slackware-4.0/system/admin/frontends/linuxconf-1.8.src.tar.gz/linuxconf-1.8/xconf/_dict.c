#include "xconf.m"
#include <translat.h>
DICTIONARY_REQUEST;


