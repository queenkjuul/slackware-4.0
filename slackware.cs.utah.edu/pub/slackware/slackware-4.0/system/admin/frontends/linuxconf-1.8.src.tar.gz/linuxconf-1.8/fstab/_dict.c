#include "fstab.m"
#include <translat.h>

DICTIONARY_REQUEST;

