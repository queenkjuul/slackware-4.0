extern const char **_dictionary_xconf;
#ifndef DICTIONARY_REQUEST
	#define DICTIONARY_REQUEST \
	const char **_dictionary_xconf;\
	TRANSLATE_SYSTEM_REQ _dictionary_req_xconf("xconf",_dictionary_xconf,2,0);\
	void dummy_dict_xconf(){}
#endif
#ifndef MSG_U
	#define MSG_U(id,m)	_dictionary_xconf[id]
	#define MSG_B(id,m,n)	_dictionary_xconf[id]
	#define MSG_R(id)	_dictionary_xconf[id]
	#define P_MSG_U(id,m)	new_trans_notload(_dictionary_xconf,id)
	#define P_MSG_B(id,m,n)	new_trans_notload(_dictionary_xconf,id)
	#define P_MSG_R(id)	new_trans_notload(_dictionary_xconf,id)
#endif
#define E_MISSCONF	0
#define E_MISSDIR	1
