#pragma interface
#ifndef MAIN_H
#define MAIN_H


#include "main.p"

#endif

