/* _dict.c 14/08/96 15.13.30 */
/* fixperm.c 18/09/96 23.46.12 */
PRIVATE void FIXPERM_SPEC::parsedev (SPEC_ONE&sp);
PUBLIC FIXPERM_SPEC::FIXPERM_SPEC (SPEC_ONE&sp);
PUBLIC int FIXPERM_SPEC::create (void);
PUBLIC int FIXPERM_SPEC::check (void);
PRIVATE void FIXPERM_SPECS::addline (const char *buf, SPEC_ONE&sp);
PUBLIC void FIXPERM_SPECS::addline (const char *buf);
PUBLIC FIXPERM_SPECS::FIXPERM_SPECS (const char *fname);
PUBLIC FIXPERM_SPECS::FIXPERM_SPECS (void);
PUBLIC FIXPERM_SPEC *FIXPERM_SPECS::getitem (int no);
PUBLIC int FIXPERM_SPECS::check (bool boottime);
PUBLIC int FIXPERM_SPECS::check (void);
PUBLIC FIXPERM_TASK::FIXPERM_TASK (void);
/* fstab.c 11/09/96 23.12.46 */
/* fstab1.c 03/10/96 15.13.12 */
PRIVATE void FSTAB_ENTRY::init (void);
PUBLIC FSTAB_ENTRY::FSTAB_ENTRY (void);
PUBLIC void FSTAB_ENTRY::parseopt (char *opts);
PUBLIC FSTAB_ENTRY::FSTAB_ENTRY (const char *line);
PUBLIC void FSTAB_ENTRY::format_opt (int tosave, char *str)const;
PUBLIC void FSTAB_ENTRY::print (FILE *fout)const;
PUBLIC int FSTAB_ENTRY::is_valid (void)const;
PUBLIC int FSTAB_ENTRY::is_auto (void);
PUBLIC int FSTAB_ENTRY::is_remote (void)const;
PUBLIC int FSTAB_ENTRY::is_swap (void)const;
PUBLIC FSTAB_ENTRY_TYPE FSTAB_ENTRY::gettype (void)const;
PUBLIC const char *FSTAB_ENTRY::getfs (void)const;
PUBLIC const char *FSTAB_ENTRY::getsource (void)const;
PUBLIC void FSTAB_ENTRY::setsource (const char *path);
PUBLIC const char *FSTAB_ENTRY::getmpoint (void)const;
PUBLIC const char *FSTAB_ENTRY::getcomment (void);
PUBLIC FSTAB::FSTAB (void);
PUBLIC FSTAB_ENTRY *FSTAB_GEN::getitem (int no);
PUBLIC int FSTAB::write (void);
/* fstab2.c 03/10/96 15.13.22 */
PUBLIC int FSTAB_ENTRY::edit (FSTAB_ENTRY_TYPE fstype);
PUBLIC void FSTAB::edit (FSTAB_ENTRY_TYPE fstype);
/* fstab3.c 14/08/96 15.14.22 */
PRIVATE void FSTAB::fixroot (FSTAB_ENTRY *root, char *status);
PUBLIC int FSTAB_ENTRY::check (void);
PUBLIC const char *FSTAB::getrootdev (void);
PUBLIC void FSTAB::check (void);
/* helpf.c 14/08/96 15.14.30 */
PUBLIC FSTAB_HELP_FILE::FSTAB_HELP_FILE (const char *fname);
/* mtab.c 14/08/96 15.14.38 */
PUBLIC MTAB::MTAB (void);
PUBLIC FSTAB_ENTRY *FSTAB_GEN::locate_mpoint (const char *str);
/* nfs.c 26/05/95 12.41.58 */
/* partition.c 14/08/96 15.14.52 */
PUBLIC PARTITION::PARTITION (const char *_dev, int _id, long _size);
PUBLIC PARTITION::~PARTITION (void);
PUBLIC void PARTITION::setdosdrive (char letter);
PUBLIC char PARTITION::getdosdrive (void);
PUBLIC int PARTITION::isdos (void);
PUBLIC int PARTITION::isos2 (void);
PUBLIC int PARTITION::isswap (void);
PUBLIC int PARTITION::islinux (void);
PUBLIC const char *PARTITION::getdevice (void);
PUBLIC long PARTITION::getsize (void);
PUBLIC int PARTITION::getid (void);
PUBLIC void PARTITION::formatinfo (char *buf);
PUBLIC const char *PARTITION::getos (void);
PUBLIC PARTITIONS::PARTITIONS (void);
PUBLIC PARTITION *PARTITIONS::getitem (int no)const;
PUBLIC PARTITION *PARTITIONS::getitem (const char *device)const;
PROTECTED void PARTITIONS::setdosdrive (void);
