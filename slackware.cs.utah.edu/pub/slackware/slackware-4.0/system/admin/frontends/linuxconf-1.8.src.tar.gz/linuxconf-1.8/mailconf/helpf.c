#include <misc.h>
#include "internal.h"
#include "../paths.h"

PUBLIC MAILCONF_HELP_FILE::MAILCONF_HELP_FILE (const char *fname)
	: HELP_FILE (HELP_MAILCONF,fname)
{
}

