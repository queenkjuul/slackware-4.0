#include "diadef.h"

/*
 * Global variables
 */
#ifdef HAVE_NCURSES

/* use colors by default? */
bool use_colors = USE_COLORS;

/* shadow dialog boxes by default?
   Note that 'use_shadow' implies 'use_colors' */
bool use_shadow = USE_SHADOW;

#endif


/* 
 * Attribute values, default is for mono display
 */
chtype attributes[] = {
  A_NORMAL,       /* screen_attr */
  A_NORMAL,       /* shadow_attr */
  A_REVERSE,      /* dialog_attr */
  A_REVERSE,      /* title_attr */
  A_REVERSE,      /* border_attr */
  A_BOLD,         /* button_active_attr */
  A_DIM,          /* button_inactive_attr */
  A_UNDERLINE,    /* button_key_active_attr */
  A_UNDERLINE,    /* button_key_inactive_attr */
  A_NORMAL,       /* button_label_active_attr */
  A_REVERSE,      /* button_label_inactive_attr */
  A_REVERSE,      /* inputbox_attr */
  A_REVERSE,      /* inputbox_border_attr */
  A_REVERSE,      /* searchbox_attr */
  A_REVERSE,      /* searchbox_title_attr */
  A_REVERSE,      /* searchbox_border_attr */
  A_REVERSE,      /* position_indicator_attr */
  A_REVERSE,      /* menubox_attr */
  A_REVERSE,      /* menubox_border_attr */
  A_REVERSE,      /* item_attr */
  A_NORMAL,       /* item_selected_attr */
  A_REVERSE,      /* tag_attr */
  A_REVERSE,      /* tag_selected_attr */
  A_NORMAL,       /* tag_key_attr */
  A_BOLD,         /* tag_key_selected_attr */
  A_REVERSE,      /* check_attr */
  A_REVERSE,      /* check_selected_attr */
  A_REVERSE,      /* uarrow_attr */
  A_REVERSE,      /* darrow_attr */
  A_REVERSE,      /* border_attr_shadow */
};

