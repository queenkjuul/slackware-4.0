/* _dict.c 14/08/96 15.16.28 */
/* askrunlevel.c 22/10/96 11.27.56 */
/* boot.c 22/10/96 10.58.36 */
/* internal.c 14/10/95 01.33.40 */
/* lilo.c 14/08/96 15.17.24 */
PUBLIC LILO_PARM::LILO_PARM (void);
PUBLIC LILO_CONF::LILO_CONF (void);
PUBLIC LILO_CONF *LILO_CONFS::getitem (int no);
PUBLIC LILO_OTHER *LILO_OTHERS::getitem (int no);
PRIVATE void LILO::parse_eq (const char *keyw,
	 const char *vals,
	 LILO_CUR&cur);
PRIVATE void LILO::parse_single (const char *pt, LILO_CUR&cur);
PRIVATE void LILO::compute_prefix (void);
PUBLIC LILO::LILO (void);
PUBLIC LILO_CONF *LILO::getconffromlabel (const char *lab);
PRIVATE void LILO::makecfgpath (const char *path, char *realpath);
PROTECTED void LILO::writeparm (FILE *fout,
	 LILO_PARM&p,
	 int global_parm);
PUBLIC int LILO::save (void);
PRIVATE void LILO::setupparm (DIALOG&dia, LILO_PARM&p);
PRIVATE void LILO::setupedit (DIALOG&dia);
PRIVATE int LILO::validate (int &nof);
PUBLIC int LILO::edit (void);
PUBLIC int LILO::updateif (void);
PUBLIC void LILO::addkernel (const char *def_src,
	 const char *def_name);
PUBLIC void LILO::setdefault (void);
/* modules.c 11/09/96 20.32.16 */
/* runlevels.c 06/10/96 11.35.32 */
PRIVATE void RUNLEVELS::parse (const char *str, RUNLEVEL *ptrun);
PUBLIC RUNLEVELS::RUNLEVELS (int graphic_ok, int net_ok);
PUBLIC RUNLEVELS::~RUNLEVELS (void);
PUBLIC void RUNLEVELS::save (void);
PUBLIC void RUNLEVELS::setmenu (const char *menuopt[]);
PUBLIC void RUNLEVELS::setlevel (int choice);
PUBLIC void RUNLEVELS::config (void);
PUBLIC void RUNLEVELS::define (void);
