#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <misc.h>
#include "netconf.h"
#include "netconf.m"

static NETCONF_HELP_FILE help_simul ("simul");

/* #Specification: netconf / simulation mode
	netconf can probe the environnement and compare to the
	current configuration. If it find some differences between
	the active setup and the requiered configuration, it will
	issue different commands to bring the system in sync with
	the configuration.

	One nice feature of netconf is that it can simulate all
	this and record all commands that would have been executed.
	This feature is mainly used by netconf which do a simulation
	before quitting from the interactive mode. If the simulation
	record any commands, netconf prompt the user and let him
	do a "netconf --update" interactivly.
*/

static FILE *fout = NULL;
static char do_close;
/*
	Start the simulation mode. Initialise the record buffer.
*/
void simul_init()
{
	if (fout == NULL){
		do_close = 1;
		fout = xconf_fopen (VAR_RUN_SIMUL,"w");
	}
}

void simul_init (FILE *f)
{
	fout = f;
	do_close = 0;
}

static char demo_mode = 0;
/*
	Set the demo flag.
	When active, linuxconf always tell that we are doing a simulation.
*/
void simul_setdemoflag (int on)
{
	demo_mode = (char)(on!=0);
}

static char disable_mode = 0;
/*
	Set the state of the disable mode
	When setting this mode, all configuration will be skipped.
	This is used when a config step notice some problem and is a simple
	way to tell the complete application to finish without carrying
	error flag everywhere.
*/
void simul_setdisable(char mode)
{
	disable_mode = mode;
	if (mode && fout != NULL){
		fclose (fout);
		fout = NULL;
	}
}
int simul_wasdisable()
{
	return disable_mode;
}
/*
	Return != 0 if we are running in demo mode
*/
int simul_isdemo()
{
	return demo_mode;
}
/*
	Return != 0 if we are running the end of a disabled config session
*/
int simul_isdisabled()
{
	return disable_mode;
}
/*
	Return != 0 if netconf is in simulation mode
*/
int simul_ison()
{
	return fout != NULL || demo_mode || disable_mode;
}

/*
	Record one shell command that would have been executed.
*/
void simul_addcommand(const char *cmd)
{
	if (fout != NULL) fprintf (fout,"Execute %s\n",cmd);
}
/*
	Record one comment.
*/
void simul_addmsg(const char *ctl, ...)
{
	if (fout != NULL){
		va_list list;
		va_start (list,ctl);
		vfprintf (fout,ctl,list);
		va_end (list);
		fflush (fout);
	}
}

/*
	Prompt the user, if needed after the simulation.
	Return 1 if an update of the system is need and the user
	has accepted to do it.

	Return 0 if there was nothing to do at all.
	Return -1 if there was something to do but the user escaped away.
	Return 1 if the user want to do it.
*/
int simul_prompt()
{
	int ret = 0;
	if (fout != NULL){
		int not_empty = ftell(fout) > 0;
		if (do_close) fclose (fout);
		fout = NULL;
		if (not_empty){
			int choice = 0;
			while (1){
				static const char *menuopt[]={
					MSG_U(M_ACTIVATE,"Activate"),	MSG_U(M_THECHANGES,"the changes"),
					MSG_U(M_PREVIEW,"Preview"),	MSG_U(M_WHATHAS,"what has to be done"),
					NULL
				};
				MENU_STATUS code = xconf_menu (
					MSG_U(T_STATUS,"Status of the system")
					,MSG_U(I_STATUS,"The state of the system is not\n"
					 "in sync with the current/updated\n"
					 "configuration. You are allowed to\n"
					 "make it current, or continue with\n"
					 "the current configuration. You can also\n"
					 "look at the things that will have to be done\n"
					 "to make the system current.\n")
					,help_simul
					,menuopt,choice);
				if (code != MENU_OK){
					ret = -1;
					break;
				}else if (choice == 0){
					ret = 1;
					break;
				}else if (choice == 1){
					dialog_textbox (MSG_U(T_THINGSTODO,"Things to do")
						,VAR_RUN_SIMUL);
				}
			}
		}
		unlink (VAR_RUN_SIMUL);
	}
	return ret;
}

