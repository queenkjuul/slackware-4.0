/* _dict.c 14/08/96 16.18.06 */
/* daemon.c 29/10/96 18.50.12 */
PUBLIC DAEMON::DAEMON (void);
PUBLIC void DAEMON::init (int _managed,
	 const char *_name,
	 const char *buf,
	 DAEMON *_next);
PUBLIC VIRTUAL DAEMON::~DAEMON (void);
PUBLIC int DAEMON::isok (void);
PUBLIC void DAEMON::setpidfile (CONFIG_FILE *_pidfile);
PUBLIC void DAEMON::settimeout (int nbsec);
PUBLIC int DAEMON::gettimeout (void);
PUBLIC int DAEMON::checkpath (void);
PUBLIC int DAEMON::system (const char *cmd);
PUBLIC VIRTUAL int DAEMON::start (void);
PUBLIC PROC *DAEMON::findprocess (void);
PUBLIC int DAEMON::signal (int signal_num,
	 const char *msg,
	 const char *sem_file);
PUBLIC int DAEMON::signal (int signal_num, const char *msg);
PUBLIC int DAEMON::kill (int signal_num);
PUBLIC VIRTUAL int DAEMON::stop (void);
PUBLIC VIRTUAL int DAEMON::restart (void);
PUBLIC int DAEMON::startif_file (const char *fname);
PUBLIC int DAEMON::startif_file (const CONFIG_FILE&cfile);
PUBLIC int DAEMON::startif_date (long date);
PUBLIC VIRTUAL int DAEMON::startif (void);
PUBLIC const char *DAEMON::getname (void);
PUBLIC DAEMON *DAEMON::getnext (void);
PUBLIC const char *DAEMON::getpath (void);
PUBLIC const char *DAEMON::getargs (void);
PUBLIC int DAEMON::is_managed (void);
PUBLIC int DAEMON::is_overriden (void);
PUBLIC void DAEMON::set_managed (int _managed);
PUBLIC void DAEMON::set_override (int _over);
PUBLIC void DAEMON::setspec (const char *_path, const char *_args);
PUBLIC void DAEMON::write (FILE *fout);
/* daemon1.c 29/10/96 17.19.36 */
PUBLIC int DAEMON::edit (void);
/* daemons.c 28/10/96 22.33.04 */
PUBLIC int DAEMON_INETD::restart (void);
PUBLIC int DAEMON_INETD::startif (void);
PUBLIC int DAEMON_AMD::stop (void);
PUBLIC int DAEMON_AMD::restart (void);
PUBLIC int DAEMON_AMD::startif (void);
PUBLIC int DAEMON_NFSD::startif (void);
PUBLIC int DAEMON_MOUNTD::startif (void);
PUBLIC int DAEMON_NAMED::startif (void);
PUBLIC int DAEMON_GATED::startif (void);
PUBLIC int DAEMON_GATED::restart (void);
PUBLIC int DAEMON_GATED::stop (void);
PUBLIC int DAEMON_GATED::start (void);
PUBLIC int DAEMON_SENDMAIL::startif (void);
PRIVATE void DAEMON_ROUTED::setcmdline (ROUTED&rt, char *cmdline);
PUBLIC int DAEMON_ROUTED::start (void);
PUBLIC int DAEMON_ROUTED::startif (void);
PRIVATE int DAEMON_YPBIND::set_domain (NIS_CONF&nis);
PUBLIC int DAEMON_YPBIND::start (void);
PUBLIC int DAEMON_YPBIND::startif (void);
PUBLIC int DAEMON_SSHD::startif (void);
/* datetime.c 30/09/96 10.33.52 */
PUBLIC DATETIME::DATETIME (void);
PUBLIC void DATETIME::save (void);
PUBLIC int DATETIME::edit (void);
PUBLIC void DATETIME::updatecmos (void);
PUBLIC int DATETIME::getfromcmos (void);
PUBLIC int DATETIME::getfromnet (void);
/* devices.c 06/10/96 15.49.16 */
/* devlist.c 14/08/96 16.19.40 */
/* exports.c 01/10/96 09.28.36 */
PUBLIC HOST_OPT::HOST_OPT (const char *_host, const char *options);
PUBLIC HOST_OPT::~HOST_OPT (void);
PUBLIC void HOST_OPT::write (char *buf);
PUBLIC void HOSTS_OPT::add (const char *_host, const char *_option);
PUBLIC char *HOSTS_OPT::parse_add (const char *pt, int &err);
PUBLIC HOST_OPT *HOSTS_OPT::getitem (int no);
PUBLIC void HOSTS_OPT::write (FILE *fout);
PUBLIC EXPORT_FS::EXPORT_FS (const char *buf, int noline);
PUBLIC EXPORT_FS::~EXPORT_FS (void);
PUBLIC const char *EXPORT_FS::getpath (void);
PUBLIC void EXPORT_FS::write (FILE *fout);
PUBLIC int EXPORT_FS::edit (void);
PUBLIC EXPORTS::EXPORTS (void);
PUBLIC EXPORT_FS *EXPORTS::getitem (int no);
PUBLIC int EXPORTS::write (void);
PUBLIC int EXPORTS::edit (void);
/* firewall.c 22/10/96 20.54.34 */
PUBLIC IPFW_RULE *IPFW_RULES::getitem (int no);
PROTECTED void IPFW_RULES::init (const char *key,
	 const char *key_active);
PUBLIC IPFW_RULES_FORWARD::IPFW_RULES_FORWARD (void);
PUBLIC IPFW_RULES_INPUT::IPFW_RULES_INPUT (void);
PUBLIC IPFW_RULES_OUTPUT::IPFW_RULES_OUTPUT (void);
PROTECTED int IPFW_RULES::savek (const char *key,
	 const char *key_active);
PUBLIC int IPFW_RULES_FORWARD::save (void);
PROTECTED IPFW_RULE *IPFW_RULES_FORWARD::newrule (void);
PROTECTED IPFW_RULE *IPFW_RULES_FORWARD::newrule (const char *pt);
PUBLIC int IPFW_RULES_INPUT::save (void);
PROTECTED IPFW_RULE *IPFW_RULES_INPUT::newrule (void);
PROTECTED IPFW_RULE *IPFW_RULES_INPUT::newrule (const char *pt);
PUBLIC int IPFW_RULES_OUTPUT::save (void);
PROTECTED IPFW_RULE *IPFW_RULES_OUTPUT::newrule (void);
PROTECTED IPFW_RULE *IPFW_RULES_OUTPUT::newrule (const char *pt);
PUBLIC int IPFW_RULES::edit (void);
PUBLIC int IPFW_RULES_INPUT::disable (int doit, SSTRING *collect);
PUBLIC int IPFW_RULES_INPUT::enable (int doit, SSTRING *collect);
PUBLIC int IPFW_RULES_INPUT::kernelok (void);
PUBLIC int IPFW_RULES_OUTPUT::disable (int doit, SSTRING *collect);
PUBLIC int IPFW_RULES_OUTPUT::enable (int doit, SSTRING *collect);
PUBLIC int IPFW_RULES_FORWARD::disable (int doit, SSTRING *collect);
PUBLIC int IPFW_RULES_FORWARD::enable (int doit, SSTRING *collect);
PUBLIC int IPFW_RULES_FORWARD::kernelok (void);
PUBLIC int IPFW_RULES_OUTPUT::kernelok (void);
PRIVATE void IPFW_RULES::reset_nbbitmsk (void);
PUBLIC int IPFW_RULES::setup (int doit, SSTRING *collect);
/* groutes.c 30/09/96 10.39.28 */
/* helpf.c 14/08/96 16.20.20 */
PUBLIC NETCONF_HELP_FILE::NETCONF_HELP_FILE (const char *fname);
/* host.c 06/10/96 15.52.16 */
/* hosts.c 06/10/96 15.52.38 */
PUBLIC void HOST::set (const char *buf);
PUBLIC HOST::HOST (const char *buf);
PUBLIC HOST::HOST (const char *_ip_num,
	 const char *_name1,
	 const char *_others,
	 const char *_comment);
PUBLIC HOST::HOST (void);
PRIVATE void HOST::freeall (void);
PUBLIC VIRTUAL HOST::~HOST (void);
PUBLIC const char *HOST::getname1 (void)const;
PUBLIC void HOST::setname1 (const char *_name1);
PUBLIC int HOST::iscomment (void)const;
PUBLIC const char *HOST::getcomment (void)const;
PUBLIC void HOST::setcomment (const char *_comment);
PUBLIC const char *HOST::getothers (void)const;
PUBLIC void HOST::setothers (const char *_others);
PUBLIC const char *HOST::getipnum (void)const;
PUBLIC void HOST::setipnum (const char *_ipnum);
PUBLIC VIRTUAL void HOST::print (FILE *fout)const;
PUBLIC VIRTUAL int HOST::is_special (void)const;
PUBLIC VIRTUAL int HOST::edit (HELP_FILE&helpfile);
PUBLIC HOSTS::HOSTS (void);
PUBLIC VIRTUAL HOST *HOSTS::newhost (const char *_ip_num,
	 const char *_name1,
	 const char *_others,
	 const char *_comment);
PUBLIC VIRTUAL HOST *HOSTS::newhost (const char *buf);
PUBLIC VIRTUAL void HOSTS::add (const char *buf);
PUBLIC VIRTUAL void HOSTS::add (const char *_ip_num,
	 const char *_name1,
	 const char *_others,
	 const char *_comment);
PUBLIC void HOSTS::add (HOST *pt);
PUBLIC int HOSTS::read (void);
PUBLIC int HOSTS::write (void)const;
PUBLIC HOST *HOSTS::getitem (int no)const;
PUBLIC HOST *HOSTS::getitem (const char *name)const;
PUBLIC int HOSTS::edit (const char *title, HELP_FILE&helpfile);
/* html_access.c 02/11/96 14.00.36 */
PUBLIC HTML_ACCESS::HTML_ACCESS (const char *_net, const char *_mask);
PUBLIC HTML_ACCESS_TB::HTML_ACCESS_TB (void);
PUBLIC HTML_ACCESS *HTML_ACCESS_TB::getitem (int no);
PUBLIC int HTML_ACCESS_TB::write (void);
PRIVATE void HTML_ACCESS_TB::addfield (DIALOG&dia, HTML_ACCESS *a);
PRIVATE void HTML_ACCESS_TB::addfields (DIALOG&dia);
PUBLIC int HTML_ACCESS_TB::edit (void);
PUBLIC int HTML_ACCESS_TB::compute (char *errmsg);
PUBLIC int HTML_ACCESS_TB::check (unsigned long badr, int printlog);
PUBLIC void HTML_ACCESS_TB::setdefaults (void);
/* ifconfig.c 21/10/96 21.10.44 */
/* internal.c 03/10/95 01.09.14 */
/* ipalias.c 06/10/96 15.51.56 */
PUBLIC IP_ALIAS::IP_ALIAS (int _num, const char *_ip);
PUBLIC IP_ALIAS::IP_ALIAS (const char *_ip);
PUBLIC int IP_ALIAS::unset (const char *devname);
PUBLIC int IP_ALIAS::set (int _num, const char *devname);
PUBLIC IP_ALIAS *IP_ALIASES::getitem (int no);
PUBLIC IP_ALIAS *IP_ALIASES::getitem (const char *ip);
PUBLIC void IP_ALIASES::readproc (const char *devname);
PUBLIC int IP_ALIASES::getmaxnum (void);
PUBLIC int IP_ALIASES::setnew (const char *devip,
	 const char *ips,
	 char *err);
PUBLIC int IP_ALIASES::setup (const char *devname);
/* ipfw.c 06/10/96 15.54.34 */
/* ipfwrule.c 21/10/96 23.14.58 */
PROTECTED IPFW_RULE::IPFW_RULE (void);
PROTECTED IPFW_RULE::IPFW_RULE (const char *&buf);
PUBLIC IPFW_RULE_FORWARD::IPFW_RULE_FORWARD (const char *buf);
PUBLIC IPFW_RULE_FORWARD::IPFW_RULE_FORWARD (void);
PUBLIC IPFW_RULE_OUTPUT::IPFW_RULE_OUTPUT (const char *buf);
PUBLIC IPFW_RULE_OUTPUT::IPFW_RULE_OUTPUT (void);
PUBLIC IPFW_RULE_INPUT::IPFW_RULE_INPUT (const char *buf);
PUBLIC IPFW_RULE_INPUT::IPFW_RULE_INPUT (void);
PROTECTED void IPFW_RULE::savek (char *buf);
PUBLIC void IPFW_RULE_FORWARD::save (void);
PUBLIC void IPFW_RULE_INPUT::save (void);
PUBLIC void IPFW_RULE_OUTPUT::save (void);
PUBLIC void IPFW_RULE::present (char *buf);
PUBLIC int IPFW_RULE::nbbitmask (IPFW_SRC&f);
PUBLIC int IPFW_RULE::nbbitmask_from (void);
PUBLIC int IPFW_RULE::nbbitmask_to (void);
PUBLIC int IPFW_RULE::editk (DIALOG&dia, const char *title);
PUBLIC int IPFW_RULE_FORWARD::edit (void);
PUBLIC int IPFW_RULE_OUTPUT::edit (void);
PUBLIC int IPFW_RULE_INPUT::edit (void);
PUBLIC int IPFW_RULE::setup (IPFW_SRC&f,
	 IPFW_SRC&t,
	 const char *type,
	 int doit,
	 SSTRING *collect,
	 SSTRING&errmsg);
PUBLIC int IPFW_RULE_FORWARD::setup_left (int doit,
	 SSTRING *collect,
	 SSTRING&errmsg);
PUBLIC int IPFW_RULE_FORWARD::setup_right (int doit,
	 SSTRING *collect,
	 SSTRING&errmsg);
PUBLIC int IPFW_RULE_OUTPUT::setup_left (int doit,
	 SSTRING *collect,
	 SSTRING&errmsg);
PUBLIC int IPFW_RULE_OUTPUT::setup_right (int doit,
	 SSTRING *collect,
	 SSTRING&errmsg);
PUBLIC int IPFW_RULE_INPUT::setup_left (int doit,
	 SSTRING *collect,
	 SSTRING&errmsg);
PUBLIC int IPFW_RULE_INPUT::setup_right (int doit,
	 SSTRING *collect,
	 SSTRING&errmsg);
/* ipx.c 22/09/96 22.38.56 */
PUBLIC IPX_INFO::IPX_INFO (void);
PRIVATE void IPX_INFO::probe_auto (void);
PUBLIC IPX_INFO::IPX_INFO (CONFIG_FILE&f);
PUBLIC int IPX_INFO::save (void);
PUBLIC int IPX_INFO::edit (void);
PUBLIC int IPX_INFO::set (void);
/* level.c 14/08/96 16.22.06 */
/* net.c 23/10/96 11.20.36 */
/* netconf.c 30/10/96 22.22.46 */
/* networks.c 30/10/96 00.23.28 */
PUBLIC NETWORK::NETWORK (const char *buf);
PUBLIC NETWORK::NETWORK (const char *_ip_num,
	 const char *_name1,
	 const char *_others,
	 const char *_comment);
PUBLIC NETWORK::NETWORK (void);
PUBLIC void NETWORK::print (FILE *fout)const;
PUBLIC int NETWORK::is_special (void)const;
PUBLIC NETWORKS::NETWORKS (void);
PUBLIC VIRTUAL HOST *NETWORKS::newhost (const char *_ip_num,
	 const char *_name1,
	 const char *_others,
	 const char *_comment);
PUBLIC VIRTUAL HOST *NETWORKS::newhost (const char *buf);
/* nis.c 30/09/96 10.36.30 */
PUBLIC NIS_CONF::NIS_CONF (void);
PUBLIC int NIS_CONF::valid_server (void);
PUBLIC int NIS_CONF::configok (void);
PUBLIC const char *NIS_CONF::getserver (void);
PUBLIC const char *NIS_CONF::getdomain (void);
PUBLIC void NIS_CONF::write (void);
PUBLIC int NIS_CONF::edit (void);
/* ppp.c 23/10/96 00.38.36 */
PRIVATE int PPPONE::lcpecho_parse (int &delay, int &retry);
PRIVATE int PPPONE::lcpecho_valid (void);
PRIVATE int PPPONE::validate_edit (SSTRING&baudstr,
	 SSTRING&oldname,
	 CONFDB&cfg);
PRIVATE void PPPONE::setdia_iproute (DIALOG&dia, int no);
PUBLIC int PPPONE::edit (CONFDB&cfg);
/* pppcon.c 23/10/96 13.59.16 */
PRIVATE void PPPONE::setipparam (char *str);
PRIVATE int PPPONE::connect_ppp (int fore);
PRIVATE int PPPONE::connect_pppssh (int);
PUBLIC int PPPONE::getpppd_pid (void);
PRIVATE int PPPONE::disconnect_ppp (void);
PRIVATE int PPPONE::connect_plip (void);
PRIVATE int PPPONE::disconnect_plip (void);
PRIVATE int PPPONE::connect_slip (int);
PRIVATE int PPPONE::disconnect_slip (void);
PUBLIC int PPPONE::connect (int fore);
PUBLIC int PPPONE::disconnect (void);
PUBLIC int PPPONE::postconnect (const char *dev);
PUBLIC int PPPONE::predisconnect (const char *);
/* pppdial.c 23/10/96 00.42.56 */
PRIVATE void PPPONE::setuptbdb (void);
PUBLIC PPPONE::PPPONE (CONFDB&cfg, const char *_name);
PUBLIC int PPPONE::save (CONFDB&cfg);
PROTECTED void PPPONE::del (CONFDB&cfg, const char *_name);
/* pppmisc.c 23/10/96 00.19.14 */
PUBLIC PPPIPROUTE::PPPIPROUTE (void);
PUBLIC PPPIPROUTE::PPPIPROUTE (const char *s);
PUBLIC PPPIPROUTE *PPPIPROUTES::getitem (int no);
PUBLIC int PPPIPROUTES::empty (void);
/* process.c 29/10/96 12.43.16 */
PUBLIC PROC::PROC (int _pid, PROC *_next);
PUBLIC PROC::~PROC (void);
PUBLIC PROC *PROC::getnext (void);
PUBLIC int PROC::isok (void);
PUBLIC const char *PROC::getpath (void);
PUBLIC const char *PROC::getname (void);
PUBLIC int PROC::kill (int signo);
PUBLIC int PROC::getpid (void);
PUBLIC int PROC::getppid (void);
PUBLIC long PROC::getstarttime (void);
/* rarp.c 06/10/96 15.55.04 */
PUBLIC RARP_ENTRY::RARP_ENTRY (const char *str, int noline);
PUBLIC RARP_ENTRY::RARP_ENTRY (const char *_ip,
	 const char *_hw,
	 int _active,
	 const char *_comment);
PUBLIC RARP_ENTRY::RARP_ENTRY (void);
PUBLIC int RARP_ENTRY::set (void);
PUBLIC int RARP_ENTRY::cmp (const char *ipstr);
PUBLIC int RARP_ENTRY::unset (void);
PUBLIC RARP_ENTRY *RARP_ENTRIES::getitem (int no);
PUBLIC RARP_ENTRY *RARP_ENTRIES::locate (const char *ipstr);
PUBLIC RARP_ENTRIES::RARP_ENTRIES (void);
PUBLIC int RARP_ENTRIES::write (void);
PUBLIC RARP_ENTRIES::RARP_ENTRIES (CONFIG_FILE&f);
PUBLIC void RARP_ENTRIES::update (RARP_ENTRIES&current);
PRIVATE int RARP_ENTRY::normalise (void);
PUBLIC int RARP_ENTRY::is_valid (int talk);
PUBLIC int RARP_ENTRY::edit (void);
PUBLIC int RARP_ENTRIES::edit (void);
PUBLIC int RARP_ENTRIES::isoneactive (void);
/* routed.c 30/09/96 10.39.40 */
PUBLIC ROUTED::ROUTED (void);
PUBLIC void ROUTED::save (void);
PUBLIC int ROUTED::is_required (void);
PUBLIC void ROUTED::setoptions (char *buf);
PUBLIC int ROUTED::edit (void);
/* routes.c 06/10/96 15.51.28 */
PUBLIC ROUTE::ROUTE (const char *dst,
	 const char *gate,
	 const char *mask,
	 const char *_flags,
	 const char *_iface);
PUBLIC ROUTE::ROUTE (const char *buf, int noline);
PUBLIC ROUTE::ROUTE (void);
PUBLIC ROUTE::~ROUTE (void);
PUBLIC void ROUTE::write (FILE *fout);
PUBLIC int ROUTE::gettag (void);
PUBLIC void ROUTE::settag (int _tag);
PUBLIC int ROUTE::isdevice (void);
PUBLIC const char *ROUTE::getiface (void);
PUBLIC const char *ROUTE::getgateway (void);
PUBLIC const char *ROUTE::getdst (void);
PUBLIC int ROUTE::dst_is_host (void);
PUBLIC int ROUTE::match (const SSTRING&dst);
PUBLIC int ROUTE::compare (const SSTRING&dst,
	 const SSTRING&gateway,
	 const SSTRING&o_netmask,
	 const SSTRING&o_flags);
PUBLIC int ROUTE::kill (void);
PUBLIC int ROUTE::is_loopback (void);
PUBLIC int ROUTE::is_default (void);
PUBLIC int ROUTES::readactive (void);
PUBLIC void ROUTES::write (FILE *fout);
PUBLIC ROUTE *ROUTES::getitem (int no)const;
PUBLIC ROUTE *ROUTES::find (const SSTRING&ip_dst);
PUBLIC void ROUTES::readbyme (void);
PUBLIC void ROUTES::writebyme (void);
/* routes1.c 14/08/96 16.23.54 */
PUBLIC int ROUTE::edit (int edit_host_route);
/* simple.c 14/08/96 16.24.02 */
/* simul.c 07/10/96 08.28.44 */
/* start.c 10/10/96 16.14.50 */
/* thishost.c 06/10/96 15.51.42 */
PUBLIC THISHOST::THISHOST (void);
PUBLIC THISHOST::~THISHOST (void);
PUBLIC void THISHOST::setname1 (const char *newname1);
PUBLIC const char *THISHOST::getipnum (int);
PUBLIC const char *THISHOST::getname1 (void);
PUBLIC int THISHOST::configok (void);
/* thishost1.c 04/10/96 10.35.02 */
