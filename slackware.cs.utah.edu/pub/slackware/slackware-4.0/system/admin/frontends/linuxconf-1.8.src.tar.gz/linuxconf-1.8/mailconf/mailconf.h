#pragma interface
#ifndef MAILCONF_H
#define MAILCONF_H

class FIELD_COMBO;
class USER;

#include "mailconf.p"

#endif

