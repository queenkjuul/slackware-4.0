//#include "messages.m"

int main (int , char *[])
{
	printf (MSG_U(MSG1,"hello\n"));
	return 0;
}


