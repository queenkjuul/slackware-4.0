#include <misc.h>
#include "xconf.h"
#include "components.h"

/*
	Print a notice to the user.
*/
void xconf_notice (const NOTICE *notice)
{
	if (notice != NULL){
		char buf[2000];
		if (notice->format (buf,2000-1) != -1){
			xconf_notice ("%s",buf);
		}
	}
}
