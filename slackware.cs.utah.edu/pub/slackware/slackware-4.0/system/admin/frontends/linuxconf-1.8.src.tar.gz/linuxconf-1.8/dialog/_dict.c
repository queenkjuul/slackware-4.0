#include "dialog.m"
#include <translat.h>
DICTIONARY_REQUEST;


