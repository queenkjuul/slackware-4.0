#pragma implementation
#include "misc.h"

