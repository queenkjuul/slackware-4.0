#pragma interface
#ifndef TRANSLATE_H
#define TRANSLATE_H


class TRANSLATE_SYSTEM_REQ{
public:
	const char *sysname;
	const char **&global_var;
	int nb_expected;
	int version;
	TRANSLATE_SYSTEM_REQ *next;
	/*~PROTOBEG~ TRANSLATE_SYSTEM_REQ */
public:
	TRANSLATE_SYSTEM_REQ (const char *_sysname,
		 const char **&_global_var,
		 int _nb_expected,
		 int _version);
	/*~PROTOEND~ TRANSLATE_SYSTEM_REQ */
};

class TRANS_NOTLOAD{
	const char **&table;
	int nomsg;
	/*~PROTOBEG~ TRANS_NOTLOAD */
public:
	TRANS_NOTLOAD (const char **&_table,
		 int _nomsg);
	const char *get (void);
	/*~PROTOEND~ TRANS_NOTLOAD */
};


void translat_load (const char *basepath, const char *basename);
void translat_load (const char *basepath, const char*, const char *basename, const char *);
int translat_load (const char *basepath, const char *basename, char *errmsg);
class TRANS_NOTLOAD;
TRANS_NOTLOAD *new_trans_notload (const char **&table, int nomsg);

#endif

