extern const char **_dictionary_dialog;
#ifndef DICTIONARY_REQUEST
	#define DICTIONARY_REQUEST \
	const char **_dictionary_dialog;\
	TRANSLATE_SYSTEM_REQ _dictionary_req_dialog("dialog",_dictionary_dialog,32,1);\
	void dummy_dict_dialog(){}
#endif
#ifndef MSG_U
	#define MSG_U(id,m)	_dictionary_dialog[id]
	#define MSG_B(id,m,n)	_dictionary_dialog[id]
	#define MSG_R(id)	_dictionary_dialog[id]
	#define P_MSG_U(id,m)	new_trans_notload(_dictionary_dialog,id)
	#define P_MSG_B(id,m,n)	new_trans_notload(_dictionary_dialog,id)
	#define P_MSG_R(id)	new_trans_notload(_dictionary_dialog,id)
#endif
#define B_YES	0
#define B_NO	1
#define B_OK	2
#define B_ACCEPT	3
#define B_CANCEL	4
#define B_QUIT	5
#define B_SAVE	6
#define B_ADD	7
#define B_DEL	8
#define B_INS	9
#define B_EDIT	10
#define B_RESET	11
#define I_SELECT	12
#define I_SAVE	13
#define I_ADD	14
#define I_INS	15
#define I_DEL	16
#define B_HELP	17
#define E_MISMATCH	18
#define B_MORE	19
#define B_USR1	20
#define B_USR2	21
#define B_USR3	22
#define E_INLIST	23
#define E_NOEMPTY	24
#define E_NOHELPFILE	25
#define E_NOPT	26
#define E_NONDIGIT	27
#define E_NOTTY	28
#define E_IVLDHTMLREQ	29
#define L_FREQUEST	30
#define L_REQUEST	31
