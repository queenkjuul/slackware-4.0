#pragma interface
#ifndef INTERNAL_H
#define INTERNAL_H

#define MSDOS_OPT_UNUSE	(-1)
#define NFS_OPT_UNUSE	(-1)

#endif