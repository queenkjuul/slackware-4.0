/* _dict.c 14/08/96 15.08.30 */
/* dns.c 14/08/96 15.08.36 */
PRIVATE void DNS::parse (const char *buf,
	 const char *fpath,
	 int noline);
PUBLIC void DNS::setlocalhost (void);
PUBLIC DNS::DNS (void);
PUBLIC int DNS::empty (void);
PUBLIC void DNS::basiccheck (void);
PUBLIC int DNS::write (void);
PUBLIC int DNS::set (const char *fqhost,
	 const char *tbip[],
	 int nbip);
PUBLIC int DNS::setns (const SSTRING&fqhost, const SSTRINGS&tbns);
PUBLIC int DNS::setmx (const SSTRING&fqhost, const SSTRINGS&tbmx);
PUBLIC void DNS::unset (const char *fqhost);
PUBLIC void DNS::unsetns (const SSTRING&fqhost);
PUBLIC void DNS::unsetmx (const SSTRING&fqhost);
PUBLIC void DNS::setcname (const SSTRING&fqhost,
	 const SSTRING&cname);
/* dnscheck.c 16/09/95 13.32.38 */
PUBLIC void DNS::check (void);
/* dnsconf.c 08/10/96 20.39.28 */
PUBLIC void DNS::editforwarders (void);
PUBLIC int DNS::edit (void);
PUBLIC int DNS::was_modified (void);
/* dnsmxs.c 14/08/96 15.09.00 */
PUBLIC void DNS::editmxs (void);
/* dnsping.c 04/10/96 09.24.26 */
/* dnsrecs.c 07/10/96 23.24.54 */
PUBLIC void DNS::editone (const char *name);
PUBLIC void DNS::editrecs (const char *preset);
/* fqhost.c 12/04/96 12.00.42 */
PRIVATE void FQHOST::init (const char *host);
PUBLIC FQHOST::FQHOST (const char *host);
PUBLIC FQHOST::FQHOST (const SSTRING&host);
PUBLIC FQHOST::FQHOST (const char *host, const char *domain);
PUBLIC int FQHOST::is_member (const char *domain, char *hostpart);
PUBLIC const char *FQHOST::gethostpart (const char *domain);
PUBLIC void FQHOST::formatfull (char *full);
PUBLIC void FQHOST::formatfull (SSTRING&full);
/* helpf.c 14/08/96 15.09.36 */
PUBLIC DNSCONF_HELP_FILE::DNSCONF_HELP_FILE (const char *fname);
/* internal.c 27/08/95 21.36.10 */
/* ipmap.c 28/08/96 11.57.46 */
PUBLIC IPMAP::IPMAP (const char *line);
PUBLIC IPMAP::IPMAP (void);
PUBLIC int IPMAP::setup (void);
PUBLIC void IPMAP::setuse (const IP_ADDR *adr);
PUBLIC IPMAP *IPMAPS::getitem (int no);
PUBLIC IPMAPS::IPMAPS (void);
PUBLIC int IPMAPS::write (void);
PUBLIC void IPMAPS::setuse (IP_ADDRS&adrs);
PUBLIC void IPMAPS::setcombo (class FIELD_COMBO *comb);
PRIVATE void IPMAPS::newdiaf (DIALOG&dia, IPMAP *e);
PUBLIC int IPMAPS::edit (void);
/* misc.c 30/06/96 18.23.14 */
PUBLIC CACHEFILE::CACHEFILE (const char *_domain, const char *_path);
PUBLIC CACHEFILE *CACHEFILES::getitem (int no);
PUBLIC IP_ADDR::IP_ADDR (void);
PUBLIC IP_ADDR::IP_ADDR (const SSTRING&str);
PUBLIC IP_ADDR::IP_ADDR (const IP_ADDR&adr);
PUBLIC void IP_ADDR::setfrom (const char *pt);
PUBLIC int IP_ADDR::is_valid (void);
PUBLIC void IP_ADDR::reformat (void);
PUBLIC void IP_ADDR::setrev (char *str);
PUBLIC void IP_ADDR::reverse (void);
PUBLIC int IP_ADDR::cmp (const IP_ADDR *p);
PUBLIC void IP_ADDR::shift (void);
PUBLIC void IP_ADDR::shift_right (void);
PUBLIC void IP_ADDR::increm (void);
PUBLIC void IP_ADDR::merge (IP_ADDR&partial);
PUBLIC IP_ADDR *IP_ADDRS::getitem (int no)const;
PUBLIC void IP_ADDRS::sort (void);
/* origin.c 25/09/96 12.00.20 */
PUBLIC ORIGIN::ORIGIN (const char *_origin);
PUBLIC void ORIGIN::print (bool save_ori, TBFILE&tbf)const;
PUBLIC int ORIGIN::getalladr (IP_ADDRS&adrs);
PUBLIC int ORIGIN::was_modified (void);
PRIVATE int ORIGINS::parsespecial (const char *key,
	 const char *pt,
	 TBFILE&tbf,
	 ORIGIN *&ori);
PRIVATE int ORIGINS::parseend (char *pt,
	 RECORD_PARSE&p,
	 ORIGIN *ori);
PUBLIC ORIGIN *ORIGINS::getitem (int no)const;
PUBLIC int ORIGINS::read (const char *named_dir,
	 const char *fname,
	 const char *first_origin);
PUBLIC int ORIGINS::save (const char *named_dir,
	 const char *fname)const;
/* primary.c 08/10/96 20.40.14 */
PUBLIC PRIMARY::PRIMARY (const char *_domain,
	 const char *_file,
	 const char *named_dir);
PUBLIC PRIMARY::PRIMARY (void);
PUBLIC VIRTUAL void PRIMARY::setfromv (void);
PUBLIC PRIMARY_REV::PRIMARY_REV (const char *_domain,
	 const char *_file,
	 const char *named_dir);
PUBLIC PRIMARY_REV::PRIMARY_REV (void);
PUBLIC void PRIMARY_REV::setfromv (void);
PUBLIC int PRIMARY::was_modified (void);
PUBLIC VIRTUAL int PRIMARY::is_reverse (void);
PUBLIC int PRIMARY_REV::is_reverse (void);
PUBLIC int PRIMARY::getalladr (IP_ADDRS&adrs);
PRIVATE RECORD *PRIMARY::getfirst (RECORD_TYPE rtype);
PROTECTED RECORD_IN_SOA *PRIMARY::getsoa (void);
PUBLIC int PRIMARY::getns (SSTRING&dom, RECORDS&recs);
PUBLIC int PRIMARY::getns (SSTRING&dom, SSTRINGS&strs);
PUBLIC int PRIMARY::getmx (SSTRING&dom, RECORDS&recs);
PUBLIC int PRIMARY::getmx (SSTRING&dom, SSTRINGS&strs);
PUBLIC int PRIMARY::geta (SSTRING&dom, RECORDS&recs);
PUBLIC int PRIMARY::geta (SSTRING&dom, IP_ADDRS&adrs);
PUBLIC int PRIMARY::getcname (SSTRING&dom, SSTRING&cname);
PUBLIC void PRIMARY::updatesoa (void);
PUBLIC int PRIMARY::write (FILE *fout, const char *named_dir)const;
PUBLIC void PRIMARY::addrec (RECORD *rec);
PUBLIC int PRIMARY::edit (DNS&dns);
PUBLIC PRIMARY *PRIMARYS::getitem (int no)const;
PUBLIC int PRIMARYS::getalladr (IP_ADDRS&adrs);
PUBLIC PRIMARY *PRIMARYS::getitem (FQHOST&fq,
	 char *hostpart,
	 int dontitself);
PUBLIC PRIMARY *PRIMARYS::getitem (FQHOST&fq, char *hostpart);
PUBLIC int PRIMARYS::write (FILE *fout, const char *named_dir)const;
PUBLIC VIRTUAL PRIMARY *PRIMARYS::new_PRIMARY (void);
PUBLIC PRIMARY *PRIMARYS_REV::new_PRIMARY (void);
PUBLIC void PRIMARYS::edit (DNS&dns);
/* primbydom.c 08/10/96 20.59.40 */
PUBLIC void PRIMARY::edithosts (DNS&dns);
PRIVATE void PRIMARYS::setselect (DIALOG&dia);
PUBLIC void PRIMARYS::editbydom (DNS&dns);
/* primquery.c 15/10/95 01.07.26 */
PUBLIC int PRIMARY::set (FQHOST&fq, RECORD *new_rec);
PUBLIC int PRIMARY::unset (RECORD *new_rec);
PUBLIC int PRIMARY::locate_left (FQHOST&fq,
	 RECORD_TYPE rtype,
	 RECORDS&recs);
/* record.c 15/08/96 15.27.06 */
PUBLIC RECORD::RECORD (RECORD_TYPE _id);
PUBLIC bool RECORD::is (RECORD_TYPE _id);
PUBLIC VIRTUAL void RECORD::sethostpart (const char *);
PROTECTED VIRTUAL int RECORD::cmpsame (const RECORD *);
PUBLIC VIRTUAL int RECORD::set (const RECORD *);
PUBLIC int RECORD::cmp (RECORD *other);
PUBLIC VIRTUAL int RECORD::cmp_left (const char *);
PUBLIC RECORD_IN::RECORD_IN (const RECORD_PARSE&p, RECORD_TYPE _id);
PUBLIC RECORD_IN::RECORD_IN (RECORD_TYPE _id);
PUBLIC void RECORD::setcomment (const char *str);
PUBLIC RECORD_COMMENT::RECORD_COMMENT (const char *str);
PUBLIC void RECORD_COMMENT::print (FILE *fout)const;
PUBLIC RECORD_IN_A::RECORD_IN_A (const RECORD_PARSE&p);
PUBLIC RECORD_IN_A::RECORD_IN_A (const char *_name, const char *_addr);
PUBLIC void RECORD_IN_A::sethostpart (const char *hostpart);
PROTECTED int RECORD_IN_A::cmpsame (const RECORD *other);
PROTECTED int RECORD_IN_A::cmp_left (const char *str);
PUBLIC int RECORD_IN_A::set (const RECORD *other);
PUBLIC int RECORD_IN_A::cmphost (const char *host);
PUBLIC void RECORD_IN_A::setip (const char *ip);
PUBLIC void RECORD_IN_A::print (FILE *fout)const;
PUBLIC RECORD_IN_PTR::RECORD_IN_PTR (const RECORD_PARSE&p);
PUBLIC RECORD_IN_PTR::RECORD_IN_PTR (const char *iprev,
	 const char *host);
PROTECTED int RECORD_IN_PTR::cmpsame (const RECORD *other);
PROTECTED int RECORD_IN_PTR::cmp_left (const char *str);
PUBLIC int RECORD_IN_PTR::set (const RECORD *other);
PUBLIC void RECORD_IN_PTR::sethostpart (const char *hostpart);
PUBLIC void RECORD_IN_PTR::print (FILE *fout)const;
PUBLIC int RECORD_IN_PTR::cmpip (const char *ip);
PUBLIC RECORD_IN_NS::RECORD_IN_NS (const RECORD_PARSE&p);
PUBLIC RECORD_IN_NS::RECORD_IN_NS (const char *_name, const char *_ns);
PUBLIC RECORD_IN_NS::RECORD_IN_NS (void);
PROTECTED int RECORD_IN_NS::cmpsame (const RECORD *other);
PUBLIC int RECORD_IN_NS::set (const RECORD *other);
PUBLIC void RECORD_IN_NS::sethostpart (const char *hostpart);
PUBLIC int RECORD_IN_NS::cmp_left (const char *str);
PUBLIC void RECORD_IN_NS::print (FILE *fout)const;
PUBLIC RECORD_IN_CNAME::RECORD_IN_CNAME (const RECORD_PARSE&p);
PUBLIC RECORD_IN_CNAME::RECORD_IN_CNAME (const char *cname,
	 const char *realname);
PUBLIC int RECORD_IN_CNAME::cmp_left (const char *str);
PUBLIC void RECORD_IN_CNAME::sethostpart (const char *hostpart);
PROTECTED int RECORD_IN_CNAME::cmpsame (const RECORD *other);
PUBLIC void RECORD_IN_CNAME::print (FILE *fout)const;
PUBLIC RECORD_IN_MX::RECORD_IN_MX (const RECORD_PARSE&p);
PUBLIC RECORD_IN_MX::RECORD_IN_MX (const char *_mailname,
	 int priority,
	 const char *_servname);
PROTECTED int RECORD_IN_MX::cmpsame (const RECORD *other);
PUBLIC int RECORD_IN_MX::set (const RECORD *other);
PUBLIC int RECORD_IN_MX::cmp_left (const char *str);
PUBLIC void RECORD_IN_MX::print (FILE *fout)const;
PUBLIC void RECORD_IN_MX::sethostpart (const char *hostpart);
PUBLIC RECORD_PARSE::RECORD_PARSE (void);
PUBLIC RECORD_INCLUDE::RECORD_INCLUDE (const char *_path);
PUBLIC void RECORD_INCLUDE::print (FILE *fout)const;
PUBLIC RECORD_END_INCLUDE::RECORD_END_INCLUDE (void);
PUBLIC void RECORD_END_INCLUDE::print (FILE *)const;
PUBLIC RECORD *RECORDS::getitem (int no)const;
PUBLIC int RECORDS::save (TBFILE&tbf)const;
/* resolv.c 30/09/96 10.41.14 */
PRIVATE void RESOLV::parse (const char *pt);
PUBLIC RESOLV::RESOLV (void);
PUBLIC int RESOLV::write (void);
/* secondary.c 26/09/96 13.38.36 */
PUBLIC SECONDARY::SECONDARY (const char *_domain,
	 const char *_backup,
	 const char **_ip_addr,
	 int nb_ip);
PUBLIC SECONDARY::SECONDARY (void);
PUBLIC void SECONDARY::write (FILE *fout, const char *named_dir)const;
PUBLIC int SECONDARY::edit (void);
PUBLIC SECONDARY *SECONDARYS::getitem (int no)const;
PUBLIC void SECONDARYS::write (FILE *fout,
	 const char *named_dir)const;
PUBLIC void SECONDARYS::edit (DNS&dns);
/* soa.c 14/08/96 15.11.00 */
PUBLIC RECORD_IN_SOA::RECORD_IN_SOA (const RECORD_PARSE&p);
PUBLIC RECORD_IN_SOA::RECORD_IN_SOA (void);
PUBLIC void RECORD_IN_SOA::print (FILE *fout)const;
PUBLIC void RECORD_IN_SOA::update (const char *name);
/* tbfile.c 08/09/95 23.54.42 */
PUBLIC TBFILE::TBFILE (const char *_defpath);
PUBLIC TBFILE::~TBFILE (void);
PUBLIC FILE *TBFILE::fopen (const char *fname, const char *mode);
PUBLIC void TBFILE::fclose (void);
/* timestr.c 14/08/96 15.11.10 */
PRIVATE void TIMESTR::formatstr (void);
PUBLIC void TIMESTR::setfrom (const char *_str);
PUBLIC void TIMESTR::setfrom (long _seconds);
PUBLIC TIMESTR::TIMESTR (long _seconds);
PUBLIC TIMESTR::TIMESTR (void);
