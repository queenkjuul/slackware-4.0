#include "netconf.m"
#include <translat.h>
DICTIONARY_REQUEST;

