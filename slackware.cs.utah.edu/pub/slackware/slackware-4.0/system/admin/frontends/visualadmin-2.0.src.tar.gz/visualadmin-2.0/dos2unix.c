/*              Mauro Javier De Gennaro <mauro@minter.com.ar>           */

/* dos2unix.c <2.0> - Converts DOS text files to Unix text files */

#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include "visualadmin.h"

void dos2unix(FILE *filep, char *data);

void dos2unix(FILE *filep, char *data) {
int i=0;

/* Remove \r from posts and fix buggy posts without \n */

for(i=0;i<=strlen(data);i++) {
	if(data[i]=='\r') {
		if(data[i+1]!='\n')
			fprintf(filep, "\n");
	} else
		fprintf(filep,"%c",data[i]);
}

}