/*            Mauro Javier De Gennaro <mauro@minter.com.ar>               */

/* cgi_lookup.c <2.0> - Reads data from a CGI input */

int get_var(const char *source, char *dest, const char *var);
int decode_hex (const char *hex, char *des);

#define NULL '\0'
		
int get_var(const char *source, char *dest, const char *var)
{
int c;
char h,i;
int size;
char *p_copy;

p_copy=strstr(source, var);

if (p_copy)
        ;
else 
        {
        return(-1);
        }

size = strlen (var);


i=0;
c=0;
while (i != '&')
{
        i = *(p_copy+size+c);

        switch(i)
                {
                case '+':
                *(dest+c) = ' ';
                c++;
                break;

                case '&':
                break;
        
                case '%':
                if (decode_hex((p_copy+size+c), &i))
                        *(dest+c) = i;
                i= '$';
                p_copy += 2;
                c++;
                break;

                default:
                *(dest+c) = i;
                c++;
                break;
                }
}
*(dest+c) = '\0';
return (c);
}

int decode_hex (const char *hex, char *des)
{
char string[3];
int i;
long l;
if ((sscanf(hex, "%%%2s", &string))==0)
        return(0);
l=strtol(string, NULL, 16);
i = (int) l;
*des = (char) i;
return(1);
}
