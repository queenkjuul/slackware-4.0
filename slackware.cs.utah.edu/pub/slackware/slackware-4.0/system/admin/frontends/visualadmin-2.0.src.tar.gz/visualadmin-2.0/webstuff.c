#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "visualadmin.h"

extern user_tb *userlist;
extern named_tb *namedlist;
extern file_tb *filelist;
extern int nusers;
extern int ndns;

void view_dnsedit(int c);
void view_dnslist();
void critical(char *msg);
void view_fedit(int m);
void view_menu();
void view_useredit(int c);
void view_userlist();
void view_welcome();
void view_search();

void view_dnsedit(int c) {
char buf[1024], name[50], forward[60], file[50]; 
int i;
FILE *dns_fp;
if(c) {
	switch(namedlist[c].buf[0]) {
		case 'p':
		case 'P':
			i=0;
			getNamedInfo(namedlist[c].buf, name, file, forward, 0);
			break;
		case 'S':
		case 's':
			i=1;
			getNamedInfo(namedlist[c].buf, name, file, forward, 1);
			break;
	}
	strcat(dnsdir, file);
}
printf("Content-type: text/html\n\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>DNS Editor</title>\n");
printf("</head>\n");
printf("<body bgcolor=\"#FFFFFF\">\n");
printf("<form action=\"/cgi-bin/visualadmin\" method=\"POST\">\n");
printf("    <input type=\"hidden\" name=\"locator\" value=\"dnsedit\"><input\n");
printf("    type=\"hidden\" name=\"pass\" value=\"%s\"><input type=\"hidden\"\n", pass);
printf("    name=\"user\" value=\"%s\"><input type=\"hidden\" name=\"num\" value=\"%d\"><table border=\"0\">\n", user, c);
printf("        <tr>\n");
printf("            <td bgcolor=\"#DDCEA8\"><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td bgcolor=\"#B19445\"><font size=\"2\"\n");
printf("                    face=\"Arial\"><strong>Zone Name</strong></font></td>\n");
printf("                    <td bgcolor=\"#B19445\"><font size=\"2\"\n");
printf("                    face=\"Arial\"><strong>Type</strong></font></td>\n");
printf("                    <td bgcolor=\"#B19445\"><font size=\"2\"\n");
printf("                    face=\"Arial\"><strong>Primary Server</strong></font></td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td><input type=\"text\" size=\"20\"\n");
printf("                    maxlength=\"50\" name=\"zonename\"");
if(c) printf(" value=\"%s\"", name);
printf("></td>\n");
printf("                    <td><select name=\"type\" size=\"1\">\n");
printf("                        <option ");
if(!c || !i) printf("selected ");
printf("value=\"primary\">Primary</option>\n");
printf("                        <option ");
if(i) printf("selected ");
printf("value=\"secondary\">Secondary</option>\n");
printf("                    </select></td>\n");
printf("                    <td><input type=\"text\" size=\"20\"\n");
printf("                    maxlength=\"20\" name=\"primary\"");
if(c&&i) printf(" value=\"%s\"", forward);
printf("></td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td bgcolor=\"#B19445\"><font size=\"2\"\n");
printf("                    face=\"Arial\"><strong>Zone File Name</strong></font></td>\n");
printf("                    <td>&nbsp;</td>\n");
printf("                    <td>&nbsp;</td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td><input type=\"text\" size=\"20\"\n");
printf("                    maxlength=\"50\" name=\"filename\"");
if(c) printf(" value=\"%s\"", file);
printf("></td>\n");
printf("                    <td>&nbsp;</td>\n");
printf("                    <td>&nbsp;</td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("        <tr>\n");
printf("            <td bgcolor=\"#DDCEA8\"><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td bgcolor=\"#B19445\"><font size=\"2\"\n");
printf("                    face=\"Arial\"><strong>Zone File</strong></font></td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td><textarea name=\"file\" rows=\"10\" cols=\"80\">");
if(c) {
	dns_fp=fopen(dnsdir, "r");
	if(dns_fp) while(fgets(buf,sizeof(buf),dns_fp)) printf("%s",buf);
}
printf("</textarea></td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("        <tr>\n");
printf("            <td bgcolor=\"#DDCEA8\"><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td><input type=\"submit\" name=\"ok\"\n");
printf("                    value=\"Save Changes\"></td>\n");
printf("                    <td><input type=\"submit\" name=\"cancel\"\n");
printf("                    value=\"Cancel\"></td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("    </table>\n");
printf("</form>\n");
printf("</body>\n");
printf("</html>\n");
exit(0);
}

void view_dnslist() {
char name[50];
int i=0,c=0;
printf("Content-type: text/html\n\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>DNS Zone List</title>\n");
printf("</head>\n");
printf("<body bgcolor=\"#FFFFFF\">\n");
printf("<form action=\"/cgi-bin/visualadmin\" method=\"POST\">\n");
printf("    <input type=\"hidden\" name=\"locator\" value=\"dnslist\"><input\n");
printf("    type=\"hidden\" name=\"pass\" value=\"%s\"><input type=\"hidden\"\n", pass);
printf("    name=\"user\" value=\"%s\"><table border=\"0\">\n", user);
printf("    <table border=\"0\">\n");
printf("        <tr>\n");
printf("            <td bgcolor=\"#BCA55F\"><font size=\"2\" face=\"Arial\"><strong>Check</strong></font></td>\n");
printf("            <td width=\"300\" bgcolor=\"#BCA55F\"><font size=\"2\"\n");
printf("            face=\"Arial\"><strong>DNS Zone</strong></font></td>\n");
printf("        </tr>\n");
for(i=1;i<=ndns;i++) {
	if(!namedlist[i].num) continue;
	c++;
	switch (namedlist[i].buf[0]) {
		case 'p':
		case 'P':
			if(namedlist[i].buf[2]=='i' ||
			   namedlist[i].buf[2]=='I')
			   getNamedInfo(namedlist[i].buf, name, NULL, NULL, 0);
			break;
		case 's':
		case 'S':
			if(namedlist[i].buf[2]=='c' ||
			   namedlist[i].buf[2]=='C')
			   getNamedInfo(namedlist[i].buf, name, NULL, NULL, 0);
			break;
		default:
			continue;
			break;
	}
	printf("        <tr>\n");
	printf("            <td bgcolor=\"#DED3B1\"><input type=\"checkbox\"\n");
	printf("            name=\"num\" value=\"%d\"></td>\n", c);
	printf("            <td width=\"300\" bgcolor=\"#DED3B1\"><a\n");
	printf("            href=\"/cgi-bin/visualadmin?locator=dnslist&user=%s&pass=%s&num=%d&moveto=moddns\"><font\n",user,pass,c);
	printf("            size=\"2\">%s</font></a></td>\n",name);
	printf("        </tr>\n");
}
printf("    </table>\n");
printf("    <table border=\"0\">\n");
printf("        <tr>\n");
printf("            <td bgcolor=\"#BCA55F\"><input type=\"submit\"\n");
printf("            name=\"delete\" value=\"Delete Selected\"></td>\n");
printf("            <td bgcolor=\"#BCA55F\"><input type=\"submit\" name=\"ok\"\n");
printf("            value=\"OK\"></td>\n");
printf("        </tr>\n");
printf("    </table>\n");
printf("    <table border=\"0\">\n");
printf("        <tr>\n");
printf("            <td width=\"620\" bgcolor=\"#D0C08E\"><font size=\"2\"\n");
printf("            face=\"Arial\"><strong><u>To Delete a zone</u></strong>:\n");
printf("            Select the target zone(s) checkbox and\n");
printf("            press 'Delete Selected' <br>\n");
printf("            <strong><u>To Modify a zone:</u></strong> Press on\n");
printf("            the DNS Zone name.</font></td>\n");
printf("        </tr>\n");
printf("    </table>\n");
printf("</form>\n");
printf("</body>\n");
printf("</html>\n");
exit(0);
}

void critical(char *msg) {
printf("Content-type: text/html\n\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>Error</title>\n");
printf("</head>\n");
printf("<body bgcolor=\"#FFFFFF\">\n");
printf("<table border=\"0\">\n");
printf("    <tr>\n");
printf("        <td bgcolor=\"#AB9347\"><table border=\"0\">\n");
printf("            <tr>\n");
printf("                <td bgcolor=\"#D0C08E\"><p align=\"center\"><font\n");
printf("                size=\"5\" face=\"Arial\"><strong>ERROR</strong></font></p>\n");
printf("                </td>\n");
printf("            </tr>\n");
printf("            <tr>\n");
printf("                <td bgcolor=\"#D0C08E\"><p align=\"center\">%s</p>\n", msg);
printf("                </td>\n");
printf("            </tr>\n");
printf("            <tr>\n");
printf("                <td bgcolor=\"#D0C08E\"><p align=\"center\"><font\n");
printf("                size=\"2\" face=\"Arial\"><strong>Go back with your\n");
printf("                browser and try to fix the error.</strong></font></p>\n");
printf("                </td>\n");
printf("            </tr>\n");
printf("        </table>\n");
printf("        </td>\n");
printf("    </tr>\n");
printf("</table>\n");
printf("</body>\n");
printf("</html>\n");
exit(0);
}

void view_fedit(int m) {
FILE *fp;
char file[50],buf[1024];
if(m<0||m>20) critical("Incorrect data in POST");
fp=fopen(filelist[m].file,"r");
if(!fp) critical("Error opening file on file editor");
printf("Content-type: text/html\n\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>File Editor - %s</title>\n",filelist[m].file);
printf("</head>\n");
printf("<body bgcolor=\"#FFFFFF\">\n");
printf("<form action=\"/cgi-bin/visualadmin\" method=\"POST\">\n");
printf("    <input type=\"hidden\" name=\"locator\" value=\"fedit\"><input\n");
printf("    type=\"hidden\" name=\"pass\" value=\"%s\"><input type=\"hidden\"\n", pass);
printf("    name=\"user\" value=\"%s\"><input type=\"hidden\" name=\"num\" value=\"%d\"><table border=\"0\">\n", user, m);
printf("        <tr>\n");
printf("            <td bgcolor=\"#DDCEA8\"><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td bgcolor=\"#B19445\"><font size=\"2\"\n");
printf("                    face=\"Arial\"><strong>File Editor - %s</strong></font></td>\n", filelist[m].file);
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td><textarea name=\"file\" rows=\"10\" cols=\"80\">");
while(fgets(buf,sizeof(buf),fp)) printf("%s",buf);
fclose(fp);
printf("</textarea></td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("        <tr>\n");
printf("            <td bgcolor=\"#DDCEA8\"><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td><input type=\"submit\" name=\"ok\"\n");
printf("                    value=\"Save\"></td>\n");
printf("                    <td><input type=\"submit\" name=\"cancel\"\n");
printf("                    value=\"Cancel\"></td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("    </table>\n");
printf("</form>\n");
printf("</body>\n");
printf("</html>\n");
exit(0);
}

void view_menu() {
int c=0;
printf("Content-type: text/html\n\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>Visual Admin 2.0 Main Menu</title>\n");
printf("</head>\n");
printf("<body bgcolor=\"#FFFFFF\" link=\"#000080\" vlink=\"#000080\"\n");
printf("alink=\"#000080\">\n");
printf("<table border=\"0\">\n");
printf("    <tr>\n");
printf("        <td width=\"200\">&nbsp;</td>\n");
printf("        <td width=\"200\" bgcolor=\"#DED3B1\"><table border=\"0\">\n");
printf("            <tr>\n");
printf("                <td width=\"198\" bgcolor=\"#AB9347\"><font size=\"2\"\n");
printf("                face=\"Arial\"><strong>Visual Admin 2.0</strong></font></td>\n");
printf("            </tr>\n");
printf("            <tr>\n");
printf("                <td width=\"198\" bgcolor=\"#D0C08E\"><p\n");
printf("                align=\"center\">A visual way to admin your system <br>\n");
printf("                <br>\n");
printf("                <font size=\"2\">by <a href=\"mailto:mauro@minter.com.ar\">Mauro J. De Gennaro</a></font></p>\n");
printf("                </td>\n");
printf("            </tr>\n");
printf("        </table>\n");
printf("        </td>\n");
printf("        <td width=\"200\">&nbsp;</td>\n");
printf("    </tr>\n");
printf("    <tr>\n");
printf("        <td width=\"200\" bgcolor=\"#DED3B1\"><table border=\"0\">\n");
printf("            <tr>\n");
printf("                <td width=\"198\" bgcolor=\"#AB9347\"><font size=\"2\"\n");
printf("                face=\"Arial\"><strong>User Manager</strong></font></td>\n");
printf("            </tr>\n");
printf("            <tr>\n");
printf("                <td width=\"198\" bgcolor=\"#D0C08E\"><a\n");
printf("                href=\"/cgi-bin/visualadmin?locator=menu&user=%s&pass=%s&moveto=usrlst\">View/Modify/Delete\n", user, pass);
printf("                User(s)</a><br>\n");
printf("                <a\n");
printf("                href=\"/cgi-bin/visualadmin?locator=menu&user=%s&pass=%s&moveto=usradd\">Add\n",user,pass);
printf("                a new  user</a></td>\n");
printf("            </tr>\n");
printf("        </table>\n");
printf("        </td>\n");
printf("        <td width=\"200\">&nbsp;</td>\n");
printf("        <td width=\"200\" bgcolor=\"#DED3B1\"><table border=\"0\">\n");
printf("            <tr>\n");
printf("                <td width=\"198\" bgcolor=\"#AB9347\"><p align=\"left\"><font\n");
printf("                size=\"2\" face=\"Arial\"><strong>DNS Manager</strong></font></p>\n");
printf("                </td>\n");
printf("            </tr>\n");
printf("            <tr>\n");
printf("                <td width=\"198\" bgcolor=\"#D0C08E\"><a\n");
printf("                href=\"/cgi-bin/visualadmin?locator=menu&user=%s&pass=%s&moveto=dnslst\">View/Modify/Delete\n",user,pass);
printf("                Zone(s)</a><br>\n");
printf("                <a\n");
printf("                href=\"/cgi-bin/visualadmin?locator=menu&user=%s&pass=%s&moveto=dnsadd\">Add\n",user,pass);
printf("                a new Zone</a></td>\n");
printf("            </tr>\n");
printf("        </table>\n");
printf("        </td>\n");
printf("    </tr>\n");
printf("    <tr>\n");
printf("        <td width=\"200\">&nbsp;</td>\n");
printf("        <td width=\"200\" bgcolor=\"#DED3B1\"><table border=\"0\">\n");
printf("            <tr>\n");
printf("                <td width=\"198\" bgcolor=\"#AB9347\"><p align=\"left\"><font\n");
printf("                size=\"2\" face=\"Arial\"><strong>System Manager</strong></font></p>\n");
printf("                </td>\n");
printf("            </tr>\n");
printf("            <tr>\n");
printf("                <td width=\"198\" bgcolor=\"#D0C08E\"><p align=\"left\">\n");
while(filelist[c].file[0]!=' '&&c<20) {
	printf("                <a href=\"/cgi-bin/visualadmin?locator=menu&user=%s&pass=%s&moveto=%d\">%s</a><br>\n",user,pass,c,filelist[c].desc);
	c++;
}
printf("</p>\n                </td>\n");
printf("            </tr>\n");
printf("        </table>\n");
printf("        </td>\n");
printf("    </tr>\n");
printf("</table>\n");
printf("</body>\n");
printf("</html>\n");
exit(0);
}

void view_useredit(int c) {
char buf[1024],*s,*e,temp[50],temp2[50];
int aux,i,b;
#ifdef SHADOW_PASSWD
long expire=86400;
struct tm *exptm;
#endif
FILE *shell_fp, *group_fp;
shell_fp=fopen(F_SHELLS, "r");
if(!shell_fp) critical("Error opening shell file");
group_fp=fopen(F_GROUP, "r");
if(!group_fp) critical("Error opening group file");
printf("Content-type: text/html\n\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>User Editor</title>\n");
printf("</head>\n");
printf("<body bgcolor=\"#FFFFFF\">\n");
printf("<form action=\"/cgi-bin/visualadmin\" method=\"POST\">\n");
printf("    <input type=\"hidden\" name=\"locator\" value=\"usermod\"><input\n");
printf("    type=\"hidden\" name=\"pass\" value=\"%s\"><input type=\"hidden\"\n",pass);
printf("    name=\"user\" value=\"%s\"><input type=\"hidden\" name=\"unum\" value=\"%d\">\n",user,c);
printf("    <input type=\"hidden\" name=\"query\" value=\"%s\">\n",query);
printf("    <table border=\"0\">\n");
printf("        <tr>\n");
printf("            <td><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td width=\"300\" bgcolor=\"#AB9347\"><font\n");
printf("                    size=\"2\" face=\"Arial\"><strong>User Info</strong></font></td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td width=\"300\" bgcolor=\"#DED3B1\"><table\n");
printf("                    border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">Login\n");
printf("                            </font></td>\n");
printf("                            <td><input type=\"text\" size=\"20\"\n");
if(c)
	printf("                            maxlength=\"8\" name=\"login\" value=\"%s\"></td>\n",userlist[c].user);
else
	printf("                            maxlength=\"8\" name=\"login\"></td>\n");
printf("                        </tr>\n");
printf("                        <tr>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">Password</font>\n");
printf("                            </td>\n");
printf("                            <td><input type=\"text\" size=\"20\"\n");
printf("                            maxlength=\"18\" name=\"passwd\"></td>\n");
printf("                        </tr>\n");
printf("                        <tr>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">Gecos</font></td>\n");
printf("                            <td><input type=\"text\" size=\"20\"\n");
if(c)
	printf("                            maxlength=\"100\" name=\"gecos\" value=\"%s\"></td>\n",userlist[c].gecos);
else
	printf("                            maxlength=\"100\" name=\"gecos\"></td>\n");
printf("                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("            <td><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td width=\"300\" bgcolor=\"#AB9347\"><font\n");
printf("                    size=\"2\" face=\"Arial\"><strong>System Settings</strong></font></td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td width=\"300\" bgcolor=\"#DED3B1\"><table\n");
printf("                    border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">UID</font></td>\n");
printf("                            <td><input type=\"text\" size=\"4\"\n");
if(c)
	printf("                            maxlength=\"4\" name=\"uid\" value=\"%d\"></td>\n", userlist[c].uid);
else {
	aux=500; 
	while(b) {
		b=0; aux++;
		for(i=1;i<=nusers;i++)
			if(userlist[i].uid==aux) {
				i=nusers+1; b=1;}
	}
	printf("                            maxlength=\"4\" name=\"uid\" value=\"%d\"></td>\n",aux);
}
printf("                        </tr>\n");
printf("                        <tr>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">GID</font></td>\n");
printf("                            <td><select name=\"gid\" size=\"1\">\n");
if(!c) printf("                                <option selected value=\"none\">&lt; Select Group &gt;</option>\n");
b=0;
while(fgets(buf,sizeof(buf),group_fp)) {
	printf("                                <option ");
	s=buf;
	e=index(s,':');
	strncpy(temp,s,e-s);
	temp[e-s]='\0';
	s=e+1;
	e=index(s,':');
	s=e+1;
	e=index(s,':');
	strncpy(temp2,s,e-s);
	temp2[e-s]='\0';
	aux=atoi(temp2);
	if(c&&aux==userlist[c].gid) { b=1; printf("selected "); }
	printf("value=\"%d\">%s</option>\n", aux,temp);
}
if(c&&!b) printf("                                <option selected value=\"%d\">%d</option>\n", userlist[c].gid,userlist[c].gid);
printf("                            </select></td>\n");
printf("                        </tr>\n");
printf("                        <tr>\n");
printf("                            <td><input type=\"checkbox\"\n");
if(c && userlist[c].pass[0]=='*')
	printf("                            name=\"lockpass\" checked value=\"yes\"></td>\n");
else
	printf("                            name=\"lockpass\" value=\"yes\"></td>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">Lock\n");
printf("                            Password</font></td>\n");
printf("                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("        <tr>\n");
printf("            <td><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td width=\"300\" bgcolor=\"#AB9347\"><font\n");
printf("                    size=\"2\" face=\"Arial\"><strong>Other</strong></font></td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td width=\"300\" bgcolor=\"#DED3B1\"><table\n");
printf("                    border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">Home\n");
printf("                            Dir</font></td>\n");
printf("                            <td><input type=\"text\" size=\"20\"\n");
if(c)
	printf("                            maxlength=\"50\" name=\"home\" value=\"%s\"></td>\n", userlist[c].home);
else
	printf("                            maxlength=\"50\" name=\"home\" value=\"%s\" onFocus=\"document.forms[0].home.value='%s/'+document.forms[0].login.value\"></td>\n", D_HOME, D_HOME);
printf("                        </tr>\n");
printf("                        <tr>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">Shell</font></td>\n");
printf("                            <td><select name=\"shell\" size=\"1\">\n");
if(!c) printf("                                <option selected value=\"none\">&lt; Select Shell &gt;</option>\n");
b=0;
while(fgets(buf,sizeof(buf),shell_fp)) {
	buf[strlen(buf)-1]='\0';
	printf("                                <option ");
	if(c&&!strcmp(buf,userlist[c].shell)) { b=1; printf ("selected "); }
	printf("value=\"%s\">%s</option>\n",buf,buf);
}
if (c&&!b) printf("                                <option selected value=\"%s\">%s</option>\n",userlist[c].shell,userlist[c].shell);
printf("                            </select></td>\n");
printf("                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
#ifdef SHADOW_PASSWD
printf("            <td><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td width=\"300\" bgcolor=\"#AB9347\"><font\n");
printf("                    size=\"2\" face=\"Arial\"><strong>Password Aging</strong></font></td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td width=\"350\" bgcolor=\"#DED3B1\"><table\n");
printf("                    border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td width=\"100\"><font size=\"2\" face=\"Arial\">Min Pass Age</font></td>\n");
printf("                            <td><input type=\"text\" size=\"5\" maxlength=\"14\" name=\"mindays\" value=\"");
if(c)
	printf("%s",userlist[c].min);
else
	printf("%d",getdefs("PASS_MIN_DAYS",0) );
printf("\"></td>\n                            <td width=\"100\"><font size=\"2\" face=\"Arial\">Max Pass Age</font></td>\n");
printf("                            <td><input type=\"text\" size=\"5\" maxlength=\"14\" name=\"maxdays\" value=\"");
if(c)
	printf("%s",userlist[c].max);
else
	printf("%d",getdefs("PASS_MAX_DAYS",10000) );
printf("\"></td>\n                        </tr>\n");
printf("                        <tr>\n");
printf("                            <td width=\"100\"><font size=\"2\" face=\"Arial\">Exp. Warn Days</font></td>\n");
printf("                            <td><input type=\"text\" size=\"5\" maxlength=\"14\" name=\"warndays\" value=\"");
if(c) {
	if(userlist[c].warn[0]=='\0') 
		printf("-1"); 
	else
		printf("%s",userlist[c].warn);
} else
	printf("%d", getdefs("PASS_WARN_AGE",-1));
printf("\"></td>\n                            <td width=\"100\"><font size=\"2\" face=\"Arial\">Inactive Days</font></td>\n");
printf("                            <td><input type=\"text\" size=\"5\" maxlength=\"14\" name=\"inactdays\" value=\"");
if(c) {
	if(userlist[c].inact[0]=='\0') 
		printf("-1");
	else
		printf("%s",userlist[c].inact); 
} else 
	printf("-1");
printf("\"></td>\n                        </tr>\n");
printf("                        <tr>\n");
printf("                            <td width=\"100\"><font size=\"2\" face=\"Arial\">Expiration Date</font></td>\n");
printf("                            <td><input type=\"text\" size=\"10\" maxlength=\"11\" name=\"expdate\" value=\"");
if(c&&strlen(userlist[c].expire)>3) {
	expire*=atol(userlist[c].expire);
	exptm=gmtime(&expire);
	switch(dispmode) {
		case 1:
			printf("%02d/%02d/%02d",exptm->tm_mday,exptm->tm_mon+1,exptm->tm_year);
			break;
		case 2:
			printf("%02d/%02d/%02d",exptm->tm_mon+1,exptm->tm_mday,exptm->tm_year);
			break;
		case 3:
			printf("%02d/%02d/%02d",exptm->tm_year,exptm->tm_mon+1,exptm->tm_mday);
			break;
	}
}
printf("\"></td>\n                            <td width=\"100\"><font size=\"2\" face=\"Arial\"><b><i>");
switch(dispmode) {
	case 1:
		printf("(dd/mm/yy)");
		break;
	case 2:
		printf("(mm/dd/yy)");
		break;
	case 3:
		printf("(yy/mm/dd)");
		break;
}		
printf("</i></b></font></td>\n                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr><tr>\n");
printf("            <td><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td bgcolor=\"#D0C08E\"><input type=\"submit\"\n");
printf("                    name=\"ok\" value=\"OK\"></td>\n");
printf("                    <td bgcolor=\"#D0C08E\"><input type=\"submit\"\n");
printf("                    name=\"cancel\" value=\"Cancel\"></td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("    </table>\n");
#else
printf("            <td><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td bgcolor=\"#D0C08E\"><input type=\"submit\"\n");
printf("                    name=\"ok\" value=\"OK\"></td>\n");
printf("                    <td bgcolor=\"#D0C08E\"><input type=\"submit\"\n");
printf("                    name=\"cancel\" value=\"Cancel\"></td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("    </table>\n");
#endif
printf("</form>\n");
printf("</body>\n");
printf("</html>\n");
fclose(group_fp);
fclose(shell_fp);
exit(0);
}

void view_userlist() {
char temp[20],utmp[15],gtmp[55];
int i=1,c=0,se=0;
printf("Content-type: text/html\n\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>User List</title>\n");
printf("</head>\n");
printf("<body bgcolor=\"#FFFFFF\">\n");
printf("<form action=\"/cgi-bin/visualadmin\" method=\"POST\">\n");
printf("    <input type=\"hidden\" name=\"locator\" value=\"usrlist\"><input\n");
printf("    type=\"hidden\" name=\"pass\" value=\"%s\"><input type=\"hidden\"\n",pass);
printf("    name=\"user\" value=\"%s\"><input type=\"hidden\" name=\"query\" value=\"%s\"><table border=\"0\">\n",user,query);
printf("    <table border=\"0\">\n");
printf("        <tr>\n");
printf("            <td bgcolor=\"#BCA55F\"><font size=\"2\" face=\"Arial\"><strong>Check</strong></font></td>\n");
printf("            <td width=\"60\" bgcolor=\"#BCA55F\"><font size=\"2\"\n");
printf("            face=\"Arial\"><strong>Login</strong></font></td>\n");
printf("            <td width=\"250\" bgcolor=\"#BCA55F\"><font size=\"2\"\n");
printf("            face=\"Arial\"><strong>Gecos</strong></font></td>\n");
printf("            <td width=\"30\" bgcolor=\"#BCA55F\"><font size=\"2\"\n");
printf("            face=\"Arial\"><strong>UID</strong></font></td>\n");
printf("            <td width=\"30\" bgcolor=\"#BCA55F\"><font size=\"2\"\n");
printf("            face=\"Arial\"><strong>GID</strong></font></td>\n");
printf("            <td width=\"100\" bgcolor=\"#BCA55F\"><font size=\"2\"\n");
printf("            face=\"Arial\"><strong>Home Dir</strong></font></td>\n");
printf("            <td width=\"85\" bgcolor=\"#BCA55F\"><font size=\"2\"\n");
printf("            face=\"Arial\"><strong>Shell</strong></font></td>\n");
printf("        </tr>\n");
if(strcmp(query,"none")) {
	for(i=2,c=0;i<=strlen(query);i++,c++)
		temp[c]=query[i];
	if(query[1]=='0') strlow(temp);
	if(query[0]=='1') se=1; else se=2;
} else se=0;
c=0;
for(i=1;i<=nusers;i++){
	if(!userlist[i].active) continue;
	c++;
	if(se) {
		strcpy(gtmp,userlist[i].gecos);
		strcpy(utmp,userlist[i].user);
		if(query[1]=='0') { strlow(utmp); strlow(gtmp); }
		switch(se) {
			case 1:
				if(!(strstr(utmp,temp) != NULL ||
				   strstr(gtmp,temp) != NULL)) continue;
				break;
			case 2:
				if(strstr(utmp,temp) != NULL ||
				   strstr(gtmp,temp) != NULL) continue;
				break;
		}
	}
	printf("        <tr>\n");
	printf("            <td bgcolor=\"#DED3B1\"><input type=\"checkbox\"\n");
	printf("            name=\"usr\" value=\"%d\"></td>\n", c);
	printf("            <td width=\"60\" bgcolor=\"#DED3B1\"><a\n");
	printf("            href=\"/cgi-bin/visualadmin?locator=usrlist&user=%s&pass=%s&num=%d&query=%s&moveto=moduser\"><font\n",user,pass,c,query);
	printf("            size=\"2\">%s</font></a></td>\n", userlist[i].user);
	printf("            <td width=\"250\" bgcolor=\"#DED3B1\"><font size=\"2\">\n");
	printf("            %s</font></td>\n", userlist[i].gecos);
	printf("            <td width=\"30\" bgcolor=\"#DED3B1\"><font size=\"2\">%d</font></td>\n", userlist[i].uid);
	printf("            <td width=\"30\" bgcolor=\"#DED3B1\"><font size=\"2\">%d</font></td>\n", userlist[i].gid);
	printf("            <td width=\"100\" bgcolor=\"#DED3B1\"><font size=\"2\">%s</font></td>\n", userlist[i].home);
	printf("            <td width=\"85\" bgcolor=\"#DED3B1\"><font size=\"2\">%s</font></td>\n", userlist[i].shell);
	printf("        </tr>\n");
}
printf("    </table>\n");
printf("    <table border=\"0\">\n");
printf("        <tr>\n");
printf("            <td bgcolor=\"#BCA55F\"><input type=\"submit\"\n");
printf("            name=\"delete\" value=\"Delete Selected\"></td>\n");
printf("            <td bgcolor=\"#BCA55F\"><input type=\"submit\" name=\"ok\"\n");
printf("            value=\"OK\"></td>\n");
printf("        </tr>\n");
printf("    </table>\n");
printf("    <table border=\"0\">\n");
printf("        <tr>\n");
printf("            <td width=\"620\" bgcolor=\"#D0C08E\"><font size=\"2\"\n");
printf("            face=\"Arial\"><strong><u>To Delete an user</u></strong>:\n");
printf("            Select the target user(s) checkbox and\n");
printf("            press 'Delete Selected' <br>\n");
printf("            <strong><u>To Modify an user:</u></strong> Press on\n");
printf("            the Login user name.</font></td>\n");
printf("        </tr>\n");
printf("    </table>\n");
printf("</form>\n");
printf("</body>\n");
printf("</html>\n");
exit(0);
}

void view_welcome() {
printf("Content-type: text/html\n\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>Welcome to Visual Admin 2.0</title>\n");
printf("</head>\n");
printf("<body bgcolor=\"#FFFFFF\">\n");
printf("<form action=\"/cgi-bin/visualadmin\" method=\"POST\">\n");
printf("    <input type=\"hidden\" name=\"locator\" value=\"login\">\n");
printf("    <table border=\"0\">\n");
printf("        <tr>\n");
printf("            <td bgcolor=\"#AB9347\"><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td bgcolor=\"#CBB981\"><table border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td bgcolor=\"#D0C08E\"><p\n");
printf("                            align=\"center\"><font size=\"4\"><strong>Visual\n");
printf("                            Admin 2.0</strong></font></p>\n");
printf("                            </td>\n");
printf("                        </tr>\n");
printf("                        <tr>\n");
printf("                            <td bgcolor=\"#D0C08E\"><p\n");
printf("                            align=\"center\"><font size=\"1\"\n");
printf("                            face=\"Arial\">by Mauro J. De Gennaro</font></p>\n");
printf("                            </td>\n");
printf("                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td bgcolor=\"#CBB981\"><table border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td bgcolor=\"#DED3B1\"><font size=\"2\"\n");
printf("                            face=\"Arial\">Username</font></td>\n");
printf("                            <td bgcolor=\"#DED3B1\"><input\n");
printf("                            type=\"text\" size=\"20\" maxlength=\"8\"\n");
printf("                            name=\"user\"></td>\n");
printf("                        </tr>\n");
printf("                        <tr>\n");
printf("                            <td bgcolor=\"#DED3B1\"><font size=\"2\"\n");
printf("                            face=\"Arial\">Password</font></td>\n");
printf("                            <td bgcolor=\"#DED3B1\"><input\n");
printf("                            type=\"password\" size=\"20\"\n");
printf("                            maxlength=\"18\" name=\"pass\"></td>\n");
printf("                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td bgcolor=\"#CBB981\"><table border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td align=\"center\" bgcolor=\"#AB9347\"><input\n");
printf("                            type=\"submit\" name=\"login\"\n");
printf("                            value=\"Login\"></td>\n");
printf("                            <td align=\"center\" bgcolor=\"#AB9347\"><input\n");
printf("                            type=\"reset\" name=\"reset\"\n");
printf("                            value=\"Reset\"></td>\n");
printf("                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("    </table>\n");
printf("</form>\n");
printf("</body>\n");
printf("</html>\n");
exit(0);
}

void view_search() {
printf("Content-type: text/html\n\n");
printf("<html>\n");
printf("<head>\n");
printf("<title>User Search Filter</title>\n");
printf("</head>\n");
printf("<body bgcolor=\"#FFFFFF\">\n");
printf("<form action=\"/cgi-bin/visualadmin\" method=\"POST\">\n");
printf("    <input type=\"hidden\" name=\"locator\" value=\"usrfind\"><input\n");
printf("    type=\"hidden\" name=\"pass\" value=\"%s\"><input type=\"hidden\"\n",pass);
printf("    name=\"user\" value=\"%s\"><table border=\"0\">\n",user);
printf("        <tr>\n");
printf("            <td width=\"400\" bgcolor=\"#DAC296\"><table border=\"0\">\n");
printf("                <tr>\n");
printf("                    <td width=\"400\" bgcolor=\"#B17441\"><font\n");
printf("                    size=\"2\" face=\"Arial\"><strong>User List -\n");
printf("                    Search Filter</strong></font></td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td width=\"400\" bgcolor=\"#C29C56\"><table\n");
printf("                    border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">Match\n");
printf("                            users</font> </td>\n");
printf("                            <td><input type=\"radio\" checked\n");
printf("                            name=\"cont\" value=\"1\"><font\n");
printf("                            size=\"2\" face=\"Arial\">Containing</font>\n");
printf("                            </td>\n");
printf("                            <td><input type=\"radio\" name=\"cont\"\n");
printf("                            value=\"2\"><font size=\"2\"\n");
printf("                            face=\"Arial\">Not Containing</font></td>\n");
printf("                            <td><input type=\"radio\" name=\"cont\"\n");
printf("                            value=\"0\"><font size=\"2\"\n");
printf("                            face=\"Arial\">All Users</font></td>\n");
printf("                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td width=\"400\" bgcolor=\"#C29C56\"><table\n");
printf("                    border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td><font size=\"2\" face=\"Arial\">word</font></td>\n");
printf("                            <td><input type=\"text\" size=\"20\"\n");
printf("                            maxlength=\"13\" name=\"word\"></td>\n");
printf("                            <td><input type=\"checkbox\"\n");
printf("                            name=\"case\" value=\"ON\"><font size=\"2\"\n");
printf("                            face=\"Arial\">Case Sensitive</font></td>\n");
printf("                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("                <tr>\n");
printf("                    <td width=\"400\" bgcolor=\"#C29C56\"><table\n");
printf("                    border=\"0\">\n");
printf("                        <tr>\n");
printf("                            <td><input type=\"submit\"\n");
printf("                            name=\"search\" value=\"Search\"></td>\n");
printf("                            <td><input type=\"submit\"\n");
printf("                            name=\"cancel\" value=\"Cancel\"></td>\n");
printf("                        </tr>\n");
printf("                    </table>\n");
printf("                    </td>\n");
printf("                </tr>\n");
printf("            </table>\n");
printf("            </td>\n");
printf("        </tr>\n");
printf("    </table>\n");
printf("</form>\n");
printf("</body>\n");
printf("</html>\n");
exit(0);
}
