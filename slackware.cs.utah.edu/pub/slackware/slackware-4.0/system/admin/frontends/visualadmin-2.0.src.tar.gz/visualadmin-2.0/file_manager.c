/*              Mauro Javier De Gennaro <mauro@minter.com.ar>           */

#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include "visualadmin.h"

extern file_tb *filelist;

void save_file(int a);

void save_file(int a) {
char *file=NULL;
int c=0,b=0;
FILE *fp;
file=malloc(strlen(data));
if(file==NULL) critical("Can't malloc() data");
get_var(data, file, "file=");
if(a<0||a>20) critical("File doesn't exist");
if(access(filelist[a].file,0)!=0) critical("File doesn't exist");
fp=fopen(filelist[a].file,"w");
if(!fp) critical("Unable to open file for writing");
dos2unix(fp,file);
fclose(fp);
return;
}
