/*              Mauro Javier De Gennaro <mauro@minter.com.ar>           */

/* getdefs.c <2.0> - Gets shadow password defaults from login.defs */

#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include "visualadmin.h"

int getdefs(char *match, int ifnot);

int getdefs(char *match, int ifnot) {
char buf[1024],tval[20],*s,*e;
int value=-1;
FILE *fp;
fp=fopen(F_LDEFS, "r");
if(!fp) return(ifnot);
while(fgets(buf,sizeof(buf),fp)) 
	if(strstr(buf,match) != NULL && buf[0]!='#') {
		s=buf;
		e=index(s,' ');
		if(!e) e=index(s,'\t');
		if(!e) return(ifnot);
		s=e+1;
		e=index(s,'\n');
		if(!e) e=index(s,'\0');
		if(!e) return(ifnot);
		strncpy(tval,s,e-s);
		tval[e-s]='\0';
		value=atoi(tval);
	}
fclose(fp);
if(value==-1)
	return(ifnot);
else
	return(value);
}