/*               Mauro Javier De Gennaro <mauro@minter.com.ar>        */

/* codepass.c <2.0> - A simple password coding/decoding algorithm */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "visualadmin.h"

void code_pass(int mode);
int cript(int carac, int code);
int dcript(int carac, int code);


void code_pass(int mode) {
char aux[21];
int i,t=0;
long code=0;

for(i=0; i<=strlen(CRIPT_KEY)-1; i++) 
	code+=(CRIPT_KEY[i]/(i+1));

for(i=0; i<=strlen(user)-1; i++) 
	code+=(user[i]/(i+1));

if(code>62) code-=((code/62)*62);
if(code==60) code--;

strcpy(aux, pass);

if (mode) {
	for(i=0;i<=strlen(aux);i++)
		aux[i]=cript(aux[i], code);
} else {
	for(i=0;i<=strlen(aux);i++)
		aux[i]=dcript(aux[i], code);
}
strcpy(pass,aux);
}

int cript(int carac, int code) {
int i,wich=0,start=0;
char alfa[]="1ZaYbXcWdV2eUfT8gSh6RiQj3PkOlNmMn0LoKp4JqIrHs7GtF5u9EvDwCxByAz";
for(i=0; i<=61; i++) if(alfa[i]==carac) { start=i; wich=1; }
if(!wich) return(carac);
for(i=0,wich=start; i<=code; i++,wich++) if (wich==61) wich=-1;
return(alfa[wich]);
}

int dcript(int carac, int code) {
int i,wich=0,start=0;
char alfa[]="1ZaYbXcWdV2eUfT8gSh6RiQj3PkOlNmMn0LoKp4JqIrHs7GtF5u9EvDwCxByAz";
for(i=0; i<=61; i++) if(alfa[i]==carac) { start=i; wich=1; }
if(!wich) return(carac);
for(i=0,wich=start; i<=code; i++,wich--) if (wich==0) wich=62;
return(alfa[wich]);
}

