/*              Mauro Javier De Gennaro <mauro@minter.com.ar>           */

#include <stdio.h> 
#include <string.h>
#include <stdlib.h>

void strlow(char *in);

void strlow(char *in) {
int c=0;

	for (c; c <= strlen(in); c++) {
	if (in[c]== 'A') in[c]='a';
	if (in[c]== 'B') in[c]='b';
	if (in[c]== 'C') in[c]='c';
	if (in[c]== 'D') in[c]='d';
	if (in[c]== 'E') in[c]='e';
	if (in[c]== 'F') in[c]='f';
	if (in[c]== 'G') in[c]='g';
	if (in[c]== 'H') in[c]='h';
	if (in[c]== 'I') in[c]='i';
	if (in[c]== 'J') in[c]='j';
	if (in[c]== 'K') in[c]='k';
	if (in[c]== 'L') in[c]='l';
	if (in[c]== 'M') in[c]='m';
	if (in[c]== 'N') in[c]='n';
	if (in[c]== 'O') in[c]='o';
	if (in[c]== 'P') in[c]='p';
	if (in[c]== 'Q') in[c]='q';
	if (in[c]== 'R') in[c]='r';
	if (in[c]== 'S') in[c]='s';
	if (in[c]== 'T') in[c]='t';
	if (in[c]== 'U') in[c]='u';
	if (in[c]== 'V') in[c]='v';
	if (in[c]== 'W') in[c]='w';
	if (in[c]== 'X') in[c]='x';
	if (in[c]== 'Y') in[c]='y';
	if (in[c]== 'Z') in[c]='z'; 
	}
}
