/*           Mauro Javier De Gennaro <mauro@minter.com.ar>        */

/* verify.c <2.0> - Checks username's passwords and GID access */

#include <stdio.h>
#include <stdlib.h>
#include "visualadmin.h"
#ifdef SHADOW_PASSWD
#include <shadow.h>
#else
#include <pwd.h>
#endif

int verify_pass();

int verify_pass() {
#ifdef SHADOW_PASSWD
struct spwd *sptr;
#endif
struct passwd *ptr;
int status=0;
char *ep;

#ifdef SHADOW_PASSWD
setpwent();
setspent();
while ((sptr=getspent()) != NULL) {
	if (strcmp(user, sptr->sp_namp) == 0) {
		ep=(char *) crypt(pass,sptr->sp_pwdp);
		if(strcmp(ep, sptr->sp_pwdp) == 0) {
			ptr=getpwnam(user);
			if(ptr->pw_gid) 
				status=1;
			else
				status=2;
		} else
			status=0; 
			break;		
	}
}
endpwent();	
endspent();
#else
setpwent();
while ((ptr=getpwent()) != NULL) {
	if (strcmp(user, ptr->pw_name) == 0) {
		ep=(char *) crypt(pass,ptr->pw_passwd);
		if(strcmp(ep, ptr->pw_passwd) == 0) 
			if(ptr->pw_gid) 
				status=1;
			else
				status=2;
		else
			status=0;
		break;		
	}
}	
endpwent();
#endif
return(status);
}
