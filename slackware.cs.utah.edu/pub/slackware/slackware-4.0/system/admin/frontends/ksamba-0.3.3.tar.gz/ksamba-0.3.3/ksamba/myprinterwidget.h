/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page1.h
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#ifndef myprinterwidget_included
#define myprinterwidget_included

#include <qdialog.h>
#include <qtabdlg.h>

#include "daten2.h"

#include "myservicewidget_page1.h"
#include "myservicewidget_page2.h"
#include "myservicewidget_page3.h"
#include "myservicewidget_page4.h"
#include "myprinterwidget_page1.h"

class myprinterwidget : public QTabDialog
{
    Q_OBJECT

public:
	myprinterwidget(QWidget* parent = NULL,const char* name = NULL,
		bool modal=TRUE);
  	virtual ~myprinterwidget();

	void setData(QCharDict *);
	void saveData(QCharDict *);


private:
	myservicewidget_page1 *ServiceWidget_Page1;
	myservicewidget_page2 *ServiceWidget_Page2;
	myservicewidget_page3 *ServiceWidget_Page3;
	myservicewidget_page4 *ServiceWidget_Page4;
	myprinterwidget_page1 *PrinterWidget_Page1;
	QTabDialog *TabDialog;
	QString *retData;
};
#endif // myprinterwidget_included
