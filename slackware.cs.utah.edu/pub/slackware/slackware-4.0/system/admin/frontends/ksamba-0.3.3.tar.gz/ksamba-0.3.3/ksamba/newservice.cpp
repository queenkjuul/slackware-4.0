/**********************************************************************

	--- Dlgedit generated file ---

	File: newservice.cpp
	Last generated: Mon Jul 21 19:13:33 1997

 *********************************************************************/

#include "newservice.h"
#include "newservice.moc"
#include <klocale.h>
#include <kapp.h>

#define Inherited newserviceData

void newservice::is_fileservice()
{
	newservice_type = "fileservice";
}

void newservice::is_printservice()
{
	newservice_type = "printservice";
}

void newservice::translate()
{
	fileservice_btn->setText( klocale->translate("fileservice") );
	newserv_label->setText( klocale->translate("name of new service") );
	newpath_label->setText( klocale->translate("path of new service") );
	cancel_btn->setText( klocale->translate("Cancel") );
	printservice_btn->setText( klocale->translate("printservice") );
	newservice_btngrp->setTitle( klocale->translate("New service is") );
}

void newservice::quit_ok()
{
	bool name_ok = true;
	bool path_ok = true;
	newservice_name = newservice_lineed->text();
	printf("%d...\n", newservice_name.length() );
	if (newservice_name.isEmpty() == true)
	{ 
		KMsgBox::message(this,"Error",
	 	"You must enter a name!\n"
	 	"Example: Test1 :)",1);
		name_ok = false;
	}
	newservice_path = path_lineed->text();
	if (newservice_path.isEmpty() == true )
	{ 
		KMsgBox::message(this,"Error",
	 	"You must enter a path!\n"
	 	"Example: /usr/local :)",1);
		path_ok = false;
	}
	if ( name_ok == true && path_ok == true) done(1); 
} 


void newservice::quit_cancel()
{
	done(0);
}

newservice::newservice(QWidget* parent,const char* name):Inherited( parent, name )
{
	setCaption( klocale->translate("New Service") );
	translate();
//	newservice_type = 0;
	newservice_type = "fileservice";
	connect ( ok_btn , SIGNAL(clicked()) , SLOT(quit_ok()) );
	connect ( cancel_btn , SIGNAL(clicked()) , SLOT(quit_cancel()) );
	connect ( fileservice_btn , SIGNAL(clicked()) , SLOT(is_fileservice()) );
	connect ( printservice_btn , SIGNAL(clicked()) , SLOT(is_printservice()) );

}


newservice::~newservice()
{
}
