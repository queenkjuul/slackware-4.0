/**********************************************************************

	--- Qt Architect generated file ---

	File: myservicewidget_page4.cpp
	Last generated: Mon Feb 2 11:04:04 1998

 *********************************************************************/

#include "myservicewidget_page4.h"
#include "myservicewidget_page4.moc"

#define Inherited myservicewidget_page4Data

myservicewidget_page4::myservicewidget_page4
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
}


myservicewidget_page4::~myservicewidget_page4()
{
}
