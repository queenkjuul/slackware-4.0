/**********************************************************************

	--- Qt Architect generated file ---

	File: myservicewidget_page1.cpp
	Last generated: Sat Jan 3 21:27:08 1998

 *********************************************************************/

#include "myservicewidget_page1.h"
#include "myservicewidget_page1.moc"

#define Inherited myservicewidget_page1Data

myservicewidget_page1::myservicewidget_page1
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
}


myservicewidget_page1::~myservicewidget_page1()
{
}
