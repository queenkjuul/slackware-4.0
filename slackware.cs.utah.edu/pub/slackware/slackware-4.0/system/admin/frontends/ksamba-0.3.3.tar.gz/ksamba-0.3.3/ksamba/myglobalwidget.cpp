/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page1.cpp
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#include "myglobalwidget.h"
#include "myglobalwidget.moc"
#include <qstring.h>

#include <kdebug.h>

#define Inherited QTabDialog

myglobalwidget::myglobalwidget(QWidget* parent,const char* name, bool modal)
	:Inherited( parent, name, modal) 
{
	GlobalWidget_Page1 = new myglobalwidget_page1(this);
	GlobalWidget_Page2 = new myglobalwidget_page2(this);
	GlobalWidget_Page3 = new myglobalwidget_page3(this);
	GlobalWidget_Page4 = new myglobalwidget_page4(this);

	addTab(GlobalWidget_Page1,"Page 1");
	addTab(GlobalWidget_Page2,"Page 2");
	addTab(GlobalWidget_Page3,"Page 3");
	addTab(GlobalWidget_Page4,"Page 4");

	setCaption( "Global Settings" );
	setCancelButton("Cancel");

	resize(660,500);
}

const char *myglobalwidget::getServerString()
{
	return GlobalWidget_Page1->server_string_lineed->text();
}

const char *myglobalwidget::getWorkgroup()
{
	return GlobalWidget_Page1->workgroup_lineed->text();
}

void myglobalwidget::saveData(QCharDict *GlobalDaten)
{
	KDEBUG(KDEBUG_INFO,3700-3800,"start saving data");
	if (strcmp(GlobalWidget_Page2->autoservices_lineed->text(),
		   GlobalDaten->find("auto services")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->autoservices_lineed->text());
		GlobalDaten->replace("auto services",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->announce_combo->currentText(),
		   GlobalDaten->find("announce as")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->announce_combo->currentText());
		GlobalDaten->replace("announce as",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->announce_version_lineed->text(),
		   GlobalDaten->find("announce version")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->announce_version_lineed->text());
		GlobalDaten->replace("announce version",retData->data());
	}

	if (GlobalWidget_Page1->bind_interfaces_chkbx->isChecked())
	GlobalDaten->replace("bind interfaces only","yes");
	else
	GlobalDaten->replace("bind interfaces only","no");

	if (GlobalWidget_Page3->browselist_chkbx->isChecked())
	GlobalDaten->replace("browse list","yes");
	else
	GlobalDaten->replace("browse list","no");

	if (strcmp(GlobalWidget_Page3->character_set_combo->currentText(),
		   GlobalDaten->find("character set")) != 0 &&
	    strcmp(GlobalWidget_Page3->character_set_combo->currentText(),
		   "(none)") != 0 )
	{
		retData = new QString(GlobalWidget_Page3->character_set_combo->currentText());
		GlobalDaten->replace("character set",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->character_set_combo->currentText(),
		   GlobalDaten->find("character set")) != 0 &&
	    strcmp(GlobalWidget_Page3->character_set_combo->currentText(),
		   "(none)") == 0 )
	{
		GlobalDaten->replace("character set","");
	}

	if (strcmp(GlobalWidget_Page3->client_code_combo->currentText(),
		   GlobalDaten->find("client code page")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->client_code_combo->currentText());
		GlobalDaten->replace("client code page",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->config_file_lineed->text(),
		   GlobalDaten->find("config file")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->config_file_lineed->text());
		GlobalDaten->replace("config file",retData->data());
	}

	if (GlobalWidget_Page1->deadtime_slider->value() != 
		atoi(GlobalDaten->find("deadtime")) )
	{
		retData = new QString();
		retData->setNum(GlobalWidget_Page1->deadtime_slider->value());
		GlobalDaten->replace("deadtime",retData->data());
	}

	if (GlobalWidget_Page1->debuglevel_slider->value() != 
		atoi(GlobalDaten->find("debuglevel")) )
	{
		retData = new QString();
		retData->setNum(GlobalWidget_Page1->debuglevel_slider->value());
		GlobalDaten->replace("debuglevel",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->dfree_command_lineed->text(),
		   GlobalDaten->find("dfree command")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->dfree_command_lineed->text());
		GlobalDaten->replace("dfree command",retData->data());
	}

	if (GlobalWidget_Page3->dns_proxy_chkbx->isChecked())
	GlobalDaten->replace("dns proxy","yes");
	else
	GlobalDaten->replace("dns proxy","no");

	if (strcmp(GlobalWidget_Page3->domain_controller_lineed->text(),
		   GlobalDaten->find("domain controller")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->domain_controller_lineed->text());
		GlobalDaten->replace("domain controller",retData->data());
	}

	if (GlobalWidget_Page3->domain_logons_chkbx->isChecked())
	GlobalDaten->replace("domain logons","yes");
	else
	GlobalDaten->replace("domain logons","no");

	if (GlobalWidget_Page3->domain_master_chkbx->isChecked())
	GlobalDaten->replace("domain master","yes");
	else
	GlobalDaten->replace("domain master","no");

	if (GlobalWidget_Page3->encrypt_passwords_chkbx->isChecked())
	GlobalDaten->replace("encrypt passwords","yes");
	else
	GlobalDaten->replace("encrypt passwords","no");

	if (GlobalWidget_Page3->getwd_cache_chkbx->isChecked())
	GlobalDaten->replace("getwd cache","yes");
	else
	GlobalDaten->replace("getwd cache","no");

	if (strcmp(GlobalWidget_Page3->homedir_map_lineed->text(),
		   GlobalDaten->find("homedir map")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->homedir_map_lineed->text());
		GlobalDaten->replace("homedir map",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->host_equiv_lineed->text(),
		   GlobalDaten->find("hosts equiv")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->host_equiv_lineed->text());
		GlobalDaten->replace("hosts equiv",retData->data());
	}

	if (strcmp(GlobalWidget_Page1->include_lineed->text(),
		   GlobalDaten->find("include")) != 0)
	{
		retData = new QString(GlobalWidget_Page1->include_lineed->text());
		GlobalDaten->replace("include",retData->data());
	}

	unsigned int i;
	QString *tmpString = new QString("");
	for (i=0; i < GlobalWidget_Page1->ip_listbx->count(); ++i)
	{
		tmpString->append(GlobalWidget_Page1->ip_listbx->text(i));
		if (i == (GlobalWidget_Page1->ip_listbx->count()-1)) break;
		tmpString->append(" ");
	}
//	if (tmpString->isNull())
//	{
//	tmpString->append("");
//	}
	if (strcmp(tmpString->data(), GlobalDaten->find("interfaces")) != 0)
	{
		printf("replace interfaces\n");
		GlobalDaten->replace("interfaces",tmpString->data());

	}
	else
	{
		delete tmpString;
	}

	if (GlobalWidget_Page1->keep_alive_slider->value() != 
		atoi(GlobalDaten->find("keep alive")) )
	{
		retData = new QString();
		retData->setNum(GlobalWidget_Page1->keep_alive_slider->value());
		GlobalDaten->replace("keep alive",retData->data());
	}

	if (GlobalWidget_Page4->lm_announce_chkbx->isChecked())
	GlobalDaten->replace("lm announce","yes");
	else
	GlobalDaten->replace("lm announce","no");

	if (GlobalWidget_Page1->load_printers_chkbx->isChecked())
	GlobalDaten->replace("load printers","yes");
	else
	GlobalDaten->replace("load printers","no");

	if (GlobalWidget_Page3->local_master_chkbx->isChecked())
	GlobalDaten->replace("local master","yes");
	else
	GlobalDaten->replace("local master","no");

	if (strcmp(GlobalWidget_Page1->lock_dir_lineed->text(),
		   GlobalDaten->find("lock directory")) != 0)
	{
		retData = new QString(GlobalWidget_Page1->lock_dir_lineed->text());
		GlobalDaten->replace("lock directory",retData->data());
	}

	if (strcmp(GlobalWidget_Page1->log_file_lineed->text(),
		   GlobalDaten->find("log file")) != 0)
	{
		retData = new QString(GlobalWidget_Page1->log_file_lineed->text());
		GlobalDaten->replace("log file",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->logon_drive_lineed->text(),
		   GlobalDaten->find("logon drive")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->logon_drive_lineed->text());
		GlobalDaten->replace("logon drive",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->logon_home_lineed->text(),
		   GlobalDaten->find("logon home")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->logon_home_lineed->text());
		GlobalDaten->replace("logon home",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->logon_path_lineed->text(),
		   GlobalDaten->find("logon path")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->logon_path_lineed->text());
		GlobalDaten->replace("logon path",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->logon_script_lineed->text(),
		   GlobalDaten->find("logon script")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->logon_script_lineed->text());
		GlobalDaten->replace("logon script",retData->data());
	}

	if (GlobalWidget_Page1->lpq_cache_slider->value() != 
		atoi(GlobalDaten->find("lpq cache time")) )
	{
		retData = new QString();
		retData->setNum(GlobalWidget_Page1->lpq_cache_slider->value());
		GlobalDaten->replace("lpq cache time",retData->data());
	}

	if (GlobalWidget_Page1->mangled_stack_slider->value() != 
		atoi(GlobalDaten->find("mangled stack")) )
	{
		retData = new QString();
		retData->setNum(GlobalWidget_Page1->mangled_stack_slider->value());
		GlobalDaten->replace("mangled stack",retData->data());
	}

	if (GlobalWidget_Page1->max_log_size_slider->value() != 
		atoi(GlobalDaten->find("max log size")) )
	{
		retData = new QString();
		retData->setNum(GlobalWidget_Page1->max_log_size_slider->value());
		GlobalDaten->replace("max log size",retData->data());
	}

	if (strcmp(GlobalWidget_Page3->max_disk_size_lineed->text(),
		   GlobalDaten->find("max disk size")) != 0)
	{
		retData = new QString(GlobalWidget_Page3->max_disk_size_lineed->text());
		GlobalDaten->replace("max disk size",retData->data());
	}

	if (strcmp(GlobalWidget_Page2->message_cmd_lineed->text(),
		   GlobalDaten->find("message command")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->message_cmd_lineed->text());
		GlobalDaten->replace("message command",retData->data());
	}

	if (strcmp(GlobalWidget_Page4->name_resolve_order_lineed->text(),
		   GlobalDaten->find("name resolve order")) != 0)
	{
		retData = new QString(GlobalWidget_Page4->name_resolve_order_lineed->text());
		GlobalDaten->replace("name resolve order",retData->data());
	}

	if (strcmp(GlobalWidget_Page4->netbios_aliases_lineed->text(),
		   GlobalDaten->find("netbios aliases")) != 0)
	{
		retData = new QString(GlobalWidget_Page4->netbios_aliases_lineed->text());
		GlobalDaten->replace("netbios aliases",retData->data());
	}

	if (strcmp(GlobalWidget_Page4->netbios_name_lineed->text(),
		   GlobalDaten->find("netbios name")) != 0)
	{
		retData = new QString(GlobalWidget_Page4->netbios_name_lineed->text());
		GlobalDaten->replace("netbios name",retData->data());
	}

	if (GlobalWidget_Page3->networkstation_user_login_chkbx->isChecked())
	GlobalDaten->replace("networkstation user login","yes");
	else
	GlobalDaten->replace("networkstation user login","no");

	if (GlobalWidget_Page3->nis_homedir_chkbx->isChecked())
	GlobalDaten->replace("nis homedir","yes");
	else
	GlobalDaten->replace("nis homedir","no");

	if (GlobalWidget_Page1->null_passwords_chkbx->isChecked())
	GlobalDaten->replace("null passwords","yes");
	else
	GlobalDaten->replace("null passwords","no");

	if (GlobalWidget_Page1->os_level_slider->value() != 
		atoi(GlobalDaten->find("os level")) )
	{
		retData = new QString();
		retData->setNum(GlobalWidget_Page1->os_level_slider->value());
		GlobalDaten->replace("os level",retData->data());
	}

	if (strcmp(GlobalWidget_Page2->password_chat_lineed->text(),
		   GlobalDaten->find("passwd chat")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->password_chat_lineed->text());
		GlobalDaten->replace("passwd chat",retData->data());
	}

	if (strcmp(GlobalWidget_Page2->passwd_programm_lineed->text(),
		   GlobalDaten->find("passwd program")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->passwd_programm_lineed->text());
		GlobalDaten->replace("passwd program",retData->data());
	}

	if (strcmp(GlobalWidget_Page2->password_server_lineed->text(),
		   GlobalDaten->find("password server")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->password_server_lineed->text());
		GlobalDaten->replace("password server",retData->data());
	}

	if (strcmp(GlobalWidget_Page1->printcap_name_lineed->text(),
		   GlobalDaten->find("printcap name")) != 0)
	{
		retData = new QString(GlobalWidget_Page1->printcap_name_lineed->text());
		GlobalDaten->replace("printcap name",retData->data());
	}

	if (strcmp(GlobalWidget_Page1->printer_driver_lineed->text(),
		   GlobalDaten->find("printer driver file")) != 0)
	{
		retData = new QString(GlobalWidget_Page1->printer_driver_lineed->text());
		GlobalDaten->replace("printer driver file",retData->data());
	}

	if (GlobalWidget_Page3->preferred_master_chkbx->isChecked())
	GlobalDaten->replace("preferred master","yes");
	else
	GlobalDaten->replace("preferred master","no");

	if (strcmp(GlobalWidget_Page1->protocol_combo->currentText(),
		   GlobalDaten->find("protocol")) != 0)
	{
		retData = new QString(GlobalWidget_Page1->protocol_combo->currentText());
		GlobalDaten->replace("protocol",retData->data());
	}

	if (GlobalWidget_Page4->read_prediction_chkbx->isChecked())
	GlobalDaten->replace("read prediction","yes");
	else
	GlobalDaten->replace("read prediction","no");

	if (GlobalWidget_Page4->read_raw_chkbx->isChecked())
	GlobalDaten->replace("read raw","yes");
	else
	GlobalDaten->replace("read raw","no");

	if (strcmp(GlobalWidget_Page2->remote_announce_lineed->text(),
		   GlobalDaten->find("remote announce")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->remote_announce_lineed->text());
		GlobalDaten->replace("remote announce",retData->data());
	}

	if (strcmp(GlobalWidget_Page2->remote_browse_lineed->text(),
		   GlobalDaten->find("remote browse sync")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->remote_browse_lineed->text());
		GlobalDaten->replace("remote browse sync",retData->data());
	}

	if (strcmp(GlobalWidget_Page2->root_dir_lineed->text(),
		   GlobalDaten->find("root directory")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->root_dir_lineed->text());
		GlobalDaten->replace("root directory",retData->data());
	}

	if (strcmp(GlobalWidget_Page2->security_combo->currentText(),
		   GlobalDaten->find("security")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->security_combo->currentText());
		GlobalDaten->replace("security",retData->data());
	}

	if (strcmp(GlobalWidget_Page1->server_string_lineed->text(),
		   GlobalDaten->find("server string")) != 0)
	{
		retData = new QString(GlobalWidget_Page1->server_string_lineed->text());
		GlobalDaten->replace("server string",retData->data());
	}

	if (strcmp(GlobalWidget_Page2->smb_password_lineed->text(),
		   GlobalDaten->find("smb passwd file")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->smb_password_lineed->text());
		GlobalDaten->replace("smb passwd file",retData->data());
	}

	if (strcmp(GlobalWidget_Page2->smbrun_lineed->text(),
		   GlobalDaten->find("smbrun")) != 0)
	{
		retData = new QString(GlobalWidget_Page2->smbrun_lineed->text());
		GlobalDaten->replace("smbrun",retData->data());
	}

	if (strcmp(GlobalWidget_Page4->socket_adress_lineed->text(),
		   GlobalDaten->find("socket address")) != 0)
	{
		retData = new QString(GlobalWidget_Page4->socket_adress_lineed->text());
		GlobalDaten->replace("socket address",retData->data());
	}

	if (GlobalWidget_Page1->status_chkbx->isChecked())
	GlobalDaten->replace("status","yes");
	else
	GlobalDaten->replace("status","no");

	if (GlobalWidget_Page1->strip_dot_chkbx->isChecked())
	GlobalDaten->replace("strip dot","yes");
	else
	GlobalDaten->replace("strip dot","no");

	if (GlobalWidget_Page1->syslog_slider->value() != 
		atoi(GlobalDaten->find("syslog")) )
	{
		retData = new QString();
		retData->setNum(GlobalWidget_Page1->syslog_slider->value());
		GlobalDaten->replace("syslog",retData->data());
	}

	if (GlobalWidget_Page1->syslog_only_chkbx->isChecked())
	GlobalDaten->replace("syslog only","yes");
	else
	GlobalDaten->replace("syslog only","no");

	if (GlobalWidget_Page1->time_server_chkbx->isChecked())
	GlobalDaten->replace("time server","yes");
	else
	GlobalDaten->replace("time server","no");

	if (GlobalWidget_Page1->unix_password_sync_chkbx->isChecked())
	GlobalDaten->replace("unix password sync","yes");
	else
	GlobalDaten->replace("unix password sync","no");

	if (GlobalWidget_Page1->unix_realname_chkbx->isChecked())
	GlobalDaten->replace("unix realname","yes");
	else
	GlobalDaten->replace("unix realname","no");

//	if (strcmp(GlobalWidget_Page2->valid_chars_lineed->text(),
//		   GlobalDaten->find("valid chars")) != 0)
//	{
//		retData = new QString(GlobalWidget_Page2->valid_chars_lineed->text());
//		GlobalDaten->replace("valid chars",retData->data());
//	}

	if (GlobalWidget_Page4->wins_proxy_chkbx->isChecked())
	GlobalDaten->replace("wins proxy","yes");
	else
	GlobalDaten->replace("wins proxy","no");

	if (strcmp(GlobalWidget_Page4->wins_server_lineed->text(),
		   GlobalDaten->find("wins server")) != 0)
	{
		retData = new QString(GlobalWidget_Page4->wins_server_lineed->text());
		GlobalDaten->replace("wins server",retData->data());
	}

	if (GlobalWidget_Page4->wins_support_chkbx->isChecked())
	GlobalDaten->replace("wins support","yes");
	else
	GlobalDaten->replace("wins support","no");

	if (strcmp(GlobalWidget_Page1->workgroup_lineed->text(),
		   GlobalDaten->find("workgroup")) != 0)
	{
		retData = new QString(GlobalWidget_Page1->workgroup_lineed->text());
		GlobalDaten->replace("workgroup",retData->data());
	}

	if (GlobalWidget_Page4->write_raw_chkbx->isChecked())
	GlobalDaten->replace("write raw","yes");
	else
	GlobalDaten->replace("write raw","no");

/*

	if (->isChecked())
	GlobalDaten->replace("","yes");
	else
	GlobalDaten->replace("","no");

	if (->value() != 
		atoi(GlobalDaten->find("")) )
	{
		retData = new QString();
		retData->setNum(->value());
		GlobalDaten->replace("",retData->data());
	}


	if (strcmp(->text(),
		   GlobalDaten->find("")) != 0)
	{
		retData = new QString(->text());
		GlobalDaten->replace("",retData->data());
	}

*/
//	KDEBUG(KDEBUG_INFO,3700-3800,"data saved");
}
/*---------------------------------------------------------
	Set the values for the lineedits, combos....
---------------------------------------------------------*/
void myglobalwidget::setData(QCharDict *GlobalDaten)
{
	GlobalWidget_Page2->autoservices_lineed->setText(GlobalDaten->find("auto services"));

	if(strcmp(GlobalDaten->find("announce as"),"NT") == 0) 
		GlobalWidget_Page3->announce_combo->setCurrentItem(0);
		else
		if (strcmp(GlobalDaten->find("announce as"),"Win95") == 0) 
			GlobalWidget_Page3->announce_combo->setCurrentItem(1);
		else
		if (strcmp(GlobalDaten->find("announce as"),"WfW") == 0) 
			GlobalWidget_Page3->announce_combo->setCurrentItem(2);

	GlobalWidget_Page3->announce_version_lineed->setText(GlobalDaten->find("announce version"));

	if (strcmp(GlobalDaten->find("bind interfaces only"),"yes") == 0)
	GlobalWidget_Page1->bind_interfaces_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page1->bind_interfaces_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("browse list"),"yes") == 0)
	GlobalWidget_Page3->browselist_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->browselist_chkbx->setChecked(FALSE);

	if(strcmp(GlobalDaten->find("character set"),"(none)") == 0) 
		GlobalWidget_Page3->character_set_combo->setCurrentItem(0);
		else
		if (strcmp(GlobalDaten->find("character set"),"ISO8859-1") == 0) 
			GlobalWidget_Page3->character_set_combo->setCurrentItem(1);
		else
		if (strcmp(GlobalDaten->find("character set"),"ISO8859-2") == 0) 
			GlobalWidget_Page3->character_set_combo->setCurrentItem(2);

	if(strcmp(GlobalDaten->find("client code page"),"437") == 0) 
		GlobalWidget_Page3->client_code_combo->setCurrentItem(0);
		else
		if (strcmp(GlobalDaten->find("client code page"),"850") == 0) 
			GlobalWidget_Page3->client_code_combo->setCurrentItem(1);

	GlobalWidget_Page3->config_file_lineed->setText(GlobalDaten->find("config file"));

	GlobalWidget_Page1->deadtime_slider->setValue(atoi(GlobalDaten->find("deadtime")));

	GlobalWidget_Page1->debuglevel_slider->setValue(atoi(GlobalDaten->find("debuglevel")));

	GlobalWidget_Page3->dfree_command_lineed->setText(GlobalDaten->find("dfree command"));

	if (strcmp(GlobalDaten->find("dns proxy"),"yes") == 0)
	GlobalWidget_Page3->dns_proxy_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->dns_proxy_chkbx->setChecked(FALSE);

	GlobalWidget_Page3->domain_controller_lineed->setText(GlobalDaten->find("domain controller"));

	if (strcmp(GlobalDaten->find("domain logons"),"yes") == 0)
	GlobalWidget_Page3->domain_logons_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->domain_logons_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("domain master"),"yes") == 0)
	GlobalWidget_Page3->domain_master_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->domain_master_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("encrypt passwords"),"yes") == 0)
	GlobalWidget_Page3->encrypt_passwords_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->encrypt_passwords_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("getwd cache"),"yes") == 0)
	GlobalWidget_Page3->getwd_cache_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->getwd_cache_chkbx->setChecked(FALSE);

	GlobalWidget_Page3->homedir_map_lineed->setText(GlobalDaten->find("homedir map"));

	GlobalWidget_Page3->host_equiv_lineed->setText(GlobalDaten->find("hosts equiv"));

	GlobalWidget_Page1->include_lineed->setText(GlobalDaten->find("include"));

	int index = 0;
	QString interstr(GlobalDaten->find("interfaces"));
	while ((index = interstr.find(" ")) > 0)
	{
// string in die einzelnen ip-nummern aufteilen
		GlobalWidget_Page1->ip_listbx->inSort(interstr.left(index));
		interstr = interstr.right(interstr.length()-index);
		interstr = interstr.stripWhiteSpace();
		printf("Index1 = %d .%s\n",index, interstr.data());
	}
	if (!interstr.isEmpty()) GlobalWidget_Page1->ip_listbx->inSort(interstr.data());
//	printf("Fertig!!\n");

	GlobalWidget_Page1->keep_alive_slider->setValue(atoi(GlobalDaten->find("keep alive")));

	if (strcmp(GlobalDaten->find("lm announce"),"yes") == 0)
	GlobalWidget_Page4->lm_announce_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page4->lm_announce_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("load printers"),"yes") == 0)
	GlobalWidget_Page1->load_printers_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page1->load_printers_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("local master"),"yes") == 0)
	GlobalWidget_Page3->local_master_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->local_master_chkbx->setChecked(FALSE);

	GlobalWidget_Page1->lock_dir_lineed->setText(GlobalDaten->find("lock directory"));

	GlobalWidget_Page1->log_file_lineed->setText(GlobalDaten->find("log file"));

	GlobalWidget_Page3->logon_drive_lineed->setText(GlobalDaten->find("logon drive"));

	GlobalWidget_Page3->logon_home_lineed->setText(GlobalDaten->find("logon home"));

	GlobalWidget_Page3->logon_path_lineed->setText(GlobalDaten->find("logon path"));

	GlobalWidget_Page3->logon_script_lineed->setText(GlobalDaten->find("logon script"));

	GlobalWidget_Page1->lpq_cache_slider->setValue(atoi(GlobalDaten->find("lpq cache time")));

	GlobalWidget_Page1->mangled_stack_slider->setValue(atoi(GlobalDaten->find("mangled stack")));

	GlobalWidget_Page1->max_log_size_slider->setValue(atoi(GlobalDaten->find("max log size")));

	GlobalWidget_Page3->max_disk_size_lineed->setText(GlobalDaten->find("max disk size"));

	GlobalWidget_Page2->message_cmd_lineed->setText(GlobalDaten->find("message command"));

	GlobalWidget_Page4->name_resolve_order_lineed->setText(GlobalDaten->find("name resolve order"));

	GlobalWidget_Page4->netbios_aliases_lineed->setText(GlobalDaten->find("netbios aliases"));

	GlobalWidget_Page4->netbios_name_lineed->setText(GlobalDaten->find("netbios name"));

	if (strcmp(GlobalDaten->find("networkstation user login"),"yes") == 0)
	GlobalWidget_Page3->networkstation_user_login_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->networkstation_user_login_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("nis homedir"),"yes") == 0)
	GlobalWidget_Page3->nis_homedir_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->nis_homedir_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("null passwords"),"yes") == 0)
	GlobalWidget_Page1->null_passwords_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page1->null_passwords_chkbx->setChecked(FALSE);

	GlobalWidget_Page1->os_level_slider->setValue(atoi(GlobalDaten->find("os level")));

	GlobalWidget_Page2->password_chat_lineed->setText(GlobalDaten->find("passwd chat"));

	GlobalWidget_Page2->passwd_programm_lineed->setText(GlobalDaten->find("passwd program"));

	GlobalWidget_Page2->password_server_lineed->setText(GlobalDaten->find("password server"));

	GlobalWidget_Page1->printcap_name_lineed->setText(GlobalDaten->find("printcap name"));

	GlobalWidget_Page1->printer_driver_lineed->setText(GlobalDaten->find("printer driver file"));

	if (strcmp(GlobalDaten->find("preferred master"),"yes") == 0)
	GlobalWidget_Page3->preferred_master_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page3->preferred_master_chkbx->setChecked(FALSE);

	if(strcmp(GlobalDaten->find("protocol"),"NT1") == 0) 
		GlobalWidget_Page1->protocol_combo->setCurrentItem(4);
		else
		if (strcmp(GlobalDaten->find("protocol"),"CORE") == 0) 
			GlobalWidget_Page1->protocol_combo->setCurrentItem(0);
		else
		if (strcmp(GlobalDaten->find("protocol"),"COREPLUS") == 0) 
			GlobalWidget_Page1->protocol_combo->setCurrentItem(1);
		else
		if (strcmp(GlobalDaten->find("protocol"),"LANMAN1") == 0) 
			GlobalWidget_Page1->protocol_combo->setCurrentItem(2);
		else
		if (strcmp(GlobalDaten->find("protocol"),"LANMAN2") == 0) 
			GlobalWidget_Page1->protocol_combo->setCurrentItem(3);

	if (strcmp(GlobalDaten->find("read prediction"),"yes") == 0)
	GlobalWidget_Page4->read_prediction_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page4->read_prediction_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("read raw"),"yes") == 0)
	GlobalWidget_Page4->read_raw_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page4->read_raw_chkbx->setChecked(FALSE);

	GlobalWidget_Page2->remote_announce_lineed->setText(GlobalDaten->find("remote announce"));

	GlobalWidget_Page2->remote_browse_lineed->setText(GlobalDaten->find("remote browse sync"));

	GlobalWidget_Page2->root_dir_lineed->setText(GlobalDaten->find("root directory"));

	if(strcmp(GlobalDaten->find("security"),"SERVER") == 0) 
		GlobalWidget_Page2->security_combo->setCurrentItem(0);
		else
		if (strcmp(GlobalDaten->find("security"),"SHARE") == 0) 
			GlobalWidget_Page2->security_combo->setCurrentItem(1);
		else
		if (strcmp(GlobalDaten->find("security"),"USER") == 0) 
			GlobalWidget_Page2->security_combo->setCurrentItem(2);

	GlobalWidget_Page1->server_string_lineed->setText(GlobalDaten->find("server string"));

	GlobalWidget_Page2->smb_password_lineed->setText(GlobalDaten->find("smb passwd file"));

	GlobalWidget_Page2->smbrun_lineed->setText(GlobalDaten->find("smbrun"));

	GlobalWidget_Page4->socket_adress_lineed->setText(GlobalDaten->find("socket address"));

	if (strcmp(GlobalDaten->find("status"),"yes") == 0)
	GlobalWidget_Page1->status_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page1->status_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("strip dot"),"yes") == 0)
	GlobalWidget_Page1->strip_dot_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page1->strip_dot_chkbx->setChecked(FALSE);

	GlobalWidget_Page1->syslog_slider->setValue(atoi(GlobalDaten->find("syslog")));

	if (strcmp(GlobalDaten->find("syslog only"),"yes") == 0)
	GlobalWidget_Page1->syslog_only_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page1->syslog_only_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("time server"),"yes") == 0)
	GlobalWidget_Page1->time_server_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page1->time_server_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("unix password sync"),"yes") == 0)
	GlobalWidget_Page1->unix_password_sync_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page1->unix_password_sync_chkbx->setChecked(FALSE);

	if (strcmp(GlobalDaten->find("unix realname"),"yes") == 0)
	GlobalWidget_Page1->unix_realname_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page1->unix_realname_chkbx->setChecked(FALSE);

//	GlobalWidget_Page2->valid_chars_lineed->setText(GlobalDaten->find("valid chars"));

	if (strcmp(GlobalDaten->find("wins proxy"),"yes") == 0)
	GlobalWidget_Page4->wins_proxy_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page4->wins_proxy_chkbx->setChecked(FALSE);

	GlobalWidget_Page4->wins_server_lineed->setText(GlobalDaten->find("wins server"));

	if (strcmp(GlobalDaten->find("wins support"),"yes") == 0)
	GlobalWidget_Page4->wins_support_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page4->wins_support_chkbx->setChecked(FALSE);

	GlobalWidget_Page1->workgroup_lineed->setText(GlobalDaten->find("workgroup"));

	if (strcmp(GlobalDaten->find("write raw"),"yes") == 0)
	GlobalWidget_Page4->write_raw_chkbx->setChecked(TRUE);
	else
	GlobalWidget_Page4->write_raw_chkbx->setChecked(FALSE);

/*

	if (strcmp(ServiceDaten->find(""),"yes") == 0)
	ServiceWidget_Page2->_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->_chkbx->setChecked(FALSE);

*/
}

myglobalwidget::~myglobalwidget()
{
}
