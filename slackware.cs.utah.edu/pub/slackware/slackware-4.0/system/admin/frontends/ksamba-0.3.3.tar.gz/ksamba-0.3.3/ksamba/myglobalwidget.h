/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page1.h
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#ifndef myglobalwidget_included
#define myglobalwidget_included

#include <qdialog.h>
#include <qtabdlg.h>

#include "daten2.h"

#include "myglobalwidget_page1.h"
#include "myglobalwidget_page2.h"
#include "myglobalwidget_page3.h"
#include "myglobalwidget_page4.h"

class myglobalwidget : public QTabDialog
{
    Q_OBJECT

public:
	myglobalwidget(QWidget* parent = NULL,const char* name = NULL,
		bool modal=TRUE);
  	virtual ~myglobalwidget();

	const char *getServerString();
	const char *getWorkgroup();

	void setData(QCharDict *);
	void saveData(QCharDict *);


private:
	myglobalwidget_page1 *GlobalWidget_Page1;
	myglobalwidget_page2 *GlobalWidget_Page2;
	myglobalwidget_page3 *GlobalWidget_Page3;
	myglobalwidget_page4 *GlobalWidget_Page4;
	QTabDialog *TabDialog;
	QString *retData;
};
#endif // myglobalwidget_included
