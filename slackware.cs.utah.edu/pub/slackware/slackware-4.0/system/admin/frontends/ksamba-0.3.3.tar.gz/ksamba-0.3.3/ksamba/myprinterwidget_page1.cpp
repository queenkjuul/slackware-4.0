/**********************************************************************

	--- Qt Architect generated file ---

	File: myprinterwidget_page1.cpp
	Last generated: Sat Jan 24 20:25:46 1998

 *********************************************************************/

#include "myprinterwidget_page1.h"
#include "myprinterwidget_page1.moc"

#define Inherited myprinterwidget_page1Data

myprinterwidget_page1::myprinterwidget_page1
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{

	connect(min_printspace_slider, SIGNAL(valueChanged(int)), 
		page1_lcd,SLOT(display(int)) );

}


myprinterwidget_page1::~myprinterwidget_page1()
{
}
