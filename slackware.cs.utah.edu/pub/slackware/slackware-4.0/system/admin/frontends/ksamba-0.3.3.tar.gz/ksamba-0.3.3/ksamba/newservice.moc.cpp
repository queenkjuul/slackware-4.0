/****************************************************************************
** newservice meta object code from reading C++ file 'newservice.h'
**
** Created: Tue Apr 21 06:38:25 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.18 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include "newservice.h"
#include <qmetaobj.h>


const char *newservice::className() const
{
    return "newservice";
}

QMetaObject *newservice::metaObj = 0;

void newservice::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(newserviceData::className(), "newserviceData") != 0 )
	badSuperclassWarning("newservice","newserviceData");
    if ( !newserviceData::metaObject() )
	newserviceData::initMetaObject();
    typedef void(newservice::*m1_t0)();
    typedef void(newservice::*m1_t1)();
    typedef void(newservice::*m1_t2)();
    typedef void(newservice::*m1_t3)();
    m1_t0 v1_0 = &newservice::quit_ok;
    m1_t1 v1_1 = &newservice::quit_cancel;
    m1_t2 v1_2 = &newservice::is_fileservice;
    m1_t3 v1_3 = &newservice::is_printservice;
    QMetaData *slot_tbl = new QMetaData[4];
    slot_tbl[0].name = "quit_ok()";
    slot_tbl[1].name = "quit_cancel()";
    slot_tbl[2].name = "is_fileservice()";
    slot_tbl[3].name = "is_printservice()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    metaObj = new QMetaObject( "newservice", "newserviceData",
	slot_tbl, 4,
	0, 0 );
}
