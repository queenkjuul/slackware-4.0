/**********************************************************************

	--- Qt Architect generated file ---

	File: myprinterwidget_page1.h
	Last generated: Sat Jan 24 20:25:46 1998

 *********************************************************************/

#ifndef myprinterwidget_page1_included
#define myprinterwidget_page1_included

#include "myprinterwidget_page1Data.h"

class myprinterwidget_page1 : public myprinterwidget_page1Data
{
    Q_OBJECT
	friend class myprinterwidget;
public:

    myprinterwidget_page1
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~myprinterwidget_page1();

};
#endif // myprinterwidget_page1_included
