/**********************************************************************

	--- Qt Architect generated file ---

	File: mymaindialog.cpp
	Last generated: Thu Apr 16 19:59:05 1998

 *********************************************************************/

#include "mymaindialog.h"
#include "mymaindialog.moc"

#define Inherited mymaindialogData

mymaindialog::mymaindialog
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
	MainTabListBox->setNumCols(5);
	MainTabListBox->setNumRows(2);
	MainTabListBox->setColumn(0, "Status", 20);
	MainTabListBox->setColumn(1, "Name", 40);
	MainTabListBox->setColumn(2, "Path", 60);
	MainTabListBox->setColumn(3, "Comment", 100);

}


mymaindialog::~mymaindialog()
{
}
