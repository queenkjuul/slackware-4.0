/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page3.cpp
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#include "myglobalwidget_page3.h"
#include "myglobalwidget_page3.moc"

#define Inherited myglobalwidget_page3Data

myglobalwidget_page3::myglobalwidget_page3
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
}


myglobalwidget_page3::~myglobalwidget_page3()
{
}
