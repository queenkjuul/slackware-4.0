/**********************************************************************

	--- Qt Architect generated file ---

	File: myservicewidget_page3.cpp
	Last generated: Sat Jan 31 12:27:04 1998

 *********************************************************************/

#include "myservicewidget_page3.h"
#include "myservicewidget_page3.moc"

#define Inherited myservicewidget_page3Data

myservicewidget_page3::myservicewidget_page3(QWidget* parent,const char* name)
	:Inherited( parent, name )
{
}


myservicewidget_page3::~myservicewidget_page3()
{
}
