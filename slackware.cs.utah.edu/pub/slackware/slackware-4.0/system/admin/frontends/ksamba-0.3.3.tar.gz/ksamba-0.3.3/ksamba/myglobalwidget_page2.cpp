/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page2.cpp
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#include "myglobalwidget_page2.h"
#include "myglobalwidget_page2.moc"

#define Inherited myglobalwidget_page2Data

myglobalwidget_page2::myglobalwidget_page2
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
}


myglobalwidget_page2::~myglobalwidget_page2()
{
}
