#ifndef main_included
#define main_included


#include <qpushbt.h>
#include <qfile.h>
#include <qstring.h>
#include <qstrlist.h>
#include <qfile.h>
#include <qtstream.h>
#include <kconfig.h>
#include <ktabctl.h>
#include <ktopwidget.h>
#include <qmsgbox.h>
#include <qmenubar.h>
#include <qfiledlg.h>

#include "daten2.h"
#include "mymaintable.h"
#include "myglobalwidget.h"
#include "newservice.h"

class MyWidget : public KTopLevelWidget {
Q_OBJECT
public:
        MyWidget (int argc, char **argv, QWidget *parent = 0, const char * name = 0);


private:
	QString tmp_string;                                //in ver�nder-slot
        MyMainTable *maindialog_widget;
        QFileDialog *filedialog_widget;
        KStatusBar *sb;
	int saveID, newserviceID, globalID, serviceID;
	int copyID, file1ID, file2ID, file3ID, file4ID;
	QPopupMenu *filemenu;
	QPopupMenu *parametermenu;
	KToolBar *tb;
	QString filename;
	QString tmpstring;
	KConfig *ConfigFile;


private slots:
        void globalsettings();
        void new_smbconf();
        void open_smbconf();
        void save_smbconf();
        void quit();
	void servicesettings();
	void add_service();
	void delete_service();
        void process_smbconf(QString);
	void open_file1();
	void open_file2();
	void open_file3();
	void open_file4();

signals:
	void EditService();
};
#endif // main_included
