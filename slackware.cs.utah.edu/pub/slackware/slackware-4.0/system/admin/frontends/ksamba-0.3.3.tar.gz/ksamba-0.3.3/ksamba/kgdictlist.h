#ifndef _KGDICTLIST_H
#define _KGDICTLIST_H

#include <qobject.h>
#include <qdict.h>

class KGDictIterator : public QGDictIterator {
public:
  KGDictIterator(const QGDict &d) :QGDictIterator((QGDict &)d) {}
  ~KGDictIterator() {}
         
  uint  count()   const     { return dict->count(); }
};

class KGDictList {
protected:
  int grouppos;
  KGDictIterator * iter;
  bool deleteIter;
public:
  KGDictList ( KGDictIterator * aIter, bool delIt = false );
  KGDictList ( QGDict * aDict );
  
  virtual ~KGDictList();
  
  // the next functions work like a QList.
  
  const char * next();
  const char * prev();
  const char * first();
  const char * last();
  const char * current();
};


#endif

