/**********************************************************************

	--- Qt Architect generated file ---

	File: mymaindialog.h
	Last generated: Thu Apr 16 19:59:05 1998

 *********************************************************************/

#ifndef mymaindialog_included
#define mymaindialog_included

#include "mymaindialogData.h"

class mymaindialog : public mymaindialogData
{
    Q_OBJECT

public:

    mymaindialog
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~mymaindialog();

};
#endif // mymaindialog_included
