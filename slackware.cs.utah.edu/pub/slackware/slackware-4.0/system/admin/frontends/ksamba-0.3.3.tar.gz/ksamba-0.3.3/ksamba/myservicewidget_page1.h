/**********************************************************************

	--- Qt Architect generated file ---

	File: myservicewidget_page1.h
	Last generated: Sat Jan 3 21:27:08 1998

 *********************************************************************/

#ifndef myservicewidget_page1_included
#define myservicewidget_page1_included

#include "myservicewidget_page1Data.h"

class myservicewidget_page1 : public myservicewidget_page1Data
{
	Q_OBJECT
	friend class myservicewidget;
	friend class myprinterwidget;

public:

    myservicewidget_page1
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~myservicewidget_page1();

};
#endif // myservicewidget_page1_included
