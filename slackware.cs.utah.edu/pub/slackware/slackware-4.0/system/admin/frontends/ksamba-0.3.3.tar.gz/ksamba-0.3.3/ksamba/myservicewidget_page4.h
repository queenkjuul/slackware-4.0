/**********************************************************************

	--- Qt Architect generated file ---

	File: myservicewidget_page4.h
	Last generated: Mon Feb 2 11:04:03 1998

 *********************************************************************/

#ifndef myservicewidget_page4_included
#define myservicewidget_page4_included

#include "myservicewidget_page4Data.h"

class myservicewidget_page4 : public myservicewidget_page4Data
{
    Q_OBJECT
	friend class myservicewidget;
	friend class myprinterwidget;

public:

    myservicewidget_page4
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~myservicewidget_page4();

};
#endif // myservicewidget_page4_included
