/**********************************************************************

	--- Qt Architect generated file ---

	File: myservicewidget_page2.cpp
	Last generated: Sat Jan 3 22:15:09 1998

 *********************************************************************/

#include "myservicewidget_page2.h"
#include "myservicewidget_page2.moc"

#define Inherited myservicewidget_page2Data

myservicewidget_page2::myservicewidget_page2
	(QWidget* parent,const char* name):Inherited( parent, name )
{
	connect(max_connections_slider, SIGNAL(valueChanged(int)), 
		max_connections_lcd,SLOT(display(int)) );

}


myservicewidget_page2::~myservicewidget_page2()
{
}
