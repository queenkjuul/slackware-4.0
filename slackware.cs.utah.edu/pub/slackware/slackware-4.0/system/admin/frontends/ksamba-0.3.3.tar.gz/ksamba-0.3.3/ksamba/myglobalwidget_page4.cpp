/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page4.cpp
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#include "myglobalwidget_page4.h"
#include "myglobalwidget_page4.moc"

#define Inherited myglobalwidget_page4Data

myglobalwidget_page4::myglobalwidget_page4
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
}


myglobalwidget_page4::~myglobalwidget_page4()
{
}
