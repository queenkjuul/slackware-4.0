/**********************************************************************

	--- Dlgedit generated file ---

	File: newservice.h
	Last generated: Mon Jul 21 19:13:33 1997

 *********************************************************************/

#ifndef newservice_included 
#define newservice_included

#include <stdio.h>
#include "newserviceData.h"
#include <kmsgbox.h>

class newservice : public newserviceData
{
    Q_OBJECT

public:

	newservice(QWidget* parent = NULL,const char* name = NULL);
	virtual ~newservice();
	QString newservice_name;
	QString newservice_path;
	QString newservice_type;

private:
//	KLocale klocale;
	void translate();

private slots:
	void quit_ok();
	void quit_cancel();
	void is_fileservice();
	void is_printservice();

};
#endif // newservice_included
