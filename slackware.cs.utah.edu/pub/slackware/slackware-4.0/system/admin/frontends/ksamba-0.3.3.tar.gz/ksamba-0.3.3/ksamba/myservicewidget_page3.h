/**********************************************************************

	--- Qt Architect generated file ---

	File: myservicewidget_page3.h
	Last generated: Sat Jan 31 12:27:04 1998

 *********************************************************************/

#ifndef myservicewidget_page3_included
#define myservicewidget_page3_included

#include "myservicewidget_page3Data.h"

class myservicewidget_page3 : public myservicewidget_page3Data
{
	Q_OBJECT
	friend class myservicewidget;
	friend class myprinterwidget;

public:

    myservicewidget_page3
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~myservicewidget_page3();

};
#endif // myservicewidget_page3_included
