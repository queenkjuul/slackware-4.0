/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page2.h
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#ifndef myglobalwidget_page2_included
#define myglobalwidget_page2_included

#include "myglobalwidget_page2Data.h"

class myglobalwidget_page2 : public myglobalwidget_page2Data
{
	Q_OBJECT
	friend class myglobalwidget;

public:

    myglobalwidget_page2
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~myglobalwidget_page2();

};
#endif // myglobalwidget_page2_included
