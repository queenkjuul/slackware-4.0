/**********************************************************************

	--- Dlgedit generated file ---

	File: maindialog.h
	Last generated: Mon Jul 21 17:48:34 1997

 *********************************************************************/

#ifndef maindialog_included
#define maindialog_included

#include <qstring.h>
#include <qstrlist.h>
#include <kmsgbox.h>
#include <qdict.h> 

#include "maindialogData.h"
#include "newservice.h"
//#include "allgemein.h"
#include "daten2.h"
//#include "fileserv.h"
//#include "printserv.h"
#include "myglobalwidget.h"
#include "myservicewidget.h"
#include "myprinterwidget.h"


class maindialog : public maindialogData
{
    Q_OBJECT

public:

	maindialog(QWidget* parent = NULL,const char* name = NULL);
	virtual ~maindialog();
	void set_listbox();
	void enable_buttons();

private:
	newservice *newservice_widget;
//	allgemein *allgemein_widget;
//	allgemein allgemein_widget;
//	fileserv *fileserv_widget;
//	printserv *printserv_widget;
	QString service;
	QString tmp_string;
//	bool result;
//	QString *retData;
	QCharDict *service2daten;
	void translate();
//	KLocale klocale;


public slots:
	void copy_service();
	void delete_service();
	void edit_service(int);
	void new_service();
	void info_service(int);
private slots:
	void edit_service();

	void change_available();

};
#endif // maindialog_included
