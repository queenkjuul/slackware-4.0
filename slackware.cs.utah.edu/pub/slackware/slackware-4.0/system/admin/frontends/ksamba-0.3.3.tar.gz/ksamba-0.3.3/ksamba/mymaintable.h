#ifndef mymaintable_included
#define mymaintable_included

#include "daten2.h"
#include "myservicewidget.h"
#include "myprinterwidget.h"

#include <ktablistbox.h>
#include <qstrlist.h>
#include <qpopmenu.h>
#include <qpoint.h>

#define QCharDict QDict<char>

class MyMainTable : public KTabListBox {
Q_OBJECT
public:
	MyMainTable (QWidget *parent = 0, const char * name = 0);
	virtual ~MyMainTable();

	void SetListValues(datenclass *daten);
	int getCurrentItem();

public slots:
	void edit_service_from_outside();

protected:
	virtual void resizeEvent (QResizeEvent*);
private:
	QStrList services_list;
	QCharDict *servicedaten;
	datenclass *daten;
	QPopupMenu *right_mouse_button;
	QPoint *PopupPoint;
	int save_Row, save_Column;
	

private slots:
	void edit_service(int,int);
	void ShowMenu(int,int);
	void toggleStatus();
	void save_position(int,int);
	void deleteService();
};

#endif // mymaintable_included
