/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page1.h
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#ifndef myglobalwidget_page1_included
#define myglobalwidget_page1_included

#include "myglobalwidget_page1Data.h"

class myglobalwidget_page1 : public myglobalwidget_page1Data
{
	Q_OBJECT
	friend class myglobalwidget;

public:
	myglobalwidget_page1(QWidget* parent = NULL,const char* name = NULL);
	virtual ~myglobalwidget_page1();

private slots:
	void add_ipnumber();
	void remove_ipnumber();
	void remove_ipnumber(int);

};
#endif // myglobalwidget_page1_included
