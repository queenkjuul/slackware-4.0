/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page1.cpp
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#include "myglobalwidget_page1.h"
#include "myglobalwidget_page1.moc"

#include <qstring.h>

#define Inherited myglobalwidget_page1Data

myglobalwidget_page1::myglobalwidget_page1(QWidget* parent,const char* name)
	:Inherited( parent, name )
{
	connect(add_btn, SIGNAL(pressed()), SLOT(add_ipnumber()) );
	connect(add_lineed, SIGNAL(returnPressed()), SLOT(add_ipnumber()) );
	connect(remove_btn, SIGNAL(pressed()), SLOT(remove_ipnumber()) );
	connect(ip_listbx, SIGNAL(selected(int)), SLOT(remove_ipnumber(int)) );

	connect(deadtime_slider, SIGNAL(valueChanged(int)), 
		page1_lcd,SLOT(display(int)) );

	connect(debuglevel_slider, SIGNAL(valueChanged(int)), 
		page1_lcd,SLOT(display(int)) );

	connect(keep_alive_slider, SIGNAL(valueChanged(int)), 
		page1_lcd,SLOT(display(int)) );

	connect(lpq_cache_slider, SIGNAL(valueChanged(int)), 
		page1_lcd,SLOT(display(int)) );

	connect(mangled_stack_slider, SIGNAL(valueChanged(int)), 
		page1_lcd,SLOT(display(int)) );

	connect(max_log_size_slider, SIGNAL(valueChanged(int)), 
		page1_lcd,SLOT(display(int)) );

	connect(os_level_slider, SIGNAL(valueChanged(int)), 
		page1_lcd,SLOT(display(int)) );

	connect(syslog_slider, SIGNAL(valueChanged(int)), 
		page1_lcd,SLOT(display(int)) );

}

void myglobalwidget_page1::add_ipnumber()
{
	QString *s = new QString(add_lineed->text());
	if (!s->isEmpty())
	{
		ip_listbx->inSort(add_lineed->text());
		add_lineed->setText("");
	}
	delete s;
}

void myglobalwidget_page1::remove_ipnumber()
{
	ip_listbx->removeItem(ip_listbx->currentItem());
}

void myglobalwidget_page1::remove_ipnumber(int index)
{
	ip_listbx->removeItem(index);
}

myglobalwidget_page1::~myglobalwidget_page1()
{
}
