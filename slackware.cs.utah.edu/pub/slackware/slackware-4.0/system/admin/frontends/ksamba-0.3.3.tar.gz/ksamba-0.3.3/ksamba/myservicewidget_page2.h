/**********************************************************************

	--- Qt Architect generated file ---

	File: myservicewidget_page2.h
	Last generated: Sat Jan 3 22:15:09 1998

 *********************************************************************/

#ifndef myservicewidget_page2_included
#define myservicewidget_page2_included

#include "myservicewidget_page2Data.h"

class myservicewidget_page2 : public myservicewidget_page2Data
{
	Q_OBJECT
	friend class myservicewidget;
	friend class myprinterwidget;

public:

    myservicewidget_page2
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~myservicewidget_page2();

};
#endif // myservicewidget_page2_included
