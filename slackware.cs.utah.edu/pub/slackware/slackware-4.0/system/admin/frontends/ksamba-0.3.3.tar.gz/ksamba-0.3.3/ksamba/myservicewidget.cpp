/**********************************************************************

	--- Qt Architect generated file ---

	File: myglobalwidget_page1.cpp
	Last generated: Thu Dec 25 17:14:43 1997

 *********************************************************************/

#include "myservicewidget.h"
#include "myservicewidget.moc"
#include <qstring.h>

#include <kdebug.h>

#define Inherited QTabDialog

myservicewidget::myservicewidget(QWidget* parent,const char* name, bool modal)
	:Inherited( parent, name, modal) 
{
	ServiceWidget_Page1 = new myservicewidget_page1(this);
	ServiceWidget_Page2 = new myservicewidget_page2(this);
	ServiceWidget_Page3 = new myservicewidget_page3(this);
	ServiceWidget_Page4 = new myservicewidget_page4(this);

	addTab(ServiceWidget_Page1,"Main");
	addTab(ServiceWidget_Page2,"Misc");
	addTab(ServiceWidget_Page3,"Name Mangling");
	addTab(ServiceWidget_Page4,"File/Dir Mask");

	setCaption( "Service Settings" );
	setCancelButton("Cancel");

	resize(660,500);
}


void myservicewidget::saveData(QCharDict *ServiceDaten)
{
	QString tmpstring;
	int mode;

//	printf("service name = %s\n", ServiceDaten->find("service name"));

	if (strcmp(ServiceWidget_Page1->admin_users_lineed->text(),
		   ServiceDaten->find("admin users")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->admin_users_lineed->text());
		ServiceDaten->replace("admin users",retData->data());
	}

	if (strcmp(ServiceWidget_Page1->allow_hosts_lineed->text(),
		   ServiceDaten->find("allow hosts")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->allow_hosts_lineed->text());
		ServiceDaten->replace("allow hosts",retData->data());
	}

	if (ServiceWidget_Page2->alternate_perm_chkbx->isChecked())
	ServiceDaten->replace("alternate permissions","yes");
	else
	ServiceDaten->replace("alternate permissions","no");

	if (ServiceWidget_Page1->browseable_chkbx->isChecked())
	ServiceDaten->replace("browseable","yes");
	else
	ServiceDaten->replace("browseable","no");

	if (ServiceWidget_Page3->case_sensitive_chkbx->isChecked())
	ServiceDaten->replace("case sensitive","yes");
	else
	ServiceDaten->replace("case sensitive","no");

	if (strcmp(ServiceWidget_Page1->comment_lineed->text(),
		   ServiceDaten->find("comment")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->comment_lineed->text());
		ServiceDaten->replace("comment",retData->data());
	}

	if (ServiceWidget_Page2->delete_readonly_chkbx->isChecked())
	ServiceDaten->replace("delete readonly","yes");
	else
	ServiceDaten->replace("delete readonly","no");

	if (ServiceWidget_Page2->delete_veto_files_chkbx->isChecked())
	ServiceDaten->replace("delete veto files","yes");
	else
	ServiceDaten->replace("delete veto files","no");

	if (ServiceWidget_Page1->disable_service_chkbx->isChecked())
	ServiceDaten->replace("available","no");
	else
	ServiceDaten->replace("available","yes");

	if (strcmp(ServiceWidget_Page3->default_case_combo->currentText(),
		   ServiceDaten->find("default case")) != 0)
	{
		retData = new QString(ServiceWidget_Page3->default_case_combo->currentText());
		ServiceDaten->replace("default case",retData->data());
	}

	if (strcmp(ServiceWidget_Page1->deny_hosts_lineed->text(),
		   ServiceDaten->find("deny hosts")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->deny_hosts_lineed->text());
		ServiceDaten->replace("deny hosts",retData->data());
	}

	if (strcmp(ServiceWidget_Page3->dont_descend_lineed->text(),
		   ServiceDaten->find("dont descend")) != 0)
	{
		retData = new QString(ServiceWidget_Page3->dont_descend_lineed->text());
		ServiceDaten->replace("dont descend",retData->data());
	}

	if (ServiceWidget_Page2->dos_filetime_resolution_chkbx->isChecked())
	ServiceDaten->replace("dos filetime resolution","yes");
	else
	ServiceDaten->replace("dos filetime resolution","no");

	if (ServiceWidget_Page2->dos_filetimes_chkbx->isChecked())
	ServiceDaten->replace("dos filetimes","yes");
	else
	ServiceDaten->replace("dos filetimes","no");

	if (ServiceWidget_Page2->fake_directory_create_times_chkbx->isChecked())
	ServiceDaten->replace("fake directory create times","yes");
	else
	ServiceDaten->replace("fake directory create times","no");

	if (ServiceWidget_Page2->fake_oplocks_chkbx->isChecked())
	ServiceDaten->replace("fake oplocks","yes");
	else
	ServiceDaten->replace("fake oplocks","no");

	if (ServiceWidget_Page2->follow_symlinks_chkbx->isChecked())
	ServiceDaten->replace("follow symlinks","yes");
	else
	ServiceDaten->replace("follow symlinks","no");

	if (strcmp(ServiceWidget_Page1->guest_account_lineed->text(),
		   ServiceDaten->find("guest account")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->guest_account_lineed->text());
		ServiceDaten->replace("guest account",retData->data());
	}

	if (ServiceWidget_Page1->guest_only_chkbx->isChecked())
	ServiceDaten->replace("guest only","yes");
	else
	ServiceDaten->replace("guest only","no");

	if (ServiceWidget_Page1->hide_dot_files_chkbx->isChecked())
	ServiceDaten->replace("hide dot files","yes");
	else
	ServiceDaten->replace("hide dot files","no");

	if (strcmp(ServiceWidget_Page3->hide_files_lineed->text(),
		   ServiceDaten->find("hide files")) != 0)
	{
		retData = new QString(ServiceWidget_Page3->hide_files_lineed->text());
		ServiceDaten->replace("hide files",retData->data());
	}

	if (strcmp(ServiceWidget_Page1->invalid_users_lineed->text(),
		   ServiceDaten->find("invalid users")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->invalid_users_lineed->text());
		ServiceDaten->replace("invalid users",retData->data());
	}

	if (ServiceWidget_Page2->locking_chkbx->isChecked())
	ServiceDaten->replace("locking","yes");
	else
	ServiceDaten->replace("locking","no");

	if (ServiceWidget_Page3->mangle_case_chkbx->isChecked())
	ServiceDaten->replace("mangle case","yes");
	else
	ServiceDaten->replace("mangle case","no");

	if (strcmp(ServiceWidget_Page3->mangled_map_lineed->text(),
		   ServiceDaten->find("mangled map")) != 0)
	{
		retData = new QString(ServiceWidget_Page3->mangled_map_lineed->text());
		ServiceDaten->replace("mangled map",retData->data());
	}

	if (ServiceWidget_Page3->mangled_names_chkbx->isChecked())
	ServiceDaten->replace("mangled names","yes");
	else
	ServiceDaten->replace("mangled names","no");

	if (strcmp(ServiceWidget_Page3->mangling_char_lineed->text(),
		   ServiceDaten->find("mangling char")) != 0)
	{
		retData = new QString(ServiceWidget_Page3->mangling_char_lineed->text());
		ServiceDaten->replace("mangling char",retData->data());
	}

	if (ServiceWidget_Page2->map_archive_chkbx->isChecked())
	ServiceDaten->replace("map archive","yes");
	else
	ServiceDaten->replace("map archive","no");

	if (ServiceWidget_Page2->map_hidden_chkbx->isChecked())
	ServiceDaten->replace("map hidden","yes");
	else
	ServiceDaten->replace("map hidden","no");

	if (ServiceWidget_Page2->map_system_chkbx->isChecked())
	ServiceDaten->replace("map system","yes");
	else
	ServiceDaten->replace("map system","no");

	if (ServiceWidget_Page2->max_connections_slider->value() != 
		atoi(ServiceDaten->find("max connections")) )
	{
		retData = new QString();
		retData->setNum(ServiceWidget_Page2->max_connections_slider->value());
		ServiceDaten->replace("max connections",retData->data());
	}

	if (ServiceWidget_Page1->only_user_chkbx->isChecked())
	ServiceDaten->replace("only user","yes");
	else
	ServiceDaten->replace("only user","no");

	if (ServiceWidget_Page2->oplocks_chkbx->isChecked())
	ServiceDaten->replace("oplocks","yes");
	else
	ServiceDaten->replace("oplocks","no");

	if (strcmp(ServiceWidget_Page1->path_lineed->text(),
		   ServiceDaten->find("path")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->path_lineed->text());
		ServiceDaten->replace("path",retData->data());
//		printf("path changed! path is now: %s\n",ServiceDaten->find("path"));
	}

	if (ServiceWidget_Page3->preserve_case_chkbx->isChecked())
	ServiceDaten->replace("preserve case","yes");
	else
	ServiceDaten->replace("preserve case","no");

	if (ServiceWidget_Page1->public_chkbx->isChecked())
	ServiceDaten->replace("public","yes");
	else
	ServiceDaten->replace("public","no");

	if (strcmp(ServiceWidget_Page1->read_list_lineed->text(),
		   ServiceDaten->find("read list")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->read_list_lineed->text());
		ServiceDaten->replace("read list",retData->data());
	}

	if (ServiceWidget_Page1->revalidate_chkbx->isChecked())
	ServiceDaten->replace("revalidate","yes");
	else
	ServiceDaten->replace("revalidate","no");

	if (ServiceWidget_Page2->set_directory_chkbx->isChecked())
	ServiceDaten->replace("set directory","yes");
	else
	ServiceDaten->replace("set directory","no");

	if (ServiceWidget_Page2->share_modes_chkbx->isChecked())
	ServiceDaten->replace("share modes","yes");
	else
	ServiceDaten->replace("share modes","no");

	if (ServiceWidget_Page3->short_preserve_case_chkbx->isChecked())
	ServiceDaten->replace("short preserve case","yes");
	else
	ServiceDaten->replace("short preserve case","no");

	if (ServiceWidget_Page2->strict_locking_chkbx->isChecked())
	ServiceDaten->replace("strict locking","yes");
	else
	ServiceDaten->replace("strict locking","no");

	if (ServiceWidget_Page1->sync_always_chkbx->isChecked())
	ServiceDaten->replace("sync always","yes");
	else
	ServiceDaten->replace("sync always","no");

	if (strcmp(ServiceWidget_Page1->username_lineed->text(),
		   ServiceDaten->find("username")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->username_lineed->text());
		ServiceDaten->replace("username",retData->data());
	}

	if (strcmp(ServiceWidget_Page1->valid_users_lineed->text(),
		   ServiceDaten->find("valid users")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->valid_users_lineed->text());
		ServiceDaten->replace("valid users",retData->data());
	}

	if (strcmp(ServiceWidget_Page1->volume_lineed->text(),
		   ServiceDaten->find("volume")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->volume_lineed->text());
		ServiceDaten->replace("volume",retData->data());
	}

	if (ServiceWidget_Page2->wide_links_chkbx->isChecked())
	ServiceDaten->replace("wide links","yes");
	else
	ServiceDaten->replace("wide links","no");

	if (ServiceWidget_Page1->writeable_chkbx->isChecked())
	ServiceDaten->replace("writeable","yes");
	else
	ServiceDaten->replace("writeable","no");

	if (strcmp(ServiceWidget_Page1->write_list_lineed->text(),
		   ServiceDaten->find("write list")) != 0)
	{
		retData = new QString(ServiceWidget_Page1->write_list_lineed->text());
		ServiceDaten->replace("write list",retData->data());
	}

//	ServiceWidget_Page4

	//save create mode
	mode=0;
	if (ServiceWidget_Page4->cm_oe_chkbx->isChecked()) mode=mode+1;
	if (ServiceWidget_Page4->cm_ow_chkbx->isChecked()) mode=mode+2;
	if (ServiceWidget_Page4->cm_or_chkbx->isChecked()) mode=mode+4;
	if (ServiceWidget_Page4->cm_ge_chkbx->isChecked()) mode=mode+10;
	if (ServiceWidget_Page4->cm_gw_chkbx->isChecked()) mode=mode+20;
	if (ServiceWidget_Page4->cm_gr_chkbx->isChecked()) mode=mode+40;
	if (ServiceWidget_Page4->cm_ue_chkbx->isChecked()) mode=mode+100;
	if (ServiceWidget_Page4->cm_uw_chkbx->isChecked()) mode=mode+200;
	if (ServiceWidget_Page4->cm_ur_chkbx->isChecked()) mode=mode+400;
	tmpstring=tmpstring.setNum(mode);
	tmpstring=tmpstring.rightJustify(4,'0');
	if (strcmp(tmpstring.data(), ServiceDaten->find("create mask")) != 0)
	{
		retData = new QString(tmpstring.data());
		ServiceDaten->replace("create mask",retData->data());
//		printf("new create mask= %s\n", tmpstring.data());
	}

	//save directory mode
	mode=0;
	if (ServiceWidget_Page4->dm_oe_chkbx->isChecked()) mode=mode+1;
	if (ServiceWidget_Page4->dm_ow_chkbx->isChecked()) mode=mode+2;
	if (ServiceWidget_Page4->dm_or_chkbx->isChecked()) mode=mode+4;
	if (ServiceWidget_Page4->dm_ge_chkbx->isChecked()) mode=mode+10;
	if (ServiceWidget_Page4->dm_gw_chkbx->isChecked()) mode=mode+20;
	if (ServiceWidget_Page4->dm_gr_chkbx->isChecked()) mode=mode+40;
	if (ServiceWidget_Page4->dm_ue_chkbx->isChecked()) mode=mode+100;
	if (ServiceWidget_Page4->dm_uw_chkbx->isChecked()) mode=mode+200;
	if (ServiceWidget_Page4->dm_ur_chkbx->isChecked()) mode=mode+400;
	tmpstring=tmpstring.setNum(mode);
	tmpstring=tmpstring.rightJustify(4,'0');
	if (strcmp(tmpstring.data(), ServiceDaten->find("directory mask")) != 0)
	{
		retData = new QString(tmpstring.data());
		ServiceDaten->replace("directory mask",retData->data());
//		printf("new directory mask= %s\n", tmpstring.data());
	}

	//save force create mode
	mode=0;
	if (ServiceWidget_Page4->fcm_oe_chkbx->isChecked()) mode=mode+1;
	if (ServiceWidget_Page4->fcm_ow_chkbx->isChecked()) mode=mode+2;
	if (ServiceWidget_Page4->fcm_or_chkbx->isChecked()) mode=mode+4;
	if (ServiceWidget_Page4->fcm_ge_chkbx->isChecked()) mode=mode+10;
	if (ServiceWidget_Page4->fcm_gw_chkbx->isChecked()) mode=mode+20;
	if (ServiceWidget_Page4->fcm_gr_chkbx->isChecked()) mode=mode+40;
	if (ServiceWidget_Page4->fcm_ue_chkbx->isChecked()) mode=mode+100;
	if (ServiceWidget_Page4->fcm_uw_chkbx->isChecked()) mode=mode+200;
	if (ServiceWidget_Page4->fcm_ur_chkbx->isChecked()) mode=mode+400;
	tmpstring=tmpstring.setNum(mode);
	tmpstring=tmpstring.rightJustify(4,'0');
	if (strcmp(tmpstring.data(), ServiceDaten->find("force create mode")) != 0)
	{
		retData = new QString(tmpstring.data());
		ServiceDaten->replace("force create mode",retData->data());
//		printf("new force create mode= %s\n", tmpstring.data());
	}

	//save force directory mode
	mode=0;
	if (ServiceWidget_Page4->fdm_oe_chkbx->isChecked()) mode=mode+1;
	if (ServiceWidget_Page4->fdm_ow_chkbx->isChecked()) mode=mode+2;
	if (ServiceWidget_Page4->fdm_or_chkbx->isChecked()) mode=mode+4;
	if (ServiceWidget_Page4->fdm_ge_chkbx->isChecked()) mode=mode+10;
	if (ServiceWidget_Page4->fdm_gw_chkbx->isChecked()) mode=mode+20;
	if (ServiceWidget_Page4->fdm_gr_chkbx->isChecked()) mode=mode+40;
	if (ServiceWidget_Page4->fdm_ue_chkbx->isChecked()) mode=mode+100;
	if (ServiceWidget_Page4->fdm_uw_chkbx->isChecked()) mode=mode+200;
	if (ServiceWidget_Page4->fdm_ur_chkbx->isChecked()) mode=mode+400;
	tmpstring=tmpstring.setNum(mode);
	tmpstring=tmpstring.rightJustify(4,'0');
	if (strcmp(tmpstring.data(), ServiceDaten->find("force directory mode")) != 0)
	{
		retData = new QString(tmpstring.data());
		ServiceDaten->replace("force directory mode",retData->data());
//		printf("new force directory mode= %s\n", tmpstring.data());
	}




//	KDEBUG(KDEBUG_INFO,3801,"myservicewidget: exit ok/data saved");
}
/*

	if (ServiceWidget_Page2->_chkbx->isChecked())
	ServiceDaten->replace("","yes");
	else
	ServiceDaten->replace("","no");

	if (->value() != 
		atoi(ServiceDaten->find("")) )
	{
		retData = new QString();
		retData->setNum(->value());
		ServiceDaten->replace("",retData->data());
	}


	if (strcmp(->text(),
		   ServiceDaten->find("")) != 0)
	{
		retData = new QString(->text());
		ServiceDaten->replace("",retData->data());
	}

*/


/*---------------------------------------------------------
	Set the values for the lineedits, combos....
---------------------------------------------------------*/
void myservicewidget::setData(QCharDict *ServiceDaten)
{
	QString tmpstring;

	ServiceWidget_Page1->admin_users_lineed->setText(ServiceDaten->find("admin users"));

	ServiceWidget_Page1->allow_hosts_lineed->setText(ServiceDaten->find("allow hosts"));

	if (strcmp(ServiceDaten->find("alternate permissions"),"yes") == 0)
	ServiceWidget_Page2->alternate_perm_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->alternate_perm_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("browseable"),"yes") == 0)
	ServiceWidget_Page1->browseable_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page1->browseable_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("case sensitive"),"yes") == 0)
	ServiceWidget_Page3->case_sensitive_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page3->case_sensitive_chkbx->setChecked(FALSE);

	ServiceWidget_Page1->comment_lineed->setText(ServiceDaten->find("comment"));

	if (strcmp(ServiceDaten->find("delete readonly"),"yes") == 0)
	ServiceWidget_Page2->delete_readonly_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->delete_readonly_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("delete veto files"),"yes") == 0)
	ServiceWidget_Page2->delete_veto_files_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->delete_veto_files_chkbx->setChecked(FALSE);

	ServiceWidget_Page1->deny_hosts_lineed->setText(ServiceDaten->find("deny hosts"));

	if (strcmp(ServiceDaten->find("available"),"yes") == 0)
	ServiceWidget_Page1->disable_service_chkbx->setChecked(FALSE);
	else
	ServiceWidget_Page1->disable_service_chkbx->setChecked(TRUE);

	ServiceWidget_Page3->dont_descend_lineed->setText(ServiceDaten->find("dont descend"));

	if(strcmp(ServiceDaten->find("default case"),"lower") == 0) 
		ServiceWidget_Page3->default_case_combo->setCurrentItem(0);
		else
		if (strcmp(ServiceDaten->find("default case"),"upper") == 0) 
			ServiceWidget_Page3->default_case_combo->setCurrentItem(1);

	if (strcmp(ServiceDaten->find("dos filetime resolution"),"yes") == 0)
	ServiceWidget_Page2->dos_filetime_resolution_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->dos_filetime_resolution_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("dos filetimes"),"yes") == 0)
	ServiceWidget_Page2->dos_filetimes_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->dos_filetimes_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("fake directory create times"),"yes") == 0)
	ServiceWidget_Page2->fake_directory_create_times_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->fake_directory_create_times_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("fake oplocks"),"yes") == 0)
	ServiceWidget_Page2->fake_oplocks_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->fake_oplocks_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("follow symlinks"),"yes") == 0)
	ServiceWidget_Page2->follow_symlinks_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->follow_symlinks_chkbx->setChecked(FALSE);

	ServiceWidget_Page2->force_user_lineed->setText(ServiceDaten->find("force user"));

	ServiceWidget_Page2->force_group_lineed->setText(ServiceDaten->find("force group"));

	ServiceWidget_Page1->guest_account_lineed->setText(ServiceDaten->find("guest account"));

	if (strcmp(ServiceDaten->find("guest only"),"yes") == 0)
	ServiceWidget_Page1->guest_only_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page1->guest_only_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("hide dot files"),"yes") == 0)
	ServiceWidget_Page1->hide_dot_files_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page1->hide_dot_files_chkbx->setChecked(FALSE);

	ServiceWidget_Page3->hide_files_lineed->setText(ServiceDaten->find("hide files"));

	ServiceWidget_Page1->invalid_users_lineed->setText(ServiceDaten->find("invalid users"));

	if (strcmp(ServiceDaten->find("locking"),"yes") == 0)
	ServiceWidget_Page2->locking_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->locking_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("mangle case"),"yes") == 0)
	ServiceWidget_Page3->mangle_case_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page3->mangle_case_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("mangled names"),"yes") == 0)
	ServiceWidget_Page3->mangled_names_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page3->mangled_names_chkbx->setChecked(FALSE);

	ServiceWidget_Page3->mangling_char_lineed->setText(ServiceDaten->find("mangling char"));

	ServiceWidget_Page3->mangled_map_lineed->setText(ServiceDaten->find("mangled map"));

	if (strcmp(ServiceDaten->find("map archive"),"yes") == 0)
	ServiceWidget_Page2->map_archive_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->map_archive_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("map hidden"),"yes") == 0)
	ServiceWidget_Page2->map_hidden_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->map_hidden_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("map system"),"yes") == 0)
	ServiceWidget_Page2->map_system_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->map_system_chkbx->setChecked(FALSE);

	ServiceWidget_Page2->max_connections_slider->
		setValue(atoi(ServiceDaten->find("max connections")));

	if (strcmp(ServiceDaten->find("only user"),"yes") == 0)
	ServiceWidget_Page1->only_user_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page1->only_user_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("oplocks"),"yes") == 0)
	ServiceWidget_Page2->oplocks_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->oplocks_chkbx->setChecked(FALSE);

	ServiceWidget_Page1->path_lineed->setText(ServiceDaten->find("path"));

	ServiceWidget_Page2->postexec_lineed->setText(ServiceDaten->find("postexec"));

	ServiceWidget_Page2->preexec_lineed->setText(ServiceDaten->find("preexec"));

	if (strcmp(ServiceDaten->find("preserve case"),"yes") == 0)
	ServiceWidget_Page3->preserve_case_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page3->preserve_case_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("public"),"yes") == 0)
	ServiceWidget_Page1->public_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page1->public_chkbx->setChecked(FALSE);

	ServiceWidget_Page1->read_list_lineed->setText(ServiceDaten->find("read list"));

	if (strcmp(ServiceDaten->find("revalidate"),"yes") == 0)
	ServiceWidget_Page1->revalidate_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page1->revalidate_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("set directory"),"yes") == 0)
	ServiceWidget_Page2->set_directory_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->set_directory_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("share modes"),"yes") == 0)
	ServiceWidget_Page2->share_modes_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->share_modes_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("short preserve case"),"yes") == 0)
	ServiceWidget_Page3->short_preserve_case_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page3->short_preserve_case_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("strict locking"),"yes") == 0)
	ServiceWidget_Page2->strict_locking_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->strict_locking_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("sync always"),"yes") == 0)
	ServiceWidget_Page1->sync_always_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page1->sync_always_chkbx->setChecked(FALSE);

	ServiceWidget_Page1->username_lineed->setText(ServiceDaten->find("username"));

	ServiceWidget_Page2->valid_chars_lineed->setText(ServiceDaten->find("valid chars"));

	ServiceWidget_Page1->valid_users_lineed->setText(ServiceDaten->find("valid users"));

	ServiceWidget_Page1->volume_lineed->setText(ServiceDaten->find("volume"));

	if (strcmp(ServiceDaten->find("wide links"),"yes") == 0)
	ServiceWidget_Page2->wide_links_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->wide_links_chkbx->setChecked(FALSE);

	if (strcmp(ServiceDaten->find("writeable"),"yes") == 0)
	ServiceWidget_Page1->writeable_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page1->writeable_chkbx->setChecked(FALSE);

	ServiceWidget_Page1->write_list_lineed->setText(ServiceDaten->find("write list"));

//	ServiceWidget_Page4
// 	printf("cm %d\n",atoi(ServiceDaten->find("create mask")));
	tmpstring = ServiceDaten->find("create mask");
	tmpstring = tmpstring.mid(1,1);
	
	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->cm_ur_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->cm_ur_chkbx->setChecked(FALSE);
  	
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->cm_uw_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->cm_uw_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->cm_ue_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->cm_ue_chkbx->setChecked(FALSE);

	tmpstring = ServiceDaten->find("create mask");
	tmpstring = tmpstring.mid(2,1);

	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->cm_gr_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->cm_gr_chkbx->setChecked(FALSE);
  		
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->cm_gw_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->cm_gw_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->cm_ge_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->cm_ge_chkbx->setChecked(FALSE);

  	tmpstring = ServiceDaten->find("create mask");
	tmpstring = tmpstring.mid(3,1);
	
	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->cm_or_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->cm_or_chkbx->setChecked(FALSE);
  		
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->cm_ow_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->cm_ow_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->cm_oe_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->cm_oe_chkbx->setChecked(FALSE);
	


	tmpstring = ServiceDaten->find("directory mask");
	tmpstring = tmpstring.mid(1,1);
	
	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->dm_ur_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->dm_ur_chkbx->setChecked(FALSE);
  	
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->dm_uw_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->dm_uw_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->dm_ue_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->dm_ue_chkbx->setChecked(FALSE);

	tmpstring = ServiceDaten->find("directory mask");
	tmpstring = tmpstring.mid(2,1);

	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->dm_gr_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->dm_gr_chkbx->setChecked(FALSE);
  		
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->dm_gw_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->dm_gw_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->dm_ge_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->dm_ge_chkbx->setChecked(FALSE);

  	tmpstring = ServiceDaten->find("directory mask");
	tmpstring = tmpstring.mid(3,1);
	
	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->dm_or_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->dm_or_chkbx->setChecked(FALSE);
  		
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->dm_ow_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->dm_ow_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->dm_oe_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->dm_oe_chkbx->setChecked(FALSE);
	

	tmpstring = ServiceDaten->find("force create mode");
	tmpstring = tmpstring.mid(1,1);
	
	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->fcm_ur_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fcm_ur_chkbx->setChecked(FALSE);
  	
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->fcm_uw_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fcm_uw_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->fcm_ue_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fcm_ue_chkbx->setChecked(FALSE);

	tmpstring = ServiceDaten->find("force create mode");
	tmpstring = tmpstring.mid(2,1);

	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->fcm_gr_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fcm_gr_chkbx->setChecked(FALSE);
  		
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->fcm_gw_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fcm_gw_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->fcm_ge_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fcm_ge_chkbx->setChecked(FALSE);

  	tmpstring = ServiceDaten->find("force create mode");
	tmpstring = tmpstring.mid(3,1);
	
	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->fcm_or_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fcm_or_chkbx->setChecked(FALSE);
  		
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->fcm_ow_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fcm_ow_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->fcm_oe_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fcm_oe_chkbx->setChecked(FALSE);
	


	tmpstring = ServiceDaten->find("force directory mode");
	tmpstring = tmpstring.mid(1,1);
	
	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->fdm_ur_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fdm_ur_chkbx->setChecked(FALSE);
  	
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->fdm_uw_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fdm_uw_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->fdm_ue_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fdm_ue_chkbx->setChecked(FALSE);

	tmpstring = ServiceDaten->find("force directory mode");
	tmpstring = tmpstring.mid(2,1);

	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->fdm_gr_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fdm_gr_chkbx->setChecked(FALSE);
  		
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->fdm_gw_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fdm_gw_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->fdm_ge_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fdm_ge_chkbx->setChecked(FALSE);

  	tmpstring = ServiceDaten->find("force directory mode");
	tmpstring = tmpstring.mid(3,1);
	
	if ((tmpstring.toInt() & 4) == 4)
	ServiceWidget_Page4->fdm_or_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fdm_or_chkbx->setChecked(FALSE);
  		
	if ((tmpstring.toInt() & 2) == 2)
	ServiceWidget_Page4->fdm_ow_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fdm_ow_chkbx->setChecked(FALSE);

	if ((tmpstring.toInt() & 1) == 1)
	ServiceWidget_Page4->fdm_oe_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page4->fdm_oe_chkbx->setChecked(FALSE);


}
/*

	_lineed->setText(ServiceDaten->find(""));

	if(strcmp(GlobalDaten->find("announce as"),"NT") == 0) 
		GlobalWidget_Page3->announce_combo->setCurrentItem(0);
		else
		if (strcmp(GlobalDaten->find("announce as"),"Win95") == 0) 
			GlobalWidget_Page3->announce_combo->setCurrentItem(1);
		else
		if (strcmp(GlobalDaten->find("announce as"),"WfW") == 0) 
			GlobalWidget_Page3->announce_combo->setCurrentItem(2);

	if (strcmp(ServiceDaten->find(""),"yes") == 0)
	ServiceWidget_Page2->_chkbx->setChecked(TRUE);
	else
	ServiceWidget_Page2->_chkbx->setChecked(FALSE);

*/

myservicewidget::~myservicewidget()
{
}
