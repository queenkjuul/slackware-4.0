/**********************************************************************

	--- Dlgedit generated file ---

	File: maindialog.cpp
	Last generated: Mon Jul 21 17:48:34 1997

 *********************************************************************/

#include "maindialog.h"
#include "maindialog.moc"
//#include "fileservqtab.h"


#include <klocale.h>
#include <kapp.h>

extern datenclass *daten;


#define Inherited maindialogData

maindialog::maindialog(QWidget* parent,const char* name):Inherited( parent, name )
{
	translate();
	connect ( new_btn , SIGNAL(clicked()) , SLOT(new_service()) );
	connect ( copy_btn , SIGNAL(clicked()) , SLOT(copy_service()) );
	connect ( edit_btn , SIGNAL(clicked()) , SLOT(edit_service()) );
	connect ( delete_btn , SIGNAL(clicked()) , SLOT(delete_service()) );
	connect ( notavail_box , SIGNAL(clicked()) , SLOT(change_available()) );
	connect ( services_listbox, SIGNAL(selected(int)), SLOT(edit_service(int)) );
	connect ( services_listbox, SIGNAL(highlighted(int)), SLOT(info_service(int)) );
	copy_btn->setEnabled(false);
	delete_btn->setEnabled(false);
	edit_btn->setEnabled(false);
	new_btn->setEnabled(false);
	notavail_box->setEnabled(false);
	fileserv_box->setEnabled(false);
	printserv_box->setEnabled(false);
}

/*---------------------------------------------------------
	enable or disable the service
---------------------------------------------------------*/
void maindialog::change_available()
{
	service2daten = daten->getServiceDataPointer(services_listbox->currentItem());

	if (notavail_box->isChecked())
	service2daten->replace("available","no");
	else
	service2daten->replace("available","yes");
}

void maindialog::copy_service()
{
		KMsgBox::message(this,"Pong",
	 	"Not yet implemented!\n"
	 	"The next release will fix this bug :)",1);
}

void maindialog::delete_service()
{
	daten->deleteService( daten->services_list.at() );
	set_listbox();
}

/*---------------------------------------------------------
	check type of service and call the right editwindow
---------------------------------------------------------*/
void maindialog::edit_service(int index)
{
// service == name of the service

	QString tmpstr;
	service = daten->services_list.at(index);
	service2daten = daten->filesrvlist.at(index);



	tmpstr = service2daten->find("printable");
//	printf("printable = %s \n",tmpstr.data());
//	// FIX ME !!!!!!!
//	if (tmpstr == NULL) tmpstr = "no";
//	//

// Check type of service

// Global Section

	if ( service.contains("global") == true ) 
	{
		myglobalwidget GlobalWidget; 
		GlobalWidget.setData(daten->getGlobalDataPointer());
		if ( GlobalWidget.exec() ) 
		{
			GlobalWidget.saveData(daten->getGlobalDataPointer());
		}
	}

// Service is fileservice (not printable and servicename is not printers)

	else if ( (strcasecmp(tmpstr,"yes") != 0) && 
		service.contains("printers") == false)
	{
		myservicewidget ServiceWidget; 
		ServiceWidget.setData(daten->getServiceDataPointer(index));
		if ( ServiceWidget.exec() ) 
		{
			ServiceWidget.saveData(daten->getServiceDataPointer(index));
		}
		info_service(index);
	}

// Service is printservice (servicename contains printers or is printable) 

	else if ( service.contains("printers") == true || 
		(strcasecmp(tmpstr,"yes") == 0) )
	{
		myprinterwidget PrinterWidget; 
		PrinterWidget.setData(daten->getServiceDataPointer(index));
		if ( PrinterWidget.exec() ) 
		{
			PrinterWidget.saveData(daten->getServiceDataPointer(index));
		}
		info_service(index);
	}
}

void maindialog::edit_service()
{
	const index = daten->services_list.at();
	edit_service(index);
}

void maindialog::enable_buttons()
{
	copy_btn->setEnabled(true);
	delete_btn->setEnabled(true);
	edit_btn->setEnabled(true);
	new_btn->setEnabled(true);
//	notavail_box->setEnabled(true);

}


void maindialog::info_service(int index) 
{
	daten->services_list.at(index);			//f�r edit doppelklick
	service2daten = daten->getServiceDataPointer(index);

	if (strcmp(service2daten->find("service name"),"global") == 0 )
	{
		notavail_box->setChecked(false);
		notavail_box->setEnabled(false);
		fileserv_box->setChecked(false);
		printserv_box->setChecked(false);
	}
	else
	{
		notavail_box->setEnabled(true);

		if (strcmp(service2daten->find("available"),"yes") == 0 )
		notavail_box->setChecked(FALSE);
		else
		notavail_box->setChecked(TRUE);

		if (strcmp(service2daten->find("printable"),"yes") == 0 )
		{
			printserv_box->setChecked(true);
			fileserv_box->setChecked(false);
		}
		else
		{
			printserv_box->setChecked(false);
			fileserv_box->setChecked(true);
		}

	}
}
void maindialog::new_service()
{
	newservice_widget = new newservice;
	if (newservice_widget->exec() == true )
	{
		daten->newService(newservice_widget->newservice_name, 
					 newservice_widget->newservice_type,
					 newservice_widget->newservice_path);
		set_listbox();
	}
}

void maindialog::set_listbox()
{
	if (services_listbox->count() > 0) 
	{
		services_listbox->clear();
	}
	services_listbox->insertStrList(&daten->services_list);
	services_listbox->setCurrentItem(0);
}

void maindialog::translate()
{
	new_btn->setText( klocale->translate("New service...") );
	copy_btn->setText( klocale->translate("Copy service...") );
	edit_btn->setText( klocale->translate("Edit service...") );
	delete_btn->setText( klocale->translate("Delete service...") );
	service_label->setText( klocale->translate("Services") );
	service_btngrp->setTitle( klocale->translate("Service is") );
	notavail_box->setText( klocale->translate("disabled") );
	fileserv_box->setText( klocale->translate("fileservice") );
	printserv_box->setText( klocale->translate("printservice") );
}

maindialog::~maindialog()
{
}
