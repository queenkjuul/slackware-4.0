/**********************************************************************

	--- Qt Architect generated file ---

	File: newPrimary.h
	Last generated: Fri Nov 28 15:28:34 1997

 *********************************************************************/

#ifndef newPrimary_included
#define newPrimary_included

#include "newPrimaryData.h"
#include "bind.h"

class newPrimary : public newPrimaryData
{
    Q_OBJECT

public:

    newPrimary
    (
    	QList<primaryDomain> *pl,
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~newPrimary();
protected slots:
    void OK_Click();
    void Cancel_Click();
    void domain_change(const char*);
private:
    QList<primaryDomain> *primaryL;

};
#endif // newPrimary_included
