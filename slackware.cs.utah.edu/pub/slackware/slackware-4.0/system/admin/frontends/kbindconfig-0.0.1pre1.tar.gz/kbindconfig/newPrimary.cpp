/**********************************************************************

	--- Qt Architect generated file ---

	File: newPrimary.cpp
	Last generated: Fri Nov 28 15:28:34 1997

 *********************************************************************/

#include "newPrimary.h"
#include "newPrimary.moc"

#define Inherited newPrimaryData

newPrimary::newPrimary
(
	QList<primaryDomain> *pl,
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
	setCaption( "New Primary Domain" );
	primaryL = pl;
}


newPrimary::~newPrimary()
{
}

void newPrimary::OK_Click()
{
   if ( (strlen(Domain_Edit->text()) > 0) &&
   	(strlen(FN_Edit->text()) > 0) &&
   	(strlen(RP_Edit->text()) > 0) ) {
		QString RP;
		int i;
		records * r;
		
		r = new records();
		r->type = TYPE_NS;
		r->owner = " ";
		r->st1 = NS_Edit->text();
										
		RP = RP_Edit->text();
		i = RP.find("@");
		if (i>0) {
			RP.replace(i,1,".");
		}
		primaryDomain *pd;
		pd = new primaryDomain(Domain_Edit->text(),FN_Edit->text());
		pd->rp = RP;
		pd->refresh = atoi(Refresh_Edit->text());
		pd->retry = atoi(Retry_Edit->text());
		pd->expire = atoi(Expire_Edit->text());
		pd->TTL = atoi(TTL_Edit->text());
	        pd->data = new (QList<records>);
		pd->data->setAutoDelete(TRUE);
		pd->data->append(r);
		primaryL->append(pd);	
		close();
	} else {
		debug("Not all Fields filled out !!!!");
	}
}

void newPrimary::Cancel_Click()
{
	debug("Cancel Clicked !");
	close();
}

void newPrimary::domain_change(const char * name)
{
	QString st;
	st.sprintf("db.%s",name);
 	FN_Edit->setText(st);

}


