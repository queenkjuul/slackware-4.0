/**********************************************************************

	--- Qt Architect generated file ---

	File: secondary.h
	Last generated: Tue Nov 25 21:22:23 1997

 *********************************************************************/

#ifndef secondary_included
#define secondary_included
#include "bind.h"
#include "secondaryData.h"

class secondary : public secondaryData
{
    Q_OBJECT

public:

    secondary
    (
    	secondaryDomain *sl,
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~secondary();
private:
    secondaryDomain *sd;

private slots:
    void addclick();
    void removeclick();
    void secondary_exit();
    void secondary_cancel();
};
#endif // secondary_included
