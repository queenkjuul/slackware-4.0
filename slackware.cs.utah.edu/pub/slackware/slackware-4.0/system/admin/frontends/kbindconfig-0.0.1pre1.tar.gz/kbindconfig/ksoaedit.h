/**********************************************************************

	--- Qt Architect generated file ---

	File: ksoaedit.h
	Last generated: Tue Nov 11 19:16:37 1997

 *********************************************************************/

#ifndef ksoaedit_included
#define ksoaedit_included

#include "ksoaeditData.h"
#include "bind.h"

class ksoaedit : public ksoaeditData
{
    Q_OBJECT

public:

    ksoaedit
    (
	primaryDomain *pl,
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~ksoaedit();
    
private slots:
  void changerecord();
  void addrecord();
  void combochange(const char * txt);
  void listclick(int index,int col);
private:
  primaryDomain *pd;
  void incser();
  int listsel;
};
#endif // ksoaedit_included
