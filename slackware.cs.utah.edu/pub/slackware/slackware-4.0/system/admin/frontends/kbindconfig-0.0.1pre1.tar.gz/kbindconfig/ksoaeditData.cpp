#include "ksoaedit.h"
#include "ksoaeditData.h"
#include "ksoaeditData.moc"

#define Inherited QDialog

#include <qlabel.h>
#include "ktablistbox.h"
#include <qpushbt.h>
#include <qlined.h>
#include <qcombo.h>



ksoaeditData::ksoaeditData
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name, TRUE, 0 )
{

	QFont font( "helvetica", 10, 50, 0 );
	font.setStyleHint( (QFont::StyleHint)0 );
	font.setCharSet( (QFont::CharSet)0 );


	listall = new KTabListBox( this, "User_1",5,0);
	listall->setGeometry( 20, 160, 615, 200 );
        listall->setSeparator('\n');
        listall->setColumn(0,"Owner",100);
        listall->setColumn(1,"Type",50);
        listall->setColumn(2,"Val1",30);
        listall->setColumn(3,"String1",250);
        listall->setColumn(4,"String2",100);
        listall->clearTableFlags(Tbl_hScrollBar);
        listall->clearTableFlags(Tbl_autoHScrollBar);
        listall->setTableFlags(Tbl_autoVScrollBar);        

	QLabel* dlgedit_Label_1;
	dlgedit_Label_1 = new QLabel( this, "Label_1" );
	dlgedit_Label_1->setGeometry( 10, 10, 60, 20 );
	dlgedit_Label_1->setFont( font );
	dlgedit_Label_1->setText( "Domain : " );
	dlgedit_Label_1->setAlignment( 289 );
	dlgedit_Label_1->setMargin( -1 );

	domainedit = new QLineEdit( this, "LineEdit_2" );
	domainedit->setGeometry( 110, 10, 120, 20 );
	domainedit->setFont( font );
	domainedit->setText( "" );
	domainedit->setMaxLength( 255 );
	domainedit->setEchoMode( QLineEdit::Normal );
	domainedit->setFrame( TRUE );

	rpedit = new QLineEdit( this, "LineEdit_3" );
	rpedit->setGeometry( 110, 30, 120, 20 );
	rpedit->setFont( font );
	rpedit->setText( "" );
	rpedit->setMaxLength( 255 );
	rpedit->setEchoMode( QLineEdit::Normal );
	rpedit->setFrame( TRUE );

	QLabel* dlgedit_Label_2;
	dlgedit_Label_2 = new QLabel( this, "Label_2" );
	dlgedit_Label_2->setGeometry( 10, 30, 90, 20 );
	dlgedit_Label_2->setFont( font );
	dlgedit_Label_2->setText( "Responsible Person :" );
	dlgedit_Label_2->setAlignment( 289 );
	dlgedit_Label_2->setMargin( -1 );

	QLabel* dlgedit_Label_3;
	dlgedit_Label_3 = new QLabel( this, "Label_3" );
	dlgedit_Label_3->setGeometry( 10, 50, 80, 20 );
	dlgedit_Label_3->setFont( font );
	dlgedit_Label_3->setText( "Serial :" );
	dlgedit_Label_3->setAlignment( 289 );
	dlgedit_Label_3->setMargin( -1 );

	serialedit = new QLineEdit( this, "LineEdit_4" );
	serialedit->setGeometry( 110, 50, 120, 20 );
	serialedit->setText( "" );
	serialedit->setFont(font);
	serialedit->setMaxLength( 255 );
	serialedit->setEchoMode( QLineEdit::Normal );
	serialedit->setFrame( TRUE );

	QLabel* dlgedit_Label_4;
	dlgedit_Label_4 = new QLabel( this, "Label_4" );
	dlgedit_Label_4->setGeometry( 10, 70, 100, 20 );
	dlgedit_Label_4->setFont( font );
	dlgedit_Label_4->setText( "Refresh :" );
	dlgedit_Label_4->setAlignment( 289 );
	dlgedit_Label_4->setMargin( -1 );

	refreshedit = new QLineEdit( this, "LineEdit_5" );
	refreshedit->setGeometry( 110, 70, 120, 20 );
	refreshedit->setFont( font );
	refreshedit->setText( "" );
	refreshedit->setMaxLength( 255 );
	refreshedit->setEchoMode( QLineEdit::Normal );
	refreshedit->setFrame( TRUE );

	QLabel* dlgedit_Label_5;
	dlgedit_Label_5 = new QLabel( this, "Label_5" );
	dlgedit_Label_5->setGeometry( 10, 90, 100, 20 );
	dlgedit_Label_5->setFont( font );
	dlgedit_Label_5->setText( "Retry :" );
	dlgedit_Label_5->setAlignment( 289 );
	dlgedit_Label_5->setMargin( -1 );

	retryedit = new QLineEdit( this, "LineEdit_6" );
	retryedit->setGeometry( 110, 90, 120, 20 );
	retryedit->setFont( font );
	retryedit->setText( "" );
	retryedit->setMaxLength( 255 );
	retryedit->setEchoMode( QLineEdit::Normal );
	retryedit->setFrame( TRUE );

	QLabel* dlgedit_Label_6;
	dlgedit_Label_6 = new QLabel( this, "Label_6" );
	dlgedit_Label_6->setGeometry( 10, 110, 100, 20 );
	dlgedit_Label_6->setFont( font );
	dlgedit_Label_6->setText( "Expire :" );
	dlgedit_Label_6->setAlignment( 289 );
	dlgedit_Label_6->setMargin( -1 );

	expireedit = new QLineEdit( this, "LineEdit_7" );
	expireedit->setGeometry( 110, 110, 120, 20 );
	expireedit->setText( "" );
	expireedit->setFont(font);
	expireedit->setMaxLength( 255 );
	expireedit->setEchoMode( QLineEdit::Normal );
	expireedit->setFrame( TRUE );

	QLabel* dlgedit_Label_7;
	dlgedit_Label_7 = new QLabel( this, "Label_7" );
	dlgedit_Label_7->setGeometry( 10, 130, 100, 20 );
	dlgedit_Label_7->setFont( font );
	dlgedit_Label_7->setText( "Time to live :" );
	dlgedit_Label_7->setAlignment( 289 );
	dlgedit_Label_7->setMargin( -1 );

	ttledit = new QLineEdit( this, "LineEdit_8" );
	ttledit->setGeometry( 110, 130, 120, 20 );
	ttledit->setMinimumSize( 10, 10 );
	ttledit->setMaximumSize( 32767, 32767 );
	ttledit->setFont( font );
	ttledit->setText( "" );
	ttledit->setMaxLength(255 );
	ttledit->setEchoMode( QLineEdit::Normal );
	ttledit->setFrame( TRUE );

        owneredit1 = new QLineEdit( this, "owneredit1" );
        owneredit1->setGeometry( 350, 30, 130, 20 );
        owneredit1->setText( "" );
        owneredit1->setMaxLength( 255 );
        owneredit1->setEchoMode( QLineEdit::Normal );
        owneredit1->setFrame( TRUE );     

        ComboType = new QComboBox(FALSE, this, "ComboType_1" );
        ComboType->setGeometry( 500, 30, 130, 20 );
        ComboType->setSizeLimit( 10 );
        ComboType->setAutoResize( FALSE );    

        MXedit = new QLineEdit( this, "MXedit" );
        MXedit->setGeometry( 350, 50, 130, 20 );
        MXedit->setText( "" );
        MXedit->setMaxLength( 255 );
        MXedit->setEchoMode( QLineEdit::Normal );
        MXedit->setFrame( TRUE );        

        str2edit = new QLineEdit( this, "str1edit" );
        str2edit->setGeometry( 350, 90, 130, 20 );
        str2edit->setMinimumSize( 10, 10 );
        str2edit->setMaximumSize( 32767, 32767 );
        str2edit->setText( "" );
        str2edit->setMaxLength( 32767 );
        str2edit->setEchoMode( QLineEdit::Normal );
        str2edit->setFrame( TRUE );     


	str1edit = new QLineEdit( this, "str2edit" );
        str1edit->setGeometry( 350, 70, 280, 20 );
        str1edit->setMinimumSize( 10, 10 );
        str1edit->setMaximumSize( 32767, 32767 );
        str1edit->setText( "" );
        str1edit->setMaxLength( 32767 );
        str1edit->setEchoMode( QLineEdit::Normal );
        str1edit->setFrame( TRUE );       

        QLabel* dlgedit_Label_c;
        dlgedit_Label_c = new QLabel( this, "Label_c" );
        dlgedit_Label_c->setGeometry( 350, 10, 80, 20 );
        dlgedit_Label_c->setMinimumSize( 10, 10 );
        dlgedit_Label_c->setMaximumSize( 32767, 32767 );
        dlgedit_Label_c->setFont( font );
        dlgedit_Label_c->setText( "Add / Change :" );
        dlgedit_Label_c->setAlignment( 289 );
        dlgedit_Label_c->setMargin( -1 );     


        QLabel* dlgedit_Label_9;
        dlgedit_Label_9 = new QLabel( this, "Label_9" );
        dlgedit_Label_9->setGeometry( 270, 30, 80, 20 );
        dlgedit_Label_9->setMinimumSize( 10, 10 );
        dlgedit_Label_9->setMaximumSize( 32767, 32767 );
        dlgedit_Label_9->setFont( font );
        dlgedit_Label_9->setText( "Owner :" );
        dlgedit_Label_9->setAlignment( 289 );
        dlgedit_Label_9->setMargin( -1 );         

        MXlabel = new QLabel( this, "MXlabel" );
        MXlabel->setGeometry( 270, 50, 80, 20 );
        MXlabel->setMinimumSize( 10, 10 );
        MXlabel->setMaximumSize( 32767, 32767 );
        MXlabel->setFont( font );
        MXlabel->setText( "MX Value :" );
        MXlabel->setAlignment( 289 );
        MXlabel->setMargin( -1 );      

        str1label = new QLabel( this, "Label_a" );
        str1label->setGeometry( 270, 70, 80, 20 );
        str1label->setMinimumSize( 10, 10 );
        str1label->setMaximumSize( 32767, 32767 );
        str1label->setFont( font );
        str1label->setText( "Text:" );
        str1label->setAlignment( 289 );
        str1label->setMargin( -1 );       

        str2label = new QLabel( this, "Label_b" );
        str2label->setGeometry( 270, 90, 80, 20 );
        str2label->setMinimumSize( 10, 10 );
        str2label->setMaximumSize( 32767, 32767 );
        str2label->setFont( font );
        str2label->setText( "Text 2:" );
        str2label->setAlignment( 289 );
        str2label->setMargin( -1 );            

	ComboType->insertItem( "MX" );
	ComboType->insertItem( "CNAME" );
	ComboType->insertItem( "A" );
	ComboType->insertItem( "PTR" );
	ComboType->insertItem( "HINFO" );
	ComboType->insertItem( "TXT" );
	ComboType->insertItem( "NS" );

        addButton = new QPushButton( this, "PushButton_1" );
        addButton->setGeometry( 270, 120, 100, 30 );
        addButton->setMinimumSize( 10, 10 );
        addButton->setMaximumSize( 32767, 32767 );
        addButton->setText( "Add" );
        addButton->setAutoRepeat( FALSE );
        addButton->setAutoResize( FALSE );

        changeButton = new QPushButton( this, "PushButton_2" );
        changeButton->setGeometry( 390, 120, 100, 30 );
        changeButton->setMinimumSize( 10, 10 );
        changeButton->setMaximumSize( 32767, 32767 );
        changeButton->setText( "Change" );
        changeButton->setAutoRepeat( FALSE );
        changeButton->setAutoResize( FALSE );     


	connect( ComboType, SIGNAL(activated(const char *)),SLOT(combochange(const char *)));
	str2edit->setEnabled(false);
	str1label->setText("Mail Server :");

	resize( 650,370 );
}


ksoaeditData::~ksoaeditData()
{
}

void ksoaeditData::combochange(const char * txt)
{
}

