/**********************************************************************

	--- Qt Architect generated file ---

	File: secondary.cpp
	Last generated: Tue Nov 25 21:22:23 1997

 *********************************************************************/

#include "secondary.h"
#include "secondary.moc"
#define Inherited secondaryData

secondary::secondary
(
	secondaryDomain *sl,
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
	setCaption( sl->domain );
	connect(add_Button,SIGNAL(clicked()),SLOT(addclick()));
	connect(delete_Button,SIGNAL(clicked()),SLOT(removeclick()));
	connect(OK_Button,SIGNAL(clicked()),SLOT(secondary_exit()));
	connect(Cancel_Button,SIGNAL(clicked()),SLOT(secondary_cancel()));
	IP_list->insertStrList(sl->ip);
	sd=sl;
	file_edit->setText(sl->file);	
}


secondary::~secondary()
{
}

void secondary::addclick()
{
	IP_list->insertItem(IP_edit->text());
}

void secondary::removeclick()
{
	int n;
	n=IP_list->currentItem();
	IP_list->removeItem(n);
	
}

void secondary::secondary_exit()
{
	int n,m;
	sd->ip->setAutoDelete(TRUE);
	while (sd->ip->removeFirst());
	n=IP_list->count();
	for (m=0;m<n;m++) {
		sd->ip->append(IP_list->text(m));
	}	
	sd->file=file_edit->text();	
 	close();
}

void secondary::secondary_cancel()
{
   close();
}


