#include <kapp.h>
#include <qapp.h>
#include "bind.h"

main(int argc, char **argv)
{

  debug("setup KApp");
  // set main application
  KApplication *bind = new KApplication(argc, argv,"KBindConfig");
  bind->setFont(QFont("Helvetica",12),true);

  // toplevel control

  KBindWidget *w = new KBindWidget();
  bind->setMainWidget(w);
  w->setCaption("KBindConfig");
  w->show();
  return bind->exec();
}
                                     
