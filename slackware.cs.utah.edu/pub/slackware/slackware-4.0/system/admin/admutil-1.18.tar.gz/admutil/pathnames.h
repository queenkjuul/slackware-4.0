/*
 *	@(#)pathnames.h	5.3 (Berkeley) 5/9/89
 *
 * Heavily modified by poe@daimi.aau.dk for Linux
 */

#ifndef __STDC__
# error "we need an ANSI compiler"
#endif

#ifndef NO_PATHS_H
#include <paths.h>
#endif

#ifndef LOGDIR
# define LOGDIR "/var/log"
#endif
#ifndef SBINDIR
# define SBINDIR "/sbin"
#endif

#define _PATH_SINGLE	"/etc/singleboot"
#define _PATH_MTAB	"/etc/mtab"
#define _PATH_UMOUNT	SBINDIR "/umount"
#define UMOUNT_ARGS	"umount", "-a"
#define SWAPOFF_ARGS	"swapoff", "-a"

#if 0
/* These are not used in sources */
#define UT_NAMESIZE     8
#define TTYTYPES        "/etc/ttytype"
#define SECURETTY       "/etc/securetty"
#define	_PATH_HUSHLOGIN	".hushlogin"
#define	_PATH_MOTDFILE	"/etc/motd"
#define _PATH_INITTAB	"/etc/inittab"
#define _PATH_RC	"/etc/rc"
#define _PATH_REBOOT	"/usr/bin/reboot"
#define _PATH_SECURE	"/etc/securesingle"
#endif  /* 0 */

/* These should come from /usr/include/paths.h */
#ifndef _PATH_BSHELL
#define _PATH_BSHELL    "/bin/sh"
#endif
#ifndef _PATH_CSHELL
#define _PATH_CSHELL    "/bin/csh"
#endif
#ifndef _PATH_TTY
#define _PATH_TTY       "/dev/tty"
#endif
#ifndef _PATH_UTMP
#define _PATH_UTMP      "/var/run/utmp"
#endif
#ifndef _PATH_WTMP
#define _PATH_WTMP      LOGDIR "/wtmp"
#endif
#ifndef _PATH_DEFPATH
#define	_PATH_DEFPATH	        "/usr/local/bin:/bin:/usr/bin:."
#endif
#ifndef _PATH_DEFPATH_ROOT
#define	_PATH_DEFPATH_ROOT	"/bin:/usr/bin:" SBINDIR
#endif
#ifndef _PATH_LASTLOG
#define	_PATH_LASTLOG	LOGDIR "/lastlog"
#endif
#ifndef _PATH_MAILDIR
#define	_PATH_MAILDIR	"/var/spool/mail"
#endif
#ifndef _PATH_NOLOGIN
#define	_PATH_NOLOGIN	"/etc/nologin"
#endif
#ifndef _PATH_LOGIN
#define _PATH_LOGIN	"/bin/login"
#endif
#define _PATH_PASSWD	"/etc/passwd"
#define _PATH_PTMP	"/etc/ptmp"
#define _PATH_PTMPTMP	"/etc/ptmptmp"
