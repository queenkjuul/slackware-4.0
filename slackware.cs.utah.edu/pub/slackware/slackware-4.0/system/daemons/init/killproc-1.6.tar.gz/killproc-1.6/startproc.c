/*
 * startproc.c  Start process(es) of the named program.
 *
 * Was:         daemon [-l log_file] /full/path/to/program
 * Usage:       startproc [+/-<prio>] [-v] [-l log_file|-q] /full/path/to/program
 *
 * Copyright 1994,95 Werner Fink, 1996-98 S.u.S.E. GmbH Fuerth, Germany.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Author:      Werner Fink <werner@suse.de>
 * 1998/05/06 Werner Fink: change name to startproc
 * 1998/05/06 Werner Fink: rework, added "-f" for pid files
 */

#include "libinit.h"
#include <sys/time.h>
#include <sys/resource.h>


#define NOPROCESS	1
#define NOPIDFILE	2
#define NOPIDREAD	4
#define WRGSYNTAX	8
#define NOLOGFILE	16

#define USAGE		"Usage:\n"\
			"\t%s [+/-<prio>] [-v] [-l log_file|-q] /full/path/to/program\n" \
			, we_are

static int do_fork(const char *name, char *argv[], const char* log,
		   const int nicelvl, const int env);

static int quiet = 1, supprmsg = 0;

int main(int argc, char **argv)
{
    extern char * we_are;
    int c;
    struct stat st;
    char *fullname = NULL, *basename = NULL, *log_file = NULL, *pid_file = NULL;
    int nicelvl = 0, env = 0;

    we_are = base_name(argv[0]);
    openlog (we_are, LOG_OPTIONS, LOG_DAEMON);

/*
 *  We should stat() fullname, because only the path identifies the executable.
 *  If there is one hardlink we have only to stat() the orignal executable.
 *  If there is more than one hardlink and we have to distinguish the
 *  executables by their swapname.  Note if the cmdline of some executables
 *  will changed by the running process its self the name is not clearly
 *  defined ... see libinit.c for more information.
 */

    if (*argv) {
        char **opt = argv;
	if (*(++opt) && (nicelvl = atoi(*opt))) {
	    if (nicelvl > PRIO_MAX)
        	nicelvl = PRIO_MAX;
	    if (nicelvl < PRIO_MIN)
	        nicelvl = PRIO_MIN;
	    argc--, argv++;
	}
    }

    opterr = 0;
    while ((c = getopt(argc, argv, "+ef:l:hqv")) != -1) { /* `+' is POSIX correct */
	switch (c) {
	    case 'v':
		quiet = 0;
		break;
	    case 'e':
		env = 1;
		break;
	    case 'f':
		/* Allocate here: address optarg (current *argv) isn't freeable */
		if (optarg && !pid_file) {
		    pid_file = strdup(optarg);
		} else {
		    nsyslog(LOG_ERR,"Option -f requires pid file to read pid from\n");
		    exit(WRGSYNTAX);
		}
		break;
	    case 'l':
		if (optarg && !log_file) {
		    log_file = optarg;
		} else {
		    nsyslog(LOG_ERR,"Option -l requires log file\n");
		    exit(WRGSYNTAX);
		}
		break;
	    case 'q':
	        supprmsg = 1;
	        break;
	    case 'h':
		nsyslog(LOG_ERR, USAGE);
		exit(0);
		break;
	    case '?':
		nsyslog(LOG_ERR, USAGE);
		exit(WRGSYNTAX);
		break;
	    default:
		break;
	}
    }

    argv += optind;
    argc -= optind;

    if (*argv) {
	fullname = *argv;
	basename = base_name(fullname);
    }

    if (!fullname) {
	nsyslog(LOG_ERR, USAGE);
	exit(WRGSYNTAX);
    }

    if (!pid_file) {		/* the default pid file */
	pid_file = (char*) xmalloc(DEFPIDLEN+strlen(basename)+1);
        pid_file = strcat(strcat(strcpy(pid_file,DEFPIDDIR),basename),DEFPIDEXT);
    }

    errno = 0;
    if (stat(pid_file, &st) < 0) {
	if (errno != ENOENT) {
	    nsyslog(LOG_ERR, "Can\'t stat %s: %s\n", pid_file, sys_errlist[errno]);
	    exit(NOPIDREAD);
	}
	/* No pid file means that we have to search in /proc/ */
	free(pid_file);
	pid_file = NULL;
    }

    if (!st.st_size) {
	nsyslog(LOG_ERR, "Empty pid file %s for %s\n", pid_file, fullname);
	exit(NOPIDREAD);
    }

    getproc();

    if (pid_file) {		/* The case of having a pid file */
	if (verify_pidfile(pid_file,fullname,(DAEMON|PIDOF)) < 0)
	    exit(NOPIDREAD);
    }

    if (!remember) {		/* No process found with pid file */
        if (pidof(fullname,(DAEMON|PIDOF)) < 0)
	    exit(NOPIDREAD);
    }

    if (remember)
	exit(NOPROCESS);

    do_fork(fullname, argv, log_file, nicelvl, env);

    /* Do we have started it? */

    if (pid_file)
	verify_pidfile(pid_file,fullname,(DAEMON|PIDOF));
    if (!remember)
	pidof(fullname,(DAEMON|PIDOF));

    if (!remember)
	exit(NOPROCESS);
    exit(0);

} /* end of main */

/* The core function */
static int do_fork(const char *name, char *argv[], const char* log,
		   const int nicelvl, const int env)
{
    extern char * we_are;
    int tty = 255;
    int devnull, olderr, status;
    FILE *tmp = NULL;
    pid_t pid;

    devnull = open("/dev/null",O_RDONLY,0);
    if (log) {
	errno = 0;
	if ((tmp = fopen(log,"a")) == NULL) {
	    nsyslog(LOG_ERR,"cannot open %s: %s\n", log, sys_errlist[errno]);
	    exit(NOLOGFILE);
	}
    }

    fflush(stdout);
    fflush(stderr);		/* flush stdout and especially stderr */
    errno = 0;
    switch ((pid = fork())) {
    case 0:
	{
	    char buf[_POSIX_PATH_MAX + 1];
	    (void)snprintf(buf, _POSIX_PATH_MAX, "%s",name);
	    setenv("DAEMON",buf,1);
	}
	if (nicelvl != 0) {
	    errno = 0;
	    if (setpriority(PRIO_PROCESS, getpid(), nicelvl) < 0) {
		nsyslog(LOG_ERR,"[1]cannot set nicelevel: %s\n",
			sys_errlist[errno]);
	    }
	}
	dup2(devnull, fileno(stdin));
	if ((log && tmp) || supprmsg) {
	    while (--tty)
		if (isatty(tty)) close(tty);
	    if (log && tmp) {		/* log file for service messages */
		dup2(fileno(tmp), fileno(stdout));
		dup2(fileno(tmp), fileno(stderr));
		setlinebuf(tmp);
	    } else if (supprmsg) {	/* suppress service messages */
		devnull = open("/dev/null",O_WRONLY,0);
		dup2(devnull, fileno(stdout));
		dup2(devnull, fileno(stderr));
	    }
	}
	fflush(stdout);
	fflush(stderr);		/* flush stdout and especially stderr */
	closelog();
	chdir("/");
	errno = 0;
#if DEBUG
	printf("execve(%s, [", name);
	while (argv && *argv) {
	    printf(" %s", *argv);
	    argv++;
	}
	printf(" ], [");
	while (environ && *environ) {
	    printf(" %s", *environ);
	    environ++;
	}
	printf(" ]);\n");
#else
	execve(name, argv, environ);
#endif
	olderr = errno;
	close(fileno(stdout));
	close(fileno(stderr));
	if (tmp)
	    fclose(tmp);
	devnull = open("/dev/tty",O_WRONLY,0);
	dup2(devnull, fileno(stdout));
	dup2(devnull, fileno(stderr));
	openlog (we_are, LOG_OPTIONS, LOG_DAEMON);
	nsyslog(LOG_ERR,"[1]cannot execute %s: %s\n", name, sys_errlist[olderr]);
	exit(NOPROCESS);
	break;
    case -1:
	if (tmp)
	    fclose(tmp);
	fflush(stdout);
	fflush(stderr);		/* flush stdout and especially stderr */
	nsyslog(LOG_ERR,"[2]cannot execute %s: %s\n", name, sys_errlist[errno]);
	exit(NOPROCESS);
	break;
    default:
	if (tmp)
	    fclose(tmp);
	fflush(stdout);
	fflush(stderr);		/* flush stdout and especially stderr */
	usleep(60*1000);	/* 60 ms time for the child and its child */
	(void) waitpid(pid, &status, WNOHANG);
	if (!quiet)
	    printf("%d\n", (int)pid);
	if (WIFEXITED(status) && WEXITSTATUS(status))
	    exit(NOPROCESS);
	break;
    }
    return 0;
}
