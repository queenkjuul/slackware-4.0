/*
 * bootlogd.c	Store output from the console during bootup into a file.
 *		The file is usually located on the /var partition, and
 *		gets written (and fsynced) as soon as possible.
 *
 * Version:	@(#)bootlogd  2.73  29-Dec-1997  miquels@cistron.nl
 *
 * Bugs:	Uses openpty(), only available in glibc. Sorry.
 *
 *		This file is part of the sysvinit suite,
 *		Copyright 1991-1997 Miquel van Smoorenburg.
 *
 *		This program is free software; you can redistribute it and/or
 *		modify it under the terms of the GNU General Public License
 *		as published by the Free Software Foundation; either version
 *		2 of the License, or (at your option) any later version.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <errno.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <getopt.h>
#include <pty.h>

char *Version = "@(#) bootlogd 2.73 29-Dec-1997 MvS";

int main(int argc, char **argv)
{
	int *t1, *t2;
	char name[64];

	/*
	 *	Grab a pty, and redirect console messages to it.
	 */
	if (openpty(&t1, &t2, name, NULL, NULL) < 0) {
		fprintf(stderr, "bootlogd: cannot allocate pseudo tty\n");
		exit(1);
	}
