#
# Now that TCP/IP is configured, mount the NFS file systems in /etc/fstab.
#
echo "Mounting remote file systems..."
mount -a -t nfs

