#
# Set hostname.
#
hostname --file /etc/hostname

