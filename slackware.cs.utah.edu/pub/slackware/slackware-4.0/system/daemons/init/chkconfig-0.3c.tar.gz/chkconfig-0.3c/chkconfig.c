/* chkconfig - checks a pre-set directory (default is /etc/config) for
 * flag-files containing "on" or "off" (OR, more precisely, "on" or
 * ANYTHING ELSE.
 *
 * Copyright (c) 1995 Marc A. Volovic (marc@leonardo.ls.huji.ac.il)
 *
 * Released under GPL.
 * 
 * If the flag file contains "on", TRUE is returned.
 *
 * If the invocation contains a third argument, changes the flag file
 * to the give
 *
 * This is a wholesale filch from the IRIX chkconfig, allowing various
 * daemons to be activated/deactivated at will, without mucking with
 * /etc/rc.d/rc.* overmuch.
 *
 * History
 *
 * 0.01a - works as advertised :-).
 *
 * 0.01b - added an additional error check.
 *
 * 0.01c - added hooks for modification of config flags.
 *
 * 0.01d - flag modification works.
 *
 * 0.02a - source cleaned up after being hit on head with Stevens'
 *         book by a dear friend and mentor - Amos Shapira
 *         (amoss@@cs.huji.ac.il). Hooks added for file locks and
 *         complete configuration scan.
 *
 * 0.02b - Complete configuration scan added. Man page written. Locks
 *         still not implemented.
 *
 * 0.02c - Fixed bug in flag test. If the flag file line did not end in
 *         a \n, the test would truncate the last char, thereby making
 *         the test FALSE, even for TRUE values. Locks still not
 *         implemented. Added check for config directory modification at
 *         compile-time.
 *
 * 0.02d - Partially modified into independent functions. Code cleaned.
 *
 * 0.03a - Added "-f" flag to explicitly create a non-existent flag.
 *
 * 0.03b - Added README and changed the Makefike slightly
 *
 * 0.03c - Added simplistic handling of IRIX-style "x.options" files
 *         in system configuration directory - chkconfig now considers
 *         _any_ file with a . in its name as an option file and does
 *         not display its contents or handle it in any other way.
 *         Changed the code ever-so-slightly to make spacing more
 *         consistent.
 *
 * CAVEAT EMPTOR: IN TWO OF ITS THREE MODES, THIS COMMAND RUNS
 * ABSOLUTELY SILENTLY! ABSOLUTELY! THERE IS NO OUTPUT! EVER! IF YOU
 * COMPILE IT TO WRITE FILES IN / AND THEN EXECUTE chkconfig vmlinuz
 * on YOU WILL HAVE A 3-BYTE KERNEL. IF YOU DO THIS, TOUGH! IF YOU
 * BREAK ANYTHING - YOU OWN _BOTH_ HALVES!  
 * */

#include <stdio.h>
#include <string.h>
#include <unistd.h> 
#include <dirent.h>

#define MAJOR_VERSION 0
#define MINOR_VERSION 03
#define REVISION_VERSION c

#define MAXLEN 1024

#ifndef CONFIG_DIRECTORY
#define CONFIG_DIRECTORY "/etc/config/"
#endif

/*
 * For debugging purposes. Linked but not used unless dire
 * circumstances force my hand.
 *
 */

extern char *sys_errlist[];
extern int errno;
extern void errexit();

int
checkflag(char flag[])
{
  char buf [MAXLEN] = CONFIG_DIRECTORY;
  FILE *infp;

  strcat (buf, flag);
  
  /* No such flag - silently disprove */
  if ((infp = fopen(buf, "r")) == NULL)
    exit (1);
  
  /* failed to read data value - silently disprove */
  if ((fgets(buf, MAXLEN, infp)) == NULL)
    exit (1);
  else if (buf[strlen(buf) - 1] == '\n')
    buf[strlen(buf) - 1] = '\0';
  
  return(strcmp(buf, "on") != 0);
}

int
setflag(char *flag, char *value, char *fmode)
{
  char buf[MAXLEN] = CONFIG_DIRECTORY;
  char type[MAXLEN];
  FILE *infp;

  if (!strcmp(fmode, "set"))
    strcpy(type, "r");
  else
    if (!strcmp(fmode, "create"))
      strcpy(type, "w");
    else
      return (1);

  if (getuid())
    /* sorry, no cigar */
    return (1);
  else {
    strcat(buf, flag);

    /* overwrite file or create it */
    if ((infp = fopen(buf, type)) == NULL)
      return (1);
    else
      if (!strcmp(type, "r")) {
	fclose(infp);
	infp = fopen(buf, "w");
      }

    /* write flag */
    if ((fputs(value, infp)) == EOF)
      return (1);

    return (0);
  }
}

int
main(ac, av)
     int ac;
     char **av;
{
  FILE *infp;
  DIR  *indp;
  struct dirent *dent;
  char buf[MAXLEN];
  
  switch (ac) {
  case 2 :
    exit (checkflag(*++av));
    break;
  case 4 :
    if ((**av = '-') && (**(av++) = 'f')) {
      /*
       * Cannot use (*++av, *++av) because of precedence. Am unwilling to
       * trust other compilers, either.
       */
      strcpy(buf, *++av);
      exit(setflag(buf, *++av, "create"));
    }
    break;
  case 3 :
    /*
     * Cannot use (*++av, *++av) because of precedence. Am unwilling to
     * trust other compilers, either.
     */
    strcpy(buf, *++av);
    exit(setflag(buf, *++av, "set"));
    break;
  case 1 :
    if ((indp = opendir(CONFIG_DIRECTORY)) == NULL)
      exit(1);
    
    fprintf(stdout, "\t%-12s\t\t\t%-5s\n\t%-12s\t\t\t%-5s\n", "Flag",
	    "Value", "====", "=====");
    while ((dent = readdir(indp)) != NULL) {
      if ((strcmp(dent->d_name, ".") && (strcmp(dent->d_name,
						"..")))) {
	if (strchr(dent->d_name, '.') != NULL)
	  continue;
	fprintf(stdout, "\t%-12s\t\t\t", dent->d_name);
	strcpy(buf, CONFIG_DIRECTORY);
	strcat(buf, dent->d_name);
	if ((infp = fopen( buf, "r" )) != NULL)
	  if ((fgets(buf, MAXLEN, infp )) != NULL) {
	    fprintf (stdout, "%-s", buf);
	    if (buf[strlen(buf) - 1] != '\n')
	      fprintf( stdout, "\n");
	  }
	fclose(infp);
      }
    }
    /* complete configuration scan */
    exit(1);
  default :
    exit(1);
  }
}

