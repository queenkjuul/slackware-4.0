/* errexit.c - errexit - filched directly from Commer */

#include <varargs.h>
#include <stdio.h>

int
errexit(format, va_alist)
char *format;
va_dcl
{
  va_list args;
  va_start(args);
  vfprintf(stderr, format, args);
  va_end(args);
  exit(1);
}
