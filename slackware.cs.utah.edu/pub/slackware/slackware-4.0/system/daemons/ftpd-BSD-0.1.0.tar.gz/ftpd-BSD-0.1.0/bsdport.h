#ifndef ORIGINAL_SOURCE

/* arc4random() is a BSD feature */

u_int32_t arc4random(void);

/* strvis() is a BSD feature */

#define VIS_SAFE        0x20    /* only encode "unsafe" characters */
#define VIS_NOSLASH     0x40    /* inhibit printing '\' */

extern int strvis (char *dst, char *src, int flag);

/* hosts_ctl() doesn't seem to have a prototype anywhere */

int hosts_ctl(char *daemon, char *client_name, char *client_addr,
	char *client_user);

#endif /* not ORIGINAL_SOURCE */
