#! /bin/sh
#
grep "^[^#]." configure | (
while read var val
do
uppervar=`echo $var | tr "a-z" "A-Z"`
/bin/echo -e "#define\t" $uppervar "\t\t" $val
done ) > config.h
