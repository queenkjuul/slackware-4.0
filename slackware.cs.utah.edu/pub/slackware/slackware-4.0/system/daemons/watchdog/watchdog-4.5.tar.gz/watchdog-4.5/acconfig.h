#undef MAJOR_VERSION
#undef MINOR_VERSION

/* path to sendmail */
#undef PATH_SENDMAIL

/* whether to use the syslog facility */
#undef USE_SYSLOG

/* minimum value accepted as reboot cause */
#undef MINLOAD

/* timer margin used by kernel */
#undef TIMER_MARGIN

/* config file path */
#undef CONFIG_FILENAME

/* config file line length */
#undef CONFIG_LINE_LEN

/* pid file path */
#undef PIDFILE

/* random seed file */
#undef RANDOM_SEED

/* whether to include NFS support */
#undef HAVE_NFS

/* debug watchdog? */
#undef DEBUG
