#define KERNEL_NFS_MOUNT_VERSION	1	/* mountd version */
