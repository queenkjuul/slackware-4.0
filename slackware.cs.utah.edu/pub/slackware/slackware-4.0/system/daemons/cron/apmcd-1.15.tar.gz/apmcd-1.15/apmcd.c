#include "apmcd.h"

#define VERSION "$Revision: 1.15 $"
#define ID "$Id: apmcd.c,v 1.15 1998/11/15 23:23:53 nicholas Exp $"

struct apmcd_tab *apmcdtab=NULL;
struct apmcd_opts options={0,"/etc/apmcdtab",0,1};
struct apmcd_stats stats;

int getconf(char *file) {
  FILE * fp;
  int percent;
  char aconline;
  char charging;
  char cmd[MAXCMDSIZE];
  char line[MAXCMDSIZE];
  int ret;
  struct apmcd_tab *tab=NULL;

  fp=fopen(file,"r");

  if(!fp) {
    fprintf(stderr,"apmcd: %s: ",file);
    perror(0);
    exit(1);
  }

  while (fgets(line,MAXCMDSIZE,fp)) {
    if (line[0] =='#' || isspace(line[0]))
      continue;

    ret=sscanf(line,"%c %c %d %[^\n]",&aconline,&charging,&percent,cmd);

    if (ret==4) {
      if (tab) {
	tab->next=calloc(1,sizeof(struct apmcd_tab));
	tab=tab->next;
      }
      else {
	apmcdtab=calloc(1,sizeof(struct apmcd_tab));
	tab=apmcdtab;
      }

      tab->aconline=tolower(aconline);
      tab->charging=tolower(charging);
      tab->percent=percent;
      tab->command=(char *)strdup(cmd);
      tab->used=0;
    }
    else
      fprintf(stderr,"unparsable: %s",line);
  }

  fclose(fp);
}

char * nicetime(int s,char *buf) {
  int h=0,m=0;

  buf[0]=0;

  if (s==0) {
    sprintf(buf,"??");
    return(buf);
  }

  if (s>3600) {
    h=s/3600;
    s-=h*3600;
  }
  if (s>60) {
    m=s/60;
    s-=m*60;
  }
  if (h)
    sprintf(buf,"%dh",h);
  if (m)
    sprintf(&buf[strlen(buf)],"%dm",m);
  if (s)
    sprintf(&buf[strlen(buf)],"%ds",s);

  return(buf);
}

int chac(char yn,int ac) {
  if (yn=='*')
    return(1);
  if (yn=='y' && ac==AC_ONLINE) 
    return(1);
  if (yn=='n' && ac!=AC_ONLINE)
    return(1);

  return(0);
}

int chch(char yn,int ch) {
  if (yn=='*')
    return(1);
  if (yn=='y' && ch==BATTERY_CHARGING) 
    return(1);
  if (yn=='n' && ch!=BATTERY_CHARGING)
    return(1);

  return(0);
}

int checktab(struct apm_status *apm,int changed) {
  int i;
  struct apmcd_tab *tab;

  for (tab=apmcdtab;tab;tab=tab->next) {
    if (tab->percent == apm->percent && tab->percent != -1
        && tab->used==0
	&& chac(tab->aconline,apm->acstatus)
	&& chch(tab->charging,apm->battstatus)
        ){

      /*
      if (sSyslog)
        syslog(LOG_INFO,"tab #%d(%d%%) triggered: %s\n",
               i,tab->percent,tab->command);

      if (sDebug)
        printf("apmcd: tab #%d(%d%%) triggered: %s\n",
               i,tab->percent,tab->command);
      */
      system(tab->command);
      
      tab->used=1;
    }
    if (changed && tab->percent == -1 &&
	chac(tab->aconline,apm->acstatus) &&
	chch(tab->charging,apm->battstatus)
	) {
      /*
      if (sSyslog)
        syslog(LOG_INFO,"tab #%d(%d%%) triggered: %s\n",
               i,tab->percent,tab->command);

      if (sDebug)
        printf("apmcd: tab #%d(%d%%) triggered: %s\n",
               i,tab->percent,tab->command);
      */
      system(tab->command);

      tab->used=1;
    }

  }
  return(0);
}

int getbattery(struct apm_status *apm) {
  FILE *fp=fopen("/proc/apm","r");

  if (!fp) {
    perror("apmcd: /proc/apm");
    return(0);
  }

  fscanf(fp,"%f %f 0x%02x 0x%02x 0x%02x 0x%02x %d%% %d\n",
         &apm->driver,&apm->biosver,&apm->apmflags,
         &apm->acstatus,&apm->battstatus,&apm->battflags,
         &apm->percent,&apm->mins);

  fclose(fp);
  return(1);
}

void usage(void) {
  printf("%s\n\n",ID);
  printf("usage: apmcd [-dh] [-f file] [-t ticks]\n"
         "\n"
         "   -d        Debug, output to stdout, don't fork.\n"
	 "   -h        This help.\n"
	 "   -f file   Read alternate configuration file.\n"
	 "   -t ticks  Report every 'tick' percentage change.\n"
         );
}

void status(struct apm_status *apm) {
  char buff[256],a[16],b[16],c[16],d[16];

  sprintf(buff,"%d%% (%c%s/%s, %s) AC(%s) BATT(%s)\n",
	  apm->percent,

	  apm->battstatus==BATTERY_CHARGING ? '+':'-',
	  nicetime(apm->mins*60,a),
	  apm->battstatus==BATTERY_CHARGING ? 
	  nicetime((100-apm->percent)*stats.avgdrain,b) :
	  nicetime(apm->percent*stats.avgdrain,c),
	  nicetime(stats.avgdrain,d),
	  acStatus[apm->acstatus],
	  batStatus[apm->battstatus]
	  );

  if (options.debug)
    fprintf(stderr,"apmcd: %s",buff);
  else
    syslog(LOG_INFO,"%s",buff);
}


int main(int argc,char **argv,char **env) {
  struct apm_status apm,oapm,capm;
  struct timeval tv,otv;
  struct apmcd_tab *tab;
  int changed=0;
  int tick=1;
  int i;
  int first=1;

  while ( (i=getopt(argc,argv,"df:ht:")) != EOF ) {
    switch (i) {
    case 'h':
      usage();
      exit(0);

    case 'd':
      options.debug=1;
      break;

    case 'f':
      options.apmcdtab=(char *)strdup(argv[optind-1]);
      break;

    case 't':
      options.tick=atoi(argv[optind-1]);
      break;

    case '?':
      fprintf(stderr,"\n");
      usage();
      exit(1);
    }
  }

  if (options.debug)
    fprintf(stderr,"%s\n\n",ID);

  openlog("apmcd",LOG_PID,LOG_DAEMON);
  syslog(LOG_INFO,ID);

  if (!getbattery(&apm)) {
    fprintf(stderr,"apmcd: this kernel does not support APM!\n");

    syslog(LOG_ERR,"this kernel does not support APM!\n");

    exit(1);
  }

  getconf(options.apmcdtab);

  oapm=capm=apm;
  gettimeofday(&otv,NULL);

  if (!options.debug)
    if (fork())
      exit(0);

  status(&apm);

  while (1) {
    getbattery(&apm);

    /* change in ac online status */
    if (capm.acstatus != apm.acstatus) {
      changed=1;
      capm.acstatus=apm.acstatus;
      oapm=apm;
      stats.avgdrain=stats.avgcount=0;
      
      /* ok, it changed 
	 if so reset the apmcdtab for stuff */
      for (tab=apmcdtab;tab;tab=tab->next)
	tab->used=0;

      status(&apm);
    }
    /* change in charge percentage */
    if (abs(oapm.percent - apm.percent)>= tick) {
      char buf[256],a[10];
      sprintf(buf,"apmcd (%d%% %s)",apm.percent,nicetime(apm.mins*60,a));
      strcpy(argv[0],buf);

      if (first) {
	gettimeofday(&otv,NULL);
	first=0;
      }
      else {
	/* drain/charge estimate */
	if (apm.acstatus==AC_OFFLINE || apm.battstatus==BATTERY_CHARGING) {
	  gettimeofday(&tv,NULL);

	  stats.lastdrain=(tv.tv_sec - otv.tv_sec) / 
	    abs(oapm.percent - apm.percent);

	  if (stats.avgcount) {
	    stats.avgdrain=((stats.avgdrain*stats.avgcount) +
			    stats.lastdrain)/(++stats.avgcount);
	  }
	  else {
	    stats.avgcount++;
	    stats.avgdrain=stats.lastdrain;
	  }
	  otv=tv;
	}
      }
      oapm=apm;

      if (apm.percent % options.tick == 0)
	status(&apm);
    }
    /* apmcdtabs ? */
    checktab(&apm,changed);
    changed=0;

    sleep(5);
  }

}
