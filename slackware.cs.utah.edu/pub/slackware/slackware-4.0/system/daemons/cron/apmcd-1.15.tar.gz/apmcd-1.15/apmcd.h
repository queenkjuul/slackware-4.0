#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/time.h>
#include <syslog.h>
#include <linux/apm_bios.h>

struct apm_status {
  int acstatus;
  int battflags;
  int percent;
  float driver;
  float biosver;
  int apmflags;
  int battstatus;
  int mins;
};

struct apmcd_tab {
  char aconline;
  char charging;
  int percent;
  char *command;
  int used;
  struct apmcd_tab *next;
};

struct apmcd_opts {
  int debug;
  char *apmcdtab;
  int quiet;
  int tick;
};

/* drain is in seconds per percent
   during recharge the same structure is used */

struct apmcd_stats {
  int avgdrain;
  int avgcount;
  int lastdrain;
};

static char *acStatus[]={
  "offline",
  "online",
  "backup"
};

static char *batStatus[]={
  "high",
  "low",
  "critical",
  "charging"
};

#define AC_OFFLINE 0
#define AC_ONLINE 1
#define AC_BACKUP 2

#define BATTERY_HIGH 0
#define BATTERY_LOW 1
#define BATTERY_CRITICAL 2
#define BATTERY_CHARGING 3

#define MAXCMDSIZE 256
