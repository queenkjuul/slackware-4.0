/************************************************************************
 *   KTAB - Keith program TABing, include/help.h
 *   Copyright (C) 1998 Keith Fralick
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef DEFAULT_TIME
# error DEFAULT_TIME NOT DEFINED!
#endif

char	*help[] = 

{

"KTAB\tBy: Keith Fralick",
"",
"all commands are done via \"-\"",
"",
"help\t\tWhat this is",
"version\t\tTells you the version info",
"settings\tTells you the current KTAB settings",
"",
"f\t\t<file>\tScript for KTAB",
"p\t\t<file>\tFile to run (takes defaults)",
"r\t\t<file>\tReview Script, report all errors",
"",
"Please report all bugs to fralick@gate.net",
NULL
};
