/************************************************************************
 *   KTAB - Keith program TABing, include/struct.h
 *   Copyright (C) 1998 Keith Fralick
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

typedef struct processes Proc;
typedef struct shortcuts Short;

struct	processes	{
	char	path[1024];
	char	args[1024];		/* this is for arguments v0.3.1 */
	time_t	chktime;
	time_t	lastchk;
	struct	processes *next;
} *proc = NULL;

struct	shortcuts	{
	char	name[256];
	char	real[1024];
	int	num;
	struct	shortcuts *next;
} *shorty = NULL;
