/************************************************************************
 *   KTAB - Keith program TABing, include/dir.h
 *   Copyright (C) 1998 Keith Fralick
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

extern	int	d_echo(), d_logfile(), d_setuid(), d_dclr(), d_num();
extern	int	d_wait(), d_exec(), d_vcat();

struct {
	char	*name;
	int	(*function)(char *);
} directive_cmds[] = {
{ "ECHO",	d_echo		},
{ "LOGFILE",	d_logfile	},
{ "SETUID",	d_setuid	},
{ "DCLR",	d_dclr		},
{ "PAUSE",	d_wait		},
{ "WAIT", 	d_wait		},
{ "EXEC",       d_exec		},
{ "VCAT",	d_vcat		},
{ NULL,		NULL		}
};

