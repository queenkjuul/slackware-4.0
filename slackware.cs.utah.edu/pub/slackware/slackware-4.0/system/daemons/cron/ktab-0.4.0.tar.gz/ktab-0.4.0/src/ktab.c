/************************************************************************
 *   KTAB - Keith program TABing, src/ktab.c
 *   Copyright (C) 1998 Keith Fralick
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>
#include <signal.h>
#include <unistd.h>
#include "config.h"
#include "version.h"
#include "help.h"
#include "struct.h"
#include "dir.h"
#include "static.h"

extern	void	dieme();
extern	void	helpout();
extern	void	add_process();
extern	void	do_script();
extern	void	check_jobs();
extern	void	rehash();
extern	void	loop_procs();
extern	void	first_write();
extern	void	write_log(char *);
extern	int	file_exists(char *);
extern	int	all_norms();
extern	char	*ret(char *);

extern	Short	*make_short();

FILE	*i, *log, *ma;

#define	mycmp	strcasecmp

#define O_RW	 "rw"
#define O_APPEND  "a"
#ifndef READ_WRITE_PERMISSION
#define	O_RDONLY "r"
#else
#define O_RDONLY O_RW
#endif

int	dupp = DEFAULT_TIME * 60;
char	*logfile = NULL;
char	*prog = NULL, *sfile = NULL;
char	*curpath, *os, *shell, *home, *myhost, *trm, *luser;
char	tmp[1024];
char	version[300];

int	opt_kill = 0;

int	review = 0, cntt = 0;

static	pid_t	w;

int	main(int argc, char *argv[])
{
	time_t a = time(NULL) + CHECK_RUN_FROM_FEET;
	time_t b = time(NULL);

	curpath = getenv("PWD");
	os = getenv("OSTYPE");
	shell = getenv("SHELL");
	home = getenv("HOME");
	myhost = getenv("HOSTNAME");
	trm = getenv("TERM");
	luser = getenv("LOGNAME");

	strcpy(version, KTAB_VERSION);

	if(argc < 2)
		dieme("No arguments given.\n%s -help for help",
			argv[0]);
	/* to accept -f as default */
	if(argv[1] && !argv[2] && *argv[1] != '-')
	{
		argv[2] = argv[1];
		argv[1] = "-f";
	}
	if(*argv[1] != '-')
		dieme("No \"-\" character");
	argv[1]++;
	if(!mycmp(argv[1], "help") || !mycmp(argv[1], "?"))
		helpout();
	else if(!mycmp(argv[1], "version") || !mycmp(argv[1], "v"))
		dieme("KTAB %s   %s %s %s %s %s", version, 
			os?os:"unknown", curpath?curpath:"unknown",
			shell?shell:"unknown",myhost?myhost:"unknown",
			luser?luser:"unknown");
	else if(!mycmp(argv[1], "settings") || !mycmp(argv[1], "s"))
	{
		printf("KTAB\tBy: Keith Fralick\tv%s\n\n",
			version);
		printf("MIN_PROGRAM_CHECK=%d\n",
			MIN_PROGRAM_CHECK);
		printf("DEFAULT_TIME=%d\n",
			DEFAULT_TIME);
		printf("READ_WRITE_PERMISSION=%s\n",
			!mycmp(O_RDONLY, "rw") ? "Yes" : "No");
		dieme("CHECK_RUN_FROM_FEET=%d",
			CHECK_RUN_FROM_FEET);
	}
	else if(!mycmp(argv[1], "f"))
	{
		if(!argv[2])
			dieme("Did not pass parameter for file");
		sfile = argv[2];
	}
	else if(!mycmp(argv[1], "p"))
	{
		if(!argv[2])
			dieme("Did not pass parameter for program");
		prog = argv[2];
	}
	else if(!mycmp(argv[1], "r"))
	{
		if(!argv[2])
			dieme("Did not pass parameter for file");
		sfile = argv[2];
		review = 1;
	}
	else
		dieme("Invalid parameters were passed, exiting");
	if(!sfile && !prog)
		dieme("dire problem");
	
	if(!((i = fopen(sfile, O_RDONLY)) ||
		(i = fopen(prog, O_RDONLY))))
		dieme("File not found known as %s(%s)",
			sfile ? "file" : "program",
			sfile ? sfile : prog);
	
	printf("KTAB\tBy:  Keith Fralick\tv%s\n",
		version);
	printf("loading %s:[%s]\n", sfile ? "file" : "program",
		sfile ? sfile : prog);
	(void)all_norms();
	if (prog)
		fclose(i);
	else
		do_script();
	if(review)
	{
		review = 0;
		dieme("\n%d Error%s reported",cntt,
			cntt > 1 || cntt == 0 ? "s" : "");
	}
	w = getpid() + 1;
	printf("Operating System   : %s\n", os ? os : "Unknown");
	printf("My PID is          : %d\n", w);
	printf("Current Directory  : %s\n", curpath ? curpath : "Unknown");
	printf("Current Shell      : %s\n", shell ? shell : "Unknown");
	printf("Home Directory     : %s\n", home ? home: "Unknown");
	printf("System Hostname    : %s\n", myhost ? myhost : "Unknown");
	printf("User Identification: %d\n", getuid());
	printf("Current TERM       : %s\n", trm ? trm : "Unknown");
	printf("Login Username     : %s\n", luser ? luser : "Unknown");
	printf("KTAB is now in the background.\n");
	argv[1] = argv[2] = NULL;
	if (fork())
		exit(0);
	(void)signal(SIGHUP, rehash);
	if(prog)
		while (1)
		{
			if(curpath) chdir(curpath);
			while(time(NULL) <= a) sleep(1);
			if(prog)
				system(prog);
			a+=dupp;
		}
	if(sfile)
		while (1)
		{
			if(curpath) chdir(curpath);
			check_jobs();
			sleep(1);			
		}
	return 0;
}

/*
 * Exits out of the program,
 * along with a particular message
 *
 * perhaps I should have used varargs here,
 * but this works just as well, besides, 
 * it's not that much of a risk whenever
 * we're leaving the program anyway
 */
void	dieme(fmt, p1, p2, p3, p4, p5, p6, p7)
char 	fmt[1024];
char	*p1, *p2, *p3, *p4, *p5, *p6, *p7;
{
	char target[1024];
	(void)sprintf(target, fmt, p1, p2, p3, p4, p5, p6, p7);
	printf("%s\n", target);
	if(review)
	{
		cntt++;
		return;
	}
	exit(0);
}

/*
 * Prints help information to the user
 * from help.h.  Rather simple and
 * quick.
 */
void	helpout()
{
	int i = -1;
	while(help[++i])
		printf("%s\n",help[i]);
	dieme("");
}

void	add_process(int t, char pathto[1024], char args[1024])
{
	Proc 	*new, *current;
	char	tog[1024];	

	if(!(new = (Proc *)malloc(sizeof(Proc))))
		dieme("No memory to procede.\n");
	if(new != NULL)
		new->next = NULL;
	if(args)
		(void)sprintf(pathto, "%s %s", pathto, args);
	else
		strcpy(tog, pathto);
	strcpy(new->path, pathto);
	new->chktime = t;
	new->lastchk = 0;
	if(proc == NULL) 
		proc = new;
	else
	{
		current = proc;
		while(current->next)
			current = current->next;
		current->next = new;
	}
}

void	do_script()
{
	char	load[2048];
	char	*div[10];
	int	c = 0, p = 0, y;
	int	mvalue = 0;
	char	*f, *s, *tp;

	while(fgets(load, sizeof(load), i))
	{
		if(!load || *load == ' ' || !strchr(load, ' ') ||
			*load == '#')
			continue; 
		if(strlen(load) > 2048)
			continue;
		while(strchr(load, '\n'))
			*strchr(load, '\n') = '\0';
		if(*load == 's')
			mvalue = 1;
		else if(*load == 'm')
			mvalue = 60;
		else if(*load == 'h')
			mvalue = 3600;
		else if(*load == 'd')
			mvalue = 3600 * 24;
		f = load;
		s = strchr(load, ' ');
		*(s)++ = '\0';
		div[0] = f;
		div[1] = s;
		if(*div[0] == '@')
		{
			div[0]++;
			for(y = 0; directive_cmds[y].name; y++)
				if(!mycmp(directive_cmds[y].name, div[0]))
				(void)directive_cmds[y].function(div[1]);
			continue;
		}
		if(mvalue)
			div[0]++;
		else
			mvalue = 60;
		p = atoi(div[0]);
		p*=mvalue; 
		if (p == 0)
			p = mvalue ? mvalue : (DEFAULT_TIME * 60);
		if(p < MIN_PROGRAM_CHECK)
			dieme("Time in your script is lower than the minimum time of %d", MIN_PROGRAM_CHECK);
		if(mvalue == 60 && p < CHECK_RUN_FROM_FEET)
			p = MIN_PROGRAM_CHECK * 60;
		if(strchr(div[1], ' '))
		{
			f = div[1];
			s = strchr(f, ' ');
			*(s)++ = '\0';
		}
		else
			f = div[1];
		/* below is where we were getting our bug */
		if(*div[1] != '@')
		{
			if(!file_exists(f))
				dieme("ERROR:[%s] non-existant program",f);
		}
		add_process(p, f, s ? s : NULL);		
		c++;
	}
	if(!c)
	 exit (-1);
	fclose(i);
}

int	file_exists(char *filename)
{
	FILE	*a;

	if(strchr(filename, '$'))
		return 1;
	if(*filename == '-')
		filename++;
	if(!((a = fopen(filename, O_RDONLY))))
		return 0;
	fclose(a);
	return 1;
}

void	check_jobs()
{
	Proc	*z;
	int	y;	
	char	*f, *s;
	char	*kind;

	for(z = proc; z; z = z->next)
	{
		if(z->lastchk == 0)
			z->lastchk = time(NULL) + CHECK_RUN_FROM_FEET;
		else
			if(time(NULL) - z->lastchk >= z->chktime)
			{			
				if(*z->path != '@')
				{
					strcpy(tmp, ret(z->path));
#ifdef 	SUPRESS_PROGRAM_DATA
					kind = tmp;
					if(*kind == '-') kind++;
					strcpy(tmp, kind);
					strcat(tmp, ">> /tmp/blah");
# else
					if(*tmp == '-')	
					{
						kind = tmp;
						kind++;
						strcpy(tmp, kind);
						strcat(tmp, ">> /tmp/blah");
					}
#endif
					system(tmp);
					write_log(tmp);
				}
				else
				{
					strcpy(tmp, z->path);
					f = tmp;
					s = strchr(tmp, ' ');
					*(s)++ = '\0';
					f++;
					strcpy(tmp, ret(tmp));
					for(y = 0; directive_cmds[y].name; y++)
					if(!mycmp(directive_cmds[y].name,f))
					(void)directive_cmds[y].function(s);
					write_log("@directive@");
				}			
				z->lastchk = time(NULL);
			} 
	}
}

/*
 * When we get signal SIGHUP, we just die.
 * The reason being, why flush out the 
 * structure and start again?  If they want
 * to reload something, do it right.
 */
void	rehash(x)
{
	exit(0);
}


int	d_exec(char *parm)
{
	char	kpr[1024];
	char 	*f, *s;
	
	if(!parm) return 0;
	parm = ret(parm);
	strcpy(kpr, parm);
	if(strchr(parm, ' '))
	{
		f = parm;
		s = strchr(f, ' ');
		*(s)++ = '\0';
		if(access(f, F_OK))
			dieme("ERROR:[%s] non-existant program",f);
	}
	else
	{
		f = parm;
		if(access(f, F_OK))
			dieme("ERROR:[%s] non-existant program",f);
	}	
	system(kpr);
	return 0;
}
/*
 * Very simple code for the @echo
 * script directive.
 */
int	d_echo(char *parm)
{
	char	rtmp[1024], trans[1024];
	int	i;
	int	f = -1;
	int	noend = 0;

	if(!parm || strlen(parm) > 1024)
	 return 0;
	if(*parm == '-')	/* suppresses the \n */
	{
		noend++;
		parm++;
	}
	if(*parm == ' ')
		while(*parm == ' ')
			parm++;
	strcpy(rtmp, ret(parm));
	i = strlen(rtmp); 
	i--;
	if(rtmp[i] != '~')
		printf("%s%s%s", rtmp, review ? " -> OK (@echo) ": "", 
			noend ? "\0" : "\n");
	else
	{
		strncpy(trans, rtmp, i-1);
		printf("%s", trans); 
	}
	return 0;
}

int	d_setuid(char *parm)
{
	int	i = 0;	

	if(!parm || !(getuid()))
	 return 0;
	i = atoi(parm);
	if(!i)
	 return 0;		
	return(setuid(i));
}

int	d_vcat(char *parm)
{
	char 	*f, *s, cp[1024];
	Short	*tmp;

	if(!strchr(parm, ' '))
		return 0;
	if(strchr(parm, '\n'))
		*strchr(parm, '\n') = '\0';
	parm = ret(parm);
	strcpy(cp,parm);
	f = parm;
	s = strchr(f, ' ');
	*(s)++ = '\0';
	for(tmp = shorty; tmp; tmp = tmp->next)
	{
		if(!mycmp(tmp->name, f))
		{
			strcat(tmp->real, s);
			return 0;
		}
	} 	
	/* If we make it here, the variable has yet to exist! */
	/* Therefore, we take a copied image and pass it to dclr! */
	return(d_dclr(cp));
}

int	d_dclr(char *parm)
{
	char	*name, *actual;
	Short	*tmp;

	if(!parm || !strchr(parm, ' '))
	 return 0;
	name = parm;
	actual = strchr(name, ' ');
	*(actual)++ = '\0';
	tmp = make_short();
	actual = ret(actual);
	strcpy(tmp->name, name);
	strcpy(tmp->real, actual);
	if(review)
		printf("$%s$:\"%s\" -> OK (@dclr)\n", name, actual);
	return 0;
}

/*
 * This routine alters and opens
 * the newly found log file
 */
int	d_logfile(char *parm)
{
	if(logfile)
		fclose(log);		
	logfile = parm;
	if(!(log = fopen(logfile, O_APPEND)))
		dieme("Unable to open logfile(%s)", logfile);
	first_write();
	return 0;
}

int	d_wait(char *parm)
{
	long	o;

	o = atoi(parm);
	if(!o || o > 90000) return(0);
	sleep(o);
}

void	first_write()
{
	if(!log)
		return;
	fprintf(log, "KTAB LOG STARTED AT %ld SECONDS\n", 
		time(NULL));
}

void	write_log(char *execute)
{
	if(!logfile)
		return;
	if(!log)
		if(!((log = fopen(logfile, O_APPEND))))
			dieme("Something wrong with the log file");
	fprintf(log, "%d: Executed program:[%s]\n",
		time(NULL), execute);
}

Short	*make_short()
{
        Short *new, *current;
        if(!(new = (Short *)malloc(sizeof(Short))))
		dieme("No memory to procede.\n");
        if(new != NULL)
                new->next = NULL;
        if(shorty == NULL)
                shorty = new;
        else
        {
                current = shorty;
                while(current->next)
                        current = current->next;
                current->next = new;
        }
	return (new);
}

char	*ret(char *str)
{
	char	*s1, *s2;
	char	*s01, *s02;
	char	name[80], all[1024], actual[350];
	int	k = 0;
	Short	*tmp;	
	int	u = 0;

	if(*str == ' ' || !strchr(str, '$'))
	 return str;
	s1 = str;
	s2 = strchr(s1, '$');
	*(s2)++ = '\0';
	if(!strchr(s2, '$'))
	 return NULL;
	s01 = s2;
	s02 = strchr(s01, '$');
	*(s02)++ = '\0';	
	strcpy(name, s01);

	for(tmp = shorty; tmp; tmp = tmp->next)
		if(tmp->name && tmp->real && !mycmp(tmp->name, name))
		{
			strncpy(actual, tmp->real, 349);
			k++;
		}
	if(!k)
		for(tmp = shorty; tmp; tmp = tmp->next)
		{
			if(tmp->name && tmp->real && !mycmp(tmp->name, name))
				strncpy(actual, tmp->real, 349);
		}

	(void)sprintf(all, "%s%s%s", s1?s1:"", actual?actual:"", s02?s02:"");
	return(ret(all));
}

int     all_norms()
{
        char    *name, *actual;
        Short   *tmp;
	int	l = -1;

	while(ld_cmds[++l].name)
	{
        	tmp = make_short();
        	strcpy(tmp->name, ld_cmds[l].name);
        	strcpy(tmp->real, ld_cmds[l].actual);
	}
	return 0;
}

