/************************************************************************
 *   KTAB - Keith program TABing, include/config.h
 *   Copyright (C) 1998 Keith Fralick
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * MIN_PROGRAM_CHECK
 *  
 * Define this to the minimum time in which a script may contain
 * for checking a program's existance.  This number is in seconds.
 */
#define	MIN_PROGRAM_CHECK	30

/*
 * DEFAULT_TIME
 *
 * Define this value to the value in which shall be default if a
 * user supplies the -p option for a KTAB.  This number is in
 * minutes.
 */
#define	DEFAULT_TIME		3	

/*
 * READ_WRITE_PERMISSION
 *
 * Define this if you want your users to have read *AND* write
 * permissions in order to ktab a process under their UID.
 */
#define READ_WRITE_PERMISSION

/*
 * CHECK_RUN_FROM_FEET
 *
 * Define this to the value that you want KTAB to wait until
 * the period that it is off its feet in order to check the
 * desired process for the very first time.  This number is
 * in seconds.
 */
#define CHECK_RUN_FROM_FEET	10	

/*
 * SUPRESS_PROGRAM_DATA
 *
 * Define this if you want to attempt to supress any data that
 * the programs you run might try to print to the screen.  However,
 * this is only an attempt, if you undef this, you may still use
 * the '-' character in front of the path to your programs in
 * the script.  However, defining this, it will attempt to supress
 * whether or not you have the '-' character.
 */
#undef SUPRESS_PROGRAM_DATA 

/*
 * Define the below paths to the correct programs.  If the path
 * are incorrect, do not expect the shortcuts to work for it.
 * *ALL* of these *MUST* be defined!
 */
#define	PATHTO_MV	"/bin/mv"
#define PATHTO_RM	"/bin/rm"
#define	PATHTO_CP	"/bin/cp"
#define	PATHTO_CHOWN	"/bin/chown"
#define	PATHTO_DATE	"/bin/date"
#define PATHTO_LS	"/bin/ls"
#define	PATHTO_UNAME	"/bin/uname"
#define	PATHTO_FREE	"/bin/free"
#define	PATHTO_ECHO	"/bin/echo"
#define	PATHTO_MKDIR	"/bin/mkdir"
#define	PATHTO_PWD	"/bin/pwd"
#define	PATHTO_PS	"/bin/ps"
