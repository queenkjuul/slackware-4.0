#ifndef INCLD_WATCHCRON_H
#define INCLD_WATCHCRON_H


#define COPYRIGHT "Copyright (c) 1998  Mike Knerr"

#define DEFAULT_STATEFILE "/var/lib/watchcrond/status"
#define DEFAULTCONFFILE "/etc/watchcrond.conf"
#define DEFAULTCONFDIR "/etc/watchcrond"

typedef enum boolean {
    FALSE = 0, TRUE = 1
} BOOLEAN;

typedef enum opmode {
   MODE_NORMAL = 0, MODE_VERBOSE, MODE_TEST, MODE_DEBUG 
} OPMODE;

BOOLEAN inDaemonMode(void);
BOOLEAN inTestMode(void);
BOOLEAN inVerboseMode(void);

#endif
