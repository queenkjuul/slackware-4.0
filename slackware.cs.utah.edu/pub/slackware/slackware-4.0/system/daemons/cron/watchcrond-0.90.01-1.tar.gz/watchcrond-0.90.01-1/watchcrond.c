/*
   watchcrond.c - main code module for watchcrond job processing daemon.

   Copyright (c) 1998  mike knerr <mk@metrotron.com>

   This file is part of the watchcrond package

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program in the file COPYING; if not write to
   the Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 
   02139, USA
 */

#include <alloca.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/types.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <syslog.h>

#include "log.h"
#include "watchcrond.h"

#define PIDFILE "/var/run/watchcrond.pid"

#define DOHOURLY "find /etc/watchcron.d/hourly \\( -type f \\) -name '*~' -prune -o -name '*orig' -prune -o -name '*save' -prune -o -name '*prev' -o -exec sh {} \\; &"
#define DODAILY "find /etc/watchcron.d/daily \\( -type f \\)  -name '*~' -prune -o -name '*orig' -prune -o -name '*save' -prune -o -name '*prev' -o -exec sh {} \\; &"
#define DOWEEKLY "find /etc/watchcron.d/weekly \\( -type f \\)  -name '*~' -prune -o -name '*orig' -prune -o -name '*save' -prune -o -name '*prev' -o -exec sh {} \\; &"
#define DOMONTHLY "find /etc/watchcron.d/monthly \\( -type f \\)  -name '*~' -prune -o -name '*orig' -prune -o -name '*save' -prune -o -name '*prev' -o -exec sh {} \\; &"



/* private: */

static BOOLEAN bDaemon = FALSE;
static OPMODE opMode;
/*
static BOOLEAN bTestMode = FALSE;
static BOOLEAN bVerboseMode = FALSE;
*/

static void usage(char *);
static void version(void);
static BOOLEAN isMyDaemonName(char *);
static BOOLEAN pidSave(void);
static int pidFetch(void);
static BOOLEAN pidIsRunning(void);
static BOOLEAN pidIsMeRunning(void);
static BOOLEAN pidErase(void);
static BOOLEAN isValidStartTime(char *);
static BOOLEAN isTimeForNonHourly(char *);
static void shutdown(int);

static BOOLEAN isOnTheHour(void);
static BOOLEAN isFirstOfTheWeek(void);
static BOOLEAN isFirstOfTheMonth(void);

static void setOpMode( OPMODE );
static OPMODE getOpMode(void);

   
   /* operational mode behavior
    * 
    * mode    |  daemon  | run jobs  |  log level  |  where messages go
    * ----------------------------------------------------------------
    * NORMAL  |  YES     |  YES      |  NORMAL     |  ONLY ERRORS TO ERRLOG
    * --------------------------------------------------------------------
    * VERBOSE |  YES     |  YES      |  TEST       |  ALL TO SYSLOG, ERRORS DUPED TO ERRLOG
    * --------------------------------------------------------------------
    * TEST    |  NO      |  NO       |  TEST       |  ALL TO STDERR
    * --------------------------------------------------------------------
    * DEBUG   |  NO      |  YES      |  DEBUG      |  ALL TO STDERR
    * --------------------------------------------------------------------
    */

void setOpMode( OPMODE mode )
{
   if ( mode == MODE_NORMAL ) {
      bDaemon = TRUE;
      logSetLevel( MSG_NORMAL);
      message(MSG_TEST, "Set operational mode to NORMAL\n");
   }
   
   if ( mode == MODE_VERBOSE ) {
      bDaemon = TRUE;
      logSetLevel( MSG_TEST);
      message(MSG_TEST, "Set operational mode to VERBOSE\n");
   }
   
   if ( mode == MODE_TEST ) {
      bDaemon = FALSE;
      logSetLevel( MSG_TEST);
      message(MSG_TEST, "Set operational mode to TEST\n");
   }
   
   
   if ( mode == MODE_DEBUG ) {
      bDaemon = FALSE;
      logSetLevel( MSG_DEBUG);
      message(MSG_TEST, "Set operational mode to DEBUG\n");
   }
   
opMode = mode;
   
}


OPMODE getOpMode(void) {
 
   return opMode;
}


BOOLEAN isDaemon(void)
{
    return bDaemon;
}

BOOLEAN inTestMode(void)
{
   if ( opMode == MODE_TEST) {
      return TRUE;
   } else {
      return FALSE;
   }
   
}

BOOLEAN inVerboseMode(void)
{

   if ( opMode == MODE_VERBOSE) {
      return TRUE;
   } else {
      return FALSE;
   }
}


static void usage(char *szExecName)
{

    if (strncmp(szExecName, "watchcrond", 9) == 0) {

	fprintf(stderr, "usage: watchcrond [-DTVv?] [-a <hh:mm>]\n");

    } else {
	/* not called by us -- so get outa here */
	exit(1);
    }

    fprintf(stderr, "\n%s " VERSION "-" PATCHLEVEL "  " COPYRIGHT "\n", szExecName);
    fprintf(stderr, "May be freely redistributed under the"
	    " terms of the GNU Public License\n\n");

    exit(1);
}

static void version(void)
{
    fprintf(stderr, "watchcrond " VERSION "-" PATCHLEVEL "\n");
    exit(1);
}

static BOOLEAN isMyDaemonName(char *szName)
{

    int iReturn = FALSE;

    if (strncmp(szName, "watchcrond", 10) == 0) {
	iReturn = TRUE;
    } else if (strncmp(szName, "/usr/sbin/watchcrond", 20) == 0) {
	iReturn = TRUE;
    } else if (strncmp(szName, "./watchcrond", 12) == 0) {
	iReturn = TRUE;
    }
    return iReturn;
}



static BOOLEAN pidSave(void)
{

    FILE *f;
    int fd;
    int pid;

    if (((fd = open(PIDFILE, O_RDWR | O_CREAT, 0640)) == -1)
	|| ((f = fdopen(fd, "r+")) == NULL)) {

	message(MSG_ERR, "cannot open or create %s\n", PIDFILE);
	return FALSE;
    }
    if (flock(fd, LOCK_EX | LOCK_NB) == -1) {
	message(MSG_ERR, "cannot lock %s\n", PIDFILE);
	fclose(f);
	return FALSE;
    }
    pid = getpid();

    message(MSG_DEBUG, "writing out pid %d\n", pid);

    if (!fprintf(f, "%d\n", pid)) {
	message(MSG_ERR, "cannot write to %s (%s)\n", PIDFILE, strerror(errno));
	close(fd);
	return FALSE;
    }
    fflush(f);

    if (flock(fd, LOCK_UN) == -1) {
	message(MSG_ERR, "cannot unlock %s (%s)\n", PIDFILE, strerror(errno));
	close(fd);
	return FALSE;
    }
    close(fd);

    return TRUE;
}


static int pidFetch(void)
{

/* either return the value in the pidfile or return 0 if an error */

    FILE *f;
    int pid;

    if (!(f = fopen(PIDFILE, "r"))) {
	message(MSG_DEBUG, "cannot open %s\n", PIDFILE);
	return 0;
    }
    fscanf(f, "%d", &pid);
    fclose(f);

    message(MSG_DEBUG, "%s contains [%d] : my pid [%d]\n", PIDFILE, pid, getpid());

    return pid;
}


static BOOLEAN pidErase(void)
{

    if (unlink(PIDFILE) == 0) {
	return TRUE;
    }
    return FALSE;
}


static BOOLEAN pidIsMeRunning(void)
{

    int pid = pidFetch();

    /* see if my pidfile is me? */

    if (pid == getpid()) {
	message(MSG_DEBUG, "pid [%d] is me!\n", pid);
	return TRUE;
    }
    message(MSG_DEBUG, "pid [%d] is NOT me\n", pid);

    return FALSE;
}


static BOOLEAN pidIsRunning(void)
{

/* returns TRUE if there is general notion
   of the saved pid representing a running process */

    int pid = pidFetch();

    /* pidfile is gone or ... ? */

    if (pid == 0) {
	return FALSE;
    }
    /* is saved pid me */

    if (pidIsMeRunning()) {
	return TRUE;
    }
    /* DONT accidentally kill off every process or all in process group
     * attempting to do this test with pid <= -1 
     * in case pidfile was hacked
     */

    if (pid > 0) {
	if ((kill(pid, 0) == -1) && (errno == ESRCH)) {
	    message(MSG_DEBUG, "fetched pid [%d] is not a running process\n", pid);
	    return FALSE;
	} else {
	    message(MSG_DEBUG, "fetched pid [%d] is a running process\n", pid);
	}
    }
    return TRUE;
}



static void shutdown(int i)
{
    message(MSG_TEST, "Shutting down...\n");

    if (bDaemon) {

	/* do clean up */

	pidErase();
    }
    logSyslog(LOG_NOTICE, "Shutting down...\n");

    exit(i);
}



static BOOLEAN isValidStartTime(char *szTime)
{

    int iReturn = TRUE;

/* now is a valid start time! */

    if (strncmp(szTime, "now", 3) == 0) {
	return FALSE;
    }
    if (strlen(szTime) != 5) {
	iReturn = FALSE;
    }
    if (szTime[2] != ':') {
	iReturn = FALSE;
    }
    if (
	   (!isdigit(szTime[0])) ||
	   (!isdigit(szTime[1])) ||
	   (!isdigit(szTime[3])) ||
	   (!isdigit(szTime[4]))
	) {
	iReturn = FALSE;
    }
    if (
	   (szTime[0] > '2') ||
	   (szTime[3] > '5')
	) {
	iReturn = FALSE;
    }
    if (
	   (szTime[0] == '2') &&
	   (szTime[1] > '3')
	) {
	iReturn = FALSE;
    }
    if (iReturn == FALSE) {

	message(MSG_ERR, "Invalid initial processing time\n");
    }
    return iReturn;
}


static BOOLEAN isOnTheHour(void)
{

    time_t tNow;
    struct tm tmNow;
    int iHour;
    int iMin;

    tNow = time(NULL);
    tmNow = *localtime(&tNow);

    message(MSG_TEST, "check if time is on the hour...\n");
    message(MSG_TEST, "time now: %d:%d \n", tmNow.tm_hour, tmNow.tm_min);

    if (0 == tmNow.tm_min) {
	message(MSG_TEST, "ok to start hourly jobs\n");
	return TRUE;
    }
    message(MSG_TEST, "not yet...\n");
    return FALSE;

}

static BOOLEAN isFirstOfTheWeek(void)
{

    time_t tNow;
    struct tm tmNow;
    int iHour;
    int iMin;

    tNow = time(NULL);
    tmNow = *localtime(&tNow);

    message(MSG_TEST, "check if Monday...\n");
    message(MSG_TEST, "day of the week: %d \n", tmNow.tm_wday);

    if (1 == tmNow.tm_wday) {
	message(MSG_TEST, "ok to start weekly jobs\n");
	return TRUE;
    }
    message(MSG_TEST, "not yet...\n");
    return FALSE;

}


static BOOLEAN isFirstOfTheMonth(void)
{

    time_t tNow;
    struct tm tmNow;
    int iHour;
    int iMin;

    tNow = time(NULL);
    tmNow = *localtime(&tNow);

    message(MSG_TEST, "check if first of the month...\n");
    message(MSG_TEST, "day of the month: %d \n", tmNow.tm_mday);

    if (1 == tmNow.tm_mday) {
	message(MSG_TEST, "ok to start monthly jobs\n");
	return TRUE;
    }
    message(MSG_TEST, "not yet...\n");
    return FALSE;

}


static BOOLEAN isTimeForNonHourly(char *szT)
{

    time_t tNow;
    struct tm tmNow;
    char t[6];
    int iHour;
    int iMin;


    if (isValidStartTime(szT) == FALSE) {

	message(MSG_ERR, "isTimeForNonHourly got invalid start time\n");
	return FALSE;
    }
    tNow = time(NULL);
    tmNow = *localtime(&tNow);

    strncpy(t, szT, 5);
    t[5] = '\0';

    iHour = atoi(strtok(t, ":"));
    iMin = atoi(strtok(NULL, ":"));

    message(MSG_TEST, "check if time for nonhourly...\n");
    message(MSG_TEST, "time now: %d:%d \n", tmNow.tm_hour, tmNow.tm_min);
    message(MSG_TEST, "time to start: %d:%d \n", iHour, iMin);

    if ((iHour == tmNow.tm_hour) && (iMin == tmNow.tm_min)) {
	message(MSG_TEST, "ok to start nonhourly\n");
	return TRUE;
    }
    message(MSG_TEST, "not yet...\n");
    return FALSE;

}




int main(int argc, char **argv)
{

    int iInterval = 1;		/* interval to run in hours */
    char *szStartTime = "02:30";	/* time to start first processing */

    int i;
    int iHr;			/* hour counter */
    int rc = 0;
    int iOption, long_index;

    struct option options[] =
    {
	{"debug-mode", 0, 0, 'D'},
	{"start-at", 1, 0, 'a'},
	{"test-mode", 0, 0, 'T'},
	{"usage", 0, 0, '?'},
	{"verbose-mode", 0, 0, 'V'},
	{"version", 0, 0, 'v'},
	{0, 0, 0, 0}
    };


    /* dont like the idea of not running under one of our names */

    if (!isMyDaemonName(argv[0])) {
	message(MSG_ERR, "Imposter! %s\n", argv[0]);
	exit(1);
    }

    logSetMyName("watchcrond");

   /* SET DEFAULT OPERATIONAL MODE */
   
   setOpMode( MODE_NORMAL );
      
   
    /* get parameters and set flags */

    while (1) {
	iOption = getopt_long(argc, argv, "DTVf:a:uv?", options, &long_index);
	if (iOption == EOF)
	    break;

	switch ((char) iOption) {


	case 'D':
	    setOpMode( MODE_DEBUG);
	    break;

	case 'a':
	    szStartTime = optarg;
	    break;

	case 'T':
	    setOpMode( MODE_TEST);
	    break;

	case 'u':
	    usage(argv[0]);
	    break;

	case 'V':
	    setOpMode( MODE_VERBOSE);
	    break;

	case 'v':
	    version();
	    break;

	case '?':
	    usage(argv[0]);
	    break;
	}
    }


    /* check out validity of daemon option parameters before continuing */




    if (isValidStartTime(szStartTime) == FALSE) {
	exit(1);
    }
    message(MSG_TEST, "Initial nonhourly processing time: %s\n", szStartTime);


if ( !inTestMode() ) {
   

   
    /* if we will be a daemon then fork now */

    if (!pidIsRunning()) {

	message(MSG_TEST, "Starting watchlog daemon\n");

	switch (fork()) {

	case -1:
	    message(MSG_ERR, "Error forking daemon [%d]\n", getpid());
	    exit(0);
	    break;

	case 0:
	    /* this process is the child
	     * so continue to run
	     */
	    message(MSG_TEST, "daemon fork is OK! [%d]\n", getpid());
	    (void) setsid();

	    logSyslog(LOG_NOTICE, "Starting Up... (watchcrond-" VERSION
		      "-" PATCHLEVEL ")\n");
	    if (!pidSave()) {
		shutdown(1);
	    }
	    break;

	default:
	    /* this process is the parent process
	     * so exit thereby letting only the 
	     * child continue to run as the daemon
	     */

	    message(MSG_TEST, "daemon parent is exiting [%d]\n", getpid());
	    _exit(0);
	}

    } else {

	message(MSG_ERR, "Daemon is already running!\n");
	logSyslog(LOG_NOTICE, "Exiting... Daemon is already running!\n");

	exit(1);

    }

} /*endif not test mode */

    /* main server loop */
    while (1) {

     if (!inTestMode()) {

	if (!pidIsMeRunning()) {
	    message(MSG_ERR, "Saved PID is NOT me!\n");
	    logSyslog(LOG_ERR, "Cannot verify my PID!\n");
	    shutdown(1);
	}
      }

       
       if (isOnTheHour()) {

	    message(MSG_TEST, "Starting hourly processing...\n");

	    if (!inTestMode()) {
                
	        rc = system(DOHOURLY);
		if (rc > 0) {
		    message(MSG_ERR, "Problem with hourly processing\n");
		}
	    }
	   message(MSG_TEST, "Finished hourly processing...\n");
	}

       /* see if time to do nonhourly stuff */

	if (isTimeForNonHourly(szStartTime)) {
	   
            message(MSG_TEST, "Starting daily processing...\n");
	    if (!inTestMode()) {
		rc = system(DODAILY);
		if (rc > 0) {
		    message(MSG_ERR, "Problem with daily processing\n");
		}
	    }
	   message(MSG_TEST, "Finished daily processing...\n");
	   
	    if (isFirstOfTheWeek()) {
	    message(MSG_TEST, "Starting weekly processing...\n");       
	        if (!inTestMode()) {
		    rc = system(DOWEEKLY);
		    if (rc > 0) {
		        message(MSG_ERR, "Problem with weekly processing\n");
		    }
	        }
	    message(MSG_TEST, "Finished weekly processing...\n");    
	    }
	   
	   
	   
	    if (isFirstOfTheMonth()) {
	    message(MSG_TEST, "Starting monthly processing...\n");       
	        if (!inTestMode()) {
		    rc = system(DOMONTHLY);
		    if (rc > 0) {
		        message(MSG_ERR, "Problem with monthly processing\n");
		    }
	        }
	    message(MSG_TEST, "Finished monthly processing...\n");    
	    }
	
	}
       
	sleep(60);

    }				/* end while server loop */
    shutdown(rc);

    return (0);			/* gcc squawks about this not being here */
}
