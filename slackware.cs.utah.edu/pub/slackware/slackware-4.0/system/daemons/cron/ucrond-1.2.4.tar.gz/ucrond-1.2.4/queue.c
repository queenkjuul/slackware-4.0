/* $Id: queue.c,v 1.4 1999/03/04 02:25:16 alinden Exp $ */

/*
*  File:            : queue.c
*  Written by       : alinden@gmx.de
*  Compiler         : gcc 2.7.2 on Linux 2.0.33
*  Portability      : Should be POSIX compliant
*  Copyright:       : GPL
*
*  DESCRIPTION: Routines for command batch queue
*/

#include "conf.h"
#include "crond.h"
#include "extern.h"

void msgout(char *);
char *cpstr(size_t, char *, ...);
void run_proc(CONFIG *);
void rmpid(void);
void runqueue(time_t ntmr);
int cmd_queued(CONFIG *); 

CONFIG *queue[32];   /* job queue */ 
unsigned char inind=0,outind=0; /* in out index */
static int numqueue=0; /* entries in queue */

#define inc32(p) (p)=++(p) & 0x1f
#define dec32(p) (p)=--(p) & 0x1f

void storequeue(CONFIG *tbuf, char usebatch)  /* store command in queue */
{
	if(tbuf->pid)
	{
		if(logfile != NULL)
			msgout(cpstr(256, "Still running: %s", (tbuf->jobid != NULL)?(tbuf->jobid):(tbuf->cmdstr)));

		return;
	}		

	if(cmd_queued(tbuf))
	{
		if(logfile != NULL)
			msgout(cpstr(256, "Still queued: %s", (tbuf->jobid != NULL)?(tbuf->jobid):(tbuf->cmdstr)));

		return;
	}			
	
	if(numqueue == 0)
	{
		numqueue++;
		queue[inind] = tbuf;
		inc32(inind);
		run_proc(tbuf);
		return;
	}	

	if((usebatch == 0 &&  tbuf->bopt == 0) || numqueue == 31)
	{
		run_proc(tbuf);
		return;
	}

	numqueue++;
	queue[inind] = tbuf;
	inc32(inind);

	if(logfile != NULL)
		msgout(cpstr(256, "User:%s Queue >#%d:%s", tbuf->username, numqueue-1, (tbuf->jobid != NULL)?(tbuf->jobid):(tbuf->cmdstr)));
}		

void runqueue(time_t ntmr)   /* run command from queue */
{
	static char lastroot=0;
	unsigned char i,i2,out2;
	
	sigchld = 0;
	rmpid();

	if(numqueue == 0)
		return;

	if(queue[outind] != NULL && queue[outind]->pid && 
	queue[outind]->lastexec+qtimeout > ntmr && ntmr > queue[outind]->lastexec)
		return;
	
	if(numqueue-- == 1)
	{
		inind = outind = lastroot = 0;
		return;
	}

	inc32(outind);
	out2 = outind;

	if(lastroot == 0)   /* priority */
	{
		i = out2;
		
		do
		{
			if(queue[i]->cmain || strcmp(queue[i]->username, "root") == 0)
			{
				out2 = i;
				dec32(outind);
				lastroot = 1;
				break;
			}
			inc32(i);
		}
		while(i != inind);
	}
	else lastroot = 0;
	
	if(logfile != NULL)
		msgout(cpstr(256, "User:%s Queue <#%d:%s", queue[out2]->username, numqueue, (queue[out2]->jobid != NULL)?(queue[out2]->jobid):(queue[out2]->cmdstr)));

	run_proc(queue[out2]);

	if(lastroot)
	{
		for(i=i2=out2; i != inind; inc32(i))
		{
			inc32(i2);
			queue[i] = queue[i2];
		}
		dec32(inind);
	}
}

int cmd_queued(CONFIG *tbuf)  /* return 1 if command is still on queue */
{
	unsigned char outind2;

	for(outind2 = outind; outind2 != inind; inc32(outind2))
	{
		if(queue[outind2] == tbuf)
			return(1);
	}
	return(0);
}

void flushqueue(void)  /* run all commands in queue */
{
	char uflush=0;
	
	if(numqueue > 1)
		uflush = 1;

	while(numqueue > 1)
	{
		if(queue[(inc32(outind))] != NULL)
			run_proc(queue[outind]);

		numqueue--;
	}
	numqueue = inind = outind = 0;
	
	if(logfile != NULL && uflush)
		msgout("Queue flushed to read crontabs");

	return;
}
	
void flushqctab(char *ctab)    /* flush queue for user, ctab = NULL: root */
{
	unsigned char i,i2,i3;
	char uflush=0;

	if(numqueue)
	{
		i = outind;
		while(i != inind)
		{
			if(queue[i] != NULL && ((ctab == NULL && queue[i]->cmain) ||
			  (ctab != NULL && ! queue[i]->cmain && strcmp(queue[i]->username, ctab) == 0)))
			{
				if(i == outind)  /* running job on queue */
					queue[i] = NULL;
				else
				{
					run_proc(queue[i]);
					
					for(i2 = i3 = i; i2 != inind; inc32(i2))
					{
						inc32(i3);
						queue[i2] = queue[i3];
					}
						
					numqueue--;
					dec32(inind);
					uflush = 1;

					continue;
				}
			}
			inc32(i);
		}
		if(uflush && logfile != NULL)
			msgout(cpstr(256, "Jobs for %s flushed from queue (executed)", (ctab == NULL)?("root"):(ctab)));
	}
}

