/* $Id: extern.h,v 1.4 1999/03/16 18:53:16 alinden Exp $ */

extern unsigned long uptime,starttime;
extern unsigned period;
extern char *logfile,sigusr;
extern char logfnam[];
extern unsigned qtimeout;
extern int njobs;
extern unsigned cperiod;
extern int svctrl;
extern int svsock;
extern char sigchld;
extern int rtabnice;
extern int utabnice;
extern NVR *nvrblock;
extern CONFIG *cblock;
