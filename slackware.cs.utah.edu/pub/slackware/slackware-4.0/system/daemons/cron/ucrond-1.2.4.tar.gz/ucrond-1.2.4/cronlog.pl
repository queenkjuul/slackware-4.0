#!/usr/bin/perl

$MINLINES=2000;
$MAXLINES=3000;

@LOGFILES=('/var/log/syslog/debug',
	'/var/log/syslog/messages',
	'/var/log/syslog/warnings',
	'/var/adm/deliver.errlog',
	'/var/adm/xferlog',
	'/var/spool/uucp/Log',
	'/var/spool/uucp/Stats',
	'/var/spool/smail/log/logfile',
	'/var/log/sudo.log',
	'/var/log/sulog',
	'/var/log/cron',
	'/var/log/postgres',
	'/var/log/mgetty.modem',
	'/var/log/isdncalls'
	);

for(@LOGFILES)
{
	unless(open(LOGFILE, "+<$_"))
	{
		warn "cannot open $_: $!\n";
		next;
	}
	$i = 0;
	$i++ while(<LOGFILE>);
	if($i <= $MAXLINES)
	{
		close LOGFILE;
		next;
	}

# It's probably better not to set flocks here	

	seek(LOGFILE, 0, 0);
	$i-=$MINLINES;
	while(<LOGFILE>) { last if(! --$i) }
	$wpos = 0;
	while(<LOGFILE>)
	{
		$rpos = tell(LOGFILE);
		seek(LOGFILE, $wpos, 0);
		print LOGFILE;
		$wpos = tell(LOGFILE);
		seek(LOGFILE, $rpos, 0);
	}
	truncate(LOGFILE, $wpos);
	close LOGFILE;
}
