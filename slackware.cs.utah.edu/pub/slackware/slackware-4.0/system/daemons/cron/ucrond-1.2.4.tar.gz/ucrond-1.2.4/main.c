/* $Id: main.c,v 1.6 1999/03/16 18:52:44 alinden Exp $ */

/*
*  File             : main.c
*  Written by       : alinden@gmx.de
*  Compiler         : gcc 2.7.2 on Linux 2.0.33
*  Portability      : Should be POSIX compliant  
*  Copyright:       : GPL
*
*  DESCRIPTION: Startup routines
*/

#include "conf.h"
#include "crond.h"
#include "extern.h"

void read_config(void);
int write_upfile(void);
void msgout(char *); 
void syslogw(char *, int);
int sig_term(void);
void sig_usr(void);
void sig_usr2(void);
void sig_chld(void);
int chktm(char *, int);
void run_proc(CONFIG *);
int dwtab(CONFIG *, struct tm *); 
time_t runtab(CONFIG *, time_t);
char *cpstr(size_t, char *, ...);
int cmd_queued(CONFIG *);
void storequeue(CONFIG *, char);
void updt(void);

void daemon_init(void)
{
	pid_t pid;
	FILE *pidfile;
	unsigned long lpid;
	int fdes;

	/* Fork a daemon process */

	if((pid = fork()) < 0) 
	{	
		perror("");
		exit(1);
	} 

	if(pid)
		exit(0);

	/* verify if another daemon is running */

	if((pidfile = fopen(PIDFILE, "r")) != NULL)
	{
		if(fscanf(pidfile, "%lu", &lpid))
		{
			fclose(pidfile);
			errno = 0;
		
			if((lpid == (unsigned long)getpid()) || (kill((pid_t)lpid, 0) && errno == ESRCH))
				unlink(PIDFILE);
			else	
			{
				fprintf(stderr, "Another daemon is already running (PID: %lu)\n", lpid);
				exit(1);
			}	
		}
	}
	
	/* Create a PID file */ 

	if((fdes = open(PIDFILE, O_WRONLY | O_CREAT | O_EXCL, 0644)) == -1 || (pidfile = fdopen(fdes, "w")) == NULL)
	{
		perror("Cannot create PID file");
		exit(1);
	}
	
	fprintf(pidfile, "%lu\n", (unsigned long)getpid());
	fclose(pidfile);
	
	umask(022);
	setsid();
}

void init_uptime(void)  /* Read the uptime file */
{
	FILE *timefile;
	
	if((timefile = fopen(TIMEFILE, "r")) != NULL)
	{
		if(fscanf(timefile, "%lu\n%lu", &starttime, &uptime) > 1)
		{
			fclose(timefile);
			return;
		}
		fclose(timefile);
	}		

	/* If necessary,initialize it */

	starttime = time(NULL);
	if(write_upfile() == 0)
	{
		syslogw("New timefile created", LOG_INFO);
		return;
	}
	fputs("Can't write uptime file\n", stderr);
	unlink(PIDFILE);
	exit(1);
}	

void runimd(void)   /* test for immediate execution (D-option used) */
{
	struct stat buf;
	time_t ltm,ctm;
	CONFIG *tbuf;
	int jobs=0;
	
	if(stat(TIMEFILE, &buf))
		return;

	while(time(&ltm) < 0)
		sleep(1);

	if(! buf.st_mtime || ! ltm || buf.st_mtime > ltm)
		return;
	
	if(buf.st_mtime > 60)
		buf.st_mtime -= 60;

	for(tbuf = cblock; tbuf != NULL; tbuf = tbuf->nblock)
	{ 
		if(tbuf->dopt && ! tbuf->pid && ! cmd_queued(tbuf) && 
		  (ctm = runtab(tbuf, buf.st_mtime)) > -1 && ctm <= ltm)
		{
			storequeue(tbuf, 1);
			jobs++;
		}		
	}

	if(jobs)
		syslogw(cpstr(100, "executed %d jobs after restart", jobs), LOG_INFO); 
}

CONFIG *fnduser(char *username)  /* find first block of a user */
{
	CONFIG *tbuf;
	char cmain=0;

	if(strcmp(username, NCTROOT) == 0)
		cmain = 1;

	for(tbuf = cblock; tbuf != NULL; tbuf = tbuf->nuser)
	{
		if((cmain && tbuf->cmain) ||
		  (! cmain && ! tbuf->cmain && strcmp(username, tbuf->username) == 0))
			break;
	}
	return(tbuf);
}
	
void resimd(void)   /* test for restart file */
{
	CONFIG *tbuf,*pbuf=NULL;
	FILE *rstfile;
	int jobs=0;
	char *rfield[4];
	char tcmd[10*1025];
	
	if((rstfile = fopen(SERVREST, "r")) == NULL)
		return;

	tcmd[(10*1025)-1]=0;

	while(fgets(tcmd, 10*1024, rstfile) != NULL)
	{
		*(tcmd+strcspn(tcmd, "\n")) = 0;
		
		if(strncmp(tcmd, "%USER", 5) == 0)
		{
			pbuf = fnduser(tcmd+6);
			continue;
		}	

		if(pbuf == NULL)
			continue;
		
		if(strncmp(tcmd, "%END", 4) == 0)
			break;

		if((rfield[0] = strtok(tcmd, "\t\n ")) == NULL ||  
		    strcmp(rfield[0], "%SUBJ") ||
		    (rfield[1] = strtok(NULL, "\t\n ")) == NULL ||  /* name */
		    (rfield[2] = strtok(NULL, "\t\n ")) == NULL ||  /* subject */
		    (rfield[3] = strtok(NULL, "\0")) == NULL)       /* command */
			continue;
		
		tbuf = pbuf;
		while(tbuf != NULL)  /* find entry */
		{
			if(strcmp(tbuf->username, rfield[1]) == 0 && (tbuf->jobid == NULL || strcmp(tbuf->jobid, rfield[2]) == 0) &&
			   strcmp(tbuf->cmdstr, rfield[3]) == 0)
				break;

			tbuf = tbuf->nblock;

			if(tbuf != NULL && tbuf->stblock)
				tbuf = NULL;
		}

		if(tbuf == NULL)
			continue;

		storequeue(tbuf, 1);
		jobs++;
	}
	fclose(rstfile);
	
	if(jobs)
		syslogw(cpstr(100, "restarted %d interrupted jobs", jobs), LOG_INFO);
}

int main(int argc, char *argv[])
{
	unsigned bdelay = BDELAY;
	sigset_t sigmask;
	struct sigaction act;
	int i; 

	if(argc > 1 && strcmp(argv[1], "--version") == 0)
	{
		puts(VERSION);
		exit(0);
	}

	for(i = 1; i < argc; i++)
	{
		if( *argv[i] != '-' )
			continue;

		switch(*(argv[i]+1))
		{
			case 'u':
					if(++i < argc) 
						period = atoi(argv[i]);
					break;
			case 'n':
					if(++i < argc)
						rtabnice = atoi(argv[i]);
					break;
			case 'm':
					if(++i < argc)
						utabnice = atoi(argv[i]);
					break;
			case 'd':
					if(++i < argc)
						bdelay = atoi(argv[i]);
					break;		
			case 'l':
					if(++i < argc)
					{
						strncpy(logfnam, argv[i], 80);
						logfnam[79] = 0;
						logfile = logfnam;
					}	
					break;
			case 't':
					if(++i < argc)
						qtimeout = atoi(argv[i]);
					break;
			default:
					fprintf(stderr, "%s%s\n", "Unknown option: ", argv[i]);
		}
	}

	daemon_init();
	init_uptime();
	mkdir(SERVDIR, 0755);

	syslogw("restart", LOG_INFO);
	
	if(bdelay)
	{
		syslogw(cpstr(100, "delayed %ds", bdelay), LOG_INFO);
		sleep(bdelay);
	}	
		
	read_config();

	if(period < 1)
		period = 1;

	cperiod = period;	

	sigfillset (&sigmask);
	sigdelset(&sigmask, SIGTERM);	
	sigdelset(&sigmask, SIGALRM);
	sigdelset(&sigmask, SIGABRT);
	sigdelset(&sigmask, SIGSEGV);
	sigdelset(&sigmask, SIGILL);
	sigdelset(&sigmask, SIGFPE);
	sigdelset(&sigmask, SIGHUP);
	sigdelset(&sigmask, SIGUSR1);
	sigdelset(&sigmask, SIGUSR2);
	sigdelset(&sigmask, SIGCHLD);

	i = 0;

	act.sa_handler = (void *)sig_term;
	sigfillset(&act.sa_mask);
	act.sa_flags = 0;
	if(sigaction(SIGTERM, &act, NULL) < 0 ||
	sigaction(SIGABRT, &act, NULL) < 0 ||
	sigaction(SIGSEGV, &act, NULL) < 0 ||
	sigaction(SIGILL, &act, NULL) < 0 ||
	sigaction(SIGFPE, &act, NULL) < 0)
		i = 1;

	act.sa_handler = (void *)sig_chld;
	sigemptyset(&act.sa_mask);
	act.sa_flags = SA_NOCLDSTOP | SA_RESTART;
	if(sigaction(SIGCHLD, &act, NULL) < 0)
		i = 1;

	act.sa_handler = (void *)sig_usr2;
	sigemptyset(&act.sa_mask);
	act.sa_flags = SA_RESTART;	
	if(sigaction(SIGUSR2, &act, NULL) < 0)
		i = 1;

	act.sa_handler = (void *)sig_usr;
	sigemptyset(&act.sa_mask);
	act.sa_flags = SA_RESTART;
	if(sigaction(SIGUSR1, &act, NULL) < 0 ||
	sigaction(SIGHUP, &act, NULL) < 0 || i)
		syslogw("Can't catch signals", LOG_WARNING);

	sigprocmask(SIG_SETMASK, &sigmask, NULL);
		
	resimd();
	unlink(SERVREST);
	runimd();	
	
	updt();

	exit(0);
}
