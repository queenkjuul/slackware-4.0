/* $Id: daemon.c,v 1.7 1999/03/01 19:00:04 alinden Exp $ */

/*
*  File             : daemon.c
*  Written by       : alinden@gmx.de
*  Compiler         : gcc 2.7.2 on Linux 2.0.33
*  Portability      : Should be POSIX compliant
*  Copyright:       : GPL
*
*  DESCRIPTION: Contains the remaining daemon stuff. Crond jumps into updt() 
*  and calls runproc() periodically to execute programs as necessary.
*/

#include "conf.h"
#include "crond.h"

/* globals as defined in extern.h */

unsigned long uptime=0,starttime=0;
unsigned period=PERIOD;
char *logfile=NULL,sigusr=0;
char logfnam[80];
int rtabnice=RTABNICE;
int utabnice=UTABNICE;
unsigned qtimeout=DQTMOUT;
int svctrl=-1,svsock=-1,njobs=0;
unsigned cperiod;
char sigchld=0,sigusr2=0,tjmp=0;
NVR *nvrblock=NULL;
CONFIG *cblock=NULL;
	
void read_config(void);
void rmpid(void);
void msgout(char *);
char *cpstr(size_t, char *, ...);
void read_fifo(void);
void storequeue(CONFIG *, char);
void runqueue(time_t ntmr);
void flushqueue(void);
int cmd_queued(CONFIG *); 

void syslogm(char *message, int priority)  /* message to syslog */
{
	openlog("crond", LOG_PID, LOG_CRON);
	syslog(priority, message);
	closelog();
}

void syslogw(char *message, int priority)  /* message to syslog and logfile */
{
	char *buf;
	int slen; 

	if((buf = strstr(message, "%m")) != NULL && *(buf+2) == 0 && (slen = strlen(message)) < 200)
	{
		buf = strncpy(cpstr(0, NULL), message, slen-2);
		strncpy(buf+slen-2, strerror(errno), 100);
		buf[300] = 0;
		message = buf;
	}	

	syslogm(message, priority);

	if(logfile != NULL)
		msgout(message);
}

void msgout(char *logmsg)  /* append messages to logfile */
{
	FILE *logfl;
	time_t ltm;
	struct tm *ltime;
	char tmbuf[20];
	
	if((logfl = fopen(logfile, "a")) == NULL)
		return;

	while(time(&ltm) < 0)
		sleep(1);
		
	ltime = localtime(&ltm);
	strftime(tmbuf, 20, "%b  %d %a %H:%M" ,ltime);

	fprintf(logfl, "%s  %s\n", tmbuf, logmsg);
	fclose(logfl);

	return;
}

/* Write/update the uptime file. This contains the time at first startup
   (starttime), \n, relative elapsed time (uptime) in seconds */

int write_upfile(void)
{
	FILE *timefile;

	if((timefile = fopen(TIMEFILE, "w")) != NULL)
	{
		fprintf(timefile, "%lu\n%lu\n", starttime, uptime);
		fclose(timefile);
		return(0);
	}
	syslogw("Uptime file: %m", LOG_ERR);
	return(-1);
}	

/* cat strings to circulating buffers, max = length of buffer 
   max = 0: only return buffer */

char *cpstr(size_t max, char *fmat, ...)
{
	static char buf[4][1025];
	va_list apl;
	static int bnum=0;

	/* provide 4 buffers */ 

	bnum = ++bnum & 0x03;

	if(! max)
		return(buf[bnum]);
	
	if(max > 1024)
		max = 1024;

	va_start(apl, fmat);
	vsnprintf(buf[bnum], max, fmat, apl);
	buf[bnum][1024] = 0;
	va_end (apl);
	
	return(buf[bnum]);
}

/* return passwd struct for user */

struct passwd *namuid(char *useradr)
{
	struct passwd *pword;

	if((pword = getpwnam(useradr)) == NULL)
	{
		syslogw(cpstr(200, "unknown user: %s", useradr), LOG_ERR);
		return(NULL);
	}	
	return(pword);	
}

void catf(FILE *infile, FILE *outfile)    /* cat file from infile to outfile */
{
	char buf[512];
	size_t inbytes;

	while((inbytes = fread(buf, 1, 512, infile)))
		fwrite(buf, 1, inbytes, outfile);  	 	 
}   

/* test if m,h,d or m field in CONFIG struct matches current time 
   *tbuf points to bitmap entry (month, hours, day or minute ) in CONFIG 
   ctm = current m,h,d or m time value, return 0 if no match */ 

int chktm(unsigned char *tbuf, int ctm)
{
	int bnum = ctm / 8;

	if ( bnum > 7 )
		return(0);

	/* test if the corresponding bit in the array is set */	

	return((int)(tbuf[bnum] << (unsigned)(ctm-bnum*8)) & 0x80);
}  

/* use chktm() to verify if week or day field match current time 
   *tbuf: current CONFIG struct, ltime: current time struct
   return 0 if no match */

int dwtab(CONFIG *tbuf, struct tm *ltime)
{
	int days,weekdays;

	if(! chktm(tbuf->month, ltime->tm_mon+1))
		return(0); 

	if ( tbuf->wdres == 0x03 )  /* both fields unrestricted */
		return(1);
	
	if ( tbuf->wdres & 0x02 )   /* day field unrestricted */
		days = 0;
	else	
		days = chktm(tbuf->days, ltime->tm_mday);

	if ( tbuf->wdres & 0x01 )   /* week field unrestricted */
		weekdays = 0;
	else	
		weekdays = chktm(tbuf->weekday, ltime->tm_wday);

	return(days | weekdays);
}

/* The following was the most reliable method. No problems with DST timezones
   etc. */ 

time_t runtab(CONFIG *tbuf, time_t ltm)
{
	struct tm *ltime;
	int i,nyear;
	time_t upt,ctm;
	
	ltm += 60;

	if(tbuf->period)
	{
		upt = uptime/60;
		ctm = upt/tbuf->period;

		if(tbuf->period == 1 && ctm)
			ctm--;
			
		ctm = (((ctm*tbuf->period)+tbuf->period-upt)*60)+ltm; 

		return(ctm);
	}
	else
	{
		ltime = localtime(&ltm);
		nyear = ltime->tm_year+1;
		
		if(! dwtab(tbuf, ltime))
		{
NDAY:			ltm += (60*60*21);
			ltime = localtime(&ltm);
		
			for(i = 0; ! dwtab(tbuf, ltime); i++)
			{
				if(i > 500)
					return(-1);

				ltm += (60*60*21);
				ltime = localtime(&ltm);
			}
		
			do
			{
				ltm -= (60*60);
				ltime = localtime(&ltm);
				
			} while(dwtab(tbuf, ltime));

			do
			{
				ltm += 60;
				ltime = localtime(&ltm);
				
			} while(! dwtab(tbuf, ltime));
		} 

		for(i = 0; i < (60*30); i++)
		{
			if(! dwtab(tbuf, ltime))
			{
				if(ltime->tm_year > nyear)
					return(-1);
					
				goto NDAY;
			}
			
			if(ltime->tm_min == 0 && ! chktm(tbuf->hours, ltime->tm_hour))
			{
				ltm += (60*60);
				ltime = localtime(&ltm);
				continue;
			}
				
			if(dwtab(tbuf, ltime) && chktm(tbuf->minutes, ltime->tm_min) && chktm(tbuf->hours, ltime->tm_hour))
				return(ltm);
				
			ltm += 60;
			ltime = localtime(&ltm);
		}
	}	
	return(-1);
}

/* Get the FQDN of the host. Thanks to Soenke Jan Peters <peters@simprovement.com> for
   mailing a patch */ 

char *getfqdn(void)
{
	char *fqdn,**h;
	struct hostent *hp;
	char addr[sizeof(struct in_addr)];

	fqdn = cpstr(0, NULL);
	fqdn[1024] = 0;

	/* Try gethostname() */
 
	if(gethostname(fqdn, 1024) == -1)
		return(NULL);

	if(strchr(fqdn, '.') != NULL)
		return(fqdn);
 
	/* Try gethostbyname() */

	if((hp = gethostbyname(fqdn)) == NULL)   
		return(NULL);

	if(strchr(hp->h_name, '.') != NULL)
	{
		strncpy(fqdn, hp->h_name, 1024);
		return(fqdn);
	}

	for(h = hp->h_aliases; *h != NULL; h++)
	{
		if(strchr(*h, '.') != NULL)
		{
			strncpy(fqdn, *h, 1024);
			return(fqdn);
		}	
	}

	/* Try gethostbyaddr() */
 
	memcpy(addr, (char*)hp->h_addr, sizeof(struct in_addr));

	if((hp = gethostbyaddr(addr, hp->h_length, hp->h_addrtype)) == NULL)
		return(NULL);

	if(strchr(hp->h_name, '.') != NULL)
	{
		strncpy(fqdn, hp->h_name, 1024);
		return(fqdn);
	}
 
	for(h = hp->h_aliases; *h != NULL; h++)
	{
		if(strchr(*h, '.') != NULL)
		{
			strncpy(fqdn, *h, 1024);
			return(fqdn);
		}
	}
	return(fqdn);
}

void restore_sigs(void)
{
	setpgrp();
	
	signal(SIGTERM, SIG_DFL);
	signal(SIGCHLD, SIG_DFL);
	signal(SIGABRT, SIG_DFL);
	signal(SIGSEGV, SIG_DFL);
	signal(SIGILL, SIG_DFL);
	signal(SIGFPE, SIG_DFL);
	signal(SIGHUP, SIG_DFL);
	signal(SIGALRM, SIG_DFL);
	signal(SIGUSR1, SIG_DFL);
	signal(SIGUSR2, SIG_DFL);
}

void stenv(CONFIG *tbuf, struct passwd *pword)   /* set the environment */
{
	NVR *nvrbuf;

	putenv(cpstr(1024, "HOME=%s", pword->pw_dir));
	putenv(cpstr(1024, "USER=%s", pword->pw_name));
	putenv("SHELL=/bin/sh");
	putenv(DPATH);

	for(nvrbuf = tbuf->envr; nvrbuf != NULL; nvrbuf = nvrbuf->nblock)
		putenv((char *)nvrbuf+sizeof(NVR));
}

void sig_dexit(int signo) { sleep(1); exit(0); }

void run_proc(CONFIG *tbuf)   /* start a job */
{
	struct stat buf;
	FILE *mpipe,*tmpfile=NULL;
	char *mailto,*mailfrom,*tmpbuf=NULL,*fqdn;
	struct passwd *pword;
	char *usernam;
	pid_t pid;

	if(logfile != NULL)
	{
		if(tbuf->jobid != NULL)
			msgout(cpstr(256, "User:%s Subject:%s", tbuf->username, tbuf->jobid)); 
		else
			msgout(cpstr(256, "User:%s Command:%s", tbuf->username, tbuf->cmdstr)); 
	}		

	if(tbuf->lopt)
	{
		if(tbuf->jobid != NULL)
			syslogm(cpstr(42, "Start %s: %s", tbuf->username, tbuf->jobid), LOG_INFO);
		else
			syslogm(cpstr(42, "Start %s: %s", tbuf->username, tbuf->cmdstr), LOG_INFO);
	}

	cperiod = 1;

	if((pid = fork()) < 0)
	{
		syslogw("cannot fork, command discarded", LOG_ERR);
		sleep(1);
		return;
	}
	
	if(pid) 
	{
		tbuf->pid = pid;
		time(&tbuf->lastexec);
		return;
	}

	restore_sigs();

	if(svsock > -1)
		close(svsock);

	/* set the user id and environment */
	
	usernam=cpstr(1024, "%s", tbuf->username);
	usernam[strcspn(usernam, "@")] = 0;

	if((pword = namuid(usernam)) == NULL)
		exit(0);

	if(setgid(pword->pw_gid) < 0)
	{
		syslogw("setgid(): %m", LOG_ERR);
		exit(0);
	}

	if(initgroups(usernam, pword->pw_gid) < 0)
	{
		syslogw("initgroups(): %m", LOG_ERR);
		exit(0);
	}	

	if(setuid(pword->pw_uid) < 0)
	{
		syslogw("setuid(): %m", LOG_ERR);
		exit(0);
	}
	
	chdir(pword->pw_dir);
	stenv(tbuf, pword);
	sleep(1);
	nice((tbuf->cmain)?(rtabnice):(utabnice)); 

	/* we write the output from the command to a file in /tmp first 
	   to avoid mailbox locking while the program is running */

	dup2(creat((tmpbuf = tmpnam(NULL)), 0600),2);
	dup2(2,1);

	if(tbuf->dopt || tbuf->period)
		signal(SIGTERM, (void *)sig_dexit);
		
	errno = 0;

	if(system(tbuf->cmdstr) && errno)
	{
		syslogw("cannot run the shell, command discarded", LOG_ERR);
		if(tmpbuf != NULL)
			unlink(tmpbuf);
		exit(0);
	}

	/* test if there was output from the job and drop a mail */

	close(1);
	close(2);
	if(stat(tmpbuf, &buf) == 0 && buf.st_size > 0 && (tmpfile = fopen(tmpbuf, "r")) != NULL)
	{
		mailto = getenv("MAILTO");

		if(tbuf->cmain)
		{
			if(strchr(tbuf->username, '@') != NULL)
				mailto = tbuf->username;
			else if(mailto == NULL)
				mailto = "root";
				
		} else if(mailto == NULL)
			mailto = tbuf->username;

		if(*mailto && strcmp(mailto, "\"\""))
		{
			fqdn = getfqdn();
			mailfrom = (tbuf->cmain)?("root"):(pword->pw_name);

			if(fqdn != NULL)
				mailfrom = cpstr(1024, "%s@%s", mailfrom, fqdn);
		
			if((mpipe = popen(cpstr(1024, "%s %s", SENDMAIL, mailto), "w")) != NULL)
			{
				fprintf(mpipe, "From: CROND <%s>\nTo: %s\nSubject: %s\n\nOutput from command: %s\n\n", mailfrom,
				mailto, (tbuf->jobid != NULL)?(tbuf->jobid):("output from job"), tbuf->cmdstr);

				catf(tmpfile, mpipe);

				pclose(mpipe);
			} else
				syslogw("cannot run the mailer: %m", LOG_WARNING);
		}
	}

	if(tmpfile != NULL)
		fclose(tmpfile);	
		
	if(tmpbuf != NULL)
		unlink(tmpbuf);
		
	if(tbuf->dopt || tbuf->period)
		sleep(1);
		
	exit(0);
}

/* adjust execution time after time jump */

char runjmp(time_t ltmr, time_t ltm)
{
	CONFIG *tbuf;
	char njmp=0,er=0;

	for(tbuf = cblock; tbuf != NULL; tbuf = tbuf->nblock)
	{ 
		if(ltm >= ltmr+(120*60) || (ltm < ltmr && ltmr - ltm >= (120*60)) || tbuf->period)
		{
			tbuf->nextexec = runtab(tbuf, ltm);
			er = 1;
		}	
		else
			njmp = 1;
			
	}

	if(er)
		syslogw("time adjustment performed", LOG_INFO);

	return(njmp);
}

void rmpid(void)   /* remove pid's from CONFIG structs of terminated jobs */
{
	CONFIG *tbuf;
	pid_t cpid;

	while((cpid = waitpid(-1, NULL, WNOHANG)) > 0)   /* zombie */
	{
		for(tbuf = cblock; tbuf != NULL; tbuf = tbuf->nblock)
		{
			if(tbuf->pid == cpid)    /* find corresponding control block */
			{
				tbuf->pid = 0;
				break;
			}	
		}
	}
} 

void runproc(time_t ltm)   /* exec programs (periodically executed) */
{
	CONFIG *tbuf;

	for(tbuf = cblock; tbuf != NULL; tbuf = tbuf->nblock)   /* go blockwise through the CONFIG struct */
	{
		if(tbuf->nextexec > -1 && ltm/60 >= tbuf->nextexec/60)
		{
			tbuf->nextexec = runtab(tbuf, ltm);
	 		storequeue(tbuf, tjmp);
	 		
	 	} else if(tbuf->nextexec == -1 && (ltm/120) % (24*60) == 0)
	 		tbuf->nextexec = runtab(tbuf, ltm);
	 	
	}
	tjmp = 0;
}

int sig_term(int signo)  /* terminate */
{
	CONFIG *tbuf;
	char fuser=1,*msgterm;
	FILE *rstfile;
	
	write_upfile();
	unlink(PIDFILE);
	unlink(SERVCTRL);

	/* check for jobs to be restarted */
	
	if(signo == SIGTERM)
	{
		rstfile = NULL;
		for(tbuf = cblock; tbuf != NULL; tbuf = tbuf->nblock)
		{
			if(tbuf->stblock)
				fuser = 1;

			if((tbuf->dopt || tbuf->period) && (tbuf->pid || (tbuf->bopt && cmd_queued(tbuf))))
			{
				if(rstfile == NULL && (rstfile = fopen(SERVREST, "w")) == NULL)
					break;

				if(fuser)
				{
					fprintf(rstfile, "%%USER %s\n", (tbuf->cmain)?(NCTROOT):(tbuf->username));
					fuser = 0;
				}

				fprintf(rstfile, "%%SUBJ %s %s %s\n", tbuf->username, 
				(tbuf->jobid != NULL)?(tbuf->jobid):("-"), tbuf->cmdstr);
			}
		}
		if(rstfile != NULL)
		{
			fprintf(rstfile, "%%END\n");
			fclose(rstfile);
		}
	}

	syslogw((msgterm = cpstr(256, "terminating on signal %d", signo)), (signo == SIGTERM)?(LOG_INFO):(LOG_WARNING));
	fprintf(stderr, "crond: %s\n", msgterm);

	exit(0);
}

void joblst(void)
{
	CONFIG *tbuf;
	FILE *msgfile;
	
	if(logfile == NULL || (msgfile = fopen(logfile, "a")) == NULL)
		return;

	fprintf(msgfile, "\n\nreceived USR2 signal, printing joblist\n\n");

	for(tbuf = cblock; tbuf != NULL; tbuf = tbuf->nblock)
	{
		if(tbuf->stblock)
			fprintf(msgfile, "first entry of user\n");
			
		if(tbuf->nuser)
			fprintf(msgfile, "block chained to next user\n");
			
		if(tbuf->period)
		 	fprintf(msgfile, "U->period:%lu bopt:%d lopt:%d cmain:%d user:%s cmd:%s\n", tbuf->period, tbuf->bopt, tbuf->lopt,
		 	        tbuf->cmain, tbuf->username, tbuf->cmdstr);
		else
			fprintf(msgfile, "C->dopt:%d bopt:%d lopt:%d cmain:%d user:%s cmd:%s\n", tbuf->dopt, tbuf->bopt, tbuf->lopt,
			        tbuf->cmain, tbuf->username, tbuf->cmdstr);

		if(tbuf->jobid != NULL)
			fprintf(msgfile, "subj: %s\n", tbuf->jobid);
		
		fprintf(msgfile, "-----------------------------------------\n");
	}
	fclose(msgfile);
}

void sig_usr2(int signo) { sigusr2 = 1; }
void sig_usr(int signo)  { sigusr = 1;  }
void sig_chld(int signo) { sigchld = 1; }	
		
void updt(void)   /* main routine of running daemon */
{
	time_t ntmr,mins2,mins,ltmr = time(NULL);
	int maxfds,addrlen;
	struct sockaddr_un client;
	char rp;
	fd_set readfds;
	struct timeval tv;

	while(1)
	{
		FD_ZERO(&readfds);
		
		maxfds = svctrl+1;
		
		if(maxfds < 1)
			maxfds = 1;

		while(time(&ntmr) < 1)
			sleep(1);

		mins2 = ntmr / 60;
		mins2 = (mins2*60)+60;

		do
		{
			if(sigchld)
				runqueue(ntmr);

			mins = ntmr / 60;
			mins = (mins*60)+60;
			mins -= ntmr;  /* sleep time */
			
			tv.tv_sec = mins;
			tv.tv_usec = 0;
			
			if(svctrl > -1)
				FD_SET(svctrl, &readfds);

			rp = 0;
	
			/* Awake on events */	

			if(select(maxfds, &readfds, NULL, NULL, &tv) > 0 && FD_ISSET(svctrl, &readfds))
				rp = 1;

			if(sigusr)
			{
				sigusr = 0;
				read_config();
			}	

			if(sigusr2)
			{
				sigusr2 = 0;
				joblst();
			}

			while(time(&ntmr) < 1)
				sleep(1);

			if(ltmr > ntmr || ntmr >= ltmr+120)  /* time jump */
			{
				if(runjmp(ltmr, ntmr) && ntmr > ltmr)
					tjmp = 1;

				if(rp)
					uptime -= 30;	
					
				mins2 = ntmr;
			}
			
			if(rp)  /* socket connection */
			{
				if((svsock = accept(svctrl, (struct sockaddr *)&client, &addrlen)) == -1)
					syslogw("accept call failed: %m", LOG_ERR);
				else
				{
					read_fifo();
					close(svsock);
					svsock = -1;
				}
			}

		} while(ntmr < mins2);
		
		uptime += 60;
		runqueue(ntmr);

		ltmr = ntmr;	 	 
		
		if(--cperiod == 0)
		{
			write_upfile();
			cperiod = period;
		}	
		
		runproc(ntmr);
	}
}
