/* $Id: build.c,v 1.6 1999/03/12 04:36:19 alinden Exp $ */

/*
*  File             : build.c
*  Written by       : alinden@gmx.de
*  Compiler         : gcc 2.7.2 on Linux 2.0.33
*  Portability      : Should be POSIX compliant  
*  Copyright:       : GPL
*
*  DESCRIPTION: Contains the stuff needed to build the crontab database.
*  This is done by calling read_config(). The list is concatenated twice for user
*  and entry. To be memory and CPU efficient, the time fields are stored as a bit
*  oriented index within this struct. For example, the minute field is an array of
*  60 bits in 8 bytes where each bit corresponds to a minute (0-59). A lookup then
*  needs only one access to check if the bit of the current minute is set. 
*/

#include "conf.h"
#include "crond.h"
#include "extern.h"

void msgout(char *); 
void syslogw(char *, int);
char *cpstr(size_t, char *, ...);
void rmenv(NVR *);
int create_socket(char *sockname);
time_t runtab(CONFIG *, time_t);
int chk_tmstr(char *, unsigned char *, int);
void lbnm(char *, int);
void flushqueue(void);
void flushqctab(char *);

unsigned long uhours(char **inbuf)   /* returns number of minutes for U option */ 
{                                    /* inbuf: field array */                
	unsigned long tminutes,timeval;

	tminutes = timeval = 0;       /* minute field */
	if ( *inbuf[0] != '*' && sscanf(inbuf[0], "%lu", &timeval) < 1 )
		return(0);
	tminutes = timeval;

	timeval = 0;                 /* hour field */           
	if ( *inbuf[1] != '*' && sscanf(inbuf[1], "%lu" , &timeval ) < 1 )
		return(0);
	tminutes += timeval*60;

	timeval = 0;                 /* day field */
	if ( *inbuf[2] != '*' && sscanf(inbuf[2], "%lu", &timeval) < 1 )
		return(0);
	tminutes += timeval*24*60;

	timeval = 0;                 /* week field */
	if ( *inbuf[3] != '*' && sscanf(inbuf[3], "%lu", &timeval) < 1 )
		return(0);
	tminutes += timeval*24*60*7;
	
	return(tminutes);
}

int rmuser(char *ctab)  /* remove a user */
{
	CONFIG *tbuf,*pbuf,*puser;
	int nentries=0,suser=0;
	
	if(strcmp(ctab, NCTROOT) == 0)
		ctab = NULL;

	tbuf = pbuf = puser = cblock;

	while(tbuf != NULL)  /* find user */
	{
		if((ctab == NULL && tbuf->cmain) ||
		  (ctab != NULL && ! tbuf->cmain && strcmp(ctab, tbuf->username) == 0))
			break;

		puser = tbuf;
		suser = 1;
		tbuf = tbuf->nuser;
	}
	
	if(tbuf == NULL)
		return(0);
		
	flushqctab(ctab);
	rmenv(tbuf->envr);

	do   /* remove entries for user */
	{
		pbuf = tbuf;
		tbuf = tbuf->nblock;
		free(pbuf);
		nentries++;
		
	} while(tbuf != NULL && tbuf->stblock == 0);

	/* close the chain */

	if(! suser)
		cblock = tbuf;
	else
	{
		puser->nuser = tbuf;

		do
		{
			pbuf = puser;
			puser = puser->nblock;
		
		} while(puser != NULL && puser->stblock == 0);

		pbuf->nblock = tbuf;
	}	
	
	return(nentries);
}

void rmenv(NVR *nvrbuf)  /* remove environment for user */
{
	NVR *pvrbuf;
	
	while(nvrbuf != NULL)
	{
		pvrbuf = nvrbuf;
		nvrbuf = nvrbuf->nblock;
		free(pvrbuf);
	}
}			

int adduser(CONFIG *tbuf)  /* add a user */
{
	CONFIG *pbuf=NULL,*nbuf,*ostart;
	int nentries=0;
	
	if(tbuf->cmain || strcmp(tbuf->username, "root") == 0)  /* priority */
	{
		ostart = cblock;
		cblock = tbuf;
		tbuf->nuser = ostart;
	}	
	else
	{
		ostart = NULL;
		
		if(cblock == NULL)
			cblock = tbuf;
		else
		{
			for(pbuf=cblock; pbuf != NULL; pbuf=pbuf->nuser)
				nbuf=pbuf;
				
			nbuf->nuser = tbuf;
			
			while(nbuf != NULL)
			{
				pbuf = nbuf;
				nbuf = nbuf->nblock;
			}
			pbuf->nblock = tbuf;
		}
	}
	
	while(tbuf != NULL)
	{
		pbuf = tbuf;
		tbuf = tbuf->nblock;
		nentries++;
	}
	pbuf->nblock = ostart;
	
	return(nentries);
}

/* take instr as crontab entry and separate tokens until command is reached
   return array of fields or NULL */

char **sptoken(char *instr) 
{
	static char *ninstr[20];
	int i,i2; 		    			 
			
	if(! *instr)
		return(NULL);
		
	if((ninstr[0] = strtok(instr, "\t ")) == NULL)
		return(NULL);
		
	for(i = 1; i < 6; i++)
	{
		if((ninstr[i] = strtok(NULL, "\t ")) == NULL)
			return(NULL);
	}

	i--;

	while(*ninstr[i] == '-')  /* options field */
	{
		if(i == 19 || (ninstr[++i] = strtok(NULL, "\t ")) == NULL)
			return(NULL);
	}

	ninstr[i+1] = NULL;

	i2 = strcspn(ninstr[i], "\n");
	
	if(*(ninstr[i]+i2) == '\n')
		*(ninstr[i]+i2) = 0;
	else
	{
		*(ninstr[i]+i2) = ' ';
		*(ninstr[i]+strcspn(ninstr[i], "\n")) = 0;   /* chop trailing \n */
	}	

	return(ninstr);
}	

/* check if crontab is owned by user, return -1 if not, 0 if user crontab, 1 if root crontab */

char userperm(char *ctab)
{					       			
	struct passwd *pword;
	char *username,cmain;
	struct stat buf;

	if(strcmp(ctab, NCTROOT) == 0)
	{
		username = "root";
		cmain = 1;
	}
	else
	{
		username = ctab;
		cmain = 0;
	}	

	while(stat(ctab, &buf) < 0)
	{
		if(errno != ENOMEM)
		{
			syslogw(cpstr(100, "userperm(): stat for %s failed", ctab), LOG_WARNING);
			return(-1);
		}	

		sleep(1);	
	}

	if(! buf.st_uid)   /* owned by root */
		return(cmain);

	while((pword = getpwnam(username)) == NULL)    /* no such user */
	{
		if(errno != ENOMEM)
		{
			syslogw(cpstr(100, "ignored crontab for %s: no such user", username), LOG_INFO);
			return(-1);
		}	
		
		sleep(1);
	}	
	
	if(buf.st_uid != pword->pw_uid )  /* not owner of file */
	{	
		syslogw(cpstr(100, "crontab for %s doesn't match owner", username), LOG_INFO);
		return(-1);
	}	
	return(cmain);
}

CONFIG *readconfig(char *ctab, char cmain)  /* read a crontab, return the first block or NULL */
{
	FILE *crontab; 
	char *ninbuf,**cpbuf,dopt,bopt,lopt,inp,*outbuf;
	char *inds[3],*nbuf;
	CONFIG *tbuf,*pbuf=NULL;
	static CONFIG *sblock;
	NVR *nvrbuf,*pvrbuf=NULL,*snvr=NULL;
	char inbuf[11*1025];
	size_t slen;
	time_t ltm;
	unsigned long tminutes; 
	int i,dres,wres,nentries=0,ncmds;

	if((crontab = fopen(cpstr(1024, "./%s", ctab), "r")) == NULL)
		return NULL;

	sblock = NULL;

	while(time(&ltm) < 0)
		sleep(1);

	while(fgets(inbuf, 1024, crontab) != NULL)
	{
		do
		{
			for(nbuf = inbuf+strlen(inbuf); nbuf > inbuf && (*nbuf == ' ' || *nbuf == '\t' || *nbuf == '\n' || ! *nbuf); nbuf--);

			if(*nbuf != '\\')  /* no continuation */
				break;

			if(! cmain && nentries++ >= UTABMAX)
				break;

			if(strlen(inbuf) > 10*1024)
				break;

		} while(fgets(nbuf, 1024, crontab) != NULL);
		
		if(strchr(inbuf, '\n') == NULL)
		{
			*(inbuf+(i = strlen(inbuf))) = '\n';
			*(inbuf+i+1) = 0;
		}

		ninbuf = inbuf + strspn(inbuf, "\t ");  /* strip leading space */

		if(*ninbuf == '#' || *ninbuf == '\n')
			continue;

		/* limit user crontabs to 200 entries */
	
		if(! cmain && nentries++ >= UTABMAX)
			break;

		/* test for environment entry */

		outbuf = ninbuf + (i = strcspn(ninbuf, "\t\n= "));

		if (i && *outbuf == '=')
		{
			*(outbuf + strcspn(outbuf, "\n")) = 0;
			while((nvrbuf = malloc(sizeof(NVR)+strlen(ninbuf)+1)) == NULL)
				sleep(1);

			strcpy((char *)nvrbuf+sizeof(NVR), ninbuf);
			nvrbuf->nblock = NULL;
			
			(snvr == NULL) ? (snvr = nvrbuf) : (pvrbuf->nblock = nvrbuf);
			pvrbuf = nvrbuf;
			continue;
		}

		if((cpbuf = sptoken(ninbuf)) == NULL)
			continue;

		inds[0] = (cmain)?("root"):(ctab);
	
		/* make entry of cron field */

		if(*cpbuf[0] == 'U' || *cpbuf[0] == 'u')  /* U option used */ 
		{
			if((tminutes = uhours(&cpbuf[1])) == 0)
				continue;
		}
		else
		{	
			lbnm(cpbuf[3], 1);
			lbnm(cpbuf[4], 0);

			tminutes = 0;
		}	

		/* options */

		ncmds = 5;
		bopt = dopt = lopt = 0;
		inds[2] = NULL;

NBLV:		while(*cpbuf[ncmds] == '-')
		{
			for(i = 1; *(cpbuf[ncmds]+i); i++)
			{
				inp = tolower(*(cpbuf[ncmds]+i));
				
				if(inp == 'u' && *(cpbuf[ncmds]+i+1) == '=')
				{
					if(cmain)
						inds[0] = cpbuf[ncmds]+i+2;

					ncmds++;
					goto NBLV;
				}	
				
				if(inp == 's' && *(cpbuf[ncmds]+i+1) == '=')
				{
					inds[2] = cpbuf[ncmds]+i+2;
				
					ncmds++;
					goto NBLV;
				}
		
				if(! tminutes && inp == 'd')
					dopt = 1;
				
				else if(inp == 'b')
					bopt = 1;

				else if(inp == 'l')
					lopt = 1;	
			}	
			ncmds++;
		}

		inds[1] = cpbuf[ncmds];

		/* inds[0] points to username, inds[1] to cmdline, inds[2] to subject now */

		slen = strlen(inds[0])+strlen(inds[1])+2;

		if(inds[2] != NULL)
			slen += strlen(inds[2])+1;

		while((tbuf = malloc(sizeof(CONFIG)+slen)) == NULL)
			sleep(1);

		if(! tminutes)
		{	
			if ( ! chk_tmstr(cpbuf[0], tbuf->minutes, 60)
			  || ! chk_tmstr(cpbuf[1], tbuf->hours, 24)
			  || ! (dres = chk_tmstr(cpbuf[2], tbuf->days, 32))
			  || ! chk_tmstr(cpbuf[3], tbuf->month, 13)
			  || ! (wres = chk_tmstr(cpbuf[4], tbuf->weekday, 7)))
			{
			 	free(tbuf);
			 	continue;
			}

			if( wres == 2 )
				tbuf->wdres = 0x01;
			else
				tbuf->wdres = 0;		

			if( dres == 2 )
				tbuf->wdres |= 0x02;	
		}
			
		/* first pointer into cblock,then expand CONFIG struct */

		(sblock == NULL) ? (sblock = tbuf) : (pbuf->nblock = tbuf); 

		tbuf->username = strcpy((char *)tbuf+sizeof(CONFIG), inds[0]);
		tbuf->cmdstr = strcpy(tbuf->username+strlen(inds[0])+1, inds[1]);

		if(inds[2] != NULL)
			tbuf->jobid = strcpy(tbuf->cmdstr+strlen(inds[1])+1, inds[2]);
		else
			tbuf->jobid = NULL;	
		 
		tbuf->nblock = NULL;
		tbuf->nuser = NULL;
		tbuf->period = tminutes;
		tbuf->dopt = dopt;
		tbuf->bopt = bopt;
		tbuf->lopt = lopt;
		tbuf->stblock = (tbuf == sblock)?(1):(0); 
		tbuf->cmain = cmain;
		tbuf->envr = snvr;
		tbuf->pid = 0;
		tbuf->nextexec = runtab(tbuf, ltm);
		tbuf->lastexec = 0;

		pbuf = tbuf;
	}
	fclose(crontab);

	if(sblock == NULL)
		rmenv(snvr);

	return(sblock);
}

void update_ctab(char *ctab)
{
	char cmain=0,*str;
	CONFIG *tbuf;
	int jobs=0;
	struct stat buf;

	if(strcmp(ctab, NCTROOT) == 0)
		cmain = 1;
	
	if(stat(ctab, &buf))  /* crontab removed  */
	{
		njobs -= rmuser(ctab);
		syslogw(cpstr(100, "removed %s%s", (cmain)?(ctab):("user "), (cmain)?(""):(ctab)), LOG_INFO);

		write(svsock, "Crontab removed\n", 16);
		return;
	}

	if((cmain = userperm(ctab)) == -1)
		return;
	
	njobs -= rmuser(ctab);

	if((tbuf = readconfig(ctab, cmain)) != NULL)
	{
		jobs = adduser(tbuf);
		njobs += jobs;
	}

	str = cpstr(100, "Registered %d jobs\n", jobs);
	write(svsock, str, strlen(str));
	
	syslogw(cpstr(100, "registered %d jobs for %s%s (total %d)", jobs, (cmain)?("root"):("user "),
		(cmain)?(""):(ctab), njobs), LOG_INFO);
}	

void read_config(void)   /* read all crontabs */
{
	DIR *crontabs;
	CONFIG *tbuf,*pbuf;
	int nuser=0;
	char cmain;
	struct dirent *dentry;

	if(chdir(CRONTABS) < 0)
	{
		syslogw("cannot chdir to crontabs: %m", LOG_ERR);
		return;
	}

	chown(CRONTABS, 0, 0);
	chmod(CRONTABS, 0755);

	if(svctrl != -1)
		close(svctrl);

	if((svctrl = create_socket(SERVCTRL)) == -1)
		syslogw("cannot create socket: %m", LOG_ERR);

	if((crontabs = opendir(CRONTABS)) == NULL)
	{
		syslogw("cannot open crontab directory: %m", LOG_ERR);
		return;
	}

	/* remove all crontabs */

	flushqueue();

	tbuf = pbuf = cblock;

	while(tbuf != NULL)
	{
		if(tbuf->stblock)
			rmenv(tbuf->envr);
			
		pbuf = tbuf;
		tbuf = tbuf->nblock;
		free(pbuf);
	}
	cblock = NULL;
	njobs = 0;

	while((dentry = readdir(crontabs)) != NULL)
	{
		if(*dentry->d_name == '.' || strcmp(dentry->d_name, SERVDIR) == 0)
			continue;

		if((cmain = userperm(dentry->d_name)) == -1)	
			continue;

		if((tbuf = readconfig(dentry->d_name, cmain)) != NULL)
		{
			njobs += adduser(tbuf);
			nuser++;
		}
	}
	closedir(crontabs);

	syslogw(cpstr(100, "registered %d jobs, %d users", njobs, nuser), LOG_INFO);
}
