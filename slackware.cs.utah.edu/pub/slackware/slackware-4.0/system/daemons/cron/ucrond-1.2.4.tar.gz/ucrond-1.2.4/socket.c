/* $Id: socket.c,v 1.2 1999/02/24 04:53:26 alinden Exp $ */

/*
*  File             : socket.c
*  Written by       : alinden@gmx.de
*  Compiler         : gcc 2.7.2 on Linux 2.0.33
*  Portability      : Should be POSIX compliant
*  Copyright:       : GPL
*
*  DESCRIPTION: Hmm... looks like socket related stuff
*/

#include "conf.h"
#include "crond.h"
#include "extern.h"

void syslogw(char *, int);
void update_ctab(char *);
char *cpstr(size_t, char *, ...);
void restore_sigs(void);
void msgout(char *);
void run_proc(CONFIG *);
int cmd_queued(CONFIG *); 

void sig_nop(int signo) { return; }

void outfifo(CMD *inb)   /* send joblist to socket */
{
	pid_t pid;
	char *username;
	CONFIG *tbuf;
	FILE *ffifo=NULL;
	char cmain;
	char *tmstr = "%b %d %a %H:%M";
	time_t ltm,lth=0;
	char tmbuf[20];
	int jobs,fjobs,lstall,i;

	if(inb->ctab == NULL || inb->par == NULL)
	{
		syslogw("outfifo(): missing parameter", LOG_ERR);
		return;
	}	
	
	if((pid = fork()) < 0)
	{
		syslogw("can't fork", LOG_WARNING);
		return;
	}

	if(pid)
		return;

	restore_sigs();

	lstall = 0;

	if(strcmp(inb->ctab+2, NCTROOT) == 0)
	{
		username = "root";
		cmain = 1;
	}
	else
	{
		username = inb->ctab+2;
		cmain = 0;
	}	

	if(cmain && strcmp(inb->par, "*all*") == 0)
		lstall = 1;

	if((ffifo = fdopen(svsock, "w")) == NULL)
		exit(0);

	tbuf = cblock;

	if(lstall == 0)
	{
		while(tbuf != NULL)  /* find user */
		{
			if((cmain && tbuf->cmain) || 
			  (! cmain && ! tbuf->cmain && strcmp(username, tbuf->username) == 0))
				break;

			tbuf = tbuf->nuser;
		}
	}
	
	if(tbuf == NULL)
	{
		if(lstall == 0) 
			fprintf(ffifo, "No jobs for user %s\n", username);
		else
			fprintf(ffifo, "No jobs\n");

		fclose(ffifo);
		exit(0);
	}

	if(lstall == 0)
		fprintf(ffifo, "Jobs for user %s\n", username);

	time(&ltm);
		
	jobs=fjobs=0;
	while(1)
	{
		jobs++;

		if(lstall == 0)
		{
			if(! (tbuf->jobid != NULL && fnmatch(inb->par, tbuf->jobid, 0) == 0) && 
			fnmatch(inb->par, tbuf->cmdstr, 0))
			{
				tbuf = tbuf->nblock;

				if(tbuf == NULL || tbuf->stblock)
					break;

				continue;	
			}
		}
		
		if(lstall == 0 || fjobs)
			fprintf(ffifo, "-----------------------------------------\n");

		fjobs = 1;	
		
		fprintf(ffifo, "Number : %d\n", jobs);
		fprintf(ffifo, "Command: %s\n", tbuf->cmdstr);
		
		if(cmain)
			fprintf(ffifo, "User   : %s\n", tbuf->username); 
		
		fprintf(ffifo, "Subject: %s\n", (tbuf->jobid)?(tbuf->jobid):("<default>"));
		
		fprintf(ffifo, "Options: ");

		i = 0;

		if(tbuf->period)
		{
			fputc('U', ffifo);
			i = 1;
		}	
		if(tbuf->dopt)
		{
			fputc('D', ffifo);
			i = 1;
		}

		if(tbuf->bopt)
		{
			fputc('B', ffifo);	
			i = 1;
		}

		if(tbuf->lopt)
		{
			fputc('L', ffifo);	
			i = 1;
		}

		if(i == 0)
			fprintf(ffifo, "<none>");

		fputc('\n', ffifo);
		
		fprintf(ffifo, "Status : ");

		if(tbuf->pid)
		{
			fprintf(ffifo, "Running\n");

		} else if(cmd_queued(tbuf))
		{
			fprintf(ffifo, "Queued\n");
			
		} else
			fprintf(ffifo, "Waiting\n");

		fprintf(ffifo, "Last   : ");

		if(tbuf->lastexec == 0)
			fprintf(ffifo, "<none>\n");
		else
		{
			strftime(tmbuf, 20, tmstr, localtime(&tbuf->lastexec));
			lth = (ltm-tbuf->lastexec)/(60*60);
			fprintf(ffifo, "%s  +(%dh %.0fm)\n", tmbuf, (int)lth, (((float)ltm-(float)tbuf->lastexec)/60)-(float)lth*60);
		}

		fprintf(ffifo, "Next   : ");

		if(tbuf->nextexec == -1)
			fprintf(ffifo, "<?>\n");
		else
		{
			strftime(tmbuf, 20, tmstr, localtime(&tbuf->nextexec));
			lth = (tbuf->nextexec-ltm)/(60*60);
			fprintf(ffifo, "%s  -(%dh %.0fm)\n", tmbuf, (int)lth, (((float)tbuf->nextexec-(float)ltm)/60)-(float)lth*60);
		}
		
		tbuf = tbuf->nblock;

		if(tbuf == NULL || (! lstall && tbuf->stblock))
			break;

	}

	if(lstall == 0 && fjobs == 0)
		fprintf(ffifo, "No match with %s\n", inb->par);

	fclose(ffifo);

	exit(0);
}

void runcmd(CMD *inb)   /* run command */
{
	char *username;
	CONFIG *tbuf;
	char cmain,*jname,*str=NULL;
	int job,i;
	
	if(inb->ctab == NULL || inb->par == NULL)
	{
		syslogw("runcmd(): missing parameter", LOG_ERR);
		return;
	}
	
	if(strcmp(inb->ctab+2, NCTROOT) == 0)
	{
		username = "root";
		cmain = 1;
	}
	else
	{
		username = inb->ctab+2;
		cmain = 0;
	}	

	tbuf = cblock;

	while(tbuf != NULL)  /* find user */
	{
		if((cmain && tbuf->cmain) || 
		  (! cmain && ! tbuf->cmain && strcmp(username, tbuf->username) == 0))
			break;

		tbuf = tbuf->nuser;
	}

	if(tbuf == NULL)
	{
		str = cpstr(256, "No jobs for user %s\n", username);
		write(svsock, str, strlen(str));
		
		return;
	}

	for(i = 0; inb->par[i] >= '0' && inb->par[i] <= '9'; i++);

	if(inb->par[i])  /* alphanumeric input */ 
	{
		do
		{
			if(tbuf->jobid != NULL && strcmp(tbuf->jobid, inb->par) == 0)
				break;

			tbuf = tbuf->nblock;

			if(tbuf != NULL && tbuf->stblock)
				tbuf = NULL;
				
		} while(tbuf != NULL);
	}
	else
	{
		job = atoi(inb->par);

		if(job)
		{
			for(i = 1; i < job; i++)
			{
				tbuf = tbuf->nblock;

				if(tbuf != NULL && tbuf->stblock)
					tbuf = NULL;

				if(tbuf == NULL)
					break;
			}
		}
		else 
			tbuf = NULL;
	}

	if(tbuf == NULL)
	{
		str = cpstr(256, "No such job (%s)\n", inb->par);
		write(svsock, str, strlen(str));
		
		return;
	}

	jname = (tbuf->jobid)?(tbuf->jobid):(inb->par);

	if(tbuf->pid)
	{
		str = cpstr(256, "Job already running (%s)\n", jname);
		write(svsock, str , strlen(str));
		
		return;
	}

	if(cmd_queued(tbuf))
	{
		str = cpstr(256, "Job is queued (%s)\n", jname);
		write(svsock, str, strlen(str));
		
		return;
	}

	str = cpstr(256, "Starting command %s\n", jname);
	write(svsock, str, strlen(str));

	run_proc(tbuf);
}

int create_socket(char *sockname)
{
	int sock;
	struct sockaddr_un name;

	unlink(sockname);

	if((sock = socket(PF_UNIX, SOCK_STREAM, 0)) < 0)
		return(-1);
	
	name.sun_family = AF_UNIX;
	strcpy(name.sun_path, sockname);

	if(bind(sock, (struct sockaddr *)&name, offsetof(struct sockaddr_un, sun_path)+strlen(name.sun_path)+1) < 0)
		return(-1);

	chmod(sockname, S_IRUSR|S_IWUSR);
	listen(sock,1);
	return(sock);
}

void read_fifo(void)    /* read a command from socket */
{
	ssize_t nrd;
	CMD inb;

	signal(SIGALRM, (void *)sig_nop);
	alarm(15);

	if((nrd = read(svsock, &inb, sizeof(CMD))) < 0)
	{
		syslogw((errno == EINTR)?("timeout on socket"):("socket error while reading: %m"), LOG_ERR);
		return;
	}

	alarm(0);
	
	if(nrd != sizeof(CMD))
	{
		syslogw("invalid block length for input command", LOG_ERR);
		return;
	}

	switch(inb.cmd)
	{
		case CMD_UPDATE:
					update_ctab(inb.ctab+2);
					break;
		case CMD_INFO:
					outfifo(&inb);
					break;
		case CMD_RUN:
					runcmd(&inb);
					break;
		default:
					syslogw("unknown command received", LOG_ERR);
	}
}
