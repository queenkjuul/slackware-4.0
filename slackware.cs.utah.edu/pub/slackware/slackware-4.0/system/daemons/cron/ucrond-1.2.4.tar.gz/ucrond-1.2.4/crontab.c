/* $Id: crontab.c,v 1.7 1999/03/16 18:51:36 alinden Exp $ */

/*
*  File:                 : crontab.c	
*  Written by            : alinden@gmx.de
*  Compiler              : gcc 2.7.2 on Linux 2.0.33
*  Portability           : Should be POSIX compliant
*  Copyright             : GPL
*  DESCRIPTION:          : Calls set_crontab() to verify permissions, modifies  
*                        : the crontab and sends a command to crond. 
*/

#include "crond.h"
#include "conf.h"

/* verify permissions and return the crontab name for a user. 
   username = NULL: assume user or NCTROOT if root. */

char *setcrontab(char *username)
{ 
	uid_t userid;
	struct passwd *pword,*upword;

	if((pword = getpwuid(userid = getuid())) == NULL)
	{
		perror("getpwuid()");
		exit(1);
	}

	if(userid == 0)  /* user is root */
	{
		if(username == NULL || strcmp(username, NCTROOT) == 0)
			return(NCTROOT);

		/* Verify if user does exist */	

		if((upword = getpwnam(username)) != NULL)
			return(upword->pw_name);
			
		fputs("Unknown user\n", stderr);
		exit(1);	
	}	

	/* not root */

	if(username == NULL )  /* no name specified */
		return(pword->pw_name);  /* own name */
		
	if((upword = getpwnam(username)) == NULL || pword->pw_uid != upword->pw_uid )
	{
		fputs("Only root will specify crontabs of other users\n", stderr);
		exit(1);
	}	
	return(pword->pw_name);
}

void chop(char *instr)
{
	int i;

	for(i = strcspn(instr, "\n"); (instr[i] == ' ' || instr[i] == '\t' || 
	    instr[i] == '\n' || instr[i] == 0) && i >= 0; i--)
		instr[i] = 0;
}

char searchuser(FILE *permfile, char *username)  /* search for a user */
{
	char buf[200];
	regex_t rgexp;
	char neg,fnd=0;

	while(fgets(buf, 200, permfile) != NULL)
	{
		chop(buf);

		if(*buf == '!')  /* negation */
		{
			neg = 1;
			*buf = '^';
		}
		else neg = 0;
		
		if(*buf != '^' || regcomp(&rgexp, buf, REG_EXTENDED | REG_NOSUB))
		{
			if(strcmp(buf, username) == 0)
				fnd=1;
				
			continue;
		}

		if(regexec(&rgexp, username, 0, NULL, 0) == 0)
		{
			if(neg)
			{
				regfree(&rgexp);
				return(0);
			}
			fnd = 1;
		}
		regfree(&rgexp);
	}
	return(fnd);
}

char *set_crontab(char *username)   /* call setcrontab and verify permissions */  
{
	char *crontab;
	static char buf[60] = { '.','/' };
	char inbuf[200];
	char fnduser;
	FILE *permfile;

	buf[59] = 0;
	crontab = setcrontab(username);

	if(getuid())
	{
		if((permfile = fopen(SERVPERM, "r")) != NULL)
		{
			if(fgets(inbuf, 200, permfile) != NULL)
			{
				chop(inbuf);
				fnduser = searchuser(permfile, crontab);

				if((strcmp(inbuf, "allow:") == 0 && ! fnduser) ||
  				  (strcmp(inbuf, "deny:") == 0 && fnduser))
				{
					fputs("You are not allowed to use cron\n", stderr);
					fclose(permfile);
					exit(1);
				}
			}	
			fclose(permfile);
		}
		else if(errno != ENOENT)
		{
			perror(SERVPERM);
			exit(1);
		}	
	}
	
	strncpy(&buf[2], crontab, 57);
	return(buf);
}

void catf(int infile, int outfile)    /* cat file from infile to outfile */
{
	char buf[1024];
	ssize_t inbytes;

	while((inbytes = read(infile, buf, 1024)) > 0)
		write(outfile, buf, inbytes);  	 	 
}   

void cdir_ctab(void)   /* change to the crontab dir */
{
	if(chdir(CRONTABS) < 0)
	{
		perror("Cannot access crontab directory");
		exit(1);
	}	
}

void send_signal(CMD *ctab)   /* create socket and send command */
{
	int sock;
	struct sockaddr_un name;

	if((sock = socket(PF_UNIX, SOCK_STREAM, 0)) < 0)
		return;

	name.sun_family = AF_UNIX;
	strcpy(name.sun_path, SERVCTRL);
	
	if(connect(sock, (struct sockaddr *)&name, offsetof(struct sockaddr_un, sun_path)+strlen(name.sun_path)+1) < 0)
	{
		if(errno == ENOENT)
			fprintf(stderr, "Cannot connect. No cron running???\n");
		else
			perror("Cannot connect");
			
		return;
	}
	write(sock, ctab, sizeof(CMD));
	catf(sock, 1);
	close(sock);
}		

int lcrontab(char *crontab)     /* list a crontab */
{
	int ctab;

	cdir_ctab();

	if ( (ctab = open(crontab, O_RDONLY)) < 0)
	{
		perror("Cannot open this crontab");
		exit(1);
	}

	catf(ctab, 1);
	
	close(ctab);

	exit(0);
}

int dcrontab(char *crontab)  /* delete a crontab */
{
	struct stat buf;
	CMD ctab;

	cdir_ctab();

	if(lstat(crontab, &buf) == 0 && S_ISLNK(buf.st_mode))
	{
		fprintf(stderr, "Crontab is a symbolic link\n");
		exit(1);
	}	

	if(unlink(crontab))
	{
		perror("No crontab deleted");
		exit(1);
	}

	ctab.cmd = CMD_UPDATE;
	strcpy(ctab.ctab, crontab);
	
	send_signal(&ctab);
		
	exit(0);	
}

int ecrontab(char *crontab)  /* edit a crontab */
{
	pid_t pid;
	uid_t userid;
	gid_t groupid;
	char *editor,*neditor;
	struct stat buf;
	time_t lmtime;
	CMD ctab;
	int fd;

	cdir_ctab();

	if((fd = open(crontab, O_RDONLY | O_CREAT, 0600)) < 0)
	{
		perror("Cannot open crontab");
		exit(1);
	}	

	groupid = getgid();

	if((userid = getuid()))    /* set crontab to current user */
		fchown(fd, userid, groupid);

	/* get the last modification time to verify that it was changed */

	fstat(fd, &buf); 
	lmtime = buf.st_mtime;
	
	close(fd);

	if((pid = fork()) < 0 )
	{
		perror("Fork");
		exit(1);
	}
	 
	if(pid == 0)   /* child */
	{
		if(userid && (setgid(groupid) || setuid(userid)))
		{
			perror("Cannot set permissions");
			exit(1);
		}

		/* verify environment to get editor name */

		if(((editor = getenv("VISUAL")) == NULL && (editor = getenv("EDITOR")) == NULL) || *editor == 0)
			editor = EDITOR;

		if((neditor = strrchr(editor, '/')) == NULL)
			neditor = editor;
		else
			neditor++;

		if(execlp(editor, neditor, crontab, NULL) < 0)
		{
			perror("Cannot run the editor"); 
			fprintf(stderr, "Editor name: %s\n", editor);
		}
		exit(0);
	}

	wait(NULL);
	chown(crontab, 0, 0);
	chmod(crontab, S_IRUSR|S_IWUSR);
	stat(crontab, &buf); 

	if(buf.st_mtime == lmtime)  /* File left unchanged */
		exit(0);

	ctab.cmd = CMD_UPDATE;
	strcpy(ctab.ctab, crontab);

	send_signal(&ctab);
	exit(0);
}	

int reqinfo(char *crontab, char *rexpr)
{
	CMD ctab;
	
	cdir_ctab();

	if(strlen(rexpr) > 199)
	{
		fputs("Command too long\n", stderr);
		exit(1);
	}
		 
	ctab.cmd = CMD_INFO;
	strcpy(ctab.ctab, crontab);

	if(*rexpr == '*')
	{
		ctab.par[0] = '*'; 
		ctab.par[1] = 0;
	}
	else sprintf(ctab.par, "*%s*", rexpr);

	send_signal(&ctab);
	exit(0);
}

int runproc(char *crontab, char *rcmd)
{
	CMD ctab;
	
	cdir_ctab();
	
	if(strlen(rcmd) > 199)
	{
		fputs("Command too long\n", stderr);
		exit(1);
	}	
	
	ctab.cmd = CMD_RUN;
	strcpy(ctab.ctab, crontab);
	strcpy(ctab.par, rcmd);

	send_signal(&ctab);
	exit(0);
}

int fcrontab(char *crontab, char *infile)  /* replace crontab from file */
{
	int intab,outtab;
	CMD ctab;

	if(*infile == '-' && ! *(infile+1))
		intab = 0;
	else
	{
		if(access(infile, R_OK) || (intab = open(infile, O_RDONLY)) == -1)
		{
			perror("Cannot open input file");
			exit(1);
		}
	}	

	cdir_ctab();

	if((outtab = open(crontab, O_WRONLY | O_CREAT | O_TRUNC, 0600)) < 0)
	{
		perror("Cannot open crontab");
		exit(1);
	}
	
	catf(intab, outtab);
	fchown(outtab, 0, 0);
	fchmod(outtab, S_IRUSR|S_IWUSR);

	close(intab);
	close(outtab);

	ctab.cmd = CMD_UPDATE;
	strcpy(ctab.ctab, crontab);
	
	send_signal(&ctab);
	exit(0);
}			

int main(int argc, char *argv[])
{
	int i;
	char *username=NULL,*filename=NULL,*rexpr=NULL,*rcmd=NULL;
	void (*func)(char *);

	func = NULL;
	
	umask(066);

	if(argc > 1)
	{	
		if(strcmp(argv[1], "--version") == 0)
		{
			puts(VERSION);
			exit(0);
		}

		for(i = 1; i < argc; i++)
		{
			if(*argv[i] != '-')
			{
				filename=argv[i]; 
				continue;
			}	

			switch(*(argv[i]+1))
			{
				case 'u':
						if(++i < argc)
							username = argv[i];
						break;	
				case 'l':
						func = (void *)lcrontab;
						break;
				case 'd':
						func = (void *)dcrontab;
						break;
				case 'e':
						func = (void *)ecrontab;
						break;
				case 'i':
						if(i+1 < argc)
						{
							if(*argv[i+1] == '-')
							{
								rexpr = "*";
								break;
							}	
							
							rexpr = argv[++i];
						}
						else
							rexpr = "*";
						break;
				case 'r':
						if(++i < argc)
							rcmd = argv[i];
						break;
				case 0:
						filename = "-";
			}
		}
		if(rexpr != NULL)
			reqinfo(set_crontab(username), rexpr);

		if(rcmd != NULL)
			runproc(set_crontab(username), rcmd);
		
		if(func == NULL && filename != NULL)
			fcrontab(set_crontab(username), filename);

		if(func != NULL && filename == NULL)	
			(*func)(set_crontab(username));
	}
	fputs("Usage: crontab [-u <user>] { <file>|-e|-d|-l|-i [<pattern>]|-r <cmd> }\n", stderr);
	exit(1);
}	

