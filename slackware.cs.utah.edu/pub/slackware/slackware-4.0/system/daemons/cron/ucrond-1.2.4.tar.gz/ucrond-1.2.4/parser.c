/* $Id: parser.c,v 1.3 1999/02/26 01:55:45 alinden Exp $ */

/*
*  File:            : parser.c
*  Written by       : alinden@gmx.de
*  Compiler         : gcc 2.7.2 on Linux 2.0.33
*  Portability      : Should be POSIX compliant  
*  Copyright:       : GPL
*
*  DESCRIPTION: simple parser for crontab time fields
*/

#include "conf.h"
#include "crond.h"
#include "extern.h"

void stfd(unsigned char *tbuf, int bnum)
{
	int cnum;

	if ( bnum < 0 )
		return;

	cnum = bnum / 8;   /* byte number */ 
	tbuf[cnum] |= (0x80 >> (unsigned)(bnum-cnum*8)); 
}	

/* input: string of a time field (*instr) in a crontab entry. Use stfd()
   to convert the string to a bitmap starting at *tbuf.
   max: max. number of bits. Return 0: no bits set, 1: bits are set,
   2: field was unrestricted ('*'), all bits are set  */

int chk_tmstr(char *instr, unsigned char *tbuf, int max)
{
	unsigned rdtm,nrdtm,srdtm;
	int ind;

	for(ind = 0; ind <= max/8; ind++)  /* set bits to zero */
		tbuf[ind] = 0;

	while(*instr)
	{
		while(1)
		{
			if(*instr == '*')
			{
				if(instr[1] == 0 || instr[1] == ',')  /* unrestricted */
				{
					for(ind = 0; ind <= max/8; ind++)  /* set all bits */
						tbuf[ind] = 0xff;

					return(2);	
				}

				if(sscanf(&instr[1], "/%d", &rdtm) < 1 || rdtm == 0)
					break;

				for(ind = 0; ind < max; ind++)	
				{
					if ( ind % rdtm == 0)
						stfd(tbuf, ind);
				}		
				break;
			}

			if(sscanf(instr, "%d-%d", &rdtm, &nrdtm) > 1)
			{
				srdtm = 1;
				ind = strcspn(instr, ",/"); 

				if ( instr[ind] == '/' && (sscanf(&instr[ind+1], "%d", &srdtm) < 1 || srdtm == 0))
						break;

				for(ind = 0; ind < max; ind++)
				{
					if ( ((rdtm <= nrdtm && ind >= rdtm && ind <= nrdtm) || ( rdtm > nrdtm && (ind <= nrdtm || ind >= rdtm))) && (ind % srdtm) == 0)
						stfd(tbuf, ind);
				}		
				break;
			}
	
			if(sscanf(instr, "%d", &rdtm) > 0 && rdtm < max)
				stfd(tbuf, rdtm);
			break;	
		}	
		while( *instr && *(instr++) != ',' );
	}			
	
	for(ind = 0; ind <= max/8; ind++)   /* bits have been set */
	{
		if(tbuf[ind] )
			return(1);
	}		
	return(0);
}  

void lbnm(char *instr, int month)   /* replace strings against numbers */
{              	                    /* month=1 : use month table */
	int ind=0,nind;
	char *outstr,**stbl;
	char *arrdow[] = {"sun","mon","tue","wed","thu","fri","sat",NULL};
	char *arrmon[] = {"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec",NULL};

	stbl=(month)?(arrmon):(arrdow);

	outstr = instr;

nloop:	while (*instr)
	{
		for(nind=0; stbl[nind] != NULL; nind++)
		{
			ind = 0;
		
			while(1)
			{
				if(! instr[ind] || tolower(instr[ind]) != *(stbl[nind]+ind))
					break;
				
				if(ind++ == 2)
				{
					sprintf(outstr++, "%d", nind+month);
					if(nind+month > 9) 
						outstr++;
					instr += 3;
					goto nloop;
				}		
			}
		}
		*(outstr++) = *(instr++);
	}
	*outstr = 0;	
} 

