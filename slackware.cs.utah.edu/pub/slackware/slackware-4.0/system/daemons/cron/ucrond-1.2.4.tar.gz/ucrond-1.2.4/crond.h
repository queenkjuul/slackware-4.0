/* $Id: crond.h,v 1.3 1999/03/01 19:00:02 alinden Exp $ */

#include <stdio.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <sys/time.h>
#include <pwd.h>
#include <dirent.h>
#include <grp.h>
#include <fnmatch.h>
#include <sys/file.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <stddef.h>
#include <sys/un.h>
#include <regex.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <sys/wait.h>
#include <errno.h>

typedef struct nvr		/* user environments */
{
	struct nvr *nblock;
} NVR;

typedef struct                  /* this goes into the control socket */
{
	char cmd;               /* command */
	char ctab[60];          /* crontab name */
	char par[200];          /* parameter */ 
} CMD;

/* commands for CMD struct */

#define CMD_UPDATE 1
#define CMD_INFO 2
#define CMD_RUN 3

typedef struct config
{
	struct config *nblock;
	struct config *nuser;
	time_t lastexec;
	time_t nextexec;
	unsigned long period;	/* minutes if U option was used or 0 */ 
	char *username;		/* username */
	char *cmdstr;		/* command line */
	NVR *envr;		/* points to user environment */  
	char cmain;		/* 1 if root */
	char stblock;		/* 1 if first block of user */
	char dopt;              /* 1 if D (reboot) option was used */
	char bopt;		/* 1 if B (batch) option was used */
	char lopt;		/* 1 if L (log) option was used */
	char *jobid;		/* points to subject line or NULL */
	pid_t pid;		
	unsigned char wdres;    /* 0x01|0x02: week|day field unrestricted */
	unsigned char minutes[8];         
	unsigned char hours[8];            
	unsigned char days[4];
	unsigned char month[2];
	unsigned char weekday[1];
} CONFIG; 
