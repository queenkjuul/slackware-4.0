/* $Id: dtime.c,v 1.2 1999/02/24 04:53:22 alinden Exp $ */

/*
*  File             : dtime.c
*  Written by       : alinden@gmx.de
*  Compiler         : gcc 2.7.2 on Linux 2.0.33
*  Portability      : Should be POSIX compliant
*  Copyright        : GPL
*  DESCRIPTION:     : Prints the uptime information maintained by crond
*                   : (path to file defined in TIMEFILE) to stdout. 
*/

#include "crond.h"
#include "conf.h"

void prtimer(char *info, unsigned long seconds)  /* Print seconds in d,h */ 
{
	unsigned days=seconds/(60*60*24);

	printf("%s%ud %dh\n", info, days, (int)((seconds/(60*60))-days*24));
}

int main(int argc, char *argv[])
{
	FILE *timefile;
	unsigned long starttime,uptime;


	if(argc > 1 && strcmp(argv[1], "--version") == 0)
	{
		puts(VERSION);
		exit(0);
	}

	if ( (timefile = fopen(TIMEFILE, "r")) == NULL)
	{
		perror("Can't open uptime");
		exit(1);
	}
	if ( fscanf(timefile, "%lu\n%lu", &starttime, &uptime) < 2)
	{
		fputs("Can't read uptime\n", stderr);
		exit(1);
	}
	printf("Counting since %s", ctime(&starttime));
	prtimer("Total uptime  : ", uptime);
	prtimer("Total downtime: ", (unsigned long)time(NULL)-starttime-uptime);
	exit(0);
}	  
