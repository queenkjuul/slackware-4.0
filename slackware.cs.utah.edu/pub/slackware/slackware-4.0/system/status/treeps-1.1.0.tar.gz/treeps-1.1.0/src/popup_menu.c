/* File: 	popup_menu.c
 *
 * Description: Routines to create and process popup menu's.
 *
 * Author:	George MacDonald
 *
 * Copyright:	Copyright (c) 1995, Pulsar Software Inc.
 *		All Rights Reserved, Unpublished rights reserved.
 *
 * History:	George MacDonald	4/14/95	Created
 *
 */

#include <sys/time.h>
#include <unistd.h>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>


#include "libXs.h"

#include "debug.h"

#include <Xpsi/Tree.h>

#include "tree.h"
#include "list.h"

#include "treeps.h"
#include "user_group.h"

Widget setup_node_popup_menu();
Widget setup_tree_popup_menu();

void 		do_node();
void 		do_tree_popup();

void 		do_renice();
void 		do_renice_subtree();

xs_menu_struct RenicePopupMenu[]={
	{"+1   (Lowers Priority)", "L", NULL_STR, do_renice, "1",  
					NULL, 0, NULL_STR},
	{"+5", NULL, NULL_STR, do_renice, "5",  
					NULL, 0, NULL_STR},
	{"-1   (Raises Priority)", "R", NULL_STR, do_renice, "-1",
					NULL, 0, NULL_STR},
	{"-5", "P", NULL_STR, do_renice, "-5",  
					NULL, 0, NULL_STR},
	{"Sep",         NULL_STR, NULL_STR, NULL, NULL_STR, NULL,
                                                           0, NULL_STR},
	{"+1   On Subtree", NULL, NULL_STR, do_renice_subtree, "1",  
					NULL, 0, NULL_STR},
	{"+5   On Subtree", NULL, NULL_STR, do_renice_subtree, "5",  
					NULL, 0, NULL_STR},
	{"-1   On Subtree", NULL, NULL_STR, do_renice_subtree, "-1",  
					NULL, 0, NULL_STR},
	{"-5   On Subtree", NULL, NULL_STR, do_renice_subtree, "-5",  
					NULL, 0, NULL_STR},

};

xs_menu_struct NodePopupData[]={
	{"Man","M", NULL_STR, do_node, "man", NULL, 
							0, NULL_STR},
#ifdef LINUX
	{"Trace System Calls","T", NULL_STR, do_node, "strace", NULL, 
#endif
							0, NULL_STR},
	{"Change Nice Value","N", NULL_STR, NULL, NULL_STR, 
			(struct _menu_struct *) RenicePopupMenu,
			XtNumber(RenicePopupMenu), "Change Process Nice Value(s)"},
	{"Sep",         NULL_STR, NULL_STR, NULL, NULL_STR, NULL,
                                                           0, NULL_STR},
	{"Select Process", "t", NULL_STR, do_node, "select",  NULL, 
							0, NULL_STR},
	{"Display Details","D", NULL_STR, do_node, "details", NULL, 
							0, NULL_STR},
	{"Sep",         NULL_STR, NULL_STR, NULL, NULL_STR, NULL,
                                                           0, NULL_STR},
	{"Signal Process", "S", NULL_STR, do_node, "signal",  NULL, 
							0, NULL_STR},
	{"Kill Process", "K", NULL_STR, do_node, "kill",  NULL, 
							0, NULL_STR},
	{"Sep",         NULL_STR, NULL_STR, NULL, NULL_STR, NULL,
                                                           0, NULL_STR},
	{"Hide Subtree",   "H", NULL_STR, do_node, "hide",    NULL, 
							0, NULL_STR},
	{"Show Subtree",   "S", NULL_STR, do_node, "show",    NULL, 
							0, NULL_STR},
	{"Outline Subtree","O", NULL_STR, do_node, "outline", NULL, 
							0, NULL_STR},
};

xs_menu_struct TreePopupData[]={
	{"Show All Hidden Processes",  "S", NULL_STR, 
			do_tree_popup,"show_all",NULL,0,NULL_STR},
	{"Toggle Tree Outline","O",NULL_STR,
			do_tree_popup,"outline",NULL,0,NULL_STR},
};

extern Popup_on_pid;
extern tnode *Head;

extern User_group_info *Users;

extern tnode *display_node_widget();
extern tnode *redisplay_node();

extern Debug;

tnode *outline_all();

Widget
setup_node_popup_menu( parent )
Widget parent;
{
	Widget 	menu;
	Arg 	wargs[10];
	int 	n;

	DEBUG0(1, "setup_node_popup_menu\n" );

	n = 0;
	menu = XmCreatePopupMenu( parent, "node_popup_menu", wargs, n );

	xs_create_menu_buttons( NULL, menu, NodePopupData, 
						    XtNumber(NodePopupData));

	return( menu );
}

Widget
setup_tree_popup_menu( parent )
Widget parent;
{
	Widget 	menu;
	Arg 	wargs[10];
	int 	n;

	DEBUG0(1, "setup_tree_popup_menu\n" );

	n = 0;
	menu = XmCreatePopupMenu( parent, "tree_popup_menu", wargs, n );

	xs_create_menu_buttons( NULL, menu, TreePopupData, 
						XtNumber(TreePopupData));
	return( menu );
}

doStrace( pid )
int pid;
{
	char cmdStr[128];
	int effective_uid=0;

	DEBUG1(1, "doStrace: on(%d)\n", pid );

	effective_uid = geteuid();

	if ( effective_uid != 0 )
	{
	    user_alert(TreeWidget,"Cannot Trace Process!! Treeps needs to be setuid root.");
	    return;
	}
	else
	{
	    sprintf( cmdStr, 
	          "/usr/X11R6/bin/xterm +ls -e %s %d > /dev/null 2>&1 &", 
		  "/usr/bin/strace -p ", pid );
	}

	spawnExternal( cmdStr );
}

void 
do_node( w, client_data, call_data)
Widget w;
caddr_t client_data; 
XmPushButtonCallbackStruct  *call_data;
{
	int        	   new_value;
	int	   	   old_value;
	tnode	   	  *t_ptr;
	Process_tree_info *pti_ptr;
	XEvent	 	  *event;
	XButtonEvent	  *but_event;
	int		   externalAction=0;

	DEBUG1( 1, "do_node client data(%s)\n", client_data);

	/* Perform a one time only action on the process */

	old_value = Process_action;

	if ( strcmp( client_data, "select") == 0 )
	{
	 	new_value = ACTION_PROCESS_SELECT;
	}
	else if ( strcmp( client_data, "details") == 0 )
	{
	 	new_value = ACTION_PROCESS_DETAILS;
	}
	else if ( strcmp( client_data, "signal") == 0 )
	{
	 	new_value = ACTION_PROCESS_SIGNAL;
	}
	else if ( strcmp( client_data, "kill") == 0 )
	{
	 	new_value = ACTION_KILL_PROCESS;
	}
	else if ( strcmp( client_data, "outline") == 0 )
	{
	 	new_value = ACTION_OUTLINE_SUBTREE;
	}
	else if ( strcmp( client_data, "hide") == 0 )
	{
	 	new_value = ACTION_HIDE_SUBTREE;
	}
	else if ( strcmp( client_data, "show") == 0 )
	{
	 	new_value = ACTION_SHOW_SUBTREE;
	}
	else if ( strcmp( client_data, "man" ) == 0 )
	{
	 	externalAction = 1;
	}
	else if ( strcmp( client_data, "info") == 0 )
	{
	 	externalAction = 1;
	}
	else if ( strcmp( client_data, "locate") == 0 )
	{
	 	externalAction = 1;
	}
	else if ( strcmp( client_data, "strace") == 0 )
	{
	 	
		doStrace( Popup_on_pid );
	 	return;
	}

	Process_action = new_value;

	/* Corrupt the event pointer button to appear as if a selection
	 * was performed. We then lookup the node associated with the
	 * popup menu and call select_node to perform the desired 
	 * single event. After the one shot event, we set the Process_action
	 * back.
	 */

	event = call_data->event;

	but_event = (XButtonEvent *)event;

	but_event->button = 1;

	t_ptr = walk_tree( Head, match_key, Popup_on_pid );
	if ( t_ptr == NULL )
	{
		DEBUG1(0,"do_node: Failed to find process(%d)\n",Popup_on_pid);
		return;
	}

	pti_ptr = (Process_tree_info *)t_ptr->data;
	if ( pti_ptr == NULL )
	{
		DEBUG1(0, "do_node: process(%d) NULL pti_ptr\n", Popup_on_pid );
		return;
	}

	if ( externalAction )
		doExternalAction( client_data, pti_ptr->pp );
	else
		select_node( pti_ptr->label_w, t_ptr, event );

	Process_action = old_value;
}

tnode
*setNiceValue( t_ptr, niceDelta )
tnode *t_ptr;
int niceDelta;
{
	Process_tree_info *pti_ptr;
	char		   cmd[40];
	int		   currentNiceValue, newNiceValue;

	DEBUG2( 1, "setNiceValue pid(%d) delta(%d)\n", t_ptr->key, niceDelta);

	if ( t_ptr == NULL )
	{
	    DEBUG0(0,"setNiceValue: Null t_ptr!!\n");
       	    return( NULL_TNODE_PTR );
	}

	pti_ptr = (Process_tree_info *)t_ptr->data;
	if ( pti_ptr == NULL )
	{
	    DEBUG1(0, "setNiceValue: process(%d) NULL pti_ptr\n", t_ptr->key );
       	    return( NULL_TNODE_PTR );
	}

	currentNiceValue = PROCESS_NICE( pti_ptr->pp );

	newNiceValue = currentNiceValue + niceDelta;

	PROCESS_NICE( pti_ptr->pp ) = newNiceValue;

	sprintf(cmd, "/usr/bin/renice %d -p %d >/dev/null", newNiceValue, 
						t_ptr->key);

	spawnExternal( cmd );

       	return( NULL_TNODE_PTR );
}

void 
do_renice( w, client_data, call_data)
Widget w;
caddr_t client_data; 
XmPushButtonCallbackStruct  *call_data;
{
	tnode	   	  *t_ptr;
	Process_tree_info *pti_ptr;
	char		   cmd[40];
	int 		   effective_uid=0;
	int		   delta;


	DEBUG1( 1, "do_renice client data(%s)\n", client_data);

	t_ptr = walk_tree( Head, match_key, Popup_on_pid );
	if ( t_ptr == NULL )
	{
	    DEBUG1(0,"do_renice: Failed to find process(%d)\n",Popup_on_pid);
	    return;
	}

	pti_ptr = (Process_tree_info *)t_ptr->data;
	if ( pti_ptr == NULL )
	{
	    DEBUG1(0, "do_renice: process(%d) NULL pti_ptr\n", Popup_on_pid );
	    return;
	}

	effective_uid = geteuid();

	if ( effective_uid != 0 )
	{
	    if ( client_data[0] == '-' )
	    {
	     user_alert(TreeWidget,"Cannot Increase Process Priority!! Treeps needs to be setuid root");
	     return;
	    }
	}

	if ( client_data[0] == '-' )
		delta = 0 - (int) (client_data[1] - '0');
	else
		delta = client_data[0] - '0';
		
	setNiceValue( t_ptr, delta );
}

void 
do_renice_subtree( w, client_data, call_data)
Widget w;
caddr_t client_data; 
XmPushButtonCallbackStruct  *call_data;
{
	tnode	   	  *t_ptr;
	Process_tree_info *pti_ptr;
	char		   cmd[40];
	int 		   effective_uid=0;
	int		   currentNiceValue, newNiceValue, delta;


	DEBUG1( 1, "do_renice_subtree client data(%s)\n", client_data);

	t_ptr = walk_tree( Head, match_key, Popup_on_pid );
	if ( t_ptr == NULL )
	{
	    DEBUG1(0,"do_renice_subtree: Failed to find process(%d)\n",
						Popup_on_pid);
	    return;
	}

	pti_ptr = (Process_tree_info *)t_ptr->data;
	if ( pti_ptr == NULL )
	{
	    DEBUG1(0, "do_renice_subtree: process(%d) NULL pti_ptr\n", 
							    Popup_on_pid );
	    return;
	}

	effective_uid = geteuid();

	if ( effective_uid != 0 )
	{
	    if ( client_data[0] == '-' )
	    {
	     user_alert(TreeWidget,"Cannot Increase Process Priority!! Treeps need to be setuid root.");
	     return;
	    }
	}

	if ( client_data[0] == '-' )
		delta = 0 - (int) (client_data[1] - '0');
	else
		delta = client_data[0] - '0';
	

	walk_tree( t_ptr, setNiceValue, delta );
}




doExternalAction( action, pp )
char *action;
sysProcInfo *pp;
{
	char cmdStr[128];
	int effective_uid=0;

	if ( pp == NULL )
		return;

	DEBUG2(1, "doExternalAction: action(%s) on(%s)\n", action, PROCESS_CMD_NAME(pp) );

	/* If uid != euid , we should run the command su'ed
	 * back to the original user_id, this will prevent any 
	 * backdoor security hacks.
	 *
	 * To do this properly need to fork/exec and ensure
	 * no sneaky environment tricks are done.
	 *
	 * For the moment we are only invoking man,
	 * and we hard code paths for xterm and man.
	 * Also inform users during install of possibility
	 * of hacking root.
	 *
	 */

	effective_uid = geteuid();

	if ( Users->user_uid != effective_uid )
	{

	    /* Later add fork/exec stuff here 
	     *
	     *			Users->user_uid_str ); */

	    sprintf( cmdStr, "%s +ls -e %s %s > /dev/null 2>&1 &", 
	    			"/usr/X11R6/bin/xterm",
				action, 
				PROCESS_CMD_NAME(pp) );

	    /* printf("Fix security problem here\n" ); */

	    /*
	     *
	     * On linux we don't care as the program is either installed
	     * setuid(i.e. the installer trusts the users), or it's not.
	     * I assume the predominant linux install is currently single user
	     * systems. If it's a multi user system I assume the SA will
	     * read the comment and make the appropriate decision, hence
	     * the default suid install on linux.
	     *
	     * Solaris/unixware are more complicated and are covered in the
	     * next pointer release.
	     *
	     * The security model needs to be improved, i.e more granular.
	     * for example on some installations a SA may want to allow
	     * users to strace daemons, on other's they may not. In fact
	     * they may only allow strace on some daemons ...
	     *
	     * Linux needs suid root for viewing CWD, files, ... on
	     * some processes, but runs fine without it. Solaris/Unixware
	     * really need to be setuid.
	    */
	}
	else
	{
	    sprintf( cmdStr, 
	    		"/usr/X11R6/bin/xterm +ls -e %s %s > /dev/null 2>&1 &", 
			action, PROCESS_CMD_NAME(pp) );
	}


	spawnExternal( cmdStr );

}

void 
do_tree_popup( w, client_data, call_data)
Widget w;
caddr_t client_data; 
XmPushButtonCallbackStruct  *call_data;
{
	Process_tree_info  *pti_ptr;

	if ( strcmp( client_data, "show_all") == 0 )
	{
		XpsiDoTreeLayout( TreeWidget, False );
		walk_tree( Head, display_node_widget, 0 );
		XpsiDoTreeLayout( TreeWidget, True );
	}
	else if ( strcmp( client_data, "outline") == 0 )
	{
		XpsiDoTreeLayout( TreeWidget, False );

		pti_ptr = (Process_tree_info *)Head->data;
		if ( pti_ptr->outline == True )
			walk_tree( Head, outline_all, False );
		else
			walk_tree( Head, outline_all, True );
		walk_tree( Head, redisplay_node, 0 );
		XpsiDoTreeLayout( TreeWidget, True );
	}
}

tnode
*outline_all( ptr, flag )
tnode *ptr;
int    flag;
{
	Process_tree_info  *pti_ptr;

	pti_ptr = (Process_tree_info *) ptr->data;

	if ( pti_ptr )
	{
		if ( flag )
			pti_ptr->outline = True;
		else
			pti_ptr->outline = False;
	}

	return( NULL );
}


int
spawnExternal( cmd )
char *cmd;
{
	system( cmd );
}
