
#include <varargs.h>
#include <stdio.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/Label.h>


void xs_wprintf(va_alist)
va_dcl
{
	Widget w;
	char *format;
	va_list args;
	Arg wargs[10];
	XmString xmstr;
	char str[10000];


	va_start(args);

	w = va_arg(args, Widget);

	/* if ( !XtIsSubclass( w, xmLabelWidgetClass ) )
		XtError("xs_wprintf() requires a label widget"); */

	format = va_arg(args, char *);

	(void) vsprintf( str, format, args );

	xmstr = XmStringLtoRCreate( str, XmSTRING_DEFAULT_CHARSET);

	XtSetArg(wargs[0], XmNlabelString, xmstr);

	XtSetValues( w, wargs, 1);

	va_end( args );
}
