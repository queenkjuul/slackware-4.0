/* File: match_list.c 
 *
 * Description:   
 *	        Return True if the supplied key matches a key of a list member.
 *
 * Author:	George MacDonald
 *
 * Copyright:	Copyright (c) 1995, Pulsar Software Inc.
 *		All Rights Reserved, Unpublished rights reserved.
 *
 * History:	George MacDonald	2/08/95	Created
 *         	George MacDonald	4/11/95	Broke out into seperate file
 *            
 */


#include <stdio.h>

#include "list.h"	/* Package definitions */

int
match_list( list, key )
lnode *list;
int    key;
{
	lnode *p;

	for ( p = list; p != NULL_LNODE_PTR; p = p->next )
	{
		if ( p->key == key )
			return( 1 );
	}

	return( 0 );
}
