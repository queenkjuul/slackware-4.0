/* invert_fgbg.c: Inverts a widgets forground and background colors */

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>


void xs_invert_fgbg( w )
Widget w;
{
	Pixel	fg;
	Pixel	bg;
	Arg     wargs[4];
	int	n;

	n = 0;
	XtSetArg( wargs[n], XmNforeground,  &fg); n++;
	XtSetArg( wargs[n], XmNbackground,  &bg); n++;
	XtGetValues( w, wargs, n);

	n = 0;
	XtSetArg( wargs[n], XmNforeground,  bg); n++;
	XtSetArg( wargs[n], XmNbackground,  fg); n++;
	XtSetValues( w, wargs, n);
}
