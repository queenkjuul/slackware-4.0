/* File: contruct_lnode.c 
 *
 * Description:   
 *	            Create a list node with supplied data and return pointer
 *
 * Author:	George MacDonald
 *
 * Copyright:	Copyright (c) 1995, Pulsar Software Inc.
 *		All Rights Reserved, Unpublished rights reserved.
 *
 * History:	George MacDonald	2/08/95	Created
 *         	George MacDonald	4/11/95	Broke out into seperate files
 *            
 */


#include <stdio.h>
#include <stdlib.h>

#include "list.h"	/* Package definitions */


lnode
*construct_lnode( key, data )
int   key;
void *data;
{
	lnode *ptr = ( lnode *) malloc(sizeof(lnode));

	if ( ptr != NULL )
	{
		ptr->key   = key;
		ptr->data  = data;
		ptr->next  = NULL_LNODE_PTR;
	}
	else
		fprintf(stderr, "construct_lnode: malloc failed(%d)\n", key);

	return( ptr );
}
