/* File:        widget_tip.c
 *
 * Description: Code to display a "widget tip" for a specified widget
 *              A widget tip is a window which is pop'ed when the mouse 
 *		moves into the the specified widget. It's
 *              similar to a tooltip/widget_tip/ballon_help ...
 *
 * Author:      George MacDonald
 *
 * Copyright:   GPL - see http://www.gnu.org
 *
 * History:     George MacDonald        2/15/99        Created
 *
 *
 */


#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <time.h>

#include "../src/debug.h"

void 		xs_widget_tip();

static void 	widget_tip_enter();
static void 	widget_tip_leave();
static void 	widget_tip_press();
static void 	widget_tip_startup_timeout();
static void 	widget_tip_uptime_timeout();

static void 	widget_tip_motion();

static Window 	create_widget_tip_window();
void 		destroy_widget_tip();

void 		widget_tip_cancel_timer();

void 		widget_tip_set_bg_color();
void 		widget_tip_set_fg_color();
void 		widget_tip_set_font();


Window 		Widget_tip_window=0;

XtIntervalId 	Widget_tip_interval_id=-1;

char 		*Widget_tip_str=NULL;

time_t 		Last_widget_tip_time=0;

Position 	Widget_tip_x, Widget_tip_y;

Widget   	Widget_tip_w=NULL;

int		Default_widget_tip_uptime=5000;
int		Default_widget_tip_startup_delay=800;
char 		*Default_widget_tip_fontname="8x13";
Pixel		Default_widget_tip_bg=-1;
Pixel		Default_widget_tip_fg=-1;

int		Widget_tip_uptime;
int		Widget_tip_startup_delay;
char 		*Widget_tip_fontname;
Pixel		Widget_tip_bg=-1;
Pixel		Widget_tip_fg=-1;

extern int debug;



void
xs_widget_tip( w, tipStr )
Widget w;
char *tipStr;
{
	static int first=1;

	if ( first )
	{
		widget_tip_set_bg_color( w, "yellow" );
		widget_tip_set_fg_color( w, "black" );

		Default_widget_tip_bg = Widget_tip_bg;
		Default_widget_tip_fg = Widget_tip_fg;

		Widget_tip_uptime	 = Default_widget_tip_uptime;
		Widget_tip_startup_delay = Default_widget_tip_startup_delay;
		Widget_tip_fontname      = Default_widget_tip_fontname;
		Widget_tip_bg		 = Default_widget_tip_bg;
		Widget_tip_fg		 = Default_widget_tip_fg;

		first = 0;
	}

	
	XtAddEventHandler(w, EnterWindowMask, FALSE, widget_tip_enter, tipStr);

	XtAddEventHandler(w, LeaveWindowMask, FALSE, widget_tip_leave, NULL);
	XtAddEventHandler(w, ButtonPressMask, FALSE, widget_tip_press, NULL);

	/*XtAddEventHandler(w,PointerMotionMask,FALSE,widget_tip_motion,NULL);*/
}

void
widget_tip_enter( w, tipStr, event, continueDispatch)
Widget w;
char *tipStr;
XCrossingEvent *event;
Boolean *continueDispatch;
{
	Arg 		wargs[20];
	int 		n;
	time_t		time_now;
	Widget 		parent;
	XtAppContext 	ctx;
	Display 	*display;
	Position	widget_x, widget_y;
	Position	root_x, root_y;

	DEBUG1( 8, "widget_tip_enter: tipStr(%s)\n", tipStr );


	display = XtDisplay( w );
	ctx     = XtWidgetToApplicationContext( w );

	*continueDispatch = TRUE;

	Widget_tip_w = w;

	n = 0;
	XtSetArg( wargs[n], XtNwidth,  &widget_x ); n++;
	XtSetArg( wargs[n], XtNheight, &widget_y ); n++;
	XtGetValues( w, wargs, n );

	XtTranslateCoords( w, widget_x, widget_y, &root_x, &root_y );

	Widget_tip_x = root_x - ( widget_x / 3 );
	Widget_tip_y = root_y + 6;

	DEBUG4( 8, "widget_tip_enter: x(%d) y(%d) root:x(%d)y(%d)\n", 
				widget_x, widget_y, root_x, root_y);

	DEBUG1( 8, "event->detail(%d)\n", event->detail );

	time( &time_now );
	if ( tipStr == NULL )
	{
		DEBUG0(8,"No tip string!!!\n");
		return ;
	}
	else	/* Create a widget tip? */
	{

		if ( event->detail == NotifyAncestor ) /* 0 - Normal Enter */
		{
			DEBUG0(8,"Entering widget: Notify Ancestor\n" );
		}
		if ( event->detail == NotifyVirtual ) 
		{
			DEBUG0(8,"Entering widget: Notify Virtual\n" );
		}
		if ( event->detail == NotifyInferior ) 
		{
			DEBUG0(8,"Entering widget: Notify Inferior\n" );
		}
		if ( event->detail == NotifyNonlinear ) /* 3 */
	        {
			DEBUG0(8,"Entering widget: Notify NonLinear\n" );
		}

		if ( event->detail == NotifyNonlinearVirtual ) 
		{
			DEBUG0(8,"Entering widget: Notify NonLinearVirtual\n" );
		}


		if ( Widget_tip_window != 0 ) /* Already got one up!? */
		{

			if ( strcmp( Widget_tip_str, tipStr) != 0 )
			{
				DEBUG0(8,"Entering widget: Teardown old tip!\n");
			        destroy_widget_tip(w);
			}
			else
			{
				DEBUG0(8,"Entering widget: Tip already up!!\n");
				return;
			}
		}

		/* We are go for widget tip */


		/* If a widget tip was recently active, then user is probably
		 * looking for a tip so put one up right away.  Otherwise wait 
		 * till the mouse is inactive for a small amount of time 
		 * while in the widget before poping up tip.
		 */

		if ( Widget_tip_str == NULL )
			Widget_tip_str = strdup(tipStr);

		if ( Last_widget_tip_time + 0 > time_now )
		{
		    DEBUG0(8,"Popup widget tip: Immediately \n");
		    Widget_tip_window = create_widget_tip_window( w, tipStr,
		    				Widget_tip_x, Widget_tip_y);

		    Widget_tip_interval_id = XtAppAddTimeOut( ctx,
		    				Widget_tip_uptime,
		    				widget_tip_uptime_timeout, 
						w 			   );
		}
		else
		{
		    DEBUG0(8,"Popup widget tip: firing startup timer \n");

		    Widget_tip_interval_id = XtAppAddTimeOut( ctx,
		    				Widget_tip_startup_delay,
		    				widget_tip_startup_timeout, w );
		}

		Last_widget_tip_time = time_now;
	}
	
	*continueDispatch = FALSE;

	return;
}

void
widget_tip_press( w, tipStr, event, continueDispatch)
Widget w;
char *tipStr;
XButtonPressedEvent *event;
Boolean *continueDispatch;
{
	destroy_widget_tip(w);

	*continueDispatch = TRUE;
}


void
widget_tip_leave( w, tipStr, event, continueDispatch)
Widget w;
char *tipStr;
XCrossingEvent *event;
Boolean *continueDispatch;
{
	Arg 		wargs[20];
	int 		n;
	time_t		time_now;
	Widget 		parent;
	XtAppContext 	ctx;
	Display 	*display;

	display = XtDisplay( w );
	ctx     = XtWidgetToApplicationContext( w );

	*continueDispatch = TRUE;

	Widget_tip_w = w;
	Widget_tip_x = event->x_root; 
	Widget_tip_y = event->y_root;  


	DEBUG3( 8, "widget_tip_leave: tipStr(%s) event->x(%d) event->y(%d)\n", 
				Widget_tip_str, event->x_root, event->y_root);

	DEBUG1( 8, "event->detail(%d)\n", event->detail );


	if ( event->detail == NotifyAncestor ) /* 0 - Normal Leave */
	{
		DEBUG0(8,"Leaving widget: Notify Ancestor\n" );
	}
	if ( event->detail == NotifyVirtual ) 
	{
		DEBUG0(8,"Leaving widget: Notify Virtual\n" );
	}
	if ( event->detail == NotifyInferior ) 
	{
		DEBUG0(8,"Leaving widget: Notify Inferior\n" );
	}
	if ( event->detail == NotifyNonlinear ) /* 3 - Into tip */
	{
		DEBUG0(8,"Leaving widget: Notify NonLinear\n" );
	}
	if ( event->detail == NotifyNonlinearVirtual ) 
	{
		DEBUG0(8,"Leaving widget: Notify NonLinearVirtual\n" );
	}

	time( &time_now );
	if ( tipStr == NULL )
	{
		if ( event->detail == NotifyNonlinear )
	        {
			Last_widget_tip_time = time_now;
			destroy_widget_tip(w);
		}
		else
		{
			DEBUG0(8,"Leaving widget: on widgets border\n");
			destroy_widget_tip(w);
		}

		Widget_tip_w = NULL;
	}
	else	/* Eh? */
	{
		DEBUG0(8,"Leave widget(%d) with non null string!\n" );
		return;
	}
	
	*continueDispatch = FALSE;

	return;
}

void
widget_tip_motion( w, tipStr, event, continue_dispatch)
Widget w;
char *tipStr;
XMotionEvent *event;
Boolean *continue_dispatch;
{
	unsigned long 		timeout;
	XtTimerCallbackProc 	timeout_func;
	XtAppContext 		ctx;

	ctx = XtWidgetToApplicationContext( w );

	DEBUG2(8,"Widget_tip_motion x(%d)/y(%d)\n",event->x_root,event->y_root);

	/* Cancel old timer */

	if ( Widget_tip_interval_id != -1 )
	{
		XtRemoveTimeOut( Widget_tip_interval_id );
		Widget_tip_interval_id = -1;
	}


	/* Reset timer */

	if ( Widget_tip_window == 0 ) 	/* Waiting to popup widget tip */
	{
		DEBUG0(8,"Reset widget tip startup timer \n");
		timeout      = Widget_tip_startup_delay;
		timeout_func = widget_tip_startup_timeout;
	}
	else
	{
		DEBUG0(8,"Reset widget tip uptime timer \n");
		timeout      = Widget_tip_uptime;
		timeout_func = widget_tip_uptime_timeout;
	}

	Widget_tip_interval_id = XtAppAddTimeOut( ctx, timeout, 
						timeout_func, w );

	*continue_dispatch = FALSE;
}

void
widget_tip_startup_timeout( w, id )  
Widget       w;
XtIntervalId id;
{
	XtAppContext 	ctx;

	ctx = XtWidgetToApplicationContext( w );


	if ( Widget_tip_window == 0 )
	{
		DEBUG1(8,"widget_tip_startup_timeout: creating widget tip(%s)\n",
						Widget_tip_str );

		if ( Widget_tip_w == NULL || Widget_tip_str == NULL )
		{
			DEBUG0(8,"widget_tip_timeout: Too Late\n");
			return;
		}

		Widget_tip_window = create_widget_tip_window(
					Widget_tip_w,
					Widget_tip_str, 
					Widget_tip_x, 
					Widget_tip_y		);

		Widget_tip_interval_id = XtAppAddTimeOut( ctx,
		    				Widget_tip_uptime,
		    				widget_tip_uptime_timeout, 
						w 			   );
	}
	else
	{
		DEBUG0(8,"widget_tip_startup_timeout: Already up!!!\n");
	}
}

void
widget_tip_uptime_timeout( w, id )  
Widget       w;
XtIntervalId id;
{

	if ( Widget_tip_window == 0 )
	{
		DEBUG0(8, "widget_tip_uptime_timeout: no widget tip!!\n");
	}
	else 
	{
		Widget_tip_interval_id = -1;
		destroy_widget_tip( w );
	}

}

void
destroy_widget_tip( w )
Widget w;
{
	time_t	time_now;

	time( &time_now );

	if ( Widget_tip_window != 0 )
	{
		DEBUG1(8,"destroying_widget_tip(%s)\n", Widget_tip_str );
		XDestroyWindow( XtDisplay( w ), Widget_tip_window );
		Widget_tip_window = 0;
	}

	if ( Widget_tip_str != NULL )
	{
		free( Widget_tip_str );
		Widget_tip_str = NULL;
	}

	Last_widget_tip_time = time_now;

	widget_tip_cancel_timer();
}

void
widget_tip_cancel_timer()
{

	if ( Widget_tip_interval_id != -1 )
	{
		DEBUG0(8,"Canceling widget tip Timer\n");
		XtRemoveTimeOut( Widget_tip_interval_id );
		Widget_tip_interval_id = -1;
	}
}

Window
create_widget_tip_window( w, str, x, y )
Widget w;
char *str;
int x;
int y;
{
	static int first=1;
	static Display *display=NULL;
	static int screen;
        static char *window_name = "Widget_tip";
        static XFontStruct *font_info;
        static int depth;
        static Visual *visual;
        static unsigned int class;
        static unsigned long valuemask;
        static unsigned long GCvaluemask=0;
        static XSetWindowAttributes setwinattr;
        static XGCValues values;
	static int border_width;
        int 		window_size = 0;
        XSizeHints 	size_hints;
        XEvent 		report;
        int  		str_x, str_y;
	unsigned int 	width, height;
	int 		len;
        GC 		gc;		/* Need to free this */
	Window		win;

	if ( first )
	{
	    border_width = 1;

	    display = XtDisplay( w );
	    screen  = DefaultScreen( display );
 
            if ((font_info = XLoadQueryFont(display, Widget_tip_fontname))==NULL)
            {
                fprintf( stderr, "Can't open %s font!!!!\n",Widget_tip_fontname);
                return( 0 );
            }

	    depth = CopyFromParent;
            class = CopyFromParent;
            visual = CopyFromParent;

            valuemask = CWBackPixel | CWBorderPixel | CWOverrideRedirect ;

	    if ( Widget_tip_bg == -1 )
	    	widget_tip_set_bg_color( w, "yellow" );

	    if ( Widget_tip_fg == -1 )
	    	widget_tip_set_fg_color( w, "black" );

            setwinattr.background_pixel = Widget_tip_bg;

            setwinattr.border_pixel = BlackPixel( display, screen );
            setwinattr.override_redirect = True;

	    first = 0;
	}

        len = strlen( str );
	width = XTextWidth( font_info, str, len ) + 6;
        height = font_info->max_bounds.ascent + font_info->max_bounds.descent +4;

        str_x = 3;
        str_y = font_info->max_bounds.ascent + 2;

        win = XCreateWindow( display, RootWindow(display, screen ),
                        x, y,
                        width, height,
                        border_width,
                        depth,
                        class,
                        visual,
                        valuemask,
                        &setwinattr );

        gc = XCreateGC( display, win, GCvaluemask, &values );

        XSetFont( display, gc, font_info->fid );


        /* XSetForeground( display, gc, BlackPixel(display, screen) ); */

        XSetForeground( display, gc, Widget_tip_fg );

	size_hints.flags = PPosition | PSize | PMinSize;
        size_hints.x = x;
        size_hints.y = y;
        size_hints.width = width;
        size_hints.height = height;
        size_hints.min_width = width;
        size_hints.min_height = height;

        XSetStandardProperties( display, win, window_name, NULL,
        				   0, NULL, 0, &size_hints );

        XMapWindow( display, win );

        XDrawString( display, win, gc, str_x, str_y, str, len );

	XFlush( display );

	XFreeGC( display, gc );

        return( win );
}

/* These must be called before first creation of a widget tip, otherwise
 * the default values will be used
 */

void
widget_tip_set_bg_color( w, colorName )
Widget w;
char *colorName;
{
	Display *dpy;
        int      scr;
        Colormap cmap;
        XColor   color;
        XColor   exact;
        int      rc;

        dpy  = XtDisplay( w );
        scr  = DefaultScreen( dpy );
        cmap = DefaultColormap( dpy, scr );

        /* Lookup Pixel colors based on character string symbolic names */

        rc = XAllocNamedColor( dpy, cmap, colorName, &color, &exact );
        if ( rc )
                Widget_tip_bg = color.pixel;
        else
        {
                fprintf(stderr, 
			"Warning: Couldn't allocate widget tip bg color %s\n",
                                                                colorName);
                Widget_tip_bg = WhitePixel(dpy, scr);
        }
}


void
widget_tip_set_fg_color( w, colorName )
Widget w;
char *colorName;
{
	Display *dpy;
        int      scr;
        Colormap cmap;
        XColor   color;
        XColor   exact;
        int      rc;

        dpy  = XtDisplay( w );
        scr  = DefaultScreen( dpy );
        cmap = DefaultColormap( dpy, scr );

        /* Lookup Pixel colors based on character string symbolic names */

        rc = XAllocNamedColor( dpy, cmap, colorName, &color, &exact );
        if ( rc )
                Widget_tip_fg = color.pixel;
        else
        {
                fprintf(stderr, 
			"Warning: Couldn't allocate widget tip fg color %s\n",
                                                                colorName);
                Widget_tip_fg = BlackPixel(dpy, scr);
        }
}

void
widget_tip_set_font( fontName )
char *fontName;
{
	/* Small memory leak here */

	Default_widget_tip_fontname = strdup( fontName );

	Widget_tip_fontname = Default_widget_tip_fontname;
}
