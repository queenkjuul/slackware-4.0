/* File: rev_insert_lnode.c 
 *
 * Description:   
 *	        Create and Insert a new member with the supplied key and data,
 *		maintaining the reverse order of the list. Return the modified
 *		list, possibly with a new head.
 *
 *		NOTE: If a node already exists with the supplied key the
 *		      new node is not added and  _new_list_entry is set to 0.
 *
 *
 * Author:	George MacDonald
 *
 * Copyright:	Copyright (c) 1995, Pulsar Software Inc.
 *		All Rights Reserved, Unpublished rights reserved.
 *
 * History:	George MacDonald	2/08/95	Created
 *         	George MacDonald	4/11/95	Broke out into seperate file
 *            
 */

#include <stdio.h>

#include "list.h"	/* Package definitions */

/* int _new_list_entry=0;		Declared in fwd_insert_lnode.c   */

lnode
*rev_insert_lnode( list, key, data )
lnode *list;
int    key;
void  *data;
{
	lnode *new_node, *ptr, *last_ptr;

	_new_list_entry = 0;

	new_node = construct_lnode( key, data );
	if ( new_node == NULL_LNODE_PTR )
		return( list );

	/* reverse sorted insertion, larger numbers first in list  */

	if ( list == NULL_LNODE_PTR )
		list = new_node;
	else
	{
		/* Find position in list in which to insert the new node */
		last_ptr = list;
		for ( ptr = list; ptr != NULL_LNODE_PTR; ptr = ptr->next )
		{
			if ( new_node->key >= ptr->key )
				break;
			last_ptr = ptr;
		}

		if ( ptr && (new_node->key == ptr->key) ) /* Already in list */
		{
			/* We null out the data pointer so we don't free users 
			 * data by accident. They should track the
			 * _new_list_entry variable and do it themselves
			 */

			new_node->data = NULL;
			destroy_lnode( new_node );
			return( list );
		}

		_new_list_entry++;
		if ( ptr == NULL_LNODE_PTR )  	/* append to list 	  */
		{
			last_ptr->next = new_node;
		}
		else if ( ptr == list )  	/* Insert at head of list */
		{
			new_node->next = list;
			list = new_node;
		}
		else				/* Into the middle of list */
		{
			last_ptr->next = new_node;
			new_node->next = ptr;
		}
	}

	return( list );
}
