
/* lpstat -  linux process status
 *
 * test prog to load and display linux process status info from
 * /proc/<pid>/status
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#include "loadValues.h"

size_t PageSize;         /* From treeps.c */
int    MaxSig=31;        /* Ditto */

int Debug=0;
int debug=0;

main( argc, argv )
int argc;
char *argv[];
{
	int 	pid = getpid();
	int 	i=0, n=1;
	struct linuxProcessStat lps;
	time_t start_at, end_at;


	PageSize = 4096;

	if ( argc > 1 )
		pid = atoi( argv[1] );

	printf( "Process status for pid(%d):\n\n", pid );

	
	n = 1;
        start_at = time((time_t *)0);
	for ( i = 0; i < n; i++ )
	{
		loadProcessStat( pid, &lps );
		loadCmdLine( pid, &lps );
		loadProcessStatus( pid, &lps );
	}

        end_at = time((time_t *)0);

	printf("loadProcessStat: %d times took(%d) secs\n", n,
					end_at - start_at );

	printProcessStat( &lps );
}


