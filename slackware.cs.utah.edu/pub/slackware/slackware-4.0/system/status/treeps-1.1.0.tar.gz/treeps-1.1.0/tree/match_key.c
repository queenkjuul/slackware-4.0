/* File: 	match_key.c:  
 *
 * Description:	Function used by walk_tree to check if the supplied key
 *		matches the one in the supplied tnode pointer.
 *
 *
 * Author:	George MacDonald
 *
 * Copyright:	Copyright (c) 1995, Pulsar Software Inc.
 *		All Rights Reserved, Unpublished rights reserved.
 *
 * History:	George MacDonald	2/18/95	Created
 *            
 */

#include "tree.h"

tnode
*match_key( ptr, key )
tnode *ptr;
int key;
{
	if ( ptr->key == key )
		return( ptr );
	else
		return( NULL_TNODE_PTR );
}

