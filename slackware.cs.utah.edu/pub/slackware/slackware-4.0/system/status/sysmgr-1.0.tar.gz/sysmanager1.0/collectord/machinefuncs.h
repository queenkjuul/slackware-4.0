/* 
   machinefucs.c contains the following functions which handle all machine
   manipulation that occurs in serverd. 

   Authors:
      Jason Carlyle
      Phile White

   Last Modification:
      5/12/97
*/

/* Adds a new machine to machine list */
int add_machine(char []);

/* Advances the machine list current pointer */
void advance_machine(void);

/* Removes a machine from the machine list */
int remove_machine(char []);

/* Updates the info string of a machine */
int update_machine(char [], char *);

/* Warns that it could not contact machine */
int warn_machine(char []);

/* Returns the machine specified */
struct machine *find_machine(char *);
