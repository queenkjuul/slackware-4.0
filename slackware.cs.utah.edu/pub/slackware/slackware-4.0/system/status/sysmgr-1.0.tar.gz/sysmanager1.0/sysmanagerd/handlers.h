/* The following functions are signal handlers for the code in server.c */

void try_to_register(int); /* When raised, tries to re-register the machine */
void check_msg_queue(int); /* Check the Message queue for message from Child */
void remove_msq(int);      /* On exit remember to remove the msqid */
