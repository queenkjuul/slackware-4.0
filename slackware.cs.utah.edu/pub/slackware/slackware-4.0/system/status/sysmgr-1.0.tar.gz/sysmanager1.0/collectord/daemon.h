/*
 * Daemon help functions.
 * Eric Jeschke  4/20/1997
 */
#ifndef _DAEMON_h
#define _DAEMON_h

/*
 * Detach a daemon process from login session context.
 */
int
daemon_start (void);

#endif /*_DAEMON_h*/
