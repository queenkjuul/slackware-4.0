/* the format for the string created by this procedure is:
   hostname
   domainname (its usually "(none)" for some reason
   arch type
   OS type
   os version
   os release
   # of users
   uptime in seconds
   load average (1 min)
   load average (5 min)
   load average (15 min)
   total ram (bytes)
   free ram
   total swap
   free swap
   # of procs
   total blocks on /
   blocks free on /
   total inodes on /
   free inodes on /

   all fields are delimited with a single pipe "|"
   */



void getstatus(char *);
