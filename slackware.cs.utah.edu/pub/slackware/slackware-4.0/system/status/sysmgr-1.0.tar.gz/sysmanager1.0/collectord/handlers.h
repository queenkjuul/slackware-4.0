/* The following funcation serve as signal handlers for the code
   is server.c

   Authors:
      Jason Carlyle
      Phil White

   Last Modification:
      5/12/97
   */

/* Check the message queue when SIGUSR1 is raised (usually by the child). */
void check_msg_queue(int);

/* Function built to simulate a raised SIGIO */
void async_request(int);

/* Handles communication between the server and the User Interface. */
void client_interaction(FILE *, FILE *, char[16]);

/* Upon SIGINT or SIGTERM, the msqid should be removed from the system. */
void remove_msq(int);
