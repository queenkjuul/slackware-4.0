/* Thomas Haukland, tompi@bigfoot.com, 18. Sep. 1998 */
/* Color-replacement for Linux "mem" and "df" */
/* Tested on kernel 2.0.35 only... */

#define BLACK 0
#define RED 1
#define GREEN 2
#define BROWN 3
#define BLUE 4
#define PURPLE 5
#define CYAN 6
#define GREY 7

#define BAR_LENGTH 50
#define BOLD 2
#define INVERSE 1
#define NORMAL 0


extern void color_printf(int color, int inv, char string[]);

extern void color_printf_int(int color, int inv, int number);

extern void color_print_summary(int i, int j, char string[]);

extern void bar_printf(int color_used, int color_free, int used, int total);
