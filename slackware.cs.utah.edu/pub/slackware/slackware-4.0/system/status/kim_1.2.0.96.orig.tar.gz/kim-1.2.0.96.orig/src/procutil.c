
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include "kim.h"

/* is strlist from ps ? */

char *strlist(char *buff, char **strs, char* sep, unsigned max) {
    int i, n, seplen = strlen(sep);
    for (n=0; *strs && n < max; strs++) {
	for (i=0; strs[0][i] && n+i < max; i++)
	    if (isprint(strs[0][i]) || strs[0][i] == ' ')
		*buff++ = strs[0][i];
	    else {
		if (max-(n+i) > 3) {
		    *buff++ = strs[0][i];
		    n += 3; /* 4 printed, but i counts one */
		} else {
		    *buff = '\0';
		    return buff;
		}   
	    }
	n += i;
	if (n + seplen < max) {
	    for(i=0; i<=seplen-1; i++)  
	    	*buff++ = sep[i];
	    n += seplen;
	} else {
	    *buff = '\0';
	    return buff;
	}    
    }
    *buff = '\0';
    return buff;
}

char *sprint_time(char *s, time_t *t, int max) 
{
	struct tm *time;
	
	time = localtime(t);
	
	if (*t <= 0) 
		sprintf(s, "      ");
	else if (*t < 3600)
		sprintf(s, _("%2d:%02d min"), time->tm_min, time->tm_sec);
	else if (*t < 3600*24)
		sprintf(s, _("%2d:%02d hour"), time->tm_hour, time->tm_min);		
	else if (*t < 3600*24*366) 
		sprintf(s, _("%2d:%02d day"), time->tm_yday, time->tm_hour);
	else 
		sprintf(s, _("%2d:%02d year"), time->tm_year, time->tm_yday);	
	return s;	
}

/* prtime is from: ps.c                
 *
 * Copyright (c) 1992 Branko Lankester
 */

char *prtime(char *s, unsigned long t, unsigned long rel) {
    if (t == 0) {
        sprintf(s, "     ");
        return s;
    }
    if ((long) t == -1) {
        sprintf(s, "   xx");
        return s;
    }
    if ((long) (t -= rel) < 0)
        t = 0;
    if (t > 9999)
        sprintf(s, "%5lu", t / 100);
    else
        sprintf(s, "%2lu.%02lu", t / 100, t % 100);
    return s;
}

