
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <sys/param.h>
#include <proc/sysinfo.h>

#include "kim.h"

#if PROCPS_1_2
	#include <proc/ps.h>
#else
	#include <proc/procps.h>
#endif

#include "procdata.h" 
#include "procutil.h"
#include "proccols.h"
#include "procsort.h"
#include "layout.h"

/* --- Kim cols ---*/
kim_COLS 	kc[] = { 
	#include "proccols_name.h"
};

int	sorted_kc[COLS_NUM+1];

/* Sort Cols names A->Z */
static int sort_cols(int *a, int *b)
{
	return (int) strcmp( (kc + *a)->name, (kc + *b)->name);
}

int *get_sort_cols()
{
	static int	is_sorted=FALSE, i;
	
	_D( " get_sort_cols() ");
	
	if (!is_sorted) {
		for (i=0; i<=COLS_NUM; i++)
			*(sorted_kc+i) = i;
		qsort(sorted_kc, COLS_NUM+1, sizeof(&sorted_kc),
              		(int (*) (const void *, const void *)) sort_cols);
		is_sorted = TRUE;
	}	 
	return sorted_kc;
}

void null_cols_width( kim_DATA *d ) 
{
	_D( " null_cols_width() ");

	memset(d->cols_width, 0, (COLS_NUM+1) * sizeof(int));
	d->tree_width = 0;
	d->area_width = 0;
}
     
void set_cols_width( kim_DATA *d ) {
	kim_COLS	*p_kc;	
	int		a, *cw, b;
	
	_D( " set_cols_width() ");
	
	for(p_kc=kc, cw=d->cols_width; p_kc->name!=chN; p_kc++, cw++) {
		memset(ks.tmp, ' ', TMP_SIZE*sizeof(char));
		p_kc->maker(ks.tmp, d);
		b = strlen(p_kc->name);
		if ((a=strlen(ks.tmp))  > *cw) {
			*cw = a > p_kc->width_max ?  p_kc->width_max : a; 
			*cw = *cw < b ? b : *cw;  
		}
	}
}

/* -------------------------------------------- 
   Next is kim API for access to process data and
   data sorting (if not used default sorter). 

   If you want add new cols, you must write new func. 
   (to this .c and .h) and add cols name, description, 
   width and data func. pointer to proccols_name.h and enum
   to proccols_enum.h.
   
   func. pattern:   
   =============
   
   inline char *cols_yourcolsname(char *buff, kim_DATA *d) 
   {
   	return buff;
   }

   inline int sort_yourcolsname(int *a, int *b) 
   {
   	if (d->sort_mode == SORT_DATA_DESC)
   		return ....... FALSE or TRUE
   	else
   		return ....... TRUE  or FALSE
   }
   
  --------------------------------------------- */


inline char *cols_name(char *buff, kim_DATA *d)
{
       return strncpy(buff, d->cpt->cmd, TMP_SIZE);	 
}

inline char *cols_state(char *buff, kim_DATA *d)
{      
     *buff = d->cpt->state;		 
     if (d->cpt->rss == 0 && d->cpt->state != 'Z')
        *(buff+1) = 'W';
     else
        *(buff+1) = ' ';
     if (d->cpt->nice < 0)
	*(buff+2) = '<';
     else if (d->cpt->nice > 0)
	*(buff+2) = 'N';
     else
	*(buff+2) = ' ';
     *(buff+3) = '\0';
    return buff;
}

inline char *cols_tty(char *buff, kim_DATA *d)
{
#if PROCPS_1_2
       return strncpy(buff, d->cpt->ttyc, TMP_SIZE);	 
#else
       return strncpy(buff, d->cpd->ttyc, TMP_SIZE);	 
#endif
}       

inline char *cols_cmdline(char *buff, kim_DATA *d)
{
      if (d->cpd->cmdline)
      	return strncpy(buff, d->cpd->cmdline, TMP_SIZE);      
      else { 	
	*buff ='\0';
	return buff;
      }	
}

inline char *cols_pid(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", d->cpt->pid); 
       return buff;
}
inline int sort_pid(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->pid > 
   			(*(sorted_d->pt + *b))->pid ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->pid > 
			(*(sorted_d->pt + *b))->pid ? TRUE : FALSE);    		
}


inline char *cols_ppid(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", d->cpt->ppid); 
       return buff;
}
inline int sort_ppid(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->ppid > 
   			(*(sorted_d->pt + *b))->ppid ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->ppid > 
			(*(sorted_d->pt + *b))->ppid ? TRUE : FALSE);    		
}

inline char *cols_pgrd(char *buff,  kim_DATA *d) 
{       
       sprintf(buff, "%d", d->cpt->pgrp); 
       return buff;
} 
inline int sort_pgrd(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->ppid > 
   			(*(sorted_d->pt + *b))->ppid ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->ppid > 
			(*(sorted_d->pt + *b))->ppid ? TRUE : FALSE);    		
}

inline char *cols_session(char *buff, kim_DATA *d) 
{        
       sprintf(buff, "%d", d->cpt->session); 
       return buff;
}
inline int sort_session(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->session > 
   			(*(sorted_d->pt + *b))->session ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->session > 
			(*(sorted_d->pt + *b))->session ? TRUE : FALSE);    		
}

inline char *cols_ttynum(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", d->cpt->tty); 
       return buff;
}
inline int sort_ttynum(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->tty > 
   			(*(sorted_d->pt + *b))->tty ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->tty > 
			(*(sorted_d->pt + *b))->tty ? TRUE : FALSE);    		
}

inline char *cols_tpgid(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", d->cpt->tpgid); 
       return buff;
}
inline int sort_tpgid(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->tpgid > 
   			(*(sorted_d->pt + *b))->tpgid ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->tpgid > 
			(*(sorted_d->pt + *b))->tpgid ? TRUE : FALSE);    		
}

inline char *cols_start(char *buff, kim_DATA *d) 
{
       time_t	time_v, sec;
   
       sec	= (d->current_time * HZ - d->cpt->start_time)/HZ;
       time_v	= d->time_now - sec;
       strftime(buff, TMP_SIZE, (sec > 3600*24 ? "%b %d" : "%H:%M"), localtime(&time_v));
       return buff;
}
inline int sort_start(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->start_time > 
   			(*(sorted_d->pt + *b))->start_time ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->start_time > 
			(*(sorted_d->pt + *b))->start_time ? TRUE : FALSE);    		
}

inline char *cols_etime(char *buff, kim_DATA *d) 
{ 
   int 		current_time; 	/* Not usage GL_current_time >>> always update */    
   time_t	time_v;
   
   if (!(current_time = uptime(0,0))) {
         *buff = '\0';
         return buff;
   }      
   if (d->cpt->start_time > current_time * HZ) 
         time_v = 0;
   else 
         time_v = (current_time * HZ - d->cpt->start_time) / HZ;
   sprint_time(buff, &time_v, TMP_MAX);
   return buff;
}
inline int sort_etime(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->start_time < 
   			(*(sorted_d->pt + *b))->start_time ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->start_time < 
			(*(sorted_d->pt + *b))->start_time ? TRUE : FALSE);    		
}

inline char *cols_uid(char *buff, kim_DATA *d) 
{        
       sprintf(buff, "%d",d->cpt->INDEP_UID); 
       return buff;
}
inline int sort_uid(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->INDEP_UID > 
   			(*(sorted_d->pt + *b))->INDEP_UID ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->INDEP_UID > 
			(*(sorted_d->pt + *b))->INDEP_UID ? TRUE : FALSE);    		
}

inline char *cols_user(char *buff, kim_DATA *d) 
{
       return strncpy(buff, d->cpt->INDEP_USER, TMP_SIZE);   
}       

inline char *cols_pmem(char *buff, kim_DATA *d) 
{       
       long 	i = get_mem_total(d),
       		pmem = d->cpt->rss * 1000 / (i >> PAGE_SHIFT);
       if (pmem > 999) pmem = 999;
       sprintf(buff, "%2ld.%ld", (pmem / 10), (pmem % 10)); 
       return buff;
}


inline char *cols_size(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", (int) d->cpt->vsize >> 10 ); 
       return buff;
}
inline int sort_size(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->size > 
   			(*(sorted_d->pt + *b))->size ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->size > 
			(*(sorted_d->pt + *b))->size ? TRUE : FALSE);    		
}

inline char *cols_rss(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lu", (conf_L.inpage ? d->cpt->rss : d->cpt->rss << (PAGE_SHIFT-10) )); 
       return buff;
}
inline int sort_rss(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->rss > 
   			(*(sorted_d->pt + *b))->rss ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->rss > 
			(*(sorted_d->pt + *b))->rss ? TRUE : FALSE);    		
}

inline char *cols_rss_rlim(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lu", d->cpt->rss_rlim); 
       return buff;
}
inline int sort_rss_rlim(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->rss_rlim > 
   			(*(sorted_d->pt + *b))->rss_rlim ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->rss_rlim > 
			(*(sorted_d->pt + *b))->rss_rlim ? TRUE : FALSE);    		
}

inline char *cols_resident(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", (int) (conf_L.inpage ? d->cpt->resident : d->cpt->resident << (PAGE_SHIFT-10))); 
       return buff;
}
inline int sort_resident(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->resident > 
   			(*(sorted_d->pt + *b))->resident ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->resident > 
			(*(sorted_d->pt + *b))->resident ? TRUE : FALSE);    		
}

inline char *cols_share(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", (int) (conf_L.inpage ? d->cpt->share : d->cpt->share << (PAGE_SHIFT-10))); 
       return buff;
}
inline int sort_share(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->share > 
   			(*(sorted_d->pt + *b))->share ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->share > 
			(*(sorted_d->pt + *b))->share ? TRUE : FALSE);    		
}

inline char *cols_dt(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", (int) (conf_L.inpage ? d->cpt->dt : d->cpt->dt << (PAGE_SHIFT-10)));
       return buff;
}
inline int sort_dt(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->dt > 
   			(*(sorted_d->pt + *b))->dt ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->dt > 
			(*(sorted_d->pt + *b))->dt ? TRUE : FALSE);    		
}

inline char *cols_trs(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", (int) (conf_L.inpage ? d->cpt->trs : d->cpt->trs << (PAGE_SHIFT-10))); 
       return buff;
}
inline int sort_trs(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->trs > 
   			(*(sorted_d->pt + *b))->trs ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->trs > 
			(*(sorted_d->pt + *b))->trs ? TRUE : FALSE);    		
}

inline char *cols_lrs(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", (int) (conf_L.inpage ? d->cpt->lrs : d->cpt->lrs << (PAGE_SHIFT-10))); 
       return buff;
}
inline int sort_lrs(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->lrs > 
   			(*(sorted_d->pt + *b))->lrs ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->lrs > 
			(*(sorted_d->pt + *b))->lrs ? TRUE : FALSE);    		
}

inline char *cols_drs(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", (int) (conf_L.inpage ? d->cpt->drs : d->cpt->drs << (PAGE_SHIFT-10))); 
       return buff;
}
inline int sort_drs(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->drs > 
   			(*(sorted_d->pt + *b))->drs ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->drs > 
			(*(sorted_d->pt + *b))->drs ? TRUE : FALSE);    		
}

inline char *cols_swap(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%d", (int) (conf_L.inpage ? (d->cpt->size - d->cpt->resident) : 
                                 (d->cpt->size - d->cpt->resident) << (PAGE_SHIFT-10) )); 
       return buff;
}
inline int sort_swap(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return (( (*(sorted_d->pt + *a))->size - (*(sorted_d->pt + *a))->resident) > 
   			( (*(sorted_d->pt + *b))->size - (*(sorted_d->pt + *b))->resident) 
   			? FALSE : TRUE); 
   	else
		return (( (*(sorted_d->pt + *a))->size - (*(sorted_d->pt + *a))->resident) > 
			( (*(sorted_d->pt + *b))->size - (*(sorted_d->pt + *b))->resident) 
			? TRUE : FALSE);    		
}

inline char *cols_minflt(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lu", d->cpt->min_flt); 
       return buff;
}

inline char *cols_majflt(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lu", d->cpt->maj_flt); 
       return buff;
}

inline char *cols_cminflt(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lu", d->cpt->cmin_flt); 
       return buff;
}

inline char *cols_cmanflt(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lu", d->cpt->cmaj_flt); 
       return buff;
}

inline char *cols_pcpu(char *buff, kim_DATA *d) 
{       
	long total_time, seconds;
    	unsigned int pcpu;
	
    	seconds = (((d->current_time * (long)HZ) - d->cpt->start_time) / HZ);
    	total_time = (d->cpt->utime + d->cpt->stime);
        pcpu = seconds ? (total_time * 10 * 100 / HZ) / seconds : 0;
    	if (pcpu > 999) pcpu = 999;	
	sprintf(buff, "%2u.%u", pcpu / 10, pcpu % 10);
        return buff;
}
inline int sort_pcpu(int *a, int *b) 
{
	long total_time, seconds;
    	unsigned int a_pcpu, b_pcpu;
	
	/* A */
    	seconds =   ((sorted_d->current_time * (long) HZ) - 
    		     (*(sorted_d->pt + *a))->start_time) / HZ;
    	total_time = (*(sorted_d->pt + *a))->utime + (*(sorted_d->pt + *a))->stime;
        a_pcpu = seconds ? (total_time * 10 * 100 / HZ) / seconds : 0;
	/* B */
	seconds =   ((sorted_d->current_time * (long) HZ) - 
    		     (*(sorted_d->pt + *b))->start_time) / HZ;
    	total_time = (*(sorted_d->pt + *b))->utime + (*(sorted_d->pt + *b))->stime;
        b_pcpu = seconds ? (total_time * 10 * 100 / HZ) / seconds : 0;
	
	if (sorted_d->sort_mode == SORT_DATA_DESC)
		return ( a_pcpu > b_pcpu ? FALSE : TRUE); 
	else	
		return ( a_pcpu > b_pcpu ? TRUE  : FALSE); 
}

inline char *cols_priority(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%ld", (long) d->cpt->priority); 
       return buff;
}
inline int sort_priority(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->priority > 
   			(*(sorted_d->pt + *b))->priority ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->priority > 
			(*(sorted_d->pt + *b))->priority ? TRUE : FALSE);    		
}

inline char *cols_nice(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%ld", (long) d->cpt->nice); 
       return buff;
}
inline int sort_nice(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->nice > 
   			(*(sorted_d->pt + *b))->nice ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->nice > 
			(*(sorted_d->pt + *b))->nice ? TRUE : FALSE);    		
}

inline char *cols_timeout(char *buff, kim_DATA *d) 
{       
      return prtime(buff, d->cpt->timeout, d->current_time * HZ);
}
inline int sort_timeout(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->timeout > 
   			(*(sorted_d->pt + *b))->timeout ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->timeout > 
			(*(sorted_d->pt + *b))->timeout ? TRUE : FALSE);    		
}

inline char *cols_time(char *buff, kim_DATA *d) 
{
       unsigned t;        
       t = (d->cpt->utime + d->cpt->stime) /HZ;
       sprintf(buff, "%3d:%02d ", t / 60, t % 60);
       return buff;
}
inline int sort_time(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return (( (*(sorted_d->pt + *a))->utime + (*(sorted_d->pt + *a))->stime) > 
   			( (*(sorted_d->pt + *b))->utime + (*(sorted_d->pt + *b))->stime) 
   			? FALSE : TRUE); 
   	else
		return (( (*(sorted_d->pt + *a))->utime + (*(sorted_d->pt + *a))->stime) > 
			( (*(sorted_d->pt + *b))->utime + (*(sorted_d->pt + *b))->stime) 
			? TRUE : FALSE);    		
}

inline char *cols_ctime(char *buff, kim_DATA *d) 
{
       unsigned t;        
       t =  (d->cpt->utime + d->cpt->stime) /HZ; 
       t += (d->cpt->cutime + d->cpt->cstime) /HZ;
       sprintf(buff, "%3d:%02d ", t / 60, t % 60);
       return buff;
}
inline int sort_ctime(int *a, int *b) 
{
	unsigned at, bt; 
   	at =  ((*(sorted_d->pt + *a))->utime  + (*(sorted_d->pt + *a))->stime)  / HZ;
   	at += ((*(sorted_d->pt + *a))->cutime + (*(sorted_d->pt + *a))->cstime) / HZ;
   	bt =  ((*(sorted_d->pt + *b))->utime  + (*(sorted_d->pt + *b))->stime)  / HZ;
   	bt += ((*(sorted_d->pt + *b))->cutime + (*(sorted_d->pt + *b))->cstime) / HZ;
   	
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ( at > bt ? FALSE : TRUE); 
   	else
		return ( at > bt ? TRUE  : FALSE); 
}

inline char *cols_flags(char *buff, kim_DATA *d) 
{        
       sprintf(buff, "%lx", d->cpt->flags); 
       return buff;
}

inline char *cols_start_code(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lx", d->cpt->start_code); 
       return buff;
}

inline char *cols_end_code(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lx", d->cpt->end_code); 
       return buff;
}

inline char *cols_start_stack(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lx", d->cpt->start_stack); 
       return buff;
}

inline char *cols_kstk_esp(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lx", d->cpt->kstk_esp); 
       return buff;
}

inline char *cols_kstk_eip(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lx", d->cpt->kstk_eip); 
       return buff;
}

inline char *cols_wchan(char *buff, kim_DATA *d) 
{       
       return strncpy(buff, wchan(d->cpt->wchan), TMP_SIZE);        
}

inline char *cols_signal(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lx", (unsigned long) d->cpt->signal); 
       return buff;
}

inline char *cols_blocked(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lx", (unsigned long) d->cpt->blocked); 
       return buff;
}

inline char *cols_sigignore(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lx", (unsigned long) d->cpt->sigignore); 
       return buff;
}

inline char *cols_sigcatch(char *buff, kim_DATA *d) 
{       
       sprintf(buff, "%lx", (unsigned long) d->cpt->sigcatch); 
       return buff;
}

inline char *cols_alarm(char *buff, kim_DATA *d) 
{      
   time_t	x = (time_t) d->cpt->it_real_value / HZ;
   
   sprint_time(buff, &x, TMP_MAX);
   /* ps comatible: return prtime(buff, d->cpt->it_real_value, 0); */
   return buff;
}
inline int sort_alarm(int *a, int *b) 
{
   	if (sorted_d->sort_mode == SORT_DATA_DESC)
   		return ((*(sorted_d->pt + *a))->it_real_value > 
   			(*(sorted_d->pt + *b))->it_real_value ? FALSE : TRUE); 
   	else
		return ((*(sorted_d->pt + *a))->it_real_value > 
			(*(sorted_d->pt + *b))->it_real_value ? TRUE : FALSE);    		
}