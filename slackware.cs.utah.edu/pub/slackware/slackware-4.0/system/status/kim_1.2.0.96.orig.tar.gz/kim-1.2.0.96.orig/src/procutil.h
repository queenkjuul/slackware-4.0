
#ifndef __PROCUTIL_H
#define __PROCUTIL_H

extern char	*strlist(char *buff, char **strs, char* sep, unsigned max);
extern char	*sprint_time(char *s, time_t *t, int max);
extern char	*prtime(char *s, unsigned long t, unsigned long rel);

#endif