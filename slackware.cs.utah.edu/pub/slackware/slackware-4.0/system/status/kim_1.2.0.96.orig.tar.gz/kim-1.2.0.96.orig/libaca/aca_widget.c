
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */
 
#include "aca.h"
#include "aca_draw.h"
#include "aca_key.h"
#include "aca_widget.h"
#include "aca_util.h"

#include <ctype.h>
#include <stdarg.h>

/* ------- predefined widgets ------- 
   - for complet dialogs definition see the file aca_dlg.h
 */ 

Wbutton def_button[] = {
	{ N_( "[ |Q|uit ]"	), 0,0 },
	{ N_( "[ |O|k ]"	), 0,0 },
	{ N_( "[ |C|ancel ]"	), 0,0 },
	{ N_( "[ |S|ave ]"	), 0,0 },
	{ N_( "[ |N|ew ]"	), 0,0 }
};


/* ------- widget func. and session utils ------- */

static int is_mouse_in_menu(SessW *s, Widget *w, Wmenu *m) ;

static void W_mvaddastr (Widget *w, int m, int n, char *astr, int c, int c2) 
{	
	if (!(w->flag & Wf_NOTUSE_ASTR)) { 	
		mvaddastr(m, n, astr, c, c2);	
	} else {				
		aca_c(c2);			
		mvaddstr(m, n, astr);		
	}					
}


int get_astr_size(Widget *w)
{
	_D( "get_astr_size() ");
	
	if (w->widget_fn == menu_fn) {
		Wmenu	*m;
		m = (Wmenu *) w->widget_data;
		return m->astr_size;
	} else  if (w->widget_fn == button_fn) {
		Wbutton	*b;
		b = (Wbutton *) w->widget_data;
		return b->astr_size;
	} else if (w->widget_fn == radio_fn) {
		Wradio	*r;
		r = (Wradio *) w->widget_data;
		return r->astr_size;
	} else  if (w->widget_fn == input_fn) {
		Winput	*inp;
		inp = (Winput *) w->widget_data;
		return inp->astr_size;
	}
	return FALSE;
}

/*
	Init alist (set strings locale)
	- return max width of alist   
*/
int init_alist(char **alist, int num)
{
	char 	**p;
	int	max=0, i;
	
	_D("init_alist()");
	
	for(p=alist; p <= alist + num; p++) {
		*p = _(*p);
		if ((i=astrlen(*p)) > max)
			max = i; 
	}
	return max;	
}

/*******
	Set widget 'x' position for more widgets which go to follow first
	widget. Format string set interspace between widgets and x position 
	of next widget, x position is always set as a:
	
	 'x position of previous widget' + 'astr_size of previous widget'
	 + 'interspace between 'w' in format string'. 
	 
	Example:
	
	set_widgets_progresion(20, "w w    w", &A, &B, &C);
				     ^ ^^^^
		    - interspace:    1	4
	
	is --> 	A.x = 20;
		B.x = 20 + A.astr_size + 1;
		C.x = 20 + A.astr_size + B.astr_size + 1 + 4;
	
	&A is pointer to Widget A

	Note: this func. is need for locale (size of strings is floating 
	      between differet translation) - strings size (value astr_size 
	      in Widget struct) is set in init_sessw().
	
*******/

int set_widgets_progresion(int first_x, char *format, ...)
{
	va_list	ap;
	int	poz=0;
	Widget	*w;
	
	_D( "set_widgets_progresion()");
	
	va_start(ap, format);
	while(*format) {
		if (*format == 'w') {
			w = va_arg(ap, Widget *);
			w->x = first_x + poz;
			poz += get_astr_size(w);  
		} else if (*format == ' ') 
			poz++;
		format++;
	}	
	va_end(ap);
	return poz+first_x;	
}

void set_widget(Widget *wtab, SessW *s, int new_actual)
{
      int	old = s->actual;
      
      if (s->count == 0) return;
      s->actual	= new_actual;	
      if (s->lock) {
      	s->lock = FALSE;
      	W_redraw_session(s);
      }
      curs_set(0);
      wtab[ old ].widget_fn (s, &wtab[ old ], 
         wtab[old].widget_data,	0, WIDGET_DRAW);  
      wtab[ s->actual ].widget_fn (s, &wtab[s->actual], 
         wtab[s->actual].widget_data, 0, WIDGET_DRAW);  				
}

#define SET_ASTR(wed,data)	{					\
	if ((data)->astr) {						\
		(data)->astr  = _((data)->astr);			\
		if ((wed)->hotkey==TRUE) 				\
			(wed)->hotkey = gethotkey((data)->astr);	\
	} 								\
}									\

void init_sessw(SessW *s)
{
	Widget 	*w;
	int	i=0;
	
	_D(" init_sessw()");
	
	for(w=s->wtab; w->widget_fn != NULL; w++, i++) {
		w->id = i;		
		if (w->widget_fn == button_fn) {
			Wbutton	*b;
			b = (Wbutton *) w->widget_data;
			SET_ASTR(w, b);
			if ((b->astr_size = astrlen(b->astr)-1) > 0) 
				w->cols = b->astr_size;
		} else if (w->widget_fn == radio_fn) {
			Wradio	*r;
			r = (Wradio *) w->widget_data;
			SET_ASTR(w, r);
			if ((r->astr_size = astrlen(r->astr)-1) > 0)
				w->cols = r->astr_size + 4;
		} else  if (w->widget_fn == input_fn) {
			Winput	*inp;
			inp = (Winput *) w->widget_data;
			SET_ASTR(w,inp);
			if ((inp->astr_size = astrlen(inp->astr)) > 0)
				w->cols = inp->astr_size + inp->max;
		} else  if (w->widget_fn == menu_fn) {
			Wmenu	*m;
			m = (Wmenu *) w->widget_data;
			if((m->flag & M_TITLE) || (m->flag & M_TOPTITLE)) {
				SET_ASTR(w,m);
				m->astr_size = astrlen(m->astr)-1;
			} 
			if(m->flag & M_ALIST) 
				w->cols = init_alist(m->alist, m->item_max)+1;
			
		} 
	}	
}

int W_go_down(SessW *s)
{
	Widget	*w;
	int	jump=1;
	
	for(w=(s->wtab+s->actual+1); w->widget_fn != NULL; w++) {
		if (w->flag & Wf_NOTVISIBLE)	++jump;
		else 				break;	
	}
	if (s->actual+jump > s->count) {
		if ((*s->wtab).flag & Wf_NOTVISIBLE) {
			s->actual = 0;
			W_go_down(s);
			W_redraw_session(s);
			return RE_OK;
		} else
			set_widget(s->wtab, s, 0);
		return RE_OK;	
	}
	set_widget(s->wtab, s, s->actual+jump);
	return RE_OK;
}

int W_go_up(SessW *s)
{
	int	i, jump=1;

	for(i=s->actual-1; i>=0; i--) {
		if (s->wtab[i].flag & Wf_NOTVISIBLE) 
			++jump;
		else 
			break;	
	}
	if (s->actual-jump < 0 ) {
		if ((*(s->wtab+s->count)).flag & Wf_NOTVISIBLE) {
			s->actual = s->count;
			W_go_up(s);
			W_redraw_session(s);
			return RE_OK;
		} else
			set_widget(s->wtab, s, s->count);
		return RE_OK;	
	}
	set_widget(s->wtab, s, s->actual-jump);
	return RE_OK;
}

void W_default_go(SessW *s)
{
    	if (!s->lock) {
		if (s->key==KEY_DOWN || s->key==KEY_RIGHT || s->key=='\t') 
			W_go_down(s);
		if (s->key==KEY_UP   || s->key==KEY_LEFT)  
			W_go_up(s);
	}
}

void W_redraw_session(SessW *s)
{
    	Widget	*w;
    	curs_set(0);
    	if (!(s->flag & Sf_HAVENT_BGR))
    		s->bgr_redraw(s);

	for(w=s->wtab; w->widget_fn != NULL; w++) {
		if (w != s->wtab+s->actual)
			w->widget_fn(s, w, w->widget_data, K_STAY, WIDGET_DRAW); 
	}
	
	if (s->actual >= 0)
		(*(s->wtab+s->actual)).widget_fn(s, s->wtab+s->actual, 
			(*(s->wtab+s->actual)).widget_data, K_STAY, WIDGET_DRAW); 
}

int W_key_to_widgets(SessW *s)
{	
	int	re = Wr_OK;
	Widget	*w;
	
	for(w=s->wtab; w->widget_fn != NULL; w++) {
		if (w != s->wtab+s->actual) {
			if ((*(s->wtab+s->actual)).flag & Wf_TYPE_INPUT)
				if (s->key != K_MOUSE_L) continue;
			re = w->widget_fn(s, w, w->widget_data, s->key, WIDGET_KEY); 
		}
		if (re != Wr_OK)
			return re;    
	}
    	return Wr_OK;
}

int is_mouse_in_widget(Widget *w, SessW *s) 
{   
#ifdef HAVE_MOUSE
	Wmenu	*m;
	   
	if (!aca.mouse) 
   		return FALSE;
	
	/* is actual widget over widget *w ? */
	if (s->actual != w->id) {
		if (w->widget_fn == menu_fn) {
   			m = (Wmenu *) (*(s->wtab+s->actual)).widget_data;
   			if (is_mouse_in_menu(s, (s->wtab+s->actual), m))
   				return FALSE;
		} else if (is_mouse_in_widget((s->wtab+s->actual), s)) 
			return FALSE;
	}
   	if (w->widget_fn == menu_fn) {
   		m = (Wmenu *) w->widget_data;
   		return is_mouse_in_menu(s, w, m); 
   	} else if (aca.mouse_x >= w->x && aca.mouse_x <= w->cols+w->x &&
   	    		aca.mouse_y >= w->y && aca.mouse_y <= w->lines+w->y)
   		return TRUE;
#endif   		
   	return FALSE;	
} 
   
static int widget_keys(int key, Widget *w, SessW *s) 
{		
#ifdef HAVE_MOUSE         
         if (!(w->flag & Wf_NOTVISIBLE) && 
             ((key == K_MOUSE_L) && is_mouse_in_widget(w, s))) {
         	set_widget(s->wtab, s, w->id);
         	return TRUE;
         }	
         else 
#endif         
         if (w->hotkey) {
            	if (w->hotkey == (isupper(key) ? tolower(key) : key) ) {
            		set_widget(s->wtab, s, w->id);
            		return TRUE;
            	}	
         }	
         return FALSE;	
}
   
int button_fn(SessW *s, Widget *w, void *data, int key, int Msg)
{
      Wbutton	*b;
      b = (Wbutton *) data;
         
      switch(Msg) {
      
      case WIDGET_DRAW:
         if (b->flag & Wb_PRESS_GO) {
         	W_mvaddastr(w, w->y, w->x, b->astr, TplC->button.sel_astr, TplC->button.sel); 
         	return Wr_OK;
         }	
         if (w->id == s->actual)
            W_mvaddastr(w, w->y, w->x, b->astr, TplC->button.sel_astr, TplC->button.sel); 
         else if (!(w->flag & Wf_NOTVISIBLE)) 	
            W_mvaddastr(w, w->y, w->x, b->astr, TplC->button.nsel_astr, TplC->button.nsel); 				
         return Wr_OK;
      
      case WIDGET_KEY:
         if ((w->id == s->actual) && (key == ' ' || key == '\n' || 
         		widget_keys(key, w, s))) 
         	return Wr_BUTTON_PRESS;
         else {
    		if ((b->flag & Wb_PRESS_GO) && (w->id != s->actual)) {
       			if (widget_keys(key, w, s))
       				return Wr_BUTTON_PRESS;
       			else 
       				return Wr_OK;	
         	}	
         	widget_keys(key, w, s);
         }	
         return Wr_OK;	
      }
      return Wr_ERROR;
}

int radio_fn(SessW *s, Widget *w, void *data, int key, int Msg)
{
      Wradio	*r;
      r = (Wradio *) data;			
   
      switch(Msg) {
      case WIDGET_DRAW:
         if (w->id == s->actual) {
            W_mvaddastr(w, w->y, w->x+4, r->astr, TplC->radio.sel_astr, TplC->radio.sel); 
            aca_c(TplC->radio.sel);
            if (r->flag & B_DEPEND)
		mvprintw(w->y, w->x, "(%c) ", show_bit(*r->point, r->mybit) ? '*' : ' ');            	
            else
            	mvprintw(w->y, w->x, "(%c) ", r->set ? '*' : ' ');
            curs_set(1);	
            move(w->y, w->x+1);
         } 
         else if (!(w->flag & Wf_NOTVISIBLE)) {	
            W_mvaddastr(w, w->y, w->x+4, r->astr, TplC->radio.nsel_astr, TplC->radio.nsel); 
            aca_c(TplC->radio.nsel);
            if (r->flag & B_DEPEND)
            	mvprintw(w->y, w->x, "(%c) ", show_bit(*r->point, r->mybit) ? '*' : ' ');
            else	
            	mvprintw(w->y, w->x, "(%c) ", r->set ? '*' : ' ');
            curs_set(0);	
         }
         return Wr_OK;
      case WIDGET_KEY:
         if ((w->id == s->actual) && ((key == ' ' || key == '\n' || 
         		widget_keys(key, w, s))) ) {
            if (r->flag & B_DEPEND) {
            	if (!show_bit(*r->point, r->mybit)) {
            		*r->point =  0;
            		set_bit(r->point, r->mybit, 1);
            	}
            } else	
            	r->set = (r->set ? FALSE : TRUE);
            
            aca_c(TplC->radio.sel);
            mvprintw(w->y, w->x, "(%c) ", r->set ? '*' : ' ');
            curs_set(1);	
            move(w->y, w->x+1);
            if (r->flag & B_DEPEND) 
	    	return Wr_RADIO_DEPEND;
	    else        
	    	return (r->set ? Wr_RADIO_SET : Wr_RADIO_UNSET);
         } else 
         	widget_keys(key, w, s);         
         return Wr_OK;
      }
      return Wr_ERROR;
}

void input_to_str(Winput *i, int key)
{
      int	a;
   
 #ifdef HAVE_MOUSE
      if (key == K_MOUSE_L || key == K_MOUSE_M || key ==K_MOUSE_R || 
          key == K_STAY) 
      		return;
      else 
 #endif    
 
      if (key == KEY_LEFT && i->poz > 0) 
         --i->poz;
      else if (key == KEY_RIGHT && i->poz < i->max && i->poz < i->a_size) 
         ++i->poz; 
      else if (key == KEY_BACKSPACE && i->poz > 0) {
         for(a=--i->poz; a < i->a_size; a++) 
            i->str[a] = i->str[a+1];
         --i->a_size;	
      }
      else if (key == KEY_DC && i->poz < i->a_size ) {
         for(a=i->poz; a < i->a_size; a++) 
            i->str[a] = i->str[a+1];
         --i->a_size;	
      }
      else {
      	 if (key == '\t') return;
      	 if (isfunckey( key )) return;
         if (aca.output_7bit_only && !isascii(key))  
         	key = ' ';
         if (i->poz < i->a_size) 
            for(a=++i->a_size; a>=i->poz+1; a--) 
               i->str[a] = i->str[a-1];
         i->str[i->poz] = key;
         if (i->poz < i->max) ++i->poz;
         if (i->poz > i->a_size) i->a_size = i->poz;			
      }
      i->str[i->a_size] = '\0';
}

int input_fn(SessW *s, Widget *w, void *data, int key, int Msg)
{
      Winput	*i;
      int	a=0;			
      i = (Winput *) data;
   
      if (i->flag & Wi_TOP) a=1;
   
      ubold;
      
      switch(Msg) {
      case WIDGET_DRAW:
         if (w->id == s->actual) {
            W_mvaddastr(w, w->y, w->x, i->astr, TplC->input.title_sel_astr, TplC->input.title_sel); 
            curs_set(1);
            aca_c(TplC->input.sel);
            CLEAN_HLINE(w->y+a, w->x +i->astr_size, w->x + i->max + i->astr_size);	 
            mvaddstr(w->y+a, w->x+i->astr_size, i->str);
            move(w->y+a, w->x + i->astr_size + i->poz);
            s->lock = TRUE;
         } 
         else if (!(w->flag & Wf_NOTVISIBLE)) {	
            W_mvaddastr(w, w->y, w->x, i->astr, TplC->input.title_nsel_astr, TplC->input.title_nsel);
            curs_set(0);
            aca_c(TplC->input.nsel);
            CLEAN_HLINE(w->y+a, w->x + i->astr_size, w->x + i->max + i->astr_size);	 
            mvaddstr(w->y+a, w->x + i->astr_size, i->str);
         }
         return Wr_OK;
      case WIDGET_KEY:
         if (w->id == s->actual) {
            if (key==KEY_DOWN || key==KEY_UP || key=='\n' || key=='\t') {
            	s->lock = FALSE;
            	return Wr_OK;
            } else 
            	s->lock = TRUE;	

	#ifdef HAVE_MOUSE            
            if (key == K_MOUSE_L && is_mouse_in_widget(w, s)) {   
            	if (aca.mouse_x >= w->x+i->astr_size && aca.mouse_x <= i->max+i->astr_size+w->x)
            		i->poz = (aca.mouse_x - w->x - i->astr_size) > i->a_size ?
            				i->a_size : aca.mouse_x - w->x -i->astr_size;
            }
        #endif    

            input_to_str(i, key);
            
            aca_c(TplC->input.sel);
            CLEAN_HLINE(w->y+a, w->x + i->astr_size, w->x + i->max + i->astr_size+1);	 
            mvaddstr(w->y+a, w->x + i->astr_size, i->str);
            move(w->y+a, w->x + i->poz + i->astr_size);
            return Wr_INPUT_CHANGE;
         } else
         	widget_keys(key, w, s);	 
         return Wr_OK;
      }
      return Wr_ERROR;
}

#define	SCR_MAX	 (m->flag & M_BLANK ? m->scr_max-1 : m->scr_max)

/*
	Set actual item and menu line if one item (line) in menu erase
	! not set menu scr_max and item_max >>> you must set it before
	  this function <<< !  
	?? not tested: if in menu is M_BLANK line ???  
*/
void decrease_item(Wmenu *m) 
{
	if (m->fios > 0) { 
		if (m->item_max - m->fios - m->scr_max < 0) {
			--m->fios;
			--m->item_act; 
		}	
	} else {
		if (m->item_act > m->item_max)
			m->item_act = m->scr_act = m->scr_last = m->item_max;
	}
	m->scr_last = m->scr_act;
}

static void menu_seek(Wmenu *m, Widget *w, int k, int flag) 
{      
      int	ref=TRUE, 
      i, a;   
      if (m->item_max < 0) 
         return;
   
      if (k==KEY_UP  || k==KEY_DOWN  || k==KEY_HOME  || k==K_STAY || 
          k==KEY_END || k==KEY_NPAGE || k==KEY_PPAGE || k==KEY_LEFT || 
          k==KEY_RIGHT) {
      
         if (k!=K_STAY || k!=KEY_LEFT || k!=KEY_RIGHT || (flag & DUMMY_GO)) { 	
         /* If K_STAY redraw only, don't go */		
            m->scr_last  = m->scr_act;
            m->item_last = m->item_act; 
         }
         switch(k) {
         case KEY_PPAGE:
            if (m->fios - SCR_MAX > 0) {
               m->item_act -= SCR_MAX;
               m->fios -= SCR_MAX; 
               break;
            }     			
         case KEY_HOME: 
            if (m->fios > 0) ref = TRUE;
            m->fios = 0; 
            if (m->flag & M_BLANK) 
               		m->scr_act = 0 != m->blank ?  0 : 1;
            else
               		m->scr_act = 0;
            m->item_act = 0;		
            break;
         case KEY_NPAGE:
            if (m->fios + SCR_MAX < m->item_max && 
            m->lios + SCR_MAX < m->item_max) {
               m->item_act += SCR_MAX; 
               m->fios = m->lios; ref = TRUE;
               break; 		
            }		
         case KEY_END:
            if (m->fios == m->item_max - SCR_MAX) 
               ref = FALSE;
	       if (m->flag & M_BLANK)
	       		m->scr_act = m->scr_max != m->blank ? m->scr_max : SCR_MAX;                
               else
            		m->scr_act = m->scr_max;
            m->fios = m->item_max - SCR_MAX; 
            m->item_act = SCR_MAX + m->fios; 		
            break;
         case KEY_UP:			
            if (m->item_act > 0) { 
               --m->item_act;
               if (m->scr_act == 0 || ((m->flag & M_BLANK) && 
               			       (m->scr_act == 1)   && 
               			       (m->blank==0 ))) 
               		--m->fios;
               else ref=FALSE; 
               if (m->scr_act  > 0) --m->scr_act;
               if (m->flag & M_BLANK)
               		m->scr_act = m->scr_act != m->blank ? m->scr_act :
               			     (m->scr_act - 1 > 0 ? --m->scr_act : ++m->scr_act);
            }
            break;
         case KEY_DOWN: 
            if (m->item_act < m->item_max) {
               ++m->item_act;
               if (m->scr_act < m->scr_max) { 
                  ++m->scr_act; ref=FALSE; 
                  if (m->flag & M_BLANK)
                  	m->scr_act = m->scr_act != m->blank ? m->scr_act :
               			     (m->scr_act + 1 > m->scr_max ? --m->scr_act : ++m->scr_act);
               } 
               else { 
                  ++m->fios; ref=TRUE; 
               }
            }
            break;	
         case KEY_LEFT:
            if (m->sht_act > 0) {
               --m->sht_act;
            }	
            break;
         case KEY_RIGHT:
            if (m->sht_act <  m->sht_max) 
               ++m->sht_act;
            break;
         }        
      /* Check */  
         if (m->scr_last < 0 && m->item_max >= 0) m->scr_last = 0; 
         if (m->scr_act  < 0 && m->item_max >= 0) m->scr_act  = 0; 
         if (m->item_act < 0 && m->item_max >= 0) m->item_act = 0;
         if ((m->flag & M_BLANK) && (m->blank == 0) && (m->scr_act==0))
         	m->scr_act=1;
         if ((m->flag & M_BLANK) && (m->blank == m->scr_max) && (m->scr_act==m->scr_max))
         	m->scr_act=SCR_MAX;	
      
         if (!(flag & DUMMY_GO) ) { 
            if (ref==FALSE)  		
            /* Redraw (only) old */					
               m->line_printer(m, w, m->item_last, m->scr_last);
            else {
            /* Set lios */  
               m->lios = m->item_max > SCR_MAX + m->fios ? 
                  SCR_MAX + m->fios  :  m->item_max;	
            /* Redraw all line in menu */            	
               for (i=m->fios, a=0; i<=m->lios; i++, a++) {	
                  if ((m->flag & M_BLANK) && a==m->blank) { 
                  	--i; continue; 
                  }
                  if (i!=m->item_act) 
                  	m->line_printer(m, w, i, a);	
               } 	
            }
         /* Last print actual item */ 
            m->line_printer(m, w, m->item_act,  m->scr_act);
         }		
      }   	
}

void menu_dummy_go(Widget *w, Wmenu *m, int key, int num)
{
   	register int	a;
   	
        for(a=0; a<=num; a++) 
        	menu_seek(m, w, key, DUMMY_GO); 
}

static int check_dummy_go(Wmenu *m, int key, int num)
{
        if (m->flag & M_BLANK) {
        	if (key == KEY_DOWN && m->item_act <= m->blank && 
        			m->item_act+num >= m->blank) {
        		--num;
        	} else if (key == KEY_UP && m->item_act >= m->blank && 
        			m->item_act-num <= m->blank) {
        		--num;
        	}	
        }
        return num;
}

static void alist_seek(Wmenu *m, Widget *w, int key)
{
      register int	i;
   
      for(i=0; i<=m->item_max; i++) {     
         if (tolower(key) == gethotkey(m->alist[i])) {
            ACA_RESET_MENU(m);
            menu_dummy_go(w, m, KEY_DOWN, i-1);  
            key = K_STAY;
            break;
         }
      }
      menu_seek(m, w, key, 0); 
}

void mvaddastr_menu(Wmenu *m, int scr_line, int scr_col, int l, int i)
{  	
      WidgetColor	*color;
      
      if      (m->flag & M_COLORDIRECT)	color = &TplC->menu_direct;
      else if (m->flag & M_COLORIN)	color = &TplC->menu_in;
      else				color = &TplC->menu_out;
      
      if (m->scr_act == l) 
         mvaddastr(scr_line, scr_col, m->alist[i], 
            color->sel_astr, color->sel);
      else		
         mvaddastr(scr_line, scr_col, m->alist[i], 
            color->nsel_astr, color->nsel);			
}

static int is_mouse_in_menu(SessW *s, Widget *w, Wmenu *m) 
{   
#ifdef HAVE_MOUSE   	
   	int	a;

   	if (!aca.mouse)			return FALSE;
      	if (m->flag & M_TOPTITLE) 	a=2;
        else 				a=1;

      	/* title */
      	if ( ((m->flag & M_TITLE) || (m->flag & M_TOPTITLE)) && 
      	    aca.mouse_x >= w->x && 
      	    aca.mouse_x <= w->x + m->astr_size &&
   	    aca.mouse_y == w->y-a)
   		return TRUE;
      	
      	if (m->flag & M_BORDER) 	a=1;
        else 				a=0;
      	
      	/* still open */
      	if ( (m->flag & M_OPEN) && 
      	    aca.mouse_x >= w->x-a &&
      	    aca.mouse_x <= w->cols + w->x+a &&
      	    aca.mouse_y >= w->y-a &&
      	    aca.mouse_y <= m->scr_max + w->y + a)
      	    	return TRUE; 
   	/* if active and open */
   	else if (w->id == s->actual && 
      	    aca.mouse_x >= w->x-a &&
      	    aca.mouse_x <= w->cols + w->x+a &&
      	    aca.mouse_y >= w->y-a &&
      	    aca.mouse_y <= m->scr_max + w->y+a)
      	    	return TRUE; 
#endif   		
   	return FALSE;	
} 

int menu_fn(SessW *s, Widget *w, void *data, int key, int Msg)
{
      Wmenu		*m;
      WidgetColor	*color;
      int		a, i;
   
      m = (Wmenu *) data;
      
      if      (m->flag & M_COLORDIRECT)	color = &TplC->menu_direct;
      else if (m->flag & M_COLORIN)	color = &TplC->menu_in;
      else				color = &TplC->menu_out;
   
      if (m->flag & M_TOPTITLE) a=2;
      else a=1;
   
      switch(Msg) {
      case WIDGET_DRAW:
         ubold;
         if ((m->flag & M_BORDER) && (m->flag & M_OPEN)) 
            draw_linebox(w->y-1, w->y + m->scr_max+1,
               w->x-1, w->x + w->cols+1, color->border_nsel);	
         
         if (w->id == s->actual) {
            if (m->flag & M_BORDER) 
            	draw_linebox(w->y-1, w->y + m->scr_max+1,
               		w->x-1, w->x + w->cols+1, color->border_sel);	
     
            if ((m->flag & M_TITLE) || (m->flag & M_TOPTITLE)) {
               if (m->flag & M_TITLE_NSEL) 
                   W_mvaddastr (w, w->y - a, w->x, m->astr, 
               		          color->title_nsel_astr, color->title_nsel);	
               else		          
                   W_mvaddastr (w, w->y - a, w->x, m->astr, 
               		          color->title_sel_astr, color->title_sel);	
            } 
            menu_seek(m, w, K_STAY, 0);	     
            s->lock = TRUE;
         } 
         else if (!(w->flag & Wf_NOTVISIBLE)) {
            if ((m->flag & M_TITLE) || (m->flag & M_TOPTITLE))
            	W_mvaddastr(w, w->y - a, w->x, m->astr, 
                  color->title_nsel_astr, color->title_nsel);			
            if (m->flag & M_OPEN) { 
            	if (!(m->flag & M_STILLV)) {	
            		/* invisible cursor line */
            		i 		= color->sel;
            		a 		= color->sel_astr;
            		color->sel	= color->nsel;
            		color->sel_astr	= color->nsel_astr;
            		menu_seek(m, w, K_STAY, 0);
            		color->sel 	= i;	
            		color->sel_astr	= a;
            	} else
            		menu_seek(m, w, K_STAY, 0);	
            }	
         }
         return Wr_OK;
      case WIDGET_KEY:
         if (w->id == s->actual) {
            
            /* spec. for SHTMENU */
            if ((!(m->flag & M_SHTMENU)) || (key!=KEY_LEFT && key!=KEY_RIGHT) ) {
            	int	akey=1, ahot=2;
            
            
            /* go out of menu */
            if (key==KEY_LEFT || key==KEY_RIGHT || key=='\n' || key=='\t'             

            	|| ((m->flag & M_ALIST) && 
            	   ((akey = tolower(key)) == (ahot = gethotkey(m->alist[m->item_act]))))
            	 
            #ifdef HAVE_MOUSE	
            	/* press mouse over actual menu item */
                || (key == K_MOUSE_L && is_mouse_in_widget(w, s) 
            	    && aca.mouse_y - w->y == m->scr_act)
            #endif	
            	) {
            		if ((m->flag & M_ALIST) && (akey == ahot))
				key = '\n';
            		
            		if (key == K_MOUSE_L ) key = '\n';
			if ((!(m->flag & M_NOTOUT)) || key!='\n') {
				s->lock = FALSE;
               			if (key == '\n') s->key = KEY_DOWN;
              		}
              		return (key == '\n' ? 
               			((m->flag & M_OPEN) ? Wr_MENU_PRESS : Wr_MENU_PRESS | Wr_NEED_REDRAW) : 
               			((m->flag & M_OPEN) ? Wr_MENU_OUT   : Wr_MENU_OUT   | Wr_NEED_REDRAW));	      
            } else 
            	s->lock = TRUE;	
            
            } else /*  SHTMENU */ 
            	s->lock = TRUE;	
            
            if((m->flag & M_TITLE) || (m->flag & M_TOPTITLE)) {
               if (m->flag & M_TITLE_NSEL) 
                   W_mvaddastr (w, w->y - a, w->x, m->astr, 
               		          color->title_nsel_astr, color->title_nsel);	
               else		          
                   W_mvaddastr (w, w->y - a, w->x, m->astr, 
               		          color->title_sel_astr, color->title_sel);
            }    
            
	#ifdef HAVE_MOUSE            
            if (key == K_MOUSE_L && is_mouse_in_widget(w, s)) {
            	i = aca.mouse_y - w->y;
            	i-= m->scr_act; 
            	
            	if (i>0) 
            		menu_dummy_go(w, m, KEY_DOWN, 
            			check_dummy_go(m, KEY_DOWN, --i));
            	else 	
            		menu_dummy_go(w, m, KEY_UP, 
            			check_dummy_go(m, KEY_UP, i * -1 - 1));
            		
            	menu_seek(m, w, K_STAY, 0);	/* redraw menu */
            	return Wr_MENU_CHANGE;		
            }
        #endif    
            
            /* standard keys */ 
            if (m->flag & M_ALIST)	
               alist_seek(m, w, key);
            else	
               menu_seek(m, w, key, 0);
            return Wr_MENU_CHANGE;	
         
         /* not actual */
         } else if (widget_keys(key, w, s))
         	return Wr_OK;
         
         return Wr_OK;
      }
      return Wr_ERROR;
}
