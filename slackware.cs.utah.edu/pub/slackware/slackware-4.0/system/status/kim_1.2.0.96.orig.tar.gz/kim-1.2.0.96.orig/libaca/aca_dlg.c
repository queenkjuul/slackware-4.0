
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>
#include <string.h>

#include "aca.h"
#include "aca_key.h"
#include "aca_draw.h"
#include "aca_dlg.h"
#include "aca_util.h"
#include "aca_widget.h"

#define Y(a)	(a+y)
#define X(a)	(a+x)

int Dlg_YesNo (char *header, char *query, int xn)
{
	int	y, x, yn;
	 
	Widget	w[] = {
		{ TRUE, 0,0,0,5, button_fn, (void *) &def_button[_BUTT_OK],     Wf_DEFAULT },
		{ TRUE, 0,0,0,9, button_fn, (void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },			
		W_NULL
	};
	SessW	s = { 1, 0, FALSE, w, K_STAY, NULL, Sf_HAVENT_BGR };	

	init_sessw(&s);

	yn = lines_instr(query) + 5;	
	y = LINES/2 - yn/2;
	x = COLS/2 - xn/2 -1;
	aca_border(y, y+yn, x, x+xn, TplC->dlg_bgr);  
	CLEAN_BOX (y+1, y+yn-1, x+1, x+xn-1);  
	bold;  aca_c(TplC->dlg_header);	
	mvaddstr( Y(0), X(xn/2 - strlen(header)/2), header);  
	ubold; aca_c(TplC->dlg_bgr);		
	center_addnstr(Y(1), COLS/2, query, xn-4);
	w[0].y = Y(yn-4+3);	w[0].x = x + xn/4;
	w[1].y = Y(yn-4+3);	w[1].x = x + xn/2+xn/4-5; 
	W_redraw_session(&s);
	do {
		if (run_act_widget(&s) & Wr_BUTTON_PRESS) {
			if (s.actual == 0)	return TRUE;	 /* Ok */		
			else			return FALSE; /* Cancel */	 
		}
		W_key_to_widgets(&s);		
		W_default_go(&s);
	} while((s.key = get_k()) != KEY_F(10));  
	return FALSE;							
}

int Dlg_Warning_org (char *header, char *query, int xn, int action)
{
	int	y, x, yn;
	Widget	w[]= {
		{ TRUE, 0,0,0,9, button_fn, (void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },	
		W_NULL
	};
	SessW	s = { 0, 0, FALSE, w, K_STAY, NULL, Sf_HAVENT_BGR };	
	
	init_sessw(&s);
	
	yn = lines_instr(query) + 5;	
	y = LINES/2 - yn/2;
	x = COLS/2 - xn/2 -1;
	aca_border(y, y+yn, x, x+xn, TplC->dlg_warning);  
	CLEAN_BOX (y+1, y+yn-1, x+1, x+xn-1);  
	bold;  mvaddstr( Y(0), X(xn/2 - strlen(header)/2), header);  
	ubold; 
	if (!aca.color) aca_c(TplC->dlg_warning);		/* because: previous ubold */
	center_addnstr(Y(1), COLS/2, query, xn-4);
	w[0].y = Y(yn-4+3);	
	w[0].x = COLS/2-6;
	beep();
	W_redraw_session(&s);
	
	if (action == Warn_draw)
		return RE_OK;
		
	do {
		if (run_act_widget(&s) & Wr_BUTTON_PRESS) 
			return RE_OK;	 /* Ok */		
	} while((s.key = get_k()) != KEY_F(10));  
	return RE_OK;							
}

static void mpr_fileviewer (Wmenu *m, Widget *w, int i, int l) 
{
         set_color_menu_in(m, l);
         CLEAN_HLINE(l+ w->y, w->x, w->x + w->cols); 
         mvaddline_nstr (l+w->y, w->x+1, (char *) m->list, i, w->cols-1);	
}

void Dlg_FileViewer(char *filename, char *header, char *infoline, int xn)
{
	int		fd, flag=0, y, x, yn;
	char		*fbuff;
	Wmenu 	menu = {
		infoline, 0,0,0,0,0,0,0,0,0,0,0,0, alistN, voN, mpr_fileviewer  
	}; 
	Widget	w[] = {
		{ FALSE, 0,0,0,0, menu_fn,   (void *) &menu, Wf_NOTUSE_ASTR },
		{ TRUE,  0,0,0,9, button_fn, (void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },			
		W_NULL
	};
	SessW	s = { 1, 0, TRUE, w, K_STAY, NULL, Sf_HAVENT_BGR };	
	
	init_sessw(&s);
	
	if ((fd	= open(filename, O_RDONLY)) == -1) {
		ErrorOpen(filename);			
	}
	if ((fbuff = aca_loadfile(fd, flag)) == NULL) 
		return;
	menu.list	= (void *) fbuff;
	menu.item_max	= lines_instr(fbuff);
	yn = menu.item_max > LINES-9 ? LINES-4 : menu.item_max+5; 
	menu.scr_max	= yn-5;
	
	y = LINES/2 - yn/2;	x = COLS/2  - xn/2 -1;
	aca_border(y, y+yn, x, x+xn, TplC->dlg_bgr);  
	CLEAN_BOX (y+1, y+yn-1, x+1, x+xn-1);  
	bold;  aca_c(TplC->dlg_header); 
	mvaddstr( Y(0), X(xn/2 - strlen(header)/2), header);  
	ubold;
	w[0].y = Y(2);	w[1].y = Y(yn-1); 		
	w[0].x = X(2);	w[1].x = X(xn-12);
	w[0].lines = menu.scr_max;
	w[0].cols  = xn-4;
	menu.flag = M_COLORIN | M_OPEN | M_BORDER;
	if (infoline) menu.flag |= M_TITLE | M_TITLE_NSEL; 
	
	W_redraw_session(&s);
	do {
		if (run_act_widget(&s) & Wr_BUTTON_PRESS) 
			break;
		W_key_to_widgets(&s);		
		W_default_go(&s);
		aca_c(TplC->dlg_bgr);
	 	CLEAN_HLINE(Y(yn-1), X(1), X(xn-13)); 
	 	mvprintw(Y(yn-1), X(2), _("%3d of %d"), menu.item_act+1, menu.item_max+1);
	} while((s.key = get_k()) != KEY_F(10)); 
	
	aca_unloadfile(fbuff, flag);
	close(fd);	
}

/* ------------- keys learning ------------- */

typedef struct {
	int	key;
	char	*name;
	int	flag;
} learn_keys;

static int setkey_ok(int key, learn_keys *p)
{
	learn_keys	*x;
	         
	for(x=p; x->key != 0; x++) {
		if (x->key == key) {
			x->flag = TRUE;
			return TRUE;
		}	
	}
	return FALSE;
}

static void mpr_learn (Wmenu *m, Widget *w, int i, int l) 
{
         learn_keys	*p;         
         p = (learn_keys *) m->list;
         set_color_menu_in(m, l);
         CLEAN_HLINE(l+w->y, w->x, w->x + w->cols +3); 
         mvaddstr (l+w->y, w->x, p[i].name);	
         if (p[i].flag)	mvaddstr (l+w->y, w->x+w->cols+1, "OK");	
}

static void bgr_learnkey(SessW *s)
{
	int		y=LINES/2-8, x=COLS/2-30, 
			yn=16, xn=59;
	 
	aca_border (y, y+yn, x, x+xn, TplC->dlg_bgr);
	CLEAN_BOX (y+1, y+yn-1, x+1, x+xn-1);  

	center_addnstr(Y(1), COLS/2, 

_("Press all the keys mentioned here. After you have\ndone it, check which keys are not marked with OK. Press\n<ENTER> (or mouse) on the missing key to define it.\nMove around with Tab, ^n, ^p or mouse.\n--> experimental routine <--"), xn-4);

	bold;  aca_c(TplC->dlg_header); 
	mvaddstr( Y(0), X(xn/2-strlen(_(" Learn keys "))/2), _(" Learn keys "));  
	ubold;	
}

void Dlg_LearnKey()
{
	int		y=LINES/2-8, x=COLS/2-30, 
			yn=16, xn=59, re, istermcap;
	char		buff[256];
	learn_keys 	*p_keys;
	learn_keys keys1[] = {			
			{ KEY_F(1), _("Function key 1") },
			{ KEY_F(2), _("Function key 2") },
			{ KEY_F(3), _("Function key 3") },
			{ KEY_F(4), _("Function key 4") },
			{ KEY_F(5), _("Function key 5") },
			{ KEY_F(6), _("Function key 6") },
			{ KEY_F(7), _("Function key 7") },
			{ 0, 0 			        } 
		   }, keys2[] = {	
			{ KEY_F(8),     _("Function key 8")  },
			{ KEY_F(9),     _("Function key 9")  },
			{ KEY_F(10),    _("Function key 10") },
			{ KEY_BACKSPACE,_("Backspace key")   },
			{ KEY_END,      _("End key")         },
			{ KEY_UP,       _("Up arrow key")    },
			{ KEY_DOWN,     _("Down arrow key")  },
			{ 0, 0                               }
		   }, keys3[] = {
			{ KEY_LEFT,   _("Left arrow key")    },
			{ KEY_RIGHT,  _("Right arrow key")   },
			{ KEY_HOME,   _("Home key")          },
			{ KEY_NPAGE,  _("Page Down key")     },
			{ KEY_PPAGE,  _("Page Up key")       },
			{ KEY_IC,     _("Insert key")        },
			{ KEY_DC,     _("Delete key")        },
			{ 0, 0                              }};
	Wmenu   menu[] = {{
			chN, 0, M_OPEN | M_NOTOUT | M_COLORIN, 
			6,0,0,6,0,0,0,0,0,0, alistN, (void *) keys1, mpr_learn
		},{
			chN, 0, M_OPEN | M_NOTOUT | M_COLORIN, 
			6,0,0,6,0,0,0,0,0,0, alistN, (void *) keys2, mpr_learn 
		},{
			chN, 0, M_OPEN | M_NOTOUT | M_COLORIN, 
			6,0,0,6,0,0,0,0,0,0, alistN, (void *) keys3, mpr_learn
		}}; 	
	Widget	w[] = {
		{ FALSE, 0,0,0,15, menu_fn,  (void *) &menu[0],  Wf_NOTUSE_ASTR },
		{ FALSE, 0,0,0,15, menu_fn,  (void *) &menu[1],  Wf_NOTUSE_ASTR },
		{ FALSE, 0,0,0,15, menu_fn,  (void *) &menu[2],  Wf_NOTUSE_ASTR },
		{ TRUE,  0,0,0,5,  button_fn,(void *) &def_button[_BUTT_OK],     Wf_DEFAULT },			
		{ TRUE,  0,0,0,9,  button_fn,(void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },			
		W_NULL
	};
	SessW	s = { 4, 0, TRUE, w, K_STAY, bgr_learnkey };	
	
	init_sessw(&s);
	
	/* menu locate */
	w[0].x =X(2);	w[1].x =X(21);	w[2].x =X(40); 
	w[0].y = w[1].y = w[2].y = Y(7);	
	/* button locate */
	w[3].y = Y(yn-4+3);	w[3].x = x + xn/4;
	w[4].y = Y(yn-4+3);	w[4].x = x + xn/2+xn/4-5; 
	
	if (aca.keypad) {
		aca_keypad(FALSE);
		load_seqences();
		istermcap = TRUE;
	} else
		istermcap = FALSE;
	init_lbuff();
	W_redraw_session(&s);
	GL_inlearn_mode = TRUE;
	do {
	     /* check key ..hmm this is very s... algorithm */
	     	if (isfunckey(s.key)) {
	     		if (!setkey_ok(s.key, keys1)) {
	     			if (!setkey_ok(s.key, keys2)) {
	     				if (setkey_ok(s.key, keys3))
	     					W_redraw_session(&s);
	     			} else
	     				W_redraw_session(&s);
	     		} else	
	     			W_redraw_session(&s);		
	     	}	
		re = run_act_widget(&s);
	     /*	Cancel */	    
		if((re & Wr_BUTTON_PRESS) && s.actual==4) {
			aca_keypad(istermcap);
			break;
		}	
	     /*	Ok */	    
		else if((re & Wr_BUTTON_PRESS) && s.actual==3) {
			cpy_lbuff();
			if (learn_keydump_check())
				INI_need_save(GL_term_name);
			break;				
		} else if ((re & Wr_MENU_PRESS) &&s.actual<=2) {
		
	#define	P_NAME	p_keys[menu[s.actual].item_act].name	
	#define	P_FLAG	p_keys[menu[s.actual].item_act].flag		
	#define	P_KEY	p_keys[menu[s.actual].item_act].key			

			p_keys = (learn_keys *) menu[s.actual].list;
			sprintf(buff, _("Please press the %s.\n\nThen, press it again (in 'Learn keys' menu) to\nsee if OK appears.\n"), P_NAME);			
			Dlg_Warning_org (_(" Teach me a key "), buff, 50, Warn_draw);
			learn_key(P_KEY); 
			W_redraw_session(&s);
		}
		
		W_key_to_widgets(&s);		
		W_default_go(&s);
		
		if (s.actual <= 2) {
			menu[0].item_act= menu[1].item_act= menu[2].item_act= menu[s.actual].item_act;
			menu[0].scr_act = menu[1].scr_act = menu[2].scr_act = menu[s.actual].scr_act;
		}	
		s.key = get_k();
	} while(1);  
	
	GL_inlearn_mode = FALSE;
	
}

/* ------------ DIR PART ------------ */

static char	curr_dir[BUFSIZ];

static int dlg_stat(char *dir, char *file)
{
        struct stat	st;
	char		filename[BUFSIZ];
	
	sprintf(filename, "%s%s", dir, file);
	if (stat((const char *) filename, &st) == -1)  
		return FALSE;
	return st.st_mode;
}

static int select_dir(struct dirent *d)
{
	if (d->d_name[0] == '.' && d->d_name[1] == '\0')
		return 0; 
	if ( d->d_name[ strlen(d->d_name) -1 ] == '~')
		return 0;	
	return d->d_ino;
}

static int dir_sort(struct dirent **a, struct dirent **b)
{
	int 	amode = dlg_stat(curr_dir, (*a)->d_name),
		bmode = dlg_stat(curr_dir, (*b)->d_name);
	
	if (S_ISDIR(amode) && S_ISDIR(bmode)) 
		return strcmp((*a)->d_name, (*b)->d_name);		
	else if (S_ISDIR(amode))
		return -1;
	else if (S_ISDIR(bmode))	
		return TRUE;
	else 
		return strcmp((*a)->d_name, (*b)->d_name);			
}	

static int fill_filelist(char *dirname, struct dirent ***namelist)
{
	int		num;	
	if ((num = scandir((const char *) dirname, namelist, select_dir, 
		       (int (*)(const void *, const void *)) dir_sort)) != -1) 
		--num; 
	return num;
}
		
static void mpr_dir (Wmenu *m, Widget *w, int i, int l) 
{
        struct dirent	**p;        
        char		*x;
        int		mode;
                  
        p = (struct dirent **) m->list;
        x = (*(p+i))->d_name;
        set_color_menu_in(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + 25); 
        
	if (!(mode=dlg_stat(curr_dir, x)))
		mvprintw (l+w->y, w->x, "!%.25s", x);
	else if (S_ISDIR(mode))
		mvprintw (l+w->y, w->x, "/%.25s", x);	
	else
		mvprintw (l+w->y, w->x, " %.25s", x);	
}

static void bgr_selectfile(SessW *s)
{
	int		y=LINES/2-8, x=COLS/2-20, 
			yn=15, xn=41;
	aca_c(TplC->dlg_bgr);
	CLEAN_BOX (y+1, y+yn-1, x+1, x+xn-1);
}

int set_dir_poz(char *str, struct dirent **p, int max)
{
	int	i;
	for(i=0; i<=max; i++) {
		if (!strcmp(str, (*(p+i))->d_name))
			return --i;
	}
	return FALSE;
}

char *Dlg_SelectFile(char *dirname, char *header, char *exten)
{
	struct dirent	**namelist;
	int		y=LINES/2-8, x=COLS/2-20, 
			yn=15, xn=43,
			re, mode;
	char		*loc, *loc2, last_d[128],  file[128];		
	Wmenu   menu = {
		chN, 0, M_COLORIN | M_OPEN | M_NOTOUT | M_BORDER | M_TITLE | M_STILLV,
		6,0,0,6,0,0,0,0,0,0, alistN, (void *) namelist, mpr_dir
	};
	Winput	input = { N_("|F|ile: "), 0, file, 0, 0, 0, 30 };
	Widget	w[] = {
		{ '/',  Y(2), X(2), 10,25, menu_fn,   (void *) &menu,  Wf_DEFAULT },
		{ TRUE, Y(14),X(2), 0, 36, input_fn,  (void *) &input, Wf_DEFAULT | Wf_TYPE_INPUT },
		{ TRUE, Y(3), X(31),0,  5, button_fn, (void *) &def_button[_BUTT_OK],    Wf_DEFAULT },
		{ TRUE, Y(5), X(31),0,  9, button_fn, (void *) &def_button[_BUTT_CANCEL],Wf_DEFAULT },
		W_NULL
	};
	SessW	s = { 3, 0, TRUE, w, K_STAY, bgr_selectfile, 0 };	
	
	init_sessw(&s);
	
	strncpy(curr_dir, dirname, BUFSIZ); 
	if ((menu.item_max = fill_filelist(curr_dir, &namelist)) == -1) {
		ErrorOpen(curr_dir);	
		return chN;
	}
	menu.list	= (void *) namelist;
	menu.scr_max	= 10;
		
	aca_border(y, y+yn, x, x+xn, TplC->dlg_bgr);  
	CLEAN_BOX (y+1, y+yn-1, x+1, x+xn-1);  
	bold;  aca_c(TplC->dlg_header); 
	mvaddstr( Y(0), X(xn/2 - strlen(header)/2), header);  
	ubold;
	menu.astr  = strlen(curr_dir) < 25 ? curr_dir : curr_dir + (strlen(curr_dir)-25);
	*file = '\0';
	W_redraw_session(&s);
	
	do {
		re = 0;
		re = run_act_widget(&s);
	        
	        W_key_to_widgets(&s);		
		W_default_go(&s);

		if (exten && s.actual !=1 && file[0]) {
			if (!strstr(file, exten)) {
				strcat(file, exten);
	        		input.a_size = input.poz = strlen(file);
	        		W_redraw_session(&s);
	        	}
	        }			     	
	     /* OK */   	
		if ((re & Wr_BUTTON_PRESS) && s.actual == 2) {
			strncpy(dirname, curr_dir, BUFSIZ);
			sprintf(curr_dir, "%s%s", curr_dir, file);
			return strdup(curr_dir);
		}
	     /* Cancel */   	
		else if ((re & Wr_BUTTON_PRESS) && s.actual == 3) { 
			if (curr_dir) strncpy(dirname, curr_dir, BUFSIZ);
			return chN;		
	     /* press menu */	
		} else if (re & Wr_MENU_PRESS) {
			*last_d = '\0';	
			loc = (*(namelist + menu.item_act))->d_name;
			if ((strcmp(curr_dir, "/") || strcmp(loc, "..")) &&
			   ((strlen(curr_dir) + strlen(loc)) < BUFSIZ )  &&
			    (mode=dlg_stat(curr_dir, loc))) {
				if (S_ISDIR(mode)) {
					if ((loc2 = strrchr(curr_dir, '/')))
						 	*loc2 = '\0';
					if (!strcmp(loc, "..")) {
						if ((loc2 = strrchr(curr_dir, '/'))) {
							strncpy(last_d, (++loc2), 128);
							*loc2 = '\0';
						}
					} else 
						sprintf(curr_dir, "%s/%s/", curr_dir, loc);
					if ((menu.item_max = fill_filelist(curr_dir, &namelist)) == -1) 
						ErrorOpen(curr_dir);
					if (*last_d) 
						menu_dummy_go(w, &menu, KEY_DOWN, 
							set_dir_poz(last_d, namelist, menu.item_max));
					else 		
						ACA_RESET_MENU((&menu));
					menu.list  = (void *) namelist;
					menu.astr  = strlen(curr_dir) < 25 ? curr_dir : 
						curr_dir + (strlen(curr_dir)-25);
				} else if (S_ISREG(mode)) {
					strncpy(file, loc, 128);
					if (exten)
						if (!strstr(file, exten)) 
							strcat(file, exten);
					input.a_size = input.poz = strlen(file);
					set_widget(w, &s, 1);
				}	
			}
			W_redraw_session(&s);
		}
	} while((s.key = get_k()) != KEY_F(10)); 
	return chN;
}
