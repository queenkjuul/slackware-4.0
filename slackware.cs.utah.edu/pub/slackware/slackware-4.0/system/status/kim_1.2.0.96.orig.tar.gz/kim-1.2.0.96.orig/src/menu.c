
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "kim.h"
#include "procdata.h" 
#include "proccols.h" 
#include "procsort.h"
#include "util.h"
#include "fill_list.h"
#include "kimwins.h"
#include "layout.h"
#include "profile.h"

#define F_ASCII		1
#define F_HTML		2
#define F_SAVE		3	

char *comm_astr[] = {	
	N_(	"|S|ort                   ^xk"	),
	N_(	"|U|ser filter            ^xw"	),
	N_(	"S|a|ve proc              ^xo"	),
	N_(	"Load proc from |f|ile    ^xf"	),
	N_(	"Loa|d| proc from proc    ^xj"	),
	N_(	"|E|xport to ASCII        ^xa"	) 
};
char *option_astr[] = {	
	N_(	"Profile |e|ditor"	),
	N_(	"|D|elete profile"	),
	N_(	"Learn |k|ey" 		),
	N_(	"Dele|t|e learned key"	),
	N_(	"Con|f|igure"		)
};

void mpr_left(Wmenu *m, Widget *w, int i, int l) 
{
        set_color_menu_out(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	if (i != 0) 
		mvaddstr (l+w->y, w->x+1, kc[ conf_P.act_profile.cols[i] ].name );	
	else	
		mvprintw (l+w->y, w->x,   "*%s", kc[ conf_P.act_profile.cols[i] ].name );		
}

void mpr_comm(Wmenu *m, Widget *w, int i, int l) 
{
        set_color_menu_out(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	mvaddastr_menu(m, l+w->y, w->x+1, l, i); 
	if (l==1) { 
		aca_c(TplC->menu_out.nsel);
		CLEAN_HLINE(l+w->y+1, w->x, w->x + w->cols); 
		mvhline(l+w->y+1, w->x+1, ACA_HLINE, w->cols-1);
	}	
}

void mpr_opt(Wmenu *m, Widget *w, int i, int l) 
{
        set_color_menu_out(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	mvaddastr_menu(m, l+w->y, w->x+1, l, i); 
}

void mpr_profile(Wmenu *m, Widget *w, int i, int l) 
{
        set_color_menu_out(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	if (i != conf_P.current) 
		mvprintw (l+w->y, w->x+1, (conf_P.p_default == i ? "<%s>" : " %s"),   
			conf_P.name[i] );	
	else	
		mvprintw (l+w->y, w->x, (conf_P.p_default == i ? "*<%s>" : "* %s"),  
			conf_P.name[i] );		
}

void mpr_view(Wmenu *m, Widget *w, int i, int l) 
{
        set_color_menu_out(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	
	strftime(ks.tmp, 20, "%H:%M %b-%d-%y", localtime((time_t *) &GL_kdata[i]->time_now));	
	if (i == GL_kdata_curr) 
		mvprintw (l+w->y, w->x, "*%.9s %s", GL_kdata[i]->uname.nodename, ks.tmp);	
	else	
		mvprintw (l+w->y, w->x+1, "%.9s %s", GL_kdata[i]->uname.nodename, ks.tmp);	
}

static void menu_to_file(kim_DATA *d, int flag)
{
	char		*file;
	
	if (flag == F_ASCII) {
		if ((file = Dlg_SelectFile(ks.current_dir, 
				_(" Export to ASCII file: "), NULL))) {
			_D("ASCII"); 
			export_to_ascii(file, d); 
		}
	} else if (flag == F_SAVE) {
		_D( "SAVE");
		if ((file = Dlg_SelectFile(ks.current_dir, _(" Save: "), ".kim"))) 
			save_proc_to_file(file, d);
	}				
}

static int add_new_proc(int flag)
{
	kim_DATA	*k;
	char		*file;	
	
	_D(" add_new_proc()"); 
	
	if (flag) {
		k = kimdata_malloc();
		if (proc_from_proc(k) == RE_ERROR) {
      			Error(_("Can't load processes data from proc !"));
      			return FALSE;
      		}
      		set_report_buff(_("Loaded next proc"));
	} else {
		if (!(file = Dlg_SelectFile(ks.current_dir, _(" Load proc from file: "), NULL))) 
			return FALSE;
		k = kimdata_malloc();		
		k->file = file;	
		if (proc_from_file(k) == RE_ERROR) 
      			return FALSE;
      		set_report_buff(_("Loaded next proc"));	
	}
	prepare_view(conf_L.view, conf_L.sort, k); 	
	if (!(k = add_kdata(k)))
		return FALSE;
	set_L_d(k);
	return TRUE;
}


int menu_user(kim_DATA *d)
{
	if (d->sort_mode == SORT_TREE) {
		Warning(_("In tree mode is User filter disabled !"));
		return FALSE;
	}
	return wins_user(d); 		 
}

int menu_action(Wmenu *m, kim_DATA *d, int id)
{
	int	i;
	
	_D( " menu_action() ");

	switch(id) {
	case 12:
		_D("FIRST");
		if (m->item_act == 0) break;
		i = conf_P.act_profile.cols[0];
		conf_P.act_profile.cols[0] = conf_P.act_profile.cols[m->item_act]; 
		conf_P.act_profile.cols[m->item_act] = i;
		return TRUE;
	case 13:
		_D("COMMAND");
		switch(m->item_act) {
			case 0: if (wins_sort(d)) {
					prepare_view(d->view_mode, d->sort_mode, d);   
					return TRUE;
				}
				return FALSE;	
			case 1: return menu_user(d);  
			case 2: menu_to_file(d, F_SAVE);  break; 
			case 3: return add_new_proc(FALSE);
			case 4: return add_new_proc(TRUE);
			case 5: menu_to_file(d, F_ASCII); break;
		}
		break;
	case 14:
		_D("PROFILE");
		if (m->item_act == conf_P.current) break;
		set_current_profile(m->item_act);
		break;
	case 15:
		_D("OPTION");
		switch(m->item_act) {
			case 0: return wins_profedit(d);
			case 1: return wins_profdel(d);
			case 2: Dlg_LearnKey(); break;
			case 3: 
				if (!aca.keypad) {
					sprintf(ks.tmp, _("Do you want to delete learned keys for\nTERM '%s' ?"), GL_term_name);
					if (Dlg_YesNo( _(" UnLearn Me "), ks.tmp, 50 )) {
						INI_del_section(&kimINI, GL_term_name);
						aca_keypad(TRUE);
						INI_set_flag(_S_TERM, FALSE);
					}
				} else
					Warning(_("For current TERMinal is not learned keys."));
				break;
			case 4: return wins_config();
		}
		break;
	case 16:
		_D("VIEW");
		if (!(d = set_current_kdata(m->item_act)))
			return FALSE;
		prepare_view(d->view_mode, d->sort_mode, d); 		
		set_L_d(d);
		return TRUE;
	}
	return FALSE;
}

/* 
	Menu action after CTRL + 'x' + key 
*/
int fast_action(int key, kim_DATA *d)
{

	_D("fast_action()");

	if (XCTRL('k') == key ) {
		if (wins_sort(d)) {
			prepare_view(d->view_mode, d->sort_mode, d);   
			return TRUE;
		}
		return FALSE;
	}		
	else if (XCTRL('w') == key )  return menu_user(d); 
	else if (XCTRL('o') == key )  menu_to_file(d, F_SAVE);  
	else if (XCTRL('f') == key )  return add_new_proc(FALSE);
	else if (XCTRL('j') == key )  return add_new_proc(TRUE);
	else if (XCTRL('a') == key )  menu_to_file(d, F_ASCII); 
	
	return FALSE;
}
