
#ifndef	__ACA_DLG_H
#define __ACA_DLG_H

extern int	Dlg_YesNo (char *header, char *query, int xn);

/* low-level warninig window */
extern int	Dlg_Warning_org (char *header, char *query, int xn, int action);

/* actions: */
#define Warn_std	0	/* draw message and wait for your key */
#define	Warn_draw	1 	/* draw only (not ----- // --------) */


extern void	Dlg_FileViewer(char *filename, char *header, char *infoline, int xn);
extern void	Dlg_LearnKey();

#define Dlg_Warning(h, q, n)	\
		Dlg_Warning_org (h, q, n, Warn_std)

#define Error(str) \
		Dlg_Warning_org (_(" Error "), str, (COLS < 50 ? COLS-2 : 50), Warn_std)

#define Warning(str) \
		Dlg_Warning_org (_(" Warning "), str, (COLS < 50 ? COLS-2 : 50), Warn_std)

#define ErrorOpen(str) \
		Dlg_Warning_org (_(" Open error "), str, (COLS < 50 ? COLS-2 : 50), Warn_std)

/* Return file name */ 				
extern char	*Dlg_SelectFile(char *dirname, char *header, char *exten);
					           /* is extension ^^^^^ */
	/* >>>	dirname must be >= BUFSIZ
		Dlg_Se.. copy to dirname last selected dir
	*/	

#endif	/* __ACA_DLG_H */
