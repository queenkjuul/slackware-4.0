
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <string.h>
#include <stdlib.h>

#include "kim.h"
#include "procdata.h" 
#include "proccols.h" 
#include "procsort.h"
#include "util.h"
#include "fill_list.h"
#include "layout.h"
#include "profile.h"

#define set_list_color(m, l, d) {                                       \
	if (m->scr_act == l) {                                          \
      		if (d->cpd->mark) {			 		\
			aca_c(YELLOW_CYAN);                             \
			bold;                                           \
		} else {                                                \
			if (conf_L.color_zombie && 			\
					d->cpt->state == 'Z') {         \
			        bold;                                   \
				aca_c(ZOMBIE_RED_CYAN);                 \
			} else if (conf_L.color_run &&	 		\
				d->cpt->state == 'R') {              	\
			        bold;                                   \
				aca_c(RUN_GREEN_CYAN);                  \
			} else {                                        \
			        ubold;                                  \
				aca_c(BLACK_CYAN);                      \
			}                                               \
		}	                                                \
	} else if (d->cpd->mark) {                        		\
		aca_c(YELLOW_BLUE);                                     \
		bold;		                                        \
	} else {                                                        \
		if (conf_L.color_zombie && 				\
			d->cpt->state == 'Z') {                         \
		        bold;                                           \
			aca_c(RED_BLUE); 	                        \
		} else if (conf_L.color_run && 				\
			d->cpt->state == 'R') {		      	        \
		        bold;	                	         	\
			aca_c(GREEN_BLUE);	                        \
		} else {	                                        \
			ubold;                                          \
			aca_c(WHITE_BLUE);                               \
		}                                                       \
	}	                                                        \
}

#define set_line_color(m, l) {                                          \
	if (m->scr_act == l) {                                          \
	        ubold;                                  		\
		aca_c(BLACK_CYAN);                	        	\
	} else {	                	                        \
		ubold;                                          	\
		aca_c(WHITE_BLUE);	                                \
	}                        	                                \
}

#define set_tree_color(m, l) {                                          \
	bold;								\
	if (m->scr_act == l) {                                          \
		aca_c(BLACK_CYAN);                	        	\
	} else {	                	                        \
		aca_c(GREEN_BLUE);	                                \
	}                        	                                \
}

void print_tree(int line, int cols, kim_DATA *d)
{
      int i;
      cols-=2;
   
      for(i=1; i<=d->cpd->tree_cols; i++) 
         if(show_bit(d->cpd->tree_flag, i) == 1) {
            if (i*2 <= d->tree_width)
            	mvaddch(line, cols+i*2, ACA_VLINE);
            else	
            	mvaddch(line, d->tree_width, ACA_VLINE);
         }   
      i = d->cpd->tree_cols*2 > d->tree_width ? d->tree_width : d->cpd->tree_cols*2;
      if (d->cpd->tree_end == TREE_END)
         mvaddch(line, i, ACA_LLCORNER);
      else 
         if (i != 0)
            mvaddch(line, cols+i, ACA_LTEE);
}


void make_data_line(char *line_buff, kim_DATA *d, 
			ACT_PROFILE *p, int sht, int header)
{
	kim_COLS	*p_kc;
	int		i, *cp, count=0, cw, cut=0, cuted=0, first;
	char		format[10], buff[TMP_SIZE], *b;

	_D( " make_data_line() ");
	
	first = *(d->cols_width + *p->cols) + 3;
	if (d->sort_mode == SORT_TREE) first = d->tree_width;
	
	for(cp=p->cols+1, i=1; i<=p->col_num; i++, cp++) {
		p_kc	= kc + *cp;
		if (i<p->col_num)	cw = *(d->cols_width + *cp);
		else			cw = COLS-3-count-first+sht; 
		count += cw;
		if (count+2 > TMP_SIZE) break;
		if (!cuted && sht) {
			if (count > sht) {
				cut = cw - (count-sht);
				cw -= cut;
				memset(buff, ' ', TMP_SIZE*sizeof(char)); 
			} else
				continue;
		}		
		sprintf(format, "%%.%ds", cw); 
		if (header)	strncpy(buff, p_kc->name, TMP_SIZE);
		else		p_kc->maker(buff, d);	
		b = buff;
		if (!cuted && sht) { b += cut; cuted=1; }
		sprintf(line_buff, format, b);
		*(line_buff + strlen(line_buff)) = ' ';
 		line_buff += (cw + 1);
 		count += 1;
 		if (count > COLS-3-first+sht) break;
	}
	*(line_buff) = '\0';
}

void mpr_list_area(Wmenu *m, Widget *w, int i, int l) 
{
	kim_DATA	*d;
	int		first;
	
	_D( " mpr_list_area() ");   
	
	d = (kim_DATA *) m->list;
	d->cpt	= *(d->pt + *(d->sort + i));
	d->cpd	= d->pd + *(d->sort + i);
	first	= *(d->cols_width + *conf_P.act_profile.cols)+3;
	
	if (d->sort_mode == SORT_TREE) first = d->tree_width;
	
	if (aca.color) {
		if (m->scr_act==l) {
			aca_c(WHITE_CYAN); 
			mvaddch(l + w->y, w->x,   ACA_RARROW);
			mvaddch(l + w->y, COLS-2, ACA_LARROW);
		} else {
			aca_c(WHITE_BLUE);
			mvaddch(l + w->y, w->x, ' ');
			mvaddch(l + w->y, COLS-2, ' ');
		}
	}
	
	set_list_color(m, l, d);
	if (aca.color) { CLEAN_HLINE(l+ w->y, w->x+1, w->x + w->cols-1);}
	else	       { CLEAN_HLINE(l+ w->y, w->x, w->x + w->cols); 	}
	memset(ks.out_buff, ' ', TMP_SIZE * sizeof(char));
	
	make_data_line(ks.out_buff, d, &conf_P.act_profile, m->sht_act, FALSE);
	*(ks.out_buff + (COLS-3-first)) = '\0';
	
	/* data cols */
	mvaddstr(l + w->y, w->x+first, ks.out_buff);
	(kc + (*conf_P.act_profile.cols))->maker(ks.out_buff, d);
	*(ks.out_buff + (w->x+first-2)) = '\0';
	
	/* first cols */
	if (d->sort_mode == SORT_TREE) 
		mvaddstr(l+w->y, w->x+ 
			(d->cpd->tree_cols*2 > d->tree_width ? d->tree_width : d->cpd->tree_cols*2),   
			ks.out_buff);
	else	
		mvaddstr(l+w->y, w->x+1, ks.out_buff);
	
	if (d->sort_mode == SORT_TREE) {
		set_tree_color(m, l);
		print_tree(l+w->y, w->x+1, d);
	}
	set_line_color(m, l);
	mvaddch(l + w->y, w->x+first-1, ACA_VLINE);	
	
	aca_c(WHITE_BLUE);
	if (l==1){
		bold; 
		CLEAN_HLINE(l + w->y - 1, w->x, w->x + w->cols);
		memset(ks.out_buff, ' ', TMP_SIZE * sizeof(char)); 
		make_data_line(ks.out_buff, d, &conf_P.act_profile, m->sht_act, TRUE);
		*(ks.out_buff +(COLS-3-first)) = '\0';
		mvaddstr(l + w->y-1, w->x+first, ks.out_buff);
		mvaddstr(l + w->y-1, w->x+1, (kc + (*conf_P.act_profile.cols))->name);
		ubold;
		mvaddch(l + w->y-1, w->x+first-1, 	ACA_VLINE);	
		if ((d->view_mode == VIEW_YOUR) && (d->view_num+1 < LINES - 6)) { 
			mvhline(w->lines+w->y+1, 1, ACA_HLINE, COLS-2);
			mvaddch(w->lines+w->y+1, 0, ACA_LTEE); 
			mvaddch(w->lines+w->y+1, COLS-1, ACA_RTEE); 
		}
	}
}

int count_prof_width(kim_DATA *d)
{
	int	i, count=0;
	
	_D( " count_prof_width() ");
	
	for(i=1; i<=conf_P.act_profile.col_num; i++) 
		count += *(d->cols_width + *(conf_P.act_profile.cols+i));
	return count;			
}
