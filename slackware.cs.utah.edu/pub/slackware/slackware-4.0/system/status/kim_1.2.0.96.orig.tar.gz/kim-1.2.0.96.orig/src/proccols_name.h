
/* --> Kim column (fields) <--
  
  Note >>>   if you change this file see (and change) files 
  		proccols.c/h, colsenum.h !!!
 
  --> #include this file after kim.h
 
 +-------------------------------------------------------------------------------------+
 |         -name- -max.width- -data func.-   	-sort func.-	-cols description-     |        
 +-------------------------------------------------------------------------------------+           
 */
			       
/* 0*/  {  "NAME",       15,	cols_name       , sort_data, 	N_("basename of executable file in call to exec(2)")	},
/* 1*/  {  "STAT",	 12,	cols_state      , sort_data, 	N_("process state (S=sleeping,Z=zombie,R=running,D,T)")	},
/* 2*/  {  "TTY",        12,	cols_tty        , sort_data, 	N_("name of controlling tty device")			},
/* 3*/  {  "CMDLINE",    35,	cols_cmdline    , sort_data, 	N_("process command line")				},
/* 4*/  {  "PID",        12,	cols_pid        , sort_pid , 	N_("process id")					},
/* 5*/  {  "PPID",       12,	cols_ppid       , sort_ppid, 	N_("parent PID")					},
/* 6*/  {  "PGRP",	 12,	cols_pgrd       , sort_pgrd, 	N_("process group id")					},
/* 7*/  {  "SESSION",    12,	cols_session    , sort_session, N_("session id")					},
/* 8*/  {  "DEVNUM",     12,	cols_ttynum     , sort_ttynum,	N_("full device number of controlling terminal")	},
/* 9*/  {  "TPGID",      12,	cols_tpgid      , sort_tpgid, 	N_("terminal process group id")				},			
/*10*/  {  "START",	 12,	cols_start      , sort_start, 	N_("start time of process")				},
/*11*/  {  "ETIME",      12,	cols_etime      , sort_etime,	N_("elapsed time from start to current time")           },
/*12*/  {  "UID",        12,	cols_uid        , sort_uid, 	N_("user effective ids")				},
/*13*/  {  "USER",	 15,	cols_user       , sort_data, 	N_("user name corresponding to effective uid") 		},
/*14*/  {  "%MEM",       12,	cols_pmem       , sort_rss, 	N_("%MEM usage of total system memory")			},
/*15*/  {  "SIZE",	 12,	cols_size    	, sort_size, 	N_("kB total of memory")				},
/*16*/  {  "RSS",	 12,	cols_rss        , sort_rss, 	N_("kB/pages memory resident set size")			},
/*17*/  {  "RSS_RLIM",   12,	cols_rss_rlim   , sort_rss_rlim,N_("current limit in bytes on the RSS of the process")	},
/*18*/  {  "RESIDENT",	 12,	cols_resident	, sort_resident,N_("kB/pages non-swapped menory size")			},
/*19*/  {  "SHARE",	 12,	cols_share   	, sort_share, 	N_("kB/pages number of shared (mmap'd) memory")		},
/*20*/  {  "DT",     	 12,	cols_dt	        , sort_dt, 	N_("kB/pages dirty memory")				},
/*21*/  {  "TRS", 	 12,	cols_trs        , sort_trs, 	N_("kB/pages text resident memory")	        	},
/*22*/  {  "LRS", 	 12,	cols_lrs        , sort_lrs, 	N_("kB/pages shared-lib (not usable for ELF)")		},
/*23*/  {  "DRS", 	 12,	cols_drs        , sort_drs, 	N_("kB/pages data resident memory")			},
/*24*/  {  "SWAP",       12,	cols_swap       , sort_swap, 	N_("kB/pages on swap device")                           },
/*25*/  {  "MINFLT",     12,	cols_minflt     , sort_data, 	N_("number of minor page faults since process start")	},
/*26*/  {  "MAJFLT",     12,	cols_majflt     , sort_data, 	N_("number of major page faults since process start")	},
/*27*/  {  "CMINFLT",    12,	cols_cminflt    , sort_data, 	N_("cumulative MIN_FLT of process and child process")	},
/*28*/  {  "CMAJFLT",    12,	cols_cmanflt    , sort_data, 	N_("cumulative MAX_FLT of process and child process")	},
/*29*/  {  "%CPU",       12,	cols_pcpu       , sort_pcpu, 	N_("%CPU usage")					},
/*30*/  {  "PRIORITY",   12,	cols_priority   , sort_priority,N_("kernel scheduling priority")			},
/*31*/  {  "NICE",	 12,	cols_nice       , sort_nice, 	N_("standard unix nice level of process")		},
/*32*/  {  "TIMEOUT",    12,	cols_timeout    , sort_timeout,    " ??? "						},
/*33*/  {  "TIME",       12,	cols_time       , sort_time, 	N_("UTIME+STIME - compatible with TIME in ps(1)")	},
/*34*/  {  "CTIME",      12,	cols_ctime      , sort_ctime, 	N_("cumulative TIME")       				},
/*35*/  {  "FLAGS",	 12,	cols_flags      , sort_data, 	N_("kernel flags for the process")			},
/*36*/  {  "START_CODE", 12,	cols_start_code , sort_data, 	N_("the address above which program text can run")	},
/*37*/  {  "END_CODE",   12,	cols_end_code   , sort_data, 	N_("the address below which program text can run")	},
/*38*/  {  "START_STACK",20,	cols_start_stack, sort_data, 	N_("the address of the start of the stack")		},
/*39*/  {  "KSTK_ESP",   20,	cols_kstk_esp   , sort_data, 	N_("the current ESP (32-bit stack pointer)")		},
/*40*/  {  "KSTK_EIP",   20,	cols_kstk_eip   , sort_data, 	N_("the current EIP (32-bit instruction pointer)")	},
/*41*/  {  "WCHAN",	 20,	cols_wchan      , sort_data, 	N_("kernel function where the process waiting") },
/*42*/  {  "SIGNAL",     20,	cols_signal     , sort_data, 	N_("mask of pending signals")				},
/*43*/  {  "BLOCKED",    20,	cols_blocked    , sort_data, 	N_("mask of blocked signal")				},
/*44*/  {  "IGNORED",    20,	cols_sigignore  , sort_data, 	N_("mask of ignored signal")				},
/*45*/  {  "CATCHED",    20,	cols_sigcatch   , sort_data, 	N_("mask of caugth signal")				},
/*46*/  {  "ALARM",      20,	cols_alarm      , sort_alarm, 	N_("the time before the next SIGALARM")                 },
                                      
/*last*/
	{  chN,		  0,	NULL		, NULL	   ,	 chN	                                        }




