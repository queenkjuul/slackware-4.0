
#ifndef __KIMWINS_H
#define __KIMWINS_H

/* --- signals --- */ 

typedef struct {
	int	signum;		/* signal number */
	char	*signame,	/* signal name	 */
		*descript;	/* signal description */
} kim_SIGNALS;

extern int	wins_sort( kim_DATA *d ); 
extern int	wins_signals( kim_DATA *d );
extern int	wins_user( kim_DATA *d ); 
extern void	wins_more( kim_DATA *d );
extern int	wins_profedit(kim_DATA *d);
extern int	wins_profdel(kim_DATA *d);
extern int	wins_config();

#endif /* __KIMWINS_H */