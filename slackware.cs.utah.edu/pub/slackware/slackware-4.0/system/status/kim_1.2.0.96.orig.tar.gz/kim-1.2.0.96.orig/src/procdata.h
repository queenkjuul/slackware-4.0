
#ifndef __DATA_H
#define __DATA_H

#define P_MARKED	TRUE
#define P_UNMARKED	FALSE

#define P_VIEW		TRUE
#define P_NOTVIEW	FALSE

#include <proc/readproc.h>
#include <sys/utsname.h>


/* Libproc conversion */

#if PROCPS_1_2		
	#define	INDEP_UID	uid
	#define	INDEP_USER	user
#endif

#if PROCPS_2_0			
	#define	INDEP_UID	ruid		
	#define	INDEP_USER	ruser	
#endif			


/* only for cols counting */
#ifndef COLS_NUM
	typedef enum {
		#include "proccols_enum.h"
	} _cols_;	
	
	#define COLS_NUM	(_COLS_COUNTER-1)
#endif

typedef struct {
	int		view,
			mark,
			tree_cols,
			tree_end;
	unsigned int	tree_flag;
	char		*cmdline;	/* kim needn't cmdline in **array (as in libproc) */

#if PROCPS_2_0
	char		ttyc[8];
#endif

} p_tab;

typedef struct {
	int	view,
		uid;
	char	*name;
} u_tab;

#ifdef __USE_GNU
	#define	U_DOMAINNAME(_u)	((_u).domainname)	
#else
	#define	U_DOMAINNAME(_u)	((_u).__domainname)	
#endif

typedef struct {
	struct utsname	uname;		/* kernel / machine information */
	proc_t		**pt;		/* process table (from libproc) */	
	proc_t		*cpt;		/* pointer to current *pt */
	p_tab		*pd;		/* kim internal data about process */	
	p_tab		*cpd;		/* pointer to current *pd */
	u_tab		*ut;		/* table with users information */
	int		cols_width[COLS_NUM+1], /* cols width for current data */
			proc_num,	/* num of process */	
			user_num,	/* num of users */
			show_selected,	/* show / not show selected users (in User filter) */
			mark_num,	/* num of marked */
			*sort,		/* sorted process table */
			current_time,
			sort_cols,	/* what cols (in kc[] is sorted key 
					(if process list is sorted) */  	
			sort_mode,	/* current sort mode */
			view_mode,	/* -- // -- view */
			tree_width,	/* max tree widht */
			area_width,	/* max list area width (for actual profile) */
			view_num,	/* num of veiw process */
			uid,		/* UID of process loader
					    --> kim's user or 'file.kim' saver */
			flag;		    
	char		*file;		/* path to file with proc (if loaded from file) */ 
	long		time_now;
	unsigned	**sys_m;	/* system memory */
	char		*uptime_str;	/* uptime string */
} kim_DATA;

/* flag: */
#define FROM_FILE	1
#define FROM_PROC	2

extern kim_DATA	**GL_kdata;	 
extern int	GL_kdata_num;
extern int	GL_kdata_curr;

extern kim_DATA *add_kdata(kim_DATA *d); 
extern kim_DATA *kimdata_malloc();
extern kim_DATA *set_current_kdata(int new);
extern void	dump_proc(FILE *f, proc_t *p, p_tab *pd);
extern int	save_proc_to_file(char *filename, kim_DATA *d);
extern int	proc_from_file(kim_DATA *d);
extern void	unselect_all(kim_DATA *d);
extern char	*get_str_meminfo(char *str);
extern int	proc_from_proc(kim_DATA *d);
extern kim_DATA *free_kim_data(kim_DATA *d);


#define get_user_name(_d, i)		( (_d)->ut[i].name	)
#define get_user_uid(_d, i)		( (_d)->ut[i].uid	)
#define get_user_view(_d, i)		( (_d)->ut[i].view	)
#define set_user_view(_d, i, set)	( (_d)->ut[i].view = set)
#define get_user_num(_d)		( (_d)->user_num	)

#define get_mem_total(_d)	( (_d)->sys_m[meminfo_main][meminfo_total] )
#define get_mem_free(_d)	( (_d)->sys_m[meminfo_main][meminfo_free] )
#define get_mem_used(_d)	( (_d)->sys_m[meminfo_main][meminfo_used] )
#define get_mem_shared(_d)	( (_d)->sys_m[meminfo_main][meminfo_shared] )
#define get_mem_buff(_d)	( (_d)->sys_m[meminfo_main][meminfo_buffers] )
#define get_mem_cached(_d)	( (_d)->sys_m[meminfo_main][meminfo_cached] )
#define get_swap_total(_d)	( (_d)->sys_m[meminfo_swap][meminfo_total] )
#define get_swap_free(_d)	( (_d)->sys_m[meminfo_swap][meminfo_free] )
#define get_swap_used(_d)	( (_d)->sys_m[meminfo_swap][meminfo_used] )

extern int	export_to_ascii(char *filename, kim_DATA *d);
       
#endif /* __DATA_H */
