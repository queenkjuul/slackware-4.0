
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "kim.h"
#include "profile.h"
#include "util.h"

kim_PROFILES	conf_P;


int INI_loader_profiling(FILE *f, int flag)
{
	char	*opt;
   	int	i;

	_D(" INI_loader_profiling() ");

	if (flag == YES_SECTION) {
		for (i=0; i<=1; i++) {
   			ks.tmp[0] = '\0';
   			fgets(ks.tmp, TMP_SIZE, f);
   			if (!(opt=separe_str(ks.tmp, '='))) 
   				continue;
   			if (!strcmp(ks.tmp, "num"))
   				conf_P.num = atoi(opt);			
   			if (!strcmp(ks.tmp, "default"))
   				conf_P.p_default = conf_P.current = atoi(opt);				
		}
		if ((conf_P.name = (char **) calloc(conf_P.num+1, sizeof(char *))) == NULL) {
         		ERROR_ALLOC;
         		return RE_ERROR;
      		}  
		for (i=0; i<= conf_P.num; i++) {
			ks.tmp[0] = '\0';
   			fgets(ks.tmp, TMP_SIZE, f);
   			if (!(opt=separe_str(ks.tmp, '='))) 
   				continue;
   			if (!strcmp(ks.tmp, "profile_name"))
   				conf_P.name[i] = strdup(strrepchr(opt, '_', ' '));					
			_D ( conf_P.name[i] );
		}
	}
	return TRUE;
}

int INI_writer_profiling(FILE *f)
{
   	int	i;
   	
   	_D(" INI_writer_profiling() ");
   	
   	fprintf(f, "num=%d\n",		conf_P.num); 
   	fprintf(f, "default=%d\n",	conf_P.p_default);
	for (i=0; i<= conf_P.num; i++) {
		fprintf(f, "profile_name=%s\n",	strrepchr(conf_P.name[i], ' ', '_'));
		strrepchr(conf_P.name[i], '_', ' ');
	}	
   	return TRUE;
}

int set_default_profile(int current)
{
	_D(" set_default_profile() ");
	
	return set_current_profile(conf_P.p_default);	
}

int set_current_profile(int current)
{
	_D(" set_current_profile() ");
	
	if (!load_profile(conf_P.name[current], &conf_P.act_profile)) {
		Error(_("Can't load profile"));
		return FALSE;
	}
	conf_P.current = current;
	return TRUE;
}

int add_profile(char *name) 
{
	int		i;
	char		**tmp;

      	tmp = conf_P.name;
      	if ((conf_P.name = (char **) calloc(++conf_P.num+1, sizeof(char *))) == NULL) {
        	ERROR_ALLOC;
        	return RE_ERROR;
      	}
      	for(i=0; i<=conf_P.num-1; i++) 
         	conf_P.name[i] = tmp[i];
         	
      	cfree((void *) tmp);
      
      	if (name)
      		conf_P.name[conf_P.num] = strdup(name);
   	else
   		conf_P.name[conf_P.num] = strdup("--???--");
      	return conf_P.num;
}

int del_prof(int dn)
{
   	int	i;
   	char 	*loc;
   	
   	if (conf_P.num < 1) return FALSE;
   	
   	strcpy(ks.tmp, kimINI.ini_file);
      	loc = strrchr(ks.tmp, '/');
      	*loc = '\0';	     
      	sprintf(ks.tmp, "%s/%s", ks.tmp, strrepchr(conf_P.name[dn], ' ', '_'));	
   	unlink(ks.tmp);
   	--conf_P.num;    	 
   	for(i=dn; i<=conf_P.num; i++) 
	    	conf_P.name[i] = conf_P.name[i+1];
	    	
	if (dn == conf_P.current) 	set_current_profile(0);
	if (dn == conf_P.p_default) 	conf_P.p_default = 0;
	INI_set_flag(_S_PROFILING, TRUE);	    
	return TRUE;	
}
   

int load_profile(char *filename, ACT_PROFILE *act) {
      FILE 	*f;
      int	i, c;
      char	*loc;

      _D(" load_profile() ");
	
      strcpy(ks.tmp, kimINI.ini_file);
      loc = strrchr(ks.tmp, '/');
      *loc = '\0';	     
      sprintf(ks.tmp, "%s/%s", ks.tmp, strrepchr(filename, ' ', '_'));	
      strrepchr(filename, '_', ' ');
      
      _D(ks.tmp);
      
      if ((f=fopen(ks.tmp,"r")) == NULL) 
         return FALSE;
 
      for(i=0; i<=COLS_NUM; i++) {
         if (feof(f)) 
         	break;
         if (fscanf(f, "%d\n", &c) != 1) 
         	break;
         if (c<=COLS_NUM) act->cols[i] = c;
         else {
         	--i; continue;
         }	
         act->col_num = i;
      }
      fclose(f);
      _D( "   -> profile loaded ");
      return TRUE;	
   }

   int write_profile(char *filename, ACT_PROFILE *act) 
   {
      FILE 	*f;
      int 	i;
      char	*loc;
	
      _D(" write_profile() ");	
	
      strcpy(ks.tmp, kimINI.ini_file);
      loc = strrchr(ks.tmp, '/');
      *loc = '\0';	     
      sprintf(ks.tmp, "%s/%s", ks.tmp, strrepchr(filename, ' ', '_'));	
      strrepchr(filename, '_', ' ');
   
      if ((f=fopen(ks.tmp,"w")) == NULL) 
         return RE_ERROR;
         
      for(i=0; i<=act->col_num; i++) 
         fprintf(f, "%d\n", act->cols[i]); 

      fclose(f);
      return RE_OK;	
   }


   void rename_profile(int num, char *newname)
   {
      char	buff[256], *loc;
     
      _D(" rename_profile() ");
	
      strcpy(ks.tmp, kimINI.ini_file);
      loc = strrchr(ks.tmp, '/');
      *loc = '\0';	     
      sprintf(ks.tmp, "%s/%s", ks.tmp, strrepchr(newname, ' ', '_'));	
      strrepchr(newname, '_', ' ');
  
      strcpy(buff, kimINI.ini_file);
      loc = strrchr(buff, '/');
      *loc = '\0';	     
      sprintf(buff, "%s/%s", buff, strrepchr(conf_P.name[num], ' ', '_'));	
      strrepchr(conf_P.name[num], '_', ' ');
  
      rename(buff, ks.tmp);

      free( (void *) conf_P.name[num]);
      conf_P.name[num] = strdup(newname); 
      INI_set_flag(_S_PROFILING, TRUE);	    
   }

   ACT_PROFILE *cpy_actprof(ACT_PROFILE *dest, ACT_PROFILE *src)
   {
   	int	*sp, *dp;
   	
   	for(sp=src->cols,dp=dest->cols; sp <= src->cols+src->col_num; sp++,dp++)
   		*dp = *sp; 
   	dest->col_num = src->col_num;
   	
   	return dest;
   }
   