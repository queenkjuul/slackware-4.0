
#ifndef	__ACA_UTIL_H
#define	__ACA_UTIL_H


/* global value */
extern int	GL_winch_flag,
		GL_interrupt_flag;

extern void	end_aca();

#ifdef CAN_RESIZE
	extern void	init_winch();
#endif		

extern void	init_aca();
extern void	set_inout_bits (int output_7bit_only, int input_8bit);
extern void	cur_pre_exec();
extern void	cur_post_exec();

#ifdef CAN_RESIZE	
	extern void	screen_resizer();
#endif

extern FILE	*aca_fileopen(char *filename, char *mode, int errors);

#define READ_LOAD	1
#define MMAP_LOAD	2	

extern char	*aca_loadfile(int fd, int flag);
extern void	aca_unloadfile(char *fbuff, int flag);

extern int	lines_instr(char *str);


/* ------ aca INI part ------ */

typedef struct {
	char	*section;
	int	(*loader)(FILE *f, int flag),	/* your section loader */
		(*writer)(FILE *f),		/* your section loader */
		flag;				/* need section save (rewrite) ? */		
} ini_func;

/* loader flags: */
#define	NOT_SECTION	FALSE
#define YES_SECTION	TRUE

typedef struct {
	ini_func	*ini_fn;
	char		*ini_file;
} aca_INI;

extern void	INI_set_current(aca_INI *ai);
extern int 	INI_goto_section(FILE *f, char *section);
extern ini_func	*INI_isneed_save(aca_INI *ai, char *section);
extern int 	INI_load(aca_INI *ai);
extern int 	INI_write(aca_INI *ai);
extern int	INI_del_section(aca_INI *ai, char *section);
extern int 	INI_need_save(char *section);
extern int	INI_set_flag(int i, int flag);
extern int 	INI_ischange(aca_INI *ai);

	/* where: 
	   - 'ai->ini_fn' is array and last item of this array must be 
	   	{ (char *) NULL, 0, 0, FALSE }
	 */  
		
extern char	*separe_str(char *org, int sep);

#define CLEAN_BIT	1
#define	KIM_BITNUM	8

extern void	set_bit(unsigned int *b, int n, int set);
extern int	show_bit(int unsigned x, int unsigned i);

#endif /* __ACA_UTIL_H  */ 