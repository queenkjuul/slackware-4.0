
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdlib.h>
#include <time.h>
#include <proc/whattime.h>
#include <proc/sysinfo.h>
#include <string.h>

#include "kim.h"
#include "procdata.h"
#include "layout.h"
#include "procsort.h"
#include "proccols.h"
#include "profile.h"
#include "util.h"
#include "fill_list.h"
#include "kimwins.h"
#include "menu.h"

kim_LAYOUT	conf_L;
static char	search_str[TMP_SIZE];
static char	*report_buff;

#define SEARCH_TITLE_SIZE	64
static char	search_title[ SEARCH_TITLE_SIZE ];

static kim_DATA	*L_d;

int INI_loader_layout(FILE *f, int flag)
{
   	char	*opt;
   	int	i;
   	
   	_D(" INI_loader_layout() ");
   	
   	if (flag == YES_SECTION) {
   		for (i=0; i<=7; i++) {
   			ks.tmp[0] = '\0';		/* TODO: rewrite to cycle */
   			fgets(ks.tmp, TMP_SIZE, f);
   			if (!(opt=separe_str(ks.tmp, '='))) 
   				continue;
   			else if (!strcmp(ks.tmp, "color_zombie"))
   				conf_L.color_zombie = atoi(opt);			
   			else if (!strcmp(ks.tmp, "color_run"))
   				conf_L.color_run = atoi(opt);	
   			else if (!strcmp(ks.tmp, "spec"))
   				aca.spec = conf_L.spec = atoi(opt);
   			else if (!strcmp(ks.tmp, "save"))
   				conf_L.save = atoi(opt);					
   			else if (!strcmp(ks.tmp, "sort"))
   				conf_L.sort = atoi(opt);
   			else if (!strcmp(ks.tmp, "sort_cols"))
   				conf_L.sort_cols = atoi(opt);   				
   			else if (!strcmp(ks.tmp, "view"))
   				conf_L.view = atoi(opt);
   			else if (!strcmp(ks.tmp, "inpage"))
   				conf_L.inpage = atoi(opt);				
   			else if (!strcmp(ks.tmp, "infoline"))
   				conf_L.infoline = atoi(opt);				
   		}		
   	} 
   	return TRUE;
}

kim_LAYOUT *cpy_conflayout(kim_LAYOUT *dest, kim_LAYOUT *src)
{
	_D(" cpy_conflayout()");

	dest->color_zombie	= src->color_zombie;
	dest->color_run 	= src->color_run; 
	dest->sort		= src->sort;     
	dest->sort_cols		= src->sort_cols;     
	dest->spec		= src->spec;     	
	dest->view		= src->view;    
	dest->inpage		= src->inpage;
	dest->infoline		= src->infoline;
	dest->save		= src->save;

	return dest;
} 
   
int INI_writer_layout(FILE *f)
{
   	_D(" INI_writer_layout() ");
   	
   	fprintf(f, "color_zombie=%d\n",	conf_L.color_zombie);
     	fprintf(f, "color_run=%d\n",	conf_L.color_run);
     	fprintf(f, "save=%d\n",		conf_L.save);
     	fprintf(f, "spec=%d\n",		conf_L.spec);
     	
     	if (conf_L.save) {
     		fprintf(f, "sort=%d\n", 	conf_L.sort);
     		fprintf(f, "sort_cols=%d\n",	conf_L.sort_cols);
     		fprintf(f, "view=%d\n",	
     			((conf_L.view==VIEW_USER) ? VIEW_ALL : conf_L.view));  
     	} else {	
     		fprintf(f, "sort=%d\n",		SORT_NATURALLY);
     		fprintf(f, "sort_cols=%d\n",	FALSE);
     		fprintf(f, "view=%d\n",		VIEW_ALL);
     	}
     	fprintf(f, "inpage=%d\n",	conf_L.inpage);
     	fprintf(f, "infoline=%d\n",	conf_L.infoline);
   	return TRUE;
}

/*------------------------ layout widgets define --------------------------- */

Wbutton kim_bar[] = {
	/* with "     " is defined in init_kim_bar(), but
		here need for init_sessw()  */
		
	{ N_("Help  "), 0, Wb_PRESS_GO },
	{    "      ",  0, Wb_PRESS_GO },
	{ N_("More  "), 0, Wb_PRESS_GO },
	{    "      ",  0, Wb_PRESS_GO },
	{ N_("Reload"), 0, Wb_PRESS_GO },
	{    "      ",  0, Wb_PRESS_GO },
	{ N_("Search"), 0, Wb_PRESS_GO },
	{    "      ",  0, Wb_PRESS_GO },
	{ N_("Menu  "), 0, Wb_PRESS_GO },
	{ N_("Quit  "), 0, Wb_PRESS_GO }
};
Wmenu list_area = { 
	chN, 0, M_OPEN | M_NOTOUT | M_BORDER | M_TITLE | M_STILLV | M_BLANK | M_SHTMENU | M_COLORDIRECT,
	0,0,0,0,0,0,0,0,0,0, alistN, voN, mpr_list_area
}; 
Wmenu k_menu[] = {
     {  N_(" |L|eft "), 0, M_TITLE | M_TOPTITLE | M_BORDER | M_COLOROUT,
	0,0,0,0,0,0,0,0,0,0, alistN, voN, mpr_left
     },{
        N_(" |C|ommand "), 0, M_TITLE | M_TOPTITLE | M_BORDER | M_ALIST | M_BLANK | M_COLOROUT,
	5,0,0,6,0,0,0,0,0,0, comm_astr, voN, mpr_comm, 2 /* blank line */ 
     },{
        N_(" |P|rofile "), 0, M_TITLE | M_TOPTITLE | M_BORDER | M_COLOROUT,
	0,0,0,0,0,0,0,0,0,0, alistN, voN, mpr_profile
     },{
        N_(" |O|ption "), 0, M_TITLE | M_TOPTITLE | M_BORDER | M_ALIST | M_COLOROUT,
	4,0,0,4,0,0,0,0,0,0, option_astr, voN, mpr_opt
     },{
        N_(" |V|iew "), 0, M_TITLE | M_TOPTITLE | M_BORDER | M_COLOROUT,
	0,0,0,0,0,0,0,0,0,0, alistN, voN, mpr_view
     }	
};
Winput w_search = { chN, 0, search_str, 0,0,0,0 };	 

Widget kim_w[] = {
/*	  -key-     -locate-  -func-     -widget data-	        -flag-	*/
	{ FALSE,    0,0, 0,0,  menu_fn,   (void *) &list_area,  Wf_NOTUSE_ASTR 	},
	{ KEY_F(1), 0,1, 0,0,  button_fn, (void *) &kim_bar[0], Wf_NOTUSE_ASTR 	},
	{ KEY_F(2), 0,9, 0,0,  button_fn, (void *) &kim_bar[1], Wf_NOTUSE_ASTR 	},	
	{ KEY_F(3), 0,17,0,0,  button_fn, (void *) &kim_bar[2], Wf_NOTUSE_ASTR 	},	
	{ KEY_F(4), 0,25,0,0,  button_fn, (void *) &kim_bar[3], Wf_NOTUSE_ASTR 	},
	{ KEY_F(5), 0,33,0,0,  button_fn, (void *) &kim_bar[4], Wf_NOTUSE_ASTR 	},
	{ KEY_F(6), 0,41,0,0,  button_fn, (void *) &kim_bar[5], Wf_NOTUSE_ASTR 	},	
	{ KEY_F(7), 0,49,0,0,  button_fn, (void *) &kim_bar[6], Wf_NOTUSE_ASTR 	},
	{ KEY_F(8), 0,57,0,0,  button_fn, (void *) &kim_bar[7], Wf_NOTUSE_ASTR 	},
	{ KEY_F(9), 0,65,0,0,  button_fn, (void *) &kim_bar[8], Wf_NOTUSE_ASTR 	},	
	{ KEY_F(10),0,74,0,0,  button_fn, (void *) &kim_bar[9], Wf_NOTUSE_ASTR 	},
	{ '/',      0,0, 0,0,  input_fn,  (void *) &w_search,   Wf_NOTVISIBLE | Wf_NOTUSE_ASTR | Wf_TYPE_INPUT },
	{ TRUE,     2,0, 0,15, menu_fn,   (void *) &k_menu[0],  Wf_DEFAULT	},
	{ TRUE,     2,0, 5,0,  menu_fn,   (void *) &k_menu[1],  Wf_DEFAULT	},
	{ TRUE,     2,0, 0,19, menu_fn,   (void *) &k_menu[2],  Wf_DEFAULT	},	
	{ TRUE,     2,0, 4,0,  menu_fn,   (void *) &k_menu[3],  Wf_DEFAULT	},	
	{ TRUE,     2,0, 0,25, menu_fn,   (void *) &k_menu[4],  Wf_DEFAULT	},	
	W_NULL
};

#define FIRST_MENU	12	/* firs menu widget ID */
#define LAST_MENU	16	/* last menu widget ID */

/* kim widgets session */
SessW	kim_s = { 16, 0, FALSE, kim_w, K_STAY, kim_bgr };

/* ------------------------------------------------------------------------- */

void reset_menu()
{
	_D(" reset_menu()");
	
	ACA_RESET_MENU((&k_menu[0]));
	ACA_RESET_MENU((&k_menu[1]));
	ACA_RESET_MENU((&k_menu[2]));
	ACA_RESET_MENU((&k_menu[3]));
	ACA_RESET_MENU((&k_menu[4]));
}

static void soft_init_layout()
{	
	static	char header[64];
	
	_D( " soft_init_layout() ");

     /* list area */
        memset(ks.tmp, '\0', sizeof(char) * TMP_SIZE);
	strftime(ks.tmp, 40, "%H:%M-%b-%d", localtime((time_t *) &L_d->time_now));	
	sprintf(header, "%.15s-%s", L_d->uname.nodename, ks.tmp);	
	
	list_area.astr		= header;
	list_area.list		= (void *) L_d;		
	list_area.item_max	= L_d->view_num;	
	list_area.scr_max 	= L_d->view_num+1 > LINES - 6 ? LINES - 6 : L_d->view_num+1;
	list_area.sht_max	= count_prof_width(L_d);
	L_d->area_width		= list_area.sht_max;
	kim_w[0].lines		= list_area.scr_max;
     
     /* command menu */
	k_menu[1].list		= (void *) L_d;
	
     /* view menu */
	k_menu[16].list		= (void *) L_d;	
}


void init_layout()
{	
	_D( " init_layout() ");

	soft_init_layout();

     /* list area */
	kim_w[0].x		= 1;
	kim_w[0].y		= 2;
	kim_w[0].cols		= COLS - 3;
	list_area.blank		= 0;
	list_area.item_act	= 0;
	list_area.item_last	= 0;
	list_area.scr_act	= 0;
	list_area.scr_last	= 0;
	list_area.sht_act	= 0;
	list_area.fios		= 0;
	list_area.lios		= 0;
     
     /* search */	
	kim_w[11].y		= LINES - 2;
	sprintf(search_title, _(" Search (in '%.45s'): "), kc[ conf_P.act_profile.cols[0] ].name );	
	w_search.astr		= search_title;
	w_search.astr_size	= strlen(search_title);
	w_search.max		= *(L_d->cols_width + *conf_P.act_profile.cols);
     
     /* left menu */
	k_menu[0].item_max	= conf_P.act_profile.col_num;
	k_menu[0].scr_max	= k_menu[0].item_max > LINES - 7 ? LINES - 7 : k_menu[0].item_max;		
	kim_w[12].lines		= k_menu[0].scr_max;

     /* profile menu */
        k_menu[2].item_max	= conf_P.num;
	k_menu[2].scr_max	= k_menu[2].item_max > LINES - 7 ? LINES - 7 : k_menu[2].item_max;		
	kim_w[14].lines		= k_menu[2].scr_max;
	
     /* View menu */
     	k_menu[4].item_max 	= GL_kdata_num;
	k_menu[4].scr_max	= k_menu[4].item_max > LINES - 7 ? LINES - 7 : k_menu[4].item_max;		     		
	kim_w[16].lines		= k_menu[4].scr_max;
}


void kim_bgr(SessW *s)
{
	int	i;
	
	_D( " kim_bgr() ");
	
	ubold;
	draw_linebox(1, LINES-3, 0, COLS-1, WHITE_BLUE);
	CLEAN_BOX(2, LINES-4, 1, COLS-2);
        
	aca_c(WHITE_BLACK);	
	CLEAN_BOX( LINES-2, LINES, 0, COLS);
	
	for(i=0; i<=9; i++) {
		if (i==9) mvaddstr(LINES-1, kim_w[FIRST_BAR +i].x - 2, "10");
		else mvprintw(LINES-1, kim_w[FIRST_BAR +i].x - 1, "%d", i+1);	
	}
	aca_c(BLACK_CYAN); 	
	CLEAN_HLINE(0, 0, COLS-1);	   
	aca_uc(BLACK_CYAN);
}

void init_kim_bar(kim_DATA *d) 
{
	int	i;

	_D( " init_kim_bar() ");
	
	for(i=0; i<=9; i++) 
		kim_w[FIRST_BAR + i].y	= LINES-1;

	/* NOTE: next bar labels not initiate in init_sessw() with
		_() - need init here with _() */

	if (d->view_mode == VIEW_YOUR) 	kim_bar[5].astr = _("All   ");
	else				kim_bar[5].astr = _("Your  ");
		
	if (d->sort_mode == SORT_TREE) {      
		kim_bar[1].astr = _("List  ");
		kim_bar[5].astr =   "      ";
	} else				
		kim_bar[1].astr = _("Tree  ");		
	
	if (d->flag == FROM_FILE)	kim_bar[3].astr =   "      ";
	else				kim_bar[3].astr = _("Maps  ");
	
	if (d->flag == FROM_FILE)	kim_bar[7].astr =   "      ";
	else				kim_bar[7].astr = _("Signal");					
}


void bar_action(SessW *s, kim_DATA *d)
{
	int	a, b;
	
	_D( " bar_action() ");
	
	switch(s->actual) {
	case FIRST_BAR + 0:
		_D( "HELP" );
		if (!kim_help()) {
			sprintf(ks.tmp, "%s%s", ks.libdir, KIM_HELP_ASCII);
			Dlg_FileViewer(ks.tmp, _(" Help "), _("Warning: Can't exec external HTML help viewer - try internal ascii viewer"), COLS-4);
		}
		break;
	case FIRST_BAR + 1:
		_D( "TREE" );
		if (d->sort_mode == SORT_TREE) 
			prepare_view(d->view_mode, SORT_NATURALLY, d); 	
		else
			prepare_view(VIEW_ALL, SORT_TREE, d); 	
		init_kim_bar(d);
		init_layout();
		W_redraw_session(&kim_s);
		break;		
	case FIRST_BAR + 2:
		_D( "MORE" );
		if (d->view_num >= 0) wins_more( d );
		break;	
	case FIRST_BAR + 3:
		_D( "MAPS" );
		if (d->flag == FROM_FILE) break;
		sprintf(ks.tmp, "%s/%d/%s", PROC_DIR, d->cpt->pid, FILE_MAPS);
		sprintf(ks.out_buff, _(" MAPS: %s (%d) "), d->cpt->cmd, d->cpt->pid);
		Dlg_FileViewer(ks.tmp, ks.out_buff, _(" address           perm offset   dev   inode"), COLS-3);
		break;		
	case FIRST_BAR + 4:
		_D( "RELOAD" );
		if (d->flag != FROM_PROC) {
			if (!Dlg_YesNo( _(" Reload "), _("Current processes data are from FILE.\n Do you want to replace data from /proc ?"), 50 )) 
				break;
		}		
		a = d->proc_num;
		b = d->sort_cols;
		free_kim_data(d);
		if (proc_from_proc(d) == RE_ERROR) 
      			exit(RE_ERROR);
      		d->sort_cols = b;	
		prepare_view(d->view_mode, d->sort_mode, d); 
		if (a > d->proc_num)	init_layout();
		else			soft_init_layout();	
		W_redraw_session(s);
		break;		
	case FIRST_BAR + 5:
		_D( "ALL / YOUR / SHORT" );
		if (d->sort_mode != SORT_TREE) {
			if (d->view_mode == VIEW_ALL) 
				prepare_view(VIEW_YOUR, d->sort_mode, d); 	
			else
				prepare_view(VIEW_ALL, d->sort_mode, d); 	
			init_kim_bar(d);
			init_layout();
			W_redraw_session(&kim_s);
		}
		break;	
	case FIRST_BAR + 6:
		_D( "SEARCH" );
			kim_s.key = '/';
			W_key_to_widgets(&kim_s);	
		break;			
	case FIRST_BAR + 7:
		_D( "SIGNAL" );
		if (d->flag == FROM_PROC) {
			if (!wins_signals(d)) break;
		} else
			break;
		s->actual = FIRST_BAR+4;
		bar_action(s, d);
		s->actual = FIRST_BAR+7;
		break;
	case FIRST_BAR + 8:
		_D( "MENU" );
		set_widget(kim_w, &kim_s, 12);	
		break;		
	case FIRST_BAR + 9:
		_D( "QUIT" );
		if (Dlg_YesNo( " kim ", _("Do you really want to quit the Kim ?"), 50 )) {
			INI_write(&kimINI);
			exit( RE_OK );
		}	
		break;	
	}
	W_redraw_session(&kim_s);
}

/*
	Print actual meminfo
*/	
void mvprintw_act_meminfo(int line, int cols)
{
      unsigned** mem;
      if (!(mem = meminfo())) 
         perror("/proc/meminfo");
      
      mvprintw(line, cols, "ACTUAL: MEM-FREE:%d SWAP-FREE:%d BUFF:%d SHARED:%d CACHED:%d (kB)", 
        (mem[meminfo_main][meminfo_free]    >> 10),
        (mem[meminfo_swap][meminfo_free]    >> 10),
        (mem[meminfo_main][meminfo_buffers] >> 10),
        (mem[meminfo_main][meminfo_shared]  >> 10),
        (mem[meminfo_main][meminfo_cached]  >> 10)
      );	       
}

/*
	Print data meminfo
*/	
void mvprintw_data_meminfo(int line, int cols, kim_DATA *d)
{
      mvprintw(line, cols, "DATA: MEM-FREE:%d SWAP-FREE:%d BUFF:%d SHARED:%d CACHED:%d (kB)",
        (d->sys_m[meminfo_main][meminfo_free]    >> 10),
        (d->sys_m[meminfo_swap][meminfo_free]    >> 10),
        (d->sys_m[meminfo_main][meminfo_buffers] >> 10),
        (d->sys_m[meminfo_main][meminfo_shared]  >> 10),
        (d->sys_m[meminfo_main][meminfo_cached]  >> 10)
      );	       
}

void set_report_buff(char *str)
{
	report_buff = str;
}

void print_report( kim_DATA *d)
{
	int	a;
	
	_D(" print_report() ");
	
	aca_c(YELLOW_CYAN); bold;
	CLEAN_HLINE(0, 45, COLS);
	if (!report_buff) {
	        if (d->mark_num) 
	        	mvprintw(0, COLS-30, _("%d processes & %d selected"), d->view_num+1, d->mark_num);
	        else 
	        	mvprintw(0, COLS-15, _("%d processes"), d->view_num+1);
        } else {
        	mvaddnstr(0, COLS-20, report_buff, 19);
        	report_buff = chN;
        }
        ubold;	

	aca_c(BLACK_WHITE);
	mvaddstr(LINES-3, (a = COLS - 2 - strlen(conf_P.name[conf_P.current])),
			conf_P.name[conf_P.current]);
     	aca_c(MAGENTA_BLUE); bold;
     	if (d->sort_mode == SORT_NATURALLY)  
     		mvprintw(LINES-3, a-10, "%s:", _("Naturally"));	
     	else if (d->sort_mode == SORT_TREE) 
     		mvprintw(LINES-3, a-5, "%s:", _("Tree"));		
     	else {
     		mvprintw(LINES-3, (a= a-1-strlen(kc[d->sort_cols].name)), 
     			"%s:", kc[d->sort_cols].name);		     
     		mvaddch	(LINES-3, a-2,
			(d->sort_mode == SORT_DATA_ASC ? ACA_DARROW : ACA_UARROW));			   	
	}	
	if (d->flag == FROM_FILE) { 
		aca_c(WHITE_BLUE); ubold;
		mvaddstr(1, COLS-8, _("(file)"));
	}	
}

void print_infoline( kim_DATA *d)
{
	_D(" print_infoline() ");	
	
	ubold; aca_c(WHITE_BLACK);
        CLEAN_HLINE(LINES-2, 0, COLS-1);
        switch(conf_L.infoline) {
        	case _I_CMDLINE:
        		mvaddnstr(LINES-2, 1, 
        			(kc +_CMDLINE)->maker(ks.out_buff, d), COLS-1);
			break;
		case _I_UPTIME:
			mvaddstr(LINES-2, 1, sprint_uptime());					
			break;
		case _I_MEM:
			mvprintw_act_meminfo(LINES-2, 1);
			break;
	}
}

void set_L_d(kim_DATA *new_L_d)
{
	L_d = new_L_d;
}


void kim_interface(kim_DATA *data)
{
	int	re=0, re2=0, spec=0, a;

	_D( " kim_interface() ");	
	
	init_sessw(&kim_s);
	
	/* set (interspace between menu and) menu 'x' positions */
	
	set_widgets_progresion(0, " w w w w w", &kim_w[FIRST_MENU], 	
			  &kim_w[FIRST_MENU+1], &kim_w[FIRST_MENU+2], 
			  &kim_w[FIRST_MENU+3], &kim_w[FIRST_MENU+4]);
	
	L_d = data;
	
	report_buff = chN;
	init_kim_bar(L_d);
	init_layout();
	
	W_redraw_session(&kim_s);
	
	do {
		_D( "RUNNIG DIRECT CYCLE" );
		
		if (XCTRL('x') == GL_last_key && kim_s.actual == 0) {
			if (fast_action(kim_s.key, L_d)) {
				init_layout();
				init_kim_bar(L_d);
			}	
			W_redraw_session(&kim_s);
			kim_s.key = K_STAY;
		} else if (D_CTRL_KEY('t','b')) {
 			mvprintw(LINES-2, 1, "DATA:%s", L_d->uptime_str);		
			continue;
		} else if (D_CTRL_KEY('t','a') || ESC_KEY('u')) {
 			mvaddstr(LINES-2, 1, sprint_uptime());		
			continue;
		} else if (D_CTRL_KEY('k', 'b')) {
			mvprintw_data_meminfo(LINES-2, 1, L_d);
			continue;
		} else if (D_CTRL_KEY('k', 'a') || ESC_KEY('f')) {
			mvprintw_act_meminfo(LINES-2, 1);
			continue;
		}
		
	  /*** pre - spec. keys ***/ 
		switch(kim_s.key) {
		case T_XCTRL('m'):
			if (kim_s.actual == 0) kim_s.key = KEY_F(3);
			break;
		case KEY_F(9):
			kim_s.key = gethotkey(_(k_menu[0].astr));
			break;
		case '/':	
		case KEY_F(7):
			if (kim_s.actual != 11) 
				{ search_str[0] = '\0'; w_search.poz = w_search.a_size = 0; }
			break;
		case K_MOUSE_R:
			if (kim_s.actual == 0 && is_mouse_in_widget(kim_w, &kim_s)) 
					{ spec = 1; kim_s.key = K_MOUSE_L; }
			break;
		case KEY_IC:
               		if (kim_s.actual == 0) {
 	              		if (L_d->cpd->mark) 
 	              			{ --L_d->mark_num; L_d->cpd->mark = P_UNMARKED; } 
	            	 	else 
	            			{ ++L_d->mark_num; L_d->cpd->mark = P_MARKED; }
            			kim_s.key = KEY_DOWN;
			}
			break;
		case KEY_F(10):
			if (kim_s.actual != 0) { 
				if (aca.color) ubold;
				kim_s.actual = 0; 
				kim_s.key = K_STAY; 
				W_redraw_session(&kim_s);
			}
			break;	
		case '-':
			if (L_d->mark_num && kim_s.actual == 0) {
				_D( "UNSELECT ALL" );
				if (Dlg_YesNo( " kim ", _("Unselect all ?"), 50 ))
					unselect_all(L_d);
				W_redraw_session(&kim_s);		
			}
			break;	
		}			
	   	
	   /*** widgets ***/
		if (!kim_s.lock) kim_s.actual = 0;
		re = 0;
		
		re = run_act_widget(&kim_s);
		
		if ((kim_s.actual >= FIRST_MENU) && (kim_s.actual <= LAST_MENU)) {
			if (re & Wr_MENU_PRESS) { 
				if (menu_action( (Wmenu *) kim_w[kim_s.actual].widget_data, 
						L_d, kim_w[kim_s.actual].id)) {
					init_layout();
					init_kim_bar(L_d);
					W_redraw_session(&kim_s);
				}	
				set_widget(kim_w, &kim_s, 0);	
				re = 0;
			}
			if (kim_s.actual == FIRST_MENU+2 && kim_s.key == ' ') {
				conf_P.p_default = k_menu[2].item_act;
				INI_set_flag(_S_PROFILING, TRUE);
				draw_widget(&kim_s, 14);	
			}	
		}
		/* redraw without actual widget */
		if (re & Wr_NEED_REDRAW) { 		
			_D( "Wr_NEED_REDRAW" );
			a = kim_s.actual; kim_s.actual = -1;
			W_redraw_session(&kim_s); kim_s.actual = a;	
		}
		if ((re & Wr_MENU_OUT) &&
		   (kim_s.actual >= FIRST_MENU) && (kim_s.actual <= LAST_MENU) &&
		   ((kim_s.key == KEY_LEFT) || (kim_s.key == KEY_RIGHT))) {
	
			if (kim_s.actual == FIRST_MENU && kim_s.key == KEY_LEFT) 
				set_widget(kim_w, &kim_s, LAST_MENU);
			if (kim_s.actual == LAST_MENU && kim_s.key == KEY_RIGHT) 
				set_widget(kim_w, &kim_s, FIRST_MENU);	
		
		} 
		/* in search (11) is insert chars ==> not goot switch to other widget 
			(through of hotkey) */
		re2= W_key_to_widgets(&kim_s);	
		
		if (kim_s.actual==11 && (kim_s.key == KEY_UP || kim_s.key == KEY_DOWN || 
					kim_s.key == '\t' || kim_s.key =='\n'))
			set_widget(kim_w, &kim_s, 0);
		
		W_default_go(&kim_s);
		
		if ((kim_s.actual == 0) && (re & Wr_MENU_PRESS)) { 	
			kim_s.actual = FIRST_BAR+2;
			bar_action(&kim_s, L_d); 
			set_widget(kim_w, &kim_s, 0);
		}
		if (((re2 & Wr_BUTTON_PRESS) || (re & Wr_BUTTON_PRESS)) &&
		    (kim_s.actual >= FIRST_BAR) &&
		    (kim_s.actual <= FIRST_BAR + 9)) {
			bar_action(&kim_s, L_d);
			if (!kim_s.lock) set_widget(kim_w, &kim_s, 0);
		}	
	   
	   /*** for left mouse key ***/
		if (spec) {
			spec = 0;
			if (L_d->cpd->mark) { --L_d->mark_num; L_d->cpd->mark = P_UNMARKED; }
 			else 		  { ++L_d->mark_num; L_d->cpd->mark = P_MARKED; }
            		W_redraw_session(&kim_s);
		}

		print_report(L_d);

	   /*** search ***/	
		if (kim_s.actual==11) {
			kim_search(L_d, w_search.str);
			kim_w[0].widget_fn( &kim_s, &kim_w[0], 
				kim_w[0].widget_data, K_STAY, WIDGET_DRAW);
			print_report(L_d);
			draw_act_widget(&kim_s);
		}
		if (kim_s.actual==0 ) print_infoline(L_d);		
	} while((kim_s.key = get_k()));  
}


