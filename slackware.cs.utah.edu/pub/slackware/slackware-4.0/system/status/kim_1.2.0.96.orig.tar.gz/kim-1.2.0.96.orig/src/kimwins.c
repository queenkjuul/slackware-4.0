
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <string.h>
#include <stdlib.h>

#include "kim.h"
#include "procdata.h" 
#include "proccols.h" 
#include "procsort.h"
#include "profile.h"
#include "layout.h"
#include "kimwins.h"
#include "util.h"

#define Y(a)	(a+y)
#define X(a)	(a+x)

static int	*s_cols;		/* sorted cols */

/*--------------------- SIGNALS / KILL ------------------------------------- */

static void mpr_signals(Wmenu *m, Widget *w, int i, int l) 
{
	kim_SIGNALS	*s;        
                  
        s = (kim_SIGNALS *) m->list;
        set_color_menu_in(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	mvprintw(l+w->y, w->x+1, "%3d %s", s[i].signum, s[i].signame);
}

static int kim_send_signal( kim_DATA *d, int signum)
{
	int 		i, re=FALSE;
	static	chtype	**scr_buff = (chtype **) NULL;
	
	_D( " kim_send_signal() ");
	
	if (!scr_buff)
		if (!(scr_buff = init_refresh_buffer()))
			exit(RE_ERROR);
	
	if (d->mark_num) {
		for(i=0; i<=d->view_num; i++) {
			_D("MORE KILL");
			if (d->pd[ d->sort[i] ].mark) {
				if (!killer(d->pt[ d->sort[i] ]->pid, signum, d->pt[ d->sort[i] ]->cmd, ks.tmp)) {
					fill_refresh_buffer(scr_buff);
					Error(ks.tmp);
					print_refresh_buffer(scr_buff);
					re = re ? TRUE : FALSE;	
				} else
					re = TRUE;
			}		
		}
		if (re) wait_time(1);
		return re;
	} else if (!killer(d->cpt->pid, signum, 
			d->cpt->cmd, ks.tmp)) {
		fill_refresh_buffer(scr_buff);
		Error(ks.tmp);
		print_refresh_buffer(scr_buff);
		return FALSE;
	} 
	wait_time(1);
	return TRUE;
}

int wins_signals( kim_DATA *d )
{
	kim_SIGNALS sig[] = {
		#include	"kim_signames.h"
	};
	int	y=LINES/2-8, x=COLS/2-20, 
		yn=16, xn=41, re;
	Wmenu	m = {
		N_(" |S|ignals "),0, M_OPEN | M_STILLV | M_BORDER | M_TITLE | M_COLORIN,
		(sizeof(sig) / sizeof(kim_SIGNALS) -1), 2,0,6,2,0,0,0,0,0, 
		alistN, (void *) &sig, mpr_signals
	};
	Widget	w[] = {
		{ TRUE, Y(7), X(2),  8,23, menu_fn,   (void *) &m, Wf_DEFAULT },
		{ TRUE, Y(8), X(31), 0, 5, button_fn, (void *) &def_button[_BUTT_OK],     Wf_DEFAULT },
		{ TRUE, Y(11),X(29), 0, 9, button_fn, (void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },
		W_NULL
	};
	SessW	s = { 2, 0, FALSE, w, K_STAY, NULL, Sf_HAVENT_BGR };	

	_D( " wins_signal() ");
	
	init_sessw(&s);
	
	aca_border (y, y+yn, x, x+xn, BLACK_WHITE); 
	CLEAN_BOX (Y(1), Y(yn-1), X(1), X(xn-1));
	draw_linebox (Y(7), Y(9), X(29), X(38), RED_WHITE);
	
	bold; aca_c(YELLOW_WHITE);
	mvaddstr( Y(0), X(16), _(" SIGNALS ")); ubold; 
	aca_c(BLACK_WHITE);
	if (!d->mark_num) {
        	mvaddstr(Y(2), X(2), _("name:")	); 
        	mvaddstr(Y(3), X(2), "pid:"	);   
   		mvaddstr(Y(4), X(2), _("user:")	);  
		mvaddstr(Y(2), X(25)," tty:"	);  
        	mvaddstr(Y(3), X(25)," stat:"	); 
   		mvaddstr(Y(4), X(25)," uid:"	);  
		ubold; aca_c(BLUE_WHITE);
		mvaddstr(Y(2), X(12), kc[_NAME].maker(ks.tmp, d));
        	mvaddstr(Y(3), X(12), kc[_PID ].maker(ks.tmp, d));
        	mvaddstr(Y(4), X(12), kc[_USER].maker(ks.tmp, d));
        	mvaddstr(Y(2), X(33),kc[_TTY ].maker(ks.tmp, d));
        	mvaddstr(Y(3), X(33),kc[_STAT].maker(ks.tmp, d));
        	mvaddstr(Y(4), X(33),kc[_UID ].maker(ks.tmp, d));
	} else {
		mvaddstr(Y(2), X(2), _("Send signal to:"));
		mvaddstr(Y(3), X(5), _("selected processes ?"));
		aca_c(BLUE_WHITE); mvprintw(Y(3), X(2), "%d", d->mark_num);
	}	
	if (getuid() == 0) 
		{ blink; mvaddstr(Y(13), X(30), "! ROOT !"); ublink; }
	ubold;
	W_redraw_session(&s);
	do {
		aca_c(BLACK_WHITE); CLEAN_HLINE(Y(15), X(2), X(xn-2));
		
		re = 0;
		re = run_act_widget(&s);
	        W_key_to_widgets(&s);		
		W_default_go(&s);
		
		if (s.actual==0) {
			aca_c(BLACK_WHITE);
			mvaddch(Y(15), X(2), ACA_RARROW);
			mvprintw(Y(15), X(4), "%.36s", _(sig[m.item_act].descript));
		} else if (s.actual == 1) {
			aca_c(RED_WHITE);
			mvaddstr(Y(15), X(14), _("Are you sure ?"));
		}
		
	     /* OK */   	
		if ((re & Wr_BUTTON_PRESS) && s.actual == 1) 
			return kim_send_signal(d, sig[m.item_act].signum);
	     /* Cancel */   	
		else if ((re & Wr_BUTTON_PRESS) && s.actual == 2) 
			return FALSE;
	} while((s.key = get_k()) != KEY_F(10)); 	
	return FALSE;
}

/*--------------------- MORE ----------------------------------------------- */

static void mpr_more(Wmenu *m, Widget *w, int i, int l) 
{
	kim_DATA	*d;
	
	d = (kim_DATA *) m->list;	
        set_color_menu_in(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	mvaddstr (l+w->y, w->x+1,  kc[ s_cols[i] ].name);
	mvprintw (l+w->y, w->x+12, " %.45s", _(kc[ s_cols[i] ].descript));
	kc[ s_cols[i] ].maker(ks.tmp, d); ks.tmp[12] = '\0';
	mvaddch(l+w->y, w->x+57, ' ');	
	if (m->scr_act == l) {
		aca_c(WHITE_BLACK); 
		CLEAN_HLINE(l+w->y, w->x+58, w->x + w->cols); 
	} else {	
		aca_c(BLACK_CYAN); 
		CLEAN_HLINE(l+w->y, w->x+58, w->x + w->cols); 
	}	
	mvaddstr(l+w->y, w->x+59, ks.tmp);	
}

void wins_more( kim_DATA *d )
{
	int	yn=LINES-5, xn=75, y=LINES/2-(yn/2), x=COLS/2-(xn/2)-1, re;
	Wmenu	m = {
		N_(" name        description                                  value "),  
		0,M_TITLE_NSEL | M_OPEN | M_BORDER | M_TITLE | M_COLORIN,
		COLS_NUM, 0,0, (yn-5 > COLS_NUM ? COLS_NUM : yn-5),
		0,0,0,0,0,0, alistN, (void *) d, mpr_more
	};
	Widget	w[] = {
		{ FALSE, Y(2),    X(2),yn-5,xn-4, menu_fn,   (void *) &m, Wf_NOTUSE_ASTR },
		{ TRUE,  Y(yn-1), X(xn-12), 0, 9, button_fn, (void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },
		W_NULL
	};
	SessW	s = { 1, 0, FALSE, w, K_STAY, NULL, Sf_HAVENT_BGR };	

	_D( " wins_more() ");

	init_sessw(&s);

	s_cols = get_sort_cols();
	aca_border (y, y+yn, x, x+xn, BLACK_WHITE); 
	CLEAN_BOX (Y(1), Y(yn-1), X(1), X(xn-1));
	sprintf(ks.tmp, _(" MORE: %s (%d) "), d->cpt->cmd, d->cpt->pid); 
	bold; aca_c(YELLOW_WHITE); 
	mvaddstr( Y(0), X(xn/2-strlen(ks.tmp)/2), ks.tmp); 
	ubold; aca_c(BLACK_WHITE); 
	
	W_redraw_session(&s);
	do {
		re = 0;
		re = run_act_widget(&s);
	        W_key_to_widgets(&s);		
		W_default_go(&s);
	     /* Quit */   	
		if ((re & Wr_BUTTON_PRESS) && s.actual == 1) 
			return;		
	} while((s.key = get_k()) != KEY_F(10)); 	
}

/* -------------------------- User filter ---------------------------------- */

#define ORIG_SETTING	1
#define WINS_SETTING	2

static void mpr_user(Wmenu *m, Widget *w, int i, int l) 
{
	kim_DATA	*d;        
                  
        d = (kim_DATA *) m->list;
        set_color_menu_in(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	if (show_bit( d->ut[i].view, WINS_SETTING))
		mvprintw (l+w->y, w->x, "[x] %s", d->ut[i].name);
	else
		mvprintw (l+w->y, w->x, "[ ] %s", d->ut[i].name);
}

/*	
	Set original TRUE/FALSE to first bit (ORIG_SETTING)
	---> wins_user() using second bit for view / not view user.
	(this is for cancel (allow return to org. setting)).
 */		 	
void pre_winsuser(kim_DATA *d)
{
	u_tab	*u;
	
	for(u=d->ut; u->name!=NULL; u++)  {
        	if (u->view) { 
        		u->view = 0; 
        		set_bit( &u->view, ORIG_SETTING, 1);
        		set_bit( &u->view, WINS_SETTING, 1);
        	} else 
        		u->view = 0; 
        }
}

/*
	If flag is TRUE set wins_user() (WINS_SETTING) setting to u->view,
	else set original setting (ORIG_SETTING). 
*/
void post_winsuser(kim_DATA *d, int flag)
{
	u_tab	*u;
	
	for(u=d->ut; u->name!=NULL; u++)  {
        	if (flag)
        		u->view = show_bit(u->view, WINS_SETTING) ? TRUE : FALSE;
        	else
        		u->view = show_bit(u->view, ORIG_SETTING) ? TRUE : FALSE;
        }
}

int wins_user( kim_DATA *d ) 
{
	int	y=LINES/2-6, x=COLS/2-20, yn=12, xn=41, re;
	Wradio	r=  { N_("|S|how / Hide selected users"),0, d->show_selected }; 
	Wmenu	m = {
		N_(" |U|sers "),0,M_COLORIN | M_STILLV | M_NOTOUT | M_OPEN | M_BORDER | M_TITLE,
		d->user_num, 0,0, (5 > d->user_num ? d->user_num : 5),
		0,0,0,0,0,0, alistN, (void *) d, mpr_user 
	};
	Widget	w[] = {
		{ TRUE, Y(2), X(2),  0, 29, radio_fn,  (void *) &r,    Wf_DEFAULT },
		{ TRUE, Y(5), X(2),  m.scr_max, 23, menu_fn, (void *) &m,    Wf_DEFAULT },
		{ TRUE, Y(6), X(29), 0, 5,  button_fn, (void *) &def_button[_BUTT_OK],     Wf_DEFAULT },
		{ TRUE, Y(8), X(29), 0, 9,  button_fn, (void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },
		W_NULL
	};
	SessW	s = { 3, 0, FALSE, w, K_STAY, NULL, Sf_HAVENT_BGR };	

	_D( " wins_user() ");
	init_sessw(&s);
	
	pre_winsuser(d);
	
	aca_border (y, y+yn, x, x+xn, BLACK_WHITE); 
	CLEAN_BOX (Y(1), Y(yn-1), X(1), X(xn-1));
	bold; aca_c(YELLOW_WHITE); 
	mvaddstr( Y(0), X(xn/2-6), _(" User filter ")); 
	ubold; aca_c(BLACK_WHITE); 
	
	W_redraw_session(&s);
	do {
		re = 0;
		re = run_act_widget(&s);
		
		if ((re & Wr_MENU_PRESS) || (s.key == ' ' && s.actual == 1)) {
			if ( show_bit( d->ut[m.item_act].view, WINS_SETTING) ) 
				set_bit( &d->ut[m.item_act].view, WINS_SETTING, 0);
			else 
				set_bit( &d->ut[m.item_act].view, WINS_SETTING, 1);
			draw_widget(&s, 1);
		}
		
		W_key_to_widgets(&s);		
		W_default_go(&s);
		
	     /* Cancel */   	
		if ((re & Wr_BUTTON_PRESS) && s.actual == 3) 
			break;
	     /* Ok */   	
		if ((re & Wr_BUTTON_PRESS) && s.actual == 2)  {
			post_winsuser(d, TRUE);
			d->show_selected = r.set;
			prepare_view(VIEW_USER, d->sort_mode, d);
			return TRUE;			
		}		
	} while((s.key = get_k()) != KEY_F(10)); 		
	
	post_winsuser(d, FALSE);
	return FALSE;		
}


/* ------------------------ SORT ------------------------------------------ */


static void mpr_sort(Wmenu *m, Widget *w, int i, int l) 
{
	kim_DATA	*d;        
                  
        d = (kim_DATA *) m->list;
        set_color_menu_in(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	if (d->sort_cols == conf_P.act_profile.cols[i]) {
		mvprintw (l+w->y, w->x+2, "%s", kc[conf_P.act_profile.cols[i]].name);
		mvaddch	(l+w->y, w->x,
			(d->sort_mode == SORT_DATA_ASC ? ACA_DARROW : ACA_UARROW));
	} else
		mvprintw (l+w->y, w->x+2, "%s", 
			kc[conf_P.act_profile.cols[i]].name);
}

static void pre_sort(kim_DATA *d, int *p)
{
	*p = 0;
	if (d->sort_cols == -1)
		d->sort_cols = conf_P.act_profile.cols[0]; 
	switch(d->sort_mode) {
	case SORT_NATURALLY:
		set_bit(p, 0, 1);
		break;
	case SORT_TREE:
		set_bit(p, 1, 1);
		break;
	case SORT_DATA_DESC:	
	case SORT_DATA_ASC:
		set_bit(p, 2, 1);
		break;			
	}
}

static void bgr_sort(SessW *s)
{
	aca_c(BLACK_WHITE);
	CLEAN_BOX(s->wtab[3].y, s->wtab[3].y + s->wtab[3].lines, 
		s->wtab[3].x, s->wtab[3].x + s->wtab[3].cols); 
}

/*
	Sort window
 */
int wins_sort( kim_DATA *d ) 
{
	int	y=LINES/2-6, x=COLS/2-20, yn=13, xn=41, re, sortype=0,
		org_mode 	= d->sort_mode, 
		org_s_cols	= d->sort_cols;
		
	Wradio	r[] =  { 
		{ N_("|N|aturally"), 	  0,0, &sortype, B_DEPEND, 0 },
		{ N_("|T|ree"),      	  0,0, &sortype, B_DEPEND, 1 },			
		{ N_("Cols |D|ESC / ASC"),0,0, &sortype, B_DEPEND, 2 }			
	}; 
	Wmenu	m = {
		N_(" DESC / ASC "),0, M_COLORIN | M_STILLV | M_NOTOUT | M_OPEN | M_BORDER | M_TITLE, 
		P_COLS_NUM, 0,0, (5 > P_COLS_NUM ? P_COLS_NUM : 5), 
		0,0,0,0,0,0, alistN, (void *) d, mpr_sort 
	};
	Widget	w[] = {
		{ TRUE, Y(1), X(2),  0, 29, radio_fn,  (void *) &r[0], Wf_DEFAULT },
		{ TRUE, Y(2), X(2),  0, 29, radio_fn,  (void *) &r[1], Wf_DEFAULT },		
		{ TRUE, Y(3), X(2),  0, 29, radio_fn,  (void *) &r[2], Wf_DEFAULT },		
		{ TRUE, Y(6), X(2), m.scr_max,23,  menu_fn,   (void *) &m,    Wf_DEFAULT },
		{ TRUE, Y(7), X(29), 0, 5,  button_fn, (void *) &def_button[_BUTT_OK],     Wf_DEFAULT },
		{ TRUE, Y(9), X(29), 0, 9,  button_fn, (void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },
		W_NULL
	};
	SessW	s = { 5, 0, FALSE, w, K_STAY, bgr_sort, 0 };	

	_D( " wins_sort() ");

	init_sessw(&s);
	
	pre_sort(d, &sortype);
	
	if (d->sort_mode == SORT_DATA_DESC || d->sort_mode == SORT_DATA_ASC)
		w[3].flag = Wf_NOTUSE_ASTR; 
	else	
		w[3].flag = Wf_NOTVISIBLE | Wf_NOTUSE_ASTR; 
		
	aca_border (y, y+yn, x, x+xn, BLACK_WHITE); 
	CLEAN_BOX (Y(1), Y(yn-1), X(1), X(xn-1));
	bold; aca_c(YELLOW_WHITE); 
	mvaddstr( Y(0), X(xn/2-3), _(" Sort ")); 
	ubold; aca_c(BLACK_WHITE); 
	
	W_redraw_session(&s);
	do {
		re = 0;
		re = run_act_widget(&s);
		
		if (re & Wr_MENU_PRESS) {
			d->sort_cols =  conf_P.act_profile.cols[m.item_act];
			draw_widget(&s, 3);
		}
		if (re & Wr_RADIO_DEPEND) {
			if      (show_bit(sortype, 0)) d->sort_mode = SORT_NATURALLY;
			else if (show_bit(sortype, 1)) d->sort_mode = SORT_TREE;		
			else if (show_bit(sortype, 2)) d->sort_mode = SORT_DATA_ASC;
			CLEAN_HELP; 
		}
		if (d->sort_mode == SORT_DATA_DESC || d->sort_mode == SORT_DATA_ASC) 
			w[3].flag = Wf_NOTUSE_ASTR; 
		else 
			w[3].flag = Wf_NOTVISIBLE | Wf_NOTUSE_ASTR; 

		if (s.actual == 3) 
			HELP_LINE(_("<space> change DESC / ASC, <tab> go to next"));
			
		if (re & Wr_RADIO_DEPEND) 
			W_redraw_session(&s);	
		
		if (s.key == ' ' && s.actual == 3) {
			d->sort_mode = (d->sort_mode == SORT_DATA_ASC ?
				SORT_DATA_DESC : SORT_DATA_ASC);
			d->sort_cols =  conf_P.act_profile.cols[m.item_act];
			draw_widget(&s, 3);
		}	
		
		W_key_to_widgets(&s);		
		W_default_go(&s);
		
	     /* Cancel */
		if ((re & Wr_BUTTON_PRESS) && s.actual == 5) {
			d->sort_mode = org_mode;
			d->sort_cols = org_s_cols;
			break;
		}	
	     /* Ok */
		if ((re & Wr_BUTTON_PRESS) && s.actual == 4)  
			return TRUE;			
	} while((s.key = get_k()) != KEY_F(10)); 		
	
	return FALSE;		
}

/* ----------------------------- EDIT PROFILE ----------------------------- */

static void mpr_pe_sel(Wmenu *m, Widget *w, int i, int l) 
{
        set_color_menu_in(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	mvaddstr(l+w->y, w->x+1, conf_P.name[i]);
}

static void mpr_pe_cols(Wmenu *m, Widget *w, int i, int l) 
{
        set_color_menu_in(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
	mvaddstr(l+w->y, w->x+2, kc[s_cols[i]].name);
}

static void mpr_pe_prof(Wmenu *m, Widget *w, int i, int l) 
{
        ACT_PROFILE *ap;
        
        ap = (ACT_PROFILE *) m->list; 
        
        set_color_menu_in(m, l);
        CLEAN_HLINE(l+w->y, w->x, w->x + w->cols); 
        if (ap->col_num != -1)
		mvaddstr(l+w->y, w->x+2, kc[ap->cols[i]].name);
}

static void bgr_pe(SessW *s)
{
	int	y=LINES/2-8, x=COLS/2-25, yn=17, xn=49;
	ubold; aca_c(BLACK_WHITE); 
	CLEAN_BOX (Y(1), Y(yn-1), X(1), X(xn-1));
	
	mvaddstr( Y(2),  X(2),  _("Select:"));
	mvaddstr( Y(7), X(21),  _("Add cols"));
	mvaddstr( Y(8), X(21),  ">> F5 >>");
	mvaddstr( Y(10), X(21), _("Del cols"));
	mvaddstr( Y(11), X(21), "<< F8 <<");	
}

/*
	Profile editor
*/

#define	NEW_PROFILE	(-2)

int wins_profedit(kim_DATA *d)
{
	int	y=LINES/2-8, x=COLS/2-25, yn=17, xn=49, re,
		p_selected, i;
	ACT_PROFILE 	pedit;
	char		pname[PROF_NAME_SIZE+1];	
	Wmenu sel_prof = {
		N_(">   |p|rofile    <"),0, M_COLORIN | M_BORDER | M_TITLE | M_TOPTITLE, 
		conf_P.num, 0,0, (5 > conf_P.num ? conf_P.num : 5), 
		0,0,0,0,0,0, alistN, NULL, mpr_pe_sel
	};
	Wmenu cm = {
		N_(" Co|l|umns "),0, M_COLORIN | M_STILLV | M_NOTOUT | M_OPEN | M_BORDER | M_TITLE, 
		COLS_NUM, 0,0, (6 > COLS_NUM ? COLS_NUM : 6), 
		0,0,0,0,0,0, alistN, NULL, mpr_pe_cols 
	};
	Wmenu pm = {
		N_(" |I|n profile "),0, M_COLORIN | M_STILLV | M_NOTOUT | M_OPEN | M_BORDER | M_TITLE, 
		0,0,0,0,0,0,0,0,0,0, alistN, (void *) &pedit, mpr_pe_prof, 
	};
	Winput p_name = { N_("P|r|ofile name: "),0, pname, 0,0,0, PROF_NAME_SIZE };
	Widget w[] = {
		{ TRUE, Y(4),  X(16), sel_prof.scr_max, 15,   menu_fn,   (void *) &sel_prof,Wf_DEFAULT },
		{ TRUE, Y(3),  X(2),  0, PROF_NAME_SIZE+14,   input_fn,  (void *) &p_name,  Wf_DEFAULT | Wf_TYPE_INPUT },
		{ TRUE, Y(6),  X(2),  cm.scr_max, 15,         menu_fn,   (void *) &cm,	    Wf_DEFAULT },
		{ TRUE, Y(6),  X(32), 0, 15, menu_fn,   (void *) &pm,   	            Wf_DEFAULT },
		{ TRUE, Y(16), X(3),  0, 6,  button_fn, (void *) &def_button[_BUTT_NEW],    Wf_DEFAULT },
		{ TRUE, Y(16), X(14), 0, 5,  button_fn, (void *) &def_button[_BUTT_OK],     Wf_DEFAULT },
		{ TRUE, Y(16), X(24), 0, 7,  button_fn, (void *) &def_button[_BUTT_SAVE],   Wf_DEFAULT },
		{ TRUE, Y(16), X(36), 0, 9,  button_fn, (void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },
		W_NULL
	};
	SessW	s = { 7, 1, FALSE, w, K_STAY, bgr_pe, 0 };	

	_D( " wins_profedit() ");
	
	init_sessw(&s);	
	
	s_cols = get_sort_cols();
	
	aca_border (y, y+yn, x, x+xn, BLACK_WHITE); 
	bold; aca_c(YELLOW_WHITE); 
	mvaddstr( Y(0), X(xn/2-8), _(" Profile editor "));

	cpy_actprof(&pedit, &conf_P.act_profile);
	pm.item_max 	= pedit.col_num;
	pm.scr_max	= pedit.col_num > 6 ? 6 : pedit.col_num;
 	
	strncpy(pname, conf_P.name[ (p_selected = conf_P.current) ], PROF_NAME_SIZE);
	p_name.a_size =	p_name.poz = strlen(pname);
	s.key = K_STAY;
	
	W_redraw_session(&s);
	
	do {
		aca_c(BLACK_WHITE); CLEAN_HLINE(Y(14), X(2), X(xn-2));
	
		re = 0;
		re = run_act_widget(&s);
	     
	     	W_key_to_widgets(&s);		
		W_default_go(&s);
	     
	     /* Change profile */	
		if (s.actual == 0 && Wr_MENU_PRESS) {
			strncpy(pname, conf_P.name[(p_selected = sel_prof.item_act)], PROF_NAME_SIZE);
			p_name.a_size =	p_name.poz = strlen(pname);
			load_profile( conf_P.name[p_selected], &pedit);
			ACA_RESET_MENU((&pm))
			pm.item_max 	= pedit.col_num;
			pm.scr_max	= pedit.col_num > 6 ? 6 : pedit.col_num;
		}	
	     /* Add cols */	
		if (s.actual == 2 && s.key == KEY_F(5) && pm.item_max < COLS_NUM) { 
			pedit.cols[++pedit.col_num] = s_cols[cm.item_act];
			++pm.item_max;
			pm.scr_max	= pm.item_max > 6 ? 6 : pm.item_max;
			re |= Wr_NEED_REDRAW;
		}
	    /* Delete cols */
	    	if (s.actual == 3 && s.key == KEY_F(8) && pm.item_max >= 0) { 
	    		--pedit.col_num;
	    		for(i=pm.item_act; i<=pedit.col_num; i++)
	    			pedit.cols[i] = pedit.cols[i+1];
	    		pm.item_max 	= pedit.col_num;	
	    		pm.scr_max	= pm.item_max > 6 ? 6 : pm.item_max;
	    		decrease_item(&pm);
	    		re |= Wr_NEED_REDRAW;	
	    	}	
	     /* New profile */
		if ((re & Wr_BUTTON_PRESS) && s.actual == 4)  {
			strcpy(pname, _("--new--"));
			p_selected = NEW_PROFILE;
			p_name.a_size =	p_name.poz = strlen(_("--new--"));
			ACA_RESET_MENU((&pm))
			pm.item_max = pm.scr_max = pedit.col_num = -1;
			re |= Wr_NEED_REDRAW;	
			set_widget(w, &s, 1);
		}	     			
		
		if (re & Wr_NEED_REDRAW) 
			W_redraw_session(&s);
		
		if (s.actual == 2 || s.actual == 3) {
			aca_c(BLACK_WHITE); 
			mvaddch(Y(14), X(2), ACA_RARROW);
			mvprintw(Y(14), X(4), "%.44s", 
				_(kc[(s.actual==2 ? s_cols[cm.item_act] : 
				pedit.cols[pm.item_act])].descript));
		}

	     /* Ok & Save */
		if ((re & Wr_BUTTON_PRESS) && (s.actual == 5 || s.actual == 6)) {
			if (p_selected == NEW_PROFILE)
				p_selected = add_profile(pname);
			else
				rename_profile(p_selected, pname);
			cpy_actprof(&conf_P.act_profile, &pedit);
			conf_P.current = p_selected;
			write_profile(pname, &pedit);
			reset_menu();
			if (s.actual==5) return TRUE;
			else {
				sel_prof.item_max = conf_P.num;
				sel_prof.scr_max  = (5 > conf_P.num ? conf_P.num : 5); 
				init_layout();
			}
		}
	     /* Cancel */
		if ((re & Wr_BUTTON_PRESS) && s.actual == 7) 
			break;
	} while((s.key = get_k()) != KEY_F(10)); 		
	
	return FALSE;			
}
	
int wins_profdel(kim_DATA *d)
{
	int	y=LINES/2-6, x=COLS/2-20, yn=13, xn=41, re;
	Wmenu prof = {
		N_(" |P|rofile "),0, M_COLORIN | M_BORDER | M_OPEN | M_STILLV | M_TITLE, 
		conf_P.num, 0,0, (8 > conf_P.num ? conf_P.num : 8), 
		0,0,0,0,0,0, alistN, NULL, mpr_pe_sel 
	};
	Widget w[] = {
		{ TRUE, Y(3), X(2), prof.scr_max, 20, menu_fn,  (void *) &prof,          Wf_DEFAULT },
		{ TRUE, Y(4), X(26), 0, 5, button_fn,(void *) &def_button[_BUTT_OK],     Wf_DEFAULT },
		{ TRUE, Y(6), X(26), 0, 9, button_fn,(void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },
		W_NULL
	};
	SessW	s = { 2, 0, FALSE, w, K_STAY, NULL, Sf_HAVENT_BGR };	

	_D( " wins_profdel() ");
	init_sessw(&s);	
	
	aca_border (y, y+yn, x, x+xn, BLACK_WHITE); 
	CLEAN_BOX (Y(1), Y(yn-1), X(1), X(xn-1));
	bold; aca_c(YELLOW_WHITE); 
	mvaddstr( Y(0), X(xn/2-8), _(" Delete profile "));
	
	W_redraw_session(&s);
	
	do {
		re = 0;
		re = run_act_widget(&s);
		
		W_key_to_widgets(&s);		
		W_default_go(&s);
	     /* Ok */
		if ((re & Wr_BUTTON_PRESS) && s.actual == 1) {
			del_prof(prof.item_act);
			reset_menu();
			return TRUE;
		}
	     /* Cancel */
		if ((re & Wr_BUTTON_PRESS) && s.actual == 2) 
			break;
	} while((s.key = get_k()) != KEY_F(10)); 		
	return FALSE;					
}


/* --------------------------- KIM CONFIGURE ------------------------------- */


static void pre_infoline(int *p)
{
	*p = 0;
	
	_D( " pre_infoline()");
	
	switch(conf_L.infoline) {
		case _I_CMDLINE:
			set_bit(p, 0, 1);
			break;
		case _I_MEM:
			set_bit(p, 1, 1);
			break;
		case _I_UPTIME:
			set_bit(p, 2, 1);
			break;			
	}
}


int wins_config()
{
	int	y=LINES/2-7, x=COLS/2-23, yn=14, xn=47, re,
		infoline=0;
	kim_LAYOUT	layout;	
	Wradio	r[] =  { 
		{ N_("Command |l|ine   "), 0,0, &infoline, B_DEPEND, 0  },
		{ N_("System |m|emory  "), 0,0, &infoline, B_DEPEND, 1  },			
		{ N_("System |u|ptime  "), 0,0, &infoline, B_DEPEND, 2  },
		{ N_("|Z|ombie  (red)  "), 0, conf_L.color_zombie       },
		{ N_("|R|unning (green)"), 0, conf_L.color_run 	     	},
		{ N_("|W|ith spec. chararacters (Arrow ..etc)"), 0, conf_L.spec },
		{ N_("Memory in |p|ages"), 0, conf_L.inpage	   	},
		{ N_("|A|uto save setup"), 0, conf_L.save  	   	}
	};
	Widget w[] = {
		{ TRUE, Y(2), X(2),  0, 0, radio_fn,  (void *) &r[0], Wf_DEFAULT },
		{ TRUE, Y(3), X(2),  0, 0, radio_fn,  (void *) &r[1], Wf_DEFAULT },
		{ TRUE, Y(4), X(2),  0, 0, radio_fn,  (void *) &r[2], Wf_DEFAULT },
		{ TRUE, Y(2), X(25), 0, 0, radio_fn,  (void *) &r[3], Wf_DEFAULT },
		{ TRUE, Y(3), X(25), 0, 0, radio_fn,  (void *) &r[4], Wf_DEFAULT },
		{ TRUE, Y(7), X(2),  0, 0, radio_fn,  (void *) &r[5], Wf_DEFAULT },
		{ TRUE, Y(10),X(2),  0, 0, radio_fn,  (void *) &r[6], Wf_DEFAULT },
		{ TRUE, Y(11),X(2),  0, 0, radio_fn,  (void *) &r[7], Wf_DEFAULT },
		{ TRUE, Y(13),X(12), 0, 0, button_fn, (void *) &def_button[_BUTT_OK],     Wf_DEFAULT },
		{ TRUE, Y(13),X(27), 0, 0, button_fn, (void *) &def_button[_BUTT_CANCEL], Wf_DEFAULT },
		W_NULL
	};
	SessW	s = { 9, 0, FALSE, w, K_STAY, NULL, Sf_HAVENT_BGR };	

	_D( " wins_config() ");
	init_sessw(&s);	
	pre_infoline(&infoline);
	cpy_conflayout(&layout, &conf_L);
	
	aca_border (y, y+yn, x, x+xn, BLACK_WHITE); 
	CLEAN_BOX (Y(1), Y(yn-1), X(1), X(xn-1));
	bold; aca_c(YELLOW_WHITE); 
	mvaddstr( Y(0), X(xn/2-7), _(" Kim configure "));
	ubold; aca_c(BLUE_WHITE); 
	mvhline(  Y(1), X(2), ACA_HLINE, 17);
	mvaddstr( Y(1), X(4), _("Infoline"));
	mvhline(  Y(1), X(25), ACA_HLINE, 17);
	mvaddstr( Y(1), X(27), _("Color"));
	mvhline(  Y(6), X(2), ACA_HLINE, 44);
	mvaddstr( Y(6), X(4), _("Display"));
	mvhline(  Y(9), X(2), ACA_HLINE, 44);
	mvaddstr( Y(9), X(4), _("Other"));
	
	W_redraw_session(&s);
	
	do {
		re = 0;
		re = run_act_widget(&s);
		
		if (re & Wr_RADIO_DEPEND) {
			if      (show_bit(infoline, 0)) layout.infoline = _I_CMDLINE;
			else if (show_bit(infoline, 1)) layout.infoline = _I_MEM;
			else if (show_bit(infoline, 2)) layout.infoline = _I_UPTIME;
			W_redraw_session(&s);	
		}
		if (s.actual == 3) {	layout.color_zombie 	= r[3].set; }
		if (s.actual == 4) {	layout.color_run 	= r[4].set; }
		if (s.actual == 5) {	aca.spec = layout.spec	= r[5].set; }
		if (s.actual == 6) {	layout.inpage 		= r[6].set; }		
		if (s.actual == 7) {	layout.save 		= r[7].set; }
		
		W_key_to_widgets(&s);		
		W_default_go(&s);
		
	     /* Ok */
		if ((re & Wr_BUTTON_PRESS) && s.actual == 8) {
			cpy_conflayout(&conf_L, &layout);
			INI_set_flag(_S_LAYOUT, TRUE);
			return TRUE;
		}
	     /* Cancel */
		if ((re & Wr_BUTTON_PRESS) && s.actual == 9) 
			break;
	} while((s.key = get_k()) != KEY_F(10)); 		
	return FALSE;					
}
