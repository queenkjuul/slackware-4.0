

#ifndef __ACA_H
#define __ACA_H

#include <curses.h>

#if !(defined(TRUE) && defined(FALSE))
	#define TRUE	1
	#define FALSE	0
#endif	

#define	RE_ERROR	-1
#define RE_OK		0

#define chN		((char *) 	NULL)
#define inN		((int  *) 	NULL)
#define voN		((void *) 	NULL)

#ifndef _
	#define	_(str)	gettext(str)
	#define N_(str)	(str)
#endif

#include <libintl.h>


typedef struct {
	int	color,			/* TRUE / FALSE */
		output_7bit_only, 	/* if TRUE: ACA support only 7bit ascii */
		input_8bit,		/* if FALSE: ACA set curses meta() */
	
	/* aca timer (all is in milliseconds) */
		getch_timeout, 		/* select() timeval or curses timeout */
		fallasleep,		/* elapsed time to go to asleep */
		fallasleep_incr,	/* fall asleep deepen and deepen 
					   (this is increment of deep) */
					   
	/* after timeout elpse ACA call your func. (if this func. is set) */					   
		extra_timeout_call; 			/* TRUE / FALSE */
	void	(*extra_timeout_call_fn)(int x);	/* your func. 
							  'x' is curren timeout */
	
	int	line,		/* TRUE (usage standard line) or FALSE ( '-' '|' '+')  */		
		keypad,		/* TRUE / FALSE - usage termcap/curses */	
		spec,		/* TRUE / FALSE - special characters (as a arrow) */
		forcekey;	
#ifdef HAVE_MOUSE
	int	mouse,		/* TRUE / FALSE	*/	
		mouse_y,	/* mouse line */
		mouse_x;	/* mouse col */
#endif

} ACA;

extern ACA	aca;

#if DEBUG==1
	#define	_D(x)	fprintf(stderr, "DEBUG: %s\n", x)
#else
	#define	_D(x)
#endif
	
#endif /* __ACA_H */