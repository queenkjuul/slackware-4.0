
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include "aca.h"
#include "aca_draw.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

int		GL_lin, 
		GL_col;

aca_COLORS	*GL_c;
TemplateColor	*TplC;

char		*GL_ll_bold,
		*GL_ll_out;

inline void aca_c(int x)
{
	if (!aca.color) attroff(A_REVERSE); 
	
	attron  ((aca.color ? (*(GL_c+x)).color : (*(GL_c+x)).bw));
}

TemplateColor *set_TplC( TemplateColor *t)
{
	return (TplC = t);
}

void draw_linebox(int l, int l_max, int c, int c_max, int color)
{
	register int i;
	
	_D( " draw_linebox() ");
	
	aca_c(color);
	
	for(i=c; i<=c_max; i++) {
		mvaddch(l,	i,	 ACA_HLINE);
		mvaddch(l_max,	i,	 ACA_HLINE);	
	}
	for(i=l+1; i<l_max; i++) {
		mvaddch(i,	c,	 ACA_VLINE);
		mvaddch(i,	c_max,	 ACA_VLINE);	
	}	 
	mvaddch(l,	c,	 ACA_ULCORNER);	
	mvaddch(l,	c_max,	 ACA_URCORNER);
	mvaddch(l_max,	c,	 ACA_LLCORNER);	
	mvaddch(l_max,	c_max,	 ACA_LRCORNER);
}

void aca_border(int l, int l_max, int c, int c_max, int color)
{
	register int i;
	
	_D( " draw_linebox() ");
	
	aca_c(color);
	
	if (!aca.color)	{
		if ((*(GL_c+color)).bw != A_REVERSE) bold;
	} else		
		ubold;
	
	for(i=c; i<=c_max; i++) {
		mvaddch(l,	i,	 ACA_HLINE);
		mvaddch(l_max,	i,	 ACA_HLINE);	
	}
	for(i=l+1; i<l_max; i++) {
		mvaddch(i,	c,	 ACA_VLINE);
		mvaddch(i,	c_max,	 ACA_VLINE);	
	}	 
	mvaddch(l,	c,	 ACA_ULCORNER);	
	mvaddch(l,	c_max,	 ACA_URCORNER);
	mvaddch(l_max,	c,	 ACA_LLCORNER);	
	mvaddch(l_max,	c_max,	 ACA_LRCORNER);
	
	if (!aca.color) 
		if ((*(GL_c+color)).bw != A_REVERSE) ubold;
}

void clear_linebox(int l, int l_max, int c, int c_max)
{
	register int i;

	_D( " clean_linebox() ");

	for(i=c; i<=c_max; i++) {
		mvaddch(l,	i,	' ');
		mvaddch(l_max,	i,	' ');	
	}
	for(i=l+1; i<l_max; i++) {
		mvaddch(i,	c,	' ');
		mvaddch(i,	c_max,	' ');	
	}	 
	mvaddch(l,	c,	' ');	
	mvaddch(l,	c_max,	' ');
	mvaddch(l_max,	c,	' ');	
	mvaddch(l_max,	c_max,	' ');
}

/*
	Print string and chars between '|' print bold and with
	acolor.
 */	
void mvaddastr(int l, int c, char *astr, int acolor, int color)
{
  	char		*p, buff[BUFSIZ], *loc;
  	register int	set=FALSE, size=0;

	_D( " mvaddastr()");
  	
  	if (!astr) return;
  	
  	strncpy(buff, astr, BUFSIZ);
	p = buff; 

	if ((loc = strchr(p, '|'))) {
  		do {
  			*loc = '\0';
  			if (set) {
  				aca_c(acolor);
  				bold;
  			} else {
  				ubold;
  				aca_c(color);		
  			}
  			mvaddstr(l, c+size, p);
  			size += strlen(p);
  			set = set ? FALSE : TRUE;
  			p = (++loc);
  			loc = strchr(p, '|');
  		} while(loc);	
  		ubold;
  		aca_c(color);		
  		mvaddstr(l, c+size, p);
  	} else {
  		ubold;
  		aca_c(color);	
  		mvaddstr(l, c, p);
  	}	
}

/*
	Return size of astr (active string).
*/	
int astrlen(char *astr)
{
  	register int	size=0;
	char 		*loc;

	_D( " astrlen()");
	
	if (!astr) return FALSE;

	if (!(size = strlen(astr))) 
		return size;
	loc = astr;
	while ((loc=strchr(loc, '|'))) {
		--size;
		++loc;
	}	
	return size;	  	
}

/*
	Return first active char in astr (in widgets used as hotkey).
	- all hotkeys is lower characters.
 */
int gethotkey(char *astr)	
{
	char	*loc;
	
	_D(" gethotkey()");
	
	if (!astr) return FALSE;
	
	if (!(loc = strchr(astr, '|')))
		return FALSE;
	else 
		return tolower(*(++loc));	
}

void center_addnstr(int y, int x, char *str, int max) /* 'x' is line center */
{
	int	a=0, b, half=0;
	char	*p, *h;
	
	_D(" center_addnstr()");
	
	for (p = str, half=0; *p != '\0'; p++, half++) 	
		if (*p == '\n') break;	
	if (half > max) half = max;
	half/=2; ++half; 
	for (p=str, b=0; *p != '\0'; b++, p++) {
		if (*p == '\n') {
			++a; b=-1; 
			for (h=p+1, half=1; *h != '\0'; h++, half++) {	
				if (*h == '\n') break;
			}
			if (half > max) half = max;		
			half/=2; ++half;
			continue;
		}
		/* if (b < max) mvaddch(y+a, x-half+b, *p ); */
		
		if (b < max) mvprintw(y+a, x-half+b, "%c", *p ); 
	} 
}

void left_addnstr(int y, int x, char *str, int maxlines, int max)	
{
	int	a=0, b;
	char	*p;
	
	_D(" left_addnstr()");
	
	for (p=str, b=0; *p != '\0'; b++, p++) {
		if (*p == '\n') {
			if (++a > maxlines) return;
			b=-1;
			continue;
		}
		if (b <= max) mvaddch(y+a, x+b, *p );
	} 
}

inline void mvaddline_nstr (int y, int x, char *str, int line, int max)	
{
	int	a=0, b;
	char	*p;
	
	_D(" mvaddline_nstr()");
	
	for (p=str, b=0; p != '\0'; b++, p++) {
		if (*p == '\t') { b+=8; continue; }	
		if (*p == '\n') {
			if (++a > line) break;
			b=-1;
			continue;
		}
		if (a == line) {
			if (b <= max) mvaddch(y, x+b, *p);
			else break;
		}	
	}	 		
}

chtype **init_refresh_buffer()
{
	int	i;
	chtype	**b;

	_D( " init_refresh_buffer()" );

	if ((b = (chtype **) calloc(LINES+1, sizeof(chtype *))) == NULL) 
		return (chtype **) NULL;
	
	for (i=0; i<=LINES; i++) 
		if ((*(b+i) = (chtype *) calloc(COLS+1, sizeof(chtype))) == NULL) 
			return (chtype **) NULL;			
	return b;
}

void fill_refresh_buffer(chtype **b)
{
	int	y, x;
	
	_D( " fill_refresh_buffer() " );
	
	for(y=0; y<= LINES; y++) 
		for(x=0; x<= COLS; x++)
			*(*(b+y)+x) = mvinch(y, x);
}

void print_refresh_buffer(chtype **b)
{
	int	y, x;
	
	_D( " print_refresh_buffer() " );	
	
	for(y=0; y<= LINES; y++) 
		for(x=0; x<= COLS; x++) {
			attron( *(*(b+y)+x) & A_COLOR);
			mvaddch(y,x, *(*(b+y)+x));
		}	
}

inline void show_run()
{
	int		showch=0;
	static int	last='/';
	
	switch(last) {
		case '|':  showch='/'; break;		
		case '/':  showch='-'; break;
		case '-':  showch='\\'; break;	
		case '\\': showch='|'; break;	
		
	}			
	mvaddch(0, COLS-1, showch);
	last = showch;
	refresh();
}

int aca_init_color(int num)
{
	_D( "aca_init_color()" );

	if ((GL_c = (aca_COLORS *) calloc(num+1, sizeof(aca_COLORS))) == NULL) 
		return FALSE;
		
	return TRUE;
}

void aca_init_pair(int color_num, int fc, int bc, int bw)
{
	_D( "aca_init_pair()");
	
	init_pair(color_num, fc, bc);
	
	GL_c[color_num].color 	= COLOR_PAIR(color_num);
	GL_c[color_num].fc 	= fc;
	GL_c[color_num].bc 	= bc;
	GL_c[color_num].bw 	= bw;		/* black / white mode 	*/
}
