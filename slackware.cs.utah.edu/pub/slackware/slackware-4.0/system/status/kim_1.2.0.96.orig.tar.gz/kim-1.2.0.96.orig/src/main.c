
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h> 


#include <getopt.h>
#include <signal.h>
#include <libintl.h>
#include <locale.h>

#include "kim.h"

#if PROCPS_1_2
	#include <proc/ps.h>
#else
	#include <proc/procps.h>
#endif

#include "util.h"
#include "procdata.h"
#include "procsort.h"
#include "layout.h"
#include "profile.h"

kim_GLOBAL	ks;

TemplateColor	kim_TplC = {

/* --- dialogs color --- */

/* bgr    */	BLACK_WHITE,
/* header */	YELLOW_WHITE,
/* warning */	WHITE_RED,		

/* --- widgets color --- */

/* buttons */	{ BLACK_CYAN, BLACK_WHITE, YELLOW_CYAN, YELLOW_WHITE },
/* radio   */	{ BLACK_CYAN, BLACK_WHITE, YELLOW_CYAN, YELLOW_WHITE },
/* input   */   { BLACK_CYAN, BLACK_CYAN, 0,0,0,0, BLACK_WHITE, BLACK_WHITE, YELLOW_WHITE, YELLOW_WHITE },
/* menu_in */   { MENU_WHITE_BLACK, BLACK_WHITE, 0,0, BLUE_WHITE, BLUE_WHITE, 
		  BLACK_CYAN,  BLUE_WHITE, YELLOW_CYAN, YELLOW_WHITE },  
/* menu_out */  { WHITE_BLACK, BLACK_CYAN, YELLOW_BLACK, YELLOW_CYAN, BLACK_CYAN, 0, 
		  WHITE_BLACK, BLACK_CYAN, YELLOW_BLACK, YELLOW_CYAN },
/*menu_direct*/ { BLACK_CYAN,  WHITE_BLUE, 0,0, WHITE_BLUE, WHITE_BLUE, 
		  GREEN_BLUE,  GREEN_BLUE, GREEN_BLUE, GREEN_BLUE }
		/* note: mpr_list_area() not use this setting */ 
};

static int	color 		= FALSE,
	  	lines 		= FALSE,
	  	your  		= FALSE,
	  	tree  		= FALSE,
	  	forcekey	= FALSE;

static char	*tofile		= chN;
static char	*fromfile 	= chN;
static char	*asciifile	= chN;

/* ini functions 
	- change carefully ! (see in kim.h to enum _INI_SECTION)	
*/
ini_func	kimINI_fn[] = {
	{ "about",	INI_loader_about,	INI_writer_about,	FALSE },
	{ "layout",	INI_loader_layout,	INI_writer_layout,	FALSE },
	{ "profiling",	INI_loader_profiling,	INI_writer_profiling,	FALSE },
	{ chN,		INI_loader_keys, 	INI_writer_keys, 	FALSE },
	{ chN,		0,			0,			FALSE }
};

/* ini struct */
aca_INI		kimINI = { kimINI_fn, chN };

void usage() 
{
	_D(" usage() ");
	      	
   	fprintf(stderr, "\n%s\n%s\n%s%s%s%s%s%s%s%s%s%s%s%s\n",
   		_("[1mThe kim - interactive process manager.[0;10m\n"),
   		_("[1mkim  [options][0;10m\n"),
   		_("[1m-a, --noline	[0;10m use of +, -, | for line drawing\n"),
   		_("[1m-b, --nocolor	[0;10m black & white mode\n"),
   		_("[1m-h, --help	[0;10m this help\n"),
   		_("[1m-k, --force-key	[0;10m force key\n"),
   		_("[1m-t, --tree	[0;10m display in tree mode\n"),
   		_("[1m-v, --version	[0;10m program version\n"),
   		_("[1m-y, --your	[0;10m display your processes only\n"),
   		_("[1m--dir=<path>	[0;10m config directory (default is '$HOME/.kim/')\n"),
   		_("[1m--from=<file>	[0;10m load process information from file\n"),
   		_("[1m--out=<file>	[0;10m output (save) process information to file\n"),
   		_("[1m--ascii=<file>	[0;10m export process information to ascii file\n"),
   		_("[1m--helper=<path>	[0;10m help HTML viewer (default: lynx)\n")
   	);	
}

typedef enum {
	ARG_NOLINE,
	ARG_NOCOLOR,
	ARG_HELP,
	ARG_FORCE_KEY,
	ARG_TREE,
	ARG_VERSION,
	ARG_YOUR,
	ARG_DIR,
	ARG_FROM,
	ARG_OUT,
	ARG_ASCII,
	ARG_HELPER
} KIM_ARGS;

void arg_opt(int argc, char **argv) {
      	int	arg, l_index=0;
      	struct option l_opt[] = {
      		{ "noline",	0, 0, ARG_NOLINE 	},
      		{ "nocolor",	0, 0, ARG_NOCOLOR     	},
      		{ "help",	0, 0, ARG_HELP   	},
      		{ "force-key",	0, 0, ARG_FORCE_KEY  	},
      		{ "tree",	0, 0, ARG_TREE  	},
      		{ "version",	0, 0, ARG_VERSION  	},
      		{ "your",	0, 0, ARG_YOUR  	},
      		{ "out", 	1, 0, ARG_OUT    	},
      		{ "from",	1, 0, ARG_FROM   	},
      		{ "dir",	1, 0, ARG_DIR    	},
      		{ "ascii",	1, 0, ARG_ASCII  	},	
		{ "helper",	1, 0, ARG_HELPER 	}
      	};     	
      	
      	_D(" arg_opt() ");
      	 
	while((arg = getopt_long(argc, argv, "hvbaytk", l_opt, &l_index)) != -1) {
        	switch(arg) {
      		case ARG_OUT:
      			_D("arg: OUT");
      			tofile = strdup(optarg); 
      			ks.interactive = FALSE;
        	    	break;
      		case ARG_FROM:
      			_D("arg: FROM");
         	    	fromfile = strdup(optarg); 
      			break;
      		case ARG_DIR:
      			_D("arg: INI DIR");
      			if (optarg[ strlen(optarg) ] != '/') 	
            	    		sprintf(ks.tmp, "%s/%s", optarg, KIM_INIFILE); 
         	    	else
         	    		sprintf(ks.tmp, "%s%s", optarg, KIM_INIFILE); 
         	    	kimINI.ini_file = strdup(ks.tmp);
        	    	break;
        	case ARG_ASCII:
      			_D("arg: ASCII");
      			asciifile = strdup(optarg); 
      			ks.interactive = FALSE;
        	    	break;
      		case ARG_HELPER:
      			_D("arg: HELPER");
      			ks.helpviewer = strdup(optarg);
      			break; 
      		case ARG_HELP:
      		case 'h':
      			usage();
      			exit(RE_OK);		
      		case ARG_VERSION:	
      		case 'v':
      			fputs("\n[1mThe kim - interactive process manager.[0;10m\n", stdout);
        		printf("\t- kim version: \"%s\"\n",   KIM_VERSION); 
	       		printf("\t- current procps: \"%s\"\n\n", get_procps_version()); 
        		exit(RE_OK);       		
        	case ARG_NOCOLOR:
        	case 'b':   
        	 	color = TRUE;
        	 	break;
        	case ARG_NOLINE:	
        	case 'a':   
        	 	lines = TRUE;
        	 	break;
        	case ARG_TREE: 	
        	case 't':
        		tree = TRUE;
        		break;
        	case ARG_YOUR:	
        	case 'y':
        		your = TRUE;
        		break;	
        	case ARG_FORCE_KEY:	
        	case 'k':
        		forcekey = TRUE;
        		break;		 	
      		}    
	}
}  

void fatal_sig_handler(int sig_num)
{
         _D(" fatal_sig_handler() ");
         
         fprintf(stderr, "\n\nKim fatal error - FATAL SIGNAL: %d\n\n", sig_num); 
         exit(RE_OK);
}
   
void end_sig_handler(int sig_num)
{
	 _D(" end_sig_handler() ");
	
         fprintf(stderr, "\n\nHmm ... Goodbay !\n\n"); 
         exit(RE_OK);
}    

void init_signals() 
{
   	struct sigaction fatal, end;
   	
   	_D(" init_signals() ");
   	
     /* fatal signals */
    	fatal.sa_handler = fatal_sig_handler;
    	fatal.sa_flags   = SA_NODEFER;

//    	sigaction (SIGSEGV, &fatal, NULL);
//    	sigaction (SIGBUS,  &fatal, NULL);
//    	sigaction (SIGFPE,  &fatal, NULL);
    
    /* end signals */
    	end.sa_handler = end_sig_handler;
    	end.sa_flags   = SA_NODEFER;
    
    	sigaction (SIGQUIT, &end, NULL);	
}

void kim_colors()
{
	_D(" kim_colors() ");	
	
	aca_init_color(KIM_COLOR_NUM);

       	/*	       -color-          -foreground-   -background-	-w/b-	*/         	    
       	aca_init_pair( BLACK_WHITE,	COLOR_BLACK,	COLOR_WHITE,	A_NORMAL);
       	aca_init_pair( YELLOW_WHITE, 	COLOR_YELLOW,	COLOR_WHITE,	A_NORMAL);
       	aca_init_pair( BLUE_WHITE,	COLOR_BLUE,	COLOR_WHITE,	A_NORMAL);       	
       	aca_init_pair( GREEN_WHITE,	COLOR_GREEN,	COLOR_WHITE,	A_NORMAL);       	
       	aca_init_pair( BLACK_CYAN,	COLOR_BLACK,	COLOR_CYAN,	A_REVERSE);      
       	aca_init_pair( WHITE_BLUE,	COLOR_WHITE,	COLOR_BLUE,	A_NORMAL);
       	aca_init_pair( WHITE_RED,	COLOR_WHITE,	COLOR_RED,	A_REVERSE);    
       	aca_init_pair( YELLOW_RED,	COLOR_YELLOW,	COLOR_RED,	A_NORMAL);           	
       	aca_init_pair( WHITE_CYAN,	COLOR_WHITE,	COLOR_CYAN,	A_NORMAL);
       	aca_init_pair( WHITE_BLACK,	COLOR_WHITE,	COLOR_BLACK,	A_NORMAL);
       	aca_init_pair( MENU_WHITE_BLACK,COLOR_WHITE,	COLOR_BLACK,	A_REVERSE);
       	aca_init_pair( YELLOW_BLUE,	COLOR_YELLOW,	COLOR_BLUE,	A_NORMAL);
       	aca_init_pair( YELLOW_CYAN,	COLOR_YELLOW,	COLOR_CYAN,	A_REVERSE);
      	aca_init_pair( YELLOW_BLACK, 	COLOR_YELLOW,	COLOR_BLACK,	A_NORMAL);  
       	aca_init_pair( RED_BLACK,	COLOR_RED,	COLOR_BLACK,	A_NORMAL);  
       	aca_init_pair( RED_BLUE,	COLOR_RED,	COLOR_BLUE,	A_NORMAL);  
      	aca_init_pair( RED_CYAN,	COLOR_RED,	COLOR_CYAN,	A_NORMAL);           
      	aca_init_pair( ZOMBIE_RED_CYAN,	COLOR_RED,	COLOR_CYAN,	A_REVERSE);                 	
       	aca_init_pair( GREEN_BLUE,	COLOR_GREEN,	COLOR_BLUE,	A_NORMAL);  
       	aca_init_pair( GREEN_CYAN,	COLOR_GREEN,	COLOR_CYAN,	A_NORMAL);
       	aca_init_pair( RUN_GREEN_CYAN,	COLOR_GREEN,	COLOR_CYAN,	A_REVERSE);       	
       	aca_init_pair( MAGENTA_BLUE, 	COLOR_MAGENTA,	COLOR_BLUE,	A_NORMAL);       	
       	aca_init_pair( BLUE_CYAN, 	COLOR_BLUE,	COLOR_CYAN,	A_REVERSE);       	
       	aca_init_pair( RED_WHITE, 	COLOR_RED,	COLOR_WHITE,	A_NORMAL);       	

	set_TplC(&kim_TplC);	
}

  
int main(int argc, char **argv)
{
      	kim_DATA	*k = (kim_DATA *) NULL;
      	
      	_D("\nRUNNING WITH DEBUG (output to stderr) !!!\n");
      	_D(" main() ");
      	
      	/* Not using LC_ALL - scanf() has problem with LC_NUMERIC (num. separator) */
      				 
      	setlocale (LC_CTYPE, "");
      	setlocale (LC_TIME, "");
    	setlocale (LC_MESSAGES, "");
    	textdomain (KIM_NAME);
      	
      	ks.interactive	= TRUE;
      	ks.libdir	= KIM_LIBDIR;
	ks.helpviewer	= KIM_HELP_VIEWER;
	sprintf(ks.current_dir, "%s/", getenv("HOME"));
      	kimINI.ini_file	= chN;
      	kimINI.ini_fn[_S_TERM].section = termname();
      	
      	_D("INIT SIGNALS HANDLERS");
      	init_signals();
      	
      	_D("READING ARG.");
      	arg_opt(argc, argv);
		
	if (ks.interactive) {
		_D("MAKING INTERACTIVE SETTINGS");
		if (!kimINI.ini_file) {
			sprintf(ks.tmp, "%s/%s%s", getenv("HOME"), KIM_INIDIR, KIM_INIFILE);   
		      	kimINI.ini_file = strdup(ks.tmp);
			check_ini_file(kimINI.ini_file);
		}
		INI_set_current(&kimINI);
		_D("INIT ACA");
		init_aca();
		aca.forcekey		= forcekey;
		if (color)	
			aca.color 	= FALSE;
		kim_colors();
		if (lines) aca.line  = FALSE;
		if (!INI_load(&kimINI)) {
			_D(" ERROR LOADING 'INI' ");
			exit(RE_ERROR);
		}
	}

      	_D("OPEN psdb AND ALLOCATE kim_DATA STRUCT");

#if PROCPS_1_2
      	if (open_psdb())
#else
      	if (open_psdb(NULL))   
#endif
      		atexit(close_psdb);
      	
      	k = kimdata_malloc();     
      	
      	if (fromfile) { 
      		_D("LOADING FROM FILE");
      		k->file = fromfile;
      		if (proc_from_file(k) == RE_ERROR) 
      			exit(RE_ERROR);
      	} else {
      		_D("LOADING FROM PROC");
      		if (proc_from_proc(k) == RE_ERROR) 
      			exit(RE_ERROR);
      	}	
      	if (tofile) {
      		_D("SAVING TO FILE");
      		save_proc_to_file(tofile, k);
      	} 
      	if (asciifile) {
      		_D("EXPORT TO ASCII");
      		export_to_ascii(asciifile, k);
      	}
      	if (!tofile && !asciifile) {	
      		_D("RUNNING INTERACTIVE INTERFACE");
      		init_keys();
      		if (!set_default_profile())
      			exit(RE_ERROR);
      		k->sort_cols = conf_L.sort_cols;
      		prepare_view( your ? VIEW_YOUR : conf_L.view, 
      			      tree ? (your ? SORT_NATURALLY: SORT_TREE) : 
      			      	     (your ? SORT_NATURALLY : conf_L.sort), k); 	
      		
      		kim_interface( add_kdata(k) );
      	}	
	exit(RE_ERROR);
}

       
