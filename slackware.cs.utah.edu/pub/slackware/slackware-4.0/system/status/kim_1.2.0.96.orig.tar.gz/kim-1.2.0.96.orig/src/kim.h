
#ifndef __KIM_H
#define __KIM_H

#include "config.h"

#define PROCPS_1_2	(PROCPS_VERSION_MAJOR == 1 && PROCPS_VERSION_MINOR == 2)
#define PROCPS_2_0	(PROCPS_VERSION_MAJOR == 2 && PROCPS_VERSION_MINOR == 0)

#ifndef NOT_HAVE_ACA
	#include "../libaca/libaca.h"
#endif

#ifndef _
	#define	_(str)	gettext(str)
	#define N_(str)	(str)
#endif

#include <libintl.h>

#define TMP_SIZE	1024 

/* -----  Kim internal struct ----- */

typedef struct {
	char	tmp[TMP_SIZE+1],	/* global tmp */
		out_buff[BUFSIZ+1],	/* global output buffer */
		*libdir,		/* kim's lib dir (default: /var/lib/kim) */
		*helpviewer,		/* (default: lynx) */
		current_dir[BUFSIZ];	/* current work dir */
	int	interactive;		/* TRUE / FALSE */
} kim_GLOBAL;

extern kim_GLOBAL	ks;
extern aca_INI		kimINI;

typedef enum {
	_S_ABOUT,
	_S_LAYOUT,
	_S_PROFILING,
	_S_TERM
} _INI_SECTION;

#define ERROR_ALLOC	fputs(_("kim: FALTAL ERROR: Can't allocate memory.\n"), stderr)

/* ------------ COLORS ----------- */

typedef enum {
	_dummy_color,
/* color */	
	BLACK_WHITE,
	YELLOW_WHITE,
	BLUE_WHITE,
	GREEN_WHITE,
	WHITE_CYAN,
	BLACK_CYAN,
	YELLOW_CYAN,
	RED_CYAN,
	ZOMBIE_RED_CYAN,
	GREEN_CYAN,
	RUN_GREEN_CYAN,
	WHITE_RED,
	YELLOW_RED,
	WHITE_BLACK,
	MENU_WHITE_BLACK,
	YELLOW_BLACK,
	RED_BLACK,
	WHITE_BLUE,
	YELLOW_BLUE,
	RED_BLUE,
	GREEN_BLUE,
	MAGENTA_BLUE,	
	BLUE_CYAN,
	RED_WHITE,
/* last */
	KIM_COLOR_NUM	
} _kim_color;


#endif /* __KIM_H */