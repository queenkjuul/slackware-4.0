#ifndef __ACA_MOUSES_H
#define __ACA_MOUSES_H

#ifdef HAVE_MOUSE

extern int	init_mouse();
extern int	aca_Gpm_Wgetch(WINDOW *win);

#endif /* HAVE_MOUSE */
#endif /* __ACA_MOUSES_H */