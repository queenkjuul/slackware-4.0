
#ifndef __PROCSORT_H
#define __PROCSORT_H

typedef enum {
	SORT_NATURALLY,
	SORT_TREE,
	SORT_DATA_ASC,	
	SORT_DATA_DESC			
} _SORT;

typedef enum {
	VIEW_ALL,
	VIEW_YOUR,
	VIEW_USER
} _VIEW;

extern kim_DATA		*sorted_d;

extern int 		sort_proc_tab(int sort, kim_DATA *d);
extern inline int 	sort_data(int *a, int *b);
extern int 		prepare_view(int view, int sort, kim_DATA *d); 

#define TREE_END	1

extern void	init_tree();	
extern void	set_flags();

extern int	kim_search(kim_DATA *d, char *str);

#endif /* procsort.h */