
#ifndef __LAYOUT_H
#define __LAYOUT_H

typedef struct {
	/* in ini file */
	int	color_zombie,
		color_run,
		spec,
		save,
		sort,
		sort_cols,
		view,
		inpage,
		infoline;
} kim_LAYOUT;

extern kim_LAYOUT	conf_L;

typedef enum {
		_I_CMDLINE,
		_I_UPTIME,
		_I_MEM
} _INFOLINE;

extern int	INI_writer_layout(FILE *f);
extern int	INI_loader_layout(FILE *f, int flag);
extern kim_LAYOUT *cpy_conflayout(kim_LAYOUT *dest, kim_LAYOUT *src);


/* num of first 'kim_bar' in 'kim_w' */
#define	FIRST_BAR	1

extern void	kim_bgr( SessW *s );
extern void	init_kim_bar(kim_DATA *d); 
extern void	kim_interface(kim_DATA *d);
extern void	reset_menu();
extern void	set_L_d(kim_DATA *d);
extern void 	init_layout();
extern void 	bar_action(SessW *s, kim_DATA *d);
extern void 	print_report( kim_DATA *d);
extern void 	print_infoline( kim_DATA *d);
extern void	set_report_buff(char *str);


#define HELP_LINE(s)	{			\
	aca_c(WHITE_BLACK);			\
	bold;					\
	mvaddstr(LINES-2, 1, "HELP: ");		\
	mvaddnstr(LINES-2, 7, s, COLS-8);	\
	ubold;					\
}

#define CLEAN_HELP	{ aca_c(WHITE_BLACK); CLEAN_HLINE( LINES-2, 0, COLS); }

#endif /* __LAYOUT_H */
