
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <curses.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>

#include "aca_dlg.h"

#ifdef HAVE_MOUSE
	#include "aca_mouse.h"
#endif

#include "aca.h"
#include "aca_util.h"
#include "aca_key.h"

ACA	aca;

int	GL_winch_flag		= FALSE,
	GL_interrupt_flag	= FALSE;

#ifdef CAN_RESIZE
	static void winch_handler();
#endif

static void interrupt_handler(int dummy);

void end_aca()
{
	erase();
	refresh();
	endwin();	
}

#ifdef CAN_RESIZE
void init_winch()
{
	struct sigaction act, oldact;	

	act.sa_handler	= winch_handler;
	sigemptyset (&act.sa_mask);
	act.sa_flags = 0;
   #ifdef SA_RESTART
        act.sa_flags |= SA_RESTART;
   #endif
	sigaction(SIGWINCH, &act, &oldact);	
}
#endif		

void init_aca()
{
	struct sigaction act, oldact;	

	_D( "init_aca()" );

	initscr();
	atexit((void *) end_aca);
	start_color();
	cbreak();
	noecho();
	curs_set(0);
	aca.line	= TRUE;
	aca.forcekey	= FALSE;
	aca.color	= has_colors();
	meta(stdscr, TRUE);
	GL_term_name	= termname();
	
#ifdef CAN_RESIZE
	init_winch();
#endif
#ifdef HAVE_MOUSE
	init_mouse();
#endif
	act.sa_handler	= interrupt_handler;
	act.sa_flags	= 0;
	sigaction(SIGINT, &act, &oldact);		

	aca.getch_timeout	= 80;
	aca.fallasleep		= 0;
	aca.fallasleep_incr	= 0;
	aca.extra_timeout_call	= FALSE;
}

void set_inout_bits (int output_7bit_only, int input_8bit)
{
	aca.output_7bit_only	=  output_7bit_only;
	aca.input_8bit 		=  input_8bit;
	if (aca.input_8bit)	meta(stdscr, TRUE);
	else			meta(stdscr, FALSE);
}

void cur_pre_exec()
{
	reset_shell_mode ();
 	keypad (stdscr, FALSE);
 	endwin ();
}

void cur_post_exec()
{
	reset_prog_mode ();
 	doupdate();
 	aca_keypad (aca.keypad);
 	curs_set(0);
}


#ifdef CAN_RESIZE

void screen_resizer()
{
	struct winsize size;
	size.ws_row = size.ws_col = 0;
	
	mvaddstr(LINES-2, COLS-5, " ");	
	
	ioctl(0, TIOCGWINSZ, &size); 
	if (size.ws_row && size.ws_col) {
		LINES	= size.ws_row;
		COLS	= size.ws_col;	
		resizeterm(size.ws_row, size.ws_col);
		clearok(stdscr,TRUE);
	}
	touchwin(stdscr); 
	refresh();
	mvaddstr(LINES-2, COLS-5, "X");
}

static void winch_handler(int dummy)
{
	GL_winch_flag	= TRUE;
}

#endif

static void interrupt_handler(int dummy)
{
	GL_interrupt_flag = TRUE;
}

FILE *aca_fileopen(char *filename, char *mode, int errors)
{
	FILE	*new;
	if ((new = fopen(filename, mode)) == NULL) {
		if (errors) 
			ErrorOpen(filename);
		return (FILE *) NULL;
	} 
	return new;
}

char *aca_loadfile(int fd, int flag)
{
	int		size=0, i;
	char		*fbuff, dummy[10];
	struct stat	st;
	FILE		*f;
	
	if (fstat(fd, &st) < 0) {
		return (char *) NULL;
	}
	size = st.st_size;
	
	/* Hmm.. example in /proc is st.st_size = 0, 
		try load to memory hardly.. */ 
	if (!size) {
		if ((f = fdopen(fd, "r")) == NULL) return (char *) NULL;
		/* go to end-of-file (very stupid) - needful for /proc/... */ 
		do {
			i = fread(dummy, sizeof(char), 10, f);
			size += i;
		} while(i > 0);
		rewind(f);
		if (!size) return (char *) NULL;
		if ((fbuff = (char *) calloc(size+2, sizeof(char))) == NULL) 
			return (char *) NULL;
		fread((void *) fbuff, size, sizeof(char), f);	
		fbuff[size] = '\0';	
		flag = READ_LOAD;
		fclose(f);
	} else {
		fbuff= (char *) mmap(0, size, PROT_READ, MAP_SHARED, fd, 0); 
		flag = MMAP_LOAD;
	}
	return fbuff;
}

void aca_unloadfile(char *fbuff, int flag)
{
	if (flag == READ_LOAD)
		free((void *) fbuff);
	if (flag == MMAP_LOAD)
		munmap(0, strlen(fbuff));
}

int lines_instr(char *str)
{
	int	a=0;
	char	*p;
	
	for (p = str; *p != '\0'; p++) 	
		if (*p == '\n') ++a;
	return a-1;
}

/* ------ aca INI part ------ */

static aca_INI	*current_ini;

void INI_set_current(aca_INI *ai)
{
	_D(" INI_set_current()");
	current_ini = ai;
}

static char* INI_get_section(FILE *f, char *buff)
{
	int	c, last=0;
	char	*loc;
	
	_D(" INI_get_section()");
	
	buff[0] = '\0';
	while(1) {
		while (!feof(f)) {
			c=getc(f);
			if (c=='[' && last=='\n') break;
			last = c;
		}	
		if (feof(f)) 
			return NULL;
		fgets(buff, 256, f);
		if ((c = strlen(buff)) < 3)
			continue;
		if (!(loc=strchr(buff, ']')))
			continue;	
		if (*(loc+1) != '\n')
			continue;
		else	
			*loc = '\0';
		return buff;
	}	
}

static void INI_cpy_section(FILE *f_old, FILE *f_new)
{
	int	c, last=0;
	
	_D(" INI_cpy_section()");
	
	while (!feof(f_old)) {
		c=getc(f_old);
		if (c=='\n' && last=='\n') { 
			ungetc(c, f_old);
			break;
		}
		last = c;
		if (!feof(f_old))
			fputc(c, f_new);
	}
}

int INI_goto_section(FILE *f, char *section)
{
	char	buff[256];
	
	_D(" INI_goto_section()");
	
	rewind(f);
	while(!feof(f)) {
		if (INI_get_section(f, buff)) {
			if (!strncmp(buff, section, 255))
				return TRUE;
		}
	}		
	return FALSE;	 	
}

ini_func *INI_isneed_save(aca_INI *ai, char *section)
{
	ini_func	*p;
	
	_D(" INI_isneed_save()");
	_D(section);
	
	for (p=ai->ini_fn; p->section != NULL; p++) {
		if (!strcmp(p->section, section)) {
			if (p->flag)
				return p;
			else
				return (ini_func *) NULL;	
		}
	}
	return (ini_func *) NULL;	
}

int INI_load(aca_INI *ai) 
{
	ini_func	*p;
	FILE		*f;
	
	_D( " INI_load()");
	
	if ((f = aca_fileopen(ai->ini_file, "r", 1)) == NULL)
		return FALSE;
	
	for (p=ai->ini_fn; p->section != NULL; p++) {
		if (!INI_goto_section(f, p->section)) 
			p->loader(f, NOT_SECTION);
		else 		
			p->loader(f, YES_SECTION);
	}
	fclose(f);
	return TRUE;
}

int INI_write(aca_INI *ai)
{
	char		buff[256];
	ini_func	*p_s;
	FILE		*f_old, *f_new;
	
	_D( " INI_write()");
	
	if (!INI_ischange(ai))
		return TRUE;
	
	f_old	= aca_fileopen(ai->ini_file, "r", 1); 
	sprintf(buff, "%s_new", ai->ini_file);
	f_new	= aca_fileopen(buff, "w", 1); 
	fprintf(f_new, "Please, not edit this file manually.\n\n");
	
	for (p_s=current_ini->ini_fn; p_s->section != NULL; p_s++) {
		if(p_s->flag == TRUE) {
		     /* Save new section version */	
			fprintf(f_new, "\n[%s]\n", p_s->section); 
			p_s->writer(f_new);	
		} else {
		     /* Copy old section version */
		        if (INI_goto_section(f_old, p_s->section)) {
				fprintf(f_new, "\n[%s]\n", p_s->section);
				INI_cpy_section(f_old, f_new);
			}	
		}
	}
	
	fclose(f_old);
	fclose(f_new);	
	unlink(ai->ini_file);
	sprintf(buff, "%s_new", ai->ini_file);
	rename(buff, ai->ini_file);
	return TRUE;
}

int INI_need_save(char *section)
{
	ini_func	*p;
	
	_D(" INI_need_save()");
	
	for (p=current_ini->ini_fn; p->section != NULL; p++) {
		if (!strcmp(p->section, section)) {
			p->flag = TRUE;
			return TRUE;
		}
	}
	return FALSE;
}

int INI_set_flag(int i, int flag)
{
	_D(" INI_set_flag()");
	
	return (current_ini->ini_fn[i].flag = flag);
}

int INI_ischange(aca_INI *ai)
{
	ini_func	*p;
	
	_D(" INI_ischange()");
	
	for (p=ai->ini_fn; p->section != NULL; p++) {
		if(p->flag)
			return TRUE;
	}
	return FALSE;
}

int INI_del_section(aca_INI *ai, char *section)
{
	char		buff[256];
	ini_func	*p_s;
	FILE		*f_old, *f_new;
	
	_D( " INI_del_section()");
	
	f_old	= aca_fileopen(ai->ini_file, "r", 1); 
	sprintf(buff, "%s_new", ai->ini_file);
	f_new	= aca_fileopen(buff, "w", 1); 
	fprintf(f_new, "Please, not edit this file manually.\n\n");
	
	for (p_s=current_ini->ini_fn; p_s->section != NULL; p_s++) {
		if (INI_get_section(f_old, buff)) {
			if (!strncmp(buff, section, 255))
				continue;
			else {
				fprintf(f_new, "\n[%s]\n", buff);
				INI_cpy_section(f_old, f_new);
			}
		}
	}	
	fclose(f_old);
	fclose(f_new);	
	unlink(ai->ini_file);
	sprintf(buff, "%s_new", ai->ini_file);
	rename(buff, ai->ini_file);
	return TRUE;
}

char *separe_str(char *buff, int sep)
{
	char	*y, *p;
	
	if ((y = strchr(buff, sep)) == NULL) 
		return (char *) NULL;
	*y = '\0';
	++y;
	if ((p = strchr(y, '\n')) != NULL) 
		*p = '\0';
	return strdup(y);
}


/* 
	(U)Set in unsigned (b) bit (n) to 0 or 1 
*/  
   void set_bit(unsigned int *b, int n, int set)
   {
      unsigned int bit_field[] = 
      { 
      	0x01,      0x02,      0x04,      0x08,      0x10,      0x20,      0x40,      0x80, 
      	0x0100,    0x0200,    0x0400,    0x0800,    0x1000,    0x2000,    0x4000,    0x8000,
      	0x010000,  0x020000,  0x040000,  0x080000,  0x100000,  0x100000,  0x400000,  0x800000,  
      	0x01000000,0x02000000,0x04000000,0x08000000,0x10000000,0x10000000,0x40000000,0x80000000  
      };
      if (set == 1) *b |= bit_field[n]; 
      else *b ^= bit_field[n]; 
   }


/* Show (n) bit in (x) */
   int show_bit(int unsigned x, int unsigned n) 
   {
      if (n >= sizeof(x) * KIM_BITNUM) 
         return(RE_ERROR);   
      else
         return((x >> n) & CLEAN_BIT);
   }
