
#ifndef __UTIL_H
#define __UTIL_H

extern void	wait_time(int t);

extern char	*get_procps_version();
extern int	check_kim_version(char *ver);
extern void	fprintf_kim_version(FILE *f);
extern char	*fscanf_kim_version(FILE *f, char *ver);
extern int	check_procps_version(char *ver);
extern void	fprintf_procps_version(FILE *f);
extern char	*fscanf_procps_version(FILE *f, char *ver);
extern int	INI_loader_about(FILE *f, int flag);
extern int	INI_writer_about(FILE *f);
extern char	*strrepchr(char *buff, int old, int new);
extern void	check_ini_file(char *ini);

extern int	kim_exec(char **argv);
extern int	kim_help(); 

extern int	killer(int pid, int sig, char *name, char *error);

#endif /* __UTIL_H */
