
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "kim.h"
#include "util.h"
#include "procdata.h"
#include "proccols.h"
#include "procsort.h"
#include "profile.h"
#include "layout.h"

kim_DATA	*sorted_d;

/* ----- Tree part ----- */

/* tree values */
int	t_line;		
int	t_cols;


static void set_tree_width(kim_DATA *d, int i)
{
	int	a = strlen( d->pt[i]->cmd );
	
	a = a < kc[_NAME].width_max ? a : kc[_NAME].width_max;
	
	if (d->tree_width < d->pd[i].tree_cols*2 + a + 2)
		d->tree_width = d->pd[i].tree_cols*2 + a + 2;	
}


void rec_tree(int pn, kim_DATA *d)		/* recursive */
{
      	int i, last=0;
   
   	show_run();
   
      	for (i=0; i<=d->proc_num; i++) {
      		if (d->pt[pn]->pid == d->pt[i]->ppid) {
            		last = i;
            		d->pd[i].tree_cols = (t_cols < 31) ? ++t_cols : 31;
            		set_tree_width(d, i);
            		d->sort[++t_line] = i;
            		rec_tree(i, d);
            		--t_cols;
         	}
      	}
      	
      	show_run();
      	
      	if (last != 0) {
        	d->pd[last].tree_end = TREE_END;
      	}   
}

void init_tree(kim_DATA *d)	
{
      	int i, last=0;   
      	t_line=0;
      	t_cols=1;
   
      	_D(" init_tree()");	
   
	for (i=0; i<=d->proc_num; i++) {
      /* init only */		
        	if (d->pt[i]->ppid == 0) {		
            		d->pd[i].tree_cols = 0;
            		set_tree_width(d, i);
            		d->sort[0] = i; 
         	}
      /* init's children */
         	if (d->pt[i]->ppid == 1)  {	
            		last = i;
            		d->pd[i].tree_cols = 1;
            		set_tree_width(d, i);
            		d->sort[++t_line] = i; 
            		rec_tree(i, d); 
         	}	
      	}
      	if (last != 0) {
        	d->pd[last].tree_end = TREE_END;
      	}   
      	d->view_num = d->proc_num;
 } 

 void set_flags(kim_DATA *d)
 {
      int i;
      unsigned int flag=0x0;
   
      for(i=0; i<=d->view_num; i++) {
         if (d->pd[ d->sort[i] ].tree_end == TREE_END) {
            if (show_bit(flag, d->pd[ d->sort[i] ].tree_cols ) == 1) 
               set_bit(&flag, d->pd[ d->sort[i] ].tree_cols, 0);
         }
         else 
            set_bit(&flag, d->pd[ d->sort[i] ].tree_cols, 1);
         d->pd[ d->sort[i] ].tree_flag = flag;
      }  
 }


/* ----- sort func. ------ */

void sort_naturally(kim_DATA *d)
{
	proc_t	**p;      
	int	i;
   
	_D(" sort_naturally() ");
      
	d->view_num = 0;
	for (p=d->pt, d->cpd=d->pd, i=0; *p!=NULL; p++, d->cpd++, i++) {
		if (d->cpd->view == P_VIEW) 
			*(d->sort + d->view_num++) = i;
	}
	--d->view_num;
}


static 	char	a_buff[TMP_SIZE], 
		b_buff[TMP_SIZE];	
/* 
	This is default kim data sorter 
 */
inline int sort_data(int *a, int *b)
{
	sorted_d->cpt = *(sorted_d->pt + *a);
	sorted_d->cpd =  (sorted_d->pd + *a);
	kc[sorted_d->sort_cols].maker(a_buff, sorted_d);
	
	sorted_d->cpt = *(sorted_d->pt + *b);
	sorted_d->cpd =  (sorted_d->pd + *b);
	kc[sorted_d->sort_cols].maker(b_buff, sorted_d);
	
	if (sorted_d->sort_mode == SORT_DATA_DESC)
                    return (int) strcmp(b_buff, a_buff);
	else
                    return (int) strcmp(a_buff, b_buff);	
}

/* ----- sort main ------ */

int sort_proc_tab(int sort, kim_DATA *d) 
{
	_D(" sort_proc_tab() ");
      
	switch(sort) {
	case SORT_NATURALLY:
         	sort_naturally(d);
         	break;	
	case SORT_TREE:
         	init_tree(d);
         	set_flags(d);
         	break;
	case SORT_DATA_DESC:
	case SORT_DATA_ASC:
		sort_naturally(d);
		sorted_d = d;
		qsort(d->sort, d->view_num+1, sizeof(d->sort), 
              		(int (*) (const void *, const void *)) 
              		kc[d->sort_cols].sorter);
		break;	
	}
	d->sort_mode = sort;   
	return(RE_OK);
}

/* 
	Set view/notview of processes and call sort func. 
	(if view==_YOUR hide processes where uid is not
	uid of processes loader) 
*/            
int prepare_view(int view, int sort, kim_DATA *d) 
{
   	proc_t	**p;      
	u_tab	*u;
	int	i;
   
        _D(" prepare_view() "); 
      
        if (conf_L.save) {
        	conf_L.sort 	 = sort;
        	conf_L.sort_cols = d->sort_cols; 
        	conf_L.view 	 = view;
        	INI_set_flag( _S_LAYOUT, TRUE);
        }
        
        if (view == VIEW_YOUR) {
        	for(u=d->ut; u->name!=NULL; u++)  {
        		if (d->uid == u->uid) 	d->cpd->view = P_VIEW;
        		else			d->cpd->view = P_NOTVIEW;
        	}
        }
      
        d->view_num = 0;
	
	if (sort != SORT_TREE) {
		for (p=d->pt, d->cpd=d->pd, i=0; *p!=NULL; p++, d->cpd++, i++) {
			switch(view) {
			case VIEW_ALL:
        	    		d->cpd->view = P_VIEW;
        	 		d->view_num++;
        	 		break;
        	 	case VIEW_YOUR:	
        	 		if ((*p)->INDEP_UID == d->uid)  {
        	 			d->cpd->view = P_VIEW;
        	 			d->view_num++;
        	 		} else {
        	 			d->cpd->view = P_NOTVIEW;
        	 			if (d->cpd->mark) {
        	 				d->cpd->mark= P_UNMARKED;
        	 				--d->mark_num;
        	 			} 
        	 		}	
        	 		break;		
			case VIEW_USER:
				d->cpd->view = (d->show_selected ? P_NOTVIEW : P_VIEW);
            			for(u=d->ut; u->name!=NULL; u++) 
                  			if (u->view && (*p)->INDEP_UID == u->uid) {
                     				d->cpd->view = (d->show_selected ? P_VIEW : P_NOTVIEW);
                     				d->view_num++;
                     				break;
                  			}
				break;
			}
		}
		--d->view_num;
		d->view_mode = view;			
	} else
        	d->view_mode = VIEW_ALL;
        sort_proc_tab(sort, d);
	return(RE_OK);
}
      
int kim_search(kim_DATA *d, char *str)
{
         int	sum = 0, i;
         int	size = strlen(str);
         
         if (!size) return 0; 
         
         unselect_all(d);
         
         _D( " int kim_search()" );
         
         for (i=0; i<= d->view_num; i++) {
      	       	d->cpt	= *(d->pt + *(d->sort + i));
		d->cpd	= d->pd + *(d->sort + i);
      	       
               	ks.tmp[0] = '\0';
               	kc[*conf_P.act_profile.cols].maker(ks.tmp, d);
               
               	if (bcmp(str, ks.tmp, size) == 0) {
                	++sum;
                  	d->cpd->mark = P_MARKED;
                }
         }
         return (d->mark_num = sum);
}
