
#ifndef __ACA_KEY_H
#define __ACA_KEY_H

typedef struct {
	int	curses;			/* curses standard KEY_ */
	char	*capname,		/* capname of key */
		*seq,			/* term seqention */	
		*default_seq;		/* default seqention */	
	int	ctrl,			/* key alternative CTRL+key */
		learn;			/* TRUE / FALSE */			
} ACA_BASIC_KEYS;

#define	SeqN		((char *) NULL)
#define XCTRL(x)	((x) & 31)
#define T_XCTRL(x)	(x==XCTRL(x) ? TRUE : FALSE)
#define ESC_CHAR	'\033'
#define ESC_STR 	"\033"

#define MAX_SEQTIME	200000		

extern  ACA_BASIC_KEYS 	basic_keys[];

extern char	*GL_term_name;
extern char	GL_seq_buff[256];
extern int	GL_last_key;
extern int	GL_current_key;	
extern int	GL_inlearn_mode;	/* if aca learning key (now!) */

/* double ctrl key */
#define D_CTRL_KEY(x, y) \
	((XCTRL(x) == GL_last_key && XCTRL(y) == GL_current_key) ? TRUE : FALSE)	

/* esc key */
#define ESC_KEY(x) \
	(((ESC_CHAR == GL_last_key) && x == GL_current_key) ? TRUE : FALSE)	

/* for menu_seek() (refresh menu, but not go) */ 
#define K_STAY		-100	

#define K_MOUSE_L	KEY_MOUSE
#define K_MOUSE_M	-120
#define K_MOUSE_R	-130	
#define K_MOUSE_NOT	-140

extern void	aca_keypad(int x);
extern void	aca_dump_keys(FILE *f, ACA_BASIC_KEYS *k);
extern int	learn_keydump_check();
extern int	isfunckey( int key ); 
extern void	set_learn_key(char *name, char *seq);
extern int	load_keys(FILE *f);
extern void	load_seqences();
extern void	init_keys();
extern int	timeout_calls(int current);
extern void	clean_input ();
extern int	check_seq(char *buffer);
extern int	get_k();
extern int	learn_key(int key);
extern int	INI_writer_keys(FILE *f);
extern int	INI_loader_keys(FILE *f, int flag);
extern void	cpy_lbuff();
extern void	init_lbuff();

#endif /* __ACA_KEY_H */
