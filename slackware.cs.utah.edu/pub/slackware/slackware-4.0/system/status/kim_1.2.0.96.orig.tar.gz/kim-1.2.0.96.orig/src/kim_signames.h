/*
	The kim's signames file 
*/	

{ 1,	"HUP", 		N_("Hangup detected on controlling terminal or death of controlling process") },
{ 2,	"INT", 		N_("Interrupt from keyboard")			},
{ 3,	"QUIT", 	N_("Quit from keyboard")			},
{ 4,	"ILL", 		N_("Illegal Instruction")			},
{ 5,	"TRAP", 	N_("Trace/breakpoint trap")			},
{ 6,	"ABRT", 	N_("Abort signal from abort(3)")		},
{ 6,	"IOT", 		N_("IOT trap. A synonym for SIGABRT")		},
{ 7,	"BUS", 		N_("Bus error")					},
{ 8,	"FPE", 		N_("Floating point exception")			},
{ 9,	"KILL", 	N_("Kill signal")				},
{ 10,	"USR1", 	N_("User-defined signal 1")			},
{ 11,	"SEGV", 	N_("Invalid memory reference")			},
{ 12,	"USR2", 	N_("User-defined signal 2")			},
{ 13,	"PIPE", 	N_("Broken pipe: write to pipe with no readers")},
{ 14,	"ALRM", 	N_("Timer signal from alarm(2)")		},
{ 15,	"TERM", 	N_("Termination signal")			},
{ 16,	"STKFLT", 	N_("Stack fault on coprocessor")		},
{ 17,	"CHLD", 	N_("Child stopped or terminated")		},
{ 18,	"CONT", 	N_("Continue if stopped")			},
{ 19,	"STOP", 	N_("Stop process")				},
{ 20,	"TSTP", 	N_("Stop typed at tty")				},
{ 21,	"TTIN", 	N_("tty input for background process")		},
{ 22,	"TTOU", 	N_("tty output for background process")		},
{ 23,	"URG", 		N_("Urgent condition on socket (4.2 BSD)")	},
{ 24,	"XCPU", 	N_("CPU time limit exceeded (4.2 BSD)")		},
{ 25,	"XFSZ", 	N_("File size limit exceeded (4.2 BSD)")	},
{ 26,	"VTALRM", 	N_("Virtual alarm clock (4.2 BSD)")		},
{ 27,	"PROF", 	N_("Profile alarm clock")			},
{ 28,	"WINCH", 	N_("Window resize signal (4.3 BSD, Sun)")	},
{ 29,	"IO", 		N_("I/O now possible (4.2 BSD)")		},
{ 30,	"PWR", 		N_("Power failure (System V)")			},
{ 31,	"UNUSED",	N_("Unused signal")				}

/* end */