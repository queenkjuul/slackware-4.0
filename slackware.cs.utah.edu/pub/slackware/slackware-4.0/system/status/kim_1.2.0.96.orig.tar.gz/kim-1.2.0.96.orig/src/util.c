
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <signal.h>
#include <errno.h>
#include <proc/version.h>

#include "kim.h"
#include "config.h"
#include "util.h"

   void wait_time(int t)
   {
   	_D(" wait_time()");
   	
   	while(t>=0) {
   		show_run();
   		sleep(1);
   		--t;
   		show_run();
   	}
   }
   
   char *get_procps_version()
   {
	char	*p = strrchr(procps_version, ' ');   	
	
	_D("get_procps_version()");
	
	return	++p; 
   }
   
   int check_kim_version(char *ver)
   {
	_D(" check_kim_version() ");

	if (!ver) 
		return FALSE;
	if (!strcmp(ver, KIM_VERSION)) 
		return TRUE;
	else 
		return FALSE;
        return FALSE;
   }

   int check_procps_version(char *ver)
   {
	_D(" check_procps_version() ");

	if (!ver) 
		return FALSE;
	if (!strcmp(ver, get_procps_version())) 
		return TRUE;
	else 
		return FALSE;
        return FALSE;
   }   
   
   void fprintf_kim_version(FILE *f) 
   {
   	_D(" fprintf_kim_version()  ");
   	
   	fprintf(f, "kim_version=%s\n", KIM_VERSION);	
   }
   
   char *fscanf_kim_version(FILE *f, char *ver)
   {
   	_D(" fscanf_kim_version() ");
   	
   	ks.tmp[0] = '\0';
   	fgets(ks.tmp, TMP_SIZE, f);
   	if (!(ver=separe_str(ks.tmp, '='))) 
   		return chN;
   	else
   		return ver;		
   	return chN;
   }
   
   void fprintf_procps_version(FILE *f) 
   {
   	_D(" fprintf_procps_version()  ");
   	
   	fprintf(f, "procps_version=%s\n", get_procps_version());	
   }
   
   char *fscanf_procps_version(FILE *f, char *ver)
   {
   	_D(" fscanf_procps_version() ");
   	
   	ks.tmp[0] = '\0';
   	fgets(ks.tmp, TMP_SIZE, f);
   	if (!(ver=separe_str(ks.tmp, '='))) 
   		return chN;
   	else
   		return ver;		
   	return chN;
   } 
   
   int INI_loader_about(FILE *f, int flag)
   {
   	char	*ver= chN;
   	
   	_D(" INI_loader_about() ");
   	
   	if (flag == YES_SECTION) {
   		ver = fscanf_kim_version(f, ver);
   		
   	/* ############## NEEDN'T NOW ###############	
   		if (!check_kim_version(ver)) {
   			if (ks.interactive)
   				Warning(_("Kim version and version of 'ini'\nfile is different!"));    
			else
				fputs(_("Kim version and version of 'ini' file is different!"), stderr);      				
   		}
   	  ############################################ */
   	} 
   	return TRUE;
   }
   
   int INI_writer_about(FILE *f)
   {
   	_D(" INI_writer_about() ");
   	
   	fprintf_kim_version(f);	
   	return TRUE;
   }
   
   char *strrepchr(char *buff, int old, int new)
   {
   	char	*loc;
   	
   	_D(" strrepch() ");
   	
   	if ((loc = strchr(buff, old)) != NULL) {
		do {
			*loc = new;
			loc = strchr(buff, old);
		} while (loc);
	}
	return buff;
   }

int kim_exec(char **argv) {
      int	pid, 
      		status;
      
      cur_pre_exec();
      
      if ((pid = fork ()) < 0) 	
         perror("kim fork");	
      
      if (pid == 0) {
      
      /* --- child --- */
         if (execvp(argv[0], argv) < 0) {
            perror(argv[0]);
            _D( "ERROR EXEC");
            exit(1);
         }
         exit(0);
         	
      } else { 
      
      /* --- parent --- */
         if (wait(&status) < (pid_t) 0 )
            perror("kim");
      
      }
      cur_post_exec();
      return status;	
   }
   
   int kim_help() 
   {
      char	*argv[3];
      int	re;
   
      argv[0]	= ks.helpviewer;
      sprintf(ks.tmp, "%s%s", KIM_LIBDIR, KIM_HELP_HTML);
      argv[1]	= ks.tmp;
      argv[2]	= NULL;  
      
      re	= kim_exec(argv);
      
      if (WIFEXITED(re)) {
      	if (WEXITSTATUS(re) == 1)
      	return FALSE;
      }
      return TRUE;	
   }   

  int killer(int pid, int sig, char *name, char *error) 
  {
      if (kill(pid, sig) == -1) {
         switch(errno) {
         case EINVAL: 
            sprintf(error, _("An invalid signal was specified: %s (%d)."), name, pid);
            break;
         case ESRCH:
            sprintf(error, _("Process does not exist (or zombie?): %s (%d)."), name, pid); 
            break;
         case EPERM:
            sprintf(error, _("Permission denied: %s (%d)."), name, pid);
            break;
         }
         return FALSE;	
      }
      return TRUE;
   }

int is_file(char *filename)
{
	struct stat	st;
      	if (stat(filename, &st) == -1) 
      		return FALSE;
	else if (S_ISREG(st.st_mode))
		return TRUE;
	
	return FALSE;	        
}

static void run_conf2ini(char *path)
{
      int	pid, 
      		status;
      
      _D( "run_conf2ini()");
      
      if ((pid = fork ()) < 0) 	
         perror("kim fork");	
      
      if (pid == 0) {
      
      /* --- child --- */
      	char	*argv[3];
   
      	argv[0]	= KIM_CONF2INI;
      	argv[1]	= path;
      	argv[2]	= NULL;  
      
         if (execvp(argv[0], argv) < 0) {
            perror(argv[0]);
            _D( "ERROR EXEC");
            exit(1);
         }
         exit(0);
         	
      } else { 
      
      /* --- parent --- */
         if (wait(&status) < (pid_t) 0 )
            perror("kim");
      
      }
}

int copy_file(char *des, char *src) {
   	FILE *sf, *df;
   	
   	_D( "copy_file()");
   	
   	if ((sf=fopen(src, "r")) == NULL || (df=fopen(des, "w")) == NULL) {
   		if (!(sf)) perror(src);
   		else perror(des);
   		return FALSE;
   	} 
	while (!feof(sf)) 
		fputc(fgetc(sf), df);
	fclose(sf);
	fclose(df);
	return TRUE;
}

static int select_dir(struct dirent *d)
{
	if (d->d_name[0] == '.')
		return 0; 
	return d->d_ino;
}

static void make_ini_dir(char *newdir)
{
	int		num, i;	
	char		des_path[TMP_SIZE],
			src_path[TMP_SIZE];
	struct dirent	**namelist;
	
	_D(" make_ini_dir()");
	
	if ((num = scandir((const char *) KIM_DEFAULT_INIDIR, &namelist, select_dir, 
		       alphasort)) != -1) {
		--num; 
	} else {
		fprintf(stderr, _("Kim: Can't scandir '%s'\n"), KIM_DEFAULT_INIDIR); 
		exit(RE_ERROR);
	}
	if (mkdir(newdir, KIM_INIDIR_MODE) == -1) {
        	if (errno != EEXIST) { 
        		perror(newdir);
         		exit(RE_ERROR); 
         	}	
      	}
	for (i=0; i<=num; i++) {
		sprintf(src_path, "%s%s", KIM_DEFAULT_INIDIR, (*(namelist+i))->d_name);
		sprintf(des_path,   "%s%s", newdir, (*(namelist+i))->d_name);
		copy_file(des_path, src_path);
	}		
}

void check_ini_file(char *ini)
{
	_D(" check_ini_file()");

	if (is_file(ini))
		return;				/* OK */
	else {
		char 	*loc;
		
		strcpy(ks.tmp, ini);
		loc = strrchr(ks.tmp, '/');
		++loc; *loc = '\0';
		strncat(ks.tmp, KIM_OLD_CONF, (TMP_SIZE-strlen(ks.tmp)));
		if (is_file(ks.tmp)){
			*loc = '\0';
			run_conf2ini(ks.tmp);
		} else {
			*loc = '\0';
			make_ini_dir(ks.tmp);
		}	
	}	
}
   