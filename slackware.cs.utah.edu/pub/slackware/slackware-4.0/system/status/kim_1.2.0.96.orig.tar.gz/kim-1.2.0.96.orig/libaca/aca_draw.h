
#ifndef __ACA_DRAW_H
#define __ACA_DRAW_H

extern int	GL_lin, 
		GL_col;

/* --- color part --- */

typedef struct {
	int	color,
		fc,
		bc,
		bw;	
} aca_COLORS;

typedef struct {
	int	sel,			/* selected area 			*/
		nsel,			/* not selected area 			*/
		sel_astr,		/* selected ACTIVE STRING 		*/
		nsel_astr,		/* not selected ACTIVE STRING 		*/
		border_sel,		/* selected border			*/
		border_nsel,		/* not selected border 			*/
		title_sel,		/* selected title 			*/
		title_nsel,		/* not selected title 			*/
		title_sel_astr, 	/* selected ACTIVE STRING in title	*/
		title_nsel_astr;	/* not selected ACTIVE STRING in title	*/
} WidgetColor;

typedef struct {
	/* dialogs colors */
	int		dlg_bgr,
			dlg_header,
			dlg_warning;
	
	/* widgets color */
	WidgetColor	button,		/* color for Wbutton	*/
			radio,		/* color for Wradio	*/
			input,		/* color for Winput	*/
			
			/* color for Wmenu (in any dialogs - see menu flag M_MENUIN) */
			menu_in,	
			/* color for Wmenu (see menu flag M_MENUDIRECT) */
			menu_out,
			/* color for Wmenu (see menu flag M_MENUOUT) */
			menu_direct;
} TemplateColor;

extern aca_COLORS 	*GL_c;
extern TemplateColor	*TplC;

extern int	aca_init_color(int num);
extern void	aca_init_pair(int color_num, int fc, int bc, int bw);
extern TemplateColor *set_TplC( TemplateColor *t);

inline extern 	void aca_c(int x);
		
#define aca_uc(x)	attroff ((aca.color ? (*(GL_c+x)).color : (*(GL_c+x)).bw))

#define bold		attron(A_BOLD)
#define ubold		attroff(A_BOLD) 

#define blink		attron(A_BLINK)	  	
#define ublink		attroff(A_BLINK)

#define	ACA_HLINE	(aca.line ? ACS_HLINE 		: '-')  
#define	ACA_VLINE	(aca.line ? ACS_VLINE 		: '|')
#define	ACA_ULCORNER	(aca.line ? ACS_ULCORNER 	: '+')
#define	ACA_URCORNER	(aca.line ? ACS_URCORNER 	: '+')
#define	ACA_LLCORNER	(aca.line ? ACS_LLCORNER 	: '+')
#define	ACA_LRCORNER	(aca.line ? ACS_LRCORNER 	: '+')
#define	ACA_TTEE	(aca.line ? ACS_TTEE 		: '+')
#define	ACA_BTEE	(aca.line ? ACS_BTEE 		: '+')
#define	ACA_LTEE	(aca.line ? ACS_LTEE 		: '+')
#define	ACA_RTEE	(aca.line ? ACS_RTEE 		: '+')
#define	ACA_DARROW	((aca.line && aca.spec) ? ACS_DARROW 	: 'v')
#define	ACA_UARROW	((aca.line && aca.spec) ? ACS_UARROW 	: '^')
#define	ACA_RARROW	((aca.line && aca.spec) ? ACS_RARROW 	: '>')
#define	ACA_LARROW	((aca.line && aca.spec) ? ACS_LARROW	: '<')


#define CLEAN_BOX(l,le,c,ce) {				\
         for( GL_lin =l; GL_lin <=le; GL_lin++)      	\
             for(GL_col =c; GL_col <=ce; GL_col++)    	\
                mvaddch(GL_lin , GL_col , ' ');		\
}  

#define CLEAN_HLINE(l,c,ce) {				\
	 for(GL_col =c; GL_col<=ce; GL_col++)   	\
	        mvaddch(l, GL_col , ' ');		\
}

extern void 	mvaddastr(int l, int c, char *astr, int acolor, int color);
extern void	center_addnstr(int y, int x, char *str, int max);
extern void	left_addnstr(int y, int x, char *str, int maxlines, int max);	
extern void	mvaddline_nstr (int y, int x, char *str, int line, int max);	

extern void	aca_border(int l, int l_max, int c, int c_max, int color);
extern void	draw_linebox(int l, int l_max, int c, int c_max, int color);
extern void	clear_linebox(int l, int l_max, int c, int c_max);

extern chtype	**init_refresh_buffer();
extern void	fill_refresh_buffer(chtype **b);
extern void	print_refresh_buffer(chtype **b);

extern inline 	void show_run();

extern int	gethotkey(char *astr);
extern int	astrlen(char *astr);

#endif /* __ACA_DRAW_H */