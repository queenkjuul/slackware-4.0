
/*
 *  Copyright (c) 1998 - 1999 Karel Zak "Zakkr" <zakkr@zf.jcu.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <proc/version.h>
#include <proc/sysinfo.h>
#include <proc/whattime.h>
#include <proc/devname.h>
#include <time.h>
#include <sys/param.h>

#include "kim.h"
#include "procdata.h"
#include "procutil.h"
#include "proccols.h"
#include "procsort.h"
#include "util.h"

static int init_user_tab(kim_DATA *d);
static int set_sys_meminfo(kim_DATA *d);

kim_DATA	**GL_kdata;	 
int		GL_kdata_num=-1;
int		GL_kdata_curr=0;

static void default_proc(kim_DATA *d)
{
	d->mark_num		= 0;
	d->show_selected 	= TRUE;
	d->sort_cols		= -1; 
}

kim_DATA *kimdata_malloc()
{
	kim_DATA	*new;
	
	_D(" kimdata_malloc() ");
	if ((new= (kim_DATA *) malloc(sizeof(kim_DATA))) == NULL) {
		ERROR_ALLOC;
		return (kim_DATA *) NULL;
	} else
		return new;		
}   

kim_DATA *add_kdata(kim_DATA *d) 
{
	int		i;
	kim_DATA	**tmp;
	
	_D(" add_kdata()");

      	tmp = GL_kdata;
      	if ((GL_kdata = (kim_DATA **) calloc(++GL_kdata_num+1, sizeof(kim_DATA *))) == NULL) {
        	ERROR_ALLOC;
        	return (kim_DATA *) NULL;
      	}
      	if (GL_kdata_num) {
      		for(i=0; i<=GL_kdata_num-1; i++) 
         		GL_kdata[i] = tmp[i];
      		cfree((void *) tmp);
      	} 
      	GL_kdata[GL_kdata_num] 	= d;
      	GL_kdata_curr		= GL_kdata_num;
      		
      	return GL_kdata[ GL_kdata_num ];
}

kim_DATA *set_current_kdata(int knew)
{
	_D(" set_current_kdata()");
	
	if (knew > GL_kdata_num)
		return  (kim_DATA *) NULL; 
	return GL_kdata[ (GL_kdata_curr=knew) ];
}

static int alloc_for_data(kim_DATA *d, int flag)
{
      _D(" alloc_for_data() ");
   	
   /* Allocate user table */ 
      if ((d->ut = (u_tab *) calloc(d->user_num+2, sizeof(u_tab))) == NULL) {
         ERROR_ALLOC;
         return RE_ERROR;
      } 
      d->ut[ d->user_num+1 ].name = chN;
      
   /* Allocate kim process data table  */
      if((d->pd = (p_tab *) calloc(d->proc_num+2, sizeof(p_tab))) == NULL) {
         ERROR_ALLOC;
         return RE_ERROR;
      } 
      d->pd[ d->proc_num+1 ].view = -1;
      
   if (flag) {
   /* Allocate sort tab */
      if((d->sort = (int *) calloc(d->proc_num+2, sizeof(int))) == NULL) {
         ERROR_ALLOC;
         return RE_ERROR;
      } 
      d->sort[ d->proc_num+1 ] = -1;
   }  
   return RE_OK;
}

void dump_proc(FILE *f, proc_t *p, p_tab *pd)
{	
	_D(" dump_proc() ");

	fprintf(f, 
#if PROCPS_1_2
	"\n%s %s %c %s\n%s\n%d %d %d %d %d %d %d %d %d %Ld %Ld %Ld %Ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %u %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n", 
#else
  #ifdef SIGNAL_STRING
	"\n%s %s %c %3s\n%s\n%d %d %d %d %d %d %d %ld %ld %s %s %s %s %lu %lu %lu %ld %ld %ld %ld %ld %ld %ld %ld %ld %u %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n", 
  #else
	"\n%s %s %c %3s\n%s\n%d %d %d %d %d %d %d %ld %ld %Ld %Ld %Ld %Ld %lu %lu %lu %ld %ld %ld %ld %ld %ld %ld %ld %ld %u %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n", 
  #endif
#endif
	p->INDEP_USER, p->cmd, p->state, 	

#if PROCPS_1_2	
	p->ttyc, 
#else
	pd->ttyc,
#endif	
	(pd->cmdline ? pd->cmdline : p->cmd), p->INDEP_UID, p->pid, p->ppid, p->pgrp, p->session, 
	p->tty, p->tpgid, p->priority, p->nice, p->signal, p->blocked, p->sigignore, p->sigcatch, 
	p->start_time, p->utime, p->stime, p->cutime, p->cstime, p->size, p->resident, p->share,		
	p->trs, p->lrs, p->drs, p->dt, p->pcpu, p->vsize, p->rss, p->rss_rlim, p->timeout, p->it_real_value, p->flags,		
	p->min_flt, p->maj_flt, p->cmin_flt, p->cmaj_flt, p->start_code, p->end_code, p->start_stack,
	p->kstk_esp, p->kstk_eip, p->wchan);			
}

static int fscanf_proc(FILE *f, proc_t *p, p_tab *pd)
{
	_D(" fscanf_proc() ");
	
	ks.tmp[0] = '\0';

	fscanf(f, "\n%s %s %c %s\n", p->INDEP_USER, p->cmd, &p->state, 
#if PROCPS_1_2
	p->ttyc);
#else	
	pd->ttyc);
#endif	
	fgets(ks.tmp, TMP_SIZE, f);	

	fscanf(f, 

#if PROCPS_1_2
	"%d %d %d %d %d %d %d %d %d %Ld %Ld %Ld %Ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %u %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n", 
#else
  #ifdef SIGNAL_STRING
	"%d %d %d %d %d %d %d %ld %ld %s %s %s %s %lu %lu %lu %ld %ld %ld %ld %ld %ld %ld %ld %ld %u %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n", 
  #else
	"%d %d %d %d %d %d %d %ld %ld %Ld %Ld %Ld %Ld %lu %lu %lu %ld %ld %ld %ld %ld %ld %ld %ld %ld %u %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu\n", 
  #endif
#endif
	&p->INDEP_UID, &p->pid, &p->ppid, 
	&p->pgrp, &p->session, &p->tty, &p->tpgid, &p->priority, &p->nice, 
#ifdef SIGNAL_STRING	
	p->signal, p->blocked, p->sigignore, p->sigcatch, 
#else
	&p->signal, &p->blocked, &p->sigignore,	&p->sigcatch, 
#endif	
	&p->start_time, &p->utime, &p->stime, &p->cutime, &p->cstime, &p->size, &p->resident, &p->share,		
	&p->trs, &p->lrs, &p->drs, &p->dt, &p->pcpu, &p->vsize, &p->rss, &p->rss_rlim, &p->timeout, &p->it_real_value, &p->flags,		
	&p->min_flt, &p->maj_flt, &p->cmin_flt, &p->cmaj_flt, &p->start_code, &p->end_code, &p->start_stack,
	&p->kstk_esp, &p->kstk_eip, &p->wchan);			
	if (ks.tmp) {
		strrepchr(ks.tmp, '\n', ' ');
		pd->cmdline = strdup(ks.tmp);
	} else
		pd->cmdline = chN;
	return TRUE;	
}

int save_proc_to_file(char *filename, kim_DATA *d)
{
	proc_t	**pt;
	p_tab	*pd;
	FILE	*f;
	
	_D(" save_proc_to_file() ");
	
	if ((f=aca_fileopen(filename, "w", ks.interactive)) == NULL) {
		if (!ks.interactive) perror(filename);
		return RE_ERROR;
        }
    /* Kim header */
    	fputs("kim\n", f);
    	fprintf_kim_version(f); 
    	fprintf_procps_version(f);  
    	fputc('\n', f);
    /* Uname */
        fprintf(f, "%s %s %s %s %s %s\n", 
        	d->uname.sysname, 
        	d->uname.nodename,
        	d->uname.release, 
        	strrepchr(d->uname.version, ' ', '_'),  
        	d->uname.machine,
        	U_DOMAINNAME(d->uname));
        strrepchr(d->uname.version, '_', ' ');
    /* Time, num. .. */
	fprintf(f, "%d %d %d %d %ld\n", 
		d->uid, d->proc_num, d->user_num, d->current_time, d->time_now);
    /* Memory */
   	fprintf(f, "%u %u %u %u %u %u %u %u %u\n",
   		d->sys_m[meminfo_main][meminfo_total],
   		d->sys_m[meminfo_main][meminfo_free],
   		d->sys_m[meminfo_main][meminfo_used],
   		d->sys_m[meminfo_main][meminfo_shared],
   		d->sys_m[meminfo_main][meminfo_buffers],
   		d->sys_m[meminfo_main][meminfo_cached],
   		d->sys_m[meminfo_swap][meminfo_total],
   		d->sys_m[meminfo_swap][meminfo_free],
   		d->sys_m[meminfo_swap][meminfo_used]
   	);
    /* Uptime */
   	fprintf(f, "%s\n", d->uptime_str);
    /* Proc */
	for (pt=d->pt, pd=d->pd; *pt!= NULL; pt++, pd++) {
		dump_proc(f, *pt, pd);
		if (ks.interactive) show_run();
	}	
	fclose(f);	
	return RE_OK;
}   

int proc_from_file(kim_DATA *d) 
{
	FILE	*f;
	proc_t	**p;
      	p_tab	*pd;
	int	i;
	char	*ver=chN;
	
	_D(" proc_from_file() "); 
	
	if (!d->file) {
		_D(" proc_from_file(): NOT FILE DEFINED"); 
		return RE_ERROR;
	}	
	if ((f=aca_fileopen(d->file, "r", ks.interactive)) == NULL) {
		if (!ks.interactive) perror(d->file);
		return RE_ERROR;
	}
    /* Kim header */   
	ks.tmp[0] = '\0';
	fscanf(f, "%s\n", ks.tmp);
	if (strcmp(ks.tmp, "kim")) {
		if(ks.interactive) Error(_("It is not kim's file format"));
		else fputs(_("It is not kim's file format"), stderr);
		return RE_ERROR;
	}
     /* kim version is not need check in this version */	
	fscanf_kim_version(f, ver);
	ver = fscanf_procps_version(f, ver);
	if (!check_procps_version(ver)) {
		if(ks.interactive) Warning(_("Loading with NO WARRANTY.\nFile was make with different procps!"));
		else fputs(_("Loading with NO WARRANTY.\nFile was make with different procps!"), stderr);
	}
    /* Uname */
        fscanf(f, "%s %s %s %s %s %s\n", 
        	d->uname.sysname, 
        	d->uname.nodename,
        	d->uname.release, 
        	d->uname.version, 
        	d->uname.machine,
        	U_DOMAINNAME(d->uname));	
        strrepchr(d->uname.version, '_', ' ');
    /* Time */
	fscanf(f, "%d %d %d %d %ld\n", 
		&d->uid, &d->proc_num, &d->user_num, &d->current_time, &d->time_now);
    /* Mem */	
   	set_sys_meminfo(d);	/* dummy: allocate **sys_m */
   	fscanf(f, "%u %u %u %u %u %u %u %u %u\n",
   		&d->sys_m[meminfo_main][meminfo_total],
   		&d->sys_m[meminfo_main][meminfo_free],
   		&d->sys_m[meminfo_main][meminfo_used],
   		&d->sys_m[meminfo_main][meminfo_shared],
   		&d->sys_m[meminfo_main][meminfo_buffers],
   		&d->sys_m[meminfo_main][meminfo_cached],
   		&d->sys_m[meminfo_swap][meminfo_total],
   		&d->sys_m[meminfo_swap][meminfo_free],
   		&d->sys_m[meminfo_swap][meminfo_used]
   	);
   	alloc_for_data(d, TRUE);
     /* Uptime */
   	fgets(ks.tmp, TMP_SIZE, f);
   	d->uptime_str = strdup(ks.tmp);
     /* Process */
	if ((d->pt = (proc_t **) calloc(d->proc_num+2, sizeof(proc_t *))) == NULL) {
		ERROR_ALLOC;
		_D("proc_from_file(): ERROR END");
		return RE_ERROR;
	}
	d->pt[d->proc_num+1] = (proc_t *) NULL;
	
	null_cols_width( d );
	for (i=0, p=d->pt, pd=d->pd; i<=d->proc_num; p++, pd++, i++) {
      		if (feof(f)) {
      			*p = (proc_t *) NULL;
      			d->proc_num = --i;
      			break;
      		}
      		if (ks.interactive) show_run();
      		
      		if ((*p = (proc_t *) malloc(sizeof(proc_t))) == NULL) {
			ERROR_ALLOC;
			_D("proc_from_file(): ERROR END");
			return RE_ERROR;
		}
      		fscanf_proc(f, *p, pd);
      		d->cpt = (*p); d->cpd = pd; 
#if PROCPS_2_0
	       	dev_to_tty(d->cpd->ttyc, 8, d->cpt->tty, d->cpt->pid, ABBREV_DEV);
#endif
      		set_cols_width(d);
	}
	fclose(f);

     /* Init user table */   
        init_user_tab(d);
        d->view_num	= d->proc_num;
	d->flag		= FROM_FILE;
	default_proc(d);
	return RE_OK;
}

static int user_num(kim_DATA *d)
{
	proc_t	**p;
	int	*x, i=FALSE, n=0;
	
	_D(" user_num() ");
	
	d->sort[0] = -1;
	for(p=d->pt; *p!=NULL; p++) {
		i=FALSE;
		for(x=d->sort; *x!=-1; x++)
			if ((*p)->INDEP_UID == *x) {
				i=TRUE;
				break;	
			}
		if (!i) {
			d->sort[n] = (*p)->INDEP_UID;
		 	d->sort[++n] = -1;
		}		
	}
	return --n;
}

static int init_user_tab(kim_DATA *d)
{
	proc_t	**p;
	int	i=FALSE, n=0;
	u_tab	*u;
	
	_D(" init_user_tab() ");
	
	d->ut[0].name = NULL;
	for(p=d->pt; *p!=NULL && n<=d->user_num; p++) {
		i=FALSE;
		for(u=d->ut; u->name!=NULL; u++)
			if ((*p)->INDEP_UID == u->uid) {
			i=TRUE;
				break;	
			}
		if (!i) {
			d->ut[n].name 	= (*p)->INDEP_USER; 
        		d->ut[n].uid 	= (*p)->INDEP_UID;
        		d->ut[n].view	= P_VIEW;
		 	d->ut[++n].name = NULL;
		}		
	}
	return --n;
}  

void unselect_all(kim_DATA *d)
{
      int i;
   
      _D(" unselect_all() ");
      for(i=0; i<=d->proc_num; i++) 
         d->pd[i].mark = P_UNMARKED;
   
      d->mark_num = 0;
}
   
static int set_sys_meminfo(kim_DATA *d)
{
      _D(" set_sys_memminfo() ");
      if (!(d->sys_m = meminfo())) {
         perror("/proc/meminfo");
         return RE_ERROR;
      }
      return RE_OK;
}
      
int proc_from_proc(kim_DATA *d)
{
      proc_t	**p;
      p_tab	*pd;

      _D(" proc_form_proc() ");
       
#if PROCPS_1_2
      set_linux_version();         
      d->pt = readproctab( PROC_FILLTTY | PROC_FILLMEM  | PROC_FILLUSR | PROC_FILLCMD );
#else
      d->pt = readproctab( PROC_FILLMEM | PROC_FILLUSR | PROC_FILLCMD | PROC_FILLSTATUS);
#endif

      set_sys_meminfo(d);

   /* Count process */
      d->proc_num=0;
      while( d->pt[d->proc_num++] != NULL );
   
      d->proc_num -= 2;
      if (d->proc_num < 0) 
         return(RE_ERROR);
      d->view_num = d->proc_num;	
      
   /* Allocate sort tab */
      if((d->sort = (int *) calloc(d->proc_num+2, sizeof(int))) == NULL) {
         ERROR_ALLOC;
         return RE_ERROR;
      } 
      d->sort[ d->proc_num+1 ] = -1;
         
      d->uid = getuid();
      d->user_num = user_num(d);
      alloc_for_data(d, FALSE); 
     
   /* Init user table */   
      init_user_tab(d);
     
      if (!(d->current_time = uptime(0,0))) {
         if (ks.interactive) Error(_("Can't set current uptime !"));
         else	fprintf(stderr, _("Kim: Can't set current uptime !\n"));
         return RE_ERROR;
      }   
      d->time_now = time(0L);

      null_cols_width( d );
      for (p=d->pt, pd=d->pd; *p!=NULL; p++, pd++) {
      	d->cpt = (*p); d->cpd = pd; ks.tmp[0] = '\0';
      	
      	if (ks.interactive) show_run();
      	
      	if (!(*p)->cmdline || !(*p)->cmdline || (!(*p)->cmdline[1] && !(*p)->cmdline)) 
        	pd->cmdline = chN;      
        else {	
        	strlist(ks.tmp, (*p)->cmdline,  " ", TMP_SIZE);
        	pd->cmdline = strdup(ks.tmp);
        }        
#if PROCPS_2_0
        dev_to_tty(d->cpd->ttyc, 8, d->cpt->tty, d->cpt->pid, ABBREV_DEV);
#endif
      	set_cols_width(d);
      }
      
      if (uname(&d->uname) != 0) {
      	if (ks.interactive) Error(_("Can't load uname information !"));
        else fprintf(stderr, _("Can't load uname information !" "\n"));    
        return RE_ERROR;
      }
      d->uptime_str	= strdup(sprint_uptime());
      d->flag		= FROM_PROC;
      default_proc(d);
      return RE_OK;
}

/*
	Frees the kim_DATA
 */	
kim_DATA *free_kim_data(kim_DATA *d)
{
	proc_t	**p;
	p_tab	*pd;

	_D(" free_kim_data()");
	
	for (p=d->pt, pd=d->pd; *p!=NULL; p++, pd++) {
      		if (pd->cmdline)
        		free((void *) pd->cmdline);
        }

     /* Frees proc table */ 
        if (d->flag == FROM_PROC)
		freeproctab(d->pt);
	else {
		for (p=d->pt; *p!=NULL; p++) 
			free((void *) *p);
	}
     /* Frees file */
     	if (d->flag == FROM_FILE)
     		free((void *) d->file); 	
	
     /* Frees user table */ 
      	cfree((void *) d->ut);
      
     /* Frees kim process data table  */
      	cfree((void *) d->pd);
     
     /* Frees sort tab */
      	cfree((void *) d->sort); 
	
	free((void *) d->uptime_str);
	
	return d;
}

void sprintf_line(char *line_buff, kim_DATA *d, int header)
{
	kim_COLS	*p_kc;
	int		*cw;
	char		buff[TMP_SIZE],
			format[20];
	
	_D( " sprintf_line() ");
	
	for(p_kc=kc, cw=d->cols_width; p_kc->name!=chN; p_kc++, cw++) {
		sprintf(format, "%%.%ds", *cw); 
		if (header) 	strcpy(buff, p_kc->name);
		else 		p_kc->maker(buff, d);	
		sprintf(line_buff, format, buff);
		*(line_buff + strlen(line_buff)) = ' ';
		line_buff += (*cw + 1);		
	}
	*(line_buff+1) = '\0'; 
} 

int export_to_ascii(char *filename, kim_DATA *d)
{
	proc_t	**p;
	FILE	*f;
	int	siz, i;
	
	_D(" export_to_ascii() ");
	
	if ((f=aca_fileopen(filename, "w", ks.interactive)) == NULL) {
		if (!ks.interactive) perror(filename);
		return RE_ERROR;
        }
     /* About */
     	fputs("\nProcesses information\n=====================\n\n", f);
     	fprintf(f, "System: \t%s\nRelease:\t%s\nVersion:\t%s\nMachine:\t%s\nNodename:\t%s\nDomain: \t%s\n\n",
	     	d->uname.sysname,  d->uname.release,
	     	d->uname.version,  d->uname.machine,  
	        d->uname.nodename, U_DOMAINNAME(d->uname));	
  	fprintf(f, "Processes:\t%d\nUsers:   \t%d\nUptime:\t%s\n\n", d->proc_num, d->user_num, d->uptime_str);
  	   
     /* Header */   
     	memset(ks.out_buff, ' ', BUFSIZ*sizeof(char));
        sprintf_line(ks.out_buff, d, TRUE); 
        siz = strlen(ks.out_buff);
        for(i=0; i<=siz; i++) fputc('-', f);
        fprintf(f, "\n%s\n", ks.out_buff);
        for(i=0; i<=siz; i++) fputc('-', f);
        fputs("\n\n", f);
     /* Process */	
	for (p=d->pt, d->cpd=d->pd; *p!=NULL; p++, d->cpd++) {
      		d->cpt = (*p); 
        	memset(ks.out_buff, ' ', BUFSIZ*sizeof(char));
        	sprintf_line(ks.out_buff, d, FALSE);
        	fprintf(f, "%s\n", ks.out_buff);
	}
	fputc('\n', f);
	for(i=0; i<=siz; i++) fputc('-', f);	
	fputs("\nThis file was created GNU program 'kim', (C) 1998-1999 \"Zakkr\" Zak Karel, URL: \"http://home.zf.jcu.cz/~zakkr/kim\"\n", f);
	for(i=0; i<=siz; i++) fputc('-', f);	
	fclose(f);
	return RE_OK;
}

