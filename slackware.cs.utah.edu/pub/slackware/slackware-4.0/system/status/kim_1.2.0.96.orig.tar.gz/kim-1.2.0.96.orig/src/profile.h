
#ifndef __PROFILE_H
#define __PROFILE_H

#define PROF_START		TRUE
#define PROF_NOTSTART		FALSE
#define PROF_NAME_SIZE		15

#include "proccols.h"

typedef struct {
	int		cols[COLS_NUM+1],
			col_num;			
} ACT_PROFILE;	

typedef struct {
	char		**name;		
	ACT_PROFILE	act_profile;
	int		current,
			p_default,			
			num;
} kim_PROFILES;	

extern kim_PROFILES	conf_P;

#define P_COLS_NUM	(conf_P.act_profile.col_num)

extern int	INI_loader_profiling(FILE *f, int flag);
extern int	INI_writer_profiling(FILE *f);
extern int	load_profile(char *filename, ACT_PROFILE *act);
extern int	write_profile(char *filename, ACT_PROFILE *act);
extern int	set_current_profile(int current);
extern int	set_default_profile();
extern int 	add_profile(char *name);
extern int 	del_prof(int dn);
extern void	rename_profile(int num, char *newname);
extern ACT_PROFILE *cpy_actprof(ACT_PROFILE *dest, ACT_PROFILE *src);

#endif /* __PROFILE_H */