
#ifndef _FILL_LIST_H
#define _FILL_LIST_H

/* Kim screen process data printer */
extern void	mpr_list_area(Wmenu *m, Widget *w, int i, int l);
extern int	count_prof_width(kim_DATA *d);

#endif
