
#ifndef __MENU_H
#define __MENU_H

extern int menu_action(Wmenu *m, kim_DATA *d, int id);
extern int fast_action(int key, kim_DATA *d);

extern void mpr_left	(Wmenu *m, Widget *w, int i, int l); 
extern void mpr_comm	(Wmenu *m, Widget *w, int i, int l); 
extern void mpr_opt	(Wmenu *m, Widget *w, int i, int l); 
extern void mpr_profile	(Wmenu *m, Widget *w, int i, int l); 
extern void mpr_view	(Wmenu *m, Widget *w, int i, int l); 

extern char *comm_astr[];
extern char *option_astr[];

#endif /* __MENU_H */