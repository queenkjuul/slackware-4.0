
/*		  CURSES	CAPNAME		SEQ,	DEFAULT, CTRL  	*/	

/* 0 */		{ KEY_UP,	"kcuu1",	SeqN,	"[A",	'p'	},
/* 1 */		{ KEY_DOWN,	"kcud1",	SeqN,	"[B",	'n'	},
/* 2 */		{ KEY_LEFT,	"kcub1", 	SeqN,	"[D",	'l'	},
/* 3 */		{ KEY_RIGHT,	"kcuf1", 	SeqN,	"[C",	'r'	},	
/* 4 */		{ KEY_BACKSPACE,"kbs", 		SeqN,	"",	 0	},
/* 5 */		{ KEY_DC,	"kdch1", 	SeqN,	"[3~",	'd'	},
/* 6 */		{ KEY_HOME,	"khome", 	SeqN,	"[1~",	'h'	},
/* 7 */		{ KEY_END,	"kend", 	SeqN,	"[4~",	'e'	},
/* 8 */		{ KEY_IC,	"kich1", 	SeqN,	"[2~",	'i'	},
/* 9 */		{ KEY_PPAGE,	"kpp", 		SeqN,	"[5~",	'u'	},
/*10 */		{ KEY_NPAGE,	"knp", 		SeqN,	"[6~",	'v'	},
/*11 */		{ KEY_F(1),	"kf1", 		SeqN,	"[[A",	 0	},
/*12 */		{ KEY_F(2),	"kf2", 		SeqN,	"[[B",	 0	},
/*13 */		{ KEY_F(3),	"kf3", 		SeqN,	"[[C",	 0	},
/*14 */		{ KEY_F(4),	"kf4", 		SeqN,	"[[D",	 0	},
/*15 */		{ KEY_F(5),	"kf5", 		SeqN,	"[[E",	 0	},
/*16 */		{ KEY_F(6),	"kf6",		SeqN,	"[17~", 0	},
/*17 */		{ KEY_F(7),	"kf7", 		SeqN,	"[18~", 0	}, 
/*18 */		{ KEY_F(8),	"kf8", 		SeqN,	"[19~", 0	},	
/*19 */		{ KEY_F(9),	"kf9", 		SeqN,	"[20~", 0	},
/*20 */		{ KEY_F(10),	"kf10", 	SeqN,	"[21~", 0	},

/*last */	{ 0x0,		SeqN,		SeqN,	SeqN,	 0	}

