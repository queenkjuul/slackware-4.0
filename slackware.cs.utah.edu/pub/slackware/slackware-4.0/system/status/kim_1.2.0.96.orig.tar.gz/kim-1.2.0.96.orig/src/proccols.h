#ifndef __COLS_H
#define __COLS_H

#include "procdata.h"

/* ----- Kim cols ----- */

typedef struct {
	char		*name;		/* column name			*/
	int		width_max;	/*	max. width		*/
	char		*(*maker)();	/* pointer to col. data maker 	*/
					/* func. for cols data sorting  */
	int		(*sorter)(int *, int *);	
	char		*descript;	/* col. description		*/
} kim_COLS;

#ifndef COLS_NUM
	typedef enum {
		#include "proccols_enum.h"
	} _cols_;	
	
	#define COLS_NUM	(_COLS_COUNTER-1)
#endif

extern kim_COLS	kc[];

extern int 	*get_sort_cols();

extern void	null_cols_width( kim_DATA *d );
extern void	set_cols_width( kim_DATA *d );

extern inline 	char *cols_name		(char *buff, kim_DATA *d);
extern inline 	char *cols_state	(char *buff, kim_DATA *d);
extern inline 	char *cols_tty		(char *buff, kim_DATA *d);
extern inline 	char *cols_cmdline	(char *buff, kim_DATA *d);

extern inline 	char *cols_pid		(char *buff, kim_DATA *d); 
extern inline 	int  sort_pid		(int *a, int *b); 

extern inline 	char *cols_ppid		(char *buff, kim_DATA *d); 
extern inline 	int  sort_ppid		(int *a, int *b); 

extern inline 	char *cols_pgrd		(char *buff,  kim_DATA *d); 
extern inline 	int  sort_pgrd		(int *a, int *b); 

extern inline 	char *cols_session	(char *buff, kim_DATA *d); 
extern inline 	int  sort_session	(int *a, int *b); 

extern inline 	char *cols_ttynum	(char *buff, kim_DATA *d);
extern inline 	int  sort_ttynum	(int *a, int *b); 

extern inline 	char *cols_tpgid	(char *buff, kim_DATA *d); 
extern inline 	int  sort_tpgid		(int *a, int *b); 

extern inline 	char *cols_start	(char *buff, kim_DATA *d); 
extern inline 	int  sort_start		(int *a, int *b); 

extern inline 	char *cols_etime	(char *buff, kim_DATA *d); 
extern inline 	int  sort_etime		(int *a, int *b); 

extern inline 	char *cols_uid		(char *buff, kim_DATA *d); 
extern inline 	int  sort_uid		(int *a, int *b); 

extern inline 	char *cols_user		(char *buff, kim_DATA *d); 

extern inline 	char *cols_pmem		(char *buff, kim_DATA *d); 

extern inline 	char *cols_size		(char *buff, kim_DATA *d); 
extern inline 	int  sort_size		(int *a, int *b); 

extern inline 	char *cols_rss		(char *buff, kim_DATA *d); 
extern inline 	int  sort_rss		(int *a, int *b); 

extern inline 	char *cols_rss_rlim	(char *buff, kim_DATA *d); 
extern inline 	int  sort_rss_rlim	(int *a, int *b); 

extern inline 	char *cols_resident	(char *buff, kim_DATA *d); 
extern inline 	int  sort_resident	(int *a, int *b); 

extern inline 	char *cols_share	(char *buff, kim_DATA *d); 
extern inline 	int  sort_share		(int *a, int *b); 

extern inline 	char *cols_dt		(char *buff, kim_DATA *d); 
extern inline 	int  sort_dt		(int *a, int *b); 

extern inline 	char *cols_trs		(char *buff, kim_DATA *d); 
extern inline 	int  sort_trs		(int *a, int *b); 

extern inline 	char *cols_lrs		(char *buff, kim_DATA *d); 
extern inline 	int  sort_lrs		(int *a, int *b); 

extern inline 	char *cols_drs		(char *buff, kim_DATA *d); 
extern inline 	int  sort_drs		(int *a, int *b); 

extern inline	char *cols_swap		(char *buff, kim_DATA *d); 
extern inline 	int  sort_swap		(int *a, int *b); 

extern inline 	char *cols_minflt	(char *buff, kim_DATA *d); 
extern inline 	char *cols_majflt	(char *buff, kim_DATA *d); 
extern inline 	char *cols_cminflt	(char *buff, kim_DATA *d); 
extern inline 	char *cols_cmanflt	(char *buff, kim_DATA *d); 

extern inline 	char *cols_pcpu		(char *buff, kim_DATA *d); 
extern inline 	int  sort_pcpu		(int *a, int *b); 

extern inline 	char *cols_priority	(char *buff, kim_DATA *d); 
extern inline 	int  sort_priority	(int *a, int *b); 

extern inline 	char *cols_nice		(char *buff, kim_DATA *d); 
extern inline 	int  sort_nice		(int *a, int *b); 

extern inline 	char *cols_timeout	(char *buff, kim_DATA *d); 
extern inline 	int  sort_timeout	(int *a, int *b); 

extern inline	char *cols_time		(char *buff, kim_DATA *d); 
extern inline 	int  sort_time		(int *a, int *b); 

extern inline 	char *cols_ctime	(char *buff, kim_DATA *d); 
extern inline 	int  sort_ctime		(int *a, int *b); 

extern inline 	char *cols_flags	(char *buff, kim_DATA *d); 
extern inline 	char *cols_start_code	(char *buff, kim_DATA *d); 
extern inline 	char *cols_end_code	(char *buff, kim_DATA *d); 
extern inline 	char *cols_start_stack	(char *buff, kim_DATA *d); 
extern inline 	char *cols_kstk_esp	(char *buff, kim_DATA *d); 
extern inline 	char *cols_kstk_eip	(char *buff, kim_DATA *d); 
extern inline 	char *cols_wchan	(char *buff, kim_DATA *d); 
extern inline 	char *cols_signal	(char *buff, kim_DATA *d); 
extern inline 	char *cols_blocked	(char *buff, kim_DATA *d);
extern inline 	char *cols_sigignore	(char *buff, kim_DATA *d); 
extern inline 	char *cols_sigcatch	(char *buff, kim_DATA *d);

extern inline 	char *cols_alarm	(char *buff, kim_DATA *d);
extern inline 	int  sort_alarm		(int *a, int *b); 	
#endif /* __COLS_H */