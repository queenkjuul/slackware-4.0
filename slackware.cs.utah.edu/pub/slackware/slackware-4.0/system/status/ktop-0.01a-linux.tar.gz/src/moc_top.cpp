/****************************************************************************
** KTop meta object code from reading C++ file 'top.h'
**
** Created: Sun Mar 22 00:00:43 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.18 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include "top.h"
#include <qmetaobj.h>


const char *KTop::className() const
{
    return "KTop";
}

QMetaObject *KTop::metaObj = 0;

void KTop::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(KTopLevelWidget::className(), "KTopLevelWidget") != 0 )
	badSuperclassWarning("KTop","KTopLevelWidget");
    if ( !KTopLevelWidget::metaObject() )
	KTopLevelWidget::initMetaObject();
    typedef void(KTop::*m1_t0)();
    typedef void(KTop::*m1_t1)();
    typedef void(KTop::*m1_t2)();
    typedef void(KTop::*m1_t3)();
    typedef void(KTop::*m1_t4)();
    typedef void(KTop::*m1_t5)();
    typedef void(KTop::*m1_t6)();
    typedef void(KTop::*m1_t7)(int,int);
    typedef void(KTop::*m1_t8)();
    typedef void(KTop::*m1_t9)(int);
    typedef void(KTop::*m1_t10)(int);
    m1_t0 v1_0 = &KTop::tkill;
    m1_t1 v1_1 = &KTop::term;
    m1_t2 v1_2 = &KTop::renice;
    m1_t3 v1_3 = &KTop::me;
    m1_t4 v1_4 = &KTop::all;
    m1_t5 v1_5 = &KTop::other;
    m1_t6 v1_6 = &KTop::about;
    m1_t7 v1_7 = &KTop::ctxMenu;
    m1_t8 v1_8 = &KTop::refreshFont;
    m1_t9 v1_9 = &KTop::selItem;
    m1_t10 v1_10 = &KTop::selColumn;
    QMetaData *slot_tbl = new QMetaData[11];
    slot_tbl[0].name = "tkill()";
    slot_tbl[1].name = "term()";
    slot_tbl[2].name = "renice()";
    slot_tbl[3].name = "me()";
    slot_tbl[4].name = "all()";
    slot_tbl[5].name = "other()";
    slot_tbl[6].name = "about()";
    slot_tbl[7].name = "ctxMenu(int,int)";
    slot_tbl[8].name = "refreshFont()";
    slot_tbl[9].name = "selItem(int)";
    slot_tbl[10].name = "selColumn(int)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    metaObj = new QMetaObject( "KTop", "KTopLevelWidget",
	slot_tbl, 11,
	0, 0 );
}
