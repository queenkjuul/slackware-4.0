//top by mAc
#ifndef TOP_H
#define TOP_H

#include "mlist.h"
#include <kmenubar.h>
#include <ktopwidget.h>
#include "top_proc.h"

class KTop:public KTopLevelWidget {
Q_OBJECT 
public:
  KTop(QColor* sc,QFont *sf,const char* name=0);
  ~KTop();
private:
  int uid,currow,curpid,sortindex;
  KMenuBar* mainmenu;
  KMultiList* list;
  KStatusBar* status;
  int nproc;
  KTableColumns tc1;
  cpui oldin;
  proci *pin;
protected:
  virtual void timerEvent(QTimerEvent *);
public slots:
  void tkill();
  void term();
  void renice();
  void me();
  void all();
  void other();
  void about(); 
  void ctxMenu(int,int);
  void refreshFont(){list->refreshFont();}
  void selItem(int i){currow=i;if (tc1.cont!=0) curpid=atoi(tc1.cont[0][i]); else curpid=-1;}  
  void selColumn(int i){sortindex=i;timerEvent(0);}
};

#endif

