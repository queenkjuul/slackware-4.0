/****************************************************************************
** KTableView meta object code from reading C++ file 'mlist.h'
**
** Created: Sun Mar 22 00:00:35 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.18 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include "mlist.h"
#include <qmetaobj.h>


const char *KTableView::className() const
{
    return "KTableView";
}

QMetaObject *KTableView::metaObj = 0;

void KTableView::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QTableView::className(), "QTableView") != 0 )
	badSuperclassWarning("KTableView","QTableView");
    if ( !QTableView::metaObject() )
	QTableView::initMetaObject();
    typedef void(KTableView::*m1_t0)();
    m1_t0 v1_0 = &KTableView::redraw;
    QMetaData *slot_tbl = new QMetaData[1];
    slot_tbl[0].name = "redraw()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    typedef void(KTableView::*m2_t0)(int);
    typedef void(KTableView::*m2_t1)(int,int);
    m2_t0 v2_0 = &KTableView::selItem;
    m2_t1 v2_1 = &KTableView::rmbPress;
    QMetaData *signal_tbl = new QMetaData[2];
    signal_tbl[0].name = "selItem(int)";
    signal_tbl[1].name = "rmbPress(int,int)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    metaObj = new QMetaObject( "KTableView", "QTableView",
	slot_tbl, 1,
	signal_tbl, 2 );
}

// SIGNAL selItem
void KTableView::selItem( int t0 )
{
    activate_signal( "selItem(int)", t0 );
}

#if !defined(Q_MOC_CONNECTIONLIST_DECLARED)
#define Q_MOC_CONNECTIONLIST_DECLARED
#include <qlist.h>
#if defined(Q_DECLARE)
Q_DECLARE(QListM,QConnection);
Q_DECLARE(QListIteratorM,QConnection);
#else
// for compatibility with old header files
declare(QListM,QConnection);
declare(QListIteratorM,QConnection);
#endif
#endif

// SIGNAL rmbPress
void KTableView::rmbPress( int t0, int t1 )
{
    QConnectionList *clist = receivers("rmbPress(int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}


const char *KColHdr::className() const
{
    return "KColHdr";
}

QMetaObject *KColHdr::metaObj = 0;

void KColHdr::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QFrame::className(), "QFrame") != 0 )
	badSuperclassWarning("KColHdr","QFrame");
    if ( !QFrame::metaObject() )
	QFrame::initMetaObject();
    typedef void(KColHdr::*m2_t0)(QMouseEvent*);
    typedef void(KColHdr::*m2_t1)(QMouseEvent*);
    m2_t0 v2_0 = &KColHdr::mPress;
    m2_t1 v2_1 = &KColHdr::mRel;
    QMetaData *signal_tbl = new QMetaData[2];
    signal_tbl[0].name = "mPress(QMouseEvent*)";
    signal_tbl[1].name = "mRel(QMouseEvent*)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    metaObj = new QMetaObject( "KColHdr", "QFrame",
	0, 0,
	signal_tbl, 2 );
}

// SIGNAL mPress
void KColHdr::mPress( QMouseEvent* t0 )
{
    QConnectionList *clist = receivers("mPress(QMouseEvent*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(QMouseEvent*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL mRel
void KColHdr::mRel( QMouseEvent* t0 )
{
    QConnectionList *clist = receivers("mRel(QMouseEvent*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(QMouseEvent*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}


const char *KTableHdr::className() const
{
    return "KTableHdr";
}

QMetaObject *KTableHdr::metaObj = 0;

void KTableHdr::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QFrame::className(), "QFrame") != 0 )
	badSuperclassWarning("KTableHdr","QFrame");
    if ( !QFrame::metaObject() )
	QFrame::initMetaObject();
    typedef void(KTableHdr::*m1_t0)(QMouseEvent*);
    typedef void(KTableHdr::*m1_t1)(QMouseEvent*);
    m1_t0 v1_0 = &KTableHdr::mousePressEvent;
    m1_t1 v1_1 = &KTableHdr::mouseReleaseEvent;
    QMetaData *slot_tbl = new QMetaData[2];
    slot_tbl[0].name = "mousePressEvent(QMouseEvent*)";
    slot_tbl[1].name = "mouseReleaseEvent(QMouseEvent*)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    typedef void(KTableHdr::*m2_t0)(int);
    typedef void(KTableHdr::*m2_t1)();
    m2_t0 v2_0 = &KTableHdr::switchIt;
    m2_t1 v2_1 = &KTableHdr::redraw;
    QMetaData *signal_tbl = new QMetaData[2];
    signal_tbl[0].name = "switchIt(int)";
    signal_tbl[1].name = "redraw()";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    metaObj = new QMetaObject( "KTableHdr", "QFrame",
	slot_tbl, 2,
	signal_tbl, 2 );
}

// SIGNAL switchIt
void KTableHdr::switchIt( int t0 )
{
    activate_signal( "switchIt(int)", t0 );
}

// SIGNAL redraw
void KTableHdr::redraw()
{
    activate_signal( "redraw()" );
}


const char *KMultiList::className() const
{
    return "KMultiList";
}

QMetaObject *KMultiList::metaObj = 0;

void KMultiList::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("KMultiList","QWidget");
    if ( !QWidget::metaObject() )
	QWidget::initMetaObject();
    typedef void(KMultiList::*m1_t0)();
    m1_t0 v1_0 = &KMultiList::refreshFont;
    QMetaData *slot_tbl = new QMetaData[1];
    slot_tbl[0].name = "refreshFont()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    typedef void(KMultiList::*m2_t0)(int);
    typedef void(KMultiList::*m2_t1)(int);
    typedef void(KMultiList::*m2_t2)(int,int);
    m2_t0 v2_0 = &KMultiList::selItem;
    m2_t1 v2_1 = &KMultiList::selColumn;
    m2_t2 v2_2 = &KMultiList::rmbPress;
    QMetaData *signal_tbl = new QMetaData[3];
    signal_tbl[0].name = "selItem(int)";
    signal_tbl[1].name = "selColumn(int)";
    signal_tbl[2].name = "rmbPress(int,int)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    signal_tbl[2].ptr = *((QMember*)&v2_2);
    metaObj = new QMetaObject( "KMultiList", "QWidget",
	slot_tbl, 1,
	signal_tbl, 3 );
}

// SIGNAL selItem
void KMultiList::selItem( int t0 )
{
    activate_signal( "selItem(int)", t0 );
}

// SIGNAL selColumn
void KMultiList::selColumn( int t0 )
{
    activate_signal( "selColumn(int)", t0 );
}

// SIGNAL rmbPress
void KMultiList::rmbPress( int t0, int t1 )
{
    QConnectionList *clist = receivers("rmbPress(int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(int);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(int,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}
