//top by mAc
//proc fs routines
#ifndef TOP_PROC_H
#define TOP_PROC_H

struct cpui{int user,nice,system,idle;};
struct memi{int total,used,free,shared,buffers,cached,stotal,sused,sfree;};
struct proci{int pid,pri,nice,uid; unsigned rss,size,time; float cpu,mem; char command[30],user[30];char state;};

int readcpui(cpui &in);
int readmemi(memi &in);
int readnproc(void);
int readproci(proci &in);
int fillproci(int n,proci *in, int j,int mems);

#endif

