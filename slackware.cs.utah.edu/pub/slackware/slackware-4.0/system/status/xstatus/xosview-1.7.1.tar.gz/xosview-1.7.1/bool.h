#ifndef HAVE_BOOL
#define bool Bool_XOS
#define false False_XOS
#define true True_XOS
typedef int Bool_XOS; 
static const Bool_XOS False_XOS = 0, True_XOS = 1; 
#endif
