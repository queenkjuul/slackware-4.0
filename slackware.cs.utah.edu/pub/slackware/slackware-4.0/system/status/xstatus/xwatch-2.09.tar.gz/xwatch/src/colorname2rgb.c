/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */
#include "xwatch.h"

#ifndef RGB_FILE
#define RGB_FILE "/usr/lib/X11/rgb.txt"
#endif

int colorname2rgb (char *name, int *r, int *g, int *b)
{
    FILE 
        *fp = NULL;
    char 
        dummy[256],
	line [256];
    int 
        red,
	green,
	blue,
	retval = 0;
        
    if (! name || ! *name)                      /* need a real name arg */
        return (0);
    
    if (! (fp = fopen(RGB_FILE, "r")) )         /* open database file */
    {
        warning ("Cannot read RGB database %s", RGB_FILE);
        warning ("(%s)", strerror (errno));
        return (0);
    }
        
    while (1)                                   /* scan whole file */
    {
        fgets (line, 256, fp);                  /* read one line */
        if (feof (fp))                          /* eof? done.. */
        {
            warning ("Couldn't find color %s in RGB database %s", 
	             name, RGB_FILE);
            break;
        }
                  
        /* convert to number number number name */
        if (sscanf (line, "%d %d %d %[^\n]", &red, &green, &blue, dummy) > 3)
        {
            while (isspace (dummy[0])) 
	        strcpy (dummy, dummy + 1);
            if (! strcasecmp (dummy, name))
            {
                *r = red;
                *g = green;
                *b = blue;
                retval = 1;
                break;
            }
        }
    }
    
    fclose (fp);
    return (retval);
}
