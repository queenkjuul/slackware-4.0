/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */

#include "xwatch.h"

void usage ()
{
    printf
(
 "\n"
 "X File Watcher  V" VER "\n"
 "Copyright (c) Karel Kubat (karel@icce.rug.nl), (ICCE) 1995,1996.\n"
 "All rights reserved.\n"
 "Maintained by Frank Brokken (frank@icce.rug.nl).\n"
 "Another MegaHard Production!\n"
 "\n"
 "Usage: xwatch [options] file(s)\n"
 "where:\n"
 "  options may be:\n"
 "   XForms options:\n"
 "    -bw width                     - specifies border width\n"
 "    -debug level                  - debugging level\n"
 "    -depth d                      - visual depth\n"
 "    -double                       - turns on double buffering\n"
 "    -display host:display         - the display, default: $DISPLAY\n"
 "    -name applicationname         - application name, default: XWatch\n"
 "    -private, -shared, -stdcmap   - private or shared or standard colormap\n"
 "    -rgamma red, -ggamma green,\n"
 "        -bgamma blue              - gamma for red/green/blue components\n"
 "    -sync                         - forces synchronous mode\n"
 "    -vid id                       - preferred visual ID\n"
 "    -visual class                 - visual class, e.g. TrueColor\n"
 "   Xwatch options: (# stands for a number, [..] means default)\n"
 "    -border 0|1           - start text window with or without border   [1]\n"
 "    -bg R/G/B or -bg col  - states background color, either as three\n"
 "                            red/green/blue numbers or as one name  [white]\n"
 "    -colorstring col:text - uses color for lines having text in them\n"
 "    -firstwarnings 0|1    - print warnings about files upon startup    [1]\n"
 "    -fg R/G/B or -fg col  - states foreground                      [black]\n"
 "    -fontsize #           - size of font: 1=smallest, 4=largest        [2]\n"
 "    -fontstyle #          - used font:\n"
 "                             0=helvetica, 1=+bold, 2=+italic, 3=bold/it\n"
 "                             4=courier,   5=+bold, 6=+italic, 7=bold/it\n"
 "                             8=times,     9=+bold,10=+italic,11=bold/it\n"
 "                            12=charter,  13=+bold,14=+italic,\n"
 "                            15=symbol                                  [0]\n"
 "    -gag text             - don't show lines with text              [none]\n"
 "    -ignore file|file|... - do not add named files to the watchlist\n"
 "    -interval #           - scanning interval in sec, 1 to 30          [5]\n"
 "    -newline 0|1          - print newline after stamp and name         [0]\n"
 "    -nlines #             - nr of lines to store; 10 to 1000         [200]\n"
 "    -printname 0|1        - print filenames                            [1]\n"
 "    -printtime 0|1        - print timestamps                           [1]\n"
 "    -printversion 0|1     - print version/copyright upon startup       [1]\n"
 "    -title name           - use name for window title             [XWatch]\n"
 "    -geometry geom        - display geometry                  [550x70+0+0]\n"
 "   Obsolete options, replace with newer alternatives:\n"
 "    -width, -height, -xpos, -ypos: replace by -geometry\n"
 "    -bred, -bgreen, -bblue: replace by -bg\n"
 "    -fred, -fgreen, -fblue: replace by -fg\n"
 "  file(s): the files to monitor. You can specify an alternate color for\n"
 "  a file using the syntax filename:colorname, in which the colorname\n"
 "  overrules the default foreground color.\n"
 "\n"
 );

    exit (1);
}
