/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */

#include "xwatch.h"

void addfile (char *filename)
{
    struct stat
	statbuf;
    char
	buf [512],
        fname [1000],
	*cp;
    FILE
	*f;
    int
	i,
	inode,
	readres,
	colorindex;
        
    colorindex = foregr;                                /* assume std foregr */
    
    cp = strchr (filename, ':');                        /* try to split name */
    if (cp)
    {
        *cp = '\0';                                     /* cut off : part */
        cp++;                                           /* cp points to */
        if (! *cp)                                      /* color info */
            cp = NULL;
    }
        
    strcpy (fname, filename);                           /* get filename */
    if (cp)                                             /* handle color */
        colorindex = colorname2index (cp);              /* colorspec here */

    if (stat (fname, &statbuf))                         /* see if file */
    {                                                   /* exists */
	if (firstwarnings)
	    warning ("Cannot find %s: %s", fname, strerror (errno));
	return;
    }

    if (! S_ISREG (statbuf.st_mode))                    /* is it ordinary */
    {                                                   /* file */
	if (firstwarnings)
	    warning ("%s is not a regular file", fname);
	return;
    }

    inode = statbuf.st_ino;

    if (! (f = fopen (fname, "r")) )                    /* is it a textfile */
    {
	if (firstwarnings)
	    warning ("Cannot read %s: %s", fname, strerror (errno));
	return;
    }
    readres = fread (buf, 1, sizeof (buf), f);
    for (i = 0; i < readres; i++)
	if (! buf [i])
	{
	    if (firstwarnings)
		warning ("File %s is a binary file", fname);
	    fclose (f);
	    return;
	}
    fclose (f);

    for (i = 0; i < nfinfo; i++)                        /* do we already */
	if (finfo [i].inode == inode)                   /* have the file */
	{
	    if (firstwarnings)
		warning ("Names %s and %s are the the same file",
		     fname, finfo [i].name);
	    return;
	}

    /* after all the checks, add it to our list */
    finfo = (Fileinfo *) xrealloc (finfo, (nfinfo + 1) * sizeof (Fileinfo));
    finfo [nfinfo].name = xstrdup (fname);
    finfo [nfinfo].active = 1;
    finfo [nfinfo].inode = inode;
    finfo [nfinfo].offset = statbuf.st_size;
    finfo [nfinfo].colorindex = colorindex;
    nfinfo++;
}
	
