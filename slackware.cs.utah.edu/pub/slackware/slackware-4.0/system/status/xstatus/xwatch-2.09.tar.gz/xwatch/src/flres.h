/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */

static FL_CMD_OPT cmdopt [] =	    /* resource options */
{
    { "-border",        "*.border",        XrmoptionSepArg, 0 },
    { "-printtime",     "*.printtime",     XrmoptionSepArg, 0 },
    { "-printname",     "*.filename",      XrmoptionSepArg, 0 },
    { "-newline",       "*.newline",       XrmoptionSepArg, 0 },
    { "-nlines",        "*.nlines",        XrmoptionSepArg, 0 },
    { "-interval",      "*.interval",      XrmoptionSepArg, 0 },
    { "-linelen",       "*.linelen",       XrmoptionSepArg, 0 },
    { "-fontsize",      "*.fontsize",      XrmoptionSepArg, 0 },
    { "-fontstyle",     "*.fontstyle",     XrmoptionSepArg, 0 },
    { "-firstwarnings", "*.firstwarnings", XrmoptionSepArg, 0 },
    { "-printversion",  "*.printversion",  XrmoptionSepArg, 0 },
    { "-gag",           "*.gag",           XrmoptionSepArg, 0 },
    { "-title",         "*.title",         XrmoptionSepArg, 0 },
    { "-colorstring",   "*.colorstring",   XrmoptionSepArg, 0 },
    { "-geometry",      "*.geometry",      XrmoptionSepArg, 0 },
    { "-ignore",        "*.ignore",        XrmoptionSepArg, 0 },
    { "-fg",            "*.foreground",    XrmoptionSepArg, 0 },
    { "-bg",            "*.background",    XrmoptionSepArg, 0 },
};

static FL_resource res [] =
{
    { "border",        "XWatch", FL_INT,    &border,             "1",   0 },
    { "printtime",     "XWatch", FL_INT,    &printtime,          "1",   0 },
    { "printname",     "XWatch", FL_INT,    &printname,          "1",   0 },
    { "newline",       "XWatch", FL_INT,    &newline,            "0",   0 },
    { "nlines",        "XWatch", FL_INT,    &nlines,             "200", 0 },
    { "interval",      "XWatch", FL_INT,    &interval,           "5",   0 },
    { "fontsize",      "XWatch", FL_INT,    &fontsize,           "2",   0 },
    { "fontstyle",     "XWatch", FL_INT,    &fontstyle,          "0",   0 },
    { "firstwarnings", "XWatch", FL_INT,    &firstwarnings,      "1",   0 },
    { "printversion",  "XWatch", FL_INT,    &printversion,	 "1",   0 },
    { "gag",           "XWatch", FL_STRING, gagbuffer,           "", 1023 },
    { "title",         "XWatch", FL_STRING, titlebuffer,         "",  127 },
    { "colorstring",   "XWatch", FL_STRING, colorstring,         "", 1023 },
    { "geometry",      "XWatch", FL_STRING, geometry,  "550x70+0+0",   79 },
    { "ignore",        "XWatch", FL_STRING, ignorestring,        "", 1023 },
    { "foreground",    "XWatch", FL_STRING, fgstring,       "black",   79 },
    { "background",    "XWatch", FL_STRING, bgstring,       "white",   79 },
};
