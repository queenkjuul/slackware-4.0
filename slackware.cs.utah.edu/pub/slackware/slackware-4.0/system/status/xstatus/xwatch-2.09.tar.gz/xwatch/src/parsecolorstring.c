/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */

#include "xwatch.h"

void parsecolorstring (char *buf)
{
    char
        *cp,
	str [256],
        matchstr [256],
        colorname [256];
    int
        r,
        g,
        b;

    if (! *buf)
        return;
        
        
    cp = strtok (buf, "|");
    while (cp && *cp)
    {
        strncpy (str, cp, 255);
        while (isspace (str [0]))
            strcpy (str, str + 1);
        cp = str + strlen (str) - 1;
        while (isspace (*cp) && cp > str)
        {
            *cp = '\0';
            cp--;
        }
        
        if (str [0]) 
        {           
            if (sscanf (str,"%[^:]:%s", colorname, matchstr) > 1 &&
                colorname2rgb (colorname, &r, &g, &b))
            {
                colorstring = xrealloc (colorstring, (ncolorstring + 1) *
                    sizeof (Colorstring));
                colorstring [ncolorstring].colorindex = 
                    getcolorindex (r, g, b);
                colorstring [ncolorstring].str = xstrdup (matchstr);
                ncolorstring++;
            }
        }
        cp = strtok (NULL, "|");
    }
}
