/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */
/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "ui.h"

FL_FORM *browser_form;

FL_OBJECT
        *watch_browser;

void create_form_browser_form(void)
{
  FL_OBJECT *obj;

  if (browser_form)
     return;

  browser_form = fl_bgn_form(FL_NO_BOX,550,70);
  obj = fl_add_box(FL_UP_BOX,0,0,550,70,"");
  watch_browser = obj = fl_add_browser(FL_NORMAL_BROWSER,0,0,550,70,"");
    fl_set_object_color(obj,FL_WHITE,FL_YELLOW);
    fl_set_object_lcol(obj,FL_RED);
  fl_end_form();

}
/*---------------------------------------*/

void create_the_forms(void)
{
  create_form_browser_form();
}

