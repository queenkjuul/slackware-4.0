/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */

#include "xwatch.h"

void *xrealloc (void *mem, int newsz)
{
    if (! mem)                          /* SUN's realloc() doesn't handle */
        mem = malloc (newsz);           /* a 0-pointer too well as first */
    else                                /* argument.. thanx, */
        mem = realloc (mem, newsz);     /* Christian Motschke, */
                                        /* <motschke@prosun.first.gmd.de> */

    if (! mem)
        error ("out of memory");

    return (mem);
}
