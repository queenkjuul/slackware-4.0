#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mempeak.h"
#include "mem.h"

extern char time_now[9];
extern mem_struct meminfo;

void mem_init() {
    meminfo.memtotal             = 0;
    meminfo.swaptotal            = 0;
    meminfo.memused              = 0;
    meminfo.memused_max          = 0;
    meminfo.memused_min  = 999999999;
    meminfo.swapused             = 0;
    meminfo.swapused_max         = 0;
    meminfo.swapused_min = 999999999;
    meminfo.memfree              = 0;
    meminfo.memfree_max          = 0;
    meminfo.memfree_min  = 999999999;
    meminfo.memshared            = 0;
    meminfo.memshared_max        = 0;
    meminfo.memshared_min= 999999999;
    meminfo.buffers              = 0;
    meminfo.buffers_max          = 0;
    meminfo.buffers_min  = 999999999;
    meminfo.cached               = 0;
    meminfo.cached_max           = 0;
    meminfo.cached_min   = 999999999;
    meminfo.swapfree             = 0;
    meminfo.swapfree_max         = 0;
    meminfo.swapfree_min = 999999999;
    strcpy(meminfo.memused_max_time, time_now);
    strcpy(meminfo.memused_min_time, time_now);
    strcpy(meminfo.swapused_max_time, time_now);
    strcpy(meminfo.swapused_min_time, time_now);
    strcpy(meminfo.memfree_max_time, time_now);
    strcpy(meminfo.memfree_min_time, time_now);
    strcpy(meminfo.memshared_max_time, time_now);
    strcpy(meminfo.memshared_min_time, time_now);
    strcpy(meminfo.buffers_max_time, time_now);
    strcpy(meminfo.buffers_min_time, time_now);
    strcpy(meminfo.cached_max_time, time_now);
    strcpy(meminfo.cached_min_time, time_now);
    strcpy(meminfo.swapfree_max_time, time_now);
    strcpy(meminfo.swapfree_min_time, time_now);
    mem_update();
}

void mem_update() {
    FILE *fp;
    char zeile[81];
    char tmpvar[81];
    
    fp = fopen(infofile, "r");
    if (fp == NULL) {
        printf("Fehler beim Oeffnen der Datei\n");
    } else {
        while (fgets(zeile, 81, fp) != NULL) {
            if (strstr(zeile, "MemTotal:") != NULL) {
                cutword(tmpvar, zeile, 2);
                meminfo.memtotal = atol(tmpvar);
            }
            if (strstr(zeile, "MemFree:") != NULL) {
                cutword(tmpvar, zeile, 2);
                meminfo.memfree = atol(tmpvar);
            }
            if (strstr(zeile, "MemShared:") != NULL) {
                cutword(tmpvar, zeile, 2);
                meminfo.memshared = atol(tmpvar);
            }
            if (strstr(zeile, "Buffers:") != NULL) {
                cutword(tmpvar, zeile, 2);
                meminfo.buffers = atol(tmpvar);
            }
            if (strstr(zeile, "Cached:") != NULL) {
                cutword(tmpvar, zeile, 2);
                meminfo.cached = atol(tmpvar);
            }
            if (strstr(zeile, "SwapTotal:") != NULL) {
                cutword(tmpvar, zeile, 2);
                meminfo.swaptotal = atol(tmpvar);
            }
            if (strstr(zeile, "SwapFree:") != NULL) {
                cutword(tmpvar, zeile, 2);
                meminfo.swapfree = atol(tmpvar);
            }
        }
    }
    if (fclose(fp) != 0) printf("Error closing file\n");
    meminfo.memused = meminfo.memtotal - meminfo.memfree;
    meminfo.swapused = meminfo.swaptotal - meminfo.swapfree;
    if (meminfo.memused > meminfo.memused_max) {
        meminfo.memused_max = meminfo.memused;
        strcpy(meminfo.memused_max_time, time_now);
    }
    if (meminfo.memused < meminfo.memused_min) {
        meminfo.memused_min = meminfo.memused;
        strcpy(meminfo.memused_min_time, time_now);
    }
    
    if (meminfo.memfree > meminfo.memfree_max) {
        meminfo.memfree_max = meminfo.memfree;
        strcpy(meminfo.memfree_max_time, time_now);
    }
    if (meminfo.memfree < meminfo.memfree_min) {
        meminfo.memfree_min = meminfo.memfree;
        strcpy(meminfo.memfree_min_time, time_now);
    }
    if (meminfo.memshared > meminfo.memshared_max) {
        meminfo.memshared_max = meminfo.memshared;
        strcpy(meminfo.memshared_max_time, time_now);
    }
    if (meminfo.memshared < meminfo.memshared_min) {
        meminfo.memshared_min = meminfo.memshared;
        strcpy(meminfo.memshared_min_time, time_now);
    }
    if (meminfo.buffers > meminfo.buffers_max) {
        meminfo.buffers_max = meminfo.buffers;
        strcpy(meminfo.buffers_max_time, time_now);
    }
    if (meminfo.buffers < meminfo.buffers_min) {
        meminfo.buffers_min = meminfo.buffers;
        strcpy(meminfo.buffers_min_time, time_now);
    }
    if (meminfo.cached > meminfo.cached_max) {
        meminfo.cached_max = meminfo.cached;
        strcpy(meminfo.cached_max_time, time_now);
    }
    if (meminfo.cached < meminfo.cached_min) {
        meminfo.cached_min = meminfo.cached;
        strcpy(meminfo.cached_min_time, time_now);
    }
    if (meminfo.swapfree > meminfo.swapfree_max) {
        meminfo.swapfree_max = meminfo.swapfree;
        strcpy(meminfo.swapfree_max_time, time_now);
    }
    if (meminfo.swapfree < meminfo.swapfree_min) {
        meminfo.swapfree_min = meminfo.swapfree;
        strcpy(meminfo.swapfree_min_time, time_now);
    }
    if (meminfo.swapused > meminfo.swapused_max) {
        meminfo.swapused_max = meminfo.swapused;
        strcpy(meminfo.swapused_max_time, time_now);
    }
    if (meminfo.swapused < meminfo.swapused_min) {
        meminfo.swapused_min = meminfo.swapused;
        strcpy(meminfo.swapused_min_time, time_now);
    }
}
