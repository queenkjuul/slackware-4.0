void set_defaults(void);
void get_color(char *outstr, char *instr, char mode);
void readconfig(void);

typedef struct set_struct
{
    int interval;
    int timeupdate_sec;
    int runonly;
    int display_userid;
    int cursoroff;
    int colorbold;
    char display_username[len_line];
    char color_bg[len_color];
    char color_head_bg[len_color];
    char color_head_fg[len_color];
    char color_legend[len_color];
    char color_mem_keys[len_color];
    char color_mem_max[len_color];
    char color_mem_min[len_color];
    char color_proc_running[len_color];
    char color_proc_notrunning[len_color];
    char color_help[len_color];
    char color_warning[len_color];
} set_struct;

