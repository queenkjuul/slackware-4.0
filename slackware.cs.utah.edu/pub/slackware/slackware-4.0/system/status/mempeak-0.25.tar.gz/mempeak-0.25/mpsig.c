#include <stdio.h>
#include <signal.h>
#include "mempeak.h"

void sig_int(int sig) {
    signal(SIGINT, SIG_IGN);
    mempeak_exit(error_sigint);
}

void sig_init() {
    if (signal(SIGINT, sig_int) == SIG_ERR) {
        printf("Sig-Error\n");
        exit(0);
    }
}

