void sig_int(int sig);
void sig_init(void);
