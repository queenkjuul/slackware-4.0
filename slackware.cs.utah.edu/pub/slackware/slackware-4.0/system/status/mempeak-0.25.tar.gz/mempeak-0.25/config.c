#include <stdio.h>
#include <stdlib.h>
#include "mempeak.h"
#include "tkansi.h"
#include "config.h"

extern char configfile[];
extern set_struct set;

void set_defaults() {
    set.interval = default_interval;
    set.timeupdate_sec = 0;
    set.runonly = 0;
    set.display_userid = -1;
    strcpy(set.display_username, "");
    set.cursoroff = 0;
    set.colorbold = 0;
    strcpy(set.color_bg, on_black);
    strcpy(set.color_head_bg, on_blue);
    strcpy(set.color_head_fg, white);
    strcpy(set.color_legend, yellow);
    strcpy(set.color_mem_keys, white);
    strcpy(set.color_mem_max, green);
    strcpy(set.color_mem_min, red);
    strcpy(set.color_proc_running, cyan);
    strcpy(set.color_proc_notrunning, blue);
    strcpy(set.color_help, white);
    strcpy(set.color_warning, red);
}

void get_color(char *outstr, char *instr, char mode) {
    if (mode == 'f') {
        if (strcmp(instr, "black") == 0)   strcpy(outstr, black);
        if (strcmp(instr, "red") == 0)     strcpy(outstr, red);
        if (strcmp(instr, "green") == 0)   strcpy(outstr, green);
        if (strcmp(instr, "yellow") == 0)  strcpy(outstr, yellow);
        if (strcmp(instr, "blue") == 0)    strcpy(outstr, blue);
        if (strcmp(instr, "magenta") == 0) strcpy(outstr, magenta);
        if (strcmp(instr, "cyan") == 0)    strcpy(outstr, cyan);
        if (strcmp(instr, "white") == 0)   strcpy(outstr, white);
    } else if (mode == 'b') {
        if (strcmp(instr, "black") == 0)   strcpy(outstr, on_black);
        if (strcmp(instr, "red") == 0)     strcpy(outstr, on_red);
        if (strcmp(instr, "green") == 0)   strcpy(outstr, on_green);
        if (strcmp(instr, "yellow") == 0)  strcpy(outstr, on_yellow);
        if (strcmp(instr, "blue") == 0)    strcpy(outstr, on_blue);
        if (strcmp(instr, "magenta") == 0) strcpy(outstr, on_magenta);
        if (strcmp(instr, "cyan") == 0)    strcpy(outstr, on_cyan);
        if (strcmp(instr, "white") == 0)   strcpy(outstr, on_white);
    }
}

void readconfig() {
    char zeile[len_line], keyword[len_line], value[len_line];
    FILE *fp;

    fp = fopen(configfile, "r");
    if (fp != NULL) {
        while (fgets(zeile, len_line, fp) != NULL) {
            if (strlen(zeile) == 1) continue;
            if (zeile[0] == '#')    continue;
            chomp(zeile);
            if (cutword(keyword, zeile, 1) == -1) error("Error in config-file", error_config);
            if (cutword(value, zeile, 2)   == -1) error("Error in config-file", error_config);
            if (strcmp(keyword, "screenmode") == 0) {
                if (strcmp(value, "bold") == 0) set.colorbold = 1;
                else if (strcmp(value, "normal") == 0) set.colorbold = 0;
            }
            if (strcmp(keyword, "color_bg") == 0)                   get_color(set.color_bg, value, 'b');
            else if (strcmp(keyword, "color_head_bg") == 0)         get_color(set.color_head_bg, value, 'b');
            else if (strcmp(keyword, "color_head_fg") == 0)         get_color(set.color_head_fg, value, 'f');
            else if (strcmp(keyword, "color_legend") == 0)          get_color(set.color_legend, value, 'f');
            else if (strcmp(keyword, "color_mem_keys") == 0)        get_color(set.color_mem_keys, value, 'f');
            else if (strcmp(keyword, "color_mem_max") == 0)         get_color(set.color_mem_max, value, 'f');
            else if (strcmp(keyword, "color_mem_min") == 0)         get_color(set.color_mem_min, value, 'f');
            else if (strcmp(keyword, "color_proc_running") == 0)    get_color(set.color_proc_running, value, 'f');
            else if (strcmp(keyword, "color_proc_notrunning") == 0) get_color(set.color_proc_notrunning, value, 'f');
            else if (strcmp(keyword, "color_help") == 0)            get_color(set.color_help, value, 'f');
            else if (strcmp(keyword, "color_warning") == 0)         get_color(set.color_warning, value, 'f');
            else if (strcmp(keyword, "interval") == 0)              set.interval = atoi(value);
            else if (strcmp(keyword, "cursor") == 0) {
                if (strcmp(value, "on") == 0) set.cursoroff = 0;
                else if (strcmp(value, "off") == 0) set.cursoroff = 1;
            }
            else if (strcmp(keyword, "runonly") == 0) {
                if (strcmp(value, "on") == 0) set.runonly = 1;
                else if (strcmp(value, "off") == 0) set.runonly = 0;
            }
            else if (strcmp(keyword, "timeupdate") == 0) {
                if (strcmp(value, "interval") == 0) set.timeupdate_sec = 0;
                else if (strcmp(value, "second") == 0) set.timeupdate_sec = 1;
            }
        }
        fclose(fp);
    }
}
