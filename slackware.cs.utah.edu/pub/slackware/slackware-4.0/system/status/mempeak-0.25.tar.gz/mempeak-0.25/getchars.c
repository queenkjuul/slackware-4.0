#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>
#include "getchars.h"

/* getch and getche returns -1, or the char 
 * getchp/getchpe returns -1 if no char is pending, -2 on error, or the char
 */

int getch(void)
{
    struct termios term_settings,term_settings_saved;
    int x;
    if ( tcgetattr(STDIN_FILENO,&term_settings))
        return -1;
    term_settings_saved=term_settings;
    term_settings.c_lflag &= ~ICANON ;
    term_settings.c_lflag &= ~ECHO ;
    term_settings.c_cc[VMIN]=1 ;
    term_settings.c_cc[VTIME]=0;
    if (tcsetattr (STDIN_FILENO, TCSANOW, &term_settings) < 0 )
        return -1;
    x=getchar();
    tcsetattr (STDIN_FILENO, TCSANOW, &term_settings_saved);
    return x;
}

int getche(void)
{
    struct termios term_settings,term_settings_saved;
    int x;
    if ( tcgetattr(STDIN_FILENO,&term_settings))
        return -1;
    term_settings_saved=term_settings;
    term_settings.c_lflag &= ~ICANON ;
    term_settings.c_lflag |= ECHO ;
    term_settings.c_cc[VMIN]=1 ;
    term_settings.c_cc[VTIME]=0;
    if (tcsetattr (STDIN_FILENO, TCSANOW, &term_settings) < 0 )
        return -1;
    x=getchar();
    tcsetattr (STDIN_FILENO, TCSANOW, &term_settings_saved);
    return x;
}

/* getch pending or getch predicate if you like */
/* this is something like '?key' in forth, or was it 'key?' ? */

int getchp(void)
{
    struct termios term_settings,term_settings_saved;
    char c;
    int x;
    if ( tcgetattr(STDIN_FILENO,&term_settings))
        return -2;
    term_settings_saved=term_settings;
    term_settings.c_lflag &= ~ICANON ;
    term_settings.c_lflag &= ~ECHO ;
    term_settings.c_cc[VMIN]=0;
    term_settings.c_cc[VTIME]=0;
    if (tcsetattr (STDIN_FILENO, TCSANOW, &term_settings) < 0 )
        return -2;
    switch(read(STDIN_FILENO,&c,1))
    {
    case 0: x=-1; break;
    case -1: x=-2; break;
    default: x=c;
    }
    tcsetattr (STDIN_FILENO, TCSANOW, &term_settings_saved);
    return x;
}

int getchpe(void)
{
    struct termios term_settings,term_settings_saved;
    char c;
    int x;
    if ( tcgetattr(STDIN_FILENO,&term_settings))
        return -2;
    term_settings_saved=term_settings;
    term_settings.c_lflag &= ~ICANON ;
    term_settings.c_lflag |= ECHO ;
    term_settings.c_cc[VMIN]=0;
    term_settings.c_cc[VTIME]=0;
    if (tcsetattr (STDIN_FILENO, TCSANOW, &term_settings) < 0 )
        return -2;
    switch(read(STDIN_FILENO,&c,1))
    {
    case 0: x=-1; break;
    case -1: x=-2; break;
    default:     x=c;
    }
    tcsetattr (STDIN_FILENO, TCSANOW, &term_settings_saved);
    return x;
}
