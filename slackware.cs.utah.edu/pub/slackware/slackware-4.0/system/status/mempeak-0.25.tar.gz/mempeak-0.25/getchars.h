int getch(void);
int getche(void);
int getchp(void);
int getchpe(void);
