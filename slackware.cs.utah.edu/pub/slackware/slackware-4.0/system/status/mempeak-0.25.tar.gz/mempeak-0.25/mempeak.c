/*

   mempeak (c) Thomas Kluge 1997-1998

   Mempeak is a small utility for Linux that displays information on
   maximum and minimum memory-usage on your system. Additionaly,
   mempeak shows a list of processes consuming most memory.
   
   Mempeak is NOT another 'top'!

   Mempeak was developed with gcc version 2.7.2.1.

   Mempeak is distributed under the terms of the General Public Licence
   (GPL), please have a look at the file LICENSE included in this package.

   If you need installation-instructions, please read INSTALL

   If you need instructions on using mempeak, please type 'man mempeak'
   after you've succesfully completed the installation.

   thomas@darkstar.rhein-neckar.de
   
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <pwd.h>

#include "mempeak.h"
#include "tkansi.h"
#include "getchars.h"
#include "proc.h"
#include "mem.h"
#include "config.h"
#include "mpsig.h"

// global variables

char homedir[len_path];
char configfile[len_path];
int process_count = -1;
ps_struct *process;
mem_struct meminfo;
set_struct set;
char time_now[len_time];
int proc_max;
int proc_lines;
int lastline;
int proc_sum;

// some utility-functions

int cutword(char *changestr, char *instr, int pos) {
    int rc, wcount = 0;
    char *txt, *ptr, *sep = " \t", nothing[] = "";

    if (strlen(instr) == 0) {
        strcpy(changestr, nothing);
        return -1;
    }
    pos--;
    if ((txt = strdup(instr)) == NULL) {
        perror("strdup");
    }
    ptr = strtok(txt, sep);
    if (wcount == pos) {
        strcpy(changestr, ptr);
        free(txt);
        return wcount;
    }
    while(ptr != NULL) {
        ptr = strtok(NULL, sep);
        wcount++;
        if (wcount == pos) {
            if (ptr != NULL) {
                strcpy(changestr, ptr);
                rc = wcount;
            } else {
                strcpy(changestr, "");
                rc = -1;
            }
            free(txt);
            return rc;
        }
    }
    strcpy(changestr, nothing);
    free(txt);
    return -1;
}

int limit_str(char *instr, int maxlen) {
    if (strlen(instr) > maxlen) {
        instr[maxlen] = '\0';
        return maxlen;
    } else return 0;
}

int chomp(char *instr) {
    int rc = 0;
    
    if (instr[strlen(instr)-1] == '\n') {
        instr[strlen(instr)-1] = '\0';
        rc = 1;
    }
    return rc;
}

int string_is_digit (char *instr) {
    int i, sid = 1;

    for (i = 0; i < strlen(instr); i++) {
        if (isdigit(instr[i]) == 0) {
            sid = 0;
        }
    }
    return sid;
}

int isdir(char *path) {
    struct stat stbuf;

    if (stat(path, &stbuf) != -1) {
        if (stbuf.st_mode & S_IFDIR) return 1;
        else return 0;
    } else return 0;
}

int get_uid(char *login_name) {
    struct passwd *pw_entry;

    pw_entry = getpwnam(login_name);
    if (pw_entry == NULL) return -1;
    else return pw_entry->pw_uid;
}

char *get_uname(int uid) {
    struct passwd *pw_entry;

    pw_entry = getpwuid(uid);
    return pw_entry->pw_name;
}

int term_getlines(int fd) {
    struct winsize size;
    
    if (ioctl(fd, TIOCGWINSZ, (char *)&size) < 0) return 0;
    return size.ws_row;
}

void error(char *errtxt, int errcode) {
    mempeak_cleanup();
    printf("\n%s%s\n", error_header, errtxt);
    exit(errcode);
}

// here it starts

void mempeak_init() {
    struct passwd *pw;

    sig_init();
    set_defaults();
    lastline = term_getlines(STDIN_FILENO);
    if ((pw = getpwuid (getuid ())) == NULL) error("Out of memory!", error_mem);
    strcpy(homedir, pw->pw_dir);
    strcpy(configfile, homedir);
    strcat(configfile, "/.mempeak");
    size_set();
    readconfig();
}

void screen_init() {
    if (set.cursoroff) cursor_off;
    if (set.colorbold == 1) BOLD;
}

void mempeak_cleanup() {
    if (process) free(process);
    if (set.cursoroff) cursor_on;
    NORMAL;
}

void mempeak_exit(int rc) {
    mempeak_cleanup();
    printf(end_msg);
    exit(rc);
}

void size_set() {
    if (term_getlines(STDIN_FILENO) <= lines_min) {
        error("Window too small", error_display);
    }
    proc_lines = term_getlines(STDIN_FILENO) - lines_min;
    proc_max   = (proc_lines * 2) - 1;
    lastline   = term_getlines(STDIN_FILENO);
}

int size_changed() {
    if ((term_getlines(STDIN_FILENO) - 14) != proc_lines) return 1;
    return 0;
}

void help() {
    printf("%s\n\n", version);
    printf("mempeak [options]\n\n");
    printf("Commandline options:\n");
    printf("-i n     Set update interval to n seconds\n");
    printf("-r       Display only processes that are still running\n");
    printf("-u name  Display only processes owned by name\n");
    printf("-c       Switch off cursor for smoother display (may not work an every system)\n");
    printf("-b       Bold display\n");
    printf("-s       Update the time-display each second, not each interval\n");
    printf("-h       Show this help\n");
    mempeak_cleanup();
    exit(error_normal);
}

void help_online() {
    char input;
    
    setcolor(set.color_bg);
    clrscr;
    head();
    setcolor(set.color_help);
    setcolor(set.color_bg);
    locate(3,1);
    printf(" What it does\n\n");
    printf(" mempeak is a small utility that displays information about maximum\n");
    printf(" and minimum memory-usage.\n\n");
    printf(" Keyboard Commands\n\n");
    printf(" d Deletes processes that aren't still running from the display\n");
    printf(" r Reset mempeak, like exiting and restarting mempeak\n");
    printf(" h Show this help\n");
    printf(" q Quit mempeak\n");
    printf("\n");
    printf(" Hit any key to continue\n");
    FLUSH;
    input = getch();
    return;
}

void time_update() {
    time_t sec;
    
    time(&sec);
    strftime(time_now, len_time, "%X", localtime(&sec));
}

void head() {
    locate(1,1);
    setcolor(set.color_head_fg);
    setcolor(set.color_head_bg);
    printf("%s", version);
    cleol;
}

void headlines() {
    locate(3,1);
    setcolor(set.color_legend);
    setcolor(set.color_bg);
    printf("%s", legend_mem);
    locate(12,1);
    printf("%s", legend_proc);
}

void statusbar_init() {
    setcolor(set.color_head_fg);
    setcolor(set.color_head_bg);
    locate(lastline,1);
    cleol;
    printf("Memory: %7ld KB Swap: %7ld KB Procs: %4d ", meminfo.memtotal, meminfo.swaptotal, proc_sum);
    if (set.display_userid != -1) printf("%s ", set.display_username);
    if (set.runonly == 1) printf("r ");
    locate(lastline,(81 - strlen(statushelp)));
    printf(statushelp);
}

void statusbar_update() {
    setcolor(set.color_head_fg);
    setcolor(set.color_head_bg);
    locate(lastline,44);
    printf("%4d", proc_sum);
}

void display_time() {
    setcolor(set.color_head_fg);
    setcolor(set.color_head_bg);
    locate(1,73);
    printf("%s", time_now);
}

void display_init() {
    setcolor(set.color_bg);
    clrscr;
    head();
    headlines();
    statusbar_init();
}

void display_proc_clear() {
    int i;

    locate(13,1);
    for (i = 0; i <= proc_lines; i++) {
        locate((i+13), 1);
        cleol;
    }
}

void display_procline(int lnum) {
    if (process[lnum].runflag == 1) setcolor(set.color_proc_running)
    else setcolor(set.color_proc_notrunning);
    printf(" %-7s %-8s %5ld %9s%6ld\n", process[lnum].uname, process[lnum].time, process[lnum].pid, process[lnum].name, process[lnum].vmsize);
}

void display_data() {
    int i, display_until, j = -1, pos;
    
    display_time();
    setcolor(set.color_bg);
    setcolor(set.color_mem_keys);
    locate(4,1);
    printf("%s MemUsed:       %9ld %s       %9ld %9s %s       %9ld %9s\n", set.color_mem_keys, meminfo.memused, set.color_mem_max, meminfo.memused_max, meminfo.memused_max_time, set.color_mem_min, meminfo.memused_min, meminfo.memused_min_time);
    printf("%s MemFree:       %9ld %s       %9ld %9s %s       %9ld %9s\n", set.color_mem_keys, meminfo.memfree, set.color_mem_max, meminfo.memfree_max, meminfo.memfree_max_time, set.color_mem_min, meminfo.memfree_min, meminfo.memfree_min_time);
    printf("%s MemShared:     %9ld %s       %9ld %9s %s       %9ld %9s\n", set.color_mem_keys, meminfo.memshared, set.color_mem_max, meminfo.memshared_max, meminfo.memshared_max_time, set.color_mem_min, meminfo.memshared_min, meminfo.memshared_min_time);
    printf("%s Buffers:       %9ld %s       %9ld %9s %s       %9ld %9s\n", set.color_mem_keys, meminfo.buffers, set.color_mem_max, meminfo.buffers_max, meminfo.buffers_max_time, set.color_mem_min, meminfo.buffers_min, meminfo.buffers_min_time);
    printf("%s Cached:        %9ld %s       %9ld %9s %s       %9ld %9s\n", set.color_mem_keys, meminfo.cached, set.color_mem_max, meminfo.cached_max, meminfo.cached_max_time, set.color_mem_min, meminfo.cached_min, meminfo.cached_min_time);
    printf("%s Swapfree:      %9ld %s       %9ld %9s %s       %9ld %9s\n", set.color_mem_keys, meminfo.swapfree, set.color_mem_max, meminfo.swapfree_max, meminfo.swapfree_max_time, set.color_mem_min, meminfo.swapfree_min, meminfo.swapfree_min_time);
    printf("%s Swapused:      %9ld %s       %9ld %9s %s       %9ld %9s\n", set.color_mem_keys, meminfo.swapused, set.color_mem_max, meminfo.swapused_max, meminfo.swapused_max_time, set.color_mem_min, meminfo.swapused_min, meminfo.swapused_min_time);
    locate(13,1);
    if (process_count < proc_lines) display_until = process_count+1;
    else display_until = proc_lines;
    for (i = 0, pos = 0; i < display_until; i++, pos++) display_procline(i);
    for (i = pos; i < proc_lines; i++) {
        locate(13 + i, 1);
        cleol;
    }
    for (i = display_until, pos = 0; i <= process_count; i++, pos++) {
        j++;
        locate(13 + j,41);
        display_procline(i);
    }
    for (i = pos; i < proc_lines; i++) {
        locate(13 + i, 41);
        cleol;
    }
    if (process_count == -1) {
        display_proc_clear();
        locate(13, 2);
        setcolor(set.color_warning);
        printf(warning_noprocs);
    }
}

void waitsec(int secs) {
    int s;
    char c;

    for (s = 1; s <= secs; s++) {
        if (set.timeupdate_sec == 1) {
            time_update();
            display_time();
            locate(lastline,80);
            FLUSH;
        }
        if (size_changed() == 1) {
            size_set();
            display_init();
            return;
        }
        sleep(1);
        c = getchpe();
        if (c == -1) continue;
        switch(toupper(c)) {
        case 'Q': mempeak_exit(error_normal);
                  break;
        case 'R': {
                      display_init();
                      time_update();
                      mem_init();
                      proc_clear();
                      return;
                  }
        case 'D': {
                      display_init();
                      proc_kill_notrunning();
                      return;
                  }
        case 'H': {
                      help_online();
                      display_init();
                      return;
                      break;
                  }
        default:  display_init();
        }
    }
}

void mainloop() {
    while(1) {
        time_update();
        mem_update();
        proc_update();
        display_time();
        display_data();
        statusbar_update();
        locate(lastline,80);
        FLUSH;
        waitsec(set.interval);
    }
}

int main(int argc, char *argv[]) {
    int i, usr;

    mempeak_init();
    for (i = 0; i <= argc; i++) {
        if (argv[i] != NULL) {
            if (strcmp(argv[i],"-i") == 0) {
                if (argv[i+1] != NULL) set.interval = atoi(argv[i+1]);
            } else if (strcmp(argv[i],"-u") == 0) {
                if (argv[i+1] != NULL) {
                    usr = get_uid(argv[i+1]);
                    if (usr == -1) error("No such user", error_user);
                    else {
                        set.display_userid = usr;
                        strcpy(set.display_username, argv[i+1]);
                        limit_str(set.display_username, len_uname);
                    }
                }
            } else if (strcmp(argv[i],"-r") == 0) set.runonly = 1;
            else if (strcmp(argv[i],"-b") == 0) set.colorbold = 1;
            else if (strcmp(argv[i],"-c") == 0) set.cursoroff = 1;
            else if (strcmp(argv[i],"-s") == 0) set.timeupdate_sec = 1;
            else if (strcmp(argv[i],"-h") == 0) help();
        }
    }
    screen_init();
    time_update();
    mem_init();
    display_init();
    mainloop();
    return error_normal;
}
