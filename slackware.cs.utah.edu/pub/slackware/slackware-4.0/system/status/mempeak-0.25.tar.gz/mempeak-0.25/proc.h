void proc_get(void);
void proc_sort(void);
void proc_killdupe(void);
void proc_cut(int num);
int  proc_pid_running(int p);
void proc_clear(void);
void proc_kill_notrunning(void);
void proc_update(void);

typedef struct ps_struct
{
    int runflag;
    int uid;
    long pid;
    long vmsize;
    char name[len_line];
    char time[len_time];
    char uname[len_uname];
} ps_struct;

