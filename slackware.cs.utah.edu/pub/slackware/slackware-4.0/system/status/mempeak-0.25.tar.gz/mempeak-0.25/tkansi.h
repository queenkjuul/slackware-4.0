#define BLACK         printf("\033[30m");
#define black         "\033[30m"
#define RED           printf("\033[31m");
#define red           "\033[31m"
#define GREEN         printf("\033[32m");
#define green         "\033[32m"
#define YELLOW        printf("\033[33m");
#define yellow        "\033[33m"
#define BLUE          printf("\033[34m");
#define blue          "\033[34m"
#define MAGENTA       printf("\033[35m");
#define magenta       "\033[35m"
#define CYAN          printf("\033[36m");
#define cyan          "\033[36m"
#define WHITE         printf("\033[37m");
#define white         "\033[37m"

#define ON_BLACK      printf("\033[40m");
#define on_black      "\033[40m"
#define ON_RED        printf("\033[41m");
#define on_red        "\033[41m"
#define ON_GREEN      printf("\033[42m");
#define on_green      "\033[42m"
#define ON_YELLOW     printf("\033[43m");
#define on_yellow     "\033[43m"
#define ON_BLUE       printf("\033[44m");
#define on_blue       "\033[44m"
#define ON_MAGENTA    printf("\033[45m");
#define on_magenta    "\033[45m"
#define ON_CYAN       printf("\033[46m");
#define on_cyan       "\033[46m"
#define ON_WHITE      printf("\033[47m");
#define on_white      "\033[47m"

#define BOLD          printf("\033[1m");
#define bold          "\033[1m"
#define NORMAL        printf("\033[0m");
#define normal        "\033[0m"

#define clrscr        printf("\033[2J");
#define cleol         printf("\033[K");
#define locate(z, s)  printf("\033[%d;%dH", z,s);
#define setcolor(c)   printf("%s", c);
#define cursor_off    printf( "\033[?25l" ); fflush(stdout);
#define cursor_on     printf( "\033[?25h" ); fflush(stdout);
#define FLUSH         fflush(stdout)
