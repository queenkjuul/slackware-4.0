#define version          "MemPeak 0.25"
#define end_msg          "\nThank you for using mempeak.\nYou'll find new versions on http://www.rhein-neckar.de/~darkstar/\n"
#define legend_mem       "                      Now              Max                        Min"
#define legend_proc      " User    Time     Pid        Name   Mem  User    Time     Pid        Name   Mem"
#define statushelp       "h=help q=quit"
#define lines_min        14
#define len_path         256
#define len_line         81
#define len_psname       9
#define len_uname        7
#define len_time         9
#define len_color        11
#define default_interval 1
#define procdir          "/proc/"
#define infofile         "/proc/meminfo"
#define error_header     "MemPeak Fatal Error: "
#define error_normal     0
#define error_sigint     1
#define error_procdir    2
#define error_config     11
#define error_mem        12
#define error_display    13
#define error_user       14
#define warning_noprocs  "No processes"

int cutword(char *changestr, char *instr, int pos);
int limit_str(char *instr, int maxlen);
int chomp(char *instr);
int string_is_digit (char *instr);
int isdir(char *path);
int get_uid(char *login_name);
char *get_uname(int uid);
int term_getlines(int fd);
void error(char *errtxt, int errcode);
void mempeak_init(void);
void screen_init(void);
void mempeak_cleanup(void);
void mempeak_exit(int rc);
void size_set(void);
int size_changed(void);
void help(void);
void help_online(void);
void time_update(void);
void head(void);
void headlines(void);
void statusbar_init(void);
void statusbar_update(void);
void display_time(void);
void display_init(void);
void display_proc_clear(void);
void display_procline(int lnum);
void display_data(void);
void waitsec(int secs);
void mainloop(void);

