#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include "mempeak.h"
#include "proc.h"
#include "config.h"

extern ps_struct *process;
extern set_struct set;
extern char time_now[len_time];
extern int process_count;
extern unsigned int proc_max;
extern unsigned int proc_sum;

int *running_pid;
int running_pid_count = -1;

void proc_get() {
    DIR *dfd;
    struct dirent *entry;
    struct ps_struct ps;
    char fullpath[256];
    char statfile[256];
    FILE *fp;
    char zeile[81];
    char tmpvar[81];
    char keyword[81];
    int p;

    proc_sum = 0;
    p = process_count;
    if ((dfd = opendir(procdir)) == NULL) error("Can't open /proc/", error_procdir);
    if (! process) process = (ps_struct *)malloc(0);
    if (running_pid) {
        free(running_pid);
        running_pid = (int *)malloc(0);
        running_pid_count = -1;
    }
    while (((entry = readdir(dfd)) != NULL)) {
        if (strcmp(entry->d_name, ".")    == 0 ||
            strcmp(entry->d_name, "..")   == 0 ||
            strcmp(entry->d_name, "self") == 0 ||
            strcmp(entry->d_name, "")     == 0 ||
            string_is_digit(entry->d_name) == 0) continue;
        strcpy(fullpath, procdir);
        strcat(fullpath, entry->d_name);
        if (isdir(fullpath)) {
            strcpy(statfile, fullpath);
            strcat(statfile, "/status");
            fp = fopen(statfile, "r");
            if (fp != NULL) {
                strcpy(ps.name, "unknown");
                ps.vmsize = 0;
                while (fgets(zeile, 81, fp) != NULL) {
                    if (strlen(zeile) == 0) continue;
                    chomp(zeile);
                    if (cutword(keyword, zeile, 1) == -1) continue;
                    if (cutword(tmpvar, zeile, 2)  == -1) continue;
                    if (strcmp(keyword, "Name:") == 0) {
                        limit_str(tmpvar, len_psname);
                        strcpy(ps.name, tmpvar);
                    }
                    else if (strcmp(keyword, "VmSize:") == 0) ps.vmsize = atol(tmpvar);
                    else if (strcmp(keyword, "Pid:") == 0)    ps.pid = atol(tmpvar);
                    else if (strcmp(keyword, "Uid:") == 0)    ps.uid = atol(tmpvar);
                }
                strcpy(ps.time, time_now);
                strcpy(tmpvar, get_uname(ps.uid));
                limit_str(tmpvar, len_uname);
                strcpy(ps.uname, tmpvar);
                running_pid_count++;
                running_pid = (int *)realloc(running_pid, sizeof(int) * (running_pid_count + 1));
                running_pid[running_pid_count] = ps.pid;
            }
            fclose(fp);
            if ((ps.uid == set.display_userid) || (set.display_userid == -1)) {
                p++;
                process = (ps_struct *)realloc(process, ((sizeof(ps_struct)) * (p + 1)));
                process[p] = ps;
                proc_sum++;
            }
        }
    }
    closedir(dfd);
    process_count = p;
}

void proc_sort() {
    int i, j;
    ps_struct temp;
    
    for (i = 0; i < process_count; i++) {
        for (j = 0; j < process_count; j++) {
            if (process[j].vmsize < process[j + 1].vmsize) {
                temp = process[j];
                process[j] = process[j + 1];
                process[j + 1] = temp;
            } else if (process[j].vmsize == process[j + 1].vmsize) {
                if (process[j].pid < process[j + 1].pid) {
                    temp = process[j];
                    process[j] = process[j + 1];
                    process[j + 1] = temp;
                }
            }
        }
    }
}

void proc_killdupe() {
    ps_struct *temp;
    int i, j, t, newpid;

    j = -1;
    temp = (ps_struct *)malloc(sizeof(ps_struct));
    for (i = 0; i <= process_count; i++) {
        newpid = 1;
        for (t = 0; t <= j; t++) {
            if (temp[t].pid == process[i].pid) {
                newpid = 0;
                if (process[i].vmsize > temp[t].vmsize) {
                    temp[t] = process[i];
                    temp[t].runflag = proc_pid_running(process[i].pid);
                }
            }
        }
        if (newpid == 1) {
            if (set.runonly == 1) {
                if (proc_pid_running(process[i].pid) == 1) {
                    j++;
                    temp = (ps_struct *)realloc(temp, sizeof(ps_struct) * (j + 1));
                    temp[j] = process[i];
                    temp[j].runflag = 1;
                }
            } else if (set.runonly == 0) {
                j++;
                temp = (ps_struct *)realloc(temp, sizeof(ps_struct) * (j + 1));
                temp[j] = process[i];
                temp[j].runflag = proc_pid_running(process[i].pid);
            }
        }
    }
    free(process);
    process = &temp[0];
    process_count = j;
}

void proc_cut(int num) {
    if (num > process_count) num = process_count;
    process = (ps_struct *)realloc(process, sizeof(ps_struct) * (num+1));
    process_count = num;
}

int proc_pid_running(int p) {
    int i;

    for (i = 0; i <= running_pid_count; i++) {
        if (running_pid[i] == p) return 1;
    }
    return 0;
}

void proc_clear() {
    process_count = -1;
}

void proc_kill_notrunning() {
    ps_struct *temp;
    int i, t = -1;

    temp = (ps_struct *)malloc(sizeof(ps_struct));
    for (i = 0; i <= process_count; i++) {
        if (process[i].runflag == 1) {
            t++;
            temp = (ps_struct *)realloc(temp, sizeof(ps_struct) * (t + 1));
            temp[t] = process[i];
        }
    }
    free(process);
    process = &temp[0];
    process_count = t;
}

void proc_update() {
    proc_get();
    proc_killdupe();
    proc_sort();
    proc_cut(proc_max);
}
