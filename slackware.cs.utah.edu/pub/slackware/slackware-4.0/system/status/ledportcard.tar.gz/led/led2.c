#include <stdio.h>
#include <fcntl.h>
#include <linux/led.h>
#include <signal.h>

int led_dev1;

static void int_handler()
{
	unsigned char count =0;	
		
	write(led_dev1, &count, 1 );	
	exit(0);
}

main()
	{
	char buf[10];
	unsigned char count;
	signal(SIGINT, int_handler);
	if ((led_dev1 = open("/dev/led1", O_WRONLY)) == -1) {
      		printf("Error opening Device led0\n");
		exit(1);
      	} 
	loop:
	for (count = 0 ; count <=63 ; count++)
		{
		write(led_dev1, &count, 1 );	
		usleep(1000);
		}
	goto loop;
	}
