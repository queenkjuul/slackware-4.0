#include <stdio.h>
#include <fcntl.h>
#include <linux/led.h>

main()
	{
	char buf[10];
	unsigned char count;
	int led_dev0;
	if ((led_dev0 = open("/dev/led0", O_WRONLY)) == -1) {
      		printf("Error opening Device led0\n");
		exit(1);
      	} 
	ioctl(led_dev0, LED_CMD_MODE, LED_BARGRAPH);
	for (count = 0 ; count <= 10 ; count++)
		{
		write(led_dev0, &count, 1 );	
		printf("count: %i\n", count);
		sleep(1); 
		}
	ioctl(led_dev0, LED_CMD_MODE, LED_BITSET);
	for (count = 0 ; count < 10 ; count++)
		{
		write(led_dev0, &count, 1 );	
		printf("count: %i\n", count);
		sleep(1); 
		}
	for (count = 0 ; count < 10 ; count++)
		{
		buf[0] = count;
		buf[1] = 9-count;
		write(led_dev0, buf, 2 );	
		printf("count: %i\n", count);
		sleep(1); 
		}
	}
