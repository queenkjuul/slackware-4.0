#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/kd.h>
#include <sys/ioctl.h>

// Comment this out if you want to use the rest of your leds 
// If you choose to comment it, remember to turn off the led pressing the
// corresponding key or you wont see it blink. The time it takes for a led
// to turn on/off after you press the key is proportional to system load
// In the rare case of experiencing problems such as random caps,
// leave it uncommented
#define OWN_LEDS

// This is the max load that can be represented in one second
// 2 is a nice value, since it appears to blink quickly at load 1 and stall
// at 2, just like system response starts to get sloppy after 2
#define MAX_LOAD 2

// Comment this out if you want a regular user to run this program
// If you comment it, after compiling please remember to do a:
//   chown root procleds
//   chmod u+s procleds
#define NOT_SUID

// Comment this out if you want to use only one tty
// Set TTY to the one you want to use below
// Note!! X Windows wont be able to start on that tty, and if you start
// procleds on it after X has, your keyboard will get disabled. Rule of
// the thumb: if agetty/mgetty or alike is running on the tty, procleds 
// will be fine.
#define MAX_TTY  6

#ifndef MAX_TTY
// tty12 is where syslog dumps out everything on my system
#define TTY     "/dev/tty12"
#endif

// options are LED_NUM, LED_SCR, LED_CAP
#define LED_LOAD LED_NUM

// minimum usecs that a led has to be off, useful for when load > MAX_LOAD
#define MIN_OFF_USECS 150000

// Ignore loads under (load * 1000000 / MAX_LOAD), for example if you want to
// ignore loads under .5, you would set it to 250000  (.5 * 1000000 / 2)
// #define MIN_LOAD 0

// procleds will normally decrease its %CPU to 0.0 after a few seconds of
// running, so you shouldn't worry about it "contributing" to system load

// --- Thats all, you shouln't have to change anything below ---

// usecs in a sec
#define USEC    1000000

#define VERSION_STR "procleds 1.1"

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

sig_atomic_t terminate = false;

inline void led_reset (int fd)
{
  ioctl (fd, KDSETLED, 0xff);
}

inline void led_on (int fd, char led)
{
  char state;
  ioctl (fd, KDGETLED, &state);
  ioctl (fd, KDSETLED, state | led);
#ifndef OWN_LEDS
//  led_reset (fd);
#endif
}

inline void led_off (int fd, char led)
{
  char state;
  ioctl (fd, KDGETLED, &state);
  ioctl (fd, KDSETLED, state & ~led);
#ifndef OWN_LEDS  
  led_reset (fd);
#endif
}

void sig_quit (int signo)
{
  if (terminate) {
    exit (255 - signo);
  } else {
    terminate = true;
  }
}

int main (int argc, char **argv)
{  
  FILE *fp;
  pid_t pid;
  int count;

#ifndef MAX_TTY
  int fd;
#else
  int fd[MAX_TTY];
#endif
  
  if (argc > 1) {
    puts (VERSION_STR " - (C) 1998 Ragnar Hojland Espinosa\n"
	  "Free software with NO WARRANTY");
    return 0;
  }

  if ((pid = fork()) < 0 ) {
    return 3;
  } else if (pid != 0) {
    return 0;
  }
  
  setsid(); 
  nice (40);
  
  for (count = 0; count < 0xff; ++count) {
    close (count);
  }
  
  fp = fopen ("/proc/loadavg", "r");
  if (!fp) {
    perror ("/proc/loadavg");
    return 1;
  }
  
#ifndef MAX_TTY
  fd = open (TTY, O_RDWR);
  if (fd == -1) {
    perror (TTY);
    return 2;
  }
#else
  for (argc = 1; argc <= MAX_TTY; ++argc) {
    char str[0xff];
    sprintf (str, "/dev/tty%d", argc);
    fd[argc-1] = open (str, O_RDWR);
    if (fd[argc-1] == -1) {
      perror (str);
      return 2;      
    }
  }
#endif  

#ifndef NOT_SUID
  seteuid (getuid());
  setegid (getgid());
#endif
  
  signal (SIGINT,  sig_quit);
  signal (SIGQUIT, sig_quit);
  signal (SIGTERM, sig_quit);
  
  while (!terminate) {
    float load;
    static long delta = 0;
#ifdef MAX_TTY
    int i;
#endif
    
    fscanf (fp, "%f", &load);
    load = load * USEC / MAX_LOAD;
    
    fflush (fp);
    rewind (fp);

#ifdef MIN_LOAD
    if (load > MIN_LOAD) {
#else
    if (load) {
#endif
#ifndef MAX_TTY    
      led_on (fd, LED_LOAD);
      usleep ( (long unsigned int) (load + delta) );
      led_off (fd, LED_LOAD);
#else
      for (i = 0; i < MAX_TTY; ++i) {
	led_on (fd[i], LED_LOAD);
      }
      usleep (load + delta);
      for (i = 0; i < MAX_TTY; ++i) {
	led_off (fd[i], LED_LOAD);
      }    
#endif
    
      if (load > USEC) {
	delta = (unsigned int) load;
	usleep (MIN_OFF_USECS);
      } else {
	delta = 0;
	usleep ( (long unsigned int) (USEC - load + MIN_OFF_USECS) );
      }
      
    } else {
      usleep (USEC);
    }
  }

#ifndef MAX_TTY
  led_reset (fd);
#else
  for (count = 0; count < MAX_TTY; ++count) {
    led_reset (fd[count]);
  }
#endif
  
  return 0;
}
