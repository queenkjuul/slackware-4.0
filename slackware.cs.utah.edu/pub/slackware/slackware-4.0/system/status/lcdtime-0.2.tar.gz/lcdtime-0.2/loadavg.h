/*
 * function exported from loadavg.c
 *
 * Written by Benjamin Tse, July 1997
 */

int loadavg(float *one, float *five, float *fifteen);
