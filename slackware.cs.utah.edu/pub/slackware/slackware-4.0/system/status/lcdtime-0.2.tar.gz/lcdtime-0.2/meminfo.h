/*
 * function exported from meminfo.c
 */

int meminfo(unsigned long *memused, unsigned long *memtotal, 
	    unsigned long *swapused, unsigned long *swaptotal);
