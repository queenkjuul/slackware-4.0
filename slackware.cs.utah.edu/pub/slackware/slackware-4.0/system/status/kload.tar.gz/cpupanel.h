// 
// 
// Class Declaration for CPUPanel: CPU Load Panel
// 
// Start: 19980531, UwS
// 
// 
// This is C++ 

#ifndef CPUPANEL_H
#define CPUPANEL_H

#include "lpanel.h"
    
// Panel for CPU Activity
class CPUPanel : public LPanel
{
    Q_OBJECT

public:
    CPUPanel(QWidget *parent=0, const char *name=0 );
    ~CPUPanel();
        
protected:
    static const char *statName;
    void resample(void); // Reread /proc/stat
};


#endif // LPANEL_H

