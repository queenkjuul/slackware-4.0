// 
// 
// Class Declaration for RAMPanel: RAM Usage Panel
// 
// Start: 19980605, UwS
// 
// 
// This is C++ 

#ifndef RAMPANEL_H
#define PAMPANEL_H

#include "lpanel.h"
    
// Panel for RAM Usage
class RAMPanel : public LPanel
{
    Q_OBJECT

public:
    RAMPanel(QWidget *parent=0, const char *name=0 );
    ~RAMPanel();
        
protected:
    static const char *statName;
    void resample(void); // Reread /proc/stat
};


#endif // LPANEL_H

