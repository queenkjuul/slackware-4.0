// 
// 
// Class Declaration for LoadPanel: Load Average Panel
// 
// Start: 19980616, UwS
// 
// 
// This is C++ 

#ifndef LOADPANEL_H

#include "lpanel.h"
    
// Panel for CPU Activity
class LoadPanel : public LPanel
{
    Q_OBJECT

public:
    LoadPanel(QWidget *parent=0, const char *name=0 );
    ~LoadPanel();
        
protected:
    static const char *statName;
    void resample(void); // Reread /proc/stat
};


#endif // LOADPANEL_H

