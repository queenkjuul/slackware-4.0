#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/tasks.h>
#include "fakestat.h"
#include "drv_yamm.h"

struct pst_status pp[NR_TASKS];

main()
{
int r;
int p = open("/dev/yamm", O_RDONLY);

r = ioctl(p, YIOCGOPROC|78, pp);

close (p);

}
