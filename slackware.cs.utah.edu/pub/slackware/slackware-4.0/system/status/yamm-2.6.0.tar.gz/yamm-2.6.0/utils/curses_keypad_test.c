#include<stdio.h>
#include <curses.h>
main(){int ch;
initscr();
keypad(stdscr, TRUE);
ch=getch();
printf("%o\n", ch);
}
