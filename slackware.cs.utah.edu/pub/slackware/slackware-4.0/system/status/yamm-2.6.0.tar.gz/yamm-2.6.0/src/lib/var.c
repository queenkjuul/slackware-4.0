/*
    yamm, Yet Another Micro Monitor
    var.c
    Copyright (C) 1992  Andrea Marangoni
    Copyright (C) 1994, 1995  Riccardo Facchetti

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "yamm.h"

long look_process = -1L, look_uid = -1L;
int wait_second = -1, sstring = 0, look_user = 0;
int invert = 0, system_time_include = 1, user_time_include = 1;
int allow_root = 0, long_format = 0, print_configuration = 0;
int vm_config = 0, wcpu = 0, who = 0, reverse = 0, reverse_index = -1;
int Num_display_proc = -1, set_euid = 0, pages = 0, displayed = 0;
int (*order)() = NULL, look_utmp = 0, load_graph = 0;
#if defined(SIGWINCH) && defined(OWN_WINCH)
char **yammav;
#endif /* SIGWINCH && OWN_WINCH */
#if defined(MODULE)
int yammfd;
#endif /* MODULE */

/*
 * The struct myps is now extern because we need it to calculate the
 * %CPU usage. We need to remember the old values of cpticks* to calculate
 * the delta(s) and the easiest way is to have myps as global struct.
 */
struct pst_status * myps;
struct pst_status * pbuf = NULL;
