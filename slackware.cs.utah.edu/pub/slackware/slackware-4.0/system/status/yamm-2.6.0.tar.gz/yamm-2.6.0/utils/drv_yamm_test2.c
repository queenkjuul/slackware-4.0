#include <stdio.h>
#include <fcntl.h>
#include "/var/unix/yamm/yamm-2.5.3d/include/drv_yamm.h"

main(){
int i, ret;
long pp;

i = open("/dev/yamm", O_RDONLY);
ret = ioctl(i, YIOCGVER, &pp);
close(i);
printf("%lx\n", pp);
}
