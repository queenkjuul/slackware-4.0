//  
//  Copyright (c) 1994 by Mike Romberg (  romberg@md.fsl.noaa.gov )
//
//  This file may be distributed under terms of the GPL
//

// Modifications made Jan '95
// Copyright Richard Laxton (u2105546@cumulus.csd.unsw.oz.au),
// Distributed under GPL.

#ifndef _CPUMETER_H_
#define _CPUMETER_H_

#include <fstream.h>

#define STATFILENAME "/proc/stat"

class CPUMeter {
public:
  CPUMeter(  );
  ~CPUMeter( void );

  const char *name( void ) { return "CPUMeter"; }
  int checkevent( int scale ); // Return the cpu load scale to 0..scale
protected:
  float cputime_[2][4];
  int cpuindex_;
  ifstream *stats_;
  float used_, total_;
  float fields_[4];

  void getcputime( void );
private:
};

#endif
