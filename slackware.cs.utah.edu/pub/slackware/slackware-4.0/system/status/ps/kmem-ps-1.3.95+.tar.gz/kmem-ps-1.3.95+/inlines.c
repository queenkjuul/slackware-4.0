#if !defined (__OPTIMIZE__)

#define inline
#define __inline__
#define extern

#include "asm/bitops.h"
#include "linux/string.h"

#endif /* !__OPTIMIZE__ */
