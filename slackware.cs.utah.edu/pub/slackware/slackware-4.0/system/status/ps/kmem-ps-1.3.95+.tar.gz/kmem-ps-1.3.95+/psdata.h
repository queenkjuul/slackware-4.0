/*
 * psdata.h
 *
 */

#define	DEBUG	1


#ifndef PSDATABASE
#define	PSDATABASE	"/etc/psdatabase"
#endif
#define	PS_MAGIC	"PSDATA.97"


struct dbtbl_s {
    off_t		off;		/* offset in psdatabase */
    int			nsym;		/* # symbols */
    int			size;		/* size of array + strings */
};

/*
 * header of psdatabase
 */
struct psdb_hdr {
    char		magic[16];
    char		uts_release[8];
    char		uts_version[8];
    char		sys_path[128];	/* name of system binary */
    char		swap_path[128];	/* name of swap device */
    struct dbtbl_s	vars;		/* bss and data symbols */
    struct dbtbl_s	fncs;		/* list of all functions */
    struct dbtbl_s	devs;		/* devs names */
};

struct sym_s {
    unsigned long	addr;		/* core address in kernel */
    int			name;		/* offset from strings ptr */
};

struct tbl_s {
    struct sym_s	*tbl;
    int			nsym;
    char		*strings;	/* ptr to start of strings */
    int			stringsize;	/* how much space is allocated there */
};

extern struct tbl_s vars, fncs, devs;
extern struct psdb_hdr db_hdr;
extern char *swappath[];


#ifdef DEBUG
extern int Debug;
#else
#define Debug 0
#endif

int varcmp(const void *p1, const void *p2);
int addrcmp(const void *p1, const void *p2);
int open_sys(char *sysfile, int update);
int open_psdb(void);
void close_psdb(void);
void make_vartbl(void);
void make_fnctbl(void);
void make_devtbl(void);
void dump_tbl(struct tbl_s *tbl);
char *first_func(unsigned long *eip);
char *next_func(unsigned long *eip);

