/*
 *	The Remote User Info Distribution Protocol
 *
 *	(c) 1997 Martin Mares <mj@atrey.karlin.mff.cuni.cz>
 *
 *	This software may be freely distributed and used according to the terms
 *	of the GNU General Public License. See file COPYING in any of the GNU packages.
 */

#define MAX_USERS 128

struct userinfo {
  char name[10];
  char con[4];
  char mesg_y;
  char pad;
  __u32 login_time;
  __u32 idle_time;
};

struct rywho_pkt {
  __u32 local_time;
  __u32 server_time;			/* Reserved for use by the server */
  __u32 num_users;
  __u32 uptime;
  __u32 avl[3];
  struct userinfo users[MAX_USERS];
};

#define YWHO_SPOOL_DIR "/var/spool/nwho"

#define DEFAULT_SEND_TIME 30
#define DEFAULT_PRUNE_TIME 30
#define DEFAULT_DEAD_TIME 120
