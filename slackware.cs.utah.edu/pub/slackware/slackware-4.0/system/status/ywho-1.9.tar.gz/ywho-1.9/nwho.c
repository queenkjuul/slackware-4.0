/*
 *	The Remote User Information Lister 1.8
 *
 *	(c) 1997 Martin Mares <mj@atrey.karlin.mff.cuni.cz>
 *
 *	This software may be freely distributed and used according to the terms
 *	of the GNU General Public License. See file COPYING in any of the GNU packages.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <netinet/in.h>
#include <asm/types.h>

#include "net.h"

static int is_uptime;

static void
puttime(int s)
{
  int d, h, m;
  if (s < 100)
    printf("%4ds", s);
  else
    {
      m = s/60;
      s %= 60;
      h = m/60;
      m %= 60;
      if (h < 100)
	printf("%02d.%02d", h, m);
      else
	{
	  d = h/24;
	  h %= 24;
	  if (d < 100)
	    printf("%2dd%02d", d, h);
	  else
	    printf("%4dd", d);
	}
    }
}

static void
show_uptime(char *name, struct rywho_pkt *p)
{
  int i;

  printf("%-16s up ", name);
  puttime(ntohl(p->uptime));
  printf("  load");
  for(i=0; i<3; i++)
    {
      int l = ntohl(p->avl[i]);
      printf(" %2d.%02d", l/100, l%100);
    }
  printf(" %3d users\n", (int) ntohl(p->num_users));
}

static void
show_users(char *name, struct rywho_pkt *p)
{
  int u;
  int m = ntohl(p->num_users);
  struct userinfo *i;

  for(u=0; u<m; u++)
    {
      i = &p->users[u];
      printf("%-8.8s %-3s %c %-16s ", i->name, i->con, (i->mesg_y ? ' ' : '-'), name);
      puttime(ntohl(i->login_time));
      putchar(' ');
      puttime(ntohl(i->idle_time));
      putchar('\n');
    }
  if (m == MAX_USERS)
    printf("%s: MAX_USERS reached!\n", name);
}

static void
scan(void)
{
  DIR *d;
  struct dirent *e;
  struct rywho_pkt pkt;
  int fd, r;
  int is = 0;

  if (chdir(YWHO_SPOOL_DIR) < 0)
    {
      fprintf(stderr, "chdir(" YWHO_SPOOL_DIR "): %m\n");
      exit(1);
    }
  d = opendir(".");
  if (!d)
    {
      perror("opendir");
      exit(1);
    }
  while (e = readdir(d))
    if (e->d_name[0] != '.')
      {
	fd = open(e->d_name, O_RDONLY);
	if (fd < 0)
	  {
	    fprintf(stderr, "%s: %m\n", e->d_name);
	    continue;
	  }
	r = read(fd, &pkt, sizeof(pkt));
	close(fd);
	if (r < sizeof(struct rywho_pkt) - MAX_USERS*sizeof(struct userinfo)
	    || r != sizeof(struct rywho_pkt) - (MAX_USERS - ntohl(pkt.num_users))*sizeof(struct userinfo))
	  {
	    fprintf(stderr, "%s: Malformed record\n", e->d_name);
	    continue;
	  }
	(is_uptime ? show_uptime : show_users)(e->d_name, &pkt);
	is = 1;
      }
  closedir(d);
  if (!is)
    puts("No data available.");
}

int
main(int argc, char **argv)
{
  if (strstr(argv[0], "uptime"))
    is_uptime = 1;
  if (argc != 1)
    {
      fprintf(stderr, "Usage: %s\n", argv[0]);
      return 1;
    }
  if (!is_uptime)
    puts("Name     Li  M Where            LogT  IdleT");
  scan();
  return 0;
}
