/* k3 v1.3
 * Public domain by Russell Marks 1993,1996.
 *
 * k3 is just a simple prettifier for /proc/meminfo.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


int buf_free=1;


#define BAR_WIDTH	40

#define USEDCHAR '#'
#define DBUFCHAR '%'
#define FREECHAR ':'


int showbar(title,avail,buffers,total)
char *title;
int avail,buffers,total;
{
int availk,buffk,totalk,limit1,limit2,count,pcnt;

availk=(avail>>10); buffk=(buffers>>10); totalk=(total>>10);
pcnt=((availk+buf_free*buffk)*100)/totalk;

printf("%s | ",title);
printf("%3d%% free (%6dk/%6dk) | [",pcnt,availk+buf_free*buffk,totalk);

limit1=BAR_WIDTH-((availk*BAR_WIDTH)/totalk);
limit2=BAR_WIDTH-(((availk+(buffers>>10))*BAR_WIDTH)/totalk);

for(count=0;count<BAR_WIDTH;count++)
  putchar((count<limit2)?USEDCHAR:((count<limit1)?DBUFCHAR:FREECHAR));

puts("]");
}


void readmeminfo(int *pmf,int *pmt,int *pmb,int *pms,int *psf,int *pst)
{
FILE *in;
char buf[128],junk[128];
int waste;

if((in=fopen("/proc/meminfo","r"))==NULL)
  {
  printf("Couldn't read /proc/meminfo.\n");
  exit(1);
  }
else
  {
  fgets(buf,sizeof(buf),in);
  fgets(buf,sizeof(buf),in);
  sscanf(buf,"%s%d%d%d%d%d",junk,pmt,&waste,pmf,pms,pmb);
  fgets(buf,sizeof(buf),in);
  sscanf(buf,"%s%d%d%d",junk,pst,&waste,psf);
  fclose(in);
  }
}


void usage()
{
printf("k3 v1.3 - public domain by Russell Marks for improbabledesigns.\n\n");
printf("\
usage: k3 [-r]

	-r	show real amount free, rather than regarding buffers as
        	more-or-less `free'.
");
}


int main(int argc,char *argv[])
{
int mf,mt,mb,ms,sf,st;

if(argc==2 && strcmp(argv[1],"-r")==0)
  buf_free=0,argc--,argv++;

if(argc!=1) usage(),exit(1);

readmeminfo(&mf,&mt,&mb,&ms,&sf,&st);
showbar("Phys",mf,mb,mt);
if(st>0)
  showbar("Swap",sf,0,st);

exit(0);
}
