/*
 * defaults.h
 * Setup X defaults for the gmemusage program
 */
#define MaxColors 9
#define ThreshholdDelta 10
#define DefaultBorder 10
/*
 * Defined in gmemusage.c
 */
extern char
   progname [] ;
/*
 * Defined in resource.c
 */
extern char
   *dGeometry ,
   *dDisplay ,
   *dFont ,
   *dForeground ,
   *dBackground ,
   *dColor[MaxColors] ;
extern int
   dnColors ,
   dUpdate ,
   dThreshhold ;
extern void
   GetInitialResources ( int *argc , char **argv ) ,
   GetResources ( Display *display , int argc , char **argv ) ;
