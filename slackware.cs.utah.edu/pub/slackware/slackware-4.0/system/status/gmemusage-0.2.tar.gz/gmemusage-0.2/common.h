/*
 * common.h
 * common definitions for gmemusage
 *
 * Copyright (C) 1997 by Raju Mathur (raju@sgi.com)
 *
 * See file COPYING (included in this distribution) for copyright information.
 */
#define	kernelname "linux"
#define freename "free"

struct ProcInfo
{
      char
	 procname [14] ;
      int
	 totMem ,
	 totRSS ,
	 nProcs ;
} ;
/*
 * Defined in hash.c
 */
extern void addProc ( char *procName , int Mem , int RSS ) ;
extern void ClearProcs ( void ) ;
extern struct ProcInfo *NextProc ( void ) ;
extern struct ProcInfo *AllProcs ( int *nprocs ) ;
/*
 * Defined in proc.c
 */
extern void makeProcs ( void ) ;
extern int
   sysmem ,
   kernelmem ,
   freemem ,
   buffermem ;
/*
 * Defined in gmemusage.c
 */
extern char
   progname [] ,
   *version ;
