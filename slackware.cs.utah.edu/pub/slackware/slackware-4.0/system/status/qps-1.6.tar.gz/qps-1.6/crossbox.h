// crossbox.h
//
// This program is free software. See the file COPYING for details.
// Author: Mattias Engdeg�rd, 1997, 1998

#ifndef CROSSBOX_H
#define CROSSBOX_H

#include <qchkbox.h>
#include <qpainter.h>

class CrossBox : public QCheckBox
{
public:
    CrossBox(const char *text, QWidget *parent, const char *name = 0);

protected:
    virtual void drawButton(QPainter *paint);
};

#endif	// CROSSBOX_H

