// checkmenu.h
//
// This program is free software. See the file COPYING for details.
// Author: Mattias Engdeg�rd, 1997, 1998

#ifndef CHECKMENU_H
#define CHECKMENU_H

#include <qpopmenu.h>
#include <qpainter.h>

class CheckMenu : public QPopupMenu
{
public:
    CheckMenu(QWidget *parent = 0, const char *name = 0);

protected:
    virtual void paintCell(QPainter *p, int row, int col);
};

#endif	// CHECKMENU_H
