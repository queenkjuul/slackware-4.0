
#ifndef __MOUSE_H__
#define __MOUSE_H__

/* note: all mouse cursors are 8x8 */

/* width and height of mouse cursor... not easily changed */
#define MC_W	8
#define MC_H	8

typedef struct
    {
    short x, y;
    } MOUSE_WHERE;

typedef enum { MC_ARROW, MC_CROSS } MOUSE_CURSOR_SELECTOR;

extern int poll_mouse(MOUSE_WHERE *where);
extern void mouse_set_cursor(MOUSE_CURSOR_SELECTOR which);
extern void mouse_force_redraw(void);

#endif
