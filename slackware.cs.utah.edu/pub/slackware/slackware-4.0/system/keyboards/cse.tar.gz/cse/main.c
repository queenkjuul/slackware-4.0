
#include "conf.h"
#include <stdio.h>
#include <vga.h>
#include <vgagl.h>
#include <vgamouse.h>
#include <stdlib.h>
#include <memory.h>
#include "font.h"
#include "mouse.h"
#include "disp.h"
#include "button.h"

void
main(int argc, char *argv[])
    {
    MOUSE_WHERE where;

    printf ("Linux Console Font Editor\nDavid B. Thomas (dthomas@rt66.com)\n"
	    "Public Domain... No Rights Reserved\n");
    if (argc != 2)
	{
	printf ("usage: %s [fontfile]\n", argv[0]);
	exit(-1);
	}

    if (font_read (argv[1], &bfont))
	{
	printf ("Unable to read font from %s\n", argv[1]);
	exit (-1);
	}

    if (init_display())
	{
	printf ("vga mode not available\n");
	exit (-1);
	}

    if (init_fonts())
	{
	shut_display();
	printf ("insufficient memory\n");
	exit (-1);
	}

    disp_show_banner();
    disp_show_font();
    button_set_dirty();
    draw_buttons();
    edit_chr (65);		/* put up letter A to start */

    /* mouse input loop */

    for (;;)
    	{
	if (poll_mouse(&where))
	    {
	    /* if mouse is over a chr, this will edit it */
	    edit_chr(disp_get_chrcode(where));

	    /* if mouse is over a pixmap bit, this will toggle it */
	    twiddle_pixmap_bit (where);

	    /* if it's over a button, process the click event */
	    if (button_handle_click(where))
		break;
	    }
	usleep (10000);
	}

    shut_fonts();
    shut_display();
    }

