
#include "conf.h"
#include "font.h"
#include <vga.h>
#include <vgagl.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include "button.h"

BITFONT bfont;
EFONT efont, reffont;
int current_chr;

static char revert_buf[128];
static char paste_buf[128];

static char fontfilename[128];

int
font_read (char *filename, BITFONT *bf)
    {
    FILE *fp;
    struct psfheader psf;

    strcpy (fontfilename, filename);

    /* open the file */
    if ( (fp = fopen (filename, "rb")) == NULL)
    	return (-1);

    /* peek at first two bytes to see if it's a "psf" font */
    if (fread (&psf, sizeof(psf), 1, fp) != 1)
	{
	fclose (fp);
    	return (-1);
	}

    if (psf.magic == PSF_MAGIC)
	{
	/* it's a psf file ... check the size field */
	if (psf.size != 16)
	    {
	    fclose (fp);
	    return (-1);
	    }
	}
    else
	{
	/* it's not a psf file, rewind to top of file */
	fseek (fp, 0, SEEK_SET);
	}

    /* read the whole font into the buffer */
    if (fread (bf, sizeof (BITFONT), 1, fp) != 1)
	{
	fclose (fp);
	return (-1);
	}

    fclose (fp);
    return (0);    
    }

int
font_write (char *filename, BITFONT *bf)
    {
    FILE *fp;
#ifdef PSF_OUTPUT
    struct psfheader psf;
#endif

    /* open the file for writing */
    if ( (fp = fopen (filename, "wb")) == NULL)
	return (-1);

#ifdef PSF_OUTPUT
    psf.magic = PSF_MAGIC;
    psf.dummy = 0;
    psf.size = 16;
    if (fwrite (&psf, sizeof(psf), 1, fp) != 1)
	{
	fclose (fp);
	return (-1);
	}
#endif

    if (fwrite (bf, sizeof (BITFONT), 1, fp) != 1)
	{
	fclose (fp);
	return (-1);
	}

    fclose (fp);
    return (0);
    }

void efont_free (EFONT *ef)
    {
    if (ef->data)
	free (ef->data);
    }

void *efont_chr (EFONT *ef, int index)
    {
    if (index < 0) index = 0;
    if (index > 255) index = 255;
    return ((void *) ((char *)ef->data +
		      index * ef->width * ef->height * ef->bpp));
    }

/* init_fonts -- expand bfont into efont, and expand builtin vga font
   into reffont.  Sets current font to reffont.
   */

int
init_fonts(void)
    {
    reffont.width = 8;
    reffont.height = 8;
    reffont.bpp = BYTESPERPIXEL;
    reffont.data = malloc (256 * reffont.width * reffont.height * reffont.bpp);
    if (!reffont.data)
	return -1;

    efont.width = 8;
    efont.height = 16;
    efont.bpp = BYTESPERPIXEL;
    efont.data = malloc (256 * efont.width * efont.height * efont.bpp);
    if (!efont.data)
	{
	free(reffont.data);
	return -1;
	}
    gl_expandfont (reffont.width, reffont.height, REF_COLOR, gl_font8x8,
		   reffont.data);
    gl_expandfont (efont.width, efont.height, FNT_COLOR, bfont, efont.data);
    gl_setfont (reffont.width, reffont.height, reffont.data);

    memset (revert_buf, 0, sizeof(revert_buf));
    memset (paste_buf, 0, sizeof(paste_buf));
    return 0;
    }

void
shut_fonts(void)
    {
    if (reffont.data)
	free(reffont.data);
    if (efont.data)
	free(efont.data);
    }

void
compress_font (EFONT *ef, BITFONT *bf)
    {
    char *e = ef->data;
    char *b = *bf;
    int byte;
    unsigned char bit;

    for (byte = 0; byte < 4096; byte++)
	{
	b[byte] = 0;
	for (bit = 0; bit < 8; ++bit)
	    if (e[8*byte+bit])
		b[byte] |= (0x80>>bit);
	}
    }

int
f_rotup(void)
    {
    char *bitmap = efont_chr (&efont, current_chr);
    char saveline[8];

    memcpy (saveline, bitmap, 8);
    memmove (bitmap, bitmap+8, 120);
    memcpy (bitmap+120, saveline, 8);
    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

int
f_rotdn(void)
    {
    char *bitmap = efont_chr (&efont, current_chr);
    char saveline[8];

    memcpy (saveline, bitmap+120, 8);
    memmove (bitmap+8, bitmap, 120);
    memcpy (bitmap, saveline, 8);
    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

int
f_rotleft(void)
    {
    char *bitmap = efont_chr (&efont, current_chr);
    char savepix;
    int i;

    savepix = *bitmap;		/* save upper left */
    memmove (bitmap, bitmap+1, 127); /* shift by one byte */

    /* copy 15 pixels on right side down one row */
    for (i = 14; i >= 0; --i)
	bitmap[8*(i+1)+7] = bitmap[8*i+7];

    /* restore saved pixel and we're done */
    bitmap[7] = savepix;
    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

int
f_rotright(void)
    {
    char *bitmap = efont_chr (&efont, current_chr);
    char savepix;
    int i;

    savepix = bitmap[127];		/* save bottom right */
    memmove (bitmap+1, bitmap, 127); /* shift by one byte */

    /* copy 15 pixels on left side up one row */
    for (i = 0; i < 15; ++i)
	bitmap[8*i] = bitmap[8*(i+1)];

    /* restore saved pixel and we're done */
    bitmap[120] = savepix;
    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

int
f_clear(void)
    {
    char *bitmap = efont_chr (&efont, current_chr);

    memset (bitmap, COLOR_BLACK, 128);
    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

int
f_invert(void)
    {
    char *bitmap = efont_chr (&efont, current_chr);
    int i;

    for (i = 0; i < 128; ++i)
	if (bitmap[i] == 0)
	    bitmap[i] = FNT_COLOR;
	else
	    bitmap[i] = COLOR_BLACK;
    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

int
f_revert(void)
    {
    char *bitmap = efont_chr(&efont, current_chr);
    memcpy (bitmap, revert_buf, 128);
    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

int
f_copy(void)
    {
    char *bitmap = efont_chr(&efont, current_chr);
    memcpy (paste_buf, bitmap, 128);
    return 0;
    }

int
f_paste(void)
    {
    char *bitmap = efont_chr(&efont, current_chr);
    memcpy (bitmap, paste_buf, 128);
    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

int
f_flipvert(void)
    {
    char *bitmap = efont_chr(&efont, current_chr);
    char saveline[8];
    int i;

    for (i = 0; i < 8; ++i)
	{
	memcpy (saveline, bitmap+8*i, 8);
	memcpy (bitmap+8*i, bitmap+120-8*i, 8);
	memcpy (bitmap+120-8*i, saveline, 8);
	}

    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

int
f_fliphoriz(void)
    {
    char *bitmap = efont_chr(&efont, current_chr);
    char temp;
    int i;
    int b;

    /* flip all rows */
    for (i = 0; i < 16; ++i)
	{
	for (b = 0; b < 4; ++b)
	    {
	    temp = bitmap[i*8+b];
	    bitmap[i*8+b] = bitmap[i*8+7-b];
	    bitmap[i*8+7-b] = temp;
	    }
	}

    redraw_chr();
    dirty = DIRTY_DIRTY;
    return 0;
    }

void
font_copy_to_revert_buffer (void)
    {
    char *bitmap = efont_chr(&efont, current_chr);
    memcpy (revert_buf, bitmap, 128);
    }

int
f_save(void)
    {
    switch (dirty)
	{
    case DIRTY_OVERWRITE:
	compress_font(&efont, &bfont);
	if (font_write(fontfilename, &bfont))
	    dirty = DIRTY_FAILED;
	else
	    dirty = DIRTY_SAVED;
	break;
    case DIRTY_SAVED:
    case DIRTY_FAILED:
	break;
    case DIRTY_DIRTY:
	dirty = DIRTY_OVERWRITE;
	break;
    case DIRTY_DISCARD:
	dirty = DIRTY_DIRTY;
	break;
	}
    return 0;
    }

int
f_exit(void)
    {
    switch (dirty)
	{
    case DIRTY_SAVED:
    case DIRTY_DISCARD:
	return 1;
    case DIRTY_DIRTY:
    case DIRTY_FAILED:
	dirty = DIRTY_DISCARD;
	break;
    case DIRTY_OVERWRITE:
	dirty = DIRTY_DIRTY;
	break;
	}
    return 0;
    }
