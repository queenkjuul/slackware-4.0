
#ifndef __CONF_H__
#define __CONF_H__

/* parameters that are actually safe to tweak are listed here */

/* Define PSF_OUTPUT if you want PSF format font files written.  This
   program can read native Linux 8x16 console fonts as well as the PSF
   8x16 fonts.  (The only difference is a 4 byte header.)  If
   PSF_OUTPUT is defined, a PSF font file (4100 bytes) is written.
   Otherwise a native Linux font (4096 bytes) is written. */

/* #define PSF_OUTPUT */


/* colors of various objects */

#include "colors.h"
#define BORDER_COLOR	COLOR_WHITE /* box borders */
#define	CURSOR_COLOR	COLOR_WHITE /* mouse cursor */
#define REF_COLOR	COLOR_CYAN /* reference font */
#define	FNT_COLOR	COLOR_GRAY /* font being edited */
#define	MAP_COLOR_OFF	COLOR_DKGRAY /* "off" color in pixmap */
#define	MAP_COLOR_ON	COLOR_CYAN /* "on" color in pixmap */
#define HIGHLIGHT_COLOR	COLOR_BRTRED /* box around selected chr */
#define BUTBORD_COLOR	COLOR_GRAY /* Border around pushbuttons */
#endif
