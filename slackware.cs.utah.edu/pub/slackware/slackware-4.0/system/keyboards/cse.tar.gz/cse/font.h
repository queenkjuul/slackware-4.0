
#ifndef __FONT_H__
#define __FONT_H__

#define PSF_MAGIC 0x0436

struct psfheader
    {
    unsigned short magic;
    unsigned char dummy;
    unsigned char size;
    };

typedef char BITFONT[4096];

typedef struct
    {
    int width;
    int height;
    int bpp;			/* bytes per pixel */
    void *data;
    } EFONT;

extern BITFONT bfont;
extern EFONT efont, reffont;

extern int font_read (char *filename, BITFONT *bf);
extern int font_write (char *filename, BITFONT *bf);
extern void efont_free (EFONT *ef);
extern void *efont_chr (EFONT *ef, int index);
extern int init_fonts(void);
extern void shut_fonts(void);
extern void font_copy_to_revert_buffer(void);

extern int f_rotleft(void);
extern int f_rotright(void);
extern int f_rotup(void);
extern int f_rotdn(void);
extern int f_clear(void);
extern int f_invert(void);
extern int f_revert(void);
extern int f_copy(void);
extern int f_paste(void);
extern int f_save(void);
extern int f_exit(void);
extern int f_flipvert(void);
extern int f_fliphoriz(void);

#endif
