
/* disp.c -- display handling logic */

#include "conf.h"
#include <vga.h>
#include <vgagl.h>
#include <stdio.h>
#include "disp.h"
#include "font.h"
#include "mouse.h"
#include "button.h"

GraphicsContext phys, virt;
int current_chr;

/* magic numbers */

const int cols = 32;
const int rows = 8;
const int xoffset = 10;
const int yoffset = 10;
const int xspacing = 16;
const int yspacing = 40;
const int refyoffset = 20;
const int bordercolor = 15;
const int xloc = 0;
const int yloc = 132;
const int hovercodex = 10;
const int hovercodey = 120;

/* disp_show_font: display font being edited next to reference characters */

void
disp_show_font (void)
    {
    int x, y;
    int rw, rh;

    gl_setcontext (&virt);

    /* first, draw rectangle around whole mess */
    rw = xoffset * 2 + cols * xspacing;
    rh = yoffset * 2 + rows * yspacing;
    gl_line (xloc, yloc, xloc+rw, yloc, bordercolor);
    gl_line (xloc, yloc, xloc, yloc+rh, bordercolor);
    gl_line (xloc+rw, yloc, xloc+rw, yloc+rh, bordercolor);
    gl_line (xloc, yloc+rh, xloc+rw, yloc+rh, bordercolor);

    for (y = 0; y < rows; ++y)
	{
	for (x = 0; x < cols; ++x)
	    {
	    gl_putbox (xloc+xoffset+x*xspacing,
		       yloc+yoffset+y*yspacing,
		       efont.width, efont.height,
		       efont_chr(&efont, y*cols+x));
	    gl_putbox (xloc+xoffset+x*xspacing,
		       yloc+yoffset+refyoffset+y*yspacing,
		       reffont.width, reffont.height,
		       efont_chr(&reffont, y*cols+x));
		       
	    }
	}
    gl_copyboxtocontext (xloc, yloc, rw+1, rh+1, &phys, xloc, yloc);
    }

int
init_display(void)
    {
    vga_init();
    vga_setmousesupport(1);
    if (!vga_hasmode(VGAMODE))
	return (-1);
    vga_setmode(VGAMODE);
    gl_setcontextvga (VGAMODE);	/* create physical screen context */
    gl_getcontext (&phys);	/* and make a struct to refer to it */

    gl_setcontextvgavirtual(VGAMODE); /* create virtual screen context */
    gl_getcontext (&virt);	/* and make a struct to refer to it */

    return (0);
    }

void
shut_display(void)
    {
    gl_freecontext (&virt);
    vga_setmode(TEXT);
    }

int
disp_get_chrcode (MOUSE_WHERE where)
    {
    int x = where.x;
    int y = where.y;
    int row, col, code;

    if (x >= xloc+xoffset &&
	y >= yloc+yoffset &&
	x < xloc+xoffset+cols*xspacing &&
	y < yloc+yoffset+rows*yspacing)
	{
	/* it's inside the box... get the character's code */
	col = (x - (xloc+xoffset)) / xspacing;
	row = (y - (yloc+yoffset)) / yspacing;
	code = row * cols + col;
	}
    else
	code = -1;
    return code;
    }

/* disp_show_hovercode -- show codes for chr mouse is currently over
   */

void
disp_show_hovercode (MOUSE_WHERE where)
    {
    char codebuf[10];
    int code;

    if ( (code = disp_get_chrcode(where)) != -1)
	{
	/* inside the box... valid code */
	sprintf (codebuf, "%c %3d %02xh", code ? code : ' ', code, code);
	}
    else
	{
	/* it's outside... no valid code */
	strcpy (codebuf, "- --- --h");
	}

    gl_setcontext(&phys);
    gl_write (hovercodex, hovercodey, codebuf);
    }

/* edit_chr -- draw the pixmap and vitals for this character, also
   sets the current character being edited to the index specified. */

const int pmlocx = 200;
const int pmlocy = 10;
const int pmxspacing = 7;
const int pmyspacing = 7;
const int pmbitwidth = 6;
const int pmbitheight = 6;
const int pmmsgx = 120;
const int pmmsgy = 15;
const int pmdecmsgy = 15;
const int pmhexmsgy = 45;
const int pmstdmsgy = 75;
const int pmnewmsgy = 105;
const int pmmsgw = 80;
const int pmmsgh = 100;
const int glyphx = 160;
const int glyphy = 100;

void
redraw_chr (void)
    {
    int x, y;
    int row, col;
    char *bitmap = efont_chr(&efont, current_chr);

    gl_setcontext (&virt);


    /* first, draw all the big bits in the pixel map */

    for (y = 0; y < efont.height; ++y)
	{
	for (x = 0; x < efont.width; ++x)
	    {
	    gl_fillbox(pmlocx+x*pmxspacing, pmlocy+y*pmyspacing,
		       pmbitwidth, pmbitheight,
		       bitmap[y * efont.width + x] ? MAP_COLOR_ON :
		       MAP_COLOR_OFF);
	    }
	}
    gl_copyboxtocontext (pmlocx, pmlocy, efont.width * pmxspacing,
			 efont.height * pmyspacing, &phys, pmlocx, pmlocy);


    /* next, update the preview glyph */

    gl_putbox (glyphx, glyphy, efont.width, efont.height, bitmap);
    gl_copyboxtocontext (glyphx, glyphy, efont.width, efont.height,
			 &phys, glyphx, glyphy);

    /* finally, update the glyph in the character set display */

    row = current_chr / cols;
    col = current_chr % cols;
    gl_putbox (xloc+xoffset+col*xspacing, yloc+yoffset+row*yspacing,
	       efont.width, efont.height, bitmap);
    gl_copyboxtocontext (xloc+xoffset+col*xspacing, yloc+yoffset+row*yspacing,
			 efont.width, efont.height, &phys,
			 xloc+xoffset+col*xspacing, yloc+yoffset+row*yspacing);

    }

void
edit_chr (int index)
    {
    int x, y;
    char *bitmap;
    char decmsg[9], hexmsg[9], stdmsg[7];

    if (index < 0 || index > 255)
	return;

    /* get out of exotic dirty states */
    if (dirty != DIRTY_SAVED && dirty != DIRTY_DIRTY)
	{
	dirty = DIRTY_DIRTY;
	button_set_dirty();
	}

    /* draw a box around the selected character */

    highlight_chr (current_chr, 0);
    current_chr = index;
    highlight_chr (current_chr, 1);

    redraw_chr();		/* draw pixels and glyphs */

    /* put up vitals */
    sprintf (decmsg, "Dec: %3d", index);
    sprintf (hexmsg, "Hex: %02xh", index);
    sprintf (stdmsg, "Std: %c", index);
    gl_write (pmmsgx, pmdecmsgy, decmsg);
    gl_write (pmmsgx, pmhexmsgy, hexmsg);
    gl_write (pmmsgx, pmstdmsgy, stdmsg);
    gl_write (pmmsgx, pmnewmsgy, "New:");
    gl_copyboxtocontext (pmmsgx, pmmsgy, pmmsgw, pmmsgh, &phys, pmmsgx, pmmsgy);

    /* save the bits in case the "revert" button is used */
    font_copy_to_revert_buffer();

    /* in case we just painted over mouse cursor */
    mouse_force_redraw();
    }

void
twiddle_pixmap_bit (MOUSE_WHERE where)
    {
    int x = where.x;
    int y = where.y;
    char *bitmap;
    int row, col;

    if (x < pmlocx || x >= pmlocx+efont.width*pmxspacing ||
	y < pmlocy || y >= pmlocy+efont.height*pmyspacing)
	return;

    /* mouse click is inside pixel map -- flip the bit */

    bitmap = (char *)efont_chr(&efont, current_chr);
    x = (x - pmlocx) / pmxspacing;
    y = (y - pmlocy) / pmyspacing;
    switch (bitmap[y * efont.width + x])
	{
    case COLOR_BLACK:		/* pixel currently off */
	bitmap[y * efont.width + x] = FNT_COLOR;
	break;
    default:			/* pixel currently on */
	bitmap[y * efont.width + x] = COLOR_BLACK;
	break;
	}

    /* redraw first the pixmap pixel, then the glyph in the charset, then
     finally the preview glyph */

    gl_setcontext (&virt);
    gl_fillbox(pmlocx+x*pmxspacing, pmlocy+y*pmyspacing,
	       pmbitwidth, pmbitheight,
	       bitmap[y * efont.width + x] ? MAP_COLOR_ON :
	       MAP_COLOR_OFF);
    gl_copyboxtocontext (pmlocx+x*pmxspacing, pmlocy+y*pmyspacing,
			 pmbitwidth, pmbitheight, &phys,
			 pmlocx+x*pmxspacing, pmlocy+y*pmyspacing);

    row = current_chr / cols;
    col = current_chr % cols;
    gl_putbox (xloc+xoffset+col*xspacing, yloc+yoffset+row*yspacing,
	       efont.width, efont.height, bitmap);
    gl_copyboxtocontext (xloc+xoffset+col*xspacing, yloc+yoffset+row*yspacing,
			 efont.width, efont.height, &phys,
			 xloc+xoffset+col*xspacing, yloc+yoffset+row*yspacing);

    gl_putbox (glyphx, glyphy, efont.width, efont.height, bitmap);
    gl_copyboxtocontext (glyphx, glyphy, efont.width, efont.height, &phys,
			 glyphx, glyphy);
    mouse_force_redraw();

    /* set the dirty bit, then update the "Save" button */
    dirty = DIRTY_DIRTY;
    button_set_dirty();
    }

void
highlight_chr (int index, int on)
    {
    int x, y;
    int row = index / cols;
    int col = index % cols;
    int w = efont.width+3;
    int h = refyoffset + reffont.height+3;
    int c;

    if (on)
	c = HIGHLIGHT_COLOR;
    else
	c = COLOR_BLACK;

    gl_setcontext (&virt);
    x = xloc+xoffset+col*xspacing - 2;
    y = yloc+yoffset+row*yspacing - 2;
    gl_line (x, y, x+w, y, c);
    gl_line (x, y, x, y+h, c);
    gl_line (x+w, y, x+w, y+h, c);
    gl_line (x, y+h, x+w, y+h, c);
    gl_copyboxtocontext (x, y, w+1, h+1, &phys, x, y);
    }

void
disp_select_cursor (MOUSE_WHERE where)
    {
    int x = where.x;
    int y = where.y;

    if (x >= pmlocx && x < pmlocx+efont.width*pmxspacing &&
	y >= pmlocy && y < pmlocy+efont.height*pmyspacing)
	mouse_set_cursor (MC_CROSS);
    else
	mouse_set_cursor (MC_ARROW);
    }

void
disp_show_banner(void)
    {
    gl_setcontext (&virt);
    gl_write (20,20,"Linux ");
    gl_write (20,50," Font ");
    gl_write (20,80,"Editor");
    gl_copyboxtocontext (20,20,50,75,&phys,20,20);
    }
