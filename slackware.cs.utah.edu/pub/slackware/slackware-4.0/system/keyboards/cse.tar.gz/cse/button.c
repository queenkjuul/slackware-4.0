
#include "conf.h"
#include <vga.h>
#include <vgagl.h>
#include "disp.h"
#include "button.h"
#include "font.h"

DIRTYSTATE dirty = DIRTY_SAVED;

const int buttextxoff = 5;
const int buttextyoff = 5;

typedef int (*BUTTONFUNC)(void);

typedef struct
    {
    int x, y, w, h;
    char text[9];
    BUTTONFUNC func;
    } BUTTON;

BUTTON buttons[] =
    {
	{ 290, 10, 70, 20,	" Rot \x18  ", f_rotup },
	{ 290, 40, 70, 20,	" Rot \x19  ", f_rotdn },
	{ 290, 70, 70, 20,	" Rot \x1b  ", f_rotleft },
	{ 290,100, 70, 20,	" Rot \x1a  ", f_rotright }, /* rot right */

	{ 370, 10, 70, 20,	" Clear  ", f_clear },
	{ 370, 40, 70, 20,	" Invert ", f_invert },
	{ 370, 70, 70, 20,	" Revert ", f_revert },

	{ 450, 10, 70, 20,	" Copy   ", f_copy },
	{ 450, 40, 70, 20,	" Paste  ", f_paste },
	{ 450, 70, 70, 20, 	" Flip V ", f_flipvert },
	{ 450,100, 70, 20,	" Flip H ", f_fliphoriz },

/* note: the labels of "save" and "exit" are overwritten dynamically */
	{ 550, 400, 70, 20,	" Saved. ", f_save },
	{ 550, 450, 70, 20,	" Exit   ", f_exit },

	{ 0, 0, 0, 0, "" }
    };
#define SAVE_BUTTON 11		/* index of save button */
#define EXIT_BUTTON 12		/* index of exit button */


void
draw_button(int i)
    {
    BUTTON *b = &buttons[i];
    int x1 = b->x;
    int y1 = b->y;
    int x2 = b->x+b->w-1;
    int y2 = b->y+b->h-1;

    gl_setcontext (&virt);

    /* draw box around outside of button */
    gl_line (x1, y1, x2, y1, BUTBORD_COLOR);
    gl_line (x1, y1, x1, y2, BUTBORD_COLOR);
    gl_line (x1, y2, x2, y2, BUTBORD_COLOR);
    gl_line (x2, y2, x2, y1, BUTBORD_COLOR);

    /* draw text inside button */
    gl_write (x1+buttextxoff, y1+buttextyoff, b->text);

    /* copy to physical */
    gl_copyboxtocontext (x1, y1, b->w, b->h, &phys, x1, y1);
    }

void
draw_buttons(void)
    {
    int i;

    for (i = 0; buttons[i].w != 0; ++i)
	{
	draw_button(i);
	}
    }

void
button_set_dirty(void)
    {
    static DIRTYSTATE oldstate = DIRTY_DISCARD;
    BUTTON *sv;
    BUTTON *ex;

    if (dirty == oldstate)
	return;
    oldstate = dirty;
    sv = &buttons[SAVE_BUTTON];
    ex = &buttons[EXIT_BUTTON];

    switch (dirty)
	{
    case DIRTY_SAVED:
	strcpy (sv->text, " Saved. ");
	strcpy (ex->text, " Exit   ");
	break;
    case DIRTY_DIRTY:
	strcpy (sv->text, " Save   ");
	strcpy (ex->text, " Exit   ");
	break;
    case DIRTY_OVERWRITE:
	strcpy (sv->text, "Overwrt?");
	strcpy (ex->text, " Exit   ");
	break;
    case DIRTY_DISCARD:
	strcpy (sv->text, " Save   ");
	strcpy (ex->text, "Discard?");
	break;
    case DIRTY_FAILED:
	strcpy (sv->text, " Failed!");
	strcpy (ex->text, " Exit   ");
	break;
	}
    draw_button(SAVE_BUTTON);
    draw_button(EXIT_BUTTON);
    mouse_force_redraw();
    }

int
button_handle_click (MOUSE_WHERE where)
    {
    int x = where.x;
    int y = where.y;
    int i;
    int ret;

    for (i = 0; buttons[i].w != 0; ++i)
	{
	BUTTON *b = &buttons[i];
	if (x >= b->x && x < b->x+b->w &&
	    y >= b->y && y < b->y+b->h)
	    {
	    ret = b->func();	/* button #i was pressed */
	    button_set_dirty();
	    return (ret);
	    }
	}
    return (0);			/* "do not exit" */
    }
