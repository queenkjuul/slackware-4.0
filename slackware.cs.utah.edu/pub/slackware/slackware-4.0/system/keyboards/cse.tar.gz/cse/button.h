
#ifndef __BUTTON_H__
#define __BUTTON_H__

#include "mouse.h"

typedef enum
    {
    DIRTY_SAVED,
    DIRTY_DIRTY,
    DIRTY_OVERWRITE,
    DIRTY_DISCARD,
    DIRTY_FAILED
    } DIRTYSTATE;

extern DIRTYSTATE dirty;

void draw_button(int i);
void draw_buttons(void);
void button_set_dirty (void);
int button_handle_click (MOUSE_WHERE where);

#endif
