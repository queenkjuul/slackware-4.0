
/* mouse.c -- handle mouse stuff */

#include "conf.h"
#include <vga.h>
#include <vgagl.h>
#include "mouse.h"
#include "disp.h"

typedef struct
    {
    int xhot;
    int yhot;
    char pixels[MC_W * MC_H];
    } MOUSE_CURSOR;

#define CC CURSOR_COLOR

static MOUSE_CURSOR mc_cross =
    {
    3, /* x hotspot offset */
    3, /* y hotspot offset */
	{
        0,  0,  0, CC,  0,  0,  0,  0,
	0,  0,  0, CC,  0,  0,  0,  0,
	0,  0,  0, CC,  0,  0,  0,  0,
       CC, CC, CC, CC, CC, CC, CC,  0,
	0,  0,  0, CC,  0,  0,  0,  0,
	0,  0,  0, CC,  0,  0,  0,  0,
	0,  0,  0, CC,  0,  0,  0,  0,
	0,  0,  0,  0,  0,  0,  0,  0
	}
    };

static MOUSE_CURSOR mc_arrow =
    {
    0, /* x hotspot offset */
    0, /* y hotspot offset */
	{
       CC, CC, CC, CC,  0,  0,  0,  0,
       CC, CC, CC,  0,  0,  0,  0,  0,
       CC, CC, CC, CC,  0,  0,  0,  0,
       CC,  0, CC, CC, CC,  0,  0,  0,
        0,  0,  0, CC, CC, CC,  0,  0,
        0,  0,  0,  0, CC, CC, CC,  0,
        0,  0,  0,  0,  0, CC, CC,  0,
	0,  0,  0,  0,  0,  0,  0,  0
	}
    };

static MOUSE_CURSOR *mouse_cursor = &mc_arrow;

/* poll mouse:
   handles mouse cursor movement, replacement of pixels underneath.

   always writes location to "where".  Returns 1 on button down.
   */

static int lastx = -1;		/* previous mouse info */
static int lasty = -1;
static int lastb = 0;

int
poll_mouse(MOUSE_WHERE *where)
    {
    int x, y, b;		/* current mouse info */
    static int lastcurx, lastcury; /* loc mouse cursor last drawn */
    int xh = mouse_cursor->xhot; /* temporaries to save time */
    int yh = mouse_cursor->yhot;

    /* get mouse location, adjust for hotspot offset, force in screen */
    /* also check buttons */
    mouse_update();
    x = mouse_getx();
    if (x < xh)
	x = xh;
    else if (x - xh + MC_W > WIDTH)
	x = WIDTH - MC_W + xh;
    y = mouse_gety();
    if (y < yh)
	y = yh;
    else if (y - yh + MC_H > HEIGHT)
	y = HEIGHT - MC_H + yh;
    b = mouse_getbutton();

    where->x = x;
    where->y = y;

    /* if the mouse has moved, update the mouse cursor display */

    if (x != lastx || y != lasty)
	{
	gl_setcontext (&phys);

	/* replace bits underneath old mouse cursor position */
	if (lastx != -1)
	    gl_copyboxfromcontext (&virt, lastcurx, lastcury,
				   MC_W, MC_H,
				   lastcurx, lastcury);

	/* then draw mouse cursor direct to phys screen in new place */
	lastcurx = x - xh;
	lastcury = y - yh;
	gl_putboxmask (lastcurx, lastcury, MC_W, MC_H,
		       mouse_cursor->pixels);
	lastx = x;
	lasty = y;
	disp_show_hovercode(*where);
	disp_select_cursor(*where);
	}

    /* if button was pressed, see if we need to report the event */

    if (b != lastb)
	{
	lastb = b;
	if (b)
	    return 1;
	}

    return 0;
    }

void
mouse_set_cursor (MOUSE_CURSOR_SELECTOR which)
    {
    switch (which)
	{
    case MC_ARROW:
	mouse_cursor = &mc_arrow;
	break;
    case MC_CROSS:
	mouse_cursor = &mc_cross;
	break;
	}
    }

void
mouse_force_redraw (void)
    {
    lastx = -1;
    lasty = -1;
    }
