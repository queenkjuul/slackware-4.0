
#ifndef __DISP_H__
#define __DISP_H__

#include <vga.h>
#include <vgagl.h>
#include "mouse.h"

#define VGAMODE G640x480x256	/* dangerous to mess with */

extern GraphicsContext phys, virt;

int init_display(void);
void shut_display(void);
void disp_show_font (void);	/* display current font on screen */
void disp_show_banner(void);
void disp_show_hovercode (MOUSE_WHERE where); /* show where mouse is */
int disp_get_chrcode (MOUSE_WHERE where); /* get code for where mouse is */
void edit_chr (int index);
void redraw_chr(void);
void twiddle_pixmap_bit (MOUSE_WHERE where);
void highlight_chr (int index, int on);
void disp_select_cursor (MOUSE_WHERE where);
#endif
