#ifndef GET_ADDRS_H
#define GET_ADDRS_H

#include <netinet/in.h>

struct in_addr* get_addrs(int argc, char** argv);

#endif
