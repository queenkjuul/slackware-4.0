#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <syslog.h>

#include "get_addrs.h"
#include "mkb.h"

unsigned char bailout[]={54,225,29,69,225,157,197,182};

int main(int argc, char** argv)
{
  struct in_addr* connect_to;
  int* sockets;
  int device;

  int current;
  int count;
  int ind=0;
  int pid;

  
  openlog(argv[0],LOG_PID,LOG_DAEMON);
  connect_to=get_addrs(argc,argv);
  if (!connect_to) {
    fprintf(stderr,"No valid hosts found to connect to\n");
    exit(1);
  }
  count=0;
  while(connect_to[count].s_addr)
    count++;
  sockets=(int*)malloc(count*sizeof(int));
  if (!sockets) {
    fprintf(stderr,"Out of memory\n");
    exit(1);
  }
  current=0;
  while (current<count) {
    struct sockaddr_in addr;

    sockets[current]=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    if (sockets[current]<0) {
      perror("mkb...opening socket");
      exit(1);
    }
    bzero((char*)&addr,sizeof(addr));
    addr.sin_family=AF_INET;
    addr.sin_addr=connect_to[current];
    addr.sin_port=htons(PORT);
    if (connect(sockets[current],(struct sockaddr*)&addr,sizeof(addr))==-1) {
      int i;

      perror("mkb...Connection failed");
      fprintf(stderr,"  Connection in question was no %d\n",current);
      for (i=0;i<count;i++)
	close(sockets[i]);
      exit(1);
    }
    current++;
  }
  current=0;
  device=open("/dev/mkbd",O_RDONLY);
  if (device<0) {
    fprintf(stderr,"mkb...Couldn't open /dev/mkbd");
    exit(1);
  }
  /* OK, we are up and running. Let's go into the background */
  pid=fork();
  if (pid<0) {
    /* Oops! couldn't fork to disassociate myself. BAD! */
    perror("mkbd...fork to disassociate");
    exit(1);
  }
  if (pid) /* The one our parent is waiting for */
    exit(0);  /* daemon was started up OK */
  close(0);  /* The daemon should leave the terminal alone */
  close(1);
  close(2);

  while (1) {
    unsigned char c;

    if (read(device,&c,1)<1) {
      syslog(LOG_WARNING,"Something really weird happened to /dev/mkbd\n");
      close(device);
      exit(1);
    }
    if (c==bailout[ind]) {
      ind++;
    }
    else
      ind=0;
	
    switch(c) {
    case 70:   /* Scroll Lock down */ 
      current++;
      if (current==count)
	current=0;
      break;
    case 198: /* Scroll lock up. Ignore! */
      break;
    default:
      if (write(sockets[current],&c,1)<1) {
	syslog(LOG_ERR,"ARGH! Couldn't write to socket %d!\n",current);
      }
      break;
    }
    if (ind==(sizeof(bailout)/sizeof(bailout[0]))) {
      syslog(LOG_INFO,"Bailing out RIGHT NOW!\n");
      close(device);
      exit(0);
    }
  }
}
