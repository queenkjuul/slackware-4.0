#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>

#include "get_addrs.h"
#include "mkb.h"

/* server (putting key events to the higher level driver) */
int main(int argc, char** argv)
{
  int incoming_socket;
  int connected_socket;
  struct in_addr* valid;
  struct sockaddr_in addr;
  int pid;

  openlog(argv[0],LOG_PID,LOG_DAEMON);
  valid=get_addrs(argc, argv);
  if (!valid) {
    fprintf(stderr,"No valid hostnames found to listen to. Exiting\n");
    exit(1);
  }
  incoming_socket=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
  if (incoming_socket<0) {
    perror("mkbd...writer opening socket");
    exit(1);
  }
  /* All right, we have a socket. Now let's name it */
  bzero((char*)&addr,sizeof(addr));
  addr.sin_family=AF_INET;
  addr.sin_addr.s_addr=htonl(INADDR_ANY);
  addr.sin_port=htons(PORT);
  if (bind(incoming_socket,(struct sockaddr*)&addr,sizeof(addr))==-1) {
    perror("mkbd...binding socket");
    exit(1);
  }
  if (listen(incoming_socket,5)==-1) {
    perror("mkbd...listening");
    exit(1);
  }

  /* Right, we have gone through all the initial steps. Now let's get 
     detach from the terminal, and disassociate from our parent */
  pid=fork();
  if (pid<0) {
    /* Oops! couldn't fork to disassociate myself. BAD! */
    perror("mkbd...fork to disassociate");
    exit(1);
  }
  if (pid) /* The one our parent is waiting for */
    exit(0);  /* daemon was started up OK */
  close(0);  /* The daemon should leave the terminal alone */
  close(1);
  close(2);
  
  for (;;) {
    int pid;
    struct sockaddr_in incoming;
    struct in_addr got_addr;
    size_t incsize=sizeof(incoming);
    int ind;

    connected_socket=accept(incoming_socket,(struct sockaddr*)&incoming,
			    &incsize);
    if (connected_socket==-1) {
      syslog(LOG_CRIT,"accept %m. Exiting\n");
      exit(1);
    }
    /* Also, there is another huge problem. The child processes should really
       denounce their parent and be adopted by init. How do you do that, other
       than forking all over the place?
       The following is a nasty hack at best! FIXME */
    while (waitpid(-1,NULL,WNOHANG)>0)
      ;


    got_addr=incoming.sin_addr;

    ind=0;
    while (valid[ind].s_addr!=got_addr.s_addr && valid[ind].s_addr)
      ind++;
    if (valid[ind].s_addr==0) {
      syslog(LOG_WARNING, "Warning! Failed connection attempt from address %x\n",got_addr.s_addr);
      close(connected_socket);
    }
    else { /* start a server */
      pid=fork();
      if (pid<0) {
	syslog(LOG_CRIT,"forking server process: %m\n");
	close(connected_socket);
      }
      else if (!pid) { /* Handle this connection */
	FILE* mkbd_dev;
	unsigned char c;
	int ret;
	
	while (1) {
	  ret=read(connected_socket,&c,1);
	  if (ret<1) {
	    close(connected_socket);
	    exit(1);
	  }
	  /* We open and close /dev/mkbd for each singly byte. This might
	     seem excessive, but really shouldn't be. After all, this is
	     handling keyboard events --- so at the max there should be a few
	     such events a second. OTOH, whenever /dev/mkbd is open, the
	     local keyboard is disabled. I'd much rather burn a few CPU
	     cycles than lock myself out of my own machine by accident */
	  mkbd_dev=fopen("/dev/mkbd","w");
	  if (!mkbd_dev) {
	    syslog(LOG_ALERT,"couldn't open /dev/mkbd. Exiting\n");
	    close(connected_socket);
	    exit(1);
	  }
	  putc(c,mkbd_dev);
	fclose(mkbd_dev);  
	}
      }
      /* main writer process */
      close(connected_socket);
    }
  }
  return 0;
}
