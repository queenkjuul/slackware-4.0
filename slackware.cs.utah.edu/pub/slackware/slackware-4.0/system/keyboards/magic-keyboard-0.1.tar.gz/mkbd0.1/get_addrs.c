#include "get_addrs.h"
#include <stdio.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <netdb.h>

struct in_addr* get_addrs(int argc, char** argv)
{
  struct in_addr* x;
  int i;
  int ind=0;

  if (argc<2)
    return NULL;
  x=(struct in_addr*)malloc(argc*sizeof(struct in_addr));
  for  (i=0;i<argc-1;i++) {
    struct hostent* tmp;

    tmp=gethostbyname(argv[i+1]);
    if (!tmp ||
	tmp->h_addrtype!=AF_INET ||
	tmp->h_length!=sizeof(struct in_addr)) {
      fprintf(stderr,"Failure looking up %s. Ignoring\n",argv[i+1]);
    }
    else {
      x[ind++]= *((struct in_addr*)tmp->h_addr);
    }
  }
  /* Now we _know_ how many of the addresses could be looked up. Let's
     reshuffle */
  if (ind) {
    x=(struct in_addr*)realloc(x,(ind+1)*sizeof(struct in_addr));
    x[ind].s_addr=0;
    return x;
  }
  free(x);
  return NULL;
}

