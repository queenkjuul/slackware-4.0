/*	
 *   diacrd - diacritical translator for RAW mode
 *
 *   Copyright (C) 1995 C�dric Adjih
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 *   Modified for US layout with diacritical translations used in 
 *   Brazil by En�as Ulir de Queiroz September 17, 1996.
 *   Small mod (see below) to make it compatible with XFree86 3.2
 *   by Andr� Balsa <andrewbalsa@usa.net> May 1997.
 * 
 */

/*
 * This program is a user-space process, that takes data from 
 * /dev/ramkbd when in RAW mode, translates diacriticals into
 * acceptable codes, and puts them back into /dev/rawkbd
 * Not configurable: US-international keyboard layout only supported,
 * sorry. Other layouts to be supported in future versions...
 */

/******************************* CONFIGURATION ******************************/

/* Uncomment this to disable the automatic xmodmap feature */
/* #define NO_XMODMAP */

/* Uncomment this to disable keyboard driven CDROM mounting/unmounting */
/* #define NO_CD_MANIPULATION */

/* You can define your CDROM device and your mount point. These are overridden
   by the options -c <cdrom device> and -m <mount point> anyway. */
#define DEFAULT_CDROM_DEVICE      "/dev/cdrom"
#define DEFAULT_CDROM_MOUNT_POINT "/mnt/cdrom"

/****************************************************************************/

/*
 * FIXME:
 * [] problem when an interrupt is received: an incorrect keycode is sent
 * (problem in the vk kernel code: interruptible sleep/wake up ?).
 */

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <linux/rawkbd.h>
#include <signal.h>
#include <errno.h>
#include <syslog.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <string.h>
#include <sys/wait.h>
#include "cdmanip.h"

#define LOGERR(x...) ({ syslog(LOG_ERR,x); })
#define DBG(x...) ({ if (debug) syslog(LOG_DEBUG,x); })
#define NOTICE(x...) ({ syslog(LOG_NOTICE,x); })

#define VK_DEVICE "/dev/rawkbd"

#define CD_IN_SPECIAL 105  /* FIXME: should be in rawkbd.h */
#define CD_OUT_SPECIAL 111
#define CD_OUT_VIOLENT_SPECIAL 118

#define GRAVE 1
#define CUTE  2
#define CIRC  3
#define TREMA 4
#define TILDE 5

#define SHIFT_P (SHIFT_L_PRESSED | SHIFT_R_PRESSED)

typedef struct {
  unsigned char initial;
  unsigned char type;
  unsigned char final;
} translation_t;

/* Universal translation table: should be taken from kernel ? */
translation_t translation_table[]={
  { 'a', GRAVE, '�'}, { 'e', GRAVE, '�'}, { 'i', GRAVE, '�'},
  { 'o', GRAVE, '�'}, { 'u', GRAVE, '�'},
  { 'a', CUTE,  '�'}, { 'e', CUTE,  '�'}, { 'i', CUTE,  '�'},
  { 'o', CUTE,  '�'}, { 'u', CUTE,  '�'},
  { 'a', CIRC,  '�'}, { 'e', CIRC,  '�'}, { 'i', CIRC,  '�'},
  { 'o', CIRC,  '�'}, { 'u', CIRC,  '�'}, 
  { 'a', TREMA, '�'}, { 'e', TREMA, '�'}, { 'i', TREMA, '�'},
  { 'o', TREMA, '�'}, { 'u', TREMA, '�'},
  { ' ', GRAVE, '\''}, { ' ', CUTE, '`'},  
  { ' ', CIRC, '^'},  { ' ', TREMA, '"'}, 
  { 'c', GRAVE, '�' }, /* this one is hackish */
  { 'a', TILDE, '�'}, { 'o', TILDE, '�'}, { 'n', TILDE, '�' },
  { ' ', TILDE, '~'}, 
  { '\0', 0, '\0' }
};

/* Specific translation table */
/* This table is initialized with the keycode values returned
 * by diacrd when a translation occurs.
*/ 
unsigned char keycode_translation[256]={'\0',};
#define S(i) ({ keycode_translation[(unsigned char)i]=current_code++; })
void set_keycode(void)
{
  int current_code=106;

  S('�');S('�');S('�');S('�');
  S('�');
  S('�'); S('�'); S('�'); S('�');
  S('�'); S('�'); S('�'); S('�');
  S('�');S('�');S('�');S('�');
  S('�');S('�');S('�');S('�');
  S('`');
  keycode_translation[(unsigned char)'^']=84;
  keycode_translation[(unsigned char)'~']=85;
  keycode_translation[(unsigned char)'"']=93;
  keycode_translation[(unsigned char)'\'']=0;
}

/* Specific tests : you may have to change these */
#define CIRC_PRESSED(h) (((h).scancode==7) && (((h).shift_state&SHIFT_P)!=0))
#define TREMA_PRESSED(h) (((h).scancode==40) && (((h).shift_state&SHIFT_P)!=0))
#define GRAVE_PRESSED(h) (((h).scancode==40) && (((h).shift_state&SHIFT_P)==0))
#define CUTE_PRESSED(h) (((h).scancode==41) && (((h).shift_state&SHIFT_P)==0))
#define TILDE_PRESSED(h) (((h).scancode==41) && (((h).shift_state&SHIFT_P)!=0))

/* diacritical / state */
static int diacritical=0;
static int new_diacritical=0;
static int diacritical_released=0;
static unsigned char diacr_code=0; /* code of the translated character */
static unsigned char scancode=0;   /* raw keyboard code before translation */
#define RELEASE 0x80


/* File descriptor of VK_DEVICE */
int fd=-1;
long stat_sent =0;

static int debug=0;

unsigned char combine(unsigned char c, int a_diacritical)
{
  int i;
  unsigned char result=c;
  for (i=0;translation_table[i].initial != 0;i++)
    if (translation_table[i].initial == c 
	&& translation_table[i].type == a_diacritical)
      result=translation_table[i].final;
  DBG(" combine : '%c'+%d=>%d",c,a_diacritical,result);
  return result;
}

unsigned char ascii2keycode(unsigned char c)
{
  unsigned char result;
  if ((keycode_translation[c] != '\0') || (c == '\'')) 
    result=keycode_translation[c];
  else
    result=c;
  DBG(" ascii2code : %d,'%c'=>%d\n",c,c,result);
  return result;
}

void writec(unsigned char c)
{ write(fd,&c,1); DBG(" (writec %d) ",c); stat_sent++; }

/* The main function that does actual conversion
 * 
 * (next time, I would implement a true state machine ;-) )
 */
void hook_diacritical(kbd_hook_data_t* hook_data_ptr)
{
  unsigned char code;
#define hook_data (*hook_data_ptr) /* lossage */
   
  if (hook_data.code_to_put == -1)
    return;
  code=(unsigned char)(hook_data.code_to_put)&(~RELEASE);

  if (!hook_data.upflag) {
    /* .................... a key was pressed */
    DBG("key PRESSED, %d /",scancode);
    if (TREMA_PRESSED(hook_data) || CIRC_PRESSED(hook_data)
          || TILDE_PRESSED(hook_data)
	  || CUTE_PRESSED(hook_data) || GRAVE_PRESSED(hook_data)) {
      /* Diacritical */
      if (TREMA_PRESSED(hook_data))
	new_diacritical=TREMA;
      else if (CIRC_PRESSED(hook_data))
	new_diacritical=CIRC;
      else if (CUTE_PRESSED(hook_data))
	new_diacritical=CUTE;
      else if (GRAVE_PRESSED(hook_data))
	new_diacritical=GRAVE;
      else if (TILDE_PRESSED(hook_data))
	new_diacritical=TILDE;
      /* else  cannot happen */ 
      DBG("  diacr %d ",new_diacritical);

      if (diacritical == 0) {
	DBG(" : new diacr\n");
	diacritical = new_diacritical;
	diacritical_released = 0;
	diacr_code = 0;
      } else {
	if (diacritical_released) {
	  DBG(" / another diacr before ");
	  if (diacritical == new_diacritical) {
	    /* twice the same diacritical */
	    DBG(" / the same, in fact\n");
	    diacr_code=code;
	    /*ascii2keycode(combine(' ',diacritical));*/
	    writec(diacr_code);
	    scancode=code;
	    diacritical=0;
	    /* diacritical_released=0; */
	  } else {		
	    /* another diacritical */
	    DBG(", %d\n",diacritical);
	    diacritical=new_diacritical;
	    diacritical_released=0;
	  }
	} else DBG(" former diacr not released\n") /* nothing to do */ ;
      }
    } else { /* Standard key */
      DBG(" non-diacr");
      if ((diacritical != 0) /* && diacritical_released */ ) { /* */
	if (code==KB_CTRL_L || code==KB_CTRL_R || code==KB_ALT_L
	    || code==KB_ALT_R || code==KB_SHIFT_R || code==KB_SHIFT_L) {
	  DBG(" avoid-combination"); /* FIXME: check this */
	  writec(code);
	} else {
	  DBG(" combine with diacr");
	  /*  DBG("[%d %d]\n",hook_data.keysym,
	      combine(hook_data.keysym,diacritical));*/
	  if (combine((hook_data.keysym&0xff),diacritical)
	      ==(hook_data.keysym&0xff)) { 
	    /* diacritical does not work */
	    DBG("/failed: '%c' + %d\n",hook_data.keysym,diacritical);
	    writec(ascii2keycode(combine(' ',diacritical)));
	    writec(RELEASE|ascii2keycode(combine(' ',diacritical)));
	    writec(code);
	    diacritical=0;
	  } else {		/* diacritical combinaison works */
	    diacr_code=ascii2keycode(combine(hook_data.keysym&0xff,
					     diacritical));
	    DBG(" succeded : '%c' -> '%c' -> %d\n",
		hook_data.keysym,combine(hook_data.keysym&0xff,
					 diacritical),diacr_code);
	    writec(diacr_code);
	    scancode=code;
	    diacritical=0;
	  }
	}
      } else {
	DBG(" no pre-diacr / code = %d\n",code);
	writec(code);
      }
    }
  } else {
      /* .................... a key was released */
      DBG("key RELEASED, %d /",scancode);
      if (TREMA_PRESSED(hook_data) || CIRC_PRESSED(hook_data)
          || TILDE_PRESSED(hook_data)
	  || CUTE_PRESSED(hook_data) || GRAVE_PRESSED(hook_data)) { 
	/* Diacritical */
	DBG(" diacr");
	if (diacritical == 0) { 
	  /* a diacriticalal is was pressed twice ; second release */
	  writec(RELEASE|diacr_code);
	  scancode=0;
	  DBG(" second release\n");
	} else {
	  DBG(" first release\n");
	  diacritical_released=1;
	}
      } else { /* non diacritical */
	DBG(" non-diacr");
	if (code == scancode) {			
	  /* the transformed key was released */
	  writec(RELEASE|diacr_code);
	  scancode=0;
	  DBG(" release of transformed %d\n",diacr_code);
	} else {
	  writec(RELEASE|code);
	  DBG(" normal\n");
	}
      }
    }
#undef hook_data
}

void special(unsigned char code);
void process_one_key(void)
{
  kbd_hook_data_t hook_data;
  do {
    if (read(fd,&hook_data,sizeof(hook_data))<0)
      continue;
    if (hook_data.special!=0)
      special(hook_data.special);    
  } while(hook_data.special!=0);
  hook_diacritical(&hook_data);
}

/*---------------------------------------------------------------------------*/
/*
 * Creeping featurism :
 *
 * The kernel sends also "special" events, when [ALT_RIGHT]+[ALT_LEFT]+[something]
 * is pressed.
 *
 * This allows for special actions to be done when a defined key combinaison 
 * is pressed :
 * - for instance, [ALT_RIGHT]+[ALT_LEFT]+[x] does a "xmodmap"
 *                 [ALT_RIGHT]+[ALT_LEFT]+[i] (In) mounts a CD
 *                 [ALT_RIGHT]+[ALT_LEFT]+[o] (Out) unmounts the CD
 */

char* cdrom_device=DEFAULT_CDROM_DEVICE;
char* cdrom_mount_point=DEFAULT_CDROM_MOUNT_POINT;
char* display_name=NULL; /* set in main() */

#if 0
/* This was intended to restore */
int tty_fd=-1; /* descriptor of /dev/tty */

unsigned long screen_mode;
unsigned long kbd_mode;

void check_ioctl(int request, char* arg)
{
  if (ioctl(tty_fd,request,arg)<0) {
    perror("ioctl :");
    exit(EXIT_FAILURE);
  }
}

void init_recovery()
{
  tty_fd=open("/dev/tty",O_RDWR);
  if (tty_fd<0) {
    LOG("Error while opening '/dev/tty': ");
    exit(EXIT_FAILURE);
  }
  check_ioctl(KDGETMODE,(char*)&screen_mode);
  check_ioctl(KDGKBMODE,(char*)&kbd_mode);
}
#endif

/* Don't be a read-only-minded fascist: don't redefine the whole keyboard */
char xmodmap_changes[]="!
keycode 114 = agrave
keycode 115 = aacute
keycode 116 = acircumflex
keycode 117 = atilde
keycode 118 = ccedilla
keycode 119 = egrave
keycode 120 = eacute
keycode 121 = ecircumflex
keycode 122 = ediaeresis
keycode 123 = igrave
keycode 124 = iacute
keycode 125 = icircumflex
keycode 126 = idiaeresis
keycode 127 = ograve
keycode 128 = oacute
keycode 129 = ocircumflex
keycode 130 = otilde
keycode 131 = ugrave
keycode 132 = uacute
keycode 133 = ucircumflex
keycode 134 = udiaeresis
keycode 135 = grave 
keycode 8 = apostrophe
keycode 92 = asciicircum
keycode 93 = asciitilde
keycode 101 = quotedbl
";

void special_set_xmodmap(void)
{
#ifdef NO_XMODMAP
  LOGERR("<Alt>-<AltGr>-x pressed, user probably tried to have xmodmap started"
	 " by diacrd");
#else
  char name[1024]; /*hce*/
  FILE* xmodmap_file;
  if (display_name == NULL || strlen(display_name)>900) {
    LOGERR("can't do special xmodmap action: display not defined");
    return;
  }
  sprintf(name,"/usr/bin/X11/xmodmap - -display %s",display_name);
  xmodmap_file=popen(name,"w");
  if (xmodmap_file==NULL) {
    LOGERR("special xmodmap action failed. Was: %s",name);
    return;
  }
  fprintf(xmodmap_file,"%s",xmodmap_changes);
  pclose(xmodmap_file); /* FIXME: can block */
  NOTICE("special action xmodmap: %s",name);
#endif
}

void cd_in(void)
{
  if (cd_mount(cdrom_device,cdrom_mount_point)<0)
    buzz_bad();
  else buzz_ok();
}

void cd_out(void)
{
  if(cd_umount(cdrom_device)<0) {    
    buzz_bad();
    log_cd_users(cdrom_device);
  }
}

void cd_out_violent(void)
{ buzz(700,200); /* FIXME */ }

void init_special(void)
{
  /* nothing */
}

/* add your "case" in this function */
void special(unsigned char code)
{
  switch (code) {
  case XMODMAP_SPECIAL:
    special_set_xmodmap();
    break;
  case SAK_SPECIAL:
    NOTICE("SAK done");
    break;

#ifdef NO_CD_MANIPULATION
  case CD_IN_SPECIAL:     
  case CD_OUT_SPECIAL:     
/*  case CD_OUT_VIOLENT_SPECIAL:*/
     LOGERR("<Alt>-<AltGr>-<i> or <o> pressed, user probably tried to have "
	    "the cdrom mounted or unmounted by diacrd");
     break;
#else          
  case CD_IN_SPECIAL:
    cd_in();
    break;
  case CD_OUT_SPECIAL:
    cd_out();
    break;
/*  case CD_OUT_VIOLENT_SPECIAL:
    cd_out_violent();
    break;*/
#endif

  default:    
    DBG("keys sent = %d\n",(int)stat_sent);
    DBG("Special action received : %d\n",(int)code);
  }
}

/*---------------------------------------------------------------------------*/

void terminate(int signo)
{
  NOTICE("exiting on TERM signal.");
  closelog(); /* optional */
  exit(EXIT_SUCCESS);
}

/* Be wild, become a daemon */
void daemonize(void)
{
  int fd,code,i;

  /* don't stay on a filesystem that might need to be unmounted (& core in /)*/
  (void) chdir("/");

  /* close every file descriptor */
  for (i=getdtablesize()-1; i>=0; i--)
    (void) close(i);

  /* initiate logging */
  openlog("diacrd",LOG_PID,LOG_DAEMON);

  /* own process group */
  (void) setpgid(0, getpid());

  /* fork */
  code=fork();
  if (code<0) {
    LOGERR("fork: %s",strerror(errno));
    exit(EXIT_FAILURE);
  }
  if (code != 0)
    exit(EXIT_SUCCESS);

  /* own session */
  setsid();

  /* no more controlling tty/new session : redondant (setsid) */
  fd = open("/dev/tty", O_RDWR);
  (void) ioctl(fd, TIOCNOTTY, 0);
  (void) close(fd);

  /* mutual exclusion should be handled by kernel vk-open */

  /* minimal handling of signals */
  (void) signal(SIGHUP,SIG_IGN);
  (void) signal(SIGTERM,terminate);
}

/*---------------------------------------------------------------------------*/

int main(int argc, char** argv)
{ 
  /* ----- parse option(s) ----- */

  int copt;
  opterr = 0;
  while ((copt = getopt (argc, argv, "dc:m:x:")) != -1)
    switch (copt) {
    case 'x':
      display_name=strdup(optarg);
      break;
    case 'c':
      cdrom_device=strdup(optarg);
      break;
    case 'm':
      cdrom_mount_point=strdup(optarg);
      break;
    case 'd':
      debug=1;
      break;
    case '?':
    default:
      fprintf(stderr,"Unknown option -%c\n", optopt);
      exit(EXIT_FAILURE);
    }

  if (optind<argc) {
    fprintf(stderr,"No arg expected, got '%s'\n",argv[optind]);
    exit(EXIT_FAILURE);
  }

  /* ----- start serious things ----- */

  daemonize();
  fd=open(VK_DEVICE,O_RDWR);
  if (fd == -1) {
    LOGERR("opening device '%s': %s",VK_DEVICE,strerror(errno));
    exit(EXIT_FAILURE);
  }
  NOTICE("started.");
  init_special();
  set_keycode();
  for(;;)
    process_one_key();
}
