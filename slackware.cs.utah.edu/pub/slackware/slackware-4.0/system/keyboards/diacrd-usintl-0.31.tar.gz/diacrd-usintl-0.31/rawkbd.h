/*
 * Definitions for RAW keyboard interface.
 *
 * March 1995, C�dric Adjih
 */

/* I do not know whether they are "portable" or not. They were found
 * with "showkey"
 */

#define KB_CTRL_L    29
#define KB_CTRL_R    97
#define KB_ALT_L     56
#define KB_ALT_R    100
#define KB_SHIFT_L   42
#define KB_SHIFT_R   54
#define KB_F1        59
#define KB_F2        60
#define KB_F3        61
#define KB_F4        62
#define KB_F5        63
#define KB_F6        64
#define KB_F7        65
#define KB_F8        66
#define KB_F9        67
#define KB_F10       68
#define KB_BACKSPACE 14

#define CTRL_L_PRESSED  (1<<0)
#define CTRL_R_PRESSED  (1<<1)
#define ALT_L_PRESSED   (1<<2)
#define ALT_R_PRESSED   (1<<3)
#define SHIFT_L_PRESSED (1<<4)
#define SHIFT_R_PRESSED (1<<5)

typedef struct  {
  unsigned char special;
  int  kbd_mode;
  int  code_to_put;
  char upflag;
  unsigned char scancode;
  unsigned char keycode;
  ushort  key_map;
  u_char  initial_type;
  u_char  type;
  u_short keysym;
  int shift_state;
} kbd_hook_data_t;

#define RECOVERY_SPECIAL 0xff
#define SAK_SPECIAL      0xfe
#define XMODMAP_SPECIAL  120
