/* (c) Ricardas Cepas <rch@pub.osf.lt>. Copying policy: BSD or GNU GPL V2. */
#include <stdlib.h>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

extern int testUTF8 (void);

main ()
{
  wchar_t wchar;
  int i, UTFmode;

  if ((UTFmode = testUTF8 ()) <= 127)
    {
      /* ^X^Z cancel any ESC sequence, to UTF-8, underline on */
      printf(" ");
      if (UTFmode != 127) printf ("\030\032\033%%G\033[4m");
      printf ("      0 1 2 3 4 5 6 7 8 9 A B C D E F 0 1 2 3 4 5 6 7 8 9 A B C D E F");
      if (UTFmode != 127) printf ("\033[24m"); /* underline off */
      puts("  ");
      for (i = 0; i < 512; i++)
	{
	  if (i % 32 == 0)
	    printf (" %.3x:  ", i);
/*      if (wctomb(s, (wchar_t)(0xf000+i))==-1) exit(-1); */
	  printf ("%c%c%c ", (0xef), (0x80 + i / 0x40), (0x80 + (i & 0x3f)));
	  if (i % 32 == 31)
	    puts ("");
	}
      if (UTFmode == 0)
	{
	  printf ("\033%%@");	/* restore non unicode mode */
	  UTFmode = 1;
	}
      else
	UTFmode = 0;
    }
  exit (UTFmode);
}
/*
   $ echo -ne '\033%G'     # Unicode mode.
   $ echo -ne '\033%@'     # Old single byte char mode.
 */
