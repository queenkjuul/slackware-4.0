#!/bin/sh
#set -nx
# © Ričardas Čepas <rch@WriteMe.Com>. Copying policy: Berkeley style.
bold () {
	tput bold || tput md
	printf "$*"
	tput sgr0 || tput me
}
BASE_DIR="`pwd`/`dirname $0`"
backup="$BASE_DIR/../backup/backup.tar"
export backup BASE_DIR
test -d "`dirname $backup`" || mkdir "`dirname $backup`"
bold "Making backup in $backup\\n"
test -e "$backup" -a ! -e "$backup.gz" && gzip -f "$backup"
> "$backup"
chmod u=rw,g=,o= "$backup"
backup () {
	tar vrf "$backup" "$@"
}
[ "$Xbasedir" = "" ] && Xbasedir=/usr/X11R6; export Xbasedir
uname="`uname`"
export uname



bold 'Make neccesary changes to configuration files? [Y/n]'
read a e
if [ "${a#[Nn]}" = "$a" ]; then

  if test -e /etc/login.defs; then
	  if perl -e 'undef $/; $_=<>;
	  exit( m/^\s*#\s*(ENVIRON_FILE|TTYTYPE_FILE|ERASECHAR\s*0177)/m || m/^[\t ]*ERASECHAR[\t ]*0177/m ? 0:1)
	  ' /etc/login.defs; then
		  backup /etc/login.defs
		  perl -i.orig -e 'undef $/; $_=<>;
			  s!^\s*#\s*ENVIRON_FILE.*$!# $&\nENVIRON_FILE   /etc/environment!m unless m/^ *ENVIRON_FILE/m;
			  s!^\s*#\s*TTYTYPE_FILE.*$!# $&\nTTYTYPE_FILE   /etc/ttytype!m unless m/^ *TTYTYPE_FILE/m;
			  s/^\s*#?\s*ERASECHAR\s*0177.*$/## $&\nERASECHAR	010/m unless m/^[\t #]*ERASECHAR\s*010/m;
		  print; ' /etc/login.defs
	  fi
	  test ! -e /etc/environment && touch /etc/environment
	  if ! grep -q '^ *LANG=' /etc/environment ; then
		  backup /etc/environment
		  cp -p /etc/environment /etc/environment.orig
		  printf '\nLANG=lt_LT.ISO_8859-4\nMM_CHARSET=ISO-8859-4\nXENVIRONMENT=/usr/local/share/x-lt/Xresources\n' >>/etc/environment
	  fi
	  if test -e /etc/ttytype; then \
	    if ! { grep -q 'linux+k' /etc/ttytype \
	    || grep -q 'linux.*+utf8' /etc/ttytype \
	    || grep -q 'cons[0-9][0-9]*l1' /etc/ttytype; }; then
		  backup /etc/ttytype
		  perl -i.orig -pe 's/linux(\s)/linux+k$1/;
			    s/(cons[0-9]+)((-m)?\s)/${1}l1$2/;' /etc/ttytype
	    fi
	  else
		  for i in 1 2 3 4 5 6 7 8 9 10 11 12
		  do echo "linux+k   tty$i" >>/etc/ttytype
		  done
	  fi
  #/etc/ttys /etc/ttytype linux+k cons??l1-m
  fi

  if test -e /etc/login.conf; then
	  if ! grep -q ':lang=lt_LT\.ISO.8859-4:' /etc/login.conf ; then
		  backup /etc/login.conf
		  perl -i.orig -pe 's{^\s*standard:\\$}{$&\n	:lang=lt_LT.ISO_8859-4:\\\n	:charset=ISO-8859-4:\\\n	:setenv=XENVIRONMENT=/usr/local/share/x-lt/Xresources:\\}' /etc/login.conf
		  cap_mkdb /etc/login.conf
	  fi
  # standard:\
  #         :lang=lt_LT.ISO_8859-4:\
  #         :charset=ISO-8859-4:\
  #         :setenv=XMCD_LIBDIR=/usr/X11R6/lib/X11/xmcd,MUSIC_CD=/dev/rwcd0c:\

  elif ! test -e /etc/login.defs; then
	  bold Can\'t 'find /etc/login.defs nor /etc/login.conf.\nAdd to your /etc/profile and other login scripts:\n	LANG=lt_LT.ISO_8859-4\n	MM_CHARSET=ISO-8859-4\n test -n "$XENVIRONMENT" || XENVIRONMENT="/usr/local/share/x-lt/Xresources"\n
	  export LANG MM_CHARSET XENVIRONMENT\n'
  fi

  if test -e /etc/ttys; then \
     if ! grep -q 'cons[0-9]+l1' /etc/ttys; then
	  backup /etc/ttys
	  perl -i.orig -pe 's/\b(cons[0-9]+)((-m)?\s)/${1}l1$2/;' /etc/ttys
     fi
  else
	  bold Can\'t 'find /etc/ttytype nor /etc/ttys.\nAdd to your /etc/profile and other login scripts:\n	stty erase ^H\n	TERM=linux+k for Linux or TERM=cons25l1 for FreeBSD\n'
  fi

  for f in /etc/rc.d/boot.setup /etc/rc.d/single /etc/rc.d/svgatext; do
   if test -e $f && grep -q '^[^#]*[^x] /usr/bin/loadunimap' $f; then
	  backup $f
	  perl -i.orig  -pe 's{^[^#]*[^x]\s/usr/bin/loadunimap\b}{: #$&}' $f
   fi
  done

  if test -e /etc/rc.conf; then
    if grep -q '^[	# ]*keymap=' /etc/rc.conf; then
	 backup /etc/rc.conf
	 perl -i.orig  -pe '
		  s/^[	# ]*keymap=[^#]*(.*)$/keymap="lt_LT.ISO_8859-4"	$1/;
		  s/^[	# ]*scrnmap=[^#]*(.*)$/scrnmap="vga2iso"	$1/;
		  s/^[	# ]*font8x16=[^#]*(.*)$/font8x16="lat4u-8x16"	$1/;
		  s/^[	# ]*font8x14=[^#]*(.*)$/font8x14="lat4u-8x14"	$1/;
		  s/^[	# ]*font8x8=[^#]*(.*)$/font8x8="lat4u-8x8"	$1/;
	  ' /etc/rc.conf

  # keymap="lt_LT.ISO_8859-4"       # keymap in /usr/share/syscons/keymaps/* (or NO).  
  # scrnmap="vga2iso"               # screen map in /usr/share/syscons/scrnmaps/* (or NO).
  # font8x16="lat4u-8x16"           # font 8x16 from /usr/share/syscons/fonts/* (or NO).
  # or   font8x16="lat4u-wide-8x16"
  # font8x14="lat4u-8x14"           # font 8x14 from /usr/share/syscons/fonts/* (or NO).
  # font8x8="lat4u-8x8"             # font 8x8 from /usr/share/syscons/fonts/* (or NO).
  # allscreens_flags="-m on"        # Set this vidcontrol mode for all virtual screens
    fi

  elif test -e /etc/rc.config; then
    if grep -q '^ *KEYTABLE' /etc/rc.config; then
	 backup /etc/rc.config
	 perl -i.orig  -pe '
		  s/^ *KEYTABLE="[^"]*"/KEYTABLE="lt.l4.map" #$&/;
		  s/^ *FONT="[^"]*"/FONT="lat4u-16+.psf -m vga2iso" #$&/;
		  s/^ *CONSOLE_FONT="[^"]*"/CONSOLE_FONT="lat4u-16+.psf" #$&/;
		  s/^ *CONSOLE_SCREENMAP="[^"]*"/CONSOLE_SCREENMAP="vga2iso" #$&/;
		  s/^ *CONSOLE_UNICODEMAP="[^"]*"/CONSOLE_UNICODEMAP="" #$&/;
		  s/^ *CONSOLE_MAGIC="[^"]*"/CONSOLE_MAGIC="\\045@\\033(K" #$&/;
	  ' /etc/rc.config
    fi
  else
	  bold Can\'t 'find /etc/rc.config nor /etc/rc.conf.\nAdd to your boot scripts:\n	setfont lat4u-16.psf -m vga2iso; loadkeys lt.l4.map\n'

  fi

  if { test -e /etc/profile.local && { ! grep -q '/share/x-lt/profile' /etc/profile.local; }; } \
  || { test ! -e /etc/profile.local && grep -q '\. /etc/profile.local' /etc/profile; } then
	  test -e /etc/profile.local || touch /etc/profile.local
	  backup /etc/profile.local
	  cp -p /etc/profile.local /etc/profile.local.orig
	  printf '\ntest -e /usr/local/share/x-lt/profile && . /usr/local/share/x-lt/profile\n' >> /etc/profile.local
  else
	  test -e /etc/profile || touch /etc/profile
	  if ! { grep -q '\. /etc/profile.local' /etc/profile \
	  || grep -q '/share/x-lt/profile' /etc/profile; }; then
		  backup /etc/profile
		  cp -p /etc/profile /etc/profile.orig
		  printf '\ntest -e /usr/local/share/x-lt/profile && . /usr/local/share/x-lt/profile\n' >> /etc/profile
	  fi
  fi
  bold '/etc/profile{.local} for bash is changed. Please edit /etc/csh.login for tcsh on your own.\n'

  
  if [ "$Xbasedir" != NO_X11 ]; then

    if test -e $Xbasedir/lib/X11/xdm/Xsession; then
      if ! { grep -q '\.[ 	]/usr/local/share/x-lt/profile' $Xbasedir/lib/X11/xdm/Xsession \
	    || grep -q '\.[ 	]/etc/profile' $Xbasedir/lib/X11/xdm/Xsession; }; then
	   backup $Xbasedir/lib/X11/xdm/Xsession
	   perl -i.orig  -e 'undef $/; $_=<>; s{^(?!#)}{\ntest -e /usr/local/share/x-lt/profile && . /usr/local/share/x-lt/profile\n}m; print;' $Xbasedir/lib/X11/xdm/Xsession
      fi
    else
      bold Can\'t find xdm/Xsession - find and edit it by 'hand!\n '
    fi

    #if test -e $Xbasedir/lib/X11/Xresources; then
    #	if ! grep -q '^[	 ]*# *include *"/usr/local/share/x-lt/Xresources"' $Xbasedir/lib/X11/Xresources; then
    #	       backup $Xbasedir/lib/X11/Xresources
    #	       perl -i.orig  -e 'undef $/; $_=<>; s{^(?!!)}{\n#include "/usr/local/share/x-lt/Xresources"\n}m; print;' $Xbasedir/lib/X11/Xresources
    #	fi
    #else
    #	if test -e $Xbasedir/lib/X11/xinit/xinitrc; then
    #	  if ! grep -q 'xrdb.*/usr/local/share/x-lt/Xresources' $Xbasedir/lib/X11/xinit/xinitrc; then
    #	       backup $Xbasedir/lib/X11/xinit/xinitrc
    #	       perl -i.orig  -e 'undef $/; $_=<>; s{^(?!#)}{\ntest -e /usr/local/share/x-lt/Xresources && xrdb -merge /usr/local/share/x-lt/Xresources\n}m; print;' $Xbasedir/lib/X11/xinit/xinitrc
    #	  fi
    #	else
    #	  bold Can\'t find xinit/xinitrc - find and edit it by 'hand! \n'
    #	fi
    #
    #	if test -e $Xbasedir/lib/X11/xdm/Xresources; then
    #	  if ! grep -q '^[	 ]*# *include *"/usr/local/share/x-lt/Xresources"' $Xbasedir/lib/X11/xdm/Xresources; then
    #		 backup $Xbasedir/lib/X11/xdm/Xresources
    #		 perl -i.orig  -e 'undef $/; $_=<>; s{^(?!!)}{\n#include "/usr/local/share/x-lt/Xresources"\n}m; print;' $Xbasedir/lib/X11/xdm/Xresources
    #	  fi
    #	else
    #	  bold Can\'t find xdm/Xresources - find and edit it by 'hand! \n'
    #	fi
    #
    #fi

    changed=0
    for f in /etc/XF86Config /etc/X11/XF86Config $Xbasedir/lib/X11/XF86Config; do
     if test -e $f; then
	     if ! { grep -q '/usr/local/lib/X11/fonts' $f \
	     || grep -q 'inet/127\.0\.0\.1:' $f; }; then
		    backup $f
		    perl -i.orig  -e 'undef $/; $_=<>; s{^[ \t]*FontPath.*$}{   FontPath   "/usr/local/lib/X11/fonts"\n$&}mi; print;' $f
	    #   FontPath   "/usr/local/lib/X11/fonts"
	     fi
	     changed=1
	     break
     fi
    done
    [ _$changed = _1 ] || bold Can\'t 'find XF86Config - add  FontPath   "/usr/local/lib/X11/fonts" there yourself ! \n'

    f=$Xbasedir/lib/X11/fs/config
    if test -e $f; then
	    if ! grep -q '/usr/local/lib/X11/fonts' $f; then
		   backup $f
		   perl -i.orig  -e 'undef $/; $_=<>;
		    s{^(\s*catalogue\s*=\s*.+?),(.*)$}{#$&\n$1,/usr/local/lib/X11/fonts/:unscaled,/usr/local/lib/X11/fonts/TTF/,$2}mi; print; print "\n#catalogue = /usr/local/lib/X11/fonts/:unscaled,/usr/local/lib/X11/fonts/Type1/,/usr/local/lib/X11/fonts/TTF/,/usr/X11R6/lib/X11/fonts/misc/:unscaled,/usr/X11R6/lib/X11/fonts/Speedo/,/usr/X11R6/lib/X11/fonts/Type1/,/usr/X11R6/lib/X11/fonts/Xg/,/usr/X11R6/lib/X11/fonts/100dpi/:unscaled,/usr/X11R6/lib/X11/fonts/75dpi/:unscaled,/usr/X11R6/lib/X11/fonts/latin2/100dpi/:unscaled,/usr/X11R6/lib/X11/fonts/latin2/75dpi/:unscaled,/usr/X11R6/lib/X11/fonts/cyrillic/,/usr/local/lib/X11/fonts/ttf2pt1_br/,/usr/local/lib/X11/fonts/ttf2pt1/:/usr/lib/X11/fonts/misc \n";' $f
	    fi
    fi

  fi # NO_X11

fi # changes to config files

if [ "$Xbasedir" != NO_X11 ]; then
while :; do
   bold 'If you want to install TrueType fonts and generated from TTF PostScript \nscalable fonts, put all *.ttf files (or make symlinks) in \n/usr/local/lib/X11/fonts/TTF/ and press Y. \nDirectory itself must have write access. \nSome TTF fonts you can download from http://www.kada.lt/litwin/ \nPlease use TTF with Unicode tables (i.e. not from Windows 3.1).\n[Y/n]'

   read a e
   if [ "${a#[Nn]}" = "$a" ]; then
	ls	/usr/local/lib/X11/fonts/TTF/*.[Tt][Tt][f] >/dev/null || continue
	touch	/usr/local/lib/X11/fonts/TTF/tmp.tmp || continue
	rm	/usr/local/lib/X11/fonts/TTF/tmp.tmp

	if ! type ttmkfdir; then
	  if [ "${uname##*[Ll]inux*}" = "" ]; then
		  libc_v="`ldd /bin/uname`" 2>&1
		  cd "$BASE_DIR"/../ttmkfontdir/
		  if [ "${libc_v#*libc.so.5}" != "$libc_v" ]; then
			  install -c -m 775 ttmkfdir.linuxbin.libc5 /usr/X11R6/bin/ttmkfdir
		  elif [ "${libc_v#*libc.so.6}" != "$libc_v" ]; then
			  install -c -m 775 ttmkfdir.linuxbin.glibc2 /usr/X11R6/bin/ttmkfdir
		  else
			  libc_v=
		  fi
	  fi
	  test -z "$libc_v" && while :; do
		  bold 'Go to ./ttmkfontdir, make it and install somewhere on the PATH. \nIf your are on *BSD go to the ports/x11-fonts/ttmkfdir and make install \nPress <Return> to continue after that..'
		  read a
		  type ttmkfdir && break
	  done
	fi
	cd /usr/local/lib/X11/fonts/TTF
	"$BASE_DIR/make_TTF_dir" -lt
	bold 'Done with TTF. Now change XF86Config and/or \n/usr/X11R6/lib/fs/config. See README for details.\n\nDo you want to convert TTF to PostScript fonts? \nThere are some programs requiring direct access to PostScript fonts.\n[Y/n]'
	read a e
	if [ "${a#[Nn]}" = "$a" ]; then
		cd "$BASE_DIR"/../ttf2pt1/
		make
		cd scripts
		DSTDIR=/usr/local/lib/X11/fonts/ttf2pt1_br
		FOUNDRY=ttf2pt1_br
		FORCEISO="`pwd`/forceiso"
		export DSTDIR FOUNDRY FORCEISO
		./convert.iso8859-4
		DSTDIR=/usr/local/lib/X11/fonts/ttf2pt1
		FOUNDRY=ttf2pt1
		FORCEISO=cat
		./convert.iso8859-4
	fi

   fi
   break
done
fi # NO_X11

bold 'If you have Netscape browser 4.5* I can add Baltic encodings to it \ninstead of Greek. Do it? [Y/n]'
read a e
if [ "${a#[Nn]}" = "$a" ]; then
	perl "$BASE_DIR/NC_baltic"
fi

test -x /sbin/SuSEconfig && /sbin/SuSEconfig --quick
if [ "${uname##*[Ll]inux*}" = "" -a -z "$DISPLAY" ]; then
	kbd_mode -a; printf '\033\045@\033(K'
	loadkeys lt.l4.map
	setfont lat4u-16+.psf -m vga2iso
fi
[ "${uname##*FreeBSD*}" = "" ] && bold 'Add to kernel config file:\n	options         "SC_MOUSE_CHAR=0x03"		and recompile.\n'
bold 'Now run XF86Setup, select Keyboard->Language->Lithuanian, \n  select mode switching keys, save XF86Config; \nread README and reboot.\n'

