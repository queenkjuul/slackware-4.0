/*	
 *   cdmanip - CDROM ioctl manipulation for diacrd
 * 
 *   UGLY, but seems to work...
 *
 *   Copyright (C) 1995,1996 C�dric Adjih
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mount.h>
#include <linux/kd.h>
#include <linux/cdrom.h>

#include "cdmanip.h"

/* #define CDROM_DEVICE  "/dev/cdrom" --unused should be a link to your CD device */

#define BUZZER_DEVICE "/dev/console"  /* device to ioctl for sound */
#define NB_TRIAL      3

#ifdef DBG_CDMOUNT
#  define DERROR(x) perror(x)           /* display error */
#else
#  define DERROR(x) /* FIXME : should use syslog here ... */
#endif

int buzz(unsigned int count, unsigned int millisec)
{
  int result;
  int fd=open("/dev/console",O_RDONLY);

  if (fd<0) {
    DERROR("can't open /dev/console");
    return -1; /* bad luck */
  }
  result=ioctl(fd, KDMKTONE, (millisec<<16)|count);
  close(fd);
  return result;
}

void buzz_bad()
{
  buzz(500,100);
  usleep(150000);
  buzz(500,100);
}

void buzz_ok()
{ buzz(500,100); }

/* Mount a cdrom (read-only)
   FIXME: won't update /etc/mtab
 */
int cd_mount(const char* name, const char* where)
{
  int i;
  for(i=0;i<NB_TRIAL;i++) {
    if (mount(name, where, "iso9660", 1, NULL)>=0) 
      return 0;
    else DERROR("mount cdrom-device");
  }
  return -1;
}

/* Users  
 */
void log_cd_users(const char* name)
{ 
  const char command[]="fuser -v -m %s | xargs logger";
  char* real_command;

  real_command=(char*)malloc(strlen(command)+strlen(name));
  sprintf(real_command,command,name);
  system(real_command);
  free(real_command);
}

/* Users  
 */
void kill_cd_users(const char* name)
{ 
  const char command[]="fuser -k -m %s ";
  char* real_command;

  real_command=(char*)malloc(strlen(command)+strlen(name));
  sprintf(real_command,command,name);
  system(real_command);
  free(real_command);
}

/* Umount a cdrom 
   FIXME: won't update /etc/mtab
 */
int cd_umount(const char* name)
{ 
  if (umount(name)<0) {
    DERROR("open cdrom-device");
    return -1;
  } else {
    int result;
    int fd=open(name,O_RDONLY);
    if (fd<0) {
      DERROR("open cdrom-device");
      return -1;
    }
    result=ioctl(fd,CDROMEJECT);
    close(fd);
    return result;
  }
}

#if 0
int brutal_cd_umount(const char* name)
{ 
  if (cd_umount(name)<0) {
    kill_cd_users(name);
    usleep(100000); /* 1/10th */
    return cd_umount(name)<0);
  }
  return 1;
}
#endif

