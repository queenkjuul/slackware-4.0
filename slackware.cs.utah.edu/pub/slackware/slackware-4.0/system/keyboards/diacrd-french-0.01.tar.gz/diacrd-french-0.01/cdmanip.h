#ifndef  CDMOUNT_H
#define CDMOUNT_H

int buzz(unsigned int count, unsigned int millisec);
void buzz_bad(void);
void buzz_ok(void);

int cd_mount(const char* name, const char* where);
int cd_umount(const char* name);
void log_cd_users(const char* name);
void kill_cd_users(const char* name);

#endif
