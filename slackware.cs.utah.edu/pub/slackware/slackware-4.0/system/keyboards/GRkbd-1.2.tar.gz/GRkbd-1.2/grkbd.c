/* GRkbd - Greek keyboard for X-windows in Linux - Version: 1.2
 * Copyright (C) 1998 Yannis Tsakiris
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * You can contact the author via e-mail at: yannis@palamida.math.uch.gr
 * or by post at:   Yannis Tsakiris
 *                  5, Ant. Kastrinaki st.
 *                  713 05 Heralion, Crete
 *                  Greece
 */

#include <stdio.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>

#define FORK

#define MESSAGE	"GRkbd 1.2  Linux  June 1998  Yannis Tsakiris\n"

#define WIDTH	47
#define HEIGHT	27

#define IS_DOWN(MAP,CODE)	(int)((MAP[CODE/8]>>(CODE%8))&1)

char *DISPLAY=NULL;
long int geo_x=0,geo_y=0;

Display *disp;
KeySym *ORIGINAL,*KEYMAP;
int MIN_CODE,MAX_CODE,KEYCODES,SYMS_PER_CODE,WIN;
int cur_lang=0,cur_state=0,flag=1;

Window root,win;
Visual *visual;
int depth,black,white,screen;
XImage *image;
char *img;
GC gc;
XEvent event;
XSizeHints wmhints;
Colormap colormap;
unsigned long RootWidth,RootHeight;

extern int deadkeys[5][7];

void parse(int argc,char **argv);

main(int argc,char **argv)
{
	unsigned char CUR_MAP[32],PREV_MAP[32];
	int i,code,is_dead,keypress,bpl;

	fprintf(stderr,MESSAGE);

	parse(argc,argv);

	if ((disp=XOpenDisplay(DISPLAY)) == NULL)
	{
		fprintf(stderr,"cannot open display\n");
		exit(0);
	}

	if (WIN)
	{
		root=DefaultRootWindow(disp);
		screen=DefaultScreen(disp);
		visual=DefaultVisual(disp,screen);
		depth=DefaultDepth(disp,screen);
		black=BlackPixel(disp,screen);
		white=WhitePixel(disp,screen);
		colormap=DefaultColormap(disp,screen);
		RootWidth=DisplayWidth(disp,screen);
		RootHeight=DisplayHeight(disp,screen);

		if (geo_x < 0) geo_x+=(RootWidth-WIDTH);
		if (geo_y < 0) geo_y+=(RootHeight-HEIGHT);
	}

	XDisplayKeycodes(disp,&MIN_CODE,&MAX_CODE);
	XSync(disp,False);
	KEYCODES=MAX_CODE-MIN_CODE+1;
	ORIGINAL=XGetKeyboardMapping(disp,MIN_CODE,KEYCODES,&SYMS_PER_CODE);
	XSync(disp,False);
	if ((KEYMAP=(KeySym *)malloc(KEYCODES*SYMS_PER_CODE*sizeof(KeySym))) == NULL)
	{
		perror("malloc: KeySym");
		exit(0);
	}

#ifdef FORK
	switch (fork())
	{
	case 0:
		break;
	case -1:
		perror("fork");
	default:
		exit(0);
	}
#endif

	if (WIN)
	{
		win=XCreateSimpleWindow(disp,root,geo_x,geo_y,WIDTH,HEIGHT,0,black,black);
		XStoreName(disp,win,"grkbd");

		wmhints.flags=PSize|PMinSize|PMaxSize|USPosition;
		wmhints.x=10;
		wmhints.y=10;
		wmhints.width=wmhints.min_width=wmhints.max_width=WIDTH;
		wmhints.height=wmhints.min_height=wmhints.max_height=HEIGHT;
		XSetNormalHints(disp,win,&wmhints);

		XMapWindow(disp,win);

		gc=XCreateGC(disp,win,0,NULL);

		img=(char *)malloc(WIDTH*HEIGHT*4);
		image=XCreateImage(disp,visual,depth,ZPixmap,0,(char *)img,WIDTH,HEIGHT,32,0);

		XSelectInput(disp,win,ExposureMask|ButtonPressMask);

		find_colors();
		set_flag(0);
	}

	XQueryKeymap(disp,PREV_MAP);
	XSync(disp,False);

	while (1)
	{
	   if (XPending(disp))
	   {
		XNextEvent(disp,&event);
		switch (event.type)
		{
		case Expose:
			XPutImage(disp,win,gc,image,
				event.xexpose.x,event.xexpose.y,
				event.xexpose.x,event.xexpose.y,
				event.xexpose.width,event.xexpose.height);
			XSync(disp,False);
			continue;

		case ButtonPress:
			cur_lang=1-cur_lang;
			cur_state=0;
			flag=1;
			if (cur_lang == 1) apply_map(cur_state); else apply_map(-1);
			set_flag(cur_lang);
			continue;
		}
	   }

	   usleep(10000);
	   XQueryKeymap(disp,CUR_MAP);
	   XSync(disp,False);
	   if (memcmp(CUR_MAP,PREV_MAP,32) == 0) continue;

	   is_dead=0;
	   keypress=0;
	   for (code=MIN_CODE; code<=MAX_CODE; code++)
	   if (IS_DOWN(CUR_MAP,code)-IS_DOWN(PREV_MAP,code) == 1)
	   {
	   if ((code == 50 || code == 62) && !flag) continue;
	   keypress=1;

	   for (i=0; i<7; i++)
	   if (((cur_lang == deadkeys[i][0]) || (deadkeys[i][0] == -1)) &&
	       (code == deadkeys[i][1]) &&
	       ((deadkeys[i][2] && IS_DOWN(CUR_MAP,deadkeys[i][2])) || (!deadkeys[i][2])))
	     {
		is_dead=1;
		if (cur_lang != deadkeys[i][3])
		{
			if (WIN) set_flag(deadkeys[i][3]);
		}
		cur_lang=deadkeys[i][3];
		cur_state&=deadkeys[i][4];
		cur_state^=deadkeys[i][5];
		flag=deadkeys[i][6];

		if (cur_lang == 1) apply_map(cur_state); else apply_map(-1);

		i=7;
	     }
	   }

	   if (keypress && !is_dead && !flag)
	   {
		cur_state=0;
		flag=1;

		if (cur_lang == 1) apply_map(cur_state); else apply_map(-1);
	   }

	   memcpy(PREV_MAP,CUR_MAP,32);
	}
}

void parse(int argc,char **argv)
{
	int i;

	WIN=1;

	for (i=1; i<argc; i++)
	{
		if (strcmp(argv[i],"-nowin") == 0)
		{
			WIN=0;
		}
		  else
		if (strcmp(argv[i],"-display") == 0)
		{
			if (i+1 >= argc)
			{
				fprintf(stderr,"%s: syntax error after -display\n",argv[0]);
				exit(0);
			}
			i++;
			DISPLAY=argv[i];
		}
		  else
		if (strcmp(argv[i],"-geometry") == 0)
		{
			if (i+1 >= argc)
			{
				fprintf(stderr,"%s: syntax error after -geometry\n",argv[0]);
				exit(0);
			}
			i++;
			if (sscanf(argv[i],"%d%d",&geo_x,&geo_y) < 2)
			{
				fprintf(stderr,"%s: invalid argument after -geometry\n",argv[0]);
				exit(0);
			}
		}
		  else
		{
			fprintf(stderr,"%s: invalid argument %s\n",argv[0],argv[i]);
			exit(0);
		}
	}
}
