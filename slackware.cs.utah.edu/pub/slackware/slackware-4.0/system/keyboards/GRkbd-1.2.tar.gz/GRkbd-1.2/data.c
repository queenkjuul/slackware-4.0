/* GRkbd - Greek keyboard for X-windows in Linux - Version: 1.2
 * Copyright (C) 1998 Yannis Tsakiris
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * You can contact the author via e-mail at: yannis@palamida.math.uch.gr
 * or by post at:   Yannis Tsakiris
 *                  5, Ant. Kastrinaki st.
 *                  713 05 Heralion, Crete
 *                  Greece
 */

#include <X11/Xlib.h>

KeySym GREEK[4][28][3] =
{
38,225,193,
56,226,194,
42,227,195,
40,228,196,
26,229,197,
52,230,198,
43,231,199,
30,232,200,
31,233,201,
45,234,202,
46,235,203,
58,236,204,
57,237,205,
44,238,206,
32,239,207,
33,240,208,
27,241,209,
25,242,211,
39,243,211,
28,244,212,
29,245,213,
41,246,214,
53,247,215,
54,248,216,
55,249,217,
24,59,58,
47,0,0,
67,0,0,
38,220,182,
56,226,194,
42,227,195,
40,228,196,
26,221,184,
52,230,198,
43,222,185,
30,232,200,
31,223,186,
45,234,202,
46,235,203,
58,236,204,
57,237,205,
44,238,206,
32,252,188,
33,240,208,
27,241,209,
25,242,211,
39,243,211,
28,244,212,
29,253,190,
41,246,214,
53,247,215,
54,248,216,
55,254,191,
24,59,58,
47,0,0,
67,0,0,
38,225,193,
56,226,194,
42,227,195,
40,228,196,
26,229,197,
52,230,198,
43,231,199,
30,232,200,
31,250,218,
45,234,202,
46,235,203,
58,236,204,
57,237,205,
44,238,206,
32,239,207,
33,240,208,
27,241,209,
25,242,211,
39,243,211,
28,244,212,
29,251,219,
41,246,214,
53,247,215,
54,248,216,
55,249,217,
24,59,58,
47,0,0,
67,0,0,
38,225,193,
56,226,194,
42,227,195,
40,228,196,
26,229,197,
52,230,198,
43,231,199,
30,232,200,
31,192,218,
45,234,202,
46,235,203,
58,236,204,
57,237,205,
44,238,206,
32,239,207,
33,240,208,
27,241,209,
25,242,211,
39,243,211,
28,244,212,
29,224,219,
41,246,214,
53,247,215,
54,248,216,
55,249,217,
24,59,58,
47,0,0,
67,0,0
};

int deadkeys[7][7] =
{
0,50,64,1,0,0,1,
1,50,64,0,0,0,1,
0,62,113,1,0,0,1,
1,62,113,0,0,0,1,
1,47,50,1,1,2,0,
1,47,62,1,1,2,0,
1,47,0,1,2,1,0
};
