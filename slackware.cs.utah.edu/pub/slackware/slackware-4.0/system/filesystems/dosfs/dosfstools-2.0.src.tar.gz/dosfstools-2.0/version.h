#ifndef _version_h
#define _version_h

#define	VERSION			"2.0"
#define VERSION_DATE	"30 Apr 1999"

#endif  /* _version_h */

