#include "config.h"

char* lwared_version="0.94";
