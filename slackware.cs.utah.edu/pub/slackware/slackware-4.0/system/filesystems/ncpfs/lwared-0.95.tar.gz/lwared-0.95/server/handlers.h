
/*
    LinuxWare daemon - Netware like server for Linux

    Copyright (C) 1994, 1995  Ales Dryak <e-mail: A.Dryak@sh.cvut.cz>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#ifndef __HANDLERS_H__

#define __HANDLERS_H__

#include "connect.h"

void ncp_handle_r23(int subfunc,int size,char* data,connection* c);
void ncp_handle_r22(int subfunc,int size,char* data,connection* c);
void ncp_handle_r21(int subfunc,int size,char* data,connection* c);
void ncp_handle_r87(int subfunc,int size,char* data,connection* c);
void handle_ncp_request_main(struct ncp_request* pkt,int size,connection* c);

#endif /* __HANDLERS_H__ */
