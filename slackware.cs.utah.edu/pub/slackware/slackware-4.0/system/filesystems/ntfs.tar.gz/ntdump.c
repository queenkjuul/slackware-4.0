/*
 *  ntdump.c
 *
 *  Copyright (C) 1995 Martin von L�wis
 */

#include <stdio.h>
#include <getopt.h>
#include <unistd.h>
#include "ntfs.h"
#include "config.h"
/* glibc string.h does not define a memcpy prototype */
void* memcpy(void*,const void*,size_t);

char *short_opts="rdf:o:c:Mi:I";
struct option options[]={
	{"raw",0,0,'r'},
	{"filesystem",1,0,'f'},
	{"offset",1,0,'o'},
	{"cluster",1,0,'c'},
	{"mft",0,0,'M'},
	{"inode",1,0,'i'},
	{"dir",0,0,'d'},
	{"info",0,0,'I'}
};

void usage()
{
	fprintf(stderr,"ntdump: prints low-level structures of an NTFS\n"
		"  --filesystem, -f device  Use device\n"
		"  --raw, -r                Access the raw device\n"
		"  --offset, -o n           Start at offset o\n"
		"  --cluster, -c n          Start at cluster n\n"
		"  --mft, -M                Display as master file table record\n"
		"  --inode, -i n            Display inode n\n"
		"  --dir, -d                Display as directory\n"
		"  --info, -I               Display file system information\n"
	);
}

int main(int argc,char *argv[])
{
	int c;
	int raw=0,as_mft=0,as_dir=0,inode=0,use_ino=0,get_info=0;
	char *device=0;
	int offset=0;
	opterr=1;
	while((c=getopt_long(argc,argv,short_opts,options,NULL))>0)
	switch(c)
	{
		case 'r': raw=1;break;
		case 'f': device=optarg;break;
		case 'o': offset=strtol(optarg,NULL,0);break;
		case 'c': offset=strtol(optarg,NULL,0)*NTFS_BLOCKSIZE;break;
		case 'M': as_mft=1;break;
		case 'i': inode=strtol(optarg,NULL,0);use_ino=1;break;
		case 'd': as_dir=1;break;
		case 'I': get_info=1;break;
	}
	if(!ntfs_open_volume(device,0) && !raw)return 1;
	if(use_ino){
		ntfs_inode ino;
		ino.i_number=inode;
		if(ntfs_get_inode(&ino)==-1)return;
		if(as_mft){
			list_attr_mem(ino.attr);
			return 0;
		}
		if(as_dir){
			dumpdir(ino.attr,ino.i_number);
			return 0;
		}
		while(1)
		{
			char buf[NTFS_CLUSTERSIZE];
			int r=ntfs_read_attr(the_vol,ino.attr,ino.i_number,AT_DATA,NULL,
				offset,buf,NTFS_CLUSTERSIZE,memcpy);
			if(r==-1)return 0;
			dump_mem(buf,offset,NTFS_CLUSTERSIZE);
			offset+=r;
			if(r<NTFS_CLUSTERSIZE)return 0;
		}
		return 0;
	}
	if(raw)
	{
		dump(offset,offset,-1);
	}else if(as_mft)
	{
		list_attributes(offset);
	}else if(get_info)
	{
		ntfs_inode ino;
		printf("Total clusters: %d\n",ntfs_get_volumesize(the_vol));
		ino.i_number=FILE_BITMAP;
		ntfs_get_inode(&ino);
		printf("Free clusters:  %d\n",
			ntfs_get_free_cluster_count(the_vol,ino.attr));
	}else{
		usage();
	}
	return 0;
}

