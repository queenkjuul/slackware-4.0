
long get_fsize (char *filename); 
void remove_file (char *filename);
void insecure_overwrite (char *filename,long size);
