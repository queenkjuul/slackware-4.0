/* Secure rm (srm)
 * by: Todd Burgess  
 * tburgess@eddie.cis.uoguelph.ca
 * 
 * This program is designed to "securely" remove files from your 
 * computer
 * Use this program at your own risk
 *
 * version 0.0.1
*/

#include <stdio.h>

int main (int argc, char *argv[]) 
{
	remove_file (argv[1]);
	return(0);
} 
