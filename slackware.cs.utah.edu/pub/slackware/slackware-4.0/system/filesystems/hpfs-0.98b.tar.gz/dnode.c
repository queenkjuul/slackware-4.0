/*
 *  linux/fs/hpfs/alloc.c
 *
 *  Mikulas Patocka (mikulas@artax.karlin.mff.cuni.cz), 1998
 *
 *  handling directory dnode tree - adding, deleteing & searching for dirents
 */

#include "hpfs_fn.h"

loff_t get_pos(struct dnode *d, struct hpfs_dirent *fde)
{
	struct hpfs_dirent *de;
	struct hpfs_dirent *de_end = dnode_end_de(d);
	int i = 1;
	for (de = dnode_first_de(d); de < de_end; de = de_next_de(de)) {
		if (de == fde) return ((loff_t) d->self << 4) | (loff_t)i;
		i++;
	}
	printk("HPFS: get_pos: not_found\n");
	return ((loff_t)d->self << 4) | (loff_t)1;
}

void add_pos(struct inode *inode, loff_t *pos)
{
	int i = 0;
	loff_t **ppos;
	if (inode->i_hpfs_rddir_off)
		for (; inode->i_hpfs_rddir_off[i]; i++)
			if (inode->i_hpfs_rddir_off[i] == pos) return;
	if (!(i&0x0f)) {
		if (!(ppos = kmalloc((i+0x11) * sizeof(loff_t*), GFP_KERNEL))) {
			printk("HPFS: out of memory for position list\n");
			return;
		}
		if (inode->i_hpfs_rddir_off) {
			memcpy(ppos, inode->i_hpfs_rddir_off, i * sizeof(loff_t));
			kfree(inode->i_hpfs_rddir_off);
		}
		inode->i_hpfs_rddir_off = ppos;
	}
	inode->i_hpfs_rddir_off[i] = pos;
	inode->i_hpfs_rddir_off[i + 1] = NULL;
}

void del_pos(struct inode *inode, loff_t *pos)
{
	loff_t **i, **j;
	if (!inode->i_hpfs_rddir_off) goto not_f;
	for (i = inode->i_hpfs_rddir_off; *i; i++) if (*i == pos) goto fnd;
	goto not_f;
	fnd:
	for (j = i + 1; *j; j++) ;
	*i = *(j - 1);
	*(j - 1) = NULL;
	if (j - 1 == inode->i_hpfs_rddir_off) {
		kfree(inode->i_hpfs_rddir_off);
		inode->i_hpfs_rddir_off = NULL;
	}
	return;
	not_f:
	/*printk("HPFS: warning: position pointer %p->%08x not found\n", pos, (int)*pos);*/
	return;
}

void for_all_poss(struct inode *inode, void (*f)(loff_t *, loff_t, loff_t),
		  loff_t p1, loff_t p2)
{
	loff_t **i;
	if (!inode->i_hpfs_rddir_off) return;
	for (i = inode->i_hpfs_rddir_off; *i; i++) (*f)(*i, p1, p2);
	return;
}

void pos_subst(loff_t *p, loff_t f, loff_t t)
{
	if (*p == f) *p = t;
}

void pos_substd(loff_t *p, loff_t f, loff_t t)
{
	if ((*p & ~0x3f) == (f & ~0x3f)) *p = (t & ~0x3f) | (*p & 0x3f);
}

void pos_ins(loff_t *p, loff_t d, loff_t c)
{
	if ((*p & ~0x3f) == (d & ~0x3f) && (*p & 0x3f) >= (d & 0x3f)) {
		int n = (*p & 0x3f) + c;
		if (n > 0x3f) printk("HPFS: pos_ins: %08x + %d\n", (int)*p, (int)c >> 8);
		else *p = (*p & ~0x3f) | n;
	}
}

void pos_del(loff_t *p, loff_t d, loff_t c)
{
	if ((*p & ~0x3f) == (d & ~0x3f) && (*p & 0x3f) >= (d & 0x3f)) {
		int n = (*p & 0x3f) - c;
		if (n < 1) printk("HPFS: pos_ins: %08x - %d\n", (int)*p, (int)c >> 8);
		else *p = (*p & ~0x3f) | n;
	}
}

struct hpfs_dirent *dnode_pre_last_de(struct dnode *d)
{
	struct hpfs_dirent *de, *de_end, *dee = NULL, *deee = NULL;
	de_end = dnode_end_de(d);
	for (de = dnode_first_de(d); de < de_end; de = de_next_de(de)) {
		deee = dee; dee = de;
	}	
	return deee;
}

struct hpfs_dirent *dnode_last_de(struct dnode *d)
{
	struct hpfs_dirent *de, *de_end, *dee = NULL;
	de_end = dnode_end_de(d);
	for (de = dnode_first_de(d); de < de_end; de = de_next_de(de)) {
		dee = de;
	}	
	return dee;
}

void set_last_pointer(struct super_block *s, struct dnode *d,
		      dnode_secno ptr)
{
	struct hpfs_dirent *de;
	if (!(de = dnode_last_de(d))) {
		hpfs_error(s, "set_last_pointer: empty dnode %08x", d->self);
		return;
	}
	if (s->s_hpfs_chk) {
		if (de->down) {
			hpfs_error(s, "set_last_pointer: dnode %08x has already last pointer %08x", d->self, de_down_pointer(de));
			return;
		}
		if (de->length != 32) {
			hpfs_error(s, "set_last_pointer: bad last dirent in dnode %08x", d->self);
			return;
		}
	}
	if (ptr) {
		if ((d->first_free += 4) > 2048) {
			hpfs_error(s,"set_last_pointer: too long dnode %08x", d->self);
			d->first_free -= 4;
			return;
		}
		de->length = 36;
		de->down = 1;
		*(dnode_secno *)((char *)de + 32) = ptr;
	}
}

/* Add an entry to dnode and don't care if it grows over 2048 bytes */

struct hpfs_dirent *add_de(struct super_block *s, struct dnode *d,
			   unsigned char *name, unsigned namelen,
			   secno down_ptr)
{
	struct hpfs_dirent *de;
	struct hpfs_dirent *de_end = dnode_end_de(d);
	unsigned d_size = de_size(namelen, down_ptr);
	PRINTK(("add_de(%c, %d, %08x)\n",*name,namelen,down_ptr));
	for (de = dnode_first_de(d); de < de_end; de = de_next_de(de)) {
		int c = compare_names(s, name, namelen, de->name, de->namelen, de->last);
		if (!c) {
			hpfs_error(s, "name (%c,%d) already exists in dnode %08x", *name, namelen, d->self);
			return NULL;
		}
		if (c < 0) break;
	}
	memmove((char *)de + d_size, de, (char *)de_end - (char *)de);
	memset(de, 0, d_size);
	if (down_ptr) {
		*(int *)((char *)de + d_size - 4) = down_ptr;
		de->down = 1;
	}
	de->length = d_size;
	if (down_ptr) de->down = 1;
	de->not_8x3 = is_name_long(name, namelen);
	de->namelen = namelen;
	memcpy(de->name, name, namelen);
	d->first_free += d_size;
	return de;
}

/* Delete dirent and don't care about it's subtree */

void delete_de(struct super_block *s, struct dnode *d, struct hpfs_dirent *de)
{
	if (de->last) {
		hpfs_error(s, "attempt to delete last dirent in dnode %08x", d->self);
		return;
	}
	d->first_free -= de->length;
	memmove(de, de_next_de(de), d->first_free + (char *)d - (char *)de);
}

void fix_up_ptrs(struct super_block *s, struct dnode *d)
{
	struct hpfs_dirent *de;
	struct hpfs_dirent *de_end = dnode_end_de(d);
	dnode_secno dno = d->self;
	for (de = dnode_first_de(d); de < de_end; de = de_next_de(de))
		if (de->down) {
			struct quad_buffer_head qbh;
			struct dnode *dd;
			if ((dd = map_dnode(s, de_down_pointer(de), &qbh))) {
				if (dd->up != dno || dd->root_dnode) {
					dd->up = dno;
					dd->root_dnode = 0;
					mark_4buffers_dirty(&qbh);
				}
				brelse4(&qbh);
			}
		}
}

/* Add an entry to dnode and do dnode splitting if required */

int add_to_dnode(struct inode *i, dnode_secno dno,
		 unsigned char *name, unsigned namelen,
		 struct hpfs_dirent *new_de, dnode_secno down_ptr)
{
	struct quad_buffer_head qbh, qbh1, qbh2;
	struct dnode *d, *ad, *rd, *nd = NULL;
	dnode_secno adno, rdno;
	struct hpfs_dirent *de;
	struct hpfs_dirent nde;
	char nname[256];
	int h;
	int pos;
	struct buffer_head *bh;
	struct fnode *fnode;
	int c1, c2 = 0;
	go_up:
	PRINTK(("add_to_dnode(%08x, %c, %d)\n", dno, *name, namelen));
	if (namelen >= 256) {
		hpfs_error(i->i_sb, "add_to_dnode: namelen == %d", namelen);
		if (nd) kfree(nd);
		return 1;
	}
	if (!(d = map_dnode(i->i_sb, dno, &qbh))) {
		if (nd) kfree(nd);
		return 1;
	}
	go_up_a:
	if (i->i_sb->s_hpfs_chk)
		if (stop_cycles(i->i_sb, dno, &c1, &c2, "add_to_dnode")) {
			if (nd) kfree(nd);
			brelse4(&qbh);
			return 1;
		}
	if (d->first_free + de_size(namelen, down_ptr) <= 2048) {
		loff_t t;
		copy_de(de=add_de(i->i_sb, d, name, namelen, down_ptr), new_de);
		t = get_pos(d, de);
		for_all_poss(i, pos_ins, t, 1);
		for_all_poss(i, pos_subst, 4, t);
		for_all_poss(i, pos_subst, 5, t + 1);
		mark_4buffers_dirty(&qbh);
		brelse4(&qbh);
		if (nd) kfree(nd);
		return 0;
	}
	if (!nd) if (!(nd = kmalloc(0x924, GFP_KERNEL))) {
		/* 0x924 is a max size of dnode after adding a dirent with
		   max name length. We alloc this only once. There must
		   not be any error while splitting dnodes, otherwise the
		   whole directory, not only file we're adding, would
		   be lost. */
		printk("HPFS: out of memory for dnode splitting\n");
		brelse4(&qbh);
		return 1;
	}	
	memcpy(nd, d, d->first_free);
	copy_de(de = add_de(i->i_sb, nd, name, namelen, down_ptr), new_de);
	for_all_poss(i, pos_ins, get_pos(nd, de), 1);
	h = ((char *)dnode_last_de(nd) - (char *)nd) / 2 + 10;
	if (!(ad = alloc_dnode(i->i_sb, d->up, &adno, &qbh1, 0))) {
		hpfs_error(i->i_sb, "unable to alloc dnode - dnode tree will be corrupted");
		kfree(nd);
		brelse4(&qbh);
		return 1;
	}
	i->i_size += 2048;
	i->i_blocks += 4;
	pos = 1;
	for (de = dnode_first_de(nd); (char *)de_next_de(de) - (char *)nd < h; de = de_next_de(de)) {
		copy_de(add_de(i->i_sb, ad, de->name, de->namelen, de->down ? de_down_pointer(de) : 0), de);
		for_all_poss(i, pos_subst, ((loff_t)dno << 4) | pos, ((loff_t)adno << 4) | pos);
		pos++;
	}
	copy_de(new_de = &nde, de);
	memcpy(name = nname, de->name, namelen = de->namelen);
	for_all_poss(i, pos_subst, ((loff_t)dno << 4) | pos, 4);
	down_ptr = adno;
	set_last_pointer(i->i_sb, ad, de->down ? de_down_pointer(de) : 0);
	de = de_next_de(de);
	memmove((char *)nd + 20, de, nd->first_free + (char *)nd - (char *)de);
	nd->first_free -= (char *)de - (char *)nd - 20;
	memcpy(d, nd, nd->first_free);
	for_all_poss(i, pos_del, (loff_t)dno << 4, pos);
	fix_up_ptrs(i->i_sb, ad);
	if (!d->root_dnode) {
		dno = ad->up = d->up;
		mark_4buffers_dirty(&qbh);
		brelse4(&qbh);
		mark_4buffers_dirty(&qbh1);
		brelse4(&qbh1);
		goto go_up;
	}
	if (!(rd = alloc_dnode(i->i_sb, d->up, &rdno, &qbh2, 0))) {
		hpfs_error(i->i_sb, "unable to alloc dnode - dnode tree will be corrupted");
		brelse4(&qbh);
		brelse4(&qbh1);
		kfree(nd);
		return 1;
	}
	i->i_size += 2048;
	i->i_blocks += 4;
	rd->root_dnode = 1;
	rd->up = d->up;
	if (!(fnode = map_fnode(i->i_sb, d->up, &bh))) {
		free_dnode(i->i_sb, rdno);
		brelse4(&qbh);
		brelse4(&qbh1);
		brelse4(&qbh2);
		kfree(nd);
		return 1;
	}
	fnode->u.external[0].disk_secno = rdno;
	mark_buffer_dirty(bh, 1);
	brelse(bh);
	d->up = ad->up = i->i_hpfs_dno = rdno;
	d->root_dnode = ad->root_dnode = 0;
	mark_4buffers_dirty(&qbh);
	brelse4(&qbh);
	mark_4buffers_dirty(&qbh1);
	brelse4(&qbh1);
	qbh = qbh2;
	set_last_pointer(i->i_sb, rd, dno);
	dno = rdno;
	d = rd;
	goto go_up_a;
}

/*
 * Add an entry to directory btree.
 * I hate such crazy directory structure.
 * It's easy to read but terrible to write.
 * I wrote this directory code 4 times.
 * I hope, now it's finally bug-free.
 */

int add_dirent(struct inode *i, unsigned char *name, unsigned namelen,
	       struct hpfs_dirent *new_de, int cdepth)
{
	struct dnode *d;
	struct hpfs_dirent *de, *de_end;
	struct quad_buffer_head qbh;
	dnode_secno dno;
	int c;
	int depth = cdepth;
	int c1, c2 = 0;
	dno = i->i_hpfs_dno;
	down:
	if (i->i_sb->s_hpfs_chk)
		if (stop_cycles(i->i_sb, dno, &c1, &c2, "add_dirent")) return 1;
	if (!(d = map_dnode(i->i_sb, dno, &qbh))) return 1;
	de_end = dnode_end_de(d);
	for (de = dnode_first_de(d); de < de_end; de = de_next_de(de)) {
		if (!(c = compare_names(i->i_sb, name, namelen, de->name, de->namelen, de->last))) {
			brelse4(&qbh);
			PRINTK(("add_dirent: already exists\n"));
			return -1;
		}	
		if (c < 0) {
			if (de->down) {
				dno = de_down_pointer(de);
				brelse4(&qbh);
				depth++;
				goto down;
			}
			break;
		}
	}
	brelse4(&qbh);
	if (!cdepth) lock_creation(i->i_sb);
	if (check_free_dnodes(i->i_sb, depth + 2)) {
		c = 1;
		goto ret;
	}	
	i->i_version = ++event;
	c = add_to_dnode(i, dno, name, namelen, new_de, 0);
	ret:
	if (!cdepth) unlock_creation(i->i_sb);
	return c;
}

/* 
 * Find dirent with higher name in 'from' subtree and move it to 'to' dnode.
 * Return the dnode we moved from (to be checked later if it's empty)
 */

secno move_to_top(struct inode *i, dnode_secno from, dnode_secno to)
{
	dnode_secno dno, ddno;
	dnode_secno chk_up = to;
	struct dnode *dnode;
	struct quad_buffer_head qbh;
	struct hpfs_dirent *de, *nde;
	int a;
	loff_t t;
	int c1, c2 = 0;
	dno = from;
	while (1) {
		if (i->i_sb->s_hpfs_chk)
			if (stop_cycles(i->i_sb, dno, &c1, &c2, "move_to_top"))
				return 0;
		if (!(dnode = map_dnode(i->i_sb, dno, &qbh))) return 0;
		if (i->i_sb->s_hpfs_chk) {
			if (dnode->up != chk_up) {
				hpfs_error(i->i_sb, "move_to_top: up pointer from %08x should be %08x, is %08x", dno, chk_up, dnode->up);
				brelse4(&qbh);
				return 0;
			}
			chk_up = dno;
		}
		if (!(de = dnode_last_de(dnode))) {
			hpfs_error(i->i_sb, "move_to_top: dnode %08x has no last de", dno);
			brelse4(&qbh);
			return 0;
		}
		if (!de->down) break;
		dno = de_down_pointer(de);
		brelse4(&qbh);
	}
	while (!(de = dnode_pre_last_de(dnode))) {
		dnode_secno up = dnode->up;
		brelse4(&qbh);
		free_dnode(i->i_sb, dno);
		i->i_size -= 2048;
		i->i_blocks -= 4;
		for_all_poss(i, pos_subst, ((loff_t)dno << 4) | 1, 5);
		if (up == to) return to;
		if (!(dnode = map_dnode(i->i_sb, up, &qbh))) return 0;
		if (dnode->root_dnode) {
			hpfs_error(i->i_sb, "move_to_top: got to root_dnode while moving from %08x to %08x", from, to);
			brelse4(&qbh);
			return 0;
		}
		de = dnode_last_de(dnode);
		if (!de || !de->down) {
			hpfs_error(i->i_sb, "move_to_top: dnode %08x doesn't point down to %08x", up, dno);
			brelse4(&qbh);
			return 0;
		}
		dnode->first_free -= 4;
		de->length -= 4;
		de->down = 0;
		mark_4buffers_dirty(&qbh);
		dno = up;
	}
	t = get_pos(dnode, de);
	for_all_poss(i, pos_subst, t, 4);
	for_all_poss(i, pos_subst, t + 1, 5);
	if (!(nde = kmalloc(de->length, GFP_KERNEL))) {
		hpfs_error(i->i_sb, "out of memory for dirent - directory will be corrupted");
		return 0;
	}
	memcpy(nde, de, de->length);
	ddno = de->down ? de_down_pointer(de) : 0;
	delete_de(i->i_sb, dnode, de);
	set_last_pointer(i->i_sb, dnode, ddno);
	mark_4buffers_dirty(&qbh);
	brelse4(&qbh);
	a = add_to_dnode(i, to, nde->name, nde->namelen, nde, from);
	kfree(nde);
	if (a) return 0;
	return dno;
}

/* 
 * Check if a dnode is empty and delete it from the tree
 * (chkdsk doesn't like empty dnodes)
 */

void delete_empty_dnode(struct inode *i, dnode_secno dno)
{
	struct quad_buffer_head qbh;
	struct dnode *dnode;
	if (!(dnode = map_dnode(i->i_sb, dno, &qbh))) return;
	if (dnode->first_free > 56) goto end;
	if (dnode->first_free == 52) {
		struct hpfs_dirent *de, *de_end;
		dnode_secno up = dnode->up;
		int p;
		if (dnode->root_dnode) {
			hpfs_error(i->i_sb, "delete_empty_dnode: root dnode %08x is empty", dno);
			goto end;
		}
		brelse4(&qbh);
		free_dnode(i->i_sb, dno);
		i->i_size -= 2048;
		i->i_blocks -= 4;
		if (!(dnode = map_dnode(i->i_sb, up, &qbh))) return;
		p = 1;
		de_end = dnode_end_de(dnode);
		for (de = dnode_first_de(dnode); de < de_end; de = de_next_de(de), p++)
			if (de->down) if (de_down_pointer(de) == dno) goto fnd;
		hpfs_error(i->i_sb, "delete_empty_dnode: pointer to dnode %08x not found in dnode %08x", dno, up);
		goto end;
		fnd:
		for_all_poss(i, pos_subst, ((loff_t)dno << 4) | 1, ((loff_t)up << 4) | p);
		de->down = 0;
		de->length -= 4;
		dnode->first_free -= 4;
		memmove(de_next_de(de), (char *)de_next_de(de) + 4, (char *)dnode + dnode->first_free - (char *)de_next_de(de));
		mark_4buffers_dirty(&qbh);
	} else if (dnode->first_free == 56) {
		dnode_secno down = de_down_pointer(dnode_first_de(dnode));
		dnode_secno up = dnode->up;
		int r = dnode->root_dnode;
		struct quad_buffer_head qbh1;
		struct dnode *dnode1;
		if (!(dnode1 = map_dnode(i->i_sb, down, &qbh1))) goto end;
		memcpy(dnode, dnode1, 2048);
		dnode->self = dno;
		dnode->up = up;
		dnode->root_dnode = r;
		for_all_poss(i, pos_subst, ((loff_t)dno << 4) | 1, get_pos(dnode, dnode_last_de(dnode)));
		for_all_poss(i, pos_substd, (loff_t)down << 4, (loff_t)dno << 4);
		brelse4(&qbh1);
		free_dnode(i->i_sb, down);
		i->i_size -= 2048;
		i->i_blocks -= 4;
		fix_up_ptrs(i->i_sb, dnode);
		mark_4buffers_dirty(&qbh);
	} else hpfs_error(i->i_sb, "delete_empty_dnode: dnode %08, first_free == %03x", dno, dnode->first_free);
	end:
	brelse4(&qbh);
}
	

/* Delete dirent from directory */

int remove_dirent(struct inode *i, dnode_secno dno, struct hpfs_dirent *de,
		  struct quad_buffer_head *qbh, int depth)
{
	struct dnode *dnode = qbh->data;
	dnode_secno down = 0;
	loff_t t;
	if (de->first || de->last) {
		hpfs_error(i->i_sb, "remove_dirent: attempt to delete first or last dirent in dnode %08x", dno);
		brelse4(qbh);
		return 1;
	}
	if (de->down) {
		if ((down = de_down_pointer(de)))
			if (depth) lock_creation(i->i_sb);
		if (depth) if (check_free_dnodes(i->i_sb, depth + 2)) {
			brelse4(qbh);
			unlock_creation(i->i_sb);
			return 2;
		}
	}
	i->i_version = ++event;
	for_all_poss(i, pos_del, (t = get_pos(dnode, de)) + 1, 1);
	delete_de(i->i_sb, dnode, de);
	mark_4buffers_dirty(qbh);
	brelse4(qbh);
	if (down) {
		dnode_secno a = move_to_top(i, down, dno);
		for_all_poss(i, pos_subst, 5, t);
		if (depth) unlock_creation(i->i_sb);
		if (a) delete_empty_dnode(i, a);
		return !a;
	} else delete_empty_dnode(i, dno);
	return 0;
}

void count_dnodes(struct super_block *s, dnode_secno dno, int *n_dnodes,
		  int *n_subdirs, int *n_items)
{
	struct dnode *dnode;
	struct quad_buffer_head qbh;
	struct hpfs_dirent *de;
	dnode_secno ptr, odno = 0;
	int c1, c2 = 0;
	int d1, d2 = 0;
	go_down:
	if (n_dnodes) (*n_dnodes)++;
	if (s->s_hpfs_chk)
		if (stop_cycles(s, dno, &c1, &c2, "count_dnodes #1")) return;
	ptr = 0;
	go_up:
	if (!(dnode = map_dnode(s, dno, &qbh))) return;
	de = dnode_first_de(dnode);
	if (ptr) while(1) {
		if (de->down) if (de_down_pointer(de) == ptr) goto process_de;
		if (de->last) {
			brelse4(&qbh);
			hpfs_error(s, "count_dnodes: pointer to dnode %08x not found in dnode %08x, got here from %08x", ptr, dno, odno);
			return;
		}
		de = de_next_de(de);
	}
	next_de:
	if (de->down) {
		odno = dno;
		dno = de_down_pointer(de);
		brelse4(&qbh);
		goto go_down;
	}
	process_de:
	if (!de->first && !de->last && de->directory && n_subdirs) (*n_subdirs)++;
	if (!de->first && !de->last && n_items) (*n_items)++;
	if ((de = de_next_de(de)) < dnode_end_de(dnode)) goto next_de;
	ptr = dno;
	dno = dnode->up;
	if (dnode->root_dnode) {
		brelse4(&qbh);
		return;
	}
	brelse4(&qbh);
	if (s->s_hpfs_chk)
		if (stop_cycles(s, ptr, &d1, &d2, "count_dnodes #2")) return;
	odno = -1;
	goto go_up;
}

struct hpfs_dirent *map_nth_dirent(struct super_block *s, dnode_secno dno,
				   int n, struct quad_buffer_head *qbh,
				   struct dnode **dn)
{
	int i;
	struct hpfs_dirent *de, *de_end;
	struct dnode *dnode;
	/*PRINTK(("map_nth_dirent(%08x,%d)\n",dno,n));*/
	dnode = map_dnode(s, dno, qbh);
	if (!dnode) return NULL;
	if (dn) *dn=dnode;
	de = dnode_first_de(dnode);
	de_end = dnode_end_de(dnode);
	for (i = 1; de < de_end; i++, de = de_next_de(de)) {
		/*PRINTK(("map_nth_dirent: i = %d, de = %03x = %p, %p, de->length = %03x, n = '%c',%d\n",i,(char *)de - (char *)dnode, de, de->length, de->name[0], de->namelen));*/
		if (i == n) {
			/*PRINTK(("map_nth_dirent: return %03x\n",(char *)de - (char *)dnode));*/
			return de;
		}	
		if (de->last) break;
	}
	brelse4(qbh);
	hpfs_error(s, "map_nth_dirent: n too high; dnode = %08x, requested %08x", dno, n);
	return NULL;
}

dnode_secno de_as_down_as_possible(struct super_block *s, dnode_secno dno)
{
	struct quad_buffer_head qbh;
	dnode_secno d = dno;
	struct hpfs_dirent *de;
	int c1, c2 = 0;

	/*PRINTK(("de_as_down_as_possible(%08x)\n",dno));*/

	again:
	if (s->s_hpfs_chk)
		if (stop_cycles(s, d, &c1, &c2, "de_as_down_as_possible"))
			return d;
	if (!(de = map_nth_dirent(s, d, 1, &qbh, NULL))) return dno;
	if (!de->down) {
		brelse4(&qbh);
		/*PRINTK(("de_as_down_as_possible: return %08x\n",d));*/
		return d;
	}
	d = de_down_pointer(de);
	brelse4(&qbh);
	goto again;
}

struct hpfs_dirent *map_pos_dirent(struct inode *inode, loff_t *posp,
				   struct quad_buffer_head *qbh)
{
	loff_t pos;
	int c;
	dnode_secno dno;
	struct hpfs_dirent *de, *d;
	struct hpfs_dirent *up_de;
	struct hpfs_dirent *end_up_de;
	struct dnode *dnode;
	struct dnode *up_dnode;
	struct quad_buffer_head qbh0;

	/*PRINTK(("map_pos_dirent(%08x)\n",*posp));*/

	pos = *posp;
	dno = pos >> 6 << 2;
	pos &= 077;
	if (!(de = map_nth_dirent(inode->i_sb, dno, pos, qbh, &dnode)))
		goto bail;

	/* Going to the next dirent */
	if ((d = de_next_de(de)) < dnode_end_de(dnode)) {
		if (!(++*posp & 077)) {
			hpfs_error(inode->i_sb, "map_pos_dirent: pos crossed dnode boundary; pos = %08x", *posp);
			goto bail;
		}
		/* We're going down the tree */
		if (d->down) {
			*posp = ((loff_t) de_as_down_as_possible(inode->i_sb, de_down_pointer(d)) << 4) + 1;
		}
	
		return de;
	}

	/* Going up */
	if (dnode->root_dnode) goto bail;

	if (!(up_dnode = map_dnode(inode->i_sb, dnode->up, &qbh0)))
		goto bail;

	end_up_de = dnode_end_de(up_dnode);
	c = 0;
	for (up_de = dnode_first_de(up_dnode); up_de < end_up_de;
	     up_de = de_next_de(up_de)) {
		if (!(++c & 077)) hpfs_error(inode->i_sb, "map_pos_dirent: pos crossed dnode boundary; dnode = %08x", dnode->up);
		if (up_de->down && de_down_pointer(up_de) == dno) {
			*posp = ((loff_t) dnode->up << 4) + c;
			brelse4(&qbh0);
			return de;
		}
	}
	
	hpfs_error(inode->i_sb, "map_pos_dirent: pointer to dnode %08x not found in parent dnode %08x", dno, dnode->up);
	brelse4(&qbh0);
	
	bail:
	*posp = -2;
	return de;
}

/* Find a dirent in tree */

struct hpfs_dirent *map_dirent(struct inode *inode, dnode_secno dno,
			       char *name, unsigned len, dnode_secno *dd,
			       struct quad_buffer_head *qbh, int *depth)
{
	struct dnode *dnode;
	struct hpfs_dirent *de;
	struct hpfs_dirent *de_end;
	int c1, c2 = 0;

	/*PRINTK(("map_dirent(%08x,'%c',%d)\n",dno,name[0],len));*/

	if (depth) *depth = 0;

	if (!S_ISDIR(inode->i_mode)) hpfs_error(inode->i_sb, "map_dirent: not a directory\n");
	again:
	if (inode->i_sb->s_hpfs_chk)
		if (stop_cycles(inode->i_sb, dno, &c1, &c2, "map_dirent")) return NULL;
	if (!(dnode = map_dnode(inode->i_sb, dno, qbh))) return NULL;
	
	de_end = dnode_end_de(dnode);
	for (de = dnode_first_de(dnode); de < de_end; de = de_next_de(de)) {
		int t = compare_names(inode->i_sb, name, len, de->name, de->namelen, de->last);
		if (!t) {
			/*PRINTK(("map_dirent: found!\n"));*/
			if (dd) *dd = dno;
			return de;
		}
		if (t < 0) {
			if (de->down) {
				dno = de_down_pointer(de);
				brelse4(qbh);
				/*PRINTK(("map_dirent: going down to dnode %08x\n",dno));*/
				if (depth) (*depth)++;
				goto again;
			}
		break;
		}
	}
	brelse4(qbh);
	PRINTK(("map_dirent: not found\n"));
	return NULL;
}

/*
 * Remove empty directory. In normal cases it is only one dnode with two
 * entries, but we must handle also such obscure cases when it's a tree
 * of empty dnodes.
 */

void remove_dtree(struct super_block *s, dnode_secno dno)
{
	struct quad_buffer_head qbh;
	struct dnode *dnode;
	struct hpfs_dirent *de;
	dnode_secno d1, d2, rdno = dno;
	while (1) {
		if (!(dnode = map_dnode(s, dno, &qbh))) return;
		de = dnode_first_de(dnode);
		if (de->last) {
			if (de->down) d1 = de_down_pointer(de);
			else goto error;
			brelse4(&qbh);
			free_dnode(s, dno);
			dno = d1;
		} else break;
	}
	if (!de->first) goto error;
	d1 = de->down ? de_down_pointer(de) : 0;
	de = de_next_de(de);
	if (!de->last) goto error;
	d2 = de->down ? de_down_pointer(de) : 0;
	brelse4(&qbh);
	free_dnode(s, dno);
	do {
		while (d1) {
			if (!(dnode = map_dnode(s, dno = d1, &qbh))) return;
			de = dnode_first_de(dnode);
			if (!de->last) goto error;
			d1 = de->down ? de_down_pointer(de) : 0;
			brelse4(&qbh);
			free_dnode(s, dno);
		}
		d1 = d2;
		d2 = 0;
	} while (d1);
	return;
	error:
	brelse4(&qbh);
	free_dnode(s, dno);
	hpfs_error(s, "directory %08x is corrupted or not empty", rdno);
}

/* 
 * Find dirent for specified fnode. Use truncated 15-char name in fnode as
 * a help for searching.
 */

struct hpfs_dirent *map_fnode_dirent(struct super_block *s, fnode_secno fno,
				     struct fnode *f,
				     struct quad_buffer_head *qbh)
{
	char *name1;
	char name2[256];
	int name1len, name2len;
	struct dnode *d;
	dnode_secno dno, downd;
	struct fnode *upf;
	struct buffer_head *bh;
	struct hpfs_dirent *de, *de_end;
	int c;
	int c1, c2 = 0;
	int d1, d2 = 0;
	name1 = f->name;
	if (f->len <= 15)
		memcpy(name2, name1, name1len = name2len = f->len);
	else {
		memcpy(name2, name1, 15);
		memset(name2 + 15, 0xff, 256 - 15);
		name1len = 15; name2len = 256;
	}
	if (!(upf = map_fnode(s, f->up, &bh))) return NULL;
	if (!upf->dirflag) {
		brelse(bh);
		hpfs_error(s, "fnode %08x has non-directory parent %08x", fno, f->up);
		return NULL;
	}
	dno = upf->u.external[0].disk_secno;
	brelse(bh);
	go_down:
	downd = 0;
	go_up:
	if (!(d = map_dnode(s, dno, qbh))) return NULL;
	de_end = dnode_end_de(d);
	de = dnode_first_de(d);
	if (downd) {
		while (de < de_end) {
			if (de->down) if (de_down_pointer(de) == downd) goto f;
			de = de_next_de(de);
		}
		hpfs_error(s, "pointer to dnode %08x not found in dnode %08x", downd, dno);
		brelse4(qbh);
		return NULL;
	}
	next_de:
	if (de->fnode == fno) return de;
	c = compare_names(s, name1, name1len, de->name, de->namelen, de->last);
	if (c < 0 && de->down) {
		dno = de_down_pointer(de);
		brelse4(qbh);
		if (s->s_hpfs_chk)
			if (stop_cycles(s, dno, &c1, &c2, "map_fnode_dirent #1")) return NULL;
		goto go_down;
	}
	f:
	if (de->fnode == fno) return de;
	c = compare_names(s, name2, name2len, de->name, de->namelen, de->last);
	if (c < 0 && !de->last) goto not_found;
	if ((de = de_next_de(de)) < de_end) goto next_de;
	if (d->root_dnode) goto not_found;
	downd = dno;
	dno = d->up;
	brelse4(qbh);
	if (s->s_hpfs_chk)
		if (stop_cycles(s, downd, &d1, &d2, "map_fnode_dirent #2"))
			return NULL;
	goto go_up;
	not_found:
	brelse4(qbh);
	hpfs_error(s, "dirent for fnode %08x not found", fno);
	return NULL;
}

