/*
 *  linux/fs/hpfs/alloc.c
 *
 *  Mikulas Patocka (mikulas@artax.karlin.mff.cuni.cz), 1998
 *
 *  general buffer i/o
 */

#include "hpfs_fn.h"

void lock_creation(struct super_block *s)
{
#ifdef DEBUG_LOCKS
	printk("lock creation\n");
#endif
	while (s->s_hpfs_creation_de_lock) sleep_on(&s->s_hpfs_creation_de);
	s->s_hpfs_creation_de_lock = 1;
}

void unlock_creation(struct super_block *s)
{
#ifdef DEBUG_LOCKS
	printk("unlock creation\n");
#endif
	s->s_hpfs_creation_de_lock = 0;
	wake_up(&s->s_hpfs_creation_de);
}

void lock_iget(struct super_block *s, int mode)
{
#ifdef DEBUG_LOCKS
	printk("lock iget\n");
#endif
	while (s->s_hpfs_rd_inode) sleep_on(&s->s_hpfs_iget_q);
	s->s_hpfs_rd_inode = mode;
}

void unlock_iget(struct super_block *s)
{
#ifdef DEBUG_LOCKS
	printk("unlock iget\n");
#endif
	s->s_hpfs_rd_inode = 0;
	wake_up(&s->s_hpfs_iget_q);
}

void hpfs_lock_inode(struct inode *i)
{
#ifdef DEBUG_LOCKS
	printk("lock inode %08x\n",i->i_ino);
#endif
	while (i->i_hpfs_lock) sleep_on(&i->i_hpfs_queue);
	i->i_hpfs_lock = 1;
}

void hpfs_unlock_inode(struct inode *i)
{
	if (!i) return;
#ifdef DEBUG_LOCKS
	printk("unlock inode %08x\n",i->i_ino);
#endif
	i->i_hpfs_lock = 0;
	wake_up(&i->i_hpfs_queue);
}

void hpfs_lock_2inodes(struct inode *i1, struct inode *i2)
{
	if (!i1) { hpfs_lock_inode(i2); return; }
	if (!i2) { hpfs_lock_inode(i1); return; }
#ifdef DEBUG_LOCKS
	printk("lock 2 inodes %08x, %08x\n",i1->i_ino,i2->i_ino);
#endif
	while (i1->i_hpfs_lock || i2->i_hpfs_lock) {
		if (i1->i_hpfs_lock) sleep_on(&i1->i_hpfs_queue);
		if (i2->i_hpfs_lock) sleep_on(&i2->i_hpfs_queue);
	}
	i1->i_hpfs_lock = 1;
	i2->i_hpfs_lock = 1;
}

void hpfs_unlock_2inodes(struct inode *i1, struct inode *i2)
{
	hpfs_unlock_inode(i1);
	if (i1 != i2) hpfs_unlock_inode(i2);
}

void hpfs_lock_3inodes(struct inode *i1, struct inode *i2, struct inode *i3)
{
	if (!i1) { hpfs_lock_2inodes(i2, i3); return; }
	if (!i2) { hpfs_lock_2inodes(i1, i3); return; }
	if (!i3) { hpfs_lock_2inodes(i1, i2); return; }
#ifdef DEBUG_LOCKS
	printk("lock 3 inodes %08x, %08x, %08x\n",i1->i_ino,i2->i_ino,i3->i_ino);
#endif
	while (i1->i_hpfs_lock || i2->i_hpfs_lock || i3->i_hpfs_lock) {
		if (i1->i_hpfs_lock) sleep_on(&i1->i_hpfs_queue);
		if (i2->i_hpfs_lock) sleep_on(&i2->i_hpfs_queue);
		if (i3->i_hpfs_lock) sleep_on(&i3->i_hpfs_queue);
	}
	i1->i_hpfs_lock = 1;
	i2->i_hpfs_lock = 1;
	i3->i_hpfs_lock = 1;
}

void hpfs_unlock_3inodes(struct inode *i1, struct inode *i2, struct inode *i3)
{
	hpfs_unlock_inode(i1);
	if (i1 != i2) hpfs_unlock_inode(i2);
	if (i1 != i3 && i2 != i3) hpfs_unlock_inode(i3);
}

/* Map a sector into a buffer and return pointers to it and to the buffer. */

void *map_sector(struct super_block *s, unsigned secno,
			struct buffer_head **bhp, int ahead)
{
	kdev_t dev = s->s_dev;
	struct buffer_head *bh;

	if (!ahead || secno + ahead >= s->s_hpfs_fs_size)
		*bhp = bh = bread(dev, secno, 512);
	else *bhp = bh = breada(dev, secno, 512, 0, (ahead + 1) << 9);
	if (bh != NULL)
		return bh->b_data;
	else {
		printk("HPFS: map_sector: read error\n");
		return NULL;
	}
}

/* Like map_sector but don't read anything */

void *get_sector(struct super_block *s, unsigned secno,
			struct buffer_head **bhp)
{
	struct buffer_head *bh;
	/*return map_sector(s, secno, bhp, 0);*/

	if ((*bhp = bh = getblk(s->s_dev, secno, 512)) != NULL) {
		mark_buffer_uptodate(bh, 1);
		return bh->b_data;
	} else {
		printk("HPFS: get_sector: getblk failed\n");
		return NULL;
	}
}

/* Map 4 sectors into a 4buffer and return pointers to it and to the buffer. */

void *map_4sectors(struct super_block *s, unsigned secno,
			  struct quad_buffer_head *qbh, int ahead)
{
	kdev_t dev = s->s_dev;
	struct buffer_head *bh;
	char *data;

	if (secno & 3) {
		printk("HPFS: map_4sectors: unaligned read\n");
		return 0;
	}

	qbh->data = data = (char *)kmalloc(2048, GFP_KERNEL);
	if (!data) {
		printk("HPFS: map_4sectors: out of memory\n");
		goto bail;
	}

	if (!ahead || secno + 4 + ahead > s->s_hpfs_fs_size)
		qbh->bh[0] = bh = breada(dev, secno, 512, 0, 2048);
	else qbh->bh[0] = bh = breada(dev, secno, 512, 0, (ahead + 4) << 9);
	if (!bh)
		goto bail0;
	memcpy(data, bh->b_data, 512);

	qbh->bh[1] = bh = bread(dev, secno + 1, 512);
	if (!bh)
		goto bail1;
	memcpy(data + 512, bh->b_data, 512);

	qbh->bh[2] = bh = bread(dev, secno + 2, 512);
	if (!bh)
		goto bail2;
	memcpy(data + 2 * 512, bh->b_data, 512);

	qbh->bh[3] = bh = bread(dev, secno + 3, 512);
	if (!bh)
		goto bail3;
	memcpy(data + 3 * 512, bh->b_data, 512);

	return data;

 bail3:
	brelse(qbh->bh[2]);
 bail2:
	brelse(qbh->bh[1]);
 bail1:
	brelse(qbh->bh[0]);
 bail0:
	kfree_s(data, 2048);
	printk("HPFS: map_4sectors: read error\n");
 bail:
	return NULL;
}

/* Don't read sectors */

void *get_4sectors(struct super_block *s, unsigned secno,
                          struct quad_buffer_head *qbh)
{
	if (secno & 3) {
		printk("HPFS: get_4sectors: unaligned read\n");
		return 0;
	}

	/*return map_4sectors(s, secno, qbh, 0);*/
	if (!(qbh->data = kmalloc(2048, GFP_KERNEL))) {
		printk("HPFS: get_4sectors: out of memory\n");
		return NULL;
	}
	if (!(get_sector(s, secno, &qbh->bh[0]))) goto bail0;
	if (!(get_sector(s, secno + 1, &qbh->bh[1]))) goto bail1;
	if (!(get_sector(s, secno + 2, &qbh->bh[2]))) goto bail2;
	if (!(get_sector(s, secno + 3, &qbh->bh[3]))) goto bail3;
	memcpy(qbh->data, qbh->bh[0]->b_data, 512);
	memcpy(qbh->data + 512, qbh->bh[1]->b_data, 512);
	memcpy(qbh->data + 2*512, qbh->bh[2]->b_data, 512);
	memcpy(qbh->data + 3*512, qbh->bh[3]->b_data, 512);
	return qbh->data;

	bail3:	brelse(qbh->bh[2]);
	bail2:	brelse(qbh->bh[1]);
	bail1:	brelse(qbh->bh[0]);
	bail0:
	return NULL;
}
	

void brelse4(struct quad_buffer_head *qbh)
{
	brelse(qbh->bh[3]);
	brelse(qbh->bh[2]);
	brelse(qbh->bh[1]);
	brelse(qbh->bh[0]);
	kfree_s(qbh->data, 2048);
}	

void mark_4buffers_dirty(struct quad_buffer_head *qbh)
{
	PRINTK(("mark_4buffers_dirty\n"));
	memcpy(qbh->bh[0]->b_data, qbh->data, 512);
	memcpy(qbh->bh[1]->b_data, qbh->data + 512, 512);
	memcpy(qbh->bh[2]->b_data, qbh->data + 2 * 512, 512);
	memcpy(qbh->bh[3]->b_data, qbh->data + 3 * 512, 512);
	mark_buffer_dirty(qbh->bh[0],1);
	mark_buffer_dirty(qbh->bh[1],1);
	mark_buffer_dirty(qbh->bh[2],1);
	mark_buffer_dirty(qbh->bh[3],1);
}

/*
void sync_4buffers(struct quad_buffer_head *qbh)
{
	memcpy(qbh->data, qbh->bh[0]->b_data, 512);
	memcpy(qbh->data + 512, qbh->bh[1]->b_data, 512);
	memcpy(qbh->data + 2 * 512, qbh->bh[2]->b_data, 512);
	memcpy(qbh->data + 3 * 512, qbh->bh[3]->b_data, 512);
}
*/
