/*
 *  msmangle.h based on
 *  linux/fs/umsdos/mangle.c
 *
 *      Written 1993 by Jacques Gelinas
 *
 * Control the mangling of file name to fit msdos name space.
 * Many optimisation by GLU == dglaude@is1.vub.ac.be (GLAUDE DAVID)
 *
 * msmangle.h is an Msdos compilable version of mangle.c to implement ls.exe
 * Once again, modification by GLU.
 */

/* Truc pour pouvoir inclure la version msdos de umsdos_fs.h */

#include "dosumsfs.h"

void umsdos_manglename (struct umsdos_info *info);
int umsdos_evalrecsize (int len);
int umsdos_parse (const char *fname, int len, struct umsdos_info *info);

