/* This have more or less the same interface that the real Linux "dirent" */
/* But it give information that "stat" usually give and other that only */
/* a special ioctl give for Umsdos directory .... */

/* Please do not wait time to try to reusse this code... This is C not Ada ! */

/*
	Attention, ce code risque de changer sans que vous ne soyez prevenu,
	tout amelioration risquant de rendre la nouvelle version
	incompatible avec les precedents...
	Veuillez ne reutiliser ce code qu'en dernier limite, et conserver
	votre version sous un autre nom.

	Ceci fait partie d'un essait de "portage" des fonctinalites de
	Umsdos sous MsDos. Une tres faible partie de cet essait est deja
	mise en	place, et seul l'indispensable pour ecrire une version
	MsDos de ls (ls.exe) est reelement implementee.
	Ce n'est vraiment pas encore genial, mais cela vaut mieux que rien.

	Ce devrais etre presque complet maintenant, seul la difference entre
	dirent et umsdos_dirent devrais etre visable. et aussi peut etre
	le fait que la directory n'est pas allouer dynamiquement !!!
	Attention de n'ouvrir qu'une directory a la fois, ou de recopier
	la structure DIR avant un deuxieme opendir...
	Le string a donner n'est pas le nom de la directory, mais le nom du
	fichier "--linux-.--- contenu dans la directory.
	Ne fonctione que dans la directory courrante (pour le moment!).
*/

#include <io.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys\stat.h>
#include "dirent.h"
#include "msmangle.h"

DIR tmpdir;

void rewinddir(DIR *dir)
{
 lseek(dir->fd, 0L, SEEK_SET);
}

void seekdir(DIR *dir, off_t offset)
{
 lseek(dir->fd, offset, SEEK_SET);
}

off_t telldir(DIR *dir)
{
 return lseek(dir->fd, 0L, SEEK_CUR);
}

DIR *opendir(const char *name)
{
 tmpdir.info.f_pos=0;
 if((tmpdir.fd=open(name, O_EXCL|O_RDONLY|O_BINARY, S_IREAD))<0)
	return NULL;
 return &tmpdir;
}

int closedir(DIR *dir)
{
 return close(dir->fd);
}

struct dirent *readdir(DIR *dir)
{
int pasfini=1;
int size;
int ok=1;

 dir->info.f_pos=lseek(dir->fd, 0L, SEEK_CUR); /* Needed for mangle */
 do{
  if ((size=read(dir->fd, &(dir->info.entry),UMSDOS_REC_SIZE))==UMSDOS_REC_SIZE){
   size=umsdos_evalrecsize(dir->info.entry.name_len);
   if (dir->info.entry.name_len!=0) pasfini=0;
  }else{
   pasfini=0;
   ok=0;
   if (size){
    printf("Error: uncomplet entry.\n");
   }
  }
 }while(pasfini);

 if(ok){
  if ((size!=UMSDOS_REC_SIZE)?
    (read(dir->fd,((char *)&(dir->info.entry)+UMSDOS_REC_SIZE),
    size-UMSDOS_REC_SIZE)!=size-UMSDOS_REC_SIZE):0){
   printf("Error: uncomplet entry.\n");
   ok=0;
  }
 }
 if(ok)
  { /* Completement foireux comme definition, mais bon */
  umsdos_parse(dir->info.entry.name, dir->info.entry.name_len, 
               (struct umsdos_info *)&(dir->info));
  umsdos_manglename((struct umsdos_info *)&(dir->info));
  } /* Si cela marche ... il faudrais quand meme corriger !!! */

 return ok?&(dir->info):NULL;
}

int alphasort(struct dirent **a ,struct dirent **b)
{
  return strcmp ((*a)->entry.name, (*b)->entry.name);
}

int scandir (char *dir, struct dirent ***namelist,
	     __dir_select_fn_t select, __dir_compar_fn_t compar)
{
  DIR *dp = opendir (dir);
  struct dirent **v = NULL;
  size_t vsize = 0, i;
  struct dirent *d;
  int save;

  if (dp == NULL)
    return -1;

  save = errno;
  errno = 0;

  i = 0;
  while ((d = readdir (dp)) != NULL)
    if (select == NULL || (*select) (d))
      {
	if (i == vsize)
	  {
	    struct dirent **new;

	    if (vsize == 0) vsize = 10;
	    else 	    vsize *= 2;
	    new = (struct dirent **) realloc (v, vsize * sizeof (*v));
	    if (new == NULL)
	      {
	      lose:
		(void) closedir (dp);
		while (i > 0)
		  free (v[--i]);
		free (v);
		errno = 1 /*ENOMEM*/;
		return -1;
	      }
	    v = new;
	  }

	v[i] = (struct dirent *) malloc (sizeof (**v));
	if (v[i] == NULL)
	  goto lose;

	*v[i++] = *d;
      }

  if (errno != 0)
    {
      (void) closedir (dp);
      return -1;
    }

  errno = save;

  if (compar != NULL)
      qsort (v, i, sizeof (*v),
	     (int(*)(const void *,const void *))compar);
  *namelist = v;
  return i;
}

