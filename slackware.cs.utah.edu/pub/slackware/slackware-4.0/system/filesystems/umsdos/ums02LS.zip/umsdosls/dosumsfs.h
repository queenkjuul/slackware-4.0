/* This include file is made to help compilation of umsdos tools under MsDos */
#ifndef DOSUMSFS_H
#define DOSUMSFS_H

typedef unsigned int uid_t;     /* Owner user id */
typedef unsigned int gid_t;     /* Group id */
typedef unsigned int dev_t;     /* major and minor number of a device */
typedef unsigned int umode_t;   /* Standard UNIX permissions bits + type of */
typedef unsigned long time_t;   /* Do not mach the MsDos definition ! */
typedef long off_t;             /* There is no MsDos definition for that */
#define VERSION_MSDOS           /* Made to skip part of UMSDOS_FS.H */
#define LINUX_FS_H		/* Made to skip the inclusion of the file */
#include "linux\ums_fs.h"	/* MsDos version of UMSDOS_FS.H */

#endif
