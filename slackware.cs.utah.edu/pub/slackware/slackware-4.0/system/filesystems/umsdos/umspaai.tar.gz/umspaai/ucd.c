#include <stdio.h>
#include <dir.h>

int error_exit(char *s)
{
printf("%s\n",s);
printf("Usage: ucd umsdosdirname\n");
printf("does a chdir to directory on umsdos' directoryname\n");
printf("Copyright Hans Paijmans 1996\n");
exit(0);
}

main(int argc, char **argv)
{
FILE *f;
char umsname[100],dosname[13];

if ((argc<2) || (!strcmp(argv[1],"-h"))
) error_exit("");

if ((f=fopen("descript.ion","r"))==NULL)
	     error_exit("No 4dos-descriptions\n");
   else
   while (!feof(f))
   {
   fscanf(f,"%s %s\n",&dosname,&umsname);
   if (!strcmp(umsname,argv[1]))
      {
      chdir(dosname);
      fclose(f);
      exit(0);
      }
   }
printf("Directory %s not found\n",argv[1]);
fclose(f);
exit(1);
}
