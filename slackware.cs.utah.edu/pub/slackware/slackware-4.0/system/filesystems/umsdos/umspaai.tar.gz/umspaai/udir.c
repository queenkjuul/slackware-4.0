#include <stdio.h>
#include <stdlib.h>
#include <dir.h>
#include <dos.h>
#include <string.h>
#include<ctype.h>

/* umsdos-blok is 64 bytes... */
struct dirent {
	unsigned char name_len;	/* if == 0, then this entry is not used */
	unsigned char  flags;	/* UMSDOS_xxxx */
	unsigned char nlink;	/* How many hard links point to this entry */

	char    lui[21];
	char	spare[12];
	char name[28];
};

int error_exit(char *s)
{
printf("%s\n",s);
printf("Usage: udir [-m file]\n");
printf("maps files from MS-DOS to umsdos' filenames\n");
printf("option -m file: only returns MS-DOS name for file\n");
printf("Copyright Hans Paijmans 1996\n");
exit(0);
return 0;
}

/*--------------------------------------------*/
int convert_32(char *s)
{
#define SPECIAL_MANGLING '{','}','(',')','!','`','^','&','@'
static char lookup3[]={
			SPECIAL_MANGLING,
			/* This is the start of lookup12 */
			'_','1','2','3','4','5','6','7','8','9',
			'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o',
			'p','q','r','s','t','u','v'
		};
#define lookup12 (lookup3+9)
int x,nul,een,twee;

nul=een=twee=0;
if (s[0]!='{') return(-1); /* not a umsdos-name */
s[2]=tolower(s[2]);
s[1]=tolower(s[1]);

for (x=0;x<10;x++) if (s[0]==lookup3[x]) nul=x;
for (x=0;x<32;x++) if (s[1]==lookup12[x]) een=x;
for (x=0;x<32;x++) if (s[2]==lookup12[x]) twee=x;

return   (nul*32) +  (een*32) + twee;

}
/* ========================================================== */

main(int argc, char **argv)
{
int done,l,x;
char a[80],ext[4];
struct ffblk ff_blk;
struct dirent blok[100];
char   zoeknaam[64],namen[13][100];
int waarden[100];
int dirtop,map,teller=0;
FILE *f;

if (!strcmp(argv[1],"-h")) error_exit("");
if (!strcmp(argv[1],"-m")) {map=1; strcpy(zoeknaam,argv[2]);} else map=0;

done=findfirst("*.*",&ff_blk,FA_DIREC+FA_RDONLY+FA_HIDDEN+FA_SYSTEM+FA_ARCH);
while (!done)
      {
      ext[1]=0;
      _splitpath(ff_blk.ff_name,a,a,a,ext);
      x=convert_32(&ext[1]);
      if (x>0)
	    {
	    strcpy(namen[teller],ff_blk.ff_name);
	    waarden[teller]=x;
	    teller++;
	    }
      done=findnext(&ff_blk);
      }
dirtop=teller-1;
teller=0;

if ((f=fopen("--linux-.---","rb"))==NULL) {printf("not found\n");exit(1);}

while (!feof(f))
     {
     l=fread(&blok[teller++],1,64,f);
     /* printf("%s\n",blok.name);*/
     }

if (!map) for (teller=0;teller<dirtop;teller++)
    if (waarden[teller]>0)
	   printf ("%s %s\n",namen[teller],blok[waarden[teller]].name);

if (map)  for (teller=0;teller<dirtop;teller++)
    if (waarden[teller]>0)
	   if (!strcmp(blok[waarden[teller]].name,zoeknaam)) printf ("%s\n",namen[teller]);

exit(0);
}
