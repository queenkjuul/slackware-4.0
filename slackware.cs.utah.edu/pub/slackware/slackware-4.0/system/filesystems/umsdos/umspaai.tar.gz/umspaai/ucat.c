#include <stdio.h>
#include <dir.h>

int error_exit(char *s)
{
printf("%s\n",s);
printf("Usage: ucat umsdosfilename\n");
printf("displays file using umsdos' filename\n");
printf("Copyright Hans Paijmans 1996\n");
exit(0);
}

main(int argc, char **argv)
{
FILE *f,*ff;
char umsname[100],dosname[13],regel[1024];

if ((argc<2) || (!strcmp(argv[1],"-h"))
) error_exit("");

if ((f=fopen("descript.ion","r"))==NULL)
	     error_exit("No 4dos-descriptions\n");
   else
   while (!feof(f))
   {
   fscanf(f,"%s %s\n",&dosname,&umsname);
   if (!strcmp(umsname,argv[1]))
       {
       if ((ff=fopen(dosname,"r"))==NULL)
	     error_exit("file problem\n");
	  while(!feof(ff))
	     {
	     fgets(regel,1024,ff);
	     printf("%s",regel);
	     }
       fclose(ff);
       fclose(f);
       exit(0);
       }
   }
printf("File %s not found\n",argv[1]);
fclose(f);
exit(1);
}
