#include <kwinwidget.h>
#include <kwinwidget.moc>

KWinWidget::KWinWidget(QWidget *parent, const char *name)
	: QWidget(parent, name)
{
}

KWinWidget::~KWinWidget()
{
}
