#ifndef KWINWIDGET_H 
#define KWINWIDGET_H 

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

#include <kapp.h>
#include <qwidget.h>

class KWinWidget : public QWidget
{
	Q_OBJECT
public:
	KWinWidget(QWidget *parent = 0, const char *name = 0);
	virtual ~KWinWidget();
};

#endif // KWINWIDGET_H 
