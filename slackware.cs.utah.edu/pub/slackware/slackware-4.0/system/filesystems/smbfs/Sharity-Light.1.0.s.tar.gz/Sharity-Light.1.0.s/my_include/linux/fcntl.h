#include <sys/fcntl.h>
#ifdef NeXT
#include <libc.h>
#endif
