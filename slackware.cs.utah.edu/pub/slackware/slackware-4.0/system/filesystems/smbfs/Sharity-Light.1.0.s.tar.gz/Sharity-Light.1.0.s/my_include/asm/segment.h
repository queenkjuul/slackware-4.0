struct vm_area_struct;

#define	memcpy_fromfs	memcpy
#define	memcpy_tofs		memcpy

#define	GFP_KERNEL	0

