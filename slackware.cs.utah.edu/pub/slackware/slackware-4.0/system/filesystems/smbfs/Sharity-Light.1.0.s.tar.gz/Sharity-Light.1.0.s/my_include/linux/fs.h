
#ifndef __FS_H_INCLUDED__
#define	__FS_H_INCLUDED__

#include <asm/segment.h>

struct inode{
/*	struct super_block *i_sb;*/
	unsigned long	i_ino;
	union {
		void	*generic_ip;
	}u;
};
struct super_block{
	union {
		void	*generic_sbp;
	}u;
};

struct iattr;
struct wait_queue;

extern void sleep_on(struct wait_queue ** p);
extern void wake_up(struct wait_queue ** p);


#endif /* !__FS_H_INCLUDED__ */
