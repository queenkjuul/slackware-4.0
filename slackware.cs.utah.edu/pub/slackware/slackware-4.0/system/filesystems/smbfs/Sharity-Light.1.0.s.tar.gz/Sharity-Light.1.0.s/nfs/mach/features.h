/*
 * Name: features.h
 * Description: Dummy file. Some NeXT system headers want to include this
 *     but can't find it.
 * Author: Christian Starkjohann <cs@hal.kph.tuwien.ac.at>
 * Date: 1996-11-14
 * Copyright: GNU-GPL
 * Tabsize: 4
 */
