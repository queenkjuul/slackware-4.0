#ifndef __TYPES_H_INCLUDED
#define	__TYPES_H_INCLUDED

#include <sys/types.h>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>

extern int	printk(const char *format, ...);


typedef signed char s8;
typedef signed char __s8;
typedef unsigned char u8;
typedef unsigned char __u8;

typedef signed short s16;
typedef signed short __s16;
typedef unsigned short u16;
typedef unsigned short __u16;

typedef signed int s32;
typedef signed int __s32;
typedef unsigned int u32;
typedef unsigned int __u32;

#if 0	/* obviously not needed */
typedef signed long long s64;
typedef signed long long __s64;
typedef unsigned long long u64;
typedef unsigned long long __u64;
#endif

#endif /* !__TYPES_H_INCLUDED */

