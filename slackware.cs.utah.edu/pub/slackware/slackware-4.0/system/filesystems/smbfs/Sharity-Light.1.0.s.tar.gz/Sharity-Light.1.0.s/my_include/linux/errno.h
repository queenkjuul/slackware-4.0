#ifndef __ERRNO_H_INCLUDED__
#define	__ERRNO_H_INCLUDED__

#include <sys/errno.h>

#define	EREMOTEIO	EIO
#define	EUCLEAN		117

#endif /* !__ERRNO_H_INCLUDED__ */
