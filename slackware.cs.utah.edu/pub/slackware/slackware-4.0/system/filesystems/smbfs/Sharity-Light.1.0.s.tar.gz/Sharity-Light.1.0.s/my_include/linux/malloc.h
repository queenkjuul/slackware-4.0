
#ifndef __MALLOC_H_INCLUDED__
#define __MALLOC_H_INCLUDED__

void * kmalloc(unsigned int size, int priority);
void kfree(void * obj);
void kfree_s(void *obj, int size);
/*
 * #define kfree_s(a,b) kfree(a)
 */

#endif /* !__MALLOC_H_INCLUDED__ */
