/*
 * display.c - all screen handling functions for the picture option of the
 * file system defragmenter.
 *
 * Copyright (C) 1997 Stephen Tweedie <sct@dcs.ed.ac.uk>
 */

#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <stdio.h>

#include "display.h"

int voyer_mode = 0;

void _die(char *last_words) 
{
	fprintf(stderr,last_words);
	exit(1);
}

void stat_line(const char *fmt, ...) 
{
	char s[256];
	va_list args;
	va_start(args,fmt);
	vsprintf(s,fmt,args);
	va_end(args);
	
	puts(s);
}

void init_screen(ulong blocks) 
{
}

void done_screen(int wait_key)
{
}

void add_comment(char *text)
{
	puts(text);
}

void clear_comments(void)
{
}

void display_comments(char *title)
{
}

void display_legend(ushort attr)
{
}

void set_attr(ulong block, ushort attr) 
{
}

void clear_attr(ushort attr) 
{
}

void show_cell(int i) 
{
}
       
void update_display(void) 
{
}

void display_map(void) 
{
}



