/*
 * errmsgs.h -- gpart error/warning messages header file
 *
 * gpart (c) 1999 Michail Brzitwa <mb@ichabod.han.de>
 * Guess PC-type hard disk partitions.
 *
 * gpart is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2, or (at your
 * option) any later version.
 *
 * Created:   04.01.1999 <mb@ichabod.han.de>
 * Modified:
 *
 */

#ifndef _ERRMSGS_H
#define _ERRMSGS_H


/* dialog messages */
#define DM_YESNO		"(y,n)"
#define DM_YES			"yY"
#define DM_STARTSCAN		"\nBegin scan...\n"
#define DM_ENDSCAN		"End scan.\n"
#define DM_ACCEPTGUESS		"\nAccept this guess"
#define DM_ACTWHICHPART		"\nActivate which partition (1..%d)? "
#define DM_ASKTOREBOOT		"partition table written, you should reboot now"
#define DM_STARTCHECK		"\nChecking partitions...\n"
#define DM_NOOFINCONS		"Number of inconsistencies found: %d.\n"
#define DM_GUESSEDPTBL		"\nGuessed primary partition table:\n"

/* partition list messages */
#define PM_DEVDESC1		"\ndev(%s) mss(%d)"
#define PM_DEVDESC2		" chs(%d/%d/%d)%s#s(%012qd) size(%qdmb)"
#define PM_MBRPRINT		"\ndev(%s) master boot record (w/o partition table):\n"
#define PM_PRIMPART		"Primary partition(%d)\n"
#define PM_EXTPART		"   Logical partition\n"
#define PM_POSSIBLEPART		"Possible partition(%s), size(%qdmb), offset(%qdmb)\n"
#define PM_POSSIBLEEXTPART	"Possible extended partition at offset(%qdmb)\n"
#define PM_PT_TYPE		"   type: %03d(0x%02X)(%s)"
#define PM_PT_SIZE		"   size: %qdmb #s(%012qd)"
#define PM_PT_CHS		"   chs:  (%04d/%03d/%02d)-(%04d/%03d/%02d)d"
#define PM_PT_HEX		"   hex: "
#define PM_G_PRIMARY		"primary "
#define PM_G_LOGICAL		"logical "
#define PM_G_INVALID		"invalid "
#define PM_G_ORPHANED		"orphaned "

/* error/warning messages */
#define EM_FATALERROR		"\n*** Fatal error: %s.\n"
#define EM_SIMPLEERROR		"\n** Error: %s.\n"
#define EM_WARNING		"\n* Warning: %s.\n"
#define EM_MALLOCFAILED		"malloc(%d) failed"
#define EM_IOCTLFAILED		"ioctl(%s) failed: %s"
#define EM_OPENFAIL		"open(%s): %s"
#define EM_STRANGEPTBLMAGIC	"strange partition table magic 0x%04X"
#define EM_WRONGSECTSIZE	"sector size must be > 0 and <= %d"
#define EM_FAILSSIZEATTEMPT	"failed trying to use sector size %d"	
#define EM_SEEKFAILURE		"dev(%s): seek failure"
#define EM_STATFAILURE		"stat(%s): %s"
#define EM_READERROR		"dev(%s): read error near sector(%qd)"
#define EM_CANTGETSSIZE		"cannot get sector size on dev(%s)"
#define EM_CANTGETGEOM		"cannot get disk geometry"
#define EM_MINITFAILURE		"module(%s) failed to init"
#define EM_INVVALUE		"invalid number value"
#define EM_PSTART2BIG		"partition(%s) starts beyond disk end"
#define EM_PSIZE2BIG		"partition(%s) is bigger than the disk"
#define EM_PEND2BIG		"partition(%s) ends beyond disk end"
#define EM_STRANGEPTYPE		"partition(%s) contains strange flag"
#define EM_PTBLREAD		"failed to read partition table"
#define EM_PTBLWRITE		"could not write partition table"
#define EM_MBRWRITE		"could not write master boot record"
#define EM_TOOMANYEXTP		"found more than one extended partition, skipping"
#define EM_TOOMANYLOGP		"more than %d logical partitions encountered"
#define EM_EPILLEGALOFS		"extended ptbl illegal sector offset"
#define EM_INVXPTBL		"invalid extended ptbl found at sector(%qd)"
#define EM_DISCARDOVLP		"Discarded %d overlapping partition guesses"
#define EM_TOOMANYXPTS		"more than one extended partition: %d"
#define EM_TOOMANYPPTS		"more than %d primary partitions: %d"
#define EM_OPENLOG		"cannot open logfile %s"
#define EM_NOSUCHMOD		"no such module: %s"


#endif /* _ERRMSGS_H */
