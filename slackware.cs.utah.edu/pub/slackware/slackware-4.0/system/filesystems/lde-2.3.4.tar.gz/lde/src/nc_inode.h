/*
 *  lde/nc_inode.h -- The Linux Disk Editor
 *
 *  Copyright (C) 1994  Scott D. Heavner
 *
 *  $Id: nc_inode.h,v 1.1 1994/09/06 01:24:59 sdh Exp $
 */

int inode_mode(void);
