/*
** natali/pap_status.c
** Copyright 1995, 1996, Trinity College Computing Center.
** Writen by David.Chappell.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software and documentation are provided "as is" without
** express or implied warranty.
**
** This file was last modified 5 December 1996.
*/

/*
** This file is part of an AppleTalk Library Interface compatible library
** for Netatalk. 
*/

#include "natali.h"
#include <stdlib.h>
#include <unistd.h>
#include <memory.h>
#include "appletalk.h"
#include "nbp.h"
#include "pap.h"

/*
** pap_status()
*/
int pap_status(at_nbptuple_t *tuple, unsigned char *status)
    {
    ATP atp;			/* ATP endpoint */
    struct atp_block atpb;	/* ATP transaction description block */
    struct sockaddr_at sat;	/* AppleTalk address */
    struct iovec iov;		/* receive space description */
    BYTE cbuf[8];		/* PAP command buffer */
    BYTE rbuf[ATP_MAXDATA];	/* response buffer */

    DODEBUG(("pap_status(tuple={%d:%d:%d}, *status=?)",
	(int)tuple->enu_addr.net, (int)tuple->enu_addr.node,
	(int)tuple->enu_addr.socket));

    /* Check for bad parameters. */
    if( tuple == (at_nbptuple_t*)NULL || status == (unsigned char*)NULL)
    	{
    	DODEBUG(("pap_status(): invalid parameters"));
    	pap_errno = PAPBADPARM;
    	return -1;
    	}
    
    /* Open an ATP endpoint. */
    if( (atp=atp_open(0)) == (ATP)NULL )
    	{
	DODEBUG(("pap_status(): atp_open() failed"));
	pap_errno = PAPSYSERR;
	return -1;
	}

    /* Fill in the status request packet. */
    cbuf[0] = 0;
    cbuf[1] = PAP_SendStatus;
    cbuf[2] = 0;
    cbuf[3] = 0;

    /* Fill in the destination socket address. */
    memset(&sat, 0, sizeof(struct sockaddr_at));
    sat.sat_family = AF_APPLETALK;
    sat.sat_addr.s_net = htons(tuple->enu_addr.net);
    sat.sat_addr.s_node = tuple->enu_addr.node;
    sat.sat_port = tuple->enu_addr.socket;

    /* Fill in the ATP block. */
    atpb.atp_saddr = &sat;
    atpb.atp_sreqdata = cbuf;
    atpb.atp_sreqdlen = 4;		/* size of data */
    atpb.atp_sreqto = 2;		/* retry timer */
    atpb.atp_sreqtries = 2;		/* retry count */

    /* Send the request. */
    DODEBUG(("pap_status(): sending request")); 
    if(atp_sreq(atp, &atpb, 1, ATP_XO) < 0)
	{
	DODEBUG(("pap_status(): atp_sreq() failed, errno=%d (%s)", errno, strerror(errno)));
	pap_errno = PAPSYSERR;
	atp_close(atp);		/* free the ATP endpoint */
	return -1;
	}

    /* Wait for the response: */
    {
    struct timeval select_timeout;
    int fd;
    fd_set fds;
    int selret;
    int countdown = 5;

    DODEBUG(("pap_status(): waiting for response"));

    fd = atp_fileno(atp);

    while(TRUE)
	{
	select_timeout.tv_sec = 1;
	select_timeout.tv_usec = 0;

	FD_ZERO(&fds);
	FD_SET(fd, &fds);

	if( (selret=select(fd+1, &fds, (fd_set*)NULL, (fd_set*)NULL, &select_timeout)) < 1 ) 
	    {
	    if(selret == -1)
		{
		DODEBUG(("pap_status(): select() failed, errno=%d (%s)", errno, strerror(errno)));
		pap_errno = PAPSYSERR;
		}
	    else if(--countdown < 0)
		{
		DODEBUG(("pap_open(): no response"));
		pap_errno = PAPTIMEOUT;
		}
	    else
		{
		DODEBUG(("pap_status(): calling natali_pap_maybe_resend()"));
		if(natali_pap_maybe_resend(atp) != -1)
		    continue;
		DODEBUG(("pap_status(): natali_pap_maybe_resend() failed"));
		pap_errno = PAPSYSERR;
		}

	    atp_close(atp);
	    return -1;
	    } /* if no file desciptors ready */
	break;
	}
    }

    /* Read the response. */
    iov.iov_base = rbuf;
    iov.iov_len = sizeof(rbuf);
    atpb.atp_rresiov = &iov;	/* set of buffers */
    atpb.atp_rresiovcnt = 1;	/* number of buffers */
    DODEBUG(("pap_status(): reading response"));
    if( atp_rresp(atp, &atpb) < 0 )
	{
	DODEBUG(("pap_status(): atp_rresp() failed, errno=%d (%s)", errno, strerror(errno)));
	pap_errno = PAPSYSERR;
	atp_close(atp);
	return -1;
	}

    /* We don't need this anymore. */
    atp_close(atp);

    /* Too short? */
    if(iov.iov_len < 9)
    	{
    	DODEBUG(("pap_status(): response too short"));
    	pap_errno = PAPSYSERR;
    	return -1;
    	}
    	
    /* Not a status reply? */
    if(rbuf[1] != PAP_Status)
    	{
    	DODEBUG(("pap_status(): reply is not PAP_Status"));
    	pap_errno = PAPSYSERR;
    	return -1;
    	}

    /* Bad format? */
    if(rbuf[0] != 0)
    	{
    	DODEBUG(("pap_status(): reply is corrupt"));
    	pap_errno = PAPSYSERR;
    	return -1;
    	}

    /*
    ** Well, it is not clearly invalid, that is something.
    ** Let's copy the status string.
    */
    {
    unsigned char *si, *di;
    int len;
	
    len = rbuf[8];			/* get the length */
    DODEBUG(("pap_status(): %d bytes of status: \"%.*s\"", len, len, &rbuf[9]));
    si = &rbuf[9];			/* point si to the start of the status string */
    di = status;			/* point di to the destination */
    *(di++) = len;			/* store the length */
    while(len--)			/* copy the string */
	*(di++) = *(si++);	    
    }

    return 0;
    } /* end of pap_status() */

/* end of file */
