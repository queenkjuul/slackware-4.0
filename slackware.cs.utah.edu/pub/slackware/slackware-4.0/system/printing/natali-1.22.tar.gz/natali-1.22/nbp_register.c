/*
** natali/nbp_register.c
** Copyright 1995, 1996, Trinity College Computing Center.
** Writen by David.Chappell.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software and documentation are provided "as is" without
** express or implied warranty.
**
** Last modified 13 December 1996.
*/

/*
** This file is part of an AppleTalk Library Interface compatible library
** for Netatalk. 
*/

#include "natali.h"
#include <errno.h>
#include <string.h>
#include "appletalk.h"
#include "nbp.h"

int nbp_register(at_entity_t *entity, int fd, at_retry_t *retry)
    {
    struct PAP *pap;		/* a kludge */

    char obj[NBP_NAME_MAX+1];	/* buffer for object name to look up */
    char type[NBP_NAME_MAX+1];	/* buffer for object type to look up */
    char zone[NBP_NAME_MAX+1];
    
    DODEBUG(("nbp_register()"));

    if( entity == (at_entity_t *)NULL )
    	{
	DODEBUG(("nbp_register(): invalid parameters"));
    	nbp_errno = NBPBADPARM;
    	return -1;
    	}

    if(entity->object.len > NBP_NAME_MAX || entity->type.len > NBP_NAME_MAX || entity->zone.len > NBP_NAME_MAX)
    	{
    	DODEBUG(("nbp_register(): name is bad"));
    	nbp_errno = NBPBADNAME;
    	return -1;
    	}
    
    memcpy(obj,entity->object.str,entity->object.len);
    obj[(int)entity->object.len] = (char)NULL;

    memcpy(type,entity->type.str,entity->type.len);
    type[(int)entity->type.len] = (char)NULL;

    memcpy(zone,entity->zone.str,entity->zone.len);
    zone[(int)entity->zone.len] = (char)NULL;

    /* This will work only for PAP */
    if( (pap=natali_fd_to_pap(fd)) == (struct PAP *)NULL )
    	{
	DODEBUG(("pap_read(): bad file descriptor"));
    	return -1;	/* pap_errno is already set, just return */
    	}

    DODEBUG(("nbp_register(): nbp_rgstr(sock, \"%s\", \"%s\", \"%s\")", obj, type, zone));

    if( nbp_rgstr( atp_sockaddr(pap->atp), obj, type, zone ) < 0 )
    	{
	#ifdef DEBUG
	natali_debug("errno=%d", errno);	/* compiler bug */
	natali_debug("nbp_register: nbp_rgstr() failed, errno=%d (%s)", errno, strerror(errno));
	#endif
	if( errno == EEXIST )			/* name already exists */
	    nbp_errno = NBPDUPNAME;
	else if( errno == EINVAL )		/* name component has wrong length */
	    nbp_errno = NBPBADNAME;
	else					/* other */
	    nbp_errno = NBPSYSERR;
	return -1;    	
    	}

    return 0;
    } /* end of nbp_register() */
    
/* end of file */
