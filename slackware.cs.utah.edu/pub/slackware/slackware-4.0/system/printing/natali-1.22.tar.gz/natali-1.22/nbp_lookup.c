/*
** natali/nbp_lookup.c
** Copyright 1995, 1996, 1997, Trinity College Computing Center.
** Writen by David.Chappell.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software and documentation are provided "as is" without
** express or implied warranty.
**
** Last modified 7 January 1997.
*/

/*
** This file is part of an AppleTalk Library Interface compatible library
** for Netatalk. 
*/

#include "natali.h"
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include "appletalk.h"
#include "nbp.h"

/*
** This is not called npb_lookup() because the Netatalk library
** already contains a function with that name.  We fix this
** in nbp.h with a macro.
*/
int natali_nbp_lookup(at_entity_t *entity,	/* name to look up */
		 at_nbptuple_t *buf,		/* buffer for returned data */
		 int max, 			/* slots in buffer */
		 at_retry_t *retry,		/* retry info structure */
		 u_char *more)			/* set to non-zero if more than fit in buffer */
    {
    int ddp;			/* endpoint to use when doing lookup */
    int retry_retries;		/* number of retries to do */
    int retry_interval;		/* delay between retries in seconds */
    struct sockaddr_at addr;	/* an AppleTalk socket address */
    int addr_len;
    BYTE sendbuf[200];		/* buffer in which to build the request */
    BYTE *p;			/* pointer into sendbuf[] */
    int retry_countdown;
    BYTE recbuf[600];
    int total_tuple_count = 0;	/* return value */
    
    #ifdef DEBUG
    natali_debug("nbp_lookup()");
    #endif

    /* Look for various types of bad parameter. */
    if(max < 1 || entity == (at_entity_t *)NULL 
    		|| buf == (at_nbptuple_t *)NULL || more == (u_char*)NULL )
    	{
	#ifdef DEBUG
	natali_debug("nbp_lookup(): bad parameter");
	#endif

    	nbp_errno = NBPBADPARM;
    	return -1;
    	}

    /* Look for an invalid name. */
    if(entity->object.len > NBP_NAME_MAX || entity->type.len > NBP_NAME_MAX || entity->zone.len > NBP_NAME_MAX)
    	{
    	DODEBUG(("nbp_lookup(): name is bad"));
    	nbp_errno = NBPBADNAME;
    	return -1;
    	}
    
    /* If the retry structure is not NULL, pull out the values. */
    if(retry != (at_retry_t *)NULL)
    	{
	retry_retries = retry->retries;
	retry_interval = retry->interval;
    	}
    else	/* If it is NULL, use default values. */
    	{
	retry_retries = 8;
	retry_interval = 1;
    	}

    /* Clear the more indicator.  We will set it later if necessary. */
    *more = 0;

    /* Open a DDP endpoint. */
    if( (ddp=socket(AF_APPLETALK, SOCK_DGRAM, 0)) == -1 )
    	{
	DODEBUG(("nbp_lookup(): socket() failed, errno=%d (%s)", errno, strerror(errno)));
	nbp_errno = NBPSYSERR;
	return -1;
	}

    /* Assign a socket number to the DDP endpoint: */
    memset(&addr, 0, sizeof(struct sockaddr_at));
    addr.sat_family = AF_APPLETALK;
    addr.sat_addr.s_net = ATADDR_ANYNET;
    addr.sat_addr.s_node = ATADDR_ANYNODE;
    addr.sat_port = ATADDR_ANYPORT;
    if (bind(ddp, (struct sockaddr*)&addr, sizeof(struct sockaddr_at)) == -1)
	{
	DODEBUG(("nbp_lookup(): bind() failed on DDP socket, errno=%d (%s)", errno, strerror(errno)));
	nbp_errno = NBPSYSERR;
	close(ddp);
	return -1;
	}

    /* Figure out what socket number was assigned: */
    addr_len = sizeof(struct sockaddr_at);
    if(getsockname(ddp, (struct sockaddr*)&addr, &addr_len) == -1)
    	{
    	DODEBUG(("nbp_lookup(): getsockname() failed, errno=%d (%s)", errno, strerror(errno)));
    	nbp_errno = NBPSYSERR;
	close(ddp);
    	return -1;
    	}
    	                                
    sendbuf[0] = NBP_DDP_TYPE;
    sendbuf[1] = NBP_BRRQ * 16 + 1;	/* NBP lookup, 1 tuple */
    sendbuf[2] = 0;			/* request ID */

    /* Put our address in the request packet: */
    sendbuf[3] = ntohs(addr.sat_addr.s_net) / 256;
    sendbuf[4] = ntohs(addr.sat_addr.s_net) % 256;
    sendbuf[5] = addr.sat_addr.s_node;
    sendbuf[6] = addr.sat_port;
    
    /* Fill in the enumberator, whatever that is: */
    sendbuf[7] = 0;

    /* Fill in the name to be looked up: */
    {
    int count;
    char *si;

    p = &sendbuf[8];
    count = *p++ = entity->object.len;
    for(si=entity->object.str; count; count--)
    	*p++ = *si++;
    count = *p++ = entity->type.len;
    for(si=entity->type.str; count; count--)
    	*p++ = *si++;
    count = *p++ = entity->zone.len;
    for(si=entity->zone.str; count; count--)
    	*p++ = *si++;
    }

    /* Set the address to send the request to: */
    memset(&addr, 0, sizeof(struct sockaddr_at));
    addr.sat_family = AF_APPLETALK;
    addr.sat_addr.s_net = ATADDR_ANYNET;
    addr.sat_addr.s_node = ATADDR_ANYNODE;
    addr.sat_port = NBP_PORT;

    /* Send the request and read responses, retrying it periodically */
    for(retry_countdown = retry_retries; retry_countdown > 0; retry_countdown--)
	{
	fd_set fds;
	struct timeval timeout;

	/* Send or resend the request */
	DODEBUG(("nbp_lookup(): sending request, retry %d", retry_retries - retry_countdown));
	if(sendto(ddp, sendbuf, p - sendbuf, 0, (struct sockaddr*)&addr, sizeof(struct sockaddr_at)) == -1 )
	    {
	    DODEBUG(("nbp_lookup(): sendto() failed, errno=%d (%s)", errno, strerror(errno)));
	    nbp_errno = NBPSYSERR;
	    close(ddp);
	    return -1;
	    }

	/*
	** We will keep calling select() until the full
	** retry interval is exhausted.
	*/
	timeout.tv_sec = retry_interval;
	timeout.tv_usec = 0;
	while(timeout.tv_sec || timeout.tv_usec)
	    {
	    int fd_count;
	    FD_ZERO(&fds);
	    FD_SET(ddp, &fds);

	    if( (fd_count=select(ddp+1, &fds, (fd_set *)NULL, (fd_set *)NULL, &timeout)) == -1 )
		{
	    	DODEBUG(("nbp_lookup(): select() failed, errno=%d (%s)", errno, strerror(errno)));
	    	nbp_errno = NBPSYSERR;
	    	close(ddp);
	    	return -1;
	    	}
	
	    /* If there is data to be read, */
	    if(fd_count)
	    	{
		struct sockaddr_at responding_addr;
		int received_byte_count;
		int tuple_count;
		int x, y;
		BYTE *si, *next_si;

	    	/* Receive the response: */
	    	addr_len = sizeof(struct sockaddr_at);
	    	if( (received_byte_count=recvfrom(ddp, recbuf, sizeof(recbuf), 0, (struct sockaddr*)&responding_addr, &addr_len)) == -1 )
		    {
		    DODEBUG(("nbp_lookup(): recvfrom() failed, errno=%d (%s)", errno, strerror(errno)));
		    nbp_errno = NBPSYSERR;
		    close(ddp);
		    return -1;
		    }

		if(received_byte_count < 3)
		    {
		    DODEBUG(("nbp_lookup(): response is too short to be valid (%d bytes)", received_byte_count));
		    continue;
		    }

	        if(recbuf[0] != NBP_DDP_TYPE)	/* if not NBP, */
		    {				/* continue in this timeout interval */	
		    DODEBUG(("nbp_lookup(): response is not of type NBP!  (type=%d", recbuf[0]));
		    continue;
		    }

		if(recbuf[1] / 16 != NBP_LKUP_REPLY)
		    {
		    DODEBUG(("nbp_lookup(): response is not a lookup reply!  type=%d", recbuf[1] / 16));
		    continue;
		    }

		if(recbuf[2] != 0)
		    {
		    DODEBUG(("nbp_lookup(): NBP ID is wrong (%d)!", (int)recbuf[2]));
		    continue;
		    }

		tuple_count = recbuf[1] % 16;
		DODEBUG(("nbp_lookup(): got response, tuple count %d", tuple_count));

		/* Step thru the tuples just received. */
		for(x=0, si=&recbuf[3]; x < tuple_count && total_tuple_count < max; x++, si=next_si)
		    {
		    int objlen = si[5];
		    BYTE *obj = &si[6];
		    int typelen = obj[objlen];
		    BYTE *type = &obj[objlen+1];
		    int zonelen = type[typelen];
		    BYTE *zone = &type[typelen+1];

		    next_si = &zone[zonelen];

		    DODEBUG(("objlen=%d, obj=\"%.*s\", typelen=%d, type=\"%.*s\", zonelen=%d, zone=\"%.*s\"",
		    	objlen, objlen, obj, typelen, typelen, type, zonelen, zonelen, zone));

		    /* A rouge node may pass us bad data. */
		    if(objlen > NBP_NAME_MAX || typelen > NBP_NAME_MAX || zonelen > NBP_NAME_MAX)
			{
			DODEBUG(("nbp_lookup(): tuple %d has bad length", x));
		    	continue;
		    	}

		    /* Some nodes do not know their own zone name. */
		    if(zonelen == 1 && zone[0] == '*')
		    	{
		    	zonelen = entity->zone.len;
		    	zone = entity->zone.str;
		    	} 

		    /* Search thru those already recorded. */
		    for(y=0; y < total_tuple_count; y++)
		    	{
			struct at_nbptuple_t *ptr = &buf[y];

		    	if(objlen == ptr->enu_entity.object.len
		    		&& typelen == ptr->enu_entity.type.len
		    		&& zonelen == ptr->enu_entity.zone.len
		    		&& strncmp(obj, ptr->enu_entity.object.str, objlen) == 0
		    		&& strncmp(type, ptr->enu_entity.type.str, typelen) == 0
		    		&& strncmp(zone, ptr->enu_entity.zone.str, zonelen) == 0)
		    	    {
		    	    break;
		    	    }
		    	}

		    /* If not found, */
		    if(y == total_tuple_count)
		    	{
			if(total_tuple_count == max)		/* if no more room, */
			    {					/* set the flag */
			    *more = 1;
			    }
			else					/* add it to the array */
			    {
			    struct at_nbptuple_t *ptr = &buf[total_tuple_count];
			    
			    ptr->enu_addr.net = si[0] * 256 + si[1];
			    ptr->enu_addr.node = si[2];
			    ptr->enu_addr.socket = si[3];
			    
			    ptr->enu_enum = si[4];
			    
			    ptr->enu_entity.object.len = objlen;
			    strncpy(ptr->enu_entity.object.str, obj, objlen);
			    ptr->enu_entity.type.len = typelen;
			    strncpy(ptr->enu_entity.type.str, type, typelen);
			    ptr->enu_entity.zone.len = zonelen;
			    strncpy(ptr->enu_entity.zone.str, zone, zonelen);
			    
			    total_tuple_count++;			    
			    }
		    	}
		    }

		/* If we have filled the buffer, stop. */
		if(total_tuple_count == max)
		     {
		     retry_countdown = 0;		/* no more retries */
		     break;				/* terminate this receive interval */
		     }
		} /* end of if response */
	    } /* end of retry interval loop */
	} /* end of retries loop */
    
    DODEBUG(("nbp_lookup(): done, total_tuple_count=%d", total_tuple_count));
    close(ddp);
    return total_tuple_count;
    } /* end of nbp_lookup() */
    
/* end of file */
