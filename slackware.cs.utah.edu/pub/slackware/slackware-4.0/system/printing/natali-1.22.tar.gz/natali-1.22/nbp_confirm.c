/*
** natali/pap_status.c
** Copyright 1996, Trinity College Computing Center.
** Writen by David.Chappell.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software and documentation are provided "as is" without
** express or implied warranty.
**
** This file was last modified 31 December 1996.
*/

/*
** This file is part of an AppleTalk Library Interface compatible library
** for Netatalk. 
*/

#include "natali.h"
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <memory.h>
#include <netinet/in.h>
#include "appletalk.h"
#include "nbp.h"

/*
** nbp_confirm()
*/
int nbp_confirm(at_entity_t *entity, at_inet_t *dest, at_retry_t *retry)
    {
    int retry_interval, retry_retries;
    int ddp;			/* DDP endpoint */
    struct sockaddr_at addr;
    int addr_len;
    BYTE buf[200];
    BYTE *p;
    int count;
    char *si;
    int retry_countdown;
    BYTE rbuf[200];

    if(retry == (at_retry_t*)NULL )
	{
	DODEBUG(("nbp_confirm(entity={\"%.*s\", \"%.*s\", \"%.*s\"}, dest={%d:%d:%d}, retry=NULL)",
		(int)entity->object.len, entity->object.str, (int)entity->type.len, entity->type.str, (int)entity->zone.len, entity->zone.str,
		(int)dest->net, (int)dest->node, (int)dest->socket));
	retry_interval = 1;
	retry_retries = 8;
	}
    else
	{
	DODEBUG(("nbp_confirm(entity={%.*s:%.*s:%.*s}, dest={%d:%d:%d}, retry={retries=%d:interval=%d})",
		(int)entity->object.len, entity->object.str, (int)entity->type.len, entity->type.str, (int)entity->zone.len, entity->zone.str,
		(int)dest->net, (int)dest->node, (int)dest->socket,
		(int)retry->retries, (int)retry->interval));
	retry_interval = retry->interval;
	retry_retries = retry->retries;
	}

    /* Check for bad parameters. */
    if(entity == (at_entity_t*)NULL || dest == (at_inet_t*)NULL)
    	{
    	DODEBUG(("nbp_confirm(): invalid parameters"));
    	nbp_errno = NBPBADPARM;
    	return -1;
    	}
    if(entity->object.len > NBP_NAME_MAX || entity->type.len > NBP_NAME_MAX || entity->zone.len > NBP_NAME_MAX)
    	{
    	DODEBUG(("nbp_confirm(): name is bad"));
    	nbp_errno = NBPBADNAME;
    	return -1;
    	}
    
    /* Open a DDP endpoint. */
    if( (ddp=socket(AF_APPLETALK, SOCK_DGRAM, 0)) == -1 )
    	{
	DODEBUG(("nbp_confirm(): socket() failed, errno=%d (%s)", errno, strerror(errno)));
	nbp_errno = NBPSYSERR;
	return -1;
	}

    /* Assign a socket number to the DDP endpoint: */
    memset(&addr, 0, sizeof(struct sockaddr_at));
    addr.sat_family = AF_APPLETALK;
    addr.sat_addr.s_net = ATADDR_ANYNET;
    addr.sat_addr.s_node = ATADDR_ANYNODE;
    addr.sat_port = ATADDR_ANYPORT;
    if (bind(ddp, (struct sockaddr*)&addr, sizeof(struct sockaddr_at)) == -1)
	{
	DODEBUG(("nbp_confirm(): bind() failed on DDP socket, errno=%d (%s)", errno, strerror(errno)));
	nbp_errno = NBPSYSERR;
	close(ddp);
	return -1;
	}

    /* Figure out what socket number was assigned: */
    addr_len = sizeof(struct sockaddr_at);
    if(getsockname(ddp, (struct sockaddr*)&addr, &addr_len) == -1)
    	{
    	DODEBUG(("nbp_confirm(): getsockname() failed, errno=%d (%s)", errno, strerror(errno)));
    	nbp_errno = NBPSYSERR;
	close(ddp);
    	return -1;
    	}
    	                                
    buf[0] = NBP_DDP_TYPE;
    buf[1] = NBP_LKUP * 16 + 1;	/* NBP lookup, 1 tuple */
    buf[2] = 0;			/* request ID */

    /* Put our address in the request packet: */
    buf[3] = ntohs(addr.sat_addr.s_net) / 256;
    buf[4] = ntohs(addr.sat_addr.s_net) % 256;
    buf[5] = addr.sat_addr.s_node;
    buf[6] = addr.sat_port;
    
    /* Fill in the enumberator, whatever that is: */
    buf[7] = 0;

    /* Fill in the name to be verified: */
    p = &buf[8];
    count = *p++ = entity->object.len;
    for(si=entity->object.str; count; count--)
    	*p++ = *si++;
    count = *p++ = entity->type.len;
    for(si=entity->type.str; count; count--)
    	*p++ = *si++;
    count = *p++ = entity->zone.len;
    for(si=entity->zone.str; count; count--)
    	*p++ = *si++;

    /* Set the address to send the request to: */
    memset(&addr, 0, sizeof(struct sockaddr_at));
    addr.sat_family = AF_APPLETALK;
    addr.sat_addr.s_net = htons(dest->net);
    addr.sat_addr.s_node = dest->node;
    addr.sat_port = NBP_PORT;

    /* Send the request and wait for a response, retrying it periodically */
    for(retry_countdown = retry_retries; retry_countdown; retry_countdown--)
	{
	fd_set fds;
	struct timeval timeout;

	/* Send or resend the request */
	DODEBUG(("nbp_confirm(): sending request, retry %d", retry_retries - retry_countdown));
	if(sendto(ddp, buf, p - buf, 0, (struct sockaddr*)&addr, sizeof(struct sockaddr_at)) == -1 )
	    {
	    DODEBUG(("nbp_confirm(): sendto() failed, errno=%d (%s)", errno, strerror(errno)));
	    nbp_errno = NBPSYSERR;
	    close(ddp);
	    return -1;
	    }

	timeout.tv_sec = retry_interval;
	timeout.tv_usec = 0;
	while(timeout.tv_sec || timeout.tv_usec)
	    {
	    FD_ZERO(&fds);
	    FD_SET(ddp, &fds);

	    if( (count=select(ddp+1, &fds, (fd_set *)NULL, (fd_set *)NULL, &timeout)) == -1 )
		{
	    	DODEBUG(("nbp_confirm(): select() failed, errno=%d (%s)", errno, strerror(errno)));
	    	nbp_errno = NBPSYSERR;
	    	close(ddp);
	    	return -1;
	    	}
	
	    if(count)
	    	{
	    	/* Receive the response: */
		struct sockaddr_at responding_addr;
	    	addr_len = sizeof(struct sockaddr_at);
	    	if( (count=recvfrom(ddp, rbuf, sizeof(rbuf), 0, (struct sockaddr*)&responding_addr, &addr_len)) == -1 )
		    {
		    DODEBUG(("nbp_confirm(): recvfrom() failed, errno=%d (%s)", errno, strerror(errno)));
		    nbp_errno = NBPSYSERR;
		    close(ddp);
		    return -1;
		    }

		if(count < 3)
		    {
		    DODEBUG(("nbp_confirm(): response is too short to be valid (%d bytes)", count));
		    continue;
		    }

	        if(rbuf[0] != NBP_DDP_TYPE)	/* if not NBP, */
		    {				/* continue in this timeout interval */	
		    DODEBUG(("nbp_confirm(): response is not NBP!  (type=%d", rbuf[0]));
		    continue;
		    }

		if(rbuf[1] / 16 != NBP_LKUP_REPLY)
		    {
		    DODEBUG(("nbp_confirm(): response is not a lookup reply!  type=%d", rbuf[1] / 16));
		    continue;
		    }

		if(rbuf[2] != 0)
		    {
		    DODEBUG(("nbp_confirm(): NBP ID is wrong (%d)", (int)rbuf[2]));
		    continue;
		    }

		DODEBUG(("nbp_confirm(): got response, tuple count %d, socket %d", rbuf[1] % 16, rbuf[6]));

		if((rbuf[1] % 16) != 1)
		    {
		    DODEBUG(("nbp_confirm(): Address is no longer good"));
		    nbp_errno = NBPNONAME;
		    close(ddp);
		    return -1;
		    }

		dest->socket = rbuf[6];
		return 0;
		} /* end of if response */
	    } /* end of retry interval loop */
	} /* end of retries loop */
    
    /* Timeout */
    DODEBUG(("nbp_confirm(): timeout"));
    nbp_errno = NBPNONAME;
    close(ddp);
    return -1;
    } /* end of nbp_confirm() */

/* end of file */
