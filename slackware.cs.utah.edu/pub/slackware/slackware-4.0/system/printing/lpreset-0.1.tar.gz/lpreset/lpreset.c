/* reset.c:
	this program resets the printer (on stdout)
	and waits for the busy bit in the printer status to clear

	Po Shan Cheah 4/3/1997
*/

#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/lp.h>

const char *progname;

/* show system related error and exit */

void syserror(const char *msg, ...) {
  va_list ap;
  char buf[1000];
  int save_errno = errno;

  va_start(ap, msg);
  fprintf(stderr, "%s: error: ", progname);
  vsprintf(buf, msg, ap);
  errno = save_errno;
  perror(buf);
  va_end(ap);
  exit(1);

} /* end of syserror */

int main(int argc, char *argv[]) {
  int fd = 1;

  progname = argv[0];

  /* if there is a command line argument, it is used as printer device
     to reset. otherwise, stdout will be reset. */

  if (argc >= 2) {
    fd = open(argv[1], O_RDONLY);
    if (fd < 0) 
      syserror("error opening `%s'", argv[1]);
  }

  /* the reset ioctl */

  if (ioctl(fd, LPRESET) < 0)
    syserror("ioctl LPRESET error");

  /* wait until the printer is not busy */

  for (;;) {
    int i;
    if (ioctl(fd, LPGETSTATUS, &i) < 0)
      syserror("ioctl LPGETSTATUS error");

    if (i & LP_PBUSY)
      break;
    sleep(1);
  }

  if (fd != 1)
    close(fd);
  return 0;
}
