#define	FILE_VERSION_MAJOR	3
#define	patchlevel		22

/*
 * Patchlevel file for Ian Darwin's MAGIC command.
 * $Id: patchlevel.h,v 1.1.1.1 1998/05/12 21:36:27 andreas Exp $
 *
 */

