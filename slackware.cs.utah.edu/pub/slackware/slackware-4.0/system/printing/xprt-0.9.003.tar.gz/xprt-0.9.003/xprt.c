/* xprt.c */
/*
	Support auxiliary-printers attached to terminals using mandatory
	locking to multiplex serial line

	Copyright (C) Christian Lademann <cal@zls.de> 1997
   
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
   
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
   
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/*
03.02.97:cal:Version 0.9.001
05.02.97:cal:select() nur noch zum Warten verwenden;
	Version 0.9.002
12.03.97:cal:read_tcaps(): Return-Status von setupterm() richtig behandeln;
13.03.97:cal:xprt(): Return-Status der einzelnen Calls, die OutFd verwenden, pruefen,
	um 'abgehaengtes' TTY zu erkennen; fatal() impl.; stat()-Call in set_lock() entfernt
	Version 0.9.003
*/

#include	<sys/time.h>
#include	<sys/types.h>
#include	<unistd.h>
#include	<stdio.h>
#include	<fcntl.h>
#include	<sys/stat.h>
#include	<curses.h>
#include	<term.h>
#include	<string.h>
#include	<stdlib.h>

#define	VERSION	"0.9.003"

#define MAX_BLOCKSIZE	256
#define DEF_BLOCKSIZE	256
#define	DEF_MAXCPS		300
#define	ESCSEQSIZE		64
#define	MAX_TRIES		10

#define	max(a,b)	((a) > (b) ? (a) : (b))

int		InFd = -1,
		OutFd = -1;


int
is_pipe(char *p) {
	struct stat	s;

	if(! stat(p, &s))
		return(S_ISFIFO(s.st_mode));
	else
		return(-1);
}


int
is_tty(char *p) {
	struct stat	s;

	if(! stat(p, &s))
		return(S_ISCHR(s.st_mode));
	else
		return(-1);
}


int
read_tcaps(char *type, char *prton, char *prtoff, char *prtmany) {
	char	*s;
	int		err;


	*prton = *prtoff = *prtmany = '\0';

	setupterm(type, 1, &err);
	if(err != 1)
		return(-1);

	s = tigetstr("mc5");
	if(s != (char *)-1 && s != (char *)0 && s != NULL) 
		strncpy(prton, s, ESCSEQSIZE);

	s = tigetstr("mc4");
	if(s != (char *)-1 && s != (char *)0 && s != NULL) 
		strncpy(prtoff, s, ESCSEQSIZE);

	s = tigetstr("mc5p");
	if(s != (char *)-1 && s != (char *)0 && s != NULL) 
		strncpy(prtmany, s, ESCSEQSIZE);

	if(strlen(prtmany) || strlen(prton) && strlen(prtoff))
		return(0);

	return(-1);
}


int
set_blocking(int f, int b) {
	int	of;

	if((of = fcntl(f, F_GETFL)) < 0)
		return(-1);

	return(fcntl(f, F_SETFL, b ? (of & ~O_NDELAY) : (of | O_NDELAY)));
}


int
open_pipe(char *path) {
	int	f;


	if((f = open(path, O_RDONLY)) < 0)
		return(-1);

	return(f);
}


int
open_tty(char *path) {
	int	f;


	if((f = open(path, O_WRONLY | O_APPEND | O_NOCTTY)) < 0)
		return(-1);

	return(f);
}


int
set_mandatory(int f) {
	struct stat	s;


	if(fstat(f, &s))
		return(-1);

	if((s.st_mode & S_IXGRP) || !(s.st_mode & S_ISGID))
		return(fchmod(f, (s.st_mode & ~S_IXGRP) | S_ISGID));

	return(0);
}


int
set_lock(int f, int l) {
	struct flock	fl;


	fl.l_type = l ? F_WRLCK : F_UNLCK;
	fl.l_whence = 0;
	fl.l_start = 0;
	fl.l_len = 0;
	return(fcntl(f, F_SETLKW, &fl));
}


void
usage(char *msg) {
	if(msg)
		fprintf(stderr, "%s\n", msg);

	fprintf(stderr, "usage: xprt [options]\n");
	fprintf(stderr, "options: -i pipe     named pipe to read from\n");
	fprintf(stderr, "         -o tty      device to output data to (default: stdout)\n");
	fprintf(stderr, "         -t term     terminaltype (default: $TERM)\n");
	fprintf(stderr, "         -b blksize  max. blocksize of printerdata (default: %d)\n", DEF_BLOCKSIZE);
	fprintf(stderr, "         -m maxcps   max. characters per second of printerdata (default: %d)\n", DEF_MAXCPS);
	fprintf(stderr, "         -d          don't detach and fork to background\n");
	fprintf(stderr, "         -h          this message\n");
	fprintf(stderr, "         -V          show version\n");

	exit(1);
}


void
fatal(char *msg, int e) {
	if(msg)
		fprintf(stderr, "xprt: ***FATAL: %s\n", msg);

	if(OutFd >= 0)
		set_lock(OutFd, 0);

	exit(e);
}


int
codeputc(int c) {
	char	d;

	d = c;
	return(write(OutFd, &d, 1));
}


void
xprt(char *InPath, char *OutPath,
	char *PrinterOn, char *PrinterOff, char *PrinterMany,
	int Blocksize, int MaxCps) {

	int				i, j, c = 0,
					len_PrinterOn = strlen(PrinterOn),
					len_PrinterOff = strlen(PrinterOff),
					len_PrinterMany = strlen(PrinterMany);
	time_t			n = time((time_t *)0), m = 0;
	struct fd_set	rf, ef;
	char			buffer [MAX_BLOCKSIZE], codebuf [ESCSEQSIZE];


	if((OutFd = open_tty(OutPath)) < 0)
		fatal("cannot open tty.", 1);

	if(set_mandatory(OutFd) < 0)
		fatal("cannot set mandatory locking.", 1);

	if((InFd = open_pipe(InPath)) < 0)	/* wait until sending side opens pipe */
		fatal("cannot open pipe.", 1);

	while(1) {
		if(MaxCps > 0 && c > MaxCps) {
			m = time((time_t *)0);
			sleep(max(c / MaxCps - (m - n), 0));

			c = 0;
			n = m;
		}

		FD_ZERO(&rf);
		FD_ZERO(&ef);

		FD_SET(InFd, &rf);
		FD_SET(InFd, &ef);

		if(select(256, &rf, (struct fd_set *)0, &ef, (struct timeval *)0) < 0)
			fatal("select failed.", 1);

		set_blocking(InFd, 0);
		i = read(InFd, &buffer, Blocksize);
		set_blocking(InFd, 1);

		if(i > 0) {
			if(c == 0)
				n = time((time_t *)0);

			c += i;

			j = MAX_TRIES;
			while(j--) {
				/* re-set mandatory file-locking */
				if(set_mandatory(OutFd) < 0) 
					goto write_failed;

				/* lock tty */
				if(set_lock(OutFd, 1) < 0)
					goto write_failed;

				/* set terminal to passthrough-mode */
				if(len_PrinterMany) {
					if(tputs(tparm(PrinterMany, i), 1, codeputc) < 0)
						goto write_failed;
				} else
					if(tputs(PrinterOn, 1, codeputc) < 0)
						goto write_failed;
			
				/* output print-data */
				if(write(OutFd, &buffer, i) < 0)
					goto write_failed;

				/* reset terminal to normal mode */
				if(! len_PrinterMany)
					if(tputs(PrinterOff, 1, codeputc) < 0)
						goto write_failed;

				/* unlock tty */
				if(set_lock(OutFd, 0) < 0)
					goto write_failed;

				/* break loop */
				break;

				write_failed:
					/* something went wrong: unlock and re-open tty */
					set_lock(OutFd, 0);
					close(OutFd);
					if((OutFd = open_tty(OutPath)) < 0)
						fatal("cannot reopen tty.", 1);
			}

			if(j <= 0)
				fatal("lock or write failed too often.", 1);
		} else {
			close(InFd);

			if((InFd = open_pipe(InPath)) < 0)
				fatal("cannot reopen pipe.", 1);
		}
	}
}


main(int argc, char *argv []) {
	int				MaxCps = DEF_MAXCPS,
					Blocksize = DEF_BLOCKSIZE,
					Detach = 1, c;
	char			*p, *TType = NULL, *InPath = NULL, *OutPath = NULL,
					PrinterOn [ESCSEQSIZE],
					PrinterOff [ESCSEQSIZE],
					PrinterMany [ESCSEQSIZE];
	extern char		*optarg;
	extern int		optind, opterr;


	while((c = getopt(argc, argv, "b:dhi:m:o:t:V")) != EOF)
		switch(c) {
		case 'b':	Blocksize = atoi(optarg); break;
		case 'd':	Detach = 0; break;
		case 'h':	usage(""); break;
		case 'i':	InPath = strdup(optarg); break;
		case 'm':	MaxCps = atoi(optarg); break;
		case 'o':	OutPath = strdup(optarg); break;
		case 't':	TType = strdup(optarg); break;
		case 'V':	printf("xprt version %s\n", VERSION); exit(0); break;
		default:	usage("unknown option"); break;
		}

	if(! TType)
		if((p = getenv("TERM")))
			TType = strdup(p);

	if(! OutPath)
		if((p = ttyname(1)))
			OutPath = strdup(p);

	if(! InPath || ! is_pipe(InPath))
		usage("invalid input-pipe");

	if(! OutPath || ! is_tty(OutPath))
		usage("invalid output-tty");

	if(! TType || read_tcaps(TType, PrinterOn, PrinterOff, PrinterMany) < 0)
		usage("invalid terminal-type");


	if(MaxCps < 0)
		MaxCps = DEF_MAXCPS;

	if(Blocksize < 0 || Blocksize > MAX_BLOCKSIZE)
		Blocksize = DEF_BLOCKSIZE;

	if(Detach) {
		switch(fork()) {
		case -1:
			fatal("fork failed.", 1);
			break;

		case 0:	
			setsid();
			break;

		default:
			exit(0);
			break;
		}
	}
	
	xprt(InPath, OutPath, PrinterOn,PrinterOff, PrinterMany, Blocksize, MaxCps);

	fatal("xprt() returned.", 1);
}
