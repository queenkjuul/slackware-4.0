#!/bin/sh
#
# ~ppr/src/misc_filters/troff_groff.sh
# Copyright 1995, Trinity College Computing Center.
# Written by David Chappell.
#
# Troff filter for the PPR spooling system.
# This version uses Groff
# This filter ignores the options.
#
# /usr/ppr/install/setup_filters passes this filter thru a sed
# script before installing it.
#
# Last Modified 10 February 1995.
#

# Path of Groff.
GROFF=""

# Run it on the standard intput.
$GROFF -man -Tps -etpR

# Pass on its exit value.
exit $?

# end of file


