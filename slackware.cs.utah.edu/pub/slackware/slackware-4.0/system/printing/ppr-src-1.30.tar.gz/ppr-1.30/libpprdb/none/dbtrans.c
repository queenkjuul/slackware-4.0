/*
** ~ppr/src/libpprdb/dbtrans.c
** Copyright 1995, 1996, Trinity College Computing Center.
** Written by David Chappell.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
**
** Make a printing charge to a user's database entry.
** Also, make a deposit or a correction.
**
** This file was last modified 4 October 1996.
*/

#include "global_defines.h"
#include "userdb.h"

int db_transaction(const char *username, int amount, int transaction_type)
    {     
    error("db_transaction(): user database support not compiled in");
    return USER_ERROR;
    } /* end of db_transaction() */

/* end of file */

