#!/bin/sh
#
# ~ppr/src/misc_filters/ditroff_groff.sh
# Copyright 1995, Trinity College Computing Center.
#
# Convert Ditroff output to PostScript using the Groff filter.
# This filter ignores all of the options.
#
# Before being installed, this filter is passed thru a sed script
# by /usr/ppr/install/setup_filters.
#
# Last modified 10 February 1995.
#

# The path of grops.
GROPS=""

# Execute it on the standard input.
$GROPS

# Pass on its exit value.
exit $?

# end of file

