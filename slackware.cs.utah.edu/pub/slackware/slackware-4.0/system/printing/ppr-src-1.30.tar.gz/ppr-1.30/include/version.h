#define VERSION "PPR version 1.30, 3 April 1997 (built "__DATE__", "__TIME__")."
#define COPYRIGHT "Copyright 1995, 1996, Trinity College Computing Center."
#define AUTHOR "Written by David Chappell."
#define SHORT_VERSION "1.30"
