/*
** ~ppr/src/pprdrv/pprdrv_persistent.c
** Copyright 1996, Trinity College Computing Center.
** Written by David Chappell.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
**
** Last modified 16 December 1996.
*/

#include "global_defines.h"
#include "pprdrv.h"

/*
** This is called by pprdrv_twoway.c whenever it gets a message.
** If we return TRUE, it will not go into the log file. 
*/
int persistent_query_callback(char *message)
    {
    return FALSE;
    } /* end of persistent_query_callback() */

/*
** This is called after the connexion to the printer has been
** opened.  It should review drvres[] and download anything
** it thinks should be made persistent.
*/
void persistent_download_now(void)
    {
    
    } /* end of persistent_download_now() */

/*
** This is called after the print job is done to give
** the persistent download machinery a chance to write
** an updated statistics file.
*/
void persistent_finish(void)
    {
    
    } /* end of persistent_finish() */

/* end of file */
