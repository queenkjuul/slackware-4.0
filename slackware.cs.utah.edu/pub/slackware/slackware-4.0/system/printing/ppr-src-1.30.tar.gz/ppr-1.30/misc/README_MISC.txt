31 January 1997

The PPR source directory "misc" contains a number of small programs.  Some
of these are not described in the primary documentation.

======================
fix410.ps
ttquery.ps
======================

These two PostScript files are not installed by "make install".  The first
one, fix410.ps sets a number of features of the QMS-PS 410.  For example, it
sets the optional paper tray as the default tray.  The second, ttquery.ps is
a query which the Macintosh LaserWriter driver uses to figure out how to
print TrueType fonts on a particular printer.  This file contains a
deliberate error, an undefined command at its end.  You can send this file
to a printer and wait for it to be arrested, then use "ppop log" to find out
what it printed on stdout.


======================
ppdconv.perl
======================

This Perl script can be used to generate PPD files for Macintosh LaserWriter
8 or for MS-Windows.  When run it will make two directories in the current
directory, "macos" and "mswin".  This program is not installed by "make
install".


======================
ppr2samba.c
smb.conf.sample
======================

This program and file are described in the ppr2samba(8) man page.  When you
run "make install", ppr2samba will be installed in ~ppr/bin and
smb.conf.sample will be installed in ~ppr/install.


======================
pprsync.sh
======================

This shell script can be used to syncronize the printer configurations on
two computers running PPR.  After making a change on one computer, while
logged in as "ppr", run "pprsync <othercomputer>".  This script uses rsh to
transfer the files.


======================
rqlaser.sh
======================

This script is a server which can be run from inetd.  It accepts a printer
or group name on stdin and then prints its status and queue contents.  This
script is not installed by "make install".


======================
samba_submitter.perl
pprpopup.tcl
======================

This is the preliminary version of two program to be used with computers in
public computer labs.  One piece, pprpopup.tcl, is run on a MS-Windows 95
computer.  The computer must have Tcl/Tk installed.  The second piece,
samba_submitter.perl, is run by Samba thru its "print command" configuration
file line.  These programs work in conjunction with the responder
"pprpopup" which may be found in the file "src/responders/pprpopup.perl".


======================
www.conf
wwwppop.perl
======================

This is a CGI script which makes it possible view the queue and do some
limited printer management with a WWW browser.  The configuration file
format is documented within the file.  The script file should be placed in
your cgi-bin directory.  The configuration file goes in the
PPR configuration file directory (by default "/etc/ppr").

This program may be somewhat out of date.  This means it may not work.
It also does not use the "ppop -M qquery" command which would make some
parts simpler.  It also doesn't use new browser features such as tables and
frames.  Need I go on?  Would anyone like to work on this?


======================
xppr.sh
xpprgrant.c
xpprstat.sh
======================
 
These programs are described in the xppr(1) man page.  The are installed in
~ppr/bin by "make install".


======================
fixed_cc_osf
======================

This script is a wrapper for DEC OSF/1 CC.


======================
modes-3.1.mf
======================

This is a recent version of K. Berry's definitive list of output device
descriptions (modes) for MetaFont.  It is included in the PPR distribution
for reference.  The mode names in mfmodes.conf are taken from this list.
Instructions for obtaining the lastest version are at the top of the file.


========================
customs.ppr
========================

This is a custom printer interface script for LAN Manager/X from AT&T.  It
is installed in ~ppr/install.  It may be copied into the LANMAN/X customs
directory by fixup.sh.


========================
xmessage
========================

This is a Tcl/Tk wish script which is intended to replace xmessage.  The
program xmessage is used by the xwin responder and the xwin commentator. 
Sadly, many X-Windows distributions don't include this neat little program. 
If your's is one of them, install this script as /usr/bin/X11/xmessage.  It
is not a perfect clone, but it is close enough to work for PPR.


=========================
printer_list.perl
=========================

This script prints a neat list of all the printers.

