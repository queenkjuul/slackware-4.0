#!/bin/sh
#
# Copyright 1995, Trinity College Computing Center.
# Written by David Chappell.
#
# Permission to use, copy, modify, and distribute this software and its
# documentation for any purpose and without fee is hereby granted, provided
# that the above copyright notice appear in all copies and that both that
# copyright notice and this permission notice appear in supporting
# documentation.  This software is provided "as is" without express or
# implied warranty.
#
# This program opens an xterm and displays the status of the destination 
# named in the first parameter.
#
# This file was last modified 24 February 1995.
#

xterm -title "$1's queue" \
    -e /bin/sh -c "while true
		do
		clear
		ppop status $1
		echo
		ppop list $1
		echo
		echo \"Please press control-C when you want to remove this window.\"
		sleep 5
		done"

exit 0
