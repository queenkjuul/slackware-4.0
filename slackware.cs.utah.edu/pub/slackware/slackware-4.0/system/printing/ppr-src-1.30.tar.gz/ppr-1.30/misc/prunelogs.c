/* This code fragment was removed from pprd and doesn't have a new home yet. */

    /* remove old log files */
    {					/* start a block for our variables */
    char newname[MAX_PATH];
    char fname[MAX_PATH];
    char *oldlogbase;
    DIR *dir;
    struct dirent *direntp;

    sprintf(newname,"%s.old",PPRD_LOGFILE);	/* save last logs/pprd */
    unlink(newname);				/* as logs/pprd.old */
    rename(PPRD_LOGFILE,newname);

    oldlogbase = strrchr(newname,'/');		/* find basename of newname */
    oldlogbase = oldlogbase != (char*)NULL ? oldlogbase+1 : newname;

    /* delete all other log files */
    if( (dir=opendir(LOGDIR)) != (DIR*)NULL )
    	{
    	while( (direntp=readdir(dir)) != (struct dirent*)NULL )
    	    {
	    if(direntp->d_name[0]=='.')			/* don't delete ., .. and hidden files */
	    	continue;
	    if(strcmp(direntp->d_name,oldlogbase)==0)	/* don't delete the old log file */
	    	continue;
	    if(strcmp(direntp->d_name,PRINTLOG)==0)	/* don't delete the printlog */
	    	continue;
	    
	    sprintf(fname,"%s/%s",LOGDIR,direntp->d_name);	/* construct as full a path as we need */
	    unlink(fname);    	    				/* erase the file */
    	    }
	closedir(dir);
    	}
    }

