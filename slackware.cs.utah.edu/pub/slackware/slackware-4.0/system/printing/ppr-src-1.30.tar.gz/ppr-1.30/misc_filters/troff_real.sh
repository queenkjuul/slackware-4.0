#!/bin/sh
#
# ~ppr/src/misc_filters/troff_real.sh
# Copyright 1995, Trinity College Computing Center.
# Written by David Chappell.
#
# Troff filter for the PPR spooling system.
#
# This version uses the Ditroff supplied with System V release 4
# and then passes the file through "lib/filter_ditroff".
#
# This program will have to be modified if your system uses a very
# old troff which emmits CAT/4 code.  In that case, you will have to
# change "lib/filter_ditroff" to "lib/filter_cat4" and create a 
# working "lib/filter_cat4".
#
# Last Modified 8 March 1995.
#

# The paths to the programs.
TBL=""
REFER=""
EQN=""
PIC=""
TROFF=""

# Execute the whole lot
$TBL | $REFER | $EQN | $PIC | $TROFF -man | lib/filter_ditroff

# Pass on the exit value of that wopping pipeline.
exit $?

# end of file

