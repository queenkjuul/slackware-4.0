#!/bin/sh
#
# ~ppr/src/misc_filters/ditroff_real.sh
# Copyright 1995, Trinity College Computing Center.
#
# Convert Ditroff output to PostScript using the System V Ditroff filters.
#
# Last modified 10 February 1995.
#

/usr/lib/lp/postscript/dpost | /usr/lib/lp/postscript/postreverse -r

exit $?

# end of file
