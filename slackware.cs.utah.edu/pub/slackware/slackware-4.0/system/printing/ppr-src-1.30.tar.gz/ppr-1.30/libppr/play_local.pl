#
# libppr/play_local.pl
# Copyright 1996, Trinity College Computing Center.
# Written by David Chappell.
#
# Permission to use, copy, modify, and distribute this software and its
# documentation for any purpose and without fee is hereby granted, provided
# that the above copyright notice appear in all copies and that both that
# copyright notice and this permission notice appear in supporting
# documentation.  This software and documentation are provided "as is" without
# express or implied warranty.
#
# This file was last modified 2 December 1996.
# 

#
# Play the indicated file on the nearest loudspeaker.
#
sub local_play_au
  {
  my ($address, $file) = @_;;

  if($DEBUG) { print "Playing \"$file\" on device \"$address\"\n"; }

  # Linux with Sox:
  system("/usr/local/bin/play $file");

  # Solaris:
  #system("/usr/bin/audioplay -d $address $file");

  # DEC OSF/1:
  #system("/usr/bin/mme/audioplay -filename $file");

  }

1;
