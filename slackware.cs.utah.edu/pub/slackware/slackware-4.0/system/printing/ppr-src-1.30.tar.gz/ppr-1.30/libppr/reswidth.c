/*
** ~ppr/src/libppr/reswidth.c
** Copyright 1995, 1996, Trinity College Computing Center.
** Written by David Chappell.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
**
** Return the maximum line length for a specified responder.  If we don't know,
** we return 0.  The number returned by this routine is passed to rewrap_string().
** If this routine returns 0, rewrap_string() does nothing, leaving the default line
** breaks in place.
**
** Last modified 3 June 1996.
*/

#include "global_defines.h"

int get_responder_width(const char *name)
    {
    if( strcmp(name, "samba") == 0 )
    	return 58;

    if( strcmp(name, "samba_mail") == 0 )
    	return 58;

    return 0;		/* others get default */
    } /* end of get_responder_width() */

/* end of file */
