This directory contains preliminary code for a wrapper program which can be
used as a substitute for lp in cases where an application program wants to
invoke lp.  Likely there will soon be a fake lpr here as well.

Suggestions on the design of there programs would be very welcome.  Write
to:

David.Chappell@mail.trincoll.edu



