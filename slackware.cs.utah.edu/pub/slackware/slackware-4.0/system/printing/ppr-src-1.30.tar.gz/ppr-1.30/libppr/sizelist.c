/*
** ~ppr/src/libppr/sizelist.c
** Copyright 1995, Trinity College Computing Center.
** Written by David Chappell.
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation.  This software is provided "as is" without express or
** implied warranty.
**
** Last modified 11 September 1995.
*/

#include "global_defines.h"
#include "global_structs.h"

struct PAGESIZE page_sizes[] =
	{
	{ "A0", 2384, 1189 },
	{ "A1", 1684, 2384 },
	{ "A2", 1191, 1684 },
	{ "A3",  842, 1191 },
	{ "A4",  595,  842 },
	{ "A5",  420,  595 },
	{ "A6",  297,  420 },
	{ "A7",  210,  297 },
	{ "A8",  148,  210 },
	{ "A9",  105,  148 },
	{ "A10",  73,  105 },
	{ "A4Small", 595, 842 },

	{ "B0", 2920, 4127 },
	{ "B1", 2064, 2920 },
	{ "B2", 1460, 2064 },
	{ "B3", 1032, 1460 },
	{ "B4",  728, 1032 },
	{ "B5",  516,  729 },
	{ "B6",  363,  516 },
	{ "B7",  258,  363 },
	{ "B8",  181,  258 },
	{ "B9",  127,  181 },
	{ "B10",  91,  127 },

	{ "C0", 2599, 3676 },
	{ "C1", 1837, 2599 },
	{ "C2", 1298, 1837 },
	{ "C3",  918, 1296 },
	{ "C4",  649,  918 },
	{ "C5",  459,  649 },
	{ "C6",  323,  459 },
	{ "C7",  230,  323 },

	{ "Comm10", 297, 684 },
	{ "DL", 312, 624 },
	{ "Executive", 522, 756 },	/* one possible definition */
	{ "Folio", 595, 936 },

	{ "ISOB0", 2835, 4008 },
	{ "ISOB1", 2004, 2835 },
	{ "ISOB2", 1417, 2004 },
	{ "ISOB3", 1001, 1417 },
	{ "ISOB4",  709, 1001 },
	{ "ISOB5",  499,  709 },
	{ "ISOB6",  354,  499 },
	{ "ISOB7",  249,  354 },
	{ "ISOB8",  176,  249 },
	{ "ISOB9",  125,  176 },
	{ "ISOB10",  88,  125 },

	{ "Letter", 612, 792 },
	{ "Legal", 612, 1008 },
	{ "Ledger", 1224, 792 },
	{ "LetterSmall", 612, 792 },
	{ "Monarch", 279, 540 },
	{ "Quarto", 567, 744 },
	{ "Statement", 396, 612 },
	{ "Tabloid", 792, 1224 },
	{ "10x13", 720, 936 },
	{ "10x14", 720, 1008 },
	{ "7x9", 504, 648 },
	{ "9x11", 648, 792 },
	{ "9x12", 648, 864} ,
	{ (char*)NULL, 0, 0}
	};

/* end of file */
