This directory contains the remote printing daemon.  At least, it will some
day.  Now, it just contains a few fragments of code.
