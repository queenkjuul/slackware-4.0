/*
** ~ppr/src/include/cap_proto.h
** No copyright claimed.
**
** Function prototypes for the CAP libraries.
**
** Last revised 2 August 1995.
*/

/* I am not sure all the return types are correct. */
int abInit(int debug_flag);
int nbpInit(void);
int PAPInit(void);
int PAPOpen(int *cno, const char *lwname, int quantum, PAPStatusRec *status, OSErr *compstate);
int PAPRead(int cno, char *buff, int *datasize, int *eof, OSErr *compstate);
int PAPWrite(int cno, char *buff, int datasize, int eof, OSErr *compstate);
int abSleep(int duration, int waitflag);
int PAPClose(int cno);
int SLInit(int *cno, char *printername, int quantum, PAPStatusRec *status);
int GetNextJob(int srefnum, int *refnum, OSErr *compstate);
int SLClose(int cno);
int PAPShutdown(int cno);
int PAPRemName(int cno, char *name);
int PAPUnload(void);
int PAPGetNetworkInfo(int cno, AddrBlock *addr);
int PAPStatus(const char *address, PAPStatusRec *status, AddrBlock *addr);
PAPSOCKET *cnotopapskt(int cno);

/* end of file */
