#!/bin/sh
#
# ~ppr/src/misc_filters/fig.sh
# Copyright 1997, Trinity College Computing Center
# Written by David Chappell.
#
# Permission to use, copy, modify, and distribute this software and its
# documentation for any purpose and without fee is hereby granted, provided
# that the above copyright notice appear in all copies and that both that
# copyright notice and this permission notice appear in supporting
# documentation.  This software is provided "as is" without express or
# implied warranty.
#
# Last modified 26 Febuary 1997.
#

# Paths of the filter.  This is filled
# in when the filter is installed.
FIG2DEV="?"

# Run it:
$FIG2DEV -L ps | sed -e 's/^%%Pages: 0$/%%Pages: 1/' -e '/^%%Title:/ d'
rval=$?

# Add the missing showpage.
echo "showpage"

# Pass on the exit value of the filter.
exit $rval

# end of file
