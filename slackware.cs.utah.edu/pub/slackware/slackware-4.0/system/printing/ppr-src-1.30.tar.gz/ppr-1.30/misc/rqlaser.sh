#!/bin/sh
#
# ~ppr/src/misc/rqlaser.sh
#
# This is a server to work with inetd to fulfill requests
# from the program Todd got.
#

read Printer
/usr/ppr/bin/ppop status $Printer

echo
/usr/ppr/bin/ppop list $Printer

exit 0
