#!/bin/sh

# Test the lp filter's placement of gutters

ls -l /usr/bin | head -100 >/tmp/x$$

echo "duplex=undef" | cat - /tmp/x$$ | ppr -o 'duplex=undef gutter=1.0 orientation=portrait'
echo "duplex=none" | cat - /tmp/x$$ | ppr -o 'duplex=none gutter=1.0 orientation=portrait'
echo "duplex=notumble" | cat - /tmp/x$$ | ppr -o 'duplex=notumble gutter=1.0 orientation=portrait'
echo "duplex=tumble" | cat - /tmp/x$$ | ppr -o 'duplex=tumble gutter=1.0 orientation=portrait'
echo "duplex=undef" | cat - /tmp/x$$ | ppr -o 'duplex=undef gutter=1.0 orientation=landscape'
echo "duplex=none" | cat - /tmp/x$$ | ppr -o 'duplex=none gutter=1.0 orientation=landscape'
echo "duplex=notumble" | cat - /tmp/x$$ | ppr -o 'duplex=notumble gutter=1.0 orientation=landscape'
echo "duplex=tumble" | cat - /tmp/x$$ | ppr -o 'duplex=tumble gutter=1.0 orientation=landscape'

rm /tmp/x$$

exit 0
