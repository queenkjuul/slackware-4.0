#!/bin/sh
#
# ~ppr/src/installprogs/make_bindist
# Copyright 1995, Trinity College Computing Center.
# Written by David Chappell.
#
# Permission to use, copy, modify, and distribute this software and its
# documentation for any purpose and without fee is hereby granted, provided
# that the above copyright notice appear in all copies and that both that
# copyright notice and this permission notice appear in supporting
# documentation.  This software is provided "as is" without express or
# implied warranty.
#
# Script to pack the binary distribution into a compressed cpio archive.
#
# This file was last modified 15 September 1995.
#

echo "/usr/ppr" >/tmp/ppr.list
echo "/var/spool/ppr">>/tmp/ppr.list
echo "/var/spool/ppr/alerts" >>/tmp/ppr.list
echo "/var/spool/ppr/logs" >>/tmp/ppr.list
echo "/var/spool/ppr/jobs" >>/tmp/ppr.list
echo "/var/spool/ppr/queue" >>/tmp/ppr.list
echo "/var/spool/ppr/pprclipr" >>/tmp/ppr.list
echo "/var/spool/ppr/dvips" >>/tmp/ppr.list
echo "/etc/ppr" >>/tmp/ppr.list
echo "/etc/ppr/mounted" >>/tmp/ppr.list
echo "/etc/ppr/printers" >>/tmp/ppr.list
echo "/etc/ppr/groups" >>/tmp/ppr.list
echo "/etc/ppr/media" >>/tmp/ppr.list
echo "/etc/ppr/fontsub" >>/tmp/ppr.list
echo "/etc/ppr/mfmodes" >>/tmp/ppr.list
find /usr/ppr/bin -print >>/tmp/ppr.list
find /usr/ppr/lib -print >>/tmp/ppr.list
find /usr/ppr/interfaces -print >>/tmp/ppr.list
find /usr/ppr/responders -print >>/tmp/ppr.list
find /usr/ppr/commentators -print >>/tmp/ppr.list
find /usr/ppr/install -print >>/tmp/ppr.list
find /usr/ppr/cache -print >>/tmp/ppr.list
find /var/spool/ppr/cache -print\
    | grep -v '^/var/spool/ppr/cache/[^/]*/.*' >>/tmp/ppr.list
find /usr/ppr/PPDFiles -print >>/tmp/ppr.list

# cat /tmp/ppr.list | cpio -o -H crc | compress >../../ppr-bin.cpio.Z
cat /tmp/ppr.list | cpio -o -H crc | gzip -9 >../../ppr-bin.cpio.gz

rm /tmp/ppr.list

exit 0
