/*
 	Project: Klpc - a GUI for LPRNG 
	Author:	Dietmar Kling <dietmar.kling@usa.net>

	This project is released under GPL
*/

#include <stdio.h>
#include "mainDlg.h"
#include "mainDlg.moc"
#include <qapp.h>
#include <kapp.h>


KApplication *TemplateApplication;


/*
 * 
 */

int
main(int argc, char **argv)
{
	TemplateApplication 	   = new KApplication (argc,argv);
	mainDlg *TemplateWidget = new mainDlg;
	
	TemplateApplication->setMainWidget(TemplateWidget);
	TemplateWidget->show();
	TemplateApplication->exec();

	//delete TemplateWidget;
	//delete TemplateApplication;
	
	return 0;
}
