/* xpGED -- an xwGUI Editor Programm
 * Copyright (C) 1999 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include <forms.h>

#include <fcntl.h>
#include <string.h>

#include <iostream.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h> /* GetEnv */
#include <time.h>
#include <ctype.h>

#include "xwged.h"

/* Stringverarbeitung */
const char *LStr(char *source,int a);
const char *RStr(char *source,int a);
const char *strMids(char *source,int a,int b);

const char *GR(char *resource,char *defStr);
void main_gui(void);
void actTable(int a);

void pref_gui(void);

const char *DoubleStr(float a);
const char *IntStr(int a);
const char *strMids(char *source,int a,int b);
const char *strInsert(char *source1,int a, char *source2);
const char *strDiffTime(long a,long b);
const char *strDiff(long aa);
const char *strDate(char *source,int year);

/* Mainform */
struct mainform mf;

/* Prefdaten */
extern struct prefs pf;

/* String Vars */
extern const char *strptr;
extern char astr[256],bstr[256],cstr[256];

const char *GR(char *resource,char *defStr)
{
  static char       val[256];
  char              className[256];
  
  strcpy(className,"xwged.");
  strcat(className,resource);
 
  fl_get_resource(resource,className,FL_STRING,defStr,&val,256);

  return(val);
}

/* Main-Window GUI Layout */ 
void main_gui(void)
{
  char       astr[90];
  const char *strdef;

  /* 800 480 */
  mf.form = fl_bgn_form(FL_UP_BOX,800,580); 

   fl_set_border_width(2);

   mf.quit = fl_add_button(FL_NORMAL_BUTTON,526,415,100,20,"Beenden");
   fl_set_object_color(mf.quit,FL_INDIANRED,FL_TOMATO);

   mf.frameA = fl_add_frame(FL_DOWN_FRAME,10,10,500,530,"");

   mf.gui = fl_add_choice(FL_DROPLIST_CHOICE,15,15,400,20,"");
   fl_set_object_boxtype(mf.gui,FL_DOWN_BOX);
   fl_addto_choice(mf.gui,"1. Oberfl�che");
   fl_addto_choice(mf.gui,"2. Oberfl�che");
   fl_addto_choice(mf.gui,"3. Oberfl�che");

   mf.test = fl_add_button(FL_NORMAL_BUTTON,415,15,90,20,"Test");

   mf.frameB = fl_add_frame(FL_DOWN_FRAME,17,37,486,496,"");

   mf.guiname = fl_add_input(FL_NORMAL_INPUT,110,42,388,20,"Oberfl�chen Name:");

   /* Tabellen umschalter */
   mf.colA = fl_add_button(FL_NORMAL_BUTTON,22,67,158,20,"Spalte 1");
   mf.colB = fl_add_button(FL_NORMAL_BUTTON,180,67,160,20,"Spalte 2");
   mf.colC = fl_add_button(FL_NORMAL_BUTTON,340,67,158,20,"Spalte 3");

   /* Browser Tabellen */
   mf.tabA = fl_add_browser(FL_HOLD_BROWSER,22,87,158,251,"");
   mf.tabB = fl_add_browser(FL_HOLD_BROWSER,180,87,160,251,"");
   mf.tabC = fl_add_browser(FL_HOLD_BROWSER,340,87,158,251,"");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabB,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabB,"Dies ist ein Demo");

   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");

   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");
   fl_addto_browser(mf.tabA,"Dies ist ein Demo");

   actTable(pf.actTab);

   /* Eintrag entfernen */
   mf.delA = fl_add_button(FL_NORMAL_BUTTON,24,338,114,20,"Entfernen");
   mf.delB = fl_add_button(FL_NORMAL_BUTTON,182,338,116,20,"Entfernen");
   mf.delC = fl_add_button(FL_NORMAL_BUTTON,342,338,114,20,"Entfernen");

   /* ganz zum anfang */
   mf.downA = fl_add_button(FL_TOUCH_BUTTON,138,338,20,20,"@2>");
   mf.downB = fl_add_button(FL_TOUCH_BUTTON,298,338,20,20,"@2>");
   mf.downC = fl_add_button(FL_TOUCH_BUTTON,456,338,20,20,"@2>");

   /* ganz zum ende */
   mf.upA = fl_add_button(FL_TOUCH_BUTTON,158,338,20,20,"@8>");
   mf.upB = fl_add_button(FL_TOUCH_BUTTON,318,338,20,20,"@8>");
   mf.upC = fl_add_button(FL_TOUCH_BUTTON,476,338,20,20,"@8>");

   /* Parameter Panel */
   mf.frameC =  fl_add_frame(FL_DOWN_FRAME,24,363,472,165,"");

   /* Drucker Auswahl 622 168 */
   mf.frameD = fl_add_frame(FL_DOWN_FRAME,519,10,271,391,"");

   /* Steuerleiste */
   mf.frameE = fl_add_frame(FL_DOWN_FRAME,519,410,271,30,"");

  fl_end_form();
  return;
}

void actTable(int a)
{
  if (a == 0)
    {
      fl_set_object_color(mf.tabA,FL_MCOL,FL_LEFT_BCOL);
    }
  else
    {
      fl_set_object_color(mf.tabA,FL_COL1,FL_LEFT_BCOL);
    }
  if (a == 1)
    {
      fl_set_object_color(mf.tabB,FL_MCOL,FL_LEFT_BCOL);
    }
  else
    {
      fl_set_object_color(mf.tabB,FL_COL1,FL_LEFT_BCOL);
    }
  if (a == 2)
    {
      fl_set_object_color(mf.tabC,FL_MCOL,FL_LEFT_BCOL);
    }
  else
    {
      fl_set_object_color(mf.tabC,FL_COL1,FL_LEFT_BCOL);
    }

  return;
}
