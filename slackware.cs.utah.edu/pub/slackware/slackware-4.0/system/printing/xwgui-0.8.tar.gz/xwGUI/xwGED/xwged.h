/* xpGED -- an xwGUI Editor Programm
 * Copyright (C) 1999 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include <forms.h>

#ifndef _XWGED_H
#define _XWGED_H

/* String Definitions */
#define xwged  "xwGED V0.1 - � 1999 by Stefan Kraus - License: GPL"
#define xwgedl_Info "xwGED V0.1"

/* ###################################
   # Pref Datas                      #
   ################################### */
typedef struct prefs 
{
  int            actTab;

 
} prefs;

/* ###################################
   # Mainform Datas - 1.st Window    #
   ################################### */
typedef struct mainform
{
/* Main-Form data */
  FL_FORM         *form;
  /* Event Loop */
  FL_OBJECT       *obj;
  int             ready;

  FL_OBJECT       *quit;

  FL_OBJECT       *frameA;
  FL_OBJECT       *gui;
  FL_OBJECT       *test;

  FL_OBJECT       *frameB;

  FL_OBJECT       *guiname;

  FL_OBJECT       *colA,*colB,*colC;
  FL_OBJECT       *tabA,*tabB,*tabC;
  
  FL_OBJECT       *delA,*delB,*delC;
  FL_OBJECT       *downA,*downB,*downC;
  FL_OBJECT       *upA,*upB,*upC;

  FL_OBJECT       *frameC,*frameD,*frameE;


} mainform;



#endif
