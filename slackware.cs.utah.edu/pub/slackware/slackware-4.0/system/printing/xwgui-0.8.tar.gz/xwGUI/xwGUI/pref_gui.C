/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include <forms.h>

#include <fcntl.h>
#include <string.h>

#include <iostream.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h> /* GetEnv */
#include <time.h>
#include <ctype.h>

#include "xwgui.h"


/* Page Datas */
extern struct pagedata pdata;

/* Mainform */
extern struct mainform mf;

/* Printerform */
extern struct prtform prtf; 

/* PrefPanelform */
extern struct prefform preff;

/* Printer General Settings */
extern struct XWGprint xwgp;

/* actual Parser Line */
extern char pstr[1024],partstr[256];

/* HomeDirectory */
extern char xpuser[1024];

/* String Vars */
extern const char *strptr;
extern char astr[256],bstr[256],cstr[256];

void setpref(void)
{
  int a,b;

  /* Clear Choice Widgets */
  b = fl_get_choice_maxitems(mf.XWQuality);
  if (b>0)
    {
      fl_clear_choice(mf.XWQuality);
    }
  b = fl_get_choice_maxitems(mf.XWSheets);
  if (b>0)
    {
      fl_clear_choice(mf.XWSheets);
    }

  /* Set Choice Widgets */
  if (xwgp.anzQuality>0)
    {
      for (a=1 ; a<=xwgp.anzQuality ; a++)
	{	
	  b = fl_addto_choice(mf.XWQuality,xwgp.quality[a]);
	}
      fl_set_choice(mf.XWQuality,xwgp.actQuality);
    }
  else
    {
      b = fl_addto_choice(mf.XWQuality,"---");
    }
 
  if (xwgp.anzPaper[xwgp.actQuality]>0)
    {
      for (a=1 ; a<=xwgp.anzPaper[xwgp.actQuality] ; a++)
	{
	  b = fl_addto_choice(mf.XWSheets,xwgp.paper[xwgp.actQuality][a]);
	}
      fl_set_choice(mf.XWSheets,xwgp.actPaper);
    }
  else
    {
      b = fl_addto_choice(mf.XWSheets,"---");
    }

  /* Set Pref Menu */
  fl_set_object_label(mf.XWPrefA,"");
  fl_set_object_label(mf.XWPrefB,"");
  fl_set_object_label(mf.XWPrefC,"");
  if (xwgp.anzform==1)
    {
       fl_set_object_label(mf.XWPrefA,xwgp.formName[1]);
    }
  if (xwgp.anzform==2)
    {
       fl_set_object_label(mf.XWPrefA,xwgp.formName[1]);
       fl_set_object_label(mf.XWPrefB,xwgp.formName[2]);
    }
  if (xwgp.anzform==3)
    {
       fl_set_object_label(mf.XWPrefA,xwgp.formName[1]);
       fl_set_object_label(mf.XWPrefB,xwgp.formName[2]);
       fl_set_object_label(mf.XWPrefC,xwgp.formName[3]);
    }
  return;
}

void setForm(int a) 
{
  int pid;
  int b,c,d;
  int e,f;
  char aas[256];
  /* Browser Input Flag / -1 - Normal Input / >-1 - Edit Input */
  int flag=-1; 

  if (a<=xwgp.anzform)
    {

      /* Save Vars */
      setPrtSet("","");

      xwgp.form = fl_bgn_form(FL_UP_BOX,xwgp.x[a],xwgp.y[a]+34); 
      fl_set_border_width(2);

      xwgp.frameB = fl_add_frame(FL_DOWN_FRAME,7,xwgp.y[a],xwgp.x[a]-14,27,"");      
      xwgp.Exit = fl_add_button(FL_NORMAL_BUTTON,int((xwgp.x[a]-100)/2),xwgp.y[a]+3,100,20,GR("exit_PB.str","OK"));
      fl_set_button_shortcut(xwgp.Exit,GR("exit_PB.sc","^O^o"),true);

      for (b=1 ; b<=xwgp.anzObj[a] ; b++)
	{
	  /* cout << b << " - " << xwgp.widget[a][b] << "\n"; */

      	  /* Choice */
	  if (xwgp.widget[a][b] == 0)
	    {
	      if (xwgp.objName[a][b] != NULL)
		{
		  xwgp.obja[b] = fl_add_choice(FL_DROPLIST_CHOICE,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],xwgp.objName[a][b]);
		}
	      else
		{
		  xwgp.obja[b] = fl_add_choice(FL_DROPLIST_CHOICE,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
		}
	      fl_set_object_boxtype(xwgp.obja[b],FL_DOWN_BOX);

	      strcpy(pstr,xwgp.formData[a][b]);
	      if (strlen(pstr)>0)
		{
		  while ( strlen(pstr) > 0 )
		    {
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      fl_addto_choice(xwgp.obja[b],partstr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		    }
		}

	      /* Set Vars */
	      if (xwgp.formVar[a][b] != NULL)
		{
		  strptr = getVar("","",xwgp.formVar[a][b]);
		  strcpy(aas,strptr);
		  if (xwgp.formResult[a][b] != NULL)
		    {
		      strcpy(pstr,xwgp.formResult[a][b]);
		      /* Search String */
		      c=0;
		      d=0;
		      if (strlen(pstr)>0)
			{
			  while ( strlen(pstr) > 0 )
			    {
			      strptr = strGetParm(pstr);
			      strcpy(partstr,strptr);
			      c++;
			      strptr = strDelParm(pstr);
			      strcpy(pstr,strptr);
			      if (strcmp(partstr,aas) == 0)
				{
				  d=c;
				}
			    }
			  if (d>0)
			    {
			      fl_set_choice(xwgp.obja[b],d);
			    }
			}
		    }
		}
	    }

	  /* Boolean */
	  if (xwgp.widget[a][b] == 1)
	    {
	      if (xwgp.objName[a][b] != NULL)
		{
		  xwgp.obja[b] = fl_add_lightbutton(FL_PUSH_BUTTON,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],xwgp.objName[a][b]);
  		}
	      else
		{
		  xwgp.obja[b] = fl_add_lightbutton(FL_PUSH_BUTTON,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
		}

	      /* Set Vars */
	      strptr = getVar("","",xwgp.formVar[a][b]);
	      strcpy(aas,strptr);
	      if (strlen(aas)>0)
		{
		  fl_set_button(xwgp.obja[b],1);
		}
	      else
		{
		  fl_set_button(xwgp.obja[b],0);
		}

	      /* Gadget Sperre */
	      if (xwgp.formData[a][b] != NULL)  
		{
		  if (int(strlen(xwgp.formData[a][b]))>0) 
		    {
		      /* Sperre anbringen */
		      strcpy(pstr,xwgp.formData[a][b]);
		      /* Search String */
		      if (strlen(pstr)>0)
			{
			  while ( strlen(pstr) > 0 )
			    {
			      strptr = strGetParm(pstr);
			      strcpy(partstr,strptr);
			      strptr = strDelParm(pstr);
			      strcpy(pstr,strptr);
			      if (int(strlen(partstr)) > 0)
				{
				  strNewUpper(partstr);
				  
				  for (c=1 ; c<=xwgp.anzObj[a] ; c++)
				    {
				      if (xwgp.formVar[a][c] != NULL)
					{
					  if (strcmp(xwgp.formVar[a][c],partstr) == 0)
					    {
					      strptr = getVar("","",xwgp.formVar[a][b]);
					      strcpy(aas,strptr);
					      if (strlen(aas)==0)
						{
						  if (xwgp.obja[c] == NULL)
						    {
						      strcpy(astr,"Obejct Error !!!");
						      strcpy(bstr,"Object must defined before this boolean Object !!!");
						      strcpy(cstr,"( ");
						      strcat(cstr,partstr);
						      strcat(cstr," before ");
						      strcat(cstr,xwgp.formVar[a][b]);
						      strcat(cstr," [VARNAMES] )");
						      fl_end_form();
						      fl_show_alert(astr,bstr,cstr,1);
						      allfree(1);
						      fl_hide_alert();
						      exit(0);
						    }
						  else
						    {
						      fl_hide_object(xwgp.obja[c]);
						      /* IBROWSER */
						      if (xwgp.widget[a][c]==3)
							{
							  fl_hide_object(xwgp.objb[c]);
							  fl_hide_object(xwgp.objc[c]);
							}
						    }
						}
					      else
						{
						  fl_show_object(xwgp.obja[c]);
						  /* IBROWSER */
						  if (xwgp.widget[a][c]==3)
						    {
						      fl_show_object(xwgp.objb[c]);
						      fl_show_object(xwgp.objc[c]);
						    }
						}
					    }
					}
				    }
				}
			    }
			}
		    }
		}

	    }

	  /* Browser */
	  if (xwgp.widget[a][b] == 2)
	    {
	      if (xwgp.objName[a][b] != NULL)
		{
		  xwgp.obja[b] = fl_add_browser(FL_HOLD_BROWSER,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],xwgp.objName[a][b]);
		}
	      else
		{
		  xwgp.obja[b] = fl_add_browser(FL_HOLD_BROWSER,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
		}
	      fl_set_browser_fontstyle(xwgp.obja[b],FL_FIXED_STYLE);
	      fl_set_object_lalign(xwgp.obja[b],FL_ALIGN_TOP);

	      strcpy(pstr,xwgp.formData[a][b]);
	      if (strlen(pstr)>0)
		{
		  while ( strlen(pstr) > 0 )
		    {
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      fl_addto_browser(xwgp.obja[b],partstr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		    }
		}

	      /* Set Vars */
	      strptr = getVar("","",xwgp.formVar[a][b]);
	      strcpy(aas,strptr);
	      strcpy(pstr,xwgp.formResult[a][b]);
	      /* Search String */
	      c=0;
	      d=0;
	      if (strlen(pstr)>0)
		{
		  while ( strlen(pstr) > 0 )
		    {
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      c++;
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strcmp(partstr,aas) == 0)
			{
			  d=c;
			}
		    }
		  if (d>0)
		    {
		      fl_select_browser_line(xwgp.obja[b],d);
		    }
		}
	    }

	  /* IBrowser */
	  if (xwgp.widget[a][b] == 3)
	    {
	      if (xwgp.objName[a][b] != NULL)
		{
		  /* FL_MULTI_BROWSER */
		  xwgp.obja[b] = fl_add_browser(FL_HOLD_BROWSER,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b]-20,xwgp.objName[a][b]);
		}
	      else
		{
		  xwgp.obja[b] = fl_add_browser(FL_HOLD_BROWSER,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b]-20,"");
		}
	      fl_set_browser_fontstyle(xwgp.obja[b],FL_FIXED_STYLE);
	      fl_set_object_lalign(xwgp.obja[b],FL_ALIGN_TOP);

	      /* Variable auslesen */
	      strptr = getVar("","",xwgp.formVar[a][b]);
	      strcpy(pstr,strptr);
	      /* Counter */
	      if (xwgp.mode[a][b] == 1)
		{
		  d=1;
		  strptr = strMids(pstr,1,1);
		  strcpy(aas,strptr);
		  while ( (strcmp(aas," ") != 0) & (d < int(strlen(pstr))) )
		    {
		      d++;
		      strptr = strMids(pstr,d,1);
		      strcpy(aas,strptr);
		    }
		  if (d>0)
		    {
		      strptr=strMids(pstr,d,(strlen(pstr)-d)+1);
		      strcpy(pstr,strptr);
		      strNewTrim(pstr);
		    }

		}
	      if (strlen(pstr)>0)
		{
		  while ( strlen(pstr) > 0 )
		    {
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      fl_addto_browser(xwgp.obja[b],partstr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		    }
		}

	      /* Input Widget */
	      /* Integer */
	      if (xwgp.type[a][b] == 0)
		{
		  xwgp.objb[b] = fl_add_input(FL_INT_INPUT,xwgp.xpos[a][b],(xwgp.ypos[a][b]+xwgp.ysize[a][b])-20,xwgp.xsize[a][b]-20,20,"");
		}
	      /* Float */
	      if (xwgp.type[a][b] == 1)
		{
		  xwgp.objb[b] = fl_add_input(FL_FLOAT_INPUT,xwgp.xpos[a][b],(xwgp.ypos[a][b]+xwgp.ysize[a][b])-20,xwgp.xsize[a][b]-20,20,"");
		}
	      /* Text */
	      if (xwgp.type[a][b] == 2)
		{
		  xwgp.objb[b] = fl_add_input(FL_NORMAL_INPUT,xwgp.xpos[a][b],(xwgp.ypos[a][b]+xwgp.ysize[a][b])-20,xwgp.xsize[a][b]-20,20,"");
		}

	      /* Delete Widget */
	      xwgp.objc[b] = fl_add_button(FL_NORMAL_BUTTON,xwgp.xpos[a][b]+xwgp.xsize[a][b]-20,(xwgp.ypos[a][b]+xwgp.ysize[a][b])-20,20,20,"E");
	    }

	  /* Scroller */
	  if (xwgp.widget[a][b] == 4)
	    {
	      if (xwgp.objName[a][b] != NULL)
		{
		  xwgp.obja[b] = fl_add_valslider(FL_HOR_FILL_SLIDER,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],xwgp.objName[a][b]);
  		}
	      else
		{
		  xwgp.obja[b] = fl_add_valslider(FL_HOR_FILL_SLIDER,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
		}
	      fl_set_object_lalign(xwgp.obja[b],FL_ALIGN_LEFT);

	      /* Set Vars */
	      fl_set_slider_bounds(xwgp.obja[b],xwgp.min[a][b],xwgp.max[a][b]);
	      fl_set_slider_step(xwgp.obja[b],xwgp.step[a][b]);
	      strptr = getVar("","",xwgp.formVar[a][b]);
	      strcpy(aas,strptr);
	      fl_set_slider_value(xwgp.obja[b],atof(aas));
	    }

	  /* Input */
	  if (xwgp.widget[a][b] == 5)
	    {
	      /* Integer */
	      if (xwgp.type[a][b] == 0)
		{
		  if (xwgp.objName[a][b] != NULL)
		    {
		      xwgp.obja[b] = fl_add_input(FL_INT_INPUT,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],xwgp.objName[a][b]);
		    }
		  else
		    {
		      xwgp.obja[b] = fl_add_input(FL_INT_INPUT,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
		    }
		}
	      /* Float */
	      if (xwgp.type[a][b] == 1)
		{
		  if (xwgp.objName[a][b] != NULL)
		    {
		      xwgp.obja[b] = fl_add_input(FL_FLOAT_INPUT,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],xwgp.objName[a][b]);
		    }
		  else
		    {
		      xwgp.obja[b] = fl_add_input(FL_FLOAT_INPUT,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
		    }
		}
	      /* Text */
	      if (xwgp.type[a][b] == 2)
		{
		  if (xwgp.objName[a][b] != NULL)
		    {
		      xwgp.obja[b] = fl_add_input(FL_NORMAL_INPUT,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],xwgp.objName[a][b]);
		    }
		  else
		    {
		      xwgp.obja[b] = fl_add_input(FL_NORMAL_INPUT,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
		    }
		}
	      fl_set_object_lalign(xwgp.obja[b],FL_ALIGN_LEFT);

	      /* Set Vars */
	      strptr = getVar("","",xwgp.formVar[a][b]);
	      strcpy(aas,strptr);
	      fl_set_input(xwgp.obja[b],aas);
	    }

	  /* Text */
	  if (xwgp.widget[a][b] == 6)
	    {
	      if (xwgp.objName[a][b] != NULL)
		{
		  xwgp.obja[b] = fl_add_text(FL_NORMAL_TEXT,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],xwgp.objName[a][b]);
		}
	      else
		{
		  xwgp.obja[b] = fl_add_text(FL_NORMAL_TEXT,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
		}
	      fl_set_object_lalign(xwgp.obja[b],FL_ALIGN_CENTER);	      
	    }

	  /* Exec */
	  if (xwgp.widget[a][b] == 7)
	    {
	      if (xwgp.objName[a][b] != NULL)
	        { 
	          xwgp.obja[b] = fl_add_button(FL_NORMAL_BUTTON,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],xwgp.objName[a][b]);
		}
	      else
	        {
		  xwgp.obja[b] = fl_add_button(FL_NORMAL_BUTTON,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
		}	  
	    }

	  /* Border */
	  if (xwgp.widget[a][b] == 256)
	    {
	      xwgp.obja[b] = fl_add_frame(FL_DOWN_FRAME,xwgp.xpos[a][b],xwgp.ypos[a][b],xwgp.xsize[a][b],xwgp.ysize[a][b],"");
	    }

	  /* Color */
	  if ( (xwgp.color[a][b] > -1) && (xwgp.bcolor[a][b] > -1) )
	    {
	      fl_set_object_color(xwgp.obja[b],xwgp.color[a][b],xwgp.bcolor[a][b]);
	    }
	}

      fl_end_form();

      fl_show_form(xwgp.form,FL_PLACE_MOUSE,FL_TRANSIENT,xwInfo);

      fl_set_app_mainform(xwgp.form); 
      /* fl_raise_form(xwgp.form); */

      /* Exit Handler */
      fl_set_form_atclose(xwgp.form,nclose_cb,"1");

      /* ###########################################
	 # Abfrage Routine                         #
         ########################################### */

      xwgp.ready=0;
      while (xwgp.ready == 0)
	{
	  /* Save Vars */
	  setPrtSet("","");

	  xwgp.obj = fl_do_forms();

	  /* Exit ? Yes */
	  if (xwgp.obj == xwgp.Exit)
	    {
	      xwgp.ready = 1;
	    }

	  /* Check Widget */
	  if (xwgp.obj != xwgp.Exit)
	    {
	      /* Search Widget */
	      d=0;
	      for (b=1 ; b<=xwgp.anzObj[a] ; b++)
		{
		  /* Obj = Widget */
		  if (xwgp.obja[b] == xwgp.obj)
		    {
		      d=0;

		      /* Choice */
		      if (xwgp.widget[a][b] == 0)
			{
			  strptr = fl_get_choice_text(xwgp.obj);
			  strcpy(aas,strptr);
			  d=1;
			}

		      /* Boolean */
		      if (xwgp.widget[a][b] == 1)
			{
			  if (fl_get_button(xwgp.obj) == 1)
			    {
			      /* Save Var */
			      if (xwgp.formResult[a][b] != NULL)
				{
				  strcpy(aas,xwgp.formResult[a][b]);
				  setVar("","",xwgp.formVar[a][b],aas);
				}
			      else
				{
				  /* Save Var */
				  setVar("","",xwgp.formVar[a][b],"");
				}
			    }
			  else
			    {
			      /* Save Var */
			      setVar("","",xwgp.formVar[a][b],"");
			    }

			  /* Sperrfunktion f�r diverse Widgets */
			  if (xwgp.formData[a][b] != NULL)  
			    {
			      if (int(strlen(xwgp.formData[a][b]))>0) 
				{
				  /* Sperre anbringen */
				  strcpy(pstr,xwgp.formData[a][b]);
				  /* Search String */
				  if (strlen(pstr)>0)
				    {
				      while ( strlen(pstr) > 0 )
					{
					  strptr = strGetParm(pstr);
					  strcpy(partstr,strptr);
					  strptr = strDelParm(pstr);
					  strcpy(pstr,strptr);
					  if (int(strlen(partstr)) > 0)
					    {
					      strNewUpper(partstr);
					      
					      for (c=1 ; c<=xwgp.anzObj[a] ; c++)
						{
						  if (xwgp.formVar[a][c] != NULL)
						    {
						      if (strcmp(xwgp.formVar[a][c],partstr) == 0)
							{
							  strptr = getVar("","",xwgp.formVar[a][b]);
							  strcpy(aas,strptr);
							  if (strlen(aas)==0)
							    {
							      fl_hide_object(xwgp.obja[c]);
							      /* IBROWSER */
							      if (xwgp.widget[a][c]==3)
								{
								  fl_hide_object(xwgp.objb[c]);
								  fl_hide_object(xwgp.objc[c]);
								}
							    }
							  else
							    {
							      fl_show_object(xwgp.obja[c]);
							      /* IBROWSER */
							      if (xwgp.widget[a][c]==3)
								{
								  fl_show_object(xwgp.objb[c]);
								  fl_show_object(xwgp.objc[c]);
								}
							    }
							}
						    }
						}
					    }
					}
				    }
				}
			    }

			}

		      /* Browser */
		      if (xwgp.widget[a][b] == 2)
			{
			  strptr = fl_get_browser_line(xwgp.obj,fl_get_browser(xwgp.obj));
			  strcpy(aas,strptr);
			  d=1;
			}

		      /* Scroller */
		      if (xwgp.widget[a][b] == 4)
			{
			  strptr = DoubleStr(fl_get_slider_value(xwgp.obj));
			  strcpy(aas,strptr);
			  setVar("","",xwgp.formVar[a][b],aas);			  
			}

		      /* Input */
		      if (xwgp.widget[a][b] == 5)
			{
			  strptr = fl_get_input(xwgp.obj);
			  strcpy(aas,strptr);
			  setVar("","",xwgp.formVar[a][b],aas);			  
			}

		      /* Exec */
		      if (xwgp.widget[a][b] == 7)
			{
			  if (xwgp.formData[a][b] != NULL)
			    {
			      pid = fl_exe_command(xwgp.formData[a][b],1);
			    }
			}	   

		      /* Ergebinss -> Result */
		      if (d>0)
			{
			  strcpy(pstr,xwgp.formData[a][b]);
			  /* Search String */
			  e=0;
			  f=0;
			  if (strlen(pstr)>0)
			    {
			      while ( strlen(pstr) > 0 )
				{
				  strptr = strGetParm(pstr);
				  strcpy(partstr,strptr);
				  e++;
				  strptr = strDelParm(pstr);
				  strcpy(pstr,strptr);
				  if (strcmp(partstr,aas) == 0)
				    {
				      f=e;
				    }
				}
			    }
			  /* Result */
			  e=0;
			  strcpy(aas,"");
			  strcpy(pstr,xwgp.formResult[a][b]);
			  if (strlen(pstr)>0)
			    {
			      while ( strlen(pstr) > 0 )
				{
				  strptr = strGetParm(pstr);
				  strcpy(partstr,strptr);
				  e++;
				  strptr = strDelParm(pstr);
				  strcpy(pstr,strptr);
				  if (f==e)
				    {
				      strcpy(aas,partstr);
				    }
				}
			    }
			  /* Save Var */
			  setVar("","",xwgp.formVar[a][b],aas);
			}
		    }

		  /* IBrowser */
		  if (xwgp.widget[a][b] == 3)
		    {
		      /* Browser */
		      if (xwgp.obja[b] == xwgp.obj)
			{
			  flag=fl_get_browser(xwgp.obja[b]);
			  strptr = fl_get_browser_line(xwgp.obja[b],flag);
			  strcpy(aas,strptr);
			  fl_set_input(xwgp.objb[b],aas);
			  fl_set_focus_object(xwgp.form,xwgp.objb[b]);
			}
		      /* Input */
		      if (xwgp.objb[b] == xwgp.obj)
			{
			  strptr = fl_get_input(xwgp.objb[b]);
			  strcpy(aas,strptr);
			  /* Normaler Input */
			  if (flag==-1)
			    {
			      if (int(strlen(aas))>0)
				{
				  fl_addto_browser(xwgp.obja[b],aas);
				}
			      flag=-1;
			      fl_set_input(xwgp.objb[b],"");
			      if (int(strlen(aas))>0)
				{
				  fl_set_input_selected(xwgp.objb[b],1);
				  fl_set_focus_object(xwgp.form,xwgp.objb[b]);
				}
			    }
			  /* Edit Input */
			  if (flag>-1)
			    {
			      fl_replace_browser_line(xwgp.obja[b],flag,aas);
			      flag=-1;
			      fl_set_input(xwgp.objb[b],"");
			      fl_set_focus_object(xwgp.form,xwgp.objb[b]);
			    }
			}
		      /* Delete */
		      if (xwgp.objc[b] == xwgp.obj)
			{
			  flag=fl_get_browser(xwgp.obja[b]);
			  if (fl_isselected_browser_line(xwgp.obja[b],flag))
			    {
			      fl_delete_browser_line(xwgp.obja[b],flag);
			      fl_select_browser_line(xwgp.obja[b],flag);
			      flag=-1;
			    }
			  fl_set_input(xwgp.objb[b],"");
			}
		      /* Ibrowser Auswertung */
		      if (fl_get_browser_maxline(xwgp.obja[b])>0)
			{
			  d=fl_get_browser_maxline(xwgp.obja[b]);
			  strcpy(aas,"");
			  /* Counter */
			  if (xwgp.mode[a][b] == 1)
			    {
			      strptr = IntStr(d);
			      strcat(aas,strptr);
			      strcat(aas," ");
			    }
			  for (e=1 ; e<=d ; e++)
			    {
			      strptr = fl_get_browser_line(xwgp.obja[b],e);
			      strcat(aas,strptr);
			      strcat(aas,",");
			    }
			  if (int(strlen(aas))>0)
			    {
			      strptr = strMids(aas,1,strlen(aas)-1);
			      strcpy(aas,strptr);
			    }
			  /* Save Var */
			  setVar("","",xwgp.formVar[a][b],aas);
			}
		      else
			{
			  /* Save Var */
			  setVar("","",xwgp.formVar[a][b],"");
			}
		    }
		}
	    }

	}
      fl_set_app_mainform(mf.form);

      fl_hide_form(xwgp.form);
      fl_free_form(xwgp.form);
      xwgp.form=NULL;
    }

  return;
}

/* Scan Directory */
void scanPrinter(char *pattern) 
{
  DIR             *dirz;
  char            bpattern[80];

  strcpy(bpattern,pattern);
  strNewUpper(bpattern);

  /* Open Directory */
  fl_clear_browser(prtf.XWfile);
  if ( (dirz = opendir("/usr/local/lib/xwgui")) != NULL)
    {
    	fl_set_dirlist_sort(FL_ALPHASORT);
    
    	int nfiles = 0;
	const FL_Dirlist *dl = fl_get_dirlist("/usr/local/lib/xwgui","*.*",&nfiles,0), *ds;
	const FL_Dirlist *dlend = dl +nfiles;
	
	fl_freeze_form(prtf.form);
	
	for (ds = dl ; dl < dlend ; dl++)
	 {
	 
	  if ( ( strcmp(dl->name,".")) )
	   {
	     if (dl->type == FT_FILE)
	      {
	       if (strlen(dl->name) > 3)
	        {
	         strptr = strMids(dl->name,strlen(dl->name)-2,3);
		 strcpy(cstr,strptr);
		 if ( (strcmp(cstr,pattern) == 0) || (strcmp(cstr,bpattern) == 0) )
		  {	       
	           strcpy(bstr,dl->name);	
	           fl_add_browser_line(prtf.XWfile,bstr);
		  }
		}
	      }       
	   }
	 }

	fl_unfreeze_form(prtf.form);
	fl_free_dirlist((FL_Dirlist*)ds);  
	
      closedir(dirz);

    }

  return;
}

/* Select an PrinterFile */
const char *getPrinter(void) 
{
  char            aas[256];

  strcpy(aas,"");

  /* Printer-Window GUI Layout */ 
  printer_gui();

  /* Form Doublebuffering */
  fl_set_form_dblbuffer(prtf.form,1);      
  fl_show_form(prtf.form,FL_PLACE_MOUSE,FL_TRANSIENT,xwInfo);

  fl_set_app_mainform(prtf.form);

  /* Exit Handler */
  fl_set_form_atclose(prtf.form,nclose_cb,"1");

  scanPrinter("xwp");

  prtf.ready=0;
  while (prtf.ready == 0)
    {
      prtf.obj = fl_do_forms();
 
      /* ###########################################
	 # Control Panel                           #
         ########################################### */

      /* Connect ? Yes */
      if (prtf.obj == prtf.XWquit)
	{
	  prtf.ready = 1;
	}

      /* FileType */
      if (prtf.obj == prtf.XWtype)
	{
	  /* xw_Print */
          if (fl_get_choice(prtf.XWtype) == 1)
	    {
	      scanPrinter("xwp");
	    }
	  /* Ghostscript */
          if (fl_get_choice(prtf.XWtype) == 2)
	    {
	      scanPrinter("ghs");
	    }
	}

      /* Selected Printer */
      if (prtf.obj == prtf.XWfile)
	{
	  prtf.ready = 1;
	  if (fl_get_browser(prtf.XWfile) > 0)
	    {
	      strptr = fl_get_browser_line(prtf.XWfile,fl_get_browser(prtf.XWfile));
	      strcpy(aas,strptr);
	    }
	}

    }
  fl_set_app_mainform(mf.form);

  fl_hide_form(prtf.form);
  fl_free_form(prtf.form);
  prtf.form=NULL;

  return(aas);
}

void savePref(void) 
{
  /* Filehandle */
  FILE *fh;
  int a=0;
  int b,c;

  /* Printer selectiert ??? */
  if (strlen(xwgp.printer) > 0)
    {

      /* Main-Pref sichern */
      strcpy(astr,xpuser);
      strcat(astr,"/.xwgui/xwgui.rc");
      /* write into file */
      if ((fh=fopen(astr,"w"))!= NULL)
	{
	  strcpy(bstr,"MAIN ");
	  strcat(bstr,xwgp.printer);
	  strcat(bstr,"\n");
	  a=fputs(bstr,fh);
	  
	  strcpy(bstr," WINDOW ");
	  if (mf.xpos<0)
	    {
	      mf.xpos=0;
	    }
	  strptr = IntStr(mf.xpos);
	  strcat(bstr,strptr);
	  strcat(bstr,",");
	  if (mf.ypos<0)
	    {
	      mf.ypos=0;
	    }
	  strptr = IntStr(mf.ypos);
	  strcat(bstr,strptr);
	  strcat(bstr,",");
	  strptr = IntStr(mf.width);
	  strcat(bstr,strptr);
	  strcat(bstr,",");
	  strptr = IntStr(mf.height);
	  strcat(bstr,strptr);
	  strcat(bstr,"\n");
	  a=fputs(bstr,fh);

	  strcpy(bstr," BORDER ");
	  strptr = IntStr(pdata.pagel);
	  strcat(bstr,strptr);
	  strcat(bstr,",");
	  strptr = IntStr(pdata.pager);
	  strcat(bstr,strptr);
	  strcat(bstr,",");
	  strptr = IntStr(pdata.paget);
	  strcat(bstr,strptr);
	  strcat(bstr,",");
	  strptr = IntStr(pdata.pageb);
	  strcat(bstr,strptr);
	  strcat(bstr,"\n");
	  a=fputs(bstr,fh);
	  
	  strcpy(bstr," QUALITY ");
	  strptr = IntStr(xwgp.actQuality);
	  strcat(bstr,strptr);
	  strcat(bstr,",");
	  strptr = IntStr(xwgp.actPaper);
	  strcat(bstr,strptr);
	  strcat(bstr,"\n");
	  a=fputs(bstr,fh);
	  
	  if (int(strlen(xwgp.viewer))>0)
	    {
	      strcpy(bstr," VIEWER ");
	      strcat(bstr,xwgp.viewer);
	      strcat(bstr,"\n");
	      a=fputs(bstr,fh);
	    }

	  /* Printer Selection */ 
	  strcpy(bstr," PRTMODE ");
	  if (xwgp.prtselect == 1)
	    {
	      strcat(bstr,"DIRECT");
	    }
	  if (xwgp.prtselect == 2)
	    {
	      strcat(bstr,"SPOOL");
	    }

	  strcat(bstr,"\n");
	  a=fputs(bstr,fh);

 	  strcpy(bstr,"END\n");
	  a=fputs(bstr,fh);
	  
	  fclose(fh);
	  chmod(astr,S_IRUSR|S_IWUSR);
	}  
      
      
      /* Pref sichern */
      strcpy(astr,xpuser);
      strcat(astr,"/.xwgui/");
      strcat(astr,xwgp.printer);
      /* write into file */
      if ((fh=fopen(astr,"w"))!= NULL)
	{
	  strcpy(bstr,"PREFS\n");
	  a=a + fputs(bstr,fh);
	  
	  for (c=1 ; c<=xwgp.anzSets ; c++)
	    {
	      
	      /* Quality/Paper Combination */
	      strcpy(bstr," DEF ");
	      strcat(bstr,xwgp.prtQuality[c]);
	      strcat(bstr,",");
	      strcat(bstr,xwgp.prtPaper[c]);
	      strcat(bstr,"\n");
	      a=a + fputs(bstr,fh);
	      
	      /* Vars */
	      for (b=0 ; b<60 ; b++)
		{
		  if (xwgp.prtvar[c][b] != NULL)
		    {
		      strcpy(bstr,"  ");
		      strcat(bstr,xwgp.prtvar[c][b]);
		      strcat(bstr," ");
		      if (int(strlen(xwgp.prtdata[c][b])) > 0)
			{
			  strcat(bstr,xwgp.prtdata[c][b]);
			  strcat(bstr,"\n");
			  a=a + fputs(bstr,fh);
			}
		      else
			{
			  strcat(bstr,"\n");
			  a=a + fputs(bstr,fh);
			}
		      
		    }
		}
	      a=a + fputs(" END\n",fh);
	    }
	  
	  a=a + fputs("END\n",fh);
	  
	  fclose(fh);
	  chmod(astr,S_IRUSR|S_IWUSR);
	} 

    }

  return;
}

/* Pref Panel */
void PrefPanel(void)
{
  char            aas[256];

  strcpy(aas,"");

  /* Printer-Window GUI Layout */ 
  pref_gui();

  /* Form Doublebuffering */
  fl_set_form_dblbuffer(preff.form,1);      
  fl_show_form(preff.form,FL_PLACE_MOUSE,FL_TRANSIENT,xwInfo);

  /* Raise Form */
  fl_set_app_mainform(preff.form);

  /* Exit Handler */
  fl_set_form_atclose(preff.form,nclose_cb,"1");

  preff.ready=0;
  while (preff.ready == 0)
    {
      preff.obj = fl_do_forms();
 
      /* ###########################################
	 # Control Panel                                                              #
         ########################################### */

      /* Connect ? Yes */
      if (preff.obj == preff.XWquit)
	{
	  preff.ready = 1;
	}

      /* Printer Selection */
      if (preff.obj == preff.XWobj[1])
	{
	  if (fl_get_choice(preff.XWobj[1])>0) 
	    {
	      xwgp.prtselect = fl_get_choice(preff.XWobj[1]);
	    }
	  else
	    {
	      fl_set_choice(preff.XWobj[1],xwgp.prtselect);
	    }	  
	}

      /* External Viewer */
      strptr = fl_get_input(preff.XWobj[0]);
      strcpy(xwgp.viewer,strptr);

    }
  fl_set_app_mainform(mf.form);

  fl_hide_form(preff.form);
  fl_free_form(preff.form);
  preff.form=NULL;

  return;
}
