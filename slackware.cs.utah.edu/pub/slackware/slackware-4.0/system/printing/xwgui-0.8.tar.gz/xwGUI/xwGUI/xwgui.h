/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <forms.h>
#include <iostream.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h> /* GetEnv */
#include <string.h>
#include <strings.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <wait.h>

#ifndef _XWGUI_H
#define _XWGUI_H

/* String Definitions */
#define xwInfo  "xwGUI V0.8 - � 1998 by Stefan Kraus - License: GPL"
#define xw_Info "xwGUI V0.8"

#ifndef TRUE
#define TRUE  1
#define FALSE 0
#endif

/* Old Flags 

   0 - delete paper & border
   1 - draw paper & border
   2 - delete picture
   3 - calculate picture 
   4 - draw picture 
   5 - draw picture
*/

/* Draw Page Modes */
#define xw_clear        0    /* draw background */
#define xw_paper        1    /* draw background,paper,borders,frames,picture */
#define xw_border       2    /* draw border,frames,picture */
#define xw_frames       3    /* draw frames,picture */
#define xw_picture      4    /* draw picture */
#define xw_calcpic      5    /* calculate picture */
#define xw_fullsize     6    /* fullsize picture */

/* Window Doubblebuffering */
/*
#define xwguiDB "True"
*/

/* ###################################
   # Work Datas                      #
   ################################### */
typedef struct pagedata 
{
  /* PIXEL */
  int             x;        /* Picture Width */
  int             y;        /* Picture Heigth */
  float           aspect;   /* Picture Aspect */
  float           xpsize;   /* 1 Pixel = x mm */
  float           ypsize;   /* 1 Pixel = x mm */
  /* REAL mm */
  float           picxmm;   /* Picture Width in mm */
  float           picymm;   /* Picture Heigth in mm */
  float           picmaxx;  /* Maximal Picture Width */
  float           picmaxy;  /* Maximal Pixture Heigth */
  /* Page Size ans Aspect Ratio */  
  float           pagex;    /* Page Width in mm */
  float           pagey;    /* Page Heigth in mm */
  float           paspect;  /* Page Aspect */  
  /* PICTURE POSITION */
  float           picposx;  /* X-Picture Position */
  float           picposy;  /* Y-Picture Position */
  /* PAGE FORMAT */
  int             page;      /* Page Format - A4 / A3 ... */
  /* PAGE BORDERS */
  int             pagel;    /* Left Border */
  int             pager;    /* Right Border */
  int             paget;    /* Top Border */
  int             pageb;    /* Bottom Border */
  /* PAPER FORMAT */
  int             landscape;/* Landscape */
  /* ROTATE IMAGE */
  int             rotate;   /* rotate Image */
  /* NOT USED */
  float           pflag;    /* inch,cm,mm */

  float           buffer;   /* for any other use */
  int             puffer;   /* for any other use */
} pagedata;

/* #########################################
   # StartUpform Datas - StartUp Window    #
   ######################################### */
typedef struct serviceform
{
  /* Main-Form data */
  FL_FORM         *form;
  /* Event Loop */
  FL_OBJECT       *obj;
  int             ready;

} serviceform;

/* ###################################
   # Mainform Datas - 1.st Window    #
   ################################### */
typedef struct mainform
{
  /* Main-Form data */
  FL_FORM         *form;
  /* Event Loop */
  FL_OBJECT       *obj;
  int             ready;
  /* Background */
  FL_OBJECT       *XWBackground;
  /* File Browser */
  FL_OBJECT       *XWBrowser;
  FL_OBJECT       *XWDrawer;
  FL_OBJECT       *XWFile;
  /* Paper Sheet */
  FL_OBJECT       *XWPFrame;
  FL_OBJECT       *XWDPI;
  /* draw Frame */
  FL_OBJECT       *frame1;
  FL_OBJECT       *frame2;
  FL_OBJECT       *frame3;
  FL_OBJECT       *frame4;
  FL_OBJECT       *frame5;
  /* Paper Panel */
  FL_OBJECT       *XWPapers;
  FL_OBJECT       *XWLandscape;
  FL_OBJECT       *XWDirection;
  /* Paper Panel - Borders */
  FL_OBJECT       *XWBorderl;
  FL_OBJECT       *XWBorderr;
  FL_OBJECT       *XWBordert;
  FL_OBJECT       *XWBorderb;
  /* Paper Panel - DPI - Image Size */
  FL_OBJECT       *XWDPIm;
  FL_OBJECT       *XWDPIp;
  FL_OBJECT       *XWDPImm;
  FL_OBJECT       *XWDPIpp;
  /* Move Panel */
  FL_OBJECT       *XWMovel;
  FL_OBJECT       *XWMover;
  FL_OBJECT       *XWMovet;
  FL_OBJECT       *XWMoveb;
  FL_OBJECT       *XWMovell;
  FL_OBJECT       *XWMoverr;
  FL_OBJECT       *XWMovett;
  FL_OBJECT       *XWMovebb;
  /* Rotate */
  FL_OBJECT       *XWRotate;
  /* Full Size */
  FL_OBJECT       *XWFullSize;
  /* Center */
  FL_OBJECT       *XWHCenter;
  FL_OBJECT       *XWVCenter;
  /* External Viewer */
  FL_OBJECT       *XWViewer;
  /* Paper Reset */
  FL_OBJECT       *XWReset;
  /* Preference Panel */
  FL_OBJECT       *XWPrinter;
  FL_OBJECT       *XWQuality;
  FL_OBJECT       *XWSheets;
  FL_OBJECT       *XWPrefA;
  FL_OBJECT       *XWPrefB;
  FL_OBJECT       *XWPrefC;
  FL_OBJECT       *XWPrefFrame;
  FL_OBJECT       *XWPrefSave;
  FL_OBJECT       *XWPrefPref;

  /* Command Panel */
  FL_OBJECT       *XWPrint;
  FL_OBJECT       *XWPrintII;
  FL_OBJECT       *XWInfo;
  FL_OBJECT       *XWquit;
  FL_OBJECT       *XWHelp;
  /* unsuported Browser */
  FL_OBJECT       *XWAbout;
  FL_OBJECT       *XWMessage;

  /* Special Panel */
  FL_OBJECT       *XWTimer;

  /* Titlebar */
  FL_OBJECT       *XWTitlebar;
  FL_OBJECT       *XWIconify;
  FL_OBJECT       *XWClose;

  /* Picture Frames */
  FL_OBJECT       *XWPicFrames;

  /* Frameesize Input Field - for MainGui */
  FL_OBJECT       *XWxsize;
  FL_OBJECT       *XWysize;
  FL_OBJECT       *XWswap;
  
  /* Picture Framesets */
  FL_OBJECT       *XWPicFrameSet;

  /* Geometry Datas for flexible GUI */
  /* Root-Window Datas */
  Window          root;
  int             x,y;
  FL_Coord        width,height;
  FL_Coord        widthh,heightt;
  FL_Coord        xpos,ypos;
  unsigned int    border_width;
  unsigned int    depth;

  /*
     Resizing
     0 = kann ausgef�hrt werden 1 = wird ausgef�hrt
  */
  int             resize;
  /* 
     Pr�fen ob Resizing durchgef�hrt werden soll 
     0 = nicht ausf�hrbar 1 = Resizing kann durchgef�hrt werden
  */
  int             check;

  /* 
     Posthandler entprellen.
     Der Posthandler darf nicht mehrfach durchlaufen werden.
  */
  int             handler;

  /*
     Bild ausgew�hlt 
     0 = nicht ausgew�hlt 1 = ausgew�hlt 
  */
  int             picture;
  /*
     Bildmanipulation 
     0 = nichts 1 = gr��e 2 = verschieben ...
  */
  int             picmod;


  /* Preference Panel Geometry */
  int             x_ppg;
  int             y_ppg;

  /* File Browser Panel Geometry */
  int             y_fpg;
  int             y_bpg;

  /* Paper Panel Geometry */
  int             x_pag;
  int             y_pag;
  /* Frame Size Geometry */
  int             x_fsg;
  int             y_fsg;
  /* Picture Panel Geometry */
  int             x_pig;
  int             y_pig;

  /* Paper Window Frame */
  int             x_pwf;  /* X-Position */
  int             y_pwf;  /* Y-Position */
  int             pwf;    /* Groesse */
  int             ppwf;

} mainform;


/* #####################################
   # Paperformat Input Window          #
   ##################################### */
typedef struct paperform
{
/* Main-Form data */
  FL_FORM         *form;
  /* Event Loop */
  FL_OBJECT       *obj;
  int             ready;
  FL_OBJECT       *XWframe;
  FL_OBJECT       *XWok;
  FL_OBJECT       *XWwidth;
  FL_OBJECT       *XWheight;
  FL_OBJECT       *XWmm;
  FL_OBJECT       *XWi;
  FL_OBJECT       *XWxsizemm;
  FL_OBJECT       *XWysizemm;
  FL_OBJECT       *XWxsizeI;
  FL_OBJECT       *XWysizeI;

  float           xmm;
  float           ymm;
  float           xi;
  float           yi;
} paperform;


/* #####################################
   # Printer Selector - 2.th Window    #
   ##################################### */
typedef struct prtform
{
/* Main-Form data */
  FL_FORM         *form;
  /* Event Loop */
  FL_OBJECT       *obj;
  int             ready;
  FL_OBJECT       *XWtype;
  FL_OBJECT       *XWfile;
  FL_OBJECT       *XWquit;
} prtform;

/* #####################################
   # Print File - 3.th Window          #
   ##################################### */
typedef struct printform
{
/* Main-Form data */
  FL_FORM         *form;
  /* Event Loop */
  FL_OBJECT       *obj;
  int             ready;
  FL_OBJECT       *XWfile;
  FL_OBJECT       *XWquit;
} printform;

/* ######################################
   # Info Window - 4.th Window          #
   ###################################### */
typedef struct infoform
{
/* Main-Form data */
  FL_FORM         *form;
  /* Event Loop */
  FL_OBJECT       *obj;
  int             ready;
  FL_OBJECT       *XWobj[20];
  FL_OBJECT       *XWquit;
} infoform;

/* ######################################
   # Pref Window - 5.th Window          #
   ###################################### */
typedef struct prefform
{
    /* Main-Form data */
    FL_FORM         *form;
    /* Event Loop */
    FL_OBJECT       *obj;
    int             ready;
    FL_OBJECT       *XWobj[20];
    FL_OBJECT       *XWquit;
} prefform;

/* #######################################
   # Frame Window - 6.th Window          #
   ####################################### */
typedef struct frameform
{
    /* FrameSet-Form data */
    FL_FORM         *form;
    /* Event Loop */
    FL_OBJECT       *obj;
    int             ready;

    /* FrameSet Widgets */
    FL_OBJECT       *XWAbort;
    FL_OBJECT       *XWFrame;
    FL_OBJECT       *XWScroll;
    
    /* Framesize */
    FL_Coord        xwXSize;
    FL_Coord        xwYSize;
    /* X-Y-Frames Count */
    int             xwXFrames;
    int             xwYFrames;
    /* X-Y-Page Rest */
    int             xwXRest;
    int             xwYRest;
    /* X-Y-Offset / Bildabst�nde */
    int             xwXOffset;
    int             xwYOffset;
    /* X-Y Position */
    int             xwXPos;
    int             xwYPos;

    /* Calculated Position */
    int             xwXRPos[20][20];
    int             xwYRPos[20][20];
    /* Frame Size - for Frame Sets */
    int             xwXRSize[20][20];
    int             xwYRSize[20][20];

    /* Selectet Position */
    int             xwSXPos;
    int             xwSYPos;

    /* Frame active ??? */
    int             xwActFrame;
    /* Selected Frame */
    int             xwXF;
    int             xwYF;
    /* Landscape Frame */
    int             landscape;

    /* Offset FrameSet Selection */
    int           fspos;
    
    /* Frame Set Datas */
    int           xwActive; /* FrameSets aktiviert -1 - nicht aktiv / >=0 - Nr. des ausgew�hlten FrameSets */
    
    /* FrameSet Handler */
    /*
     Posthandler entprellen.
     Der Posthandler darf nicht mehrfach durchlaufen werden.
     */
    int           handler;
    
} frameform;

/* #########################################
   # Printer Window - 7.th Window          #
   ######################################### */
typedef struct xwprtform
{
    /* Main-Form data */
    FL_FORM         *form;
    /* Event Loop */
    FL_OBJECT       *obj;
    int             ready;
    FL_OBJECT       *XWbrowser;
    FL_OBJECT       *XWquit;
} xwprtform;

/* #########################################
   # Error Window - 8.th Window            #
   ######################################### */
typedef struct xwbugform
{
    /* Main-Form data */
    FL_FORM         *form;
    /* Event Loop */
    FL_OBJECT       *obj;
    int             ready;
    FL_OBJECT       *XWbrowser;
    FL_OBJECT       *XWquit;
} xwbugform;

/* ###################################
   # Printer Settings                #
   ################################### */
typedef struct XWGprint
{
  /* Script Datas */
  char        remark[4];                /* Remark Character */
  char        fill[4];                  /* F�ll Character */

  /* Actual Quality & Paper */
  int         actQuality;
  int         actPaper;

  /* Landcape Drucker Parameter */
  char        *landscape;               /* Druckerstring */
  char        *nolandscape;             /* Druckerstring */

  /* Druckerdaten f�r die GUI */
  char        *prtname;		        /* Druckername */
  char        printer[256];             /* Druckerfile */
  char        viewer[256];              /* Bildanzeiger ( Default: XV ) */
  int         anzQuality;               /* Anzahl Qualit�ten */
  char        *quality[11];             /* Qualit�t */
  int         anzPaper[11];             /* Anzahl Papier */
  char        *paper[11][11];           /* Papiel */

  /* 60 Variablen */
  char        *varName[60];	        /* Variablennamen */
  char        *varData[60];             /* Variableninhalt */

  /* aktueller Drucker Set */
  int         anzSets;		        /* Anzahl Drucker Einstellungen */
  int         actSet;                   /* Aktuelle Drucker Einstellung */
  char        *prtQuality[101];         /* Qualit�tsstring */
  char        *prtPaper[101];           /* Papierart */
  char        *prtvar[101][60];         /* Variablenname */
  char        *prtdata[101][60];        /* Variableninhalt */
 
  /* Print String */
  char        *printstr;                /* Drucker String */
  char        *prtdirect;               /* Direkt-String - 0 */
  char        *prtspool;                /* Spool-String  - 1 */
  char        *prtgimpdirect;           /* Gimp-String   - 2 */
  char        *prtgimpspool;            /* Gimp-String   - 2 */
  int         prtselect;                /* Prt Selection */

  /* Drucker DEVICE */
  char        *xw_device;              
  /* Spooler Daten */
  char        *xw_spooler;              /* Spooler Dir. */
  char        *xw_name;                 /* Device File */
  char        *xw_host;                 /* Host */

  /* Druckerdatei Daten - Argfile */
  char        *prtfile;                 /* Druckerdatei */
  int         prtfanz;                  /* Anzahl Zeilen */
  char        *prtfdata[100];           /* Druckerscript */

  /* - Formulardaten - */
  int         anzform;                  /* anzahl Formulare */
  int	      x[4]; 		        /* Fensterbreite */
  int         y[4]; 		        /* Fensterh�he */
  FL_FORM     *form;	                /* Zeiger auf das Formular */
  char        *formName[4];             /* Namen der Formulare */

  int         anzObj[4];                /* Anzahl Objekte Pro Formular */
  char	      *objName[4][30];	        /* Object Name */ 
  FL_OBJECT   *obj;                     /* Object for Event Loop */
  int         ready;                    /* Event Loop Status */
  FL_OBJECT   *Exit;                    /* Exit Widget */
  FL_OBJECT   *frameA;                  /* Frame A */
  FL_OBJECT   *frameB;                  /* Frame B */
  FL_OBJECT   *obja[30];                /* XForms Objecte */
  FL_OBJECT   *objb[30];              
  FL_OBJECT   *objc[30];              
  int         widget[4][30];    	/* Widget Type 
                                                       0 = CHOICE	1 = BOOLEAN	2 = BROWSER 
                                                       3 = IBROWSER	4 = SCROLLER	5 = INPUT
                                                     256 = BORDER
                                        */
  int         type[4][30];              /* 0 = INT / 1 = FLOAT / 2 = TEXT / 3 = NORMAL / 4 = PROZENT / 5 = %PROZENT */ 
  int         mode[4][30];              /* IBROWSER Modus
					   0 = None ( keine Funktion )
					   1 = COUNTER (Anzahl voranstellen )
					*/
  int         xpos[4][30];      	/* Position und Gr��e */
  int         ypos[4][30];
  int         xsize[4][30];
  int         ysize[4][30];
  float       min[4][30];               /* Scroller Datas */
  float       max[4][30];
  float       step[4][30];
  /* Drucker - Variablen */
  int         color[4][30];             /* Widget Color */
  int         bcolor[4][30];            /* Widget Color 2 */
  char        *formVar[4][30];          /* Variablenname - f�r Datenzuweisungen */
  char        *formDef[4][30];          /* Defaultdaten Zeichenkette */
  char        *formData[4][30];         /* Anzeige-Zeichenkette */
                                        /* ( CHOICE / BROWSER ) */
  char        *formResult[4][30];       /* Ergebniss-Zeichenkette */ 
                                        /* ( CHOICE / BROWSER */

  /* Gimp Datas */
  int         gimp;                     /* Gimp-Modus = 1 */

} XWGprint;

/* Get Printer Mode */
#define xw_getname      0    /* DESC-Dateinamen ermitteln */
#define xw_gethost      1    /* DESC-Host ermitteln */

/* xw_Tools Structur */
typedef struct xwPrinters_s
{
   char    *host;
   char    *name;
   char    *type;
   char    *comment;
   char    *spooldir;
   int      doIt;
} xwPrinters_t;

/* 
   ########################################## 
   #  Prototypes                            #
   ##########################################
*/
/* 
   fileio.C
*/
int readbyte(char *source,int fpos);  
int readword(char *source,int fpos);
int readlong(char *source,int fpos);
const char *readtext(char *source,int fpos,int a);
const char *getFileFormat(char *source);
void setByteOrder();
int readValue(char *source,int fpos, int size, int fileOrder);
/* Byte einlesen */
int readbyte(char *source,int fpos);
/* Word einlesen */
int readword(char *source,int fpos);
/* Long einlesen */
int readlong(char *source,int fpos);
/* Text einlesen */
const char *readtext(char *source,int fpos,int a);
/* check Picture-Format */
void checkgif(void);
void checktiff(void);
void checkppm(void);
void checkbmp(void);
void checkjpg(void);
/*
  frame.C
*/
/* Recalculate Frames */
void frames_redraw(void);
/* Frame-Window */
void picframes(void);
/* Init Frames */
void initframes(int a,int b);
/* Draw Frame into Paper */
void drawframe(int m,int x,int y,int xp,int yp,int a,int b,int c,int d);
/* Draw FrameSets */
void fsdraw(void);
/* FrameSets */
void frameset(void);
/*
  gui.C
*/
const char *GR(char *resource,char *defStr);
void main_gui(void);
int resize_main_gui(void);
void printer_gui(void);
void print_gui(void);
void info_gui(void);
void pref_gui(void);
void frame_gui(void);
/* Paper Size Layout */ 
void paper_gui(void);
/* XWPrint-Window GUI Layout */ 
void xwprint_gui(void);
/*
  handler.C
*/
/* Posthandler for Picture Control - MainForm */
int post(FL_OBJECT *ob,int ev,FL_Coord mx, FL_Coord my, int key, void *xev);
/* Posthandler for Mouse Control - FrameForm */
int ffpost(FL_OBJECT *ob,int ev,FL_Coord mx,FL_Coord my,int key,void *xev);
/* Exit Handler */
int close_cb(FL_FORM *frm,void *data);
/* None Exit Handler */
int nclose_cb(FL_FORM *frm,void *data);
/*
  main.C
*/
/* Directory scan & sort */
void scandir(void);
/*
  paper.C
*/
/* Paper-Format-Routines */
void setpaper(void); 
void drawpaper(int a);
void setdpi(void);
/*
  parser.C
*/
void addPrinter(char *source);
void addQuality(int set,char *source);
void addPaper(char *source);
void addDef(void);

void setVar(char *quality,char *paper,char *varname,char *vardata);
const char *getVar(char *quality,char *paper,char *varname);
void setDefault(void);
void setPrtSet(char *quality,char *paper);

void checkVar(void);

void allfree(int flag);

const char *readLN(void);
int getColor(char *col);
void xwParser(char *source,int act);
/*
  pref_gui.C
*/
void setpref(void);
void setForm(int a);
/* Scan Directory */
void scanPrinter(char *pattern);
/* Select an PrinterFile */
const char *getPrinter(void) ;
void savePref(void);
/* Pref Panel */
void PrefPanel(void);
/*
  printer.C
*/
void printStr(void);
void xwprint(void);
void _getData(char *dir, char *name, xwPrinters_t *xwPrinters);
int cmpName(const void *a, const void *b);
void _readDir(char *dir, xwPrinters_t **xwPrinters, int *nb, char *queryPrinter);
void checkPRT(void);
/*
  standart.C
*/
/* System Funktionen & Erweiterungen */
void newSleep(int delay);
/* Datenkonvertieren */
const char *IntStr(int a);
const char *DoubleStr(float a);
int IRound(float a);
/* Stringverarbeitung */
const char *LStr(char *source,int a);
const char *RStr(char *source,int a);
const char *strMids(char *source,int a,int b);
const char *strTrim(char *source);
void strNewTrim(char *source);
const char *strNoRem(char *source,char *rem);
const char *strGetFirst(char *source,char *cutter);
const char *strDelFirst(char *source,char *cutter);
const char *strGetParm(char *source);
const char *strDelParm(char *source);
const char *strUpper(char *source);
void strNewUpper(char *source);
const char *strInsert(char *source1,int a, char *source2);
/* Zeitrelevante Funktionen */
const char *strDiffTime(long a,long b);
const char *strDiff(long aa);
const char *strDate(char *source,int year);
int monthLen(int a,int b);
int daysBetwin(int a,int b,int c,int d,int e,int f);
int getDay(int c,int a,int b);
void test(char *source);
/*
  error.C
*/
void xwError(int nr);
#endif

