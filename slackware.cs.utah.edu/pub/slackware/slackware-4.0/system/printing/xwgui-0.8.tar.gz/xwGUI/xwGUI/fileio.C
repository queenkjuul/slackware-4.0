/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

/* Change: Jean-Jacques Sarton 03.09.1998
 *         fuctions never close the opened file !
 *
 * Remarks: This code will not work on all machine
 *          (order of bytes for short and long is not the same
 *           for a processor as the 68000 or sparc as for x86 processor)
 *
 *          This is not corrected !
 */

#include "xwgui.h"

/* Page Datas */
extern struct pagedata pdata;

/* String Vars */
extern const char *strptr;
extern char astr[256],bstr[256],cstr[256];

/* WorkFile */
extern char xwwork[1024];     /* Picture File Selection */
extern int xwworkflag;        /* Picture File active 0=Deactive 1=active */

struct gbyte
{
    char rbyte;
};

struct gword
{
    short rword;
};

struct glong
{
  unsigned int rlong;
};

/* jj Damit das Einlesen aud Liitle und Big Endian Maschine
   funktionniert nachstehende Erg�nzung
 */

#define WRONG_ORDER 0             /* INTEL Reihenfolge     */
#define GOOD_ORDER  1             /* Motorola Reihenfolge  */
static int readMode = GOOD_ORDER; /* irgend etwas sinnvoll */

static union allType_u           /* zum Einlesen          */
{
    unsigned char  b[4];
    unsigned short s[2];
    unsigned long  l[1];
} allType;

void setByteOrder()               /* initialisierung */ /*FOLD00*/
{
    allType.l[0] = 0x01020304;
    if ( allType.b[0] == 4 )
    {
        readMode = WRONG_ORDER;
    }
}

/* Byte Word oder Long einlesen, Ordnung sicher stellen */
/*
 char *source     Datei die zu lesen ist
 int   fpos       Position wo zu lesen ist
 int   size       1 , 2 oder 4 entsprechene byte, short oder long
 int   fileOrder  entsprechend anordnung der byte bei long / short
                  in der Datei, Wert 0 = Intel, 1 = Motorola
 */

int readValue(char *source,int fpos, int size, int fileOrder) /*FOLD00*/
{
    FILE *fh;
    unsigned char byte;
    int           returnValue = 0;

    if ((fh=fopen(source,"r"))!=NULL)
    {
        fseek(fh,fpos,SEEK_SET);
        if (fread(allType.b,size,1,fh) > 0)
        {
            if ( readMode != fileOrder )
            {
                switch(size)
                {
                case 1:
                    returnValue = allType.b[0];
                    break;
                case 2:
                    byte         = allType.b[0];
                    allType.b[0] = allType.b[1];
                    allType.b[1] = byte;
                    returnValue  = allType.s[0];
                    break;
                case 4:
                    byte         = allType.b[0];
                    allType.b[0] = allType.b[3];
                    allType.b[3] = byte;
                    byte         = allType.b[1];
                    allType.b[1] = allType.b[2];
                    allType.b[2] = byte;
                    returnValue  = allType.l[0];
                    break;
                }
            }
            else
            {
                switch(size)
                {
                case 1:
                    returnValue = allType.b[0];
                    break;
                case 2:
                    returnValue = allType.s[0];
                    break;
                case 4:
                    returnValue = allType.l[0];
                    break;
                }
            }
        }
        fclose(fh);
    }
    return(returnValue);
}

/* Byte einlesen */
int readbyte(char *source,int fpos) /*FOLD00*/
{
    gbyte  buf;
    FILE *fh;

    if ((fh=fopen(source,"r"))!=NULL)
    {
        fseek(fh,fpos,SEEK_SET);
        if (fread(&buf,sizeof(buf),1,fh) > 0)
        {
            fclose(fh);
            return(buf.rbyte);
        }
        else
        {
            fclose(fh);
            return(0);
        }
        /*fclose(fh); jj wird niemals geschlossen */
    }
    return(0);
}

/* Word einlesen */
int readword(char *source,int fpos) /*FOLD00*/
{
    struct gword buf;
    FILE *fh;

    if ((fh=fopen(source,"r"))!=NULL)
    {
        fseek(fh,fpos,SEEK_SET);
        if (fread(&buf,sizeof(buf),1,fh) > 0)
        {
            fclose(fh);
            return(buf.rword);
        }
        else
        {
            fclose(fh);
            return(0);
        }
        /*fclose(fh); jj wird niemals geschlossen ! */
    }
    return(0);
}

/* Long einlesen */
int readlong(char *source,int fpos) /*FOLD00*/
{
    struct glong buf;
    FILE *fh;

    if ((fh=fopen(source,"r"))!=NULL)
    {
        fseek(fh,fpos,SEEK_SET);
        if (fread(&buf,sizeof(buf),1,fh) > 0)
        {
            fclose(fh);
            return(buf.rlong);
        }
        else
        {
            fclose(fh);
            return(0);
	}
        /*fclose(fh); jj wird niemals geschlossen ! */
    }
  return(0);
}

/* Text einlesen */
const char *readtext(char *source,int fpos,int a) /*FOLD00*/
{
    static char buf[256]; /* siehe standard.c jj */
    FILE *fh;

    /* String Vars */
    const char *strptr;

    strptr = LStr("",a);
    strcpy(buf,strptr);

    if ((fh=fopen(source,"r"))!=NULL)
    {
        fseek(fh,fpos,SEEK_SET);
        if (fread(&buf,a,1,fh) > 0)
        {
            return(buf);
        }
        else
        {
            return("");
        }
        fclose(fh);
    }
    return("");
}

/* check file format */
const char *getFileFormat(char *source) /*FOLD00*/
{
    char buf[20];
    unsigned char *s;
    FILE *fh;

    /* open file and read any bytes */
    if ((fh=fopen(source,"r"))!=NULL)
    {
        fread(buf,1,sizeof(buf),fh);
        fclose(fh);

        s = buf;

        /* PPM */
        if (*s == 'P')
        {
            s++;
            switch(*s)
            {
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
                return("PPM");
            }
        }

      /* GIF */
        if (strncmp(s,"GIF87a",6) == 0)
	{
            return("GIF");
        }
        if (strncmp(s,"GIF89a",6) == 0)
        {
            return("GIF");
        }

        /* TIFF */
        if (*s == 0115 && s[1] == 0115)
        {
            return("TIFF");
        }
        if (*s == 0111 && s[1] == 0111)
        {
            return("TIFF");
        }

        /* JPEG */
        if (*s == 0xff && s[1] == 0xd8 && s[2] == 0xff && s[6] == 0x4a && s[7] == 0x46 && s[8] == 0x49 && s[9] == 0x46)
        {
            return("JPEG");
        }

        /* PNG */
        if (strncmp(s,"\x89PNG",4) == 0)
        {
            return("PNG");
        }

        /* BMP */
        if (strncmp(s,"BM",2) == 0)
        {
            return("BMP");
        }

    }
    return("");
}

/* ##################################### */
/* #                                   # */
/* # FILE FORMAT ANALYSE               # */
/* #                                   # */
/* ##################################### */

/* check GIF-Format */
void checkgif(void) /*FOLD00*/
{
    strptr = readtext(xwwork,0,3);
    strcpy(astr,strptr);

    if (strcmp(astr,"GIF") == 0)
    {
        /*
         pdata.x = readword(xwwork,6);
         pdata.y = readword(xwwork,8);
         */
        pdata.x = readValue(xwwork,6,2,0);
        pdata.y = readValue(xwwork,8,2,0);
        pdata.aspect = float(pdata.x)/float(pdata.y);
        xwworkflag=1;
    }

    return;
}

/* check TIF-Format */
void checktiff(void) /*FOLD00*/
{
    int filepos=0;
    int taganz=0;
    int tag=0;
    int nr=1;
    int status=0;
    int tiffByteOrder = 0;

    strptr = readtext(xwwork,0,2);
    strcpy(astr,strptr);

    if (strcmp(astr,"MM") == 0)
    {
        tiffByteOrder = 1;
    }
    if (strcmp(astr,"II") == 0 || strcmp(astr,"MM") == 0)
    {
        /*
         filepos = readlong(xwwork,4);
         taganz = readword(xwwork,filepos);
         */
        filepos = readValue(xwwork,4,4,tiffByteOrder);
        taganz = readValue(xwwork,filepos,2,tiffByteOrder);
        filepos = filepos+2;

        for (nr=1 ; nr<=taganz ; nr++)
        {
            tag = readValue(xwwork,filepos,2,tiffByteOrder);

            /* Image Width Tag */
            if (tag == 256)
            {
                status++;
                filepos = filepos+8;
                pdata.x = readValue(xwwork,filepos,2,tiffByteOrder);
                filepos = filepos+4;
                tag = 0;
            }
            /* Image Length Tag */
            if (tag == 257)
            {
                status++;
                filepos = filepos+8;
                pdata.y = readValue(xwwork,filepos,2,tiffByteOrder);
                filepos = filepos+4;
                tag = 0;
            }
            /* Next Tag */
            if (tag > 0)
            {
                filepos = filepos+12;
            }
        }

    }

    if (status == 2)
    {
        pdata.aspect = float(pdata.x)/float(pdata.y);
        xwworkflag=1;
    }

    return;
}

/* check PPM-Format */
void checkppm(void) /*FOLD00*/
{
    /* Filehandle */
    FILE *fh;
    int status=0;
    /* read from file */
    if ((fh=fopen(xwwork,"r"))!=NULL)
    {
        /* Header */
        if (fgets(astr,255,fh)!=NULL)
        {
            memmove((astr+strlen(astr))-1,(astr+strlen(astr)),1);
            if ( (strcmp(astr,"P3")==0) || (strcmp(astr,"P6")==0))
            {
                if (fgets(astr,255,fh)!=NULL)
                {
                    memmove((astr+strlen(astr))-1,(astr+strlen(astr)),1);
                    strptr = strMids(astr,1,1);
                    strcpy(bstr,strptr);
                    while (strcmp(bstr,"#")==0)
                    {
                        if (fgets(astr,255,fh)!=NULL)
                        {
                            memmove((astr+strlen(astr))-1,(astr+strlen(astr)),1);
                            strptr = strMids(astr,1,1);
                            strcpy(bstr,strptr);
                        }
                    }

                    strptr = strtok(astr," ");
                    while (strptr != NULL)
                    {
                        strcpy(bstr,strptr);
                        status++;
                        if (status == 1)
                        {
                            pdata.x = atoi(bstr);
                        }
                        if (status == 2)
                        {
                            pdata.y = atoi(bstr);
                        }
                        strptr = strtok(NULL," ");
                    }
                }
            }
        }
        fclose(fh);
    }

    if (status >= 2)
    {
        pdata.aspect = float(pdata.x)/float(pdata.y);
        xwworkflag=1;
    }

    return;
}

/* check BMP-Format */
void checkbmp(void) /*FOLD00*/
{
    strptr = readtext(xwwork,0,2);
    strcpy(astr,strptr);

    if (strcmp(astr,"BM") == 0)
    {
        /*
         pdata.x = readword(xwwork,6);
         pdata.y = readword(xwwork,8);
         */
        pdata.x = readValue(xwwork,18,4,0);
        pdata.y = readValue(xwwork,22,4,0);
        pdata.aspect = float(pdata.x)/float(pdata.y);
        xwworkflag=1;
    }

    return;
}

/* check JPG-Format */
void checkjpg(void) /*FOLD00*/
{
    int filepos=0;
    int a=0;
    int b=0;
    int ready=0;

    struct stat statpuff;
    int filesize=0;

    a = readValue(xwwork,filepos,2,0);
    if (a == 55551)
    {
        filepos = filepos + 2;

        if (stat(xwwork,&statpuff) == 0)
        {
            filesize = statpuff.st_size;
            while ( (ready == 0) && (filepos < filesize) )
            {
                a = readValue(xwwork,filepos,2,1);

                /* gesuchter Chunk */
                if (a == 65472)
                {
                    pdata.x = readValue(xwwork,filepos+7 ,2,1);
                    pdata.y = readValue(xwwork,filepos+5 ,2,1);
                    pdata.aspect = float(pdata.x)/float(pdata.y);
                    xwworkflag=1;
                    ready=1;
                    a=0;
                }
                /* Endkennung */
                if (a == 65497)
                {
                    ready=1;
                    a=0;
                }

                /* Chunk �berspringen */
                if (a != 0)
                {
                    b = readValue(xwwork,filepos+2,2,1);
                    filepos = filepos + b + 2;
                }

            }
        }
    }

    return;
}
