/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include "xwgui.h"

/* Page Datas */
extern struct pagedata pdata;

/* Mainform */
extern struct mainform mf;

/* Frameform */
extern struct frameform framef;

/* HomeDirectory */
extern char xpuser[1024];

/* String Vars */
extern const char *strptr;
extern char astr[256],bstr[256],cstr[256];

/* Recalculate Frames */
void frames_redraw(void)
{
    int a,b;

    /* Normal Frames */
    if (framef.xwActive==-1)
    {
    
        /* X-Y-Frames Count */
        framef.xwXFrames=int((pdata.pagex-(pdata.pagel+pdata.pager))/framef.xwXSize);
        framef.xwYFrames=int((pdata.pagey-(pdata.paget+pdata.pageb))/framef.xwYSize);
        /* X-Y-Page Rest */
        framef.xwXRest=int((pdata.pagex-(pdata.pagel+pdata.pager))- (framef.xwXSize*framef.xwXFrames) );
        framef.xwYRest=int((pdata.pagey-(pdata.paget+pdata.pageb))- (framef.xwYSize*framef.xwYFrames) );
        /* Frame Offsets / Bildabst�nde */
        if (framef.xwXFrames>1)
        {
            framef.xwXOffset=int(framef.xwXRest/(framef.xwXFrames-1));
        }
        if (framef.xwYFrames>1)
        {
            framef.xwYOffset=int(framef.xwYRest/(framef.xwYFrames-1));
        }

        /* add Frame Widgets */
        for (a=0 ; a<=framef.xwXFrames-1 ; a++)
        {

            if (a==0)
            {
                framef.xwXPos=pdata.pagel;
            }
            else
            {
                framef.xwXPos=framef.xwXPos+framef.xwXSize+framef.xwXOffset;
            }

            /* Only 1 Frame */
            if (framef.xwXFrames==1)
            {
                framef.xwXPos=pdata.pagel +  int(framef.xwXRest/2); /* /2 */
            }

            for (b=0 ; b<=framef.xwYFrames-1 ; b++)
            {

                if (b==0)
                {
                    framef.xwYPos=pdata.paget;
                }
                else
                {
                    framef.xwYPos=framef.xwYPos+framef.xwYSize+framef.xwYOffset;
                }

                /* Only 1 Frame */
                if (framef.xwYFrames==1)
                {
                    framef.xwYPos=pdata.pagel +  int(framef.xwYRest/2); /* /2 */
                }

                framef.xwXRPos[a][b]= framef.xwXPos;
                framef.xwYRPos[a][b]= framef.xwYPos;
                framef.xwXRSize[a][b]= framef.xwXSize;
                framef.xwYRSize[a][b]= framef.xwYSize;

                fl_rectbound(mf.x_pwf + IRound( (framef.xwXRPos[a][b]/pdata.xpsize) ),
                             26+12 + IRound( (framef.xwYRPos[a][b]/pdata.ypsize) ),
                             IRound( (framef.xwXRSize[a][b]/pdata.xpsize) ),
                             IRound( (framef.xwYRSize[a][b]/pdata.ypsize) ),
                             FL_LEFT_BCOL);
            }
        }

    }
    else
    {
        /* Recalculate FrameSets */

        /* Set 0 */
        if (framef.xwActive == 0)
        {
            initframes(1,3);
            drawframe(1,1,1,10,9,5,1,6,3);
            drawframe(1,1,2,10,9,3,4,6,3);
            drawframe(1,1,3,10,9,1,7,6,3);
        }
        /* Set 1 */
        if (framef.xwActive == 1)
        {
            initframes(1,3);
            drawframe(1,1,1,10,9,5,1,6,3);
            drawframe(1,1,2,10,9,1,4,6,3);
            drawframe(1,1,3,10,9,5,7,6,3);
        }
        /* Set 2 */
        if (framef.xwActive == 2)
	  {
            initframes(1,6);
            drawframe(1,1,1,10,8,1,1,5,4);
            drawframe(1,1,2,10,8,6,1,5,2);
            drawframe(1,1,3,10,8,6,3,5,2);
            drawframe(1,1,4,10,8,6,5,5,4);
            drawframe(1,1,5,10,8,1,5,5,2);
            drawframe(1,1,6,10,8,1,7,5,2);
	  }
        /* Set 3 */
        if (framef.xwActive == 3)
	  {
            initframes(1,2);
            drawframe(1,1,1,2,8,2,1,1,5);
            drawframe(1,1,2,2,8,1,4,1,5);
	  }
	/* Set 4 */
	if (framef.xwActive == 4)
	  {
	    initframes(1,4);
	    drawframe(1,1,1,6,7,2,1,4,2);
	    drawframe(1,1,2,6,7,1,3,3,3);
	    drawframe(1,1,3,6,7,4,3,3,3);
	    drawframe(1,1,4,6,7,2,6,4,2);
	  }
	/* Set 5 */
	if (framef.xwActive == 5)
	  {
	    initframes(1,12);
	    drawframe(1,1,1,4,6,1,1,1,1);
	    drawframe(1,1,2,4,6,3,1,1,1);
	    drawframe(1,1,3,4,6,2,2,1,1);
	    drawframe(1,1,4,4,6,4,2,1,1);
	    drawframe(1,1,5,4,6,1,3,1,1);
	    drawframe(1,1,6,4,6,3,3,1,1);
	    drawframe(1,1,7,4,6,2,4,1,1);
	    drawframe(1,1,8,4,6,4,4,1,1);
	    drawframe(1,1,9,4,6,1,5,1,1);
	    drawframe(1,1,10,4,6,3,5,1,1);
	    drawframe(1,1,11,4,6,2,6,1,1);
	    drawframe(1,1,12,4,6,4,6,1,1);
	  }

	/* Set 6 */
	if (framef.xwActive == 6)
	  {
	    initframes(1,3);
	    drawframe(1,1,1,2,2,1,1,1,1);
	    drawframe(1,1,2,2,2,2,1,1,1);
	    drawframe(1,1,3,2,2,1,2,2,1);
	  }
	/* Set 7 */
	if (framef.xwActive == 7)
	  {
	    initframes(1,9);
	    drawframe(1,1,1,6,5,5,1,2,1);
	    drawframe(1,1,2,6,5,4,2,2,1);
	    drawframe(1,1,3,6,5,3,3,2,1);
	    drawframe(1,1,4,6,5,2,4,2,1);
	    drawframe(1,1,5,6,5,1,5,2,1);
	    
	    drawframe(1,1,6,6,5,2,1,2,1);
	    drawframe(1,1,7,6,5,1,2,2,1);
	    
	    drawframe(1,1,8,6,5,5,4,2,1);
	    drawframe(1,1,9,6,5,4,5,2,1);
	  }
	/* Set 8 */
	if (framef.xwActive == 8)
	  {
	    initframes(1,5);
	    drawframe(1,1,1,2,4,1,1,1,1);
	    drawframe(1,1,2,2,4,2,1,1,1);
	    drawframe(1,1,3,2,4,1,2,2,2);
	    drawframe(1,1,4,2,4,1,4,1,1);
	    drawframe(1,1,5,2,4,2,4,1,1);
	  }

	/* Set 9 */
	if (framef.xwActive == 9)
	  {
	    initframes(1,6);
	    drawframe(1,1,1,3,3,1,1,2,2);
	    drawframe(1,1,2,3,3,3,1,1,1);
	    drawframe(1,1,3,3,3,3,2,1,1);
	    drawframe(1,1,4,3,3,1,3,1,1);
	    drawframe(1,1,5,3,3,2,3,1,1);
	    drawframe(1,1,6,3,3,3,3,1,1);
	  }

	/* Set 10 */
	if (framef.xwActive == 10)
	  {
	    initframes(1,15);
	    drawframe(1,1,1,3,6,1,1,1,1);
	    drawframe(1,1,2,3,6,2,1,1,1);
	    drawframe(1,1,3,3,6,3,1,1,1);
	    
	    drawframe(1,1,4,3,6,1,2,1,1);
	    drawframe(1,1,5,3,6,2,2,1,1);
	    drawframe(1,1,6,3,6,3,2,1,1);
	    
	    drawframe(1,1,7,3,6,1,3,2,2);
	    
	    drawframe(1,1,8,3,6,3,3,1,1);
	    drawframe(1,1,9,3,6,3,4,1,1);
		
	    drawframe(1,1,10,3,6,1,5,1,1);
	    drawframe(1,1,11,3,6,2,5,1,1);
	    drawframe(1,1,12,3,6,3,5,1,1);
	    
	    drawframe(1,1,13,3,6,1,6,1,1);
	    drawframe(1,1,14,3,6,2,6,1,1);
	    drawframe(1,1,15,3,6,3,6,1,1);
	  }
	/* Set 11 */
	if (framef.xwActive == 11)
	  {
	    initframes(1,5);
	    drawframe(1,1,1,3,3,1,1,2,1);
	    drawframe(1,1,2,3,3,3,1,1,2);
	    drawframe(1,1,3,3,3,2,3,2,1);
	    drawframe(1,1,4,3,3,1,2,1,2);
	    
	    drawframe(1,1,5,3,3,2,2,1,1);
	  }

	
    }
    
    return;
}

/* Frame-Window */
void picframes(void) 
{

    /* Draw Frames */
    frames_redraw();

    /* Frame Selection */
    framef.xwSXPos = framef.xwXRPos[framef.xwXF][framef.xwYF];
    framef.xwSYPos = framef.xwYRPos[framef.xwXF][framef.xwYF];

    /* Selected Position */
    if ( (framef.xwSXPos>-1) && (framef.xwSYPos>-1) )
    {
        /* scale Picture */
        if ( (framef.xwXRSize[framef.xwXF][framef.xwYF]/pdata.aspect) < framef.xwYRSize[framef.xwXF][framef.xwYF] )
        {
            pdata.picxmm = framef.xwXRSize[framef.xwXF][framef.xwYF];
            pdata.picymm = IRound(framef.xwXRSize[framef.xwXF][framef.xwYF]/pdata.aspect);
            pdata.picposx = framef.xwSXPos;
            pdata.picposy = framef.xwSYPos + ((framef.xwYRSize[framef.xwXF][framef.xwYF]-pdata.picymm) /2 );
        }
        else
            if ( (framef.xwYRSize[framef.xwXF][framef.xwYF]*pdata.aspect) < framef.xwXRSize[framef.xwXF][framef.xwYF] )
            {
                pdata.picxmm = IRound(framef.xwYRSize[framef.xwXF][framef.xwYF]*pdata.aspect);
                pdata.picymm = framef.xwYRSize[framef.xwXF][framef.xwYF];
                pdata.picposx = framef.xwSXPos + ((framef.xwXRSize[framef.xwXF][framef.xwYF]-pdata.picxmm) /2 );
                pdata.picposy = framef.xwSYPos;
            }
    }

    framef.landscape=pdata.landscape;

    return;
}

void initframes(int a,int b)
{
    int aa,bb;

    for (aa=0 ; aa<=19 ; aa++)
    {
        for (bb=0 ; bb<=19 ; bb++)
        {
            framef.xwXRPos[aa][bb]= -1;
            framef.xwYRPos[aa][bb]= -1;
            framef.xwXRSize[aa][bb]= -1;
            framef.xwYRSize[aa][bb]= -1;
        }
    }

    framef.xwXFrames=a;
    framef.xwYFrames=b;

    return;
}


/* Draw Frame into Paper */
/* drawframe(mode,x-pos,y-pos,x-parts,y-parts,x-pos,y-pos,x-size,y-size) */
void drawframe(int m,int x,int y,int xp,int yp,int a,int b,int c,int d) /*fold00*/
{
    float aa,bb; /* Paper Parts */
    float cc,dd; /* Rest fromn Paper */

    /* FrameSet Selection Mode */
    if (m==0)
    {
        if (pdata.landscape == 0)
        {
            aa=100/xp;
            bb=150/yp;
            fl_rectbound(x+IRound((a-1)*aa)+25,y+IRound((b-1)*bb),
                         IRound(c*aa),IRound(d*bb),
                         FL_LEFT_BCOL);
        }
        else
        {
            aa=150/yp;
            bb=100/xp;
            fl_rectbound((x)+IRound((b-1)*aa),(y+25)+IRound((a-1)*bb),
                         IRound(d*aa),IRound(c*bb),
                         FL_LEFT_BCOL);
        }
    }

    /* x and y used as Index Pointer for Position and Size
     of Frame                                            */
    /* Normal FrameSet Mode for Frames */
    if (m==1)
    {
        if (pdata.landscape == 0)
        {
            /* Normal FrameSet Mode for Frames */
            aa=(pdata.pagex-(pdata.pagel+pdata.pager))/xp;
            bb=(pdata.pagey-(pdata.paget+pdata.pageb))/yp;
            cc=(pdata.pagex-(pdata.pagel+pdata.pager)) - (aa*xp);
            dd=(pdata.pagey-(pdata.paget+pdata.pageb)) - (bb*yp);

            framef.xwXRPos[x-1][y-1]= IRound( pdata.pagel + cc + ( (a-1)*aa) );
            framef.xwYRPos[x-1][y-1]= IRound( pdata.pager + dd + ( (b-1)*bb) );
            framef.xwXRSize[x-1][y-1]= IRound(c*aa);
            framef.xwYRSize[x-1][y-1]= IRound(d*bb);

            fl_rectbound(mf.x_pwf + IRound( (framef.xwXRPos[x-1][y-1]/pdata.xpsize) ),
                         26+12 + IRound( (framef.xwYRPos[x-1][y-1]/pdata.ypsize) ),
                         IRound( (framef.xwXRSize[x-1][y-1]/pdata.xpsize) ),
                         IRound( (framef.xwYRSize[x-1][y-1]/pdata.ypsize) ),
                         FL_LEFT_BCOL);
        }
        else
        {
            aa=(pdata.pagex-(pdata.pagel+pdata.pager))/yp;
            bb=(pdata.pagey-(pdata.paget+pdata.pageb))/xp;
            cc=(pdata.pagex-(pdata.pagel+pdata.pager)) - (aa*yp);
            dd=(pdata.pagey-(pdata.paget+pdata.pageb)) - (bb*xp);

            framef.xwXRPos[x-1][y-1]= IRound( pdata.pagel + cc + ( (b-1)*aa) );
            framef.xwYRPos[x-1][y-1]= IRound( pdata.pager + dd + ( (a-1)*bb) );
            framef.xwXRSize[x-1][y-1]= IRound(d*aa);
            framef.xwYRSize[x-1][y-1]= IRound(c*bb);

            fl_rectbound(mf.x_pwf + IRound( (framef.xwXRPos[x-1][y-1]/pdata.xpsize) ),
                         26+12 + IRound( (framef.xwYRPos[x-1][y-1]/pdata.ypsize) ),
                         IRound( (framef.xwXRSize[x-1][y-1]/pdata.xpsize) ),
                         IRound( (framef.xwYRSize[x-1][y-1]/pdata.ypsize) ),
                         FL_LEFT_BCOL);
	}

    }
}

/* Draw FrameSets */
void fsdraw(void) 
{
    int fs,x,y; /* Frameset, X-Pos, Y-Pos */
    int a,b;

    for (a=0 ; a<=2 ; a++)
    {
        for (b=0 ; b<=1 ; b++)
        {
            fs=a+(b*3)+framef.fspos;
            x=20+(a*160);
            y=20+(b*160);
            
            /* Draw Frame */
            if (fs==framef.xwActive)
            {
                fl_rectbound(x,y,150,150,FL_MCOL);
            }
            else
            {
                fl_rectbound(x,y,150,150,FL_COL1);
            }

            /* Draw Paper */
            if (pdata.landscape == 0)
            {
                fl_rectbound(x+25,y,100,150,FL_WHITE);
            }
            else
            {
                fl_rectbound(x,y+25,150,100,FL_WHITE);
            }

            /* Set 0 */
            if (fs == 0)
            {
                drawframe(0,x,y,10,9,5,1,6,3);
                drawframe(0,x,y,10,9,3,4,6,3);
                drawframe(0,x,y,10,9,1,7,6,3);
            }
            /* Set 1 */
            if (fs == 1)
            {
                drawframe(0,x,y,10,9,5,1,6,3);
                drawframe(0,x,y,10,9,1,4,6,3);
                drawframe(0,x,y,10,9,5,7,6,3);
            }
            /* Set 2 */
            if (fs == 2)
            {
                drawframe(0,x,y,10,8,1,1,5,4);
                drawframe(0,x,y,10,8,6,1,5,2);
                drawframe(0,x,y,10,8,6,3,5,2);
                drawframe(0,x,y,10,8,6,5,5,4);
                drawframe(0,x,y,10,8,1,5,5,2);
                drawframe(0,x,y,10,8,1,7,5,2);
            }

            /* Set 3 */
            if (fs == 3)
            {
                drawframe(0,x,y,2,8,2,1,1,5);
                drawframe(0,x,y,2,8,1,4,1,5);
            }
	    /* Set 4 */
	    if (fs == 4)
	      {
		drawframe(0,x,y,6,7,2,1,4,2);
		drawframe(0,x,y,6,7,1,3,3,3);
		drawframe(0,x,y,6,7,4,3,3,3);
		drawframe(0,x,y,6,7,2,6,4,2);
	      }
	    /* Set 5 */
	    if (fs == 5)
	      {
		drawframe(0,x,y,4,6,1,1,1,1);
		drawframe(0,x,y,4,6,3,1,1,1);
		drawframe(0,x,y,4,6,2,2,1,1);
		drawframe(0,x,y,4,6,4,2,1,1);
		drawframe(0,x,y,4,6,1,3,1,1);
		drawframe(0,x,y,4,6,3,3,1,1);
		drawframe(0,x,y,4,6,2,4,1,1);
		drawframe(0,x,y,4,6,4,4,1,1);
		drawframe(0,x,y,4,6,1,5,1,1);
		drawframe(0,x,y,4,6,3,5,1,1);
		drawframe(0,x,y,4,6,2,6,1,1);
		drawframe(0,x,y,4,6,4,6,1,1);
	      }

	    /* Set 6 */
	    if (fs == 6)
	      {
		drawframe(0,x,y,2,2,1,1,1,1);
		drawframe(0,x,y,2,2,2,1,1,1);
		drawframe(0,x,y,2,2,1,2,2,1);
	      }
	    /* Set 7 */
	    if (fs == 7)
	      {
		drawframe(0,x,y,6,5,5,1,2,1);
		drawframe(0,x,y,6,5,4,2,2,1);
		drawframe(0,x,y,6,5,3,3,2,1);
		drawframe(0,x,y,6,5,2,4,2,1);
		drawframe(0,x,y,6,5,1,5,2,1);

		drawframe(0,x,y,6,5,2,1,2,1);
		drawframe(0,x,y,6,5,1,2,2,1);

		drawframe(0,x,y,6,5,5,4,2,1);
		drawframe(0,x,y,6,5,4,5,2,1);
	      }
	    /* Set 8 */
	    if (fs == 8)
	      {
		drawframe(0,x,y,2,4,1,1,1,1);
		drawframe(0,x,y,2,4,2,1,1,1);
		drawframe(0,x,y,2,4,1,2,2,2);
		drawframe(0,x,y,2,4,1,4,1,1);
		drawframe(0,x,y,2,4,2,4,1,1);
	      }

	    /* Set 9 */
	    if (fs == 9)
	      {
		drawframe(0,x,y,3,3,1,1,2,2);
		drawframe(0,x,y,3,3,3,1,1,1);
		drawframe(0,x,y,3,3,3,2,1,1);
		drawframe(0,x,y,3,3,1,3,1,1);
		drawframe(0,x,y,3,3,2,3,1,1);
		drawframe(0,x,y,3,3,3,3,1,1);
	      }
	    /* Set 10 */
	    if (fs == 10)
	      {
		drawframe(0,x,y,3,6,1,1,1,1);
		drawframe(0,x,y,3,6,2,1,1,1);
		drawframe(0,x,y,3,6,3,1,1,1);

		drawframe(0,x,y,3,6,1,2,1,1);
		drawframe(0,x,y,3,6,2,2,1,1);
		drawframe(0,x,y,3,6,3,2,1,1);

		drawframe(0,x,y,3,6,1,3,2,2);
		
		drawframe(0,x,y,3,6,3,3,1,1);
		drawframe(0,x,y,3,6,3,4,1,1);

		drawframe(0,x,y,3,6,1,5,1,1);
		drawframe(0,x,y,3,6,2,5,1,1);
		drawframe(0,x,y,3,6,3,5,1,1);

		drawframe(0,x,y,3,6,1,6,1,1);
		drawframe(0,x,y,3,6,2,6,1,1);
		drawframe(0,x,y,3,6,3,6,1,1);
	      }
	    /* Set 11 */
	    if (fs == 11)
	      {
		drawframe(0,x,y,3,3,1,1,2,1);
		drawframe(0,x,y,3,3,3,1,1,2);
		drawframe(0,x,y,3,3,2,3,2,1);
		drawframe(0,x,y,3,3,1,2,1,2);
	       
		drawframe(0,x,y,3,3,2,2,1,1);
	      }
            
        }
    }

}

void frameset(void) 
{
  double  scb=0;

  /* Frame Selection Handler */
  framef.handler=0;
  
  /* Offset FrameSet Selection */
  /* framef.fspos=0; */
  
  /* Frameset GUI */
  frame_gui();
  
  /* Form Doublebuffering */
  /*fl_set_form_dblbuffer(framef.form,0);*/
  fl_show_form(framef.form,FL_PLACE_MOUSE,FL_TRANSIENT,xwInfo);

  fl_set_app_mainform(framef.form);

  /* Post Handler for Frame Selection */
  fl_set_object_posthandler(framef.XWFrame,ffpost);

  /* Exit Handler */
  fl_set_form_atclose(framef.form,nclose_cb,"1");

  /* draw FrameSets */
  fsdraw();

  /* Init Scrollbar */
  fl_set_scrollbar_bounds(framef.XWScroll,0,2);
  fl_set_scrollbar_step(framef.XWScroll,1);
  fl_set_scrollbar_increment(framef.XWScroll,2,1);
  fl_set_scrollbar_value(framef.XWScroll,int(framef.fspos/3));

  framef.ready=0;
  while (framef.ready == 0)
    {
      framef.obj = fl_check_forms();
      
      /* Abbruch */
      if (framef.obj == framef.XWAbort)
        {
	  framef.ready = 1;
        }
     
      if (scb != fl_get_scrollbar_value(framef.XWScroll))
	{
	  scb=fl_get_scrollbar_value(framef.XWScroll);
	  framef.fspos=int(scb)*3;
	  fsdraw();
	}
      
    }
  fl_set_app_mainform(mf.form);
  
  /* Frame Selection Handler */
  framef.handler=1;
  
  fl_hide_form(framef.form);
  fl_free_form(framef.form);
  framef.form = NULL;

  /* Select Main Window for Canvas */
  fl_winset(mf.form->window);
  
  return;
}
