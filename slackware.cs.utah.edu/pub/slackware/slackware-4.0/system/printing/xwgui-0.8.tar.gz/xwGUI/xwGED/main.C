/* xpGED -- an xwGUI Editor Programm
 * Copyright (C) 1999 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include <forms.h>

#include <fcntl.h>
#include <string.h>

#include <signal.h>

#include <iostream.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h> /* GetEnv */
#include <time.h>

#include "xwged.h"

/* Internal Routines */
int close_cb(FL_FORM *frm,void *data);

/* External Routines */

/* Main-GUI */
void main_gui(void);
void actTable(int a);

/* Formulardaten */
extern struct mainform mf;

/* Prefdaten */
struct prefs pf;

/* HomeDirectory */
char *user;
char xpuser[1024]="";

int close_cb(FL_FORM *frm,void *data)
{
  long a;
  a=long(data);

  a=long(frm);

  fl_show_alert("Bedienungsfehler !!!","So kann dieses Programm nicht beendet werden !!!","Bitte, bet�tigen Sie das `Beenden` Button !!!",0);
  return(FL_IGNORE);
}

main(int argc, char *argv[])
{
  /* Grundeinstellung */
  pf.actTab=0;


  /* HomeDirectory */
  user=getenv("HOME");
  strcpy(xpuser,user);
  
  fl_initialize(&argc, argv, "xwGED", 0, 0);

  main_gui();

  /* Form Doublebuffering */
  fl_set_form_dblbuffer(mf.form,1);      

  fl_show_form(mf.form,FL_PLACE_CENTER,FL_FULLBORDER,xwged);

  fl_set_form_atclose(mf.form,close_cb,"1");

  mf.ready=0;
  while (mf.ready == 0)
    {
      mf.obj = fl_do_forms();

      /* Browser Direkt Auswahl */
      if (mf.obj == mf.colA)
	{
	  pf.actTab=0;
	  actTable(pf.actTab);
	}
      if (mf.obj == mf.colB)
	{
	  pf.actTab=1;
	  actTable(pf.actTab);
	}
      if (mf.obj == mf.colC)
	{
	  pf.actTab=2;
	  actTable(pf.actTab);
	}

      /* Browser Auswahl */
      if (mf.obj == mf.tabA)
	{
	  pf.actTab=0;
	  actTable(pf.actTab);
	}
      if (mf.obj == mf.tabB)
	{
	  pf.actTab=1;
	  actTable(pf.actTab);
	}
      if (mf.obj == mf.tabC)
	{
	  pf.actTab=2;
	  actTable(pf.actTab);
	}
   
 
      /* Quit */
      if (mf.obj == mf.quit)
	{
	  mf.ready=1;
	}

    }
  fl_hide_form(mf.form);
  fl_free_form(mf.form);

  return(0);
}

