/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include "xwgui.h"

/* 
   ########################################################################## 
   # System Funktionen & Erweiterungen                                      #
   ##########################################################################
*/

/* 1/1.000.000 Sekunden warten */
void newSleep(int delay) 
{
  struct timeval tval;

  tval.tv_usec = delay % 1000000;
  tval.tv_sec = delay / 1000000;
  select(1,0,0,0,&tval);

  return;
}

/* 
   ########################################################################## 
   # Datenkonvertieren                                                      #
   ##########################################################################
*/

/* Convert Integer To String */
const char *IntStr(int a) /*fold00*/
{
  static char buf[30];
  sprintf(buf,"%d",a);
  return(buf);
}

/* Convert Float To String */
const char *DoubleStr(float a) /*fold00*/
{
  static char buf[30];
  sprintf(buf,"%g",a);
  return(buf);
}

/* Convert Float To Int */
int IRound(float a) /*FOLD00*/
{
    return(int(a));

    if ( float(int(a))+0.4 < a)
    {
        return(int(a)+1);
    }
    else
    {
        return(int(a));
    }
    return(0);
}

/* Delete Digits after Point */


/* 
   ########################################################################## 
   # Stringverarbeitung                                                     #
   ##########################################################################
*/

/* 
   Syntax  : lstr(String,Gew�nschte Stringl�nge)
   Funktion: String auf angegebene L�nge bringen, durch anh�ngen von 
             Leerzeichen.
*/
const char *LStr(char *source,int a) /*fold00*/
{
  static char tex[1024]=""; 
  const char *strdef;

  if (0<a)       
    {
      strcpy(tex,source);
      /* Zeit intensiv */
      while (int(strlen(tex))<a)
	{
	  strcat(tex," ");
	}
       /* besser */
       /* a -= strlen(tex);
	* strdef = tex+len;
	* while ( a-- ) *strdef = ' ';
	* *strdef = '\0';
	 */
    }
  else
    {
      strdef=strMids(tex,1,a);
      strcpy(tex,strdef);
    }

  return(tex);

}

/* 
   Syntax  : rstr(String,Gew�nschte Stringl�nge)
   Funktion: String auf angegebene L�nge bringen, durch voranh�ngen von 
             Leerzeichen.                               ^^^ ???
*/
const char *RStr(char *source,int a) 
{
  static char tex[1024]="";
  char tex2[1024]="";

  strcpy(tex2,source);
  strcpy(tex,"");
  while ((int(strlen(tex))+int(strlen(tex2)))<a)
    {
      strcat(tex," ");
    }
  strcat(tex,tex2);
  
  return(tex);
}

/*
  Syntax  : strmids(String,Position,Length);
  Funktion: Teilbereich eines Strings ausschneiden.
*/ 
const char *strMids(char *source,int a,int b)
{
  static char tex[1024];
  int aa;

  strcpy(tex,source);

  aa=(a+b)-1;
  if ( (aa <= int(strlen(tex))) && ((a+b)-1 <= int(strlen(tex))) )
    { 
      memmove(tex,(tex+a)-1,b);
      memmove(tex+b,tex+strlen(tex),1);
    }

  return(tex);
}

/*
  Syntax  : strtrim(string1)
  Funktion: entfernt alle Leerzeichen, vorn und hinten.
*/
const char *strTrim(char *source) /*fold00*/
{
  static char tex[1024]="";
  const char *strdef;

  int a=1;
  strcpy(tex,source);
  while ( ( (strcmp(strMids(tex,a,1)," ") == 0) && (a <= int(strlen(tex))) ) ||
	  ( (strcmp(strMids(tex,a,1),"\t") == 0) && (a <= int(strlen(tex))) ) ) 
    {
      a++;
    }
  strdef = strMids(tex,a,(strlen(tex)-a)+1);
  strcpy(tex,strdef);

  a = strlen(tex);
  while ( ( (strcmp(strMids(tex,a,1)," ") == 0) && (a > 0) ) ||
          ( (strcmp(strMids(tex,a,1),"\t") == 0) && (a > 0) ) ) 
    {
      a--;
    }
  strdef = strMids(tex,1,a);
  strcpy(tex,strdef);

  return(tex);
}

void strNewTrim(char *source) /*fold00*/
{
  static char tex[1024]="";
  const char *strdef;

  /* front */
  int a=1;
  strcpy(tex,source);
  while ( ( (strcmp(strMids(tex,a,1)," ") == 0) && (a <= int(strlen(tex))) ) ||
	  ( (strcmp(strMids(tex,a,1),"\t") == 0) && (a <= int(strlen(tex))) ) ) 
    {
      a++;
    }
  strdef = strMids(tex,a,(strlen(tex)-a)+1);
  strcpy(tex,strdef);

  /* back */
  a = strlen(tex);
  while ( ( (strcmp(strMids(tex,a,1)," ") == 0) && (a > 0) ) ||
          ( (strcmp(strMids(tex,a,1),"\t") == 0) && (a > 0) ) ) 
    {
      a--;
    }
  strdef = strMids(tex,1,a);
  strcpy(source,strdef);

  return;
}	  

/*
  Syntax  : strnorem(string1,string2)
  Funktion: entfernt alle Zeichen ab dem Kommentarzeichen.
*/
const char *strNoRem(char *source,char *rem) 
{
  static char tex[1024]="";
  char aas[4]="";
  const char *strdef;
  int a=1;
  int b=0;

  strcpy(tex,source);
  if (strlen(tex) > 0)
    {
      strdef = strMids(tex,1,1);
      strcpy(aas,strdef);
      if ( (strcmp(aas,rem) == 0) && (a == 1) )
	{
	  strcpy(tex,"");
	}
      else
	{
	  while (a < int(strlen(tex)))
	    {
	      a++;
	      strdef = strMids(tex,a,1);
	      strcpy(aas,strdef);

	      if (strcmp(aas,rem) == 0)
		{
		  b=a-1;
		}

	    }
	  if (b>0)
	    {
	      strdef = strMids(tex,1,b-1);
	      strcpy(tex,strdef);
	    }
	}
    }
  else
    {
      strcpy(tex,"");
    }
  return(tex);
}

/*
  Syntax  : strGetFirst(string,cutter)
  Funktion: Teilbereich bis zum Trennzeichen r�ckgeben
*/
const char *strGetFirst(char *source,char *cutter) 
{
  static char tex[1024]="";
  const char *strdef;
  int a; 

  strcpy(tex,source);
  a = 1;
  while ( (strcmp(strMids(tex,a,1),cutter) != 0) && (a <= int(strlen(tex))) )
    {
      a++;
    }
  strdef = strMids(tex,1,a-1);
  strcpy(tex,strdef);

  return(tex);
}

/*
  Syntax  : strDelFirst(string,cutter)
  Funktion: Teilbereich bis zum Trennzeichen entfernen
*/
const char *strDelFirst(char *source,char *cutter) 
{
  static char tex[1024]="";
  const char *strdef;
  int a; 

  strcpy(tex,source);
  a = 1;
  while ( (strcmp(strMids(tex,a,1),cutter) != 0) && (a <= int(strlen(tex))) )
    {
      a++;
    }
  if (a < int(strlen(tex)))
    {
      strdef = strMids(tex,a+1,strlen(tex)-a);
      strcpy(tex,strdef);
    }
  else
    {
      strcpy(tex,"");
    }

  return(tex);
}

/*
  Syntax  : strGetParm(string)
  Funktion: Teilbereich bis zum Komma r�ckgeben
*/
const char *strGetParm(char *source) /*fold00*/
{
  static char tex[1024]="";
  const char *strdef;
  int a; 

  strcpy(tex,source);
  a = 1;
  while ( (strcmp(strMids(tex,a,1),",") != 0) && (a <= int(strlen(tex))) )
    {
      a++;
    }
  if (int(strlen(tex))>1)
    {
      strdef = strMids(tex,1,a-1);
      strcpy(tex,strdef);
    }

  return(tex);
}

/*
  Syntax  : strDelParm(string)
  Funktion: Teilbereich bis zum , entfernen
*/
const char *strDelParm(char *source) 
{
  static char tex[1024]="";
  const char *strdef;
  int a; 

  strcpy(tex,source);
  a = 1;
  while ( (strcmp(strMids(tex,a,1),",") != 0) && (a <= int(strlen(tex))) )
    {
      a++;
    }
  if (a < int(strlen(tex)))
    {
      strdef = strMids(tex,a+1,strlen(tex)-a);
      strcpy(tex,strdef);
    }
  else
    {
      strcpy(tex,"");
    }

  return(tex);
}


/*
  Syntax  : strupper(string)
  Funktion: String in GROSSBUCHSTABEN umwandeln
*/
const char *strUpper(char *source) /*fold00*/
{
  static char tex[1024]="";
  int a;

  a=1;
  strcpy(tex,source);
  if ( strlen(tex) > 0)
    {
      for ( a=1 ; a <= int(strlen(tex)) ; a++ )
	{
	  tex[a-1] = toupper(tex[a-1]);
	}
    } 
  return(tex);
}
void strNewUpper(char *source) /*fold00*/
{
  static char tex[1024]="";
  int a;

  a=1;
  strcpy(tex,source);
  if ( strlen(tex) > 0)
    {
      for ( a=1 ; a <= int(strlen(tex)) ; a++ )
	{
	  tex[a-1] = toupper(tex[a-1]);
	}
    } 
  strcpy(source,tex);

  return;
}

/*
  Syntax  : strinsert(String1,Position,String2);
  Funktion: F�gt String2 ab Position in String1 ein.
*/
const char *strInsert(char *source1,int a, char *source2) /*fold00*/
{
  static char tex[1024]="";
  const char *strdef;
   
  if (a>0)
    {    
      if (a <int(strlen(source1)))
	{
	  strdef=strMids(source1,1,a-1);
	  strcpy(tex,strdef);
	  strcat(tex,source2);
	  strdef=strMids(source1,a,strlen(source1)-(a-1));
	  strcat(tex,strdef);
	}
    }

  return(tex);
}


/* 
   ########################################################################## 
   # Zeitrelevante Funktionen                                               #
   ##########################################################################
*/

/*
  Syntax  : strdifftime(time,time);
  Funktion: verstrichene Zeit ermitteln und als String zur�ckgeben.
*/ 
const char *strDiffTime(long aa,long bb) /*fold00*/
{
 static char tex[20];
 const char *strdef;
 int a;
 double difft;

 difft = difftime(bb,aa);
 a = int(difft);
 strdef = strDiff(a);
 strcpy(tex,strdef); 

 return (tex);
}

/*
  Syntax  : strdiff(zeit);
  Funktion: Uhrzeit in einen String konvertieren.
*/ 
const char *strDiff(long aa) /*fold00*/
{
 static char tex[20];
 char atex[20];
 const char *strdef;
 int a;

 a = aa;
 strdef = IntStr((a/3600));
 a=a%3600;
 strcpy(tex,strdef);
 if (strlen(tex)==0)
   {
     strcpy(tex,"0");
   }
 strcat(tex,":");
 strdef = IntStr((a/60));
 a=a%60;
 strcpy(atex,strdef);
 if (strlen(atex)==1)
   {
     strcat(tex,"0");
   }
 if (strlen(atex)==0)
   {
     strcat(tex,"00");
   }
 strcat(tex,atex);
 strcat(tex,":");
 strdef = IntStr(a);
 strcpy(atex,strdef);
 if (strlen(atex)==1)
   {
     strcat(tex,"0");
   }
 if (strlen(atex)==0)
   {
     strcat(tex,"00");
   }
 strcat(tex,atex);

 return (tex);
}

/* Date and Time from Message Logfile Entry */
const char *strDate(char *source,int year) /*fold00*/
{

  const char *const monthstr[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

  static char tex[1024]="";
  char texx[1024]="";
  int aa;
  const char *strdef;

  int day,month=0;

  /* Month */ 
  strdef = strMids(source,1,3);
  strcpy(texx,strdef);
  for (aa=0 ; aa<=11 ; aa++)
    {
      /* found month */
      if (strstr(monthstr[aa],texx) != NULL)
	{
	  month = aa+1;
	}
    }

  /* Day */
  strdef = strMids(source,5,2);
  strcpy(texx,strdef);
  day = atoi(texx);

  /* Date String */
  strcpy(tex,"");
  strdef = IntStr(month);
  strcpy(texx,strdef);
  if (strlen(texx)==1)
    {
      strcat(tex,"0");
    }
  strcat(tex,texx);
  strcat(tex,"/");

  strdef = IntStr(day);
  strcpy(texx,strdef);
  if (strlen(texx)==1)
    {
      strcat(tex,"0");
    }
  strcat(tex,texx);
  strcat(tex,"/");

  if (year>1900)
    {
      year=year-1900;
    }
  if (year>2000)
    {
      year=year-2000;
    }
  strdef = IntStr(year);
  strcpy(texx,strdef);
  if (strlen(texx)==1)
    {
      strcat(tex,"0");
    }
  strcat(tex,texx);
  strcat(tex," ");

  /* Time String */
  strdef = strMids(source,8,8);
  strcat(tex,strdef);

  return(tex);
}

/* Returns the len of an Month in days */
int monthLen(int a,int b) /*fold00*/
{
  struct tm atm;
  time_t atime,btime;
  double difft;
  int aa;
  
  /* first time_t */
  atm.tm_mday = 1;
  atm.tm_mon = a-1;
  atm.tm_year = b-1900;
  atm.tm_hour = atm.tm_min = 0;
  atm.tm_sec = 1;
  atm.tm_isdst = -1;
  atime = mktime(&atm);

  /* second time_t */
  atm.tm_mday = 1;
  atm.tm_hour = atm.tm_min = 0;
  atm.tm_sec = 1;
  atm.tm_isdst = -1;
  if (a == 12)
    {
      atm.tm_mon = 0;
      atm.tm_year = atm.tm_year +1;
    }
  else
  {
    atm.tm_mon = a;
    atm.tm_year = b-1900;    
  }
  btime = mktime(&atm);

  difft = difftime(btime,atime);

  difft = difft / 86400;
  aa = int(difft);
  difft = difft - double(aa);
  if (difft>=0.5)
    {
      aa=aa+1;
    }

  return(aa);
}

/* Returns the len of an Month in days */
/* a = day, b = month, c = year   Start Time
 * d = day, e = month, d = year   End Time
 *
 * function return the number of day between the given dates
 * if the number of day of a month are to be found we can do this
 * as follow:
 *   int daysbetwin(int month, int year)
 *   {
 *      int lap;
 *      if ( month == 2 )
 *      {
 *	   if ( (year / 4) == 0 )           // may be lapyear
 *         {
 *            if ( (year / 100) == 0 )      // may not be
 *            {
 *                if ( (year / 400 ) == 0 ) // is lapyear
 *                {
 *                   return 29;
 *                }
 *                return 28;                // not lapyear
 *            }
 *           return 29;                     // is lapyear
 *         }
 *         return 28;
 *         // alternately 
 *         // if ( !(year/400) || (!(year/4) && !((year/100)==0)) )
 *         //    return 29;
 *         // else;
 *         //    return 28;
 *      }
 *      else
 *      {
 *         case 1: case 3: case 5: case 7:
 *         case 8: case 10: case 12:
 *            return 31;
 *         default:
 *            return 30;
 *      }
 *   }
 *
 * 
 */

/*
  Syntax  : daysbetwin(tag,monat,jahr,tag,monat,jahr);
  Funktion: Anzahl Tage, zwischen zwei Datumsangaben, ermitteln.
*/ 
int daysBetwin(int a,int b,int c,int d,int e,int f) /*fold00*/
{
  struct tm atm;
  time_t atime,btime;
  float difft;
  int aa;
  
  /* first time_t */
  atm.tm_mday = a;
  atm.tm_mon = b-1;
  atm.tm_year = c-1900;
  atm.tm_hour = atm.tm_min = 0;
  atm.tm_sec = 1;
  atm.tm_isdst = -1;
  atime = mktime(&atm);

  /* second time_t */
  atm.tm_mday = d;
  atm.tm_mon = e-1;
  atm.tm_year = f-1900;
  atm.tm_hour = 23;
  atm.tm_min = 59;
  atm.tm_sec = 59;
  atm.tm_isdst = -1;
  btime = mktime(&atm);

  difft = difftime(btime,atime);

  difft = difft / 86400;
  aa = int(difft);
  difft = difft - double(aa);
  if (difft>=0.5)
    {
      aa=aa+1;
    }

  return(aa);
}

/*
  Syntax  : getday(tag,monat,jahr);
  Funktion: Beechnet denn Wochentag.
*/ 
int getDay(int c,int a,int b) /*fold00*/
{
  struct tm atm;
  time_t atime;
  int aa;
  
  atm.tm_mday = c;
  atm.tm_mon = a-1;
  atm.tm_year = b-1900;
  atm.tm_hour = atm.tm_min = 0;
  atm.tm_sec = 1;
  atm.tm_isdst = -1;
  atime = mktime(&atm);
  aa = atm.tm_wday;

  return(aa);
}


void test(char *source) /*fold00*/
{
  cout << source << "\n";
  return;
}
