/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include "xwgui.h"

/* HomeDirectory */
extern char *user;
extern char xpuser[1024];

/* Directory-Path */
extern char xwpath[1024];
extern char xwpathh[1024];  /* For Path Manipulations */

/* WorkFile */
extern char xwwork[1024];   /* Picture File Selection */
extern int xwworkflag;      /* Picture File active 0=Deactive 1=active */

/* Page Datas */
extern struct pagedata pdata;

/* Mainform */
extern struct mainform mf;

/* Frameform */
extern struct frameform framef;

/* String Vars */
extern const char *strptr;
extern char astr[256],bstr[256],cstr[256];

/* Integer Values */
extern int a,b,c,d;

/* Mouseposition - Mouse Datas */
extern Window win;
extern int winx,winy;
extern int xcor,ycor,xxcor,yycor;
extern int picmode;
extern unsigned int wink;

/* Iconify Vars */
extern int icommand;       /* Internal Command Code */
extern XWindowAttributes attr;

/* Posthandler for Picture Control */
int post(FL_OBJECT *ob,int ev,FL_Coord mx, FL_Coord my, int key, void *xev) /*fold00*/
{
  char buff[128];
  FL_Coord ax,ay,aw,ah;
  /* Integer Values */
  int a,b,c,d;
  /* Mouse Data - Maus entprellen - nur 1 Klick m�glich - ben�tigt f�r Frame Mode */
  static int Mouse;

  /* for compiler - disable warning message */
  a=ev;
  a=key;
  a=long(xev);

  /* cout << ev << "\n"; */
  
  /* ReIconify - redraw page */
  if (ev==1)
    {
      drawpaper(xw_paper);
    }

  /* Posthandler entprellen */
  if (mf.handler==0)
    {
      /* Posthandler Sperre setzen */
      mf.handler=1;

      /* Resize Mainform */
      if (mf.check==1)
	{
	  mf.check=0;
	  /* Windowgeometry for Resizing Window - old resizing routine */
	  fl_get_wingeometry(mf.form->window,&mf.xpos,&mf.ypos,&mf.widthh,&mf.heightt);
	  if ( (mf.width != mf.widthh) || (mf.height != mf.heightt) )
	    {
	      mf.width=mf.widthh;
	      mf.height=mf.heightt;
	      
	      while (resize_main_gui() == 0);      
	    }
	  
	  /* Widget Check for Resizing Window */
	  if (mf.XWInfo->w != 36)
	    {
	      while (resize_main_gui() == 0);  
	    }
	  if (mf.XWInfo->h != 18)
	    {
	      while (resize_main_gui() == 0);  
	    }
	  mf.check=1;
	}

      /* +++ Set Mouse Pointer for Frame Mode +++ */
      if ( (picmode==0) && (mf.picture==1) && (mf.check==1) && (framef.xwActFrame==1) ) 
	{
	  winx = mx-mf.x_pwf;
	  winy = my-36;

          /* Frame Selection */
	  c=-1;
	  d=-1;
	  for (a=0 ; a<=framef.xwXFrames-1 ; a++)
          {
	      for (b=0 ; b<=framef.xwYFrames-1 ; b++)
              {

		  if ( (c==-1) && (d==-1) )
                  {

                      /* for aktive frames */
                      if ( (framef.xwXRPos[a][b]>-1) && (framef.xwYRPos[a][b]>-1) )
                      {

                          if ( (winx>=IRound(framef.xwXRPos[a][b]/pdata.xpsize)) &&
                               (winx<=IRound((framef.xwXRPos[a][b]+framef.xwXRSize[a][b])/pdata.xpsize)) &&
                               (winy>=IRound(framef.xwYRPos[a][b]/pdata.ypsize)) &&
                               (winy<=IRound((framef.xwYRPos[a][b]+framef.xwYRSize[a][b])/pdata.ypsize)) )
                          {
                              c=a;
                              d=b;
                              if ( (a==framef.xwXF) && (b==framef.xwYF) )
                              {
                                  fl_set_cursor(mf.form->window,XC_exchange);
                              }
                              else
                              {
                                  fl_set_cursor(mf.form->window,XC_hand1);
                              }
                          }
                      }
                  }
                }
            }
	  if ( (c==-1) || (d==-1) )
	    {
	      fl_set_cursor(mf.form->window,FL_DEFAULT_CURSOR); 
	    }
	}
      
      /* +++ Set Mouse Pointer for Normal Mode +++ */
      if ( (picmode==0) && (mf.picture==1) && (mf.check==1) && (framef.xwActFrame==0) ) 
	{
	  winx = mx-mf.x_pwf;
	  winy = my-36;
	  /* X - Move */
	  if ( (winx>=IRound( pdata.picposx/pdata.xpsize )+5) && (winx<=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)-5) &&
	       (winy>=IRound( pdata.picposy/pdata.ypsize )+5) && (winy<=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)-5) )
	    {
	      fl_set_cursor(mf.form->window,XC_fleur);
	    }
	  /* Horizontal Resize */
	  if ( (winx>=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)-5) && (winx<=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)) &&
	       (winy>=IRound(pdata.picposy/pdata.ypsize)+5) && (winy<=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)-5) )
	    {
	      fl_set_cursor(mf.form->window,XC_sb_h_double_arrow); /* XC_sb_h_double_arrow */
	    }
	  /* Vertical Resize */
	  if ( (winx>=IRound(pdata.picposx/pdata.xpsize)+5) && (winx<=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)-5) &&
	       (winy>=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)-5) && (winy<=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)) )
	    {
	      fl_set_cursor(mf.form->window,XC_sb_v_double_arrow);  /* XC_sb_v_double arrow */
	    }
	  /* Default Cursor */
	  if ( (winx<IRound( pdata.picposx/pdata.xpsize) ) || (winx>IRound( (pdata.picposx+pdata.picxmm) /pdata.xpsize) ) ||
	       (winy<IRound( pdata.picposy/pdata.ypsize) ) || (winy>IRound( (pdata.picposy+pdata.picymm) /pdata.ypsize) ) )
	    {
	      fl_set_cursor(mf.form->window,FL_DEFAULT_CURSOR); 
	    }
	}
      
      /* Mausaktivit�ten */
      if ( (ev == FL_PUSH) || (ev == FL_MOUSE) )
	{
	  /* Normal Mode */
	  if (framef.xwActFrame==0)
	    {
	      Mouse=0;
	    }
	  
	  /* Framemode */
	  if (Mouse==0)
	    {
	      Mouse=1;
	      
	      winx = mx-mf.x_pwf;
	      winy = my-36;
	      
	      strcpy(buff,"");
	      
	      
	      /* Middle Mouse Button */
	      
	      
	      /* Left Mouse Button - Frame Mode */
	      if ( (fl_mouse_button()==1) && (framef.xwActFrame==1) )
		{
		  /* Frame Selection */
		  /*
		    framef.xwXF = -1;
		    framef.xwYF = -1;
		  */
		  /* Rotate Mode */
		  c=0;
		  /* Break Loop */
		  d=0;
		  for (a=0 ; a<=framef.xwXFrames-1 ; a++)
		    {
		      for (b=0 ; b<=framef.xwYFrames-1 ; b++)
			{
			  if (d==0)
			    {
			      if ( (winx>=IRound(framef.xwXRPos[a][b]/pdata.xpsize)) &&
				   (winx<=IRound((framef.xwXRPos[a][b]+framef.xwXRSize[a][b])/pdata.xpsize)) &&
				   (winy>=IRound(framef.xwYRPos[a][b]/pdata.ypsize)) &&
				   (winy<=IRound((framef.xwYRPos[a][b]+framef.xwYRSize[a][b])/pdata.ypsize)) )
				{
				  /* Rotate Mode ? */
				  if ( (a==framef.xwXF) && (b==framef.xwYF) ) 
				    {
				      c=1;
				    }
				  framef.xwXF=a;
				  framef.xwYF=b;
				  d=1;
				}
			    }
			}
		    }
	      
		  /* Rotate Image */
		  if (c==1)
		    {
		      if (pdata.rotate == 0)
			{
			  pdata.rotate=1;
		          pdata.puffer=pdata.x;
			  pdata.x=pdata.y;
			  pdata.y=pdata.puffer;
			  
			  pdata.aspect = float(pdata.x)/float(pdata.y);
			}
		      else
			{
			  if (pdata.rotate == 1)
			    {
			      pdata.rotate=0;
			      pdata.puffer=pdata.x;
			      pdata.x=pdata.y;
			      pdata.y=pdata.puffer;
			      
			      pdata.aspect = float(pdata.x)/float(pdata.y);
			    }
			}
		      picframes();
		      /* drawpaper(xw_paper); */
		      c=0;
		    }
		  
		  /* Redraw Paper */
		  if ( (framef.xwXF>=0) && (framef.xwYF>=0) && (c==0) )
		    {
		      /* Frame Selection */
		      framef.xwSXPos = framef.xwXRPos[framef.xwXF][framef.xwYF];
		      framef.xwSYPos = framef.xwYRPos[framef.xwXF][framef.xwYF];
		      
		      /* Selected Position */
		      if ( (framef.xwSXPos>-1) && (framef.xwSYPos>-1) )
			{
			  /* scale Picture */
			  if ( (framef.xwXSize/pdata.aspect) < framef.xwYSize )
			    {
			      pdata.picxmm = framef.xwXSize;
			      pdata.picymm = IRound(framef.xwXSize/pdata.aspect);
			      pdata.picposx = framef.xwSXPos;
			      pdata.picposy = framef.xwSYPos + ((framef.xwYSize-pdata.picymm) /2 ); 
			    }
			  else
			    if ( (framef.xwYSize*pdata.aspect) < framef.xwXSize )
			      {
			    pdata.picxmm = IRound(framef.xwYSize*pdata.aspect);
			    pdata.picymm = framef.xwYSize;
			    pdata.picposx = framef.xwSXPos + ((framef.xwXSize-pdata.picxmm) /2 );
			    pdata.picposy = framef.xwSYPos;
			      }
			  drawpaper(xw_frames);	
			}
		      
		    }
		  newSleep(25000);
		}
	      
	      /* Left Mouse Button - Normal Mode */
	      if ( (fl_mouse_button()==1) && (framef.xwActFrame==0) )
		{
		  
		  if (mf.picture==1)
		    {
		      /* Top */
		      if ( (winx>=IRound(pdata.picposx/pdata.xpsize)) && (winx<=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)) &&
			   (winy>=0) && (winy<=IRound(pdata.picposy/pdata.ypsize)) )
			{
			  strcat(buff,IntStr(IRound(pdata.picposy)));
			  strcat(buff," mm");
			}
		      /* Buttom */
		      if ( (winx>=IRound(pdata.picposx/pdata.xpsize)) && (winx<=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)) &&
			   (winy>=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)) && (winy<=IRound(pdata.pagey/pdata.ypsize)) )
			{
			  strcat(buff,IntStr(IRound(pdata.pagey - ( pdata.picposy+pdata.picymm) )) );
			  strcat(buff," mm");
			}
		      /* Left */
		      if ( (winx>=0) && (winx<=IRound(pdata.picposx/pdata.xpsize)) &&
			   (winy>=IRound(pdata.picposy/pdata.ypsize)) && (winy<=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)) )
			{
			  strcat(buff,IntStr(IRound(pdata.picposx)));
			  strcat(buff," mm");
			}
		      /* Right */
		      if ( (winx>=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)) && (winx<=IRound(pdata.pagex/pdata.xpsize)) &&
			   (winy>=IRound(pdata.picposy/pdata.ypsize)) && (winy<=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)) )
			{
			  strcat(buff,IntStr(IRound(pdata.pagex - ( pdata.picposx+pdata.picxmm) )) );
			  strcat(buff," mm");
			}
		      
		      
		      /* Move */
		      if ( (xxcor==-1) && (yycor==-1) && (picmode==0) )
			{
			  if ( (winx>=IRound(pdata.picposx/pdata.xpsize)+5) && (winx<=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)-5) &&
			       (winy>=IRound(pdata.picposy/pdata.ypsize)+5) && (winy<=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)-5) )
			    {
			      xcor=IRound(pdata.picposx/pdata.xpsize)-winx;
			      ycor=IRound(pdata.picposy/pdata.ypsize)-winy;
			      xxcor=winx;
			      yycor=winy;						
			      fl_set_cursor(mf.form->window,XC_fleur);
			      picmode=1;
			    }
			}
		      if (picmode==1)
			{
			  pdata.picposx=(winx+xcor)*pdata.xpsize;
			  pdata.picposy=(winy+ycor)*pdata.ypsize;
			  
			  if (pdata.picposx<pdata.pagel)
			    {								
			      pdata.picposx=pdata.pagel;
			    }
			  if (pdata.picposy<pdata.paget)
			    {											
			      pdata.picposy=pdata.paget;
			    }										
			  if (pdata.picposx>pdata.pagex-(pdata.pager+pdata.picxmm))
			    {								
			      pdata.picposx=pdata.pagex-(pdata.pager+pdata.picxmm);
			    }
			  if (pdata.picposy>pdata.pagey-(pdata.pageb+pdata.picymm))
			    {								
			      pdata.picposy=pdata.pagey-(pdata.pageb+pdata.picymm);
			    }		
			  
			  if ( (winx!=xxcor) || (winy!=yycor) )
			    {
			      drawpaper(xw_border);	
			    }
			  
			  xxcor=winx;
			  yycor=winy;
			  
			  /* Create Onliner Text */
			  strcpy(buff,IntStr(IRound(pdata.picposy)));
			  strcat(buff," mm\n\n");
			  strcat(buff,IntStr(IRound(pdata.picposx)));
			  strcat(buff," mm      ");
			  strcat(buff,IntStr(IRound(pdata.pagex - ( pdata.picposx+pdata.picxmm ) )));
			  strcat(buff," mm\n\n");
			  strcat(buff,IntStr(IRound( pdata.pagey - ( pdata.picposy+pdata.picymm ) )));
			  strcat(buff," mm"); 
			}
		      
		      /* Resize Right */
		      if ( (xxcor==-1) && (yycor==-1) && (picmode==0) )
			{
			  if ( (winx>=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)-5) && (winx<=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)) &&
			       (winy>=IRound(pdata.picposy/pdata.ypsize)+5) && (winy<=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)-5) )
			    {
			      xcor=IRound((pdata.picxmm+pdata.picposx)/pdata.xpsize)-winx; /* ??? */
			      xxcor=winx;
			      yycor=winy;						
			      fl_set_cursor(mf.form->window,XC_sb_h_double_arrow);
			      picmode=2;
			    }
			}
		      if (picmode==2)
			{
			  pdata.picxmm=IRound( ( (winx+xcor) - IRound(pdata.picposx/pdata.xpsize) ) *pdata.xpsize);
			  pdata.picymm=IRound( pdata.picxmm / pdata.aspect );
			  
			  /* X-Minimal Check */
			  if (pdata.picxmm<10)
			    {
			      pdata.picxmm=10;
			      pdata.picymm=IRound(10/pdata.aspect);
			    }
			  			  
			  /* Y-Minimal Check */
			  if (pdata.picymm<10)
			    {
			      pdata.picymm=10;
			      pdata.picxmm=IRound(10*pdata.aspect);
			    }
			  			  
			  /* X Size Check */
			  if (pdata.picxmm>IRound(pdata.pagex-(pdata.picposx+pdata.pager)))
			    {
			      pdata.picxmm=IRound(pdata.pagex-(pdata.picposx+pdata.pager));
			      pdata.picymm=IRound( pdata.picxmm / pdata.aspect );
			    }
			  			  
			  /* Y Size Check */
			  if (pdata.picymm>IRound( pdata.pagey - ( pdata.picposy+pdata.pageb ) ) )
			    {
			      pdata.picymm=IRound(pdata.pagey-(pdata.picposy+pdata.pageb));
			      pdata.picxmm=IRound( pdata.picymm * pdata.aspect );
			    }
			  
			  /* DPI Check */
			  a = IRound((pdata.x/(pdata.picxmm-1))*25.4);
			  if (a>719)
			    {
			      pdata.picxmm = IRound((float(pdata.x)/720)*25.4);
			      pdata.picymm = IRound(pdata.picxmm / pdata.aspect );
			    }

			  if ( (winx!=xxcor) || (winy!=yycor) )
			    {
			      drawpaper(xw_border);	
			    }
			  
			  xxcor=winx;
			  yycor=winy;
			  
			  /* Create Onliner Text */
			  strcpy(buff,IntStr(IRound(pdata.picxmm)));
			  strcat(buff," mm x ");
			  strcat(buff,IntStr(IRound(pdata.picymm)));
			  strcat(buff," mm");
			}
		      
		      /* Resize Buttom */
		      if ( (xxcor==-1) && (yycor==-1) && (picmode==0) )
			{
			  if ( (winx>=IRound(pdata.picposx/pdata.xpsize)+5) && (winx<=IRound((pdata.picposx+pdata.picxmm)/pdata.xpsize)-5) &&
			       (winy>=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)-5) && (winy<=IRound((pdata.picposy+pdata.picymm)/pdata.ypsize)) )
			    {
			      ycor=IRound((pdata.picymm+pdata.picposy)/pdata.ypsize)-winy; /* ??? */
			      xxcor=winx;
			      yycor=winy;						
			      fl_set_cursor(mf.form->window,XC_sb_v_double_arrow);
			      picmode=3;
			    }
			}
		      if (picmode==3)
			{
			  pdata.picymm=IRound( ( (winy+ycor) - IRound(pdata.picposy/pdata.ypsize) ) *pdata.ypsize);
			  pdata.picxmm=IRound( pdata.picymm * pdata.aspect );
			  
			  /* X-Minimal Check */
			  if (pdata.picxmm<10)
			    {
			      pdata.picxmm=10;
			      pdata.picymm=IRound(10/pdata.aspect);
			    }
			  
			  /* Y-Minimal Check */
			  if (pdata.picymm<10)
			    {
			      pdata.picymm=10;
			      pdata.picxmm=IRound(10*pdata.aspect);
			    }
			  
			  /* X Size Check */
			  if (pdata.picxmm>IRound(pdata.pagex-(pdata.picposx+pdata.pager)))
			    {
			      pdata.picxmm=IRound(pdata.pagex-(pdata.picposx+pdata.pager));
			      pdata.picymm=IRound( pdata.picxmm / pdata.aspect );
			    }
		      
			  /* Y Size Check */
			  if (pdata.picymm>IRound( pdata.pagey - ( pdata.picposy+pdata.pageb ) ) )
			    {
			      pdata.picymm=IRound(pdata.pagey-(pdata.picposy+pdata.pageb));
			      pdata.picxmm=IRound( pdata.picymm * pdata.aspect );
			    }

			  /* DPI Check */
			  a = IRound((pdata.x/(pdata.picxmm-1))*25.4);
			  if (a>719)
			    {
			      pdata.picxmm = IRound((float(pdata.x)/720)*25.4);
			      pdata.picymm = IRound(pdata.picxmm / pdata.aspect );
			    }
			
			  if ( (winx!=xxcor) || (winy!=yycor) )
			    {
			      drawpaper(xw_border);	
			    }
			  
			  xxcor=winx;
			  yycor=winy;
			  
			  /* Create Onliner Text */
			  strcpy(buff,IntStr(IRound(pdata.picxmm)));
			  strcat(buff," mm x ");
			  strcat(buff,IntStr(IRound(pdata.picymm)));
			  strcat(buff," mm");
			}
		      
		      
		    }	 
		  
		  if (strlen(buff)!=0)
		    {
		      fl_get_wingeometry(mf.form->window,&ax,&ay,&aw,&ah);
		      fl_show_oneliner(buff,mx+15+ax,my+15+ay);
		    }
		  
		  ob->wantkey = FL_KEY_ALL;
		  ob->input = 1;
		}
	    }
	}
      else if (ev == FL_RELEASE)
	{
	  fl_hide_oneliner();
	  fl_set_cursor(mf.form->window,FL_DEFAULT_CURSOR); 
      
	  xxcor=yycor=-1;
	  picmode=0;
	  Mouse=0;
	}

      /* Posthandler Sperre entfernen */
      mf.handler=0;

    }

  return(0);
}

/* Posthandler for Picture Control */
int ffpost(FL_OBJECT *ob,int ev,FL_Coord mx, FL_Coord my, int key, void *xev) /*FOLD00*/
{
  /* Integer Values */
  int a;
  /* Mouse Selection */
  static int mouse;

  /* for compiler - disable warning message */
  a=ev;
  a=key;
  a=long(xev);

  /* cout << ev << "\n"; */
  
  /* ReIconify - redraw page */
  if (ev==1)
    {
      fsdraw();
    }

  /* Posthandler entprellen */
  if (framef.handler==0)
    {
      /* Posthandler Sperre setzen */
      framef.handler=1;

      /* +++ Set Mouse Pointer for Frame Mode +++ */
      winx = mx; /* -mf.x_pwf; */
      winy = my; /* -36; */

      a=-1;
      if ( (winx>20) && (winx<170) && (winy>20) && (winy<170) )
      {
          a=0;
      }
      if ( (winx>180) && (winx<330) && (winy>20) && (winy<170) )
      {
          a=1;
      }
      if ( (winx>340) && (winx<490) && (winy>20) && (winy<170) )
      {
          a=2;
      }
      if ( (winx>20) && (winx<170) && (winy>180) && (winy<330) )
      {
          a=3;
      }
      if ( (winx>180) && (winx<330) && (winy>180) && (winy<330) )
      {
          a=4;
      }
      if ( (winx>340) && (winx<490) && (winy>180) && (winy<330) )
      {
          a=5;
      }      
          
      if (a>-1)
      {
          fl_set_cursor(framef.form->window,XC_hand1);
      }
      else
      {
          fl_set_cursor(framef.form->window,FL_DEFAULT_CURSOR);
      }
      
      /* Mausaktivit�ten */
      if ( (ev == FL_PUSH) || (ev == FL_MOUSE) )
      {
          if (mouse==0)
          {
              mouse=1;
              a=-1;
              if ( (winx>20) && (winx<170) && (winy>20) && (winy<170) )
              {
                a=0;
              }
              if ( (winx>180) && (winx<330) && (winy>20) && (winy<170) )
              {
                  a=1;
              }
              if ( (winx>340) && (winx<490) && (winy>20) && (winy<170) )
              {
                  a=2;
              }
              if ( (winx>20) && (winx<170) && (winy>180) && (winy<330) )
              {
                  a=3;
              }
              if ( (winx>180) && (winx<330) && (winy>180) && (winy<330) )
              {
                  a=4;
              }
              if ( (winx>340) && (winx<490) && (winy>180) && (winy<330) )
              {
                  a=5;
              }
              framef.xwActive=framef.fspos+a;

              fsdraw();
          }
      }
      else if (ev == FL_RELEASE)
      {
          mouse=0;
      }

      /* Posthandler Sperre entfernen */
      framef.handler=0;
    }
  return(0);
}


/* Exit Handler */
int close_cb(FL_FORM *frm,void *data) /*fold00*/
{
  XWindowAttributes attr;  

  cout << "Close Widget activated !!!\nBegin xwGUI termination...";

  /* Disable Window Refresh */
  mf.check = 0;

  /* Close any Customform */
  if (long(frm) != long(mf.form))
    {
      fl_hide_form(frm);
      fl_free_form(frm);
      frm=NULL;
    }

  /* Mainform Geometry */
  fl_get_wingeometry(mf.form->window,&mf.xpos,&mf.ypos,&mf.widthh,&mf.heightt);
  XGetWindowAttributes(fl_get_display(),mf.form->window,&attr);
  mf.xpos=mf.xpos-attr.x;
  mf.ypos=mf.ypos-attr.y;
  
  /* Close Mainform */
  fl_hide_form(mf.form);
  fl_free_form(mf.form);
  mf.form=NULL;

  /* save Prefs */
  savePref();
  
  /* Free all Memory */
  allfree(0);
  
  cout << "Ready.\n";
  
  exit(-1);
      
  return(FL_IGNORE);
}

int nclose_cb(FL_FORM *frm,void *data) /*fold00*/
{
  long a;
  a=long(data);
  a=long(frm);

  /*
  fl_show_alert("Bedienungsfehler !!!","So kann dieses Programm nicht beendet werden !!!","Bitte, bet�tigen Sie das `Beenden` Button !!!",0);
  */
  return(FL_IGNORE);
}
