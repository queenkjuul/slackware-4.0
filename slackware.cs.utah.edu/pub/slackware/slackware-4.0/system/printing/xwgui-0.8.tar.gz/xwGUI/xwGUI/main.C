/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include "xwgui.h"

#include "Pixmaps/frames.xpm"
#include "Pixmaps/noframes.xpm"

/* HomeDirectory */
char *user;
char xpuser[1024]="";

/* Directory-Path */
char xwpath[1024]="";
char xwpathh[1024]="";  /* For Path Manipulations */

/* WorkFile */
char xwwork[1024]="";   /* Picture File Selection */
int xwworkflag=0;       /* Picture File active 0=Deactive 1=active */

/* Page Datas */
struct pagedata pdata;

/* SF */
struct serviceform sf;

/* Mainform */
extern struct mainform mf;

/* Frameform */
extern struct frameform framef;

/* Printer General Settings */
extern struct XWGprint xwgp;

/* String Vars */
const char *strptr;
char astr[256],bstr[256],cstr[256];

/* Integer Values */
int a,b,c,d;

/* Mouseposition - Mouse Datas */
Window win;
int winx,winy;
int xcor,ycor,xxcor,yycor;
int picmode;
unsigned int wink;

/* Iconify Vars */
int icommand;       /* Internal Command Code */
XWindowAttributes attr;

main(int argc, char *argv[]) 
{
  fl_initialize(&argc, argv, "Xwgui", 0, 0);

  /* Default Form Size */
  mf.width = 640;
  mf.height = 480;
  mf.widthh = 640;
  mf.heightt = 480;

  /* Default Frameform */
  framef.xwXSize=130;   /* 130 mm */
  framef.xwYSize=90;    /*  90 mm */
  framef.xwActFrame=0;  /* Frame Mode Offline */
  framef.xwActive=-1;   /* Selected FrameSet */

  int pid;        /* Prozess ID */
  mf.picture = 0; /* Picture not selectet             
                     ( NICHT identisch mit xwworkflag. 
                     Flag um zu sehen ob �berhaupt 
                     schonmal ein Bild ausgew�hlt wurde. */
  mf.check = 0;   /* Resizing Check */
  mf.resize = 0;  /* Resizing Mode */
  mf.handler = 0; /* Posthandler noch nicht aufgerufen */

  xcor=ycor=-1;   /* Resizing Position */
  xxcor=yycor=-1;
  picmode=0;      /* Picture Mode 
		      0 - None
                      1 - Move
                      2 - Resizing right
                      3 - Resizing buttom
		  */

  /* Prozess sauber abtrennen */
  signal(SIGCHLD,SIG_IGN);

  /* Pdata Defaults */
  pdata.page=2;      /* A4 */
  pdata.pagel=20;    /* Page Borders */
  pdata.pager=20;
  pdata.paget=20;
  pdata.pageb=20;
  pdata.landscape=0; /* Landscape Offliner */
  pdata.rotate=0;    /* Image Rotated ??? */
  xwgp.prtselect=1;  /* Print Mode */

  /* Default Viewer */
  strcpy(xwgp.viewer,"xv");

  /* File-Browser */
  int brwline;
  char brwstr[256];

  /* HomeDirectory */
  user=getenv("HOME");
  strcpy(xpuser,user);
  
  /* Home-Preferences */
  strcpy(astr,xpuser);
  strcat(astr,"/.xwgui");
  a=mkdir(astr,S_IRWXU);

  setByteOrder(); /* jj neue Funktion */

  /* Quality & Paper - no selected */
  xwgp.actQuality=-1;
  xwgp.actPaper=-1;

  /* Printer Setting */
  strcpy(xwgp.printer,"");
  /* Printer File */
  xwgp.prtfanz=-1;

  /* Load Pref File�s */
  strcpy(astr,xpuser);
  strcat(astr,"/.xwgui/xwgui.rc");
  xwParser(astr,1);

  allfree(0);

  /* Gimp Modus */
  xwgp.gimp = 0;
  if (argc == 2)
    {
      strcpy(astr,argv[1]);
      strptr = strMids(astr,1,5);
      strcpy(bstr,strptr);
      if (strcmp(bstr,"-gimp") == 0) 
	{
     	  strptr = strMids(astr,6,strlen(astr)-5);
	  strcpy(astr,strptr);

	  strptr = strGetFirst(astr,"x");
	  if (strptr != NULL)
	    {
	      strcpy(bstr,strptr);
	      strptr = strMids(astr,strlen(bstr)+2,strlen(astr)-(strlen(bstr)+1));
	      strcpy(cstr,strptr);
	     
	      pdata.x = atoi(bstr);
	      pdata.y = atoi(cstr);
	      pdata.aspect = float(pdata.x)/float(pdata.y);
	      xwworkflag=1;

	      /* Deactivate Frame Mode */
	      framef.xwActFrame=0;
	      pdata.rotate=0;
	      mf.picture = 1;
	      xwgp.gimp = 1;
	      strcpy(xwwork,"/");
	    }
	}     
    }
     
  main_gui();

  /* Form Doublebuffering */
#ifdef xwguiDB
 fl_set_form_dblbuffer(mf.form,1);      
#endif

  fl_set_form_geometry(mf.form,mf.xpos,mf.ypos,mf.width,mf.height);
  fl_prepare_form_window(mf.form,FL_PLACE_POSITION|FL_FREE_SIZE,FL_FULLBORDER,xwInfo);
  /* Display Window */
  fl_show_form_window(mf.form);

  /* Post Handler for Picture Control */
  fl_set_object_posthandler(mf.XWBackground,post);
  /* Exit Handler */
  fl_set_form_atclose(mf.form,close_cb,"1");

  /* Window Resizing Check */   
  mf.check=1;

  /* Set Paper Size */
  setpaper();

  if (xwgp.gimp == 1)
    {
      fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
      drawpaper(xw_calcpic);
    }
  drawpaper(xw_paper);

  /* Scan Directory */
  if (xwgp.gimp == 0)
    {
      scandir();
    }

  if (int(strlen(xwgp.printer)) > 0)
    {
      fl_set_object_label(mf.XWPrinter,xwgp.printer);
      fl_set_object_color(mf.XWPrinter,FL_COL1,FL_MCOL);

      /* Printer Script */
      strcpy(astr,"/usr/local/lib/xwgui/");
      strcat(astr,xwgp.printer);
      xwParser(astr,0);

      /* Printer Script ( User Settings )*/
      strcpy(astr,xpuser);
      strcat(astr,"/.xwgui/");
      strcat(astr,xwgp.printer);
      xwParser(astr,0);
    }

  setpref();

  /* Set Vars */
  setDefault();

  if (xwgp.actQuality > 0)
    {
      if (xwgp.actPaper > 0)
	{
       	  setPrtSet(xwgp.quality[xwgp.actQuality],xwgp.paper[xwgp.actQuality][xwgp.actPaper]);
	}
    }

  mf.ready=0;
  while (mf.ready == 0)
    {
      mf.obj = fl_do_forms();

      /* ###########################################
	 # Control Panel                           #
         ########################################### */

      /* Info */
      if (mf.obj == mf.XWInfo)
	{
	  fl_deactivate_form(mf.form);
	  info_gui();
	  fl_activate_form(mf.form);
	}

      /* Print */
      if (mf.obj == mf.XWPrint)
	{
	  fl_deactivate_form(mf.form);
	  if (xwgp.gimp == 1)
	    {
	      mf.check = 0;
	      mf.ready = 1;
	    }
	  xwprint();
	  fl_activate_form(mf.form);
	}

      /* Exit */
      if (mf.obj == mf.XWquit) 
	{
	  mf.check = 0;
	  mf.ready = 1;
	}

      /* Frames */
      if ( (mf.obj == mf.XWPicFrames) && (mf.picture==1) )
      {
          if (framef.xwActFrame==0)
          {
              framef.xwActFrame=1;
              framef.xwActive=-1;
              fl_set_pixmap_data(mf.XWPicFrames,frames_xpm);

              /* Selected Frame Position */
              framef.xwXF=0;
              framef.xwYF=0;

              drawpaper(xw_border);
          }
          else
          {
              framef.xwActFrame=0;
              framef.xwActive=-1;
              fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);

              drawpaper(xw_border);
          }
      }

      /* Swap */
      if (mf.obj == mf.XWswap)
      {
          /* Swap Value */
          a=framef.xwXSize;
          framef.xwXSize=framef.xwYSize;
          framef.xwYSize=a;

          /* check Maxsize */
          if (framef.xwXSize > IRound(pdata.pagex-(pdata.pagel+pdata.pager)) )
          {
              framef.xwXSize = IRound(pdata.pagex-(pdata.pagel+pdata.pager));
          }
          if (framef.xwYSize > IRound(pdata.pagey-(pdata.paget+pdata.pageb)) )
          {
              framef.xwYSize = IRound(pdata.pagey-(pdata.paget+pdata.pageb));
          }

          /* Set Values */
          strptr = IntStr(framef.xwXSize);
          strcpy(astr,strptr);
          fl_set_input(mf.XWxsize,astr);
          strptr = IntStr(framef.xwYSize);
          strcpy(astr,strptr);
	  fl_set_input(mf.XWysize,astr);

          /* Picture selected ??? */
          if (mf.picture==1)
          {

              framef.xwActFrame=1;
              framef.xwActive=-1;
              fl_set_pixmap_data(mf.XWPicFrames,frames_xpm);

              /* Selected Frame Position */
              framef.xwXF=0;
              framef.xwYF=0;

              drawpaper(xw_border);

          }
      }

      /* Frame Input Fields */
      if (mf.picture==1)
      {
          b=0;
          strptr = fl_get_input(mf.XWxsize);
          strcpy(astr,strptr);
          a = atoi(astr);
          if (a != framef.xwXSize)
          {
              framef.xwXSize = a;
              if (a < 30)
              {
                  framef.xwXSize = 30;
              }
              if (a > (pdata.pagex-(pdata.pagel+pdata.pager)) )
              {
                  framef.xwXSize = IRound(pdata.pagex-(pdata.pagel+pdata.pager));
              }
              strptr = IntStr(framef.xwXSize);
              strcpy(astr,strptr);
              fl_set_input(mf.XWxsize,astr);
	      b = 1;
          }
          strptr = fl_get_input(mf.XWysize);
          strcpy(astr,strptr);
          a = atoi(astr);
	  if (a != framef.xwYSize)
          {
              framef.xwYSize = a;
              if (a < 30)
              {
                  framef.xwYSize = 30;
              }
              if (a > (pdata.pagey-(pdata.paget+pdata.pageb)) )
              {
                  framef.xwYSize = IRound(pdata.pagey-(pdata.paget+pdata.pageb));
              }
              strptr = IntStr(framef.xwYSize);
              strcpy(astr,strptr);
              fl_set_input(mf.XWysize,astr);
              b = 1;
          }

          if (b != 0)
          {
              framef.xwActFrame=1;
              framef.xwActive=-1;
              fl_set_pixmap_data(mf.XWPicFrames,frames_xpm);

              /* Selected Frame Position */
              framef.xwXF=0;
              framef.xwYF=0;

              drawpaper(xw_border);
          }
      }

      /* FrameSets */
      if ( (mf.obj == mf.XWPicFrameSet) && (mf.picture==1) )
      {
          /* Selected Frame Position */
          framef.xwXF=0;
          framef.xwYF=0;

          fl_deactivate_form(mf.form);
          frameset();
          fl_activate_form(mf.form);

          if (framef.xwActive>-1)
          {
	    framef.xwActFrame=1;
	    fl_set_pixmap_data(mf.XWPicFrames,frames_xpm);
              drawpaper(xw_paper);
          }
      }

      /* ###########################################
	 # Pref Control Panel                      #
         ########################################### */

      /* Save Settings */
      if (mf.obj == mf.XWPrefSave)
	{
	  fl_deactivate_form(mf.form);
	  savePref();
	  fl_activate_form(mf.form);
	}

      /* Pref Settings */
      if (mf.obj == mf.XWPrefPref)
	{
	  fl_deactivate_form(mf.form);
	  PrefPanel();
	  fl_activate_form(mf.form); 
	}

      /* ###########################################
	 # Pref Settings                           #
         ########################################### */

      /* Printer Selection */
      if (mf.obj == mf.XWPrinter)
	{
	  fl_deactivate_form(mf.form);
	  strptr = getPrinter();
	  strcpy(astr,strptr);
	  fl_activate_form(mf.form);
	  if (int(strlen(astr))>0)
	    {
	      strcpy(xwgp.printer,astr);

	      /* Printerscript laden */
	      if (strlen(xwgp.printer) > 0)
		{
		  fl_set_object_label(mf.XWPrinter,xwgp.printer);
		  fl_set_object_color(mf.XWPrinter,FL_COL1,FL_MCOL);
		  
		  allfree(1);
		  
		  /* Printer Script */
		  strcpy(astr,"/usr/local/lib/xwgui/");
		  strcat(astr,xwgp.printer);
		  xwParser(astr,2);

		  /* Printer Script ( User Settings )*/
		  strcpy(astr,xpuser);
		  strcat(astr,"/.xwgui/");
		  strcat(astr,xwgp.printer);
		  xwParser(astr,1);
		  
		  setpref();
		  
		  /* Set Vars */
		  setDefault();
		  setPrtSet(xwgp.quality[xwgp.actQuality],xwgp.paper[xwgp.actQuality][xwgp.actPaper]);
		
		  /* Save Vars */
		  setPrtSet("","");
		}
	    }
	}

      /* Quality */
      if (mf.obj == mf.XWQuality)
	{
	  if (fl_get_choice(mf.XWQuality)>0)
	    {
	      /* Save Vars */
	      setPrtSet("","");
	      
	      if (xwgp.actQuality > 0)
		{
		  xwgp.actQuality = fl_get_choice(mf.XWQuality);
		  xwgp.actPaper = 1;
		  /* Set Vars */
		  setDefault();
		  setPrtSet(xwgp.quality[xwgp.actQuality],xwgp.paper[xwgp.actQuality][xwgp.actPaper]);
		  
		  setpref();
		}
	    }
	  else
	    {
	      fl_set_choice(mf.XWQuality,xwgp.actQuality);
	    }
	}

      /* Paper */
      if (mf.obj == mf.XWSheets)
	{
	  if (fl_get_choice(mf.XWSheets)>0)
	    {
	      /* Save Vars */
	      setPrtSet("","");
	      
	      if (xwgp.actPaper > 0)
		{ 
		  xwgp.actPaper = fl_get_choice(mf.XWSheets);
		  /* Set Vars */
		  setDefault();
		  setPrtSet(xwgp.quality[xwgp.actQuality],xwgp.paper[xwgp.actQuality][xwgp.actPaper]);
		  
		  setpref();
		}
	    }
	  else
	    {
	      fl_set_choice(mf.XWSheets,xwgp.actPaper);
	    }
	}
      /* Pref A */
      if (mf.obj == mf.XWPrefA)
	{
	  fl_deactivate_form(mf.form);
	  setForm(1);
	  fl_activate_form(mf.form);
	}
      /* Pref B */
      if (mf.obj == mf.XWPrefB)
	{
	  fl_deactivate_form(mf.form);
	  setForm(2);
	  fl_activate_form(mf.form);
	}
      /* Pref C */
      if (mf.obj == mf.XWPrefC)
	{
	  fl_deactivate_form(mf.form);
	  setForm(3);
	  fl_activate_form(mf.form);
	}

      /* ###########################################
	 # Page Settings                           #
         ########################################### */

      /* Paperformat */
      if (mf.obj == mf.XWPapers)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
	  
	  if (fl_get_choice(mf.XWPapers)>0) 
	    {
	      pdata.page = fl_get_choice(mf.XWPapers);
	      setpaper();
	      drawpaper(xw_calcpic);
	      drawpaper(xw_paper);
	    }
	  else
	    {
	      fl_set_choice(mf.XWPapers,pdata.page);
	    }
	}

      /* Landscape */
      if (mf.obj == mf.XWLandscape)
	{
	  if (pdata.landscape == 0)
	    {
	      /* -> */
	      pdata.buffer = float(pdata.pagel);
	      pdata.pagel = pdata.pageb;
	      pdata.pageb = pdata.pager;
	      pdata.pager = pdata.paget;
	      pdata.paget = int(pdata.buffer);
	      pdata.landscape = 1;
	      pdata.buffer = pdata.pagex;
	      pdata.pagex = pdata.pagey;
	      pdata.pagey = pdata.buffer;
	      strcpy(astr,"@->");
	    }
	  else
	    {
	      /* <- */
	      pdata.buffer = float(pdata.pagel);
	      pdata.pagel = pdata.paget;
	      pdata.paget = pdata.pager;
	      pdata.pager = pdata.pageb;
	      pdata.pageb = int(pdata.buffer);
	      pdata.landscape = 0;
	      pdata.buffer = pdata.pagex;
	      pdata.pagex = pdata.pagey;
	      pdata.pagey = pdata.buffer;
	      strcpy(astr,"@8->");
	    }

	  fl_set_object_label(mf.XWDirection,astr);

	  fl_set_button(mf.XWLandscape,pdata.landscape);
	  pdata.paspect=pdata.pagex/pdata.pagey;

	  /* Border Parameters */
	  strptr = IntStr(pdata.pagel);
	  strcpy(astr,strptr);
	  fl_set_input(mf.XWBorderl,astr);
	  strptr = IntStr(pdata.pager);
	  strcpy(astr,strptr);
	  fl_set_input(mf.XWBorderr,astr);
	  strptr = IntStr(pdata.paget);
	  strcpy(astr,strptr);
	  fl_set_input(mf.XWBordert,astr);
	  strptr = IntStr(pdata.pageb);
	  strcpy(astr,strptr);
	  fl_set_input(mf.XWBorderb,astr);

	  /* Frame Modus */
	  if ( (framef.xwActFrame==1) && (framef.landscape!=pdata.landscape) )
          {
              /* FrameSet */
              if (framef.xwActive==-1)
              {
                  /* recalculate Frames */
                  
                  /* Swap Value */
                  a=framef.xwXSize;
                  framef.xwXSize=framef.xwYSize;
                  framef.xwYSize=a;

                  /* Set Values */
                  strptr = IntStr(framef.xwXSize);
                  strcpy(astr,strptr);
                  fl_set_input(mf.XWxsize,astr);
                  strptr = IntStr(framef.xwYSize);
                  strcpy(astr,strptr);
                  fl_set_input(mf.XWysize,astr);

                  if (framef.landscape==0)
                  {
                      a=framef.xwXF;
                      framef.xwXF=framef.xwYF;
                      framef.xwYF=a;

                      framef.xwXF=(framef.xwYFrames-1)-(framef.xwXF);
                  }
                  if (framef.landscape==1)
                  {
                      a=framef.xwXF;
                      framef.xwXF=framef.xwYF;
                      framef.xwYF=a;

                      framef.xwYF=(framef.xwXFrames-1)-(framef.xwYF);
                  }
              }
	    }
          else
          {
              /* Normal Paper and Border Display */
              drawpaper(xw_calcpic);
          }
              
	  drawpaper(xw_paper);

	}

      /* DPI */
      if (mf.obj == mf.XWDPImm)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);

	  if (xwworkflag == 1)
	    {
	      if (pdata.picxmm>19)
		{
		  a = IRound((pdata.x/(pdata.picxmm-10))*25.4);
		  if ( (pdata.landscape==0) && (pdata.rotate==1) )
		    {
		      a = IRound((pdata.y/ ((pdata.picxmm-10)/pdata.aspect) )*25.4);
		    }
		  if ( (pdata.landscape==1) && (pdata.rotate==0) )
		    {
		      a = IRound((pdata.y/ ((pdata.picxmm-10)/pdata.aspect) )*25.4);
		    }
		  if (a<=720)
		    {
		      pdata.picxmm = pdata.picxmm-10;
		      pdata.picymm = pdata.picxmm / pdata.aspect;
		      drawpaper(xw_border);
		    }
		}
	    }
	}	  
      /* DPI */
      if (mf.obj == mf.XWDPIm)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
	
	  if (xwworkflag == 1)
	    {
	      if (pdata.picxmm>10)
		{
		  a = IRound((pdata.x/(pdata.picxmm-1))*25.4);
		  if ( (pdata.landscape==0) && (pdata.rotate==1) )
		    {
		      a = IRound((pdata.y/ ((pdata.picxmm-1)/pdata.aspect) )*25.4);
		    }
		  if ( (pdata.landscape==1) && (pdata.rotate==0) )
		    {
		      a = IRound((pdata.y/ ((pdata.picxmm-1)/pdata.aspect) )*25.4);
		    }
		  if (a<=719)
		    {
		      pdata.picxmm = pdata.picxmm-1;
		      pdata.picymm = pdata.picxmm / pdata.aspect;
		      drawpaper(xw_border);
		    }
		}
	    }
	}
      /* DPI */
      if (mf.obj == mf.XWDPIp)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
     
	  if (xwworkflag == 1)
	    {
	      if ( (pdata.picxmm+1+pdata.picposx) <= (pdata.pagex-pdata.pager) )
		{
		  if ( (((pdata.picxmm+1)/pdata.aspect)+pdata.picposy) <= (pdata.pagey-float(pdata.pageb)) )
		    {
		      pdata.picxmm = pdata.picxmm+1;
		      pdata.picymm = pdata.picxmm / pdata.aspect;
		      drawpaper(xw_border);		  
		    }
		}
	    }
	}	  
      /* DPI */
      if (mf.obj == mf.XWDPIpp)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
     
	  if (xwworkflag == 1)
	    {
	      /*	      if ( (pdata.picxmm+10+pdata.picposx) <= (pdata.pagex-pdata.pager) ) */
	      if ( (pdata.picxmm+10+pdata.picposx) <= (pdata.pagex-pdata.pager) )
		{
		  if ( (((pdata.picxmm+10)/pdata.aspect)+pdata.picposy) <= (pdata.pagey-float(pdata.pageb)) )
		    {
		      pdata.picxmm = pdata.picxmm+10;
		      pdata.picymm = pdata.picxmm / pdata.aspect;
		      drawpaper(xw_border);
		    }
		}
	    }
	}
      /* Mover */
      if (mf.obj == mf.XWMovel)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
     
	  if (xwworkflag == 1)
	    {
	      if (pdata.picposx>pdata.pagel)
		{
		  pdata.picposx = pdata.picposx-1;		  
		  if (pdata.pagel>pdata.picposx)
		    {
		      pdata.picposx = pdata.pagel;
		    }
		  drawpaper(xw_border);
		}
	    }
	}
      if (mf.obj == mf.XWMover)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
       
	  if (xwworkflag == 1)
	    {
	      if (pdata.picposx+pdata.picxmm<pdata.pagex-pdata.pager)
		{
		  pdata.picposx = pdata.picposx+1;
		  if (pdata.picposx+pdata.picxmm>pdata.pagex-pdata.pager)
		    {
		      pdata.picposx = pdata.pagex-(pdata.pager+pdata.picxmm);
		    }
		  drawpaper(xw_border);
		}
	    }
	}	  
      if (mf.obj == mf.XWMovet)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
       
	  if (xwworkflag == 1)
	    {
	      if (pdata.picposy>pdata.paget)
		{
		  pdata.picposy = pdata.picposy-1;		  
		  if (pdata.paget>pdata.picposy)
		    {
		      pdata.picposy = pdata.paget;
		    }
		  drawpaper(xw_border);
		}
	    }
	}
      if (mf.obj == mf.XWMoveb)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
      
	  if (xwworkflag == 1)
	    {
	      if (pdata.picposy+pdata.picymm<pdata.pagey-pdata.pageb)
		{
		  pdata.picposy = pdata.picposy+1;		  
		  if (pdata.picposy+pdata.picymm>pdata.pagey-pdata.pageb)
		    {
		      pdata.picposy = pdata.pagey-(pdata.pageb+pdata.picymm);
		    }
		  drawpaper(xw_border);
		}
	    }
	}	  
      /* Mover 10 mm */
      if (mf.obj == mf.XWMovell)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
      
	  if (xwworkflag == 1)
	    {
	      if (pdata.picposx>pdata.pagel)
		{
		  pdata.picposx = pdata.picposx-10;		  
		  if (pdata.pagel>pdata.picposx)
		    {
		      pdata.picposx = pdata.pagel;
		    }
		  drawpaper(xw_border);
		}
	    }
	}
      if (mf.obj == mf.XWMoverr)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
	
	  if (xwworkflag == 1)
	    {
	      if (pdata.picposx+pdata.picxmm<pdata.pagex-pdata.pagel)
		{
		  pdata.picposx = pdata.picposx+10;		  
		  if (pdata.picposx+pdata.picxmm>pdata.pagex-pdata.pager)
		    {
		      pdata.picposx = pdata.pagex-(pdata.pager+pdata.picxmm);
		    }
		  drawpaper(xw_border);
		}
	    }
	}	  
      if (mf.obj == mf.XWMovett)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
       
	  if (xwworkflag == 1)
	    {
	      if (pdata.picposy>pdata.paget)
		{
		  pdata.picposy = pdata.picposy-10;		  
		  if (pdata.paget>pdata.picposy)
		    {
		      pdata.picposy = pdata.paget;
		    }
		  drawpaper(xw_border);
		}
	    }
	}
      if (mf.obj == mf.XWMovebb)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
       
	  if (xwworkflag == 1)
	    {
	      if (pdata.picposy+pdata.picymm<pdata.pagey-pdata.pageb)
		{
		  pdata.picposy = pdata.picposy+10;		  
		  if (pdata.picposy+pdata.picymm>pdata.pagey-pdata.pageb)
		    {
		      pdata.picposy = pdata.pagey-(pdata.pageb+pdata.picymm);
		    }
		  drawpaper(xw_border);
		}
	    }
	}	  

      /* Rotate */
      if (mf.obj == mf.XWRotate)
	{
	  if (pdata.rotate == 0)
	    {
	      pdata.rotate=1;
	      pdata.puffer=pdata.x;
	      pdata.x=pdata.y;
	      pdata.y=pdata.puffer;
		  
	      pdata.aspect = float(pdata.x)/float(pdata.y);
	    }
	  else
	    {
	      if (pdata.rotate == 1)
		{
		  pdata.rotate=0;
		  pdata.puffer=pdata.x;
		  pdata.x=pdata.y;
		  pdata.y=pdata.puffer;
		  
		  pdata.aspect = float(pdata.x)/float(pdata.y);
		}
	    }
	  
	  if (framef.xwActFrame==1)
	    {
	      picframes();
	      drawpaper(xw_frames); 
	    }
	  else
	    {
	      drawpaper(xw_calcpic);
	      drawpaper(xw_border); 
	    }

	}

      /* FullSize */
      if (mf.obj == mf.XWFullSize)
	{
	  if (framef.xwActFrame==0)
	    {
	      drawpaper(xw_fullsize);
	      drawpaper(xw_border); 
	    }

	}

      /* Center */
      if (mf.obj == mf.XWHCenter)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
      
	  if (xwworkflag == 1)
	    {
	      pdata.picposx = ((pdata.pagex-(pdata.picxmm+pdata.pagel+pdata.pager)) /2)+pdata.pagel;
	      drawpaper(xw_border);
	    }
	}
      if (mf.obj == mf.XWVCenter)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
    
	  if (xwworkflag == 1)
	    {
	      pdata.picposy = ((pdata.pagey-(pdata.picymm+pdata.paget+pdata.pageb)) /2)+pdata.paget;
	      drawpaper(xw_border);
	    }
	}

      /* Viewer */
      if (mf.obj == mf.XWViewer)
	{
	  if (int(strlen(xwwork))>0)
	    {
	      strcpy(astr,xwgp.viewer);
	      strcat(astr," ");
	      strcat(astr,xwwork);
	      pid = fl_exe_command(astr,0);
	    }
	}

      /* Reset */
      if (mf.obj == mf.XWReset)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);
     
	  /* Pdata Defaults */
	  pdata.page=2;
	  fl_set_choice(mf.XWPapers,pdata.page);

	  /* Landscape offline */
	  pdata.landscape=0;
	  fl_set_button(mf.XWLandscape,pdata.landscape);

	  setpaper();
	  drawpaper(xw_calcpic);
	  drawpaper(xw_paper);
      	}

      /* ###########################################
	 # File Browser                            #
         ########################################### */

      /* Drawer Browser */
      if (mf.obj == mf.XWBrowser)
	{
	  brwline = fl_get_browser(mf.XWBrowser);
	  strcpy(xwpath,"/");
	  if (brwline > 1)
	    {
	      for (a=2 ; a<=brwline ; a++)
		{
		  strptr = fl_get_browser_line(mf.XWBrowser,a);
		  strcat(xwpath,strptr);
		  strcat(xwpath,"/");
		}
	    }
	  scandir();
	}

      /* File Browser */
      if (mf.obj == mf.XWFile)
	{
	  brwline = fl_get_browser(mf.XWFile);
	  if (brwline > 0)
	    {
	      strptr = fl_get_browser_line(mf.XWFile,brwline);
	      strcpy(brwstr,strptr);

	      /* Path-Selection */
	      if (strcmp(brwstr,"@C7<DIR.> .."))
		{
		  /* File or Drawer Entry */
		  strptr = strMids(brwstr,1,6);
		  strcpy(astr,strptr);
		  if (strcmp(astr,"@C7<DI") == 0)
		    {
		      /* Drawer */
		      strptr = strMids(brwstr,11,strlen(brwstr)-10);
		      strcpy(astr,strptr);
		      strcat(xwpath,astr);
		      strcat(xwpath,"/");
		      scandir();
		    }
		  else
		    {
		      /* File */
		      strcpy(xwwork,xwpath);
		      strptr = strMids(brwstr,8,strlen(brwstr)-7);
		      strcpy(astr,strptr);
		      strcat(xwwork,astr);
		      /* File-Format-Check */
		      xwworkflag=0;
		      
		      /* XXX File-Format-Check */		
		      strptr = getFileFormat(xwwork);
		      strcpy(astr,strptr);
		      /* GIF-File */
		      if (strcmp(astr,"GIF") == 0) checkgif();
		      /* PNG-File */
		      /*
		      if (strcmp(astr,"PNG") == 0))
		      */
		      /* PPM-File */
		      if (strcmp(astr,"PPM") == 0) checkppm();
		      /* TIFF-File */
		      if (strcmp(astr,"TIFF") == 0) checktiff();
	              /* BMP-File */
		      if (strcmp(astr,"BMP") == 0) checkbmp();
		      /* JPG-File */
		      if (strcmp(astr,"JPEG") == 0) checkjpg();
			
		      /* Draw Picture Format */
		      if (xwworkflag == 1)
			{
			  /* Deactivate Frame Mode */
			  framef.xwActFrame=0;
			  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);

   			  pdata.rotate=0;
			  mf.picture = 1;
			  drawpaper(xw_calcpic);
			  drawpaper(xw_border);
			}
		    }
		}
	      else
		{
		  /* Parent */
		  if (strlen(xwpath)>1)
		    {
		      strcpy(astr," ");
		      memmove(xwpath+strlen(xwpath)-1,xwpath+strlen(xwpath),1); 
		      memmove(astr,(xwpath+strlen(xwpath))-1,1);
		      while (strcmp(astr,"/")!=0)
			{
			  memmove(xwpath+strlen(xwpath)-1,xwpath+strlen(xwpath),1); 
			  memmove(astr,(xwpath+strlen(xwpath))-1,1);	      
			}
		    }
		  scandir();	      
		}
	    }
	}


      /* Drawer Input */
      if (xwgp.gimp == 0)
	{
	  strptr = fl_get_input(mf.XWDrawer);
	  strcpy(xwpathh,strptr);
	  if (strcmp(xwpathh,xwpath))
	    {
	      strcpy(xwpath,xwpathh);
	      if (strlen(xwpath) == 0) 
		{
		  strcpy(xwpath,"/");
		}
	      else
		{
		  strptr = strMids(xwpath,strlen(xwpath),1);
		  strcpy(astr,strptr);
		  if (strcmp(astr,"/"))
		    {
		      strcat(xwpath,"/");
		    }
		  strptr = strMids(xwpath,1,1);
		  strcpy(astr,strptr);
		  if (strcmp(astr,"/"))
		    {
		      strcpy(xwpathh,"/");
		      strcat(xwpathh,xwpath);
		      strcpy(xwpath,xwpathh);
		    }
		}
	      scandir();
	    }
	}

      /* Set Page Borders */
      b = 0; /* Change Border ??? 0 = No , 1 = Yes */
      strptr = fl_get_input(mf.XWBorderl);
      strcpy(astr,strptr);
      a = atoi(astr);
      if (a != pdata.pagel)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);

	  pdata.pagel = a;
	  if (pdata.pagel < 0)
	    {
	      pdata.pagel = 0;
	    }
	  if (pdata.pagel > 40)
	    {
	      pdata.pagel = 40;
	    }
	  strptr = IntStr(pdata.pagel);
	  strcpy(astr,strptr);
	  fl_set_input(mf.XWBorderl,astr);
	  b = 1;
	}
      strptr = fl_get_input(mf.XWBorderr);
      strcpy(astr,strptr);
      a = atoi(astr);
      if (a != pdata.pager)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);

	  pdata.pager = a;
	  if (pdata.pager < 0)
	    {
	      pdata.pager = 0;
	    }
	  if (pdata.pager > 40)
	    {
	      pdata.pager = 40;
	    }
	  strptr = IntStr(pdata.pager);
	  strcpy(astr,strptr);
	  fl_set_input(mf.XWBorderr,astr);
	  b = 1;
	}
      strptr = fl_get_input(mf.XWBordert);
      strcpy(astr,strptr);
      a = atoi(astr);
      if (a != pdata.paget)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);

	  pdata.paget = a;
	  if (pdata.paget < 0)
	    {
	      pdata.paget = 0;
	    }
	  if (pdata.paget > 40)
	    {
	      pdata.paget = 40;
	    }
	  strptr = IntStr(pdata.paget);
	  strcpy(astr,strptr);
	  fl_set_input(mf.XWBordert,astr);
	  b = 1;
	}
      strptr = fl_get_input(mf.XWBorderb);
      strcpy(astr,strptr);
      a = atoi(astr);
      if (a != pdata.pageb)
	{
	  /* Deactivate Frame Mode */
 	  framef.xwActFrame=0;
	  fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);

	  pdata.pageb = a;
	  if (pdata.pageb < 0)
	    {
	      pdata.pageb = 0;
	    }
	  if (pdata.pageb > 40)
	    {
	      pdata.pageb = 40;
	    }
	  strptr = IntStr(pdata.pageb);
	  strcpy(astr,strptr);
	  fl_set_input(mf.XWBorderb,astr);
	  b = 1;
	}
      if (b > 0 )
	{
            drawpaper(xw_calcpic);
            drawpaper(xw_paper); 	  
	}

    }
  /* Disable Window Refresh */
  mf.check=0;

  /* Mainform Geometry */
  fl_get_wingeometry(mf.form->window,&mf.xpos,&mf.ypos,&mf.widthh,&mf.heightt);
  XGetWindowAttributes(fl_get_display(),mf.form->window,&attr);
  mf.xpos=mf.xpos-attr.x;
  mf.ypos=mf.ypos-attr.y;

  fl_hide_form(mf.form);
  fl_free_form(mf.form);
  mf.form = NULL;

  /* save Prefs */
  savePref();

  /* Free all Memory */
  allfree(0);

  return 0;
}

/* ##################################### */
/* #                                   # */
/* # FILE & DIRECTORY BROWSER ROUTINES # */
/* #                                   # */
/* ##################################### */

/* Scan Directory into Browser */
void scandir(void) /*fold00*/
{
  /* struct stat     statpuff; */
  /* struct dirent   *direntz; */
  DIR             *dirz;

  char cpath[1024],direntry[256];

  /* Path Browser */
  fl_clear_browser(mf.XWBrowser);

  strcpy(cpath,xwpath);
  if (strlen(cpath)>1)
    {
      strptr = strMids(cpath,2,strlen(cpath)-2);
      strcpy(cpath,strptr);
    }

  fl_addto_browser(mf.XWBrowser,"/");
  if (strlen(cpath)>1)
    {
      strptr = strtok(cpath,"/");
      while (strptr != NULL)
	{
	  strcpy(direntry,strptr);
	  fl_addto_browser(mf.XWBrowser,direntry);
	  strptr = strtok(NULL,"/");
	}
    }

  /* Path Input */
  fl_set_input(mf.XWDrawer,xwpath);

/* Form Doublebuffering */
#ifdef xwguiDB
 fl_set_form_dblbuffer(mf.form,0);      
#endif
  
  fl_show_form(mf.form,FL_PLACE_CENTER,FL_NOBORDER,"wxGUI V0.1 - License: General Public License (GPL)");
  
  fl_set_object_color(mf.XWFile,FL_TOMATO,FL_YELLOW);

  /* File Browser */
  fl_clear_browser(mf.XWFile);

  /* Open Directory */
  if ( (dirz = opendir(xwpath)) != NULL)
    {
    	fl_set_dirlist_sort(FL_ALPHASORT);
    
    	int nfiles = 0;
	const FL_Dirlist *dl = fl_get_dirlist(xwpath,"*.*",&nfiles,0), *ds;
	const FL_Dirlist *dlend = dl + nfiles;
	
	fl_freeze_form(mf.form);
	
	for (ds = dl ; dl < dlend ; dl++)
	 {
	 
	  if ( ( strcmp(dl->name,".")) )
	   {
	     if (dl->type == FT_DIR)
	      {
	        strcpy(bstr,"@C7<DIR.> ");
		strcat(bstr,dl->name);
		fl_add_browser_line(mf.XWFile,bstr);
	      }
	     if (dl->type == FT_FILE)
	      {
	       if (strlen(dl->name) > 3)
	        {

		 strcpy(cpath,xwpath);
		 strcat(cpath,dl->name);
		 strptr = getFileFormat(cpath);
		 
		 if (strcmp(strptr,"") != 0) 
		   {
		     strcpy(bstr,"<FILE> ");
		     strcat(bstr,dl->name);	
		     fl_add_browser_line(mf.XWFile,bstr);
		   }
		}
	      }
	     if (dl->type == FT_LINK)
	      {
	       strcpy(bstr,"<LINK> ");
	       strcat(bstr,dl->name);
	       fl_add_browser_line(mf.XWFile,bstr);
	      }	          
	   }
	 }

	fl_unfreeze_form(mf.form);
	fl_free_dirlist((FL_Dirlist*)ds);  
	
      closedir(dirz);

    }
  else
    {
      fl_add_browser_line(mf.XWFile,"@C7<DIR.> ..");
    }

/* Form Doublebuffering */
#ifdef xwguiDB
 fl_set_form_dblbuffer(mf.form,1);      
#endif

  fl_show_form(mf.form,FL_PLACE_CENTER,FL_FULLBORDER,xwInfo);

  fl_set_object_color(mf.XWFile,FL_COL1,FL_YELLOW);

  return;
}

