/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include "xwgui.h"

/* Mainform */
extern struct mainform mf;

/* Printerform */
extern struct prtform prtf; 

/* Printerform */
extern struct printform printfm; 

/* Infoform */
extern struct infoform infof;

/* PrefPanelform */
extern struct prefform preff;

/* Frameform */
extern struct frameform framef;

/* Paper Size Form */
extern struct paperform paperf;

/* xw_Tools Printer Selection */
extern struct xwprtform xwprtf;

/* Error Form */
struct xwbugform errorf;

/*

  Errorcodes:

  - 499 Normal Error Codes

  500 - Codes for the Parser




*/

void xwError(int nr)
{
  char txt[80];
  char resourceA[80];
  char resourceB[80];
  const char *strptr;
  int deactive=0;
  int zeile=0;

  if (prtf.form != NULL)
    {
      fl_deactivate_form(prtf.form);
      deactive=1;
    }
  if (printfm.form != NULL)
    {
      fl_deactivate_form(printfm.form);
      deactive=1;
    }  
  if (infof.form != NULL)
    {
      fl_deactivate_form(infof.form);
      deactive=1;
    }
  if (preff.form != NULL)
    {
      fl_deactivate_form(preff.form);
      deactive=1;
    }
  if (framef.form != NULL)
    {
      fl_deactivate_form(framef.form);
      deactive=1;
    }
  if (paperf.form != NULL)
    {
      fl_deactivate_form(paperf.form);
      deactive=1;
    }
  if ( (deactive == 0) && (mf.form != NULL) )
    {
      fl_deactivate_form(mf.form);
      deactive=11;
    }

  errorf.form = fl_bgn_form(FL_UP_BOX,300,100); 

   fl_set_border_width(2);

   errorf.XWquit = fl_add_button(FL_NORMAL_BUTTON,100,75,100,20,GR("exit_PB.str","OK"));
   fl_set_button_shortcut(errorf.XWquit,GR("exit_PB.sc","^O^o"),true);

   errorf.XWbrowser = fl_add_browser(FL_NORMAL_BROWSER,5,5,290,65,"");
   fl_set_browser_fontstyle(errorf.XWbrowser,FL_FIXED_STYLE);

   /* Create Error Message */
   strcpy(txt,"@c@bError Code: ");
   strptr = IntStr(int(nr-int((nr/1000)*1000)));
   strcat(txt,strptr);
   strcat(txt," / Fehlerkode: ");
   strptr = IntStr(int(nr-int((nr/1000)*1000)));
   strcat(txt,strptr);
   strcat(txt,"\n@c--------------------------");
   fl_add_browser_line(errorf.XWbrowser,txt);

   /* Parser Errors - Line Number */
   if (nr>1000)
     {
       strcpy(txt,"@c");
       strcat(txt,GR("lineerror_PB.str","Druckerdateifehler in Zeile"));
       strcat(txt," ");
       strcat(txt,IntStr(int(nr/1000)));
       strcat(txt," !!!");
       fl_add_browser_line(errorf.XWbrowser,txt);
       nr=int(nr-int((nr/1000)*1000));
     }
   
   /* Create Resource Entrys */
   strcpy(resourceA,"xwgui.error");
   strcat(resourceA,IntStr(nr));
   strcpy(resourceB,resourceA);
   strcat(resourceA,"A_PB.str");
   strcat(resourceB,"B_PB.str");

   cout << resourceA << "\n";
   cout << resourceB << "\n";

  fl_end_form();

  /* Form Doublebuffering */
  fl_set_form_dblbuffer(errorf.form,1);      
  fl_show_form(errorf.form,FL_PLACE_MOUSE,FL_TRANSIENT,xwInfo);

  fl_set_app_mainform(errorf.form);

  /* Exit Handler */
  fl_set_form_atclose(errorf.form,nclose_cb,"1");

  errorf.ready=0;
  while (errorf.ready == 0)
    {
      errorf.obj = fl_do_forms();

      /* Abbruch */
      if (errorf.obj == errorf.XWquit)
	{
	  errorf.ready = 1;
	}
    }

  fl_hide_form(errorf.form);
  fl_free_form(errorf.form);

  if (deactive == 1)
    {
      if (prtf.form != NULL)
	{
	  fl_activate_form(prtf.form);
	}
      if (printfm.form != NULL)
	{
	  fl_activate_form(printfm.form);
	}  
      if (infof.form != NULL)
	{
	  fl_activate_form(infof.form);
	}
      if (preff.form != NULL)
	{
	  fl_activate_form(preff.form);
	}
      if (framef.form != NULL)
	{
	  fl_activate_form(framef.form);
	}
      if (paperf.form != NULL)
	{
	  fl_activate_form(paperf.form);
	}
    }
  if ( (deactive == 11) && (mf.form != NULL) )
    {
      fl_activate_form(mf.form);
    }
  
  return;
}
