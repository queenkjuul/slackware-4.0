/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can void main_gui(void)
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include "xwgui.h"

/* Icon Import */
#include "Pixmaps/info.xpm"
#include "Pixmaps/pref.xpm"                   
#include "Pixmaps/exit.xpm"
#include "Pixmaps/noframes.xpm"
#include "Pixmaps/frameset.xpm"
#include "Pixmaps/rotate.xpm"
#include "Pixmaps/fullsize.xpm"

/* HomeDirectory */
extern char *user;
extern char xpuser[1024];

/* Directory-Path */
extern char xwpath[1024];
extern char xwpathh[1024];  /* For Path Manipulations */

/* Page Datas */
extern struct pagedata pdata;

/* Printer General Settings */
extern struct XWGprint xwgp;

/* Mainform */
struct mainform mf;

/* Printerform */
struct prtform prtf; 

/* Printerform */
struct printform printfm; 

/* Infoform */
struct infoform infof;

/* PrefPanelform */
struct prefform preff;

/* Frameform */
struct frameform framef;

/* Paper Size Form */
struct paperform paperf;

/* xw_Tools Printer Selection */
struct xwprtform xwprtf;

/* String Vars */
extern const char *strptr;
extern char astr[256],bstr[256],cstr[256];

const char *GR(char *resource,char *defStr) /*fold00*/
{
    static char       val[256];
    char              className[256];

    strcpy(className,"xwgui.");
    strcat(className,resource);
 
    fl_get_resource(resource,className,FL_STRING,defStr,&val,256);

    return(val);
}

/* Main-Window GUI Layout */
void main_gui(void) /*fold00*/
{
    /* Test Format */
    /*
     mf.width = 800;
     mf.height = 600;
     */
    /*
     mf.width = 640;
     mf.height = 480;
     */

    /* Preference Panel Geometry - POSITION */
    mf.x_ppg = 8;
    mf.y_ppg = 26 + 8;

    /* Browser Panel Geometry - HEIGHT */
    mf.y_fpg = mf.y_ppg + ( 132 + 8 );
    mf.y_bpg = mf.height - ( mf.y_fpg + 8 );

    /* Paper Panel Geometry */
    mf.x_pag = 8 + 204 + 4 + 2;
    mf.y_pag = 26 + 8;
    /* Frame Size Geometry */
    mf.x_fsg = mf.width - ( mf.x_pag + 8 );
    mf.y_fsg = mf.height - ( mf.y_pag + 8 );

    /* Picture Panel Geometry */
    mf.x_pig = mf.width - ( 180 + 10 );
    mf.y_pig = 26 + 10;

    /* Paper Window Frame */
    mf.x_pwf = 8 + 204 + 4 + 2 + 4;
    mf.pwf = mf.x_pig - ( mf.x_pag + 4 );
    mf.ppwf = mf.height - ( 26 + 12 + 8 );
    if (mf.ppwf < mf.pwf)
    {
        mf.pwf = mf.ppwf;
    }

    /* 628,396 */
    mf.form = fl_bgn_form(FL_UP_BOX,mf.width,mf.height);

    fl_set_form_minsize(mf.form,640,480);

    fl_set_border_width(2);

    /* Background */
    mf.XWBackground = fl_add_frame(FL_UP_BOX,0,0,mf.width,mf.height,"");

    /* FileBrowser */
    if (xwgp.gimp == 0)
      {
	/* Browser Frames 380 */
	mf.frame1 = fl_add_frame(FL_DOWN_FRAME,8,mf.y_fpg,204,mf.y_bpg,"");
	/* Directory Browser */
	mf.XWBrowser = fl_add_browser(FL_HOLD_BROWSER,10,mf.y_fpg+2,200,72,"");
	fl_set_browser_fontstyle(mf.XWBrowser,FL_FIXED_STYLE);
	strcpy(xwpath,xpuser);
	strcat(xwpath,"/");
	/* Drawer Input */
	mf.XWDrawer = fl_add_input(FL_NORMAL_INPUT,10,mf.y_fpg+74,200,20,"");
	fl_set_button_shortcut(mf.XWDrawer,"^ ",false);
	fl_set_input(mf.XWDrawer,xwpath);
	/* File Browser 284 */
	mf.XWFile = fl_add_browser(FL_HOLD_BROWSER,10,mf.y_fpg+94,200,mf.y_bpg-96,"");
	fl_set_browser_fontstyle(mf.XWFile,FL_FIXED_STYLE);
      }
    else
      {
	/* Browser Frames 380 */
	mf.frame1 = fl_add_frame(FL_DOWN_FRAME,
				 8,mf.y_fpg,
				 204,
				 mf.y_bpg,
				 "xwGUI\n\n(c) '98,'99 by Stefan Kraus\n\n--------------------\n\nxw_Tools\n\n(c) '96,'97,'98,'99 by Jean-Jacques Sarton\n\n--------------------\n\nGimp xwGUI / xw_Tools PlugIn\n\n(c) 1999 by Jean-Jacques Sarton\nand\nStefan Kraus");
      }

    /* Paper Frame */
    mf.frame2 = fl_add_frame(FL_DOWN_FRAME,mf.x_pag,mf.y_pag,mf.x_fsg,mf.y_fsg,"");

    /* Paper-Window-Frame */
    /*
     mf.XWPFrame = fl_add_frame(FL_DOWN_FRAME,mf.x_pwf-2,10+26,mf.pwf,mf.pwf,"");
     */
    mf.XWPFrame = fl_add_frame(FL_DOWN_FRAME,mf.x_pwf,10+28,mf.pwf-4,mf.pwf-4,"");

    /* Paperformat */
    mf.XWPapers = fl_add_choice(FL_DROPLIST_CHOICE,mf.x_pig,mf.y_pig,180,20,"");
    fl_set_object_boxtype(mf.XWPapers,FL_DOWN_BOX);
    fl_set_button_shortcut(mf.XWPapers,GR("paper_PB.sc","^B^b"),false);
    fl_addto_choice(mf.XWPapers,"A5 148 x 210 mm");
    fl_addto_choice(mf.XWPapers,"A4 210 x 297 mm");
    fl_addto_choice(mf.XWPapers,"A3 297 x 420 mm");
    fl_addto_choice(mf.XWPapers,"Executive 7.25 x 10.5 Inch");
    fl_addto_choice(mf.XWPapers,"Letter 8.5 x 11 Inch");
    fl_addto_choice(mf.XWPapers,"Legal 8.5 x 14 Inch");
    fl_addto_choice(mf.XWPapers,"Ledger 11 x 17 Inch");
    fl_addto_choice(mf.XWPapers,"Tabloid 11 x 17 Inch");
    fl_addto_choice(mf.XWPapers,"Panorama 210 x 594 mm");
    fl_addto_choice(mf.XWPapers,GR("custompaper_PB.str","Benutzer definiert"));
    fl_set_choice(mf.XWPapers,pdata.page);
    /* Landscape */
    mf.XWLandscape = fl_add_lightbutton(FL_PUSH_BUTTON,mf.x_pig,mf.y_pig+22,180,20,GR("landscape_PB.str","Landscape"));
    fl_set_button_shortcut(mf.XWLandscape,GR("landscape_PB.sc","^A^a"),true);
    fl_set_button(mf.XWLandscape,pdata.landscape);

    /* Border Parameters */
    mf.XWBorderl = fl_add_input(FL_INT_INPUT,mf.x_pig+114,mf.y_pig+44,66,20,GR("leftBorder_PB.str","Linker Rand (mm):"));
    fl_set_button_shortcut(mf.XWBorderl,GR("leftBorder_PB.sc","^L^l"),true);
    strptr = IntStr(pdata.pagel);
    strcpy(astr,strptr);
    fl_set_input(mf.XWBorderl,astr);
    mf.XWBorderr = fl_add_input(FL_INT_INPUT,mf.x_pig+114,mf.y_pig+66,66,20,GR("rightBorder_PB.str","Rechter Rand (mm):"));
    fl_set_button_shortcut(mf.XWBorderr,GR("rightBorder_PB.sc","^C^c"),true);
    strptr = IntStr(pdata.pager);
    strcpy(astr,strptr);
    fl_set_input(mf.XWBorderr,astr);
    mf.XWBordert = fl_add_input(FL_INT_INPUT,mf.x_pig+114,mf.y_pig+88,66,20,GR("topBorder_PB.str","Oberer Rand (mm):"));
    fl_set_button_shortcut(mf.XWBordert,GR("topBorder_PB.sc","^O^o"),true);
    strptr = IntStr(pdata.paget);
    strcpy(astr,strptr);
    fl_set_input(mf.XWBordert,astr);
    mf.XWBorderb = fl_add_input(FL_INT_INPUT,mf.x_pig+114,mf.y_pig+110,66,20,GR("buttomBorder_PB.str","Unterer Rand (mm):"));
    fl_set_button_shortcut(mf.XWBorderb,GR("buttomBorder_PB.sc","^U^u"),true);
    strptr = IntStr(pdata.pageb);
    strcpy(astr,strptr);
    fl_set_input(mf.XWBorderb,astr);

    /* DPI Panel */
    mf.XWDPI = fl_add_box(FL_DOWN_BOX,mf.x_pig,mf.y_pig+132,180,100,"");
    /* fl_set_object_lalign(mf.XWDPI,FL_ALIGN_LEFT);*/
    fl_set_object_lstyle(mf.XWDPI,FL_FIXED_STYLE);
    fl_set_object_lsize(mf.XWDPI,FL_NORMAL_FONT);

    mf.XWDPImm = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig,mf.y_pig+234,45,20,"@#4>>");
    /* fl_set_button_shortcut(mf.XWDPImm,"^M^m",false); */
    mf.XWDPIpp = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+45,mf.y_pig+234,45,20,"@#>>");
    /* fl_set_button_shortcut(mf.XWDPIpp,"^P^p",false); */
    mf.XWDPIm = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+90,mf.y_pig+234,45,20,"@#4>");
    fl_set_button_shortcut(mf.XWDPIm,"^-",false);
    mf.XWDPIp = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+135,mf.y_pig+234,45,20,"@#>");
    fl_set_button_shortcut(mf.XWDPIp,"^+",false);

    /* Rotate */
    mf.XWRotate = fl_add_pixmapbutton(FL_NORMAL_BUTTON,mf.x_pig,mf.y_pig+256,45,20,"");
    fl_set_pixmap_data(mf.XWRotate,rotate_xpm);
    /* Full Size */
    mf.XWFullSize = fl_add_pixmapbutton(FL_NORMAL_BUTTON,mf.x_pig+45,mf.y_pig+256,45,20,"");
    fl_set_pixmap_data(mf.XWFullSize,fullsize_xpm);
    /* Center */
    mf.XWHCenter = fl_add_button(FL_NORMAL_BUTTON,mf.x_pig+90,mf.y_pig+256,45,20,"@#<->");
    /* fl_set_button_shortcut(mf.XWHCenter,"^H",false); */
    mf.XWVCenter = fl_add_button(FL_NORMAL_BUTTON,mf.x_pig+135,mf.y_pig+256,45,20,"@#8<->");
    /* fl_set_button_shortcut(mf.XWVCenter,"^V",false); */

    /* Move Panel */
    mf.XWMovel = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+30,mf.y_pig+308,30,30,"@#4>");
    mf.XWMover = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+90,mf.y_pig+308,30,30,"@#6>");
    mf.XWMovet = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+60,mf.y_pig+278,30,30,"@#8>");
    mf.XWMoveb = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+60,mf.y_pig+338,30,30,"@#2>");
    mf.XWMovell = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+60,mf.y_pig+308,30,30,"@#4>>");
    mf.XWMoverr = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+120,mf.y_pig+308,30,30,"@#6>>");
    mf.XWMovett = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+90,mf.y_pig+278,30,30,"@#8>>");
    mf.XWMovebb = fl_add_button(FL_TOUCH_BUTTON,mf.x_pig+90,mf.y_pig+338,30,30,"@#2>>");

   /* View Picture */
    if (xwgp.gimp == 0)
      {
	mf.XWViewer = fl_add_button(FL_NORMAL_BUTTON,mf.x_pig,mf.y_pig+370,90,20,GR("view_PB.str","Bild anzeigen"));
	fl_set_button_shortcut(mf.XWViewer,GR("view_PB.sc","^G^g"),true);
      }

   /* Paper Reset */
   mf.XWReset = fl_add_button(FL_NORMAL_BUTTON,mf.x_pig+90,mf.y_pig+370,90,20,GR("reset_PB.str","Zur�cksetzen"));
   fl_set_button_shortcut(mf.XWReset,GR("reset_PB.sc","^Z^z"),true);

   /* Print Direction */
   mf.XWDirection = fl_add_box(FL_DOWN_BOX,mf.x_pig,mf.y_pig+392,40,40,"@8->");
    
   /* Print Picture */
   mf.XWPrint = fl_add_button(FL_NORMAL_BUTTON,mf.x_pig+40,mf.y_pig+392,140,40,GR("print_PB.str","DRUCKEN"));
   fl_set_button_shortcut(mf.XWPrint,GR("print_PB.sc","^D^d"),true);
   fl_set_object_lsize(mf.XWPrint,FL_MEDIUM_FONT);

   /* Preference Frame */
   mf.frame3 = fl_add_frame(FL_DOWN_FRAME,mf.x_ppg,mf.y_ppg,204,134,"");
   mf.XWPrinter = fl_add_button(FL_NORMAL_BUTTON,mf.x_ppg+2,mf.y_ppg+2,200,20,GR("printers_PB.str","Druckerauswahl"));
   fl_set_object_color(mf.XWPrinter,FL_INDIANRED,FL_RED);
   fl_set_button_shortcut(mf.XWPrinter,GR("printers_PB.sc","^R^r"),true); 
   mf.XWQuality = fl_add_choice(FL_DROPLIST_CHOICE,mf.x_ppg+57,mf.y_ppg+24,145,20,GR("quality_PB.str","Qualit�t:"));
   fl_set_object_boxtype(mf.XWQuality,FL_DOWN_BOX);
   fl_set_button_shortcut(mf.XWQuality,GR("quality_PB.sc","^Q^q"),true); 
   mf.XWSheets = fl_add_choice(FL_DROPLIST_CHOICE,mf.x_ppg+57,mf.y_ppg+46,145,20,GR("sheettype_PB.str","Papierart:"));
   fl_set_object_boxtype(mf.XWSheets,FL_DOWN_BOX);
   fl_set_button_shortcut(mf.XWSheets,GR("sheettype_PB.sc","^T^t"),true);
   mf.XWPrefA = fl_add_button(FL_NORMAL_BUTTON,mf.x_ppg+2,mf.y_ppg+68,200,20,"");
   fl_set_button_shortcut(mf.XWPrefA,GR("prefA_PB.sc","&1"),true);
   mf.XWPrefB = fl_add_button(FL_NORMAL_BUTTON,mf.x_ppg+2,mf.y_ppg+90,200,20,"");
   fl_set_button_shortcut(mf.XWPrefB,GR("prefB_PB.sc","&2"),true);
   mf.XWPrefC = fl_add_button(FL_NORMAL_BUTTON,mf.x_ppg+2,mf.y_ppg+112,200,20,"");
   fl_set_button_shortcut(mf.XWPrefC,GR("prefC_PB.sc","&3"),true);

   /* Titlebar */
   mf.XWTitlebar = fl_add_frame(FL_DOWN_FRAME,8,8,mf.width-16,21,"");
   /* fl_set_object_color(mf.XWTitlebar,FL_LEFT_BCOL,FL_WHITE); */
   /* fl_set_object_lcol(mf.XWTitlebar,FL_WHITE); */
   /* Info Widget */
   mf.XWInfo = fl_add_pixmapbutton(FL_NORMAL_BUTTON,10,9,36,18,"");
   fl_set_pixmap_data(mf.XWInfo,info_xpm);
   /* Pref */
   mf.XWPrefPref = fl_add_pixmapbutton(FL_NORMAL_BUTTON,48,9,36,18,"");
   fl_set_pixmap_data(mf.XWPrefPref,pref_xpm);
   /* Exit */
   mf.XWquit = fl_add_pixmapbutton(FL_NORMAL_BUTTON,86,9,36,18,"");
   fl_set_pixmap_data(mf.XWquit,exit_xpm);
    
   /* Frames */
   mf.XWPicFrames = fl_add_pixmapbutton(FL_NORMAL_BUTTON,144,9,36,18,"");
   fl_set_pixmap_data(mf.XWPicFrames,noframes_xpm);

   /* Width */
   mf.XWxsize = fl_add_input(FL_INT_INPUT,250,9,40,18,GR("framewidth_PB.str","Breite (mm):"));
   fl_set_button_shortcut(mf.XWxsize,GR("framewidth_PB.sc","^R^r"),true);
   strptr = IntStr(framef.xwXSize);
   strcpy(astr,strptr);
   fl_set_input(mf.XWxsize,astr);
   /* Swap */
   mf.XWswap = fl_add_button(FL_NORMAL_BUTTON,300,9,20,18,"@<->");
   fl_set_button_shortcut(mf.XWswap,GR("swap_PB.sc","^T^t"),true);
   /* Height */
   mf.XWysize = fl_add_input(FL_INT_INPUT,390,9,40,18,GR("frameheight_PB.str","H�he (mm):"));
   fl_set_button_shortcut(mf.XWysize,GR("frameheight_PB.sc","^N^n"),true);
   strptr = IntStr(framef.xwYSize);
   strcpy(astr,strptr);
   fl_set_input(mf.XWysize,astr);

   /* Frameset */
   mf.XWPicFrameSet = fl_add_pixmapbutton(FL_NORMAL_BUTTON,440,9,36,18,"");
   fl_set_pixmap_data(mf.XWPicFrameSet,frameset_xpm);

   /* Special Panel */
   mf.frame5 = fl_add_frame(FL_DOWN_FRAME,mf.x_pig+2,mf.y_pig+436,176,176,"");
  mf.XWTimer = fl_add_clock(FL_ANALOG_CLOCK,mf.x_pig+4,mf.y_pig+438,170,170,"");

  if ( (mf.height - ( mf.y_pig + 432 + 2 + 8 )) < 182 )
  {
      fl_hide_object(mf.frame5);
      fl_hide_object(mf.XWTimer);
  }

  fl_end_form();
  return;
}

int resize_main_gui(void) /*fold00*/
{
    if (mf.resize == 0)
    {
        mf.resize=1;

        fl_get_wingeometry(mf.form->window,&mf.xpos,&mf.ypos,&mf.width,&mf.height);

        /* Width slower as 640 Dots ? */
        if (mf.width < 640)
        {
            mf.width = 640;
        }
      /* Height slower as 480 Dots ? */
        if (mf.height < 480)
	{
	  mf.height = 480;
	}

      mf.widthh=mf.width;
      mf.heightt=mf.height;

      /* Preference Panel Geometry - POSITION */
      mf.x_ppg = 8;
      mf.y_ppg = 26 + 8;

      /* Browser Panel Geometry - HEIGHT */
      mf.y_fpg = mf.y_ppg + ( 132 + 8 );
      mf.y_bpg = mf.height - ( mf.y_fpg + 8 );
  
      /* Paper Panel Geometry */
      mf.x_pag = 8 + 204 + 4 + 2;
      mf.y_pag = 26 + 8;
      /* Frame Size Geometry */
      mf.x_fsg = mf.width - ( mf.x_pag + 8 );
      mf.y_fsg = mf.height - ( mf.y_pag + 8 );
      
      /* Picture Panel Geometry */
      mf.x_pig = mf.width - ( 180 + 10 );
      mf.y_pig = 26 + 10;

      /* Paper Window Frame */
      mf.x_pwf = 8 + 204 + 4 + 2 + 4;
      mf.pwf = mf.x_pig - ( mf.x_pag + 4 );
      mf.ppwf = mf.height - ( 26 + 12 + 8 ); 
      if (mf.ppwf < mf.pwf)
	{
	  mf.pwf = mf.ppwf;
	}

      fl_freeze_form(mf.form); 
      
      /* Background */
      fl_set_object_geometry(mf.XWBackground,0,0,mf.width,mf.height);
      
      /* Browser Frames 380 */
      fl_set_object_geometry(mf.frame1,8,mf.y_fpg,204,mf.y_bpg);
      
      /* FileBrowser */
      if (xwgp.gimp == 0)
	{
	  /* Directory Browser */
	  fl_set_object_geometry(mf.XWBrowser,10,mf.y_fpg+2,200,72);
	  /* Drawer Input */
	  fl_set_object_geometry(mf.XWDrawer,10,mf.y_fpg+74,200,20);
	  /* File Browser 284 */
	  fl_set_object_geometry(mf.XWFile,10,mf.y_fpg+94,200,mf.y_bpg-96);
	}

      /* Paper Frame */
      fl_set_object_geometry(mf.frame2,mf.x_pag,mf.y_pag,mf.x_fsg,mf.y_fsg);
      
      /* Paper-Window-Frame */
      fl_set_object_geometry(mf.XWPFrame,mf.x_pwf,10+28,mf.pwf-4,mf.pwf-4);

      
      /* Paperformat */
      fl_set_object_geometry(mf.XWPapers,mf.x_pig,mf.y_pig,180,20);
      
      /* Landscape */
      fl_set_object_geometry(mf.XWLandscape,mf.x_pig,mf.y_pig+22,180,20);
      /* Border Parameters */
      fl_set_object_geometry(mf.XWBorderl,mf.x_pig+114,mf.y_pig+44,66,20);
      fl_set_object_geometry(mf.XWBorderr,mf.x_pig+114,mf.y_pig+66,66,20);
      fl_set_object_geometry(mf.XWBordert,mf.x_pig+114,mf.y_pig+88,66,20);
      fl_set_object_geometry(mf.XWBorderb,mf.x_pig+114,mf.y_pig+110,66,20);
      
      /* DPI Panel */
      fl_set_object_geometry(mf.XWDPI,mf.x_pig,mf.y_pig+132,180,100);
      
      fl_set_object_geometry(mf.XWDPImm,mf.x_pig,mf.y_pig+234,45,20);
      fl_set_object_geometry(mf.XWDPIpp,mf.x_pig+45,mf.y_pig+234,45,20);
      fl_set_object_geometry(mf.XWDPIm,mf.x_pig+90,mf.y_pig+234,45,20);
      fl_set_object_geometry(mf.XWDPIp,mf.x_pig+135,mf.y_pig+234,45,20);
      
      /* Rotate */
      fl_set_object_geometry(mf.XWRotate,mf.x_pig,mf.y_pig+256,45,20);

      /* Full Size */
      fl_set_object_geometry(mf.XWFullSize,mf.x_pig+45,mf.y_pig+256,45,20);

      /* Center */
      fl_set_object_geometry(mf.XWHCenter,mf.x_pig+45,mf.y_pig+256,45,20);
      fl_set_object_geometry(mf.XWVCenter,mf.x_pig+90,mf.y_pig+256,45,20);
      
      /* Move Panel */
      fl_set_object_geometry(mf.XWMovel,mf.x_pig+30,mf.y_pig+308,30,30);
      fl_set_object_geometry(mf.XWMover,mf.x_pig+90,mf.y_pig+308,30,30);
      fl_set_object_geometry(mf.XWMovet,mf.x_pig+60,mf.y_pig+278,30,30);
      fl_set_object_geometry(mf.XWMoveb,mf.x_pig+60,mf.y_pig+338,30,30);
      fl_set_object_geometry(mf.XWMovell,mf.x_pig+60,mf.y_pig+308,30,30);
      fl_set_object_geometry(mf.XWMoverr,mf.x_pig+120,mf.y_pig+308,30,30);
      fl_set_object_geometry(mf.XWMovett,mf.x_pig+90,mf.y_pig+278,30,30);
      fl_set_object_geometry(mf.XWMovebb,mf.x_pig+90,mf.y_pig+338,30,30);
      
      /* Paper Reset */
      fl_set_object_geometry(mf.XWViewer,mf.x_pig,mf.y_pig+370,90,20);
      
      /* Paper Reset */
      fl_set_object_geometry(mf.XWReset,mf.x_pig+90,mf.y_pig+370,90,20);

      /* Print Direction */
      fl_set_object_geometry(mf.XWDirection,mf.x_pig,mf.y_pig+392,40,40);
      
      /* Print Picture */
      fl_set_object_geometry(mf.XWPrint,mf.x_pig+40,mf.y_pig+392,140,40);
      
      /* Preference Frame */
      fl_set_object_geometry(mf.frame3,mf.x_ppg,mf.y_ppg,204,134);
      fl_set_object_geometry(mf.XWPrinter,mf.x_ppg+2,mf.y_ppg+2,200,20);
      fl_set_object_geometry(mf.XWQuality,mf.x_ppg+57,mf.y_ppg+24,145,20);
      fl_set_object_geometry(mf.XWSheets,mf.x_ppg+57,mf.y_ppg+46,145,20);
      fl_set_object_geometry(mf.XWPrefA,mf.x_ppg+2,mf.y_ppg+68,200,20);
      fl_set_object_geometry(mf.XWPrefB,mf.x_ppg+2,mf.y_ppg+90,200,20);
      fl_set_object_geometry(mf.XWPrefC,mf.x_ppg+2,mf.y_ppg+112,200,20);
  
      /* Titlebar */
      fl_set_object_geometry(mf.XWTitlebar,6,6,mf.width-12,24);
      /* Info Widget */
      fl_set_object_geometry(mf.XWInfo,10,9,36,18);
      /* Pref */
      fl_set_object_geometry(mf.XWPrefPref,48,9,36,18);
      /* Exit */
      fl_set_object_geometry(mf.XWquit,86,9,36,18);
      
      /* Frames */
      fl_set_object_geometry(mf.XWPicFrames,144,9,36,18);
      /* Width */
      fl_set_object_geometry(mf.XWxsize,250,9,40,18);
      /* Swap */
      fl_set_object_geometry(mf.XWswap,300,9,20,18);
      /* Height */
      fl_set_object_geometry(mf.XWysize,390,9,40,18);

      /* Frameset */
      fl_set_object_geometry(mf.XWPicFrameSet,440,9,36,18);

      /* Special Panel */
      fl_set_object_geometry(mf.frame5,mf.x_pig+2,mf.y_pig+436,176,176);
      fl_set_object_geometry(mf.XWTimer,mf.x_pig+4,mf.y_pig+438,170,170);
      if ( (mf.height - ( mf.y_pig + 432 + 2 + 8 )) < 182 )
	{
	  fl_hide_object(mf.frame5);
	  fl_hide_object(mf.XWTimer);
	}
      else
	{
	  fl_show_object(mf.frame5);
	  fl_show_object(mf.XWTimer);
	}

      fl_unfreeze_form(mf.form);

      drawpaper(xw_paper);
      setdpi();

      mf.resize=0;

      return(1);
    }
  else
    {
      return(0);
    }

}

/* Printer-Window GUI Layout */ 
void printer_gui(void) /*fold00*/
{
  prtf.form = fl_bgn_form(FL_UP_BOX,220,220); 

   fl_set_border_width(2);

   /* FileType */
   prtf.XWtype = fl_add_choice(FL_DROPLIST_CHOICE,5,5,210,20,"");
   fl_set_object_boxtype(prtf.XWtype,FL_DOWN_BOX);
   fl_addto_choice(prtf.XWtype,"xw_Print (*.xwp)");
   fl_addto_choice(prtf.XWtype,"Ghostscript (*.ghs)");
   fl_set_choice(prtf.XWtype,1);

   /* File Browser */
   prtf.XWfile = fl_add_browser(FL_HOLD_BROWSER,5,25,210,167,"");
   fl_set_browser_fontstyle(prtf.XWfile,FL_FIXED_STYLE);

   prtf.XWquit = fl_add_button(FL_NORMAL_BUTTON,60,195,100,20,GR("exit_PB.str","OK"));
   fl_set_button_shortcut(prtf.XWquit,GR("exit_PB.sc","^O^o"),true);

  fl_end_form();
  return;
}

/* Print-Window GUI Layout */ 
void print_gui(void) /*fold00*/
{
  printfm.form = fl_bgn_form(FL_UP_BOX,640,100); 

   fl_set_border_width(2);

   printfm.XWquit = fl_add_button(FL_NORMAL_BUTTON,240,75,160,20,GR("continue_PB.str","WEITER/ABBRUCH"));
   fl_set_button_shortcut(printfm.XWquit,GR("continue_PB.sc","^E^e"),true);

   /* File Browser */
   printfm.XWfile = fl_add_browser(FL_NORMAL_BROWSER,5,5,630,67,"");
   fl_set_browser_fontstyle(printfm.XWfile,FL_FIXED_STYLE);

  fl_end_form();
  return;
}

/* Info-Window GUI Layout */ 
void info_gui(void) /*fold00*/
{
  char ig[160];
  char id[80] = xw_Info;

  infof.form = fl_bgn_form(FL_UP_BOX,540,400); 

   fl_set_border_width(2);

   infof.XWquit = fl_add_button(FL_NORMAL_BUTTON,220,375,100,20,GR("exit_PB.str","OK"));
   fl_set_button_shortcut(infof.XWquit,GR("exit_PB.sc","^O^o"),true);

   infof.XWobj[0] = fl_add_box(FL_DOWN_BOX,5,5,530,40,xw_Info);
   fl_set_object_lsize(infof.XWobj[0],FL_HUGE_FONT);
   fl_set_object_lstyle(infof.XWobj[0],FL_EMBOSSED_STYLE);

   infof.XWobj[1] = fl_add_browser(FL_NORMAL_BROWSER,5,50,530,320,"");
   fl_set_browser_fontstyle(infof.XWobj[1],FL_FIXED_STYLE);
   fl_add_browser_line(infof.XWobj[1],"@c� 10/1998 by Stefan Kraus\n\n@c@bProgram:\n@cxwGUI\n");

   strcpy(ig,"@c@bVersion:\n@c");
   strcat(ig,id);
   strcat(ig,"\n\n@c@bAuthor:\n@cStefan Kraus\n");
   fl_add_browser_line(infof.XWobj[1],ig);
   fl_add_browser_line(infof.XWobj[1],"@c@bContact Adress:\n@cStefan Kraus\n@cLeipzigerstr. 3a\n@c31848 Bad M�nder\n@c-Germany-\n");
   fl_add_browser_line(infof.XWobj[1],"@c@bEMail-Adress:\n@cskraus@weserbergland.de\n");
   fl_add_browser_line(infof.XWobj[1],"@c@bHomepage:\n@chttp://www.weserbergland.de/privat/kraus\n");
   fl_add_browser_line(infof.XWobj[1],"@c---------------------------------------------------------------------------\n");
   fl_add_browser_line(infof.XWobj[1],"@c@bThanks to\n@cJean-Jacques Sarton\n@c( http://home.t-online.de/home/jj.sarton/start.htm )");
   fl_add_browser_line(infof.XWobj[1],"@cfor Testing, Bug-Reports, Corrections, Source-Codes, Ideas and his Program");
   fl_add_browser_line(infof.XWobj[1],"@cxw_Tools. The very best printing Tools.\n");
   fl_add_browser_line(infof.XWobj[1],"@c@bThanks to\n@cT.C. Zhao & Mark Overmars\n@cfor the xforms library.\n");
   fl_add_browser_line(infof.XWobj[1],"@c---------------------------------------------------------------------------\n");
   fl_add_browser_line(infof.XWobj[1],"@c@bLicense:\n@cGNU General Public License\n");
   fl_add_browser_line(infof.XWobj[1],"@cxwGUI -- an X11-GUI for xw_print");
   fl_add_browser_line(infof.XWobj[1],"@cCopyright (C) 1998 Stefan Kraus\n");
   fl_add_browser_line(infof.XWobj[1],"@cThis program is free software; you can redistribute it and/or modify");
   fl_add_browser_line(infof.XWobj[1],"@cit under the terms of the GNU General Public License as published by");
   fl_add_browser_line(infof.XWobj[1],"@cthe Free Software Foundation; either version 2 of the License, or");
   fl_add_browser_line(infof.XWobj[1],"@c(at your option) any later version.\n");
   fl_add_browser_line(infof.XWobj[1],"@cThis program is distributed in the hope that it will be useful,");
   fl_add_browser_line(infof.XWobj[1],"@cbut WITHOUT ANY WARRANTY; without even the implied warranty of");
   fl_add_browser_line(infof.XWobj[1],"@cMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the");
   fl_add_browser_line(infof.XWobj[1],"@cGNU General Public License for more details.\n");
   fl_add_browser_line(infof.XWobj[1],"@cYou should have received a copy of the GNU General Public License");
   fl_add_browser_line(infof.XWobj[1],"@calong with this program; if not, write to the Free Software");
   fl_add_browser_line(infof.XWobj[1],"@cFoundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.");
   
  fl_end_form();

  /* Form Doublebuffering */
  fl_set_form_dblbuffer(infof.form,1);      
  fl_show_form(infof.form,FL_PLACE_MOUSE,FL_TRANSIENT,xwInfo);

  fl_set_app_mainform(infof.form);

  /* Exit Handler */
  fl_set_form_atclose(infof.form,nclose_cb,"1");

  infof.ready=0;
  while (infof.ready == 0)
    {
      infof.obj = fl_do_forms();

      /* Abbruch */
      if (infof.obj == infof.XWquit)
	{
	  infof.ready = 1;
	}
    }
  fl_set_app_mainform(mf.form);

  fl_hide_form(infof.form);
  fl_free_form(infof.form);
  infof.form=NULL;

  return;
}

/* Pref-Window GUI Layout */ 
void pref_gui(void) 
{
  preff.form = fl_bgn_form(FL_UP_BOX,620,220); 

   fl_set_border_width(2);

   preff.XWobj[0] = fl_add_input(FL_NORMAL_INPUT,150,10,460,20,GR("external_viewer_PB.str","Externer Bild Anzeiger:"));
   fl_set_button_shortcut(preff.XWobj[0],GR("external_viewer_PB.sc","^A^a"),true);
   fl_set_input(preff.XWobj[0],xwgp.viewer);

   preff.XWobj[1] = fl_add_choice(FL_DROPLIST_CHOICE,150,32,460,20,GR("printmode_PB.str","Druckmodus:"));
   fl_set_object_boxtype(preff.XWobj[1],FL_DOWN_BOX);
   fl_set_button_shortcut(preff.XWobj[1],GR("printmode_PB.sc","^P^p"),false);
   fl_addto_choice(preff.XWobj[1],GR("printmdA_PB.str","�ber den Treiber drucken..."));
   fl_addto_choice(preff.XWobj[1],GR("printmdB_PB.str","�ber den Spooler drucken..."));
   fl_set_choice(preff.XWobj[1],xwgp.prtselect);

   preff.XWquit = fl_add_button(FL_NORMAL_BUTTON,260,195,100,20,GR("exit_PB.str","OK"));
   fl_set_button_shortcut(preff.XWquit,GR("exit_PB.sc","^O^o"),true);

  fl_end_form();
  return;
}

void frame_gui(void) 
{
    framef.form = fl_bgn_form(FL_UP_BOX,531,371);

     fl_set_border_width(2);

     framef.XWFrame = fl_add_frame(FL_DOWN_FRAME,12,12,487,327,"");
     framef.XWScroll = fl_add_scrollbar(FL_VERT_SCROLLBAR,501,10,20,331,"");

     framef.XWAbort = fl_add_button(FL_NORMAL_BUTTON,259,346,100,20,GR("exit_PB.str","OK"));
     fl_set_button_shortcut(framef.XWAbort,GR("exit_PB.sc","^O^o"),true);

     fl_end_form();

    return;
}

/* Paper Size Layout */ 
void paper_gui(void)
{
  float xy;

  paperf.xmm = pdata.pagex;
  paperf.ymm = pdata.pagey;
  paperf.xi = paperf.xmm/25.4;
  paperf.yi = paperf.ymm/25.4;

  paperf.form = fl_bgn_form(FL_UP_BOX,210,90+20+6); 

   fl_set_border_width(2);

   paperf.XWframe = fl_add_frame(FL_DOWN_FRAME,5,5,200,80,"");
   paperf.XWmm = fl_add_text(FL_NORMAL_TEXT,75,10,60,20,"mm");
   paperf.XWi = fl_add_text(FL_NORMAL_TEXT,140,10,60,20,"inch (Zoll)");
   paperf.XWwidth = fl_add_text(FL_NORMAL_TEXT,10,35,60,20,GR("width_PB.str","Breite:"));
   paperf.XWheight = fl_add_text(FL_NORMAL_TEXT,10,60,60,20,GR("height_PB.str","H�he:"));

   paperf.XWxsizemm = fl_add_input(FL_FLOAT_INPUT,75,35,60,20,"");
   strptr = DoubleStr(paperf.xmm);
   strcpy(astr,strptr);
   fl_set_input(paperf.XWxsizemm,astr);

   paperf.XWysizemm = fl_add_input(FL_FLOAT_INPUT,75,60,60,20,"");
   strptr = DoubleStr(paperf.ymm);
   strcpy(astr,strptr);
   fl_set_input(paperf.XWysizemm,astr);
   
   paperf.XWxsizeI = fl_add_input(FL_FLOAT_INPUT,140,35,60,20,"");
   strptr = DoubleStr(paperf.xi);
   strcpy(astr,strptr);
   fl_set_input(paperf.XWxsizeI,astr);

   paperf.XWysizeI = fl_add_input(FL_FLOAT_INPUT,140,60,60,20,"");
   strptr = DoubleStr(paperf.yi);
   strcpy(astr,strptr);
   fl_set_input(paperf.XWysizeI,astr);

   paperf.XWok =  fl_add_button(FL_NORMAL_BUTTON,55,91,100,20,GR("exit_PB.str","OK"));
   fl_set_button_shortcut(paperf.XWok,GR("exit_PB.sc","^O^o"),true);

  fl_end_form();

  /* Form Doublebuffering */
  fl_set_form_dblbuffer(paperf.form,1);      
  fl_show_form(paperf.form,FL_PLACE_MOUSE,FL_TRANSIENT,xwInfo);

  fl_set_app_mainform(paperf.form);

  /* Exit Handler */
  fl_set_form_atclose(paperf.form,nclose_cb,"1");

  paperf.ready=0;
  while (paperf.ready == 0)
    {
      paperf.obj = fl_do_forms();

      /* Exit */
      if (paperf.obj == paperf.XWok)
	{
	  paperf.ready = 1;
	}

      /* With mm */
      if (paperf.obj == paperf.XWxsizemm)
	{
	  strptr = fl_get_input(paperf.XWxsizemm);
	  strcpy(astr,strptr);
	  paperf.xmm = atof(astr);
	  paperf.xi = paperf.xmm/25.4;
	}
      /* With i */
      if (paperf.obj == paperf.XWxsizeI)
	{
	  strptr = fl_get_input(paperf.XWxsizeI);
	  strcpy(astr,strptr);
	  paperf.xi = atof(astr);
	  paperf.xmm = paperf.xi*25.4;
	}

      /* Height mm */
      if (paperf.obj == paperf.XWysizemm)
	{
	  strptr = fl_get_input(paperf.XWysizemm);
	  strcpy(astr,strptr);
	  paperf.ymm = atof(astr);
	  paperf.yi = paperf.ymm/25.4;
	}
      /* Height i */
      if (paperf.obj == paperf.XWysizeI)
	{
	  strptr = fl_get_input(paperf.XWysizeI);
	  strcpy(astr,strptr);
	  paperf.yi = atof(astr);
	  paperf.ymm = paperf.yi*25.4;
	}

      strptr = DoubleStr(paperf.xmm);
      strcpy(astr,strptr);
      fl_set_input(paperf.XWxsizemm,astr);
      strptr = DoubleStr(paperf.ymm);
      strcpy(astr,strptr);
      fl_set_input(paperf.XWysizemm,astr);
      strptr = DoubleStr(paperf.xi);
      strcpy(astr,strptr);
      fl_set_input(paperf.XWxsizeI,astr);
      strptr = DoubleStr(paperf.yi);
      strcpy(astr,strptr);
      fl_set_input(paperf.XWysizeI,astr);
    }
  fl_set_app_mainform(mf.form);

  fl_hide_form(paperf.form);
  fl_free_form(paperf.form);
  paperf.form=NULL;

  /* Select Main Window for Canvas */
  fl_winset(mf.form->window);

  /* Landscape Check */
  if (paperf.xmm > paperf.ymm) 
    {
      xy = paperf.xmm;
      paperf.xmm = paperf.ymm;
      paperf.ymm = xy;
    }

  return;
}

/* XWPrint-Window GUI Layout */ 
void xwprint_gui(void)
{
  xwprtf.form = fl_bgn_form(FL_UP_BOX,640,100); 

   fl_set_border_width(2);

   xwprtf.XWquit = fl_add_button(FL_NORMAL_BUTTON,240,75,160,20,GR("continue_PB.str","WEITER"));
   fl_set_button_shortcut(xwprtf.XWquit,GR("continue_PB.sc","^E^e"),true);

   /* File Browser */
   xwprtf.XWbrowser = fl_add_browser(FL_HOLD_BROWSER,5,5,630,67,"");
   fl_set_browser_fontstyle(xwprtf.XWbrowser,FL_FIXED_STYLE);

  fl_end_form();
  return;
}
