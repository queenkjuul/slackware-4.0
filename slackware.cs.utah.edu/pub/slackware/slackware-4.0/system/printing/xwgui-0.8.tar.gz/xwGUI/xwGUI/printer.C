/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

/* Change: Jean-Jacques Sarton 03.09.1998
 *         fuctions never close the opened file !
 *
 * Remarks: This code will not work on all machine
 *          (order of bytes for short and long is not the same
 *           for a processor as the 68000 or sparc as for x86 processor)
 *
 *          This is not corrected !
 */

#include "xwgui.h"

/* None Exit Handler */
int nclose_cb(FL_FORM *frm,void *data);

void newSleep(int delay);
const char *strMids(char *source,int a,int b);
void strNewUpper(char *source);
const char *IntStr(int a);
const char *DoubleStr(float a);

const char *getVar(char *quality,char *paper,char *varname);

void print_gui(void);
void xwprint(void);
const char *checkPRT(int a,char *source);


/* WorkFile */
extern char xwwork[1024];   /* Picture File Selection */
extern int xwworkflag;      /* Picture File active 0=Deactive 1=active */

/* Page Datas */
extern struct pagedata pdata;

/* Mainform */
extern struct mainform mf;

/* Printerform */
extern struct printform printfm;

/* xw_Tools Printer Selection */
extern struct xwprtform xwprtf;

/* Printer General Settings */
extern struct XWGprint xwgp;

/* HomeDirectory */
extern char xpuser[1024];

/* String Vars */
extern const char *strptr;
extern char astr[256],bstr[256],cstr[256];

/* Print Vars */
int printing;
char prts[1024]="";

void printStr(void) 
{
  static char prtstr[1024];   /* C++ Schreibweise ( Nullterminierter String ) */
  static char aas[4];         /* aktuelles Zeichen, beim String-Scannen */
  static char variable[1024]; /* Variablenbnamen sowie dessen Inhalt */
  static int a,b,c;           /* Laufvariablen */
  int mo;                     /* Trennmodus */

  int zaehler=0;              /* Kontrollz�hler ob Variablen eingef�gt wurden */

  /* Grundinitialisierung */
  strcpy(prtstr,"");
  strcpy(variable,"");
  mo=0;
  a=b=c=0;

  /* dekoding printstring */ 
  for (a=1 ; a<=int(strlen(prts)) ; a++)
    {
      strptr = strMids(prts,a,1);
      strcpy(aas,strptr);
      
      /* Trennzeichen erkannt ? */
      if (strcmp(aas,"%") == 0)
	{
	  if (mo==0)
	    {
	      mo=1;
	      strcpy(variable,"");
	    }
	  else
	    {
	      mo=0;
	      /* Variable durch Variableninhalt ersetzen */
	      if (strlen(variable)>0)
		{
		  strNewUpper(variable);
		  
		  c=0;
		  /* Fest Installierte Variablen */
		  if ( (strcmp(variable,"FILE") == 0) && (c==0) )
		    {
		      strcpy(variable,xwwork);
		      c=1;
		    }

      		  if ( (strcmp(variable,"HOME") == 0) && (c==0) )
		    {
		      strcpy(variable,xpuser);
		      strcat(variable,"/");
		      c=1;
		    }
		  
		  if ( (strcmp(variable,"LANDSCAPE") == 0) && (c==0) )
		    {
		      if (pdata.rotate == 0)
			{
			  if (pdata.landscape == 0)
			    {
			      strcpy(variable,xwgp.nolandscape);
			    }
			  else
			    {
			      strcpy(variable,xwgp.landscape);
			    }
			}
		      else
			{
			  if (pdata.landscape == 0)
			    {
			      strcpy(variable,xwgp.landscape);
			    }
			  else
			    {
			      strcpy(variable,xwgp.nolandscape);
			    }
			}

		      c=1;
		    }
		  
		  if ( (strcmp(variable,"LBORDER") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = IntStr(pdata.pagel);
			}
		      else
			{
			  strptr = IntStr(pdata.pageb);
			}
		      strcpy(variable,strptr);
		      c=1;
		      
		    }
		  if ( (strcmp(variable,"RBORDER") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = IntStr(pdata.pager);
			}
		      else
			{
			  strptr = IntStr(pdata.paget);
			}
		      strcpy(variable,strptr);
		      c=1;
		    }
		  if ( (strcmp(variable,"TBORDER") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = IntStr(pdata.paget);
			}
		      else
			{
			  strptr = IntStr(pdata.pagel);
			}
		      strcpy(variable,strptr);
		      c=1;
		    }
		  if ( (strcmp(variable,"BBORDER") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = IntStr(pdata.pageb);
			}
		      else
			{
			  strptr = IntStr(pdata.pager);
			}
		      strcpy(variable,strptr);
		      c=1;
		    }			  
		  if ( (strcmp(variable,"PAPERX") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = DoubleStr(pdata.pagex);
			}
		      else
			{
			  strptr = DoubleStr(pdata.pagey);
			}
		      strcpy(variable,strptr);
		      c=1;
		    }
		  if ( (strcmp(variable,"PAPERY") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = DoubleStr(pdata.pagey);
			}
		      else
			{
			  strptr = DoubleStr(pdata.pagex);
			}
		      strcpy(variable,strptr);
		      c=1;
		    }
		  if ( (strcmp(variable,"XPOS") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = DoubleStr(pdata.picposx);
			}
		      else
			{
			  strptr = DoubleStr(pdata.picposy);
			}
		      strcpy(variable,strptr);
		      c=1;
		    }
		  if ( (strcmp(variable,"YPOS") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = DoubleStr(pdata.picposy);
			}
		      else
			{
			  strptr = DoubleStr(pdata.picposx);
			  strptr = DoubleStr(pdata.pagex-(pdata.picposx+pdata.picxmm));
			}
		      strcpy(variable,strptr);
		      c=1;
		    }
		  if ( (strcmp(variable,"XSIZE") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = DoubleStr(pdata.picxmm);
			}
		      else
			{
			  strptr = DoubleStr(pdata.picymm);
			}
		      strcpy(variable,strptr);
		      c=1;
		    }
		  if ( (strcmp(variable,"YSIZE") == 0) && (c==0) )
		    {
		      if (pdata.landscape == 0)
			{
			  strptr = DoubleStr(pdata.picymm);
			}
		      else
			{
			  strptr = DoubleStr(pdata.picxmm);
			}
		      strcpy(variable,strptr);
		      c=1;
		    }	

		  if ( (strcmp(variable,"SPOOL") == 0) && (c==0) )
		    {
		      strcpy(variable,xwgp.xw_spooler);
		      c=1;
		    }
		  if ( (strcmp(variable,"HOST") == 0) && (c==0) )
		    {
		      strcpy(variable,xwgp.xw_host);
		      c=1;
		    }

		  if ( (strcmp(variable,"DEVICE") == 0) && (c==0) )
		    {
		      strcpy(variable,xwgp.xw_name);
		      c=1;
		    }
		  
		  if ( (strcmp(variable,"XWTEST") == 0) && (c==0) )
		    {
		      strcpy(variable,"");
		      printing=1; 
		      c=1;
		    }		
		  
		  /* Normale Variable */
		  if (c==0)
		    {
		      strptr = getVar("","",variable);
		      strcpy(variable,strptr);
		      if (strcmp(variable,xwgp.fill) == 0)
			{
			  strcpy(variable,"");
			}
		      zaehler++;
		    }
		  strcat(prtstr,variable); 
		}
	    }
	}
      
      /* Character an PrintString anh�ngen */
      if ((mo==0) && (strcmp(aas,"%") != 0) )
	{
	  strcat(prtstr,aas);
	}
      
      /* Character an Variable anh�ngen */
      if ( (mo==1) && (strcmp(aas,"%") != 0) )
	{
	  strcat(variable,aas);
	}
    }

  strcpy(prts,prtstr);

  if (zaehler > 0)
    {
      printStr();
    }

  return;
}

void xwprint(void) 
{
  char               lpstr[1024];
  long               pid,pidt;   /* Prozess ID */
  int                status;
  int                a,b; 
  FILE               *fh,*fhh;
  int                prtset=0;   /* Print Selection Buffer */
  unsigned char      buf[1024];  /* Copy Buffer */
  int                size;

  printing=0;

  prtset = xwgp.prtselect;
  xwgp.prtselect--;

  /* Gimp Modus */
  if (xwgp.gimp == 1)
    {
      if (xwgp.prtselect == 0)
	{ 
	  xwgp.prtselect = 3;  /* 2 - Direktdruck gesperrt */
	}
      else
	{
	  xwgp.prtselect = 3;
	}
    }

  /* Script-Datei sichern und starten */
  if (xwgp.prtfile != NULL)
    {
      strcpy(prts,xwgp.prtfile);
      printStr();
      strcpy(astr,prts);

      if ((fh=fopen(astr,"w")) != NULL)
	{
	  for (a=0 ; a<=xwgp.prtfanz ; a++)
	    {
	      /* verfolst�ndige Skript-String */
	      strcpy(prts,xwgp.prtfdata[a]);
	      printStr();
	      /* String schreiben */	      
	      b=fputs(prts,fh);
	      b=fputs("\n",fh);
	    }
	  fclose(fh);
	  chmod(astr,S_IRUSR|S_IWUSR);
	}
    }

  /* Drucker Modus */
  /* Direktdruck */
  if (xwgp.prtselect == 0)
    {
      if (xwgp.prtdirect != NULL)
	{
	  strcpy(prts,xwgp.prtdirect);
	  printStr();
	}
    }
  /* Spooler */
  if (xwgp.prtselect == 1)
    {
      if (xwgp.prtspool != NULL)
	{
	  checkPRT();
	  strcpy(prts,xwgp.prtspool);
	  printStr();
	}
    }
  /* Gimp Direct */
  if (xwgp.prtselect == 2)
    {
      if (xwgp.prtgimpspool != NULL)
	{
	  checkPRT();
	  strcpy(prts,xwgp.prtgimpdirect);
	  printStr();
	}
    } 
  /* Gimp Spooler */
  if (xwgp.prtselect == 3)
    {
      if (xwgp.prtgimpspool != NULL)
	{
	  checkPRT();
	  strcpy(prts,xwgp.prtgimpspool);
	  printStr();
	}
    } 

  /* Druckerstring setzen */
  if (xwgp.printstr == NULL)
    {
      /* neuen Druckerstring erstellen */
      if (xwgp.printstr == NULL)
	{
	  xwgp.printstr = (char*) malloc(strlen(prts)+1);
	  strcpy(xwgp.printstr,prts);
	}
      else
	{
	  xwgp.printstr = (char*) realloc(xwgp.printstr,strlen(prts)+1);
	  strcpy(xwgp.printstr,prts);
	}
    }

  /* Druckerstring starten */
  if (xwgp.printstr != NULL)
    {
      if ( (strlen(xwgp.printstr) > 0) && (strlen(xwwork) > 0) )
	{
	  strcpy(prts,xwgp.printstr);
	  printStr();

    	  if (printing==0)
	    {
	      fl_deactivate_form(mf.form);
	      
	      if (xwgp.prtselect == 0)
		{
		  /* Direct Printing */
		  pid = fl_exe_command(prts,0);
		}
	      else
		{
		  /* Spool Priniting */
		  pid = 1;
		}
	      if (pid>0)
		{
		  
		  /* Printer-Window GUI Layout */ 
		  print_gui();

		  /* Form Doublebuffering */
		  fl_set_form_dblbuffer(printfm.form,1);      
		  fl_show_form(printfm.form,FL_PLACE_CENTER,FL_TRANSIENT,xwInfo);

		  fl_set_app_mainform(printfm.form);

		  /* Exit Handler */
		  fl_set_form_atclose(printfm.form,nclose_cb,"1");
		  
		  /* Print String */		  
		  strcpy(lpstr,prts);
		  while (strlen(lpstr)>0)
		    {
		      if (strlen(lpstr)>100)
			{
			  strptr = strMids(lpstr,1,100);
			  fl_addto_browser(printfm.XWfile,strptr);
			  strptr = strMids(lpstr,101,strlen(lpstr)-100);
			  strcpy(lpstr,strptr);
			}
		      else
			{
			  fl_addto_browser(printfm.XWfile,lpstr);
			  strcpy(lpstr,"");
			}
		    } 
		  
		  /* Direct Print */
		  if (xwgp.prtselect == 0)
		    {
		      printfm.ready=0;
		      while (printfm.ready == 0)
			{
			  /* printfm.obj = fl_do_forms(); */
			  printfm.obj = fl_check_forms();
			  
			  /* check PID */
			  pidt = waitpid(pid,&status,WNOHANG);		     
			  if (pidt == -1)
			    { 
			      printfm.ready = 1;
			    }
			  
			  /* ###########################################
			     # Control Panel                           #
			     ########################################### */
			  
			  /* Connect ? Yes */
			  if (printfm.obj == printfm.XWquit)
			    {
			      printfm.ready = 1;
			      
			      /* Druck-Prozess terminieren */
			      if (xwgp.prtselect == 0)
				{
				  a = kill(pid,SIGTERM);
				}
			    }
			}
		      newSleep(250000);
		    }

		  /* Spool Print */
		  if (xwgp.prtselect == 1)
		    {
		      if ( (fh=fopen(xwwork,"rb")) != NULL )
			{
			  if ( (fhh=popen(prts,"w")) != NULL )
			    {
			      while ( (size=fread(buf,1,sizeof(buf),fh)) > 0)
				{
				  printfm.obj = fl_check_forms();
				  fwrite(buf,1,size,fhh);
				}
			      pclose(fhh);
			    }
			  fclose(fh);
			}
		    }
		  
		  /* Gimp Direct Print */
		  if (xwgp.prtselect == 2)
		    {
		      if ( (fhh=popen(prts,"w")) != NULL )
			{
			  while ( (size=fread(buf,1,sizeof(buf),stdin)) > 0)
			    {
			      printfm.obj = fl_check_forms();
			      fwrite(buf,1,size,fhh);
			    }
			  pclose(fhh);
			} 
		    }

		  /* Gimp Spool Print */
		  if (xwgp.prtselect == 3)
		    {
		      if ( (fhh=popen(prts,"w")) != NULL )
			{
			  while ( (size=fread(buf,1,sizeof(buf),stdin)) > 0)
			    {
			      printfm.obj = fl_check_forms();
			      fwrite(buf,1,size,fhh);
			    }
			  pclose(fhh);
			} 
		    }

		  fl_set_app_mainform(mf.form);

		  fl_hide_form(printfm.form);
		  fl_free_form(printfm.form);
		  printfm.form=NULL;

		}		  
	      
	      fl_activate_form(mf.form);
	    }
	  else
	    {
	      cout << prts << "\n";
	    }
	}
    }

  /* Reset Print Selection */
  xwgp.prtselect = prtset;

  return;
}




/*******************************************************************/ 
/*                                                                 */ 
/* NAME:      _getData                                             */ 
/*                                                                 */ 
/* FUNCTION:  read from the given file and load data's we need     */
/*                                                                 */
/* INPUT:     char *dir                                            */
/*            char *name                                           */
/*                                                                 */
/* OUTPUT:    xwPrinters_t *xwPrinters                             */ 
/*                                                                 */ 
/* RETURN:                                                         */ 
/*                                                                 */ 
/* REMARKS:                                                        */ 
/*                                                                 */ 
/*******************************************************************/ 

void _getData(char *dir, char *name, xwPrinters_t *xwPrinters)
{
   FILE *fp;
   char  buf[1024];
   int   l;
   char  *s;
   static char *var[] = {
      "XW_PrintHost",
      "XW_Comment",
      "XW_SpoolDir",
      "XW_dev",
      "XW_IsXwd",
   };

   xwPrinters->doIt  = FALSE;

   xwPrinters->name = strdup(name+3);
   l = strlen(xwPrinters->name);
   xwPrinters->name[l-5] = '\0';

   strcpy(buf, dir);
   strcat(buf,"/");
   strcat(buf,name);
  
   fp =  fopen(buf, "r");
   if ( fp != NULL )
   {
      while ( fgets(buf, sizeof(buf),fp ) != NULL )
      {
         if ( strncmp(buf, var[0], strlen(var[0])) == 0 )
         {
            if ( xwPrinters->host == NULL )
            {
               s = buf + strlen(var[0]);
               while ( *s && isspace(*s) ) s++;
               if ( *s )
               {
                  xwPrinters->host = strdup(s);
                  s = xwPrinters->host;
                  while ( *s && !isspace(*s)  ) *s++;
                  *s = '\0';
               }
            }
         }
         else if ( strncmp(buf, var[1], strlen(var[1])) == 0 )
         {
            if ( xwPrinters->comment == NULL )
            {
               s = buf + strlen(var[1]);
               while ( *s && isspace(*s) ) s++;
               if ( *s )
               {
                  xwPrinters->comment = strdup(s);
                  l = strlen(xwPrinters->comment);
                  if ( l )
                     xwPrinters->comment[l-1] = '\0';
               }
            }
         }
         else if ( strncmp(buf, var[2], strlen(var[2])) == 0 )
         {
            if ( xwPrinters->spooldir == NULL )
            {
               s = buf + strlen(var[2]);
               while ( *s && isspace(*s) ) s++;
               if ( *s )
               {
                  xwPrinters->spooldir = strdup(s);
                  s = xwPrinters->spooldir;
                  while ( *s && !isspace(*s)  ) *s++;
                  *s = '\0';
               }
            }
         }
         else if ( strncmp(buf, var[3], strlen(var[3])) == 0 )
         {
            if ( xwPrinters->type == NULL )
            {
               s = buf + strlen(var[3]);
               while ( *s && isspace(*s) ) s++;
               if ( *s )
               {
                  xwPrinters->type = strdup(s);
                  s = xwPrinters->type;
                  while ( *s && !isspace(*s)  ) *s++;
                  *s = '\0';
               }
            }
         }
         else if ( strncmp(buf, var[4], strlen(var[4])) == 0 )
         {
            xwPrinters->doIt = TRUE;
         }
      }
      fclose(fp);
   }
   if ( xwPrinters->comment == NULL )
   {
      xwPrinters->comment = strdup("");
   }
}

/*******************************************************************/ 
/*                                                                 */ 
/* NAME:      cmpName                                              */ 
/*                                                                 */ 
/* FUNCTION:  compare function for qsort                           */
/*                                                                 */
/* INPUT:                                                          */
/*                                                                 */
/* OUTPUT:                                                         */ 
/*                                                                 */ 
/* RETURN:                                                         */ 
/*                                                                 */ 
/* REMARKS:                                                        */ 
/*                                                                 */ 
/*******************************************************************/ 

int cmpName(const void *a, const void *b)
{
   return strcmp(((xwPrinters_t*)a)->name,
                 ((xwPrinters_t*)b)->name);
}

/*******************************************************************/ 
/*                                                                 */ 
/* NAME:      _readDir                                             */ 
/*                                                                 */ 
/* FUNCTION:  scan the directory for desc. files and load any      */
/*            data's from then                                     */
/*                                                                 */
/* INPUT:     char *dir                                            */
/*            char *queryPrinter how to send a query to xw_snd or  */
/*                               NULL                              */
/*                                                                 */
/* OUTPUT:    xwPrinters_t *xwPrinters                             */ 
/*            int          *nb                                     */ 
/*                                                                 */ 
/* RETURN:                                                         */ 
/*                                                                 */ 
/* REMARKS:                                                        */ 
/*                                                                 */ 
/*******************************************************************/ 

void _readDir(char *dir, xwPrinters_t **xwPrinters, int *nb, char *queryPrinter)
{
   DIR           *dirp;
   struct dirent *direntp;
   int            l;
   xwPrinters_t  *xwp = NULL;
   char           queryBuf[1024];
   int            alive;
   *nb = 0;

   dirp = opendir(dir);
   if ( dirp == NULL )
   {
      return;
   }

   while ( (direntp = readdir(dirp)) )
   {
      if ( *direntp->d_name == '.' )
      {
         continue;
      }
      if ( strncmp(direntp->d_name, "xw_", 3) == 0 )
      {
         l = strlen(direntp->d_name) - 5;
         if ( l > 0 )
         {
            if ( strcmp(direntp->d_name+l, ".desc") == 0 )
            {
               if ( *nb == 0 )
               {
                  xwp = (xwPrinters_t*)malloc(sizeof(xwPrinters_t));
               }
               else
               {
                  xwp = (xwPrinters_t*)realloc(xwp,
                                               sizeof(xwPrinters_t) * (*nb+1));
               }
               if ( xwp == NULL )
               {
                  break;
               }
               memset(&xwp[*nb], 0 , sizeof(xwPrinters_t));
               _getData(dir, direntp->d_name, &xwp[*nb]);

               if ( xwp[*nb].doIt &&         xwp[*nb].spooldir != NULL && 
                    xwp[*nb].type != NULL && xwp[*nb].name     != NULL &&
                    xwp[*nb].host != NULL
                  )
               {
                  alive = 1;
                  if ( queryPrinter )
                  {
                     sprintf(queryBuf,
                             queryPrinter, xwp[*nb].host);
                     if ( system(queryBuf) == 0 )
                        alive = 1;
                     else
                        alive = 0;
                  }
               }
               else
               {
                  alive = 0;
               }

               if ( alive == 1 )
               {
                  *nb += 1;
               }
               else
               {
                  if ( xwp[*nb].name != NULL )
                  {
                     free((void*) xwp[*nb].name);
                     xwp[*nb].name = NULL;
                  }

                  if ( xwp[*nb].type != NULL )
                  {
                     free((void*) xwp[*nb].type);
                     xwp[*nb].type = NULL;
                  }

                  if ( xwp[*nb].comment != NULL )
                  {
                     free((void*) xwp[*nb].comment);
                     xwp[*nb].comment = NULL;
                  }

                  if ( xwp[*nb].spooldir != NULL )
                  {
                     free((void*) xwp[*nb].spooldir);
                     xwp[*nb].spooldir = NULL;
                  }

                  if ( xwp[*nb].host != NULL )
                  {
                     free((void*) xwp[*nb].host);
                     xwp[*nb].host = NULL;
                  }

                  if ( *nb == 0 )
                  {
                     free((void*)xwp);
                     xwp = NULL;
                  }
               }
            }
         }
      }
   }

   if ( xwp != NULL )
   {
      qsort(xwp, *nb, sizeof(xwPrinters_t), cmpName);
   }

   *xwPrinters = xwp;
   closedir(dirp);
}

/*

  HOST und NAME Variable einbauen 

*/

void checkPRT(void)
{
  int           i;
  xwPrinters_t *xwPrinters       = NULL;
  int           xwPrintersNb     = 0;
  char         *queryPrinter     = NULL;

  int          a=0;
  int          b=0;

  _readDir("/usr/local/lib/xw", &xwPrinters, &xwPrintersNb, queryPrinter);

  /* Count Printers */
  for ( i = 0;  i < xwPrintersNb; i++ )
    {
      if (strcmp(xwPrinters[i].type,xwgp.xw_device) == 0)
	{
	  a++;
	  b=i;
	}
    }

  /* select printer */
  if (a>1)
    {
      xwprint_gui();

      /* Scan Browser Entrys */
      for ( i = 0;  i < xwPrintersNb; i++ )
	{
	  if (strcmp(xwPrinters[i].type,xwgp.xw_device) == 0)
	    {
	      /* Create Browser Entry */
	      strcpy(astr,"");
	      strptr = LStr(xwPrinters[i].name,35);
	      strcat(astr,strptr);
	      strcat(astr," ");
	      strptr = LStr(xwPrinters[i].host,35);
	      strcat(astr,strptr);
	      fl_addto_browser(xwprtf.XWbrowser,astr);
	    }
	}

      b=1;
      fl_select_browser_line(xwprtf.XWbrowser,b);

      /* Form Doublebuffering */
      fl_set_form_dblbuffer(xwprtf.form,1);      
      fl_show_form(xwprtf.form,FL_PLACE_MOUSE,FL_TRANSIENT,xwInfo);

      fl_set_app_mainform(xwprtf.form);

      /* Exit Handler */
      fl_set_form_atclose(xwprtf.form,nclose_cb,"1");

      xwprtf.ready=0;
      while (xwprtf.ready == 0)
	{
	  xwprtf.obj = fl_do_forms();
      
	  /* Exit */
	  if (xwprtf.obj == xwprtf.XWquit)
	    {
	      xwprtf.ready = 1;
	    }

	  if (xwprtf.obj == xwprtf.XWbrowser)
	    {
	      b = fl_get_browser(xwprtf.XWbrowser);
	    }

	}
      fl_set_app_mainform(mf.form);
      
      fl_hide_form(xwprtf.form);
      fl_free_form(xwprtf.form);
      xwprtf.form=NULL;

      /* Select Main Window for Canvas */
      fl_winset(mf.form->window);

      /* get Printer Datas */
      a=0;
      for ( i = 0;  i < xwPrintersNb; i++ )
	{
	  if (strcmp(xwPrinters[i].type,xwgp.xw_device) == 0)
	    {
	      a++;
	      if (a == b)
		{
		  b=i;
		}
	    }
	}

      /* Host */
      if (xwgp.xw_host == NULL)
	{
	  xwgp.xw_host = (char*) malloc(strlen(xwPrinters[b].host)+1);
	  strcpy(xwgp.xw_host,xwPrinters[b].host);
	}
      else
	{
	  xwgp.xw_host = (char*) realloc(xwgp.xw_host,strlen(xwPrinters[b].host)+1);
	  strcpy(xwgp.xw_host,xwPrinters[b].host);
	}
      /* Spooler */
      if (xwgp.xw_spooler == NULL)
	{
	  xwgp.xw_spooler = (char*) malloc(strlen(xwPrinters[b].spooldir)+1);
	  strcpy(xwgp.xw_spooler,xwPrinters[b].spooldir);
	}
      else
	{
	  xwgp.xw_spooler = (char*) realloc(xwgp.xw_spooler,strlen(xwPrinters[b].spooldir)+1);
	  strcpy(xwgp.xw_spooler,xwPrinters[b].spooldir);
	}
      /* Device */
      if (xwgp.xw_name == NULL)
	{
	  xwgp.xw_name = (char*) malloc(strlen(xwPrinters[b].name)+1);
	  strcpy(xwgp.xw_name,xwPrinters[b].name);
	}
      else
	{
	  xwgp.xw_name = (char*) realloc(xwgp.xw_name,strlen(xwPrinters[b].name)+1);
	  strcpy(xwgp.xw_name,xwPrinters[b].name);
	}

    }
  else
    {
      if (a==1)
	{
	  /* Host */
	  if (xwgp.xw_host == NULL)
	    {
	      xwgp.xw_host = (char*) malloc(strlen(xwPrinters[b].host)+1);
	      strcpy(xwgp.xw_host,xwPrinters[b].host);
	    }
	  else
	    {
	      xwgp.xw_host = (char*) realloc(xwgp.xw_host,strlen(xwPrinters[b].host)+1);
	      strcpy(xwgp.xw_host,xwPrinters[b].host);
	    }
	  /* Spooler */
	  if (xwgp.xw_spooler == NULL)
	    {
	      xwgp.xw_spooler = (char*) malloc(strlen(xwPrinters[b].spooldir)+1);
	      strcpy(xwgp.xw_spooler,xwPrinters[b].spooldir);
	    }
	  else
	    {
	      xwgp.xw_spooler = (char*) realloc(xwgp.xw_spooler,strlen(xwPrinters[b].spooldir)+1);
	      strcpy(xwgp.xw_spooler,xwPrinters[b].spooldir);
	    }
	  /* Device */
	  if (xwgp.xw_name == NULL)
	    {
	      xwgp.xw_name = (char*) malloc(strlen(xwPrinters[b].name)+1);
	      strcpy(xwgp.xw_name,xwPrinters[b].name);
	    }
	  else
	    {
	      xwgp.xw_name = (char*) realloc(xwgp.xw_name,strlen(xwPrinters[b].name)+1);
	      strcpy(xwgp.xw_name,xwPrinters[b].name);
	    }
	}
    }
  

  return;
}
