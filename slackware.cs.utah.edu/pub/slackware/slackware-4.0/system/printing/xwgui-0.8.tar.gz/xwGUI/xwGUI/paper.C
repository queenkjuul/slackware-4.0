/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include "xwgui.h"


/* Page Datas */
extern struct pagedata pdata;

/* Mainform */
extern struct mainform mf;

/* Frameform */
extern struct frameform framef;

/* Paper Size Form */
extern struct paperform paperf;

/* HomeDirectory */
extern char xpuser[1024];

/* String Vars */
extern const char *strptr;
extern char astr[256],bstr[256],cstr[256];

/* WorkFile */
extern char xwwork[1024];   /* Picture File Selection */
extern int xwworkflag;      /* Picture File active 0=Deactive 1=active */

/* ##################################### */
/* #                                   # */
/* # PAPER FORMAT DRAW                 # */
/* #                                   # */
/* ##################################### */

/* Set Paper-Format */
void setpaper(void) /*fold00*/
{
    /* 0 = mm / 1 = cm / 2 = inch */
    int b;
    float x=0,y=0;

    b = pdata.page;

    /* A5 - 297 x 148 mm */
    if (b == 1)
    {
        x=148;
        y=210;
    }
    /* A4 - 210 x 297 mm */
    if (b == 2)
    {
        x=210;
        y=297;
    }
    /* A3 - 297 x 420 mm */
    if (b == 3)
    {
        x=297;
        y=420;
    }
    /* Executive - 7.25 x 10.5 Inch */
    if (b == 4)
    {
        x=184.15;
        y=266.7;
    }
    /* Letter - 8.5 x 11 Inch */
    if (b == 5)
    {
        x=215.9;
        y=279.4;
    }
    /* Legal - 8.5 x 14 Inch */
    if (b == 6)
    {
        x=215.9;
        y=355.6;
    }
    /* Ledger - 11 x 17 Inch */
    if (b == 7)
    {
        x=279.4;
        y=431.8;
    }
    /* Tabloid - 11 x 17 Inch */
    if (b == 8)
    {
        x=279.4;
        y=431.8;
    }
    /* Panorama - 594 x 210 */
    if (b == 9)
    {
        x=210;
        y=594;
    }

    /* Custom Paper */
    if (b == 10)
      {
	fl_deactivate_form(mf.form);
	paper_gui();
	fl_activate_form(mf.form); 
	x = paperf.xmm;
	y = paperf.ymm;
      }


    /* PData */
    pdata.pagex = x;
    pdata.pagey = y;

    /* Change X - Y for Landscape Mode */
    if (pdata.landscape == 1)
    {
        pdata.buffer = pdata.pagex;
        pdata.pagex = pdata.pagey;
        pdata.pagey = pdata.buffer;
    }
    /* Page Aspect Ratio */
    pdata.paspect=pdata.pagex/pdata.pagey;

    /* Inch, mm, cm - Not supported yet */
    pdata.pflag=0;

    return;
}

/* draw page */
void drawpaper(int flag) 
{
    int aa,bb;

    aa=flag;

    /* all - clear page frame */
    if (aa==xw_clear)
    {
        /*
         fl_rectf(mf.x_pwf,36+2,mf.pwf-4,mf.pwf-4,FL_COL1);
         */
        aa=xw_paper;
    }

    /* paper - draw paper */
    if (aa==xw_paper)
    {
        if (pdata.pagex<pdata.pagey)
        {
            /* Paint Paper */
            fl_rectf(mf.x_pwf,26+12,IRound( (mf.pwf-4) *pdata.paspect ),(mf.pwf-4),FL_WHITE);
            /* mm per Pixel */
            pdata.xpsize = pdata.pagex/( (mf.pwf-4) *pdata.paspect );
            pdata.ypsize = pdata.pagey/ ( mf.pwf-4 );
            /* Clear Rest */
            fl_rectf(mf.x_pwf+IRound( (mf.pwf-4) *pdata.paspect),38,IRound(mf.pwf - (IRound( (mf.pwf-4) *pdata.paspect)+4)),(mf.pwf-4),FL_COL1);
        }
        if (pdata.pagex>pdata.pagey)
        {
            /* Paint Paper */
            fl_rectf(mf.x_pwf,26+12,(mf.pwf-4),IRound((mf.pwf-4)/pdata.paspect),FL_WHITE);
            /* mm per Pixel */
            pdata.xpsize = pdata.pagex/ ( mf.pwf-4 );
            pdata.ypsize = pdata.pagey/( ( mf.pwf-4 )/pdata.paspect);
            /* Clear Rest */
            fl_rectf(mf.x_pwf,38+IRound((mf.pwf-4)/pdata.paspect),(mf.pwf-4),IRound(mf.pwf - (IRound((mf.pwf-4)/pdata.paspect) +4)),FL_COL1);
        }

        aa=xw_border;
    }

    /* border - draw border */
    if (aa==xw_border)
    {
        fl_rectbound(mf.x_pwf+IRound(float(pdata.pagel)/pdata.xpsize),26+12+IRound(float(pdata.paget)/pdata.ypsize),IRound((pdata.pagex-float((pdata.pagel+pdata.pager)))/pdata.xpsize),IRound((pdata.pagey-float((pdata.paget+pdata.pageb)))/pdata.ypsize),FL_WHITE);

        aa=xw_frames;
    }

    /* frames - draw frames */
    if (aa==xw_frames)
    {
        if (framef.xwActFrame==1)
        {
            picframes();
        }

        aa=xw_picture;
    }

    /* picture - draw picture */
    if (aa==xw_picture)
    {
        if (xwworkflag == 1)
        {
            /* Draw Picture Field */
            fl_rectbound(mf.x_pwf+IRound(pdata.picposx/pdata.xpsize),26+12+IRound(pdata.picposy/pdata.ypsize),IRound(pdata.picxmm/pdata.xpsize),IRound(pdata.picymm/pdata.ypsize),FL_MCOL);

            if (pdata.landscape == 0)
            {

                if (pdata.rotate == 1)
                {
                    fl_rectbound(mf.x_pwf+ IRound(pdata.picposx/pdata.xpsize),
                                 26+12 + IRound(pdata.picposy/pdata.ypsize),
                                 5,
                                 IRound(pdata.picymm/pdata.ypsize),
                                 FL_RED);
                }
                else
                {
                    fl_rectbound(mf.x_pwf+ IRound(pdata.picposx/pdata.xpsize),
                                 26+12 + IRound(pdata.picposy/pdata.ypsize),
                                 IRound(pdata.picxmm/pdata.xpsize),
                                 5,
                                 FL_BLUE);
                }
            }
            else
            {
                if (pdata.rotate == 1)
                {
                    fl_rectbound(mf.x_pwf+ (( IRound(pdata.picposx/pdata.xpsize)+IRound(pdata.picxmm/pdata.xpsize) ) - 5 ),
                                 26+12 + IRound(pdata.picposy/pdata.ypsize),
                                 5,
                                 IRound(pdata.picymm/pdata.ypsize),
                                 FL_RED);
                }
                else
                {
                    fl_rectbound(mf.x_pwf+ IRound(pdata.picposx/pdata.xpsize),
                                 26+12 + IRound(pdata.picposy/pdata.ypsize),
                                 IRound(pdata.picxmm/pdata.xpsize),
                                 5,
                                 FL_BLUE);
                }
            }

            setdpi();
        }
    }

    /* calcpic - calculate picture */
    if (aa==xw_calcpic)
    {
        /* Normal Picture Calculation */
        bb=0;

        /* Special DPI Calculation */
        /* Picture Calculation 75 DPI */
	pdata.picymm = (pdata.y/75)*25.4;
	pdata.picxmm = pdata.picymm * pdata.aspect;

	if ( (pdata.landscape==0) && (pdata.rotate==0) )
	  {
	    pdata.picxmm = (pdata.x/75)*25.4; /* pagex - Borders */
	    pdata.picymm = pdata.picxmm / pdata.aspect;
	  }
	if ( (pdata.landscape==1) && (pdata.rotate==1) )
	  {
	    pdata.picxmm = (pdata.x/75)*25.4; /* pagex - Borders */
	    pdata.picymm = pdata.picxmm / pdata.aspect;
	  }

        /* Picture Maximal Size */
        pdata.picmaxx = pdata.pagex-(pdata.pagel+pdata.pager);                  /* pagex - Borders */
        pdata.picmaxy = (pdata.pagex-(pdata.pagel+pdata.pager)) / pdata.aspect;
        if ( (pdata.picymm > (pdata.pagey-(pdata.paget+pdata.pageb))) ||
             (pdata.picxmm > (pdata.pagex-(pdata.pagel+pdata.pager))) )
        {
            /* Picture Calculation */
            pdata.picymm = (pdata.y/75)*25.4;
            pdata.picxmm = pdata.picymm * pdata.aspect;
            /* Picture Maximal Size */
            pdata.picmaxx = pdata.pagey-(pdata.paget+pdata.pageb);
            pdata.picmaxy = (pdata.pagey-(pdata.paget+pdata.pageb)) * pdata.aspect;
        }
        if ( (pdata.picymm <= (pdata.pagey-(pdata.paget+pdata.pageb)) ) &&
             (pdata.picxmm <= (pdata.pagex-(pdata.pagel+pdata.pager)) ) )
        {
            bb=1;
        }

        /* Normal Picture Calculation */
        if (bb==0)
        {
            /* Picture Calculation */
            pdata.picxmm = pdata.pagex-(pdata.pagel+pdata.pager); /* pagex - Borders */
            pdata.picymm = pdata.picxmm / pdata.aspect;
            /* Picture Maximal Size */
            pdata.picmaxx = pdata.picxmm;
            pdata.picmaxy = pdata.picymm;
            if (pdata.picymm > (pdata.pagey-(pdata.paget+pdata.pageb)) ) /* pagey - Borders */
            {
                /* Picture Calculation */
                pdata.picymm = pdata.pagey-(pdata.paget+pdata.pageb);
                pdata.picxmm = pdata.picymm * pdata.aspect;
                /* Picture Maximal Size */
                pdata.picmaxx = pdata.picxmm;
                pdata.picmaxy = pdata.picymm;
            }
        }

        /* Picture Center */
        /*
         pdata.picposx = ((pdata.pagex-(pdata.picmaxx+pdata.pagel+pdata.pager)) /2)+pdata.pagel;
         pdata.picposy = ((pdata.pagey-(pdata.picmaxy+pdata.paget+pdata.pageb)) /2)+pdata.paget;
         */
        pdata.picposx = ((pdata.pagex-(pdata.picxmm+pdata.pagel+pdata.pager)) /2)+pdata.pagel;
        pdata.picposy = ((pdata.pagey-(pdata.picymm+pdata.paget+pdata.pageb)) /2)+pdata.paget;
    }

    /* fullsize - calculate picture */
    if (aa==xw_fullsize)
    {
        /* Normal Picture Calculation */
        bb=0;

        /* scale Picture */
        if ( IRound( (pdata.pagex-(pdata.pagel+pdata.pager)) /pdata.aspect) <  IRound(pdata.pagey-(pdata.paget+pdata.pageb)) )
        {
            pdata.picxmm =  IRound(pdata.pagex-(pdata.pagel+pdata.pager));
            pdata.picymm =  IRound( (pdata.pagex-(pdata.pagel+pdata.pager)) /pdata.aspect);
            pdata.picposx = pdata.pagel;
            pdata.picposy = IRound( (pdata.pagey-pdata.picymm) /2 );
        }
        else
            if ( IRound( (pdata.pagey-(pdata.paget+pdata.pageb)) *pdata.aspect) <  IRound(pdata.pagex-(pdata.pagel+pdata.pager)) )
            {
                pdata.picxmm =  IRound( (pdata.pagey-(pdata.paget+pdata.pageb)) *pdata.aspect);
                pdata.picymm =  IRound( pdata.pagey-(pdata.paget+pdata.pageb));
                pdata.picposx = IRound( (pdata.pagex-pdata.picxmm) /2 );
                pdata.picposy = pdata.paget;
            }
    }

    return;
}

/* calculate & display DPI */
void setdpi(void) /*fold00*/
{
    if (mf.picture == 1)
    {
        strptr = GR("leftB.str","Linker Rand  (mm):");
        strcpy(astr,strptr);
        strcat(astr," ");
        strptr = IntStr(IRound(pdata.picposx));
        strcpy(bstr,strptr);
        strptr = RStr(bstr,5);
        strcat(astr,strptr);
        strcat(astr,"\n");

        strptr = GR("rightB.str","Rechter Rand (mm):");
        strcat(astr,strptr);
        strcat(astr," ");
        strptr = IntStr(IRound( pdata.pagex - ( pdata.picposx+pdata.picxmm ) ));
        strcpy(bstr,strptr);
        strptr = RStr(bstr,5);
        strcat(astr,strptr);
        strcat(astr,"\n");

        strptr = GR("topB.str","Oberer Rand  (mm):");
        strcat(astr,strptr);
        strcat(astr," ");
        strptr = IntStr(IRound( pdata.picposy ));
        strcpy(bstr,strptr);
        strptr = RStr(bstr,5);
        strcat(astr,strptr);
        strcat(astr,"\n");

        strptr = GR("buttomB.str","Unterer Rand (mm):");
        strcat(astr,strptr);
        strcat(astr," ");
        strptr = IntStr(IRound( pdata.pagey - ( pdata.picposy+pdata.picymm ) ));
        strcpy(bstr,strptr);
        strptr = RStr(bstr,5);
        strcat(astr,strptr);
        strcat(astr,"\n");

        strptr = GR("widthP.str","Breite       (mm):");
        strcat(astr,strptr);
        strcat(astr," ");
        strptr = IntStr(IRound( pdata.picxmm ));
        strcpy(bstr,strptr);
        strptr = RStr(bstr,5);
        strcat(astr,strptr);
        strcat(astr,"\n");

        strptr = GR("heightP.str","H�he         (mm):");
        strcat(astr,strptr);
        strcat(astr," ");
        strptr = IntStr(IRound( pdata.picymm ));
        strcpy(bstr,strptr);
        strptr = RStr(bstr,5);
        strcat(astr,strptr);
        strcat(astr,"\n");

        strptr = GR("dpiP.str","DPI              :");
        strcat(astr,strptr);
        strcat(astr," ");
        if ( (pdata.picymm>0) && (pdata.picxmm>0) )
        {
	  strptr = IntStr(IRound((pdata.x/pdata.picxmm)*25.4));
	  if ( (pdata.landscape==0) && (pdata.rotate==1) )
	    {
	      strptr = IntStr(IRound((pdata.y/pdata.picymm)*25.4));
	    }
	  if ( (pdata.landscape==1) && (pdata.rotate==0) )
	    {
	      strptr = IntStr(IRound((pdata.y/pdata.picymm)*25.4));
	    }
	  
	  strcpy(bstr,strptr);
        }
        else
        {
            strcpy(bstr,"0");
        }
        strptr = RStr(bstr,5);
        strcat(astr,strptr);

        fl_set_object_label(mf.XWDPI,astr);
    }

    return;
}
