/* xwGUI -- an X11-GUI for xw_print
 * Copyright (C) 1998 Stefan Kraus
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */ 

#include "xwgui.h"

/* Parser File Handle */
FILE *pfh;
/* actual line number */
int parserLine=0;
/* Parser-Level */
int parserLevel=0;
/* Errorcode */
int parserError;

/* actual Parser Line */
char pstr[1024],partstr[256];
extern char astr[256],bstr[256],cstr[256];

/* String Vars */
extern const char *strptr;

/* Page Datas */
extern struct pagedata pdata;

/* Printer General Settings */
struct XWGprint xwgp;

/* Mainform */
extern struct mainform mf;

/* 
   ########################################################################## 
   # xwGUI - Routines for Loading Prozess                                   #
   ##########################################################################
*/

/* Druckername setzen - f�r User-Prefs */
void addPrinter(char *source) /*fold00*/
{
  /* all Memory Resources free */
  if (xwgp.prtname == NULL)
    {	      
      xwgp.prtname = (char*) malloc(strlen(source)+1);
    }
  else
    {
    xwgp.prtname = (char*) realloc(xwgp.prtname,strlen(source)+1);
    }
  strcpy(xwgp.prtname,source);
  return;
}

/* eine weiter Qualit�tsgruppe zuf�gen */
void addQuality(char *source) /*fold00*/
{
  xwgp.anzQuality++;
  if (xwgp.quality[xwgp.anzQuality] == NULL)
    {
      xwgp.quality[xwgp.anzQuality] = (char*) malloc(strlen(source)+1);
    }
  else
    {
      xwgp.quality[xwgp.anzQuality] = (char*) realloc(xwgp.quality[xwgp.anzQuality],strlen(source)+1);
    }
  strcpy( xwgp.quality[xwgp.anzQuality] ,source);
  return;
}

/* ein weitere Papierart zuf�gen */
void addPaper(char *source) 
{
  if (xwgp.anzPaper[xwgp.anzQuality] < 11)
    {
      xwgp.anzPaper[xwgp.anzQuality]++;
      if (xwgp.paper[xwgp.anzQuality] [xwgp.anzPaper[xwgp.anzQuality]] == NULL)
	{
	  xwgp.paper[xwgp.anzQuality] [xwgp.anzPaper[xwgp.anzQuality]] = (char*) malloc(strlen(source)+1);
	}
      else
	{
	  xwgp.paper[xwgp.anzQuality] [xwgp.anzPaper[xwgp.anzQuality]] = (char*) realloc(xwgp.paper[xwgp.anzQuality] [xwgp.anzPaper[xwgp.anzQuality]],strlen(source)+1);
	}
      
      strcpy(xwgp.paper[xwgp.anzQuality] [xwgp.anzPaper[xwgp.anzQuality]],source);
    }
  else
    {
      strcpy(astr,GR("papererror1_PB.str","Papier Fehler in Zeile"));
      strcat(astr," ");
      strptr = IntStr(parserLine);
      strcat(astr,strptr);
      strcpy(bstr,GR("papererror2_PB.str","Zu viele Papier Eintr�ge !!!"));
      strcpy(cstr,"");
      fl_show_alert(astr,bstr,cstr,0);
      exit(0);
    }

  return;
}

/* Variablendefinition einleiten */
void addDef(char *asource,char *bsource)
{
  int a=0;
  int b;

  /* Aktuelle Definition */
  xwgp.actSet=-1;

  /* Pr�fen ob Definition schon existiert */
  for (b=1 ; b<=xwgp.anzSets ; b++)
    {
      if ( (xwgp.prtQuality[b] != NULL) && (xwgp.prtPaper[b] != NULL) )
	{
	  if ( (strcmp(xwgp.prtQuality[b],asource) == 0) && (strcmp(xwgp.prtPaper[b],bsource) == 0) )
	    {
	      a=b;
	    }
	}
    }

  /* Falls Definition nicht existiert */
  if (a==0)
    {
      if (xwgp.anzSets < 101)
	{
	  xwgp.anzSets++;
	  
	  /* Quality */
	  if (xwgp.prtQuality[xwgp.anzSets] == NULL)
	    {
	      xwgp.prtQuality[xwgp.anzSets] = (char*) malloc(strlen(asource)+1);
	    }
	  strcpy(xwgp.prtQuality[xwgp.anzSets],asource); 
	  
	  /* Paper */
	  if (xwgp.prtPaper[xwgp.anzSets] == NULL)
	    {
	      xwgp.prtPaper[xwgp.anzSets] = (char*) malloc(strlen(bsource)+1);
	    }
	  strcpy(xwgp.prtPaper[xwgp.anzSets],bsource);

	  xwgp.actSet=xwgp.anzSets;
	}
      else
	{
	  strcpy(astr,GR("deferror1_PB.str","Definitions Fehler in Zeile"));
	  strcat(astr," ");
	  strptr = IntStr(parserLine);
	  strcat(astr,strptr);
	  strcpy(bstr,GR("deferror2_PB.str","Zu viele Definitions Sektionen !!!"));
	  strcpy(cstr,"");
	  fl_show_alert(astr,bstr,cstr,0);
	  exit(0);
	}
    }
  else
    {
      /* Definition existiert */
      xwgp.actSet=a;
    }

  return;
}

/* 
   ########################################################################## 
   # xwGUI - Routines for Var Managment                                     #
   ##########################################################################
*/

/* Variable setzen */
void setVar(char *quality,char *paper,char *varname,char *vardata) 
{
  int a,c,d;

  /* Variable im Arbeitsbereich setzen */
  if ( (strlen(quality) == 0) && (strlen(paper) == 0) )
    {
      /* Variable suchen */
      d=-1;
      for (a=0 ; a<60 ; a++)
	{
	  if (xwgp.varName[a] != NULL )
	    {
	      if (strcmp(xwgp.varName[a],varname) == 0)
		{
		  d=a;
		}
	    }
	}
      /* Variable gefunden ? */
      if (d>-1)
	{
	  /* Inhalt setzen */ 
	  if (xwgp.varData[d] == NULL)
	    {
	      xwgp.varData[d] = (char*) malloc(strlen(vardata)+1);
	    }
	  else
	    {
	      xwgp.varData[d] = (char*) realloc(xwgp.varData[d],strlen(vardata)+1);
	    }
	  strcpy(xwgp.varData[d],vardata);
	}
      else
	{
	  /* Freien Platz suchen */
	  d=-1;
	  for (a=0 ; a<60 ; a++)
	    {
	      if (xwgp.varName[a] == NULL)
		{
		  d=a;
		}
	    }

	  if (d>-1)
	    {
	      /* Variable anlegen */
	      if (xwgp.varName[d] == NULL)
		{
		  xwgp.varName[d] = (char*) malloc(strlen(varname)+1);
		}
	      else
		{
		  xwgp.varName[d] = (char*) realloc(xwgp.varName[d],strlen(varname)+1);
		}
	      strcpy(xwgp.varName[d],varname);

	      /* Inhalt setzen */ 
	      if (xwgp.varData[d] == NULL)
		{
		  xwgp.varData[d] = (char*) malloc(strlen(vardata)+1);
		}
	      else
		{
		  xwgp.varData[d] = (char*) realloc(xwgp.varData[d],strlen(vardata)+1);
		}
	      strcpy(xwgp.varData[d],vardata);
	    }
	  else
	    {
	      strcpy(astr,GR("varerror1A_PB.str","Variablen Fehler !!!("));
		  strcat(astr,varname);
		  strcat(astr,")");
	      strcpy(bstr,GR("varerror2A_PB.str","Zu viele Variablen definiert !!!"));
	      strcpy(cstr,GR("varerror3A_PB.str","�berpr�fe alle Variablen Deklarationen !!!"));
	      fl_show_alert(astr,bstr,cstr,0);
	      exit(0);
	    }
	}
    }
  else
    {
      /* Definitionsbereich suchen */
      d=-1;
      for (a=1 ; a<=100 ; a++)
	{
	  if ( (xwgp.prtQuality[a] != NULL) && (xwgp.prtPaper[a] != NULL) )
	    {
	      if ( (strcmp(xwgp.prtQuality[a],quality) == 0) && (strcmp(xwgp.prtPaper[a],paper) == 0) )
		{
		  d=a;
		}
	    }
	}

      /* Qualit�t und Papierart erstellen */
      if (d==-1)
	{
	  if ( (strlen(quality) > 0) && (strlen(paper) > 0) )
	    {
	      addDef(quality,paper);
	      d=xwgp.anzSets;
	    }
	}

      /* Qualit�t und Papierart gefunden */
      if (d>-1)
	{
	  /* Variable suchen */
	  c=-1;
	  for (a=0 ; a<60 ; a++)
	    {
	      if (xwgp.prtvar[d][a] != NULL)
		{
		  if (strcmp(xwgp.prtvar[d][a],varname) == 0)
		    {
		      c=a;
		    }
		}
	    }

	  /* Variable gefunden ? */
	  if (c>-1)
	    {
	      /* Inhalt setzen */ 
	      if (xwgp.prtdata[d][c] == NULL)
		{
		  xwgp.prtdata[d][c] = (char*) malloc(strlen(vardata)+1);
		}
	      else
		{
		  xwgp.prtdata[d][c] = (char*) realloc(xwgp.prtdata[d][c],strlen(vardata)+1);
		}
	      strcpy(xwgp.prtdata[d][c],vardata);
	    }
	  else
	    {
	      /* Freien Platz suchen */
	      c=-1;
	      for (a=0 ; a<60 ; a++)
		{
		  if (xwgp.prtvar[d][a] == NULL)
		    {
		      c=a;
		    }
		}

	      if (c>-1)
		{
		  /* Variable anlegen */
		  if (xwgp.prtvar[d][c] == NULL)
		    {
		      xwgp.prtvar[d][c] = (char*) malloc(strlen(varname)+1);
		    }
		  else
		    {
		      xwgp.prtvar[d][c] = (char*) realloc(xwgp.prtvar[d][c],strlen(varname)+1);
		    }
		  strcpy(xwgp.prtvar[d][c],varname);
		  
		  /* Inhalt setzen */ 
		  if (xwgp.prtdata[d][c] == NULL)
		    {
		      xwgp.prtdata[d][c] = (char*) malloc(strlen(vardata)+1);
		    }
		  else
		    {
		      xwgp.prtdata[d][c] = (char*) realloc(xwgp.prtdata[d][c],strlen(vardata)+1);
		    }
		  strcpy(xwgp.prtdata[d][c],vardata);
		}
	      else
		{
		  strcpy(astr,GR("varerror1B_PB.str","Variablen Fehler !!! ("));
		  strcat(astr,varname);
		  strcat(astr,")");
		  strcpy(bstr,GR("varerror2B_PB.str","Zu viele oder falsche Variablen Deklarationen !!!"));
		  strcpy(cstr,GR("varerror3B_PB.str","�berpr�fe alle Variablen Deklarationen !!!"));
		  fl_show_alert(astr,bstr,cstr,0);
		  exit(0);
		}
	    }
	}
    }

  return;
}

/* Variable auslesen */
const char *getVar(char *quality,char *paper,char *varname)
{
  int a,c,d;

  /* Variable im Arbeitsbereich setzen */
  if ( (strlen(quality) == 0) && (strlen(paper) == 0) )
    {
      /* Variable suchen */
      d=-1;
      for (a=0 ; a<60 ; a++)
	{
	  if (xwgp.varName[a] != NULL )
	    {
	      if (strcmp(xwgp.varName[a],varname) == 0)
		{
		  d=a;
		}
	    }
	}
      if (d>-1)
	{
	  return(xwgp.varData[d]);
	}
      else
	{
	  return("");
	}
    }
  else
    {
      /* Definitionsbereich suchen */
      d=-1;
      for (a=1 ; a<=100 ; a++)
	{
	  if ( (xwgp.prtQuality[a] != NULL) && (xwgp.prtPaper[a] != NULL) )
	    {
	      if ( (strcmp(xwgp.prtQuality[a],quality) == 0) && (strcmp(xwgp.prtPaper[a],paper) == 0) )
		{
		  d=a;
		}
	    }
	}

      /* Qualit�t und Papierart gefunden */
      if (d>-1)
	{
	  /* Variable suchen */
	  c=-1;
	  for (a=0 ; a<60 ; a++)
	    {
	      if (xwgp.prtvar[d][a] != NULL)
		{
		  if (strcmp(xwgp.prtvar[d][a],varname) == 0)
		    {
		      c=a;
		    }
		}
	    }

	  /* Variable gefunden ? */
	  if (c>-1)
	    {
	      /* Inhalt setzen */ 
	      return(xwgp.prtdata[d][c]);
	    }
	}
    }

  return("");
}

/* Set All Default Vars */
void setDefault(void)
{
  int a,b;

  if (xwgp.anzform>0)
    {
      for (a=1 ; a<=xwgp.anzform ; a++)
	{
	  for (b=1 ; b<=xwgp.anzObj[a] ; b++)
	    {
	      if (xwgp.formVar[a][b] != NULL)
		{
		  if (xwgp.formDef[a][b] != NULL)
		    {
		      setVar("","",xwgp.formVar[a][b],xwgp.formDef[a][b]);
		    }
		  else
		    {
		      setVar("","",xwgp.formVar[a][b],"");
		    }
		}
	    }
	}
    }

  return;
}

/* Set Printer Set */
void setPrtSet(char *quality,char *paper)
{
  int a,d;

  /* Variable aus dem Arbeitsbereich umkopieren */
  if ( (strlen(quality) == 0) && (strlen(paper) == 0) )
    {
      for (a=0 ; a<60 ; a++)
	{
	  if (xwgp.varName[a] != NULL)
	    {
	      if (xwgp.varData[a] != NULL)
		{
		  setVar(xwgp.quality[xwgp.actQuality],xwgp.paper[xwgp.actQuality][xwgp.actPaper],xwgp.varName[a],xwgp.varData[a]);
		}
	      else
		{
		  setVar(xwgp.quality[xwgp.actQuality],xwgp.paper[xwgp.actQuality][xwgp.actPaper],xwgp.varName[a],"");
		}
	    }
	}
    }
  else
    {
      /* Definitionsbereich suchen */
      d=-1;
      for (a=1 ; a<=100 ; a++)
	{
	  if ( (xwgp.prtQuality[a] != NULL) && (xwgp.prtPaper[a] != NULL) )
	    {
	      if ( (strcmp(xwgp.prtQuality[a],quality) == 0) && (strcmp(xwgp.prtPaper[a],paper) == 0) )
		{
		  d=a;
		}
	    }
	}  

      /* Dataset found */
      if (d > -1)
	{
	  for (a=0 ; a<60 ; a++)
	    {
	      if (xwgp.prtvar[d][a] != NULL)
		{
		  /* Inhalt setzen */ 
		  if (xwgp.prtdata[d][a] == NULL)
		    {
		      setVar("","",xwgp.prtvar[d][a],"");
		    }
		  else
		    {
		      setVar("","",xwgp.prtvar[d][a],xwgp.prtdata[d][a]);
		    }
		}
	    }
	}
    }

  return;
}

/* Alle Variablen auflisten */
void checkVar(void) 
{
  int a,b;

  cout << "\n\n" << xwgp.anzSets << " Sets sind vorhanden.\n\n";

  for (a=1 ; a<=xwgp.anzSets ; a++)
    {
      cout << "Qualit�t : " << xwgp.prtQuality[a] << "\n";
      cout << "Papier   : " << xwgp.prtPaper[a] << "\n";

      for (b=0 ; b<60 ; b++)
	{
	  if (xwgp.prtvar[a][b] != NULL)
	    {
	      cout << xwgp.prtvar[a][b] << "=" << xwgp.prtdata[a][b] << "\n";	 
	    }

	}
      cout << "Ready.\n\n";

    }

  return;
}

/* 
   Syntax  : allfree()
   Funktion: alle Speicherresourcen wieder freigeben 
*/
void allfree(int flag) 
{
  int a,b;

  /* Remark */
  strcpy(xwgp.remark,"#");
  /* F�ll Character */
  strcpy(xwgp.fill,"^");

 if (flag==1)
   {
     xwgp.actQuality=0;
     xwgp.actPaper=0;
   }

  /* Landscape */
  if (xwgp.landscape != NULL)
    {
      free(xwgp.landscape);
      xwgp.landscape = NULL;
    }
  /* No Landscape */
  if (xwgp.nolandscape != NULL)
    {
      free(xwgp.nolandscape);
      xwgp.nolandscape = NULL;
    }

  /* Printername */
  if (xwgp.prtname != NULL)
    {
      free(xwgp.prtname);
      xwgp.prtname = NULL;
    }
  
  /* Quality & Paper */
  for (a=0 ; a <= xwgp.anzQuality ; a++)
    {
      /* Quality */
      if (xwgp.quality[a] != NULL)
	{
	  free(xwgp.quality[a]);
	  xwgp.quality[a] = NULL;
	}

      /* Paper */
      for (b=0 ; b <= xwgp.anzPaper[a] ; b++)
	{
	  if (xwgp.paper[a][b] != NULL)
	    {
	      free(xwgp.paper[a][b]);
	      xwgp.paper[a][b] = NULL;
	    }
	}
      xwgp.anzPaper[a]=0;
    }
  xwgp.anzQuality=0;

  /* Vars */
  for (a=0 ; a<60 ; a++)
    {
      if (xwgp.varName[a] != NULL)
	{
	  free(xwgp.varName[a]);
	  xwgp.varName[a] = NULL;
	  free(xwgp.varData[a]);
	  xwgp.varData[a] = NULL;
	}
    }

  /* Set Vars */
  for (a=0 ; a<=100 ; a++)
    {
      /* Quality */
      if (xwgp.prtQuality[a] != NULL)
	{
	  free(xwgp.prtQuality[a]);
	  xwgp.prtQuality[a] = NULL;
	}
      /* Paper */
      if (xwgp.prtPaper[a] != NULL)
	{
	  free(xwgp.prtPaper[a]);
	  xwgp.prtPaper[a] = NULL;
	}

      for (b=0 ; b<60 ; b++)
	{

	  /* Vars Name */
	  if (xwgp.prtvar[a][b] != NULL)
	    {
	      free(xwgp.prtvar[a][b]);
	      xwgp.prtvar[a][b] = NULL;
	    }

	  /* Vars Data */
	  if (xwgp.prtdata[a][b] != NULL)
	    {
	      free(xwgp.prtdata[a][b]);
	      xwgp.prtdata[a][b] = NULL;
	    }
	}
    }

  xwgp.anzSets=0;

  /* Printer String */
  if (xwgp.printstr != NULL)
    {
      free(xwgp.printstr);
      xwgp.printstr = NULL;
    }
  if (xwgp.prtdirect != NULL)
    {
      free(xwgp.prtdirect);
      xwgp.prtdirect = NULL;
    }
  if (xwgp.prtspool != NULL)
    {
      free(xwgp.prtspool);
      xwgp.prtspool = NULL;
    }
  if (xwgp.prtgimpdirect != NULL)
    {
      free(xwgp.prtgimpdirect);
      xwgp.prtgimpdirect = NULL;
    }
  if (xwgp.prtgimpspool != NULL)
    {
      free(xwgp.prtgimpspool);
      xwgp.prtgimpspool = NULL;
    }

  /* xw_Tools Device */
  if (xwgp.xw_device != NULL)
    {
      free(xwgp.xw_device);
      xwgp.xw_device = NULL;
    } 
  if (xwgp.xw_spooler != NULL)
    {
      free(xwgp.xw_spooler);
      xwgp.xw_spooler = NULL;
    }
  if (xwgp.xw_name != NULL)
    {
      free(xwgp.xw_name);
      xwgp.xw_name = NULL;
    }
  if (xwgp.xw_host != NULL)
    {
      free(xwgp.xw_host);
      xwgp.xw_host = NULL;
    }

  /* Printer-Script - ArgFile */
  if (xwgp.prtfile != NULL)
    {
      free(xwgp.prtfile);
      xwgp.prtfile = NULL;
    }
  if (xwgp.prtfanz>-1)
    {
      for (a=0 ; a<=xwgp.prtfanz ; a++)
	{
	  free(xwgp.prtfdata[a]);
	  xwgp.prtfdata[a] = NULL;
	}
      xwgp.prtfanz=-1;
    }

  /* Formular */
  for (a=1 ; a<= xwgp.anzform ; a++)
    {
      /* Windowsize */
      xwgp.x[a]=0;
      xwgp.y[a]=0;
      /* Form Name */
      if (xwgp.formName[a] != NULL)
	{
	  free(xwgp.formName[a]);
	  xwgp.formName[a] = NULL;
	}
      
      for (b=0 ; b<=xwgp.anzObj[a] ; b++)
	{
	  /* Object Name */
	  if (xwgp.objName[a][b] != NULL)
	    {
	      free(xwgp.objName[a][b]);
	      xwgp.objName[a][b] = NULL;
	    }

	  /* Widget Type */
	  xwgp.widget[a][b] = 0;
	  /* Widget Format */
	  xwgp.type[a][b] = 0;
	  /* Pos. & Size */
	  xwgp.xpos[a][b] = 0;
	  xwgp.ypos[a][b] = 0;
	  xwgp.xsize[a][b] = 0;
	  xwgp.ysize[a][b] = 0;
	  /* Slider */
	  xwgp.min[a][b] = 0;
	  xwgp.max[a][b] = 0;
	  xwgp.step[a][b] = 0;
	  /* Color */
	  xwgp.color[a][b] = -1;
	  xwgp.bcolor[a][b] = -1;

	  /* Vars Name */
	  if (xwgp.formVar[a][b] != NULL)
	    {
	      free(xwgp.formVar[a][b]);
	      xwgp.formVar[a][b] = NULL;
	    }
	  if (xwgp.formDef[a][b] != NULL)
	    {
	      free(xwgp.formDef[a][b]);
	      xwgp.formDef[a][b] = NULL;
	    }
	  if (xwgp.formData[a][b] != NULL)
	    {
	      free(xwgp.formData[a][b]);
	      xwgp.formData[a][b] = NULL;
	    }
	  if (xwgp.formResult[a][b] != NULL)
	    {
	      free(xwgp.formResult[a][b]);
	      xwgp.formResult[a][b] = NULL;
	    }

	}
      xwgp.anzObj[a]=0;
    }
  xwgp.anzform=0;

  return;
}


/* 
   ########################################################################## 
   # xwGUI - Routines for Parameter-Managment                               #
   ##########################################################################
*/


/* 
   ########################################################################## 
   # xwGUI - Parser                                                         #
   ##########################################################################
*/

/* 
   Syntax  : readLN()
   Funktion: n�chste Interpretierbare Zeile einlesen.
*/
const char *readLN(void)
{
  const char *strptr;
  static char puffer[1024];

  do
    {
      /* read line */
      if (fgets(puffer,1024,pfh) != NULL)
	{
	  parserLine++;
	  if (strlen(puffer) > 0)
	    {
	      strptr = strMids(puffer,1,strlen(puffer)-1);
	      strcpy(puffer,strptr);
	      strptr = strNoRem(puffer,xwgp.remark);
	      strcpy(puffer,strptr);
	      strNewTrim(puffer);
	    }
	}
      else
	{
	  /* script not active */
	  parserError=9999;
	  /* clear puffer */
	  strcpy(puffer,"");
	}
    } while ( ( int(strlen(puffer)) == 0 ) && (parserError == 0) );
    
  return(puffer);
}


/* Get Color Number */
int getColor(char *partstr) 
{
  int a=-1;

  if (strcmp(partstr,"BLACK") == 0)
    {
      a=FL_BLACK; 
    }
  if (strcmp(partstr,"GREEN") == 0)
    {
      a=FL_GREEN;
    }
  if (strcmp(partstr,"BLUE") == 0)
    {
      a=FL_BLUE;			  
			}
  if (strcmp(partstr,"MAGENTA") == 0)
    {
      a=FL_MAGENTA;			  
    }
  if (strcmp(partstr,"COL1") == 0)
    {
      a=FL_COL1;			  
    }
  if (strcmp(partstr,"TOP_BCOL") == 0)
    {
      a=FL_TOP_BCOL;			  
    }
  if (strcmp(partstr,"RIGHT_BCOL") == 0)
    {
      a=FL_RIGHT_BCOL;			  
    }
  if (strcmp(partstr,"INACTIVE_COL") == 0)
    {
      a=FL_INACTIVE_COL;	  
    }
  if (strcmp(partstr,"INDIANRED") == 0)
    {
      a=FL_INDIANRED;	  
    }
  if (strcmp(partstr,"DARKGOLD") == 0)
    {
      a=FL_DARKGOLD;	  
    }
  if (strcmp(partstr,"ORCHID") == 0)
    {
      a=FL_ORCHID;	  
    }
  if (strcmp(partstr,"DARKTOMATO") == 0)
    {
      a=FL_DARKTOMATO;	  
    }
  if (strcmp(partstr,"FREE_COL1") == 0)
    {
      a=FL_FREE_COL1;	  
    }
  if (strcmp(partstr,"INPUT_COL2") == 0)
    {
      a=FL_INPUT_COL2;	  
    }
  if (strcmp(partstr,"RED") == 0)
    {
      a=FL_RED;	  
    }
  if (strcmp(partstr,"YELLOW") == 0)
    {
      a=FL_YELLOW;		  
    }
  if (strcmp(partstr,"CYAN") == 0)
    {
      a=FL_CYAN;	  
    }
  if (strcmp(partstr,"WHITE") == 0)
    {
      a=FL_WHITE;		  
    }
  if (strcmp(partstr,"MCOL") == 0)
    {
      a=FL_MCOL;	  
    }
  if (strcmp(partstr,"BOTTOM_BCOL") == 0)
    {
      a=FL_BOTTOM_BCOL;		  
    }
  if (strcmp(partstr,"LEFT_BCOL") == 0)
    {
      a=FL_LEFT_BCOL;	  
    }
  if (strcmp(partstr,"TOMATO") == 0)
    {
      a=FL_TOMATO;	  
    }
  if (strcmp(partstr,"SLATEBLUE") == 0)
    {
      a=FL_SLATEBLUE;	  
    }
  if (strcmp(partstr,"PALEGREEN") ==0 )
    {
      a=FL_PALEGREEN;	  
    }
  if (strcmp(partstr,"DARKCYAN") == 0)
    {
      a=FL_DARKCYAN;	  
    }
  if (strcmp(partstr,"WHEAT") == 0)
    {
      a=FL_WHEAT;  
    }
  if (strcmp(partstr,"INPUT_COL1") == 0)
    {
      a=FL_INPUT_COL1;	  
    }
  
  if (a==-1)
    {
      parserError=11;
    }

  return(a);
}

void xwParser(char *source,int act) 
{
  int a;

  /* char puffer[1024]=""; */

  /* Fehlercode */
  parserError=0;

  /* actual parser line */
  parserLine=0;
  /* Parser Level */
  parserLevel=0;

  if ( (pfh=fopen(source,"rb")) != NULL )
    {
      if ( (act==1) || (act==2) )
	{
	  /* Default Setting */
	  xwgp.actQuality=1;
	  xwgp.actPaper=1;
	}

      do
	{
	  /* load Next Command Line */
	  strptr = readLN();
	  strcpy(pstr,strptr);
	
	  /* Command Name */
	  /* cout << ">" << pstr << "< " << parserLevel << " " << parserLine << "\n"; */
	  strptr = strGetFirst(pstr," ");
	  strcpy(partstr,strptr);
	  strNewUpper(partstr);
	  strptr = strDelFirst(pstr," ");
	  strcpy(pstr,strptr);
	  
/* 
   Komandos Level 0 

   Syntax  : REMARK zeichen
   Funktion: definiert das Remarkzeichen neu

   Syntax  : PRINTER druckername
   Funktion: leitet ein Drucker-Definition ein.

*/
	  if (parserLevel == 0)
	    {

	      /* Remarkzeichen neu definieren */
	      if (strcmp(partstr,"REMARK") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (int(strlen(partstr)) == 1)
		    {
		      strcpy(xwgp.remark,partstr);
		    }
		  else
		    {
		      parserError=1;
		    }
		  strcpy(pstr,"*");
		}

	      /* Fuellcharacter  neu definieren */
	      if (strcmp(partstr,"FILL") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (int(strlen(partstr)) == 1)
		    {
		      strcpy(xwgp.fill,partstr);
		    }
		  else
		    {
		      parserError=1;
		    }
		  strcpy(pstr,"*");
		}

	      /* Printer Set */
	      if (strcmp(partstr,"PRINTER") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  parserLevel=1;
		  if (int(strlen(partstr)) > 0)
		    {
		      /* Printer zuf�gen */
		      addPrinter(partstr);
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* PREFS Kommando */
	      if (strcmp(partstr,"PREFS") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (int(strlen(partstr)) == 0)
		    {
		      parserLevel=1;
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* MAIN setzen */
	      if (strcmp(partstr,"MAIN") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (int(strlen(partstr)) > 0)
		    {
		      strcpy(xwgp.printer,partstr);
		      parserLevel=1000;
		    }
		  else
		    {
		      parserError=1;
		    }
		  strcpy(pstr,"*");
		}

	      /* END Kommando */
	      if (strcmp(partstr,"END") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  parserError=9;
		  strcpy(pstr,"*");
		}
	    
	    }


/* 
   Komandos Level 1 

   Syntax  : CHOICE quality,paper,paper,...
   Funktion: Qualit�t und seine zugeh�rigen Papierarten

   Syntax  : PRINTSTR druckerstring
   Funktion: definiert den Druckerstring

   Syntax  : GUI Bezeichnung
   Funktion: leitet eine definition einer GUI ein

   Syntax  : DEF quality,paper
   Funktion: Parameterset f�r quality/paper Kombination

*/
	  if (parserLevel == 1)
	    {

	      /* CHOICE Kommando */
	      if (strcmp(partstr,"CHOICE") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      /* Qualit�t */
		      addQuality(partstr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      
		      if (strlen(pstr)>0)
			{
			  while ( strlen(pstr) > 0 )
			    {
			      strptr = strGetParm(pstr);
			      strcpy(partstr,strptr);
			      addPaper(partstr);
			      strptr = strDelParm(pstr);
			      strcpy(pstr,strptr);
			    }
			}
		      else
			{
			  parserError=2;
			}	
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");		 
		}


	      /* DEVICE Kommando */
	      if (strcmp(partstr,"DEVICE") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      if (xwgp.xw_device == NULL)
			{
			  xwgp.xw_device = (char*) malloc(strlen(partstr)+1);
			  strcpy(xwgp.xw_device,partstr);
			}
		      else
			{
			  xwgp.xw_device = (char*) realloc(xwgp.xw_device,strlen(partstr)+1);
			  strcpy(xwgp.xw_device,partstr);
			}
		    }
		  else
		    {
		      parserError=2;
		    }		 
		  strcpy(pstr,"*");
		}

	      /* PRTDIRECT Kommando */
	      if (strcmp(partstr,"PRTDIRECT") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      if (xwgp.prtdirect == NULL)
			{
			  xwgp.prtdirect = (char*) malloc(strlen(partstr)+1);
			  strcpy(xwgp.prtdirect,partstr);
			}
		      else
			{
			  xwgp.prtdirect = (char*) realloc(xwgp.prtdirect,strlen(partstr)+1);
			  strcpy(xwgp.prtdirect,partstr);
			}
		    }
		  else
		    {
		      parserError=2;
		    }		 
		  strcpy(pstr,"*");
		}

	      /* PRTSPOOL Kommando */
	      if (strcmp(partstr,"PRTSPOOL") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      if (xwgp.prtspool == NULL)
			{
			  xwgp.prtspool = (char*) malloc(strlen(partstr)+1);
			  strcpy(xwgp.prtspool,partstr);
			}
		      else
			{
			  xwgp.prtspool = (char*) realloc(xwgp.prtspool,strlen(partstr)+1);
			  strcpy(xwgp.prtspool,partstr);
			}
		    }
		  else
		    {
		      parserError=2;
		    }		 
		  strcpy(pstr,"*");
		}

	      /* PRTGIMP Kommando */
	      if (strcmp(partstr,"PRTGIMPSPOOL") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      if (xwgp.prtgimpspool == NULL)
			{
			  xwgp.prtgimpspool = (char*) malloc(strlen(partstr)+1);
			  strcpy(xwgp.prtgimpspool,partstr);
			}
		      else
			{
		          xwgp.prtgimpspool = (char*) realloc(xwgp.prtgimpspool,strlen(partstr)+1);
			  strcpy(xwgp.prtgimpspool,partstr);
			}
		    }
		  else
		    {
		      parserError=2;
		    }		 
		  strcpy(pstr,"*");
		}
	      /* PRTGIMP Kommando */
	      if (strcmp(partstr,"PRTGIMPDIRECT") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      if (xwgp.prtgimpdirect == NULL)
			{
			  xwgp.prtgimpdirect = (char*) malloc(strlen(partstr)+1);
			  strcpy(xwgp.prtgimpdirect,partstr);
			}
		      else
			{
			  xwgp.prtgimpdirect = (char*) realloc(xwgp.prtgimpdirect,strlen(partstr)+1);
			  strcpy(xwgp.prtgimpdirect,partstr);
			}
		    }
		  else
		    {
		      parserError=2;
		    }		 
		  strcpy(pstr,"*");
		}

	      /* ARGFILE Kommando */
	      if (strcmp(partstr,"ARGFILE") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      if (xwgp.prtfile == NULL)
			{
			  xwgp.prtfile = (char*) malloc(strlen(partstr)+1);
			  strcpy(xwgp.prtfile,partstr);
			}
		      else
			{
			  xwgp.prtfile = (char*) realloc(xwgp.prtfile,strlen(partstr)+1);
			  strcpy(xwgp.prtfile,partstr);
			}
		    }
		  else
		    {
		      parserError=2;
		    }		 
		  strcpy(pstr,"*");
		}


	      /* ARGFILEDEF Kommando */
	      if (strcmp(partstr,"ARGFILEDEF") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      if (xwgp.prtfanz < 199)
			{
			  xwgp.prtfanz++;
			  if (xwgp.prtfdata[xwgp.prtfanz] == NULL)
			    {
			      xwgp.prtfdata[xwgp.prtfanz] = (char*) malloc(strlen(partstr)+1);
			      strcpy(xwgp.prtfdata[xwgp.prtfanz],partstr);
			    }
			}
		    }
		  else
		    {
		      parserError=2;
		    }		 
		  strcpy(pstr,"*");
		}

	      /* LANDSCAPE Kommando */
	      if (strcmp(partstr,"LANDSCAPE") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      /* Inhalt setzen */ 
		      if (xwgp.landscape == NULL)
			{
			  xwgp.landscape = (char*) malloc(strlen(partstr)+1);
			}
		      else
			{
			  xwgp.landscape = (char*) realloc(xwgp.landscape,strlen(partstr)+1);
			}
		      strcpy(xwgp.landscape,partstr);
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr) > 0)
			{
			  /* Inhalt setzen */ 
			  if (xwgp.nolandscape == NULL)
			    {
			      xwgp.nolandscape = (char*) malloc(strlen(partstr)+1);
			    }
			  else
			    {
			      xwgp.nolandscape = (char*) realloc(xwgp.nolandscape,strlen(partstr)+1);
			    }
			  strcpy(xwgp.nolandscape,partstr);
			  xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=atoi(partstr);
			  xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]];
			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);
			  if (strlen(pstr)>0)
			    {
			      parserError=6;
			    }
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* GUI Kommando */
	      if (strcmp(partstr,"GUI") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  parserLevel=1;
		  if (int(strlen(partstr)) > 0)
		    {
		      if (xwgp.anzform < 3)
			{
			  xwgp.anzform++;
			  xwgp.formName[xwgp.anzform] = (char*) malloc(strlen(partstr)+1);
			  strcpy(xwgp.formName[xwgp.anzform],partstr);
			  parserLevel=100;
			}
		      else
			{
			  parserError=4;
			}
		    }
		  else
		    {
		      parserError=2;
		    }

		  strcpy(pstr,"*");
		}

	      /* DEF  Kommando */
	      if (strcmp(partstr,"DEF") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      strcpy(astr,partstr);
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr) > 0)
			{
			  strcpy(bstr,partstr);			  
			  addDef(astr,bstr);
			  parserLevel=300;
			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);
			  if (strlen(pstr)>0)
			    {
			      parserError=6;
			    }
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* END Kommando */
	      if (strcmp(partstr,"END") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) == 0)
		    {
		      if (parserLevel == 1)
			{
			  parserLevel=0;
			}
		      else
			{
			  parserError=3;
			}
		    }
		  else
		    {
		      parserError=6;
		    }		 
		  strcpy(pstr,"*");
		}
	    }

/* 
   Komandos Level 100 for GUI

   Syntax  : SIZE buttontext
   Funktion: bestimmt die gr��e eines Voreinstellungsfensterts.

   Syntax  : BORDER x,y,w,h
   Funktion: Rahmen zeichnen

   Syntax  : OBJ buttonname
   Funktion: leitet eine Widget definition ein 

*/
	  if (parserLevel == 100)
	    {

	      /* SIZE Kommando */
	      if (strcmp(partstr,"SIZE") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      xwgp.x[xwgp.anzform]=atoi(partstr);
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr) > 0)
			{
			  xwgp.y[xwgp.anzform]=atoi(partstr);
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* BORDER Kommando */
	      if (strcmp(partstr,"BORDER") == 0)
		{
		  xwgp.anzObj[xwgp.anzform]++;
		  if (xwgp.anzObj[xwgp.anzform]<30)
		    {
		      xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = 256;
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr)>0)
			{
			  xwgp.xpos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = atoi(partstr);
			  strcpy(partstr,strptr);
			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);
			  if (strlen(partstr)>0)
			    {
			      xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = atoi(partstr);
			      strcpy(partstr,strptr);
			      strptr = strDelParm(pstr);
			      strcpy(pstr,strptr);
			      if (strlen(partstr)>0)
				{
				  xwgp.xsize[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = atoi(partstr);
				  strcpy(partstr,strptr);
				  strptr = strDelParm(pstr);
				  strcpy(pstr,strptr);
				  if (strlen(partstr)>0)
				    {
				      xwgp.ysize[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = atoi(partstr);
				      /* Widget Color */
				      xwgp.color[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = -1;
				      xwgp.bcolor[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = -1;
				    }
				  else
				    {
				      parserError=2;
				    }
				}
			      else
				{
				  parserError=2;
				}
			    }
			  else
			    {
			      parserError=2;
			    }
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=10;
		    }
		  strcpy(pstr,"*");
		}

	      /* Obj Kommando */
	      if (strcmp(partstr,"OBJ") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      xwgp.anzObj[xwgp.anzform]++;
		      if (xwgp.anzObj[xwgp.anzform]<30)
			{
			  if (xwgp.objName[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] == NULL)
			    {
			      xwgp.objName[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = (char*) malloc(strlen(partstr)+1);
			    }
			  else
			    {
			      xwgp.objName[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = (char*) realloc(xwgp.objName[xwgp.anzform][xwgp.anzObj[xwgp.anzform]],strlen(partstr)+1);
			    }
			  strcpy(xwgp.objName[xwgp.anzform][xwgp.anzObj[xwgp.anzform]],partstr);
			  /* Widget Color */
			  xwgp.color[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = -1;
			  xwgp.bcolor[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = -1;
			  /* Modus */
			  xwgp.mode[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = 0;
			}
		      else
			{
			  parserError=10;
			}
		      parserLevel=200;
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* END Kommando */
	      if (strcmp(partstr,"END") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) == 0)
		    {
		      if (parserLevel == 100)
			{
			  parserLevel=1;
			}
		      else
			{
			  parserError=5;
			}
		    }
		  else
		    {
		      parserError=6;
		    }		 
		  strcpy(pstr,"*");
		}
	    }

/* 
   Komandos Level 200 for Widgets
*/
	  if (parserLevel == 200)
	    {

	      /* TYPE  Kommando */
	      if (strcmp(partstr,"TYPE") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=-1;	
		      strNewUpper(partstr);
		      if (strcmp(partstr,"CHOICE") == 0)
			{
			  xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=0;			  
			}
		      if (strcmp(partstr,"BOOLEAN") == 0)
			{
			  xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=1;			  
			}
		      if (strcmp(partstr,"BROWSER") == 0)
			{
			  xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=2;			  
			}
		      if (strcmp(partstr,"IBROWSER") == 0)
			{
			  xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=3;			  
			}
		      if (strcmp(partstr,"SCROLLER") == 0)
			{
			  xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=4;			  
			}
		      if (strcmp(partstr,"INPUT") == 0)
			{
			  xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=5;			  
			}
		      if (strcmp(partstr,"TEXT") == 0)
			{
			  xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=6;			  
			}
		      if (strcmp(partstr,"EXEC") == 0)
			{
			  xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=7;			  
			}
		      if (xwgp.widget[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] == -1)
			{
			  parserError=7;
			}
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(pstr)>0)
			{
			  parserError=6;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* FORMAT  Kommando */
	      if (strcmp(partstr,"FORMAT") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      xwgp.type[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=-1;	
		      strNewUpper(partstr);
		      if (strcmp(partstr,"INT") == 0)
			{
			  xwgp.type[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=0;			  
			}
		      if (strcmp(partstr,"FLOAT") == 0)
			{
			  xwgp.type[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=1;			  
			}
		      if (strcmp(partstr,"TEXT") == 0)
			{
			  xwgp.type[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=2;			  
			}
		      if (xwgp.type[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] == -1)
			{
			  parserError=8;
			}
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(pstr)>0)
			{
			  parserError=6;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* MODE Kommando */
	      if (strcmp(partstr,"OPTION") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      strNewUpper(partstr);
		      if (strcmp(partstr,"COUNTER") == 0)
			{
			  xwgp.mode[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = 1;
			}
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(pstr)>0)
			{
			  parserError=6;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* GEOMETRY Kommando */
	      if (strcmp(partstr,"GEOMETRY") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      xwgp.xpos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = atoi(partstr);
		      xwgp.xpos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]= xwgp.xpos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]];
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr)>0)
			{
			  xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = atoi(partstr);
			  xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]];
			  strcpy(partstr,strptr);
			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);
			  if (strlen(partstr)>0)
			    {
			      xwgp.xsize[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = atoi(partstr);
			      strcpy(partstr,strptr);
			      strptr = strDelParm(pstr);
			      strcpy(pstr,strptr);
			      if (strlen(partstr)>0)
				{
				  xwgp.ysize[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = atoi(partstr);
				}
			      else
				{
				  parserError=2;
				}
			    }
			  else
			    {
			      parserError=2;
			    }
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}
	 
	  /* POS  Kommando */
	      if (strcmp(partstr,"POS") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      xwgp.xpos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=atoi(partstr);
		      xwgp.xpos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=xwgp.xpos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]];
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr) > 0)
			{
			  xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=atoi(partstr);
			  xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=xwgp.ypos[xwgp.anzform][xwgp.anzObj[xwgp.anzform]];
			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);
			  if (strlen(pstr)>0)
			    {
			      parserError=6;
			    }
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* SIZE  Kommando */
	      if (strcmp(partstr,"SIZE") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      xwgp.xsize[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=atoi(partstr);
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr) > 0)
			{
			  xwgp.ysize[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=atoi(partstr);
			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);
			  if (strlen(pstr)>0)
			    {
			      parserError=6;
			    }
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}   

	      /* COLOR Kommando */
	      if (strcmp(partstr,"COLOR") == 0)
		{
		  a=0;
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      strNewUpper(partstr);
		      a=getColor(partstr);
		      xwgp.color[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = a;
		       
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr) > 0)
			{
			  strNewUpper(partstr);
			  a=getColor(partstr);
			  xwgp.bcolor[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = a;

			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);
			  if (strlen(pstr)>0)
			    {
			      parserError=6;
			    }
			}
		      else
			{
			 parserError=2; 
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}


	      /* ENTRYS Kommando */
	      if (strcmp(partstr,"ENTRYS") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      if (xwgp.formData[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] == NULL)
			{
			  xwgp.formData[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = (char*) malloc(strlen(pstr)+1);
			}
		      else
			{
			  xwgp.formData[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = 
                           (char*) realloc( xwgp.formData[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] ,strlen(pstr)+1);
			}
		      strcpy(xwgp.formData[xwgp.anzform][xwgp.anzObj[xwgp.anzform]],pstr);
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* RESULT Kommando */
	      if (strcmp(partstr,"RESULT") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      if (xwgp.formResult[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] == NULL)
			{
			  xwgp.formResult[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = (char*) malloc(strlen(pstr)+1);
			}
		      else
			{
			  xwgp.formResult[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = 
                           (char*) realloc( xwgp.formResult[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] ,strlen(pstr)+1);
			}
		      strcpy(xwgp.formResult[xwgp.anzform][xwgp.anzObj[xwgp.anzform]],pstr);
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* DEFAULT Kommando */
	      if (strcmp(partstr,"DEFAULT") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      if (xwgp.formDef[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] == NULL)
			{
			  xwgp.formDef[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = (char*) malloc(strlen(pstr)+1);
			}
		      else
			{
			  xwgp.formDef[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = 
                           (char*) realloc(xwgp.formDef[xwgp.anzform][xwgp.anzObj[xwgp.anzform]],strlen(pstr)+1);
			}
		      strcpy(xwgp.formDef[xwgp.anzform][xwgp.anzObj[xwgp.anzform]],pstr);
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* VARNAME Kommando */
	      if (strcmp(partstr,"VARNAME") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      if (xwgp.formVar[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] == NULL)
			{
			  xwgp.formVar[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = (char*) malloc(strlen(pstr)+1);
			}
		      else
			{
			  xwgp.formVar[xwgp.anzform][xwgp.anzObj[xwgp.anzform]] = 
                           (char*) realloc(xwgp.formVar[xwgp.anzform][xwgp.anzObj[xwgp.anzform]],strlen(pstr)+1);
			}
		      strNewUpper(pstr);
		      strcpy(xwgp.formVar[xwgp.anzform][xwgp.anzObj[xwgp.anzform]],pstr);
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* MIN Kommando */
	      if (strcmp(partstr,"MIN") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      xwgp.min[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=atof(partstr);
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr) > 0)
			{
			  parserError=6;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* MAX Kommando */
	      if (strcmp(partstr,"MAX") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      xwgp.max[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=atof(partstr);
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr) > 0)
			{
			  parserError=6;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* STEP Kommando */
	      if (strcmp(partstr,"STEP") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr) > 0)
		    {
		      xwgp.step[xwgp.anzform][xwgp.anzObj[xwgp.anzform]]=atof(partstr);
		      strptr = strGetParm(pstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr) > 0)
			{
			  parserError=6;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* END Kommando */
	      if (strcmp(partstr,"END") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) == 0)
		    {
		      if (parserLevel == 200)
			{
			  parserLevel=100;
			}
		      else
			{
			  parserError=5;
			}
		    }
		  else
		    {
		      parserError=6;
		    }		 
		  strcpy(pstr,"*");
		}
	    }

/* 
   Komandos Level 300 for Widgets
*/
	  if (parserLevel == 300)
	    {
	      /* END Kommando */
	      if (strcmp(partstr,"END") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) == 0)
		    {
		      if (parserLevel == 300)
			{
			  parserLevel=1;
			}
		      else
			{
			  parserError=5;
			}
		    }
		  else
		    {
		      parserError=6;
		    }		 
		  strcpy(pstr,"*");
		  strcpy(partstr,"");
		}

	      /* Variablendefinition */
	      if ( (strcmp(partstr,"") != 0) && (strcmp(pstr,"*") != 0) )
		{
		  /*
		  cout << "setVar(" << xwgp.prtQuality[xwgp.actSet] << "," << xwgp.prtPaper[xwgp.actSet] << "," << partstr << ",�" << pstr << "�);\n";
		  */

		  /* @ - Parameter ignorieren */
		  if (strcmp(pstr,"@") == 0)
		    {
		      strcpy(pstr,"");
		    }

		  setVar(xwgp.prtQuality[xwgp.actSet],xwgp.prtPaper[xwgp.actSet],partstr,pstr);
		 		  
		  strcpy(pstr,"*");
		}

	    }

/* 
   Komandos Level 1000 for MainPref-File
*/
	  if (parserLevel == 1000)
	    {
	      /* END Kommando */
	      if (strcmp(partstr,"END") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) == 0)
		    {
		      if (parserLevel == 1000)
			{
			  parserLevel=0;
			}
		      else
			{
			  parserError=5;
			}
		    }
		  else
		    {
		      parserError=6;
		    }		 
		  strcpy(pstr,"*");
		  strcpy(partstr,"");
		}

	      /* WINDOW Kommando */
	      if (strcmp(partstr,"WINDOW") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      mf.xpos=atoi(partstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr)>0)
			{
			  mf.ypos=atoi(partstr);
			  strcpy(partstr,strptr);
			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);

			  if (strlen(partstr)>0)
			    {
			      mf.width=atoi(partstr);
			      strcpy(partstr,strptr);
			      strptr = strDelParm(pstr);
			      strcpy(pstr,strptr);
			      if (strlen(partstr)>0)
				{
				  mf.height=atoi(partstr);
				  strcpy(partstr,strptr);
				  strptr = strDelParm(pstr);
				  strcpy(pstr,strptr);
				 				  
				  if (int(strlen(pstr))>0)
				    {
				      parserError=6;
				    }
				}
			      else
				{
				  parserError=2;
				}
			    }
			  else
			    {
			      parserError=2;
			    }
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* BORDER Kommando */
	      if (strcmp(partstr,"BORDER") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      pdata.pagel = atoi(partstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr)>0)
			{
			  pdata.pager = atoi(partstr);
			  strcpy(partstr,strptr);
			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);
			  if (strlen(partstr)>0)
			    {
			      pdata.paget = atoi(partstr);
			      strcpy(partstr,strptr);
			      strptr = strDelParm(pstr);
			      strcpy(pstr,strptr);
			      if (strlen(partstr)>0)
				{
				  pdata.pageb = atoi(partstr);
				}
			      else
				{
				  parserError=2;
				}
			    }
			  else
			    {
			      parserError=2;
			    }
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* QUALITY Kommando */
	      if (strcmp(partstr,"QUALITY") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      xwgp.actQuality = atoi(partstr);
		      strcpy(partstr,strptr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (strlen(partstr)>0)
			{
			  xwgp.actPaper = atoi(partstr);
			  strcpy(partstr,strptr);
			  strptr = strDelParm(pstr);
			  strcpy(pstr,strptr);
			  if (int(strlen(pstr))>0)
			    {
			      parserError=6;
			    }
			}
		      else
			{
			  parserError=2;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* VIEWER Kommando */
	      if (strcmp(partstr,"VIEWER") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      strcpy(xwgp.viewer,partstr);
		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (int(strlen(pstr))>0)
			{
			  parserError=6;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* PRTABORT Kommando */
	      if (strcmp(partstr,"PRTABORT") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  if (strlen(partstr) != 0)
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	      /* PRTMODE Kommando */
	      if (strcmp(partstr,"PRTMODE") == 0)
		{
		  strptr = strGetParm(pstr);
		  strcpy(partstr,strptr);
		  strptr = strDelParm(pstr);
		  strcpy(pstr,strptr);
		  if (strlen(partstr)>0)
		    {
		      if (strcmp(partstr,"DIRECT") == 0)
			{
			  xwgp.prtselect = 1;
			}
		      if (strcmp(partstr,"SPOOL") == 0)
			{
			  xwgp.prtselect = 2;
			}

		      strptr = strDelParm(pstr);
		      strcpy(pstr,strptr);
		      if (int(strlen(pstr))>0)
			{
			  parserError=6;
			}
		    }
		  else
		    {
		      parserError=2;
		    }
		  strcpy(pstr,"*");
		}

	    }

/* 
   Normale weiterverarbeitung 
*/	

	  /* Falsches Kommando */
	  if ( (strcmp(pstr,"*") != 0) && (parserError<9000) )
	    {
	      cout << pstr << "\n";
	      parserError=3;
	    }

	} while ( parserError==0 );

      fclose(pfh);

      if (parserError>0)
	{
	  strcpy(astr,"");
	  strcpy(bstr,"");
	  strcpy(cstr,"");
	  if (parserError == 1)
	    {
	      strcpy(astr,GR("argument1A_PB.str","Syntax Fehler in Zeile"));
	      strcat(astr," ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,GR("argument2A_PB.str","Parameter zu lang !!!"));
	    }
	  if (parserError == 2)
	    {
	      strcpy(astr,GR("argument1B_PB.str","Syntax Fehler in Zeile"));
	      strcat(astr," ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,GR("argument2B_PB.str","Parameter fehlt !!!"));
	    }
	  if (parserError == 3)
	    {
	      strcpy(astr,GR("command1_PB.str","Kommando Fehler in Zeile"));
	      strcat(astr," ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,GR("command2_PB.str","Unbekannter Befehl f�r diesen Parser Level !!!"));
	      strcpy(cstr,GR("command3_PB.str","Parser Level:"));
	      strcat(cstr," ");
	      strptr = IntStr(parserLevel);
	      strcat(cstr,strptr);
	    }
	  if (parserError == 4)
	    {
	      strcpy(astr,"GUI Error in Line ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,"To many Pref-GUIs !!!");
	    }
	  if (parserError == 5)
	    {
	      strcpy(astr,"Parsing Error in Line ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,"Bad Parsing Level !!!");
	      strcpy(cstr,"Parsing Level: ");
	      strptr = IntStr(parserLevel);
	      strcat(cstr,strptr);
	    }

	  if (parserError == 6)
	    {
	      strcpy(astr,"Syntax Error in Line ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,"To many Argument !!!");
	    }
	  if (parserError == 7)
	    {
	      strcpy(astr,"Widget Error in Line ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,"Unknown Widget Type !!!");
	      strcpy(cstr,"(");
	      strcat(cstr,partstr);
	      strcat(cstr,")");
	    }
	  if (parserError == 8)
	    {
	      strcpy(astr,"Format Error in Line ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,"Unknown Format Type !!!");
	      strcpy(cstr,"(");
	      strcat(cstr,partstr);
	      strcat(cstr,")");
	    }
	  if (parserError == 9)
	    {
	      strcpy(astr,"Structur Error in Line ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,"Bad Command on bad Place !!!");
	    }
	  if (parserError == 10)
	    {
	      strcpy(astr,"Object Error in Line ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,"To many Objects define !!!");
	    }
	  if (parserError == 11)
	    {
	      strcpy(astr,"Object Error in Line ");
	      strptr = IntStr(parserLine);
	      strcat(astr,strptr);
	      strcpy(bstr,"Unknown Color defined !!!");
	    }

	  if (parserError < 9000)
	    {
	      /*
	      cout << astr << "\n";
	      cout << bstr << "\n";
	      cout << cstr << "\n";
	      */
	      if (int(strlen(cstr))>0)
		{
		  strcat(cstr,"| ");
		}
	      strcat(cstr,source);
	      fl_show_alert(astr,bstr,cstr,1);
	      parserError=1234;
	    }

	}

    }
  else
    {
      if (act == 2)
	{
	  strcpy(astr,"Datei konnte nicht ge�ffnet werden !!!");
	  strcpy(bstr,"<");
	  strcat(bstr,source);
	  strcat(bstr,">");
	  strcpy(cstr,"");
	  fl_show_alert(astr,bstr,cstr,1);
	  parserError=1234;
	}
    }

  /* ERROR -> Halt */
  if (parserError == 1234)
    {
      allfree(0);
      exit(0);
    }

  parserLine=12345678;

  return;
}

