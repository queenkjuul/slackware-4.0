#!/bin/sh
# add indexing clause and copyright notice to given files.

for args
	do
		echo Changing "$args"
		cat $HPMODESET/extra/indexing "$args" $HPMODESET/extra/license > "$args".new
		co -l "$args"
		mv "$args".new "$args"
		ci -u -m"added indexing and license text" "$args"
	done
