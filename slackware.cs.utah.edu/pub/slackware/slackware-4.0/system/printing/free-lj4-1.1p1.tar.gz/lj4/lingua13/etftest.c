/* --------------------------------------------*\
| etftest.c (version 1.3)  (C) SichemSoft 1994  |
| Roghorst 160, 6708 KS Wageningen, Netherlands |
| check for language independent applications   |
| author: Anneke Sicherer-Roetman, date: 940311 |
\* --------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include "ui_text.h"

extern unsigned _ui_memcount,_ui_filcount;

int main(int argc,char *argv[])
{
   char filename[81],version[81]; unsigned i;

   if (argc>3) return 1;
   if (argc==3) strcpy(version,argv[2]); else version[0]='\0';
   if (argc>=2) strcpy(filename,argv[1]); else strcpy(filename,"english");

   if (ui_loadtext(filename,version)) {
      printf("--- %u memory items\n",_ui_memcount);
      for (i=0; i<_ui_memcount; i++) printf("%3u %s\n",i,ui_text[i]);
      printf("--- %u file items\n",_ui_filcount);
   for (i=0; i<_ui_filcount; i++) printf("%3u %s\n",i,ui_filetext(i));
      ui_unloadtext();
   } else puts("Fatal error");
   return 0;
}
