/* --------------------------------------------*\
| lingua.h (version 1.3) -- (C) SichemSoft 1994 |
| Roghorst 160, 6708 KS Wageningen, Netherlands |
| include for language independent applications |
| author: Anneke Sicherer-Roetman, date: 940311 |
\* --------------------------------------------*/

/*
** inserted open mode readRO to avoid permission
** conflicts for a running program that only loads
** an .etf file
** Frank Tegtmeyer (fte@gecko.de)
*/

#ifndef LINGUAH
#define LINGUAH

#define UIT_ENCRYPT    53
#define TRUE           1
#define FALSE          0

#ifdef __MSDOS__
#define readRA  "rb+"
#define readRO  "rb"
#define writeRA "wb+"
#define lf      "\r\n"
#define lfchk   ('\r'+'\n')
#else /* UNIX */
#define readRA  "r+"
#define readRO  "r"
#define writeRA "w+"
#define lf      "\n"
#define lfchk   ('\n')
#endif

#endif
