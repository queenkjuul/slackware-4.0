#!/bin/sh

gs_version=`gs --version`
rm -f /etc/gamma*.ps
rm -f /etc/powergamma.ps
rm -f /usr/share/ghostscript/$gs_version/cdj_error*.upp
rm -f /usr/share/ghostscript/$gs_version/cdj_floyd*.upp
rm -f /usr/share/ghostscript/$gs_version/power/cdj_error*.upp
rm -f /usr/share/ghostscript/$gs_version/power/cdj_floyd*.upp
rm -f /usr/share/ghostscript/$gs_version/powercolor.upp
 
cp -f gamma* /etc
cp -f powercolor.8 /usr/bin/powercolor
chmod 700 /usr/bin/powercolor
