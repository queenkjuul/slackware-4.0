/* 
 * Copyright 1994 Chris Smith
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appears in all copies and that
 * both that copyright notice and this permission notice appears in
 * supporting documentation.  I make no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 */

#define when break; case
#define otherwise break; default
typedef unsigned char uchar;

extern void do_init (const char *font, int cpi, int code_page, int draft,
		     float lpi, float page_length);
extern void do_fin (void);
extern void fin_string (const char **string, int *len);
extern void do_hskip (int pos);
extern void init_font (int lflag, int x2flag, int x4flag, int code_page);
extern void send_quoted (uchar c);
extern void bold_on (void);
extern void bold_off (void);
extern void underline_on (void);
extern void underline_off (void);
extern uchar replace_overstrike (uchar a, uchar b);
extern int check_font_name (const char *name);
extern void send_pair (uchar c1, uchar c2);
extern void send_linebuf (int hskip);

extern uchar *myfont;

#define MAXCOL 179
