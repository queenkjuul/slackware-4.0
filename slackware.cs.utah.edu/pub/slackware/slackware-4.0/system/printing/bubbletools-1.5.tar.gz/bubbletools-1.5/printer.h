extern void init_printer(int printer, int color);
extern void prt_draw(int color, int x, int len);
extern void prt_next(void);
extern void prt_feedup(void);

extern int scale_x, scale_y;
extern int offs_x, offs_y;
extern int lowres;

/* Needed for the color driver */
#define CYAN	0
#define MAGENTA	1
#define YELLOW	2
#define BLACK	3


/* Who we are */
#define PRT_BJ	0
#define PRT_LQ	1
