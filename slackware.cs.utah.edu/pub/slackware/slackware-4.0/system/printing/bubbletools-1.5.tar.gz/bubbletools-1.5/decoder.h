extern void g3_decode(char *fname, int printer);
extern void pnm_decode(char *fname, int printer);
