#include <qlayout.h>
#include <qbttngrp.h>
#include <qcombo.h>
#include <qframe.h>
#include <qgrpbox.h>
#include <qradiobt.h>
#include <qchkbox.h> 
#include <qlabel.h>
#include <qpixmap.h>
#include <qstrlist.h>

class PaperDialog : public QWidget { 
Q_OBJECT

public:
    PaperDialog( QWidget *parent=0, const char *name=0 );
    void setOrientation( QString orient );
    void setPaperSize( QString size );
    void setPaperType( QString size );
    void setFeed( QString size );
    QString getOrientation();
    QString getPaperSize();
    QString getPaperType();
    QString getFeed();
private:
    QStrList *orientation;
    QStrList *paper_size;
    QStrList *paper_type;
    QButtonGroup *orient_bg; 
    QRadioButton *orient_port;
    QRadioButton *orient_land;
    QComboBox *paperType;
    QComboBox *paperSize;
    QCheckBox *feedBox;
};


