#ifndef __DJET_MAIN__
#define __DJET_MAIN__


#include <qtabdlg.h>
#include <qtstream.h>
#include <qfile.h>
#include "QualityDialog.h"
#include "PaperDialog.h"
#include "TuningDialog.h"
#include "OtherDialog.h"
#include "AboutDialog.h"

class DeskjetTool : public QTabDialog
{
    Q_OBJECT

public:
    DeskjetTool( QWidget *parent=0, const char *name=0 );
    void readConfig();
private slots: 
    void writeConfig();
    void setDefaultConfig();
private:
   QualityDialog *qdlg;
   PaperDialog *pdlg;
   TuningDialog *tdlg;
   OtherDialog *odlg;
   AboutDialog *adlg;
};


#endif
