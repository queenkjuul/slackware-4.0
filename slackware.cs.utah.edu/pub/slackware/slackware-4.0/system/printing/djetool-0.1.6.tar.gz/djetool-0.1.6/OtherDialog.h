#include <qlayout.h>
#include <qcombo.h>
#include <qframe.h>
#include <qlabel.h>
#include <qslider.h>
#include <qlcdnum.h>
#include <qlined.h>
#include <qstrlist.h>
#include <qgrpbox.h>

class OtherDialog : public QWidget { 
Q_OBJECT

public:
    OtherDialog( QWidget *parent=0, const char *name=0 );
    void setModel( QString model );
    void setMarginFile( QString mfile );
    QString getModel();
    QString getMarginFile();    
private:
    QStrList  *printer_model;
    QComboBox *printerModel;
    QLineEdit *marginFile;
};


