/****************************************************************
** Copyright (C) 1998 Peter Cebokli
**
** This file is distributed under the GNU general public license
** version 2.
** See the file COPYING included in the distribution for the usage
** and distribution terms.
**
** This software comes with no warranty at all except that if it
** breaks, or if it breaks something else, you get to keep all
** the pieces.
**
****************************************************************/

#include "AboutDialog.h"
#include <qframe.h>
#include <qlabel.h>

AboutDialog::AboutDialog( QWidget *parent, const char *name )
    : QWidget( parent, name )
{ 
    QFrame* frame;
    frame = new QFrame( this, "frame" );
    frame->move( 10, 10 );
    frame->resize(parent->width()-36,200);
    frame->setFrameStyle( 49 );
    frame->setBackgroundColor(QColor(233,233,233));

    QLabel *about=new QLabel(frame,0);
    about->move(50,50);
    about->setAutoResize(TRUE);     
    QFont f("charter", 16, QFont::Bold);    
    about->setFont( f );
    about->setText(" Deskjet tool ver. 0.1.6 \n Author Peter Cebokli \n GNU Copyright"); 
    about->setBackgroundColor(QColor(233,233,233));  
}
