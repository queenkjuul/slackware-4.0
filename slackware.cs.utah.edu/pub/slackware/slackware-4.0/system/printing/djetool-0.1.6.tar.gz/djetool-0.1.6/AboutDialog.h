#include <qwidget.h>

class AboutDialog : public QWidget { 
Q_OBJECT

public:
    AboutDialog( QWidget *parent=0, const char *name=0 );
};


