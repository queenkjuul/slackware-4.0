/****************************************************************
**
** configuration and initialization
**
** Copyright (C) 1998 Peter �ebokli
**
** This file is distributed under the GNU general public license
** version 2.
** See the file COPYING included in the distribution for the usage
** and distribution terms.
**
** This software comes with no warranty at all except that if it
** breaks, or if it breaks something else, you get to keep all
** the pieces.
**
****************************************************************/
#ifndef __config_h
#define __config_h

// installation directory
#define HPTOOLDIR	"/usr/local/djetool"

//don't change this
#define CNF_FILE	(HPTOOLDIR"/hpdj.cnf")
#define DRAFT_BMP	(HPTOOLDIR"/draft.bmp")
#define NORMAL_BMP	(HPTOOLDIR"/normal.bmp")
#define BEST_BMP	(HPTOOLDIR"/best.bmp")
#define PORTRAIT_BMP	(HPTOOLDIR"/Portrait.bmp")
#define LANDSCAPE_BMP	(HPTOOLDIR"/Landscape.bmp")

#endif // __config_h
