/******************************************************************
  Program: PriMa
  File:    tt.c
  Author:  J�rg R�dler
******************************************************************/

#include "main.h"

extern FD_mainwin *fd_mainwin;
extern FD_optwin *fd_optwin;

void tt_maketips()
{
  tooltips_addtip(fd_mainwin->printer, TT_PRINTER);
  tooltips_addtip(fd_mainwin->paper, TT_PAPER);
  tooltips_addtip(fd_mainwin->one_up, TT_ONE_UP);
  tooltips_addtip(fd_mainwin->two_up, TT_TWO_UP);
  tooltips_addtip(fd_mainwin->four_up, TT_FOUR_UP);
  tooltips_addtip(fd_mainwin->reverse_order, TT_REVERSE_ORDER);
  tooltips_addtip(fd_mainwin->book_order, TT_BOOK_ORDER);
  tooltips_addtip(fd_mainwin->signature, TT_SIGNATURE);
  tooltips_addtip(fd_mainwin->all_pages, TT_ALL_PAGES);
  tooltips_addtip(fd_mainwin->even_pages, TT_EVEN_PAGES);
  tooltips_addtip(fd_mainwin->odd_pages, TT_ODD_PAGES);
  tooltips_addtip(fd_mainwin->startpage, TT_STARTPAGE);
  tooltips_addtip(fd_mainwin->endpage, TT_ENDPAGE);
  tooltips_addtip(fd_mainwin->printbutton, TT_PRINTBUTTON);
  tooltips_addtip(fd_mainwin->previewbutton, TT_PREVIEWBUTTON);
  tooltips_addtip(fd_mainwin->quitbutton, TT_QUITBUTTON);
  tooltips_addtip(fd_mainwin->filebutton, TT_FILEBUTTON);
  tooltips_addtip(fd_mainwin->optionsbutton, TT_OPTIONSBUTTON);
  tooltips_addtip(fd_mainwin->infobutton, TT_INFOBUTTON);

  tooltips_addtip(fd_optwin->opt_printer_number, TT_OPT_PRINTER_NUM); 
  tooltips_addtip(fd_optwin->opt_printer_name, TT_OPT_PRINTER_NAME);
  tooltips_addtip(fd_optwin->opt_converter, TT_OPT_CONVERTER);
  tooltips_addtip(fd_optwin->opt_printer, TT_OPT_PRINTER);
  tooltips_addtip(fd_optwin->opt_globalbutton, TT_OPT_GLOBAL_BTN); 
  tooltips_addtip(fd_optwin->opt_quitbutton, TT_OPT_QUIT_BTN);
  tooltips_addtip(fd_optwin->opt_reloadbutton, TT_OPT_RELOAD_BTN);
  tooltips_addtip(fd_optwin->opt_savebutton, TT_OPT_SAVE_BTN);
}
