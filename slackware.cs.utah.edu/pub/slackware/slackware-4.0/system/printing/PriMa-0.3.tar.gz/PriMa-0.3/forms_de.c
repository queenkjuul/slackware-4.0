/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "forms_de.h"

FD_mainwin *create_form_mainwin(void)
{
  FL_OBJECT *obj;
  FD_mainwin *fdui = (FD_mainwin *) fl_calloc(1, sizeof(*fdui));

  fdui->mainwin = fl_bgn_form(FL_NO_BOX, 505, 255);
  fdui->main_frame = obj = fl_add_box(FL_FLAT_BOX,0,0,505,255,"");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
  obj = fl_add_text(FL_NORMAL_TEXT,425,0,75,40,"PriMa");
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_TIMESBOLDITALIC_STYLE+FL_EMBOSSED_STYLE);
  fdui->printbutton = obj = fl_add_button(FL_RETURN_BUTTON,375,40,125,25,"Drucken");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,actbutton_cb,0);
  fdui->previewbutton = obj = fl_add_button(FL_NORMAL_BUTTON,375,70,125,25,"Vorschau");
    fl_set_button_shortcut(obj,"V v",1);
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,actbutton_cb,0);
  fdui->quitbutton = obj = fl_add_button(FL_NORMAL_BUTTON,375,100,125,25,"Beenden");
    fl_set_button_shortcut(obj,"B b",1);
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,actbutton_cb,0);
  fdui->infobutton = obj = fl_add_button(FL_NORMAL_BUTTON,375,195,125,25,"Info");
    fl_set_button_shortcut(obj,"f F",1);
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_RED);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,actbutton_cb,0);
  fdui->filebutton = obj = fl_add_button(FL_NORMAL_BUTTON,375,135,125,25,"Datei wechseln");
    fl_set_button_shortcut(obj,"w W",1);
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_RED);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,actbutton_cb,0);
  fdui->optionsbutton = obj = fl_add_button(FL_NORMAL_BUTTON,375,165,125,25,"Optionen");
    fl_set_button_shortcut(obj,"t T",1);
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_RED);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,actbutton_cb,0);
  fdui->statusline = obj = fl_add_text(FL_NORMAL_TEXT,5,225,495,25,"PriMa V0.3 - Autor: J�rg R�dler");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,5,150,180,70,"");
    fl_set_object_color(obj,FL_COL1,FL_COL1);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,190,100,180,120,"");
    fl_set_object_color(obj,FL_COL1,FL_COL1);
  fdui->startpage = obj = fl_add_input(FL_INT_INPUT,235,185,40,25,"Von:");
    fl_set_input_shortcut(obj,"o O",1);
    fl_set_object_color(obj,FL_MCOL,FL_WHITE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->endpage = obj = fl_add_input(FL_INT_INPUT,310,185,40,25,"bis:");
    fl_set_input_shortcut(obj,"i I",1);
    fl_set_object_color(obj,FL_MCOL,FL_WHITE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,5,5,200,90,"");
    fl_set_object_color(obj,FL_COL1,FL_COL1);
  fdui->printer = obj = fl_add_choice(FL_DROPLIST_CHOICE,80,20,115,25,"Drucker:");
    fl_set_object_shortcut(obj,"D d",1);
    fl_set_object_boxtype(obj,FL_DOWN_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_BLACK);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->paper = obj = fl_add_choice(FL_DROPLIST_CHOICE,80,55,115,25,"Papier:");
    fl_set_object_shortcut(obj,"P p",1);
    fl_set_object_boxtype(obj,FL_DOWN_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_BLACK);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,210,5,160,90,"");
    fl_set_object_color(obj,FL_COL1,FL_COL1);

  fdui->nup_group = fl_bgn_group();
  fdui->four_up = obj = fl_add_checkbutton(FL_RADIO_BUTTON,215,60,150,25,"Vier Seiten pro Blatt");
    fl_set_button_shortcut(obj,"l L",1);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_callback(obj,nup_cb,4);
  fdui->one_up = obj = fl_add_checkbutton(FL_RADIO_BUTTON,215,10,150,25,"Eine Seite pro Blatt ");
    fl_set_button_shortcut(obj,"E e",1);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_callback(obj,nup_cb,1);
  fdui->two_up = obj = fl_add_checkbutton(FL_RADIO_BUTTON,215,35,150,25,"Zwei Seiten pro Blatt");
    fl_set_button_shortcut(obj,"Z z",1);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_callback(obj,nup_cb,2);
  fl_end_group();


  fdui->pages_group = fl_bgn_group();
  fdui->all_pages = obj = fl_add_checkbutton(FL_RADIO_BUTTON,195,105,165,25,"Alle Seiten");
    fl_set_button_shortcut(obj,"A a",1);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_callback(obj,pages_cb,1);
  fdui->odd_pages = obj = fl_add_checkbutton(FL_RADIO_BUTTON,195,155,165,25,"Ungerade Seitenzahlen");
    fl_set_button_shortcut(obj,"U u",1);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_callback(obj,pages_cb,3);
  fdui->even_pages = obj = fl_add_checkbutton(FL_RADIO_BUTTON,195,130,165,25,"Gerade Seitenzahlen");
    fl_set_button_shortcut(obj,"G g",1);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_callback(obj,pages_cb,2);
  fl_end_group();

  fdui->pixmap = obj = fl_add_pixmap(FL_NORMAL_PIXMAP,370,0,60,40,"");
  fdui->signature = obj = fl_add_input(FL_INT_INPUT,110,185,30,25,"Signatur: ");
    fl_set_input_shortcut(obj,"S s",1);
    fl_set_object_color(obj,FL_MCOL,FL_WHITE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,5,100,180,45,"");
    fl_set_object_color(obj,FL_COL1,FL_COL1);
  fdui->reverse_order = obj = fl_add_checkbutton(FL_PUSH_BUTTON,15,110,160,25,"Reverse Reihenfolge");
    fl_set_button_shortcut(obj,"R r",1);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->book_order = obj = fl_add_checkbutton(FL_PUSH_BUTTON,15,160,160,25,"Buchdruck");
    fl_set_button_shortcut(obj,"c C",1);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_callback(obj,book_cb,0);
  fl_end_form();

  fdui->mainwin->fdui = fdui;

  return fdui;
}
/*---------------------------------------*/

FD_optwin *create_form_optwin(void)
{
  FL_OBJECT *obj;
  FD_optwin *fdui = (FD_optwin *) fl_calloc(1, sizeof(*fdui));

  fdui->optwin = fl_bgn_form(FL_NO_BOX, 495, 130);
  obj = fl_add_box(FL_FLAT_BOX,0,0,495,130,"");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
  fdui->pixmap = obj = fl_add_pixmap(FL_NORMAL_PIXMAP,355,0,60,40,"");
  obj = fl_add_text(FL_NORMAL_TEXT,415,0,75,40,"PriMa");
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_TIMESBOLDITALIC_STYLE+FL_EMBOSSED_STYLE);
  fdui->opt_savebutton = obj = fl_add_button(FL_NORMAL_BUTTON,365,100,125,25,"Sichern");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,opt_actbutton_cb,0);
  fdui->opt_reloadbutton = obj = fl_add_button(FL_NORMAL_BUTTON,365,70,125,25,"Neu Laden");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,opt_actbutton_cb,0);
  fdui->opt_quitbutton = obj = fl_add_button(FL_RETURN_BUTTON,365,40,125,25,"Ok");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,opt_actbutton_cb,0);
  fdui->opt_printer_number = obj = fl_add_counter(FL_SIMPLE_COUNTER,80,5,85,25,"Drucker:");
    fl_set_object_color(obj,FL_MCOL,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
    fl_set_object_callback(obj,opt_printer_number_cb,0);
  fdui->opt_printer_name = obj = fl_add_input(FL_NORMAL_INPUT,80,40,270,25,"Name:");
    fl_set_object_color(obj,FL_MCOL,FL_WHITE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->opt_converter = obj = fl_add_input(FL_NORMAL_INPUT,80,70,270,25,"Magicfilter:");
    fl_set_object_color(obj,FL_MCOL,FL_WHITE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->opt_printer = obj = fl_add_input(FL_NORMAL_INPUT,80,100,270,25,"Druckbefehl:");
    fl_set_object_color(obj,FL_MCOL,FL_WHITE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->opt_globalbutton = obj = fl_add_checkbutton(FL_PUSH_BUTTON,225,5,125,25,"Globale Konfiguration");
  fl_end_form();

  fdui->optwin->fdui = fdui;

  return fdui;
}
/*---------------------------------------*/

