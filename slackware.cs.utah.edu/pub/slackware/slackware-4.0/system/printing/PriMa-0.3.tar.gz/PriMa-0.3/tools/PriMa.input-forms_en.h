#ifndef FD_mainwin_h_
#define FD_mainwin_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void button_cb(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *mainwin;
	void *vdata;
	long ldata;
	FL_OBJECT *pixmap;
	FL_OBJECT *clear_button;
	FL_OBJECT *input;
	FL_OBJECT *ok_button;
	FL_OBJECT *restore_button;
	FL_OBJECT *cancel_button;
} FD_mainwin;

extern FD_mainwin * create_form_mainwin(void);

#endif /* FD_mainwin_h_ */
