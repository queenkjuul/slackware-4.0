/******************************************************************
  Program: PriMa
  File:    tt.h
  Author:  J�rg R�dler
******************************************************************/

/* ENGLISH */

#ifdef LANG_EN
#define TT_PRINTER "Change the logical printer.\n This will change the convert and print commands."
#define TT_PAPER "Change paper size (psresize)"
#define TT_ONE_UP "One up printing (psnup)"
#define TT_TWO_UP "Two up printing (psnup)"
#define TT_FOUR_UP "Four up printing (psnup)"
#define TT_REVERSE_ORDER "Prints last page first (psselect)"
#define TT_BOOK_ORDER "Rearrange pages for book printing (psbook)"
#define TT_SIGNATURE "Signature for book printing,\n must be a multiple of four 4 (psbook)"
#define TT_ALL_PAGES "Prints all pages\n in the given range (psselect)"
#define TT_EVEN_PAGES "Prints all even pages\n in the given range (psselect)"
#define TT_ODD_PAGES "Prints all odd pages\n in the given range (psselect)"
#define TT_STARTPAGE "First page in range (psselect)\n Beware: Pagenumbers may differ\n from the internal numbers in document!"
#define TT_ENDPAGE "Last page in range (psselect)\n Beware: Pagenumbers may differ\n from the internal numbers in document!"
#define TT_PRINTBUTTON "Press button to convert, transform\n and print document!"
#define TT_PREVIEWBUTTON "Press button to convert, transform\n and preview document!"
#define TT_QUITBUTTON "Press button to leave PriMa!"
#define TT_FILEBUTTON "Press button to select\n a new document!"
#define TT_OPTIONSBUTTON "Press button to set\n and save default options"
#define TT_INFOBUTTON "Press button to get information\n on authors, copyright and version of PriMa!"
#define TT_OPT_PRINTER_NUM "Choose a logical printer"
#define TT_OPT_PRINTER_NAME "Printer name, will be\n used as the menu item"
#define TT_OPT_CONVERTER "Command for converting to postscript,\n %INFILE and %PSFILE will be replaced\n by the real filenames"
#define TT_OPT_PRINTER "Command for printing\n %PSFILE will be replaced\n by the real filename"
#define TT_OPT_GLOBAL_BTN "Activate to load and save\n global configuration instead\n of user-specific" 
#define TT_OPT_QUIT_BTN "Press button to accept\n changes and close window"
#define TT_OPT_RELOAD_BTN "Press button to\n reload configuration"
#define TT_OPT_SAVE_BTN "Press button to\n save configuration"
#endif


/* GERMAN */
#ifdef LANG_DE
#define TT_PRINTER "Auswahl eines logischen Druckers.\n Legt die Kommandos zum Konvertieren\n und Drucken fest."
#define TT_PAPER "Auswahl des Papierformates (psresize)"
#define TT_ONE_UP "Druckt eine Dokumentenseite\n pro Blattseite (psnup)"
#define TT_TWO_UP "Druckt zwei Dokumentenseiten\n pro Blattseite (psnup)"
#define TT_FOUR_UP "Druckt vier Dokumentenseiten\n pro Blattseite (psnup)"
#define TT_REVERSE_ORDER "Druckt letzte Seite zuerst (psselect)"
#define TT_BOOK_ORDER "Ordnet die Seiten f�r\n eine Buchbindung um (psbook)"
#define TT_SIGNATURE "Signatur f�r den Buchdruck,\n ein Vielfaches von 4 (psbook)"
#define TT_ALL_PAGES "Druckt alle Seiten\n im gew�hlten Bereich (psselect)"
#define TT_EVEN_PAGES "Druckt alle Seiten mit gerader Seitenzahl\n im gew�hlten Bereich (psselect)"
#define TT_ODD_PAGES "Druckt alle Seiten mit ungerader Seitenzahl\n im gew�hlten Bereich (psselect)"
#define TT_STARTPAGE "Erste zu druckende Seite (psselect)\n Achtung: Seitenzahlen m�ssen nicht mit der\n internen Numerierung �bereinstimmen!"
#define TT_ENDPAGE "Letzte zu druckende Seite (psselect)\n Achtung: Seitenzahlen m�ssen nicht mit der\n internen Numerierung �bereinstimmen!"
#define TT_PRINTBUTTON "Konvertiert, filtert und �bergibt das Dokument\n an den gew�hlten logischen Drucker"
#define TT_PREVIEWBUTTON "Konvertiert, filtert und �bergibt das Dokument\n an einen Previewer"
#define TT_QUITBUTTON "Beendet das Programm\n nach einer weiteren Abfrage"
#define TT_FILEBUTTON "L�dt eine neue Datei zur Bearbeitung"
#define TT_OPTIONSBUTTON "L��t Voreinstellungen interaktiv\n vornehmen und speichern"
#define TT_INFOBUTTON "Gibt Hinweis auf Autoren, Copyright\n und Version des Programmes"
#define TT_OPT_PRINTER_NUM "W�hlt einen logischen Drucker aus"
#define TT_OPT_PRINTER_NAME "Der Name des Druckers\n wie er im Men� erscheint"
#define TT_OPT_CONVERTER "Befehl zum Konvertieren der Datei\n nach Postscript.\n %INFILE und %PSFILE werden durch die wahren\n Dateinamen ersetzt"
#define TT_OPT_PRINTER "Befehl zum Drucken der Datei.\n %PSFILE wird durch den wahren\n Dateinamen ersetzt"
#define TT_OPT_GLOBAL_BTN "Mit dieser Option wird statt der\n  userspezifischen die globale\n Konfiguration gesichert bzw. geladen" 
#define TT_OPT_QUIT_BTN "Setzt die �nderungen\n und schlie�t das Fenster"
#define TT_OPT_RELOAD_BTN "L�dt die urspr�ngliche Konfiguration"
#define TT_OPT_SAVE_BTN "Sichert die �nderungen\n in der Konfigurationsdatei"
#endif

