/******************************************************************
  Program: PriMa
  File:    version.h
  Author:  J�rg R�dler
******************************************************************/

#ifndef VERSION_H
#define VERSION_H

#define VERSION "V0.3"
#define LONG_VERSION "Print Manager (PriMa) Version 0.3"

#endif
