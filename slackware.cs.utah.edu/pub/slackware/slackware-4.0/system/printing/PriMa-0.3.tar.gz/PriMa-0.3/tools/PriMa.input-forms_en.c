/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "PriMa.input-forms_en.h"

FD_mainwin *create_form_mainwin(void)
{
  FL_OBJECT *obj;
  FD_mainwin *fdui = (FD_mainwin *) fl_calloc(1, sizeof(*fdui));

  fdui->mainwin = fl_bgn_form(FL_NO_BOX, 490, 110);
  obj = fl_add_box(FL_FLAT_BOX,0,0,490,110,"");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
  fdui->pixmap = obj = fl_add_pixmap(FL_NORMAL_PIXMAP,355,0,60,40,"");
  obj = fl_add_text(FL_NORMAL_TEXT,415,0,75,40,"PriMa");
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_TIMESBOLDITALIC_STYLE+FL_EMBOSSED_STYLE);
  fdui->clear_button = obj = fl_add_button(FL_NORMAL_BUTTON,395,80,95,25,"Clear");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,button_cb,3);
  fdui->input = obj = fl_add_input(FL_NORMAL_INPUT,175,40,315,30,"Name:");
    fl_set_object_color(obj,FL_MCOL,FL_WHITE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->ok_button = obj = fl_add_button(FL_RETURN_BUTTON,5,80,125,25,"Ok");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,button_cb,0);
  fdui->restore_button = obj = fl_add_button(FL_NORMAL_BUTTON,290,80,95,25,"Reset");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,button_cb,2);
  fdui->cancel_button = obj = fl_add_button(FL_NORMAL_BUTTON,140,80,125,25,"Back");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lcolor(obj,FL_BLUE);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
    fl_set_object_callback(obj,button_cb,1);
  fl_end_form();

  fdui->mainwin->fdui = fdui;

  return fdui;
}
/*---------------------------------------*/

