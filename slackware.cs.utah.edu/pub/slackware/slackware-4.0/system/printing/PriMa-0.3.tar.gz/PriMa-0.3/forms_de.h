#ifndef FD_mainwin_h_
#define FD_mainwin_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void actbutton_cb(FL_OBJECT *, long);
extern void nup_cb(FL_OBJECT *, long);
extern void pages_cb(FL_OBJECT *, long);
extern void book_cb(FL_OBJECT *, long);

extern void opt_actbutton_cb(FL_OBJECT *, long);
extern void opt_printer_number_cb(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *mainwin;
	void *vdata;
	long ldata;
	FL_OBJECT *main_frame;
	FL_OBJECT *printbutton;
	FL_OBJECT *previewbutton;
	FL_OBJECT *quitbutton;
	FL_OBJECT *infobutton;
	FL_OBJECT *filebutton;
	FL_OBJECT *optionsbutton;
	FL_OBJECT *statusline;
	FL_OBJECT *startpage;
	FL_OBJECT *endpage;
	FL_OBJECT *printer;
	FL_OBJECT *paper;
	FL_OBJECT *nup_group;
	FL_OBJECT *four_up;
	FL_OBJECT *one_up;
	FL_OBJECT *two_up;
	FL_OBJECT *pages_group;
	FL_OBJECT *all_pages;
	FL_OBJECT *odd_pages;
	FL_OBJECT *even_pages;
	FL_OBJECT *pixmap;
	FL_OBJECT *signature;
	FL_OBJECT *reverse_order;
	FL_OBJECT *book_order;
} FD_mainwin;

extern FD_mainwin * create_form_mainwin(void);
typedef struct {
	FL_FORM *optwin;
	void *vdata;
	long ldata;
	FL_OBJECT *pixmap;
	FL_OBJECT *opt_savebutton;
	FL_OBJECT *opt_reloadbutton;
	FL_OBJECT *opt_quitbutton;
	FL_OBJECT *opt_printer_number;
	FL_OBJECT *opt_printer_name;
	FL_OBJECT *opt_converter;
	FL_OBJECT *opt_printer;
	FL_OBJECT *opt_globalbutton;
} FD_optwin;

extern FD_optwin * create_form_optwin(void);

#endif /* FD_mainwin_h_ */
