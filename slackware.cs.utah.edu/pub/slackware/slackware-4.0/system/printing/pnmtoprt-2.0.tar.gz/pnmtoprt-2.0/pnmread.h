#define PPM 1
#define PGM 2
#define PBM 3

typedef struct {
  char magic[3];
  long width;
  long height;
  long colors;
  int binary;
  int type;
#ifdef __STDC__
  int (*get_pixel_mono)(int *, FILE *);
  int (*get_pixel_color)(int *, int *, int *, int *, FILE *);
#else
  int (*get_pixel_mono)();
  int (*get_pixel_color)();
#endif
} Pnm_Info;


#ifdef __STDC__
extern Pnm_Info *pnm_get_info(FILE *);
#else
extern Pnm_Info *pnm_get_info();
#endif
