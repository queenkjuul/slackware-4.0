/* new drivers must be added here
 */


typedef struct {
  char *driver_name;
  int (*driver)();
} Driver_List;

/* Declaration of new drivers */
#ifdef __STDC__
extern int necp6_mono(FILE *in, FILE *out, int argc, char *argv[]);
extern int necp6_color(FILE *in, FILE *out, int argc, char *argv[]);
#else
extern int necp6_mono();
extern int necp6_color();
#endif

/* insert new drivers here */
Driver_List driver_list[] = {
  { "necp6_mono", necp6_mono },
  { "necp6_color", necp6_color },
  { NULL, NULL }
};
