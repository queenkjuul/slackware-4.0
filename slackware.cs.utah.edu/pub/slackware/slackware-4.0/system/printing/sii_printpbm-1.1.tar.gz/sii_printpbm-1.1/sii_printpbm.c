/* 
  sii_printpbm.c - Print to a Seiko Instruments SLP1100 Label printer
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  The GNU General Public License is contained in the file LICENSE.


  Author:	 Eric Ayers.  Copyright (c) 1998

  Desription:	 Takes a PBM file (Portable Bitmap Format) as input.  
		 There are lots of tools for converting other graphics
		 formats into PBM format (I use the netpbm toolkit)
		 A good resolution for this file is 240x100.  
		 The bitmap is centered on the label. I'm using 3" long
		 stock.

		 I've tested this with the SLP-1100 only - (also called
		 the Smart Label Printer EZ30 ) 
		 
		 We used this code to print badges for the 1998 Atlanta 
		 Linux Showcase.  The label printer is too slow to
		 do high volume, but it does look fairly nice, so for
		 VIPs, we printed names on transparent labels and stuck
		 them on top of Pre-printed badges.

		 We set this up by having a postscript header file that
		 we appended a function call to with the name to print. 
		 Then, we send the post script file to gs -sDEVICE=pbm
		 and piped the output to this program.

		 Compiled under Red Hat Linux 5.0 with glibc.
		 It should work with any UNIX, but the default serial
		 port name will be wrong. 

  Specs for Seiko Printer originally from: http://www.seikosmart.com/ 
 
  Compile with: cc -o sii_printpbm sii_printpbm.c
  			or
  		cc -o sii_printpbm sii_printpbm.c -DUSE_SELECT


  TODO:		Better error handling would be nice
  		Document usage with LPR
		Sample Post script code to generate PBM files
 */
/*
 Revision History:

 $Log$

 */
/**************************************************************************
 *			Include Files
 **************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>

/* UNIX isms */
#include <errno.h>
#include <termios.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/*#define USE_SELECT */	/* for testing */
#if !defined (USE_SELECT)
#include <sys/poll.h>		/* SYSV replacement for select() */
#endif


/**************************************************************************
 *			Macro Definitions
 **************************************************************************/

/* The status bit definitions and command definitons come from the 
   sample code distributed by Seiko Instruments from their web site.
 */

/* ******************* Printer status bit definitions ******************* */

#define STAT_PAPER_OUT   0x01
#define STAT_PAPER_JAM   0x02
#define STAT_HARD_ERR    0x04
#define STAT_COMM_ERR    0x08
#define STAT_COMMAND_ERR 0x10
#define STAT_IDLE        0x20
#define STAT_BUFFER_FULL 0x40
#define STAT_ACK         0x80

#define STAT_ERROR      0x1F            /* mask for any error */
#define STAT_9600       0x77            /* response to CMD_CHECK */

/* ********************* Printer command definitions ********************* */

#define CMD_NOP         0x00            /* no-operation               */
#define CMD_STATUS      0x01            /* request printer status     */
#define CMD_L2R         0x03            /* print left to right        */
#define CMD_R2L         0x04            /* print right to left        */
#define CMD_TABRIGHT    0x07            /* tab n dots to right        */
#define CMD_TABLEFT     0x08            /* tab n dots to left         */
#define CMD_HALFDOT     0x09            /* move vertically 1/2 dot    */
#define CMD_LINEFEED    0x0A            /* move vertically 8 dots     */
#define CMD_VERTTAB     0x0B            /* move vertically 7.5 dots   */
#define CMD_FORMFEED    0x0C            /* advance label              */
#define CMD_RETURN      0x0D            /* move to left margin        */
#define CMD_DENSITY     0x0E            /* set print density          */
#define CMD_RESET       0x0F            /* reset print and feed label */
#define CMD_CHECK       0x88            /* version check command      */

#ifndef MAX
#define MAX(a,b) ((a)>(b) ? (a) : (b))
#endif

#define DBG_ERROR	1
#define DBG_CTRACE	5
#define DBG_TRACE	9
/***********************************************************************
 *			     Global Variables
 ***********************************************************************/

int global_serial_fd = -1;
unsigned char global_status;
unsigned int global_dbg_lvl;

/***********************************************************************
 *				Functions
 ***********************************************************************/


/*
  dbg_prt - Print out a debugging message if debugging is on 


  
  Inputs: dbg_lvl - a number that tells what level of debugging is on
                    DBG_ERROR  == 1 == errors
                    DBG_CTRACE == 5 == function start tracing
                    DBG_TRACE  == 9 == verbose error message

		    The message is printed if debugging is on for the
                    specified level or higher.

          format_string - printf like format string
          ...  - arguments to follow

  Outputs: If debugging has been durned on (set by global_dbg_lvl)
  	errors will be written to stdout.
 */
static dbg_prt
(
 int dbg_lvl,
 char * format_string,
 ...
)
{
  va_list ap;
 
  va_start (ap, format_string);

  if (global_dbg_lvl >= dbg_lvl) {
    vfprintf (stderr, format_string, ap);
    fflush (stderr);
  }

} /* end dbg_prt() */

/* ========================================================================= */
/*
  get_status - Retrieve the current status bit from the printer.

  Description:  If you are reading the SII sample code, this function
                should look familiar, but it isn't quite the same.
		Basically, since they are peeking at registers in Win32,
		they can see a little more information than we can 
		(they can tell when the last byte in the serial port 
		buffer has been sent.)

		FYI, If I had to do it over again, I'd make this code
		work more like the sample code. If you are reading this
		and want to re-implement it, you have my blessing!
		

  Inputs:	wait_flag - 1 means wait up to 1 second for a character
                            0 means return immediately if no new input.

  Outputs:	None.

  Returns:	-1 on timeout
                8 bit status value from printer on success.
 */
int get_status  
(
 int wait_flag
)
{
#define ROUTINE "get_status ()"
  int return_val;
  int global_status_int = 0;
  
#if defined(USE_SELECT)
  fd_set readfds;
  struct timeval tv;

  dbg_prt (DBG_CTRACE, "%s: Starting. using select() wait_flag=%d\n", 
	   ROUTINE, wait_flag);

  tv.tv_sec = wait_flag;
  tv.tv_usec = 1;

  FD_ZERO(&readfds); 
  FD_SET(global_serial_fd,&readfds);
  return_val = select (1, &readfds, NULL, NULL, &tv);

  if (!return_val) {
    return -1;
  }
#else
  struct pollfd poll_str[1];

  dbg_prt (DBG_CTRACE, "%s: Starting. using poll() wait_flag=%d\n", 
	   ROUTINE, wait_flag);

  poll_str[0].fd= global_serial_fd;
  poll_str[0].events = POLLIN;
  poll_str[0].revents = 0;

  return_val = poll (poll_str, 1, (wait_flag * 1000) + 1);
  if (return_val != 1) {
      return -1;
    }
#endif


  global_status = 0;

  return_val = read (global_serial_fd, &global_status, 1);
  if (return_val != 1) {
    fprintf (stderr, "Error on read: %s\n", strerror(errno)); 
    fflush (stderr);
    return -1;
  }

  global_status_int = global_status;

  return global_status;

#undef ROUTINE
} /* end get_status() */

/* ========================================================================= */
/*
  read_pbm  - read a pbmfile into a buffer
  Inputs:	filename - name of file to read

  Outputs:	width - width of the pbm file in pixels
                height - height of the pbm file in pixels
                image_buf_ptr - malloc()'ed buffer of the image
                    data.  1 byte = 8 horizontal pixels of 
                    b&w image data.

  Returns: 	0 on success, non-zero on failure.
 */
int read_pbm  
(
 FILE * pbmfile, 
 char *filename,
 int * width, 
 int * height, 
 char **image_buf_ptr
)
{
#define ROUTINE "read_pbm ()"
  char buf[80];
  int pbm_version = 0;
  int byte_size = 0;
/* ------------------------------------------------------------------------- */
  dbg_prt (DBG_CTRACE, "%s: Starting\n", ROUTINE);

  if (!pbmfile) {
    fprintf (stderr, "Couldn't open PBM file: %s - %s\n", 
	     filename, strerror(errno));  
    fflush (stderr);
    return 1;
  }

  /* Read the version of the PBM file*/
  if (fgets(buf, sizeof(buf), pbmfile) == NULL) {
    fprintf (stderr, "fgets got EOF: %s - %s\n",
	     pbmfile, strerror(errno));  
    fflush (stderr);      
    return 1;
  };

  /* check for the PBM header */
  if (buf[0] != 'P') {
    fprintf (stderr, "Not a pbmfile\n"); fflush (stderr);
    return 1;
  }
  pbm_version = buf[1];

  /* get the width & height of the file (skipping over comments*/
  *width = 0; *height = 0;

  while (NULL != (fgets (buf, sizeof(buf), pbmfile))) {
    if (2 == sscanf (buf, "%d%d\n", width, height)) {
      
      dbg_prt  (DBG_TRACE, "%s: got width %d height %d\n", 
		ROUTINE, *width, *height);
      break;
    }
      *width = 0; *height = 0;

    } 

  /* check to see if we read width & height correctly */
  if (*width == 0 || *height == 0)
    {
      fprintf (stderr, "Couldn't get width & height\n");
      return 1;
    } 

  /* alloc a buf for the image */
  byte_size = ((*width) / 8) * (*height);
  (*image_buf_ptr) = (char *)calloc(1,byte_size);
  
  /* read a version that contains a binary dump */
  if (pbm_version == '4')
  {
    /* Raw data follows 1 byte = 8 bits of data */
    if (fread ((*image_buf_ptr), byte_size, 1, pbmfile) != 1)
      {
	fprintf (stderr, "couldn't read %d bytes - %s\n", byte_size, strerror(errno));
	return 1;
      };

    dbg_prt (DBG_TRACE, "read %d bytes\n", byte_size);
    return 0;
  }

  /* Or, it might be a version with ascii 0 and ascii 1 */
  else if (pbm_version == '1')
  {
    char *tmp_buf = (char *)calloc(1,(*width) + (*width)%8); 
		    /* alloc enough to round out to 8 bytes */
    int x,y;
    int width_bytes = (*width) / 8;

    /*fprintf (stderr, "In version 1 read routine\n"); fflush(stderr);*/

    /* Raw data follows 1 byte = 1 bits of data */    
    /* Ascii 0 = 0, ASCII 1 = 1 */
    for (y=0;y<*height; y++)
      {
	memset (tmp_buf, 0, *width);

	for (x=0;x<(*width);x++)
	  {
	    while ((tmp_buf[x] = fgetc(pbmfile))
		   && tmp_buf[x] != '1' && tmp_buf[x] != '0') ;
	    if (feof(pbmfile))
	      {
		printf ("ERROR: Got EOF\n");
		return 1;
	      }
	  }

	for (x=0;x<width_bytes;x++)
	  {
	    int offset = (width_bytes * y) + x;

	    /* pack the data 8 bits at a time into 1 byte */
	    (*image_buf_ptr) [offset] = 
	       ((tmp_buf[x*8] == '1') ? 0x80 : 0)
	      +((tmp_buf[x*8+1] == '1') ? 0x40 :0)
	      +((tmp_buf[x*8+2] == '1') ? 0x20 : 0)
	      +((tmp_buf[x*8+3] == '1') ? 0x10 : 0)
	      +((tmp_buf[x*8+4] == '1') ? 0x08 : 0)
	      +((tmp_buf[x*8+5] == '1') ? 0x04 : 0)
	      +((tmp_buf[x*8+6] == '1') ? 0x02 : 0)
	      +((tmp_buf[x*8+7] == '1') ? 0x01 : 0);
	  }
      }

    free (tmp_buf);

    return 0;
  }  /* end recognized versions of PBM format */

  
  fprintf (stderr, "Couldn't deal with PBM file version : %c\n", 
	   buf[1]);
  fflush (stderr);

  return 1;

#undef ROUTINE
} /* end read_pbm() */

/* ========================================================================= */
/*
  write_command - send a command to the printer 

  Description:	This function sends data to the printer,
                making sure that the printer accepts the
                data without the buffers overflowing by
                sending a few bytes, then checking for 
		a returned status bit. It looks like the
                printer chokes if you just do a 'write()' 
		and you send more than 80 characters.  What
                a shame, since the printer's width is 
		102 pixels! 

  Inputs:	buf    - buffer to send to the printer
                length - length of entire command.

  Outputs:      None
  
  Returns:	None

  Side Effects: The buffer that is passed is trashed,
                don't use it again w/o overwriting it!

 */
void write_command 
(
 char * buf, 
 int length
)
{
#define ROUTINE "write_command ()"
#define MAX_CMD_CHUNK 10
  int curr_byte;
/* ------------------------------------------------------------------------- */
  dbg_prt (DBG_CTRACE, "%s: Starting\n", ROUTINE);

  for (curr_byte = 0; curr_byte< length; curr_byte+=MAX_CMD_CHUNK)
    {
      int result;

      if (curr_byte +MAX_CMD_CHUNK > length)
	write (global_serial_fd, &buf[curr_byte], length%MAX_CMD_CHUNK);
      else
	write (global_serial_fd, &buf[curr_byte], MAX_CMD_CHUNK);

      result = get_status(0);
      if (result != -1 && (result & STAT_BUFFER_FULL))
	{
	        while (1)
		  {
		    result = get_status(0);
		    if ((result != -1) && !(result & STAT_BUFFER_FULL))
		      break;
		  }
	}
    }
#undef MAX_CMD_CHUNK
#undef ROUTINE
} /* end write_command () */


/* ========================================================================= */
/* flip_buf - reverse the order of bytes in the buffer.  

   Description:	This function is useful for making the
   		print head run in reverse.  The documentation
		doesn't recommend it, however.  The print
                quality is really lousy.

  Input:      	buf - string to reverse
           	length - length of the string

  Outputs:    	None.
  
  Returns:	None.
 */
void flip_buf (char * buf, int length)
{
#define ROUTINE "flip_buf ()"
  char temp;
  int i;
/* ------------------------------------------------------------------------- */
  dbg_prt (DBG_CTRACE, "%s: Starting. length=%d\n", ROUTINE, length);
  
  for (i=0;i<length/2;i++) {
    temp=buf[length-i];
    buf[length-i] = buf[i];
    buf[i]=temp;
  }

#undef ROUTINE
} /* end flip_buf() */


/* ========================================================================= */
/*
  usage - print out what this program does

  Inputs:	progname - name of this program.

 */
int usage (char * progname)
{
  printf ("usage: %s [-bidirection] [-density <value 0-4>]\n"
	  "          [-port <serial port device>] filename\n", progname);
  printf ("sends a PBM file to the SII label printer\n");
  printf ("  -bidirectional - print head moves both way, slighty\n");
  printf ("                     faster, but poor quality\n");
  printf ("  -density <#>   - 0 == normal 4 == darkest\n");
  printf ("  -port <device> - Use the specified serial port for the\n");
  printf ("                     printer. Default is /dev/cua0\n");
  printf ("  -debug <#>     - Turn on debugging messages\n");
  printf ("                   1=errors only, 5=functions, 9=verbose\n");
  printf ("  filename       - Portable Bitmap File (PBM version 1, 4 or 5)\n");
  exit(1);
} /* end usage () */

/* ========================================================================= */
/*
  main - the main line of the program.
  
  Probably needs to be split up into some more functions - but then
  again, we aren't writing a software masterpiece here... I just want
  the damn thing to work!

 */
int main (int argc, char * argv[])
{
#define ROUTINE "main ()"
    struct termios termios_buf;
    char buf[256];
    int i; 
    int curr_offset;
    int width, height;
    int width_bytes, height_bytes;
    char * image_buf;
    FILE * pbmfile;
    char * filename = NULL;
    int x_pos, y_pos, center_pad;
    int	in, out, numargs, len;
    int double_flag = 0;
    int bidirection_flag = 0;
    int direction = 0;
    int density_value = 0x80;
    char * serial_port = "/dev/cua0";
/* --------------------------------------------------------------------- */

    /* parse cmdline args						*/
    for (numargs = argc, out = in = 1; in < numargs; in ++)
      {
	len = strlen (argv [in]);
	
	if (strncmp (argv [in], "-double", len) == 0)
	  {
	    double_flag++;
	    argc --;
	    continue;
	  }
	if (strncmp (argv [in], "-bidirection", len) == 0)
	  {
	    bidirection_flag++;
	    argc --;
	    continue;
	  }
	if (strncmp (argv [in], "-port", len) == 0)
	  {
	    argc --;
	    in ++;
	    serial_port = strdup(argv [in]);
	    argc --;
	    continue;
	  }
	if (strncmp (argv [in], "-debug", len) == 0)
	  {
	    argc --;
	    in ++;
	    if ((sscanf(argv[in], "%d", &global_dbg_lvl) != 1) ||
		global_dbg_lvl < DBG_ERROR || global_dbg_lvl > DBG_TRACE)
	      {
		fprintf (stderr, 
			 "Debug level should be a number between 1 and 9");
		usage(argv[0]);
		exit(1);
	      }
	    
	    argc --;
	    continue;
	  }
	if (strncmp (argv [in], "-density", len) == 0)
	  {
	    int tmp_density_value;
	    argc --;
	    in ++;
	    tmp_density_value = atoi(argv[in]);

	    if (tmp_density_value < 0 || tmp_density_value > 4)
	      printf ("Valid values for -density are between 0 & 4 \n");
	    else
	      density_value = 0x80 + density_value;

	    argc --;
	    continue;
	  }
	else if ((strncmp (argv [in], "-help", len) == 0)
		 || (strncmp (argv [in], "-?", len) == 0))
	  {
	    usage (argv[0]);
	    exit(1);
	  }
	
	/* Not our argument, save it for caller */
	argv [out ++] = argv [in];
      }
    argv [out] = NULL;		/* re-terminate arg list */

    if (out>=2)
      {
	filename = argv[1];
	pbmfile = fopen (filename, "r");
      }
    else
      {
	fprintf (stderr, "No filename argument: Reading pbmfile from stdtin\n");
	filename="<STDIN>";
	pbmfile=stdin;
      }


    if (read_pbm(pbmfile, filename, &width, &height, &image_buf)!= 0)
    {
      fprintf (stderr, "Couldn't read PBM file\n");  fflush (stderr);
      exit (1);
    }

    dbg_prt (DBG_TRACE, "%s: Read file %d x %d\n", ROUTINE, width, height);

    width_bytes = (width / 8);

    dbg_prt (DBG_TRACE, "%s: Opening Serial Port... %s\n", 
	     ROUTINE, serial_port); 

    global_serial_fd = open (serial_port, O_RDWR);

    dbg_prt (DBG_TRACE, "%s: Opened Serial Port. fd=%d\n", ROUTINE, 
	     global_serial_fd );

    if (global_serial_fd < 0)
    {
      printf ("Couldn't open serial port %s. %s\n", serial_port, 
	      strerror(errno));
      exit (1);
    }

    /* set port for 9600 baud, no parity, 8 data bits, one stop bit  */
    memset (&termios_buf, 0, sizeof (termios_buf));
    cfmakeraw(&termios_buf);
    cfsetospeed(&termios_buf, B9600);
    cfsetispeed(&termios_buf, B9600);

    dbg_prt (DBG_TRACE, "%s: Setting Serial Port...",ROUTINE);

    tcsetattr(global_serial_fd, TCSANOW, &termios_buf);

    dbg_prt (DBG_TRACE, "%s: Set Serial Port\n", ROUTINE);

    buf[0]=CMD_STATUS; /* Request Status */
    write (global_serial_fd, &buf, 1);

    while (get_status(1) != -1);
    
    /* Send a printer reset */
    buf[0]=CMD_RESET;
    write (global_serial_fd, &buf, 1);
    while (get_status(1) != -1);

    buf[0]=CMD_RETURN;
    write (global_serial_fd, &buf, 1);
    while (get_status(1) != -1);

    /* Send a CHECK command to see if this is an SLP1100 */
    /* I commented this out, becuase 
          1) it takes time 
          2) I don't know how I'd  change my code if it weren't an SLP1100!
     */
    /*
    buf[0]=CMD_CHECK;
    write (global_serial_fd, &buf, 1);
    while (get_status(1) != -1);
    */

    /* set the print density */
    buf[0]=CMD_DENSITY;
    buf[1]=density_value;
    write (global_serial_fd, &buf, 2);
    while (get_status(1) != -1);

    /* calculate how far to shift the image over in order to center 
       it on the label.
    */
    center_pad = MAX(51 - (height /2), 0);

    /* send a stripe the bitmap, 8 horizontal pixels wide */
    for (x_pos = (width_bytes -1) ; x_pos >= 0; x_pos--)
      {
	direction = !direction;
	if (bidirection_flag && direction)
	  buf[0]=CMD_R2L; /* print backwards */
	else
	  buf[0]=CMD_L2R;

	buf[1]= height + center_pad;

	for (y_pos=0; y_pos < center_pad; y_pos++)
	{
	  buf[2 + y_pos] = 0;
	}

	for (y_pos=0; y_pos < height; y_pos++)
	{
	  int offset = x_pos + (width_bytes * y_pos);
	  buf[2 + center_pad + y_pos] = image_buf[offset];
	}

	if (bidirection_flag && direction)
	  flip_buf(&buf[2],height+center_pad);

	write_command (buf, height+center_pad +2);

	/* wait for the printer to finish up */
	while ((get_status(1) & STAT_IDLE) == 0);

	if (!bidirection_flag)
	  {
	    dbg_prt (DBG_TRACE,  "%s: moving back to the left\n", ROUTINE);
	    
	    buf[0]=CMD_TABLEFT;
	    buf[1]=height + center_pad;
	    write (global_serial_fd, &buf, 2);
	  }

	dbg_prt (DBG_TRACE, "%s: Sending Linefeed\n", ROUTINE);

	buf[0]=CMD_LINEFEED;
	buf[1]=height;
	write (global_serial_fd, &buf, 2);
      }

    /* Send a Label Eject command */
    dbg_prt (DBG_TRACE, "%s: Sending Eject\n", ROUTINE);

    buf[0]=CMD_FORMFEED;
    write (global_serial_fd, &buf, 1);
    while (get_status(1) != -1);

    return 0;
#undef ROUTINE
} /* end main() */
