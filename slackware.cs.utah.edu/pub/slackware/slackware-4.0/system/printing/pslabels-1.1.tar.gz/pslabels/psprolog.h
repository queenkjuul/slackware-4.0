// $Id: psprolog.h,v 1.1.1.1 1998/05/14 16:58:34 perk Exp $

char *ps_prolog[] = {
  "/BeginEPSF { %def",
  "  /b4_Inc_state save def",
  "  /dict_count countdictstack def",
  "  /op_count count 1 sub def",
  "  userdict begin",
  "  /showpage {} def",
  "  0 setgray 0 setlinecap",
  "  1 setlinewidth 0 setlinejoin",
  "  10 setmiterlimit [] 0 setdash newpath",
  "  /languagelevel where",
  "  {pop languagelevel",
  "  1 ne",
  "    {false setstrokeadjust false setoverprint",
  "    } if",
  "  } if",
  "} bind def",
  "",
  "/EndEPSF { %def",
  "  count op_count sub {pop} repeat",
  "  countdictstack dict_count sub {end} repeat",
  "  b4_Inc_state restore",
  "} bind def",
  "",
  NULL
};
