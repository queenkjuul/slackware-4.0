char *version="1.0";
char *copyright="Vitaly Lev 1994";
char *reldate="29 September 1994";
