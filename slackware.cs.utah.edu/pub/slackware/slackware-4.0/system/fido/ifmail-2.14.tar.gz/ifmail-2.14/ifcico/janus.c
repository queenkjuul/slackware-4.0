#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "lutil.h"
#include "ttyio.h"
#include "session.h"
#include "statetbl.h"
#include "config.h"
#include "emsi.h"

extern int janus(void);
extern int janus(void)
{
	debug(11,"start janus transfer");
	return 0;
}
