#!/bin/sh
exec /usr/local/lib/ifmail/ifnews -rf230.n5020.z2
