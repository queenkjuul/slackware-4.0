#ifndef size_t
#define size_t unsigned int
#endif

char *xmalloc(size_t);
char *xstrcpy(char *);
char *xstrcat(char *,char *);
