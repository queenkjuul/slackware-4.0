#ifndef HASH_H
#define HASH_H

extern void hash_update_n();
extern void hash_update_s();

#endif
