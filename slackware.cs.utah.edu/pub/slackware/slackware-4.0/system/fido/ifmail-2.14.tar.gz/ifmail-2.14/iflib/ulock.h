int lock(char *);
int ulock(char *);
