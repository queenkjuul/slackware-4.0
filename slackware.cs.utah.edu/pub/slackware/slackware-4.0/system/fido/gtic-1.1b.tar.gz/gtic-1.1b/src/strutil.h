#ifndef _STRUTIL_H
#define _STRUTIL_H

#include "config.h"

char *strschr(char *str,char *what);
char *strschr2(char *str,char *what);
void strremove(char *str,char *str_to_remove);
int cmp_paths(char *str1,char *str2);
void str_truncate(int max,char *str);
void delcrlf(char *);
int parse_list_with_flag_tab(char *,int,char *,struct flag_tab *,char *);

#endif
