#include <string.h>
#include <sys/stat.h>

#include "config.h"

void mkdirs(name,mode)
char *name; int mode;
{
        char buf[PATH_MAX],*p,*q;
        int rc;

        strncpy(buf,name,sizeof(buf)-1);
        buf[sizeof(buf)-1]='\0';
        p=buf+1;
        while ((q=strchr(p,'/')))
        {
                *q='\0';
                rc=mkdir(buf,mode);
                *q='/';
                p=q+1;
        }
	mkdir(name,mode);
}

