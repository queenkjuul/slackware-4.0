#ifndef __XMALLOC_H
#define __XMALLOC_H

void *xmalloc(size_t size);
void xfree(void *ptr);

#endif
