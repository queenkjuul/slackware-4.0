#ifndef _LOCK_H
#define _LOCK_H

/* Checks lock_file. Returns 0 if no another gtic. */
int check_lock(void);

/* Touch lock_file. Call mkfifo(lock_file,0600) and forks for lock_file
controlling. Returns 0 if lock succesfully created. */
int touch_lock(void);
#endif
