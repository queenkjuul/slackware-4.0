/*
  standard assert function but with writing to log_file
*/

#include <stdio.h>
#include "config.h"

void my__assert_fail(char *expr,char *file,unsigned line,char *func)
{
fprintf(stderr,"assertion failed at %s(%u) in %s(): %s\n",file,line,func,expr);
l_printf(      "assertion failed at %s(%u) in %s(): %s",file,line,func,expr);
abort();
}
