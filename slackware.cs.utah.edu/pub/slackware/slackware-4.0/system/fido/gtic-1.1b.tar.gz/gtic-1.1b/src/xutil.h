#ifndef _XUTIL_H
#define _XUTIL_H

#ifndef size_t
#define size_t unsigned int
#endif

void *__old_xmalloc(size_t);
char *xstrcpy(char *);
char *xstrcat(char *,char *);
#endif
