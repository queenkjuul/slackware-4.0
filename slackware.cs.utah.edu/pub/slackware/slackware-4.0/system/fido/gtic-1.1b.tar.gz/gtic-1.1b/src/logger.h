#ifndef _LOGGER_H
#define _LOGGER_H
void l_init(const char *logname);
void l_printf(const char *format, ...);
void e_printf(const char *format, ...);
#endif
