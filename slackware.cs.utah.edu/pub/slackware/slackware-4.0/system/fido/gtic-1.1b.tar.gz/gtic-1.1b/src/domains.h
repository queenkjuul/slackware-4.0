#ifndef _DOMAINS_H
#define _DOMAINS_H

extern ilist_t *domains;

void read_domains_file();
char *get_outbound(int zone);

#endif
