#ifndef _TEXTTIME_H
#define _TEXTTIME_H
char *texttime(int islocal);
char *textUTC(void);
#endif
