extern char *version;
extern char *copyright;
extern char *reldate;
