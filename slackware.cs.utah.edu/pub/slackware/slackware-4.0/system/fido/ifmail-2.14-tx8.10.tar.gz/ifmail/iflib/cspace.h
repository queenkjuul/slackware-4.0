#ifndef CSPACE_H
#define CSPACE_H

extern int checkspace(char *,char *,int);
extern unsigned long freespace(char *);

#endif
