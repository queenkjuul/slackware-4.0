#include <sys/types.h>
#include <sys/time.h>
#include <stdio.h>

void usleep (unsigned long);
