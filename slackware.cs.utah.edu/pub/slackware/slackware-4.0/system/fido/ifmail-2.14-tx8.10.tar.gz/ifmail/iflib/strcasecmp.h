#include <ctype.h>

int strcasecmp(register unsigned char *,register unsigned char *);
