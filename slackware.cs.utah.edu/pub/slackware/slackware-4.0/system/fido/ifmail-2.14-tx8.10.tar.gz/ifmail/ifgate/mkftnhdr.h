int ftnmsgid(char *,char **,unsigned long *,char *);
