#ifndef FTSCPROD_H
#define FTSCPROD_H

extern struct _ftscprod {
	unsigned short code;
	char *name;
} ftscprod[];

#endif
