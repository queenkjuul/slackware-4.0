#include <ctype.h>

int strncasecmp(register unsigned char *, register unsigned char *, register int);
