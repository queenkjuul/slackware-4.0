sub _POSIX_C_SOURCE {0;}	# for .ph's from GCC 2.7.x include files
1;
