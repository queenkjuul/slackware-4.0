#include <sys/types.h>
#include <unistd.h>

int rename(char *,char *);
