unsigned long crc(char *);
/* unsigned long crc32(char *,int);
unsigned short crc16(char *,int);
unsigned char checksum(char *,int); */
