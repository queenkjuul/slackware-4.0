/* Contributed by Igor Sharfmesser <igor@kit.kz> */

/* FILE *tmpfile (void); */
