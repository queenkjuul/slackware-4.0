#ifndef NODECHECK_H
#define NODECHECK_H

#include "ftn.h"

extern int chknlent();

#endif
