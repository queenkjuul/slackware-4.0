#include <string.h>
#include <ctype.h>

char *strcasestr(char *,char *);
