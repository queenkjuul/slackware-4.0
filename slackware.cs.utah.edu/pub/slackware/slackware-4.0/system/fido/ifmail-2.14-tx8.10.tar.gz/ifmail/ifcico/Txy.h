#ifndef IFMAIL_TXY_H
#define IFMAIL_TXY_H

#include "nodelist.h"

int not_work_time_now( node * );

#endif
