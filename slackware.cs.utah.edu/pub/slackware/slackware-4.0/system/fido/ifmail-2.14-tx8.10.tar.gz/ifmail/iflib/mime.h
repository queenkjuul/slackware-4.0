char *qp_decode(char *);
/* int=0 for text (normal mode), int=1 for headers and gatebau MSGID */
char *qp_encode(char *,int);
char *b64_decode(char *);
char *b64_encode(char *);
