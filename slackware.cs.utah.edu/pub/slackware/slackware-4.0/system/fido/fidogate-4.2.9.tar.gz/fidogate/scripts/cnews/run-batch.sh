#!/bin/sh
#
# Call newsrun, sendbatches
#
/usr/local/lib/newsbin/input/newsrun
/usr/local/lib/newsbin/batch/sendbatches fidogate
