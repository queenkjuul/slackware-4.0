#!/bin/sh
#
# $Id: runpoll.sh,v 4.9 1997/11/16 15:53:25 mj Exp $
#
# Poll uplink
#

FIDOGATE=<LIBDIR>
IFMAIL=<IFMAILDIR>
NEWS=<NEWSETCDIR>

UPLINK=f2.n1000.z242

# -xterm: run in XTerm window
if [ "$1" = "-xterm" ]; then
  exec /usr/bin/X11/xterm -display :0 -g 80x20 -title "FIDOGATE runpoll" -e $FIDOGATE/runpoll
  exit 0
fi


# Show executed commands
set -x


# Batch ffx news
$NEWS/send-ffx

# Batch ffx mail
#$FIDOGATE/ffxbatch -F Normal -w -b morannon 242:1000/1
$FIDOGATE/ftnpack -f 242:1000/1 -I %O/out.0f2/morannon

# Gateway
$NEWS/send-fidogate

# Tosser w/file attachments
#$FIDOGATE/runtoss outf
# Tosser w/o file attachments
$FIDOGATE/runtoss outpkt/mail
$FIDOGATE/runtoss out

# Poll
$IFMAIL/ifcico $UPLINK

# Tosser
#$FIDOGATE/runin
# only protected inbound
$FIDOGATE/rununpack pin
$FIDOGATE/runtoss   pin

# Unbatch and process ffx files
$FIDOGATE/ffxqt

# Process tic files
$FIDOGATE/ftntick

# Gateway
$FIDOGATE/ftnin -x %L/ftninpost

# Process mail queue
/usr/sbin/sendmail -q

# Tosser expire
$FIDOGATE/ftnexpire
