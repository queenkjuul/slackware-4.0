/*
 * Automatically generated --- do not edit!
 */
#define BINDIR   "/usr/local/bin"
#define LIBDIR   "/usr/local/lib/fidogate"
#define SPOOLDIR "/var/spool/fido"
#define LOGDIR   "/var/log/fido"
 
#define OUTBOUND "/var/spool/bt"
#define INBOUND  "/var/spool/bt/in"
#define PINBOUND "/var/spool/bt/pin"
