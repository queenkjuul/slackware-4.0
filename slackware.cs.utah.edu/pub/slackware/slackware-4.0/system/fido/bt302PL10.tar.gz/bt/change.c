
/* change port  */

#ifdef USG
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#else
#include <libc.h>
#endif

void main(argc, argv)
	int argc;
	char *argv[];
{
	int uid,gid;
	uid = gid = atoi(argv[2]);	
	printf ("Change Owner for port\n");
	printf("UserId= %d  GroupId= %d  Port= %s\n",uid,gid,argv[1]);

	(void)chown(argv[1],uid,gid);
	(void)chmod(argv[1],0620);
	
}
