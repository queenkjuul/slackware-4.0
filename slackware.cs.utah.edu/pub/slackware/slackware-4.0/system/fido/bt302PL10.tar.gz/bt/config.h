/*
 * config.h
 *
 * Enumeration of Binkley Configuration commands
 *
 */

enum {
	C_ZERO,
	C_SameRing,
	C_NewNodeList,
#ifndef ATARIST
	C_QuickNodeList,
#endif
	C_Answerback,
	C_Macro,
	C_Shell,
	C_Dial,
	C_Event,
	C_Zone,
	C_MaxReq,
	C_LogLevel,
	C_Baud,
	C_MaxPort,
	C_Port,
	C_Carrier,
	C_StatusLog,
	C_Reader,
	C_BossPhone,
	C_BossPwd,
	C_Protocol,
	C_System,
	C_Sysop,
	C_Boss,
	C_Point,
	C_Aka,
	C_Hold,
	C_DownLoads,
	C_NetFile,
	C_Init,
	C_Busy,
	C_Prefix,
	C_NodeList,
	C_Avail,
	C_OKFile,
	C_About,
	C_MailNote,
	C_Banner,
	C_UnAttended,
	C_OverWrite,
#ifndef ATARIST
	C_Rev3,
#endif
	C_ReqOnUs,
	C_LockBaud,
	C_TimeOut,
	C_NoSLO,
	C_SlowModem,
	C_SmallWindow,
	C_NoPickup,
	C_NoRequests,
	C_NetMail,
	C_Suffix,
	C_NoFullScreen,
	C_AutoBaud,
	C_Gong,
	C_NoCollide,
#ifndef ATARIST
	C_TBBSList,
	C_TaskView,
	C_TopView,
#endif
	C_ExtrnMail,
	C_BBSNote,
	C_BBS,
	C_ScriptPath,
	C_BoxType,
#ifndef ATARIST
	C_MultiLink,
#endif
	C_Include,
	C_CaptureFile,
	C_CursorCol,
	C_CursorRow,
	C_DoingMail,
	C_EnterBBS,
	C_PrivateNet,
	C_Packer,
	C_Cleanup,
	C_AfterMail,
	C_Colors,
	C_JanusBaud,
	C_ReqTemplate,
	C_KnownAvail,
	C_KnownReqList,
	C_KnownAbout,
	C_KnownInbound,
	C_KnownReqLim,
	C_KnownReqTpl,
	C_ProtAvail,
	C_ProtReqList,
	C_ProtAbout,
	C_ProtInbound,
	C_ProtReqLim,
	C_ProtReqTpl,
	C_Application,
	C_NoZones,
	C_Answer,
	C_PollTries,
#ifdef NEW
	C_PollDelay,
#endif	
#ifndef ATARIST
	C_SwapDir,
#endif
	C_Address,
#ifdef MULTIPOINT
	C_Key,
#endif
	C_CurMudgeon,
	C_NoWaZOO,
#ifdef EMSI
	C_NoEMSI,
#endif
#ifdef IOS
	C_IOS,
	C_Hold4D,
#endif
	C_ScreenBlank,
	C_Mark_Kromm,
	C_Server,
	C_ModemTrans,
	C_PreDial,
	C_PreInit,
	C_DTRHigh,
	C_Debug,
	C_NoZedZap,
	C_NoResync,
	C_NoSEAlink,
	C_FTS_0001,
	C_LineUpdate,
	C_JanusOK,
	C_TermInit,
	C_Domain,
#ifndef ATARIST
	C_Snoop,
#endif
	C_Flags,
	C_TaskNumber,
	C_MaxBytes,
	C_KnownMaxBytes,
	C_ProtMaxBytes,
#ifdef NEW
	C_MaxTime,
	C_KnownMaxTime,
	C_ProtMaxTime,
#endif
#ifdef ATARIST
	C_NoLineA,
#ifdef BIOSDISPLAY
	C_BIOSdisplay,
#endif
	C_UseColors,	
	C_IKBDclock,
	C_NoCTS,
	C_HardCTS,
#if 0
	C_NoXon,
#endif
#endif  /* ATARIST */
#if defined(ATARIST) || defined(unix)
	C_STlockBaud,
#endif /* defined(ATARIST) || defined(unix) */
#ifdef ATARIST
	C_SlowJanus,
	C_Hard38400,
#endif                                    
#ifdef NEW /* several */
	C_NiceOutbound,
	C_ReInitTime,
	C_ReadHoldTime,
	C_HoldsOnUs,
	C_SendRSP,
#if defined(__PUREC__) || defined(__TURBOC__)
	C_CLIcommand,
#endif	
#if 0
	C_CostLog,
	C_NoWildcards,
	C_SuckerLimit,
	C_HstLs2400c,
	C_CostUnit,
#endif
#endif
#ifdef EMSI
	C_NLsystem,
	C_Phone,
	C_City,
	C_NLfLags,
	C_NLbaud,
#endif
	C_LAST
} CONFIG_VALUES;

#if 0
/*
 * Values for btconfig
 */

#if defined(ATARIST)
 #define CFG_ATARIST C_NoLineA		/* 1st CFG for AtariST 119? */
 #define CFG_HS  C_NiceOutbound	/* (CFG_ATARIST+6) */
#elif defined(NEW)
 #define CFG_HS C_NiceOutbound	/* 119 */				/* HS expansions */
#endif

#endif
