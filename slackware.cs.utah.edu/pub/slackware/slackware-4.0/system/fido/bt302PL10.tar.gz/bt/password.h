#ifndef H_PASSWORD
#define H_PASSWORD
/*
 * Password function prototypes and variables
 */

extern char *remote_password;

int n_password (ADDR *, char *, BOOLEAN);
int n_getpassword (ADDR *);

#endif
