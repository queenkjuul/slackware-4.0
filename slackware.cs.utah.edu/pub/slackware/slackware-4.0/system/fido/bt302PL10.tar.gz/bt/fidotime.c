/* generate fido packet name
 * DDHHMMSS
 * where D = day, H = hour, M = minute, S = second
 * compile with: cc fidotime.c -o fidotime
 */

#include <stdio.h>
#include <time.h>

int main() {
	char timestr[80];
	struct tm *tp;
	time_t tm;
	
	time(&tm);
	tp = localtime(&tm);
	strftime(timestr, 9, "%d%H%M%S\0", tp);
	puts(timestr);

	return 0;
}
