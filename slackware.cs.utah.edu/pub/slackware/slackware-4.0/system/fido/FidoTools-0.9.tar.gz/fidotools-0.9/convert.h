#ifndef CONVERT_H
#define CONVERT_H

/* This function converts a string from ASCII to KOI8-R charset and back */
char *alt2koi (char*);
char *koi2alt (char*);

#endif
