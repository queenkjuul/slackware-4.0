/* Header file for file attach utility */
#ifndef ATTACH_H
#define ATTACH_H

void attachfile (char*, char*, int, int, int);

#endif