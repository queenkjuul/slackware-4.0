#ifndef CRC32_H
#define CRC32_H

unsigned long count_crc32 (char*);
unsigned long count_file_crc32 (char*);

#endif