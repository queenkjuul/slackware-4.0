#ifndef FETOSS_H
#define FETOSS_H

#include <stdio.h>
#include "fidotools.h"

/* This function processes one TIC file */
int process_tic (char*,FILE*,fileinfo*);

void toss_new_files (void);	
void send_autocreat_message (int);
void make_report (fileinfo*,int);
void send_to_receivers (char*, FILE*, int);
void apply_replaces (char*, char*);

#endif