#ifndef POSTFILE_H
#define POSTFILE_H

/* This funtion sends file to file echo-conference */
int post (char*, char*, int);

#endif