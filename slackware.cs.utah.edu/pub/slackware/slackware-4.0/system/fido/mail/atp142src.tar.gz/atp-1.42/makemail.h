/*
     ATP QWK MAIL READER FOR READING AND REPLYING TO QWK MAIL PACKETS.
     Copyright (C) 1992  Thomas McWilliams 
     Copyright (C) 1990  Rene Cougnenc
   
     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 1, or (at your option)
     any later version.
     
     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
     
     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
makemail.h
*/

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#define PACK   ( (int) 1 )
#define ADDREP ( (int) 0 )
#define SKIPIT 'K'

struct  QmailRepType ;

void    ResetHeader(struct QmailRepType *Qmail);
int     Cnf2Msg( const char * );
int     KodeMessage( const char *fname, struct QmailRepType *Qmail );
int     OpenRepFile( const int  );
extern char CurTag[] ;
extern const unsigned char code7bit[] ;
extern const unsigned char codelu[] ;
extern unsigned char codevt[] ; 

/*--------------------- end of makemail.h ----------------------------*/
