/*
     ATP QWK MAIL READER FOR READING AND REPLYING TO QWK MAIL PACKETS.
     Copyright (C) 1992, 1993  Thomas McWilliams 
     Copyright (C) 1990  Rene Cougnenc

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 1, or (at your option)
     any later version.
     
     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
     
     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* 
text.c
*/

/* 
 * ATTENTION: There are two French language sections here. One uses
 * the DOS character set and one uses the Linux character set. DO
 * NOT edit the DOS set under Linux or the Linux set under DOS.
 * It won't work.
 *
 * ATTENTION: Il y a deux sections dessous pour la langue francais.
 * L'un pour MS-DOS, et l'autre pour le Linux. Ne pas editer l'un avec
 * un editeur pour l'autre systeme. Ca ne marchera pas !  
 *                                  '
 */

#include <stdio.h>
#include "system.h"
#include "ansi.h"
#include "reader.h"
/*
#include <sys/types.h>
  */
#ifndef NULL
#define NULL (char *)0
#endif
const char *terms[] = {
 
     "ATP reader to read and reply to messages in QWK format mail packets.",
     "Copyright (c) 1992, 1993  Thomas McWilliams ",
     " ",
     "This program is free software; you can redistribute it and/or modify",
     "it under the terms of the GNU General Public License as published by",
     "the Free Software Foundation; either version 1, or (at your option)",
     "any later version. YOU MAY NOT DENY to others the freedom which you",
     "have been granted, including FULL ACCESS TO THE SOURCE CODE for ATP",
     "or ANY DERIVED WORK.",
     " ",
     "This program is distributed in the hope that it will be useful,",
     "but WITHOUT ANY WARRANTY; without even the implied warranty of",
     "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the",
     "GNU General Public License for more details.",
     " ", 
     "You should have received a copy of the GNU General Public License",
     "along with this program; if not, write to the Free Software",
     "Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.",
     " ",
     "The author of ATP may be reached by posting messages in the",
     "RIME or Fidonet OFFLINE conference and by e-mail at:",
     " ",
     "        thomas.mcwilliams@f615.n109.z1.fidonet.org"
     " ",
     NULL 
     } ;
  
/*
                   Language-dependant file


  All messages tous les messages displayed affich�s by par this program
  ce programme are sont in this file dans ce fichier :-)

*/

/*<<<<< Define FRENCH or ENGLISH  in Makefile's CFLAGS >>>>>*/

#ifndef ENGLISH 
#ifndef FRENCH
#define FRENCH
#endif
#endif

/*=========================================================================*
 *                                                                         *
 *      EEEEEEE  NN   NN   GGGGG   LL       IIII   SSSSS   HH   HH         *
 *      EE       NNN  NN  GG   GG  LL        II   SS   SS  HH   HH         *
 *      EEEE     NNNN NN  GG       LL        II    SSSS    HHHHHHH         *
 *      EE       NN NNNN  GG  GGG  LL        II       SS   HH   HH         *
 *      EE       NN  NNN  GG   GG  LL        II   SS   SS  HH   HH         *
 *      EEEEEEE  NN   NN   GGGG G  LLLLLLL  IIII   SSSSS   HH   HH         *
 *                                                                         *
 *=========================================================================*/

#ifdef ENGLISH

const char *txt[]=
{
/*    0  */   "Ren� Cougnenc 1900",
/*    1  */   "Memory allocation failed !",
/*    2  */   "Warning !",
/*    3  */   "You have replies for",
/*    4  */   "Pack them ?",
/*    5  */   "Loading",
/*    6  */   "No mail found",
/*    7  */   "Try the 'review' command...",
/*    8  */   "Extracting Messages...",
/*    9  */   "empty",
/*   10  */   "Reader",                              /* 1st default prompt */
/*   11  */   "'New' packet seems to be older than existing one",
/*   12  */   "Do you really want to add the messages",
/*   13  */   "No bbs found",
/*   14  */   "Error in CONTROL.DAT.",
/*   15  */   "First Message !",
/*   16  */   "Seek Error",
/*   17  */   "End of messages here.",
/*   18  */   "Read Error",
/*   19  */   " From : ",          /* This is the message header.        */
/*   20  */   "   To : ",          /* Fields must be correctly aligned ! */
/*   21  */   "Subj. : ",
/*   22  */   " Date : ",
/*   23  */   "Number : ",
/*   24  */   " Ref.# : ",
/*   25  */   "  Conf : ",
/*   26  */   "  Time : ",
/*   27  */   "PRIVATE MESSAGE",
/*   28  */   "Unknown conference...",
/*   29  */   "Conference",
/*   30  */   "joined",
/*   31  */   "No new mail",
/*   32  */   "Enter 'n' in any field to abort entry of this message.",
/*   33  */   "Message aborted",
/*   34  */   "Entry too long !  25 chars max.",
/*   35  */   "Too long !  R = Receiver only, N = none = public msg.",
/*   36  */   "Receiver only",
/*   37  */   "Public message",
/*   38  */   "Calling Editor",
/*   39  */   "Save this message in what file? ",
/*   40  */   "Aborted",
/*   41  */   "Message",
/*   42  */   "Saved in",
/*   43  */   "Appended to",
/*   44  */   "No mail in conference",
/*   45  */   "New BBS in this base.",
/*   46  */   "Mail packet older than last base update",
/*   47  */   "Mail not extracted",
/*   48  */   "Unable to remove file",
/*   49  */   "Unable to read file",
/*   50  */   "Unable to create file",
/*   51  */   "Unable to open file",
/*   52  */   "Unable to open configuration file",
/*   53  */   "Reading Configuration file",
/*   54  */   "Error in configuration file",
/*   55  */   "in line",
/*   56  */   "Line",
/*   57  */   "Cleaning",
/*   58  */   "Error Reading file",
/*   59  */   "Quoting message with",
/*   60  */   "More",                      /* This is the 'more' message   */
/*   61  */   "Y/N",                       /* This is the 'yes/no' message */
/*   62  */   "File",                      /* '.. the file..." */
/*   63  */   "Already exists",
/*   64  */   "Delete it ?",
/*   65  */   "Packing Replies in",
/*   66  */   "Last Read pointer updated",
/*   67  */   "No file",
/*   68  */   "Hey !",
/*   69  */   "There is no BBS loaded !",
/*   70  */   "Use 'review' 'load' or 'help' command",
/*   71  */   "Adding messages and creating Indexes",
/*   72  */   "Message too long, sorry...",
/*   73  */   "Error writing file",
/*   74  */   "Error writing index file",
/*   75  */   "Saving message",
/*   76  */   "Adding message to file",
/*   77  */   "Creating file",
/*   78  */   "Conferences available on",
/*   79  */   "Inactive",
/*   80  */   "Active",
/*   81  */   "Number out of range !",
/*   82  */   "Valid messages are",
/*   83  */   "to",
/*   84  */   "Ansi output",
/*   85  */   "on",
/*   86  */   "off",
/*   87  */   "Usage :",
/*   88  */   "load bbs_name",
/*   89  */   "review bbs_name",
/*   90  */   "Conference_Number",
/*   91  */   "or",
/*   92  */   "Conference_Name",
/*   93  */   "type 'conf' to list active conferences",
/*   94  */   "setvbuf() failed in function ",
/*   95  */   "Unauthorized Command !\n",
/*   96  */   " ",  /* Dear, */
/*   97  */   "  In a message on",
/*   98  */   "wrote",
/*   99  */   "you wrote to me",
/*  100  */   "to",
/*  101  */   "Automatic Header",
/*  102  */   "Selective erasing of conference archives",
/*  103  */   "Personal Mail",
/*  104  */   "Reply Mail",
/*  105  */   "KILLED MESSAGE",
/*  106  */   "[Y/n]",
/*  107  */   "[y/N]"
};

const char *hlp[] =
{
 /*    0  */   "",
#ifdef UNIXCMDS  
/*     1  */   " Some of the ATP commands ( type 'man atp' for indepth help ):",
#else /* non unix */
/*     1  */   " Some of the ATP commands ( read atp.doc for indepth help ):",
#endif
 /*    2  */   " Quit program"                                         ,
 /*    3  */   " Kill a reply"                                         ,
 /*    4  */   " System Command"                                       ,
 /*    5  */   " Read Next message"                                    ,
 /*    6  */   " Read Previous message"                                ,
 /*    7  */   " Read Again current message"                           ,
 /*    8  */   " Enter a message in current conference"                ,
 /*    9  */   " Join a conference ( by name or by number )"           ,
 /*   10  */   " Toggle ansi / tty output"                             ,
 /*   11  */   " Join Next conference"                                 ,
 /*   12  */   " Reply to current message"                             ,
 /*   13  */   " [ file ] Save message in text file"                   ,
 /*   14  */   " List Conferences"                                     ,
 /*   15  */   " Selectively delete conference message archives"       ,
 /*   16  */   " Load new mail from QWK packet into message base"      ,
 /*   17  */   " Read mail in the base  ( `rev' is the short form ) "  ,
 /*   18  */   " List new files  (`welcome' & `news' also valid )"     , 
 /*   19  */   " Display tagline help menu"                            ,
 /*   20  */   " Display last news"                                    ,
 /*   21  */   " First Screen of the BBS."                             ,
 /*   22  */   " Toggle Automatic Reply Header on / off"               ,
 /*   23  */   " List QWK packets in mail spool directory"             ,
 /*   24  */   " Scan headers forward from current message"            ,
 /*   25  */   " Find text 'foobar'" 
 
 };

const char *taghlp[] =
{
 /*    0  */   "",
 /*    1  */   " Tagline Commands for ATP tagline manager: ", 
 /*    2  */   "display list of taglines",
 /*    3  */   "display current tagline",
 /*    4  */   "select numbered tagline from list",
 /*    5  */   "select a random tagline",
 /*    6  */   "swap between volatile and persistent tagline",
 /*    7  */   "toggle auto tagline selection ON/OFF",
 /*    8  */   "when followed by sentence, defines volatile tagline",
 /*    9  */   "displays this menu",
 /*   10  */   "toggle Fidonet style tagline ON/OFF"
};

const char *Months[] =
{
        "January", "February", "March", "April" ,"May", "June", "July",
        "August"  , "September", "October",  "November" , "December"
};

#endif  /* ENGLISH */

void Title(void)
{
  white(); high();
printf("\n\n\n");
#define grON    "\016"
#define grOFF   "\017"
#define grX1     grON "x" 
#define grX2     grON "x"  grOFF
#define grX3     grON "xaa" grOFF
#define grBGN1 "\t   " grX1
#define grBGN2 "\t   " grX2
#define grEND1 grX1  "\n"
#define grEND2 grX3  "\n"

if(graphics){
printf("\t   \016lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk\017\n");
printf(grBGN1 "   lqqqqqqqk  lqqqqqqqk  lqqqqqqqk   \017Ver." ATPVER "  " grEND1 );
printf(grBGN1 "   x lqqqk xa mqqk lqqja x lqqqk xa              " grEND1 ); 
printf(grBGN1 "   x xa  x xa  aax xaaaa x xa  x xa              " grEND2 ); 
printf(grBGN1 "   x mqqqj xa    x xa    x mqqqj xa              " grEND2 );
printf(grBGN1 "   x lqqqk xa    x xa    x lqqqqqja              " grEND2 );
printf(grBGN1 "   x xaaax xa    x xa    x xaaaaaaa              " grEND2 ); 
printf(grBGN1 "   mqja  mqja    mqja    mqja                    " grEND2 );
printf(grBGN1 "     aa    aa      aa      aa \017QWK PACKET READER  " grEND2 );
printf(grBGN2 "                                                 " grEND2 );
printf(grBGN2 "                                                 " grEND2 );
printf(grBGN2 "   Copyright 1992, 1993 (c) Thomas McWilliams    " grEND2 ); 
printf(grBGN2 "                                                 " grEND2 ); 
printf(grBGN2 "   Free Software subject to terms of Free Soft-  " grEND2 ); 
printf(grBGN2 "   ware Foundation GNU General Public License.   " grEND2 ); 
printf(grBGN2 "   ABSOLUTELY NO WARRANTY,  type `show terms'    " grEND2 ); 
printf("\t   \016mqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqjaa\017\n");
printf("\t   \016   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\017\n");

}else if(charset) { /* latin1 or 7bit character set without vt100 graphics */

printf("\t   +-------------------------------------------------+\n");
printf("\t   |    ======    =========   ========    Ver." ATPVER  " |\n");
printf("\t   |   ===  ===   =========   ==     ==              |\n"); 
printf("\t   |   ==    ==      ===      ==     ==              |\n"); 
printf("\t   |   ========      ===      ========               |\n");
printf("\t   |   ==    ==      ===      ==                     |\n");
printf("\t   |   ==    ==      ===      ==                     |\n");       
printf("\t   |   ==    ==      ===      ==  QWK PACKET READER  |\n");
printf("\t   |                                                 |\n");
printf("\t   |                                                 |\n");
printf("\t   |   Copyright 1992, 1993 (c) Thomas McWilliams    |\n"); 
printf("\t   |                                                 |\n"); 
printf("\t   |   Free Software subject to terms of Free Soft-  |\n"); 
printf("\t   |   ware Foundation GNU General Public License.   |\n"); 
printf("\t   |   ABSOLUTELY NO WARRANTY,  type `show terms'    |\n"); 
printf("\t   +-------------------------------------------------+\n\n");
} else {  /* msdos character set */
printf("\t   �������������������������������������������������Ŀ\n");
printf("\t   �   �������Ŀ  �������Ŀ  �������Ŀ    Ver." ATPVER  " �\n");
printf("\t   �   � ���Ŀ �� ��Ŀ ���ٱ � ���Ŀ ��              �\n");
printf("\t   �   � ��  � ��  ��� ����� � ��  � ��              ���\n");
printf("\t   �   � ����� ��    � ��    � ����� ��              ���\n");
printf("\t   �   � ����  ��    � ��    � ������ٱ              ���\n");
printf("\t   �   � ����� ��    � ��    � ��������              ���\n");
printf("\t   �   ��ٱ  ��ٱ    ��ٱ    ��ٱ                    ���\n");
printf("\t   �     ��    ��      ��      ��  QWK PACKET READER ���\n");
printf("\t   �                                                 ���\n");
printf("\t   �                                                 ���\n");
printf("\t   �   Copyright 1992, 1993 (c) Thomas McWilliams    ���\n");
printf("\t   �                                                 ���\n");
printf("\t   �   Free Software subject to terms of Free Soft-  ���\n");
printf("\t   �   ware Foundation GNU General Public License.   ���\n");
printf("\t   �   ABSOLUTELY NO WARRANTY,  type `show terms'    ���\n");
printf("\t   ��������������������������������������������������ٱ�\n");
printf("\t      ��������������������������������������������������\n");
}
  clear();
}



/*=========================================================================*
 *                                                                         *
 *       FFFFFFF  RRRRRR   EEEEEEE  NN   NN   CCCCC   HH   HH              *
 *       FF       RR   RR  EE       NNN  NN  CC   CC  HH   HH              *
 *       FFFF     RR   RR  EEEE     NNNN NN  CC       HHHHHHH              *
 *       FF       RRRRRR   EE       NN NNNN  CC       HH   HH              *
 *       FF       RR  RR   EE       NN  NNN  CC   CC  HH   HH              *
 *       FF       RR   RR  EEEEEEE  NN   NN   CCCCC   HH   HH              *
 *                                                                         *
 *=========================================================================*/

#ifdef FRENCH

#ifdef LATIN1    /* use ISO high ASCII characters */

const char *txt[]=
{
/*    0  */   "Ren� Cougnenc 1990"   ,
/*    1  */   "Allocation m�moire refus�e !"  ,
/*    2  */   "Attention !",
/*    3  */   "Vous avez des r�ponses pour",
/*    4  */   "Les compacter ?",
/*    5  */   "Chargement de",
/*    6  */   "Pas de courrier trouv�",
/*    7  */   "Essayez la commande 'revois'...",
/*    8  */   "D�compactage des messages...",
/*    9  */   "vide",
/*   10  */   "Reader",                              /* 1st default prompt */
/*   11  */   "Le 'Nouveau' paquet semble plus vieux que la derni�re mis� � jour",
/*   12  */   "Voulez-vous vraiment rajouter les messages",
/*   13  */   "Pas de BBS trouv�",
/*   14  */   "Erreur dans CONTROL.DAT.",
/*   15  */   "Premier message !",
/*   16  */   "Seek Error",
/*   17  */   "Plus de messages ici.",
/*   18  */   "Erreur de lecture",

/*   19  */   "Auteur: ",          /* This is the message header.        */
/*   20  */   " Pour : ",          /* Fields must be correctly aligned ! */
/*   21  */   "Sujet : ",
/*   22  */   " Date : ",
/*   23  */   "Num�ro : ",
/*   24  */   "R�f.N� : ",
/*   25  */   "  Conf : ",
/*   26  */   " Heure : ",
/*   27  */   "MESSAGE  PRIVE",
/*   28  */   "Conf�rence inconnue...",
/*   29  */   "Conf�rence",
/*   30  */   "rejointe",
/*   31  */   "Pas de nouveaux messages",
/*   32  */   "Entrez 'n' pour abandonner la saisie de ce message.",
/*   33  */   "Message abandonn�",
/*   34  */   "Entr�e trop longue !  25 caract�res max.",
/*   35  */   "Trop long !  R = Receceveur seul, N = message public.",
/*   36  */   "Message PRIVE",
/*   37  */   "Message Public",
/*   38  */   "Appel de l'�diteur",
/*   39  */   "Sauver ce message dans le fichier : ",
/*   40  */   "Abandon",
/*   41  */   "Message",
/*   42  */   "Sauv� dans",
/*   43  */   "Rajout� �",
/*   44  */   "pas de message dans la conf�rence",
/*   45  */   "Nouveau BBS dans cette base.",
/*   46  */   "Paquet QWK plus ancien que la derni�re mise � jour",
/*   47  */   "Courrier non trait�",
/*   48  */   "Impossible de supprimer le fichier",
/*   49  */   "Impossible de lire le fichier",
/*   50  */   "Impossible de cr�er le fichier",
/*   51  */   "Impossible d'ouvrir le fichier",
/*   52  */   "Impossible d'ouvrir le fichier de configuration",
/*   53  */   "Lecture du fichier de configuration",
/*   54  */   "Error dans le fichier de configuration",
/*   55  */   "� la ligne",
/*   56  */   "Ligne",
/*   57  */   "Nettoyage de",
/*   58  */   "Erreur de lecture sur le fichier",
/*   59  */   "Annotation du message avec",
/*   60  */   "Encore",                      /* This is the 'more' message   */
/*   61  */   "O/N",                       /* This is the 'yes/no' message */
/*   62  */   "Le fichier",                      /* '.. the file..." */
/*   63  */   "existe d�j�",
/*   64  */   "Le supprimer ?",
/*   65  */   "Compactage des r�ponses dans",
/*   66  */   "Pointeur de lecture mis � jour",
/*   67  */   "Pas de fichier",
/*   68  */   "Hola !",
/*   69  */   "Il n'y a pas de BBS charg� !",
/*   70  */   "Utilisez les commandes 'revois' 'load' ou 'aide'",
/*   71  */   "Ajout des messages � la base et cr�ation des index",
/*   72  */   "D�sol�, il y a un message trop gros...",
/*   73  */   "Erreur en �criture du fichier",
/*   74  */   "Error d'�criture du fichier index",
/*   75  */   "Sauvegarde du message",
/*   76  */   "Ajout du message au fichier",
/*   77  */   "Cr�ation du fichier",

/*   78  */   "Liste des conf�rences sur",
/*   79  */   "Inactive",
/*   80  */   "Active",

/*   81  */   "Nombre hors limites !",
/*   82  */   "Les messages valides vont de",
/*   83  */   "�",

/*   84  */   "Mode Ansi",
/*   85  */   "en service",
/*   86  */   "hors service",

/*   87  */   "Syntaxe :",
/*   88  */   "load nom_du_serveur",
/*   89  */   "revois nom_du_serveur",
/*   90  */   "Num�ro_de_conf�rence",
/*   91  */   "ou",
/*   92  */   "Nom_de_conf�rence",
/*   93  */   "tapez 'conf' pour la liste des conf�rences",

/*   94  */   "setvbuf() refus� dans fonction ",
/*   95  */   "Commande Interdite !\n"
              "Vous devez compiler vous-m�me le programme pour cela !\n",

/*   96  */   "Cher",
/*   97  */   "Dans un message du",
/*   98  */   "vous �crivez",
/*   99  */   "vous m'�crivez",
/*  100  */   "destin� �",
/*  101  */   "En-t�te automatique",
/*  102  */   "Effacement s�lectif des conf�rences", 
/*  103  */   "Personnel" ,
/*  104  */   "R�ponses",
/*  105  */   "MESSAGE TUE",
/*  106  */   "[O/n]",
/*  107  */   "[o/N]"
};

const char *hlp[] =
{
 /*    0  */   "",
 /*    1  */   "Commandes disponibles :"                              ,
 /*    2  */   "Quitter le programme, retour au syst�me"              ,
 /*    3  */   "Tuer une r�ponse"                                     ,
 /*    4  */   "Commande syst�me"                                     ,
 /*    5  */   "Lecture du message suivant"                           ,
 /*    6  */   "Lecture du message pr�c�dant"                         ,
 /*    7  */   "R�affichage du message courant"                       ,
 /*    8  */   "Entrer un message dans la conf�rence courante"        ,
 /*    9  */   "Rejoindre une conf�rence. ( par nom ou par num�ro )"  ,
 /*   10  */   "Bascule affichage Ansi-Couleur / tty - monochrome"    ,
 /*   11  */   "Rejoindre la conf�rence suivante"                     ,
 /*   12  */   "R�pondre au message courant"                          ,
 /*   13  */   "[ fichier ] Sauver message dans fichier (mode append)",
 /*   14  */   "Liste des conf�rences disponibles"                    ,
 /*   15  */   "Effacement de(s) conf�rence(s)"                       ,
 /*   16  */   "Charge le nouveau courrier d'un serveur"              ,
 /*   17  */   "Lire le mail d'un serveur dans la base"               ,
 /*   18  */   "Nouveaux fichiers pour cette session"                 ,
 /*   19  */   "Remet la signature normale. (tag ?  = aide)"          ,
 /*   20  */   "Affiche les derni�res nouvelles s'il y en a..."       ,
 /*   21  */   "Affiche le logo du serveur"                           ,
 /*   22  */   "En-t�te de lettre automatique oui / non"              ,
 /*   23  */   "Liste des paquets QWK "                               ,
 /*   24  */   "Scruter les en-t�tes des messages"                    ,
 /*   25  */   "Chercher le mot 'foobar' "
 
 };

const char *taghlp[] =
{
 /*    0  */   "display list of taglines",
 /*    1  */   "display current tagline",
 /*    3  */   "select numbered tagline from list",
 /*    2  */   "select a random tagline",
 /*    4  */   "swap between volatile and persistent tagline",
 /*    5  */   "toggle auto tagline selection ON/OFF",
 /*    6  */   "when followed by any other text, defines volatile tagline",
 /*    7  */   "displays this menu"
};

const char *Months[] =
{
        "Janvier", "F�vrier", "Mars", "Avril" ,"Mai", "Juin", "Juillet",
        "Ao�t"  , "Septembre", "Octobre",  "Novembre" , "Decembre"
};


#else     /* DOS charcter set. */

const char *txt[]=
{
/*    0  */   "Ren� Cougnenc 1990"   ,
/*    1  */   "Allocation m�moire refus�e !"  ,
/*    2  */   "Attention !",
/*    3  */   "Vous avez des r�ponses pour",
/*    4  */   "Les compacter ?",
/*    5  */   "Chargement de",
/*    6  */   "Pas de courrier trouv�",
/*    7  */   "Essayez la commande 'revois'...",
/*    8  */   "D�compactage des messages...",
/*    9  */   "vide",
/*   10  */   "Reader",                              /* 1st default prompt */
/*   11  */   "Le 'Nouveau' paquet semble plus vieux que la derni�re mis� � jour",
/*   12  */   "Voulez-vous vraiment rajouter les messages",
/*   13  */   "Pas de BBS trouv�",
/*   14  */   "Erreur dans CONTROL.DAT.",
/*   15  */   "Premier message !",
/*   16  */   "Seek Error",
/*   17  */   "Plus de messages ici.",
/*   18  */   "Erreur de lecture",

/*   19  */   "Auteur: ",          /* This is the message header.        */
/*   20  */   " Pour : ",          /* Fields must be correctly aligned ! */
/*   21  */   "Sujet : ",
/*   22  */   " Date : ",
/*   23  */   "Num�ro : ",
/*   24  */   "R�f.N� : ",
/*   25  */   "  Conf : ",
/*   26  */   " Heure : ",
/*   27  */   "MESSAGE  PRIVE",
/*   28  */   "Conf�rence inconnue...",
/*   29  */   "Conf�rence",
/*   30  */   "rejointe",
/*   31  */   "Pas de nouveaux messages",
/*   32  */   "Entrez 'n' pour abandonner la saisie de ce message.",
/*   33  */   "Message abandonn�",
/*   34  */   "Entr�e trop longue !  25 caract�res max.",
/*   35  */   "Trop long !  R = Receceveur seul, N = message public.",
/*   36  */   "Message PRIVE",
/*   37  */   "Message Public",
/*   38  */   "Appel de l'�diteur",
/*   39  */   "Sauver ce message dans le fichier : ",
/*   40  */   "Abandon",
/*   41  */   "Message",
/*   42  */   "Sauv� dans",
/*   43  */   "Rajout� �",
/*   44  */   "pas de message dans la conf�rence",
/*   45  */   "Nouveau BBS dans cette base.",
/*   46  */   "Paquet QWK plus ancien que la derni�re mise � jour",
/*   47  */   "Courrier non trait�",
/*   48  */   "Impossible de supprimer le fichier",
/*   49  */   "Impossible de lire le fichier",
/*   50  */   "Impossible de cr�er le fichier",
/*   51  */   "Impossible d'ouvrir le fichier",
/*   52  */   "Impossible d'ouvrir le fichier de configuration",
/*   53  */   "Lecture du fichier de configuration",
/*   54  */   "Error dans le fichier de configuration",
/*   55  */   "� la ligne",
/*   56  */   "Ligne",
/*   57  */   "Nettoyage de",
/*   58  */   "Erreur de lecture sur le fichier",
/*   59  */   "Annotation du message avec",
/*   60  */   "Encore",                      /* This is the 'more' message   */
/*   61  */   "O/N",                       /* This is the 'yes/no' message */
/*   62  */   "Le fichier",                      /* '.. the file..." */
/*   63  */   "existe d�j�",
/*   64  */   "Le supprimer ?",
/*   65  */   "Compactage des r�ponses dans",
/*   66  */   "Pointeur de lecture mis � jour",
/*   67  */   "Pas de fichier",
/*   68  */   "Hola !",
/*   69  */   "Il n'y a pas de BBS charg� !",
/*   70  */   "Utilisez les commandes 'revois' 'load' ou 'aide'",
/*   71  */   "Ajout des messages � la base et cr�ation des index",
/*   72  */   "D�sol�, il y a un message trop gros...",
/*   73  */   "Erreur en �criture du fichier",
/*   74  */   "Error d'�criture du fichier index",
/*   75  */   "Sauvegarde du message",
/*   76  */   "Ajout du message au fichier",
/*   77  */   "Cr�ation du fichier",

/*   78  */   "Liste des conf�rences sur",
/*   79  */   "Inactive",
/*   80  */   "Active",

/*   81  */   "Nombre hors limites !",
/*   82  */   "Les messages valides vont de",
/*   83  */   "�",

/*   84  */   "Mode Ansi",
/*   85  */   "en service",
/*   86  */   "hors service",

/*   87  */   "Syntaxe :",
/*   88  */   "load nom_du_serveur",
/*   89  */   "revois nom_du_serveur",
/*   90  */   "Num�ro_de_conf�rence",
/*   91  */   "ou",
/*   92  */   "Nom_de_conf�rence",
/*   93  */   "tapez 'conf' pour la liste des conf�rences",

/*   94  */   "setvbuf() refus� dans fonction ",
/*   95  */   "Commande Interdite !\n"
              "Vous devez compiler vous-m�me le programme pour cela !\n",

/*   96  */   "Cher",
/*   97  */   "Dans un message du",
/*   98  */   "vous �crivez",
/*   99  */   "vous m'�crivez",
/*  100  */   "destin� �",
/*  101  */   "En-t�te automatique",
/*  102  */   "Effacement s�lectif des conf�rences", 
/*  103  */   "Personnel" ,
/*  104  */   "R�ponses",
/*  105  */   "MESSAGE TUE",
/*  106  */   "[O/n]",
/*  107  */   "[o/N]"
};

const char *hlp[] =
{
 /*    0  */   "",
 /*    1  */   "Commandes disponibles :"                              ,
 /*    2  */   "Quitter le programme, retour au syst�me"              ,
 /*    3  */   "Tuer une r�ponse"                                     ,
 /*    4  */   "Commande syst�me"                                     ,
 /*    5  */   "Lecture du message suivant"                           ,
 /*    6  */   "Lecture du message pr�c�dant"                         ,
 /*    7  */   "R�affichage du message courant"                       ,
 /*    8  */   "Entrer un message dans la conf�rence courante"        ,
 /*    9  */   "Rejoindre une conf�rence. ( par nom ou par num�ro )"  ,
 /*   10  */   "Bascule affichage Ansi-Couleur / tty - monochrome"    ,
 /*   11  */   "Rejoindre la conf�rence suivante"                     ,
 /*   12  */   "R�pondre au message courant"                          ,
 /*   13  */   "[ fichier ] Sauver message dans fichier (mode append)",
 /*   14  */   "Liste des conf�rences disponibles"                    ,
 /*   15  */   "Effacement de(s) conf�rence(s)"                       ,
 /*   16  */   "Charge le nouveau courrier d'un serveur"              ,
 /*   17  */   "Lire le mail d'un serveur dans la base"               ,
 /*   18  */   "Nouveaux fichiers pour cette session"                 ,
 /*   19  */   "Remet la signature normale. (tag ?  = aide)"          ,
 /*   20  */   "Affiche les derni�res nouvelles s'il y en a..."       ,
 /*   21  */   "Affiche le logo du serveur"                           ,
 /*   22  */   "En-t�te de lettre automatique oui / non"             ,
 /*   23  */   "Liste des QWK paquets QWK"                              ,
 /*   24  */   "Scruter les en-t�tes des messages",
 /*   25  */   "Chercher le mot 'foobar' "
 
 };

const char *taghlp[] =
{
 /*    0  */   "display list of taglines",
 /*    1  */   "display current tagline",
 /*    3  */   "select numbered tagline from list",
 /*    2  */   "select a random tagline",
 /*    4  */   "swap between volatile and persistent tagline",
 /*    5  */   "toggle auto tagline selection ON/OFF",
 /*    6  */   "when followed by any other text, defines volatile tagline",
 /*    7  */   "displays this menu"
} ;

const char *Months[] =
{
        "Janvier", "F�vrier", "Mars", "Avril" ,"Mai", "Juin", "Juillet",
        "Ao�t"  , "Septembre", "Octobre",  "Novembre" , "Decembre"
};

#endif  /* ISO LATIN1 */

#endif    /* FRENCH */ 
