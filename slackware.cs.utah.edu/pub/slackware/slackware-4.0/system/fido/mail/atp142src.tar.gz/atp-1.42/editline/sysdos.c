/*  $Revision: 1.1.1.1 $
**
**  MS-DOS system-dependant routines for editline library.
*/
#include "editline.h"

void
rl_ttyset(Reset)
    int				Reset;
{
}
;

void
rl_add_slash(path, p)
    char	*path;
    char	*p;
{
    struct stat	Sb;

    if (stat (path, &Sb) >= 0 )
    (void)strcat( p, S_ISDIR (Sb.st_mode) ? SEPST : " ");
}
