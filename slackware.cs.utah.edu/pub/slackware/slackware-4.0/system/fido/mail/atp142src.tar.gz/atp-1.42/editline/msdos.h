/*  $Revision: 1.2 $
**
**  Editline system header file for MSDOS 
*/

#ifndef __STDC__
#ifdef __BORLANDC__
#define __STDC__
#endif
#endif

#define CRLF		"\r\n"
#define FORWARD		STATIC

#include <sys/types.h>
#include <sys/stat.h>

#if	defined(USE_DIRENT)
#include <dirent.h>
typedef struct dirent	DIRENTRY;
#elif defined(WIN32)
#define FINDFIRST
#include <direct.h>
typedef struct _finddata DIRENTRY;
#else
#include <dir.h>
typedef struct ffblk DIRENTRY;
#endif	/* defined(USE_DIRENT) */

#if defined(__TURBOC__) && defined(__STDC__)
char *strdup( const char *s );
char *strlwr( const char *s );
#endif

#if	!defined(S_ISDIR)
#define S_ISDIR(m)		(((m) & S_IFMT) == S_IFDIR)
#endif	/* !defined(S_ISDIR) */

#ifdef BADLWR 
#ifdef tolower
#undef tolower
#undef toupper
#endif
#define tolower(x) (((x)>0x40)&&((x)<0x5b)?((x)|0x20):(x))
#define toupper(x) (((x)>0x60)&&((x)<0x7b)?((x)&0xdf):(x))
#endif
