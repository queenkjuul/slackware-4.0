/*
     ATP QWK MAIL READER FOR READING AND REPLYING TO QWK MAIL PACKETS.
     Copyright (C) 1992  Thomas McWilliams 
     Copyright (C) 1990  Rene Cougnenc
   
     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 1, or (at your option)
     any later version.
     
     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
     
     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

/*
ansi.h
*/

extern  int  ansi ;
extern  int  color ;
extern  void cls(void );
extern  void deleol(void );
extern  void clear(void );
extern  void high(void );
extern  void blink(void );
extern  void reverse(void );
extern  void black(void );
extern  void red(void );
extern  void green(void );
extern  void yellow(void );
extern  void blue(void );
extern  void magenta(void );
extern  void cyan(void );
extern  void white(void );
extern  void bblack(void );
extern  void bred(void );
extern  void bgreen(void );
extern  void byellow(void );
extern  void bblue(void );
extern  void bmagenta(void );
extern  void bcyan(void );
extern  void bwhite(void );
extern  void locate(int x,int y);
extern  void up(int nb);
extern  void dn(int nb);
extern  void right(int nb);
extern  void left(int nb);
/*---------------------- end of ansi.h -----------------------------------*/
