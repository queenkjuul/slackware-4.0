#ifndef MAIN_H
#define MAIN_H

#define _(String) (String)
#define N_(String) (String)
#define textdomain(Domain)
#define bindtextdomain(Package, Directory)

#define FALSE 0
#define TRUE 1

/* set plain output or not 
   if it is TRUE a plain output is made...
   this could help someone making a front-end for plor
   (we hope so)
   */

extern int plain;
extern int Last_Mesg;
extern int Curr_Mesg;
extern int Curr_Conf;
extern int Last_Conf;

extern int ROWS;
extern int COLS;

extern void startup_msg();
extern void init_plor();

#endif
