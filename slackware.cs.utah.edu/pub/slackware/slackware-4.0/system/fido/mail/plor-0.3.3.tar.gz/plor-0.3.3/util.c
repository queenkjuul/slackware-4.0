/*
 * souputil.c (C) 1996 1997 by Davide Barbieri
 * some functions used by soupread.c
 * THIS IS FREE SOFTWARE
 * see file COPYING for more information on copyright policy
 */

#include <stdio.h>
#include <string.h>

#include "main.h"
#include "util.h"


/* delete Carriage Return character 
   that seems to be present in every qwk packet */
void del_CR(char *ptr)
{
	while (*ptr != '\r') ptr++;
	*ptr = '\0';
	}

/* simply function that return the size
   of a specified file */
unsigned long file_size(FILE *f)
{
  unsigned long temp;
  fseek(f,0,SEEK_END);
  temp=ftell(f);
  fseek(f,0,SEEK_SET);
  return temp;
}


void read_line(char* line)
{
  int i=0;
  int ch=33;

  for(;;) {
    ch=getchar();
   
    if (ch<=33 || ch>=126 || ch==63 || ch==42) break;

    line[i]=ch; i++;
    printf("%c",ch);
    
  }

  line[i]='\0';
}



