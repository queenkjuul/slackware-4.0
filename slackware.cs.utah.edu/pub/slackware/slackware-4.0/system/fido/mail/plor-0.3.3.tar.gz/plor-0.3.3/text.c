#include "pconfig.h"

#ifdef ITA
#include "lang/text-ita.c"
#endif
#ifdef ENG
#include "lang/text-eng.c"
#endif
