#ifndef TEXTENG_C
#define	TEXTENG_C

/* english string to be used in plor */

char *win_msg[]={
	"PLOR Pluto Linux Offline Reader v. 0.2Alpha",
	"News Reader",
	"Mail Reader",
	"Replies"
	};

char *main_menu[]={
	"Read qwk packet",
	"Read soup packet",
	"Help On-Line",			/* non ancora aggiunto */
	"Replies",
	"Exit"
	};

char *qwk_msg[]={
	"QWK Conference Selector",
	"QWK Message Selector"
	};

char *soup_msg[]={
	"SOUP Conference Selector",
	"SOUP Message Selector"
	};

char *err_msg[]={
	"ERROR: cannot initialize slang\n",
	"ERROR: cannot write file",
	"ERROR: cannot read file"
	};

#endif	/* TEXTENG_C */






