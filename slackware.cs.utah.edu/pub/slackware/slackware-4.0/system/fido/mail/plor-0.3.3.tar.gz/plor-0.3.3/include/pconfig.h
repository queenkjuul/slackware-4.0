#ifndef CONFIG_H
#define CONFIG_H

#define VERSION "0.3.3Alpha by paci"
#define PROGNAME "Prosa Linux Offline Reader"

#define COMPRESS   "zip"
#define UNCOMPRESS "unzip"
#define EDITOR     "vi"
#define PAGER      "less"

#define QUOTE      ">"

/* define language to use in plor; choose from:
 *
 * ITA -> italian
 * ENG -> english
 */

#define ENG

/* define color-video */

#define color 1
#define Plor_Color 0 
#define Reverse_Plor_Color 12

#endif /* CONFIG_H */
