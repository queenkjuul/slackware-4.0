#ifndef TEXTITA_C
#define TEXTITA_C

/* mettiamo qua tutte le stringhe in italiano usate dal programma plor */

const char *win_msg[]={
	"PLOR Pluto Linux Offline Reader v. 0.0.1Alpha",
	"Lettore di News",
	"Lettore di Mail",
	"Risposte"
	};

const char *main_menu[]={
	"Leggi pacchetto qwk",
	"Leggi pacchetto soup",
	"Scrivi o rispondi",
	"Aiuto in linea",			/* non ancora aggiunto */
	"Esci"
	};

const char *qwk_msg[]={
	"Selettore di conferenze in formato qwk",
	"Selettore di messaggi in formato qwk"
	};

const char *soup_msg[]={
	"Selettore di conferenze in formato SOUP",
	"Selettore di messaggi in formato SOUP"
	};

const char *err_msg[]={
	"ERRORE: non posso inizializzare le slang\n",
	"ERRORE: non posso scrivere il file",
	"ERRORE: non riesco a leggere il file"
	};

#endif /* TEXTITA_C */
