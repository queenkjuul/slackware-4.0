/* 
 * soupread.h 
 * (C) 1996 by Davide Barbieri & Zeno Michielon
 * THIS IS FREE SOFTWARE 
 */
#ifndef SOUPREAD_H
#define SOUPREAD_H

/* up to 100 conferences */
char *files[100];
char *area_name[100];
char *encoding[100];

/*
char *files[];
char **area_name;
char **encoding;
*/
/* this is a struct to save message information: line & subj */
typedef struct msg{
  int line;           /* in which line it is     */
  char from[18];      /* who write the message   */
  char *email;        /* his email address       */
  char subj[60];      /* the subj of the message */
  char id[255];       /* to make References:     */
  /*char type;*/          /* message type u,b,M,etc  */
} msg;

/* per ora non gestiamo piu` di 1000 messaggi per conferenza
   anche questo verra` allocato dinamicamente in futuro */
msg mesg_array[1000];  



/***************/
/*  FUNCTIONS  */
/***************/


/* load file AREAS */
void SOUP_load_areas();

/* read data from AREAS */
/*void SOUP_update_areas(char *, long);*/

void SOUP_show_conf_list();
void SOUP_read_conf();
void SOUP_show_conf();
/* read message */
/* int msg (number of-), char type (u,b,M,etc)*/
void SOUP_save_msg(int, int);
void SOUP_read_msg(int);
int SOUP_browser(int );

/* define in soupreply.c */
extern void SOUP_reply(int, char, int);
extern void SOUP_pack_replies();

#endif /* SOUPREAD_H */

