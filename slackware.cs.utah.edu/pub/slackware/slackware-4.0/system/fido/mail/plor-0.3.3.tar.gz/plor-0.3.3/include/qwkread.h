#ifndef QWKREAD_H
#define QWKREAD_H

#define MSG_FILE    "messages.dat" /* Message filename prepared by Qmail */
#define CTRL_FILE   "control.dat"  /* List of conferences by Qmail       */
#define DOORID      "door.id"      /* Info for the BBS QWK door          */
#define NEWFILES    "newfiles.dat" /* List of new files   by Qmail       */
#define WELCOME     "welcome"      /* 1st Screen of te BBS               */
#define NEWS        "news"         /* news file, ascii mode              */
#define TAGFILE     "taglines.atp" /* taglines file                      */
#define PERS_CONF   9000           /* Conference number for personal mail*/
#define REPL_CONF   9001           /* Conference number for replies      */

extern void del_CR(char *);
extern void QWK_load_control();
extern void QWK_read_conf(int);
extern void QWK_show_conf();

#endif
