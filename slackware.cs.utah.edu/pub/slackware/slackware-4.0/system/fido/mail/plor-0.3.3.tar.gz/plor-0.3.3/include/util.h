#ifndef SOUPUTIL_H
#define SOUPUTIL_H
#include <stdio.h>

void del_CR(char*);
unsigned long file_size(FILE *);
void read_line(char* );

#endif
