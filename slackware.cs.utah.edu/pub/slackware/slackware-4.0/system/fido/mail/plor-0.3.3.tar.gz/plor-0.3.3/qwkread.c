/* (C) 1996 by Davide Barbieri & Zeno Michielon */
#include <stdio.h>
#include <stdlib.h>

#include "main.h"
#include "pconfig.h"
#include "qwkread.h"
#include "util.h"
#include "video.h"
#include "text.h"

/* control.dat structure */
char BBS_Name[76];
/*char Board_Name[74];
  char Tel_Number[2]; 
  char Sysop_Name[2];
  char Other_BBS[2]; 
  char Other_Tel_Number[2];*/
char User_Name[256];
int QNum_Conf=0;                        /* number of conferences present */
int QCurr_Conf=0;                       /* actual active conference      */

/* other stuff such as temporary variables */
char *tmp;
int k=0;
int row_tmp;
char chtmp;

void QWK_load_control() 
{
	FILE *fc;
	/* if the file doesn't exist or we can't open it ... */
	if ((fc=fopen(CTRL_FILE,"r"))==NULL){
		printf("%s", err_msg[2]);
		exit(1);
		}
	fgets(BBS_Name, 76, fc); del_CR(BBS_Name);

	/* jumps 5 lines */
	tmp = malloc(256);
	for( ; k<5 ; k++) fgets(tmp, 256, fc); 

	fgets(User_Name, 256, fc); del_CR(User_Name);

	/* jumps 3 lines */
	for(k=0; k<3; k++) fgets(tmp, 256, fc);

	/* gets number of conferences */
	fgets(tmp, 256, fc);
	/* atoi(tmp)+1 because email is not counted in control.dat */
	QNum_Conf = atoi(tmp)+1;
	if (QNum_Conf==0){
		printf("No conferences");
		return;
		}

	/*fgets(tmp, 256, fc);
	QCurr_Conf = atoi(tmp);	*/
	/*row_tmp = (ROWS-(QNum_Conf+3))/2;
	
	row_tmp++;*/
	locate(4,row_tmp);
	printf("Conferences = %i ", QNum_Conf);
	printf("BBS name = %s ", BBS_Name);
	printf("User Name = %s ", User_Name);

	row_tmp++;
	for (k=0; k<QNum_Conf; k++){
		fgets(tmp, 256, fc); del_CR(tmp);
		locate(4,row_tmp+k);
		printf("%i) %s", k+1, tmp);
		fgets(tmp, 256, fc);	
		}	
	
	fclose(fc);
	/* probabilmente in un ambiente multitasking e` meglio chiamare fclose
	dopo refresh(); perche' prima e` necessario aggiornare lo schermo, mentre
	il file verra` chiuso quando vuole il sistema */
	k = getchar();
	/* k is the ascii so the number is k-48 */
	QWK_read_conf(k-48);
	}

void QWK_read_conf(int Which_Conf){
	FILE *fm;
	
	/* if the file doesn't exist or we can't open it ... */
	if ((fm=fopen(MSG_FILE,"r"))==NULL){
		fprintf(stderr, "%s %s\n", err_msg[2], MSG_FILE);
		exit(1);
		}	

	/* scan messages.dat */
	fgets(tmp,256,fm); /* QMail etc etc */

	chtmp = getchar();	
	}

void QWK_show_conf()
{
}





