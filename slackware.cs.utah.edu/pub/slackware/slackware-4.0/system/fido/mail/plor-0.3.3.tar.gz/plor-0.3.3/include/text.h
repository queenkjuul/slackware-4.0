#ifndef TEXT_H
#define TEXT_H

/* messages for main windows */
extern char *win_msg[];

/* messages for main menu */
extern char *main_menu[];

/* message for qwk windows */
extern char *qwk_msg[];

/* messages for soup windows */
extern char *soup_msg[];

/* error messages */
extern char *err_msg[];

#endif /* TEXT_H */
