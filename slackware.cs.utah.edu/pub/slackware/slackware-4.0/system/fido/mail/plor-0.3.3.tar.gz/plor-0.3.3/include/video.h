#ifndef VIDEO_H
#define VIDEO_H

#include "pconfig.h"

#define ESC 27

extern  void cls(void );
extern  void deleol(void );
extern  void clear(void );
extern  void high(void );
extern  void blink(void );
extern  void reverse(void );
extern  void black(void );
extern  void red(void );
extern  void green(void );
extern  void yellow(void );
extern  void blue(void );
extern  void magenta(void );
extern  void cyan(void );
extern  void white(void );
extern  void bblack(void );
extern  void bred(void );
extern  void bgreen(void );
extern  void byellow(void );
extern  void bblue(void );
extern  void bmagenta(void );
extern  void bcyan(void );
extern  void bwhite(void );
extern  int  rows();
extern  int  cols();
extern  void locate(int x,int y);
extern  void up(int nb);
extern  void dn(int nb);
extern  void right(int nb);
extern  void left(int nb);
extern  int  get_ch();
#endif /* VIDEO_H */
