

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

#ifndef _CHARSET_H
#define _CHARSET_H

#define MAXCHRS 2

#define STDCHRS 1

/* this looks like '<<' on my term */
#define HARDCRCHAR 0xab
/* this looks like '>>' on my term */
#define HARDCUTCHAR 0xbb

typedef struct {
  int code;
  char conversion[5];
} ConversionType;

#ifndef _CHARSET
extern const char CHRSETS[MAXCHRS][5][10];
extern const char PRINTABLECHAR[256];
extern const int maxCONVERTCHAR;
extern const ConversionType CONVERTCHAR[8];
extern const unsigned char RE_ICASE_TRANS_MAP[256];
#endif

void transstr (char *s, int Set);
void transback (char *s, int Set);

#endif
