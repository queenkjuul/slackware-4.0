

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

#ifndef _COLORS_H
#define _COLORS_H

#define COL_NormalText					 0
#define COL_QuoteText						 1
#define COL_Header							 2
#define COL_HeaderText					 3
#define COL_ReceivedDT					 4
#define COL_MarkedFlag					 5
#define COL_PrivateFlag					 6
#define COL_ProtectedFlag				 7
#define COL_StatusLine					 8
#define COL_StatusLineHigh			 9
#define COL_Menu								10
#define COL_MenuHigh						11
#define COL_MenuKey							12
#define COL_MenuKeyHigh					13
#define COL_Link								14
#define COL_Warning							15
#define COL_InputText						16
#define COL_FoundText						17
#define COL_LocalMessage				18
#define COL_PrivateMsgList			19
#define COL_PrivateMsgListHigh	20
#define COL_ImportArea					21
#define COL_ImportAreaHigh			22
#define COL_NormalTextHigh			23
#define COL_QuoteTextHigh				24
#define COL_WarningBox					25
#define COL_HelpBox							26
#define COL_FirstQuoteText			27
#define COL_CutOriginText				28
#define COL_FirstQuoteTextHigh	29
#define COL_CutOriginTextHigh		30

#define COL_ItalicText		31
#define COL_BoldText		32
#define COL_UnderlinedText	33

void setFEddiColor (char *s);
void initFEddiColors ();
void wcolon (WINDOW *, int);
void wcoloff (WINDOW *);
void wkill (WINDOW *, int);

#endif
