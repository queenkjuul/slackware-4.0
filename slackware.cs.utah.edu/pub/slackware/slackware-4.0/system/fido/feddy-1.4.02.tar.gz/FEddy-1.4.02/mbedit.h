

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

#ifndef _MBEDIT_H
#define _MBEDIT_H

void deleteMsg ();
void toggleMark (int sh); /* see toggleProtect */
void toggleNew ();
void toggleProtect (int sh); /* sh <> 0 => call showhdr() else not */
void changeFrom ();
void changeTo ();
void changeSubj ();
void changeFlags ();
void exportMsg ();
void printMsg ();
void enterMsg ();
void replyMsg ();
void netreplyMsg ();
void replyDest ();
void netreplyDest ();
void quitFEddi ();
void showKludges ();
void cycleAka ();
void folderInfo ();
void folderOrigin ();
void folderAlias ();
void toggleLink ();
void toggleClearMarks ();
void showtree ();
void changeText ();
void tossit ();
void scanit ();
void packit ();
void linkit ();
void dupeit ();
void nlcompit ();
void deleteThread ();
void toggleReadOnly ();
void crosspost ();
void forward ();
void changeCharset ();
void changeShowAll ();
void requestFiles ();
void requestFilesfromAddr ();
void startSearch ();
void FolderShell ();
void ListShell ();
void redrawScreen ();
void callUtility ();
void chooseOrigin ();

#endif
