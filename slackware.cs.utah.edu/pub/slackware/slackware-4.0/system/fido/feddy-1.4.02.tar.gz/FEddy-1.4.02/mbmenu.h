

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

#ifndef _MBMENU_H
#define _MBMENU_H

#define ARROW_NIL	0
#define ARROW_CLICK	1
#define ARROW_UP	2
#define ARROW_DOWN	4
#define ARROW_RIGHT	8
#define ARROW_LEFT	16

#define UTILITY_MENU_PLACE 4

typedef struct {
  int entries;
  int width;
  int xpos;
  char name[8];
  char entry[15][24];
  int pos[15];
  void (*funct[15]) ();
} MenuType;

extern MenuType Menu[];
extern int curMenpos, maxMen;

void initmenu ();
void menukey (int);
int menuarrow (int);
void killmenu ();

#endif
