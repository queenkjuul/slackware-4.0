

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

#ifndef _FLAGS_H
#define _FLAGS_H

static char NAMEFLAG[16][3] =
{
  "pr", "cr", "rc", "se", "fa", "it", "or", "ks",
  "lo", "hp", "--", "fr", "rr", "ir", "ar", "fu"
};
#define A_PRIVATE            1
#define A_CRASH              2
#define A_RECIEVED           4
#define A_SEND               8
#define A_FILEATTACHED      16
#define A_INTRANSIT         32
#define A_ORPHAN            64
#define A_KILLSENT         128
#define A_LOCAL            256
#define A_HOLD             512
#define A_UNUSED          1024
#define A_FILEREQUEST     2048
#define A_RERECEIPT       4096
#define A_ISRECEIPT       8192
#define A_AUDITREQUEST   16384
#define A_FULLUPDREQ     32768

#define A_LOCAL_SEND   (A_LOCAL | A_SEND)

#define BIT_PRIVATE          0
#define BIT_CRASH            1
#define BIT_RECIEVED         2
#define BIT_SENT             3
#define BIT_FILEATTACHED     4
#define BIT_INTRANSIT        5
#define BIT_ORPHAN           6
#define BIT_KILLSENT         7
#define BIT_LOCAL            8
#define BIT_HOLD             9
#define BIT_UNUSED          10
#define BIT_FILEREQUEST     11
#define BIT_RERECEIPT       12
#define BIT_ISRECEIPT       13
#define BIT_AUDITREQUEST    14
#define BIT_FULLUPDREQ      15


#endif
