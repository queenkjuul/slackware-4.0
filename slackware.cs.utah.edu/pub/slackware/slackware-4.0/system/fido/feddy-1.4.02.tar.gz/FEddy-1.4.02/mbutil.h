

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

#ifndef _MBUTIL_H
#define _MBUTIL_H

typedef struct {
  char *Name;
  char *Description;
  char *CommandLine;
  char Key;
  int MetaKey:1;
  int NeedsText:1;
  int NeedsHeader:1;
  int NeedsKludges:1;
  int NeedsScreen:1;
  int NeedsMsgBase:1;
  int NeedsArea:1;
  int TakesMany:1;
  int NeedsFromArea:1;
} UtilityType;

#define UtilitySize sizeof(UtilityType)

#ifndef _MBUTIL_C
extern int numUtility;
extern UtilityType *Utility;
#endif

void initutils ();
int chooseUtility ();
int execUtility (int);
void execMenuUtility ();

#endif
