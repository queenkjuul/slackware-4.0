

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

#include "crash.h"



void crash_handler (int sig)
{
  FILE *deadfile;
  int i = 0;

  if ((deadfile = fopen ("msg.FEddy", "w")) == NULL)
    Log ("*Can't open crash recovery file!");
  else {
    Log ("*FEddy trying crash recovery");
    fprintf (deadfile, "===========================================================================\n");
    fprintf (deadfile, " FEddy-Crash recovery result: \n");
    fprintf (deadfile, "===========================================================================\n");
    for (i = 0; i < txLines; i++) {
      fprintf (deadfile, "%s\n", (*edtext)[i].line);
    }
    fclose (deadfile);
    EndLog ();
    endwin ();
    printf ("Caught Segmentation Fault. Message-Text saved in msg.FEddy\n");
    exit (11);
  }
  EndLog ();
  endwin ();
  printf ("Caught Segmentation Fault, but unable to save message-text. Sorry. :(\n");
  exit (1);
}
