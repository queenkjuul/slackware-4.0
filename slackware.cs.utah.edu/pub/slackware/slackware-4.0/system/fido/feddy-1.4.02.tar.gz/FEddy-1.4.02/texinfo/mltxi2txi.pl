#!/usr/bin/perl -w
# /*
# ===========================================================================
#           (c) copyright by Karl Heinz Marbaise Aachen 1998, 1999
#                      Multilingual-Texinfo to Texinfo
#                               Release 0.01
# ---------------------------------------------------------------------------
#
# Description:
#     Convert Multilingual-Texinfo(*.texi_ml) files to
#     language depend standalone Texinfo files.
#     The source Texinfo files should be using the ISO 639
#     language codes to determine the used language.
#
# Author, Date:
#     Karl Heinz Marbaise, 20. December 1998
#
# e-mail:
#     kama@hippo.fido.de
#
# License:
#     GPL Version 2.0 or later
#
# e-mail:
#     kama@hippo.fido.de
#
# */
#
# $Id: mltxi2txi.pl,v 1.3 1999/02/28 16:18:50 pm Exp $
#
# command line arguments.
use Getopt::Long;
use Getopt::Std;
#
$FILERE = '[\/\w.+-]+';	       # RE for a file name
@Dateien = ();                 # list of read files
#
$Version="
===========================================================================
          (c) copyright by Karl Heinz Marbaise Aachen 1998, 1999
                     Multilingual-Texinfo to Texinfo
                              Release 0.01
---------------------------------------------------------------------------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

Written by Karl Heinz Marbaise, <kama\@hippo.fido.de>
";
#
#
$usage="
===========================================================================
          (c) copyright by Karl Heinz Marbaise Aachen 1998, 1999
                     Multilingual-Texinfo to Texinfo
---------------------------------------------------------------------------

Description:
    Convert Multilingual-Texinfo(*.texi_ml) files to
    language depend standalone Texinfo files.
    The source Texinfo files should be using the ISO 639
    language codes to determine the used language.

Author, Date:
    Karl Heinz Marbaise, 20. December 1998

e-mail:
    kama\@hippo.fido.de

License:
    GPL Version 2.0 or later

Synopsis:
    mltxi2txi [--lang=s] test.texi

Options:
    --verbose    be a little informative
    --version    print out version and copyright stuff and stop
    --help       print this help screen then stop.
    --lang=s     s is the ISO 639 language code
                 (actualy only de and en allowed)
                 Default is en.
";
#
$SelectedLanguageOpt = "en"; #default english !
#
&GetOptions ("lang=s" => \$SelectedLanguageOpt,
             "help" => \$HelpOpt,
             "version" => \$VersionOpt,
             "verbose" => \$VerboseOpt);
#
if ($VersionOpt)
{
    print STDOUT $Version, "\n";
    exit 1;
}
if ($HelpOpt)
{
    print STDOUT $usage, "\n";
    exit 1;
}
#
#
sub ReadFile
{
    local ($Datei) = @_;
    my $Lang="all";
    my $NewLang="all";
    my $MultiLing=$Datei . "_ml";
    #
    if ($VerboseOpt) {
        printf ("Working on %s", $Datei);
    }
    open (In, $MultiLing) or die "(1)Couldn't open $MultiLing!\n";
    open (LANGOUT, ">$Datei") or die "(2)Couldn't open file $Datei!\n";
    LINE: while (<In>)
    {
        chop;
        # Get the files which are included and save them
        # for later usage.
        if (/^\@include\s+($FILERE)\s*$/o) {
            $file = $1;
            #########print "# Include File ", $file, "\n";
            push @Dateien, ($file);
        }
        #
        #
        if (/^\\\\\[([a-z]+)*\]/)
        {
            $NewLang=$1;
            if ($Lang ne $1)
            {
                $Lang=$NewLang;
            }
            next;
        }
        if (($Lang eq $SelectedLanguageOpt) or ($Lang eq "all"))
        {
            print LANGOUT $_,"\n";
        }
    } #while (<In>)...
    close (LANGOUT);
    close (In);

    #    printf (".\n");
} #sub ReadFile...

# =============================================================================
# ===                               M A I N                                 ===
# =============================================================================
#
###printf ("Argumente=\"%s\"\n", @ARGV);
#
foreach $GlobalFile (@ARGV)
{
    ReadFile ($GlobalFile);
    #
    foreach $DateiName (@Dateien)
    {
        if ($VerboseOpt) {
            printf ("Reading %s...", $DateiName);
        }
        ReadFile ($DateiName);
        if ($VerboseOpt) {
            printf ("\n");
        }
    } #foreach $DateiName (@Dateien)...
}
#
