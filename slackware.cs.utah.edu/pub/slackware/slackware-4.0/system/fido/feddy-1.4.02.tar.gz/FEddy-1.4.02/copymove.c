

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */
 
/*-------------------------------------------------------------------------*/
/*               R E V I S I O N   C O N T R O L                           */
/*-------------------------------------------------------------------------*/ 
#ifdef __RCS__ 
const static char *COPYMOVE_C = "$Id: copymove.c,v 1.4 1998/07/04 18:25:50 pm Exp $";
#endif 
/*-------------------------------------------------------------------------*/ 
/*                   I N C L U D E S                                       */
/*-------------------------------------------------------------------------*/ 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include "proc.h"
/*-------------------------------------------------------------------------*/
/*                   D E F I N E S                                         */
/*-------------------------------------------------------------------------*/ 
/*-------------------------------------------------------------------------*/
/*                   F U N C T I O N S                                     */
/*-------------------------------------------------------------------------*/ 
/*-------------------------------------------------------------------------*/
/*                   S E L F T E S T                                       */
/*-------------------------------------------------------------------------*/ 
#ifndef SELFTEST 
#define SELFTEST 1
#endif 
/*-------------------------------------------------------------------------*/
#if             SELFTEST 
/*-------------------------------------------------------------------------*/ 

 
static char *descr[] = { 
"", 
"$Id: copymove.c,v 1.4 1998/07/04 18:25:50 pm Exp $", 
}; 
int quiet=2;
int made_new_dir = 0;
void ShowHelp(void) 
{ 
  int i, hs = sizeof(descr) / sizeof(descr[0]); 
 
  for (i=0; i != hs; i++) 
       printf("%s\n",descr[i]); 
} 
 
void spezExt( char *line){
}
int main(int argc,char **argv) 
{ 
    char buffer[512];

    loadrc (0);
    if ( argc < 4 ) {
        Log (" CopyMove Parameter Error\n");
        exit (EXIT_FAILURE);
    }
    if ( (!strcmp( argv[1] , "copy" )) && (!strcmp( argv[1] , "move")))
    {
        Log (" CopyMove Parameter Error\n");
        exit (EXIT_FAILURE);
    }

    if ( strcmp ( argv[2] , argv[3] ) == 0 ) {
        
        Log (" CopyMove Parameter Error SRC==DEST\n");
        exit (EXIT_FAILURE);
    }

    sprintf(buffer,"futility -qq copy marked %s %s",argv[2],argv[3]);
    Log ( " cm %s\n",buffer);
    system(buffer);
    
    sprintf(buffer,"futility -qq tool -mark mark+ %s",argv[2]);
    Log ( " cm %s\n",buffer);
    system(buffer);


    if ( strcmp( argv[1] , "copy" ) == 0) {
          sprintf(buffer,"futility -qq tool -mark mark+ %s",argv[3]);
          Log ( " cm %s\n",buffer);
          system(buffer);
    }
    else {
         sprintf(buffer,"futility -qq tool +delete mark+ %s",argv[3]);
         Log ( " cm %s\n",buffer);
         system(buffer);

         sprintf(buffer,"futility -qq pack %s",argv[3]);
         Log ( " cm %s\n",buffer);
         system(buffer);
    }

    sprintf(buffer,"futility -qq rescan");
    Log ( " cm %s\n",buffer);
    system(buffer);

    return 0; 
 
} 
#endif 
/*-------------------------------------------------------------------------*/ 
/* end of COPYMOVE.C */
 

