

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

#ifndef _MBHELP_H
#define _MBHELP_H

#define bhelp_inputline	"<CR>-accept <ESC>^2-cancel <C-y>-kill line"\
												" <UP|DOWN>-words <PGUP|PGDN>-history"
#define bhelp_inputfile	"<CR>-accept <ESC>^2-cancel <C-y>-kill line"\
												" <TAB>-expandfile <PGUP|PGDN>-history"
#define bhelp_inputfld	"<CR>-accept  <ESC>^2-cancel  <C-y>-kill line"
#define bhelp_textedit	"<M-x>-save&exit  <ESC>^2-cancel  <M-h>-help"
#define bhelp_request		"<M-g>-request files  <ESC>^2-cancel  <M-h>-help"
#define bhelp_changefld	"<CR>-change folder  <ESC>^2-cancel "\
												" <RIGHT>-MessageList  <M-h>-help"
#define bhelp_changemsg	"<CR|RIGHT>-change to message  <ESC>^2-cancel "\
												" <LEFT>-FolderList  <M-h>-help"
#define bhelp_tree			"<CR>-change message  <ESC>^2-cancel  <M-h>-help"
#define bhelp_search		"<CR>-change message  <ESC>^2-cancel  <M-h>-help"
#define bhelp_utility		"<CR>-cancel  <ESC>^2-cancel  <UP|DOWN>-scroll list"
#define bhelp_nlchoose	"<CR>-choose  <ESC>^2-cancel  <TAB>-info"

void showAbout ();
void showGlobalHelp ();
void showKeyboardHelp ();
void showNumblockHelp ();
void showFolderHelp ();
void showMessageHelp ();
void showTreeHelp ();
void showRequestHelp ();
void showSearchHelp ();
void showRegexHelp ();
void showEditorHelp ();

#endif
