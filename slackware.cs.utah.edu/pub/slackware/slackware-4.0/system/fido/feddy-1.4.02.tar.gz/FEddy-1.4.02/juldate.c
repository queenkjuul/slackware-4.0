

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

int schaltjahr (short j)
{
  if (!(j % 4) && (j % 100 || !(j % 400)))
    return 1;
  else
    return 0;
}

int jahr = 999999999, sjahre = 999999999;

int schaltjahre (short j)
{
  int c, jj;
  if (j == jahr)
    return sjahre;
  for (c = 0, jj = 0; jj < j; jj++)
    if (schaltjahr (jj + 1900))
      c++;
  jahr = j;
  sjahre = c;
  return c;
}

long juldat (short t, short m, short j)
{
  short tage[] =
  {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};
  long numDays;
  numDays = tage[m - 1] + t;
  if (schaltjahr (1900 + j) && m > 2)
    numDays++;
  numDays += (j * 365 + schaltjahre (j));
  return numDays;
}
