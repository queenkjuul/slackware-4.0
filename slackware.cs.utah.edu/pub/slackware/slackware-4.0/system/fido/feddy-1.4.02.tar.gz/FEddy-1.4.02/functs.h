

/*
 * This file is part of the FEddy package
 *
 *       Release 1.4.02  02/28/99
 *
 * Maintainance : Peter Marbaise (pema@hippo.fido.de,2:2452/110.20)
 *
 * based on Oliver Graf's FEddi  Fido 2:2454/130.69
 *                                email ograf@informatik.uni-koblenz.de

 * Personal use allowed under the terms of the
 *
 *              GNU GENERAL PUBLIC LICENSE Version 2
 *              (see LICENSE for the complete text)
 *
 *-------------------------------------------------------------------
 *
 *    ENTER AT YOUR OWN RISK !!
 *
 * This source is without any documentation and can drive you mad.
 * In case of sudden epileptic seizures please call your doctor.
 *
 */

#ifndef _FUNCTS_H
#define _FUNCTS_H

#include "structs.h"

#define CURSOR_ON  1
#define CURSOR_OFF 0

int inputline (WINDOW * win, WINDOW * hlp, int y, int x, int l, char *s, \
	       char **h, int e, int tabexpand);
WINDOW *openask (int yl, int xl, int ys, int xs, char *title, chtype attr);
char **addhistory (char **hist, int entrys, char *line);
void Beep ();
int scrolltext (LineListType * text, int lines, char *title, int question);
int scrollchoice (LineListType * text, int lines, char *title,
		  int (*key) (int, int));
void EXTWait ();
void EXTEnd ();
char *fldlm (char *match, char *result);
int inputfld (WINDOW * win, WINDOW * hlp, int y, int x, int l, char *s);
int showlog (LineListType **);
int waddstru (WINDOW *, char *);
int mvwaddstru (WINDOW *, int, int, char *);
int mvwaddstrucol (WINDOW *, int, int, char *, int);
int mvwaddstrucoled (WINDOW *, int, int, char *, int);
int wclrtoeoln (WINDOW * win);
int wclrtoeolu (WINDOW * win);
int wclrnumn (WINDOW * win, int l);
#define getchn() (getch()&255)

#endif /* _FUNCTS_H */
