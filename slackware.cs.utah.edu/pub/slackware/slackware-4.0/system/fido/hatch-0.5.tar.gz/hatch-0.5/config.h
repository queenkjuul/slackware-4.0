/*
 * hatch - a tool for hatching files into Fidonet file areas
 *
 * config.h
 *
 * Copyright (c) 1995 by Martin Schulze
 *
 * You may distribute it under the terms of the GNU General Public
 * License as specified in the file COPYING that comes with this
 * distribution.
 *
 * Martin Schulze
 * mgs@infodrom.north.de
 *
 * Configuration
 */

/* file containing information about file areas
 * see readme for more information
 */
#define FILEAREA_FILE "/usr/local/lib/fidonet/fileareas"

/* file containing fidogate aliases: login, AKA and Realname
 * We just need the rest of the aka
 */
#define ALIASES_FILE "/usr/local/lib/fidonet/aliases"

/* file containing ifcico passwords
 */
#define PASSWDS_FILE "/usr/local/lib/fidonet/passwds"

/* directory where to put the files. It has to be the 
 * ifcico outbound, and not the fidogate outbound.
 */
#define OUTBOUND "/var/spool/fidonet/outb"

/* the suffix for flo files without leading '.'.
 * On Infodrom I have flo, but you might have FLO
 */
#define FLO "flo"
/**************************************************************/


