#define IFCONFIG "/etc/ifmail/config"
