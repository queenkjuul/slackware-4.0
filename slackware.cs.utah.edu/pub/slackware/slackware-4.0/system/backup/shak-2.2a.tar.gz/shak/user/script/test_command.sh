#!/bin/sh
dd ibs=10240 obs=512 if=/dev/nst0 | cpio -itv 1>&2
