#ifndef H_MISCFN
#define H_MISCFN

/*#include "config.h" */

#define  HAVE_FNMATCH_H 0
#define HAVE_GLOB_H 0
#define HAVE_REALPATH 1


#if HAVE_FNMATCH_H
#include <fnmatch.h>
#else
#include "misc-fnmatch.h"
#endif

#if HAVE_GLOB_H
#include <glob.h>
#else
#include "misc-glob.h"
#endif

#if ! HAVE_REALPATH
char *realpath(char *path, char resolved_path[]);
#endif

#endif
