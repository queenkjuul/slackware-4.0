#!/bin/sh
# $Id: log_stderr.sh_v 1.4 1996/04/14 19:58:33 jhl Exp $

if [ $# -ne 1 ]; then
  exit 1
fi

nlines="` wc -l <$1 | sed -e 's/^ *//'`"

echo "#STDERR FOLLOWS ON NEXT LINE" |
${SHAK_USERPATH}/lib/shak0_append_file ${SHAK_LOGHOST} ${LOGFILE}

${SHAK_USERPATH}/lib/shak0_append_file ${SHAK_LOGHOST} ${LOGFILE}  <$1

echo "#STDERR ENDS ON LINE ABOVE" |
${SHAK_USERPATH}/lib/shak0_append_file ${SHAK_LOGHOST} ${LOGFILE} 

${SHAK_USERPATH}/lib/shak0_append_file ${SHAK_LOGHOST} ${LOGFILE}.STDERR  <$1
retval=$?

if [ $retval = 0 -a $nlines = 1 ]; then
	cat $1 
	exit 0
else
	if [ $retval -gt 0 ]; then
		echo ""
		exit 1
	else
		echo ""
		exit 2
	fi
fi

