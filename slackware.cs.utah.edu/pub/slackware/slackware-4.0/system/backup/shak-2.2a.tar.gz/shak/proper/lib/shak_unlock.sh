#!/bin/sh
# $Id: shak_unlock_v 1.4 1996/05/10 01:16:19 jhl Exp $

# shak_unlock - Program for unlocking the tapedevice.

# return values: 0 or 1
#   1: unlock unsuccessful, unlink not performed, not locked
#   0: unlock successful, unlink performed.
#   2: error

lockhost=$SHAK_INDEXHOST
lockfile="`$SHAK_LIBPATH/shak_lockname`"
lockline="`${SHAK_LIBPATH}/shak_lockentry`"

${SHAK_LIBPATH}/shak_checklock $lockhost "$lockline"
retval=$?

case $retval in
	0)
		errorstring="`${SHAK_LIBPATH}/shak_remsh ${SHAK_REMSH} $lockhost "/bin/rm -f $lockfile"`"
		if [ ! $? -eq 0 -o "$errorstring" ]; then	
			echo "shak_unlock: rm failed" 2>&1
			exit 2
		fi
		exit 0
	        ;;
	1)
		exit 1
		break
	        ;;
	2)
		exit 2
		break
		;;

	3)
		exit 3
		break;;
esac


