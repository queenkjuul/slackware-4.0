
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

int main (int argc, char **argv)
{
  extern char * optarg;
  extern int optind;
  
  int c, optionerror=0;  
  time_t last=2147483647, calt=1000000;
  struct tm  *tmp;
  char str[2000],TZ[400];

  strcpy( TZ, "TZ=GMT0GMT");
  putenv (TZ);
  tmp=gmtime (&last);
/*
  printf ("last second of 32-bit epoch:  %s\n", asctime (tmp));
*/
  while ((c = getopt (argc, argv, "z:c:")) != EOF)
    {
      switch (c)
	{
	case 'z':    /* filter by ctime or mtime */ 
          strcpy (str, optarg);
	  break;
	case 'c':    /* debug mode on */ 
	  calt = (time_t) atoi (optarg);
	  break;
        default:
          optionerror = 1;
        }
    }
  argv += optind;
  argc -= optind;

  strcpy (TZ, "TZ=");
  strcat (TZ, str);
  
  if ((optionerror == 1))
    {
    fprintf (stderr,"Usage: testmkstrtime [-c calender_time] [-z TZ_variable]\n");
    fprintf (stderr,"  Example: testmkstrtime -c 812799203 -z GMT0GMT\n");
    exit (1);
    }

  putenv (TZ);
  tmp=localtime (&calt);
  printf ("%s", asctime (tmp));
  
  exit (0);
}

