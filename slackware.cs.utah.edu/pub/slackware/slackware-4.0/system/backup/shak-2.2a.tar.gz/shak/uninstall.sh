#!/bin/sh

    echo "This will delete files listed in var/installed_files"
    echo -n "Continue    yes or no ? "
    read ans </dev/tty
    if [ $ans != yes ]; then
	exit 1
    fi


while read file
do

if [ -f $file ]; then
   rm $file
fi

if [ -d $file ]; then
  rmdir $file
  if [ $? != 0 ]; then
    echo -n "force delete $file yes or no ? "
    read ans </dev/tty
    if [ $ans = yes ]; then
      rm -fR $file
    fi
  fi
fi

done <var/installed_files


