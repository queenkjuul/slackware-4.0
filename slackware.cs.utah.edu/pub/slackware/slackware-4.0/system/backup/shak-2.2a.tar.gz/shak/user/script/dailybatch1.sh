#!/bin/sh
LCH=localhost
program=backupshak
echo -h localhost backupshak.sh
echo -t incrs -h $LCH ${PROGRAM}.sh
echo -t diffs -h $LCH ${PROGRAM}.sh
echo -t fullu -h $LCH ${PROGRAM}.sh
