#!/bin/sh
# $Id: shak_lock_v 1.2 1996/05/10 01:16:13 jhl Exp $

# shak_lock - Program for locking the tapedevice.

# return values: 0 or 1
#   1: lock unsuccessful
#   0: lock successful

lockhost=$SHAK_INDEXHOST
lockfile="`$SHAK_LIBPATH/shak_lockname`"
lockline="`${SHAK_LIBPATH}/shak_lockentry`"

echo "$lockline" | ${SHAK_LIBPATH}/shak0_append_file -u 002 $lockhost $lockfile
sleep 1

${SHAK_LIBPATH}/shak_checklock $lockhost "$lockline"

exit $?


