#!/bin/sh
Id_trivial_sh="\$Id: trivial.sh_v 1.11 1996/11/24 19:33:42 jhl Exp $"

trap 'echo "trivial.sh: signal 1 2 or 15 raised" ; exit 3' 1 2 15

IDSTRING="$Id_trivial_sh"

echo "ARGS: $*"
echo "NUMBER OF ARGS: $#"
echo "--- START `date`" 1>&2
echo "These are the exported variables:"
echo ""

echo "__BEGIN__" 1>&2

echo "SHAK_DOMAIN      :$SHAK_DOMAIN"
echo "SHAK_SHAKPATH    :$SHAK_SHAKPATH"
echo "SHAK_SHAKHEADER  :$SHAK_SHAKHEADER"
echo "SHAK_LIBPATH     :$SHAK_LIBPATH"
echo "SHAK_USERPATH    :$SHAK_USERPATH"
echo "SHAK_TAPEHOST    :$SHAK_TAPEHOST"
echo "SHAK_LOGHOST     :$SHAK_LOGHOST"
echo "SHAK_INDEXHOST   :$SHAK_INDEXHOST"
echo "SHAK_INDEXPATH   :$SHAK_INDEXPATH"
echo "SHAK_TAPEDEVICE  :$SHAK_TAPEDEVICE"
echo "SHAK_REMSH       :$SHAK_REMSH"
echo "SHAK_LOGNAME     :$SHAK_LOGNAME"
echo "SHAK_LOGPATH     :$SHAK_LOGPATH"
echo "SHAK_SHAKDATE    :$SHAK_SHAKDATE"
echo "SHAK_TIME_T      :$SHAK_TIME_T"
echo "SHAK_TAPENUMBER  :$SHAK_TAPENUMBER"
echo "SHAK_SHAKTYPE    :$SHAK_SHAKTYPE"
echo "SHAK_LOGBASENAME :$SHAK_LOGBASENAME"
echo "SHAK_USEHEADERS  :$SHAK_USEHEADERS"
echo "SHAK_MT_EOM      :$SHAK_MT_EOM"
echo "SHAK_USER000     :$SHAK_USER000"
echo "SHAK_USER001     :$SHAK_USER001"
echo "SHAK_USER002     :$SHAK_USER002"
echo "SHAK_USER003     :$SHAK_USER003"
echo "SHAK_USER004     :$SHAK_USER004"
echo "SHAK_USER005     :$SHAK_USER005"
echo "SHAK_USER006     :$SHAK_USER006"
echo "SHAK_USER007     :$SHAK_USER007"

if [ "$2" ]; then
	echo "$2" 1>&2
fi

if [ "$1" ]; then
	echo "START Sleeping $1 seconds"
	sleep $1
	echo "FINISH Sleeping $1 seconds"
fi


echo ""
echo "trivial.sh: exit 0 (success)"
echo "--- FINISH `date`" 1>&2


echo "__END__" 1>&2
exit 0

