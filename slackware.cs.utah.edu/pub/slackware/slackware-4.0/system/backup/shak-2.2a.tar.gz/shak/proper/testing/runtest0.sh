#!/bin/sh

./test.sh $1

./retr_hostname $1

