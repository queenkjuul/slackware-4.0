/* $Header: /wwg/Submitted.src/ftpbackup.src/RCS/ftplib.h,v 1.3 1997/09/16 03:11:18 wwg rel $
 *
 * Under GPL2 License : See file COPYING
 *
 * $Log: ftplib.h,v $
 * Revision 1.3  1997/09/16 03:11:18  wwg
 * Now under GPL2 license
 *
 * Revision 1.2  1997/09/14 00:35:36  wwg
 * Added VERS and extern int cmdopt_D to support the new
 * -D option.
 *
 * Revision 1.1  1997/09/13 21:12:11  wwg
 * Initial revision for RCS
 *
 * Originally created on Sat Jun  8 08:28:22 1996 by Warren W. Gay VE3WWG
 */
#ifndef _ftplib_h_
#define _ftplib_h_ "@(#)ftplib.h $Revision: 1.3 $"

#define VERS	"2.1"

#define FTPBUF_SIZE	1024

extern char ftpBuf[FTPBUF_SIZE];
extern short ftpDebug;
extern int cmdopt_D;

/*
 * Support I/O functions :
 */
extern int ftpio_GetResp(int s);
extern int ftpio_PutCmdf(int s,char *format,...);

/*
 * ftplib API :
 */
extern int ftpOpen(const char *host,int port);
extern int ftpUserPW(int s,const char *userid,const char *passwd);
extern int ftpType(int s,char Type);
extern int ftpQuit(int s);
extern char *ftpSyst(int s);

extern int ftpChdir(int s,const char *directory);
extern int ftpStore(int s,const char *RemoteFileName);
extern int ftpRetrieve(int s,const char *RemoteFileName);
extern int ftpList(int s,const char *What);
extern int ftpClose(int s,int s2);

#endif /* _ftplib_h_ */

/* $Source: /wwg/Submitted.src/ftpbackup.src/RCS/ftplib.h,v $ */
