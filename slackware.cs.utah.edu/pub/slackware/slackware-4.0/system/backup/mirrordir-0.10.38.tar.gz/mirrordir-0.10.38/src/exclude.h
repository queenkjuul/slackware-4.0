/*   This has nothing to do with cryptography. */


typedef struct {
    char *filename;
    char **paths;
    size_t num_paths;
} FastSearch;

int fastsearch_init (FastSearch *fast_search, char *filename);
void fastsearch_shut (FastSearch *fast_search);
int fastsearch_islisted (FastSearch *fast_search, char *path);


