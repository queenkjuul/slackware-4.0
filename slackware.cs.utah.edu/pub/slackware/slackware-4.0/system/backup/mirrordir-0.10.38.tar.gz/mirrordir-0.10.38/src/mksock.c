/*   This has nothing to do with cryptography. */
/* mksock - make a Unix domain socket */

#ifdef WIN32
int main ()
{
    return 0;
}

#else

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

int main(int argc, char **argv)
{
  int sd;
  struct sockaddr_un sin;
  if ((sd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) exit(1);
  strcpy(sin.sun_path, argv[1]);
  sin.sun_family = AF_UNIX;
  if ((bind(sd, (const struct sockaddr *) &sin, sizeof(sin)) == -1)) exit(1);
  exit(0);
}

#endif

