/*   This has nothing to do with cryptography. */
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#ifdef HAVE_MALLOC_H
#include <malloc.h>
#endif
#ifdef HAVE_TYPES_H
#include <types.h>
#endif
#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif
#include <ctype.h>	/* For isdigit */


#if HAVE_DIRENT_H
#include <dirent.h>
#define NAMLEN(dirent) strlen((dirent)->d_name)
#else
#define HAVE_DIR_D_NAMELEN
#define dirent direct
#define NAMLEN(dirent) (dirent)->d_namlen
#if HAVE_SYS_NDIR_H
#include <sys/ndir.h>
#endif
#if HAVE_SYS_DIR_H
#include <sys/dir.h>
#endif
#if HAVE_NDIR_H
#include <ndir.h>
#endif
#endif

#ifdef HAVE_UTIME_H
#include <utime.h>
#endif
#if TIME_WITH_SYS_TIME
#include <sys/time.h>
#include <time.h>
#else
#if HAVE_SYS_TIME_H
#include <sys/time.h>
#else
#include <time.h>
#endif
#endif
#if HAVE_SYS_TIMEB_H
#include <sys/timeb.h>
#endif

#include <sys/stat.h>
#ifdef HAVE_FCNTL_H
#include <fcntl.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifndef INHIBIT_STRING_HEADER
#if defined (HAVE_STRING_H) || defined (STDC_HEADERS) || defined (_LIBC)
#include <string.h>
#else
#include <strings.h>
#endif
#endif
#include <errno.h>

#ifdef HAVE_LIMITS_H
#    include <limits.h>
#endif
#ifndef NGROUPS_MAX
#    ifdef HAVE_SYS_PARAM_H
#        include <sys/param.h>
#    endif
#    ifdef NGROUPS
#        undef NGROUPS_MAX
#        define NGROUPS_MAX NGROUPS
#    endif
#endif
#ifdef HAVE_GRP_H
#    include <grp.h>
#endif
#ifdef HAVE_SHADOW_H
#    include <shadow.h>
#else
#    ifdef HAVE_SHADOW_SHADOW_H
#        include <shadow/shadow.h>
#    endif
#endif
#ifdef HAVE_CRYPT_H
#    include <crypt.h>
#endif
#include <signal.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
/* CHECK */
#ifdef HAVE_SETSOCKOPT
#    include <netinet/ip.h>	/* IP options */
#endif
#ifdef HAVE_ARPA_INET_H
#include <arpa/inet.h>
#endif
#ifdef HAVE_ARPA_FTP_H
#include <arpa/ftp.h>
#endif
#ifdef HAVE_ARPA_TELNET_H
#include <arpa/telnet.h>
#endif

#ifdef USE_TERMNET
/* CHECK */
#include <termnet.h>
#endif

#ifdef HAVE_SELECT_H
#   include <select.h>
#endif
#ifdef HAVE_SYS_SELECT_H
#   include <sys/select.h>
#endif

#ifdef HAVE_PMAP_SET
/* CHECK */
#    include <rpc/rpc.h>
#    include <rpc/pmap_prot.h>
#    ifdef HAVE_RPC_PMAP_CLNT_H
#        include <rpc/pmap_clnt.h>
#    endif
#endif

#ifdef HAVE_PWD_H
#include <pwd.h>
#endif
#ifdef HAVE_PAM
/* CHECK */
#    include <security/pam_misc.h>
#    ifndef PAM_ESTABLISH_CRED
#        define PAM_ESTABLISH_CRED PAM_CRED_ESTABLISH
#    endif
#endif

#ifdef HAVE_SYS_IOCTL_H
#include <sys/ioctl.h>
#endif
#ifdef HAVE_TERMIOS_H
#include <termios.h>
#endif

#undef MC_MAXPATHLEN
#define MC_MAXPATHLEN 4096
#undef MAX_PATH_LEN
#define MAX_PATH_LEN 4096

#ifdef HAVE_PATHS_H
#include <paths.h>
#endif

#ifdef NEED_WINSIZE
struct winsize {
	unsigned short ws_row, ws_col;
	unsigned short ws_xpixel, ws_ypixel;
};
#endif


