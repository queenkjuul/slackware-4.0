/* acconfig.h   Additional defines */

/* Define to long if your headers don't */
#undef dev_t

/* Define to long if your headers don't */
#undef ino_t

/* Define to mode_t if your headers don't */
#undef umode_t

/* Define to unsigned int if your headers don't */
#undef nlink_t

/* Define to `char *' if your headers don't */
#undef caddr_t

/* Package name */
#undef PACKAGE

/* Version number */
#undef VERSION

/* using VFS ? */
#undef USE_VFS

/* using network code */
#undef USE_NETCODE

/* have socket function */
#undef HAVE_SOCKET

/* If your OS does not have enough space for a file name in struct dirent */
#undef NEED_EXTRA_DIRENT_BUFFER

/* using a shadow password file */
#undef HAVE_SHADOW

/* have crypt function */
#undef HAVE_CRYPT

/* on linux, have Portable Authentication Modules ? */
#undef HAVE_PAM

/* sun has char d_name[2] or something, define if so */
#undef NEED_EXTRA_DIRENT_BUFFER

/* define if have struct winsize */
#undef NEED_WINSIZE

/* define if you have the forkpty() function */
#undef HAVE_FORKPTY

/* define if youn have the logout() function */
#undef HAVE_LOGOUT

/* define if you have the pw_encrypt() function */
#undef HAVE_PW_ENCRYPT

/* define for proxy support */
#undef HSC_PROXY

/* installation path. usually /usr/local or /usr */
#undef INSTALL_PREFIX

/* compiled in arc encryption for International version requires arcencrypt.inc, arcinit.inc */
#undef HAVE_BUILTIN_ARC
