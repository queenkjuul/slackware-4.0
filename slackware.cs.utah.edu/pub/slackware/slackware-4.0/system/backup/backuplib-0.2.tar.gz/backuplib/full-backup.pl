#!/usr/bin/perl

use lib "/etc/backup/";
use backuplib;


backuplib::dat_load();

backuplib::dat_backup( );
