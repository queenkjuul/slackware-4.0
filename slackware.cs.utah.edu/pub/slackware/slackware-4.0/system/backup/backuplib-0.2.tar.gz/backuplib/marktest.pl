#!/usr/bin/perl

# used to test the setmark feature of backuplib

use lib "/etc/backup/";
use backuplib;


backuplib::dat_load();

backuplib::dat_backup( );

backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();
backuplib::dat_backup_incremental();

