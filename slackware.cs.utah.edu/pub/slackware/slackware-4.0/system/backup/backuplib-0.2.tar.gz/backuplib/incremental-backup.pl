#!/usr/bin/perl

use lib "/etc/backup/";
use backuplib;


backuplib::dat_backup_incremental( );
