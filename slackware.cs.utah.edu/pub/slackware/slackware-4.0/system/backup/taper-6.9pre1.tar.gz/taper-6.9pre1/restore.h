/*
   Time-stamp: <96/07/19 20:18:09 yusuf>

   $Id: restore.h,v 1.4 1996/07/27 20:42:11 yusuf Exp $
*/


extern int select_restore_files(void);


