/*
   Time-stamp: <97/04/20 10:04:17 yusuf>

   $Id: taper.h,v 1.14 1997/06/29 01:31:26 yusuf Exp $
*/


/* Functions in tapeio.h */

#define __FROM_MAIN__

#include "config.h"
#include "version.h"
#include <stdlib.h>
#ifdef ASM_STRING
  #include <linux/string.h>
#else
  #include <string.h>
#endif

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <utime.h>
#include <time.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/mtio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/mount.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <curses.h>
#include <form.h>

#include "select_box.h"
#include "compress/lzrw3.h"
#include "compress/gzip.h"
#include "non-ansi.h"
#include "defaults.h"
#include "structs.h"
#include "vars.h"
#include "common.h"
#include "tapeio.h"
#include "endianize.h"
#include "library.h"
#include "fifo.h"
#include "rmt.h"


#include <stdio.h>
#include <sys/types.h>
#include <signal.h>

