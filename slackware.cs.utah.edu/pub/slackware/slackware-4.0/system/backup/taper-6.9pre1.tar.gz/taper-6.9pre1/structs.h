/*
   Time-stamp: <98/05/02 17:23:04 yusuf>

   $Id: structs.h,v 1.25 1998/05/02 12:51:41 yusuf Exp $
*/

#include <unistd.h>

/* Tape header */
struct tape_header {
    _u32     magic;
    _u32     archive_id;
    _s32     tape_number;
    char     archive_title[MAX_ARCHIVETITLE];
};


/* Header of info file */
struct info_file_header {
    _u32  magic;
    _u32  free[INFO_INDICIES];			 /* for use with m-tree */
    _u32  end[INFO_INDICIES];			 /* indicies */
    _u32  root[INFO_INDICIES];
    _u32  archive_id;
    _s32  number_tapes;
    _s32  number_volumes;			 /* volume/tape info at end of info file */
    _u32  size_volume_headers;			 /* size of volume headers */
    _s32  no_in_archive;
    _s32  number_tsi;				 /* # times end vol hit end of tape */
    char archive_title[MAX_ARCHIVETITLE];
};

/* A volume header consists of:
      magic number
      no in volume
      title of volume
      time of backup
      number of selection strings 
      selection strings (ie. the selection criteria used to
                         select files for this volume)
           each string contains :
	     string len     ) selection criteria
	     string         )
	     string len     ) filter - blank filter means select all
	     string         )
*/
struct volume_header {
    _s32 volume_magic;				 /* magic number of a volume */
    _s32 no_in_volume;				 /* # files in volume */
    char volume_title[MAX_ARCHIVETITLE];	 /* name of volume */
    _time_t backup_time;			 /* time volume backed up */
    _s32  no_sels;				 /* number of select */
    _u32 size_header;				 /* size of volume header information */
};




/* Information for each file on tape */
struct file_info {
    _u32     act_size;	 
    _s32     volume;
    /* If the volume < 0, then this means that this file is a directory that
       was added because of a change in common path names. The volume is the
       negative of the original */
    _s32      pos_in_archive;
    _dev_t    dev;
    _uid_t    uid;				 
    _gid_t    gid;
    _umode_t  mode;				 /* mode of the file (if link, mode of link file) */
    _umode_t  org_mode;				 /* mode of the original file */
    _u32     size;
    _time_t  atime;
    _time_t  mtime;
    _time_t  ctime;
    _time_t  backup_time;
    _u8      name_len;
    _u8      compressed;
    _s32     checksum;				 /* just the sum of all the bytes in the file */
      						 /* if =-1, then problem backing up this file 
						       =-2, the backup was aborted */
};


struct file_info_file_data {			 /* structure holding information */
    _u32 recnum;				 /* record number */
    struct file_info f;				 /* in data file */
    off_t  fname_pos;				 /* position in filename file */
};

struct info_file_data {				 /* structure holding information */
    _u32 recnum;				 /* record number */
    struct file_info f;				 /* in data file */
    off_t  fname_pos;				 /* position in filename file */
    char name[MAX_FNAME];	       		 /* position in filename file */
};

struct info_file_key {				 /* common key for info file */
    _u32 recnum;
    off_t  fname_pos;				 /* position in filename file */
    _u32  pos_in_archive;
    _s32     volume;
    _time_t  mtime;
};

    
/* Information about which tape each volume is on 
   Appened to end of info file */
struct volume_tape_info {
    _s32 volume;				 /* volume */
    _s32 start_tape;				 /* tape this volume starts */
    _s32 end_tape;				 /* tape this volume ends on */
    _u32 blocks_on_last_tape;			 /* # blocks that belong to this vol on end_tape */
};

/* Information about size of each tape 
 * Appended to end of inf file */
struct tape_size_info {
    _s32 tape_number;				 /* tape number */
    _s32 volume;
    _u32 blocks;				 /* # blocks on tape */
    _u32 lb_bytes_short;			 /* # bytes the last block is short by */
};


struct memory_file {				 /* representation of a file in memory */
    _u32 size;
    _s8 selected;				 /* 0 not selected, 1 selected  */
    _s8 unselected;				 /* 0 not unselected, 1 unselected */
    _u32 most_recent;				 /* rec # of most recent */
};

    
/* Representation in memory of a file on the archive */
#define ENTRY_INCLUDE 1
#define ENTRY_EXCLUDE 2
struct selected_entry {
    struct info_file_data i, savedi;
    _s8                   incremental;		 /* in sel_restore: 1 = restore most recent
						                    0 = restore volume given
						    in sel_backup:  1 = incremental backup
						                    0 = full backup */
    _s8                 selected;		 /* 0 if directly, 1 if indirectly */
    _u32                size;			 /* size of selection */
    _u32                mm_size, ab_size;
};						 


/* Representation in memory of the directory I create in sel_restore */
struct dir_file_entry {
    struct info_file_data i;
    char                name[MAX_FNAME];
    _s8                 selected;
    _u32                size;
};						 

struct shared_mems {				 /* things that are */
    volatile _s32   _write_offset;		 /* and the taper writing process */
    volatile _s8    _for_close_1;		 /* trying to close with buffer */
    volatile _s8    _for_close_2;		 /* trying to close with buffer */
    volatile _s8    _still_compressing;		 /* restore child is still compressing */
    volatile _s32   _log_errors;		 /* child of parent can change them */
    volatile _s32   _log_warnings;
    volatile pid_t  _write_pid;			 /* pid of write child */
    volatile _vptr  _write_buf_no;		 /* tells child which buffer to write */
    volatile _s32   _buf_length_1;		 /* how long the buffer 1 is */
    volatile _s32   _buf_length_2;		 /* how long buffer 2 is */
    volatile _s32   _left_tr;			 /* amount left to transfer out of a buffer after write */
    volatile _s32   _blocks_passed;		 /* number of blocks passed */
    volatile _u32   _bytes_short;		 /* # bytes that couldn't be read/written to last block on tape */
             _s8    *_w_current_buffer;		 /* buffer data being currently spooled to */
             _s8    *_w_current_writing;	 /* buffer child is currently writing to tape */
             _s8    *_w_buffer_1, *_w_buffer_2;	 /* double buffers */
};

struct pref_template {
    char   *pref_name;				 /* long command name & preference name */
    _s8    cln;					 /* short command name */
    _vptr  option_1;
    _vptr  option_2;				 /* for colours */
    _s8    handle;				 /* how to handle option */
						 /* Y = true/false, S = string */
						 /* I = integer, P = preference file name */
						 /* C = colour */
    _s8 save_pref;				 /* if FALSE, needs tape name in front of this pref */
};

struct pref_info {
    char * name;
    _vptr opt;
    _s8   type;
    _s32  length;
    /* Types:  S = string
               I = integer (0..99)
	       L = log level (0..3)
	       B = block size (ie. divide by 1024)
               Y = yes or no (0..1)
               O = overwrite (0..2)
               T = tape type (0..2)
               C = compression (0..2)
    */
};


typedef _errstat (*file_passed_action) (struct file_info *fi, char * fn, struct info_file_data *i_data);
typedef void (*print_status) (WINDOW *mes_box, _s32 cur_in_vol, 
			      _s32 no_in_vol, _s32 vol,
			      _u32 file_size,
			      char *, _time_t start, _time_t t_current);
typedef _errstat (*chksum_err) (struct file_info *fi, char *fn);



/* For mtree.c */
      
typedef _u32 dskblk; 
typedef struct info_file_key keytype;		 /* key */
typedef struct {				 /* structure of a node */
	int n;					
	keytype keys[TREEORD+1];
	dskblk a[TREEORD+1];	
} info_file_datai;
typedef info_file_datai node;
