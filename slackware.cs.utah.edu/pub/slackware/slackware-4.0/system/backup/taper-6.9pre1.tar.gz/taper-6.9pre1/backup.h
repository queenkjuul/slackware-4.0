/*
   Time-stamp: <97/08/10 11:38:52 yusuf>

   $Id: backup.h,v 1.13 1997/08/10 04:25:22 yusuf Exp $
*/


/* Common variables */
extern int backup_select_files(char *cur_dir);
extern void select_entry_engine(struct file_info *fi, struct selected_entry *se, 
			 char *fn, int printbox, int add, int sel_method);
extern int select_entry_1(struct direntry *entry, char *s);
extern int exclude_entry_1(struct direntry *entry, char *s);
extern _s8 for_backup(char *s);
