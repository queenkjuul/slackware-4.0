/*
   Time-stamp: <97/04/20 09:48:17 yusuf>

   $Id: memory.h,v 1.7 1997/04/20 02:00:04 yusuf Exp $
*/



#include <stdlib.h>
#ifdef ASM_STRING
  #include <linux/string.h>
#else
  #include <string.h>
#endif

void init_memory(void);
void *my_malloc(size_t size);
void *my_realloc(void *block, size_t size);
void my_free(void *block);
void my_free_all(void);
						 /* have it, you'll have to do it yourself */
