/*   Time-stamp: <98/05/02 19:21:58 yusuf>

   $Id: common.h,v 1.46 1998/05/02 12:51:40 yusuf Exp $
*/


/* Functions in common.c */
extern char *trunc_filename(char *org, char *s, int c);
extern char *pr_filename(char *org, char *s, int c);
extern _s8 check_selected(_u32 rec);
extern void clear_ifd();
extern _errstat look_most_recent(char *s, struct info_file_data *i_data);
extern void mail_finish(char *prog);
extern void sendmail(void);
extern  void paint_main(void);
extern _errstat file_more_recent(char *s1, struct stat *b);	 /* in sel_backup.c */
extern _u8 make4len(char *s);
extern void init_common_vars(void);
extern _errstat get_statinfo(char *s, struct stat *b);
extern _errstat make_path(char *s);
extern _errstat make_dirs(char *s);
extern void make_fn(char *dest, char *src, _s32 no_in_vol);
extern _errstat check_device_names(void);
extern dev_t get_file_info(char *file, struct file_info *fi, _s8 chk, struct stat *ob);
extern _errstat process_info(WINDOW *mes, int line, _s8 calc_strip);
extern _errstat do_read_vol_dir(_u32 archive_id, char *tape, int mode, _s8 rvdir, _s8 exist, _s8 open_index);
extern char *convtime(char *s, time_t t1, time_t t2);
extern _s32 calc_checksum(int fd);
extern _s32 mem_calc_checksum(char *m, _s32 sz);
extern _errstat open_logfile(char *prog);
extern void close_logfile(char *prog);
extern void write_log(char *s);
extern void write_error_log(char *s);
extern void write_warning_log(char *);
extern void write_fatal_log(char *s);
extern _errstat read_volheader(struct volume_header *vh, _s8 read_vh, _s8 into_mem);
extern char *get_vh(struct volume_header *svh, _s32 vol);
extern _errstat traverse_volume(file_passed_action action, _s32 no_in_vol,
			   time_t t_start, WINDOW *mes_box, _s8 full_traverse, 
			   print_status ps, _s32 *files_passed, _s8 use_info,
			   chksum_err ce);
extern void change_dollar(char *s);
extern void mail_finish(char *prog);
extern void final_message(char *prog);
extern void print_title_line(void);
extern _errstat search_file(char *, _s32, struct info_file_data *i_data);
extern void backrest_init_windows(void);
extern void backrest_clear_screen(void);
extern void backrest_kill_windows(void);
extern void backrest_free_memory(void);
extern _errstat  backrest_do_mallocs(void);
extern void print_on_voldir_line(WINDOW *win, _s32 entry, int line, char ref);
extern void print_on_vol_dir(WINDOW *win, _s32 start, char *p_scroll);
extern void print_my_name(void);
extern _s8 chk_sel_excl(char *s);
extern char *get_line(char *s, FILE *f);
extern void backrest_save_backupset(int in_backup);
extern FILE *backrest_restore_backupset(char *fn);
extern _errstat bmessage_box(char *s, int type);
extern void backrest_paint(void);
extern _errstat exclude_list(char *fn, char *list);
extern _errstat exclude_compression(char *fn);
extern _errstat exclude_archive(char *fn);
typedef _errstat (*do_process_dir) (char *full_path, struct stat *b);
extern _errstat process_dir(WINDOW *mes, int ln, char *full_dir, char inc, do_process_dir dpd, _s8 send_dir);
extern _errstat init_buffers(_s8 reall);
extern void free_buffers(void);
extern void free_sems(void);
extern char *print_mb(char *s1, _u32 bytes);
extern char *print_kb(char *s1, _u32 bytes);
extern char *pr_size(char *s1, _u32 bytes);
extern _errstat fill_in_defaults(void);
extern void clear_main(void);
extern char *color_string(char fore, char back);
extern _errstat my_filecopy(int oldfd, int newfd);
extern _errstat my_rename(char *oldf, char *newf);
extern _errstat malloc_comp_buffers(void);
extern void free_comp_buffers(void);
extern  void taper_tmpnam(char *s);
extern _errstat setowners(char *s, _errstat ret, struct file_info *fi);
extern _errstat do_write_block(_s8 *buf_to_write, _s32 old_length, _s8 fc);
extern _errstat read_into_temp(struct file_info *fi, char *tmpf, char *fn);
extern _errstat read_u32(int fd, _u32 *x);
extern _errstat write_u32(int fd, _u32 *x);
extern void set_1s_timer();
extern void reset_timer();
extern void retrigger_alarm();

/* Info file struff */
extern _errstat read_volume_info();
extern void make_info_filename(char *info_file, _u32 archive_id);
extern _errstat open_one_index(char *info_file,_s8 must_exist, _s8 index);
extern _errstat open_info_file(char must_exit, _u32 archive_id, _s8 open_index);
extern _errstat write_info_rec(_s32 rec, struct info_file_data *i_data);
extern _errstat read_info_filename(off_t pos, char *name);
extern char *get_fn1(off_t pos);
extern char *get_fn2(off_t pos);
extern _errstat read_info_rec(_s32 rec, struct info_file_data *i_data);
extern void fill_info_key(struct info_file_data i_data, struct info_file_key *i_key);
extern _errstat add_to_info_index(struct info_file_data *id);
extern _errstat add_to_info(struct file_info *fi, char *name, char in_index);
extern _errstat write_info_file();
extern _errstat compress_info_file(_u32 archive_id);
extern void close_info_file();
extern void del_info_file(_u32 archive_id);
extern void strip_trailing_spaces(char *s);



/* From mtree.c */

#define TRAVERSE_TOP 0
#define TRAVERSE_BOTTOM 1
#define TRAVERSE_SEARCH 2
#define TRAVERSE_CONTINUE 3
extern  int insertb(int stackno, keytype *x, int index);
extern  int ntraverse(int stackno, keytype *start, keytype *end,
		 dskblk *rec, char command, int index);	/* Traverse the tree */
