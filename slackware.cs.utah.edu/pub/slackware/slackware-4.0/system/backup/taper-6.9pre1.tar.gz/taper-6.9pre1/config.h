/*
   Time-stamp: <97/04/20 15:13:35 yusuf>

   $Id: config.h,v 1.2 1997/06/29 01:31:25 yusuf Exp $
*/

#ifndef __CONFIG_H__

#ifdef GLIBC_2
#define umode_t mode_t
#endif

#define NULL ((void *)0)

#define __CONFIG_H__
/* These may have to change for other systems */
#define RETSIGTYPE void
#define MAJOR_IN_SYSMACROS 1
#define HAVE_SYS_MTIO_H 1
#define HAVE_UNISTD_H 1
#define STDC_HEADERS 1
#define HAVE_STRING 1
#define HAVE_FCNTL 1
#define HAVE_UTIME 1
#define HAVE_STRERROR 1
#define HAVE_VPRINTF 1
#define HAVE_ALLOCA 1
#define DIRENT 1

/* #define inline __inline__ */

/* Taper types */

typedef signed int _s32;			 
typedef unsigned int _u32;
typedef unsigned short _u16;
typedef signed short _s16;
typedef signed char _s8;
typedef unsigned char _u8;
typedef void * _vptr;

/* The types under Linux are:
 * These are now hard coded. There may be a problem if using a
 *   different machine where the formats are different. There will
 *   be no problem restoring to/from the tape, but the values may
 *   be meaningless. In a future version, I will store time as a
 *   day/month/year, modes as x/x/x etc.. to overcome this.
 *
 *    long _time_t
 *    unsigned short _gid_t
 *    unsigned short _uid_t 
 *    unsigned short _dev_t
 *    unsigned short _umode_t
 *    int pid_t
*/

typedef long _time_t;
typedef _u16 _gid_t;
typedef _u16 _uid_t;
typedef _u16 _dev_t;
typedef _u16 _umode_t;

typedef _s8 _errstat;


#endif
