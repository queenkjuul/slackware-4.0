/* library.h */

#ifndef LIBRARY_H_INCLUDED
#define LIBRARY_H_INCLUDED

#include <stdio.h>

char *fgetsz (char *s, int size, FILE *stream);
int fputsz (const char *s, FILE *stream);
void convert_to_printable (char *s);

#endif
