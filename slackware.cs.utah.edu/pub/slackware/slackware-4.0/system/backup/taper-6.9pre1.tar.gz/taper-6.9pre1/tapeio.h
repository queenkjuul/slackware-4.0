/*
   Time-stamp: <97/06/29 08:55:58 yusuf>

   $Id: tapeio.h,v 1.16 1997/06/29 01:31:26 yusuf Exp $
*/


/* Functions in tapeio.h */

extern char *make_tt(char tt);
extern _errstat tape_readheader(struct tape_header *t, _s8 allowz, int mode);
extern _errstat check_tape(WINDOW *mes, int line, _s32 tape_required);
extern _errstat tape_rewind_engine(int opendevice);
extern _errstat tape_rewind(void);
extern _errstat	tape_tell(_u32 *pos);
extern _errstat tape_seek(int toblock, char must_seek);
extern _errstat tape_eom();
extern _errstat tape_fsf(int count, int allowerr);
extern _errstat tape_erase(void);
extern _errstat tape_goto_block(WINDOW *mes, int line, _s32 block);
extern _errstat ntape_open(int mode);
extern _errstat tape_open(int mode);
extern _errstat write_tape_header(struct tape_header *tdh);
extern _errstat wait_finish_writing(void);
extern _errstat flush_buffers(void);
extern ssize_t tape_read(_vptr buf, ssize_t count);
extern ssize_t tape_write(_vptr buf, ssize_t count);
extern _errstat tape_read_s32(_s32 *x);
extern _errstat tape_read_namelen(char *s);
extern _errstat tape_read_fi(struct file_info *fi);
extern _errstat tape_read_volheader(struct volume_header *vh, int allower);
extern _errstat tape_write_fi(struct file_info *fi);
extern _errstat tape_write_namelen(char *s);
extern _errstat tape_write_volheader(struct volume_header *vh);
extern _errstat tape_close(void);
extern _errstat get_tape_header(WINDOW *mess, int line, struct tape_header *tdh, int mode);
extern _errstat is_regfile(int d);
extern _errstat tape_get_blk_size(_s32);
extern  void tape_set_blk_size(void);
extern _errstat read_volheader(struct volume_header *vh, _s8 read_vh, _s8 into_mem);
extern _errstat goto_end_vol(WINDOW *mes, int line, _s32 vol, _s32 at_vol, _s8 get_th, int mode);
