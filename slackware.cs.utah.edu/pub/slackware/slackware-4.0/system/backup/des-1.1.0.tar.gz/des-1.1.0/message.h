#ifndef __MESSAGE__H
#define __MESSAGE__H

extern char *VERSION;
extern char *COPYRIGHT;
extern long PRG_VERSION;

void checkVersion(long ver);

#endif


