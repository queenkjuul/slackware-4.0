#ifndef __SOMEF_DES__
#define __SOMEF_DES__

#include <stdio.h>
#include <crypt.h>
#include <string.h>
#ifdef MSDOS
  #include <alloc.h>
#else
  #include <malloc.h>
  #include <sys/types.h>
  #include <unistd.h>
#endif


void checkRead(int readRes);
void checkWrite(FILE *f);
void checkNull(FILE *f,char *name);

#define KEY_FILLER '\0'
#define BUF_SIZE    (16384-sizeof(long)-sizeof(long))
#define BUF_ALLOC   16384
#define MAX_PASS_SIZE 256
#define MAX_KEY_SIZE  256

#endif
