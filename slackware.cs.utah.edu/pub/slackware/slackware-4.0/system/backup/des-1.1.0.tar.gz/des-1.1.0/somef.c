#include <stdio.h>
#include <somef.h>

void checkRead(int readRes)
{
  if (readRes==-1) {
    fprintf(stderr,"\nFATAL   : error reading input stream\n");
    perror (       "MESSAGE ");
    exit(3);
  }
}

void checkWrite(FILE *f)
{
  if (ferror(f)) {
    fprintf(stderr,"\nFATAL   : error writing output stream\n");
    perror (       "MESSAGE ");
    exit(3);
  }
}

void checkNull(FILE *f,char *n)
{
  if (f==NULL) {
    fprintf(stderr,"\nFATAL   : Cannot open '%s'\n",n);
    perror (       "MESSAGE ");
    exit(3);
  }
}

