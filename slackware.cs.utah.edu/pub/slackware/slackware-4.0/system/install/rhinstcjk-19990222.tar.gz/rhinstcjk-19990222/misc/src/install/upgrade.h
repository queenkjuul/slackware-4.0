int ugFindUpgradePackages(struct pkgSet *psp, char *installRoot);
