#ifndef H_PKGS
#define H_PKGS

#include <rpmlib.h>

struct packageInfo {
    Header h;
    char * name, * group;
    char selected;
    char inmenu;
    int size;
    void * data;	/* this points to different things for different */
			/* install methods */
} ;

struct pkgSet {
    struct packageInfo ** packages;
    int numPackages;
};

struct component {
    char * name;
    int selected;
    int inmenu;
    struct pkgSet ps;
};

struct componentSet {
    struct component * comps;
    struct component * base;
    int numComponents;
} ;

int psVerifyDependencies(struct pkgSet * psp, int fixup);
int psUsingDirectory(char * dir, struct pkgSet * psp);
int psFromHeaderListDesc(int fd, struct pkgSet * psp, int noSeek);
int psFromHeaderListFile(char * file, struct pkgSet * psp);
int psSelectPackages(struct pkgSet * psp, struct componentSet * csp,
			 char * justComponent,
			 int goForward, int isUpgrade);
int psReadComponentsFile(char * filespec, struct pkgSet * psp, 
			 struct componentSet * csp);
void psFreeComponentSet(struct componentSet * csp);

/* upgrade code uses this for bsearch */
int pkgCompare(void * first, void * second);

#endif
