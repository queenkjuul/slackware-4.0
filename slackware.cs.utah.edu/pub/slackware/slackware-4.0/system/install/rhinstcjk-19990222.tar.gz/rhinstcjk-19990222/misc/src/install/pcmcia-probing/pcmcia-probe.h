#ifndef PCMCIA_PROBE_H
#define PCMICA_PROBE_H

char *pcmciaProbeController( void );

#endif
