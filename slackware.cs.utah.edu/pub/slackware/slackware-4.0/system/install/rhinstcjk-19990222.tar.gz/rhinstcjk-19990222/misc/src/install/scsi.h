#ifndef H_SCSI
#define H_SCSI

#include "devices.h"

int setupSCSIInterfaces(int forceConfig, struct driversLoaded ** dl,
			int automatic, int dir);
int scsiDeviceAvailable(void);
int scsiGetDevices(struct deviceInfo ** sdiPtr);
int ideGetDevices(struct deviceInfo ** sdiPtr);

#endif
