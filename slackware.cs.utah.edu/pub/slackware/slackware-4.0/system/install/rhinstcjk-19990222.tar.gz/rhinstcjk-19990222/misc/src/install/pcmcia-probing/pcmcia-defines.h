#ifndef PCMCIA_DEFINES_H
#define PCMCIA_DEFINES_H

#define I365_REG(slot, reg)    (((slot) << 6) + reg)

#define I365_IDENT	0x00	/* Identification and revision */
#define I365_IDENT_VADEM	0x08
#define VG468_MISC		0x3a	/* Miscellaneous */
#define VG468_MISC_GPIO		0x04	/* General-purpose IO */
#define VG468_MISC_DMAWSB	0x08	/* DMA wait state control */
#define VG468_MISC_VADEMREV	0x40	/* Vadem revision control */
#define VG468_MISC_UNLOCK	0x80	/* Unique register lock */
#define VG468_MISC_VADEMREV	0x40	/* Vadem revision control */
#define I365_IDENT_VADEM	0x08
#define PD67_CHIP_INFO		0x1f	/* Chip information */
#define PD67_INFO_CHIP_ID	0xc0
#define PD67_INFO_SLOTS		0x20	/* 0 = 1 slot, 1 = 2 slots */
#define TCIC_MODE		0x08
#define TCIC_MODE_PGMMASK	0x1f
#define TCIC_MODE_NORMAL	0x00
#define TCIC_MODE_PGMWR		0x01
#define TCIC_MODE_PGMRD		0x02
#define TCIC_MODE_PGMCE		0x04
#define TCIC_MODE_PGMDBW	0x08
#define TCIC_MODE_PGMWORD	0x10
#define TCIC_MODE_AUXSEL_MASK	0xe0
#define TCIC_MODE_PGMMASK	0x1f
#define TCIC_AUX		0x0E
#define TCIC_AUX_TCTL		(0<<5)
#define TCIC_AUX_PCTL		(1<<5)
#define TCIC_AUX_WCTL		(2<<5)
#define TCIC_AUX_EXTERN		(3<<5)
#define TCIC_AUX_PDATA		(4<<5)
#define TCIC_AUX_SYSCFG		(5<<5)
#define TCIC_AUX_ILOCK		(6<<5)
#define TCIC_AUX_TEST		(7<<5)
#define TCIC_MODE		0x08
#define TCIC_MODE_PGMMASK	0x1f
#define TCIC_MODE_NORMAL	0x00
#define TCIC_MODE_PGMWR		0x01
#define TCIC_MODE_PGMRD		0x02
#define TCIC_MODE_PGMCE		0x04
#define TCIC_MODE_PGMDBW	0x08
#define TCIC_MODE_PGMWORD	0x10
#define TCIC_MODE_AUXSEL_MASK	0xe0
#define TCIC_MODE_PGMMASK	0x1f
#define TCIC_AUX		0x0E
#define TCIC_AUX_TCTL		(0<<5)
#define TCIC_AUX_PCTL		(1<<5)
#define TCIC_AUX_WCTL		(2<<5)
#define TCIC_AUX_EXTERN		(3<<5)
#define TCIC_AUX_PDATA		(4<<5)
#define TCIC_AUX_SYSCFG		(5<<5)
#define TCIC_AUX_ILOCK		(6<<5)
#define TCIC_AUX_TEST		(7<<5)
#define TCIC_AUX_TEST		(7<<5)
#define TCIC_TEST_DIAG		0x8000
#define TCIC_AUX_ILOCK		(6<<5)
#define TCIC_ILOCKTEST_ID_MASK	0x7f00
#define TCIC_ILOCKTEST_ID_SH	8
#define TCIC_SCTRL		0x06
#define TCIC_SCTRL_ENA		0x01
#define TCIC_SCTRL_INCMODE	0x18
#define TCIC_SCTRL_INCMODE_HOLD	0x00
#define TCIC_SCTRL_INCMODE_WORD	0x08
#define TCIC_SCTRL_INCMODE_REG	0x10
#define TCIC_SCTRL_INCMODE_AUTO	0x18
#define TCIC_SCTRL_EDCSUM	0x20
#define TCIC_SCTRL_RESET	0x80
#define TCIC_SCTRL_RESET	0x80
#define TCIC_ADDR		0x02
#define TCIC_ADDR_REG		0x80000000
#define TCIC_ADDR_SS_SHFT	(TCIC_SS_SHFT+16)
#define TCIC_ADDR_SS_MASK	(TCIC_SS_MASK<<16)
#define TCIC_ADDR_INDREG	0x08000000
#define TCIC_ADDR_IO		0x04000000
#define TCIC_ADDR_MASK		0x03ffffff
#define TCIC_ID_DB86082		0x02
#define TCIC_ID_DB86082A	0x03
#define TCIC_ID_DB86082B	0x17
#define TCIC_ID_DB86082A	0x03
#define TCIC_ID_DB86084		0x04
#define TCIC_ID_DB86084A	0x08
#define TCIC_ID_DB86084A	0x08
#define TCIC_ID_DB86072		0x15
#define TCIC_ID_DB86184		0x14
#define TCIC_ID_DB86082B	0x17
#define TCIC_BASE		0x240

#endif
