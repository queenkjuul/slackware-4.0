#include <fcntl.h>
#include <newt.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <zlib.h>

#include "cpio.h"
#include "install.h"

/* librpm.a provides this */
int cpioInstallArchive(gzFile stream, void * mappings,
		       int numMappings, void * cb, void * cbData,
		       char ** failedFile);

struct cpioFileMapping {
    char * archivePath;
    char * fsPath;
    mode_t finalMode;
    uid_t finalUid;
    gid_t finalGid;
    int mapFlags;
};

#define CPIO_MAP_PATH           (1 << 0)

int installCpioFile(gzFile stream, char * cpioName, char * outName, int inWin) {
    struct cpioFileMapping map;
    int rc;
    char * failedFile;

    if (outName) {
	map.archivePath = cpioName;
	map.fsPath = outName;
	map.mapFlags = CPIO_MAP_PATH;
    }
    
    rc = cpioInstallArchive(stream, outName ? &map : NULL, 1, NULL, NULL, 
			    &failedFile);
    if (rc || access(outName, R_OK)) {
	if (inWin)
	    newtWinMessage("Error", "Ok", "Cannot find archive member %s.\n", 
			    cpioName);
	else
	    printf("Cannot find archive member %s.\n", cpioName);
	return INST_ERROR;
    }

    return 0;
}
