#ifndef H_HINTS
#define H_HINTS

#define HINT_SKIPNTSYSV		(1 << 0)
#define HINT_AUTOFORMAT		(1 << 1)
#define HINT_SKIPPRINTER	(1 << 2)
#define HINT_SKIPBOOTDISK	(1 << 3)
#define HINT_AUTOSWAP		(1 << 4)
#define HINT_SKIPBOOTLOADER	(1 << 5)
#define HINT_FORCEDDRUID	(1 << 6)
#define HINT_AUTOSCSI		(1 << 7)
#define HINT_NOLOGMESSAGE	(1 << 8)

struct hintsBootloader {
    char * options;
    int flags;
};

struct hintsPartitioning {
    int flags;
    struct attemptedPartition * attempts;
};

struct hints {
    int flags;
    struct hintsBootloader bootloader;
    struct hintsPartitioning partitioning;
    char * component;
};

void ksToHints(struct hints * hints);

#endif
