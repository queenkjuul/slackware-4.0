#ifndef _H_LOG
#define _H_LOG

#include <stdio.h>

extern FILE * log;
extern int logfd;

extern int testing;
extern int hackDisk;

#define logDebugMessage(a) doLogDebugMessage a

void logMessage(char * s, ...);
void doLogDebugMessage(char * s, ...);
void openLog(int useLocal);
void closeLog(void);

#endif
