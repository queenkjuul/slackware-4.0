#ifndef H_DOIT
#define H_DOIT

#include "methods.h"
#include "pkgs.h"

int doInstall(struct installMethod * method, char * rootPath,
	      struct pkgSet * psp, char * netSharedPath, char * keymap,
	      int upgrade);

#endif H_DOIT
