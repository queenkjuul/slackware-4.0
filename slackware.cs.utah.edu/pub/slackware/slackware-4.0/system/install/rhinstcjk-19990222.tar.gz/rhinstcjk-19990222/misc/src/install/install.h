#ifndef H_INSTALL
#define H_INSTALL

#define INST_CANCEL	-1
#define INST_OKAY	0
#define INST_ERROR	1
#define INST_NOP	2

extern int expert;
extern int kickstart;

#endif
