#ifndef H_KICKSTART

#define KS_CMD_NONE	 0
#define KS_CMD_NFS	 1
#define KS_CMD_INSTALL	 2
#define KS_CMD_UPGRADE	 3
#define KS_CMD_ROOTPW	 4
#define KS_CMD_LILO	 5
#define KS_CMD_KEYBOARD	 6
#define KS_CMD_PART      7
#define KS_CMD_CLEARPART 8
#define KS_CMD_MOUSE	 9
#define KS_CMD_TIMEZONE  10
#define KS_CMD_ZEROMBR   11
#define KS_CMD_XCONFIG   12
#define KS_CMD_CDROM     13
#define KS_CMD_DEVICE    14
#define KS_CMD_LANG	 15
#define KS_CMD_NETWORK	 16

struct ksPackage {
    char * name;
    int isComponent;
};

int ksReadCommands(char * cmdFile);
int ksGetCommand(int cmd, char ** last, int * argc, char *** argv);
void ksGetPackageList(struct ksPackage ** list, int * count);
int ksRunPost(void);
int ksHasCommand(int cmd);

#endif
