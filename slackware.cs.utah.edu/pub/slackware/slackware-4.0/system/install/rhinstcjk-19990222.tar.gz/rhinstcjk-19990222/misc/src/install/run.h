#ifndef H_RUN
#define H_RUN

enum runType { RUN_NOLOG, RUN_LOG };

int runProgram(enum runType, char * name, char ** args);
int runProgramRoot(enum runType, char * root, char * name, char ** args);
int runProgramIORoot(enum runType, char * root, char * name, char ** args, 
		 char * in, char ** out);	/* out must be free()d */
int runProgramIO(enum runType, char * name, char ** args, char * in, 
		 char ** out);		/* out must be free()d */

#endif
