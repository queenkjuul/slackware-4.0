#ifndef H_SYSLOG
#define H_SYSLOG

int handleSyslogSocket(char * rootPath);

#endif
