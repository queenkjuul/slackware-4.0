#include "lang.h"

#define _(foo) translateString((foo))
#define N_(foo) (foo)
#define F_(foo) translateString((foo))
