#include <fcntl.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/kd.h>
#include <unistd.h>

void die(char * mess) {
    perror(mess);
    exit(1);
}

int main(void) {
    char font[8192];
    char map[E_TABSZ];
    int fd;

    if ((fd = open("/dev/tty1", O_RDONLY)) < 0)
	die("open");

    if (ioctl(fd, GIO_FONT, font))
	die("GIO_FONT"); 

    if (ioctl(fd, GIO_SCRNMAP, map))
	die("GIO_SCRNMAP"); 

    write(1, font, sizeof(font));
    write(1, map, sizeof(map));

    return 0;
}
