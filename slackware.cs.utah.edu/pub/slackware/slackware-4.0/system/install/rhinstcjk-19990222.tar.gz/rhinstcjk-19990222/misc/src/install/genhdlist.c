#include <alloca.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <rpmlib.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define FILENAME_TAG 1000000

int tags[] =  { RPMTAG_NAME, RPMTAG_VERSION, RPMTAG_RELEASE, RPMTAG_SERIAL,
		RPMTAG_FILENAMES, RPMTAG_FILESIZES, RPMTAG_GROUP,
		RPMTAG_REQUIREFLAGS, RPMTAG_REQUIRENAME, RPMTAG_REQUIREVERSION,
		RPMTAG_DESCRIPTION, RPMTAG_SUMMARY, RPMTAG_PROVIDES,
		RPMTAG_SIZE, RPMTAG_OBSOLETES };
int numTags = sizeof(tags) / sizeof(int);

int main(int argc, char ** argv) {
    char buf[300];
    DIR * dir;
    int outfd;
    struct dirent * ent;
    int fd, rc, isSource;
    Header h;
    int count, type;
    int i;
    void * ptr;

    if (argc != 2) {
	fprintf(stderr, "usage: genhdlist <dir>\n");
	exit(1);
    }

    strcpy(buf, argv[1]);
    strcat(buf, "/RedHat/RPMS");

    dir = opendir(buf);
    if (!dir) {
	fprintf(stderr,"error opening directory %s: %s\n", buf,
		strerror(errno));
	return 1;
    }
    chdir(buf);

    strcpy(buf, argv[1]);
    strcat(buf, "/RedHat/base/hdlist");
    
    outfd = open(buf, O_WRONLY | O_TRUNC | O_CREAT, 0644);
    if (outfd < 0) {
	fprintf(stderr,"error creating file %s: %s\n", buf, strerror(errno));
	return 1;
    }

    errno = 0;
    ent = readdir(dir);
    if (errno) {
	perror("readdir");
	return 1;
    }

    while (ent) {
	if (!(ent->d_name[0] == '.' && (ent->d_name[1] == '\0' || 
	    ((ent->d_name[1] == '.') && (ent->d_name[2] == '\0'))))) {
	    fd = open(ent->d_name, O_RDONLY);

	    if (fd < 0) {
		perror("open");
		exit(1);
	    }

	    rc = rpmReadPackageHeader(fd, &h, &isSource, NULL, NULL);

	    headerRemoveEntry(h, RPMTAG_POSTIN);
	    headerRemoveEntry(h, RPMTAG_POSTUN);
	    headerRemoveEntry(h, RPMTAG_PREIN);
	    headerRemoveEntry(h, RPMTAG_PREUN);
	    headerRemoveEntry(h, RPMTAG_FILEMD5S);
	    headerRemoveEntry(h, RPMTAG_FILELINKTOS);
	    headerRemoveEntry(h, RPMTAG_FILEUSERNAME);
	    headerRemoveEntry(h, RPMTAG_FILEGROUPNAME);
	    headerRemoveEntry(h, RPMTAG_FILEVERIFYFLAGS);
	    headerRemoveEntry(h, RPMTAG_FILESIZES);
	    headerRemoveEntry(h, RPMTAG_FILERDEVS);
	    headerRemoveEntry(h, RPMTAG_FILEMTIMES);
	    headerRemoveEntry(h, RPMTAG_FILEDEVICES);
	    headerRemoveEntry(h, RPMTAG_FILEINODES);
	    headerRemoveEntry(h, RPMTAG_FILELANGS);
	    headerRemoveEntry(h, RPMTAG_FILEFLAGS);
	    headerRemoveEntry(h, RPMTAG_TRIGGERSCRIPTS);
	    headerRemoveEntry(h, RPMTAG_TRIGGERVERSION);
	    headerRemoveEntry(h, RPMTAG_TRIGGERFLAGS);
	    headerRemoveEntry(h, RPMTAG_TRIGGERNAME);
	    headerRemoveEntry(h, RPMTAG_CHANGELOGTIME);
	    headerRemoveEntry(h, RPMTAG_CHANGELOGNAME);
	    headerRemoveEntry(h, RPMTAG_CHANGELOGTEXT);
	    headerRemoveEntry(h, RPMTAG_ICON);
	    headerRemoveEntry(h, RPMTAG_GIF);
	    headerRemoveEntry(h, RPMTAG_VENDOR);
	    headerRemoveEntry(h, RPMTAG_EXCLUDE);
	    headerRemoveEntry(h, RPMTAG_EXCLUSIVE);
	    headerRemoveEntry(h, RPMTAG_DISTRIBUTION);
	    headerRemoveEntry(h, RPMTAG_VERIFYSCRIPT);

	    headerAddEntry(h, FILENAME_TAG, RPM_STRING_TYPE, ent->d_name, 1);

	    headerWrite(outfd, h, HEADER_MAGIC_YES);
	    headerFree(h);
	    close(fd);
	}

	errno = 0;
	ent = readdir(dir);
	if (errno) {
	    perror("readdir");
	    return 1;
	}
    } 

    closedir(dir);
    close(outfd);

    return 0;
}
