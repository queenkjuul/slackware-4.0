#ifndef H_CPIO
#define H_CPIO

#include <zlib.h>

int installCpioFile(gzFile stream, char * cpioName, char * outName, int inWin);

#endif
