#ifndef H_MKSWAP
#define H_MKSWAP

#include "fs.h"

int enableswap(char * device_name, int size, int checkBlocks);
int activeSwapSpace(struct partitionTable * table, struct fstab * finalFstab,
		    int forceFormat);

extern int canEnableSwap;

#endif
