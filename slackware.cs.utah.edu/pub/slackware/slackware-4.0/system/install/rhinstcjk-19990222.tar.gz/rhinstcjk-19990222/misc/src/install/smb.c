/*
 *  smbmount.c
 *
 *  Copyright (C) 1995, 1996 by Paal-Kr. Engstad and Volker Lendecke
 *
 *  Hacked by msf@redhat.com
 *
 */

#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <pwd.h>
#include <grp.h>
#include <sys/socket.h>
#include <sys/param.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/stat.h>
#include <sys/types.h>
/* #include <sys/wait.h> */  /* generates a warning here */
extern pid_t waitpid(pid_t, int *, int);
#include <sys/errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <ctype.h>
#include <stdlib.h>
#include <sys/mount.h>
#include <mntent.h>

#include "dns.h"
#include "smb_mount.h"

#ifndef MS_MGC_VAL
#define MS_MGC_VAL 0xC0ED0000
#endif

#define SMB_PORT 139

#include "log.h"


/* probably have your own version of this? */

static void
str_upper(char *name)
{
	while (*name)  {
		*name = toupper(*name);
		name = name + 1;
	}
}

/****************************************
 Mount smb filesystem


   server is name of SMB server - should NOT have domain name, etc 
                                  as this is a NetBIOS name. For
                                  machines running samba, is normally
                                  the same as the hostname (sans domain)

   share is the name of the SMB share we are trying to mount

   user is the user to login as on SMB server.

   password is corresponding password.

   client is the NetBIOS name of machine attempting the mount. Just
                 strip the hostname of domain to get this.

   mount_point - self explanatory

Way I'd do this - look at printtool (new one of course) and add a SMB printer.
                  Ask for stuff just like I do.

End of docs 
*****************************************/

int 
smbmount(char *server, char *share, char *user, char *password, char *client, char *mount_point)
{
        struct smb_mount_data data;
	char hostname[MAXHOSTNAMELEN + 1];

        int um;
	unsigned int flags;

	/*        
	struct stat st;
	unsigned int flags;
	*/

	memset(&data, 0, sizeof(struct smb_mount_data));

	memset(hostname, '\0', MAXHOSTNAMELEN+1);
	gethostname(hostname, MAXHOSTNAMELEN);

	data.version = SMB_MOUNT_VERSION;

        /* getuid() gives us the real uid, who may umount the fs */
        data.mounted_uid = getuid();

	sprintf(data.service, "\\\\%s\\%s", server, share);
        str_upper(data.service);

        strcpy(data.root_path, "/");
	strcpy(data.username, user);

	/* msf - this doesn't make sense during the install */
#if 0
        if (getenv("USER")) {
                strcpy(data.username, getenv("USER"));
                str_upper(data.username);
        }

        if (data.username[0] == 0 && getenv("LOGNAME"))
        {
                strcpy(data.username,getenv("LOGNAME"));
                str_upper(data.username);
        }
#endif

        data.max_xmit = 4070;   /* allocate at most one page in kernel */
        data.uid = getuid();
        data.gid = getgid();
        um = umask(0);
        umask(um);
        data.file_mode = (S_IRWXU|S_IRWXG|S_IRWXO) & ~um;
        data.dir_mode  = 0;
	data.addr.sin_family = AF_INET;
	data.addr.sin_port = htons(SMB_PORT);

	/*	strcpy(data.domain, "?"); */

	if (mygethostbyname(server, &data.addr.sin_addr)) {
	  logMessage("%s: unknown host", server);
	  return -1;
	}
	
	data.fd = socket(AF_INET, SOCK_STREAM, 0);
	if (data.fd == -1) {
		logMessage("smb socket: %s", strerror(errno));
                return -1;
	}
	

        if (data.dir_mode == 0) {
                data.dir_mode = data.file_mode;
                if ((data.dir_mode & S_IRUSR) != 0)
                        data.dir_mode |= S_IXUSR;
                if ((data.dir_mode & S_IRGRP) != 0)
                        data.dir_mode |= S_IXGRP;
                if ((data.dir_mode & S_IROTH) != 0)
                        data.dir_mode |= S_IXOTH;
        }

	strcpy(data.password, password);

	str_upper(data.password);

        if (data.server_name[0] == '\0')
	{
                if (strlen(server) > sizeof(data.server_name)-1)
		{
                        logMessage("server name too long as a netbios name");
                        return -1;
                }
                strcpy(data.server_name, server);
                str_upper(data.server_name);
        }

	
	strcpy(data.client_name, client);
  
	flags = MS_MGC_VAL;

	if (mount(NULL, mount_point, "smbfs",
                  flags, (char *)&data) < 0) {
		logMessage("smb mount error: %s", strerror(errno));
	        close(data.fd);
		return -1;
	}

        close(data.fd);


	return 0;
}	
