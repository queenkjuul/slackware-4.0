#include "pkgs.h"
#include "upgrade.h"
#include "log.h"

int testing = 0;
int expert = 0;
int kickstart = 0;

void main(void)
{
    struct pkgSet ps;

    putenv("DEBUG=y");
    testing = 1; 
    openLog();
    testing = 0;
    
    psFromHeaderListFile("/tmp/install/hdlist", &ps);
    
    ugFindUpgradePackages(&ps, "/");

    closeLog();
}
