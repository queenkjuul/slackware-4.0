int 
smbmount(char *server, char *share, char *user, char *password, char *client, char *mount_point);
 
