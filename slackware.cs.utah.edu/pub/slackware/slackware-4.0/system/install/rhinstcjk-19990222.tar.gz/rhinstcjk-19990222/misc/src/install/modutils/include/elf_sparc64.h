/* Machine-specific elf macros for the Sparc.  */
#ident "$Id: elf_sparc64.h,v 1.1.1.1 1998/01/06 20:51:07 ewt Exp $"

#define ELFCLASSM	ELFCLASS64
#define ELFDATAM	ELFDATA2MSB

#define MATCH_MACHINE(x)  (x == EM_SPARC64)

#define SHT_RELM	SHT_RELA
#define Elf64_RelM	Elf64_Rela

#ifndef ELF64_R_SYM
#define ELF64_R_SYM(x)	((x) >> 32)
#define ELF64_R_TYPE(x)	((unsigned)(x))
#endif

#ifndef ELF64_ST_BIND
#define ELF64_ST_BIND(x)	((x) >> 4)
#define ELF64_ST_TYPE(x)	((x) & 0xf)
#endif

