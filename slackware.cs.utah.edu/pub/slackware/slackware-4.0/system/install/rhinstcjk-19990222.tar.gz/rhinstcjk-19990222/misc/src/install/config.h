#ifndef H_CONFIG
#define H_CONFIG

int timeConfig(char * rootPath);
int mouseConfig(char * rootPath);
int xfree86Config(char * rootPath, char *mode);
void configPCMCIA(char * rootPath, char * pcic);
int servicesConfig(char * rootPath);

#endif
