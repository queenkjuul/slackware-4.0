int kernelCopy(char * filename);
