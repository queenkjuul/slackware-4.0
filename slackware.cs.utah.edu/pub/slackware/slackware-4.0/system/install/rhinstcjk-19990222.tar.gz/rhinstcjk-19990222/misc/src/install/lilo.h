#ifndef H_LILO
#define H_LILO

#include "hd.h"
#include "fs.h"

#define		LILO_ON_MBR		(1 << 0)
#define		LILO_ON_PARTITION	(1 << 1)
#define		LILO_USE_LINEAR		(1 << 2)
#define		LILO_USE_OPTIONS	(1 << 3)

int installLilo(char * prefix, struct partitionTable table, struct fstab fstab,
		char * kernelVersion, int flags, char * options);
int makeBootdisk(char * prefix, char * kernelVersion);

#endif
