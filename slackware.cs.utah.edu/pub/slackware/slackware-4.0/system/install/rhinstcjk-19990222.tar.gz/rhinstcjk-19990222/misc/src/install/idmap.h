#ifndef H_IDMAP

char * idSearchByUid(long int id);
char * idSearchByGid(long int id);
int idInit(void);

#endif
