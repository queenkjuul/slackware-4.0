#ifndef H_OTHERINSMOD
#define H_OTHERINSMOD

int ourInsmodCommand(int argc, char ** argv);

#endif
