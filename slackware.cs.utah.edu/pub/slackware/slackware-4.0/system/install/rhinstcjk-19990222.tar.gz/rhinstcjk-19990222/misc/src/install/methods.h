#ifndef H_METHOD
#define H_METHOD

#include "hd.h"
#include "fs.h"
#include "net.h"
#include "pkgs.h"

struct installMethod {
    char * name;
    char * abbrev;
    int rmFiles;
    int (*prepareImage)(struct installMethod * method, struct netInfo * netc,
		        struct intfInfo * intf, int forceSupp,
			struct driversLoaded ** dl);
    int (*prepareRoot)(struct installMethod * method, 
		       struct partitionTable table, struct netInfo * netc,
		       struct intfInfo * intf, struct driversLoaded ** dl);
    int (*getFile)(struct installMethod * method, char * name, 
			char ** realName);
    int (*getPackageSet)(struct installMethod * method,
			 struct pkgSet * ps);
    int (*getComponentSet)(struct installMethod * method,
			   struct pkgSet * ps,
			   struct componentSet * cs);
    int (*prepareMedia)(struct installMethod * method, struct fstab * fstab);
    void * data;		/* isn't saved between early and late */
};

int chooseInstallMethod(int forceSupp, struct installMethod ** method, 
		        struct netInfo * netc,
		        struct intfInfo * intf, struct driversLoaded ** dl);
struct installMethod * findInstallMethod(char * argptr);
int loadFloppyRoot(struct installMethod * method);
int floppyRoot(struct installMethod * method, struct netInfo * netc,
		struct intfInfo * intf, int useSupp,
		struct driversLoaded ** dl);
int loadCjkRoot(struct installMethod * method);
int cjkRoot(struct installMethod * method, struct netInfo * netc,
		struct intfInfo * intf, int useSupp,
		struct driversLoaded ** dl);

#endif
