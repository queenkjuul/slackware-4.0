#include <stdio.h>

#include "pciprobe.h"



void printpciDevices( int n, struct pciDevice **devs, char *type ) {
    int i, j;

    if (n<0) {
	fprintf(stderr,
		"System error - probably means you dont have a PCI mboard!\n");
	exit(1);
    } else if (n==0) {
	printf("No PCI devices of type %s found.\n", type);
    } else {
	for (i=0; i<n; i++) {
	    printf("Card %d:    %d matches found in db\n", i, devs[i]->nhits);
	    for (j=0; j<devs[i]->nhits; j++) {
		printf("       Match %d:  |%s| -> |%s|\n",
		       j, devs[i]->name[j], devs[i]->module[j]);
	    }
	}
    }
}

int main () {

    int i, n;
    struct pciDevice **devs;
    
    printf("Probing for ETHERNET devices....\n");
    n = pciProbeDevice(PCI_ETHERNET, &devs);
    printpciDevices(n, devs, "Ethernet");
    for (i=0; i<n; i++)
	pciFreeDevice(devs[i]);
    
    printf("\nProbing for SCSI devices....\n");
    n = pciProbeDevice(PCI_SCSI, &devs);
    printpciDevices(n, devs, "SCSI");
    for (i=0; i<n; i++)
	pciFreeDevice(devs[i]);

    printf("\nProbing for VIDEO devices....\n");
    n = pciProbeDevice(PCI_VIDEO, &devs);
    printpciDevices(n, devs, "Video");
    for (i=0; i<n; i++)
	pciFreeDevice(devs[i]);

    return 0;
}
