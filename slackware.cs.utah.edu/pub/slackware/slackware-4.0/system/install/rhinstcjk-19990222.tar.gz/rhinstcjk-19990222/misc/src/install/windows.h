#ifndef H_WINDOWS
#define H_WINDOWS

void errorWindow(char * str);
void winStatus(int width, int height, char * title, char * text, ...);

#endif
