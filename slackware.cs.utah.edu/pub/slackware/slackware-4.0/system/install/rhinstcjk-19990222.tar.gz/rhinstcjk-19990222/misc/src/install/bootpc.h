#ifndef H_BOOTP
#define H_BOOTP

#include "net.h"

char * doBootp(int timeout, struct intfInfo * intf, struct netInfo * net);
char * doDhcp(int timeout, struct intfInfo * intf, struct netInfo * net,
		int shouldDaemonize);
void setMissingIpInfo(struct intfInfo * intf);

#endif
