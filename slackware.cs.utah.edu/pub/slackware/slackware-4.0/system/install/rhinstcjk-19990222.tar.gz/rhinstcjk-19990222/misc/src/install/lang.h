#ifndef LANG_H
#define LANG_H

char * translateString(char * str);
int chooseLanguage(void);
void setDefaultLanguage(int stage);
void loadLanguageStage(int stage, char * file);
int writeLangInfo(char * rootPath);

int needsKon(void);
void setupKon(void);
void execvKon(char *path, char **argv);
void loadKonFont(void);

#endif
