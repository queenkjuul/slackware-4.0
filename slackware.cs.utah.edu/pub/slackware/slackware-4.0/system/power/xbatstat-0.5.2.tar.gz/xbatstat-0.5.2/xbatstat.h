/*
 *	xbatstat  the Linux battery status checker for X.
 *						       version 0.5.2
 *						        Jan. 2, 1997
 *      (c) Daisuke SUZUKI <daisuke@jaist.ac.jp/daisuke@linux.or.jp>
 */

FL_FORM *apm_form;
FL_OBJECT *apm_life, *apm_status, *apm_batt;

void create_form(int , int);
void life_cb(FL_OBJECT *, long);
int read_cb( XEvent * , void *);
void usage(void);
