#!/bin/sh

XBM_DEST=/usr/X11/include/X11/bitmaps
PRG_DEST=/usr/local/bin

install -m 0444 -o root -g root *.xbm $XBM_DEST
install -m 0755 -o root -g root xbattery $PRG_DEST

