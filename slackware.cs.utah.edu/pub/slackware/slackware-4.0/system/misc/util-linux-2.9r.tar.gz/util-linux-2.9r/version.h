#define UTIL_LINUX_VERSION	"2.9r"

const char * const util_linux_version = "util-linux " UTIL_LINUX_VERSION;
