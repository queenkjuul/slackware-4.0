#include <config.h>
#include "version.h"
const char *version_string = "GNU sh-utils+sec 1.12";
