Article 28977 of comp.os.linux:
Path: samba!concert!gatech!howland.reston.ans.net!spool.mu.edu!uunet!news.claremont.edu!nntp-server.caltech.edu!thefru
From: thefru@cco.caltech.edu (Your Worst Nightmare)
Newsgroups: comp.os.linux
Subject: MS-Cardfile Reader for Linux
Date: 1 Mar 1993 17:30:14 GMT
Organization: California Institute of Technology, Pasadena
Lines: 99
Message-ID: <1mth76INN54b@gap.caltech.edu>
NNTP-Posting-Host: punisher.caltech.edu

Hi all!

I don't know if this is the right group to put this on or if c.o.l.a is since I
don't nn too often.  I found out a long time ago that it's harmful for my GPA.

I also don't know how many of you out there share my situation, but I'm an avid
MS-Windows user.  Mostly for the sake of writing papers, spreadsheets etc.
While linux serves as my programming environment (and a superb one at that.)

The problem I had was that I couldn't access my cardfile data from linux, so I
wrote a little program that does it and prints it out to stdout.  The format is
so trivial!  I'm not sure if dosemu can do MS-Win yet, since I haven't
installed it.  If it can, this is a moot point.  If it can't - enjoy!

Oh yeah, one last thing.  This program is really rough and is mostly one big
hack (hehe).  I envision, one day, an x-app that will simulate cardfile, so you
can also add stuff in.  Again, the usefulness may be nil if dosemu runs it
well, but hey, I'll look into that some other morning when I haven't slept for
two days... ;)

Allright - here's the source code for cardread.c:

/* CardRead V1.0
 * A program that will read and print out Microsoft Cardfile files.
 * By Dan 'Fru' Frumin
 * March 1st, 1993
 */

#include <stdio.h>
#include <strings.h>

typedef struct {
  char name[46];
  char data[1000];
  } INFO;

main(int argc, char **argv) {
  FILE *fp;
  char buf[81];
  INFO *data;
  int reccount, counter, len;
  char c;
  int i;

  if (argc != 2) {
    printf("Usage: %s file\n", argv[0]);
    exit(-1);
    }

  fp = fopen(argv[1], "r");
  if (!fp) {
    printf("Error: %s couldn't open %s.\n", argv[0], argv[1]);
    exit(-1);
    }

  fgets(buf, 4, fp);
  if (strcmp(buf,"MGC")) {
    printf("Error: %s isn't in Microsoft Cardfile format.\n", argv[1]);
    exit(-1);
    }

  reccount = fgetc(fp);
  data = (INFO *) malloc (reccount * sizeof(INFO));

  for (i = 0; i < 12; i++, fgetc(fp));

  for (counter = 0; counter < reccount; counter++) {
    fgets(data[counter].name, 46, fp);
    if (data[counter].name[0] == 0)
      sprintf(data[counter].name, "NULL");
    if (counter < reccount - 1)
      for (i = 0; i < 7; i++, fgetc(fp));
    }

  counter = 0;
  i = 0;
  while((c = fgetc(fp)) != EOF) {
    data[counter].data[i] = c;
    i++;
    if (c == 0) {
      for (i = 0; i < 3; i++, fgetc(fp));
      counter++;
      i=0;
      }
    }

  fclose(fp);

  printf("=============================================\n");
  for (counter = 0; counter < reccount; counter++) {
    printf("%s\n", data[counter].name);
    printf("---------------------------------------------\n");
    printf("%s\n", data[counter].data);
    printf("\n");
    printf("=============================================\n");
    }
  }




