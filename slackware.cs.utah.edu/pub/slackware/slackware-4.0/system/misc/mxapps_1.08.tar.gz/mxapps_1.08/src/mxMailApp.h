////////////////////////////////////////////////////////////////////////////////
//
//	Class : mxMailApp
//
//	Author : Andy Jefferson
//
//	Description :
//		mxMailApp is the application class for mxMail
//
//	Public Methods :
//		(Constructor) requires :-
//			app_name	Application Name (resource specifier)
//			app_version	Application Version
//			app_title	Application title (text description)
//
//	Limitations :
//
////////////////////////////////////////////////////////////////////////////////
#ifndef _mxMailApp_h
#define _mxMailApp_h
#ifdef __cplusplus

#include <std/string.h>
#include "akApp.h"
#include "akSound.h"

class mxMailApp : public akApp
{
	public:

		// Constructor,destructor

		mxMailApp(const string app_name,
			  const string app_version,
			  const string app_title);
		~mxMailApp();

	private:

		akSound		*_introSound;
};

#endif
#endif
