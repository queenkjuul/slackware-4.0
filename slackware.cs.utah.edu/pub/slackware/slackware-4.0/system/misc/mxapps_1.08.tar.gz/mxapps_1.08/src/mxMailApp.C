#include "mxMailApp.h"
#include "mxMail.h"
#include "mxSetup.h"

akApp		*myApp  = new mxMailApp("mxMail","1.08","Linux Mail Environment");
akWindow	*window = new mxMail("mxMail");

////////////////////////////////////////////////////////////////////////////////
//
//	Constructor
//
////////////////////////////////////////////////////////////////////////////////
mxMailApp::mxMailApp(const string app_name,
		     const string app_version,
		     const string app_title)
	:akApp(app_name,app_version,app_title)
{
	theMxSetup = new mxSetup;

	if (theMxSetup->introSound())
	  {
	   string soundfile = theMxSetup->audioDirectory() + "introSound";
	   _introSound = new akSound(soundfile);
	   _introSound->play();
	  }
}
////////////////////////////////////////////////////////////////////////////////
//
//	Destructor
//
////////////////////////////////////////////////////////////////////////////////
mxMailApp::~mxMailApp()
{
	if (_introSound)
	  delete _introSound;
	if (theMxSetup)
	  delete theMxSetup;
	theMxSetup = 0;
}
