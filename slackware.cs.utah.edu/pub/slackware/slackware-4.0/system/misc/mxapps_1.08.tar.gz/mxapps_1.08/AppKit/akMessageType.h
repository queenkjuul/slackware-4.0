////////////////////////////////////////////////////////////////////////////////
//
//	Author : Andy Jefferson
//
//	Description :
//		This file contains the definition of the message types accepted
//		by the akMessageLine and akMessageArea classes.
//
////////////////////////////////////////////////////////////////////////////////
#ifndef _akMessageType_h
#define _akMessageType_h
#ifdef __cplusplus

typedef enum
{
	AK_ERROR,
	AK_WARNING,
	AK_INFO,
	AK_CONTINUE
} akMessageType;

#endif
#endif
