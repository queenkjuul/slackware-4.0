#include <iostream.h>
#include "mxNetApp.h"
#include "mxNet.h"
#include "mxSetup.h"

akApp		*myApp  = new mxNetApp("mxNet","1.00","Linux Internet Environment");
akWindow	*window = new mxNet("mxNet");
////////////////////////////////////////////////////////////////////////////////
//
//	Constructor
//
////////////////////////////////////////////////////////////////////////////////
mxNetApp::mxNetApp(const string app_name,
		   const string app_version,
		   const string app_title)
	:akApp(app_name,app_version,app_title)
{
	theMxSetup = new mxSetup;

	if (theMxSetup->introSound())
	  {
	   string soundfile = theMxSetup->audioDirectory() + "introSound";
	   _introSound = new akSound(soundfile);
	   _introSound->play();
	  }
}
////////////////////////////////////////////////////////////////////////////////
//
//	Destructor
//
////////////////////////////////////////////////////////////////////////////////
mxNetApp::~mxNetApp()
{
	if (_introSound)
	  delete _introSound;
	if (theMxSetup)
	  delete theMxSetup;
	theMxSetup = 0;
}
