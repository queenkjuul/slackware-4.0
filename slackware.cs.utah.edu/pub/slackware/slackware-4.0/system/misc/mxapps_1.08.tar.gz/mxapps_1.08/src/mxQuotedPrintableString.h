////////////////////////////////////////////////////////////////////////////////
//
//	Class : mxQuotedPrintableString
//
//	Author : Andy Jefferson
//
//	Description :
//		mxQuotedPrintableString provides encode/decode methods for a
//		string.
//
//	Public Methods :
//
//	Limitations :
//
////////////////////////////////////////////////////////////////////////////////
#ifndef mxQuotedPrintableString_h
#define mxQuotedPrintableString_h
#ifdef __cplusplus

#include <std/string.h>
#include <bool.h>

class mxQuotedPrintableString
{
	public:

		// Constructor

		mxQuotedPrintableString();

		// Methods

		string		decode(string,bool text_mode=TRUE);

	private:

		// Internal methods

		int	isEndOfLine(int);

		// Internal static data (Decode)

		static int		_unHex0[256];
		static int		_unHex1[256];
		static unsigned char	_magic[256];

		static bool		_initial;
};

#endif
#endif
