#include "mxFtpApp.h"
#include "mxFtp.h"
#include "mxSetup.h"

akApp		*myApp  = new mxFtpApp("mxFtp","1.03","Linux FTP Environment");
akWindow	*window = new mxFtp("mxFtp");
////////////////////////////////////////////////////////////////////////////////
//
//	Constructor
//
////////////////////////////////////////////////////////////////////////////////
mxFtpApp::mxFtpApp(const string app_name,
		   const string app_version,
		   const string app_title)
	:akApp(app_name,app_version,app_title)
{
	theMxSetup = new mxSetup;

	if (theMxSetup->introSound())
	  {
	   string soundfile = theMxSetup->audioDirectory() + "introSound";
	   _introSound = new akSound(soundfile);
	   _introSound->play();
	  }
}
////////////////////////////////////////////////////////////////////////////////
//
//	Destructor
//
////////////////////////////////////////////////////////////////////////////////
mxFtpApp::~mxFtpApp()
{
	if (_introSound)
	  delete _introSound;
	if (theMxSetup)
	  delete theMxSetup;
	theMxSetup = 0;
}
