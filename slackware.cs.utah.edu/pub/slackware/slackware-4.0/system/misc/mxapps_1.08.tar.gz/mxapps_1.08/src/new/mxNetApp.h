////////////////////////////////////////////////////////////////////////////////
//
//	Class : mxNetApp
//
//	Author : Andy Jefferson
//
//	Description :
//		mxNetApp is the application class for mxNet
//		It simply creates the GLOBAL mxSetup object, and starts up
//		a mxNet window object.
//
//	Public Methods :
//		(Constructor) requires :-
//			app_name	Name used in resource specs.
//			app_version	Application version
//			app_title	Application title (text description).
//
//	Limitations :
//
////////////////////////////////////////////////////////////////////////////////
#ifndef _mxNetApp_h
#define _mxNetApp_h
#ifdef __cplusplus

#include <std/string.h>
#include "akApp.h"
#include "akSound.h"

class mxNetApp : public akApp
{
	public:

		// Constructor,destructor

		mxNetApp(const string app_name,
			 const string app_version,
			 const string app_title);
		~mxNetApp();

	private:

		akSound		*_introSound;
};

#endif
#endif
