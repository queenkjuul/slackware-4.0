////////////////////////////////////////////////////////////////////////////////
//
//	Class : mxFtpApp
//
//	Author : Andy Jefferson
//
//	Description :
//		mxFtpApp is the application class for mxFtp
//		It simply creates the GLOBAL mxSetup object, and starts up
//		a mxFtp window object.
//
//	Public Methods :
//		(Constructor) requires :-
//			app_name	Name used in resource specs.
//			app_version	Application version
//			app_title	Application title (text description).
//
//	Limitations :
//
////////////////////////////////////////////////////////////////////////////////
#ifndef _mxFtpApp_h
#define _mxFtpApp_h
#ifdef __cplusplus

#include <std/string.h>
#include "akApp.h"
#include "akSound.h"

class mxFtpApp : public akApp
{
	public:

		// Constructor,destructor

		mxFtpApp(const string app_name,
			 const string app_version,
			 const string app_title);
		~mxFtpApp();

	private:

		akSound		*_introSound;
};

#endif
#endif
