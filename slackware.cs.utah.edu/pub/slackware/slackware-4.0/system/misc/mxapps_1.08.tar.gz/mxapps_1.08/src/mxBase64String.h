////////////////////////////////////////////////////////////////////////////////
//
//	Class : mxBase64String
//
//	Author : Andy Jefferson
//
//	Description :
//		mxBase64String provides encode/decode methods for a string.
//
//	Public Methods :
//
//	Limitations :
//
////////////////////////////////////////////////////////////////////////////////
#ifndef mxBase64String_h
#define mxBase64String_h
#ifdef __cplusplus

#include <std/string.h>
#include <bool.h>

class mxBase64String
{
	public:

		// Constructor

		mxBase64String() {};

		// Methods

		string		encode(string,bool text_mode=FALSE);
		string		decode(string);

	private:

		// Internal methods

		int		nextCharForEncode();
		int		nextCharForDecode();
};

#endif
#endif
