/*
 *	totem v2.0.3, (c) lilo, 1996, all rights reserved.
 *
 *	This program provides a banner, and a file /proc/totem, in which can
 *	be found a `totem' (animal designation) corresponding to the current
 *	kernel.  It consists of a loadable kernel module to implement those
 *	functions.
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
 
/*
 *	Various required header files.
 */

#include <linux/module.h>
#include <linux/types.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/utsname.h>

/*
 *	Typedef for string tables.
 */

typedef struct STRINGTABLE
{
	int Code;
	char *String;
} StrTab;


/*
 *	Functions.
 */

char *find_string(StrTab *, int);
static int totem_read(char *, char **, off_t, int, int);
int init_module(void);
static int inodeval = 0;
static char *beast, *sort, *preposition, *object;
void cleanup_module(void);

/*
 *	The string tables.
 */

StrTab Beast[] =	/* the animals (primary release numbers) */
{
	{0, "Ostrich"},
	{1, "Hedgehog"},
	{2, "Penguin"},
	{3, "Bear"},
	{4, "Moose"},
	{5, "Kitten"},
	{6, "Owl"},
	{7, "Elephant"},
	{8, "Rabbit"},
	{9, "Hawk"},
	{10, "Platypus"},
	{11, "Grouse"},
	{-1, "Strange Creature"}
};

StrTab Sort[] =		/* the characteristics (secondary release numbers) */
{
	{0, "Zen"},
	{1, "Stealth"},
	{2, "Invincible"},
	{3, "Greased"},
	{4, "Ethereal"},
	{5, "Perturbed"},
	{6, "Turbocharged"},
	{7, "Hesitant"},
	{8, "Electric"},
	{9, "Dyslexic"},
	{10, "Thermonuclear"},
	{99, "Impatient"},
	{-1, "Unexplainable"}
};

StrTab Preposition[] =	/* the prepositions (first nibble of tertiary release number) */
{
	{0, "on"},
	{1, "needing"},
	{2, "feeling the effects of"},
	{3, "abusing"},
	{4, "buying"},
	{5, "handing out"},
	{6, "selling"},
	{7, "whining for"},
	{8, "looking for"},
	{9, "making"},
	{10, "just saying NO! to"},
	{11, "giving Elvis"},
	{12, "running spectral analyses on"},
	{13, "swearing off"},
	{14, "in withdrawal from"},
	{15, "remembering"},
	{-1, "who doesn't seem to have anything to do with"}
};

StrTab Object[] =	/* the substances (last nibble of tertiary release number) */
{
	{0, "Endorphins"},
	{1, "Warm Milk"},
	{2, "Vitamins"},
	{3, "Whiskey"},
	{4, "Quaaludes"},
	{5, "Jolt Cola"},
	{6, "Steroids"},
	{7, "Hot Java"},
	{8, "Mountain Dew"},
	{9, "Adrenaline"},
	{10, "Cocaine"},
	{11, "LSD"},
	{12, "Dark Rum"},
	{13, "Garlic Ice Cream"},
	{14, "Old Star Trek Episodes"},
	{15, "Virtual Beer"},
	{-1, "Some Unidentified Substance"}
};

/*
 *	Directory entry for /proc/totem, read-only.
 */

struct proc_dir_entry dir =
{
	0, 5, "totem",
	S_IFREG | S_IRUGO, 1, 0, 0,
	0, NULL,
	&totem_read
};

/*
 *	Search a string table for the appropriate index, from the release
 *	numbers.  Return a pointer to the string defined for that index.
 */

char *find_string(StrTab *Table, int FindCode)
{
	for(;;)
		if (Table->Code == -1 || Table->Code == FindCode)
			return Table->String;
		else Table++;
}

/*
 *	Initialize the module.
 */

int init_module(void)
{

/*
 *	Try to register the file in the root directory of the proc
 *	filesystem.  Dynamic registration means we won't provide a fixed
 *	inode number, but rather the registration code will allocate one for
 *	us.  This is safer, since we never know when someone will add a new
 *	fixed inode number to the filesystem.  Possible returns are 0
 *	(success) and -ENOENT (failure), and since there's only one error we
 *	won't worry unduly about messages.  If successful, continue.
 */

	if (!proc_register(&proc_root, &dir))
	{

/*
 *	First allocate a working int variable and a pointer to the Linux
 *	release in `n.m.p' form.  Then save the inode value from the
 *	registration call, as we will need it to unregister.
 */
 
		int i;
		char *release = system_utsname.release;
		
		inodeval = dir.low_ino;

/*
 *	Extract the primary release number (or -1 if not found) and use it
 *	to index the appropriate string (beast name).  If we get -1, it
 *	indexes as `Strange Creature' (perhaps a political science major). 
 *	We now have a pointer to the appropriate beast.  Our original
 *	pointer should now be should be pointing to the `.', so skip past
 *	it.
 */
 
		beast=find_string(Beast, simple_strtoul(release,&release,10));
		release++;

/*
 *	Extract the secondary release number (or -1 if not found) and use it
 *	to index the appropriate string (beast characteristic).  If we get
 *	-1, it indexes as `Unexplainable', like the tides, or where your lap
 *	goes when you stand up.
 */

		sort=find_string(Sort, simple_strtoul(release,&release,10));
		release++;

/*
 *	Extract the tertiary release number (or -1 if not found).  If not
 *	found, just set both Preposition and Object to their `unknown'
 *	values (respectively, these are `who doesn't seem to have anything
 *	to do with' and `Some Unidentified Substance'.
 */

		i = simple_strtoul(release,&release,10);
		if (i < 0)
		{
			preposition=find_string(Preposition, -1);
			object=find_string(Object, -1);
		}

/*
 *	If found, use integer division to extract the upper nibble, used to
 *	index the preposition, and use modulo-16 arithmetic to extract the
 *	lower nibble, used to index the object.  We will then have our complete
 *	set of strings for messages.
 */

		else
		{
			preposition=find_string(Preposition, i/16);
			object=find_string(Object, i%16);
		}

/*
 *	Display a nice console banner line with the kernel version and totem
 *	information.  Make sure you get a new-line character on the end or
 *	the console output will just get buffered.  Return without errors.
 */

		printk("%s version %s <%s %s %s %s> %s\n",
			system_utsname.sysname, system_utsname.release,
			sort, beast, preposition, object,
			system_utsname.version);
	}
	return 0;
}

/*
 *	Remove the module.  If a nonzero inode value was returned,
 *	unregister the /proc directory entry; that's all we really need to
 *	do, but we'll log a notice as well.
 */

void cleanup_module(void)
{
	if (inodeval)
	{
		proc_unregister(&proc_root, inodeval);
		printk("totem v" VERSION " kernel support removed\n");
	}
}

/*
 *	Process a read to the file.  we just return the whole mess to the
 *	user with a new-line character on the end.
 */

static int totem_read(char *buf, char **start, off_t offset, int len, int unused)
{
	len = sprintf(buf, "%s %s %s %s\n", sort, beast, preposition, object);
	return len;
}
