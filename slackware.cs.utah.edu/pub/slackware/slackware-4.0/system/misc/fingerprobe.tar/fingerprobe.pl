#!/usr/bin/perl

#
# list the hostnames to probe here
#
$hosts[0] = "ogimaa";
$hosts[1] = "bine";
$hosts[2] = "gaag";
$hosts[3] = "makwa";
$hosts[4] = "maang";
$hosts[5] = "mooz";
$hosts[6] = "nigig";
$hosts[7] = "waabooz";
$hosts[8] = "zagime";
$hosts[9] = "ogaa";
$hosts[10] = "euclid";
$hosts[11] = "aki";
$hosts[12] = "fermat";
$hosts[13] = "gegek";
$hosts[14] = "bee";
$hosts[16] = "esiban";
#
# list the command to run for 'finger' e.g. /usr/bin/finger
#
$fingercommand = "finger";
if ($ARGV[0] eq "-probe") {
	&fingerprobe;
} 
elsif ($ARGV[0] eq "-print") {
	&readlog;
	print "<PRE>\n";
	&print_user_stats;
	&print_host_stats;
	&print_week_stats;
	&print_stats_thisweek;
	&print_hour_stats;
	&print_uptime;
	print "</pre>\n";
}
else {
	print "Usage: fingerprobe { -print < logfile} {-probe >> logfile}\n";
	exit(0);
}
	

# convert a yeay/month/day into a serial number
# (namely the number of days since Jan 1 1997
sub date_to_daynum {
	local ($year,$hour,$day) = @_;
	local ($daynum);
	local (@days_month);
	$days_month[1] = 31;
	$days_month[2] = 28;
	$days_month[3] = 31;
	$days_month[4] = 30;
	$days_month[5] = 31;
	$days_month[6] = 30;
	$days_month[7] = 31;
	$days_month[8] = 31;
	$days_month[9] = 30;
	$days_month[10] = 31;
	$days_month[11] = 30;
	$days_month[12] = 31;
	$year = $year - 97;
	$daynum = $year * 365;
	if ($year == 2000 && $mon > 1) {
		$daynum++;
	}
	$test = 1;
	while ($test <= $mon) {
		$daynum += $days_month[$test];
		$test++;
	}
	$daynum += $day;
	return $daynum;
}
# 
# Reads stdin for the logfile, filling in many arrays
#
sub readlog {
	while ($line = <STDIN>) {
		$linenum++;
		print "Read $linenum lines\n" if ($linenum % 10000 == 0);
		($w1, $w2, $w3, $w4, $w5, $w6, $w7) = split(' ', $line);
		if ($w1 eq "Host") {
			$host_usage{$w2} += $w3;
			$host_observations{$w2}++;
		}
		elsif ($w1 eq "User") {
			$user_usage{$w2}++;
			$user_total++;
			$user_by_hour{$hour}++;
			$user_by_date{$date}++;
		}
		elsif ($w1 eq "Date") {
			# must be careful to keep everything 2 digits for sorting
			$observations++;
			$year = $w2;
			$mon = substr($w3 + 1000, 2, 2);
			$day = substr($w4 + 1000, 2, 2);
			$hour = substr($w5 + 1000, 2, 2);
			$min = substr($w6 + 1000, 2, 2);
			$date = "$year $mon $day";
			$hour_observations{$hour}++;
			$date_observations{$date}++;
		}
		elsif (length($line) < 2 || $w1 eq "Total") {
			# do nothing
		}
		else {
			print STDERR "ERROR: line $linenum starting $w1 $w2\n";
		}
	}
}
#
# compute and print by user stats
#
sub print_user_stats {
	print "\n\nStats by user\n";
	print "User\tTotal  \tUsage\tHours\n";
	print "Name\tObserv.\tPercent\t/Day\n";
	for $user (sort keys %user_usage) {
		$usage = $user_usage{$user};
		$usage_percent = int($usage / $user_total * 1000)/10;
		$hours_day = int($usage/$observations * 24 * 100)/100;
		$total_hours_day += $hours_day;
		$user = substr($user,0,7);
		$total_usage += $usage;
		print "$user\t$usage\t$usage_percent\t$hours_day\n";
	}
	print "---------------------------------\n";
	print "Overall\t$total_usage\t\t$total_hours_day\n";
}


#
# Compute and print host stats
#
sub print_host_stats {
	$count = 0;
	print "\n\nStats by Host\n";
	print "Host\tTotal\tPercent\tHours\nName\tObserv.\tBusy\t/Day\n";
	for $host (sort keys %host_usage) {
		$count++;
		$percent = $host_usage{$host} / $host_observations{$host};
		$hours = $percent * 24;
		$total_hours += $hours;
		$total_percent += $percent;
		$total_usage+= $host_usage{$host};
		$percent = int($percent*1000)/10;
		$hours = int($hours * 1000) / 1000;
		print "$host\t$host_usage{$host}\t$percent%\t$hours\n";
	}
	$percent = int($total_percent*1000/$count)/10;
	$hours = int($total_hours * 1000) / 1000;
	print "------------------------\nOverall\t$total_usage\t$percent%\t$hours\n";
}

#
# Compute and print stats by the week
#
sub print_week_stats 
{
	print "\n\nStats by the Week\n";
	print "Week\t\tUser\nStarting\tHours\n";
	$total = 0;
	for $date (sort { $b gt $a} keys %user_by_date) {
		($year,$mon,$day) = split(' ', $date);
		$daynum = date_to_daynum($year,$mon,$day);
		if (!defined($startnum)) {
			$startnum = $daynum;
		}
		$total += $user_by_date{$date} / $date_observations{$date} * 24;
		if (($daynum - $startnum) % 7 == 0 && $daynum != $startnum) {
			$date = substr($date . "                ", 0,15);
			print "$date $total\n";
			$total = 0;
		}
	}
}
#
# Compute and print stats of this week
#
sub print_stats_thisweek
{
	print "\n\nLast Two Weeks\n";
	print "Day\t User\n\t Hours\n";
	$count = 1;
	for $date (sort { $b gt $a} keys %user_by_date) {
		($year,$mon,$day) = split(' ', $date);
		$nicedate = substr($date . "       ", 0,8);
		$total = $user_by_date{$date} / $date_observations{$date} * 24;
		print "$nicedate $total\n";
		if ($count++ > 13 ) {
			last;
		}
	}
}
#
# Compute and print stats by the hour
#
sub print_hour_stats {
	print "\n\nStats by the Hour\n";
	print "Hour\tAvg Users\n";
	for $hour (sort { $a > $b} keys %user_by_hour) {
		$percent = int($user_by_hour{$hour}/$hour_observations{$hour}*1000)/1000;
		print "$hour\t$percent\n";
	}
}


sub fingerprobe {
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)= localtime(time);
	print "Date $year $mon $mday $hour $min\n";
	for $host (@hosts) {
		#
		# Read in a single host's LAST output, and sets the usage array.
		#
		open(FINGER, "$fingercommand  @". $host . " 2> /dev/null  | cut -c0-9,35-40 |sort | uniq |") || die "Unable to run finger";
		$count = 0;
		$total_lines = 0;
		while ($line = <FINGER>) {
			$total_lines++;
			($user, $idle) = split(' ', $line);
			if (!defined($user) || $user eq "No" || index($user, "[") != -1) {
				next;
			} elsif (defined($idle) && ($idle eq "")) {
				$count++;
				$usage{$user} = 1;
			}
		}
		print "Host $host $count\n" if ($total_lines > 1);
	}
	
	
	$count = 0;
	for $user (sort keys %usage) {
		print "User $user\n";
		$count++;
	}
	print "Total $count users\n";
}

sub print_uptime {
	print "\nUptime by host\nHostname\tPercent Up\n";
	for $host (sort keys %host_observations) {
		$percent = $host_observations{$host} / $observations * 100;
		print "$host\t$percent\n";
	}
}

