#include <stdio.h>
#include <time.h>

main() {
printf("%d\n", time(0));
return(0);
}
