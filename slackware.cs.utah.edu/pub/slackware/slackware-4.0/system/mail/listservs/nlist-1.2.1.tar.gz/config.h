/******* config.h
	Common configuration file for nlist and listarchiver
			**********/

/* OS type. Note that Linux should be GNU, this setting
   must be used on Solaris with GCC */
#define LINUX
/* #define SOLARIS */

/* NList version number */
#define NLIST_VERSION	"1.2.1"

/* Size of temporary buffer. This is a pretty good value. I wouldn't
   change it */

#define N_BUFSIZE 256

/* Default smtp server, can be overridden by smtp_server
   configuration option in the config file */
#define	DEFAULT_SMTP_SERVER	"localhost"

/* Default nntp server, can be overridden by the nntp_server
   configuration option in the config file */
#define DEFAULT_NNTP_SERVER	"localhost"

/* Location of the nlist and the list files
   This should be the location in which you installed NList */

#define PATH "/project/www/list"
/* #define PATH "/usr/local/bin/NList" */

/* Virtual Web-directory from which the list icons are served */
#define ICONDIR			"/listicons/"

#if defined LINUX
#define LOCK_STRUCT struct flock
#elif defined SOLARIS
#define LOCK_STRUCT flock_t
#endif

/* Internationalization features for strings
   compiled into binaries */
/* #define ENGLISH */
#define HUNGARIAN
#if defined ENGLISH

/* Names of months. Note that they go to HTML
   files so HTML &; encoding can be used */
#if defined MAIN
char	*MonthNames[12] = {
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
};
#endif

/* Sender string head and tail. Sender address will
   be substituted between the two strings and added
   to the head of the letter if the letterhead option
   is enabled */
#define INTL_SENDER	"*** Sender: %s ***\n\n"

#elif defined HUNGARIAN

/* These are Hungarian intl strings. Don't worry if
   you don't understand a word ... ;-) */
/* Names of months. */
#if defined MAIN
char	*MonthNames[12] = {
  "Janu&aacute;r",
  "Febru&aacute;r",
  "M&aacute;rcius",
  "&Aacute;prilis",
  "M&aacute;jus",
  "J&uacute;nius",
  "J&uacute;lius",
  "Augusztus",
  "Szeptember",
  "Okt&oacute;ber",
  "November",
  "December"
};
#endif
#define INTL_SENDER	"*** Felado: %s ***\n\n"

#endif
