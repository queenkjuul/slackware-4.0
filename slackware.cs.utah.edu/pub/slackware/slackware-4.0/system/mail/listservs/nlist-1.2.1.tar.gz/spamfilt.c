/*********** spamfilt.c
		Spam filter for the nlist mailing
		list software.
		Written by Gabor Paller
			    ***********/
			    
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<ctype.h>
#include	"config.h"

#define ANDNODE struct andnode
struct andnode {
  char	word[128];
  int	actctr;
  int	maxctr;
  ANDNODE *voclink;
  ANDNODE *forward_link;
  ANDNODE *backward_link;
};

#define ORNODE struct ornode
struct ornode {
  ANDNODE *chain;
  ORNODE *link;
};

/* Define DEBUG to find out what happens in the spam filter */
/* #define DEBUG */

/* The spam filter builds a somewhat complicated data structure
   in the memory. Basically the conditions are ORed connection
   of ANDed conditions. One structure stores the OR descriptors
   in a chain beginning with orend. Each OR descriptor points
   to the beginning of an AND condition chain. Each AND condition
   chain contains one word list. Independently for
   making the word lookup easier AND word structures are inserted
   into a vocabulary hash structure whose starting point is the
   vochash array. Words in this structure are indexed by their
   first letter. */

static ORNODE	*orend;
static ANDNODE	*andend;
static ANDNODE  *vochash[256];
static char	linebuf[1024];

/* Imports from nlist.c */
extern char	list_name[];
void ehandle( int level, char format[], ...);
void Log( int loglevel, int datestr, char format[], ... );

#if defined DEBUG
void printlists() {
  int	i;
  ANDNODE *ap,*pp;
  ORNODE *op;
  
  printf( "Vocabulary list\n" );
  for( i = 0 ; i < 256 ; ++i ) {
    if( vochash[i] != NULL ) {
      printf( "Letter: %c\n",i );
      ap = vochash[i];
      while( ap != NULL ) {
        printf( "%s (%u) ",ap->word,ap->maxctr );
        ap = ap->voclink;
      }
      printf( "\n" );
    }
  }
  printf( "Condition list\n" );
  op = orend;
  while( op != NULL ) {
    printf( "OR\n" );
    ap = op->chain;
    while( ap != NULL ) {
      printf( " AND %s ",ap->word );
      pp = ap;
      ap=ap->backward_link;
    }
    printf( "\n" );
    while( pp != NULL ) {
      printf( " AND %s ",pp->word );
      pp=pp->forward_link;
    }
    printf( "\n" );
    op = op->link;
  }
}
#endif

/* Prints a rule into a buffer */
char *rule( ANDNODE *ap ) {
  static char	work[1024];
  char	w[16];
  ANDNODE *pp;
  
  pp = ap;
  while( ap != NULL ) {
    pp = ap;
    ap = ap->forward_link;
  }
  *work = 0;
  while( pp != NULL ) {
    strcat( work,pp->word );
    strcat( work," " );
    sprintf( w,"(%u:%u) ",pp->actctr,pp->maxctr );
    strcat( work,w );
    pp = pp->backward_link;
  }
  return work;
}

/* Checks a rule chain. Returns 1, if the rule chain
   is true */
int checkchain( ANDNODE *ap ) {
  ANDNODE	*pp;
  
  pp = ap;
  while( ap != NULL ) {
    pp = ap;
    ap = ap->forward_link;
  }
  while( pp != NULL ) {
    if( pp->actctr < pp->maxctr )
	return 0;
    pp = pp->backward_link;
  }
  return 1;
}

/* Applies the spam filter to a letter. Returns 1, if the
   letter passed the spam test, 0 if not. The filter
   returns 1 if the spam filter is switched off */
int spamfilt( char letterfile[] ) {
  FILE	*letter,*spamfile;
  char	SpamFileName[N_BUFSIZE],*p1,*p2,*base;
  int	m,i;
  ANDNODE *ap;
  ORNODE *op;
  
  sprintf( SpamFileName,"%s/%s.spamfilt",PATH,list_name );
  if( ( spamfile = fopen( SpamFileName,"r" ) ) == NULL )
      return 1;
  orend = NULL;
  for( i = 0 ; i < 256 ; ++i )
    vochash[i] = NULL;
  while( fgets( linebuf,1020,spamfile ) != NULL ) {
    if( linebuf[0] == '#' )
	continue;
    base = linebuf;
    andend = NULL;
    do {
      p1 = strtok( base," \t\r\n" );
      p2 = base = NULL;
      if( p1 != NULL )
          p2 = strtok( base," \t\r\n" );
      if( ( p1 != NULL ) && ( p2 != NULL ) ) {
        if( sscanf( p2,"%u",&m ) < 1 ) {
	  ehandle( 0,"%s: invalid constant %s for word %s in line %s",
			SpamFileName,p2,p1,linebuf );
	  continue;
	}
	ap = malloc( sizeof( ANDNODE ) );
	if( ap == NULL ) {
	  ehandle( 0,"Out of memory while allocating ANDNODE" );
	  return 1;
	}
	ap->actctr = 0;
	ap->maxctr = m;
	strncpy( ap->word,p1,127 );
	ap->word[127] = 0;
/* Inserting the AND structure into the AND chain */
	ap->forward_link = NULL;
	ap->backward_link = andend;
	if( andend != NULL )
	    andend->forward_link = ap;
	andend = ap;
/* Inserting the AND structure into the vocabulary chain */
        m = ((int) toupper( *p1 ) ) & 0xFF;
	ap->voclink = vochash[m];
	vochash[m] = ap;
      } 
    } while( ( p1 != NULL ) && ( p2 != NULL ) );
/* There was a rule, add it to the list */
    if( andend != NULL ) {
      op = malloc( sizeof( ORNODE ) );
      if( op == NULL ) {
	ehandle( 0,"Out of memory while allocating ORNODE" );
	return 1;
      }
      op->chain = andend;
      op->link = orend;
      orend = op;
    }
  }
  fclose( spamfile );
#if defined DEBUG
  printlists();
#endif
/* Check the letter now */
  if( ( letter = fopen( letterfile,"r" ) ) == NULL )
      return 1;
  while( fgets( linebuf,1020,letter ) != NULL ) {
    base = linebuf;
    do {
      if( ( p1 = strtok( base," \t\r\n,:.-?!()\"<>'*" ) ) == NULL )
                  continue;
      base = NULL;
      m = ((int) toupper( *p1 ) ) & 0xFF;
      ap = vochash[m];
      while( ap != NULL ) {
        if( strcasecmp( p1,ap->word ) == 0 ) {
	  ++(ap->actctr);
	  if( ( ap->actctr >= ap->maxctr ) && 
	      checkchain( ap ) ) {
/* Spam filter triggered, letter will be killed */
	    Log( 2,1,"letter filtered out by rule %s",rule( ap ) );
	    rewind( letter );
	    while( fgets( linebuf,1020,letter ) != NULL ) {
	      if( ( p2 = strchr( linebuf,'\n' ) ) != NULL )
	          *p2 = 0;
	      Log( 2,0,"SPAM: %s",linebuf ); 
	    }
	    fclose( letter );
	    return 0;
	  }
	}
        ap = ap->voclink;
      }
    } while( p1 != NULL );
  }
  fclose( letter );
  return 1;
}
