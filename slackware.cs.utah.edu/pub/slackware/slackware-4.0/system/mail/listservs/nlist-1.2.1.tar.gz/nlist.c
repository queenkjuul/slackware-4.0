 /*********************************************************************** 
  *                                                                      *
  *    NList 1.2.1 Copyright (C) 1997 Erich Menge (erich@minn.net)       *
  *		Enhanced by Gabor Paller (paller@javasite.bme.hu)	 *
  *                                                                      *
  * This program is free software; you can redistribute it and/or modify *
  * it under the terms of the GNU General Public License as published by *
  * the Free Software Foundation; either version 2 of the License, or    *
  * (at your option) any later version.                                  *
  *                                                                      *
  * This program is distributed in the hope that it will be useful,      *
  * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
  * GNU General Public License for more details.                         *
  *                                                                      *
  * You should have received a copy of the GNU General Public License    *
  * along with this program; if not, write to the Free Software          *
  * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            *
  *                                                                      *
  ************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>
#include <setjmp.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>
#include <sys/timeb.h>
#include <errno.h>
#define MAIN
#include "config.h"
#include	<stdarg.h>
#if defined SOLARIS
#include	<sys/varargs.h>
#endif

/* Error names */
#define	FINISH_OK		1
#define GENERAL_ERROR		2
#define	BAD_SUBSCRIBE		3
#define ALREADY_ON_LIST		4
#define LIST_DISABLED		5
#define NOT_ALLOWED		6	/* Subscription not allowed */
#define SEND_SUBS_MESSAGE	7
#define BAD_UNSUBSCRIBE		8
#define SEND_UNSUBS_MESSAGE	9
#define HELP_MESSAGE		10
#define NO_LIST			11	/* No such list */
#define NOT_ON_LIST		12

/* SMTP IANA number */
#define SMTP_PORT		25

/* From iofunc.c */
char *getline(FILE *fp);
/* From spamfilt.c */
int spamfilt( char letterfile[] );
/* From nntp.c */
void nntp_post( char from[] );

/* True if the list can be used only by subscribed members */
int	closed = 0;
/* True if subscribe and unsubscribe is allowed */
int	subscribe = 1;
/* True if sender banner is allowed */
int	sender_banner = 0;
/* Contains the reply-to address if set */
char	replyto[N_BUFSIZE];
/* Archive directory */
char	archive[N_BUFSIZE];
/* Name of the SMTP server */
char	smtp_server[N_BUFSIZE];
/* Errors-To: address */
char	errors_to[N_BUFSIZE];
/* To: address */
char	to_address[N_BUFSIZE];
/* From: address */
char	from_address[N_BUFSIZE]; 
/* Address of the list */
char	list_address[N_BUFSIZE];
/* Domain name of the SMTP server */
char	domain_name[N_BUFSIZE];
/* List title */
char	list_title[N_BUFSIZE];
/* Subject work string */
char	subject_string[N_BUFSIZE];
/* Full address of the sender */
char *sender_full_address = NULL;

/* Buffer variable */
char	work[2*N_BUFSIZE];

/* File name buffer */
char	fname[N_BUFSIZE];

/* Name of the list */
char	list_name[N_BUFSIZE];

/* TRUE if control mode */
int	control_mode;

/* Error handling setjmp buffer */
jmp_buf	finish;

/* We keep the config file pointer here so that we can make proper
   lock/unlock */
FILE	*config = NULL;

/* Pointer to the sender address from the From field */
char *addr = NULL;

/* Pointer to the subject field */
char *subject;

/* Name of the temporary file that stores the message */
char	TempFileName[N_BUFSIZE];

/* Pointer to the beginning of the content in the temporary file */
long	ContentPointer;

/* Timeout in seconds for config file lock */
long	ConfigLockTimeout;

/* Name of the log file */
char	LogFileName[N_BUFSIZE];

/* Logging level */
int	LogLevel;

/* Logging on/off */
int	LogEnable;

/* NNTP newsgroup name */
char	nntp_newsgroup[N_BUFSIZE];

/* NNTP server name */
char	nntp_server[N_BUFSIZE];

/* NNTP port number */
int	nntp_port;

/* NNTP list address */
char	nntp_list_address[N_BUFSIZE];

/* NNTP from address */
char	nntp_from_address[N_BUFSIZE];

/* NNTP replyto address */
char	nntp_replyto[N_BUFSIZE];

char	protstr[8];
int		sock;		/* socket fd */

/* Log function, writes its output to the log file */
void Log( int loglevel, int datestr, char format[], ... ) {
  va_list	ap;
  FILE	*logfile;
  LOCK_STRUCT	lt;
  int	i,err;
  struct timeb	ts;
  struct tm	*tp;
  char	timestr[32],*p,logbuf[1024];

  va_start( ap,format );
  if( loglevel < LogLevel ) {
    if( !LogEnable ) {
      if( loglevel < 1 )
        vfprintf( stderr,format,ap );
    } else {
      if( *list_name == 0 )
	    sprintf( LogFileName,"%s/general.log",PATH );
      else
	    sprintf( LogFileName,"%s/%s.log",PATH,list_name );
      if( ( logfile = fopen( LogFileName,"a" ) ) == NULL )
	goto l0;
      lt.l_type = F_WRLCK;
      lt.l_whence = 0;
      lt.l_start = 0;
      lt.l_len = 0;
/* We try ten times to lock the file */
      for( i = 0 ; i < 10 ; ++i ) {
        err = fcntl( fileno( logfile ), F_SETLK, &lt );
        if( err >= 0 )
	    break;
        if( ( err < 0 ) && ( errno == EAGAIN ) )
	    sleep( 1 );
      }
      if( err < 0 ) {
        fclose( logfile );
        fprintf( stderr, "Cannot lock log file %s for 10 seconds\n",
		    LogFileName );
        goto l0;
      }
      if( datestr ) {
        ftime( &ts );
        tp = localtime( &(ts.time) );
        strcpy( timestr,asctime( tp ) );
        timestr[ strlen( timestr ) - 1 ] = 0;
        fprintf( logfile,"%s ",timestr );
      }
      vsprintf( logbuf,format,ap );
      if( ( p = strchr( logbuf,'\n' ) ) != NULL )
          *p = 0;
      fprintf( logfile,"%s\n",logbuf );
      fclose( logfile );
    }
  }
l0:
  va_end( ap );
}

/* Error handling function. level=0 - warning,
   level=1 - fatal error */
void ehandle(int level, char format[], ...) {
  char	buf[N_BUFSIZE];
  va_list	ap;

  va_start( ap,format );
  switch (level) {
    case 1:
	vsprintf( buf,format,ap );
	Log( 0,1,"Error: %s",buf );
	longjmp( finish,GENERAL_ERROR );
	break;

    case 0:
	vsprintf( buf,format,ap );
	Log( 1,1,"Warning: %s",buf );
	break;
  }
  va_end( ap );
} 


/* Makes address substitution on a configuration parameter.
   Substitutes "sender" with act_from_address, "addressee" with
   act_to_address, "list" with list_address else leaves the
   input unchanged. */
char *subst_lname( char config_value[],
			    char *act_from_address,
			    char *act_to_address,
			    char *l_address ) {
  static char ret_buf[N_BUFSIZE];
  	
  if( strcasecmp( config_value,"sender" ) == 0 )
     strcpy( ret_buf,act_from_address );
  else
  if( strcasecmp( config_value,"addressee" ) == 0 )
      strcpy( ret_buf,act_to_address );
  else
  if( strcasecmp( config_value,"list" ) == 0 )
      strcpy( ret_buf,l_address );
  else
      strcpy( ret_buf,config_value );
  return ret_buf;
}

void open_socket( char server[],int port ) {
   struct sockaddr_in server_addr;
   struct hostent *hp, *gethostbyname();
   char buf[1024];
   
/* Create socket */
   sock = socket( AF_INET, SOCK_STREAM, 0 );
   if (sock == -1)
	ehandle( 1,"Could not create stream socket: %s",strerror( errno ) );
	
/* Connect socket using name specified by command line. */
   server_addr.sin_family = AF_INET;
   hp = gethostbyname( server );
/*
* gethostbyname returns a structure including the network address
* of the specified host
*/
  if (hp == (struct hostent *) 0)
	ehandle( 1,"Cannot resolve hostname %s: %s",server,strerror( errno ) );
  memcpy((char *) &server_addr.sin_addr, (char *) hp->h_addr,
                   hp->h_length );
  server_addr.sin_port = htons( port );
  if (connect(sock, (struct sockaddr *) &server_addr, sizeof server_addr)
          == -1)
        ehandle( 1,"Could not connect to %s:%u: %s",server,port,
        		strerror( errno ) );
}

/* Close the socket connection.
 */
void close_socket() {
  if (close(sock) < 0)
	ehandle( 1,"socket close: %i\n",errno );
}

/* Write out the output buffer to the socket */
void socket_write_line( char *buffer ) {
  char *p = buffer;
  int len;
  int w;

  Log( 4,0,"%s OUT: %s",protstr,buffer );
  len = strlen( buffer );
  while (len > 0) {
    do {
      w = write(sock, p, len);
    } while (w < 0 && errno == EINTR); /* retry on interrupted system call */
    if (w < 0)
	ehandle( 1,"socket write: %i\n",errno );
    p += w;			/* write the rest out if short write */
    len -= w;
  }
}

void socket_read_line( char *buffer, int bufsize ) {
  int	i,n;
  char	*p = buffer,*p1;

  do {
    do {
      n = read(sock, p, 1 );
    } while (n < 0 && errno == EINTR);
    if (n < 0)
	ehandle( 1,"socket read: %i\n",errno );
    if (n == 0) {
      *p = 0;
      Log( 4,0,"%s IN: %s",protstr,buffer );
      return;
    }
    p1 = p;
    ++p;
    --bufsize;
    if( ( *p1 == '\n' ) || ( bufsize == 0 ) ) {
      *p = 0;
      Log( 4,0,"%s IN: %s",protstr,buffer );
      return;
    } 
  } while( 1 );
}

int open_smtp_session( char *from, char *to ) {
  char	tempbuffer[256];
  char	outbuffer[256];
  int	retry = 10;

  strcpy( protstr,"SMTP" );
l0:
  if( retry == 0 )
    ehandle( 1,"SMTP error: %i:'%s'\n",errno,tempbuffer );
  open_socket( smtp_server, SMTP_PORT );
  sprintf( tempbuffer,"HELO %s\n",domain_name );
  socket_write_line( tempbuffer );
  do {
    socket_read_line( tempbuffer,255 );
    if( strncmp( tempbuffer,"220",3 ) == 0 )	/* Login response */
	continue;
    if( strncmp( tempbuffer,"250",3 ) == 0 )	/* OK */
	break;
/* Some garbage arrived. Terminate the connection,
   close the socket and retry. I don't know how it can happen
   but it happens ... :-( */
    --retry;
    close_socket();
    sleep( 1 );		/* Wait 1 second */
    goto l0;
  } while( 1 );
  sprintf( outbuffer,"MAIL FROM: %s\n",
              subst_lname( from_address,from,to,list_address ) );
  socket_write_line( outbuffer );
  socket_read_line( tempbuffer,255 );
  if( strncmp( tempbuffer,"250",3 ) != 0 )
	return 1;
  sprintf( outbuffer,"RCPT TO: %s\n",to );
  socket_write_line( outbuffer );
  socket_read_line( tempbuffer,255 );
  if( strncmp( tempbuffer,"250",3 ) != 0 )
	return 1;
  socket_write_line( "DATA\n" );
  socket_read_line( tempbuffer,255 );
  if( strncmp( tempbuffer,"354",3 ) != 0 )
	return 1;
  return 0;
}

void write_smtp_line( char *buffer ) {
  if( strncmp( buffer,".\n",2 ) == 0 )
	socket_write_line( " .\n" );
  else
	socket_write_line( buffer ); 
}

void close_smtp_session() {
  socket_write_line( "\n.\n" );
  close_socket();
}

FILE *file_open( char fname[], char mode[] ) {
  FILE	*f;

  if( ( f = fopen( fname, mode ) ) ==NULL ) {
    if (errno == 2)
	ehandle(1, "File cannot be opened in mode %s: %s\n",
		mode,fname);
    else if (errno == 13)
	ehandle(1, "Permission to open %s denied\n",fname);
    else
	ehandle( 1,"Unknown error number %d\n", errno);
  }
  return f;
}

/* Processes a yes/no configuration option. Gets a pointer to the
   beginning of the parameter area, return 0 if the answer was no,
   1, if it was yes, -1, if it was neither */
int process_yes_no( char *c ) {
  char *p;
  if( ( p = strtok( c," \t\n" ) ) == NULL )
      return -1;
  if( strcasecmp( p,"yes" ) == 0 )
      return 1;
  if( strcasecmp( p,"no" ) == 0 )
      return 0;
  return -1;
}

/* Processes the config file of the list of the given name. Locks
   the config file but doesn't close it as it is the signal that
   one instance of the program is in the critical region.
   If the silent flag is notzero, missing config file
   results in silent return, not error message */
void read_config( char listname[], int silent ) {
  char	fname[N_BUFSIZE];
  char	buf[N_BUFSIZE];
  LOCK_STRUCT	lt;
  int	err,i,tc;
  long	to;
  
  if( config != NULL )
      fclose( config );
  
  ConfigLockTimeout = 60L;
  *archive = 0;
  closed = 0;
  subscribe = 1;
  sender_banner = 0;
  strcpy( replyto,"" );
  strcpy( smtp_server,DEFAULT_SMTP_SERVER );
  strcpy( errors_to,"" );
  strcpy( to_address,"list" );
  strcpy( from_address,"sender" );
  strcpy( list_address,"" );
  strcpy( domain_name,"" );
  strcpy( list_title,"" );
  strcpy( nntp_newsgroup,"" );
  strcpy( nntp_server,DEFAULT_NNTP_SERVER );
  strcpy( nntp_list_address,"" );
  strcpy( nntp_from_address,"" );
  strcpy( nntp_replyto,"" );
  nntp_port = 119;
  sprintf( buf, "%s/%s.config", PATH, listname );
  if( ( config = fopen( buf,"r+" ) ) == NULL ) {
    if( silent )
	return;
    longjmp( finish,NO_LIST );
  }  
  while( fgets( buf,N_BUFSIZE-1,config ) != NULL ) {
    i = strlen( buf );
    if( i > 0 )
	--i;
    if( buf[i] == '\n' )
	buf[i] = 0;
    if( strncasecmp( "closed=",buf,7 ) == 0 ) {
      tc = process_yes_no( buf+7 );
      if( tc < 0 )
        ehandle( 1,"Error in %s config file: %s",listname,buf );
      closed = tc;
    } else
    if( strncasecmp( "subscribe=",buf,10 ) == 0 ) {
      tc = process_yes_no( buf+10 );
      if( tc < 0 )
        ehandle( 1,"Error in %s config file: %s",listname,buf );
      subscribe = tc;
    } else
    if( strncasecmp( "senderbanner=",buf,13 ) == 0 ) {
      tc = process_yes_no( buf+13 );
      if( tc < 0 )
        ehandle( 1,"Error in %s config file: %s",listname,buf );
      sender_banner = tc;
    } else
    if( strncasecmp( "logging=",buf,8 ) == 0 ) {
      tc = process_yes_no( buf+8 );
      if( tc < 0 )
        ehandle( 1,"Error in %s config file: %s",listname,buf );
      LogEnable = tc; 
    } else
    if( strncasecmp( "replyto=",buf,8 ) == 0 ) {
      strcpy( replyto,buf+8 );
    } else
    if( strncasecmp( "errorsto=",buf,9 ) == 0 ) {
      strcpy( errors_to,buf+9 );
    } else
    if( strncasecmp( "to=",buf,3 ) == 0 ) {
      strcpy( to_address,buf+3 );
    } else
    if( strncasecmp( "from=",buf,5 ) == 0 ) {
      strcpy( from_address,buf+5 );
    } else
    if( strncasecmp( "archive=",buf,8 ) == 0 ) {
      strcpy( archive,buf+8 );
    } else
    if( strncasecmp( "list=",buf,5 ) == 0 ) {
     strcpy( list_address,buf+5 );
    } else
    if( strncasecmp( "smtp_server=",buf,12 ) == 0 ) {
      strcpy( smtp_server,buf+12 );
    } else
    if( strncasecmp( "domain_name=",buf,12 ) == 0 ) {
      strcpy( domain_name,buf+12 );
    } else
    if( strncasecmp( "title=",buf,6 ) == 0 ) {
      strcpy( list_title,buf+6 );
    } else
    if( strncasecmp( "timeout=",buf,8 ) == 0 ) {
      if( sscanf( buf+8,"%lu",&ConfigLockTimeout ) < 1 )
        ehandle( 1,"Error in %s config file: %s",listname,buf );
    } else
    if( strncasecmp( "loglevel=",buf,9 ) == 0 ) {
      if( sscanf( buf+9,"%u",&LogLevel ) < 1 )
        ehandle( 1,"Error in %s config file: %s",listname,buf );
    } else
    if( strncasecmp( "newsgroup=",buf,10 ) == 0 ) {
      strcpy( nntp_newsgroup,buf+10 );
    } else
    if( strncasecmp( "nntp_server=",buf,12 ) == 0 ) {
      strcpy( nntp_server,buf+12 );
    } else
    if( strncasecmp( "nntp_port=",buf,10 ) == 0 ) {
      if( sscanf( buf+10,"%u",&nntp_port ) < 1 )
        ehandle( 1,"Error in %s config file: %s",listname,buf );
    } else
    if( strncasecmp( "nntp_list=",buf,10 ) == 0 ) {
      strcpy( nntp_list_address,buf+10 );
    } else
    if( strncasecmp( "nntp_from=",buf,10 ) == 0 ) {
      strcpy( nntp_from_address,buf+10 );
    } else
    if( strncasecmp( "nntp_replyto=",buf,13 ) == 0 ) {
      strcpy( nntp_replyto,buf+13 );
    }
  }
  if( *list_address == 0 )
      ehandle( 1,"list address was not specified for list %s",listname );
  if( *nntp_list_address == 0 )
      strcpy( nntp_list_address,list_address );
  if( *nntp_from_address == 0 )
      strcpy( nntp_from_address,from_address );
  if( *nntp_replyto == 0 )
      strcpy( nntp_replyto,replyto );
/* We never write the config file neverthless we lock it for write.
   The reason is that this is the signal that one instance of the program
   is in the critical region where it may write common files. That's
   the reason why we close the config file only before quitting */
  lt.l_type = F_WRLCK;
  lt.l_whence = 0;
  lt.l_start = 0;
  lt.l_len = 0;
/* We try ten times to lock the file */
  for( to = 0 ; to < ConfigLockTimeout ; ++to ) {
    err = fcntl( fileno( config ), F_SETLK, &lt );
    if( err >= 0 )
      break;
    if( ( err < 0 ) && ( errno == EAGAIN ) )
        sleep( 1 );
  }
  if( err < 0 ) {    
    fclose( config );
    ehandle( 1, "Cannot lock config file %s for %lu seconds",buf,
		ConfigLockTimeout ); 
  }
}

/* Sends the obligatory header lines */
void send_list_headers( char *addressee ) {
/* This header is always sent to detect mail loops */
  sprintf( work,"X-Sender: nlist %s\n",NLIST_VERSION );
  write_smtp_line( work );
/* This header conforms with sendmail */
  sprintf( work,"Auto-Submitted: auto-generated (mail list message)\n" );
  write_smtp_line( work );
  if( *to_address ) {
    sprintf( work,"To: %s\n",
	    subst_lname( to_address,addr,addressee,list_address ) );
    write_smtp_line( work );
  }
  if( *replyto ) {
    sprintf( work,"Reply-To: %s\n",
	    subst_lname( replyto,addr,addressee,list_address ) );
    write_smtp_line( work );
  }
  if( *errors_to ) {
    sprintf( work,"Errors-To: %s\n",
	    subst_lname( errors_to,addr,addressee,list_address ) );
    write_smtp_line( work );
  }
}

/* Sends back a reply letter. Gets the destination address and the
   name of the template file */
void send_reply( char dest[], char templatename[] ) {
  char	c,*p1,*p2,*p3,*p4;
  int	len,numread;
  FILE	*template,*tempfile;
  char	buf[N_BUFSIZE];

  if( *list_name == 0 )
      p3 = "unknown_list";
  else
      p3 = list_name;
  sprintf( fname,"%s/%s.%s",PATH,list_name,templatename );
  if( ( template = fopen( fname,"r" ) ) == NULL )
	return;		/* Quit in silence if file doesn't exist */
  if( open_smtp_session( list_address,addr ) )
	ehandle( 1,"SMTP error for %s\n",dest );
  sprintf(work, "Subject: Re: " );
  if( *list_title != 0 ) {
    strcat( work,list_title );
    strcat( work," " );
  }
  if( subject != NULL ) {
    p2 = subject+9;
    strcat( work,p2 );
  }
  strcat( work,"\n" );
  write_smtp_line( work );
  send_list_headers( addr );
/* Now comes the message body */
  write_smtp_line( "\n" );

/* Sending out text in pieces */
  while( fgets( work,N_BUFSIZE,template ) != NULL ) {
    p1 = work;
    p2 = buf;
    while( c = *(p1++) ) {
      if( c == '[' ) {
	if( strncmp( p1,"listname]",9 ) == 0 ) {
	  strcpy( p2,p3 );
	  p1 += 9;
	  p2 += strlen( p3 );
	  continue;
	} else
	if( strncmp( p1,"sender]",7 ) == 0 ) {
	  p1 += 7;
	  strcpy( p2,addr );
	  p2 += strlen( addr );
	  continue;
	}
      }
      *(p2++) = c;
    }
    *p2 = 0;
    write_smtp_line( buf );
  }
  fclose( template );
/* Appending the original message now */
  sprintf( buf,"------------------------------------------------------\n" );
  write_smtp_line( buf );
  tempfile = file_open( TempFileName,"r" );
  while( fgets( buf,N_BUFSIZE-1,tempfile ) != 0 )
	write_smtp_line( buf );
  fclose( tempfile );
  close_smtp_session();
}

/* Handles subscribe requests. Gets a pointer to the subject
   header pointing after "subscribe" word */
void handle_subscribe( char *adr2 ) {
  FILE *deny;
  FILE *approve;
  FILE *member;
  char **members;
  int pass=1;
  char *aof;
  
  adr2=adr2 + 9;
  adr2 = strtok( adr2," " );
  if( ( adr2 == NULL ) || ( *adr2 == 0 ) ) {
    if( *list_name == 0 || control_mode )	/* List name not yet set */
	longjmp( finish,BAD_SUBSCRIBE );
  } else
	strcpy( list_name,adr2 );
  read_config( list_name,0 );
  Log( 2,1,"subscription request on list %s for %s",list_name,addr );
/* Quit if the list is closed for subscription */
  if( !subscribe ) {
    Log( 2,1,"list %s is closed for subscription",list_name );
    longjmp( finish, LIST_DISABLED );
  }
  sprintf(fname, "%s/%s.deny", PATH, list_name );
  deny=fopen( fname, "r");
  sprintf(fname, "%s/%s.approve", PATH, list_name );
  approve=fopen( fname, "r");
  sprintf(fname, "%s/%s.members", PATH, list_name);
  member = file_open( fname,"r+" );
/* Quit if the member is already on the list */
  while(fscanf(member, "%s", work)!=EOF)
	if(!strcasecmp(addr, work)) {
	  Log( 2,1,"address %s is already on list %s",
	              addr,list_name );
	  longjmp( finish, ALREADY_ON_LIST );
	}
  pass=1;
  if(deny) {
     while(((aof=getline(deny))!=NULL) && pass==1) {
       if(((strstr(aof, addr))!=NULL) ||
	   (!strncmp(aof, "*\0", 2)) ||
	   (!strncmp(aof, "ALL\0", 4))) {
		pass=0;
                break;
       }
     }
  }
  if(approve) {
     while((aof=getline(approve))!=NULL && pass==0) {
	if((strstr(aof, addr))!=NULL)
		pass=1;
     }
  }
/* Quit if subscription from this address is not allowed */        
  if (pass==0) {
    Log( 2,1,"subscription to list %s from %s denied",list_name,
		addr );
    longjmp( finish, NOT_ALLOWED );
  }
/* Adding the user to the list */                
  fprintf(member, "%s\n", addr);
  fclose( member );
  longjmp( finish,SEND_SUBS_MESSAGE );  
}

/* Handles unsubscribe messages */
void handle_unsubscribe( char *adr2 ) {
  FILE *member;
  int len;
  int numlines=0;
  int x=0;
  int	success = 0;
  char	*temp;
  char **members;
  char *s;

  adr2=adr2 + 11;
  adr2 = strtok( adr2," " );
  if( ( adr2 == NULL ) || ( *adr2 == 0 ) ) {
    if( *list_name == 0 || control_mode )	/* List name not yet set */
	longjmp( finish,BAD_UNSUBSCRIBE );
  } else
  if( control_mode )
	strcpy( list_name,adr2 );
  read_config( list_name,0 );
  Log( 2,1,"unsubscribe request on list %s for %s",list_name,addr );
  if( !subscribe ) {
    Log( 2,1,"list %s is disabled",list_name );
    longjmp( finish, LIST_DISABLED );
  }
  sprintf( fname, "%s/%s.members", PATH, list_name );
  member = file_open( fname,"r" );
  while((s = getline(member))) if(*s) numlines++;
  rewind(member);
  members=(char **)malloc(numlines * sizeof(char *));
  len=0;
  while((temp=getline(member))!=NULL) {
    if(strstr(temp, addr)==NULL) {
      members[len]=temp;
      len++;
    } else
	success = 1;	/* Address found, remove from list */
  }
  fclose( member );
  if( !success ) {
    Log( 2,1,"address %s not on list %s",addr,list_name );
    longjmp( finish,NOT_ON_LIST );
  }
  member = file_open( fname,"w+" );
  for( x = 0 ; x < len ; ++x )
    if (members[x]!=NULL)
	fprintf(member, "%s\n", members[x]);
  fclose( member );
  longjmp( finish,SEND_UNSUBS_MESSAGE );
}

/* Housekeeping before termination. Generally sends out
   confirmation mails. Returns the new error code */
int housekeep( int errcode ) {
  switch( errcode ) {
    case BAD_SUBSCRIBE:
	send_reply( addr,"bad_subscribe" );
	return FINISH_OK;

    case ALREADY_ON_LIST:
	send_reply( addr,"already_on_list" );
	return FINISH_OK;

    case LIST_DISABLED:
	send_reply( addr,"list_disabled" );
	return FINISH_OK;

    case NOT_ALLOWED:
	send_reply( addr,"not_allowed" );
	return FINISH_OK;

    case SEND_SUBS_MESSAGE:
	send_reply( addr,"subs_message" );
	return FINISH_OK;

    case BAD_UNSUBSCRIBE:
	send_reply( addr,"bad_unsubscribe" );
	return FINISH_OK;

    case SEND_UNSUBS_MESSAGE:
	send_reply( addr,"unsubs_message" );
	return FINISH_OK;

    case HELP_MESSAGE:
	send_reply( addr,"help" );
	return FINISH_OK;

    case NO_LIST:
	send_reply( addr,"no_list" );
	return FINISH_OK;
	
    case NOT_ON_LIST:
	send_reply( addr,"not_on_list" );
	return FINISH_OK;
  }
  return errcode;
}

int main(int argc, char **argv) {

  char *s;
  FILE *member,*tempfile,*banner;
  char *adr,*p;
  char *adr2=NULL;
  char *dateaddr = NULL;
  char *fromcur=NULL;
  char buf[N_BUFSIZE];
  char **members,**command_array;
  int	fds[2],fc,newpid;
  int len;
  int numlines=0;
  int pass=1;
  int x=0;
  int numread=0;
  int xsender_found;

	LogLevel = 1;
	LogEnable = 1;
	strcpy( smtp_server,DEFAULT_SMTP_SERVER );
	strcpy( domain_name,"" );
	strcpy( list_address,"nlist" );
	strcpy( from_address,"nlist" );
/* What an ugly solution, I am really ashamed :-) We return here
   at the end of the program to perform some housekeeping before
   quitting ... Sorry but the original program was full of exit()s */
	if( x = setjmp( finish ) ) {
	  x = housekeep( x );
	  if( config != NULL )
		fclose( config );	/* See remark at read_config */
          unlink( TempFileName );
          exit( x - 1 );
	}

	*list_name = 0;
	if( argc == 2 ) {
	  strcpy( list_name,argv[1] );
	  control_mode = 0;
	}
	else {
/* control.config may be necessary for list commands */
	  strcpy( list_name,"control" );
	  control_mode = 1;
	}
	read_config( list_name,1 );
/* Opening temporary file for the message */
        sprintf( TempFileName,"%s/nlist%i.tmp",PATH,getpid() );
	tempfile = file_open( TempFileName,"w+" );
	xsender_found = 0;
	while(*(adr=getline(stdin))) {
	  fprintf( tempfile,"%s\n",adr );
	  if( !strncmp(adr, "Subject: ", 9 ) ) {
	    subject = adr;
/* That may be vacation auto reply */
	    if( strstr( adr,"Auto-reply" ) != NULL )
		xsender_found = 1;
	  }
	  if( ! strncmp( adr,"Date: ",6 ) )
		dateaddr = adr;
	  if (!strncmp(adr, "From ", 5)) {
	    addr = strtok( adr+5," " );
	    if( sender_full_address == NULL )
		sender_full_address = addr;
	  }
	  if (!strncmp(adr, "From: ", 6)) {
	    fromcur=adr;
/* Use address from the From: field if any, else use
   the address in the From field */
	    sender_full_address = adr+6;
	  }
/* If there's an X-Sender: nlist header in the letter, it came
   from nlist and somehow we got into a mail loop. We swallow
   the letter but this time we just signal it in a flag.
   The header checking is a bit overcomplicated as some
   braindead mail servers send back headers without space
   after the colon */
	  if( !strncasecmp( adr,"X-Sender:",9 ) &&
	      ( strstr( adr,"nlist" ) != NULL ) )
	      xsender_found = 1;
/* Set the xsender_found flag if auto-submitted header was found,
   then it is an automatic reply from somewhere that should not
   be processed. */
          if( !strncasecmp( adr,"Auto-Submitted:",15 ) )
	      xsender_found = 1;
	}
	fprintf( tempfile,"\n" );
/* Now saving the content of the letter */
	ContentPointer = ftell( tempfile );
	while((numread = fread(buf, 1, N_BUFSIZE, stdin)))
	    fwrite( buf,1,numread,tempfile );
/* Now looking for X-Sender: nlist strings in the message
   body. Most of mailer daemons quote the full incoming
   message along with its headers when generating error
   letter */
	fseek( tempfile,ContentPointer,SEEK_SET );
	while( fgets( work,N_BUFSIZE,tempfile ) != NULL ) {
	  if( !strncasecmp( work,"X-Sender:",9 ) &&
	      ( strstr( work,"nlist" ) != NULL ) )
		xsender_found = 1;
	  if( !strncasecmp( work,"Auto-Submitted:",15 ) )
	  	xsender_found = 1;
	}
	if( LogLevel > 3 ) {
	  Log( 3,1,"letter arrived" );
	  fseek( tempfile,0,SEEK_SET );
	  while( fgets( work,N_BUFSIZE,tempfile ) != NULL ) {
	    if( ( p = strchr( work,'\n' ) ) != NULL )
		    *p = 0;
	    Log( 3,0,"L: %s",work );
	  }
	}
	fclose( tempfile );
/* It's not OK at all, the message has no From field. We swallow
   it silently */
	if( ( addr == NULL ) || ( *addr == 0 ) )
		longjmp( finish,FINISH_OK );
/* The message had X-Sender: nlist header, we have a mail loop
   here. Delete the message. */
        if( xsender_found ) {
	  Log( 2,1,"mail loop detected from %s",addr );
	  longjmp( finish,FINISH_OK );
	}
/* Analyzing whether it is a list command */
	adr2 = subject;
/* Must have subject for that */
	if( ( adr2 != NULL ) &&
	    ( ( adr2=strchr(adr2, ' ') ) != NULL ) ) { 	  
	  ++adr2;
	  if( !strncasecmp(adr2, "subscribe", 9) )
		handle_subscribe( adr2 );
	  if( !strncasecmp(adr2, "unsubscribe", 11) )
		handle_unsubscribe( adr2 );
	  if( !strncasecmp(adr2,"help",4 ) ) {
	    Log( 2,1,"help request for %s",addr );
	    longjmp( finish,HELP_MESSAGE );
	  }
	}
	if (argc==2) {		/* Called with list argument */
	  read_config( list_name,0 );
/* Creating new subject into subject_string */
	  *subject_string = 0;
	  if( subject ) {
            adr2 = subject+9;
	    if( ( *list_title != 0 ) &&
	        ( strstr( adr2,list_title ) == NULL ) )
	          sprintf( subject_string,"%s %s",list_title,adr2 );
	    if( *subject_string == 0 )
		strcpy( subject_string,adr2 );
	  }
	  sprintf(fname, "%s/%s.members", PATH, list_name);
	  member = file_open( fname,"r" );
/* Swallow the message silently if error message; should be
   processed ! */
	  if( ( addr != NULL ) &&
	      ( ( strncasecmp( addr,"mailer-daemon",13 ) == 0 ) ||
	        ( strncasecmp( addr,"postmaster",10 ) == 0 ) ) ) {
	    Log( 2,1,"automatic reply from %s swallowed",addr );
	    longjmp( finish, 1 );
	  }
/* spam filtering */
	  if( !spamfilt( TempFileName ) ) {
	    Log( 2,1,"letter from %s is filtered out by the spam filter",
			addr );
	    longjmp( finish,1 );
	  }
	  if( closed ) {	/* Check membership if the list is closed */
	    pass=0;
	    while((fscanf(member, "%s", work))!=EOF) {
	      if( strstr(work, addr) !=NULL )
	        pass=1;
	    }
	    if (pass==0) {
	      Log( 2,1,"%s is not member to list %s and the list is closed",
	              addr,list_name );
	      longjmp( finish,1 );
	    }
	  }
	  fclose(member);
	  sprintf( fname, "%s/%s.members", PATH, list_name);
	  member = file_open( fname,"r" );
	  while((s = getline(member))) if(*s) numlines++;
	  rewind(member);
/* Now creating parameter array for sendmail */
	  members=(char **)malloc( ( numlines+1 ) * sizeof(char *));
	  for( len = 0 ; len < numlines ; ++len )
		members[len] = getline(member);
	  members[len] = NULL;
	  tempfile = file_open( TempFileName,"r" );
	  sprintf( fname,"%s/%s.banner",PATH,list_name );
	  banner = fopen( fname,"r" );
/* Sending the message one by one */
	  for( len = 0 ; len < numlines ; ++len ) {
	    if( members[len] == NULL )
		continue;		/* Paranoia ... :-) */
	    Log( 3,1,"sending letter to %s",members[len] );
	    if( open_smtp_session( addr,members[len] ) ) {
	      close_socket();
	      continue;
	    }
/* Sending headers now */
	    sprintf( buf,"Subject: %s\n",subject_string );
	    write_smtp_line( buf );
	    send_list_headers( members[len] );	    
/* Now comes the message body */
	    write_smtp_line( "\n" );
/* Send out sender banner if any */
	    if( sender_banner ) {
	      sprintf( buf,INTL_SENDER,sender_full_address );
	      write_smtp_line( buf );
	    }
	    fseek( tempfile,ContentPointer,SEEK_SET );
	    while( fgets( buf, N_BUFSIZE, tempfile ) != NULL )
		write_smtp_line( buf );
	    if( banner != NULL ) {
	      while( fgets(buf, N_BUFSIZE, banner ) != NULL )
		    write_smtp_line( buf );
	      rewind( banner );	        
	    }
	    close_smtp_session();
          }	/* for( len == 0 ) */
	  free( members );
	  if( banner != NULL )
	          fclose( banner );
/* if archive is switched on, letter is piped into the listarchiver
   utility */
	  if( *archive != 0 ) {	/* Archiving switched on for this list */
	    command_array = (char **)malloc( 3 * sizeof( char * ) );
	    command_array[0] = "listarchiver";
	    command_array[1] = archive;
	    command_array[2] = NULL;
	    if(pipe(fds)==-1)
	  		ehandle(1, "pipe\n");
	    fc = fcntl(fds[1], F_GETFL, 0);
	    fcntl(fds[1], F_SETFL, fc & ~O_NONBLOCK);
	    newpid = fork();
            if( newpid ) {
              close( fds[0] );
	      if (fromcur) {
	        x=strlen(fromcur);
	        write(fds[1], fromcur, x );
	        write(fds[1], "\n", 1);
	      }
	      if( subject != NULL ) {
	        x=strlen( subject );
	        write(fds[1], subject, x );
	        write(fds[1], "\n", 1);
	      }
	      if( dateaddr ) {
	        x=strlen( dateaddr );
	        write(fds[1], dateaddr, x );
	        write(fds[1], "\n", 1);
	      }
	      write(fds[1], "\n", 1);
	      fseek( tempfile,ContentPointer,SEEK_SET );
	      while((numread = fread(buf, 1, N_BUFSIZE-1, tempfile)))
		write(fds[1], buf, numread);
	      close(fds[1]);
 	    } else {
 	      close( fds[1] );
	      close(0);
	      dup2( fds[0] , 0);
	      close( fds[0] );
	      sprintf( work,"%s/listarchiver",PATH );
	      if(execv(work, command_array )==-1)
			ehandle(1, "Unable to execute %s\n",work);
	    }
            free( command_array );
	  }	  
          fclose( tempfile );
/* Post to Usenet if requested */
	  if( *nntp_newsgroup != 0 )
	      nntp_post( addr );
	}	/* if( argc == 2 ) */
	longjmp( finish, FINISH_OK );
	return( 0 );		/* So that compiler don't complain */
}
