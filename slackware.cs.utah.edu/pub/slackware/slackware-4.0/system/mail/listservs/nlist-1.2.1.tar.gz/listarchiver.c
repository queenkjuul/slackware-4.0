/******* listarchiver.c
    List archiver program. Collects incoming messages into message
    archives. Written by Gabor Paller
			**************/


#include	<stdio.h>
#include	<sys/types.h>
#include	<sys/timeb.h>
#include	<time.h>
#include	<fcntl.h>
#include	<unistd.h>
#include	<string.h>
#include	<errno.h>
#include	<setjmp.h>
#define MAIN
#include	"config.h"

#include	<stdarg.h>
#if defined SOLARIS
#include	<sys/varargs.h>
#endif
 
#define	TRUE	1
#define	FALSE	0
typedef char	bool;

#define	FILEPATH	256	/* Length of the maximal file path */
#define	ENDCH				0

#define CANNOT_CHANGE_TO_DATADIR	10
#define CANNOT_OPEN_SPOOL		11
#define CANNOT_WRITE_INDEX		12
#define CANNOT_WRITE_LETTER		13
#define CANNOT_OPEN_INDEX		14
#define CANNOT_OPEN_CONFIG		15
#define	NO_LISTS			16
#define CANNOT_TRUNC_SPOOL		17
#define	CANNOT_OPEN_SCRATCH		18
#define	CANNOT_OPEN_STATUS		19
#define CANNOT_LOCK_STATUS		20

/* Jump buffer for error handling */
jmp_buf	finish;

/* Actual year */
int	ActYear;
/* Actual month */
int	ActMonth;
/* Actual message counter */
long	MessageCounter;
/* Sender of the actual letter */
char	fromfield[256];
/* Subject of the actual letter */
char	subjfield[256];
/* Date field of the actual letter */
char	datefield[256];
/* HTML conversion string */
char	htmlstr[512];
/* Log file name */
char	logfilename[FILEPATH];
/* Name of the actually created HTML file */
char	ActFileName[FILEPATH];
/* Handle of the status file - global so that it can remain locked */
FILE	*status = NULL;
/* Date in short format as produced by letter processor */
char	shortdate[256];

/* End-of-line flag */
int	eoln;
/* Actual string to be processed */
char	actline[256];
/* Pointer in the actual string */
char	*cptr;

/* Reads a character from the line. eoln is set to TRUE if end of line
   reached */
char gch() {
  char c = ENDCH;

  eoln = FALSE;
  if( *cptr == ENDCH )
	eoln = TRUE;
  else
	c = *( cptr++ );
  return c;
}

/* Reads in a line from a specified stream using read(). Buffers the
   result and gives back a pointer to the line separated by newline
   or end-of-file. Returns NULL on error */
char *read_line( char *buffer, int maxlen,int fd ) {
  static int	sterr = 0;	/* Stored error */
  char	*p,*p1;
  int	n;

  if( sterr )			/* Error was stored in the previous call */
	return NULL;
  p = buffer;
  errno = 0;
  do {
    n = read( fd,p,1 );
    p1 = p;
    if( n > 0 ) {
      p += n;
      maxlen -= n;
      if( ( *p1 == '\n' ) || ( maxlen <= 0 ) ) {
        *p = 0;
	return buffer;
      }
    }
  } while( n > 0 );
  *p = 0;
  sterr = 1;
  return p == buffer ? NULL : buffer;
}


/* Skips the next white characters in line. eoln is set to TRUE if end of
   line */
void skipspc() {
 while( isspace( gch() ) && !eoln );
 if( !eoln )
	--cptr;
}

/* Fits a string to the actual line. If it fits, pushes the actual pointer
   after the end of the string found and returns TRUE else returns FALSE
   and leaves the string pointer in place */
int fit( char str[] ) {
  register char *t,*s,c;
  int r = FALSE;

  s = str;
  skipspc();
  if( !eoln ) {
    t = cptr;
    while( ( ( c = *s ) != ENDCH ) && ( c == *t ) ) {
      s++; t++;
    }
    if( c == ENDCH ) {
      cptr = t;
      r = TRUE;
    }
  }
  return r;
}

/* Cuts down spaces from the beginning and end of a string and the closing
   newline as well */
void Trim( char s[] ) {
  char	*p;

  if( strlen( s ) == 0 )
	return;
  if( s[ strlen(s)-1 ] == '\n' )
	s[ strlen(s)-1 ] = 0;
  p = s;
  while( *p == ' ' )
	++p;
  if( s != p )
	strcpy( s,p );
  if( strlen( s ) == 0 )
	return;
  p = s + strlen( s ) - 1;
  while( *p == ' ' )
	--p;
  ++p;
  *p = 0;
}

/* Escapes a string into CGI-coded form. Gets the string, returns a pointer
  to the result */
char *Escape( char *s ) {
  static char	result[1024];
  char	c,*dest;

  dest = result;
  while( c = *(s++) ) {
    if( ( c != ' ' ) && !isalnum( c ) ) {
      sprintf( dest,"%%%02X",c );
      dest += 3;
    } else {
      if( c == ' ' )
	c = '+';
      *(dest++) = c;
    }
  }
  *dest = 0;
  return result;
}

/* Logs the error text into the log file */
void Log( char format[], ... ) {
  va_list	ap;
  FILE		*logfile;
  struct timeb	ts;
  struct tm	*tp;
  char	timestr[32];
  
  ftime( &ts );
  tp = localtime( &(ts.time) );
  strcpy( timestr,asctime( tp ) );
  timestr[ strlen( timestr ) - 1 ] = 0;
  if( ( logfile = fopen( "errorlog","a" ) ) == NULL )
	return;		/* What can we do ? Can't open error log ... */
  fprintf( logfile,"%s : ",timestr );
  va_start( ap,format );
  vfprintf( logfile,format,ap );
  va_end( ap );
  fprintf( logfile,"\n" );
  fclose( logfile );
}

/* Searches for the end of the file */
void SearchListEnd( FILE *indexfile ) {
  long	fp;

  while( !feof( indexfile ) ) {
    fp = ftell( indexfile );
    if( fgets( actline,256,indexfile ) != NULL ) {
      eoln = FALSE;
      cptr = actline;
      if( fit( "<!-- LISTEND -->" ) ) {
	fseek( indexfile,fp,SEEK_SET );
	break;
      }	/* if( fit ... ) */
    }		/* if( fgets ... ) */
  }		/* while( !feof() ) */
}

/* Reads the date and compares it with the status file's date.
   If the date changed compared to the status file, the message
   counter is set back to 0. Writes the new status file. Creates
   status file if it didn't exist. *DANGER* it keeps locked the
   status file. */
void AdjustConfigFile() {
  struct timeb ts;
  struct tm *tp;
  char	work[128];
  LOCK_STRUCT	lt;
  int	i,err;

  ActYear = 0;
  ActMonth = 0;
  MessageCounter = 0L;
l1:
  if( ( status = fopen( "status","r+" ) ) == NULL ) {
    if( ( status = fopen( "status","w" ) ) == NULL ) {
      Log( "Cannot create status file" );
      longjmp( finish, CANNOT_OPEN_STATUS );
    }
    goto l1;
  }
  lt.l_type = F_WRLCK;
  lt.l_whence = 0;
  lt.l_start = 0;
  lt.l_len = 0;
/* We try ten times to lock the file */
  for( i = 0 ; i < 10 ; ++i ) {
    err = fcntl( fileno( status ), F_SETLK, &lt );
    if( err >= 0 )
      break;
    if( ( err < 0 ) && ( errno == EAGAIN ) )
        sleep( 1 );
  }
  if( err < 0 ) {
    Log( "Cannot lock status file for 10 seconds" );
    fclose( status );
    longjmp( finish,CANNOT_LOCK_STATUS );
  }
  if( fgets( work,127,status ) != NULL )
	sscanf( work,"%i",&ActYear );
  if( fgets( work,127,status ) != NULL )
	sscanf( work,"%i",&ActMonth );
  if( fgets( work,127,status ) != NULL )
	sscanf( work,"%li",&MessageCounter );
          
  ftime( &ts );
  tp = localtime( &(ts.time) );
  if( ( ActYear != tp->tm_year ) || ( ActMonth != ( tp->tm_mon + 1 ) ) )
  {
    ActYear = tp->tm_year;
    ActMonth = tp->tm_mon + 1;
    MessageCounter = 0L;
  }
  fseek( status,0L,SEEK_SET );
  fprintf( status,"%i\n",ActYear );
  fprintf( status,"%i\n",ActMonth );
  fprintf( status,"%li\n",MessageCounter+1 );
/* Status file is updated but not closed and unlocked. That we will do
   at the end of the program so that other instances of this program
   keep waiting at the beginning of this routine and they don't blast
   the HTML-updating tasks */
  fflush( status );
}

/* Writes the string in HTML format, converts special characters into
   escaped version. Gets the string, returns the converted string */
char *WriteHTMLString( char actline[] )
{
  char	*p,*dp;
  int	cc = 0;

  dp = htmlstr;
  for( p = actline; ( *p != ENDCH ) && ( cc < 506 ) ; ++p )
    if( *p == '<' ) {
      *dp = 0;
      strcat( dp,"&lt;" );
      dp += 4;
      cc += 4;
    }
    else if( *p == '>' ) {
      *dp = 0;
      strcat( dp,"&gt;" );
      dp += 4;
      cc += 4;
    }
    else {
      *(dp++) = *p;
      ++cc;
    }
  *dp = 0;
  return htmlstr;
}

/* Checks the existence of the index page and creates a new index
   page if it does not exist */
void CheckIndexFile() {
  char	IndexFileName[FILEPATH];
  FILE	*indexfile,*monthindex,*subjectfile;

  sprintf( IndexFileName,"%03i%02i.html",ActYear,ActMonth );
  if( ( indexfile = fopen( IndexFileName,"r" ) ) == NULL ) {
    if( ( indexfile = fopen( IndexFileName,"w" ) ) == NULL ) {
      Log( "Cannot write index file: %s",IndexFileName );
      longjmp( finish, CANNOT_WRITE_INDEX );
    }
    fprintf( indexfile,"<HTML>\n<HEAD>\n<TITLE>Tartalomjegyz&eacute;k: %i %s</TITLE>\n</HEAD>\n<BODY>",
	1900+ActYear, MonthNames[ ActMonth - 1 ] );
    fprintf( indexfile,
	"<H1>Tartalomjegyz&eacute;k: %i %s</H1>\n<HR>\n",
	 1900+ActYear, MonthNames[ ActMonth - 1 ] );
    fprintf( indexfile,"<ul>\n<!-- LISTEND -->\n</ul>\n" );
    fprintf( indexfile,
      "<HR><a href=\"index.html\"><img src=\"%sback.gif\"></a>\n",
			ICONDIR );
    if( ( monthindex = fopen( "index.html","r+" ) ) != NULL ) {
      SearchListEnd( monthindex );
      fprintf( monthindex,"<a href=\"%s\">%i %s</a><br>\n",
		IndexFileName,
		1900+ActYear,
		MonthNames[ ActMonth - 1 ] );
      fprintf( monthindex,"<!-- LISTEND -->\n" );
      fprintf( monthindex,
         "<a href=\"/\"><img src=\"%sback.gif\"></a>\n",ICONDIR );
      fclose( monthindex );
    }
  }
  fclose( indexfile );
}

/* Inserts a forward chain to the actual letter into the previous
   letter */
void InsertForwardChain()
{
  char	PrevFileName[FILEPATH],ActFileName[FILEPATH];
  FILE	*prevfile,*scratch;
  if( MessageCounter == 0L )
      return;
  sprintf( PrevFileName,"%03i%02i%li.html",ActYear,ActMonth,
		MessageCounter-1 );
  if( ( prevfile = fopen( PrevFileName,"r+" ) ) != NULL ) {
    if( ( scratch = fopen( "scratch","w" ) ) == NULL ) {
      Log( "Cannot open scratch for forward chain inserting" );
      longjmp( finish, CANNOT_OPEN_SCRATCH );
    }
    while( fgets( actline,256,prevfile ) != NULL ) {
      eoln = FALSE;
      cptr = actline;
      if( fit( "<!-- FORWARDICON -->" ) ) {
        fprintf( scratch,
"<td><a href=\"%03i%02i%li.html\"><img src=\"%sforward.gif\"></a></td>\n",
	    ActYear,ActMonth,MessageCounter,ICONDIR );
      }	else /* if( fit ... ) */
          fprintf( scratch,"%s",actline );
    }		/* while( fgets ) */
    fclose( prevfile );
    fclose( scratch );
    rename( "scratch",PrevFileName );
  }		/* if( ( prevfile = ... */
}		/* void InsertForwardChain() */

/* Inserts the arrowbar at the end of the letter. Gets the file handle */
void InsertArrowBar( FILE *prevfile ) {
  fprintf( prevfile,"<center>\n<table>\n<tr>\n" );
  if( MessageCounter > 0L ) {
    fprintf( prevfile,
    "<td><a href=\"%03i%02i%li.html\"><img src=\"%sback.gif\"></a></td>\n",
	    ActYear,ActMonth,MessageCounter-1,ICONDIR );
  }
  fprintf( prevfile,
    "<td><a href=\"%03i%02i.html\"><img src=\"%sup.gif\"></a></td>\n",
	    ActYear,ActMonth,ICONDIR );
  fprintf( prevfile,"<!-- FORWARDICON -->\n</tr>\n</table>\n</center>\n" );
}

/* Reads a letter from the file stream and converts it into HTML
   format. Writes the converted letter to disk and adds a reference
   to the index file. */
void ConvertLetterToHTML() {
  FILE	*actfile;
  char	*sp,*ep;
  int	n;

  CheckIndexFile();
  sprintf( ActFileName,"%03i%02i%li.html",ActYear,ActMonth,
		MessageCounter );
  if( ( actfile = fopen( ActFileName,"w" ) ) == NULL ) {
    Log( "Cannot write: %s",ActFileName );
    longjmp( finish, CANNOT_WRITE_LETTER );
  }
  InsertForwardChain();
  fprintf( actfile,"<HTML>\n<HEAD>\n<TITLE>%s</TITLE>\n</HEAD>\n<BODY>\n",
	subjfield );
/* Cutting down leading spaces from datefield */
  sp = datefield;
  while( ( *sp == ' ' ) || ( *sp == '\t' ) )
	++sp;
  strcpy( datefield,sp );
  Trim( datefield );
  Trim( fromfield );
  Trim( subjfield );
  if( *subjfield == 0 )
	strcpy( subjfield,"<no subject>" );
  fprintf( actfile,"<!-- %s -->\n",WriteHTMLString( fromfield ) );
  fprintf( actfile,"<I>%s</I><P>\n",WriteHTMLString( datefield ) );
  fprintf( actfile,"<H3>%s</H3><P>\n",WriteHTMLString( fromfield ) );
  fprintf( actfile,"<H1>%s</H1><P>\n<HR>\n",WriteHTMLString( subjfield ) );
  fprintf( actfile,"<PRE>\n" );
  while( read_line( actline, 255, 0 ) != NULL ) {
    fputs( WriteHTMLString( actline ),actfile );
    fputs( "<br>",actfile );
  }
  fprintf( actfile,"</PRE>\n" );
  InsertArrowBar( actfile );
  fclose( actfile );
/* Then the date is preceded by day abbrev - cut it */
  if( datefield[3] == ',' )
	strcpy( shortdate,datefield+5 );
  else
	strcpy( shortdate,datefield );
  if( *shortdate == '0' )
	strcpy( shortdate,shortdate+1 );
  sp = shortdate;
/* Skip four fields to get the short date */
  for( n = 0 ; ( n < 4 ) && ( sp != NULL ) ; ++n ) {
    sp = strchr( sp,' ' );
    if( sp != NULL )
	++sp;
  }
  if( sp != NULL )
	*sp = 0;
}

/* Processes the incoming mail arriving from stdin */
void ProcessIncomingMail() {
  char	IndexFileName[FILEPATH];
  FILE	*index1,*index2;

  *fromfield = 0;
  *datefield = 0;
  *subjfield = 0;
  while( read_line( actline,255,0 ) != NULL ) {
    cptr = actline;
    eoln = TRUE;
    if( fit( "From: " ) ) {
      strncpy( fromfield, cptr,256 );
      fromfield[255] = 0;
    } else if( fit( "Date: " ) ) {
      strncpy( datefield, cptr,256 );
      datefield[255] = 0;
    } else if( fit( "Subject: " ) ) {
      strncpy( subjfield, cptr,256 );
      subjfield[255] = 0;
    }
/* If an empty line closing the header, we read the letter and transform
   it into HTML form */
    else if( *actline == '\n' ) {
      ConvertLetterToHTML();
      break;
    }
  }
/* Updating index file */
  sprintf( IndexFileName,"%03i%02i.html",ActYear,ActMonth );
  if( ( index1 = fopen( IndexFileName,"r" ) ) == NULL ) {
    Log( "Cannot open index: %s",IndexFileName );
    longjmp( finish, CANNOT_OPEN_INDEX );
  }
  if( ( index2 = fopen( "scratch","w" ) ) == NULL ) {
    Log( "Cannot open scratch" );
    longjmp( finish, CANNOT_OPEN_SCRATCH );
  }
  while( fgets( actline,256,index1 ) != NULL ) {
    cptr = actline;
    eoln = TRUE;
    if( fit( "<!-- LISTEND -->" ) ) {
      fprintf( index2,"<li><a href=\"%s\">%s</a> : %s",ActFileName,
			WriteHTMLString( subjfield ),shortdate );
      fprintf( index2," : %s\n",WriteHTMLString( fromfield ) );      
    }
    fprintf( index2,"%s",actline );
  }
  fclose( index1 );
  fclose( index2 );
  rename( "scratch",IndexFileName );
}

/* Mail archiver main program */
int main( int argc, char *argv[] ) {
  int	err;

  if( argc < 2 ) {
    fprintf( stderr,"Usage: listarchiver <archive directory>" );
    exit( 1 );
  }
  if( chdir( argv[1] ) != 0 ) {
    fprintf( stderr,"Cannot change to directory %s\n",argv[1] );
    exit( 1 );
  }
  if( ( err = setjmp( finish ) ) ) {
    if( status != NULL )
	fclose( status );	/* Status file must be unlocked */
    exit( err-1 );
  }
  AdjustConfigFile();
  ProcessIncomingMail();
/* We close now the status file so that other instances of this program
   can get in */
  fclose( status );
  return 0;
}
