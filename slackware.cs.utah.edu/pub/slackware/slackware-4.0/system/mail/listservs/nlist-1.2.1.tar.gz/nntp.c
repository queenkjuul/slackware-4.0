/************ nntp.c
	NNTP interface for nlist. Written by Gabor Paller
			    **********/
			    
#include	<stdio.h>
#include	<string.h>
#include	<unistd.h>
#include	<sys/timeb.h>
#include	<time.h>
#include	<errno.h>
#include	"config.h"

/* Imports from nlist.c */
void Log( int loglevel, int datestr, char format[], ... );
void ehandle(int level, char format[], ...);
void open_socket( char server[], int port );
void close_socket();
void socket_write_line( char *buffer );
void socket_read_line( char *buffer, int bufsize );
void write_smtp_line( char *buffer );

extern char	nntp_newsgroup[];
extern char	nntp_server[];
extern int	nntp_port;
extern char	nntp_list_address[];
extern char	nntp_from_address[];
extern char	nntp_replyto[];
extern char	TempFileName[];
extern long	ContentPointer;
extern char	protstr[];
extern char	subject_string[];
extern int	sender_banner;
extern char	*sender_full_address;
extern char	list_name[];
extern char	fname[];

static char	tempbuffer[256];
static char	outbuffer[256];

static char *nntp_daynames[] = {
  "Sun","Mon","Tue","Wed","Thu","Fri","Sat"
};

static char *nntp_monthnames[] = {
  "Jan","Feb","Mar","Apr","May","Jun",
  "Jul","Aug","Sep","Oct","Nov","Dec"
};

/* Opens an NNTP session to the NNTP server */
int open_nntp_session() {
  int	retry = 10;

  strcpy( protstr,"NNTP" );
l0:
  if( retry == 0 )
    ehandle( 1,"NNTP error: %i:'%s'\n",errno,tempbuffer );
  open_socket( nntp_server, nntp_port );
  do {
    socket_read_line( tempbuffer,255 );
    if( strncmp( tempbuffer,"200",3 ) == 0 )	/* OK */
	break;
    if( strncmp( tempbuffer,"201",3 ) == 0 )	/* No posting allowed */ 
	ehandle( 1,"NNTP error: %s",tempbuffer );
/* Some garbage arrived. Terminate the connection,
   close the socket and retry. I don't know how it can happen
   but it happens ... :-( */
    --retry;
    close_socket();
    sleep( 1 );		/* Wait 1 second */
    goto l0;
  } while( 1 );
/* This code is of little importance. I use INN on my testing
   machine and INND must be switched into reader mode if
   I post news articles from the server. In general case,
   this check is not needed */
  if( ( strstr( tempbuffer,"INN" ) != NULL ) &&
      ( strstr( tempbuffer,"NNRP" ) == NULL ) ) {
    socket_write_line( "mode reader\r\n" );
    socket_read_line( tempbuffer,255 );
    if( strstr( tempbuffer,"NNRP" ) == NULL )
	ehandle( 1,"Cannot switch NNTP server to reader mode: %s",
		tempbuffer );
  }
  socket_write_line( "POST\n" );
  socket_read_line( tempbuffer,255 );
  if( strncmp( tempbuffer,"340",3 ) != 0 )
	ehandle( 1,"NNTP POST error: %s",tempbuffer );
  return 0;
}

/* Closes the NNTP session */
void close_nntp_session() {
  socket_write_line( "\n.\n" );
  socket_read_line( tempbuffer,255 );
  if( strncmp( tempbuffer,"240",3 ) != 0 )
          ehandle( 1,"NNTP posting failed: %s",tempbuffer );
  socket_write_line( "QUIT\n" );
  socket_read_line( tempbuffer,255 );
  close_socket();  
}

/* Calculates a simple hash value to be used for message id */
int make_hash( FILE *infile ) {
  int hash = 0xABCD1234;
  char	*p,c;
  while( fgets( tempbuffer,255,infile ) != NULL ) {
    p = tempbuffer;
    while( c = *(p++) ) {
      hash = hash << 1 | ( ( hash & 0x80000000 ) == 0 );
      hash ^= ((int)c) & 0xFF;
    } 
  }
  return hash;
}

/* Posts the letter to the newsgroup */
void nntp_post( char from[] ) {
  FILE	*letter,*banner;
  int	hash;
  char	hostname[128],domainname[128];
  struct timeb ts;
  struct tm *tp;
  
  if( ( letter = fopen( TempFileName,"r" ) ) == NULL )
      ehandle( 1,"Cannot open letter file %s for NNTP posting",
                  TempFileName );
  fseek( letter,ContentPointer,SEEK_SET );
/* Calculate a simple hash for Message-ID */
  hash = make_hash( letter );
  fseek( letter,ContentPointer,SEEK_SET );
/* Opens nntp session */
  open_nntp_session();
/* From header goes out */
  sprintf( tempbuffer,"From: %s\n",
                subst_lname( nntp_from_address,sender_full_address,
		"news",
		nntp_list_address ) );
  write_smtp_line( tempbuffer );
/* Entry path */
  write_smtp_line( "Path: entry\n" );
/* Newsgroups */
  sprintf( tempbuffer,"Newsgroups: %s\n",nntp_newsgroup );
  write_smtp_line( tempbuffer );
/* Subject */
  sprintf( tempbuffer,"Subject: %s\n",subject_string );
  write_smtp_line( tempbuffer );
/* Message ID */
  gethostname( hostname,127 );
  getdomainname( domainname,127 );
/* This is again my testing environment where domains
   are not properly set up. My Linux box returns (none)
   as domain name and it is not accepted by the news server.
   We fix it here. */
  if( strncmp( domainname,"(none)",6 ) == 0 )
      strcpy( domainname,"localdomain" );
  sprintf( tempbuffer,"Message-ID: <%08X.%u@%s.%s>\n",hash,
                                      getpid(),hostname,
				      domainname );
  write_smtp_line( tempbuffer );
/* Date. We don't rely on the date header of the original
   mailer of the letter as mail programs can often produce
   hideous date fields. The news post is timestamped by
   nlist */
  ftime( &ts );
  tp = gmtime( &(ts.time) );
  sprintf( tempbuffer,"Date: %s, %02i %s %04i %02i:%02i:%02i GMT\n",
              nntp_daynames[tp->tm_wday],tp->tm_mday,
	      nntp_monthnames[tp->tm_mon],tp->tm_year+1900,
	      tp->tm_hour,tp->tm_min,tp->tm_sec );
  write_smtp_line( tempbuffer );
  if( *nntp_replyto != 0 ) {
    sprintf( tempbuffer,"Reply-To: %s\n",subst_lname( nntp_replyto,
		sender_full_address,
		"news",
		nntp_list_address ) );
    write_smtp_line( tempbuffer );
  }
  write_smtp_line( "\n" );
  if( sender_banner ) {
    sprintf( tempbuffer,INTL_SENDER,sender_full_address );
    write_smtp_line( tempbuffer );
  }
  while( fgets( tempbuffer,255,letter ) != NULL ) {
    write_smtp_line( tempbuffer );
  }
  fclose( letter );
  sprintf( fname,"%s/%s.banner",PATH,list_name );
  banner = fopen( fname,"r" );
  if( banner != NULL ) {
    while( fgets( tempbuffer, N_BUFSIZE, banner ) != NULL )
		    write_smtp_line( tempbuffer );
    fclose( banner );
  }
  close_nntp_session();
}
