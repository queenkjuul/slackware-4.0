/* TransferMail 1.0                                                          
   This program sends mail spooled using beromail to the net.        
   
   (c) 1996 by Bernhard Rosenkraenzer <root@startrek.in-trier.de>        */
   
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "beromail.h"

char exist(char *filename)
{
	FILE *temp;
	temp=fopen(filename,"r");
	if(temp==NULL)
		return 0;
	else {
		fclose(temp);
		return 1;
	}
}

int main(int argc, char *argv[])
{
	char *filename_base, *filename, *command;
	register int i,ret;
	
	filename_base=(char *) malloc(strlen(SPOOLDIR)+7);
	strcpy(filename_base,SPOOLDIR);
	strcpy(filename_base+strlen(SPOOLDIR),"/mail.");
	
	filename=(char *) malloc(strlen(filename_base)+5);
	command=(char *) malloc(strlen(TRANSFER_COMMAND)+2+strlen(filename)+1);
	
	for(i=0;i<10000;i++) {
		sprintf(filename,"%s%d\0",filename_base,i);
		if(exist(filename)) {
			printf("%s\n",filename);
			sprintf(command,"%s <%s\0",TRANSFER_COMMAND,filename);
			ret=system(command);
			printf("%s returned %d.\n",command,ret);
			sync();			// Make sure file is not locked.
			if(ret==0) {
				printf("Ok... Deleting.\n");
				remove(filename);
			}
		} else {
			return 0;
		}
	}
	return 0;
}
