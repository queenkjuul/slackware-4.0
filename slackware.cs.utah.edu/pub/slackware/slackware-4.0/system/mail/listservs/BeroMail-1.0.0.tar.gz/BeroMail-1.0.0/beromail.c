/* BeroMail 1.0                                                          
   This program spools outgoing mail so it can be sent as soon as        
   a connection to the net is made. Optimal for expensive connections...
   
   (c) 1996 by Bernhard Rosenkraenzer <root@startrek.in-trier.de>        */
   
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include "beromail.h"
#include "header.h"

char exist(char *filename)
{
	FILE *temp;
	temp=fopen(filename,"r");
	if(temp==NULL)
		return 0;
	else {
		fclose(temp);
		return 1;
	}
}

int main(int argc, char *argv[])
{
	FILE *out;
	char *filename_base, *filename;
	char *hostname,*fullhostname;
	char *message;
	char *to;
	register char c;
	register int i=0;
	char local=0;
	
	/* Find local hostname */
	hostname = (char *) malloc(1024); /* Don't tell me - I know I'm exaggerating */
	fullhostname = (char *) malloc(1024);
	gethostname(hostname,1024);
	strcpy(fullhostname,hostname);
	fullhostname[strlen(fullhostname)+1]='\0';
	fullhostname[strlen(fullhostname)]='.';
	getdomainname(fullhostname+strlen(fullhostname),1024-strlen(fullhostname)-1);
	
	/* Read message... */
	message=(char *) malloc(1024);
	while(!feof(stdin)) {
		c=(char) fgetc(stdin);
		if(c!=EOF)
			message[i++]=c;
		if(i%1024==0)
			message=(char *) realloc(message,i+1024);
	}
	message[i]='\0';
	
	/* Find recipient... */
	to=extract(message,"To: ",'\n');
	
	/* Check for local user... */
	if(to!=NULL) {                 /* Paranoia check... */
		if(strchr(to,'@')==NULL)
			local=1;
		else
			if((strcasecmp(strchr(to,'@')+1,hostname)==0)||strcasecmp(strchr(to,'@')+1,fullhostname)==0||strcasecmp(strchr(to,'@')+1,"localhost")==0)
				local=1;
	}
	if(local==1) {
		/* Deliver mail locally */
		filename=(char *) malloc(strlen(SENDMAIL_COMMAND)+4);
		sprintf(filename,"%s -t",SENDMAIL_COMMAND);
		out=popen(filename,"w");
		fprintf(out,"%s",message);
		pclose(out);
		return 0;
	}
	
	filename_base=(char *) malloc(strlen(SPOOLDIR)+7);
	strcpy(filename_base,SPOOLDIR);
	strcpy(filename_base+strlen(SPOOLDIR),"/mail.");
	
	filename=(char *) malloc(strlen(filename_base)+5);
	
	for(i=0;i<10000;i++) {
		sprintf(filename,"%s%d\0",filename_base,i);
		if(!exist(filename)) {
			umask(066);
			out=fopen(filename,"w");
			fprintf(out,"%s",message);
			fclose(out);
			sync();
			free(message);
			free(filename);
			free(filename_base);
			return 0;
		}
	}
	printf("Out of mailer space. :(\n");
	return 1;
}
