#include <stdio.h>
#include <string.h>

char *extract(char *from, const char *begin, const char end)
{
  #define VALIDCHAR "\t\n\r\b\000"
  char *found,*result;

  found=strstr(from,begin);

  while(found){
    if(strchr(VALIDCHAR,(int) (*(found-1))) || !(*(found-1))) {
          result=(char *) malloc(strlen(from) + 1);
          strcpy(result,(char *) found+strlen(begin));
          if((char *) strchr(result,end)!=NULL)
                  result[strchr(result,end)-result]='\0';
          if((char *) strchr(result,'\n')!=NULL)
                  result[strchr(result,'\n')-result]='\0';
          return(result);
    };
    found=strstr(found+1,begin);
  };
  return(NULL);
}

char *email(char *full_address)
{
  /* Get the plain address part from an e-mail address */
  /* (i.e. remove realname) */
  
  char *addr;
  
  addr=(char *) malloc(strlen(full_address)+1);
  strcpy(addr, full_address);
  
  /* Realname <user@host> type address */
  if(((char *) strchr(addr,'<'))!=NULL) {
  	addr=(char *) strchr(addr,'<')+1;
  	addr[strchr(addr,'>')-addr]='\0';
  }
  
  /* user@host (Realname) type address */
  if(((char *) strchr(addr,' '))!=NULL)
  	addr[strchr(addr,' ')-addr]='\0';
  
  return(addr);
  
}

char *realname(char *full_address)
{
  char *name;
  
  name=(char *) malloc(strlen(full_address)+1);
  strcpy(name,full_address);

  if(((char *) strchr(name,'<'))!=NULL)
  	/* Realname <user@host> type address */
  	name[strchr(name,'<')-1-name]='\0';
  else if(((char *) strchr(name,'('))!=NULL) {
  	/* user@host (Realname) type address) */
  	name=strchr(name,'(')+1;
  	name[strchr(name,')')-name]='\0';
  } else
  	/* Realname not specified -> use username */
  	name[strchr(name,'@')-name]='\0';
  
  return(name);
  
}

char *username(char *address)
{
  char *name;
  name=email(address);
  if ( strchr(name,'@') != NULL )
    name[strchr(name,'@')-name]='\0';
  return(name);
}

char *readline(FILE *file)
{
  char *line;
  register char last;
  register int len;

  line=(char *) malloc(sizeof(char)*1024);
  last=0; len=0;
  while(!feof(file) && last!='\n') {
  	last=(char) fgetc(file);
  	if(last!='\n' && last!=EOF && !feof(file))
  		line[len++]=last;
  }
  line[len]='\0';
  return(line);
}
