/* SMTP-OUT v1.0
   Forwards messages to the nearest SMTP-Server around to keep
   connection time short. */

#define HEADER			1
#define MAIL			2

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "beromail.h"
#include "header.h"
#include "socket.h"
extern int errno;

int main(int argc, char *argv[])
{
	char *header, *line, *parameter, *value, *from, *to, *reply, *cc, *bcc, *rcptto, *save_to;
	int socket;
	register int mode=HEADER;
	register int i;
	int success=0;
	
	line=(char *) malloc(512*1024);  /* 512k-Mails should be big enough...                       */
	header=(char *) malloc(20*1024); /* 20k per header... Good enough.                           */
	parameter=(char *) malloc(8096); /* 8k for an address? I gotta be kiddin'...                 */
	value=(char *) malloc(8096);     /* 8k for an address? I gotta be kiddin'...                 */
	from=(char *) malloc(8096);      /* 8k for an address? I gotta be kiddin'...                 */
	reply=(char *) malloc(8096);     /* 8k for a server reply? ditto...                          */
	to=(char *) malloc(65536);       /* Always keep in mind: To: User1,User2,User3,... is valid  */
	cc=(char *) malloc(65536);       /* Can't be cautious enough...                              */
	bcc=(char *) malloc(65536);      /* Can't be cautious enough...                              */
	rcptto=(char *) malloc(65536);   /* Can't be cautious enough...                              */
	
	save_to=to;

	socket=Socket(SERVER,25);
	if(socket<=0) {
		puts("Error: Can't connect.");
		return 1;
	}
	printf("Connected! Socket ID: %d\n\n",socket);
	SockGets(socket,reply,8096);
	puts(reply);
	SockPrintf(socket,"HELO %s\r\n",HOST);
	SockGets(socket,reply,8096);
	puts(reply);
	
	header[0]='\0';
	cc[0]='\0';
	bcc[0]='\0';
	
	while(!feof(stdin)) {
		strcpy(line,readline(stdin));
		if(line[0]=='\0' && mode==HEADER) {
			printf("MAIL FROM: %s\n",email(from));
			SockPrintf(socket,"MAIL FROM: %s\r\n",email(from));
			SockGets(socket,reply,8096);
			puts(reply);

			/* Find all recipients for RCPT TO: field */
			
			if(strchr(to,',')!=NULL) {
				while(strchr(to,',')!=NULL) {
					strcpy(line,to);
					line[strchr(line,',')-line]='\0';
					to=strpbrk(to,",")+1;
					while(to[0]==' ' || to[0]==9) to++;
					printf("RCPT TO: %s\n",email(line));
					SockPrintf(socket,"RCPT TO: %s\r\n",email(line));
					SockGets(socket,reply,8096);
					puts(reply);
				}
				printf("RCPT TO: %s\n",email(to));
				SockPrintf(socket,"RCPT TO: %s\r\n",email(to));
				SockGets(socket,reply,8096);
				puts(reply);
			} else {
				printf("RCPT TO: %s\n",email(to));
				SockPrintf(socket,"RCPT TO: %s\r\n",email(to));
				SockGets(socket,reply,8096);
				puts(reply);
			}
			if(strlen(cc)>0) {
				to=cc;
				if(strchr(to,',')!=NULL) {
					while(strchr(to,',')!=NULL) {
						strcpy(line,to);
						line[strchr(line,',')-line]='\0';
						to=strpbrk(to,",")+1;
						while(to[0]==' ' || to[0]==9) to++;
						printf("RCPT TO: %s\n",email(line));
						SockPrintf(socket,"RCPT TO: %s\r\n",email(line));
						SockGets(socket,reply,8096);
						puts(reply);
					}
					printf("RCPT TO: %s\n",email(to));
					SockPrintf(socket,"RCPT TO: %s\r\n",email(to));
					SockGets(socket,reply,8096);
					puts(reply);
				} else {
					printf("RCPT TO: %s\n",email(to));
					SockPrintf(socket,"RCPT TO: %s\r\n",email(to));
					SockGets(socket,reply,8096);
					puts(reply);
				}
			}
			if(strlen(bcc)>0) {
				to=bcc;
				if(strchr(to,',')!=NULL) {
					while(strchr(to,',')!=NULL) {
						strcpy(line,to);
						line[strchr(line,',')-line]='\0';
						to=strpbrk(to,",")+1;
						while(to[0]==' ' || to[0]==9) to++;
						printf("RCPT TO: %s\n",email(line));
						SockPrintf(socket,"RCPT TO: %s\r\n",email(line));
						SockGets(socket,reply,8096);
						puts(reply);
					}
					printf("RCPT TO: %s\n",email(to));
					SockPrintf(socket,"RCPT TO: %s\r\n",email(to));
					SockGets(socket,reply,8096);
					puts(reply);

				} else {
					printf("RCPT TO: %s\n",email(to));
					SockPrintf(socket,"RCPT TO: %s\r\n",email(to));
					SockGets(socket,reply,8096);
					puts(reply);
				}
			}
			puts("DATA");
			SockPrintf(socket,"DATA\r\n");
			SockGets(socket,reply,8096);
			puts(reply);
			puts(header);
			SockPuts(socket,header);
			mode=MAIL;
		} else {
			if(line[0]=='.' && line[1]=='\0') {
				line[1]=' ';
				line[2]='\0';
			}
			if(mode==HEADER) {
				if(strchr(line,':')!=NULL) {
					strcpy(parameter,line);
					parameter[strchr(parameter,':')-parameter]='\0';
					strcpy(value,strpbrk(line,":")+1);
					if(value[0]=' ') strcpy(value,value+1);
					if(strcasecmp(parameter,"from")==0)
						strcpy(from,value);
					else if(strcasecmp(parameter,"to")==0)
						strcpy(to,value);
					else if(strcasecmp(parameter,"cc")==0)
						strcpy(cc,value);
					else if(strcasecmp(parameter,"bcc")==0)
						strcpy(bcc,value);
					if(strcasecmp(parameter,"bcc")!=0) {
						/* Do not put Bcc: in the mail */
						strcpy(header+strlen(header),line);
						strcpy(header+strlen(header),"\n");
					}
				}
			}
			else if(mode==MAIL) {
				puts(line);
				SockPuts(socket,line);
			}
		}
	}
	SockPrintf(socket,".\r\n");
	SockGets(socket,reply,8096);
	puts(reply);
	if(strstr(reply,"accepted")!=NULL || strstr(reply,"ACCEPTED")!=NULL || strstr(reply,"Accepted")!=NULL)
		success=1;
	if(success==1) puts("Mail accepted ! :)\n");
	          else puts("Mail rejected ! :(\n");
	SockPrintf(socket,"QUIT\r\n");
	SockGets(socket,reply,8096);
	puts(reply);
	puts("Killing socket...\n");
	SockKill(socket);
	puts("Un-Allocating space...\n");
	free(from);
	free(save_to);
	free(value);
	free(parameter);
	free(header);
	free(line);
	free(reply);
	free(cc);
	free(bcc);
	free(rcptto);
	puts("Syncing disk...\n");
	sync();
	if(success==0) {
		puts("Error... Will retry next time.\n");
		return 1;
	}
	puts("Message sent.\n");
	return 0;
}
