char *extract(char *from, const char *begin, const char end);
char *email(char *full_address);
char *realname(char *full_address);
char *username(char *address);
char *readline(FILE *file);
