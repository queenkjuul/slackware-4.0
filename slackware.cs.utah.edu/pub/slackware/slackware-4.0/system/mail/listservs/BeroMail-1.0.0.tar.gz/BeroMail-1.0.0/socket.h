int Socket(char *host, int clientPort);
int SockGets(int socket, char *buf, int len);
int SockPuts(int socket, char *buf);
int SockWrite(int socket, char *buf, int len);
int SockRead(int socket, char *buf, int len);
int SockPrintf(int socket, char *format, ...) ;
int SockStatus(int socket, int seconds);
int SockKill(int socket);