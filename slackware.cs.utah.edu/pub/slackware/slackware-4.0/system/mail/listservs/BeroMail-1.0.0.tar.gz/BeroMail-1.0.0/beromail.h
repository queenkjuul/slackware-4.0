/* Header file... */

/* SMTP Server */
#define SERVER                  "mail.in-trier.de"

/* Hostname to use in HELO request */
#define HOST                    "ufp.in-trier.de"

/* Some pathnames... */

#define SPOOLDIR "/var/spool/beromail"
#define TRANSFER_COMMAND "/usr/bin/smtp-out"
#define SENDMAIL_COMMAND "/usr/bin/sendmail"
#define RM_COMMAND "/bin/rm"
