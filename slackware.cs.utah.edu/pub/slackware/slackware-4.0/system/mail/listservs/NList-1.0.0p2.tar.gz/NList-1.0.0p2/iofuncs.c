#include <stdio.h>

struct ListNode
{
	char car;
	struct ListNode *cdr;
};

char *getline(FILE *fp)
{
	struct ListNode *head, *tail;
	char c, *ans;
	int len = 1;

	head = tail = (struct ListNode *)malloc(sizeof(struct ListNode));

	while(((c = fgetc(fp)) != EOF) && (c != '\n'))
	{
		tail->cdr = (struct ListNode *)malloc(sizeof(struct ListNode));
		tail = tail->cdr;
		tail->car = c;
		len++;
	}
	tail->cdr = NULL;
	if((c == EOF) && (head == tail))
	{
		ans = NULL;
	}
	else
	{
		ans = (char *)malloc(len * sizeof(char));

		tail = head;
		head = head->cdr; /* Get rid of the "sentinel" */
		free(tail);

		len = 0;
		while(head)
		{
			ans[len] = head->car;
			tail = head;
			head = head->cdr;
			free(tail);
			len++;
		}
		ans[len] = '\0';
	}

	return(ans);
}
