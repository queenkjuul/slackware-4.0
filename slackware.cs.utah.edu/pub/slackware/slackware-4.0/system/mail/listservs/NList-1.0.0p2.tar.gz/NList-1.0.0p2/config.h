/* Size of temporary buffer. This is a pretty good value. I wouldn't change it */

#define BUFSIZE 100

/* Location of sendmail. Likely /usr/sbin/sendmail */

#define SENDMAIL_PATH "/usr/sbin/sendmail"

/* Location of the nlist and the list files */
/* This should be the location in which you installed NList */
/* DO NOT FORGET THE TRAILING / NList WILL _NOT_ WORK RIGHT WITHOUT IT */

#define PATH "/usr/local/bin/NList/"

/* Define this if you don't want NList to display what list the message */
/* came from in each message */
/* >>> "whatever" */

#define QUIET
