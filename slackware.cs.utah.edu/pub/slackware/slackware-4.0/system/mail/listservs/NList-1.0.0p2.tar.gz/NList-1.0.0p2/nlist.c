 /************************************************************************ 
  *                                                                      *
  *    NList 1.0.0p2 Copyright (C) 1997 Erich Menge (erich@minn.net)     *
  *                                                                      *
  * This program is free software; you can redistribute it and/or modify *
  * it under the terms of the GNU General Public License as published by *
  * the Free Software Foundation; either version 2 of the License, or    *
  * (at your option) any later version.                                  *
  *                                                                      *
  * This program is distributed in the hope that it will be useful,      *
  * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
  * GNU General Public License for more details.                         *
  *                                                                      *
  * You should have received a copy of the GNU General Public License    *
  * along with this program; if not, write to the Free Software          *
  * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            *
  *                                                                      *
  ************************************************************************/

#include "config.h"
#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

char *getline(FILE *fp);

ehandle(int level, char *message)
{
	switch (level)
	{
		case 1:
		fprintf(stderr, "Error: %s", message);
		exit(1);
		break;
		case 0:
		fprintf(stderr, "Warning: %s", message);
		break;
	}
} 

main(int argc, char **argv)
{
	FILE *deny;
	FILE *approve;
	FILE *member;
	int motd;
	char *adr;
	char *adr2=NULL;
	char *temp;
	char *addr;
	char *subject;
	char *s;
	char *aof;
	char *fromcur=NULL;
	char buf[BUFSIZE];
	char **members;
	int fc;
	int fds[2];
	int len=0;
	int numlines=0;
	int pass=1;
	int x=0;
	int newpid, numread=0;
	if (argc==2)
	{
	temp=(char *)malloc(BUFSIZE);
	sprintf(temp, "%s%s.members", PATH,  argv[1]);
	if((member=fopen(temp, "r"))==NULL)
	{
		if (errno == 2)
			ehandle(1, "Members file not found\n");
		else if (errno == 13)
			ehandle(1, "Permission to open members file denied\n");
		else
		{
			fprintf(stderr, "Error: Unknown error number %d\n", errno);
			exit(1);
		}
	}
	free(temp);
	while(*(adr=getline(stdin)))
	{
		if(!strncmp(adr, "Subject: ", 9))
		{
			adr2=adr;
		}
		if (!strncmp(adr, "From ", 5))
		{
			addr=(char *)malloc(strlen(adr) + 1);
			strcpy(addr, adr);
			addr = addr + 5;
			while(*addr && isspace(*addr)) addr++;
			s = addr + 1;
			while(*s && !isspace(*s)) s++;
			*s = '\0';
		}
		if (!strncmp(adr, "From: ", 6))
			fromcur=adr;
	}
	pass=0;
	temp=(char *)malloc(BUFSIZE);
	while((fscanf(member, "%s", temp))!=EOF)
	{
		if(strstr(temp, addr)!=NULL)
		{
			pass=1;
		}
	}
	if (pass==0)
		exit(0);
	fclose(member);
	free(temp);
	addr=addr - 2;
	*addr = '-';
	addr[1] = 'f';
	temp=(char *)malloc(BUFSIZE);
	sprintf(temp, "%s%s.members", PATH,  argv[1]);
	if((member=fopen(temp, "r"))==NULL)
	{
		if (errno == 2)
			ehandle(1, "Members file not found\n");
		else if (errno == 13)
			ehandle(1, "Permission to open members file denied\n");
		else
		{
			fprintf(stderr, "Error: Unknown error number %d\n", errno);
			exit(1);
		}
	}
	while((s = getline(member))) if(*s) numlines++;
	rewind(member);
	members=(char **)malloc(numlines * sizeof(char *));
	*members="sendmail";
	members[1]=addr;
	while(len != numlines)
	{
		members[len + 2] = getline(member);
		len++;
	}
	members[len + 2] = NULL;
	if (len==1 && members[2]==NULL)
		ehandle(1, "Members file is empty\n");
	if(pipe(fds)==-1)
		ehandle(1, "pipe\n");
		
	fc = fcntl(fds[1], F_GETFL, 0);
	fcntl(fds[1], F_SETFL, fc & ~O_NONBLOCK);
	newpid = fork();
	if (newpid)
	{
		if (fromcur)
		{
			x=strlen(fromcur);
			fromcur[x]='\n';
			write(fds[1], fromcur, x + 1);
		}
		if (adr2)
		{
			x=strlen(adr2);
			adr2[x]='\n';
			write(fds[1], adr2, x + 1);
		}
		write(fds[1], "\n", 1);
#ifndef QUIET
sprintf(temp, ">>> \"%s\" mailing list\n\n---\n\n", argv[1]);
write(fds[1], temp, strlen(temp));
#endif
		while((numread = fread(buf, 1, BUFSIZE, stdin))) 
		{
			write(fds[1], buf, numread);
		}
		close(fds[1]);
	}
	else
	{
		close(0);
		dup2(*fds, 0);
		if(execv(SENDMAIL_PATH, members)==-1)
			ehandle(1, "Unable to execute sendmail\n");
	}
	
}
else
{
	while(*(adr=getline(stdin)))
        {
                if(!strncmp(adr, "Subject: ", 9))
                {
                        adr2=adr;
                }

        	if (!strncmp(adr, "From ", 5))
        	{                  
                addr=(char *)malloc(strlen(adr) + 1);
                strcpy(addr, adr);
                addr = addr + 5;
                while(*addr && isspace(*addr)) addr++;
                s = addr + 1;
                while(*s && !isspace(*s)) s++;
                *s = '\0'; 
        	}
        }
	adr2=strchr(adr2, ' ');
	adr2=adr2 + 1;
	if (!strncasecmp(adr2, "subscribe ", 10))
	{
		adr2=adr2 + 10;
        temp=(char *)malloc(BUFSIZE);
        sprintf(temp, "%s%s.deny", PATH, adr2);
        deny=fopen(temp, "r");
        sprintf(temp, "%s%s.approve", PATH, adr2);
        approve=fopen(temp, "r");
        sprintf(temp, "%s%s.members", PATH, adr2);
        if((member=fopen(temp, "r+"))==NULL)
        {
		printf("%s\n", errno);
        }
        free(temp);
        temp=(char *)malloc(BUFSIZE);
	while(fscanf(member, "%s", temp)!=EOF)
		if(!strcasecmp(addr, temp))
			exit(0);
        pass=1;
	free(temp);
	if(deny)
	{
        	while(((aof=getline(deny))!=NULL) && pass==1)
        	{
                	if(((strstr(aof, addr))!=NULL) || (!strncmp(aof, "*\0", 2)) || (!strncmp(aof, "ALL\0", 4)))
                	{
                        	pass=0;
                        	break;
                        }
                }
        }
	if(approve)
	{
        	while((aof=getline(approve))!=NULL && pass==0)
        	{
                	if((strstr(aof, addr))!=NULL)
                	{
                        	pass=1;
                	}
                }
        }
        
        if (pass==0)
                exit(0);
                
        	fprintf(member, "%s\n", addr);
        	temp=(char *)malloc(BUFSIZE);
        	sprintf(temp, "%s%s.motd", PATH, adr2);
        	if((motd=open(temp, O_RDONLY))!=-1)
        	{
        	
        		if(pipe(fds)==-1)
        			ehandle(1, "pipe\n");
        				
			fc = fcntl(fds[1], F_GETFL, 0);
			fcntl(fds[1], F_SETFL, fc & ~O_NONBLOCK);
			newpid = fork();
			if (newpid)
			{
				free(temp);
				temp=(char *)malloc(BUFSIZE);
				sprintf(temp, "Subject: Welcome to the \"%s\" list\n", adr2);
				write(fds[1], temp, strlen(temp));
				free(temp);
				while((numread = read(motd, buf, BUFSIZE))) write(fds[1], buf, numread);
				close(fds[1]);
			}
			else
			{
				temp="-rnlist";
				members=(char **)malloc(2);
				*members="sendmail";
				members[1]=temp;
				members[2]=addr;
				members[3]=NULL;
				close(0);
				dup2(*fds, 0);
				if(execv(SENDMAIL_PATH, members)==-1)
					ehandle(1, "Unable to execute sendmail\n");
				free(members);
			}
		}
	exit(0);
	}
	else if(!strncasecmp(adr2, "unsubscribe ", 12))
	{
		adr2=adr2 + 12;
		temp=(char *)malloc(BUFSIZE);
		sprintf(temp, "%s%s.members", PATH, adr2);
		if((member=fopen(temp, "r"))==NULL)
		{
			if (errno == 2)
				ehandle(1, "Members file not found\n");
			else if (errno == 13)
				ehandle(1, "Permission to open members file denied\n");
			else
			{
				fprintf(stderr, "Error: Unknown error number %d\n", errno);
			}
		}
		free(temp);
        	while((s = getline(member))) if(*s) numlines++;
        	rewind(member);
        	members=(char **)malloc(numlines * sizeof(char *));
		len=0;
		while((temp=getline(member))!=NULL)
		{
			if(strstr(temp, addr)==NULL)
			{
				members[len]=temp;
				len++;
			}
		}
		if (len==0)
			exit(0);
		temp=(char *)malloc(BUFSIZE);
		fclose(member);
		sprintf(temp, "%s%s.members", PATH, adr2);
		if((member=fopen(temp, "w+"))==NULL)
		{
			if(errno == 2)
				ehandle(1, "Members file not found\n");
			else if (errno == 13)
				ehandle(1, "Permission to open members file denied\n");
			else
			{
				fprintf(stderr, "Unknown error number %d\n", errno);
				exit(1);
			}
		}
		x=0;
		while(x != len)
		{
			if (members[x]!=NULL)
				fprintf(member, "%s\n", members[x]);
			x++;
		}
		exit(0);
	}
}
}
