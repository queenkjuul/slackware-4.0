#!/usr/bin/perl -w
# minordomo.pl - This is minordomo, a minimalistic mailing list manager
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version. And also
# please DO NOT REMOVE my name, and give me a CREDIT when you use
# whole or a part of this program in an other program.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
use Socket;

$config = "/etc/minordomo.conf";
$version = "minordomo 0.6.1";

$list = '';
$smtp_server = 'localhost';
$directory = '/var/lib/minordomo';
$admin = 'root@localhost';
$domain = 'localdomain.com';
$archive = '';
$list_cmd = '';
$open_lists = '';
$subject_pre = '';
$url = '';

do_conf($config);

$list = $ARGV[0];

while (<STDIN>){
 $message .= $_;
}
($header, $mess) = split(/\n\n/, $message, 2);
@header = split (/\n/, $header);
$from = '';
foreach (@header){ if (($_ =~ /^from:/i) && ($from eq '')){ $from= $_; } }
$from =~ s/^from: //ig;
if ($from =~ /<.*>/) { $from =~ s/.*<(.*\@.*\..*)>/$1/; }
elsif ($from =~ /\(.*\)/) { $from =~ s/(.*\@.*\..*).*/$1/g; }

# For a message to a list
unless ($list eq ''){
 mkdir "$directory/$list", 0755;
 do_conf("$directory/$list/config");
 if ($subject_pre ne ''){
  foreach(@header) {
   if ($_ =~ /^subject:/i){
    $subject_pre =~ s/[\r|\n]//g;
    $subject_pre =~ s/([\[|\]])/\\$1/g;
    unless ($_ =~ /$subject_pre/){
     $subject_pre =~ s/\\([\[|\]])/$1/g;
     $_ =~ s/(: )/$1$subject_pre /;
    }
   }
  }
  $header = join("\r\n", @header);
 }
 $header .= "\r\nX-Mailing-List: $list\@$domain\r\n";
 $header .= "X-Mailing-List-Server: $version\r\n";
 $header .= "X-Loop: $list\@$domain\r\n";
 $header .= "Precedence: bulk\r\n";
 $header .= "Reply-To: $list\@$domain\r\n";
 if (($archive =~ /$list/i) || ($archive =~ /\*/) && !($noarchive)){
  ($messno, $archfile) = get_archive($list);
  if ($url ne ''){ $url =~ s/[\r|\n]//g; $header .= "X-Archive-URL: $url\r\n"; }
  $header .= "X-Archive-ID: $messno\r\n";
 }
 $header .= "\r\n";

 open LIST, "$directory/$list/list";
 while (<LIST>){ $listmembers .= $_; }
 close LIST;

 $listmembers =~ s/\r//g;
 @listmembers = split (/\n/, $listmembers);
 foreach $member (@listmembers){
  if ($member eq $from) {
   $send_ok = 'yes';
  }
 }

 if (($open_lists =~ /$list/) || ($open_lists =~ /\*/)) {
  $send_ok = 'yes';
 }

 $footfile = $directory . "/" . $list . "/footer";
 open FOOT, "$footfile";
 while (<FOOT>){
  $footer .= $_;
 }
 close FOOT;

 $footer =~ s/\\a/$admin/ig;
 $footer =~ s/\\d/$domain/ig;
 $footer =~ s/\\l/$list/ig;

 $to = '';
 if ($send_ok eq 'yes'){
  foreach (@listmembers){
   if ($to eq ''){ $to = $_; }
   else { $to .= " $_"; }
  }
  $message = "$header$mess\r\n$footer";
 } else {
  $noarchive = 1;
  $to = $from;
  $message = "From: minordomo\@$domain\r\nTo: $from\r\nSubject: Not allowed\r\n\r\nThis e-mail address is not subscribed to the mailing list $list\@$domain. You may not send to this list.";
 }

 send_mesg($to, $message);

 if (($archive =~ /$list/i) || ($archive =~ /\*/) && !($noarchive)){
  ($messno, $archfile) = get_archive($list);
  open ARCHIVE, ">$archfile";
  print ARCHIVE $message;
  close ARCHIVE;
 }

# For a message to minordomo
} else {
 @header = split(/\n/, $header);
 $subject = '';
 foreach (@header){
  if (($_ =~ /^subject/i) && ($subject eq '')){ $subject = $_; }
 }
 ($junk, $command) = split (/: /, $subject, 2);
 $list = '';
 ($cmd, $list) = split (/ /, $command, 2);
 $mess = "From: minordomo\@$domain\r\nTo: $from\r\nSubject: Re: $command\r\n\r\n";
 if ($cmd eq 'subscribe') {
  if ((-d "$directory/$list") && ($list ne '')) {
   if (-s "$directory/$list/list") { 
    open LISTFILE, ">>$directory/$list/list";
   } else {
    open LISTFILE, ">$directory/$list/list";
   } 
   print LISTFILE "$from\n";
   close LISTFILE;
   open RET, "$directory/$list/info";
   $mess .= "You have been subscribed to $list\@$domain.\r\n\r\n";
   while (<RET>) { $mess .= $_; }
   close RET;
  } else {
   $mess .= "There is no such list $list here. Send a message to minordomo\@$domain with a subject of 'info' (no quotes) for a list of available lists.";
  }
 } elsif ($cmd eq 'unsubscribe') {
  if ((-d "$directory/$list") && ($list ne '')) {
   open LISTFILE, "$directory/$list/list";
   while (<LISTFILE>) { $listfile .= $_; }
   close LISTFILE;
   $listfile =~ s/$from\n//g;
   $listfile =~ s/$from//g;
   $listfile =~ s/\r//g;
   open LISTFILE, ">$directory/$list/list";
   print LISTFILE $listfile;
   close LISTFILE;
   $mess .= "You have been unsubscribed from $list\@$domain.";
  } else {
   $mess .= "There is no such list here. You have not been unsubscribed.";
  }
 } elsif ($cmd eq 'info') {
  if ((-d "$directory/$list") && ($list ne '')) {
   open INFO, "$directory/$list/info";
   while (<INFO>) { $mess .= $_ };
   close INFO;
  } elsif ($list ne '') {
   $mess .= "There is no such list $list here. Send a message to minordomo\@$domain with a subject of 'info' (no quotes) for a list of available lists.";
  } else {
   $mess .= "This is a minordomo run list server. Commands are:\r\n\r\n";
   $mess .= "subscribe <list>:       adds your e-mail address to a list\r\n";
   $mess .= "unsubscribe <list>:     removes your address from a list\r\n";
   $mess .= "info [<list>]:          gives you information on a list\r\n";
   $mess .= "                        if <list> is omitted, gives this message";
   $mess .= "\r\n\r\nAvailable lists are:\r\n";
   open INFO, "$directory/lists";
   while (<INFO>) { $mess .= $_; }
   close INFO;
  }
 } elsif ($cmd eq 'list') {
  if ((-e "$directory/$list/list")&&(($list_cmd=~/$list/)||($list_cmd=~/\*/))){
   open LIST, "$directory/$list/list";
   while (<LIST>) { $mess .= $_ };
   close LIST;
  } else { 
   $mess .= "There is no such list $list here, or you are not allowed to view ";
   $mess .= "this list's subscriber list. Sorry.";
  }
 } else {
  $mess .= "Unrecongnized command $cmd.";
 }
 send_mesg($from, $mess);
} 

###############################################################################
# Send a message
# syntax - send_mesg($to, $message);
sub send_mesg{
 $proto = getprotobyname('tcp');
 socket(SOCK, AF_INET, SOCK_STREAM, $proto);
 $iaddr = gethostbyname($smtp_server);
 $port = getservbyname('smtp', 'tcp');
 $sin = sockaddr_in($port, $iaddr);
 connect(SOCK, $sin);

 $to = shift;
 @tos = split(/ /, $to);
 $message = shift;

 send SOCK, "HELO $domain\r\n", 0;
 recv SOCK, $err, 512, 0;
 send SOCK, "MAIL FROM: $admin\r\n", 0;
 recv SOCK, $err, 512, 0;
 foreach $to (@tos){
  send SOCK, "RCPT TO: $to\r\n", 0;
  recv SOCK, $err, 512, 0;
 }
 send SOCK, "DATA\r\n", 0;
 recv SOCK, $err, 512, 0;
 send SOCK, "$message\r\n.\r\n", 0;
 recv SOCK, $err, 512, 0;
 send SOCK, "QUIT\r\n", 0;
 recv SOCK, $err, 512, 0;
 close SOCK;
} 

###########################################################################
# Gets the archive filename and message number
# Syntax - get_archive($list);
sub get_archive{
 $list = shift;

 @date = localtime;
 $year = 1900 + $date[5];
 $month = 1 + $date[4];
 $day = $date[3];

 mkdir "$directory/$list/archive", 0755;
 mkdir "$directory/$list/archive/$year", 0755;
 mkdir "$directory/$list/archive/$year/$month", 0755;
 mkdir "$directory/$list/archive/$year/$month/$day", 0755;
 $messno = "0";
 $break = 'no';
 while ($break ne 'yes'){
  if (-e "$directory/$list/archive/$year/$month/$day/$messno"){
   $messno++;
  } else {
   $break = 'yes';
  }
 }
 $file = "$directory/$list/archive/$year/$month/$day/$messno";
 return ($messno, $file);
}

###########################################################################
# Reads a configuration file
# Syntax - do_conf($config_filename);
sub do_conf{
 $file = shift;

 open CONF, $file;
 while (<CONF>){
  if($_ =~ /^#/){
  } elsif ($_ =~ /^smtp_server/i){
   ($directive, $smtp_server) = split(/=/, $_);
   chomp $smtp_server;
  } elsif ($_ =~ /^directory/i){
   ($directive, $directory) = split(/=/, $_);
   chomp $directory;
  } elsif ($_ =~ /^admin/i){
   ($directive, $admin) = split(/=/, $_);
   chomp $admin;
  } elsif ($_ =~ /^domain/i){
   ($directive, $domain) = split(/=/, $_);
   chomp $domain;
  } elsif ($_ =~ /^archive/i){
   ($directive, $archive) = split(/=/, $_);
  } elsif ($_ =~ /^list_cmd/i){
   ($directive, $list_cmd) = split(/=/, $_);
  } elsif ($_ =~ /^open_lists/i){
   ($directive, $open_lists) = split(/=/, $_);
  } elsif ($_ =~ /^subject_prefix/i){
   ($directive, $subject_pre) = split(/=/, $_);
  } elsif ($_ =~ /^url/i){
   ($directive, $url) = split(/=/, $_);
  }
 }
 close CONF;
}
