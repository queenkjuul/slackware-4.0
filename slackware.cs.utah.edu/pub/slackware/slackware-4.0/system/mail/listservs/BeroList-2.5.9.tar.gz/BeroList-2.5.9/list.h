/*  BeroList Mailing List - Configuration file                    
    (c) 1996-98 by Bernhard Rosenkraenzer, bero@linux.net.eu.org
    $Id: list.h,v 1.1.1.1 1998/08/21 18:11:02 root Exp $ */

/* PASSWORD: Password to be used for WWW based list creation and as
   default password for WWW based list administration.
   If you do not define a PASSWORD, everyone can create new lists. */
#define PASSWORD "BeroList"

/* SMTP server used to send messages   */
/* localhost should work in most cases */
#define SMTP_SERVER "localhost"

/* NNTP server settings used to send copies of messages to newsgroups */
/* Check README for details.                                          */
#define HAS_NNTP
#ifdef HAS_NNTP
	#define DEFAULT_NNTP_SERVER "localhost"
	#define DEFAULT_NNTP_DISTRIBUTION "local"
#endif

/* Maximum number of members for a list */
#define MAX_MEMBERS 1000

/* Uncomment the following lines if you do not want sender and list addresses
   in your message */
/* #define NO_SENDER_ADDRESS */
/* #define NO_LIST_ADDRESS   */   

/* If USE_SENDMAIL is defined, BeroList will use sendmail to send out
   messages (the 1.x way).                                            */
/* #define USE_SENDMAIL                                               */

/* Path to sendmail - required if USE_SENDMAIL is defined. */
#ifdef USE_SENDMAIL
	#define SENDMAIL "/usr/bin/sendmail"
	/* define TRUSTED if 'bin' may run sendmail -f - RECOMMENDED
	Not necessary if USE_SENDMAIL is undefined. */
	/* #define TRUSTED */
#endif

/* VERSION will be used in error messages. As it is used to generate
   Message IDs, it may not contain whitespaces. */
#define VERSION "BeroList-2.5.9"

/* That's it. Go on and run configure and make. */
