/* $Id: cgitool.h,v 1.1.1.1 1998/08/21 18:11:02 root Exp $ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *cgi_scan(char *setting);
unsigned int cgi_count();
void html_head(char *title);
char *to_cgi(char *t);
