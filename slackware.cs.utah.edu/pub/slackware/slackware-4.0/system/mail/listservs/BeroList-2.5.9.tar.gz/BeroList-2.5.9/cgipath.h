/* relative URL to BeroList CGI script, used in HTML-links */
/* $Id: cgipath.h,v 1.1.1.1 1998/08/21 18:11:02 root Exp $ */

#define MESSAGES_CGI "/cgi-bin/messages"
#define DISPLAY_CGI "/cgi-bin/display"
#define EDIT_CGI "/cgi-bin/edit"
#define LISTADM_CGI "/cgi-bin/listadm"
