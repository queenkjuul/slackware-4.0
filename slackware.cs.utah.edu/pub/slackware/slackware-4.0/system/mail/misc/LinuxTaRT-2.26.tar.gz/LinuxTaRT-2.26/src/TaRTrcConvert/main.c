#include <stdio.h>
#include "../tartutil.h"
#include "../stringutil.h"

int main (void)
{
    char custom1[256];
    char custom2[256];
    char sigfile[256];
    char tagfile[256];
    char customfile[256];
    char datefile[256];
    FILE *aFile;

    if (ReadINIFile (custom1, custom2, customfile, sigfile, tagfile, datefile) == 1) {
	fprintf (stderr, "error reading .TaRTrc\n");
	exit (1);
    }
    StripCR (custom1);
    StripCR (custom2);
    printf ("\nI read these values from your .TaRTrc:\n\n");
    printf ("Custom Text 1:\t\t%s\n", custom1);
    printf ("Custom Text 2:\t\t%s\n", custom2);
    printf ("Signature File:\t\t%s\n", sigfile);
    printf ("Tagline Database:\t%s\n", tagfile);
    printf ("Custom Layout File:\t%s\n", customfile);
    printf ("Special Dates File:\t%s\n\n", datefile);
    printf ("Writing new file to " "./TaRTrc-new" "...\n\n");

    if ((aFile = fopen ("TaRTrc-new", "w")) == NULL) {
	printf ("Could not create new file\n");
	exit (1);
    }
    fprintf (aFile, "CustomText1=%s\n", custom1);
    fprintf (aFile, "CustomText2=%s\n", custom2);
    fprintf (aFile, "SignatureFile=%s\n", sigfile);
    fprintf (aFile, "TagLineDatabase=%s\n", tagfile);
    fprintf (aFile, "CustomFile=%s\n", customfile);
    fprintf (aFile, "SpecialDates=%s\n", datefile);

    if (fclose (aFile)) {
	printf ("error closing file\n");
	exit (1);
    }
    return 0;
}
