#include "unxconio.h"

/* NB See history entry for v0.06 BUILD 1 about getch before you use it
   yourself */

/*
**  UNXGETCH.C - Non-blocking console input function for Unix/Posix.
**
**  public domain by Bob Stout using Steve Poole's term_option().
*/


int getch()
{
      int istat, key;
      char buf[2];

      if (0 > term_option(1))
            return EOF;
      if (0 > term_option(2))
            return EOF;
      istat = read(STDIN_FILENO,&buf,1);
      if (istat < 0)
            key = EOF;
      else  key = (int)buf[0];
      term_option(0);
      return key;
}

/* end of unxgetch.c */

/*
**
**  This was written under AIX 3.2.5.1
**  (Cripes just a few more numbers please.)
**
**  Terminal functions
**
**  Option 0 - Turns the ECHO on.
**         1 - Turns the ECHO off.
**         2 - Waits forever for keyboard activity.
**
**  Public Domain *IX terminal functions.
**  Slung together by Steve Poole for RBS's SNIPPETS.
**
*/

#define _POSIX_SOURCE 1

#include <termios.h>
#include <sys/types.h>

int term_option(option)
int  option;
{
  struct termios attributes;

    switch(option)
    {
/*
**  Turn echo on
*/
      case 0:
             if(tcgetattr(STDIN_FILENO,&attributes) != 0)
               return (-1);
             attributes.c_lflag |= ECHO;
             if(tcsetattr(STDIN_FILENO,TCSANOW,&attributes) != 0)
               return (-1);
	     return 0;
             break;
/*
**  Turn echo off
*/
      case 1:
             if(tcgetattr(STDIN_FILENO,&attributes) != 0)
               return (-1);
             attributes.c_lflag &= ~(ECHO);
             if(tcsetattr(STDIN_FILENO,TCSAFLUSH,&attributes) != 0)
               return (-1);
             return 0;
	     break;
/*
**  Wait forever for the keyboard to be touched. (AHHHHHH!!!!!!!)
*/
      case 2:
             if(tcgetattr(STDIN_FILENO,&attributes) != 0)
               return (-1);
             attributes.c_lflag    &= ~(ICANON);
             attributes.c_cc[VMIN]  = 1;
             attributes.c_cc[VTIME] = 1;
             if(tcsetattr(STDIN_FILENO,TCSANOW,&attributes) != 0)
               return (-1);
	     return 0;
             break;
/*
**  Don't be a bozo, call it with something
*/
      default:
              printf("Error in terminal options routine, "
                    "BAD OPTION %d\n",option);
              return(-1);
              break;
    }
}

