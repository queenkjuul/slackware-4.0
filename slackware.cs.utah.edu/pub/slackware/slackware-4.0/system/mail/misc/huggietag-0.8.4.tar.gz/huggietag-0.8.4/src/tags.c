/*
HuggieTag 0.8
Copyright (C) Project Purple 1999
Main source file.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

All comments to: Simon Huggins <huggie@dial.pipex.com>
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "common.h"
#ifndef __MSDOS__
#include <termios.h>
#include <unistd.h>
#include <signal.h>
struct termios oldattr;
#endif

struct options opt;
struct from frm;
struct clever_sig pyrex_clerk;

void closeprogram() {
int i;
struct sigspaces *cur,*next;
if (opt.idxfn!=NULL)   { free(opt.idxfn); }
if (opt.tmpfile[0]!=0) remove(opt.tmpfile);
if (opt.pauseonerror) {
	puts("Press any key to continue...");
	getch();
	puts(" "); /* go onto next line after whatever they hit */
	}
i=0;
while (*opt.tears[i]!=0) { free(opt.tears[i]); i++; }
free(opt.tears[i]);
i=0;
while (*opt.sigs[i]!=0) { free(opt.sigs[i]); i++; }
free(opt.sigs[i]);
i=0;
while (*opt.headers[i]!=0) { free(opt.headers[i]); i++; }
free(opt.headers[i]);
if (pyrex_clerk.firstspace!=NULL) {
	cur=pyrex_clerk.firstspace;
	next=cur->next;
	while (next!=NULL) { free(cur); cur=next; next=cur->next; }
	free(cur);
	}
#ifndef __MSDOS__
tcsetattr(STDIN_FILENO,TCSAFLUSH,&oldattr);
#endif
/* files closed by exit() */
}

#ifndef __MSDOS__
void handler(int sig) {
opt.pauseonerror=0;
exit(5);
}
#endif

int main(int argc, char **argv) {
time_t t;

#ifndef __MSDOS__
struct sigaction sa;
/* HT's getch seems to stop getpass from working properly (this is A Bad Thing
   when you're trying to su (leaves password visible except first char)).
   This is a proposed fix by Jonathan McDowell. (don't blame me :)) */
tcgetattr(STDIN_FILENO,&oldattr);
sa.sa_handler=handler;
if (sigaction(SIGINT, &sa, NULL)) {
	puts("Error: Could not trap SIGINT!");
	exit(10);
	}
#endif
atexit(&closeprogram);

printf("HuggieTag %s by Simon Huggins (huggie@dial.pipex.com) Build %s\n", VERSION, BUILD);
puts("Written by Simon Huggins and Jonathan McDowell");
puts("Copyright (C) 1999 Project Purple. Released under the GPL. (See Documentation)\n");

slongrand((unsigned) time(&t)); /*seed long rand function*/
srand((unsigned) time(&t)); /* seed int rand function */

clear_options(&opt);
clear_from(&frm);
clear_sigstuff(&pyrex_clerk);
parse_args(&opt, argc, argv);

parse_msg_headers(&opt, &frm);
add_msg_cust_headers(&opt,&frm);
copy_body(&opt);
check_for_tags(&opt);
copy_to_tear(&opt);
/* If we've survived so far we add a tag */
add_sig(&opt, &pyrex_clerk);
add_tag(&opt, &frm, &pyrex_clerk);
add_tear(&opt);
copy_rest(&opt);
fclose(opt.msg);
fclose(opt.tmp);
move_file(opt.tmpfile, opt.msgfile); /* tmp -> msg */

opt.pauseonerror=0; /* Stop it pausing if all goes "to plan" */
exit(0);
}
