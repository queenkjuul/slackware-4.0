#include <stdio.h>
#include <stdlib.h>
#include "common.h"

void move_file(char *from, char *to)
{
FILE *in,*out;
char *buf;
int n,bufsize,error;

if ((in = fopen(from,"rt"))==NULL)
	{
	printf("\nCannot open file for input.\nTrying to open: \"%s\"\n",from);
	exit(3);
	}
if ((out = fopen(to,"wt"))==NULL)
	{
	printf("\nCannot open file for output.\nTrying to open: \"%s\"\n",to);
	exit(3);
	}

error=TRUE;

/* following code loosely based upon wb_fcopy from snippets */

for (bufsize=0x4000; bufsize>=128; bufsize=bufsize >> 1)
	{
	buf=malloc(bufsize);
	if (buf)
		{
		while (1)
			{
			n=fread(buf, 1, bufsize, in);
			if (n<0) break;
			if (n==0)
				{
				error=FALSE;
				break;
				}
			if (n!= fwrite(buf, 1, n, out))
				break;
			}
		}
	free(buf);
	break;
	}
if (error)
	{
	printf("\nError copying %s to %s\n", from, to);
	exit(6);
	}

if (remove(from)!=0)
	{
	printf("\nUnable to remove temporary file %s.\n", from);
	exit(6);
	}

}
