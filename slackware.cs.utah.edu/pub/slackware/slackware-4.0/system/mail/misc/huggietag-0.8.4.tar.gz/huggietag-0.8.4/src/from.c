#include "common.h"
#include <ctype.h>
#include <string.h>

int is_header(char *buf, struct from *frm);
void split_from(char *buf, struct from *frm);

void parse_msg_headers(struct options *opt, struct from *frm) {
int lines;
char buf[1024];

open_msg(opt);

lines=0;
while ((lines<100)&&(!feof(opt->msg))) {
	buf[0]=0; /* avoid fgets twice at end bug */
	fgets(buf, 1023, opt->msg);
	buf[1023]=0;
	lines++;
	if (is_header(buf, frm)) break;
	}
if (frm->full[0]==0) {
	puts("Could not extract from name from headers. Macro expansion disabled!");
	}
}

int is_header(char *buf, struct from *frm) {
int curpos,namepos;
char *next, *jam;

/* From: from name <email@example.com> */
if (strncmp(buf, "To:", 3)==0||
    strncmp(buf, "TO:", 3)==0) {
	curpos=3;
	while (buf[curpos]&&isspace(buf[curpos++])) ;
	namepos=curpos-1;
	while (buf[curpos]&&!isspace(buf[curpos])&&buf[curpos]!='@') curpos++;
	if (buf[curpos-1]=='\n') return 0;
	if (buf[curpos]=='@') return 0;	/* looks like an email address
					   without a name */
	while (buf[curpos]&&buf[curpos]!='<') curpos++;
	if (buf[curpos]=='<') {
		curpos--;
		buf[curpos]=0;
		}
	while (isspace(buf[--curpos])) buf[curpos]=0;
	split_from(buf+namepos,frm);
	return 1;
	}
/* Pine's "On Tue, 26 Jan 1999, Simon Huggins wrote:" */
if (strncmp(buf, "On ", 3)==0) {	
	next=strstr(buf+3, ", ");
	if (next!=NULL) {
		while (strstr(next+2, ", ")!=NULL) next=strstr(next+2, ", ");
		jam=rindex(buf, ' ');
		if (jam!=NULL&&strlen(jam)==8&&
		    strncmp(jam, " wrote:\n", 8)==0) {
			*jam=0;
			split_from(next+2, frm);
			return 1;
			}
		}
	}

return 0;
}

void split_from(char *buf, struct from *frm) {
char *first_space, *last_space;
int curpos;

if (strlen(buf)>79) {
	puts("Name too long. Cannot parse for from names. Macro expansion disabled");
	return;
	}
first_space=index(buf, ' ');
last_space=rindex(buf, ' ');
if (first_space==NULL) {
	strcpy(frm->full,  buf);
	strcpy(frm->first, buf);
	strcpy(frm->last,  buf);
} else {
	strcpy(frm->full,  buf);
	strcpy(frm->first, buf);
	while ((first_space=rindex(frm->first, ' '))!=NULL) *first_space=0;
	/* take off any spaces after text in frm->first */
	curpos=strlen(frm->first)-1;
	while (isspace(frm->first[--curpos])) frm->first[curpos]=0;
	strcpy(frm->last,  last_space+1);
	}
#ifdef DEBUG
printf("'%s' '%s' '%s'\n", frm->full, frm->first, frm->last);
#endif
}
