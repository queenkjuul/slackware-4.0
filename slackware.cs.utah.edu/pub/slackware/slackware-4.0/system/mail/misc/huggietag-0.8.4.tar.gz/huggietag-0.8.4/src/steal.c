#include "common.h"
#include <string.h>

void steal_tags(struct options *opt) {
char tstr[1000], *steal;
int added;

open_msg(opt);
open_out_tag(opt);

fseek(opt->msg, 0L, 2);
/* Actually I wonder if this is correct behaviour?
   messages over 10k are likely to be file attachments with msgs at the start
   Hmmm.
   OK let's change this to only go *up* to 10240 bytes
*/
fseek(opt->msg, 0L, 0);
tstr[0]=0;
added=0;
while (ftell(opt->msg)<10240L&&!feof(opt->msg))
	{
	tstr[0]=0;
	fgets(tstr, 999, opt->msg);
	tstr[999]=0;
	if (strncmp(tstr, "...", 3)==0)
		{
		printf("\n%s\nSteal this tag? (y,n) ",tstr);
		if (yesno())
			{
			tstr[strlen(tstr)-1]=0; /* remove \n */
			steal=tstr+3;
			while (*steal==' '||*steal=='.') steal++;
			if (fseek(opt->tag, -1L, 2)==-1) {
				fputs(steal,opt->tag);
			} else {
				if (fgetc(opt->tag)=='\n') fprintf(opt->tag, "%s", steal);
				else fprintf(opt->tag,"\n%s",steal);
				}
			added++;
			}
		}
	}
printf("\nStolen %i tags!!\nDon't forget to update the index file with --build\n",added);
fclose(opt->tag);
fclose(opt->msg);
opt->pauseonerror=0;
exit(0);
}
