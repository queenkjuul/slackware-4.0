#include <stdio.h>

int main(void) {
FILE *in;
char buf[1000];

in=fopen("/usr/local/share/huggietag/taglines.tag","rt");
fseek(in, 924621999L, 0);
fgets(buf, 999, in);
buf[999]=0;
puts(buf);
fclose(in);
}
