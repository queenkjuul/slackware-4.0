#include "common.h"
#include <stdlib.h>
#include <string.h>

void add_msg_cust_headers(struct options *opt, struct from *frm) {
int i=0;
char *newhdr, *hdr;

copy_headers(opt);

while (*opt->headers[i]!=0) i++;
if (i>0 && frm->first[0]!=0) {
	if (i>1) i=(rand() % i);
	else i--;
	if ((newhdr=malloc(strlen(opt->headers[i])+1))==NULL) {
		puts("Could not allocate memory for newhdr!");
		exit(2);
		}
	strcpy(newhdr, opt->headers[i]);
	hdr=reformat_head(newhdr, opt, frm);
	fputs(hdr,opt->tmp);
	free(hdr);
	free(newhdr);
	}

}
