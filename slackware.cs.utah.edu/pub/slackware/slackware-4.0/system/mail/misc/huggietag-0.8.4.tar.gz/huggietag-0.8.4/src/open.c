#include "common.h"
#include <stdlib.h>
#include <string.h>

void gen_idx(struct options *opt) {
int p;
char *dot;

p=strlen(opt->tagfile);
if ((opt->idxfn=(char *)malloc(p+5))==NULL) {
	puts("Could not allocate memory for idxfn!\nNo taglines stolen!!");
	exit(2);
	}
strcpy(opt->idxfn, opt->tagfile);
dot=(char *)rindex(opt->idxfn, '.');
if (!dot) {
	strcpy((char *)opt->idxfn+p, ".idx");
} else {
	strcpy(dot, ".idx");
	}		
}

void open_out_idx(struct options *opt) {
if (opt->idxfn==NULL) gen_idx(opt);
if (opt->idx==NULL) opt->idx=fopen(opt->idxfn, "wt");
if (opt->idx==NULL) {
	printf("Cannot open idx file!\nTrying to open \"%s\"\n",opt->idxfn);
	exit(3);
	}
}

void open_idx(struct options *opt) {
if (opt->idxfn==NULL) gen_idx(opt);
if (opt->idx==NULL) opt->idx=fopen(opt->idxfn, "rt");
if (opt->idx==NULL) {
	printf("Cannot open idx file!\nTrying to open \"%s\"\n",opt->idxfn);
	exit(3);
	}
}

void open_msg(struct options *opt) {
if (opt->msg==NULL) opt->msg=fopen(opt->msgfile, "rt");
if (opt->msg==NULL) {
	printf("Cannot open message file!\nTrying to open \"%s\"\n",opt->msgfile);
	exit(3);
	}
}

void open_tag(struct options *opt) {
if (opt->tag==NULL) opt->tag=fopen(opt->tagfile, "rt");
if (opt->tag==NULL) {
 	printf("Cannot open tagfile!\nTrying to open \"%s\"\n",opt->tagfile);
	exit(3);
	}
}

void open_out_tag(struct options *opt) {
if (opt->tag==NULL) opt->tag=fopen(opt->tagfile, "a+t");
if (opt->tag==NULL) {
 	printf("Cannot open tagfile!\nTrying to open \"%s\"\n",opt->tagfile);
	exit(3);
	}
}

void open_tmp(struct options *opt) {
if (opt->tmp==NULL) opt->tmp=fopen(opt->tmpfile, "wt");
if (opt->tmp==NULL) {
	printf("Cannot open temp file!\nTrying to open \"%s\"\n",opt->tmpfile);
	exit(3);
	}
}
