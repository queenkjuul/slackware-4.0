#include "common.h"
#include <stdlib.h>

void clear_options(struct options *opt) {
/* Comments are reminder to document default values :) */
opt->leader[0]=0;
opt->first[0]=0;
opt->tearline[0]=0;
opt->maxlinelen=76;	/* defaulting to 76 */
opt->newline=1;		/* defaulting to 1 */
opt->tagfound=0;
opt->tearlinetype=8;
opt->fillallspaces=0;
opt->pauseonerror=1; 	/* defaulting on. Be sure to document */
opt->msgfile[0]=0;
opt->msg=NULL;
opt->tagfile[0]=0;
opt->tag=NULL;
opt->tmpfile[0]=0;
opt->tmp=NULL;
opt->sigfile[0]=0;
opt->sig=NULL;
opt->idxfn=NULL;
opt->idx=NULL;

if ((opt->headers[0]=malloc(1))==NULL) {
	puts("Could not allocate memory for last header!");
	exit(2);
	}
*opt->headers[0]=0;
if ((opt->tears[0]=malloc(1))==NULL) {
	puts("Could not allocate memory for last tearline!");
	exit(2);
	}
*opt->tears[0]=0;
if ((opt->sigs[0]=malloc(1))==NULL) {
	puts("Could not allocate memory for last signature!");
	exit(2);
	}
*opt->sigs[0]=0;
}

void clear_from(struct from *frm) {
frm->full[0]=0;
frm->first[0]=0;
frm->last[0]=0;
}

void clear_sigstuff(struct clever_sig *pyrex_clerk) {
pyrex_clerk->tmpsig[0]=0;
pyrex_clerk->firstspace=NULL;
}
