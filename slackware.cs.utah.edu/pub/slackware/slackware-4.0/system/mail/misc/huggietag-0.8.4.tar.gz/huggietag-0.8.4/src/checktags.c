#include "common.h"
#include <string.h>

void check_for_tags(struct options *opt) {
long curpos;
char buf[1024];
int numtags=0;

curpos=ftell(opt->msg);

buf[0]=0;
while (!feof(opt->msg)) {
	buf[0]=0;
	fgets(buf,1023,opt->msg);
	buf[1023]=0;
	if (strncmp(buf, "...", 3)==0) numtags++;
	}

if (numtags>0) {
	printf("%d taglines found in message file already!\n",numtags);
	printf("Are you sure you want to add another tagline to \"%s\"? (y,n)",opt->msgfile);
	if (!yesno()) { puts("Aborted!"); opt->pauseonerror=0; exit(5); }
	}
	
fseek(opt->msg, curpos, 0);
}
