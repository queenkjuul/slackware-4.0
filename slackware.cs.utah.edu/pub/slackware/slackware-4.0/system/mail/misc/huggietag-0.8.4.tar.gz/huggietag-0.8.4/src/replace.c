#include "common.h"
#include <string.h>
#include <stdlib.h>

void do_replace(char *buf, const char *foo, const char *bar) {
/* replace foo with bar in buf */
/* buf needs to have strlen(bar)-strlen(foo) characters extra */

char *start,*end;
char *tmp;

if ((tmp = malloc(strlen(buf)+strlen(bar)-strlen(foo)+2)) == NULL) {
	puts("Error! Could not allocate memory for tmp in do_replace.");
	exit(2);
	}
strcpy(tmp,buf);
start=strstr(tmp,foo);
if (start==NULL) {
	free(tmp);
	return;
	}

strcpy(start, bar);
end=strstr(buf,foo);
strcpy(start+strlen(bar),end+strlen(foo));
strcpy(buf,tmp);
free(tmp);
}

char *replace_all(char *buf, struct from *frm, int cr) {
/* buf is a malloc'd area of memory */
char *tmp;
int len;
int count;

len=strlen(buf);
count=0;
tmp=buf;
while ((tmp=strstr(tmp, "@B"))) {
	count++;
	if (tmp[2]!=0) tmp=tmp+2;
	else break;
	}
len=len+count*strlen("\n");
count=0;
tmp=buf;
while ((tmp=strstr(tmp, "@N"))) {
	count++;
	if (tmp[2]!=0) tmp=tmp+2;
	else break;
	}
len=len+count*strlen(frm->full)-count*2;
count=0;
tmp=buf;
while ((tmp=strstr(tmp, "@F"))) {
	count++;
	if (tmp[2]!=0) tmp=tmp+2;
	else break;
	}
len=len+count*strlen(frm->first)-count*2;
count=0;
tmp=buf;
while ((tmp=strstr(tmp, "@L"))) {
	count++;
	if (tmp[2]!=0) tmp=tmp+2;
	else break;
	}
len=len+count*strlen(frm->last)-count*2+2;

if ((tmp=malloc(len+2))==NULL) {
	puts("Error allocating memory for tmp (replace_all)!");
	exit(2);
	}
strcpy(tmp,buf);
if (cr) while(strstr(tmp, "@B")) do_replace(tmp, "@B", " ");
else while(strstr(tmp, "@B")) do_replace(tmp, "@B", "\n");
while(strstr(tmp, "@F")) do_replace(tmp, "@F", frm->first);
while(strstr(tmp, "@L")) do_replace(tmp, "@L", frm->last);
while(strstr(tmp, "@N")) do_replace(tmp, "@N", frm->full);
free(buf);
return tmp;
}
