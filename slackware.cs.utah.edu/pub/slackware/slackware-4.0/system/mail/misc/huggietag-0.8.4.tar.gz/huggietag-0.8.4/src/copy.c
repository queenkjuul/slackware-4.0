#include "common.h"
#include <string.h>

void copy_headers(struct options *opt) {
char buf[1024];

open_tmp(opt);
fseek(opt->msg, 0L, 0);

buf[0]=0;
while (!feof(opt->msg)) {
	buf[0]=0;
	fgets(buf,1023,opt->msg);
	buf[1023]=0;
	if (buf[0]=='\n') {
		fputs(buf,opt->tmp);
		break;
		}
	fputs(buf,opt->tmp);
	}
}

void copy_body(struct options *opt) {
char buf[1024];

fseek(opt->msg, -1L, 1); /* rewind over the \n */

buf[0]=0;
while (!feof(opt->msg)) {
	buf[0]=0;
	fgets(buf,1023,opt->msg);
	buf[1023]=0;
	if (strncmp(buf,"...",3)==0) {
		fseek(opt->msg, -((long)strlen(buf)), 1);
		break;
		}
	if (strncmp(buf,"---",3)==0) {
		fseek(opt->msg, -((long)strlen(buf)), 1);
		break;
		}
	fputs(buf,opt->tmp);
	}
}

void copy_to_tear(struct options *opt) {
char buf[1024];

buf[0]=0;
while (!feof(opt->msg)) {
	buf[0]=0;
	fgets(buf,1023,opt->msg);
	buf[1023]=0;
	if (strncmp(buf,"---",3)==0) {
		fputs(buf,opt->tmp);
		break;
		}
	fputs(buf,opt->tmp);
	}
}

void copy_rest(struct options *opt) {
char buf[1024];

buf[0]=0;
while (!feof(opt->msg)) {
	buf[0]=0;
	fgets(buf,1023,opt->msg);
	buf[1023]=0;
	fputs(buf,opt->tmp);
	}
}
