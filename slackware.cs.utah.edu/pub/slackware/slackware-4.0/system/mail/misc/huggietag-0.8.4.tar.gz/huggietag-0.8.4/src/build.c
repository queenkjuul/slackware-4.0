#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#ifndef __MSDOS__
#include <unistd.h>
#endif

void build_index_file(struct options *opt)
{
long total;
struct stat coaster;
char *buff;

open_tag(opt);
open_out_idx(opt);

fseek(opt->tag, 0L, 2);
if (ftell(opt->tag)<=0) {
	puts("\nError reading tagline file. Check that there are a valid number of taglines\nand try again");
	exit(4); 
	}
/* Now count total tags in file... */

if ((buff=(char *)malloc(1000))==NULL) {
	puts("\nCould not allocate memory for buff!\nCould not build index file!!");
	exit(2);
	}

total=0;
fseek(opt->tag, 0L, 0);
puts("Counting tags. (one . per 100 tags found)");
printf(".");
while (!feof(opt->tag))
	{
	buff[0]='\0';
	fgets(buff, 999, opt->tag);
	buff[999]=0;
	if (feof(opt->tag)) {
		if (total!=0) {
			if (strlen(buff)>0) total++; /* don't forget to add last tag too...
						        but don't add just a single CR     */
			break;	
		} else {
			puts("\nError reading tagline file. Check that there are a valid number of taglines and\ntry again");
			exit(11);
			}
		}
	if (buff[strlen(buff)-1]!='\n'||(strlen(buff)==0)) {
		/* If tagline too long or just CR on line on it's own tell them... */
		puts("\nError reading tagline file. Invalid tagline found!!! Check that there are a\nvalid number of taglines and that each is less than 998 characters long.");
		exit(4);
		}
	else total++;
	if (total%100==0) printf(".");
	}

printf("\nNumber of tags in file: %ld\n", total);

/* er if this fails after we've opened it we're in trouble */
if (stat(opt->tagfile, &coaster)) {
	puts("Pigs have flown!");
	exit(42);
	}

fseek(opt->tag, 0L, 0);
fwrite(&total, sizeof(total), 1, opt->idx);
fwrite(&coaster.st_mtime, sizeof(coaster.st_mtime), 1, opt->idx);
while (!feof(opt->tag))
	{
	total=ftell(opt->tag);
	fwrite(&total, sizeof(total), 1, opt->idx);
	buff[0]='\0';
	fgets(buff, 999, opt->tag);
	buff[999]=0;
	if ((feof(opt->tag))||(strlen(buff)==0)) break;
	}
total=0;
fwrite(&total, sizeof(total), 1, opt->idx);
/* Write out a zero to the end. Stops fread not being able to read the pos
   of the last tag in tagpos */
free(buff);
puts("Index File Built!");
opt->pauseonerror=0;
exit(0);
}
