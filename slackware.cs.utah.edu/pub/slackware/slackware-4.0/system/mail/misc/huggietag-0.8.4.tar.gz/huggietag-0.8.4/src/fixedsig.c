/* Various stuff for dealing with sigs
 * 09/02/1999 - Started by Jonathan McDowell.

 * Started? I would have said written by but hey - huggie 2/4/99
 * Now deals with word breaks, and functions modified to "fit in" with
 * huggietag.
 */

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "common.h"

char *choosesig(const char *sigfile)
{
	FILE *sigf;
	char tmpsig[MAXSIG];
	size_t siglen;

	if ((sigf=fopen(sigfile,"rt"))!=NULL) {
		siglen=fread(tmpsig, sizeof(char), MAXSIG-1, sigf);
		fclose(sigf);
		if (siglen==MAXSIG-1) {
			puts("Error! Sig file is too large.");
			exit(18);
		} else {
			tmpsig[siglen]=0;
		}
	} else {
		printf("Error! Could not open '%s'\n",sigfile);
		exit(17);
	}
	return strdup(tmpsig);
}

void parsesig(char *sig, int *spaces, struct clever_sig *pyrex_clerk)
{
	char tmpsig[MAXSIG], *curchar, *numstart, *oldcurchar;
	struct sigspaces *curspace,*firstspace;
	int offset,loop;

	*spaces=tmpsig[0]=offset=0;
	curspace=firstspace=NULL;
	
	oldcurchar=sig;
	curchar=strchr(sig,'@');

	while (curchar!=NULL) {
		strncat(tmpsig, oldcurchar, curchar-oldcurchar);
		offset=offset+(curchar-oldcurchar);
		numstart=++curchar;
		while (*curchar=='@') {
			numstart=++curchar;
			++offset;
			strcat(tmpsig,"@");
		}
		while (isdigit(*curchar) && curchar!=0) {
			++curchar;
		}
		if (*curchar==0) {
			curchar=NULL;
			++offset;
			strcat(tmpsig, "@");
		} else if (*(curchar-1)=='@') {
			oldcurchar=curchar;
			curchar=(strchr(++curchar,'@'));
			++offset;
			strcat(tmpsig, "@");
		} else if (*curchar=='@'||
			   (*curchar=='R'&&*(curchar+1)=='@')||
			   (*curchar=='C'&&*(curchar+1)=='@')) {
			if (curspace==NULL) {
				firstspace=curspace=malloc(sizeof(*pyrex_clerk));
				curspace->size=0;
				curspace->align=0;
				curspace->next=NULL;
			} else {
				curspace->next=malloc(sizeof(*pyrex_clerk));
				curspace=curspace->next;
				curspace->next=NULL;
			}
			if (curspace==NULL) {
				perror("parsesig()");
				exit(18);
			}
			curspace->size=atoi(numstart);
			*spaces=*spaces+(curspace->size);
			curspace->offset=offset;
			curspace->align=0;
			if (*curchar=='R') {
				curspace->align=2;
				curchar++;
				}
			if (*curchar=='C') {
				curspace->align=1;
				curchar++;
				}
			for (loop=0; loop<curspace->size; ++loop) {
				strcat(tmpsig, " ");
				++offset;
			}

			oldcurchar=++curchar;
			curchar=(strchr(curchar,'@'));
		} else {
			oldcurchar=curchar;
			curchar=strchr(curchar,'@');
		}
	}
	strncat(tmpsig, oldcurchar, strlen(oldcurchar));
	strcpy(pyrex_clerk->tmpsig, tmpsig);
	pyrex_clerk->firstspace=firstspace;
}

int mergesigandtag(struct options *opt, struct clever_sig *pyrex_clerk, char *tag)
{
	char *tagleft, *nl, *buf, *realign, *realigned;
	struct sigspaces *curspace;
	int space;

	tagleft=tag;
	curspace=pyrex_clerk->firstspace;

	while (tagleft!=NULL && *tagleft!=0 && curspace!=NULL) {
		space=curspace->size;
		/* break at word/nl */
		if ((buf=malloc(space+2))==NULL) {
			puts("Eeek!");
			exit(4);
			}
		strncpy(buf, tagleft, MIN(space, strlen(tagleft)));
		buf[MIN(space, strlen(tagleft))]=0;
		if (space>strlen(tagleft)) {
			strncpy(&(pyrex_clerk->tmpsig[curspace->offset]), buf, MIN(space,strlen(buf)));
			tagleft=NULL;
		} else {
			if ((nl=index(buf,'\n'))||(nl=rindex(buf,' '))) {
				memset(nl+1,' ', strlen(nl)-1);
				space=space-strlen(nl);
				if (*nl=='\n') space++;
				}
			strncpy(&(pyrex_clerk->tmpsig[curspace->offset]), buf, MIN(space,strlen(buf)));
			tagleft=tagleft+space;
			if (nl&&strlen(tagleft)>strlen(tagleft+strlen(nl))&&isspace(*(tagleft+strlen(nl))))
			{
				strncpy((pyrex_clerk->tmpsig+curspace->offset+space),
					tagleft, strlen(nl));
				tagleft=tagleft+strlen(nl)+1;
				}
		}
		if (curspace->align>0) {
			if ((realign=malloc(curspace->size+1))==NULL) {
				puts("Error allocating memory for realign (mergesigandtag)!");
				exit(2);
				}
			strncpy(realign, &(pyrex_clerk->tmpsig[curspace->offset]), curspace->size);
			realign[curspace->size]=0;
			realigned=realign_space(realign, curspace->align);
			strncpy(&(pyrex_clerk->tmpsig[curspace->offset]), realigned, curspace->size);
			free(realign);
			free(realigned);
			}
		if (tagleft&&isspace(*tagleft)) tagleft++;
		free(buf);
		curspace=curspace->next;
	}
	if (opt->fillallspaces)
		{
		if (curspace==NULL&&tagleft==NULL) return 1;
		else return 0;
	} else {
		if (curspace==NULL&&tagleft) return 0;
		else return 1;
		}
}

int check_clever_sig(struct options *opt, int num, struct clever_sig *pyrex_clerk)
{
	int space;
	parsesig(choosesig(opt->sigs[num]),&space, pyrex_clerk);
	return (space>0);
}

char* realign_space(char *buf, int align) {
char *tmp;
int spaces,i,j;
int curpos;

if ((tmp=malloc(strlen(buf)+1))==NULL) {
	puts("Error allocating memory for tmp (realign_space)!");
	exit(2);
	}
tmp[0]=0;

spaces=0;
curpos=strlen(buf);
while(buf[--curpos]==' ') spaces++;

if (spaces==0) {
	strncpy(tmp,buf,strlen(buf));
} else {
	switch (align) {
		case 1: /* CENTER */
			i=spaces/2;
			for (j=0; j<i; j++) strcat(tmp, " ");
			strncat(tmp, buf, curpos+1);
			i=spaces%2;
			if (i) strcat(tmp, " ");
			i=spaces/2;
			for (j=0; j<i; j++) strcat(tmp, " ");
			if (strlen(buf)!=strlen(tmp)) {
				puts("This should never happen! Length mismatch C");
				exit(2);
				}
			break;
		case 2: /* RIGHT */
			for (i=0; i<spaces; i++) strcat(tmp, " ");
			strncat(tmp, buf, curpos+1);
			if (strlen(buf)!=strlen(tmp)) {
				puts("This should never happen! Length mismatch R");
				exit(2);
				}
			break;
		}
	}
return tmp;
}
