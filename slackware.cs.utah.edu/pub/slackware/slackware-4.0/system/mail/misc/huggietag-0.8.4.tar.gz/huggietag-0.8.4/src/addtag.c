#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#ifdef __MSDOS__
#include <time.h>
#else
#include <unistd.h>
#endif

long tagpos(struct options *opt) {
long num,randnum;
struct stat coaster;
time_t mtime;

open_idx(opt);
fseek(opt->idx, 0L, 0); /* reset to BOF */

fread(&num, sizeof(long), 1, opt->idx); /* read first long */
fread(&mtime, sizeof(mtime), 1, opt->idx); /* read timestamp */

/* er if this fails after we've opened it we're in trouble */
if (stat(opt->tagfile, &coaster)) {
	puts("Pigs have flown!");
	exit(42);
	}
if (mtime!=coaster.st_mtime) {
	puts("Error! Tagfile has changed! Please rebuild the index file!");
	exit(8);
	}

if (num<200) randnum=rand();
else randnum=longrand();
randnum=(randnum % num);
/*TRY ALTERNATE METHOD*/

fseek(opt->idx, 1*sizeof(time_t), 0);
/* NB fixes error where Huggietag assumed old idx file format
   In the new one of course, the first long is really a time_t and trying to
   assume that the time_t is a pos in the tagfile causes "interesting"
   results */
fseek(opt->idx, (randnum+1)*sizeof(long), 1);
if (feof(opt->idx)) {
	puts("Error! EOF reached in idx.");
	exit(7);
	}
fread(&num, sizeof(long), 1, opt->idx);
/*
This would work *IF* randnum*sizeof(long) could be guaranteed not to exceed
a long. If you are having problems then I could implement a store in double,
decrement double while not long < max_long fseek(max_long) sort of loop but
imho it's not worth it.
*/
return num;
}

char *gettagline(struct options *opt, struct from *frm, int reformat) {
long tag;
char tagline[1000];
int recursion;
char *ref_tag;

open_tag(opt);

recursion=0;
do {
	tag=tagpos(opt);
	if (tag!=0) {
		fseek(opt->tag, tag-1, 0);
		if (fgetc(opt->tag)!='\n') {
			puts("Error in tagfile! Please check the index file is recent!");
#ifdef DEBUG
printf("Problem at %ld\n", tag-1);
#endif
			exit(8);
			}
		}
	fseek(opt->tag, tag, 0);
	tagline[0]=0;
	fgets(tagline, 999, opt->tag);
	tagline[999]=0;
	recursion++;
	if (recursion>300) {
		puts("Too much recursion! This could be because there are no tags in the tagline\nfile or they all require macro expansion which may have been disabled.\nIf you think you have no reason to get this please mail the author\n(see README for address)");
		exit(9);
		}
	} while(tagline[0]=='#'||
	(frm->first[0]==0&&(strstr(tagline, "@N")||strstr(tagline,"@L")||
			    strstr(tagline,"@F"))));
if (reformat) {
	ref_tag=reformat_tag(tagline, opt, frm);
	return ref_tag;
} else {
	return strdup(tagline);
	}
}

void normal_add_tag(struct options *opt, struct from *frm) {
char *ref_tag;
int i;
while (1) {
	ref_tag=gettagline(opt,frm,1);
	printf(ref_tag);
	printf("Do you want to add this tagline? (y,n)");
	if (yesno()) {
		for (i=0; i<opt->newline; i++) fputs("\n", opt->tmp);
		fputs(ref_tag, opt->tmp);
		free(ref_tag);
		break;
	} else {
		free(ref_tag);
		printf("Do you want to quit without adding a tagline? (y,n)");
		if (yesno()) {
			opt->pauseonerror=0;
			exit(5);
			}
		}
	}
}

void add_tag(struct options *opt, struct from *frm, struct clever_sig *pyrex_clerk) {
char *tag, *tmp, *oldtmp;
char clear[MAXSIG];
int recursion;
if (pyrex_clerk->firstspace==NULL) normal_add_tag(opt,frm);
else {
/* otherwise we merge sig and tag */
strcpy(clear, pyrex_clerk->tmpsig);
recursion=0;
while (1) {
	tag=gettagline(opt,frm,0);
	if ((oldtmp=malloc(strlen(tag)+1))==NULL) {
		puts("Error allocating memory for tmp (add_tag)!");
		exit(2);
		}
	strcpy(oldtmp, tag);
	if (oldtmp[strlen(oldtmp)-1]=='\n') oldtmp[strlen(oldtmp)-1]=0;
	tmp=replace_all(oldtmp, frm,1);

#ifdef DEBUG	
printf("Tagline in add_tag: %s\n",tmp);
#endif
	if (mergesigandtag(opt, pyrex_clerk, tmp)) {
		puts(pyrex_clerk->tmpsig);
		printf("Do you want to add this tagline? (y,n)");
		if (yesno()) {
			fputs(pyrex_clerk->tmpsig, opt->tmp);
			free(tmp);
			break;
		} else {
			free(tmp);
			printf("Do you want to quit without adding a tagline? (y,n)");
			if (yesno()) {
				opt->pauseonerror=0;
				exit(5);
				}
			}
		recursion=0;
		}
	else free(tmp); //ahem we wouldn't forget to do that would we.
	recursion++;
	if (recursion>300) {
		puts("Too much recursion! This could be because there are no tags in the tagline\nfile or they are all too long to fit inside your signature.");
		puts("Alternately this could occur if FILLALLSPACES is set to YES and there are no\ntaglines long enough to fill all the spaces in your tagline");
		puts("If you think you have no reason to get this please mail the author\n(see README for address)");
		exit(9);
		}
	strcpy(pyrex_clerk->tmpsig, clear);
	free(tag);
	}
} //else
}
