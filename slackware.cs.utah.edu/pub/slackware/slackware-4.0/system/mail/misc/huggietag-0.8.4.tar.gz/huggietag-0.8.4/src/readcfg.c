#include "common.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>

#ifndef __MSDOS__
#include <getopt.h>
#else
#include "getopt.c"
#include "getopt1.c"
#endif

#define NUMOPT 14
#define MAX(a,b) ((a)>(b)) ? (a) : (b)

FILE *open_conf(char *filename) {
return fopen(filename, "rt");
}

void parsebuf(char *buf, struct options *opt, char *home) {
int curpos=0;
int length=strlen(buf);
int i,tmppos=0;
long tlong;
DIR *sigdir;
struct dirent *thisent;
struct stat fileinf;
char filetmp[256];
char tmp[256];
char b[256], *beard;
char options[NUMOPT][14]={
"LEADER", "FIRST", "PRETEAR", "TAGFILE", "MAXLINELEN", "NEWLINE",
"TAGTEMP","RANDHEAD", "TEARLINE", "RANDTEAR", "RANDSIG", "FILLALLSPACES",
"SIGDIR", "PAUSEONERROR"};

while (curpos<length-1 && isspace(buf[curpos])) curpos++;

if (buf[curpos]=='#') return;  /* It's a comment    */
if (buf[curpos]=='\n') return; /* It's a blank line (Oh what fun it is to
				  write an htrc parser...) */
if (buf[curpos]==0) return; /* It's an empty string. Don't forget about
				those, Mr Huggins. :P */

while (! isspace(buf[curpos])) tmp[tmppos++]=buf[curpos++];
tmp[curpos]=0;

while (curpos<length-1 && isspace(buf[curpos])) curpos++;

if (buf[curpos]=='\n') {
	printf("Option %s has no value!\n",tmp);
	return;
	}

i=0;
while ((strncmp(tmp, options[i], MIN(strlen(options[i]),strlen(tmp)))!=0)&&(i<NUMOPT)) i++;

beard=buf+curpos;
if (beard[strlen(beard)-1]=='\n') beard[strlen(beard)-1]=0; /* strip off \n */

strcpy(b,beard);

switch(i) {
	case 0: /* LEADER */
		if (b[0]!='\"') {
			puts("Error in config file! LEADER option not surrounded by \".");
			exit(1);
			}
		if (strlen(b)>60) {
			puts("Error in config file! LEADER option too long!");
			exit(1);
			}
		if (strlen(b)==2) {
			puts("Error in config file! LEADER value too short!");
			exit(1);
			}
		strncpy(opt->leader, b+1, strlen(b)-2);
		opt->leader[strlen(b)-2]=0;
#ifdef DEBUG_CFG
printf("LEADER %s '%s'\n",tmp,opt->leader);
#endif
		break;
	case 1: /* FIRST */
		if (b[0]!='\"') {
			puts("Error in config file! FIRST option not surrounded by \".");
			exit(1);
			}
		if (strlen(b)>59) {
			puts("Error in config file! FIRST option too long!");
			exit(1);
			}
		if (strlen(b)==2) {
			puts("Error in config file! FIRST value too short!");
			exit(1);
			}
		strncpy(opt->first, b+1, strlen(b)-2);
		opt->first[strlen(b)-2]=0;
#ifdef DEBUG_CFG
printf("FIRST %s '%s'\n",tmp,opt->first);
#endif
		break;
	case 2: /* PRETEAR */
		if (b[0]!='\"') {
			puts("Error in config file! PRETEAR option not surrounded by \".");
			exit(1);
			}
		if (strlen(b)!=5) {
			puts("Error in config file! PRETEAR option not 5 characters long!");
			exit(1);
			}
		strncpy(opt->tearline, b+1, 3);
		opt->tearline[3]=0;
#ifdef DEBUG_CFG
printf("PRETEAR %s %s\n",tmp,opt->tearline);
#endif
		break;
	case 3: /* TAGFILE */
		if (strlen(b)>254) {
			puts("Error in config file! TAGFILE option too long!");
			exit(1);
			}
#ifndef __MSDOS__
		expand_home(b, "TAGFILE",254,home);
#endif
		strncpy(opt->tagfile, b, strlen(b));
		opt->tagfile[strlen(b)]=0;
#ifdef DEBUG_CFG
printf("TAGFILE %s %s\n",tmp,opt->tagfile);
#endif
		break;
	case 4: /* MAXLINELEN */
		opt->maxlinelen=0;
		if (strlen(b)<4) {
			tlong=strtol(b, NULL, 10);
			if (tlong>9&&tlong<257) opt->maxlinelen=(int)tlong;
			}
		if (opt->maxlinelen==0) {
			puts("Error in config file! MAXLINELEN is not between 10 and 256!");
			exit(1);
			}
#ifdef DEBUG_CFG
printf("MAXLINELEN %s %d\n",tmp,opt->maxlinelen);
#endif
		break;
	case 5: /* NEWLINE */
		opt->newline=11;
		if (strlen(b)<3) {
			tlong=strtol(b, NULL, 10);
			if (tlong>-1&&tlong<11) opt->newline=(int)tlong;
			}
		if (opt->newline==11) {
			puts("Error in config file! NEWLINE is not between 0 and 10!");
			exit(1);
			}
#ifdef DEBUG_CFG
printf("NEWLINE %s %d\n",tmp,opt->newline);
#endif
		break;
	case 6: /* TAGTEMP */
		if (strlen(b)>254) {
			puts("Error in config file! TAGTEMP option too long!");
			exit(1);
			}
#ifndef __MSDOS__
		expand_home(b, "TAGTEMP", 254, home);
#endif
		strcpy(opt->tmpfile, b);
#ifdef DEBUG_CFG
printf("TAGTEMP %s %s\n",tmp,opt->tmpfile);
#endif
		break;
	case 7: /* RANDHEAD */
		i=0;
		while (*opt->headers[i]!=0) {
			if (i>48) {
				puts("Error in config file! Cannot allow more than 50 headers!");
				exit(1);
				}
			i++;
			}
		if ((opt->headers[i]=realloc(opt->headers[i], strlen(b)+1))==NULL) {
			puts("Could not allocate memory for header!");
			exit(2);
			}
		if (strlen(b)>254) {
			puts("Cannot allow more than 255 chars per header. Please check config file");
			exit(1);
			}
		strncpy(opt->headers[i],b+1,strlen(b)-2); /* Remove quotes */
		opt->headers[i][strlen(b)-2]=0;
		i++;
		if ((opt->headers[i]=malloc(1))==NULL) {
			puts("Could not allocate memory for last header!");
			exit(2);
			}
		*opt->headers[i]=0;
#ifdef DEBUG_CFG
printf("RANDHEAD %s %s\n",tmp,opt->headers[--i]);
#endif
		break;
	case 8: /* TEARLINE OFF SHORT or LONG */
		i=8;
		if (strncmp(b,"OFF",3)==0) i=0;
		if (strncmp(b,"SHORT",5)==0) i=1;
		if (strncmp(b,"LONG",4)==0) i=2;
		if (i==8) {
		    	puts("Error in config file! Invalid option after TEARLINE");
		    	exit(1);
		    	}
		opt->tearlinetype=i;
#ifdef DEBUG_CFG
printf("TEARLINE %s %d\n",tmp, opt->tearlinetype);
#endif
		break;
	case 9: /* RANDTEAR */
		i=0;
		while (*opt->tears[i]!=0) {
			if (i>48) {
				puts("Error in config file! Cannot allow more than 50 tearlines!");
				exit(1);
				}
			i++;
			}
		if ((opt->tears[i]=realloc(opt->tears[i], strlen(b)+1))==NULL) {
			puts("Could not allocate memory for tearline!");
			exit(2);
			}
		if (strlen(b)>56) {
			puts("Cannot allow more than 57 chars per tearline. Please check config file");
			exit(1);
			}
		strncpy(opt->tears[i],b+1,strlen(b)-2); /* Remove quotes */
		opt->tears[i][strlen(b)-2]=0;
		i++;
		if ((opt->tears[i]=malloc(1))==NULL) {
			puts("Could not allocate memory for last tearline!");
			exit(2);
			}
		*opt->tears[i]=0;
#ifdef DEBUG_CFG
printf("RANDTEAR %s %s\n",tmp,opt->tears[--i]);
#endif
		break;
	case 10: /* RANDSIG */
		i=0;
		while (*opt->sigs[i]!=0) {
			if (i>48) {
				puts("Error in config file! Cannot allow more than 50 signatures!");
				exit(1);
				}
			i++;
			}
#ifndef __MSDOS__
		expand_home(b, "RANDSIG", 254, home);
#endif
		if ((opt->sigs[i]=realloc(opt->sigs[i], strlen(b)+1))==NULL) {
			puts("Could not allocate memory for signature file!");
			exit(2);
			}
		if (strlen(b)>254) {
			puts("Cannot allow more than 255 chars per signature filename. Please check config file");
			exit(1);
			}
		strncpy(opt->sigs[i],b,strlen(b)); /* Remove quotes */
		opt->sigs[i][strlen(b)]=0;
		i++;
		if ((opt->sigs[i]=malloc(1))==NULL) {
			puts("Could not allocate memory for last signature!");
			exit(2);
			}
		*opt->sigs[i]=0;
#ifdef DEBUG_CFG
printf("RANDSIG %s %s\n",tmp,opt->sigs[--i]);
#endif
		break;
	case 11: /* FILLALLSPACES YES or NO */
		i=2;
		if (strncmp(b,"NO",2)==0) i=0;
		if (strncmp(b,"YES",3)==0) i=1;
		if (i==2) {
puts(b);
		    	puts("Error in config file! Invalid option after FILLALLSPACES");
		    	exit(1);
		    	}
		opt->fillallspaces=i;
#ifdef DEBUG_CFG
printf("FILLALLSPACES %s %d\n",tmp, opt->fillallspaces);
#endif
		break;
	case 12: /* SIGDIR */
		i=0;
		while (*opt->sigs[i]!=0) {
			if (i>48) {
				puts("Error in config file! Cannot allow more than 50 signatures!");
				exit(1);
				}
			i++;
			}

#ifndef __MSDOS__
		expand_home(b, "SIGDIR", 254, home);
#endif
		if (b[strlen(b)-1]!='/')
			strncat(b, "/", 1);
		if ((sigdir=opendir(b))==NULL) {
			printf("Error! Could not open SIGDIR! Trying to open '%s'\n",b);
			exit(3);
			}
		while ((thisent=readdir(sigdir))!=NULL) {
			strncpy(filetmp, b, 255);
                        filetmp[255]=0;
                        strncat(filetmp, thisent->d_name, 255-strlen(filetmp));
			if (strlen(filetmp)<(strlen(b)+strlen(thisent->d_name))) {
				puts("Error! filetmp would overflow if SIGDIR expanded!");
				exit(1);
				}

			stat(filetmp, &fileinf);

#ifdef __MSDOS__
			if ((S_IFDIR & fileinf.st_mode)==S_IFDIR) {
#else
			if (!S_ISDIR(fileinf.st_mode)) {
#endif
#ifdef DEBUG_CFG
				printf("SIGDIR: Adding %s to siglist.\n", filetmp);
#endif
				if ((opt->sigs[i]=realloc(opt->sigs[i], strlen(filetmp)+1))==NULL) {
					puts("Could not allocate memory for signature file!");
					exit(2);
					}
				if (strlen(filetmp)>254) {
					puts("Cannot allow more than 255 chars per signature filename. Please check config file");
					exit(1);
					}
				strncpy(opt->sigs[i],filetmp,strlen(filetmp)); /* Remove quotes */
				opt->sigs[i][strlen(filetmp)]=0;
				i++;
				if ((opt->sigs[i]=malloc(1))==NULL) {
					puts("Could not allocate memory for last signature!");
					exit(2);
					}
				*opt->sigs[i]=0;
				}
			}
#ifdef DEBUG_CFG
printf("SIGDIR %s %s %d\n",tmp,opt->sigs[--i], i);
#endif
		break;
	case 13: /* PAUSEONERROR YES or NO */
		i=2;
		if (strncmp(b,"NO",2)==0) i=0;
		if (strncmp(b,"YES",3)==0) i=1;
		if (i==2) {
		    	puts("Error in config file! Invalid option after PAUSEONERROR");
		    	exit(1);
		    	}
		opt->pauseonerror=i;
#ifdef DEBUG_CFG
printf("PAUSEONERROR %s %d\n",tmp, opt->pauseonerror);
#endif
		break;
	default: /* UNKNOWN */
		printf("Unknown option found in config file '%s'\nContinuing...\n",tmp);
		break;
	} //end switch

} //end parsebuf()

#ifndef __MSDOS__
void expand_home(char *b, const char *what, int num, const char *home) {
if (strstr(b, "$HOME")!=NULL) {
	if (home[0]==0) {
		printf("Error! %s wants $HOME expanded but no HOME variable is available in the\nenvironment!\n",what);
		exit(1);
		}
	if (strlen(b)-5+strlen(home)>num) {
		printf("Error! %s would overflow if $HOME expanded!\n",what);
		exit(1);
		}
	do_replace(b, "$HOME", home);
	}
if (strstr(b, "~")!=NULL) {
	if (home[0]==0) {
		printf("Error! %s wants ~ expanded but no HOME variable is available in the\nenvironment!\n",what);
		exit(1);
		}
	if (strlen(b)-1+strlen(home)>num) {
		printf("Error! %s would overflow if ~ expanded!\n",what);
		exit(1);
		}
	do_replace(b, "~", home);
	}
}
#endif

int parse_config(struct options *opt, char *cfgfile) {
FILE *cfg;
char buf[256];
char *home;

if (!(cfg=open_conf(cfgfile))) return -1;

home=strdup(getenv("HOME"));                               
if (strlen(home)>245) {                                    
	puts("Home directory from environment >245 chars");
	exit(1);                                           
	}                                                  
strcpy(buf, home);                                         
strcat(buf, "/.htrc");                                     

while (!feof(cfg)) {
	buf[0]=0;
	fgets(buf, 255, cfg);
	buf[255]=0;
#ifdef STUPID_DEBUG
puts(buf);
#endif
	parsebuf(buf, opt, home);

} //while !feof(cfg)

fclose(cfg);
free(home);
return 0;
}

void parse_args(struct options *opt, int argc, char **argv) {
int c;
int cfgread, msgf, tagf, buildme,stealme;
char buf[256];
#ifndef __MSDOS__
char *home;
home=NULL;
#endif

cfgread=msgf=tagf=buildme=stealme=FALSE;

while (1)
	{
	int option_index = 0;
	static struct option long_options[] =
	{
		{"build", 0, 0, 'b'},
		{"config", 1, 0, 'c'},
		{"help", 0, 0, 'h'},
		{"steal", 0, 0, 's'},
		{"tag", 1, 0, 't'},
		{"BUILD", 0, 0, 'B'},
		{"CONFIG", 1, 0, 'C'},
		{"HELP", 0, 0, 'H'},
		{"STEAL", 0, 0, 'S'},
		{"TAG", 1, 0, 'T'},
		{0, 0, 0, 0}
	};

	c = getopt_long (argc, argv, "bc:st:hBC:ST:H",
			long_options, &option_index);
	if (c == -1)
		break;

	switch (c)
		{
		case 0:
			printf ("option %s", long_options[option_index].name);
			if (optarg)
			printf (" with arg %s", optarg);
			printf ("\n");
			break;

		case 'b':
		case 'B':
			/* build */
			if (tagf) build_index_file(opt);
			else
				buildme=TRUE;
			break;

		case 'c':
		case 'C':
			/* config */
			if (parse_config(opt, optarg)==0) cfgread=TRUE;
			if (opt->tagfile[0]!=0) tagf=TRUE;
			if (tagf&&buildme) build_index_file(opt);
			break;

		case 'h':
		case 'H':
			/* help */
			display_help();
			break;
		case 's':
		case 'S':
			/* steal */
			stealme=TRUE;
			break;
		case 't':
		case 'T':
			/* tag */
			if (strlen(optarg)>254)
				{
				puts("Tagfile argument too long! Must be less than 254 characters");
				exit(1);
				}
			strcpy(opt->tagfile,optarg);
			opt->tagfile[254]=0;
			tagf=TRUE;
			if (buildme) build_index_file(opt);
			break;

		case '?':
			puts(" ");
			display_help();
			break;

		default:
			printf ("ERROR: getopt returned character code 0%o ??\\n", c);
 		}
	}

if (!cfgread) {
	#ifdef __MSDOS__
	parse_config(opt, "ht.cfg");
	#else
	home=strdup(getenv("HOME"));                               
	if (strlen(home)>245) {                                    
		puts("Home directory from environment >245 chars");
		exit(1);                                           
		}                                                  
	strcpy(buf, home);                                         
	strcat(buf, "/.htrc");                                     
	parse_config(opt, buf);
	#endif
	}
if (opt->tagfile[0]!=0) tagf=TRUE;
if (buildme&&tagf) build_index_file(opt);
if (!tagf) {
	puts("No tagline file on cmdline or in cfg file! Cannot continue.\nUse tags --help for help");
	exit(1);
	}

if (optind < argc)
	{
	if (strlen(argv[optind])>254) {
		puts("Message filename too long! Must be less than 255 characters (inc. path)\nUse tags --help for help");
		exit(14);
		}
	strcpy(opt->msgfile,argv[optind++]);
	msgf=TRUE;

	if (stealme) {
		if (tagf&&msgf) steal_tags(opt);
		else {
			puts("No tagline file on cmdline or in cfg file! Cannot steal tags\nUse tags --help for help");
			exit(1);
			}
		}

	if (optind<argc) {
		puts("Unrecognised command line parameters: ");
		while (optind < argc)
			printf("%s ", argv[optind++]);
		display_help();
		}
	}

if (!msgf) {
	puts("No message file supplied on the commandline. I'm good but I'm not psychic\n");
	puts("Use tags --help for help");
	exit(1);
	}

if (opt->tearlinetype==2&&opt->tears[0][0]==0) {
	puts("You have chosen LONG tearlines but have not specified any RANDTEAR lines\nin the config file");
	exit(1);
	}
if (opt->first[0]==0) {
	puts("You have not specified FIRST in the config file!");
	exit(1);
	}
if (opt->leader[0]==0) {
	puts("You have not specified LEADER in the config file!");
	exit(1);
	}
if (opt->tearlinetype==8) {
	puts("You have not specified TEARLINE in the config file!");
	exit(1);
	}
if (opt->tearlinetype>0 && opt->tearline[0]==0) {
	puts("You have not specified PRETEAR in the config file but TEARLINE is not OFF!");
	exit(1);
	}
if (opt->tmpfile[0]==0) {
	puts("You have not specified TAGTEMP in the config file!");
	exit(1);
	}

#ifndef __MSDOS__
free(home);
#endif 
}
