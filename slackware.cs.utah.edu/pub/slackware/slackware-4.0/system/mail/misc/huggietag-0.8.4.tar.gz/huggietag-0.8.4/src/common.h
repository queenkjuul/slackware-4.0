#include <stdio.h>

#define TRUE 1
#define FALSE 0
#define BUILD "4"
#define VERSION "0.8"
#define MAXSIG 480  /* That's enough for 6*80, which is EBW */
#define MIN(a,b) (a>b) ? b : a

#ifdef __MSDOS__
#define rindex strrchr
#define index strchr
#endif

struct options {
	char leader[62]; 		/* bit before tagline */
	char first[61];			/* bit before first line of tag */
	char tearline[5];		/* used before "Huggietag" */
	int maxlinelen;			/* max chars per line */
	int newline;			/* how many newlines before sig */
	int tearlinetype;		/* OFF=0, SHORT=1, LONG=2 */
	int tagfound;
	int fillallspaces;
	int pauseonerror;
	
	char msgfile[256]; FILE *msg;
	char tagfile[256]; FILE *tag;
	char tmpfile[256]; FILE *tmp;
	char sigfile[256]; FILE *sig;
	char *idxfn;   FILE *idx;
	
	char *headers[51];		/* Array of pointers to rand headers */
	char *tears[51];		/* rand tearlines */
	char *sigs[51];			/* rand sigs */
	};

struct from {
	char full[80];
	char first[80];
	char last[80];
	};

struct sigspaces {
	int offset;
	int size;
	int align;
	struct sigspaces *next;
};

struct clever_sig {
	struct sigspaces *firstspace;
	char tmpsig[MAXSIG];
	};

//options.c
void clear_options(struct options *opt);
void clear_from(struct from *frm);
void clear_sigstuff(struct clever_sig *pyrex_clerk);
//readcfg.c
int parse_config(struct options *opt, char *cfgfile);
void parse_args(struct options *opt, int argc, char **argv);
void expand_home(char *b, const char *what, int num, const char *home);
//reformat.c
char* reformat_head(char *buf, struct options *opt, struct from *frm);
char* reformat_tag(char *buf, struct options *opt, struct from *frm);
//help.c
void display_help();
//build.c
void build_index_file(struct options *opt);
//steal.c
void steal_tags(struct options *opt);
//from.c
void parse_msg_headers(struct options *opt, struct from *frm);
//open.c
void open_msg(struct options *opt);
void open_idx(struct options *opt);
void open_out_idx(struct options *opt);
void open_tag(struct options *opt);
void open_out_tag(struct options *opt);
void open_tmp(struct options *opt);
//addheaders.c
void add_msg_cust_headers(struct options *opt, struct from *frm);
//copy.c
void copy_headers(struct options *opt);
void copy_body(struct options *opt);
void copy_to_tear(struct options *opt);
void copy_rest(struct options *opt);
//rand.c
long longrand();
void slongrand(unsigned long seed);
//checktags.c
void check_for_tags(struct options *opt);
//linux_getch.c
int getch();
//yesno.c
int yesno();
int yesnoquit();
//addtag
void add_tag(struct options *opt, struct from *frm, struct clever_sig *pyrex_clerk);
//move.c
void move_file(char *from, char *to);
//replace.c
char *replace_all(char *buf, struct from *frm, int cr);
void do_replace(char *buf, const char *foo, const char *bar);
//addsig.c
void add_sig(struct options *opt, struct clever_sig *pyrex_clerk);
void add_tear(struct options *opt);

// Definitions for Jonathan McDowells cunning sig interpreters etc.
#define MAXSIG 480  /* That's enough for 6*80, which is EBW */
#define MIN(a,b) (a>b) ? b : a


char *choosesig(const char *sigfile);
void parsesig(char *sig, int *spaces, struct clever_sig *pyrex_clerk);
int mergesigandtag(struct options *opt, struct clever_sig *pyrex_clerk, char *tag);
int check_clever_sig(struct options *opt, int num, struct clever_sig *pyrex_clerk);
char* realign_space(char *buf, int align);
