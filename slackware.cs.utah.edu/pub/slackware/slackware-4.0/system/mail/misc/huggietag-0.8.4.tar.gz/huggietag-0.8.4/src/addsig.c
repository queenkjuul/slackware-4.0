#include "common.h"
#include <stdlib.h>
#include <string.h>

void add_sig(struct options *opt, struct clever_sig *pyrex_clerk) {
FILE *sig;
char buf[1000];
int i,j,c,pos,used[50];
char *tmpsig;

pos=i=0;
for (c=0; c<50; c++) used[c]=255;
while (*opt->sigs[i]!=0) i++;
if (i>0) {
	if (i>1) {
		j=i;
		do {
			i=(rand() % j);
			
			if (pos==j) {
				printf("All signatures in list exhausted! Restart? (y,n,q)");
				if (yesnoquit()==1) {
					pos=0;
					for (c=0; c<50; c++) used[c]=255;
			/* if we allow >255 sigs then this becomes invalid */
				} else {
					opt->pauseonerror=0;
					exit(5);
					}
				}
			
			for (c=0; c<50; c++) {
				if (used[c]==i) {
					break;
					}
				}
			if (c==50) {
				used[pos++]=i;
 				tmpsig=choosesig(opt->sigs[i]);
				puts(tmpsig);
				printf("Do you want to use this sig? (y,n,q)");
				free(tmpsig);
				c=yesnoquit();
				}
			else c=0;
			} while (!c);
			if (c==2) {
				opt->pauseonerror=0;
				exit(5);
				}
		}
	else i--;

	if (!check_clever_sig(opt,i,pyrex_clerk)) {

		if ((sig=fopen(opt->sigs[i],"rt"))==NULL) {
			printf("Could not open signature! Trying to open \"%s\"",opt->sigs[i]);
			exit(3);
			}

		while (!feof(sig)) {
			buf[0]=0;
			fgets(buf, 999, sig);
			buf[999]=0;
			fputs(buf,opt->tmp);
			}
		}

	}
}

void add_tear(struct options *opt) {
int i=0;
char buf[100];

buf[0]=0;
switch(opt->tearlinetype) {
	case 0: /* OFF */
		break;
	case 1: /* SHORT */
		sprintf(buf, "%s HuggieTag %s", opt->tearline, VERSION);
		break;
	case 2: /* LONG */
		sprintf(buf, "%s HuggieTag %s - ", opt->tearline, VERSION);
		while (*opt->tears[i]!=0) i++;
		if (i>0) {
			if (i>1) i=(rand() % i);
			else i--;
			strcat(buf, opt->tears[i]);
			}
		break;
	}

if (opt->tearlinetype>0) fputs(buf, opt->tmp);
}
