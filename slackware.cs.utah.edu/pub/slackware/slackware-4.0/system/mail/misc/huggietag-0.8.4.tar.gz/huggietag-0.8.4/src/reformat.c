#include "common.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

char *reformat_line(char *buf, int length) {
char *b;
char *spc;

if ((b=malloc(strlen(buf)+1))==NULL) {
	puts("Error allocating memory for b (reformat_line)!");
	exit(2);
	}
strcpy(b,buf);
if (strlen(b)<length) return b;
spc=index(b, '\n');
if (spc) {
	if (strlen(spc)!=strlen("\n")&&	      /* if it's the \n at the end of */
	    (strlen(b)-strlen(spc))<length) { /* the line then keep it        */
		*spc=0;
		return b;
		}
	}
b[length-1]=0;
/* Do not use isspace because that would pickup on the \n which would mean that
   if a tag is exactly the right length and the \n falls at length then it would
   be pruned from the end making adding a sig more difficult.
   while :; do ../tags test; sleep 1; done IMF :) */
if (buf[length-1]==' '||buf[length-1]=='\t') return b;
spc=rindex(b, ' ');
if (spc) {
	*spc=0;
	}
return b;
}

char* reformat_head(char *buf, struct options *opt, struct from *frm) {
/* for moment just print it */
char *b, *line, *temp, *oldtmp;

if ((temp=malloc(strlen(buf)+1))==NULL) {
	puts("Error allocating memory for temp (reformat_head)!");
	exit(2);
	}
strcpy(temp,buf);
oldtmp=replace_all(temp, frm,0);
temp=oldtmp;

if ((b=malloc(2))==NULL) {
	puts("Error allocating initial memory for b (reformat_head)!");
	exit(2);
	}
*b=0;

do {
	line=reformat_line(temp, opt->maxlinelen);
	if ((b=realloc(b, strlen(b)+strlen(line)+3))==NULL) {
		puts("Error allocating memory for b (reformat_head)!");
		exit(2);
		}
	if (*b!=0) strcat(b, "\n");
	strcat(b,line);
	temp=temp+strlen(line);
	if (isspace(*temp)) temp=temp+1;
	free(line);
	} while(strlen(temp)>0);
free(oldtmp);
return b;
}

char* reformat_tag(char *buf, struct options *opt, struct from *frm) {
/* for moment just print it */
char *b, *line, *temp, *oldtmp;
int first_time;

if ((temp=malloc(strlen(buf)+1))==NULL) {
	puts("Error allocating memory for temp (reformat_tag)!");
	exit(2);
	}
strcpy(temp, buf);
oldtmp=replace_all(temp, frm,0);
temp=oldtmp;

if ((b=strdup(opt->leader))==NULL) {
	puts("Error allocating initial memory for b (reformat_tag)!");
	exit(2);
	}
strncpy(b,opt->first,strlen(opt->first)); /* copy first over the first bit of leader */

first_time=1;
do {
	line=reformat_line(temp, opt->maxlinelen-strlen(opt->leader));
	if ((b=realloc(b, strlen(b)+strlen(opt->leader)+strlen(line)+3))==NULL) {
		puts("Error allocating memory for b (reformat_tag)!");
		exit(2);
		}
	if (first_time) first_time=0;
	else {
		strcat(b, "\n");
		strcat(b, opt->leader);
		first_time=0;
		}
	strcat(b,line);
	temp=temp+strlen(line);
	if (temp&&isspace(*temp)) temp++;
	free(line);
	} while(strlen(temp)>0);
free(oldtmp);
return b;
}
