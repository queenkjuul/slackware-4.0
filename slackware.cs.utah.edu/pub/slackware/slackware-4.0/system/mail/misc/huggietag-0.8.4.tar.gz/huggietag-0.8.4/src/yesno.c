#include <ctype.h>
#include <stdio.h>
#include "common.h"

#ifdef __MSDOS__
#include <conio.h>
#else
#include "unxconio.h"
#endif

int yesno()
{
char c;
c='\0';
fflush(stdout);
do {
	c=tolower(getch());
	if (!((c=='n')||(c=='y')))
		{
#ifdef UNXCONIO__H
		term_option(1);
#endif
		putchar('\a');
		fflush(stdout);
		}
	} while (!((c=='n')||(c=='y')));
printf("%c\n",c); /* return to start of next line */
return c=='y' ? 1 : 0;
}

int yesnoquit()
{
char c;
c='\0';
fflush(stdout);
do {
	c=tolower(getch());
	if (!((c=='n')||(c=='y')||(c=='q'))) /* Hmmm. I think I'm a bracket fetishist */
		{
#ifdef UNXCONIO__H
		term_option(1);
#endif
		putchar('\a');
		fflush(stdout);
		}
	} while (!((c=='n')||(c=='y')||(c=='q')));
printf("%c\n",c); /* return to start of next line */
return c=='y' ? 1 : (c=='q' ? 2 : 0);
}
