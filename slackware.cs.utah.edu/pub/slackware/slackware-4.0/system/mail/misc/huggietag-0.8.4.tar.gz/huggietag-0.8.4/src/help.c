#include "common.h"

void display_help()
{
puts("Usage: tags [options] message_file");
puts("Options:");
puts(" -s, --steal message_file     - Steal tag(s) from message_file");
puts(" -b, --build                  - Build index file");
puts(" -c, --config configfile      - Use configfile instead of ht.cfg");
puts(" -t, --tag tagfile            - Use tagfile as the tag file overriding default"); 
puts(" -h, --help                   - This help");
puts("NB tagfile is only optional when specified in the configuration file ht.cfg");
exit(6);
}
