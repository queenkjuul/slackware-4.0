/*
 * Header file for the config rutines...
 */

#define config "/etc/system.tagrc"
#define MAX 500
#define MAXFILES 20
#define MAXDES 70

char *tagrc;

char *Config(void);
char *homedir(void);

/* where we store all the tagfiles */
char tagpath[100];

/* where we keep our files and description... */
char tagfiles[MAXFILES][MAXDES];
char tagdes[MAXFILES][MAXDES];

/* how much taglines we have? */
int tagcount;

/* As default no random... */
int tagrandom;

/* can i put some credit in the email? */
int credits;

/* do we use crontab for changing taglines? */
char cronfile[MAXFILES][MAXDES];
int croncheck;

/* the function that parses the config file. */
void parse(void);
