/*
 * Linux project for emails with taglines ...
 * 
 * This thing was used on BBSes and i guess it is still used,
 * because it is real fun..
 * 
 * Author: Andrej Bagon
 * 
 * Start date: 10.June.1997
 * Last modified: 11.June.1997
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "tagrc.h" 
#include "tagline.h"
#include "interface.h"

char *reedit(char split[MAX])
{
	char c;
	int i=0,j=0,x=0,blah=80;
       		
	while (x<strlen(split))
	  {
		  c= split[x];
		  if (c == ' ')
		      j=i+x;
		  if ( (j > blah-15) && (j < blah))
		    {
			    split[j]='\n';
			    blah=j+80;
		    }
		  x++;
	  }
       	return split;
}

void main(argc, argv)
int argc;
char *argv[];
{
	FILE *inFile, *tagFile;
	char tagline[MAX];
	int ran,count=1, noumber=0;
	FILE *thirdone;
	char thirds[MAX], thome[MAX];
	
	sprintf(thome,"%s", homedir());
	tagrc=homedir();
	strcat(tagrc,"/.tagrc");
	
	parse();
	if (croncheck && tagrandom)
	  {
		  printf("\nWarning mail from tagline.\n\n Okey you can't run tagline this way.\n\nPlease choose between crontab version or visual mode.\n\n     Check your config file!\n\n                                Crontab checker :)\n");
	  }
	
	if (!croncheck)
	  {
		  if (argc != 2)
		    {
			    printf("Wrong arguments.\nTry %s filename\n", argv[0]);
			    exit(1);
		    }
	  }
	else
	  {
		  argv[1] = thome;
		  strcat(argv[1], "/.signature");
	  }
      	
	strcpy(tagname,tagpath);
	
	if (tagrandom == 0)
	  {
		  strcat(tagname,menu());
	  }
	else
	  {
		  strcat(tagname,tagfiles[time(NULL) % tagcount + 1]);
	  }

	if (croncheck)
	  {
		  thirdone=fopen(cronfile, "r");
		  inFile=fopen(argv[1], "w");
	  }
	else
	  {
		  inFile=fopen(argv[1], "a");
	  }
	tagFile=fopen(tagname, "r");
			  
	do
	  {
		  fgets(tagline,MAX,tagFile);
		  noumber++;
	  }
	while (!feof(tagFile));
	
	rewind(tagFile);
	
	ran=time(NULL) % noumber+1;
	do
	  {
		  fgets(tagline,MAX,tagFile);
		  count++;
	  }
	while (count<ran);
	
	if (croncheck)
	  {
		  do
		    {
			    fgets(thirds,MAX,thirdone);
			    if (!feof(thirdone))
				fputs(thirds, inFile);
		    }
		  while (!feof(thirdone));
		  fclose(thirdone);
	  }
	
	fputs("\n",inFile);
	fputs(reedit(tagline),inFile);
	if(credits)
	  {
		  /* how nice i can put my little credit in here :)*/
		  fputs(" -- tagline 1.00 by xopy",inFile);
	  }	
	fclose(tagFile);
	fclose(inFile);
}
