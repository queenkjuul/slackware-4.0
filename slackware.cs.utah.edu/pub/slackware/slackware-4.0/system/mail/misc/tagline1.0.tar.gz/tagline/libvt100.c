#include <stdio.h>

void beeper(int nbeep)
{
  int x;
     for (x=0; x<nbeep; x++)
     { printf("\007"); fflush(stdout); }
}

void blinkstart()
{
   printf("\033[5m"); fflush(stdout);
}

void boldstart()
{
   printf("\033[1m"); fflush(stdout);
}

void reversestart()
{
   printf("\033[7m"); fflush(stdout);
}

void understart()
{
   printf("\033[4m"); fflush(stdout);
}

void totalend()
{
   printf("\033[0m"); fflush(stdout);
}

void clreol()
{
   printf("\033[0K"); fflush(stdout);
}

void clrscr()
{
   printf("\033[;H\033[2J"); fflush(stdout);
}

void gotoxy(int x, int y)
{
   printf("\033[%d;%dH", y, x); fflush(stdout);
}

