#include "libvt100.h"
#include "interface.h"
#include "tagrc.h"
#include <stdio.h>
#include <string.h>
#include <termios.h>

struct termios old_term;
struct termios new_term;

void writeit(void)
{
	int i;
	
	for(i=0;i<tagcount;i++)
	  {
		  gotoxy((80 / 2) - (strlen(tagdes[i+1]) / 2),3+i);
		  printf("%s",tagdes[i+1]);
	  }
	reversestart();
	for (i=0;i<10;i++)
	  {
		  gotoxy(i*8,1);
		  printf("        ");
	  }
	boldstart();
	gotoxy(10,1);
	printf("tagline 1.00 by Andrej Bagon (andrej.bagon@guest.arnes.si)");
	totalend();
	totalend();
	gotoxy(9,19);
	printf("Up & Down cursors for selecting the taglines file, x to quit");
	
		  
}

void set_raw_term(void)
{
        tcgetattr(0, &old_term);
	new_term = old_term;
	new_term.c_lflag &= ~(ECHO | ICANON);
	new_term.c_cc[VMIN] = 0;
	new_term.c_cc[VTIME] = 10;
	tcsetattr(0, TCSANOW, &new_term);
}

char *menu(void)
{
	int i,y=3,x=1;

	clrscr();
	set_raw_term();
	
	writeit();

	reversestart();
        gotoxy((80 / 2) - (strlen(tagdes[x]) / 2),y);
	printf("%s",tagdes[x]);
	totalend();
	
	do
	  {
		  i = getchar();
		  if ( i == '0')
		      i = getchar();
		  switch (i)
		    {
		    case 65:
			      {
				      if (y <= 3)
					{
						reversestart();
						gotoxy((80 / 2) - (strlen(tagdes[x]) / 2),y);
						printf("%s",tagdes[x]);
						totalend();
					}
				      else
					{
						gotoxy((80 / 2) - (strlen(tagdes[x]) / 2),y);
						printf("%s",tagdes[x]);
						y--;
						x--;
						reversestart();
						gotoxy((80 / 2) - (strlen(tagdes[x]) / 2),y);
						printf("%s",tagdes[x]);
						totalend();
					}
				      break;
			      }
		    case 66:
			      {
				      if (y >= 2+tagcount)
					{
						reversestart();
						gotoxy((80 / 2) - (strlen(tagdes[x]) / 2),y);
						printf("%s",tagdes[x]);
						totalend();
					}
				      else
					{
						gotoxy((80 / 2) - (strlen(tagdes[x]) / 2),y);
						printf("%s",tagdes[x]);
						y++;
						x++;
						reversestart();
						gotoxy((80 / 2) - (strlen(tagdes[x]) / 2),y);
						printf("%s",tagdes[x]);
						totalend();
					}				      
				      break;
			      }
		    case 10:
			      {
				      gotoxy(1,20);
				      tcsetattr(0, TCSANOW, &old_term);
				      return tagfiles[x];
				      break;				      
			      }
		    default:
			      {
				      break;
			      }			    
		    }
	  }
	while ( (i != 'x') && (i != 'X') );
	tcsetattr(0, TCSANOW, &old_term);
	gotoxy(1,20);
	printf("Hmm no tagline this time.. you aborted..\n");
	exit(1);
	return "nothing :)";
}
