/*
 * Okey like all big programs this one needs a config file too..
 * How this file is going to be configured.. hmm I have no idea now..
 * I tagfile and a proggy for catting tagfiles in one.. or this config
 * let get the tagline...
 * 
 * I think i'll get one tag file per one... 
 * lines starting with # will be comments otherwist it is a tagline file :)
 * 
 * Author: Andrej Bagon
 * 
 * Start date: 11.June.1997
 * Last modified: 2.July.1997
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "tagrc.h"
#include "tagline.h"

char *homedir(void)
{
	char *env;
	env = getenv("HOME");
	return env;
}

void parse(void)
{
	FILE *pars;
	char buffer[MAX];
	int counter=1;
	
	pars=fopen(tagrc,"r");
	/* check if we can not open the file.. */
	if (pars == 0)
	  {		  
/*		  printf("No user tagrc file. Trying with global one..\n"); */
		  pars=fopen(config,"r");
		  if (pars == 0)
		    {
			    printf("Okey now we are really in deep shit.. no config file.. bye bye..\n");
			    exit(1);
		    }
	  }
	
/*	printf("Parsing the configuration file...\n"); */
	
	do
	  {
		  fscanf(pars, "%s", buffer); 
		  
		  /* comments */
		  if(buffer[0] == '#')
		    {
			    /* Got to next line */
			    fgets(buffer, MAX, pars);
		    }
		  else
		  /* this is the directory where we store all tagfiles */
		  if(!strcasecmp(buffer, "tagdir"))
		    {
			    fscanf(pars, "%s", buffer);
			    strcpy(tagpath,buffer);
			    fgets(buffer, MAX, pars);
		    }
		  else
		  /* what about if we want random tagline? */
		  if(!strcasecmp(buffer, "random"))
		    {
/*			    printf("Choosing a random tagline for ya...\n"); */
			    tagrandom=1;
			    fgets(buffer, MAX, pars);
		    }
		  else
		  /* if we run tagline via crontab */
		  if (!strcasecmp(buffer, "crontab"))
		    {
/*			    printf("Running tagline from crontab.\n"); */
			    croncheck=1;
			    fscanf(pars, "%s", buffer);
			    strcpy(cronfile,buffer);
			    fgets(buffer, MAX, pars);
		    }
		  else
		  /* can i include mine tagline info in the mail? */
		  if(!strcasecmp(buffer, "credit"))
		    {
/*			    printf("How nice i can include tagline credit in your email :)\n"); */
			    credits=1;
			    fgets(buffer, MAX, pars);
		    }		  
		  /* other should be tagfiles with the description... */
		    {
			    if (buffer[strlen(buffer)-1] != 10)
			      {
				      strcpy(tagfiles[counter],buffer);
				      fgets(buffer, MAX, pars);
				      strcpy(tagdes[counter],buffer);
				      tagcount=counter;
				      counter++;
			      }			    
		    }
	  }
	while (!feof(pars));
	fclose(pars);
}
