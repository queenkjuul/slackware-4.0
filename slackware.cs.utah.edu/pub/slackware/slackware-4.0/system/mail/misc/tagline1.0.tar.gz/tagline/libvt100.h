void beeper(int nbeep);
void blinkstart();
void boldstart();
void reversestart();
void understart();
void totalend();
void clreol();
void clrscr();
void gotoxy(int x, int y);

