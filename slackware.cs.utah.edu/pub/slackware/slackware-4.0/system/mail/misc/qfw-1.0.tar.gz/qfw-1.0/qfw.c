/*
 * inject.c 
 * Version 1.0
 *
 * (C) 1996 Emanuele Pucciarelli <emanuele@debian.org>
 * This file is distributed under the GNU General Public License.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define CFGFILENAME 	".qfwrc"
#define MAXCFGLINESIZE	256
#define MAXFNAMESIZE	256
#define MAXHDRSIZE	1024
#define MAXADDRSIZE	256
#define BUFSIZE		8192
#define INJECTPROGRAM	"/var/qmail/bin/qmail-inject"

struct matchtable {
	char *domain;
	char *mailuser;
	char *mailhost;
	struct matchtable *next;
};

struct hdrtable {
	char *header;
	struct hdrtable *next;
};

struct matchtable *firstmatch = 0;
struct hdrtable *firsthdr = 0;

struct matchtable **cursor;
struct hdrtable **hdrc;

void stracpy(char **dest, char *src)
{
	(*dest) = malloc(strlen(src)+1);
	strcpy(*dest, src);
}

void fatal_parseerror (int linecount)
{
	fprintf (stderr, "Fatal: parsing error at line %d of %s", linecount,
		 CFGFILENAME);
	fflush (stderr);
	exit (1);
}

void fatal_cantread ()
{
	fprintf (stderr, "Fatal: cannot read from %s", CFGFILENAME);
	fflush (stderr);
	exit (1);
}

void addvalues(char *domain, 
	       char *mailuser, char *mailhost)
{
	if (!firstmatch)
		cursor = &firstmatch;

	*cursor = malloc(sizeof(struct matchtable));
	stracpy (&((*cursor)->domain), domain);
	stracpy (&((*cursor)->mailuser), mailuser);
	stracpy (&((*cursor)->mailhost), mailhost);
	(*cursor)->next = 0;
	cursor = &((*cursor)->next);
}

void storeheader(char *header)
{
	if (!firsthdr)
		hdrc = &firsthdr;

	*hdrc = malloc(sizeof(struct hdrtable));
	stracpy(&((*hdrc)->header), header);
	(*hdrc)->next = 0;
	hdrc = &((*hdrc)->next);
}

void readline(char *line, int linecount, struct matchtable **cursor)
{
	char domain[80] = "", mailuser[80], mailhost[256], *ptr;

	if ( (sscanf (line, "%s%s%s", domain, mailuser, mailhost) != 3)
	    && (*domain != '#'))
		fatal_parseerror(linecount);
	if (*domain != '#')
		addvalues(domain, mailuser, mailhost);
}

void change_info(struct matchtable *mptr)
{
	if (strcmp(mptr->mailuser, "-"))
		setenv("MAILUSER", mptr->mailuser, 1);
	if (strcmp(mptr->mailhost, "-"))
		setenv("MAILHOST", mptr->mailhost, 1);
}

int main(int argc, char *argv[])
{
	char filename[MAXFNAMESIZE];
	char string[MAXCFGLINESIZE];
	FILE *cfgfile, *pipe;
	int linecount, i, rb;
	struct matchtable *mptr = 0;
	char header[MAXHDRSIZE], *hdrdata;	
	char address[MAXADDRSIZE];
	char arguments[256];
	char buffer[BUFSIZE];

	/* Open the config file. */
	strcpy (filename, getenv("HOME"));
	strcat (filename, "/");
	strcat (filename, CFGFILENAME);
	if (! (cfgfile = fopen (filename, "r"))) {
		perror("Can't read cfg file");
		exit(1);
	}
	
	/* Read it in. If a line begins with a hash, it's a comment. */
	while (!feof (cfgfile)) {
		if (fgets (string, MAXCFGLINESIZE, cfgfile)) {
			readline(string, ++linecount, &mptr);
		} else {
			if (!feof (cfgfile)) fatal_cantread();
		}
	}

	/* Now close. */
	fclose(cfgfile);

	/* Read headers, until To: is reached. */
	do {
		if (!fgets(header, MAXHDRSIZE, stdin))
			exit(1);
		if (strncmp(header, "From: ", 6))
			storeheader(header);
		if (*header == '\n')
			exit(1);
	} while (strncmp (header, "To: ", 4));
	hdrdata = header + 4;

	/* Now we have To: in header. Parse it. Ugly hack :-( */

	/* Case 1: we have '<>'. Use address between '<' and '>'. */
	if (strchr (hdrdata, '<') && strchr (hdrdata, '>')) {
		while (*hdrdata != '<') hdrdata++;
		sscanf(hdrdata, "<%s>", address);
	} else {

	/* Case 2: we take first string. */
		sscanf(hdrdata, "%s", address);
	}
	
	/* Chop '>', if any. */
	if (address[strlen(address)-1] == '>')
		address[strlen(address)-1] = 0;
	
	/* Scan matchtable; on match, setup environment and break. */
	mptr = firstmatch;
	while (mptr) {
		char *ptr;
		ptr = address + strlen(address) - strlen(mptr->domain);
		if ( (ptr >= address) && (!strcmp (ptr, mptr->domain))) {
			change_info(mptr);
			break;
		}
		mptr = mptr->next;
	}

	/* Assemble command line. */
	strcpy(arguments, INJECTPROGRAM);
	i = 0;
	while(argv[++i]) {
		strcpy(arguments, " \"");
		strcpy(arguments, argv[i]);
		strcpy(arguments, "\"");
	}

	/* Open a pipe to the inject program. */
	if (!(pipe = popen(INJECTPROGRAM, "w"))) {
		perror("Can't open pipe to qmail-inject");
		exit(1);
	}

	/* Print collected headers to pipe. */
	hdrc = &firsthdr;
	while (*hdrc) {
		fputs((*hdrc)->header, pipe);
		hdrc = &((*hdrc)->next);
	}

	/* Print all the rest to pipe. */

	while (rb = fread (buffer, 1, BUFSIZE, stdin)) {
		fwrite(buffer, rb, 1, pipe);
	}
	exit(pclose(pipe));
}

