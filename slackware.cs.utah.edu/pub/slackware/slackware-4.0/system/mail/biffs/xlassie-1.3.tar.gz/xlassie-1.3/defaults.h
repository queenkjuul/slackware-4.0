/* Default settings */

/* You can change the default colors by editing the source code, they are
 * near the beginning and should be pretty obvious */


/****************************************************************************/

/* Support for getting mail from a POP3 server.  Use the -pop3 option to give
 * the server name, the -password option for the password, and the -usename
 * option if the usename is different than the local one.  The password
 * argument will be overwritten so it doesn't show up in a "ps".  Even if you
 * compile in POP3 support, it is still possible to use a local mail spool. */

#define POP3

/****************************************************************************/

/* Make offline mode the default.  Offline mode is usefull if you have a
 * dialup connection to the internet.  XLassie will display an "X" instead of
 * a number if it is unable to contact the POP3 server.  */

/* #define OFFLINE_DEFAULT */

/****************************************************************************/
/* Interval between checks for new mail, the default is 5 seconds for a local
 * file and 60 seconds for a POP3 server */

#define INTERVAL_POP3	60   /* POP3 default */
#define INTERVAL_SPOOL	5	/* Spool file default */

/****************************************************************************/

/* Default command to run when the window is clicked on.  The command will get
 * executed via system() which means you can use shell contructs.  The command
 * should be placed in the background or xlassie will be frozen untill it
 * completes. */

/* run pine in an xterm */
#define COMMAND	"rxvt +sb -T pine -e pine &"

/* fetch mail from pop server */
/* #define COMMAND "fetchpop -r &" */

/* fetch pop mail, then run pine */
/* #define COMMAND "(fetchpop -r ; rxvt -e pine) &" */

/****************************************************************************/

/* Default font for the display.  You can use xfontsel to try and find some
 * nice fonts on your system.  I would suggest using a scalable font. */

#define FONTNAME "-*-utopia-medium-r-normal--40-*-*-*-*-*-iso8859-1"

/*                   ^font^                  ^^ size in pixels */

/****************************************************************************/
