
#ifdef X_SUPPORT

#include <stdlib.h>
#include <fcntl.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <linux/kd.h>
#include "config.h"
#include "mailleds.h"

extern Display *dpy;
extern int x_leds[3];

void get_X_leds_from_kbd_leds(leds)
int leds;
{
	int i = 0;
	if (leds & LED_CAP)
		x_leds[i++] = X_CAP;
	if (leds & LED_NUM)
		x_leds[i++] = X_NUM;
	if (leds & LED_SCR)
		x_leds[i++] = X_SCR;
	x_leds[i] = 0;
}

#endif				/* X_SUPPORT */
