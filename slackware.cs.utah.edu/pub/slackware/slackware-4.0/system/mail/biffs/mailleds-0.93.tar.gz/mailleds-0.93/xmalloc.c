












#include <stdlib.h>		/* for NULL */

void *xmalloc(bytes)
int bytes;
{
	void *vp;

	vp = malloc(bytes);
	if (vp == NULL && bytes > 0) {
		perror("malloc failed");
		exit(-1);
	}
	return vp;
}
