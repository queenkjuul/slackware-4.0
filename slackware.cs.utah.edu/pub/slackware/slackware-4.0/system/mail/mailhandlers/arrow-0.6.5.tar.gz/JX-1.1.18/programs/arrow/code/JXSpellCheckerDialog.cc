/******************************************************************************
 JXSpellCheckerDialog.cc

	BASE CLASS = JXDialogDirector

	Copyright @ 1997 by Glenn W. Bach.

 ******************************************************************************/

#include "JXSpellCheckerDialog.h"

#include <JXWindow.h>
#include <JXTextButton.h>
#include <JXStringInput.h>
#include <JXStaticText.h>
#include <JXSpellList.h>
#include <JXScrollbarSet.h>
#include <JXColormap.h>

#include <JString.h>

#include <jXGlobals.h>

#include <jAssert.h>

/******************************************************************************
 Constructor

 ******************************************************************************/

JXSpellCheckerDialog::JXSpellCheckerDialog
	(
	JXDirector* supervisor
	)
	:
	JXDialogDirector(supervisor, kTrue)
{
	BuildWindow();
}

/******************************************************************************
 Destructor

 ******************************************************************************/

JXSpellCheckerDialog::~JXSpellCheckerDialog()
{
}

/******************************************************************************
 BuildWindow (private)

 ******************************************************************************/

void
JXSpellCheckerDialog::BuildWindow()
{
	
// begin JXLayout

    JXWindow* window = new JXWindow(this, 535,270, "Spelling");
    assert( window != NULL );
    SetWindow(window);

    JXStaticText* obj1 =
        new JXStaticText("Not in Dictionary:", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 15,15, 105,20);
    assert( obj1 != NULL );

    JXStaticText* obj2 =
        new JXStaticText("Change To:", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 15,48, 90,20);
    assert( obj2 != NULL );

    JXStaticText* obj3 =
        new JXStaticText("Suggestions:", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 15,78, 90,20);
    assert( obj3 != NULL );

    itsCheckText =
        new JXStaticText("", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 130,15, 280,20);
    assert( itsCheckText != NULL );

    itsIgnoreButton =
        new JXTextButton("Ignore", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 350,60, 75,20);
    assert( itsIgnoreButton != NULL );
    itsIgnoreButton->SetShortcuts("^M");
    ListenTo(itsIgnoreButton);

    itsChangeButton =
        new JXTextButton("Change", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 350,90, 75,20);
    assert( itsChangeButton != NULL );
    ListenTo(itsChangeButton);

    itsLearnButton =
        new JXTextButton("Learn word", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 350,130, 165,20);
    assert( itsLearnButton != NULL );
    ListenTo(itsLearnButton);

    itsLearnCapsButton =
        new JXTextButton("Learn word with caps", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 350,160, 165,20);
    assert( itsLearnCapsButton != NULL );
    ListenTo(itsLearnCapsButton);

    itsIgnoreAllButton =
        new JXTextButton("Ignore All", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 440,60, 75,20);
    assert( itsIgnoreAllButton != NULL );
    ListenTo(itsIgnoreAllButton);

    itsChangeAllButton =
        new JXTextButton("Change All", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 440,90, 75,20);
    assert( itsChangeAllButton != NULL );
    ListenTo(itsChangeAllButton);

    JXTextButton* cancelButton =
        new JXTextButton("Close", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 440,235, 75,20);
    assert( cancelButton != NULL );
    cancelButton->SetShortcuts("^[");

	itsFirstGuess =
        new JXStringInput(window, 
        	JXWidget::kHElastic, JXWidget::kVElastic, 105,45, 230,20);
    assert( itsFirstGuess != NULL );

	JXScrollbarSet* set = 
		new JXScrollbarSet(window, 
        	JXWidget::kHElastic, JXWidget::kVElastic, 105,75, 230,180);
    assert(set != NULL);

	itsSuggestions =
        new JXSpellList(set, set->GetScrollEnclosure(), 
        	JXWidget::kHElastic, JXWidget::kVElastic, 0,0, 230,180);
    assert( itsSuggestions != NULL );
    ListenTo(itsSuggestions);

// end JXLayout

	SetButtons(itsIgnoreButton, cancelButton);
	itsFirstGuess->SetBackColor(JGetCurrColormap()->GetWhiteColor());
	ListenTo(itsFirstGuess);
	itsCheckText->SetCurrentFontBold(kTrue);
	itsCheckText->SetDefaultFontStyle(JFontStyle(kTrue, kFalse, 0, kFalse));
}

/******************************************************************************
 Receive 

 ******************************************************************************/

void
JXSpellCheckerDialog::Receive
	(
	JBroadcaster* 	sender, 
	const Message&	message
	)
{
	if (sender == itsSuggestions && message.Is(JXSpellList::kChoiceSelected))
		{
		JXSpellList::ChoiceSelected* choice = 
			dynamic_cast(JXSpellList::ChoiceSelected*, &message);
		assert(choice != NULL);
		JIndex index = choice->GetIndex();
		const JPtrArray<JString>& words = itsSuggestions->GetStringList();
		JString guess = *(words.NthElement(index));
		itsFirstGuess->SetString(guess);
		itsFirstGuess->Focus();
		itsIgnoreButton->SetShortcuts("");
		itsChangeButton->SetShortcuts("^M");
		}
	else if (sender == itsFirstGuess && message.Is(JTextEditor::kTextChanged))
		{
		itsIgnoreButton->SetShortcuts("");
		itsChangeButton->SetShortcuts("^M");
		}
	if (message.Is(JXButton::kPushed))
		{
		if (sender == itsIgnoreButton)
			{
			itsCurrentAction = kIgnore;
			JXDialogDirector::Receive(sender, message);
			}
		else if (sender == itsChangeButton)
			{
			itsCurrentAction = kChange;
			EndDialog(kTrue);
			}
		else if (sender == itsLearnButton)
			{
			itsCurrentAction = kLearn;
			EndDialog(kTrue);
			}
		else if (sender == itsLearnCapsButton)
			{
			itsCurrentAction = kLearnCaps;
			EndDialog(kTrue);
			}
		else if (sender == itsIgnoreAllButton)
			{
			itsCurrentAction = kIgnoreAll;
			EndDialog(kTrue);
			}
		else if (sender == itsChangeAllButton)
			{
			itsCurrentAction = kChangeAll;
			EndDialog(kTrue);
			}
		else
			{
			JXDialogDirector::Receive(sender, message);
			}
		}
}

/******************************************************************************
 GetCorrection 

 ******************************************************************************/

const JString& 
JXSpellCheckerDialog::GetCorrection()
{
	return itsFirstGuess->GetString();
}

/******************************************************************************
 GetCheckWord 

 ******************************************************************************/

const JString& 
JXSpellCheckerDialog::GetCheckWord()
{
	return itsCheckText->GetText();
}

/******************************************************************************
 GetSpellAction 

 ******************************************************************************/

JXSpellCheckerDialog::SpellAction
JXSpellCheckerDialog::GetSpellAction()
{
	return itsCurrentAction;
}

/******************************************************************************
 SetCheckWord 

 ******************************************************************************/

void
JXSpellCheckerDialog::SetCheckWord
	(
	const JCharacter* word
	)
{
	itsCheckText->SetText(word);
}

/******************************************************************************
 SetFirstGuess 

 ******************************************************************************/

void
JXSpellCheckerDialog::SetFirstGuess
	(
	const JCharacter* word
	)
{
	itsFirstGuess->SetString(word);
}

/******************************************************************************
 SetSuggestions 

 ******************************************************************************/

void
JXSpellCheckerDialog::SetSuggestions
	(
	const JPtrArray<JString>* words
	)
{
	itsSuggestions->SetStringList(words);
}
