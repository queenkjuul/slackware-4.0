/******************************************************************************
 GMGlobals.cc

	Access to testjx global objects and factories.

	Written by Glenn W. Bach.

 ******************************************************************************/

#include "GMGlobals.h"
#include "GMApp.h"
#include "SMTPDebugDir.h"
#include "GAddressBookMgr.h"
#include "GPrefsMgr.h"
#include "GInboxMgr.h"
#include "GHelpText.h"
#include "ClipDir.h"
#include "JXSRFullDialog.h"

#include <JXWindow.h>

#include <JUserNotification.h>
#include <JUNIXDirEntry.h>
#include <JInPipeStream.h>
#include <JRegex.h>

#include <jProcessUtil.h>
#include <jStreamUtil.h>
#include <jDirUtil.h>
#include <jFileUtil.h>
#include <jTime.h>

#include <unistd.h>
#include <stdlib.h>
#include <jAssert.h>

static GMApp*				theApplication 		= NULL;		// owns itself
static SMTPDebugDir*		itsDebugDir;
static JBoolean 			itsPGPEnabled;
static GAddressBookMgr* 	itsAddressBookMgr 	= NULL;
static GPrefsMgr*			itsPrefsMgr			= NULL;
static GInboxMgr*			itsInboxMgr			= NULL;
static JBoolean 			itsProgramIsDying	= kFalse;
static JBoolean				itsSpellCheckEnabled;
static JXTextClipboard*		theTextClipboard    = NULL;
static JXSRTextDialogBase*	itsDialog			= NULL;

/******************************************************************************
 GMCreateGlobals

	server can be NULL

 ******************************************************************************/

JBoolean
GMCreateGlobals
	(
	GMApp*		app
	)
{
	theApplication = app;
	
	itsAddressBookMgr = new GAddressBookMgr();
	assert(itsAddressBookMgr != NULL);

	itsPGPEnabled = kTrue;

	JBoolean isNew;
	itsPrefsMgr = new GPrefsMgr(&isNew);
	assert(itsPrefsMgr != NULL);

	itsInboxMgr = new GInboxMgr();
	assert(itsInboxMgr != NULL);

	GCheckPGP();

	itsSpellCheckEnabled = JProgramOnPath("ispell");

	JXInitHelp(kOverviewHelpName, kHelpSectionCount,
			   kHelpSectionName, kHelpSectionTitle, kHelpSectionText,
			   JXMenu::kMacintoshStyle);

	ClipDir* dir = new ClipDir(app);
	assert(dir != NULL);

	theTextClipboard = new JXTextClipboard(kFalse, dir->GetWindow());
	assert( theTextClipboard != NULL );

	itsDialog = new JXSRFullDialog(app);
	assert(itsDialog != NULL);

	itsPrefsMgr->ReadFindDialogPrefs(itsDialog);
	itsPrefsMgr->ReadChooseSaveDialogPrefs();
	
	return isNew;	
}

/******************************************************************************
 GMDeleteGlobals

 ******************************************************************************/

void
GMDeleteGlobals()
{	
	itsPrefsMgr->WriteChooseSaveDialogPrefs();
	theApplication = NULL;
	delete itsInboxMgr;
	delete itsPrefsMgr;
	delete itsAddressBookMgr;
}

/******************************************************************************
 GMGetApplication

 ******************************************************************************/

GMApp*
GMGetApplication()
{
	assert( theApplication != NULL );
	return theApplication;
}

/******************************************************************************
 GGetPrefsMgr

 ******************************************************************************/

GPrefsMgr*
GGetPrefsMgr()
{
	assert(itsPrefsMgr != NULL);
	return itsPrefsMgr;
}

/******************************************************************************
 GGetInboxMgr

 ******************************************************************************/

GInboxMgr*
GGetInboxMgr()
{
	assert(itsInboxMgr != NULL);
	return itsInboxMgr;
}

/******************************************************************************
 SetSMTPDebugDir

 ******************************************************************************/

void
GMSetSMTPDebugDir
	(
	SMTPDebugDir* dir
	)
{
	itsDebugDir = dir;
}

/******************************************************************************
 GMGetSMTPDebugDir

 ******************************************************************************/

SMTPDebugDir*
GMGetSMTPDebugDir()
{
	assert( itsDebugDir != NULL );
	return itsDebugDir;
}

/******************************************************************************
 GGetAddressBookMgr


 ******************************************************************************/

GAddressBookMgr* 
GGetAddressBookMgr()
{
	assert(itsAddressBookMgr != NULL);
	return itsAddressBookMgr;
}

/******************************************************************************
 GPGPEnabled


 ******************************************************************************/

JBoolean 
GPGPEnabled()
{
	return itsPGPEnabled;
}

/******************************************************************************
 GSpellCheckEnabled


 ******************************************************************************/

JBoolean 
GSpellCheckEnabled()
{
	return itsSpellCheckEnabled;
}

/******************************************************************************
 GCheckPGP


 ******************************************************************************/

void
GCheckPGP()
{
	if (!JProgramOnPath("pgp"))
		{
		itsPGPEnabled = kFalse;
		return;
		}
	JString sysCmd = "pgp -kv";
	int inFD;
	JError err = 
		JExecute(sysCmd, NULL,
			kJIgnoreConnection, NULL,
			kJCreatePipe, &inFD,
			kJTossOutput, NULL);
	if (err.OK())
		{
		JInPipeStream is(inFD, kTrue);
		if (is.peek())
			{
			JString buffer;
			JReadAll(is, &buffer);
			JRegex regex;
			JBoolean matched;
			JArray<JIndexRange> subList;
			err = regex.SetPattern("([0-9]+) matching key[s]* found");
			assert(err.OK());
			matched = regex.Match(buffer, &subList);
			if (matched)
				{
				JIndexRange sRange = subList.GetElement(2);
				JString number = buffer.GetSubstring(sRange);
				if (number == "0")
					{
					itsPGPEnabled = kTrue;
					}
				}
			else
				{
				itsPGPEnabled = kFalse;
				}
			}
		else
			{
			itsPGPEnabled = kFalse;
			}
		}
	else
		{
		itsPGPEnabled = kFalse;
		}
}

/******************************************************************************
 GBlockUntilFileUnlocked


 ******************************************************************************/

void
GBlockUntilFileUnlocked
	(
	const JCharacter* filename
	)
{
	GMGetApplication()->DisplayBusyCursor();
	JString lockfile = JString(filename) + ".lock";
	if (!JFileExists(lockfile))
		{
		return;
		}
	JString report = "The file \"" + JString(filename) + "\" is locked. Waiting for the file to be unlocked.";
	if (!itsProgramIsDying)
		{
		JGetUserNotification()->ReportError(report);
		}
	for (JSize count = 1; count <= 60; count++)
		{
		JWait(5);
		if (!JFileExists(lockfile))
			{
			return;
			}
		}
	JRemoveFile(lockfile);
}

/******************************************************************************
 GLockFile


 ******************************************************************************/

JBoolean
GLockFile
	(
	const JCharacter* filename
	)
{
	JString lockfile = JString(filename) + ".lock";
	ofstream os(lockfile, ios::out, 0444);
	if (!os.good())
		{
		JString report = "I was unable to lock the mailbox \"" + 
						 JString(filename) +
						 "\", so I won't be able to save your changes.";
		JGetUserNotification()->ReportError(report);
		return kFalse;
		}
	return kTrue;
}

/******************************************************************************
 GFileLocked


 ******************************************************************************/

JBoolean
GFileLocked
	(
	const JCharacter* filename
	)
{
	JString lockfile = JString(filename) + ".lock";
	if (JFileExists(lockfile))
		{
		return kTrue;
		}
	return kFalse;
}

/******************************************************************************
 GUnlockFile


 ******************************************************************************/

void
GUnlockFile
	(
	const JCharacter* filename
	)
{
	JString lockfile = JString(filename) + ".lock";
	JRemoveFile(lockfile);
}

/******************************************************************************
 GProgramIsDying


 ******************************************************************************/

JBoolean 
GProgramIsDying()
{
	return itsProgramIsDying;
}

/******************************************************************************
 GSetProgramDying


 ******************************************************************************/

void 
GSetProgramDying()
{
	itsProgramIsDying = kTrue;
}

/******************************************************************************
 GQuoteString

 ******************************************************************************/

void
GQuoteString
	(
	JString* 		text,
	const JBoolean 	quoteFirst
	)
{
	if (quoteFirst)
		{
		if (text->IndexValid(1))
			{
			if (text->GetCharacter(1) == '>')
				{
				text->InsertSubstring(">", 1);
				}
			else
				{
				text->InsertSubstring("> ", 1);
				}
			}
		}
	JIndex index = 1;
	while (text->IndexValid(index) && text->LocateNextSubstring("\n", &index))
		{
		if (text->IndexValid(index + 1))
			{
			if (text->GetCharacter(index+1) == '>')
				{
				text->InsertSubstring(">", index+1);
				}
			else if (text->GetCharacter(index+1) == '\n')
				{
				text->InsertSubstring(">", index+1);
				}
			else
				{
				text->InsertSubstring("> ", index+1);
				}
			}
		index ++;
		}

}

/******************************************************************************
 GMGetTextClipboard

 ******************************************************************************/

JXTextClipboard*
GMGetTextClipboard()
{
	assert( theTextClipboard != NULL );
	return theTextClipboard;
}

/******************************************************************************
 GMUpdateTextClipboard

 ******************************************************************************/

void
GMUpdateTextClipboard()
{
	assert( theTextClipboard != NULL );
	theTextClipboard->UpdateClipboard();
}

/******************************************************************************
 GCheckMail

 ******************************************************************************/

void
GCheckMail()
{
	theApplication->CheckMail();
}

/******************************************************************************
 GCheckMail

 ******************************************************************************/

JXSRTextDialogBase*
GetSearchDialog()
{
	assert(itsDialog != NULL);
	return itsDialog;
}
