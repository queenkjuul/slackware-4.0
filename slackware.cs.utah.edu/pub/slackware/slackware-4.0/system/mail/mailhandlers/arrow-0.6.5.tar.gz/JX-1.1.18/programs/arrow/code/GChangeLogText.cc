/******************************************************************************
 GChangeLogText.cc

	Copyright � 1998 by Glenn Bach. All rights reserved.

 ******************************************************************************/

#include "GHelpText.h"

const JCharacter* kChangeLogName  = "GChangeLog";
const JCharacter* kChangeLogTitle = "Changes from previous versions";

const JCharacter* kChangeLogText =

"Please send all bug reports and suggestions for features to Glenn Bach."
"<p>"
"glenn@cco.caltech.edu"
"<p>"
"----------"
"<p>"
"<b>0.6.5</b>"
"<p>"
"The STMP routines weren't 822bis compliant. I was sending LF instead of "
"CR LF. This should now be ok.<p>"
"Arrow now saves the prefs for the open dialog box."
"<p>"
"<p>"
"<b>0.6.4</b>"
"<p>"
"Fixed a lock file bug."
"<p>"
"<b>0.6.3</b>"
"<p>"
"Fixed a bug that caused a problem in drag-and-drop for a very specific case."
"<p>"
"<b>0.6.2</b>"
"<p>"
"I missed a JX change that killed the spell checker for version 0.6. "
"It should work now."
"<p>"
"<b>0.6.1</b>"
"<p>"
"Fixed a bug that caused Arrow to crash on startup for some systems."
"<p>"
"<b>0.6</b>"
"<p>"
"Access mail on POP servers - supports APOP.<p>"
"Text search in view and edit windows.<p>"
"The <i>Inbox</i> menu is no longer a sub-menu, but is now on the menu bar.<p>"
"European keyboards are now supported.<p>"
"Will not open mailboxes when a lock file can't be created.<p>"
"Preference to allow automatic insertion of reply text.<p>"
"Added <i>SMTP User</i> preference which is needed for some servers.<p>"
"<p>"
"<b>0.5</b>"
"<p>"
"initial release"
;
