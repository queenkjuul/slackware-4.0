/******************************************************************************
 GMailPrefsDialog.h

	Interface for the GMailPrefsDialog class

	Copyright @ 1997 by Glenn W. Bach.

 ******************************************************************************/

#ifndef _H_GMailPrefsDialog
#define _H_GMailPrefsDialog

#include <JXDialogDirector.h>

class JXTextButton;
class JXStringInput;
class JXTextCheckbox;
class JXStaticText;
class JString;
class JXIntegerInput;

class GMailPrefsDialog : public JXDialogDirector
{
public:

	GMailPrefsDialog(JXDirector* supervisor,
						const JString& inbox,
						const JString& smtp,
						const JString& smtpuser,
						const JBoolean showstate,
						const JString& pop,
						const JString& account,
						const JBoolean usePop,
						const JBoolean leave,
						const JBoolean save,
						const JBoolean useAPop,
						const JBoolean autoQuote,
						const JBoolean autoCheck, 
						const JInteger minutes);

	virtual ~GMailPrefsDialog();

	void	GetValues(JString* inbox,
						JString* 	smtp,
						JString* 	smtpuser,
						JBoolean* 	showstate,
						JString* 	pop,
						JString* 	account,
						JBoolean* 	usePop,
						JBoolean* 	leave,
						JBoolean* 	save,
						JBoolean* 	useAPop,
						JBoolean* 	autoQuote,
						JBoolean* 	autoCheck,
						JInteger*	minutes);
	
protected:
	
	virtual void	Receive(JBroadcaster* sender, const Message& message);

private:

// begin JXLayout

    JXTextButton*   itsChooseInboxButton;
    JXStringInput*  itsSMTPServerInput;
    JXStringInput*  itsPopServerInput;
    JXTextCheckbox* itsUsePopButton;
    JXTextCheckbox* itsLeaveMailButton;
    JXTextCheckbox* itsSavePasswdButton;
    JXStringInput*  itsPopAccountInput;
    JXStaticText*   itsInboxText;
    JXTextCheckbox* itsShowStateInTitle;
    JXTextCheckbox* itsAutoQuote;
    JXTextCheckbox* itsUseAPop;
    JXTextCheckbox* itsAutoCheckMail;
    JXIntegerInput* itsCheckMailDelay;
    JXStringInput*  itsSMTPUserName;

// end JXLayout

private:

	void	BuildWindow(const JString& inbox,
						const JString& smtp,
						const JString& smtpuser,
						const JBoolean showstate,
						const JString& pop,
						const JString& account,
						const JBoolean usePop,
						const JBoolean leave,
						const JBoolean savepasswd,
						const JBoolean useAPop,
						const JBoolean autoQuote,
						const JBoolean autoCheck,
						const JInteger minutes);

	// not allowed

	GMailPrefsDialog(const GMailPrefsDialog& source);
	const GMailPrefsDialog& operator=(const GMailPrefsDialog& source);
};

#endif
