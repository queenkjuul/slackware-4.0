/******************************************************************************
 gMailUtils.h

	Copyright � 1997 by Glenn W. Bach.  All rights reserved.
	
 *****************************************************************************/

#ifndef _H_gMailUtils
#define _H_gMailUtils

#include <JString.h>
#include <JPtrArray.h>
#include <jTypes.h>
#include <iostream.h>

void GParseNameLists(const JString& to, const JString& cc, const JString& bcc,
					JPtrArray<JString>& tos, JPtrArray<JString>& ccs,
					JPtrArray<JString>& bccs);

void GParseNameLists(const JString& to, const JString& cc, const JString& bcc,
					JPtrArray<JString>& names);

void GParseNameList(const JString& list,	
					JPtrArray<JString>& names,
					const JBoolean forName = kFalse);
void GGetRealNames(const JString& list,	JPtrArray<JString>& names);

JBoolean GVerifyPGPNames(const JPtrArray<JString>& names);

JString GGetAddress(const JString& fullname);
JString GGetName(const JString& fullname);
void	GSplitAddressAndName(const JString& fullname, JString* address, JString* name);
void	GFixHeaderForReply(JString* sub);
void	GCompressWhitespace(JString* sub);

void	GReadQuote(istream& is, JString* str);
void	GReadComment(istream& is, JString* str);
void	GReadBracket(istream& is, JString* str);

#endif