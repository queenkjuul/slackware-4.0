/******************************************************************************
 GAddressBookMgr.cc


	Copyright � 1998 by Glenn W. Bach. All rights reserved.

 ******************************************************************************/

#include "GAddressBookMgr.h"
#include "GAddressBookEntry.h"

#include <jXGlobals.h>

#include <jStreamUtil.h>
#include <jDirUtil.h>

#include <X11/keysym.h>
#include <stdio.h>
#include <strstream.h>
#include <fstream.h>
#include <iostream.h>
#include <jAssert.h>

/*****************************************************************************
 Constructor

 *****************************************************************************/

GAddressBookMgr::GAddressBookMgr()
	:
	JBroadcaster()
{
	itsAddresses = new JStringPtrMap<GAddressBookEntry>;
	assert(itsAddresses != NULL);
	JString homeDir;
	if (JGetHomeDirectory(&homeDir))
		{
		JAppendDirSeparator(&homeDir);
		JString addfile = homeDir + ".addressbook";
		ifstream is(addfile);
		while (is.good())
			{
			JString line = JReadLine(is);
			GAddressBookEntry* entry = new GAddressBookEntry();
			assert(entry != NULL);
			JString name;
			if (GetNextRecord(line, name, is))
				{
				GetNextRecord(line, entry->fullname, is);
				if (GetNextRecord(line, entry->address, is))
					{
					GetNextRecord(line, entry->fcc, is);
					GetNextRecord(line, entry->comment, is);
					itsAddresses->SetElement(name, entry);
					}
				}
			}
		}
}

/*****************************************************************************
 Destructor

 *****************************************************************************/

GAddressBookMgr::~GAddressBookMgr()
{
	itsAddresses->DeleteAll();
	delete itsAddresses;
}

/*****************************************************************************
 NameIsAlias

 *****************************************************************************/

JBoolean
GAddressBookMgr::NameIsAlias
	(
	const JCharacter* 	name, 
	JString& 			alias, 
	JString& 			fcc
	)
{
	GAddressBookEntry* entry;
	if (itsAddresses->GetElement(name, &entry))
		{
		alias = entry->address;
		if (alias.IsEmpty())
			{
			return kFalse;
			}
		if (alias.GetFirstCharacter() == '(')
			{
			if (entry->address.GetLength() > 2)
				{
				alias = entry->address.GetSubstring(2, entry->address.GetLength() - 1);
				}
			}
		fcc = entry->fcc;
		if (!fcc.IsEmpty() && (fcc.GetFirstCharacter() == '('))
			{
			if (entry->fcc.GetLength() > 2)
				{
				fcc = entry->fcc.GetSubstring(2, entry->fcc.GetLength() - 1);
				}
			}
		return kTrue;
		}
	return kFalse;
}

/*****************************************************************************
 GetNextRecord

 *****************************************************************************/

JBoolean
GAddressBookMgr::GetNextRecord
	(
	JString& line, 
	JString& record, 
	istream& is
	)
{
	if (line.IsEmpty())
		{
		return kFalse;
		}
	JIndex index;
	if (line.LocateSubstring("\t", &index))
		{
		if (index > 1)
			{
			record = line.GetSubstring(1, index - 1);
			line.RemoveSubstring(1, index);
			return kTrue;
			}
		line.RemoveSubstring(1, 1);
		return kFalse;
		}
	record = line;
	if (record.Contains("(") && !record.Contains(")"))
		{
		JString temp = JReadUntil(is, ')');
		record += temp + ")";
		}
	line.Clear();
	return kTrue;
}