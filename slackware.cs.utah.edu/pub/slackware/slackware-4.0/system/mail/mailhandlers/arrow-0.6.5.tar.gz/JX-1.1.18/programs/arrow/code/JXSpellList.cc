/******************************************************************************
 JXSpellList.cc

	BASE CLASS = JXDialogDirector

	Copyright @ 1997 by Glenn W. Bach.

 ******************************************************************************/

#include "JXSpellList.h"

#include <JXColormap.h>

#include <JTableSelection.h>

#include <jXGlobals.h>

#include <jAssert.h>

const JCharacter* JXSpellList::kChoiceSelected = "JXSpellList::kChoiceSelected";

/******************************************************************************
 Constructor

 ******************************************************************************/

JXSpellList::JXSpellList
	(
	JXScrollbarSet* 	scrollbarSet, 
	JXContainer* 		enclosure,
	const HSizingOption hSizing, 
	const VSizingOption vSizing,
	const JCoordinate 	x, 
	const JCoordinate 	y,
	const JCoordinate 	w, 
	const JCoordinate 	h
	)
	:
	JXStringList(scrollbarSet, enclosure, hSizing, vSizing, x, y, w, h)
{
	SetFont(JGetDefaultFontName(), 12);
	SetBackColor(JGetCurrColormap()->GetWhiteColor());
}

/******************************************************************************
 Destructor

 ******************************************************************************/

JXSpellList::~JXSpellList()
{
}

/******************************************************************************
 HandleMouseDown

 ******************************************************************************/

void
JXSpellList::HandleMouseDown
	(
	const JPoint& 			pt, 
	const JXMouseButton 	button,
	const JSize 			clickCount,
	const JXButtonStates& 	buttonStates,
	const JXKeyModifiers& 	modifiers
	)
{
	JPoint cell;
	if (GetCell(pt, &cell))
		{
		if (clickCount == 1)
			{
			GetTableSelection().ClearSelection();
			GetTableSelection().SelectCell(cell);
			ChoiceSelected choice(cell.y);
			Broadcast(choice);
			}
		}
}
