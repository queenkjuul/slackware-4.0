/******************************************************************************
 GMessageTableDir.h

	Interface for the GMessageTableDir class

	Copyright � 1997 by Glenn Bach. 

 ******************************************************************************/

#ifndef _H_GMessageTableDir
#define _H_GMessageTableDir

#include <JXWindowDirector.h>
#include <JPtrArray.h>
#include <JString.h>

class GMessageFrom;
class GMessageHeaderList;
class GMessageHeader;
class GMessageViewDir;
class JUNIXDirEntry;
class JXTextMenu;
class GMessageDirUpdateTask;
class istream;
class ostream;
class JXWindow;
class JXImage;
class JXStaticText;
class GXBlockingPG;
class JXProgressIndicator;
class GMessageTable;
class JXScrollbarSet;
class JFileArray;

class GMessageTableDir : public JXWindowDirector
{
public:
	
	static JBoolean Create(JXDirector* supervisor, const JString& mailfile, 
							GMessageTableDir** dir, const JBoolean iconify = kFalse);
	static JBoolean Create(JXDirector* supervisor, JFileArray& fileArray, 
							GMessageTableDir** dir);
	GMessageTableDir(JXDirector* supervisor, const JString& mailfile);
	virtual ~GMessageTableDir();

	const JString& 		GetMailFile();
	JBoolean			Update(const JBoolean unlock = kTrue);
	void				DataModified();
	void				DataReverted();
	void				Save();
	void				SaveMessage(istream& is, ostream& os, 
									GMessageHeader* header, 
									const JBoolean update = kFalse,
									const JBoolean flush = kTrue);
	virtual JBoolean	Close();
	void				UpdateFileEntry();
	void				GenerateFromList();
	GMessageTable&		GetTable();
	
	GMessageHeaderList& GetHeaderList();
	void				ViewMessage(GMessageHeader* header);
	void				SaveState(JFileArray& fileArray);
	void				ReadState(JFileArray& fileArray);	
	void				UpdateMessageCount();
	void				CloseMessage(GMessageHeader* header);

protected:

	virtual void	Receive(JBroadcaster* sender,
								const JBroadcaster::Message& message);
	virtual void	DirectorClosed(JXDirector* theDirector);
	
private:

	GMessageTable*				itsTable;
	JString						itsMailFile;
	JPtrArray<GMessageFrom>*	itsFromList;
	GMessageHeaderList*			itsList;
	JUNIXDirEntry*				itsEntry;
	JXTextMenu*					itsFileMenu;
	JXTextMenu*					itsInboxMenu;
	JXTextMenu*					itsHelpMenu;
	GMessageDirUpdateTask*		itsIdleTask;
	JPtrArray<GMessageViewDir>*	itsViewDirs;

	JBoolean		itsNeedsUpdate;
	JBoolean		itsNeedsSave;
	JXWindow*		itsWindow;
	
	JXImage*		itsNoMailIcon;
	JXImage*		itsNewMailIcon;
	JXImage*		itsSmallNewMailIcon;
	JXImage*		itsHaveMailIcon;
	
	JXStaticText*	itsPath;
	JXStaticText*	itsMessageCount;
	
	GXBlockingPG*			itsPG;
	JXProgressIndicator*	itsIndicator;
	JXScrollbarSet*			itsSBSet;

	JBoolean				itsHasNewMail;
	
private:
	
	static JBoolean CreateX(JXDirector* supervisor, const JString& mailfile, 
							GMessageTableDir** dir);	

	void		AdjustWindowTitle();

	void		UpdateFileMenu();
	void		HandleFileMenu(const JIndex index);
	
	void		UpdateInboxMenu();
	void		HandleInboxMenu(const JIndex index);

	void		HandleHelpMenu(const JIndex index);
	
	void		BuildWindow(const JString& mailfile);
	
	// not allowed

	GMessageTableDir(const GMessageTableDir& source);
	const GMessageTableDir& operator=(const GMessageTableDir& source);

};

/******************************************************************************
 GetMailFile

 ******************************************************************************/

inline const JString&
GMessageTableDir::GetMailFile()
{
	return itsMailFile;
}

/******************************************************************************
 GetTable

 ******************************************************************************/

inline GMessageTable&
GMessageTableDir::GetTable()
{
	return *itsTable;
}

/******************************************************************************
 GetHeaderList

 ******************************************************************************/

inline GMessageHeaderList&
GMessageTableDir::GetHeaderList()
{
	return *itsList;
}

#endif
