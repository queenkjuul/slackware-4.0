#include <GMessageFrom.h>
#include <JArray.tmpls>
#define JTemplateType GMessageFrom
#include <JPtrArray.tmpls>
