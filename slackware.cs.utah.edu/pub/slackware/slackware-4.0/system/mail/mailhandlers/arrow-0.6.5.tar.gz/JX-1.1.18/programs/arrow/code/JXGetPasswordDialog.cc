/******************************************************************************
 JXGetPasswordDialog.cc

	BASE CLASS = JXDialogDirector

	Copyright @ 1997 by Glenn W. Bach.

 ******************************************************************************/

#include "JXGetPasswordDialog.h"

#include <JXWindow.h>
#include <JXTextButton.h>
#include <JXPasswordInput.h>
#include <JXStaticText.h>

#include <JString.h>

#include <jAssert.h>

/******************************************************************************
 Constructor

 ******************************************************************************/

JXGetPasswordDialog::JXGetPasswordDialog
	(
	JXDirector* supervisor
	)
	:
	JXDialogDirector(supervisor, kTrue)
{
	BuildWindow();
}

/******************************************************************************
 Destructor

 ******************************************************************************/

JXGetPasswordDialog::~JXGetPasswordDialog()
{
}

/******************************************************************************
 BuildWindow (private)

 ******************************************************************************/

void
JXGetPasswordDialog::BuildWindow()
{
	
// begin JXLayout

    JXWindow* window = new JXWindow(this, 270,80, "");
    assert( window != NULL );
    SetWindow(window);

    JXStaticText* obj1 =
        new JXStaticText("Password:", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 10,10, 70,20);
    assert( obj1 != NULL );

    JXTextButton* okButton =
        new JXTextButton("OK", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 50,50, 70,20);
    assert( okButton != NULL );
    okButton->SetShortcuts("^M");

    JXTextButton* cancelButton =
        new JXTextButton("Cancel", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 150,50, 70,20);
    assert( cancelButton != NULL );
    cancelButton->SetShortcuts("^[");

	itsInput =
        new JXPasswordInput(window, 
        	JXWidget::kHElastic, JXWidget::kVElastic, 90,10, 165,20);
    assert( itsInput != NULL );

// end JXLayout

	window->SetTitle("Enter password");
	SetButtons(okButton, cancelButton);
}

/******************************************************************************
 GetPassword 

 ******************************************************************************/

const JString& 
JXGetPasswordDialog::GetPassword()
{
	return itsInput->GetPassword();
}
