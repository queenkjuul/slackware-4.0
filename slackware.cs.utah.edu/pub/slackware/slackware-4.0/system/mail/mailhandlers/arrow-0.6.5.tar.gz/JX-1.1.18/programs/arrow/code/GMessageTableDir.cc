/******************************************************************************
 GMessageTableDir.cc

	BASE CLASS = JXWindowDirector

	Copyright � 1997 by Glenn Bach. All rights reserved.

 ******************************************************************************/

#include "GMessageTableDir.h"
#include "GMessageEditDir.h"
#include "GMessageTable.h"
#include "GMessageHeaderList.h"
#include "GMessageHeader.h"
#include "GMessageColHeader.h"
#include "GMessageFrom.h"
#include "GMessageDirUpdateTask.h"
#include "GMessageViewDir.h"
#include "SMTPMessage.h"
#include "nomail.xpm"
#include "newmail.xpm"
#include "newmail_small.xpm"
#include "havemail.xpm"
#include <GMGlobals.h>
#include <GMApp.h>
#include <GPrefsMgr.h>
#include <GInboxMgr.h>
#include <GHelpText.h>
#include <GXBlockingPG.h>

#include <JXImage.h>
#include <JXScrollbarSet.h>
#include <JXScrollbar.h>
#include <JXProgressIndicator.h>
#include <JXStaticText.h>
#include <JXChooseSaveFile.h>
#include <JXApplication.h>
#include <JXWindow.h>
#include <JXMenuBar.h>
#include <JXTextMenu.h>
#include <JXDisplay.h>
#include <JXHelpManager.h>

#include <JUNIXDirEntry.h>
#include <JUserNotification.h>
#include <JString.h>
#include <JFileArray.h>
#include <JStaticBuffer.h>

#include <jProcessUtil.h>
#include <jStreamUtil.h>
#include <jFileUtil.h>
#include <jDirUtil.h>
#include <jStrStreamUtil.h>

#include <iostream.h>
#include <fstream.h>
#include <strstream.h>
#include <stdlib.h>
#include <jAssert.h>

//extern JUserNotification* 	gUserNotification;
//extern JXApplication* 		gApplication;
//extern JChooseSaveFile* 	gChooseSaveFile; 

extern const JIndex		kPriorityIndex;
extern const JIndex		kIconIndex;
extern const JIndex		kAttachIndex;
extern const JIndex		kFromIndex;
extern const JIndex		kSubjectIndex;
extern const JIndex		kDateIndex;

static const JCharacter* kFileMenuTitleStr = "File";
static const JCharacter* kFileMenuStr = 
	"New message %k Meta-N | New mailbox|Open mailbox... %k Meta-O"
	"|Open current outbox"
	"%l| Check mail %k Meta-M | Save changes %k Meta-S|Flush deleted messages %k Meta-F"
	"%l|Preferences"
	"%l|Close %k Meta-W|Quit %k Meta-Q";

enum
{	
	kNewCmd = 1,
	kNewMBox,
	kOpenCmd,
	kOpenOutboxCmd,
	kCheckMailCmd,
	kSaveCmd,
	kFlushCmd,
	kPrefsCmd,
	kCloseCmd,
	kQuitCmd
};

static const JCharacter* kInboxMenuTitleStr = "Inbox";
static const JCharacter* kInboxMenuStr = 
	"Add inbox %k Meta-plus| Remove inbox %k Meta-minus"
	"|Remove all inboxes | Open all inboxes%l";

enum
{
	kAddInboxCmd = 1,
	kRemoveInboxCmd,
	kRemoveAllInboxesCmd,
	kOpenAllInboxesCmd
};

static const JCharacter* kHelpMenuTitleStr = "Help";
static const JCharacter* kHelpMenuStr = 
	"About"
	"%l|Overview|Mail files|Viewing mail|Sending mail|Using POP"
	"%l|Changes|Credits";

enum
{	
	kAboutCmd = 1,
	kOverviewCmd,
	kMailFilesCmd,
	kViewingCmd,
	kSendingCmd,
	kUsingPOPCmd,
	kChangesCmd,
	kCreditsCmd
};

const JCharacter kStateDataEndDelimiter     = '\032';
const JCharacter kViewStateDataEndDelimiter     = '\031';

/******************************************************************************
 Constructor

 ******************************************************************************/

JBoolean
GMessageTableDir::CreateX
	(
	JXDirector* supervisor, 
	const JString& mailfile, 
	GMessageTableDir** dir
	)
{
	(*dir)->Activate();
	(*dir)->itsPath->Hide();
	(*dir)->itsIndicator->Show();
	(*dir)->GetWindow()->Update();
	(*dir)->GetDisplay()->Flush();
	(*dir)->GetDisplay()->Synchronize();
	GMessageHeaderList* list;
	JBoolean ok = GMessageHeaderList::Create(mailfile, &list, (*dir)->itsPG);
	(*dir)->itsIndicator->Hide();
	(*dir)->itsPath->Show();
	if (ok)
		{
		(*dir)->itsList = list;
		(*dir)->itsTable->SetList(list);
		(*dir)->UpdateMessageCount();
		(*dir)->GenerateFromList();		
		return kTrue;
		}
	(*dir)->JXWindowDirector::Close();
	*dir = NULL;
	return kFalse;
}

JBoolean
GMessageTableDir::Create
	(
	JXDirector* supervisor, 
	const JString& mailfile, 
	GMessageTableDir** dir,
	const JBoolean iconify
	)
{
	*dir = new GMessageTableDir(supervisor, mailfile);
	assert(*dir != NULL);
	if (iconify)
		{
		(*dir)->GetWindow()->Iconify();
		}
	JBoolean success = CreateX(supervisor, mailfile, dir);
	if (iconify && success)
		{
		(*dir)->GetWindow()->SetIcon(*((*dir)->itsNewMailIcon));
		(*dir)->itsHasNewMail = kTrue;
		(*dir)->AdjustWindowTitle();
		}
	return success;
}

JBoolean
GMessageTableDir::Create
	(
	JXDirector* supervisor, 
	JFileArray& fileArray, 
	GMessageTableDir** dir
	)
{
	JFAID id = 1;
	JStaticBuffer data;
	fileArray.GetElement(id, &data);
	jistrstream(is, data.GetData(), strlen(data));
	
	JString mailfile;
	is >> mailfile;

	*dir = new GMessageTableDir(supervisor, mailfile);
	assert(*dir != NULL);
	(*dir)->GetWindow()->ReadGeometry(is);
	JBoolean success = CreateX(supervisor, mailfile, dir);
	if (success)
		{
		(*dir)->ReadState(fileArray);
		}
	return success;
}

/******************************************************************************
 Constructor

 ******************************************************************************/

GMessageTableDir::GMessageTableDir
	(
	JXDirector* supervisor,
	const JString& mailfile
	)
	:
	JXWindowDirector(supervisor),
	itsMailFile(mailfile)
{
	if (!itsMailFile.BeginsWith("/"))
		{
		const JString cwd = JGetCurrentDirectory();
		itsMailFile = JCombinePathAndName(cwd, itsMailFile);
		}
	itsEntry = new JUNIXDirEntry(mailfile);
	assert(itsEntry != NULL);

	BuildWindow(mailfile);
	if (itsMailFile.GetCharacter(1) != '/')
		{
		JString cwd = JGetCurrentDirectory();
		itsMailFile.Prepend(cwd);
		}
	itsFromList = new JPtrArray<GMessageFrom>;
	assert(itsFromList != NULL);
	itsFromList->SetCompareFunction(GMessageFrom::CompareFromLines);
	
	itsViewDirs = new JPtrArray<GMessageViewDir>;
	assert(itsViewDirs != NULL);

	itsIdleTask = new GMessageDirUpdateTask(this);
	assert(itsIdleTask != NULL);
	JXGetApplication()->InstallIdleTask(itsIdleTask);

	itsNeedsUpdate  = kFalse;
	itsNeedsSave	= kFalse;
	itsHasNewMail	= kFalse;

	UpdateInboxMenu();
	ListenTo(GGetPrefsMgr());
}

/******************************************************************************
 Destructor

 ******************************************************************************/

GMessageTableDir::~GMessageTableDir()
{
	delete itsEntry;
	JXGetApplication()->RemoveIdleTask(itsIdleTask);
	delete itsIdleTask;
	delete itsNoMailIcon;
	delete itsNewMailIcon;
	delete itsSmallNewMailIcon;
	delete itsHaveMailIcon;
	itsFromList->DeleteAll();
	delete itsFromList;
	delete itsViewDirs;
	delete itsPG;
	delete itsList;
}

/******************************************************************************
 BuildWindow

 ******************************************************************************/

void
GMessageTableDir::BuildWindow
	(
	const JString& mailfile
	)
{
	JSize w = 560;
	JSize h = 300;
	JString title;
	JString path;
	JSplitPathAndName(mailfile, &path, &title);
	itsWindow = new JXWindow(this, w,h, title);
    assert( itsWindow != NULL );
    SetWindow(itsWindow);
    ListenTo(itsWindow);
    
    itsWindow->SetMinSize(w, 150);
	
	JXMenuBar* menuBar = 
		new JXMenuBar(itsWindow, 
			JXWidget::kHElastic, JXWidget::kFixedTop,
			0, 0, w, kJXStdMenuBarHeight);
	assert(menuBar != NULL);
	
	itsFileMenu = menuBar->AppendTextMenu(kFileMenuTitleStr);
	itsFileMenu->SetMenuItems(kFileMenuStr);
	itsFileMenu->SetUpdateAction(JXMenu::kDisableNone);
	ListenTo(itsFileMenu);

//	itsInboxMenu = new JXTextMenu(itsFileMenu, kInboxCmd, menuBar);
	itsInboxMenu = menuBar->AppendTextMenu(kInboxMenuTitleStr);
	assert(itsInboxMenu != NULL);
	itsInboxMenu->SetMenuItems(kInboxMenuStr);
	itsInboxMenu->SetUpdateAction(JXMenu::kDisableNone);
	ListenTo(itsInboxMenu);
	
	const JCoordinate pathheight = 20;
	const JCoordinate scrollheight = h-kJXStdMenuBarHeight - pathheight;
	
	itsSBSet = 
		new JXScrollbarSet(itsWindow,
			JXWidget::kHElastic, JXWidget::kVElastic, 
			0,kJXStdMenuBarHeight,w,scrollheight);
	assert(itsSBSet != NULL);
	
	itsTable = 
		new GMessageTable(this, menuBar,
			itsSBSet, itsSBSet->GetScrollEnclosure(),
			JXWidget::kHElastic, JXWidget::kVElastic, 
			0,20,w,scrollheight-20);
	assert (itsTable != NULL);

	GMessageColHeader* header = 
		new GMessageColHeader(itsTable, 
			itsSBSet, itsSBSet->GetScrollEnclosure(),
			JXWidget::kHElastic, JXWidget::kFixedTop, 
			0,0,w,20);
	assert(header != NULL);
	
	header->SetColTitle(4, "From");
	header->SetColTitle(5, "Subject");
	header->SetColTitle(6, "Date");
	header->SetColTitle(7, "Size");
	
	const JCoordinate pathwidth = w - 150;
	
	itsPath = 
		new JXStaticText(itsMailFile, itsWindow,
			JXWidget::kHElastic, JXWidget::kFixedBottom, 
			0,scrollheight+kJXStdMenuBarHeight,pathwidth,pathheight);
	assert(itsPath != NULL);
	itsPath->SetBorderWidth(1);
//	JSize count = itsList->GetElementCount();
//	JString messageCount(count);
//	messageCount += " messages";
	
	itsMessageCount =
		new JXStaticText("", itsWindow,
			JXWidget::kFixedRight, JXWidget::kFixedBottom, 
			pathwidth,scrollheight+kJXStdMenuBarHeight,w-pathwidth,pathheight);
	assert(itsMessageCount != NULL);
	itsMessageCount->SetBorderWidth(1);
	
	itsNoMailIcon = new JXImage(itsWindow->GetDisplay(), itsWindow->GetColormap(), JXPM(nomail_xpm));
	itsNoMailIcon->ConvertToRemoteStorage();
	
	itsNewMailIcon = new JXImage(itsWindow->GetDisplay(), itsWindow->GetColormap(), JXPM(newmail_xpm));
	itsNewMailIcon->ConvertToRemoteStorage();

	itsSmallNewMailIcon = new JXImage(itsWindow->GetDisplay(), itsWindow->GetColormap(), JXPM(newmail_small_xpm));
	itsSmallNewMailIcon->ConvertToRemoteStorage();

	itsHaveMailIcon = new JXImage(itsWindow->GetDisplay(), itsWindow->GetColormap(), JXPM(havemail_xpm));
	itsHaveMailIcon->ConvertToRemoteStorage();
	
	itsWindow->SetIcon(*itsNoMailIcon);
	itsHasNewMail = kFalse;
	
	itsIndicator =
        new JXProgressIndicator(itsWindow,
        	JXWidget::kHElastic, JXWidget::kFixedBottom, 
			5,scrollheight+kJXStdMenuBarHeight+5,pathwidth-10,pathheight/2);
	assert(itsIndicator != NULL);
	itsIndicator->Hide();

	itsPG = new GXBlockingPG(NULL, NULL, itsIndicator);
	assert(itsPG != NULL);
//	itsPG->SetItems(NULL, NULL, itsIndicator);
// begin JXLayout

	itsHelpMenu = menuBar->AppendTextMenu(kHelpMenuTitleStr);
	itsHelpMenu->SetMenuItems(kHelpMenuStr);
	itsHelpMenu->SetUpdateAction(JXMenu::kDisableNone);
	ListenTo(itsHelpMenu);
}

/******************************************************************************
 Receive

 ******************************************************************************/

void
GMessageTableDir::Receive
	(
	JBroadcaster* sender,
	const JBroadcaster::Message& message
	)
{
	if (sender == itsFileMenu && message.Is(JXMenu::kItemSelected))
		{
		 const JXMenu::ItemSelected* selection =
			dynamic_cast(const JXMenu::ItemSelected*, &message);
		assert( selection != NULL );
		HandleFileMenu(selection->GetIndex());
		}
		
	else if (sender == itsFileMenu && message.Is(JXMenu::kNeedsUpdate))
		{
		UpdateFileMenu();
		}
	else if (sender == itsInboxMenu && message.Is(JXMenu::kItemSelected))
		{
		 const JXMenu::ItemSelected* selection =
			dynamic_cast(const JXMenu::ItemSelected*, &message);
		assert( selection != NULL );
		HandleInboxMenu(selection->GetIndex());
		}

	else if (sender == itsHelpMenu && message.Is(JXMenu::kItemSelected))
		{
		 const JXMenu::ItemSelected* selection =
			dynamic_cast(const JXMenu::ItemSelected*, &message);
		assert( selection != NULL );
		HandleHelpMenu(selection->GetIndex());
		}


	else if (sender == itsWindow && message.Is(JXWindow::kDeiconified))
		{
		if (itsNeedsUpdate)
			{
			Update();
			itsNeedsUpdate = kFalse;
			}
		else
			{
			itsHasNewMail = kFalse;
			UpdateMessageCount();
			}
		}
	else if (sender == GGetPrefsMgr())
		{
		if (message.Is(GPrefsMgr::kInboxesChanged))
			{
			UpdateInboxMenu();
			}
		else if (message.Is(GPrefsMgr::kShowStateChanged))
			{
			AdjustWindowTitle();
			}
		}

	else
		{
		JXWindowDirector::Receive(sender, message);
		}

}

/******************************************************************************
 DirectorClosed 

 ******************************************************************************/

void
GMessageTableDir::DirectorClosed
	(
	JXDirector* theDirector
	)
{
	GMessageViewDir* dir = dynamic_cast(GMessageViewDir*, theDirector);
	assert(dir != NULL);
	if (itsViewDirs->Includes(dir))
		{
		itsViewDirs->Remove(dir);
		}
}

/******************************************************************************
 UpdateFileMenu 


 ******************************************************************************/

void
GMessageTableDir::UpdateFileMenu()
{
	if (itsNeedsSave)
		{
		itsFileMenu->EnableItem(kSaveCmd);
		itsFileMenu->EnableItem(kFlushCmd);
		}
	else
		{
		itsFileMenu->DisableItem(kSaveCmd);
		itsFileMenu->DisableItem(kFlushCmd);
		}
	if (GGetPrefsMgr()->UsingPopServer())
		{
		itsFileMenu->EnableItem(kCheckMailCmd);
		}
	else
		{
		itsFileMenu->DisableItem(kCheckMailCmd);
		}
}

/******************************************************************************
 HandleFileMenu 


 ******************************************************************************/

void
GMessageTableDir::HandleFileMenu
	(
	const JIndex index
	)
{
	if (index == kNewCmd)
		{
		GMessageEditDir* dir = new GMessageEditDir(JXGetApplication());
		assert(dir != NULL);
		dir->Activate();
		}
	else if (index == kNewMBox)
		{
		JString mbox;
		if (JXGetChooseSaveFile()->SaveFile("Name of new mailbox:", "", "",  &mbox))
			{
			GMGetApplication()->NewMailbox(mbox);
			}
		}
	else if (index == kOpenCmd)
		{
		GMGetApplication()->OpenMailbox();
		}
	else if (index == kOpenOutboxCmd)
		{
		GMGetApplication()->OpenMailbox(GGetPrefsMgr()->GetCurrentOutbox());
		}
	else if (index == kCheckMailCmd)
		{
		GCheckMail();
		}
	else if (index == kSaveCmd)
		{
		Save();
		}
	else if (index == kFlushCmd)
		{
		JSize count = itsList->GetElementCount();
		for (JSize index = count; index >= 1; index--)
			{
			GMessageHeader* header = itsList->NthElement(index);
			if (header->GetMessageStatus() == GMessageHeader::kDelete)
				{
				DataModified();
				JIndex i = itsViewDirs->GetElementCount();
				JBoolean found = kFalse;
				while ((i >= 1) && !found)
					{
					GMessageViewDir* dir = itsViewDirs->NthElement(i);
					if (dir->GetMessageHeader() == header)
						{
						dir->Close();
						found = kTrue;
						}
					i--;
					}
				itsList->Remove(header);
				CloseMessage(header);
				delete(header);
				}
			}
		GenerateFromList();
		itsEntry->ForceUpdate();
		UpdateMessageCount();
		Save();
		}
	else if (index == kPrefsCmd)
		{
		GGetPrefsMgr()->EditPrefs();
		}
	else if (index == kCloseCmd)
		{
		Close();
		}
	else if (index == kQuitCmd)
		{
		JXGetApplication()->Quit();
		}
}

/******************************************************************************
 UpdateInboxMenu 


 ******************************************************************************/

void
GMessageTableDir::UpdateInboxMenu()
{
	JSize count = itsInboxMenu->GetItemCount();
	for (JSize i = count; i >= 5; i--)
		{
		itsInboxMenu->DeleteItem(i);
		}

	JPtrArray<JString> inboxes;
	GGetPrefsMgr()->GetInboxes(inboxes);
	for (JSize i = 1; i <= inboxes.GetElementCount(); i++)
		{
		JString inbox;
		JString path;
		JSplitPathAndName(*(inboxes.NthElement(i)), &path, &inbox);
		itsInboxMenu->AppendItem(inbox);
		}

	for (JSize i = 5; i <= itsInboxMenu->GetItemCount(); i++)
		{
		itsInboxMenu->SetItemImage(i, itsSmallNewMailIcon, kFalse);
		}
}

/******************************************************************************
 HandleInboxMenu 


 ******************************************************************************/

void
GMessageTableDir::HandleInboxMenu
	(
	const JIndex index
	)
{
	if (index == kAddInboxCmd)
		{
		GGetPrefsMgr()->AddInbox(itsMailFile);
		}
	else if (index == kRemoveInboxCmd)
		{
		GGetPrefsMgr()->DeleteInbox(itsMailFile);
		}
	else if (index == kRemoveAllInboxesCmd)
		{
		JString notice = "Are you sure you want to delete all of the inboxes?";
		JBoolean ok = JGetUserNotification()->AskUserYes(notice);
		if (ok)
			{
			GGetPrefsMgr()->DeleteAllInboxes();
			}
		}
	else if (index == kOpenAllInboxesCmd)
		{
		JPtrArray<JString> inboxes;
		GGetPrefsMgr()->GetInboxes(inboxes);
		for (JSize i = 1; i <= inboxes.GetElementCount(); i++)
			{
			GMGetApplication()->OpenMailbox(*(inboxes.NthElement(i)));
			}
		}
	else
		{
		JPtrArray<JString> inboxes;
		GGetPrefsMgr()->GetInboxes(inboxes);
		JSize count = inboxes.GetElementCount();
		assert(count >= index - 4);
		GMGetApplication()->OpenMailbox(*(inboxes.NthElement(index - 4)));
		}
}

/******************************************************************************
 HandleHelpMenu 


 ******************************************************************************/

void
GMessageTableDir::HandleHelpMenu
	(
	const JIndex index
	)
{
	if (index == kAboutCmd)
		{
		GMGetApplication()->DisplayAbout();
//		JString about = "Arrow version 0.5.0\nWritten by Glenn W. Bach\nglenn@cco.caltech.edu";
//		JGetUserNotification()->DisplayMessage(about);
		}
	else if (index == kOverviewCmd)
		{
		(JXGetHelpManager())->ShowSection(kOverviewHelpName);
		}
	else if (index == kMailFilesCmd)
		{
		(JXGetHelpManager())->ShowSection(kMailboxHelpName);
		}
	else if (index == kViewingCmd)
		{
		(JXGetHelpManager())->ShowSection(kViewHelpName);
		}
	else if (index == kSendingCmd)
		{
		(JXGetHelpManager())->ShowSection(kSendHelpName);
		}
	else if (index == kUsingPOPCmd)
		{
		(JXGetHelpManager())->ShowSection(kPOPHelpName);
		}
	else if (index == kChangesCmd)
		{
		(JXGetHelpManager())->ShowSection(kChangeLogName);
		}
	else if (index == kCreditsCmd)
		{
		(JXGetHelpManager())->ShowSection(kCreditsName);
		}

}

/******************************************************************************
 GenerateFromList

 ******************************************************************************/

void
GMessageTableDir::GenerateFromList()
{
	itsFromList->DeleteAll();
	JSize count = itsList->GetElementCount();
	for (JSize index = 1; index <= count; index++)
		{
		GMessageHeader* header = itsList->NthElement(index);
		GMessageFrom* from = new GMessageFrom(header);
		assert(from != NULL);
		itsFromList->InsertSorted(from, kTrue);
		}
}

/******************************************************************************
 Update

 ******************************************************************************/

JBoolean
GMessageTableDir::Update
	(
	const JBoolean unlock
	)
{
	time_t oldTime 		= itsEntry->GetModTime();
	JBoolean updated 	= itsEntry->Update();
	if (updated || itsNeedsUpdate)
		{
		if (itsWindow->IsIconified())
			{
			if (!itsNeedsUpdate)
				{
				GetWindow()->GetDisplay()->Beep();
				itsNeedsUpdate = kTrue;
				if (oldTime != itsEntry->GetModTime())
					{
					itsWindow->SetIcon(*itsNewMailIcon);
					itsHasNewMail = kTrue;
					AdjustWindowTitle();
					}
				}
			}
		else
			{
			if (!itsNeedsUpdate)
				{
				GetWindow()->GetDisplay()->Beep();
				itsHasNewMail = kTrue;
				AdjustWindowTitle();
				}
			GMessageHeaderList* list;
			itsPath->Hide();
			itsIndicator->Show();
			GetWindow()->Deactivate();
			GBlockUntilFileUnlocked(itsMailFile);
			GLockFile(itsMailFile);
			JBoolean ok = GMessageHeaderList::Create(itsMailFile, &list, itsPG);
			GetWindow()->Activate();
			itsIndicator->Hide();
			itsPath->Show();
			if (ok)
				{
				JPtrArray<GMessageFrom> fromlist;
				JSize count = list->GetElementCount();
				JSize index;
				for (index = 1; index <= count; index++)
					{
					GMessageHeader* header = list->NthElement(index);
					GMessageFrom* from = new GMessageFrom(header);
					assert(from != NULL);
					fromlist.Append(from);
					}
				count = fromlist.GetElementCount();
				for (index = count; index >= 1; index--)
					{
					GMessageFrom* from = fromlist.NthElement(index);
					JIndex findindex;
					if (itsFromList->SearchSorted(from, JOrderedSetT::kFirstMatch, &findindex))
						{
						GMessageFrom* currentfrom = itsFromList->NthElement(findindex);
						GMessageHeader* header = currentfrom->GetHeader();
						GMessageHeader* header2 = from->GetHeader();
						header->SetHeaderStart(header2->GetHeaderStart());
						header->SetHeaderEnd(header2->GetHeaderEnd());
						header->SetMessageEnd(header2->GetMessageEnd());
						list->Remove(header2);
						fromlist.Remove(from);
						itsFromList->Remove(currentfrom);
						delete header2;
						delete from;
						delete currentfrom;
						}
					}
				count = itsFromList->GetElementCount();
				for (index = count; index >= 1; index--)
					{
					GMessageFrom* from = itsFromList->NthElement(index);
					GMessageHeader* header = from->GetHeader();
					itsList->Remove(header);
					CloseMessage(header);
					itsFromList->Remove(from);
					delete header;
					delete from;
					}
				count = fromlist.GetElementCount();
				for (index = 1; index <= count; index++)
					{
					GMessageFrom* from = fromlist.NthElement(index);
					GMessageHeader* header = from->GetHeader();
					itsList->Append(header);
					}
				delete list;
				}
			
			GenerateFromList();
			
			UpdateMessageCount();
			if (unlock)
				{
				GUnlockFile(itsMailFile);
				}
			return kTrue;
			}
		}
	return kFalse;
}

/******************************************************************************
 Save

 ******************************************************************************/

void
GMessageTableDir::Save()
{
	if (!itsNeedsSave)
		{
		return;
		}
//	GBlockUntilFileUnlocked(itsMailFile);
//	if (!GLockFile(itsMailFile))
//		{
//		return;
//		}
	JString tempname = itsMailFile + ".tmp";
	mode_t perms;
	JError err = JGetPermissions(itsMailFile, &perms);
	if (!err.OK())
		{
		perms = 0600;
		}
	Update(kFalse);
	ifstream is(itsMailFile);
	assert(is.good());
	ofstream os(tempname);
	JBoolean ok = JConvertToBoolean(os.good());
	if (!ok)
		{
		tempname = JGetTempFileName();
		os.close();
		os.open(tempname);
		}
	JSize count = itsList->GetElementCount();
	JSize index;
	for (index = 1; index <= count; index++)
		{
		GMessageHeader* header = itsList->NthElement(index);
		SaveMessage(is, os, header, kTrue);
		}

	is.close();
	os.close();
	JString cmd;
	if (ok)
		{
		cmd = "mv -f " + tempname + " " + itsMailFile;
		}
	else
		{
		cmd = "cp -f " + tempname + " " + itsMailFile;
		}
	err = JExecute(cmd, NULL);
	JSetPermissions(itsMailFile, perms);
	if (!ok)
		{
		JRemoveFile(tempname);
		}
	itsEntry->ForceUpdate();
	DataReverted();
	GUnlockFile(itsMailFile);
}

/******************************************************************************
 SaveMessage

 ******************************************************************************/

void
GMessageTableDir::SaveMessage
	(
	istream& is, 
	ostream& os,
	GMessageHeader* header,
	const JBoolean update,
	const JBoolean flush
	)
{
	JSize headerStart = JTellp(os);
	if ((header->GetMessageStatus() != GMessageHeader::kDelete) || !flush)
		{
		JSeekg(is, header->GetHeaderStart());
		JString line;
		JBoolean foundG = kFalse;
		JBoolean foundS = kFalse;
		while ((line = JReadLine(is)) != "")
			{
			if (line.BeginsWith("Status:"))
				{
				foundS = kTrue;
				line = "Status: ";
				if (header->GetMessageStatus() != GMessageHeader::kNew)
					{
					line += "RO";
					line.Print(os);
					os << "\n";
					}
				}
			else if (line.BeginsWith("GMStatus:"))
				{
				foundG = kTrue;
				line = "GMStatus: ";
				if (header->GetMessageStatus() == GMessageHeader::kUrgent)
					{
					line += "U";
					line.Print(os);
					os << "\n";
					}
				else if (header->GetMessageStatus() == GMessageHeader::kImportant)
					{
					line += "I";
					line.Print(os);
					os << "\n";							
					}
				}
			else
				{
				line.Print(os);
				os << "\n";
				}
			}
		if (!foundG)
			{
			line = "GMStatus: ";
			if (header->GetMessageStatus() == GMessageHeader::kUrgent)
				{
				line += "U";
				line.Print(os);
				os << "\n";
				}
			else if (header->GetMessageStatus() == GMessageHeader::kImportant)
				{
				line += "I";
				line.Print(os);
				os << "\n";
				}
			}
		if (!foundS)
			{
			line = "Status: ";
			if (header->GetMessageStatus() != GMessageHeader::kNew)
				{
				line += "RO";
				line.Print(os);
				os << "\n";
				}
			}
		line = "\n";
		line.Print(os);
		JSize headerEnd = JTellp(os);
		JString body = JRead(is, header->GetMessageEnd() - header->GetHeaderEnd());
		if (!body.EndsWith("\n\n"))
			{
			body.Append("\n\n");
			}
		body.Print(os);
		JSize messageEnd = JTellp(os);
		if (update)
			{
			header->SetHeaderStart(headerStart);
			header->SetHeaderEnd(headerEnd);
			header->SetMessageEnd(messageEnd);
			}
		}
}

/******************************************************************************
 Close

 ******************************************************************************/

JBoolean
GMessageTableDir::Close()
{
	Save();
	GGetInboxMgr()->MailboxClosed(GetMailFile());
	return JXWindowDirector::Close();
}

/******************************************************************************
 UpdateFileEntry

 ******************************************************************************/

void
GMessageTableDir::UpdateFileEntry()
{
	itsEntry->ForceUpdate();
}

/******************************************************************************
 UpdateMessageCount

 ******************************************************************************/

void
GMessageTableDir::UpdateMessageCount()
{
	JSize count = itsList->GetElementCount();
	JString messageCount(count);
	messageCount += " messages";
	itsMessageCount->SetText(messageCount);
	if (count > 0)
		{
		itsWindow->SetIcon(*itsHaveMailIcon);
		}
	else
		{
		itsWindow->SetIcon(*itsNoMailIcon);
		}
	AdjustWindowTitle();
}

/******************************************************************************
 ViewMessage

 ******************************************************************************/

void
GMessageTableDir::ViewMessage
	(
	GMessageHeader* header
	)
{
	GMessageViewDir* dir;
	for (JSize i = 1; i <= itsViewDirs->GetElementCount(); i++)
		{
		dir = itsViewDirs->NthElement(i);
		if (header == dir->GetMessageHeader())
			{
			dir->Activate();
			return;
			}
		}
	dir = new GMessageViewDir(this, itsMailFile, header);
	assert(dir != NULL);
	itsViewDirs->Append(dir);
	dir->Activate();
}

/******************************************************************************
 CloseMessage

 ******************************************************************************/

void
GMessageTableDir::CloseMessage
	(
	GMessageHeader* header
	)
{
	GMessageViewDir* dir;
	for (JSize i = 1; i <= itsViewDirs->GetElementCount(); i++)
		{
		dir = itsViewDirs->NthElement(i);
		if (header == dir->GetMessageHeader())
			{
			dir->Close();
			itsViewDirs->Remove(dir);
			}
		}
}

/******************************************************************************
 SaveState

 ******************************************************************************/

void
GMessageTableDir::SaveState
	(
	JFileArray& fileArray
	)
{
	{
	ostrstream os;
	os << itsMailFile << " ";
	GetWindow()->WriteGeometry(os);
	fileArray.AppendElement(os);
	}
	JSize count;
	{
	ostrstream os;
	JXScrollbar* hsb = itsSBSet->GetHScrollbar();
	JXScrollbar* vsb = itsSBSet->GetVScrollbar();
	os << hsb->GetValue() << " ";
	os << vsb->GetValue() << " ";
	JBoolean hasNewMail = kFalse;
	os << itsHasNewMail << " ";
	os << itsEntry->GetModTime() << " ";
	for (JSize i = 1; i <= itsTable->GetColCount(); i++)
		{
		os << itsTable->GetColWidth(i) << " ";
		}
		
	count = itsViewDirs->GetElementCount();
	os << count << " ";
	fileArray.AppendElement(os);
	}
	for (JSize i = 1; i <= count; i++)
		{
		ostrstream os;
		itsViewDirs->NthElement(i)->SaveState(os);
		fileArray.AppendElement(os);
		}
}

/******************************************************************************
 ReadState

 ******************************************************************************/

void
GMessageTableDir::ReadState
	(
	JFileArray& fileArray
	)
{
	JSize count;
	JFAID id = 2;

	{
	JStaticBuffer data;
	fileArray.GetElement(id, &data);
	jistrstream(is, data.GetData(), strlen(data));
	
	JCoordinate hval, vval;
	is >> hval;
	is >> vval;
	JXScrollbar* hsb = itsSBSet->GetHScrollbar();
	JXScrollbar* vsb = itsSBSet->GetVScrollbar();
	hsb->SetValue(hval);
	vsb->SetValue(vval);

	// check for had new mail
	JBoolean hadNewMail;
	is >> hadNewMail;
	if (hadNewMail)
		{
		if (GetWindow()->IsIconified())
			{
			GetWindow()->SetIcon(*itsNewMailIcon);
			itsHasNewMail = kTrue;
			AdjustWindowTitle();
			}
		}
	
	// check for different mod time
	time_t time;
	is >> time;
	if (time < itsEntry->GetModTime())
		{
		if (GetWindow()->IsIconified())
			{
			GetWindow()->SetIcon(*itsNewMailIcon);
			itsHasNewMail = kTrue;
			AdjustWindowTitle();
			}
		}
	
	for (JSize i = 1; i <= itsTable->GetColCount(); i++)
		{
		JCoordinate width;
		is >> width;
		itsTable->SetColWidth(i, width);
		}
	is >> count;
	}
	id.SetID(id.GetID() + 1);

	for (JSize i = 1; i <= count; i++)
		{
		JStaticBuffer data;
		fileArray.GetElement(id, &data);
		jistrstream(is, data.GetData(), strlen(data));
		JString fromline;
		is >> fromline;
		GMessageHeader* header;
		JIndex index = 1;
		JBoolean found = kFalse;
		while (index <= itsList->GetElementCount() && !found)
			{
			header = itsList->NthElement(index);
			if (header->GetHeader() == fromline)
				{
				found = kTrue;
				}
			index++;
			}
		if (found)
			{
			GMessageViewDir* dir = 
				new GMessageViewDir(this, itsMailFile, header);
			assert(dir != NULL);
			itsViewDirs->Append(dir);
			dir->ReadState(is);
			dir->Activate();
			}
		id.SetID(id.GetID() + 1);
		}
}

/******************************************************************************
 DataModified

 ******************************************************************************/

void
GMessageTableDir::DataModified()
{
	if (!itsNeedsSave)
		{
//		JString name;
//		JString path;
//		JSplitPathAndName(itsMailFile, &path, &name);
		itsNeedsSave = kTrue;
		itsHasNewMail = kFalse;
		AdjustWindowTitle();
//		JString title = "***" + name;
//		GetWindow()->SetTitle(title);
		}
}

/******************************************************************************
 DataReverted

 ******************************************************************************/

void
GMessageTableDir::DataReverted()
{
	if (itsNeedsSave)
		{
//		JString name;
//		JString path;
//		JSplitPathAndName(itsMailFile, &path, &name);
		itsNeedsSave = kFalse;
//		GetWindow()->SetTitle(name);
		}
}

/******************************************************************************
 AdjustWindowTitle

 ******************************************************************************/

void
GMessageTableDir::AdjustWindowTitle()
{
	JString title;
	JString path;
	JSplitPathAndName(itsMailFile, &path, &title);
	if (GGetPrefsMgr()->ShowingStateInTitle())
		{
		const JSize count = itsList->GetElementCount();
		if (itsHasNewMail)
			{
			title.Prepend("**");
			}
		else if (count > 0)
			{
			title.Prepend("*");
			}
		GetWindow()->SetTitle(title);
		}
	else
		{
		GetWindow()->SetTitle(title);
		}
}
