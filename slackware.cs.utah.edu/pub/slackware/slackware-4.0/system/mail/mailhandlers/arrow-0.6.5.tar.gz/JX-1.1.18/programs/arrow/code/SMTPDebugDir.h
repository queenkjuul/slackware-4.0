/******************************************************************************
 SMTPDebugDir.h

	Interface for the SMTPDebugDir class

	Copyright � 1997 by Glenn Bach. 
	This code may be freely distributed, used, and modified without restriction.

 ******************************************************************************/

#ifndef _H_SMTPDebugDir
#define _H_SMTPDebugDir

#include <JXWindowDirector.h>

class JXStaticText;

class SMTPDebugDir : public JXWindowDirector
{
public:

	SMTPDebugDir(JXDirector* supervisor);

	virtual ~SMTPDebugDir();

	void	AddText(const JCharacter* text);

protected:

	virtual void		Receive(JBroadcaster* sender,
								const JBroadcaster::Message& message);
private:

	JXStaticText*				itsText;
		
private:

	// not allowed

	SMTPDebugDir(const SMTPDebugDir& source);
	const SMTPDebugDir& operator=(const SMTPDebugDir& source);
};

#endif