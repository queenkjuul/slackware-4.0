/******************************************************************************
 JXSpellList.h

	Interface for the JXSpellList class

	Copyright @ 1997 by Glenn W. Bach.

 ******************************************************************************/

#ifndef _H_JXSpellList
#define _H_JXSpellList

#include <JXStringList.h>

class JString;

class JXSpellList : public JXStringList
{

public:

	JXSpellList(JXScrollbarSet* scrollbarSet, JXContainer* enclosure,
				 const HSizingOption hSizing, const VSizingOption vSizing,
				 const JCoordinate x, const JCoordinate y,
				 const JCoordinate w, const JCoordinate h);

	virtual ~JXSpellList();
		
protected:
	
	virtual void HandleMouseDown(const JPoint& pt, const JXMouseButton button,
								const JSize clickCount,
								const JXButtonStates& buttonStates,
								const JXKeyModifiers& modifiers);

private:

	// not allowed

	JXSpellList(const JXSpellList& source);
	const JXSpellList& operator=(const JXSpellList& source);

public:

// Broadcaster messages

	static const JCharacter* kChoiceSelected;

	class ChoiceSelected : public JBroadcaster::Message
		{
		public:

			ChoiceSelected(const JIndex index)
				:
				JBroadcaster::Message(kChoiceSelected),
				itsIndex(index)
				{ };

			JIndex
			GetIndex() const
				{
				return itsIndex;
				};
		private:

			JIndex itsIndex;
		};

};

#endif
