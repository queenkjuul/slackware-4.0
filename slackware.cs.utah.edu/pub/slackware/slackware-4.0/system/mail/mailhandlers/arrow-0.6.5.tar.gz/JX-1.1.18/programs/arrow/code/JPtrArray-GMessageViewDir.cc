#include <GMessageViewDir.h>
#include <JArray.tmpls>
#define JTemplateType GMessageViewDir
#include <JPtrArray.tmpls>
