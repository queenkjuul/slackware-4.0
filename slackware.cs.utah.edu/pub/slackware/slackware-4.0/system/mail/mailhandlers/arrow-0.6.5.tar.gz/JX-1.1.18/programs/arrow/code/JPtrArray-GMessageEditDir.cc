#include <GMessageEditDir.h>
#include <JArray.tmpls>
#define JTemplateType GMessageEditDir
#include <JPtrArray.tmpls>
