#include <GMessageTableDir.h>
#include <JArray.tmpls>
#define JTemplateType GMessageTableDir
#include <JPtrArray.tmpls>
