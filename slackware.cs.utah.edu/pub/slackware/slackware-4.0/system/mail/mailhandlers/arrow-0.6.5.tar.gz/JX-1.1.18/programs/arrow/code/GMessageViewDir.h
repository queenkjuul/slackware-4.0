/******************************************************************************
 GMessageViewDir.h

	Interface for the GMessageViewDir class

	Copyright � 1997 by Glenn Bach. 

 ******************************************************************************/

#ifndef _H_GMessageViewDir
#define _H_GMessageViewDir

#include <JXWindowDirector.h>
#include <JString.h>

class GMessageHeader;
class GMessageView;
class JXTextButton;
class JXTextMenu;
class JXScrollbarSet;
class GMessageTableDir;
class JXGetPasswordDialog;
class JXVertPartition;
class ostream;

class GMessageViewDir : public JXWindowDirector
{
public:
	
	GMessageViewDir(GMessageTableDir* supervisor, const JString& mailfile,
							GMessageHeader* header);
	virtual ~GMessageViewDir();

	GMessageHeader*	GetMessageHeader();
	void			SaveState(ostream& os);
	void			ReadState(istream& is);	

protected:

	virtual void		Receive(JBroadcaster* sender,
								const JBroadcaster::Message& message);
private:

	GMessageTableDir*	itsDir;
	GMessageView*		itsView;
	GMessageView*		itsHeader;
	JXTextButton*		itsReplyButton;
	JXTextButton*		itsReplyToAllButton;
	JXTextButton*		itsForwardButton;
	JXTextButton*		itsRedirectButton;
	JXTextMenu*			itsFileMenu;
	JXTextMenu*			itsMessageMenu;
	JXTextMenu*			itsHelpMenu;
	
	JString				itsFrom;
	JString				itsTo;
	JString				itsReplyTo;
	JString				itsDate;
	JString				itsCC;
	JString				itsSubject;
	JString				itsFullHeader;
	JString				itsBody;
	
	JXScrollbarSet*		itsSBSet;
	JBoolean			itsShowFullHeaders;
	GMessageHeader*		itsMessageHeader;

	JXGetPasswordDialog*	itsPasswdDialog;
	JXVertPartition*		itsPart;
private:
	
	void		HandleFileMenu(const JIndex index);
	void		UpdateFileMenu();
	
	void		HandleMessageMenu(const JIndex index);
	void		UpdateMessageMenu();
	
	void		HandleHelpMenu(const JIndex index);

	void		ShowNext();
	void		ShowPrev();
	void		ShowHeader(GMessageHeader* header);

	void		FixHeaderForReply(JString* sub);
	
	void		BuildWindow(const JString& mailfile);
	
	
	// not allowed

	GMessageViewDir(const GMessageViewDir& source);
	const GMessageViewDir& operator=(const GMessageViewDir& source);

};

/******************************************************************************
 Constructor

 ******************************************************************************/

inline GMessageHeader*	
GMessageViewDir::GetMessageHeader()
{
	return itsMessageHeader;
}

#endif
