/******************************************************************************
 GMessageViewDir.cc

	BASE CLASS = JXWindowDirector

	Copyright � 1997 by Glenn Bach. All rights reserved.

 ******************************************************************************/

#include "GMessageViewDir.h"
#include "GMessageView.h"
#include "GMessageEditor.h"
#include "GMessageHeader.h"
#include "GMessageTableDir.h"
#include "GMessageTable.h"
#include "GMessageEditDir.h"
#include "GMessageHeaderList.h"
#include "JXGetPasswordDialog.h"
#include "gMailUtils.h"
#include <GMApp.h>
#include <GHelpText.h>
#include <GPrefsMgr.h>

#include <JXColormap.h>
#include <JXVertPartition.h>
#include <JXTextMenu.h>
#include <JXDownRect.h>
#include <JXTextButton.h>
#include <JXScrollbarSet.h>
#include <JXScrollbar.h>
#include <JXChooseSaveFile.h>
#include <JXApplication.h>
#include <JXWindow.h>
#include <JXMenuBar.h>
#include <JXFontManager.h>

#include <JUserNotification.h>
#include <JString.h>
#include <JPtrArray.h>
#include <JColormap.h>
#include <JInPipeStream.h>
#include <JOutPipeStream.h>
#include <JRegex.h>
#include <JError.h>

#include <GMGlobals.h>

#include <jStreamUtil.h>
#include <jFileUtil.h>
#include <jProcessUtil.h>
#include <jDirUtil.h>

#include <iostream.h>
#include <fstream.h>
#include <strstream.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <jAssert.h>

static const JCharacter* kFileMenuTitleStr = "File";
static const JCharacter* kFileMenuStr = 
	"New message %k Meta-N | New mailbox| Open mailbox... %k Meta-O"
	"%l|Save... %k Meta-S | Save with headers..."
	"%l| Print... %k Meta-P | Print with headers..."
	"%l|Show next %k Meta-plus| Show previous %k Meta-minus"
	"|Delete and show next %k Meta-Shift-D"
	"%l|Preferences"
	"%l|Close %k Meta-W|Close and delete %k Meta-D"
	"|Quit %k Meta-Q";

enum
{	
	kNewCmd = 1,
	kNewMBox,
	kOpenCmd,
	kSaveCmd,
	kSaveHeadCmd,
	kPrintCmd,
	kPrintHeadCmd,
	kShowNextCmd,
	kShowPrevCmd,
	kDeleteShowNextCmd,
	kPrefsCmd,
	kCloseCmd,
	kCloseDeleteCmd,
	kQuitCmd
};

static const JCharacter* kMessageMenuTitleStr = "Message";
static const JCharacter* kMessageMenuStr = 
	"Show full headers %b | Decrypt"
	"%l|Reply %k Meta-R| Reply to sender"
	"|Reply to all| Forward | Redirect";

enum
{
	kShowHeaderCmd = 1,
	kDecryptCmd,
	kReplyCmd,
	kReplySenderCmd,
	kReplyAllCmd,
	kForwardCmd,
	kRedirectCmd
};

static const JCharacter* kHelpMenuTitleStr = "Help";
static const JCharacter* kHelpMenuStr = 
	"Viewing mail";

enum
{	
	kViewingCmd = 1
};

/******************************************************************************
 Constructor

 ******************************************************************************/

GMessageViewDir::GMessageViewDir
	(
	GMessageTableDir* supervisor,
	const JString& mailfile,
	GMessageHeader* header
	)
	:
	JXWindowDirector(supervisor)
{
	itsPasswdDialog = NULL;

	BuildWindow(mailfile);
	itsDir = supervisor;
	itsShowFullHeaders = kFalse;
	ShowHeader(header);
}

/******************************************************************************
 Destructor

 ******************************************************************************/

GMessageViewDir::~GMessageViewDir()
{
}

/******************************************************************************
 BuildWindow

 ******************************************************************************/

void
GMessageViewDir::BuildWindow
	(
	const JString& mailfile
	)
{
	JSize w = 500;
	JSize h = 300;
	JXWindow* window = 
		new JXWindow(this, w,h, mailfile);
    assert( window != NULL );
    SetWindow(window);
    
    window->SetMinSize(w, 150);
    window->SetFocusWhenShow(kTrue);
	
	JXMenuBar* menuBar = 
		new JXMenuBar(window, 
			JXWidget::kHElastic, JXWidget::kFixedTop,
			0, 0, w, kJXStdMenuBarHeight);
	assert(menuBar != NULL);

	itsFileMenu = menuBar->AppendTextMenu(kFileMenuTitleStr);
	itsFileMenu->SetMenuItems(kFileMenuStr);
	itsFileMenu->SetUpdateAction(JXMenu::kDisableNone);
	ListenTo(itsFileMenu);
	
	itsMessageMenu = menuBar->AppendTextMenu(kMessageMenuTitleStr);
	itsMessageMenu->SetMenuItems(kMessageMenuStr);
	itsMessageMenu->SetUpdateAction(JXMenu::kDisableNone);
	ListenTo(itsMessageMenu);

	itsReplyButton = 
		new JXTextButton("Reply", window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop,
			10, kJXStdMenuBarHeight + 5, 70, 20);
	assert(itsReplyButton != NULL);
	ListenTo(itsReplyButton);
	
	itsReplyToAllButton = 
		new JXTextButton("Reply to all", window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop,
			90, kJXStdMenuBarHeight + 5, 90, 20);
	assert(itsReplyToAllButton != NULL);
	ListenTo(itsReplyToAllButton);

	itsForwardButton = 
		new JXTextButton("Forward", window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop,
			190, kJXStdMenuBarHeight + 5, 70, 20);
	assert(itsForwardButton != NULL);
	ListenTo(itsForwardButton);

	itsRedirectButton = 
		new JXTextButton("Redirect", window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop,
			270, kJXStdMenuBarHeight + 5, 70, 20);
	assert(itsRedirectButton != NULL);
	ListenTo(itsRedirectButton);

	const JCoordinate headerheight = 58;

	JArray<JCoordinate> sizes;
	JArray<JCoordinate> minSizes;
	
	sizes.AppendElement(headerheight);
	minSizes.AppendElement(headerheight);
	sizes.AppendElement(w - headerheight);
	minSizes.AppendElement(50);
	JIndex elasticIndex = 2;

	itsPart = 
		new JXVertPartition(sizes, elasticIndex, minSizes, window, 
			JXWidget::kHElastic, JXWidget::kVElastic,
			0, kJXStdMenuBarHeight + kJXStdMenuBarHeight, 
			w, h - kJXStdMenuBarHeight - kJXStdMenuBarHeight);
	assert(itsPart != NULL);

	itsSBSet = 
		new JXScrollbarSet(itsPart->GetCompartment(2),
			JXWidget::kHElastic, JXWidget::kVElastic, 
			0,0,
			100,100);
//	itsSBSet = 
//		new JXScrollbarSet(window,
//			JXWidget::kHElastic, JXWidget::kVElastic, 
//			0, kJXStdMenuBarHeight + kJXStdMenuBarHeight + headerheight,
//			w,h - headerheight - kJXStdMenuBarHeight - kJXStdMenuBarHeight);
	assert(itsSBSet != NULL);
	itsSBSet->FitToEnclosure(kTrue, kTrue);
	
	itsView = 
		new GMessageView(menuBar, itsSBSet, itsSBSet->GetScrollEnclosure(),
			JXWidget::kHElastic, JXWidget::kVElastic, 
			0,0,10,10);
	assert (itsView != NULL);
	itsView->FitToEnclosure(kTrue, kTrue);

//	JXScrollbarSet* sbs = 
//		new JXScrollbarSet(window,
//			JXWidget::kHElastic, JXWidget::kVElastic, 
//			0,0,
//			w,50);

	JXScrollbarSet* sbs = 
		new JXScrollbarSet(itsPart->GetCompartment(1),
			JXWidget::kHElastic, JXWidget::kVElastic, 
			0,0,
			100,50);
	assert(sbs != NULL);
	sbs->FitToEnclosure(kTrue, kTrue);

	itsHeader = 
		new GMessageView(sbs, sbs->GetScrollEnclosure(),
			JXWidget::kHElastic, JXWidget::kVElastic, 
			0,0,10,10);
	assert (itsHeader != NULL);
	itsHeader->FitToEnclosure(kTrue, kTrue);

	itsHeader->ShareEditMenu(itsView, kFalse, kFalse);
	itsHeader->ShareSearchMenu(itsView);

	itsHelpMenu = menuBar->AppendTextMenu(kHelpMenuTitleStr);
	itsHelpMenu->SetMenuItems(kHelpMenuStr);
	itsHelpMenu->SetUpdateAction(JXMenu::kDisableNone);
	ListenTo(itsHelpMenu);

}

/******************************************************************************
 Receive

 ******************************************************************************/

void
GMessageViewDir::Receive
	(
	JBroadcaster* sender,
	const JBroadcaster::Message& message
	)
{
	if (sender == itsReplyButton && message.Is(JXButton::kPushed))
		{
		HandleMessageMenu(kReplyCmd);
		}
	
	else if (sender == itsReplyToAllButton && message.Is(JXButton::kPushed))
		{
		HandleMessageMenu(kReplyAllCmd);
		}

	else if (sender == itsForwardButton && message.Is(JXButton::kPushed))
		{
		HandleMessageMenu(kForwardCmd);
		}

	else if (sender == itsRedirectButton && message.Is(JXButton::kPushed))
		{
		HandleMessageMenu(kRedirectCmd);
		}

	else if (sender == itsFileMenu && message.Is(JXMenu::kItemSelected))
		{
		 const JXMenu::ItemSelected* selection =
			dynamic_cast(const JXMenu::ItemSelected*, &message);
		assert( selection != NULL );
		HandleFileMenu(selection->GetIndex());
		}
	else if (sender == itsHelpMenu && message.Is(JXMenu::kItemSelected))
		{
		 const JXMenu::ItemSelected* selection =
			dynamic_cast(const JXMenu::ItemSelected*, &message);
		assert( selection != NULL );
		HandleHelpMenu(selection->GetIndex());
		}
	else if (sender == itsFileMenu && message.Is(JXMenu::kNeedsUpdate))
		{
		UpdateFileMenu();
		}
	else if (sender == itsMessageMenu && message.Is(JXMenu::kItemSelected))
		{
		 const JXMenu::ItemSelected* selection =
			dynamic_cast(const JXMenu::ItemSelected*, &message);
		assert( selection != NULL );
		HandleMessageMenu(selection->GetIndex());
		}
	else if (sender == itsMessageMenu && message.Is(JXMenu::kNeedsUpdate))
		{
		UpdateMessageMenu();
		}
	else if (sender == itsPasswdDialog && message.Is(JXDialogDirector::kDeactivated))
		{
		const JXDialogDirector::Deactivated* info =
			dynamic_cast(const JXDialogDirector::Deactivated*, &message);
		assert( info != NULL );
		if (info->Successful())
			{
			JString passwd = itsPasswdDialog->GetPassword();
			JString file_out = JGetTempFileName("/tmp");
			itsView->WritePlainText(file_out, JTextEditor::kUNIXText);
			JString file_in = JGetTempFileName("/tmp");
			JString sysCmd = "pgp " + file_out + " -o " + file_in;

			setenv("PGPPASS", passwd, 1);
			JError err =
				JExecute(sysCmd, NULL,
					kJIgnoreConnection, NULL,
					kJTossOutput, NULL,
					kJTossOutput, NULL);
			unsetenv("PGPPASS");
			JRemoveFile(file_out);
			if (err.OK())
				{
				JTextEditor::PlainTextFormat format;
				itsView->ReadPlainText(file_in, &format);
				JRemoveFile(file_in);
				}
			else
				{
				JGetUserNotification()->ReportError("Error decrypting file.");
				}
			}
		itsPasswdDialog = NULL;
		}
	else
		{
		JXWindowDirector::Receive(sender, message);
		}
}

/******************************************************************************
 HandleFileMenu 


 ******************************************************************************/

void
GMessageViewDir::HandleFileMenu
	(
	const JIndex index
	)
{
	if (index == kNewCmd)
		{
		GMessageEditDir* dir = new GMessageEditDir(JXGetApplication());
		assert(dir != NULL);
		dir->Activate();
		}
	else if (index == kNewMBox)
		{
		JString mbox;
		if (JXGetChooseSaveFile()->SaveFile("Name of new mailbox:", "", "",  &mbox))
			{
			GMGetApplication()->NewMailbox(mbox);
			}
		}
	else if (index == kOpenCmd)
		{
		GMGetApplication()->OpenMailbox();
		}
	else if (index == kSaveCmd)
		{
		JString name;
		if (JXGetChooseSaveFile()->SaveFile("Choose file name:", "", "",  &name))
			{
			itsView->WritePlainText(name, JTextEditor::kUNIXText);			
			}
		}
	else if (index == kSaveHeadCmd)
		{
		JString name;
		if (JXGetChooseSaveFile()->SaveFile("Choose file name:", "", "", &name))
			{
			if (itsShowFullHeaders)
				{
				itsView->WritePlainText(name, JTextEditor::kUNIXText);
				}
			else
				{
				itsView->SetText(itsFullHeader + itsBody);
				itsView->WritePlainText(name, JTextEditor::kUNIXText);
				itsView->SetText(itsBody);				
				}
			}
		}
	else if (index == kPrintCmd)
		{
		itsView->HandlePrintPlainText();
		}
	else if (index == kPrintHeadCmd)
		{
		if (!itsShowFullHeaders)
			{
			itsShowFullHeaders = kTrue;
			itsView->SetText(itsFullHeader + itsBody);
			}
		itsView->HandlePrintPlainText();
		}
	else if (index == kPrefsCmd)
		{
		GGetPrefsMgr()->EditPrefs();
		}
	else if (index == kCloseCmd)
		{
		Close();
		}
	else if (index == kCloseDeleteCmd)
		{
		itsDir->GetTable().DeleteHeader(itsMessageHeader);
		Close();
		}
	else if (index == kDeleteShowNextCmd)
		{
		itsDir->GetTable().DeleteHeader(itsMessageHeader);
		GMessageHeader* header = itsMessageHeader;
		ShowNext();
		if (header == itsMessageHeader)
			{
			Close();
			}
		}
	else if (index == kShowNextCmd)
		{
		ShowNext();
		}
	else if (index == kShowPrevCmd)
		{
		ShowPrev();
		}
	else if (index == kQuitCmd)
		{
		JXGetApplication()->Quit();
		}
}

/******************************************************************************
 UpdateFileMenu 


 ******************************************************************************/

void
GMessageViewDir::UpdateFileMenu()
{
	GMessageHeaderList& list = itsDir->GetHeaderList();
	JIndex findex;
	list.Find(itsMessageHeader, &findex);

	if (findex > 1)
		{
		itsFileMenu->EnableItem(kShowPrevCmd);
		}
	else
		{
		itsFileMenu->DisableItem(kShowPrevCmd);
		}
	if (findex < list.GetElementCount())
		{
		itsFileMenu->EnableItem(kShowNextCmd);
		}
	else
		{
		itsFileMenu->DisableItem(kShowNextCmd);
		}
}

/******************************************************************************
 UpdateMessageMenu 


 ******************************************************************************/

void
GMessageViewDir::UpdateMessageMenu()
{
	if (itsShowFullHeaders)
		{
		itsMessageMenu->CheckItem(kShowHeaderCmd);
		}
}

/******************************************************************************
 HandleMessageMenu 


 ******************************************************************************/

void
GMessageViewDir::HandleMessageMenu
	(
	const JIndex index
	)
{
	if (index == kShowHeaderCmd)
		{
		itsShowFullHeaders = JNegate(itsShowFullHeaders);
		if (itsShowFullHeaders)
			{
			itsView->SetText(itsFullHeader + itsBody);
			}
		else
			{
			itsView->SetText(itsBody);
			}
		}
	else if (index == kDecryptCmd)
		{
		assert(itsPasswdDialog == NULL);
		itsPasswdDialog = new JXGetPasswordDialog(this);
		assert(itsPasswdDialog != NULL);
		ListenTo(itsPasswdDialog);
		itsPasswdDialog->BeginDialog();
		}
	else if (index == kReplyCmd)
		{
		itsDir->GetTable().Reply(itsMessageHeader);
		}
	else if (index == kReplySenderCmd)
		{
		itsDir->GetTable().ReplySender(itsMessageHeader);
		}
	else if (index == kReplyAllCmd)
		{
		itsDir->GetTable().ReplyAll(itsMessageHeader);
		}
	else if (index == kForwardCmd)
		{
		itsDir->GetTable().Forward(itsMessageHeader);
		}
	else if (index == kRedirectCmd)
		{
		itsDir->GetTable().Redirect(itsMessageHeader);
		}
}

/******************************************************************************
 HandleHelpMenu 


 ******************************************************************************/

void
GMessageViewDir::HandleHelpMenu
	(
	const JIndex index
	)
{
	if (index == kViewingCmd)
		{
		(JXGetHelpManager())->ShowSection(kViewHelpName);
		}
}

/******************************************************************************
 ShowNext 


 ******************************************************************************/

void
GMessageViewDir::ShowNext()
{
		GMessageHeaderList& list = itsDir->GetHeaderList();
		JIndex findex;
		list.Find(itsMessageHeader, &findex);
		if (findex < list.GetElementCount())
			{
			JBoolean found = kFalse;
			JIndex i = findex + 1;
			GMessageHeader* header;
			while (!found && i <= list.GetElementCount())
				{
				header = list.NthElement(i);
				if (header->GetMessageStatus() != GMessageHeader::kDelete)
					{
					found = kTrue;
					}
				i++;
				}
			if (found)
				{
				itsDir->GetTable().UnSelectHeader(itsMessageHeader);
				ShowHeader(header);
				itsDir->GetTable().SelectHeader(header);
				itsDir->GetTable().ShowMessageRead(header);
				}
			}
}

/******************************************************************************
 ShowPrev 


 ******************************************************************************/

void
GMessageViewDir::ShowPrev()
{
		GMessageHeaderList& list = itsDir->GetHeaderList();
		JIndex findex;
		list.Find(itsMessageHeader, &findex);
		if (findex > 1)
			{
			JBoolean found = kFalse;
			JIndex i = findex - 1;
			GMessageHeader* header;
			while (!found && i > 0)
				{
				header = list.NthElement(i);
				if (header->GetMessageStatus() != GMessageHeader::kDelete)
					{
					found = kTrue;
					}
				i--;
				}
			if (found)
				{
				itsDir->GetTable().UnSelectHeader(itsMessageHeader);
				ShowHeader(header);
				itsDir->GetTable().SelectHeader(header);
				itsDir->GetTable().ShowMessageRead(header);
				}
			}
}

/******************************************************************************
 ShowHeader 


 ******************************************************************************/

void
GMessageViewDir::ShowHeader
	(
	GMessageHeader* header
	)
{
	itsMessageHeader = header;

	mode_t perms;
	JError err = JGetPermissions(itsDir->GetMailFile(), &perms);
	if (!err.OK())
		{
		perms = 0600;
		}

	fstream is(itsDir->GetMailFile(), ios::in|ios::out, perms);
	assert(is.good());
	
	is.seekp(header->GetHeaderStart());
	itsFullHeader = JRead(is, header->GetHeaderEnd() - header->GetHeaderStart());
	
	itsFrom = header->GetFrom();
	itsTo = header->GetTo();
	itsDate = header->GetDate();
	itsSubject = header->GetSubject();
	itsReplyTo = header->GetReplyTo();
	itsCC = header->GetCC();
	JString head = "From: " + itsFrom;
	if (!itsSubject.IsEmpty())
		{
		if (head.GetLastCharacter() != '\n')
			{
			head += "\n";
			}	
		head += "Subject: " + itsSubject;
		}
	if (head.GetLastCharacter() != '\n')
		{
		head += "\n";
		}
	head += "Date: " + itsDate;
	if (!itsTo.IsEmpty())
		{
		if (head.GetLastCharacter() != '\n')
			{
			head += "\n";
			}
		head += "To: " + itsTo;
		}
	if (!itsReplyTo.IsEmpty())
		{
		if (head.GetLastCharacter() != '\n')
			{
			head += "\n";
			}
		head += "Reply-To: " + itsReplyTo;
		}
	if (!itsCC.IsEmpty())
		{
		if (head.GetLastCharacter() != '\n')
			{
			head += "\n";
			}
		head += "Cc: " + itsCC;
		}
	head.TrimWhitespace();
	itsHeader->SetText(head);

	itsBody = JRead(is, header->GetMessageEnd() - header->GetHeaderEnd());
	
	if (itsShowFullHeaders)
		{
		itsView->SetText(itsFullHeader + itsBody);
		}
	else
		{
		itsView->SetText(itsBody);
		}
	is.close();
	JString title = itsFrom;
	JIndex findindex;
	if (title.LocateSubstring("@", &findindex))
		{
		title.RemoveSubstring(findindex, title.GetLength());
		}
	JString sub = ":" + itsSubject;
	if (sub.GetLength() > 11)
		{
		sub.RemoveSubstring(10, sub.GetLength());
		}
	title.Append(sub);
	GetWindow()->SetTitle(title);
}

/******************************************************************************
 FixHeaderForReply 


 ******************************************************************************/

void
GMessageViewDir::FixHeaderForReply
	(
	JString* sub
	)
{
	JRegex regex;
	JError err = regex.SetPattern("^[rR][eE][.:]");
	assert(err.OK());
	JBoolean matched;
	JArray<JIndexRange>* subList = new JArray<JIndexRange>;
	assert(subList != NULL);
	matched = regex.Match(*sub, subList);
	if (!matched)
		{
		sub->Prepend("Re: ");
		}
}

/******************************************************************************
 SaveState 


 ******************************************************************************/

void
GMessageViewDir::SaveState
	(
	ostream& os
	)
{
	os << itsMessageHeader->GetHeader() << " ";
	GetWindow()->WriteGeometry(os);

	JXScrollbar* hsb = itsSBSet->GetHScrollbar();
	JXScrollbar* vsb = itsSBSet->GetVScrollbar();
	os << hsb->GetValue() << " ";
	os << vsb->GetValue() << " ";

	const JArray<JCoordinate>& sizes = itsPart->GetCompartmentSizes();
	JSize count = 2;
	for (JSize i = 1; i <= 2; i++)
		{
		os << sizes.GetElement(i) << " ";
		}
}

/******************************************************************************
 ReadState 


 ******************************************************************************/

void
GMessageViewDir::ReadState
	(
	istream& is
	)
{
	GetWindow()->ReadGeometry(is);
	JCoordinate hval, vval;
	is >> hval;
	is >> vval;
	JXScrollbar* hsb = itsSBSet->GetHScrollbar();
	JXScrollbar* vsb = itsSBSet->GetVScrollbar();
	hsb->SetValue(hval);
	vsb->SetValue(vval);

	JArray<JCoordinate> sizes;
	JCoordinate value;
	is >> value;
	sizes.AppendElement(value);
	is >> value;
	sizes.AppendElement(value);
	itsPart->JPartition::SetCompartmentSizes(sizes);
}