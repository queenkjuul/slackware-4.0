/******************************************************************************
 memview.cc
 
 Written by Glenn Bach - 1997.

 ******************************************************************************/

#include "GMessageTableDir.h"
#include <GMApp.h>
#include <GMMDIServer.h>

#include <JString.h>

#include <jXGlobals.h>

#include <iostream.h>
#include <jAssert.h>

extern JCharacter* kGMSig;

const JCharacter* kArrowVersionNumberStr = "0.6.5";

const JCharacter* kArrowVersionStr =

	"Arrow 0.6.5\n"
	"\n"
	"An e-mail program for X.\n"
	"\n"
	"Copyright � 1998 by Glenn W. Bach.\n"
	"The binary version of this program may be\n"
	"freely distributed at no charge.\n"
	"\n"
	"http://www.cco.caltech.edu/~glenn/arrow/\n"
	"glenn@cco.wonderland.caltech.edu";

// Prototypes

void ParseTextOptions(const int argc, char* argv[]);

void PrintHelp();
void PrintVersion();

/******************************************************************************
 main

 ******************************************************************************/

int
main
	(
	int		argc,
	char*	argv[]
	)
{
	ParseTextOptions(argc, argv);
	
	if (!GMMDIServer::WillBeMDIServer(kGMSig, argc, argv))
		{
		return 0;
		}

	JBoolean displayAbout;
	JString prevVersStr;
	GMApp* app =
		new GMApp(&argc, argv, &displayAbout, &prevVersStr);
	assert( app != NULL );

	if (displayAbout)
		{
		app->DisplayAbout(prevVersStr);
		}
		
	app->Run();				
	return 0;
}

/******************************************************************************
 ParseTextOptions

	Handle the command line options that don't require opening an X display.

	Options that don't call exit() should use JXApplication::RemoveCmdLineOption()
	so ParseXOptions won't gag.

 ******************************************************************************/

void
ParseTextOptions
	(
	const int	argc,
	char*		argv[]
	)
{
	long index = 1;
	while (index < argc)
		{
		if (strcmp(argv[index], "-h") == 0)
			{
			PrintHelp();
			exit(0);
			}
		else if (strcmp(argv[index], "-v") == 0)
			{
			PrintVersion();
			exit(0);
			}
		index++;
		}
}

/******************************************************************************
 PrintHelp

	ruler:	 01234567890123456789012345678901234567890123456789012345678901234567890123456789

 ******************************************************************************/

void
PrintHelp()
{
	cout << endl;
	cout << "Arrow " << kArrowVersionNumberStr << endl;
	cout << endl;
	cout << "This X application provides access to e-mail." << endl;
	cout << endl;
	cout << "Because Arrow fully supports the Multiple Document concept," << endl;
	cout << "it can be safely invoked from the command line or via a file manager" << endl;
	cout << "as often as you like." << endl;
	cout << endl;
	cout << "Usage:" << endl;
	cout << "arrow mailbox1 mailbox2 ..." << endl;
	cout << endl;
	cout << "-h        prints this help" << endl;
	cout << "-v        prints version information" << endl;
	cout << endl;
	cout << "http://www.cco.caltech.edu/~glenn/arrow/" << endl;
	cout << "glenn@cco.wonderland.caltech.edu" << endl;
	cout << endl;
}

/******************************************************************************
 PrintVersion

 ******************************************************************************/

void
PrintVersion()
{
	cout << endl;
	cout << kArrowVersionStr << endl;
	cout << endl;
}
