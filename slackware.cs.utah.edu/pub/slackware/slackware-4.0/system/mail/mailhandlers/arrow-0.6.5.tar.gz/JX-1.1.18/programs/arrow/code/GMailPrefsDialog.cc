/******************************************************************************
 GMailPrefsDialog.cc

	BASE CLASS = JXDialogDirector

	Copyright @ 1997 by Glenn W. Bach.

 ******************************************************************************/

#include "GMailPrefsDialog.h"

#include <JXWindow.h>
#include <JXTextButton.h>
#include <JXStringInput.h>
#include <JXTextCheckbox.h>
#include <JXStaticText.h>
#include <JXIntegerInput.h>

#include <JString.h>

#include <jXGlobals.h>

#include <jAssert.h>

/******************************************************************************
 Constructor

 ******************************************************************************/

GMailPrefsDialog::GMailPrefsDialog
	(
	JXDirector* 	supervisor,
	const JString& 	inbox,
	const JString& 	smtp,
	const JString& 	smtpuser,
	const JBoolean 	showstate,
	const JString& 	pop,
	const JString& 	account,
	const JBoolean 	usePop,
	const JBoolean 	leave,
	const JBoolean 	save,
	const JBoolean 	useAPop,
	const JBoolean 	autoQuote,
	const JBoolean 	autoCheck,
	const JInteger	minutes
	)
	:
	JXDialogDirector(supervisor, kTrue)
{
	BuildWindow(inbox, smtp, smtpuser, showstate, pop, account, usePop, leave, 
					save, useAPop, autoQuote, autoCheck, minutes);
}

/******************************************************************************
 Destructor

 ******************************************************************************/

GMailPrefsDialog::~GMailPrefsDialog()
{
}

/******************************************************************************
 BuildWindow (private)

 ******************************************************************************/

void
GMailPrefsDialog::BuildWindow
	(
	const JString& 	inbox,
	const JString& 	smtp,
	const JString& 	smtpuser,
	const JBoolean 	showstate,
	const JString& 	pop,
	const JString& 	account,
	const JBoolean 	usePop,
	const JBoolean 	leave,
	const JBoolean 	save,
	const JBoolean 	useAPop,
	const JBoolean 	autoQuote,
	const JBoolean 	autoCheck,
	const JInteger	minutes
	)
{
	
// begin JXLayout

    JXWindow* window = new JXWindow(this, 370,460, "");
    assert( window != NULL );
    SetWindow(window);

    itsChooseInboxButton =
        new JXTextButton("Choose inbox", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 20,40, 100,20);
    assert( itsChooseInboxButton != NULL );

    JXStaticText* obj1 =
        new JXStaticText("Default inbox:", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 120,18, 110,20);
    assert( obj1 != NULL );

    itsSMTPServerInput =
        new JXStringInput(window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 120,70, 230,20);
    assert( itsSMTPServerInput != NULL );

    JXStaticText* obj2 =
        new JXStaticText("SMTP server:", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 20,73, 90,20);
    assert( obj2 != NULL );

    itsPopServerInput =
        new JXStringInput(window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 120,365, 230,20);
    assert( itsPopServerInput != NULL );

    JXStaticText* obj3 =
        new JXStaticText("POP server:", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 20,368, 85,20);
    assert( obj3 != NULL );

    itsUsePopButton =
        new JXTextCheckbox("Use POP server", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 20,195, 120,20);
    assert( itsUsePopButton != NULL );

    itsLeaveMailButton =
        new JXTextCheckbox("Leave mail on server", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 30,220, 150,20);
    assert( itsLeaveMailButton != NULL );

    itsSavePasswdButton =
        new JXTextCheckbox("Save password", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 30,245, 120,20);
    assert( itsSavePasswdButton != NULL );

    itsPopAccountInput =
        new JXStringInput(window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 120,395, 230,20);
    assert( itsPopAccountInput != NULL );

    JXStaticText* obj4 =
        new JXStaticText("POP account:", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 20,398, 90,20);
    assert( obj4 != NULL );

    JXTextButton* okButton =
        new JXTextButton("OK", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 90,433, 70,20);
    assert( okButton != NULL );
    okButton->SetShortcuts("^M");

    JXTextButton* cancelButton =
        new JXTextButton("Cancel", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 200,433, 70,20);
    assert( cancelButton != NULL );
    cancelButton->SetShortcuts("#W^[");

    itsInboxText =
        new JXStaticText("", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 120,40, 230,20);
    assert( itsInboxText != NULL );

    itsShowStateInTitle =
        new JXTextCheckbox("Show mailbox state in title", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 20,135, 175,20);
    assert( itsShowStateInTitle != NULL );

    itsAutoQuote =
        new JXTextCheckbox("Automatically insert quote on reply", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 20,165, 230,20);
    assert( itsAutoQuote != NULL );

    itsUseAPop =
        new JXTextCheckbox("Use APOP", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 30,270, 120,20);
    assert( itsUseAPop != NULL );

    itsAutoCheckMail =
        new JXTextCheckbox("Automatically check mail", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 30,295, 180,20);
    assert( itsAutoCheckMail != NULL );

    itsCheckMailDelay =
        new JXIntegerInput(window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 120,325, 70,20);
    assert( itsCheckMailDelay != NULL );
    itsCheckMailDelay->SetFontSize(10);

    JXStaticText* obj5 =
        new JXStaticText("every", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 70,328, 45,20);
    assert( obj5 != NULL );

    JXStaticText* obj6 =
        new JXStaticText("minutes", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 200,328, 55,20);
    assert( obj6 != NULL );

    itsSMTPUserName =
        new JXStringInput(window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 120,100, 230,20);
    assert( itsSMTPUserName != NULL );

    JXStaticText* obj7 =
        new JXStaticText("SMTP user:", window,
                    JXWidget::kHElastic, JXWidget::kVElastic, 20,103, 80,20);
    assert( obj7 != NULL );

// end JXLayout

	window->SetTitle("Mail Preferences");
	SetButtons(okButton, cancelButton);

	itsInboxText->SetBorderWidth(2);

	ListenTo(itsChooseInboxButton);
	ListenTo(itsUsePopButton);

	itsInboxText->SetText(inbox);
	itsSMTPServerInput->SetString(smtp);
	itsSMTPUserName->SetString(smtpuser);
	itsPopServerInput->SetString(pop);
	itsPopAccountInput->SetString(account);

	itsShowStateInTitle->SetState(showstate);
	itsUsePopButton->SetState(usePop);
	itsLeaveMailButton->SetState(leave);
	itsSavePasswdButton->SetState(save);
	itsUseAPop->SetState(useAPop);

	itsAutoQuote->SetState(autoQuote);
	itsAutoCheckMail->SetState(autoCheck);
	itsCheckMailDelay->SetValue(minutes);
	
	if (usePop)
		{
		itsPopServerInput->Activate();
		itsLeaveMailButton->Activate();
		itsSavePasswdButton->Activate();
		itsPopAccountInput->Activate();
		itsUseAPop->Activate();
		itsAutoCheckMail->Activate();
		itsCheckMailDelay->Activate();
		}
	else
		{
		itsPopServerInput->Deactivate();
		itsLeaveMailButton->Deactivate();
		itsSavePasswdButton->Deactivate();
		itsPopAccountInput->Deactivate();
		itsUseAPop->Deactivate();
		itsAutoCheckMail->Deactivate();
		itsCheckMailDelay->Deactivate();
		}

	// ******* temporary until pop working *******

//	itsPopServerInput->Deactivate();
//	itsLeaveMailButton->Deactivate();
//	itsSavePasswdButton->Deactivate();
//	itsPopAccountInput->Deactivate();
//	itsUsePopButton->Deactivate();
}

/******************************************************************************
 GetValues 

 ******************************************************************************/

void
GMailPrefsDialog::GetValues
	(
	JString* 	inbox,
	JString* 	smtp,
	JString* 	smtpuser,
	JBoolean* 	showstate,
	JString* 	pop,
	JString* 	account,
	JBoolean* 	usePop,
	JBoolean* 	leave,
	JBoolean* 	save,
	JBoolean* 	useAPop,
	JBoolean* 	autoQuote,
	JBoolean* 	autoCheck,
	JInteger*	minutes
	)
{
	*inbox 		= itsInboxText->GetText();
	*smtp 		= itsSMTPServerInput->GetString();
	*smtpuser 	= itsSMTPUserName->GetString();
	*showstate 	= itsShowStateInTitle->IsChecked();
	*pop 		= itsPopServerInput->GetString();
	*account 	= itsPopAccountInput->GetString();

	*usePop 	= itsUsePopButton->IsChecked();
	*leave 		= itsLeaveMailButton->IsChecked();
	*save 		= itsSavePasswdButton->IsChecked();

	*useAPop 	= itsUseAPop->IsChecked();
	*autoQuote 	= itsAutoQuote->IsChecked();

	*autoCheck	= itsAutoCheckMail->IsChecked();
	itsCheckMailDelay->GetValue(minutes);
}

/******************************************************************************
 Receive 

 ******************************************************************************/

void
GMailPrefsDialog::Receive
	(
	JBroadcaster* 	sender, 
	const Message& 	message
	)
{
	if (sender == itsChooseInboxButton && message.Is(JXButton::kPushed))
		{
		JString mbox;
		if (JXGetChooseSaveFile()->ChooseFile("Choose default inbox:", "", &mbox))
			{
			itsInboxText->SetText(mbox);
			}
		}
	else if (sender == itsUsePopButton && message.Is(JXCheckbox::kPushed))
		{
		const JXCheckbox::Pushed* info = 
			dynamic_cast(const JXCheckbox::Pushed*, &message);
		assert(info != NULL);
		if (info->IsChecked())
			{
			itsPopServerInput->Activate();
			itsLeaveMailButton->Activate();
			itsSavePasswdButton->Activate();
			itsPopAccountInput->Activate();
			itsUseAPop->Activate();
			itsAutoCheckMail->Activate();
			itsCheckMailDelay->Activate();
			}
		else
			{
			itsPopServerInput->Deactivate();
			itsLeaveMailButton->Deactivate();
			itsSavePasswdButton->Deactivate();
			itsPopAccountInput->Deactivate();
			itsUseAPop->Deactivate();
			itsAutoCheckMail->Deactivate();
			itsCheckMailDelay->Deactivate();
			}
		}
	else
		{
		JXDialogDirector::Receive(sender, message);
		}
}
