/******************************************************************************
 GAddressBookMgr.h

	Interface for the GAddressBookMgr class

	Copyright � 1998 by Glenn W. Bach. All rights reserved.

 ******************************************************************************/

#ifndef _H_GAddressBookMgr
#define _H_GAddressBookMgr

#include <JBroadcaster.h>
#include <JString.h>
#include <JStringPtrMap.h>

#include <GAddressBookEntry.h>

#include <jTypes.h>

class GAddressBookMgr : virtual public JBroadcaster
{
public:

	GAddressBookMgr();
	virtual ~GAddressBookMgr();

	JBoolean NameIsAlias(const JCharacter* name, JString& alias, JString& fcc);
	
protected:


private:

	JStringPtrMap<GAddressBookEntry>*	itsAddresses;

private:

	JBoolean	GetNextRecord(JString& line, JString& record, istream& is);

	// not allowed

	GAddressBookMgr(const GAddressBookMgr& source);
	const GAddressBookMgr& operator=(const GAddressBookMgr& source);
};

#endif