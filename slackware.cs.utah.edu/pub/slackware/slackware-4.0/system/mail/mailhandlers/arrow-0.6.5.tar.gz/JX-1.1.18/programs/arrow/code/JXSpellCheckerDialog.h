/******************************************************************************
 JXSpellCheckerDialog.h

	Interface for the JXSpellCheckerDialog class

	Copyright @ 1997 by Glenn W. Bach.

 ******************************************************************************/

#ifndef _H_JXSpellCheckerDialog
#define _H_JXSpellCheckerDialog

#include <JXDialogDirector.h>

class JXStringInput;
class JXTextButton;
class JXStaticText;
class JXSpellList;
class JString;

class JXSpellCheckerDialog : public JXDialogDirector
{
public:

	enum SpellAction
	{
	kIgnore = 1,
	kIgnoreAll,
	kChange,
	kChangeAll,
	kLearn,
	kLearnCaps
	};

public:

	JXSpellCheckerDialog(JXDirector* supervisor);

	virtual ~JXSpellCheckerDialog();
	
	const JString& 	GetCorrection();
	const JString& 	GetCheckWord();
	SpellAction		GetSpellAction();

	void			SetCheckWord(const JCharacter* word);
	void			SetFirstGuess(const JCharacter* word);
	void			SetSuggestions(const JPtrArray<JString>* words);
	
	
protected:
	
	virtual void	Receive(JBroadcaster* sender, const Message& message);

private:

	JXStaticText*	itsCheckText;
	JXStringInput*	itsFirstGuess;
	JXSpellList*	itsSuggestions;
	JXTextButton*	itsIgnoreButton;
	JXTextButton*	itsIgnoreAllButton;
	JXTextButton*	itsChangeButton;
	JXTextButton*	itsChangeAllButton;
	JXTextButton*	itsLearnButton;
	JXTextButton*	itsLearnCapsButton;

	SpellAction		itsCurrentAction;

private:

	void	BuildWindow();

	// not allowed

	JXSpellCheckerDialog(const JXSpellCheckerDialog& source);
	const JXSpellCheckerDialog& operator=(const JXSpellCheckerDialog& source);
};

#endif
