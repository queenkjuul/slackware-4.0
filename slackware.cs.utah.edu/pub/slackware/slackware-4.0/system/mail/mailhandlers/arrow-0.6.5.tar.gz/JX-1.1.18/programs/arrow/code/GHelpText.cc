/******************************************************************************
 GHelpText.cc

	Copyright � 1998 by Glenn Bach. All rights reserved.

 ******************************************************************************/

#include "GHelpText.h"

const JCharacter* kHelpSectionName[] =
	{ kMailboxHelpName, kSendHelpName, kViewHelpName,
	  kOverviewHelpName, kChangeLogName, kCreditsName, kPOPHelpName };

const JCharacter* kHelpSectionTitle[] =
	{ kMailboxHelpTitle, kSendHelpTitle, kViewHelpTitle,
	  kOverviewHelpTitle, kChangeLogTitle, kCreditsTitle, kPOPHelpTitle };

const JCharacter* kHelpSectionText[] =
	{ kMailboxHelpText, kSendHelpText, kViewHelpText,
	  kOverviewHelpText, kChangeLogText, kCreditsText, kPOPHelpText };

JSize kHelpSectionCount = sizeof(kHelpSectionName) / sizeof(JCharacter*);
