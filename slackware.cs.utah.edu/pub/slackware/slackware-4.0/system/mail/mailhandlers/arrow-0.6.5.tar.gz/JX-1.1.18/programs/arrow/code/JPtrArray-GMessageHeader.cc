#include <GMessageHeader.h>
#include <JArray.tmpls>
#define JTemplateType GMessageHeader
#include <JPtrArray.tmpls>
