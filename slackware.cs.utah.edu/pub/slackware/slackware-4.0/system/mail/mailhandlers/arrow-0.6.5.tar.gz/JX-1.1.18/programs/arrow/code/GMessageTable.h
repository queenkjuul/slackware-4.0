/******************************************************************************
 GMessageTable.h

	Interface for the GMessageTable class

	Copyright � 1997 by Glenn W. Bach. All rights reserved.

 ******************************************************************************/

#ifndef _H_GMessageTable
#define _H_GMessageTable

#include <JXTable.h>

class JXScrollbar;
class GMessageTableDir;
class GMessageHeaderList;
class GMessageHeader;
class JString;
class JXImage;
class JXTextMenu;
class JXMenuBar;
class JXTimerTask;

class GMessageTable : public JXTable
{
public:

	GMessageTable(GMessageTableDir* dir, 
				JXMenuBar* menuBar, 
				JXScrollbarSet* scrollbarSet, JXContainer* enclosure,
				const HSizingOption hSizing, const VSizingOption vSizing,
				const JCoordinate x, const JCoordinate y,
				const JCoordinate w, const JCoordinate h);

	virtual ~GMessageTable();

	void	SetList(GMessageHeaderList* list);
	void	DeleteHeader(GMessageHeader* header);
	void	ShowMessageRead(GMessageHeader* header);
	void	SelectHeader(GMessageHeader* header);
	void	UnSelectHeader(GMessageHeader* header);
	void	Reply(GMessageHeader* header, const JBoolean useReplyTo = kTrue,
					const JBoolean useCC = kFalse, 
					const JBoolean fillTo = kTrue,
					const JBoolean insertText = kFalse,
					const JBoolean quoteText = kFalse);
	void	ReplySender(GMessageHeader* header);
	void	ReplyAll(GMessageHeader* header);
	void	Forward(GMessageHeader* header);
	void	Redirect(GMessageHeader* header);

	virtual void HandleKeyPress(const int key,				
								const JXKeyModifiers& modifiers);


	
protected:

	virtual void Draw(JXWindowPainter& p, const JRect& rect);
	virtual void Receive(JBroadcaster* sender, const Message& message);
	virtual void TableDrawCell(JPainter& p, const JPoint& cell, 
								const JRect& rect);

	virtual void HandleMouseDown(const JPoint& pt, const JXMouseButton button,
								const JSize clickCount,
								const JXButtonStates& buttonStates,
								const JXKeyModifiers& modifiers);
	virtual void HandleMouseDrag(const JPoint& pt, const JXButtonStates& buttonStates,
								const JXKeyModifiers& modifiers);

	virtual JBoolean WillAcceptDrop(const JArray<Atom>& typeList, 
									Atom* action,const Time time, 
									const JXWidget*		source);
	virtual void	DNDInit(const JPoint& pt, const JXButtonStates& buttonStates,
							const JXKeyModifiers& modifiers);
	virtual void 	HandleDNDHere(const JPoint& pt, const JXWidget* source);
	virtual void 	HandleDNDLeave();
	virtual void 	HandleDNDDrop(	const JPoint& pt, const JArray<Atom>& typeList,
									const Atom 	action, const Time time, 
									const JXWidget* source);
	virtual JBoolean ConvertSelection(	const Atom name, const Atom requestType,
										Atom* returnType, unsigned char** data,
										JSize* dataLength, JSize* bitsPerBlock);

private:

	GMessageTableDir*	itsDir;				// We don't own this.
	JSize				itsLineHeight;
	GMessageHeaderList* itsList;
	JXImage*			itsMailIcon;
	JXImage*			itsCheckIcon;
	JIndex				itsLastSelectedIndex;
	JIndex				itsCurrentDndHereIndex;
	Atom 				itsMessageXAtom;
	JBoolean			itsDownInCell;
	JPoint				itsDownPt;
	JXTextMenu*			itsMessageMenu;
	JBoolean			itsAboveTop;
	JBoolean			itsIsDND;
	JXTimerTask*		itsUnlockTask;			

private:

	void	UpdateMessageMenu();
	void	HandleMessageMenu(const JIndex index);

	void 	AddToSelection(const JIndex index);
	void 	ExtendSelection(const JIndex index);
	void 	ElementSelected(const JIndex index);
	void	SyncWithList();

	// not allowed

	GMessageTable(const GMessageTable& source);
	const GMessageTable& operator=(const GMessageTable& source);
	
};

#endif