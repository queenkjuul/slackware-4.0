/******************************************************************************
 GMessageEditDir.cc

	BASE CLASS = JXWindowDirector

	Copyright � 1997 by Glenn Bach. All rights reserved.

 ******************************************************************************/

#include "GMessageEditDir.h"
#include <SMTPMessage.h>
#include <GMessageEditor.h>
#include "JXGetPasswordDialog.h"
#include "gMailUtils.h"
#include <GMApp.h>
#include <GPrefsMgr.h>
#include <GHelpText.h>

#include <JXStaticText.h>
#include <JXStringInput.h>
#include <JXScrollbarSet.h>
#include <JXScrollbar.h>
#include <JXChooseSaveFile.h>
#include <JXColormap.h>
#include <JXApplication.h>
#include <JXTextButton.h>
#include <JXWindow.h>
#include <JXMenuBar.h>
#include <JXTextMenu.h>

#include <JUNIXDirEntry.h>
#include <JUserNotification.h>
#include <JString.h>
#include <JColormap.h>
#include <JInPipeStream.h>
#include <JOutPipeStream.h>

#include <GMGlobals.h>

#include <jProcessUtil.h>
#include <jStreamUtil.h>
#include <jFileUtil.h>
#include <jDirUtil.h>
#include <jFStreamUtil.h>

#include <iostream.h>
#include <fstream.h>
#include <strstream.h>
#include <stdlib.h>
#include <unistd.h>
#include <jAssert.h>

static const JCharacter* kFileMenuTitleStr = "File";
static const JCharacter* kFileMenuStr = 
	"New message %k Meta-N | New mailbox |Open mailbox... %k Meta-O"
	"%l|Send message | Save message %k Meta-S | Save message as..."
	"%l|Preferences"
	"%l|Discard and close|Quit %k Meta-Q";

enum
{	
	kNewCmd = 1,
	kNewMBox,
	kOpenCmd,
	kSendCmd,
	kSaveCmd,
	kSaveAsCmd,
	kPrefsCmd,
	kDiscardCmd,
	kQuitCmd
};

// Message menu

static const JCharacter* kMessageMenuTitleStr = "Message";
static const JCharacter* kMessageMenuStr = 
	"Insert quoted %k Meta-I| Insert unquoted"
	"| Insert signature %k Meta-Shift-G"
	"%l|Encrypt"
	"%l|Show Reply-To %b| Show Cc %b %k Meta-Shift-C| Show Bcc %b";

enum
{
	kQuoteCmd = 1,
	kUnquoteCmd,
	kSigCmd,
	kEncryptCmd,
	kShowRepToCmd,
	kShowCcCmd,
	kShowBccCmd
};

/*
static const JCharacter* kMessageMenuTitleStr = "Message";
static const JCharacter* kMessageMenuStr = 
	"Insert quoted %k Meta-I| Insert unquoted"
	"|Paste quoted %k Meta-Shift-V "
	"|Quote selected %l| Insert signature %k Meta-G"
	"%l|Check spelling %k Meta-L|Encrypt"
	"%l|Show Reply-To %b| Show Cc %b| Show Bcc %b";

enum
{
	kQuoteCmd = 1,
	kUnquoteCmd,
	kPasteQuotedCmd,
	kQuoteSelectedCmd,
	kSigCmd,
	kCheckSpellingCmd,
	kEncryptCmd,
	kShowRepToCmd,
	kShowCcCmd,
	kShowBccCmd
};

*/
static const JCharacter* kHelpMenuTitleStr = "Help";
static const JCharacter* kHelpMenuStr = 
	"Sending mail";

enum
{	
	kSendingCmd = 1
};

static const JCharacter* kDefaultReplyString = "On %d, %f wrote:";
static const JCharacter* kDefaultMark = ">";

/******************************************************************************
 Constructor

 ******************************************************************************/

GMessageEditDir::GMessageEditDir
	(
	JXDirector* supervisor
	)
	:
	JXWindowDirector(supervisor)
{
	itsPasswdDialog	= NULL;
	itsMessage 		= NULL;
	BuildWindow();
	
	itsReplyString = 		new JString(kDefaultReplyString);
	assert(itsReplyString != NULL);
	
	itsReplyMark = 			new JString(kDefaultMark);
	assert(itsReplyMark != NULL);
	
	itsSentFrom = 			new JString();
	assert(itsSentFrom != NULL);
	
	itsSentDate = 			new JString();
	assert(itsSentDate != NULL);
	
	itsSentTextFileName = 	new JString();
	assert(itsSentTextFileName != NULL);
	
	itsShowReplyTo 	= kFalse;
	itsShowCC		= kFalse;
	itsShowBCC		= kFalse;
	
	AdjustInputFields();

	GMGetApplication()->AppendNewMessage(this);

}

/******************************************************************************
 Destructor

 ******************************************************************************/

GMessageEditDir::~GMessageEditDir()
{
	delete itsReplyString;
	delete itsReplyMark;
	delete itsSentFrom;
	delete itsSentDate;
	if (JFileExists(*itsSentTextFileName))
		{
		JRemoveFile(*itsSentTextFileName);
		}
	delete itsSentTextFileName;
}

/******************************************************************************
 BuildWindow

 ******************************************************************************/

void
GMessageEditDir::BuildWindow()
{
	JSize w = 510;
	JSize h = 400;
	JString title;
	JString path;
	JXWindow* window = new JXWindow(this, w,h, "New Message");
    assert( window != NULL );
    SetWindow(window);

    window->SetMinSize(w, 250);
    window->SetMaxSize(w, 3000);
    window->SetFocusWhenShow(kTrue);
	
	JXMenuBar* menuBar = 
		new JXMenuBar(window, 
			JXWidget::kHElastic, JXWidget::kFixedTop,
			0, 0, w, kJXStdMenuBarHeight);
	assert(menuBar != NULL);
	
	itsFileMenu = menuBar->AppendTextMenu(kFileMenuTitleStr);
	itsFileMenu->SetMenuItems(kFileMenuStr);
	itsFileMenu->SetUpdateAction(JXMenu::kDisableNone);
	ListenTo(itsFileMenu);
	
	itsMessageMenu = menuBar->AppendTextMenu(kMessageMenuTitleStr);
	itsMessageMenu->SetMenuItems(kMessageMenuStr);
	itsMessageMenu->SetUpdateAction(JXMenu::kDisableNone);
	ListenTo(itsMessageMenu);

	itsToLabel =
		new JXStaticText("To:", window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			60,43,30,17);
	assert(itsToLabel != NULL);
	
	itsToInput =
		new JXStringInput(window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			100,40,250,20);
	assert(itsToInput != NULL);
	ListenTo(itsToInput);
	itsToInput->SetDefaultFont(GGetPrefsMgr()->GetDefaultMonoFont(), kJDefaultFontSize);
	
	itsReplyToLabel =
		new JXStaticText("Reply-To:", window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			20,73,70,17);
	assert(itsReplyToLabel != NULL);
	
	itsReplyToInput =
		new JXStringInput(window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			100,70,250,20);
	assert(itsReplyToInput != NULL);
	itsReplyToInput->SetDefaultFont(GGetPrefsMgr()->GetDefaultMonoFont(), kJDefaultFontSize);
	
	itsCCLabel =
		new JXStaticText("Cc:", window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			58,103,30,17);
	assert(itsCCLabel != NULL);
	
	itsCCInput =
		new JXStringInput(window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			100,100,250,20);
	assert(itsCCInput != NULL);
	itsCCInput->SetDefaultFont(GGetPrefsMgr()->GetDefaultMonoFont(), kJDefaultFontSize);

	itsBCCLabel =
		new JXStaticText("Bcc:", window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			52,133,40,17);
	assert(itsBCCLabel != NULL);
	
	itsBCCInput =
		new JXStringInput(window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			100,130,250,20);
	assert(itsBCCInput != NULL);
	itsBCCInput->SetDefaultFont(GGetPrefsMgr()->GetDefaultMonoFont(), kJDefaultFontSize);
	
	itsSubjectLabel =
		new JXStaticText("Subject:", window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			32,163,60,17);
	assert(itsSubjectLabel != NULL);
	
	itsSubjectInput =
		new JXStringInput(window,
			JXWidget::kFixedLeft, JXWidget::kFixedTop, 
			100,160,250,20);
	assert(itsSubjectInput != NULL);
	ListenTo(itsSubjectInput);
	itsSubjectInput->SetDefaultFont(GGetPrefsMgr()->GetDefaultMonoFont(), kJDefaultFontSize);

	itsEditorSet = 
		new JXScrollbarSet(window,
			JXWidget::kFixedLeft, JXWidget::kVElastic, 
			0,190,510,h - 190);
	assert(itsEditorSet != NULL);
	
	itsEditor = 
		new GMessageEditor(menuBar, 
			itsEditorSet, itsEditorSet->GetScrollEnclosure(),
			JXWidget::kHElastic, JXWidget::kVElastic, 
			0,0,510,h - 190);
	assert (itsEditor != NULL);
	itsEditor->SetBackColor(GetColormap()->GetWhiteColor());

	itsToInput->ShareEditMenu(itsEditor, kFalse, kFalse);
	itsToInput->ShouldAllowDragAndDrop(kTrue);

	itsReplyToInput->ShareEditMenu(itsEditor, kFalse, kFalse);
	itsReplyToInput->ShouldAllowDragAndDrop(kTrue);

	itsCCInput->ShareEditMenu(itsEditor, kFalse, kFalse);
	itsCCInput->ShouldAllowDragAndDrop(kTrue);

	itsBCCInput->ShareEditMenu(itsEditor, kFalse, kFalse);
	itsBCCInput->ShouldAllowDragAndDrop(kTrue);

	itsSubjectInput->ShareEditMenu(itsEditor, kFalse, kFalse);
	itsSubjectInput->ShouldAllowDragAndDrop(kTrue);

	itsSendButton = 
		new JXTextButton("Send", window,
			JXWidget::kFixedRight, JXWidget::kFixedTop, 
			380,40,70,20);
	assert(itsSubjectInput != NULL);
//	itsSendButton->SetShortcuts("#s");
	ListenTo(itsSendButton);

	itsHelpMenu = menuBar->AppendTextMenu(kHelpMenuTitleStr);
	itsHelpMenu->SetMenuItems(kHelpMenuStr);
	itsHelpMenu->SetUpdateAction(JXMenu::kDisableNone);
	ListenTo(itsHelpMenu);
}

/******************************************************************************
 Receive

 ******************************************************************************/

void
GMessageEditDir::Receive
	(
	JBroadcaster* sender,
	const JBroadcaster::Message& message
	)
{
	if (sender == itsFileMenu && message.Is(JXMenu::kItemSelected))
		{
		 const JXMenu::ItemSelected* selection =
			dynamic_cast(const JXMenu::ItemSelected*, &message);
		assert( selection != NULL );
		HandleFileMenu(selection->GetIndex());
		}
	else if (sender == itsMessageMenu && message.Is(JXMenu::kItemSelected))
		{
		 const JXMenu::ItemSelected* selection =
			dynamic_cast(const JXMenu::ItemSelected*, &message);
		assert( selection != NULL );
		HandleMessageMenu(selection->GetIndex());
		}
	else if (sender == itsHelpMenu && message.Is(JXMenu::kItemSelected))
		{
		 const JXMenu::ItemSelected* selection =
			dynamic_cast(const JXMenu::ItemSelected*, &message);
		assert( selection != NULL );
		HandleHelpMenu(selection->GetIndex());
		}
	else if (sender == itsMessageMenu && message.Is(JXMenu::kNeedsUpdate))
		{
		UpdateMessageMenu();
		}
	else if (sender == itsSendButton && message.Is(JXButton::kPushed))
		{
		HandleFileMenu(kSendCmd);
		}
	else if (sender == itsToInput && message.Is(JXWidget::kLostFocus))
		{
		JString text = itsToInput->GetString();
		if (!text.IsEmpty())
			{
			AdjustWindowTitle();
			}
		}
	else if (sender == itsSubjectInput && message.Is(JXWidget::kLostFocus))
		{
		JString text = itsSubjectInput->GetString();
		if (!text.IsEmpty())
			{
			AdjustWindowTitle();
			}
		}
	else if (sender == itsPasswdDialog && message.Is(JXDialogDirector::kDeactivated))
		{
		const JXDialogDirector::Deactivated* info =
			dynamic_cast(const JXDialogDirector::Deactivated*, &message);
		assert( info != NULL );
		if (info->Successful())
			{
			JString passwd = itsPasswdDialog->GetPassword();
			JString file_out = JGetTempFileName("/tmp");
			itsEditor->WritePlainText(file_out, JTextEditor::kUNIXText);
			JString file_in = JGetTempFileName("/tmp");
			JString sysCmd = "pgp -east " + file_out + " -o " + file_in + " ";
			JPtrArray<JString> names;
			GParseNameLists(itsToInput->GetString(), itsCCInput->GetString(), 
							itsBCCInput->GetString(), names);
			if (GVerifyPGPNames(names))
				{
				for (JSize i = 1; i <= names.GetElementCount(); i++)
					{
					sysCmd += *(names.NthElement(i)) + " ";
					}
				setenv("PGPPASS", passwd, 1);
				int errFD;
				JError err =
					JExecute(sysCmd, NULL,
						kJIgnoreConnection, NULL,
						kJTossOutput, NULL,
						kJCreatePipe, &errFD);
				JRemoveFile(file_out);
				if (err.OK())
					{
					file_in += ".asc";
					JString buffer;
					JReadFile(file_in, &buffer);
					JRemoveFile(file_in);
					if (!buffer.IsEmpty())
						{
						itsEditor->SelectAll();
						itsEditor->Paste(buffer);
						}
					}
				else
					{
					JGetUserNotification()->ReportError("Error decrypting file.");
					}
				names.DeleteAll();
				unsetenv("PGPPASS");
				}
			}
		itsPasswdDialog = NULL;
		}
	else if (sender == itsMessage)
		{
		if (message.Is(SMTPMessage::kMessageSent))
			{
			Close();
			itsMessage = NULL;
			}
		else if (message.Is(SMTPMessage::kSendFailure))
			{
			GetWindow()->Show();
			itsMessage = NULL;
			}
		}
	else
		{
		JXWindowDirector::Receive(sender, message);
		}

}

/******************************************************************************
 HandleFileMenu 


 ******************************************************************************/

void
GMessageEditDir::HandleFileMenu
	(
	const JIndex index
	)
{
	if (index == kNewCmd)
		{
		GMessageEditDir* dir = new GMessageEditDir(JXGetApplication());
		assert(dir != NULL);
		dir->Activate();
		}
	else if (index == kNewMBox)
		{
		JString mbox;
		if (JXGetChooseSaveFile()->SaveFile("Name of new mailbox:","", "",  &mbox))
			{
			GMGetApplication()->NewMailbox(mbox);
			}
		}
	else if (index == kOpenCmd)
		{
		GMGetApplication()->OpenMailbox();
		}
	else if (index == kSendCmd)
		{
		Send();
		}
	else if (index == kSaveCmd)
		{
		if (itsFileName.IsEmpty())
			{
			JXGetChooseSaveFile()->SaveFile("Save text as:","", "",  &itsFileName);
			}
		if (!itsFileName.IsEmpty())
			{
			ofstream os(itsFileName);
			if (os.good())
				{
				itsEditor->GetText().Print(os);
				JString path;
				JString name;
				JSplitPathAndName(itsFileName, &path, &name);
				JString menuName = "Save message (" + name + ")";
				itsFileMenu->SetItemText(kSaveCmd, menuName);
				}
			else
				{
				JString notice = "Unable to open file " + itsFileName;
				JGetUserNotification()->ReportError(notice);
				}
			}
		}
	else if (index == kSaveAsCmd)
		{
		JXGetChooseSaveFile()->SaveFile("Save text as:","", "",  &itsFileName);
		if (!itsFileName.IsEmpty())
			{
			ofstream os(itsFileName);
			if (os.good())
				{
				itsEditor->GetText().Print(os);
				JString path;
				JString name;
				JSplitPathAndName(itsFileName, &path, &name);
				JString menuName = "Save message (" + name + ")";
				itsFileMenu->SetItemText(kSaveCmd, menuName);
				}
			else
				{
				JString notice = "Unable to open file " + itsFileName;
				JGetUserNotification()->ReportError(notice);
				}
			}
		}
	else if (index == kPrefsCmd)
		{
		GGetPrefsMgr()->EditPrefs();
		}
	else if (index == kDiscardCmd)
		{
		Close();
		}
	else if (index == kQuitCmd)
		{
		JXGetApplication()->Quit();
		}
}

/******************************************************************************
 UpdateMessageMenu 


 ******************************************************************************/

void
GMessageEditDir::UpdateMessageMenu()
{
	itsMessageMenu->EnableItem(kSigCmd);
	if (itsSentTextFileName->IsEmpty())
		{
		itsMessageMenu->DisableItem(kQuoteCmd);
		itsMessageMenu->DisableItem(kUnquoteCmd);
		}
	else
		{
		itsMessageMenu->EnableItem(kQuoteCmd);
		itsMessageMenu->EnableItem(kUnquoteCmd);
		}
	if (GPGPEnabled())
		{
		itsMessageMenu->EnableItem(kEncryptCmd);
		}
	else
		{
		itsMessageMenu->DisableItem(kEncryptCmd);
		}
	if (itsShowReplyTo)
		{
		itsMessageMenu->CheckItem(kShowRepToCmd);
		}
	if (itsShowCC)
		{
		itsMessageMenu->CheckItem(kShowCcCmd);
		}
	if (itsShowBCC)
		{
		itsMessageMenu->CheckItem(kShowBccCmd);
		}
}

/******************************************************************************
 HandleMessageMenu 


 ******************************************************************************/

void
GMessageEditDir::HandleMessageMenu
	(
	const JIndex index
	)
{
	if (index == kQuoteCmd)
		{
		InsertText(kTrue);
		}
	else if (index == kUnquoteCmd)
		{
		InsertText(kFalse);
		}
	else if (index == kSigCmd)
		{
		JString homeDir;
		if (JGetHomeDirectory(&homeDir))
			{
			JAppendDirSeparator(&homeDir);
			JString sigFile = homeDir + ".signature";
			if (JFileExists(sigFile))
				{
				ifstream is(sigFile);
				if (is.good())
					{
					JString sig;
					JReadFile(is, &sig);
					itsEditor->Paste(sig);
					}
				}
			else
				{
				JGetUserNotification()->ReportError("Can't find signature file.");
				}
			}
		else
			{
			JGetUserNotification()->ReportError("Can't find home directory.");
			}
		}
	else if (index == kEncryptCmd)
		{
		if (itsToInput->GetString().IsEmpty())
			{
			JGetUserNotification()->ReportError("You must specify a recipient.");
			}
		else
			{
			assert(itsPasswdDialog == NULL);
			itsPasswdDialog = new JXGetPasswordDialog(this);
			assert(itsPasswdDialog != NULL);
			ListenTo(itsPasswdDialog);
			itsPasswdDialog->BeginDialog();
			}
		}
	else if (index == kShowRepToCmd)
		{
		itsShowReplyTo = JNegate(itsShowReplyTo);
		AdjustInputFields();
		if (itsShowReplyTo)
			{
			itsReplyToInput->Focus();
			}
		}
	else if (index == kShowCcCmd)
		{
		itsShowCC = JNegate(itsShowCC);
		AdjustInputFields();
		if (itsShowCC)
			{
			itsCCInput->Focus();
			}
		}
	else if (index == kShowBccCmd)
		{
		itsShowBCC = JNegate(itsShowBCC);
		AdjustInputFields();
		if (itsShowBCC)
			{
			itsBCCInput->Focus();
			}
		}
}

/******************************************************************************
 HandleHelpMenu 


 ******************************************************************************/

void
GMessageEditDir::HandleHelpMenu
	(
	const JIndex index
	)
{
	if (index == kSendingCmd)
		{
		(JXGetHelpManager())->ShowSection(kSendHelpName);
		}
}

/******************************************************************************
 Send

 ******************************************************************************/

void
GMessageEditDir::Send()
{
	if (itsToInput->GetText().IsEmpty())
		{
		JGetUserNotification()->ReportError("You must specify a recipient.");
		itsToInput->Focus();
		return;
		}

	GetWindow()->Hide();
	JXGetApplication()->DisplayBusyCursor();
	itsMessage = new SMTPMessage();
	assert(itsMessage != NULL);
	ListenTo(itsMessage);
	itsMessage->SetTo(itsToInput->GetString());
	JString username = GGetPrefsMgr()->GetSMTPUser();
	itsMessage->SetFrom(username);
	itsMessage->SetSubject(itsSubjectInput->GetString());
	itsMessage->SetCC(itsCCInput->GetString());
	itsMessage->SetBCC(itsBCCInput->GetString());
	itsMessage->SetReplyTo(itsReplyToInput->GetString());
	itsMessage->SetData(itsEditor->GetText());
	itsMessage->Send();
}

/******************************************************************************
 Close

 ******************************************************************************/

JBoolean
GMessageEditDir::Close()
{
	return JXWindowDirector::Close();
}

/******************************************************************************
 SetTo

 ******************************************************************************/

void
GMessageEditDir::SetTo
	(
	const JString& to
	)
{
	JString temp = to;
	temp.TrimWhitespace();
	GCompressWhitespace(&temp);
	itsToInput->SetString(temp);
	AdjustWindowTitle();
	itsEditor->Focus();
}

/******************************************************************************
 SetCC

 ******************************************************************************/

void
GMessageEditDir::SetCC
	(
	const JString& cc
	)
{
	JString temp(cc);
	temp.TrimWhitespace();
	GCompressWhitespace(&temp);
	if (!temp.IsEmpty())
		{
		itsCCInput->SetString(temp);
		itsShowCC = kTrue;
		AdjustInputFields();
		}
}

/******************************************************************************
 SetSubject

 ******************************************************************************/

void
GMessageEditDir::SetSubject
	(
	const JString& subject
	)
{
	itsSubjectInput->SetString(subject);
	AdjustWindowTitle();
}

/******************************************************************************
 SetSentFrom

 ******************************************************************************/

void
GMessageEditDir::SetSentFrom
	(
	const JString& sentfrom
	)
{
	*itsSentFrom = sentfrom;
	itsSentFrom->TrimWhitespace();
}

/******************************************************************************
 SetSentDate

 ******************************************************************************/

void
GMessageEditDir::SetSentDate
	(
	const JString& sentdate
	)
{
	*itsSentDate = sentdate;
}

/******************************************************************************
 SetText

 ******************************************************************************/

void
GMessageEditDir::SetText
	(
	const JString& filename
	)
{
	*itsSentTextFileName = filename;
}

/******************************************************************************
 InsertText

 ******************************************************************************/

void
GMessageEditDir::InsertText
	(
	const JBoolean marked
	)
{
	JString text;
	ifstream is(*itsSentTextFileName);
	JReadAll(is, &text);
	JIndex startIndex;
	itsEditor->GetCaretLocation(&startIndex);

	if (!marked)
		{
		itsEditor->Paste(text);
		}
	else
		{
		JString replystring(*itsReplyString);
		JIndex findindex;
		if (replystring.LocateSubstring("%d", &findindex))
			{
			replystring.ReplaceSubstring(findindex, findindex+1, *itsSentDate);
			}
		if (replystring.LocateSubstring("%f", &findindex))
			{
			replystring.ReplaceSubstring(findindex, findindex+1, *itsSentFrom);
			}
		if (replystring.GetLastCharacter() != '\n')
			{
			replystring.Append("\n");
			}

		replystring.Append("\n");
		text.Prepend(replystring);
		GQuoteString(&text, kFalse);
		itsEditor->Paste(text);
		
		}
	itsEditor->SelectLine(itsEditor->GetLineForChar(startIndex));
	itsEditor->TEScrollToSelection(kFalse);
	itsEditor->SetCaretLocation(startIndex);
}

/******************************************************************************
 AdjustInputFields

 ******************************************************************************/

void
GMessageEditDir::AdjustInputFields()
{
	JSize inputcount = 0;
	if (itsShowReplyTo)
		{
		itsReplyToInput->Place(100,70);
		itsReplyToLabel->Place(20,73);
		inputcount++;
		itsReplyToInput->Show();
		itsReplyToLabel->Show();
		}
	else
		{
		itsReplyToInput->Hide();
		itsReplyToLabel->Hide();
		}
	if (itsShowCC)
		{
		itsCCInput->Place(100,70 + inputcount*30);
		itsCCLabel->Place(58,73 + inputcount*30);
		inputcount++;
		itsCCInput->Show();
		itsCCLabel->Show();
		}
	else
		{
		itsCCInput->Hide();
		itsCCLabel->Hide();
		}
	if (itsShowBCC)
		{
		itsBCCInput->Place(100,70 + inputcount*30);
		itsBCCLabel->Place(52,73 + inputcount*30);
		inputcount++;
		itsBCCInput->Show();
		itsBCCLabel->Show();
		}
	else
		{
		itsBCCInput->Hide();
		itsBCCLabel->Hide();
		}
	itsSubjectInput->Place(100, 70 + inputcount*30);
	itsSubjectLabel->Place(32, 73 + inputcount*30);
	inputcount++;
	
	JSize currentheight = itsEditorSet->GetFrameHeight();
	JRect frame = itsEditorSet->GetFrame();
	JCoordinate newpos = 70 + inputcount*30;
	JCoordinate oldpos = frame.top;
	itsEditorSet->Move(0, newpos - oldpos);
	itsEditorSet->AdjustSize(0, oldpos - newpos);
//	GetWindow()->AdjustSize(0, newpos-oldpos);
}

/******************************************************************************
 AdjustWindowTitle

 ******************************************************************************/

void
GMessageEditDir::AdjustWindowTitle()
{
	JString title;
	if (!(itsToInput->GetText().IsEmpty()))
		{
		title = itsToInput->GetText();
		JIndex findindex;
		if (title.LocateSubstring("@", &findindex))
			{
			title.RemoveSubstring(findindex, title.GetLength());
			}
		}
	if (!(itsSubjectInput->GetText().IsEmpty()))
		{
		if (!title.IsEmpty())
			{
			title.Append(":");
			}
		JString sub = itsSubjectInput->GetText();
		const JSize kMaxSubjectWidth = 10;
		if (sub.GetLength() > kMaxSubjectWidth)
			{
			sub.RemoveSubstring(10, sub.GetLength());
			}
		title.Append(sub);
		}
	GetWindow()->SetTitle(title);
}

/******************************************************************************
 SaveState 


 ******************************************************************************/

void
GMessageEditDir::SaveState
	(
	ostream& os
	)
{
	os << itsToInput->GetText();
	os << itsReplyToInput->GetText();
	os << itsCCInput->GetText();
	os << itsBCCInput->GetText();
	os << itsSubjectInput->GetText();

	os << itsShowReplyTo << " ";
	os << itsShowCC << " ";
	os << itsShowBCC << " ";

	os << *itsReplyString;
	os << *itsReplyMark;
	os << *itsSentFrom;
	os << *itsSentDate;

	os << itsEditor->GetText();

	JString buffer;
	if (JFileExists(*itsSentTextFileName))
		{
		JReadFile(*itsSentTextFileName, &buffer);
		}
	os << buffer;

	GetWindow()->WriteGeometry(os);

	JXScrollbar* hsb = itsEditorSet->GetHScrollbar();
	JXScrollbar* vsb = itsEditorSet->GetVScrollbar();
	os << hsb->GetValue() << " ";
	os << vsb->GetValue() << " ";
}

/******************************************************************************
 ReadState 


 ******************************************************************************/

void
GMessageEditDir::ReadState
	(
	istream& is
	)
{
	JString buffer;
	is >> buffer;
	itsToInput->SetText(buffer);
	is >> buffer;
	itsReplyToInput->SetText(buffer);
	is >> buffer;
	itsCCInput->SetText(buffer);
	is >> buffer;
	itsBCCInput->SetText(buffer);
	is >> buffer;
	itsSubjectInput->SetText(buffer);

	JBoolean visible;
	is >> visible;
	itsShowReplyTo = visible;
	is >> visible;
	itsShowCC = visible;
	is >> visible;
	itsShowBCC = visible;
	
	is >> *itsReplyString;
	is >> *itsReplyMark;
	is >> *itsSentFrom;
	is >> *itsSentDate;

	is >> buffer;
	itsEditor->SetText(buffer);

	is >> buffer;
	if (!buffer.IsEmpty())
		{
		*itsSentTextFileName = JGetTempFileName("/tmp/");
		ofstream os(*itsSentTextFileName);
		buffer.Print(os);
		}

	GetWindow()->ReadGeometry(is);
	JCoordinate hval, vval;
	is >> hval;
	is >> vval;
	JXScrollbar* hsb = itsEditorSet->GetHScrollbar();
	JXScrollbar* vsb = itsEditorSet->GetVScrollbar();
	hsb->SetValue(hval);
	vsb->SetValue(vval);

	AdjustInputFields();
}

/******************************************************************************
 QuoteLineRange

 ******************************************************************************/

void
GMessageEditDir::QuoteLineRange
	(
	const JIndex linestart,
	const JIndex lineend
	)
{
	for (JSize i = linestart+1; i <= lineend; i++)
		{
		itsEditor->SelectLine(i-1);
		JString test;
		itsEditor->GetSelection(&test);
		test.TrimWhitespace();
		if ((test == "\n") || test.IsEmpty())
			{
			itsEditor->SelectLine(i);
			itsEditor->GetSelection(&test);
			test.TrimWhitespace();
			JString mark;
			if (test.BeginsWith(">"))
				{
				mark = ">";
				}
			else if (!test.IsEmpty())
				{
				mark = "> ";
				}
			itsEditor->GoToLine(i);
			itsEditor->Paste(mark);
			}
		}
}


/******************************************************************************
 CheckForPendingMessage

 ******************************************************************************/

void
GMessageEditDir::CheckForPendingMessage()
{
	if (itsMessage != NULL)
		{
		itsMessage->BlockUntilOkOrFail();
		}
}