/******************************************************************************
 GViewHelpText.cc

	Copyright � 1997 by John Lindal. All rights reserved.

 ******************************************************************************/

#include "GHelpText.h"

const JCharacter* kViewHelpName  = "GViewHelp";
const JCharacter* kViewHelpTitle = "Viewing mail";

const JCharacter* kViewHelpText =

"<b>Navigating within the view window</b>"
"<p>"
""
"To move to a different message from within a view window, hit the meta and "
"plus/minus. This will move you to the next/previous message that has not "
"been marked deleted. If you wish to move to the next message and also wish "
"to delete the current message, hit Control-Shift-D. To delete and close a "
"message, hit Control-D. These function can also be access via the <i>Show "
"next</i>, <i>Show previous</i>, <i>Delete and show next</i>, and <i>Delete "
"and close</i> menu items in the <i>File</i> menu."
""
"<p>"
""
"Within a message, you can view the entire message header by selecting "
"<i>Show full headers</i> from the <i>Message</i> menu."
""
"<p>"
"<b>Saving and printing</b>"
"<p>"
""
"To save a message, select <i>Save...</i> or <i>Save with headers...</i> "
"from the <i>File</i> menu. You will then be asked to name the saved "
"message. To print the message, select <i>Print...</i> or <i>Print with "
"headers...</i> from the <i>File</i> menu."
""
"<p>"
"<b>Responding</b>"
"<p>"
""
"When responding to a message, you have the choice of <i>Reply</i>, <i>Reply "
"to sender</i>, <i>Reply to all</i>, <i>Forward</i>, and <i>Redirect</i> "
"from the <i>Message</i> menu or from the appropriate buttons in the view "
"window.  Choosing <i>Reply</i> will start a new message with the sender "
"specified in the <i>To:</i> field, or, if a <i>Reply-To:</i> field was "
"listed in the original message, that address will be used for the "
"<i>To:</i> field instead. <i>Reply to sender</i> will respond to the "
"actually sender regardless of the presence of a <i>Reply-To:</i> field. "
"<i>Reply to all</i> will start a new message including every address in the "
"<i>To:</i>, <i>From:</i>, and <i>Cc:</i> fields in the message header. "
"<i>Forward</i> will start a new message with no default recipient, and the "
"message text will automatically be filled in and quoted (ie. each line will "
"have a '>' prepended to it). <i>Redirect</i> is the same as <i>Forward</i> "
"except that the message text is not quoted."
""
"<p>"
"<b>Decrypting</b>"
"<p>"
""
"If you receive a file that has been encrypted with PGP, you can decrypt it "
"by using <i>Decrypt</i> from the <i>Message</i> menu."
;
