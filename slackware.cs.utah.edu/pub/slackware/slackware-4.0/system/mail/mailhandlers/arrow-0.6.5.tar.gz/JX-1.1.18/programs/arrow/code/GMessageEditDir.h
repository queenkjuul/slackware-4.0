/******************************************************************************
 GMessageEditDir.h

	Interface for the GMessageEditDir class

	Copyright � 1997 by Glenn Bach. 

 ******************************************************************************/

#ifndef _H_GMessageEditDir
#define _H_GMessageEditDir

#include <JXWindowDirector.h>
#include <JPtrArray.h>
#include <JString.h>

class JXTextMenu;
class JXStaticText;
class JXStringInput;
class GMessageEditor;
class JXScrollbarSet;
class JXTextButton;
class JXGetPasswordDialog;
class SMTPMessage;

class GMessageEditDir : public JXWindowDirector
{
public:
	
	GMessageEditDir(JXDirector* supervisor);
	virtual ~GMessageEditDir();

	void				SetTo(const JString& to);
	void				SetCC(const JString& cc);
	void				SetSubject(const JString& subject);
	void				SetText(const JString& filename);
	void				SetSentFrom(const JString& sentfrom);
	void				SetSentDate(const JString& date);
	void				Send();
	virtual JBoolean	Close();
	void				InsertText(const JBoolean marked);
	void				SaveState(ostream& os);
	void				ReadState(istream& is);	

	void				CheckForPendingMessage();

protected:

	virtual void	Receive(JBroadcaster* sender,
								const JBroadcaster::Message& message);
private:

	JXStaticText*	itsToLabel;
	JXStaticText*	itsReplyToLabel;
	JXStaticText*	itsCCLabel;
	JXStaticText*	itsBCCLabel;
	JXStaticText*	itsSubjectLabel;
	
	JXStringInput*	itsToInput;
	JXStringInput*	itsReplyToInput;
	JXStringInput*	itsCCInput;
	JXStringInput*	itsBCCInput;
	JXStringInput*	itsSubjectInput;

	JXScrollbarSet*	itsEditorSet;
	GMessageEditor*	itsEditor;
	
	JXTextMenu*		itsFileMenu;
	JXTextMenu*		itsMessageMenu;
	JXTextMenu*		itsHelpMenu;
	JBoolean		itsShowReplyTo;
	JBoolean		itsShowCC;
	JBoolean		itsShowBCC;
	
	JString*		itsReplyString;
	JString*		itsReplyMark;
	JString*		itsSentFrom;
	JString*		itsSentDate;
	JString*		itsSentTextFileName;
	
	JXTextButton*	itsSendButton;

	JXGetPasswordDialog* 	itsPasswdDialog;
	SMTPMessage*			itsMessage;
	JString					itsFileName;
	
private:
	
	
	void		UpdateFileMenu();
	void		HandleFileMenu(const JIndex index);

	void		UpdateMessageMenu();
	void		HandleMessageMenu(const JIndex index);

	void		HandleHelpMenu(const JIndex index);

	void		BuildWindow();
	
	void		AdjustInputFields();
	void		AdjustWindowTitle();
	void		QuoteLineRange(const JIndex linestart,
								const JIndex lineend);
	
	// not allowed

	GMessageEditDir(const GMessageEditDir& source);
	const GMessageEditDir& operator=(const GMessageEditDir& source);

};

#endif
