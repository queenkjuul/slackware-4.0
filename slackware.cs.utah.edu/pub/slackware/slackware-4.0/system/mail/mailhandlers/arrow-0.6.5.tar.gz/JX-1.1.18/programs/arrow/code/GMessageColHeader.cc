/******************************************************************************
 GMessageColHeader.cc

	Maintains a row to match the columns of a JTable.

	BASE CLASS = JXEditTable

	Copyright � 1996 by John Lindal. All rights reserved.

 ******************************************************************************/

#include <GMessageColHeader.h>
#include <JXWindow.h>
#include <JString.h>
#include <JXColormap.h>
#include <jXGlobals.h>
#include <JFontStyle.h>
#include <JPainter.h>
#include <JColormap.h>
#include <jAssert.h>

const JCoordinate kMinColSize = 10;

/******************************************************************************
 Constructor

 ******************************************************************************/

GMessageColHeader::GMessageColHeader
	(
	JXTable*			table,
	JXScrollbarSet*		scrollbarSet,
	JXContainer*		enclosure,
	const HSizingOption	hSizing,
	const VSizingOption	vSizing,
	const JCoordinate	x,
	const JCoordinate	y,
	const JCoordinate	w,
	const JCoordinate	h
	)
	:
	JXColHeaderWidget(table, scrollbarSet, enclosure, hSizing,vSizing, x,y, w,h)
{
	TurnOnColResizing(kMinColSize);
	SetBackColor(GetColormap()->GetWhiteColor());
	SetColBorderInfo(1, GetColormap()->GetDefaultBackColor());
}

/******************************************************************************
 Destructor

 ******************************************************************************/

GMessageColHeader::~GMessageColHeader()
{
}

/******************************************************************************
 TableDrawCell (virtual protected)

	We provide a default implementation, for convenience.

 ******************************************************************************/

void
GMessageColHeader::TableDrawCell
	(
	JPainter&		p,
	const JPoint&	cell,
	const JRect&	rect
	)
{
	JString str;
	JBoolean hasTitle = GetColTitle(cell.x, &str);
	p.SetFont(JGetDefaultFontName(), 12,
			  JFontStyle());
	if (hasTitle)
		{
		p.String(rect, str, JPainter::kHAlignCenter, JPainter::kVAlignCenter);
		}
}
