/******************************************************************************
 GMGlobals.h

 *****************************************************************************/

#ifndef _H_GMGlobals
#define _H_GMGlobals

// we include these for convenience

#include <JString.h>

#include <jXGlobals.h>
#include <jTypes.h>
#include <JXTextClipboard.h>

class GMApp;
class SMTPDebugDir;
class GAddressBookMgr;
class GPrefsMgr;
class GInboxMgr;
class JXSRTextDialogBase;

GMApp*				GMGetApplication();
void				GMSetSMTPDebugDir(SMTPDebugDir* dir);
SMTPDebugDir*		GMGetSMTPDebugDir(); 
GAddressBookMgr*	GGetAddressBookMgr();
GPrefsMgr*			GGetPrefsMgr();
GInboxMgr*			GGetInboxMgr();

void				GCheckPGP();
JBoolean			GPGPEnabled();

JBoolean			GSpellCheckEnabled();

void				GBlockUntilFileUnlocked(const JCharacter* filename);
JBoolean			GLockFile(const JCharacter* filename);
JBoolean			GFileLocked(const JCharacter* filename);
void				GUnlockFile(const JCharacter* filename);

JBoolean			GProgramIsDying();
void				GSetProgramDying();

void				GQuoteString(JString* text, const JBoolean quoteFirst);

JXTextClipboard*	GMGetTextClipboard();
void				GMUpdateTextClipboard();
void				GCheckMail();
JXSRTextDialogBase*	GetSearchDialog();

	// called by TestApp

JBoolean 	GMCreateGlobals(GMApp* app);
void 		GMDeleteGlobals();

#endif
