/******************************************************************************
 SMTPDebugDir.cc

	BASE CLASS = JXWindowDirector

	Copyright � 1997 by Glenn Bach. All rights reserved.

 ******************************************************************************/

#include "SMTPDebugDir.h"

#include <JXStaticText.h>
#include <JXScrollbarSet.h>
#include <JXWindow.h>

#include <JString.h>

#include <GMGlobals.h>

#include <iostream.h>
#include <jAssert.h>

/******************************************************************************
 Constructor

 ******************************************************************************/

SMTPDebugDir::SMTPDebugDir
	(
	JXDirector* supervisor
	)
	:
	JXWindowDirector(supervisor)
{
	JXWindow* window = new JXWindow(this, 400,300, "Debug Window");
    assert( window != NULL );
    SetWindow(window);
    window->SetCloseAction(JXWindow::kDeactivateDirector);
    
	JXScrollbarSet* scrollbarSet = 
		new JXScrollbarSet(window,
			JXWidget::kHElastic, JXWidget::kVElastic, 
			0,0,400,300);
	assert ( scrollbarSet != NULL );
	
	itsText = 
		new JXStaticText("", kFalse, kTrue,
			scrollbarSet, scrollbarSet->GetScrollEnclosure(),
			JXWidget::kHElastic, JXWidget::kVElastic, 
			0,0,400,300);
	assert (itsText != NULL);
	GMSetSMTPDebugDir(this);
}

/******************************************************************************
 Destructor

 ******************************************************************************/

SMTPDebugDir::~SMTPDebugDir()
{
}

/******************************************************************************
 Receive

 ******************************************************************************/

void
SMTPDebugDir::Receive
	(
	JBroadcaster* sender,
	const JBroadcaster::Message& message
	)
{
	JXWindowDirector::Receive(sender, message);
}

/******************************************************************************
 Receive

 ******************************************************************************/

void
SMTPDebugDir::AddText
	(
	const JCharacter* text
	)
{
	JSize count = itsText->GetTextLength();
	itsText->SetCaretLocation(count);
	itsText->Paste("\n");
	itsText->Paste(text);
}