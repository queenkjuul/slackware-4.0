/******************************************************************************
 JXTimerTask.cc

	Idle task to update a directory listing.

	BASE CLASS = JXIdleTask

	Copyright � 1998 by Glenn W. Bach. All rights reserved.

 ******************************************************************************/

#include <JXTimerTask.h>

#include <jXGlobals.h>

const JCharacter* JXTimerTask::kTimerWentOff = "JXTimerTask::kTimerWentOff";

/******************************************************************************
 Constructor

 ******************************************************************************/

JXTimerTask::JXTimerTask
	(
	const Time updateTime,
	const JBoolean oneShot
	)
	:
	JXIdleTask(updateTime)
{
	itsIsOneShot = oneShot;
}

/******************************************************************************
 Destructor

 ******************************************************************************/

JXTimerTask::~JXTimerTask()
{
}

/******************************************************************************
 Perform

 ******************************************************************************/

void
JXTimerTask::Perform
	(
	const Time	delta,
	Time*		maxSleepTime
	)
{
	if (TimeToPerform(delta, maxSleepTime))
		{		
		Broadcast(TimerWentOff());
		if (itsIsOneShot)
			{
			JXGetApplication()->RemoveIdleTask(this);
			delete this;
			}
		}
}
