/******************************************************************************
 JXGetPasswordDialog.h

	Interface for the JXGetPasswordDialog class

	Copyright @ 1997 by Glenn W. Bach.

 ******************************************************************************/

#ifndef _H_JXGetPasswordDialog
#define _H_JXGetPasswordDialog

#include <JXDialogDirector.h>

class JXPasswordInput;
class JString;

class JXGetPasswordDialog : public JXDialogDirector
{
public:

	JXGetPasswordDialog(JXDirector* supervisor);

	virtual ~JXGetPasswordDialog();
	
	const JString& GetPassword();
	
protected:
	
private:

	JXPasswordInput*	itsInput;

private:

	void	BuildWindow();

	// not allowed

	JXGetPasswordDialog(const JXGetPasswordDialog& source);
	const JXGetPasswordDialog& operator=(const JXGetPasswordDialog& source);
};

#endif
