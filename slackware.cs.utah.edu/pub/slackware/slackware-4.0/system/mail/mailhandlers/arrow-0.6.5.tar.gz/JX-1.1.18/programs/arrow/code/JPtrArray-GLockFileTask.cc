#include <GLockFileTask.h>
#include <JArray.tmpls>
#define JTemplateType GLockFileTask
#include <JPtrArray.tmpls>
