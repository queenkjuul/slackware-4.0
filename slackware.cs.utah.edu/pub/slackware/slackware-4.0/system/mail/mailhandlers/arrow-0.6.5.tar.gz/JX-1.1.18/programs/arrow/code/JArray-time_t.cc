#include <time_t.h>
#define JTemplateType time_t
#include <JArray.tmpls>
