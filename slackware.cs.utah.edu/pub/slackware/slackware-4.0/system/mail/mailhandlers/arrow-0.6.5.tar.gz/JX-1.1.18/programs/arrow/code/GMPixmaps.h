/******************************************************************************
 GMPixmaps.h

	Copyright � 1998 by Glenn W. Bach. All rights reserved.

 ******************************************************************************/

#ifndef _H_GMPixmaps
#define _H_GMPixmaps

#include <JXImage.h>

const JSize kAboutIconCount = 8;

extern JXPM kAboutIcon[ kAboutIconCount ];

#endif
