#!/usr/bin/perl

%config = ('from_address', "gna\@gnacademy.org",
	   'bounce_address', "gna-errors\@gnacademy.org",
	   'web_command', "/var/local/gna/bin/lynx -dump",
	   'sendmail', '/usr/lib/sendmail -t ',
	   'password_address', "gna-services\@uu-gna.mit.edu",
	   'awk', "/afs/athena.mit.edu/project/gnu/gbin/awk",
	   'rdb_dir', "/u1/ejs",
	   'co', "/usr/athena/bin/co",
	   'ci', "/usr/athena/bin/ci");

# What the variables mean

# from address - The address that your e-mail will be from
# bounce_address - The address to which the bounces will be forwarded to
# web_command - This is a command that takes a URL and outputs the
#               page correspending to that URL
# sendmail - The location of your sendmail mailer
# password_address - The address that people should ask for passwords
# awk - The location of the "awk" program
# rdb_dir - If you are using this package with /rdb database scripts
#           this is the root directory of those scripts
# co - The location of the co command used with RCS
# ci - The location of the ci command used with RCS

use lib "/var/local/gna/uu-gna/tech/dbedit/src";

# Put the GNU utilities in front so that one uses the GNU routines instead
# of the standard UNIX ones.  The standard Ultrix sort and awk have in 
# board limits.

$ENV{'PATH'} = "/afs/athena.mit.edu/project/gnu/gbin:" . $ENV{'PATH'};









