
   Frontdesk
   
                                   FRONTDESK
                                       
   Frontdesk is an groupware application designed for customer support
   and bug tracking. People e-mail their messages into a threaded central
   repository which may be accessed via the web
   
What's new?

     * Removed some code which is useful only at the gna site
     * Added feature to attach the name of the replier in the from line
     * Added instructions which on how to get frontdesk to receive mail
       
Source

   The current version of frontdesk is 0.3 and is available as a gzip'ed
   tar file from
   [1]http://admin.gnacademy.org:8001/uu-gna/tech/dbedit/frontdesk-0.3.t
   ar.gz,
   
Support

   The frontdesk home page is
   [2]http://admin.gnacademy.org:8001/uu-gna/tech/dbedit/frontdesk.html
   
   There is an informal support and development mailing list
   dbedit@gnacademy.org, which you can subscribe to by e-mail
   majordomo@gnacademy.org with the message

subscribe dbedit

   
   
   Please post your patches, suggestions, and bug reports to that
   list!!!!
   
License

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   Library Public License for more details.
