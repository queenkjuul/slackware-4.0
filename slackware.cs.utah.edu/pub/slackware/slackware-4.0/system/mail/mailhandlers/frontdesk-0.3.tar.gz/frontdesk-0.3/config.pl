
$title = "GNA Mail Handler";
$rootdir = "/var/local/gna/uu-gna/admin/frontdesk";
$rooturl = "http://www.gnacademy.org:8001/gna-frontdesk";
$prefix = "gna-frontdesk-";
$from = "gna\@gnacademy.org";
$errors_to = "gna-errors\@gnacademy.org";
$default_queue = "pending";

$from_queue{'catalog'} = "catalog\@gnacademy.org";
$from_queue{'bookstore'} = "bookstore\@gnacademy.org";
$from_queue{'president'} = "president\@gnacademy.org";
$from_queue{'secretary'} = "secretary\@gnacademy.org";
$from_queue{'jumbo'} = "jumbo\@gnacademy.org";

# Notify queue.  Send e-mail to the following addresses if message
# is moved into those queues

$notify_queue{'president'} = "joe\@mit.edu";
$notify_queue{'secretary'} = "frosc000\@mail.uni-mainz.de";

# Forward queue.  Send e-mail to the following addresses if a message
# is added to these queues

$forward_queue{'president'} = "joe\@mit.edu";

# Items moved into these queues are considered read
$mark_read{'done'} = 1;

# Items moved into these queues are considered unread
$mark_unread{'president'} = 1;

$newqueue{"gna-president\@uu-gna.mit.edu"} = "president";
$group = "majordom";

# This is the absolute pathname of some programs

%programs = (
"agrep", "/afs/athena.mit.edu/contrib/watchmaker/bin/agrep");

# Heaader
$header = <<EOP;
<body bgcolor="#ffffff">
<h1><IMG src="/uu-gna/admin/emblems/gna-logo-small.gif" alt="GNA">GNA Mail System</h1>
<font size=+1><a href=/uu-gna/admin/secretariat/instructions/frontdesk.html>Mailing list instructions</a></font>
<p>
EOP


# The user hash contains the real names of the user
%user = ("foo_user", "Foo User");

# The following loads the usernames from an rdb table
$personnel_dir = "/var/local/gna/uu-gna/tables/gna-admin-dir.rdb";
if (-e $personnel_dir) {
    local($line, @fields, %f);
    open(USER_FILE, $personnel_dir);
    $line = <USER_FILE>;
    chop $line;
    @fields = split(/\t/, $line);
    $line = <USER_FILE>;
    while($line = <USER_FILE>) {
       chop $line;
       @f{@fields} = split(/\t/, $line);
       $user{$f{"web_username"}} = "$f{'name_first'} $f{'name_middle'} $f{'name_last'} $f{'name_suffix'}";
    }
    close(USER_FILE);
}

