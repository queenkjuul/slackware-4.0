sub gna_frontdesk_add_to_list {
    local($filename, $item) = @_;
    local($_);
    open (LISTFILE, $filename) || print "Cannot open $filename";
    while (<LISTFILE>) {
	chop;
	if ($_ eq $item) {
	    return;
	}
    }
    close (LISTFILE);

    if (!-w $filename) {
	`mv -f $filename $filename.bak
cp -f $filename.bak $filename`;
    }

    open (LISTFILE, ">>$filename");
    print LISTFILE $item, "\n";
    close(LISTFILE);

    &gna_frontdesk_permissions_filename($filename);
}

sub gna_frontdesk_remove_from_list {
    local($filename, $item) = @_;
    local($_);
    `mv -f $filename $filename.bak`;
    open (OLDLISTFILE, "$filename.bak");
    open (LISTFILE, ">$filename");
    while(<OLDLISTFILE>) {
	chop;
	($_ ne $item) &&
	    print LISTFILE "$_\n";
    }
    close(LISTFILE);
    close(OLDLISTFILE);
    &gna_frontdesk_permissions_filename($filename); 
}

sub gna_frontdesk_load_list {
    local($filename, *array) = @_;
    open (LISTFILE, "$filename");
    while (<LISTFILE>) {
	chop;
	$array{$_} = 1;
    }
    close(LISTFILE);
}
1;
