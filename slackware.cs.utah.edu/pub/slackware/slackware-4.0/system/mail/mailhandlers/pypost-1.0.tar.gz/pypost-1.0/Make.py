#!/usr/bin/env python

print """

Starting Make.py.  If there are any problems with this, please mail me
at bescoto@stanford.edu.

I encourange anyone who is interested in Pypost to join the Pypost and
Mapil mailing list by sending a message to
majordomo@lists.stanford.edu with "subscribe mapil-list" on a blank
line (omit the quotes).  Volume is expected to be quite low.

"""

import os, sys, string, marshal, py_compile

print """
To save time loading, this script will byte compile the mapil.py file,
producing a pypost.pyc file.  A small bootstrap script called 'pypost'
will be created in this directory.  Then, whenever Pypost is run,
python will execute the byte code instead of the pypost.py source,
cutting loading time by about 75%.

Creating pypost.pyc..."""
py_compile.compile('pypost.py', 'pypost.pyc')
sys.stdout.write('Done, press return to continue: ')
sys.stdin.readline()
print """

In order to create the 'pypost' loader, this script needs to know
where you intend to put 'pypost.py' and 'pypost.pyc' if it is not in
the python module search path.  Here are the currently searched
directories: """

for directory in sys.path:
    print directory

print """

If you intend to place pypost in one of these directories, leave the
following prompt blank.  Otherwise, enter the directory where
'pypost.py' and 'pypost.pyc' will go."""

while 1:
    print
    sys.stdout.write("Directory: ")
    dir = string.strip(sys.stdin.readline())

    if not dir:
	print 'Assuming files will be found by normal module search.'
	break
    else:
	try: os.stat(dir)
	except:
	    print 'Error, directory not found'
	    continue

	print 'Directory ' + dir + ' found.'
	break

print
print "Creating 'pypost' loader..."
fpmapil = open('pypost', 'w')
fpmapil.write('#!/usr/bin/env python\n')
if dir:
    fpmapil.write('import sys\n')
    fpmapil.write("sys.path.append('" + dir + "')\n")
fpmapil.write('import pypost\n')
fpmapil.close()
os.chmod('pypost', 0755)

print """

That's it!  Now just copy 'pypost' to a convenient location (say,
/usr/local/bin) and copy 'pypost.py' and 'pypost.pyc' to the
appropriate directory you decided on above.  You may also want to
install the manual page pypost.1.

"""
