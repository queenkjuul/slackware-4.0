#!/usr/bin/env python

# Pypost - Python Post
#
# A sendmail replacement that performs arbitrary processing on a
# message and then passes it on to sendmail or an SMTP gateway.

import os, sys, rfc822, tempfile, string

Settings = {'Verbose':0}



############################################################
##############  Code borrowed from Mapil ###################
############################################################

def ParseLine(line):
    # This is used in a few different places, like for recipients
    # given on the command line or the prompt, and for parsing the
    # policies and configuration file.  Returns a list of strings.

    outlist = []
    i = 0
    length = len(line)

    while i < length:
	field, i = GetField(line, i)
	if not field:
	    break
	outlist.append(field)

    return outlist


def GetField(str, i):
    # Get the quoted field used in the policies file starting at position
    # i of the string str.  Return a tuple of the field, and the next
    # position of the string after the field.  Bypasses initial
    # whitespace Returns None, 0 if parse error

    length = len(str)

    while str[i] in string.whitespace:
	i = i+1
	if i == length:
	    return None, 0
    start = i

    if str[i] in string.letters+string.digits+'~/':
	while not (i == length or \
		   str[i] in string.whitespace):
	    i = i+1
	return str[start:i], i
    else:
	# Field is quoted
	quotechar = str[i]
	i = i+1
	if i == length:
	    return None, 0

	while not str[i] == quotechar:
	    i = i+1
	    if i == length:
		return None, 0
	return str[start+1:i], i+1


class MyMessage(rfc822.Message):

    # Like MimePart in the mapil distribution, but with a lot of stuff
    # missing.

    def GetHeaderPos(self, name):
	# Return index of first header line in self.headers starting with
	# name:.  If not found, return -1.

	length = len(name)+1
	name = string.lower(name)

	for i in range(len(self.headers)):
	    if string.lower(self.headers[i][:length]) == name+':':
		return i

	return -1


    def RemoveHeader(self, name):
	# Removes header matching name

	i = self.GetHeaderPos(name)
	if i != -1:
	    length = len(self.getfirstmatchingheader(name))
	    del self.headers[i:i+length]


    def GetAddresses(self):
	# Returns a list of the email address occuring in the To:,
	# Cc:, Bcc:, and Dcc: headers of a message, only in lower case.
	# My attempt at a obfuscated one-liner

	return map(string.lower, map(lambda t: t[1], \
		reduce(lambda x,y: x+y, map(self.getaddrlist, \
					    ['To','Cc','Bcc','Dcc']))))


##################################################################
###########    Smtp code, courtesy of Mike Meyer    ##############
##################################################################

"""An smtp client class.

Based on rfc 821. Service extensions are not yet supported.  Each smtp
object is an open connection to an SMTP server which lets you deliver
one or more mail messages to that server.

What makes SMTP clients hard is two unusual conditions in sending
mail: 1) that the destination host may be something different from the
host in the address, which is specified by an MX in the DNS database;
2) the correct server may be down, which requires that the client
queue the message and retry later. Both those conditions are handled
the same way - by punting. No MX lookup is done. If the host in the
destination address is unreachable for any reason - currently down, or
this host has an MX record and isn't running an SMTP connection, we
try a second host, the local smtp server. The name of that host is the
'gateway' instance variable. It can be set as a keyword argument to
the smtp instance initialization. The default for the default is in
the module global variable 'defaultgateway'. It's normal value is
localhost, which will work for most Unix workstations, but probably
not other systems. The best way to change that is to set it correctly
for your installation in the local copy of smtp.py. If you want to use
a specific gateway, use the instance initialization override.

If you're going to set gateway, you might consider changing
'defaultdirect' at the same time. If defaultdirect is false, then mail
is just forwarded to the gateway, without bothering to try a direct
delivery. This is usefull at sites that don't allow outgoing smtp from
arbitrary hosts.

I'd love to have a better way of handling the gateway stuff. A good
start would be the ability to do an MX lookup before sending the mail.
"""

defaultgateway = 'localhost'	# Correct if you're running an SMTP server
defaultdirect = 1		# If false, then we by default skip trying
				# to send to the destination address
defaultport = 25		# default for the SMTP service

import os, string

# Import SOCKS module if it exists, else standard socket module socket
try:
    import SOCKS; socket = SOCKS
except ImportError:
    import socket

# Line terminators (we always output CRLF, but accept any of CRLF, CR, LF)
CRLF = '\r\n'

# Exception raised on error or invalid response
error = "smtp.error"

# Names of states we track internally
init = 0		# No connection established.
connected = init + 1	# We have a connection
sender = connected + 1	# Have successfully issued the "MAIL" command
recipient = sender + 1	# Have set up a list of users
			# DATA is next, whence we go back to connected

class SMTP:
    """Create a connection to an smtp host to send mail to.
    
    Initialization keyword arguments:
    host - to connect to if not the one specified in the first destination
	   address.
    port - to connect to if not the default smtp port.
    my_name
    gateway - the smarter server that we hand off failures to.
    direct - True to try a direct connection to the host, false otherwise.
    name - the host name to use when we connect to the outside world,
	   if it's not my host name.
    debuglevel - set the debug output level. 0 -> none; 1 -> command/response;
    	   2 -> everything

    Note: see the module comments for more on gateway & direct.

    Public methods:
    mail - This signals we are starting a new message. There is one optional
	   argument, an email address. If it is provided, then that will
	   be the default SMTP from address. if it is not provided, the
	   current users id at the instance variable name will be used.
    
    to - This has one or more arguments, which are the email address
	 that the mail is to be sent to.

    send - This has one argument, the message text of the message to send.
	   That argument is a list of lines to be written out. Line
	   terminators are optional, and will be stripped off by the method
	   before sending, and RFC-821 valid values used.

    close - no arguments. This closes the connections.

    get_welcome - no arguments. This returns the response to the connection.

    set_debuglevel - Sets the debug level to the argument argument.


    Example Usage (but lots of variants are possible):
    	s = smtp.SMTP('destinationhost')
	r1 = s.mail('from-name')
	r2 = s.to('recipient1', 'recipient2')
	r3 = s.send(['list', 'of', 'message', 'lines'])
	r4 = s.mail('other-from-name')
	r5 = s.to('other-recipient1', 'other-recipient2', 'other-recipient3')
	r6 = s.send(['another', 'list', 'of', 'lines'])
	s.close()
    """

    def __init__(my, host = None, port = None, name = None, gateway = None,
		 direct = None, debuglevel = 0):
	my.host = host
	my.port = port or defaultport
	my.name = name or socket.gethostname()
	my.gateway = gateway or defaultgateway
	my.direct = direct or defaultdirect
	my.debuglevel = debuglevel
	my.state = init

	if host: my.connect()

    def mail(my, user = None, host = None):
	"""Set up to send mail. It will be from the string USER, or the
	environment variable LOGNAME if no user is specified. If we aren't
	already connected, try to connect to host, or localhost if no host is
	specified."""

	if my.state == init: my.connect(host)
	if my.state != connected:
	    raise error, "Tried to start message in state " + my.state

	response = my.send_command('MAIL FROM:<%s>' %
				   (user or os.environ['LOGNAME']))
	if response[0] not in '12': raise error, response
	my.state = sender
	return response

    def to(my, *to):
	"""Add a set of users to the outbound message now being built. If
	no from address has been set, set it to the default, and ask
	for a host connection to the hostname in the first to address."""

	if my.state < sender:
	    my.mail(host = string.split(to[0], '@')[-1])

	good, bad = [], []
	for user in to:
	    response = my.send_command('RCPT TO:<%s>' % user)
	    if response[0] in '12': good.append(user)
	    else: bad.append(user, response)
	my.state = recipient
	return good, bad
	    
    def send(my, message):
	"Sends the text in the message list as data lines for the messages."

	if my.state != recipient: raise error, "No recipient specified"

	send_response = my.send_command('DATA')
	if send_response[0] != '3': raise error, send_response
	for line in message:
	    if line[0] == '.': my.send_line('.' + line)
	    else: my.send_line(line)
	response = my.send_command('.')
	if response[0] not in '12': raise error, response
	my.state = connected
	return response
    
    def sendfp(my, fp):
	"I wrote this so the message wouldn't have to be given in memory."

	if my.state != recipient: raise error, "No recipient specified"

	send_response = my.send_command('DATA')
	if send_response[0] != '3': raise error, send_response

	line = fp.readline()
	while(line):
	    if line[-2:] == CRLF:
		line = line[:-2]
	    elif line[-1:] in CRLF:
		line = line[:-1]
	    if line and line[0] == '.': my.send_line('.' + line)
	    else: my.send_line(line)
	    line = fp.readline()

	response = my.send_command('.')
	if response[0] not in '12': raise error, response
	my.state = connected
	return response


    def close(my):
	"We're done, so shut it down nicely."

	my.send_command('RSET')
	my.send_command('QUIT')
	my.sock.close()
	my.file.close()

    def get_welcome(my):
	"Returns the response we got during the connect."

	return my.welcome

    def set_debuglevel(my, level):
	"""Set the debugging level.
	The required argument level means:
	0: no debugging output (default)
	1: print commands and responses but not body text etc.
	2: also print raw lines read and sent without line terminators"""

	my.debuglevel = level

    #
    # Utilities meant for internal use.
    #

    def connect(my, host = None):
	"Internal utility to open a connection to send  mail over."

	my.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	if not my.host: my.host = host or my.gateway
	if not my.direct: my.sock.connect(my.gateway, my.port)
	else: 
	    try: my.sock.connect(my.host, my.port)
	    except socket.error:
		my.sock.connect(my.gateway, my.port)
	my.file = my.sock.makefile('rb')
	my.welcome = my.get_response()
	my.state = connected
	return my.send_command('HELO ' + my.name)

    def send_line(my, line):
	"Internal routine to send a line to the server with optional debugging"

	if my.debuglevel > 1: print '*SEND*', line
	my.sock.send(line + CRLF)

    def send_command(my, command):
	"""Internal routine to send a command to the server
	with optional debugging."""

	if my.debuglevel: print "*CMD*", command
	my.send_line(command)
	return my.get_response()

    def get_line(my):
	"""Internal routine to get a line from the server
	with optional debugging."""

	line = my.file.readline()
	if not line: raise error, 'EOF'
	if line[-2:] == CRLF: line = line[:-2]
	elif line[-1] in CRLF: line = line[:-1]
	if my.debuglevel > 1: print '*GET*', line
	return line

    def get_multiline(my):
	"Internal routine to get a multiline response from the server."

	line = my.get_line()
	code = line[:3]
	if line[3] == '-':
	    code = line[:3]
	    while 1:
		more = my.get_line()
		line = line + '\n' + more
		if more[3] != '-': break
	return line

    def get_response(my):
	"Internal routine to get a response from the server."

	response = my.get_multiline()
	if my.debuglevel: print "*RESP*", response
	my.last_response = response
	c = response[0]
	if c not in '12345': raise error, response
	return response


###################################################################
############## Code I actually wrote for Pypost ###################
###################################################################

class MessageOutput:

    # This class is initialized by a message and returns an object
    # with a readline() method, which returns the headers one by one,
    # a blank line, M.removedline if it exists, and then the rest of
    # the data through the file pointer.  The file pointer is
    # consumed, but nothing else is changed.

    def __init__(self, message):
	self.message = message
	self.position = 0

    def readline(self):

	if self.position < len(self.message.headers):
	    self.position = self.position + 1
	    return self.message.headers[self.position - 1]

	elif self.position == len(self.message.headers):
	    self.position = self.position + 1
	    return '\r\n'

	elif self.position == len(self.message.headers) + 1:
	    self.position = self.position + 1
	    if hasattr(self.message, 'removedline'):
		return self.message.removedline
	    else: return self.message.fp.readline()

	else: return self.message.fp.readline()



def Report(message):
    if Settings['Verbose']:
	print message


def Exit(errlvl):
    if Settings.has_key('Filename'):
	try: os.remove(Settings['Filename'])
	except: pass

    Report('Exiting with errorlevel '+str(errlvl))
    sys.exit(errlvl)


def Init():
    # read configuration file and set aliases and Settings
    # Mostly taken from Mapil, as is Parseline function.

    os.umask(077)

    if os.environ.has_key('PYPOSTRC'):
	rcfilename = os.environ['PYPOSTRC']
    elif os.environ.has_key('HOME'):
	rcfilename = os.environ['HOME']+'/.pypostrc'
    else: rcfilename = '.pypostrc'

    if os.environ.has_key('PYPOST_VERBOSE'):
	Settings['Verbose'] = 1

    if os.environ.has_key('SMTPGATEWAY'):
	Settings['SmtpGateway'] = os.environ['SMTPGATEWAY']

    if os.environ.has_key('SENDMAIL'):
	Settings['Sendmail'] = os.environ['SENDMAIL']

    # Read configuration file.  This was called ConfigSettings in
    # mapil.
    try: f = open(rcfilename)
    except (IOError, TypeError):
	Report('Unable to open rcfile '+rcfilename)

    else:
	linenum = 1
	curline = f.readline()
	while curline:
	    curline=string.lstrip(curline)

	    if curline and curline[0] != '#':
		l = ParseLine(curline)
		if len(l) <= 1:
		    Report('Parse error in config file line '+str(linenum))
		    Exit(2)
		if len(l) == 2:
		    Report('Setting ' + l[0] + ' to ' + l[1])
		    Settings[l[0]]=l[1]
		else:
		    Settings[l[0]]=l[1:]
	
	    linenum=linenum+1
	    curline = f.readline()

	f.close()

    Report('Command line arguments: '+str(sys.argv))

    # Set some variables depending on the settings in config file
    if Settings.has_key('TempDir'):
	tempfile.tempdir = Settings['TempDir']


def GetMessage():
    # If only one option, and it is readable, return message object
    # from that option.  Else return message based on stdin.

    if len(sys.argv) == 2:
	try: os.stat(sys.argv[1])
	except os.error:
	    pass
	else:
	    try: fp = open(sys.argv[1])
	    except: pass
	    else:
		# Message is stored in filename sys.argv[1]
		if Settings.has_key('SendmailArgs'):
		    sys.argv[1:] = [Settings['SendmailArgs']]
		else: sys.argv[1:] = ['-oeq -t']

		return MyMessage(fp)

    return MyMessage(sys.stdin)


def GetCmdList(M):
    # Reads message M looking for X-Pypost: header or X-Pypost: in
    # first line of message.  It then removes the line (only one line
    # will be removed), and then splits the field by ",".

    # Set cmdlist to list of commands found after x-pypost:
    commands = M.getheader('x-pypost')
    if commands:
	M.RemoveHeader('x-pypost')
    else:
	line = M.fp.readline()
	if string.lower(line[:9]) == 'x-pypost:':
	    commands = string.strip(line[9:])
	else:
	    M.removedline = line

    # Use commands from DefaultCmd if none specified
    if not commands:
	if Settings.has_key('DefaultCmd'):
	    commands = Settings['DefaultCmd']
	else:
	    Report('Returning null command list')
	    return []

    cmdlist = map(string.strip, string.split(commands, ','))

    # Substitute for aliases
    while 1:
	for i in range(len(cmdlist)):
	    if Settings.has_key('Alias-'+cmdlist[i]):
		Report('Substituting '+cmdlist[i]+' for ' + \
		       Settings['Alias-'+cmdlist[i]])
		cmdlist[i:i+1] = map(string.strip,
				     string.split(Settings['Alias-' + \
							   cmdlist[i]], ','))
		break
	else: break

    # Make sure no null commands in list
    while 1:
	try: cmdlist.remove('')
	except ValueError:
	    Report('Returning cmdlist: ' + str(cmdlist))
	    return cmdlist


def SaveToTemp(Message):
    # Save Message into a temp file, return filename.

    tempfn = tempfile.mktemp()
    try: tempfp = open(tempfn, 'w')
    except IOError:
	Report('Unable to create tempfile ' + tempfn)
	Exit(4)

    MO = MessageOutput(Message)
    line = MO.readline()
    while line:
	tempfp.write(line)
	line = MO.readline()

    tempfp.close()
    return tempfn


def ProcessCmd(command):
    # Run command on filename, exit if non-zero exit status.

    # Add message argument, either through %M or at end
    i = 0
    while i < len(command) - 1:
	if command[i:i+2] == '%M':
	    command = command[:i] + Settings['Filename'] + command[i+2:]
	    break
	i = i + 1
    else: command = command + ' ' + Settings['Filename']

    # Now run the command with system
    errlvl = os.system(command)
    if errlvl != 0:
	Report('Command ' + command + ' returned with errlvl ' + str(errlvl))
	Exit(5)


def Sendmail(filename):
    # Send the data from filep to sendmail.

    if Settings.has_key('Sendmail'):
	sendmail = Settings['Sendmail']
    else:
	try: os.stat('/usr/lib/sendmail')
	except: sendmail = 'sendmail'
	else: sendmail = '/usr/lib/sendmail'

    commandstr = sendmail + ' ' + string.join(sys.argv[1:]) + \
		 ' < ' + filename
    Report('Running: '+commandstr)
    errlvl = os.system(commandstr)

    Report('Sendmail exited with error level: '+str(errlvl))
    Exit(errlvl)


def SmtpSend(M):
    # Send Message to SMTP Gateway

    try:
	s = SMTP(Settings['SmtpGateway'], None, None, Settings['SmtpGateway'])
	s.defaultdirect = 0
    except (socket.error, error):
	Report('SMTP error')
	Exit(8)

    if Settings['Verbose']:
	s.set_debuglevel(2)

    # Get the recipients and remove the Bcc: and Dcc: headers
    recipients = M.GetAddresses()
    M.RemoveHeader('dcc')
    M.RemoveHeader('bcc')

    # get return address
    if Settings.has_key('ReturnAddress'):
	returnaddress = Settings['ReturnAddress']
    else:
	addr = M.getaddr('from')
	if addr:
	    returnaddress = addr[1]
	else: returnaddress = 'unknown'

    # Send the message - this is straight from the SMTP example
    try:
	s.mail(returnaddress)
	apply(s.to, tuple(recipients))
	s.sendfp(MessageOutput(M))
	s.close()
    except (socket.error, error):
	Report('SMTP error')
	Exit(8)
    else:
	Report('Successfully sent by SMTP')
	Exit(0)


def Main():
    # This is called first (and last)

    Init()
    M = GetMessage()

    # Check to see if have message
    if not M.headers:
	Report('No message found')
	Exit(3)

    cmdlist = GetCmdList(M)

    # If cmdlist is empty and sending to SMTP Gateway, no need to
    # write to file.
    if Settings.has_key('SmtpGateway') and not \
       Settings.has_key('Sendmail') and not cmdlist:
	Report('Saving to file not necessary.')
	SmtpSend(M)

    else:
	Settings['Filename'] = SaveToTemp(M)
	map(ProcessCmd, cmdlist)

	# Now either send by SMTP or sendmail
	if Settings.has_key('SmtpGateway') and \
	   not Settings.has_key('Sendmail'):

	    # We need to reload message into M for SMTP
	    try: fp = open(Settings['Filename'])
	    except os.error:
		Report('Unable to open temp file '+Settings['Filename'])
		Exit(7)

	    SmtpSend(MyMessage(fp))

	else:
	    Sendmail(Settings['Filename'])

    # We should never get to this point :)
    Exit(6)


# Start
Main()
