#!/bin/bash
# ^^^^^^^^^ this program uses the Bourne Again Shell!!!
#
# AntiJunk (version 6.1 - beta) - 21/May/1998 - written by ste.b@theoffice.net (Stephen Bowyer)
#
# please send any changes and/or bug reports to ste.b@theoffice.net, thank you.
#

# variables
# ---------


AJ_USER=$LOGNAME
	# ^^ the users name, taken automatically from the $LOGNAME variable

AJ_MAILQ=/var/spool/mail
	# ^^ where messages are stored after spooling

AJ_INOUT=ajinout.sh
	# ^^ location and filename of the file distributed as "ajinout.sh"

AJ_USERFILE=$HOME/.AJsettings
	# ^^ location and filename of the personal user settings file

AJ_TMP=/tmp
	# ^^ location of temp space



# THE NEXT FEW VARIABLES ARE DEFAULT ONLY, AND MAY BE CHANGED BY USER



AJ_SUBWORDS="limited offer
free
offer
affordable
now
$
buy
FREE
NOW
Buy"
	# ^^ list of words that are selected from the subject line

AJ_MAIWORDS="limited offer
free
offer
cheap
affordable
$
buy
FREE
NOW
Buy"
	# ^^ **THIS IS NOT CURRENTLY USED (as per version 1 to 4)**

AJ_ACTION="add"
	# ^^ 	add - add "(SPAM)" to beginning of message
	#	del - delete message
	#	1   - forward mail to $AJ_ACTUSE
	#	2   - save mail in file named $AJ_ACTUSE
	# **currently only "add" works**


AJ_ACTUSE="**not currently used!!!**"

AJ_COMPLAIN="no"
	# ^^ **not currently used**, will send a message to person
	# in the FROM: field of message

AJ_CHK="1"
	# ^^	1 - check subject and main body of message
	#	2 - check subject only
	#	3 - check main body only
	#	4 - check nothing



# DO NOT EDIT BELOW THIS LINE!!!!!!!!!!!




AJ_VERSION="6.1 - beta"
AJ_UNDERLI="----------"
AJ_EOFMARKER="************EOF***AntiJunk****oaihsgdiufdoi@@@@@@@@lkjasldfkjasd"
AJ_ADD="X-AntiJunk: AntiJunk $AJ_VERSION (for info email ste.b@theoffice.net)"
AJ_SPC="!SPC!55b0m.@*"
AJ_TAB="!TAB!9g90m.@*"

export AJ_VERSION
export AJ_UNDERLI
export AJ_EOFMARKER
export AJ_MAILQ
export AJ_INOUT
export AJ_USER
export AJ_ADD
export AJ_TMP
export AJ_USERFILE
export AJ_SPC
export AJ_TAB




# main code
# ---------


	AJ_MESSAGES=off

	if [ "$1" = "-disclaimer" ]; then

		clear
		echo "ANTIJUNK DISCLAIMER:
--------------------

No warranties, either express or implied, are hereby given. All software
is supplied as is, without guarantee.  The user assumes all responsibility
for damages resulting from the use of these features, including, but not
limited to, frustration, disgust, system abends, disk head-crashes, general
malfeasance, floods, fires, shark attack, nerve gas, locust infestation,
cyclones, hurricanes, tsunamis, local electromagnetic disruptions, hydraulic
brake system failure, invasion, hashing collisions, normal wear and tear
of friction surfaces, comic radiation, inadvertent destruction of sensitive
electronic components, windstorms, the Riders of Nazgul, infuriated chickens,
malfunctioning mechanical or electrical sexual devices, premature activation
of the distant early warning system, peasant uprisings, halitosis, artillery
bombardment, explosions, cave-ins, and/or frogs falling from the sky.


By using this software you agree to these conditions!

"
		echo
		exit
	fi

	if [ "$1" = "-createfile" ]; then
		echo
		echo "AntiJunk: writing $AJ_USERFILE..."
		echo "#
# example $HOME/.AJsettings file for AntiJunk 6.1+
#
# NOTE: try to keep this file in roughly the same style - AntiJunk is
#       case sensitive. The lines must be as follows:
<VARIABLENAME>:<ONESPACE><CONTENTS>

AJ_SUBWORDS: limited offer,free,offer,affordable,now,$,buy,FREE,NOW,Buy
# the words to search for in the subject line, overrides any AntiJunk default
#     NOTE: word,word,word - there must be no spaces where you don't want them!

AJ_MAIWORDS: limited offer,free,offer,affordable,now,$,buy,FREE,NOW,Buy
# the words to search for in the main body, overrides any AntiJunk default

AJ_ACTION: add
# action to take, overrides any AntiJunk default, actions are:
#               add - add \"(SPAM)\" to the subject line
#               del - delete the message
#               1   - forward message to \"AJ_ACTUSE\" below
#               2   - save message in file named in \"AJ_ACTUSE\" below
# ***** IN VERSION 6.1 OF ANTIJUNK ONLY \"add\" WORKS! *****

AJ_ACTUSE: nothing
# see AJ_ACTION, overrides any AntiJunk default

AJ_COMPLAIN: no
# will send a complaint message to sender of message, default is \"no\"
# choice of \"yes\" or \"no\" only
# ***** IN VERSION 6.1 OF ANTIJUNK ONLY \"no\" WORKS! *****

AJ_CHK: 1
# where to check for spam words, default is 1, actions are:
#       1 - check subject and main body of message
#       2 - check subject only
#       3 - check main body only
#       4 - check nothing
# ***** IN VERSION 6.1 OF ANTIJUNK \"1\" IS DEFAULT BUT ALL ONLY
#       ACT AS \"2\"! *****

">$AJ_USERFILE
		echo "Done!"
		echo
		exit
	fi


	if [ "$1" = "" -o "$1" = "" -o "$1" = "--help" -o "$2" = "--help" -o "$3" = "--help" -o "$4" = "--help" -o "$5" = "--help" ]; then

		echo
		echo "AntiJunk (version $AJ_VERSION)"
		echo "------------------$AJ_UNDERLI-"
		echo
		echo "USAGE:     $0 [commands] "
		echo
		echo " --help        this screen"
		echo " -process      check for junk (must be first command)"
		echo " -messageson   turn on-screen messages on"
		echo " -disclaimer   please read this disclaimer before using this program"
		echo " -createfile   create a user settings file as $AJ_USERFILE"
		echo
		exit

	else

		if [ "$1" = "-process" -o "$2" = "-process" -o "$3" = "-process" -o "$4" = "-process" -o "$5" = "-process" ]; then

			A="1"

		else

			echo
			echo "AntiJunk (version $AJ_VERSION)"
			echo "------------------$AJ_UNDERLI-"
			echo
			echo "nothing to do!"
			echo
			echo "for help do     $0 --help"
			echo
			exit

		fi

		if [ "$1" = "-messageson" -o "$2" = "-messageson" -o "$3" = "-messageson" -o "$4" = "-messageson" -o "$5" = "-messageson" ] ; then

			AJ_MESSAGES=on

		fi

		export AJ_MESSAGES

#		if [ "$1" = "-process" ] ; then
		if [ "$1" = "-process" -o "$2" = "-process" -o "$3" = "-process" -o "$4" = "-process" -o "$5" = "-process" ]; then

			if [ ! -f "$AJ_MAILQ/$AJ_USER" ]; then

				if [ "$AJ_MESSAGES" = "on" ]; then

					echo
					echo "AntiJunk (version $AJ_VERSION)"
					echo "------------------$AJ_UNDERLI-"
					echo
					echo "No mail to process..."
					echo
				fi

				exit

			fi


			if [ "$AJ_MESSAGES" = "on" ]; then

				echo
				echo "AntiJunk (version $AJ_VERSION)"
				echo "------------------$AJ_UNDERLI-"

			fi

			if [ "$AJ_MESSAGES" = "on" ]; then
				echo "Deleting temp files..."
				rm -f $AJ_TMP/tmpaj_"$AJ_USER"* >/dev/null
			else
				rm -f $AJ_TMP/tmpaj_"$AJ_USER"* ; fi

			if [ "$AJ_MESSAGES" = "on" ]; then
				echo "Attempting to load user variables..."; fi

			if [ -f "$AJ_USERFILE" ]; then


				$AJ_INOUT -ajuservar

				AJ_TMP_SUBWORDS=""
				AJ_TMP_MAIWORDS=""
				AJ_TMP_ACTION=""
				AJ_TMP_ACTUSE=""
				AJ_TMP_COMPLAIN=""
				AJ_TMP_CHK=""

				if [ -f "$AJ_TMP/tmpaj_$AJ_USER-subwords" ]; then
					sed -e 's/,/\
/g'<$AJ_TMP/tmpaj_$AJ_USER-subwords >$AJ_TMP/tmpaj_$AJ_USER-subwords2
					AJ_TMP_SUBWORDS="`cat $AJ_TMP/tmpaj_$AJ_USER-subwords2`"; fi
				if [ -f "$AJ_TMP/tmpaj_$AJ_USER-maiwords" ]; then
					sed -e 's/,/\
/g'<$AJ_TMP/tmpaj_$AJ_USER-maiwords >$AJ_TMP/tmpaj_$AJ_USER-maiwords2
					AJ_TMP_MAIWORDS="`cat $AJ_TMP/tmpaj_$AJ_USER-maiwords2`"; fi
				if [ -f "$AJ_TMP/tmpaj_$AJ_USER-action" ]; then
					AJ_TMP_ACTION="`cat $AJ_TMP/tmpaj_$AJ_USER-action`"; fi
				if [ -f "$AJ_TMP/tmpaj_$AJ_USER-actuse" ]; then
					AJ_TMP_ACTUSE="`cat $AJ_TMP/tmpaj_$AJ_USER-actuse`"; fi
				if [ -f "$AJ_TMP/tmpaj_$AJ_USER-complain" ]; then
					AJ_TMP_COMPLAIN="`cat $AJ_TMP/tmpaj_$AJ_USER-complain`"; fi
				if [ -f "$AJ_TMP/tmpaj_$AJ_USER-chk" ]; then
					AJ_TMP_CHK="`cat $AJ_TMP/tmpaj_$AJ_USER-chk`"; fi

				if [ ! "$AJ_TMP_SUBWORDS" = "" ]; then
					AJ_SUBWORDS=$AJ_TMP_SUBWORDS; fi

				if [ ! "$AJ_TMP_MAIWORDS" = "" ]; then
					AJ_MAIWORDS=$AJ_TMP_MAIWORDS; fi

				if [ ! "$AJ_TMP_ACTION" = "" ]; then
					AJ_ACTION=$AJ_TMP_ACTION; fi

				if [ ! "$AJ_TMP_ACTUSE" = "" ]; then
					AJ_ACTUSE=$AJ_TMP_ACTUSE; fi

				if [ ! "$AJ_TMP_COMPLAIN" = "" ]; then
					AJ_COMPLAIN=$AJ_TMP_COMPLAIN; fi

				if [ ! "$AJ_TMP_CHK" = "" ]; then
					AJ_CHK=$AJ_TMP_CHK; fi


			fi


			export AJ_SUBWORDS
			export AJ_MAIWORDS
			export AJ_ACTION
			export AJ_ACTUSE
			export AJ_COMPLAIN
			export AJ_CHK


			if [ "$AJ_MESSAGES" = "on" ]; then
				echo "Deleting temp files..."
				rm -f $AJ_TMP/tmpaj_"$AJ_USER"* >/dev/null
			else
				rm -f $AJ_TMP/tmpaj_"$AJ_USER"* ; fi


			if [ -f "$HOME/.un-AJed-mail.gz" ]; then
				gunzip -fq $HOME/.un-AJed-mail.gz ; fi

			cat $AJ_MAILQ/$AJ_USER >>$HOME/.un-AJed-mail

			if [ -f "$HOME/.un-AJed-mail" ]; then
				gzip -fq1 $HOME/.un-AJed-mail ; fi

			if [ "$AJ_MESSAGES" = "on" ]; then
				echo "Processing mail from $AJ_MAILQ/$AJ_USER..."; fi

			AJ_MAILSRC=$AJ_TMP/tmpaj_"$AJ_USER"1
			export AJ_MAILSRC

#			cat $AJ_MAILQ/$AJ_USER >$AJ_MAILSRC


			sed 's/ /$AJ_SPC/g' $AJ_MAILQ/$AJ_USER >$AJ_TMP/tmpaj_"$AJ_USER"6
				# ^^ spaces
			sed 's/	/$AJ_TAB/g' $AJ_TMP/tmpaj_"$AJ_USER"6 >$AJ_MAILSRC
				# ^^ tabs


			rm -f $AJ_MAILSRC1

			echo -n "">$AJ_MAILQ/$AJ_USER
			chmod 600 $AJ_MAILSRC

			echo "$AJ_EOFMARKER">>$AJ_MAILSRC

			$AJ_INOUT <$AJ_MAILSRC

			cat $AJ_TMP/tmpaj_"$AJ_USER"0 >>$AJ_MAILQ/$AJ_USER
			chmod 600 $AJ_MAILQ/$AJ_USER

			rm -f $AJ_TMP/tmpaj_"$AJ_USER"*

			if [ "$AJ_MESSAGES" = "on" ]; then
				echo "Done!"; echo ; fi

	fi

fi


