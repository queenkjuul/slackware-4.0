#!/bin/bash
#
# script to process incoming mail for AntiJunk (version 6.1 - beta)
#

if [ "$1" = "-ajuservar" ]; then

	grep "AJ_SUBWORDS: " $AJ_USERFILE| sed -e 's/AJ_SUBWORDS: *//'>$AJ_TMP/tmpaj_$AJ_USER-subwords
	grep "AJ_MAIWORDS: " $AJ_USERFILE| sed -e 's/AJ_MAIWORDS: *//'>$AJ_TMP/tmpaj_$AJ_USER-maiwords
	grep "AJ_ACTION: " $AJ_USERFILE| sed -e 's/AJ_ACTION: *//'>$AJ_TMP/tmpaj_$AJ_USER-action
	grep "AJ_ACTUSE: " $AJ_USERFILE| sed -e 's/AJ_ACTUSE: *//'>$AJ_TMP/tmpaj_$AJ_USER-actuse
	grep "AJ_COMPLAIN: " $AJ_USERFILE| sed -e 's/AJ_COMPLAIN: *//'>$AJ_TMP/tmpaj_$AJ_USER-complain
	grep "AJ_CHK: " $AJ_USERFILE| sed -e 's/AJ_CHK: *//' >$AJ_TMP/tmpaj_$AJ_USER-chk
	AJ_FINISH=yes
	exit
fi


AJ_FINISH=no
rm -f $AJ_TMP/tmpaj_"$AJ_USER"0
	# delete temp files from previous sessions


until [ "AJ_FINISH" = "yes" ]; do

	echo -n "" >>$AJ_TMP/tmpaj_"$AJ_USER"0
	rm -f $AJ_TMP/tmpaj_"$AJ_USER"2
	rm -f $AJ_TMP/tmpaj_"$AJ_USER"3

	read -r line
		# read from standard input


	if [ "$line" = "$AJ_EOFMARKER" ]; then

		AJ_FINISH=yes
		exit

	else

		echo $line >$AJ_TMP/tmpaj_"$AJ_USER"2
		echo -n "" >>$AJ_TMP/tmpaj_"$AJ_USER"3

		sed 's/$AJ_SPC/ /g' $AJ_TMP/tmpaj_"$AJ_USER"2 >$AJ_TMP/tmpaj_"$AJ_USER"5 #spaces
		sed 's/$AJ_TAB/	/g' $AJ_TMP/tmpaj_"$AJ_USER"5 >$AJ_TMP/tmpaj_"$AJ_USER"2 #tabs
#cat $AJ_TMP/tmpaj_"$AJ_USER"2 >>$AJ_TMP/tmpaj---test

		grep "Subject: " $AJ_TMP/tmpaj_"$AJ_USER"2 | grep -v "(SPAM)" - | grep -F "$AJ_SUBWORDS" >$AJ_TMP/tmpaj_"$AJ_USER"3

			# check for subjects containing the words

		read -r newline <$AJ_TMP/tmpaj_"$AJ_USER"3
			# check if a bad subject was found

		if [ "$newline" = "" ]; then

			cat $AJ_TMP/tmpaj_"$AJ_USER"2 >>$AJ_TMP/tmpaj_"$AJ_USER"0

		else

			sed -e 's/Subject: */Subject: (SPAM) /' <$AJ_TMP/tmpaj_"$AJ_USER"3 >>$AJ_TMP/tmpaj_"$AJ_USER"0
			echo "$AJ_ADD" >>$AJ_TMP/tmpaj_"$AJ_USER"0
			rm $AJ_TMP/tmpaj_"$AJ_USER"3
				# change "Subject: " to "Subject: (SPAM)"
	
		fi

	fi


done

