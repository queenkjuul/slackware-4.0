/*
 * Mail decoder for UU, XX, Base64 and BinHex encoded files
 *
 * created by Simone Chemelli <genius@dei.unipd.it>
 *
 * Copyright '95 '96
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#define MOVE	    "mv "
#define CHR	    '/'
#define STR	    "/"

char buf[81], dest[80]="", dec_dir[120]="", *destp=NULL, in_file[150]="stdin";
FILE *f_in=stdin, *f_out;
int forward, done, mode, file;

extern char *optarg;
extern int optind, opterr, optopt;
extern int getopt(int argc, char * const *argv, const char *optstring);
extern char *tempnam(const char *, const char *);
extern void uu_decode(void);
extern void base64_decode(void);
extern void xx_decode(void);
extern void hexbin_decode();

void help(char);
void clean(char s[]);
void fix_file_name(char nome[]);
void err_func(int err);
int lookfor(char p[], char s[]);


int main(int argc, char **argv)
{
  int n, xx=0, del=0, num=0;
  FILE *f_tmp;
  char *tmpfile;

  for(;;) {
   n = getopt(argc, argv, "ho:ev");
   if( n == -1 ) break;
   switch(n) {
     case 'h': help('h');
     case 'o': strcpy(dec_dir, optarg); num+=2; break;
     case 'e': del = 1; num+=1; break;
     case 'v': help('v');
   }
  }
  file = 1;
  argc--;
  if(num != argc) strcpy(in_file, argv[argc]);
  else 		  file=0;

  if(file) {
	 f_in = fopen(in_file, "r");
	 if(f_in == NULL) err_func(1);
  }
  if(!strcmp(dec_dir, "")) strcpy(dec_dir, getenv("HOME"));

  tmpfile = tempnam("/tmp", NULL);
  
  f_tmp = fopen(tmpfile, "w");
  sscanf("660", "%o", &mode);
  chmod(tmpfile, mode);

  if(dec_dir[strlen(dec_dir)-1]!=CHR) strcat(dec_dir, STR);
  if( strcmp(dec_dir, STR) && dec_dir[strlen(dec_dir)-1]==CHR) strncpy(buf, dec_dir, strlen(dec_dir)-1);
  printf("\nDecode directory : %s", buf);
  printf("\nTemporary file   : %s", tmpfile);
  printf("\nInput file name  : %s\n", in_file);
  if(!file && del) {
  	printf("(Option \"-e\" ignored when using stdin)\n");
  	del=0;
  }
  printf("\nSearching for UU/XX/Base64/BinHex encoded files...\n\n");
  while(!feof(f_in)) {
	fgets(buf, 80, f_in);
	if( !lookfor(buf, "Content-Type:") && ( !lookfor(buf, "name=")) )
	{
		destp = strrchr(buf, '=');
		destp++;
		if( *(destp) == '"' ) destp++;
		n = strcspn(destp, "\"");
		if(n) *(destp + n) ='\0';
		strcpy(dest, destp);
		buf[0]='\0';
	}
	if( !lookfor(buf, "Content-Transfer-Encoding: X-xxencode") ) xx = 1;
	if( !lookfor(buf, "begin ") ) {
		sscanf(buf, "begin %o %s", &mode, dest);
		if(mode <= 0) continue;
		if(xx) xx_decode();
		else   uu_decode();
		xx = 0; mode = -1;
	}
	if( !lookfor(buf, "Content-Transfer-Encoding: base64") )
		base64_decode();
	if( (!lookfor(buf, "(This file")) || (!lookfor(buf, "(Convert with")) )
		hexbin_decode();
	if(del) fputs(buf, f_tmp);
  }
  if(file) fclose(f_in);
  fclose(f_tmp);
  if(del) {
	strcpy(buf, MOVE);
	strcat(buf, tmpfile);
	strcat(buf, " ");
	strcat(buf, in_file);
	system(buf);
  }
  if(done) printf("\nSearch complete !\n\n");
  else	   printf("   Nothing to do ...\n\n");
  remove(tmpfile);
  return 0;
}

void help(char c)
{
 printf("\nMail decoder version %1.1f by Simone Chemelli <genius@dei.unipd.it>\n\n", VER);
 if( c == 'v') exit(1);
 printf("\nDecodes file in UU, XX, Base64 and BinHex formats\n");
 printf("\nUsage : maildec [-v] [-h] [-e] [-o outputdir] filename/<stdin>\n\n");
 exit(1);
}

void fix_file_name(char out_file[80])
{
  int m;
  char *out, *out2;

  out = strrchr(out_file,  '/');
  out2= strrchr(out_file, '\\');
  strcpy(buf, out_file);
  if(!strcmp(buf, "")) strcpy(buf, "default");
  if(out != NULL) {
	out++;
	strcat(buf, out);
  }
  if(out2 != NULL) {
	out2++;	
	strcat(buf, out2);
  }
  strcpy(out_file, dec_dir);
  strcat(out_file, buf);

  for(m=2;m<10;m++)
  {
    f_out = fopen(out_file, "r");
    if( f_out != NULL ) out_file[strlen(out_file)-1] = (m+'0');
     else break;
    fclose(f_out);
  }	  
  fclose(f_out);
  f_out = fopen(out_file, "wb");
  if(f_out == NULL) err_func(2);
  destp = strrchr(out_file, CHR);
  destp++;
  return;
}  

int lookfor(char p[], char s[])
{
 int i;
 char *t_res, t_p[81], t_s[81];
 if(strlen(p) < strlen(s)) return 1;		  
 strcpy(t_p, p);
 strcpy(t_s, s);
 for(i=0;i<=strlen(t_p);i++) t_p[i]=toupper(t_p[i]);
 for(i=0;i<=strlen(t_s);i++) t_s[i]=toupper(t_s[i]);
 t_res = strstr(t_p, t_s);
 if(t_res != NULL) {
	forward = strlen(p) - strlen(t_res);
	return 0;
 }
 else {
	forward = 0;
	return 1;
 }
}
	  
void err_func(int err)
{
 char str_err[80];
 
 switch(err) 
 {
	case 1 : strcpy(str_err, "Can't open input file for reading");
		break;
	case 2 : strcpy(str_err, "Can't open output file for writing");
		break;
	case 4 : strcpy(str_err, "Unknown error while decoding (file corrupted ?): exit");
 }
 printf("\n Error : %s.\n\n", str_err);
 if(file) fclose(f_in);
 fclose(f_out);
 exit(err);
}

void clean(char s[])
{
 char *t;
 
 if(forward) {
	t = (s+forward);
	strcpy(s, t);
 }
 if( s[strlen(s)-2] == 13 ) s[strlen(s)-2]='\0'; 
 return;
}
