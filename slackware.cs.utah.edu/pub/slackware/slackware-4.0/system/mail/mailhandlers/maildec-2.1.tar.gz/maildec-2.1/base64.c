#include <stdio.h>
#include <string.h>

#include "maildec.h"

void base64_decode(void)
{
	int	d, i, num, len, oldlen=0, j, val, loop;
	char	nw[4], *p, *c, tmp[81], *set_base =
	  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

	fgets(buf, 80, f_in);
	strcpy(tmp, buf);
	if( !lookfor(buf, "Content-Disposition:") && strstr(buf, "name=") != NULL )
	{
		buf[strlen(buf)-1]='\0';
		destp = strrchr(buf, '=');
		destp++;
		if( *(destp) == '"' ) destp++;
		if( (i = strcspn(destp, "\"")) != 0 ) *(destp + i) ='\0';
		strcpy(dest, destp);
	}
	fix_file_name(dest);
	printf("Base64 : decoding %-25s\n", destp);
	strcpy(buf, tmp);
	while( strrchr(buf, ':') ) fgets(buf, 80, f_in);
	loop = 1;
	while (fgets(buf, 80, f_in) && loop)
	{ 
		clean(buf);
		len = strlen(buf)-1;
		for (i = 0; i < len; i += 4)
		{
			if(len < oldlen) loop=0;
			if(strrchr(buf, '=')) loop=0;
			val = 0;
			num = 3;
			c = buf+i; 
			if (c[2] == '=')      num = 1;
			else if (c[3] == '=') num = 2;

			for (j = 0; j <= num; j++)
			{
				p = strchr(set_base, c[j]);
				d = p-set_base;
				d <<= (3-j)*6;
				val += d;
			}
			for (j = 2; j >= 0; j--)
			{
				nw[j] = val & 255;
				val >>= 8;
			}
			fwrite(nw, 1, num, f_out);
		}
		oldlen = len;
	}
	fclose(f_out);
	done = 1;
	buf[0]='\0';
	return;
}
