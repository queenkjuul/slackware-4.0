extern char buf[81], dest[80], dec_dir[120], *destp, in_file[150];
extern FILE *f_in, *f_out; 
extern int forward, done, mode;
 
extern void clean(char s[]);
extern void fix_file_name(char nome[]);
extern void err_func(int err);
extern int lookfor(char p[], char s[]);

