#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>

#include "maildec.h"

#define DEC(c)	( table[ (c) & 0177 ] )

char table[128];
void outdec(char *, int);

void xx_decode(void)
{
	char *bp, *set_xx = 
	  "+-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	int n;
	
	bp = table;
	for( n=128 ; n ; --n ) {
	  *(bp++) = 0;
	};
	bp=set_xx;
	for( n=64 ; n ; --n ) {
	  table[ *(bp++) & 0177 ] = 64-n;
	};
	
	fix_file_name(dest);
	printf("XX     : decoding %-25s\n", destp);
	
	for (;;) {
		fgets(buf, 80, f_in);
		clean(buf);
		n = DEC(buf[0]);
		if (n <= 0) break;
		bp = &buf[1];
		while (n > 0) {
			outdec(bp, n);
			bp += 4;
			n -= 3;
		}
	}
	fclose(f_out);
	chmod(dest, mode);
	done = 1;
	buf[0]='\0';
	return;
}

void outdec(char *p, int n)
{
	int c1, c2, c3;
	c1 = DEC(*p) << 2 | DEC(p[1]) >> 4;
	c2 = DEC(p[1]) << 4 | DEC(p[2]) >> 2;
	c3 = DEC(p[2]) << 6 | DEC(p[3]);
	if (n >= 1) putc(c1, f_out);
	if (n >= 2) putc(c2, f_out);
	if (n >= 3) putc(c3, f_out);
	return;
}
