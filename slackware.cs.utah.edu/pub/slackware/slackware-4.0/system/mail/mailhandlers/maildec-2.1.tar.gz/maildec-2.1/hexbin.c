#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "maildec.h"
 
extern long timezone;
extern char *strrchr();

#define output(c) { *op++ = (c); if (op >= &obuf[BUFSIZ]) oflush(); }
#define CRCCONSTANT 0x1021
#define SIXB(c) (((c)-0x20) & 0x3f)
#define search_last strrchr
#define FNAMELEN 254 
#define TIMEDIFF 0x7c25b080
#define DATABYTES 128
#define BYTEMASK 0xff
#define BYTEBIT 0x100
#define WORDMASK 0xffff
#define WORDBIT 0x10000
#define NAMEBYTES 63
#define H_NLENOFF 1
#define H_NAMEOFF 2
#define H_TYPEOFF 65
#define H_AUTHOFF 69
#define H_FLAGOFF 73
#define H_LOCKOFF 81
#define H_DLENOFF 83
#define H_RLENOFF 87
#define H_CTIMOFF 91
#define H_MTIMOFF 95
#define H_OLD_DLENOFF 81
#define H_OLD_RLENOFF 85
#define F_BUNDLE 0x2000
#define F_LOCKED 0x8000

struct macheader {
	char m_name[NAMEBYTES+1];
	char m_type[4];
	char m_author[4];
	short m_flags;
	long m_datalen;
	long m_rsrclen;
	long m_createtime;
	long m_modifytime;
} mh;

struct filenames {
	char f_info[256];
	char f_data[256];
	char f_rsrc[256];
} files;

int compressed, qformat;
FILE *ifp;

void put4(char *, long );
void put2(char *, short);
int  hexit(int);
int  hex_to_bin(char [], FILE *);
int  comp_to_bin(char [], FILE *);
void comp_e_crc(unsigned char);
void comp_c_crc(unsigned char);
long make_file(char *, int);
void do_o_forks(void);
void do_o_header(char *, char *);
void comp_q_crc(register unsigned int);
void do_q_everything(char *, char*);
void getqbuf(char *, int);
void verify_crc(unsigned int, unsigned int);
int  getq(void);
void forge_info(void);
void process_forks(void);
void name_stuffing( char *);
void setup_files(char *);
int  find_decode_method(void);


void hexbin_decode(void)
{
	char *macname;

	ifp = f_in;

	macname = "";
	setup_files(macname);
	process_forks();
	forge_info();
	done =1;
	buf[0]='\0';
	return;
}

void setup_files(char *macname)
{
	struct stat stbuf;
	long curtime;
	char nome_file[150];
	
	if (ifp == stdin) {
		curtime = time(0);
		mh.m_createtime = curtime;
		mh.m_modifytime = curtime;
	}
	else {
		mh.m_createtime = stbuf.st_mtime;
		mh.m_modifytime = stbuf.st_mtime;
	}
	qformat = find_decode_method();

	strcpy(nome_file, in_file);

	if (qformat)
		do_q_everything(macname, nome_file);
	else {
		do_o_header(macname, nome_file);
		name_stuffing(macname);
	}
	return;
}

void name_stuffing(char *namebuf)
{
	int n, m;
	char *np, *appendix="", dest[100];
	n = strlen(mh.m_name);
	if (n > FNAMELEN - 2)
		n = FNAMELEN - 2;
	strncpy(namebuf, mh.m_name, n);
	namebuf[n] = '\0';

	for (np = namebuf; *np; np++){
		if (*np == ' ' || *np == '/' || *np == '!' ||
		*np == '(' || *np == ')' || *np == '[' || *np == ']'
		|| *np == '*' || *np == '<' || *np == '>' ||
		*np == '?' || *np == '\'' || *np == '"' || *np == '$')
			*np = '_';
		*np &= 0x7f;
	}
	
	strcat(namebuf, ".data");	
	fix_file_name(namebuf);
	m = strlen(strpbrk(namebuf, "data"));
	m++;
	appendix = strrchr(namebuf, '.');
	namebuf[strlen(namebuf)-m]='\0';   
	
	if(!strcmp(appendix, ".")) strcpy(appendix, "");
	strcpy(dest, namebuf);
	strcat(dest, ".{data,rsrc,info}");
	strcat(dest, appendix);
	destp = strrchr(dest, '/');
	
	printf("BinHex : decoding %-25s\n", (++destp));
	
	sprintf(files.f_data, "%s.data%s", namebuf, appendix);
	sprintf(files.f_rsrc, "%s.rsrc%s", namebuf, appendix);
	sprintf(files.f_info, "%s.info%s", namebuf, appendix);
	return;
}

void process_forks(void)
{
	if (!qformat) do_o_forks();
	return;
}

/* write out .info file from information in the mh structure */
void forge_info(void)
{
	static char buf[DATABYTES];
	char *np;
	FILE *fp;
	int n;
	long tdiff;
	struct tm *tp;
#ifdef BSD
	struct timeb tbuf;
#else
	long bs;
#endif

	for (np = mh.m_name; *np; np++)
		if (*np == '_') *np = ' ';

	buf[H_NLENOFF] = n = np - mh.m_name;
	strncpy(buf + H_NAMEOFF, mh.m_name, n);
	strncpy(buf + H_TYPEOFF, mh.m_type, 4);
	strncpy(buf + H_AUTHOFF, mh.m_author, 4);
	put2(buf + H_FLAGOFF, mh.m_flags & ~F_LOCKED);
	put4(buf + H_DLENOFF, mh.m_datalen);
	put4(buf + H_RLENOFF, mh.m_rsrclen);
	time(&bs);
	tp = localtime(&bs);
	tdiff = TIMEDIFF - timezone;
	if (tp->tm_isdst) tdiff += 60 * 60;
	put4(buf + H_CTIMOFF, mh.m_createtime + tdiff);
	put4(buf + H_MTIMOFF, mh.m_modifytime + tdiff);
	fp = fopen(files.f_info, "w");
	if (fp == NULL) exit(4);
	fwrite(buf, 1, DATABYTES, fp);
	fclose(fp);
	return;
}

int find_decode_method(void)
{
	int c, at_bol;

	at_bol = 1;
	while ((c = getc(ifp)) != EOF) {
		switch (c) {
		case '\n':
		case '\r':
			at_bol = 1;
			break;
		case ':':
			if (at_bol)  return 1;	  /*  q  format */
			break;
		case '#':
			if (at_bol) {	  	  /* old format */
				ungetc(c, ifp);
				return 0;
			}
			break;
		default:
			at_bol = 0;
			break;
		}
	}
	exit(2);
	return 1;
}

static unsigned int crc;

short get2q();
long get4q();

/* read header of .hqx file */
void do_q_header(char *macname)
{
	char namebuf[256];
	int n;
	unsigned int calc_crc, file_crc;

	crc = 0;

	n = getq();
	n++;
	getqbuf(namebuf, n);
	if (macname[0] == '\0') macname = namebuf;

	n = strlen(macname);
	if (n > NAMEBYTES) n = NAMEBYTES;
	strncpy(mh.m_name, macname, n);
	mh.m_name[n] = '\0';

	getqbuf(mh.m_type, 4);
	getqbuf(mh.m_author, 4);
	mh.m_flags = get2q();
	mh.m_datalen = get4q();
	mh.m_rsrclen = get4q();

	comp_q_crc(0);
	comp_q_crc(0);
	calc_crc = crc;
	file_crc = get2q();
	verify_crc(calc_crc, file_crc);
	return;
}

void verify_crc(unsigned int calc_crc, unsigned int file_crc)
{
	calc_crc &= WORDMASK;
	file_crc &= WORDMASK;

	if (calc_crc != file_crc) exit(4);
	return;
}

#define RUNCHAR 0x90

#define DONE 0x7F
#define SKIP 0x7E
#define FAIL 0x7D

char lookup[256] = {
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
/*		    \n		      \r		*/
	FAIL, FAIL, SKIP, FAIL, FAIL, SKIP, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06,
	0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, FAIL, FAIL,
	0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, FAIL,
/*		    :					*/
	0x14, 0x15, DONE, FAIL, FAIL, FAIL, FAIL, FAIL,
	0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D,
	0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, FAIL,
	0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, FAIL,
	0x2C, 0x2D, 0x2E, 0x2F, FAIL, FAIL, FAIL, FAIL,
	0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, FAIL,
	0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, FAIL, FAIL,
	0x3D, 0x3E, 0x3F, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
	FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL,
};

char *g_macname;
char *g_namebuf;

int stop=0;

void get_header(void)
{
	do_q_header(g_macname);
	name_stuffing(g_namebuf);
	return;
}

unsigned char obuf[BUFSIZ];
unsigned char *op= obuf;
unsigned char *oq;

#define S_HEADER	0
#define S_DATAOPEN	1
#define S_DATAWRITE	2
#define S_DATAC1	3
#define S_DATAC2	4
#define S_RSRCOPEN	5
#define S_RSRCWRITE	6
#define S_RSRCC1	7
#define S_RSRCC2	8
#define S_EXCESS	9

int ostate= S_HEADER;

unsigned int calc_crc;
unsigned int file_crc;

long todo;
FILE *ofp;

void oflush(void)
{
	int n;
	register unsigned char *end;
	register unsigned char *p;
	
	oq= obuf;
	while (oq < op && !stop) {
		switch (ostate) {
		case S_HEADER:
			get_header();
			++ostate;
			break;
		case S_DATAOPEN:
			ofp= fopen(files.f_data, "w");
			todo= mh.m_datalen;
			crc= 0;
			++ostate;
			break;
		case S_RSRCOPEN:
			ofp= fopen(files.f_rsrc, "w");
			todo= mh.m_rsrclen;
			crc= 0;
			++ostate;
			break;
		case S_DATAWRITE:
		case S_RSRCWRITE:
			n= op-oq;
			if (n > todo)
				n= todo;
			if (fwrite(oq, 1, n, ofp) != n) {
				perror("fwrite");
				exit(1);
			}
			end= oq+n;
			p  = oq;
			while (p < end) comp_q_crc(*p++);
			oq += n;
			todo -= n;
			if (todo <= 0) {
				fclose(ofp);
				++ostate;
			}
			break;
		case S_DATAC1:
		case S_RSRCC1:
			comp_q_crc(0);
			comp_q_crc(0);
			calc_crc= crc;
			file_crc= getq() << 8;
			++ostate;
			break;
		case S_DATAC2:
		case S_RSRCC2:
			file_crc |= getq();
			verify_crc(calc_crc, file_crc);
			++ostate;
			break;
		case S_EXCESS:
			fprintf(stderr, "%d excess bytes ignored\n", op-oq);
			oq= op;
			break;
		}
	}
	op= obuf;
	return;
}

int getq(void)
{
	int c;
	
	if (oq >= op) exit(4);
	c= *oq++;
	comp_q_crc((unsigned)c);
	return c;
}

short get2q(void)
{
	short high= getq() << 8;
	return high | getq();
}

long get4q(void)
{
	int i;
	long value= 0;

	for (i= 0; i < 4; i++) value= (value<<8) | getq();
	return value;
}

void getqbuf(char *buf, int n)
{
	int i;

	for (i = 0; i < n; i++)  *buf++ = getq();
	return;
}

void do_q_everything(char *macname, char *namebuf)
{
	unsigned char buf[BUFSIZ];
	int n;
	register unsigned char *in, *out;
	register int b6, b8=0, data=0, lastc=0;
	char state68= 0, run= 0;
	
	g_macname= macname;
	g_namebuf=namebuf;
	
	ostate= S_HEADER;
	stop= 0;
	
	while (!stop && (n= fread(buf, 1, BUFSIZ, ifp)) > 0) {
		in= buf;
		out= buf+n;
		do {
			if ((b6= lookup[*in]) >= 64) {
				switch (b6) {
				case DONE:
					goto done;
				case SKIP:
					break;
				default:
					goto done;
				}
			}
			else {
				switch (state68++) {
				case 0:
					b8= b6<<2;
					continue;
				case 1:
					data= b8 | (b6>>4);
					b8= (b6&0xF) << 4;
					break;
				case 2:
					data= b8 | (b6>>2);
					b8= (b6&0x3) << 6;
					break;
				case 3:
					data= b8 | b6;
					state68= 0;
					break;
				}
				if (!run) {
					if (data == RUNCHAR)
						run= 1;
					else
						output(lastc= data);
				}
				else {
					if (data == 0) {
						output(lastc= RUNCHAR);
					}
					else {
						while (--data > 0) {
							output(lastc);
						}
					}
					run= 0;
				}
			}
		} while (++in < out);
	}
 done:	oflush();
 	if (!stop && ostate != S_EXCESS) err_func(4);
 	return;
}

void comp_q_crc(register unsigned c)
{
	register int j;
	register unsigned long temp = crc;

	for(j=1;j<9;j++) {
	  c <<= 1;
	  if ((temp <<= 1) & WORDBIT) temp = (temp & WORDMASK) ^ CRCCONSTANT;
	  temp ^= (c >> 8);
	  c &= BYTEMASK;
	}
	crc = temp;
	return;
}

/* old format -- process .hex and .hcx files */
void do_o_header(char *macname, char *filename)
{
	char namebuf[256];
	char ibuf[BUFSIZ];
	int n;

	if (macname[0] == '\0') {
		strcpy(namebuf, filename);
		macname = search_last(namebuf, '/');
		if (macname == NULL) macname = namebuf;
		else		     macname++;
		n = strlen(macname);
		if (n > 4) {
		    n -= 4;
		    if (macname[n] == '.' && macname[n+1] == 'h' && macname[n+3] == 'x')
			    macname[n] = '\0';
		}
	}
	n = strlen(macname);
	if (n > NAMEBYTES)
		n = NAMEBYTES;
	strncpy(mh.m_name, macname, n);
	mh.m_name[n] = '\0';

	if (fgets(ibuf, BUFSIZ, ifp) == NULL) {
		fprintf(stderr, "unexpected EOF\n");
		exit(2);
	}
	n = strlen(ibuf);
	if (n >= 7 && ibuf[0] == '#' && ibuf[n-6] == '$') {
		if (n >= 11)
			strncpy(mh.m_type, &ibuf[1], 4);
		if (n >= 15)
			strncpy(mh.m_author, &ibuf[5], 4);
		sscanf(&ibuf[n-5], "%4hx", &mh.m_flags);
	}
	return;
}

void do_o_forks(void)
{
	char ibuf[BUFSIZ];
	int forks = 0, found_crc = 0;
	unsigned int calc_crc=0, file_crc;
	extern long make_file();


	crc = 0;

	close(creat(files.f_data, 0666));
	close(creat(files.f_rsrc, 0666));

	while (!found_crc && fgets(ibuf, BUFSIZ, ifp) != NULL) {
		if (forks == 0 && strncmp(ibuf, "***COMPRESSED", 13) == 0) {
			compressed++;
			continue;
		}
		if (strncmp(ibuf, "***DATA", 7) == 0) {
			mh.m_datalen = make_file(files.f_data, compressed);
			forks++;
			continue;
		}
		if (strncmp(ibuf, "***RESOURCE", 11) == 0) {
			mh.m_rsrclen = make_file(files.f_rsrc, compressed);
			forks++;
			continue;
		}
		if (compressed && strncmp(ibuf, "***CRC:", 7) == 0) {
			found_crc++;
			calc_crc = crc;
			sscanf(&ibuf[7], "%x", &file_crc);
			break;
		}
		if (!compressed && strncmp(ibuf, "***CHECKSUM:", 12) == 0) {
			found_crc++;
			calc_crc = crc & BYTEMASK;
			sscanf(&ibuf[12], "%x", &file_crc);
			file_crc &= BYTEMASK;
			break;
		}
	}
	if (found_crc) verify_crc(calc_crc, file_crc);
	else	       exit(4);
	return;
}

long make_file(char *fname, int compressed)
{
	char ibuf[BUFSIZ];
	FILE *outf;
	register long nbytes = 0L;

	outf = fopen(fname, "w");
	if (outf == NULL) {
		perror(fname);
		exit(-1);
	}
	while (fgets(ibuf, BUFSIZ, ifp) != NULL) {
		if (strncmp(ibuf, "***END", 6) == 0)
			break;
		if (compressed)
			nbytes += comp_to_bin(ibuf, outf);
		else
			nbytes += hex_to_bin(ibuf, outf);
	}
	fclose(outf);
	return nbytes;
}

void comp_c_crc(unsigned char c)
{
	crc = (crc + c) & WORDMASK;
	crc = ((crc << 3) & WORDMASK) | (crc >> 13);
	return;
}

void comp_e_crc(unsigned char c)
{
	crc += c;
	return;
}

int comp_to_bin(char ibuf[], FILE *outf)
{
	char obuf[BUFSIZ];
	register char *ip = ibuf;
	register char *op = obuf;
	register int n, outcount;
	int numread, incount;

	numread = strlen(ibuf);
	ip[numread-1] = ' ';
	outcount = (SIXB(ip[0]) << 2) | (SIXB(ip[1]) >> 4);
	incount = ((outcount / 3) + 1) * 4;
	for (n = numread; n < incount; n++) ibuf[n] = ' ';
	n = 0;
	while (n <= outcount) {
		*op++ = SIXB(ip[0]) << 2 | SIXB(ip[1]) >> 4;
		*op++ = SIXB(ip[1]) << 4 | SIXB(ip[2]) >> 2;
		*op++ = SIXB(ip[2]) << 6 | SIXB(ip[3]);
		ip += 4;
		n += 3;
	}
	for (n=1; n <= outcount; n++)  comp_c_crc((unsigned)obuf[n]);
	fwrite(obuf+1, 1, outcount, outf);
	return outcount;
}

int hex_to_bin(char ibuf[], FILE *outf)
{
	register char *ip = ibuf;
	register int n, outcount;
	int c;

	n = strlen(ibuf) - 1;
	outcount = n / 2;
	for (n = 0; n < outcount; n++) {
		c = hexit(*ip++);
		comp_e_crc((unsigned)(c = (c << 4) | hexit(*ip++)));
		fputc(c, outf);
	}
	return outcount;
}

int hexit(int c)
{
	if ('0' <= c && c <= '9') return c - '0';
	if ('A' <= c && c <= 'F') return c - 'A' + 10;
	return 0;
}

void put2(char *bp, short value)
{
	*bp++ = (value >> 8) & BYTEMASK;
	*bp++ = value & BYTEMASK;
	return;
}

void put4(char *bp, long value)
{
	register int i, c;

	for (i = 0; i < 4; i++) {
		c = (value >> 24) & BYTEMASK;
		value <<= 8;
		*bp++ = c;
	}
	return;
}
