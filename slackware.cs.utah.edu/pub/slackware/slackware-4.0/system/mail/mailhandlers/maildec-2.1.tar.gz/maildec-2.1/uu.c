#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "maildec.h"

#define DEC(c)	(((c) - ' ') & 077)

void uu_decode(void)
{
	char *bp;
	int n, c1, c2, c3;

	fix_file_name(dest);
	printf("UU     : decoding %-25s\n", destp);

	for (;;) 
	{
		fgets(buf, sizeof buf, f_in);
		clean(buf);
		n = DEC(buf[0]);
		if (n <= 0) break;
		bp = &buf[1];
		while (n > 0) 
		{
			c1 = DEC(*bp) << 2 | DEC(bp[1]) >> 4;
			c2 = DEC(bp[1]) << 4 | DEC(bp[2]) >> 2;
			c3 = DEC(bp[2]) << 6 | DEC(bp[3]);
			if (n >= 1)  putc(c1, f_out);
			if (n >= 2)  putc(c2, f_out);
			if (n >= 3)  putc(c3, f_out);
			bp += 4;
			n -= 3;
		}
	}
	fclose(f_out);
	chmod(dest, mode);
	done = 1;
	buf[0]='\0';
	return;
}
