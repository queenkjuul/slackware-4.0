/*
 * version.h
 * Copyright (c) 1994-1998 by Christopher Heng. All rights reserved.
 * You may not remove any of the copyright notices and/or conditions for
 * use and distribution. See COPYING for additional conditions for use
 * and distribution.
 *
 * Header file to contain version number (for debugging purpose) and
 * copyright notice.
 *
 * $Id: version.h,v 2.6 1998/03/30 13:18:26 chris Released $
 */

#define VERSTR	"splitdigest 2.4 - Undigests file(s) with multiple mail digests.\n"\
	      "Copyright (c) 1994-1998 by Christopher Heng. All rights reserved.\n"
	      