//qmail-unread v0.9.0 by Simon Bond (bondsc@tcp.co.uk)
//Displays a summary of all unread mail (i.e. waiting in a user's mailbox) for all users on the system who
//appear to be Qmail users.

#include <stdio.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <strings.h>
#include <malloc.h>
#include <unistd.h>

#define MAILBOX	0
#define MAILDIR 1
#define YES 1
#define NO 0
#define MAILDIRBAD 2
#define MAILDIRMISSING 3
#define MAILBOXMISSING 4
#define MAILBOXISDIR 5
#define HOMEMISSING 6
#define HOMEMODEBAD 7
#define MAXDOTQMAILLINE 200

class cQmailUsers {
  char *UserRootDetails[3]={"root", "/var/qmail/alias", "/var/qmail/alias/.qmail-root"};
  char *UserPostmasterDetails[3]={"postmaster", "/var/qmail/alias", "/var/qmail/alias/.qmail-postmaster"};
  char *UserMailerDetails[3]={"mailer-daemon", "/var/qmail/alias", "/var/qmail/alias/.qmail-mailer-daemon"};

  char *Username;		//Taken from PasswdData->pw_name (for neatness)
  long ValidUser;		//0=Not a user, 1=A valid user

  char *HomeDir;		//Taken from PasswdData->pw_dir  (for neatness)
  char *DotQmail;		//Location of user's .qmail file
  char *MailLoc;		//Location of user's Mailbox or Maildir/
  long DotQmailExists;		//Does user have a .qmail file (YES, NO)
  long MailType;		//Mail format type (MAILBOX, MAILDIR)
  long MailValid;		//Is Mailbox or Maildir/ OK (YES, NO)
  long MailQuantity;		//Size of Mailbox or num files in Maildir/

  void GetNextUser();
  void GetMailInfo();
  void ShowMailError();
  void ShowMailInfo();
  void ValidateMaildir();
  void ValidateMailbox();
  void GetNumMailsInMailbox();
  long GetNumFilesInMaildir();

  struct passwd *PasswdData;
  char *DotQmailLine;
  FILE *DotQmailHandle;
  long DotQmailLocationLineFound;
  void FindLocationLine();
 public:
  void ParseAllUsers();
};



long TestForDir(char *MyDir)
{
  DIR *DirHandle;
  long DirExists=NO;

  DirHandle=opendir(MyDir);
  if (DirHandle!=NULL) DirExists=YES;
  closedir(DirHandle);

  return(DirExists);
}



char *strjoin(char *Str1, char *Str2, char *Result)
{
  Result=(char *)malloc(strlen(Str1)+strlen(Str2)+1);
  strcpy(Result, Str1);
  strcat(Result, Str2);
  return(Result);
}


char *StripTrailingReturn(char *InStr)
{
  if (InStr[strlen(InStr)-1]==10) InStr[strlen(InStr)-1]=0;
  return InStr;
}



void cQmailUsers::FindLocationLine()
{
  char *Result;

  DotQmailLocationLineFound=NO;			//Not found location line yet
  DotQmailLine=(char *)malloc(MAXDOTQMAILLINE);

  do {
    Result=fgets(DotQmailLine, MAXDOTQMAILLINE-1, DotQmailHandle);
    if (Result!=NULL) {
      if (strlen(DotQmailLine)<2) continue;		//Simple test for valid line
      if (DotQmailLine[0]=='.' || DotQmailLine[0]=='/') {
        DotQmailLocationLineFound=YES;
        DotQmailLine=StripTrailingReturn(DotQmailLine);
        break;					//We have found the line we want. Break loop
      }
    }
  } while(Result!=NULL);
// Oh, location line not found

}



void cQmailUsers::GetMailInfo()
{
  struct stat InodeBuffer;

  if (TestForDir(HomeDir)==NO) {
    DotQmailExists=NO;
    MailType=MAILBOX;
    MailValid=HOMEMISSING;
    MailLoc="";
    return;
  }

  DotQmailHandle=fopen(DotQmail, "r");
  if (DotQmailHandle==NULL) {				//If no .qmail file
    DotQmailExists=NO;
    MailType=MAILBOX;
    MailLoc=strjoin(HomeDir,"/Mailbox", MailLoc);
  }
  else {
    DotQmailExists=YES;
    FindLocationLine();					//If a .qmail file, but not Mail location specified
    fclose(DotQmailHandle);

    if (DotQmailLocationLineFound==NO) {
      MailType=MAILBOX;
      MailLoc=strjoin(HomeDir,"/Mailbox", MailLoc);
    }
    else {
      if (DotQmailLine[strlen(DotQmailLine)-1]=='/') MailType=MAILDIR;
      else MailType=MAILBOX;

      if (DotQmailLine[0]=='.') MailLoc=strjoin(HomeDir, DotQmailLine+1, MailLoc);
      else MailLoc=DotQmailLine;
    }
  }

  if (MailType==MAILDIR) {
    ValidateMaildir();
    if (MailValid==YES) GetNumFilesInMaildir();
  }
  else {
    ValidateMailbox();
    if (MailValid==YES) GetNumMailsInMailbox();//GetSizeOfMailbox();
  }

  stat(HomeDir, &InodeBuffer);
  if ((InodeBuffer.st_mode & S_IWGRP)!=0 || (InodeBuffer.st_mode & S_IWOTH)!=0) {
    ValidUser=HOMEMODEBAD;
    return;
  }  

}


void cQmailUsers::GetNextUser()
{
  ValidUser=YES;
  PasswdData=getpwent();
  if (PasswdData==NULL) {
    ValidUser=NO;
    return;
  }
  Username=PasswdData->pw_name;
  HomeDir=PasswdData->pw_dir;

  DotQmail=strjoin(HomeDir,"/.qmail", DotQmail);
  GetMailInfo();
}



void cQmailUsers::ParseAllUsers()
{
  printf("%-15s%-30s%-15s%s\n", "Username", "Mail location", "Format", "Mail waiting");
  printf("------------------------------------------------------------------------\n");

  do {
    GetNextUser();
    if (strcmp(Username,"root")==0 ||
        strcmp(Username,"postmaster")==0 ||
        strcmp(Username,"alias")==0) continue;		//These users are dealt with separately
    if (ValidUser!=NO) ShowMailInfo();
  } while (ValidUser!=NO);

// Now deal with root

  Username=UserRootDetails[0];
  HomeDir=UserRootDetails[1];
  DotQmail=UserRootDetails[2];
  ValidUser=YES;
  GetMailInfo();
  ShowMailInfo();

// Now deal with postmaster

  Username=UserPostmasterDetails[0];
  HomeDir=UserPostmasterDetails[1];
  DotQmail=UserPostmasterDetails[2];
  ValidUser=YES;
  GetMailInfo();
  ShowMailInfo();

// Now deal with mailer-daemon

  Username=UserMailerDetails[0];
  HomeDir=UserMailerDetails[1];
  DotQmail=UserMailerDetails[2];
  ValidUser=YES;
  GetMailInfo();
  ShowMailInfo();


}


void cQmailUsers::ShowMailError()
{
if (MailValid==MAILDIRBAD) printf("Maildir/ directory layout wrong\n");
else if (MailValid==MAILDIRMISSING) printf("Maildir/ directory is missing\n");
else if (MailValid==MAILBOXMISSING) printf("Mailbox file is missing\n");
else if (MailValid==MAILBOXISDIR) printf("Mailbox file is a directory!\n");
else if (MailValid==HOMEMISSING) printf("User's home directory is missing!\n");
else if (ValidUser==HOMEMODEBAD) printf("Wrong permissions on home direcory\n");
else printf("Unknown error\n");
}



void cQmailUsers::ShowMailInfo()
{
  if (DotQmailExists==NO && MailValid==MAILBOXMISSING) return;	//Not a Qmail user

  printf("%-15s%-30s", Username, MailLoc);
  if (MailType==MAILDIR) printf("%-15s", "Maildir");
  else printf("%-15s", "Mailbox");

  if (MailValid!=YES || ValidUser!=YES) ShowMailError();	//.qmail specifies mail location, but there is a problem
  else if (MailValid==YES) {
  printf("%d\n", MailQuantity);
  }
}


void cQmailUsers::ValidateMailbox()
{
  FILE *TempHandle;

  MailValid=YES;
  TempHandle=fopen(MailLoc, "r");
  if (TempHandle==NULL) MailValid=MAILBOXMISSING;	//Could not find Mailbox file
  else fclose(TempHandle);

  if (TestForDir(MailLoc)==YES) MailValid=MAILBOXISDIR;	//Mailbox file should not be a directory
}



void cQmailUsers::GetNumMailsInMailbox()
{
  FILE *TempHandle;
  char TempLine[5];
  char *Result;

  MailQuantity=0;
  TempHandle=fopen(MailLoc, "r");
  do {
    Result=fgets(TempLine, 4, TempHandle);
    if (Result!=NULL) {
      if (strncmp(TempLine, "To:", 4)==0) MailQuantity++;
    }
  } while (Result!=NULL);
  fclose(TempHandle);
}



void cQmailUsers::ValidateMaildir()
{
 // Check for Maildir/, Maildir/cur, Maildir/new and Maildir/tmp
  DIR *DirHandle;
  char *StrTemp;	//Temporary string workspace
  MailValid=YES;	//Assume OK until determined otherwise;

  if (TestForDir(MailLoc)==NO) {
    MailValid=MAILDIRMISSING;
    return;
  }
  if (TestForDir(strjoin(MailLoc, "/cur", StrTemp))==NO) {
    MailValid=MAILDIRBAD;
    return;
  }
  if (TestForDir(strjoin(MailLoc, "/new", StrTemp))==NO) {
    MailValid=MAILDIRBAD;
    return;
  }
  if (TestForDir(strjoin(MailLoc, "/tmp", StrTemp))==NO) {
    MailValid=MAILDIRBAD;
    return;
  }

}



long cQmailUsers::GetNumFilesInMaildir()
{
  DIR *DirHandle;
  struct dirent *TempDirRead;
  char *MailDirNew;		//Temp variable to hold location of new/

  MailQuantity=-2;	//So "." and ".." are not counted.

  DirHandle=opendir(strjoin(MailLoc, "new", MailDirNew));
  if (DirHandle==NULL) {
    printf("Panic. Maildir did exist and now it doesn't!\n");
    exit(-1);
  }

  do {
    TempDirRead=readdir(DirHandle);
    if (TempDirRead!=NULL) MailQuantity++;
  } while(TempDirRead!=NULL);

  closedir(DirHandle);
  return(MailQuantity);		//Only returned incase outide routines want this data
}



void main(int argc, char **argv)
{
  class cQmailUsers QmailUsers;

  QmailUsers.ParseAllUsers();
}
