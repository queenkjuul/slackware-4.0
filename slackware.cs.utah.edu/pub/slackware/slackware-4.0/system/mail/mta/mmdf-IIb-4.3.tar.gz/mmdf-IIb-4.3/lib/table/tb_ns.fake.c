/*
 *	TB_NS.FAKE.C
 *
 *	Module to call on host system provided lookup routines.
 */

/* Place holder only */
int	dummy_thing_for_namelist;	/* to keep ranlib/lorder quiet */
