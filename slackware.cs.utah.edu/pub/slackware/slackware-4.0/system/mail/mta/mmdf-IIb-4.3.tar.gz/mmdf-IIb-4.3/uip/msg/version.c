char      *verdate = "3 Jun 1994 Update #43";
