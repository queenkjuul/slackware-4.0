/*
 * Copyright (c) 1980 Regents of the University of California.
 * All rights reserved.  The Berkeley software License Agreement
 * specifies the terms and conditions for redistribution.
 */

#ifndef lint
static char *sccsid = "@(#)version.c	5.2 (Berkeley) 6/21/85";
#endif not lint

/*
 * Just keep track of the date/sid of this version of Mail.
 * Load this file first to get a "total" Mail version.
 */
#ifndef lint
static	char	*SccsID = "@(#)UCB Mail Version 5.2 (6/21/85)";
#endif
char	*version = "5.2 6/21/85";
