/* @(#) $Id: copyright.c,v 1.3 1992/07/11 11:48:11 tron Exp $ */

/*
 *    Copyright (C) 1987, 1988 Ronald S. Karr and Landon Curt Noll
 *    Copyright (C) 1992  Ronald S. Karr
 * 
 * See the file COPYING, distributed with smail, for restriction
 * and warranty information.
 */

/*
 * copyright.c:
 *	include a copyright notice in the smail binary.
 */
static char copyright[] =
"\
Copyright (C) 1987, 1988 Ronald S. Karr and Landon Curt Noll\n\
\n\
SMAIL is free software and you are welcome to distribute copies of it\n\
under certain conditions.  Consult a file COPYING, distributed in the\n\
source for SMAIL to see the conditions";
