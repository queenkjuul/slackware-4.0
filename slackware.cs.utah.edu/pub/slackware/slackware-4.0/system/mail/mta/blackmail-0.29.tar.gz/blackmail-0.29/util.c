/*
** BlackMail
** Utility routines
*/

#include "blackmail.h"

/*
 * Added 07/30/97: Four more entries to the strip table.
 */
/* removed " from strip table - jsm 98/02/07 */
/* removed ] from strip table - jsm 98/02/19 */
static char striptable[] = { '(', ')', '<', '>', '\r', ' ', ',', '\'', 0 };

/*
 * Added 07/30/97: Removed ampersand from invalid table.  Some mailers are
 *                 dependent on this.
 */
static char invaltable[] = { '#', '$', '^', '*', '{', '}', 0 };

/*
 * List of reply strings to give to sites depending on data that comes
 * back.  This is used in order to speed up changes to the source and
 * just made sense after going through some optimizations.
 */
#if defined(DEBUG2) || defined(PASSIVE)
char *debugreplystrings[] = {
    "220-Connection timed out.  You should install identd.\r\n",
    "220-Service reply accepted from identd server.\r\n",
    "421 Service shutting down.  No configuration file present\r\n",
    "450 Your site has been banned from sending mail here. DEBUG\r\n",
    "421 Closing SMTP connection because your site is too slow.\r\n",
    "421 Service shutting down.  You need to install identd.\r\n",
    "450 Bulk redistribution of E-Mail is not accepted here. DEBUG\r\n",
    "450 Invalid X-UIDL given in message headers. DEBUG\r\n",
    "402 Sorry, we do not allow this operation. DEBUG\r\n",
    "404 Your site contains an illegal character. DEBUG\r\n",
    "450 Command rejected.  Missing username or domain name. DEBUG\r\n",
    "450 E-Mail relaying is not allowed here. DEBUG\r\n",
    "452 Invalid domain \"%s\" specified in \"%s\". DEBUG\r\n",
    "454 E-Mail address \"%s\" is not legal. DEBUG\r\n",
    "454 Received line contains an invalid header. DEBUG\r\n",
    "450 Internet Address incorrect.  Must contain username and/or domain.DEBUG\r\n",
    "450 Your mail contains a header that is associated with spam.DEBUG\r\n",
    "450 Your E-Mail is redundant.  You cannot send E-Mail to yourself.DEBUG\r\n",
    "421 DNS lookup on \"%s\" failed.  Closing connection.DEBUG\r\n",
    "450 You cannot send an HTML document as E-Mail to this site.DEBUG\r\n",
    "450 Authenticated sender is invalid.DEBUG\r\n",
    "450 Message-ID \"%s\" is invalid.DEBUG\r\n",
    "450 Site \"%s\" is blacklisted on the RBL, see http://maps.vix.com/rbl DEBUG\r\n",
    "450 Email contains lines which are too long.DEBUG\r\n",
    NULL
};
#endif

char *replystrings[] = {
    "220-Connection timed out.  You should install identd.\r\n",
    "220-Service reply accepted from identd server.\r\n",
    "421 Service shutting down.  No configuration file present.\r\n",
    "550 Your site has been banned from sending mail here.\r\n",
    "421 Closing SMTP connection because your site is too slow.\r\n",
    "421 Service shutting down.  You need to install identd.\r\n",
    "550 Bulk redistribution of E-Mail is not accepted here.\r\n",
    "550 Invalid X-UIDL given in message headers.\r\n",
    "502 Sorry, we do not allow this operation.\r\n",
    "504 Your site contains an illegal character.\r\n",
    "550 Command rejected.  Missing username or domain name.\r\n",
    "550 E-Mail relaying is not allowed here.\r\n",
    "552 Invalid domain \"%s\" specified in \"%s\".\r\n",
    "554 E-Mail address \"%s\" is not legal.\r\n",
    "554 Received line contains an invalid header.\r\n",
    "550 Internet Address incorrect.  Must contain username and/or domain.\r\n",
    "550 Your mail contains a header that is associated with spam.\r\n",
    "550 Your E-Mail is redundant.  You cannot send E-Mail to yourself (%s).\r\n",
    "421 DNS lookup on \"%s\" failed.  Closing connection.\r\n",
    "550 You cannot send an HTML document as E-Mail to this site.\r\n",
    "550 Authenticated sender is invalid.\r\n",
    "550 Message-ID \"%s\" is invalid.\r\n",
    "550 Site \"%s\" is blacklisted on the RBL, see http://maps.vix.com/rbl\r\n",
    "550 Email contains lines which are too long.\r\n",
    NULL
};

void strip_crap2(char *str)
{
    char *P, *newstr;
    int done = 0, q = 0;
	
    newstr = (char *)malloc(BM_LINE_BUF);
    strncpy(newstr, str, BM_LINE_BUF);

    /* find first @ */
    /* changed to find _last_ in case we find a source routed address */
    P = (char *) rindex(newstr, '@');

    /* this can occur if we let a fake address through using DEBUG2 */
    if (P == NULL)
	return;

    /* then mark \0 at first stripable char */
    while (*P != '\0') {
	P++;
	if (in_strip( (char)*P) )
	    *P = '\0';
    }

    /* then work backwards from @ to find another stripable char
        and make the char after this the start of the string */

    /* changed to find _last_ in case we find a source routed address */
    /* BUT need to allow from "quoted string"@host.domain case
       jsm 98/02/07 */
    
    P = (char *) rindex(newstr, '@');
    while (!done) {
	P--;
	if ((in_strip( (char)*P ) && !q) || P < newstr) {
	    P++;
	    done = 1;
	} else
	    if (*P == '"')
		q = !q;
    }
strcpy(str, P);
free(newstr);
}

int in_strip(char c)
{
    int i;

    for (i = 0; striptable[i] != 0; i++) {
	if (c == striptable[i])
		return(1);
    }
    return(0);
}

int isInvalid(char *str)
{
    int i, j,l;
    l = strlen(str);
    for(i = 0; i < l; i++) {
	for(j = 0; invaltable[j] != 0; j++) {
	    if (str[i] == invaltable[j])
		return 1;
	}
    }
    
    return 0;
}

void checkAddress(char *str, char *reason, char *line_data, char *extract)
{
    char newstr[BM_ADDR_BUF];
    char *data, *tmp, *tmp2;
    int i, found = 0;
 
    bzero(newstr, BM_ADDR_BUF);

    /*
     * Patched by Karsten Jeppesen <kj@yarc.com>
     * Originally didn't check the address according to received rules.
     * It does now!
     */
    checkReceived(str);
    
    strncpy(newstr, str, BM_ADDR_BUF);

    extract_address(newstr);

    /* if the calling routine wanted it, we can save a copy of the address */
    if (extract)
	strcpy(extract, newstr); 

    /*
     * Patched by Karsten Jeppesen <kj@yarc.com>
     * Fixed by Ken Hollis <khollis@chatlink.com> to give a real error reply
     * Re-modified to use "has" routine instead of "index".
     */
    if (!has(newstr, '@')) {
	if (!has(newstr, '.')) {
	    if ((strstr(newstr, "Multiple recipients of list")) != NULL)
		return;	/* This skips over all the other checks.  (Potential hazard?) */
	    else {
		illegal_email_address(newstr, line_data);
	    }
	} else
		illegal_email_address(newstr, line_data);
    }
    
    /*
     * Found an "@", assume the user has "user@some-domain.com".
     */
    /* first check for domain literal "user@[a.b.c.d]" */

    if (wildmat(newstr, "*@\\[*.*.*.*\\]*")) {
	/* Received email@[a.b.c.d] format, convert numeric to name */

	/* remove square brackets */
	tmp = rindex(newstr, ']' );
	*tmp = '\0';
        tmp = rindex(newstr, '[');

	if ((tmp2 = number_lookup(tmp +1, line_data)) == NULL)
	    return; /* can only get here in DEBUG2 or PASSIVE */

	/* now replace the IP address with the hostname and continue */
	strcpy(tmp, tmp2);
    }

    data = (char *) rindex(newstr, '.');

    if (data) {
	data++;
	for(i = 0; i < num_tlds; i++) {
	    if ((!strncasecmp(tlds[i], data, strlen(tlds[i]))) &&
		(strlen(tlds[i]) == strlen(data))) {
		found = 1;
		break;
	    }
	}

	if (!found) {
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf("454-Bogus Top-Level Domain specified in \"%s\" field (or none given.)\r\n", reason);
	    printf("454-If this is an anonymous mailing list, your mail will not be allowed\r\n");
	    printf("454 to pass through unless you supply a valid address in the reply field.\r\n");
	    fflush(stdout);
#endif
	    syslog(LOG_NOTICE, "(debug)Rejected: TLD invalid \"%s\" (%s)", data, ident_user);
	    syslog(LOG_NOTICE, "(debug)Reject line: \"%s\"", line_data);
	    return;
#else
	    printf("554-Bogus Top-Level Domain specified in \"%s\" field (or none given.)\r\n", reason);
	    printf("554-If this is an anonymous mailing list, your mail will not be allowed\r\n");
	    printf("554 to pass through unless you supply a valid address in the reply field.\r\n");
	    fflush(stdout);

	    syslog(LOG_NOTICE, "Rejected: TLD invalid \"%s\" (%s)", data, ident_user);
	    syslog(LOG_NOTICE, "Reject line: \"%s\"", line_data);

	    closelog();
	    exit(0);
#endif
	}

	if (isInvalid(newstr))
	    illegal_email_address(newstr, line_data);

 	/* more address checks */

	data = (char *) rindex(newstr, '@');
	data++;

#ifdef DNS_CHECK
	if (!dnslookup(data)) {
#else
	    /* perform a very simplistic check to exclude From: .com */
	if (data[0] == '.' ) {
#endif
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[INVALID_DOMAIN], data, reason);
	    fflush(stdout);
#endif
	    syslog(LOG_NOTICE, "(debug)Rejected invalid domain \"%s\" from %s", data, ident_user);
	    return;
#else
	    printf(replystrings[INVALID_DOMAIN], data, reason);
	    fflush(stdout);

	    syslog(LOG_NOTICE, "Rejected invalid domain \"%s\" from %s", data, ident_user);
	    exit(0);
#endif
	}
    } else {
	/* only fake addresses _seem_ to get here - so double check */
	if (!wildmat(newstr, "*@*.*") )
	    illegal_email_address(newstr, line_data);
    }
}

#ifdef DNS_CHECK
int dnslookup(BM_GHBN data)
{
    extern int h_errno;
    struct hostent *host_info;
#ifdef RBL_CHECK_ALL
    char ip[15];
#endif
#ifdef DEBUG
    syslog(LOG_NOTICE, "About to execute gethostbyname(\"%s\")\n", data);
#endif
    if ( (host_info = gethostbyname( data)) == NULL ) {
	switch (h_errno) {
	    case NO_DATA:
		/* address valid. should ACCEPT mail
		 * note: this was NO_ADDRESS but NO_DATA seems to
		 * be the correct form.
		 */
#ifdef DEBUG
		syslog(LOG_NOTICE, "dns OK (NO_DATA)");
#endif
		break;
	    case HOST_NOT_FOUND:
#ifdef DEBUG
		syslog(LOG_NOTICE, "dns (HOST_NOT_FOUND)");
#endif
		return(0);
		break;
	    case NO_RECOVERY:
#ifdef DEBUG
		syslog(LOG_NOTICE, "dns error occured (NO_RECOVERY)");
#endif
	    case TRY_AGAIN:
	    default:
#if defined (DEBUG2) || defined (PASSIVE)
		debug_reject++;
#ifndef PASSIVE
		printf(debugreplystrings[DNS_TIMEOUT], data);
		fflush(stdout);
#endif
		syslog(LOG_NOTICE, "(debug)DNS check on \"%s\" gave error deferring mail", data);
#else
		printf(replystrings[DNS_TIMEOUT], data);
		fflush(stdout);

		syslog(LOG_NOTICE, "DNS check on \"%s\" gave error, deferring mail", data);
		exit(0);
#endif
	    break;
	}
    }
    else {
	/* host lookup was ok, should ACCEPT mail */
#ifdef DEBUG
	syslog(LOG_NOTICE, "dns OK");
#endif

#ifdef RBL_CHECK_ALL
	/* Now do an RBL (Realtime Blackhole List) check
	 * This section added 22 Jan 1998 - jsm
	 */

	sprintf(ip, "%d.%d.%d.%d",
	       (int)(unsigned char)host_info->h_addr_list[0][0], (int)(unsigned char)host_info->h_addr_list[0][1], (int)(unsigned char)host_info->h_addr_list[0][2], (int)(unsigned char)host_info->h_addr_list[0][3] );

	if (rblcheck(ip)) {
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[RBL_BLOCKED], data);
	    fflush(stdout);
#endif
	    syslog(LOG_NOTICE, "(debug)Rejected RBL blocked site \"%s\" [%s]", data, ip);
#else
	    printf(replystrings[RBL_BLOCKED], data);
	    fflush(stdout);

	    syslog(LOG_NOTICE, "Rejected RBL blocked site \"%s\" [%s]", data, ip);
	    exit(0);
#endif /* DEBUG2, PASSIVE */
	}
#endif /* RBL */
    }

    /*  return as if ok, unless host does NOT exist, hoping other end will
	make some sense of any 4xx */
    return(1);
}
#endif

void checkReceived(char *data)
{
    int i;

    for(i = 0; i < num_headers; i++)
	if (wildmat(data, headers[i])) {
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[SPAM_HEADER]);
	    fflush(stdout);
#endif
	    syslog(LOG_NOTICE, "(debug)Received header check matched - mail rejected.");
	    syslog(LOG_DEBUG, "Bad header line: %s matched %s\n\r",data,headers[i]);
	    return;
#else
	    printf(replystrings[SPAM_HEADER]);
	    fflush(stdout);

	    syslog(LOG_NOTICE, "Header check matched %s - mail rejected.", headers[i]);
	    exit(0);
#endif
	}
}

void checkAddressRejected(char *data)
{
    int i;

    if (isInvalid(data)) {
#if defined (DEBUG2) || defined (PASSIVE)
	debug_reject++;
#ifndef PASSIVE
	printf(debugreplystrings[SITE_ILLEGAL_CHAR]);
	fflush(stdout);
#endif
	syslog(LOG_NOTICE, "(debug)Address given by %s was invalid.", ident_user);
	syslog(LOG_DEBUG, "Invalid Data: %s",data);
#else
	printf(replystrings[SITE_ILLEGAL_CHAR]);
	fflush(stdout);
	
	syslog(LOG_NOTICE, "Address given by %s was invalid.", ident_user);
	exit(0);
#endif
    }
    for(i = 0; i < num_spamsites; i++)
	if (wildmat(data, spamsites[i])) {
	    /* if mail is from a relay its not this site (messages changed) */
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[SITE_BANNED]);
	    fflush(stdout);
#endif	    
	    syslog(LOG_NOTICE, "(debug)Rejected spam from %s.", ident_user);
	    syslog(LOG_DEBUG, "Site Matched: %s matches(%s).",data,spamsites[i]);
	    return;
#else
	    printf(replystrings[SITE_BANNED]);

	    fflush(stdout);
	    
	    syslog(LOG_NOTICE, "Rejected spam from %s.", ident_user);
	    exit(0);
#endif
	}
}

int has(char *str, char ch)
{
    int i, l;
    l = strlen(str);
    for(i = 0; i < l; i++)
	if (str[i] == ch)
	    return 1;

    return 0;
}

/* SunOS 4.x does not have strerror(). */

#if defined(__sun__) && !defined(__svr4__)
extern int sys_nerr;
extern char *sys_errlist[];

char* strerror(int err)
{
    if(err>0 && err<sys_nerr)
	return(sys_errlist[err]);
    else
	return("Unknown error");
}
#endif

/* converts string to lowercase, overwriting original string */
void strtolower(char *str)
{
    char *p = str;
    while (*p != '\0' ) {
	*p = tolower(*p);
	p++;
    }
}

void extract_address(char *line) {
    char *tmp;
    int i=0, b=0, ab=-1, at=0, abok=0, q=0, B[BM_LINE_BUF];

    tmp = (char *)malloc(BM_LINE_BUF);

    /* want to search out <*@*> not within a comment as the preferred address */

    while ((line[i] != '\0') && (abok == 0)) {
	switch (line[i]) {
	    case ')':
		strncpy(tmp, line + i + 1, BM_LINE_BUF);
		/* almost to RFC822 (3.4.3)
		 * a comment is lexically equivalent with a single SPACE
		 */
		strcpy(line + B[b], " ");
		strcpy(line + B[b] +1, tmp);
		i = B[b]+1;
		b--;
		break;
	    case '(':
		b++;
		B[b] = i;
		i++;
		break;
	    case '<':
		if (!b && !q) {
#ifdef DEBUG
		    if (ab >= 0)
			syslog(LOG_NOTICE, "Too many angle brackets: <  in %s\n", line);
#endif
		    ab = i;
		    at = 0;
		}
		i++;
		break;
	    case '@':
		if (!b && !q && (ab >= 0))
		    at = 1;
		i++;
		break;
	    case '>':
		if (!b && !q && (ab >= 0)) {
		    /* we're done */
		    line[i] = '\0';
		    strncpy(tmp, line + ab + 1, BM_LINE_BUF);
		    strcpy(line, tmp);
		    abok = 1;
		}
		i++;
		break;
	    case '\\':
	        if (line[i+1] != '\0')
		    i++;
		i++;
		break;
	    case '"':
		q = !q;
		i++;
	    default:
		i++;
	}
    }
    /* just to be fully sure */
    strip_crap2(line);
#ifdef DEBUG
	syslog(LOG_NOTICE, "Extracted address %s", line);
#endif
}

/* The following routine saves repeating the same chunk of code lots */
void illegal_email_address(char *newstr, char *line_data)
{
#if defined (DEBUG2) || defined (PASSIVE)
    debug_reject++;
#ifndef PASSIVE
    printf(debugreplystrings[ILLEGAL_EMAIL_ADDRESS], newstr);
    fflush(stdout);
#endif
    syslog(LOG_NOTICE, "(debug)Rejected: invalid address: <%s>", newstr);
    syslog(LOG_NOTICE, "(debug)Reject line: %s", line_data);
    return;
#else
    printf(replystrings[ILLEGAL_EMAIL_ADDRESS], newstr);
    fflush(stdout);

    syslog(LOG_NOTICE, "Rejected: invalid address: <%s>", newstr);
    syslog(LOG_NOTICE, "Reject line: %s", line_data);

    closelog();
    exit(0);
#endif
}

char *number_lookup(char *dotted_quad, char *line)
{
	struct in_addr numeric;
	struct hostent *host_tmp;

        if ((numeric.s_addr = inet_addr(dotted_quad)) == -1) {
#if defined(DEBUG2) || defined(PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[INVALID_DOMAIN], dotted_quad, line);
	    fflush(stdout);
#endif
            syslog(LOG_NOTICE, "(debug)Rejected invalid IP address [%s]\n", dotted_quad);
            return NULL;
#else
	    printf(replystrings[INVALID_DOMAIN], dotted_quad, line);
	    fflush(stdout);
	    syslog(LOG_NOTICE, "Rejected invalid IP address [%s]\n", dotted_quad);
	    exit(0);
#endif
	}

    if ((host_tmp = gethostbyaddr((char *)&numeric, sizeof(struct in_addr),
                              AF_INET)) == NULL) {
	switch (h_errno) {
	    case HOST_NOT_FOUND:
#if defined(DEBUG2) || defined(PASSIVE)
		debug_reject++;
#ifndef PASSIVE
		printf(debugreplystrings[INVALID_DOMAIN], dotted_quad, line);
		fflush(stdout);
#endif
		syslog(LOG_NOTICE, "(debug)Rejected invalid IP address [%s]\n", dotted_quad);
		return NULL;
#else
		printf(replystrings[INVALID_DOMAIN], dotted_quad, line);
		fflush(stdout);
		syslog(LOG_NOTICE, "Rejected invalid IP address [%s]\n", dotted_quad);
		exit(0);
#endif
	    default:
#if defined (DEBUG2) || defined (PASSIVE)
		debug_reject++;
#ifndef PASSIVE
		printf(debugreplystrings[DNS_TIMEOUT], dotted_quad);
		fflush(stdout);
#endif
		syslog(LOG_NOTICE, "(debug)DNS check on \"%s\" gave error deferring mail", dotted_quad);
		return NULL;
#else
		printf(replystrings[DNS_TIMEOUT], dotted_quad);
		fflush(stdout);

		syslog(LOG_NOTICE, "DNS check on \"%s\" gave error, deferring mail", dotted_quad);
		exit(0);
#endif
	}
    }
    return (char *)host_tmp->h_name;
}
