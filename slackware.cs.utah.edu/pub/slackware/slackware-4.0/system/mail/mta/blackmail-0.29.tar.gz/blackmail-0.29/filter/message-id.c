/*
** BlackMail Proxy
** Message-ID filter rule
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>

#include "../blackmail.h"

void filter_message_id(char *data, char *orig_data)
{
/* Here we check that the only allowed format is:
   Message-ID: <whatever@domain.TLD>
   Wildmat check changed from *<*@*>* 98/1/1 jsm
*/
    if (!wildmat(orig_data, "*<?*@?*>*")) {
#if defined (DEBUG2) || defined (PASSIVE)
	debug_reject++;
#ifndef PASSIVE
	printf(debugreplystrings[INVALID_ID], orig_data);
	fflush(stdout);
#endif
	syslog(LOG_NOTICE, "(debug)Rejected invalid Message-ID \"%s\"\n", orig_data);
#else
	printf(replystrings[INVALID_ID], orig_data);
	fflush(stdout);

	syslog(LOG_NOTICE, "Rejected invalid Message-ID \"%s\"\n", orig_data);
	exit(0);
#endif
    }
    else {
	/* in here need to do some checks that the message-id contains a
	 * real domain using the dns check.
	 * BUT, is this always true? What about real machines not directly on
	 * the 'net?
	 *
	 * Jan 1998
	 * From reading RCF822 it is clear what format Message-ID should take,
	 * but it does not state whether the domain part needs to be
	 * resolvable.
	 * Checking through IDs I have received, there are a number from
	 * genuine senders that would be rejected.
	 */
    }
}
