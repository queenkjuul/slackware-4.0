/*
** BlackMail
** Quit Handler
*/

#include "../blackmail.h"

void Quit(char *data)
{
    fprintf(mailer, "QUIT\r\n");
    fflush(mailer);
    fflush(stdout);

    did_quit = 1;

    if (headers_from > 5)
	syslog(LOG_NOTICE, "Sender possibly sent a chain-letter.");

    syslog(LOG_NOTICE, "%s closed connection.", ident_user);
    fclose(mailer);

    closelog();
    exit(0);
}
