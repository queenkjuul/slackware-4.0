/*
** BlackMail
** Header file
*/

/* T. Rightnour 11/24/97 */
/* This allows you to set the log facility.  Normally you wouldn't want to
 * this, however in combination with DEBUG, you may get alot of logs, so you
 * could set this to LOG_USR1 (or whatever it may be on your implementation
 * and redirect all logs to their own file. */

#ifdef DEBUG
/* Change the next line to log somewhere else in debug mode.
   See your syslog man pages for more info */
#define FACILITY LOG_MAIL
#else
#define FACILITY LOG_MAIL
#endif

#define MAXLINES 1000
#define BM_LINE_BUF 2048
#define BM_ADDR_BUF 1023
#define BM_HOST_BUF 80
#define BM_CONF "/etc/blackmail.conf"

/*** -- DO NOT CHANGE ANYTHING BELOW THIS LINE! -- ***/

#define	VERSION	"0.29 (5 Oct 98)"

/* All of the #includes from the rest of the source are now here. This
 * was prompted by Solaris and SunOs refusing to compile with the way the
 * code was written. Order based on old samba code. 20 Apr 1998
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>

#if defined(__sun__)
#include <strings.h>
#else
#include <string.h>
#endif

#include <fcntl.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <pwd.h>
#include <sys/stat.h>
#include <syslog.h>
#include <utmp.h>

#ifdef NEXT
#include <libc.h>
#else
#include <malloc.h>
#endif

#ifndef AIX
#include <arpa/inet.h>
#endif


/* end of includes */

#define	CONNECTION_TIMEOUT	0
#define	IDENT_REPLY_OK		1
#define	NO_CONFIG_FILE		2
#define	SITE_BANNED		3
#define	SITE_TOO_SLOW		4
#define	SITE_NEEDS_IDENTD	5
#define	NO_BULK_MAIL		6
#define	INVALID_UIDL		7
#define	OPERATION_NOT_ALLOWED	8
#define	SITE_ILLEGAL_CHAR	9
#define	MISSING_USER_OR_DOMAIN	10
#define	NO_EMAIL_RELAY		11
#define	INVALID_DOMAIN		12
#define	ILLEGAL_EMAIL_ADDRESS	13
#define	INVALID_HEADER		14
#define	ILLEGAL_EMAIL_HEADER	15
#define	SPAM_HEADER		16
#define	REDUNDANT_MAIL		17
#define	DNS_TIMEOUT		18
#define	NO_HTML_EMAIL		19
#define INVALID_AUTH_SENDER	20
#define INVALID_ID		21
#define RBL_BLOCKED		22
#define LINE_TOO_LONG		23

extern char *ip_address, *ident_user, *tofromaddress, *mailfile, *lochost;
extern char *spamsites[MAXLINES], *headers[MAXLINES], *tlds[MAXLINES],
	    *localhosts[MAXLINES], *allowedmail[MAXLINES];
extern char *replystrings[];
#if defined(DEBUG2) || defined(PASSIVE)
extern char *debugreplystrings[];
extern int debug_reject;
#endif
extern char mail_from[BM_ADDR_BUF], helo_from[BM_ADDR_BUF];
extern int bounce, command_line, did_quit, num_rcpt, headers_from;
extern int data_mode, num_spamsites, num_headers, num_tlds;
extern int gave_mail, gave_rcpt, gave_headers, header_mode;
extern int num_localhosts, num_allowedmail, outbound, allow_vrfy;
extern long smtp_timeout;
extern FILE *mailer;

/* typedef of gethostbyname argument */
#ifndef NEXT
#define BM_GHBN const char *
#else
#define BM_GHBN char *
#endif

/*** PROTOTYPES ***/
void startMailer();
void loadConfig();
int wildmat(char *, char *);

void Data(char *);
void Quit(char *);
void Rcpt(char *);
void Mail(char *);
void Helo(char *);
void Ehlo(char *);
void Expn(char *);
void Vrfy(char *);

void checkAddress(char *, char *, char *, char *);
void checkReceived(char *);
void checkAddressRejected(char *);
int has(char *, char);
int dnslookup(BM_GHBN);

#if defined(__sun__) && !defined(__svr4__)
char *strerror(int);
#endif

int in_strip(char);
void strip_crap2(char *);
void strtolower (char *);
void extract_address(char *);
void illegal_email_address(char *, char *);
char *number_lookup(char *, char *);
void resetglobals(void);

#ifdef RBL_CHECK
int rblcheck(char *);
#define RBL_DNS_HOST "rbl.maps.vix.com"
#define RBL_BUF_SIZE 255 /* Is this enough? */
#define RBL_DOMAIN_LENGTH 32 /* "xxx.xxx.xxx.xxx.rbl.maps.vix.com" */
#endif

void filter_reply_to(char *, char *);
void filter_from(char *, char *);
void filter_to(char *, char *);
void filter_received(char *, char *);
void filter_distribution(char *, char *);
void filter_comments(char *, char *);
void filter_message_id(char *, char *);
void filter_apparently_to(char *, char *);
