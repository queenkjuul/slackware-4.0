/*
** BlackMail
** Mail From processor
*/

#include "../blackmail.h"

void Mail(char *data)
{
    char *tmp;

    bzero(mail_from, BM_ADDR_BUF);

    sscanf(data, "%*[^:]:%[^\r\n]\r\n", mail_from);

    /* rfc821 says MAIL FROM:<> is ok, so let it through */
    if (strcmp("<>", mail_from)) {

        if (!outbound) {
	    tmp = (char *)malloc(BM_ADDR_BUF);
	    strncpy(tmp, data, BM_ADDR_BUF);
	    strtolower(tmp);
	    checkAddress(mail_from, "MAIL from:", tmp, NULL);
	    checkAddressRejected(tmp);
	    free(tmp);
        }

    } else
	syslog(LOG_NOTICE, "Possible bounced mail coming in.");

    gave_mail = 1;

    fprintf(mailer, "MAIL from:%s\r\n", mail_from);
    fflush(mailer);
    fflush(stdout);
}
