/*
** BlackMail Proxy
** Reply-to Filtering Agent
*/

#include "../blackmail.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>

void filter_reply_to(char *data, char *orig_data)
{
    checkAddressRejected( orig_data);
    checkAddress(data, "Reply-To", orig_data, NULL);
}
