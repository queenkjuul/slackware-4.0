/*
** BlackMail Proxy
** VRFY command filter
*/

#include "../blackmail.h"

void Vrfy(char *data)
{
    if (allow_vrfy) {
	fprintf(mailer, "VRFY %s", data);
	fflush(mailer);
    } else {
	syslog(LOG_NOTICE, "VRFY rejected for %s", ident_user);

	printf(replystrings[OPERATION_NOT_ALLOWED]);
	fflush(stdout);
    }
}
