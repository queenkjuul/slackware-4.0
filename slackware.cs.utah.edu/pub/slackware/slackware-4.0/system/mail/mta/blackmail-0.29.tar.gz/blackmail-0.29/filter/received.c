/*
** BlackMail Proxy
** Received filter rule
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>

#include "../blackmail.h"

void filter_received(char *data, char *orig_data)
{
    checkReceived(data);
}
