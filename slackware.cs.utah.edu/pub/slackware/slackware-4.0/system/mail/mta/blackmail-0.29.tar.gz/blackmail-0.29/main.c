/*
** Blackmail Mailer Wrapper for SMAIL
** Written by Ken Hollis <khollis@chatlink.com>
** Maintained by James Murray <jsm@jsm-net.demon.co.uk>
*/

#include "blackmail.h"

#ifndef RD
#define RD      0
#define WD      1
#endif

char *ip_address, *ident_user, *remote_addr, *tofromaddress, *lochost;
static int remote_port, local_port;
int bounce, command_line, did_quit, num_rcpt, headers_from, debug_reject;
long smtp_timeout;

void alarmRFC1413(int signal)
{
    syslog(LOG_NOTICE, "Timeout on IDENT Query.");
    ident_user = "unknown";

#ifdef	IDENT_INTERACT
    printf(replystrings[CONNECTION_TIMEOUT]);
    fflush(stdout);
#endif
}

char *getRFC1413(void)
{
    int i, j;
    struct sockaddr_in sin;
    char buffer[1024], buf[256], uname[64], *bleah;

    bleah = (char *) malloc(BM_ADDR_BUF);
    bzero(bleah, BM_ADDR_BUF);

#ifdef	IDENT_INTERACT
    printf("220-Connecting to IDENTD server.\r\n");
#ifdef DEBUG2
    syslog(LOG_DEBUG, "Connecting to ident server, %s", remote_addr);
#endif
    fflush(stdout);
#endif

    j = socket(AF_INET, SOCK_STREAM, 0);
    if (j < 2) {
	sprintf(bleah, "%s", remote_addr);
	syslog(LOG_ERR, "rfc1413-socket: %s", strerror(errno));
	return(bleah);
    }

    sin.sin_family = AF_INET;
    sin.sin_port = getservbyname("auth", "tcp")->s_port;
    sin.sin_addr.s_addr = inet_addr(ip_address);

    signal(SIGALRM, alarmRFC1413);
    alarm(5);

    i = connect(j, (struct sockaddr *) &sin, sizeof(sin));
    if (i < 0) {
	close(j);
	sprintf(bleah, "%s", remote_addr);
	alarm(0);
	return(bleah);
    }

#ifdef	IDENT_INTERACT
    printf("220-Connected, sending request to server.\r\n");
#ifdef DEBUG2
    syslog(LOG_DEBUG,"Connected to remote ident server.");
#endif /* debug2 */
    fflush(stdout);
#endif

    sprintf(buffer, "%d,%d\n", remote_port, local_port);
    write(j, buffer, strlen(buffer));

    if (read(j, buf, 256) <= 0) {
	sprintf(bleah, "%s", remote_addr);
    } else {
	sscanf(buf, "%*d , %*d : %*[^ \t\n\r:] : %*[^\t\n\r:] : %[^\n\r]", uname);

	if ((uname[0] == 0) || (uname[0] == 13) || (uname[0] == 10) ||
	    (uname[0] == ' '))
	    sprintf(bleah, "%s", remote_addr);
	else
	    sprintf(bleah, "%s@%s", uname, remote_addr);
    }

    alarm(0);

#ifdef	IDENT_INTERACT
    printf(replystrings[IDENT_REPLY_OK]);
#ifdef DEBUG2
    syslog(LOG_DEBUG, "Remote user is %s",bleah);
#endif
    fflush(stdout);
#endif

    (void) shutdown(j, 2);
    close(j);

    return(bleah);
}

char *getHost(void)
{
    struct sockaddr_in socket_addr;
    struct hostent *host_ent;
    int psize = 0;

    psize = sizeof(socket_addr);

    if (getsockname(0, (struct sockaddr *) &socket_addr, (size_t *) &psize)) {
	syslog(LOG_WARNING, "getsockname: %s", strerror(errno));
	local_port = 0;
    } else
	local_port = ntohs(socket_addr.sin_port);

    if (getpeername(0, (struct sockaddr *) &socket_addr, (size_t *) &psize)) {
	syslog(LOG_ERR, "getpeername: %s", strerror(errno));
	closelog();

	fprintf(stderr, "This is not a command-line program.  Try blackmail -h\n");
	exit(-1);
    } else
	remote_port = ntohs(socket_addr.sin_port);

    ip_address = inet_ntoa(socket_addr.sin_addr);

    host_ent = (struct hostent *) gethostbyaddr((char *) &socket_addr.sin_addr,
	sizeof(socket_addr.sin_addr), AF_INET);

    if (host_ent == NULL)
	remote_addr = inet_ntoa(socket_addr.sin_addr);
    else
	remote_addr = (char *) host_ent->h_name;

#ifdef DISABLE_IDENT
    ident_user = ip_address;
#else
    ident_user = getRFC1413();
#endif
    return(ident_user);
}

void alarmHandler(int signal)
{
    printf(replystrings[SITE_TOO_SLOW]);
    fflush(stdout);

    syslog(LOG_NOTICE, "%s SMTP timed out after %d min.", ident_user,
	(smtp_timeout / 60));

    exit(-1);
}

static void give_greeting(void)
{
    if (*lochost != 0) {
	printf("220-%s BlackMail-%s\r\n", lochost, VERSION);
    } else {
#if defined(__NetBSD__) || defined(__FreeBSD__) || defined(__OpenBSD__)
	char host[BM_HOST_BUF];

	bzero(host, BM_HOST_BUF);
	gethostname(host, BM_HOST_BUF);
	printf("220-%s BlackMail-%s\r\n", host, VERSION);
#else
	char host[BM_HOST_BUF];
	char domain[BM_HOST_BUF];

	bzero(host, BM_HOST_BUF);
	bzero(domain, BM_HOST_BUF);
    
	gethostname(host, BM_HOST_BUF);
	getdomainname(domain, BM_HOST_BUF);
	printf("220-%s.%s BlackMail-%s\r\n", host, domain, VERSION);
#endif /* bsd */
    }
#ifdef DEBUG2
    syslog(LOG_DEBUG,"Initial greeting sent: someone has connected");
#endif
}

int main(int argc, char **argv)
{
    char *vmi;
    int pid = getpid();

    bounce = 0;
    command_line = 0;
    data_mode = 0;
    did_quit = 0;
    num_rcpt = 0;
    headers_from = 0;
    tofromaddress = (char *)malloc(BM_ADDR_BUF);
    mailfile = (char *)malloc(80);
    lochost = (char *)malloc(80);

    if (argc > 1) {
	if (!strncasecmp(argv[1], "-c", 2)) {
	    fprintf(stderr, "%s: Command line mode selected.\n", argv[0]);
	    command_line = 1;
	} else if (!strncasecmp(argv[1], "-h", 2)) {
	    fprintf(stderr, "\n");
	    fprintf(stderr, "This is BlackMail %s.\n\n", VERSION);
	    fprintf(stderr, "\t-c\tInitiates command line mode (for testing.)\n");
	    fprintf(stderr, "\t-t\tMake BlackMail report what it believes your host+domain are.\n");
	    fprintf(stderr, "\t-o\tReport what Makefile options BlackMail was built with.\n");
	    fprintf(stderr, "\nSee http://www.bitgate.com/spam/ for more information.\n\n");
	    exit(0);
	} else if (!strncasecmp(argv[1], "-t", 2)) {
#if defined(__NetBSD__) || defined(__FreeBSD__) || defined(__OpenBSD__)
	    char host[BM_HOST_BUF];

	    bzero(host, BM_HOST_BUF);
	    gethostname(host, BM_HOST_BUF);
	    printf("BlackMail's internal routine thinks your site is: %s\r\n", host);
#else
	    char host[BM_HOST_BUF], domain[BM_HOST_BUF];
	    
	    bzero(host, BM_HOST_BUF);
	    bzero(domain, BM_HOST_BUF);
	    
	    gethostname(host, BM_HOST_BUF);
	    getdomainname(domain, BM_HOST_BUF);
	    
	    printf("BlackMail's internal routine thinks your site is: %s.%s\n", host, domain);
#endif
	    loadConfig();
	    if (*lochost != 0)
		printf("\nBut this is overridden by LOCHOST which is: %s\n", lochost);
	    exit(0);
	} else if (!strncasecmp(argv[1], "-o", 2)) {
	    fprintf(stderr, "\nThis is BlackMail %s.\n\n", VERSION);
	    printf("Compiled in options are:\n");
#ifdef DISABLE_IDENT
	    printf("DISABLE_IDENT, ");
#else
#ifdef FULL_HEAD
	    printf("FULL_HEAD, ");
#endif
#ifdef FORCE_IDENT
	    printf("FORCE_IDENT, ");
#endif
#ifdef IDENT_INTERACT
	    printf("IDENT_INTERACT, ");
#endif
#endif /* disable ident */
#ifdef BAN_HTML
	    printf("BAN_HTML, ");
#endif
#ifdef TO_FROM
	    printf("TO_FROM, ");
#endif
#ifdef DNS_CHECK
	    printf("DNS_CHECK, ");
#endif
#ifdef RBL_CHECK
	    printf("RBL_CHECK, ");
#endif
#ifdef RBL_CHECK_ALL
	    printf("RBL_CHECK_ALL, ");
#endif
#ifdef DEBUG
	    printf("DEBUG, ");
#endif
#ifdef DEBUG2
	    printf("DEBUG2, ");
#endif
#ifdef PASSIVE
	    printf("PASSIVE, ");
#endif
#ifdef PASSIVE_RELAY
	    printf("PASSIVE_RELAY, ");
#endif
#ifdef SYSLOG_ALL
	    printf("SYSLOG_ALL, ");
#endif
#if defined(DEBUG2) || defined(PASSIVE)
#ifdef DEBUG_TAGS
	    printf("DEBUG header/footer = %s, ", DEBUG_TAGS);
#endif
#endif
	    printf("\n");
	    exit(0);
	} else {
	    fprintf(stderr, "%s: Use -h for help.\n", argv[0]);
	    exit(0);
	}
    }
    /* need to load the config now as LOCHOST and SMTP_TIMEOUT are needed */
    resetglobals();
    loadConfig();

/* set the alarm handler */
    signal(SIGALRM, alarmHandler);
    alarm(smtp_timeout);

    vmi = malloc(26);
    sprintf(vmi, "blackmail[%d]", pid);

    openlog(vmi, LOG_NDELAY, FACILITY);

    if (!command_line)
	ident_user = getHost();

/* getHost uses alarm so reset the alarm handler */
    signal(SIGALRM, alarmHandler);
    alarm(smtp_timeout);

    if (ip_address == NULL)
	ip_address = "127.0.0.1";
#ifdef DEBUG2
    syslog(LOG_DEBUG,"Connection from %s",ip_address);
#endif
    if (ident_user) {
#ifdef	FORCED_IDENT
	if ((!strncasecmp(ident_user, "unknown", 7)) && (!command_line)) {
	    printf(replystrings[SITE_NEEDS_IDENTD]);
	    fflush(stdout);
	    syslog(LOG_NOTICE, "Exiting, site does not run identd.");
	    exit(-1);
	}
#endif
#ifndef NEXT
	sprintf(argv[0], "blackmail: %s active", ident_user);
#endif
    } else {
	if ((!ident_user) && (!strcmp(ip_address, "127.0.0.1")))
#ifdef NEXT
	/* do nothing */;
#else
	    sprintf(argv[0], "blackmail: localhost active");
#endif
	else {
#ifdef	FORCED_IDENT
	    if ((!strncasecmp(ident_user, "unknown", 7)) && (!command_line)) {
		printf(replystrings[SITE_NEEDS_IDENTD]);
	        syslog(LOG_NOTICE, "Exiting, site does not run identd.");
		fflush(stdout);
		exit(-1);
	    }
#endif
	    ident_user = (char *) malloc(8 + strlen(ip_address) + 1);
	    sprintf(ident_user, "unknown@%s", ip_address);
#ifndef NEXT
	    sprintf(argv[0], "blackmail: %s active", ident_user);
#endif
	}
    }

    give_greeting();
    printf("220-This system is private property.  In order to ensure security,\r\n");
    printf("220-we routinely perform security checks.  In the course of these scans,\r\n");
    printf("220-your activities might be monitored.\r\n");
/*#ifdef DEBUG2
    printf("220-This site is currently in debug mode. Please report any\n\r");
    printf("220-strange activities.\n\r");
#endif
*/
    fflush(stdout);

    startMailer();

    return(0);
}
