/*
** much shortened version of Blackmail util.c just for dnslookup
** <jsm@jsm-net.demon.co.uk>      24 Jan 1998
*/

#include <stdio.h>
#include <netdb.h>

int dnslookup(const char *);

int main(int argc, char **argv)
{
    if (argc != 2) {
	printf("Usage: %s <hostname|MX name>\n", argv[0]);
	exit(-1);
    }
    return(dnslookup(argv[1]));
}


int dnslookup(const char *data)
{
    extern int h_errno;

    struct hostent *host_info;

    printf( "About to execute gethostbyname(\"%s\")\n", data);

    if ( (host_info = gethostbyname( data)) == NULL ) {
	printf("h_errno = %d\n", h_errno);
	switch (h_errno) {
	    case NO_DATA:
		/* address valid. should ACCEPT mail */
		printf("dns OK (NO_DATA)\n");
		break;
	    case HOST_NOT_FOUND:
		printf("dns (HOST_NOT_FOUND)\n");
		return(0);
		break;
	    case NO_RECOVERY:
		printf("dns error occured (NO_RECOVERY)\n");
	    case TRY_AGAIN:
	    default:
		printf("DNS check on \"%s\" gave error\n", data);
		fflush(stdout);
		exit(0);
	    break;
	}
    }
    else {
	/* host lookup was ok, should ACCEPT mail */
	printf("dns OK\n");
    }
    return(1);
}

