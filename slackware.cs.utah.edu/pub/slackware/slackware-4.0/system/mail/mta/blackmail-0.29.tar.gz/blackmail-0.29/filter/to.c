/*
** BlackMail Proxy
** To filter rule
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>

#include "../blackmail.h"

void filter_to(char *data, char *orig_data)
{
#ifdef TO_FROM
    char *tmp;
    tmp = (char *)malloc(BM_ADDR_BUF);

    checkAddressRejected(orig_data);
    checkAddress(data, "To", orig_data, tmp);

    /* use extracted address in *tmp */

    if (*tofromaddress == 0 ) {
	strcpy(tofromaddress, tmp);
#ifdef DEBUG
	syslog(LOG_NOTICE, "Set tofromaddress to %s\n", tofromaddress );
#endif
    } else {
	if ( strcmp( tofromaddress, tmp ) == 0) {
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[REDUNDANT_MAIL], tofromaddress);
	    fflush(stdout);
#endif
	    syslog(LOG_NOTICE, "(debug)Rejected Spam. (To: = From:) %s from %s.", tofromaddress, ident_user);
#else
	    printf(replystrings[REDUNDANT_MAIL], tofromaddress);
	    fflush(stdout);

	    syslog(LOG_NOTICE, "Rejected Spam. (To: = From:) %s from %s.", tofromaddress, ident_user);
	    exit(0);
#endif
	}
    }
    free(tmp);
#else  /* not using TO_FROM */
    checkAddressRejected(orig_data);
    checkAddress(data, "To", orig_data, NULL);
#endif
}
