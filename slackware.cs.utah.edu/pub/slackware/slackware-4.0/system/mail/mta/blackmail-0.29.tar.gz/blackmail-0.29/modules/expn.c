/*
** BlackMail Proxy
** EXPN command filter
*/

#include "../blackmail.h"

void Expn(char *data)
{
    syslog(LOG_NOTICE, "EXPN rejected for %s", ident_user);

    printf(replystrings[OPERATION_NOT_ALLOWED]);
    fflush(stdout);
}
