/*
** BlackMail
** Mailer Dispatch Routines
*/

#include "blackmail.h"

char *spamsites[MAXLINES], *headers[MAXLINES], *tlds[MAXLINES],
	*localhosts[MAXLINES], *allowedmail[MAXLINES],
	*mailfile, *lochost;
char mail_from[BM_ADDR_BUF], helo_from[BM_ADDR_BUF];
int num_spamsites, num_headers, num_tlds, gave_mail, gave_rcpt,
    num_localhosts, num_allowedmail, outbound, outbound_check, allow_vrfy;
long smtp_timeout;
FILE *mailer;

typedef struct {
    char *command;
    void (*function)();
} commandset;

/*
** This is the set of commands that are used to check.  This should be
** updated if you add any of your own commands to this ruleset.
*/
static commandset commands[] = {
	{ "DATA",	Data },
	{ "QUIT",	Quit },
	{ "RCPT",	Rcpt },
	{ "MAIL",	Mail },
	{ "HELO",	Helo },
	{ "EHLO",	Ehlo },
	{ "VRFY",	Vrfy },
	{ "EXPN",	Expn },
	{ NULL,		NULL }
};


void loadConfig(void)
{
    FILE *file;
    char *line, *line_orig;
    int mode = 0, found = 1;

    /* first load built-in tlds */
    #include "tld.c"

    line = line_orig = (char *)malloc(BM_LINE_BUF);

    for(num_tlds=0 ; num_tlds<MAXLINES ; num_tlds++) {
	if (tld_built_in[num_tlds] == 0) break;
	tlds[num_tlds] =  tld_built_in[num_tlds];
    }

    file = fopen(BM_CONF, "r");
    *mailfile = 0;
    *lochost = 0;
    outbound_check = 0;
    allow_vrfy = 0;

    if (file == NULL) {
	printf(replystrings[NO_CONFIG_FILE]);
	fflush(stdout);

	syslog(LOG_NOTICE, "%s: %s", BM_CONF, strerror(errno));
	closelog();

	exit(0);
    }

    while(!feof(file)) {
	line = line_orig;
	bzero(line, BM_LINE_BUF);
	fgets(line, BM_LINE_BUF, file);
	
recheck:
	if (line[0] == '\t') {
	    line++;
	    goto recheck;
	} else if (line[0] == ' ') {
	    line++;
	    goto recheck;
	}

	if ((line[0] != '#') && (line[0] != '\r') && (line[0] != '\n')) {
recheck2:
	    if (line[strlen(line) - 1] == '\r') {
		line[strlen(line) - 1] = 0;
		goto recheck2;
	    } else if (line[strlen(line) - 1] == '\n') {
		line[strlen(line) - 1] = 0;
		goto recheck2;
	    }

	    if (mode > 0) {
		switch(mode) {
		    case 1:
			if (!strncmp(line, "MAILFILE:", 9))
			    strcpy(mailfile, line + 9);
			else if (!strncmp(line, "SMTP_TIMEOUT:", 13))
			    smtp_timeout = strtol(line + 13, NULL, 10);
			else if (!strncmp(line, "LOCHOST:", 8))
			    strcpy(lochost, line + 8);
			else if (!strncmp(line, "IGNORE_OUTBOUND", 15))
			    outbound_check = 1;
			else if (!strncmp(line, "ALLOW_VRFY", 10))
			    allow_vrfy = 1;
			break;
		    case 2:
			headers[num_headers] = malloc(strlen(line) + 1);
			strcpy(headers[num_headers++], line);
			headers[num_headers] = NULL;
			break;

		    case 3:
			spamsites[num_spamsites] = malloc(strlen(line) + 1);
			strcpy(spamsites[num_spamsites++], line);
			spamsites[num_spamsites] = NULL;
			break;

		    case 4:
			tlds[num_tlds] = malloc(strlen(line) + 1);
			strcpy(tlds[num_tlds++], line);
			tlds[num_tlds] = NULL;
			break;

		    case 5:
			localhosts[num_localhosts] = malloc(strlen(line) + 1);
			strcpy(localhosts[num_localhosts++], line);
			localhosts[num_localhosts] = NULL;
			break;

		    case 6:
			allowedmail[num_allowedmail] = malloc(strlen(line) + 1);
			strcpy(allowedmail[num_allowedmail++], line);
			allowedmail[num_allowedmail] = NULL;
			break;
		}
	    } else if (mode == 0) {
		if (!strncasecmp(line, "INTERNAL", 8))
		    mode = 1;
		else if (!strncasecmp(line, "HEADERS", 7))
		    mode = 2;
		else if (!strncasecmp(line, "REJECTED_ADDRESSES", 18))
		    mode = 3;
		else if (!strncasecmp(line, "TLD", 3))
		    mode = 4;
		else if (!strncasecmp(line, "TREAT_AS_LOCALHOST", 18))
		    mode = 5;
		else if (!strncasecmp(line, "ALLOWED_MAIL_SITES", 18))
		    mode = 6;
	    }

	    if ((line[0] == '}') && (line[1] == ';'))
		mode = 0;
	}
    }
    /* some checks that the mandatory INTERNAL variables were read ok */
    if (*mailfile == 0) {
	syslog(LOG_NOTICE, "No MAILFILE defined in %s. Aborting.\n", BM_CONF);
	found = 0;
    }
    if (smtp_timeout == 0) {
	syslog(LOG_NOTICE, "SMTP_TIMEOUT incorrectly defined in %s. Aborting.\n", BM_CONF);
	found = 0;
    }
    if (!found) {
	/* not exact reply string, but its close enough */
	printf(replystrings[NO_CONFIG_FILE]);
	fflush(stdout);
	closelog();
	exit(0);
    }
    free(line_orig);
}
/*
** This routine checks the incoming site (via ident) to make sure it's
** not one of the spamsites listed.  If it is, the site is immediately
** disconnected.
*/
void checkSpammers(void)
{
    int i;

    if (num_spamsites == 0)
	return;

    for(i = 0; i < num_spamsites; i++) {
	if (wildmat(ident_user, spamsites[i])) {
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[SITE_BANNED]);
	    fflush(stdout);
#endif
	    syslog(LOG_NOTICE, "Spamsite -> %s (Rejected)", spamsites[i]);
	    syslog(LOG_DEBUG, "User: %s matches spamsite: %s",ident_user,spamsites[i]);
#else
	    printf(replystrings[SITE_BANNED]);
	    fflush(stdout);

	    did_quit = 1;
	    syslog(LOG_NOTICE, "Spamsite -> %s (Rejected)", spamsites[i]);

	    exit(0);
#endif
	}
    }
}

void openMailer(void)
{
    /*
    ** Since the mailer is running in inetd.conf, we can cheat here
    ** somewhat, since the mailer sends all replies via stderr, and stderr
    ** is not trapped by popen.  But, you knew this already.  :)
    */
    mailer = popen(mailfile, "w");
}

/*
** This is the heart of the mail loop.  This routine actually senses
** whether or not you're in data mode, or whether or not a command should
** be intercepted.  If not, it passes the command through, and BlackMail
** completely ignores it.
**
** Patched to work a little nicer thanks to Martin Patzel (05/20/97)
*/
void mailLoop(void)
{
    char buffer[BM_LINE_BUF], *cp;
    int i;
    bzero(buffer, BM_LINE_BUF);

    if (outbound_check) {
	for(i = 0; i < num_localhosts; i++) {
            if (wildmat(ip_address, localhosts[i]))
		outbound = 1;
		/* this is a global variable that disables checks elsewhere */
	}
#ifdef DEBUG
	if (outbound)
	    syslog(LOG_NOTICE, "Local connection, no checks.");
#endif
    }

#ifdef RBL_CHECK
    if (!outbound) {
	/* Check machine that connected is not blacklisted */
	if (rblcheck(ip_address)) {
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[RBL_BLOCKED], ip_address);
	    fflush(stdout);
#endif
	    syslog(LOG_NOTICE, "(debug)Rejected RBL blocked site [%s]", ip_address);
#else
	    printf(replystrings[RBL_BLOCKED], ip_address);
	    fflush(stdout);

	    syslog(LOG_NOTICE, "Rejected RBL blocked site [%s]", ip_address);
	    exit(0);
#endif /* DEBUG2, PASSIVE */
	}
    }
#endif /* RBL */

    while(fgets(buffer, sizeof(buffer), stdin)) {
	int i, found = 0;

	if (data_mode) {
	    Data(buffer);
	    found = 1;
	} else {
	    for (i = 0; commands[i].command != NULL; i++) {
		if (!strncasecmp(buffer, commands[i].command,
		    strlen(commands[i].command))) {
		    cp = buffer + strlen(commands[i].command);

		    /*
		    ** Skip \r\n sequence after command
		    */
		    if (*cp == '\n' || *cp == '\r')
			cp++;

		    if (*cp == '\n' || *cp == '\r')
			cp++;
#ifdef SYSLOG_ALL
		    /*
		    ** DANGEROUS function
		    */
		    if (!outbound)
			syslog(LOG_NOTICE, "Command sent:%s", buffer);
#endif
		    commands[i].function(cp);

		    found = 1;
		}
	    }
	}

	if (!found) {
	    fprintf(mailer, "%s", buffer);
#ifdef DEBUG2
	    syslog(LOG_DEBUG, "bad command: %s", buffer);
#endif
	    fflush(mailer);
	    fflush(stdout);
	}

	bzero(buffer, BM_LINE_BUF);
    }
}

void resetglobals(void)
{
    num_spamsites = 0;
    gave_mail = 0;
    gave_rcpt = 0;
    gave_headers = 0;
    header_mode = 0;
    num_localhosts = 0;
    num_allowedmail = 0;
}

void startMailer(void)
{
    checkSpammers();
    openMailer();
    mailLoop();
}
