/*
** BlackMail Proxy
** Comments filter rule
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>

#include "../blackmail.h"

void filter_comments(char *data, char *orig_data)
{
    if (strstr(orig_data, "authenticated sender is") == NULL ) {
	checkReceived(orig_data);
    }
    else {
	if (!wildmat(orig_data, "*<*@*>*")) {
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[INVALID_AUTH_SENDER]);
	    fflush(stdout);
#endif
	    syslog(LOG_NOTICE, "(debug)Rejected invalid authenticated sender\n");
#else
	    printf(replystrings[INVALID_AUTH_SENDER]);
	    fflush(stdout);

	    syslog(LOG_NOTICE, "Rejected invalid authenticated sender\n");
	    exit(0);
#endif
	}
	else {
	    checkAddress(data, "Comments", orig_data, NULL);
	}
    }
}
