/*
** rblcheck.c for Blackmail - a modified version of rblcheck 1.0
** modified by James Murray <jsm@jsm-net.demon.co.uk> 23 Jan 1998

** Original headers follow:

** rblcheck 1.0 - Command-line interface to Paul Vixie's RBL filter.
** Copyright (C) 1997, Edward S. Marshall <emarshal@logic.net>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** 27-Nov-97 [emarshal@logic.net]: Created.
*/

#ifdef RBL_CHECK

#include "blackmail.h"

int rblcheck( char *rbl_addr )
{
	u_char answer[ RBL_BUF_SIZE ];
	int a, b, c, d, i;
	char domain[ RBL_DOMAIN_LENGTH ];

	/* Don't RBL local addresses */
	for(i = 0; i < num_localhosts; i++) {
            if (wildmat(rbl_addr, localhosts[i]))
		return 0;
	}

#ifdef DEBUG
		syslog(LOG_NOTICE, "RBL checking [%s]\n", rbl_addr );
#endif

	if( sscanf( rbl_addr, "%d.%d.%d.%d", &a, &b, &c, &d ) != 4 ||
	  a < 0 || a > 255 || b < 0 || b > 255 || c < 0 || c > 255 ||
	  d < 0 || d > 255 )
	{
		syslog(LOG_ALERT, "Internal error: invalid IP address [%s] supplied to rblcheck()\n", rbl_addr );
		printf("421 Internal Blackmail error - please try later.\n");
		fflush(stdout);
		
		exit(0);
	}

	/* Create a domain name, in reverse. */
	sprintf( domain, "%d.%d.%d.%d.%s", d, c, b, a, RBL_DNS_HOST );

	/* Here we go... */
	res_init();
	bzero( answer, RBL_BUF_SIZE );
	res_query( domain, C_IN, T_A, answer, RBL_BUF_SIZE );
	if( h_errno != 0 )
	{
#ifdef DEBUG
		syslog(LOG_NOTICE, "[%s] is not RBL filtered\n", rbl_addr );
#endif
		return 0;
	}
#ifdef DEBUG
		syslog(LOG_NOTICE, "[%s] is RBL filtered\n", rbl_addr );
#endif
	return 1;
}
#endif
