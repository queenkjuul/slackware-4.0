/*
** BlackMail
** Data handler
*/

#include "../blackmail.h"

int data_mode, gave_headers, header_mode;
char *lochost;
long smtp_timeout;

typedef struct {
	char *keyword;
	void (*routine)();
} FILTERS;

/*
** These are the filter rulesets.  If you want to add a new filter,
** add the first entry, being the line to check for in the headers,
** and the second entry is the routine that is called with the extra
** data as the parameters.
*/
static FILTERS filters[] = {
	{ "reply-to:",		filter_reply_to },
	{ "from:",		filter_from },
	{ "to:",		filter_to },
	{ "received:",		filter_received },
	{ "x-distribution:",	filter_distribution },
	{ "comments:",		filter_comments },
	{ "message-id:",	filter_message_id },
	{ "apparently-to:",	filter_apparently_to },
	{ NULL,		NULL }
};

static void stripnl(char *str)
{
    char *P;
    P = (char *)rindex((char *) str, '\r');
    if (P)
	*P = '\0';
}

static void sendXHeaders(void)
{
    char timestamp[BM_ADDR_BUF];
    time_t tim = time(NULL);

    bzero(timestamp, BM_ADDR_BUF);
    strftime(timestamp, BM_ADDR_BUF, "%H:%M:%S(%Z) on %B %d, %Y", localtime(&tim));

#ifdef	FULL_HEADERS
    if (*lochost != 0) {
	fprintf(mailer, "X-Comments: BlackMail headers - Mail to abuse@%s to report spam.\r\n", lochost);
    } else {
	char host[BM_HOST_BUF], domain[BM_HOST_BUF];

	bzero(host, BM_HOST_BUF);
	bzero(domain, BM_HOST_BUF);

	gethostname(host, BM_HOST_BUF);
	getdomainname(domain, BM_HOST_BUF);
	fprintf(mailer, "X-Comments: BlackMail headers - Mail to abuse@%s.%s to report spam.\r\n",
		host, domain);
    }

    fprintf(mailer, "X-Comments: See http://www.bitgate.com/spam/ for info on this software.\r\n");
    fprintf(mailer, "X-Comments: These headers are here for you to report spam!\r\n");
    fprintf(mailer, "X-Authenticated-Connect: %s\r\n", 
	(ident_user == NULL) ? "Run-from-command-line" : ident_user);
    fprintf(mailer, "X-Authenticated-Timestamp: %s\r\n", timestamp);
    fprintf(mailer, "X-HELO-From: %s\r\n", helo_from);
    fprintf(mailer, "X-Mail-From: %s\r\n", mail_from);
    fprintf(mailer, "X-Sender-IP-Address: %s\r\n", ip_address);
#else
    fprintf(mailer, "X-BlackMail: %s, %s, %s, %s\r\n",
	(ident_user == NULL) ? "Run-from-command-line" : ident_user,
	helo_from, mail_from, ip_address);
    fprintf(mailer, "X-Authenticated-Timestamp: %s\r\n", timestamp);
#endif

    fflush(mailer);

    gave_headers = 1;
/* once per message we need to reset tofromaddress */
    *tofromaddress = 0;
#if defined (DEBUG2) || defined (PASSIVE)
    debug_reject = 0;
#endif
}

static void process(char *data)
{
    char from_user[BM_LINE_BUF], recv_header[BM_LINE_BUF];
/* was from_user[BM_ADDR_BUF]  - changed 23 April 1998 - jsm*/
    int i;

    if (!header_mode)
	return;

    bzero(from_user, BM_ADDR_BUF);
    bzero(recv_header, BM_LINE_BUF);

    if ((data[0] == '\0') && (header_mode)) {
#if ( defined (DEBUG2) || defined (PASSIVE) ) && defined (DEBUG_HEADER)
                if (debug_reject > 0)
                        fprintf(mailer,
"X-Debug: Blackmail[%d] Would have rejected this mail for %d reasons.\r\n",
     (int)getpid(), debug_reject);
#endif

	header_mode = 0;
	return;
    }

    /* it is safe to lowercase  *data here without fear of corrupting the
     * original case because *dat is sent to the mailer
     */
    strtolower(data);

    for(i = 0; filters[i].keyword != NULL; i++)
	if (!strncasecmp(data, filters[i].keyword, strlen(filters[i].keyword))) {
	    sscanf(data, "%*[^:]: %[^\r\n]\r\n", from_user);
#ifdef DEBUG
		syslog(LOG_NOTICE, "Checking %s header, data is: %s\n",
		       filters[i].keyword, data);
#endif
	    filters[i].routine(from_user, data);
	    return;
	}
    /* no existing headers found, test it for naughty words */
    checkReceived( data);
}

void Data(char *dat)
{
    char *BolPtr = NULL, *EolPtr = NULL;
    char data[BM_LINE_BUF], next_line[BM_LINE_BUF];
    int done = 0;

    if ((!gave_mail) || (!gave_rcpt)) {
	printf("550 You must specify a MAIL FROM: and a RCPT TO: before using DATA\r\n");
	fflush(stdout);
	return;
    }

    fprintf(mailer, "DATA\r\n");
    sendXHeaders();
    header_mode = 1;
    fflush(mailer);
    fflush(stdout);

    data_mode = 1;
    next_line[0] = '\0';

    while(data_mode) {
	if (next_line[0] != '\0') {
	    strcpy(dat, next_line);
	} else {
	    if (fgets(dat, BM_LINE_BUF, stdin) == NULL )
		return;
	}
	next_line[0] = '\0';

	if ((dat[0] == '.') && ((dat[1] == '\r') || (dat[1] == '\n'))) {
	    data_mode = 0;
	    header_mode = 0;
	    gave_headers = 0;
	    gave_mail = 0;
	    gave_rcpt = 0;

#ifdef DEBUG
	    if (!outbound)
		syslog(LOG_NOTICE, "-end of message-");
#endif
#if ( defined (DEBUG2) || defined (PASSIVE) ) && defined (DEBUG_FOOTER)
	    if (debug_reject > 0)
		fprintf(mailer,
"---\r\n** (debug) Blackmail[%d] would have rejected this message for %d reasons. **\r\n"
    , (int)getpid(), debug_reject);
#endif
	    fprintf(mailer, ".\r\n");
	    fflush(mailer);
	    fflush(stdout);

	    return;
	}

	bzero(data, BM_LINE_BUF);
	strcpy(data, dat);
	done = !header_mode;
	while(!done) {
	    if (fgets(next_line, BM_LINE_BUF, stdin) == NULL ) {
		next_line[0] = '\0';
	    } else {
	        if((next_line[0] == ' ') || (next_line[0] == '\t')) {
		    /* wrapped line */
		    stripnl(data);
		    if((strlen(dat)+strlen(next_line)) < BM_LINE_BUF) {
		        strcpy(dat+strlen(dat), next_line);
			strcpy(data+strlen(data), next_line);
		    } else {
#if defined(DEBUG2) || defined(PASSIVE)
			printf(debugreplystrings[LINE_TOO_LONG]);
#else
		        printf(replystrings[LINE_TOO_LONG]);
#endif
		        fflush(stdout);
		        syslog(LOG_NOTICE, "Rejected potentially harmless mail from %s Line too long. Length %d > Limit = %d", mail_from, (strlen(dat)+strlen(next_line)), BM_LINE_BUF);
		        exit(0);
	/* MUST exit or the long line would cause a segfault
	 * This applies even if in DEBUG2 or PASSIVE mode.
	 */
		    }
	        } else
		    done = 1;
	    }
	}
	EolPtr = NULL;
	BolPtr = NULL;

	BolPtr = data;
	stripnl(data);

	done = 0;
	while(!done) {
	    EolPtr = (char *) index(BolPtr, (int) '\n');

	    if (EolPtr == NULL) {
		if (!outbound)
		    process(BolPtr);
		done = 1;
		break;
	    }

	    if (!done) {
		*EolPtr = '\0';
		if (!outbound)
		    process(BolPtr);
		EolPtr++;
		BolPtr = EolPtr;
	    }
	}
	
#ifdef BAN_HTML
        if (!outbound) {
	    if ( strstr(dat, "<HTML>") != NULL || strstr(dat, "<html>" ) != NULL) {
#if defined (DEBUG2) || defined (PASSIVE)
	        debug_reject++;
#ifndef PASSIVE
	        printf(debugreplystrings[NO_HTML_EMAIL]);
	        fflush(stdout);
#endif
	        syslog(LOG_NOTICE, "(debug)Rejected HTML email");
#else
	        printf(replystrings[NO_HTML_EMAIL]);
	        fflush(stdout);
	        syslog(LOG_NOTICE, "Rejected HTML email");
       
	        closelog();
	        exit(0);
#endif
	    }
        }
#endif /*BAN HTML */
        fprintf(mailer, "%s", dat);
        fflush(mailer);
        fflush(stdout);
        /* restart timeout alarm timer */
        alarm(smtp_timeout);
    }
}
