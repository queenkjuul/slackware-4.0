/*
** BlackMail Proxy
** X-Distribution filter rule
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>

#include "../blackmail.h"

void filter_distribution(char *data, char *orig_data)
{
    if ((!strncasecmp(data, "bulk", 4)) ||
	(!strncasecmp(data, "spam", 4)) ||
	(!strncasecmp(data, "mass", 4))) {
#if defined (DEBUG2) || defined (PASSIVE)
	debug_reject++;
#ifndef PASSIVE
	printf(debugreplystrings[NO_BULK_MAIL]);
	fflush(stdout);
#endif
	syslog(LOG_NOTICE, "(debug)Bulk Redistribution detected");
#else
	printf(replystrings[NO_BULK_MAIL]);
	fflush(stdout);

	syslog(LOG_NOTICE, "Bulk Redistribution detected");
	exit(0);
#endif
    }
}
