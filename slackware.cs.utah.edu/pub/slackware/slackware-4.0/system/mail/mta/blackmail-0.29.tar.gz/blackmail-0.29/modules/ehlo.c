/*
** BlackMail
** HELO handler
*/

#include "../blackmail.h"

void Ehlo(char *data)
{
    char *tmp;
    bzero(helo_from, BM_ADDR_BUF);
    strcpy(data, data + 1);

    sscanf(data, "%[^\r\n]\r\n", helo_from);

    if (!outbound) {
	tmp = (char *)malloc(BM_ADDR_BUF);
	strncpy(tmp, helo_from, BM_ADDR_BUF);
	strtolower(tmp);
	checkAddressRejected(tmp);
	free(tmp);
    }

    fprintf(mailer, "EHLO %s\r\n", helo_from);
    fflush(mailer);
    fflush(stdout);
}
