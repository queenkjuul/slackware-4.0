/*
** BlackMail
** HELO handler
*/

#include "../blackmail.h"

void Helo(char *data)
{
    char *tmp;
    bzero(helo_from, BM_ADDR_BUF);
    strcpy(data, data + 1);

    sscanf(data, "%[^\r\n]\r\n", helo_from);

    if (!outbound) {
	tmp = (char *)malloc(BM_ADDR_BUF);
	strncpy(tmp, helo_from, BM_ADDR_BUF);
	strtolower(tmp);
	checkAddressRejected(tmp);

#ifdef DNS_CHECK
	if (!dnslookup(helo_from)) {
#if defined (DEBUG2) || defined (PASSIVE)
	    debug_reject++;
#ifndef PASSIVE
	    printf(debugreplystrings[INVALID_DOMAIN], helo_from, "HELO");
	    fflush(stdout);
#endif
	    syslog(LOG_NOTICE, "(debug)Rejected invalid domain \"%s\" from %s", helo_from, ip_address);
#else
	    printf(replystrings[INVALID_DOMAIN], helo_from, "HELO");
	    fflush(stdout);

	    syslog(LOG_NOTICE, "Rejected invalid domain \"%s\" from %s", helo_from, ip_address);
	    exit(0);
#endif
	}
#endif /* DNS_CHECK */
	free(tmp);
    }

    fprintf(mailer, "HELO %s\r\n", helo_from);
    fflush(mailer);
    fflush(stdout);
}
