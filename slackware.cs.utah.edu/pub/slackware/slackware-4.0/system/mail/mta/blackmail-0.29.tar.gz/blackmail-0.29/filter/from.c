/*
** BlackMail Proxy
** From filter rule
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>

#include "../blackmail.h"

void filter_from(char *data, char *orig_data)
{
#ifdef TO_FROM
    int i, is_local=0;
    char *tmp;
    tmp = (char *)malloc(BM_ADDR_BUF);

    headers_from++;
    checkAddressRejected(orig_data);
    checkAddress(data, "From", orig_data, tmp);

    /* use previously extracted address in tmp */

    for(i = 0; i < num_allowedmail; i++) {
	if (wildmat(tmp, allowedmail[i])) {
	    is_local = 1;
#ifdef DEBUG
	    syslog(LOG_NOTICE, "Mail is From: this site, ignoring tofromaddress\n");
#endif
	    }
	}

    if (!is_local) {
	if ( *tofromaddress == 0 ) {
	    strcpy(tofromaddress, tmp);
#ifdef DEBUG
	    syslog(LOG_NOTICE, "Set tofromaddress to %s\n", tofromaddress );
#endif
	} else {
	    if ( strcmp( tofromaddress, tmp ) == 0 ) {
#if defined (DEBUG2) || defined (PASSIVE)
		debug_reject++;
#ifndef PASSIVE
		printf(debugreplystrings[REDUNDANT_MAIL], tofromaddress);
		fflush(stdout);
#endif
		syslog(LOG_NOTICE, "(debug)Rejected Spam. (To: = From:) %s from %s.", tofromaddress, ident_user);
#else
		printf(replystrings[REDUNDANT_MAIL], tofromaddress);
		fflush(stdout);

		syslog(LOG_NOTICE, "Rejected Spam. (To: = From:) %s from %s.", tofromaddress, ident_user);
		exit(0);
#endif
	    }
	}
    }
    free(tmp);
#else /* not using TO_FROM */
    headers_from++;
    checkAddressRejected(orig_data);
    checkAddress(data, "From", orig_data, NULL);
#endif
}
