/*
** BlackMail Proxy
** Apparently-To filter rule
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>

#include "../blackmail.h"

void filter_apparently_to(char *data, char *orig_data)
{
    checkAddressRejected(orig_data);
    checkAddress(data, "Apparently-To", orig_data, NULL);
}
