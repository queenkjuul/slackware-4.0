/*
** BlackMail
** Recipient Handler
*/

#include "../blackmail.h"

void Rcpt(char *data)
{
    int i;
    char rcpt_to[BM_ADDR_BUF], rcpt_old[BM_ADDR_BUF], rcpt_new[BM_ADDR_BUF],
	user[BM_ADDR_BUF], host[BM_ADDR_BUF];
    char *tmp, *tmp2;

    bzero(rcpt_to, BM_ADDR_BUF);
    bzero(rcpt_old, BM_ADDR_BUF);
    bzero(rcpt_new, BM_ADDR_BUF);
    bzero(user, BM_ADDR_BUF);
    bzero(host, BM_ADDR_BUF);

    tmp = (char *)malloc(BM_ADDR_BUF);
    tmp2 = (char *)malloc(BM_ADDR_BUF);
    strncpy(rcpt_to, data, BM_ADDR_BUF);

    if (!strncasecmp(rcpt_to, " to", 3))
	strcpy(rcpt_old, rcpt_to + 3);

    sscanf(rcpt_old, ":%[^\r\n]\r\n", rcpt_new);

    if (!outbound) {

	strncpy(tmp, rcpt_new, BM_ADDR_BUF);
	strtolower(tmp);
	checkAddress(tmp, "RCPT to:", data, tmp2);
	/* tmp2 now contains the extracted email address */

	if (has(rcpt_new, '@')) {
	    int found = 0;

	    sscanf(tmp2, "%[^@]@%[^\r\n]\r\n", user, host);

	    if ((host[0] == '[') && (host[strlen(host) - 1] == ']')) {
	        strcpy(host, host + 1);
	        host[strlen(host) - 1] = '\0';
	    }

	    for(i = 0; i < num_localhosts; i++) {
	        if ((wildmat(ip_address, localhosts[i])) ||
		    (wildmat(host, localhosts[i]))) {
		    found = 1;
		    break;
		}
	    }

	    if (!found)
	        for(i = 0; i < num_allowedmail; i++) {
		    if (wildmat(host, allowedmail[i])) {
		        found = 1;
		        break;
		    }
	        }

	    if (!found) {
#if defined (DEBUG2) || defined (PASSIVE) || defined(PASSIVE_RELAY)
	        debug_reject++;
	        syslog(LOG_NOTICE, "(debug)Rejected relay attempt from %s to %s",
		    ip_address, rcpt_new);
#ifndef PASSIVE_RELAY
	        printf(debugreplystrings[NO_EMAIL_RELAY]);
	        fflush(stdout);

		closelog();
		exit(0);
#endif
#else
	        printf(replystrings[NO_EMAIL_RELAY]);
	        fflush(stdout);
	        syslog(LOG_NOTICE, "Rejected relay attempt from %s to %s",
		    ip_address, rcpt_new);

	        closelog();
	        exit(0);
#endif
	    }
	}
    }

    /* if we didn't exit, it must be ok */
    fprintf(mailer, "RCPT to:%s\r\n", rcpt_new);
    fflush(mailer);
    fflush(stdout);

    gave_rcpt = 1;

    free(tmp);
}
