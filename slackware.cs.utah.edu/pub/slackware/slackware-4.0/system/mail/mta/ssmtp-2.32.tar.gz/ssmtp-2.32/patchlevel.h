#define VERSION "2.32, 11 March 1999"
