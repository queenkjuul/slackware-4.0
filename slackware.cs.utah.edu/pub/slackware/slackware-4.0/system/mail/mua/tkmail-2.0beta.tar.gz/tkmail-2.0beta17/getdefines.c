#include <stdio.h>
#include <sys/wait.h>
#include <sys/file.h>
#include <sys/errno.h>
#include <sys/socket.h>

main(int argc, char **argv)
{
#ifdef LOCK_SH
  printf("LOCK_SH = %d\nLOCK_EX = %d\n", LOCK_SH, LOCK_EX );
  printf("LOCK_NB = %d\nLOCK_UN = %d\n", LOCK_NB, LOCK_UN );
  printf("EWOULDBLOCK = %d\n", EWOULDBLOCK );
#else
  printf("It appears your system can't use flock()\n");
#endif
  printf("SOCK_STREAM = %d\nAF_UNIX = %d\n", SOCK_STREAM, AF_UNIX );
  printf("WNOHANG = %d\n", WNOHANG );
  exit(0);
}
