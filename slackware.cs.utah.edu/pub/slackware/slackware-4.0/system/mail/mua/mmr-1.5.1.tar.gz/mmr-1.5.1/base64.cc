
/* Convert to Base64 encoding */
static char to_base64[64] = {
	'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 
	'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 
	'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 
	'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 
	'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' 
	};
#define PAD	'='		/* Trailing pad character */


void base64_encode(char **dstptr, char *from, int fromlen)
{
	char *to = *dstptr = new char[(fromlen*4)/3+5];
	unsigned char sextet[4];
	unsigned int i, index=0, o=0;

#ifdef PRINT_CHECKSUM
error("Encoding %d chars...", fromlen);
#endif
	for ( i=0; i<fromlen; ++i ) {
		switch (index++) {
			case 0: sextet[0]  = ((from[i]&0xfc)>>2);
					sextet[1]  = ((from[i]&0x03)<<4);
					break;
			case 1: sextet[1] |= ((from[i]&0xf0)>>4);
					sextet[2]  = ((from[i]&0x0f)<<2);
					break;
			case 2: sextet[2] |= ((from[i]&0xc0)>>6);
					sextet[3]  = (from[i]&0x3f);
					/* Now output the encoded data */
					for ( index=0; index<4; ++index )
						to[o++] = to_base64[sextet[index]];
					index=0;
					break;
			default:  /* Never reached */ ;
		}
	}
	if ( index ) { /* We must flush the output */
		for ( i=0; i<=index; ++i )
			to[o++] = to_base64[sextet[i]];
		for ( ; index<3; ++index )
			to[o++] = PAD;
	}
	to[o] = 0;
#ifdef PRINT_CHECKSUM
error("into %d chars. (allocated %d chars)\n", o+1, (fromlen*4)/3+5);
#endif
	return;
}

int base64_decode(char **dstptr, int *olen, char *from)
{
	char *to;
	char sextet[4], obyte;
	int i, fromlen, index=0;
	unsigned int o=0;

	/* No blank lines, please */
	if ( (*from == '\0') || (*from == '\n') )
		return(0);

	/* Allocate space */
	fromlen=strlen(from);
	to = *dstptr = new char[(fromlen*3)/4+1];

	/* Now loop, decoding. */
/*
fprintf(stderr, "Decoding %d chars...", fromlen);
*/
	for ( i=0; i<fromlen; ++i ) {
		if ( from[i] >= 'A' && from[i] <= 'Z' )
			sextet[index++]=(from[i]-'A');
		else if ( from[i] >= 'a' && from[i] <= 'z' )
			sextet[index++]=(from[i]-'a'+26);
		else if ( from[i] >= '0' && from[i] <= '9' )
			sextet[index++]=(from[i]-'0'+52);
		else {
			switch (from[i]) {
				case '+': sextet[index++]=62;
					  	  break;
				case '/': sextet[index++]=63;
					  	  break;
				case '-':
				case PAD: /* End of input.  Flush any remaining data. */
						  switch(index) {
							case 0: break;
							case 1: /* Should never happen */
									break;
							case 2: obyte=(sextet[0]&0x3f);
									obyte <<= 2;
									obyte |= ((sextet[1]&0x30)>>4);
									to[o++] = obyte;
									break;
							case 3: obyte=(sextet[0]&0x3f);
									obyte <<= 2;
									obyte |= ((sextet[1]&0x30)>>4);
									to[o++] = obyte;
									obyte=(sextet[1]&0x0f);
									obyte <<= 4;
									obyte |= ((sextet[2]&0x3c)>>2);
									to[o++] = obyte;
									break;
			  			   }
						   *olen = o;
/*
fprintf(stderr, "into %d chars\n", *olen);
*/
			  			   return(0);
				/* RFC 1521 says ignore junk */
				default:  break;
			}
		}
		if ( index == 4 ) {	/* Output the decoded data */
			obyte=(sextet[0]&0x3f);
			obyte <<= 2;
			obyte |= ((sextet[1]&0x30)>>4);
			to[o++] = obyte;
			obyte=(sextet[1]&0x0f);
			obyte <<= 4;
			obyte |= ((sextet[2]&0x3c)>>2);
			to[o++] = obyte;
			obyte=(sextet[2]&0x03);
			obyte <<= 6;
			obyte |= (sextet[3]&0x3f);
			to[o++] = obyte;
			index=0;
		}
	}
	*olen = o;
/*
fprintf(stderr, "into %d chars\n", *olen);
*/
	return(1);
}

