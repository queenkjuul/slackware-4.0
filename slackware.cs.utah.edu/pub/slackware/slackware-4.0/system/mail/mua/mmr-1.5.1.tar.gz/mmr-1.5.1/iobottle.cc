
extern "C" {
#include <stdlib.h>
#include <stdarg.h>
};
#include "iobottle.h"

/* This class implements an IO object on an existing file that supports
   accessing the filename, file descriptor, allows file locking, reads
   and writes both binary data and text lines, and has separate read 
   and write stream offsets.

   It's based on stdio, and doesn't support iostream's fancy operators. :-)
   Since it is built for special purposes, it doesn't support many of
   the numerous options to open(), it just opens a read/write stream on
   an existing file.
*/
IObottle:: IObottle(char *FilePath) {
	do_unlink = 0;
	Init(FilePath);
}
IObottle:: IObottle(char *Lines[]) {
	/* Generate a file from a series of blocks of memory */
	char *temp_name;
	FILE *output;
	if ( (temp_name=tmpnam(NULL)) && (output=fopen(temp_name, "w")) ) {
		for ( int i=0; Lines[i]; ++i )
			fputs(Lines[i], output);
		fclose(output);
		do_unlink = 1;
	}
	Init(temp_name);
}
void
IObottle:: Init(char *FilePath) {
	/* Save the filename, doing tilde expansion */
	char *home;
	if ( (*FilePath == '~') && (*(FilePath+1) == '/') &&
						(home=getenv("HOME")) ) {
		filepath = new char[strlen(home)+strlen(FilePath)];
		sprintf(filepath, "%s/%s", home, FilePath+2);
	} else {
		filepath = new char[strlen(FilePath)+1];
		strcpy(filepath, FilePath);
	}

	/* Open the file */
	waserr = 0;
	rfp = wfp = NULL;
	rfd = wfd = -1;
	if ( ((rfd=open(filepath, O_RDONLY)) < 0) ||
				((rfp=fdopen(rfd, "r")) == NULL) ) {
		waserr = 1;
		close(rfd); rfd = -1;
		return;
	}
	if ( ((wfd=open(filepath, O_WRONLY)) < 0) ||
				((wfp=fdopen(wfd, "w")) == NULL) ) {
		waserr = 1;
		fclose(rfp); rfp = NULL;
		close(rfd); rfd = -1;
		close(wfd); wfd = -1;
		return;
	}

	/* Trigger EOF */
	fgetc(rfp);
	fseek(rfp, 0, SEEK_SET);
}

IObottle:: ~IObottle() {
	/* Clean everything up */
	if ( rfp != NULL )
		(void) fclose(rfp);
	if ( rfd >= 0 )
		(void) close(rfd);
	if ( wfp != NULL )
		(void) fclose(wfp);
	if ( wfd >= 0 )
		(void) close(wfd);
	if ( do_unlink )
		(void) unlink(filepath);
	delete[] filepath;
}

/* If buf[lenread-1] is a null, then a newline was stripped */
size_t
IObottle:: readline(char *buf, size_t len) {
	int lenread;
	*buf = '\0';
	if ( fgets(buf, len-1, rfp) == NULL )
		return(0);
	lenread = strlen(buf);
	if ( buf[lenread-1] == '\n' )
		buf[lenread-1] = '\0';
	return(lenread);
}
/* If buf[len-1] is a null, then a newline should be written */
size_t
IObottle:: writeline(char *buf, size_t len = 0) {
	int lenwritten = 0;

	if ( fputs(buf, wfp) >= 0 )
		lenwritten = strlen(buf);
	if ( len && (buf[len-1] == '\0') ) {
		if ( fputc('\n', wfp) != EOF )
			++lenwritten;
	}
	return(lenwritten);
}
void
IObottle:: printf(char *fmt, ...)
{
	char string[BUFSIZ];
	va_list ap;

	va_start(ap, fmt);
	vsprintf(string, fmt, ap);
	fputs(string, wfp);
}

/* File mode/time functions */
int
IObottle:: get_time(time_t *actime, time_t *modtime) {
	struct stat    sb;

	/* Find out existing time-stamp */
	if ( stat(filepath, &sb) < 0 )
		return(-1);
	if ( actime )
		*actime = sb.st_atime;
	if ( modtime )
		*modtime = sb.st_mtime;
	return(0);
}
int
IObottle:: set_time(time_t actime, time_t modtime = 0) {
	struct stat    sb;
	struct utimbuf ub;

	/* Find out existing time-stamp */
	if ( stat(filepath, &sb) < 0 )
		return(-1);

	/* Set new timestamp */
	if ( actime )
		ub.actime = actime;
	else
		ub.actime = sb.st_atime;
	if ( modtime )
		ub.modtime = modtime;
	else
		ub.modtime = sb.st_mtime;
	return(utime(filepath, &ub));
}
off_t
IObottle:: Size(off_t *sizeptr) {
	struct stat    sb;

	/* Find out existing time-stamp */
	if ( stat(filepath, &sb) < 0 )
		return(-1);

	if ( sizeptr )
		*sizeptr = sb.st_size;
	return(sb.st_size);
}
