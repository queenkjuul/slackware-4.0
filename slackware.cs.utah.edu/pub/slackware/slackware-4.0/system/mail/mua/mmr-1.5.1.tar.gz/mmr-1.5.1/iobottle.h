
#ifndef _iobottle_h
#define _iobottle_h

/* Appropriate system headers */
extern "C" {
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <stdio.h>
#include <unistd.h>
#include <utime.h>
#include <fcntl.h>

#ifdef sparc		/* Solaris needs these, since flock() is deprecated */
#ifndef LOCK_EX
#define LOCK_EX	2
#define LOCK_UN	8
#endif
extern int flock(int fd, int operation);
#endif /* sparc */
};

/* This class implements an IO object on an existing file that supports
   accessing the filename, file descriptor, allows file locking, reads
   and writes both binary data and text lines, and has separate read 
   and write stream offsets.

   It's based on stdio, and doesn't support iostream's fancy operators. :-)
   Since it is built for special purposes, it doesn't support many of
   the numerous options to open(), it just opens a read/write stream on
   an existing file.
*/
class IObottle {

public:
	IObottle(char *FilePath);
	IObottle(char *Lines[]);
	void Init(char *FilePath);
	~IObottle();

	/* What file are we opened on? */
	const char *Path() {
		return(filepath);
	}

	/* Binary data handling */
	size_t read(void *buf, size_t len) {
		return(fread(buf, 1, len, rfp));
	}
	size_t write(void *buf, size_t len) {
		return(fwrite(buf, 1, len, wfp));
	}
	/* Text data handling */
	/* If buf[lenread-1] is a null, then a newline was stripped */
	size_t readline(char *buf, size_t len);
	/* If buf[len-1] is a null, then a newline should be written */
	size_t writeline(char *buf, size_t len = 0);
	/* The printf of the IObottle class. :) */
	void printf(char *fmt, ...);

	/* Seeking functions */
	int seekg(long offset, int whence = SEEK_SET) {
		return(fseek(rfp, offset, whence));
	}
	int seekp(long offset, int whence = SEEK_SET) {
		return(fseek(wfp, offset, whence));
	}
	long tellg(void) {
		return(ftell(rfp));
	}
	long tellp(void) {
		return(ftell(wfp));
	}
	int truncate(size_t length) {
		this->flush();
		return(ftruncate(wfd, length));
	}

	/* File mode/time functions */
	int get_time(time_t *actime, time_t *modtime);
	int set_time(time_t actime, time_t modtime = 0);
	off_t Size(off_t *sizeptr);

	/* Locking functions */
	int lock(void) {
		return(flock(wfd, LOCK_EX));
	}
	int unlock(void) {
		fflush(wfp);
		return(flock(wfd, LOCK_UN));
	}

	/* Error flags */
	int eof(void) {
		return(feof(rfp));
	}
	int fail(void) {
		return(waserr || ferror(rfp) || ferror(wfp));
	}
	void clrerr(void) {
		clearerr(rfp); clearerr(wfp);
	}

	/* Flush output */
	void flush(void) {
		fflush(rfp); fflush(wfp);
	}

	/* Set temporary flag -- if temporary, unlink on close */
	void temp(int setit) {
		do_unlink = setit;
	}

private:
	int   do_unlink;
	int   waserr;
	int   rfd, wfd;
	char *filepath;
	FILE *rfp, *wfp;
};

#endif /* _iobottle_h */
