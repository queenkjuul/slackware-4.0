
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <Regex.h>			/* g++ regular expression class */

char *match(char *string, char *pattern, int *matchlen)
{
	int start;

	/* No string, no pattern, no service. :) */
	if ( ! string || ! pattern ) {
		return((char *)0);
	}

	/* Create the regular expression object */
	Regex regpat(pattern);

	/* Check for a match */
	if ( (start=regpat.search(string, strlen(string), *matchlen)) < 0 ) {
		return((char *)0);
	}
	return(string+start);
}

/* Perform case-insensitive string matching */
char *match_nocase(char *string, char *pattern, int *matchlen)
{
	char *newpattern;
	int   inswitch, j;
	char *matched;

	/* As a special case, if '[Xx' exists in the pattern, assume it 
	   already handles any desired case sensitivity, so return match().
	*/
	if ( (matched=strchr(pattern, '[')) != NULL ) {
		++matched;
		if ( toupper(*matched) == toupper(*(matched+1)) )
			return(match(string, pattern, matchlen));
	}

	/* Perform preprocessing on the pattern */
	newpattern = new char[4*strlen(pattern)+1];
	for (inswitch = 0, j = 0; *pattern; ++pattern){
		if ( *pattern == '[' )
			inswitch = 1;
		if ( *pattern == ']' )
			inswitch = 0;
		if ( ! inswitch && isalpha(*pattern) ) {
			newpattern[j++] = '[';
			newpattern[j++] = toupper(*pattern);
			newpattern[j++] = tolower(*pattern);
			newpattern[j++] = ']';
		} else
			newpattern[j++] = *pattern;
	}
	newpattern[j] = '\0';

	matched = match(string, newpattern, matchlen);
	delete[] newpattern;
	return(matched);
}

