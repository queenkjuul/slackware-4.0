
// C++ class to manage a mail message

#ifndef _mailmsg_h 
#define _mailmsg_h

extern "C" {
#include <sys/types.h>
};

#include "my_regex.h"
#include "fifo.tmpl"
#include "iobottle.h"
#include "mime.h"

/* A buffer structure used in a buffer ring */
typedef struct {
	char *data;
	int   len;
} buflen;

/* Notes on the thread structure:

	All messages have next and previous pointers that point to the
	indexed messages before and after them.  They also have thread
	next and previous pointers that point to the logical messages
	before and after them, following threads.  Messages within a
	thread have "threaded" and "thread_next" set.  Messages heading
	a thread have "thread_next" set, but "threaded" is not set.
*/
#define NO_THREADS	0
#define HIDE_THREADS	1
#define SHOW_THREADS	2

class mailmsg {

/* Forward declaration mailbox data */
struct mbox_data {
	IObottle *MailFile;
	int nmessages;
	int showthreads;
	int aborted;
	int saveall;
	void (*onsave)(mailmsg *ptr);	/* Deletion callback */
};

public:
	mailmsg(IObottle *mailfile, void (*oncreate)(mailmsg *ptr) = NULL);
	mailmsg(struct mbox_data *MBox, mailmsg *prevmesg, int seqnum,
						void (*oncreate)(mailmsg *ptr));
	void Init(struct mbox_data *MBox, mailmsg *prevmesg,
				int seqnum, void (*oncreate)(mailmsg *ptr));
	void Abort() { mbox->aborted = 1; }
	void SetSave(int doit) { mbox->saveall = doit; }
	~mailmsg();

	/* Mailbox stuff */
	void ShowThreads(int showthem) {
		mbox->showthreads = showthem;
	}
	int ShowThreads(void) {
		return(mbox->showthreads);
	}
	int NumMessages(void) {
		return(mbox->nmessages);
	}
	/* Thread navigation stuff */
	mailmsg *ByIndex(int the_index);
	mailmsg *ByStatus(char *the_status);
	mailmsg *ByBody(MIME_body *the_body);
	int ThreadSize(void);
	int ThreadIndex(void);
	mailmsg *ThreadNext(void) {
		return(thread_next);
	}
	mailmsg *Next(void);
	mailmsg *Next(int howmany);
	mailmsg *Prev(void);
	mailmsg *Prev(int howmany);
	mailmsg *Last(void) {
		mailmsg *the_last, *ptr;
		for ( the_last=this; (ptr=the_last->Next()); the_last=ptr );
		return(the_last);
	}
	void SetNext(mailmsg *newnext) {
		next = newnext;
	}
	void SetPrev(mailmsg *newprev) {
		prev = newprev;
	}
	void ReOrder(void) {
		next = privnext;
		prev = privprev;
	}

	/* Header fields */
	char *GetHeader(char **keyholder);
	const char *GetField(char *str);
	const char *From(void) {
		const char *from = GetField("From");
		return(from ? from : "Unknown");
	}
	/* Extract a human name from an email address, if possible */
	char *FromName(char *namebuf, int namelen);
	/* Return the message's subject */
	const char *Subject(void) {
		const char *subject = GetField("Subject");
		return(subject ? subject : "<no subject>");
	}
	const char *Subject_Key(void) {
		return(subject_key ? subject_key : "");
	}
	/* Return the message's date in MM/DD/YY format */
	char *MMDDYY(void);
	char *MonthDay(void);

	int Index(void) {
		return(index);
	}

	/* See/Set the status of the message */
	const char *Status(int in_listing = 0);
	const char *DiskStatus(void);
	void Status(char *newstatus);
	int Changed(void) {
		return(changed);
	}
	void NoChange(void) {
		changed = 0;
	}
	mailmsg *SkipDeleted(int *nrows);
	
	/* Get the body of the message */
	MIME_body *Body(void) {
		return(body);
	}
	/* Make sure the body hasn't changed */
	int Verify(void);
	/* Append new messages to the end of the list */
	int NewMail(void);
	/* Save the message to a file */
	int Save(char *filename);

	/* Calls to lock and unlock the mailbox */
	int Lock(void);
	void UnLock(int locked);
		
	/* Callback for saving */
	void OnSave(void (*callback)(mailmsg *ptr)) {
		mbox->onsave = callback;
	}

	/* Two mail messages are equivalent iff they have the same MIME
	   bodies, the same "Subject" lines, and the same "From" lines.
	 */
	int operator == (mailmsg &other) {
		return(
			(*body == *(other.body)) &&
			(strcmp(From(), other.From()) == 0) &&
			(strcmp(Subject(), other.Subject()) == 0)
		);
	}
	int operator != (mailmsg &other) {
		return(
			(*body != *(other.body)) ||
			(strcmp(From(), other.From()) != 0) ||
			(strcmp(Subject(), other.Subject()) != 0)
		);
	}

private:
	static char *boundary[];		/* The message separator */

	/* Real variables. :-) */
	int index;
	IObottle *MailFile;
	struct mbox_data *mbox;
	char             *status;
	long              mstart;		/* Offset of mail message */
	int               mlength;		/* Length of message */
	MIME_body       *body;
	int              changed;

	/* String of messages stuff */
	mailmsg *privnext, *privprev;
	mailmsg *next, *prev;
	mailmsg *thread_next, *thread_prev;
	char *subject_key;
	int   subject_hash;
	int   threaded;
	int   thread_size;
	char *NormalizeSubject(const char *subject);
	int   HashString(char *str);

	/* Return a translation of the given status string */
	char *TranslateStatus(char *str) {
		if ( ! str )
			str = "N";
		else if ( *str == 'R' )
			str = " ";
		return(str);
	}
	int ThreadMe(mailmsg *me, int hash, char *subject);
	void NewField(char *name, char *value);
	void QueueRing(Fifo<buflen> *ringbuf, char *data, int len);
	int FlushRing(Fifo<buflen> *ringbuf, int gap);
	int SaveToDisk(Fifo<buflen> *ringbuf, int gap);
};

#endif /* _mailmsg_h */
