
/* The outbound mail functions */

#include <stdio.h>
#include "terminal.h"

int NewMail(char *To[], char *Subject);
int NewMail(char *To, char *Cc, char *Subject, int do_edit, FILE *incfile,
								Terminal *tty);
