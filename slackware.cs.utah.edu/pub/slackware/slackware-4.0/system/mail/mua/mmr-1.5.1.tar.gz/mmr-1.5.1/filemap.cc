
/* These functions allow you to memory map files -- very useful. :-) */

extern "C" {
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
}

#include "filemap.h"

/* The lines constructed with this function should fit comfortably within
   a screen display of width 'linewidth'
*/
filemap *MapFile(const char *filename, int flags, filemap *themap,
							int linewidth)
{
	struct stat sb;
	int    oflags;
	int    i, j, n;
	char  *lptr, *fptr;
		
	/* Make sure we have a file to map */
	if ( filename == NULL )
		return(NULL);

	/* What are we doing? */
	switch (flags) {
		case PROT_READ:
			oflags = O_RDONLY;
			break;
		case PROT_WRITE:
			oflags = O_RDWR;
			break;
		default:
			/* Unsupported */
			return(NULL);
	}

	/* Find out how far to map the file */
	themap->lines = NULL;
	if ( stat(filename, &sb) < 0 )
		return(NULL);
	themap->size = sb.st_size;

	/* Open it.. */
	if ( (themap->fd=open(filename, oflags)) < 0 )
		return(NULL);

	/* And memory map it */
	if ( (themap->rawfile=(char *)mmap(NULL, themap->size, PROT_READ,
				MAP_SHARED, themap->fd, 0)) == (char *)-1 ) {
		close(themap->fd);
		return(NULL);
	}

	/* Map the file into a set of lines of width linewidth-1 */
	--linewidth;
	themap->lines = NULL;
	themap->nlines = 0;
	if ( linewidth <= 0 )
		return(themap);

	/* Pass 1: Figure out how many lines are in the file */
	fptr=themap->rawfile;
	for ( i=0, n=1; i<sb.st_size; ++i, ++fptr ) {
		if ( *fptr == '\t' ) {  /* Assume 8 char tabstops */
			n += 8;
		} else {
			n += 1;
		}
		if ( (n >= linewidth) || (*fptr == '\n') ) {
			++themap->nlines;
			n = 0;
			if ( *fptr != '\n' ) {
				--fptr;
				--i;
			}
		}
	}

	/* Pass 2: Fill in the line pointers */
	themap->lines = new char *[themap->nlines+1];
	themap->linelens = new int[themap->nlines];
	lptr=fptr=themap->rawfile;
	for ( i=0, j=0, n=0; i<sb.st_size; ++i, ++fptr ) {
		if ( *fptr == '\t' ) {  /* Assume 8 char tabstops */
			n += 8;
		} else {
			n += 1;
		}
		if ( (n >= linewidth) || (*fptr == '\n') ) {
			/* Set the line */
			themap->lines[j] = lptr;
			themap->linelens[j] = (fptr-lptr);
			++j;

			/* Reset the counters */
			n = 0;
			if ( *fptr == '\n' )
				lptr = fptr+1;
			else {
				lptr = fptr;
				--fptr;
				--i;
			}
		}
	}
	if ( j < themap->nlines ) {
		themap->lines[j] = lptr;
		themap->linelens[j] = (fptr-lptr);
		++j;
	}
	themap->lines[j] = NULL;

	/* That's it! :) */
	return(themap);
}

void UnMapFile(filemap *themap)
{
	munmap(themap->rawfile, themap->size);
	close(themap->fd);
	if ( themap->lines ) {
		delete[] themap->lines;
		delete[] themap->linelens;
	}
}

