
#include "terminal.h"
#include "mailmsg.h"
#include "filemap.h"
#include "iobottle.h"

/* Message sorting constants */
#define SORTBY_NOTHING	0
#define SORTBY_AUTHOR	1
#define SORTBY_SUBJECT	2
#define NUMSORTS	3

/* Listing states */
#define LIST_STATE	0x01
#define VIEW_STATE	0x02
#define HELP_STATE	0x80

/* If this is defined, the message date will show up in the listing */
#define SHOW_INDEX_DATE

class Msg_Listing {

public:
	Msg_Listing(IObottle *MailFile, mailmsg *Current);
	~Msg_Listing();

	/* This function handles the main command loop */
	void RunMain(mailmsg *(*checkmail)(mailmsg *, Terminal *, int *));
	void ReSize(int modified = 1);

	/* The various modes */
	void Show(void);
	void Info(mailmsg *which);
	mailmsg *View(mailmsg *which, MIME_body *body = NULL);
	void Help(Terminal *tty);

	/* Jump to the next "N" or "O" message */
	mailmsg *TabJump(mailmsg *which);

	/* Set the message ordering */
	void OrderBy(mailmsg *which, int sortorder);

	/* Set the thread indenting */
	void IndentThread(int flag) {
		if ( flag )
			thread_str = "  ";
		else
			thread_str = "|";
	}

private:
	Terminal *listpane, *infopane, *viewpane, *helppane;
	mailmsg  *current, *lastshown;
	IObottle *mailfile;
	mailmsg *(*CheckMail)(mailmsg *, Terminal *, int *);

	/* Listing variables and functions */
	char hdr_string[1024], fmt_string[1024];
	char *thread_str;
	static char *separator;
	int offset;
	int currow;
	int width, height;
	int subject_len;
	static char *last_pattern;	/* Last search pattern */
	static int   last_sdirect;	/* Last list search direction */
	static int   last_vdirect;	/* Last view search direction */
	int main_done;			/* Main loop control variable */

	/* Listing helper functions */
	char *ThreadSpecial(mailmsg *mesgptr) {
		char *tstatus;

		if ( mesgptr->ThreadSize() > 0 ) {
			if ( mesgptr->ThreadIndex() == 0 ) {
				if ( mesgptr->ShowThreads() == HIDE_THREADS )
					tstatus = "*";
				else
					tstatus = ">";
			} else
				tstatus = thread_str;
		} else {
			tstatus = " ";
		}
		return(tstatus);
	}
	void ShowLine(mailmsg *mesgptr) {
		char namebuf[1024];
		/* Show the line */
		listpane->printf(fmt_string, ThreadSpecial(mesgptr),
				*(mesgptr->Status(1)),
#ifdef SHOW_INDEX_DATE
				mesgptr->MonthDay(), mesgptr->Index(),
#else
				mesgptr->Index(),
#endif /* SHOW_INDEX_DATE */
				mesgptr->FromName(namebuf, 1024),
						mesgptr->Subject());
	}
	void ListStatus(void);
	int  ListChanged(int);
	mailmsg *Goto_Msg(int key, mailmsg *which);
	void     SavePattern(char *pattern);
	mailmsg *SearchList(int direction, mailmsg *which, MIME_body **bodyptr,
								char *pattern);
	int      SearchView(int direction, filemap *fmap, int offset,
								char *pattern);
	int      matchline(filemap *fmap, int offset, char *pattern);

	/* List sorting data */
	static int (*orderers[NUMSORTS])(const void *A, const void *B);

	/* Some viewing functions and state data */
	int  list_state;
	int  changed;
	void ViewHeader(mailmsg *which);
	int  ViewPage(filemap *fmap, int offset, int distance, int clearit = 0);
	MIME_body *ViewBody(mailmsg **whichptr, MIME_body *body);
};
