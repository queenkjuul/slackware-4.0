
/* Code to handle the init startup file -- MIME format */

/* Startup database */
extern MIME_body *startup;

/* Easy access to the startup variables */
extern char *GetStartVar(char *varname);
