
/* Code to handle the init startup file -- MIME format */

extern "C" {
#include <stdlib.h>
};
#include "iobottle.h"
#include "mime.h"
#include "rcfile.h"

#define RCFILE	".mmrc"

/* Startup variables */
IObottle  *rcfile = NULL;
MIME_body *startup = NULL;

MIME_body *Startup(char *RCpath)
{
	char *rcpath;
	char *home;
	char *nuttin[] = { NULL };

	/* Find and open the startup file */
	if ( RCpath == NULL ) {
		if ( (home=getenv("HOME")) == NULL )
			return(NULL);
		rcpath = new char[strlen(home)+1+strlen(RCFILE)+1];
		sprintf(rcpath, "%s/%s", home, RCFILE);
	} else {
		rcpath = new char[strlen(RCpath)+1];
		strcpy(rcpath, RCpath);
	}
	rcfile = new IObottle(rcpath);
	delete[] rcpath;

	/* Make sure we opened it okay */
	if ( rcfile->fail() || rcfile->eof() ) {
		delete rcfile;
		return(NULL);
	}

	/* Now parse it -- that easy! :) */
	return(new MIME_body(rcfile, nuttin));
}

char *GetStartVar(char *varname)
{
	MIME_body *variables;

	/* Get the variables section of the startup file */
	if ( ! startup || ((variables=startup->ByName("variables")) == NULL) )
		return(NULL);

	return((char *)variables->GetField(varname));
}
