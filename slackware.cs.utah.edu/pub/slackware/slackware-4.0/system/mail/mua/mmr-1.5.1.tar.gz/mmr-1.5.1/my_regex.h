
#ifndef _my_regex_h
#define _my_regex_h

/* My simple regular expression matching engine */

extern char *match(char *string, char *pattern, int *matchlen);
extern char *match_nocase(char *string, char *pattern, int *matchlen);

#endif /* _my_regex_h */
