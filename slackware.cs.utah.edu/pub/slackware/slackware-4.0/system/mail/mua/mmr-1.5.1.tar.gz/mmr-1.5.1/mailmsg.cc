
/* The body of the mail message class

   This is a logical structure for the raw data of a message.
    -- threading, status, raw read/write, etc.
*/

#include <stdlib.h>
#include <time.h>

#include "headers.h"
#include "mailmsg.h"
#include "my_regex.h"

/*#define REWRITE_MBOX		/* Write new messages out as unread */

char *
mailmsg::boundary[] = { "From", NULL };

/* This is called by a program to create a new list of messages */
mailmsg:: mailmsg(IObottle *mailfile, void (*oncreate)(mailmsg *ptr) = NULL)
{
	struct mbox_data *MBox;

	/* Fill in the mailbox info */
	MBox = new struct mailmsg::mbox_data;
	MBox->MailFile = mailfile;
	MBox->nmessages = 0;
#ifdef THREADMAIL
	MBox->showthreads = SHOW_THREADS;
#else
	MBox->showthreads = NO_THREADS;
#endif
	MBox->aborted = 0;
	MBox->saveall = 1;
	MBox->onsave = NULL;

	/* Start it up! :) */
	Init(MBox, NULL, 1, oncreate);
}

mailmsg:: mailmsg(struct mbox_data *MBox, mailmsg *prevmesg, int seqnum,
						void (*oncreate)(mailmsg *ptr))
{
	Init(MBox, prevmesg, seqnum, oncreate);
}

void
mailmsg:: Init(struct mbox_data *MBox, mailmsg *prevmesg, int seqnum,
						void (*oncreate)(mailmsg *ptr))
{
	/* Set the mailbox data */
	mbox = MBox;

	/* Mark the position of this message in the file */
	MailFile = mbox->MailFile;
	mstart = MailFile->tellg();
	body   = new MIME_body(MailFile, boundary); 
	mlength = (MailFile->tellg()-mstart);

	/* Set up the message list */
	++mbox->nmessages;
	index = seqnum;

	/* Run the callback, if any */
	if ( oncreate )
		(*oncreate)(this);

	/* Recursively create the next messages on the list */
	privprev = prev = prevmesg;
	if ( MailFile->eof() )
		privnext = next = NULL;
	else
		privnext = next = new mailmsg(mbox, this, index+1, oncreate);

	/* Pass ourselves down for threading */
	/* Note that on average case, if it weren't for the subject hashing,
	   the strcmp() in ThreadMe would be performed O(n^2) times.
	*/
	thread_prev = NULL;
	thread_next = NULL;
	threaded = 0;
	thread_size = 0;
	subject_key = NormalizeSubject(GetField("Subject"));
	subject_hash = HashString(subject_key);
	if ( next )
		next->ThreadMe(this, subject_hash, subject_key);
	status = NULL;
	Status((char *)GetField("Status"));
	NoChange();

	/* Make sure we delete messages that were aborted previously */
	if ( *status == 'D' )
		NewField("Status", "O");
}

void
mailmsg:: QueueRing(Fifo<buflen> *ringbuf, char *data, int len)
{
	buflen *bptr;

	bptr = new buflen;
	bptr->data = new char[len];
	bptr->len = len;
	memcpy(bptr->data, data, len);
	/* Put back the newline */
	if ( data[len-1] == '\0' )
		bptr->data[len-1] = '\n';
	ringbuf->Push(bptr);
}

/* Note that the gap ranges from 0 to negative infinity */
int
mailmsg:: FlushRing(Fifo<buflen> *ringbuf, int gap)
{
	buflen *bptr;

	/* See if we can write out a bunch of data */
	while ( (bptr=ringbuf->Peek()) && ((bptr->len+gap) <= 0) ) {
		if ( MailFile->write(bptr->data, bptr->len) != bptr->len ) {
			/* FIXME!  Abort -- disk full? */
		}
		gap += bptr->len;
		ringbuf->Pull();
		delete bptr->data;
		delete bptr;
	}
	return(gap);
}

int
mailmsg:: SaveToDisk(Fifo<buflen> *ringbuf, int gap)
{
	buflen *bptr;
	char   *sptr;			/* Temporary (char *) pointer */
	char    newdata[BUFSIZ];
	int     newlen, lenleft;
	int     status_written = 0;

	/* Write out any data possible */
	gap = FlushRing(ringbuf, gap);

	/* If there is no gap, the ring is empty, and we are in the
	   proper place, we don't have to rewrite ourselves here.
	*/
	if ( (*Status() == *DiskStatus()) && ! gap && ! ringbuf->Peek() &&
						(MailFile->tellp() == mstart) )
		return(0);

	/* Run the callback, if any */
	if ( mbox->onsave )
		(*(mbox->onsave))(this);

	/* Do it! */
	switch (*status) {
		case 'D':
			/* We don't save anything to disk */
			if ( ! mbox->aborted ) {
				gap -= mlength;
				MailFile->seekg(mstart+mlength);

				/* Force our status to "deleted" */
				NewField("Status", "D");
				break;
			}
			/* If aborted, fall through and save ourselves */

		default:
			/* Save ourselves to disk */
			/* First the header */
			while ( ! MailFile->fail() ) {
				newlen = MailFile->readline(newdata, BUFSIZ);
				gap -= newlen;

				/* Break at end of header */
				if ( newdata[0] == '\0' )
					break;

				/* Check for status line and update it */
				/* Hack hack hack. :) */
				if ( strncasecmp(newdata, "Status: ",
						strlen("Status: ")) == 0 ) {
					char *schar;
					sptr=newdata+strlen("Status: ");
					/* There is a status, right? */
					if ( ! *sptr ) {
						gap -= newlen;
						continue;
					}
					schar = 
					  ((*status == ' ') ? "R" : status);
					*sptr = *schar;
					NewField("Status", schar);
					status_written = 1;
				}

				/* Queue current data */
				QueueRing(ringbuf, newdata, newlen);

				/* Write out data if possible */
				gap = FlushRing(ringbuf, gap);
			}

			/* Now write the current status, if necessary */
			if ( ! status_written ) {
				char *schar;
				sptr = new char[strlen("Status: ")+2+1];
				strcpy(sptr, "Status: ");
				schar = ((*status == ' ') ? "R" : status);
				strcat(sptr, schar); strcat(sptr, "\n");
				QueueRing(ringbuf, sptr, strlen(sptr));
				delete[] sptr;
				NewField("Status", schar);
			}
			QueueRing(ringbuf, "\n", 1);
			gap = FlushRing(ringbuf, gap);

			/* Splash past the body */
			lenleft = (mlength-(MailFile->tellg()-mstart));
			while ( (lenleft > 0) && ! MailFile->fail() ) {
				newlen = MailFile->readline(newdata, BUFSIZ);

				/* Simple corruption check -- early end? */
				if ( strncmp(newdata, "From ",
						strlen("From ")) == 0 ) {
					cerr << "Warning: Corrupt mailfile?"
								<< endl;
					break;
				}

				/* Queue current data */
				QueueRing(ringbuf, newdata, newlen);
				gap -= newlen;
				lenleft -= newlen;

				/* Write out data if possible */
				gap = FlushRing(ringbuf, gap);
			}
			break;
	}
	if ( next )
		return(next->SaveToDisk(ringbuf, gap));
	else {
		int    newmail = 0;

		/* New Mail! */
		while ( (newlen=MailFile->read(newdata, BUFSIZ)) > 0 ) {
			QueueRing(ringbuf, newdata, newlen);
			gap -= newlen;
			gap = FlushRing(ringbuf, gap);
			++newmail;
		}
		/* Flush the ring -- write past EOF here */
		while ( (bptr=ringbuf->Pull()) ) {
			if ( MailFile->write(bptr->data, bptr->len) !=
								bptr->len ) {
				/* FIXME!  Abort -- disk full? */
			}
			delete bptr->data;
			delete bptr;
		}
		MailFile->flush();
		MailFile->truncate(MailFile->tellp());
		return(newmail);
	}
	/* Not reached */
}

int
mailmsg:: Lock(void)
{
	char *lockfile;
	int   lockfd;

	/* Figure out the lock file */
	lockfile = new char[strlen(MailFile->Path())+5+1];
	sprintf(lockfile, "%s.lock", MailFile->Path());

	/* Assume a blocking Lock() call */
	while ( ((lockfd=open(lockfile, (O_WRONLY|O_CREAT|O_EXCL), 0)) < 0) &&
							(errno == EEXIST) ) {
		sleep(1);
	}
	if ( lockfd >= 0 )
		close(lockfd);
	delete[] lockfile;

	/* The lock failing could be a problem.. */
	(void) MailFile->lock();		/* Blocking call */
	return((lockfd < 0) ? 0 : 1);
}

void
mailmsg:: UnLock(int locked)
{
	/* Figure out the lock file */
	if ( locked ) {
		char *lockfile;

		lockfile = new char[strlen(MailFile->Path())+5+1];
		sprintf(lockfile, "%s.lock", MailFile->Path());
		(void) unlink(lockfile);
		delete[] lockfile;
	}
	(void) MailFile->unlock();
}

mailmsg:: ~mailmsg()
{
#ifdef REWRITE_MBOX		/* This rewrites the status of incoming mail */
	if ( *Status() == 'N' ) {
		for ( mailmsg *mesgptr=this; mesgptr; mesgptr=mesgptr->next ) {
			if ( *(mesgptr->Status()) == 'N' )
				mesgptr->Status("O");
		}
	}
#endif

	/* Check to see if our status changed */
	if ( mbox->saveall && (*Status() != *DiskStatus()) ) {
		int newmail, locked;

		Fifo<buflen> *ringbuf = new Fifo<buflen>;
		MailFile->clrerr();
		MailFile->seekg(mstart);
		MailFile->seekp(mstart);
		/* Lock the mailfile */
		locked = Lock();
		newmail = SaveToDisk(ringbuf, 0); 
		if ( ringbuf->Size() > 0 ) {
			cerr << "Warning: Internal error: ringbuf not flushed!"
								<< endl;
		}
		delete ringbuf;

		/* Check for new mail */
		time_t now = time(NULL);
		if ( newmail > 0 )
			MailFile->set_time(now-1, now);
		else
			MailFile->set_time(now, now-1);

		/* Unlock the mailfile */
		UnLock(locked);
	}
	delete[] status;

	/* Clean up thread data */
	if ( subject_key )
		delete[] subject_key;

	/* Clean up message body */
	delete body;

	/* Delete next message in chain */
	if ( next )
		delete next;
}

/* Verify that our content has not changed.
   We do this by creating a new message body and verifying that it is the
   same as our original.
 */
int
mailmsg:: Verify(void)
{
	long       oldpos;
	MIME_body *newbody;
	int        okay = 1;

	oldpos = MailFile->tellg();
	MailFile->seekg(mstart);
	newbody = new MIME_body(MailFile, boundary);
	if ((mlength != (MailFile->tellg()-mstart)) || (*newbody != *newbody))
		okay = 0;
	MailFile->seekg(oldpos);
	delete newbody;
	return(okay);
}

int
mailmsg:: NewMail(void)
{
	long       oldpos;
	char       testbuf[BUFSIZ];
	mailmsg   *newmsg;

	/* The last message in the chain should perform newmail addition */
	if ( privnext )
		return(privnext->NewMail());

	/* Check for EOF in the mailfile */
	oldpos = MailFile->tellg();
	MailFile->seekg(mstart+mlength);
	if ( MailFile->read(testbuf, BUFSIZ) <= 0 ) {
		MailFile->seekg(oldpos);
		return(-1);
	}

	/* Read in the new messages */
	MailFile->seekg(mstart+mlength);
	privnext = new mailmsg(mbox, this, index+1, NULL);

	/* Continue any threads with the new messages */
	for ( newmsg=this; newmsg; newmsg = newmsg->privprev ) {
		/* Attach only to ends of threads */
		if ( newmsg->thread_next == NULL ) {
			privnext->ThreadMe(newmsg, newmsg->subject_hash,
						newmsg->subject_key);
		}
	}

	/* Attach it to the end of the list of messages */
	for ( newmsg=next; newmsg && newmsg->next; newmsg = newmsg->next );
	if ( newmsg )
		newmsg->next = privnext;
	else
		next = privnext;
	return(0);
}

int
mailmsg:: Save(char *filename)
{
	FILE *output;
	char  buffer[BUFSIZ];
	char *home;
	int   len, lenleft;

	/* Make sure we have somewhere to save. :) */
	if ( ! filename || ! *filename ) {
		errno = EINVAL;
		return(-1);
	}

	/* Open the output file */
	if ( (output=fopen(filename, "a")) == NULL )
		return(-1);

	/* Seek appropriately and save out the message */
	MailFile->seekg(mstart);
	for ( lenleft = mlength; lenleft > 0; lenleft -= len ) {
		if ( lenleft < BUFSIZ )
			len = MailFile->read(buffer, lenleft);
		else
			len = MailFile->read(buffer, BUFSIZ);

		if ( len == 0 ) {
			/* Some read error */
			fclose(output);
			return(-1);
		}
		if ( fwrite(buffer, 1, len, output) != len ) {
			fclose(output);
			return(-1);
		}
	}
	fclose(output);
	return(0);
}

/* Create the thread linkages recursively.  This function is called from
   an earlier message, wanting to know if it is part of a thread deeper
   in the chain.  We can assume we are the direct thread-child of that
   message, if we match it, and we just attach ourselves right up.
*/
int
mailmsg:: ThreadMe(mailmsg *me, int hash, char *subject)
{
	if ( subject && subject_key && (hash == subject_hash) &&
					(strcmp(subject_key, subject) == 0) ) {
		mailmsg *mesgptr;
		int      n;

		/* Stuff ourselves in as a thread */
		me->thread_next = this;
		thread_prev = me;

		/* thread_size (ThreadSize) goes: 3 2 1 (go up) */
		if ( thread_size == 0 )
			thread_size = 1;
		for ( n=1, mesgptr=me; mesgptr; mesgptr=mesgptr->thread_prev,
									++n )
			mesgptr->thread_size = (thread_size+n);

		/* threaded (ThreadIndex) goes: 0 1 2  (go deeper) */
		for ( n=(me->threaded+1), mesgptr=this; mesgptr; 
					mesgptr=mesgptr->thread_next, ++n )
			mesgptr->threaded = n;

		/* That's it, we've been threaded */
		return(1);
	} else if ( next )
		return(next->ThreadMe(me, hash, subject));
	return(0);
}

/* See/Set the status of the message */
const char *
mailmsg:: Status(int in_listing = 0)
{
	/* Thread aware. :) */
	if ( in_listing && (mbox->showthreads == HIDE_THREADS) ) {
		/* Return the _thread_ status */
		if ( ThreadSize() && ! ThreadIndex() ) {
			mailmsg *mesgptr;

			/* Look for any new message */
			mesgptr = this;
			do {
				if ( *(mesgptr->Status()) == 'N' )
					return(mesgptr->Status());
			} while ( mesgptr = mesgptr->ThreadNext() );

			/* Look for any non-deleted messages */
			mesgptr = this;
			do {
				if ( *(mesgptr->Status()) != 'D' )
					return(mesgptr->Status());
			} while ( mesgptr = mesgptr->ThreadNext() );
			return("D");  /* Deleted thread */
		}
	}
	return(status);
}
const char *
mailmsg:: DiskStatus(void)
{
	return(TranslateStatus((char *)GetField("Status")));
}

/* Message state transitions and actions */
#define STATE_NULL	0
#define STATE_PUSH	1
#define STATE_POP	2
#define STATE_REPL	3

inline int StateIndex(char State)
{
	switch (State) {
		case 'N':	/* New -- Unread, unreplied */
			return(0);
		case ' ':	/* Read and/or replied to */
			return(1);
		case 'D':	/* Deleted */
			return(2);
		case 'U':	/* Undeleted/Unread */
			return(3);
		default:	/* Unknown state */
			return(4);
	}
}
static int State_Transitions[5][5] = {
         /* 0 */      /* 1 */     /* 2 */     /* 3 */     /* 4 */
/* 0 */ { STATE_NULL, STATE_PUSH, STATE_PUSH, STATE_NULL, STATE_NULL },
/* 1 */ { STATE_REPL, STATE_NULL, STATE_PUSH, STATE_POP,  STATE_NULL },
/* 2 */ { STATE_REPL, STATE_NULL, STATE_NULL, STATE_POP,  STATE_NULL },
/* 3 */ { STATE_NULL, STATE_NULL, STATE_NULL, STATE_NULL, STATE_NULL },
/* 4 */ { STATE_REPL, STATE_REPL, STATE_REPL, STATE_NULL, STATE_NULL },
};

void
mailmsg:: Status(char *newstatus)
{
	char *ptr;

	newstatus = (char *)TranslateStatus(newstatus);

	/* Set default status */
	if ( ! status ) {
		status = new char[2];
		strcpy(status, "?");
	}

	/* If no status change, don't mark the status as being changed */
	if ( *newstatus == *status )
		return;

	/* Perform the state transition and mark the message as changed */
	switch (State_Transitions[StateIndex(*status)][StateIndex(*newstatus)]){
		case STATE_NULL:
			break;
		case STATE_PUSH:
			ptr = status;
			status = new char[1+strlen(ptr)+1];
			sprintf(status, "%c%s", *newstatus, ptr);
			delete[] ptr;
			break;
		case STATE_POP:
			if ( strlen(status) == 1 ) {
				/* A pop of a single state results in 'N' */
				*status = 'N';
			} else {
				ptr = status;
				status = new char[strlen(ptr)-1+1];
				strcpy(status, ptr+1);
				delete[] ptr;
			}
			break;
		case STATE_REPL:
			*status = *newstatus;
			break;
	}
	++changed;
	return;
}

/* Thread navigation stuff */
mailmsg *
mailmsg:: ByIndex(int the_index)
{
	if ( the_index == index )
		return(this);
	if ( next && (the_index > index) )
		return(next->ByIndex(the_index));
	if ( prev && (the_index < index) )
		return(prev->ByIndex(the_index));
	/* Always returns some message */
	return(this);
}
mailmsg *
mailmsg:: ByStatus(char *the_status)
{
	mailmsg *next_one;
	if ( *the_status == *Status() )
		return(this);
	if ( (next_one=Next()) )
		return(next_one->ByStatus(the_status));
	return(NULL);
}
mailmsg *
mailmsg:: ByBody(MIME_body *the_body)
{
	mailmsg *next_one;
	if ( *the_body == *body )
		return(this);
	if ( (next_one=Next()) )
		return(next_one->ByBody(the_body));
	return(NULL);
}
int 
mailmsg:: ThreadSize(void)
{
	if ( mbox->showthreads == NO_THREADS )
		return(0);
	return(thread_size);
}
int 
mailmsg:: ThreadIndex(void)
{
	if ( mbox->showthreads == NO_THREADS )
		return(0);
	return(threaded);
}
mailmsg *
mailmsg:: Next(void)
{
	switch (mbox->showthreads) {
		case NO_THREADS:
			return(next);
		case HIDE_THREADS: {
			mailmsg *ptr = next;
			while ( ptr && ptr->threaded )
				ptr = ptr->next;
			return(ptr);
			}
		case SHOW_THREADS:
			if ( ! thread_next ) {
				mailmsg *ptr;
				/* Back up the current thread */
				ptr = this;
				while ( ptr->threaded )
					ptr = ptr->thread_prev;
				/* Skip intervening threaded mail */
				ptr = ptr->next;
				while ( ptr && ptr->threaded )
					ptr = ptr->next;
				return(ptr);
			} else
				return(thread_next);
	}
	return(NULL); /* Error? */
}
mailmsg *
mailmsg:: Next(int howmany)
{
	mailmsg *mesgptr, *nextptr;
	
	for ( mesgptr=this; howmany && (nextptr=mesgptr->Next()); --howmany )
		mesgptr = nextptr;
	return(mesgptr);
}
mailmsg *
mailmsg:: Prev(void)
{
	switch (mbox->showthreads) {
		case NO_THREADS:
			return(prev);
		case HIDE_THREADS:
			if ( prev && prev->threaded )
				return(prev->Prev());
			return(prev);
		case SHOW_THREADS:
			if ( ! thread_prev ) {
				mailmsg *ptr = prev;

				/* Skip past intervening thread msgs */
				while ( ptr && ptr->threaded )
					ptr = ptr->prev;
				/* Go to end of possible thread */
				while ( ptr && ptr->thread_next )
					ptr = ptr->thread_next;
				return(ptr);
			} else
				return(thread_prev);
	}
	return(NULL); /* Error? */
}
mailmsg *
mailmsg:: Prev(int howmany)
{
	mailmsg *mesgptr, *prevptr;
	
	for ( mesgptr=this; howmany && (prevptr=mesgptr->Prev()); --howmany )
		mesgptr = prevptr;
	return(mesgptr);
}
/* Move around, finding an undeleted message */
mailmsg *
mailmsg:: SkipDeleted(int *rows)
{
	mailmsg *mesgptr;
	int      i, offset;

	/* Return ourselves if we qualify. :-) */
	if ( *Status() != 'D' )
		return(this);

	if ( ThreadSize() > 0 ) {
		/* Check for an undeleted message further down */
		mesgptr = Next();
		offset  = 0;
		for ( i=(ThreadSize()-1); i; --i ) {
			++offset;
			if ( *mesgptr->Status() != 'D' ) {
				if ( rows ) *rows = offset;
				return(mesgptr);
			}
			mesgptr = mesgptr->Next();
		}
		/* Okay, try further up */
		mesgptr = Prev();
		offset  = 0;
		for ( i=ThreadIndex(); i; --i ) {
			--offset;
			if ( *mesgptr->Status() != 'D' ) {
				if ( rows ) *rows = offset;
				return(mesgptr);
			}
			mesgptr = mesgptr->Prev();
		}
	}

	/* Nope, either we are not a thread, or the entire thread is deleted */
	mesgptr = Next();
	offset  = 0;
	while ( mesgptr ) {
		++offset;
		if ( *mesgptr->Status() != 'D' ) {
			if ( rows ) *rows = offset;
			return(mesgptr);
		}
		mesgptr = mesgptr->Next();
	}
	return(NULL);
}

/* Header field stuff */
char *
mailmsg:: GetHeader(char **keyholder)
{
	return(body->GetHeader(keyholder));
}
void
mailmsg:: NewField(char *name, char *value)
{
	body->NewField(name, value);
}
const char *
mailmsg:: GetField(char *key)
{
	return(body->GetField(key));
}

/* This function takes a mail subject, and strips all "Re:" type strings. */
/* This is useful for determining whether a message is part of a thread */
char *
mailmsg:: NormalizeSubject(const char *subject)
{
	char *newsubject;
	char *REptr;
	int   RElen;
	
	/* Check to make sure there is a subject */
	if ( subject ) {
		newsubject = new char[strlen(subject)+1];
		strcpy(newsubject, subject);
	} else
		return(NULL);

	while ( (REptr = match(newsubject, "R[Ee][^:]*:[ ]+", &RElen)) ) {
		char *ptr, *newptr;
		int i;

		/* Copy the stripped subject line */
		newptr = new char[strlen(newsubject)-RElen+1];
		for ( i=0, ptr = newsubject; ptr != REptr; ++ptr, ++i )
			newptr[i] = *ptr;
		ptr += RElen;
		while ( *ptr )
			newptr[i++] = *(ptr++);
		newptr[i] = '\0';

		/* Sanity check */
		if ( i != (strlen(newsubject)-RElen) ) {
			cerr << "Warning: RE stripping: possible corruption!"
								<< endl;
		}

		/* Make it the new subject */
		delete[] newsubject;
		newsubject = newptr;
	}
	return(newsubject);
}

int
mailmsg:: HashString(char *str)
{
	int num = 0;
	while ( str && *str ) {
		num += *str;
		++str;
	}
	return(num);
}

char *
mailmsg:: FromName(char *namebuf, int namelen)
{
	const char *from = From();
	char *matchptr;
	int   matchlen;

	/* Make a copy of the from field */
	strncpy(namebuf, from, namelen-1);
	if ( strlen(from) > (namelen-1) )
		namebuf[namelen-1] = '\0';
	else
		namebuf[strlen(from)] = '\0';

	/* Check for a name:
			"homer@simpsons.org "Homer Simpson (tm)""
	*/
	if ( (matchptr=match(namebuf, "\".*\"", &matchlen)) ) {
		strncpy(namebuf, matchptr+1, matchlen-2);
		namebuf[matchlen-2] = '\0';
	} else
	/* Check for a name:
			"homer@simpsons.org (Homer Simpson)"
	*/
	if ( (matchptr=match(namebuf, "(.*)", &matchlen)) ) {
		strncpy(namebuf, matchptr+1, matchlen-2);
		namebuf[matchlen-2] = '\0';
	} else
	/* Check for an e-mail address:
			"Homer Simpson <homer@simpsons.org>"
	*/
	/* This pattern is equivalent to "[ \t]+<.*>", but less buggy. ;) */
	if ( (matchptr=match(namebuf, "[ \t][ \t]*<.*>", &matchlen)) ) {
		*matchptr = '\0';
	}
	/* Strip any quotes */
	if ( (matchptr=match(namebuf, "\".*\"", &matchlen)) ) {
		strncpy(namebuf, matchptr+1, matchlen-2);
		namebuf[matchlen-2] = '\0';
	}
	/* That should catch most of them.. :-) */
	return(namebuf);
}

/* Translate the date of the message into a numerical date string
   This works, but is not used.  Since it could be useful, I'll leave it.
*/
char *
mailmsg:: MMDDYY(void)
{
	static char *months[] = {
		"Jan", "Feb", "Mar", "Apr", "May", "Jun",
		"Jul", "Aug", "Sep", "Oct", "Nov", "Dec", NULL
	};
	char *datefield, *bad_date="??/??/??";
	char *day, *month, *year;
	int   dayi, monthi, yeari;
	int   dlen;
	static char datebuf[12];

	/* Actually, if this failed, we could use the first "From ..." line */
	if ( (datefield=(char *)GetField("Date")) == NULL )
		return(bad_date);
	else {
		char *dptr = new char[strlen(datefield)+1];
		strcpy(dptr, datefield);
		datefield = dptr;
	}

	/* Extract the portions of the string that we need */
	if ( (day=match(datefield,
			"[0-9]+ [A-Z][a-z][a-z] [0-9][0-9]",
							&dlen)) == NULL ) {
		delete[] datefield;
		return(bad_date);
	}
	dayi = atoi(day);

	/* Pull the month */
	for ( month=day; !isspace(*month); ++month );
	*(month++) = '\0';
	for ( ; isspace(*month); ++month );

	/* Pull the year */
	for ( year=month; !isspace(*year); ++year );
	*(year++) = '\0';
	for ( ; isspace(*year); ++year );
	for ( ; isdigit(*year); ++year );
	*year = '\0';
	year -= 2;
	yeari = atoi(year);

	/* Get the number of the month */
	for ( monthi = 0; months[monthi]; ++monthi ) {
		if ( strcasecmp(month, months[monthi]) == 0 )
			break;
	}
	if ( ! months[monthi] ) {
		delete[] datefield;
		return(bad_date);
	}
	
	/* Put it all together */
	sprintf(datebuf, "%.2d/%.2d/%.2d", monthi+1, dayi, yeari);
	delete[] datefield;
	return(datebuf);
}
char *
mailmsg:: MonthDay(void)
{
	static char *months[] = {
		"Jan", "Feb", "Mar", "Apr", "May", "Jun",
		"Jul", "Aug", "Sep", "Oct", "Nov", "Dec", NULL
	};
	char *datefield, *bad_date="??? ??";
	char *day, *month, *year;
	int   dayi, monthi, yeari;
	int   dlen;
	static char datebuf[7];

	/* Actually, if this failed, we could use the first "From ..." line */
	if ( (datefield=(char *)GetField("Date")) == NULL )
		return(bad_date);
	else {
		char *dptr = new char[strlen(datefield)+1];
		strcpy(dptr, datefield);
		datefield = dptr;
	}

	/* Extract the portions of the string that we need */
	if ( (day=match(datefield, "[0-9]+ [A-Z][a-z][a-z] [0-9][0-9]",
							&dlen)) == NULL ) {
		delete[] datefield;
		return(bad_date);
	}
	dayi = atoi(day);

	/* Pull the month */
	for ( month=day; !isspace(*month); ++month );
	*(month++) = '\0';
	for ( ; isspace(*month); ++month );

	/* Pull the year */
	for ( year=month; !isspace(*year); ++year );
	*(year++) = '\0';
	for ( ; isspace(*year); ++year );
	for ( ; isdigit(*year); ++year );
	*year = '\0';
	year -= 2;
	yeari = atoi(year);

	/* Get the number of the month */
	for ( monthi = 0; months[monthi]; ++monthi ) {
		if ( strcasecmp(month, months[monthi]) == 0 )
			break;
	}
	if ( ! months[monthi] ) {
		delete[] datefield;
		return(bad_date);
	}
	
	/* Put it all together */
	sprintf(datebuf, "%s %.2d", months[monthi], dayi);
	delete[] datefield;
	return(datebuf);
}
