
#include "terminal.h"
#include "commands.h"

/* Here are the key bindings for the above commands */
static struct cmdtab_entry {
	int		key;
	cmd_token	cmd;
} commands[] = {
	{ 'q',		QUIT },
	{ KEY_LEFT,	QUIT },
	{ 'Q',		QUITALL },
	{ '^',		GOTO_START },
	{ 'k',		LINE_UP },
	{ '',		LINE_UP },
	{ KEY_UP,	LINE_UP },
	{ 'j',		LINE_DOWN },
	{ '',		LINE_DOWN },
	{ KEY_DOWN,	LINE_DOWN },
	{ 'b',		PAGE_UP },
	{ '',		PAGE_UP },
	{ '',		PAGE_UP },
#ifdef KEY_PPAGE
	{ KEY_PPAGE,	PAGE_UP },
#endif
	{ ' ',		PAGE_DOWN },
	{ '',		PAGE_DOWN },
	{ '',		PAGE_DOWN },
#ifdef KEY_NPAGE
	{ KEY_NPAGE,	PAGE_DOWN },
#endif
	{ '$',		GOTO_END },
	{ 'G',		GOTO_END },
	{ 'c',		GOTO_MSG },
	{ '1',		GOTO_MSG },
	{ '2',		GOTO_MSG },
	{ '3',		GOTO_MSG },
	{ '4',		GOTO_MSG },
	{ '5',		GOTO_MSG },
	{ '6',		GOTO_MSG },
	{ '7',		GOTO_MSG },
	{ '8',		GOTO_MSG },
	{ '9',		GOTO_MSG },
	{ '/',		SEARCH_FORE },
	{ '?',		SEARCH_BACK },
	{ 'n',		SEARCH_REP },
	{ 'i',		MSG_INFO },
	{ '\r',		MSG_VIEW },
	{ KEY_RIGHT,	MSG_VIEW },
	{ '\t',		MSG_NEXT },
	{ 'd',		MSG_DEL },
	{ 'u',		MSG_UNDEL },
	{ 'r',		MSG_REPLY },
	{ 'R',		MSG_REPLYALL },
	{ '',		MSG_SREPLY },
	{ 'f',		MSG_FORWARD },
	{ 'm',		MSG_NEW },
	{ 's',		MSG_SAVE },
	{ 'S',		MSG_SAVEALL },
	{ 'o',		MSG_ORDER },
	{ REDRAW_CMD,	REDRAW },
	{ 'h',		HELP },
	{ '!',		SYSTEM },
	{ 0,		UNKNOWN }
};

/* Translate a key to a command */
cmd_token KeyToCmd(int key)
{
	int i;
	for ( i=0; commands[i].key; ++i ) {
		if ( key == commands[i].key )
			break;
	}
	return(commands[i].cmd);
}
