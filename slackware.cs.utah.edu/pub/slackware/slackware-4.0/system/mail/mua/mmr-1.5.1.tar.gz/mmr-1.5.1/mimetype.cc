
/* Functions to translate and determine MIME types */

extern "C" {
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <ctype.h>
#include <errno.h>
};
#include "hash.tmpl"
#include "mimetype.h"

/* A standard set of MIME types... */
#ifndef MIMETYPE_FILE
#define MIMETYPE_FILE	"/usr/local/lib/netscape/mime.types"
#endif
static char *std_mimetypes[] = {
	"application/pdf                pdf",
	"application/postscript         eps ps       ",
	"application/rtf                rtf             ",
	"application/x-csh              csh             ",
	"application/x-dvi              dvi             ",
	"application/x-latex            latex           ",
	"application/x-sh               sh              ",
	"application/x-tcl              tcl             ",
	"application/x-tk               tk              ",
	"application/x-tex              tex             ",
	"application/x-texinfo          texinfo texi   ",
	"application/x-troff            t tr roff       ",
	"application/x-troff-man        man             ",
	"application/x-troff-me         me              ",
	"application/x-troff-ms         ms              ",
	"application/zip                zip             ",
	"application/x-cpio             cpio            ",
	"application/x-shar             shar            ",
	"application/x-tar              tar             ",
	"application/x-compressed-gzip  gz              ",
	"audio/basic                    au snd          ",
	"audio/x-aiff                   aif aiff aifc",
	"audio/x-wav                    wav             ",
	"image/gif                      gif             ",
	"image/jpeg                     jpeg jpg jpe",
	"image/tiff                     tiff tif        ",
	"image/x-portable-anymap        pnm             ",
	"image/x-portable-bitmap        pbm             ",
	"image/x-portable-graymap       pgm             ",
	"image/x-portable-pixmap        ppm             ",
	"image/x-rgb                    rgb",
	"image/x-xbitmap                xbm             ",
	"image/x-xpixmap                xpm             ",
	"image/x-xwindowdump            xwd             ",
	"text/html                      html htm",
	"text/plain                     txt",
	"text/richtext                  rtx             ",
	"video/mpeg                     mpeg mpg mpe    ",
	"video/quicktime                qt mov          ",
	"video/x-msvideo                avi             ",
	"video/x-sgi-movie              movie           ",
	NULL,
};
static char **mime_types = NULL;
static Hash<char *>  *mimetype_hash = NULL;

/* Convert a line into white-space delimited tokens */
static int StrTOK(char *line, char **&tokens)
{
	char *word, *ptr;
	int   n, len;
	int   nwords;

	/* Figure out how many words to allocate */
	nwords = 0;
	ptr = line;
	while ( *ptr ) {
		while ( *ptr && isspace(*ptr) ) ++ptr;
		if ( *ptr ) {
			++nwords;
			while ( *ptr && !isspace(*ptr) ) ++ptr;
		}
	}

	/* Allocate the words */
	tokens = new char *[nwords+1];
	for ( n=0, ptr=line; *ptr; ) {
		while ( *ptr && isspace(*ptr) ) ++ptr;
		if ( *ptr ) {
			word = ptr;
			while ( *ptr && !isspace(*ptr) ) ++ptr;
			len = (ptr-word);
			tokens[n] = new char[len+1];
			memcpy(tokens[n], word, len);
			tokens[n][len] = '\0';
			++n;
		}
	}
	tokens[n] = NULL;
	return(nwords);
}

/* Initialize mime_types */
void Init_MIMEtypes(char *mimefile)
{
	FILE *mimetype_fp;

	/* Reload? */
	if ( mime_types != NULL )
		Quit_MIMEtypes();

	if ( mimefile == NULL )
		mimefile = MIMETYPE_FILE;

	mimetype_hash = new Hash<char *>(32);
	if ( (mimetype_fp=fopen(mimefile, "r")) ) {
		char   line[BUFSIZ];
		char **tokens;
		int    n, m, i, j;

		for ( n=0; fgets(line, BUFSIZ-1, mimetype_fp); ) {
			if ( line[0] && (line[0] != '#') )
				++n;
		}
		rewind(mimetype_fp);
		mime_types = new char *[n+1];
		for ( n=0, i=0; fgets(line, BUFSIZ-1, mimetype_fp); ++i ) {
			if ( ! line[0] || (line[0] == '#') )
				continue;
			m = StrTOK(line, tokens);
			mime_types[n++] = tokens[0];
			for ( j=1; j<m; ++j ) {
				mimetype_hash->Add(tokens[j], tokens[0]);
				delete[] tokens[j];
			}
			delete[] tokens;
		}
		mime_types[n] = NULL;
	} else {
		char **tokens;
		int    n, m, i, j;

		for ( n=0; std_mimetypes[n]; ++n );
		mime_types = new char *[n+1];
		for ( n=0, i=0; std_mimetypes[i]; ++i ) {
			m = StrTOK(std_mimetypes[i], tokens);
			mime_types[n++] = tokens[0];
			for ( j=1; j<m; ++j ) {
				mimetype_hash->Add(tokens[j], tokens[0]);
				delete[] tokens[j];
			}
			delete[] tokens;
		}
		mime_types[n] = NULL;
	}
}
/* Free mime_types memory */
void Quit_MIMEtypes(void)
{
	if ( ! mime_types )
		return;

	for ( int i=0; mime_types[i]; ++i )
		delete[] mime_types[i];
	delete[] mime_types;
	mime_types = NULL;

	delete mimetype_hash;
	mimetype_hash = NULL;
}

/* Given a filename, return an appropriate MIME type */
char * MIME_Type(char *filename)
{
	char *extension, **type;

	/* Grab the extension */
	if ( (extension=strrchr(filename, '.')) == NULL )
		return(NULL);
	++extension;
	if ( (type=mimetype_hash->Search(extension)) )
		return(*type);
	return(NULL);
}

/* Given a filename, return an appropriate MIME encoding */
/*
   Rules:
	7-bit non-control-char text is encoded as 7bit
	8-bit non-control-char text is encoded as quoted-printable
	data with nulls or control characters is encoded as base64
*/
#define control(c)	((c < ' ') && ((c!='\t')&&(c!='\n')&&(c!='\n')))
#define sevenbit(c)	(!control(c) && ((c&0x80) == 0))
#define eightbit(c)	(!control(c))

char * MIME_Encoding(char *filename)
{
	char *encodings[] = {
		"7bit", "quoted-printable", "base64", NULL
	};
	int state = SEVEN_BIT;

	struct stat sb;
	FILE *input;
	int   len;
	/* This must be an UNSIGNED character buffer to evaluate properly */
	unsigned char  buffer[BUFSIZ];

	if ( (stat(filename, &sb) < 0) ||
		(!S_ISREG(sb.st_mode) && (errno = EISDIR)) ||
					(input=fopen(filename, "r")) == NULL )
		return(NULL);

	while ( (state != BASE64) &&
				((len=fread(buffer, 1, BUFSIZ, input)) > 0) ) {
		for ( int i=0; i<len; ++i ) {
			switch (state) {
				case SEVEN_BIT:
					if ( ! sevenbit(buffer[i]) ) {
#ifdef DEBUG
	if ( control(buffer[i]) )
		printf("7->other: Offending character is ^%c\n", buffer[i]+'@');
	else
		printf("7->other: Offending character is %c\n", buffer[i]);
#endif
						if ( eightbit(buffer[i]) )
							state = QUOTE_PRT;
						else
							state = BASE64;
					}
					break;
				case QUOTE_PRT:
					if ( ! eightbit(buffer[i]) ) {
#ifdef DEBUG
	printf("8->Base64: Offending character is ^%c\n", buffer[i]+'@');
#endif
						state = BASE64;
					}
					break;
				case BASE64:
					/* We're done checking! */
					break;
			}
		}
	}
	fclose(input);
	return(encodings[state]);
}
