
extern "C" {
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <unistd.h>
#include <strings.h>
};

#include <iostream.h>
#include "iobottle.h"

/* Include the base64 conversion routines */
#include "base64.cc"

int Base64_Decode(IObottle *body, char *endstrings[], int endlens[],
								char **outfile)
{
	long here = body->tellg();
	FILE *output;
	char *temp_name;
	char  line[1024], *newline;
	int   n, newlen, finished;

	/* Grab a temporary file */
	*outfile = NULL;
	if ( ((temp_name=tmpnam(NULL)) == NULL) ||
				((output=fopen(temp_name, "w")) == NULL) )
		return(-1);

	/* Just DO it! :) */
	for ( finished = 0; ! finished; ) {
		here = body->tellg();

		/* Read in the next line, checking for termination boundary */
		body->readline(line, 1024);
		if ( body->eof() ) {
			finished = 1;
			continue;
		}
		for ( n=0; endstrings[n]; ++n ) {
			if ( (strncmp(line,endstrings[n],endlens[n]) == 0) )
				break;
		}
		if ( endstrings[n] ) {
			finished = 1;
			continue;
		}

		/* Do any processing here */
		newlen = 0;
		if ( (line[0] == '\0') ||
			(base64_decode(&newline, &newlen, line) == 0) ) {
			if ( fwrite(newline, 1, newlen, output) != newlen ) {
				/* WRITE ERROR! */
				delete[] newline;
				fclose(output);
				(void) unlink(temp_name);
				return(-1);
			}
			/* End of Base64 text -- eat up remaining text */
			for ( finished = 0; ! finished; ) {
				here = body->tellg();

				body->readline(line, 1024);
				if ( body->eof() )
					break;
				for ( n=0; endstrings[n]; ++n ) {
					if ( (strncmp(line, endstrings[n],
							endlens[n]) == 0) )
						break;
				}
				if ( endstrings[n] )
					break;
			}
			break;
		}

		/* Write to the temporary file */
		if ( fwrite(newline, 1, newlen, output) != newlen ) {
			/* WRITE ERROR! */
			delete[] newline;
			fclose(output);
			(void) unlink(temp_name);
			return(-1);
		}
		delete[] newline;
	}
	fclose(output);

	/* Rewind to before the terminating line */
	body->seekg(here);
	*outfile = new char[strlen(temp_name)+1];
	strcpy(*outfile, temp_name);
	return(0);
}


main(int argc, char *argv[])
{
	char *outfile;
	char *seps[] = { NULL };

	while ( *(++argv) ) {
		IObottle input(*argv);

		if ( input.fail() ) {
			cerr << "Couldn't open " << *argv << endl;
			continue;
		}
		if ( Base64_Decode(&input, seps, NULL, &outfile) < 0 ) {
			cerr << "Base64_Decode() returned error!" << endl;
			continue;
		}
		cout << "Decoded data saved to: " << outfile << endl;
	}
	exit(0);
}
