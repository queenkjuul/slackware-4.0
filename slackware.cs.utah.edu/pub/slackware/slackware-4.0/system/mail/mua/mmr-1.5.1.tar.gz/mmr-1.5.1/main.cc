
/* This is the main body of my C++ mailer */

/* Include all of the standard headers that we need */
#include "headers.h"
#include "my_regex.h"
#include "iobottle.h"
#include "terminal.h"
#include "mailmsg.h"
#include "listing.h"
#include "outgoing.h"
#include "mime.h"
#include "mimetype.h"
#include "rcfile.h"

static char *Version = 
	"My Mailer v1.5.1 by Sam Lantinga <slouken@devolution.com>";

/* The location of the user mailboxes */
#ifndef MAILPATH
//#define MAILPATH	"/var/mail"			/* A common path */
#define MAILPATH	"/usr/spool/mail"
#endif

/* Global variables */
IObottle *mailfile = NULL;
mailmsg  *messages = NULL;
Msg_Listing *listing = NULL;

/* Startup variables */
extern MIME_body *Startup(char *RCpath);
extern IObottle  *rcfile;
int was_compressed = 0;

void LoadStatus(mailmsg *message)
{
	static char twiddle[] = "-+|+";
	cerr << "\b\b" << twiddle[message->Index()%4] << ')';
}
void QuitStatus(mailmsg *message)
{
	static char twiddle[] = "-+|+";
	cerr << "\b\b" << twiddle[message->Index()%4] << ')';
}


/* Note that it's possible for us to be called multiple times:
	e.g. if there's a segmentation violation from within this function..
*/
void quit(int exitcode)
{
	int sig;

	/* Ignore signals while we clean up */
	signal(SIGHUP, SIG_IGN);
	signal(SIGINT, SIG_IGN);
	signal(SIGQUIT, SIG_IGN);
	signal(SIGSEGV, SIG_DFL);
	signal(SIGBUS, SIG_DFL);
	signal(SIGTERM, SIG_IGN);
#ifdef SIGWINCH
	signal(SIGWINCH, SIG_DFL);
#endif

	/* Clean up everything */
	if ( listing ) {
		delete listing;
		listing = NULL;
	}

	/* Why are we exiting? */
	switch(exitcode) {
		case SIGHUP:
			if ( messages )
				messages->Abort();
			cout << "\rExiting because of hang-up signal!" << endl;
			break;
		case SIGINT:
		case SIGQUIT:
			if ( messages )
				messages->Abort();
			cout << "\rExiting because of keyboard interrupt!" <<
									endl;
			break;
		case SIGSEGV:
		case SIGBUS:
			if ( messages )
				messages->Abort();
			cout << "\rExiting because of program bug!" << endl;
			break;
		case SIGTERM:
			if ( messages )
				messages->Abort();
			cout << "\rExiting because of termination signal!" <<
									endl;
			break;
		default:
			break;
	}
	/* Make sure we have a mailfile and messages */
	if ( mailfile ) {
		char cmdbuf[BUFSIZ];

		if ( messages ) {
			cout << "Saving  messages: ( )" << flush;
			messages->OnSave(QuitStatus);
			delete messages;
			messages = NULL;
			cout << " -- Done." <<  endl;

			/* Check for new mail */
			time_t atime, mtime;
			mailfile->get_time(&atime, &mtime);
			if ( mtime > atime )
				cout << "You have NEW mail!" << endl;
		}
		if ( was_compressed ) {
			/* For some reason, this crashes on some mailboxes
				cmdbuf = new char[strlen("gzip "),
						strlen(mailfile->Path())+1];
			*/
			sprintf(cmdbuf, "gzip %s", mailfile->Path());
		}
		delete mailfile;
		mailfile = NULL;

		/* Any final mailfile cleanup */
		if ( was_compressed ) {
			cout << "Compressing mailfile..." << flush;
			(void) system(cmdbuf);
			cout << "Done." << endl;
			/* For some reason, this crashes on some mailboxes
				delete[] cmdbuf;
			*/
		}
	}
	Quit_MIMEtypes();
	if ( startup ) {
		delete startup;
		delete rcfile;
		startup = NULL;
	}
	exit(exitcode);
}

/* Notify the listing of a window size change */
void resize(int sig)
{
	signal(sig, resize);
	if ( listing )
		listing->ReSize();
	
}

int CheckLock(const char *path)
{
	struct stat sb;
	char *lockfile;
	int   retval;

	/* Just try to stat() the lockfile */
	lockfile = new char[strlen(path)+5+1];
	sprintf(lockfile, "%s.lock", path);
	retval = stat(lockfile, &sb);
	delete[] lockfile;
	return(retval == 0 ? 1 : 0);
}

static time_t last_mtime = 0;
static off_t  last_size  = 0;
mailmsg *CheckMail(mailmsg *current, Terminal *tty, int *changed)
{
	time_t   mtime;
	off_t    size;
	int      threading;
	mailmsg *newmsgs;
	mailmsg *origptr, *newptr, *otherptr;
	int      oldwait, answer;
	char     buffer[BUFSIZ];

	/* Check for modified mailbox */
	mailfile->get_time(NULL, &mtime);
	mailfile->Size(&size);
	if ( (mtime == last_mtime) && (size == last_size) )
		return(current);

	/* If we are aborted here, we don't save the mailfile */
	messages->SetSave(0);

	/* Check for simple newly arrived mail */
	if ( size > last_size ) {
		mailmsg *lastmesg = messages->ByIndex(messages->NumMessages());

		/* If last message is fine, assume newly arrived mail */
		if ( lastmesg->Verify() ) {
			tty->status(0, "You have NEW mail!");
			/* Check the lockfile */
			do {
				sleep(1);
			} while ( CheckLock(mailfile->Path()) );

			if ( lastmesg->NewMail() < 0 ) {
				tty->promptchar(0,
		"Internal Error: lastmesg->NewMail() failed -- aborting.");
				return(NULL);
			}
			messages->SetSave(1);
			mailfile->get_time(NULL, &last_mtime);
			mailfile->Size(&last_size);
			if ( changed )
				++(*changed);
			return(current);
		}
	}

	oldwait = tty->setwait(5*2);	/* Wait for 5 seconds */
	answer = tty->promptchar(0,
		"Mailfile has changed.  [R]eload messages or [q]uit? ");
	tty->setwait(oldwait);
	if ( tolower(answer) == 'q' )
		return(NULL);
		
	/* Check the lockfile */
	while ( CheckLock(mailfile->Path()) )
		sleep(1);
	
	/* Make sure there is mail there */
	mailfile->seekg(0);
	if ( mailfile->readline(buffer, BUFSIZ) <= 1 ) {
		tty->status(0, "No mail left in %s", mailfile->Path());
		sleep(3);
		return(NULL);
	}
	mailfile->seekg(0);

	/* Create a new set of messages */
	tty->status(0, "Reloading messages: ( )");
	newmsgs = new mailmsg(mailfile, LoadStatus);
	mailfile->get_time(NULL, &last_mtime);
	mailfile->Size(&last_size);

	/* Mark deleted messages as deleted */
	threading = messages->ShowThreads();
	messages->ShowThreads(NO_THREADS);
	newmsgs->ShowThreads(NO_THREADS);
	for ( origptr = messages, newptr = newmsgs; origptr;
						origptr = origptr->Next() ) {
		if ( *origptr->Status() == *origptr->DiskStatus() )
			continue;

		otherptr = newptr;
		while ( (otherptr=otherptr->ByBody(origptr->Body())) ) {
			if ( *otherptr == *origptr ) {
				/* Skip newptr to keep step here */
				newptr = otherptr;
				break;
			}
		}
		if ( otherptr != NULL )
			otherptr->Status((char *)origptr->Status());
		LoadStatus(origptr);
	}

	/* Try to keep the same current message */
	while ( (otherptr=newmsgs->ByBody(current->Body())) ) {
		if ( *otherptr == *current )
			break;
	}
	if ( ! otherptr ) {
		if ( ((current = newmsgs->ByStatus("N")) == NULL) &&
		     ((current = newmsgs->ByStatus("O")) == NULL) ) {
			mailmsg *newmsg;
			for ( current = newmsgs; newmsg = current->Next(); )
				current = newmsg;
		}
	} else
		current = otherptr;

	/* Now delete the old messages */
	delete messages;
	messages = newmsgs;
	messages->ShowThreads(threading);

	/* Return. :) */
	if ( changed )
		++(*changed);
	return(current);
}

void Usage(char *prog)
{
	cout << 
Version << endl << endl <<
"Usage: " << prog << " [-s subject] recipient1 recipient2 ... " << endl <<
"or...  " << prog << " -c" << endl <<
"or...  " << prog << " [-r initfile] [-f mailbox]" << endl <<
	endl;
}

main(int argc, char *argv[])
{
	/* Flags */
	int   check_mail = 0;
	char *rcpath = NULL;
	char *subject = NULL;

	/* Normal variables */
	char *mailpath = NULL;
	char *lockfile;
	char *whoami;
	char *variable;
	mailmsg *current;

	/* Parse the command line arguments */
	int arg;
	while ( (arg=getopt(argc, argv, "cf:hr:s:v")) != EOF ) {
		switch (arg) {
			case 'c':
				/* Check for new mail */
				check_mail = 1;
				break;
			case 'h':
				Usage(argv[0]);
				quit(0);
			case 'f':
				mailpath = optarg;
				break;
			case 'r':
				rcpath = optarg;
				break;
			case 's':
				subject = optarg;
				break;
			default:
				Usage(argv[0]);
				quit(0);
		}
	}
	argc -= optind;
	argv += optind;
	umask(066);			/* Protect our tempfiles */

	/* Open the startup file */
	startup = Startup(rcpath);

	/* Load MIME type database */
	Init_MIMEtypes(NULL);

	/* Command line mailing? */
	if ( *argv ) {
		if ( NewMail(argv, subject) < 0 ) {
			cerr << "Mail send failed!" << endl;
			quit(-1);
		}
		quit(0);
	}

	/* Use the default mailfile, if defined */
	if ( mailpath == NULL )
		mailpath = GetStartVar("MailFile");

	/* Find out who we are and what our mailfile is */
	if ( (mailpath == NULL) &&
			((mailpath=(char *)getenv("MAIL")) == NULL) ) {
		if ( ((whoami=getlogin()) == NULL) &&
					((whoami=cuserid(NULL)) == NULL) ) {
			cerr << "Who are you?  -- Aborting!" << endl;
			quit(-1);
		}
		mailpath = new char[strlen(MAILPATH)+1+strlen(whoami)+1];
		sprintf(mailpath, "%s/%s", MAILPATH, whoami);
	}

	/* Check for new mail and quit */
	if ( check_mail ) {
		struct stat sb;

		if ( (stat(mailpath, &sb) < 0) || (sb.st_size == 0) ) 
			cout << "No mail." << endl;
		else if ( sb.st_mtime < sb.st_atime )
			cout << "You have mail." << endl;
		else
			cout << "You have NEW mail." << endl;
		quit(0);
	}

	/* Check to see if the lock file exists */
	if ( CheckLock(mailpath) ) {
		cout << "Lockfile (" << mailpath << ".lock) exists!" << endl;
		cout << "Please try again later..." << endl;
		quit(0);
	}

	/* Check for compressed mail */
	{
		struct stat sb;
		char *ptr, *cmdbuf = new
				char[strlen("gzip -d ")+strlen(mailpath)+3+1];
		int decompress = 0;

		/* Check for compressed mailfile */
		sprintf(cmdbuf, "gzip -d %s", mailpath);
		ptr = cmdbuf + strlen("gzip -d ")+strlen(mailpath)-3;
		if ( strcmp(ptr, ".gz") == 0 ) {
			/* Strip .gz ending on mailpath */
			ptr = mailpath+strlen(mailpath)-3;
			*ptr = '\0';
			decompress = 1;
		} else if ( stat(ptr, &sb) < 0 ) {
			strcat(cmdbuf, ".gz");
			ptr = cmdbuf + strlen("gzip -d ");
			if ( stat(ptr, &sb) == 0 )
				decompress = 1;
		}

		/* Perform decompression */
		if ( decompress ) {
			cout << "Uncompressing mailfile..." << flush;
			if ( system(cmdbuf) == 0 )
				was_compressed = 1;
			cout << "Done." << endl;
		}
		delete[] cmdbuf;
	}
		
	/* Set up the signal handlers */
	signal(SIGHUP, quit);
	signal(SIGINT, quit);
	signal(SIGQUIT, quit);
	signal(SIGSEGV, quit);
	signal(SIGBUS, quit);
	signal(SIGTERM, quit);
#ifdef SIGWINCH
	signal(SIGWINCH, resize);
#endif

	/* If we get here, we are reading mail */
	mailfile = new IObottle(mailpath);
	char             buffer[BUFSIZ];

	if ( mailfile->fail() || mailfile->eof() ) {
		cout << "No mail in " << mailpath << endl;
		quit(0);
	}
	if ( mailfile->readline(buffer, BUFSIZ) == 1 ) {
		cout << "Newline at start of mailfile -- aborting!" << endl;
		quit(-1);
	}
	mailfile->seekg(0);

	/* Set the MIME content types to ignore */
	MIME_body::MIME_Ignore(GetStartVar("MIME_ignore"));

	/* If we have succeeded in opening the mailfile, load mail */
	cout << "Loading messages: ( )" << flush;
	messages = new mailmsg(mailfile, LoadStatus);
	if ( ((current = messages->ByStatus("N")) == NULL) &&
	     ((current = messages->ByStatus("O")) == NULL) ) {
		mailmsg *newmsg;
		for ( current = messages; newmsg = current->Next(); )
			current = newmsg;
	}
	cout << " -- Done." <<  endl;
	sleep(1);
	mailfile->get_time(NULL, &last_mtime);
	mailfile->Size(&last_size);

	/* Set the threading, if desired */
	if ( (variable=GetStartVar("Threading")) != NULL ) {
		if ( strcmp(variable, "NO_THREADS") == 0 )
			messages->ShowThreads(NO_THREADS);
		else
		if ( strcmp(variable, "HIDE_THREADS") == 0 )
			messages->ShowThreads(HIDE_THREADS);
		else
		if ( strcmp(variable, "SHOW_THREADS") == 0 )
			messages->ShowThreads(SHOW_THREADS);
	}

	/* Note that the listing will control the new "current" message */
	listing = new Msg_Listing(mailfile, current);

	/* Set the listing format */
	if ( (variable=GetStartVar("IndentThread")) != NULL ) {
		if ( tolower(*variable) == 'n' )
			listing->IndentThread(0);
		else
			listing->IndentThread(1);
	}

	/* Main command loop */
	listing->RunMain(CheckMail);
	quit(0);
}
