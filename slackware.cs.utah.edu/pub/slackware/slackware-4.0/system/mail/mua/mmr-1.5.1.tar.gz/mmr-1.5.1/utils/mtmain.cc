
#include <stdio.h>
#include "mimetype.h"

main(int argc, char *argv[])
{
	char *encoding, *type;

	Init_MIMEtypes(NULL);
	while ( *(++argv) ) {
		encoding = MIME_Encoding(*argv);
		if ( encoding == NULL ) {
			perror("Couldn't open file");
			continue;
		}
		if ( (type=MIME_Type(*argv)) == NULL ) {
			if ( strcmp(encoding, "base64") == 0 )
				type = DEFAULT_BIN;
			else
				type = DEFAULT_TXT;
		}
		printf("%s: Type = %s, Encoding = %s\n", *argv, type, encoding);
	}
	Quit_MIMEtypes();
}
