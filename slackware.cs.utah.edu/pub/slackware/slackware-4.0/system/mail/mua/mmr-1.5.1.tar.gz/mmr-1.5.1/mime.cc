
extern "C" {
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <unistd.h>
#include <strings.h>
#include <errno.h>
};

#include "mime.h"
#include "mimetype.h"
#include "my_regex.h"

#define SILLY_SUN_STUFF			/* Handle Sun's attachment formats */

/* MIME default values */
#define DEFAULT_VERSION		"1.0"
#define DEFAULT_CONTENT		"text/plain"
#define DEFAULT_ENCODING	"7bit"

/* Check if a line is a MIME boundary */
static int IsBoundary(char *line, char *boundary, int boundlen);

/* List of MIME encodings and stream handlers */
struct encoding_handler {
	char *type;			/* Case insensitive */
	int (*encode)(FILE *input, IObottle *output);
	int (*decode)(IObottle *, char **, int *, char **);
};

int No_Encode(FILE *input, IObottle *output);
int QP_Encode(FILE *input, IObottle *output);
int Base64_Encode(FILE *input, IObottle *output);

int No_Decode(IObottle *body,char *endstrings[],int endlens[], char **outfile);
int QP_Decode(IObottle *body,char *endstrings[],int endlens[], char **outfile);
int Base64_Decode(IObottle *body, char *endstrings[], int endlens[],
							char **outfile);

/* List of MIME encodings and handlers for them */
static struct encoding_handler encodings[] =
{
	{ "7bit",	No_Encode, No_Decode },
	{ "8bit",	No_Encode, No_Decode },
	{ "binary",	No_Encode, No_Decode },
	{ "quoted-printable", QP_Encode, QP_Decode },
	{ "base64",	Base64_Encode, Base64_Decode },
	{ NULL,		No_Encode, No_Decode }
};


/* Allow exclusion of particular MIME types */
char **MIME_body::mime_ignore = NULL;
void
MIME_body::MIME_Ignore(char *ignorelist)
{
	char *ptr, *word;
	int   i,   nwords;

	/* Clean out existing list */
	if ( mime_ignore ) {
		for ( i=0; mime_ignore[i]; ++i )
			delete[] mime_ignore[i];
		delete[] mime_ignore;
	}
	mime_ignore = NULL;

	/* Find out how long the new list is */
	nwords = 0;
	for ( ptr=ignorelist; ptr; ) {
		while ( *ptr && isspace(*ptr) ) ++ptr;
		if ( ! *ptr )
			break;
		while ( *ptr && !isspace(*ptr) ) ++ptr;
		++nwords;
	}
	/* We're done if we have an empty list */
	if ( nwords == 0 )
		return;

	mime_ignore = new char *[nwords+1];
	for ( i=0, ptr=ignorelist; i<nwords; ++i ) {
		int wordlen;
		while ( *ptr && isspace(*ptr) ) ++ptr;
		word = ptr;
		while ( *ptr && !isspace(*ptr) ) ++ptr;
		wordlen = (ptr-word);
		mime_ignore[i] = new char[wordlen+1];
		memcpy(mime_ignore[i], word, wordlen);
		mime_ignore[i][wordlen] = 0;
	}
	mime_ignore[i] = NULL;
}


/* The MIME_body class constructor */
MIME_body:: MIME_body(IObottle *RawFile, char *endings[],
						MIME_body *lineage = NULL)
{
	MD5_CTX md5_ctx;
	int i;
	char *ptr;
	char line[BUFSIZ];

	/* Get the file. :) */
	rawfile = RawFile;
	parent  = lineage;
	decoded = NULL;
	bodyref = 0;
	hstart  = rawfile->tellg();

	/* Copy the boundary string pointers */
	for ( numends = 0; endings[numends]; ++numends );
	endlens = new int[numends];
	endstrings = new char *[numends+1];
	for ( i = 0; endings[i]; ++i ) {
		endstrings[i] = endings[i];
		endlens[i] = strlen(endings[i]);
	}
	endstrings[i] = NULL;

	/* Read in the header until the first newline */
	char lastfield[1024], *lastdata=NULL;
	fieldtab = new Hash<char *>(16);
	do {
		/* Note, we don't check for boundary lines here.
		   It's mostly because mail messages will have a boundary
		   line as the first line, while MIME messages will not.
		   If I don't check for boundaries in the header, I avoid
		   the problem, but make it possible to mis-read a header
		   that isn't followed by a newline.  (a problem?)
		*/
		rawfile->readline(line, BUFSIZ);

		/* This allows us to put comments in a "header" :-) */
		if ( line[0] == '#' )
			continue;

		/* If the header line starts with whitespace, it continues
		   the last field.
		*/
		if ( isspace(line[0]) && lastdata ) {
			/* Remove the last field */
			fieldtab->Remove(lastfield);

			/* Create new appended field data */
			for ( ptr=line; isspace(*ptr); ++ptr );
			char *data = new char
					[strlen(lastdata)+1+strlen(ptr)+1];
			sprintf(data, "%s %s", lastdata, ptr);
			delete[] lastdata;

			/* Insert it into the hash list */
			fieldtab->Add(lastfield, data);
			lastdata = data;
		} else {
			/* If the header line contains ": " it is hashable */
			if ( (ptr=strstr(line, ": ")) != NULL ) {
				char *data;
				*ptr = '\0';
				for ( ptr += 2; isspace(*ptr); ++ptr );
				/* Translate inline QP characters */
				data = DecodeLine(ptr);
				fieldtab->Add(line, data); 
				strcpy(lastfield, line);
				lastdata = data;
			} else
				lastdata = NULL;
		}
	} while ( ! rawfile->eof() && (strlen(line) > 0) );

	/* We should check MIME version, but... :-)
	   We're an incomplete implementation anyway, and future versions
	   of MIME will probably be backwards compatible.
	 */
	if ( (version=GetField("Mime-Version")) == NULL )
		version = DEFAULT_VERSION;

	/* Set the content */
	if ( (content=GetField("Content-Type")) != NULL ) {
#ifdef SILLY_SUN_STUFF
		/* Handle special attachment types */
		if ( strncasecmp(content, "X-sun-attachment",
					strlen("X-sun-attachment")) == 0 ) {
			content = "multipart/mixed; boundary=\"--------\"";
		}
#endif /* SILLY_SUN_STUFF */
	} else
		content = DEFAULT_CONTENT;

	/* Set the encoding (support MIME and Sun protocol) */
	if ( (encoding=GetField("Content-Transfer-Encoding")) == NULL ) {
#ifdef SILLY_SUN_STUFF
		/* Handle special attachment types */
		if ( (encoding=GetField("X-Sun-Encoding-Info")) != NULL ) {
			if ( strcasecmp(encoding, "base64") == 0 ) {
				/* Set an application content type */
				content = "application/X-sun-unknown";
			}
		} else
#endif /* SILLY_SUN_STUFF */
			encoding = DEFAULT_ENCODING;
	}

	/* Try to get a name for this body */
	if ( (ptr=match((char *)content, "[Nn][Aa][Mm][Ee]=", &i)) != NULL ) {
		/* Pull out an unquoted name */
		ptr += i;
		GetWord(ptr, &name);
	} else
	if ( (ptr=match((char *)GetField("Content-Disposition"),
			"[Ff][Ii][Ll][Ee][Nn][Aa][Mm][Ee]=", &i)) != NULL ) {
		/* Pull out an unquoted name */
		ptr += i;
		GetWord(ptr, &name);
	} else
#ifdef SILLY_SUN_STUFF
	if ( (ptr=(char *)GetField("X-Sun-Data-Type")) != NULL ) {
		name = new char[strlen(ptr)+1];
		strcpy(name, ptr);
	} else
#endif /* SILLY_SUN_STUFF */
		name = NULL;
		
	/* Suck up the body, handling multipart messages */
	bstart = rawfile->tellg();
	MD5Init(&md5_ctx);
	multipart = NULL;
	if ( strncasecmp(content, "multipart", strlen("multipart")) == 0 ) {
		(void) ParseMulti(&md5_ctx);

		/* For now, delete complex parts we can't view */
		if ( multipart && (strncasecmp(content, "multipart/alternative",
					strlen("multipart/alternative")) == 0)){
			MIME_body  **dataptr;
			multipart->InitIterator();
			multipart->Iterate();		/* Keep simple part */
			while ( (dataptr=multipart->Iterate()) ) {
				MIME_body *oldpart = *dataptr;
				multipart->Remove(dataptr);
				delete oldpart;		/* Delete other part */
			}
		}

		/* Delete any MIME parts that we have been told to ignore */
		if ( mime_ignore ) {
			MIME_body  **dataptr;
			multipart->InitIterator();
			while ( (dataptr=multipart->Iterate()) ) {
				for ( i=0; mime_ignore[i]; ++i ) {
					if ( strcasecmp((*dataptr)->Content(),
							mime_ignore[i]) == 0 ) {
						MIME_body *oldpart = *dataptr;
						multipart->Remove(dataptr);
						delete oldpart;
					}
				}
			}
		}

		/* Multipart bodies that have only one subpart are, in effect,
		   proxies for us, and have our parents.
		*/
		if ( multipart && (multipart->Size() == 1) ) {
			MIME_body  **dataptr;

			multipart->InitIterator();
			dataptr = multipart->Iterate();
			(*dataptr)->parent = parent;
		}
	} else {
		/* Move the file pointer to the end of this body */
		for ( ; ; ) {
			int n, len;
			long here;

			/* Read in the next line, checking for boundary */
			here = rawfile->tellg();
			len = rawfile->readline(line, BUFSIZ);
			if ( rawfile->eof() )
				break;
			for ( n=0; endstrings[n]; ++n ) {
				/* If we have a match, break out */
				if (IsBoundary(line, endstrings[n], endlens[n]))
					break;
			}
			if ( endstrings[n] ) {
				rawfile->seekg(here);
				break;
			}
			MD5Update(&md5_ctx, (unsigned char *)line, len);
		}
	}
	MD5Final(md5sum, &md5_ctx);

	/* Tidy up */
	addedparts = NULL;
	if ( multipart )
		currentpart = 1;
	else
		currentpart = 0;
	return;
}

MIME_body:: ~MIME_body()
{
	char **dataptr;

	/* Free up memory used by header data strucures */
	fieldtab->InitIterator();
	while ( (dataptr=fieldtab->Iterate()) )
		delete[] *dataptr;
	delete fieldtab;

	/* Remove any temp file */
	while ( FreeFile() == 0 ) {
		/* Force a close */;
	}

	/* Free up any sub-part MIME bodies */
	if ( multipart ) {
		MIME_body  **dataptr;
		multipart->InitIterator();
		while ( (dataptr=multipart->Iterate()) )
			delete *dataptr;
		delete multipart;
	}
	if ( addedparts ) {
		IObottle  **dataptr;
		addedparts->InitIterator();
		while ( (dataptr=addedparts->Iterate()) )
			delete *dataptr;
		delete addedparts;
	}
	if ( name )
		delete[] name;

	/* Finally, clean up random memory chunks */
	delete[] endstrings;
	delete[] endlens;
}

/* Quick utility routine for getting a (possibly quoted) word from a string */
void
MIME_body:: GetWord(char *src, char **dst)
{
	char *src_head;
	int   wordlen;

	src_head = src;
	if ( *src == '"' ) {
		++src_head;
		++src;
		while ( *src && (*src != '"') )
			++src;
	} else {
		while ( *src && ! isspace(*src) )
			++src;
	}
	wordlen = (src-src_head);
	*dst = new char[wordlen+1];
	strncpy(*dst, src_head, wordlen);
	(*dst)[wordlen] = '\0';
}

/* Create a sub-menu of body parts ;-) */
int
MIME_body:: ParseMulti(MD5_CTX *md5ctx)
{
	int    n, seplen;
	char  *newcontent;
	char **newends;
	int   *newendlens;
	char   line[BUFSIZ];
	long   here;

	/* Copy the content string so we can muck it up :) */
	newcontent = new char[strlen(content)+1];
	strcpy(newcontent, content);

	/* Try to find the boundary */
	char *mstr, *sepstr;
	int   mlen;
	if ( (sepstr=match(newcontent, "[Bb][Oo][Uu][Nn][Dd][Aa][Rr][Yy]=",
							&mlen)) == NULL ) {
		delete[] newcontent;
		return(-1);
	}
	sepstr += mlen;
	if ( *sepstr == '"' )
		for ( mstr=(++sepstr); *mstr && (*mstr != '"'); ++mstr );
	else
		for ( mstr=sepstr; *mstr && !isspace(*mstr); ++mstr );
	*mstr = '\0';
	/* MIME boundaries are "--boundary" */
	*(--sepstr) = '-';
	*(--sepstr) = '-';

	/* Add in the boundary as a new ending */
	newends = new char *[numends+1+1];
	newendlens = new int [numends+1];
	for ( n=0; endstrings[n]; ++n ) {
		newends[n] = endstrings[n];
		newendlens[n] = endlens[n];
	}
	newends[n] = sepstr;
	seplen = strlen(sepstr);
	newendlens[n] = seplen;
	newends[n+1] = NULL;

	/* Suck up to the first boundary -- no pun intended. :) */
	here = rawfile->tellg();
	for ( ; ; ) {
		int len;

		here = rawfile->tellg();

		/* Read in the next line, checking for termination boundary */
		len = rawfile->readline(line, BUFSIZ);
		if ( rawfile->eof() )
			break;

		for ( n=0; newends[n]; ++n ) {
			if ( IsBoundary(line, newends[n], newendlens[n]) )
				break;
		}
		if ( newends[n] )
			break;

		MD5Update(md5ctx, (unsigned char *)line, len);
	}
	if ( newends[n] == NULL ) { /* EOF? */
		delete[] newcontent;
		delete[] newends;
		delete[] newendlens;
		return(-1);
	}

	/* Make sure we didn't hit an upper boundary */
	if ( strncmp(newends[n], sepstr, seplen) != 0 ) {
		rawfile->seekg(here);
		delete[] newcontent;
		delete[] newends;
		delete[] newendlens;
		return(-1);
	}

	/* Warning: Memory Leak!
	   At this point we never free 'newcontent', since it stays in use
	   by any child MIME bodies we create here.
	*/

	multipart = new List<MIME_body *>;
	do {
		/* Elegant, isn't it? */
		MIME_body *newbody = new MIME_body(rawfile, newends, this);
		MD5Update(md5ctx, newbody->md5sum, 16);
		multipart->Add(newbody);

		/* Check the next boundary line */
		here = rawfile->tellg();
		rawfile->readline(line, BUFSIZ);

		/* Anything other than our separator, we quit here */
		if ( strncmp(line, sepstr, seplen) != 0 )
			break;

		/* If we find "boundary--", then we suck up input and quit */
		if ( (line[seplen] == '-') && (line[seplen+1] == '-') ) {
			for ( ; ; ) {
				here = rawfile->tellg();

				rawfile->readline(line, BUFSIZ);
				if ( rawfile->eof() )
					break;

				for ( n=0; endstrings[n]; ++n ) {
					if ( IsBoundary(line, endstrings[n],
								endlens[n]) )
						break;
				}
				if ( endstrings[n] )
					break;
			}
			break;
		}
	} while ( ! rawfile->eof() );

	/* That's it!  We're done! :) */
	if ( ! rawfile->eof() )
		rawfile->seekg(here);
	delete[] newends;
	delete[] newendlens;
	return(0);
}

char *
MIME_body:: DecodeLine(const char *line)
{
	char *data, *ptr;
	data = new char[strlen(line)+1];
	strcpy(data, line);

	/* Check for translatable encodings */
	if ( (ptr=strstr(data, "=?")) != NULL ) {
		char *end;

		/* Mark this as the end of the non-encoded string */
		end = ptr;
		*end = '\0';

		/* Skip the encoding type -- assume that the decoded
		   data is comprehensible. :-)
		*/
		for ( ptr += 2; *ptr && (*ptr != '?'); ++ptr );
		if ( *ptr )
			++ptr;

		/* Assume quoted printable encoding... :-) */
		for ( ; *ptr && (*ptr != '?'); ++ptr );
		if ( *ptr )
			++ptr;

		/* Go, and translate */
		while ( *ptr && (*ptr != '?') ) {
			if ( *ptr == '=' ) {
				/* Make sure no buffer overflow */
				++ptr;
				if ( ! *ptr || ! *(ptr+1) )
					continue;

				/* Convert from hexidecimal */
				*end = '\0';
				if ( isdigit(*ptr) )
					*end |= (*ptr-'0');
				else
					*end |= (toupper(*ptr)-'A'+10);
				++ptr;
				*end <<= 4;
				if ( isdigit(*ptr) )
					*end |= (*ptr-'0');
				else
					*end |= (toupper(*ptr)-'A'+10);
				++end;
				++ptr;
			} else
				*(end++) = *(ptr++);
		}
		if ( *ptr )
			++ptr;
		if ( *ptr == '=' )
			++ptr;

		/* End of encoded data, continue with non-encoded data */
		while ( *ptr )
			*(end++) = *(ptr++);
		*end = '\0';
	}
	return(data);
}

int
MIME_body:: Open(void)
{
	int i;

	/* Save the body to a file, with appropriate translation */
	rawfile->seekg(bstart);

	for ( i=0; encodings[i].type; ++i ) {
		if ( strcasecmp(encodings[i].type, encoding) == 0 )
			break;
	}
	return(encodings[i].decode(rawfile, endstrings, endlens, &decoded));
}

void
MIME_body:: NewField(char *name, char *value)
{
	char *sptr;

	/* Remove any existing value */
	if ((sptr=(char *)GetField(name))) {
		delete[] sptr;
		fieldtab->Remove(name);
	}
	sptr = new char[strlen(value)+1];
	strcpy(sptr, value);
	fieldtab->Add(name, sptr);
}

const char *
MIME_body:: GetField(char *key)
{
	char **dataptr;
	if ( (dataptr=fieldtab->Search(key)) )
		return(*dataptr);
	return(NULL);
}

/* Allow searching of MIME bodies, matching within lines  */
MIME_body *
MIME_body:: Search(char *pattern)
{
	FILE *rawbody;
	int   found = 0;

	/* First check ourselves */
	if ( (strncmp(Content(), "text", strlen("text")) == 0) &&
				((rawbody=fopen(File(), "r")) != NULL) ) {
		char buffer[BUFSIZ];
		int  matchlen;

		while ( fgets(buffer, BUFSIZ-1, rawbody) ) {
			if ( match(buffer, pattern, &matchlen) ) {
				found = 1;
				break;
			}
		}
		fclose(rawbody);
		FreeFile();
	}
	if ( found )
		return(this);

	/* Check our children */
	if ( multipart ) {
		MIME_body **bodyptr;
		MIME_body  *okay;

		multipart->InitIterator();
		okay = NULL;
		while ( ! okay && (bodyptr=multipart->Iterate()) ) {
			okay = (*bodyptr)->Search(pattern);
		}
		return(okay ? okay : (MIME_body *)0);
	}
	return(NULL);
}

/* Add a part to the current body.
   Note, because we call MultipartMe(), we must be rewritten (with a greater
   length) to a new IO stream with SaveRaw(), or these changes will be lost.
 */
int
MIME_body:: AddPart(char *file, int is_mime = 0)
{
	MD5_CTX md5_ctx;
	int (*EncodeFile)(FILE *, IObottle *);
	FILE *input;
	char  line[BUFSIZ];
	int   len, blen;
	long  here;
	char *boundary, *ptr;
	char *newcontent, *newencoding;

	/* Open the input file */
	if ( ((newencoding=MIME_Encoding(file)) == NULL) ||
				((input=fopen(file, "r")) == NULL) )
		return(-1);

	/* Find the encoder we use */
	for ( len = 0; encodings[len].type; ++len ) {
		if ( strcasecmp(newencoding, encodings[len].type) == 0 )
			break;
	}
	EncodeFile = encodings[len].encode;

	/* Make sure we are a multipart message */
	if ( MultipartMe(&boundary) < 0 ) {
		fclose(input);
		return(-1);
	}
	blen = strlen(boundary);

	/* Add the new file, first seek to end of message */
	rawfile->seekg(bstart);
	do {
		here = rawfile->tellg();
		len = rawfile->readline(line, BUFSIZ);
		if ( (line[0] == '-') && (line[1] == '-') ) {
			if ( strncmp(&line[2], boundary, blen) == 0 ) {
				if ( (line[2+blen] == '-') &&
						(line[2+blen+1] == '-') ) {
					break;
				}
			}
		}
	} while ( ! rawfile->fail() && ! rawfile->eof() );
	rawfile->seekp(here);

	/* Add boundary */
	rawfile->printf("--%s\n", boundary);
	if ( ! is_mime ) {
		if ( (newcontent=MIME_Type(file)) == NULL ) {
			if ( strcmp(newencoding, "base64") == 0 )
				newcontent = DEFAULT_BIN;
			else
				newcontent = DEFAULT_TXT;
		}
		/* Skip the full path of the file when naming the content */
		if ( (ptr=strrchr(file, '/')) != NULL )
			file = ptr+1;
		rawfile->printf("Content-Type: %s; name=\"%s\"\n",
							newcontent, file);
		rawfile->printf("Content-Transfer-Encoding: %s\n", newencoding);
		rawfile->printf("\n");
	}
	if ( (*EncodeFile)(input, rawfile) < 0 ) {
		fclose(input);
		rawfile->seekg(here);
		rawfile->printf("--%s--\n", boundary);
		rawfile->truncate(rawfile->tellp());
		delete[] boundary;
		return(-1);
	}
	fclose(input);
	rawfile->printf("--%s--\n", boundary);
	rawfile->truncate(rawfile->tellp());
	delete[] boundary;

	/* Free up any sub-part MIME bodies */
	if ( multipart ) {
		MIME_body  **dataptr;
		multipart->InitIterator();
		while ( (dataptr=multipart->Iterate()) )
			delete *dataptr;
		delete multipart;
		multipart = NULL;
	}

	/* Create the new MIME body sublist */
	rawfile->seekg(bstart);
	MD5Init(&md5_ctx);
	(void) ParseMulti(&md5_ctx);
	MD5Final(md5sum, &md5_ctx);
	return(0);
}

/* NOTE:  After this function runs, we are no longer tied to the main MIME
          message base.  We are fully contained in a separate temporary file,
	  and must be rewritten to a stream via the SaveRaw() function.
*/
int
MIME_body:: MultipartMe(char **boundaryptr)
{
	/* Output variables */
	char *temp_name;
	FILE *teaser;
	int   i;
	IObottle *output;

	/* MIME variables */
	const char *oldcontent = Content();
	const char *oldencoding = Encoding();
	char *newcontent = "multipart/mixed; boundary=";
	char *boundary, *ptr;
	int   set_version, set_content, set_encoding;

	/* Buffer copy variables */
	char  line[BUFSIZ];
	int   len, n;
	long  oldpos;

	/* Don't do anything if we are already multipart */
	if ( strncmp(oldcontent, "multipart/mixed", strlen("multipart/mixed"))
									== 0 ) {
		/* Try to find the boundary */
		char *mstr, *sepstr;
		int   mlen;

		newcontent = new char[strlen(oldcontent)+1];
		strcpy(newcontent, oldcontent);
		if ( (sepstr=match(newcontent,
				"[Bb][Oo][Uu][Nn][Dd][Aa][Rr][Yy]=",
							&mlen)) == NULL ) {
			delete[] newcontent;
			return(-1);
		}
		sepstr += mlen;
		if ( *sepstr == '"' )
			for (mstr=(++sepstr); *mstr && (*mstr != '"'); ++mstr);
		else
			for (mstr=sepstr; *mstr && !isspace(*mstr); ++mstr);
		*mstr = '\0';

		/* Copy it in.. */
		*boundaryptr = new char[strlen(sepstr)+1];
		strcpy(*boundaryptr, sepstr);
		delete[] newcontent;
		return(0);
	}

	/* Open a new file */
	if ( ((temp_name=tmpnam(NULL)) == NULL) ||
				((teaser=fopen(temp_name, "w")) == NULL) )
		return(-1);
	fclose(teaser);
	output = new IObottle(temp_name);
	if ( output->fail() ) {
		delete output;
		return(-1);
	}
	/* We are primed and ready. :) */

	/* Create the new content type and boundary */
	/* WARNING: Memory leak!
		content[] is never freed, since normally it is read-only.
	*/
	(char *)content = new char[strlen(newcontent)+1+32+1+1+1];
	strcpy((char *)content, newcontent);
	strcat((char *)content, "\"");
	boundary = (char *)content+strlen(newcontent)+1;
	for ( i=0, ptr=boundary; i<16; ++i, ptr += 2 )
		sprintf(ptr, "%.2X", md5sum[i]);
	*ptr = '\0';
	*boundaryptr = new char[2*16+1];
	strcpy(*boundaryptr, boundary);
	strcat((char *)content, "\";");
	encoding = "7bit";

	/* Write out our new header */
	oldpos = rawfile->tellg();
	rawfile->seekg(hstart);
	hstart = 0;
	set_version = set_content = set_encoding = 0;
	do {
		/* Read a header line */
		len = rawfile->readline(line, BUFSIZ);

		/* Check for header clean up at EOH (here) */
		if ( len == 1 ) {
			if ( ! set_version ) {
				output->printf("MIME-Version: %s\n", version);
			}
			if ( ! set_content ) {
				output->printf("Content-Type: %s\n", content);
			}
			if ( ! set_encoding ) {
				output->printf(
				"Content-Transfer-Encoding: %s\n", encoding);
			}
		}

		/* Translate a couple of fields, spit out the rest */
		if ( strncasecmp(line, "MIME-Version:",
					strlen("MIME-Version:")) == 0 ) {
			output->printf("MIME-Version: %s\n", version);
			set_version = 1;
		} else
		if ( strncasecmp(line, "Content-Type:",
					strlen("Content-Type:")) == 0 ) {
			output->printf("Content-Type: %s\n", content);
			set_content = 1;
		} else
		if ( strncasecmp(line, "Content-Transfer-Encoding:",
				strlen("Content-Transfer-Encoding:")) == 0 ) {
			output->printf("Content-Transfer-Encoding: %s\n",
								encoding);
			set_encoding = 1;
		} else
			output->writeline(line, len);
	} while ( strlen(line) > 0 );

	/* Print the intro and the initial body separator */
	bstart = output->tellg();
	output->writeline("\nThis is a multi-part message in MIME format.\n\n");
	output->printf("--%32.32s\n", boundary);

	/* Print out our existing body */
	output->printf("Content-Type: %s; name=\"Message Text\"\n", oldcontent);
	output->printf("Content-Transfer-Encoding: %s\n", oldencoding);
	output->printf("\n");
	for ( ; ; ) {
		/* Read in the next line, checking for boundary */
		len = rawfile->readline(line, BUFSIZ);
		if ( rawfile->eof() )
			break;
		for ( n=0; endstrings[n]; ++n ) {
			/* If we have a match, break out */
			if (IsBoundary(line, endstrings[n], endlens[n]))
				break;
		}
		if ( endstrings[n] )
			break;
		output->writeline(line, len);
	}
	output->printf("--%32.32s--\n", boundary);
	output->flush();

	/* That's it! */
	if ( addedparts == NULL )
		addedparts = new List<IObottle *>;
	addedparts->Add(output);
	rawfile = output;
	return(1);
}

/* Save the body to a file */
int
MIME_body:: Save(char *filename, int overwrite)
{
	char *ourfile;
	FILE *input, *output;
	char *mode;
	char  buffer[BUFSIZ];
	int   blen;
	int   retval;

	if ( ! filename || ! *filename )
		return(0);

	switch (overwrite) {
		case 0: {
			struct stat sb;
			if ( stat(filename, &sb) == 0 ) {
				errno = EEXIST;
				return(-1);
			}
			mode = "w";
			}
			break;
		case 1:
			mode = "w";
			break;
		case 2:
			mode = "a";
			break;
		default:
			errno = EINVAL;
			return(-1);
	}

	/* Open the files */
	ourfile = decoded;
	if ( ourfile == NULL ) {	/* Do a temporary open */
		if ( Open() < 0 ) {
			return(-1);
		}
		ourfile = decoded;
		decoded = NULL;
	}
	if ( (output=fopen(filename, mode)) == NULL ) {
		if ( decoded == NULL )
			(void) unlink(ourfile);
		return(-1);
	}
	if ( (input=fopen(ourfile, "r")) == NULL ) {
		fclose(output);
		if ( decoded == NULL )
			(void) unlink(ourfile);
		return(-1);
	}

	/* Just DO it */
	retval = 0;
	while ( (blen=fread(buffer, 1, BUFSIZ, input)) > 0 ) {
		/* Write okay? */
		if ( fwrite(buffer, 1, blen, output) != blen ) {
			retval = -1;
			break;
		}
	}
	/* Read error? */
	if ( ! feof(input) )
		retval = -1;

	/* Clean up and exit */
	fclose(input);
	fclose(output);
	if ( decoded == NULL )
		(void) unlink(ourfile);
	return(retval);
}

/* Check if a line is a MIME boundary */
static int IsBoundary(char *line, char *boundary, int boundlen)
{
	int bodies_ended = 0;

	/* Check for boundary matching */
	if ( strncmp(line, boundary, boundlen) != 0 )
		return(0);

	/* First part of boundary matched, now either it's a normal
	   MIME boundary (terminated by whitespace) or it's a special
	   "no more bodies" boundary (terminated by "--")
	*/
	if ( (line[boundlen] == '-') && (line[boundlen+1] == '-') ) {
		bodies_ended = 1;
		boundlen += 2;
	}
	if ( ! line[boundlen] || isspace(line[boundlen]) )
		return(1+bodies_ended);
	return(0);
}

/* Okay, the basic structure of a decoder is:

	Open a temporary file.
	Copy from IObottle to temporary file, performing appropriate decoding.
	Set outfile to NULL on write error and return -1.
	Quit writing at "endstrings" and rewind to the line before.
	Set outfile to name of temporary file and return 0.
*/

int No_Decode(IObottle *body, char *endstrings[], int endlens[], char **outfile)
{
	long here = body->tellg();
	FILE *output;
	char *temp_name;
	char  line[1024];
	int   n, finished;

	/* Grab a temporary file */
	*outfile = NULL;
	if ( ((temp_name=tmpnam(NULL)) == NULL) ||
				((output=fopen(temp_name, "w")) == NULL) )
		return(-1);

	/* Just DO it! :) */
	for ( finished = 0; ! finished; ) {
		here = body->tellg();

		/* Read in the next line, checking for termination boundary */
		body->readline(line, 1024);
		if ( body->eof() ) {
			finished = 1;
			continue;
		}
		for ( n=0; endstrings[n]; ++n ) {
			if ( IsBoundary(line,endstrings[n],endlens[n]) )
				break;
		}
		if ( endstrings[n] ) {
			finished = 1;
			continue;
		}

		/* Do any processing here */

		/* Write to the temporary file */
		if ( (fputs(line, output) == EOF) ||
					(fputc('\n', output) == EOF) ) {
			/* WRITE ERROR! */
			fclose(output);
			(void) unlink(temp_name);
			return(-1);
		}
	}
	fclose(output);

	/* Rewind to before the terminating line */
	body->seekg(here);
	*outfile = new char[strlen(temp_name)+1];
	strcpy(*outfile, temp_name);
	return(0);
}
int No_Encode(FILE *input, IObottle *output)
{
	char buffer[BUFSIZ];
	int len;

	while ( (len=fread(buffer, 1, BUFSIZ, input)) > 0 ) {
		if ( output->write(buffer, len) != len )
			return(-1);
	}
	return(0);
}

int QP_Decode(IObottle *body, char *endstrings[], int endlens[], char **outfile)
{
	long here = body->tellg();
	FILE *output;
	char *temp_name;
	char  line[1024], newline[1024];
	int   i, j, n;
	int   finished;

	/* Grab a temporary file */
	*outfile = NULL;
	if ( ((temp_name=tmpnam(NULL)) == NULL) ||
				((output=fopen(temp_name, "w")) == NULL) )
		return(-1);

	/* Just DO it! :) */
	for ( finished = 0; ! finished; ) {
		here = body->tellg();

		/* Read in the next line, checking for termination boundary */
		body->readline(line, 1024);
		if ( body->eof() ) {
			finished = 1;
			continue;
		}
		for ( n=0; endstrings[n]; ++n ) {
			if ( IsBoundary(line,endstrings[n],endlens[n]) )
				break;
		}
		if ( endstrings[n] ) {
			finished = 1;
			continue;
		}

		/* Strip trailing whitespace */
		for ( i = strlen(line); (i > 0) && isspace(line[i-1]); --i );
		line[i] = '\0';

		/* Convert lines from Quoted-Printable to raw data */
		for ( i = 0, j = 0; line[i]; ++i, ++j ) {
			if ( line[i] == '=' ) {
				/* Check for soft return */
				if ( line[i+1] == '\0' )
					break;

				/* Make sure no buffer overflow */
				if ( ! line[i+1] || ! line[i+2] )
					continue;

				/* Convert from hexidecimal */
				newline[j] = '\0';
				if ( isdigit(line[++i]) )
					newline[j] |= (line[i]-'0');
				else
					newline[j] |= (toupper(line[i])-'A'+10);
				newline[j] <<= 4;
				if ( isdigit(line[++i]) )
					newline[j] |= (line[i]-'0');
				else
					newline[j] |= (toupper(line[i])-'A'+10);
			} else
				newline[j] = line[i];
		}
		if ( line[i] == '=' ) {
			/* Soft Return, don't add a return to the stream */;
		} else {
			newline[j++] = '\n';
		}
		newline[j] = '\0';

		/* Write to the temporary file */
		if ( fputs(newline, output) == EOF ) {
			/* WRITE ERROR! */
			fclose(output);
			(void) unlink(temp_name);
			return(-1);
		}
	}
	fclose(output);

	/* Rewind to before the terminating line */
	body->seekg(here);
	*outfile = new char[strlen(temp_name)+1];
	strcpy(*outfile, temp_name);
	return(0);
}
/* A loose interpretation of the original... :-) */
/* This implementation allows whitespace at the end of the line.
   I do this mainly because a bunch of whitespace representations at the
   ends of many lines looks really bad.  Personal taste. :-)
*/
int QP_Encode(FILE *input, IObottle *output)
{
	char  buffer[BUFSIZ];
	char  outline[80];
	char *ptr;
	int   inlen, outlen;

	outlen = 0;
	while ( fgets(buffer, BUFSIZ-1, input) ) {
		inlen = strlen(buffer);

		/* The standard specifies no more than 76 chars per line */
		for ( ptr=buffer; *ptr && (*ptr != '\n'); ++ptr ) {
			/* Allowed non-encoded characters:
				'\t', ' ', '!'-'<', '>'-'~' inc. A-Za-z
			*/
			if ( (*ptr == '\t') || (*ptr == ' ') ||
					((*ptr >= 33) && (*ptr <= 60) ) ||
					((*ptr >= 62) && (*ptr <= 126) ) ) {
				outline[outlen++] = *ptr;

				/* If we've hit soft limit, put soft return */
				if ( outlen == 76 ) {
					outline[outlen++] = '=';
					outline[outlen++] = '\n';
					if ( output->write(outline, outlen) !=
								outlen ) {
						return(-1);
					}
					outlen = 0;
				}
			} else {
				/* If we've hit soft limit, put soft return */
				if ( outlen >= (76-3) ) {
					outline[outlen++] = '=';
					outline[outlen++] = '\n';
					if ( output->write(outline, outlen) !=
								outlen ) {
						return(-1);
					}
					outlen = 0;
				}
				
				/* Must encode */
				sprintf(&outline[outlen], "=%X", *ptr);
				outlen += 3;
			}
		}

		/* Take care of the (possible) newline */
		if ( buffer[strlen(buffer)-1] == '\n' ) {
			outline[outlen++] = '\n';
			if ( output->write(outline, outlen) != outlen )
				return(-1);
			outlen = 0;
		}
	}
	/* Flush any remaining output (file not terminated by newline) */
	if ( outlen > 0 ) {
		outline[outlen++] = '\n';
		if ( output->write(outline, outlen) != outlen )
			return(-1);
		outlen = 0;
	}
	return(0);
}

/* Declare the base64 conversion routines (from base64.cc) */
extern int base64_decode(char **dstptr, int *olen, char *from);
extern void base64_encode(char **dstptr, char *from, int fromlen);

/* Note, this hasn't been fully tested. */
int Base64_Decode(IObottle *body, char *endstrings[], int endlens[],
								char **outfile)
{
	long here = body->tellg();
	FILE *output;
	char *temp_name;
	char  line[1024], *newline;
	int   n, newlen, finished;

	/* Grab a temporary file */
	*outfile = NULL;
	if ( ((temp_name=tmpnam(NULL)) == NULL) ||
				((output=fopen(temp_name, "w")) == NULL) )
		return(-1);

	/* Just DO it! :) */
	for ( finished = 0; ! finished; ) {
		here = body->tellg();

		/* Read in the next line, checking for termination boundary */
		body->readline(line, 1024);
		if ( body->eof() ) {
			finished = 1;
			continue;
		}
		for ( n=0; endstrings[n]; ++n ) {
			if ( IsBoundary(line,endstrings[n],endlens[n]) )
				break;
		}
		if ( endstrings[n] ) {
			finished = 1;
			continue;
		}

		/* Do any processing here */
		newlen = 0;
		if ( (line[0] == '\0') ||
			(base64_decode(&newline, &newlen, line) == 0) ) {
			if ( fwrite(newline, 1, newlen, output) != newlen ) {
				/* WRITE ERROR! */
				delete[] newline;
				fclose(output);
				(void) unlink(temp_name);
				return(-1);
			}
			/* End of Base64 text -- eat up remaining text */
			for ( finished = 0; ! finished; ) {
				here = body->tellg();

				body->readline(line, 1024);
				if ( body->eof() )
					break;
				for ( n=0; endstrings[n]; ++n ) {
					if ( IsBoundary(line, endstrings[n],
								endlens[n]) )
						break;
				}
				if ( endstrings[n] )
					break;
			}
			break;
		}

		/* Write to the temporary file */
		if ( fwrite(newline, 1, newlen, output) != newlen ) {
			/* WRITE ERROR! */
			delete[] newline;
			fclose(output);
			(void) unlink(temp_name);
			return(-1);
		}
		delete[] newline;
	}
	fclose(output);

	/* Rewind to before the terminating line */
	body->seekg(here);
	*outfile = new char[strlen(temp_name)+1];
	strcpy(*outfile, temp_name);
	return(0);
}
int Base64_Encode(FILE *input, IObottle *output)
{
	char  buffer[19*3];
	char *outline;
	int   len;

	/* Loop, reading in 19*3 bytes, transforming them into 19*4 bytes */
	/*                  57                                 76         */
	while ( (len=fread(buffer, 1, 19*3, input)) > 0 ) {
		base64_encode(&outline, buffer, len);
		len = strlen(outline);
		if ( output->write(outline, len) != len )
			return(-1);
		output->printf("\n");
		delete[] outline;
	}
	return(0);
}
