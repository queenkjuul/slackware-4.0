
extern "C" {
#include <stdio.h>
#include <string.h>
#include <signal.h>
};

#include "terminal.h"

int Terminal::refcount = 0;
int Terminal::wasraw = 0;
int Terminal::maxwait = 0;

Terminal:: Terminal(int makeraw = 1)
{
	/* Initialize curses, if necessary */
	if ( refcount == 0 ) {
		initscr();
		if ( makeraw ) {
			cbreak();
			noecho();
		}
		nonl();
		wasraw = makeraw;
	}
	MyRef = refcount;

	/* Create the window */
	pane = NULL;
	sub1 = sub2 = NULL;
	statuspane = NULL;
	splity = 0;
	resizewin();
}

/* Reset should be called in reverse order of creation */
int
Terminal:: reset(void)
{
	/* Clean up existing windows */
	if ( statuspane )
		delwin(statuspane);
	if ( sub1 )
		delwin(sub1);
	if ( sub2 )
		delwin(sub2);
	if ( pane )
		delwin(pane);

	/* Only the first (0'th) screen created can do this */
	--refcount;
	if ( MyRef > 0 )
		return(0);
	if ( (MyRef == 0) && refcount )
		return(-1);

	/* Set up the newly sized window */
	endwin();
 	set_term(newterm(getenv("TERM"), stdout, stdin));
	if ( wasraw ) {
		cbreak();
		noecho();
	}
	nonl();
}

void
Terminal:: resizewin(void)
{
	/* Create the windows */
	refcount++;
	curpane = pane = newwin(lines()-1,0,0,0);
	if ( splity )
		split(splity);
	statuspane = newwin(1,0,lines()-1,0);

	/* Set hardware capabilities */
	idlok(pane, TRUE);
	scrollok(pane, TRUE);
	keypad(pane, TRUE);
	keypad(statuspane, TRUE);
}

Terminal:: ~Terminal()
{
	/* Clean up existing windows */
	if ( statuspane )
		delwin(statuspane);
	if ( sub1 )
		delwin(sub1);
	if ( sub2 )
		delwin(sub2);
	if ( pane )
		delwin(pane);

	/* Clean up everything, if necessary */
	if ( ! --refcount ) {
		endwin();
	}
}

/* Output routines */
void
Terminal:: printf(char *fmt, ...)
{
	char string[BUFSIZ];
	va_list ap;

	va_start(ap, fmt);
	vsprintf(string, fmt, ap);
	waddstr(curpane, string);
}
void
Terminal:: status(int striking, char *fmt, ...)
{
	char string[BUFSIZ];
	va_list ap;

	/* Clear existing status bar */
	waddch(statuspane, '\r');
	wclrtoeol(statuspane);

	/* Print formatted line */
	va_start(ap, fmt);
	vsprintf(string, fmt, ap);
	if ( striking )
		wattron(statuspane, A_STANDOUT);
	waddstr(statuspane, string);
	if ( striking )
		wattroff(statuspane, A_STANDOUT);
	wrefresh(statuspane);
}

/* Input routines */
int
Terminal:: waitchar(WINDOW *the_win = NULL)
{
	int ch, t;

	/* Default to the current pane */
	if ( the_win == NULL )
		the_win = curpane;

	/* This is a hack to get input stuffed into our queue */
	wtimeout(the_win, 500);		/* 1/2 second timeout on wgetch() */
	t = 0;
	while ( (! maxwait || (t < maxwait)) && ((ch=wgetch(the_win)) < 0) )
		++t;
	return(ch);
}
void
Terminal:: stuffch(int ch)
{
	ungetch(ch);
}
/* Timeout waiting for input (specified in 1/2 second intervals) */
int
Terminal:: setwait(int the_wait)
{
	int oldwait = maxwait;
	maxwait = the_wait;
	return(oldwait);
}
int
Terminal:: promptchar(int striking, char *fmt, ...)
{
	char string[BUFSIZ];
	va_list ap;
	int ch;

	/* Clear existing status bar */
	waddch(statuspane, '\r');
	wclrtoeol(statuspane);

	/* Print formatted line */
	va_start(ap, fmt);
	vsprintf(string, fmt, ap);
	if ( striking )
		wattron(statuspane, A_STANDOUT);
	waddstr(statuspane, string);
	if ( striking )
		wattroff(statuspane, A_STANDOUT);
	wrefresh(statuspane);
	return(waitchar(statuspane));
}
/* This is a full-editable line prompt */
/* Remember if you change this function, also change softprompt() below. */
char *
Terminal:: fillprompt(char *buf, int buflen, char *hard, char *autofill,
				char *(*complete)(char *))
{
	int offset, maxi;
	int i;
	int ch;

	/* Clear existing status bar */
	waddch(statuspane, '\r');
	wclrtoeol(statuspane);

	/* Print the hard part of the prompt */
	for ( offset = 0; *hard; ++hard, ++offset )
		waddch(statuspane, *hard);
	maxi = (cols()-offset-1);

	/* Print the autofill part of the prompt */
	--buflen;
	i = 0;
	buf[i] = '\0';
	if ( autofill ) {
		char *ptr;
		for (ptr=autofill; (i<maxi)&&(i<buflen) && *ptr; ++ptr, ++i) {
			buf[i] = *ptr;
			waddch(statuspane, *ptr);
		}
		buf[i] = '\0';
	}
	wrefresh(statuspane);

	/* Handle editing of the line */
	for ( ; ; ) {
		switch((ch=waitchar(statuspane))) {
			case '\t':
				if ( ! complete )
					break;
				/* Tab completion */
				wmove(statuspane, 0, offset);
				wclrtoeol(statuspane);
				strcpy(buf, (*complete)(buf));
				i = strlen(buf);
				waddstr(statuspane, buf);
				wrefresh(statuspane);
				break;
					
			case '':
			case KEY_RIGHT:
				if ( buf[i] ) {
					waddch(statuspane, buf[i]);
					wrefresh(statuspane);
					++i;
				}
				break;

			case '':
			case KEY_LEFT:
				if ( i > 0 ) {
					--i;
					wmove(statuspane, 0, offset+i);
					wrefresh(statuspane);
				}
				break;

			case '':
				/* Delete line */
				wmove(statuspane, 0, offset);
				wclrtoeol(statuspane);
				wrefresh(statuspane);
				i = 0;
				buf[i] = '\0';
				break;
				
			case '':
			case '':
			case KEY_BACKSPACE:
				if ( i > 0 ) {
					--i;
					wmove(statuspane, 0, offset+i);
					wclrtoeol(statuspane);
					for ( int j=i; buf[j]; ++j ) {
						buf[j] = buf[j+1];
						if ( buf[j] )
							waddch(statuspane, buf[j]);
					}
					wrefresh(statuspane);
				}
				break;

			case '\r':
				return(buf);

			default:
				if ( (i<maxi) && (i<buflen) ) {
					if ( buf[i] == '\0' ) {
						buf[i++] = ch;
						buf[i] = '\0';
					} else
						buf[i++] = ch;
					waddch(statuspane, ch);
					wrefresh(statuspane);
				}
				break;
		}
	}
	/* Never reached */
}
char *
Terminal:: softprompt(char *buf, int buflen, char *hard, char *soft,
				char *(*complete)(char *))
{
	int offset, maxi;
	int i;
	int ch;

	/* Clear existing status bar */
	waddch(statuspane, '\r');
	wclrtoeol(statuspane);

	/* Print the hard part of the prompt */
	for ( offset = 0; *hard; ++hard, ++offset )
		waddch(statuspane, *hard);
	maxi = (cols()-offset-1);

	/* Print the soft part of the prompt */
	--buflen;
	i = 0;
	buf[i] = '\0';
	if ( soft ) {
		char *ptr;
		wattron(statuspane, A_STANDOUT);
		for ( ptr=soft; (i<maxi) && (i<buflen) && *ptr; ++ptr, ++i ) {
			buf[i] = *ptr;
			waddch(statuspane, *ptr);
		}
		buf[i] = '\0';
		wattroff(statuspane, A_STANDOUT);
		/* Work around bug in ncurses */
		waddch(statuspane, '>');
		wrefresh(statuspane);
		waddstr(statuspane, "\b \b");
	}
	wrefresh(statuspane);

	/* Handle editing of the line */
	for ( ; ; ) {
		switch((ch=waitchar(statuspane))) {
			case '\t':
				if ( ! complete )
					break;
				if ( soft ) {
					/* Make it hard. :) */
					wmove(statuspane, 0, offset);
					wclrtoeol(statuspane);
					waddstr(statuspane, buf);
					soft = NULL;
				}
				/* Tab completion */
				wmove(statuspane, 0, offset);
				wclrtoeol(statuspane);
				strcpy(buf, (*complete)(buf));
				i = strlen(buf);
				waddstr(statuspane, buf);
				wrefresh(statuspane);
				break;
					
			case '':
			case KEY_RIGHT:
				if ( soft ) {
					/* Make it hard. :) */
					wmove(statuspane, 0, offset);
					wclrtoeol(statuspane);
					waddstr(statuspane, buf);
					wrefresh(statuspane);
					soft = NULL;
				}
				if ( buf[i] ) {
					waddch(statuspane, buf[i]);
					wrefresh(statuspane);
					++i;
				}
				break;

			case '':
			case KEY_LEFT:
				if ( soft ) {
					/* Make it hard. :) */
					wmove(statuspane, 0, offset);
					wclrtoeol(statuspane);
					waddstr(statuspane, buf);
					wrefresh(statuspane);
					soft = NULL;
				}
				if ( i > 0 ) {
					--i;
					wmove(statuspane, 0, offset+i);
					wrefresh(statuspane);
				}
				break;

			case '':
				/* Delete line */
				wmove(statuspane, 0, offset);
				wclrtoeol(statuspane);
				wrefresh(statuspane);
				i = 0;
				buf[i] = '\0';
				soft = NULL;
				break;
				
			case '':
			case '':
			case KEY_BACKSPACE:
				if ( soft ) {
					/* Delete soft line */
					wmove(statuspane, 0, offset);
					wclrtoeol(statuspane);
					wrefresh(statuspane);
					i = 0;
					buf[i] = '\0';
					soft = NULL;
					break;
				}
				if ( i > 0 ) {
					--i;
					wmove(statuspane, 0, offset+i);
					wclrtoeol(statuspane);
					for ( int j=i; buf[j]; ++j ) {
						buf[j] = buf[j+1];
						if ( buf[j] )
							waddch(statuspane, buf[j]);
					}
					wrefresh(statuspane);
				}
				break;

			case '\r':
				return(buf);

			default:
				if ( soft ) {
					/* Delete soft line */
					wmove(statuspane, 0, offset);
					wclrtoeol(statuspane);
					i = 0;
					buf[i] = '\0';
					soft = NULL;
				}
				if ( (i<maxi) && (i<buflen) ) {
					if ( buf[i] == '\0' ) {
						buf[i++] = ch;
						buf[i] = '\0';
					} else
						buf[i++] = ch;
					waddch(statuspane, ch);
					wrefresh(statuspane);
				}
				break;
		}
	}
	/* Never reached */
}

/* Screen manipulation */
void
Terminal:: redraw(void)
{
	clearok(pane, 1);
	touchwin(pane);
	wnoutrefresh(pane);
	if ( sub1 ) {
		touchwin(sub1);
		wnoutrefresh(sub1);
	}
	if ( sub2 ) {
		touchwin(sub2);
		wnoutrefresh(sub2);
	}
	touchwin(statuspane);
	wnoutrefresh(statuspane);
	doupdate();
}
void
Terminal:: clrpane(int updateit)
{
	wclear(curpane);
	if ( updateit )
		wrefresh(curpane);
}
void
Terminal:: clrscr(int updateit)
{
	wclear(curpane);
	wdeleteln(statuspane);
	if ( sub1 != NULL )
		wclear(sub1);
	if ( sub2 != NULL )
		wclear(sub2);

	if ( updateit )
		redraw();
}
void
Terminal:: lineup(int distance)
{
	int x, y;
	getyx(curpane, y, x);
	y -= distance;
	wmove(curpane, y, 0);
}
void
Terminal:: linedown(int distance)
{
	int x, y;
	getyx(curpane, y, x);
	y += distance;
	wmove(curpane, y, 0);
}
void
Terminal:: moveto(int x, int y)
{
	if ( x == 0 )
		x = 1;
	if ( y == 0 )
		y = 1;
	if ( x < 0 )
		x = (COLS+x+1);
	if ( y < 0 )
		y = (LINES+y+1);
	wmove(curpane, y-1, x-1);
}
void
Terminal:: movetostatus(int x)
{
	if ( x == 0 )
		x = 1;
	if ( x < 0 )
		x = (COLS+x+1);
	wmove(statuspane, 0, x-1);
}

/* System routines */
int
Terminal:: system(int waitforkey, char *fmt, ...)
{
	char command[BUFSIZ];
	va_list ap;
	int retval;
#ifdef SIGTSTP
	void (*oldaction)(int);
#endif

	va_start(ap, fmt);
	vsprintf(command, fmt, ap);

#ifdef SIGTSTP
	/* We don't want to hear terminal stop signal during system().
	   Curses will try to mess with the tty modes if it hears it.
	*/
	oldaction = signal(SIGTSTP, SIG_DFL);
#endif
	endwin();
	retval = ::system(command);
	if ( waitforkey ) {
		fprintf(stderr, "Press <Return> to continue: ");
		fgets(command, BUFSIZ-1, stdin);
	}
#ifdef SIGTSTP
	signal(SIGTSTP, oldaction);
#endif
	keypad(stdscr, TRUE);
	redraw();
	return(retval);
}

/* New window routines */
int
Terminal:: split(int SplitY)
{
	/* Create two subwindows for the split */
	splity = SplitY;
	sub1 = subwin(pane, splity, 0, 0, 0);
	sub2 = subwin(pane, lines()-splity-1, 0, splity, 0);

	/* Allow hardware scrolling and arrow keys */
	idlok(sub1, TRUE);
	scrollok(sub1, TRUE);
	keypad(sub1, TRUE);
	idlok(sub2, TRUE);
	scrollok(sub2, TRUE);
	keypad(sub2, TRUE);

	/* Set the current pane to the top one */
	return(selectpane(0));
}
int
Terminal:: selectpane(int which)
{
	if ( sub1 && (which == 0) ) {
		curpane = sub1;
		return(0);
	}
	if ( sub2 && (which == 1) ) {
		curpane = sub2;
		return(1);
	}
	return(-1);
}
void
Terminal:: unsplit(void)
{
	if ( sub1 ) {
		delwin(sub1);
		sub1 = NULL;
	}
	if ( sub2 ) {
		delwin(sub2);
		sub2 = NULL;
	}
	curpane = pane;
	splity = 0;
}
