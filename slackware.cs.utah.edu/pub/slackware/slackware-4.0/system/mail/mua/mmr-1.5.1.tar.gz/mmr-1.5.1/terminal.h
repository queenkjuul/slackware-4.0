
/* This class contains generic terminal update functions 

   This uses ncurses, but it should work okay with any curses implementation
   supporting subwin, wattron and the KEY_ definitions.
   Ironically, I wrote this from a SunOS curses manpage, but the Sun system
   didn't even have the functions in the manpage.  ncurses works great. :)
*/

#ifndef _terminal_h
#define _terminal_h

extern "C" {
#include <stdlib.h>
#include <stdarg.h>
#include <curses.h>
}

/* Note that screen coordinates start at (1,1) */

class Terminal {

public:
	Terminal(int makeraw = 1);
	~Terminal();

	/* Output routines */
	void flush(void) {
		wnoutrefresh(pane);
		if ( sub1 )
			wnoutrefresh(sub1);
		if ( sub2 )
			wnoutrefresh(sub2);
		wnoutrefresh(statuspane);
		doupdate();
	}
	void printf(char *fmt, ...);
	void status(int striking, char *fmt, ...);

	/* Input routines */
	int waitchar(WINDOW *the_win = NULL);
	void stuffch(int ch);
	int promptchar(int striking, char *fmt, ...);
	char *fillprompt(char *buf, int buflen, char *hard, char *autofill,
						char *(*complete)(char *));
	char *softprompt(char *buf, int buflen, char *hard, char *soft,
						char *(*complete)(char *));
	/* Timeout waiting for input (specified in 1/2 second intervals) */
	int setwait(int the_wait);

	/* Screen manipulation */
	void redraw(void);
	void clrpane(int updateit);
	void clrscr(int updateit);
	void clrscr(void) {
		clrscr(1);
	}
	void clreol(void) {
		wclrtoeol(curpane);
	}
	void lineup(int distance);
	void lineup(void) {
		lineup(1);
	}
	void linedown(int distance);
	void linedown(void) {
		linedown(1);
	}
	void moveto(int x, int y);
	void movetostatus(int x);
	void savexy(int *x, int *y) {
		getyx(curpane, *x, *y);
		++*x; ++*y;
	}
	void statusx(int *x) {
		int y;
		getyx(statuspane, *x, y);
		++*x;
	}
	void hilite(int setit) {
		if ( setit )
			wattron(curpane, A_STANDOUT);
		else
			wattroff(curpane, A_STANDOUT);
	}

	/* System routines */
	int system(int waitforkey, char *fmt, ...);
	int lines(void) {
		return(LINES);
	}
	int cols(void) {
		return(COLS);
	}
	/* The terminal is a tabula rosa after this. :) */
	int reset(void); void resizewin(void);

	/* New window routines */
	int split(int splity);
	int selectpane(int which);
	void unsplit(void);

private:
	static int refcount;
	static int wasraw;
	WINDOW    *pane;
	WINDOW    *sub1, *sub2, *curpane;
	WINDOW    *statuspane;
	int        splity;
	int	   MyRef;

	/* Interrupted I/O hacks */
	static int maxwait;
};

#endif /* _terminal_h */
