
#include <iostream.h>

extern "C" {
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include <string.h>
};

int main(int argc, char *argv[])
{
	while ( *(++argv) ) {
		struct stat sb;

		if ( stat(*argv, &sb) == 0 ) {
			cout << "Access time: " << ctime(&sb.st_atime) << flush;
			cout << "Modify time: " << ctime(&sb.st_mtime) << flush;
		} else {
			cerr << "Couldn't open " << *argv << ": " <<
						strerror(errno) << endl;
		}
	}
	return(0);
}
	
