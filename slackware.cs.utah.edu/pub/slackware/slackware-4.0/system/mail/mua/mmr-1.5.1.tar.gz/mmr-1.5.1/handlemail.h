
/* General mail handling functions entry point */

MIME_body *SelectPart(mailmsg **whichptr, MIME_body *body,
						Terminal *tty, int tty_height);

#define STATUS_BAR	0x80		/* Flag for updating the status bar */

extern int HandleMail(int command, mailmsg *which, MIME_body *body,
							Terminal *tty);
