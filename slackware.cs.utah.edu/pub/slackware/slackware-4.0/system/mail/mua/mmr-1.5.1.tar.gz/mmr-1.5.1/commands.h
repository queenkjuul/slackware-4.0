
/* Here is a standard set of logical commands */

enum cmd_token {
	/* The "Unknown" function */
	UNKNOWN,

	/* Navigation */
	QUIT, QUITALL,
	LINE_UP, LINE_DOWN, PAGE_UP, PAGE_DOWN,
	SEARCH_FORE, SEARCH_BACK, SEARCH_REP,
	MSG_INFO, MSG_VIEW, MSG_NEXT, GOTO_START, GOTO_END, GOTO_MSG,

	/* Mail commands */
	MSG_ORDER, MSG_DEL, MSG_UNDEL,
	MSG_REPLY, MSG_REPLYALL, MSG_SREPLY, MSG_FORWARD, MSG_NEW,
	MSG_SAVE, MSG_SAVEALL,

	/* General commands */
	REDRAW, HELP, SYSTEM
};

#define REDRAW_CMD	''			/* Don't remove this!! */

extern cmd_token KeyToCmd(int key);
