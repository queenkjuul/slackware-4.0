
/* Some default MIME types */
#define DEFAULT_TXT	"text/plain"
#define DEFAULT_BIN	"application/octet-stream"

/* The three major encoding types */
#define SEVEN_BIT	0
#define QUOTE_PRT	1
#define BASE64		2

/* Functions in mimetype.cc */
void Init_MIMEtypes(char *mimefile);
char * MIME_Type(char *filename);
char * MIME_Encoding(char *filename);
void Quit_MIMEtypes(void);
