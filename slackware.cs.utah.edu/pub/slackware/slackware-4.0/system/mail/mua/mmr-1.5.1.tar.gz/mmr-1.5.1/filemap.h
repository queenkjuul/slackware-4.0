
/* These functions allow you to memory map files -- very useful. :-) */

typedef struct {
	int fd;
	int size;
	char *rawfile;
	char **lines;
	int *linelens;
	int nlines;
} filemap;

extern filemap *MapFile(const char *filename, int flags, filemap *themap,
								int linewidth);
extern void     UnMapFile(filemap *themap);

