
extern "C" {
#include <sys/types.h>
#include <sys/time.h>
#include <signal.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <ctype.h>
}

#include "listing.h"
#include "commands.h"
#include "handlemail.h"
#include "helpfile.h"

char * Msg_Listing::separator = 
" ---------------------------------------------------------------------- ";

Msg_Listing:: Msg_Listing(IObottle *MailFile, mailmsg *Current)
{
	/* Very important variables. :) */
	mailfile = MailFile;
	lastshown = current = Current;

	/* Create the various virtual screens */
	listpane = new Terminal(1);
	infopane = new Terminal(1);
	viewpane = new Terminal(1);
	helppane = new Terminal(1);
	list_state = LIST_STATE;

	/* The dimensions of the listing */
	offset = 2;
	currow = 1;
	ReSize(0);

	/* Set formatting */
	IndentThread(0);
}

void
Msg_Listing:: ReSize(int modified = 1)
{
	if ( modified ) {
		helppane->reset();
		viewpane->reset();
		infopane->reset();
		listpane->reset();
		listpane->resizewin();
		infopane->resizewin();
		viewpane->resizewin();
		helppane->resizewin();
	}
	listpane->stuffch(REDRAW_CMD);

	/* Set up the screen sizes */
	width  = (listpane->cols()-1);
	height = (listpane->lines()-4);

	/* The listing fields :-) */
#ifdef SHOW_INDEX_DATE
	/* 15 (for flags / date) +4 (for index) +25 (for "from") +1 for edge */
	subject_len = listpane->cols()-(15+4+25)-1;

	sprintf(hdr_string, "   S  Date      #  %%-21.21s  %%-%d.%ds\n%s",
					subject_len, subject_len, separator);
	sprintf(fmt_string, " %%s %%c  %%s  %%3d  %%-21.21s  %%-%d.%ds",
					subject_len, subject_len);
#else
	/* 10 (for flags) + 26 (for "from") + 1 for edge */
	subject_len = listpane->cols()-(10+26)-1;

	sprintf(hdr_string, "   S  #   %%-23.23s  %%-%d.%ds\n%s",
					subject_len, subject_len, separator);
	sprintf(fmt_string, " %%s %%c %%3d  %%-23.23s  %%-%d.%ds",
					subject_len, subject_len);
#endif /* SHOW_INDEX_DATE */
}

Msg_Listing:: ~Msg_Listing()
{
	listpane->status(0, "");
	delete listpane;
	delete infopane;
	delete viewpane;
	delete helppane;
}

void
Msg_Listing:: Help(Terminal *tty)
{
	Terminal *oldview = viewpane;
	IObottle *helpfile;
	mailmsg  *helpmsg;

	/* Create a mini-mailfile of the help info */
	helpfile = new IObottle(help);
	if ( helpfile->fail() || helpfile->eof() ) {
		delete helpfile;
		return;
	}
	helpmsg = new mailmsg(helpfile, NULL);

	/* View the help file */
	viewpane = helppane;
	helppane = oldview;	/* So we clean up properly if interrupted */
	list_state |= HELP_STATE;
	View(helpmsg);
	list_state &= ~HELP_STATE;
	helppane = viewpane;
	viewpane = oldview;
	tty->redraw();

	/* Clean up */
	helpmsg->SetSave(0);
	delete helpmsg;
	delete helpfile;
}

/* This function handles optimized redrawing of the listing screen if
   message status has changed.

   Key:
	0:	No change
	1:	Refresh screen, check for changes
	0x80:	Redraw status bar
*/
int
Msg_Listing:: ListChanged(int showit)
{
	int redraw_bar = (showit & 0x80);
	int tty_changed;
	int x;
	int row;
	mailmsg *mesgptr;

	/* Move down if the current message was deleted */
	if ( current->Changed() ) {
		if ( (mesgptr=current->SkipDeleted(&row)) &&
						(mesgptr != current) ) {
			currow += row;
			if ( (currow < 1) || (currow > height) )
				++showit;
			current = mesgptr;
		}
	}

	/* Forced redraw? */
	if ( (showit&(~0x80)) != 0 ) {
		Show();
		return(height);
	}

	/* Redraw any messages that have changed */
	tty_changed = 0;

	/* Start at the top, work down */
	listpane->statusx(&x);
	for ( mesgptr = current->Prev(currow-1), row=1;
				mesgptr && (row <= height);
					++row, mesgptr=mesgptr->Next() )  {
		/* If there is a new current message, de-hilight the old */
		if ( current != lastshown ) {
			if ( mesgptr == lastshown ) {
				listpane->moveto(1, offset+row);
				listpane->clreol();
				ShowLine(mesgptr);
				mesgptr->NoChange();
				++tty_changed;
			}
			if ( mesgptr == current ) {
				listpane->moveto(1, offset+row);
				listpane->clreol();
				listpane->hilite(1);
				ShowLine(mesgptr);
				listpane->hilite(0);
				mesgptr->NoChange();
				++tty_changed;
			}
		}
		if ( mesgptr->Changed() ) {
			listpane->moveto(1, offset+row);
			listpane->clreol();
			if ( mesgptr == current ) {
				listpane->hilite(1);
				ShowLine(mesgptr);
				listpane->hilite(0);
			} else
				ShowLine(mesgptr);
			mesgptr->NoChange();
			++tty_changed;
		}
	}
	if ( tty_changed ) {
		listpane->movetostatus(x);
		listpane->flush();
		lastshown = current;
	}

	if ( redraw_bar )
		ListStatus();

	return(tty_changed);
}

mailmsg *
Msg_Listing:: TabJump(mailmsg *which)
{
	mailmsg *newmsg;

	/* Search for new message here */
	if ( (newmsg=which->Next()) && (newmsg=newmsg->ByStatus("N")) )
		return(newmsg);
	/* Search for "old" message here */
	if ( (newmsg=which->Next()) && (newmsg=newmsg->ByStatus("O")) )
		return(newmsg);
	return(NULL);
}

mailmsg *
Msg_Listing:: Goto_Msg(int key, mailmsg *which)
{
	char num_buf[BUFSIZ];
	char softbuf[2] = { '\0', '\0' };

	/* Start it off.. */
	if ( isdigit((char)key) )
		softbuf[0] = (char)key;

	/* Find out which number to goto */
	listpane->fillprompt(num_buf, BUFSIZ, "Goto message: ", softbuf, NULL);

	/* User cancelled */
	if ( num_buf[0] == '\0' )
		return(which);

	return(which->ByIndex(atoi(num_buf)));
}

char *Msg_Listing::last_pattern = NULL;
int   Msg_Listing::last_sdirect = 0;
void
Msg_Listing:: SavePattern(char *pattern)
{
	char *newpattern;

	/* Copy the successful pattern */
	newpattern = new char[strlen(pattern)+1];
	strcpy(newpattern, pattern);

	/* Get rid of any left over pattern */
	if ( last_pattern != NULL )
		delete[] last_pattern;
	last_pattern = newpattern;
	return;
}

mailmsg *
Msg_Listing:: SearchList(int direction, mailmsg *which, MIME_body **bodyptr,
								char *pattern)
{
	MIME_body *body;
	char buffer[BUFSIZ];
	int   mlen;
	mailmsg *matched;

	*bodyptr = NULL;
	if ( pattern == NULL ) {
		if ( direction > 0 ) {
			listpane->softprompt(buffer, BUFSIZ,
				"Search forward for: ", last_pattern, NULL);
		} else {
			listpane->softprompt(buffer, BUFSIZ,
				"Search backward for: ", last_pattern, NULL);
		}
		if ( buffer[0] == '\0' )
			return(which);
		pattern = buffer;
	}

	/* Search in the From and Subject lines of the messages */
	last_sdirect = direction;
	if ( direction > 0 ) {
		/* Search to end of messages */
		for (matched=which->Next(); matched; matched=matched->Next()) {
			if ( match_nocase((char *)matched->GetField("From"),
							pattern, &mlen) )
				break;
			if ( match_nocase((char *)matched->GetField("Subject"),
							pattern, &mlen) )
				break;
		}
		if ( matched ) {
			SavePattern(pattern);
			return(matched);
		}

		/* Wrap around and continue searching */
		listpane->status(0, " Wrapping...");
		matched = which->ByIndex(1);
		while ( matched != which ) {
			if ( match_nocase((char *)matched->GetField("From"),
							pattern, &mlen) )
				break;
			if ( match_nocase((char *)matched->GetField("Subject"),
							pattern, &mlen) )
				break;
			matched = matched->Next();
		}
		if ( matched != which ) {
			SavePattern(pattern);
			return(matched);
		}
	} else {
		/* Search to beginning of messages */
		for (matched=which->Prev(); matched; matched=matched->Prev()) {
			if ( match_nocase((char *)matched->GetField("From"),
							pattern, &mlen) )
				break;
			if ( match_nocase((char *)matched->GetField("Subject"),
							pattern, &mlen) )
				break;
		}
		if ( matched ) {
			SavePattern(pattern);
			return(matched);
		}

		/* Wrap around and continue searching */
		listpane->status(0, " Wrapping...");
		matched = which->Last();
		while ( matched != which ) {
			if ( match_nocase((char *)matched->GetField("From"),
							pattern, &mlen) )
				break;
			if ( match_nocase((char *)matched->GetField("Subject"),
							pattern, &mlen) )
				break;
			matched = matched->Prev();
		}
		if ( matched != which ) {
			SavePattern(pattern);
			return(matched);
		}
	}

	/* Check the current message */
	if ( match_nocase((char *)which->GetField("From"), pattern, &mlen) ||
	     match_nocase((char *)which->GetField("Subject"), pattern, &mlen) )
	{
		SavePattern(pattern);
		return(which);
	}

	/* No match, try again, going through the text */
	if (listpane->promptchar(0, "No match -- Search text? [yN]: ") != 'y')
		return(which);
	
	if ( direction > 0 ) {
		/* Search to end of messages */
		listpane->status(0, " Searching to bottom...");
		for (matched=which; matched; matched=matched->Next()) {
			if ( (body=(matched->Body())->Search(pattern)) )
				break;
		}
		if ( matched ) {
			SavePattern(pattern);
			*bodyptr = body;
			return(matched);
		}

		/* Wrap around and continue searching */
		listpane->status(0, " Searching from top...");
		matched = which->ByIndex(1);
		while ( matched != which ) {
			if ( (body=(matched->Body())->Search(pattern)) )
				break;
			matched = matched->Next();
		}
		if ( matched != which ) {
			SavePattern(pattern);
			*bodyptr = body;
			return(matched);
		}
	} else {
		/* Search to beginning of messages */
		listpane->status(0, " Searching to top...");
		for (matched=which; matched; matched=matched->Prev()) {
			if ( (body=(matched->Body())->Search(pattern)) )
				break;
		}
		if ( matched ) {
			SavePattern(pattern);
			*bodyptr = body;
			return(matched);
		}

		/* Wrap around and continue searching */
		listpane->status(0, " Searching from bottom...");
		for (matched=which; matched->Next(); matched=matched->Next());
		matched = which->Last();
		while ( matched != which ) {
			if ( (body=(matched->Body())->Search(pattern)) )
				break;
			matched = matched->Prev();
		}
		if ( matched != which ) {
			SavePattern(pattern);
			*bodyptr = body;
			return(matched);
		}
	}

	/* No match.. */
	listpane->status(0, " -- No Match --");
	sleep(1);
	return(which);
}

void
Msg_Listing:: RunMain(mailmsg *(*checkmail)(mailmsg *, Terminal *, int *))
{
	mailmsg *newmsg;
	int changed = 0;

	CheckMail = checkmail;
	main_done = 0;
	while ( ! main_done ) {
		int key, cmd;

		list_state = LIST_STATE;

		/* Check for NEW mail! :) */
		if ( (newmsg=(*CheckMail)(current, listpane, &changed))
								!= current ) {
			if ( (current = newmsg) == NULL ) {
				main_done = 1;
				continue;
			}
		}

		/* Redraw portions of the screen that have changed */
		ListChanged(changed);
		changed = 0;

		/* Wait for 10 seconds for input before checking mail. :) */
		listpane->setwait(10*2);
		key = listpane->waitchar();
		listpane->setwait(0);

		switch ((cmd=KeyToCmd(key))) {
			case REDRAW:
				++changed;
				break;
			case QUIT:
				if ( (key != 'q') && 
					(*ThreadSpecial(current) == '>') ) {
					current->ShowThreads(HIDE_THREADS);
					++changed;
					break;
				}
				if ( listpane->promptchar(0,
						"Really quit? [Yn]: ") == 'n' )
					ListStatus();
				else
					main_done = 1;
				break;
			case QUITALL:
				main_done = 1;
				break;
			case GOTO_START:
				while ( (newmsg=current->Prev()) )
					current = newmsg;
				++changed;
				break;
			case GOTO_END:
				while ( (newmsg=current->Next()) )
					current = newmsg;
				++changed;
				break;
			case GOTO_MSG:
				if ((newmsg=Goto_Msg(key, current)) != current){
					current = View(newmsg);
					++changed;
				} else {
					changed |= STATUS_BAR;
				}
				break;
			case SEARCH_FORE: {
				MIME_body *intext;
				newmsg=SearchList(1, current, &intext, NULL);
				if ( intext ) {
					current=View(newmsg, intext);
					++changed;
				} else if ( newmsg != current) {
					current = newmsg;
					++changed;
				} else {
					changed |= STATUS_BAR;
				}
				} break;
			case SEARCH_BACK: {
				MIME_body *intext;
				newmsg=SearchList(-1, current, &intext, NULL);
				if ( intext ) {
					current=View(newmsg, intext);
					++changed;
				} else if ( newmsg != current) {
					current = newmsg;
					++changed;
				} else {
					changed |= STATUS_BAR;
				}
				} break;
			case SEARCH_REP: {
				MIME_body *intext;

				if ( last_pattern == NULL )
					break;

				newmsg=SearchList(last_sdirect, current,
							&intext, last_pattern);
				if ( intext ) {
					current=View(newmsg, intext);
					++changed;
				} else if ( newmsg != current) {
					current = newmsg;
					++changed;
				} else {
					changed |= STATUS_BAR;
				}
				} break;
			case LINE_UP:
				if ( (newmsg=current->Prev()) ) {
					current = newmsg;
					--currow;
					if ( currow <= 0 ) {
						++changed;
					} else {
						changed |= STATUS_BAR;
					}
				}
				break;
			case LINE_DOWN:
				if ( (newmsg=current->Next()) ) {
					current = newmsg;
					++currow;
					if ( currow > height ) {
						++changed;
					} else {
						changed |= STATUS_BAR;
					}
				}
				break;
			case PAGE_UP:
				current = current->Prev(height);
				++changed;
				break;
			case PAGE_DOWN:
				current = current->Next(height);
				++changed;
				break;
			case MSG_INFO:
				Info(current);
				++changed;
				break;
			case MSG_VIEW:
				if ( *ThreadSpecial(current) == '*' ) {
					current->ShowThreads(SHOW_THREADS);
					++changed;
					break;
				}
				if ( (newmsg=View(current)) != current )
					current = newmsg;
				++changed;
				break;
			case MSG_NEXT:
				if ( (newmsg=TabJump(current)) ) {
					current = View(newmsg);
					++changed;
				}
				break;
			case MSG_ORDER: {
				int sort_mode;
				switch (listpane->promptchar(0,
			"Sort by [a]uthor, [s]ubject, or [N]either? ")) {
					case 'a':
						sort_mode = SORTBY_AUTHOR;
						break;
					case 's':
						sort_mode = SORTBY_SUBJECT;
						break;
					case 'n':
					default:
						sort_mode = SORTBY_NOTHING;
						break;
				}
				listpane->status(0, "Sorting...");
				OrderBy(current, sort_mode);
				++changed;
				}
				break;
			case HELP:
				Help(listpane);
				break;
			case UNKNOWN:
				/* Handle listing specific commands */
				switch (key) {
					case 0:
					/* Mailcheck timeout - handled above */
						break;
					/* Toggle threading with ^T */
					case '':
						if ( current->ShowThreads() == NO_THREADS )
							current->ShowThreads(SHOW_THREADS);
						else
							current->ShowThreads(NO_THREADS);
						++changed;
						break;
					default:
						break;
				}
				break;
			default:
				if ( HandleMail(cmd, current, NULL, listpane)
								& STATUS_BAR ) {
					changed |= STATUS_BAR;
				}
				break;
		}
	}
	return;
}

void
Msg_Listing:: Show(void)
{
	char buffer[1024];
	int  linesleft;

	/* Print banner */
	listpane->clrscr(0);
	listpane->moveto(1,1);
	listpane->printf(hdr_string, "From", "Subject");
	listpane->moveto(1, -2);
	listpane->printf(separator);
	listpane->moveto(1, offset+1);

	/* Print the listing of messages */
	linesleft = height;
	mailmsg *mesgptr = current->Prev(linesleft/2);
	while ( linesleft-- && mesgptr ) {
		/* Print the header line */
		if ( mesgptr == current ) {
			currow = (height-linesleft);
			listpane->hilite(1);
			ShowLine(mesgptr);
			listpane->hilite(0);
		} else
			ShowLine(mesgptr);
		mesgptr->NoChange();

		/* Go to next message */
		listpane->linedown();
		mesgptr = mesgptr->Next();
	}
	lastshown = current;
	listpane->flush();
	ListStatus();
}

void
Msg_Listing:: ListStatus(void)
{
	listpane->status(0, "Loaded %d messages (%d): ",
				current->NumMessages(), current->Index());
}

static int PrintField(Terminal *window, char *name, char *value, int extralines)
{
	int  width, i;
	int  prefix;
	int  linelen;
	char fmt[128];

	/* Figure out how long the prefix is */
	width = window->cols();
	linelen = width-(1+strlen(name)+strlen(":  "));
	if ( linelen < 0 )
		return(extralines);

	/* Print the first part of the string */
	sprintf(fmt, " %%s:  %%.%ds", linelen);
	window->printf(fmt, name, value);
	if ( strlen(value) > linelen ) {
		sprintf(fmt, "%%.%ds", width);
		value += linelen;
		while ( *value && extralines-- ) {
			if ( extralines == 0 ) {
				sprintf(fmt, "%%.%ds...", width-3-1);
				window->printf(fmt, value);
			} else {
				window->printf(fmt, value);
				value += (strlen(value) > width) ?
							width : strlen(value);
			}
		}
	}
	return(extralines);
}
void
Msg_Listing:: Info(mailmsg *which)
{
	char *fields[] = {
		"Date", "Sender", "From", "Reply-To",
		"To", "Cc", "Subject",
		"Mime-Version", NULL
	};
	char *field, *field_data;
	mailmsg *newmsg;
	int      i, lines;
		
	infopane->clrscr(0);
	infopane->moveto(1,1);
	infopane->printf(separator);
	infopane->linedown();

	/* Calculate the number of lines we have available */
	lines = infopane->lines()-3-1;
	for ( which->GetHeader(NULL); which->GetHeader(&field); ) {
		if (strncasecmp(field, "Content-", strlen("Content-")) == 0) {
			--lines;
			continue;
		}
		if (strncasecmp(field, "X-", strlen("X-")) == 0) {
			--lines;
			continue;
		}
		for ( i=0; fields[i]; ++i ) {
			if ( strcmp(field, fields[i]) == 0 ) {
				--lines;
				break;
			}
		}
	}
	if ( lines < 0 )
		lines = 0;

	/* Print specific fields */
	for ( i=0; fields[i]; ++i ) {
		field_data = (char *)which->GetField(fields[i]);
		if ( field_data ) {
			lines = PrintField(infopane, fields[i], field_data,
									lines);
			infopane->linedown();
		}
	}
	/* Print extra MIME fields */
	for ( which->GetHeader(NULL);
			(field_data=(char *)which->GetHeader(&field)); ) {
		if (strncasecmp(field, "Content-", strlen("Content-")) == 0) {
			lines = PrintField(infopane, field, field_data, lines);
			infopane->linedown();
		}
	}
	/* Now print the extension fields */
	for ( which->GetHeader(NULL);
			(field_data=(char *)which->GetHeader(&field)); ) {
		if (strncasecmp(field, "X-", strlen("X-")) == 0) {
			lines = PrintField(infopane, field, field_data, lines);
			infopane->linedown();
		}
	}
	infopane->printf(separator);
	infopane->linedown();
	infopane->flush();

	listpane->waitchar();
}

#define VIEW_HLINES	5
#define VIEW_PLINES	(viewpane->lines()-(VIEW_HLINES+1))

void
Msg_Listing:: ViewHeader(mailmsg *which)
{
	char *fields[] = {
		"Date", "From", "To", "Subject", NULL
	};
	int i;

	/* Print the header */
	viewpane->selectpane(0);
	viewpane->moveto(1, 1);
	for ( i=0; fields[i]; ++i ) {
		const char *field_data = which->GetField(fields[i]);
		if ( field_data ) {
			char  fmt[24];
			char *ptr;
			int   len, maxlen;

			/* Tabs take an extra 7 spaces */
			maxlen = width-strlen(fields[i])-2-1;
			for ( len = 0, ptr = (char *)field_data; 
					(len < maxlen) && *ptr; ++ptr ) {
				if ( *ptr == '\t' )
					len = ((len/8)+1)*8;
				else
					++len;
			}
			sprintf(fmt,"%%s: %%.%ds", len);
			viewpane->printf(fmt, fields[i], field_data);
			viewpane->linedown();
		}
	}
	while ( (i++) < 4 )
		viewpane->linedown();
		
	viewpane->hilite(1);
	{  /* Print the message header bar */
		mailmsg *mesgptr;
		char     buffer[BUFSIZ];
		int      bufferlen;
		int      width_left;

		bufferlen = 0;
		sprintf(buffer, "-- Message: %d %c ",
					which->Index(), *(which->Status()));
		bufferlen = strlen(buffer);
		if ( (mesgptr=which->Next()) ) {
			sprintf(&buffer[bufferlen], "--  Next: %d %c ",
					mesgptr->Index(), *(mesgptr->Status()));
			bufferlen = strlen(buffer);
		}
		if ( (width_left=which->ThreadSize()) > 0 ) {
			int index = (which->ThreadIndex()+1);
			sprintf(&buffer[bufferlen],
				"--  (%d/%d) in thread  ",
						index, index+width_left-1);
			bufferlen = strlen(buffer);
		}
		width_left = (width-bufferlen-1);
		while ( (width_left--) > 0 )
			buffer[bufferlen++] = '-';
		buffer[bufferlen] = '\0';
		viewpane->printf("%s", buffer);
	}
	viewpane->hilite(0);
	viewpane->selectpane(1);
}

int
Msg_Listing:: ViewPage(filemap *fmap, int offset, int distance, int clearit)
{
	/* Don't show what isn't there :-) */
	if ( (offset < 0) || (offset >= fmap->nlines) )
		return(-1);

	if ( clearit ) {
		viewpane->clrpane(0);
	}
	/* View the text */
	for ( ; fmap->lines[offset] && distance; ++offset, --distance ) {
		char fmt[24];
		if ( *(fmap->lines[offset]+fmap->linelens[offset]) == '\n' ) {
			sprintf(fmt, "\n%%.%ds", fmap->linelens[offset]);
		} else {
			sprintf(fmt, "\n%%.%ds\\", fmap->linelens[offset]);
		}
		viewpane->printf(fmt, fmap->lines[offset]);
	}
	viewpane->flush();
	return(offset);
}

int   Msg_Listing::last_vdirect = 1;
int
Msg_Listing:: matchline(filemap *fmap, int offset, char *pattern)
{
	char *line;
	char *dptr, *max;
	int   linelen;
	int   dlen;
	char *matched;

	/* Find the end of the line */
	dptr = line = fmap->lines[offset];
	max = (fmap->lines[fmap->nlines-1]+fmap->linelens[fmap->nlines-1]);
	for ( linelen = 0; (dptr < max) && (*dptr != '\n'); ++dptr, ++linelen );

	/* Copy it in */
	dptr = new char[linelen+1];
	memcpy(dptr, line, linelen);
	dptr[linelen] = '\0';

	/* Do we have a match? */
	matched = match(dptr, pattern, &dlen);
	delete[] dptr;
	return(matched ? 1 : 0);
}
int
Msg_Listing:: SearchView(int direction, filemap *fmap, int offset,
								char *pattern)
{
	char buffer[BUFSIZ];
	int  found;

	/* Make sure we have a pattern */
	if ( pattern == NULL ) {
		if ( direction > 0 ) {
			listpane->softprompt(buffer, BUFSIZ,
				"Search forward for: ", last_pattern, NULL);
		} else {
			listpane->softprompt(buffer, BUFSIZ,
				"Search backward for: ", last_pattern, NULL);
		}
		if ( buffer[0] == '\0' )
			return(offset);
		pattern = buffer;
	}

	last_vdirect = direction;
	if ( direction > 0 ) {
		/* Search to end of message */
		for ( found=(offset+1); fmap->lines[found]; ++found ) {
			if ( matchline(fmap, found, pattern) )
				break;
		}
		if ( fmap->lines[found] ) {
			SavePattern(pattern);
			return(found);
		}

		/* Wrap around and continue searching */
		listpane->status(0, " Wrapping...");
		sleep(1);
		for ( found=0; found <= offset; ++found ) {
			if ( matchline(fmap, found, pattern) )
				break;
		}
		if ( found <= offset ) {
			SavePattern(pattern);
			return(found);
		}
	} else {
		/* Search to beginning of messages */
		for ( found=(offset-1); found >= 0; --found ) {
			if ( matchline(fmap, found, pattern) )
				break;
		}
		if ( found >= 0 ) {
			SavePattern(pattern);
			return(found);
		}

		/* Wrap around and continue searching */
		listpane->status(0, " Wrapping...");
		sleep(1);
		for ( found=(fmap->nlines-1); found >= offset; --found ) {
			if ( matchline(fmap, found, pattern) )
				break;
		}
		if ( found >= offset ) {
			SavePattern(pattern);
			return(found);
		}
	}
	/* No match.. */
	viewpane->status(0, " -- No Match --");
	sleep(1);
	return(offset);
}

/* We can change messages within this level, so return the message
   that we finish with.  We view new messages serially instead of
   recursing, just to prevent using stack space.  gotos can be useful. :)
*/
#define VIEWNEW(newmsg)	(*whichptr = newmsg, view_done = 1)

MIME_body *
Msg_Listing:: ViewBody(mailmsg **whichptr, MIME_body *oldbody)
{
	mailmsg   *which = *whichptr;
	MIME_body *body;
	filemap    fmap;
	mailmsg   *newmsg;

	/* Show the header */
	viewpane->clrscr(0);
	ViewHeader(which);

	/* Select and open the body of the message */
	body = SelectPart(whichptr, oldbody ? oldbody : which->Body(),
						viewpane, VIEW_PLINES-1);

	/* Open and print the body of the message */
	if ( body ) {
		int     offset;
		int     shown, lastline;
		int     view_done = 0;
		char   *bodyfile;
		
		/* Open and memory map the file */
		bodyfile = body->File();
		if (MapFile(bodyfile, PROT_READ, &fmap, width-1) == NULL) {
			viewpane->printf(
				"ERROR: Couldn't memory map %s\n", bodyfile);
			viewpane->waitchar();
			body->FreeFile();
			return(NULL);
		}

		/* Set up for viewing */
		lastline = offset = 0;
		lastline = ViewPage(&fmap, offset, VIEW_PLINES, 1);
		while ( ! view_done ) {
			int key, cmd;

			if ( (offset+VIEW_PLINES) < fmap.nlines ) {
				key = viewpane->promptchar(1,
	"Line (%d/%d)  Press <space> for more, or press 'q' to quit: ",
						lastline, fmap.nlines);
			} else { 
				key = viewpane->promptchar(1,
	"Line (%d/%d)  Press 'q' to quit: ",
						lastline, fmap.nlines);
			}
			switch ((cmd=KeyToCmd(key))) {
				case REDRAW:
					/* Check for NEW mail! :) */
					if ((newmsg=(*CheckMail)(which,
						viewpane, NULL)) != which) {
						if ( newmsg == NULL ) {
							view_done = 1;
							main_done = 1;
							break;
						}
						VIEWNEW(newmsg);
					} else {
						ViewHeader(which);
						lastline = ViewPage(&fmap,
							offset, VIEW_PLINES, 1);
					}
					break;
				case QUIT:
					/* Semantics:
					    Pop to prev message if we are in a
					    thread, otherwise to the listing!
					*/
					if ( (key == KEY_LEFT) &&
							which->ThreadIndex() &&
							(newmsg=which->Prev())){
						*whichptr = newmsg;
					}
					view_done = 1;
					break;
				case QUITALL:
					main_done = 1;
					view_done = 1;
					break;
				case GOTO_START:
					lastline = offset = 0;
					lastline = ViewPage(&fmap, offset, VIEW_PLINES, 1);
					break;
				case GOTO_END:
					lastline = ViewPage(&fmap, fmap.nlines-VIEW_PLINES, VIEW_PLINES, 1);
					if ( (lastline-VIEW_PLINES) >= 0 )
						offset = (lastline-VIEW_PLINES);
					break;
				case SEARCH_FORE: {
					int newoff;
					if ((newoff=SearchView(1,&fmap,offset,NULL)) != offset) {
						if ( (shown=ViewPage(&fmap, newoff, VIEW_PLINES, 1)) >= 0 ) {
							lastline = shown;
							offset = newoff;
						}
					}
					} break;
				case SEARCH_BACK: {
					int newoff;
					if ((newoff=SearchView(-1,&fmap,offset,NULL)) != offset) {
						if ( (shown=ViewPage(&fmap, newoff, VIEW_PLINES, 1)) >= 0 ) {
							lastline = shown;
							offset = newoff;
						}
					}
					} break;
				case SEARCH_REP: {
					int newoff;

					if ( last_pattern == NULL )
						break;

					if ((newoff=SearchView(last_vdirect,&fmap,offset,last_pattern)) != offset) {
						if ( (shown=ViewPage(&fmap, newoff, VIEW_PLINES, 1)) >= 0 ) {
							lastline = shown;
							offset = newoff;
						}
					}
					} break;
				case LINE_UP:
					if ( (shown=ViewPage(&fmap, offset-1, VIEW_PLINES, 1)) >= 0 ) {
						lastline = shown;
						offset -= 1;
					}
					break;
				case LINE_DOWN:
					if ( (shown=ViewPage(&fmap, lastline, 1)) >= 0 ) {
						lastline = shown;
						offset += 1;
					}
					break;
				case PAGE_UP: {
					int loffset = (VIEW_PLINES-1);
					if ( (offset-loffset) < 0 )
						loffset = offset;
					if ( (shown=ViewPage(&fmap, offset-loffset, VIEW_PLINES)) >= 0 ) {
						lastline = shown;
						offset -= loffset;
					}
					} break;
				case PAGE_DOWN:
					if ( (shown=ViewPage(&fmap, offset+VIEW_PLINES, VIEW_PLINES-1)) >= 0 ) {
						offset += (shown-lastline);
						lastline = shown;
					}
					break;
				case MSG_INFO:
					Info(which);
					viewpane->redraw();
					break;
				case MSG_VIEW:
					if ( (newmsg=which->Next()) != NULL )
						VIEWNEW(newmsg);
					else
						view_done = 1;
					break;
				case MSG_NEXT:
					if ( (newmsg=TabJump(which)) )
						VIEWNEW(newmsg);
					break;
				case HELP:
					if ( ! (list_state&HELP_STATE) )
						Help(viewpane);
					break;
				case UNKNOWN:
					/* Handle listing specific commands */
					switch (key) {
						/* Toggle header with 'H' */
						case 'H':
							break;
						default:
							break;
					}
					break;
				default:
					(void) HandleMail(cmd, which, body,
								viewpane);
					break;
			}

			/* Handle change here */
			if ( which->Changed() ) {
				which->NoChange();
				if ((newmsg=which->SkipDeleted(NULL)) != NULL){
					if ( newmsg == which ) {
						ViewHeader(which);
						viewpane->flush();
					} else
						VIEWNEW(newmsg);
				} else {
					view_done = 1;
				}
			}
		}
		UnMapFile(&fmap);
		body->FreeFile();
	}

	/* We're done! */
	if ( main_done )
		return(NULL);
	if ( body )
		return(body->Parent());
	if ( oldbody )
		return(oldbody->Parent());
	return(NULL);
}

mailmsg *
Msg_Listing:: View(mailmsg *which, MIME_body *body = NULL)
{
	mailmsg   *newmsg, *holder;

	/* Get ready... */
	list_state |= VIEW_STATE;	/* Prevent recursive View()'s */
	viewpane->split(VIEW_HLINES);

	holder = which;
	do {
		/* This triggers if ViewBody() changed our current message */
		if ( holder != which ) {
			which = holder;
			if ( ! which ) {
				main_done = 1;
				break;
			}
			body = NULL;
		}

		/* Whenever we view a message, we must first check if the
		   mailbox has changed, so we don't view a corrupt mailfile
		*/
		if ((newmsg=(*CheckMail)(which, viewpane, NULL)) != which) {
			if ( newmsg == NULL ) {
				main_done = 1;
				break;
			}
			holder = which = newmsg;
			body = NULL;
		}

		/* Read the message */
		body = ViewBody(&holder, body);

		/* Mark the message READ */
		if ( *which->Status() != 'D' )
			which->Status("R");

		/* Continue while new message, or more body parts */
	} while ( (which != holder) || body );

	/* Clean up... */
	viewpane->unsplit();
	list_state &= ~VIEW_STATE;
	return(which);
}

/* Listing sort stuff */
static int MesgSortByIndex(const void *A, const void *B)
{
	mailmsg *a = *(mailmsg **)A;
	mailmsg *b = *(mailmsg **)B;
	return(a->Index() - b->Index());
}
static int MesgSortByAuthor(const void *A, const void *B)
{
	mailmsg *a = *(mailmsg **)A;
	mailmsg *b = *(mailmsg **)B;
	char buf_a[BUFSIZ], buf_b[BUFSIZ];
	return(strcmp(a->FromName(buf_a,BUFSIZ), b->FromName(buf_b,BUFSIZ)));
}
static int MesgSortBySubject(const void *A, const void *B)
{
	mailmsg *a = *(mailmsg **)A;
	mailmsg *b = *(mailmsg **)B;
	return(strcmp(a->Subject_Key(), b->Subject_Key()));
}
int (*Msg_Listing::orderers[NUMSORTS])(const void *A, const void *B) = {
	MesgSortByIndex, MesgSortByAuthor, MesgSortBySubject
};

void
Msg_Listing:: OrderBy(mailmsg *which, int sortorder)
{
	mailmsg **messages, *mesgptr, *tmpptr;
	int    i, nmessages;

	/* Check the bounds of the sorting order */
	if ( (sortorder < 0) || (sortorder > (NUMSORTS-1)) )
		return;

	/* Allocate an array of the suckers */
	nmessages = which->NumMessages();
	messages = new mailmsg *[nmessages];
	/* Grab start of messages */
	for ( mesgptr = which; (tmpptr=mesgptr->Prev()); mesgptr = tmpptr );
	/* Stuff them into the array */
	for ( i = 0; i < nmessages; ++i, mesgptr = mesgptr->Next() )
		messages[i] = mesgptr;

	/* Sort it. :-) */
	qsort(messages, nmessages, sizeof(mailmsg *), orderers[sortorder]);

	/* Notify the messages that they've been sorted. :) */
	for ( i = 0; i < nmessages; ++i ) {
		if ( i == 0 )
			messages[i]->SetPrev(NULL);
		else
			messages[i]->SetPrev(messages[i-1]);
		if ( i == (nmessages-1) )
			messages[i]->SetNext(NULL);
		else
			messages[i]->SetNext(messages[i+1]);
	}
	/* We're done!  That's it! :) */
	delete[] messages;
}

