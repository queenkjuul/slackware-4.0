
/* This module handles the more generic mail functions -- replying,
   saving to disk, etc...
*/

extern "C" {
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <string.h>
};

#include "headers.h"
#include "iobottle.h"
#include "terminal.h"
#include "mailmsg.h"
#include "outgoing.h"
#include "commands.h"

#include "handlemail.h"

extern MIME_body *startup;

/* Global variables used by the mail system */
#define DEFAULT_MBOX	"~/mail/general.mail"
static char *default_mbox = NULL;
static char *default_to = NULL;
static char *system_cmd = NULL;


/* Some helper routines for HandleMail() */
static void StatusOne(mailmsg *which, char *status)
{
	if ( *which->Status() != *status ) {
		which->Status(status);
	}
}
static void StatusThread(mailmsg *which, char *status)
{
	/* Back up the thread */
	while ( which->ThreadIndex() > 0 ) {
		which = which->Prev();
	}
	do {
		StatusOne(which, status);
	} while ( which = which->ThreadNext() );
}

/* Perform file completion on a partial pathname
   Currently, this function returns the first possible matching file.
 */
char *file_complete(char *sofar)
{
	static char buffer[BUFSIZ];
	char  newbuf[BUFSIZ];
	struct stat sb;
	DIR  *dir = NULL;
	struct dirent *entry;
	char *dir_str, *file_str;
	int             file_len;

	/* Set up initial pointers */
	strcpy(buffer, sofar);

	/* Home directory completion */
	if ( (strncmp(buffer, "~", 1) == 0) && (dir_str=getenv("HOME")) ) {
		file_str = &buffer[1];
		if ( *file_str != '\0' ) {
			if (  *file_str != '/' ) {
				/* Um, Don't do other people's homes */
				if ( (file_str=strchr(buffer, '/')) == NULL )
					file_str = "/";
			}
			++file_str;
		}
		sprintf(newbuf, "%s/%s", dir_str, file_str);
		strcpy(buffer, newbuf);
	}
	dir_str = buffer;

	/* Default to current directory */
	if ( (file_str=strrchr(dir_str, '/')) == NULL ) {
		sprintf(newbuf, "./%s", dir_str);
		strcpy(dir_str, newbuf);
		file_str = dir_str+1;
	}

	/* Separate file from directory */
	*file_str = '\0';
	if ( *dir_str )
		strcpy(newbuf, dir_str);
	else
		strcpy(newbuf, "/");
	dir_str = newbuf;
	*(file_str++) = '/';

	/* Return just the directory, if there's no partial file */
	if ( ! *file_str )
		return(buffer);

	/* Open the directory */
	if ( (dir=opendir(*dir_str ? dir_str : "/")) == NULL ) {
		return(buffer);
	}

	/* Poke through it for the closest match */
	file_len = strlen(file_str);
	while ( (entry=readdir(dir)) ) {
		/* Hide "dot" files */
		if ( *entry->d_name == '.' )
			continue;

		if ( strncmp(entry->d_name, file_str, file_len) == 0 ) {
			strcpy(file_str, entry->d_name);
			break;
		}
	}
	closedir(dir);

	/* See if what we have is a directory */
	if ( (buffer[strlen(buffer)-1] != '/') && (stat(buffer, &sb) == 0) ) {
		if ( S_ISDIR(sb.st_mode) )
			strcat(buffer, "/");
	}
	return(buffer);
}

static char *PromptFile(char *file, Terminal *tty)
{
	char *home;
	char *buffer = new char[BUFSIZ];

	/* Perform tilde de-expansion and get filename */
	if ( file && (home=getenv("HOME")) &&
				(strncmp(file, home, strlen(home)) == 0) ) {
		char *newfile = new char[strlen(file)-strlen(home)+1+1];
		newfile[0] = '~';
		strcpy(&newfile[1], file+strlen(home));
		tty->softprompt(buffer, BUFSIZ, "Enter File: ", newfile,
								file_complete);
		delete[] newfile;
	} else {
		tty->softprompt(buffer, BUFSIZ, "Enter File: ", file,
								file_complete);
	}
	/* Perform tilde re-expansion */
	if ( *buffer == '~' ) {
		char *home, *expanded;
		if ( (buffer[1] != '/') || ((home=getenv("HOME")) == NULL) ) {
			tty->status(0, "Bad tilde expansion");
			tty->waitchar();
			buffer[0] = '\0';
		} else {
			expanded = new char[strlen(home)+strlen(buffer)];
			sprintf(expanded, "%s/%s", home, buffer+2);
			delete[] buffer;
			buffer = expanded;
		}
	}
	return(buffer);
}

/* This routine uses rules in the startup file to determine a default mailbox
   for a particular message.
*/
struct possibility {
	char *key;
	char *value;
};
static int SortPossibleByKey(const void *A, const void *B)
{
	const struct possibility *a = *(struct possibility **)A;
	const struct possibility *b = *(struct possibility **)B;
	return(strcmp(a->key, b->key));
}
static char *GetValue(char *str, char **A, char *sep, char **B)
{
	char *val1, *val2;

	/* Suck up first value */
	while ( *str && isspace(*str) )
		++str;
	if ( *str == '"' ) {
		val1 = ++str;
		while ( *str && (*str != '"') )
			++str;
	} else {
		val1 = str;
		while ( *str && ! isspace(*str) )
			++str;
	}
	if ( ! *str )
		return(NULL);
	*(str++) = '\0';

	/* Skip past separator */
	if ( (! *str) || ((str=strstr(str, sep)) == NULL) )
		return(NULL);
	str += strlen(sep);
	while ( *str && isspace(*str) )
		++str;

	/* Suck up second value */
	if ( *str == '"' ) {
		val2 = ++str;
		while ( *str && (*str != '"') )
			++str;
	} else {
		val2 = str;
		while ( *str && (*str != ';') && ! isspace(*str) )
			++str;
	}
	if ( *str ) {
		*str = '\0';
		do {
			++str;
		} while ( *str && (isspace(*str) || (*str == ';')) );
	}
	*A = val1;
	*B = val2;
	return(str);
}
static char *GetDefaultMBox(mailmsg *which)
{
	MIME_body *autosave = NULL;
	char      *header_key;
	char      *header_val;
	List<struct possibility *> *possibles = NULL;
	struct possibility **parray;
	int        i, npossibles;

	/* Get the rules for default mailboxes */
	if ( startup )
		autosave = startup->ByName("autosave");
	if ( ! autosave )
		return(NULL);

	/* Cycle through the headers, looking for matches */
	autosave->GetHeader(NULL);
	possibles = new List<struct possibility *>;
	while ( (header_val=autosave->GetHeader(&header_key)) ) {
		char *pattern, *filename;
		char *string,  *ptr;
		char *matchable;
		int   matchlen;

		/* Non-digit fields are real header info */
		if ( ! isdigit(*header_key) )
			continue;

		/* Make sure the message has the field in its header */
		for ( ptr = header_key; isdigit(*ptr); ++ptr );
		if ( *ptr == '-' )
			++ptr;
		if ( ! (matchable=(char *)which->GetField(ptr)) )
			continue;

		/* Make a copy to play with */
		string = new char[strlen(header_val)+1];
		strcpy(string, header_val);

		/* Play away. :) */
		ptr = string;
		while ( *ptr ) {
			struct possibility *p;

			/* Grab the next pattern for this header field */
			if ( ! (ptr=GetValue(ptr, &pattern, "=>", &filename)) )
				break;

			/* Case insensitive match */
			if ( ! match_nocase(matchable, pattern, &matchlen) ) {
				continue;
			}
			p = new struct possibility();
			p->key = header_key;
			p->value = new char[strlen(filename)+1];
			strcpy(p->value, filename);
			possibles->Add(p);
		}
		delete[] string;
	}
	if ( (npossibles=possibles->Size()) == 0 )
		return(NULL);

	/* Sort possibilities and return the first one */
	possibles->InitIterator();
	parray = new struct possibility *[possibles->Size()+1];
	for ( i=npossibles; i; --i ) {
		struct possibility **dval = possibles->Iterate();
		parray[i-1] = *dval;
		possibles->Remove(dval);
	}
	delete possibles;
	qsort(parray, npossibles, sizeof(struct possibility *),
							SortPossibleByKey);
	header_val = new char[strlen(parray[0]->value)+1];
	strcpy(header_val, parray[0]->value);
	for ( i=npossibles; i; --i ) {
		delete[] parray[i-1]->value;
		delete parray[i-1];
	}
	delete[] parray;
	return(header_val);
}

static int SaveWholeMessage(mailmsg *which, char *filename)
{
	if ( which->Save(filename) >= 0 ) {
		StatusOne(which, "D");
		return(0);
	}
	return(-1);
}

static int SaveWholeThread(mailmsg *which, char *filename)
{
	/* Back up the thread */
	while ( which->ThreadIndex() > 0 ) {
		which = which->Prev();
	}
	do {
		if ( SaveWholeMessage(which, filename) < 0 )
			return(-1);
	} while ( which = which->ThreadNext() );
	return(0);
}

static int SaveBody(MIME_body *which, Terminal *tty, char *filename)
{
	int writemode = 2;		/* Append mode */

	if ( filename == NULL ) {
		filename = PromptFile((char *)which->Name(), tty);
		writemode = 0;		/* Write / no overwrite */
	}
	tty->status(0, "Saving...");
	if ( which->Save(filename, writemode) < 0 ) {
		if ( errno == EEXIST ) {
			switch (tty->promptchar(0,
		"File exists -- [o]verwrite, [a]ppend, or [N]either? ")) {
				case 'o':
					tty->status(0, "Saving...");
					if ( which->Save(filename, 1) == 0 )
						goto save_okay;
					break;
				case 'a':
					tty->status(0, "Saving...");
					if ( which->Save(filename, 2) == 0 )
						goto save_okay;
					break;
				case 'n':
				default:
					tty->status(0, "Save cancelled.");
					sleep(1);
					delete[] filename;
					return(0);
			}
		}
		tty->status(0, "Save failed: %s", strerror(errno));
		tty->waitchar();
		delete[] filename;
		return(-1);
	}
  save_okay:
	if ( *filename ) {
		tty->status(0, "Message portion saved.");
		sleep(1);
		delete[] filename;
		return(1);
	} else {
		tty->status(0, "Save cancelled.");
		sleep(1);
		delete[] filename;
		return(0);
	}
}

static int SaveTextBody(mailmsg *which, MIME_body *body, Terminal *tty)
{
	struct stat sb;
	char *openmode;
	char *filename;
	char *headerval;
	int   nheaders;
	FILE *output;

	/* Where do we save it? */
	filename = PromptFile((char *)body->Name(), tty);
	if ( ! *filename ) {
		tty->status(0, "Save cancelled.");
		sleep(1);
		delete[] filename;
		return(0);
	}

	openmode = "w";
	if ( stat(filename, &sb) == 0 ) {
		switch (tty->promptchar(0,
		"File exists -- [o]verwrite, [a]ppend, or [N]either? ")) {
			case 'o':
				openmode = "w";
				break;
			case 'a':
				openmode = "a";
				break;
			case 'n':
			default:
				tty->status(0, "Save cancelled.");
				sleep(1);
				delete[] filename;
				return(0);
		}
	}

	/* Open the file */
	if ( (output=fopen(filename, openmode)) == NULL ) {
		tty->status(0, "Save failed: %s", strerror(errno));
		tty->waitchar();
		delete[] filename;
		return(-1);
	}

	/* Write out some header information */
	nheaders = 0;
	if ( (headerval=(char *)which->GetField("Date")) != NULL ) {
		fprintf(output, "Date: %s\n", headerval);
		++nheaders;
	}
	if ( (headerval=(char *)which->GetField("From")) != NULL ) {
		fprintf(output, "From: %s\n", headerval);
		++nheaders;
	}
	if ( (headerval=(char *)which->GetField("To")) != NULL ) {
		fprintf(output, "To: %s\n", headerval);
		++nheaders;
	}
	if ( (headerval=(char *)which->GetField("Subject")) != NULL ) {
		fprintf(output, "Subject: %s\n", headerval);
		++nheaders;
	}
	if ( nheaders > 0 )
		fprintf(output, "\n");
	fclose(output);

	if ( body->Save(filename, 2) < 0 ) {
		tty->status(0, "Couldn't save body: %s", strerror(errno));
		tty->waitchar();
		delete[] filename;
		return(-1);
	}
	tty->status(0, "Message portion saved.");
	sleep(1);
	delete[] filename;
	return(1);
}

static int ReplyMail(char *to[], char *cc[], mailmsg *which, MIME_body *body,
								Terminal *tty)
{
	int   i, retval, len;
	char *To, *Cc;
	char *subject, *Subject;
	FILE *temp_file = NULL;

	/* First, get the right "To" line */
	To = NULL;
	for ( i=0; to[i]; ++i ) {
		if ( (To=(char *)which->GetField(to[i])) )
			break;
	}
	if ( ! To ) {
		tty->status(0, "Couldn't find reply-to address!");
		sleep(1);
		return(0);
	}

	/* Create a CC line */
	Cc = NULL;
	if ( cc ) {
		char *ptr;
		for ( i=0, len=0; cc[i]; ++i ) {
			if ( (ptr=(char *)which->GetField(cc[i])) ) {
				if ( i > 0 )
					len += 2;
				len += strlen(ptr);
			}
		}
		Cc = new char[len+1];

		*Cc = '\0';
		for ( i=0; cc[i]; ++i ) {
			if ( (ptr=(char *)which->GetField(cc[i])) ) {
				if ( i > 0 )
					strcat(Cc, ", ");
				strcat(Cc, ptr);
			}
		}
	}

	/* Create the subject line */
	subject = (char *)which->Subject_Key();
	Subject = new char[4+strlen(subject)+1];
	sprintf(Subject, "Re: %s", subject);
	
	/* Find the text to include */
	if ( body == NULL ) {	/* Get a body */
		body = which->Body();
	}
	if ( body->NumParts() > 1 ) {
		/* A multipart message */
		Terminal *screen = new Terminal(1);
		screen->split(5);
		screen->moveto(1, 3);
		screen->printf("Choose the text to include in your reply:");
		screen->selectpane(1);
		body=SelectPart(NULL, body, screen, screen->lines()-5);
		delete screen;
		tty->redraw();
	}
	if ( body && (strncasecmp(body->Content(), "text",
						strlen("text")) == 0) ) {
		char *bodyfile = body->File();
		FILE *input;
		char *temp_name = tmpnam(NULL);
		if ( bodyfile && (input=fopen(bodyfile, "r")) ) {
			if ( (temp_file=fopen(temp_name, "w+")) != NULL ) {
				char line[BUFSIZ];
				while ( fgets(line, BUFSIZ-1, input) ) {
					if ( line[0] != '\n' )
						fprintf(temp_file, "> ");
					fputs(line, temp_file);
				}
				fseek(temp_file, 0, SEEK_SET);
				(void) unlink(temp_name);
			}
			fclose(input);
		}
		body->FreeFile();
	}

	/* Send it off! */
	retval = NewMail(To, Cc, Subject, 1, temp_file, tty);

	/* Clean up, and we're done. :) */
	if ( temp_file )
		fclose(temp_file);
	if ( Cc )
		delete[] Cc;
	delete[] Subject;
	return(retval);
}

static int Forward(char *To, char *Cc, mailmsg *which, Terminal *tty)
{
	char *tmp_name, *tmp;
	char *subject, *newsubject;
	char *headerval;
	FILE *temp_file;
	int   nheaders, retval;

	/* Get a temporary file name */
	tmp = tmpnam(NULL);
	tmp_name = new char[strlen(tmp)+1];
	strcpy(tmp_name, tmp);

	/* First, save the forwarded message to a tempfile */
	if ( (temp_file=fopen(tmp_name, "w")) == NULL ) {
		tty->status(0, "Couldn't write to %s: %s", tmp_name,
							strerror(errno));
		tty->waitchar();
		return(-1);
	}
	nheaders = 0;
	fprintf(temp_file, "Forwarded message: -------------------\n");
	if ( (headerval=(char *)which->GetField("Date")) != NULL ) {
		fprintf(temp_file, "Date: %s\n", headerval);
		++nheaders;
	}
	if ( (headerval=(char *)which->GetField("From")) != NULL ) {
		fprintf(temp_file, "From: %s\n", headerval);
		++nheaders;
	}
	if ( (headerval=(char *)which->GetField("Subject")) != NULL ) {
		fprintf(temp_file, "Subject: %s\n", headerval);
		++nheaders;
	}
	if ( nheaders > 0 )
		fprintf(temp_file, "\n");
	fclose(temp_file);
	if ( (which->Body())->Save(tmp_name, 2) < 0 ) {
		tty->status(0, "Couldn't save part to %s: %s", tmp_name,
							strerror(errno));
		tty->waitchar();
		return(-1);
	}
	/* Since we need to read from this file later, use "a+" append mode */
	if ( (temp_file=fopen(tmp_name, "a+")) == NULL ) {
		tty->status(0, "Couldn't reopen %s: %s", tmp_name,
							strerror(errno));
		tty->waitchar();
		(void) unlink(tmp_name);
		return(-1);
	}
	fprintf(temp_file, "------------------- end forwarded message.\n");
	rewind(temp_file);

	/* Make a new subject */
	subject = (char *)which->Subject();
	newsubject = new char[strlen(subject)+6+1];
	sprintf(newsubject, "%s (fwd)", subject);

	retval = NewMail(To, Cc, newsubject, 0, temp_file, tty);
	fclose(temp_file);
	(void) unlink(tmp_name);
	delete[] tmp_name;
	delete[] newsubject;
	return(retval);
}

/* This is the generic mail command entry point --
   	it returns 1 if it handled the command, or 0 if it didn't.
	it returns STATUS_BAR if the status bar has been changed
*/
int HandleMail(int command, mailmsg *which, MIME_body *body, Terminal *tty)
{
	const int did_something = 1;

	switch (command) {
		case MSG_DEL:
			/* If regular message... */
			if ( which->ThreadSize() == 0 ) {
				StatusOne(which, "D");
				return(did_something);
			}
			/* Delete entire thread? */
			switch (tty->promptchar(0,
			"Delete [t]hread, [A]rticle, or [n]either? ")) {
				case 't':
					StatusThread(which, "D");
					return(did_something|STATUS_BAR);
				case 'n':
					return(did_something|STATUS_BAR);
				case 'a':
				default:
					StatusOne(which, "D");
					return(did_something|STATUS_BAR);
			}
			/* Shouldn't ever get here */
			break;

		case MSG_UNDEL:
			/* If regular message... */
			if ( which->ThreadSize() == 0 ) {
				StatusOne(which, "U");
				return(did_something);
			}
			/* Delete entire thread? */
			switch (tty->promptchar(0,
			"Undelete [t]hread, [A]rticle, or [n]either? ")) {
				case 't':
					StatusThread(which, "U");
					return(did_something|STATUS_BAR);
				case 'n':
					return(did_something|STATUS_BAR);
				case 'a':
				default:
					StatusOne(which, "U");
					return(did_something|STATUS_BAR);
			}
			/* Shouldn't ever get here */
			break;

		case MSG_REPLY: {
			char *to[] = {
				"Reply-To", "From", "Sender", NULL
			};
			ReplyMail(to, NULL, which, body, tty);
			StatusOne(which, "R");
			return(did_something|STATUS_BAR);
		    }
		case MSG_REPLYALL: {
			char *to[] = {
				"Reply-To", "From", "Sender", NULL
			};
			char *plus[] = {
				"To", "Cc", NULL
			};
			ReplyMail(to, plus, which, body, tty);
			StatusOne(which, "R");
			return(did_something|STATUS_BAR);
		    }
		case MSG_SREPLY: {
			char *to[] = {
				"From", "Reply-To", NULL
			};
			ReplyMail(to, NULL, which, body, tty);
			StatusOne(which, "R");
			return(did_something|STATUS_BAR);
		    }
		case MSG_FORWARD: {
			char to[BUFSIZ];
			char cc[BUFSIZ];
			tty->softprompt(to, BUFSIZ, "Forward To: ", default_to,
									NULL);
			if ( to[0] == '\0' ) {
				tty->status(0, "Forwarding cancelled.");
				sleep(1);
				return(did_something|STATUS_BAR);
			}
#ifdef PROMPT_CC
			tty->fillprompt(cc, BUFSIZ, "Cc: ", NULL, NULL);
			if ( cc[0] )
				Forward(to, cc, which, tty);
			else
#endif
				Forward(to, NULL, which, tty);
			/* Save the recipient */
			if ( default_to )
				delete[] default_to;
			default_to = new char[strlen(to)+1];
			strcpy(default_to, to);
			return(did_something|STATUS_BAR);
		    }
		case MSG_SAVE:
			if ( body == NULL ) {	/* Get a body */
				body = which->Body();
			}
			if ( strncasecmp(body->Content(), "text",
						strlen("text")) != 0 ) {
				/* A single-part non-plaintext message */
				if ( body->NumParts() == 1 ) {
					SaveBody(body, tty, NULL);
					return(did_something|STATUS_BAR);
				}
				/* A multipart message */
				Terminal *screen = new Terminal(1);
				screen->split(5);
				screen->moveto(1, 3);
				screen->printf(
				"Choose the text to save to a formatted file:");
				screen->selectpane(1);
				body=SelectPart(NULL, body, screen,
							screen->lines()-5);
				delete screen;
				tty->redraw();

				/* Has the body been saved? */
				if ( body == NULL )
					return(1);

				/* Save non-plaintext messages */
				if ( strncasecmp(body->Content(), "text",
						strlen("text")) != 0 ) {
					SaveBody(body, tty, NULL);
					return(did_something|STATUS_BAR);
				}
			}
			/* Now, we have a plain text message */
			SaveTextBody(which, body, tty);
			return(did_something|STATUS_BAR);

		case MSG_SAVEALL: {
			unsigned int howmany = 1;
			int   retval;
			char *filename, *mbox;

			/* Set the default mailbox, if necessary */
			if ( ! default_mbox ) {
				default_mbox = new char[strlen(DEFAULT_MBOX)+1];
				strcpy(default_mbox, DEFAULT_MBOX);
			}
			if ( which->ThreadSize() > 0 ) {
				/* Save entire thread? */
				switch (tty->promptchar(0,
			"Save [t]hread, [A]rticle, or [n]either? ")) {
					case 't':
						howmany = (~1&0xEF); /* Lots */
						break;
					case 'a':
						howmany = 1;
						break;
					case 'n':
					return(did_something|STATUS_BAR);
					default:
						howmany = 1;
						break;
				}
			}

			/* Save to a file */
			if ( (mbox=GetDefaultMBox(which)) == NULL )
				mbox = default_mbox;
			filename = PromptFile(mbox, tty);
			if ( filename[0] == '\0' ) {
				tty->status(0, "Save cancelled.");
				sleep(1);
				delete[] filename;
				return(did_something|STATUS_BAR);
			}
			if ( howmany > 1 )
				retval = SaveWholeThread(which, filename);
			else
				retval = SaveWholeMessage(which, filename);

			/* Let the user know what happened */
			if ( retval < 0 ) {
				tty->status(0, "Save failed: %s",
							strerror(errno));
				tty->waitchar();
				delete[] filename;
				return(did_something|STATUS_BAR);
			}
			tty->status(0, "%s saved and deleted.",
					(howmany > 1) ? "Messages" : "Message");
			sleep(1);

			/* Make the default mbox the file we just saved to */
			delete[] default_mbox;
			default_mbox = filename;
			return(did_something|STATUS_BAR);
		    }
		case MSG_NEW: {
			char to[BUFSIZ];
			char cc[BUFSIZ];
			char subject[BUFSIZ];
			tty->softprompt(to, BUFSIZ, "To: ", default_to, NULL);
			if ( to[0] == '\0' ) {
				tty->status(0, "Message cancelled.");
				sleep(1);
				return(did_something|STATUS_BAR);
			}
#ifdef PROMPT_CC
			tty->fillprompt(cc, BUFSIZ, "Cc: ", NULL, NULL);
#endif
			tty->fillprompt(subject,BUFSIZ,"Subject: ",NULL, NULL);
#ifdef PROMPT_CC
			if ( cc[0] )
				NewMail(to, cc, subject, 1, NULL, tty);
			else
#endif
				NewMail(to, NULL, subject, 1, NULL, tty);
			/* Save the recipient */
			if ( default_to )
				delete[] default_to;
			default_to = new char[strlen(to)+1];
			strcpy(default_to, to);
			return(did_something|STATUS_BAR);
		    }
		case SYSTEM: {
			char command[1024];

			/* What are we to run? */
			tty->softprompt(command, 1024-1, "Shell Escape: ",
							system_cmd, NULL);
			if ( command[0] ) {
				tty->system(1, "%s", command);

				if ( system_cmd )
					delete[] system_cmd;
				system_cmd = new char[strlen(command)+1];
				strcpy(system_cmd, command);
			}
			return(did_something|STATUS_BAR);
		    }
		default:
			return(0);
	}
}

/* Helper routine for SelectPart() */
static void DrawPart(int which, MIME_body *body, Terminal *tty)
{
	char  fmt[1024];
	char *desc;

	/* Basic sanity */
	if ( ! body )
		return;


	/* Find a string to use for describing the body */
	desc = NULL;
	if ( (--which) == 0 ) {
		desc = "RAW MESSAGE";
	}
	if ( desc == NULL )
		desc = (char *)body->GetField("Content-Description");
	if ( desc == NULL )
		desc = (char *)body->Name();
	if ( desc == NULL )
		desc = (char *)body->GetField("Content-ID");
	if ( desc == NULL )
		desc = "";

	/* Print it */
	tty->linedown();
	tty->clreol();
	sprintf(fmt, " Part %%d:  %%.%ds", tty->cols()-strlen("Part ddd:  ")-2);
	tty->printf(fmt, which, desc);
	tty->linedown();
	tty->clreol();
	sprintf(fmt, "\tContent-Type:  %%.%ds",
				tty->cols()-8-strlen("Content-Type:  ")-2);
	tty->printf(fmt, body->Content());
}

static void DrawPartList(MIME_body *body, Terminal *tty, int offset,
						int howmany, int current)
{
	tty->clrpane(0);
	while ( howmany-- ) {
		if ( offset == current ) {
			tty->hilite(1);
			DrawPart(offset, body->GetPart(offset), tty);
			tty->hilite(0);
		} else
			DrawPart(offset, body->GetPart(offset), tty);
		tty->linedown();
		++offset;
	}
	tty->flush();
}

/* We return text bodies, and save unknown body types to disk */
MIME_body *ViewPart(MIME_body *which, Terminal *tty)
{
	if ( (strncasecmp(which->Content(), "text", strlen("text")) == 0) ||
	     (strncasecmp(which->Content(), "message", strlen("message")) == 0)
			 || (strncasecmp(which->Content(), "multipart",
						strlen("multipart")) == 0) )
		return(which);

	tty->status(0, "Not viewable -- saving to file.");
	sleep(1);
	SaveBody(which, tty, NULL);
	return(NULL);
}

MIME_body *SelectPart(mailmsg **whichptr, MIME_body *body,
						Terminal *tty, int tty_height)
{
	int max_draw = body->NumParts();
	int can_draw = ((tty_height/3) > max_draw) ? max_draw : (tty_height/3);
	int current;
	MIME_body *part;

	if ( (body == NULL) || (body->NumParts() == 1) )
		return(body);

	/* Automatically display a one-part textual MIME message */
	if ( body->NumParts() == 2 ) {
		part = body->GetPart(2);
		if ( strncasecmp(part->Content(),"text",strlen("text")) == 0 )
			return(part);
	}
			

	/* Otherwise, pick the part */
	current = body->CurrentPart();
	DrawPartList(body, tty, (((current-1)/can_draw)*can_draw)+1,
							can_draw, current);
	for ( ; ; ) {
		int key, cmd;

		tty->status(1,
			" Use arrow keys to select a part (currently %d of %d)",
							current-1, max_draw-1);
		key = tty->waitchar();
		switch (cmd=KeyToCmd(key)) {
			case REDRAW:
				DrawPartList(body, tty,
					(((current-1)/can_draw)*can_draw)+1,
							can_draw, current);
				break;
			case QUIT:
				body->CurrentPart(current);
				return(NULL);

			case QUITALL:
				if ( whichptr )
					/* Really quit! */
					*whichptr = NULL;
				return(NULL);

			case LINE_UP:
				if ( current <= 1 )
					break;

				--current;
				if ( (current%can_draw) != 0 ) {
					tty->moveto(1, 1+(current%can_draw)*3);
					DrawPart(current+1,
						body->GetPart(current+1), tty);
					tty->moveto(1,
						1+((current%can_draw)-1)*3);
					tty->hilite(1);
					DrawPart(current,
						body->GetPart(current), tty);
					tty->hilite(0);
					tty->flush();
				} else {
					DrawPartList(body, tty,
						current-can_draw+1,
							can_draw, current);
				}
				break;

			case LINE_DOWN:
				if ( current == max_draw )
					break;

				if ( (current%can_draw) != 0 ) {
					tty->moveto(1,
						1+((current%can_draw)-1)*3);
					DrawPart(current,
						body->GetPart(current), tty);
					++current;
					tty->linedown();
					tty->hilite(1);
					DrawPart(current,
						body->GetPart(current), tty);
					tty->hilite(0);
					tty->flush();
				} else {
					++current;
					DrawPartList(body, tty,
						((current/can_draw)*can_draw)+1,
							can_draw, current);
				}
				break;

			case MSG_VIEW:
				body->CurrentPart(current);
				part = body->GetPart(current);
				if ( (body == part) ||
(strncasecmp(part->Content(), "multipart", strlen("multipart")) != 0) ) {
					if ( (part=ViewPart(part, tty)) ) {
						return(part);
					}
				} else {
					/* Go DOWN! */
					if ( (part=SelectPart(whichptr, part,
							tty, tty_height)) ) {
						return(part);
					}
					DrawPartList(body, tty,
					(((current-1)/can_draw)*can_draw)+1,
							can_draw, current);
				}
				break;

			default:
				if ( whichptr ) {
					mailmsg *which = *whichptr;

					/* Handle possible mail command */
					(void) HandleMail(cmd, which,
						body->GetPart(current), tty);

					/* If the current message changed.. */
					if ( which->Changed() ) {
						mailmsg *newmsg;
						if ( (newmsg=which->SkipDeleted(NULL)) )
							*whichptr = newmsg;
						return(NULL);
					}
				}
				break;
		}
	}
}
