/* 

   Project:     soma - stefan's own mail application 
   File:        folder_menu.c
   Description: 
   Created:     
   Changed:     $Date: 1996/02/23 11:40:16 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995,1996 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: folder_menu.c,v 1.1 1996/02/23 11:40:16 kuehnel Exp $
	$Author: kuehnel $
	$Log: folder_menu.c,v $
	Revision 1.1  1996/02/23 11:40:16  kuehnel
	Initial revision

 	$Date: 1996/02/23 11:40:16 $

   ---------------------------------------------------------------------------

*/

#include <xview/xview.h>
#include <xview/panel.h>
#include "global.h"
#include "machine.h"


/*
   Function:     fill_menu
   Parameters:   Menu m                 - Menu to be filled
                 struct folder_list *fl - pointer to the first element of a
		                          folder list
   Return-Value: -
   Remarks:      Used to fill the "Folder"-Menu
*/
void fill_menu (Menu m,struct folder_list *fl)
{
  struct folder_list *pfl;
  Menu_item mi;

  pfl=fl;

  while (pfl!=NULL)
    {
      mi = (Menu_item) xv_create (0,MENUITEM,
				  MENU_STRING,pfl->this_one.folder_name,
				  MENU_RELEASE,NULL);
      xv_set (m, MENU_APPEND_ITEM, mi , NULL);
      pfl=pfl->next;
    }
}


