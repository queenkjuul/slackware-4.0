/* 

   Project:     soma - stefan's own mail application 
   File:        view.h
   Description: contains functions for view-window 
   Created:     09 Dec. 1995
   Changed:     
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: view.h,v 1.5 1996/02/23 11:42:32 kuehnel Exp kuehnel $  
	$Author: kuehnel $
	$Log: view.h,v $
	Revision 1.5  1996/02/23 11:42:32  kuehnel
	Check in before a new release.

	Revision 1.4  1996/02/18 14:11:13  kuehnel
	Keine �nderungen (?).

 * Revision 1.3  1995/12/11  20:28:43  kuehnel
 * Keine �nderung.
 *
 * Revision 1.2  1995/12/10  21:52:05  kuehnel
 * �berarbeitet.
 *
 * Revision 1.1  1995/12/09  20:39:44  kuehnel
 * Initial revision
 *
 * Revision 1.1  1995/12/09  20:39:44  kuehnel
 * Initial revision
 *
 	$Date: 1996/02/23 11:42:32 $ 
   ---------------------------------------------------------------------------

*/



/*
   Function:     open_view
   Parameters:   -
   Return-Value: -
   Remarks:      Opens the view frame 
*/
extern void open_view(struct message msg);

/*
   Function:     close_view
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
extern void close_view();

/*
   Function:     insert_view
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
extern void insert_view(char *line);

/*
   Function:     set_view_pos 
   Parameters:   int pos
   Return-Value: -
   Remarks:      - 
*/
extern void set_view_pos (int pos);

/*
   Function:     set_view_msg_id  
   Parameters:   char*
   Return-Value: 
   Remarks:      called by main
*/
extern void set_view_msg_id (char *msgid);
