/* 

   Project:     soma - stefan's own mail application 
   File:        somastr.h
   Description: contains functions for string-handling
   Created:     03 Dec. 1995
   Changed:     03 Dec. 1995 
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: somastr.c,v 1.3 1996/01/07 16:48:34 kuehnel Exp $ 
	$Author: kuehnel $
	$Log: somastr.c,v $
 * Revision 1.3  1996/01/07  16:48:34  kuehnel
 * #include "machine.h" ergaenzt.
 *
 * Revision 1.2  1995/12/11  20:26:49  kuehnel
 * Keine �nderung.
 *
 * Revision 1.1  1995/12/03  23:12:23  kuehnel
 * Initial revision
 *
 * Revision 1.1  1995/12/03  23:12:23  kuehnel
 * Initial revision
 * 
 	$Date: 1996/01/07 16:48:34 $ 
   ---------------------------------------------------------------------------

*/

#include <string.h>
#include "machine.h"

/*
   Function:     scopy
   Parameters:   char *str1 
                 char *str2
		 int from
   Return-Value: -
   Remarks:      copy all characters from position from to end from str1 to 
                 str2
*/
void scopy (char *str1,char *str2,int from)
{
  int i;
  for (i=from;i<=strlen(str1);i++)
    {
      str2[i-from]=str1[i];
    }
}


/*
   Function:     sfill
   Parameters:   char *tofill - string to be filled
                 int nos - number of space
   Return-Value: -
   Remarks:      fills nos spaces in str "tofill"
*/

void sfill (char *tofill,int nos)
{
  int i=0;
  
  if (nos!=0)
    {
      for (i=0;i<=nos;i++)
	{
	  tofill[i]=' ';
	}
    }
  tofill[i]=(char)0;
}

/*
   Function:     strim
   Parameters:   char *source - string to be trimmed
                 char *dest   - string to store result in
                 int len      - length of deststr
   Return-Value: -
   Remarks:      trims source to the length of des
*/

void strim (char *source,char *dest,int len)
{
  int i;
  char fill[255];

  if (strlen(source)>len)
    {
      for (i=0;i<len;i++) dest[i]=source[i];
      dest[i]=(char)0;
    }
  else
    {
      sfill (fill,len-strlen(source)-1);
      strcat (source,fill);
      strcpy (dest,source);
    }
  
}
