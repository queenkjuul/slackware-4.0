/* 

   Project:     soma - stefan's own mail application 
   File:        send.c
   Description: Communication with SMTP via Socket
   Created:     14.12.1995
   Changed:     $Date: 1995/12/14 18:28:41 $
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: send.h,v 1.1 1995/12/14 18:28:41 kuehnel Exp $
	$Author: kuehnel $
	$Log: send.h,v $
 * Revision 1.1  1995/12/14  18:28:41  kuehnel
 * Initial revision
 *
 	$Date: 1995/12/14 18:28:41 $

   ---------------------------------------------------------------------------

*/

/*
   Function:     read_from_socket
   Parameters:   
   Return-Value: 
   Remarks:      
*/
extern void read_from_socket (int fd,char *buff,int len);

/*
   Function:     write_to_socket
   Parameters:   
   Return-Value: 
   Remarks:      
*/
extern void write_to_socket (int fd,char *what);

/*
   Function:     init_sock
   Parameters:   - 
   Return-Value: socket
   Remarks:      opens connection to rsmtp-Host
*/

extern int init_sock ();
