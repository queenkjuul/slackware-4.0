/* 

   Project:     soma - stefan's own mail application 
   File:        global.c
   Description: global data
   Created:     11 Dec. 1995
   Changed:     $Date: 1996/02/23 11:41:42 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: global.c,v 1.12 1996/02/23 11:41:42 kuehnel Exp kuehnel $
	$Author: kuehnel $
	$Log: global.c,v $
	Revision 1.12  1996/02/23 11:41:42  kuehnel
	Check in before a new release.

	Revision 1.11  1996/02/21 21:54:07  kuehnel
	removed: set/get_foldermenu
	new: fill_menu (previously in main.c)

	Revision 1.10  1996/02/18 14:06:02  kuehnel
	Create_folder_list liest folder aus .somarc. Neue Funktionen zum Speichern
	des aktiven Folders und des Folder-Menus.

	Revision 1.9  1996/02/04 21:51:56  kuehnel
	Neu: create_folder_list, zun�chst einmal mit "hardwired" Foldern.

	Revision 1.8  1996/02/04 14:07:41  kuehnel
	Renamed "expand_path" to "expand_tilde" because the old name lead to a
	name conflict with a built-in function of libxview...
	Removed: get_sig_content and store_sig_file

	Revision 1.7  1996/02/01 21:09:13  kuehnel
	Neue Funktion: expand_path, ersetzt ~ in einem String durch Pfad zum
	Homedir.

 * Revision 1.6  1996/01/07  16:48:15  kuehnel
 * #include "machine.h" ergaenzt.
 *
 * Revision 1.5  1996/01/07  14:17:41  kuehnel
 * Neue globale Variable, samt Zugriffsfunktionen: access_mode. Dient
 * spaeterer Erweiterung auf andere Mail-Zugriffsarten (z.B. POP3).
 *
 * Revision 1.4  1995/12/19  23:29:39  kuehnel
 * Neue Routinen zur Verwaltung der Timer-Variablen.
 *
 * Revision 1.3  1995/12/17  19:34:14  kuehnel
 * Neu: set/get_smtpserver
 * Verbessert: readconfig nimmt Standardwerte an, wenn Variable nicht in .somarc vorhanden
 *
 * Revision 1.2  1995/12/14  18:29:42  kuehnel
 * new function: get_hostname
 *
 * Revision 1.1  1995/12/11  20:24:37  kuehnel
 * Initial revision
 *
 	$Date: 1996/02/23 11:41:42 $

   ---------------------------------------------------------------------------

*/

/* #define DEBUG_GLOBAL */

#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>
#include "somastr.h"
#include "fileop.h"
#include "global.h"
#include "machine.h"

/* following varibles are global */

char mailfile[STRSIZE];
char returnpath[STRSIZE];
char sigfile[STRSIZE];
char homedir[STRSIZE];
char smtpserver[STRSIZE];
char printcommand[STRSIZE];
char spool_file[STRSIZE];
int usesig,validate=0;
int timerval;

struct folder_list *f_list;
struct folder active_folder;

enum acc_modes access_mode=LOCAL;


/* Functions for reading/setting global data */


/*
   Function:     get_mailfile
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void get_mailfile (char *value)
{
  strcpy (value,mailfile);
}

/*
   Function:     set_mailfile
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void set_mailfile (char *value)
{
  strcpy (mailfile,value);
}


/*
   Function:     set_active_folder
   Parameters:   struct folder - av;
   Return-Value: -
   Remarks:      -
*/
void set_active_folder (struct folder av)
{
  active_folder = av;
}

/*
   Function:     get_active_folder
   Parameters:   -
   Return-Value: struct folder 
   Remarks:      -
*/
struct folder* get_active_folder ()
{
  return &active_folder;
}


/*
   Function:     set_folder_list
   Parameters:   struct folder_list *
   Return-Value: -
   Remarks:      -
*/
void set_folder_list (struct folder_list *p)
{
  f_list = p;
}

/*
   Function:     get_folder_list 
   Parameters:   -
   Return-Value: struct folder_list *
   Remarks:      -
*/
struct folder_list* get_folder_list ()
{
  return f_list;
}

/*
   Function:     get_printcommand
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void get_printcommand (char *value)
{
  strcpy (value,printcommand);
}

/*
   Function:     set_printcommand
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void set_printcommand (char *value)
{
  strcpy (printcommand,value);
}

/*
   Function:     get_returnpath
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void get_returnpath (char *value)
{
  strcpy (value,returnpath);
}

/*
   Function:     set_returnpath
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void set_returnpath (char *value)
{
  strcpy (returnpath,value);
}

/*
   Function:     get_sigfile 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void get_sigfile (char *value)
{
  strcpy (value,sigfile);
}


/*
   Function:     get_homedir 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void get_homedir (char *value)
{
  strcpy (value,homedir);
}

/*
   Function:     get_hostname 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void get_hostname (char *value)
{
  strcpy (value,(char *)getenv("HOSTNAME"));
}


/*
   Function:     get_usesig
   Parameters:   -
   Return-Value: int
   Remarks:      
*/
int get_usesig (void)
{
  return usesig;
}

/*
   Function:     set_usesig
   Parameters:   int
   Return-Value: -
   Remarks:      
*/
void  set_usesig (int value)
{
  usesig=value;
}

/*
   Function:     get_smtpserver 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void get_smtpserver (char *value)
{
  strcpy (value,smtpserver);
}

/*
   Function:     set_smtpserver 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void set_smtpserver (char *value)
{
  strcpy (smtpserver,value);
}

/*
   Function:     get_spool_file 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void get_spool_file (char *value)
{
  strcpy (value,spool_file);
}

/*
   Function:     set_spool_file 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
void set_spool_file (char *value)
{
  strcpy (spool_file,value);
}


/*
   Function:     get_timerval 
   Parameters:   -
   Return-Value: int
   Remarks:      -
*/
int get_timerval ()
{
  return timerval;
}

/*
   Function:     set_timerval
   Parameters:   int tv
   Return-Value: -
   Remarks:      -
*/
void set_timerval (int tv)
{
  timerval = tv;
}

/*
   Function:     set_acc_mode
   Parameters:   enum acc_modes
   Return-Value: -
   Remarks:      -
*/
void set_acc_mode (enum acc_modes acc)
{
  access_mode = acc; 
}

/*
   Function:     get_acc_mode
   Parameters:   -
   Return-Value: enum acc_modes
   Remarks:      -
*/
enum acc_modes get_acc_mode ()
{
  return access_mode;
}

/*
   Function:     expand_tilde
   Parameters:   char * - path to be expanded
   Return-Value: int - number of replaced characters
   Remarks:      replaces ~ with path to homedir
*/

int expand_tilde (char *path)
{
  int i=0,j=0,k=0,r=0;
  char tmp_path[STRSIZE],home_dir[STRSIZE];

  for (i=0;i<strlen(path);i++)
    {
      if (path[i]=='~')
	{
	  if (path[i+1]=='/')
	    {
	      get_homedir (home_dir);
	      for (k=0;k<strlen(home_dir);k++)
		{
		  tmp_path[j]=home_dir[k]; j++;
		}
	    }
	  r++;
	}
      else 
	{
	  tmp_path[j]=path[i]; j++;
	}

    }
  tmp_path[j]=(char)0;
  strcpy (path,tmp_path);
  return r;
}

/*
   Function:     read_config_file 
   Parameters:   -
   Return-Value: int - !0 if configfile could be read, 0 else
   Remarks:      -
*/
int read_config_file ()
{
  char config_file_name[STRSIZE],home_dir[STRSIZE];
  char line[STRSIZE],buffer[STRSIZE];
  FILE *fd;

  get_homedir (home_dir);
  sprintf (config_file_name,"%s/.somarc",home_dir);

  /* 
     Structure of a line of the config file:
     
     Keyword:<spc>Value<nl>

     valid keywords are (a/n means alphanumeric, n - numeric 
                         and "x"/"y" - literal "x" or "y"): 
     
     Keyword      values     Meaning
     
     Mail-File    a/n        the path to the Incoming-Folder
     Return-Path  a/n        a correct Mailadress for replies
     SMTP-Server  a/n        name or IP-address of a smtp-server
     Timer        n          Timer interval for mail-checking
     Print        a/n        command-line for printing (e.g. lpr or lp )
     Use-Sig      "yes"/"no" use a signature?
     Spool        a/n        spool-file for outgoing messages
  */  

  if ((fd=fopen(config_file_name,"r"))!=NULL)
    {
      while (!feof(fd))
	{
	  read_to_nl (fd,line);
	  if (match("Mail-File:",line))
	    {
	      scopy (line,buffer,11);
	      expand_tilde (buffer);
	      set_mailfile (buffer);
	    }
	  else if (match ("Return-Path:",line))
	    {
	      scopy (line,buffer,13);
	      set_returnpath (buffer);
	    }
	  else if (match ("Spool:",line))
	    {
	      scopy (line,buffer,7);
	      set_spool_file (buffer);
	    }
          else if (match ("SMTP-Server:",line))
	    {
	      scopy (line,buffer,13);
	      set_smtpserver (buffer);
	    }
	  else if (match ("Timer:",line))
	    {
	      int timer_value;
	      scopy (line,buffer,7);
	      timer_value = atoi (buffer);
	      set_timerval (timer_value);
	    }
	  else if (match ("Use-Sig:",line))
	    {
	      scopy (line,buffer,9);
	      if (strcmp(buffer,"yes")==0)
		{
		  usesig = 1;
		}
	      else 
		{
		  usesig = 0 ;
		}
	    }
	} /* while (!feof... */
      fclose (fd);
    }     /* if ((fd=... */
  else
    {
      return 0;
    }     /* else ... */
  return 1;
}

/*
   Function:     get_user_information
   Parameters:   -
   Return-Value: -
   Remarks:      initializes global variables by reading config-file or
                 system-information.
*/

void get_user_information (struct folder_list **flist)
{ 
  struct passwd *pw;
  uid_t userid;
  char user[STRSIZE],host[STRSIZE],retpth[STRSIZE], mailf[STRSIZE];
  char spool[STRSIZE];
#ifdef DEBUG_GLOBAL
  char buffer[STRSIZE];
#endif
  
       
  gethostname(host,STRSIZE);  
  userid=getuid();
  pw=getpwuid(userid);
  strcpy(user,pw->pw_name);
  strcpy(homedir,pw->pw_dir);
 
  sprintf (sigfile,"%s/.signature",homedir);

  /* Initialize Configuration-Parameters */

  if (getenv("MAIL")!=0) strcpy (mailf,(char *)getenv("MAIL"));
  else  sprintf (mailf,"/var/spool/mail/%s",user);
  set_mailfile (mailf);
  
  sprintf (retpth,"<%s@%s>",user,host);
  set_returnpath (retpth);
  
  set_smtpserver ("localhost");
  set_timerval (30);
  set_printcommand ("lpr");
  sprintf (spool,"%s/.soma_out",homedir);
  set_spool_file (spool);
  usesig=1;

  /* Configuration parameters also contained in the config_file woul 
     be overwritten */

  read_config_file();

#ifdef DEBUG_GLOBAL
  printf ("Configuration-parameters:\n");
  get_mailfile(buffer);
  printf ("\tMail-File: %s\n",buffer);
  get_returnpath(buffer);
  printf ("\tReturnpath: %s\n",buffer);
  get_smtpserver(buffer);
  printf ("\tSMTP-Server: %s\n",buffer);
  printf ("\tTimer: %d\n",get_timerval());
  get_printcommand(buffer);
  printf ("\tPrint: %s\n",buffer);
  printf ("\tUse-Sig: %d\n",usesig);
#endif
   
}


/*
   Function:     create_folder_list
   Parameters:   -
   Return-Value: -
   Remarks:      Use this function to create a folder list. There is always
                 at least the folder incoming containing the value from the
		 global variable mailfile. Therefore create_folder_list 
		 can only performed after get_user_information. The remaining
		 folders from the config-file could be added with the function
		 add_config_folders
*/

void create_folder_list (struct folder_list **flist)
{
  struct folder f_entry;

  strcpy (f_entry.folder_name,"Incoming");
  strcpy (f_entry.folder_path,mailfile);
  f_entry.deletable = 0;
  
  add_folder (flist,f_entry);
}

/*
   Function:     add_config_folders
   Parameters:   -
   Return-Value: int
   Remarks:      Adds folders stored in the Config-File to the list
*/
int add_config_folders (struct folder_list **flist)
{
  char config_file_name[STRSIZE],home_dir[STRSIZE];
  char line[STRSIZE],buffer[STRSIZE],name[STRSIZE],path[STRSIZE];
  FILE *fd;
  int  i=0,n=0,p=0,np=0,pp=0,folders=0,inmarks=0;
  struct folder flist_entry;

  /* 
     Folder entry:

     Folder:<spc>"name of the folder","path to folder"
   
   */

  get_homedir (home_dir);
  sprintf (config_file_name,"%s/.somarc",home_dir);

  if ((fd=fopen(config_file_name,"r"))!=NULL)
    {
      while (!feof(fd))
	{
	  read_to_nl (fd,line);
	  if (match("Folder:",line))
	    {
	      scopy (line,buffer,8);
	      
	      n=1; /* line starts with name */
	      np=0;
	      pp=0;

	      for (i=0;i<strlen(buffer);i++)
		{
		  if ((buffer[i]==',')&&(n==1))
		    {
		      n=0; p=1;
		    }
		  if (buffer[i]=='"') inmarks=!inmarks;
		  if ((buffer[i]!='"')&&(buffer[i]!=',')&&((buffer[i]!=' ')
							   ||(inmarks)))
		    {
		      if (n==1)
			{
			  name[np++]=buffer[i];
			}
		      else 
			{
			  path[pp++]=buffer[i];
			}
		    }
		} /* for ... */
	
	      name[np]=(char)0;
	      path[pp]=(char)0;
	      
	      if ((pp!=0)&&(np!=0))
		{
		  folders++;
#ifdef DEBUG_GLOBAL
		  printf ("Folder recognized: Name: %s\n",name);
		  printf ("                   Path: %s\n",path);
#endif
		  expand_tilde (path);
#ifdef DEBUG_GLOBAL
		  printf ("(after expand_tilde)   : %s\n",path);
#endif
		  strcpy (flist_entry.folder_name,name);
		  strcpy (flist_entry.folder_path,path);
		  flist_entry.deletable=1;
		  add_folder (flist,flist_entry);
		}
	    } /* if (match... */
	}     /* while */
      fclose (fd);
      return 1;
    }
  else 
    {
      return 0;
    }
}

