/* 

   Project:     soma - stefan's own mail application 
   File:        folder.c
   Description: functions for folder-handling
   Created:     04.02.1996
   Changed:     $Date: 1996/02/18 14:01:50 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995,1996 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: folder.c,v 1.2 1996/02/18 14:01:50 kuehnel Exp $
	$Author: kuehnel $
	$Log: folder.c,v $
	Revision 1.2  1996/02/18 14:01:50  kuehnel
	Remove_folder �berarbeitet.

	Revision 1.1  1996/02/04 21:52:15  kuehnel
	Initial revision

 	$Date: 1996/02/18 14:01:50 $

   ---------------------------------------------------------------------------

*/
#include <stdlib.h>
#include <strings.h>
#include <stdio.h>
#include "global.h"

/* #define DEBUG_FOLDER */

/*
   Function:     print_folder_list ()
   Remarks:      this function is for debug_reasons only
*/
void print_folder_list ()
{
  struct folder_list *flptr;
  int i=0;

  flptr=get_folder_list();

  while (flptr!=NULL)
    {
      printf ("%d. Folder: %s, %s, (%d)\n",i++,flptr->this_one.folder_name,
	      flptr->this_one.folder_path,flptr->this_one.deletable);
      flptr=flptr->next;
    }

}


/*
   Function:     add_folder 
   Parameters:   struct folder_list **fptr; 
                 struct folder entry;
   Return-Value: -
   Remarks:      
*/
void add_folder (struct folder_list **fptr,struct folder entry)
{
  if (*fptr==NULL)
    {
      *fptr = malloc (sizeof(struct folder_list));
      (*fptr)->this_one=entry;
      (*fptr)->next=NULL;
    }
  else
    {
      add_folder (&((*fptr)->next),entry);
    }

}

/*
   Function:     remove_folder_list_entry 
   Parameters:   struct folder_list *flist root  - root-pointer
                 struct folder_list *flist todel - pointer to the entry
		                                   to be deleted
   Return-Value: 
   Remarks:      
*/
void remove_folder_list_entry (struct folder_list *root,
			       struct folder_list *todel)
{
  struct folder_list *tmp_ptr,*tmp_ptr2;
  
  tmp_ptr=root;
  while ((tmp_ptr->next!=todel)&&(tmp_ptr->next!=NULL))
    {
      tmp_ptr=tmp_ptr->next;
    }
  if (tmp_ptr->next->this_one.deletable)
    {
      tmp_ptr2=tmp_ptr->next;
#ifdef DEBUG_FOLDER
      printf ("Going to delete folder %s\n",tmp_ptr2->this_one.folder_name);
      printf ("Path to this folder is %s\n",tmp_ptr2->this_one.folder_path);
#endif
      tmp_ptr->next=tmp_ptr->next->next;
      free (tmp_ptr2);
    }
#ifdef DEBUG_FOLDER
  print_folder_list ();
#endif

}

/*
   Function:     get_folder_list_entry
   Parameters:   struct folder_list *fl - pointer to a folder_list
                 int nr                 - number of the entry to be returned
   Return-Value: struct folder_list*          
   Remarks:      -
*/

struct folder_list* get_folder_list_entry (struct folder_list *fl, int nr) 
{
  struct folder_list *tmp_ptr;
  int i=1;

  tmp_ptr=fl;

  while ((tmp_ptr!=NULL)&&(i!=nr))
    {
      i++;
      tmp_ptr=tmp_ptr->next;
    }

  return tmp_ptr;

}

/*
   Function:     get_folder_list_entry_by_name
   Parameters:   struct folder_list *fl - pointer to a folder_list
                 char *str              - name of the entry to be returned
   Return-Value: struct folder_list*    - NULL if not found      
   Remarks:      -
*/

struct folder_list *get_folder_by_name (struct folder_list *fl, 
						   char *str) 
{
  struct folder_list *tmp_ptr;

  tmp_ptr=fl;

  while ((tmp_ptr!=NULL)&&(strcmp(tmp_ptr->this_one.folder_name,str)!=0))
    {
      tmp_ptr=tmp_ptr->next;
    }

  return tmp_ptr;

}






