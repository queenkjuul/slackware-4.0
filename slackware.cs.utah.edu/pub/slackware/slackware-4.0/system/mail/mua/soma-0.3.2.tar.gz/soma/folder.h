/* 

   Project:     soma - stefan's own mail application 
   File:        folder.h
   Description: functions for folder-handling
   Created:     04.02.1996
   Changed:     $Date: 1996/02/21 21:57:10 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995,1996 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: folder.h,v 1.3 1996/02/21 21:57:10 kuehnel Exp $
	$Author: kuehnel $
	$Log: folder.h,v $
	Revision 1.3  1996/02/21 21:57:10  kuehnel
	*** empty log message ***

	Revision 1.2  1996/02/18 14:02:34  kuehnel
	remove_folder ge�ndert.

	Revision 1.1  1996/02/04 21:52:37  kuehnel
	Initial revision

 	$Date: 1996/02/21 21:57:10 $

   ---------------------------------------------------------------------------

*/

#include <sys/time.h> 
#include <time.h>


/* A folder is a file containing messages in a RFC822 format */

struct folder {
  char folder_name [STRSIZE];
  char folder_path [STRSIZE];
  int  deletable;               /* 0 not deletable, !0 deletable */
  time_t last_access;
};

struct folder_list {
  struct folder this_one;
  struct folder_list *next;
};

/*
   Function:     add_folder 
   Parameters:   struct folder_list **fptr
                 struct folder entry;
   Return-Value: -
   Remarks:      
*/
extern void add_folder (struct folder_list **fptr,struct folder entry);

/*
   Function:     get_folder_list_entry
   Parameters:   struct folder_list *fl - pointer to a folder_list
                 int nr                 - number of the entry to be returned
   Return-Value: struct folder_list*          
   Remarks:      -
*/

extern struct folder_list *get_folder_list_entry (struct folder_list *fl, int nr);

/*
   Function:     get_folder_list_by_name
   Parameters:   struct folder_list *fl - pointer to a folder_list
                 char *str              - name of the entry to be returned
   Return-Value: struct folder_list*          
   Remarks:      -
*/
extern struct folder_list *get_folder_by_name (struct folder_list *fl, 
					       char *str); 
 

/*
   Function:     remove_folder_list_entry 
   Parameters:   struct folder_list *flist root  - root-pointer
                 struct folder_list *flist todel - pointer to the entry
		                                   to be deleted
   Return-Value: 
   Remarks:      
*/
extern void remove_folder_list_entry (struct folder_list *root,
				      struct folder_list *todel);


/*
   Function:     print_folder_list ()
   Remarks:      this function is for debug_reasons only
*/
extern void print_folder_list ();









