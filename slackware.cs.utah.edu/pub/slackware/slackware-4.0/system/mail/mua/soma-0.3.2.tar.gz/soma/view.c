/* 

   Project:     soma - stefan's own mail application 
   File:        view.c 
   Description: contains functions for view-window 
   Created:     09 Dec. 1995
   Changed:     $Date: 1996/02/23 11:42:27 $
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: view.c,v 1.11 1996/02/23 11:42:27 kuehnel Exp kuehnel $  
	$Author: kuehnel $
	$Log: view.c,v $
	Revision 1.11  1996/02/23 11:42:27  kuehnel
	Check in before a new release.

	Revision 1.10  1996/02/21 21:55:26  kuehnel
	new: set_view_msg_id, save_folder_proc
	the save-button has a menu attended now.

	Revision 1.9  1996/02/18 14:10:32  kuehnel
	Keine �nderungen (?).

	Revision 1.8  1996/02/01 21:18:01  kuehnel
	Neue Funktion: Set_View_Pos.

	Revision 1.7  1996/01/10 21:17:59  kuehnel
	Forward und Save gehen jetzt. Bug beim Doppelklick auf Mails bei
	offenem View-Fenster behoben.

 * Revision 1.6  1996/01/07  16:48:38  kuehnel
 * #include "machine.h" ergaenzt.
 *
 * Revision 1.5  1995/12/18  19:47:04  kuehnel
 * Jetzt mit destroy_func, die in die notifier-Kette eingehaengt wird.
 * Behebung des Bugs bei Schlie�en des Fensters ueber Window-Manager.
 *
 * Revision 1.4  1995/12/18  10:10:13  kuehnel
 * F�r noch nicht implementierte Funktionen wird jetzt eine Message
 * angezeigt.
 *
 * Revision 1.3  1995/12/11  20:27:26  kuehnel
 * Reply-Menu ge�ndert. Jetzt zwei verschiedene Notify-Prozeduren.
 *
 * Revision 1.2  1995/12/10  20:27:36  kuehnel
 * �berarbeitet.
 *
 * Revision 1.1  1995/12/09  20:39:24  kuehnel
 * Initial revision
 *
 	$Date: 1996/02/23 11:42:27 $ 
   ---------------------------------------------------------------------------

*/
#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/frame.h>
#include <xview/notify.h>
#include <xview/textsw.h>
#include <xview/file_chsr.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "compose.h"
#include "global.h"
#include "getmail.h"
#include "msg_box.h"
#include "folder_menu.h"
#include "machine.h"

Frame viewframe;
Textsw textsw;
Panel viewpanel;
Menu replymenu,savemenu,foldermenu;
char msg_id[STRSIZE];
int visible_view=0;

struct message current_msg;

/* Prototyp */

void save_chsr_callback (File_chooser fc, char *path,char *file, 
			 Xv_opaque client_data);

/*
   Function:     set_view_msg_id  
   Parameters:   char*
   Return-Value: 
   Remarks:      called by main
*/
void set_view_msg_id (char *msgid)
{
  strcpy (msg_id,msgid);
}


/*
   Function:     view_destroy_func
   Parameters:   -
   Return-Value: -
   Remarks:      called when vieframe is closed 
*/
Notify_value view_destroy_func(Notify_client clnt,Destroy_status status)
{
  if (status==DESTROY_CLEANUP)
    {
      visible_view=0;
      return notify_next_destroy_func (clnt,status);
    }
  else 
    return NOTIFY_DONE;
}



/*
   Function:     close_view
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
void close_view()
{
  
   xv_destroy_safe (viewframe);
   visible_view = 0;
}

/*
   Function:     reply_proc
   Parameters:   Menu menu
                 Menu_item menu_item
   Return-Value: -
   Remarks:      -
*/
void reply_proc (Menu menu,Menu_item menu_item)
{
  char rep_sub[255],returnpath[255];
  get_returnpath(returnpath);
  sprintf (rep_sub,"Re: %s",current_msg.subj);
  open_compose (returnpath,current_msg.returnpath,"\0",rep_sub);
  
}

/*
   Function:     reply_proc_incl
   Parameters:   Menu menu
                 Menu_item menu_item
   Return-Value: -
   Remarks:      -
*/
void reply_proc_incl (Menu menu,Menu_item menu_item)
{
  char rep_sub[255],returnpath[255];
  char mailfile[255],linestr[255],linestr2[255];
  FILE *fd;
  struct folder *af;

  get_returnpath(returnpath);
  af = get_active_folder ();
  strcpy (mailfile,af->folder_path);
  sprintf (rep_sub,"Re: %s",current_msg.subj);
  open_compose (returnpath,current_msg.returnpath,"\0",rep_sub);

  get_body_first_line (&fd,mailfile,current_msg.message_id);
  while ((get_body_line(fd,linestr))!=0)
    {
      sprintf (linestr2,": %s",linestr);
      insert_compose (linestr2);
    }
  set_compose_pos (0);
  fclose (fd);
  
}


/*
   Function:     forward_proc
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/
void forward_proc ()
{
  char rep_sub[255],returnpath[255];
  char mailfile[255],linestr[255],linestr2[255];
  FILE *fd;
  struct folder *af;

  get_returnpath(returnpath);
  af=get_active_folder();
  strcpy (mailfile,af->folder_path);
  sprintf (rep_sub,"Fwd: %s",current_msg.subj);
  open_compose (returnpath,"","\0",rep_sub);

  get_body_first_line (&fd,mailfile,current_msg.message_id);
  while ((get_body_line(fd,linestr))!=0)
    {
      sprintf (linestr2,": %s",linestr);
      insert_compose (linestr2);
    }
  set_compose_pos (0);
  fclose (fd);

}

void save_chsr_callback (File_chooser fc, char *path,char *file, 
			 Xv_opaque client_data)
{  
  textsw_store_file (textsw,path,100,100);

}  


/*
   Function:     save_proc
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/
void save_proc (Menu menu,Menu_item menu_item)
{
  File_chooser save_chsr;

  save_chsr=(File_chooser) 
    xv_create (0, 
	       FILE_CHOOSER_SAVE_DIALOG,
	       FILE_CHOOSER_NOTIFY_FUNC, save_chsr_callback,
	       NULL);
  xv_set (save_chsr,XV_SHOW,TRUE);

}

/*
   Function:     save_folder_proc
   Parameters:   -
   Return-Value: -
   Remarks:      Stores a message to a folder
*/
void save_folder_proc (Menu menu,Menu_item menu_item)
{
  char folder_name[STRSIZE],mailfile[STRSIZE],folder_path[STRSIZE];
  struct folder_list *flist;

  strcpy (folder_name,(char*)xv_get(menu_item,MENU_STRING));
  flist = get_folder_by_name (get_folder_list(),folder_name);
  strcpy (folder_path,flist->this_one.folder_path);
  printf ("Save to folder %s (%s)\n",folder_name,folder_path);
  get_mailfile(mailfile);

  if (strcmp(mailfile,folder_path)!=0)
    {
      if ((store_message (mailfile,folder_path,msg_id))==0)
	{
	  msg_box (viewframe,"Could not store the message to this folder!");
	}
    }
  else
    {
      msg_box (viewframe,"The message cannot be stored to this folder!");
    }
  
}
/*
   Function:     print_proc
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/
void print_proc ()
{
  char filename[STRSIZE],print_comm[STRSIZE],command[STRSIZE];

  tmpnam(filename);
  textsw_store_file (textsw,filename,10,10);
  get_printcommand(print_comm);
  sprintf (command,"%s %s",print_comm,filename);
  system (command);
  remove (filename);
 /*
    msg_box (viewframe,"Print: not yet implemented.\n");
 */
}



/*
   Function:     open_view
   Parameters:   -
   Return-Value: -
   Remarks:      Opens the view frame 
*/
void open_view(struct message msg)
{
  if (visible_view==0)
    {
      viewframe = (Frame) xv_create (0, FRAME, 
				     FRAME_LABEL, "Soma: View Message",
				     XV_SHOW,TRUE,
				     NULL);
      viewpanel = (Panel) xv_create (viewframe, PANEL, NULL);
      
      textsw = (Textsw) 
	xv_create (viewframe,TEXTSW,
		   TEXTSW_MEMORY_MAXIMUM, MEMMAX * 1024 ,
		   XV_SHOW,TRUE,
		   XV_X,0,
		   XV_Y,30,
		   TEXTSW_BROWSING, TRUE,           /* No edits are allowed */
		   TEXTSW_IGNORE_LIMIT, TEXTSW_INFINITY, /* No confirmation
							    on destroy! */
		   NULL);
      
      replymenu = (Menu) xv_create (0,MENU,
				    MENU_ITEM, 
				    MENU_STRING, "... include message",
				    MENU_NOTIFY_PROC, reply_proc_incl,
				    NULL,
				    MENU_ITEM,
				    MENU_STRING, "... don't include msg.",
				    MENU_NOTIFY_PROC, reply_proc,
				    NULL,
				    NULL);

      foldermenu = xv_create (0,MENU,NULL);
      fill_menu (foldermenu,get_folder_list());
      xv_set (foldermenu, MENU_NOTIFY_PROC, (void*)save_folder_proc, NULL);

      
      savemenu = (Menu) xv_create (0,MENU,
				   MENU_ITEM,
				   MENU_STRING, "to file",
				   MENU_NOTIFY_PROC, save_proc,
				   NULL,
				   MENU_ITEM,
				   MENU_STRING, "to folder",
				   MENU_PULLRIGHT, foldermenu,
				   NULL,
				   NULL);

      (void) xv_create (viewpanel, PANEL_BUTTON, 
			PANEL_NOTIFY_PROC, close_view,
			PANEL_LABEL_STRING, "Close",
			XV_Y,5,
			NULL);
      
      (void) xv_create (viewpanel, PANEL_BUTTON, 
			PANEL_ITEM_MENU, replymenu,
			PANEL_LABEL_STRING, "Reply...",
			XV_Y,5,
			NULL);
      
      (void) xv_create (viewpanel, PANEL_BUTTON, 
			PANEL_NOTIFY_PROC, forward_proc,
			PANEL_LABEL_STRING, "Forward",
			XV_Y,5,
			NULL);
      
      (void) xv_create (viewpanel, PANEL_BUTTON, 
			PANEL_ITEM_MENU, savemenu,
			PANEL_LABEL_STRING, "Save",
			XV_Y,5,
			NULL);
      
      (void) xv_create (viewpanel, PANEL_BUTTON, 
			PANEL_NOTIFY_PROC, print_proc,
			PANEL_LABEL_STRING, "Print",
			XV_Y,5,
			NULL);
    
      notify_interpose_destroy_func (viewframe,view_destroy_func);
      
      visible_view=1;
    }
  else
    {
      textsw_reset (textsw,100,100);
      /* textsw_delete (textsw,0,TEXTSW_INFINITY); */
    }
  current_msg = msg;
}



/*
   Function:     insert_view
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
void insert_view(char *line)
{
  char newline[255];
  sprintf (newline,"%s\n",line);

  textsw_insert (textsw,newline,strlen(newline));
}

/*
   Function:     set_view_pos 
   Parameters:   int pos
   Return-Value: -
   Remarks:      - 
*/
void set_view_pos (int pos)
{
  xv_set (textsw,TEXTSW_FIRST,pos,NULL); 

}
