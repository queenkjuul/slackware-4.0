/* 

   Project:     soma - stefan's own mail application 
   File:        folder_edit.h
   Description: Edit the folder list (Header-File)
   Created:     06.02.1996
   Changed:     $Date: 1996/02/18 14:03:52 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995,1996 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: folder_edit.h,v 1.1 1996/02/18 14:03:52 kuehnel Exp $
	$Author: kuehnel $
	$Log: folder_edit.h,v $
	Revision 1.1  1996/02/18 14:03:52  kuehnel
	Initial revision

 	$Date: 1996/02/18 14:03:52 $

   ---------------------------------------------------------------------------

*/

/*
   Function:     open_folder_ed
   Parameters:   Frame frame                - Frame of which folder_ed should 
                                              be a subframe
		 struct folder list *flist  - root pointer of folder list
   Return-Value: 
   Remarks:      
*/

extern void open_folder_ed (Frame frame, struct folder_list *flist);

/*
   Function:     folder_ed_close_proc
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/

extern void folder_ed_close_proc ();
