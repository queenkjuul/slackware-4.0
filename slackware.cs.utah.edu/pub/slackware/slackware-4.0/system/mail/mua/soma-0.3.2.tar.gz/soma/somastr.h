/* 

   Project:     soma - stefan's own mail application 
   File:        somastr.h
   Description: contains functions for string-handling
   Created:     03 Dec. 1995
   Changed:     03 Dec. 1995 
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: somastr.h,v 1.2 1995/12/11 20:28:36 kuehnel Exp $ 
	$Author: kuehnel $
	$Log: somastr.h,v $
 * Revision 1.2  1995/12/11  20:28:36  kuehnel
 * Keine �nderung.
 *
 * Revision 1.1  1995/12/03  23:13:09  kuehnel
 * Initial revision
 *
 * Revision 1.1  1995/12/03  23:13:09  kuehnel
 * Initial revision
 * 
 	$Date: 1995/12/11 20:28:36 $ 
   ---------------------------------------------------------------------------

*/

/*
   Function:     scopy
   Parameters:   char *str1 
                 char *str2
		 int from
   Return-Value: -
   Remarks:      copy all characters from position from to end from str1 to 
                 str2
*/
extern void scopy (char *str1,char *str2,int from);

/*
   Function:     sfill
   Parameters:   char *tofill - string to be filled
                 int nos - number of space
   Return-Value: -
   Remarks:      fills nos spaces in str "tofill"
*/

extern void sfill (char *tofill,int nos);

/*
   Function:     strim
   Parameters:   char *source - string to be trimmed
                 char *dest   - string to store result in
                 int len      - length of deststr
   Return-Value: -
   Remarks:      trims source to the length of des
*/

extern void strim (char *source,char *dest,int len);



