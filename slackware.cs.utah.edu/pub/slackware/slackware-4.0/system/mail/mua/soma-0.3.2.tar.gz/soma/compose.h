/* 

   Project:     soma - stefan's own mail application 
   File:        compose.h 
   Description: Header-File for compose.c
   Created:     10 Dec. 1995
   Changed:     $Date: 1996/02/18 13:59:40 $
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   To see 8-bit-characters type 'M-x standard-display-european'! 

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: compose.h,v 1.2 1996/02/18 13:59:40 kuehnel Exp $  
	$Author: kuehnel $
	$Log: compose.h,v $
	Revision 1.2  1996/02/18 13:59:40  kuehnel
	Keine �nderungen.

	Revision 1.1  1995/12/10 20:27:55  kuehnel
	Initial revision

 	$Date: 1996/02/18 13:59:40 $
   ---------------------------------------------------------------------------

*/

/*
   Function:     open_compose
   Parameters:   char *from - Sender
                 char *to   - Addressee
		 char *cc   - 2nd Addressee
		 char *subj - Subject
   Return-Value: 
   Remarks:      
*/
extern void open_compose(char *from,char *to, char *cc,char *subj);

/*
   Function:     insert_compose
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
extern void insert_compose(char *line);

/*
   Function:     set_compose_pos 
   Parameters:   int pos
   Return-Value: -
   Remarks:      - 
*/
extern void set_compose_pos (int pos);
