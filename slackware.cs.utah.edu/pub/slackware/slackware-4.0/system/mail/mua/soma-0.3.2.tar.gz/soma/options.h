/* 

   Project:     soma - stefan's own mail application 
   File:        options.h 
   Description: Header-File for options.c
   Created:     10 Dec. 1995
   Changed:     $Date: 1996/02/18 14:10:17 $
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   To see 8-bit-characters type 'M-x standard-display-european'! 

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: options.h,v 1.2 1996/02/18 14:10:17 kuehnel Exp $  
	$Author: kuehnel $
	$Log: options.h,v $
	Revision 1.2  1996/02/18 14:10:17  kuehnel
	Keine �nderungen (?).

	Revision 1.1  1995/12/10 20:29:06  kuehnel
	Initial revision

 	$Date: 1996/02/18 14:10:17 $
   ---------------------------------------------------------------------------

*/

/*
   Function:     open_option
   Parameters:   
   Return-Value: 
   Remarks:      
*/
extern void open_option (Frame baseframe);

