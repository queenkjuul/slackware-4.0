/* 

   Project:     soma - stefan's own mail application 
   File:        global.h 
   Description: contains definitions of global data
   Created:     01 Dec. 1995
   Changed:     01 Dec. 1995 
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: global.h,v 1.15 1996/06/15 10:14:46 kuehnel Exp $ 
	$Author: kuehnel $
	$Log: global.h,v $
	Revision 1.15  1996/06/15 10:14:46  kuehnel
	Versionsnummer angepasst

	Revision 1.14  1996/02/23 11:41:59  kuehnel
	Check in before a new release.

	Revision 1.13  1996/02/21 21:53:51  kuehnel
	removed: set/get_foldermenu
	new: fill_menu (previously in main.c)

	Revision 1.12  1996/02/18 14:07:28  kuehnel
	Neue Funktionen zum Speichern des aktiven Folders und des Folder-Menus.

	Revision 1.11  1996/02/04 21:53:39  kuehnel
	Neu: create_folder_list.

	Revision 1.10  1996/02/04 14:08:55  kuehnel
	Removed headers for get_sig_content and store_sig_file

	Revision 1.9  1996/02/04 14:06:18  kuehnel
	expand_path renamed to expand_tilde. Reason: there already exists a
	function called "expand_path" in libxview. This conflict lead to
	System-Warnings when running soma. To find this error needed > 10
	hours an a lot of nerves...

	Revision 1.8  1996/02/01 21:09:49  kuehnel
	Neue Funktion: expand_path

 * Revision 1.7  1996/01/07  14:19:25  kuehnel
 * Header fuer Zugriffsfunktiinen auf access_mode ergaenzt. Enum-Type
 * fuer access_mode.
 *
 * Revision 1.6  1995/12/19  23:30:08  kuehnel
 * Neue Prototypen fuer get_/set_timerval
 *
 * Revision 1.5  1995/12/17  19:35:14  kuehnel
 * Header zu global.c. Neu: ste/get_smtpserver
 *
 * Revision 1.4  1995/12/11  20:27:59  kuehnel
 * Header f�r die neuen Funktionen in "global.c".
 *
 * Revision 1.3  1995/12/10  20:28:36  kuehnel
 * Neue globale Variablen: mailfile, returnpath, sigfile, usesig
 *
 * Revision 1.2  1995/12/03  23:13:44  kuehnel
 * Einige Aenderungen an der struct msg_list
 *
 * Revision 1.1  1995/12/02  17:16:31  kuehnel
 * Initial revision
 *
 	$Date: 1996/06/15 10:14:46 $ 
   ---------------------------------------------------------------------------

*/

#define STRSIZE 255
#define MEMMAX  512        /* KB for Textsize in View & Compose-Window */
#define SIGSIZE 320        /* Bytes for Signature; due to "Nettiquette" this
			      shouldn't be more than 4*80=320 Bytes */

#define VERSION "0.3.2"

#include <xview/openmenu.h>
#include "folder.h"

/* Data structures */

struct message {
  char returnpath[STRSIZE];
  char message_id[STRSIZE];
  char date[STRSIZE];
  char from[STRSIZE];
  char to[STRSIZE];
  char subj[STRSIZE];
  char cc[STRSIZE];
  char status[STRSIZE];
};

struct msg_list {
  struct message actual;
  struct msg_list *next;
};

enum acc_modes { LOCAL, POP3 };


/* user information */

/*
   Function:     get_user_information
   Parameters:   -
   Return-Value: -
   Remarks:      initializes global variables by reading config-file or
                 system-information.
*/

extern void get_user_information ();


/* Functions for access on global-data */

/*
   Function:     get_mailfile
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void get_mailfile (char *value);

/*
   Function:     set_mailfile
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void set_mailfile (char *value);

/*
   Function:     get_printcommand
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void get_printcommand (char *value);

/*
   Function:     set_printcommand
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void set_printcommand (char *value);


/*
   Function:     get_returnpath
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void get_returnpath (char *value);

/*
   Function:     set_returnpath
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void set_returnpath (char *value);

/*
   Function:     get_sigfile 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void get_sigfile (char *value);

/*
   Function:     get_homedir 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void get_homedir (char *value);

/*
   Function:     get_hostname
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void get_hostname (char *value);


/*
   Function:     get_usesig
   Parameters:   -
   Return-Value: int
   Remarks:      
*/
extern int get_usesig (void);

/*
   Function:     set_usesig
   Parameters:   int
   Return-Value: -
   Remarks:      
*/
extern void  set_usesig (int value);

/*
   Function:     get_smtpserver
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void get_smtpserver (char *value);

/*
   Function:     set_smtpserver
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void set_smtpserver (char *value);

/*
   Function:     get_timerval 
   Parameters:   -
   Return-Value: int
   Remarks:      -
*/
extern int get_timerval ();

/*
   Function:     set_timerval
   Parameters:   int tv
   Return-Value: -
   Remarks:      -
*/
extern void set_timerval (int tv);

/*
   Function:     set_acc_mode
   Parameters:   enum acc_modes
   Return-Value: -
   Remarks:      -
*/
extern void set_acc_mode (enum acc_modes);

/*
   Function:     get_acc_mode
   Parameters:   -
   Return-Value: enum acc_modes
   Remarks:      -
*/
extern enum acc_modes get_acc_mode ();


/*
   Function:     expand_tilde
   Parameters:   char * - path to be expanded
   Return-Value: int - number of replaced characters
   Remarks:      replaces ~ with path to homedir
*/

extern int expand_tilde (char *path);

/*
   Function:     create_folder_list
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/

/*
   Function:     create_folder_list
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/
extern void create_folder_list (struct folder_list **flist);

/*
   Function:     add_config_folders
   Parameters:   -
   Return-Value: int - !0 if successful, 0 else
   Remarks:      Adds folders stored in the Config-File to the list
*/
extern int add_config_folders (struct folder_list **flist);

/*
   Function:     set_folder_list
   Parameters:   struct folder_list *
   Return-Value: -
   Remarks:      -
*/
extern void set_folder_list (struct folder_list *p);

/*
   Function:     get_folder_list 
   Parameters:   -
   Return-Value: struct folder_list *
   Remarks:      -
*/
extern struct folder_list* get_folder_list ();


/*
   Function:     set_active_folder
   Parameters:   struct folder - av;
   Return-Value: -
   Remarks:      -
*/
extern void set_active_folder (struct folder av);

/*
   Function:     get_active_folder
   Parameters:   -
   Return-Value: struct folder 
   Remarks:      -
*/
extern struct folder* get_active_folder ();

/*
   Function:     get_spool_file 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void get_spool_file (char *value);

/*
   Function:     set_spool_file 
   Parameters:   char *
   Return-Value: -
   Remarks:      -
*/
extern void set_spool_file (char *value);


