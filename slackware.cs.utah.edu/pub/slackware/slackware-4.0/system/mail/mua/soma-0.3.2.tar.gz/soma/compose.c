/* 

   Project:     soma - stefan's own mail application 
   File:        compose.c 
   Description: contains functions for compose-window 
   Created:     10 Dec. 1995
   Changed:     $Date: 1996/02/23 11:41:21 $
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   Emacs: to see 8-bit-characters type 'M-x standard-display-european'! 
   
   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: compose.c,v 1.11 1996/02/23 11:41:21 kuehnel Exp kuehnel $  
	$Author: kuehnel $
	$Log: compose.c,v $
	Revision 1.11  1996/02/23 11:41:21  kuehnel
	Check in before a new release.

	Revision 1.10  1996/02/01 21:16:23  kuehnel
	Send_Proc ge�ndert. Inhalt des Text-Subwindows wird jetzt in einem
	Puffer im Speicher zwischengespeichert. Nach dem Einfuegen wird die
	Textposition auf den Anfang der Datei gesetzt.

	Revision 1.9  1996/01/27 14:17:42  kuehnel
	Inhalt des Text-Subwindows wird vor dem Schreiben komplett in Buffer
	kopiert.

	Revision 1.8  1996/01/17 21:28:28  kuehnel
	Signatur-Datei (.signature) wird jetzt Zeile f�r Zeile eingelesen und
	eingefuegt. Methode mit TEXTSW_FILE_CONTENTS hatte fuer St�rungen
	gesorgt.

 * Revision 1.7  1996/01/07  16:47:38  kuehnel
 * #include "machine.h" ergaenzt.
 *
 * Revision 1.6  1995/12/18  19:48:41  kuehnel
 * Jetzt mit destroy_func. Erl�uterung siehe view.c.
 *
 * Revision 1.5  1995/12/18  10:11:57  kuehnel
 * Der Fehler, da� manchmal die Subject-Zeile im Body auftauchte, wurde
 * behoben.
 *
 * Revision 1.4  1995/12/17  15:46:36  kuehnel
 * Cc: funktioniert jetzt.
 *
 * Revision 1.3  1995/12/14  18:28:54  kuehnel
 * can send message via SMTP.
 *
 * Revision 1.2  1995/12/11  20:22:20  kuehnel
 * Debug-Informationen.
 * Text-Felder breiter.
 *
 * Revision 1.1  1995/12/10  20:25:57  kuehnel
 * Initial revision
 *
 	$Date: 1996/02/23 11:41:21 $
   ---------------------------------------------------------------------------

*/
#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/frame.h>
#include <xview/notify.h>
#include <xview/textsw.h>
#include <string.h>
#include <unistd.h>
#include "global.h"
#include "send.h"
#include "msg_box.h"
#include "machine.h"
#include "fileop.h"

Frame composeframe;
Textsw textsw;
Panel composepanel;
Panel_item inp_from, inp_to, inp_subj, inp_cc;
Menu sendmenu;

int visible_compose=0;

/*
   Function:     compose_destroy_func
   Parameters:   -
   Return-Value: -
   Remarks:      called when vieframe is closed 
*/
Notify_value compose_destroy_func(Notify_client clnt,Destroy_status status)
{
  if (status==DESTROY_CLEANUP)
    {
      visible_compose=0;
      return notify_next_destroy_func (clnt,status);
    }
  else 
    return NOTIFY_DONE;
}




/*
   Function:     close_proc
   Parameters:   -
   Return-Value: -
   Remarks:      closes compose_window without sending mail
*/
void close_proc ()
{
  xv_destroy_safe (composeframe);
  visible_compose = 0;

}

/*
   Function:     send_proc
   Parameters:   Menu menu
                 Menu_item menu_item
   Return-Value: int - 0 if OK, 1 if not
   Remarks:      send mail via internet connection to an rsmtpd
*/
int send_proc (Menu menu,Menu_item menu_item)
{
  int sock,cc_active=0,laenge;
  char buff[1024],line[4096],host[STRSIZE];
  char sender[STRSIZE],recipient[STRSIZE],subject[STRSIZE],ccline[2048];
  char *buffer;
  Textsw_index pos;
  

  strcpy(sender,(char *)xv_get(inp_from,PANEL_VALUE));
  strcpy(recipient,(char *)xv_get(inp_to,PANEL_VALUE));
  strcpy(subject,(char *)xv_get(inp_subj,PANEL_VALUE));
  strcpy(ccline,(char *)xv_get(inp_cc,PANEL_VALUE));

  cc_active=strlen(ccline); /* Trick: !=0 == TRUE */

  if (strlen(recipient)==0)
    {
      msg_box (composeframe, "You have to fill out the 'To:' field.");

      return 1;
    }
  else
    {
      laenge = (int) xv_get (textsw,TEXTSW_LENGTH);
      buffer = (char *) malloc (laenge+1);
      if (buffer!=NULL)
	{
	  pos = (Textsw_index) xv_get(textsw,TEXTSW_CONTENTS,0,buffer,laenge);
	  buffer[laenge+1]=(char)0;

	  close_proc();
	  
	  /* connect to rsmtpd */
	  
	  sock = init_sock();
	  read_from_socket (sock,buff,1024);
#ifdef DEBUG_COMPOSE
	  printf ("%s\n",buff);
#endif
	  
	  get_hostname(host); /* Name of localhost */
	  sprintf (line,"HELO %s\r\n",host);
	  write_to_socket (sock,line);
	  read_from_socket (sock,buff,1024);
#ifdef DEBUG_COMPOSE
	  printf ("%s\n",buff);
#endif
	  
	  sprintf (line,"MAIL FROM:%s\r\n",sender);
	  write_to_socket (sock,line);
	  read_from_socket (sock,buff,1024);
#ifdef DEBUG_COMPOSE
	  printf ("%s\n",buff);
#endif
	  
	  
	  sprintf (line,"RCPT TO:%s\r\n",recipient);
	  write_to_socket (sock,line);
	  read_from_socket (sock,buff,1024);
#ifdef DEBUG_COMPOSE
	  printf ("%s\n",buff);
#endif
	  
	  /* some more recipients are given in the ccline */
	  
	  if (cc_active)
	    {
	      int i=0,j=0;
	      char name[STRSIZE];
	      
#ifdef DEBUG_COMPOSE
	      printf ("ccline: %s\n",ccline);
#endif
	      
	      for (i=0;i<=cc_active;i++)
		{
		  if ((ccline[i]!=',')&&(ccline[i]!='\n')&&(ccline[i]!='\0'))
		    name[j++]=ccline[i];
		  else 
		    {
		      name[j]='\0';
	      
#ifdef DEBUG_COMPOSE
		      printf ("ccname erkannt: %s\n",name);
#endif
		      j=0;
		      sprintf (line,"RCPT TO:%s\r\n",name);
		      write_to_socket (sock,line);
		      read_from_socket (sock,buff,1024);
#ifdef DEBUG_COMPOSE
		      printf ("%s\n",buff);
#endif
		    }
		}
	      
	    }
	  write_to_socket(sock,"DATA\r\n");
	  read_from_socket (sock,buff,1024);
#ifdef DEBUG_COMPOSE
	  printf ("%s\n",buff);
#endif
	  /* Mail begins here */
	  sprintf (line,"From: %s\r\n",sender);
	  write_to_socket (sock,line);
	  
	  sprintf (line,"To: %s\r\n",recipient);
	  write_to_socket (sock,line);
	  if (cc_active)
	    {
	      sprintf (line,"Cc: %s\r\n",ccline);
	      write_to_socket (sock,line);
	    }
	  sprintf (line,"Subject: %s\r\n\n",subject);
	  write_to_socket (sock,line);
	  write_to_socket (sock,buffer); /* Body der Mail !!! */
	  /* Mail ends here */
	  write_to_socket(sock,"\n.\r\n");
	  read_from_socket (sock,buff,1024);
#ifdef DEBUG_COMPOSE
	  printf ("%s\n",buff);
#endif  
	  write_to_socket(sock,"QUIT\r\n");
	  read_from_socket (sock,buff,1024);
#ifdef DEBUG_COMPOSE
	  printf ("%s\n",buff);
#endif
	  close (sock);
	  
	  xv_set (textsw,TEXTSW_IGNORE_LIMIT,TEXTSW_INFINITY,NULL);
	  
	  free (buffer);
	}
      else
	{
	  msg_box (composeframe ,"Not enough memory to perform this action!");
	}
      return 0; /* OK */
    }

}

/*
   Function:     send_spooled_proc
   Parameters:   Menu menu
                 Menu_item menu_item
   Return-Value: 
   Remarks:      store mail for later sending
*/
int send_spooled_proc (Menu menu,Menu_item menu_item)
{

  char spoolfile[STRSIZE];
  char host[STRSIZE];
  char sender[STRSIZE],recipient[STRSIZE],subject[STRSIZE],ccline[2048];
  char *buffer;
  int  laenge,cc_active;
  FILE *spool_fd;
  Textsw_index pos;
  

  /* Get the recipients name, the subject and so on */
  strcpy(sender,(char *)xv_get(inp_from,PANEL_VALUE));
  strcpy(recipient,(char *)xv_get(inp_to,PANEL_VALUE));
  strcpy(subject,(char *)xv_get(inp_subj,PANEL_VALUE));
  strcpy(ccline,(char *)xv_get(inp_cc,PANEL_VALUE));
  get_hostname(host); /* Name of localhost */
  cc_active=strlen(ccline); /* Trick: !=0 == TRUE ; more than one recipien? */

  get_spool_file (spoolfile);
  if ((spool_fd=fopen(spoolfile,"a"))!=NULL)
    {
      laenge = (int) xv_get (textsw,TEXTSW_LENGTH);
      buffer = (char *) malloc (laenge+1);
      if (buffer!=NULL)
	{
	  pos = (Textsw_index) xv_get(textsw,TEXTSW_CONTENTS,0,buffer,laenge);
	  buffer[laenge+1]=(char)0;
	  close_proc();
	  
	  if (strlen(recipient)==0)
	    {
	      msg_box (composeframe, "You have to fill out the 'To:' field.");
	      
	      return 1;
	    }
	  else
	    {
	      fprintf (spool_fd,"HELO FROM %s\r\n",host);
	      fprintf (spool_fd,"MAIL FROM:%s\r\n",sender);
	      fprintf (spool_fd,"RCPT TO:%s\r\n",recipient);
	      if (cc_active)
		{
		  int i=0,j=0;
		  char name[STRSIZE];
		  for (i=0;i<=cc_active;i++)
		    {
		      if ((ccline[i]!=',')&&(ccline[i]!='\n')&&(ccline[i]!='\0'))
		      name[j++]=ccline[i];
		      else 
		      {
			name[j]='\0';
			j=0;
			fprintf (spool_fd,"RCPT TO:%s\r\n",name);
		      }
		    }
		}
	      fprintf (spool_fd,"DATA\n");
	      /* Mail begins here */
	      fprintf (spool_fd,"From: %s\r\n",sender);
	      fprintf (spool_fd,"To: %s\r\n",recipient);
	      if (cc_active)
		{
		  fprintf (spool_fd,"Cc: %s\r\n",ccline);
		}
	      fprintf (spool_fd,"Subject: %s\r\n\n",subject);
	      fprintf (spool_fd,buffer); /* Body der Mail !!! */
	      fprintf (spool_fd,"QUIT\n");
	      xv_set (textsw,TEXTSW_IGNORE_LIMIT,TEXTSW_INFINITY,NULL);
	      free (buffer);
	    }
	}
      fclose (spool_fd);
    }
  else
    {
      char message[STRSIZE];
      sprintf (message,"Could not open %s for write",spoolfile);
      msg_box (composeframe,message);
    }
  return 0;
}

/*
   Function:        
   Parameters:   
   Return-Value: 
   Remarks:      
*/


/*
   Function:     open_compose
   Parameters:   char *from - Sender
                 char *to   - Addressee
		 char *cc   - 2nd Addressee
		 char *subj - Subject
   Return-Value: 
   Remarks:      
*/
void open_compose(char *from,char *to, char *cc,char *subj)
{

  FILE *sf;

#ifdef DEBUG_COMPOSE
  printf("open_compose: Paramters: %s,%s,%s,%s\n",from,to,cc,subj);
#endif

  if (visible_compose==0)
    {
      composeframe = (Frame) xv_create (0,FRAME,
					FRAME_LABEL,"Soma: Compose Message",
					XV_SHOW, TRUE,
					NULL);

      
#ifdef DEBUG_COMPOSE
      printf ("compose.c: composeframe ok\n");
#endif

      composepanel = (Panel) xv_create (composeframe, PANEL, NULL);

#ifdef DEBUG_COMPOSE
      printf ("compose.c: composepanel ok\n");
#endif
      /* Buttons */
      
      (void) xv_create (composepanel, PANEL_BUTTON,
			PANEL_NOTIFY_PROC, close_proc,
			PANEL_LABEL_STRING, "Close",
			XV_Y,5,
			NULL);

      sendmenu = (Menu) xv_create (0,MENU,
				   MENU_ITEM,
				     MENU_STRING, "Send now",
				     MENU_NOTIFY_PROC, send_proc,
				     NULL,
				   MENU_ITEM,
				     MENU_STRING, "Spool for later sending",
				     MENU_NOTIFY_PROC, send_spooled_proc,
				     NULL,
				   NULL);

      (void) xv_create (composepanel, PANEL_BUTTON,
			PANEL_ITEM_MENU, sendmenu,
			PANEL_LABEL_STRING, "Send",
			XV_Y,5,
			NULL);
#ifdef DEBUG_COMPOSE
      printf ("compose.c: buttons ok\n");
#endif
      /* Entry-Felder */
      
#ifdef DEBUG_COMPOSE
      printf ("compose.c: going to make entries\n");
#endif

      inp_from = (Panel_item) xv_create (composepanel, PANEL_TEXT,
					 PANEL_LABEL_STRING, "From:",
					 PANEL_VALUE, from,
					 PANEL_LABEL_WIDTH, 50,
					 PANEL_VALUE_DISPLAY_WIDTH, 500,
					 XV_Y, 30,
					 XV_X, 5,
					 NULL);
#ifdef DEBUG_COMPOSE
      printf ("compose.c: inp_from (%s) ok \n",from);
#endif


      inp_to = (Panel_item) xv_create (composepanel, PANEL_TEXT,
				       PANEL_LABEL_STRING, "To:",
				       PANEL_VALUE, to,
				       PANEL_LABEL_WIDTH, 50,
				       PANEL_VALUE_DISPLAY_WIDTH, 500,
				       XV_Y, 55, 
				       XV_X, 5, 
				       NULL);

#ifdef DEBUG_COMPOSE
      printf ("compose.c: inp_to (%s) ok \n",to);
#endif

      inp_cc = (Panel_item) xv_create (composepanel, PANEL_TEXT,
				       PANEL_LABEL_STRING, "CC:",
				       PANEL_VALUE, cc,
				       PANEL_LABEL_WIDTH, 50,
				       PANEL_VALUE_DISPLAY_WIDTH, 500,
				       XV_Y, 80, 
				       XV_X, 5, 
				       NULL);

#ifdef DEBUG_COMPOSE
      printf ("compose.c: inp_cc (%s) ok \n",cc);
#endif


      inp_subj = (Panel_item) xv_create (composepanel, PANEL_TEXT,
				       PANEL_LABEL_STRING, "Subj.:",
				       PANEL_VALUE, subj,
				       PANEL_LABEL_WIDTH, 50,
				       PANEL_VALUE_DISPLAY_WIDTH, 500,
				       XV_Y, 105, 
				       XV_X, 5, 
				       NULL);
#ifdef DEBUG_COMPOSE
      printf ("compose.c: inp_subj (%s) ok \n",subj);
#endif

#ifdef DEBUG_COMPOSE
      printf ("compose.c: going to make textwindow \n");
#endif


      /* Text Subwindow */
      
      textsw = (Textsw) xv_create (composeframe, TEXTSW,
				   TEXTSW_MEMORY_MAXIMUM, MEMMAX * 1024 ,
				   XV_SHOW,TRUE,
				   XV_X,0,
				   XV_Y,130,
				   NULL);

      notify_interpose_destroy_func (composeframe,compose_destroy_func);

#ifdef DEBUG_COMPOSE
      printf ("compose.c: textwindow ok \n");
#endif

      if (get_usesig())
	{ 
	  char fill[STRSIZE],sigfile[STRSIZE],sigline[STRSIZE];

#ifdef DEBUG_COMPOSE
	  printf ("compose.c: trying to insert signature \n");
#endif

	  sprintf (fill,"\n---\n");
	  get_sigfile(sigfile);

#ifdef DEBUG_COMPOSE
	  printf ("compose.c: sprintf and get_sigfile (%s) ok \n",sigfile);
#endif

	  if ((sf=fopen(sigfile,"r"))!=NULL)
	    {
	      while (!feof(sf))
		{
		  read_to_nl (sf,sigline);
		  strcat (sigline,"\n");
		  textsw_insert (textsw,sigline,strlen(sigline));
		 /*  xv_set(textsw,TEXTSW_FILE_CONTENTS,sigfile,TEXTSW_FIRST,0,NULL); */
		}
				 
	    }
#ifdef DEBUG_COMPOSE
	  printf ("compose.c: TEXTSW_FILE_CONTENTS ok\n");
#endif
	  xv_set(textsw,TEXTSW_INSERTION_POINT,0,NULL);	  
	  textsw_insert (textsw,fill,strlen(fill));

#ifdef DEBUG_COMPOSE
	  printf ("compose.c: textsw_insert (textsw,fill,strlen(fill)) ok\n");
#endif
	  xv_set(textsw,TEXTSW_INSERTION_POINT,0,NULL);	  
	  
	}
      visible_compose = 1;
     
    }
  else
    {

    }
}

/*
   Function:     insert_compose
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
void insert_compose(char *line)
{
  char newline[STRSIZE];
  sprintf (newline,"%s\n",line);

  textsw_insert (textsw,newline,strlen(newline));
}

/*
   Function:     set_compose_pos 
   Parameters:   int pos
   Return-Value: -
   Remarks:      - 
*/
void set_compose_pos (int pos)
{
  xv_set (textsw,TEXTSW_FIRST,pos,NULL);

}





























