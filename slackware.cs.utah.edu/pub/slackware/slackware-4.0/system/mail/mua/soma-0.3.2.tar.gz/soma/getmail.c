/* 

   Project:     soma - stefan's own mail application 
   File:        getmail.c 
   Description: contains function to read the user's mail-file
   Created:     01 Dec. 1995
   Changed:     $Date: 1996/06/18 17:23:14 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995,1996 by Stefan K�hnel

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: getmail.c,v 1.16 1996/06/18 17:23:14 kuehnel Exp $ 
	$Author: kuehnel $
	$Log: getmail.c,v $
	Revision 1.16  1996/06/18 17:23:14  kuehnel
	mechanism to recognize a header redesigned. I hope it's conforming
	RFC0822 now!

	Revision 1.15  1996/06/18 15:29:32  kuehnel
	Aenderungen, um endlich RFC822-Konformitaet zu erhalten...
	Nach RFC822 besteht der minimale Header aus Date:, From: und Bcc:
	bzw. To:.

	Revision 1.14  1996/03/04 17:33:57  kuehnel
	Now a header is recognized even without an return-path: entry.

	Revision 1.13  1996/02/21 21:55:57  kuehnel
	store message debugged

	Revision 1.12  1996/02/18 14:04:19  kuehnel
	Testweise �nderungen zum Aufsp�ren des folgenden Problems: getmail erkennt
	eine Mail nur, wenn mindestens 6 Header-Elemente vorhanden sind.

	Revision 1.11  1996/02/01 21:22:11  kuehnel
	Neue Funktion: store_message (ungetestet!)

 * Revision 1.10  1996/01/07  16:48:11  kuehnel
 * #include "machine.h" ergaenzt.
 *
 * Revision 1.9  1996/01/07  16:06:37  kuehnel
 * Debug-Ausgabe entfernt.
 *
 * Revision 1.8  1996/01/07  14:14:26  kuehnel
 * delete_message eingebaut.
 *
 * Revision 1.7  1995/12/18  10:13:35  kuehnel
 * Es werden jetzt auch CC:- (alternativ cc: oder Cc:) Felder im Header
 * erkannt und in die msg-Struktur eingetragen.
 *
 * Revision 1.6  1995/12/11  20:23:21  kuehnel
 * Komplett umgestellt, da alte Version nicht mit PINE-generierten
 * Messages zurechtkam. Reihenfolge der Schl�sselw�rter im Header
 * ist jetzt egal. Au�erdem wird die PINE-Variante "Message-ID" statt "Message-Id" verarbeitet.
 *
 * Revision 1.5  1995/12/10  20:26:44  kuehnel
 * Einige Routinen nach "fileop.c" ausgelagert.
 *
 * Revision 1.4  1995/12/09  20:40:04  kuehnel
 * get_msg_body_line usw. funktionieren jetzt ausgezeichnet.
 *
 * Revision 1.3  1995/12/06  23:49:10  kuehnel
 * Funktion get_body angefangen. Kann bereits Message-ID aus msg_list finden.
 *
 * Revision 1.2  1995/12/03  23:12:04  kuehnel
 * Funktioniert jetzt ohne lex-Scanner.
 *
 * Revision 1.1  1995/12/02  17:15:00  kuehnel
 * Initial revision
 *
 	$Date: 1996/06/18 17:23:14 $ 
   ---------------------------------------------------------------------------

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>

#include "global.h"
#include "somastr.h"
#include "fileop.h"
#include "msg_box.h"
#include "machine.h"

/* Global variables */

int body_line = 0;



int isheader_begin (char *ln)
{
  if ((ln[0]=='F')&&(ln[1]=='r')&&(ln[2]=='o')&&(ln[3]=='m')&&(ln[4]==' '))
    return (1);
  else
    return (0);
}

/*
   Function:     scans the mailfile for headers and stores the 
                 header's informations in a list
   Parameters:   char *mailfile  - name of the user's mailfile
                 msg_list **root - pointer to the start of the lisr
   Return-Value: int             - number of messages found in the mailfile
   Remarks:      
*/
int read_mail_file (char *mailfile,struct msg_list **root)
{
  
  struct msg_list *buffer,*tmp_ptr;
  FILE *fd;
  char line [1024];
  int countmsg=0,date=0,from=0,to=0,head_complete=0;
  
  if ((fd=fopen(mailfile,"r")))
    {
      read_to_nl(fd,line);
      while (!feof(fd))
	{
	 
	  while ((isheader_begin(line)==0)&&(!feof(fd)))
	    {
	      read_to_nl(fd,line);
	    } 

	  if (!feof(fd))
	    {
		 
	      if (isheader_begin(line)==1)
		{
		  buffer = (struct msg_list*)malloc(sizeof(struct msg_list));
		  buffer->next=NULL;
		  buffer->actual.returnpath[0]='\0';
		  buffer->actual.message_id[0]='\0';
		  buffer->actual.date[0]='\0';
		  buffer->actual.from[0]='\0';
		  buffer->actual.subj[0]='\0';
		  buffer->actual.cc[0]='\0';
		  buffer->actual.status[0]='\0';

		   if (*root==NULL) 
 		    { 
 		      *root=buffer; 
 		    } 
 		  else 
 		    { 
 		      tmp_ptr=*root; 
 		      while (tmp_ptr->next!=NULL) tmp_ptr=tmp_ptr->next; 
 		      tmp_ptr->next=buffer; 
 		    } 
		  countmsg++;
		  
		  date=from=to=head_complete=0;

		  do
		    {
		      
		      do
			{
			  int num;
			  if (((num=read_to_nl(fd,line))==0)&&!feof(fd))
			    {
			      if (from+date+to==3)
				{
				  head_complete=1;
				  from=to=date=0;
				}
			    }
			} 
		      while ((match("Return-Path:",line)==0)
			     &&(match("Message-Id:",line)==0)
			     &&(match("Message-ID:",line)==0)
			     &&(match("Date:",line)==0)
			     &&(match("From:",line)==0)
			     &&(match("Apparently-From:",line)==0)
			     &&(match("Apparently-To:",line)==0)
			     &&(match("To:",line)==0)
			     &&(match("Cc:",line)==0)
			     &&(match("CC:",line)==0)
			     &&(match("cc:",line)==0)
			     &&(match("Bcc:",line)==0)
			     &&(match("Subject:",line)==0)
			     &&(isheader_begin(line)==0)
			     &&(!feof(fd)));

		      if (match("Return-Path:",line))
			{
			  scopy (line,buffer->actual.returnpath,13);
			}
		      else if ((match("Message-Id:",line))||(match("Message-ID:",line)))
			{
			  scopy (line,buffer->actual.message_id,strlen("Message-Id:")+1);
			}
		      else if (match("Date:",line))
			{
			  scopy (line,buffer->actual.date,strlen("Date:")+1);
			  date=1;
			}
		      else if (match("From:",line))
			{
			  scopy (line,buffer->actual.from,strlen("From:")+1);
			  from=1;
			}
		      else if (match("Apparently-From:",line))
			{
			  scopy (line,buffer->actual.from,strlen("Apparently-From:")+1);
			  from=1;
			}
		      else if (match("To:",line))
			{
			  scopy (line,buffer->actual.to,strlen("To:")+1);
			  to=1;
			}
		      else if ((match("Cc:",line))||(match("cc:",line))||(match("CC:",line)))
			{
			  scopy (line,buffer->actual.cc,strlen("CC:")+1);
			  to=1;
			}
		      else if (match("Bcc:",line))
			{
			  to=1;
			}
		      else if (match("Apparently-To:",line)) 
			{
			  scopy (line,buffer->actual.to,strlen("Apparently-To:")+1);
			  to=1;
			}
		      else if (match("Subject:",line))
			{
			  scopy (line,buffer->actual.subj,strlen("Subject:")+1);
			}
		    } 
		  while ((!feof(fd))&&(!head_complete)&&(isheader_begin(line)==0));
		}
	    }
	} /* while (!feof(fd)) */
      fclose (fd);
    }  
  else /* if (fopen ...) */
    {
      fprintf (stderr,"soma: couldn't open mailfile '%s'\nCheck if environment-variable MAIL contains the path to your mailfile\n",mailfile);
      exit(-1);
    }
  return countmsg;
}



/*
   Function:     get_msg_list_entry
   Parameters:   struct msg_list *root -
                 int list_index        - First Element is #1!
                 struct message *ret   -
   Return-Value: int
   Remarks:      
*/

int get_msg_list_entry (struct msg_list *root, int list_index, struct message *ret) 
{
  int i=1;
  struct msg_list *tmp_ptr;
  
  tmp_ptr=root;
  
  while ((i<list_index)&&(tmp_ptr!=NULL)) 
    {
      tmp_ptr=tmp_ptr->next;
      i++;
    }
  
  *ret=tmp_ptr->actual;
  
  return 0;

}

/*
   Function:     get_msg_id
   Parameters:   struct msg_list *root 
                 int list_index
                 char *msg_id 
   Return-Value: int
   Remarks:      
*/

int get_msg_id (struct msg_list *root,int list_index, char *msg_id)
{
  int i=1;
  struct msg_list *tmp_ptr=root;

  while ((i<list_index)&&(tmp_ptr!=NULL)) 
    {
      tmp_ptr=tmp_ptr->next;
      i++;
    }
  sprintf(msg_id,"%s",tmp_ptr->actual.message_id);

  return 0;
}


/*
   Function:     get_body_first_line
   Parameters:   FILE **fd      - filedescriptor of mailfile is returned
                 char *mailfile - name of mailfile
                 char *msg_id   - msg_id
   Return-Value: int            - not zero if found, else zero
   Remarks:      searching for first body line of message with given id
*/

int get_body_first_line (FILE **fd, char *mailfile, char *msg_id)
{
  char actual_msg_id[255];
  char line[STRSIZE],c1,c2;

  if ((*fd=fopen(mailfile,"r"))!=NULL)
    {
     
      do
	{
	  do
	    {
	      read_to_nl(*fd,line);
	    } 
	  while ((match("Message-Id:",line)==0)&&(match("Message-ID:",line)==0)&&(!feof(*fd)));

	  /* Pine marks message-id's with 'Message-ID' instead of 
	     'Message-Id' */
	  scopy (line,actual_msg_id,strlen("Message-Id:")+1);
#ifdef DEBUG_GETMAIL
	  printf ("gesuchte Msg-ID: %s\n",msg_id);
	  printf ("aktuelle Msg-ID: %s\n",actual_msg_id);
#endif
	}
      while ((strcmp(actual_msg_id,msg_id)!=0)&&(!feof(*fd)));

      /* Body starts with a single newline */

      c1=fgetc(*fd);
      do
	{
	  c2=c1;
	  c1=fgetc(*fd);
	}
      while ((c1!='\n')||(c2!='\n'));
    }
  if (feof(*fd)) 
    {
      fclose(*fd); return 0;
    }
  else return 1;
}

/*
   Function:     get_body_line
   Parameters:   FILE *fd   - filedescriptor of mailfile     
                 char *line - returned line
   Return-Value: int        - not zero if found, else zero
   Remarks:      
*/

int get_body_line (FILE *fd, char *line)
{
  read_to_nl (fd,line);
  
  if ((isheader_begin(line))||(feof(fd)))
      {
	return 0;
      }
  else
      {
	return 1;
      }
}

/*
   Function:     next_header;
   Parameters:   FILE *fd    Valid Filedscriptor       
   Return-Value: long int    Dateiposition unmittelbar vor dem Headerbeginn
   Remarks:      
*/
long int next_header (FILE *fd)
{
  long int act_pos;
  char zeile[STRSIZE];

  do
    {
      act_pos = ftell (fd);
      read_to_nl (fd,zeile);
    }
  while ((isheader_begin(zeile)==0)&&(!feof(fd)));
  
  if (!feof(fd)) return act_pos; else return ftell(fd)-1;
}

/*
   Function:     next_msg_id;
   Parameters:   FILE *fd    Valid Filedscriptor
                 char *id    char array to return the message id in
   Return-Value: 
   Remarks:      
*/
void  next_msg_id (FILE *fd, char *id)
{
  char zeile[STRSIZE];

  do
    {
      read_to_nl (fd,zeile);
    }
  while ((match("Message-Id:",zeile)==0)&&(match("Message-ID:",zeile)==0)&&(!feof(fd)));
  scopy (zeile,id,strlen("Message-Id:")+1);
}


/*
   Function:     delete_message
   Parameters:   char *mailfile, name of the mailfile from which to delete
                 char *msg_id,   id of message to be deleted
   Return-Value: 0  - message could not be deleted
                 !0 - succes
   Remarks:      
*/
int delete_message (char *mailfile, char *msg_id)
{
  FILE *fd,*tmp_file;
  long int act_pos, beg_pos=0,end_pos=0;
  int found,c,mailfiledeleted=0,ok=0;
  char local_msg_id[STRSIZE],tmp_file_name[L_tmpnam];
  struct stat file_stat;

  /* Suchen der Anfangs- und End-Position der zu loeschenden Mail
     im Mail-File */

  if ((fd=fopen(mailfile,"r+"))!=NULL)
    {

      found=0;
      while ((!feof(fd))&&(found==0))
	{
	  beg_pos = next_header(fd);
	  next_msg_id (fd,local_msg_id);
	  if (strcmp(local_msg_id,msg_id)==0) found=1;
	}
      if (found==1) end_pos = next_header(fd);
      else end_pos=0;

      /* copy the old mail_file to a temporary file */

      if ((beg_pos>=0)&&(end_pos>0))
	{
	  tmpnam(tmp_file_name);
	  
#ifdef DEBUG_GETMAIL
	  printf ("temporary-file: %s \n",tmp_file_name);
#endif
	  tmp_file=fopen(tmp_file_name,"w+"); /* Create a tmp_file */
	
	  rewind (fd);

#ifdef DEBUG_GETMAIL	
	  printf ("Kopieren au�er von %ld bis %ld \n",beg_pos,end_pos);
#endif
	  while (!feof(fd))
	    {
	      act_pos = ftell(fd);
	      c = fgetc(fd);
	      if (!((act_pos>=beg_pos)&&(act_pos<end_pos)))
		{
		  if (!feof(fd)) fputc (c,tmp_file);
		}
	      }
	  fclose (tmp_file);
	  fclose (fd);

	  /* Delete Mailfile */

	  stat (mailfile,&file_stat); /* Get Modus of mail-file */

	  if ((remove (mailfile)!=0)) 
	    {
	      fprintf (stderr,"Could not remove %s!\n",mailfile);
	      mailfiledeleted=0;
	    }
	  else 
	    {
	      mailfiledeleted=1;
	    }

	  /* move or copy tmp_file to mailfile */

	  if ((rename (tmp_file_name,mailfile))!=0)
	    {
	      /* rename klappt nicht �ber Partitionsgrenzen hinweg */
	      
	      ok=0;

	      if (file_copy (tmp_file_name,mailfile)==0)
		{
		  ok=1;
		}
	      else
		{
		  fprintf (stderr,"Soma Error: Could neither move nor copy %s to %s\n",tmp_file_name,mailfile);
		}
	    }
	  else
	    {
	      ok=1;
	    }

	  if (ok) remove(tmp_file_name); 
	        
	  chmod (mailfile,file_stat.st_mode); /* restore the mode of 
                                               old-mailfile */  
	
	  return 1;
	}
      else
	{
	  /* failure */

	  fclose (fd);
	  return 0;
	}
    }

  return 0;
}


/*
   Function:     store_message
   Parameters:   char *mailfile
                 char *folder
                 char *msg_id
   Return-Value: 0 - Message could not be stored
                 !0 - Message was successfully stored
   Remarks:      Stores message with id msg_id from 
                 mailfile in an alternative folder
*/


int store_message (char *mailfile, char *folder, char *msg_id)
{

  FILE *fd_folder,*fd_mailfile;
  int found;
  long int beg_pos=0,end_pos=0,pos;
  char local_msg_id[STRSIZE], msg[STRSIZE];;

  if ((fd_mailfile=fopen(mailfile,"r+"))!=NULL)
    {
      found=0;
      while ((!feof(fd_mailfile))&&(found==0))
	{
	  beg_pos = next_header(fd_mailfile);
	  next_msg_id (fd_mailfile,local_msg_id);
	  if (strcmp(local_msg_id,msg_id)==0) found=1;
	}
      if (found==1) end_pos = next_header(fd_mailfile);
      else end_pos=0;

      if ((fd_folder=fopen(folder,"a"))!=NULL)
	{
	  fseek (fd_mailfile,beg_pos,SEEK_SET);
	  fgetpos(fd_mailfile,&pos);
	  while ((pos>=beg_pos)&&(pos<end_pos))
	    {
	      fputc(fgetc(fd_mailfile),fd_folder);
	      fgetpos(fd_mailfile,&pos);
	    }
	  fclose (fd_folder);
	}
      else
	{
	   sprintf (msg,"Could not open %s !",folder);
	   msg_box (0,msg);
	   fclose (fd_mailfile);
	   return 0;
	}
      fclose (fd_mailfile);
      return 1;
    }
  else
    {
      sprintf (msg,"Could not open %s !",mailfile);
      msg_box (0,msg);
      return 0;
    }

}









