/* 

   Project:     soma - stefan's own mail application 
   File:        options.c 
   Description: contains functions for options-window 
   Created:     10 Dec. 1995
   Changed:     $Date: 1996/02/23 11:42:21 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   To see 8-bit-characters type 'M-x standard-display-european'! 

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: options.c,v 1.11 1996/02/23 11:42:21 kuehnel Exp kuehnel $  
	$Author: kuehnel $
	$Log: options.c,v $
	Revision 1.11  1996/02/23 11:42:21  kuehnel
	Check in before a new release.

	Revision 1.10  1996/02/18 14:09:58  kuehnel
	Neu: Aufruf des Folder-Editors.

	Revision 1.9  1996/02/04 00:33:18  kuehnel
	Behobene Fehler: Anklicken der Buttons des numeric_text_item fuehrt
	nicht mehr zum Absturz. Wert fuer Timer_intervall wird jetzt beim
	Schliessen des Fensters korrekt in die entspr. globale Variable
	uebertragen.

	Revision 1.8  1996/02/01 21:13:01  kuehnel
	Signature-Eingabe jetzt in einem mehrzeiligen Editierfeld statt in
	einem Text-Subwindow. Beim Speichern des Pfades zum Mail-File wird
	jetzt auch das Sonderzeichen "~" ausgewertet.

 * Revision 1.7  1996/01/07  16:48:27  kuehnel
 * #include "machine.h" ergaenzt.
 *
 * Revision 1.6  1995/12/19  23:27:03  kuehnel
 * Neues Eingabefeld fuer die Zeitintervalle des New-Mail-Checks.
 *
 * Revision 1.5  1995/12/18  19:50:46  kuehnel
 * Jetzt mit destroy_func.
 *
 * Revision 1.4  1995/12/17  19:35:40  kuehnel
 * Neu: Eingabe-Feld f�r SMTP-Server
 * Neu: Cancel-Button
 *
 * Revision 1.3  1995/12/14  18:30:01  kuehnel
 * minor changes.
 *
 * Revision 1.2  1995/12/11  20:25:44  kuehnel
 * Nur kleinere �nderungen (betreffen haupts�chlich Anzeige der
 * Signature).
 *
 * Revision 1.1  1995/12/10  20:27:20  kuehnel
 * Initial revision
 *
 	$Date: 1996/02/23 11:42:21 $
   ---------------------------------------------------------------------------

*/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/frame.h>
#include <xview/notify.h>
#include <xview/textsw.h>
#include <string.h>
#include <signal.h>
#include "global.h"
#include "folder_edit.h"
#include "machine.h"

Frame optionframe;
Panel optionpanel;
Panel_item inp_retpath,inp_mailfile,inp_smtpserver,inp_timer,cb,inp_printcomm;
Panel_item inp_spoolfile;
Textsw edit_signature;
int option_visible=0;

/*
   Function:     option_destroy_func
   Parameters:   -
   Return-Value: -
   Remarks:      called when optionframe is closed 
*/
Notify_value option_destroy_func(Notify_client clnt,Destroy_status status)
{
  if (status==DESTROY_CLEANUP)
    {
      option_visible=0;
      return notify_next_destroy_func (clnt,status);
    }
  else 
    return NOTIFY_DONE;
}


/*
   Function:     show_sig
   Parameters:   
   Return-Value: 
   Remarks:      
*/
void show_sig ()
{
  if (((int)xv_get(cb,PANEL_VALUE))!=0)
    {
      xv_set (edit_signature,XV_SHOW,TRUE,NULL);
      set_usesig(1);
    }
  else
    {
      xv_set (edit_signature,XV_SHOW,FALSE,NULL);
      set_usesig(0);
    }

}

/*
   Function:     interval_proc
   Parameters:   -
   Return-Value:  
   Remarks:      dummy, but without this procedure numeric_text_item
                 would cause a segmentation fault (very strange) :-(
*/
void interval_proc ()
{

}

/*
   Function:     option_save_proc
   Parameters:   
   Return-Value: 
   Remarks:      
*/
void option_save_proc ()
{
  FILE *fd;
  char filename[STRSIZE];
  char mailfile[STRSIZE],returnpath[STRSIZE],homedir[STRSIZE],sigfile[STRSIZE];
  char smtpserver[STRSIZE],strtimer[6],print_command[STRSIZE];
  char spoolfile[STRSIZE];
  int timer,usesig;

  struct folder_list *flist_ptr;

  /* get values from PANEL_TEXT's */

  strcpy(mailfile,(char *)xv_get(inp_mailfile,PANEL_VALUE));
  expand_tilde (mailfile); /* replace ~ with homedir */
  
  strcpy(returnpath,(char *)xv_get(inp_retpath,PANEL_VALUE));
  usesig=(int)xv_get(cb,PANEL_VALUE);
  strcpy(smtpserver,(char *)xv_get(inp_smtpserver,PANEL_VALUE));
  strcpy(print_command,(char *)xv_get(inp_printcomm,PANEL_VALUE));
  timer=(int) xv_get (inp_timer,PANEL_VALUE);
  sprintf (strtimer,"%d",timer);

  strcpy(spoolfile,(char *)xv_get(inp_spoolfile,PANEL_VALUE));

  /* get global data */

  get_homedir(homedir);
  get_sigfile(sigfile);
  flist_ptr = get_folder_list ();
  flist_ptr = flist_ptr->next;    /* The first entry is always the saved 
				     separately as Mail-File */

  sprintf (filename,"%s/.somarc",homedir);
  if ((fd=fopen(filename,"w"))!=NULL)
    {
      fprintf (fd,"Mail-File: %s\n",mailfile);
      fprintf (fd,"Return-Path: %s\n",returnpath);
      fprintf (fd,"SMTP-Server: %s\n",smtpserver);
      fprintf (fd,"Timer: %s\n",strtimer);
      fprintf (fd,"Print: %s\n",print_command);
      fprintf (fd,"Spool: %s\n",spoolfile);
      if (usesig) fprintf (fd,"Use-Sig: yes\n"); 
      else fprintf (fd,"Use-Sig: no\n");

      /* Now write out the rest of folder_list */

      while (flist_ptr!=NULL)
	{
	  fprintf (fd,"Folder: \"%s\", \"%s\"\n",
		   flist_ptr->this_one.folder_name, 
		   flist_ptr->this_one.folder_path);
	  flist_ptr=flist_ptr->next;
	}

      fclose (fd);
    }
  if (get_usesig())
    {
      textsw_store_file(edit_signature,sigfile,100,100);
   }

}

/*
   Function:     option_close_proc
   Parameters:   
   Return-Value: 
   Remarks:      
*/
void option_close_proc ()
{
  char mailfile[STRSIZE],returnpath[STRSIZE],smtpserver[STRSIZE];
  char spoolfile[STRSIZE];
  int mailcheck_intervall;
  struct folder_list *fptr;
  struct folder *af; 

  af=get_active_folder ();
  strcpy(mailfile,(char *)xv_get(inp_mailfile,PANEL_VALUE));
  expand_tilde (mailfile);
  /* If mailfile was changed -> change entry in the folderlist too */

#ifdef DBUG_OPTIONS
  printf ("mailfile is %s\n",mailfile);
#endif

  fptr = get_folder_list_entry (get_folder_list(),1);
  if (strcmp(fptr->this_one.folder_path,mailfile)!=0)
    {
       strcpy (fptr->this_one.folder_path,mailfile);

       printf ("Incoming-Path changed to: %s\n",mailfile);

       if (strcmp(af->folder_name,"Incoming")==0)
	 {
	   set_active_folder (fptr->this_one);
	   printf ("going to raise signal\n");
	   if (raise (SIGUSR1)!=0)
	     {
	       printf ("couldn't raise signal\n");
	     }
	   else printf ("raise ok\n");
	 }

    }

  strcpy(returnpath,(char *)xv_get(inp_retpath,PANEL_VALUE));
  set_returnpath(returnpath);
  set_usesig((int)xv_get(cb,PANEL_VALUE));
  strcpy(smtpserver,(char *)xv_get(inp_smtpserver,PANEL_VALUE));
  set_smtpserver(smtpserver);
  mailcheck_intervall = (int) xv_get (inp_timer,PANEL_VALUE);
  set_timerval (mailcheck_intervall);
  strcpy(spoolfile,(char *)xv_get(inp_spoolfile,PANEL_VALUE));
  set_spool_file (spoolfile);

  xv_destroy_safe (optionframe);
  option_visible = 0;
  
  folder_ed_close_proc ();

}

/*
   Function:     option_cancel_proc
   Parameters:   
   Return-Value: 
   Remarks:      
*/
void option_cancel_proc ()
{
  xv_destroy_safe (optionframe);
  option_visible = 0;

}

/*
   Function:     folder_edit_proc
   Parameters:   
   Return-Value: 
   Remarks:      
*/
void folder_edit_proc ()
{
  open_folder_ed (optionframe,get_folder_list());
}

/*
   Function:     open_option
   Parameters:   Frame baseframe
   Return-Value: 
   Remarks:      
*/
void open_option (Frame baseframe)
{
  struct folder_list *fliste;

  Xv_Font sigfont;
  char mailfile[STRSIZE],returnpath[STRSIZE],sigfile[STRSIZE];
  char smtpserver[STRSIZE],print_command[STRSIZE],spoolfile[STRSIZE];

  fliste=get_folder_list_entry (get_folder_list(),1);
  strcpy (mailfile,fliste->this_one.folder_path);
  get_returnpath(returnpath);
  get_sigfile(sigfile);
/*  get_sig_content (sigfile,sig_buff,SIGSIZE+1); */
  get_smtpserver(smtpserver);
  get_printcommand(print_command);
  get_spool_file(spoolfile);


#ifdef DEBUG_OPTIONS
  printf ("Sigfile: %s\n",sigfile);
  printf ("Mailfile: %s\n",mailfile);
  printf ("Returnpath: %s\n",returnpath);
  printf ("SMTP-Server: %s\n",smtpserver);
  printf ("Print command: %s\n",print_command);
  printf ("Spool-File: %s\n",spoolfile);
#endif
    
  if (option_visible==0)
    {
      option_visible=1;
      
      optionframe = (Frame) xv_create (baseframe,FRAME,
				       FRAME_LABEL, "Soma: Options",
				       XV_SHOW, TRUE,
				       NULL);
      optionpanel = (Panel) xv_create (optionframe,PANEL, NULL);


      /* Buttons */
     
      (void) xv_create (optionpanel,PANEL_BUTTON,
			PANEL_NOTIFY_PROC, option_close_proc,
			PANEL_LABEL_STRING, "Close",
			XV_Y,5,
			NULL);

      (void) xv_create (optionpanel,PANEL_BUTTON,
			PANEL_NOTIFY_PROC, option_save_proc,
			PANEL_LABEL_STRING, "Save",
			XV_Y,5,
			NULL);

      (void) xv_create (optionpanel,PANEL_BUTTON,
			PANEL_NOTIFY_PROC, folder_edit_proc,
			PANEL_LABEL_STRING, "Folders...",
			XV_Y,5,
			NULL);


      (void) xv_create (optionpanel,PANEL_BUTTON,
			PANEL_NOTIFY_PROC, option_cancel_proc,
			PANEL_LABEL_STRING, "Cancel",
			XV_Y,5,
			NULL);


      cb = (Panel_item) xv_create (optionpanel,PANEL_CHECK_BOX,
				   PANEL_LAYOUT, PANEL_HORIZONTAL,
				   PANEL_LABEL_STRING,"Use Signature:",
				   PANEL_LABEL_WIDTH,220,
				   PANEL_CHOICE_STRINGS, "Yes", NULL,
				   PANEL_NOTIFY_PROC, show_sig,
				   PANEL_VALUE, get_usesig(),
				   XV_X,5,
				   XV_Y,180,
				   XV_SHOW, TRUE,
				   NULL);

      /* Input-Felder */
      
      inp_retpath = (Panel_item) xv_create (optionpanel, PANEL_TEXT,
					    PANEL_LABEL_STRING, "Return-Path:",
					    PANEL_VALUE, returnpath,
					    PANEL_LABEL_WIDTH, 220,
					    PANEL_VALUE_DISPLAY_WIDTH, 300,
					    XV_Y, 30, 
					    XV_X, 5, 
					    NULL);

      inp_mailfile = (Panel_item) xv_create (optionpanel, PANEL_TEXT,
					    PANEL_LABEL_STRING, "Mail-File (Incoming):",
					    PANEL_VALUE, mailfile,
					    PANEL_LABEL_WIDTH, 220,
					    PANEL_VALUE_DISPLAY_WIDTH, 300,
					    XV_Y, 55, 
					    XV_X, 5, 
					    NULL);

      inp_smtpserver = (Panel_item) xv_create (optionpanel, PANEL_TEXT,
					    PANEL_LABEL_STRING, "SMTP-Server:",
					    PANEL_VALUE, smtpserver,
					    PANEL_LABEL_WIDTH, 220,
					    PANEL_VALUE_DISPLAY_WIDTH, 300,
					    XV_Y, 80, 
					    XV_X, 5, 
					    NULL);

      inp_spoolfile = (Panel_item) xv_create (optionpanel, PANEL_TEXT,
				    PANEL_LABEL_STRING, "Spoolfile for outgoing mail:",
				    PANEL_VALUE, spoolfile,
				    PANEL_LABEL_WIDTH, 220,
				    PANEL_VALUE_DISPLAY_WIDTH, 300,
				    XV_Y, 105, 
				    XV_X, 5, 
				    NULL);


     inp_printcomm = (Panel_item) xv_create (optionpanel, PANEL_TEXT, 
					 PANEL_LABEL_STRING, "Print command:", 
					 PANEL_LABEL_WIDTH, 220, 
					 PANEL_VALUE, print_command , 
					 PANEL_VALUE_DISPLAY_WIDTH, 300,
					 PANEL_MIN_VALUE, 0, 
					 PANEL_MAX_VALUE,300, 
					 XV_Y,130, 
					 XV_X,5, 
					 NULL); 

     inp_timer = (Panel_item) xv_create (optionpanel, PANEL_NUMERIC_TEXT, 
					 PANEL_LABEL_STRING, "Mail check intervall (seconds):", 
					 PANEL_LABEL_WIDTH, 220, 
					 PANEL_VALUE, get_timerval(), 
					 PANEL_VALUE_DISPLAY_WIDTH, 75,
					 PANEL_MIN_VALUE, 0, 
					 PANEL_MAX_VALUE,300, 
					 XV_Y,155, 
					 XV_X,5, 
					 PANEL_NOTIFY_PROC, interval_proc,
					 NULL); 


      sigfont = (Xv_Font) xv_find (optionframe,FONT,
				FONT_FAMILY, FONT_FAMILY_DEFAULT_FIXEDWIDTH,
				FONT_STYLE, FONT_STYLE_NORMAL,
				NULL);
#ifdef DEBUG_OPTIONS
      printf ("sigfont created\n");
#endif

      edit_signature = (Textsw) xv_create (optionframe,TEXTSW,
					PANEL_LABEL_STRING, "Signature:",
					XV_X,5,
					XV_Y,205,
					XV_WIDTH,((int)xv_get(sigfont,FONT_DEFAULT_CHAR_WIDTH,'X'))*80+5,
					XV_HEIGHT,((int)xv_get(sigfont,FONT_DEFAULT_CHAR_HEIGHT,'X'))*4+5,
					TEXTSW_FILE_CONTENTS,sigfile,
					TEXTSW_FONT,sigfont, 
					NULL);
      
#ifdef DEBUG_OPTIONS
      printf ("signature_sw created\n");
#endif

      if ((get_usesig())) 
	{
	  if (((Bool)xv_get(edit_signature,XV_SHOW))!=TRUE)
	    xv_set (edit_signature,XV_SHOW,TRUE); 

	}
      else 
	{
	  xv_set (edit_signature,XV_SHOW,FALSE);

	}

      notify_interpose_destroy_func (optionframe,option_destroy_func);

    }
  else
    {
    }
  
}












