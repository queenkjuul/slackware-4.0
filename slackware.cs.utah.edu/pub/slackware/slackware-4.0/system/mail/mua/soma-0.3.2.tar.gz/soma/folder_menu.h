/* 

   Project:     soma - stefan's own mail application 
   File:        folder_menu.h
   Description: 
   Created:     
   Changed:     $Date: 1996/02/23 11:40:50 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995,1996 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: folder_menu.h,v 1.1 1996/02/23 11:40:50 kuehnel Exp $
	$Author: kuehnel $
	$Log: folder_menu.h,v $
	Revision 1.1  1996/02/23 11:40:50  kuehnel
	Initial revision

 	$Date: 1996/02/23 11:40:50 $

   ---------------------------------------------------------------------------

*/




/*
   Function:     fill_menu
   Parameters:   Menu m                 - Menu to be filled
                 struct folder_list *fl - pointer to the first element of a
		                          folder list
   Return-Value: -
   Remarks:      Used to fill the "Folder"-Menu
*/
extern void fill_menu (Menu m,struct folder_list *fl);
