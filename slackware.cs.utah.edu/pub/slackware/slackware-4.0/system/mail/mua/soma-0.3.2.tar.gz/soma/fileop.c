/* 

   Project:     soma - stefan's own mail application 
   File:        fileop.c 
   Description: contains functions for reading lines from files 
   Created:     10 Dec. 1995
   Changed:     $Date: 1996/06/18 17:23:58 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   To see 8-bit-characters type 'M-x standard-display-european'! 

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: fileop.c,v 1.4 1996/06/18 17:23:58 kuehnel Exp $  
	$Author: kuehnel $
	$Log: fileop.c,v $
	Revision 1.4  1996/06/18 17:23:58  kuehnel
	Read_to_nl returns the number of chars read now.

	Revision 1.3  1996/02/18 14:00:04  kuehnel
	Neue Funktion: file_copy (sehr einfache Implementierung: Byte by Byte).

	Revision 1.2  1996/01/07 16:48:02  kuehnel
	#include "machine.h" ergaenzt.

 * Revision 1.1  1995/12/10  20:26:23  kuehnel
 * Initial revision
 *
 	$Date: 1996/06/18 17:23:58 $
   ---------------------------------------------------------------------------

*/

#include <stdio.h>
#include <string.h>
#include "machine.h"


/*
   Function:     read_to_nl
   Parameters:   FILE *fd   
                 char *str  
   Return-Value: int, number of chars read
   Remarks:      Reads from actual file position til next new-line-character
*/


int read_to_nl (FILE *fd,char *str)
{
  int i=0;
  char c;

  while (((c=fgetc(fd))!='\n')&&(!feof(fd)))
    {
      str[i++]=c;
    }
  str[i]=(char)0;
  return i;
}

/*
   Function:     match
   Parameters:   char *muster   
                 char *str  
   Return-Value: -
   Remarks:      compares the beginning of the line with muster, returns
                 1 if muster matches line
*/


int match (char *muster,char *line)
{
  int i=0,j=1;
  for(i=0;i<strlen(muster);i++)
    {
      if (line[i]!=muster[i]) j=0;
    }
  return j;
}



/*
   Function:     file_copy
   Parameters:   char *name1
                 char *name2
   Return-Value: int 0 if ok !0 else
   Remarks:      Copies file "name1" to "name2". 
                 Algorithm may be suboptimal!
*/
int file_copy (char *name1,char *name2)
{
  FILE *fd1,*fd2;
  int retval;
  char c;

  fd1=fopen(name1,"r");
  fd2=fopen(name2,"w");

  if ((fd1!=NULL)&&(fd2!=NULL))
    {
      while (!feof(fd1))
	{
	  c = fgetc(fd1);
	  if (!feof(fd1)) fputc(c,fd2);
	  /* else printf ("%c\n",c); */
	}      
      retval=0;
    }
  else
    {
      retval=1;
    }
  fclose (fd1);
  fclose (fd2);
  return retval;
}
