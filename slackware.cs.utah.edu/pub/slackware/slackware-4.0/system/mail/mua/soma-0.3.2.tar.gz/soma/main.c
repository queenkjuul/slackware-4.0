/* 

   Project:     soma - stefan's own mail application 
   File:        main.c 
   Description: contains functions for main window
   Created:     02 Dec. 1995
   Changed:     $Date: 1996/02/23 11:42:11 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995,1996 by Stefan K�hnel

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: main.c,v 1.18 1996/02/23 11:42:11 kuehnel Exp kuehnel $  
	$Author: kuehnel $
	$Log: main.c,v $
	Revision 1.18  1996/02/23 11:42:11  kuehnel
	Check in before a new release.

	Revision 1.17  1996/02/21 21:53:06  kuehnel
	fill_menu moved to global.c
	calls set_view_msg_id because view.c needs to know which is the
	current message id

	Revision 1.16  1996/02/18 14:08:02  kuehnel
	Neu: folder_menu, Signal-Handler fuer den Fall das Folder-Informationen
	ge�ndert werden. Problem: Folder-Menu pa�t sich beim L�schen von Foldern
	noch nicht richtig an.

	Revision 1.15  1996/02/04 21:51:09  kuehnel
	Neue Funktion: Mehrere folder m�glich.

	Revision 1.14  1996/02/01 21:18:54  kuehnel
	Textposition nach �ffnen des View-Fensters ist jetzt der Beginn des
	Textes.

	Revision 1.13  1996/01/18 19:52:09  kuehnel
	Unused variable mid removed from del_proc

	Revision 1.12  1996/01/17 21:27:19  kuehnel
	Verbessert: Datum wird jetzt mit 20 Zeichen Breite dargestellt.
	Das Auffrischen der Liste nach Delete klappt jetzt besser.

 * Revision 1.11  1996/01/07  16:48:19  kuehnel
 * #include "machine.h" ergaenzt.
 *
 * Revision 1.10  1996/01/07  14:16:22  kuehnel
 * del_proc eingebaut. Delete-Button. Loeschen einer Nachricht moeglich.
 * Vorraussetzung (bei Verwendung von /var/spool/mail ...): Programm muss
 * zur Gruppe mail gehoeren und GID-Bit muss gesetzt sein.
 *
 * Revision 1.9  1995/12/19  23:28:57  kuehnel
 * Check_proc �berarbeitet: Message_Liste wird nur noch neu eingelesen,
 * wenn mailfile seit dem letzten lesen ge�ndert wurde.
 * Jetzt mit Timer. In einstellbaren Zeitabst�nden wird Check_proc
 * aufgerufen. Aufruf von Hand aber immer noch moeglich.
 *
 * Revision 1.8  1995/12/18  10:08:58  kuehnel
 * Neu: Button "About..."
 * Neu: Date and CC are displayed in message-view
 *
 * Revision 1.7  1995/12/17  14:09:33  kuehnel
 * Auswahl der zu lesenden Mail jetzt per Doppelklick m�glich
 * Letzte Mail wird automatisch selektiert, und Scrollbar so
 * manipuliert, da� sie auch zu sehen ist.
 *
 * Revision 1.6  1995/12/14  18:29:10  kuehnel
 * new button: check for new mail.
 *
 * Revision 1.5  1995/12/11  20:24:56  kuehnel
 * Funktion "get_user_information" wurde nach global.c verlagert.
 *
 * Revision 1.4  1995/12/10  20:27:01  kuehnel
 * Kann jetzt ".somarc" lesen und auswerten.
 *
 * Revision 1.3  1995/12/09  20:40:53  kuehnel
 * Neueste Version. Funktioniert ausgezeichnet. Compose geht noch nicht.
 *
 * Revision 1.2  1995/12/06  23:50:12  kuehnel
 * Aufruf von get_body in view_proc. struct msg_list *root jetz globale Var.
 *
 * Revision 1.1  1995/12/03  23:12:39  kuehnel
 * Initial revision
 * 
 	$Date: 1996/02/23 11:42:11 $ 
   ---------------------------------------------------------------------------

*/

/* #define DEBUG_MAIN */

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/frame.h>
#include <xview/notify.h>
#include <xview/scrollbar.h>
#include <xview/win_input.h>
#include <xview/win_event.h>
#include <xview/icon.h>
#include <xview/svrimage.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include "global.h"
#include "getmail.h"
#include "somastr.h"
#include "view.h"
#include "compose.h"
#include "options.h"
#include "fileop.h"
#include "msg_box.h"
#include "folder_menu.h"
#include "machine.h"

/* includes f�r die Icons */

#include "empty.xbm"
#include "new.xbm"
#include "full.xbm"


Frame mainframe;
Panel mainpanel;
Panel_item headerlist;
Xv_Font listfont;
Menu folder_menu; 
Icon icon_full, icon_empty, icon_new;
Server_image empty_image,full_image,new_image;

struct msg_list *msg_root;
/* time_t last_mail_access; */

struct folder_list *flist;

char footnote[STRSIZE];

int new_flag_cleared=1; /* switch between full and new icon */

/* Functions */

void fill_list (struct msg_list *root); /* Forward declaration */
void clear_list (struct msg_list **root); /* Forward declaration */
void set_timer (int secs); /* Forward declaration */

/*
   Function:     quit_proc
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
void quit_proc()
{
  xv_destroy_safe (mainframe);
  exit(0);
}

/*
   Function:     get_msg_list
   Parameters:   struct msg_list **root
   Return-Value: 
   Remarks:      Fills the message list
*/

void get_msg_list (struct msg_list **root)
{
  char mailfile[STRSIZE];  
  int howmuch;
  struct folder *fldr;

  *root=NULL;
  fldr=get_active_folder();
  time (&fldr->last_access);
  strcpy (mailfile,fldr->folder_path);

#ifdef DEBUG_MAIN
  printf ("mailfile is %s\n",mailfile);
#endif

  if (mailfile!=NULL)
    {
      howmuch=read_mail_file (mailfile,root);
#ifdef DEBUG_MAIN
      printf ("'%s' contains %d messages:\n",mailfile,howmuch);
#endif
      if (howmuch==0)
	{
	  xv_set (mainframe, FRAME_ICON, icon_empty , NULL);
	}
    }

}


/*
   Function:     force_new_header_list
   Parameters:   -
   Return-Value: -
   Remarks:      
*/
void force_new_header_list ()
{
  int nrows;
  struct folder *active_folder;

  nrows = (int) xv_get (headerlist,PANEL_LIST_NROWS); 
  xv_set (headerlist,PANEL_LIST_DELETE_ROWS,0,nrows,NULL); 
  
  clear_list (&msg_root);
  get_msg_list (&msg_root);
  fill_list(msg_root);  

  /* update the footer */

  active_folder = get_active_folder();

  sprintf (footnote,"Active folder: %s",active_folder->folder_name);
  xv_set (mainframe,FRAME_LEFT_FOOTER,footnote,NULL);
  xv_set (mainframe,FRAME_SHOW_FOOTER,TRUE,NULL);

 
}

/*
   Function:     check_proc
   Parameters:   -
   Return-Value: -
   Remarks:      Checks if mailfile was modified after last access.
                 If it was modified msg_list is read again.
*/
void check_proc()
{
  char mail_file[STRSIZE];
  struct stat buffer;
  struct folder *fldr;

  fldr=get_active_folder();
  strcpy (mail_file,fldr->folder_path);
  stat (mail_file,&buffer);
  if ((buffer.st_mtime)>(fldr->last_access))
    {
      force_new_header_list ();
      xv_set (mainframe, FRAME_ICON, icon_new , NULL);
      new_flag_cleared=0;
    }
  else 
    {
      if (new_flag_cleared==1)
	{
	  xv_set (mainframe, FRAME_ICON, icon_full , NULL);
	}
    }
}


/*
   Function:     timer_func
   Parameters:   Notify_client clnt
                 int           which
   Return-Value: Notify_value
   Remarks:      This function is executed after the timer expired 
*/
Notify_value timer_func (Notify_client clnt,int which)
{
  check_proc ();
  return NOTIFY_DONE;

}



/*
   Function:     options_proc
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
void options_proc()
{
  open_option (mainframe);
  set_timer(get_timerval());

}

/*
   Function:     about_proc
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
void about_proc()
{
  char buffer[512];

  sprintf (buffer,"Soma - Stefan's own mail application\nVersion %s\n\nCopyright (C) 1995,1996 by Stefan K�hnel,\nD-30419 Hannover, Federal Republic of Germany\n\nRead the files README and COPYING for further information.\n",VERSION);
  msg_box (mainframe,buffer);
}



/*
   Function:     process_line
   Parameters:   int index
   Return-Value: -
   Remarks:      Parameter index is the number of an entry in the messagelist
                 this message is read and inserted into the view-window.
*/
void process_line (int index)
{
  char idstr[STRSIZE],from_str[STRSIZE],to_str[STRSIZE],subj_str[STRSIZE];
  char linestr[STRSIZE],date_str[STRSIZE],cc_str[STRSIZE];
  char mailfile[STRSIZE];
  FILE *fd;
  struct message msg_entry;
  int cc_active;
  struct folder *af;

  af=get_active_folder();
  strcpy (mailfile,af->folder_path);

  get_msg_list_entry (msg_root,index,&msg_entry);
  open_view(msg_entry);
  strcpy (idstr,msg_entry.message_id);
  set_view_msg_id (idstr);

  sprintf (date_str,"Date:\t %s",msg_entry.date);
  sprintf (from_str,"From:\t %s",msg_entry.from);
  sprintf (to_str,"To:\t %s",msg_entry.to);
  sprintf (subj_str,"Subj.:\t %s",msg_entry.subj);
  cc_active=strlen(msg_entry.cc);
  if (cc_active) sprintf (cc_str,"Cc:\t %s",msg_entry.cc);

  insert_view (date_str);
  insert_view (from_str);
  insert_view (to_str);
  if (cc_active) insert_view (cc_str);
  insert_view (subj_str);
  insert_view ("");

#ifdef DEBUG_MAIN
  printf ("Message-ID: %s\n",idstr);
#endif
  get_body_first_line (&fd,mailfile,idstr);
#ifdef DEBUG_MAIN
  printf ("First Body-Line found\n");
#endif

  while ((get_body_line(fd,linestr))!=0)
    {
#ifdef DEBUG_MAIN
      printf ("%s\n",linestr);
#endif
      insert_view (linestr);
    }
  set_view_pos (0);
  fclose (fd);
}

/*
   Function:     view_proc
   Parameters:   -
   Return-Value: -
   Remarks:      - 
*/
void view_proc()
{
  int index,nrows,fsel;
  
  nrows=(int) xv_get (headerlist,PANEL_LIST_NROWS,NULL);
  fsel=(int) xv_get (headerlist,PANEL_LIST_FIRST_SELECTED,NULL);
  if (fsel!=-1)
    {
      index = fsel+1; /* fsel is between 0 and n-1; index between 1 and n */
#ifdef DEBUG_MAIN 
      printf ("NROWS   : %d\n",nrows);
      printf ("SELECTED: %d\n",fsel);
#endif
      process_line (index);
      if (new_flag_cleared==0) new_flag_cleared=1;
    }
}

/*
   Function:     del_proc
   Parameters:   -
   Return-Value: -
   Remarks:      deletes selected message from mail_file 
*/
void del_proc()
{
  int index,nrows,fsel;
  char mf[STRSIZE];
  struct message msg_entry;

  nrows=(int) xv_get (headerlist,PANEL_LIST_NROWS,NULL);
  fsel=(int) xv_get (headerlist,PANEL_LIST_FIRST_SELECTED,NULL);
  if (fsel!=-1)
    {
      index = fsel+1; /* fsel is between 0 and n-1; index between 1 and n */
#ifdef DEBUG_MAIN 
      printf ("NROWS   : %d\n",nrows);
      printf ("SELECTED: %d\n",fsel);
#endif
      if (get_acc_mode()==LOCAL)
	{
	  struct folder *af;

	  af=get_active_folder();
	  strcpy (mf,af->folder_path);

	  get_msg_list_entry (msg_root,index,&msg_entry);
	  delete_message (mf,msg_entry.message_id);
	
	  /* Alte Eintr�ge loeschen */
	  xv_set (headerlist,PANEL_LIST_DELETE_ROWS,0,nrows,NULL); 
	  clear_list (&msg_root);
	  get_msg_list (&msg_root);
	  fill_list(msg_root);  

	}
    }

}

/*
   Function:     list_proc
   Parameters:   -
   Return-Value: -
   Remarks:      notifier procedure for list-events 
*/
void list_proc(Panel_item item, char *str, Xv_opaque client_data, Panel_list_op op, Event *event, int row)
{
  
  if (op==PANEL_LIST_OP_DBL_CLICK)
    view_proc();
}

/*
   Function:     compose_proc
   Parameters:   -
   Return-Value: -
   Remarks:      notifier-procedure for compose-button 
*/
void compose_proc()
{
  char retpath[STRSIZE];

  get_returnpath(retpath);
#ifdef DEBUG_MAIN
  printf ("going to open compose-window\n");
#endif
  
  open_compose (retpath,"\0","\0","\0");
}


/*
   Function:     clear_list
   Parameters:   -
   Return-Value: - 
   Remarks:      clears the message-list
*/
void clear_list (struct msg_list **root)
{
  struct msg_list *tmp_ptr,*tmp_ptr2;;

  tmp_ptr=*root;
  
  while (tmp_ptr!=NULL) 
    {
      tmp_ptr2=tmp_ptr->next;
      free(tmp_ptr);
      tmp_ptr=tmp_ptr2;
    }
  *root=NULL;
}

/* 
   Function:     fill_list
   Parameters:   -
   Return-Value: -
   Remarks:      fills the message-list with mail headers
*/

void fill_list (struct msg_list *root)
{
  struct msg_list *tmp_msg;
  char headerentry[STRSIZE],fromstr[STRSIZE],datestr[STRSIZE];

  int cnt,nrows;
  Scrollbar sbar;  
  
  tmp_msg=root;
  cnt=0;
  if (tmp_msg!=NULL)
    {
      while (tmp_msg!=NULL)
	{ 	      
	  strim(tmp_msg->actual.from,fromstr,24);
	  strim(tmp_msg->actual.date,datestr,20);
	  sprintf(headerentry,"%3d   %s   %s   %s",cnt+1,datestr,fromstr,
		  tmp_msg->actual.subj);
	  xv_set (headerlist,
		  PANEL_LIST_INSERT,cnt,
		  PANEL_LIST_STRING,cnt,headerentry,
		  PANEL_LIST_FONT, cnt, listfont,
		  NULL);
	  tmp_msg=tmp_msg->next;
	  cnt++;
	}
    }
  
  nrows = (int) xv_get (headerlist,PANEL_LIST_DISPLAY_ROWS);
  xv_set (headerlist,PANEL_LIST_SELECT,cnt-1,TRUE,NULL);
  
  sbar = (Scrollbar) xv_get (headerlist,PANEL_LIST_SCROLLBAR);
  
  if ((cnt-1)>nrows)
    xv_set (sbar,SCROLLBAR_VIEW_START,cnt-10,NULL);
  
}

/*
   Function:     set_timer
   Parameters:   int secs
   Return-Value: 
   Remarks:      establishes a timer for new-mail checking
*/

void set_timer (int secs)
{
  struct itimerval timerval;

  if (secs>0)
    {
      timerval.it_value.tv_sec = secs;
      timerval.it_value.tv_usec = 0;

      timerval.it_interval.tv_sec = secs; 
      timerval.it_interval.tv_usec = 0;

      notify_set_itimer_func (mainframe, timer_func, ITIMER_REAL, &timerval,NULL); 
    }
  else notify_set_itimer_func (mainframe, NOTIFY_FUNC_NULL, ITIMER_REAL, NULL, NULL);
  

}

/*
   Function:     change_folder_proc
   Parameters:   
   Return-Value: 
   Remarks:      notify-proc for the "Folder"-Menu
*/
void change_folder_proc (Menu menu, Menu_item menu_item)
{
  struct folder active_folder;

  char menu_str[STRSIZE];

  strcpy (menu_str, (char *)xv_get (menu_item,MENU_STRING));

#ifdef DEBUG_MAIN
  printf ("Selected folder: %s\n",menu_str);
#endif

  active_folder = (get_folder_by_name (flist,menu_str))->this_one;
  set_active_folder (active_folder);


  force_new_header_list ();
}



/*
   Function:     signal_folder_list
   Parameters:   
   Return-Value: 
   Remarks:      This function is a signal handler for SIGUSR2
*/
void signal_folder_list ()
{
  int nitems,i,ok;
  
  struct folder *active_folder;
  struct folder_list *folder_ptr;
  char af_name[STRSIZE],af_path[STRSIZE];
  nitems = (int) xv_get (folder_menu,MENU_NITEMS,NULL);

#ifdef DEBUG_MAIN
  printf ("SIGUSR2 received\n");
  printf ("nitems %d\n",nitems);
#endif

  for (i=1;i<=nitems;i++)
    {
      xv_set (folder_menu,MENU_REMOVE,1);
    }

  xv_set (folder_menu,MENU_NROWS,0,NULL);

#ifdef DEBUG_MAIN
  printf ("Vor fill_menu Aufruf\n");
#endif

  fill_menu (folder_menu,get_folder_list());
  xv_set (folder_menu, MENU_NOTIFY_PROC, change_folder_proc, NULL);

#ifdef DEBUG_MAIN
  print_folder_list ();
#endif

  /* check if active folder is existing yet */

  active_folder = get_active_folder();
  strcpy (af_name,active_folder->folder_name);
  strcpy (af_path,active_folder->folder_path);
  folder_ptr = get_folder_by_name (get_folder_list(),af_name);
  ok =0;
  if (folder_ptr!=NULL)
    {
      if (strcmp(af_path,folder_ptr->this_one.folder_path)==0) ok = 1;
      else ok=0;
    }
  else
    {
      /* folder does not longer exist or name was changed */
      ok = 0;
    }
  if (ok==0)
    {
      /* make Incoming folder to the active one */

#ifdef DEBUG_MAIN
      printf ("Active folder no longer valid!\n");
#endif

      msg_box (mainframe,"Folder information for active folder was changed or folder was deleted!\nSwitching to 'Incoming'.\n");

      folder_ptr = get_folder_list_entry (get_folder_list(),1);
      set_active_folder (folder_ptr->this_one);
      force_new_header_list ();
      
    }
}


int main (int argc,char* argv[])
{
  struct sigaction newaction,oldaction;

  xv_init (XV_INIT_ARGC_PTR_ARGV, &argc, argv, NULL);
  mainframe = (Frame) xv_create (0, FRAME, 
				 FRAME_LABEL, argv[0],
				 NULL);
				
  get_user_information();

  create_folder_list (&flist);
  set_folder_list (flist);         /* make the just created folder_list the
				      global one! */
  add_config_folders (&flist);

  set_active_folder((get_folder_list_entry (flist,1))->this_one);

  newaction.sa_handler=signal_folder_list;
  newaction.sa_mask=SA_NOMASK;
  newaction.sa_flags=SA_RESTART;
  sigaction (SIGUSR2,&newaction,&oldaction);
  
  newaction.sa_handler=force_new_header_list;
  newaction.sa_mask=SA_NOMASK;
  newaction.sa_flags=SA_RESTART;
  sigaction (SIGUSR1,&newaction,&oldaction);
  
  

  mainpanel=(Panel) xv_create (mainframe, PANEL, NULL);

    (void) xv_create (mainpanel, PANEL_BUTTON,
		    PANEL_NOTIFY_PROC, quit_proc,
		    PANEL_LABEL_STRING, "Quit",
		    XV_Y,5,
		    /* XV_X,5, */
		    NULL);
  
  (void) xv_create (mainpanel, PANEL_BUTTON,
		    PANEL_NOTIFY_PROC, view_proc,
		    PANEL_LABEL_STRING, "View...",
		    XV_Y,5,
		    /* XV_X,55, */
		    NULL);

  (void) xv_create (mainpanel, PANEL_BUTTON,
		    PANEL_NOTIFY_PROC, del_proc,
		    PANEL_LABEL_STRING, "Delete",
		    XV_Y,5,
		    /* XV_X,115, */
		    NULL);


  (void) xv_create (mainpanel, PANEL_BUTTON,
		    PANEL_NOTIFY_PROC, compose_proc,
		    PANEL_LABEL_STRING, "Compose ...",
		    XV_Y,5,
		    /* XV_X,175, */
		    NULL);

  (void) xv_create (mainpanel, PANEL_BUTTON,
		    PANEL_NOTIFY_PROC, check_proc,
		    PANEL_LABEL_STRING, "Check for new mail",
		    XV_Y,5,
		    /* XV_X,265, */
		    NULL);

  folder_menu = (Menu) xv_create (0,MENU,NULL);

  fill_menu (folder_menu,flist);
  xv_set (folder_menu,MENU_NOTIFY_PROC, change_folder_proc,NULL);


  (void) xv_create (mainpanel, PANEL_BUTTON,
		    PANEL_LABEL_STRING, "Folder",
		    PANEL_ITEM_MENU, folder_menu,
		    XV_Y,5,
		    /* XV_X,410, */
		    NULL);  

  (void) xv_create (mainpanel, PANEL_BUTTON,
		    PANEL_NOTIFY_PROC, options_proc,
		    PANEL_LABEL_STRING, "Options ...",
		    XV_Y,5,
		    /* XV_X,5, */
		    NULL);

  (void) xv_create (mainpanel, PANEL_BUTTON,
		    PANEL_NOTIFY_PROC, about_proc,
		    PANEL_LABEL_STRING, "About ...",
		    XV_Y,5,
		    /* XV_X,90, */
		    NULL);
	
  headerlist = (Panel_item) xv_create (mainpanel, PANEL_LIST,
				       PANEL_CHOOSE_ONE,TRUE,
				       PANEL_NOTIFY_PROC, list_proc,
				       PANEL_LIST_DO_DBL_CLICK, TRUE,
				       PANEL_READ_ONLY,TRUE,
				       PANEL_LIST_DISPLAY_ROWS,10,
				       XV_SHOW, TRUE,
				       XV_X, 0,
				       XV_Y,30,
				       PANEL_LIST_WIDTH,-1, 
				       NULL);
  

  listfont = (Xv_Font) xv_find (mainframe,FONT,
				FONT_FAMILY, FONT_FAMILY_DEFAULT_FIXEDWIDTH,
				FONT_STYLE, FONT_STYLE_NORMAL,
				NULL);


  empty_image = (Server_image)xv_create(0,SERVER_IMAGE,
					XV_WIDTH, empty_width,
					XV_HEIGHT, empty_height,
					SERVER_IMAGE_X_BITS, empty_bits,
					NULL);
					
  full_image = (Server_image)xv_create(0,SERVER_IMAGE,
				       XV_WIDTH, full_width,
				       XV_HEIGHT, full_height,
				       SERVER_IMAGE_X_BITS, full_bits,
				       NULL);

  new_image = (Server_image)xv_create(0,SERVER_IMAGE,
				      XV_WIDTH, new_width,
				      XV_HEIGHT, new_height,
				      SERVER_IMAGE_X_BITS, new_bits,
				      NULL);

  icon_full = (Icon)xv_create(mainframe,ICON,
			      ICON_IMAGE, full_image,
			      XV_X, 100,
			      XV_Y, 100,
			      NULL);

  icon_empty = (Icon)xv_create(mainframe,ICON,
			       ICON_IMAGE, empty_image,
			       XV_X, 100,
			       XV_Y, 100,
			       NULL);
  
  icon_new = (Icon)xv_create(mainframe,ICON,
			     ICON_IMAGE, new_image,
			     XV_X, 100,
			     XV_Y, 100,
			     NULL);


  xv_set (mainframe, FRAME_ICON, icon_full , NULL);

  /* Initialization of the main window */

  get_msg_list (&msg_root);
  fill_list (msg_root);

  set_timer (get_timerval());

  sprintf (footnote,"Active folder: %s",get_active_folder()->folder_name);
  xv_set (mainframe,FRAME_LEFT_FOOTER,footnote,NULL);
  xv_set (mainframe,FRAME_SHOW_FOOTER,TRUE,NULL);
  
  
  window_fit (mainpanel);
  window_fit (mainframe);
  
  xv_main_loop (mainframe);

  return 0;
}




