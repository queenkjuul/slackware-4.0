/* 

   Project:     soma - stefan's own mail application 
   File:        folder_edit.c
   Description: Edit the folder list
   Created:     06.02.1996
   Changed:     $Date: 1996/02/18 14:02:52 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995,1996 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: folder_edit.c,v 1.1 1996/02/18 14:02:52 kuehnel Exp $
	$Author: kuehnel $
	$Log: folder_edit.c,v $
	Revision 1.1  1996/02/18 14:02:52  kuehnel
	Initial revision

 	$Date: 1996/02/18 14:02:52 $

   ---------------------------------------------------------------------------

*/


#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/frame.h>
#include <signal.h>
#include <errno.h>
#include "global.h"
#include "msg_box.h"
#include "machine.h"

/* #define DEBUG_FOLDER_ED  */

Frame folder_ed_frame;
Panel folder_ed_panel;
Panel_item inp_folder_name,inp_folder_path,folder_list;
int folder_ed_visible=0,folder_list_changed=0;

/*
   Function:     folder_ed_destroy_func
   Parameters:   -
   Return-Value: -
   Remarks:      called when optionframe is closed 
*/
Notify_value folder_ed_destroy_func(Notify_client clnt,Destroy_status status)
{
  if (status==DESTROY_CLEANUP)
    {
      folder_ed_visible=0;
      return notify_next_destroy_func (clnt,status);
    }
  else 
    return NOTIFY_DONE;
}

void text_fname ()
{
}

void text_fpath ()
{
}

/*
   Function:     folder_ed_close_proc
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/

void folder_ed_close_proc ()
{
  int row;
  char buffer[STRSIZE];
  struct folder_list *flistptr;

  if (folder_ed_visible)
    {
      /* at first copy the content of the text_fields to the selected
	 element of the folder-list */
      
      row = (int) xv_get (folder_list,PANEL_LIST_FIRST_SELECTED,NULL);
      
      if ((flistptr=get_folder_list_entry(get_folder_list(),row+2))!=NULL)
	{
	  strcpy (buffer,(char*) xv_get (inp_folder_name,PANEL_VALUE,NULL));
	  if (strcmp(buffer,flistptr->this_one.folder_name)!=0)
	    {
	      strcpy (flistptr->this_one.folder_name,buffer);
	      folder_list_changed=1;
	    }
	  strcpy (buffer,(char*) xv_get (inp_folder_path,PANEL_VALUE,NULL));
	  expand_tilde (buffer);
	  if (strcmp(buffer,flistptr->this_one.folder_path)!=0)
	    {
	      strcpy (flistptr->this_one.folder_path,buffer);
	      folder_list_changed=1;
	    }
	}
      
      xv_destroy_safe (folder_ed_frame);
      folder_ed_visible = 0;

  
      if (folder_list_changed==1) 
	{
	  if (raise (SIGUSR2)!=0)
	    { 
	      int e=errno;
	      printf ("Couldn't raise signal. Error %d (%s)\n",e,strerror(e));
	    }
	  else
	    {
#ifdef DEBUG_FOLDER_ED
	      printf ("signal raised.\n");
#endif
	    }
	}
    }
}

/*
   Function:     folder_list_notify_proc
   Parameters:   -
   Return-Value: -
   Remarks:      This procedure is called, when a new row is selected
*/

void folder_list_notify_proc (Panel_item item, char *string, 
			      Xv_opaque client_data, Panel_list_op op, 
			      Event *event, int row)
{
  struct folder_list *flistptr;
  char buffer[STRSIZE];

#ifdef DEBUG_FOLDER_ED
  printf ("folder_list_select_proc: row: %d\n",row);
#endif

  flistptr = get_folder_list_entry (get_folder_list(),row+2);

  if (flistptr!=NULL)
    {
      switch  (op)
	{
	case PANEL_LIST_OP_SELECT:

	  xv_set (inp_folder_name,
		  PANEL_VALUE,flistptr->this_one.folder_name,NULL);
	  xv_set (inp_folder_path,
		  PANEL_VALUE,flistptr->this_one.folder_path,NULL);
	  break;

	case PANEL_LIST_OP_DESELECT:
	case PANEL_LIST_OP_VALIDATE:

	  /* if a new row is selected the values from the text-input-fields
             must be copied to the folder list, if they were changed */

	  strcpy (buffer,(char*) xv_get (inp_folder_name,PANEL_VALUE,NULL));
	  if (strcmp(buffer,flistptr->this_one.folder_name)!=0)
	    {
	      strcpy (flistptr->this_one.folder_name,buffer);
	      xv_set (folder_list,PANEL_LIST_STRING,row,buffer);
	      folder_list_changed = 1;
	    }
	  strcpy (buffer,(char*) xv_get (inp_folder_path,PANEL_VALUE,NULL));
	  expand_tilde (buffer);
	  if (strcmp(buffer,flistptr->this_one.folder_path)!=0)
	    {
	      strcpy (flistptr->this_one.folder_path,buffer);
	      folder_list_changed = 1;
	    }
	default:
	  
	}
    }
}

/*
   Function:     folder_new_proc
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/

void folder_new_proc ()
{
  int nrows;
  struct folder new_one;
  struct folder_list *root;

  strcpy (new_one.folder_name,"New folder");
  strcpy (new_one.folder_path,"Path to new folder");
  new_one.deletable=1;
  
  root=get_folder_list();
  if (root!=NULL) add_folder (&root,new_one); 

  nrows = (int) xv_get (folder_list,PANEL_LIST_NROWS,NULL);

  /* if (nrows>0) nrows++; */
 
  xv_set (folder_list,
	  PANEL_LIST_INSERT,nrows,
	  PANEL_LIST_STRING,nrows ,"New folder",
	  NULL);

  xv_set (folder_list,PANEL_LIST_SELECT,nrows,TRUE,NULL);

  xv_set (inp_folder_name,PANEL_VALUE,new_one.folder_name,NULL);
  xv_set (inp_folder_path,PANEL_VALUE,new_one.folder_path,NULL);
  
  folder_list_changed=1;
}

/*
   Function:     folder_del_proc
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/

void folder_del_proc ()
{
  int row,selected;
  struct folder_list *flp, *flp2;

  if (msg_box_2(folder_ed_frame,"Do you really want to delete this folder?",
		"Yes","No")==1)
    {
      row = (int) xv_get (folder_list,PANEL_LIST_FIRST_SELECTED,NULL);
      xv_set (folder_list,PANEL_LIST_DELETE,row);
      flp=get_folder_list();
#ifdef DEBUG_FOLDER_ED
      printf ("folder_del_proc: row+2 %d\n",row+2);
#endif
      remove_folder_list_entry(flp,get_folder_list_entry(flp,row+2));

      /* Upate the information in the text-fields */

      selected = (int) xv_get (folder_list,PANEL_LIST_FIRST_SELECTED,NULL);
      if (selected+2>1)
	{
	  flp2=get_folder_list_entry (get_folder_list(),selected+2);
	  xv_set (inp_folder_name,PANEL_VALUE,flp2->this_one.folder_name,NULL);
	  xv_set (inp_folder_path,PANEL_VALUE,flp2->this_one.folder_path,NULL);
	}
      else
	{
	  xv_set (inp_folder_name,PANEL_VALUE,"",NULL);
	  xv_set (inp_folder_path,PANEL_VALUE,"",NULL);
	}
    }
#ifdef DEBUG_FOLDER_ED
      print_folder_list (); 
#endif
  
  folder_list_changed = 1;
}

/*
   Function:     fill_folder_list ()
   Parameters:   -
   Return-Value: -
   Remarks:      -
*/

void fill_folder_list ()
{
  struct folder_list *flptr,*flptr2; 
  int nrows,nrows2,selected;

#ifdef DEBUG_FOLDER_ED
  print_folder_list ();
#endif

  flptr=get_folder_list ();
  flptr=flptr->next;          /* The first entry is the Incoming folder! */
  nrows = (int) xv_get (folder_list,PANEL_LIST_NROWS,NULL);
  if (nrows>0) nrows++;
  while (flptr!=NULL)
    {
      xv_set (folder_list,PANEL_LIST_INSERT,nrows,
	      PANEL_LIST_STRING,nrows,flptr->this_one.folder_name,
	      NULL);

#ifdef DEBUG_FOLDER_ED
      printf ("DEBUG_FOLDER_ED: %s\n", flptr->this_one.folder_name);
#endif
      nrows++;
      flptr=flptr->next;
    }
  nrows2 = (int) xv_get (folder_list,PANEL_LIST_NROWS,NULL);
  if (nrows2>0) 
    {
      selected = (int) xv_get (folder_list,PANEL_LIST_FIRST_SELECTED,NULL);
      flptr2=get_folder_list_entry (get_folder_list(),selected+2);
      xv_set (inp_folder_name,PANEL_VALUE,flptr2->this_one.folder_name,NULL);
      xv_set (inp_folder_path,PANEL_VALUE,flptr2->this_one.folder_path,NULL);
    }
}



/*
   Function:     open_folder_ed
   Parameters:   Frame frame                - Frame of which folder_ed should 
                                              be a subframe
		 struct folder list *flist  - root pointer of folder list
   Return-Value: 
   Remarks:      
*/

void open_folder_ed (Frame frame, struct folder_list *flist)
{
  if (folder_ed_visible==0)
    {
      folder_ed_visible = 1;
      
      folder_ed_frame = (Frame) xv_create (frame,FRAME,
					   FRAME_LABEL, "Soma: Options (Folder Editor)",
					   XV_SHOW,TRUE,
					   NULL);

      folder_ed_panel = (Panel) xv_create (folder_ed_frame,PANEL,
					   NULL);

      (void) xv_create (folder_ed_panel,PANEL_BUTTON,
			PANEL_LABEL_STRING, "Close",
			PANEL_NOTIFY_PROC, folder_ed_close_proc,
			XV_Y, 5,
			NULL);

      (void) xv_create (folder_ed_panel,PANEL_BUTTON,
			PANEL_LABEL_STRING, "New Folder",
			PANEL_NOTIFY_PROC, folder_new_proc,
			XV_Y, 5,
			NULL);

      (void) xv_create (folder_ed_panel,PANEL_BUTTON,
			PANEL_LABEL_STRING, "Delete Folder",
			PANEL_NOTIFY_PROC, folder_del_proc,
			XV_Y, 5,
			NULL);

      inp_folder_name=(Panel_item) xv_create (folder_ed_panel, PANEL_TEXT,
					      PANEL_LABEL_STRING,
					      "Folder Name:",
					      PANEL_LABEL_WIDTH, 90,
					      PANEL_VALUE_DISPLAY_WIDTH, 200,
					      PANEL_NOTIFY_PROC, text_fname,
					      XV_Y,30,
					      XV_X,5,
					      NULL);
      
      inp_folder_path=(Panel_item) xv_create (folder_ed_panel, PANEL_TEXT,
					      PANEL_LABEL_STRING,
					      "Folder Path:",
					      PANEL_LABEL_WIDTH, 90,
					      PANEL_VALUE_DISPLAY_WIDTH, 200,
					      PANEL_NOTIFY_PROC, text_fpath,
					      XV_Y,55,
					      XV_X,5,
					      NULL);

      folder_list = (Panel_item) xv_create (folder_ed_panel, PANEL_LIST,
					    PANEL_LIST_WIDTH,290, 
					    PANEL_CHOOSE_ONE,TRUE,
					    PANEL_NOTIFY_PROC, 
					    folder_list_notify_proc,
					    PANEL_READ_ONLY,TRUE,
					    PANEL_LIST_DO_DBL_CLICK, 
					    FALSE,
					    PANEL_LIST_DISPLAY_ROWS,5,
					    XV_Y,80,
					    XV_X,5,
					    XV_SHOW, TRUE,
					    NULL);

      window_fit (folder_ed_panel);
      window_fit (folder_ed_frame);

      fill_folder_list ();

    }
}




