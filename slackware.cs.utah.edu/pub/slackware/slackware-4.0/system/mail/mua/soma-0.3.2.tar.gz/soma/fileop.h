/* 

   Project:     soma - stefan's own mail application 
   File:        fileop.h 
   Description: Header-File for fileop.c
   Created:     10 Dec. 1995
   Changed:     $Date: 1996/06/18 17:24:35 $
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   To see 8-bit-characters type 'M-x standard-display-european'! 

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: fileop.h,v 1.3 1996/06/18 17:24:35 kuehnel Exp $  
	$Author: kuehnel $
	$Log: fileop.h,v $
	Revision 1.3  1996/06/18 17:24:35  kuehnel
	Read_to_nl header changed. See in fileop.c for details.

	Revision 1.2  1996/02/18 14:01:36  kuehnel
	Neue Funktion: file_copy

	Revision 1.1  1995/12/10 20:28:09  kuehnel
	Initial revision

 	$Date: 1996/06/18 17:24:35 $
   ---------------------------------------------------------------------------

*/

/*
   Function:     read_to_nl
   Parameters:   FILE *fd   
                 char *str  
   Return-Value: int, the number of chars read
   Remarks:      Reads from actual file position til next new-line-character
*/
extern int read_to_nl (FILE *fd,char *str);

/*
   Function:     match
   Parameters:   char *muster   
                 char *str  
   Return-Value: -
   Remarks:      compares the beginning of the line with muster, returns
                 1 if muster matches line
*/
extern int match (char *muster,char *line);

/*
   Function:     file_copy
   Parameters:   char *name1
                 char *name2
   Return-Value: int 0 if ok !0 else
   Remarks:      Copies file "name1" to "name2". 
                 Algorithm may be suboptimal!
*/
extern int file_copy (char *name1,char *name2);
