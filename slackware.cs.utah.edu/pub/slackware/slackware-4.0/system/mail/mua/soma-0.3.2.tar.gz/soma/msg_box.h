/* 

   Project:     soma - stefan's own mail application 
   File:        msg_box.c
   Description: Opens a window with an message in it
   Created:     18.12.1995
   Changed:     $Date: 1996/02/18 14:09:46 $
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: msg_box.h,v 1.2 1996/02/18 14:09:46 kuehnel Exp $
	$Author: kuehnel $
	$Log: msg_box.h,v $
	Revision 1.2  1996/02/18 14:09:46  kuehnel
	Neue Funktion "msg_box2" mit Auswahl-Alternative ("Yes"/"No").

 * Revision 1.1  1995/12/18  10:10:32  kuehnel
 * Initial revision
 *
 	$Date: 1996/02/18 14:09:46 $

   ---------------------------------------------------------------------------

*/

#include <xview/frame.h>

/*
   Function:     msg_box
   Parameters:   Frame owner
                 char *message
   Return-Value: 
   Remarks:      
*/
extern void msg_box (Frame owner, char *message);


/*
   Function:     msg_box_2
   Parameters:   Frame owner
                 char *message
		 char *first   - label for the first button
		 char *second  - label for the second button
   Return-Value: int - 1 first button, 2 second button pressed
   Remarks:      This function displays a message_box with two buttons.
*/
extern int msg_box_2 (Frame owner, char *message,char *first,char *second);


