/* 

   Project:     soma - stefan's own mail application 
   File:        msg_box.c
   Description: Opens a window with an message in it
   Created:     18.12.1995
   Changed:     $Date: 1996/02/18 14:09:16 $
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: msg_box.c,v 1.3 1996/02/18 14:09:16 kuehnel Exp $
	$Author: kuehnel $
	$Log: msg_box.c,v $
	Revision 1.3  1996/02/18 14:09:16  kuehnel
	Neue Funktion "msg_box2" mit Auswahl-Alternative ("Yes"/"No").

 * Revision 1.2  1996/01/07  16:48:23  kuehnel
 * #include "machine.h" ergaenzt.
 *
 * Revision 1.1  1995/12/18  10:07:02  kuehnel
 * Initial revision
 *
 	$Date: 1996/02/18 14:09:16 $

   ---------------------------------------------------------------------------

*/


#include <xview/notice.h>
#include <xview/frame.h>
#include <xview/panel.h>
#include "machine.h"

/*
   Function:     msg_box
   Parameters:   Frame owner
                 char *message
   Return-Value: 
   Remarks:      
*/
void msg_box (Frame owner, char *message)
{
  int result;

  result = notice_prompt (owner, NULL,
		      NOTICE_MESSAGE_STRING, message,
		      NOTICE_BUTTON, "OK", 101,
		      NULL);


}

/*
   Function:     msg_box_2
   Parameters:   Frame owner
                 char *message
		 char *first   - label for the first button
		 char *second  - label for the second button
   Return-Value: int - 1 first button, 2 second button pressed
   Remarks:      This function displays a message_box with two buttons.
*/
int msg_box_2 (Frame owner, char *message,char *first,char *second)
{
  int result;

  result = notice_prompt (owner, NULL,
			  NOTICE_MESSAGE_STRING, message,
			  NOTICE_BUTTON, first, 101,
			  NOTICE_BUTTON, second, 102,
			  NULL);
  return result-100;
}








