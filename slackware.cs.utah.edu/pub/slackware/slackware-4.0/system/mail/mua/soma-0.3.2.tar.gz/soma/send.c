/* 

   Project:     soma - stefan's own mail application 
   File:        send.c
   Description: Communication with SMTP via Socket
   Created:     14.12.1995
   Changed:     $Date: 1996/02/01 21:14:23 $
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: send.c,v 1.6 1996/02/01 21:14:23 kuehnel Exp $
	$Author: kuehnel $
	$Log: send.c,v $
	Revision 1.6  1996/02/01 21:14:23  kuehnel
	Kleinere �nderungen (bei Fehlermeldungen f�r select)

	Revision 1.5  1996/01/27 14:20:00  kuehnel
	Fehler in write_to_socket und read_from_socket behoben. Jetzt wird
	statt dem festen und falschen Wert 3 der File-Deskriptor des
	entsprechenden Sockets in das jeweilige FD_SET geschrieben.

	Revision 1.4  1996/01/10 21:16:45  kuehnel
	Laengeres Timeout.

 * Revision 1.3  1996/01/07  16:48:30  kuehnel
 * #include "machine.h" ergaenzt.
 *
 * Revision 1.2  1995/12/17  19:36:14  kuehnel
 * Verbessert: SMTP-Server wird aus Variable gelesen (mit Funktion get_smtpserver)
 *
 * Revision 1.1  1995/12/14  18:28:11  kuehnel
 * Initial revision
 *
 	$Date: 1996/02/01 21:14:23 $

   ---------------------------------------------------------------------------

*/

#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <netdb.h>
#include <unistd.h>
#include "global.h"
#include "machine.h"

/*
   Function:     read_from_socket
   Parameters:   
   Return-Value: 
   Remarks:      
*/
void read_from_socket (int fd,char *buff,int len)
{
  int amnt,lfd,i;
  struct timeval tv;
  fd_set rset,wset,eset;

  lfd=fd;

  FD_ZERO(&rset);
  FD_ZERO(&wset);
  FD_ZERO(&eset);

  /* FD_SET(0, &rset); */
  FD_SET(lfd, &rset);
  
  tv.tv_sec  = 60;    /* Set the Time-Out-Values, 5 seems too short */
  tv.tv_usec = 0;
  i=select (256,&rset,(fd_set *)&wset,(fd_set *)&eset,&tv);
 
  if (i<=0)
    {
      printf ("read_from_socket: Couldn't select: %s.\n",strerror(errno));
      exit (-1);
    }
  else
    if ((amnt=recv(fd,(void *)buff,len,0))<0)
      {
	printf ("Couldn't perform recv: %s \n",strerror(errno));
	exit (-1);
      }
    else buff[amnt]=(char)0;
}

/*
   Function:     write_to_socket
   Parameters:   
   Return-Value: 
   Remarks:      
*/
void write_to_socket (int fd,char *what)
{
  int lfd,i;
  fd_set wset,rset,eset;
  struct timeval tv;
  lfd=fd;

  FD_ZERO(&rset);
  FD_ZERO(&eset);

  FD_ZERO(&wset);
  /* FD_SET(0, &wset); */
  FD_SET(lfd, &wset);
  

  tv.tv_sec = 10;
  tv.tv_usec = 0;

  i=select (256,(fd_set *)&rset,(fd_set *)&wset,(fd_set *)&eset,&tv); 
  if (i<=0)
    {
      printf ("write_to_socket: Couldn't select: %s.\n",strerror(errno));
      exit (-1);
    }
  
  send (fd,(void *)what,strlen(what),0);

}


/*
   Function:     init_sock
   Parameters:   - 
   Return-Value: socket
   Remarks:      opens connection to rsmtp-Host
*/

int init_sock ()
{
  struct sockaddr_in sin;
  struct servent *sp;
  int i,fd;
  int optval=1;
  char str_addr[4];
  unsigned long int *addr;

#ifdef DEBUG_SEND
  int smtp_port;
#endif

  char service[STRSIZE],smtpserver[STRSIZE];
  struct hostent *hostptr;

  if ((fd=socket(AF_INET,SOCK_STREAM,0))<0)
    {
      fprintf (stderr,"Couldn't create socket: %s \n",strerror(errno));
      exit (-1);
    }
  else
    {
#ifdef DEBUG_SEND
      printf ("Socket created.\n");
#endif
    }
  
  strcpy (service,"smtp");
  setservent(0);
  sp=(struct servent *)getservbyname(service,NULL);
  endservent();
  if (sp==NULL)
    {
      fprintf (stderr,"Service %s not found: %s \n",service,strerror(errno));
      exit (-1);
    }
  else
    {
#ifdef DEBUG_SEND 
      smtp_port=(sp->s_port&0xFF00)>>8;
      printf ("Official Service-Name: %s \n",sp->s_name);
      printf ("Port-Number          : %d \n",smtp_port);
      printf ("Protocol to use      : %s \n",sp->s_proto);
#endif
    }
  
  sin.sin_family=AF_INET;
  sin.sin_port=sp->s_port; 

  get_smtpserver(smtpserver);
  hostptr=gethostbyname(smtpserver);

  if (hostptr==NULL)
    {
      fprintf (stderr,"Could not find SMTP-host: %s\n",strerror(errno));
      exit (-1);
    }

  for (i=0;i<4;i++) str_addr[i]=hostptr->h_addr_list[0][i];

  addr=(unsigned long int *)str_addr;
  sin.sin_addr.s_addr=*addr;

#ifdef DEBUG_SEND
  printf ("Smtpserver: %s (%x , %d.%d.%d.%d)",smtpserver,sin.sin_addr.s_addr,
	  str_addr[0],str_addr[1],str_addr[2],str_addr[3]);
#endif

  for (i=0;i<sizeof(sin.sin_zero);i++) sin.sin_zero[i]=0;


  if (connect(fd,(struct sockaddr *)&sin,sizeof (struct sockaddr_in))<0)
    {
      fprintf (stderr,"Couldn't connect: %s \n",strerror(errno));
      exit (-1);
    }
  
  optval = 1;
  setsockopt (fd,SOL_SOCKET,SO_OOBINLINE,&optval,sizeof(optval));
   
  return fd;
}








