/* 

   Project:     soma - stefan's own mail application 
   File:        getmail.h 
   Description: contains function to read the user's mail-file
   Created:     01 Dec. 1995
   Changed:     01 Dec. 1995 
   Author:      Stefan K�hnel <kuehnel@scoop.mst.uni-hannover.de>
   Copyright:   (C) 1995 by Stefan K�hnel

   ---------------------------------------------------------------------------
   RCS Informationen:

	$Id: getmail.h,v 1.7 1996/02/21 21:56:22 kuehnel Exp $ 
	$Author: kuehnel $
	$Log: getmail.h,v $
	Revision 1.7  1996/02/21 21:56:22  kuehnel
	header fuer store_message ergaenzt

	Revision 1.6  1996/01/07 14:18:33  kuehnel
	Header fuer delete_message ergaenzt.

 * Revision 1.5  1995/12/10  20:28:23  kuehnel
 * �berarbeitet.
 *
 * Revision 1.4  1995/12/09  20:40:25  kuehnel
 * Neueste Version. Funktioniert ausgezeichnet.
 *
 * Revision 1.3  1995/12/06  23:49:52  kuehnel
 * Prototyp fuer get_body.
 *
 * Revision 1.2  1995/12/06  23:41:12  kuehnel
 * ???
 *
 * Revision 1.1  1995/12/02  17:16:16  kuehnel
 * Initial revision
 *
 * Revision 1.1  1995/12/02  17:16:16  kuehnel
 * Initial revision
 *
 	$Date: 1996/02/21 21:56:22 $ 
   ---------------------------------------------------------------------------

*/

extern int read_mail_file (char *mailfile,struct msg_list **root);

/*
   Function:     get_msg_id
   Parameters:   struct msg_list *root 
                 int list_index
                 char *msg_id 
   Return-Value: int
   Remarks:      
*/

extern int get_msg_id (struct msg_list *root,int list_index, char *msg_id);

/*
   Function:     get_body_first_line
   Parameters:   FILE **fd      - filedescriptor of mailfile is returned
                 char *mailfile - name of mailfile
                 char *msg_id   - msg_id
   Return-Value: int            - not zero if found, else zero
   Remarks:      searching for first body line of message with given id
*/

extern int get_body_first_line (FILE **fd, char *mailfile, char *msg_id);

/*
   Function:     get_body_line
   Parameters:   FILE *fd   - filedescriptor of mailfile     
                 char *line - returned line
   Return-Value: int        - not zero if found, else zero
   Remarks:      
*/

extern int get_body_line (FILE *fd, char *line);

/*
   Function:     get_msg_list_entry
   Parameters:   struct msg_list *root 
                 int list_index
                 struct message *return 
   Return-Value: int
   Remarks:      
*/

extern int get_msg_list_entry (struct msg_list *root,int list_index,
			       struct message *ret);

/*
   Function:     delete_message
   Parameters:   char *mailfile, name of the mailfile from which to delete
                 char *msg_id,   id of message to be deleted
   Return-Value: 0  - message could not be deleted
                 /0 - succes
   Remarks:      
*/
extern int delete_message (char *mailfile, char *msg_id);


/*
   Function:     store_message
   Parameters:   char *mailfile
                 char *folder
                 char *msg_id
   Return-Value: 0 - Message could not be stored
                 !0 - Message was successfully stored
   Remarks:      Stores message with id msg_id from 
                 mailfile in an alternative folder
*/

extern int store_message (char *mailfile, char *folder, char *msg_id);






