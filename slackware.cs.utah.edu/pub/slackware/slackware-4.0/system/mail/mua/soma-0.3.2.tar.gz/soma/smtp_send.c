/* 

   Project:     soma - stefan's own mail application 
   File:        smtp_send
   Description: smtp_send is a utility for sending
                mail via smtp from the users spool_file
   Created:     
   Changed:     $Date: 1996/04/20 10:31:47 $
   Author:      Stefan K�hnel <kuehnel@stud.uni-hannover.de>
   Copyright:   (C) 1995,1996 by Stefan K�hnel

   ---------------------------------------------------------------------------

   RCS Informationen:

	$Id: smtp_send.c,v 1.2 1996/04/20 10:31:47 kuehnel Exp kuehnel $
	$Author: kuehnel $
	$Log: smtp_send.c,v $
	Revision 1.2  1996/04/20 10:31:47  kuehnel
	function main: improved command-line-parsing

	Revision 1.1  1996/02/23 11:26:08  kuehnel
	Initial revision

 	$Date: 1996/04/20 10:31:47 $

   ---------------------------------------------------------------------------

*/
#include <unistd.h>
#include "send.h"
#include "global.h"
#include "fileop.h"
#include "machine.h"

/* uncomment the following option if you want to get debug-output */
/* #define DEBUG_SMTP_SEND */

/*
   Function:     smtp_send
   Parameters:   char *spool_file_name - Name des Spool-Files
   Return-Value: int                   - Anzahl der versendeten Mails
   Remarks:      
*/
int smtp_send (char *spool_file_name)
{
  char smtp_server[STRSIZE];
  int sock,zahl=0;
  char buff[1024],line[4095],buffer[4096];
  FILE *spool_fd;

  if ((spool_fd=fopen(spool_file_name,"r"))!=NULL)
    {
      get_smtpserver(smtp_server);
      sock = init_sock();
      read_from_socket (sock,buff,1024);
#ifdef DEBUG_SMTP_SEND
      printf ("%s\n",buff);
#endif
      while (!feof(spool_fd))
	{
	  do 
	    {
	      read_to_nl (spool_fd,line);
	      if (match("HELO",line)||match("MAIL FROM:",line)||
		  match("RCPT TO:",line))
		{
#ifdef DEBUG_SMTP_SEND
		  printf ("%s\n",line);
#endif
		  sprintf (buffer,"%s\n",line);
		  write_to_socket (sock,buffer);
		  read_from_socket (sock,buff,1024);
#ifdef DEBUG_SMTP_SEND
		  printf ("%s\n",buff);
#endif
		}
	    }
	  while ((!match("DATA",line))&&(!feof(spool_fd)));
	  if (!feof(spool_fd))
	    {
	      sprintf (buffer,"%s\n",line);
	      write_to_socket (sock,buffer);
	      read_from_socket (sock,buff,1024);
#ifdef DEBUG_SMTP_SEND
	      printf ("%s\n",buff);
#endif
	      do
		{
		  read_to_nl (spool_fd,line);
		  if (!match("QUIT",line))
		    {
		      sprintf (buffer,"%s\n",line);
		      write_to_socket (sock,buffer);
		    }
		  else
		    {
#ifdef DEBUG_SMTP_SEND
		      printf ("going to write a '.'\n");
#endif
		      write_to_socket (sock,"\n.\r\n");
		      read_from_socket (sock,buff,1024);
#ifdef DEBUG_SMTP_SEND
		      printf ("%s\n",buff);
#endif
		      zahl++;
		    }
		}
	      while (!match("QUIT",line));
	    }
	} /* if not feof (spool_fd) */
      fclose (spool_fd);
#ifdef DEBUG_SMTP_SEND
      printf ("going to write QUIT\n");
#endif
      write_to_socket(sock,"QUIT\r\n");
      read_from_socket (sock,buff,1024);
#ifdef DEBUG_SMTP_SEND
      printf ("%s\n",buff);
#endif
      close (sock);
    }
  else
    {
      printf ("Could not open %s\n",spool_file_name);
    }
  return zahl;
}


int main (int argc, char **argv)
{
  char spool_file_name[STRSIZE]; 
  char smtp_server[STRSIZE];
  int k,i,verbose=0;

  /* Get default values */

  get_user_information ();
  get_spool_file (spool_file_name);
  get_smtpserver(smtp_server);

  /* Parse the command line */

  if (argc>1)
    {

      for (i=1;i<argc;i++)
	{
	  if (strcmp(argv[i],"-f")==0)
	    {
	      strcpy (spool_file_name,argv[++i]);
	    }
	  else if (strcmp(argv[i],"-s")==0)
	    {
	      strcpy (smtp_server,argv[++i]);
	      set_smtpserver (smtp_server); /* Set the global variable */
	    }
	  else if (strcmp(argv[i],"-v")==0)
	    {
	      verbose=1;
	    }
	  else if ((strcmp(argv[i],"-h")==0)||(strcmp(argv[i],"-?")==0))
	    {
	      printf ("Usage: %s [-s <smtp_server>][-f <spool_file>] [-v] [-h|-?]\n",
		      argv[0]);
	      printf ("Defaults are '%s' for <smtp_server> \n",smtp_server);
	      printf ("and '%s' for <spool_file>\n",spool_file_name);
	      return 0; /* No actions */
	    }
	}
    }
  
  if (verbose)
    {
      printf ("Going to send messages from file '%s' to server '%s' ...",
	      spool_file_name,smtp_server);
      
    }
  k=smtp_send (spool_file_name);
  if (k>0)
    {
      if (remove(spool_file_name)!=0)
	{
	  printf ("Could not remove file %s\n",spool_file_name);
	}
    }
  if (verbose)
    {
      printf ("%s: %d messages sent to %s \n",argv[0],k,smtp_server);
    }

  return 0;
}



