/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TWindow.h"

void TWindow::ShowWindow()
	{
	logfile("TWindow::ShowWindow");               
	int x,y;
	mvaddch(winy1,winx1,ACS_ULCORNER);        //narozniki okna
	mvaddch(winy2,winx1,ACS_LLCORNER);
	mvaddch(winy1,winx2,ACS_URCORNER);
	mvaddch(winy2,winx2,ACS_LRCORNER);
	for(y=winy1+1;y<winy2;y++)       //linie pionowe ramki
		{
		mvaddch(y,winx1,ACS_VLINE);    
		mvaddch(y,winx2,ACS_VLINE);
		}
	for(x=winx1+1;x<winx2;x++)
		{
		for(y=winy1+1;y<winy2;y++)     //wypelnianie powierzchni okna
		mvaddch(y,x,' ');
		mvaddch(winy1,x,ACS_HLINE);          //linie poziome ramki
		mvaddch(winy2,x,ACS_HLINE);
		}
	int titlelength=0;             //obliczenie dlugosci tytulu
	titlelength=strlen(title);     //i wypisanie go na srodku
	mvaddstr(winy1,((winx2-winx1)>>1)+winx1-(titlelength>>1),title);
	}

void TWindow::GetWindow()
	{
	logfile("TWindow::GetWindow");   
	int x,y,licznik=0;
	if(window!=MYNULL) { delete[] window; window=MYNULL; }
	window=new chtype[(winx2-winx1+1)*(winy2-winy1+1)];
	for(y=winy1;y<=winy2;y++)
	for(x=winx1;x<=winx2;x++)
	window[licznik++]=mvinch(y,x);
	
	}
void TWindow::PutWindow()
	{
	logfile("TWindow::PutWindow");   
	int x,y,licznik=0;
	attrset(A_NORMAL);
	for(y=winy1;y<=winy2;y++)
	for(x=winx1;x<=winx2;x++)
		{
		mvaddch(y,x,window[licznik++]);
		}
	}

void TWindow::user_mvaddstr(int y, int x, int maxlen, char *str)
	{
	logfile("TWindow::user_mvaddstr");  
	if(maxlen>strlen(str)) maxlen=strlen(str);
	char *txt=new char[maxlen+1];
	int i,ustaw_zero=0;
	for(i=0;i<0;i++)
	if(str[i]==0) ustaw_zero=1;
	if(!ustaw_zero)
	for(i=0;i<maxlen;i++)
	txt[i]=str[i+0];
	else
	txt[0]=0;
	txt[maxlen]=0; 
	mvaddstr(y,x,txt);
	delete[] txt;
	}

