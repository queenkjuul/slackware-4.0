#ifndef _TMARKINGDIALOG_H
#define _TMARKINGDIALOG_H
#include "TMenu.h"
#include "TInputField.h"
#include <regex.h>

class TMarkingDialog {
	TMenu *menu;
	long cur_msg,max_msg;
	pchar *list;
	int x1,y1,x2,y2;
	long *startpos;
	long *endpos;
	char *filename;
	
	void MarkAll();
	void InvertAll();
	void InvertUp();
	void InvertDown();
	void MarkDown();
	void MarkUp();
	void UnmarkDown();
	void UnmarkUp();
	void UnmarkAll();
	void MarkRegexp();
	public:
	void Keyboard();
	TMarkingDialog(int x,int y,int x_1,int y_1,long curmsg,
	long maxmsg,pchar *thelist,
	long *spos,long *epos,char *file):
	cur_msg(curmsg),max_msg(maxmsg),list(thelist),
	x1(x),y1(y),x2(x_1),y2(y_1),
	startpos(spos),endpos(epos),
	filename(file)
		{
		static char *options[10]=
			{"Mark all messages      ",
			"Invert < than current  ",
			"Invert > than current  ",
			"Match regexp           ",
			"Mark < than current    ",
			"Mark > than current    ",
			"Unmark < than current  ",
			"Unmark > than current  ",
			"Unmark all messaes     ",
			"Invert all messages    "};
		static char *descriptions[10]=			   
			{"Makrs all messages in the base",
			"Inverts messages, which appear in the list before current message",
			"Inverts messages, which appear in the list after current message",
			"Inverts messages, with specified expression in their body or headers",
			"Marks messages, which appear in the list before current message",
			"Marks messages, which appear in the list after current message",
			"Unmarks messages, which appear in the list before current message",
			"Unmarks messages, which appear in the list after current message",
			"Unmarks all messages in the base",
			"Inverts all messages in the base"};
		menu=new TMenu(options,descriptions,10,x1,y1,x1+27,y1+11);
		}
	~TMarkingDialog()
		{
		delete menu;
		}
	};

#endif
