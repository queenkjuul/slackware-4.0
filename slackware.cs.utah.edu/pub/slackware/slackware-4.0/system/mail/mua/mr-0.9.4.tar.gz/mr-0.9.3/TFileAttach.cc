/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TFileAttach.h"

void TFileAttach::Keyboard()
	{
	int key=0;
	int bye=0;
	while((key!=KEY_ESC)&&(!bye))
		{
		key=user_getch();
		switch(key)
			{
			case 'w':
			SaveFile();
			break;
			case 'm':
			RunMetamail();
			break;
			} 
		}   
	}
void TFileAttach::RunMetamail()
	{
	if(attach[-headerpos][0]=='-') headerpos--;
	FILE *metamail=popen("metamail","w");
	endwin();
	for(long i=0-headerpos;i<=maxy;i++)
	fprintf(metamail,"%s\n",attach[i]);
	pclose(metamail);
	getch();
	doupdate();
	}
void TFileAttach::SaveFile()
	{
	unsigned char *data=new unsigned char[1];   
	char *defaultname=new char[255];
	defaultname[0]=0;
	long filelen=0;
	int j=0;
	long length_of_file=0;
	if(CompareStr(content_transfer,"BASE64",6,1))
		{
		TBASE64 decoder(&data,&attach,&maxy,0,&filelen);
			{TWindow d(20,7,60,9,"Info");
			d.ShowWindow();
			mvaddstr(8,26,"Decoding message...");
			refresh();
			decoder.Decode();}
		for(int i=0;i<strlen(content_type);i++)
			{
			if((content_type[i]=='n')||(content_type[i]=='N'))
				{
				if(CompareStr("name=",content_type+i,5,1))
					{
					if(content_type[i+5]=='"')
					for(j=0,i=i+6;content_type[i]!='"';j++,i++)
					defaultname[j]=content_type[i];  
					else
					for(j=0,i=i+5;content_type[i]!=' ';j++,i++)
					defaultname[j]=content_type[i];
					defaultname[j]='\0';                  
					}  
				}
			}
		}
	else
		{
		for(int i=0;i<=maxy;i++)
			{
			for(int k=0;k<strlen(attach[i]);k++)
			if(attach[i][k]!='=') 
				{
				length_of_file++;
				data=(unsigned char*)realloc(data,length_of_file+10);
				data[length_of_file-1]=attach[i][k];
				}
			else
				{
				if(attach[i][k+1]=='\0')
					{
					i++;k=-1;
					if(i==maxy+1) break;
					}
				else
					{
					unsigned char val=0;
					length_of_file++;
					data=(unsigned char*)realloc(data,length_of_file+10);
					if(attach[i][k+1]<'A') 
					val=((unsigned char)attach[i][k+1]-'0')*16;
					else val=((unsigned char)attach[i][k+1]-'A'+10)*16;
					if(attach[i][k+2]<'A') 
					val+=((unsigned char)attach[i][k+2]-'0');
					else val+=((unsigned char)attach[i][k+2]-'A'+10);
					data[length_of_file-1]=val;
					k+=2;
					}
				}
			if(i<maxy)
				{
				length_of_file++;
				data=(unsigned char*)realloc(data,length_of_file+10);
				data[length_of_file-1]='\n';
				}
			}
		filelen=length_of_file;
		}
	FILE *id;
	attrset(savemessagewindowcolor);
	TWindow okienko(15,5,65,8,"Save message");
	okienko.ShowWindow();
	mvaddstr(6,17,"Enter the filename (or escape for cancel)");
	TInputField savemsg(17,7,46,defaultname);
	savemsg.GetString();
	if(!savemsg.CheckEscape())
		{
		if((id=fopen(savemsg.ReturnString(),"r"))==MYNULL)  
			{
			if((id=fopen(savemsg.ReturnString(),"wb"))!=MYNULL)
				{
				fwrite(data,1,filelen,id);
				fclose(id);  
				}
			}   
		else {
			fclose(id);
			TWindow okno(20,8,60,10,"File exists!");
			okno.ShowWindow();
			mvaddstr(9,31,"Overwrite? (y/n)");
			refresh();
			int key=0;
			while((key!='n')&&(key!='N')&&(key!='y')&&(key!='Y')) key=getch();
			if((key=='y')||(key=='Y'))
			if((id=fopen(savemsg.ReturnString(),"wb"))!=MYNULL)
				{
				fwrite(data,1,filelen,id);
				fclose(id);  
				}
			
			}        
		}     
	delete[] data;
	delete[] defaultname;             
	}

