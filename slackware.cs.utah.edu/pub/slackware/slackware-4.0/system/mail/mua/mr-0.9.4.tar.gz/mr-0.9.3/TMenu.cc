/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TMenu.h"

void TMenu::Keyboard()
	{
	logfile("TMenu::Keyboard");   
	int key;   
	ungetch(KEY_UP);
	do
		{
		ShowWindow();  
		key=user_getch();
		TList::KeyboardInternal(key);
		}
	while((key!=KEY_LEFT)&&(key!=KEY_RIGHT)&&(key!='\n')&&(key!=KEY_ESC));
	if(key!='\n') escape=1;
	else escape=0;
	if((key!=KEY_ESC)&&(key!='\n'))
		{ungetch('\n');ungetch(key);}
	}
void TMenu::ShowWindow()
	{
	logfile("TMenu::ShowWindow");  
	int x,y;
	getmaxyx(stdscr,y,x);
	TList::ShowWindow();
	attrset(submenutextcolor);
	for(int i=winx1+1;i<winx2;i++)
	mvaddch(winy1,i,ACS_HLINE);
	for(int i=winy1+1;i<winy2;i++)
	mvaddch(i,winx2,ACS_VLINE);   
	StatusLine(status[GetElement()]);
	} 

