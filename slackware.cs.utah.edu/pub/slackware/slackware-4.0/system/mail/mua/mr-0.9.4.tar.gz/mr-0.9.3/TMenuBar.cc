/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TMenuBar.h"

int TMenuBar::Keyboard()
	{
	logfile("TMenuBar::Keyboard");  
	int l,i,n;
	int ret_value;
	int key=0;
	while((key!=KEY_ESC)&&(key!='\n')&&(key!=KEY_DOWN))
		{
		ShowBar();
		l=0;
		for(i=opt-1;i>=0;i--)
		l+=strlen(menu[i][0])+2;
		attrset(menubarselectedcolor);
		mvaddstr(0,l+2,menu[opt][0]);    
		key=user_getch();  
		switch(key)
			{
			case KEY_LEFT:
			if(opt>0) opt--;
			else opt=mb_cnt;
			break;
			case KEY_RIGHT:
			if(opt<mb_cnt) opt++;
			else opt=0;
			break;
			default:
			if((key=='\n')||(key==KEY_DOWN))
				{
				n=0;
				for(i=count[opt];i>0;i--)
				if(strlen(menu[opt][i])>n) n=strlen(menu[opt][i]);
				TMenu submenu(&menu[opt][1],&status[opt][1],count[opt],l+1,1,l+n+6,1+count[opt]+1);
				submenu.Keyboard();              
				if(submenu.CheckEscape()) key=0;
				else ret_value=submenu.GetElement()+opt*1000;
				}
			}
		StatusLine(status[opt][0]);    
		}
	if(key!=KEY_ESC)    
	return ret_value;
	else 
	return -1;  
	}             
void TMenuBar::ShowBar()             
	{
	logfile("TMenuBar::ShowBar"); 
	char *bar=new char[255]; 
	char *nic="  ";
	int x,y,i;
	attrset(menubarcolor);
	getmaxyx(stdscr,y,x);
	for(i=0;i<=x;i++)
	mvaddch(0,i,' ');
	sprintf(bar,"\0");
	for(i=0;i<=mb_cnt;i++)
		{
		strcat(bar,nic);
		strcat(bar,menu[i][0]);  
		} 
	mvaddstr(0,0,bar);    
	delete[] bar;
	}
TMenuBar::TMenuBar(char *ptr) : menu(MYNULL), status(MYNULL), sub_cnt(-1), mb_cnt(-1), count(MYNULL),opt(0)
	{
	logfile("TMenuBar::TMenuBar");  
	ProgramPosition=TMENUBAR;  
	int i;  
	int st=0;
	int l=0,l1;
	for(i=0;i<strlen(ptr);i++)
		{
		if(ptr[i]=='\r')
			{
			st=0;  
			if(i>0) {menu[mb_cnt][sub_cnt][l]='\0';
				status[mb_cnt][sub_cnt][l1]='\0';
				count[mb_cnt]=sub_cnt;  }
			l=0,l1=0;  
			sub_cnt=0,mb_cnt++;  
			menu=(ppchar*)realloc(menu,sizeof(ppchar)*(mb_cnt+1));
			count=(int*)realloc(count,sizeof(int)*(mb_cnt+1));
			menu[mb_cnt]=new pchar[1];
			menu[mb_cnt][sub_cnt]=new char[255];
			status=(ppchar*)realloc(status,sizeof(ppchar)*(mb_cnt+1));
			status[mb_cnt]=new pchar[1];
			status[mb_cnt][sub_cnt]=new char[255];
			}
		else if(ptr[i]=='\n')
			{
			st=0;  
			if(i>0) {menu[mb_cnt][sub_cnt][l]='\0';
				status[mb_cnt][sub_cnt][l1]='\0';}
			l=0,l1=0;  
			sub_cnt++;
			menu[mb_cnt]=(pchar*)realloc(menu[mb_cnt],sizeof(pchar)*(sub_cnt+1));
			menu[mb_cnt][sub_cnt]=new char[255];
			status[mb_cnt]=(pchar*)realloc(status[mb_cnt],sizeof(pchar)*(sub_cnt+1));
			status[mb_cnt][sub_cnt]=new char[255];
			}
		else if(ptr[i]==':') st=1;    
		else if(ptr[i])    
			{
			if(!st)   
			menu[mb_cnt][sub_cnt][l]=ptr[i],l++;
			else
			status[mb_cnt][sub_cnt][l1]=ptr[i],l1++;
			}
		}
	menu[mb_cnt][sub_cnt][l]='\0';     
	count[mb_cnt]=sub_cnt;  
	}

