/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TViewTextMsg.h"

void TViewTextMsg::ShowWindow()
	{
	logfile("TViewTextMsg::ShowWindow");  
	char *str=new char[255];
	int a=minimum_line+filepos;
	TView::ShowWindow();
	if((signature>=0)&&(signature-a>=0))
	if(a+MaxHeight()>signature)
		{
		userline=1; 
		if(MaxHeight()+filepos<=maxy)
			{
			for(long i=signature;i<=a+MaxHeight();i++) 
			if(cur_col<strlen(file[i]))  
			user_mvaddstr(winy1+1+(i-a),winx1+1,
			MaxWidth(),file[i]+cur_col);
			}
		else    
			{
			for(long i=signature;i<=maxy+minimum_line;i++)   
			if(cur_col<strlen(file[i]))  
			user_mvaddstr(winy1+1+(i-a),winx1+1,
			MaxWidth(),file[i]+cur_col);
			}
		userline=0;
		}
	delete[] str;
	StatusLine("Arrows:Browse l:Msglst t:Thrds v:Headers (I)NS:New q:Reply s:Mark F10:Menu");
	}                  
void TViewTextMsg::user_mvaddstr(int y,int x,int maxlen,char *str)
	{
	attr_t attrs;
	int j;
	logfile("TViewTextMsg::user_mvaddstr");  
	int highlighted=0;  
	if(maxlen>strlen(str)) maxlen=strlen(str);
	if((str[0]=='>')||(str[0]==':'))
	attrset(viewerquotedcolor);
	else if(userline)
	attrset(signaturecolor);
	else
	attrset(viewertextcolor);
	
	for(int i=0;i<maxlen;i++)
		{
		if(str[i]=='_') 
			{
			mvaddch(y,x+i,str[i] & A_CHARTEXT);
			for(j=i+1;j<maxlen;j++) 
			if(str[j]==' ') {mvaddch(y,x+i,str[i] & A_CHARTEXT);break;}
			else if(str[j]=='_')
				{
				attrs=attr_get();
				attrset(underlined);
				for(int k=i;k<=j;k++)
				mvaddch(y,x+k,str[k] & A_CHARTEXT);
				attrset(attrs);
				i=j;
				break;
				}
			
			}
		else if(str[i]=='*') 
			{
			mvaddch(y,x+i,str[i] & A_CHARTEXT);
			for(j=i+1;j<maxlen;j++) 
			if((str[j]==' ')) {mvaddch(y,x+i,str[i] & A_CHARTEXT);break;}
			else if(str[j]=='*')
				{
				attrs=attr_get();
				attrset(boldtext);
				for(int k=i;k<=j;k++)
				mvaddch(y,x+k,str[k] & A_CHARTEXT);
				attrset(attrs);
				i=j;
				break;
				}
			}
		else if(str[i]=='/') 
			{
			mvaddch(y,x+i,str[i] & A_CHARTEXT);
			for(j=i+1;j<maxlen;j++) 
			if((str[j]==' ')) {mvaddch(y,x+i,str[i] & A_CHARTEXT);break;}
			else if(str[j]=='/')
				{
				attrs=attr_get();
				attrset(italictext);
				for(int k=i;k<=j;k++)
				mvaddch(y,x+k,str[k] & A_CHARTEXT);
				attrset(attrs);
				i=j;
				break;
				}
			}
		else if(str[i]=='@') 
			{
			mvaddch(y,x+i,str[i] & A_CHARTEXT);
			for(j=i;j>=0;j--) 
			if((str[j]==' ')||(j==0))
				{
				if(str[j]==' ') j++;
				int k;
				attrs=attr_get();
				attrset(emailhighlighttext);
				for(k=j;(str[k]!=' ')&&(k<maxlen);k++)
				mvaddch(y,x+k,str[k] & A_CHARTEXT);
				attrset(attrs);
				i=k;
				break;
				}
			}
		else 
		mvaddch(y,x+i,str[i] & A_CHARTEXT);
		}
	}
void TViewTextMsg::Keyboard()
	{
	logfile("TFolderView::Keyboard");   
	int key,semafor=0;
	char *tmpstr=new char[255];
	do
		{
		key=user_getch();
		ProgramPosition=TFOLDERVIEW;  
		switch(key)
			{
			case 'v':
			if(!getenv("PBMR_SHOWHEADERS")) 
			ShowHeaders();
			else
			HideHeaders();
			ShowWindow();  
			break;     
			case 's':
			semafor=1;
			break;
			case 't':
			semafor=1;
			break;
			case 'l':
			semafor=1;
			break;
			case KEY_UP:
			MoveUp(); 
			break;
			case KEY_DOWN:
			MoveDown();
			break;
			case KEY_RIGHT:
			semafor=1;
			break; 
			case KEY_LEFT:
			semafor=1;
			break;
			case KEY_NPAGE:
			PgDn();
			break;
			case KEY_PPAGE:
			PgUp();
			break;
			case '+':
			semafor=1;
			break;
			case '-':
			semafor=1;
			break;
			case 'g':
			semafor=1;
			break;
			case 'q':
			InsertMessage(REPLY);
			break;  
			case 'f':
			//           TForwardFolderList forward(winx1,winy1,winx2,winy2);
			InsertMessage(FORWARD);
			break;   
			case 'c':
			InsertMessage(COMMENT);
			break;   
			case KEY_DC:
			semafor=1;
			break;  
			case 'i': 
			case KEY_IC:
			InsertMessage(NEW);
			break;   
			case KEY_F(10):
			MenuPlay();
			break;
			case KEY_F(1):
			semafor=1;
			break;    
			case KEY_F(6):
			semafor=1;
			break;    
			case 'w':
			SaveMsg();
			break;    
			case ' ':
			semafor=1;
			break;    
			}
		}
	while((key!=KEY_ESC)&&(!semafor));
	nofoldergetch=key;
	if(key==KEY_ESC) ungetch(KEY_ESC);
	delete[] tmpstr;     
	}

void TViewTextMsg::WriteQuotedMsg(int reply)    //zapisanie i zaquotowanie listu
	{
	logfile("TFolderView::WriteMsg");         
	FILE *id,*id1;
	char *path=new char[255];
	char *str=new char[255];
	Template(reply,from,email,to,toemail,subj,date);
	sprintf(path,"%s/.mr/mailfile.%ld.tmp",getenv("HOME"),(long)getpid());
	id=fopen(path,"at");
	if((reply!=NEW)&&(reply!=FORWARD))
	for(int i=GetMinimumLine();i<maxy+GetMinimumLine();i++)
		{
			{
			char *atoms=new char[255];    
			sprintf(atoms," ");
			int cnt=i+1,qlen=0;
			while(file[i][qlen]=='>') qlen++; //ilosc znakow quotowania
			ConcatenateAtoms(atoms,file[i]);
			//                while(cnt<maxy+GetMinimumLine())
			//                       {
			//                    if(CheckIfRefillingIsAllowed(file[i],file[cnt])) 
			//                     { ConcatenateAtoms(atoms,file[cnt]);
			//                      cnt++;}
			//                    else
			//                      break;  
			//                        }
			WriteAtoms(qlen+1,atoms,id);
			i=cnt-1;
			delete[] atoms;
			}
		}
	else if(reply==FORWARD)
		{
		fprintf(id,"%s\n",rc_forwardbanner);
		for(int i=GetMinimumLine();i<maxy+GetMinimumLine();i++)
		fprintf(id,"%s\n",file[i]);  
		}         
	else fprintf(id,"\n");          
	fclose(id);   
	Template(SIGNATURE,from,email,to,toemail,subj,date);
	delete[] str;
	delete[] path; 
	}
void TViewTextMsg::WriteAtoms(int qlen,char *atoms,FILE *id)
	{
	logfile("TFolderView::WriteAtoms");  
	FILE *id1;
	int a;
	char *str=new char[255];
	int linelength=1;
	long count=0,maxlen=strlen(atoms);
	for(int i=0;i<qlen;i++)
		{
		fprintf(id,">");
		linelength++;  
		}  
	if(atoms[0])
	while(count<maxlen)
		{
		do
			{
			if(atoms[count])  
				{fprintf(id,"%c",atoms[count]);
				linelength++;  
				count++;}  
			if(count>=maxlen) break;
			}
		while(atoms[count]!=' ');
		int tmplen=1;
		if(count<maxlen)
			{
			while((atoms[count+tmplen]!=' ')&&(count+tmplen<maxlen)) tmplen++;
			if(linelength+tmplen>72)
				{ 
				fprintf(id,"\n"); linelength=1;
				for(int i=0;i<qlen;i++)
					{
					fprintf(id,">");
					linelength++;  
					}  
				}
			}                       
		}  
	fprintf(id,"\n");       
	delete[] str;
	}

void TViewTextMsg::ConcatenateAtoms(char *&atoms,char *str)
	{
	logfile("TFolderView::ConcatenateAtoms"); 
	long newsize=strlen(atoms)+strlen(str)+255;
	int ok=0,tmp=0;
	if((atoms==MYNULL)&&(!newsize)) ok=1;
	atoms=(char*)realloc(atoms,newsize);
	if((atoms==MYNULL)&&(!ok))
		{
		printf("\n Memory allocation error: \n"
		"Failed by concatenating atoms for\n"
		"justifing the quote for the reply\n"
		"Hypothetical problem: Out of memory\n");
		exit(1);   
		}
	while(str[tmp]=='>') ++tmp;
	strcat(atoms,str+tmp);
	strcat(atoms," ");
	}

int TViewTextMsg::CheckIfRefillingIsAllowed(char *line1,char *line2)
	{
	logfile("TFolderView::CheckIfRefillingIsAllowed"); 
	int i=0; 
	while(line1[i]==line2[i]) if(line1[i]!='>') { return 1;}
	else i++;
	if(line2[0]==0) { return 0; }
	if((line1[i]!='>')&&(line2[i]!='>')) { return 1; }
	return 0;                          
	}

void TViewTextMsg::SaveMsg()
	{
	logfile("TFolderView::SaveMsg");  
	FILE *id;
	attrset(savemessagewindowcolor);
	TWindow okienko(15,5,65,8,"Save message");
	okienko.ShowWindow();
	mvaddstr(6,17,"Enter the filename (or nothing for cancel)");
	TInputField savemsg(17,7,46,"\0");
	savemsg.GetString();
	id=fopen(savemsg.ReturnString(),"r");
	if(id!=MYNULL)
		{
		fclose(id);
		TWindow okno(20,8,60,10,"File exists!");
		okno.ShowWindow();
		mvaddstr(9,31,"Overwrite? (y/a/n)");
		refresh();
		int key=0;
		while((key!='n')&&(key!='N')&&
		(key!='y')&&(key!='Y')&&
		(key!='a')&&(key!='A')) key=getch();
		if((key=='y')||(key=='Y'))
		id=fopen(savemsg.ReturnString(),"w");
		else if((key=='a')||(key=='A'))
		id=fopen(savemsg.ReturnString(),"a");
		
		}
	else
	id=fopen(savemsg.ReturnString(),"w");
	
	if(id!=MYNULL)
		{
		for(long i=0;i<maxy+GetMinimumLine();i++)
			{
			if(file[i][0]!='.')  
			fprintf(id,"%s\n",file[i]);
			else
			fprintf(id," %s\n",file[i]);
			}
		fclose(id);   
		}
	}

void TViewTextMsg::InsertMessage(int reply)
	{
	logfile("TViewText::InsertMessage");      
	char *tmpstr=new char[strlen(from)+strlen(email)+255];      
	sprintf(tmpstr,"\0");
	char *subject=new char[strlen(subj)+20];  
	char *tmpmsgid=new char[255];
	sprintf(subject,"\0");
	if(reply==REPLY)      
		{
		if(!defaultto[0])
			{     
			if(!secondfrom[0])
				{if(from[0])       
				sprintf(tmpstr,"\"%s\" <%s>",from,email);
				else
				sprintf(tmpstr,"%s",email);}
			else sprintf(tmpstr,"%s",secondfrom);
			}
		else sprintf(tmpstr,"%s",defaultto);       
		sprintf(subject,"%s",subj);
		}
	
	
	if(reply==COMMENT)
		{if(to[0])       
		sprintf(tmpstr,"\"%s\" <%s>",to,toemail);
		else
		sprintf(tmpstr,"%s",toemail);
		sprintf(subject,"%s",subj);}
	
	if(reply==NEW)
		{if(defaultto[0])
		sprintf(tmpstr,"%s",defaultto);
		sprintf(subject,"\0");}   
	if(reply==FORWARD)
		{if(defaultto[0])
		sprintf(tmpstr,"%s",defaultto);
		sprintf(subject,"%s",subj);}   
	
	if((reply==REPLY)||(reply==COMMENT))
	sprintf(tmpmsgid,"%s",msgid);
	else tmpmsgid[0]=0;
	THeaderModify
	head(GetWinX1(),
	GetWinY1()-6,
	GetWinX2(),
	GetWinY1()+5-6,
	tmpstr,subject,
	defaultcc,
	defaultbcc,
	replyto,
	"text/plain; charset=\"ISO-8859-2\"",
	"Quoted-Printable",
	tmpmsgid);
	head.Keyboard();
	if(!head.IsAborted())
		{
		sprintf(tmpstr,"%s/.mr/mailfile.%ld.tmp",getenv("HOME"),(long)getpid());
		WriteQuotedMsg(reply);
		
		if(!rc_alternateeditor[0])
			{
			TMailEdit reply(tmpstr,GetWinX1(),GetWinY1(),
			GetWinX2(),GetWinY2());
			reply.WriteMsg();                       
			if(!reply.CheckEscape())
				{SendMsg();max_msg++;}                       
			else  { unsetenv("PBMR_ATTACH"); unsetenv("PBMR_BOUNDARY"); }   
			}
		else
			{
			int x,y;
			char *str=new char[255];
			getmaxyx(stdscr,y,x);
			sprintf(str,"%s %s",rc_alternateeditor,tmpstr);
			endwin();
			system(str);
			doupdate();
			delete[] str;
			TWindow okienko(x/2-14,y/2-2,x/2+14,y/2+2,"Send message");
			okienko.ShowWindow();
			mvaddstr(y/2,x/2-10,"Send message (y/n)?");
			int a=getch();
			if((a=='y')||(a=='Y'))
				{SendMsg();max_msg++;}
			else  { unsetenv("PBMR_ATTACH"); unsetenv("PBMR_BOUNDARY"); }   
			}   
		}
	delete[] tmpmsgid;
	delete[] tmpstr;    
	delete[] subject;
	}                  


