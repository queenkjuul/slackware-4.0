/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TFILEVIEW_H
#define _TFILEVIEW_H
#include "TView.h"

class TFileView : public TView
	{
	int pos;
	public:
	TFileView(char *plik,int x,int y,int x1,int y1,int textcolr=A_NORMAL,int barcolr=A_REVERSE) :
	TView(plik,x,y,x1,y1,0,textcolr,barcolr),pos(0)
		{
		logfile("TFileView::TFileView");               
		FILE *id=fopen(plik,"rt");
		if(id!=MYNULL)
			{
			fseek(id,0,SEEK_END);
			long len=ftell(id);               
			char *buffer=new char[len];
			fseek(id,0,SEEK_SET);
			fread(buffer,1,len,id);
			fclose(id);
			maxx=255;
			for(long i=0;i<len;i++)
				{
				if((!i)||(buffer[i]=='\n'))
					{
					if(i) file[l_act][pos]='\0',l_act++,pos=0;  
					file=(pchar*)realloc(file,sizeof(pchar)*(l_act+2));
					file[l_act]=new char[255];
					if((!i)&&(buffer[i]!='\n'))  file[l_act][pos++]=buffer[i];
					}
				else file[l_act][pos++]=buffer[i];
				}
			file[l_act][pos]='\0';
			maxy=l_act;      
			delete[] buffer;
			}
		else
			{
			endwin();
			printf("\nError opening file %s\n",plik);
			exit(1);   
			}    
		}
	~TFileView()
		{
		for(long i=0;i<=maxy;i++)
		delete[] file[i];
		delete[] file;  
		}       
	void Keyboard()
		{
		logfile("TFileView::Keyboard"); 
		int key; 
		do
			{ 
			ShowWindow(); 
			key=user_getch();
			switch(key)
				{
				case KEY_UP:
				MoveUp();
				break;
				case KEY_DOWN:
				MoveDown();   
				break;
				case KEY_LEFT:
				MoveLeft();
				break;
				case KEY_RIGHT:
				MoveRight();
				break;
				case KEY_PPAGE:
				PgUp();
				break;
				case KEY_NPAGE:
				PgDn();
				break;        
				}
			}
		while(key!=KEY_ESC);
		}       
	};
#endif
