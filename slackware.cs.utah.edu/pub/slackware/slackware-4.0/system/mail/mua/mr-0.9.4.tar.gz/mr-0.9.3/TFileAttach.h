/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TFILEATTACH_H
#define _TFILEATTACH_H
#include"TWindow.h"
#include"TInputField.h"
#include"TBASE64.h"

class TFileAttach {
	pchar *attach;
	long maxy;
	char *content_type;
	char *content_transfer;
	long headerpos;
	public:
	void RunMetamail();
	void Keyboard();
	void SaveFile();
	TFileAttach(pchar *aattach,long amaxy, long whereisheader, 
	char *acontent_type, char *acontent_transfer) : 
	attach(aattach),
	maxy(amaxy),
	content_type(acontent_type),
	content_transfer(acontent_transfer),
	headerpos(whereisheader)
	
		{
		TWindow wybor(10,5,70,12,"File attach");
		wybor.ShowWindow();
		mvaddstr(7,25,"This is a file attach, press");
		mvaddstr(8,25,"'w' to  save , or escape  to");
		mvaddstr(9,25,"go back. 'm' runs metamail.");
		Keyboard();  
		}
	};


#endif
