/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TFolderList.h"

int TFolderList::Action()
	{
	int default_v=0;
	TFolderListEngine folderlist(items,count+1,x,y,x1,y1,default_v,folderlisttextcolor,folderlistselectedcolor,folderlistbarcolor);
	folderlist.Keyboard();
	if(folderlist.CheckIns())
		{
		pchar *fake=new pchar[2];
		pchar *fake2=new pchar[2];
		fake[0]=new char[255];
		fake[1]=new char[255];
		fake2[0]=new char[255];
		fake2[1]=new char[255];
		strcpy(fake[0],"\0");
		strcpy(fake[1],"\0");
			{TViewTextMsg msg(fake,x,y+6,x1,y1,
			"\0","\0","\0","\0",
			"\0","\0",
			1,0,0,0,
			"\0","\0","\0","\0",
			"\0","\0",fake2);
			msg.InsertMessage(NEW);}
		delete[] fake[0];
		delete[] fake[1];
		delete[] fake2[0];
		delete[] fake2[1];
		delete[] fake; 
		delete[] fake2;
		}
	if(!folderlist.CheckEscape())
		{default_v=folderlist.GetElement();
		TFolderView folderview(files[folderlist.GetElement()],x,y,x1,y1,dto[folderlist.GetElement()],dcc[folderlist.GetElement()],dbcc[folderlist.GetElement()],replyto[folderlist.GetElement()]);}
	else return 0;
	return 1;    
	}

void TFolderList::InitItems()
	{
	logfile("TFolderList::InitItems"); 
	FILE *id;
	int action=-1,config;
	char *str=new char[255];
	sprintf(str,"%s/mr.rc",ETCDIR);
	items=new pchar[1];
	files=new pchar[1];
	dto=new pchar[1];
	dcc=new pchar[1];
	dbcc=new pchar[1];
	replyto=new pchar[1];
	for(config=0;config<2;config++)
		{
		if(((id=fopen(str,"rb" ))==MYNULL)&&(config==1))
			{
			endwin();
			system("clear");
			system(" echo 'Error opening file ~/.mr/mr.rc'");
			system(" echo 'Do you want to create a default one?'");
			system(" echo 'Say \"yes\", or \"no\", and press enter'");
			char *s=new char[255];
			scanf("%s",s);
			tolower(s);
			if(s[0]=='y');
				{
				sprintf(s,"mkdir %s/.mr",getenv("HOME"));
				system(s);
				id=fopen(str,"wt");
				fprintf(id,"# MR's folder configuration file\n\n");
				fprintf(id,"folder \"My incoming mail\"\n");
				fprintf(id,"  path \"%s\"\n",getenv("MAIL"));  
				fclose(id);
				printf("\nFile created... Now Start the program"
				"\nagain. And consult the doc's"
				"\nto get know about some features of this"
				"\nbeautiful software :-)\n");
				}
			delete[] str;
			delete[] s;
			exit(1);   
			}
		else if((config==0)&&(id==MYNULL));
		else
			{
			int active=0;
			while(!feof(id))
				{
				ReadItem(id,str);
				if(strlen(str))
				if(!active)
					{
					if(CompareStr(str,"charset",strlen("charset"),1))
						{action=CHARSET; active=1;}
					else if(CompareStr(str,"forwardbanner",strlen("forwardbanner"),1))
					action=FORWARDBANNER,active=1;    
					else if(CompareStr(str,"alternateeditor",strlen("alternateeditor"),1))
					action=ALTERNATEEDITOR,active=1;    
					else if(CompareStr(str,"fileimportbanner",strlen("fileimportbanner"),1))
					action=FILEIMPORTBANNER,active=1;    
					else if(CompareStr(str,"graph_warez",strlen("graph_warez"),1))
					action=GRAPHWAREZ,active=1;    
					else if(CompareStr(str,"folder",strlen("folder"),1))
						{
						action=FOLDER; active=1; 
						count++; 
						items=(pchar*)realloc(items,sizeof(pchar)*(count+2)); 
						items[count]=new char[255];
						sprintf(items[count],"[noname]");
						files=(pchar*)realloc(files,sizeof(pchar)*(count+2)); 
						files[count]=new char[255];
						sprintf(files[count],"\0");
						dto=(pchar*)realloc(dto,sizeof(pchar)*(count+2)); 
						dto[count]=new char[255];
						sprintf(dto[count],"\0");
						dcc=(pchar*)realloc(dcc,sizeof(pchar)*(count+2)); 
						dcc[count]=new char[255];
						sprintf(dcc[count],"\0");
						dbcc=(pchar*)realloc(dbcc,sizeof(pchar)*(count+2)); 
						dbcc[count]=new char[255];
						sprintf(dbcc[count],"\0");
						replyto=(pchar*)realloc(replyto,sizeof(pchar)*(count+2)); 
						replyto[count]=new char[255];
						sprintf(replyto[count],"\0");
						} 
					else if(CompareStr(str,"path",strlen("path"),1))
					action=PATH,active=1;
					else if(CompareStr(str,"defaultto",strlen("defaultto"),1))
					action=DTO,active=1;
					else if(CompareStr(str,"defaultcc",strlen("defaultcc"),1))
					action=DCC,active=1;
					else if(CompareStr(str,"defaultbcc",strlen("defaultbcc"),1))
					action=DBCC,active=1;
					else if(CompareStr(str,"replyto",strlen("replyto"),1))
					action=REPLYTO,active=1;    
					else if(CompareStr(str,"sorting",strlen("sorting"),1))
					action=SORTING,active=1;    
					else if(action==-1)
						{
						endwin();
						printf("\nerror parsing file mr.rc\n");
						fclose(id);
						exit(1);
						}
					}
				else {
					active=0;
					if(action==-1)
						{
						endwin();
						printf("\nerror parsing file mr.rc\n");
						fclose(id);
						exit(1);
						}
					else if(action==CHARSET)
					sprintf(rc_charset,"%s",str);
					else if(action==FOLDER)
					sprintf(items[count],"%s",str);
					else if(action==PATH)
					sprintf(files[count],"%s",str);
					else if(action==DTO)
					sprintf(dto[count],"%s",str);
					else if(action==DCC)
					sprintf(dcc[count],"%s",str);
					else if(action==DBCC)
					sprintf(dbcc[count],"%s",str);         
					else if(action==REPLYTO)
					sprintf(replyto[count],"%s",str);  
					else if(action==SORTING)
					sprintf(rc_sorting,"%s",str);  
					else if(action==FORWARDBANNER)
					sprintf(rc_forwardbanner,"%s",str);  
					else if(action==FILEIMPORTBANNER)
					sprintf(rc_fileimportboundary,"%s",str);  
					else if(action==ALTERNATEEDITOR)
					sprintf(rc_alternateeditor,"%s",str);  
					else if(action==GRAPHWAREZ)
					sprintf(rc_graph_warez,"%s",str);  
					}    
				}
			}
		sprintf(str,"%s/.mr/mr.rc",getenv("HOME"));
		}
	fclose(id);           
	delete[] str;
	}

