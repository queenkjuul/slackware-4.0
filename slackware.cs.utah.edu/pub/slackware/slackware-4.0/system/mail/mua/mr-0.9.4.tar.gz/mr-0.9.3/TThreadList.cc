#include "mr.h"
#include "TThreadList.h"

void TThreadList::UpdateList()
	{
	TThreads *to=tree->next;
	long i=0;
	for(;to->val;to=to->next)
		{
		to->val[1]=subject[references[i]][7];
		to->val[2]=subject[references[i]][8];
		i++;
		}
	
	}

long TThreadList::CheckForRoot(long n, char *marks)
	{
	for(long i=0;i<max_msg;i++)
		{
		if(marks[i]==0)
		if(strcmp(in_reply_to[n],msg_id[i])==0)
		return i;
		}
	return n;
	}

void TThreadList::InitializeList()
	{
	active=1;
	char *str=new char[1024];
	tree=new TThreads("fake");
	char *marks=new char[max_msg+1];
	for(long i=0;i<max_msg;i++) marks[i]=0;
	int depth=0;
	long tmp;
	for(long i=0;i<max_msg;i++)
		{
		if(marks[i]==0)
			{
			long n=i;
			n=i;
			char *tmpmarks=new char[max_msg+1];
			strncpy(tmpmarks,marks,max_msg+1);
			do
				{
				tmp=n;
				tmpmarks[tmp]=1;
				n=CheckForRoot(tmp,tmpmarks);
				}
			while(n!=tmp);
			delete[] tmpmarks;
			marks[n]=1;
			str[0]=0;
			strncat(str,subject[n]+5,5);
			strncat(str,subject[n]+10,26);
			strcat(str,subject[n]+(x1-x));
			strcat(str,"                                       ");
			strcpy(str+36,subject[n]+36);
			tree->AddNext(new TThreads(str));
			references[thread_number]=n;
			if(default_value==n) default_thread=thread_number;
			thread_number++;
			CheckForReply(n,depth+1,marks);
			}
		}
	delete[] str;
	}
void TThreadList::CheckForReply(long i, int depth, char *marks)
	{
	char modified=0;
	char *str=new char[1024];
	for(long j=0;j<max_msg;j++)
		{
		if(marks[j]==0)
			{
			if(strcmp(msg_id[i],in_reply_to[j])==0)
				{
				marks[j]=1;
				if(default_value==j) default_thread=thread_number;
				str[0]=0;
				strncat(str,subject[j]+5,5);
				
				for(int i=0;i<depth;i++)
				strcat(str,"  ");
				int len=strlen(str);
				strcat(str,"`->");
				strncat(str,subject[j]+10,26);
				strcat(str,subject[j]+(x1-x));
				strcat(str,"                                       ");
				strcpy(str+36,subject[j]+36);
				TThreads *tmp=tree->next;
				if(tmp)
				while(tmp->val[len]==' ')
					{
					tmp->val[len]='|';
					tmp=tmp->next;
					if(tmp==MYNULL) break;
					}
				if(tmp) { if(tmp->val[len]=='`') 
					tmp->val[len]= '|';  }
				tree->AddNext(new TThreads(str));
				references[thread_number]=j;
				thread_number++;
				CheckForReply(j,depth+1,marks);
				}
			}
		}
	
	delete[] str;
	}
void TThreads::AddNext(TThreads *new_el)
	{
	TThreads *tmp=next;
	next=new_el;
	next->next=tmp;
	}
void TThreadList::RunList()
	{ 
	TList *itemlist;
	if(!active) 
	InitializeList();
	pchar *list=new pchar[max_msg];
	TThreads *tree_object;
	tree_object=tree->next;
	for(int i=0;tree_object;i++)
		{
		list[max_msg-i-1]=new char[strlen(tree_object->val)+32];
		sprintf(list[max_msg-i-1],"%s",tree_object->val);
		list[max_msg-i-1][0]=subject[references[max_msg-i-1]][5];
		list[max_msg-i-1][2]=subject[references[max_msg-i-1]][7];
		list[max_msg-i-1][3]=subject[references[max_msg-i-1]][8];
		tree_object=tree_object->next;
		}
	itemlist=new TList(list,max_msg,x,y,x1,y1,default_thread,threadlistnormal,threadlistselected,threadlistbar);
	DoThreadAgain:
	itemlist->Keyboard();
	if(itemlist->CheckSpace())
		{
		if(subject[references[itemlist->GetElement()]][5]=='*')
			{
			subject[references[itemlist->GetElement()]][5]=' ';
			list[itemlist->GetElement()][0]=' ';
			}
		else
			{
			subject[references[itemlist->GetElement()]][5]='*';
			list[itemlist->GetElement()][0]='*';
			}
		itemlist->ResetSpace();
		goto DoThreadAgain;
		}
	else if(!itemlist->CheckEscape())
	return_value=references[itemlist->GetElement()]+1;
	for(int i=0;i<max_msg-1;i++) 
	delete[] list[i];
	delete itemlist;
	delete[] list;
	}
