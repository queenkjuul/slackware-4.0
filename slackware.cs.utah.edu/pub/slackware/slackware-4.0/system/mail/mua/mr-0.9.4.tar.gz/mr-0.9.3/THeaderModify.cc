/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "THeaderModify.h"

#define HDR (*hdr)

void THeaderModify::EncodeHdr(char **hdr)
	{
	int i,oldpos=0;
	char *word=new char[255];
	pchar *pword=&word;
	char *tail=new char[255];
	for(i=0;i<strlen(HDR);i++)
		{
		if((HDR[i]==' ')||(HDR[i]==',')||
		(HDR[i]=='<')||(HDR[i]=='>')||
		(HDR[i]=='(')||(HDR[i]==')')||
		(HDR[i]=='"')||(HDR[i]==';')||
		(HDR[i]==':')||(HDR[i]=='/')||
		(HDR[i]=='[')||(HDR[i]==']'))
			{
			int address=0;
			*pword=(char*)realloc(*pword,i-oldpos+20);
			tail=(char*)realloc(tail,strlen(HDR)-i+20);
			strncpy(*pword,HDR+oldpos,i-oldpos);
			strcpy(tail,HDR+i);
			(*pword)[i-oldpos]='\0';
			for(int k=0;k<strlen(*pword);k++)
			if((*pword)[k]=='@') address=1;   
			if(!address)
				{
				if(i-oldpos>1)
					{
					THeaderMIME encoder(pword);
					encoder.Encode();      
					HDR=(char*)realloc(HDR,oldpos+strlen(*pword)+strlen(tail)+20);
					sprintf(HDR+oldpos,"%s%s",*pword,tail);
					}
				}
			oldpos=i;
			}
		}
	delete[] *pword;
	delete[] tail; 
	}

#undef HDR

void THeaderModify::Keyboard()
	{
	logfile("THeaderModify::Keyboard");
	int key,maxx,maxy;
	ungetch(KEY_UP);
	while( (((key=user_getch())!='\n') || (pos!=3) ) && (key!=KEY_ESC) )  
		{
		switch(key)
			{
			case KEY_F(3):
			if((pos==0)||(pos==1)||(pos==2))
				{
				TAddressBook book(x,y,x1,y1+10);
				book.Keyboard();
				if(book.ReturnEmail()!=MYNULL)
					{
					char *wsk;
					if(pos==0) wsk=to;
					if(pos==1) wsk=cc;
					if(pos==2) wsk=bcc;
					if(book.ReturnName()!=MYNULL)
						{
						sprintf(wsk,"\"%s\" ",book.ReturnName());
						}
					strcat(wsk,"<");
					strcat(wsk,book.ReturnEmail());
					strcat(wsk,">");
					}
				}
			break;
			case KEY_UP:
			if(pos) pos--;
			break;
			case KEY_RIGHT:
			pos=4;
			break;
			case KEY_LEFT:
			pos=0;
			break;      
			case KEY_DOWN:
			if((pos<3)||(pos==4)) pos++;
			break;
			case '\n':
			if(pos!=4) ungetch(KEY_DOWN);
			else       ungetch('a'); //aby wyszedl default...  
			break;   
			case '\t':
			if(pos<5)
			pos++;
			else 
			pos=0;
			break;     
			default:
			ungetch(key);
			if(pos==0)
				{TInputField i_to(x+5,y+1,x+(x1-x)/2-5,to);
				i_to.GetString();
				sprintf(to,"%s",i_to.ReturnString());}
			else if(pos==1)
				{TInputField i_cc(x+5,y+2,x+(x1-x)/2-5,cc);
				i_cc.GetString();
				sprintf(cc,"%s",i_cc.ReturnString());}
			else if(pos==2)
				{TInputField i_bcc(x+5,y+3,x1-x-6,bcc);
				i_bcc.GetString();
				sprintf(bcc,"%s",i_bcc.ReturnString());}
			else if(pos==3)
				{TInputField i_subj(x+10,y+4,x1-x-11,subj);
				i_subj.GetString();
				sprintf(subj,"%s",i_subj.ReturnString());}
			else if(pos==4)
				{getmaxyx(stdscr,maxy,maxx);
				TFileBox filebox(x+5,y+6,x1-5,maxy-6);
				filebox.Activate();}
			else if(pos==5)
				{TInputField i_fcc(x+1+(x1-x)/2+5,y+2,(x1-x)/2,fcc);
				i_fcc.GetString();
				sprintf(fcc,"%s",i_fcc.ReturnString());}
			}  
		ShowWindow();
		}
	if(key==KEY_ESC) { aborted=1; unsetenv("PBMR_ATTACH"); }
	else {WriteHdr(); sprintf(tplto,"%s",to);
		GetEMailFromAddress(tplto);
		sprintf(tpltoemail,"%s",to);
		GetNameFromAddress(tpltoemail);
		sprintf(tplsubj,"%s",subj);}
	}                    
void THeaderModify::ShowWindow()
	{
	logfile("THeaderModify::ShowWindow");   
	attrset(hdmodifytextcolor);   
	TWindow::ShowWindow();   
	int xt;   
	char *str=new char[1024];
	sprintf(str,"To: [%s",to);
	user_mvaddstr(y+1,x+1,x+(x1-x)/2-2,str);
	if(pos==0) xt=strlen(str);
	sprintf(str,"Cc: [%s",cc);
	user_mvaddstr(y+2,x+1,x1-x-2,str);
	if(pos==1) xt=strlen(str);
	sprintf(str,"Bcc: [%s",bcc);
	user_mvaddstr(y+3,x+1,x1-x-2,str);
	if(pos==2) xt=strlen(str);
	sprintf(str,"Subject: [%s",subj);
	user_mvaddstr(y+4,x+1,x1-x-2,str);
	if(pos==3) xt=strlen(str);
	if(getenv("PBMR_ATTACH")) strcpy(attach,getenv("PBMR_ATTACH"));
	sprintf(str,"Attach: [%s",attach);
	user_mvaddstr(y+1,x+1+(x1-x)/2,(x1-x)/2,str);
	if(pos==4) xt=strlen(str);
	sprintf(str,"Fcc: [%s",fcc);
	if(pos==5) xt=strlen(str);
	user_mvaddstr(y+2,x+1+(x1-x)/2,(x1-x)/2,str);
	if(pos<4) {if(xt<(x1-x)/2-2) move(y+pos+1,x+1+xt);
		else move(y+pos+1,(x1-x)/2-2);}
	else      {if(xt<x1-2)  move(y+pos-3,x+(x1-x)/2+1+xt);
		else move(y+pos-3,x1-2);}
	delete[] str;
	}                    

void THeaderModify::WriteHdr()
	{
	logfile("THeaderModify::WriteHdr");   
	char *homedir=getenv("HOME");
	char *str=new char[255];
	FILE *id;
	int noattach=1;
	srand(time(MYNULL));
	if(getenv("PBMR_ATTACH")!=MYNULL) noattach=0;
	if(getenv("PBMR_OLDFOLDERNAME"))
		{setenv("PBMR_FOLDERNAME",getenv("PBMR_OLDFOLDERNAME"),1);
		unsetenv("PBMR_OLDFOLDERNAME");}
	if(fcc[0]) 
		{setenv("PBMR_OLDFOLDERNAME",getenv("PBMR_FOLDERNAME"),1);
		setenv("PBMR_FOLDERNAME",fcc,1);}
	if(!noattach)
		{
		sprintf(str,"MR.%ld%ld%ld.%s@%s",
		rand(),
		rand(),
		rand(),
		getenv("LOGNAME"),
		getenv("HOSTNAME"));
		sprintf(content_type,"Multipart/mixed; boundary=\"%s\"",str);
		setenv("PBMR_BOUNDARY",str,1);
		}
	sprintf(str,"%s/.mr/mailhdr.%ld.tmp",homedir,(long)getpid());
	if((id=fopen(str,"wt"))!=MYNULL)
		{
		EncodeHdr(&to);
		fprintf(id,"To: %s\n",to);
		fprintf(id,"Message-ID: <MR.%lX%lX%lX.%s@%s>\n",
		rand(),
		rand(),
		rand(),
		getenv("LOGNAME"),
		getenv("HOSTNAME"));
		if(replyto[0])
			{EncodeHdr(&to);
			fprintf(id,"Reply-To: %s\n",replyto);}
		if(cc[0])
			{EncodeHdr(&cc);
			fprintf(id,"Cc: %s\n",cc);}
		if(bcc[0])
			{EncodeHdr(&bcc);
			fprintf(id,"Bcc: %s\n",bcc);}
			{THeaderMIME SubjEncoder(&subj);
			SubjEncoder.Encode();}
		fprintf(id,"Subject: %s\n",subj);
		fprintf(id,"MIME-Version: 1.0\n");
		fprintf(id,"Content-Type: %s\n",content_type);
		if(!getenv("PBMR_ATTACH"))
		fprintf(id,"Content-Transfer-Encoding: %s\n",content_transfer_encoding);
		if(msgid[0])
			{
			fprintf(id,"In-Reply-To: %s\n",msgid);
			}
		fprintf(id,"X-Mailer: %s by Przemek Borys\n",MRVERSION);
		fprintf(id,"\n");
		fclose(id);  
		}
	else   {
		printf("Cannot create file ~/.mr/mailhdr.%ld.tmp",(long)getpid());
		exit(1);
		}       
	delete[] str;   
	}   


