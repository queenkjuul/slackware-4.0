/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TList.h"

void TList::ShowWindow()
	{
	logfile("TList::ShowWindow");  
	int pos1;  
	attrset(textcolor);
	TWindow::ShowWindow();
	if(count>0)
		{	
		for(int i=0;i<=MaxHeight();i++)
		if(i+pos<count) 
		user_mvaddstr(winy1+i+1,winx1+1,MaxWidth(),items[pos+i]);
		attrset(selectedcolor);
		if(pos+p<count)
		user_mvaddstr(winy1+p+1,winx1+1,MaxWidth()+1,items[pos+p]);      
		}
	attrset(barcolor);
	for(int i=winy1+1;i<winy2;i++)
	mvaddch(i,winx2,' ');  
	if((pos+p)&&(count>0)) pos1=(MaxHeight()*(pos+p))/(count);
	else pos1=0;
	mvaddch(winy1+1+pos1,winx2,'O');
	}             
void TList::KeyboardInternal(int a)
	{
	logfile("TList::KeyboardInternal");
	switch(a)
		{
		case KEY_HOME:
		pos=p=0;
		break;
		case KEY_END:
		pos=long((count-1)/MaxHeight())*MaxHeight(); 
		p=count-1-pos;
		break;
		case KEY_PPAGE:
		if(pos>MaxHeight()) pos-=MaxHeight();
		else pos=0;
		break;  
		case KEY_NPAGE:
		if(pos+p<count-MaxHeight()) pos+=MaxHeight();
		else pos=count-p-1;
		break;  
		case KEY_UP:
		if(count)
		if(p>0) p--;
		else if(pos>0) pos--;
		break;
		case KEY_DOWN:
		if(count)
		if((p<MaxHeight())&&(p+pos+1<count))
		p++;
		else if((p==MaxHeight())&&(p+pos+1<count))
		pos++;
		break;  
		case KEY_F(10):
		MenuPlay();
		break;  
		case KEY_F(1):
		sprintf(helpfile,"%s",hlpfile);
		Help();
		break;  
		}  
	}              
void TList::Keyboard()
	{
	logfile("TList::Keyboard");   
	int a;  
	escape=0;
	do
		{  
		ShowWindow();   
		a=user_getch();
		KeyboardInternal(a);
		}
	while((a!=KEY_ESC)&&(a!='\n')&&(a!=' '));  
	if(a==KEY_ESC) escape=1;
	if(a==' ') space=1;
	} 

