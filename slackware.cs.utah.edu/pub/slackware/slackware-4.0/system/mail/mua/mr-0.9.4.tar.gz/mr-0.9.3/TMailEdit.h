/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TMAILEDIT_H
#define _TMAILEDIT_H
#include"TEdit.h"
#include"keyboard.h"
#include"colors.h"
#include"misc.h"
#include"TQuotedPrintable.h"
#include"mr.rc.variables.h"

class TMailEdit : public TEdit {
	char *filename;              //nazwa pliq
	int textcolor,quotedcolor,barcolor;
	public:
	void AddChar(char ch);
	void ImportFile(char *filename);
	void Delete();
	void BackSpace();
	void user_mvaddstr(int x,int y,int maxlen,char *str);
	int SplitLine(int line);
	TMailEdit(char *file_name,int x,int y,int x1,int y1) : TEdit(file_name,x,y,x1,y1,mailedittextcolor,maileditbarcolor)
		{       
		logfile("TMailEdit::TMailEdit");   
		int key;
		do
			{
			Keyboard();
				{
				TWindow okno(x+5,y+5,x+40,y+8,"\0");
				okno.ShowWindow();
				if(!CheckEscape())
					{mvaddstr(y+6,x+7,"Are you sure you want to post?");
					mvaddstr(y+7,x+7,"            (y/n)             ");}
				else
					{mvaddstr(y+6,x+7,"Are you sure you want to abort?");
					mvaddstr(y+7,x+7,"            (y/n)             ");}
				refresh();
				key=getch();
				}
			}
		while((key!='y')&&(key!='Y'));
			{TQuotedPrintable qp(&file,&maxy,0); qp.Encode(); l_act=maxy;}
		}
	};
#endif               
