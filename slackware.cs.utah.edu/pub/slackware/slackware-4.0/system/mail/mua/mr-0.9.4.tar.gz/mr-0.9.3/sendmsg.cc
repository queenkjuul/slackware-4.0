/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "sendmsg.h"

void SendMsg()
	{
	logfile("sendmsg.h::SendMsg"); 
	TWindow okno(1+5,1+5,1+40,1+7,"\0");
	okno.ShowWindow();
	mvaddstr(1+6,1+7,"Wait: Sending message...");
	refresh();
	char *str=new char[1024];
	if(getenv("PBMR_ATTACH")==MYNULL)
		{sprintf(str,"cat %s/.mr/mailfile.%ld.tmp >> %s/.mr/mailhdr.%ld.tmp",getenv("HOME"),(long)getpid(),getenv("HOME"),(long)getpid());
		system(str);}
	else
		{TSendMultipart multipart;
		multipart.SendMultipart();}   
	time_t t=time(MYNULL);
	char *t2=ctime(&t);
	
	if(getenv("PBMR_FOLDERNAME"))
		{
		FILE *id=fopen(getenv("PBMR_FOLDERNAME"),"a");
		fprintf(id,"\nFrom MR %s"
		"From: %s <%s@%s>\n"
		"Date: %s",
		t2,
		getenv("PBMR_FULLUSERNAME"),
		getenv("LOGNAME"),
		getenv("HOSTNAME"),t2); 
		fclose(id);             
		
		sprintf(str,"cat %s/.mr/mailhdr.%ld.tmp >> %s",getenv("HOME"),(long)getpid(),getenv("PBMR_FOLDERNAME"));
		system(str);
		if(getenv("PBMR_FOLDERNAME"))
			{
			sprintf(str,"echo '' >> %s",getenv("PBMR_FOLDERNAME"));
			system(str);
			}
		}
	
	sprintf(str,"/usr/sbin/sendmail -t -bm < %s/.mr/mailhdr.%ld.tmp",getenv("HOME"),(long)getpid());
	system(str);
	sprintf(str,"rm -f %s/.mr/*.%ld.tmp",getenv("HOME"),(long)getpid());
	system(str);
	delete[] str;
	if(ProgramPosition!=FOLDERLIST)
	setenv("PBMR_MESSAGE_MAILED",t2,1);
	if(getenv("PBMR_OLDFOLDERNAME"))
		{
		setenv("PBMR_FOLDERNAME",getenv("PBMR_OLDFOLDERNAME"),1);
		unsetenv("PBMR_OLDFOLDERNAME");
		}
	}


