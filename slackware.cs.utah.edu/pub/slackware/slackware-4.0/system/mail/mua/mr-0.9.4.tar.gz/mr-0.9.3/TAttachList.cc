/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TAttachList.h"

void TAttachList::InitData()
	{
	char *str=new char[4096];
	char *p=new char[255];
	sprintf(str,getenv("PBMR_ATTACH"));
	long len=strlen(str);
	long last=0;
	while(last<len)
		{
		strcpy(p,"\0");  
		for(int i=last;((i<len)&&(str[i]!=' '));i++,last++)
		strncat(p,&str[i],1);
		AddItem(p);    
		while(str[last]==' ') last++;
		}
	delete[] str;         
	delete[] p;         
	}
void TAttachList::ShowWindow()
	{
	logfile("TList::ShowWindow");  
	int pos1;  
	attrset(A_REVERSE);
	TWindow::ShowWindow();
	for(int i=0;i<=MaxHeight();i++)
	if(i<itemcount) 
	user_mvaddstr(winy1+i+1,winx1+1,MaxWidth(),list[i]);
	}
void TAttachList::SetEnvForAttach()
	{
	char *str=new char[4096];
	unsetenv("PBMR_ATTACH");
	strcpy(str,"\0"); 
	if(itemcount)
		{
		for(int i=0;i<itemcount;i++)
			{
			strcat(str,list[i]);
			if(i<itemcount-1)
			strcat(str," "); 
			} 
		setenv("PBMR_ATTACH",str,1);     
		}
	delete[] str;
	}
void TAttachList::Keyboard()
	{
	do
		{ 
			{TDelAddList object(list,itemcount,winx1,winy1,winx2,winy2,current,filelisttxtcolor,filelistselectedcolor,filelistbarcolor);
			object.Keyboard();
			current=object.GetElement();
			escape=object.CheckEscape();
			if(object.CheckDelete()) DelItem(current);
			tab=object.CheckTab();}
		}
	while(!tab);
	}

void TAttachList::AddItem(char *item)
	{
	itemcount++; 
	list=(pchar*)realloc(list,sizeof(pchar)*(itemcount+2)); 
	list[itemcount-1]=new char[255];
	strcpy(list[itemcount-1],item);
	}
void TAttachList::DelItem(int item)
	{
	if(!itemcount) return; 
	delete[] list[item];
	for(int i=item+1;i<itemcount;i++)
	list[i-1]=list[i];             
	itemcount--;
	if((current>=itemcount)&&(itemcount)) current--;
	}    

