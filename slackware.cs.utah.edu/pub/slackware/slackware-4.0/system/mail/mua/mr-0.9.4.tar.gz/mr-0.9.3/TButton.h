/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/

/*   This header file defines a class, which represents a button. You can 
     see it for example in the File Attach window of my mailreader */

#ifndef _TBUTTON_H
#define _TBUTTON_H

#include "TWindow.h"

class TButton : public TWindow {
	
	char *buttonname;   //name of the button (the name, you see)
	
	int selected;       //determines, if the button is highlighted
	
	int tab,escape;     //checks, if the keyboard procedure was 
	//finished by pressing tab or escape
	
	public:
	
	int CheckTab() {return tab;} //checks, if the last pressed key was 
	//tab
	
	int CheckEscape() {return escape;} //checks, if the last pressed
	//key was escape
	
	void ShowWindow();  //Paints the button on the screen
	
	void Keyboard();    //Keyboard interface of the object
	
	TButton(int x,int y,char *str) : TWindow(x,y,x+strlen(str)+2,y,"\0"),
	buttonname(new char[255]),selected(0),
	tab(0),escape(0)
		{
		sprintf(buttonname,"[%s]",str); 
		}
	~TButton() { delete[] buttonname; }               
	};                           

#endif
