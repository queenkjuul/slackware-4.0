/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TView.h"

void TView::ShowWindow()           //wyswietlenie zawartosci aktualnego 
//miejsca edycji
	{
	logfile("TView::ShowWindow");   
	int i,mx,my;    
	attrset(textcolor);
	TWindow::ShowWindow();
	if(yt)
		{
		mvaddch(winy1,winx1,ACS_LTEE);
		mvaddch(winy1,winx2,ACS_RTEE);
		for(i=winx1+1;i<winx2;i++)
		mvaddch(winy1,i,ACS_HLINE);
		}
	if(MaxHeight()+filepos<=maxy)
		{
		for(i=0;i<=MaxHeight();i++) 
		if(cur_col<strlen(file[i+minimum_line+filepos]))  
		user_mvaddstr(winy1+i+1,winx1+1,
		MaxWidth()+1,file[i+minimum_line+filepos]+cur_col);
		}
	else    
		{
		for(i=filepos;i<=maxy;i++)   
			{
			if(cur_col<strlen(file[i+minimum_line]))  
			user_mvaddstr(winy1+i-filepos+1,winx1+1,
			MaxWidth()+1,file[i+minimum_line]+cur_col);
			}
		}            
	//         if(maxx>0)  //rysowanie scrollbarow
	//           mx=((cursorx+cur_col)*MaxWidth())/maxx; else mx=0;
	if(maxy>0)
	my=((filepos+cursory)*MaxHeight())/maxy; else my=0;
	attrset(barcolor);  
	for(i=winy1+1;i<winy2;i++)
	if(i-winy1-1==my) mvaddch(i,winx2,'O'); else mvaddch(i,winx2,' ');
	//         for(i=winx1+1;i<winx2;i++)                                      
	//           if(i-winx1-1==mx) mvaddch(winy2,i,'O'); else mvaddch(winy2,i,' ');
	move(winy1+1+cursory,winx1+1+cursorx); //ustawienie kursora
	}            


