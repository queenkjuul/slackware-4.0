#ifndef _TTHREADLIST_H
#define _TTHREADLIST_H
#include "TList.h"

class TThreads {
	public:
	TThreads *next;
	char *val;
	void AddNext(TThreads *next);
	TThreads(char *value) : val(new char[strlen(value)+10]), 
	next(MYNULL)
		{ 
		strcpy(val,value); 
		}
	~TThreads()
		{ 
		delete[] val; 
		}
	};

class TThreadList {
	int active;
	long *references; // the fields which contain the real msg numbers
	// and not the ones, sorted in a thread tree
	TThreads *tree;   // the thread tree
	long max_msg,cur_msg;
	long thread_number;
	long return_value;
	long default_value;
	long default_thread;
	pchar *in_reply_to;
	pchar *msg_id;
	pchar *subject;
	int x,x1,y,y1;
	void CheckForReply(long i, int depth, char* marks);
	long CheckForRoot(long n,char *marks);
	public:
	void UpdateList();
	void InitializeList();
	void SetCurMsg(long curmsg) 
		{cur_msg=curmsg; 
		for(default_thread=0;
		(references[default_thread]!=curmsg) &&
		(default_thread<thread_number);default_thread++);}
	void RunList();
	long GetElement() {return return_value; }
	TThreadList(int x_1,int y_1,int x_2,int y_2,pchar *inreplyto,
	pchar *msgid, pchar *subj,int maxmsg,int curmsg,
	long defaultval) :
	x(x_1),y(y_1),x1(x_2),y1(y_2),
	in_reply_to(inreplyto),msg_id(msgid),max_msg(maxmsg),
	cur_msg(curmsg),tree(MYNULL),thread_number(0),
	subject(subj),active(0),references(new long[maxmsg]),
	return_value(0),default_value(defaultval),
	default_thread(0)
		{
		return_value=curmsg;
		}
	~TThreadList()
		{
		delete[] references;
		TThreads *tmp;
		TThreads *tmp2;
		tmp=tree;
		for(;tmp;)
			{
			tmp2=tmp->next;
			delete tmp;
			tmp=tmp2;  
			}
		}	         
	};

#endif
