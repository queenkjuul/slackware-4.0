/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TFileBox.h"

void TFileBox::Activate()
	{
	int object=0;
	TWindow okno(x1,y1,x2,y2,"File attach window");
	attrset(fileattachbrowsercolor);
	okno.ShowWindow();
	TFileList filelist(curdir,x1+1,y1+1,x1+((x2-x1)>>1)-1,y2-4);
	TAttachList choosenlist(x1+((x2-x1)>>1)+1,y1+1,x2-1,y2-4);
	TButton ok(x1+2+3,y2-2,"  OK  ");
	TButton cancel(x2-4-3-strlen("Cancel"),y2-2,"Cancel");
	cancel.ShowWindow();
	ok.ShowWindow();
	choosenlist.ShowWindow();
	do
		{
		if(object==0)  
			{
			filelist.Keyboard();
			filelist.ShowWindow();
			if(filelist.CheckTab()) object++;
			else if(!filelist.CheckEscape()) 
				{
				choosenlist.AddItem(filelist.ReturnFileName());
				choosenlist.ShowWindow();
				filelist.RestoreDir();
				}
			else break;
			}
		if(object==1)
			{
			choosenlist.Keyboard();
			choosenlist.ShowWindow();
			if(choosenlist.CheckTab()) object++;
			else if(choosenlist.CheckEscape()) break;
			}      
		if(object==2)
			{
			ok.Keyboard();
			if(ok.CheckTab()) object++;
			else if(!ok.CheckEscape())
				{
				choosenlist.SetEnvForAttach();   
				break;
				}
			else break;        
			}       
		if(object==3)
			{
			cancel.Keyboard();
			if(cancel.CheckTab()) object=0;
			else break;     
			}       
		}
	while(1);  
	}

