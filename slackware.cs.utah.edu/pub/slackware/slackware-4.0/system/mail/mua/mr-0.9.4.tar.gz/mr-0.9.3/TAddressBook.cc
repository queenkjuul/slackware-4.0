#include "mr.h"
#include "TAddressBook.h"

char *TAddressBook::ReturnEmail()
	{
	if(selected)
	return emails[curitem];
	else
	return MYNULL;
	}
char *TAddressBook::ReturnName()
	{
	if(selected)
	return names[curitem];
	else
	return MYNULL;
	}
void TAddressBook::LoadBase()
	{
	FILE *id;
	char *filename;
	char *str=new char[255];
	sprintf(str,"%s/.mr/addressbook.dat",getenv("HOME"));
	if((id=fopen(str,"r"))!=MYNULL)
		{
		while(!feof(id))
			{
			emails=(pchar*)realloc(emails,(itemnum+2)*sizeof(pchar));
			emails[itemnum]=new char[255];
			ReadItem(id,emails[itemnum]);
			names=(pchar*)realloc(names,(itemnum+2)*sizeof(pchar));
			names[itemnum]=new char[255];
			ReadItem(id,names[itemnum]);
			idents=(pchar*)realloc(idents,(itemnum+2)*sizeof(pchar));
			idents[itemnum]=new char[255];
			ReadItem(id,idents[itemnum]);
			itemnum++;
			}
		itemnum--;
		delete[] emails[itemnum];
		delete[] names[itemnum];
		delete[] idents[itemnum];	      
		fclose(id);
		}
	delete[] str;
	}
void TAddressBook::SaveBase()
	{
	FILE *id;
	char *filename;
	char *str=new char[255];
	sprintf(str,"%s/.mr/addressbook.dat",getenv("HOME"));
	if((id=fopen(str,"w"))!=MYNULL)
		{
		for(long i=0;i<itemnum;i++)
			{
			fprintf(id,"\"%s\"\n",emails[i]);
			fprintf(id,"\"%s\"\n",names[i]);
			fprintf(id,"\"%s\"\n",idents[i]);
			}
		fclose(id);
		}
	delete[] str;
	}
void TAddressBook::Keyboard()
	{
	TDelAddList *itemlist = new TDelAddList(idents,itemnum,x1+1,y1+1,x2-1,y2-5,curitem,addressbookwindowcolor,addressbookselected,addressbookbar);
	TButton    add(x1+1, y2-2," Add new ");
	add.ShowWindow();
	TButton select(x1+13,y2-2," Select ");
	select.ShowWindow();
	TButton    del(x1+24,y2-2," Delete ");
	del.ShowWindow();
	TButton   edit(x1+35,y2-2," Edit ");
	edit.ShowWindow();
	TButton save(x1+44,y2-2," Save changes ");
	save.ShowWindow();
	TButton cancel(x1+61,y2-2," Cancel ");
	cancel.ShowWindow();
	int object=1;
	while(1)
		{
		if(object==1)
			{
			itemlist->Keyboard();
			curitem=itemlist->GetElement();
			if(itemlist->CheckTab()) object++;
			else if(itemlist->CheckEscape()) {selected=0;break;}
			}
		else if(object==2)
			{
			add.Keyboard();
			if(add.CheckTab()) object++;
			else if(add.CheckEscape()) break;
			else {AddItem();
				delete itemlist;
				itemlist=new TDelAddList(idents,itemnum,x1+1,y1+1,x2-1,y2-5,curitem,addressbookwindowcolor,addressbookselected,addressbookbar);
				itemlist->ShowWindow();}
			}	
		else if(object==3)
			{
			select.Keyboard();
			if(select.CheckTab()) object++;
			else if(select.CheckEscape()) break;
			else {selected=1; break;}
			}
		else if(object==4)
			{
			del.Keyboard();
			if(del.CheckTab()) object++;
			else if(del.CheckEscape()) break;
			else {DeleteItem(curitem);
				delete itemlist;
				itemlist=new TDelAddList(idents,itemnum,x1+1,y1+1,x2-1,y2-5,curitem,addressbookwindowcolor,addressbookselected,addressbookbar);
				itemlist->ShowWindow();}
			
			}
		else if(object==5)
			{
			edit.Keyboard();
			if(edit.CheckTab()) object++;
			else if(edit.CheckEscape()) break;
			else {EditItem(curitem);
				delete itemlist;
				itemlist=new TDelAddList(idents,itemnum,x1+1,y1+1,x2-1,y2-5,curitem,addressbookwindowcolor,addressbookselected,addressbookbar);
				itemlist->ShowWindow();}
			
			}
		else if(object==6)
			{
			save.Keyboard();
			if(save.CheckTab()) object++;
			else if(save.CheckEscape()) break;
			else {SaveBase(); break;}
			}
		else if(object==7)
			{
			cancel.Keyboard();
			if(cancel.CheckTab()) object=1;
			else if(cancel.CheckEscape()) break;
			else break;
			}		
		}	
	}
void TAddressBook::DeleteItem(long item)
	{
	for(long i=item;i<itemnum-1;i++)
		{
		emails[i]=emails[i+1];
		names[i]=names[i+1];
		idents[i]=idents[i+1];
		}
	itemnum--;
	}
void TAddressBook::AddItem()
	{
	TWindow okienko(x1+3,y1+3,x2-3,y2-3," Add item ");	
	okienko.ShowWindow();
	TInputField    address(x1+5+14,y1+5,(x2-4)-(x1+5+14));
	TInputField   fullname(x1+5+14,y1+6,(x2-4)-(x1+5+14));
	TInputField identifier(x1+5+14,y1+7,(x2-4)-(x1+5+14));
	mvaddstr(y1+5,x1+5,"E-Mail:");
	mvaddstr(y1+6,x1+5,"Full name:");
	mvaddstr(y1+7,x1+5,"Identifier:");
	TButton     ok(x1+5, y1+9,"  OK  ");
	ok.ShowWindow();
	TButton cancel(x1+14,y1+9,"Cancel");
	cancel.ShowWindow();
	int object=1;
	while(1)
		{
		user_mvaddstr(y1+5,x1+5+15,(x2-4)-(x1+5+14),address.ReturnString());
		user_mvaddstr(y1+6,x1+5+15,(x2-4)-(x1+5+14),fullname.ReturnString());
		user_mvaddstr(y1+7,x1+5+15,(x2-4)-(x1+5+14),identifier.ReturnString());
		if(object==1)
			{
			move(y1+5,x1+5+15);
			int key=user_getch();
			
			if((key!='\t')&&(key!=KEY_ESC)&&(key!='\n')&&
			(key!=KEY_DOWN)&&(key!=KEY_UP)&&(key!=KEY_LEFT)&&(key!=KEY_RIGHT))
				{
				ungetch(key);
				address.GetString();
				}
			else if(key=='\t') object++;
			else if(key=='\n') object++;
			else if(key==KEY_ESC) break;
			else if((key==KEY_DOWN)||(key==KEY_RIGHT)) object++;
			else object=5;
			}
		else if(object==2)
			{
			move(y1+6,x1+5+15);
			int key=user_getch();
			if((key!='\t')&&(key!=KEY_ESC)&&(key!='\n')&&
			(key!=KEY_DOWN)&&(key!=KEY_UP)&&(key!=KEY_LEFT)&&(key!=KEY_RIGHT))
				{
				ungetch(key);
				fullname.GetString();
				}
			else if(key=='\t') object++;
			else if(key=='\n') object++;
			else if(key==KEY_ESC) break;
			else if((key==KEY_DOWN)||(key==KEY_RIGHT)) object++;
			else object--;
			}
		else if(object==3)
			{
			move(y1+7,x1+5+15);
			int key=user_getch();
			if((key!='\t')&&(key!=KEY_ESC)&&(key!='\n')&&
			(key!=KEY_DOWN)&&(key!=KEY_UP)&&(key!=KEY_LEFT)&&(key!=KEY_RIGHT))
				{
				ungetch(key);
				identifier.GetString();
				}
			else if(key=='\t') object++;
			else if(key=='\n') object++;
			else if(key==KEY_ESC) break;
			else if((key==KEY_DOWN)||(key==KEY_RIGHT)) object++;
			else object--;
			}
		else if(object==4)
			{
			ok.Keyboard();
			if(ok.CheckTab()) object++;
			else if(ok.CheckEscape()) break;
			else 
				{
				emails=(pchar*)realloc(emails,(itemnum+2)*sizeof(pchar));
				emails[itemnum]=new char[255];
				strcpy(emails[itemnum],address.ReturnString());
				names=(pchar*)realloc(names,(itemnum+2)*sizeof(pchar));
				names[itemnum]=new char[255];
				strcpy(names[itemnum],fullname.ReturnString());
				idents=(pchar*)realloc(idents,(itemnum+2)*sizeof(pchar));
				idents[itemnum]=new char[255];
				strcpy(idents[itemnum],identifier.ReturnString());
				itemnum++;
				break;
				}
			}
		else if(object==5)
			{
			cancel.Keyboard();
			if(cancel.CheckTab()) object=1;
			else break;
			}				
		
		}
	}
void TAddressBook::EditItem(long item)
	{
	TWindow okienko(x1+3,y1+3,x2-3,y2-3," Add item ");	
	okienko.ShowWindow();
	TInputField    address(x1+5+14,y1+5,(x2-4)-(x1+5+14),emails[item]);
	TInputField   fullname(x1+5+14,y1+6,(x2-4)-(x1+5+14),names[item]);
	TInputField identifier(x1+5+14,y1+7,(x2-4)-(x1+5+14),idents[item]);
	mvaddstr(y1+5,x1+5,"E-Mail:");
	mvaddstr(y1+6,x1+5,"Full name:");
	mvaddstr(y1+7,x1+5,"Identifier:");
	TButton     ok(x1+5, y1+9,"  OK  ");
	ok.ShowWindow();
	TButton cancel(x1+14,y1+9,"Cancel");
	cancel.ShowWindow();
	int object=1;
	while(1)
		{
		user_mvaddstr(y1+5,x1+5+15,(x2-4)-(x1+5+14),address.ReturnString());
		user_mvaddstr(y1+6,x1+5+15,(x2-4)-(x1+5+14),fullname.ReturnString());
		user_mvaddstr(y1+7,x1+5+15,(x2-4)-(x1+5+14),identifier.ReturnString());
		if(object==1)
			{
			move(y1+5,x1+5+15);
			int key=user_getch();
			
			if((key!='\t')&&(key!=KEY_ESC)&&(key!='\n')&&
			(key!=KEY_DOWN)&&(key!=KEY_UP)&&(key!=KEY_LEFT)&&(key!=KEY_RIGHT))
				{
				ungetch(key);
				address.GetString();
				}
			else if(key=='\t') object++;
			else if(key=='\n') object++;
			else if(key==KEY_ESC) break;
			else if((key==KEY_DOWN)||(key==KEY_RIGHT)) object++;
			else object=5;
			}
		else if(object==2)
			{
			move(y1+6,x1+5+15);
			int key=user_getch();
			if((key!='\t')&&(key!=KEY_ESC)&&(key!='\n')&&
			(key!=KEY_DOWN)&&(key!=KEY_UP)&&(key!=KEY_LEFT)&&(key!=KEY_RIGHT))
				{
				ungetch(key);
				fullname.GetString();
				}
			else if(key=='\t') object++;
			else if(key=='\n') object++;
			else if(key==KEY_ESC) break;
			else if((key==KEY_DOWN)||(key==KEY_RIGHT)) object++;
			else object--;
			}
		else if(object==3)
			{
			move(y1+7,x1+5+15);
			int key=user_getch();
			if((key!='\t')&&(key!=KEY_ESC)&&(key!='\n')&&
			(key!=KEY_DOWN)&&(key!=KEY_UP)&&(key!=KEY_LEFT)&&(key!=KEY_RIGHT))
				{
				ungetch(key);
				identifier.GetString();
				}
			else if(key=='\t') object++;
			else if(key=='\n') object++;
			else if(key==KEY_ESC) break;
			else if((key==KEY_DOWN)||(key==KEY_RIGHT)) object++;
			else object--;
			}
		else if(object==4)
			{
			ok.Keyboard();
			if(ok.CheckTab()) object++;
			else if(ok.CheckEscape()) break;
			else 
				{
				strcpy(emails[item],address.ReturnString());
				strcpy(names[item],fullname.ReturnString());
				strcpy(idents[item],identifier.ReturnString());
				break;
				}
			}
		else if(object==5)
			{
			cancel.Keyboard();
			if(cancel.CheckTab()) object=1;
			else break;
			}				
		
		}
	}

