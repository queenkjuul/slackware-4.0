/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TFileList.h"

void TFileList::ShowWindow()
	{
	logfile("TList::ShowWindow");  
	int pos1;  
	attrset(A_REVERSE);
	TWindow::ShowWindow();
	for(int i=0;i<=MaxHeight();i++)
	if(i<itemcount) 
	user_mvaddstr(winy1+i+1,winx1+1,MaxWidth(),directory[i]);
	}

void TFileList::Keyboard()
	{
	char dirsign,noreread_flag=0;
	do
		{  
		TFileAttachList object(directory,itemcount,x1,y1,x2,y2,current,filelisttxtcolor,filelistselectedcolor,filelistbarcolor);
		object.Keyboard();
		current=object.GetElement();
		escape=object.CheckEscape();
		space=object.CheckSpace();
		tab=object.CheckTab();
		
		char *tmp=ReturnValue(); dirsign=tmp[0];
		if((strcmp(tmp,"/.")!=0)&&(strcmp(tmp,"/..")!=0))
			{
			if(dirsign=='/') strcat(dirname,tmp);
			
			else if(space) { strcat(dirname,"/"); 
				strcat(dirname,tmp); 
				noreread_flag=1; }
			}
		else if((strcmp(tmp,"/..")==0)&&(!tab)&&(!escape)&&(!space))
		for(int i=strlen(dirname);i>=0;i--) if(dirname[i]=='/') 
			{dirname[i]=0; break;}
		if(tab) noreread_flag=1;
		if(!noreread_flag)
			{current=0;
			itemcount=0;
			destruct();
			InitData();}
		noreread_flag=0;
		}
	while(((!space)||(dirsign=='/'))&&(!escape)&&(!tab));
	}
void TFileList::InitData()
	{
	DIR *dir;
	struct stat st;
	struct dirent *dir_content;
	char *str=new char[255];
	if(dirname[0]!='\0')
	dir=opendir(dirname);
	else
	dir=opendir("/");
	dir_content=readdir(dir);
	while(dir_content=readdir(dir))
		{
		itemcount++;  
		directory=(pchar*)realloc(directory,sizeof(pchar)*(itemcount+2));
		directory[itemcount-1]=new char[255];
		sprintf(str,"%s/%s",dirname,dir_content->d_name);
		stat(str,&st);
		if(S_ISDIR(st.st_mode))
		sprintf(directory[itemcount-1],"/%s",dir_content->d_name);
		else
		strcpy(directory[itemcount-1],dir_content->d_name);   
		}
	closedir(dir);          
	delete[] str;
	}

