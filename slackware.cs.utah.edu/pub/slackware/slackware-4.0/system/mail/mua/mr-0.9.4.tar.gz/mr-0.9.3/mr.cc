/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include"mr.h"
#include"TFolderList.h"
#include"TUserMenuBar.h" 
#include<signal.h>

void handle_sigint(int signum)  //obsluga ctrl+break / ctrl+c
	{
	char *str=new char[255];
	sprintf(str,"rm -f %s/.mr/*%ld.tmp",getenv("HOME"),(long)getpid());
	system(str);
	endwin();
	system("clear");
	if(signum==SIGINT) printf("MR: Program interrupted!\n");
	else if(signum==SIGTERM) printf("MR: Program terminated.\n");
	else if(signum==SIGSEGV) printf("MR: Oooops! Something's wrong with memory allocation. Segmentation fault.\n"); 
	exit(1);
	}

TUserMenuBar  menubar("\rFile:System operations"
"\nAbout:About the program and his author"
"\nExit :Exit program"
"\rFolder:Folder related commands"
"\nFolders window:Opens a window, where you can choose the folder"
"\rFolderviewer:Folder viewer options"
"\nEnter a message  i,INS:Start writing new message"
"\nReply to a message   q:Reply to current message"
"\nMessage list         l:Open a window with the list of messages of this folder"
"\nNext                 +:See next message in this thread"
"\nPrevious             -:See previous message in this thread"
"\nComment reply        c:Reply to the receiver of the message"
"\nSave message         w:Write message to disk"
"\nView headers         v:View the headers of the message"
"\nForward message      f:Copy (forward) the message to another account"
"\nFind string         F6:Find a message with a specified string of characters"
"\nGo to message        g:Go to a message of specified number"
"\nSign (mark) messages s:Toggles the window, which gives advanced features for marking"
"\nDelete message(s)  DEL:Deletes message (or marked messages)"
"\rEditor:Message editor commands"
"\nAbort writing ESC:Abort writing the message"
"\nSave message   F2:Send the message"
"\nModify header    :Modify header - to, cc, bcc, and subject lines"
"\rOptions:Configuration options"
"\nConfigure colors   :Configure colors"
"\nSave colors        :Save defined colors to disk"
"\nEdit msg header    :Edit the \"new message\"template"
"\nEdit reply header  :Edit the \"reply\" template"
"\nEdit comment header:Edit the \"comment\" template"
"\nEdit signature     :Edit the signature template"
"\nEdit addres book   :Edit the address book message base");




main(int argc,char *argv[])
	{
	char str[255];
	signal(SIGINT,handle_sigint);
	signal(SIGTERM,handle_sigint);
	signal(SIGSEGV,handle_sigint);
	logging=0;
	nofoldergetch=0;
	menu_outfromfolderviewer=0;
	strcpy(rc_charset,"US-ASCII");
	strcpy(rc_forwardbanner,"------- forwarded message --------");
	LoadUsername(getenv("LOGNAME"));
	if(argc>=2)
	for(int i=1;i<argc;i++)
		{
		if(strcmp(argv[i],"-l")==0) logging=1;
		else if(strcmp(argv[i],"-f")==0)
			{i++; setenv("PBMR_ATTACH",argv[i],1);ungetch(KEY_IC);}
		}
	int key;
	int x,y;
	initscr();
	noecho();
	cbreak();
	keypad(stdscr,TRUE);
	start_color();
	initcolors();
	ReadColorsFile();
		{
		
		menubar.ShowBar();
		getmaxyx(stdscr,y,x);
		TFolderList lista(0,1,x-1,y-2);
		} 
	endwin();
	system("clear");
	sprintf(str,"rm ~/.mr/*.%ld.tmp -f",getpid());
	system(str);
	}
void Help()
	{
	int x,y;
	char *str=new char[255];
	getmaxyx(stdscr,y,x);
	sprintf(str,"%s/%s",GetHelpPath(),helpfile);
	TFileView help(str,15,5,x-15,y-5);
	help.Keyboard();
	delete[] str;
	}
void MenuPlay()
	{
	menubar.UngetchKeys();
	}

