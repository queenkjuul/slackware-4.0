/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TMIME_H
#define _TMIME_H
#include"TView.h"
#include"TFileAttach.h"
#include"TMsgList.h"
#include"TMailEdit.h"
#include"THeaderModify.h"
#include"colors.h"
#include"keyboard.h"
#include"misc.h"
#include"TViewTextMsg.h"
#include"TQuotedPrintable.h"
#include"TCharset.h"
#include"TMultipartList.h"
#include"TBASE64.h"
#include"TWindow.h"
#include"THeaderMIME.h"

#define HEADER_NUMBER 9

extern const char *header[HEADER_NUMBER];
class TMime;
typedef TMime *pTMime;


class TMime  : public TWindow{
	static TMime **MimePtr;
	static int licznik;
	ppchar *ptrtooldfile;
	TViewTextMsg *msgviewer;
	pchar *file;
	pchar *list;
	static char *from;   //imie i nazwisko z pola from:
	static char *secondfrom; //e-mail z pola reply-to:
	static char *to;    //imie i nazwisko z pola to:
	static char *subj;  //pole subject:
	static char *date;  //pole date:
	static char *email; //adres z from:
	static char *toemail;         //adres z to:
	static char *msgid;
	char *defaultto;
	char *defaultcc;
	char *defaultbcc;
	char *replyto;
	char *content_type;
	char *content_transfer_encoding;
	long minline;
	long maxy,curmsg,maxmsg;
	int x1,y1,x2,y2;
	void WriteFromHeader(char *str,char **str1); //wyciagnij zawartosc
	//z naglowka
	void QuotedPrintable();     //dekoder quoted printable
	void KillHeaderLines(); //inicjalizacja zmiennych z naglowkow i
	//usuniecie ich z oczu usera
	void MimeOperations();  //dekodowanie listu                                     
	void Multipart();       //obsluga multiparta
	void TextMessage();
	void GetFilename(char *);
	void MessageRFC822();
	void MimeManager();
	void GetType(char*,pchar*);
	void ShowWindow();
	public:
	long ReturnMaxy() { return maxy+minline; }
	TMime(ppchar *msg,int x,int y,int x1,int y1,
	char *dfltto="\0",char *dfltcc="\0", 
	char *dfltbcc="\0",char *rplto="\0",long max_y=0,
	long curmsg=0,long maxmsg=0,pchar *l=MYNULL);
	~TMime()
		{
		logfile("TMime::~TMime");
		if(msgviewer) delete msgviewer;
		delete[] content_type;
		delete[] content_transfer_encoding;
		licznik--;
		}         
	};

#endif                  
