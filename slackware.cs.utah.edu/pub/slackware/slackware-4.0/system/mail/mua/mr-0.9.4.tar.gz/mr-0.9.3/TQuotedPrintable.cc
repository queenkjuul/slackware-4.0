/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TQuotedPrintable.h"

void TQuotedPrintable::Encode()
	{
	logfile("TQuotedPrintable::Encode");
	long y,x;
	for(y=minline;y<=minline+MAXY;y++)
		{
		for(x=0;x<strlen(FILE1[y]);x++)
			{
			if((((unsigned char)FILE1[y][x])<32)
			||(((unsigned char)FILE1[y][x])>126)
			||(((unsigned char)FILE1[y][x])=='=')
			||((((unsigned char)FILE1[y][x])=='.')&&(x==0)))
				{
				int len=strlen(FILE1[y]); 
				int val=(unsigned char)FILE1[y][x];
				FILE1[y]=(char*)realloc(FILE1[y],len+5);
				for(int i=len+1;i>x;i--) FILE1[y][i+2]=FILE1[y][i];
				FILE1[y][x]='=';
				if(int(val/16)>=10) FILE1[y][x+1]=((unsigned char)(val/16))+'A'-10;
				else FILE1[y][x+1]=((unsigned char)(val/16))+'0';
				val-=int(val/16)*16;
				if(val>=10) FILE1[y][x+2]=val+'A'-10;
				else FILE1[y][x+2]=val+'0';
				x+=2;
				}
			if(x>73)
				{
				FILE1=(pchar*)realloc(FILE1,sizeof(pchar)*(MAXY+minline+5));
				MAXY++;
				for(long i=MAXY+minline;i>y+1;i--) FILE1[i]=FILE1[i-1];
				FILE1[y+1]=new char[strlen(FILE1[y])];
				sprintf(FILE1[y+1],"%s",&(FILE1[y][x+1]));
				FILE1[y][x+1]='\0';
				strcat(FILE1[y],"=");
				y++; x=-1;
				}
			}
		if(FILE1[y][strlen(FILE1[y])-1]==' ') 
			{ strcpy(&(FILE1[y][strlen(FILE1[y])-1]),"=20"); }
		
		}
	}
void TQuotedPrintable::Decode()
	{
	logfile("TQuotedPrintable::Decode");  
	for(int y=minline;y<=minline+MAXY;y++)
		{
		logfile("1");  
		for(int j=0;j<strlen(FILE1[y]);j++)
			{
			logfile("2");  
			if(FILE1[y][j]=='=') 
				{
				logfile("3");   
				unsigned char val;
				int len=strlen(FILE1[y]);
				logfile("4");
				if(FILE1[y][j+1]=='\0') 
					{
					if(y<MAXY+minline)
						{
						
						FILE1[y]=(char*)realloc(FILE1[y],strlen(FILE1[y])+strlen(FILE1[y+1])+50);   
						FILE1[y][j]='\0';
						strcat(FILE1[y],FILE1[y+1]);
						delete[] FILE1[y+1];
						for(int i=y+1;i<=MAXY+minline-1;i++)
						FILE1[i]=FILE1[i+1];
						MAXY--;
						j--;
						}
					}
				else if(FILE1[y][j]=='=')
					{
					if(FILE1[y][j+1]<'A') 
					val=((unsigned char)FILE1[y][j+1]-'0')*16;
					else val=((unsigned char)FILE1[y][j+1]-'A'+10)*16;
					if(FILE1[y][j+2]<'A') 
					val+=((unsigned char)FILE1[y][j+2]-'0');
					else val+=((unsigned char)FILE1[y][j+2]-'A'+10);
					FILE1[y][j]=val;
					for(int k=j+1;k<=len-2;k++)
					FILE1[y][k]=FILE1[y][k+2];
					}
				}
			}
		if((strlen(FILE1[y])>76)&&(!binary))
			{
			FILE1=(pchar*)realloc(FILE1,sizeof(pchar)*(MAXY+minline+5));
			for(long i=MAXY+minline;i>y;i--)
			FILE1[i+1]=FILE1[i];
			FILE1[y+1]=new char[strlen(FILE1[y])];
			strcpy(FILE1[y+1],FILE1[y]+76);
			FILE1[y][76]='\0';
			MAXY++;   
			}  
		}
	}                  

#undef FILE1
#undef MAXY

