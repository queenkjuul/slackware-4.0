/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TFILELIST_H
#define _TFILELIST_H

#include "misc.h"
#include "TFileAttachList.h"
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

class TFileList : public TWindow {
	char *dirname;
	pchar *directory;
	int x1,y1,x2,y2;
	long itemcount;
	int escape;
	int space;
	int tab;
	long current;
	void InitData();
	public:
	int CheckEscape() { return escape; }
	int CheckTab() { return tab; }
	char *ReturnValue() { return directory[current]; }
	char *ReturnFileName() { if(dirname[0]) return dirname; else return MYNULL; }                      
	void RestoreDir() { for(int i=strlen(dirname);i>=0;i--)
		if(dirname[i]=='/') {dirname[i]='\0'; break;} }
	void Keyboard();
	void ShowWindow();
	TFileList(char *dname,int x,int y,int x_1,int y_1) : dirname(new char[1024]),
	TWindow(x,y,x_1,y_1,"Browse files"),
	directory(new pchar[1]),
	itemcount(0),
	x1(x),x2(x_1),y1(y),y2(y_1),
	current(0),
	escape(0),tab(0)
		{
		strcpy(dirname,dname);   
		InitData();   
		}
	void destruct()
		{
		for(long i=0;i<itemcount;i++)
		delete[] directory[i];
		}                 
	~TFileList() { destruct(); delete[] directory; delete[] dirname; }                 
	};

#endif


