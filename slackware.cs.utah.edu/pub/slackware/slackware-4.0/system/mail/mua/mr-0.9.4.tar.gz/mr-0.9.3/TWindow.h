/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/

#ifndef _TWINDOW_H
#define _TWINDOW_H
#include"colors.h"
#include"keyboard.h"
#include"misc.h"

class TWindow {
	char *title;                 //tytul okna
	chtype *window;
	public:
	int winx1,winy1,winx2,winy2; //wspolrzedne okna 
	int MaxHeight() { return winy2-winy1-2; }
	int MaxWidth()  { return winx2-winx1-2; }
	void GetWindow();
	void PutWindow();
	void virtual user_mvaddstr(int y, int x, int maxlen, char *str);
	
	TWindow(int x1,int y1,int x2,int y2, char *title) : winx1(x1), winy1(y1),
	winx2(x2), winy2(y2),
	title(title),
	window(MYNULL)
		{
		logfile("TWindow::TWindow");  
		GetWindow();  
		}
	~TWindow()
		{
		logfile("TWindow::~TWindow");  
		PutWindow();
		delete[] window;
		}     
	void virtual ShowWindow();            //wyswietlenie ramki okna
	};

#endif               
