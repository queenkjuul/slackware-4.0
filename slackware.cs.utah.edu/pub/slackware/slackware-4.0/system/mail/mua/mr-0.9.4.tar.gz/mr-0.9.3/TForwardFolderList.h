/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TFORWARD_H
#define _TFORWARD_H

#include "TFolderListEngine.h"
#include "mr.rc.variables.h"
#include "extensions.h"
#include "misc.h"
#include <stdio.h>

class TForwardFolderList : public TWindow
	{
	private:
	long startpos,endpos;
	pchar *items;  
	pchar *files;  
	pchar *dto;
	pchar *dcc;
	pchar *dbcc;
	pchar *replyto;
	long count;
	int x,y,x1,y1;
	public:
	long current;
	void InitItems();  
	int virtual Action();
	TForwardFolderList(int xi,int yi,int xi1,int yi1,long startp,long endp):  
	count(-1),files(MYNULL),
	startpos(startp),endpos(endp),
	items(MYNULL),dto(MYNULL),
	dcc(MYNULL),dbcc(MYNULL),
	replyto(MYNULL),
	current(0),
	TWindow(xi,yi,xi1,yi1,"\0"),
	x(xi),y(yi),x1(xi1),y1(yi1)
		{
		logfile("TFolderList::TFolderList"); 
		InitItems();
		ProgramPosition=FOLDERLIST;
		StatusLine("Up/Down: Choose folder  Enter: Run folder  F10: Menu");
		Action();   
		}
	~TForwardFolderList()
		{
		logfile("TFolderList::~TFolderList");
		for(int i=0;i<count;i++)
			{
			delete[] items[i];  
			delete[] files[i];
			}
		delete[] items;
		delete[] files;
		delete[] dto;
		delete[] dcc;
		delete[] dbcc;
		delete[] replyto;
		}      
	};

#endif

