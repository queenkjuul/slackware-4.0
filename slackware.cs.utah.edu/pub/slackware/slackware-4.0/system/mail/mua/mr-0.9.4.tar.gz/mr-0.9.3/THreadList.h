#ifndef _TTHREADLIST_H
#define _TTHREADLIST_H
#include "TList.h"

class TThreadList {
	int *references; // the fields which contain the real msg numbers
	// and not the ones, sorted in a thread tree
	pchar *tree;     // the thread tree
	int max_msg,cur_msg;
	public:
	TThreadList(pchar *inreplyto,pchar *msgid,int maxmsg,int curmsg) :
	in_reply_to(inreplyto),msg_id(msgid),max_msg(maxmsg),
	cur_msg(curmsg),tree(MYNULL)
		{
		tree=new pchar[max_msg];
		}
	~TThreadList()
		{
		for(int i=0;i<max_msg-1;i++)
		delete[] tree[i];
		delete[] tree;  
		}	         
	};

#endif
