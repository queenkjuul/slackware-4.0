/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TMime.h"

int TMime::licznik=0;
char *TMime::from=new char[255];   //imie i nazwisko z pola from:
char *TMime::secondfrom=new char[255]; //e-mail z pola reply-to:
char *TMime::to=new char[255];    //imie i nazwisko z pola to:
char *TMime::subj=new char[255];  //pole subject:
char *TMime::date=new char[255];  //pole date:
char *TMime::email=new char[255]; //adres z from:
char *TMime::toemail=new char[255];         //adres z to:
char *TMime::msgid=new char[255];         //message id

const char *header[HEADER_NUMBER]= {"From:",
	"To:",
	"Subject:",
	"Date:",
	"Reply-To:",
	"Content-Type:",
	"Message-ID:",
	"Status:",
	"Content-Transfer-Encoding:"};



TMime **TMime::MimePtr=MYNULL;

TMime::TMime(ppchar *msg,int ax,int ay,int ax1,int ay1,
char *dfltto,char *dfltcc, 
char *dfltbcc,char *rplto,long max_y,
long acurmsg,long amaxmsg,pchar *l)  : 
TWindow(ax,ay,ax1,ay+5,"Header"),
ptrtooldfile(msg),
file(*msg),
defaultto(dfltto),
defaultcc(dfltcc),
defaultbcc(dfltbcc),
replyto(rplto),
content_type(new char[255]),
content_transfer_encoding(new char[255]),
minline(0),
maxy(max_y-1),
x1(ax),
x2(ax1),
y1(ay),
y2(ay1),
curmsg(acurmsg),
maxmsg(amaxmsg),
list(l),
msgviewer(MYNULL)

	{
	logfile("TMime::TMime");   
	licznik++;
	msgid[0]=0;
	MimePtr=(pTMime*)realloc(MimePtr,(licznik)*sizeof(pTMime));
	MimePtr[licznik-1]=this;
	sprintf(content_type,"text/plain; charset=US-ASCII");
	sprintf(content_transfer_encoding,"7bit");
	sprintf(secondfrom,"\0");   
	KillHeaderLines();
	MimeOperations();
	MimeManager();
	}

void TMime::GetFilename(char *name)
	{
	int j=0;
	name[0]='\0';
	for(int i=0;i<strlen(content_type);i++)
		{
		if((content_type[i]=='n')||(content_type[i]=='N'))
			{
			if(CompareStr("name=",content_type+i,5,1))
				{
				if(content_type[i+5]=='"')
				for(j=0,i=i+6;content_type[i]!='"';j++,i++)
				name[j]=content_type[i];  
				else
				for(j=0,i=i+5;content_type[i]!=' ';j++,i++)
				name[j]=content_type[i];
				name[j]='\0';                  
				}  
			}
		}
	
	}
void TMime::MessageRFC822()
	{
	pchar *tmpfile=new pchar[maxy-minline+5];
	for(long i=minline;i<=maxy;i++)
		{
		tmpfile[i-minline]=new char[strlen(file[i])+10];
		strcpy(tmpfile[i-minline],file[i]);  
		}
	new TMime(&tmpfile,
	x1,y1,x2,y2,
	defaultto,
	defaultcc,
	defaultbcc,
	replyto,
	maxy-minline,
	curmsg,
	maxmsg,list);
	long newmaxy=MimePtr[licznik-1]->ReturnMaxy();
	for(long i=0;i<newmaxy;i++)
	delete[] tmpfile[i];
	delete[] tmpfile;
	delete MimePtr[licznik-1]; //bo licznik pokazuje 2, nie 1
	}
void TMime::ShowWindow()
	{
	int len=0,a=0;
	if((a=strlen(subj))>len) len=a;
	if((a=strlen(from))>len) len=a;
	if((a=strlen(email))>len) len=a;
	if((a=strlen(date))>len) len=a;
	if((a=strlen(from))>len) len=a;
	if((a=strlen(toemail))>len) len=a;
	char *str=new char[len+255];      
	attrset(viewerheaderscolor);
	TWindow::ShowWindow();
	if(list[curmsg-1][5]!='*')
	sprintf(str,"Message %ld of %ld",curmsg,maxmsg);
	else  
	sprintf(str,"Message *%ld of %ld",curmsg,maxmsg);
	attrset(viewerheaderscolor);
	user_mvaddstr(winy1+1,winx1+1,MaxWidth()>>1,str);
	sprintf(str,"From:%s                                        ",from);
	sprintf(str+38," %s",email);
	user_mvaddstr(winy1+2,winx1+1,MaxWidth(),str);
	sprintf(str,"To:%s                                          ",to);
	sprintf(str+38," %s",toemail);
	user_mvaddstr(winy1+3,winx1+1,MaxWidth(),str);
	sprintf(str,"Subject:%s",subj);
	user_mvaddstr(winy1+4,winx1+1,MaxWidth(),str);
	sprintf(str," Date:%s",date);
	user_mvaddstr(winy1+1,winx1+1+MaxWidth()>>1,
	MaxWidth()>>1,str);
	delete[] str;      
	}                      
void TMime::MimeManager()
	{
	if(CompareStr(content_type,"Multipart",9,1))
	Multipart();
	else if(CompareStr(content_type,"Application",11,1))
		{TFileAttach attach(&file[minline],maxy,minline,content_type,content_transfer_encoding);}
	else if(CompareStr(content_type,"Image",5,1)) 
		{TFileAttach attach(&file[minline],maxy,minline,content_type,content_transfer_encoding);}
	else if(CompareStr(content_type,"Audio",5,1)) 
		{TFileAttach attach(&file[minline],maxy,minline,content_type,content_transfer_encoding);}
	else if(CompareStr(content_type,"Video",5,1)) 
		{TFileAttach attach(&file[minline],maxy,minline,content_type,content_transfer_encoding);}
	else if(CompareStr(content_type,"Message/rfc822",14,1))
		{MessageRFC822();}
	else               
	TextMessage();
	(*ptrtooldfile)=file;
	}                      
void TMime::TextMessage()
	{
	logfile("TMime::TextMessage");
	static char name_param[256];
	pchar *tmpfile=MYNULL;
	unsigned char *dane_tmp=new unsigned char[1];
	long filelen=0,n1,n2,maximumy=maxy,mline=minline;
	if(!CompareStr(content_transfer_encoding,"BASE64",6,1))
	tmpfile=file;
	else
		{
		tmpfile=new pchar[5];  
		tmpfile[0]=new char[5];
		long len=maxy;  
		TBASE64 b64(&dane_tmp,&file,&len,minline,&filelen);
		b64.Decode();
		n1=0,n2=0;
		for(long i=0;i<filelen;i++)  //przepisanie tekstu z ciagu 
			{                    //na linijki
			if((dane_tmp[i]=='\n')||(n2>=(x2-x1-2)))
				{tmpfile[n1][n2]=0, n1++;
				tmpfile=(pchar*)realloc(tmpfile,sizeof(pchar)*(n1+2));
				tmpfile[n1]=new char[5];
				n2=0;}
			else
				{ 
				tmpfile[n1]=(char*)realloc(tmpfile[n1],sizeof(char)*(n2+5));
				tmpfile[n1][n2]=dane_tmp[i],n2++;
				}
			}
		tmpfile[n1][n2]=0;            
		mline=0;
		maximumy=n1;
		}  
	
		{ShowWindow();
		if(msgviewer) delete msgviewer;
		GetFilename(name_param);
		msgviewer = new  TViewTextMsg(tmpfile,x1,y1+6,x2,y2,from,to,email,toemail,
		subj,date,curmsg,maxmsg,mline,maximumy,
		defaultto,defaultcc,defaultbcc,replyto,
		msgid,
		secondfrom,list,name_param);
		msgviewer->Keyboard();}    
	
	delete[] dane_tmp;
	if(CompareStr(content_transfer_encoding,"BASE64",6,1))
		{
		for(int i=0;i<=n1;i++)  delete[] tmpfile[i];
		delete[] tmpfile;
		}
	(*ptrtooldfile)=file;         
	}
void TMime::KillHeaderLines()
	{
	logfile("TMime::KillHeaders");
	int i=0,j,k;
	sprintf(secondfrom,"\0");
	while(i<maxy)
		{
		THeaderMIME dequoter(&file[i]);
		dequoter.Decode();
		for(k=0;k<HEADER_NUMBER;k++)  
			{
			if(CompareStr(file[i],header[k],strlen(header[k]),1))
				{
				if(CompareStr(header[k],"From:",5,1))
					{
					WriteFromHeader(file[i]+5,&from);
					WriteFromHeader(file[i]+5,&email);
					GetNameFromAddress(from);
					GetEMailFromAddress(email);
					}
				else if(CompareStr(header[k],"To:",3,1))
					{
					WriteFromHeader(file[i]+3,&to);
					WriteFromHeader(file[i]+3,&toemail);
					GetNameFromAddress(to);
					GetEMailFromAddress(toemail);
					}
				else if(CompareStr(header[k],"Content-Transfer-Encoding:",26,1))
					{
					WriteFromHeader(file[i]+26,&content_transfer_encoding);
					GetEMailFromAddress(content_transfer_encoding);
					}
				else if(CompareStr(header[k],"Content-Type:",13,1))
					{
					WriteFromHeader(file[i]+13,&content_type);  
					long t=i+1;
					while((file[t][0]==' ')||(file[t][0]=='\t'))
						{
						content_type=(char*)realloc(content_type,strlen(content_type)+strlen(file[t])+10);
						strcat(content_type,file[t]);
						t++;
						}
					}
				else if(CompareStr(header[k],"Message-ID:",11,1))
				WriteFromHeader(file[i]+11,&msgid);  
				else if(CompareStr(header[k],"Subject:",8,1))
				WriteFromHeader(file[i]+8,&subj);  
				else if(CompareStr(header[k],"Date:",5,1))
				WriteFromHeader(file[i]+5,&date);    
				else if(CompareStr(header[k],"Reply-To:",9,1))
				WriteFromHeader(file[i]+9,&secondfrom);    
				}
			} 
		i++;     
		if(file[i][0]==0)
			{
			minline=i+1;
			maxy-=i+1;
			break;
			}
		}  
	}                  
void TMime::WriteFromHeader(char *str2, char **str1)
	{   //str1=naglowek, str=fragment zmiennej file
	logfile("TMime::WriteFromHeader"); 
	char *tmp=new char[256]; 
	int headerlength=250;
	int i=0,j=0;
	while(1)
		{
		if((str2[i]=='\n')||(str2[i]=='\0')) break;
		else tmp[j++]=str2[i];
		if(j>headerlength)
			{
			headerlength=j+40;
			tmp=(char*)realloc(tmp,headerlength+50);
			}
		i++;
		}
	tmp[j]='\0';    
	int cnt;
	for(cnt=strlen(tmp);cnt>0;cnt--)
	if(tmp[cnt]!=' ') break;
	tmp[cnt+1]='\0';   
	for(cnt=0;cnt<strlen(tmp);cnt++)
	if(tmp[cnt]!=' ') break;
	(*str1)=(char*)realloc((*str1),headerlength+50);
	for(i=cnt;i<strlen(tmp)+1;i++)
	(*str1)[i-cnt]=tmp[i];
	delete[] tmp;       
	}

void TMime::MimeOperations()
	{
	char *str=new char[255];   
	char *ct=content_type;
	logfile("TMime::MimeOperations");   
	if(CompareStr(content_transfer_encoding,"quoted-printable",16,1))
		{if(CompareStr(content_type,"Text",4,1))
                 	{TQuotedPrintable qp(&file,&maxy,minline); qp.Decode();}}
                
	if(CompareStr(content_type,"text",4,1))
		{
		for(;(*ct)&&(*ct!='=');ct++);
		if(ct[0]!='\0'){for(int i=0;i<strlen(ct);i++)ct[i]=toupper(ct[i]);
			sprintf(str,"%s/%s",CHARSETPATH,++ct);
			TCharset ch(file,maxy,minline,str);
			ch.Decode();}
		}
	delete[] str;       
	(*ptrtooldfile)=file;
	}
void TMime::Multipart()
	{
	logfile("TMime::Multipart");  
	char *bstart="boundary=";
	pchar *optionz=new pchar[1];
	long *maxys=new long[1],tmp,y;
	maxys[0]=0;
	char *boundary=new char[255];
	int optnumber=0;
	ppchar *start=new ppchar[1];
	for(int i=0;i<strlen(content_type);i++)
		{
		if((content_type[i]=='b')||(content_type[i]=='B'))
		if(CompareStr(content_type+i,bstart,9,1))
			{
			int quoted=0;
			for(int j=i+9;j<strlen(content_type);j++)
				{
				if(content_type[j]=='"')
				quoted^=1;
				if((!quoted)&&(content_type[j]==';'))
					{
					content_type[j]=0;
					break;
					}
				}
			if(content_type[i+9]=='"') 
				{
				sprintf(boundary,"%s",content_type+i+10);
				for(int j=0;j<=strlen(boundary);j++)
				if(boundary[j]=='"') {boundary[j]=0;break;}
				}
			else
			sprintf(boundary,"%s",content_type+i+9);  
			break;
			}
		}
	for(y=minline;y<=maxy+minline;y++)
		{
		if((file[y][0]=='-')&&(file[y][1]=='-'))
			{
			logfile(file[y]); 
			if(strlen(file[y])>strlen(boundary))  
			if(CompareStr(&file[y][2],boundary,strlen(boundary)-2,0))
				{
				logfile("Msg found!");  
				optnumber++;  
				
				start=(ppchar*)realloc(start,(optnumber+2)*sizeof(ppchar));
				
				optionz=(pchar*)realloc(optionz,(optnumber+2)*sizeof(pchar));
				optionz[optnumber]=new char[255];
				GetType(optionz[optnumber],&file[y]);
				
				start[optnumber]=&file[y];
				
				maxys=(long*)realloc(maxys,sizeof(long)*(optnumber+4));
				tmp=0; for(int i=0;i<=optnumber-1;i++) tmp+=maxys[i];
				maxys[optnumber]=y-tmp;
				}
			}
		}      
	
	char bye;
	ShowWindow();
	TMultipartList multipart_list(&optionz[1],optnumber-1,x1,y1+6,x2,y2,0,multipartlistnormal,multipartlistselected,multipartlistbar,list,from,email,to,toemail,subj,date,curmsg,maxmsg);
	do
		{
		int element; 
		multipart_list.Keyboard();
		element=multipart_list.GetElement();
		bye=multipart_list.CheckEscape();
		if(!bye)
			{
			pchar *tmpfile=new pchar[maxys[element+2]+5];
			for(long i=0;i<=maxys[element+2];i++)
				{
				tmpfile[i]=new char[strlen(start[element+1][i])+10];
				strcpy(tmpfile[i],start[element+1][i]);  
				}
			new TMime(&tmpfile,
			x1,y1,x2,y2,
			defaultto,
			defaultcc,
			defaultbcc,
			replyto,
			maxys[element+2],
			curmsg,
			maxmsg,list);
			long newmaxy=MimePtr[licznik-1]->ReturnMaxy();
			for(long i=0;i<newmaxy;i++)
			delete[] tmpfile[i];
			delete[] tmpfile;
			delete MimePtr[licznik-1]; //bo licznik pokazuje 2, nie 1
			}
		}
	while(!bye);  
	
	for(int i=1;i<=optnumber;i++)
	delete[] optionz[i];
	delete[] optionz;
	delete[] maxys;
	delete[] boundary;        
	delete[] start;
	}                  
void TMime::GetType(char *str,pchar *list)
	{
	char *type=new char[255];
	sprintf(str,"Text message");   
	for(int i=0;list[i][0]!='\0';i++)
		{
		if(CompareStr(list[i],"Content-type:",13,1))
			{
			WriteFromHeader(list[i]+13,&type);   
			if(CompareStr(type,"Application",11,1))
			sprintf(str,"Attachment of a binary file");
			else if(CompareStr(type,"Text",4,1))
			sprintf(str,"Text message");
			else if(CompareStr(type,"Image",5,1))
			sprintf(str,"Attachment of an image");
			else if(CompareStr(type,"Video",5,1))
			sprintf(str,"Attachment of an animation");
			else if(CompareStr(type,"Voice",5,1))
			sprintf(str,"Attachment of a sound message");
			else if(CompareStr(type,"Message",7,1))
			sprintf(str,"Attachment of an e-mail message");
			else if(CompareStr(type,"Multipart",9,1))
			sprintf(str,"Attachment of a multipart message");
			else sprintf(str,"Unknown subtype of message");   
			break;   
			}  
		}
	delete[] type;     
	}                  

