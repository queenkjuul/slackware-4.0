/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TEdit.h"

TEdit::TEdit(char *file_name,int x,int y,int x1,int y1,int textcolr,int barcolr) : 
filename(file_name), 
TView(file_name,x,y,x1,y1,0,textcolr,barcolr),
escape(0),hlpfile("edit.hlp")
	{
	logfile("TEdit::TEdit");
	long filelength=0;
	long i;
	FILE *id;
	int col=0,row=0; 
	if((id=fopen(filename,"rt"))!=MYNULL)   //otwarcie pliq
		{
		char *plik=MYNULL;  
		fseek(id,0,SEEK_END);              //zmierzenie jego dlugosci
		filelength=ftell(id);         
		if(filelength)
			{fseek(id,0,SEEK_SET);
			plik=new char[filelength];        //zaalokowanie na niego pamieci
			fread(plik,1,filelength,id);}     //oczytanie go
		fclose(id);
		file=(pchar*)realloc(file,sizeof(pchar)*2);
		file[0]=new char[255];           //przeksztalcenie go na tekst       
		if(filelength)
		for(i=0;i<filelength;i++)        //w "linijkach"
			{
			if(plik[i]=='\n')          //tj, po kazdym '\n' zmieniamy
				{                   //pozycje w tablicy 2d
				file[row][col]=0;  
				if(col>maxx) maxx=col;
				row++,col=0;
				file=(pchar*)realloc(file,sizeof(pchar)*(row+2));
				file[row]=new char[255];
				continue;
				}
			file[row][col]=plik[i];
			col++;   
			}
		file[row][col]=0;          
		
		
		maxy=row;     
		l_act=maxy;
		if(filelength)
		delete[] plik;     
		}
	else
		{
		maxy=row;
		l_act=maxy;
		file=(pchar*)realloc(file,sizeof(pchar)*2);
		file[0]=new char[255];
		file[0][0]='\0';
		}
	ShowWindow();                        //wyswietlenie okna
	logfile("...ShowWindow przeszlo");
	//               Keyboard();
	}

void TEdit::AddChar(char ch)
	{
	logfile("TEdit::AddChar");  
	char tmp[255];
	int i;
	int czy_null=0;
	attrset(textcolor);
	for(i=0;i<cursorx+cur_col;i++)
	if(file[filepos+cursory][i]==0)        //sprawdzenie, czy znaku
	czy_null=1,file[filepos+cursory][i]=' ';
	else if(czy_null)                      //nie stawiamy poza stringiem
	file[filepos+cursory][i]=' ';     //(po znaku MYNULL)
	if(!czy_null)
	for(i=cursorx+cur_col;i<255;i++)
	tmp[i]=file[filepos+cursory][i];       //zapamietanie linijki
	file[filepos+cursory][cursorx+cur_col]=ch; //wprowadzenei znaku
	if(czy_null)
	file[filepos+cursory][cursorx+cur_col+1]=0;
	else
	for(i=cursorx+cur_col;i<254;i++)       //odtworzenie prze-
	file[filepos+cursory][1+i]=tmp[i];  //sunietej linijki
	MoveRight();                           //kursor o kratke w prawo
	if(cursorx+cur_col>maxx) maxx=cursorx+cur_col;
	}

void TEdit::Delete()
	{
	logfile("TEdit::Delete");  
	int i;
	if(cursorx+cur_col<strlen(file[filepos+cursory]))
	for(i=cursorx+cur_col;i<254;i++)
	file[filepos+cursory][i]=file[filepos+cursory][i+1];
	else if(cursory+filepos<maxy-1)
		{
		AddChar(' ');  
		cursorx=cur_col=0;
		MoveDown();
		BackSpace();
		BackSpace();
		}    
	ShowWindow();
	} 

void TEdit::BackSpace()
	{
	logfile("TEdit::Backspace");  
	int i;
	if(cursorx+cur_col>0)
		{
		if(cursorx+cur_col<=strlen(file[filepos+cursory]))
			{
			for(i=cursorx+cur_col-1;i<254;i++)
			file[filepos+cursory][i]=file[filepos+cursory][i+1];
			}
		MoveLeft();
		}
	else if(cursory+filepos)
		{
		int len=strlen(file[cursory-1+filepos]);
		strcat(file[filepos+cursory-1],file[filepos+cursory]);
		DelLine(filepos+cursory);
		MoveUp();
		GotoXPos(len);
		}
	} 
void TEdit::Keyboard()
	{
	logfile("TEdit::Keyboard");   
	int key,x,y;       
	escape=0;        
	getmaxyx(stdscr,y,x);
	StatusLine("Arrows: Move  F2: Save F3: Import file ESC: Abort  F10: Menu");
	ShowWindow();
	do
		{
		key=user_getch();
		ProgramPosition=TEDIT;  
		switch(key)
			{
			case KEY_F(3):
				{TWindow okienko(15,5,x-15,8,"\0");
				okienko.ShowWindow();
				mvaddstr(6,17,"Enter the filename or nothing to abort:"); 
				TInputField inputfld(17,7,x-34,"\0");
				inputfld.GetString();
				ImportFile(inputfld.ReturnString());}
			break;
			case KEY_CTRL_Y:
			if(maxy>0)
				{
				DelLine(filepos+cursory);
				//           MoveUp();
				}
			break;   
			case KEY_UP:
			MoveUp(); 
			break;
			case KEY_DOWN:
			MoveDown();
			break;
			case KEY_RIGHT:
			MoveRight();
			break; 
			case KEY_LEFT:
			MoveLeft();
			break;
			case KEY_NPAGE:
			PgDn();
			break;
			case KEY_PPAGE:
			PgUp();
			break;
			case KEY_BCKSPC:
			case KEY_BACKSPACE:
			case 8:
			BackSpace();
			break;
			case KEY_DC:
			Delete();
			break;
			case '\n':
			EnterKey();
			break;   
			case KEY_END:
			GotoXPos(strlen(file[cursory+filepos]));
			break;
			case KEY_HOME:
			cursorx=0,cur_col=0;
			break;   
			case KEY_F(1):
			sprintf(helpfile,"%s",Hlp());
			Help();
			break;   
			case KEY_F(10):
			MenuPlay();
			break;
			//-------------------- zabezpieczenie przed default'em
			case KEY_F(2):
			break;
			case KEY_ESC:
			break;      
			//----------------------------------------------------           
			default:
			AddChar(key);
			}
		ShowWindow();
		}
	while((key!=KEY_ESC)&&(key!=KEY_F(2)));
	if(key==KEY_ESC)
	escape=1;
	}                              
void TEdit::AddLine()
	{
	logfile("TEdit::AddKey"); 
	maxy++;
	file=(pchar*)realloc(file,sizeof(pchar)*(maxy+2));
	char *tmp=new char[255];  //utworzenie i ustawineie dlugosci 0
	tmp[0]=0;           //w nowej linii
	if(filepos+cursory+1<maxy)   //przesuniecie linijek z tekstem w dol
	for(int i=maxy;i>filepos+cursory+1;i--)
	file[i]=file[i-1];
	file[filepos+cursory+1]=tmp;//ustawienie nowej linijki
	l_act++;  //ilosc linii aktywnych
	}
void TEdit::DelLine(int line)
	{
	logfile("TEdit::DelLine");
	char *tmpstr=file[line];
	if(line<maxy)
	for(int i=line;i<maxy;i++) 
	file[i]=file[i+1];
	file[maxy]=tmpstr;
	delete[] file[maxy];
	l_act--;
	maxy--;
	}               
void TEdit::EnterKey()
	{
	logfile("TEdit::EnterKey"); 
	AddLine();
	if(cursorx+cur_col<strlen(file[cursory+filepos]))
	sprintf(file[cursory+filepos+1],"%s",file[cursory+filepos]+cursorx+cur_col);
	file[cursory+filepos][cursorx+cur_col]=0;
	MoveDown();
	GotoXPos(0);
	}               
void TEdit::WriteMsg()
	{
	logfile("TEdit::WriteMsg");  
	FILE *id;
	int i;
	if((id=fopen(filename,"w"))!=MYNULL)
		{
		for(i=0;i<maxy;i++)
		fprintf(id,"%s\n",file[i]);
		fprintf(id,"%s",file[i]);
		fclose(id);  
		}
	else    
		{
		endwin();
		printf("\nCannot create %s\n",filename);
		exit(1);  
		}
	}
void TEdit::ImportFile(char *filename)
	{
	logfile("TEdit::ImportFile");  
	FILE *id;
	if((id=fopen(filename,"rb"))!=MYNULL)
		{
		fseek(id,0,SEEK_END);
		long length=ftell(id);
		fseek(id,0,SEEK_SET);
		char *data=new char[length+5];
		fread(data,length,1,id);
		fclose(id);
		long last=-1;
		for(long i=0;i<=length;i++)
			{
			if((data[i]=='\n')||(i==length))
				{
				data[i]=0;   
				AddLine();
				if(cursory<MaxHeight()) cursory++; else filepos++;
				strcpy(file[cursory+filepos],&data[last+1]);
				last=i;
				}
			}
		delete[] data;   
		}
	}

