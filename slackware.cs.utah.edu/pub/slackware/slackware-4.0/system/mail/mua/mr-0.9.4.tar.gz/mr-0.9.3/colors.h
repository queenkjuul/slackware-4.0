/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _COLORS_H
#define _COLORS_H

//Message editor colors   
extern int mailedittextcolor; //normal text
extern int maileditbarcolor;  //scrollbar color
extern int maileditquotecolor; //quote color

//Menu bar colors
extern int menubarcolor;       //color of unhighlighted bar
extern int menubarselectedcolor;     //color of highlighted item

//Submenu colors
extern int submenutextcolor;  //color of the unselected text
extern int submenuselectedcolor;//color of the selected text

//Folder listbox
extern int folderlisttextcolor; //color of unselected text
extern int folderlistselectedcolor;      //color of selected item
extern int folderlistbarcolor; //color of the scrollbar   

//Folder viewer
extern int viewerheaderscolor; //color of the headers
extern int viewerquotedcolor; //color of the quotes
extern int viewertextcolor; //color of the normal text
extern int viewerbarcolor; //color of the scrollbar

//Header modyfing window
extern int hdmodifytextcolor; //color of the window

//Multipart list
extern int multipartlistnormal;
extern int multipartlistbar;
extern int multipartlistselected;

//Threads list
extern int threadlistnormal;
extern int threadlistbar;
extern int threadlistselected;

//file lister colors
extern int filelisttxtcolor;
extern int filelistselectedcolor;
extern int filelistbarcolor;

//button colors
extern int buttoncolor;
extern int buttonselected;

//file attach browser window
extern int fileattachbrowsercolor;

//definitions of various message body text highlighs
extern int underlined;
extern int boldtext;
extern int italictext;
extern int emailhighlighttext;
extern int signaturecolor;

//little windows
extern int gotomessagewindowcolor; //the window available under 'g' in folderviewer
extern int savemessagewindowcolor; //the window for saving the msg to disk

extern int addressbookwindowcolor; //the color of the address book window
extern int addressbookselected;
extern int addressbookbar;

void initcolors();
void ReadColorsFile();
void WriteColorsFile();

#endif    
