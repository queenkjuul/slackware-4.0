/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _THEADERMODIFY_H
#define _THEADERMODIFY_H
#include"TWindow.h"
#include"TInputField.h"
#include"colors.h"
#include"keyboard.h"
#include"misc.h"
#include"TemplateUtility.h"
#include"TFileBox.h"
#include"THeaderMIME.h"
#include"TAddressBook.h"
#include<time.h>
#include<stdlib.h>

class THeaderModify : public TWindow
	{
	char *msgid;
	char *attach;     
	char *fcc;
	char *to;
	char *subj;
	char *cc;
	char *bcc;
	char *replyto;
	char *content_type;
	char *content_transfer_encoding;
	int pos;
	int x,y,x1,y1;
	int aborted;
	
	public:
	
	int IsAborted() {return aborted;}
	void ShowWindow();               
	void Keyboard();
	void WriteHdr();     
	void EncodeHdr(char **hdr);
	THeaderModify(int hx,int hy,int hx1,int hy1,
	char *hto="\0",char *hsubj="\0",
	char *hcc="\0",char *hbcc="\0", 
	char *rplto="\0",
	char *ctype="text/plain; charset=\"ISO-8859-2\"",
	char *ctencoding="Quoted-Printable",
	char *msg_id="\0") :
	TWindow(hx,hy,hx1,hy1,"Header"),
	to(new char[1024]),
	msgid(msg_id),
	subj(new char[1024]),
	cc(new char[1024]),
	fcc(new char[1024]),
	bcc(new char[1024]),
	replyto(rplto),
	x(hx),y(hy),x1(hx1),y1(hy1),
	pos(0),aborted(0),
	content_type(new char[255]),
	content_transfer_encoding(new char[255]),
	attach(new char[1024])
		{
		logfile("THeaderModify::THeaderModify");
		sprintf(content_type,"%s",ctype);
		sprintf(content_transfer_encoding,"%s",ctencoding);
		sprintf(to,"%s",hto);
		sprintf(subj,"%s",hsubj);
		sprintf(cc,"%s",hcc);
		sprintf(bcc,"%s",hbcc);
		sprintf(attach,"\0");
		sprintf(fcc,"\0");
		}                         
	~THeaderModify()
		{
		logfile("THeaderModify::~THeaderModify");   
		delete[] to;
		delete[] subj;
		delete[] cc;
		delete[] fcc;
		delete[] bcc;   
		delete[] content_type;
		delete[] content_transfer_encoding;
		delete[] attach;
		}                              
	};
#endif                                     
