/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/

/*   This class defines one of the most fundamental classes of this program:
     the editor. */

#ifndef _TEDIT_H
#define _TEDIT_H
#include"TView.h"
#include"TInputField.h"
#include"colors.h"
#include"keyboard.h"
#include"misc.h"

class TEdit : public TView {
	char *filename;              //name of the file, you want to edit
	
	char *hlpfile;               //name of the helpfile for this class
	
	int escape;                  //determines, if using of editor was 
	//aborted
	public:
	
	void WriteMsg();             //writes the file to disk
	
	/* bellow: moves the cursor one line down */
	
	void MoveDown()  {if(( filepos+cursory<maxy )&&( cursory<MaxHeight() ))
		cursory++; 
		else if(filepos+cursory<maxy) filepos++; ShowWindow();}
	
	/* bellow: moves the cursor one line up */
	
	void MoveUp()    { if(cursory>0) cursory--; 
		else if(filepos) filepos--; ShowWindow();  }
	
	int CheckEscape() { return escape; } //checks, if the editing was 
	//aborted
	
	void virtual AddChar(char ch);       //Adds a character to the edited 
	//file
	
	void virtual Delete();               //Handles the DEL key
	
	void virtual BackSpace();            //Handles the BACKSPACE key
	
	void virtual ImportFile(char *filename); //Imports a file to currently
	//edited file
	
	TEdit(char *file_name,int x,int y,int x1,int y1,int textcolr=A_NORMAL,int barcolr=A_REVERSE);
	
	void Keyboard();         //Handles the keyboard behaviour
	
	void AddLine();          //Adds a new line to the edited file
	
	void DelLine(int line);  //deletes a line from the edited file
	
	void EnterKey();         //handles the ENTER key
	
	/* bellow: moves the cursor to a specified column of the edited file */
	
	void GotoXPos(int cnt) { cur_col=int(cnt/MaxWidth())*MaxWidth();
		cursorx=cnt-cur_col;}
	
	char virtual *Hlp() {return hlpfile;} //returns the path to the helpfile
	
	~TEdit()
		{
		for(long i=0;i<=maxy;i++)
		delete[] file[i];
		delete[] file;  
		}
	};


#endif                

