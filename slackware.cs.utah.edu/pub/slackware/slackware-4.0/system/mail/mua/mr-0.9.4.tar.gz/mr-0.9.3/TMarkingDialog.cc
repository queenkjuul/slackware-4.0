#include "mr.h"
#include "TMarkingDialog.h" 

void TMarkingDialog::Keyboard()
	{
	menu->Keyboard();
	if(menu->CheckEscape()) return;
	int option=menu->GetElement();
	switch(option)
		{
		case 0: //all messages
		MarkAll();
		break;
		case 1: //lower than current
		InvertDown();
		break;
		case 2: //greater than current
		InvertUp();
		break;
		case 3: //match from
		MarkRegexp();
		break;
		case 4:
		MarkDown();
		break;
		case 5:
		MarkUp();
		break;
		case 6:
		UnmarkDown();
		break;
		case 7:
		UnmarkUp();
		break;
		case 8:
		UnmarkAll();
		break;		  
		}
	}
void TMarkingDialog::InvertAll()
	{
	for(long i=0;i<max_msg;i++)
		{
		if(list[i][5]=='*') list[i][5]=' ';
		else list[i][5]='*';
		}
	}
void TMarkingDialog::MarkAll()
	{
	for(long i=0;i<max_msg;i++)
	list[i][5]='*';
	}
void TMarkingDialog::UnmarkAll()
	{
	for(long i=0;i<max_msg;i++)
	list[i][5]=' ';
	}
void TMarkingDialog::InvertDown()
	{
	for(long i=cur_msg-2;i>=0;i--)
		{
		if(list[i][5]=='*') list[i][5]=' ';
		else list[i][5]='*';
		}
	}
void TMarkingDialog::MarkDown()
	{
	for(long i=cur_msg-2;i>=0;i--)
	list[i][5]='*';
	}
void TMarkingDialog::UnmarkDown()
	{
	for(long i=cur_msg-2;i>=0;i--)
	list[i][5]=' ';
	}
void TMarkingDialog::InvertUp()
	{
	for(long i=cur_msg;i<max_msg;i++)
		{
		if(list[i][5]=='*') list[i][5]=' ';
		else list[i][5]='*';
		}
	}
void TMarkingDialog::MarkUp()
	{
	for(long i=cur_msg;i<max_msg;i++)
	list[i][5]='*';
	}
void TMarkingDialog::UnmarkUp()
	{
	for(long i=cur_msg;i<max_msg;i++)
	list[i][5]=' ';
	}
void TMarkingDialog::MarkRegexp()
	{
	TWindow okno(x1,y1,x2,y1+3,"Mark regexps");
	okno.ShowWindow();
	mvaddstr(y1+1,x1+2,"Enter the regexp (ESC aborts)");
	TInputField theinput(x1+2,y1+2,(x2-x1)-4);
	theinput.GetString();
	if(theinput.CheckEscape()) return;
	re_comp(theinput.ReturnString());
	FILE *id=fopen(filename,"r");
	for(long i=1;i<=max_msg;i++)
		{
		char *buf=new char[endpos[i]-startpos[i]];
		fseek(id,startpos[i],SEEK_SET);
		fread(buf,endpos[i]-startpos[i],1,id);
		if(re_exec(buf)) {if(list[i-1][5]=='*') list[i-1][5]=' ';
			else			list[i-1][5]='*';}
		delete[] buf;
		}
	}

