/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TMSGLIST_H
#define _TMSGLIST_H
#include "TList.h"

class TMsgList : public TList
	{
	int marked;
	
	public:
	
	int CheckMarked()  {return marked;}
	void Keyboard();
	TMsgList(pchar *i, long n, int x,int y,int x1,int y1, int defaultv=0, int textcolr=A_REVERSE,int selectedcolr=A_NORMAL,int barcolr=A_REVERSE):           
	TList(i,n,x,y,x1,y1,defaultv,textcolr,selectedcolr,barcolr),
	marked(0)
		{
		logfile("TMsgList::TMsgList");  
		StatusLine("Up/Dn/PgUp/PgDn:Browse items,Enter:select,Space:mark");
		}
	};
#endif
