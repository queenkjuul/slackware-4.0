/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TVIEWTEXTMSG_H
#define _TVIEWTEXTMSG_H
#include"TView.h"
#include"TMsgList.h"
#include"TMailEdit.h"
#include"THeaderModify.h"
#include"colors.h"
#include"keyboard.h"
#include"misc.h"
#include"sendmsg.h"
#include"TemplateUtility.h"
#include"TBASE64.h"
#include"TForwardFolderList.h"

class TViewTextMsg : public TView {
	long cur_msg;          //aktualnie wyswietlany list
	long max_msg;          //ilosc listow w folderze
	char *from;            //imie i nazwisko z pola from:
	char *to;              //imie i nazwisko z pola to:
	char *subj;            //pole subject:
	char *date;            //pole date:
	char *email;           //adres z from:
	char *toemail;         //adres z to:
	char *defaultto;
	char *defaultcc;
	char *defaultbcc;
	char *replyto;
	char *secondfrom;
	int showheaders;
	int signature;
	int userline;
	long minline;
	pchar *list;
	char *msgid;
	
	void user_mvaddstr(int y,int x,int maxlen,char *str);
	void ShowWindow();      //wyswietlenie okna (virtual)
	void WriteQuotedMsg(int reply);  //zapisanie i zaquotowanie listu  
	int  CheckIfRefillingIsAllowed(char *line1,char *line2);
	void WriteAtoms(int qlen,char *atoms,FILE *id);
	void ConcatenateAtoms(char *&atoms,char *str);
	void SaveMsg(); //zapisanie listu na twardziela
	void ShowHeaders() { if(!getenv("PBMR_SHOWHEADERS")) maxy+=minline; 
		setenv("PBMR_SHOWHEADERS","TRUE",1); SetMinimumLine(0);}
	void HideHeaders() { if(getenv("PBMR_SHOWHEADERS")) maxy-=minline;
		unsetenv("PBMR_SHOWHEADERS"); SetMinimumLine(minline);}
	public:
	
	void Keyboard();   //obsluga klawiatury
	void InsertMessage(int reply);
	TViewTextMsg(pchar *msg,int x,int y,int x1,int y1,
	char *cfrom,char *cto,char *cemail,char *ctoemail,
	char *csubj,char *cdate,
	int cur_msg,int max_msg,int aminline,
	int max_y,
	char *default_to,char *default_cc,char *default_bcc,
	char *reply_to,char *msg_id,char *second_from,pchar *l,
	char *title=" Message ")  : 
	TView(title,x,y,x1,y1,0,viewertextcolor,viewerbarcolor),
	cur_msg(cur_msg),max_msg(max_msg),
	from(cfrom), 
	to(cto),
	msgid(msg_id),
	subj(csubj),
	date(cdate),
	email(cemail),
	toemail(ctoemail),
	defaultto(default_to),
	defaultcc(default_cc),
	defaultbcc(default_bcc),
	replyto(reply_to),
	secondfrom(second_from),
	showheaders(0),
	signature(-1),
	userline(0),
	minline(aminline),
	list(l)
	
		{
		file=msg;   
		list[cur_msg-1][7]='R';
		list[cur_msg-1][8]='O';
		l_act=max_y;
		maxy=max_y;
		char *str=new char[255];
		sprintf(str,"maxy=%d,minline=%d",maxy,minline);
		logfile(str);
		logfile("TViewTextMsg::TViewTextMsg");
		SetMinimumLine(minline);   
		for(int i=maxy+minline;i>0;i--)
		if((strcmp(file[i],"--")==0)||
		(strcmp(file[i],"-- ")==0)) signature=i;
		sprintf(str,"signature=%d",signature);
		logfile(str);
		if(getenv("PBMR_SHOWHEADERS")) 
			{unsetenv("PBMR_SHOWHEADERS"); ShowHeaders();}
		ShowWindow();   
		delete[] str;  
		}
	};
#endif                  
