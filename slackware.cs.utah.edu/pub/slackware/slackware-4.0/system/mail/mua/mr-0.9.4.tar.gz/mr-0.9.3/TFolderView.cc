/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TFolderView.h"

void TFolderView::GotoMessage()
	{
	long n=cur_msg;
	attrset(gotomessagewindowcolor);
	TWindow okienko(15,5,65,8,"Go to a message");
	okienko.ShowWindow();
	mvaddstr(6,17,"Enter the number of the message");
	TInputField msg(17,7,46,"\0");
	msg.GetString();
	if(!msg.CheckEscape())
		{
		n=atol(msg.ReturnString());
		if((n>1)&&(n<=max_msg))
		cur_msg=n;
		}
	GetMessage(n,filename);
	}

void TFolderView::UpdateMailboxStatus()
	{
	char str[50];
	FILE *id;
	if(rc_graph_warez[0]=='y')
		{mvaddstr(y+7,x+7,"Loading file...");refresh();}
	id=fopen(getenv("PBMR_FOLDERNAME"),"r");
	fseek(id,0,SEEK_END);
	long length=ftell(id);
	fseek(id,0,SEEK_SET);
	char *mailbox=new char[length+50];
	fread(mailbox,1,length,id);
	fclose(id);
	id=fopen(getenv("PBMR_FOLDERNAME"),"w");
	for(long i=1;i<=max_msg;i++)
		{
		if(rc_graph_warez[0]=='y')
			{
			if(i&4)
				{
				sprintf(str,"Message %ld...",i);
				mvaddstr(y+7,x+7,str);
				refresh();
				}
			}
		int l;
		if(list[i-1][7]==' ') l=0;
		else if(list[i-1][8]==' ') l=1;
		else l=2;
		if(strncmp(list[i-1]+7,status_hdrs[i-1],l)==0)
			{
			fwrite(mailbox+startpos[i],1,endpos[i]-startpos[i],id);
			}
		else
			{
			for(long j=startpos[i];j<endpos[i];j++)
				{
				if((mailbox[j]=='\n')&&(mailbox[j+1]=='\n'))
					{
					fwrite(mailbox+startpos[i],1,j+1-startpos[i],id);
					if(list[i-1][8]==' ')
					fprintf(id,"Status: %c\n",list[i-1][7]);
					else
					fprintf(id,"Status: %c%c\n",list[i-1][7],list[i-1][8]);
					fwrite(mailbox+j+1,1,endpos[i]-j-1,id);
					break;
					}
				else if(mailbox[j]=='\n')
					{
					int k;
					if(CompareStr(mailbox+j+1,"Status:",7,1))
						{
						fwrite(mailbox+startpos[i],1,j+1-startpos[i],id);
						if(list[i-1][8]==' ')
						fprintf(id,"Status: %c\n",list[i-1][7]);
						else
						fprintf(id,"Status: %c%c\n",list[i-1][7],list[i-1][8]);
						for(k=j+1;k<endpos[i];++k)
						if(mailbox[k]=='\n') {++k; break;}
						fwrite(mailbox+k,1,endpos[i]-k,id);
						break;
						}
					}
				}
			}
		}
	if(endpos[max_msg]<length)
	fwrite(mailbox+endpos[max_msg],length-endpos[max_msg],1,id);
	fclose(id);
	delete[] mailbox;
	}

void TFolderView::SaveLastread()
	{
	logfile("TFolderView::SaveLastread");
	FILE *id;
	char *lastreadname=new char[1024];
	sprintf(lastreadname,"%s/.mr/lastread",getenv("HOME"));
	int len=strlen(lastreadname);
	for(int i=0;i<=strlen(filename);i++)
		{
		if(filename[i]!='/') 	lastreadname[i+len]=filename[i];
		else 			lastreadname[i+len]='.';
		}
	logfile(lastreadname);
	id=fopen(lastreadname,"w");
	fprintf(id,"%s",msgid[cur_msg-1]);
	fclose(id);
	delete[] lastreadname;
	}

void TFolderView::ReadLastread()
	{
	logfile("TFolderView::ReadLastread");
	FILE *id;
	char *lastreadname=new char[1024];
	sprintf(lastreadname,"%s/.mr/lastread",getenv("HOME"));
	int len=strlen(lastreadname);
	for(int i=0;i<=strlen(filename);i++)
		{
		if(filename[i]!='/') 	lastreadname[i+len]=filename[i];
		else 			lastreadname[i+len]='.';
		}
	if((id=fopen(lastreadname,"r"))!=MYNULL)
		{
		fseek(id,0,SEEK_END);
		int len1=ftell(id);
		fseek(id,0,SEEK_SET);
		fread(lastreadname,len1,1,id);
		fclose(id);
		lastreadname[len1]='\0';
		for(int i=0;i<max_msg;i++)
			{
			if(strcmp(lastreadname,msgid[i])==0)
			cur_msg=i+1;
			}
		}
	delete[] lastreadname;
	}

void TFolderView::FindString(char *str)
	{
	long i,j=0,koniec=0,len=strlen(str)-1;
	FILE *id=fopen(filename,"rt");
	char *str2=new char[512];
	for(i=0;i<strlen(str);i++)
		{
		if((str[i]>32)&&(str[i]<126)&&(str[i]!='='))
		str2[j++]=str[i];
		else
			{
			sprintf(str2+j,"=%X",(unsigned char)str[i]);
			j+=3;
			}
		}
	str2[j]=0;
	fseek(id,startpos[cur_msg+1],SEEK_SET);
	for(i=cur_msg+1;i<=max_msg;i++)
		{
		char *buf=new char[endpos[i]-startpos[i]];
		fread(buf,endpos[i]-startpos[i],1,id);
		re_comp(str);
		for(j=0;j<2;j++)
			{
			if(re_exec(buf))
				{
				cur_msg=i;
				koniec=1;
				break;
				}
			re_comp(str2);
			}
		delete[] buf;
		if(koniec) break;
		}
	fclose(id);
	delete[] str2;
	}

void TFolderView::InitializePointers(char *filename,long dpos)                  
	{
	logfile("TFolderView::InitializePointers");     
	char klucz[]="From          ";   // zdefiniowanie klucza poczatku listu
	FILE *id;
	char *from=new char[255],*subj=new char[255],*status=new char[255];
	char *from1=new char[255];
	long length;
	int reallocation=15;
	long i,n1=max_msg,j=dpos;
	if(max_msg==1) n1=0;
	if(rc_graph_warez[0]=='y')
		{mvaddstr(y+7,x+7,"Loading file...");refresh();}
	if((id=fopen(filename,"rt"))!=MYNULL) //otworz plik z folderem
		{
		ExistenceOfTheFolder=1;
		fseek(id,0,SEEK_END);    //zmierz jego dlugosc...
		length=ftell(id);
		fseek(id,0,SEEK_SET);
		if(length>0)
			{
			char *dane_tmp=new char[length+255];  //zarezerwuj na niego pamiec...
			fread(dane_tmp,1,length,id);
			fclose(id);              //i juz mozna go zamknac...
			for(i=0;i<6;i++)    //wyszukiwanie poczatku listu...
				{
				if(klucz[i]!=dane_tmp[j]) i=-1;  //sprawdzanie klucza
				if(i==4) {             //jesli klucz pasuje, to sprawdz
					if(NaprawdeFrom(dane_tmp,j)) //skladnie za nim
						{
						if(rc_graph_warez[0]=='y')
							{
							char str[255];
							sprintf(str,"Message %ld...",n1);
							mvaddstr(y+7,x+7,str);
							refresh();
							}
						n1++,i=0; //zwieksz numer listu...
						if(reallocation>10)
							{
							endpos=(long*)realloc(endpos,sizeof(long)*(n1+15));
							startpos=(long*)realloc(startpos,sizeof(long)*(n1+15));
							inreplyto=(pchar*)realloc(inreplyto,sizeof(pchar)*(n1+15));
							msgid=(pchar*)realloc(msgid,sizeof(pchar)*(n1+15));
							list=(pchar*)realloc(list,sizeof(pchar)*(n1+15));
							status_hdrs=(pchar*)realloc(status_hdrs,sizeof(pchar)*(n1+15));
							reallocation=0;
							}
						else reallocation++;
						startpos[n1]=j-4; 
						endpos[n1-1]=j-4; 
						inreplyto[n1-1]=new char[255];
						msgid[n1-1]=new char[255];
						strcpy(status,"\0");
						strcpy(subj,"\0");
						strcpy(msgid[n1-1],"\0");
						strcpy(inreplyto[n1-1],"\0");
						InitializeList(dane_tmp+j,from,
						subj,status,
						msgid[n1-1],
						inreplyto[n1-1]);
						//zaladuj *from i *subj
						GetEMailFromAddress(msgid[n1-1]);
						GetEMailFromAddress(inreplyto[n1-1]);
						if(!inreplyto[n1-1][0])
						sprintf(inreplyto[n1-1],"%ld",random());
						if(!msgid[n1-1][0])
						sprintf(inreplyto[n1-1],"%ld",random());
						
						list[n1-1]=new char[255];
						status_hdrs[n1-1]=new char[30];
						strcpy(from1,from);
						GetNameFromAddress(from);
						sprintf(list[n1-1],"%ld     ",n1);
						sprintf(list[n1-1]+6,"|%s  ",status);
						from[100]=0;
						from1[100]=0;
						subj[100]=0;
						if(from[0]!='\0')
							{THeaderMIME dequoter(&from);
							dequoter.Decode();
							sprintf(list[n1-1]+9,"|%s                                 ",from);}
						else  
							{sprintf(list[n1-1]+9,"|%s                                         ",from1);}
						THeaderMIME dequoter(&subj);
						dequoter.Decode();
						sprintf(list[n1-1]+36,"| %s                                                ",subj);
						list[n1-1][x1-x]=0;
						if(from[0]!='\0')
							{if(strlen(from)>26)
							strncpy(list[n1-1]+(x1-x),from+26,254-(x1-x));}
						else if(strlen(from1)>26)
						strncpy(list[n1-1]+(x1-x),from1+26,254-(x1-x));
						strcpy(status_hdrs[n1-1],status);
						}
					}   
				if(j==length-1)
					{ endpos[n1]=length; max_msg=n1; break; } //jesli to koniec foldera, to jest to tez endpos       
				j++;
				}
			delete[] dane_tmp;    
			}
		else
		ExistenceOfTheFolder=0,fclose(id);    
		}     
	else
	ExistenceOfTheFolder=0;  
	delete[] from1;
	delete[] from; delete[] subj; delete[] status;   
	}
void  TFolderView::GetMessage(long n, char *filename)
	{
	if(demimer) {delete demimer; demimer=MYNULL;}
	logfile("TFolderView::GetMessage"); 
	char tmpstr[100];        //na tymczasowe komunikaty
	long n1=0,i,n2;             //zmienne pomocnicze
	long j=0;
	FILE *id;                //uchwyt pliku
	int headerend=0;
	int reallocation=0;
	if(lines_active)
	for(i=0;i<lines_active;i++)
	delete[] file[i];
	lines_active=0;
	int pos_in_line=0;
	int qp=0;
	lines_active++;
	file=(pchar*)realloc(file,sizeof(pchar)*(lines_active+5));
	file[0]=new char[30];   //zarezerwuj pamiec  na 1-sza linijke tekstu
	if((id=fopen(filename,"rt"))!=MYNULL) //otworz plik z folderem
		{
		fseek(id,startpos[n],SEEK_SET);
		char *dane_tmp=new char[endpos[n]-startpos[n]+5];
		fread(dane_tmp,endpos[n]-startpos[n],1,id);
		fclose(id);
		n1=0,n2=0;
		for(i=0;i<endpos[n]-startpos[n];i++)  //przepisanie tekstu z ciagu 
			{                    //na linijki
			if((dane_tmp[i]=='\n')&&(dane_tmp[i+1]=='\n')) headerend=1;
			if((dane_tmp[i]=='\n')&&
			((dane_tmp[i+1]==' ')||(dane_tmp[i+1]=='\t'))&&
			(!headerend)) 
				{
				i++;  
				while((dane_tmp[i]==' ')||(dane_tmp[i]=='\t'))
				i++;
				i--;
				}
			else if((dane_tmp[i]=='\n')||((n2>=MaxWidth())&&(headerend)&&(!qp)))
				{file[n1][n2]=0, n1++;
				if(dane_tmp[i]!='\n') i--;
				if(n1>=lines_active)
					{
					if(!qp)
						{
						int len=strlen("Content-Transfer-Encoding: Quoted");
						if(CompareStr(file[n1-1],"Content-Transfer-Encoding: Quoted",len,1))
						qp=1;
						}
					file=(pchar*)realloc(file,sizeof(pchar)*(lines_active+5));
					file[n1]=new char[15];
					lines_active++;
					}
				n2=0;}
			else
				{ 
				if(reallocation>10)		
					{
					/*****************************************************/
					file[n1]=(char*)realloc(file[n1],sizeof(char)*(n2+15));
					/*****************************************************/
					reallocation=0;
					}
				else reallocation++;
				file[n1][n2]=dane_tmp[i],n2++;
				}
			}
		file[n1][n2]=0;            
		logfile("gm10");
		delete[] dane_tmp;
		logfile("gm11");
		}
	else   //jesli nie udalo sie otworzyc pliq
		{
		sprintf(file[0],"Folder file does not exist");
		}  
	
	demimer = new  TMime(&file,x,y,x1,y1,defaultto,defaultcc,
	defaultbcc,replyto,lines_active,
	cur_msg,max_msg,list);
	lines_active=(demimer->ReturnMaxy())+1; 		   
	
	}
int TFolderView::NaprawdeFrom(char *dane,long indeks)
	{
	logfile("TFolderView::NaprawdeFrom");
	char klucz[8]={' ',' ',' ',' ',' ',':',':',' '};    
	int przerwa=1;
	int allOK=0;
	int i=0;
	int alfa=0;
	while((dane[indeks]!='\n')&&(dane[indeks]!=0))
		{
		if((dane[indeks]==klucz[i])&&(przerwa))
		allOK++,przerwa=0,i++;
		else if(dane[indeks]!=klucz[i]) przerwa=1;     
		if((przerwa)&&(allOK>=4))
			{
			if((dane[indeks]<'0')||(dane[indeks]>'9'))
			break;
			}
		indeks++;
		}
	if (allOK==8) return 1;
	else          return 0;
	}

void TFolderView::WriteFromHeader(char *str2, char *str1)
	{   //str1=naglowek, str=fragment zmiennej file
	logfile("TFolderView::WriteFromHeader"); 
	char *tmp=new char[256]; 
	int i=0,j=0;
	while(1)
		{
		if(((str2[i]=='\n')&&((str2[i+1]!='\t')&&(str2[i+1]!=' ')))
		||(str2[i]=='\0')
		||(j>250)) break;
		if((str2[i]!='\n')&&(!((str2[i]==' ')&&(str2[i-1]=='\n')))
		&&((str2[i]!='\t')&&(str2[i-1]!='\n'))) tmp[j++]=str2[i];
		i++;
		}
	tmp[j]='\0';    
	int cnt;
	for(cnt=strlen(tmp);cnt>0;cnt--)
	if(tmp[cnt]!=' ') break;
	tmp[cnt+1]='\0';   
	for(cnt=0;cnt<strlen(tmp);cnt++)
	if(tmp[cnt]!=' ') break;
	for(i=cnt;i<strlen(tmp)+1;i++)
	str1[i-cnt]=tmp[i];
	delete[] tmp;       
	}

void TFolderView::InitializeList(char *point,char *from,char *subj,
char *status, char *msgid, char *inreplyto)
	{
	logfile("TFolderView::InitializeList"); 
	int k=0;
	long i,j;
	for(i=1;(point[k]!='\n')||(point[k+1]!='\n');i++)
		{
		if(point[k-1]=='\n')
		switch(tolower(point[k]))
			{
			case 'f':
			if(CompareStr(point+k,"From:",5,1))
			WriteFromHeader(point+k+5,from); 
			break; 
			case 's':
			if(CompareStr(point+k,"Status:",7,1))
			WriteFromHeader(point+k+7,status); 
			else if(CompareStr(point+k,"Subject:",8,1))
			WriteFromHeader(point+k+8,subj); 
			break; 
			case 'm':
			if(CompareStr(point+k,"Message-ID:",11,1))
			WriteFromHeader(point+k+11,msgid); 
			break; 
			case 'r':
			if(!inreplyto[0])
				{
				int brackets=0;
				if(CompareStr(point+k,"References:",11,1))
					{
					WriteFromHeader(point+k+11,inreplyto); 
					for(int n=0;n<strlen(inreplyto);n++)
					if(inreplyto[n]==',') {inreplyto[n]=0;break;}
					else if((inreplyto[n]=='<')&&(brackets)) {inreplyto[n]=0;break;}
					else if(!brackets) brackets++;
					}
				}
			break; 
			case 'i':
			if(CompareStr(point+k,"In-Reply-To:",12,1))
				{inreplyto[0]=0;WriteFromHeader(point+k+12,inreplyto);}
			break; 
			}
		k++;
		}
	for(i=0;i<strlen(inreplyto);i++)
	if(inreplyto[i]=='>') {inreplyto[i+1]=0; break;}
	}

void TFolderView::ThreadNext()
	{
	logfile("TFolderView::ThreadNext");  
	for(int i=cur_msg;i<=max_msg-1;i++)  
		{
		if((CompareStr(list[i]+38,list[cur_msg-1]+38,
		strlen(list[cur_msg-1]+38),1))||
		(CompareStr(list[i]+38,list[cur_msg-1]+42,
		strlen(list[cur_msg-1]+42),1))||           
		(CompareStr(list[i]+42,list[cur_msg-1]+38,
		strlen(list[cur_msg-1]+38),1)))           
			{
			cur_msg=i+1;
			break;  
			}
		}
	GetMessage(cur_msg,filename);
	}
void TFolderView::ThreadPrev()
	{
	logfile("TFolderView::ThreadPrev");  
	for(int i=cur_msg-2;i>0;i--)  
		{
		if((CompareStr(list[i]+38,list[cur_msg-1]+38,
		strlen(list[cur_msg-1]+38),1))||
		(CompareStr(list[i]+38,list[cur_msg-1]+42,
		strlen(list[cur_msg-1]+42),1))||           
		(CompareStr(list[i]+42,list[cur_msg-1]+38,
		strlen(list[cur_msg-1]+38),1)))           
			{
			cur_msg=i+1;
			break;  
			}
		}
	GetMessage(cur_msg,filename);
	}                  

void TFolderView::Keyboard()
	{
	logfile("TFolderView::Keyboard");   
	int key;
	char *tmpstr=new char[255];
	char *fake[1]={" \0       "};
	do
		{
		if(getenv("PBMR_MESSAGE_MAILED"))
			{InitializePointers(filename,endpos[max_msg]);
			if(threadlist)
				{
				delete threadlist;
				threadlist=new TThreadList(x,y,x1,y1,inreplyto,msgid,TFolderView::list,max_msg,cur_msg,cur_msg-1);
				}
			unsetenv("PBMR_MESSAGE_MAILED");}
		if(!nofoldergetch)
		key=user_getch();
		else
			{key=nofoldergetch; nofoldergetch=0;}   
		ProgramPosition=TFOLDERVIEW;  
		switch(key)
			{
			case 's':  //sign messages
				{
				TMarkingDialog marker(x+5,y+5,x1-5,y1-5,cur_msg,max_msg,list,startpos,endpos,filename);
				marker.Keyboard();
				}
			break;
			case 't':  //threads
				{
				if(!threadlist) threadlist=new TThreadList(x,y,x1,y1,inreplyto,msgid,TFolderView::list,max_msg,cur_msg,cur_msg-1);
				threadlist->SetCurMsg(cur_msg-1);
				threadlist->RunList();
				cur_msg=threadlist->GetElement();
				GetMessage(cur_msg,filename);
				}
			break;
			case 'l':
			RunList();
			break;
			case 'g':
			GotoMessage();
			break;
			case KEY_RIGHT:
			NextMsg();
			break; 
			case KEY_LEFT:
			PrevMsg();
			break;
			case '+':
			ThreadNext();
			break;
			case '-':
			ThreadPrev();
			break;
			case KEY_DC:
			DeleteMsg(cur_msg);
			if(threadlist) { delete threadlist; threadlist=MYNULL; }
			if(max_msg>0)
				GetMessage(cur_msg,filename);
			else
				key=KEY_ESC;
			break;   
			case 'f':
			//           {TForwardFolderList forwardlist(x,y,x1,y1,startpos[cur_msg],endpos[cur_msg]);}
			break;   
			case KEY_IC:
				{TViewTextMsg msg(fake,x,y+6,x1,y1,
				"\0","\0","\0","\0",
				"\0","\0",
				cur_msg,max_msg,0,0,
				defaultto,defaultcc,defaultbcc,
				replyto,"\0","\0",list);
				msg.InsertMessage(NEW);}
			GetMessage(cur_msg,filename);
			break;   
			case KEY_F(10):
			MenuPlay();
			if(!menu_outfromfolderviewer)
			GetMessage(cur_msg,filename);
			break;
			case KEY_F(1):
			sprintf(helpfile,"%s",Hlp());
			Help();
			GetMessage(cur_msg,filename);
			break;    
			case KEY_F(6):  //wyszukiwanie stringu
				{
				TWindow okienko(15,5,65,8,"Find string");
				okienko.ShowWindow();
				mvaddstr(6,17,"Enter the regexp you want to find");
				TInputField msg(17,7,46,findstring);
				msg.GetString();
				if(!msg.CheckEscape())
					{
					if(msg.ReturnString())
						{
						sprintf(findstring,"%s",msg.ReturnString());
						FindString(msg.ReturnString());
						GetMessage(cur_msg,filename);
						}
					}
				}
			break;
			case ' ':
			if(list[cur_msg-1][5]!='*')
			list[cur_msg-1][5]='*';    
			else
			list[cur_msg-1][5]=' ';
			GetMessage(cur_msg,filename);
			break;    
			}
		}
	while(key!=KEY_ESC);
	delete[] tmpstr;     
	}

void TFolderView::DeleteMsg(int number)
	{
	logfile("TFolderView::DeleteMsg");  
	long *spos=new long[max_msg+1];
	long *epos=new long[max_msg+1];
	char *marks=new char[max_msg];
	char *str=new char[255];
	long deleted=0;
	TWindow okienko(5,5,35,10," Delete ");
	okienko.ShowWindow();
	mvaddstr(7,7,"Deletion in progress...");
	refresh();
	for(long i=0;i<max_msg;i++)
	spos[i+1]=startpos[i+1],epos[i+1]=endpos[i+1],marks[i]=list[i][5];
	if(!CheckMarked())
	marks[number-1]='*';  
	FILE *id;
	id=fopen(filename,"rb");  
	fseek(id,0,SEEK_END);
	long length=ftell(id);
	fseek(id,0,SEEK_SET);
	
	char *folder=new char[length];
	fread(folder,1,length,id);
	fclose(id);
	id=fopen(filename,"w");
	long old_max_msg=max_msg;
	for(long j=1;j<=old_max_msg;j++)
		{
		if(marks[j-1]!='*')
		fwrite(&folder[spos[j]],1,epos[j]-spos[j],id); //bez CR przed From
		else
			{    
			long len=epos[j]-spos[j];    //dlugosc skasowanego listu
			delete[] list[j-1-deleted];  //do zaktualizowania wskaznikow
			for(long i=j-deleted;i<max_msg;i++)
				{
				startpos[i]=startpos[i+1]; //przepisanie wskaznikow
				startpos[i]-=len; //zmniejszenie wartosci przesunietych
				endpos[i]=endpos[i+1];  
				endpos[i]-=len;
				list[i-1]=list[i]; //przesuniecie listy
				sprintf(str,"%d",i);
				for(int k=0;k<strlen(str);k++)
				list[i-1][k]=str[k];
				if(strlen(str)<5) list[i-1][strlen(str)]=' ';    
				}
			list[max_msg-1]=MYNULL;
			deleted++;
			if(j<number) cur_msg--;          
			max_msg--;
			}     
		}
	fclose(id);
	delete[] folder;
	delete[] str;
	delete[] spos;
	delete[] epos;
	delete[] marks;
	if((cur_msg>max_msg)&&(max_msg)) cur_msg=max_msg;
	}
void TFolderView::RunList()
	{
	logfile("TFolderView::RunList"); 
		{TMsgList msglist(list,max_msg,x,y,x1,y1,cur_msg-1,folderlisttextcolor,folderlistselectedcolor,folderlistbarcolor); 
		do
			{
			msglist.Keyboard();
			if((!msglist.CheckEscape())&&
			(!msglist.CheckMarked()))
			cur_msg=msglist.GetElement()+1;
			else if(msglist.CheckMarked())
				{char ch;
				if(list[msglist.GetElement()][5]!='*')
				ch='*';
				else   
				ch=' ';
				list[msglist.GetElement()][5]=ch;
				ungetch(KEY_DOWN);}
			}
		while(msglist.CheckMarked());}
	GetMessage(cur_msg,filename);
	}

