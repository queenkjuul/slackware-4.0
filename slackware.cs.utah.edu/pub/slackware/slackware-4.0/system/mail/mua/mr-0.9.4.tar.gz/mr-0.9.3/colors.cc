/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"

//Message editor colors   
int mailedittextcolor; //normal text
int maileditbarcolor;  //scrollbar color
int maileditquotecolor; //quote color

//Menu bar colors
int menubarcolor;       //color of unhighlighted bar
int menubarselectedcolor;     //color of highlighted item

//Submenu colors
int submenutextcolor;  //color of the unselected text
int submenuselectedcolor;//color of the selected text

//Folder listbox
int folderlisttextcolor; //color of unselected text
int folderlistselectedcolor;      //color of selected item
int folderlistbarcolor; //color of the scrollbar   

//Folder viewer
int viewerheaderscolor; //color of the headers
int viewerquotedcolor; //color of the quotes
int viewertextcolor; //color of the normal text
int viewerbarcolor; //color of the scrollbar

//Header modyfing window
int hdmodifytextcolor; //color of the window

//Multipart list
int multipartlistnormal;
int multipartlistbar;
int multipartlistselected;

//Threads list
int threadlistnormal;
int threadlistbar;
int threadlistselected;


//file lister colors
int filelisttxtcolor;
int filelistselectedcolor;
int filelistbarcolor;

//button colors
int buttoncolor;
int buttonselected;

//file attach browser window
int fileattachbrowsercolor;

//colors of message text
int underlined;
int boldtext;
int italictext;
int emailhighlighttext;
int signaturecolor;

//little windows
int gotomessagewindowcolor; //the window available under 'g' in folderviewer
int savemessagewindowcolor; //the window for saving the msg to disk

int addressbookwindowcolor; //the color of the address book window
int addressbookselected;
int addressbookbar;

void initcolors()
	{
	//Message editor colors   
	mailedittextcolor =COLOR_PAIR(1); //normal text
	maileditbarcolor  =COLOR_PAIR(2);  //scrollbar color
	maileditquotecolor=COLOR_PAIR(3); //quote color
	
	//Menu bar colors
	menubarcolor      =COLOR_PAIR(4);       //color of unhighlighted bar
	menubarselectedcolor=COLOR_PAIR(5);     //color of highlighted item
	
	//Submenu colors
	submenutextcolor=COLOR_PAIR(6);  //color of the unselected text
	submenuselectedcolor=COLOR_PAIR(7);//color of the selected text
	
	//Folder listbox
	folderlisttextcolor=COLOR_PAIR(8); //color of unselected text
	folderlistselectedcolor=COLOR_PAIR(9);      //color of selected item
	folderlistbarcolor=COLOR_PAIR(10); //color of the scrollbar   
	
	//Folder viewer
	viewerheaderscolor=COLOR_PAIR(11); //color of the headers
	viewerquotedcolor=COLOR_PAIR(12); //color of the quotes
	viewertextcolor=COLOR_PAIR(13); //color of the normal text
	viewerbarcolor=COLOR_PAIR(14); //color of the scrollbar
	
	//Header modyfing window
	hdmodifytextcolor=COLOR_PAIR(15); //color of the window
	
	//Multipart list
	multipartlistnormal=COLOR_PAIR(16);
	multipartlistbar=COLOR_PAIR(17);
	multipartlistselected=COLOR_PAIR(18);
	
	//file lister colors
	filelisttxtcolor=COLOR_PAIR(19);
	filelistselectedcolor=COLOR_PAIR(20);
	filelistbarcolor=COLOR_PAIR(21);
	
	//button colors
	buttoncolor=COLOR_PAIR(22);
	buttonselected=COLOR_PAIR(23);
	
	//file attach browser window
	fileattachbrowsercolor=COLOR_PAIR(24);
	
	//colors of msg body
	underlined=COLOR_PAIR(25);
	boldtext=COLOR_PAIR(26);
	italictext=COLOR_PAIR(27);
	emailhighlighttext=COLOR_PAIR(28);
	signaturecolor=COLOR_PAIR(29);
	gotomessagewindowcolor=COLOR_PAIR(30);
	savemessagewindowcolor=COLOR_PAIR(31);
	
	//Threads list
	threadlistnormal=COLOR_PAIR(32);
	threadlistbar=COLOR_PAIR(33);
	threadlistselected=COLOR_PAIR(34);
	
	addressbookwindowcolor=COLOR_PAIR(35); //the color of the address book window
	addressbookselected=COLOR_PAIR(36);
	addressbookbar=COLOR_PAIR(37);
	
	if(has_colors())
		{
		init_pair(1,COLOR_WHITE,COLOR_BLUE);
		init_pair(2,COLOR_GREEN,COLOR_RED);
		init_pair(3,COLOR_GREEN,COLOR_BLUE);
		init_pair(4,COLOR_BLACK,COLOR_WHITE);
		init_pair(5,COLOR_RED,COLOR_GREEN);
		init_pair(6,COLOR_BLACK,COLOR_WHITE);
		init_pair(7,COLOR_RED,COLOR_GREEN);
		init_pair(8,COLOR_WHITE,COLOR_BLUE);
		init_pair(9,COLOR_BLACK,COLOR_WHITE);
		init_pair(10,COLOR_YELLOW,COLOR_WHITE);
		init_pair(11,COLOR_WHITE,COLOR_BLUE);
		init_pair(12,COLOR_GREEN,COLOR_BLUE);
		init_pair(13,COLOR_WHITE,COLOR_BLUE);
		init_pair(14,COLOR_YELLOW,COLOR_WHITE);
		init_pair(15,COLOR_GREEN,COLOR_BLUE);
		init_pair(16,COLOR_WHITE,COLOR_BLUE);
		init_pair(17,COLOR_BLACK,COLOR_WHITE);
		init_pair(18,COLOR_YELLOW,COLOR_WHITE);
		init_pair(19,COLOR_BLACK,COLOR_GREEN);
		init_pair(20,COLOR_WHITE,COLOR_BLACK);
		init_pair(21,COLOR_YELLOW,COLOR_WHITE);
		init_pair(22,COLOR_WHITE,COLOR_BLUE);
		init_pair(23,COLOR_YELLOW,COLOR_GREEN);
		init_pair(24,COLOR_CYAN,COLOR_RED);
		init_pair(25,COLOR_RED,COLOR_BLUE);
		
		init_pair(26,COLOR_YELLOW,COLOR_BLUE); //do highlightu
		boldtext|=A_BOLD;
		init_pair(27,COLOR_GREEN,COLOR_BLUE);
		init_pair(28,COLOR_CYAN,COLOR_BLUE);  //---
		
		init_pair(29,COLOR_MAGENTA,COLOR_BLUE);  //---
		init_pair(30,COLOR_BLACK,COLOR_WHITE);
		init_pair(31,COLOR_BLACK,COLOR_WHITE);
		
		init_pair(32,COLOR_WHITE,COLOR_BLUE);
		init_pair(33,COLOR_BLACK,COLOR_WHITE);
		init_pair(34,COLOR_YELLOW,COLOR_WHITE);
		init_pair(35,COLOR_BLACK,COLOR_WHITE);
		init_pair(36,COLOR_BLACK,COLOR_GREEN);
		init_pair(37,COLOR_RED,COLOR_BLUE);
		}
	else
		{
		//Message editor colors   
		mailedittextcolor =A_NORMAL; //normal text
		maileditbarcolor  =A_REVERSE;  //scrollbar color
		maileditquotecolor=A_BOLD; //quote color
		
		//Menu bar colors
		menubarcolor      =A_REVERSE;       //color of unhighlighted bar
		menubarselectedcolor=A_NORMAL;     //color of highlighted item
		
		//Submenu colors
		submenutextcolor=A_REVERSE;  //color of the unselected text
		submenuselectedcolor=A_NORMAL;//color of the selected text
		
		//Folder listbox
		folderlisttextcolor=A_NORMAL; //color of unselected text
		folderlistselectedcolor=A_REVERSE;      //color of selected item
		folderlistbarcolor=A_REVERSE; //color of the scrollbar   
		
		//Folder viewer
		viewerheaderscolor=A_NORMAL; //color of the headers
		viewerquotedcolor=A_BOLD; //color of the quotes
		viewertextcolor=A_NORMAL; //color of the normal text
		viewerbarcolor=A_REVERSE; //color of the scrollbar
		
		//Header modyfing window
		hdmodifytextcolor=A_NORMAL; //color of the window
		
		//Multipart List
		multipartlistnormal=A_NORMAL;
		multipartlistbar=A_REVERSE;
		multipartlistselected=A_REVERSE;
		
		//Threads list
		threadlistnormal=A_NORMAL;
		threadlistbar=A_REVERSE;
		threadlistselected=A_REVERSE;
		
		
		//file list
		filelisttxtcolor=A_NORMAL;
		filelistselectedcolor=A_REVERSE;
		filelistbarcolor=A_NORMAL;
		
		//buttons
		buttoncolor=A_REVERSE;
		buttonselected=A_NORMAL;
		
		//file attach browser window
		fileattachbrowsercolor=A_REVERSE;
		
		underlined=A_UNDERLINE;
		boldtext=A_REVERSE;
		italictext=A_BOLD;
		emailhighlighttext=A_BOLD;
		signaturecolor=A_NORMAL;
		gotomessagewindowcolor=A_REVERSE;
		savemessagewindowcolor=A_REVERSE;
		addressbookwindowcolor=A_REVERSE; //the color of the address book window
		addressbookselected=A_NORMAL;
		addressbookbar=A_NORMAL;
		}        
	
	}


void ReadColorsFile()
	{
	FILE *id;
	int liczba;
	char *str=new char[255];
	sprintf(str,"%s/.mr/colors.cfg",getenv("HOME"));
	if(has_colors())
	if((id=fopen(str,"rt"))!=MYNULL)
		{
		for(int i=1;i<=15;i++)
			{ 
			fscanf(id,"%d",&liczba);
			init_pair(i,liczba/10,liczba-int(liczba/10)*10);
			}
		fclose(id);
		}
	delete[] str;   
	}

void WriteColorsFile()
	{
	short f,b; 
	FILE *id;
	int liczba;
	char *str=new char[255];
	sprintf(str,"%s/.mr/colors.cfg",getenv("HOME"));
	id=fopen(str,"wt");
	for(int i=1;i<=15;i++)
		{
		pair_content(i,&f,&b);  
		fprintf(id,"%d%d\n",f,b);
		}
	fclose(id);   
	delete[] str;      
	}

