#ifndef _TADDRESSBOOK_H
#define _TADDRESSBOOK_H
#include "TWindow.h"
#include "TDelAddList.h"
#include "TButton.h"
#include "TInputField.h"

class TAddressBook : public TWindow {
	int x1,x2,y1,y2;
	pchar *emails;
	pchar *names;
	pchar *idents;
	long itemnum;
	int selected;
	long curitem;
	public:
	void LoadBase();
	void SaveBase();
	void Keyboard();
	void AddItem();
	void EditItem(long item);
	void DeleteItem(long item);
	char *ReturnEmail();
	char *ReturnName();
	TAddressBook(int x_1,int y_1,int x_2,int y_2) : x1(x_1),
	x2(x_2),
	y1(y_1),
	y2(y_2),
	TWindow(x_1,y_1,x_2,y_2,
	"Address Book"),
	emails(new pchar[1]),
	names(new pchar[1]),
	idents(new pchar[1]),
	itemnum(0),
	selected(0),
	curitem(0)
		{
		LoadBase();
		attrset(addressbookwindowcolor);
		ShowWindow();
		}						        
	~TAddressBook()
		{
		for(long i=0;i<itemnum;i++)
			{
			delete[] emails[i];
			delete[] names[i];
			delete[] idents[i];
			}
		delete[] emails;
		delete[] names;
		delete[] idents;
		}		
	};

#endif
