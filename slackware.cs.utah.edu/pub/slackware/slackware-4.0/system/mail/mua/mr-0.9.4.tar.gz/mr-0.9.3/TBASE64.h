/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/

/* This header file defines a class, which decodes and encodes BASE64
   messages */

#ifndef _TBASE64_H
#define _TBASE64_H
#include"misc.h"

typedef unsigned char *upchar;

class TBASE64 {
	upchar *file;         //A reference to a string given externally,
	//which covers the decoded form of data
	
	ppchar *message;      //a reference to an array of strings, which
	//hold the encoded form of message (one 
	//string is one line)
	
	char *alphabet;       //an array, containign the BASE64 alphabet
	
	long *maxy,minline;   //number of lines in encoded data, and
	//position, where msg headers ends (minline)
	
	long *filelen;	 //length of the unencoded data
	public:
	
	void Decode();        //Decodes the encoded data
	void Encode();	 //Encodes the unencoded data
	
	TBASE64(upchar *file64,ppchar *amessage,long *max_y,long min_line, 
	long *file_len) :
	file(file64),maxy(max_y),minline(min_line),filelen(file_len),
	alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	"abcdefghijklmnopqrstuvwxyz"
	"0123456789+/="),
	message(amessage)         
		{
		logfile("TBASE64::TBASE64");  
		}
	};
#endif
