/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TFOLDERVIEW_H
#define _TFOLDERVIEW_H
#include<regex.h>
#include"TView.h"
#include"TMsgList.h"
#include"TMailEdit.h"
#include"THeaderModify.h"
#include"colors.h"
#include"keyboard.h"
#include"misc.h"
#include "TMime.h"
#include "TForwardFolderList.h"
#include "THeaderMIME.h"
#include "TThreadList.h"
#include "TMarkingDialog.h"

class TFolderView {
	pchar *file;
	TMime *demimer;
	TThreadList *threadlist;
	int x,y,x1,y1;
	long lines_active;     //liczba zaalokowanych linijek zmienej file
	long cur_msg;          //aktualnie wyswietlany list
	long max_msg;          //ilosc listow w folderze
	pchar *status_hdrs;
	char *filename;        //nazwa foldera
	char *hlpfile;         //nazwa pliq z helpem
	long *startpos;        //wskazniki poczatkow i koncow listow
	long *endpos;          //w mailboxie
	int NaprawdeFrom(char *dane,long indeks); //czy poczatek listu?
	char *defaultto;       //defaultowe pola dla wprowadzanych
	char *defaultcc;       //listow
	char *defaultbcc;
	char *replyto;
	char *findstring;
	pchar *msgid; 
	pchar *inreplyto;
	pchar *list;       //lista subjectow (pod klawiszem 'l')
	int ExistenceOfTheFolder;  //czy istnieje plik z folderem?!
	void SortMessages();
	void UpdateMailboxStatus();
	void WriteFromHeader(char *str,char *str1); //wyciagnij zawartosc
	//z naglowka
	void InitializeList(char *point,char *from,
	char *subj,char *status,
	char *msgid,char *inreplyto);  
	//inicjalizuj liste subjectow
	void DeleteMsg(int number);          //kasuje list
	void GotoMessage();     //idzie do listu wybranego tu przez juzera
	int CheckMarked()    { for(long i=0;i<max_msg;i++)
		if(list[i][5]=='*') return 1; return 0;}    
	void InitializePointers(char *filename,long dpos=0); //inicjalizacja wskaznikow
	//poczatkow i koncow listow
	//w folderze
	void GetMessage(long n,char *filename);  //pobranie danego listu    
	void ThreadNext();            // nastepny list o tym samym temacie
	void ThreadPrev();            // poprzedni ---------//--------
	void NextMsg() {if(cur_msg<max_msg) cur_msg++; 
		GetMessage(cur_msg,filename);}
	void PrevMsg() {if((cur_msg>1)) cur_msg--; 
		GetMessage(cur_msg,filename);}
	void RunList();
	char virtual *Hlp() { return hlpfile;}
	int MaxWidth() { return x1-x-2; }
	void FindString(char *str);
	void SaveLastread();
	void ReadLastread();
	public:
	
	void Keyboard();   //obsluga klawiatury
	TFolderView(char *folder,int xx,int yy,int xx1,int yy1,
	char *dfltto="\0",char *dfltcc="\0", 
	char *dfltbcc="\0",char *rplto="\0")  : 
	lines_active(0),
	filename(folder),
	startpos(new long[1]),
	endpos(new long[1]),
	cur_msg(1),max_msg(1),
	list(new pchar[1]),
	msgid(new pchar[1]),
	inreplyto(new pchar[1]),
	ExistenceOfTheFolder(0),
	defaultto(dfltto),
	defaultcc(dfltcc),
	defaultbcc(dfltbcc),
	hlpfile("folderview.hlp"),
	replyto(rplto),
	file(new pchar[1]),
	status_hdrs(new pchar[1]),
	x(xx),y(yy),x1(xx1),y1(yy1),
	demimer(MYNULL),
	threadlist(MYNULL),
	findstring(new char[256])
	
		{
		logfile("TFolderView::TFolderView");   
		findstring[0]=0;
		if(getenv("PBMR_MESSAGE_MAILED"))
		unsetenv("PBMR_MESSAGE_MAILED");
		if(setenv("PBMR_FOLDERNAME",folder,1)==-1) exit(1);
			{
			attrset(viewertextcolor);
			TWindow okno(x+5,y+5,x+40,y+8,"\0");
			okno.ShowWindow();
			mvaddstr(y+6,x+7,"Wait: Initializing pointers...");
			refresh();
			InitializePointers(folder);   
			}
		if((ExistenceOfTheFolder)&&(max_msg>0))
			{
			ReadLastread();
			GetMessage(cur_msg,folder);
			Keyboard();
			}
		}
	~TFolderView()
		{
		logfile("TFolderView::~TFolderView");
		
		if(ExistenceOfTheFolder)
			{SaveLastread();
			TWindow okno(x+5,y+5,x+40,y+8,"\0");
			okno.ShowWindow();
			mvaddstr(y+6,x+7,"Wait: Updating mailbox status...");
			refresh();
			UpdateMailboxStatus();}
		unsetenv("PBMR_FOLDERNAME");
		if(demimer) delete demimer;
		if(ExistenceOfTheFolder)
			{for(int i=0;i<max_msg;i++)
				{delete[] list[i]; delete[] msgid[i]; inreplyto[i];
				delete[] status_hdrs[i];}
			for(int i=0;i<lines_active;i++)
			delete[] file[i];
			delete[] file;}
		delete[] status_hdrs;
		delete[] list;
		delete[] msgid;
		delete[] inreplyto;
		delete[] startpos;
		delete[] endpos;
		if(threadlist) delete threadlist;
		delete[] findstring;
		}         
	
	};

#endif                  
