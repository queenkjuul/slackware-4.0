/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TBASE64.h"
void TBASE64::Encode()
	{
	long n1=0,n2=0;
	for(long i=0;i<(*filelen);i+=3,n2+=4)  //przepisanie tekstu z ciagu 
		{                    //na linijki
		if(n2>=76)
			{
			(*message)[n1][n2]=0;
			n1++;
			(*message)=(pchar*)realloc((*message),sizeof(pchar)*(n1+2));
			(*message)[n1]=new char[255];
			n2=0;
			}
		if(n2<76)
			{ 
			(*message)[n1]=(char*)realloc((*message)[n1],sizeof(char)*(n2+5));
			(*message)[n1][n2]=alphabet[(*file)[i]>>2];
			if(i+2<(*filelen))
				{
				(*message)[n1][n2+1]=alphabet[(int)((((*file)[i]<<4)&63) | ((*file)[i+1]>>4))];
				(*message)[n1][n2+2]=alphabet[(int)((((*file)[i+1]<<2)) & 63) | ((*file)[i+2]>>6)];
				(*message)[n1][n2+3]=alphabet[(int)((*file)[i+2] & 63)]; 
				}
			else if(i+1<(*filelen))
				{
				(*message)[n1][n2+1]=alphabet[(int)((((*file)[i]<<4)&63) | ((*file)[i+1]>>4))];
				(*message)[n1][n2+2]=alphabet[(int)(((*file)[i+1]<<2) & 63)];
				(*message)[n1][n2+3]='=';
				}       
			else
				{
				(*message)[n1][n2+1]=alphabet[(int)(((*file)[i]<<4) & 63)]; 
				(*message)[n1][n2+3]=(*message)[n1][n2+2]='=';
				}
			}
		}
	(*message)[n1][n2]=0;            
	(*maxy)=n1;
	}              
void TBASE64::Decode()
	{
	unsigned char quartet[4];
	int q=0;
	char i;
	for(long y=minline;y<=(*maxy)+minline;y++)
	for(long x=0;x<strlen((*message)[y]);x++)
		{
		for(i=0;i<65;i++) if((*message)[y][x]==alphabet[i]) 
			{quartet[q]=i; q++; break;}
		if(q==4) 
			{
			q=0;
			(*file)=(unsigned char*)realloc((*file),(*filelen)+10);
			(*file)[(*filelen)]=char((quartet[0]<<2)|(quartet[1]>>4));
			(*filelen)++;
			if(quartet[2]!=64)
				{(*file)[(*filelen)]=char((quartet[1]<<4)|(quartet[2]>>2));
				(*filelen)++;}
			if(quartet[3]!=64)
				{(*file)[(*filelen)]=char((quartet[2]<<6)|(quartet[3]));
				(*filelen)++;}
			}
		}
	}              

