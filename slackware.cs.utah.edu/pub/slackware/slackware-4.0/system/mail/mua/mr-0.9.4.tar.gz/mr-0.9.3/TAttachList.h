/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/

/* This header file defines a class named TAttachList. This is the class, 
   which object can you see, when browsing files for attach. It is the 
   listbox, where you store your choosen files */

#ifndef _TATTACHLIST_H
#define _TATTACHLIST_H

#include "misc.h"
#include "TWindow.h"
#include "TDelAddList.h"

class TAttachList : public TWindow {
	pchar *list;           //a list of files choosen for attach
	
	int tab,escape;        //what key was the last, when leaving
	//the TAttachList object
	
	long itemcount,current;//currently highlighted item, and the
	//item count
	public:
	
	void InitData();              //initialize list of items
	
	void SetEnvForAttach();       //set the env. variable - the 
	//attached files are passed
	//to external classes as env.
	//variable - PBMR_ATTACH
	
	void AddItem(char *item);	    //Adds an item to the list
	
	void DelItem(int item);       //Deletes an item from the list
	
	int CheckTab() { return tab; } //Checks, if user has pressed
	//the tab key when working
	//with the list
	
	int CheckEscape() {return escape;} //Same as above, but checks
	//escape key
	
	void Keyboard();		     //This function does all
	//things related with keyboard,
	//when using this listbox
	
	void ShowWindow();	     //Paints the object on the screen
	
	TAttachList(int x1,int y1,int x2,int y2)  :
	TWindow(x1,y1,x2,y2,"Choosen list"),
	tab(0),escape(0),list(new pchar[1]),
	itemcount(0),current(0)
	
		{
		if(getenv("PBMR_ATTACH")) InitData();
		}
	};
#endif


