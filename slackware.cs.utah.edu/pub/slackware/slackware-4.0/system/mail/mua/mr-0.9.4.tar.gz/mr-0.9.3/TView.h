/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/

#ifndef _TVIEW_H
#define _TVIEW_H

#include"TWindow.h"
#include"colors.h"
#include"keyboard.h"
#include"misc.h"

class TFolderView; 

class TView : public TWindow {
	friend class TFolderView;
	char *title;                 //tytul okna
	protected:
	int winx1,winy1,winx2,winy2; //rozmiary okna (by wiedziec, ile tekstu
	//wyswietlic
	int yt;
	int minimum_line;
	public:
	long l_act;                 //ilosc aktywnych linii
	long maxx,maxy;
	int cur_col;                 //bierzaca pierwsza z lewej kolumna                                     
	int cursorx,cursory;         //wspolrzedne kursora
	pchar *file;                 //zawartosc pliku tekstowego w linijkach
	long filepos;                //pozycja w pliq
	int textcolor,barcolor;
	
	void ShowWindow();           //wyswietlenie pliku w aktualnej pozycji w 
	//edycji
	int MaxWidth() { return winx2-winx1-2; }
	int MaxHeight(){ return winy2-winy1-2; }
	TView(char *title1, int x,int y,int x1,int y1,int yt=0,int textcolr=A_NORMAL,int barcolr=A_REVERSE) : 
	cursorx(0),cursory(0), textcolor(textcolr),
	barcolor(barcolr),
	winx1(x),winy1(y+yt),winx2(x1),winy2(y1),
	title(title1), cur_col(0),
	TWindow(x,y,x1,y1,title1),
	filepos(0), file(MYNULL),yt(yt),
	minimum_line(0),l_act(0),maxx(0),maxy(0)
		{
		logfile("TView::TView");    
		TWindow::ShowWindow();    //namalowanie okna
		}
	~TView()
		{
		//           for(int i=0;i<l_act;i++)
		//              delete[] file[i];
		//           delete[] file;   
		}
	void setcorners(int x,int y,int x1,int y1) {winx1=x,winx2=x1,winy1=y,winy2=y1;}      
	void MoveLeft()  { if(cursorx>0) cursorx--; 
		else if(cur_col>0) cur_col--; ShowWindow(); }                     
	void MoveRight() { if(cursorx<MaxWidth()) cursorx++; 
		else cur_col++; ShowWindow(); }
	void MoveDown()  { if(filepos+MaxHeight()<maxy) cursory=MaxHeight(); 
		if(filepos+cursory<maxy) filepos++; ShowWindow();}
	void MoveUp()    { cursory=0; 
		if(filepos) filepos--; ShowWindow();  }
	void PgUp()      { if(filepos>MaxHeight()) filepos-=MaxHeight();
		else filepos=0; ShowWindow(); }
	void PgDn()      { if(filepos+MaxHeight()<maxy) filepos+=MaxHeight();
		else filepos=maxy-MaxHeight(); ShowWindow(); }                                      
	void SetMinimumLine(int line) {minimum_line=line;}
	int GetMinimumLine() {return minimum_line;}
	int GetWinX1() { return winx1; }
	int GetWinX2() { return winx2; }
	int GetWinY1() { return winy1-yt; }
	int GetWinY2() { return winy2; }
	};
#endif
