/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TSendMultipart.h"

void TSendMultipart::SendMultipart()
	{
	FILE *in,*out;
	char *str=new char[4096], *p=new char[255];
	long len;
	int last=0;
	sprintf(str,"%s/.mr/mailfile.%ld.tmp",getenv("HOME"),(long)getpid());
	in=fopen(str,"rt");
	sprintf(str,"%s/.mr/mailhdr.%ld.tmp",getenv("HOME"),(long)getpid());
	out=fopen(str,"a");
	fprintf(out,"--%s\nContent-Type: Text/plain; charset=\"%s\"\nContent-Transfer-Encoding: Quoted-Printable\n\n",getenv("PBMR_BOUNDARY"),rc_charset);
	fseek(in,0,SEEK_END);
	len=ftell(in);
	fseek(in,0,SEEK_SET);
	char *buf=new char[len+5];
	fread(buf,len,1,in);
	fwrite(buf,len,1,out);
	fprintf(out,"\n");
	fclose(in);
	sprintf(str,"%s",getenv("PBMR_ATTACH"));
	len=strlen(str);
	while(last<len)
		{
		strcpy(p,"\0");  
		for(int i=last;((i<len)&&(str[i]!=' '));i++,last++)
		strncat(p,&str[i],1);
		AddFile(out,p);    
		while(str[last]==' ') last++;
		}
	fprintf(out,"--%s--\n",getenv("PBMR_BOUNDARY"));
	fclose(out);
	delete[] str;
	delete[] p;
	}

void TSendMultipart::AddFile(FILE *id, char *filename)
	{
	char *name=new char[255],*p;
	int i=0,contentset=0;
	for(i=strlen(filename);i>=0;i--) if(filename[i]=='/') { i++; break; }
	sprintf(name,"%s",filename+i);
	fprintf(id,"--%s\n",getenv("PBMR_BOUNDARY"));
	for(p=name+strlen(name);((*p)!='.')&&(p>name);p--);
	for(i=0;i<NUMBER_OF_IMAGE_TYPES;i++)
	if(strcmp(image_types[i],p)==0)
	fprintf(id,"Content-Type: %s; name=\"%s\"\n",
	image_content_types[i],name),contentset=1;
	
	for(i=0;i<NUMBER_OF_AUDIO_TYPES;i++)
	if(strcmp(audio_types[i],p)==0)
	fprintf(id,"Content-Type: %s; name=\"%s\"\n",
	audio_content_types[i],name),contentset=1;
	
	for(i=0;i<NUMBER_OF_VIDEO_TYPES;i++)
	if(strcmp(video_types[i],p)==0)
	fprintf(id,"Content-Type: %s; name=\"%s\"\n",
	video_content_types[i],name),contentset=1;
	
	for(i=0;i<NUMBER_OF_TEXT_TYPES;i++)
	if(strcmp(text_types[i],p)==0)
	fprintf(id,"Content-Type: %s; name=\"%s\"\n",
	text_content_types[i],name),contentset=1;
	
	if(!contentset)
	fprintf(id,"Content-Type: Application/octet-stream; name=\"%s\"\n",name);
	
	fprintf(id,"Content-Transfer-Encoding: BASE64\n\n");
	FILE *in;
	in=fopen(filename,"rb");
	fseek(in,0,SEEK_END);
	long len=ftell(in);
	fseek(in,0,SEEK_SET);
	unsigned char *buf=new unsigned char[len+100];
	fread(buf,len,1,in);
	fclose(in);
	pchar *tmp=new pchar[1];
	tmp[0]=new char[255];
	long maxy=0;
	TBASE64 b64(&buf,&tmp,&maxy,0,&len);
	b64.Encode();
	for(long j=0;j<=maxy;j++)
		{
		fprintf(id,"%s\n",tmp[j]);
		delete[] tmp[j];
		}
	delete[] tmp; 
	delete[] buf; 
	delete[] name;
	}


