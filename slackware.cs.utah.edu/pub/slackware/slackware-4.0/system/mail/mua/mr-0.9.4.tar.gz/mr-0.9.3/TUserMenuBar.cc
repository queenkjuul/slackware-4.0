/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TUserMenuBar.h"

#define CNUMBER 31

char *coloritems[31]={"Msg editor text         " ,
	"Msg editor quoted       " ,
	"Msg editor scrollbar    ",
	"Menubar color           ",
	"Menubar selected        ",
	"Submenu color           ",
	"Submenu selected        ",
	"Folder listbox text     ",
	"Folder listbox selected ",
	"Folder listbox scrollbar",
	"Folderview header       ",
	"Folderview quotes       ",
	"Folderview text         ",
	"Folderview scrollbar    ",
	"Hdr modify window color ",
	"Multipart list text     ",
	"Multipart list scrollbar",
	"Multipart list selected ", //---
	"File list color         ",
	"File list selected      ",
	"File list scrollbar     ",
	"Button color            ",
	"Button selected         ",
	"Fileattach window color ",
	"View msg: underlined _u_",
	"View msg: bold       *b*",
	"View msg: italic     /i/",
	"View msg: email  abc@xyz",
	"View msg: signature     ",
	"Go to message window    ",
	"Save message to disk win"};


void TUserMenuBar::UngetchKeys()
	{
	logfile("TUserMenuBar::UngetchKeys");
	char *str=new char[255]; 
	int x,y;
	menu_outfromfolderviewer=0;
	getmaxyx(stdscr,y,x); 
	int val=Keyboard();
	if(val==EXIT)
		{endwin();
		exit(1);}
	else if(val==ABOUT)
		{char *str=new char[255];
		sprintf(str,"%s/about.mr",GetHelpPath());
		TFileView about(str,15,4,x-15,y-4);     
		about.Keyboard();
		delete[] str;}
	else if(val==FOLDERLIST)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch(KEY_ESC);
		ungetch(KEY_ESC);}
	else if(val==ENTERMSG)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch(KEY_IC);}
	else if(val==REPLYMSG)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch('q');}
	else if(val==MSGLIST)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch('l');}
	else if(val==MSGNEXT)
		{if(ProgramPosition==TFOLDERVIEW)
		ungetch('+');}
	else if(val==MSGPREV)
		{if(ProgramPosition==TFOLDERVIEW)
		ungetch('-');}
	else if(val==COMMENTMSG)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch('c');}
	else if(val==SAVEMSG)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch('w');}
	else if(val==VIEWHEADERS)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch('v');}
	else if(val==FORWARDMSG)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch('f');}
	else if(val==FINDSTRING)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch(KEY_F(6));}
	else if(val==GOTOMESSAGE)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch('g');}
	else if(val==MARKMESSAGE)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch('s');}
	else if(val==DELETEMESSAGE)
		{if(ProgramPosition==TFOLDERVIEW)
		menu_outfromfolderviewer=1;
		ungetch(KEY_DC);}
	else if(val==ABORTWRITING)
		{if(ProgramPosition==TEDIT)
		ungetch(KEY_ESC);
		ungetch(KEY_ESC);}
	else if(val==SENDMSG)
		{if(ProgramPosition==TEDIT)
		ungetch(KEY_F(2));}
	else if(val==CHANGECOLORS)
		{
		int f,b;
		TList lista(coloritems,CNUMBER,15,4,x-15,y-4);
		lista.Keyboard();
		if(!lista.CheckEscape())
			{
			TWindow okienko(15,4,40,15," Colors ");
			okienko.ShowWindow();
			mvaddstr(5,16,"  0 - BLACK   1   -   RED");
			mvaddstr(6,16,"  2 - GREEN   3  - YELLOW");
			mvaddstr(7,16,"  4  - BLUE   5 - MAGENTA");
			mvaddstr(8,16,"  6  - CYAN   7  -  WHITE");
			mvaddstr(9,16, " Enter two digits - one");
			mvaddstr(10,16,"for the foreground, and");
			mvaddstr(11,16,"the other for background");
			TInputField atrs(17,14,22,"07");
			atrs.GetString();
			f=atoi(atrs.ReturnString())/10;
			b=atoi(atrs.ReturnString())-f*10;
			init_pair(lista.GetElement()+1,f,b);
			}
		}  
	else if(val==SAVECOLORS)
	WriteColorsFile();
	else if(val==ADDRESSBOOK)
		{
		int x1,y1;
		getmaxyx(stdscr,y1,x1);
		TAddressBook book(2,2,x1-3,y1-3);
		book.Keyboard();
		}
	else if(val==CHREPLYTPL)
		{
		sprintf(str,"%s/.mr/reply.tpl",getenv("HOME"));
		TTplEdit edycja(str,15,5,x-15,y-5);
		edycja.Keyboard();
		if(!edycja.CheckEscape())
		edycja.WriteMsg();
		}  
	else if(val==CHCOMMENTTPL)
		{
		sprintf(str,"%s/.mr/comment.tpl",getenv("HOME"));
		TTplEdit edycja(str,15,5,x-15,y-5);
		edycja.Keyboard();
		if(!edycja.CheckEscape())
		edycja.WriteMsg();
		}  
	else if(val==CHNEWTPL)
		{
		sprintf(str,"%s/.mr/new.tpl",getenv("HOME"));
		TTplEdit edycja(str,15,5,x-15,y-5);
		edycja.Keyboard();
		if(!edycja.CheckEscape())
		edycja.WriteMsg();
		}  
	else if(val==CHSIGNATURETPL)
		{
		sprintf(str,"%s/.mr/signature.tpl",getenv("HOME"));
		TTplEdit edycja(str,15,5,x-15,y-5);
		edycja.Keyboard();
		if(!edycja.CheckEscape())
		edycja.WriteMsg();
		}  
	ShowBar();       
	delete[] str;
	}


