/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TButton.h"

void TButton::ShowWindow()
	{
	if(selected) attrset(buttonselected);
	else         attrset(buttoncolor);
	mvaddstr(winy1,winx1,buttonname);        
	}    

void TButton::Keyboard()
	{
	int key=0;
	tab=0,escape=0,selected=1;
	ShowWindow();
	do
		{
		key=getch(); 
		}
	while((key!=KEY_ESC)&&(key!='\t')&&(key!='\n'));
	if(key=='\t') tab=1;
	else if(key!='\n') escape=1;
	selected=0;
	ShowWindow();           
	}

