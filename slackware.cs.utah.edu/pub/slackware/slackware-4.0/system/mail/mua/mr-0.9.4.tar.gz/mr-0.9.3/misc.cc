/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include <pwd.h>

int nofoldergetch;
int menu_outfromfolderviewer;
int logging=0;
int ProgramPosition;
char helpfile[255];

int user_getch()
	{
	int a=getch();
	int escape=0;
	if(a==KEY_ESC)
	escape=1;
	if(!escape) return a;
	else a=getch();
	if((a>'0')&&(a<='9')) return KEY_F((a-'0'));
	else if(a=='0') return KEY_F(10);
	else if(a==KEY_ESC) return KEY_ESC;
	return a; 
	}

void logfile(char *msg)
	{
	if(logging)
		{  
		FILE *id=fopen("./logfile","a");
		if(id!=MYNULL)
			{
			fprintf(id,"%s\n",msg);
			fclose(id);
			}
		}
	}


void StatusLine(char *str)
	{
	logfile("misc.h::StatusLine");
	int x,y;
	attrset(A_REVERSE);
	getmaxyx(stdscr,y,x);
	for(int i=0;i<x;i++)
	mvaddch(y-1,i,' ');
	mvaddstr(y-1,0,str);
	}

int ReadItem(FILE *id,char *str)
	{
	logfile("misc.h::ReadItem"); 
	int i=0;
	int quote=0;
	int spaceerror=0;
	int special=0;
	while(1)
		{
		fread(&str[i],1,1,id);
		if((str[i]=='#')&&(!special)&&(!quote)) {while(str[i]!='\n') fread(&str[i],1,1,id);}
		if((str[i]=='\\')&&(!special)) special=1;
		else if((str[i]=='"')&&(!special)) {quote^=1; if(quote==0) {str[i]='\0'; break;}}
		else if((str[i]=='\n')&&(i>0)&&(!quote)) {str[i]='\0'; break;}
		else if(((str[i]!=' ')&&(str[i]!='\n'))||(quote)) 
			{i++; if(!quote) spaceerror=1; special=0;}
		else if(spaceerror) {str[i]='\0'; break;}
		
		if(feof(id)){str[i]='\0'; break;}
		}
	return 1;  
	}

int CompareStr(const char *st1,const char *st2,int mincmp,int lowerletters)
	{
	logfile("misc.h::CompareStr");  
	char *s1=new char[1024];
	char *s2=new char[1024];
	if(mincmp>1020) mincmp=1020;
	strncpy(s1,st1,mincmp+1);
	strncpy(s2,st2,mincmp+1);
	if(lowerletters)
		{
		for(int i=0;i<=mincmp;i++)  
			{s1[i]=tolower(s1[i]);
			s2[i]=tolower(s2[i]);}
		}
	int ok=strncmp(s1,s2,mincmp);
	delete[] s1;
	delete[] s2;
	return !ok;
	}

char *GetHelpPath()
	{
	logfile("misc.h::GetHelpPath");  
	char *str=DHELPDIR;
	if(getenv("MRPATH")!=MYNULL) return getenv("MRPATH");
	else return str;
	}

void GetNameFromAddress(char *addr)
	{
	logfile("misc.h::GetNameFromAddress");  
	char *tmp=new char[strlen(addr)+50];
	int i,flag=1,cnt=0,name=0;
	for(i=0;i<strlen(addr);i++)
	if((addr[i]=='(')||(addr[i]=='<')||(addr[i]=='"'))
	name=1;
	if(name)     
	for(i=0;i<strlen(addr);i++)
		{
		if(addr[i]=='<')  flag=0;
		if(addr[i]=='>')  flag=1;
		if(addr[i]=='(') { cnt=0; }
		if((flag)&&(addr[i]!='"')&&(addr[i]!='>')
		&&(addr[i]!='(')&&(addr[i]!=')'))
		tmp[cnt++]=addr[i];
		}  
	tmp[cnt]=0;
	for(cnt=strlen(tmp)-1;cnt>0;cnt--)
	if(tmp[cnt]!=' ') break;
	tmp[cnt+1]='\0';   
	for(cnt=0;cnt<strlen(tmp);cnt++)
	if(tmp[cnt]!=' ') break;
	for(i=cnt;i<strlen(tmp)+1;i++)
	addr[i-cnt]=tmp[i];       
	delete[] tmp;
	}

void GetEMailFromAddress(char *addr)
	{
	logfile("misc.h::GetEmailFromAddress");  
	char *tmp=new char[strlen(addr)+50];
	int i,flag=1,cnt=0;
	for(i=0;i<strlen(addr);i++)
		{
		if(addr[i]=='<')  cnt=0,flag=1;
		if(addr[i]=='>')  flag=0;
		if(addr[i]=='(')  flag=0; 
		if(addr[i]==')')  flag=1;
		if((flag)&&(addr[i]!='"')&&(addr[i]!=')')
		&&(addr[i]!='<')&&(addr[i]!='>'))
		tmp[cnt++]=addr[i];
		}  
	tmp[cnt]=0;
	for(cnt=strlen(tmp)-1;cnt>0;cnt--)
	if(tmp[cnt]!=' ') break;
	tmp[cnt+1]='\0';   
	for(cnt=0;cnt<strlen(tmp);cnt++)
	if(tmp[cnt]!=' ') break;
	for(i=cnt;i<strlen(tmp)+1;i++)
	addr[i-cnt]=tmp[i];       
	delete[] tmp;
	}

void LoadUsername(char *login)
	{
	FILE *id;
	id=fopen("/etc/passwd","r");
	passwd *Passwd=getpwnam(login);
	setenv("PBMR_FULLUSERNAME",Passwd->pw_gecos,1);
	fclose(id);
/*	fseek(id,0,SEEK_END);
	long length=ftell(id);
	fseek(id,0,SEEK_SET);	
	char *buf=new char[length+10];
	char *temp=new char[255];
	fread(buf,1,length,id);
	fclose(id);
	for(int i=0;i<length;i++)
		{
		int a=0;
		if(i>0)a=1;
		if((buf[i]=='\n')||(i==0))
			{
			int colon=0;
			if(strncmp(login,buf+i+a,strlen(login))==0)
				{
				for(int j=i;j<length;j++)
					{
					if(buf[j]==':') colon++;
					if(colon==4)
						{
						int k;
						for(k=j+1;(k<length)&&(buf[k]!=':');k++)
						temp[k-j-1]=buf[k];
						temp[k-j-1]=0;
						setenv("PBMR_FULLUSERNAME",temp,1);
						break;
						}
					}
				}
			}
		}
	delete[] temp;
	delete[] buf;
*/	}       

