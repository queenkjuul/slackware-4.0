/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _MISC_H
#define _MISC_H
#include <ctype.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

typedef char *pchar;
typedef pchar *ppchar;
extern int nofoldergetch;
extern int menu_outfromfolderviewer;
extern int logging;

#define FOLDER 0
#define PATH 1
#define DTO 2
#define DCC 3
#define DBCC 4
#define REPLYTO 5
#define CHARSET 6
#define FORWARDBANNER 7
#define GRAPHWAREZ 8
#define FILEIMPORTBANNER 9
#define ALTERNATEEDITOR 10
#define SORTING 11

#define REPLY 0
#define COMMENT 1
#define NEW 2
#define FORWARD 3
#define SIGNATURE 4

#define TFOLDERLIST 0
#define TFOLDERVIEW 1
#define TEDIT 2
#define TMENUBAR 3

#define ABOUT 0
#define EXIT 1
#define FOLDERLIST 1000
#define ENTERMSG 2000
#define REPLYMSG 2001
#define MSGLIST 2002
#define MSGNEXT 2003
#define MSGPREV 2004
#define COMMENTMSG 2005
#define SAVEMSG 2006
#define VIEWHEADERS 2007
#define FORWARDMSG 2008
#define FINDSTRING 2009
#define GOTOMESSAGE 2010
#define MARKMESSAGE 2011
#define DELETEMESSAGE 2012

#define ABORTWRITING 3000
#define SENDMSG 3001
#define MODIFYHEADER 3002
#define CHANGECOLORS 4000
#define SAVECOLORS 4001
#define CHNEWTPL 4002
#define CHREPLYTPL 4003
#define CHCOMMENTTPL 4004
#define CHSIGNATURETPL 4005
#define ADDRESSBOOK 4006

extern int ProgramPosition;
extern char helpfile[255];

/*extern char PBMR_ATTACH[256];
extern char PBMR_FOLDERNAME[256];
extern char PBMR_BOUNDARY[256];
extern char PBMR_MESSAGE_MAILED[256];
extern char PBMR_*/

int user_getch();
void logfile(char *msg);
void LoadUsername(char *login);
void StatusLine(char *str);
int ReadItem(FILE *id,char *str);
int CompareStr(const char *st1,const char *st2,int mincmp,int lowerletters=0);
char *GetHelpPath();
void GetNameFromAddress(char *addr);
void GetEMailFromAddress(char *addr);

#endif
