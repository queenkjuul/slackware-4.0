/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TINPUTFIELD_H
#define _TINPUTFIELD_H
#include"TWindow.h"
#include"keyboard.h"
#include"colors.h"
#include"misc.h"

class TInputField : public TWindow {
	int pos;
	int x,y,width;
	int cur_col;
	char *hlpfile;
	char *string;
	char *oldstr;
	int escape;
	public:
	int CheckEscape() {return escape;}
	void InitializeString();
	void GetString();
	char* ReturnString() { return string; }
	void DeleteChar();
	void AddChar(int key);
	char virtual *Hlp() {return hlpfile;}
	TInputField(int xi,int yi,int widthi, char *default_v="\0") : 
	string(default_v), pos(0),x(xi),y(yi), 
	cur_col(0), width(widthi-2),
	TWindow(xi,yi,xi+widthi,yi," "),hlpfile("inputfield.hlp"),
	oldstr(new char[1024]),escape(0)
		{
		logfile("TInputField::TInputField");
		InitializeString();  
		}
	~TInputField()
		{
		logfile("TInputField::~TInputField");   
		delete[] string;   
		delete[] oldstr;
		}        
	};

#endif                   
