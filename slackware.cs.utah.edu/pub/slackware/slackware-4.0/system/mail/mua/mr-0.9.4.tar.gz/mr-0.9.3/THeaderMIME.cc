/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
//#include "mr.h"
#include "THeaderMIME.h"

void THeaderMIME::Encode()
	{
	int i;
	char *newtxt=new char[255]; newtxt[0]='\0';
	char *tmpstr=new char[10]; tmpstr[0]='\0';
	if(strlen(TEXT)<8) return;
	for(i=0;i<strlen(TEXT);i++)
		{
		if((TEXT[i]<32)||(TEXT[i]>126))
			{
			sprintf(newtxt,"=?%s?q?",rc_charset);
			for(int j=0;j<strlen(TEXT);j++)
				{
				if((TEXT[j]>32)&&(TEXT[j]<126)&&
				(TEXT[j]!='=')&&(TEXT[j]!='_')&&
				(TEXT[j]!='?')&&(TEXT))
					{
					sprintf(tmpstr,"%c",TEXT[j]);
					}
				else
					{
					if(TEXT[j]==' ')
					sprintf(tmpstr,"_");
					else if((unsigned char)TEXT[j]>=16)
					sprintf(tmpstr,"=%X",(unsigned char)TEXT[j]);
					else
					sprintf(tmpstr,"=0%X",(unsigned char)TEXT[j]);
					}
				newtxt=(char*)realloc(newtxt,strlen(newtxt)+strlen(tmpstr)+20);
				strcat(newtxt,tmpstr);
				}
			strcat(newtxt,"?=");
			TEXT=(char*)realloc(TEXT,strlen(newtxt)+10);
			strcpy(TEXT,newtxt);
			break;
			}
		}
	delete[] newtxt;
	delete[] tmpstr;
	}
void THeaderMIME::Decode()
	{
	long data_begin=0,data_end=0,charset_begin=0,charset_end=0,method_begin=0;
	for(int i=0;i<strlen(TEXT);i++)
		{
		if((TEXT[i]=='=')&&(TEXT[i+1]=='?'))  //poczatek headera MIME
			{
			int q=0;
			charset_begin=i+2;
			for(int j=i+2;j<strlen(TEXT);j++)
				{
				if(TEXT[j]=='?') 
					{
					q++;
					if(q==1)
						{
						charset_end=j-1;
						method_begin=j+1;
						}
					else if(q==2)
					data_begin=j+1;
					else if(q==3)
					data_end=j-1;
					}
				if((q==3)&&(TEXT[j+1]=='='))
					{
					char *encoded_str=new char[1024];
					char *the_rest_of_str=new char[1024];
					pchar *pstr=new pchar[1];
					pstr[0]=encoded_str;
					long maxy=0;
					strncpy(encoded_str,&(TEXT[data_begin]),data_end-data_begin+1);
					encoded_str[data_end-data_begin+1]='\0';
					strcpy(the_rest_of_str,&(TEXT[data_end+3]));
					if((TEXT[method_begin]=='q')||(TEXT[method_begin]=='Q'))
						{
						//zamiana '_' na ' '
						for(int k=0;k<strlen(encoded_str);k++)
							{if(encoded_str[k]=='_') encoded_str[k]=' ';}
						//teraz to juz zwykle quoted printable...
						TQuotedPrintable dequoter(&pstr,&maxy,0);
						dequoter.Decode();
						//skasowanie ew. dodatkowych linijek...
						//(nie obsluguje ich)
						if(maxy>0) for(int k=maxy;k>0;k--) delete[] pstr[k];
						sprintf(TEXT+i,"%s%s",pstr[0],the_rest_of_str);
						}
					else if((TEXT[method_begin]=='B')||(TEXT[method_begin]=='b'))
						{
						unsigned char *str=new unsigned char[1024];
						long filelen=0;
						TBASE64 debaser(&str,&pstr,&maxy,0,&filelen);
						debaser.Decode();
						for(int b=0;b<maxy;b++)
						delete[] pstr[b];
						strncpy(pstr[0],(char*)str,filelen);
						pstr[0][filelen]='\0'; 
						sprintf(TEXT+i,"%s%s",pstr[0],the_rest_of_str);					 
						delete[] str;
						}
					delete[] pstr[0];
					delete[] the_rest_of_str;
					delete[] pstr;
					break;
					}
				}
			}
		} 
	}
