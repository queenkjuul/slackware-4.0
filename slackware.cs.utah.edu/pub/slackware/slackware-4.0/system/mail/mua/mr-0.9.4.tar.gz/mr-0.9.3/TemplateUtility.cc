/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TemplateUtility.h"

char tplto[255];
char tpltoemail[255];
char tplsubj[255];


void AddTemplate(FILE *id1,FILE *id2, char *from, char *email, char *to, 
char *toemail, char *subj, char *date)
	{
	char *dayofweek=new char[255]; dayofweek[0]=0;
	char *day=new char[255]; day[0]=0;
	char *month=new char[255]; month[0]=0;
	char *year=new char[255]; year[0]=0;
	char *time_sec=new char[255]; time_sec[0]=0;
	char *time_min=new char[255]; time_min[0]=0;
	char *time_hour=new char[255]; time_hour[0]=0;
	char *fromfirstname=new char[255];fromfirstname[0]=0;
	char *fromlastname=new char[255];fromlastname[0]=0;
	char *tofirstname=new char[255];tofirstname[0]=0;
	char *tolastname=new char[255];tolastname[0]=0;
	if(from[0])
		{
		int i=0;  
		for(;(i<strlen(from))&&(from[i]!=' ');fromfirstname[i]=from[i++]);  
		fromfirstname[i]=0; 
		while(from[i]==' ') i++;
		int j=0;
		for(;(i<strlen(from))&&(from[i]!=' ');fromlastname[j++]=from[i++]);  
		fromlastname[j]=0;
		}
	if(to[0])
		{
		int i=0;  
		for(;(i<strlen(to))&&(to[i]!=' ');tofirstname[i]=to[i++]);  
		tofirstname[i]=0;
		while(to[i]==' ') i++;
		int j=0;
		for(;(i<strlen(to))&&(to[i]!=' ');tolastname[j++]=to[i++]);  
		tolastname[j]=0;
		}
	if(date[0])
		{
		int i=0,j,istheredayofweek=0;
		for(j=0;j<strlen(date);j++)
		if(date[j]==',')istheredayofweek=1;
		if(istheredayofweek)
			{   
			for(;(i<strlen(date))&&(date[i]!=' ');dayofweek[i]=date[i++]);  
			dayofweek[i]=0;
			while(date[i]==' ') i++;
			}
		j=0;   
		for(;(i<strlen(date))&&(date[i]!=' ');day[j++]=date[i++]);
		day[j]=0;
		while(date[i]==' ') i++;
		j=0;   
		for(;(i<strlen(date))&&(date[i]!=' ');month[j++]=date[i++]);
		month[j]=0;
		while(date[i]==' ') i++;
		j=0;   
		for(;(i<strlen(date))&&(date[i]!=' ');year[j++]=date[i++]);
		year[j]=0;
		while(date[i]==' ') i++;
		j=0;   
		for(;(i<strlen(date))&&(date[i]!=':');time_hour[j++]=date[i++]);
		time_hour[j]=0;
		while(date[i]==':') i++;
		j=0;   
		for(;(i<strlen(date))&&(date[i]!=':');time_min[j++]=date[i++]);
		time_min[j]=0;
		while(date[i]==':') i++;
		j=0;   
		for(;(i<strlen(date))&&(date[i]!=' ');time_sec[j++]=date[i++]);
		time_sec[j]=0;
		}
	logfile("TemplateUtility.h::AddTemplate"); 
	int a;
	fseek(id2,0,SEEK_END);
	long length=ftell(id2);  
	fseek(id2,0,SEEK_SET);
	char *data=new char[length+5];
	char *data2=new char[length+10000];
	sprintf(data2,"\0");
	fread(data,length,1,id2);
	data[length]='\0';
	a=0;
	for(int i=0;i<length;i++)
		{
		if(data[i]=='@')
			{
			if((data[i+1]=='f')&&(data[i+2]=='f'))
			strcat(data2,fromfirstname),i+=2;
			else if((data[i+1]=='f')&&(data[i+2]=='l'))
			strcat(data2,fromlastname),i+=2;
			else if((data[i+1]=='t')&&(data[i+2]=='f'))
			strcat(data2,tofirstname),i+=2;
			else if((data[i+1]=='t')&&(data[i+2]=='l'))
			strcat(data2,tolastname),i+=2;
			else if((data[i+1]=='f')&&(data[i+2]=='a'))
			strcat(data2,email),i+=2;
			else if((data[i+1]=='t')&&(data[i+2]=='a'))
			strcat(data2,toemail),i+=2;
			else if(data[i+1]=='s')
			strcat(data2,subj),i++;
			else if(data[i+1]=='@')
			strcat(data2,"@"),i++,a++;
			else if((data[i+1]=='d')&&(data[i+2]=='y'))
			strcat(data2,year),i+=2;
			else if((data[i+1]=='d')&&(data[i+2]=='m'))
			strcat(data2,month),i+=2;
			else if((data[i+1]=='d')&&(data[i+2]=='d'))
			strcat(data2,day),i+=2;
			else if((data[i+1]=='d')&&(data[i+2]=='w'))
			strcat(data2,dayofweek),i+=2;
			else if((data[i+1]=='d')&&(data[i+2]=='h'))
			strcat(data2,time_hour),i+=2;
			else if((data[i+1]=='d')&&(data[i+2]=='n'))
			strcat(data2,time_min),i+=2;
			else if((data[i+1]=='d')&&(data[i+2]=='s'))
			strcat(data2,time_sec),i+=2;
			}
		else {long q=strlen(data2);
			data2[q]=data[i];
			data2[q+1]=0;}
		}
	int linecnt=0;
	for(int i=0;i<strlen(data2);i++)
		{
		if(data2[i]=='\n')
		linecnt=0; 
		if(data2[i]==' ')    
			{
			int j;
			for(j=i+1;j<70;j++)
			if(data2[j]==' ') break;
			if(j-i==70) {fprintf(id1,"\n"); linecnt=0;}
			}
		if(linecnt==70) {fprintf(id1,"\n"); linecnt=0;}    
		fprintf(id1,"%c",data2[i]);
		linecnt++;     
		}
	delete[] data;
	delete[] data2;
	delete[] dayofweek;
	delete[] day;
	delete[] month;
	delete[] year;
	delete[] time_sec;
	delete[] time_min;
	delete[] time_hour;
	delete[] fromfirstname;
	delete[] fromlastname;
	delete[] tofirstname;
	delete[] tolastname;
	
	}

void Template(int tpl,char *from, char *email, char *to, char *toemail,
char* subj, char *date)
	{
	logfile("TemplateUtility.h::Template");
	char *str=new char[255];  
	FILE *id1,*id2;  
	sprintf(str,"%s/.mr/mailfile.%ld.tmp",getenv("HOME"),(long)getpid());   
	if(tpl!=SIGNATURE)  
		{id1=fopen(str,"wt");
		if(tpl==NEW)
			{sprintf(str,"%s/.mr/new.tpl",getenv("HOME")); id2=fopen(str,"rt");}
		else if(tpl==REPLY)
			{sprintf(str,"%s/.mr/reply.tpl",getenv("HOME")); id2=fopen(str,"rt");}
		else if(tpl==COMMENT)
			{sprintf(str,"%s/.mr/comment.tpl",getenv("HOME")); id2=fopen(str,"rt");}
		else if(tpl==FORWARD)
			{sprintf(str,"%s/.mr/forward.tpl",getenv("HOME")); id2=fopen(str,"rt");}}
	else     
		{id1=fopen(str,"at");
		sprintf(str,"%s/.mr/signature.tpl",getenv("HOME"));
		id2=fopen(str,"rt");}
	
	if((id1!=MYNULL)&&(id2!=MYNULL))
		{AddTemplate(id1,id2,from,email,to,toemail,subj,date);}
	else logfile("Template file error");    
	fclose(id1); fclose(id2);
	delete[] str;      
	}


