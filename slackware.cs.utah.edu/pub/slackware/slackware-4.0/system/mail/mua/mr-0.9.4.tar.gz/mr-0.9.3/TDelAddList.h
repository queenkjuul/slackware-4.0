/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/

/*   This header file defines a list class, which breaks it's keyboard 
     procedure when key DEL is pressed. This class is used by TAttachList */

#ifndef _TDELADDLIST_H
#define _TDELADDLIST_H

#include "TList.h"

class TDelAddList : public TList {
	int x1,y1,x2,y2,textcolor; //coordinates of the window, and color
	
	int tab,del;  //these determine the state of keys: tab and del
	
	public:
	
	void Keyboard();    //Handles the keyboard for this object
	
	void ShowWindow();  //Paints the object on the screen
	
	int CheckTab() { return tab; } //checks the state of tab
	
	int CheckDelete() { return del; } //checks the state of del
	
	TDelAddList(pchar *i, long n, int ax,int ay,int ax1,int ay1,
	            int defaultv=0, int textcolr=A_NORMAL,
	            int selectedcolr=A_REVERSE,int barcolr=A_NORMAL):
	TList(i,n,ax,ay,ax1,ay1,defaultv,textcolr,selectedcolr,barcolr),
	x1(ax),y1(ay),x2(ax1),y2(ay1),
	textcolor(textcolr),
	tab(0),del(0)
		{
		}
	
	};

#endif
