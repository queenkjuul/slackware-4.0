/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TFOLDERLIST_H
#define _TFOLDERLIST_H
#include "TWindow.h"
#include "TFolderListEngine.h"
#include "TFolderView.h"
#include "TInputField.h"
#include "keyboard.h"
#include "colors.h"
#include "misc.h"
#include "TViewTextMsg.h"
#include "mr.rc.variables.h"

class TFolderList : public TWindow
	{
	private:
	pchar *items;  
	pchar *files;  
	pchar *dto;
	pchar *dcc;
	pchar *dbcc;
	pchar *replyto;
	long count;
	int x,y,x1,y1;
	public:
	void InitItems();  
	int virtual Action();
	TFolderList(int xi,int yi,int xi1,int yi1):  count(-1),files(MYNULL),
	items(MYNULL),dto(MYNULL),
	dcc(MYNULL),dbcc(MYNULL),
	replyto(MYNULL),
	TWindow(xi,yi,xi1,yi1,"\0"),
	x(xi),y(yi),x1(xi1),y1(yi1)
		{
		logfile("TFolderList::TFolderList"); 
		InitItems();
		do
			{
			ProgramPosition=FOLDERLIST;
			StatusLine("Up/Down: Choose folder  Enter: Run folder  F10: Menu");
			}
		while(Action());   
		}
	~TFolderList()
		{
		logfile("TFolderList::~TFolderList");
		for(int i=0;i<count;i++)
			{
			delete[] items[i];  
			delete[] files[i];
			}
		delete[] items;
		delete[] files;
		delete[] dto;
		delete[] dcc;
		delete[] dbcc;
		delete[] replyto;
		}      
	};


#endif              
