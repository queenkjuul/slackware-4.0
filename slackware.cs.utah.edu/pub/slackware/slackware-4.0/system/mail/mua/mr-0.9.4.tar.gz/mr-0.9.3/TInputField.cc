/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TInputField.h"

void TInputField::InitializeString()
	{
	logfile("TInputField::InitializeString");    
	char *pointer=new char[2048];
	if(strlen(string)>1024)
	pointer=(char*)realloc(pointer,strlen(string)+1000);
	for(int i=0;i<1024;i++) pointer[i]=0;
	if(string!=MYNULL)
	sprintf(pointer,"%s",string);     
	else
	pointer[0]=0;
	string=pointer;
	}
void TInputField::GetString()
	{
	logfile("TInputField::GetString");   
	int len=strlen(string);   
	sprintf(oldstr,"%s",string);
	if(len<width)
	pos=len;
	else
		{pos=width; cur_col=len-width;}
	int key;   
	ungetch(KEY_RIGHT);
	while((key=user_getch())!='\n')
		{
		if(key==KEY_ESC)
			{sprintf(string,"%s",oldstr);  
			escape=1;
			break;}
		switch(key)
			{
			case KEY_LEFT:
			if(pos) pos--;
			else if(cur_col>0) cur_col--;
			break;
			case KEY_RIGHT:
			if(pos+cur_col<len) 
			if(pos<width)
			pos++;
			else
			cur_col++;   
			break;
			case KEY_BACKSPACE:
			case 8:
			case KEY_BCKSPC:
			if(pos+cur_col>0)
			DeleteChar(),len--;
			break;  
			case KEY_DC:
			if(pos+cur_col<len)
				{pos++; DeleteChar(); len--;}
			break;
			
			case KEY_F(1):
			sprintf(helpfile,"%s",Hlp());
			Help();
			break; 
			default:
			AddChar(key),len++;
			}  
		for(int i=0;i<width+2;i++)
		mvaddch(y,x+i,' ');
		user_mvaddstr(y,x+1,width,string+cur_col);
		mvaddch(y,x,'[');
		mvaddch(y,x+width+1,']');
		if(cur_col)
		mvaddch(y,x,'<');
		if(cur_col+pos<len)
		mvaddch(y,x+width+1,'>');
		move(y,x+pos+1);
		}
	}
void TInputField::AddChar(int key)
	{
	logfile("TInputField::AddChr");  
	int len=strlen(string);
	if(len==pos+cur_col)   
	string[pos+cur_col]=char(key),string[pos+cur_col+1]=0;
	else
		{
		int i;  
		for(i=len+1;i>pos+cur_col;i--)  
		string[i]=string[i-1];
		string[i]=char(key);
		}
	ungetch(KEY_RIGHT);     
	}                   
void TInputField::DeleteChar()
	{
	logfile("TInputField::DeleteChar");  
	int i,len=strlen(string);
	if(len+cur_col>0)
		{
		for(i=pos+cur_col-1;i<len;i++)
		string[i]=string[i+1];
		string[i]=0;   
		}
	ungetch(KEY_LEFT);       
	}                  

