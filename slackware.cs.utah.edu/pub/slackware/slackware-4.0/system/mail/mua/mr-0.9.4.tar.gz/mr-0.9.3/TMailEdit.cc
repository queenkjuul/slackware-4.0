/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#include "mr.h"
#include "TMailEdit.h"

void TMailEdit::ImportFile(char *file)
	{
	char *tmp=new char[255];
	sprintf(tmp,"%s/.mr/bound.%ld.tmp",getenv("HOME"),(long)getpid());
	FILE *id=fopen(tmp,"w");
	fprintf(id,"%s",rc_fileimportboundary);
	fclose(id);
	TEdit::ImportFile(tmp);
	TEdit::ImportFile(file);
	TEdit::ImportFile(tmp);
	unlink(tmp);
	delete[] tmp;
	}

int TMailEdit::SplitLine(int line)
	{
	logfile("TMailEdit::SplitLine");  
	int len=strlen(file[line]);
	int y=cursory;
	int fromwhere=len-2;   //wyliczenie, gdzie zlamac linie
	while(file[line][fromwhere]!=' ') {fromwhere--; if(fromwhere==0)
			{
			fromwhere=71;
			break;  
			}}
	fromwhere++;           //ewentualne stworzenie nowej linii
	
	if(line==maxy)                                                             
		{cursory=line-filepos;
		AddLine(); cursory=y;}
	else if(file[line+1][0]=='\0')
		{cursory=line-filepos;
		AddLine(); cursory=y;}
	
	//przesuniecie zawartosci dolnej linijki
	int nextlinelen=strlen(file[line+1])+2;  
	for(int j=nextlinelen;j>=0;j--)
	file[line+1][j+len-fromwhere]=file[line+1][j];
	//przepisanie danych od zlamania z gory na dol
	for(int i=fromwhere;i<len;i++)
	file[line+1][i-fromwhere]=file[line][i];
	//zaznaczenie konca linii na zlamaniu
	file[line][fromwhere]='\0';
	return fromwhere;
	}
void TMailEdit::AddChar(char ch)
	{
	logfile("TMailEdit::AddChar");  
	int i,len=1000;  
	TEdit::AddChar(ch);
	
	if(strlen(file[cursory+filepos])>72)
	len=SplitLine(filepos+cursory); 
	
	for(i=filepos+cursory+1;i<maxy;i++)
	if(strlen(file[i])>72)
	SplitLine(i);
	if(cursorx>len)
		{
		MoveDown();
		GotoXPos(cursorx-len);
		}
	}

void TMailEdit::Delete()
	{
	logfile("TMailEdit::Delete");  
	if((cursorx+cur_col>=strlen(file[cursory+filepos]))&&(cursory+filepos<maxy))
		{
		if(cursorx+cur_col>strlen(file[cursory+filepos]))
			{MoveLeft(); AddChar(' ');}
		cursory++;
		cursorx=0;
		cur_col=0;
		BackSpace();
		}
	else    
	TEdit::Delete();
	} 

void TMailEdit::BackSpace()
	{
	logfile("TMailEdit::BackSpace");  
	int i;
	if(cursorx+cur_col>0) //zwykle skasowanie znaku
	TEdit::BackSpace();
	else if(cursory+filepos) //przeniesienie linijke wyzej
		{
		int len=strlen(file[cursory-1+filepos]);
		int len2=strlen(file[cursory+filepos]);
		int wsk=0;
		if(len<72)
			{
			int i;
			if(len2>0)      //jesli trzeba przeniesc cos z dolu do gory
				{
				wsk=72-len;  //wyszukiwanie, ile mozna przeniesc do gory
				//slow by u gory bylo x<72 znakow
				if(wsk>len2) wsk=len2;             
				else
				while(file[cursory+filepos][wsk]!=' ') if(wsk==0) break; 
				else wsk--;
				if(wsk)
					{
					for(i=0;i<wsk;i++)
					file[cursory-1+filepos][len+i]=file[cursory+filepos][i];
					file[cursory-1+filepos][len+i]=0;
					}
				} 
			if(len2<=wsk) 
			DelLine(cursory+filepos);       
			else
				{
				for(i=0;i<=len2-wsk;i++)
				file[cursory+filepos][i]=file[cursory+filepos][i+wsk];
				}
			MoveUp();      //qrsor do gory
			GotoXPos(len);
			}
		}
	} 
void TMailEdit::user_mvaddstr(int y,int x,int maxlen,char *str)
	{
	attr_t attrs;
	int j;
	logfile("TViewTextMsg::user_mvaddstr");  
	int highlighted=0;  
	if(maxlen>strlen(str)) maxlen=strlen(str);
	if((str[0]=='>')||(str[0]==':'))
	attrset(viewerquotedcolor);
	else
	attrset(viewertextcolor);
	
	for(int i=0;i<maxlen;i++)
		{
		if(str[i]=='_') 
			{
			mvaddch(y,x+i,str[i] & A_CHARTEXT);
			for(j=i+1;j<maxlen;j++) 
			if(str[j]==' ') {mvaddch(y,x+i,str[i] & A_CHARTEXT);break;}
			else if(str[j]=='_')
				{
				attrs=attr_get();
				attrset(underlined);
				for(int k=i;k<=j;k++)
				mvaddch(y,x+k,str[k] & A_CHARTEXT);
				attrset(attrs);
				i=j;
				break;
				}
			
			}
		else if(str[i]=='*') 
			{
			mvaddch(y,x+i,str[i] & A_CHARTEXT);
			for(j=i+1;j<maxlen;j++) 
			if((str[j]==' ')) {mvaddch(y,x+i,str[i] & A_CHARTEXT);break;}
			else if(str[j]=='*')
				{
				attrs=attr_get();
				attrset(boldtext);
				for(int k=i;k<=j;k++)
				mvaddch(y,x+k,str[k] & A_CHARTEXT);
				attrset(attrs);
				i=j;
				break;
				}
			}
		else if(str[i]=='/') 
			{
			mvaddch(y,x+i,str[i] & A_CHARTEXT);
			for(j=i+1;j<maxlen;j++) 
			if((str[j]==' ')) {mvaddch(y,x+i,str[i] & A_CHARTEXT);break;}
			else if(str[j]=='/')
				{
				attrs=attr_get();
				attrset(italictext);
				for(int k=i;k<=j;k++)
				mvaddch(y,x+k,str[k] & A_CHARTEXT);
				attrset(attrs);
				i=j;
				break;
				}
			}
		else if(str[i]=='@') 
			{
			mvaddch(y,x+i,str[i] & A_CHARTEXT);
			for(j=i;j>=0;j--) 
			if((str[j]==' ')||(j==0))
				{
				if(str[j]==' ')j++;
				int k;
				attrs=attr_get();
				attrset(emailhighlighttext);
				for(k=j;(str[k]!=' ')&&(k<maxlen);k++)
				mvaddch(y,x+k,str[k] & A_CHARTEXT);
				attrset(attrs);
				i=k;
				break;
				}
			}
		else 
		mvaddch(y,x+i,str[i] & A_CHARTEXT);
		}
	}

