/*   MR -- A colorful and powerful mailreader
     Copyright (C) 1997 Przemek Borys

     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 2 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

     Przemek Borys can be contacted on pborys@p-soft.silesia.linux.org.pl
     (home machine), or pborys@rhea.ids.pl, or 2:484/17.25 at FidoNet.
*/
#ifndef _TMULTIPARTLIST_H
#define _TMULTIPARTLIST_H

#include "TList.h"

class TMultipartList : public TList {
	int x1,y1,x2,y2,textcolor;
	char *from,*email,*to,*toemail,*subj,*date;
	pchar *msglist;
	int cur_msg,max_msg;
	public:
	void Keyboard();
	void ShowWindow();
	TMultipartList(pchar *i, long n, int ax,int ay,int ax1,int ay1, int defaultv=0, 
	int textcolr=A_NORMAL,int selectedcolr=A_REVERSE,int barcolr=A_NORMAL,
	pchar *l,char *f, char *e, char *t, char *te, char *s, char *d,
	int curmsg,int maxmsg):
	TList(i,n,ax,ay,ax1,ay1,defaultv,textcolr,selectedcolr,barcolr),
	x1(ax),y1(ay),x2(ax1),y2(ay1),
	textcolor(textcolr),msglist(l),
	from(f),email(e),to(t),toemail(te),subj(s),date(d),
	cur_msg(curmsg),max_msg(maxmsg)
		{
		StatusLine("Up/Dn/PgUp/PgDn:Browse items,<-/->:Browse msgs,l:msglist,(i)ns:new msg");
		}
	
	};
#endif
