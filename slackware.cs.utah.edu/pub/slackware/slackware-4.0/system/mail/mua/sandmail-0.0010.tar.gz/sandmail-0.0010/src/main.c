#include "common.h"
#include <gtk/gtk.h>
#include "struc.h"
#include "main.h"

#include "gladesrc.h"
#include "gui.h"
#include "menu.h"

int main (int argc, char *argv[]) {
char a[128];

acur=0;
afol=0;
fol_norep=0;
acc_norep=0;
yesmsg=0;
aboutboxopen=0;
sendmsgopen=0;

statusbar_total=0;
msgstatusbar_total=0;

  gtk_set_locale();
  gtk_init(&argc, &argv);

#ifdef I18N
//  setlocale (LC_MESSAGES, "");
//  setlocale (LC_MESSAGES, LOC);
  bindtextdomain ("sandmail", LOCALEDIR);
  textdomain ("sandmail");
#endif

  readconfig();

#ifndef _CTREE_
  if (threadmsgs>0) threadmsgs=0;
  if (ctree>0) ctree=0;
#endif

  config=create_config();
  mainwin=create_main();
  
  msgwin=create_msgwin(); /* because creating a msgwin (one with pixmaps) is
                             VERY slow, we create one and show/hide it in the
							 rest of the program (only re-created when user
							 changes icons' layout)
						  */
#ifdef _MENUS_
  strcpy(a,"~/.sandmailrc.menus");
  ConvertHome(a);
  gtk_item_factory_parse_rc(a);

  msg_menu_activate(FALSE);
#endif
  menu_activate_newmsg(TRUE);

  gtk_widget_show(mainwin);

  if (accounts==0) Open_Config(msgwin, NULL);

  gtk_main();
  return(0);
}
