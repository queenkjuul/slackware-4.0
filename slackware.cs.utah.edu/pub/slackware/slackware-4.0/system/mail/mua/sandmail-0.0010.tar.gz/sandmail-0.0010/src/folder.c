#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <signal.h>
#include "common.h"
#include "folder.h"
#include "main.h"
#include "struc.h"
#include "findrep.h"
#include "gui.h"

extern  char yesmsg;   // from gladesrc.h
void clist_clear();    // from gladesrc.h

void debugmsg(char *a);

void fixdate(char s[])
{
char a[7][128];
int i;
char w[7][5];
char f;

for(i=0;i<7;i++) strcpy(a[i],"");

strcpy(w[0],"Sun,");
strcpy(w[1],"Mon,");
strcpy(w[2],"Tue,");
strcpy(w[3],"Wed,");
strcpy(w[4],"Thu,");
strcpy(w[5],"Fri,");
strcpy(w[6],"Sat,");

sscanf(s,"%s %s %s %s %s %s %s",a[0],a[1],a[2],a[3],a[4],a[5],a[6]);

//Fri, 16 Oct 1998 12:48:29 +0300 (EET DST)
// 0    1  2    3      4      5    6    7

f=0;
for(i=0;(i<7) && (f==0);i++) if (strcmp(a[0],w[i])==0) f++;
if (f==0)
  {
  for(i=5;i>=0;i--) strcpy(a[i+1],a[i]);
  strcpy(a[0],"");
  } else a[0][3]=0;

//sprintf(s,"%s, %s %s, %s  %s %s",a[3],a[2],a[1],a[0],a[4],a[5]);
// Year, Month Day, Dayname  Time Timezone

sprintf(s,"%s %s %s, %s  %s %s",a[2],a[1],a[0],a[3],a[4],a[5]);
//  Month Day Dayname, Year  Time Timezone

}



int ConvertHome(char s[])
{
char a[128], b[128]; int i,j;

  strcpy(b,s);
  if ((strlen(b)>2) && (b[0]=='~') && (b[1]=='/'))
	{
	j=strlen(b);
	for(i=2;i<j;i++) b[i-2]=b[i];
	b[j-2]=0;
	strcpy(a,b);
	sprintf(b,"%s/%s",getenv("HOME"),a);
	strcpy(s,b);
	return(1);
	}
  return(0);
}

int SearchStart(FILE *f, char searchfor[], char searchtoo[])
{
  char ch; int p1=0,p2=0,l1,l2;
  l1=strlen(searchfor);
  l2=strlen(searchtoo);
  
  while ((p1<l1) && (p2<l2))
    {
    ch=fgetc(f);
    if (ch!=searchfor[p1]) p1=0;
    if (ch!=searchtoo[p2]) p2=0;
	while ((ch!=searchfor[p1]) && (ch!=searchtoo[p2]) && (!feof(f)))
	  {
	  ch=fgetc(f);
	  if (ch!=searchfor[p1]) p1=0;
	  if (ch!=searchtoo[p2]) p2=0;
	  }
	if (feof(f)) return(0); // reached end-of-file
	if (ch==searchfor[p1]) p1++; else p1=0;
	if (ch==searchtoo[p2]) p2++; else p2=0;
	}
  if (p2==l2) return(2); // searchtoo match found
  return(1); // searchfor match found
}


// return value:
// 0: not identical
// +: n identical
// -: n identical. len(searchfor)>len(string)
int strstartcmp(char *s, char *searchfor)
{
  int i,l1,z;

  l1=strlen(searchfor);

  z=0;
  for(i=0;i<l1;i++)
	if ((searchfor[i] | 32)==(s[i] | 32)) z++; else i=l1;

 if ((l1>strlen(s)) && (z>0)) return(-z);
 return(z);
}

int Scan_Box(char fname[], GtkWidget *clis)
{  FILE *f; unsigned int i,j,t; long p; char a[128], b[128];
  char mailkey[6][50];
  char mailfound[6][256];
  gchar *add[6];

if (mails!=NULL) free(mails);
mails=(smallmailstruc *)malloc(sizeof(smallmailstruc));

  strcpy(mailkey[0],"\nFrom: ");
  strcpy(mailkey[1],"\nDate: ");
  strcpy(mailkey[2],"\nTo: ");
  strcpy(mailkey[3],"\nSubject: ");
  strcpy(mailkey[4],"\nNewsgroups: ");
  strcpy(mailkey[5],"\nStatus: ");


  strcpy(a,fname);
  ConvertHome(a);
  f=myfopen(a,"r");
  if (f==NULL) return(1); // error opening file

  fseek(f,0,SEEK_END);
  totprogress=ftell(f);
  fseek(f,0,SEEK_SET);
  progress_update(ftell(f));


  t=0;
  strcpy(mails[t].date,"");
  i=SearchStart(f,"From ","From ");
  while (i>0)
    {
	for(j=0;j<6;j++) strcpy(mailfound[j],"");
    p=ftell(f);
	
	for(j=0;((j<6) && (i>0));j++)
	  {
	  fseek(f,p,SEEK_SET);
      i=SearchStart(f,mailkey[j],"\nFrom ");
	  if (i==1)
		{
		fgets(mailfound[j],255,f);
		mailfound[j][strlen(mailfound[j])-1]=0;
		}
	  }
	sprintf(b,"%i",t+1);
	sprintf(a,"      ");
	sprintf(&a[6-strlen(b)],"%s",b);
	strcpy(mails[t].m_data[0],a);
    strcpy(mails[t].date,mailfound[1]);
	fixdate(mailfound[1]);
	strcpy(mails[t].m_data[1],mailfound[1]);
	strcpy(mails[t].m_data[2],mailfound[3]);
	
	while (replacestr(mailfound[0],"\"","")==1); // get rid of the " 's
	while (replacestr(mailfound[2],"\"","")==1);
	
	if ((strcmp(mailfound[2],"")==0) && (strcmp(mailfound[4],"")!=0)) sprintf(mailfound[2],"News: %s",mailfound[4]);
	strcpy(mails[t].m_data[3],mailfound[0]);
	strcpy(mails[t].m_data[4],mailfound[2]);
	strcpy(mails[t].m_data[5],mailfound[5]);

	mails[t].realstartpos=p-5;
	mails[t].haveparent=0;

    fseek(f,p,SEEK_SET);
    i=SearchStart(f,"\n\n", "\nFrom ");
	if (i==1) mails[t].startpos=ftell(f)-1;
	if (i==2) { mails[t].startpos=mails[t].realstartpos; puts("$it"); }

//	printf("\nr:%li * p:%li",mails[t].realstartpos,mails[t].startpos); fflush(stdout);

    t++;

	mails=(smallmailstruc *)realloc(mails,(t+1)*sizeof(smallmailstruc));
	strcpy(mails[t].date,"");

  progress_update(ftell(f));
	
    i=SearchStart(f,"\nFrom ", "\nFrom ");
    }
  mails[t].realstartpos=ftell(f);

  progress_update(ftell(f));

/*
  i=SearchStart(f,"\n\n", "\nFrom ");
  if (i==1) mails[t].startpos=ftell(f)-1;
  if (i==2) { mails[t].startpos=mails[t].realstartpos; puts("$itt"); }
*/
  mails=(smallmailstruc *)realloc(mails,(t+1)*sizeof(smallmailstruc));

  totmail=t;

  fclose(f);
  strcpy(a,fname);
  ConvertHome(a);
  unlockfolder(a);


  clist_clear();
  gtk_clist_freeze(GTK_CLIST(clis));

  totprogress=totmail;
  PushStatusbar(_("Adding messages to the list..."));
  progress_update(0);
//  while(gtk_events_pending()) gtk_main_iteration(); // *important*


if (threadmsgs!=0) /* *************** */
  {

  for(i=0;i<totmail;i++)
	{
  progress_update(i);

	for(j=0;j<6;j++) add[j]=mails[i].m_data[j];

#ifdef _CTREE_
	if (ctree!=0)
	  {
	  GtkCTreeNode *g, *g2;
	  gchar *add2[6]; char c[32], d[32];

	  strcpy(a,mails[i].m_data[2]);
	  if ((a[0]=='R') && (a[1]=='e') && (a[2]==':') && (a[3]==' ')) replacestr(a,"Re: ","");

if (mails[i].haveparent==0)
  {
	  mails[i].haveparent++;
	  g=gtk_ctree_insert_node(GTK_CTREE(clis),NULL,NULL,add,0,NULL,NULL,NULL,NULL,TRUE,FALSE);
	  gtk_ctree_node_set_row_data(GTK_CTREE(clis),g,(gpointer)i);

	  sprintf(d,"%i",i+1);
	  strcpy(c,"        ");
	  sprintf(&c[8-strlen(d)],"%s",d);

	  for(t=0;t<totmail;t++)
		{
		strcpy(b,mails[t].m_data[2]);
		if ((b[0]=='R') && (b[1]=='e') && (b[2]==':') && (b[3]==' ')) replacestr(b,"Re: ","");
	    if ((mails[t].haveparent==0) && (strcmp(b,a)==0))
		  {
		  for(j=0;j<6;j++) add2[j]=mails[t].m_data[j];
		  mails[t].haveparent++;

		  gtk_ctree_set_node_info(GTK_CTREE(clis),g,c,0,NULL,NULL,NULL,NULL,FALSE,TRUE);
		  g2=gtk_ctree_insert_node(GTK_CTREE(clis),g,NULL,add2,0,NULL,NULL,NULL,NULL,TRUE,FALSE);
		  gtk_ctree_node_set_row_data(GTK_CTREE(clis),g2,(gpointer)t);
		  }
		}
  }


	  } else
#endif
	  {
	  gtk_clist_append(GTK_CLIST(clis),add);
	  gtk_clist_set_row_data(GTK_CLIST(clis),i,(gpointer)i);
	  }


	}

#ifdef _CTREE_
  if ((ctree!=0) && (threadmsgs!=0))
	{
	GtkCList *cl;
    cl=GTK_CLIST(clis);
    cl->sort_type=GTK_SORT_ASCENDING;
    gtk_clist_set_sort_column(cl, 1);
	gtk_ctree_sort_recursive(GTK_CTREE(clis), NULL);
	}
#endif

} /* *************** */
else
{

  for(i=0;i<totmail;i++)
	{

	for(j=0;j<6;j++) add[j]=mails[i].m_data[j];

#ifdef _CTREE_
	if (ctree!=0)
	  {
	  GtkCTreeNode *g;
	  g=gtk_ctree_insert_node(GTK_CTREE(clis),NULL,NULL,add,0,NULL,NULL,NULL,NULL,TRUE,FALSE);
	  gtk_ctree_node_set_row_data(GTK_CTREE(clis),g,(gpointer)i);
	  } else
#endif
	  {
	  gtk_clist_append(GTK_CLIST(clis),add);
	  gtk_clist_set_row_data(GTK_CLIST(clis),i,(gpointer)i);
	  }

	}

} /* *************** */

  gtk_clist_thaw(GTK_CLIST(clis));
  progress_update(0);

  return(0);
}



void Scan_Mail(FILE *f, int fullheaders)
{
  signed int i,j,noatt,ismime,a,l, tmp;
  char mimekey[80],sep[80],endsep[80],b[80],c[80], *sp;
  unsigned long p;
    
debugmsg("\nscan_mail: called");

  strcpy(mimekey,"\nContent-Type: ");
  curmail.mimecount=0;
  curmail.mimepos[0]=curmail.realstartpos;
  strcpy(curmail.mimesep,"");
  
  fseek(f,curmail.realstartpos+5,SEEK_SET);

  ismime=SearchStart(f,mimekey,"\nFrom ");
  if (ismime==1)
	{
	debugmsg("\nscan_mail: begin mime scan");
	fgets(b,80,f);
	b[strlen(b)-1]=0;
#ifdef _DEBUG_
    printf("\nmime content-type:*%s*",b);
#endif
	i=strlen(b);
    for(j=0;j<i;j++) c[j]=b[j];
	c[i]=0;


	a=0; l=0;
#ifdef _DEBUG_
	printf("\nebe. a:%i  c: * %s *",a,c);
#endif
//                     123456789012345|7890123456|
	tmp=strstartcmp(c,"MULTIPART/MIXED; BOUNDARY=\x022");
	if ((tmp>10) || (tmp<-10))
	  {
	  a=27; l=tmp; debugmsg("\n**mixed");
	  if ((l!=-17) && (l!=27)) { a=0; debugmsg(".. abandoned!");	}
	  }

//                     123456789012345678901|3456789012|
	tmp=strstartcmp(c,"MULTIPART/ALTERNATIVE; BOUNDARY=\x022");
	if ((a==0) && ((tmp>10) || (tmp<-10)))
	  {
	  a=33; l=tmp; debugmsg("\n**alternative");
	  if ((l!=-23) && (l!=33)) { a=0; debugmsg(".. abandoned!"); }
	  }

//	printf("\nlala. l:%i  a:%i c: * %s *",l,a,c);

	if ((l==-17) && (a==27)) // mixed
  	  {
	  debugmsg("\n entering mixed conversion");

	  fgets(c,80,f);
	  if (c[0]!=9)
		{
		fseek(f,-strlen(b),SEEK_CUR);
		a=0;
		} else
		{
		i=strlen(c);
    	for(j=0;j<=i;j++) c[j]=c[j+1];
		c[i]=0;
		sprintf(b,"MULTIPART/MIXED; %s",c);
#ifdef _DEBUG_
		printf("\n new b: * %s *",b);
#endif
		}
	  }
	
	if ((l==-23) && (a==33)) // alternative
  	  {
	  debugmsg("\n entering alternative conversion");
	  fgets(c,80,f);
	  if (c[0]!=9)
		{
		fseek(f,-strlen(b),SEEK_CUR);
		a=0;
		} else
		{
		i=strlen(c);
    	for(j=0;j<=i;j++) c[j]=c[j+1];
		c[i]=0;
		sprintf(b,"MULTIPART/ALTERNATIVE; %s",c);
#ifdef _DEBUG_
		printf("\n new b: * %s *",b);
#endif
		}
	  }
	  
//	printf("\nLOLA. l:%i  a:%i b: * %s *",l,a,b);
	
	if (a>0)
	  {
	  strcpy(curmail.mimesep,"");
	  for(i=a;i<strlen(b);i++) curmail.mimesep[i-a]=b[i];
	  curmail.mimesep[strlen(curmail.mimesep)-1]=0;
	  for(i=0;i<strlen(curmail.mimesep);i++) if (curmail.mimesep[i]==0x22) { curmail.mimesep[i]=0; break; }
#ifdef _DEBUG_
	  printf("\nmultipart/mixed or alternative, seperator: *%s*",curmail.mimesep);
#endif
	  sprintf(sep,"\n--%s\n",curmail.mimesep);
	  sprintf(endsep,"\n--%s--\n",curmail.mimesep);
	  noatt=0;
	  } else
	  {
	  strcpy(sep,"\nFrom ");
	  noatt=1;
	  }

    if (noatt==0) i=SearchStart(f,sep,endsep);
	else
	  {
	  fseek(f,curmail.realstartpos,SEEK_SET);
	  i=1;
	  }
	  
    while (i==1)
      {
	  debugmsg("\nscan_mail: begin mime attributes scan");
	  curmail.mimepos[curmail.mimecount]=ftell(f);

	  p=ftell(f);
	  if (noatt==1) p+=4;
	  strcpy(curmail.mimedesc[curmail.mimecount],_("No desc."));
	  j=SearchStart(f,"\nContent-Description: ",sep);
	  if (j==1)
		{
		fgets(curmail.mimedesc[curmail.mimecount],80,f);
		curmail.mimedesc[curmail.mimecount][strlen(curmail.mimedesc[curmail.mimecount])-1]=0;
	    curmail.mimecutpos[curmail.mimecount]=ftell(f)+1;
		}
	  fseek(f,p-2,SEEK_SET);

	  strcpy(curmail.mimefile[curmail.mimecount],"");
	  j=SearchStart(f,"\nContent-Type: ",sep);
	  if (j==1)
		{
		fgets(b,80,f);
		b[strlen(b)-1]=0;
		sprintf(c,"%s (%s)",curmail.mimedesc[curmail.mimecount],b);
		sprintf(curmail.mimecont[curmail.mimecount],"%s",b);
		strcpy(curmail.mimedesc[curmail.mimecount],c);
#ifdef _DEBUG_
		printf("\nmime content-type: *%s*",b);
#endif
		strcpy(c,b);
		sp=strstr(c,"; name=");
		if (sp!=NULL)
		  {
		  sprintf(b,"%s",sp);
	  	  j=strlen(b);
		  for(i=7;i<j;i++) b[i-7]=b[i];
		  b[j-7]=0;
		  if ((b[0]==0x22) && (b[strlen(b)-1]==0x22))
		    {
		    j=strlen(b)-1;
		    for(i=1;i<j;i++) b[i-1]=b[i];
		    b[j-1]=0;		  		  
		    }
		  strcpy(curmail.mimefile[curmail.mimecount],b);
#ifdef _DEBUG_
		  printf("\nmimefile: *%s*",curmail.mimefile[curmail.mimecount]);
#endif
		  }

		}
	  fseek(f,p-2,SEEK_SET);
	  
	  strcpy(curmail.mimeenc[curmail.mimecount],"");
	  j=SearchStart(f,"\nContent-Transfer-Encoding: ",sep);
	  if (j==1)
		{
		fgets(b,80,f);
		b[strlen(b)-1]=0;
		strcpy(curmail.mimeenc[curmail.mimecount],b);
		}
	  fseek(f,p,SEEK_SET);

	  curmail.mimecount++;
	  debugmsg("\nscan_mail: end mime attributes scan");
	  if (noatt==1) i=2; else i=SearchStart(f,sep,endsep);
      }
	if ((i==2) && (noatt==0)) curmail.endpos=ftell(f)-2;
    debugmsg("\nscan_mail: end mime scan");
	if (fullheaders==0) curmail.mimepos[0]=curmail.startpos; // **
	} else
	{
	debugmsg("\nscan_mail: no mime");
	curmail.mimecount=1;
	curmail.endpos=ftell(f)-5;
	if (ismime==0) curmail.endpos+=5; // last msg, dont rewind "From "
	if (fullheaders==0) curmail.mimepos[0]=curmail.startpos;
            	else curmail.mimepos[0]=curmail.realstartpos;
	strcpy(curmail.mimedesc[0],_("Body"));
	strcpy(curmail.mimeenc[0],"");
	strcpy(curmail.mimefile[0],"");
	curmail.mimepos[1]=curmail.endpos;
	curmail.mimecutpos[0]=curmail.endpos;
	}
#ifdef _DEBUG_
printf("\nscanmail p:%li * e:%li",curmail.startpos,curmail.endpos);
#endif
}



int fcopy(char *sf, char *df)
{
FILE *s, *d; unsigned long i,w,b; char buf[64000]; char a[128];

  b=64000;

  strcpy(a,sf);
  ConvertHome(a);
  s=myfopen(a,"r");
  if (s==NULL) return(1); // error opening file
  strcpy(a,df);
  ConvertHome(a);
  d=myfopen(a,"w");
  if (d==NULL) return(2); // error opening file

  i=1; w=i;
  while ((!feof(s)) && (w==i))
	{
    i=fread(buf,1,b,s);
    w=fwrite(buf,1,i,d);
	}

  fclose(s);
  strcpy(a,sf);
  ConvertHome(a);
  unlockfolder(a);

  fclose(d);
  strcpy(a,df);
  ConvertHome(a);
  unlockfolder(a);

  if (w!=i) return(3);
  return(0);
}

int fdel(char *fn)
{
char a[128];

  strcpy(a,fn);
  ConvertHome(a);
  if (access(a,F_OK)==0) // if file exists
	{
	remove(a);
	}
    return(0);
}



int CopyMsg(char *sf, unsigned long ss, unsigned long se, char *df)
{
FILE *s,*d; unsigned long i; char a[128];

  strcpy(a,sf);
  ConvertHome(a);
  s=myfopen(a,"r");
  if (s==NULL) return(1); // error opening file
  strcpy(a,df);
  ConvertHome(a);
  d=myfopen(a,"a");
  if (d==NULL) return(2); // error opening file

  fseek(s,ss,SEEK_SET);
  for(i=ss;i<se;i++) fputc(fgetc(s),d);

  fclose(s);
  strcpy(a,sf);
  ConvertHome(a);
  unlockfolder(a);

  fclose(d);
  strcpy(a,df);
  ConvertHome(a);
  unlockfolder(a);

  return(0);
}


int DelMsg(char *fn, unsigned long ss, unsigned long se)
{
FILE *f; unsigned long i,l; char ff[128]; char a[128];


// get size of folder
strcpy(a,fn);
ConvertHome(a);
f=myfopen(a,"r");
if (f==NULL) return(1);
fseek(f,0,SEEK_END);
l=ftell(f);
fclose(f);
strcpy(a,fn);
ConvertHome(a);
unlockfolder(a);

// zero-byte temp file
fdel("/tmp/sandmail.delmsg.half.tmp");

// backup copy
sprintf(ff,"%s.before-delmsg.bak",fn);
i=fcopy(fn,ff);
if (i!=0) return(i);


// copy the part before the deleted msg
if (ss>0) i=CopyMsg(fn,0,ss,"/tmp/sandmail.delmsg.half.tmp");
if (i!=0) return(i);

// copy the part after the deleted msg
if (se<l) i=CopyMsg(fn,se,l,"/tmp/sandmail.delmsg.half.tmp");
if (i!=0) return(i);

// replace original folder file with the new one
i=fcopy("/tmp/sandmail.delmsg.half.tmp",fn);
fdel("/tmp/sandmail.delmsg.half.tmp");
return(i);
}





/*
  >0 already locked
   0 successful
  -1 could not create lock
*/
int lockfolder(char folfile[])
{
  FILE *f;
  pid_t apid;
  char lockfile[64];
  
  sprintf(lockfile,"%s.lock",folfile);

  if (access(lockfile,F_OK)==0) {
    f=fopen(lockfile, "r");
    fscanf(f,"%d",&apid);
	if (apid==getpid()) return(0);  /* FIXME */
	return((int)apid);
	}
  if ((f = fopen(lockfile,"w")) != NULL) {
    fprintf(f,"%d",getpid());
    fclose(f);
	return(0);
	} else return(-1);
}



/*
  >0 locked by another process
   0 successful
*/
int unlockfolder(char folfile[])
{
  FILE *f;
  pid_t apid;
  char lockfile[64];
  
  sprintf(lockfile,"%s.lock",folfile);

  if (access(lockfile,F_OK)==0) {
    f=fopen(lockfile, "r");
    fscanf(f,"%d",&apid);
	fclose(f);
	if (getpid()==apid)
	  {
	  fdel(lockfile);
	  return(0);
	  } else return(apid);
	}
  return(0);
}



FILE *myfopen(char *path, char *mode)
{
int i;
FILE *r;

i=lockfolder(path);
i=0;
if (i!=0)
  {
  printf("Folder %s is locked by pid %i. Remove %s.lock if it's not\n",path,i,path);
  fflush(stdout);
  return(NULL);
  }

r=fopen(path,mode);
if (r==NULL) unlockfolder(path);
return(r);
}
