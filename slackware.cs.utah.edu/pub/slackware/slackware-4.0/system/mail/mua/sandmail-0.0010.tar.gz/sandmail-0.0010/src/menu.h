#ifndef _MENU_H_
#define _MENU_H_

#include <gtk/gtk.h>

#ifdef _MENUS_
GtkItemFactory *item_factory_0;
GtkItemFactory *item_factory_1;
GtkItemFactory *item_factory_2;
#endif

char durun_lan;
char durun_lan2;

void menu_activate_newmsg(gboolean b);

#ifdef _MENUS_
void disable_nonfunctional_menuitems(int which);
void msg_menu_activate(gboolean b);
void msg_menu_set_toggles();
void msg_menu_toggle (gpointer callback_data,guint callback_action,GtkWidget *widget);
void msg_menu_close (gpointer callback_data,guint callback_action,GtkWidget *widget);
void msg_menu_cb (gpointer callback_data,guint callback_action,GtkWidget *widget);
void main_menu_quit (gpointer callback_data,guint callback_action,GtkWidget *widget);
void write_menu_cb (gpointer callback_data,guint callback_action,GtkWidget *widget);
void write_pgp_menu_set_toggles();
void write_pgp_menu_toggle(gpointer callback_data,guint callback_action,GtkWidget *widget);
GtkWidget *create_menu(GtkWidget *win, int i);
#endif

#endif
