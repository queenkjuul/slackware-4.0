#include "folder.h"
#include "gladesrc.h"
#include "gui.h"
#include "menuitems.c"
#include "menu.h"
#include "main.h"

void menu_activate_newmsg(gboolean b)
{
#ifdef _MENUS_
gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/File/New message"),b);
gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/Message/Reply"),b);
gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/Message/Forward"),b);
gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_1, "<main>/File/New message"),b);
gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_1, "<main>/Message/Reply"),b);
gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_1, "<main>/Message/Forward"),b);
#endif

gtk_widget_set_sensitive(mainwin_but_compose,b);
gtk_widget_set_sensitive(msgwin_but_reply,b);
gtk_widget_set_sensitive(msgwin_but_forward,b);
}


#ifdef _MENUS_

void disable_nonfunctional_menuitems(int which)
{
  if (which==0)
	{
	gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/Message/Reply"),FALSE);
    gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/Message/Forward"),FALSE);
    gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/Message/Mark"),FALSE);
    gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/Message/Mark as Read"),FALSE);
    gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/Message/Mark as Unread"),FALSE);
    gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/Mail/Send mail"),FALSE);
	}

  if (which==1)
	{
	gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_1, "<main>/Message/Reply"),FALSE);
    gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_1, "<main>/Message/Forward"),FALSE);
	gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_1, "<main>/Message/Mark"),FALSE);
	gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_1, "<main>/Message/Mark as Read"),FALSE);
	gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_1, "<main>/Message/Mark as Unread"),FALSE);
	}

  if (which==2)
	{
    gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_2, "<main>/File/Send message now"),FALSE);
	gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_2, "<main>/File/Send message later"),FALSE);
	gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_2, "<main>/File/Insert file"),FALSE);
	gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_2, "<main>/File/Attach file"),FALSE);
	}

}

void msg_menu_activate(gboolean b)
{
gtk_widget_set_sensitive(gtk_item_factory_get_widget(item_factory_0, "<main>/Message"),b);
}

void msg_menu_set_toggles()
{
GtkCheckMenuItem *a;
  durun_lan++;
  a=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(item_factory_1, "<main>/View/View with full headers"));
  if (a!=NULL) gtk_check_menu_item_set_state(a,fullhead);
  a=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(item_factory_1, "<main>/View/Launch web browser when html detected"));
  if (a!=NULL) gtk_check_menu_item_set_state(a,autoweb);
  while (gtk_events_pending()) gtk_main_iteration();
  durun_lan=0;
}


void msg_menu_toggle (gpointer callback_data,guint callback_action,GtkWidget *widget)
{
if (durun_lan>0) return;

  if (callback_action==0)
	{
	if (fullhead==0) fullhead++; else fullhead=0;
	}
  if (callback_action==1)
	{
	if (autoweb==0) autoweb++; else autoweb=0;
	}

#ifdef _CTREE_
  if (ctree!=0)
	{
	gtk_signal_emit_by_name(GTK_OBJECT(clist),"tree_select_row",cur_msg_row_ctree,1);
	}
	else
#endif
	{
	gtk_signal_emit_by_name(GTK_OBJECT(clist),"select_row",cur_msg_row,1);
	}

}


void main_menu_quit (gpointer callback_data,guint callback_action,GtkWidget *widget)
{
//delete_event(GtkWidget *widget, GdkEvent *event, gpointer data);
delete_event(mainwin, NULL, NULL);
destroy(mainwin, NULL);
//gtk_signal_emit_by_name(GTK_OBJECT(mainwin),"destroy",NULL);
}

void msg_menu_close (gpointer callback_data,guint callback_action,GtkWidget *widget)
{
hidewin(msgwin);
}


void msg_menu_cb (gpointer callback_data,guint callback_action,GtkWidget *widget)
{
FILE *f; unsigned long r,p,e; int i; char a[128];

  if (yesmsg==0) return;


  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  f=myfopen(a,"r");
  if (f==NULL) { PushStatusbar(_("Cannot open folder file")); return; }

  i=cur_msg;

  p=mails[i].startpos;
  r=mails[i].realstartpos;
  i++;
  if (i==totmail) { fseek(f,0,SEEK_END); e=ftell(f); }
	  else e=mails[i].realstartpos;

  curmail.curpart=0;
  curmail.realstartpos=r;
  curmail.startpos=p;
  curmail.endpos=e;

  Scan_Mail(f,fullhead);

  fclose(f);
  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  unlockfolder(a);

  msgmenu_func(NULL,(gpointer)callback_action);
}


void write_menu_cb (gpointer callback_data,guint callback_action,GtkWidget *widget)
{
int bla;
bla=(int)callback_action;

if (bla==0) // sendnow
  {
  Prepare_Message();
  } else if (bla==1) // send l8er
  {
  } else if (bla==2) // insert file
  {
  } else if (bla==3) // attach file
  {
  } else if (bla==4) // close
  {
  menu_activate_newmsg(TRUE);
  gtk_widget_destroy(sendwin);
  sendmsgopen=0;
  }

}


void write_pgp_menu_set_toggles()
{
GtkCheckMenuItem *a;
  durun_lan2++;
  a=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(item_factory_2, "<main>/PGP/Sign this message"));
  if (a!=NULL) gtk_check_menu_item_set_state(a,(writepgp & 1));
  a=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(item_factory_2, "<main>/PGP/Encrypt this message"));
  if (a!=NULL) gtk_check_menu_item_set_state(a,(writepgp & 2));
  while (gtk_events_pending()) gtk_main_iteration();
  durun_lan2=0;
}

void write_pgp_menu_toggle(gpointer callback_data,guint callback_action,GtkWidget *widget)
{
int bit;

if (durun_lan2>0) return;

bit=(int)callback_action;
if ((writepgp & bit)==0) writepgp|=bit;
					else writepgp&=(255-bit);

#ifdef _DEBUG_
  printf("\nwritepgp Changed to %i",writepgp); fflush(stdout);
#endif

}


GtkWidget *create_menu(GtkWidget *win, int i)
{
  GtkAccelGroup *accel_group;
  GtkWidget *w=NULL;
  int nmenu_items;

  accel_group = gtk_accel_group_new ();
  durun_lan=0;
  durun_lan2=0;

  if (i==0)
	{
    item_factory_0 = gtk_item_factory_new (GTK_TYPE_MENU_BAR, "<main>", accel_group);
	nmenu_items = sizeof (main_menu_items) / sizeof (main_menu_items[0]);
	gtk_item_factory_create_items (item_factory_0, nmenu_items, main_menu_items, NULL);
    gtk_accel_group_attach (accel_group, GTK_OBJECT(win));
    w=gtk_item_factory_get_widget(item_factory_0, "<main>");
    }
  if (i==1)
	{
    item_factory_1 = gtk_item_factory_new (GTK_TYPE_MENU_BAR, "<main>", accel_group);
	nmenu_items = sizeof (msg_menu_items) / sizeof (msg_menu_items[0]);
	gtk_item_factory_create_items (item_factory_1, nmenu_items, msg_menu_items, NULL);
    gtk_accel_group_attach (accel_group, GTK_OBJECT(win));
    w=gtk_item_factory_get_widget(item_factory_1, "<main>");
	}
  if (i==2)
	{
    item_factory_2 = gtk_item_factory_new (GTK_TYPE_MENU_BAR, "<main>", accel_group);
	nmenu_items = sizeof (send_menu_items) / sizeof (send_menu_items[0]);
	gtk_item_factory_create_items (item_factory_2, nmenu_items, send_menu_items, NULL);
    gtk_accel_group_attach (accel_group, GTK_OBJECT(win));
    w=gtk_item_factory_get_widget(item_factory_2, "<main>");
	}

  gtk_widget_show(w);

if (i==1) msg_menu_set_toggles();
if (i==2) write_pgp_menu_set_toggles();

disable_nonfunctional_menuitems(i);

  return(w);
}

#endif
