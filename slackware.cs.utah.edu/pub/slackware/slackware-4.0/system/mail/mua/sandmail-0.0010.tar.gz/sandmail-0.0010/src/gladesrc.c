#include "common.h"

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>

#include <gtk/gtk.h>
#include "gladesrc.h"
#include "gui.h"
#include "main.h"
#include "struc.h"
#include "folder.h"
#include "findrep.h"
//#include "xpm.h"
#include "getmail.h"
#include "menu.h"

void debugmsg(char *a)
{
#ifdef _DEBUG_
  printf("%s",a);  fflush(stdout);
#endif
}

#ifndef GTK_HAVE_FEATURES_1_1_2
#ifndef _SET_MODAL_DEFINED
#define _SET_MODAL_DEFINED
// From gtk+ 1.1.2's gtkwindow.c -- modified a bit
void gtk_window_set_modal (GtkWindow *window, gboolean modal)
{
  g_return_if_fail (window != NULL);
  g_return_if_fail (GTK_IS_WINDOW (window));

  /* If the widget was showed already, adjust it's grab state */
  if (GTK_WIDGET_VISIBLE(GTK_WIDGET(window)))
    {
      if (!modal)
	gtk_grab_remove (GTK_WIDGET(window));
      else if (modal)
	gtk_grab_add (GTK_WIDGET(window));
    }
}
#endif
#endif


#ifdef _CTREE_
void ctree_click_column (GtkCTree *ctree, gint column, gpointer data)
{
GtkCList *mclist;
  mclist = GTK_CLIST (ctree);
  if (column == mclist->sort_column)
	{
    if (mclist->sort_type == GTK_SORT_ASCENDING)
	  mclist->sort_type = GTK_SORT_DESCENDING;
    else
	  mclist->sort_type = GTK_SORT_ASCENDING;
    }
  else
    gtk_clist_set_sort_column (mclist, column);
  gtk_ctree_sort_recursive (ctree, NULL);
}
#endif


#ifdef _CLISTSORT_
void clist_click_column (GtkCList *aclist, gint column, gpointer data)
{
  if (column == aclist->sort_column)
    {
      if (aclist->sort_type == GTK_SORT_ASCENDING)
	aclist->sort_type = GTK_SORT_DESCENDING;
      else
	aclist->sort_type = GTK_SORT_ASCENDING;
    }
  else
    gtk_clist_set_sort_column (aclist, column);

  gtk_clist_sort(aclist);
}
#endif


GtkWidget* new_pixmap (gchar *filename[], GdkWindow *window, GdkColor  *background)
{
  GtkWidget *wpixmap;
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  pixmap = gdk_pixmap_create_from_xpm_d (window, &mask, background,filename);
  wpixmap = gtk_pixmap_new (pixmap, mask);
  gdk_pixmap_unref (pixmap);
  return wpixmap;
}


gint delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
 char a[128];
 if (writeconfig()!=0) return(TRUE); // if error do NOT exit

#ifdef _MENUS_
  strcpy(a,"~/.sandmailrc.menus");
  ConvertHome(a);
  gtk_item_factory_dump_rc(a,NULL,TRUE);
#endif									                                          gboolean                modified_only);

/* GTK will emit the "destroy" signal.  Returning TRUE means
 * you don't want the window to be destroyed. */
 return (FALSE);
}

gint dont_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
/* GTK will emit the "destroy" signal.  Returning TRUE means
 * you don't want the window to be destroyed. */
 return (TRUE);
}

void SetToolbarTipColor(GtkWidget *widget)
{
  GdkColor *t_fore,*t_back;

  t_fore=(GdkColor*)g_malloc( sizeof(GdkColor));
  t_back=(GdkColor*)g_malloc( sizeof(GdkColor));

  if (gdk_color_parse("Yellow",t_back))
	{
    if(gdk_color_alloc(gdk_colormap_get_system(),t_back))
	  {
      gdk_color_black(gdk_colormap_get_system(),t_fore);
      gtk_tooltips_set_colors(GTK_TOOLTIPS(GTK_TOOLBAR(widget)->tooltips),t_back,t_fore);
	  }
	}
}


void DoToolTips(GtkWidget *widget, char *desc)
{
  GtkTooltips *ttip;
  GdkColor *t_fore,*t_back;

  t_fore=(GdkColor*)g_malloc( sizeof(GdkColor));
  t_back=(GdkColor*)g_malloc( sizeof(GdkColor));

  ttip=gtk_tooltips_new();
  gtk_tooltips_set_tip(ttip,widget,desc,NULL);

  if (gdk_color_parse("Yellow",t_back))
	{
    if(gdk_color_alloc(gdk_colormap_get_system(),t_back))
	  {
      gdk_color_black(gdk_colormap_get_system(),t_fore);
      gtk_tooltips_set_colors(ttip,t_back,t_fore);
	  }
	}
}


void PopStatusbar()
{
gtk_statusbar_pop(GTK_STATUSBAR(statusbar),statusbar_id);
if (statusbar_total>0) statusbar_total--;
}

void PushStatusbar(char *desc)
{
while (statusbar_total>0) PopStatusbar();
gtk_statusbar_push(GTK_STATUSBAR(statusbar),statusbar_id,desc);
statusbar_total++;
}


void PopMsgStatusbar()
{
gtk_statusbar_pop(GTK_STATUSBAR(msgstatusbar),msgstatusbar_id);
if (msgstatusbar_total>0) msgstatusbar_total--;
}

void PushMsgStatusbar(char *desc)
{
while (msgstatusbar_total>0) PopMsgStatusbar();
gtk_statusbar_push(GTK_STATUSBAR(msgstatusbar),msgstatusbar_id,desc);
msgstatusbar_total++;
}

void DoStatusbar(GtkWidget *widget, GdkEvent *event, gpointer data)
{gtk_statusbar_push(GTK_STATUSBAR(statusbar),statusbar_id,data);}

void UndoStatusbar(GtkWidget *widget, GdkEvent *event, gpointer data)
{gtk_statusbar_pop(GTK_STATUSBAR(statusbar),statusbar_id);}

void PrepStatusbar(GtkWidget *widget, char *desc)
{
  gtk_signal_connect(GTK_OBJECT(widget),"enter_notify_event",GTK_SIGNAL_FUNC(DoStatusbar),desc);
  gtk_signal_connect(GTK_OBJECT(widget),"leave_notify_event",GTK_SIGNAL_FUNC(UndoStatusbar),NULL);
}

void toggle_button_callback (GtkWidget *widget, gpointer data)
{
  if (GTK_TOGGLE_BUTTON (widget)->active) cfg_radio_sel=(int)data;
}


void Update_Combo(accstruc acs[], int acb)
{
GList *combo_acct_items = NULL;
int i;

debugmsg("\n update_combo");

if (acb==0) return;

acc_norep=1;

for(i=0;i<acb;i++) combo_acct_items=g_list_append(combo_acct_items,acs[i].accname);
gtk_combo_set_popdown_strings(GTK_COMBO(combo_acct),combo_acct_items);
g_list_free(combo_acct_items);
gtk_list_select_item(GTK_LIST(GTK_COMBO(combo_acct)->list),acur);
gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(combo_acct)->entry),acs[acur].accname);

acc_norep=0;

}

void Update_FolderCombo(folderstruc folders[], int fnum)
{
GList *combo_items = NULL;
int i;

debugmsg("\n update_foldercombo");

if (fnum==0) return;


afol=0;
fol_norep=1;

gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(combo_folder)->entry),folders[afol].name);

for(i=0;i<fnum;i++) combo_items=g_list_append(combo_items,folders[i].name);
gtk_combo_set_popdown_strings(GTK_COMBO(combo_folder),combo_items);
g_list_free(combo_items);

gtk_list_select_item(GTK_LIST(GTK_COMBO(combo_folder)->list),afol);

#ifdef _DEBUG_
printf("\n * %s",folders[afol].name);
#endif

fol_norep=0;
}




void Update_FolderStatus()
{
  int i;

debugmsg("\n update_folderstatus");

  i=accbuf[acur].foldata[afol].status;
  gtk_option_menu_set_history(GTK_OPTION_MENU(opt_foldertype),i);
  gtk_entry_set_text(GTK_ENTRY(ent_folderfile),accbuf[acur].foldata[afol].file);
  if (i==5) gtk_entry_set_editable(GTK_ENTRY(ent_filter),1); else gtk_entry_set_editable(GTK_ENTRY(ent_filter),0);
}




void FolderCombo_change(GtkWidget *widget, gpointer data)
{ 
  int i,z; char *a;

#ifdef _DEBUG_
printf("\n foldercombo_change. norep: %i",fol_norep);
#endif

if (fol_norep==0) {

  a=gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo_folder)->entry));
  if (strcmp(a,accbuf[acur].foldata[afol].name)==0) return;
  
  if (afol>=accbuf[acur].folders) afol=0;

  z=-1;
  for(i=0;i<accbuf[acur].folders;i++) if (strcmp(a,accbuf[acur].foldata[i].name)==0) { z=i; break; }
  if (z==-1)
	{
	strcpy(accbuf[acur].foldata[afol].name,a);
	Update_FolderCombo(accbuf[acur].foldata,accbuf[acur].folders);
    gtk_list_select_item(GTK_LIST(GTK_COMBO(combo_folder)->list),afol);
	}
	else
	{
    afol=z;
    Update_FolderStatus();
	}
}	
}



void Update_Config(int a)
{

debugmsg("\n update_config");

  if ((a>=0) && (a<accountsbuf))
	{
	acur=a;
	gtk_entry_set_text(GTK_ENTRY(ent_password),accbuf[acur].password);
	gtk_entry_set_text(GTK_ENTRY(ent_username),accbuf[acur].username);
	gtk_entry_set_text(GTK_ENTRY(ent_org),accbuf[acur].org);
	gtk_entry_set_text(GTK_ENTRY(ent_sigfile),accbuf[acur].sigfile);
	gtk_entry_set_text(GTK_ENTRY(ent_fullname),accbuf[acur].fullname);
	gtk_entry_set_text(GTK_ENTRY(ent_replyto),accbuf[acur].replytoaddress);
	gtk_entry_set_text(GTK_ENTRY(ent_mail),accbuf[acur].mailaddress);
	gtk_entry_set_text(GTK_ENTRY(ent_pop3server),accbuf[acur].mailserver);
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(chk_leave),accbuf[acur].leaveonserver);
    gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(chk_trash),accbuf[acur].movetotrash);
	afol=0;
    Update_FolderCombo(accbuf[acur].foldata, accbuf[acur].folders);
    Update_FolderStatus();
	if (accbuf[acur].folders>1) gtk_widget_set_sensitive(but_delfol,TRUE);
						   else gtk_widget_set_sensitive(but_delfol,FALSE);
    }
}




void Combo_change(GtkWidget *widget, gpointer data)
{ 
  int i,z; char *a;

#ifdef _DEBUG_
printf("\n combo_change. norep: %i",acc_norep);
#endif

if (acc_norep==0) {
  
  a=gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo_acct)->entry));
  if (strcmp(a,accbuf[acur].accname)==0) return;
  z=-1;
  for(i=0;i<accountsbuf;i++) if (strcmp(a,accbuf[i].accname)==0) { z=i; break; }
  if (z==-1)
	{
	strcpy(accbuf[acur].accname,a);
	Update_Combo(accbuf,accountsbuf);
    gtk_list_select_item(GTK_LIST(GTK_COMBO(combo_acct)->list),acur);
	}
	else
	  Update_Config(z);
}	  
}




void Folder_Filter(GtkWidget *widget, GdkEvent *event, gpointer data)
{
  char *a;

debugmsg("\n folder_filter");

  a=gtk_entry_get_text(GTK_ENTRY(ent_filter));
  strcpy(accbuf[acur].foldata[afol].filter,a);
}



void Folder_File(GtkWidget *widget, GdkEvent *event, gpointer data)
{
  char *a;

debugmsg("\n folder_file");

  a=gtk_entry_get_text(GTK_ENTRY(ent_folderfile));
  strcpy(accbuf[acur].foldata[afol].file,a);
}




void Folder_Option_Change(GtkWidget *widget, gpointer data)
{
  int s,i;

debugmsg("\n folder_option_change");

  s=(int)data;
  accbuf[acur].foldata[afol].status=s;
  
  if (s==5) gtk_entry_set_editable(GTK_ENTRY(ent_filter),1); else gtk_entry_set_editable(GTK_ENTRY(ent_filter),0);
  if ((s>0) && (s<5))
	{
    for(i=0;i<accbuf[acur].folders;i++) if ((i!=afol) && (accbuf[acur].foldata[i].status==s)) accbuf[acur].foldata[i].status=0;
    }  
}


void destroy (GtkWidget *widget, gpointer data)
{
fdel("/tmp/sandmail.webbrowser.tmp.html");
fdel("/tmp/sandmail.webbrowser.run");
fdel("/tmp/sandmail.fetchpop.log");
if (mails!=NULL) free(mails);
gtk_main_quit ();
}



void Open_Config(GtkWidget *widget, gpointer data)
{

debugmsg("\n open_config");

gtk_widget_hide(msgwin);
gtk_window_set_modal(GTK_WINDOW(config),TRUE);
cpyaccs(accdata,&accounts,accbuf,&accountsbuf);
acur=0; afol=0;

if (autoweb==0) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_autoweb), FALSE);
		   else gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_autoweb), TRUE);

if (fullhead==0) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_fullhead), FALSE);
		   else gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_fullhead), TRUE);

if (threadmsgs==0) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_thread), FALSE);
		      else gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_thread), TRUE);

/*
if (ctree==0) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_ctree), FALSE);
  	     else gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_ctree), TRUE);
*/

gtk_entry_set_text(GTK_ENTRY(ent_pgpe),pgpdata.e);
gtk_entry_set_text(GTK_ENTRY(ent_pgps),pgpdata.s);
gtk_entry_set_text(GTK_ENTRY(ent_pgpv),pgpdata.v);
gtk_entry_set_text(GTK_ENTRY(ent_pgpuid),pgpdata.uid);
gtk_entry_set_text(GTK_ENTRY(ent_pgppassp),pgpdata.passp);

if ((pgpdata.option & 1)==0) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_pgp_sgn), FALSE);
	          	        else gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_pgp_sgn), TRUE);
if ((pgpdata.option & 2)==0) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_pgp_enc), FALSE);
	                    else gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_pgp_enc), TRUE);
Update_Combo(accbuf,accountsbuf);
Update_Config(acur);

if (accounts>1) gtk_widget_set_sensitive(but_delacc,TRUE);
		   else gtk_widget_set_sensitive(but_delacc,FALSE);

if (accdata[acur].folders>1) gtk_widget_set_sensitive(but_delfol,TRUE);
   					    else gtk_widget_set_sensitive(but_delfol,FALSE);

gtk_widget_show(config);
}


void Prepare_ServerTree(GtkWidget *w)
{
GtkWidget *treeitem,*subtree,*subitem;
int i,j;

debugmsg("\n prepare_servertree");

if (accounts>0)
  {

    for(i=0;i<accounts;i++)
      {
      treeitem=gtk_tree_item_new_with_label(accdata[i].accname);
      gtk_tree_append(GTK_TREE(w), treeitem);
      gtk_widget_show(treeitem);
	  accdata[i].tree=treeitem; // **

      subtree=gtk_tree_new();
      gtk_tree_item_set_subtree(GTK_TREE_ITEM(treeitem),subtree);
	  gtk_signal_connect(GTK_OBJECT(subtree), "select_child",GTK_SIGNAL_FUNC(Servertree_select), subtree);

  	  for(j=0;j<accdata[i].folders;j++)			   
		{
		subitem=gtk_tree_item_new_with_label(accdata[i].foldata[j].name);
  		accdata[i].foldata[j].tree=subitem; // **
		gtk_tree_append(GTK_TREE(subtree),subitem);
		gtk_widget_show(subitem);
		}
      }
	  gtk_tree_item_expand(GTK_TREE_ITEM(accdata[acur].tree));
  }
	  clist_clear();
}


void Record_First_Page()
{
  gchar *a;
  int oldthreadmsgs;

  a=gtk_entry_get_text(GTK_ENTRY(ent_smtp));
  sprintf(smtpserver,"%s",a);
  a=gtk_entry_get_text(GTK_ENTRY(ent_webb));
  sprintf(webbrowser,"%s",a);

  autoweb=(int)(GTK_TOGGLE_BUTTON(chk_autoweb)->active);
  fullhead=(int)(GTK_TOGGLE_BUTTON(chk_fullhead)->active);

  oldthreadmsgs=threadmsgs;
  threadmsgs=(int)(GTK_TOGGLE_BUTTON(chk_thread)->active);
  if (oldthreadmsgs!=threadmsgs)
	{
	if (threadmsgs==1)
	  {
	  ctree=1;
	  gtk_signal_handlers_destroy(GTK_OBJECT(mainwin)); 
	  gtk_widget_destroy(mainwin);
  	  mainwin=create_main();
	  gtk_widget_show(mainwin);
	  gtk_tree_clear_items(GTK_TREE(servertree),0,accounts);
	  Prepare_ServerTree(servertree);
	  }
	  else
	  {
	  ctree=0;	  
	  gtk_signal_handlers_destroy(GTK_OBJECT(mainwin)); 
	  gtk_widget_destroy(mainwin);
  	  mainwin=create_main();
	  gtk_widget_show(mainwin);
	  gtk_tree_clear_items(GTK_TREE(servertree),0,accounts);
	  Prepare_ServerTree(servertree);
	  }
	}
  
/*
  if (ctree!=(int)(GTK_TOGGLE_BUTTON(chk_ctree)->active))
	{
	ctree=(int)(GTK_TOGGLE_BUTTON(chk_ctree)->active);
	gtk_signal_handlers_destroy(GTK_OBJECT(mainwin)); 
	gtk_widget_destroy(mainwin);
	mainwin=create_main();
	gtk_widget_show(mainwin);
	gtk_tree_clear_items(GTK_TREE(servertree),0,accounts);
	Prepare_ServerTree(servertree);
	}
*/
}

void Record_Second_Page()
{
debugmsg("\nRecord Second Page.");
  strcpy(accbuf[acur].username,gtk_entry_get_text(GTK_ENTRY(ent_username)));
  strcpy(accbuf[acur].password,gtk_entry_get_text(GTK_ENTRY(ent_password)));
  strcpy(accbuf[acur].mailserver,gtk_entry_get_text(GTK_ENTRY(ent_pop3server)));
  strcpy(accbuf[acur].mailaddress,gtk_entry_get_text(GTK_ENTRY(ent_mail)));
  strcpy(accbuf[acur].replytoaddress,gtk_entry_get_text(GTK_ENTRY(ent_replyto)));
  strcpy(accbuf[acur].fullname,gtk_entry_get_text(GTK_ENTRY(ent_fullname)));
  strcpy(accbuf[acur].org,gtk_entry_get_text(GTK_ENTRY(ent_org)));
  strcpy(accbuf[acur].sigfile,gtk_entry_get_text(GTK_ENTRY(ent_sigfile)));

  accbuf[acur].leaveonserver=(int)(GTK_TOGGLE_BUTTON(chk_leave)->active);
  accbuf[acur].movetotrash=(int)(GTK_TOGGLE_BUTTON(chk_trash)->active);

}

void RecSecond(GtkWidget *widget, GdkEvent *event, gpointer data)
{
Record_Second_Page();
}

void Record_PGP_Page()
{
debugmsg("\nRecord PGP Page.");

  pgpdata.option=(int)(GTK_TOGGLE_BUTTON(chk_pgp_sgn)->active)|((GTK_TOGGLE_BUTTON(chk_pgp_enc)->active)*2);

  strcpy(pgpdata.e,gtk_entry_get_text(GTK_ENTRY(ent_pgpe)));
  strcpy(pgpdata.v,gtk_entry_get_text(GTK_ENTRY(ent_pgpv)));
  strcpy(pgpdata.s,gtk_entry_get_text(GTK_ENTRY(ent_pgps)));
  strcpy(pgpdata.uid,gtk_entry_get_text(GTK_ENTRY(ent_pgpuid)));
  strcpy(pgpdata.passp,gtk_entry_get_text(GTK_ENTRY(ent_pgppassp)));
}


void Close_Config(GtkWidget *widget, gpointer data)
{
int i;

i=(int)data;

if (i==0)
  {
  gtk_tree_clear_items(GTK_TREE(servertree),0,accounts);
  //cpyaccs(accbuf,&accountsbuf,accdata,&accounts);
  Prepare_ServerTree(servertree);
//  gtk_clist_clear(GTK_CLIST(clist));
  }

  clist_clear();
/*
  yesmsg=0;
#ifdef _MENUS_
  msg_menu_activate(FALSE);
#endif
*/

  PopStatusbar();

  debugmsg("\n close_config");

  gtk_window_set_modal(GTK_WINDOW(config),FALSE);
  gtk_widget_hide(config);
}


gint Close_Config_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
Close_Config(widget,(gpointer)0);
return (TRUE); // do not destroy window
}

void Ok_Close_Config(GtkWidget *widget, gpointer data)
{
gtk_widget_hide(msgwin);
Record_First_Page();
Record_Second_Page();
Record_PGP_Page();
cpyaccs(accbuf,&accountsbuf,accdata,&accounts);

if (icons!=cfg_radio_sel)
  {
  icons=cfg_radio_sel;
  if (icons==0)
	{
	gtk_toolbar_set_style(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_ICONS);
	gtk_toolbar_set_style(GTK_TOOLBAR(msgtoolbar), GTK_TOOLBAR_ICONS);
	}
  if (icons==1)
	{
	gtk_toolbar_set_style(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_TEXT);
	gtk_toolbar_set_style(GTK_TOOLBAR(msgtoolbar), GTK_TOOLBAR_TEXT);
	}
  if (icons==2)
	{
	gtk_toolbar_set_style(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_BOTH);
	gtk_toolbar_set_style(GTK_TOOLBAR(msgtoolbar), GTK_TOOLBAR_BOTH);
	}

  }

#ifdef _MENUS_
  msg_menu_set_toggles(); // update toggles
#endif

gtk_tree_clear_items(GTK_TREE(servertree),0,accounts);
Prepare_ServerTree(servertree);

Close_Config(widget,(gpointer)1);
}

void Save_Close_Config(GtkWidget *widget, gpointer data)
{
Ok_Close_Config(widget,data);
writeconfig();
}

void Update_clist()
{
  int i;
  char a[128];

debugmsg("\n update_clist");

gtk_widget_set_sensitive(mainwin,FALSE);
gtk_window_set_modal(GTK_WINDOW(mainwin),TRUE);
//gtk_widget_set_sensitive(statusbar,TRUE); /* does not work */


  PushStatusbar(_("Scanning mailbox, please wait..."));
  while(gtk_events_pending()) gtk_main_iteration(); // *important*

  i=Scan_Box(accdata[acur].foldata[afol].file,clist);

gtk_widget_set_sensitive(mainwin,TRUE);
gtk_window_set_modal(GTK_WINDOW(mainwin),FALSE);

  if (i!=0)
	{
	clist_clear();
    PushStatusbar(_("Error reading folder"));
	return;
	} 

  sprintf(a,_("Mailbox opened, %i messages"),totmail);
  if (totmail==0) strcpy(a,_("Mailbox opened, no messages"));
  PushStatusbar(a);

}

void view_with_browser()
{
FILE *f,*c; unsigned long p,e; pid_t pid; char a[128];

  PushMsgStatusbar(_("Launching Web browser"));
  p=curmail.mimepos[curmail.curpart];
  if ((curmail.curpart+1)==curmail.mimecount) e=curmail.endpos;
  else e=curmail.mimepos[curmail.curpart+1];
//  e=e-strlen(curmail.mimesep)-3;
	
  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  f=myfopen(a,"r");
  if (f==NULL) { PushMsgStatusbar(_("Error: Unable to open folder file")); return; } // **
  
  c=fopen("/tmp/sandmail.webbrowser.tmp.html","w");
  if (c==NULL) { PushMsgStatusbar(_("Error: Unable to create temprorary file")); return; } // **

  fseek(f,p,SEEK_SET);
  while ((p<e) && (!feof(f)))
    {
    fputc(fgetc(f),c);
	p++;	
	}
  fclose(f);
  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  unlockfolder(a);

  fclose(c);

  strcpy(a,webbrowser);
  ConvertHome(a);

  while(replacestr(a,"%s","/tmp/sandmail.webbrowser.tmp.html")==1);

  f=fopen("/tmp/sandmail.webbrowser.run","w");
  if (f==NULL) { PushMsgStatusbar(_("Error: Unable to create temprorary file")); return; } // **
  fprintf(f,"#/bin/sh\n");
  fprintf(f,"%s",a);
  fclose(f);


  chmod("/tmp/sandmail.webbrowser.tmp.html",S_IRUSR | S_IWUSR);
  chmod("/tmp/sandmail.webbrowser.run",S_IRUSR | S_IWUSR | S_IXUSR);

  pid=fork();
  if (!pid)
    {
    execlp("/tmp/sandmail.webbrowser.run","/tmp/sandmail.webbrowser.run",NULL);
    exit(0);
    }
//  pid=wait(NULL);

  PushMsgStatusbar(_("Web browser launch complete"));
}


int save_quoted_printable()
{
FILE *f,*c; unsigned long p,e; pid_t pid; char a[128];

  if (strcasecmp(curmail.mimeenc[curmail.curpart],"quoted-printable")==0)
	{
    p=curmail.mimepos[curmail.curpart];
	if ((curmail.curpart+1)==curmail.mimecount) e=curmail.endpos;
	else e=curmail.mimepos[curmail.curpart+1];
	
	strcpy(a,accdata[acur].foldata[afol].file);
    ConvertHome(a);
	f=myfopen(a,"r");
    if (f==NULL) return(0);

	c=fopen("/tmp/sandmail.quoted-printable.tmp","w");
    if (c==NULL) return(0);

    fseek(f,p,SEEK_SET);
    while ((p<e) && (!feof(f)))
  	  {
	  fputc(fgetc(f),c);
	  p++;	
	  }
	fclose(f);
	strcpy(a,accdata[acur].foldata[afol].file);
    ConvertHome(a);
	unlockfolder(a);

	fclose(c);
    chmod("/tmp/sandmail.quoted-printable.tmp",S_IRUSR | S_IWUSR);

    pid=fork();
    if (!pid)
      {
	  execlp("mmencode","mmencode","-u","-q","/tmp/sandmail.quoted-printable.tmp","-o","/tmp/sandmail.quoted-printable.decoded.tmp",NULL);
      exit(0);
      }
    pid=wait(NULL);

	fdel("/tmp/sandmail.quoted-printable.tmp");
	return(1);
	}
return(0);
}


void msgopt_change(GtkWidget *widget, gpointer data)
{
  FILE *f; unsigned long p,e; char c[2]; int s,i; char a[128];

  s=(int)data;
  curmail.curpart=s;

  gtk_text_freeze(GTK_TEXT(msgtext));
  
  gtk_text_set_point(GTK_TEXT(msgtext),0);
  gtk_text_forward_delete(GTK_TEXT(msgtext),gtk_text_get_length((GTK_TEXT(msgtext))));

  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  f=myfopen(a,"r");
  if (f==NULL) return;
  
  p=curmail.mimepos[s];

#ifdef _DEBUG_
  printf("\npart: %i * s: %li * endpos: %li * mimepos+1: %li",s,p,curmail.endpos,curmail.mimepos[s+1]);
#endif

  if ((s+1)==curmail.mimecount) e=curmail.endpos; else e=curmail.mimepos[s+1];
  if (strlen(curmail.mimesep)>0) e=e-strlen(curmail.mimesep)-3;

#ifdef _DEBUG_
  printf("\ns: %li * e: %li",p,e);
  printf("\nmimecount: %i",curmail.mimecount);
  printf("\nmimecont: * %s *",curmail.mimecont[0]);
#endif

  if (strcmp(curmail.mimeenc[s],"BASE64")==0) e=curmail.mimecutpos[s];
  i=save_quoted_printable();
//  if (i==1) e=curmail.mimecutpos[s];

if (i==0) {
  fseek(f,p,SEEK_SET);
  while ((p<e) && (!feof(f)))
	{
	c[0]=fgetc(f);
	c[1]=0;
    gtk_text_insert(GTK_TEXT(msgtext),NULL,NULL,NULL,c,-1);
	p++;	
	}
}
  fclose(f);
  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  unlockfolder(a);
  
  if (i==1)
	{
    f=fopen("/tmp/sandmail.quoted-printable.decoded.tmp","r");
    if (f==NULL) return;
    while (!feof(f))
	  {
	  c[0]=fgetc(f);
	  c[1]=0;
	  gtk_text_insert(GTK_TEXT(msgtext),NULL,NULL,NULL,c,-1);
	  }
	fclose(f);	
    fdel("/tmp/sandmail.quoted-printable.decoded.tmp");
	}

  gtk_text_thaw(GTK_TEXT(msgtext));

  strcpy(a,curmail.mimecont[s]);
  if ((strstr(a,"text/html")!=NULL) && (autoweb==1)) view_with_browser(); // *
}

void clist_select(GtkWidget *clist,gint row,gint column,GdkEventButton *event,gpointer data)
{
  gchar *text;
  FILE *f; unsigned long r,p,e; int i; char a[128];

debugmsg("\nclist_select()");

  if ((event->button == 2) || (event->button == 3)) return;

  gtk_clist_get_text(GTK_CLIST(clist),row,2,&text);
  gtk_entry_set_text(GTK_ENTRY(ent_msgsubj),text);
  gtk_entry_set_position(GTK_ENTRY(ent_msgsubj),0);

  gtk_clist_get_text(GTK_CLIST(clist),row,3,&text);
  gtk_entry_set_text(GTK_ENTRY(ent_msgfrom),text);
  gtk_entry_set_position(GTK_ENTRY(ent_msgfrom),0);

  gtk_clist_get_text(GTK_CLIST(clist),row,4,&text);
  gtk_entry_set_text(GTK_ENTRY(ent_msgto),text);
  gtk_entry_set_position(GTK_ENTRY(ent_msgto),0);

  gtk_widget_realize(msgtext);
  gtk_text_set_word_wrap(GTK_TEXT(msgtext),1);

  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  f=myfopen(a,"r");
  if (f==NULL) { PushStatusbar(_("Cannot open folder file")); return; }
  i=(int)gtk_clist_get_row_data(GTK_CLIST(clist),row);
  cur_msg=i;
  cur_msg_row=row;
  yesmsg=1;

#ifdef _MENUS_
  msg_menu_activate(TRUE);
#endif

  gtk_entry_set_text(GTK_ENTRY(ent_msgdate),mails[i].date);
  gtk_entry_set_position(GTK_ENTRY(ent_msgdate),0);

  p=mails[i].startpos;
  r=mails[i].realstartpos;
  i++;
  if (i==totmail) { fseek(f,0,SEEK_END); e=ftell(f); }
	  else e=mails[i].realstartpos;

  curmail.curpart=0;
  curmail.realstartpos=r;
  curmail.startpos=p;
  curmail.endpos=e;

debugmsg("\ncalling scan_mail");

  Scan_Mail(f,fullhead);

debugmsg("\nscan_mail returned");

  fclose(f);
  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  unlockfolder(a);

  opt_msgparts_menu = gtk_menu_new();

  for(i=0;i<curmail.mimecount;i++)
    {
    curmail.mimeitem[i]=gtk_menu_item_new_with_label(curmail.mimedesc[i]);
    gtk_widget_show(curmail.mimeitem[i]);
    gtk_signal_connect_object(GTK_OBJECT(curmail.mimeitem[i]),"activate",GTK_SIGNAL_FUNC(msgopt_change),(gpointer)i);
    gtk_menu_append(GTK_MENU(opt_msgparts_menu), curmail.mimeitem[i]);
	}
  gtk_option_menu_set_menu(GTK_OPTION_MENU(opt_msgparts), opt_msgparts_menu);

debugmsg("\ncalling msgopt_change");

msgopt_change(opt_msgparts,(gpointer)0);

debugmsg("\ndisplaying window\n");

gtk_widget_show(msgwin);

}


#ifdef _CTREE_
void ctree_select(GtkWidget *clist,GtkCTreeNode *row,gint column,GdkEventButton *event,gpointer data)
{
  gchar *text;
  FILE *f; unsigned long r,p,e; int i; char a[128];

debugmsg("\nctree_select()");
  
  gtk_ctree_node_get_text(GTK_CTREE(clist),row,2,&text);
  gtk_entry_set_text(GTK_ENTRY(ent_msgsubj),text);
  gtk_entry_set_position(GTK_ENTRY(ent_msgsubj),0);

  gtk_ctree_node_get_text(GTK_CTREE(clist),row,3,&text);
  gtk_entry_set_text(GTK_ENTRY(ent_msgfrom),text);
  gtk_entry_set_position(GTK_ENTRY(ent_msgfrom),0);

  gtk_ctree_node_get_text(GTK_CTREE(clist),row,4,&text);
  gtk_entry_set_text(GTK_ENTRY(ent_msgto),text);
  gtk_entry_set_position(GTK_ENTRY(ent_msgto),0);

  gtk_widget_realize(msgtext);
  gtk_text_set_word_wrap(GTK_TEXT(msgtext),1);

  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  f=myfopen(a,"r");
  if (f==NULL) { PushStatusbar(_("Cannot open folder file")); return; }

  i=(int)gtk_ctree_node_get_row_data(GTK_CTREE(clist),row);
  cur_msg=i;
  cur_msg_row_ctree=row;
  yesmsg=1;

#ifdef _MENUS_
  msg_menu_activate(TRUE);
#endif

  gtk_entry_set_text(GTK_ENTRY(ent_msgdate),mails[i].date);
  gtk_entry_set_position(GTK_ENTRY(ent_msgdate),0);

  p=mails[i].startpos;
  r=mails[i].realstartpos;
  i++;
  if (i==totmail) { fseek(f,0,SEEK_END); e=ftell(f); }
	  else e=mails[i].realstartpos;

  curmail.curpart=0;
  curmail.realstartpos=r;
  curmail.startpos=p;
  curmail.endpos=e;

debugmsg("\ncalling scan_mail");

  Scan_Mail(f,fullhead);

debugmsg("\nscan_mail returned");

  fclose(f);
  strcpy(a,accdata[acur].foldata[afol].file);
  ConvertHome(a);
  unlockfolder(a);

  opt_msgparts_menu = gtk_menu_new();

  for(i=0;i<curmail.mimecount;i++)
    {
    curmail.mimeitem[i]=gtk_menu_item_new_with_label(curmail.mimedesc[i]);
    gtk_widget_show(curmail.mimeitem[i]);
    gtk_signal_connect_object(GTK_OBJECT(curmail.mimeitem[i]),"activate",GTK_SIGNAL_FUNC(msgopt_change),(gpointer)i);
    gtk_menu_append(GTK_MENU(opt_msgparts_menu), curmail.mimeitem[i]);
	}
  gtk_option_menu_set_menu(GTK_OPTION_MENU(opt_msgparts), opt_msgparts_menu);

debugmsg("\ncalling msgopt_change");

msgopt_change(opt_msgparts,(gpointer)0);

debugmsg("\ndisplaying window\n");

gtk_widget_show(msgwin);
}
#endif


void msgmenu_decode_filesel_ok(GtkWidget *w, GtkFileSelection *fs)
{
  pid_t pid;
  char f[128];
  sprintf(f,"%s",gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
  gtk_object_destroy(GTK_OBJECT(fs));

  pid=fork();
  if (!pid)
    {
	execlp("mmencode","mmencode","-u","/tmp/sandmail.base64.tmp","-o",f,NULL);
    exit(0);
    }
  pid=wait(NULL);
  fdel("/tmp/sandmail.base64.tmp");
}




void msgmenu_export_filesel_ok(GtkWidget *w, GtkFileSelection *fs)
{
  char fn[128]; int i;
  sprintf(fn,"%s",gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
  gtk_object_destroy(GTK_OBJECT(fs));

  fdel(fn);
  i=CopyMsg(accdata[acur].foldata[afol].file,curmail.realstartpos,curmail.endpos,fn);
  if (i!=0)
	{
	sprintf(fn,_("Cannot export message: CopyMsg returned error %i"),i);
	PushMsgStatusbar(fn);
	} else
	{
	PushMsgStatusbar(_("Export message complete"));
	}
}



void cpymove_do(GtkWidget *widget, gpointer data)
{
int cpymove; unsigned long p,e; char fn[128]; int i;

  cpymove=(int)data;

  sprintf(fn,"%s",gtk_entry_get_text(GTK_ENTRY(cpy_ent_s)));
  p=atoi(fn);
  sprintf(fn,"%s",gtk_entry_get_text(GTK_ENTRY(cpy_ent_e)));
  e=atoi(fn);
  sprintf(fn,"%s",gtk_entry_get_text(GTK_ENTRY(cpy_ent_src)));

#ifdef _DEBUG_
  printf("\n\ncpymove_do called");
  printf("\n\nmove: %i * p: %li * e: %li * fn: %s",cpymove,p,e,fn);
  fflush(stdout);
#endif

  i=CopyMsg(fn,p,e,accdata[cpy_acc].foldata[cpy_fld].file);
  if (i!=0)
	{
	sprintf(fn,_("Cannot copy/move message: CopyMsg returned error %i"),i);
	PushMsgStatusbar(fn);
	return;
	}
  if ((i==0) && (cpymove==1))
	{
	i=DelMsg(fn,p,e);
    if (i!=0)
	  {
	  sprintf(fn,_("Cannot move message: Just copied. (DelMsg returned error %i)"),i);
	  PushMsgStatusbar(fn);
	  return;
	  }
	}
  gtk_widget_destroy(cpy_win);
  Update_clist();
  PushMsgStatusbar(_("Copy/Move message complete"));
}




void cpy_opt_fld_change(GtkWidget *widget, gpointer data)
{
  cpy_fld=(int)data;
}


void cpy_opt_acc_change(GtkWidget *widget, gpointer data)
{
  GtkWidget *item;
  int s,i;


  s=(int)data;
  cpy_acc=s;

  cpy_opt_fld_menu=gtk_menu_new();
  for(i=0;i<accdata[s].folders;i++)
    {
    item=gtk_menu_item_new_with_label(accdata[s].foldata[i].name);
    gtk_widget_show(item);
    gtk_signal_connect_object(GTK_OBJECT(item),"activate",GTK_SIGNAL_FUNC(cpy_opt_fld_change),(gpointer)i);
    gtk_menu_append(GTK_MENU(cpy_opt_fld_menu),item);
    }
  gtk_option_menu_set_menu(GTK_OPTION_MENU(cpy_opt_fld), cpy_opt_fld_menu);

}

void msgmenu_func(GtkWidget *widget, gpointer data)
{
FILE *f,*c; int s,i; unsigned long p,e; char a[128];
/*	0: reply
	1: forward
	2: copy
	3: move
	4: del
	5: decode
	6: export
	7: view as html
	8: prev unread
	9: prev
	10: next
	11: next unread

	12: mark
	13: mark as read
	14: mark as unread

//	15: read message
*/
  s=(int)data;

  if ((s==2) || (s==3))
	{
    char text[128];
	GtkWidget *item=NULL;

	if (s==2)
	  cpy_win=create_cpy_win(0);
	else
	  cpy_win=create_cpy_win(1);

	sprintf(text,"%s",accdata[acur].foldata[afol].file);
    gtk_entry_set_text(GTK_ENTRY(cpy_ent_src),text);
    gtk_entry_set_position(GTK_ENTRY(cpy_ent_src),0);

	sprintf(text,"%li",curmail.realstartpos);
    gtk_entry_set_text(GTK_ENTRY(cpy_ent_s),text);
    gtk_entry_set_position(GTK_ENTRY(cpy_ent_s),0);

	sprintf(text,"%li",curmail.endpos);
    gtk_entry_set_text(GTK_ENTRY(cpy_ent_e),text);
    gtk_entry_set_position(GTK_ENTRY(cpy_ent_e),0);

	cpy_opt_acc_menu=gtk_menu_new();
	for(i=0;i<accounts;i++)
      {
  	  item=gtk_menu_item_new_with_label(accdata[i].accname);
  	  gtk_widget_show(item);
  	  gtk_signal_connect_object(GTK_OBJECT(item),"activate",GTK_SIGNAL_FUNC(cpy_opt_acc_change),(gpointer)i);
  	  gtk_menu_append(GTK_MENU(cpy_opt_acc_menu),item);
	  }
	gtk_option_menu_set_menu(GTK_OPTION_MENU(cpy_opt_acc), cpy_opt_acc_menu);

	cpy_opt_acc_change(item,(gpointer)0);

	cpy_acc=0;
	cpy_fld=0;
	gtk_widget_show(cpy_win);

	}

  
  
  if (s==4)
	{
	PushMsgStatusbar(_("Deleting message.."));
    p=DelMsg(accdata[acur].foldata[afol].file,curmail.realstartpos,curmail.endpos);
	if (p!=0)
	  {
	  sprintf(a,_("Could not delete message, error %li"),p);
	  PushMsgStatusbar(a);
	  } else
	  {
	  PushMsgStatusbar(_("Message deleted"));
	  }
	}

  if ((s==5) && (strcmp(curmail.mimeenc[curmail.curpart],"BASE64")==0))
	{
	GtkWidget *filew;
	
    p=curmail.mimecutpos[curmail.curpart];
	if ((curmail.curpart+1)==curmail.mimecount) e=curmail.endpos;
	else e=curmail.mimepos[curmail.curpart+1];
    e=e-strlen(curmail.mimesep)-3;
	
	strcpy(a,accdata[acur].foldata[afol].file);
	ConvertHome(a);
	f=myfopen(a,"r");
    if (f==NULL) return;

	c=fopen("/tmp/sandmail.base64.tmp","w");
    if (c==NULL) return;

    fseek(f,p,SEEK_SET);
    while ((p<e) && (!feof(f)))
  	  {
	  fputc(fgetc(f),c);
	  p++;	
	  }
	fclose(f);
	strcpy(a,accdata[acur].foldata[afol].file);
	ConvertHome(a);
	unlockfolder(a);

	fclose(c);
    chmod("/tmp/sandmail.base64.tmp",S_IRUSR | S_IWUSR);

	filew = gtk_file_selection_new (_("Decode MIME Attachment"));
    gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button),"clicked",(GtkSignalFunc)msgmenu_decode_filesel_ok,filew);
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION (filew)->cancel_button),"clicked",(GtkSignalFunc)gtk_widget_destroy,GTK_OBJECT(filew));
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew),curmail.mimefile[curmail.curpart]);
  	gtk_window_set_modal(GTK_WINDOW(&GTK_FILE_SELECTION(filew)->window),TRUE);
    gtk_widget_show(filew);
	}
  if (s==6)
	{
	GtkWidget *filew;
	filew=gtk_file_selection_new(_("Export Message"));
    gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button),"clicked",(GtkSignalFunc)msgmenu_export_filesel_ok,filew);
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION (filew)->cancel_button),"clicked",(GtkSignalFunc)gtk_widget_destroy,GTK_OBJECT(filew));
    gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew),_("savedmsg.txt"));
	gtk_window_set_modal(GTK_WINDOW(&GTK_FILE_SELECTION(filew)->window),TRUE);
    gtk_widget_show(filew);
	}

  if (s==7)
	{
	view_with_browser();
	}


  if (s==8) // prev unread
	{
#ifdef _CTREE_
	if (ctree!=0)
	  {
	  GtkCTreeNode *g;
	  gchar *t;
	  g=cur_msg_row_ctree;
	  t="R";
	  while ((g!=NULL) && (findstr(t,"R")>=0))
		{
	    g=GTK_CTREE_NODE_PREV(g);
	    gtk_ctree_node_get_text(GTK_CTREE(clist),g,5,&t);
		}
	  if (g!=NULL)
		{
		gtk_signal_emit_by_name(GTK_OBJECT(clist),"tree_select_row",g,1);
		gtk_ctree_node_moveto(GTK_CTREE(clist),g,0,0.5,0);
		}
	  }
	else
#endif
	  {
	  int g;
	  gchar *t;
	  g=cur_msg_row;
	  t="R";
	  while ((g>=0) && (findstr(t,"R")>=0))
		{
	    g--;
	    gtk_clist_get_text(GTK_CLIST(clist),g,5,&t);
		}
	  if (g>=0)
		{
		gtk_signal_emit_by_name(GTK_OBJECT(clist),"select_row",g,1);
		gtk_clist_moveto(GTK_CLIST(clist),g,0,0.5,0);
		}
	  }
	}

  if (s==9) // prev
	{
#ifdef _CTREE_
	if (ctree!=0)
	  {
	  GtkCTreeNode *g;
	  g=GTK_CTREE_NODE_PREV(cur_msg_row_ctree);
	  if (g!=NULL)
		{
		gtk_signal_emit_by_name(GTK_OBJECT(clist),"tree_select_row",g,1);
		gtk_ctree_node_moveto(GTK_CTREE(clist),g,0,0.5,0);
		}
	  }
	else
#endif
	  if (cur_msg_row>0)
		{
		gtk_signal_emit_by_name(GTK_OBJECT(clist),"select_row",cur_msg_row-1,1);
		gtk_clist_moveto(GTK_CLIST(clist),cur_msg_row-1,0,0.5,0);
		}
	}

  if (s==10) // next
	{
#ifdef _CTREE_
	if (ctree!=0)
	  {
	  GtkCTreeNode *g;
	  g=GTK_CTREE_NODE_NEXT(cur_msg_row_ctree);
	  if (g!=NULL)
		{
		gtk_signal_emit_by_name(GTK_OBJECT(clist),"tree_select_row",g,1);
		gtk_ctree_node_moveto(GTK_CTREE(clist),g,0,0.5,0);
		}
	  }
	else
#endif
	  if (cur_msg_row<totmail-1)
		{
		gtk_signal_emit_by_name(GTK_OBJECT(clist),"select_row",cur_msg_row+1,1);
		gtk_clist_moveto(GTK_CLIST(clist),cur_msg_row+1,0,0.5,0);
		}
	}

  if (s==11) // next unread
	{
#ifdef _CTREE_
	if (ctree!=0)
	  {
	  GtkCTreeNode *g;
	  gchar *t;
	  g=cur_msg_row_ctree;
	  t="R";
	  while ((g!=NULL) && (findstr(t,"R")>=0))
		{
	    g=GTK_CTREE_NODE_NEXT(g);
	    gtk_ctree_node_get_text(GTK_CTREE(clist),g,5,&t);
		}
	  if (g!=NULL)
		{
		gtk_signal_emit_by_name(GTK_OBJECT(clist),"tree_select_row",g,1);
		gtk_ctree_node_moveto(GTK_CTREE(clist),g,0,0.5,0);
		}
	  }
	else
#endif
	  {
	  int g;
	  gchar *t;
	  g=cur_msg_row;
	  t="R";
	  while ((g<totmail) && (findstr(t,"R")>=0))
		{
	    g++;
	    gtk_clist_get_text(GTK_CLIST(clist),g,5,&t);
		}
	  if (g<totmail)
		{
		gtk_signal_emit_by_name(GTK_OBJECT(clist),"select_row",g,1);
		gtk_clist_moveto(GTK_CLIST(clist),g,0,0.5,0);
		}
	  }
	}


}

void Servertree_select (GtkWidget *root_tree, GtkWidget *child, GtkWidget *subtree)
{
  GList *i;
  gchar *name;
  GtkLabel *label;
  GtkWidget *item;
  int j,l,a,f;

debugmsg("\n servertree_select");

  i = GTK_TREE_SELECTION(servertree);
  item = GTK_WIDGET (i->data);
  label = GTK_LABEL (GTK_BIN (item)->child);
  gtk_label_get (label, &name);

  a=-1; f=-1;
  for(j=0;((j<accounts) && (a<0));j++) for(l=0;l<accdata[j].folders;l++) 
    if (GTK_WIDGET(child)==GTK_WIDGET(accdata[j].foldata[l].tree)) { a=j; f=l; break; }
	
  // check if clicked on subtree and we aren't there

#ifdef _DEBUG_
  printf("\nservertree_select: *a:%i  *f:%i",a,f); fflush(stdout);
#endif

  if ((a==-1) && (f==-1)) return;
  if (acur==0) acur++;
  if ((a!=acur) || (f!=afol)) { acur=a; afol=f; Update_clist(); }
}



void new_account(GtkWidget *widget, gpointer data)
{
int i;

debugmsg("\n new_account");

Record_Second_Page();

i=accountsbuf;
accountsbuf++;

strcpy(accbuf[i].accname,_("new account"));
strcpy(accbuf[i].username,"");
strcpy(accbuf[i].password,"");
strcpy(accbuf[i].mailserver,"");
strcpy(accbuf[i].mailaddress,"");
strcpy(accbuf[i].replytoaddress,"");
strcpy(accbuf[i].fullname,"");
strcpy(accbuf[i].org,"");
strcpy(accbuf[i].sigfile,"~/.signature");
accbuf[i].leaveonserver=0;
accbuf[i].movetotrash=0;

accbuf[i].folders=1;

strcpy(accbuf[i].foldata[0].name,_("Inbox"));
accbuf[i].foldata[0].status=1;
strcpy(accbuf[i].foldata[0].filter,"");
strcpy(accbuf[i].foldata[0].file,"");

acur=i;
afol=0;

Update_Combo(accbuf,accountsbuf);
Update_FolderCombo(accbuf[i].foldata,accbuf[i].folders);
Update_FolderStatus();

gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(combo_acct)->entry),accbuf[i].accname);
Combo_change(combo_acct,NULL);

if (accountsbuf>1) gtk_widget_set_sensitive(but_delacc,TRUE);

}



void del_account(GtkWidget *widget, gpointer data)
{
int a,i,j;

a=acur;

if (accountsbuf>1)
  {
  for(i=a+1;i<accountsbuf;i++)
    {
    strcpy(accbuf[i-1].accname,accbuf[i].accname);
    strcpy(accbuf[i-1].username,accbuf[i].username);
    strcpy(accbuf[i-1].password,accbuf[i].password);
	strcpy(accbuf[i-1].mailserver,accbuf[i].mailserver);
    strcpy(accbuf[i-1].mailaddress,accbuf[i].mailaddress);
	strcpy(accbuf[i-1].replytoaddress,accbuf[i].replytoaddress);
    strcpy(accbuf[i-1].fullname,accbuf[i].fullname);
	strcpy(accbuf[i-1].org,accbuf[i].org);
	strcpy(accbuf[i-1].sigfile,accbuf[i].sigfile);
    accbuf[i-1].leaveonserver=accbuf[i].leaveonserver;
    accbuf[i-1].movetotrash=accbuf[i].movetotrash;
    accbuf[i-1].folders=accbuf[i].folders;
	for(j=0;j<accbuf[i-1].folders;j++)
	  {
	  strcpy(accbuf[i-1].foldata[j].name,accbuf[i].foldata[j].name);
	  accbuf[i-1].foldata[j].status=accbuf[i].foldata[j].status;
	  strcpy(accbuf[i-1].foldata[j].filter,accbuf[i].foldata[j].filter);
	  strcpy(accbuf[i-1].foldata[j].file,accbuf[i].foldata[j].file);
	  }
    }
  accountsbuf--;
  acur=0; afol=0;

  Update_Combo(accbuf,accountsbuf);
  gtk_list_select_item(GTK_LIST(GTK_COMBO(combo_acct)->list),acur);
  Update_Config(acur);
  }

if (accountsbuf<2) gtk_widget_set_sensitive(but_delacc,FALSE);

}



void new_folder(GtkWidget *widget, gpointer data)
{
int i,a;

debugmsg("\n new_folder");

a=acur;
i=accbuf[a].folders;
accbuf[a].folders++;
afol=i;

strcpy(accbuf[a].foldata[i].name,_("New folder"));
accbuf[a].foldata[i].status=0;
strcpy(accbuf[a].foldata[i].filter,"");
strcpy(accbuf[a].foldata[i].file,"");

Update_FolderCombo(accbuf[a].foldata,accbuf[a].folders);

gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(combo_folder)->entry),accbuf[a].foldata[i].name);
FolderCombo_change(combo_folder,NULL);

if (accbuf[a].folders>1) gtk_widget_set_sensitive(but_delfol,TRUE);
}


void del_folder(GtkWidget *widget, gpointer data)
{
int a,i;
a=acur;

if (accbuf[a].folders>1)
  {
  for(i=afol+1;i<accbuf[a].folders;i++)
    {
    strcpy(accbuf[a].foldata[i-1].name,accbuf[a].foldata[i].name);
    accbuf[a].foldata[i-1].status=accbuf[a].foldata[i].status;
    strcpy(accbuf[a].foldata[i-1].filter,accbuf[a].foldata[i].filter);
    strcpy(accbuf[a].foldata[i-1].file,accbuf[a].foldata[i].file);
    }
  accbuf[a].folders--;
  afol=0;

  Update_FolderCombo(accbuf[a].foldata,accbuf[a].folders);
  Update_FolderStatus();
  }

if (accbuf[a].folders<2) gtk_widget_set_sensitive(but_delfol,FALSE);
}


void hidewin(GtkWidget *w)
{
  gtk_widget_hide(w);
}

void Close_About()
{
 gtk_widget_destroy(aboutwin);
 aboutboxopen=0;
}


void Write_From_Change(GtkWidget *widget, gpointer data)
{
writeid=(int)data;
#ifdef _DEBUG_
  printf("\nWriteId Changed to %i",writeid); fflush(stdout);
#endif
}

void Close_Sendwin()
{
  gtk_widget_destroy(sendwin);
  menu_activate_newmsg(TRUE);
  sendmsgopen=0;
}



void Prepare_Message()
{
/*
FILE *f;
char s[1024];

  f=fopen("/tmp/sandmail.written.tmp","w");
  if (f==NULL) { puts("err!"); exit(255); }

  fprintf(f,"From: \"%s\" <%s>",accdata[writeid].fullname,accdata[writeid].mailaddress);
  strcpy(s,accdata[writeid].replytoaddress);
  if (strcmp(s,"")!=0) fprintf(f,"\nReply-to: %s",s);

  sprintf(s,"%s",gtk_entry_get_text(GTK_ENTRY(ent_wto)));
  if (strcmp(s,"")!=0) fprintf(f,"\nTo: %s",s);

  sprintf(s,"%s",gtk_entry_get_text(GTK_ENTRY(ent_wcc)));
  if (strcmp(s,"")!=0) fprintf(f,"\nCc: %s",s);

  strcpy(s,accdata[writeid].org);
  if (strcmp(s,"")!=0) fprintf(f,"\nOrganisation: %s",s);

  sprintf(s,"%s",gtk_entry_get_text(GTK_ENTRY(ent_wsubj)));
  if (strcmp(s,"")!=0) fprintf(f,"\nSubject: %s",s);

  fprintf(f,"\nX-Mailer: Sandmail 0.0010 Alpha");
  fprintf(f,"\n");

// *DOES NOT WORK*  fwrite(GTK_TEXT(text_w)->text,1,gtk_text_get_length(GTK_TEXT(text_w)),f); 
  fclose(f);

  Close_Sendwin();
*/
}


void clist_clear()
{
  gtk_clist_clear(GTK_CLIST(clist));
  yesmsg=0;
#ifdef _MENUS_
  msg_menu_activate(FALSE);
#endif

}
