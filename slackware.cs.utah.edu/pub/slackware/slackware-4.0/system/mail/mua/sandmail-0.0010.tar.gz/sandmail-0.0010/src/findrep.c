#include "common.h"
#include "findrep.h"

#include <stdio.h>
#include <string.h>

// search find[] in s[] and return starting point
signed int findstr(char s[], char find[])
{
int l,l2,i,j;

  l=strlen(s);
  l2=strlen(find);
  j=0;
  for(i=0;((i<l) && (j<l2));i++)
	if ((s[i] | 32)==(find[j] | 32)) j++; else j=0;
  if (j<l2) j=0;
  if (j==0) return(-1);
  return(i-j);
}


// search find[] in s[] and replace it with rep[]
char replacestr(char s[], char find[], char rep[])
{
char a[256], b[256];
int i,j,l,l2;

i=findstr(s,find);
if (i==-1) return(0);
sprintf(a,"%s",s);
a[i]=0;

strcpy(b,"");
l=strlen(s);
l2=strlen(find);
for(j=i+l2;j<l;j++) b[j-i-l2]=s[j];
b[j-i-l2]=0;
sprintf(s,"%s%s%s",a,rep,b);
return(1);
}

// read a line
void readl(FILE *f, char line[])
{
int ch,p=0;
ch=fgetc(f);
if ((ch=='\n') || (feof(f))) { line[0]=0; return; }
while ((ch!='\n') && (!feof(f)))
{
  line[p]=ch;
  p++;
  ch=fgetc(f);
}
line[p]=0;
}


// iterate in f till found find[]
signed int findf(FILE *f, char finda[])
{
  char ch, find[1024]; int p,l;
  
  l=strlen(finda);
  for(p=0;p<l;p++) find[p]=finda[p] | 32;
  find[l]=0;
  p=0;
  
  while (p<l)
    {
    ch=fgetc(f) | 32;
    if (ch!=find[p]) p=0;
	while ((ch!=find[p]) && (!feof(f)))
	  {
	  ch=fgetc(f) | 32;
	  if (ch!=find[p]) p=0;
	  }
	if (feof(f)) return(-1); // reached end-of-file
	if (ch==find[p]) p++; else p=0;
	}
  if (p==l) return(1); // found
  return(0); // notfound
}


char scandesc(FILE *f, char desc[], char value[])
{
int i; char b[1024];
  
  fseek(f,0,SEEK_SET);

  strcpy(value,"");
  sprintf(b,"\n%s=",desc);
  i=0;
  while ((i<1) && (!feof(f))) i=findf(f,b);
  if (i==1)
	{
	readl(f,value);
	return(1);
	}
  clearerr(f);
  return(0);
}
