#ifndef _XPM_H_
#define _XPM_H_

#include "../xpm/copy.xpm"
#include "../xpm/decode.xpm"
#include "../xpm/delete.xpm"
#include "../xpm/export.xpm"
#include "../xpm/forward.xpm"
#include "../xpm/move.xpm"
#include "../xpm/new.xpm"
#include "../xpm/options.xpm"
#include "../xpm/read.xpm"
#include "../xpm/reply.xpm"
#include "../xpm/about.xpm"
#include "../xpm/html.xpm"
#include "../xpm/logo.xpm"
#include "../xpm/answered.xpm"
#include "../xpm/attachment.xpm"
#include "../xpm/deleted.xpm"
#include "../xpm/flagged.xpm"
#include "../xpm/unread.xpm"

#endif
