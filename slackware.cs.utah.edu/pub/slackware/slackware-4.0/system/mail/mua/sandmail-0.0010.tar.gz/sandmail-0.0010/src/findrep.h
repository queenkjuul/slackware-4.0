#include "common.h"
#include <stdio.h>

signed int findstr(char s[], char find[]);
char replacestr(char s[], char find[], char rep[]);
void readl(FILE *f, char line[]);
signed int findf(FILE *f, char finda[]);
char scandesc(FILE *f, char desc[], char value[]);
