#include "menu.h"
#include "gladesrc.h"
#include <gtk/gtk.h>

#ifdef _MENUS_

static  GtkItemFactoryEntry main_menu_items[] =
	{
  { "/_File",                   NULL,         NULL,      0, "<Branch>" },
  { "/File/_New message",      "<control>W", (GtkSignalFunc)create_sendwin,      0 },
  { "/File/sep1",              NULL,         NULL,      0, "<Separator>" },
  { "/File/_Options",          "<control>O", (GtkSignalFunc)Open_Config,      0 },
  { "/File/sep2",              NULL,         NULL,      0, "<Separator>" },
  { "/File/_Quit",             "<control>Q", (GtkSignalFunc)main_menu_quit,      0 },

  { "/_Mail",                   NULL,         NULL,      0, "<Branch>" },
  { "/Mail/_Get mail",         "<control>G", (GtkSignalFunc)get_mail,      0 },
  { "/Mail/_Send mail",        "<control>S", NULL,      0 },

  { "/M_essage",                NULL,         NULL,      0, "<Branch>" },
//  { "/Message/R_ead",          "<control>E", (GtkSignalFunc)msg_menu_cb,      15 },
  { "/Message/_Reply",          "<control>R", (GtkSignalFunc)msg_menu_cb,      0 },
  { "/Message/_Forward",        "<control>F", (GtkSignalFunc)msg_menu_cb,      1 },
  { "/Message/sep1",           NULL,         NULL,       0, "<Separator>" },
  { "/Message/_Copy",          "<control>C", (GtkSignalFunc)msg_menu_cb,      2 },
  { "/Message/_Move",          "<control>M", (GtkSignalFunc)msg_menu_cb,      3 },
  { "/Message/_Delete",        "<control>D", (GtkSignalFunc)msg_menu_cb,      4 },
  { "/Message/sep2",           NULL,         NULL,       0, "<Separator>" },
  { "/Message/E_xport",        "<control>X", (GtkSignalFunc)msg_menu_cb,      6 },
  { "/Message/View with _browser",  "<control>B", msg_menu_cb,      7 },
  { "/Message/sep3",           NULL,         NULL,       0, "<Separator>" },
  { "/Message/Mar_k",          "<control>K", (GtkSignalFunc)msg_menu_cb,      12 },
  { "/Message/M_ark as Read",  "<control>A", (GtkSignalFunc)msg_menu_cb,      13 },
  { "/Message/Mark as _Unread","<control>U", (GtkSignalFunc)msg_menu_cb,      14 },
  { "/Message/sep4",           NULL,         NULL,       0, "<Separator>" },
  { "/Message/_Prev",          "<control>P",           (GtkSignalFunc)msg_menu_cb,      9 },
  { "/Message/_Next",          "<control>N",           (GtkSignalFunc)msg_menu_cb,      10 },
  { "/Message/P_rev unread",   "<control><shift>P", (GtkSignalFunc)msg_menu_cb,     8 },
  { "/Message/N_ext unread",   "<control><shift>N", (GtkSignalFunc)msg_menu_cb,    11 },

  { "/_Help",                   NULL,         NULL,       0, "<LastBranch>" },
  { "/Help/_About",             NULL,         (GtkSignalFunc)create_aboutwin,       0 },
	};

static  GtkItemFactoryEntry msg_menu_items[] =
	{
  { "/_File",                   NULL,         NULL,      0, "<Branch>" },
  { "/File/_New message",      "<control>W", (GtkSignalFunc)create_sendwin,      0 },
  { "/File/sep1",              NULL,         NULL,      0, "<Separator>" },
  { "/File/_Options",          "<control>O", (GtkSignalFunc)Open_Config,      0 },
  { "/File/sep2",              NULL,         NULL,      0, "<Separator>" },
  { "/File/_Close",             "<control>Q", (GtkSignalFunc)msg_menu_close,      0 },

  { "/_View",                   NULL,         NULL,      0, "<Branch>" },
  { "/View/View with full _headers",   "<control>h", (GtkSignalFunc)msg_menu_toggle,      0, "<ToggleItem>" },
  { "/View/Launch _web browser when html detected",   "<control>w", (GtkSignalFunc)msg_menu_toggle,      1, "<ToggleItem>" },

  { "/M_essage",                NULL,         NULL,      0, "<Branch>" },
  { "/Message/_Reply",          "<control>R", (GtkSignalFunc)msg_menu_cb,      0 },
  { "/Message/_Forward",        "<control>F", (GtkSignalFunc)msg_menu_cb,      1 },
  { "/Message/sep1",           NULL,         NULL,       0, "<Separator>" },
  { "/Message/_Copy",          "<control>C", (GtkSignalFunc)msg_menu_cb,      2 },
  { "/Message/_Move",          "<control>M", (GtkSignalFunc)msg_menu_cb,      3 },
  { "/Message/_Delete",        "<control>D", (GtkSignalFunc)msg_menu_cb,      4 },
  { "/Message/sep2",           NULL,         NULL,       0, "<Separator>" },
  { "/Message/E_xport",        "<control>X", (GtkSignalFunc)msg_menu_cb,      6 },
  { "/Message/View with _browser",  "<control>B", (GtkSignalFunc)msg_menu_cb,      7 },
  { "/Message/sep3",           NULL,         NULL,       0, "<Separator>" },
  { "/Message/Mar_k",          "<control>K", (GtkSignalFunc)msg_menu_cb,      12 },
  { "/Message/M_ark as Read",  "<control>A", (GtkSignalFunc)msg_menu_cb,      13 },
  { "/Message/Mark as _Unread","<control>U", (GtkSignalFunc)msg_menu_cb,      14 },
  { "/Message/sep4",           NULL,         NULL,       0, "<Separator>" },
  { "/Message/_Prev",          "<control>P",           (GtkSignalFunc)msg_menu_cb,      9 },
  { "/Message/_Next",          "<control>N",           (GtkSignalFunc)msg_menu_cb,      10 },
  { "/Message/P_rev unread",   "<control><shift>P", (GtkSignalFunc)msg_menu_cb,     8 },
  { "/Message/N_ext unread",   "<control><shift>N", (GtkSignalFunc)msg_menu_cb,    11 },

  { "/_Help",                   NULL,         NULL,       0, "<LastBranch>" },
  { "/Help/_About",             NULL,         (GtkSignalFunc)create_aboutwin,       0 },
	};


static  GtkItemFactoryEntry send_menu_items[] =
	{
  { "/_File",                   NULL,         NULL,      0, "<Branch>" },
  { "/File/_Send message now",    "<control>Z", (GtkSignalFunc)write_menu_cb,      0 },
  { "/File/_Send message later",  "<control>L", (GtkSignalFunc)write_menu_cb,      1 },
  { "/File/sep1",              NULL,         NULL,      0, "<Separator>" },
  { "/File/_Insert file",     "<control>I", (GtkSignalFunc)write_menu_cb,      2 },
  { "/File/_Attach file",     "<control>A", (GtkSignalFunc)write_menu_cb,      3 },
  { "/File/sep2",              NULL,         NULL,      0, "<Separator>" },
  { "/File/_Options",          "<control>O", (GtkSignalFunc)Open_Config,      0 },
  { "/File/sep3",              NULL,         NULL,      0, "<Separator>" },
  { "/File/_Close",            "<control>Q", (GtkSignalFunc)write_menu_cb,      4 },

  { "/_PGP",                   NULL,         NULL,      0, "<Branch>" },
  { "/PGP/_Sign this message",       	   NULL,		 (GtkSignalFunc)write_pgp_menu_toggle,      1, "<ToggleItem>" },
  { "/PGP/_Encrypt this message",          NULL,		 (GtkSignalFunc)write_pgp_menu_toggle,      2, "<ToggleItem>" },

  { "/_Help",                   NULL,         NULL,       0, "<LastBranch>" },
  { "/Help/_About",             NULL,         (GtkSignalFunc)create_aboutwin,       0 },
	};

#endif
