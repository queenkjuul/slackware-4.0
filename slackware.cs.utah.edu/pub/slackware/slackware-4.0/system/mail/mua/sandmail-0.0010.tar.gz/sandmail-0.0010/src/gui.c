#include "common.h"

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>

#include <gtk/gtk.h>
#include "gladesrc.h"
#include "gui.h"
#include "main.h"
#include "struc.h"
#include "folder.h"
#include "findrep.h"
#include "xpm.h"
#include "getmail.h"
#include "menu.h"

void progress_update(unsigned long cur)
{
float a;

a=(float)cur/(float)totprogress;

if ((a!=mprogperc) && (a>=0) && (a<=1))
  {
  gtk_progress_bar_update(GTK_PROGRESS_BAR(progbar),a);
  while (gtk_events_pending()) gtk_main_iteration();
  mprogperc=a;
  }

}


GtkWidget*
create_main ()
{
  GtkWidget *win;
  GtkWidget *vbox1;
  GtkWidget *hbox1; 
  GtkWidget *handlebox;
  GtkWidget *hpaned;
  GtkWidget *labelFrom;
  GtkWidget *labelDate;
  GtkWidget *labelTo;
  GtkWidget *labelSubj;
  GtkWidget *labelFlags;
  GtkWidget *scrolledwindow1;
  GtkWidget *toolbarwidget;


  win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_usize(win, 650, 325);
  gtk_window_set_title(GTK_WINDOW(win), _("Sandmail"));
  gtk_window_set_policy(GTK_WINDOW(win), TRUE, TRUE, TRUE);
  gtk_window_position (GTK_WINDOW (win), GTK_WIN_POS_CENTER);
  gtk_widget_realize(win);

  gtk_signal_connect (GTK_OBJECT(win),"delete_event",GTK_SIGNAL_FUNC(delete_event),NULL);
  gtk_signal_connect (GTK_OBJECT(win),"destroy",GTK_SIGNAL_FUNC(destroy),NULL);


  vbox1 = gtk_vbox_new(FALSE, 0);
  gtk_widget_show(vbox1);
  gtk_container_add(GTK_CONTAINER(win), vbox1);

#ifdef _MENUS_
  handlebox = gtk_handle_box_new();
  gtk_widget_show(handlebox);
  gtk_box_pack_start(GTK_BOX(vbox1), handlebox, FALSE, FALSE, 0);
  gtk_container_add (GTK_CONTAINER(handlebox), create_menu(win,0));
#endif

  handlebox = gtk_handle_box_new();
  gtk_widget_show(handlebox);
  gtk_box_pack_start(GTK_BOX(vbox1), handlebox, FALSE, TRUE, 0);

  if (icons==0)	toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_ICONS);
  if (icons==1)	toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_TEXT);
  if (icons==2) toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
  gtk_container_add (GTK_CONTAINER(handlebox), toolbar);

#ifdef _TOOLBAR_BORDERS_
//  gtk_toolbar_set_button_relief (GTK_TOOLBAR (toolbar), GTK_RELIEF_NORMAL);
  gtk_toolbar_set_button_relief (GTK_TOOLBAR (toolbar), GTK_RELIEF_NONE);
#endif
//  SetToolbarTipColor(toolbar);

  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),_("Get mail"), _("Check for mail"), "",
			       new_pixmap (reply_xpm, win->window, &win->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)get_mail, NULL);

  toolbarwidget=gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),_("Send mail"), _("Send mail in Outbox"), "",
			       new_pixmap (forward_xpm, win->window, &win->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)NULL, NULL);
  gtk_widget_set_sensitive(toolbarwidget,FALSE);

  mainwin_but_compose=gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),_("Compose"), _("Write a message"), "",
			       new_pixmap (new_xpm, win->window, &win->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)create_sendwin, NULL);

  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),_("Options"), _("Options..."), "",
			       new_pixmap (options_xpm, win->window, &win->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)Open_Config, NULL);

  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),_("About"), _("About the author"), "",
			       new_pixmap (about_xpm, win->window, &win->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)create_aboutwin, NULL);

  gtk_widget_show (toolbar);

  hpaned = gtk_hpaned_new();
  gtk_widget_show(hpaned);
  gtk_box_pack_start(GTK_BOX(vbox1), hpaned, TRUE, TRUE, 0);
  DoToolTips(hpaned, _("Click and drag to resize"));

  scrolledwindow1 = gtk_scrolled_window_new(NULL, NULL); // scrolledwindow for servertree
  gtk_widget_show(scrolledwindow1);
  gtk_container_add(GTK_CONTAINER(hpaned), scrolledwindow1);

  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledwindow1), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_widget_set_usize(scrolledwindow1, 120, -1);

  servertree = gtk_tree_new();
  gtk_tree_set_selection_mode (GTK_TREE(servertree),GTK_SELECTION_BROWSE);
  
  gtk_widget_show(servertree);
//  gtk_container_add(GTK_CONTAINER(scrolledwindow1), servertree);
gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolledwindow1), servertree);


  DoToolTips(servertree, _("Select the server folder you wish to browse"));

  gtk_signal_connect (GTK_OBJECT(servertree), "select_child", GTK_SIGNAL_FUNC(Servertree_select), servertree);


  scrolledwindow1 = gtk_scrolled_window_new (NULL, NULL); // scrolledwindow for clist/ctree
  gtk_widget_show (scrolledwindow1);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow1), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

  gtk_container_add (GTK_CONTAINER (hpaned), scrolledwindow1);

#ifdef _CTREE_
  if (ctree!=0) clist = gtk_ctree_new(6,0); else 
#endif
			    clist = gtk_clist_new(6);

//  gtk_container_add(GTK_CONTAINER(hpaned), clist);

//  gtk_container_add (GTK_CONTAINER (scrolledwindow1), clist);
gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolledwindow1), clist);

  gtk_clist_set_column_width(GTK_CLIST(clist), 0, 10);
  gtk_clist_set_column_width(GTK_CLIST(clist), 1, 40);
  gtk_clist_set_column_width(GTK_CLIST(clist), 2, 140);
  gtk_clist_set_column_width(GTK_CLIST(clist), 3, 120);
  gtk_clist_set_column_width(GTK_CLIST(clist), 4, 120);
  gtk_clist_set_column_width(GTK_CLIST(clist), 5, 15);
  gtk_clist_column_titles_show(GTK_CLIST(clist));

#ifndef _NO_CLIST_POLICY_
  gtk_clist_set_policy(GTK_CLIST(clist), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
#endif

  gtk_widget_show(clist);

#ifdef _CTREE_
  if (ctree!=0) 
	{
	gtk_signal_connect(GTK_OBJECT(clist),"tree_select_row",GTK_SIGNAL_FUNC(ctree_select),NULL);
	gtk_signal_connect(GTK_OBJECT(clist),"click_column",(GtkSignalFunc)ctree_click_column,NULL);
	gtk_ctree_set_line_style(GTK_CTREE(clist), GTK_CTREE_LINES_DOTTED);
//	gtk_ctree_set_line_style(GTK_CTREE(clist), GTK_CTREE_LINES_NONE);
//	gtk_ctree_set_line_style(GTK_CTREE(clist), GTK_CTREE_LINES_TABBED);
	gtk_ctree_set_reorderable(GTK_CTREE(clist), FALSE);
	gtk_ctree_set_indent(GTK_CTREE(clist),10);
	} else
#endif
	{
	gtk_signal_connect(GTK_OBJECT(clist),"select_row",GTK_SIGNAL_FUNC(clist_select),NULL);
#ifdef _CLISTSORT_
    gtk_signal_connect(GTK_OBJECT(clist),"click_column",(GtkSignalFunc)clist_click_column,NULL);
#endif
	}

  Prepare_ServerTree(servertree);

  labelDate = gtk_label_new(_("#"));
  gtk_widget_show(labelDate);
  gtk_clist_set_column_widget(GTK_CLIST(clist), 0, labelDate);
  gtk_label_set_justify(GTK_LABEL(labelDate), GTK_JUSTIFY_CENTER);
  gtk_misc_set_alignment(GTK_MISC(labelDate), 0.5, 0);

  labelFrom = gtk_label_new(_("From"));
  gtk_widget_show(labelFrom);
  gtk_clist_set_column_widget(GTK_CLIST(clist), 3, labelFrom);
  gtk_label_set_justify(GTK_LABEL(labelFrom), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment(GTK_MISC(labelFrom), 0, 0);

  labelDate = gtk_label_new(_("Date"));
  gtk_widget_show(labelDate);
  gtk_clist_set_column_widget(GTK_CLIST(clist), 1, labelDate);
  gtk_label_set_justify(GTK_LABEL(labelDate), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment(GTK_MISC(labelDate), 0, 0);

  labelTo = gtk_label_new(_("To"));
  gtk_widget_show(labelTo);
  gtk_clist_set_column_widget(GTK_CLIST(clist), 4, labelTo);
  gtk_label_set_justify(GTK_LABEL(labelTo), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment(GTK_MISC(labelTo), 0, 0);

  labelSubj = gtk_label_new(_("Subject"));
  gtk_widget_show(labelSubj);
  gtk_clist_set_column_widget(GTK_CLIST(clist), 2, labelSubj);
  gtk_label_set_justify(GTK_LABEL(labelSubj), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment(GTK_MISC(labelSubj), 0, 0);

  labelFlags = gtk_label_new(_("Flags"));
  gtk_widget_show(labelFlags);
  gtk_clist_set_column_widget(GTK_CLIST(clist), 5, labelFlags);
  gtk_label_set_justify(GTK_LABEL(labelFlags), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment(GTK_MISC(labelFlags), 0, 0.5);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (hbox1);
  gtk_box_pack_start(GTK_BOX(vbox1), hbox1, FALSE, TRUE, 0);

  statusbar = gtk_statusbar_new();
  gtk_widget_show(statusbar);
//  gtk_box_pack_start(GTK_BOX(vbox1), statusbar, FALSE, TRUE, 0);
  gtk_box_pack_start (GTK_BOX (hbox1), statusbar, TRUE, TRUE, 0);

  statusbar_id=gtk_statusbar_get_context_id(GTK_STATUSBAR(statusbar),"Main window Statusbar");
  statusbar_total=0;

  progbar = gtk_progress_bar_new ();
  gtk_widget_show (progbar);
  gtk_box_pack_start (GTK_BOX (hbox1), progbar, FALSE, TRUE, 0);
#ifdef _DISCRETE_PROGRESSBAR_
  gtk_progress_bar_set_discrete_blocks (GTK_PROGRESS_BAR(progbar),10);
  gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR(progbar),GTK_PROGRESS_DISCRETE);
#endif
  gtk_progress_bar_update(GTK_PROGRESS_BAR(progbar),0.0);

  return win;
}

GtkWidget*
create_config ()
{
  GtkWidget *config;
  GtkWidget *dialog_vbox1;
  GtkWidget *notebook1;
  GtkWidget *label3;
  GtkWidget *table1,*table0,*table2,*table3;
  GtkWidget *label1;
  GtkWidget *label11;
  GtkWidget *label10;
  GtkWidget *label16;
  GtkWidget *label17;
  GtkWidget *label18;
  GtkWidget *label9;
  GtkWidget *label8;
  GtkWidget *label7;
  GtkWidget *label6;
  GtkWidget *label5;
  GtkWidget *label4;
  GtkWidget *dialog_action_area1;
  GtkWidget *tlabel1, *tlabel2;
  GtkWidget *hbox3;
  GtkWidget *hbox2;
  GtkWidget *label12;
  GtkWidget *vseparator1;
  
  GtkWidget *button_ok;
  GtkWidget *button_save;
  GtkWidget *button_cancel;

  GtkWidget *radio_vbox;
  GtkWidget *radio_frame;
  GtkWidget *pgpframe;
  
  config = gtk_dialog_new();
  gtk_object_set_data(GTK_OBJECT(config), "config", config);
  gtk_window_set_title(GTK_WINDOW(config), _("Configuration"));
  gtk_window_set_policy(GTK_WINDOW(config), FALSE, FALSE, TRUE);
  gtk_window_position (GTK_WINDOW (config), GTK_WIN_POS_CENTER);
  gtk_signal_connect(GTK_OBJECT(config),"delete_event",GTK_SIGNAL_FUNC(Close_Config_delete_event),NULL);

  dialog_vbox1 = GTK_DIALOG (config)->vbox;
  gtk_widget_show(dialog_vbox1);

  notebook1 = gtk_notebook_new();
  gtk_notebook_set_tab_border(GTK_NOTEBOOK(notebook1), 2);
  gtk_notebook_set_show_tabs (GTK_NOTEBOOK(notebook1), TRUE);
#ifdef _POPUP_NOTEBOOK_
  gtk_notebook_popup_enable(GTK_NOTEBOOK(notebook1));
#endif
#ifdef _SCROLLABLE_NOTEBOOK_
  gtk_notebook_set_scrollable(GTK_NOTEBOOK(notebook1),TRUE);
#endif
  gtk_widget_show(notebook1);
  gtk_box_pack_start(GTK_BOX(dialog_vbox1), notebook1, TRUE, TRUE, 0);


  table0 = gtk_table_new(6, 3, FALSE); // y,x
  gtk_widget_show(table0);
  gtk_table_set_col_spacings(GTK_TABLE(table0), 3);

  tlabel1=gtk_label_new(_("General"));
  gtk_widget_show(tlabel1);
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook1),table0,tlabel1);


  label3 = gtk_label_new("");
  gtk_widget_show(label3);
   gtk_table_attach (GTK_TABLE (table0), label3, 0, 3, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  label3 = gtk_label_new("");
  gtk_widget_show(label3);
  gtk_table_attach (GTK_TABLE (table0), label3, 2, 3, 1, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label3 = gtk_label_new(_("SMTP server:"));
  gtk_widget_show(label3);
  gtk_table_attach(GTK_TABLE(table0), label3, 0, 1, 0, 1,
                  /* GTK_EXPAND |*/ GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label3), 1, 0.5);

  ent_smtp = gtk_entry_new_with_max_length(50);
  gtk_entry_set_text(GTK_ENTRY(ent_smtp),smtpserver);
  gtk_widget_show(ent_smtp);
  gtk_table_attach(GTK_TABLE(table0), ent_smtp, 1, 2, 0, 1,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label3 = gtk_label_new(_("Web Browser:"));
  gtk_widget_show(label3);
  gtk_table_attach(GTK_TABLE(table0), label3, 0, 1, 1, 2,
                /*   GTK_EXPAND  |*/ GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label3), 1, 0.5);

  ent_webb = gtk_entry_new_with_max_length(50);
  gtk_entry_set_text(GTK_ENTRY(ent_webb),webbrowser);
  gtk_widget_show(ent_webb);
  gtk_table_attach(GTK_TABLE(table0), ent_webb, 1, 2, 1, 2,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  chk_autoweb = gtk_check_button_new_with_label(_("Launch web browser automatically when text/html detected"));
  gtk_widget_show(chk_autoweb);
  gtk_table_attach(GTK_TABLE(table0), chk_autoweb, 0, 2, 2, 3,
                   GTK_FILL | GTK_EXPAND | GTK_SHRINK, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 40, 0);
  if (autoweb==0) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_autoweb), FALSE);
		     else gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_autoweb), TRUE);



  chk_thread = gtk_check_button_new_with_label(_("(Experimental) Thread messages"));
  gtk_widget_show(chk_thread);
  gtk_table_attach(GTK_TABLE(table0), chk_thread, 0, 2, 3, 4,
                   GTK_FILL | GTK_EXPAND | GTK_SHRINK, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 40, 0);
  if (threadmsgs==0) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_thread), FALSE);
		     else gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_thread), TRUE);

#ifndef _CTREE_
  gtk_widget_set_sensitive(chk_thread, FALSE);
#endif

  chk_fullhead = gtk_check_button_new_with_label(_("View messages with full headers"));
  gtk_widget_show(chk_fullhead);
  gtk_table_attach(GTK_TABLE(table0), chk_fullhead, 0, 2, 5, 6,
                   GTK_FILL | GTK_EXPAND | GTK_SHRINK, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 40, 0);
  if (fullhead==0) gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_fullhead), FALSE);
		     else gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON (chk_fullhead), TRUE);


  radio_frame = gtk_frame_new (_(" Show Toolbar Icons As "));
  gtk_container_border_width (GTK_CONTAINER (radio_frame), 5);
  gtk_widget_show (radio_frame);
  gtk_widget_set_usize(radio_frame,-1,-1);
  gtk_frame_set_label_align (GTK_FRAME(radio_frame), 0.02, 0.5);
  gtk_table_attach(GTK_TABLE(table0), radio_frame, 1, 2, 4, 5,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  radio_vbox = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (radio_vbox);
  gtk_container_add (GTK_CONTAINER (radio_frame), radio_vbox);

  cfg_radio[0] = gtk_radio_button_new_with_label (radio_group, _("Pictures"));
  radio_group = gtk_radio_button_group (GTK_RADIO_BUTTON (cfg_radio[0]));
  gtk_widget_show (cfg_radio[0]);
  gtk_widget_set_usize(cfg_radio[0],-1,-1);
  gtk_box_pack_start (GTK_BOX (radio_vbox), cfg_radio[0], FALSE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(cfg_radio[0]),"toggled",GTK_SIGNAL_FUNC(toggle_button_callback),(gpointer)0);

  cfg_radio[1] = gtk_radio_button_new_with_label (radio_group, _("Text"));
  radio_group = gtk_radio_button_group (GTK_RADIO_BUTTON (cfg_radio[1]));
  gtk_widget_show (cfg_radio[1]);
  gtk_widget_set_usize(cfg_radio[1],-1,-1);
  gtk_box_pack_start (GTK_BOX (radio_vbox), cfg_radio[1], FALSE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(cfg_radio[1]),"toggled",GTK_SIGNAL_FUNC(toggle_button_callback),(gpointer)1);

  cfg_radio[2] = gtk_radio_button_new_with_label (radio_group, _("Pictures & Text"));
  radio_group = gtk_radio_button_group (GTK_RADIO_BUTTON (cfg_radio[2]));
  gtk_widget_show (cfg_radio[2]);
  gtk_widget_set_usize(cfg_radio[2],-1,-1);
  gtk_box_pack_start (GTK_BOX (radio_vbox), cfg_radio[2], FALSE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(cfg_radio[2]),"toggled",GTK_SIGNAL_FUNC(toggle_button_callback),(gpointer)2);
  
  gtk_toggle_button_set_state (GTK_TOGGLE_BUTTON (cfg_radio[icons]), TRUE);


  table1 = gtk_table_new(12, 5, FALSE);
  gtk_widget_show(table1);
  gtk_table_set_col_spacings(GTK_TABLE(table1), 3);

  tlabel2=gtk_label_new(_("Accounts"));
  gtk_widget_show(tlabel2);
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook1),table1,tlabel2);

  hbox3 = gtk_hbox_new(FALSE, 0);
  gtk_widget_show(hbox3);
  gtk_table_attach(GTK_TABLE(table1), hbox3, 0, 2, 11, 12,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  but_newacc = gtk_button_new_with_label(_("New"));
  gtk_widget_show(but_newacc);
  gtk_box_pack_start(GTK_BOX(hbox3), but_newacc, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(but_newacc),"clicked",GTK_SIGNAL_FUNC(new_account),NULL);

  but_delacc = gtk_button_new_with_label(_("Delete"));
  gtk_widget_show(but_delacc);
  gtk_box_pack_start(GTK_BOX(hbox3), but_delacc, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(but_delacc),"clicked",GTK_SIGNAL_FUNC(del_account),NULL);

  hbox2 = gtk_hbox_new(TRUE, 0);
  gtk_widget_show(hbox2);
  gtk_table_attach(GTK_TABLE(table1), hbox2, 3, 5, 11, 12,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  ent_filter = gtk_entry_new_with_max_length(50);
  gtk_widget_show(ent_filter);
  gtk_table_attach(GTK_TABLE(table1), ent_filter, 4, 5, 4, 5,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_entry_set_editable(GTK_ENTRY(ent_filter), FALSE);
  gtk_signal_connect(GTK_OBJECT(ent_filter),"focus_out_event",GTK_SIGNAL_FUNC(Folder_Filter),NULL);

  label18 = gtk_label_new(_("Filter script:"));
  gtk_widget_show(label18);
  gtk_table_attach(GTK_TABLE(table1), label18, 3, 4, 4, 5,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label18), 1, 0.5);
  
  opt_foldertype = gtk_option_menu_new();
  gtk_widget_show(opt_foldertype);
  gtk_table_attach(GTK_TABLE(table1), opt_foldertype, 4, 5, 3, 4,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
	   
  opt_foldertype_menu = gtk_menu_new();

  
  menuitem[0] = gtk_menu_item_new_with_label(_("Normal"));
  gtk_widget_show(menuitem[0]);
  gtk_signal_connect_object(GTK_OBJECT(menuitem[0]),"activate",GTK_SIGNAL_FUNC(Folder_Option_Change),(gpointer)0);
  gtk_menu_append(GTK_MENU(opt_foldertype_menu), menuitem[0]);
  
  menuitem[1] = gtk_menu_item_new_with_label(_("Inbox"));
  gtk_widget_show(menuitem[1]);
  gtk_signal_connect_object(GTK_OBJECT(menuitem[1]),"activate",GTK_SIGNAL_FUNC(Folder_Option_Change),(gpointer)1);
  gtk_menu_append(GTK_MENU(opt_foldertype_menu), menuitem[1]);

  menuitem[2] = gtk_menu_item_new_with_label(_("Outbox"));
  gtk_widget_show(menuitem[2]);
  gtk_signal_connect_object(GTK_OBJECT(menuitem[2]),"activate",GTK_SIGNAL_FUNC(Folder_Option_Change),(gpointer)2);
  gtk_menu_append(GTK_MENU(opt_foldertype_menu), menuitem[2]);

  menuitem[3] = gtk_menu_item_new_with_label(_("Sent mail"));
  gtk_widget_show(menuitem[3]);
  gtk_signal_connect_object(GTK_OBJECT(menuitem[3]),"activate",GTK_SIGNAL_FUNC(Folder_Option_Change),(gpointer)3);
  gtk_menu_append(GTK_MENU(opt_foldertype_menu), menuitem[3]);

  menuitem[4] = gtk_menu_item_new_with_label(_("Trash"));
  gtk_widget_show(menuitem[4]);
  gtk_signal_connect_object(GTK_OBJECT(menuitem[4]),"activate",GTK_SIGNAL_FUNC(Folder_Option_Change),(gpointer)4);
  gtk_menu_append(GTK_MENU(opt_foldertype_menu), menuitem[4]);

  menuitem[5] = gtk_menu_item_new_with_label(_("Filtered"));
  gtk_widget_show(menuitem[5]);
  gtk_signal_connect_object(GTK_OBJECT(menuitem[5]),"activate",GTK_SIGNAL_FUNC(Folder_Option_Change),(gpointer)5);
  gtk_menu_append(GTK_MENU(opt_foldertype_menu), menuitem[5]);

  gtk_option_menu_set_menu(GTK_OPTION_MENU(opt_foldertype), opt_foldertype_menu);

  label17 = gtk_label_new(_("Folder type:"));
  gtk_widget_show(label17);
  gtk_table_attach(GTK_TABLE(table1), label17, 3, 4, 3, 4,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label17), 1, 0.5);

  ent_folderfile = gtk_entry_new_with_max_length(50);
  gtk_widget_show(ent_folderfile);
  gtk_table_attach(GTK_TABLE(table1), ent_folderfile, 4, 5, 1, 2,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_signal_connect (GTK_OBJECT(ent_folderfile),"focus_out_event",GTK_SIGNAL_FUNC(Folder_File),NULL);

  label16 = gtk_label_new(_("Folder file:"));
  gtk_widget_show(label16);
  gtk_table_attach(GTK_TABLE(table1), label16, 3, 4, 1, 2,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label16), 1, 0.5);

  label12 = gtk_label_new(_("Folder name:"));
  gtk_widget_show(label12);
  gtk_table_attach(GTK_TABLE(table1), label12, 3, 4, 0, 1,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label12), 1, 0.5);

  but_newfol = gtk_button_new_with_label(_("New"));
  gtk_widget_show(but_newfol);
  gtk_box_pack_start(GTK_BOX(hbox2), but_newfol, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(but_newfol),"clicked",GTK_SIGNAL_FUNC(new_folder),NULL);

  but_delfol = gtk_button_new_with_label(_("Delete"));
  gtk_widget_show(but_delfol);
  gtk_box_pack_start(GTK_BOX(hbox2), but_delfol, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(but_delfol),"clicked",GTK_SIGNAL_FUNC(del_folder),NULL);

  combo_folder = gtk_combo_new();
  gtk_table_attach(GTK_TABLE(table1), combo_folder, 4, 5, 0, 1,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  Update_FolderCombo(accdata[acur].foldata,accdata[acur].folders);
  gtk_signal_connect(GTK_OBJECT(GTK_LIST(GTK_COMBO(combo_folder)->list)),"selection_changed",GTK_SIGNAL_FUNC(FolderCombo_change),NULL);
  gtk_widget_show(combo_folder);

gtk_combo_set_value_in_list(GTK_COMBO(combo_folder), FALSE, FALSE); // **



  vseparator1 = gtk_vseparator_new();
  gtk_widget_show(vseparator1);
  gtk_table_attach(GTK_TABLE(table1), vseparator1, 2, 3, 0, 11,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 10, 5);

  chk_leave = gtk_check_button_new_with_label(_("Leave messages on server"));
  gtk_widget_show(chk_leave);
  gtk_table_attach(GTK_TABLE(table1), chk_leave, 0, 2, 9, 10,
                   GTK_FILL | GTK_EXPAND | GTK_SHRINK, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 40, 0);

  chk_trash = gtk_check_button_new_with_label(_("Move deleted msgs in Trash box"));
  gtk_widget_show(chk_trash);
  gtk_table_attach(GTK_TABLE(table1), chk_trash, 0, 2, 10, 11,
                   GTK_FILL | GTK_EXPAND | GTK_SHRINK, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 40, 0);

  label11 = gtk_label_new(_("Password:"));
  gtk_widget_show(label11);
  gtk_table_attach(GTK_TABLE(table1), label11, 0, 1, 7, 8,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label11), 1, 0.5);

// **
  label11 = gtk_label_new(_("Signature file:"));
  gtk_widget_show(label11);
  gtk_table_attach(GTK_TABLE(table1), label11, 0, 1, 8, 9,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label11), 1, 0.5);

  label10 = gtk_label_new(_("Username:"));
  gtk_widget_show(label10);
  gtk_table_attach(GTK_TABLE(table1), label10, 0, 1, 6, 7,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label10), 1, 0.5);

  label9 = gtk_label_new(_("POP3 Mail server:"));
  gtk_widget_show(label9);
  gtk_table_attach(GTK_TABLE(table1), label9, 0, 1, 5, 6,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label9), 1, 0.5);

  label8 = gtk_label_new(_("Organisation:"));
  gtk_widget_show(label8);
  gtk_table_attach(GTK_TABLE(table1), label8, 0, 1, 4, 5,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label8), 1, 0.5);

  label7 = gtk_label_new(_("Full name:"));
  gtk_widget_show(label7);
  gtk_table_attach(GTK_TABLE(table1), label7, 0, 1, 3, 4,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label7), 1, 0.5);

  label6 = gtk_label_new(_("Reply-to address:"));
  gtk_widget_show(label6);
  gtk_table_attach(GTK_TABLE(table1), label6, 0, 1, 2, 3,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label6), 1, 0.5);

  label5 = gtk_label_new(_("Mail address:"));
  gtk_widget_show(label5);
  gtk_table_attach(GTK_TABLE(table1), label5, 0, 1, 1, 2,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label5), 1, 0.5);

  label4 = gtk_label_new(_("Account name:"));
  gtk_widget_show(label4);
  gtk_table_attach(GTK_TABLE(table1), label4, 0, 1, 0, 1,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label4), 1, 0.5);


  ent_password = gtk_entry_new();
  gtk_widget_show(ent_password);
  gtk_table_attach(GTK_TABLE(table1), ent_password, 1, 2, 7, 8,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
#ifdef _ENTRY_VISIBILITY_
  gtk_entry_set_visibility(GTK_ENTRY(ent_password),FALSE);
#endif


  ent_username = gtk_entry_new();
  gtk_widget_show(ent_username);
  gtk_table_attach(GTK_TABLE(table1), ent_username, 1, 2, 6, 7,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);


  ent_pop3server = gtk_entry_new();
  gtk_widget_show(ent_pop3server);
  gtk_table_attach(GTK_TABLE(table1), ent_pop3server, 1, 2, 5, 6,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  ent_org = gtk_entry_new();
  gtk_widget_show(ent_org);
  gtk_table_attach(GTK_TABLE(table1), ent_org, 1, 2, 4, 5,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  ent_fullname = gtk_entry_new();
  gtk_widget_show(ent_fullname);
  gtk_table_attach(GTK_TABLE(table1), ent_fullname, 1, 2, 3, 4,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  ent_replyto = gtk_entry_new();
  gtk_widget_show(ent_replyto);
  gtk_table_attach(GTK_TABLE(table1), ent_replyto, 1, 2, 2, 3,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  ent_mail = gtk_entry_new();
  gtk_widget_show(ent_mail);
  gtk_table_attach(GTK_TABLE(table1), ent_mail, 1, 2, 1, 2,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  ent_sigfile = gtk_entry_new();
  gtk_widget_show(ent_sigfile);
  gtk_table_attach(GTK_TABLE(table1), ent_sigfile, 1, 2, 8, 9,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  combo_acct = gtk_combo_new();
  
  Update_Combo(accdata,accounts);

gtk_combo_set_value_in_list(GTK_COMBO(combo_acct), FALSE, FALSE); // **

  gtk_widget_show(combo_acct);
  gtk_table_attach(GTK_TABLE(table1), combo_acct, 1, 2, 0, 1,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_signal_connect(GTK_OBJECT(GTK_LIST(GTK_COMBO(combo_acct)->list)),"selection_changed",GTK_SIGNAL_FUNC(Combo_change),NULL);
  gtk_signal_connect(GTK_OBJECT(GTK_COMBO(combo_acct)),"focus_in_event",GTK_SIGNAL_FUNC(RecSecond),NULL);
  gtk_signal_connect(GTK_OBJECT(GTK_ENTRY(GTK_COMBO(combo_acct)->entry)),"focus_in_event",GTK_SIGNAL_FUNC(RecSecond),NULL);
  gtk_signal_connect(GTK_OBJECT(GTK_COMBO(combo_acct)->button),"focus_in_event",GTK_SIGNAL_FUNC(RecSecond),NULL);

  dialog_action_area1 = GTK_DIALOG (config)->action_area;
  gtk_widget_show(dialog_action_area1);
  gtk_container_border_width(GTK_CONTAINER(dialog_action_area1), 7);

  button_ok = gtk_button_new_with_label(_("Ok"));
  gtk_widget_show(button_ok);
  gtk_box_pack_start(GTK_BOX(dialog_action_area1), button_ok, TRUE, TRUE, 0);
  GTK_WIDGET_SET_FLAGS(button_ok, GTK_CAN_DEFAULT);
  gtk_signal_connect (GTK_OBJECT(button_ok),"clicked",GTK_SIGNAL_FUNC(Ok_Close_Config),NULL);

  button_save = gtk_button_new_with_label(_("Save"));
  gtk_widget_show(button_save);
  gtk_box_pack_start(GTK_BOX(dialog_action_area1), button_save, TRUE, TRUE, 0);
  GTK_WIDGET_SET_FLAGS(button_save, GTK_CAN_DEFAULT);
  gtk_signal_connect (GTK_OBJECT(button_save),"clicked",GTK_SIGNAL_FUNC(Save_Close_Config),NULL);

  button_cancel = gtk_button_new_with_label(_("Cancel"));
  gtk_widget_show(button_cancel);
  gtk_box_pack_start(GTK_BOX(dialog_action_area1), button_cancel, TRUE, TRUE, 0);
  GTK_WIDGET_SET_FLAGS(button_cancel, GTK_CAN_DEFAULT);
  gtk_signal_connect (GTK_OBJECT(button_cancel),"clicked",GTK_SIGNAL_FUNC(Close_Config),(gpointer)0);

  Update_Config(acur);




  table2 = gtk_table_new(6, 3, FALSE); // y,x
  gtk_widget_show(table2);
  gtk_table_set_col_spacings(GTK_TABLE(table2), 3);

  tlabel1=gtk_label_new(_("PGP"));
  gtk_widget_show(tlabel1);
  gtk_notebook_append_page(GTK_NOTEBOOK(notebook1),table2,tlabel1);

  label1 = gtk_label_new("");
  gtk_widget_show(label1);
  gtk_table_attach(GTK_TABLE(table2), label1, 2, 3, 0, 6,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_widget_set_usize(label1,60,-1);

  label1 = gtk_label_new(_("pgpe executable:"));
  gtk_widget_show(label1);
  gtk_table_attach(GTK_TABLE(table2), label1, 0, 1, 0, 1,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label1), 1, 0.5);
  ent_pgpe = gtk_entry_new();
  gtk_widget_show(ent_pgpe);
  gtk_table_attach(GTK_TABLE(table2), ent_pgpe, 1, 2, 0, 1,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label1 = gtk_label_new(_("pgps executable:"));
  gtk_widget_show(label1);
  gtk_table_attach(GTK_TABLE(table2), label1, 0, 1, 1, 2,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label1), 1, 0.5);
  ent_pgps = gtk_entry_new();
  gtk_widget_show(ent_pgps);
  gtk_table_attach(GTK_TABLE(table2), ent_pgps, 1, 2, 1, 2,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label1 = gtk_label_new(_("pgpv executable:"));
  gtk_widget_show(label1);
  gtk_table_attach(GTK_TABLE(table2), label1, 0, 1, 2, 3,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label1), 1, 0.5);
  ent_pgpv = gtk_entry_new();
  gtk_widget_show(ent_pgpv);
  gtk_table_attach(GTK_TABLE(table2), ent_pgpv, 1, 2, 2, 3,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label1 = gtk_label_new(_("pgp userid:"));
  gtk_widget_show(label1);
  gtk_table_attach(GTK_TABLE(table2), label1, 0, 1, 3, 4,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label1), 1, 0.5);
  ent_pgpuid = gtk_entry_new();
  gtk_widget_show(ent_pgpuid);
  gtk_table_attach(GTK_TABLE(table2), ent_pgpuid, 1, 2, 3, 4,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  label1 = gtk_label_new(_("pgp pass phrase:"));
  gtk_widget_show(label1);
  gtk_table_attach(GTK_TABLE(table2), label1, 0, 1, 4, 5,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label1), 1, 0.5);

  ent_pgppassp = gtk_entry_new();
  gtk_widget_show(ent_pgppassp);
  gtk_table_attach(GTK_TABLE(table2), ent_pgppassp, 1, 2, 4, 5,
                   GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
#ifdef _ENTRY_VISIBILITY_
  gtk_entry_set_visibility(GTK_ENTRY(ent_pgppassp),FALSE);
#endif

  pgpframe = gtk_frame_new (_(" Default PGP Behaviour "));
  gtk_widget_show (pgpframe);
  gtk_table_attach(GTK_TABLE(table2), pgpframe, 1, 2, 5, 6,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK /*| GTK_FILL*/, 0, 0);
  gtk_frame_set_label_align (GTK_FRAME (pgpframe), 0.05, 0.5);

  table3 = gtk_table_new (2, 1, FALSE);
  gtk_widget_show (table3);
  gtk_container_add (GTK_CONTAINER (pgpframe), table3);


  chk_pgp_sgn = gtk_check_button_new_with_label (_("Sign message"));
  gtk_widget_show (chk_pgp_sgn);
  gtk_table_attach (GTK_TABLE (table3), chk_pgp_sgn, 0, 1, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_FILL, 20, 0);

  chk_pgp_enc = gtk_check_button_new_with_label (_("Encrypt message"));
  gtk_widget_show (chk_pgp_enc);
  gtk_table_attach (GTK_TABLE (table3), chk_pgp_enc, 0, 1, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_FILL, 20, 0);

  return config;
}


GtkWidget*
create_msgwin ()
{
  GtkWidget *msgwin;
  GtkWidget *vpaned1;
  GtkWidget *vbox3;
  GtkWidget *msghandlebox;
  GtkWidget *msgtoolbar2;
  GtkWidget *table2;
  GtkWidget *label9;
  GtkWidget *label8;
  GtkWidget *label7;
  GtkWidget *label5;
  GtkWidget *label4;
  GtkWidget *vbox2;
  GtkWidget *hbox1;
  GtkWidget *vscrollbar1;

  msgwin = gtk_window_new(GTK_WINDOW_DIALOG);
  gtk_object_set_data(GTK_OBJECT(msgwin), "msgwin", msgwin);
  gtk_window_set_title(GTK_WINDOW(msgwin), _("Read Message"));
  gtk_window_position (GTK_WINDOW (msgwin), GTK_WIN_POS_CENTER);
  gtk_widget_set_usize(msgwin, -1, -1);
  gtk_window_set_policy(GTK_WINDOW(msgwin), TRUE, TRUE, TRUE);

  gtk_signal_connect(GTK_OBJECT(msgwin),"destroy",GTK_SIGNAL_FUNC(hidewin),NULL);
  gtk_signal_connect(GTK_OBJECT(msgwin),"delete_event",GTK_SIGNAL_FUNC(hidewin),NULL);

  vpaned1 = gtk_vpaned_new();
  gtk_widget_show(vpaned1);
  gtk_container_add(GTK_CONTAINER(msgwin), vpaned1);
  gtk_paned_handle_size(GTK_PANED(vpaned1), 0);
  gtk_paned_gutter_size(GTK_PANED(vpaned1), 13);

  vbox3 = gtk_vbox_new(FALSE, 0);
  gtk_widget_show(vbox3);
  gtk_container_add(GTK_CONTAINER(vpaned1), vbox3);


#ifdef _MENUS_
  msghandlebox = gtk_handle_box_new();
  gtk_widget_show(msghandlebox);
  gtk_box_pack_start(GTK_BOX(vbox3), msghandlebox, FALSE, FALSE, 0);
  gtk_container_add (GTK_CONTAINER(msghandlebox), create_menu(msgwin,1));
#endif

  msghandlebox = gtk_handle_box_new();
  gtk_widget_show(msghandlebox);
  gtk_box_pack_start(GTK_BOX(vbox3), msghandlebox, TRUE, TRUE, 1);

  gtk_widget_realize(msgwin);
  if (icons==0)	msgtoolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_ICONS);
  if (icons==1)	msgtoolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_TEXT);
  if (icons==2) msgtoolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
  gtk_container_add (GTK_CONTAINER(msghandlebox), msgtoolbar);
#ifdef _TOOLBAR_BORDERS_
//  gtk_toolbar_set_button_relief (GTK_TOOLBAR (msgtoolbar), GTK_RELIEF_NORMAL);
  gtk_toolbar_set_button_relief (GTK_TOOLBAR (msgtoolbar), GTK_RELIEF_NONE);
#endif
//  SetToolbarTipColor(msgtoolbar);

  msgwin_but_reply=gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar),_("Reply"), _("Reply to this message; does not work for now"), "",
			       new_pixmap (reply_xpm, msgwin->window, &msgwin->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)msgmenu_func, (gpointer)0);
  gtk_widget_set_sensitive(msgwin_but_reply,FALSE);

  msgwin_but_forward=gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar),_("Forward"), _("Forward this message; does not work for now"), "",
			       new_pixmap (forward_xpm, msgwin->window, &msgwin->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)msgmenu_func, (gpointer)1);
  gtk_widget_set_sensitive(msgwin_but_forward,FALSE);

  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar),_("Copy"), _("Copy this message to another folder"), "",
			       new_pixmap (copy_xpm, msgwin->window, &msgwin->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)msgmenu_func, (gpointer)2);

  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar),_("Move"), _("Move this message to another folder"), "",
			       new_pixmap (move_xpm, msgwin->window, &msgwin->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)msgmenu_func, (gpointer)3);

  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar),_("Delete"), _("Delete this message from folder"), "",
			       new_pixmap (delete_xpm, msgwin->window, &msgwin->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)msgmenu_func, (gpointer)4);

  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar),_("Decode"), _("Decode this part of the message"), "",
			       new_pixmap (decode_xpm, msgwin->window, &msgwin->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)msgmenu_func, (gpointer)5);

  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar),_("Export"), _("Save this message into a textfile"), "",
			       new_pixmap (export_xpm, msgwin->window, &msgwin->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)msgmenu_func, (gpointer)6);

  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar),_("Html"), _("View this part in web browser"), "",
			       new_pixmap (html_xpm, msgwin->window, &msgwin->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)msgmenu_func, (gpointer)7);

  gtk_widget_show (msgtoolbar);


  table2 = gtk_table_new(3, 4, FALSE);
  gtk_widget_show(table2);
  gtk_box_pack_start(GTK_BOX(vbox3), table2, TRUE, TRUE, 0);

  ent_msgsubj = gtk_entry_new();
  gtk_widget_show(ent_msgsubj);
  gtk_table_attach(GTK_TABLE(table2), ent_msgsubj, 1, 4, 2, 3,
                   GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_FILL, 0, 0);
  gtk_entry_set_editable(GTK_ENTRY(ent_msgsubj), FALSE);

  opt_msgparts = gtk_option_menu_new();
  gtk_widget_show(opt_msgparts);
  gtk_table_attach(GTK_TABLE(table2), opt_msgparts, 3, 4, 1, 2,
                   GTK_SHRINK | GTK_FILL, GTK_FILL, 0, 0);
  gtk_widget_set_usize(opt_msgparts, 100, 25);
  gtk_container_border_width(GTK_CONTAINER(opt_msgparts), 1);

  ent_msgdate = gtk_entry_new();
  gtk_widget_show(ent_msgdate);
  gtk_table_attach(GTK_TABLE(table2), ent_msgdate, 3, 4, 0, 1,
                   GTK_FILL, GTK_FILL, 0, 0);
  gtk_widget_set_usize(ent_msgdate, 60, -1);
  gtk_entry_set_editable(GTK_ENTRY(ent_msgdate), FALSE);

  label9 = gtk_label_new(_("Subject:"));
  gtk_widget_show(label9);
  gtk_table_attach(GTK_TABLE(table2), label9, 0, 1, 2, 3,
                   GTK_FILL, GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label9), 1, 0.5);
  gtk_misc_set_padding(GTK_MISC(label9), 7, 0);

  label8 = gtk_label_new(_("Parts:"));
  gtk_widget_show(label8);
  gtk_table_attach(GTK_TABLE(table2), label8, 2, 3, 1, 2,
                   GTK_FILL, GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label8), 1, 0.5);
  gtk_misc_set_padding(GTK_MISC(label8), 7, 0);

  label7 = gtk_label_new(_("Date:"));
  gtk_widget_show(label7);
  gtk_table_attach(GTK_TABLE(table2), label7, 2, 3, 0, 1,
                   GTK_FILL, GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label7), 1, 0.5);
  gtk_misc_set_padding(GTK_MISC(label7), 7, 0);

  label5 = gtk_label_new(_("To:"));
  gtk_widget_show(label5);
  gtk_table_attach(GTK_TABLE(table2), label5, 0, 1, 1, 2,
                   GTK_FILL, GTK_FILL, 0, 0);
  gtk_widget_set_usize(label5, -1, 22);
  gtk_misc_set_alignment(GTK_MISC(label5), 1, 0.5);
  gtk_misc_set_padding(GTK_MISC(label5), 7, 0);

  label4 = gtk_label_new(_("From:"));
  gtk_widget_show(label4);
  gtk_table_attach(GTK_TABLE(table2), label4, 0, 1, 0, 1,
                   GTK_FILL, GTK_FILL, 0, 0);
  gtk_misc_set_alignment(GTK_MISC(label4), 1, 0.5);
  gtk_misc_set_padding(GTK_MISC(label4), 7, 0);

  ent_msgto = gtk_entry_new();
  gtk_widget_show(ent_msgto);
  gtk_table_attach(GTK_TABLE(table2), ent_msgto, 1, 2, 1, 2,
                   GTK_SHRINK | GTK_FILL, GTK_FILL, 0, 0);
  gtk_widget_set_usize(ent_msgto, -1, 22);
  gtk_entry_set_editable(GTK_ENTRY(ent_msgto), FALSE);

  ent_msgfrom = gtk_entry_new();
  gtk_widget_show(ent_msgfrom);
  gtk_table_attach(GTK_TABLE(table2), ent_msgfrom, 1, 2, 0, 1,
                   GTK_SHRINK | GTK_FILL, GTK_FILL, 0, 0);
  gtk_entry_set_editable(GTK_ENTRY(ent_msgfrom), FALSE);

  vbox2 = gtk_vbox_new(FALSE, 0);
  gtk_widget_show(vbox2);
  gtk_container_add(GTK_CONTAINER(vpaned1), vbox2);

  hbox1 = gtk_hbox_new(FALSE, 0);
  gtk_widget_show(hbox1);
  gtk_box_pack_start(GTK_BOX(vbox2), hbox1, TRUE, TRUE, 0);

  msgtext = gtk_text_new(NULL, NULL);
  gtk_widget_show(msgtext);
  gtk_box_pack_start(GTK_BOX(hbox1), msgtext, TRUE, TRUE, 3);
  gtk_text_set_editable(GTK_TEXT(msgtext), FALSE);

  vscrollbar1=gtk_vscrollbar_new(GTK_TEXT(msgtext)->vadj);
  gtk_widget_show(vscrollbar1);
  gtk_box_pack_start(GTK_BOX(hbox1), vscrollbar1, FALSE, TRUE, 0);

  hbox1 = gtk_hbox_new(FALSE, 0);
  gtk_widget_show(hbox1);
  gtk_box_pack_start(GTK_BOX(vbox2), hbox1, FALSE, TRUE, 0);

  msghandlebox = gtk_handle_box_new();
  gtk_widget_show(msghandlebox);
  gtk_box_pack_start(GTK_BOX(hbox1), msghandlebox, FALSE, TRUE, 0);

  msgtoolbar2=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_TEXT);
  gtk_container_add(GTK_CONTAINER(msghandlebox), msgtoolbar2);
#ifdef _TOOLBAR_BORDERS_
//  gtk_toolbar_set_button_relief (GTK_TOOLBAR (msgtoolbar2), GTK_RELIEF_NORMAL);
  gtk_toolbar_set_button_relief (GTK_TOOLBAR (msgtoolbar2), GTK_RELIEF_NONE);
#endif
//  SetToolbarTipColor(msgtoolbar2);

  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar2),_("<<"), _("Previous unread message"), "",
					      NULL,(GtkSignalFunc)msgmenu_func, (gpointer)8);
  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar2),_("<"), _("Previous message"), "",
					      NULL,(GtkSignalFunc)msgmenu_func, (gpointer)9);
  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar2),_(">"), _("Next message"), "",
					      NULL,(GtkSignalFunc)msgmenu_func, (gpointer)10);
  gtk_toolbar_append_item(GTK_TOOLBAR(msgtoolbar2),_(">>"), _("Next unread message"), "",
					      NULL,(GtkSignalFunc)msgmenu_func, (gpointer)11);

  gtk_widget_show (msgtoolbar2);

  msgstatusbar = gtk_statusbar_new();
  gtk_widget_show(msgstatusbar);
  gtk_box_pack_start(GTK_BOX(hbox1), msgstatusbar, TRUE, TRUE, 0);
  msgstatusbar_id=gtk_statusbar_get_context_id(GTK_STATUSBAR(msgstatusbar),"Read message window Statusbar");
  msgstatusbar_total=0;

  return msgwin;
}

GtkWidget*
create_aboutwin ()
{
  GtkWidget *dialog_vbox1;
  GtkWidget *vbox3;
  GtkWidget *label;
  GtkWidget *dialog_action_area1;
  GtkWidget *but_close;

  GtkWidget *pixmap1;
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GtkStyle *style;

if (aboutboxopen!=0) return(NULL);

  aboutwin = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (aboutwin), "aboutwin", aboutwin);
  GTK_WINDOW (aboutwin)->type = GTK_WINDOW_DIALOG;
  gtk_window_set_title (GTK_WINDOW (aboutwin), _("About Sandmail (tm)"));
  gtk_window_set_policy (GTK_WINDOW (aboutwin), FALSE, FALSE, TRUE);
  gtk_window_position (GTK_WINDOW (aboutwin), GTK_WIN_POS_CENTER);
  gtk_signal_connect(GTK_OBJECT(aboutwin),"delete_event",GTK_SIGNAL_FUNC(dont_delete_event),NULL);
  gtk_widget_realize(aboutwin);

  dialog_vbox1 = GTK_DIALOG (aboutwin)->vbox;
  gtk_widget_show (dialog_vbox1);

  vbox3 = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (vbox3);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), vbox3, TRUE, TRUE, 0);



  style=gtk_widget_get_style(aboutwin);
  pixmap=gdk_pixmap_create_from_xpm_d(aboutwin->window,&mask,
							  &style->bg[GTK_STATE_NORMAL],(gchar **)logo_xpm);
  pixmap1=gtk_pixmap_new(pixmap,mask);
  gdk_pixmap_unref (pixmap);
  gtk_widget_show(pixmap1);
  gtk_box_pack_start(GTK_BOX(vbox3),pixmap1,TRUE,TRUE,0);
 

  label = gtk_label_new (
_("\
\npreview release 0.0010 \
\nby Kemal 'Disq' Hadimli \
\n \
\ndisq@bir.net.tr \
\nhttp://disq.bir.net.tr/sandmail \
\n \
\nUsing Seung-Hong Oh's POP3 code (Fetchpop 1.9)\
\n"));

  gtk_widget_show (label);
  gtk_box_pack_start (GTK_BOX (vbox3), label, TRUE, TRUE, 0);

  dialog_action_area1 = GTK_DIALOG (aboutwin)->action_area;
  gtk_widget_show (dialog_action_area1);

  but_close = gtk_button_new_with_label (_("Close"));
  gtk_widget_show (but_close);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), but_close, TRUE, TRUE, 0);
  gtk_container_border_width (GTK_CONTAINER (but_close), 5);
  gtk_signal_connect(GTK_OBJECT(but_close),"clicked",GTK_SIGNAL_FUNC(Close_About),NULL);

  gtk_widget_show(aboutwin);
  aboutboxopen++;
  return aboutwin;
}



GtkWidget*
create_cpy_win (int ismove)
{
  GtkWidget *but_cpy;
  GtkWidget *but_cancel;
  GtkWidget *dialog_vbox1;
  GtkWidget *table2;
  GtkWidget *label8;
  GtkWidget *label7;
  GtkWidget *hbox1;
  GtkWidget *label3;
  GtkWidget *label4;
  GtkWidget *label6;
  GtkWidget *dialog_action_area1;

  cpy_win = gtk_dialog_new ();
  gtk_object_set_data (GTK_OBJECT (cpy_win), "cpy_win", cpy_win);
  GTK_WINDOW (cpy_win)->type = GTK_WINDOW_DIALOG;

  if (ismove==0)
    gtk_window_set_title (GTK_WINDOW (cpy_win), _("Copy message"));
  else
    gtk_window_set_title (GTK_WINDOW (cpy_win), _("Move message"));
	
  gtk_window_position (GTK_WINDOW (cpy_win), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (cpy_win), FALSE, FALSE, TRUE);
  gtk_signal_connect(GTK_OBJECT(cpy_win),"delete_event",GTK_SIGNAL_FUNC(dont_delete_event),NULL);

  dialog_vbox1 = GTK_DIALOG (cpy_win)->vbox;
  gtk_widget_show (dialog_vbox1);

  table2 = gtk_table_new (5, 2, FALSE);
  gtk_widget_show (table2);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), table2, TRUE, TRUE, 0);
  gtk_container_border_width (GTK_CONTAINER (table2), 5);

  cpy_ent_src = gtk_entry_new ();
  gtk_widget_show (cpy_ent_src);
  gtk_table_attach (GTK_TABLE (table2), cpy_ent_src, 1, 2, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_widget_set_usize (cpy_ent_src, 140, -1);
  gtk_entry_set_editable (GTK_ENTRY (cpy_ent_src), FALSE);

  label8 = gtk_label_new (_("Source:"));
  gtk_widget_show (label8);
  gtk_table_attach (GTK_TABLE (table2), label8, 0, 1, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label8), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label8), 1, 0.5);
  gtk_misc_set_padding (GTK_MISC (label8), 3, 0);

  label7 = gtk_label_new (_("Pos:"));
  gtk_widget_show (label7);
  gtk_table_attach (GTK_TABLE (table2), label7, 0, 1, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label7), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label7), 1, 0.5);
  gtk_misc_set_padding (GTK_MISC (label7), 3, 0);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (hbox1);
  gtk_table_attach (GTK_TABLE (table2), hbox1, 1, 2, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);

  cpy_ent_s = gtk_entry_new ();
  gtk_widget_show (cpy_ent_s);
  gtk_box_pack_start (GTK_BOX (hbox1), cpy_ent_s, FALSE, TRUE, 0);
  gtk_widget_set_usize (cpy_ent_s, 60, -1);
  gtk_entry_set_editable (GTK_ENTRY (cpy_ent_s), FALSE);

  cpy_ent_e = gtk_entry_new ();
  gtk_widget_show (cpy_ent_e);
  gtk_box_pack_start (GTK_BOX (hbox1), cpy_ent_e, FALSE, TRUE, 0);
  gtk_widget_set_usize (cpy_ent_e, 60, -1);
  gtk_entry_set_editable (GTK_ENTRY (cpy_ent_e), FALSE);

  cpy_opt_fld = gtk_option_menu_new ();
  gtk_widget_show (cpy_opt_fld);
  gtk_table_attach (GTK_TABLE (table2), cpy_opt_fld, 1, 2, 4, 5,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_widget_set_usize (cpy_opt_fld, -1, 25);
  cpy_opt_fld_menu = gtk_menu_new ();
  gtk_option_menu_set_menu (GTK_OPTION_MENU (cpy_opt_fld), cpy_opt_fld_menu);

  cpy_opt_acc = gtk_option_menu_new ();
  gtk_widget_show (cpy_opt_acc);
  gtk_table_attach (GTK_TABLE (table2), cpy_opt_acc, 1, 2, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_widget_set_usize (cpy_opt_acc, 150, 25);
  cpy_opt_acc_menu = gtk_menu_new ();
  gtk_option_menu_set_menu (GTK_OPTION_MENU (cpy_opt_acc), cpy_opt_acc_menu);

  if (ismove==0)
    label3 = gtk_label_new (_("Copy message to:"));
  else
    label3 = gtk_label_new (_("Move message to:"));

  gtk_widget_show (label3);
  gtk_table_attach (GTK_TABLE (table2), label3, 0, 2, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_misc_set_alignment (GTK_MISC (label3), 0.5, 0.7);
  gtk_misc_set_padding (GTK_MISC (label3), 3, 15);

  label4 = gtk_label_new (_("Account:"));
  gtk_widget_show (label4);
  gtk_table_attach (GTK_TABLE (table2), label4, 0, 1, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_widget_set_usize (label4, 80, 25);
  gtk_label_set_justify (GTK_LABEL (label4), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label4), 1, 0.5);
  gtk_misc_set_padding (GTK_MISC (label4), 3, 0);

  label6 = gtk_label_new (_("Folder:"));
  gtk_widget_show (label6);
  gtk_table_attach (GTK_TABLE (table2), label6, 0, 1, 4, 5,
                    GTK_EXPAND | GTK_FILL, GTK_EXPAND | GTK_FILL, 0, 0);
  gtk_widget_set_usize (label6, 80, 25);
  gtk_label_set_justify (GTK_LABEL (label6), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label6), 1, 0.5);
  gtk_misc_set_padding (GTK_MISC (label6), 3, 0);

  dialog_action_area1 = GTK_DIALOG (cpy_win)->action_area;
  gtk_widget_show (dialog_action_area1);
  gtk_container_border_width (GTK_CONTAINER (dialog_action_area1), 10);

  but_cpy = gtk_button_new_with_label (_("Copy"));
  gtk_widget_show (but_cpy);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), but_cpy, TRUE, TRUE, 0);
  gtk_signal_connect(GTK_OBJECT(but_cpy),"clicked",GTK_SIGNAL_FUNC(cpymove_do),(gpointer)ismove);

  but_cancel = gtk_button_new_with_label (_("Cancel"));
  gtk_widget_show (but_cancel);
  gtk_box_pack_start (GTK_BOX (dialog_action_area1), but_cancel, TRUE, TRUE, 0);
  gtk_signal_connect_object(GTK_OBJECT(but_cancel),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(cpy_win));

  gtk_window_set_modal(GTK_WINDOW(cpy_win),TRUE);
  return cpy_win;
}


GtkWidget*
create_sendwin ()
{

  GtkWidget *vbox2;
  GtkWidget *handlebox0;
  GtkWidget *handlebox1;
  GtkWidget *table;
  GtkWidget *label;
  GtkWidget *hbox1;
  GtkWidget *vscroll;
  GtkWidget *toolbarwidget;
  int i;
  char a[256];

if (sendmsgopen==1) 
{
puts("\n**attempt to open send window while another is open");
return(NULL);
}

  sendwin = gtk_window_new (GTK_WINDOW_DIALOG);
  gtk_widget_set_usize (sendwin, 500, 500);
  gtk_container_border_width (GTK_CONTAINER (sendwin), 2);
  gtk_window_set_title (GTK_WINDOW (sendwin), _("Quicksand"));
  gtk_window_position (GTK_WINDOW (sendwin), GTK_WIN_POS_CENTER);
  gtk_window_set_policy(GTK_WINDOW(sendwin), TRUE, TRUE, TRUE);

  gtk_signal_connect(GTK_OBJECT(sendwin),"destroy",GTK_SIGNAL_FUNC(Close_Sendwin),NULL);
  gtk_signal_connect(GTK_OBJECT(sendwin),"delete_event",GTK_SIGNAL_FUNC(Close_Sendwin),NULL);

  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_widget_show (vbox2);
  gtk_container_add (GTK_CONTAINER (sendwin), vbox2);
  
  writepgp=pgpdata.option;

#ifdef _MENUS_
  handlebox0 = gtk_handle_box_new ();
  gtk_widget_show (handlebox0);
  gtk_box_pack_start (GTK_BOX (vbox2), handlebox0, FALSE, FALSE, 0);
  gtk_container_add (GTK_CONTAINER(handlebox0), create_menu(sendwin,2));
#endif

  handlebox1 = gtk_handle_box_new ();
  gtk_widget_show (handlebox1);
  gtk_box_pack_start (GTK_BOX (vbox2), handlebox1, FALSE, TRUE, 0);
  gtk_widget_realize(sendwin);

  if (icons==0)	wtoolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_ICONS);
  if (icons==1)	wtoolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_TEXT);
  if (icons==2) wtoolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
  gtk_container_add (GTK_CONTAINER(handlebox1), wtoolbar);
#ifdef _TOOLBAR_BORDERS_
//  gtk_toolbar_set_button_relief (GTK_TOOLBAR (wtoolbar), GTK_RELIEF_NORMAL);
  gtk_toolbar_set_button_relief (GTK_TOOLBAR (wtoolbar), GTK_RELIEF_NONE);
#endif
//  SetToolbarTipColor(wtoolbar);

  toolbarwidget=gtk_toolbar_append_item(GTK_TOOLBAR(wtoolbar),_("Send"), _("Send this message"), "",
			       new_pixmap (forward_xpm, sendwin->window, &sendwin->style->bg[GTK_STATE_NORMAL]),
			       (GtkSignalFunc)Prepare_Message, NULL);
  gtk_widget_set_sensitive(toolbarwidget,FALSE);

  toolbarwidget=gtk_toolbar_append_item(GTK_TOOLBAR(wtoolbar),_("Send later"), _("Put this message to Outbox, send later"), "",
			       new_pixmap (reply_xpm, sendwin->window, &sendwin->style->bg[GTK_STATE_NORMAL]),
			       NULL, NULL);
  gtk_widget_set_sensitive(toolbarwidget,FALSE);

  gtk_widget_show (wtoolbar);

  table = gtk_table_new (4, 3, FALSE);
  gtk_widget_show (table);
  gtk_box_pack_start (GTK_BOX (vbox2), table, FALSE, TRUE, 3);
  gtk_table_set_col_spacings (GTK_TABLE (table), 2);

  ent_wsubj = gtk_entry_new ();
  gtk_widget_show (ent_wsubj);
  gtk_table_attach (GTK_TABLE (table), ent_wsubj, 1, 3, 3, 4,
                    GTK_EXPAND | GTK_FILL, GTK_FILL, 0, 0);

  ent_wcc = gtk_entry_new ();
  gtk_widget_show (ent_wcc);
  gtk_table_attach (GTK_TABLE (table), ent_wcc, 1, 2, 2, 3,
                    GTK_EXPAND | GTK_FILL, GTK_FILL, 0, 0);

  ent_wto = gtk_entry_new ();
  gtk_widget_show (ent_wto);
  gtk_table_attach (GTK_TABLE (table), ent_wto, 1, 2, 1, 2,
                    GTK_EXPAND | GTK_FILL, GTK_FILL, 0, 0);

  opt_wfrom = gtk_option_menu_new ();
  gtk_widget_show (opt_wfrom);
  gtk_table_attach (GTK_TABLE (table), opt_wfrom, 1, 3, 0, 1,
                    GTK_EXPAND | GTK_FILL, GTK_FILL, 0, 0);
  gtk_widget_set_usize (opt_wfrom, 32, 22);
  opt_wfrom_menu = gtk_menu_new ();

for(i=0;i<accounts;i++)
  {
  sprintf(a,"%s <%s>",accdata[i].fullname,accdata[i].mailaddress);
  accdata[i].menuitem=gtk_menu_item_new_with_label(a);
  gtk_widget_show(accdata[i].menuitem);
  gtk_signal_connect_object(GTK_OBJECT(accdata[i].menuitem),"activate",GTK_SIGNAL_FUNC(Write_From_Change),(gpointer)i);
  gtk_menu_append(GTK_MENU(opt_wfrom_menu), accdata[i].menuitem);
  }
  gtk_option_menu_set_menu (GTK_OPTION_MENU (opt_wfrom), opt_wfrom_menu);
  gtk_option_menu_set_history(GTK_OPTION_MENU(opt_wfrom),writeid);

  but_wcc = gtk_button_new_with_label ("...");
  gtk_widget_show (but_wcc);
  gtk_table_attach (GTK_TABLE (table), but_wcc, 2, 3, 2, 3,
                    0, 0, 0, 0);
  gtk_widget_set_usize (but_wcc, 22, -1);

  but_wto = gtk_button_new_with_label ("...");
  gtk_widget_show (but_wto);
  gtk_table_attach (GTK_TABLE (table), but_wto, 2, 3, 1, 2,
                    0, 0, 0, 0);
  gtk_widget_set_usize (but_wto, 22, -1);

  label = gtk_label_new ("Subject:");
  gtk_widget_show (label);
  gtk_table_attach (GTK_TABLE (table), label, 0, 1, 3, 4,
                    GTK_FILL, GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label), 1, 0.5);
  gtk_misc_set_padding (GTK_MISC (label), 2, 0);

  label = gtk_label_new ("Cc:");
  gtk_widget_show (label);
  gtk_table_attach (GTK_TABLE (table), label, 0, 1, 2, 3,
                    GTK_FILL, GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label), 1, 0.5);
  gtk_misc_set_padding (GTK_MISC (label), 2, 0);

  label = gtk_label_new ("From:");
  gtk_widget_show (label);
  gtk_table_attach (GTK_TABLE (table), label, 0, 1, 0, 1,
                    GTK_FILL, GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label), 1, 0.5);
  gtk_misc_set_padding (GTK_MISC (label), 2, 0);

  label = gtk_label_new ("To:");
  gtk_widget_show (label);
  gtk_table_attach (GTK_TABLE (table), label, 0, 1, 1, 2,
                    GTK_FILL, GTK_FILL, 0, 0);
  gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_RIGHT);
  gtk_misc_set_alignment (GTK_MISC (label), 1, 0.5);
  gtk_misc_set_padding (GTK_MISC (label), 2, 0);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox1, TRUE, TRUE, 0);

  text_w = gtk_text_new (NULL, NULL);
  gtk_widget_show (text_w);
  gtk_box_pack_start (GTK_BOX (hbox1), text_w, TRUE, TRUE, 0);
  gtk_text_set_editable (GTK_TEXT (text_w), TRUE);

  vscroll = gtk_vscrollbar_new(GTK_TEXT(text_w)->vadj);
  gtk_widget_show (vscroll);
  gtk_box_pack_start (GTK_BOX (hbox1), vscroll, FALSE, TRUE, 0);

  wstatusbar = gtk_statusbar_new ();
  gtk_widget_show (wstatusbar);
  gtk_box_pack_start (GTK_BOX (vbox2), wstatusbar, FALSE, TRUE, 0);

  gtk_widget_show(sendwin);
  sendmsgopen=1;
  menu_activate_newmsg(FALSE);

  return sendwin;
}

