#ifndef _GLADESRC_H_
#define _GLADESRC_H_

#include <gtk/gtk.h>
#include <stdio.h>
#include "common.h"

#include "struc.h"
#include "folder.h"
#include "getmail.h"

 GtkWidget *mainwin_but_compose;
 GtkWidget *msgwin_but_reply;
 GtkWidget *msgwin_but_forward;

 GtkWidget *servertree;
 GtkWidget *but_newacc;
 GtkWidget *but_delacc;
 GtkWidget *but_newfol;
 GtkWidget *but_delfol;
 GtkWidget *ent_smtp;
 GtkWidget *ent_webb;
 GtkWidget *chk_autoweb;
 GtkWidget *chk_thread;
// GtkWidget *chk_ctree;
 GtkWidget *chk_leave;
 GtkWidget *chk_trash;
 GtkWidget *chk_fullhead;
 GtkWidget *ent_password;
 GtkWidget *ent_username;
 GtkWidget *ent_pop3server;
 GtkWidget *ent_org;
 GtkWidget *ent_fullname;
 GtkWidget *ent_replyto;
 GtkWidget *ent_mail;
 GtkWidget *ent_sigfile;
 GtkWidget *combo_acct;
 GtkWidget *menuitem[6];
 GtkWidget *opt_foldertype;
 GtkWidget *opt_foldertype_menu;
 GtkWidget *combo_folder;
 GtkWidget *ent_folderfile;
 GtkWidget *ent_filter;
 GtkWidget *clist;
 GtkWidget *statusbar;
 guint statusbar_id;
 unsigned int statusbar_total;

 GtkWidget *msgtext;
 GtkWidget *msgstatusbar;
 guint msgstatusbar_id;
 unsigned int msgstatusbar_total;

 GtkWidget *progbar;
 GtkWidget *toolbar;
 GtkWidget *msgtoolbar;

 GtkWidget *ent_msgto;
 GtkWidget *ent_msgfrom;
 GtkWidget *ent_msgdate;
 GtkWidget *ent_msgsubj;
 GtkWidget *opt_msgparts;
 GtkWidget *opt_msgparts_menu;

 GtkWidget *cpy_win;
 GtkWidget *cpy_ent_src;
 GtkWidget *cpy_ent_s;
 GtkWidget *cpy_ent_e;
 GtkWidget *cpy_opt_acc;
 GtkWidget *cpy_opt_acc_menu;
 GtkWidget *cpy_opt_fld;
 GtkWidget *cpy_opt_fld_menu;
 int cpy_acc, cpy_fld;

 GSList *radio_group;
 GtkWidget *cfg_radio[3];
 int cfg_radio_sel;

 GtkWidget *ent_pgpe;
 GtkWidget *ent_pgpv;
 GtkWidget *ent_pgps;
 GtkWidget *ent_pgpuid;
 GtkWidget *ent_pgppassp;
 GtkWidget *chk_pgp_sgn;
 GtkWidget *chk_pgp_enc;

 GtkWidget *sendwin;
 GtkWidget *ent_wsubj;
 GtkWidget *ent_wcc;
 GtkWidget *ent_wto;
 GtkWidget *opt_wfrom;
 GtkWidget *opt_wfrom_menu;
 GtkWidget *wtoolbar;
 GtkWidget *but_wto;
 GtkWidget *but_wcc;
 GtkWidget *text_w;
 GtkWidget *wstatusbar;
 int writeid;
 int writepgp;

 int acur;
 int afol;
  
 int fol_norep;
 int acc_norep;

 char yesmsg;  // 0 if clist/ctree is empty
 unsigned int cur_msg;
 unsigned int cur_msg_row;
 char aboutboxopen;
 char sendmsgopen;

#ifdef _CTREE_
 GtkCTreeNode *cur_msg_row_ctree;
#endif


void get_mail();
void debugmsg(char *a);
#ifndef GTK_HAVE_FEATURES_1_1_2
void gtk_window_set_modal (GtkWindow *window, gboolean modal);
#endif
#ifdef _CTREE_
void ctree_click_column (GtkCTree *ctree, gint column, gpointer data);
void ctree_select(GtkWidget *clist,GtkCTreeNode *row,gint column,GdkEventButton *event,gpointer data);
#endif
#ifdef _CLISTSORT_
void clist_click_column (GtkCList *aclist, gint column, gpointer data);
#endif
void clist_select(GtkWidget *clist,gint row,gint column,GdkEventButton *event,gpointer data);
void my_set_usize(GtkWidget *w, gint x, gint y);
GtkWidget* new_pixmap (gchar *filename[], GdkWindow *window, GdkColor  *background);
gint delete_event(GtkWidget *widget, GdkEvent *event, gpointer data);
gint dont_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data);
void SetToolbarTipColor(GtkWidget *widget);
void DoToolTips(GtkWidget *widget, char *desc);
void PushStatusbar(char *desc);
void PopStatusbar();
void PushMsgStatusbar(char *desc);
void PopMsgStatusbar();
void DoStatusbar(GtkWidget *widget, GdkEvent *event, gpointer data);
void UndoStatusbar(GtkWidget *widget, GdkEvent *event, gpointer data);
void PrepStatusbar(GtkWidget *widget, char *desc);
void toggle_button_callback (GtkWidget *widget, gpointer data);
void Update_Combo(accstruc acs[], int acb);
void Update_FolderCombo(folderstruc folders[], int fnum);
void Update_FolderStatus();
void FolderCombo_change(GtkWidget *widget, gpointer data);
void Update_Config(int a);
void Combo_change(GtkWidget *widget, gpointer data);
void Folder_Filter(GtkWidget *widget, GdkEvent *event, gpointer data);
void Folder_File(GtkWidget *widget, GdkEvent *event, gpointer data);
void Folder_Option_Change(GtkWidget *widget, gpointer data);
void destroy (GtkWidget *widget, gpointer data);
void Open_Config(GtkWidget *widget, gpointer data);
void Servertree_select (GtkWidget *root_tree, GtkWidget *child, GtkWidget *subtree);
void Prepare_ServerTree(GtkWidget *w);
void Record_First_Page();
void Record_Second_Page();
void RecSecond(GtkWidget *widget, GdkEvent *event, gpointer data);
void Record_PGP_Page();
void Close_Config(GtkWidget *widget, gpointer data);
gint Close_Config_delete_event(GtkWidget *widget, GdkEvent *event, gpointer data);
void Ok_Close_Config(GtkWidget *widget, gpointer data);
void Save_Close_Config(GtkWidget *widget, gpointer data);
void Update_clist();
void view_with_browser();
int save_quoted_printable();
void msgopt_change(GtkWidget *widget, gpointer data);
void msgmenu_decode_filesel_ok(GtkWidget *w, GtkFileSelection *fs);
void msgmenu_export_filesel_ok(GtkWidget *w, GtkFileSelection *fs);
void cpymove_do(GtkWidget *widget, gpointer data);
void cpy_opt_fld_change(GtkWidget *widget, gpointer data);
void cpy_opt_acc_change(GtkWidget *widget, gpointer data);
void msgmenu_func(GtkWidget *widget, gpointer data);
void new_account(GtkWidget *widget, gpointer data);
void del_account(GtkWidget *widget, gpointer data);
void new_folder(GtkWidget *widget, gpointer data);
void del_folder(GtkWidget *widget, gpointer data);
void hidewin(GtkWidget *w);
void Close_About();
void Write_From_Change(GtkWidget *widget, gpointer data);
void Close_Sendwin();
void Prepare_Message();
void clist_clear();

#endif
