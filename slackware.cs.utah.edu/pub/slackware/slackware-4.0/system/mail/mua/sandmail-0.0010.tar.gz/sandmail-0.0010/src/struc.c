#include "common.h"
#include "gladesrc.h"
#include "findrep.h"
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "struc.h"
#include "gui.h"

#define CFGVERSION "1.0"

void cpyaccs(accstruc s[], int *sn, accstruc d[], int *dn)
{
  int i,j;

  dn[0]=sn[0];
  for(i=0;i<sn[0];i++)
	{
    strcpy(d[i].accname,s[i].accname);
    strcpy(d[i].username,s[i].username);
    strcpy(d[i].password,s[i].password);
	strcpy(d[i].mailserver,s[i].mailserver);
    strcpy(d[i].mailaddress,s[i].mailaddress);
	strcpy(d[i].replytoaddress,s[i].replytoaddress);
    strcpy(d[i].fullname,s[i].fullname);
	strcpy(d[i].org,s[i].org);
	strcpy(d[i].sigfile,s[i].sigfile);
    d[i].leaveonserver=s[i].leaveonserver;
    d[i].movetotrash=s[i].movetotrash;
    d[i].folders=s[i].folders;
	for(j=0;j<s[i].folders;j++)
	  {
	  strcpy(d[i].foldata[j].name,s[i].foldata[j].name);
	  d[i].foldata[j].status=s[i].foldata[j].status;
	  strcpy(d[i].foldata[j].filter,s[i].foldata[j].filter);
	  strcpy(d[i].foldata[j].file,s[i].foldata[j].file);
	  }
	}
}

void readconfig() {
char dummy[1024]; FILE *f; int i,j; char a[128], b[128], c[128];

accounts=0;
smtpserver[0]=0;
webbrowser[0]=0;
icons=2;

sprintf(a,"%s/.sandmailrc",getenv("HOME"));
f=fopen(a,"r");
if (f==NULL) return;

scandesc(f, "ConfigVersion",dummy);
if (strcmp(dummy,CFGVERSION)!=0)
  {
  printf(_("\n\n Your configuration file (~/.sandmailrc) is old! Please fix it or delete it.\n Thank you.\n\n"));
  exit(255);
  }

scandesc(f, "PGPe",pgpdata.e);
scandesc(f, "PGPv",pgpdata.v);
scandesc(f, "PGPs",pgpdata.s);
scandesc(f, "PGPuid",pgpdata.uid);
scandesc(f, "PGPpassp",pgpdata.passp);
scandesc(f, "PGPopt",dummy); pgpdata.option=atoi(dummy);

scandesc(f, "ToolbarStatus",dummy); icons=atoi(dummy);
scandesc(f, "SMTP Server",smtpserver);
scandesc(f, "Web browser",webbrowser);
scandesc(f, "Autoweb",dummy); autoweb=atoi(dummy);
scandesc(f, "Full headers",dummy); fullhead=atoi(dummy);
scandesc(f, "Thread messages",dummy); threadmsgs=atoi(dummy);
//scandesc(f, "Use GtkCTree",dummy); ctree=atoi(dummy);
if (threadmsgs==1) ctree=1; else ctree=0;

scandesc(f, "Accounts",dummy); accounts=atoi(dummy);

for(i=0;((i<accounts) && (!feof(f)));i++) {
sprintf(a,"Acc%i",i);
sprintf(b,"%s Name",a); scandesc(f, b,accdata[i].accname);
sprintf(b,"%s Username",a); scandesc(f, b,accdata[i].username);
sprintf(b,"%s Password",a); scandesc(f, b,accdata[i].password);
sprintf(b,"%s POP3serv",a); scandesc(f, b,accdata[i].mailserver);
sprintf(b,"%s Mail address",a); scandesc(f, b,accdata[i].mailaddress);
sprintf(b,"%s Reply-to address",a); scandesc(f, b,accdata[i].replytoaddress);
sprintf(b,"%s Fullname",a); scandesc(f, b,accdata[i].fullname);
sprintf(b,"%s Orgy",a); scandesc(f, b,accdata[i].org);
sprintf(b,"%s Signature file",a); scandesc(f, b,accdata[i].sigfile);
sprintf(b,"%s Leave on server",a); scandesc(f, b,dummy); accdata[i].leaveonserver=atoi(dummy);
sprintf(b,"%s Move msgs 2 trash",a); scandesc(f, b,dummy); accdata[i].movetotrash=atoi(dummy);
sprintf(b,"%s Folders",a); scandesc(f, b,dummy); accdata[i].folders=atoi(dummy);

for(j=0;j<accdata[i].folders;j++)
  {
  sprintf(c,"%s Fol%i",a,j);
  sprintf(b,"%s Name",c); scandesc(f, b,accdata[i].foldata[j].name);
  sprintf(b,"%s File",c); scandesc(f, b,accdata[i].foldata[j].file);
  sprintf(b,"%s Type",c); scandesc(f, b,dummy); accdata[i].foldata[j].status=atoi(dummy);
  sprintf(b,"%s Filter",c); scandesc(f, b,accdata[i].foldata[j].filter);
  }
}
if (i<accounts) accounts=i;

fclose(f);
}


int writeconfig() {
FILE *f; int i,j; char a[128], b[128];

sprintf(a,"%s/.sandmailrc",getenv("HOME"));
f=fopen(a,"w");
if (f==NULL) { PushStatusbar(_("Error writing config file")); return(1); }

fprintf(f,_("This is Sandmail config file. DO NOT EDIT!\n"));

fprintf(f,"ConfigVersion=%s\n",CFGVERSION);

fprintf(f,"PGPe=%s\n",pgpdata.e);
fprintf(f,"PGPv=%s\n",pgpdata.v);
fprintf(f,"PGPs=%s\n",pgpdata.s);
fprintf(f,"PGPuid=%s\n",pgpdata.uid);
fprintf(f,"PGPpassp=%s\n",pgpdata.passp);
fprintf(f,"PGPopt=%i\n",pgpdata.option);

fprintf(f,"ToolbarStatus=%i\n",icons);
fprintf(f,"SMTP Server=%s\n",smtpserver);
fprintf(f,"Web Browser=%s\n",webbrowser);
fprintf(f,"Autoweb=%i\n",autoweb);
fprintf(f,"Full headers=%i\n",fullhead);
fprintf(f,"Thread messages=%i\n",threadmsgs);
//fprintf(f,"Use GtkCTree=%i\n",ctree);
fprintf(f,"Accounts=%i\n",accounts);

fprintf(f,"\n# * Accounts start here *");
for(i=0;(i<accounts);i++) {
sprintf(a,"Acc%i",i);

fprintf(f,"\n# Account %i\n",i);
fprintf(f,"%s Name=%s\n",a,accdata[i].accname);
fprintf(f,"%s Username=%s\n",a,accdata[i].username);
fprintf(f,"%s Password=%s\n",a,accdata[i].password);
fprintf(f,"%s POP3serv=%s\n",a,accdata[i].mailserver);
fprintf(f,"%s Mail address=%s\n",a,accdata[i].mailaddress);
fprintf(f,"%s Reply-to address=%s\n",a,accdata[i].replytoaddress);
fprintf(f,"%s Fullname=%s\n",a,accdata[i].fullname);
fprintf(f,"%s Orgy=%s\n",a,accdata[i].org);
fprintf(f,"%s Signature file=%s\n",a,accdata[i].sigfile);
fprintf(f,"%s Leave on server=%i\n",a,accdata[i].leaveonserver);
fprintf(f,"%s Move msgs 2 trash=%i\n",a,accdata[i].movetotrash);
fprintf(f,"%s Folders=%i\n",a,accdata[i].folders);

for(j=0;j<accdata[i].folders;j++)
  {
  sprintf(b,"%s Fol%i",a,j);

  fprintf(f,"%s Name=%s\n",b,accdata[i].foldata[j].name);
  fprintf(f,"%s File=%s\n",b,accdata[i].foldata[j].file);
  fprintf(f,"%s Type=%i\n",b,accdata[i].foldata[j].status);
  if (accdata[i].foldata[j].status==5) fprintf(f,"%s Filter=%s\n",a,accdata[i].foldata[j].filter);
  }
}

fclose(f);
PushStatusbar(_("Config file written"));
return(0);
}
