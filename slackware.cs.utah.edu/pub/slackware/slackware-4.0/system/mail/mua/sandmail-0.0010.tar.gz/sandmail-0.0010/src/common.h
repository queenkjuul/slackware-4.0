#include "../config.h"
#include "i18n.h"
#include <gtk/gtk.h>

#ifdef GTK_HAVE_FEATURES_1_1_2
  #define _CTREE_
  #define _CLISTSORT_
  #define _ENTRY_VISIBILITY_
//  #define _TOOLBAR_BORDERS_
  #define _POPUP_NOTEBOOK_
  #define _SCROLLABLE_NOTEBOOK_
  #define _DISCRETE_PROGRESSBAR_
#endif

#ifdef GTK_HAVE_FEATURES_1_1_4
  #define _NO_CLIST_POLICY_
#endif

#ifdef __GTK_ITEM_FACTORY_H__
  #define _MENUS_
#endif

