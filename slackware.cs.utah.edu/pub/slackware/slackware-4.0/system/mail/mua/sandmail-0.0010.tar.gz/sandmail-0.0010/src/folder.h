#ifndef _FOLDER_H_
#define _FOLDER_H_

#include "common.h"
#include <gtk/gtk.h>
#include <stdio.h>
#include <fcntl.h>

typedef struct mailstruc {
  unsigned long realstartpos;
  unsigned long startpos;
  unsigned long endpos;
  char mimesep[80];
  unsigned int mimecount;
  unsigned long mimepos[16];
  GtkWidget *mimeitem[16];
  char mimedesc[16][80];
  char mimeenc[16][80];
  char mimefile[16][80];
  char mimecont[16][80];
  unsigned long mimecutpos[16];
  unsigned int curpart;
} mailstruc;

typedef struct smallmailstruc {
  unsigned long realstartpos;
  unsigned long startpos;
  char date[64];
  unsigned int flags;
  char m_data[6][256];
  char haveparent;
} smallmailstruc, *smallmailstruc_p;

mailstruc curmail;
unsigned int totmail;
smallmailstruc_p mails;

void fixdate(char s[]);
int ConvertHome(char s[]);
int SearchStart(FILE *f, char searchfor[], char searchtoo[]);
int strstartcmp(char *s, char *searchfor);
int Scan_Box(char fname[], GtkWidget *clis);
void Scan_Mail(FILE *f, int fullheaders);
int fcopy(char *sf, char *df);
int fdel(char *fn);
int CopyMsg(char *sf, unsigned long ss, unsigned long se, char *df);
int DelMsg(char *fn, unsigned long ss, unsigned long se);
int lockfolder(char folfile[]);
int unlockfolder(char folfile[]);
FILE *myfopen(char *path, char *mode);

#endif
