/*
 this file is included from common.h, and common.h is included from every .c
 file in /src

 just define I18N when compiling to enable it.
*/
#ifndef _I18N_H_
#define _I18N_H_

#ifdef ENABLE_NLS
  #define I18N
#endif

#ifdef I18N
  #define _(String) gettext (String)
  #include <libintl.h>
  #include <locale.h>
//  #define LOC ""
//  #define LOCALEDIR ""
#endif

#ifndef I18N
  #define _(String) String
#endif

#endif
	