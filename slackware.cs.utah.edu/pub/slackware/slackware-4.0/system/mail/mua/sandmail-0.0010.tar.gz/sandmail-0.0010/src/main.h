#ifndef _MAIN_H_
#define _MAIN_H_

#include <gtk/gtk.h>
#include "common.h"
#include <stdio.h>
/*
#include "struc.h"
*/
GtkWidget *config;
GtkWidget *msgwin;
GtkWidget *aboutwin;
GtkWidget *mainwin;

int main (int argc, char *argv[]);

#endif
