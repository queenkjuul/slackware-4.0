#ifndef _GUI_H_
#define _GUI_H_

#include <gtk/gtk.h>
#include <stdio.h>
#include "common.h"
#include "gladesrc.h"

float mprogperc;
unsigned long totprogress;

void progress_update(unsigned long cur);

GtkWidget* create_main ();
GtkWidget* create_config ();
GtkWidget* create_msgwin ();
GtkWidget* create_aboutwin ();
GtkWidget* create_cpy_win (int ismove);
GtkWidget* create_sendwin ();

#endif
