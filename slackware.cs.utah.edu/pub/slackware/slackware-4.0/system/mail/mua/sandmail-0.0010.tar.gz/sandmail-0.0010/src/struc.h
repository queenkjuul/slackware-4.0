#ifndef _STRUC_H_
#define _STRUC_H_

#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>

typedef struct pgpstruc {
  char e[256];
  char v[256];
  char s[256];
  char uid[256];
  char passp[256];
  int option;
} pgpstruc;

typedef struct folderstruc {
 char name[50];
 unsigned int status;
 char filter[50]; 
 char file[50];
 GtkWidget *tree;
 } folderstruc;

typedef struct accstruc {
 char accname[50];
 char username[50];
 char password[50];
 char mailserver[50];
 char mailaddress[50];
 char replytoaddress[50];
 char fullname[50];
 char org[50];
 int leaveonserver;
 int movetotrash;
 char sigfile[50];
 
 unsigned int folders;
 folderstruc foldata[16];

 GtkWidget *tree;
 GtkWidget *menuitem;
 } accstruc;

int accounts, accountsbuf;
accstruc accdata[16],accbuf[16];
pgpstruc pgpdata;

char smtpserver[50];
char webbrowser[50];
char getmailprg[256];
int autoweb;
int icons;
int threadmsgs;
int ctree;
int fullhead;

void cpyaccs(accstruc s[], int *sn, accstruc d[], int *dn);
void readconfig();
int writeconfig();

#endif
