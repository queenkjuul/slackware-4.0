#ifndef _GETMAIL_H_
#define _GETMAIL_H_

#include "common.h"

void get_mail();

#endif
