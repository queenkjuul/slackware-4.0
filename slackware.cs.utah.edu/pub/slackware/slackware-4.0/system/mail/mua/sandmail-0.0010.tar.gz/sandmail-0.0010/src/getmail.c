#include "common.h"

#include <stdio.h>
#include <string.h>

#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <signal.h>

#include "getmail.h"
#include "fetchpop.h"
#include "fetch-pop.h"
#include "gladesrc.h"
#include "gui.h"
#include "main.h"
#include "struc.h"
#include "folder.h"

void get_mail()
{
char a[128],b[50],c[256];
int i,j,k,e;
struct optrep o;

gtk_widget_set_sensitive(mainwin,FALSE);
gtk_window_set_modal(GTK_WINDOW(mainwin),TRUE);
//gtk_widget_set_sensitive(statusbar,TRUE); /* does not work */

e=0;
for(i=0;i<accounts;i++)
{

totprogress=1;
progress_update(0);

sprintf(c,"Getting mail: %s.. ",accdata[i].accname);
PushStatusbar(c);
while(gtk_events_pending()) gtk_main_iteration(); // *important*

//i=acur;

  strcpy(b,"");
  for(j=0;j<accdata[i].folders;j++)
	if (accdata[i].foldata[j].status==1)
	  {
	  strcpy(b,accdata[i].foldata[j].file);
	  j=accdata[i].folders;
	  }
  ConvertHome(b);

bzero(&o,sizeof(struct optrep));

o.toplines=0;
o.check=2;
o.whichdeliver=1;
strcpy(o.output,b);

o.logging=1;
strcpy(o.logfile,"/tmp/sandmail.fetchpop.log");

if (accdata[i].leaveonserver==0) o.remove=0; else o.remove=1;

o.daemon=0;

strcpy(a,accdata[i].mailserver); // **  fix port num
strcpy(o.host,a);
o.popport=110;

strcpy(o.userid,accdata[i].username);
strcpy(o.password,accdata[i].password);
o.hack_addresses=0;

j=pop(&o);

//PopStatusbar();
k=1;
if (j==POP_ERROR)
  {
  sprintf(c,"%s POP_ERROR",c);
  PushStatusbar(c);
  } else if (j==WRONG_PROTOCOL)
  {
  sprintf(c,"%s WRONG_PROTOCOL",c);
  PushStatusbar(c);
  } else if (j==DOWN)
  {
  sprintf(c,"%s site is down",c);
  PushStatusbar(c);
  }
  else if (j==SHIT)
  {
  sprintf(c,"%s SH*T",c);
  PushStatusbar(c);
  }
  else if (j==KILLED)
  {
  sprintf(c,"%s KILLED",c);
  PushStatusbar(c);
  }
  else
  {
  k=0;
  sprintf(c,"%s Ok.",c);
  PushStatusbar(c);
  }  
while(gtk_events_pending()) gtk_main_iteration(); // *important*
if (k==1) { e++; sleep(5); }
//PopStatusbar();
}
sprintf(c,"Complete. Errors: %i",e);
PushStatusbar(c);
totprogress=1;
progress_update(0);
gtk_widget_set_sensitive(mainwin,TRUE);
gtk_window_set_modal(GTK_WINDOW(mainwin),FALSE);
}




/*
void get_mail()
{
FILE *f;
char a[1024], b[50];
int i,j;
pid_t pid;

for(i=0;i<acur;i++)
  {
  strcpy(a,getmailprg);
  while(replacestr(a,"$ACCNAME",accdata[i].accname)==1);
  while(replacestr(a,"$USERNAME",accdata[i].username)==1);
  while(replacestr(a,"$PASSWORD",accdata[i].password)==1);
  while(replacestr(a,"$POP3",accdata[i].mailserver)==1);
  while(replacestr(a,"$MAILADDR",accdata[i].mailaddress)==1);
  while(replacestr(a,"$REPLYTO",accdata[i].replytoaddress)==1);
  while(replacestr(a,"$FULLNAME",accdata[i].fullname)==1);
  while(replacestr(a,"$ORG",accdata[i].org)==1);
  while(replacestr(a,"$SIGFILE",accdata[i].sigfile)==1);
  sprintf(b,"%i",accdata[i].leaveonserver); while(replacestr(a,"$LEAVEONSERVER",b)==1);
  sprintf(b,"%i",accdata[i].movetotrash); while(replacestr(a,"$MOVETOTRASH",b)==1);
  sprintf(b,"%i",i); replacestr(a,"$ACCNUM",b);
  while(replacestr(a,"$HOME",getenv("HOME"))==1);
  while(replacestr(a,"~/",getenv("HOME"))==1);

  strcpy(b,"");
  for(j=0;j<accdata[i].folders;j++)
	if (accdata[i].foldata[j].status==1)
	  {
	  strcpy(b,accdata[i].foldata[j].file);
	  j=accdata[i].folders;
	  }
  ConvertHome(b);
  while(replacestr(a,"$INBOX",b)==1);

  f=fopen("/tmp/sandmail.getmail.run","w");
  if (f==NULL) { printf(_("\nunable to create tempfile")); fflush(stdout); return; } // **
  fprintf(f,"#/bin/sh\n");
  fprintf(f,"%s",a);
  fclose(f);

  chmod("/tmp/sandmail.getmail.run",S_IRUSR | S_IWUSR | S_IXUSR);

  pid=fork();
  if (!pid)
    {
    execlp("/tmp/sandmail.getmail.run","/tmp/sandmail.getmail.run",NULL);
    exit(0);
    }
  pid=wait(NULL);
  fdel("/tmp/sandmail.getmail.run");
  }
  fdel("/tmp/sandmail.getmail.run");
}
*/