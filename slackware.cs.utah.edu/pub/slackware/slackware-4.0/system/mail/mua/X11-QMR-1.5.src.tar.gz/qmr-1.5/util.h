/*========================================================================*
 * TITLE:	Qwik Mail Reader for Unix/Linux
 * MODULE:	util.h -- Prototypes for utility funcs
 * BY:		Ross C LINDER	(c) 1994 All rights reserved
 *
 * X11-QMR is Copyright (c) 1994 of Ross C Linder. X11-QMR is not public
 * domain. Permission is granted to use and distribute X11-QMR freely.
 * 
 * The only restriction is that you do not attempt to prevent others from
 *  having free access to the source.
 *
 * @(#)util.h	$Revision: 1.2 $	$Date: 1995/05/19 12:29:14 $
 *========================================================================*/

Widget tree_widget (Widget parent, ...);
Widget info_dialog (char *text, char *but1, char *but2, char *but3, void (*call));
Widget query_dialog (char *text, char *but1, char *but2, char *but3, void (*call));
Widget error_dialog (char *text, char *but1, char *but2, char *but3, void (*call));
Widget working_dialog (char *text, char *but1, char *but2, char *but3, void (*call));
Widget warn_dialog (char *text, char *but1, char *but2, char *but3, void (*call));
char *xmsstr (XmString xms);
void XmComboBoxDeleteAllItems (Widget w);
void XmComboBoxAddItem (Widget w, XmString xms, int pos);
void XmComboBoxSelectPos (Widget w, int pos, Boolean notify);
char *XmComboBoxGetString (Widget w);

