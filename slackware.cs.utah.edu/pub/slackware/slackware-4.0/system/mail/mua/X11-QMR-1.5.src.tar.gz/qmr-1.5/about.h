/*========================================================================*
 * TITLE:	Qwik Mail Reader for Unix/Linux
 * MODULE:	about.h -- The about message
 * BY:		Ross C LINDER	(c) 1994 All rights reserved
 *
 * X11-QMR is Copyright (c) 1994 of Ross C Linder. X11-QMR is not public
 * domain. Permission is granted to use and distribute X11-QMR freely.
 * 
 * The only restriction is that you do not attempt to prevent others from
 *  having free access to the source.
 *
 * If you make some usefull modifications to qmr, then send them to me
 * I will include them and give you credit.
 *========================================================================*/


char	about_msg[]= {
" X11-QMR is Copyright (c) 1994/95 of Ross C Linder. X11-QMR is not public
 domain. Permission is granted to use and distribute X11-QMR freely.

 Bugs and suggestions may be sent to.

 Ross C Linder           Email:    ross@mecalc.co.za
 P.O Box 101             Ftp:      sleepy.softconn.co.za
 Bromhof                           /pub/X11-QMR/
 South Africa            
 2154                    Ph: +27 (11) 793-4818 (SAST !)
"};
