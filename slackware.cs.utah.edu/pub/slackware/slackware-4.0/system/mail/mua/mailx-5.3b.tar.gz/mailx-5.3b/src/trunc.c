#include "rcv.h"
#include <sys/stat.h>
#include <sys/file.h>
#include <stdio.h>
/* #include <sys/locking.h> */

#include <fcntl.h>

void trunc(stream, name)
FILE *stream;
char *name;
{
char	temp[24];
int	pid;
FILE	*tf;
long	i;
char	bfr[512];
struct stat	statbuf;

	pid = getpid();
	sprintf(temp, "/tmp/Rs%05dz", pid);
	tf = fopen(temp, "w+");
	if (tf == (FILE *)0) return;
			/* get file status for future use */
	stat(name,&statbuf);
	i = ftell(stream);
	rewind(stream);
	do {
		fgets(bfr,512,stream);
		fprintf(tf, "%s",bfr);
	} while (ftell(stream) < i);
	fclose(stream);
	unlink(name);
	stream = fopen(name,"w+");
			/* restore file status and owner and group */
	chown(name,(int) statbuf.st_uid, (int) statbuf.st_gid);
	chmod(name, (int) statbuf.st_mode & 0777);
	rewind(tf);
	do {
		fgets(bfr, 512, tf);
		fprintf(stream,"%s",bfr);
	} while (!feof(tf));
	
	fclose(tf);
	unlink(temp);
}
	
	
	

