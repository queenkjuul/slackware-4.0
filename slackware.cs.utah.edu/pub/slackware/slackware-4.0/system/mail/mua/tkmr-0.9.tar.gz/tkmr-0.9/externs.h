extern int hits();
extern void parse_file();
extern struct message *messages[];
extern struct message *firstmsg;
extern struct message *gomsg();
extern struct mbox *mboxes[];
extern int mbox_number;
extern int number;
extern char *skip_whitespace();

extern int errno;

extern struct regexp *exp1,*exp2,*exp3,*exp4;
