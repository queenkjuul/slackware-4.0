/* configurable paths */

/* some "test" settings -- for ease of running without installing */

#ifdef KEEP_HERE 
#define MR_PATH "./mr"
#define MRTCL_PATH "./client/mr.tcl"

#else

/* pathname  of  mr  can be overridden in makefile */

#ifndef MR_PATH
#define MR_PATH "/home/users/teffta/work/mr/mr"
#endif

/* pathname of mr.tcl */

#ifndef MRTCL_PATH
#define MRTCL_PATH "/home/users/teffta/work/mr/client/mr.tcl"
#endif

#endif /* keep_here */

/* pathname of wish */

#ifndef WISH_PATH
#define WISH_PATH "/usr/local/bin/wish"
#endif


/* message types */

#define INFO   0
#define ERROR  1

static char *msg_colors[2]={ "black", "red" };

