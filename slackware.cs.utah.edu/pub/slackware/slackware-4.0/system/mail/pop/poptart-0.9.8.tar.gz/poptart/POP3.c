/*    poptart -- A general-purpose POP3 client
    Copyright (C) 1996 Jim Anderson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    Jim Anderson may be contacted at jim.anderson@accessone.com
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <pwd.h>
#include <time.h>
#include <sys/types.h>
#include "poptart.h"
#include "POP3.h"

extern void net_init(void);			/* Init comms */
extern int net_connect(const char *host);	/* Make a connection -1 = error, net has reported why */
extern int POPConnect(const char *host, int nPort);   /* Make a connection, specifying the port */
extern int net_getline(char *buf,int len,long time);
				/* Get a line of text ending \r\n - return PE_NETERROR for error, PE_TIMEOUT timeout , PE_BUFFEROVERFLOW overlong input */
				/* result buffer has the \r\n stripped */
extern void net_sendline(const char *buf);	/* send a null terminated line of data */



static char szLinebuffer[LINEBUFLEN];
static FILE *fOutput;			/* Output mailbox */

/* These functions wrap the net IO functions to allow for debug writes to the screen */
void NetSend(const char *sBuf, int fDebug)
{
	if (fDebug)
		printf("%s\n", sBuf);
	net_sendline(sBuf);
}

int NetFetch(char *sBuf, int nLen, long lTime, int fDebug)
{
  if (fDebug) printf("%s\n", sBuf);
  return net_getline(sBuf, nLen, lTime);
}

/* General error handler */
static void ShowError(const int nError,const char *szError)
{
  switch(nError) {
  case PE_NETERROR:
    fprintf(stderr, "%s failed while %s: Network error.\n", POPTART_NAME, szError);
    exit(1);
    break;
  case PE_TIMEOUT:
    fprintf(stderr, "%s failed while %s: No reponse after %ld seconds.\n", POPTART_NAME, szError, IO_TIMEOUT);
    exit(1);
    break;
  case PE_BUFFEROVERFLOW:
    fprintf(stderr, "%s was given a stupidly long line while %s by the remote POP3 server. \n", POPTART_NAME, szError);
    exit(1);
    break;
  case PE_OUTOFMEMORY:
    fprintf(stderr, "poptart ran out of memory\n");
    exit(1);
    break;
  case PE_UNKNOWNUSER:
    fprintf(stderr, "It's kind of hard to ask for your mail if you don't say who you are...\n");
    exit(1);
    break;
  case PE_POPTARTEXPLODED:
    fprintf(stderr, "%s encountered an unrecoverable error doing %s and will now explode.\n", POPTART_NAME, szError);
    exit(1);
    break;
  case PE_CANTCONNECT:
    fprintf(stderr, "%s unable to connect.\n", szError);
    exit(1);
    break;
  case PE_CANTOPENMAILFILE:
    fprintf(stderr, "Unable to open mailfile %s.\n", szError);
    exit(1);
    break;
  case PE_NOUIDL:
    fprintf(stderr, "Unable to retrieve a message UIDL.  Your"
                     "\nPop3 server might not support UIDL.");
    exit(1);
    break;
  default:
    fprintf(stderr, "Unexpected error -- please contact Jim Anderson (jim.anderson@accessone.com).\nPat yourself on the back, you found a bug!\n\n");
    exit(1);
    break;
  }
}

/* Check for error */
static void FetchLine(const char *szMsg, int fDebug)
{
int nError;
const char *lp;
   
   nError = NetFetch(szLinebuffer,LINEBUFLEN,IO_TIMEOUT, fDebug);
   if(nError<0) ShowError(nError,szMsg);
   if(*szLinebuffer=='-') {
     lp=szLinebuffer;
     while(*lp&&!isspace(*lp))
       lp++;
     fprintf(stderr,"%s was told '%s' while %s and gave up.\n",POPTART_NAME, lp+1,szMsg);
     exit(1);
   }
}

/* Log on to the mail server */
void LogToHost(struct popstruct *ps)
{
	char sBuf[64];
	if (ps->user==NULL) ShowError(PE_UNKNOWNUSER, NULL);
  
	sprintf(sBuf, PTPC_SENDUSER, ps->user);
	NetSend(sBuf, ps->fDebug);
	FetchLine("sending the username", ps->fDebug);
	sprintf(sBuf, PTPC_SENDPASS, ps->pwd);
	NetSend(sBuf, ps->fDebug);
	FetchLine("sending the password", ps->fDebug);
}


typedef struct _msgent Message;
struct _msgent
{
	Message *Next;
	char *Identity;
};

static Message *Messages=NULL;

static void get_msg_list(int fDebug)
{
  int nError;
  char *lp,*tmp;
  Message *m,*last=NULL;
  
  NetSend(PTPC_GETLIST, fDebug);
  FetchLine("getting a message list", fDebug);
  while(1) {
    nError=NetFetch(szLinebuffer,LINEBUFLEN,IO_TIMEOUT, fDebug);
    if(nError<0) 
	ShowError(nError,PTEM_READINGMLIST);
    lp=szLinebuffer;
    if(*lp=='.') {      if(lp[1]==0) break;
      lp++;
    }
    m=(Message *)malloc(sizeof(Message));
    if(m==NULL) ShowError(PE_OUTOFMEMORY,NULL);
    m->Next=NULL;
    if(last!=NULL)
      last->Next=m;
    else
      Messages=m;
    last=m;
    tmp=lp;
    while(*lp&&!isspace(*lp))
      lp++;
    *lp=0;
    m->Identity=strdup(tmp);
    if(m->Identity==NULL) 
	ShowError(PE_OUTOFMEMORY, NULL);
  }
}

static void get_uidl(char* msg_num, char* uidl, int len, int fDebug)
{
   int nError;
   char sBuf[64];
   char* lp;

   sprintf(sBuf, PTPC_UIDL, msg_num);
   NetSend(sBuf, fDebug);
   nError = NetFetch(szLinebuffer,LINEBUFLEN,IO_TIMEOUT,fDebug);
   if (nError<0) 
       ShowError(PE_NOUIDL, NULL);
   lp = szLinebuffer;
   while(*lp != ' ') lp++;
   if (*lp == 0) 
       ShowError(PE_NOUIDL, NULL);
   lp++;
   while(*lp != ' ') lp++;
   if (*lp == 0) 
       ShowError(PE_NOUIDL, NULL);
   lp++;
   strncpy(uidl, lp, len);
}

static void fetch_message(FILE *fMailfile, Message *m, struct popstruct *ps)
{
    char szTmp[1024];
    char szCmd[1536];
    char szBuf[128];
    time_t tTime;
    int  nError;
    char *lp;
    int  nPast_header=0;
    
    if (!fMailfile) {
	if (!ps->temp) {
	    tmpnam(szTmp);
	    ps->temp = malloc(strlen(szTmp));
	    if (!ps->temp) 
		ShowError(PE_OUTOFMEMORY, NULL);
	    strcpy(ps->temp, szTmp);
	}
	fMailfile = fopen(szTmp, "w");
	if (!fMailfile) {
	    fprintf(stderr, "Couldn't create temp file (%s) for .forward processing!\n Giving up!\n", szTmp);
	    exit(1);
	}
	if (ps->fDebug)
	    printf("Piping through %s\n", ps->forward);
    }
    
    /* Amateur radio wants to send a single packet of the request for those poor 1200 baud people ! */
    if(strlen(m->Identity)>100){
	NetSend(PTPC_RETR_PRE, ps->fDebug);
	NetSend(m->Identity, ps->fDebug);
	NetSend(PTPC_POSTFIX, ps->fDebug);
    }
    else{
	sprintf(szBuf,PTPC_RETR,m->Identity);
	NetSend(szBuf, ps->fDebug);
    }
    FetchLine("fetching a message", ps->fDebug);
   
    /* This is here because pine is really finicky about mail delimiters */
    tTime = time(NULL);
    fprintf(fMailfile, "%s%s", PTS_FROMSTRING, ctime(&tTime));
    
    while(1) {
	nError=NetFetch(szLinebuffer,LINEBUFLEN,IO_TIMEOUT, ps->fDebug);
	if(nError<0)
	    ShowError(nError,"fetching a message");
	lp=szLinebuffer;
	if(*lp=='.')
	    {
		if(lp[1]==0)
		    break;
		lp++;
	    }
	if(nPast_header && strncmp(lp,"From",4)==0)
	    fputc('>',fMailfile);	/* Quote from lines */
	if(*lp==0)
	    nPast_header=1;
	fputs(lp,fMailfile);
	fputc('\n',fMailfile);
    }
    if (!ps->fPreserve)
	{
	    if(strlen(m->Identity)>100) {
		NetSend(PTPC_DELETE_PRE, ps->fDebug);
		NetSend(m->Identity, ps->fDebug);
		NetSend(PTPC_POSTFIX, ps->fDebug);
	    }
	    else {
		sprintf(szBuf, PTPC_DELETE,m->Identity);
		NetSend(szBuf, ps->fDebug);
	    }
	    FetchLine("deleting a message", ps->fDebug);
	}
    if (ps->forward) {
	fclose(fMailfile);
	sprintf(szCmd, "cat %s %s", szTmp, ps->forward);
	if (ps->fDebug)
	    printf("system(%s)\n", szCmd);
	system(szCmd);
	unlink(szTmp);
    }
}

void RetrieveMessages(struct popstruct *ps)
{

  Message *m;
  Message* prev;
  char szFile[512];
  FILE *fp;   /* For the forward file */ 
	
  if (ps->fDebug) printf("Initializing connection...\n");
  net_init();
  if (ps->fDebug) printf("Connecting to host...\n");		
  if (POPConnect(ps->host, atoi(ps->port))==-1) ShowError(PE_CANTCONNECT, ps->host);
  if (ps->fDebug) printf("Opening mailfile %s.\n", ps->mailfile);
  sprintf(szFile, "%s/.forward", ps->home);
  fp = fopen(szFile, "r");
  if (fp) {
      char szBuf[1024];
      if (!fgets(szBuf, 1024, fp)) {
	  fprintf(stderr, "Bad .forward file! Giving up!\n");
	  exit(1);
      }
      ps->forward = malloc(strlen(szBuf) + 1);
      if (!ps->forward) 
	  ShowError(PE_OUTOFMEMORY, NULL);
      strcpy(ps->forward, szBuf);
      fclose(fp);
      fOutput = NULL;
  }
  else {
      ps->forward = NULL;
      fOutput = fopen(ps->mailfile, "a");
      if (fOutput == NULL) {
	  fprintf(stderr, "Unable to open mailfile %s.\n", ps->mailfile);
	  perror(ps->mailfile);
	  exit(1);
      }
  }
				
  FetchLine("waiting for the banner to fall", ps->fDebug);
				
  LogToHost(ps);
			
  get_msg_list(ps->fDebug);

  m=Messages;
  prev = NULL;

  while(m!=NULL)
  {
    if (ps->use_uidl)
    {
      char uidl[256];
      get_uidl(m->Identity, uidl, 255, ps->fDebug);
      re_comp(uidl);
      if (ps->popstats && re_exec(ps->popstats) == 1)
      {
         /* Remove m from Messages list */
         if (prev == NULL)
         {  Messages = m->Next;
            free(m);
            m = Messages;
         }
         else
         {  prev->Next = m->Next;
            free(m);
            m = prev->Next;
         }
      }
      else
      {
         /* Retrieve the message! */
         fetch_message(fOutput, m, ps);
         prev = m;
         m = m->Next;
      }
      if (ps->popfd != -1)
      {  write(ps->popfd, uidl, strlen(uidl));
         write(ps->popfd, "\n", 1);
      }
    }
    else
    {
       /* Retrieve the message no matter what! */
       fetch_message(fOutput, m, ps);
       prev = m;
       m = m->Next;
    }
  }

  fclose(fOutput);

  NetSend(PTPC_QUIT, ps->fDebug);
  FetchLine("logging out", ps->fDebug);
}
