/*    poptart -- A general-purpose POP3 client
    Copyright (C) 1996 Jim Anderson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    Jim Anderson may be contacted at jim.anderson@accessone.com
*/

#define IO_TIMEOUT		120L		/* 2 minutes - less for non amateur radio! */

/* changed from 515 in hopes of fixing some peoples POP problems with buffer overruns... */
#define LINEBUFLEN  2048     /* POP standard isn't clear if this includes the \r\n or not... */

/* Error codes */
#define PE_NOERROR 0
#define PE_NETERROR -1
#define PE_TIMEOUT -2
#define PE_BUFFEROVERFLOW -3
#define PE_OUTOFMEMORY -4
#define PE_UNKNOWNUSER -5
#define PE_POPTARTEXPLODED  -6
#define PE_CANTCONNECT -7
#define PE_CANTOPENMAILFILE -8
#define PE_NOUIDL -9

/* Error messages */
#define PTEM_OUTOFMEMORY  "poptart ran out of memory\n"
#define PTEM_READINGMLIST  "reading list of messages"

/* From string prefix */
#define PTS_FROMSTRING "From poptart "

/* POP3 commands */
#define PTPC_POSTFIX  "\r\n"
#define PTPC_GETLIST  "LIST\r\n"
#define PTPC_SENDPASS  "PASS %s\r\n"
#define PTPC_SENDUSER  "USER %s\r\n"
#define PTPC_UIDL "UIDL %s\r\n"
#define PTPC_RETR  "RETR %s\r\n"
#define PTPC_RETR_PRE  "RETR "
#define PTPC_DELETE  "DELE %s\r\n"
#define PTPC_DELETE_PRE  "DELE "
#define PTPC_QUIT "QUIT\r\n"

struct popstruct {
    char *user;
    char *pwd;
    char *host;
    char *port;
    char *mailfile;
    /* Password and host are the two things we can't figure decent
       defaults for. fPwd and fHost are set true if we have values for
       them - otherwise we need to prompt for them. */
    int fPwd;	
    int fHost;	
    /* True if we won't display a banner */
    int fSilent;
    /* True if we are viewing debuggin info */
    int fDebug;
    /* True if we have enough info to go by -- obsolete */
    int fValid;
    /* True if we are preserving mail on the host */
    int fPreserve;
    /* These are part of the UIDL extensions. */
    int use_uidl;
    int popfd;
    char* popstats;
    /* This is the contents of the .forward file -- if it exists, then we will
       write a temp file, and run: cat <tmpfile> <.forward> */
    char* forward;
    /* This is the users home directory. It is used to locate the .forward file,
       and to prepend to the name of a temp file. */
    char *home;
    /* This is the name of a temp file used with .forward files */
    char *temp;
};
