#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>

int main() {
    FILE *fp;
    char *pszForward;
    FILE * fOutput;
    struct passwd *pwd;
    char szFile[1024];

    pwd = getpwuid(getuid());

    sprintf(szFile, "%s/.forward", pwd->pw_dir);

    fp = fopen(szFile, "r");
  printf("Attempting to open file %s\n", szFile);
  if (fp) {
      char szBuf[1024];
      printf("Opened!\n");
      if (!fgets(szBuf, 1024, fp)) {
	  fprintf(stderr, "Bad .forward file! Giving up!\n");
	  exit(1);
      }
      pszForward = malloc(strlen(szBuf) + 1);
      if (!pszForward) {
	  /* ShowError(PE_OUTOFMEMORY, NULL); */
	  exit(1);
      }
      strcpy(pszForward, szBuf);
      fclose(fp);
      fOutput = NULL;
      printf("pszForward = %s\n", pszForward);
  }
  else
      printf("Couldn't open ~/.forward\n"); 
}
