/*    poptart -- A general-purpose POP3 client
    Copyright (C) 1996 Jim Anderson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    Jim Anderson may be contacted at jim.anderson@accessone.com
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "poptart.h"
#include "POP3.h"

extern void RetrieveMessages(struct popstruct *ps);

struct passwd *pwdUser;

static struct popstruct psMain;

void ShowError(nError, szError)
{
  switch(nError) {
  case PTE_NOERROR:
    break;
  case PTE_EXPLODED:
    fprintf(stderr, "%s encountered an unrecoverable error doing %s and will now explode.\n", POPTART_NAME, szError);
    exit(1);
    break;
  case PTE_OUTOFMEMORY:
    fprintf(stderr, "%s ran out of memory\n", POPTART_NAME);
    exit(1);
    break;
  case PTE_NOHOST:
    fprintf(stderr, "%s cannot retrieve your mail if it doesn't know the mailserver!!\n", POPTART_NAME);
    exit(1);
    break;
  case PTE_BADRSFILE:
    fprintf(stderr, "%s can't find the resource file %s.\n", POPTART_NAME, szError);
  default:
    fprintf(stderr, "Unexpected error -- please contact Jim Anderson (jim.anderson@accessone.com).\nPat yourself on the back, you found a bug!\n\n");
    exit(1);
    break;
  }
}

void SetDefaults(struct popstruct *ps)
{
	/* Read the user name */
	pwdUser = getpwuid(getuid());
	if (pwdUser == NULL) ShowError(PTE_EXPLODED, "getting user info");
	ps->user = pwdUser->pw_name;
	ps->home = pwdUser->pw_dir;
	ps->mailfile = malloc(strlen(DEFAULT_MAILFILE) + strlen(ps->user) + 1);
	if (ps->mailfile == NULL) ShowError(PTE_OUTOFMEMORY, NULL);
	strcpy(ps->mailfile, DEFAULT_MAILFILE);
	strcat(ps->mailfile, ps->user);
	ps->port = DEFAULT_PORT;
	ps->fDebug = 0;
	ps->fPreserve = 0;  
	ps->use_uidl = 0;
	ps->popfd = -1;
	ps->popstats = NULL;
	ps->fPwd = 0;
	ps->fHost = 0;
	ps->fSilent = 0;
}  

void DispHelp(void)
{
	printf("Useage: poptart [OPTION]...\n\n");
	printf("%s <file>, %s <file>\tsave mail to the file <file>\n", PTC_MAILFILE, PTG_MAILFILE);
	printf("%s <host>, %s <host>\tconnect to host <host>\n", PTC_HOST, PTG_HOST);
	printf("%s <user>, %s <user>\tconnect as user <user>\n", PTC_USER, PTG_USER);
	printf("%s <pwd>, %s <pwd>\tconnect with the password <pwd>\n", PTC_PASSWORD, PTG_PASSWORD);
	printf("%s, %s\t\t\tprompt for a password to connect with\n", PTC_PROMPTPWD, PTG_PROMPTPWD);
	printf("%s <port>, %s <port>\tconnect to port <port> on the host\n", PTC_PORT, PTG_PORT);
	printf("%s, %s\t\t\tpreserve mail on the host\n", PTC_PRESERVE, PTG_PRESERVE);
	printf("%s, %s\t\t\tuse UIDLs to retrieve each message only once\n", PTC_UIDL, PTG_UIDL);
	printf("%s <file>, %s <file>\tread options from the file <file>\n",
      PTC_RSFILE, PTG_RSFILE);
	printf("%s, %s\t\t\trun in debug mode\n", PTC_DEBUG, PTG_DEBUG);
	printf("%s, %s, %s\t\tdisplay help\n", PTC_HELP, PTC_HELP2, PTG_HELP);
	printf("%s, %s\t\t\trun silently\n", PTC_SILENT, PTG_SILENT);	
}

void DispVersion(void)
{
	printf("%s version %s Copyright (c) 1996 Outback Software.\n", POPTART_NAME, POPTART_VERSION);
	printf("%s is covered under the Gnu General Public License,\n", POPTART_NAME);
	printf("and comes with ABSOLUTELY NO WARRANTY!\n");
}

static void load_popstats()
{
   char* homedir;
   char fname[256];
   struct stat fstatus;
   int bytes;

   homedir = getenv("HOME");
   sprintf(fname, "%s%s", homedir, "/.popstats");
   psMain.popfd = open(fname, O_RDONLY);
   if (psMain.popfd != -1)
   {
      fstat(psMain.popfd, &fstatus);
      psMain.popstats = (char*)malloc(fstatus.st_size + 256);
      bytes = read(psMain.popfd, psMain.popstats, fstatus.st_size + 255);
      psMain.popstats[bytes] = 0;
      close(psMain.popfd);
      psMain.popfd = 0;
   }

   unlink(fname);
   psMain.popfd = open(fname, O_WRONLY | O_CREAT, 0644);
}

void PromptForPopPwd(struct popstruct *ps) 
{
    ps->pwd=getpass("Password:");
    ps->fPwd = 1;
}

void PromptForPopHost(struct popstruct *ps)
{
char *szBuf;

 szBuf = malloc(128);
 if (szBuf == NULL) ShowError(PTE_OUTOFMEMORY, NULL);
 
 printf("Mail Host:");
 szBuf = gets(szBuf);
 if (strlen(szBuf) > 0) {
     ps->host = malloc(strlen(szBuf) + 1);
     if (ps->host == NULL) ShowError(PTE_OUTOFMEMORY, NULL);
     strcpy(ps->host, szBuf);
     ps->fHost = 1;
 } else ShowError(PTE_NOHOST, NULL);\
 
 free(szBuf);
}

void PromptForPopStruct(struct popstruct *ps)
{
/* Prompt for the info: user; pwd; host; port; mailfile */
char *szBuf;

 if (!ps->fSilent)
     DispVersion();
 
 szBuf = malloc(128);
 if (szBuf == NULL) ShowError(PTE_OUTOFMEMORY, NULL);
 
 printf("Username (%s):", ps->user);
 szBuf = gets(szBuf);
 if (strlen(szBuf) > 0) {
     free(ps->user);
     ps->user = malloc(strlen(szBuf) + 1);
     if (ps->user == NULL) ShowError(PTE_OUTOFMEMORY, NULL);
     strcpy(ps->user, szBuf);
 }
 
 PromptForPopPwd(ps);
 PromptForPopHost(ps);
 
 printf("Port (%s):", ps->port);
 szBuf = gets(szBuf);
 if (strlen(szBuf) > 0) {
     if (atoi(szBuf) > 0) {
	 ps->port = malloc(strlen(szBuf) + 1);
	 if (ps->port == NULL) ShowError(PTE_OUTOFMEMORY, NULL);
	 strcpy(ps->port, szBuf);
     }
 }
 
 printf("Mailfile (%s):", ps->mailfile);
 szBuf = gets(szBuf);
 if (strlen(szBuf) > 0) {
     free(ps->mailfile);
     ps->mailfile = malloc(strlen(szBuf) + 1);
     if (ps->mailfile == NULL) ShowError(PTE_OUTOFMEMORY, NULL);
     strcpy(ps->mailfile, szBuf);
 }
 
 ps->fValid = 1;
 free(szBuf);
}


int FillPopStruct(int argc, char *argv[], struct popstruct *ps, int fBanner)
{
int nIndex;
int fError;
int fDispOnly;

 fError = 0;
 fDispOnly = 0;
 if (argc > 1) {
     for (nIndex = 1; nIndex < argc; nIndex++) {
	 if ((strcmp(argv[nIndex], PTC_DEBUG) == 0) | (strcmp(argv[nIndex], PTG_DEBUG) ==0))
	     ps->fDebug = 1;
	 else if ((strcmp(argv[nIndex], PTC_MAILFILE) == 0) | (strcmp(argv[nIndex], PTG_MAILFILE) == 0)) {
	     free(ps->mailfile);
	     ps->mailfile = malloc(strlen(argv[++nIndex]) + 1);
	     fError = (ps->mailfile == NULL);
	     strcpy(ps->mailfile, argv[nIndex]);
	 }
	 else if ((strcmp(argv[nIndex], PTC_HELP) == 0) | (strcmp(argv[nIndex], PTG_HELP) == 0) | (strcmp(argv[nIndex], PTC_HELP2) == 0)) {
	     DispHelp();
	     fDispOnly = 1;
	 }
	 else if ((strcmp(argv[nIndex], PTC_HOST) == 0) | (strcmp(argv[nIndex], PTG_HOST) == 0)) {
	     ps->host = malloc(strlen(argv[++nIndex]) + 1);
	     if (!fError) fError = (ps->host == NULL);
	     strcpy(ps->host, argv[nIndex]);
	     ps->fHost = 1;
	 }
	 else if ((strcmp(argv[nIndex], PTC_PRESERVE) == 0) | (strcmp(argv[nIndex], PTG_PRESERVE) == 0)) 
	     ps->fPreserve = 1;
	 else if ((strcmp(argv[nIndex], PTC_USER) == 0) | (strcmp(argv[nIndex], PTG_USER) == 0)) {
	     ps->user = malloc(strlen(argv[++nIndex]) + 1);
	     if (!fError) fError = (ps->user == NULL);
	     strcpy(ps->user, argv[nIndex]);
	 }
	 else if ((strcmp(argv[nIndex], PTC_VERSION) == 0) | (strcmp(argv[nIndex], PTG_VERSION) == 0)) {
	     fError = 1;
	 }
	 else if ((strcmp(argv[nIndex], PTC_PASSWORD) == 0) | (strcmp(argv[nIndex], PTG_PASSWORD) == 0)) {
	     ps->pwd = malloc(strlen(argv[++nIndex]) + 1);
	     if (!fError) fError = (ps->pwd == NULL);
	     strcpy(ps->pwd, argv[nIndex]);
	     ps->fPwd = 1;
	 }
	 else if ((strcmp(argv[nIndex], PTC_PROMPTPWD) ==0) | (strcmp(argv[nIndex], PTG_PROMPTPWD) == 0)) 
	     PromptForPopPwd(ps);
	 else if ((strcmp(argv[nIndex], PTC_PORT) == 0) | (strcmp(argv[nIndex], PTG_PORT) == 0)) {
	     ps->port = malloc(strlen(argv[++nIndex]) + 1);
	     if (!fError) fError = (ps->port == NULL);
	     strcpy(ps->port, argv[nIndex]);
	 }
	 else if ((strcmp(argv[nIndex], PTC_UIDL) == 0) | (strcmp(argv[nIndex], PTG_UIDL) == 0))
	     {
		 ps->use_uidl = 1;
		 load_popstats();
	     }
	 else if ((strcmp(argv[nIndex], PTC_SILENT) == 0) | (strcmp(argv[nIndex], PTG_SILENT) == 0))
	     ps->fSilent = 1;
	 else if ((strcmp(argv[nIndex], PTC_RSFILE) == 0) | (strcmp(argv[nIndex], PTG_RSFILE) == 0)){
	     FillPopStructFromFile((char *)argv[++nIndex], ps);
	 }
	 else {
	     fError = 1;
	 }
     }
 }
 else
     fError = 1;
 
 if (!fError) {
     if ((!ps->fSilent) & (fBanner))
	 DispVersion();
     if (!ps->fPwd) PromptForPopPwd(ps);
     if (!ps->fHost) PromptForPopHost(ps);
 }
 
 ps->fValid = !fDispOnly;
 if (fDispOnly)
     return 1;
 else
     return !fError;
}

void DumpPS(struct popstruct *ps)
{
    printf("User: %s\nPwd: %s\nHost: %s\nPort: %s\n", ps->user, ps->pwd, ps->host, ps->port);
    printf("Mailfile: %s\n", ps->mailfile);
    
    if(ps->fPwd)
	printf("fPwd set, ");
    else
	printf("fPwd not set,  ");
    
    if (ps->fHost)
	printf("fHost set\n");
    else
	printf("fHost not set\n");
    
    printf("use_uidl: %d, popfd: %d\n", ps->use_uidl, ps->popfd);
    printf("popstats: %s\n", ps->popstats);
    
    if (ps->fDebug)
	printf("Debug set on\n");
    else
	printf("Debug set off\n");
}

int FillPopStructFromFile(char *szFile, struct popstruct *ps)
{
/* Fill the popstruct from a resource file */
FILE *fRS;
char *szRS;
char *szBuf;
char *pargv[20];
int pargc;
int i;

 pargc = 1;
 fRS = fopen(szFile, "r");
 if (fRS == NULL) ShowError(PTE_BADRSFILE, szFile);
 szRS = malloc(1024);
 szRS = fgets(szRS, 1024, fRS);
 szBuf = strtok(szRS, " \n\t\f\r");
 while (szBuf != NULL) {
     pargv[pargc] = malloc(strlen(szBuf) + 1);
     if (pargv[pargc] == NULL) ShowError(PTE_OUTOFMEMORY, NULL);
     strcpy(pargv[pargc++], szBuf);
     szBuf = strtok(NULL, " \n\t\f\r");
     
 }
 FillPopStruct(pargc, pargv, ps, 0);
 fclose(fRS);
 return (1);
}

void main(int argc, char *argv[])
{
    SetDefaults(&psMain);
    if (argc == 1) { 
	PromptForPopStruct(&psMain);
	if (psMain.fValid) RetrieveMessages(&psMain);
    }
    else {
	if (FillPopStruct(argc, argv, &psMain,1)) 
	    if (psMain.fValid) RetrieveMessages(&psMain);
	    else {
		printf("Type %s -h for help.\n", POPTART_NAME);
		exit(1);
	    }
    }
    
    /* 	DumpPS(&psMain); */
    
    if (psMain.popfd != -1) close(psMain.popfd);
}

