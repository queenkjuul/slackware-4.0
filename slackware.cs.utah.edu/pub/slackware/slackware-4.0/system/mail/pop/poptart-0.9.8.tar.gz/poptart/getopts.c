/*
    getopts.c

    This is an implementation of GNU-style long program options for use on systems
    which do not have the GNU libraries. It is not intended to be efficient, but it
    should work for everyone.
    
    Copyright (C) 1997 Jim Anderson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    Jim Anderson may be contacted at jim.anderson@accessone.com
*/

#include "getopts.h"
#include <stdio.h>
#include "trace.h"

int getopt_long (int ARGC, char **ARGV, const char
                 *SHORTOPTS, struct option *LONGOPTS, int *INDEXPTR) {
  int oi, i = 0, found = 0, done = 0, err = 0;

  TRACE("getopt_long(%d, **ARGV, %s, *LONGOPTS, %d) optind == %d\n", ARGC, SHORTOPTS, &INDEXPTR, optind);
  
  if (++optind == ARGC) 
    return -1;

  oi = optind;
  
  /* Can we find the option in *LONGOPTS? */
  if ((*(*(ARGV + oi)) == '-') && (*(*(ARGV + oi) + 1) == '-')) {
    TRACE("Found a long arg: %s\n", *(ARGV + oi));
    while (!done) {
      if (strcasecmp((*(ARGV + oi) + 2), (LONGOPTS + i)->name) == 0) {
        TRACE("Identified long argument: (LONGOPTS + %d)->name == %s\n", i, (LONGOPTS + i)->name);
        found = 1;
        done = 1;
      }
      else
        i++;
      if ((LONGOPTS + i)->name == 0) {
        TRACE("Couldn't identify a long argument\n");
        done = 1;
      }
    }
  }
  if (!found)
    return getopt(ARGC, ARGV, SHORTOPTS);
  else {
    /* Set up for return */
    TRACE("Setting up for return on %s\n", *(LONGOPTS + i));
    TRACE("(LONGOPTS + %d)->has_arg == %d\n", i, (LONGOPTS + i)->has_arg);
    optarg = NULL;
    if ((LONGOPTS + i)->has_arg == required_argument) {
      TRACE("Required argument\n");
      if (++oi == ARGC) {
        err = 1;
        oi--;
        optarg == NULL;
        TRACE("%d == %d, so err = 1\n", oi, ARGC);
      }
      else 
        optarg = *(ARGV + oi);
    }
    else {
      if ((LONGOPTS + i)->has_arg == optional_argument) {
        TRACE("Optional argument\n");
        if (++oi == ARGC) {
          oi--;
          optarg == NULL;
          TRACE("%d == %d, so err = 1\n", oi, ARGC);
        }
        else
          optarg = *(ARGV + oi);
      }
      else {
        TRACE("No argument information\n");
        optarg == NULL;
      }
    }
    if (err)
      return 1;

    if ((LONGOPTS + i)->flag != NULL) {
      TRACE("((LONGOPTS + %d)->flag != NULL, so setting *((LONGOPTS + %d)->flag) to %d\n", i, i, (LONGOPTS + i)->val);
      *((LONGOPTS + i)->flag) = (LONGOPTS + i)->val;
    }

    *INDEXPTR = i;
    optind = oi;

    TRACE("Returning %d\n", (LONGOPTS + i)->val);
    return (LONGOPTS + i)->val;
  }
}
