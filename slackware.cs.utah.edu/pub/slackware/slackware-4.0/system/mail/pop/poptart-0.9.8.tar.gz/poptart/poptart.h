/*    poptart -- A general-purpose POP3 client
    Copyright (C) 1996 Jim Anderson

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    Jim Anderson may be contacted at jim.anderson@accessone.com
*/


#define POPTART_NAME "poptart"
#define POPTART_VERSION "0.9.8"

#define DEFAULT_PORT "110"
#define DEFAULT_MAILFILE "/var/spool/mail/"

/* command line parameters */
#define PTC_HELP "-?"
#define PTC_HELP2 "-h"
#define PTG_HELP "--help"
#define PTC_VERSION "-v"
#define PTG_VERSION "--version"
#define PTC_DEBUG "-d"
#define PTG_DEBUG "--debug"
#define PTC_HOST "-mh"
#define PTG_HOST "--host"
#define PTC_PORT "-mp"
#define PTG_PORT "--port"
#define PTC_PRESERVE "-p"
#define PTG_PRESERVE "--preserve"
#define PTC_USER "-u"
#define PTG_USER "--user"
#define PTC_PASSWORD "-pw"
#define PTG_PASSWORD "--password"
#define PTC_PROMPTPWD "-ppw"
#define PTG_PROMPTPWD "--promptpassword"
#define PTC_MAILFILE "-mf"
#define PTG_MAILFILE "--mailfile"
#define PTC_RSFILE "-rs"
#define PTG_RSFILE "--rsfile"
#define PTC_UIDL "-i"
#define PTG_UIDL "--uidl"
#define PTC_SILENT "-s"
#define PTG_SILENT "--silent"

#define PTE_NOERROR 0
#define PTE_EXPLODED -1
#define PTE_OUTOFMEMORY -2
#define PTE_NOHOST -3
#define PTE_BADRSFILE -4

