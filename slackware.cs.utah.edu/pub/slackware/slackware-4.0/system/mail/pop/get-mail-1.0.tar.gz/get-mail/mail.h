/*
 * $Id: mail.h,v 0.2 1998/01/09 04:41:08 ral Exp $
 * 
 * $Log: mail.h,v $
 * Revision 0.2  1998/01/09 04:41:08  ral
 * *** empty log message ***
 *
 * Revision 0.1  1996/12/04 02:21:27  ral
 * *** empty log message ***
 *
 */
#include <pwd.h>
#ifndef _mailh
#define _mailh

#ifdef __cplusplus
extern "C" {
#endif

typedef struct addresses {
   char*personal_name, 
     source_route,
     boxname,
     hostname;
} addresses;

typedef struct mail_header {
   /* 
    * Bit 0: New (\recent)
    * Bit 1: Seen (\seen)
    * Bit 2: Beantwortet (\answered)
    * Bit 3: markiert (\flagged)
    * Bit 4: gel�scht (\deleted)
    */
   int flags;
   char*date,
     subject,
     inreplyto,
     messageid;
   
   addresses*from,
     sender,
     replyto,
     to,
     cc,
     bcc;
     
} mail_header;
   
typedef struct mail_Liste {
   unsigned long int Number;
   unsigned long int Bytes;
   short int del;
   struct mail_Liste*Next;
} mail_Liste;

int convert_to_unix(unsigned char*FileName);
int create_mail_entry(unsigned char*Dest, unsigned char*Src,char*dummy);
struct passwd*get_user_name();

#ifdef __cplusplus
}
#endif

#endif
