/*
 * $Id: pop3.c,v 0.2 1998/01/09 04:40:33 ral Exp $
 * 
 * $Log: pop3.c,v $
 * Revision 0.2  1998/01/09 04:40:33  ral
 * *** empty log message ***
 *
 * Revision 0.1  1996/12/04 02:21:01  ral
 * *** empty log message ***
 *
 */
/* 
 * This files implements the various pop3-routines.
 * Not the best - but it works.
 */
#include "main-tcp.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include "mail.h"
#include "misc.h"
#include "pop3.h"


pop3_data*connect_pop3(unsigned char*host,unsigned char*user,unsigned char*pass) {
   pop3_data*Pop3;
   unsigned char*Return_text;
   Pop3 = (pop3_data*)malloc(sizeof(pop3_data));
   if (Pop3 == NULL)
     return NULL;
   Pop3->UserName = (unsigned char*)malloc((strlen(user)+3)*sizeof(unsigned char));
   Pop3->PassWord = (unsigned char*)malloc((strlen(pass)+3)*sizeof(unsigned char));
   Pop3->HostName = (unsigned char*)malloc((strlen(host)+1)*sizeof(unsigned char));
   strcpy(Pop3->HostName,host);
   strcpy(Pop3->UserName,user);
   strcpy(Pop3->PassWord, pass);
   Pop3->PassWord = strcat(Pop3->PassWord, "\r\n");
   Pop3->UserName = strcat(Pop3->UserName, "\r\n");
   Pop3->socket = connect_mail(Pop3->HostName,110);
   if (!(Pop3->socket > 0))
     return Pop3;		       /* could not connect */
   Return_text = read_data(Pop3->socket,1);
   if (!(check_return(Return_text))) {
      close(Pop3->socket);
      Pop3->socket = 0;		       /* access denied */
      free(Return_text);
      return Pop3;
   }
   free(Return_text);
   Return_text = set_user(Pop3);
   if (!(check_return(Return_text))) {
      close(Pop3->socket);
      free(Return_text);
      Pop3->User_reply = 0;	       /* User not accepted */
      return Pop3;
   } else {
      Pop3->User_reply = 1;	       /* User accepted */
   }
   free(Return_text);
   Return_text = send_pass(Pop3);
   if (!(check_return(Return_text))) {
      close(Pop3->socket);
      free(Return_text);
      Pop3->Pass_reply = 0;	       /* Password not correct */
      return Pop3;
   } else {
      Pop3->Pass_reply = 1;	       /* Password correct */
   }
   free(Return_text);
   return Pop3;
}

unsigned char*POP3_disconnect(pop3_data*Pop3) {
   unsigned char*return_text;
   unsigned char*dummy;
   unsigned char*dum2;
   int code;
   if ((return_text = (unsigned char*)malloc(7*sizeof(unsigned char))) == NULL) {
      return NULL;
   }
   strcpy(return_text, "QUIT\r\n");
   code = write_data(Pop3->socket, return_text, 6);
   if (code != 6) {
      strcpy(return_text, "-errw");    /* Error writing data */
      return return_text;
   }
   free(return_text);
   return_text = read_data(Pop3->socket,1);
   if (!(check_return(return_text))) {
      strcpy(return_text, "-errc");    /* Quitting was not succesfull */
      return return_text;
   }
   dummy = strstr((strtok(return_text,"\r"))," ");
   close(Pop3->socket);
   free(Pop3);
   if (dummy == NULL) {
      free(return_text);
      return ("");
   }
   else {
      dummy = &dummy[1];
      dum2 = strdup(dummy);
      free(return_text);
   }
   return dum2;
}

int POP3_Noop(pop3_data*Pop3) {
   unsigned char*return_text;
   int code;
   code = write_data(Pop3->socket, "NOOP\r\n",6);
   if (!(code == 6)) {
      return 0;
   }
   return_text = read_data(Pop3->socket,1);
   code = check_return(return_text);
   free(return_text);
   return code;
}

int POP3_Rset(pop3_data*Pop3) {
   unsigned char*return_text;
   int code;
   code = write_data(Pop3->socket, "RSET\r\n",6);
   if (!(code == 6)) {
      return 0;
   }
   return_text = read_data(Pop3->socket,1);
   code = check_return(return_text);
   free(return_text);
   return code;
}

int POP3_Status(pop3_data*Pop3) {
   int return_code;
   unsigned char*Anzahl_s;
   unsigned char*return_text;
   return_code = write_data(Pop3->socket, "STAT\r\n",6);
   if (return_code != 6) {
      return -1;
   }
   return_text = read_data(Pop3->socket,1);
   if (!(check_return(return_text))) {
      free(return_text);
      return 0;
   }
   Anzahl_s = strchr(return_text, ' ');
   Pop3->status_zahl = strtoul(Anzahl_s, NULL, 0);
   Anzahl_s = strrchr(return_text, ' ');
   Pop3->status_groesse = strtoul(Anzahl_s, NULL, 0);
   free(return_text);
   return 1;
}

int check_return(unsigned char*return_code) {
   if (strstr(return_code, "+OK"))
     return 1;
   else
     return 0;
}

unsigned char*set_user(pop3_data*Pop3) {
   unsigned char*text;
   text = (unsigned char*)malloc(1024*sizeof(unsigned char));
   strcpy(text,"USER ");
   text = strcat(text,Pop3->UserName);
   write_data(Pop3->socket, text, strlen(text));
   free(text);
   text = read_data(Pop3->socket,1);
   return text;
}

unsigned char*send_pass(pop3_data*Pop3) {
   unsigned char*text;
   text = (unsigned char*)malloc(1024*sizeof(unsigned char));
   strcpy(text, "PASS ");
   text = strcat(text, Pop3->PassWord);
   write_data(Pop3->socket,text,strlen(text));
   free(text);
   text = read_data(Pop3->socket,1);
   return text;
}

mail_Liste*POP3_Liste(pop3_data*Pop3) {
   mail_Liste* Return_liste;
   mail_Liste* Dummy_liste = NULL;
   unsigned char*Return_text;
   unsigned char*Dummy_text = NULL;
   unsigned char*Dummy2 = NULL;
   unsigned int i = 1;
   if (!((write_data(Pop3->socket, "LIST\r\n",6)) == 6)) {
      return NULL;
   }
   Return_text = read_data(Pop3->socket, 0);   
   /* Dieses erste Auslesen dient nur
    * dem ermitteln des Status (Ok oder ERR)
    */
   Return_liste = (mail_Liste*)malloc(sizeof(mail_Liste));
   Return_liste->Number = 0;
   Return_liste->Bytes = 0;
   if (!(check_return(Return_text))) {
      return Return_liste;
   }
   while (NULL == (strstr(Return_text, "\r\n.\r\n"))) {
      i++;
      if (!(Dummy_text == NULL)) {
	 free(Dummy_text);
      }
      Dummy_text = Return_text;
      Return_text = (unsigned char*)malloc((i*101+1)*sizeof(unsigned char));
      Return_text = strcpy(Return_text, Dummy_text);
      Dummy2 = read_data(Pop3->socket, 0);
      Return_text = strcat(Return_text, Dummy2);
      free(Dummy2);
      
   }
   Dummy_text = Return_text;
   Dummy_liste = Return_liste;
   Dummy_liste->Next = NULL;
   Dummy_text=strstr(Dummy_text, "\n");
   while ((!(Dummy_text == NULL)) && (!(Dummy_text[1] == '.'))) {
      Dummy_text = &Dummy_text[1];
      Dummy_liste->Number = strtol(Dummy_text, NULL, 0);
      Dummy_text = &(strstr(Dummy_text, " "))[1];
      Dummy_liste->Bytes = strtoul(Dummy_text, NULL, 0);
      Dummy_text = strstr(Dummy_text,"\n");
      if (Dummy_text[1] == '.') {
	 Dummy_liste->Next = NULL;
      }
      else {
	 Dummy_liste->Next = (mail_Liste*)malloc(sizeof(mail_Liste));
	 Dummy_liste = Dummy_liste->Next;
      }
   }
   free(Return_text);
   return Return_liste;
}

unsigned char*POP3_Top(pop3_data*Pop3, long int Number) {
   unsigned char*Dummy_text = NULL;
   unsigned char*Return_text = NULL;
   unsigned char*Number_s = NULL;
   unsigned int i;
   Number_s = ltostr(Number);
   i = strlen(Number_s)+9;
   Return_text = (unsigned char*)malloc(i*sizeof(unsigned char));
   if (Return_text == NULL)
     return Return_text;
   strcpy(Return_text, "TOP ");
   Return_text = strcat(Return_text, Number_s);
   Return_text = strcat(Return_text, " 1\r\n");
   Return_text[i]= '\0';
   i--;
   if (!((write_data(Pop3->socket, Return_text,i)) == i)) {
      return NULL;
   }
   free(Return_text);
   Return_text = read_data(Pop3->socket, 0);
   /* Dieses erste Auslesen dient nur
    * dem ermitteln des Status (Ok oder ERR)
    */
   if (!(check_return(Return_text))) {
      if (strlen(Return_text) < 5){
	 free(Return_text);
	 Return_text = (unsigned char*)malloc(6*sizeof(unsigned char));
      }
      strcpy(Return_text, "--err");
      return Return_text;
   }
   i = 1;
   while (NULL == strstr(Return_text, "\r\n.\r\n")) {
      i++;
      if (!(Dummy_text == NULL)) {
	 free(Dummy_text);
      }
      Dummy_text = Return_text;
      Return_text = (unsigned char*)malloc(i*101*sizeof(unsigned char));
      if (Return_text == NULL) {
	 strcpy(Dummy_text, "--err Mem");
	 return Dummy_text;
      }
      Return_text = strcpy(Return_text, Dummy_text);
      Return_text = strcat(Return_text, read_data(Pop3->socket, 0));
   }
   Dummy_text = Return_text;
   Return_text = strdup(&(strstr(Return_text, "\n"))[1]);
   if (Return_text == NULL) {
      Return_text = &(strstr(Dummy_text, "\n"))[1];
   }
   else 
     free(Dummy_text);
   return Return_text;
}

/* *****************************************
 * Diese Funktion wird noch weiter �ber-   *
 * arbeitet, vor allem soll sie noch echt  *
 * 8-bit-clean gemacht werden.             *
 * *****************************************/
int POP3_getmsg(pop3_data*Pop3, long int Number, char*FileName) {
   unsigned char*Number_s;
   unsigned char*Return_text;
   FILE*fp = NULL;
   int i;
   mode_t old_umask;
   int status=0;
   int return_code;
   Number_s = ltostr(Number);
   i = strlen(Number_s)+8;
   if ((Return_text = (unsigned char*)malloc(i * sizeof(unsigned char))) == NULL){
      return -1;
   }
   Return_text = strcpy(Return_text, "RETR ");
   Return_text = strcat(Return_text, Number_s);
   Return_text = strcat(Return_text, "\r\n");
   Return_text[i]= '\0';
   i--;
   if (!((write_data(Pop3->socket, Return_text,i)) == i)) {
      if (errno == 0)
	errno = -1;
      return 0;			       /* Konnte nicht sauber geschrieben werden */
   }
   free(Return_text);
   free(Number_s);
   Return_text = (unsigned char*)malloc(5*sizeof(unsigned char));
   i = read_data_2(Pop3->socket, Return_text, 4);
   if (!(i == 4)) {
      if (errno == 0)
	errno = -1;
      free(Return_text);
      return-1;
   }
   /* Dieses erste Auslesen dient nur
    * dem ermitteln des Status (Ok oder ERR)
    */
   if (!(check_return(Return_text))) {
      free(Return_text);
      return -5;		       /* Tscha, dat mag der Server nich */
   }
   while (!(Return_text[0] == '\n')) {
      i = read_data_2(Pop3->socket, Return_text, 1);
      if (!(i == 1)){
	 free(Return_text);
	 return -1;
      }
   }
   old_umask = umask(S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH);
   fp = fopen(FileName, "w+");
   if (fp == NULL)
     return -2;			       /* Irgendwie haben wir ein Problem, das File zu erstellen */
   free(Return_text);
   Return_text = (unsigned char*)malloc(2*sizeof(unsigned char));
   if (Return_text == NULL)
     return -2;
   Number_s = (unsigned char*)malloc(5*sizeof(unsigned char));
   if (Number_s == NULL)
     return -2;
   while (status < 5){
      return_code = read_data_2(Pop3->socket, Return_text, 1);
      if (return_code == -1) {
	 fclose(fp);
	 return -1;
      }
      if (!return_code)
	break;
      if ( (Return_text[0] == '\r') && ( (status == 0) || (status==3) ) )
	{
	   Number_s[status] = Return_text[0];
	   status++;
	   Number_s[status] = '\0';
	}
      else {
	 if ( (Return_text[0] == '\n') && ( (status == 1) || (status == 4) )){
	    Number_s[status] = Return_text[0];
	    status++;
	    Number_s[status] = '\0';
	 }
	 else {
	    if ( (Return_text[0] == '.') && (status == 2) ) {
	       Number_s[status] = Return_text[0];
	       status++;
	       Number_s[status] = '\0';
	    }
	    else {
	       for (i=0;i<status;i++) {
		  fprintf(fp, "%c", Number_s[i]);
	       }
	       if (Return_text[0] == '\r') {   /* Dieser Vergleich dient */
		  status = 1;	               /* zum Filtern mehrfacher <CRLF> */
		  Number_s[0] = '\r';          /* Sequenzen. */
		  Number_s[1] = '\0';
	       }		               
	       else {
		  status = 0;
		  fprintf(fp, "%c", Return_text[0]);
	       }
	    }
	 }
      }
   }
   fprintf(fp, "%c", '\r');
   fprintf(fp, "%c", '\n');
   fflush(fp);
   fclose(fp);
   free(Return_text);
   free(Number_s);
   umask(old_umask);
   /* chmod(FileName, S_IRUSR | S_IWUSR); */
   return 1;
}
   
int POP3_delmsg(pop3_data*Pop3, mail_Liste*What) {
   int code;
   unsigned char*Number_s;
   unsigned char*Return_text;
   Number_s = ltostr(What->Number);
   code = strlen(Number_s) + 8;
   Return_text = (unsigned char*)malloc(code*sizeof(unsigned char));
   if (Return_text == NULL)
     return -1;			       /* Tscha halt Speicherprobleme */
   Return_text = strcpy(Return_text, "DELE ");
   Return_text = strcat(Return_text, Number_s);
   Return_text = strcat(Return_text, "\r\n");
   Return_text[code]= '\0';
   code--;
   if (!((write_data(Pop3->socket, Return_text,code)) == code)) {
      errno = -1;
      return -2;			       /* Konnte nicht sauber geschrieben werden */
   }
   free(Return_text);
   Return_text = read_data(Pop3->socket, 1);
   code = check_return(Return_text);
   What->del=code;
   free(Return_text);
   return code;
}

short int check_dot(unsigned char*Text_1, unsigned char*Text_2){
   unsigned char*Text = NULL;
   int i;
   if (Text_2 == NULL)
     return 0;
   if (Text_1 == NULL) {
      Text = strdup(Text_2);
   }
   else {
      i = strlen(Text_1)+strlen(Text_2)+1;
      Text = (unsigned char*)malloc(i*(sizeof(unsigned char)));
      Text = strcpy(Text, Text_1);
      Text = strcat(Text, Text_2);
   }
   if (Text == NULL)
     i = 0;
   else {
      if (NULL == (strstr(Text, "\r\n.\r\n")))
	i = 0;
      else i= 1;
      free(Text);
   }
   return i;
}
