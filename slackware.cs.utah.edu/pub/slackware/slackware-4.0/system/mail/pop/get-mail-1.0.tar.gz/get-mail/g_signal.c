/*
 * $Log: g_signal.c,v $
 * Revision 1.2  1998/02/02 18:30:23  ral
 * *** empty log message ***
 *
 * Revision 1.1  1998/02/02 18:25:48  ral
 * Initial revision
 *
 */

#ifndef rcsid
static char rcsid[]="$Id: g_signal.c,v 1.2 1998/02/02 18:30:23 ral Exp $";
#endif

#include "g_signal.h"
#include "mail.h"
#include <pwd.h>
#include <paths.h>
#include <stdlib.h>

int install_signal_haendler()
{
   struct sigaction neuaktion, altaktion, f_neuaktion, f_altaktion;
   
   neuaktion.sa_handler = ctrl_c;
   sigemptyset(&neuaktion.sa_mask);
   neuaktion.sa_flags = 0;
   sigaction(SIGINT, &neuaktion, &altaktion);
   
   f_neuaktion.sa_handler = terminator;
   sigemptyset(&f_neuaktion.sa_mask);
   neuaktion.sa_flags = 0;
   sigaction(15, &f_neuaktion, &f_altaktion);
   
   return 1;
}

void ctrl_c (int sig)
{
   struct passwd*zgr;
   zgr = get_user_name();
   Unlock_prog(zgr->pw_name);
   fputs("Exiting on ctrl-c!\n", stderr);
   fputs("Please check for temporary files in /tmp\n", stderr);

   exit(EXIT_FAILURE);
}

void terminator(int sig)
{
   struct passwd*zgr;
   zgr = get_user_name();
   Unlock_prog(zgr->pw_name);
   fputs("Program terminate abnorm via Signal 15\n",stderr);
   fputs("Please check for temporary files in /tmp\n",stderr);

   exit(EXIT_FAILURE);
}
