#ifndef __MAIN_TCP_ALWIN
#define __MAIN_TCP_ALWIN

#define PORTNUM 110

int connect_mail(char*hostname, unsigned short portnum);
int write_data(int socket, unsigned char*buf, int n);
unsigned char* read_data(int socket, int modus);
int read_data_2(int socket, unsigned char*buf, int n);

#endif
