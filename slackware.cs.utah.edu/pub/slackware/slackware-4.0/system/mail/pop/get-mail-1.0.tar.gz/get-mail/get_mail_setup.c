/* 
 * $Log: get_mail_setup.c,v $
 * Revision 1.3  1998/02/02 18:21:32  ral
 * clean-up code, better code(?), lclint found no more errors...
 *
 * Revision 1.2  1998/01/10 10:53:55  ral
 * *** empty log message ***
 *
 * Revision 1.1  1998/01/10 10:53:05  ral
 * Initial revision
 *
 */
#include "mail.h"
#include "get_mail_setup.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

#ifndef rcsid
/*@unused@*/static char rcsid[]="$Id: get_mail_setup.c,v 1.3 1998/02/02 18:21:32 ral Exp $";
#endif

/*
 * The setup-routine
 */ 
int get_mail_setup(char*Home)
{
   int i;
   char*user;

   FILE*init_file;
   user = (char*)malloc(256*sizeof(char));
   if ( user == NULL) {
       perror("allocating memory");
       exit(EXIT_FAILURE);
   }
   if (Home == NULL) {
      fprintf(stderr,"Could not get \"Home\"-Directory....\n");
      free(user);
      return 0;
   }
   Home = strcat(Home, "/.get_mail");
   i = mkdir(Home,S_IWUSR | S_IXUSR | S_IRUSR);
   if (i == -1) {
      if (errno != EEXIST) {
	 fprintf(stderr,"Error creating ini-dir: %s\n",strerror(errno));
	 free(user);
	 return 0;
      }
   }
   Home = strcat(Home,"/initmail");
   i = umask(S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH | S_IXUSR);
   init_file = fopen(Home,"w");
   (void)umask(i);
   if (init_file == NULL) {
      fprintf(stderr, "Error creating / accessing Init-File %s\n",Home);
      fprintf(stderr,"%s\n", strerror(errno));
      free(user);
      return 0;
   }
   printf("input your user-name:\n");
   if (fgets(user,249,stdin) == NULL) {
       free(user);
       (void)fclose(init_file);
       return 0;
   }
   if (fputs("User: ",init_file) == EOF) {
       free(user);
       return 0;
   }
   if (fputs(user,init_file) == EOF) {
       free(user);
       return 0;
   }
   printf("Insert the pop3-host:\n");
   memset(user,'\0',256);
   if (fgets(user,249,stdin) == NULL) {
       free(user);
       (void)fclose(init_file);
       return 0;
   }
   if (fputs("Host: ",init_file) == EOF) {
       free(user);
       return 0;
   }
   if (fputs(user,init_file) == EOF) {
       free(user);
       return 0;
   }
   free(user);
   printf("Enter your Passwort at the pop3-host: ");
   user = strdup(getpass(""));
   if (user) {
       if (fputs("Pass: ", init_file) == EOF) {
	   free(user);
	   return 0;
       }
       if (fputs(user, init_file) == EOF) {
	   free(user);
	   return 0;
       }
       free(user);
   }
   (void)fclose(init_file);
   return 1;
}
