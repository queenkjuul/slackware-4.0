/*
 * $Log: misc.c,v $
 * Revision 1.1  1998/01/09 05:53:23  ral
 * Initial revision
 *
 */
 
#ifndef rcsid
static char rcsid[]="$Id: misc.c,v 1.1 1998/01/09 05:53:23 ral Exp $";
#endif
 
#include <unistd.h>
#include "misc.h"
#include <stdlib.h>
#include <string.h>
#include <string.h>

long int getl_quot(long int number, long int demon) {
   ldiv_t i_;
   i_ = ldiv(number, demon);
   return (i_.quot);
}
   
unsigned int get_quot(unsigned int number, unsigned int demon) {
   div_t i_;
   i_ = div(number, demon);
   return (i_.quot);
}

unsigned char*ltostr(long int number){
   unsigned int i=1;
   char*Return_text;
   int counter=1;
   if (!number) {
       Return_text = (unsigned char*)malloc(2*sizeof(unsigned char));
       if (Return_text)
	   strcpy(Return_text,"0");
       return Return_text;
   }
   while ((getl_quot(number, i))) {
      i *= 10;
      counter++;
   }
   i /= 10;
   Return_text = (unsigned char*)malloc(1+counter*sizeof(unsigned char));
   if (Return_text) {
       memset(Return_text,'\0',counter);
       sprintf(Return_text,"%li",number);
   }
   return Return_text;
}

unsigned char*itostr(unsigned int number){
   unsigned int i=1;
   char*Return_text;
   int counter=1;
   if (!number) {
       Return_text = (unsigned char*)malloc(2*sizeof(unsigned char));
       if (Return_text)
	   strcpy(Return_text,"0");
     return Return_text;
   }
   while ((get_quot(number, i))) {
      i *= 10;
      counter++;
   }
   i /= 10;
   Return_text = (unsigned char*)malloc(1+counter*sizeof(unsigned char));
   if (Return_text) {
       memset(Return_text,'\0',counter);
       sprintf(Return_text,"%u",number);
   }
   return Return_text;
}
