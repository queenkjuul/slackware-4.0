/*
 * $Id: main-tcp.c,v 0.2 1998/01/09 04:40:33 ral Exp $
 * 
 * $Log: main-tcp.c,v $
 * Revision 0.2  1998/01/09 04:40:33  ral
 * *** empty log message ***
 *
 * Revision 0.1  1996/12/04 02:21:01  ral
 * *** empty log message ***
 *
 */
#include <errno.h>       /* obligatory includes */
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netdb.h>
#include "main-tcp.h"

int connect_mail(char* hostname, unsigned short portnum) {
   struct sockaddr_in sa;
   struct hostent *hp;
   int s;
   if ((hp=gethostbyname(hostname))==NULL) {
      errno= -1;
      return(-1);
   }
#ifdef bzero   
   bzero(&sa, sizeof(sa));
#else
   memset(&sa,'\0',sizeof(sa));
#endif   
   bcopy(hp->h_addr, (char*)&sa.sin_addr,hp->h_length);
   sa.sin_family= hp->h_addrtype;
   sa.sin_port= htons((u_short)portnum);
   if ((s= socket(hp->h_addrtype,SOCK_STREAM,0)) < 0)   /* get socket */
     return(-1);
   if (connect(s,&sa,sizeof(sa)) < 0)                    /* connect */
     return(-1);
   return(s);
}

int write_data(int socket, unsigned char*buf, int zaehl) {
   int bcount;
   int br;
   bcount = 0;
   br = 0;
   while (bcount < zaehl) {
      if ((br = write(socket, &buf[bcount], zaehl-bcount)) > 0) {
	 bcount += br;
      }
      if (br < 0)
	return(-1);
      if (br == 0)
	break;
   }
   return bcount;
}

int read_data_2(int socket, unsigned char*buf, int n){
   int bcount;
   int br;
   bcount = 0;
   br = 0;
   strcpy(buf, "");
   br = read(socket, buf, n);
   buf[br]='\0';
   return br;
}

unsigned char*read_data(int socket, int mode) 
/* 
 * mode = 0: Groessere Datenmengen lesen, die mit "\r\n." beendet werden.
 * mode = 1: Daten lesen, die mit einem "\r\n" beendet werden. (USER, PASS)
 * Bei Modus 0 muss die Schleife in den einzelnen Kommandos nachgebildete 
 * werden.
 * Bei Modus 1 koennen maximal 2 kByte ausgelesen werden. Es findet keine �ber-
 * pr�fung der Datenmenge statt. (Noch nicht)
 */
{ 
   int bcount;
   unsigned char * buf2;
   int br;
   unsigned char*buf3;
   bcount = 101;
   br = 0;
   buf2 = (unsigned char*)malloc(105*sizeof(char));
   if (buf2 == NULL){
      return buf2;
   }
   if (mode) {
      if ((buf3 = (unsigned char*)malloc(2048*sizeof(unsigned char))) == NULL){
	 return buf3;
      }
      strcpy(buf3,"");
   }
   strcpy(buf2,"");
   while (bcount == 101) {
      bcount = read_data_2(socket, buf2, 101);
      if (bcount == 101) br++;
      if (bcount < 0) return NULL;
      if (mode) {
	 buf3 = strcat(buf3, buf2);
	 buf3[bcount+101*br]='\0';
      } else {
	 buf2[bcount]='\0';
	 return buf2;
      }
   }
   bcount = bcount + 101*br;
   free(buf2);
   return(buf3);
}
