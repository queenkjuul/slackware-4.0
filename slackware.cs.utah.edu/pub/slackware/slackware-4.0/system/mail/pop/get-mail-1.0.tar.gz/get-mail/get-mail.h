/*
 * $Id: get-mail.h,v 1.2 1998/02/02 17:33:51 ral Exp $
 */

#include <pwd.h>

#ifndef _MAIN_INCLUDE
#define _MAIN_INCLUDE

typedef struct Hostinfo {
   char*host;
   char*usr;
   char*pass;
} Hostinfo;

/*@null@*/Hostinfo*get_info(struct passwd*zgr);
int Lock_prog(char*user);
int Unlock_prog(char*user);
#endif
