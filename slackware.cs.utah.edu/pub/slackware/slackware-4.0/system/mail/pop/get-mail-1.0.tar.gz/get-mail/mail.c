/*
 * $Id: mail.c,v 0.2 1998/01/09 04:40:33 ral Exp $
 * 
 * $Log: mail.c,v $
 * Revision 0.2  1998/01/09 04:40:33  ral
 * *** empty log message ***
 *
 * Revision 0.1  1996/12/04 02:21:01  ral
 * *** empty log message ***
 *
 */
/*
 * this file includes various routines to handle the mails 
 * and user-informations.
 */
#include <unistd.h>
#include "mail.h"
#include "misc.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <pwd.h>

struct passwd*get_user_name(){
   uid_t user_id;
   struct passwd*zgr;
   user_id = geteuid();
   zgr = getpwuid(user_id);
   if (zgr == NULL) {
      fprintf(stderr,"%s\n",strerror(errno));
      exit(1);
   }
   return zgr;
}

int convert_to_unix(unsigned char*FileName){
   FILE*fp;
   FILE*fp_b;
   int i;
   mode_t old_umask;
   unsigned char*File_back;
   unsigned char*Buffer;
   Buffer = (unsigned char*)malloc(2*sizeof(unsigned char));
   if (Buffer == NULL)
     return 0;
   i = strlen(FileName);
   File_back = (unsigned char*)malloc((i+1)*sizeof(unsigned char));
   if (File_back == NULL)
     return 0;
   File_back = strcpy(File_back, FileName);
   if (i < 255) {
      File_back[i]='~';
      File_back[i+1]='\0';
   }
   else 
     File_back[i-1]='~';
   old_umask = umask(S_IXUSR | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH);
   fp = fopen(FileName,"r");
   if (fp == NULL)
     return -1;
   fp_b = fopen(File_back, "w+");
   if (fp_b == NULL){
      fclose(fp);
      return -2;
   }
   i = 1;
   while (!(i == EOF)){
      i = fgetc(fp);
      if ( (!(i =='\r')) && (!(i == EOF)) )
	fputc(i,fp_b);
   }
   fflush(fp_b);
   fclose(fp);
   fclose(fp_b);
   i = rename(File_back, FileName);
   if (i)
     return -3;
   umask(old_umask);
   return 1;
}

int create_mail_entry(unsigned char*Dest, unsigned char*Src,char*dummy){
   unsigned char*HeaderLine = NULL;
   unsigned char*DateLine = NULL;
   unsigned char*FromLine = NULL;
   struct tm * BTime = NULL;
   time_t * PTime;
   FILE*Dest_f;
   FILE*Src_f;
   int i, Dest_fi, retour;
   mode_t old_umask;
   if ((HeaderLine = (unsigned char*)malloc(256*sizeof(unsigned char)))==NULL){
      return -1;
   }
   if ((DateLine = (unsigned char*)malloc(256*sizeof(unsigned char)))==NULL){
      free(HeaderLine);
      return -1;
   }
   if ((FromLine = (unsigned char*)malloc(256*sizeof(unsigned char)))==NULL){
      free(HeaderLine);
      free(DateLine);
      return -1;
   }
   PTime = (time_t*)malloc(sizeof(time_t));
   HeaderLine = strcpy(HeaderLine, "From ");
   if ((gethostname(DateLine, 255)) == -1) {
      free(HeaderLine);
      free(DateLine);
      free(FromLine);
      return 0;
   }
   old_umask = umask(S_IXUSR | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH);

   Dest_fi = open(Dest, O_CREAT | O_APPEND | O_RDWR);
   if (!(Dest_fi > 0))
     return 0;
   retour = flock(Dest_fi, LOCK_EX);
   if (retour < 0) {
     close(Dest_fi);
     return 0;
   }
   Dest_f = fdopen(Dest_fi,"a+");
   if (Dest_f == NULL) {
     close(Dest_fi);
     return 0;
   }
   fprintf(Dest_f,"%s",HeaderLine);
   fprintf(Dest_f,"%s",dummy);
   fprintf(Dest_f,"%c",'@');
   fprintf(Dest_f,"%s", DateLine);
   fprintf(Dest_f,"%c", ' ');
   free(DateLine);
   time(PTime);
   BTime = localtime(PTime);
   DateLine = asctime(BTime);
   fprintf(Dest_f, "%s",DateLine);
   Src_f = fopen(Src, "r");
   if (Src_f == NULL){
      fclose(Dest_f);
      return 0;
   }
   i = 1;
   while (!(i == EOF)){
      i = fgetc(Src_f);
      if ( !(i==EOF))
	fputc(i, Dest_f);
   }
   fflush(Dest_f); 
   fclose(Src_f);
   flock(Dest_fi, LOCK_UN);
   fclose(Dest_f);
   close(Dest_fi);
   umask(old_umask);
   if ((unlink(Src))==-1)
     return -2;
   return 1;
}
