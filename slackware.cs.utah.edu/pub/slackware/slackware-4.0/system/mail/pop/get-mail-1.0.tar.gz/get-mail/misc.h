/*
 * $Id: misc.h,v 0.2 1998/01/09 04:41:08 ral Exp $
 * 
 * $Log: misc.h,v $
 * Revision 0.2  1998/01/09 04:41:08  ral
 * *** empty log message ***
 *
 * Revision 0.1  1996/12/04 02:21:27  ral
 * *** empty log message ***
 *
 */
#ifndef misch
#define misch

#ifdef __cplusplus
extern "C" {
#endif 

long int getl_quot(long int number, long int demon);
unsigned int get_quot(unsigned int number, unsigned int demon);
unsigned char*ltostr(long int number);
unsigned char*itostr(unsigned int number);

#ifdef __cplusplus
}
#endif

#endif
