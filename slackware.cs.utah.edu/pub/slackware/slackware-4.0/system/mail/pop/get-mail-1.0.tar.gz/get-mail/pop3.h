#ifndef pop3
#define pop3

#include "mail.h"

typedef struct pop3_data {
   unsigned char*UserName;
   unsigned char*PassWord;
   unsigned char*HostName;
   int User_reply;
   int Pass_reply;
   int socket;
   unsigned long int status_zahl;
   unsigned long int status_groesse;
} pop3_data;


/*********************************************************************
 * Stellt die Verbindung zum Mailserver her. Die Strings m�ssen in   *
 * korrekter Form sein.                                              *
 * *******************************************************************/
pop3_data*connect_pop3(unsigned char*host,unsigned char*user,unsigned char*pass);

/*********************************************************************
 * Sendet das "USER" - Kommando. Sollte nur von connect_pop3() an-   *
 * gewendet werden.                                                  *
 * *******************************************************************/
unsigned char*set_user(pop3_data*Pop3);

/*********************************************************************
 * Sendet das "PASS" - Kommando. sollte nur von connect_pop3() an-   *
 * gewendet werden.                                                  *
 * *******************************************************************/
unsigned char*send_pass(pop3_data*Pop3);

/*********************************************************************
 * Ermittelt die Anzahl und Gr��e der Mails in der Box. Diese Werte  *
 * werden in Pop3->status_zahl und Pop3_status_groesse abgelegt.     *
 * *******************************************************************/
int POP3_Status(pop3_data*Pop3);

/*********************************************************************
 * Beendet die Verbindung mit der Mailbox.                           *
 * *******************************************************************/
unsigned char*POP3_disconnect(pop3_data*Pop3);

/*********************************************************************
 * Setzt den Status der Mailbox zur�ck. Dabei wird laut Spezifikation*
 * als gel�scht markierte Mail wieder hergestellt.                   *
 * *******************************************************************/
int POP3_Rset(pop3_data*Pop3);

/*********************************************************************
 * Do nothing! :)                                                    *
 * *******************************************************************/
int POP3_Noop(pop3_data*Pop3);

/*********************************************************************
 * liefert eine Liste der in der Mailbox existierenden Mail zur�ck,  *
 * diese Liste wird mittels malloc() kreeirt und kann sp�ter mit     *
 * free() wieder gel�scht werden.                                    *
 * *******************************************************************/
mail_Liste*POP3_Liste(pop3_data*Pop3);

/*********************************************************************
 * Ermitteln, ob der vorhergehende befehl erfolgreich war oder nicht *
 * *******************************************************************/
int check_return(unsigned char*return_code);

/*********************************************************************
 * Ermitteln des Headers einer Mail. Achtung: Es wird der pop3-Befehl*
 *                   "Top <Number> 1"                                *
 * eingesetzt. Das sollte reichen. Allerdings kann es - je nach Ser- *
 * ver Abweichungen im Inhalt geben. (Mitunter werden mehr Zeilen an-*
 * geh�ngt)                                                          *
 * *******************************************************************/
unsigned char*POP3_Top(pop3_data*Pop3, long int Number);

/*********************************************************************
 * Diese Funktion liest eine Message vom Server, der Inhalt wird     *
 * in das File "FileName" geschrieben. Es findet keine Umwandlung von*
 * <CRLF> nach '\n' statt. Diese Funktion ist generell 8-Bit-f�hig.  *
 * Es findet kein Check auf zu lange Filenamen statt.                *
 *********************************************************************/
int POP3_getmsg(pop3_data*Pop3, long int Number, char*FileName);

/*********************************************************************
 * Diese Funktion l�scht die Message aus dem angegebenen Listen-     *
 * eintrage "What". Dann wird das Del_flag in diesem Eintrage ge-    *
 * setzt.                                                            *
 *********************************************************************/
int POP3_delmsg(pop3_data*Pop3, mail_Liste*What);

/********************************************************************* 
 * Diese Funktion kontrolliert auf die <CRLF>.<CRLF> - Sequenz       *
 * Erster Fall:                                                      *
 * Text_1: die letzten 5 Zeichen der vorhergehenden Sequenz          *
 * Text_2: die ersten (max) 5 Zeichen der gerade gelesenen Seuquenz  *
 * Zweiter Fall:                                                     *
 * Text_1: Null                                                      *
 * Text_2: die gerade gelesene Sequenz                               *
 * Diese Funktion wird eigentlich nur von getmsg ben�tigt, da hier   *
 * hier nicht der komplette R�ckgabewert behandelt werden kann.      *
 *********************************************************************/

short int check_dot(unsigned char*Text_1, unsigned char*Text_2);

#endif
