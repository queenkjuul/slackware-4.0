/*
 *
 * The main file for the program
 *
 * $Log: get-mail.c,v $
 * Revision 1.7  1998/02/02 18:52:49  ral
 * *** empty log message ***
 *
 * Revision 1.6  1998/02/02 18:22:17  ral
 * clean code with lclint for better performance, removed some errors
 *
 * Revision 1.5  1998/02/02 00:13:47  ral
 * ouch! I had a very ugly bug in the main-routine
 *
 * Revision 1.4  1998/02/01 19:16:12  ral
 * re-made routine to read setup file
 *
 * Revision 1.3  1998/01/09 06:02:53  ral
 * *** empty log message ***
 *
 * Revision 1.2  1998/01/09 06:02:29  ral
 * *** empty log message ***
 *
 * Revision 1.1  1998/01/09 05:49:11  ral
 * Initial revision
 *
 */

#ifndef rcsid
/*@unused@*/static char rcsid[]="$Id: get-mail.c,v 1.7 1998/02/02 18:52:49 ral Exp $";
#endif

#include "main-tcp.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <netdb.h>
#include <dirent.h>
#include <pwd.h>
#include <errno.h>
#include "mail.h"
#include "misc.h"
#include "pop3.h"
#include "get-mail.h"
#include "get_mail_setup.h"
#include "g_signal.h"
#include <paths.h>
#include <ctype.h>
#include <getopt.h>
#include <linux/limits.h>

/* 
 * The program should only run once at a time for a user.
 * thats why I lock it...
 */
int Lock_prog (char*user)
{
    char*Komplett;
    int lockfile;
    Komplett = (char*)malloc(255*sizeof(char));
    if (!Komplett)
	return 0;
    Komplett = strcpy(Komplett,_PATH_TMP);
    Komplett = strcat(Komplett, user);
    Komplett = strcat(Komplett, ".get-mail.lock");
    lockfile = open(Komplett,O_CREAT | O_EXCL | O_RDWR);
    if (lockfile == -1) {
	free(Komplett);
	return -1;
    }
    if (close(lockfile) == -1)
	perror("Error closing file");
    if (chmod(Komplett, S_IRUSR | S_IWUSR) == -1)
	perror("Error changing mode");
    free(Komplett);
    return 1;
}

/*
 * After a downloading and putting the mail
 * we can unlock it.
 */
int Unlock_prog (char*user)
{
    char*Komplett;
    Komplett = (char*)malloc(255*sizeof(char));
    if (!Komplett)
	return 0;
    Komplett = strcpy(Komplett,_PATH_TMP);
    Komplett = strcat(Komplett, user);
    Komplett = strcat(Komplett, ".get-mail.lock");
    if (unlink(Komplett) < 0) {
	free(Komplett);
	return -1;
    }
    free(Komplett);
    return 1;
}

/*
 * Getting the Infos about login etc.
 * and reading the ini-file
 */
Hostinfo*get_info(struct passwd*zgr){
    Hostinfo*Infos;
    FILE*ini_file;
    char*Home;
    char*dummy;
    int i,j,k;
    int runfile;
    char*Kompletter_Pfad;
    Infos = (Hostinfo*)malloc(sizeof(Hostinfo));
    if (Infos == NULL)
	return NULL;
    Infos->usr = NULL;
    Infos->pass = NULL;
    Infos->host = NULL;
    if (zgr==NULL) {
	fprintf(stderr,"could not get user-infos!\n");
	exit(EXIT_FAILURE);
    }
    Home = strdup(zgr->pw_dir);
    if (Home == NULL) {
	free(Infos);
	fprintf(stderr,"Could not get Home-Dir!\n");
	(void)Unlock_prog(zgr->pw_name);
	exit(EXIT_FAILURE);
    }
    Kompletter_Pfad = (char*)malloc(256*sizeof(char));
    if (Kompletter_Pfad == NULL) {
	perror("Allocating memory");
	if (Unlock_prog(zgr->pw_name) == -1) 
	    perror("unlocking");
	exit(EXIT_FAILURE);
    }
    Kompletter_Pfad=strcpy(Kompletter_Pfad,Home);
    Kompletter_Pfad=strcat(Kompletter_Pfad,"/.get_mail/initmail");
    dummy = (char*)malloc(256*sizeof(char));
    if (dummy == NULL) {
	fprintf(stderr, "Error allocating memory!\n");
	if (Unlock_prog(zgr->pw_name) == -1)
	    perror("unlocking");
	exit(EXIT_FAILURE);
    }
    dummy = strcpy(dummy, Home);
    dummy = strcat(dummy,"/.get_mail/last_start");
    (void)unlink(dummy);
    runfile = creat(dummy, S_IRUSR|S_IWUSR);
    if (runfile > 0)
	(void)close(runfile);
    free(Home);
    free(dummy);
    ini_file = fopen(Kompletter_Pfad,"r");
    free(Kompletter_Pfad);
    if (ini_file == NULL) {
	i = errno;
	if (i == ENOENT) {
	    free(Infos);
	    fprintf(stderr,"Please run first setup with option \"-s\"!\n");
	    (void)Unlock_prog(zgr->pw_name);
	    exit(EXIT_FAILURE);
	}
	else if (i == ENOMEM) {
	    perror("While getting user-infos");
	    (void)Unlock_prog(zgr->pw_name);
	    exit(EXIT_FAILURE);
	}
	else {
	    free(Infos);
	    fprintf(stderr,"Please run first setup with option \"-s\"!\n");
	    (void)Unlock_prog(zgr->pw_name);
	    exit(EXIT_FAILURE);
	}
    }
    Home = (char*)malloc(256*sizeof(char));
    if (!Home) {
	perror("allocating memory");
	free(Infos);
	if (Unlock_prog(zgr->pw_name) == -1)
	    perror("unlocking");
	exit(EXIT_FAILURE);
    }
    while (fgets(Home,255,ini_file)) {
	j = 0; k= 0;
	dummy = strtok(Home,": ");
	j = (int)strlen(Home);
	for (k=0; k<j; k++) {
	    Home[k]=toupper(Home[k]);
	}
	dummy = strtok(NULL,": \n");
	if (dummy && !(strstr(Home,"#")) && !(strstr(Home,";"))) {
	    if (strstr(Home,"HOST")) {
		Infos->host = strdup(dummy);
	    }
	    else if (strstr(Home, "USER")) {
		Infos->usr = strdup(dummy);
	    }
	    else if (strstr(Home, "PASS")) {
		Infos->pass = strdup(dummy);
	    }
	}
    }
    free(Home);
    if (fclose(ini_file) != 0)
	perror("closing ini-file");
    if ( (!(Infos->pass)) || (!(Infos->host)) || (!(Infos->usr)) ) {
	free(Infos);
	Infos = NULL;
    }
    return Infos;
}

/*
 * The main routine
 * very long, to long?
 * Next versions i'll split into more parts.
 */
int main(int argc, char*argv[]) {
    Hostinfo * Infos;
    pop3_data*Mail;
    unsigned char*buffer;
    unsigned char*mailfile;
    struct passwd*zgr;
    int QUIET;
    int NODEL;
    int Log;
    int c;
    mail_Liste * Liste;
    mail_Liste * dummy_Liste;
    int i;
    int EXITCODE = 0;		       /* Got I new mail? */
    QUIET = 0;
    NODEL = 0;
    zgr=get_user_name(1);
    if (Lock_prog(zgr->pw_name) < 0) {
	if (errno==EEXIST) {
	    printf("I think, the programs already runs, if not,\n");
	    printf("remove the file %s%s.get-mail.locked.\n",_PATH_TMP,zgr->pw_name);
	    printf("May be, that there were any errors and I could not remove\n");
	    printf("the lock-file. But-- remove it only, you're sure, there's no\n");
	    printf("other session running....\n");
	    exit(EXIT_FAILURE);
	}
	else {
	    perror("An error during locking the program");
	}
    }
    (void)install_signal_haendler();
    Log = 1;
    while ((c = getopt (argc, argv, "qdshvl?")) != -1) {
	switch(c){
	case 'q':
	    QUIET=1;
	    break;
	case 's':
	    QUIET = get_mail_setup(zgr->pw_dir);
	    (void)Unlock_prog(zgr->pw_name);
	    if (QUIET == 0)
		exit(EXIT_FAILURE);
	    exit(EXIT_SUCCESS);
	case 'd':
	    NODEL=1;
	    break;
	case 'l':
	    Log=0;
	    break;
	case 'v':
	case 'h':
	case '?':
	default:
	    fprintf(stderr,"get-mail Version 1.0\n");
	    fprintf(stderr,"Usage: get-mail <-sqhd>\n");
	    fprintf(stderr,"-h: Get this Info\n");
	    fprintf(stderr,"-s: running setup\n");
	    fprintf(stderr,"-q: QUIET-Mode, do not print run-infos\n");
	    fprintf(stderr,"-d: Do not delete received messages on Server\n");
	    (void)Unlock_prog(zgr->pw_name);
	    exit(EXIT_FAILURE);
	}
    }
    Infos = get_info(zgr);
    if(!(Infos)) {
	fprintf(stderr, "Error getting user - infos!");
	(void)Unlock_prog(zgr->pw_name);
	exit(EXIT_FAILURE);
    }
    if (!(QUIET)) {
	printf("connecting to server %s\n",Infos->host);
    }
    Mail = connect_pop3(Infos->host,Infos->usr,Infos->pass);
    if (!(Mail->socket > 0)) {
	if (errno == -1){
	    herror("Error open connection");
	}
	else {
	    perror("Error open connection");
	}
	(void)Unlock_prog(zgr->pw_name);
	exit(EXIT_FAILURE);
    }
    if (!(Mail->User_reply)) {
	fprintf(stderr, "Error: Username not accepted\n");
	write_data(Mail->socket, "QUIT\r\n",6);
	close(Mail->socket);
	(void)Unlock_prog(zgr->pw_name);
	exit(EXIT_FAILURE);
    }
    if (!(Mail->Pass_reply)) {
	fprintf(stderr, "Error: Bad login (Not correct Password?)\n");
	write_data(Mail->socket,"QUIT\r\n",6);
	close(Mail->socket);
	(void)Unlock_prog(zgr->pw_name);
	exit(EXIT_FAILURE);
    }
    POP3_Status(Mail);
    if (Mail->status_zahl > 0) {
	EXITCODE = 2; 		       /* You got new mail */
	Liste = POP3_Liste(Mail);
	buffer =(unsigned char*)malloc((PATH_MAX+NAME_MAX)*sizeof(char));
	if (buffer== NULL) {
	    perror("allocating memory");
	    buffer = POP3_disconnect(Mail);
	    if (buffer)
		free(buffer);
	    (void)Unlock_prog(zgr->pw_name);
	    exit(EXIT_FAILURE);
	}
	mailfile = (unsigned char*)malloc((PATH_MAX+NAME_MAX)*sizeof(char));
	if (mailfile == NULL) {
	    perror("Allocating memory");
	    (void)Unlock_prog(zgr->pw_name);
	    exit(EXIT_FAILURE);
	}
	strcpy(mailfile, _PATH_MAILDIR);
	mailfile = strcat(mailfile,"/");
	mailfile = strcat(mailfile, zgr->pw_name);
	buffer = tmpnam(NULL);
	if (!(Liste == NULL)) {
	    dummy_Liste = Liste;
	    while (!(dummy_Liste == NULL)){
		if (QUIET==0) {
		    printf("getting mail No %lu (%lu bytes) ",dummy_Liste->Number, dummy_Liste->Bytes);
		    fflush(stdout);	       /* print the info about current download BEFORE load */
		}
		errno = 0;
		i = POP3_getmsg(Mail, dummy_Liste->Number, buffer);
		if (!(i==1)) {
		    if (!(errno == 0)) {
			perror("\nError getting Mail: ");
		    }
		    else {
			if (errno == -1)
			    herror("\nError getting Mail: ");
			else {
			    if (i == -5) {
				fprintf(stderr,"\n The server didn't accept your read-request!\n");
			    }
			    else
				fprintf(stderr,"\n Error getting Mail and I don't know why!\n");
			}
		    }
		    buffer = POP3_disconnect(Mail);
		    if (buffer)
			free(buffer);
		    Unlock_prog(zgr->pw_name);
		    exit(EXIT_FAILURE);
		}
		i = convert_to_unix(buffer);
		if (i < 1) {
		    perror("Error converting mail!");
		    Unlock_prog(zgr->pw_name);
		    exit(EXIT_FAILURE);
		}
		if (!( (create_mail_entry(mailfile, buffer,zgr->pw_name)) == 1)) {
		    perror("Error creating mailentry");
		    buffer = POP3_disconnect(Mail);
		    if (buffer)
			free(buffer);
		    Unlock_prog(zgr->pw_name);
		    exit(EXIT_FAILURE);
		}
		if (QUIET == 0) 
		    printf("- done");
		if (!NODEL) {
		    if(QUIET==0) 
			printf(" - delete on host");
		    errno = 0;
		    h_errno = 0;
		    if (POP3_delmsg(Mail, dummy_Liste) < 0) {
			if (errno > 0) {
			    perror("\nError deleting mail on host: ");
			}
			else if (h_errno > 0) {
			    herror("\nError deleting mail on host: ");
			}
			else
			    fprintf(stderr,"\Error deleting mail on host and I don't know why\n");
			buffer = POP3_disconnect(Mail);
			if (buffer)
			    free(buffer);
			Unlock_prog(zgr->pw_name);
			exit(EXIT_FAILURE);
		    }
		}
		if (QUIET == 0)
		    printf("\n");
		dummy_Liste = dummy_Liste->Next;
		free(Liste);
		Liste = dummy_Liste;
	    }
	}
	free(mailfile);
    }
    buffer = POP3_disconnect(Mail);
    if (buffer)
	free(buffer);
    if (Infos)
	free(Infos);
    free(Mail);
    Unlock_prog(zgr->pw_name);
    return EXITCODE;
}
