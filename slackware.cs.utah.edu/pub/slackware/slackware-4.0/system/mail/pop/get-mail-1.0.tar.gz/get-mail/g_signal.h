/*
 * $Id: g_signal.h,v 1.1 1998/02/02 18:36:02 ral Exp $
 */

#include <stdio.h>
#include <signal.h>
#include "get-mail.h"

#ifndef _G_SIGNAL
#define _G_SIGNAL

int install_signal_haendler();
void ctrl_c(int sig);
void terminator(int sig);

#endif
