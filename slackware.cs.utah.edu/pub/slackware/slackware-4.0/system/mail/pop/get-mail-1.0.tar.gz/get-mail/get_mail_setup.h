/*
 * $Id: get_mail_setup.h,v 1.1 1998/01/10 10:53:05 ral Exp $
 */

#ifndef _GET_MAIL_SETUP
#define _GET_MAIL_SETUP

int get_mail_setup(char*Home);

#endif
