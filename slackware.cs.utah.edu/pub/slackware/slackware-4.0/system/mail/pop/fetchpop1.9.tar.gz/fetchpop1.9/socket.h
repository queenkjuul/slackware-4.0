/*
 * $Id: socket.h,v 1.9 1996/06/26 01:27:31 oh Exp $
 *
 *    Copyright (C) 1996	seung-hong oh
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; version 2 of the License.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define SOCK_ERROR -1
#define SOCK_NOEXIST	-2
#define SOCK_NORESPOND -3 

int get_connect(char* serv_name, unsigned short  port_num);
int writesock( int sockfd, char* buff, int bufflen );
int readsock( int sockfd, char* buff, int bufflen);
int writeln(int sockfd, char* buf);
int sockprintf(int sockfd, char* format, ...);
int sockgetline(int sockfd, char* buff, int bufflen);
