void lowerstr(char *);
void trimstr(char *);
char *md5hash(char *);
void fgetline(FILE *, char *, int);
char *environvar(char *);
