char isIP(char *, char *);
char *emailaddr(char *);
void splitheader(char *, char *, char **);
int isspam(char *, char *, struct friendrec *, struct torec *,
           struct spamrec *, struct subjrec *, struct extrarec *,
	   char forged, char paranoid, char tomode);
