/*
    popspam version 0.95 - POP3 mail client with integrated spam filtering.
    Copyright (C) 1998 James DeRidder
    
    Please see the file "COPYING" included with this distribution for
    license information.
    
*/

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "md5.h"

  void lowerstr(char *str)      /* makes string all lowercase */

    {

      if(strlen(str)>0)
        while(*str!='\0')
          *str=(char)tolower((int)*str++);

    }


  void trimstr(char *str)  /* trims off preceding and trailing white spaces */
                           /* and replaces any TABs with spaces */
    {

      char *tmpstrp;

      if(strlen(str)>0)
        {
          tmpstrp=str;
          while(*tmpstrp != '\0')
            {
              if(*tmpstrp=='\x9')
                { 
                  *tmpstrp=' ';
                }
              tmpstrp++;
            }

          while(*str==' ') 
            strcpy(str,str+1);
          while(*(str+strlen(str)-1)==' ')
            *(str+strlen(str)-1)='\0';
        }

    } 
      

  char *md5hash(char *str)
    {
      char i,o;
      char hexchar[] = "0123456789abcdef";
      unsigned char digest[16];
      static char hash[33] = "";
      
      md5_buffer(str,strlen(str),digest);
      
      for(i=0, o=0; i<16; i++)
        {
          hash[o++]=hexchar[digest[i]>>4];
	  hash[o++]=hexchar[digest[i]&15];
	}  
      
      return(hash);
    }
      
      
  void fgetline(FILE *fl, char *str, int sz)

  /* returns a line of text into 'str' from file 'fl' up to 'sz' chars
     or a newline or carriage return is encountered (which get stripped) */

    {

      char *ch;

      if(fgets(str,sz+1,fl)!=NULL)
        {
          ch=&str[strlen(str)-1];
          while( (*ch=='\r') || (*ch=='\n') )
            {
              *ch='\0';
              ch--;
            }
        }
      else
        {
          strcpy(str,"");
        }

    }


  char *environvar(char *var) 

  /* returns contents of environmental variable named 'var' */

    {

      static char tmpstr[201];
      char tvar[81];
      char **startenvir;
      int lenvar;
      
      startenvir=environ;

      strcpy(tmpstr,"");
      strcpy(tvar,var);
      strcat(tvar,"=");
      lenvar=strlen(tvar);

      while(*environ != NULL)
        {
          if (!strncmp(*environ,tvar,lenvar))
            {
              strcpy(tmpstr,*environ+lenvar);
              break;
            }
          *environ++;
        }

      environ=startenvir; 

      return tmpstr;

    }
