#define NO    0
#define YES   1

struct torec
  {
    struct torec *last, *next;
    char toaddr[36];
  };
  
struct friendrec
  {
    struct friendrec *last, *next;
    char myfriend[36];
  };
    
struct spamrec
  {
    struct spamrec *last, *next;
    char spammer[36];
   };

struct subjrec
  {
    struct subjrec *last, *next;
    char subjstr[41];
  };

struct extrarec
  {
    struct extrarec *last, *next;
    char extra[81];
  };

struct maildatarec
        {
          char system_user[9];
          char user[101]; 
          char pass[65] ;
	  char pophost[129]; 
	  char mailbox[201];
	  char apop;
	  char forged;
	  char notifybycomsat;
	  char safemode;
	  char verbosemode;
          char paranoid;
	  char tomode;
        };
