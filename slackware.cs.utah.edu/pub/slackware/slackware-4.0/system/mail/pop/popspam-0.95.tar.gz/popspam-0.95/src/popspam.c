/*
    popspam version 0.95 - POP3 mail client with integrated spam filtering.
    Copyright (C) 1998 James DeRidder

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pwd.h>
#include <bsd/signal.h>
#include <string.h>
#include "popspam.h"
#include "email.h"
#include "daemon.h"
#include "misc.h"
#include "pop3.h"
#include "sockets.h"

struct torec     *to;
struct friendrec *friend;
struct spamrec   *spam;
struct subjrec   *subject;
struct extrarec  *extras;


void getuserinfo(char *, char *);
void processparams(int, char **, char, char *, pid_t, char *, int *);
int  readconfigfile(char *, char *, char *, char *, struct maildatarec *);
int  readspammers(char *, char, char);
void (*callretrievemail)();



  
char popidentity[26];
char daemonmode;
int  counter;
char logstate=0;
char logfilename[201];
char lockfilename[201];


  void getuserinfo(char *system_user, char *user_home)

    /* get user login name and home directory */

    {

      struct passwd *pwinfo;


      if((pwinfo=getpwuid(getuid()))!=NULL)
        {
          /* copy user login name to 'system_user' */
	  memcpy(system_user,"\0\0\0\0\0\0\0\0\0",9);
          strncpy(system_user,pwinfo->pw_name,8);
          /* get user home dir. */
          strcpy(user_home,pwinfo->pw_dir);
        }
      else
        /* user login name could not be found! this shouldn't happen */
        {
          /* USER environmental var value instead */
          strcpy(system_user,environvar("USER"));
          /* HOME environmental var for user home dir. */
          strcpy(user_home,environvar("HOME"));
        }

    }


  void processparams(int numargs, char **arg, char bgmode, char *dmode, pid_t dpid, char *vrbsmode, int *cntr)

    /* processes parameters passed on command line */

    { 
    
      char tmpstr[201];


      if (numargs>1)  /* if user provided any parms */
        {
          strcpy(tmpstr,arg[1]);
          trimstr(tmpstr);
          if(!strcmp(tmpstr,"-k"))  /* -k  to kill popspam daemon */
            {
              if (bgmode)  /* there must be a daemon running to kill */
                {
                  printf("Killing popspam with PID %ld.\n",dpid);
                  kill(dpid,SIGTERM);
                  exit(0);
                }
              else   /* kill what? */
              {       
                printf("popspam is not running in the background - Cannot kill.\n");
                exit(7);
              }
            }
          else
            if(!strcmp(tmpstr,"-w"))  /* -w  to 'wake up' daemon  */
              {
                if (bgmode)
                  {
                    printf("Waking up popspam at PID %ld.\n",dpid);
                    kill(dpid,SIGALRM);
                    exit(0);
                  }
                else  /* nothing to wake up */
                  {
                    printf("popspam is not running in the background - Cannot wake up.\n");
                    exit(8);
                  }
              }
          else
            if(*dmode=!strcmp(tmpstr,"-d"))  /* user wants daemon mode */
              {
                if(bgmode)  /* daemon already running */
                  {
                    printf("popspam is already running - Cannot start another daemon\n");
                    exit(9);
                  }
                if (numargs==2)  /* no time interval specified for daemon */
                  *cntr=10*60;   /* default is 10 minutes (600 seconds) */ 
                else
                  {
                    *cntr=atoi(arg[2]); /* read specified time */
                    if(*cntr<5 || *cntr>180)
                      {
                        printf("Invalid time value specified for daemon mode.\n");
                        exit(10);
                      }
                    else
                      *cntr*=60; /* convert time to seconds */
                  }
              }
          else
            /* -v  verbose mode, -vv even more verbose 
               verbose mode only valid when running in the foreground */

            if(!(*vrbsmode=( (!strcmp(tmpstr,"-v") + ((!strcmp(tmpstr,"-vv")) * 2)) * !bgmode )))
              {
                /* bogus parms or bad usage */
                printf("Invalid parameter specified.\n");
                if(bgmode)
                  {
                   /* daemon is running, here's what user can do */
                    printf("popspam is already running in the background.\n\n");
                    printf("popspam -k  to kill current background process\n");
                    printf("popspam -w  to wake current background process\n\n");
                    exit(11);
                  }
                else
                  {
                    /* here are the valid parms to start the program */
                    printf("popspam  without parameters runs program in foreground\n");
                    printf("         -v  starts program in foreground in verbose mode\n"); 
                    printf("         -d [n]  starts program in daemon mode\n");
                    printf("         where \"n\" is an optional time between 1 and 180 MINUTES.\n");
                    exit(11);
                  }
              }
           
        }
      else
        /* no parameters specified on command line */
        if(bgmode)
          {
            /* but the program is already running as a daemon, 
               so  -k  or  -w  parm must be provided */
            printf("popspam is already running in the background.\n\n");
            printf("popspam -k  to kill current background process\n");
            printf("popspam -w  to wake current background process\n\n");
            exit(11);
          }

    }


  int readconfigfile(char *user_home, char *datapath, char *logstate,
		     char *logfilename, struct maildatarec *md)

  /* read and process the configuration file '~/.popspam' */

    {

      FILE *file;
      int tmpfd;
      struct stat buf;
      char filename[201];
      char tmpstr[163];
      char tmpstr1[163];
      char *scan;

      strcpy(filename,user_home);
      strcat(filename,"/.popspam");

      if (stat(filename,&buf) == -1) 
       /* if file does not exist, return error */
        return -1;

      if( !((buf.st_mode == (S_IFREG|S_IRUSR|S_IWUSR)) || (buf.st_mode == (S_IFREG|S_IRUSR))) )
      /* file must be read/write, read accessible by user only */ 
        {
          /* if not, return error */
          return -2;
        }
 
      if((file=fopen(filename,"r"))==NULL)
      /* error opening file, return error */ 
        return -1;

      while (!feof(file))
        {
          fgetline(file,tmpstr,162);
          trimstr(tmpstr);
          strcpy(tmpstr1,tmpstr);
          lowerstr(tmpstr1);
          
          if (tmpstr[0]=='#')  /* if file line begins with '#' symbol */
            continue;   /* skip as comment */
                    
          if (!strncmp(tmpstr1,"user ",5))  /* get user name */
            {
              if ( (scan=strrchr(tmpstr,' ')) != NULL )
                strcpy(md->user,scan+1);
              continue;
            }

          if (!strncmp(tmpstr1,"pass ",5))  /* get password */
            {
              if ( (scan=strrchr(tmpstr,' ')) != NULL )
                strcpy(md->pass,scan+1);
              continue;
            }
      
          if (!strncmp(tmpstr1,"host ",5))  /* get pop3 address */
            {
              if ( (scan=strrchr(tmpstr,' ')) != NULL )
                strcpy(md->pophost,scan+1);
              continue;
            }

          if (!strncmp(tmpstr1,"datapath ",9))
          /* user wants an alternate path for data files */
            {
              if ( (scan=strrchr(tmpstr,' ')) != NULL )
                {
                  strcpy(datapath,scan+1);
                  if(datapath[strlen(datapath)-1] == '/')
                    datapath[strlen(datapath)-1]='\0';
                  if (stat(datapath,&buf) == -1)   /* if datapath bad */
                    return -3;
                  strcat(datapath,"/"); 
                }
              continue;
            }

          if (!strncmp(tmpstr1,"log ",4))
          /* what kind of logging does the user want? */
            {
              if ( (scan=strrchr(tmpstr1,' ')) != NULL )
                {
                  if (!strcmp(scan+1,"no"))
                    *logstate=LOGNO;   /* no logging */
                  else
                  if (!strcmp(scan+1,"system"))  /* system logging */ 
                    *logstate=LOGSY;
                  else
                    {
                      /* log to user specified file */
                      scan=strrchr(tmpstr,' ');
                      strcpy(logfilename,scan+1);
                      if( (tmpfd=open(logfilename,O_RDWR|O_APPEND|O_CREAT)) != -1 )
                      /* open/create file and set permissions to read/write
                         access for the user only, if file is created */
                        {
                          *logstate=LOGFI;
                         /* keep file accessible by the user only */
                          fchmod(tmpfd,S_IRUSR|S_IWUSR);
                          close(tmpfd);
                        }
                      else /* error opening/creating log file */
                        {
                          fclose(file); 
                          return -4;
                        }
                    }
                }
              continue;
            }

          if (!strncmp(tmpstr1,"mailbox ",8))
          /* user wants to use an alternative mailbox */
            {
              if ( (scan=strrchr(tmpstr,' ')) != NULL )
                {
                  strcpy(md->mailbox,scan+1);
                  if( (tmpfd=open(md->mailbox,O_RDWR|O_APPEND|O_CREAT)) != -1 )
                  /* open/create file, set permissions for user only */
                    {
                      fchmod(tmpfd,S_IRUSR|S_IWUSR); 
                      close(tmpfd);
                    }
                  else /* error opening/creating mailbox file */
                    {
                      fclose(file);
                      return -5;
                    }
                }
              continue;
            }


          if (!strncmp(tmpstr1,"comsat ",7))
          /* does user want comsat mail notification? */
            {
              if ( (scan=strrchr(tmpstr1,' ')) != NULL )
                {
                  if (!strcmp(scan+1,"yes"))
                    md->notifybycomsat=YES;
                }
              continue;
            }


          if (!strncmp(tmpstr1,"safe ",5))
          /* safe mode - don't delete spam from mail server */
            {
              if ( (scan=strrchr(tmpstr1,' ')) != NULL )
                {
                  if (!strcmp(scan+1,"yes"))
                    md->safemode=YES;
                }
            }


          if (!strncmp(tmpstr1,"apop ",5))
          /* paranoid mode - don't accept mail from strangers! */
            {
              if ( (scan=strrchr(tmpstr1,' ')) != NULL )
                {
                  if (!strcmp(scan+1,"yes"))
                    md->apop=YES;
                }
            }
	    
	    
          if (!strncmp(tmpstr1,"forgedcheck ",9))
          /* paranoid mode - don't accept mail from strangers! */
            {
              if ( (scan=strrchr(tmpstr1,' ')) != NULL )
                {
                  if (!strcmp(scan+1,"yes"))
                    md->forged=YES;
                }
            }
	    
	    
          if (!strncmp(tmpstr1,"paranoid ",9))
          /* paranoid mode - don't accept mail from strangers! */
            {
              if ( (scan=strrchr(tmpstr1,' ')) != NULL )
                {
                  if (!strcmp(scan+1,"yes"))
                    md->paranoid=YES;
                }
            }


          if (!strncmp(tmpstr1,"to-mode ",8))
          /* message must have a valid 'To: ' line */
            {
              if ( (scan=strrchr(tmpstr1,' ')) != NULL )
                {
                  if (!strcmp(scan+1,"1"))
                    md->tomode=1;
		  else
		    if (!strcmp(scan+1,"2"))
                      md->tomode=2;
                }
            }


        }

      fclose(file);

      if (strlen(md->user)==0)  /* user, pass, host are required */
        return -6;          /* return error if any are missing */
      if (strlen(md->pass)==0)
        return -6;
      if (strlen(md->pophost)==0)
        return -6;
     
      if (strlen(md->mailbox)==0)
      /* user didn't provide name of mailbox file, so use system default */
        {
          strcpy(md->mailbox,MAILDIR);
          strcat(md->mailbox,"/");
          strcat(md->mailbox,md->system_user);
        }
      else
        md->notifybycomsat=NO;
 
      if (strlen(datapath)==0)
      /* no data path provided, so use user's home directory */
        {
          strcpy(datapath,user_home);
          strcat(datapath,"/");
        }

      if(md->paranoid)
        md->tomode=NO;
	
      return 0;  /* no errors occured and all required parms provided */


    }     


  int readspammers(char *datapath, char paranoid, char tomode)
  
  /* read files providing listings of spammers, friends, spam subjects,
     and extra headers.   spammers list is required */

    {

      int  cnt=0;
      FILE *file;
      char complete, skip;
      char filename[201];
      char tmpstr[81];
      void *first, *old;


      if(!paranoid)
        {
	
          strcpy(filename,datapath);
          strcat(filename,"spammers.popspam");
     
          /* skip if 'spammers' file doesn't exist */ 
          skip=((file=fopen(filename,"r")) == NULL); 

          while( (!skip) && (!feof(file)) )
            {

              fgetline(file,tmpstr,80);

              if(strlen(tmpstr)>0)  /* if not a blank line */
                {
                  lowerstr(tmpstr);
                  trimstr(tmpstr);
 
                  if((cnt++)==0)
                    {
                      spam=malloc(sizeof(struct spamrec));
                      first=spam;
                      spam->last=NULL;
                    }  
                  else
                    {
                      spam->next=malloc(sizeof(struct spamrec));
                      old=spam;
                      spam=spam->next;
                      spam->last=old;
                    }

                  if(isIP(tmpstr,&complete))
                   /* if spammer is IP address */
                    { 

                  /* enclose complete IP address in brackets[],
                     partial IP addresses only begin with an open bracket[
                     this simplifies scanning for IPs in message headers */
 
                      strcpy(spam->spammer,"[");
                      if(complete)
                        strcat(tmpstr,"]");
                      else
                        if(tmpstr[strlen(tmpstr)-1]=='*')
                          tmpstr[strlen(tmpstr)-1]='\0';
                    }
      
                  strncat(spam->spammer,tmpstr,35);

                }  /* if(strlen */

            }  /* while */

          fclose(file);

          if (!skip)
            {
              spam->next=NULL;
              spam=first;
            }

          if(cnt==0)  /* if no spammers where available */
            return -1;  /* then don't waste any more time, exit */
	
          cnt=0;
	  
        }  /* if !paranoid */

      strcpy(filename,datapath);
      strcat(filename,"friends.popspam");

      skip=((file=fopen(filename,"r")) == NULL);
      
      if((paranoid) && (skip))
        return -2;
	
      while( (!skip) && (!feof(file)) )
        {

          fgetline(file,tmpstr,80); 
 
          if(strlen(tmpstr)>0)
            {
              lowerstr(tmpstr);
              trimstr(tmpstr);

              if((cnt++)==0)
                {
                  friend=malloc(sizeof(struct friendrec));
                  first=friend;
                  friend->last=NULL;
                }
              else
                {
                  friend->next=malloc(sizeof(struct friendrec));
                  old=friend;
                  friend=friend->next;
                  friend->last=old;
                }
              strncpy(friend->myfriend,tmpstr,35);

            }  /* if(strlen  */

        }  /* while */ 

      fclose(file);
 
      if(!skip)
        {
          friend->next=NULL;
          friend=first;
        }

      if(paranoid)
        return 0;  /* we're done, since only friends list is needed */
	
      cnt=0;
      

      if(tomode>1)
        {
          strcpy(filename,datapath);
          strcat(filename,"to.popspam");

          skip=((file=fopen(filename,"r")) == NULL);
	  
	  if(skip)
	    return -3;

          while(!feof(file))
            {

              fgetline(file,tmpstr,80); 
 
              if(strlen(tmpstr)>0)
                {
                  lowerstr(tmpstr);
                  trimstr(tmpstr);

                  if((cnt++)==0)
                    {
                      to=malloc(sizeof(struct torec));
                      first=to;
                      to->last=NULL;
                    }
                  else
                    {
                      to->next=malloc(sizeof(struct torec));
                      old=to;
                      to=to->next;
                      to->last=old;
                    }
                  strncpy(to->toaddr,tmpstr,35);

                }  /* if(strlen  */

            }  /* while */ 

          fclose(file);
 
          to->next=NULL;
          to=first;

        }  /* if tomode */

      cnt=0;

      strcpy(filename,datapath);
      strcat(filename,"subjects.popspam");
 
      skip=((file=fopen(filename,"r")) == NULL);

      while( (!skip) && (!feof(file)) )
        {

          fgetline(file,tmpstr,80); 

          if(strlen(tmpstr)>0)
            {
              lowerstr(tmpstr);

              if((cnt++)==0)
                {
                  subject=malloc(sizeof(struct subjrec));
                  first=subject;
                  subject->last=NULL;
                }
              else
                {
                  subject->next=malloc(sizeof(struct subjrec));
                  old=subject;
                  subject=subject->next;
                  subject->last=old;
                }
              strncpy(subject->subjstr,tmpstr,40);

            }  /* if(strlen  */

        }  /* while */

      fclose(file);
  
      if(!skip)
        {
           subject->next=NULL;
           subject=first;
         }
 
      cnt=0;
     
      strcpy(filename,datapath);
      strcat(filename,"extra.popspam");
      skip=((file=fopen(filename,"r")) == NULL); 

      while( (!skip) && (!feof(file)) )
        {

          fgetline(file,tmpstr,80);

          if(strlen(tmpstr)>0)  /* if not a blank line */
            {
              lowerstr(tmpstr);
               
              if((cnt++)==0)
                {
                  extras=malloc(sizeof(struct extrarec));
                  first=extras;
                  extras->last=NULL;
                }
              else
                {
                  extras->next=malloc(sizeof(struct extrarec));
                  old=extras;
                  extras=extras->next;
                  extras->last=old;
                }

              strcpy(extras->extra,tmpstr);

            }  /* if(strlen */

        }  /* while */

      fclose(file);

      if (!skip)
        {
          extras->next=NULL;
          extras=first;
        }
     

      return 0;  /* no error reading spammers list */

    }
    
          
      
    
  main(int numargs, char **arg)

    {

      struct maildatarec maildata;
      char user_home[201] = "";
      char datapath[201]  = "";
      char background;
      int   returnval;
      pid_t daemonpid;

      void crtrvmail()
        {
          retrievemail(daemonmode, counter, &maildata);
        }
	
      callretrievemail=crtrvmail;

      maildata.apop=NO;
      maildata.forged=NO;
      maildata.notifybycomsat=NO;      
      maildata.verbosemode=NO;
      maildata.safemode=NO;
      maildata.paranoid=NO;
      maildata.tomode=NO;
      
      getuserinfo(maildata.system_user,user_home);

      /* determine if a popspam daemon is already running and if so,
         get its pid in 'daemonpid' */

      background=backgroundmode(&daemonpid, user_home, lockfilename);
             
      processparams(numargs,arg,background,&daemonmode,daemonpid,&maildata.verbosemode,&counter);


      if((returnval=readconfigfile(user_home, datapath, &logstate, logfilename, &maildata)) != 0) 
      /* if error reading config file */
        {
          switch(returnval)
            {
              case -1:  printf("Error: Cannot access config. file %s/.popspam\n",user_home);
                        exit(1);
              case -2:  printf("Error: Config. file %s/.popspam must have read/write access for the user only.\n",user_home);
                        exit(2);
              case -3:  printf("Error: Invalid/Inaccessable datapath %s\n",datapath);
                        exit(3);
              case -4:  printf("Error: Cannot access log file %s\n",logfilename);
                        exit(4);
              case -5:  printf("Error: Cannot access alternative mailbox file %s\n",maildata.mailbox);
                        exit(5);
              case -6:  printf("Error: A required parameter(host, user, password) is missing from config. file\n");
                        exit(6);
            }
        }


      if((returnval=readspammers(datapath,maildata.paranoid,maildata.tomode))!=0)
      /* if no spammers list available */
        {
	  switch(returnval)
	    {
	      case -1: printf("\nYou must provide a list of spammers in file \"spammers.popspam\".\n");
	               break;
  	      case -2: printf("\nMissing file \"friends.popspam\" required for paranoid mode.\n");
	               break;
	      case -3: printf("\nMissing file \"to.popspam\" required for to-mode #2\n");
	    }
          exit(12);
        }


      if (daemonmode)  /* if user wants to run in daemon mode */
        rundaemonmode(lockfilename);


      /* set popspam identity string used for all log messages 
         this must be set after we enter daemon mode to get correct pid */

      if(logstate==LOGSY) 
        /* include user login name in system log messages */
        sprintf(popidentity,"popspam[%ld](%s)",getpid(),maildata.system_user);
      else
        sprintf(popidentity,"popspam[%ld]",getpid());
 
         
      if(!daemonmode)   /* if foreground mode */
        /* call retrievemail function directly */
	(*callretrievemail)();
      else
        raise(SIGALRM); /* daemonmode, so use SIGALRM signal to activate
                           'retrievemail', thus ensuring signal blocking

/*
   while in daemon mode, just hangout, since the alarm function is used by
   'retrievemail' to make sure that 'retrievemail' is reactivated at the
   appropriate time, automatically.
*/

      while(daemonmode) 
        pause();      /*  'pause' just waits for a signal and
                          doesn't load down the system  */

    } 
