#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>


int connecttohost(char *addrname, char stream, int port)

  {

    int addr;
    struct hostent *host;
    struct sockaddr_in sock;

    host=gethostbyname(addrname);
    if (host==NULL)
      return -1;

    sock.sin_addr.s_addr=*((long*)host->h_addr);
    sock.sin_family=host->h_addrtype;
    sock.sin_port=htons(port);

    if (stream==1)
      addr=socket(AF_INET,SOCK_STREAM,0);
    else
      addr=socket(AF_INET,SOCK_DGRAM,0);
     
    if (addr==-1)
      return -1;
      
    if (connect(addr,(struct sockaddr *)&sock,sizeof(sock)) == -1 )
      return -1;
  
    return addr;

  }
    
int sendsock(int sock, char *msgs, char verbose)

  {
    if(verbose)
      printf("%s",msgs);
    return sendto(sock,msgs,strlen(msgs),0,NULL,0);
  }

void receivesock(int sock, char *str, int len, int timeout, char verbose)

  {

    char ch = 'x';
    int i=0;
    long starttime;
  
    starttime=time(NULL);
 
    while( (ch!='\n') && (i<len) && ( (time(NULL)-starttime)<timeout ) )
      {
        if(read(sock,&ch,1) == 1)
          *(str+(i++))=ch;
      } 

    str[i]='\0';

    if( (verbose) && (strlen(str)>0) )
      printf("%s",str);

  }
 
    


