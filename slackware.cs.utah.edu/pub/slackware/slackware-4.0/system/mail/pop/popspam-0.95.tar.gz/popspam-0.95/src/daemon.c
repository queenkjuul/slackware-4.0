/*
    popspam version 0.95 - POP3 mail client with integrated spam filtering.
    Copyright (C) 1998 James DeRidder
    
    Please see the file "COPYING" included with this distribution for
    license information.
    
*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <bsd/signal.h>
#include <syslog.h>
#include <time.h>
#include <unistd.h>
#include "daemon.h"

extern void (*callretrievemail)();
extern char popidentity[26];
extern char logstate;
extern char logfilename[201];
extern char lockfilename[201];


  char backgroundmode(pid_t *dpid, char *user_home, char *lockfilename)

  /* returns whether or not popspam is already running in daemon mode */

    {
 
      FILE *pidfile;
      char bgmode=0;

      strcpy(lockfilename,user_home);
      strcat(lockfilename,"/.popspam.pid");   
      if( (pidfile=fopen(lockfilename,"r")) != NULL )
       /* if lockfile found in user home directory */
        {
          /* read process pid from lockfile */
          fscanf(pidfile,"%ld",dpid);
          fclose(pidfile);
          /* check if the pid exists */
          bgmode=(!kill(*dpid,0));
          if(!bgmode)
           /* if pid does not exist then delete old lockfile */
            unlink(lockfilename);
        }

      return bgmode;

    }


  void rundaemonmode(char *lockfilename)

  /* run popspam as a daemon */

    {
      pid_t childpid;
      int i, fd;
      FILE *pidfile;

      childpid=fork(); 

      if (childpid!=0)
        exit(0);  /* parent terminates */

      if (childpid==0)
        {
          /* child creates lockfile in user home directory and saves
             its pid in that file. */
          fd=open(lockfilename,O_WRONLY|O_CREAT,S_IRUSR|S_IWUSR);
          pidfile=fdopen(fd,"w");
          fprintf(pidfile,"%ld\n",getpid());
          fclose(pidfile);
          close(fd);

          fd=getdtablesize();
          for(i=0; i<fd; i++)
            close(i);  /* close all files */
          setsid();
          signal(SIGTERM,signalcatch);  /* catch TERMinate signal */
          signal(SIGALRM,signalcatch);  /* catch ALaRM signal */
        } 

    }

  void signalcatch(int sig)

  /* handle TERM and ALRM signals */

    {

      if (sig==SIGTERM)
      /* shutdown daemon */
        {
          logmsg(logstate, logfilename, popidentity, "Terminated.");  /* write final log entry */
          unlink(lockfilename);   /* remove lockfile */
          exit(0);
        }

      if (sig==SIGALRM)  /* this 'wakes up' daemon to retrieve mail */
        (*callretrievemail)(); 
  
    }


  void logmsg(char logstate, char *logfilename, char *identity, char *str)

  /* write system/user log entry */

    {

      FILE *lf;
      int fdlf;
      time_t gmtime;
      struct tm localtm;
      struct tm *localtmptr = &localtm;
      char timestr[26];


      switch (logstate)
        {   

          case LOGNO:  break;  /* no logging, entry ignored */

          case LOGSY: openlog(identity,0,LOG_USER); /* use system log */
                      syslog(LOG_USER|LOG_INFO,str);
                      break;
 
          case LOGFI: if( (fdlf=open(logfilename,O_WRONLY|O_APPEND|O_CREAT)) != -1 )
              /* open/create user log, restrict access to user only */
                        {
                          fchmod(fdlf,S_IRUSR|S_IWUSR);
                          lf=fdopen(fdlf,"a");
                          gmtime=time(NULL);
                          localtmptr=localtime(&gmtime);
                          strftime(timestr,25,"%b %d %H:%M:%S",localtmptr);
                   /* simulate system log date/time stamp */
                          fprintf(lf,"%s %s: %s\n",timestr,identity,str);
                          fclose(lf);
                          close(fdlf);
                        }

        }  /* switch */

      }
