/*
    popspam version 0.95 - POP3 mail client with integrated spam filtering.
    Copyright (C) 1998 James DeRidder
    
    Please see the file "COPYING" included with this distribution for
    license information.
    
*/

#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "popspam.h"
#include "email.h"


  char isIP(char *str, char *complete)

  /* is string 'str' a complete or partial IP address? 
     may be invalid address (such as 300.299.300.1)
     but must be of general form ???.???.???.???
     example: 1234.128.12345.1 would return false */  

    {

      int i, digcnt=0, percnt=0, wasper=0;


      *complete=1;

      for(i=0; i<strlen(str); i++)  /* look at each char individualy */
        {
          if(isdigit(*(str+i)))  /* if character a number */
            {
              digcnt++;   /* increment digit count */
              wasper=0;   /* char was not a period */
            }
          else
            if(*(str+i)=='.')  /* if char a period */
              {
                if( wasper || (i==0) )    /* if previous char was a period 
                                             or if this is the first char */
                  return 0;  /* then not IP */
                else
                  {
                    digcnt=0;  /* reset digit count */
                    percnt++;  /* increment the period count */
                    wasper=1;  /* yes, this was a period */
                    if(i==strlen(str)-1) /* if this char is last char in str */
                      *complete=0; /* then 'str' is not a complete IP */ 
                  }
              }
            else   /* char was not a number or a period */
              return 0;  /* not IP */

          if(digcnt>3)  /* if more than 3 consecutive digits */
            return 0;   /* not IP */
 
        }  /* for */
      
 
      if(percnt<3)   /* if less than 3 periods in 'str' */
        *complete=0; /* then IP address is not complete  */
 
      if(percnt>3)  /* if more than 3 periods in 'str' */ 
        return 0;   /* not IP */
      else
        return 1;   /* yes, 'str' is in IP address format */


    }


  char *emailaddr(char *str)

  /* return email address in user@host.dom format, stripping away
     plain text username, etc. */

    {

      static char tmpstr[201];
      char tmpstr1[201] = "";
      char i, *ptr, *ptr1;


      /* find the '@' symbol in 'str' */
      if( (ptr=ptr1=strchr(str,'@')) != NULL)
        {
          strcpy(tmpstr,"");

          while((ptr--)!=str)
            {

           /* get user name, reading chars until beginning of
              'str' or char is not a letter, number, dash, underscore
              or period */

              if(isalnum(*ptr) || (*ptr=='-') || (*ptr=='_') || \
                 (*ptr=='.')) 
                strncat(tmpstr,ptr,1);
              else
                break;
            }

      /* username was read backwards starting at '@' so
         copy 'tmpstr' into 'tmpstr1' in reverse order */ 

          for(i=0; i<strlen(tmpstr); i++)
            tmpstr1[i]=tmpstr[strlen(tmpstr)-1-i];

          strcat(tmpstr1,"@");  /* restore the '@' after username */

          while(*(ptr1++)!='\0')
            {

          /* get hostname, reading from the right of '@' in 'str'
             until end of the string or char is not a letter, number, dash,
             underscore, or period */

              if(isalnum(*ptr1) || (*ptr1=='-') || (*ptr1=='_') || \
                 (*ptr1=='.'))
                strncat(tmpstr1,ptr1,1);
              else
                break;
            }
          strcpy(tmpstr,tmpstr1);
        }
      else  /* no '@' symbol was found in 'str' */
        strcpy(tmpstr,"nobody");

      return tmpstr;  /* return the processed email address */

    }
void splitheader(char *key, char *msgheader, char **rtrheader) 

  /* returns 'rtrheader' which contains all headers from 'msgheader' 
     that match the keyword specified in 'key' */
 
    {

      char *scan, *tmp;
      int linelen;

           
      scan=msgheader;
      while((scan=strstr(scan,key))!=NULL) /* look for 'key' in 'msgheader' */
        {
             
          linelen=((long)strchr(scan,'\r') - (long)scan + 1);
          tmp=malloc(linelen+1);
          memcpy(tmp,scan,linelen);
          *(tmp+linelen)='\0';
        
          if(*rtrheader==NULL)
            {
              *rtrheader=malloc(strlen(tmp)+2);
              strcpy(*rtrheader,tmp);
            }
          else
            {
              *rtrheader=realloc(*rtrheader,strlen(*rtrheader)+strlen(tmp)+2);
              strcat(*rtrheader,tmp);
            }
          free(tmp);
          scan++; 

        }   /* while 'key' can still be found in 'msgheader' keep looping */

    }


  int isspam(char *msghdr, char *firstline, struct friendrec *fr,
             struct torec *to, struct spamrec *sp, struct subjrec *sj,
	     struct extrarec *ex, char forged, char paranoid, char tomode)

  /* determine if message is spam based upon message header */

    {

      void *first;
      char i, *scan, *scan1, *scan2, *tmphdr, valid;
      char *fromhdr=NULL, *tohdr=NULL, *recvhdr=NULL, *subjhdr=NULL;
      char *msgidhdr=NULL, *referencehdr=NULL;
      char **fromptr=&fromhdr, **toptr=&tohdr, **receiveptr=&recvhdr;
      char **subjptr=&subjhdr, **msgidptr=&msgidhdr, **refptr=&referencehdr;
      char splitkey[3][15] = { "from: ","return-path: ", "reply-to: " };
      int o;
      
      
      
      for(i=0; i<3; i++)
            /* get from headers from 'msgheader' */
            splitheader(&splitkey[i][0],msghdr,fromptr);
          
      first=fr;
      while ( (fromhdr!=NULL) && (fr!=NULL) )
      /* check from header against known friends */
        {
          if(strstr(fromhdr,fr->myfriend) != NULL)  /* if friend */
            {
              fr=first;
	      free(fromhdr);
              return 0;  /* friend, so consider it not spam */
            }
          fr=fr->next;
        }
      fr=first;
      
      
      splitheader("subject: ",msghdr,subjptr);
      
      if(paranoid)
      /* no strangers! */   
        {
	  /* since message was not from a friend, check if it's
	     in reference (a response) to another message */
	  splitheader("references: ",msghdr,refptr);
	  if(referencehdr==NULL)
	    if((subjhdr==NULL) || strncmp(subjhdr+9,"re:",3))
	      {
	        free(fromhdr);
		free(referencehdr);
	        free(subjhdr);
	        return 1; /* not a reply, treat as spam */
	      }	
	  free(referencehdr);      
	}    
      
      
      splitheader("message-id: ",msghdr, msgidptr);
      if(msgidhdr==NULL)
        {
	  free(fromhdr);
	  free(subjhdr);
          return 1;
	 }
      else
        {
	  if( ((scan=strchr(msgidhdr,'<'))!=NULL) && ((scan1=strchr(msgidhdr,'>'))!=NULL))
	    {
	      scan2=strchr(scan,' ');
	      if((scan2!=NULL) && (scan2<scan1))
	        {
		  free(fromhdr);
		  free(msgidhdr);
		  free(subjhdr);
		  return 1;
		}
	      scan2=strchr(scan,'@');
	      if((scan2==NULL) || (scan2>scan1))
	        {
		  free(fromhdr);
		  free(msgidhdr);
		  free(subjhdr);
		  return 1;
		}      
	    }
	  else
	    {
	      free(fromhdr);
	      free(msgidhdr);
	      free(subjhdr);
	      return 1;
	    }  
        }
	
      free(msgidhdr);
	
      first=ex;
      while (ex!=NULL)
      /* check for spammer headers */
        {
          if(strstr(msghdr,ex->extra) != NULL)
            {
              ex=first;
	      free(fromhdr);
	      free(subjhdr);
              return 1;  /* spammer */
            }
          ex=ex->next;
        }
      ex=first;

     
      splitheader("received: ",msghdr,receiveptr);

      if(forged && (recvhdr!=NULL)) 
      /* if received header exists and we want to check for forgery */ 
        if(strstr(recvhdr,"may be forged")!=NULL)
         /* if forged message warning found in received header */
	  {
	    free(fromhdr);
	    free(recvhdr);
	    free(subjhdr);
            return 1;    /* consider it spam */
	  }
      
      splitheader("\nto: ",msghdr,toptr);

      for(i=0; i<3; i++) 
        /* check from, to, received headers against know spammers */ 
        {
          if(i==0)
            tmphdr=fromhdr;
          else
            if(i==1)
              tmphdr=tohdr;
            else
              tmphdr=recvhdr; 

          if( (tmphdr!=NULL) && (i<2) )
            for(o=0; o<strlen(tmphdr); o++)
              if(!isascii(*(tmphdr+o)))
	        {
		  free(fromhdr);
	          free(tohdr);
                  free(recvhdr);
		  free(subjhdr);
                  return 1;
		}

          first=sp;
          while ( (tmphdr!=NULL) && (sp!=NULL) )
            {
              if((scan=strstr(tmphdr,sp->spammer)) != NULL)
              /* found spammer as substring in header */
                {
                  if( (!isalnum(*(scan-1))) && ( *(scan-1) !='-' ) && ( *(scan-1) != '_' ) )
                    if( (!isalnum(*(scan+strlen(sp->spammer)))) && \
                        (*(scan+strlen(sp->spammer)) != '.')    && \
                        (*(scan+strlen(sp->spammer)) != '-')    && \
                        (*(scan+strlen(sp->spammer)) != '_') )
                     /* if not just random part of another host name */
                      {
                        sp=first;
			free(fromhdr);
	                free(tohdr);
                        free(recvhdr);
			free(subjhdr);
                        return 1;  /* spammer */
                      }
                }
            
              sp=sp->next;

            }   /* while not done with spammer list */

          sp=first;

        }  /* for */

            
       free(fromhdr);
       free(recvhdr);

       if(tomode)
         if((tohdr==NULL) || (!strncmp(tohdr,"\nto: \r",6)))
           {
	     free(subjhdr);
  	     free(tohdr);  /* no 'To: ' header and to-mode active */
	     return 1;     /* consider spam */
	   }  

      if(tomode>1)
        {
	  valid=0;
	  first=to;
	  while(to != NULL)
	    {
  	      valid=((strstr(tohdr,to->toaddr))!=NULL) | valid;
	      to=to->next;
	    }
	  if(!valid)
	    {
	      to=first;
	      free(subjhdr);
	      free(tohdr);  /* valid 'To: ' line not found */
	      return 1;     /* consider spam */
	    }         
	}
	
      to=first;
      free(tohdr);
	  	   	    
      /* scan subject header through list of spam subjects */ 

      
      
      first=sj;
      while ( (subjhdr!=NULL) && (sj!=NULL) )
        {

          if((strstr(subjhdr,sj->subjstr) != NULL) || \
	     (strstr(firstline,sj->subjstr) != NULL))
            {
              /* found spam subject as substring in subject header */
              sj=first;
	      free(subjhdr);
              return 1;  /*spammer */
            }
          sj=sj->next;

        }   /* while not done with spam subject list */ 

      sj=first;
      free(subjhdr);


      return 0;  /* not spammer */

    }
