int connecttohost(char *addrname, char stream, int port);
int sendsock(int sock, char *msgs, char verbose);
void receivesock(int sock, char *str, int len, int timeout, char verbose);

