#define LOGNO 0
#define LOGSY 1
#define LOGFI 2

char backgroundmode(pid_t *, char *, char *);
void rundaemonmode(char *);
void signalcatch(int);
void logmsg(char, char *, char *, char *);
