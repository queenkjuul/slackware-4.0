char *apophost(char *);
void process_msgs(int socketaddr, int num, char daemonmode, struct maildatarec *);
void process_good(int socketaddr, int num, struct maildatarec *);
int connecttopop(struct maildatarec *, int *nummsg);
void disconnectpop(int socketaddr, char verbosemode);
void retrievemail(char daemonmode, int counter, struct maildatarec *);
