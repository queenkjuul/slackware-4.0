/*
    popspam version 0.95 - POP3 mail client with integrated spam filtering.
    Copyright (C) 1998 James DeRidder
    
    Please see the file "COPYING" included with this distribution for
    license information.
    
*/

#include <bsd/signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>
#include "popspam.h"
#include "email.h"
#include "daemon.h"
#include "misc.h"
#include "pop3.h"
#include "sockets.h"

extern struct torec *to;
extern struct friendrec *friend;
extern struct spamrec *spam;
extern struct subjrec *subject;
extern struct extrarec *extras;
  
extern char popidentity[26];
extern char logstate;
extern char logfilename[201];


char *apophost(char *str)

  {
  
      char *scan, *scan2;
      static char ts[101] = "";
      
      if ((scan=strchr(str,'<'))==NULL)
        return (char *)NULL;
      if ((scan2=strchr(scan,'>'))==NULL)
        return (char *)NULL;
      
      strncpy(ts,scan,scan2-scan+1);
      
      return ts;
      
  }
      


void process_msgs(int socketaddr, int num, char daemonmode, struct maildatarec *md)

  /* read in message headers, determine if they are spam, and
     retrieve/delete messages accordingly */

    {
  
      int numgoodmsgs=0, numspammsgs=0, i, linecnt;
      char done, spammsg;
      char *firstline, *msgheader;
      char tmpstr[301];

      for(i=0; i<num; i++)
        {

          linecnt=0;
          done=0;

          /* get message headers and first line of message text */

          sprintf(tmpstr,"TOP %d 1\r\n",i+1);
          sendsock(socketaddr,tmpstr,md->verbosemode); 
          
          do
            {
              receivesock(socketaddr,tmpstr,82,2,md->verbosemode>1);

              /* pop3 done string is '.' alone on single line */ 

              done=(!strncmp(tmpstr,".\r",2)) | done;

              if((strlen(tmpstr)>0) && !done)
                {
                  if ((linecnt++)==0)
                    {
                      msgheader=malloc(strlen(tmpstr)+1);
                      strcpy(msgheader,tmpstr);
                    }
                  else
                    {
                      msgheader=realloc(msgheader,strlen(msgheader)+strlen(tmpstr)+1);
                      strcat(msgheader,tmpstr);
                    }
                }
            }
          while(!done);  /* while not done receiving message header */

          firstline=strrchr(msgheader,'\n');
	  *firstline=' ';
	  firstline=strrchr(msgheader,'\n');
	  
          lowerstr(msgheader);

          if(spammsg=isspam(msgheader, firstline, friend, to, spam, subject,
	     extras, md->forged, md->paranoid, md->tomode))
            {
              /* message was spam */
              numspammsgs++;         /* increment count of spam messages */
              if(md->verbosemode)
                printf("Message #%d is spam!\n",i+1);
            }
          else
              {
                /* good message */
                process_good(socketaddr, i+1, md);  /* retrieve it */
                numgoodmsgs++;      /* increment count of good messages */
              }

          if( (spammsg && !md->safemode) || (!spammsg) )
           /* if spam message and not safe mode OR not spam message */
            {
              /* delete the already retrieved or spam message */
              sprintf(tmpstr,"DELE %d\r\n",i+1);
              sendsock(socketaddr,tmpstr,md->verbosemode);
              receivesock(socketaddr,tmpstr,82,20,md->verbosemode);
            }
	    
	  free(msgheader);
	  msgheader=NULL;

        }
 
        sprintf(tmpstr,"%d messages for %s@%s",num,md->user,md->pophost);
        logmsg(logstate, logfilename, popidentity, tmpstr);
        sprintf(tmpstr,"%d messages retrieved, %d were spam.",numgoodmsgs,numspammsgs);
        logmsg(logstate, logfilename, popidentity, tmpstr);
        if(md->safemode && (numspammsgs>0))
          logmsg(logstate, logfilename, popidentity, "Safe mode, spam not deleted.");

        if(!daemonmode)
          {
            printf("Retrieved %d and identified %d as spam.\n",numgoodmsgs,numspammsgs);
            if(numspammsgs>0)
              if(md->safemode)
                printf("Safe mode active, spam messages NOT deleted from server.\n");
              else
                printf("Spam messages have been deleted.\n");
          }
        
      }

      
  void process_good(int socketaddr, int num, struct maildatarec *md)

  /* retrieve an individual message from the server */

    {

      FILE *mail, *mailtmp;
      int fdcomsat, fdmail, linecnt=0;
      char done=0, tmpstr[163], fromline[203];
      time_t currtime;
      sigset_t set;
      long mailboxpos;
   
      strcpy(fromline,"");
 
      mailtmp=tmpfile();  /* open a temporary file for the message */ 
 
      sprintf(tmpstr,"RETR %d\r\n",num);
      sendsock(socketaddr,tmpstr,md->verbosemode); 

      do
        {
          receivesock(socketaddr,tmpstr,162,2,0);
          done=( (!strncmp(tmpstr,".\r",2)) | done);
          if( (!done) && (++linecnt>1) ) 
            {
              fprintf(mailtmp,"%s",tmpstr);
              if(strlen(fromline)==0)
                if(!strncmp(tmpstr,"From: ",6))  /* if this is from line */
                  {
                    /* create formatted from line with current date stamp */
                    strcpy(fromline,"From ");
                    strcat(fromline,emailaddr(tmpstr+6));
                    strcat(fromline,"  ");
                    currtime=time(NULL);
                    strcat(fromline,ctime(&currtime));
                  }
            }
        }
      while (!done);   /* read message until done string is sent by server */


      rewind(mailtmp);

      /* open mailbox file, not taking no for an answer */
      while ( (fdmail=open(md->mailbox,O_RDWR|O_CREAT,S_IRUSR|S_IWUSR)) == -1 );
      mail=fdopen(fdmail,"r+");
      while ( (flock(fdmail,LOCK_EX)) == -1 );  /* get exclusive file lock */

      fseek(mail,0,SEEK_END);  /* seek to end of mailbox file */
      mailboxpos=ftell(mail);  /* get offset of file end, needed by comsat */ 


      /* block TERM signal while message is being written to mailbox file */
      sigemptyset(&set);
      sigaddset(&set, SIGTERM);
      sigprocmask(SIG_BLOCK, &set, NULL);

      /* first write formated from line */
      fprintf(mail,"%s",fromline);

      while(!feof(mailtmp))  /* write contents of 'mailtmp' to mailbox */
        {
          fgetline(mailtmp,tmpstr,80);
          if(strlen(tmpstr)<80)
            strcat(tmpstr,"\n");
          fprintf(mail,"%s",tmpstr);
        }

      fclose(mail);
      close(fdmail);
      fclose(mailtmp);

      /* unblock TERM signal */
      sigprocmask(SIG_UNBLOCK, &set, NULL);
 

      if(md->notifybycomsat)
        {
          /* send UDP datagram to comsat */
          fdcomsat=connecttohost("localhost",0,512);
          /* send new mail notice to comsat */
          sprintf(tmpstr,"%s@%ld\r\n",md->system_user,mailboxpos);
          sendsock(fdcomsat,tmpstr,0);
          close(fdcomsat);
        }

    }


  int connecttopop(struct maildatarec *md, int *nummsg)

  /* connect to POP3 server and return the number of messages on the
     server in 'nummsg' */ 

    {

      char *timestampstr;
      char sendstr[151];
      char recvstr[201];
      int msglen;
      int socketaddr;


      if(md->verbosemode)
        printf("\nContacting host \"%s\"\n",md->pophost);

      if( (socketaddr=connecttohost(md->pophost,1,110)) == -1)
        return -1;  /* error connecting */

      /* receive initial greeting from server */
      receivesock(socketaddr,recvstr,200,30,md->verbosemode);

      if( md->apop && ((timestampstr=apophost(recvstr))!=NULL))
        {

          strcat(timestampstr,md->pass);	
	  sprintf(sendstr,"APOP %s %s\r\n",md->user,md5hash(timestampstr));
	  sendsock(socketaddr,sendstr,md->verbosemode);
          receivesock(socketaddr,recvstr,82,20,md->verbosemode);
	  
	}
      else
        {  
	  
	  if(md->apop)
	    {
	      *nummsg=-1;  /* APOP loggin not possible */
	      return socketaddr;
	    }  
	    
          sprintf(sendstr, "USER %s\r\n",md->user);
          sendsock(socketaddr,sendstr,md->verbosemode);
          receivesock(socketaddr,recvstr,82,20,md->verbosemode);
       
          sprintf(sendstr, "PASS %s\r\n", md->pass);
          if(md->verbosemode)
            printf("PASS x\n");
          sendsock(socketaddr,sendstr,0);
          receivesock(socketaddr,recvstr,82,20,md->verbosemode);
	  
        }


      if (strncmp(recvstr,"+OK",3))
	{
          *nummsg=-2;  /* error logging in */
	  return socketaddr;
	}
	    
	    
      /* use 'STAT' command to get number of messages on server */ 
      sendsock(socketaddr,"STAT\r\n",md->verbosemode);
      receivesock(socketaddr,recvstr,82,20,md->verbosemode);

      sscanf(recvstr,"%s %u %lu",recvstr,nummsg,&msglen);
      if (strcmp(recvstr,"+OK"))
        *nummsg=-3;  /* error talking to server */
         
      return socketaddr;  /* return file descriptor for the connection */

    }


  void disconnectpop(int socketaddr, char verbosemode)
  
  /* disconnect from the server */ 
  
    {
      char tmpstr[83];
      
      sendsock(socketaddr,"QUIT\r\n",verbosemode);
      receivesock(socketaddr,tmpstr,82,20,verbosemode);
      close(socketaddr);
    }
    
    
  void retrievemail(char daemonmode, int counter, struct maildatarec *md)
 
  /* calls 'connecttopop' and if neccessary, 'process_msgs'
     this function is called by the main program and in daemon mode
     to 'do it all' */

    {

      int nummsg;
      int socketaddr;
      char tmpstr[301];


      if(daemonmode)
      /* set SIGALRM alarm to 'wake up' daemon in 'counter' seconds */
        alarm(counter);
  
      socketaddr=connecttopop(md, &nummsg);

      if(socketaddr == -1)  /* if couldn't connect */
        {
          if(!daemonmode)   /* if foreground mode */
            {
              /* complain to user and terminate */
              printf("Cannot connect to host \"%s\" \n",md->pophost);
              exit(13);
            }
        }
      else  /* connection established */
        { 
          if(nummsg==0)  /* if no mail */
            {
              sprintf(tmpstr,"No messages for %s@%s",md->user,md->pophost);
              logmsg(logstate, logfilename, popidentity, tmpstr);
              if(!daemonmode)
                printf("No messages.\n");
            }
          else
            if(nummsg<0)
              {
                switch(nummsg)
		  {
		    case -1:
		    case -2:  disconnectpop(socketaddr,md->verbosemode);
		              if(nummsg==-1)
		                sprintf(tmpstr,"Host \"%s\" does not support APOP",md->pophost);
			      else
			      	sprintf(tmpstr,"Loggin failed at host \"%s\"",md->pophost);
			      logmsg(logstate, logfilename, popidentity, tmpstr);
			      if(!daemonmode)
			        {
			          printf("%s\n",tmpstr);
				  exit(14);
				}
			      else
			        raise(SIGTERM);
			      break; 
			      
		    case -3:  if(!daemonmode)
			        {
				  disconnectpop(socketaddr,md->verbosemode);
				  printf("Error checking for mail at host \"%s\"\n",md->pophost);
			          exit(14);	  
				}
		  }	       
                
              }
            else
              if(nummsg>0)  /* if user has mail */
                {
                  if(!daemonmode)
                    printf("Processing %d messages.\n",nummsg);
		  /* process the mail on server */    
                  process_msgs(socketaddr, nummsg, daemonmode, md);
                }
        
          disconnectpop(socketaddr,md->verbosemode);
             
        }

    }
