#include <strings.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <syslog.h>
#include "global.h"
extern "C"
{
#include "md5.h"
}
#include <signal.h>
#include <sys/file.h>
#ifdef PASSAUTH
#include <pwd.h>
#endif
#ifdef SPASSAUTH
#include <shadow.h>
#endif


#define PTIMEOUT 600 /*10 mins of no typing*/

/*
  The mailbox will be locked, and then recreated as a temp file.
  It will then be transfered line by line into a new file.
  While the transfer is taking place, the mailbox will be parsed to see
  where new messages begin.
*/

#define MBOXDIR "/var/spool/mail/" /*directory in which the mailbox is found*/

struct message
{
  unsigned int number; /*message number*/
  char status; /*0 for deleted, 1 otherwise*/
  unsigned long int position; /*which octet in the file it starts at*/
  unsigned int numlines; /*number of lines in this message*/
  message *next; /*pointer to the next message struct*/
};

struct mailbox
{
  char username[100]; /*username*/
  uid_t uid;
  gid_t gid;
  mode_t mode;
  unsigned int nummessages; /*Number of messages*/
  unsigned long int size; /*Total size of mailbox*/
  unsigned long int numlines; /*Total # of lines*/
  message *start;         /*pointer to first messages*/
};

int statfnc(mailbox &MBOX);
int retmessagesize(mailbox &MBOX,int messagenum);
int list(mailbox &MBOX,int messagenum);
int retr(mailbox &MBOX,int messagenum,int numlines,FILE *mailbox);
int dele(mailbox &MBOX,int messagenum);
int noop(void);
int rset(mailbox &MBOX);
int top(mailbox &MBOX,int messagenum, unsigned int numlines,FILE *mailbox);
int uidl(mailbox &MBOX, int messagenum,FILE *mailbox);
int retr_msguid(mailbox &MBOX,int msgnum, unsigned char *digest,FILE *mailbox);
int closeandupdate(mailbox &MBOX,FILE *mailbox);
int closenoupdate(mailbox &MBOX,FILE *mailbox);
int authuser(char *username,char *password);





/*************************************************************************/

FILE *mbox_init(char *mbox,mailbox &MBOX) /* mbox is just the mailbox, no
					  path
                                          MBOX is the mailbox we will
                                          fill in
                                       */
{
  int mboxfd,tempfd,lfd;/*lfd is the lock file fd*/
  struct stat stats; 
  FILE *mboxp,*tempmboxp;
  char tempfilename[100]=MBOXDIR;
  char lockfilename[100];
  message *temp;
  char line[512];
  char newmess=1; /*just a flag that goes on when a blank line is read*/
  unsigned long int position=0; 

  strncpy(MBOX.username,mbox,sizeof(MBOX.username));
  sprintf(tempfilename,"%s.%s.pop",MBOXDIR,mbox);/*create a ".mbox.pop" file*/
  if ((tempfd=open(tempfilename,O_CREAT|O_EXCL|O_WRONLY,0600))==-1)
    {
      printf("-ERR Temporary file already exists\r\n");
      fflush(stdout);
      return NULL;
    };
  /*there is no need to lock the temporary file, however, the
    mailbox must be locked while it is accessed*/
  strcpy(tempfilename,MBOXDIR);
  strncat(tempfilename,mbox,sizeof(tempfilename)-strlen(MBOXDIR));

  if (stat(tempfilename,&stats)==-1) /*create a zero size file if it does not exist*/
    {
      if (errno==ENOENT)
        {
          mboxfd=open(tempfilename,O_CREAT|O_WRONLY);
          close(mboxfd);
        };
    };

  /*sleep if a procmail type lock file exists, else create it:*/
  strcpy(lockfilename,tempfilename);
  strcat(lockfilename,".lock");
  lfd=open(lockfilename,O_CREAT|O_EXCL|O_WRONLY);
  while(lfd==-1)  
    {
      sleep(1);
      lfd=open(lockfilename,O_CREAT|O_EXCL|O_WRONLY);
    };
  flock(lfd,LOCK_EX);

  if ((mboxfd=open(tempfilename,O_RDONLY))==-1)
    {
        printf("-ERR error opening mailbox\r\n");
        fflush(stdout);
        sprintf(tempfilename,"%s.%s.pop",MBOXDIR,mbox);
        unlink(tempfilename);
        return NULL; 
    };

  fstat(mboxfd,&stats); /*get permissions and modes for the file*/
  MBOX.uid=stats.st_uid;
  MBOX.gid=stats.st_gid;
  MBOX.mode=stats.st_mode;  

  flock(mboxfd,LOCK_EX);
  mboxp=fdopen(mboxfd,"r");
  tempmboxp=fdopen(tempfd,"w");
  
  MBOX.nummessages=0;
  MBOX.size=0;
  MBOX.numlines=0;
  MBOX.start=new message;
  temp=MBOX.start;
  temp->number=0;
  temp->status=1;
  temp->position=0;
  temp->numlines=0;

  while(fgets(line,512,mboxp)!=NULL)
    {
      if ((strncmp(line,"\n",1)==0)||(strncmp(line,"\r\n",2)==0))
        newmess=1;
      else if ((strncmp(line,"From ",5)==0)&(newmess==1))
        {
          MBOX.nummessages++;
          temp->next=new message;
          temp=temp->next;
          temp->position=position;
          temp->numlines=0;
          temp->status=1;
          temp->number=MBOX.nummessages;
        }
      else
        newmess=0;
      MBOX.size+=strlen(line);
      MBOX.numlines++;                  
      position+=strlen(line);
      temp->numlines++;
      fputs(line,tempmboxp);
    };
  sprintf(tempfilename,"%s%s",MBOXDIR,mbox);
  flock(mboxfd,LOCK_UN);
  fclose(mboxp);
  while(unlink(tempfilename)!=0)
    syslog(LOG_CRIT,"Error deleting file %s\r\n",tempfilename);
  unlink(lockfilename); /*kill lockfile*/

  temp->next=NULL;
  printf("+OK I am ready to serve you master!\r\n");
  fflush(stdout);
  fclose(tempmboxp);
  sprintf(tempfilename,"%s.%s.pop",MBOXDIR,mbox);
  tempmboxp=fopen(tempfilename,"r");
  return tempmboxp;
};
/*************************************************************************/
int statfnc(mailbox &MBOX)
{
  printf("+OK %d %d\r\n",MBOX.nummessages,MBOX.size);
  fflush(stdout);
  return 1;
};

/*************************************************************************/

int retmessagesize(mailbox &MBOX,int messagenum) /*return message size,
                                                   note that first
                                                   message is 0*/
{
  unsigned int dummy;
  message *temp=MBOX.start;
  unsigned int size;

  for (dummy=0;dummy<messagenum;dummy++)
    temp=temp->next;
  if (messagenum!=MBOX.nummessages)
    size=(temp->next)->position-temp->position;
  else
    size=MBOX.size-temp->position;
  return size;
};
/*************************************************************************/
int list(mailbox &MBOX,int messagenum)
{
  message *temp;
  unsigned int dummy; 
  unsigned int size; 

  if (messagenum==0)
    {
      temp=MBOX.start;
      printf("+OK %d messages\r\n",MBOX.nummessages);
      fflush(stdout);
      for (dummy=1;dummy<=MBOX.nummessages;dummy++)
        {
          printf("%d %d\r\n",dummy,retmessagesize(MBOX,dummy));
          fflush(stdout);
        };
      printf(".\r\n");
      fflush(stdout);
    }
  else
    {
      if (messagenum>MBOX.nummessages|messagenum<=0)
        {
          printf("-ERR Number out of range, insert 20c and try again\r\n");
          fflush(stdout);
          return -1;
        };
      printf("+OK %d %d\r\n",messagenum,retmessagesize(MBOX,messagenum));
      fflush(stdout);
    };
  return 1;
};
/*************************************************************************/
int retr(mailbox &MBOX,int messagenum,int numlines,FILE *mailbox)
{
  unsigned int dummy=0;
  char line[513];
  message *temp=MBOX.start;
  unsigned int headlines=0; /*Number of lines in header*/

  if (messagenum>MBOX.nummessages|messagenum<=0)
    { 
      printf("-ERR Number out of range, insert 20c and try again\r\n");
      fflush(stdout);
      return -1;
    };
  printf("+OK\r\n");
  fflush(stdout);
  while(dummy!=messagenum)
    {
      dummy++;
      temp=temp->next;
    };

  fseek(mailbox,temp->position,SEEK_SET);
  
  if ((numlines>temp->numlines)|(numlines<0))
    numlines=temp->numlines;
  else
    {
      char blankline=0;
      while(!blankline)
        {
          headlines++;
          fgets(line,513,mailbox);
          if (strncmp(line,"\r\n",2)==0|strncmp(line,"\n",1)==0)
            blankline=1;
          if (line[strlen(line)-1]=='\n')
            {
              if (line[strlen(line)-2]=='\r')
                line[strlen(line)-2]=0x0;
              line[strlen(line)-1]=0x0;
            };
          if (line[0]=='.')
            {
              printf(".");
              fflush(stdout);
            };
          printf("%s\r\n",line);
          fflush(stdout);
        };
    };
  if (numlines+headlines>=temp->numlines) /*if the number of lines asked for*/
    numlines=temp->numlines-headlines;  /*is > # of lines in msg after header, give whole msg*/

  for (dummy=0;dummy<numlines;dummy++)
    {
      fgets(line,513,mailbox);
      if (line[strlen(line)-1]=='\n')     /*UUUUUUUGGGGGGGGLLLYYYY*/
        {
          if (line[strlen(line)-2]=='\r')
            line[strlen(line)-2]=0x0;
          line[strlen(line)-1]=0x0;
        };
      if (line[0]=='.')
        {
          printf(".");
          fflush(stdout);
        };
      printf("%s\r\n",line);
      fflush(stdout);
    };
  printf(".\r\n");
  fflush(stdout);
  return 1; 
};     
/*************************************************************************/
int dele(mailbox &MBOX,int messagenum)
{
  unsigned int dummy=0;
  message *temp=MBOX.start;
  
  if (messagenum>MBOX.nummessages|messagenum<=0)
    { 
      printf("-ERR Number out of range, insert 20c and try again\r\n");
      fflush(stdout);
      return -1;
    };
  while(dummy!=messagenum)
    {
      dummy++;
      temp=temp->next;
    };
  temp->status=0;
  printf("+OK the message has gone to the great bit bucket\r\n");  
  fflush(stdout);
  return 1;
};
/*************************************************************************/
int noop(void)
{
  printf("+OK blah blah blah \r\n");
  fflush(stdout);
  return 1;
};
/*************************************************************************/
int rset(mailbox &MBOX)
{
  unsigned int dummy=0;
  message *temp=MBOX.start;
  for (dummy=1;dummy<=MBOX.nummessages;dummy++)
    {
      temp->status=1;
      if (temp->next!=NULL)
        temp=temp->next;
    };
  temp->status=1;
  fflush(stdout);
  return 1;
};
/*************************************************************************/
int top(mailbox &MBOX,int messagenum, unsigned int numlines,FILE *mailbox)
{
  return retr(MBOX,messagenum,numlines,mailbox);
};
/*************************************************************************/
int uidl(mailbox &MBOX, int messagenum,FILE *mailbox)
{
  unsigned char digest[16];
  int i,j;

  if (messagenum==0)
    {
      printf("+OK %d messages; msg# and uidl for message\r\n",MBOX.nummessages);
      fflush(stdout);
      for (i=1;i<=MBOX.nummessages;i++)
        {
          retr_msguid(MBOX,i,digest,mailbox);
          printf("%d ",i);
          fflush(stdout);
          for(j=0;j<16;j++)
            {
              printf("%02x",digest[j]);
              fflush(stdout);
            };
          printf("\r\n");
          fflush(stdout);
        };
      printf(".\r\n");
      fflush(stdout);
    }
   else
    {
      if (messagenum>MBOX.nummessages|messagenum<=0)
        { 
          printf("-ERR Number out of range, insert 20c and try again\r\n");
          fflush(stdout);
          return -1;
        };
      retr_msguid(MBOX,messagenum,digest,mailbox);
      printf("+OK %d ",messagenum);
      fflush(stdout);
        {
          for (j=0;j<16;j++)
            { 
              printf("%02x",digest[j]);
              fflush(stdout);
            };
          printf("\r\n");
          fflush(stdout);
        };
    };
   return 1;
};
/*************************************************************************/
int retr_msguid(mailbox &MBOX,int msgnum, unsigned char *digest,FILE *mailbox)
{
  unsigned int dummy=0;
  char line[513];
  message *temp=MBOX.start;
  MD5_CTX context;  

  MD5Init(&context);
  while(dummy!=msgnum)
    {
      dummy++;
      temp=temp->next;
    };
  fseek(mailbox,temp->position,SEEK_SET);
  for (dummy=0;dummy<temp->numlines;dummy++)
    {
      /*fseek(mailbox,temp->position,SEEK_SET);*/
      fgets(line,513,mailbox);
      MD5Update(&context,(unsigned char *) line,strlen(line)); 
    };
  MD5Final(digest,&context); 
  return 1;
};
/*************************************************************************/
int closeandupdate(mailbox &MBOX,FILE *mailbox)
{
  char popmbox[100];
  char tempfile[100],tempfile2[100],lockfile[100];
  FILE *origmbox;
  unsigned int dummy=0;
  char line[513];
  int fd,lfd;
  message *temp=MBOX.start;
  
  sprintf(tempfile,"%s%s",MBOXDIR,MBOX.username);
  fd=open(tempfile,O_WRONLY|O_APPEND,0660);
  if (fd==-1)
    fd=open(tempfile,O_CREAT|O_WRONLY,0660); /*no mailbox so create it*/
  if (fd!=-1)
    {
      /*procmail type lock:*/
      sprintf(lockfile,"%s%s.lock",MBOXDIR,MBOX.username);
      lfd=-1;
      lfd=open(lockfile,O_WRONLY|O_CREAT|O_EXCL);
      while(lfd==-1)
        {
          lfd=open(lockfile,O_WRONLY|O_CREAT|O_EXCL);
          sleep(1);
        };
      flock(lfd,LOCK_EX);

      flock(fd,LOCK_EX);
      origmbox=fdopen(fd,"a");
    }
  else
    {
      printf("-ERR unable to create new mailbox\r\n");
      exit(-1);
    };
  
  while (temp->next!=NULL)
    {
      if (temp->status==1)
        {
          fseek(mailbox,temp->position,SEEK_SET);
          for (dummy=0;dummy<temp->numlines;dummy++)
            {
              fgets(line,513,mailbox);
              fputs(line,origmbox);
            };  
        };
      temp=temp->next;
    };
/*And for the last message:*/   
  if (temp->status==1)
    {
      fseek(mailbox,temp->position,SEEK_SET);
      for (dummy=0;dummy<temp->numlines;dummy++)
        {
          fgets(line,513,mailbox);
          fputs(line,origmbox);
        };  
    };
    
  /*delete temp mailbox*/
  sprintf(tempfile2,"%s.%s.pop",MBOXDIR,MBOX.username);
  unlink(tempfile2);
  flock(fd,LOCK_UN);
  fchown(fd,MBOX.uid,MBOX.gid);  /*set permissions correctly*/
  fchmod(fd,MBOX.mode);
  fclose(origmbox);
  unlink(lockfile);

  return 1;
};
/*************************************************************************/

int closenoupdate(mailbox &MBOX,FILE *mailbox)
{
  rset(MBOX);
  return closeandupdate(MBOX,mailbox);
};  
/*************************************************************************/
int authuser(char *username,char *password)
{
#ifdef NOAUTH
  return 1;
#endif
#ifdef PASSAUTH
  passwd *pw;
  if ((pw=getpwnam(username))==NULL)
    return -1;
  if (strncmp(crypt(password,pw->pw_passwd),pw->pw_passwd,13)==0)
    return 1;
  return -1;
#endif
#ifdef SPASSAUTH
  spwd *spw;
  if ((spw=getspnam(username))==NULL)
    return -1;
  if (strncmp(crypt(password,spw->sp_pwdp),spw->sp_pwdp,13)==0)
    return 1;
  return -1;
#endif
};

/*************************************************************************/

/*GLOBAL VARIABLES FOR SIGNAL STUFF*/

FILE *mboxf;
mailbox MBOXG;
/*************************************************************************/

void alarm_handler(int blah)
{
  closenoupdate(MBOXG,mboxf);
  exit(-1);
};
void other_err(int blah)
{
  closenoupdate(MBOXG,mboxf);
  exit(-1);
};
/*************************************************************************/

int main(void)
{
  char buffer[40];
  char command[4];
  char username[20];
  char password[20];
  char gotname=0;
  char auth=0;
  char quit=0;
  FILE *mailboxf;
  mailbox MBOX;
  unsigned int messagenum;

  signal(SIGHUP,other_err);
  signal(SIGALRM,alarm_handler);
  signal(SIGSEGV,other_err);
  signal(SIGINT,SIG_IGN);
  signal(SIGQUIT,other_err);
  signal(SIGABRT,other_err);
  signal(SIGTERM,other_err);
  struct sigaction sigact;
  sigact.sa_handler=other_err;
  sigemptyset(&sigact.sa_mask);
  sigact.sa_flags=SA_RESTART;
  sigaction(SIGPIPE,&sigact,NULL);

  printf("+OK welcome to YAPS v1.0(c) by Nir Oren, and how are we today?\r\n");
  fflush(stdout);
  while(!auth)
    {
      alarm(PTIMEOUT);
      fgets(buffer,40,stdin);
      alarm(0);
      if (strncasecmp(buffer,"USER ",5)==0)
        {
          strncpy(username,buffer+5,sizeof(username)-1);
          strtok(username,"\r");
          gotname=1;
          printf("+OK show me your papers, what is the pazzword?\r\n");
          fflush(stdout);
        }
      else if (strncasecmp(buffer,"PASS ",5)==0)
        {
          if (gotname!=1)
            {
              printf("-ERR very funny, I still don't know who you are\r\n");
              fflush(stdout);
            }
          else
            {
              strncpy(password,buffer+5,sizeof(password)-1);
              strtok(password,"\r");
              if (authuser(username,password)==1)
                auth=1;
              else
                {
                  printf("-ERR c'mon, I can think of a better username and password then that...\r\n");
                  fflush(stdout);
                  gotname=0;
                  sleep(5);
                };
            };
        }
      else if (strncasecmp(buffer,"QUIT",4)==0)
        {
          printf("+OK I can take rejection\r\n");
          fflush(stdout);
          exit(1);
        }
      else 
        {
          gotname=0;
          printf("-ERR spek in engliz plez\r\n");
          fflush(stdout);
        };
    };
 

  if ((mailboxf=mbox_init(username,MBOX))==NULL)
    {
      exit(-1);
    };
  mboxf=mailboxf; /*dumb global variable stuff*/
  MBOXG=MBOX;
  while(1)
    {
      alarm(PTIMEOUT);
      fgets(buffer,40,stdin);
      alarm(0);
      if (strncasecmp(buffer,"STAT",4)==0)
        statfnc(MBOX);
      else if (strncasecmp(buffer,"LIST",4)==0)
        {
          if (strlen(buffer)>6)
            {
              strtok(buffer," ");
              list(MBOX,atoi((char *)strtok(NULL,"\r")));
            }
          else
            list(MBOX,0);
        }
      else if (strncasecmp(buffer,"RETR",4)==0)
        {
          if (strtok(buffer," ")==NULL)
            {
              printf("-ERR need argument\r\n");
              fflush(stdout);
            }
          else 
            retr(MBOX,atoi((char *)strtok(NULL,"\r")),-1,mailboxf);
        }
      else if (strncasecmp(buffer,"DELE",4)==0)
        {
          if (strtok(buffer," ")==NULL)
            {
              printf("-ERR need argument\r\n");
              fflush(stdout);
            }
          else
            dele(MBOX,atoi((char *)strtok(NULL,"\r")));
        }
      else if (strncasecmp(buffer,"NOOP",4)==0)
        {
          noop();
        }
      else if (strncasecmp(buffer,"RSET",4)==0)
        {
          rset(MBOX);
          printf("+OK bzzzt mailbox has been reset\r\n");
	  fflush(stdout);
        }
      else if (strncasecmp(buffer,"TOP ",4)==0)
        {
          if (strtok(buffer," ")==NULL)
            {
              printf("-ERR need argument\r\n");
              fflush(stdout);
            }
          else
            {
              messagenum=atoi((char *)strtok(NULL," "));
              char *tmp=strtok(NULL,"\r");
              if (tmp==NULL)
                {
                  printf("-ERR need 2 arguments\r\n");
                  fflush(stdout);
                }
              else
                {
                  unsigned int numlines=atoi(tmp);
                  top(MBOX,messagenum,numlines,mailboxf);
                };
            };
        }
      else if (strncasecmp(buffer,"UIDL",4)==0)
        {
          if (strlen(buffer)>6)
            {
              strtok(buffer," ");
              uidl(MBOX,atoi((char *)strtok(NULL,"\r")),mailboxf);
            }
          else
            uidl(MBOX,0,mailboxf);
        }
      else if (strncasecmp(buffer,"QUIT",4)==0)
        {
          closeandupdate(MBOX,mailboxf);
          printf("+OK luv u, bye-bye\r\n");
          fflush(stdout);
          exit(1);
        }
      else
        {
          printf("-ERR spek in engliz plez\r\n");
          fflush(stdout);
        };
    };
};
