package msg;


$file = main'STDERR;
$level = 1;


sub level
{
local($m) = @_;

	$level = $m;
}

sub msg
{
local($line) = @_;

	print $file "$line\n" unless ($level < 1);
}

sub debug
{
local($line) = @_;

	print $file "debug: $line\n" unless ($level < 2);
}

sub warn
{
local($line) = @_;

	print $file "warning: $line\n";
}

sub error
{
local($line) = @_;

	print $file "error: $line\n";
}

1;
