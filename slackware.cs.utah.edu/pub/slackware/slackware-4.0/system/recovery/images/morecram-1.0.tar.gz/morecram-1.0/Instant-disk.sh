#!/bin/sh

if [ "$1" = "" ] ; then
    echo `basename $0`: Usage: 
    echo "     " `basename $0` "<path-to-root-directory>"
    echo " This creates a cramdisk on /dev/fd0 with the kernel image"
    echo " <path-to-root-directory>/zImage and the root filesystem"
    echo " specified by <path-to-root-directory>"
    echo "" `basename $0` "must run on a system with ramdisk"
    echo " support in the kernel as well as an unused /dev/ram1"
    echo " Only one" `basename $0` "can be running simultaneously"
    exit 1
fi

if [ ! -f $1/zImage ] ; then
    echo "cannot find $1/zImage"
    exit 1
fi

cp $1/zImage /tmp/cramdisk-kernel.tmp
./bin/dir2fsz2 $1 /tmp/cramdisk-image.tmp 3700 480
./bin/writefsz2 /tmp/cramdisk-image.tmp
rm /tmp/cramdisk-kernel.tmp

