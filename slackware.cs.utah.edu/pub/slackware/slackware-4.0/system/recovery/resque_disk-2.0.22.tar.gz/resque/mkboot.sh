#!/bin/sh
function instt
{
if [ -r $1 ]; then
printf "Install $1 on $2 ? [n/y] "
read ans
if [ "$ans" = "y" -o "$ans" = "Y" ]; then
printf "Installing $1 on $2 ..."
dd if=$1 of=$2 bs=1k > /tmp/dd.$$ 2>&1 
rdev $2 $2
###  for 350kB  zImage size
rdev -r $2 16734
echo done
cat /tmp/dd.$$
rm -f /tmp/dd.$$
return 0
fi
return 1
fi
return 1
}

if [ $# -ge 2 ]; then
instt $1 $2 || exit 1
else
if [ $# -ge 1 ]; then
instt /usr/src/linux/arch/i386/boot/zImage $2 || instt ./zImage $2 || \
instt /boot/vmlinuz $2 || exit 1
else
instt /usr/src/linux/arch/i386/boot/zImage /dev/fd0 || \
instt ./zImage /dev/fd0 || instt /boot/vmlinuz /dev/fd0 || \
echo "Usage: mkboot zImage"
fi
fi
