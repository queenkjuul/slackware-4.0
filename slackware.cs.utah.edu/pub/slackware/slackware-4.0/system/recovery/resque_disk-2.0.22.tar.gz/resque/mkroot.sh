#!/bin/sh
function instt
{
if [ -r $1 ]; then
printf "Install $1 on $2 ? [n/y] "
read ans
if [ "$ans" = "y" -o "$ans" = "Y" ]; then
printf "Installing $1 on $2 ..."
dd if=$1 of=$2 bs=1k seek=350 > /tmp/dd.$$ 2>&1 
rdev $2 $2
### for 350kB zImage size
rdev -r $2 16734
echo done
cat /tmp/dd.$$
rm -f /tmp/dd.$$
return 0
fi
return 1
fi
return 1
}

if [ $# -ge 2 ]; then
instt $1 $2 || exit 1
else
if [ $# -ge 1 ]; then
instt $1 /dev/fd0 || exit 1
else
echo "Usage: mkroot ram_image.gz [/dev/fd0]"
fi
fi
