#include "holecp.h"

/* Print usage and die */

void usage ()
{
    fprintf
(stderr,
 "\n"
 "ICCE HoleCopier  V" VER "\n"
 "Copyright (c) K. Kubat / ICCE 1995. All rights reserved.\n"
 "Another MegaHard production!\n"
 "\n"
 "%s by Karel Kubat (karel@icce.rug.nl)\n"
 "\n"
 "Usage: %s [-p -v] infile outfile\n"
 "       %s [-p -v] infile(s) destdir\n"
 "Where:\n"
 "    infile  :  the file to copy\n"
 "    outfile : destination file\n"
 "    destdir : destination directory\n"
 "    -p      : protects destination files, won't overwrite\n"
 "    -v      : verbose mode\n"
 "%s will copy files whilst preserving holes, modes and owner.\n"
 "\n"
 , progname, progname, progname, progname);

    exit (1);
}
