#include <stdarg.h> 
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

#define VER "0.02"

typedef struct			/* program flags */
{
    int verbose: 1;		/* verbosity */
    int dontoverwrite: 1;	/* protect destionation files */
} FLAGS;

extern FLAGS flags;
extern char const *progname;

extern int  copyfiles (char const *inf, char const *outf);
extern void error (char const *fmt, ...);
extern int  file2file (char const *in, char const *out);
extern void getprogname (char const *av0);
extern int  message (char const *fmt, ...);
extern void parseargs (int *ac, char ***av);
extern void usage ();
