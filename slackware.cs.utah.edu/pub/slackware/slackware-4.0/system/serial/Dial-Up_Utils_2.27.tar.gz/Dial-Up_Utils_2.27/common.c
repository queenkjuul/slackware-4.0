#include <stdlib.h>
#include "common.h"

const int		days[12] = { 31, 28, 31, 30, 31, 30,
                                     31, 31, 30, 31, 30, 31 };
const char		*configFilePath = LIB"/dial-up_utils.config";
const char		*userFilePath = LIB"/dial-up_users";
const char		*banFilePath = LIB"/banned_users";

FILE		*userFile;
FILE		*banFile;
int		optReturnDelay;
int		optSendMail;
int		optGuestTime;
int		optGuestPriority;
int		nBootWarnTimes;
int		bootWarnTime[MAX_BOOT_WARN_TIMES];
int		optMaxKick;
int		optSmartBoot;
int		optSessionSmartBoot;
int		optIdleBoot;
int		optIdleSmartBoot;
int		nTimeClasses;
TimeClass	timeClass[MAX_TIME_CLASSES];
int		optTimeClassSmartBoot;
int		nExcluded;
uid_t		excluded[64];
char		modemDial[64] = "\\r\\dATZ\\r\\dATDT";
char		phNoAreaFormat[16] = "3 (3)";
char		phNoLocalFormat[16] = "3-4";
int		phNoDigits;
int		userFileFD, banFileFD;
int		nLines;
dev_t		lineDev[MAX_USERS];
