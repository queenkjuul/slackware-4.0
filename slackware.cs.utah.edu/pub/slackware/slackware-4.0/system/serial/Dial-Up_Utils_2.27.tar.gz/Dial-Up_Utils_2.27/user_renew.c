#include <stdlib.h>
#include "common.h"

void main(int argc, char **argv) {
  int i, optClassRenew = 0, optDataRenew = 0, optTimeRenew = 0;
  UserRec ur;
  processConfig();
  while ((i = getopt(argc, argv, "cdt")) != EOF) {
    switch (i) {
    case 'c': optClassRenew = 1; break;
    case 'd': optDataRenew = 1; break;
    case 't': optTimeRenew = 1; break;
    }
  }
  if (!optClassRenew && !optDataRenew && !optTimeRenew)
    optClassRenew = optDataRenew = optTimeRenew = 1;
  userFileOpen();
  while (!userFileRead(&ur)) {
    int i;
    if (optTimeRenew) {
      ur.tLeft = ur.tLimit;
      ur.sLeft = ur.sLimit;
    }
    if (optClassRenew)
      for (i = 0; i < MAX_TIME_CLASSES; i++)
	ur.cLeft[i] = ur.cLimit[i];
    if (optDataRenew)
      ur.bSession = ur.bTotal = 0;
    userFileEdit(&ur);
  }
  userFileClose();
  exit(0);
}
