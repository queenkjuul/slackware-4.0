#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "common.h"

void main() {
  int expire = 0;
  uid_t uid;
  UserRec ur;
  processConfig();
  uid = geteuid();
  userFileOpen();
  if (!userFileSearch(&ur, uid)) {
    if (ur.expire) {
      expire = 1;
      printf("%.2f day(s) remaining.\n",
             (float) (ur.expire - time(NULL)) / (24 * 60 * 60));
    }
  }
  userFileClose();
  if (!expire) printf("no expiration date!\n");
  exit(0);
}
