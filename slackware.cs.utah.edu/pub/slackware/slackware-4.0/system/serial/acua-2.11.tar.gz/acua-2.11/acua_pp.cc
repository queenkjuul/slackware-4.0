#include "common.h"

int
acua_pp(int argc, char **argv)
{
  uid_t                    uid;
  UserRec                  ur;
  char                     inPath[256];

  readConfig();
  if (argc != 4)
    errQuit("usage: pp <login> <infile> <outfile>");
  uid = UIDfromLogin(argv[1]);
  if (uid == (uid_t)-1)
    errQuit("user does not exist: %s", argv[1]);
  userFileOpen();
  if (userFileSearch(&ur, uid))
    errQuit("user not found: %s", argv[1]);
  if (argv[2][0] == '/') strcpy(inPath, argv[2]);
  else sprintf(inPath, LIB"/%s", argv[2]);
  preprocessFile(&ur, inPath, argv[3]);
  userFileClose();
  return 0;
}
