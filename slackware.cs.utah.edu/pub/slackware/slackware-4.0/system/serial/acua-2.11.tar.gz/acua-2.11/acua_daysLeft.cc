#include <assert.h>
#include "common.h"

int
acua_daysLeft(int argc, char **argv)
{
  int                      expire = 0;
  uid_t                    uid;
  UserRec                  ur;

  argc = argc; argv = argv;
  readConfig();
  uid = geteuid();
  userFileOpen();
  if (!userFileSearch(&ur, uid)) {
    if (ur.expire) {
      expire = 1;
      printf("%.2f day(s) remaining.\n",
       (float) (ur.expire - time(NULL)) / (24 * 60 * 60));
    }
  }
  userFileClose();
  if (!expire)
    printf("no expiration date!\n");
  return 0;
}
