#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <utmp.h>
#include "types.h"
#include "macros.h"
#include "hash.h"

#define ACUA_USERS_MAGIC                "ACUA202"
#define ACUA_USERS_MAGIC_LEN            8
#define MAX_HOSTS                       16
#define MAX_USERS                       256
#define MAX_PROCS                       512
#define MAX_EXPIRE_WARN_TIMES           16
#define MAX_BOOT_WARN_TIMES             16
#define MAX_TIME_CLASSES                16
#define MAX_LOGINCHARS                  8
#define MAX_PPP_UNITS                   MAX_USERS
#define LOCK_EXCLUSIVE                  0
#define LOCK_UNLOCK                     1
#define LOCK_BLOCK                      2
#define FLG_PRIORITY                    0xe000
#define FLG_SMARTTIME                   0x1000
#define FLG_SSMARTTIME                  0x0800
#define FLG_TCSMARTTIME                 0x0400
#define FLG_SMARTBOOT                   0x0200
#define FLG_SSMARTBOOT                  0x0100
#define FLG_TCSMARTBOOT                 0x0080
#define FLG_ISMARTBOOT                  0x0040
#define FLG_EXPIRE                      0x0020
#define FLG_WARNEXPIRE                  0x0010
#define FLG_WARNBOOT                    0x0008
#define FLG_EXPLAINBOOT                 0x0004
#define FLG_LOCK                        0x0001
#define PRIORITY(f)                     (((f) & FLG_PRIORITY) >> 13)
#define SMARTTIME(f)                    ((f) & FLG_SMARTTIME)
#define SSMARTTIME(f)                   ((f) & FLG_SSMARTTIME)
#define TCSMARTTIME(f)                  ((f) & FLG_TCSMARTTIME)
#define SMARTBOOT(f)                    ((f) & FLG_SMARTBOOT)
#define SSMARTBOOT(f)                   ((f) & FLG_SSMARTBOOT)
#define TCSMARTBOOT(f)                  ((f) & FLG_TCSMARTBOOT)
#define ISMARTBOOT(f)                   ((f) & FLG_ISMARTBOOT)
#define EXPIRE(f)                       ((f) & FLG_EXPIRE)
#define WARNEXPIRE(f)                   ((f) & FLG_WARNEXPIRE)
#define WARNBOOT(f)                     ((f) & FLG_WARNBOOT)
#define EXPLAINBOOT(f)                  ((f) & FLG_EXPLAINBOOT)
#define LOCK(f)                         ((f) & FLG_LOCK)
#define EXPIRE_DELETE                   0x0000
#define EXPIRE_UNSUBSCRIBE              0x0020

typedef struct {
  uid_t         uid                             __attribute__((packed));
  word          flags                           __attribute__((packed));
  word          phNoArea                        __attribute__((packed));
  word          phNoLocal                       __attribute__((packed));
  byte          nHosts                          __attribute__((packed));
  word          host[MAX_HOSTS]                 __attribute__((packed));
  byte          nLogins[MAX_HOSTS]              __attribute__((packed));
  time_t        lastLogin[MAX_HOSTS]            __attribute__((packed));
  time_t        lastOnline[MAX_HOSTS]           __attribute__((packed));
  word          maxLogins                       __attribute__((packed));
  word          maxDeduct                       __attribute__((packed));
  int           idleLimit                       __attribute__((packed));
  int           PPPidleMinutes                  __attribute__((packed));
  word          PPPidleBytes                    __attribute__((packed));
  int           tLeft                           __attribute__((packed));
  int           tLimit                          __attribute__((packed));
  int           credit                          __attribute__((packed));
  int           sLeft                           __attribute__((packed));
  int           sLimit                          __attribute__((packed));
  int           cLeft[MAX_TIME_CLASSES]         __attribute__((packed));
  int           cLimit[MAX_TIME_CLASSES]        __attribute__((packed));
  dword         bTx                             __attribute__((packed));
  dword         bRx                             __attribute__((packed));
  dword         bTxLimit                        __attribute__((packed));
  dword         bRxLimit                        __attribute__((packed));
  dword         bLimit                          __attribute__((packed));
  dword         bStx                            __attribute__((packed));
  dword         bSrx                            __attribute__((packed));
  dword         bStxLimit                       __attribute__((packed));
  dword         bSrxLimit                       __attribute__((packed));
  dword         bSlimit                         __attribute__((packed));
  word          nBytes[60]                      __attribute__((packed));
  time_t        lockDate                        __attribute__((packed));
  time_t        subscrDate                      __attribute__((packed));
  time_t        subExpire                       __attribute__((packed));
  word          subFlags                        __attribute__((packed));
  word          subMaxLogins                    __attribute__((packed));
  word          subMaxDeduct                    __attribute__((packed));
  int           subIdleLimit                    __attribute__((packed));
  int           subPPPidleMinutes               __attribute__((packed));
  word          subPPPidleBytes                 __attribute__((packed));
  int           subTlimit                       __attribute__((packed));
  int           subCredit                       __attribute__((packed));
  int           subSlimit                       __attribute__((packed));
  int           subClimit[MAX_TIME_CLASSES]     __attribute__((packed));
  dword         subBtxLimit                     __attribute__((packed));
  dword         subBrxLimit                     __attribute__((packed));
  dword         subBlimit                       __attribute__((packed));
  dword         subBStxLimit                    __attribute__((packed));
  dword         subBSrxLimit                    __attribute__((packed));
  dword         subBSlimit                      __attribute__((packed));
  word          tMinutes                        __attribute__((packed));
  time_t        creation                        __attribute__((packed));
  time_t        expire                          __attribute__((packed));
} UserRec;      /* sizeof(UserRec) = 885 */

typedef struct {
  time_t        startTime;
  time_t        expire;
  word          nMinutes[24 * 60];
  word          linesBusy[24 * 60];
  word          sessionLength[24 * 60];
} UsageRec;

typedef struct {
  byte          flags                           __attribute__((packed));
  word          phNoArea                        __attribute__((packed));
  word          phNoLocal                       __attribute__((packed));
  time_t        expire                          __attribute__((packed));
} BanRec;

typedef struct {
  pid_t         pid;
  uid_t         uid,
                euid;
  dev_t         tty;
  char          name[16];
} ProcRec;

typedef struct {
  uid_t         uid;
  dev_t         tty;
  char          ttyName[12];
  time_t        time;
} LoginRec;

typedef struct {
  int           startDay,
                endDay;
  int           startHour,
                startMin,
                endHour,
                endMin;
} TimeClass;

typedef struct PPPuserRec {
  uid_t         uid;
  Boolean       root;
  pid_t         pid;
  int           unit;
  dev_t         tty;
  time_t        loginTime;
} PPPuserRec;

extern int               acua_addRec(int argc, char **argv);
extern int               acua_ban(int argc, char **argv);
extern int               acua_daysLeft(int argc, char **argv);
extern int               acua_delRec(int argc, char **argv);
extern int               acua_dump(int argc, char **argv);
extern int               acua_dumpStats(int argc, char **argv);
extern int               acua_expire(int argc, char **argv);
extern int               acua_forEach(int argc, char **argv);
extern int               acua_kickUser(int argc, char **argv);
extern int               acua_lock(int argc, char **argv);
extern int               acua_modRec(int argc, char **argv);
extern int               acua_purge(int argc, char **argv);
extern int               acua_renew(int argc, char **argv);
extern int               acua_subscribe(int argc, char **argv);
extern int               acua_sync(int argc, char **argv);
extern int               acua_touch(int argc, char **argv);
extern int               acua_unBan(int argc, char **argv);
extern int               acua_unLock(int argc, char **argv);
extern int               acua_unSubscribe(int argc, char **argv);
extern int               acua_pp(int argc, char **argv);
extern int               acua_timeLeft(int argc, char **argv);

extern void              errQuit(char *format,...);
extern void              perrQuit(char *format,...);
extern dev_t             devNumFromName(char *devName);
extern int               lineNo(dev_t dev);
extern int               runCommand(char *path,...);
extern int               runCommandV(char *path, char **arg);
extern void              daemonInit();
extern time_t            addTime(time_t t, char *s);
extern void              procList(int *nProcs, ProcRec *procRec);
extern int               nKick(int nProcs, ProcRec *procRec);
extern void              userList(int *nLogins, LoginRec *loginRec);
extern time_t            lastLogin(UserRec *ur);
extern time_t            lastOnline(UserRec *ur);
extern void              addHost(UserRec *ur, word host);
extern int               findHost(UserRec *ur, word host);
extern void              removeHost(UserRec *ur, word host);
extern word              nLogins(UserRec *ur);
extern word              nLogins(HashTable *loginRec, uid_t uid);
extern int               userLoggedIn(int nLogins, LoginRec *loginRec, uid_t uid);
extern int               getToken(char *d, char *s, int *idx);
extern uid_t             UIDfromLogin(char *login);
extern char             *loginFromUID(char *login, uid_t uid);
extern void              userFileOpen();
extern void              userFileClose();
extern int               userFileRead(UserRec *ur);
extern int               userFileWrite(UserRec *ur);
extern void              userFileEdit(UserRec *ur);
extern int               userFileSearch(UserRec *ur, uid_t uid);
extern void              userFileRewind();
extern void              banFileOpen();
extern void              banFileClose();
extern int               banFileRead(BanRec *br);
extern int               banFileWrite(BanRec *br);
extern int               banFileSearch(BanRec *br, word phNoArea, word phNoLocal);
extern int               phNo2Words(word *phNoArea, word *phNoLocal, char *phNo, int phNoDigits);
extern char             *words2PhNo(char *phNo, word phNoArea, word phNoLocal);
extern int               stringSum(char *s);
extern void              bytes2ASCII(char *str, dword bytes);
extern int               inTimeClass(int tc);
extern int               curTimeClass(UserRec *ur);
extern int               fLock(char *path, int operation);
extern void              preprocessFile(UserRec *ur, char *inPath, char *outPath);
extern void              hhmm(char *s, int nMinutes);
extern void              PPPfindUnits(HashTable *PPPuser, HashTable *loginRecTable, HashTable *procRecTable);
extern word              hostAddr(char *hostname);
extern word              UIDhash(word size, void *key);
extern int               UIDcomp(void *p1, void *p2);
extern word              PIDhash(word size, void *key);
extern int               PIDcomp(void *p1, void *p2);
extern word              TTYhash(word size, void *key);
extern int               TTYcomp(void *p1, void *p2);
extern void              readConfig();

extern const int         days[12];
extern char             *configFilePath;
extern char             *userFilePath;
extern FILE             *userFile;
extern char             *banFilePath;
extern FILE             *banFile;
extern int               optPurgeDays;
extern int               optMinDeduct;
extern int               optBusyThreshold;
extern int               optMaxKick;
extern int               optLowCPUpriority,
                         optHighCPUpriority;
extern int               optReturnDelay;
extern int               optGuestTime;
extern int               optGuestPriority;
extern char              optMailHost[64];
extern int               optExplainBoot;
extern int               nBootWarnTimes;
extern int               bootWarnTime[MAX_BOOT_WARN_TIMES];
extern int               optPPPWarnBoot;
extern int               nExpireWarnTimes;
extern int               expireWarnTime[MAX_EXPIRE_WARN_TIMES];
extern char              optWarnExpireCC[64];
extern int               optIdleLimit;
extern int               optPPPidleMinutes;
extern int               optPPPidleBytes;
extern int               optSmartTime;
extern int               optSessionSmartTime;
extern int               optTimeClassSmartTime;
extern int               optSmartBoot;
extern int               optSessionSmartBoot;
extern int               optTimeClassSmartBoot;
extern int               optIdleSmartBoot;
extern int               nTimeClasses;
extern TimeClass         timeClass[MAX_TIME_CLASSES];
extern int               nExcluded;
extern uid_t             excluded[64];
extern char              optModemDial[64];
extern char              optPhNoAreaFormat[16];
extern char              optPhNoLocalFormat[16];
extern int               optPhNoDigits;
extern int               userFileFD,
                         banFileFD;
extern int               nLines;
extern dev_t             lineDev[MAX_USERS];

#endif
