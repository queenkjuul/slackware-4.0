#include <assert.h>
#include <pwd.h>
#include <sys/stat.h>
#include "common.h"

int
acua_delRec(int argc, char **argv)
{
  int                      i,
                           n;
  uid_t                    uid;
  UserRec                  ur;
  char                     tUserPath[16];
  FILE                    *tUserFile;

  readConfig();
  if (argc != 2)
    errQuit("usage: delRec <login>");
  uid = UIDfromLogin(argv[1]);
  if (uid == (uid_t) - 1)
    errQuit("user does not exist: %s", argv[1]);
  userFileOpen();
  if (userFileSearch(&ur, uid))
    errQuit("user not found: %s", argv[1]);
  strcpy(tUserPath, "/tmp/XXXXXX");
  mktemp(tUserPath);
  tUserFile = fopen(tUserPath, "wb");
  assert(tUserFile != NULL);
  fwrite(ACUA_USERS_MAGIC, 1, ACUA_USERS_MAGIC_LEN, tUserFile);
  n = ftell(userFile) / sizeof(UserRec) - 1;
  userFileRewind();
  for (i = 0;; i++) {
    if (userFileRead(&ur))
      break;
    if (i == n)
      continue;
    fwrite(&ur, sizeof(UserRec), 1, tUserFile);
  }
  fclose(tUserFile);
  runCommand("/bin/mv", "-f", tUserPath, userFilePath, NULL);
  chmod(userFilePath, 0644);
  userFileClose();
  printf("user deleted: %s\n", argv[1]);
  return 0;
}
