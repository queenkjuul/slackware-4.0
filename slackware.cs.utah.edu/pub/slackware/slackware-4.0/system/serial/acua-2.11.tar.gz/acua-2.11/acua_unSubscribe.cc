#include <assert.h>
#include "common.h"

int
acua_unSubscribe(int argc, char **argv)
{
  int                      i;
  uid_t                    uid;
  UserRec                  ur;

  readConfig();
  if (argc != 2)
    errQuit("usage: unsubscribe <login>");
  uid = UIDfromLogin(argv[1]);
  if (uid == (uid_t) - 1)
    errQuit("user does not exist: %s", argv[1]);
  userFileOpen();
  if (userFileSearch(&ur, uid))
    errQuit("user not found: %s", argv[1]);
  if (EXPIRE(ur.flags) != EXPIRE_UNSUBSCRIBE)
    errQuit("user does not have a subscription: %s", argv[1]);
  time(&ur.subscrDate);
  ur.flags = ur.subFlags;
  ur.maxLogins = ur.subMaxLogins;
  ur.maxDeduct = ur.subMaxDeduct;
  ur.idleLimit = ur.subIdleLimit;
  ur.PPPidleMinutes = ur.subPPPidleMinutes;
  ur.PPPidleBytes = ur.subPPPidleBytes;
  ur.expire = ur.subExpire;
  ur.tLimit = ur.tLeft = ur.subTlimit;
  ur.credit = ur.subCredit;
  ur.sLimit = ur.sLeft = ur.subSlimit;
  for (i = 0; i < MAX_TIME_CLASSES; i++) {
    ur.cLeft[i] = ur.cLimit[i] = ur.subClimit[i];
    if (ur.cLimit[i] == -1) ur.cLeft[i] = 0;
  }
  ur.bTxLimit = ur.subBtxLimit;
  ur.bRxLimit = ur.subBrxLimit;
  ur.bLimit = ur.subBlimit;
  ur.bStxLimit = ur.subBStxLimit;
  ur.bSrxLimit = ur.subBSrxLimit;
  ur.bSlimit = ur.subBSlimit;
  userFileEdit(&ur);
  userFileClose();
  printf("user unsubscribed: %s\n", argv[1]);
  return 0;
}
