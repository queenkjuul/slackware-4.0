#include <time.h>
#include "common.h"

static int               userExpire();
static int               banExpire();

int
acua_expire(int argc, char **argv)
{
  argc = argc; argv = argv;
  readConfig();
  while (!userExpire());
  while (!banExpire());
  return 0;
}

int
userExpire()
{
  time_t                   t;
  char                     login[9];
  UserRec                  ur;

  userFileOpen();
  time(&t);
  while (!userFileRead(&ur)) {
    if (ur.expire && t >= ur.expire) {
      if (!loginFromUID(login, ur.uid)) continue;
      userFileClose();
      if (EXPIRE(ur.flags) == EXPIRE_DELETE)
        runCommand(BIN"/acua", "delUser", login, NULL);
      else
        runCommand(BIN"/acua", "unSubscribe", login, NULL);
      return 0;
    }
  }
  userFileClose();
  return 1;
}

int
banExpire()
{
  time_t                   t;
  BanRec                   br;
  char                     phNo[32];

  banFileOpen();
  time(&t);
  while (!banFileRead(&br)) {
    if (br.expire && t >= br.expire) {
      banFileClose();
      runCommand(BIN"/acua", "unBan", words2PhNo(phNo, br.phNoArea, br.phNoLocal), NULL);
      return 0;
    }
  }
  banFileClose();
  return 1;
}
