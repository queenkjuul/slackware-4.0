#ifndef TYPES_H
#define TYPES_H

#include <sys/types.h>

typedef unsigned char           byte;
typedef unsigned int            word;
typedef unsigned long long      dword;
#undef FALSE
#undef TRUE
typedef enum { FALSE, TRUE }    Boolean;

typedef int                     (*CompFn) (void *p1, void *p2);

#endif
