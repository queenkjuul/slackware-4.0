#include <assert.h>
#include <ctype.h>
#include <sys/wait.h>
#include "common.h"

static int               purgeUser(int days);

int
acua_purge(int argc, char **argv)
{
  int                      days;

  readConfig();
  if (argc != 2)
    errQuit("usage: purge <days>");
  days = atoi(argv[1]);
  if (days < 14)
    errQuit("<days> must be >= 14.");
  while (!purgeUser(days));
  return 0;
}

int
purgeUser(int days)
{
  time_t                   t;
  char                     login[9];
  UserRec                  ur;

  userFileOpen();
  time(&t);
  while (!userFileRead(&ur)) {
    time_t lastOnlineTime = lastOnline(&ur);
    if ((t - lastOnlineTime) / (24 * 60 * 60) >= days) {
      if (!loginFromUID(login, ur.uid)) continue;
      userFileClose();
      runCommand(SBIN"/acua_deluser", login, NULL);
      return 0;
    }
  }
  userFileClose();
  return 1;
}
