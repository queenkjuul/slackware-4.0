#include "common.h"

int
acua_lock(int argc, char **argv)
{
  uid_t                    uid;
  UserRec                  ur;

  readConfig();
  if (argc < 2)
    errQuit("usage: lock <login>");
  uid = UIDfromLogin(argv[1]);
  if (uid == (uid_t) - 1)
    errQuit("user does not exist: %s", argv[1]);
  userFileOpen();
  if (userFileSearch(&ur, uid))
    errQuit("user not found: %s", argv[1]);
  if (LOCK(ur.flags))
    errQuit("user is already locked: %s", argv[1]);
  ur.flags |= FLG_LOCK;
  time(&ur.lockDate);
  userFileEdit(&ur);
  userFileClose();
  printf("user locked: %s\n", argv[1]);
  return 0;
}
