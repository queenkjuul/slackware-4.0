#include <arpa/inet.h>
#include <assert.h>
#include <ctype.h>
#include <fcntl.h>
#include <limits.h>
#include <net/if_ppp.h>
#include <linux/ppp_defs.h>
#include <math.h>
#include <pwd.h>
#include <signal.h>
#include <string.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/ioctl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <syslog.h>
#include <utime.h>
#include "common.h"

#define PUNT_BUSY               0
#define PUNT_DATA_PERIOD        1
#define PUNT_DATA_SESSION       2
#define PUNT_TIME_IDLE          3
#define PUNT_TIME_CLASS         4
#define PUNT_TIME_PERIOD        5
#define PUNT_TIME_SESSION       6
#define USAGE_TOTAL             0
#define USAGE_DAY               1
#define USAGE_WEEK              2
#define USAGE_MONTH             3
#define USAGE_YEAR              4

typedef struct VictimRec {
  UserRec               ur;
  dev_t                 tty;
  char                  ttyName[12];
  int                   reason;
  int                   sLeft;
  int                   sendMail;
} VictimRec;

void                     update();
char                    *userTTY(char *ttyPath, int uid, PPPuserRec *PPPuser);
void                     userMessage(char *ttyName, char *format,...);
void                     sendMail(UserRec *ur, char *login, char *cc,
                                  char *subject, char *sPath, char *dPath);
int                      PPPidleLeft(UserRec *ur, time_t loginTime);
int                      TTYidleLeft(UserRec *ur);
void                     PPPupdate(UserRec *ur, int unit, time_t loginTime);
int                      warnExpire(time_t expire);
int                      CPUpriority(int priority);
int                      victimCmp(const VictimRec *v1, const VictimRec *v2);
void                     readUsageRecords();
void                     writeUsageRecords(int curMinute);
void                     unlinkOldLockFiles();

const char              *msgTimeWarning = "You have %d minute(s) remaining.";
const char              *msgIdleWarning = "You will be logged out after 1 more minute of idle time.";
const char              *msgPath[7] = { LIB"/acua_updated.busy",
                                        LIB"/acua_updated.data_period",
                                        LIB"/acua_updated.data_session",
                                        LIB"/acua_updated.idle",
                                        LIB"/acua_updated.time_class",
                                        LIB"/acua_updated.time_period",
                                        LIB"/acua_updated.time_session" };
const char              *puntReason[7] = { "system busy",
                                           "data limit exceeded",
                                           "session data limit exceeded",
                                           "idle time limit exceeded",
                                           "class time limit exceeded",
                                           "time limit exceeded",
                                           "session time limit exceeded" };
const char              *usageRecExpire[5] = { "", "1d", "7d", "1m", "12m" };
const char              *usageRecName[5] = { "overall",
                                             "day",
                                             "week",
                                             "month",
                                             "year" };

word                     myHostAddr;
int                      automatic = 1,
                         runAsDaemon = 1,
                         effect = 1,
                         loggingLevel = 1;
time_t                   configTime;
int                      systemBusy;
int                      nLoginRecs;
LoginRec                 loginRec[MAX_USERS];
int                      nProcs;
ProcRec                  procRec[MAX_PROCS];
uid_t                    guestUID;
HashTable                PPPuserTable;
HashTable                loginRecTable;
HashTable                loginRecTable_TTY;
HashTable                procRecTable;
HashTable                procRecTable_EUID;
HashTable                procRecTable_PID;
UsageRec                 usageRec[5];

int
main(int argc, char **argv)
{
  int                      i;
  struct stat              _stat;
  time_t                   t;
  struct tm               *tmP;
  char                     hostname[256];
  struct in_addr           _in_addr;

  readConfig();
  configTime = time(NULL);
  while ((i = getopt(argc, argv, "adel")) != EOF) {
    switch (i) {
    case 'a':
      automatic = 0;
      break;
    case 'd':
      runAsDaemon = 0;
      break;
    case 'e':
      effect = 0;
      break;
    case 'l':
      loggingLevel = atoi(argv[optind++]);
      break;
    }
  }
  
  if (runAsDaemon)
    daemonInit();
  openlog("acua_updated", LOG_PID, LOG_DAEMON);
  guestUID = UIDfromLogin("guest");
  gethostname(hostname, 256); myHostAddr = hostAddr(hostname);
  
  _in_addr.s_addr = myHostAddr;
  if (loggingLevel >= 1)
    syslog(LOG_INFO, "hostname = %s, IP = %s",
           hostname,
           inet_ntoa(_in_addr));

  for (;;) {
    // re-read the config file if it's been updated
    if (stat(configFilePath, &_stat) < 0)
      perrQuit("couldn't stat %s", configFilePath);
    if (_stat.st_mtime > configTime) {
      readConfig();
      if (configTime && loggingLevel >= 1)
        syslog(LOG_INFO, "re-read %s", configFilePath);
      configTime = _stat.st_mtime;
    }

    // do sync, purge, expire
    time(&t);
    tmP = localtime(&t);
    if (tmP->tm_min == 0) {
      unlinkOldLockFiles();
    }
    if (automatic && (tmP->tm_hour == 3)) {
      char *_argv[16] = { "acua", NULL, NULL };
      char arg[16];
      switch (tmP->tm_min) {
      case 0:
        acua_sync(1, _argv);
        break;
      case 1:
        if (optPurgeDays >= 14) {
          sprintf(arg, "%d", optPurgeDays);
          _argv[1] = arg;
          acua_purge(2, _argv);
          _argv[1] = NULL;
        }
        break;
      case 2:
        acua_expire(1, _argv);
        break;
      }
    }

    // do the update
    update();

    // back to sleep...
    time(&t);
    tmP = localtime(&t);
    sleep(60 - tmP->tm_sec);
  }
  return 0;
}

void
update()
{
  char                     login[MAX_LOGINCHARS + 1],
                           ttyPath[32],
                           dPath[256];
  int                      i,
                           nOnline = 0,
                           idleLeft,
                           sLeft,
                           sessionLength,
                           curClass,
                           deductMins,
                           deductTime,
                           deductSession,
                           puntDataPeriod,
                           puntDataSession,
                           nKill = 0,
                           nVictims,
                           curMinute;
  struct stat              _stat;
  VictimRec                victim[MAX_USERS];
  UserRec                  ur;
  LoginRec                *curLogin;
  ProcRec                 *curProc;
  pid_t                    killPID[MAX_PROCS];
  PPPuserRec              *PPPuser;
  time_t                   t;
  struct tm               *tmP;
  word                     nUserLogins;
  int                      hostIdx;

  time(&t);
  tmP = localtime(&t);
  curMinute = tmP->tm_hour * 60 + tmP->tm_min;

  nVictims = 0;
  userList(&nLoginRecs, loginRec);
  procList(&nProcs, procRec);
  systemBusy = nKick(nProcs, procRec);

  hashTableInit(&loginRecTable, MAX_USERS, UIDhash, UIDcomp, 0, FALSE);
  for (i = 0; i < nLoginRecs; i++)
    hashTableAdd(&loginRecTable, &loginRec[i]);

  hashTableInit(&loginRecTable_TTY, MAX_USERS, TTYhash, TTYcomp,
    (word)&loginRec[0].tty - (word)&loginRec[0], FALSE);
  for (i = 0; i < nLoginRecs; i++)
    hashTableAdd(&loginRecTable_TTY, &loginRec[i]);

  hashTableInit(&procRecTable, MAX_PROCS, UIDhash, UIDcomp,
    (word)&procRec[0].uid - (word)&procRec[0], FALSE);
  for (i = 0; i < nProcs; i++)
    hashTableAdd(&procRecTable, &procRec[i]);

  hashTableInit(&procRecTable_EUID, MAX_PROCS, UIDhash, UIDcomp,
    (word)&procRec[0].euid - (word)&procRec[0], FALSE);
  for (i = 0; i < nProcs; i++)
    hashTableAdd(&procRecTable_EUID, &procRec[i]);

  hashTableInit(&procRecTable_PID, MAX_PROCS, PIDhash, PIDcomp, 0, FALSE);
  for (i = 0; i < nProcs; i++)
    hashTableAdd(&procRecTable_PID, &procRec[i]);

  PPPfindUnits(&PPPuserTable, &loginRecTable_TTY, &procRecTable_PID);

  userFileOpen();
  readUsageRecords();
  while (!userFileRead(&ur)) {
    // make sure the user has a passwd entry
    if (!loginFromUID(login, ur.uid)) continue;
    
    // warn users when their accounts/subscriptions are almost expired
    if (ur.expire) {
      if (WARNEXPIRE(ur.flags) && !warnExpire(ur.expire)) {
        ur.flags &= ~FLG_WARNEXPIRE;
        userFileEdit(&ur);
      } else if (!WARNEXPIRE(ur.flags) && warnExpire(ur.expire)) {
        char subject[64];
        char cc[64] = "";

        // set the subject
        if (EXPIRE(ur.flags) == EXPIRE_DELETE)
          strcpy(subject, "Account Expires Soon");
        else
          strcpy(subject, "Subscription Expires Soon");

        // set the CC string
        if (optWarnExpireCC[0] != '\0') {
          sprintf(cc, "-c %s ", optWarnExpireCC);
        }

        // send the e-mail
        sprintf(dPath, "/tmp/acua_updated.%d", (int)getpid());
        sendMail(&ur, login, cc, subject, LIB"/acua_updated.warn_expire", dPath);
        ur.flags |= FLG_WARNEXPIRE;
      }
    }

    // clear out any hosts the user has no session to
    for (i = 0; i < ur.nHosts; i++) {
      if ((time(NULL) > ur.lastOnline[i]) &&
          ((time(NULL) - ur.lastOnline[i])) > 600)
      {
        removeHost(&ur, ur.host[i]);
        i = -1;
      }
    }

    hostIdx = findHost(&ur, myHostAddr);

    // make sure this host is in ur.host[]
    if (hostIdx < 0) {
      userFileEdit(&ur);
      continue;
    }

    // set nLogins for this host
    ur.nLogins[hostIdx] = nLogins(&loginRecTable, ur.uid);

    // find PPP record (the user may have a PPP record, and yet own no processes!)
    PPPuser = (PPPuserRec*)hashTableSearch(&PPPuserTable, &ur.uid);
    if (PPPuser)
      goto found;

    // set the CPU priority, see if they have any processes
    curProc = (ProcRec*)hashTableSearch(&procRecTable, &ur.uid);
    if (curProc)
      setpriority(PRIO_USER, ur.uid, CPUpriority(PRIORITY(ur.flags)));
    // look for processes with matching uid
    while (curProc) {
      if (lineNo(curProc->tty) >= 0)
        goto found;
      curProc = (ProcRec*)hashTableSearchNext(&procRecTable, &ur.uid);
    }
    // look for processes with matching euid
    curProc = (ProcRec*)hashTableSearch(&procRecTable_EUID, &ur.uid);
    while (curProc) {
      if (lineNo(curProc->tty) >= 0)
        goto found;
      curProc = (ProcRec*)hashTableSearchNext(&procRecTable_EUID, &ur.uid);
    }

    // user is not online anymore -- record stats and remove this host from ur.host[]
    sessionLength = (t - ur.lastLogin[hostIdx]) / 60;
    if (sessionLength < optMinDeduct)
    {
      ur.tLeft -= (optMinDeduct - sessionLength);
      ur.sLeft = ur.sLimit - optMinDeduct;
    }
    if (sessionLength < 24 * 60)
      for (i = 0; i < 5; i++)
        usageRec[i].sessionLength[sessionLength]++;
    removeHost(&ur, myHostAddr);
    userFileEdit(&ur);
    continue;
    
found:
    // increment tMinutes for this user
    ur.tMinutes++;

    nOnline += ur.nLogins[hostIdx];
    if (!userTTY(ttyPath, ur.uid, PPPuser))
      continue;
    curClass = curTimeClass(&ur);
    if (PPPuser)
      PPPupdate(&ur, PPPuser->unit, PPPuser->loginTime);
    nUserLogins = nLogins(&loginRecTable, ur.uid);

    // update their record
    deductMins = min(ur.nLogins[hostIdx], ur.maxDeduct);
    deductTime = deductSession = 1;
    if (SMARTTIME(ur.flags) && !systemBusy)
      deductTime = 0;
    if (SSMARTTIME(ur.flags) && !systemBusy)
      deductSession = 0;
    for (i = 0; i < nTimeClasses; i++) {
      if (inTimeClass(i)) {
        if (ur.cLimit[i] <= -3)
          deductTime = 0;
        if (ur.cLimit[i] <= -2)
          deductSession = 0;
        if (ur.cLimit[i] >= 0 && (!TCSMARTTIME(ur.flags) || systemBusy))
          ur.cLeft[i] -= deductMins;
      }
    }
    if (deductTime)
      ur.tLeft -= deductMins;
    if (deductSession)
      ur.sLeft -= deductMins;
    time(&ur.lastOnline[hostIdx]);
    if (effect)
      userFileEdit(&ur);

    // figure out how much time they have left
    sLeft = INT_MAX;
    if ((!SMARTBOOT(ur.flags) || systemBusy) && ur.tLimit >= 0)
      sLeft = min(sLeft, ur.tLeft + ur.credit);
    if ((!SSMARTBOOT(ur.flags) || systemBusy) && ur.sLimit >= 0)
      sLeft = min(sLeft, ur.sLeft);
    if ((!TCSMARTBOOT(ur.flags) || systemBusy) && curClass >= 0 && ur.cLimit[curClass] >= 0)
      sLeft = min(sLeft, ur.cLeft[curClass]);
    if (!PRIORITY(ur.flags) && systemBusy)
      sLeft = min(sLeft, -(int)(time(NULL) - ur.lastLogin[hostIdx]));

    // figure out how much idle time they have left
    idleLeft = INT_MAX;
    if (PPPuser && ur.PPPidleBytes && ur.PPPidleMinutes) {
      idleLeft = PPPidleLeft(&ur, PPPuser->loginTime);
    } else if (!PPPuser && ur.idleLimit > 0) {
      idleLeft = TTYidleLeft(&ur);
    }

    // send a warning message if necessary
    if (effect && WARNBOOT(ur.flags) && PPPuser) {
      if ((optPPPWarnBoot > 0) && (sLeft == optPPPWarnBoot)) {
        char subject[64];

        // set the subject
        sprintf(subject, "Warning: possible disconnection within %d minutes", optPPPWarnBoot);

        // send the e-mail
        sprintf(dPath, "/tmp/acua_updated.%d", (int)getpid());
        sendMail(&ur, login, "", subject, LIB"/acua_updated.warn_boot", dPath);
      }
    } else if (effect && WARNBOOT(ur.flags) && !PPPuser) {
      if (idleLeft == 1 && sLeft > 1)
        userMessage(ttyPath + 5, (char *) msgIdleWarning);
      else if (deductTime || deductSession)
        for (i = 0; i < nBootWarnTimes; i++)
          if (sLeft == bootWarnTime[i]) {
            userMessage(ttyPath + 5, (char *) msgTimeWarning, sLeft);
            break;
          }
    }

    // take idle time into account
    if (!ISMARTBOOT(ur.flags) || systemBusy)
      sLeft = min(sLeft, idleLeft);
    
    puntDataPeriod = (ur.bLimit && ur.bTx + ur.bRx > ur.bLimit) ||
                     (ur.bTxLimit && ur.bTx > ur.bTxLimit) ||
                     (ur.bRxLimit && ur.bRx > ur.bRxLimit);
    puntDataSession = (ur.bSlimit && ur.bStx + ur.bSrx > ur.bSlimit) ||
                      (ur.bStxLimit && ur.bStx > ur.bStxLimit) ||
                      (ur.bSrxLimit && ur.bSrx > ur.bSrxLimit);

    // victimize this user if necessary
    if (sLeft <= 0 || puntDataPeriod || puntDataSession) {
      memcpy(&victim[nVictims].ur, &ur, sizeof(UserRec));
      victim[nVictims].tty = devNumFromName(ttyPath + 5);
      strcpy(victim[nVictims].ttyName, ttyPath + 5);
      victim[nVictims].sLeft = sLeft;
      if ((ur.tLimit >= 0) && (ur.tLeft <= 0))
        victim[nVictims].reason = PUNT_TIME_PERIOD;
      else if ((ur.sLimit >= 0) && (ur.sLeft <= 0))
        victim[nVictims].reason = PUNT_TIME_SESSION;
      else if ((curClass >= 0) && (ur.cLimit[curClass] >= 0) && (ur.cLeft[curClass] <= 0))
        victim[nVictims].reason = PUNT_TIME_CLASS;
      else if (idleLeft <= 0)
        victim[nVictims].reason = PUNT_TIME_IDLE;
      else if (puntDataPeriod)
        victim[nVictims].reason = PUNT_DATA_PERIOD;
      else if (puntDataSession)
        victim[nVictims].reason = PUNT_DATA_SESSION;
      else
        victim[nVictims].reason = PUNT_BUSY;
      victim[nVictims++].sendMail = EXPLAINBOOT(ur.flags) && ur.tLimit > 0;
    }
  }
  for (i = 0; i < 5; i++)
    usageRec[i].linesBusy[curMinute] += nOnline;
  writeUsageRecords(curMinute);
  userFileClose();

  // update guest users
  curLogin = (LoginRec*)hashTableSearch(&loginRecTable, &guestUID);
  while (curLogin) {
    sprintf(ttyPath, "/dev/%s", curLogin->ttyName);
    sLeft = optGuestTime * 60 - (time(NULL) + 5 - curLogin->time);
    if (sLeft > -60 && sLeft < 0)
      sLeft = -60;
    sLeft = sLeft / 60 + 1;
    if (!optGuestPriority && systemBusy)
      sLeft = min(sLeft, -(optGuestTime - sLeft));
    if (optIdleLimit) {
      if (stat(ttyPath, &_stat))
        continue;
      idleLeft = optIdleLimit * 60 - (time(NULL) - _stat.st_mtime);
      if (idleLeft < 0)
        idleLeft = 0;
      else
        idleLeft = idleLeft / 60 + 1;
    } else
      idleLeft = INT_MAX;
    if (effect) {
      if (idleLeft == 1 && sLeft > 1)
        userMessage(curLogin->ttyName, (char*)msgIdleWarning);
      else
        for (i = 0; i < nBootWarnTimes; i++)
          if (sLeft == bootWarnTime[i]) {
            userMessage(curLogin->ttyName, (char*)msgTimeWarning, sLeft);
            break;
          }
    }

    // take idle time into account
    if (!optIdleSmartBoot || systemBusy)
      sLeft = min(sLeft, idleLeft);
    if (sLeft <= 0) {
      victim[nVictims].ur.uid = guestUID;
      victim[nVictims].tty = curLogin->tty;
      strcpy(victim[nVictims].ttyName, curLogin->ttyName);
      victim[nVictims].ur.flags = optGuestPriority << 13;
      victim[nVictims].sLeft = sLeft;
      if (idleLeft <= 0)
        victim[nVictims].reason = PUNT_TIME_IDLE;
      else if (sLeft <= 0)
        victim[nVictims].reason = PUNT_TIME_SESSION;
      else
        victim[nVictims].reason = PUNT_BUSY;
      victim[nVictims++].sendMail = FALSE;
    }
    curLogin = (LoginRec*)hashTableSearchNext(&loginRecTable, &guestUID);
  }

  // select victims
  if (optMaxKick && systemBusy && nVictims > systemBusy) {
    qsort(victim, nVictims, sizeof(VictimRec), (int (*)(const void *, const void *)) victimCmp);
    nVictims = systemBusy;
  }

  // create process list
  for (i = 0; i < nVictims; i++) {
    curProc = (ProcRec*)hashTableSearch(&procRecTable, &victim[i].ur.uid);
    while (curProc) {
      if (victim[i].ur.uid != guestUID || curProc->tty == victim[i].tty)
        killPID[nKill++] = curProc->pid;
      curProc = (ProcRec*)hashTableSearchNext(&procRecTable, &victim[i].ur.uid);
    }
    curProc = (ProcRec*)hashTableSearch(&procRecTable_EUID, &victim[i].ur.uid);
    while (curProc) {
      if ((victim[i].ur.uid != guestUID || curProc->tty == victim[i].tty) &&
          curProc->uid != victim[i].ur.uid)
        killPID[nKill++] = curProc->pid;
      curProc = (ProcRec*)hashTableSearchNext(&procRecTable_EUID, &victim[i].ur.uid);
    }
    PPPuser = (PPPuserRec*)hashTableSearch(&PPPuserTable, &victim[i].ur.uid);
    if (PPPuser && PPPuser->root)
      killPID[nKill++] = PPPuser->pid;
  }

  /* go process-hunting */
  if (effect) {
    for (i = 0; i < nVictims; i++) {
      if (loggingLevel >= 1) {
        loginFromUID(login, victim[i].ur.uid);
        syslog(LOG_INFO, "Punted %s on %s (%s)", login, victim[i].ttyName, puntReason[victim[i].reason]);
      }
      if (victim[i].sendMail == TRUE) {
        sprintf(dPath, "/tmp/acua_updated.%d", (int)getpid());
        sendMail(&victim[i].ur, login, "", "Connection Terminated",
                 (char*)msgPath[victim[i].reason], dPath);
      }
    }
    if (nKill) {
      for (i = 0; i < nKill; i++)
        kill(killPID[i], SIGTERM);
      sleep(5);
      for (i = 0; i < nKill; i++)
        kill(killPID[i], SIGKILL);
    }
  }
 
  hashTableDeinit(&loginRecTable);
  hashTableDeinit(&loginRecTable_TTY);
  hashTableDeinit(&procRecTable);
  hashTableDeinit(&procRecTable_EUID);
  hashTableDeinit(&procRecTable_PID);
  hashTableDeinit(&PPPuserTable);
}

char *
userTTY(char *ttyPath, int uid, PPPuserRec *PPPuser)
{
  uid_t                    _uid = uid;
  LoginRec                *loginRec;

  loginRec = (LoginRec*)hashTableSearch(&loginRecTable, &_uid);
  while (loginRec) {
    if ((PPPuser && loginRec->tty == PPPuser->tty) ||
        (!PPPuser && lineNo(loginRec->tty) >= 0))
    {
      sprintf(ttyPath, "/dev/%s", loginRec->ttyName);
      return ttyPath;
    }
    loginRec = (LoginRec*)hashTableSearchNext(&loginRecTable, &_uid);
  }
  ttyPath[0] = '\0';
  return NULL;
}

void
userMessage(char *ttyName, char *format, ...)
{
  int                      fd;
  FILE                    *f;
  char                     ttyPath[16],
                           line[256];
  struct stat              _stat;
  struct utimbuf           _utime;
  va_list                  ap;

  va_start(ap, format);
  sprintf(ttyPath, "/dev/%s", ttyName);
  if (stat(ttyPath, &_stat))
    goto l0;
  if (!(_stat.st_mode & S_IWGRP))
    goto l0;
  vsprintf(line, format, ap);
  fd = open(ttyPath, O_WRONLY | O_NONBLOCK | O_NOCTTY);
  if (fd >= 0) {
    f = fdopen(fd, "w");
    fputc(7, f);         /* send ^G */
    fprintf(f, "\n\nNOTICE: ");
    fprintf(f, "%s\n\n", line);
    fclose(f);
  }
  if (optIdleLimit) {
    _utime.actime = _stat.st_atime;
    _utime.modtime = _stat.st_mtime;
    utime(ttyPath, &_utime);
  }
l0:
  va_end(ap);
}

void
sendMail(UserRec *ur, char *login, char *cc, char *subject, char *sPath, char *dPath)
{
  char mailDest[64];
  char str[64];

  // set the mail destination
  strcpy(mailDest, login);
  if (optMailHost[0])
    sprintf(mailDest + strlen(mailDest), "@%s", optMailHost);

  preprocessFile(ur, sPath, dPath);
  sprintf(str, "mail -s \"%s\" %s%s < %s", subject, cc, mailDest, dPath);
  system(str);
  unlink(dPath);
}

int
PPPidleLeft(UserRec *ur, time_t loginTime)
{
  int                      i;
  word                     nBytes;

  if ((((time(NULL) - loginTime) / 60) >= ur->PPPidleMinutes)) {
    nBytes = 0;
    for (i = 0; i < ur->PPPidleMinutes; i++)
      nBytes += ur->nBytes[i];
    if (nBytes < ur->PPPidleBytes) return 0;
  }
  return INT_MAX;
}

int
TTYidleLeft(UserRec *ur)
{
  int          res = INT_MAX;
  struct stat  _stat;
  char         ttyPath[32];
  LoginRec    *loginRec;

  loginRec = (LoginRec*)hashTableSearch(&loginRecTable, &ur->uid);
  while (loginRec) {
    sprintf(ttyPath, "/dev/%s", loginRec->ttyName);
    if (stat(ttyPath, &_stat) < 0)
      perrQuit("couldn't stat %s", ttyPath);
    int idleLeft = ur->idleLimit * 60 - (time(NULL) - _stat.st_mtime);
    if (res == INT_MAX)
      res = idleLeft;
    else
      res = max(res, idleLeft);
    loginRec = (LoginRec*)hashTableSearchNext(&loginRecTable, &ur->uid);
  }
  if (res < 0)
    res = 0;
  else
    res = res / 60 + 1;
  return res;
}

void
PPPupdate(UserRec *ur, int PPPunit, time_t loginTime)
{
  struct ifreq             _ifreq;
  struct ppp_stats         _ppp_stats;
  int                      s;
  word                     bStx, bSrx;
  int                      idx;

  if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    perrQuit("couldn't create socket");
  bzero(&_ifreq, sizeof(struct ifreq));
  sprintf(_ifreq.ifr_ifrn.ifrn_name, "ppp%d", PPPunit);
  _ifreq.ifr_ifru.ifru_data = (caddr_t)&_ppp_stats;
  if (ioctl(s, SIOCGPPPSTATS, (caddr_t)&_ifreq) < 0)
    goto err;
  bStx = _ppp_stats.p.ppp_ooctects;
  bSrx = _ppp_stats.p.ppp_ioctects;

  if (ur->PPPidleMinutes > 0)
  {
    idx = ((time(NULL) - loginTime) / 60) % ur->PPPidleMinutes;
  }
  else
  {
    idx = ((time(NULL) - loginTime) / 60) % 60;
  }
  ur->nBytes[idx] = 0;
  if (bStx > ur->bStx) {
    ur->nBytes[idx] += bStx - ur->bStx;
    ur->bTx += bStx - ur->bStx;
    ur->bStx = bStx;
  }
  if (bSrx > ur->bSrx) {
    ur->nBytes[idx] += bSrx - ur->bSrx;
    ur->bRx += bSrx - ur->bSrx;
    ur->bSrx = bSrx;
  }
err:
  close(s);
}

int
warnExpire(time_t expire) {
  int                      i;
  time_t                   t = time(NULL), low, high;

  for (i = 0; i < nExpireWarnTimes; i++) {
    low = expire - expireWarnTime[i] * 24 * 60 * 60;
    high = expire - (expireWarnTime[i] - 1) * 24 * 60 * 60;
    if (t >= low + 120 && t < high) return 1;
  }
  return 0;
}

int
CPUpriority(int priority) {
  int                     res;

  if (optLowCPUpriority == optHighCPUpriority)
    return 0;

  if (priority <= 4) {
    res = 4 - priority;
    res *= optLowCPUpriority;
    res /= 4;
  } else {
    res = priority - 4;
    res *= optHighCPUpriority;
    res /= 3;
  }
  return res;
}

int
victimCmp(const VictimRec *v1, const VictimRec *v2)
{
  int                      v1Data = v1->reason == PUNT_DATA_PERIOD ||
                                    v1->reason == PUNT_DATA_SESSION;
  int                      v2Data = v2->reason == PUNT_DATA_PERIOD ||
                                    v2->reason == PUNT_DATA_SESSION;

  if (v1Data && !v2Data)
    return -1;
  else if (v2Data && !v1Data)
    return 1;
  else if (PRIORITY(v1->ur.flags) == PRIORITY(v2->ur.flags)) {
    if (v1->sLeft == v2->sLeft)
      return 0;
    else if (v1->sLeft < v2->sLeft)
      return -1;
    else
      return 1;
  } else if (PRIORITY(v1->ur.flags) < PRIORITY(v2->ur.flags))
    return -1;
  else
    return 1;
}

void
readUsageRecords()
{
  int                      i,
                           n;
  time_t                   t;
  struct tm               *tmP;
  FILE                    *f;
  char                     path[256];

  time(&t);
  for (i = 0; i < 5; i++) {
    sprintf(path, LIB"/record/%s", usageRecName[i]);
    f = fopen(path, "rb");
    if (f) {
      n = fread(usageRec + i, sizeof(UsageRec), 1, f);
      fclose(f);
      if (n <= 0) goto create;
      if (usageRec[i].expire && t >= usageRec[i].expire) {
        tmP = localtime(&usageRec[i].expire);
        sprintf(path, LIB"/record/archive/%s.%d-%d-%d", usageRecName[i],
                tmP->tm_year, tmP->tm_mon, tmP->tm_mday);
        f = fopen(path, "wb");
        if (f) {
          fwrite(usageRec + i, sizeof(UsageRec), 1, f);
          fclose(f);
        }
        goto create;
      }
    } else {
create:
      bzero(usageRec + i, sizeof(UsageRec));
      usageRec[i].startTime = t;
      if (usageRecExpire[i][0])
        usageRec[i].expire = addTime(time(NULL), (char*)usageRecExpire[i]);
    }
  }
}

void
writeUsageRecords(int curMinute)
{
  int                      i;
  FILE                    *f;
  char                     path[256];

  for (i = 0; i < 5; i++) {
    usageRec[i].nMinutes[curMinute]++;
    sprintf(path, LIB"/record/%s", usageRecName[i]);
    f = fopen(path, "wb");
    if (f) {
      fwrite(usageRec + i, sizeof(UsageRec), 1, f);
      fclose(f);
    }
  }
}

void
unlinkOldLockFiles()
{
  DIR            *dir = opendir(LIB);
  char            path[256];
  struct dirent  *_dirent;
  struct stat     _stat;

  if (dir == NULL)
    perrQuit("opendir(%s)", LIB);

  while ((_dirent = readdir(dir)) != NULL) {
    if (!strncmp(_dirent->d_name, "LOCK", 4)) {
      sprintf(path, "%s/%s", LIB, _dirent->d_name);
      if (lstat(path, &_stat))
        continue;
      if (time(NULL) - _stat.st_atime >= 3600)
        unlink(path);
    }      
  }
  closedir(dir);
}
