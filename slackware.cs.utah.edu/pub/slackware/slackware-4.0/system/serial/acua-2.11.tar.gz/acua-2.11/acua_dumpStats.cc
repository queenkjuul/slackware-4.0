#include "common.h"

int
acua_dumpStats(int argc, char **argv)
{
  int       i;
  char      name[256], path[256];
  UsageRec  usage;
  FILE     *f;

  if (argc == 1)
    strcpy(name, "overall");
  else
    strcpy(name, argv[1]);
  if (name[0] == '/') {
    f = fopen(name, "rb");
  } else {
    sprintf(path, LIB"/record/%s", name);
    f = fopen(path, "rb");
    if (!f) {
      sprintf(path, LIB"/record/archive/%s", name);
      f = fopen(path, "rb");
    }
  }
  if (!f) errQuit("can't find statistics file: %s", name);

  fread(&usage, sizeof(UsageRec), 1, f);
  fclose(f);

  printf("%lu\n", usage.startTime);
  for (i = 0; i < 24 * 60; i++) {
    if (i) printf(" ");
    printf("%u", usage.nMinutes[i]);
  }
  printf("\n");
  for (i = 0; i < 24 * 60; i++) {
    if (i) printf(" ");
    printf("%u", usage.linesBusy[i]);
  }
  printf("\n");
  for (i = 0; i < 24 * 60; i++) {
    if (i) printf(" ");
    printf("%u", usage.sessionLength[i]);
  }
  return 0;
}
