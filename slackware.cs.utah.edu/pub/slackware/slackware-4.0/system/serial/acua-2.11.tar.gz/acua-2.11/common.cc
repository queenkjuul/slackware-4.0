#include "common.h"

const int                days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
char                    *configFilePath = LIB"/acua.config";
char                    *userFilePath = LIB"/acua_users";
char                    *banFilePath = LIB"/banned_users";

FILE                    *userFile;
FILE                    *banFile;

int                      optPurgeDays;
int                      optMinDeduct;
int                      optBusyThreshold;
int                      optMaxKick;
int                      optLowCPUpriority,
                         optHighCPUpriority;
int                      optReturnDelay;
int                      optGuestTime;
int                      optGuestPriority;
char                     optMailHost[64];
int                      optExplainBoot;
int                      nBootWarnTimes;
int                      bootWarnTime[MAX_BOOT_WARN_TIMES];
int                      optPPPWarnBoot;
int                      nExpireWarnTimes;
int                      expireWarnTime[MAX_EXPIRE_WARN_TIMES];
char                     optWarnExpireCC[64];
int                      optIdleLimit;
int                      optPPPidleMinutes;
int                      optPPPidleBytes;
int                      optSmartTime;
int                      optSessionSmartTime;
int                      optTimeClassSmartTime;
int                      optSmartBoot;
int                      optSessionSmartBoot;
int                      optTimeClassSmartBoot;
int                      optIdleSmartBoot;
int                      nTimeClasses;
TimeClass                timeClass[MAX_TIME_CLASSES];
int                      nExcluded;
uid_t                    excluded[64];
char                     optModemDial[64];
char                     optPhNoAreaFormat[16];
char                     optPhNoLocalFormat[16];
int                      optPhNoDigits;
int                      userFileFD,
                         banFileFD;
int                      nLines;
dev_t                    lineDev[MAX_USERS];
