#ifndef MACROS_H
#define MACROS_H

#define K(x)            ((x) * 1024)
#define M(x)            (K(K(x)))
#define min(x,y)        ((x) < (y) ? (x) : (y))
#define max(x,y)        ((x) > (y) ? (x) : (y))

#endif
