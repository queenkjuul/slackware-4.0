/* 
Last updated: Tue May 04 15:21:11 EDT 1999      
*/  

void scrollon(int ttyfd);
void scrolloff(int ttyfd);
void capson(int ttyfd);
void capsoff(int ttyfd);
void numon(int ttyfd);
void numoff(int ttyfd);

#define NUM_DEVICES 3

