// logserial.h

#ifndef __LOGSERIAL_H__
#define __LOGSERIAL_H__

#define VERSION "0.3"

extern void m_savestate( int);
extern void m_restorestate( int);
extern void m_setparms( int, char *, char *, char *, int, int);
extern void m_nohang( int);
extern void m_hupcl( int, int);
extern void m_flush( int);

#endif // (__LOGSERIAL_H__)