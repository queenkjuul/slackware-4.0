#ifndef RINGSM
#define RINGSM

/* Start the ring state machine */
extern void rsm_start(void);

/* Step the ring state machine on a modem ring */
extern void rsm_process_ring(void);

/* Stop the ring state machine */
extern void rsm_stop(void);

#endif
