#ifndef RINGSEQ
#define RINGSEQ

#include "types.h"

extern ringseq *program;
extern void rs_exec(const ringseq *);
extern void remove_program(void);
extern void install_program(ringseq *);
extern int modemfd;

extern range *newrange(range *, long, long, long, long);
extern interval *newinterval(interval *, range *);
extern ringseq *newringseq(long, long, interval *, long, long, char *);

extern void freeringseqs(ringseq *);

#endif
