#ifndef DECODE
#define DECODE

#include "types.h"

extern char *decode_string(const char *);
/* Decode a string representation to a string */
/* Copy to suitably malloc'd memory           */

extern bool decode_int(const char *,const int,int*);
/* Decode an int representation */
/* Check for overflow           */
/* Return whether successful    */

extern bool decode_word(char const*, int *);
/* Decode a word into a token */
/* Return whether successful  */

#endif
