#include "dim.h"

void usage ()
{
    error ("\n"
        "ICCE Dial-In Monitor  V" VERSION "\n"
    	"Copyright (c) ICCE " YEAR ". All rights reserved.\n"
	"This program may be distributed and modified in accordance with\n"
        "the GNU General Public Licence.\n"
    	"\n"
    	"Dim by Frank B. Brokken.\n"
    	"\n"
    	"Usage: dim -flag, where flag may be:\n"
	"       -disable             : disables dial-in\n"
    	"       -enable              : enables dial-in\n"
    	"       -file                : shows getty's definition file\n"
    	"       -wake                : wakeup init to reload getty\n"
    	"\n"
    	"Flags may be abbreviated, e.g., \"-wa\" is equivalent to "
    	   							" \"-wake\".\n"
    	"\n");
}
