/* DBS Telephony Server (c) 1997-1998 Tycho Softworks.
 * $Id: poweron.c 1.1 Sat, 19 Sep 1998 20:57:22 -0400 dyfet $
 *
 * This software is free software; permission is granted to use, modify
 * and redistribute this software as according to the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2, as found in the "COPYING" file distributed with this
 * software, or (at your option) any later version published by the
 * Free Software Foundation. 
 * 
 * This software is supplied "AS IS" WITHOUT ANY WARRANTY, EXPRESSED OR
 * IMPLIED; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for further details. 
 */

#include <std/string.h>
#include "dbs.h"

int	dbs_poweron(int slot)
{
	DBSMSG	msg[DBS_POWERON_MSGLEN + 10];

	dbs_setslot(msg, slot);	
	dbs_setmsglen(msg, sizeof(msg));
	dbs_setmsgtype(msg, DBS_POWERON_MSGTYPE);
	dbs_getappname(msg + 6, 10);
	return dbs_send(msg);
}

