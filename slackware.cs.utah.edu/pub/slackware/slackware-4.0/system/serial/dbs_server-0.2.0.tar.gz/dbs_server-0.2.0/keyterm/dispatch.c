/* DBS Telephony Server (c) 1997-1998 Tycho Softworks.
 * $Id: dispatch.c 1.2 Sun, 11 Oct 1998 20:20:08 -0400 dyfet $
 *
 * This software is free software; permission is granted to use, modify
 * and redistribute this software as according to the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2, as found in the "COPYING" file distributed with this
 * software, or (at your option) any later version published by the
 * Free Software Foundation. 
 * 
 * This software is supplied "AS IS" WITHOUT ANY WARRANTY, EXPRESSED OR
 * IMPLIED; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for further details. 
 */

#include <std/signal.h>
#include <std/types.h>
#include "keyterm.h"

static	bool	timeout = FALSE;
static	bool	active = FALSE;

static	int	sigterm()
{
	if(active)
		down(0);
	else
		down(-1);
}

static	int	sigtimer()
{
	timeout = TRUE;
	signal(SIGALRM, sigtimer);
}

int	dispatch(void)
{
	int	timer	= powerup_timer;
	int	extension;
	DBSMSG	mbuf[128];

	signal(SIGALRM, sigtimer);
	signal(SIGINT, sigterm);
	signal(SIGTERM, sigterm);

	for(;;)
	{
		alarm(timer);
		timeout = FALSE;
		if(dbs_recv(mbuf))
		{
			alarm(0);
			if(active)
				synckterm();

			continue;
		}

		alarm(0);
		if(timeout && !active)
			return -1;
 							
		if(dbs_getslot(mbuf) != 0)
			continue;

		extension = 0;
	
		switch(dbs_getmsgtype(mbuf))
		{
		case DBS_KEYPAD_MSGTYPE:
			extension = dbs_getextnbr(mbuf + 8);
			break;
		case DBS_APIKEY_MSGTYPE:
			extension = dbs_getextnbr(mbuf + 10);
			break;
		case DBS_SERVICE_MSGTYPE:
			dbs_service(mbuf, &timer);
			if(timer)
				return -1;
			active = TRUE;
			dts_syslog(0, TLOG_INFO, "active");
			dts_setflags(0, FLAG_KEYMON);
			timer = event_timer;
			break;
		}

		putkterm(extension, mbuf);
	}
}
