/* DBS Telephony Server (c) 1997-1998 Tycho Softworks.
 * $Id: station.c 1.2 Sun, 11 Oct 1998 20:20:08 -0400 dyfet $
 *
 * This software is free software; permission is granted to use, modify
 * and redistribute this software as according to the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2, as found in the "COPYING" file distributed with this
 * software, or (at your option) any later version published by the
 * Free Software Foundation. 
 * 
 * This software is supplied "AS IS" WITHOUT ANY WARRANTY, EXPRESSED OR
 * IMPLIED; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for further details. 
 */

#include <std/math.h>
#include <std/process.h>
#include <std/limits.h>
#include <std/time.h>
#include "keyterm.h"

static	uchar	*page;
static	int	used;
static	int	pagesize;
static	int	first = 100;
static	int	stations = 600;
static	KEYTERM	**kt;

KEYTERM	*getkterm(int ext)
{
	ext = ext - first;
	if(ext < 0 || ext > stations)
		return NULL;

	return kt[ext];
}

void	initkterm(void)
{
	int	i;

	pagesize = used = min(4096, getpagesize());

	if (dbs_digits == 2)
	{
		first = 10;
		stations = 60;
	}

	kt = (KEYTERM **)malloc(stations * sizeof(KEYTERM *));
	for(i = 0; i < stations; ++i)
		kt[i] = NULL; 	
}

void	synckterm(void)
{
	int	i;
	KEYTERM	*kp;
	time_t	now;

	time(&now);
	for(i = 0; i < stations; ++i)
	{
		kp = kt[i];
		if(!kp)
			continue;

		if(!kp->timer)
			continue;
		
		if(now >= kp->timer)
		{
			kp->timer = 0;
			(*kp->khandler)(kp, i + first, NULL);
		}
	}
}

void	putkterm(int extension, DBSMSG *msg)
{
	KEYTERM	*kp;
	unsigned offset;

	if((extension < first) || (extension >= first + stations))
		return;
	
	offset = extension - first;
	kp = kt[offset];
	if(!kp)
	{
		if(used + sizeof(KEYTERM) > pagesize)
		{
			used = 0;
			page = (uchar *)malloc(pagesize);
			memset(page, 0, pagesize);
		}
		kt[offset] = kp = (KEYTERM *)&page[used];
		used += sizeof(KEYTERM);

		kp->khandler = kt_init;
	}

	if(kp->khandler)
		(*kp->khandler)(kp, extension, msg);
}
