/* DBS Telephony Server (c) 1997-1998 Tycho Softworks.
 * $Id: dbs_keys.h 1.1 Sun, 11 Oct 1998 20:20:08 -0400 dyfet $
 *
 * This software is free software; permission is granted to use, modify
 * and redistribute this software as according to the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2, as found in the "COPYING" file distributed with this
 * software, or (at your option) any later version published by the
 * Free Software Foundation. 
 * 
 * This software is supplied "AS IS" WITHOUT ANY WARRANTY, EXPRESSED OR
 * IMPLIED; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for further details. 
 */

#define	DBS_KEY_HOLD		0x05
#define	DBS_KEY_FLASH		0x06
#define	DBS_KEY_NEXT		0x02
#define	DBS_KEY_MENU		0x0b
#define	DBS_KEY_PREV		0x0c
#define	DBS_KEY_AUTO		0x4d
#define	DBS_KEY_REDIAL		0x4e
#define	DBS_KEY_ONHOOK		0x0d
#define	DBS_KEY_OFFHOOK		0x0e
#define	DBS_KEY_CONF		0x09
#define	DBS_KEY_XFER		0x0a
#define	DBS_KEY_FAIL		0x81
#define	DBS_KEY_RECOVER		0x80
#define	DBS_KEY_S0L		0x10
#define	DBS_KEY_S1L		0x11
#define	DBS_KEY_S2L		0x12
#define	DBS_KEY_S3L		0x13
#define	DBS_KEY_S4L		0x14
#define	DBS_KEY_S0R		0x15
#define	DBS_KEY_S1R		0x16
#define	DBS_KEY_S2R		0x17
#define	DBS_KEY_S3R		0x18
#define	DBS_KEY_S4R		0x19
#define	DBS_KEY_0		0x40
#define	DBS_KEY_1		0x41
#define	DBS_KEY_2		0x42
#define	DBS_KEY_3		0x43
#define	DBS_KEY_4		0x44
#define	DBS_KEY_5		0x45
#define	DBS_KEY_6		0x46
#define	DBS_KEY_7		0x47
#define	DBS_KEY_8		0x48
#define	DBS_KEY_9		0x49
#define	DBS_KEY_10		0x4a
#define	DBS_KEY_STAR		0x4b
#define	DBS_KEY_POUND		0x4c



	
