/* Portable System Interfaces Copyright (c) 1997-1998 Tycho Softworks.
 * $Id: _locking.c 1.1 Tue, 23 Jun 1998 11:38:33 -0400 dyfet $
 *
 * Permission is hear-by granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute with modifications, sub-license, and/or sell copies of the
 * software, and to permit persons to whom the Software is furnished to
 * do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * Neither the name of Tycho Softworks nor the names of it's contributors
 * may be used to endorse or promote products derived from this Software
 * without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY TYCHO SOFTWORKS "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL TYCHO SOFTWORKS OR IT'S
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * OR CONSEQUENTIAL DAMAGES (INCLUDING BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS "SOFTWARE",
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <std/locking.h>

#ifdef	FLOCK_F_MISSING
int	flock(fd_t fd, int mode)
{
	struct	flock	lck;
	int	cmd = F_SETLKW;

	lck.l_start = lck.l_len = 0l;
	lck.l_whence = SEEK_SET;
	
	if(mode & LOCK_NB)
	{
		cmd = F_SETLK;
		mode &= ~LOCK_NB;
	}

	switch(mode)
	{
	case LOCK_SH:
		lck.l_type = F_RDLCK;
		break;
	case LOCK_EX:
		lck.l_type = F_WRLCK;
		break;
	case LOCK_UN:
		lck.l_type = F_UNLCK;
	}

	return fcntl(fd, cmd, &lck);
}	

#endif

#ifdef	LOCKF_F_MISSING

int	lockf(fd_t fd, int cmd, off_t len)
{
	struct	flock	lck;

	lck.l_start = 0l;
	lck.l_whence = SEEK_CUR;
	lck.l_len = len;

	switch(cmd)
	{
	case F_ULOCK:
		lck.l_type = F_UNLCK;
		return fcntl(fd, F_SETLK, &lck);
		break;
	case F_LOCK:
		lck.l_type = F_WRLCK;
		return fcntl(fd, F_SETLKW, &lck);
		break;
	case F_TLOCK:
		lck.l_type = F_WRLCK;
		return fcntl(fd, F_SETLK, &lck);
		break;
	case F_TEST:
		lck.l_type = F_WRLCK;
		fcntl(fd, F_GETLK, &lck);
		if(lck.l_type == F_UNLCK)
			return 0;
		return -1;
	}
}
#endif

