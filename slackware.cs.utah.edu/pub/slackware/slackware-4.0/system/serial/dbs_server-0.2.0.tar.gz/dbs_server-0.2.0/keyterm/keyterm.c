/* DBS Telephony Server (c) 1997-1998 Tycho Softworks.
 * $Id: keyterm.c 1.1 Sat, 10 Oct 1998 19:51:45 -0400 dyfet $
 *
 * This software is free software; permission is granted to use, modify
 * and redistribute this software as according to the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2, as found in the "COPYING" file distributed with this
 * software, or (at your option) any later version published by the
 * Free Software Foundation. 
 * 
 * This software is supplied "AS IS" WITHOUT ANY WARRANTY, EXPRESSED OR
 * IMPLIED; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for further details. 
 */

#include <std/string.h>
#include <std/process.h>
#include <std/signal.h>
#include <std/errlog.h>
#include "keyterm.h"

static	bool	daemon_flag	= FALSE;

int	expire_timer;
int	powerup_timer;
int	event_timer;	/* timer resolution				*/

void down(int excode)
{
	if(excode)
	{
		dts_syslog(0, TLOG_ERROR, "failed");
		if(!daemon_flag)
			errexit(excode, "dbs_keyterm: channel failed");
	}
	else
		dts_syslog(0, TLOG_INFO, "shutdown");
	dbs_shutdown();
	exit(excode);
} 

int main(int argc, char **argv)
{
	int	status, opt;
	bool	usage = FALSE;

	while(EOF != (opt = getopt(argc, argv, "D")))
		switch(opt)
		{
		case 'D':
			daemon_flag = TRUE;
			break;
		default:
			usage = TRUE;
		}

	if(usage || optind != argc)
		errexit(EX_USAGE, "use: dbs_keyterm [-D]");

	status = dbs_connect("keyterm");

	if(status)
		errexit(EX_CONFIG, "dbs_keyterm: cannot connect");

	expire_timer = dbs_getvalue("expire", 15) * 60;
	event_timer = dbs_getvalue("update", 5);
	powerup_timer = dbs_getvalue("powerup", 5);

	if(dbs_getslots() != 1)
		errexit(EX_CONFIG, "dbs_keyterm: incorrectly bound to API channels");

	if(dts_syslog(0, TLOG_INFO, "startup"))
	{
		dbs_shutdown();
		errexit(EX_CONFIG, "dbs_keyterm: no server");
	}

	if(daemon_flag)
	{
		close(0);
		close(1);
		close(2);
		pdetach();
	}

	if(dbs_poweron(0))
		down(EX_CONFIG);

	initkterm();

	down(dispatch());
}

