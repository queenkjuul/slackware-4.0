/* DBS Telephony Server (c) 1997-1998 Tycho Softworks.
 * $Id: station.c 1.1 Sat, 10 Oct 1998 19:51:45 -0400 dyfet $
 *
 * This software is free software; permission is granted to use, modify
 * and redistribute this software as according to the terms of the GNU
 * General Public License as published by the Free Software Foundation;
 * either version 2, as found in the "COPYING" file distributed with this
 * software, or (at your option) any later version published by the
 * Free Software Foundation. 
 * 
 * This software is supplied "AS IS" WITHOUT ANY WARRANTY, EXPRESSED OR
 * IMPLIED; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for further details. 
 */

#include <std/time.h> 
#include "keyterm.h"

/* login state */

void	kt_login(KEYTERM *kp, int extension, DBSMSG *msg)
{
	int	digits;
	uchar	*digit;

	if(!msg)
	{
		logout(kp, extension);
		return;
	}

	switch(dbs_getmsgtype(msg))
	{
	case DBS_KEYPAD_MSGTYPE:
		digits = msg[12];
		digit = msg + 13;
		kp->timer += 5;
		while(digits--)
		{
			switch(*digit)
			{
			case DBS_KEY_MENU:
				kp->kpos = 0;
				strcpy(kp->kbuf, "DBS Login");
				break;
			case DBS_KEY_STAR:
			case DBS_KEY_POUND:
			case DBS_KEY_AUTO:
			case DBS_KEY_CONF:
				if(!kp->kpos)
					break;
				--kp->kpos;
				kp->kbuf[kp->kpos] = 0;
				break;
			case DBS_KEY_S4R:
				logout(kp, extension);
				return;
			case DBS_KEY_FAIL:
				kp->timer = 0;
				kp->khandler = kt_init;
				return;	
			case 0x4a:
				*digit = 0x40;
			case 0x41:
			case 0x42:
			case 0x43:
			case 0x44:
			case 0x45:
			case 0x46:
			case 0x47:
			case 0x48:
			case 0x49:
				if(kp->kpos < 16)
				{
					kp->kbuf[kp->kpos++] = *digit - 16;
					kp->kbuf[kp->kpos] = 0;
				}
			}
			++digit;
			dbs_display_line(0, extension, 0, kp->kbuf);
		}		
		return;
	case DBS_APIKEY_MSGTYPE:
		logout(kp, extension);
		return;
	default:
		return;
	}
}

