// 
// FILE:
// demo.C
//
// FUNCTION:
// A simple demo of the linSerial class.
//
// HISTORY:
// Copyright (c) 1995, 1997 Linas Vepstas
// Released under the  conditions  of  the  GNU General 
// Public License.

#include "serial.h"

main () {
   linSerial j;

   j.OpenDevice ("yo.txt");
   FILE * fh = j.GetFileHandle ();
   fprintf (fh, "Yo, Duuuuude ! \n");
   j.Close();
}


// ====================== END OF FILE ============================
