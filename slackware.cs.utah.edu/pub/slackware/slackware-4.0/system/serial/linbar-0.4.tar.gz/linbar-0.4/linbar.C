//
// FILE:
// linbar.C
//
// Version 0.4
//
// FUNCTION:
// A Linux driver for barcode reader connected on serial ports
//
// Copyright (c) 1998,1999 Ioannis Ioannou <roryt@hol.gr>
// Released under the  conditions  of  the  GNU General
// Public License. See COPYING for details.
//
// Warranty : There is NO WARRANTY for this program. See COPYING for details.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
//
//
// HISTORY:
//
// 24APR99 : Version 0.4 released
//	     	(Ioannou) Added 1 parameter :
//			-T to specify the output console
//
// 06MAR99 : Version 0.3 released
//	     	(Ioannou) Added 3 parameters :
//			-c to filter Carriage Return
//			-n to filter New Line
//			-l to force logging thru syslog
//			   by default there is no logging because
//			   in some systems this slow downs the TIOCSTI
//	
//
// 01OCT98 : Version 0.2 released
//	     	(Ioannou) Use of select and read instead of getc to read
//				   	  from the serial port
//
// 29JUL98 Version 0.1 released
//

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/param.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <syslog.h>


#include "serial.h"

linSerial j;
char NAME[MAXPATHLEN];
int no_debug = 1;
int mfd = -1;
int fd = -1;
int MustLog=0;
char smes[256];




void printVerion(void)
{
    fprintf (stderr, "\nlinbar version 0.4, Copyright (C) 1998,1999 Ioannis Ioannou <roryt@hol.gr>\n\n");
    fprintf (stderr, "linbar comes with ABSOLUTELY NO WARRANTY; See COPYING for details.\n");
    fprintf (stderr, "This is free software, and you are welcome to redistribute it\n");
    fprintf (stderr, "under certain conditions; See COPYING for details.\n");
    fprintf (stderr, "You should have received a copy of the GNU General Public License\n");
    fprintf (stderr, "along with this program; if not, write to the Free Software\n");
    fprintf (stderr, "Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA\n\n");
}    








void usage ()
{
	fprintf (stderr, "\nusage: %s [parameters] [&]", NAME);
	fprintf (stderr, "\n        Optional parameters are :");
	fprintf (stderr, "\n\t\t -T ouput tty      \tdefault /dev/tty0");
	fprintf (stderr, "\n\t\t -t input tty      \tdefault /dev/ttyS0");
	fprintf (stderr, "\n\t\t -s speed          \tdefault 9600");
	fprintf (stderr, "\n\t\t -d data bits      \tdefault 8");
	fprintf (stderr, "\n\t\t -p parity         \tdefault N");
	fprintf (stderr, "\n\t\t -b stop bits      \tdefault 1");
	fprintf (stderr, "\n\t\t -c cut off cr     \tdefault no");
	fprintf (stderr, "\n\t\t -n cut off nl     \tdefault no");
	fprintf (stderr, "\n\t\t -l log messages   \tdefault no");	
	fprintf (stderr, "\n\t\t -V print version and exit");
	fprintf (stderr, "\n\t\t -D enable debug messages");
	fprintf (stderr, "\n\t\t -h this help screen\n\n");
}


void dprint (char *c)
{
    if (MustLog)
    {
  	openlog (NAME, LOG_PID, LOG_DAEMON);
	syslog (LOG_DAEMON, "%s", c);
	closelog ();
    }
	if (!no_debug)
		fprintf (stderr, "%s\n", c);
}

void close_com (int sig)
{
	j.Close ();
	if (fd > 0)
		close(fd);
	if (sig != 0)
	{
		sprintf (smes, "Got signal %d\n", sig);
		dprint(smes);
	}
	dprint ("Exiting..");
	exit (1);
}

main (int argc, char **argv)
{
	char Input_dev[MAXPATHLEN], Output_dev[MAXPATHLEN], Parity_bit[2];
	int Speed, Data_bits, Stop_bits, CutCr, CutNl, c;

	/* Default values tty0, ttyS0, 9600,8,N,1 
	   no_debug, no filter, no logging */
	strcpy (Output_dev, "/dev/tty0");
	strcpy (Input_dev, "/dev/ttyS0");
	Speed = 9600;
	Data_bits = 8;
	strcpy (Parity_bit, "N");
	Stop_bits = 1;
	no_debug = 1;
	CutCr=CutNl=MustLog=0;
	strcpy (NAME, argv[0]);
	j.SetLogLevel (DEBUG);

	/* parse command line */
	while ((c = getopt (argc, argv, "T:t:s:d:p:b:cnlVDh")) != EOF)
	{
		switch (c)
		{
		case 'T':
			strcpy (Output_dev, optarg);
			break;

		case 't':
			strcpy (Input_dev, optarg);
			break;

		case 's':
			Speed = atoi (optarg);
			break;

		case 'd':
			Data_bits = atoi (optarg);
			break;

		case 'p':
			strcpy (Parity_bit, optarg);
			break;

		case 'b':
			Stop_bits = atoi (optarg);
			break;
			
		case 'c':
			CutCr=1;
			break;

		case 'n':
			CutNl=1;
			break;

		case 'l':
			MustLog=1;
			break;

		case 'D':
			no_debug = 0;
			break;

		case 'V':
			printVerion();
			exit (0);
			
		case 'h':
		default:
			usage ();
			exit (2);
		}
	}
	if (no_debug)
		j.SetLogLevel (NONE);

	sprintf (smes, "Starting, Device %s, speed %d, data bits %d, parity %s, stop bits %d\n",
	    Input_dev, Speed, Data_bits, Parity_bit, Stop_bits);
	dprint (smes);

	if (j.OpenDevice (Input_dev) != 0)
	{
		fprintf (stderr, "Can't open device %s\n", Input_dev);
		exit (1);
	}
	mfd = j.GetFileDescriptor ();
	if (mfd == -1)
	{
		fprintf (stderr, "Can't find file descriptor for %s\n", Input_dev);
		close_com (0);
	}

	/* trap signals */

	signal (SIGHUP, &close_com);
	signal (SIGINT, &close_com);
	signal (SIGQUIT, &close_com);
	signal (SIGTERM, &close_com);
	signal (SIGABRT, &close_com);


	/* Setup the serial line */
	/* FIXME any error messages ? */
	j.SetDTR ();
	j.SetupRaw ();
	j.SetBits (Data_bits, Parity_bit[0], Stop_bits);
	j.SetSpeed (Speed);
	j.SetSoftwareFlowControl ();

      if (!no_debug)
      {
           struct termios tset;
           tcgetattr(mfd, &tset);

           if (tset.c_iflag & IGNBRK)
              printf("IGNBRK ");
           if (tset.c_iflag & BRKINT)
              printf("BRKINT ");
           if (tset.c_iflag & IGNPAR)
              printf("IGNPAR ");
           if (tset.c_iflag & PARMRK)
              printf("PARMRK ");
           if (tset.c_iflag & INPCK)
              printf("INPCK ");
           if (tset.c_iflag & ISTRIP)
              printf("ISTRIP ");
           if (tset.c_iflag & INLCR)
              printf("INLCR ");
           if (tset.c_iflag & IGNCR)
              printf("IGNCR ");
           if (tset.c_iflag & ICRNL)
              printf("ICRNL ");
           if (tset.c_iflag & IUCLC)
              printf("IUCLC ");
           if (tset.c_iflag & IXON)
              printf("IXON ");
           if (tset.c_iflag & IXANY)
              printf("IXANY ");
           if (tset.c_iflag & IMAXBEL)
              printf("IMAXBEL ");

           if (tset.c_oflag & OPOST)
              printf("OPOST ");
           if (tset.c_oflag & OLCUC)
              printf("OLCUC ");
           if (tset.c_oflag & ONLCR)
              printf("ONLCR ");
           if (tset.c_oflag & OCRNL)
              printf("OCRNL ");
           if (tset.c_oflag & ONOCR)
              printf("ONOCR ");
           if (tset.c_oflag & ONLRET)
              printf("ONLRET ");
           if (tset.c_oflag & OFILL)
              printf("OFILL ");
           if (tset.c_oflag & OFDEL)
              printf("OFDEL ");
           if (tset.c_oflag & NLDLY)
              printf("NLDLY ");
           if (tset.c_oflag & NL0)
              printf("NL0 ");
           if (tset.c_oflag & NL1)
              printf("NL1 ");
           if (tset.c_oflag & CRDLY)
              printf("CRDLY ");
           if (tset.c_oflag & CR0)
              printf("CR0 ");
           if (tset.c_oflag & CR1)
              printf("CR1 ");
           if (tset.c_oflag & CR2)
              printf("CR2 ");
           if (tset.c_oflag & CR3)
              printf("CR3 ");
           if (tset.c_oflag & TABDLY)
              printf("TABDLY ");
           if (tset.c_oflag & TAB0)
              printf("TAB0 ");
           if (tset.c_oflag & TAB1)
              printf("TAB1 ");
           if (tset.c_oflag & TAB1)
              printf("TAB1 ");
           if (tset.c_oflag & TAB2)
              printf("TAB2 ");
           if (tset.c_oflag & TAB3)
              printf("TAB3 ");
           if (tset.c_oflag & XTABS)
              printf("XTABS ");
           if (tset.c_oflag & BSDLY)
              printf("BSDLY ");
           if (tset.c_oflag & BS0)
              printf("BS0 ");
           if (tset.c_oflag & BS1)
              printf("BS1 ");
           if (tset.c_oflag & VTDLY)
              printf("VTDLY ");
           if (tset.c_oflag & VT0)
              printf("VT0 ");
           if (tset.c_oflag & VT1)
              printf("VT1 ");
           if (tset.c_oflag & FFDLY)
              printf("FFDLY ");
           if (tset.c_oflag & FF0)
              printf("FF0 ");
           if (tset.c_oflag & FF1)
              printf("FF1 ");

           if (tset.c_cflag & CBAUD)
              printf("CBAUD ");
           if (tset.c_cflag & B9600)
              printf("B9600 ");
           if (tset.c_cflag & CSIZE)
              printf("CSIZE ");
           if (tset.c_cflag & CS8)
              printf("CS8 ");
           if (tset.c_cflag & CSTOPB)
              printf("CSTOPB ");
           if (tset.c_cflag & CREAD)
              printf("CREAD ");
           if (tset.c_cflag & PARENB)
              printf("PARENB ");
           if (tset.c_cflag & PARODD)
              printf("PARODD ");
           if (tset.c_cflag & HUPCL)
              printf("HUPCL ");
           if (tset.c_cflag & CLOCAL)
              printf("CLOCAL ");
           if (tset.c_cflag & CBAUDEX)
              printf("CBAUDEX ");
           if (tset.c_cflag & CIBAUD)
              printf("CIBAUD ");
           if (tset.c_cflag & CRTSCTS)
              printf("CRTSCTS ");

           if (tset.c_lflag & ISIG)
              printf("ISIG ");
           if (tset.c_lflag & ICANON)
              printf("ICANON ");
           if (tset.c_lflag & XCASE)
              printf("XCASE ");
           if (tset.c_lflag & ECHO)
              printf("ECHO ");
           if (tset.c_lflag & ECHOE)
              printf("ECHOE ");
           if (tset.c_lflag & ECHOK)
              printf("ECHOK ");
           if (tset.c_lflag & ECHONL)
              printf("ECHONL ");
           if (tset.c_lflag & NOFLSH)
              printf("NOFLSH ");
           if (tset.c_lflag & TOSTOP)
              printf("TOSTOP ");
           if (tset.c_lflag & ECHOCTL)
              printf("ECHOCTL ");
           if (tset.c_lflag & ECHOPRT)
              printf("ECHOPRT ");
           if (tset.c_lflag & ECHOKE)
              printf("ECHOKE ");
           if (tset.c_lflag & FLUSHO)
              printf("FLUSHO ");
           if (tset.c_lflag & PENDIN)
              printf("PENDIN ");
           if (tset.c_lflag & IEXTEN)
              printf("IEXTEN\n");
	   fflush(stdout);      
      }


	int nfd, hcount;
	fd_set fdread;
	char hbuf[2];
	
        hcount = 0;
	
	for (;;)
	{

		FD_ZERO (&fdread);
		if (hcount == 0)
     		    FD_SET (mfd, &fdread);


		nfd = select (16, &fdread, NULL, NULL, NULL /*(struct timeval *) 0*/);
		if (nfd <= 0)
		{
			dprint ("Select failed");
			break;
		}

		/* Read data from the tty */

		if (FD_ISSET (mfd, &fdread))
		{
		    hcount = read (mfd, hbuf, 1);

		    if (!no_debug)
			printf ("\nReceived %2d byte(s) from tty\n", hcount);

		    if (hcount > 0)
		    {
			if ((hbuf[0] == 13) && (CutCr == 1))
			    continue;
			    
			if ((hbuf[0] == 10) && (CutNl == 1))
			    continue;
			    			    
			if ((fd = open (Output_dev, O_WRONLY | O_NONBLOCK)) < 0)
			{
    			    sprintf(smes, "Can't open %s", Output_dev);
			    dprint(smes);
	    		    perror ("");
			    break;
			}
			if (ioctl (fd, TIOCSTI, &hbuf[0]) < 0)
			{
			  dprint ("Can't call ioctl(TIOCSTI)");
			  close (fd);
			  close_com(0);
			  exit(1);
			}
			close(fd);
		    }
		    hcount = 0;
		}
	}
	close_com (0);
}
