// Copyright 1996 - 1997, Tim Hart.
// All rights reserved.
//
// Modem Resource Manager.
//
//      Author: Tim Hart.
//
//	mrmtypes.h
//
// 
//
// dynamic data types used in the modem resource manager
// + routines for their access and usage.

typedef int BOOL;

typedef struct DEV_INFO
{
    char * pDeviceId;
    char current_user[UT_NAMESIZE+1];
    char prev_user[UT_NAMESIZE+1];
    time_t login_time;
    time_t logout_time;
    pid_t login_pid;
    BOOL occupied;
    struct DEV_INFO * pNextDevice;
    int DevIndex;
} DEV_INFO;

typedef struct DEV_INFO_BASE
{
    DEV_INFO * pFirstDevice;
    DEV_INFO * pLastDevice;
    int NumberOfDevices;
} DEV_INFO_BASE;

typedef struct USER_NODE
{
    char pUser[UT_NAMESIZE+1];
    time_t online_limit;
    time_t wait_limit;
    struct USER_NODE * pNextUser;
    int UserIndex,iMaxLogins;
} USER_NODE;

typedef struct USER_BASE
{
    USER_NODE * pFirstUser;
    USER_NODE * pLastUser;
    int NumberOfUsers;
} USER_BASE;

typedef struct GLG_NODE
{
    gid_t group_id;
    time_t group_limit;
    time_t group_grace;
    struct GLG_NODE * pNextGLG;
    int GLGIndex,iMaxLogins;
} GLG_NODE;

typedef struct GLG_BASE
{
    GLG_NODE * pFirstGLG;
    GLG_NODE * pLastGLG;
    int NumberOfGLG;
} GLG_BASE;

typedef struct EXEMPT_NODE
{
    char * pExemptUser;
    uid_t ExemptUid;
    struct EXEMPT_NODE * pNextExempt;
    int ExemptIndex;
} EXEMPT_NODE;

typedef struct EXEMPT_BASE
{
    EXEMPT_NODE * pFirstExempt;
    EXEMPT_NODE * pLastExempt;
    int NumberExempt;
} EXEMPT_BASE;

typedef struct USERGLG
{
    BOOL check;
    int position;
} USERGLG;

typedef struct USERGID
{
    BOOL Found;
    gid_t UserGID;
} USERGID;

typedef struct DIVTIME_T
{
    int hours;
    int minutes;
    int seconds;
} DIVTIME_T;

typedef struct USERKILL
{
    BOOL Found;
    int position;
} USERKILL;

typedef struct KICK_NODE
{
    char * pKickUser;
    time_t KickTime;
    time_t GracePeriod;
    struct KICK_NODE * pNextKick;
    int KickIndex,NumReKicks;
} KICK_NODE;

typedef struct KICK_BASE
{
    KICK_NODE * pFirstKick;
    KICK_NODE * pLastKick;
    int NumberOfKicks;
} KICK_BASE;

typedef struct ONLINE_INFO
{
    char * pDeviceId;
    struct ONLINE_INFO * pNextLogin;
    int iNumLogins;
} ONLINE_INFO;

