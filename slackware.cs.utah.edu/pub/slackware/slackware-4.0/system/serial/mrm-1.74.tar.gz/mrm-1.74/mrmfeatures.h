// Copyright 1996 - 1997, Tim Hart.
// All rights reserved.
//
// Modem Resource Manager.
//
//      Author: Tim Hart.
//
//	mrmfeatures.h
//
//	Program Specific Values.
//

// System Headers.

#include <stdio.h>
#include <pwd.h>
#include <utmp.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <setjmp.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

// FULL PATH to File locations
#define tty_path     "/etc/mrmtty"
#define group_path   "/etc/mrmgroup"
#define ranking_path "/etc/mrmranking"
#define exempt_path  "/etc/mrmexempt"
#define utmp_path    "/var/run/utmp"
#define log_path     "/var/log/mrmlog"
#define debug_path   "/var/log/mrmdebug"
#define un_sock_addr "/tmp/mrmsock"

// should not need to touch these default values.
// you may overide them with commandline options.
#define MAX_FIELD_LENGTH       10    // max number of chars in 1 glg field.
#define MAXCLIENTS              3    // highest connection count allowed.
#define MIN_FREE_DEVICES        1    // modem number that must be free at all times.
#define LOOP_SECOND_INTERVALS   5    // second w8 time btween loops
#define TIMEOUTSEC             30    // Client max idle time in seconds.
#define FALSE                   0
#define TRUE                    1
#define max_path_length       128    // max size of path strings.
#define PPP_MON_PERIOD        120    // period in seconds.
#define PAP_TIMEOUT           120    // the pap ppp login timeout in seconds.
#define PAP_LOGIN            "ppp"
//
//	Selective Compile Option Defines.
//
// DO NOT TOUCH ANYTHING BELOW THIS LINE. :)

#define KILL_FOR_REAL    TRUE  	    // actually kill the users.
#define LOG_ACTIONS      TRUE       // log user kills
#define FORK	         TRUE       // release controlling terminal
#define CATCH_SIGHUP     TRUE       // catch signal for config re-read
#define DEBUG_HIGH       FALSE      // test mode
#define DO_BASE_DELETION TRUE       // dont touch
#define RANKING_BASED_DISCONNECT TRUE
#define USE_EXEMPT       TRUE       // take advantage of an exempt users list.
#define ZERO_LIMIT_CHECK TRUE       // allow zero limit to give special powers.
#define VIS_SERVER       FALSE      // activate unix server code for a visual client.
#define FILE_DEBUG       FALSE      // log some debugging info.
#define KILL_EXEMPT_CHECKING TRUE
#define RANKING_KILL_GUARD TRUE
#define PPP_PAP_MON      TRUE

// Network/Socket stuff.

#define S_STOP           5
#define S_START          6
#define S_HELLO          7
#define S_SAYHELLO       8
#define S_ALL            9
#define S_DEVICELIST     10
#define S_USERLIST       11
#define S_KICKLIST       12
#define S_GLGLIST        13
#define S_EXEMPTLIST     14
#define S_UPTIME         15
#define S_TOTALKILLS     16
#define S_TOTALREKILLS   17
#define S_UKILLREQUEST	 18
#define S_DKILLREQUEST   19
#define S_UDKILLREQUEST  20
// end network stuff.


//  The Version :)
//
#define V_INFO "1.74"

// me.

#define A_INFO "Copyright (C) 1997 Tim Hart."

#define UsageMesg "\n\
mrm comes with ABSOLUTELY NO WARRANTY.\n\
This is free software, and you are welcome to redistribute\n\
it under certain conditions; - see the  GNU GENERAL PUBLIC LICENSE\n\
for detials.\n\
\n\
Usage: mrm [-m int] [-w int] [-x [off_t]] [-p [int]] [-option(s)]\n\n\
        -m int     : (int) the minimum free devices.         [1]\n\
        -w int     : (int) wait second intervals.            [5]\n\
        -x [off_t] : file debug on. (off_t) Bytes max size.  [1]\n\
        -p [int]   : pap ppp login monitoring.                +\n\
The follow options may be passed singularly or combined.\n\
        -v         : version and compilation information.\n\
        -h         : shows this usage message.\n\
        -d         : stdout debuging info dumps.              -\n\
        -s         : catch SIGHUP signal for config re-read.  +\n\
        -f         : task forking (run in background).        +\n\
        -k         : kill (disconnect) mode.                  +\n\
        -l         : logging.                                 +\n\
        -e         : use exempt information.                  +\n\
        -r         : ranking based disconnection.             +\n\
        -n         : activate server for a monitoring client. -\n\
        \n\
        server code is very alpha and should not be activated by mere mortals.\n\
        +/- indicates on/off by default, most parameters toggle.\n"

#define KillUserUsageMesg "\n\
killuser comes with ABSOLUTELY NO WARRANTY.\n\
This is free software, and you are welcome to redistribute\n\
it under certain conditions; - see the GNU GENERAL PUBLIC LICENSE\n\
for details.\n\
\n\
Usage: killuser username [-d] [-e] [-h] [-l] [-o devID] [-r] [-v]\n\n\
        username   : the user to kill.                         \n\
        -d         : stdout debuging info dumps.              -\n\
        -e         : check exempt information.                +\n\
        -h         : shows this usage message.\n\
        -l         : logging (via mrm files).                 +\n\
        -o devID   : logout user on devId only. (not yet working)\n\
        -r         : ranking kill guard                       +\n\
        -v         : version and compilation information.\n\
        \n\
        +/- indicates on/off by default, most parameters toggle.\n"
