// Copyright 1996 - 1997, Tim Hart.
// All rights reserved.
//
// Modem Resource Manager.
//
// Author: Tim Hart.
//
//	mrmglobals.h
//
//

// *************************************************************************
// device routines.
//
BOOL NewDevice(DEV_INFO_BASE *,char *);   // puts another device onto an existing linked list. 
BOOL DelDevice(DEV_INFO_BASE *,int); // delete device with given index.
DEV_INFO * GetDevice(DEV_INFO_BASE *,int);       // return device pointer for index Value Given. 
DEV_INFO_BASE * NewDeviceBase(void);  // create a new device base... for a new list.
BOOL DelDeviceBase(DEV_INFO_BASE *);   // delete memory used by device(s) in list.
//
// 
// **************************************************************************

// **************************************************************************
// name / limit / grace period routines.
// These are used if RANKING_BASED_DISCONNECT is defined instead of
// the group/limit/grace period routines below.

BOOL NewUser(USER_BASE *,char *,time_t,time_t,int);
BOOL DelUser(USER_BASE *,int);
USER_NODE * GetUser(USER_BASE *,int);
USER_BASE * NewUserBase(void);
BOOL DelUserBase(USER_BASE *);

//
//
// **************************************************************************

// **************************************************************************
// group / limit / grace period routines.
//
BOOL NewGLG(GLG_BASE *,gid_t,time_t,time_t,int);
BOOL DelGLG(GLG_BASE *,int);
GLG_NODE * GetGLG(GLG_BASE *,int);
GLG_BASE * NewGLGBase(void);
BOOL DelGLGBase(GLG_BASE *);
//
//
// **************************************************************************

// **************************************************************************
// Exempt user list routines.
//
BOOL NewExempt(EXEMPT_BASE *,char *);
BOOL DelExempt(EXEMPT_BASE *,int);
EXEMPT_NODE * GetExempt(EXEMPT_BASE *,int);
EXEMPT_BASE * NewExemptBase(void);
BOOL DelExemptBase(EXEMPT_BASE *);
//
//
// **************************************************************************

// **************************************************************************
// user kick list routines.
BOOL NewKick(KICK_BASE *,char *,time_t,time_t);
BOOL DelKick(KICK_BASE *,int);
KICK_NODE * GetKick(KICK_BASE *,int);
KICK_BASE * NewKickBase(void);
BOOL DelKickBase(KICK_BASE *);

// **************************************************************************
// Program routines.
//

int ConfigRead(DEV_INFO_BASE *,USER_BASE *,GLG_BASE *,EXEMPT_BASE *);
USERGLG UserInGLGList(GLG_BASE *,DEV_INFO_BASE *,int);
USERGID UserGroupId(char *);
USERKILL InKickList(KICK_BASE *,char *);

void SetDevices(DEV_INFO_BASE *,int *);
void SetUsers(USER_BASE *,int *);
void SetGLG(GLG_BASE *,int *);
void SetExempt(EXEMPT_BASE *,int *);
void KickListPurge(KICK_BASE *);
BOOL ReLoginCheck(DEV_INFO_BASE *,KICK_BASE *);
BOOL MultipleLoginKill(DEV_INFO_BASE *,USER_BASE *,GLG_BASE *);
void CmdLine(int, char **);
void UtmpRead(DEV_INFO_BASE *);
void DieTimeBandits(DEV_INFO_BASE *,USER_BASE *,GLG_BASE *,EXEMPT_BASE *,KICK_BASE *,int);
void RankingDieModule(DEV_INFO_BASE *,USER_BASE *,EXEMPT_BASE *,KICK_BASE *,int);

void LogMsg(char *);
void LogDebug(char *);
void LogKill(DEV_INFO_BASE *,int);
void LogReKill(DEV_INFO_BASE *,int,KICK_BASE *,int);

void Fatality(char *);
void cFill(char *,char,int);
void iFill(int *,int,int);

int TimeCheck(DEV_INFO_BASE *);
BOOL ExemptOnDevice(EXEMPT_BASE *,DEV_INFO_BASE *,int);
BOOL Occupied(DEV_INFO_BASE *,int);
BOOL Exempt(EXEMPT_BASE *,char *);

char * GetDay(int);
char * GetMonth(int);
char * User(DEV_INFO_BASE *,int);
char * Line(DEV_INFO_BASE *,int);
time_t LoginTime(DEV_INFO_BASE *,int);
DIVTIME_T DivTime(time_t);
int SignalHandle(int);
int LineNum(DEV_INFO_BASE *,char *);
char * OnlineInfoPos(ONLINE_INFO *,int);
ONLINE_INFO * UserOnline(DEV_INFO_BASE *,char *);
char * GetDeviceIdStr(ONLINE_INFO *,int);

BOOL ServerInit();
BOOL Connection();
BOOL RequestHandle(DEV_INFO_BASE *,USER_BASE *,KICK_BASE *,GLG_BASE *,EXEMPT_BASE *,int);

BOOL DebugSizeOk();


// **************************************************************************
// Globals
//
jmp_buf env;                             // needed for setjmp/longjmp
int iMinimumFree      =(int)MIN_FREE_DEVICES;  // number of devices to make sure are free.
int iLoopSleep        =(int)LOOP_SECOND_INTERVALS;  // sleep time in secs.
int iMaxClients       =(int)MAXCLIENTS;
int iMaxUserNameLength=(int)15;
int iDefaultWaitTime  =(int)15;
int iPppPapMonPeriod  =(int)PPP_MON_PERIOD;

BOOL CatchSigHup      =(BOOL)CATCH_SIGHUP;
BOOL ForkJob          =(BOOL)FORK;
BOOL Debug            =(BOOL)DEBUG_HIGH;
BOOL RealKill         =(BOOL)KILL_FOR_REAL;
BOOL Logging          =(BOOL)LOG_ACTIONS;
BOOL ExemptUserChecks =(BOOL)USE_EXEMPT;
BOOL RankingBased     =(BOOL)RANKING_BASED_DISCONNECT;
BOOL VisServer        =(BOOL)VIS_SERVER;
BOOL DebugLog         =(BOOL)FILE_DEBUG;
BOOL ExemptKillGuard  =(BOOL)KILL_EXEMPT_CHECKING;
BOOL RankingKillGuard =(BOOL)RANKING_KILL_GUARD;
BOOL PppPapMon        =(BOOL)PPP_PAP_MON;
    
char pUserToKill[15];
char pDevToFree[max_path_length+1];

time_t iClientTimeOut =(time_t)TIMEOUTSEC;
off_t iMaxBytesDebug  =(off_t)2097152;         // max size in bytes for debug file.

int ifromlength,s,ns,iNumClients=0;
struct sockaddr_un saun, fsaun;

//
//
// **************************************************************************
