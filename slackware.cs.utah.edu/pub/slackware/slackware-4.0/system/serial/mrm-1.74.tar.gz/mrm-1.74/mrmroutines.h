// Copyright 1996 - 1997, Tim Hart.
// All rights reserved.
//
// Modem Resource Manager.
//
// Author: Tim Hart.
//
//	mrmroutines.h
//
//


DEV_INFO * GetDevice(DEV_INFO_BASE * pLinkedList,int DeviceIndex)
{
    int i;
    DEV_INFO * pStore;

    if ((DeviceIndex>(pLinkedList->NumberOfDevices))|(DeviceIndex<1))
    {
        if (DebugLog) LogDebug("NULL RETURN! getdevice top");
        return NULL;
    }
    i=1;
    pStore=pLinkedList->pFirstDevice;
    while ((pStore->pNextDevice)&&(i<DeviceIndex))
    {
        pStore=pStore->pNextDevice;
        i++;
    }
    if (!pStore)
    {
        if (DebugLog) LogDebug("NULL RETURN! getdevice bottom");
        return NULL;
    }

    return pStore;
}

BOOL NewDevice(DEV_INFO_BASE * pLinkedList,char * pDeviceIdIn)
{
    int i;
    DEV_INFO * pNewDevice;

    pNewDevice=(DEV_INFO *)malloc(sizeof(DEV_INFO));
    pNewDevice->pDeviceId=(char *)malloc(sizeof(char)*(max_path_length+1));
        
    if ((pNewDevice)&&(pNewDevice->pDeviceId))
    {
        // null fill.
        cFill(pNewDevice->pDeviceId,'\0',max_path_length+1);
        for (i=0;i<max_path_length;i++) (pNewDevice->pDeviceId)[i]=pDeviceIdIn[i];
        pNewDevice->pNextDevice=NULL;
        pNewDevice->DevIndex=(pLinkedList->NumberOfDevices)+1;
        if (!pLinkedList->pLastDevice) pLinkedList->pFirstDevice=pNewDevice; // first node made.
        else pLinkedList->pLastDevice->pNextDevice=pNewDevice; // all others.
        (pLinkedList->NumberOfDevices)++;
        pLinkedList->pLastDevice=pNewDevice;// end points to the new end node, as it should.
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

DEV_INFO_BASE * NewDeviceBase(void)
{
    DEV_INFO_BASE * pNewBDevice;

    pNewBDevice=(DEV_INFO_BASE *)malloc(sizeof(DEV_INFO_BASE));
    if (pNewBDevice)
    {
        pNewBDevice->pFirstDevice=NULL;
        pNewBDevice->pLastDevice=NULL;
        pNewBDevice->NumberOfDevices=0;
        return pNewBDevice;
    }
    else
    {
        if (DebugLog) LogDebug("NULL RETURN! new device base");
        //exit(0);
        return NULL;
    }

}

BOOL DelDeviceBase(DEV_INFO_BASE * pListToDelete)
{
    // destroy list. start from end node, work inwards.
    int i;
    BOOL bFlag;

    bFlag=TRUE;
    if (pListToDelete)
    {
        for (i=pListToDelete->NumberOfDevices;i>0;i--)
        {
            if (!DelDevice(pListToDelete,i))
            {
                bFlag=FALSE;
                break;
            }
        }
        free(pListToDelete);
    }
    return bFlag;
}

BOOL DelDevice(DEV_INFO_BASE * pList,int DeviceToDelete)
{
    // delete specified node.. AND make previous node point to
    // the specified nodes successor. (take a link out and rejoin it.)
    // if the last node is to be deleted from the list then the prev.
    // node's pNext is set to NULL, as GetNode() should return NULL on
    // a Node Greater than the max number of nodes in the list.

    if ((DeviceToDelete>pList->NumberOfDevices)||(DeviceToDelete<1)) return FALSE;
    free(GetDevice(pList,DeviceToDelete)->pDeviceId);
    free(GetDevice(pList,DeviceToDelete));

    if (DeviceToDelete==pList->NumberOfDevices)
    {
        // MAKE SURE MORE THAN ONE NODE IN LIST!
        if (pList->NumberOfDevices>1)
        {
            GetDevice(pList,DeviceToDelete-1)->pNextDevice=NULL; // new last node.
            pList->pLastDevice=GetDevice(pList,DeviceToDelete-1);
        }
        else
        {
            pList->pFirstDevice=NULL; // no more nodes.
            pList->pLastDevice=NULL;
        }
    }
    else
    {
        if (DeviceToDelete==1) // deleting first node...
        {
            // make base ptr point to the second node...
            pList->pFirstDevice=GetDevice(pList,2);
        }
        else
        {
            GetDevice(pList,DeviceToDelete-1)->pNextDevice=GetDevice(pList,DeviceToDelete+1);
        }
    }


    (pList->NumberOfDevices)--;  // one less node.
    return TRUE;
}

//
//
//
//
//
// USER RANKING ROUTINES.
//
//
//
//
//
//
//
//
//

USER_NODE * GetUser(USER_BASE * pLinkedList,int UserIndex)
{
    int i;
    USER_NODE * pStore;

    if ((UserIndex>pLinkedList->NumberOfUsers)|(UserIndex<1))
    {
        if (DebugLog) LogDebug("NULL RETURN! getUser top");
        //exit(0);
        return NULL;
    }

    i=1;
    pStore=pLinkedList->pFirstUser;
    while ((pStore->pNextUser)&&(i<UserIndex))
    {
        pStore=pStore->pNextUser;
        i++;
    }
    if (!pStore)
    {
        if (DebugLog) LogDebug("NULL RETURN! getUser bottom");
        //exit(0);
        return NULL;
    }
    return pStore;
}
	
BOOL NewUser(USER_BASE * pLinkedList,char * pUser,time_t limit,time_t grace,int logins)
{
    USER_NODE * pNewUser;
    int i;

    pNewUser=(USER_NODE *)malloc(sizeof(USER_NODE));
    if (pNewUser)
    {
        cFill(pNewUser->pUser,'\0',UT_NAMESIZE+1);
        for (i=0;i<UT_NAMESIZE;i++) pNewUser->pUser[i]=pUser[i];
        pNewUser->online_limit=limit;
        pNewUser->wait_limit=grace;
        if (logins>=0) pNewUser->iMaxLogins=logins;   // else iMaxLogins defaults to 1.
        else pNewUser->iMaxLogins=1;
        pNewUser->pNextUser=NULL;
        pNewUser->UserIndex=(pLinkedList->NumberOfUsers)+1;
        if (!pLinkedList->pLastUser) pLinkedList->pFirstUser=pNewUser; // first node made.
        else pLinkedList->pLastUser->pNextUser=pNewUser; // all others.
        (pLinkedList->NumberOfUsers)++;
        pLinkedList->pLastUser=pNewUser;// end points to the new end node, as it should.
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

USER_BASE * NewUserBase(void)
{
    USER_BASE * pNewBUser;

    pNewBUser=(USER_BASE *)malloc(sizeof(USER_BASE));
    if (pNewBUser)
    {
        pNewBUser->pFirstUser=NULL;
        pNewBUser->pLastUser=NULL;
        pNewBUser->NumberOfUsers=0;
        return pNewBUser;
    }
    else
    {
        if (DebugLog) LogDebug("NULL RETURN! new base User");
        //exit(0);
        return NULL;
    }

}

BOOL DelUserBase(USER_BASE * pListToDelete)
{
    // destroy list. start from end node, work inwards.
    int i;
    BOOL bFlag;

    bFlag=TRUE;
    if (pListToDelete)
    {
        for (i=pListToDelete->NumberOfUsers;i>0;i--)
        {
            if (!DelUser(pListToDelete,i)) bFlag=FALSE;
        }
        free(pListToDelete);
    }
    return bFlag;
}

BOOL DelUser(USER_BASE * pList,int UserToDelete)
{
    // delete specified node.. AND make previous node point to
    // the specified nodes successor. (take a link out and rejoin it.)
    // if the last node is to be deleted from the list then the prev.
    // node's pNext is set to NULL, as GetNode() should return NULL on
    // a Node Greater than the max number of nodes in the list.

    if ((UserToDelete>pList->NumberOfUsers)||(UserToDelete<1)) return FALSE;
    free(GetUser(pList,UserToDelete));

    if (UserToDelete==pList->NumberOfUsers)
    {
        // MAKE SURE MORE THAN ONE NODE IN LIST!
        if (pList->NumberOfUsers>1)
        {
            GetUser(pList,UserToDelete-1)->pNextUser=NULL; // new last node.
            pList->pLastUser=GetUser(pList,UserToDelete-1);
        }
        else
        {
            pList->pFirstUser=NULL; // no more nodes.
            pList->pLastUser=NULL;
        }
    }
    else
    {
        if (UserToDelete==1) // deleting first node...
        {
            // make base ptr point to the second node...
            pList->pFirstUser=GetUser(pList,2);
        }
        else
        {
            GetUser(pList,UserToDelete-1)->pNextUser=GetUser(pList,UserToDelete+1);
        }
    }
    (pList->NumberOfUsers)--;  // one less node.
    return TRUE;
}


//
//
//
//
//
// GLG ROUTINES.
//
//
//
//
//
//
//
//
//

GLG_NODE * GetGLG(GLG_BASE * pLinkedList,int GLGIndex)
{
    int i;
    GLG_NODE * pStore;

    if ((GLGIndex>pLinkedList->NumberOfGLG)|(GLGIndex==0))
    {
        if (DebugLog) LogDebug("NULL RETURN! getGLG top");
        //exit(0);
        return NULL;
    }

    i=1;
    pStore=pLinkedList->pFirstGLG;
    while ((pStore->pNextGLG)&&(i<GLGIndex))
    {
        pStore=pStore->pNextGLG;
        i++;
    }
    if (!pStore)
    {
        if (DebugLog) LogDebug("NULL RETURN! getGLG bottom\n");
        //exit(0);
        return NULL;
    }
    return pStore;
}
	
BOOL NewGLG(GLG_BASE * pLinkedList,gid_t group,time_t limit,time_t grace,int logins)
{
    GLG_NODE * pNewGLG;

    pNewGLG=(GLG_NODE *)malloc(sizeof(GLG_NODE));
    if (pNewGLG)
    {
        pNewGLG->group_id=group;  		// GLG specifics.
        pNewGLG->group_limit=limit;
        pNewGLG->group_grace=grace;
        if (logins>=0) pNewGLG->iMaxLogins=logins;   // else iMaxLogins defaults to 1.
        else pNewGLG->iMaxLogins=1;
        pNewGLG->pNextGLG=NULL;
        pNewGLG->GLGIndex=(pLinkedList->NumberOfGLG)+1;
        if (!pLinkedList->pLastGLG) pLinkedList->pFirstGLG=pNewGLG; // first node made.
        else pLinkedList->pLastGLG->pNextGLG=pNewGLG; // all others.
        (pLinkedList->NumberOfGLG)++;
        pLinkedList->pLastGLG=pNewGLG;// end points to the new end node, as it should.
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

GLG_BASE * NewGLGBase(void)
{
    GLG_BASE * pNewBGLG;

    pNewBGLG=(GLG_BASE *)malloc(sizeof(GLG_BASE));
    if (pNewBGLG)
    {
        pNewBGLG->pFirstGLG=NULL;
        pNewBGLG->pLastGLG=NULL;
        pNewBGLG->NumberOfGLG=0;
        return pNewBGLG;
    }
    else
    {
        if (DebugLog) LogDebug("NULL RETURN! new base GLG");
        return NULL;
    }

}

BOOL DelGLGBase(GLG_BASE * pListToDelete)
{
    // destroy list. start from end node, work inwards.
    int i;
    BOOL bFlag;

    bFlag=TRUE;
    if (pListToDelete)
    {
        for (i=(pListToDelete->NumberOfGLG);i>0;i--)
        {
            if (!DelGLG(pListToDelete,i)) bFlag=FALSE;
        }
        free(pListToDelete);
    }
    return bFlag;
}

BOOL DelGLG(GLG_BASE * pList,int GLGToDelete)
{
    // delete specified node.. AND make previous node point to
    // the specified nodes successor. (take a link out and rejoin it.)
    // if the last node is to be deleted from the list then the prev.
    // node's pNext is set to NULL, as GetNode() should return NULL on
    // a Node Greater than the max number of nodes in the list.

    if ((GLGToDelete>pList->NumberOfGLG)||(GLGToDelete<1)) return FALSE;
    free(GetGLG(pList,GLGToDelete));

    if (GLGToDelete==pList->NumberOfGLG)
    {
        // MAKE SURE MORE THAN ONE NODE IN LIST!
        if (pList->NumberOfGLG>1)
        {
            GetGLG(pList,GLGToDelete-1)->pNextGLG=NULL; // new last node.
            pList->pLastGLG=GetGLG(pList,GLGToDelete-1);
        }
        else
        {
            pList->pFirstGLG=NULL; // no more nodes.
            pList->pLastGLG=NULL;
        }
    }
    else
    {
        if (GLGToDelete==1) // deleting first node...
        {
            // make base ptr point to the second node...
            pList->pFirstGLG=GetGLG(pList,2);
        }
        else
        {
            GetGLG(pList,GLGToDelete-1)->pNextGLG=GetGLG(pList,GLGToDelete+1);
        }
    }
    (pList->NumberOfGLG)--;  // one less node.
    return TRUE;
}



//
//
//
//
//	Exempt USER ROUTINES.
//
//
//
//
EXEMPT_NODE * GetExempt(EXEMPT_BASE * pLinkedList,int ExemptIndex)
{
    int i;
    EXEMPT_NODE * pStore;

    if ((ExemptIndex>pLinkedList->NumberExempt)|(ExemptIndex==0))
    {
        if (DebugLog) LogDebug("NULL RETURN! get exempt top");
        //exit(0);
        return NULL;
    }
    i=1;
    pStore=pLinkedList->pFirstExempt;
    while ((pStore->pNextExempt)&&(i<ExemptIndex))
    {
        pStore=pStore->pNextExempt;
        i++;
    }
    if (!pStore)
    {
        if (DebugLog) LogDebug("NULL RETURN! get exempt bottom");
        //exit(0);
        return NULL;
    }

    return pStore;
}

BOOL NewExempt(EXEMPT_BASE * pLinkedList,char * pExemptUser)
{
    int i;
    EXEMPT_NODE * pNewExempt;

    pNewExempt=(EXEMPT_NODE *)malloc(sizeof(EXEMPT_NODE));
    pNewExempt->pExemptUser=(char *)malloc(sizeof(char)*(UT_NAMESIZE+1));
    
    if ((pNewExempt)&&(pNewExempt->pExemptUser))
    {
        pNewExempt->pExemptUser=(char *)malloc(sizeof(char)*(UT_NAMESIZE+1));
        // fill with null
        cFill(pNewExempt->pExemptUser,'\0',UT_NAMESIZE+1);
        for (i=0;i<UT_NAMESIZE;i++) (pNewExempt->pExemptUser)[i]=pExemptUser[i];
        pNewExempt->pNextExempt=NULL;
        pNewExempt->ExemptIndex=(pLinkedList->NumberExempt)+1;
        if (!pLinkedList->pLastExempt) pLinkedList->pFirstExempt=pNewExempt; // first node made.
        else pLinkedList->pLastExempt->pNextExempt=pNewExempt; // all others.
        (pLinkedList->NumberExempt)++;
        pLinkedList->pLastExempt=pNewExempt;// end points to the new end node, as it should.
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

EXEMPT_BASE * NewExemptBase(void)
{
    EXEMPT_BASE * pNewBExempt;

    pNewBExempt=(EXEMPT_BASE *)malloc(sizeof(EXEMPT_BASE));
    if (pNewBExempt)
    {
        pNewBExempt->pFirstExempt=NULL;
        pNewBExempt->pLastExempt=NULL;
        pNewBExempt->NumberExempt=0;
        return pNewBExempt;
    }
    else
    {
        if (DebugLog) LogDebug("NULL RETURN! new base exempt");
        //exit(0);
        return NULL;
    }

}

BOOL DelExemptBase(EXEMPT_BASE * pListToDelete)
{
    // destroy list. start from end node, work inwards.
    int i;
    BOOL bFlag;

    bFlag=TRUE;
    if (pListToDelete)
    {
        for (i=(pListToDelete->NumberExempt);i>0;i--)
        {
            if (!DelExempt(pListToDelete,i)) bFlag=FALSE;
        }
    free(pListToDelete);
    }
    return bFlag;
}

BOOL DelExempt(EXEMPT_BASE * pList,int ExemptToDelete)
{

    if ((ExemptToDelete>pList->NumberExempt)||(ExemptToDelete<1)) return FALSE;
    free(GetExempt(pList,ExemptToDelete)->pExemptUser);
    free(GetExempt(pList,ExemptToDelete));

    if (ExemptToDelete==pList->NumberExempt)
    {
        // MAKE SURE MORE THAN ONE NODE IN LIST!
        if (pList->NumberExempt>1)
        {
            GetExempt(pList,ExemptToDelete-1)->pNextExempt=NULL; // new last node.
            pList->pLastExempt=GetExempt(pList,ExemptToDelete-1);
        }
        else
        {
            pList->pFirstExempt=NULL; // no more nodes.
            pList->pLastExempt=NULL;
        }
    }
    else
    {
        if (ExemptToDelete==1) // deleting first node...
        {
            // make base ptr point to the second node...
            pList->pFirstExempt=GetExempt(pList,2);
        }
        else
        {
            GetExempt(pList,ExemptToDelete-1)->pNextExempt=GetExempt(pList,ExemptToDelete+1);
        }
    }
    (pList->NumberExempt)--;  // one less node.
    return TRUE;
}

//
//
//
//
// kick list routines.
//
//
//
//

KICK_NODE * GetKick(KICK_BASE * pLinkedList,int KickIndex)
{
    int i;
    KICK_NODE * pStore;

    if ((KickIndex>(pLinkedList->NumberOfKicks))|(KickIndex<1))
    {
        if (DebugLog) LogDebug("NULL RETURN! get kick top\n");
        //exit(0);
        return NULL;
    }
    i=1;
    pStore=pLinkedList->pFirstKick;
    while ((pStore->pNextKick)&&(i<KickIndex))
    {
        pStore=pStore->pNextKick;
        i++;
    }
    if (!pStore)
    {
        if (DebugLog) LogDebug("NULL RETURN! get kick bottom");
        //exit(0);
        return NULL;
    }
    return pStore;
}

BOOL NewKick(KICK_BASE * pLinkedList,char * pKickUser,time_t KilledTime,time_t GraceWaitTime)
{
    int i;
    KICK_NODE * pNewKick;


    pNewKick=(KICK_NODE *)malloc(sizeof(KICK_NODE));
    pNewKick->pKickUser=(char *)malloc(sizeof(char)*(UT_NAMESIZE+1));
        
    if ((pNewKick)&&(pNewKick->pKickUser))
    {
        cFill(pNewKick->pKickUser,'\0',(UT_NAMESIZE+1));
        for (i=0;i<UT_NAMESIZE;i++) (pNewKick->pKickUser)[i]=pKickUser[i];
        pNewKick->KickTime=KilledTime;
        pNewKick->GracePeriod=GraceWaitTime;
        pNewKick->NumReKicks=0;
        pNewKick->pNextKick=NULL;
        pNewKick->KickIndex=(pLinkedList->NumberOfKicks)+1;
        if (!pLinkedList->pLastKick) pLinkedList->pFirstKick=pNewKick; // first node made.
        else pLinkedList->pLastKick->pNextKick=pNewKick; // all others.
        (pLinkedList->NumberOfKicks)++;
        pLinkedList->pLastKick=pNewKick;// end points to the new end node, as it should.
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

KICK_BASE * NewKickBase(void)
{
    KICK_BASE * pNewBKick;

    pNewBKick=(KICK_BASE *)malloc(sizeof(KICK_BASE));
    if (pNewBKick)
    {
        pNewBKick->pFirstKick=NULL;
        pNewBKick->pLastKick=NULL;
        pNewBKick->NumberOfKicks=0;
        return pNewBKick;
    }
    else
    {
        if (DebugLog) LogDebug("NULL RETURN! new base kick");
        //exit(0);
        return NULL;
    }

}

BOOL DelKickBase(KICK_BASE * pListToDelete)
{
    // destroy list. start from end node, work inwards.
    int i;
    BOOL bFlag;

    bFlag=TRUE;
    if (pListToDelete)
    {
        for (i=(pListToDelete->NumberOfKicks);i>0;i--)
        {
            if (!DelKick(pListToDelete,i)) bFlag=FALSE;
        }
    free(pListToDelete);
    }
    return bFlag;
}

BOOL DelKick(KICK_BASE * pList,int KickToDelete)
{

    if ((KickToDelete>pList->NumberOfKicks)|(KickToDelete<1)) return FALSE;
    free(GetKick(pList,KickToDelete)->pKickUser);
    free(GetKick(pList,KickToDelete));

    if (KickToDelete==pList->NumberOfKicks)
    {
        // MAKE SURE MORE THAN ONE NODE IN LIST!
        if (pList->NumberOfKicks>1)
        {
            GetKick(pList,KickToDelete-1)->pNextKick=NULL; // new last node.
            pList->pLastKick=GetKick(pList,KickToDelete-1);
        }
        else
        {
            pList->pFirstKick=NULL; // no more nodes.
            pList->pLastKick=NULL;
        }
    }
    else
    {
        if (KickToDelete==1) // deleting first node...
        {
            // make base ptr point to the second node...
            pList->pFirstKick=GetKick(pList,2);
        }
        else
        {
            GetKick(pList,KickToDelete-1)->pNextKick=GetKick(pList,KickToDelete+1);
        }
    }
    (pList->NumberOfKicks)--;  // one less node.
    return TRUE;
}

// Online_Info Walker.

char * OnlineInfoPos(ONLINE_INFO * pOnlineInfo,int iPosition)
{
    ONLINE_INFO * pNext;

    // bounds check.
    if ((iPosition>(pOnlineInfo->iNumLogins))||(iPosition<1)) return NULL;
    if (iPosition==1) return pOnlineInfo->pDeviceId;
    // 2 or more logins present..
    pNext=pOnlineInfo;
    while (iPosition>1)
    {
        pNext=pNext->pNextLogin;
        iPosition--;
    }
    return (pNext->pDeviceId);
}

// free up for the online_info struct

void FreeInfo(ONLINE_INFO * pOnlineInfo)
{
    int i,iNodes;
    ONLINE_INFO * Travel;

    if (Debug) if (DebugLog) LogDebug("FreeInfo() Start");
    if (pOnlineInfo)
    {
        // core dump watch here.
        Travel=pOnlineInfo;
        iNodes=pOnlineInfo->iNumLogins;

        // free the space taken by each node of the list.
        while (iNodes>0)
        {
            for (i=1;i<iNodes;i++) Travel=Travel->pNextLogin;
            // now travel is at the end-most pointer.
            free(Travel);
            Travel=pOnlineInfo;   // put travel back at starting pointer.
            iNodes--;
        }
    }
    if (Debug) if (DebugLog) LogDebug("FreeInfo() End");
}

char * GetDeviceIdStr(ONLINE_INFO * pUserInfo,int iLoginIndex)
{
    ONLINE_INFO * travellor;
    int i;
    
    if ((iLoginIndex>(pUserInfo->iNumLogins))||(i<1)) return NULL;
        
    travellor=pUserInfo;
    
    for (i=1;i<iLoginIndex;i++)
        travellor=travellor->pNextLogin;

    return (travellor->pDeviceId);
}
// Online_Info retriever.

ONLINE_INFO * UserOnline(DEV_INFO_BASE * pDeviceList,char * pUser)
{
    int i,iNumLogins;
    ONLINE_INFO * pOnlineInfoTemp;
    ONLINE_INFO * pNewEntry;
    
    iNumLogins=0;
    // if the username matches, and also if online flag set.
    if (DebugLog) LogDebug("UserOnline() Start");
    for (i=0;i<pDeviceList->NumberOfDevices;i++)
    {
        if (strncmp(pUser,User(pDeviceList,i+1),UT_NAMESIZE)==0)
        {
            if (Debug) printf("Username Match %s, Device Number %d\n",pUser,i+1);
            if (Occupied(pDeviceList,i+1))
            {
                // ok, this device is in use.
                iNumLogins++;
                pNewEntry=(ONLINE_INFO *)malloc(sizeof(ONLINE_INFO));
                pNewEntry->pDeviceId=Line(pDeviceList,i+1);
                pNewEntry->iNumLogins=iNumLogins;
                if (iNumLogins==1) pOnlineInfoTemp=pNewEntry;
                else pOnlineInfoTemp->pNextLogin=pNewEntry;
            }
        }
    }
    if (!iNumLogins) return NULL;
    else
    {
        pOnlineInfoTemp->iNumLogins=iNumLogins;
        if (Debug) printf("inside... user has %d logins.\n",pOnlineInfoTemp->iNumLogins);
        return pOnlineInfoTemp;
    }
    if (DebugLog) LogDebug("UserOnline() End");
}

//
//
//
//
//
//
//
//
//




int ConfigRead(DEV_INFO_BASE * pDeviceList,USER_BASE * pUserList,GLG_BASE * pGLGList,EXEMPT_BASE * pExemptList)
{
    // config file read module.
    FILE * pTmpFp;
    long lTmpLen,lTtyLen,lUserLen,lGLGLen,lExemptLen;
    int * pTmpBuffer, * pTtyBuffer, * pUserBuffer, * pGLGBuffer, * pExemptBuffer;
    int i=0,ii=0,iii=0,tmp_buf=0,index=0,tmpbound; // parsing.
    char * pTmpPath;


    tmpbound=0;
    if (ExemptUserChecks) tmpbound=3;
    else tmpbound=2;
    for(i=0;i<tmpbound;i++)
    {
        switch (i)
        {
        case 0:
            pTmpPath=tty_path;
            break;
        case 1:
            if (RankingBased) pTmpPath=ranking_path;
            else pTmpPath=group_path;
            break;
        case 2:
            pTmpPath=exempt_path;
            break;
        }

        if ((pTmpFp=fopen(pTmpPath,"r"))==NULL)
        {
            printf("error opening %s for read.\n",pTmpPath);
            exit(1);
        }

        // get length of the file.
        fseek(pTmpFp,0,SEEK_END);
        lTmpLen=ftell(pTmpFp);
        if (Debug) printf("Open for read, %s, %d, bytes.\n",pTmpPath,lTmpLen);
        rewind(pTmpFp);
        //create int buffer.
        pTmpBuffer=(int *)malloc(sizeof(int)*(lTmpLen+1));
        if (!pTmpBuffer) Fatality("MALLOC FAIL pTmpBuffer.\n");
        // set all to null.
        iFill(pTmpBuffer,'\0',(lTmpLen+1));
        //read file into buffer.
        index=0;
        ii=0;
        while (ii<lTmpLen)
        {
            //if '#' is found skip until '\n' is reached.
            if ((tmp_buf=fgetc(pTmpFp))=='#') while ((tmp_buf=fgetc(pTmpFp))!='\n') ii++;
            else
            {
                pTmpBuffer[index]=(char)tmp_buf;
                ii++;
                index++;
            }
        }
        // done with file.
        fclose(pTmpFp);

        // get rid of trailing white space.
        while ((pTmpBuffer[index]==EOF)||(pTmpBuffer[index]==' ')||(pTmpBuffer[index]=='\n')||(pTmpBuffer[index]=='\0')) index--;
        index++;
        pTmpBuffer[index]='\0';
        switch (i)
        {
        case 0:
            lTtyLen=index;
            pTtyBuffer=(int *)malloc(sizeof(int)*(lTtyLen+1));
            if (!pTtyBuffer) Fatality("pTtyBuffer MALLOC FAIL.\n");
            iFill(pTtyBuffer,'\0',(lTtyLen+1));
            for (ii=0;ii<lTtyLen;ii++) pTtyBuffer[ii]=pTmpBuffer[ii];
            break;
        case 1:
            if (RankingBased)
            {
                lUserLen=index;
                pUserBuffer=(int *)malloc(sizeof(int)*(lUserLen+1));
                if (!pUserBuffer) Fatality("pUserBuffer MALLOC FAIL.\n");
                iFill(pUserBuffer,'\0',(lUserLen+1));
                for (ii=0;ii<lUserLen;ii++) pUserBuffer[ii]=pTmpBuffer[ii];
            }
            else
            {
                lGLGLen=index;
                pGLGBuffer=(int *)malloc(sizeof(int)*(lGLGLen+1));
                if (!pGLGBuffer) Fatality("pGLGBuffer MALLOC FAIL.\n");
                iFill(pGLGBuffer,'\0',(lGLGLen+1));
                for (ii=0;ii<lGLGLen;ii++) pGLGBuffer[ii]=pTmpBuffer[ii];
            }
            break;
        case 2:
            lExemptLen=index;
            pExemptBuffer=(int *)malloc(sizeof(int)*(lExemptLen+1));
            if (!pExemptBuffer) Fatality("pExemptBuffer MALLOC FAIL.\n");
            iFill(pExemptBuffer,'\0',(lExemptLen+1));
            for (ii=0;ii<lExemptLen;ii++) pExemptBuffer[ii]=pTmpBuffer[ii];
            break;
        }
        // file now in buffer.
        free(pTmpBuffer);
    }
    // initialize the various lists.
    if (Debug) printf("setup() routines\n");
    if (DebugLog) LogDebug("setup routines.\n");
    SetDevices(pDeviceList,pTtyBuffer);
    if (RankingBased) SetUsers(pUserList,pUserBuffer);
    else SetGLG(pGLGList,pGLGBuffer);
    if (ExemptUserChecks) SetExempt(pExemptList,pExemptBuffer);
    // free Buffers
    if (Debug) printf("Freeing buffers\n");
    free(pExemptBuffer);
    if (Debug) printf("Exemptbuf freed\n");
    free(pTtyBuffer);
    if (Debug) printf("ttybuf freed\n");
    if (RankingBased) free(pUserBuffer);
    else free(pGLGBuffer);
    if (Debug) printf("GLGbuf freed\n");
    if (DebugLog) LogDebug("configread() end");
}

void SetDevices(DEV_INFO_BASE * pDeviceList,int * pTtyBuffer)
{
    // setup the Devices.
    //
    //
    //

    int i,ii;
    char * pDeviceId;

    pDeviceId=(char *)malloc(sizeof(char)*(max_path_length+1));
    if (!pDeviceId) Fatality("NULL pDeviceId!\n");

    cFill(pDeviceId,'\0',(max_path_length+1));      // nullify :)
    i=0;
    if (Debug) printf("Scanned Device(s): ");
    while (pTtyBuffer[i]!='\0')  // stop at end of buffer
    {
        while (pTtyBuffer[i]=='\n') i++;
        if (pTtyBuffer[i]=='\0') break;
        for (ii=0;ii<max_path_length;ii++)
        {
            pDeviceId[ii]=(char)pTtyBuffer[i];
            i++;
            if ((pTtyBuffer[i]=='\n')||(pTtyBuffer[i]=='\0')) break;
        }
        if (Debug) printf("%s, ",pDeviceId);
        NewDevice(pDeviceList,pDeviceId);
        cFill(pDeviceId,'\0',(max_path_length+1));
    }
    if (Debug) printf(".\n");
    free(pDeviceId);
} // setup_devices

void SetUsers(USER_BASE * pUserList,int * pUserBuffer)
{
    // setup the UserList.
    //
    //
    //

    int i=0,ii=0,MaxLogins;
    time_t TimeLimit,Grace;
    char * pName, * pTimeLimit, * pGrace, * pMaxLogins;

    pName=(char *)malloc(sizeof(char)*(UT_NAMESIZE+1));
    if (!pName) Fatality("pName MALLOC FAIL.\n");
    pTimeLimit=(char *)malloc(sizeof(char)*(MAX_FIELD_LENGTH+1));
    if (!pTimeLimit) Fatality("pTimeLimit MALLOC FAIL.\n");
    pGrace=(char *)malloc(sizeof(char)*(MAX_FIELD_LENGTH+1));
    if (!pGrace) Fatality("pGrace MALLOC FAIL.\n");
    pMaxLogins=(char *)malloc(sizeof(char)*(MAX_FIELD_LENGTH+1));
    if (!pMaxLogins) Fatality("pMaxLogins MALLOC FAIL.\n");
    

    // nullify all.
    cFill(pName,'\0',(UT_NAMESIZE+1));
    cFill(pTimeLimit,'\0',(MAX_FIELD_LENGTH+1));
    cFill(pGrace,'\0',(MAX_FIELD_LENGTH+1));
    cFill(pMaxLogins,'\0',(MAX_FIELD_LENGTH+1));
    i=0;
    if (Debug) printf("Scanned Users: ");
    while (pUserBuffer[i]!='\0')  // stop at end of buffer.
    {
        while (pUserBuffer[i]=='\n') i++;
        ii=0;
        if (pUserBuffer[i]==',') Fatality("User NULL FIELD DETECTED!");
        while ((pUserBuffer[i]!=',')&&(pUserBuffer[i]!=':')&&(ii<=UT_NAMESIZE))
        {
            pName[ii]=(char)pUserBuffer[i];
            i++;
            ii++;
        }
        i++;
        ii=0;
        while ((pUserBuffer[i]!=',')&&(pUserBuffer[i]!=':')&&(ii<=MAX_FIELD_LENGTH))
        {
            pTimeLimit[ii]=(char)pUserBuffer[i];
            i++;
            ii++;
        }
        i++;
        ii=0;
        while ((pUserBuffer[i]!=',')&&(pUserBuffer[i]!=':')&&(ii<=MAX_FIELD_LENGTH))
        {
            pGrace[ii]=(char)pUserBuffer[i];
            i++;
            ii++;
        }
        ii=0;
        while ((pUserBuffer[i]!='\n')&&(pUserBuffer[i]!='\0')&&(ii<=MAX_FIELD_LENGTH))
        {
            pMaxLogins[ii]=(char)pUserBuffer[i];
            i++;
            ii++;
        }
        // now convert value(s) to long integer(s) etc
        TimeLimit=(time_t)strtol(pTimeLimit,NULL,10);
        Grace=(time_t)strtol(pGrace,NULL,10);
        MaxLogins=(int)strtol(pMaxLogins,NULL,10);
        if (Debug) printf("%s, ",pName);
        NewUser(pUserList,pName,TimeLimit,Grace,MaxLogins);
        // nullify
        cFill(pName,'\0',(UT_NAMESIZE+1));
        cFill(pTimeLimit,'\0',(MAX_FIELD_LENGTH+1));
        cFill(pGrace,'\0',(MAX_FIELD_LENGTH+1));
        cFill(pMaxLogins,'\0',(MAX_FIELD_LENGTH+1));
    }
    if (Debug) printf(".\n");
    free(pGrace);
    free(pTimeLimit);
    free(pName);
    free(pMaxLogins);
    if (Debug) printf("End SetUsers()\n");
}

void SetGLG(GLG_BASE * pGLGList,int * pGLGBuffer)
{
    // setup the GLG
    //
    //
    //

    int i=0,ii=0,MaxLogins;
    gid_t GroupId;
    time_t TimeLimit,Grace;
    char * pGroupId, * pTimeLimit, * pGrace, * pMaxLogins;

    pGroupId=(char *)malloc(sizeof(char)*(MAX_FIELD_LENGTH+1));
    if (!pGroupId) Fatality("pGroupId MALLOC FAIL.\n");
    pTimeLimit=(char *)malloc(sizeof(char)*(MAX_FIELD_LENGTH+1));
    if (!pTimeLimit) Fatality("pTimeLimit MALLOC FAIL.\n");
    pGrace=(char *)malloc(sizeof(char)*(MAX_FIELD_LENGTH+1));
    if (!pGrace) Fatality("pGrace MALLOC FAIL.\n");
    pMaxLogins=(char *)malloc(sizeof(char)*(MAX_FIELD_LENGTH+1));
    if (!pMaxLogins) Fatality("pMaxLogins MALLOC FAIL.\n");
    

    // nullify all.
    cFill(pGroupId,'\0',(MAX_FIELD_LENGTH+1));
    cFill(pTimeLimit,'\0',(MAX_FIELD_LENGTH+1));
    cFill(pGrace,'\0',(MAX_FIELD_LENGTH+1));
    cFill(pMaxLogins,'\0',(MAX_FIELD_LENGTH+1));
    i=0;
    while (pGLGBuffer[i]!='\0')  // stop at end of buffer.
    {
        while (pGLGBuffer[i]=='\n') i++;
        ii=0;
        if (pGLGBuffer[i]==',') Fatality("GLG NULL FIELD DETECTED!");
        while ((pGLGBuffer[i]!=',')&&(pGLGBuffer[i]!=':'))
        {
            pGroupId[ii]=(char)pGLGBuffer[i];
            i++;
            ii++;
        }
        i++;
        ii=0;
        while ((pGLGBuffer[i]!=',')&&(pGLGBuffer[i]!=':'))
        {
            pTimeLimit[ii]=(char)pGLGBuffer[i];
            i++;
            ii++;
        }
        i++;
        ii=0;
        while ((pGLGBuffer[i]!=',')&&(pGLGBuffer[i]!=':'))
        {
            pGrace[ii]=(char)pGLGBuffer[i];
            i++;
            ii++;
        }
        ii=0;
        while ((pGLGBuffer[i]!='\n')&&(pGLGBuffer[i]!='\0'))
        {
            pMaxLogins[ii]=(char)pGLGBuffer[i];
            i++;
            ii++;
        }
        // now convert value(s) to long integer(s) etc.
        GroupId=(gid_t)strtol(pGroupId,NULL,10);
        TimeLimit=(time_t)strtol(pTimeLimit,NULL,10);
        Grace=(time_t)strtol(pGrace,NULL,10);
        MaxLogins=(int)strtol(pMaxLogins,NULL,10);
        
        NewGLG(pGLGList,GroupId,TimeLimit,Grace,MaxLogins);
        // nullify
        cFill(pGroupId,'\0',(MAX_FIELD_LENGTH+1));
        cFill(pTimeLimit,'\0',(MAX_FIELD_LENGTH+1));
        cFill(pGrace,'\0',(MAX_FIELD_LENGTH+1));
        cFill(pMaxLogins,'\0',(MAX_FIELD_LENGTH+1));
    }
    free(pGrace);
    free(pTimeLimit);
    free(pGroupId);
    free(pMaxLogins);
}

void SetExempt(EXEMPT_BASE * pExemptList,int * pExemptBuffer)
{
    int i=0,ii=0;
    char * pExemptUser;

    pExemptUser=(char *)malloc(sizeof(char)*(UT_NAMESIZE+1));
    if (!pExemptUser) Fatality("pExemptUser MALLOC FAIL.");

    cFill(pExemptUser,'\0',(UT_NAMESIZE+1));
    i=0;
    if (Debug) printf("Exempt User(s): ");
    while (pExemptBuffer[i]!='\0') // stop at end of buffer
    {
        while (pExemptBuffer[i]=='\n') i++;
        if (pExemptBuffer[i]=='\0') break;
        for (ii=0;ii<UT_NAMESIZE;ii++)
        {
            pExemptUser[ii]=(char)pExemptBuffer[i];
            i++;
            if ((pExemptBuffer[i]=='\n')||(pExemptBuffer[i]=='\0')) break;
        }
        if (Debug) printf("%s, ",pExemptUser);
        NewExempt(pExemptList,pExemptUser);
        cFill(pExemptUser,'\0',(UT_NAMESIZE+1));
    }
    if (Debug) printf(".\n");
    free(pExemptUser);
} // setup_devices

void CmdLine(int argc, char **argv)
{
    int i,ii;
    BOOL CmdError;
    
    CmdError=FALSE;
    if (argc>1)
    {
        for (i=1;i<argc;i++)
        {
            switch (argv[i][0])
            {
            case '-':
                {
                    if (strlen(argv[i])>2)
                    {
                        // these are combinatorial options.
                        for (ii=1;ii<strlen(argv[i]);ii++)
                        {
                            switch(argv[i][ii])
                            {
                            case 'n':
                                printf("Server code for a client monitor program: ");
                                if (VisServer=(!VisServer)) printf("enabled.\n");
                                else printf("disabled.\n");
                                continue;
                            case 'd':
                                printf("Debugging: ");
                                if (Debug=(!Debug)) printf("enabled.\n");
                                else printf("disabled.\n");
                                continue;
                            case 'e':
                                printf("ExemptUserChecks: ");
                                if (ExemptUserChecks=(!ExemptUserChecks)) printf("enabled.\n");
                                else printf("disabled.\n");
                                continue;
                            case 'f':
                                printf("Forking: ");
                                if (ForkJob=(!ForkJob)) printf("enabled.\n");
                                else printf("disabled.\n");
                                continue;
                            case 'h':
                                CmdError=TRUE;
                                printf("Command Help: enabled.\n");
                                continue;
                            case 'k':
                                printf("Real Killing: ");
                                if (RealKill=(!RealKill)) printf("enabled.\n");
                                else printf("disabled.\n");
                                continue;
                            case 'l':
                                printf("Logging: ");
                                if (Logging=(!Logging)) printf("enabled.\n");
                                else printf("disabled.\n");
                                continue;
                            case 'r':
                                printf("Ranking Disconnection: ");
                                if (RankingBased=(!RankingBased)) printf("enabled.\n");
                                else printf("disabled.\n");
                                continue;
                            case 's':
                                printf("Signal Catching: ");
                                if (CatchSigHup=(!CatchSigHup)) printf("enabled.\n");
                                else printf("disabled.\n");
                                continue;
                            case 'v':
                                printf("[mrm main module] Compiled Form Of: %s on: %s at: %s\nCopyright (C) 1996-1997, Tim Hart\n",__FILE__,__DATE__,__TIME__);
                                exit(1);
                                continue;
                            default:
                                printf("Combined parameter %d unrecognised \"%c\".\n",i,(char)(argv[i][ii]));
                                CmdError=TRUE;
                                continue;
                            }
                        }
                    }
                    else
                    {
                        switch (argv[i][1])
                        {
                            // these are singular options.
                        case 'c':
                            if (((i+1)<argc)&&(argv[i+1][0]!='-'))
                            {
                                if (!VisServer) printf("iMaxClients error: Network Server code has been disabled in this version.\n");
                                else
                                {
                                    iMaxClients=(int)strtol((char *)argv[i+1],NULL,10);
                                    printf("Maximum Clients: %d.\n",iMaxClients);
                                }
                            }
                            else
                            {
                                printf("Invalid -c option.\n");
                                CmdError=TRUE;
                            }
                            i++;
                            continue;
                        case 'm':
                            if (((i+1)<argc)&&(argv[i+1][0]!='-'))
                            {
                                iMinimumFree=(int)strtol((char *)argv[i+1],NULL,10);
                                printf("Minimum Free Devices: %d.\n",iMinimumFree);
                            }
                            else
                            {
                                printf("Invalid -m option.\n");
                                CmdError=TRUE;
                            }
                            i++;
                            continue;
                        case 'p':
                            if (((i+1)<argc)&&(argv[i+1][0]!='-'))
                            {
                                iPppPapMonPeriod=(off_t)strtol((char *)argv[i+1],NULL,10);
                                i++;
                                printf("ppp - pap monitoring: enabled. iPppPapMonPeriod=%d.\n",iPppPapMonPeriod);
                                PppPapMon=TRUE;
                                continue;
                            }
                            printf("ppp - pap monitoring: ");
                            if (PppPapMon=(!PPP_PAP_MON)) printf("enabled. iPppPapMonPeriod=%d.\n",iPppPapMonPeriod);
                            else printf("disabled.\n");
                            continue;
                        case 't':
                            if (((i+1)<argc)&&(argv[i+1][0]!='-'))
                            {
                                iClientTimeOut=(time_t)strtol((char *)argv[i+1],NULL,10);
                                printf("Client TimeOut: %d.\n",iMaxClients);
                            }
                            else
                            {
                                printf("Invalid -t option.\n");
                                CmdError=TRUE;
                            }
                            i++;
                            continue;
                        case 'w':
                            if ((i+1)<argc) iLoopSleep=(int)strtol((char *)argv[i+1],NULL,10);
                            else
                            {
                                printf("Invalid -w option.\n");
                                CmdError=TRUE;
                            }
                            i++;
                            continue;
                        case 'x':
                            DebugLog=TRUE;
                            printf("Debug info logging enabled.\n");
                            if (((i+1)<argc)&&(argv[i+1][0]!='-'))
                            {
                                iMaxBytesDebug=(off_t)strtol((char *)argv[i+1],NULL,10);
                                i++;
                            }
                            continue;
                        // combined params that may be specified sigularly.
                        case 'n':
                            printf("Server code for a client monitor program: ");
                            if (VisServer=(!VisServer)) printf("enabled.\n");
                            else printf("disabled.\n");
                            continue;
                        case 'd':
                            printf("Debugging: ");
                            if (Debug=(!Debug)) printf("enabled.\n");
                            else printf("disabled.\n");
                            continue;
                        case 'e':
                            printf("ExemptUserChecks: ");
                            if (ExemptUserChecks=(!ExemptUserChecks)) printf("enabled.\n");
                            else printf("disabled.\n");
                            continue;
                        case 'f':
                            printf("Forking: ");
                            if (ForkJob=(!ForkJob)) printf("enabled.\n");
                            else printf("disabled.\n");
                            continue;
                        case 'h':
                            CmdError=TRUE;
                            printf("Command Help: enabled.\n");
                            continue;
                        case 'k':
                            printf("Real Killing: ");
                            if (RealKill=(!RealKill)) printf("enabled.\n");
                            else printf("disabled.\n");
                            continue;
                        case 'l':
                            printf("Logging: ");
                            if (Logging=(!Logging)) printf("enabled.\n");
                            else printf("disabled.\n");
                            continue;
                        case 'r':
                            printf("Ranking Disconnection: ");
                            if (RankingBased=(!RankingBased)) printf("enabled.\n");
                            else printf("disabled.\n");
                            continue;
                        case 's':
                            printf("Signal Catching: ");
                            if (CatchSigHup=(!CatchSigHup)) printf("enabled.\n");
                            else printf("disabled.\n");
                            continue;
                        case 'v':
                            printf("[mrm main module] Compiled Form Of: %s on: %s at: %s\nCopyright (C) 1996-1997, Tim Hart\n",__FILE__,__DATE__,__TIME__);
                            exit(1);
                            continue;
                        default:
                            printf("Singular Parameter %d unrecognised \"-%c\".\n",i,(char)(argv[i][1]));
                            CmdError=TRUE;
                            continue;
                        }
                        break;
                    }
                }
            default:
                printf("Parameter %d unrecognised \"%c\".\n",i,(char)(argv[i][0]));
                CmdError=TRUE;
                break;
            }
        }
    }
    else
    {
        if (Debug) printf("No command line options detected.\n");
    }
    if (CmdError)
    {
        printf("%s",UsageMesg);
        exit(1);
    }
    if (Debug) printf("end CmdLine().\n");
}

void UtmpRead(DEV_INFO_BASE * pDeviceList)
{
    // read the utmp_path.
    // fill device list with info found in utmp.
    //
    //
    struct utmp * temp_utmp, * pUtmpBuffer;
    char tmp[UT_NAMESIZE+1];
    long UtmpLen=0,UtmpEntries=0,UtmpEntriesStore=0;
    int i=0,ii=0,iii=0;	// lots of counters :)
    BOOL found;

    if (Debug) printf("UtmpRead() begin.\n");
    if (DebugLog) LogDebug("UtmpRead() begin.");
    setutent();
    while ((temp_utmp=getutent())!=NULL)
    {
        if (temp_utmp->ut_name[0]=='\0') continue; // ignore null logins
        if (temp_utmp->ut_line[0]=='\0') continue; // ignore null lines.
        strncpy(tmp,(temp_utmp->ut_name),UT_NAMESIZE);
        if (!getpwnam(tmp)) continue;
        UtmpEntries++;
    }
    pUtmpBuffer=(struct utmp *)malloc(sizeof(struct utmp)*(UtmpEntries));
    if (!pUtmpBuffer) Fatality("pUtmpBuffer MALLOC FAIL\n");
    endutent();
    setutent();
    UtmpEntriesStore=UtmpEntries;
    i=0;
    while (((temp_utmp=getutent())!=NULL)&&(UtmpEntries>0))
    {
        if (temp_utmp->ut_name[0]=='\0') continue; // ignore null logins
        if (temp_utmp->ut_line[0]=='\0') continue; // ignore null lines.
        strncpy(tmp,(temp_utmp->ut_name),UT_NAMESIZE);
        if (!getpwnam(tmp)) continue;
        pUtmpBuffer[i]=*temp_utmp;
        i++;UtmpEntries--;
    }
    UtmpEntries=UtmpEntriesStore-UtmpEntries; // (they may have shrunk/expanded)
    endutent();
    if (Debug)
    {
        printf("Entries=%d | ut_line dump: ",UtmpEntries);
        for (i=0;i<UtmpEntries;i++) printf("%s, ",pUtmpBuffer[i].ut_line);
        printf(".\n");
    }
    if (Debug) printf("Occupied Device(s): ");
    for (ii=0;ii<(pDeviceList->NumberOfDevices);ii++)
    {
        found=FALSE;
        for (i=0;i<UtmpEntries;i++)
        {
            if (strcmp(pUtmpBuffer[i].ut_line,GetDevice(pDeviceList,ii+1)->pDeviceId)!=0) continue;
            // found a match.
            found=TRUE;
            if (Debug) printf("%s, ",pUtmpBuffer[i].ut_line);
            cFill(GetDevice(pDeviceList,ii+1)->current_user,'\0',UT_NAMESIZE+1);
            for (iii=0;iii<UT_NAMESIZE;iii++) GetDevice(pDeviceList,ii+1)->current_user[iii]=pUtmpBuffer[i].ut_user[iii];
            GetDevice(pDeviceList,ii+1)->login_time=pUtmpBuffer[i].ut_time;
            GetDevice(pDeviceList,ii+1)->login_pid=pUtmpBuffer[i].ut_pid;
            GetDevice(pDeviceList,ii+1)->occupied=TRUE;
        }
        if (!found)
        {
            GetDevice(pDeviceList,ii+1)->occupied=FALSE;
            if (GetDevice(pDeviceList,ii+1)->current_user[0]!='\0')
            {	// user logged out on us :)
                cFill(GetDevice(pDeviceList,ii+1)->prev_user,'\0',UT_NAMESIZE+1);
                for (i=0;i<UT_NAMESIZE;i++) GetDevice(pDeviceList,ii+1)->prev_user[i]=GetDevice(pDeviceList,ii+1)->current_user[i];
                GetDevice(pDeviceList,ii+1)->current_user[0]='\0'; //set null.
            }
            // THIS HERE could be the solution to catching ppl that logout
            // just before their limit and re-login...
            // by storing their time online, instead of reseting it to zero.
            GetDevice(pDeviceList,ii+1)->login_time=0; // zeroize login time.
        }

    }
    if (Debug) printf(".\n");
    free(pUtmpBuffer);
    if (Debug) printf("end UtmpRead()\n");
    if (DebugLog) LogDebug("UtmpRead End");
} // UtmpRead

int SignalHandle(int sig)
{
    // SIGHUP caught
    // re-read in the config files... and setup the lists again.
    signal(SIGHUP,SIG_IGN);
    // ignore signal for this routine and until
    // reset after the longjmp.

    LogMsg("[signal] SIGHUP Caught. re-loading Setup");
    longjmp(env,1);
}

int TimeCheck(DEV_INFO_BASE * pDeviceList)
{
    int i=0,NumberFree=0;

    if (Debug) printf("Time Check. iMinimumFree = %d.\n",iMinimumFree);
    if (Debug) printf("Free Device(s): ");
    for (i=0;i<(pDeviceList->NumberOfDevices);i++)
    {
        if (Occupied(pDeviceList,i+1)) continue;
        NumberFree++;
        if (Debug) printf("%s, ",GetDevice(pDeviceList,i+1)->pDeviceId);
    }
    if (Debug) printf(".\n");
    if (iMinimumFree<NumberFree) return 0; // enuff lines are free.
    else
    {
        if (Debug) printf("Must free up %d device(s)\n",(iMinimumFree-NumberFree));
        return (iMinimumFree-NumberFree);
    }
}

void DieTimeBandits(DEV_INFO_BASE * pDeviceList,USER_BASE * pUserList,GLG_BASE * pGLGList,EXEMPT_BASE * pExemptList,KICK_BASE * pKickList,int BodyCount)
{
    int i=0,ii=0,MaxOverDevice=0,UserGLGIndex=0;
    char tmp[UT_NAMESIZE+1];
    BOOL Found,FoundNaughty,FoundExempt;
    time_t CurrentTime,TimeOver=0,MaxOver=0;
    pid_t MaxOverPid;

    CurrentTime=time(NULL);
    MaxOver=0;TimeOver=0;
    //find which user has been on the longest
    FoundNaughty=TRUE;
    if (Debug) printf("The BodyCount is %d.\n",BodyCount);
    while ((BodyCount>0)&&(FoundNaughty))
    {
        i=0;
        FoundNaughty=FALSE;
        while ((i<(pDeviceList->NumberOfDevices))&&(BodyCount>0))
        {
            // find person on the longest.
            if (!Occupied(pDeviceList,i+1))
            {
                i++;
                continue;
            }
            // check if exempt.

            if (ExemptUserChecks)
            {
                if (ExemptOnDevice(pExemptList,pDeviceList,i+1))
                {
                    i++;
                    continue;
                }
            }
            if (!(UserInGLGList(pGLGList,pDeviceList,i+1).check))
            {
                if (Debug) printf("Ignoring user %s because of gid (not in GLGList).\n",User(pDeviceList,i+1));
                i++;
                continue;	//ignoring user of this group.
            }
            // ok.. they were found to be in GLG file.
            UserGLGIndex=UserInGLGList(pGLGList,pDeviceList,i+1).position;
            if (Debug) printf("Found User %s. has gid %d\n",User(pDeviceList,i+1),GetGLG(pGLGList,UserGLGIndex+1)->group_id);

#ifdef ZERO_LIMIT_CHECK
            if (GetGLG(pGLGList,UserGLGIndex+1)->group_limit==0)
            {
                if (Debug) printf("ignoring user, %s, because of time limit 0.\n",User(pDeviceList,i+1));
                i++;
                continue;  // ignore the super privillaged.
            }
#endif
            
            TimeOver=(CurrentTime-GetDevice(pDeviceList,i+1)->login_time-GetGLG(pGLGList,UserGLGIndex+1)->group_limit);
            if (Debug) printf("User %s,TimeOver=%d\n",GetDevice(pDeviceList,i+1)->current_user,TimeOver);
            if (TimeOver>0)
            {
                //they have been on toooo long.
                //but have they been on the most?
                if (TimeOver>MaxOver)
                {
                    FoundNaughty=TRUE;
                    MaxOver=TimeOver;
                    MaxOverPid=GetDevice(pDeviceList,i+1)->login_pid;
                    MaxOverDevice=i;
                }
            }
            i++;
        }
        if (FoundNaughty)
        {
            if (Debug) printf("Found User Over Limit! Killing %s.\n",GetDevice(pDeviceList,MaxOverDevice+1)->current_user);
            // there will be hell to pay!!
            LogKill(pDeviceList,MaxOverDevice+1);
            // add to kick list.
            NewKick(pKickList,GetDevice(pDeviceList,MaxOverDevice+1)->current_user,\
                    CurrentTime,GetGLG(pGLGList,UserInGLGList(pGLGList,pDeviceList,MaxOverDevice+1).position+1)->group_grace);
            if (RealKill) kill(MaxOverPid,SIGKILL);
            GetDevice(pDeviceList,MaxOverDevice+1)->occupied=FALSE;
            GetDevice(pDeviceList,MaxOverDevice+1)->logout_time=CurrentTime;
            for (ii=0;ii<UT_NAMESIZE;ii++) GetDevice(pDeviceList,MaxOverDevice+1)->prev_user[ii]=GetDevice(pDeviceList,MaxOverDevice+1)->current_user[ii];
            GetDevice(pDeviceList,MaxOverDevice+1)->current_user[0]='\0';
            BodyCount--; // one down.. more to go?
        }
    }
} // DieTimeBandits();

BOOL ExemptOnDevice(EXEMPT_BASE * pExemptList,DEV_INFO_BASE * pDeviceList,int iDeviceNumber)
{
    int i;

    for (i=0;i<(pExemptList->NumberExempt);i++)
    {
        if (strcmp(User(pDeviceList,iDeviceNumber),GetExempt(pExemptList,i+1)->pExemptUser)==0)
            return TRUE;
    }
    return FALSE;
} // ExemptOnDevice();

BOOL Occupied(DEV_INFO_BASE * pDeviceList,int iDeviceNumber) // true/false occupied.
{
    return (GetDevice(pDeviceList,iDeviceNumber)->occupied);
} // Occupied();

USERGLG UserInGLGList(GLG_BASE * pGLGList,DEV_INFO_BASE * pDeviceList,int iDeviceNumber)
{
    // is the gid of user on device iDeviceNumber
    // in the GLGList?
    // if so,.. return the User's GID GLGIndex.

    int i;
    char NameTmp[UT_NAMESIZE+1];
    BOOL Found;
    USERGLG TempUserGLG;
    struct passwd * pPasswdTmp;

    TempUserGLG.check=FALSE;
    TempUserGLG.position=0;
    cFill(NameTmp,'\0',(UT_NAMESIZE+1));
    strncpy(NameTmp,GetDevice(pDeviceList,iDeviceNumber)->current_user,UT_NAMESIZE);
    if (Debug) printf("usergid call.\n");

    pPasswdTmp=getpwnam(NameTmp);

    if (!pPasswdTmp)
    {
        if (Debug) printf("User %s HAS NO GID!!!!! (VERY BAD).\n",NameTmp);
        return TempUserGLG;
    }
    for (i=0;i<pGLGList->NumberOfGLG;i++)
    {
        if ((pPasswdTmp->pw_gid)==(GetGLG(pGLGList,i+1)->group_id))
        {
            TempUserGLG.check=TRUE;
            break;
        }
    }
    TempUserGLG.position=i;
    free(pPasswdTmp);
    if (!TempUserGLG.check) TempUserGLG.position=0;
    return TempUserGLG;
    if (Debug) printf("end of UserInGLGList\n");
} // UserInGLGList();

char * User(DEV_INFO_BASE * pDeviceList,int iDeviceNumber)
{
    if (iDeviceNumber<=0) return NULL;
    return (GetDevice(pDeviceList,iDeviceNumber)->current_user);
} // User();

char * Line(DEV_INFO_BASE * pDeviceList,int iDeviceNumber)
{
    if (iDeviceNumber<=0) return NULL;
    return (GetDevice(pDeviceList,iDeviceNumber)->pDeviceId);
} // Line();

time_t LoginTime(DEV_INFO_BASE * pDeviceList,int iDeviceNumber)
{
    if (iDeviceNumber<=0) return 0;
    return (GetDevice(pDeviceList,iDeviceNumber)->login_time);
} // LoginTime();

void LogMsg(char * logmsg)
{
    FILE * logfp;
    time_t TimeStore;
    struct tm * TimeNow;

    TimeStore=time(NULL);
    TimeNow=localtime(&TimeStore);
    if (Logging)
    {
        if ((logfp=fopen(log_path,"a+"))==NULL) printf("CANNOT OPEN LOG FILE!\n");
        fprintf(logfp,"[msg]    |%s, %02d %s. %02d:%02d:%02d| %s\n",\
                GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
                TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,logmsg);
        fclose(logfp);
    }
    else
    {
        printf("[msg]    |%s, %02d %s. %02d:%02d:%02d| %s\n",\
               GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
               TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,logmsg);
    }
}

void LogDebug(char * logdebugmsg)
{
    FILE * Debugfp;
    time_t TimeStore;
    struct tm * TimeNow;

    TimeStore=time(NULL);
    TimeNow=localtime(&TimeStore);
    if (DebugLog)
    {
        if ((Debugfp=fopen(debug_path,"a+"))==NULL) printf("CANNOT OPEN DEBUG FILE!\n");
        fprintf(Debugfp,"[debug]   |%s, %02d %s. %02d:%02d:%02d| %s\n",\
                GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
                TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,logdebugmsg);
        fclose(Debugfp);
    }
    else
    {
        printf("[debug]   |%s, %02d %s. %02d:%02d:%02d| %s\n",\
               GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
               TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,logdebugmsg);
    }
}

BOOL DebugSizeOk()
{
    struct stat DebugStat;

    if (stat(debug_path,&DebugStat)<0) Fatality("DebugSizeOk() - getting file stat.");
    // ok.. got stat...
    if (DebugStat.st_size>iMaxBytesDebug)
    {
        printf("debugsizeok(): debug file is too big, deleting.\n");
        if (unlink(debug_path)<0) printf("debugsizeok(): cannot unlink.\n");
    }
}

void LogKill(DEV_INFO_BASE * pDeviceList,int iDeviceIndex)
{
    FILE * logfp;
    time_t TimeStore,TimeOn;
    struct tm * TimeNow;

    TimeStore=time(NULL);
    TimeOn=TimeStore-LoginTime(pDeviceList,iDeviceIndex);
    TimeNow=localtime(&TimeStore);
    if (Logging)
    {
        if ((logfp=fopen(log_path,"a+"))==NULL) Fatality("CANNOT OPEN LOG FILE TO LOG KILLING!");
        fprintf(logfp,"[kill]   |%s, %02d %s. %02d:%02d:%02d| |%s| on %s.",\
                GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
                TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,\
                User(pDeviceList,iDeviceIndex),Line(pDeviceList,iDeviceIndex));
        fprintf(logfp," >%02d:%02d:%02d<\n",DivTime(TimeOn).hours,DivTime(TimeOn).minutes,DivTime(TimeOn).seconds);
        fclose(logfp);
    }
    else
    {
        printf("[kill]   |%s, %02d %s. %02d:%02d:%02d| |%s| on %s.",\
               GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
               TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,\
               User(pDeviceList,iDeviceIndex),Line(pDeviceList,iDeviceIndex));
        printf(" >%02d:%02d:%02d<\n",DivTime(TimeOn).hours,DivTime(TimeOn).minutes,DivTime(TimeOn).seconds);
    }
}

void LogReKill(DEV_INFO_BASE * pDeviceList,int iDeviceIndex,KICK_BASE * pKickList,int iKickIndex)
{
    FILE * logfp;
    time_t TimeStore,TimeOn;
    struct tm * TimeNow;

    TimeStore=time(NULL);
    TimeOn=TimeStore-LoginTime(pDeviceList,iDeviceIndex);
    TimeNow=localtime(&TimeStore);
    if (Logging)
    {
        if ((logfp=fopen(log_path,"a+"))==NULL) Fatality("CANNOT OPEN LOG FILE TO LOG RE-KILLING!");
        fprintf(logfp,"[rekill] |%s, %02d %s. %02d:%02d:%02d| |%s| on %s. re-kill #%d",\
                GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
                TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,\
                User(pDeviceList,iDeviceIndex),Line(pDeviceList,iDeviceIndex),GetKick(pKickList,iKickIndex)->NumReKicks);
        fprintf(logfp," >%02d:%02d:%02d<\n",DivTime(TimeOn).hours,DivTime(TimeOn).minutes,DivTime(TimeOn).seconds);
        fclose(logfp);
    }
    else
    {
        printf("[rekill] |%s, %02d %s. %02d:%02d:%02d| |%s| on %s. re-kill #%d",\
               GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
               TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,\
               User(pDeviceList,iDeviceIndex),Line(pDeviceList,iDeviceIndex),GetKick(pKickList,iKickIndex)->NumReKicks);
        printf(" >%02d:%02d:%02d<\n",DivTime(TimeOn).hours,DivTime(TimeOn).minutes,DivTime(TimeOn).seconds);
    }
}


char * GetDay(int in_day)
{
    switch (in_day)
    {
    case 0: return "Sun";
    case 1: return "Mon";
    case 2: return "Tue";
    case 3: return "Wed";
    case 4: return "Thu";
    case 5: return "Fri";
    case 6: return "Sat";
    }
}

char * GetMonth(int in_month)
{
    switch (in_month)
    {
    case 0: return "Jan";
    case 1: return "Feb";
    case 2: return "Mar";
    case 3: return "Apr";
    case 4: return "May";
    case 5: return "Jun";
    case 6: return "Jul";
    case 7: return "Aug";
    case 8: return "Sep";
    case 9: return "Oct";
    case 10: return "Nov";
    case 11: return "Dec";
    }
}

DIVTIME_T DivTime(time_t TimeIn)
{
    //return number of hours/minutes or seconds.
    int hours=0,minutes=0,seconds=0;
    DIVTIME_T TimeSegments;
    signed long TimeInStore;

    TimeInStore=TimeIn;	// dunno if time_t is signed.. quick fix anyway.
    hours=0;
    while ((TimeInStore=TimeInStore-3600)>0) hours++;
    if (TimeInStore==0) { minutes=0;seconds=0; }
    else
    {
        TimeInStore=TimeInStore+3600; // set back to above 0.
        while ((TimeInStore=TimeInStore-60)>0) minutes++;
        if (TimeInStore==0) seconds=0;
        else seconds=TimeInStore+60;
    }
    TimeSegments.hours=hours;
    TimeSegments.minutes=minutes;
    TimeSegments.seconds=seconds;
    return TimeSegments;
}

void Fatality(char * ExitMsg)
{
    // something has gone wrong!
    printf("FATAL ERROR: %s :EXITING\n",ExitMsg);
    LogMsg("[fatal] !PROGRAM ERROR!");
    LogMsg(ExitMsg);
    LogMsg("[fatal] !EXITING!");
    exit(1);
}

void cFill(char * pArray,char FillChar,int iNumElements)
{
    int i;

    for (i=0;i<iNumElements;i++) pArray[i]=FillChar;
}

void iFill(int * pArray,int FillInt,int iNumElements)
{
    int i;

    for (i=0;i<iNumElements;i++) pArray[i]=FillInt;
}

void KickListPurge(KICK_BASE * pKickList)
{
    // Process Time list and remove old entries.
    time_t CurrentTime;
    int i;

    CurrentTime=time(NULL);
    if (DebugLog) LogDebug("Top KickList()");
    for (i=0;i<pKickList->NumberOfKicks;i++)
    {
        if (Debug) printf("[kicklist] position %d, user %s.\n",i+1,GetKick(pKickList,i+1)->pKickUser);
        if (((GetKick(pKickList,i+1)->KickTime)+(GetKick(pKickList,i+1)->GracePeriod))<CurrentTime)
        {
            // ok.. this entry is old.
            if (Debug) printf("kicklist entry for user %s is old.. deleting.\n",(GetKick(pKickList,i+1)->pKickUser));
            if (!DelKick(pKickList,i+1)) Fatality("COULD NOT DELETE KICK LIST ENTRY!");
        }
    }
    if (DebugLog) LogDebug("End KickList()");
}

USERKILL InKickList(KICK_BASE * pKickList,char * pName)
{
    char pNameTmp[UT_NAMESIZE+1];
    int i;
    USERKILL UserKillInfo;

    UserKillInfo.Found=FALSE;
    
    cFill(pNameTmp,'\0',(UT_NAMESIZE+1));
    strncpy(pNameTmp,pName,UT_NAMESIZE);
    //  a null terminated name string has now been forced.
    for (i=0;i<pKickList->NumberOfKicks;i++)
    {
        if (strcmp(pNameTmp,GetKick(pKickList,i+1)->pKickUser)==0)
        {
            UserKillInfo.Found=TRUE;
            UserKillInfo.position=i+1;
            return UserKillInfo;
        }
    }
    return UserKillInfo;
}

int UserRank(USER_BASE * pUserList,char * pName)
{
    int i;
    BOOL Found;
    
    Found=FALSE;
    for (i=0;i<pUserList->NumberOfUsers;i++)
    {
        if (strcmp(&(GetUser(pUserList,i+1)->pUser),pName)==0)
        {
            // found matching name.
            Found=TRUE;
            break;
        }
    }
    if (Found) return i+1;
    else return -1;
}

BOOL ReLoginCheck(DEV_INFO_BASE * pDeviceList,KICK_BASE * pKickList)
{
    // this is where it all happens :)
    // check the list with the on-line users.
    // if in list.. then kill them.
    // the kick list should only ever hold logins of users that
    // have a time limit.. super user should not be found here
    // at any time.. unless time limit is applied to root too.
    // as NewKick() is only used in kill routines... only killed
    // users.. (timed) will be in the kick list.
    int i;
    BOOL FoundABadPerson;

    FoundABadPerson=FALSE;     // innocent until proven ______ :)
    
    for (i=0;i<pDeviceList->NumberOfDevices;i++)
    {
        if (!Occupied(pDeviceList,i+1)) continue; // skip non-logged in devices.
        if (InKickList(pKickList,User(pDeviceList,i+1)).Found)
        {
            FoundABadPerson=TRUE;
            GetKick(pKickList,InKickList(pKickList,User(pDeviceList,i+1)).position)->NumReKicks++;
            // log it.
            LogReKill(pDeviceList,i+1,pKickList,InKickList(pKickList,User(pDeviceList,i+1)).position);
            // ok.. now chop off their heads.
            if (RealKill) kill(GetDevice(pDeviceList,i+1)->login_pid,SIGKILL);
            GetDevice(pDeviceList,i+1)->occupied=FALSE; // no-one is on this line now.
        }
    }
    return FoundABadPerson;
}

BOOL MultipleLoginKill(DEV_INFO_BASE * pDeviceList,USER_BASE * pUserList,GLG_BASE * pGLGList)
{
    // check if multiple logins of the same user are in progress.
    // if so... check if number of logins present has been previously
    // authorized to the user.
    // no auth to use mult logins, or over login limit results in killing all logins
    BOOL FoundMultiple;

    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // do this l8r.
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    
    FoundMultiple=FALSE;
    return FoundMultiple;
}

BOOL Exempt(EXEMPT_BASE * pExemptList,char * pUser)
{
    int i;

    for (i=0;i<pExemptList->NumberExempt;i++)
    {
        if (strncmp(pUser,GetExempt(pExemptList,i+1)->pExemptUser,UT_NAMESIZE)==0)
        {
            // ok, found the matching line id.
            // the line number that matches is i+1
            return TRUE;
        }
    }
    // not found.
    return FALSE;
}

int LineNum(DEV_INFO_BASE * pDeviceList,char * pDeviceIdStr)
{
    int i;
    // return 0 if line not found.

    for (i=0;i<pDeviceList->NumberOfDevices;i++)
    {
        if (strcmp(pDeviceIdStr,GetDevice(pDeviceList,i+1)->pDeviceId)==0)
        {
            // ok, found the matching line id.
            // the line number that matches is i+1
            return i+1;
        }
    }
    // if we are here then the line was not found.
    if (Debug) printf("line %s, not found\n",pDeviceIdStr);
    return 0;
}

// this diemodule is used with the user indexed rankings base disconnect
// option.

void RankingDieModule(DEV_INFO_BASE * pDeviceList,USER_BASE * pUserList,EXEMPT_BASE * pExemptList,KICK_BASE * pKickList,int BodyCount)
{
    ONLINE_INFO * pOnlineInfo;
    int i,ii,iLoginIndex,iLineNumber,iUserIndex;
    pid_t PidToKill;
    time_t CurrentTime,TimeOver;
    
    if (Debug) printf("RankingDieModule(). %d Users Exist. The BodyCount is %d\n",pUserList->NumberOfUsers,BodyCount);
    if (DebugLog) LogDebug("Top TankingDieModule()");
    CurrentTime=time(NULL);
    TimeOver=0;
    iUserIndex=0;
    while ((BodyCount>0)&&(iUserIndex<(pUserList->NumberOfUsers)))
    {
        iUserIndex++;

#ifdef ZERO_LIMIT_CHECK
        if (GetUser(pUserList,iUserIndex)->online_limit==0)
        {
            if (Debug) printf("ignoring user, %s, because of time limit 0.\n",GetUser(pUserList,iUserIndex)->pUser);
            continue;  // ignore the super privillaged.
        }
#endif
        if (ExemptUserChecks)
        {
            // quick check if they have been made exempt.
            if (Exempt(pExemptList,GetUser(pUserList,iUserIndex)->pUser))
            {
                if (Debug) printf("%s is exempt.\n",GetUser(pUserList,iUserIndex)->pUser);
                continue;
            }
        }
        // alrite they are not superhuman, get info on there login(s).
        pOnlineInfo=UserOnline(pDeviceList,GetUser(pUserList,iUserIndex)->pUser);
        // is this person logged in?
        if (!pOnlineInfo) continue; // they arent logged in.
        if (Debug) printf("user %s, has %d logins.\n",GetUser(pUserList,iUserIndex)->pUser,pOnlineInfo->iNumLogins);
        // okay.. they are logged in
        // are they over their limit?
        // check limit on each login instance.
        iLoginIndex=0;
        while (iLoginIndex<pOnlineInfo->iNumLogins)
        {
            // walk the list if we have to.
            // first time no need to walk.
            iLoginIndex++;
            iLineNumber=LineNum(pDeviceList,OnlineInfoPos(pOnlineInfo,iLoginIndex));
            // test code only
            if (!iLineNumber)
            {
                // this should never happen... but if it does.
                Fatality("big problem, line number not resolved.");
            }
            // now check the user's time.
            TimeOver=(CurrentTime-GetDevice(pDeviceList,iLineNumber)->login_time-GetUser(pUserList,iUserIndex)->online_limit);
            if (Debug) printf("User %s,TimeOver=%d\n",GetDevice(pDeviceList,iLineNumber)->current_user,TimeOver);
            if (TimeOver>0)
            {
                if (DebugLog) LogDebug("timeover>0");
                // they have been on toooo long.
                // now kill the user that is in the topmost position of the list.
                // find the ranking of the user.
                PidToKill=GetDevice(pDeviceList,iLineNumber)->login_pid;
                if (Debug) printf("Found User Over Limit! Killing %s.\n",GetDevice(pDeviceList,iLineNumber)->current_user);
                // there will be hell to pay!!
                LogKill(pDeviceList,iLineNumber);
                // add to kick list.
                NewKick(pKickList,GetDevice(pDeviceList,iLineNumber)->current_user,\
                        CurrentTime,GetUser(pUserList,iUserIndex)->wait_limit);
                if (DebugLog) LogDebug("added kick entry.");
                if (RealKill) kill(PidToKill,SIGKILL);
                GetDevice(pDeviceList,iLineNumber)->occupied=FALSE;
                GetDevice(pDeviceList,iLineNumber)->logout_time=CurrentTime;
                for (ii=0;ii<UT_NAMESIZE;ii++) GetDevice(pDeviceList,iLineNumber)->prev_user[ii]=GetDevice(pDeviceList,iLineNumber)->current_user[ii];
                GetDevice(pDeviceList,iLineNumber)->current_user[0]='\0';
                BodyCount--; // one down.. more to go?
                if (DebugLog) LogDebug("end timeover>0 block");
            }
        }  // end of while block.
        FreeInfo(pOnlineInfo);
    }  // end of main while block
    if (Debug) printf("end RankingDieModule().\n");
    if (DebugLog) LogDebug("End RankingDieModule()");
}

BOOL ServerInit()
{

    BOOL Status;

    Status=TRUE;

    // get socket
    if ((s=socket(AF_UNIX,SOCK_STREAM,0))<0)
    {
        if (Debug) printf("server: socket error.\n");
        Status=FALSE;
    }

    // change the attribs of the descriptor... make it nonblocking.
    // this one can be nonblocking as it only accepts connections
    if (fcntl(s,F_SETFL,O_NONBLOCK)<0)
    {
        if (Debug) printf("server: error with nonblock set.\n");
        Status=FALSE;
    }
    
    // create address.
    saun.sun_family=AF_UNIX;
    strcpy(saun.sun_path,un_sock_addr);

    // bind name to address.
    // unlink so bind will work.
    unlink(un_sock_addr);
    if (bind(s,&saun,sizeof(saun)) < 0)
    {
        if (Debug) printf("server: bind error.\n");
        Status=FALSE;
    }

    // listen on socket.
    if (listen(s,iMaxClients)<0)
    {
        if (Debug) printf("server: listen error.\n");
        Status=FALSE;
    }

    return Status;
}

BOOL Connection()
{
    BOOL bConnect;
    struct stat stattmp;
    time_t ClientSnooze;

    bConnect=FALSE;
    // check if socket(s) are still connected.
    // employ a timeout routine.
    if ((iNumClients<iMaxClients)&&(VisServer))
    {
        if ((ns = accept(s,&fsaun,&ifromlength))<0)
        {
            switch (errno)
            {
            case EWOULDBLOCK:
                if (Debug) printf("server: accept: no pending connections.\n");
                break;
            default:
                if (Debug) printf("server: accept: UNKNOWN error.\n");
                break;
            }
        }
        else
        {
            if (Debug) printf("server: connection to client established.\n");
            bConnect=TRUE;
            iNumClients++;
            // change the attribs of the descriptor... make it nonblocking.
            //if (fcntl(ns,F_SETFL,O_NONBLOCK)<0) if (Debug) printf("server: error with nonblock set.\n");
        }
    }
    return bConnect;
}

BOOL RequestHandle(DEV_INFO_BASE * pDeviceList,USER_BASE * pUserList,KICK_BASE * pKickList,GLG_BASE * pGLGList,EXEMPT_BASE * pExemptList,int UpTime)
{
    // see if a request for info has been made.
    // if so, look at request type, then write appropriate info to socket.
    
    BOOL ReadSuccess,WriteSuccess;
    char RequestCode,Reply,ClientMsg;
    int i,ii,iLineNumber,iReadStatus,iUserIndex;
    struct timeval S_timeout;
    fd_set pSelectReadSet;
    ONLINE_INFO * pUserInfo;
    time_t CurrentTime;
    pid_t PidToKill;
    
    ReadSuccess=FALSE;
    CurrentTime=time(NULL);
    
    if (Debug) printf("RequestHandle()\n");
    FD_SET(ns,&pSelectReadSet);
    S_timeout.tv_sec=0;
    S_timeout.tv_usec=500;  // wait 1/2 second if have to...
    select(ns+1,&pSelectReadSet,NULL,NULL,&S_timeout);
    if (!FD_ISSET(ns,&pSelectReadSet))
    {
        if (Debug) printf("RequestHandle(): No request(s) ready to be processed.\n");
        return ReadSuccess;
    }
    // ok, there is data available for reading.
    iReadStatus=read(ns,&RequestCode,sizeof(RequestCode));

    switch (iReadStatus)
    {
    case 0:
        if (Debug) printf("read: eof on socket.\n");
        break;
    case (-1):
        if (Debug) printf("read: error occured.\n");
        break;
    case (sizeof(RequestCode)):
        if (Debug) printf("read: success, ");
        // ok.. got a byte, now see what this byte means.
        if (Debug) printf("byte recieved =%d.\n",(int)RequestCode);
        ReadSuccess=TRUE;
        break;
    default:
        if (Debug) printf("read: big problem occured.\n");
        break;
    }
    if (ReadSuccess)
    {
        // ok.. get code, then write data.
        switch ((int)RequestCode)
        {
        case S_SAYHELLO:
            if (Debug) printf("S_SAYHELLO\n");
            // is the server still alive?
            Reply=S_HELLO;
            switch (write(ns,&Reply,sizeof(Reply)))
            {
            case (sizeof(Reply)):
                if (Debug) printf("write: S_HELLO success.\n");
                break;
            default:
                if (Debug) printf("write: S_HELLO error.\n");
                break;
            }
            break;
        case S_ALL:
            if (Debug) printf("S_ALL\n");
            // write all data to the client.
            break;
        case S_DEVICELIST:
            if (Debug) printf("S_DEVICELIST\n");
            break;
        case S_USERLIST:
            if (Debug) printf("S_USERLIST\n");
            break;
        case S_KICKLIST:
            if (Debug) printf("S_KICKLIST\n");
            break;
        case S_GLGLIST:
            if (Debug) printf("S_GLGLIST\n");
            break;
        case S_EXEMPTLIST:
            if (Debug) printf("S_EXEMPTLIST\n");
            break;
        case S_UPTIME:
            if (Debug) printf("S_UPTIME\n");
            break;
        case S_TOTALKILLS:
            if (Debug) printf("S_TOTALKILLS\n");
            break;
        case S_TOTALREKILLS:
            if (Debug) printf("S_TOTALREKILLS\n");
            break;
        case S_UKILLREQUEST:
            if (Debug) printf("S_UKILLREQUEST\n");
            cFill(pUserToKill,'\0',iMaxUserNameLength);
            
            for (i=0;i<iMaxUserNameLength;i++)
            {
                if (!read(ns,&(pUserToKill[i]),sizeof(char))) break;
            }
            if (Debug) printf("[ukillrequest] user \"%s\".\n",pUserToKill);
            if ((ExemptKillGuard)&&(Exempt(pExemptList,pUserToKill)))
            {
                if (Debug) printf("[ukillrequest] user exempt! aborting.\n");
                break;
            }
            pUserInfo=UserOnline(pDeviceList,pUserToKill);
            if (!pUserInfo)
            {
                // the user is not online.
                if (Debug) printf("[ukillrequest] user not logged onto a scanned device! aborting.\n");
                break;
            }
            if (((iUserIndex=UserRank(pUserList,pUserToKill))<0)&&(RankingKillGuard))
            {
                if (Debug) printf("[ukillrequest] user not in rankings! aborting.\n");
                break;
            }
            // ok, user has an index
            if (Debug) printf("[ukillrequest] user ranking=%d.\n",iUserIndex);
            if (iUserIndex<0)
            {
                NewKick(pKickList,pUserToKill,CurrentTime,iDefaultWaitTime);
            }
            else
            {
                NewKick(pKickList,pUserToKill,CurrentTime,GetUser(pUserList,iUserIndex)->wait_limit);
            }

            i=0;
            while (i<(pUserInfo->iNumLogins))    // logout all user instances.
            {
                iLineNumber=LineNum(pDeviceList,GetDeviceIdStr(pUserInfo,i+1));
                if (Debug) printf("[ukillrequest] user line=%d.\n",iLineNumber);
                PidToKill=GetDevice(pDeviceList,iLineNumber)->login_pid;
                LogKill(pDeviceList,iLineNumber);
                if (RealKill) kill(PidToKill,SIGKILL);
                else if (Debug) printf("not really killing pid %d\n",PidToKill);
                GetDevice(pDeviceList,iLineNumber)->occupied=FALSE;
                GetDevice(pDeviceList,iLineNumber)->logout_time=CurrentTime;
                strncpy(GetDevice(pDeviceList,iLineNumber)->prev_user,pUserToKill,UT_NAMESIZE);
                GetDevice(pDeviceList,iLineNumber)->current_user[0]='\0';
                i++;
            }
            break;
        default:
            if (Debug) printf("unrecognised client request.\n");
            break;
        case S_DKILLREQUEST:
            if (Debug) printf("S_DKILLREQUEST\n");
            cFill(pDevToFree,'\0',max_path_length);
            break;
        case S_UDKILLREQUEST:
            // doesnt currently work.. hangs at write(S_START) line.
            if (Debug) printf("S_UDKILLREQUEST\n");
            cFill(pUserToKill,'\0',iMaxUserNameLength);
            cFill(pDevToFree,'\0',max_path_length);
            // get username.
            for (i=0;i<iMaxUserNameLength;i++)
            {
                if (!read(ns,pUserToKill[i],sizeof(char))) break;
            }
            if (Debug) printf("[udkillrequest] user \"%s\".\n",pUserToKill);
            // send an S_START and get the deviceId.
            ClientMsg=S_START;
            write(ns,&ClientMsg,sizeof(ClientMsg));
            for (i=0;i<max_path_length;i++)
            {
                if (!read(ns,pDevToFree[i],sizeof(char))) break;
            }
            if (Debug) printf("[udkillrequest] device \"%s\".\n",pDevToFree);
            break;
        }
        
    }
    return ReadSuccess;
}
