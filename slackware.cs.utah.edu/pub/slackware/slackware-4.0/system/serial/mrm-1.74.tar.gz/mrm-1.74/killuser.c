//      Modem Resource Manager.
//	Copyright (C) 1996-1997 Tim Hart.
//	
//	Author: Tim Hart
//
//	killuser.c
//
//	killuser interface to mrm, client to the mrm server.
//

#include "./mrmfeatures.h"
#include "./mrmtypes.h"
#include "./mrmglobals.h"

// routines.
//
BOOL ClientConnect();
BOOL MakeRequest(char);
void KillUserCmdLine(int argc, char **argv);
void cFill(char *,char,int);
void iFill(int *,int,int);

//
////////////////////

// globals
//
char hostname[64];
struct hostent * hp;
int s;
struct sockaddr_un s_address;
//
/////////////////////

main (int argc,char **argv)
{
    int i;
    char ServerReply;
    
    LogMsg("Killuser Executed.");
    printf("Modem Resource Manager %s, %s : [killuser] module.\n",V_INFO,A_INFO);
    KillUserCmdLine(argc,argv);
    
    if (!ClientConnect())
    {
        printf("ClientConnect() error detected.\n");
        exit(1);
    }
    if ((pDevToFree[0]!='\0')&&(pUserToKill[0]!='\0'))
    {
        // make a udkillrequest.
        if (MakeRequest((char)S_UDKILLREQUEST))
        {
            if (Debug) printf("request made, sending username: \"%s\".\n",pUserToKill);
            for (i=0;i<(strlen(pUserToKill));i++)
            {
                write(s,pUserToKill[i],sizeof(char));
            }
            // read an S_START and then send the deviceId.
            sleep(2);
            switch (read(s,&ServerReply,sizeof(char)))
            {
            case 0:
                if (Debug) printf("read: eof on socket.\n");
                break;
            case (-1):
                if (Debug) printf("read: error occured.\n");
                break;
            case (sizeof(char)):
                if (Debug) printf("read: success, ");
                // ok.. got a byte, now see what this byte means.
                if (Debug) printf("byte recieved =%d.\n",ServerReply);
                break;
            default:
                if (Debug) printf("read: big problem occured.\n");
                break;
            }
            if (ServerReply==S_START)
            {
                for (i=0;i<(strlen(pDevToFree));i++)
                {
                    write(s,&(pDevToFree[i]),sizeof(char));
                }
            }
        }
    }
    if ((pDevToFree[0]!='\0')&&(pUserToKill[0]=='\0'))
    {
        // make a udkillrequest.
        if (MakeRequest((char)S_DKILLREQUEST))
        {
            if (Debug) printf("request made, sending device string: \"%s\".\n",&pDevToFree);
            for (i=0;i<(strlen(pDevToFree));i++)
            {
                write(s,&(pDevToFree[i]),sizeof(char));
            }
        }
    }
    if ((pDevToFree[0]=='\0')&&(pUserToKill[0]!='\0'))
    {
        // make a udkillrequest.
        if (MakeRequest((char)S_UKILLREQUEST))
        {
            if (Debug) printf("request made, sending device string: \"%s\".\n",pUserToKill);
            for (i=0;i<(strlen(pUserToKill));i++)
            {
                write(s,&(pUserToKill[i]),sizeof(char));
            }
        }
    }
    
    exit(1);
}

BOOL ClientConnect()
{

    BOOL ConnectStatus;
    ConnectStatus=TRUE;
    
    /* get socket to work with.*/
    if ((s=socket(AF_UNIX,SOCK_STREAM,0))<0)
    {
        printf("client: socket error.\n");
        ConnectStatus=FALSE;
    }

    // create address connecting to.
    s_address.sun_family = AF_UNIX;
    strcpy(s_address.sun_path,un_sock_addr);
    
    /* try to connect to address. */
    // may need (struct sockaddr *) type cast.
    if (connect(s,&s_address,sizeof(s_address)) <0)
    {
        printf("client: connect error.\n");
        ConnectStatus=FALSE;
    }
    
    return ConnectStatus;
}

BOOL MakeRequest(char ServerRequest)
{
    // this routine attempts to send a byte to the server
    // the byte will differ depending on the information the
    // client is after.

    BOOL RequestSent;
    int WriteStatus;
    struct timeval S_timeout;
    fd_set pSelectWriteSet;
    
    RequestSent=FALSE;

    if (Debug) printf("MakeRequest()\n");

    FD_SET(s,&pSelectWriteSet);
    S_timeout.tv_sec=0;
    S_timeout.tv_usec=0;
    select(s+1,NULL,&pSelectWriteSet,NULL,&S_timeout);
    if (!FD_ISSET(s,&pSelectWriteSet))
    {
        if (Debug) printf("MakeRequest(): Socket Not ready for write().\n");
        return RequestSent;
    }
    
    WriteStatus=write(s,&ServerRequest,sizeof(ServerRequest));

    switch (WriteStatus)
    {
    case 0:
        printf("write: 0 returned... nothing written!\n");
        break;
    case (-1):
        printf("write: -1 returned. error occured.\n");
        break;
    case (sizeof(ServerRequest)):
        if (Debug) printf("write: success... \n");
        RequestSent=TRUE;
        break;
    default:
        printf("hmmm default... thats bad.\n");
        break;
    }
    return RequestSent;
}

void KillUserCmdLine(int argc, char **argv)
{
    int i;
    BOOL CmdError,UserNameGiven,DeviceIdGiven;

    UserNameGiven=FALSE;
    CmdError=FALSE;
    cFill(pDevToFree,'\0',max_path_length);
    cFill(pUserToKill,'\0',iMaxUserNameLength);
    
    if (argc>1)
    {
        for (i=1;i<argc;i++)
        {
            switch (argv[i][0])
            {
            case '-':
                {
                    switch (argv[i][1])
                    {
                    case 'd':
                        Debug=(!Debug);
                        continue;
                    case 'e':
                        ExemptKillGuard=(!ExemptKillGuard);
                        continue;
                    case 'h':
                        CmdError=TRUE;
                        continue;
                    case 'l':
                        Logging=(!Logging);
                        continue;
                    case 'r':
                        RankingKillGuard=(!RankingKillGuard);
                        continue;
                    case 'o':
                        if ((i+1)<argc)
                        {
                            printf("[-o devId] not _yet_ implemented.\n");
                            //strncpy(pDevToFree,argv[i+1],max_path_length);
                            //DeviceIdGiven=TRUE;
                        }
                        else
                        {
                            printf("Invalid -o option.\n");
                            CmdError=TRUE;
                        }
                        i++;
                        continue;
                    case 'v':
                        printf("[killuser module] Compiled Form Of: %s on: %s at: %s\nCopyright (C) 1996-1997, Tim Hart\n",__FILE__,__DATE__,__TIME__);
                        exit(1);
                        continue;
                    default:
                        printf("Parameter %d unrecognised \"-%c\".\n",i,(char)(argv[i][1]));
                        CmdError=TRUE;
                        continue;
                    }
                break;
                }
            default:
                // ok, its a username.
                strncpy(pUserToKill,argv[i],iMaxUserNameLength);
                if (Debug) printf("Parameter %d recognised as username: \"%s\".\n",i,argv[i]);
                UserNameGiven=TRUE;
                break;
            }
        }
    }
    else
    {
        if (Debug) printf("No command line options detected.\n");
        CmdError=TRUE;
    }
    if ((CmdError)||(!((UserNameGiven)||(DeviceIdGiven))))
    {
        printf("%s",KillUserUsageMesg);
        exit(1);
    }
    if (Debug) printf("end KillUserCmdLine().\n");
}

void LogMsg(char * logmsg)
{
    FILE * logfp;
    time_t TimeStore;
    struct tm * TimeNow;

    TimeStore=time(NULL);
    TimeNow=localtime(&TimeStore);
    if (Logging)
    {
        if ((logfp=fopen(log_path,"a+"))==NULL) printf("CANNOT OPEN LOG FILE!\n");
        fprintf(logfp,"[msg]    |%s, %02d %s. %02d:%02d:%02d| %s\n",\
                GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
                TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,logmsg);
        fclose(logfp);
    }
    else
    {
        printf("[msg]    |%s, %02d %s. %02d:%02d:%02d| %s\n",\
               GetDay(TimeNow->tm_wday),TimeNow->tm_mday,GetMonth(TimeNow->tm_mon),\
               TimeNow->tm_hour,TimeNow->tm_min,TimeNow->tm_sec,logmsg);
    }
}

char * GetDay(int in_day)
{
    switch (in_day)
    {
    case 0: return "Sun";
    case 1: return "Mon";
    case 2: return "Tue";
    case 3: return "Wed";
    case 4: return "Thu";
    case 5: return "Fri";
    case 6: return "Sat";
    }
}

char * GetMonth(int in_month)
{
    switch (in_month)
    {
    case 0: return "Jan";
    case 1: return "Feb";
    case 2: return "Mar";
    case 3: return "Apr";
    case 4: return "May";
    case 5: return "Jun";
    case 6: return "Jul";
    case 7: return "Aug";
    case 8: return "Sep";
    case 9: return "Oct";
    case 10: return "Nov";
    case 11: return "Dec";
    }
}

void cFill(char * pArray,char FillChar,int iNumElements)
{
    int i;

    for (i=0;i<iNumElements;i++) pArray[i]=FillChar;
}

void iFill(int * pArray,int FillInt,int iNumElements)
{
    int i;

    for (i=0;i<iNumElements;i++) pArray[i]=FillInt;
}

