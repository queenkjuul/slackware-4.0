// Copyright 1996 - 1997, Tim Hart.
// All rights reserved.
//
// Modem Resource Manager.
//
//	Author: Tim Hart.
//
//	Purpose: Monitors and Manages selected tty(s) and performs
//		 required logout procedures when modem use is too high.
//		 >Makes use of /etc/mrmtty
//			       /etc/mrmgroup
//			       /etc/mrmexempt
//		 >Uses dynamic data structures
//		 >Catches SIGHUP, then updates setup.
//
//
//	Comments: Limited testing as yet.
//		  READ THE README :).
//

#include "./mrmfeatures.h"
#include "./mrmtypes.h"
#include "./mrmglobals.h"
#include "./mrmroutines.h"

int main(int argc,char **argv)
{
    int BodyCount=0;
    DEV_INFO_BASE * pDeviceList;
    USER_BASE * pUserList;
    GLG_BASE * pGLGList;
    EXEMPT_BASE * pExemptList;
    KICK_BASE * pKickList;
    pid_t tmp_pid;
    time_t iStartTime,iClientSnooze,iClientStartTime,iTimer1;
    BOOL bTimeClient=FALSE;
    int i;
    int (*pSignalHandle) (int);

    LogMsg("MRM Started.");
    printf("Modem Resource Manager %s, %s.\n",V_INFO,A_INFO);
    iStartTime=time((time_t *)NULL);
    iTimer1=iStartTime;
    CmdLine(argc,argv);
    if (VisServer) ServerInit();
    if (ForkJob)
    {
        tmp_pid=getpid();
        if (fork()==-1) Fatality("Fork. Could Not Spawn Child.");
        /* kill parent. */
        if (tmp_pid==getpid()) exit(0);
    }
    pSignalHandle=SignalHandle;

    if (setjmp(env)==0)
    {
        pDeviceList=NewDeviceBase();
        if (!pDeviceList) Fatality("NULL DEVICE BASE");
        if (RankingBased)
        {
            pUserList=NewUserBase();
            if (!pUserList) Fatality("NULL USER BASE");
        }
        pGLGList=NewGLGBase();
        if (!pGLGList) Fatality("NULL GLG BASE");
        if (ExemptUserChecks)
        {
            pExemptList=NewExemptBase();
            if (!pExemptList) Fatality("NULL EXEMPT BASE");
        }
        // setup the kickedList.
        pKickList=NewKickBase();
        if (!pKickList) Fatality("NULL KICK BASE");
        // done.
    }
    else
    {
#ifdef DO_BASE_DELETION
        if (!DelDeviceBase(pDeviceList)) Fatality("DelDeviceBase()");
        if (RankingBased) if (!DelUserBase(pUserList)) Fatality("DelUserBase()");
        else if (!DelGLGBase(pGLGList)) Fatality("DelGLGBase()");
        if (ExemptUserChecks) if (!DelExemptBase(pExemptList)) Fatality("DelExemptBase()");
        if (!DelKickBase(pKickList)) Fatality("DelKickBase()");
#endif
        pDeviceList=NewDeviceBase();
        if (!pDeviceList) Fatality("NULL DEVICE BASE");
        if (RankingBased)
        {
            pUserList=NewUserBase();
            if (!pUserList) Fatality("NULL USER BASE");
        }
        else
        {
            pGLGList=NewGLGBase();
            if (!pGLGList) Fatality("NULL GLG BASE");
        }
        if (ExemptUserChecks)
        {
            pExemptList=NewExemptBase();
            if (!pExemptList) Fatality("NULL EXEMPT BASE");
        }
        pKickList=NewKickBase();
        if (!pKickList) Fatality("NULL KICK BASE");
    }
    if (Debug) printf("ConfigRead() call.\n");
    ConfigRead(pDeviceList,pUserList,pGLGList,pExemptList);
    if (CatchSigHup) signal(SIGHUP,(void *)pSignalHandle);
    for (;;)
    {
        if (DebugLog) LogDebug("Forever Loop.");
        DebugSizeOk();
        UtmpRead(pDeviceList);
        MultipleLoginKill(pDeviceList,pUserList,pGLGList);
        KickListPurge(pKickList);
	ReLoginCheck(pDeviceList,pKickList);
        // check if there are enuff free modems... if not.. kill off as many as needed.
        if (DebugLog) LogDebug("TimeCheck Outside.");
        if (BodyCount=TimeCheck(pDeviceList))
        {
            if (DebugLog) LogDebug("TimeCheck Inside.");
            if (RankingBased) RankingDieModule(pDeviceList,pUserList,pExemptList,pKickList,BodyCount);
            else DieTimeBandits(pDeviceList,pUserList,pGLGList,pExemptList,pKickList,BodyCount);
        }
        if (DebugLog) LogDebug("iNumClients");
        Connection();
        if (iNumClients>0)
        {
            if (!RequestHandle(pDeviceList,pUserList,pKickList,pGLGList,pExemptList,iStartTime))
            {
                if (!bTimeClient) iClientStartTime=time((time_t *)NULL);
                bTimeClient=TRUE;
                iClientSnooze=(time((time_t *)NULL)-iClientStartTime);
                if (Debug) printf("iClientSnooze=%d, iClientStartTime=%d.\n",iClientSnooze,iClientStartTime);
                if (iClientSnooze>iClientTimeOut)
                {
                    if (Debug) printf("Client has timed out.\n");
                    iNumClients--;
                    bTimeClient=FALSE;
                }
            }
            else bTimeClient=FALSE;
        }
        if (PppPapMon)
        {
        // timer related operations get done before the sleep.
        if ((time((time_t *)NULL)-iTimer1)>iPppPapMonPeriod)
        {
            if (Debug) printf("time to check the ppp login.\n");
            for (i=0;i<pDeviceList->NumberOfDevices;i++)
            {
                if (strcmp(PAP_LOGIN,User(pDeviceList,i+1)))
                {
                    if (Debug) printf("PAP_LOGIN found. - checking if timed-out.\n");
                    if ((time((time_t *)NULL)-(GetDevice(pDeviceList,i+1)->login_time))>PAP_TIMEOUT)
                    {
                        if (Debug) printf("yep. a timed-out pap ppp login has been found-killing.\n");
                        LogKill(pDeviceList,i+1);
                        if (RealKill) kill(GetDevice(pDeviceList,i+1)->login_pid,SIGKILL);
                    }
                }
            }
            iTimer1=time((time_t *)NULL);
        }
        }
        if (Debug)
        {
            if (VisServer) printf("Currently Serving %d Client(s) out of Max %d.\n",iNumClients,iMaxClients);
            printf("__________> Sleeping %d.",iLoopSleep);
        }
        sleep(iLoopSleep);	// is this only _safe_ time for a signal?.
    } // test forever loop.
}
