 
#include "dbase.p"

char *append_line(char *file, char *line)
{
    char
	*ret;

    ret = xmalloc(strlen(file) + strlen(line) + 2);   /* file.line */
    sprintf(ret, "%s.%s", file, line);
    return (ret);
}
