
#include "config.p"

char *get_emailaddress()
{
    return (email_address);
}