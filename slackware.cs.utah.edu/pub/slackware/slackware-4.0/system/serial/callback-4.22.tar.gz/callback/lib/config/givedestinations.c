
#include "config.p"

int givedestinations()
{
    return (show_destinations);
}
