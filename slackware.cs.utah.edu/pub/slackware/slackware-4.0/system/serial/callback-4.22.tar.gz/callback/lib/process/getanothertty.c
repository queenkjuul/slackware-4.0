
#include "process.p"

char *get_another_tty()         /* get any tty, but the defaultline */
{   
    int 
        index;
    char
        *line = get_default_tty();
              
    for (index = 0; index != n_available; index++)
    {       
        char
            *try_line = available[index].line;
        if 
	(
	    strcmp(try_line, line)                  /* another line */
            &&
            available[index].state <= 0             /* which is not busy */
        )
        {
            log(log_on, "switching to free line '%s' for callback", try_line);
            activate_ttyline(lookup_tty(try_line));
            return (try_line);
        }
    }
    return (0);                                     /* no available line */
}

