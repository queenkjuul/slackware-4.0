
#include "dname.p"

char *get_dname(unsigned index)
{
    return (dname_vector[index].name);
}
