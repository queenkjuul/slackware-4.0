#ifndef _mem_H_
#define _mem_H_

#include <stdio.h>
#include <string.h>        
#include <stdlib.h>

#include "../error/error.h"

/* mem-functions: */

void        *xmalloc(unsigned size);                /* protected malloc() */
void        *xstrdup(char *s);                      /* protected strdup () */
void        *xrealloc(void *mem, unsigned size);    /* protected realloc() */

#endif  _mem_H_
