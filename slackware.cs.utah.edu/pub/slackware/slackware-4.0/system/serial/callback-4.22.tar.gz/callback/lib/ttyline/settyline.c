
#include "ttyline.p"

void settyline(char *next)
{
    ttyline = xrealloc(ttyline, ++n_lines * sizeof(char *));
    ttyline[n_lines - 1] = xstrdup(next);
}

