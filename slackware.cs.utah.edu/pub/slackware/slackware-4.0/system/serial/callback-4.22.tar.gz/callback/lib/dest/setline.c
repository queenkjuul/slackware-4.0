
#include "dest.p"

void set_line(char *line)
{       

    DESTINATION_
        *last = &destination[ndestinations - 1];

    if (!line)                      /* use default (active) line */
        last->line = 0;
    else if 
    (
        !strcmp(line, "")           /* empty string: don't use current line */
        ||  
        lookup_tty(line) != -1      /* line exists: use specific line */
    )
        last->line = xstrdup(line); /* store the line */
    else
        yysemantic("No such line.");
}
