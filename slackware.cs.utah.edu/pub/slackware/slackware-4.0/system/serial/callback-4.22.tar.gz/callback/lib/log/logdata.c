
#include "log.p"
#include "../../configure.h"

LOG_TYPE_
    log_type;

unsigned
    log_defaults;

char
    *log_filename = LOGFILENAME,
    *diallog_filename = DIALLOGFILENAME,
    *panic_filename = PANICLOGFILE;

