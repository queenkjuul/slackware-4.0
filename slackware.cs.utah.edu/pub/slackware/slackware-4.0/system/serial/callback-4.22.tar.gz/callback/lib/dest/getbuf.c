
#include "dest.p"

char *getbuf(char *buf, unsigned buflen)
{
    int
	idx,
	c = '\n';
    register char
	*cp;

    buflen--;				/* room for the final 0 */

    for (cp = buf, idx = 0; idx < buflen; idx++)    /* read a buffer */
    {
	c = getchar();			/* fetch a char */

	if (c == '\n')			/* read until \n */
	    break;

	*cp++ = (char)c;		/* store the char */
    }

    while (c != '\n')			/* keep reading until EOF or \n */
	c = getchar();

    *cp = 0;				/* terminate the number */

    return
    (
	*buf ?				/* something entered ? */
	    buf				/* then return buf */
	:
	    NULL			/* else return NULL */
    );
}
