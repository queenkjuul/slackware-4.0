 
#include "cblogin.h"

void determine_tty()
{
    char
        *tty_name;
                                        /* get the devicename */
    if (!(tty_name = ttyname(fileno(stdin))))
	error("Can't find the tty-name");

					/* use the name without '/dev/' */
    tty_name = strrchr(tty_name, '/') + 1;
                                        /* activate it (or error) */
    if (activate_ttyline(lookup_tty(tty_name)))
        error("Line %s not available for callback", tty_name);
        
    assign_filenames(tty_name);         /* make proper tty-filenames */
}
