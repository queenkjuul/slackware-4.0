
#include "dbase.p"

void enable_state()
{
    unlink_files();
    copyfile(filename[the_enablefile], filename[the_activefile]);
    make_configfile();
}
