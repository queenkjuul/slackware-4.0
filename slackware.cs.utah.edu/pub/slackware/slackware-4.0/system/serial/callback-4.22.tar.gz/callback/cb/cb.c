
#include "cb.h"

int main(int argc, char **argv)
{
    logging(&argc, &argv);      /* determine log-request from -l flag */

    startup(argc, argv);        /* initial startup:
                                    read the setupfile, determine the name of 
                                    the tty-line to be used
                                */

    if (argc == 1)              /* parsing succeeded here */
    	usage();

    argv1len = strlen(argv[1]);

    use_ttyline(argv[2]);	/* determine the line, usually in argv[2] */

    task(argc, argv);           /* do the appropriate task */

    return(0);
}
    	
