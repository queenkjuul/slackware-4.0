#include "cblogin.h"            

void login(char *name)
{
    int					
	state,
	uid;
        
    switch (getstate(&state, &uid))     /* do appropriate task */
    {
        case -2:                        /* this shouldn't happen: cbmgetty  */
                                        /* should have forced the enable-   */
                                        /* state                            */
            log(log_off, "Unexpected force-enable state");         

            enable_state();             /* make the enable-state */
        /* FALLING THROUGH */

        case -1:
            first_login(name);          /* state ok: first login */
        break;
        
        case 0:
        default:                        /* default: callback attempt,   */
            exec_login(uid);		/* run original login           */
    }
}
