
#include "user.p"

int combine(int uid, char *where)
{
    unsigned
	index,
	dest;
    char
	*dname;


    if (look_dname(where) == -1)        /* can we get there ?   */
        return (-1);                    /* no, return -1        */ 

                                        /* walk the destinations */
    for (dest = get_ndestinations(); dest--; )
    {
	dname = get_dname(get_dnameindex(dest));    /* keep its name */

	if (!strcmp(where, dname))		/* target matches request */
	{
	    for (index = user_ngroups(uid); index--; )
	    {					/* matching group was found */
		if (usergroup(uid, index) == get_dgroupindex(dest))
		{
		    log(log_on, "Destination %s: ok", where);
		    return (dest);		/* then return the destin.-id */
		}
	    }
	    log(log_on, "Destination %s: no available group", where);
	}
	else
	    log(log_max, "Comparing %s to %s: no match", dname, where);
    }

    return (-1);               
}

