
#include "parser.p"
#include "../../configure.h"

void parse_setupfile(void)
{
    char
	*setup;

    if (!(yyin = fopen(setup = FIRSTSETUP, "r")))	/* open the setupfile */
	if (!(yyin = fopen(setup = SECONDSETUP, "r")))	/* open the setupfile */
	    yyin = xfopen(setup = THIRDSETUP, "r");	/* open the setupfile */

    setbase(setup);

    yyparse();

    if ((parse_errors))				/* or semantic errrors */
	error("Syntax error(s) in %s", setup);
}
