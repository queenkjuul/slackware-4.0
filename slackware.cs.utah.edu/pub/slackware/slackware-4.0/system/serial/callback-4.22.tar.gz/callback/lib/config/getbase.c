
#include "config.p"

char *getbase()
{
    return (base_path);
}