
#include "cb.h"

void state()
{            
    need_cbmode();
    states();
}
