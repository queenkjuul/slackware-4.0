
#include "config.p"

void showdestinations()
{
    show_destinations = 1;
}