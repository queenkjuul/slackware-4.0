
#include "process.p"
#include "../../configure.h"

void killinit()
{
    activate_ttylines();		/* kill them all */

    load(the_enablefile, 1);		/* reload the enable files */

    make_configfile();                  /* make final configuration file */

    if (kill(PID_INIT, SIGHUP))		/* kill init (rereads inittab) */
        error("can't restart init.");

    modem_respawn();                     /* kill all modem processes */

    puts("init restarted (modemlines enabled)\n");
}
    
