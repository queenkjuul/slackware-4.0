
#include "dbase.p"

void load(THE_FILE_ENUM_ the_source, int rm_disablefile)
{                                  
    char
        *line;

    while ((line = get_active_tty()))
    {
        assign_filenames(line);
        copyfile(filename[the_source], filename[the_activefile]);
        unlink(filename[the_statefile]);
        if (rm_disablefile)
        {
            unlink(filename[the_disablefile]);
            log(log_on, "Line %s enabled: %s removed", line, 
                                         getfile(the_disablefile));
        }
        else
            log(log_on, "Enable-file of Line %s installed", line);
    }
    make_configfile();
}

