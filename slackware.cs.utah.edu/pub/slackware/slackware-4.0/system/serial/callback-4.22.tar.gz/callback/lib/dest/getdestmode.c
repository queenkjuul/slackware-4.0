
#include "dest.p"

MODE_ get_destmode(unsigned destindex)
{
    return (destination[destindex].mode);
}
