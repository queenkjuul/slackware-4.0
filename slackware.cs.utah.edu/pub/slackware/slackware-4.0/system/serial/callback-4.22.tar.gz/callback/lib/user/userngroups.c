
#include "user.p"

unsigned user_ngroups(unsigned uid)
{
    return (user[uid].ngroups);
}

