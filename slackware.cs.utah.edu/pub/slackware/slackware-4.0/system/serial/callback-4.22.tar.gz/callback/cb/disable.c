
#include "cb.h"

void disable()
{
    char
        *line;

    while ((line = get_active_tty()))
    {
        char
            *dis;
            
        assign_filenames(line);                  
        dis = getfile(the_disablefile);
        fclose(xfopen(dis, "w"));
        log(log_on, "Disable %s by creating %s", line, dis);

	unlink(getfile(the_statefile));
    }
    load(the_enablefile, 0);                /* make sure calling stops */
    modem_respawn();
}
