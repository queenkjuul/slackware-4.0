
#include "dname.p"

DNAME_
    *dname_vector;
unsigned
    ndnames;
