
#include "startup.p"

void setprogname(char *argv0)
{
    char
        *cp;

    progname =
        xstrdup
        (
            (cp = strrchr(argv0, '/')) ?    /* '/' found in the program ? */    
                cp + 1                      /* the use the program beyond / */    
            :
                argv0                       /* otherwise use argv0 */    
        );
}
