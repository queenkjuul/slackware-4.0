
#include "ttyline.p"

char *get_default_tty()
{       
    return (ttyline[active_line == -1 ? 0 : active_line]);
}
