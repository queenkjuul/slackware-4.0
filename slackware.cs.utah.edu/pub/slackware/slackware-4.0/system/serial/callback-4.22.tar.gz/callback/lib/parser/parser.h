#ifndef _parser_H_
#define _parser_H_

#include "../config/config.h"
#include "../log/log.h"
#include "../dbase/dbase.h"
#include "../dest/dest.h"
#include "../ttyline/ttyline.h"
#include "../dgroup/dgroup.h"
#include "../user/user.h"

void parse_setupfile();
void parse_error();
void yysemantic(char *s, ...);


#endif  _parser_H_
