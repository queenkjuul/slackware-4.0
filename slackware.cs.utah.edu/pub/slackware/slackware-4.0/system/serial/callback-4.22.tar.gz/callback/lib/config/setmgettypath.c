
#include "config.p"

void setmgettypath(char *name)
{
    mgetty_path = xstrdup(name);
}

