#include "user.p"

unsigned lastuser()
{
    return (nusers - 1);
}
