
#include "cb.h"

void maybe_force()
{                                
    need_cbmode();

    if (gargc != 3 && gargc != 4)       /* 'force' only with 3 or 4 args */
        usage();
        
    use_ttyline(gargv[3]);
    force(gargv[1], gargv[2]);          /* force cb to user (1) at dest (2) */
}
