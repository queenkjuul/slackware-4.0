#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	USERS	258
#define	LINE	259
#define	IDENTIFIER	260
#define	DESTINATIONS	261
#define	NUMBER	262
#define	DIRECT	263
#define	EXTRA	264
#define	USING	265
#define	PATH	266
#define	MGETTYCONFIG	267
#define	MODEMBASE	268
#define	LOGIN	269
#define	EMAIL	270
#define	PANICLOG	271
#define	LOGFILE	272
#define	RETRY	273
#define	SHOWNUMS	274
#define	CALL	275
#define	LOG	276
#define	ON	277
#define	DEFAULT	278
#define	OFF	279
#define	MAX	280
#define	MAXTIME	281
#define	MODE	282
#define	CALLBACK	283
#define	DIALIN	284
#define	NODESTINATIONS	285
#define	DIALLOG	286
#define	TTYNR	287
#define	TTYFREE	288


extern YYSTYPE yylval;
