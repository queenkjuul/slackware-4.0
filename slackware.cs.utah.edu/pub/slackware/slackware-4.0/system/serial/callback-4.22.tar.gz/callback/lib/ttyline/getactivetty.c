
#include "ttyline.p"

char *get_active_tty()
{       
    if (active_index == n_lines)        /* at the end of the set */
    {
        reset_active_tty();
        return (NULL);                      
    }
    
    if (active_line == -1)              /* all lines are active */
        return (ttyline[active_index++]);/* return line, upgrade to next */
        
    active_index = n_lines;             /* one line: next call returns NULL */

    return (ttyline[active_line]);      /* return the active line */
}