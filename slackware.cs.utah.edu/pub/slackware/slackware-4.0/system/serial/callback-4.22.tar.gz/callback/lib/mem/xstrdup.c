
#include "mem.p"

void *xstrdup(char *s)
{
    if (!(s = strdup(s)))
        error(out_of_memory);

    return (s);
}
