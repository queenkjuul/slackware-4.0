
#include "dname.p"        

int look_dname(char *dname)
{
    int
        index;

    for (index = 0; index < ndnames; index++)	/* look for the target */
    {
	if (!strcmp(dname_vector[index].name, dname))	/* name found */
	    return (index);			/* ok */
    }   
    return (-1);                                /* not found */
}
