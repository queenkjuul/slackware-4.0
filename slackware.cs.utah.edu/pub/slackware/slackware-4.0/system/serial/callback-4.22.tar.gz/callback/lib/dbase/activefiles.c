
#include "dbase.p"

void active_files()
{
    FILE
    	*inf;
    char
        *line,
    	*cp;

    while ((line = get_active_tty()))
    {
	make_filenames(line);		    /* define the line to use */

	inf = xfopen(filename[the_activefile], "r");
    	
	printf("Active file: \"%s\":\n", filename[the_activefile]);

	while((cp = fgetline(inf)) )
	    printf("    %s\n", cp);

	fclose(inf);
        
        tellstate(line);
    }
}
    
    
