
#include "log.p"

void setpanicfilename(char *name)
{
    panic_filename = xstrdup(name);
}
