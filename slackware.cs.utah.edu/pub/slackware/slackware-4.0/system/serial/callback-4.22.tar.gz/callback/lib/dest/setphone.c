
#include "dest.p"

void set_phone(char *phone)
{					    /* set the destinationfile */
    set_phonenr(ndestinations - 1, phone);
}
