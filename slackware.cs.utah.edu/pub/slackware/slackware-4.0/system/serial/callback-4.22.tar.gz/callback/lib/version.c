
char
    version[] = "4.22",
    year[]    = "1993--1997";
    
