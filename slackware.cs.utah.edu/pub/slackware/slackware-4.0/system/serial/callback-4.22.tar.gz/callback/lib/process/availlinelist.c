
#include "process.p"
#include "../../configure.h"

void availline_list()
{
    FILE
    	*pslist;
    unsigned
        nlines = 0;
    char    
    	buf[500];

    if (!(pslist = popen(PSCMD, "r")))
    	error("Can't get processes list");
 
    log(log_max, "Looking for %s-processes", getmodembase());

    if (available)
        free(available);                        /* Never mind allocated mem. */
    available = NULL;                           /* for the linenames */

    n_available = 0;

    while (fgets(buf, 499, pslist))             /* walk all processes */
    {
        nlines++;
        linestate(buf);                         /* store the line-state */
    }
     
    if (!nlines)
        log(log_off, "No processes retrieved");

    pclose(pslist);
}
               
