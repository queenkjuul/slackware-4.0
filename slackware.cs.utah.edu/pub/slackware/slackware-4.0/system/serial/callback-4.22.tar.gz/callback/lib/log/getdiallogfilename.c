
#include "log.p"

char *get_diallogfilename()
{
    return (diallog_filename);
}
