
#include "dgroup.p"

int newgroup(char *gp)
{
    return
    (
        lastusergroup(lookgroup(gp))
    );
}
