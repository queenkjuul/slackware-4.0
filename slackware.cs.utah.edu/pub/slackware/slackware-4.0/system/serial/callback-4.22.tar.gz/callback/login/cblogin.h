#ifndef _login_H_
#define _login_H_

#include <stdio.h>           
#include <unistd.h>

#include "../lib/startup/startup.h"
#include "../lib/ttyline/ttyline.h"
#include "../lib/dbase/dbase.h"
#include "../lib/user/user.h"
#include "../lib/dest/dest.h"

void banner();
void determine_tty();
void login(char *username);
unsigned validate (char *username);
int get_destination(int uid);
void first_login(char *username);
void exec_login(int uid);


#endif
