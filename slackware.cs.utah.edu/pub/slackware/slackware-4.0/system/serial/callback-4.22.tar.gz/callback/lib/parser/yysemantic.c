
#include "parser.p" 

void yysemantic(char *fmt, ...)
{
    va_list
        list;
        
    va_start(list, fmt);

    parse_errors++;
    printf("Line %d at '%s': ", yylineno, yytext);
    vprintf(fmt, list);
    putchar('\n');
}
