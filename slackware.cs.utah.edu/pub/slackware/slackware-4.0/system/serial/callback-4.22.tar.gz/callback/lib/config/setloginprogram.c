
#include "config.p"

void setloginprogram(char *prog)
{
    login_program = xstrdup(prog);
}
