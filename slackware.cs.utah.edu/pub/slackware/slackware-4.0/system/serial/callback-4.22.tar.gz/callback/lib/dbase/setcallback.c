
#include "dbase.p"

void setcallback(int uid, int dest)
{
    log(log_on, "setcallback(%d (= %s), %d (= %s))",
        uid, username(uid),
        dest, get_dname(get_dnameindex(dest)));

    make_activefile(uid, dest);			/* make new active file */
    
    log(log_max, "setcallback() calling make_configfile()");
    make_configfile();                          /* new mgetty config file */

    log(log_max, "setcallback() calling writestate()");
    writestate(get_ntries(), uid);		/* initialize state-file */

    log(log_max, "setcallback() completed");
}
