
#include "cblogin.h"

int get_destination(int uid)
{
    char
    	where[30];				/* buffer for destination */
    int
	dest;
    	
    printf("----------------------------------\n"
	   "Enter the callback-destination for %s: ", username(uid));


    if (!getbuf(where, 30))		    /* read input (return max 30) */
    {                                       /* no input: reset to enable */
	log(log_on, "Callback cancelled by %s", username(uid));
	puts("Callback cancelled");	    /* reset the file and exit */
        enable_state();                     
	exit (1);
    }
    

    if ((dest = combine(uid, where)) == -1) /* invalid callback name ? */
    {
	log(log_default, "Invalid destination '%s' requested by %s",
		    where,
		    username(uid));
	printf("Can't callback %s at %s\n", username(uid), where);
	enable_state();
	exit (1);
    }

    return (dest);
}
