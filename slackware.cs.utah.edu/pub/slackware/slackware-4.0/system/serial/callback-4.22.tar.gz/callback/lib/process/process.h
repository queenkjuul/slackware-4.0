#ifndef _process_H_
#define _process_H_
                        
void availline_list();
void modem_respawn();
void killinit();
char *get_another_tty();                /* return another avail. line, make */
                                        /* it the default, or return 0 */
int switch_tty(char *line);             /* switch to another ttyline and */
                                        /* make it the default, or return 0 */

#endif  _process_H_
