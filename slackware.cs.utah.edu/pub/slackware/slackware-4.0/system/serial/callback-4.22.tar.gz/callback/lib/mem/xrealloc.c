
#include "mem.p"

void *xrealloc(void *s, unsigned size)
{
    if (!(s = realloc(s, size)))
        error(out_of_memory);

    return (s);
}
