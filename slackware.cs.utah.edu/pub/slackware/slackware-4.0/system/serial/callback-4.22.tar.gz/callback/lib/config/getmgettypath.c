
#include "config.p"

char *getmgettypath()
{
    return (mgetty_path);
}