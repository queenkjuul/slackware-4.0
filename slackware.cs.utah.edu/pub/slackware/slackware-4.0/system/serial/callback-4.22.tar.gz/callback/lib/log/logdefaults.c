
#include "log.p"

unsigned logdefaults()
{
    return (log_defaults);
}