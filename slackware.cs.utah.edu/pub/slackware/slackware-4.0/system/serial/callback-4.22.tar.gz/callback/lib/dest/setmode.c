
#include "dest.p"

void set_cbmode(MODE_ mode)
{					    /* set the destinationfile */
    destination[ndestinations - 1].mode = mode;
    destination[ndestinations - 1].phonenr =
	xstrdup
	(
	    mode == direct_mode ?
		"dial-in"
	    :
		"ask cb-number"
	);
}
