
#include "cblogin.h"

void error (char *fmt, ...)
{
    va_list
    	args;
    	
    va_start (args, fmt);		/* get the arguments */
					/* display message to user */
    if (!get_emailaddress())
	puts("The callback wasn't established.\n"
	    "Please repair the following problem:");
    else
	printf("The callback wasn't established.\n"
	    "Please inform %s about the following problem:\n"
		, get_emailaddress());

    vprintf(fmt, args);			/* print the message itself */
    putchar('\n');			/* and nl */

    logv(fmt, args);			/* log the error */
    exit (1);
}
    
