
#include "dgroup.p"

void addgroup(char *group)
{
    if (newgroup(group))		    /* if this is a newgroup */
	tag_dnames();			    /* then tag the dnames */
}
