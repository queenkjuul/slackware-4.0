#ifndef _error_H_
#define _error_H_

/*  The generic error function must be defined with every program.
    It is only declared here for translation/declaration purposes
*/                                       

void	    error(char *fmt, ...);	    /* generic error function:
                                               print message and die 
					    */

#endif  _error_H_
