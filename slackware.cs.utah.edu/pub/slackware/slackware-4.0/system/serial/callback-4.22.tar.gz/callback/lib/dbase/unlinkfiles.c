
#include "dbase.p"

void unlink_files()
{
    unlink(filename[the_statefile]);
    unlink(filename[the_disablefile]);
}