
#include "log.p"

void logv(char *fmt, va_list args)
{
    FILE
        *logfile;
    time_t
        ltime;

    if 
    (
        (logfile = fopen (log_filename, "a")) /* logfile opened ok */
        ||
        (logfile = fopen (panic_filename, "a")) /* panicfile opened ok */
    )
    {
        time (&ltime); 
        fprintf
	(
	    logfile, "%s %s V %s: ", ctime (&ltime),
	    getprogname(), version
	);
        vfprintf (logfile, fmt, args);
	fputc('\n', logfile);

        fclose(logfile);
    }
}
