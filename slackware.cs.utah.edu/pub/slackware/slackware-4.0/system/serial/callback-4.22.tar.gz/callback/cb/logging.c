#include "cb.h"    

void logging(int *argc, char ***argv)
{                                                            
                                /* log requested */
    if (*argc > 1 && !strcmp((*argv)[1], "-l"))
    {
        set_logdefaults();
	(*argv)[1] = (*argv)[0];
	--*argc;
	++*argv;
    }
}
