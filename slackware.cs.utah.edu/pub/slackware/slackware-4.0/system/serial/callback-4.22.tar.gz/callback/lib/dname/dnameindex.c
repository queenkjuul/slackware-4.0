
#include "dname.p"

unsigned dname_index(char *dname)
{
    int
	index;

    if ((index = look_dname(dname)) != -1)
        return (index);                         /* name found */

    index = ndnames++;				/* new dname */
    dname_vector = xrealloc(dname_vector, ndnames * sizeof(DNAME_));
    dname_vector[index].name = xstrdup(dname);	/* fill in the new target */
    /*
	usergroup irrelevant at this point: will be set after defining all
	users
    */
    return (index);
}
