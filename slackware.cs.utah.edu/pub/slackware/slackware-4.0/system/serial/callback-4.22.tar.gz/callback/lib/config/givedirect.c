
#include "config.p"

int givedirect()
{
    return (show_direct);
}
