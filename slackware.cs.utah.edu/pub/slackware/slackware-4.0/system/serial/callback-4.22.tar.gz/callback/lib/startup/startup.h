#ifndef _startup_H_
#define _startup_H_

#include "../parser/parser.h"          /* functions related to parsing the
                                           setupfile
					*/
char *getprogname();

void startup(int argc, char **argv);    /* initial startup:    
                                            read setupfile, provide usage    
                                            if arguments aren't ok  */    
                                            
extern char
    version[],
    year[];

#endif  _startup_H_
