
#include "dest.p"

char *get_phone(unsigned dest)
{
    return (destination[dest].phonenr);
}
