
#include "cb.h"

void preusage()
{
    printf(
    	   "%s by Frank B. Brokken.\n"
    	   "\n"
    	   "ICCE Callback Control Unit V %s.\n"
    	   "Copyright(c) ICCE %s. All rights reserved.\n"
    	   "\n"
    	   "Usage: %s [-l] action [line]\n"
	   , getprogname()
	   , version
           , year
	   , getprogname()
    );
}
