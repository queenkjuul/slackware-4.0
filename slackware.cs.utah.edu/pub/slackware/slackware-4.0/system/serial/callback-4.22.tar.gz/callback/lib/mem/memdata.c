
#include "mem.p"

char
    out_of_memory[] = "Out of memory.";
    
