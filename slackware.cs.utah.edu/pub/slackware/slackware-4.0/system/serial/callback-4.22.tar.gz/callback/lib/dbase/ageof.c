
#include "dbase.p"

unsigned ageof(char *fname)
{
    struct stat
        ss;
    unsigned
        secs;
        
    if (stat(fname, &ss))
        return (0);                     /* no file: no time lapsed */
    
    secs = (unsigned)difftime(time(NULL), ss.st_mtime);
    
    log(log_on, "Age of '%s': %u secs", fname, secs);
    return (secs);
}
