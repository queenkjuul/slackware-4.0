
#include "dbase.p"

void writestate (int st, unsigned uid)
{
    FILE
    	*fstate;

    if (getmode() != mode_callback)	/* no callback mode */
	return;
    fstate = xfopen(filename[the_statefile], "w");

    fprintf(fstate, "%d %d", st, uid);		    /* write state/uid */

    log(log_on, "statefile %s: write state %d for %s (uid: %d)",
	filename[the_statefile],
	st,
	username(uid),
	uid);

    fclose (fstate);				    /* close state file */
}
