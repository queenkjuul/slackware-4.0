
#include "dbase.p"

void states()
{
    char
	*line;
	
    while ((line = get_active_tty()))
    {
	make_filenames(line);		    /* define the line to use */
					    /* and disable */
	tellstate(line);
    }
}
