
#include "cbmgetty.h"

/*
    the tty-line must be argv[1]
*/    

void main (int argc, char **argv)
{
    startup(argc, argv);    /* initial startup: 
                                read the setupfile, determine the name of 
                                the tty-line(s) that can be used
                            */
                            
    log(log_default, "'%s %s' started", getprogname(), argv[1]);

    make_filenames(argv[1]);    /* names for file-manipulation, argv[1] */
                                /* must be the ttyS-line to use         */

    update_cbstate(argv[1]);    /* upate to waiting or next callback state */
    
    argv[0] = modemfile();      /* argv[0] = mgetty.ttySx */

    log(log_on, "Executing %s from cbmgetty", argv[0]);
    execv(argv[0], argv);       /* original mgetty program via the link */

    error("Can't exec %s.", argv[0]);   /* we should never get here */
}
