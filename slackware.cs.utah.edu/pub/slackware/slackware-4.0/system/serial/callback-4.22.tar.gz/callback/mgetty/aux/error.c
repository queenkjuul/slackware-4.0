
#include "../cbmgetty.h"

static int
    recursion = 0;                      /* Prevent recursive calls */

void error(char *fmt, ...)		/* local error function, */
{					/* overrules ../rss/error.c */
    va_list
    	args;

    va_start(args, fmt);
    logv(fmt, args);			/* log the error */

    if (!recursion++)	                /* reinitialize only once */
    {
        log(log_on, "Returning to the enable-state");
/*        enable_state(); */
        recursion--;
    }

    exit(1);				/* all out */
}
