
#include "dest.p"

void set_dname(char *dname)
{					    /* set the destination name */
    destination[ndestinations - 1].dname = dname_index(dname);
}
