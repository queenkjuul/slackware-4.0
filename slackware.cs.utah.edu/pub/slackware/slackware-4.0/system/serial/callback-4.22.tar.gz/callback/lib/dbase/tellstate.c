 
#include "dbase.p"       

void tellstate(char *line)
{
    int
	uid,
    	state;

    printf("Callback state %s: ", line);

    if (!access(filename[the_statefile], R_OK))    /* statefile exists ? */    
    {    
        switch (getstate(&state, &uid))
        {    
            case -2:          
                printf(" callback expired: ");    
            /* FALLING THROUGH */    
            
            case -1:    
            case 0:    
                printf(" ready for incoming call.\n");    
            break;    
                
            default:    
                printf(" calling %s (attempt %d).\n",    
	            username(uid),
	            get_ntries() + 1 - state);
        }
    }                                       /* disablefile exists ? */
    else if (!access(filename[the_disablefile], R_OK))
        printf(" incoming calls disabled.\n");
    else
        printf(" ready for incoming calls.\n");
}

