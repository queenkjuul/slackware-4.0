
#include "log.p"

void setlog(LOG_TYPE_ type)
{
    log_type = type;
}