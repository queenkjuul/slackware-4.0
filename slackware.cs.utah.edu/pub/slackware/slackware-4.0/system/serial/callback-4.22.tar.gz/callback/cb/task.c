
#include "cb.h"

void task(int argc, char **argv)
{    
    int
        index = 0;
        
    gargc = argc;                           /* set global argc/argv */
    gargv = argv;

    taskarr[sizeof_taskarr - 1].name = argv[1];    /* set taskname */
    
    for (; ; index++)
    {   
                                                /* look for the argument */
        if (!strncmp(argv[1], taskarr[index].name, argv1len))
            break;
    }

    log(log_default, "'%s %s ...' started", getprogname(), argv[1]);
    taskarr[index].taskfun();               /* do appropriate function */
    return;
}
