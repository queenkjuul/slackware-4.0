
#include "config.p"

unsigned get_ntries()
{
    return (ntries);
}
