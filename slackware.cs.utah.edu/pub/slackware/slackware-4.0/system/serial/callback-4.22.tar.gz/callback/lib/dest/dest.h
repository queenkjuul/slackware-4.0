#ifndef _dest_H_
#define _dest_H_

#include "../dgroup/dgroup.h"
#include "../dname/dname.h"

typedef enum			    /* the callback modi for destinations */
{
    phone_mode,
    direct_mode,
    extra_mode,
} MODE_;

MODE_ get_destmode(unsigned destindex);
unsigned get_dnameindex(unsigned destindex);
unsigned get_dgroupindex(unsigned destindex);
unsigned get_ndestinations();
char *get_phone();
int get_line_to_use(int dest);  
char *get_filename();
char *getbuf(char *buf, unsigned buflen);

void listdestinations(int uid, int all);
void define_dest(char *destname);   /* define a destination (+ name) */
void set_dname(char *dname);
void set_cbmode(MODE_ mode);
void set_phone(char *phone);
void set_file(char *filename);
void set_line(char *line);          /* line to use for callback */
void tag_dnames();
void ask_extra_number(unsigned uid, unsigned dest);

#endif  _dest_H_
