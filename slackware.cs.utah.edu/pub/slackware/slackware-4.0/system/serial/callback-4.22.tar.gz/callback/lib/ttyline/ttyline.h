#ifndef _ttyline_H_
#define _ttyline_H_

#include "../mem/mem.h"

void settyline(char *next);
int activate_ttyline(unsigned index);   /* activate a ttyline  (0: ok) */
void activate_ttylines();               /* activate all ttylines */
int lookup_tty(char *line);             /* return index (or -1) */
char *get_ttyline(unsigned index);      /* return name of ttyline */
char *get_active_tty();                 /* active line(s) in sequence, or 0 */
char *get_default_tty();                /* get the 1st of the active line(s) */
void reset_active_tty();                /* reset to first/active line */

#endif  _ttyline_H_
