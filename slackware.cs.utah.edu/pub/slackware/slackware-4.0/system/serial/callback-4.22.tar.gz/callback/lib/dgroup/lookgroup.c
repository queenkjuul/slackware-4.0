
#include "dgroup.p"

unsigned lookgroup(char *group)
{
    int
	index;

    for (index = 0; index < ndgroupnames; index++)
    {
	if (!strcmp(group, dgroupvector[index]))/* names match ? */
	    return (index);			/* then return its index */
    }
    log(log_off, "lookgroup(): Can't find group %s", group);
    parse_error();

    return (index);				/* group not found */
}
