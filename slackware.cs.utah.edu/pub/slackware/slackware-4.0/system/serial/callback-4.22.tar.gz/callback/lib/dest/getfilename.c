
#include "dest.p"

char *get_filename(unsigned dest)
{
    return (destination[dest].filename);
}
