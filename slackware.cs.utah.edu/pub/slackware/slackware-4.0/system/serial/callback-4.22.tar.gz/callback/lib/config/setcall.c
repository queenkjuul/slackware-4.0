
#include "config.p"

void setcall()
{
    call = 1;
}
