
#include "ttyline.p"

unsigned   
    active_index,           /* index used when looking for active lines */
    n_lines;
char
    **ttyline;
int 
    active_line;            /* index to active line or -1 for all */
