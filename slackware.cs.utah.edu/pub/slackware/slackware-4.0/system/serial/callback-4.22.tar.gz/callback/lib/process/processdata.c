
#include "process.p"

unsigned
    n_available = 0;
    
AVAILLINE_
    *available = NULL;
