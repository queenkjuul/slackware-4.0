
#include "dest.p"    

void set_phonenr(unsigned dest, char *phone)
{
    destination[dest].mode = phone_mode;
    destination[dest].phonenr = xstrdup(phone);
}
