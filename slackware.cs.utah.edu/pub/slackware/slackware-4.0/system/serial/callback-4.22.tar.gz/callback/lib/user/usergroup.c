
#include "user.p"

unsigned usergroup(unsigned uid, unsigned gindex)
{
    return(user[uid].groups[gindex]);	
}

