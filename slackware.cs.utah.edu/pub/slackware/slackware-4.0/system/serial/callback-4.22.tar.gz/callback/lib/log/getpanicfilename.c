
#include "log.p"

char *get_panicfilename()
{
    return (panic_filename);
}
