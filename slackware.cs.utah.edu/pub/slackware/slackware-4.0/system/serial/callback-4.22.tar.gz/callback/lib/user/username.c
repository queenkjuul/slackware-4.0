
#include "user.p"

char *username(unsigned index)
{
    return (user[index].name);
}
