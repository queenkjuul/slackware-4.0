
#include "dbase.p"

char *modemfile()
{
    return (filename[the_modemfile]);
}
