
#include "ttyline.p"

char *get_ttyline(unsigned index)
{
    return 
    (
        index >= n_lines ?
            NULL
        :
            ttyline[index]
    );
}
