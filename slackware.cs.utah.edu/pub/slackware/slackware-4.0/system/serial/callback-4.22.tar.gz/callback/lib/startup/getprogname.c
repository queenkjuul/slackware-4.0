
#include "startup.p"

char *getprogname()
{
    return (progname);
}
