
#include "cb.h"

void enable()
{
    load(the_enablefile, 1);
    modem_respawn();                /* and have mgetty reread the file */
}
