/***************************************************************************/
/***************************************************************************/
/*                                                                         */
/*   (c) 1995.  The Regents of the University of California.  All rights   */
/*   reserved.                                                             */
/*                                                                         */
/*   This work was produced at the University of California, Lawrence      */
/*   Livermore National Laboratory (UC LLNL) under contract no.            */
/*   W-7405-ENG-48 (Contract 48) between the U.S. Department of Energy     */
/*   (DOE) and The Regents of the University of California (University)    */
/*   for the operation of UC LLNL.  Copyright is reserved to the           */
/*   University for purposes of controlled dissemination,                  */
/*   commercialization through formal licensing, or other disposition      */
/*   under terms of Contract 48; DOE policies, regulations and orders;     */
/*   and U.S. statutes.  The rights of the Federal Government are          */
/*   reserved under Contract 48 subject to the restrictions agreed upon    */
/*   by the DOE and University.                                            */
/*                                                                         */
/*                                                                         */
/*                              DISCLAIMER                                 */
/*                                                                         */
/*   This software was prepared as an account of work sponsored by an      */
/*   agency of the United States Government.  Neither the United States    */
/*   Government nor the University of California nor any of their          */
/*   employees, makes any warranty, express or implied, or assumes any     */
/*   liability or responsibility for the accuracy, completeness, or        */
/*   usefulness of any information, apparatus, product, or process         */
/*   disclosed, or represents that its specific commercial products,       */
/*   process, or service by trade name, trademark, manufacturer, or        */
/*   otherwise, does not necessarily constitute or imply its               */
/*   endorsement, recommendation, or favoring by the United States         */
/*   Government or the University of California. The views and opinions    */
/*   of the authors expressed herein do not necessarily state or reflect   */
/*   those of the United States Government or the University of            */
/*   California, and shall not be used for advertising or product          */
/*   endorsement purposes.                                                 */
/*                                                                         */
/*   Permission to use, copy, modify and distribute this software and its  */
/*   documentation for any non-commercial purpose, without fee, is         */
/*   hereby granted, provided that the above copyright notice and this     */
/*   permission notice appear in all copies of the software and            */
/*   supporting documentation, and that all UC LLNL identification in      */
/*   the user interface remain unchanged.  The title to copyright LLNL     */
/*   XDIR shall at all times remain with The Regents of the University     */
/*   of California and users agree to preserve same. Users seeking the     */
/*   right to make derivative works with LLNL XDIR for commercial          */
/*   purposes may obtain a license from the Lawrence Livermore National    */
/*   Laboratory's Technology Transfer Office, P.O. Box 808, L-795,         */
/*   Livermore, CA 94550.                                                  */
/*                                                                         */
/***************************************************************************/
/***************************************************************************/

/*
 * "CLICK ON NAME FOR"
 */
#define gprefsmsg1_width 91
#define gprefsmsg1_height 7
static unsigned char gprefsmsg1_bits[] = {
   0x4e, 0xc8, 0x89, 0xe0, 0x4c, 0x98, 0x88, 0xa0, 0x87, 0xe7, 0x3c, 0x00,
   0x51, 0x28, 0x4a, 0x10, 0x4d, 0x98, 0x94, 0xb1, 0x80, 0x10, 0x45, 0x00,
   0x41, 0x28, 0x28, 0x10, 0x55, 0xa8, 0x94, 0xaa, 0x80, 0x10, 0x45, 0x00,
   0x41, 0x28, 0x18, 0x10, 0x55, 0xa8, 0x94, 0xa4, 0x83, 0x13, 0x3d, 0x00,
   0x41, 0x28, 0x28, 0x10, 0x65, 0xc8, 0xbe, 0xa0, 0x80, 0x10, 0x15, 0x00,
   0x51, 0x28, 0x4a, 0x10, 0x65, 0xc8, 0xa2, 0xa0, 0x80, 0x10, 0x25, 0x00,
   0xce, 0xcb, 0x89, 0xe0, 0x44, 0x88, 0xa2, 0xa0, 0x87, 0xe0, 0x44, 0x00};


/*
 * "INFORMATION ABOUT"
 */
#define gprefsmsg2_width 95
#define gprefsmsg2_height 7
static unsigned char gprefsmsg2_bits[] = {
   0x4d, 0xcf, 0x79, 0x82, 0x88, 0x2f, 0x67, 0x02, 0xf1, 0x38, 0xd1, 0x07,
   0x4d, 0x21, 0x8a, 0xc6, 0x08, 0xa2, 0x68, 0x02, 0x11, 0x45, 0x11, 0x01,
   0x55, 0x21, 0x8a, 0xaa, 0x14, 0xa2, 0xa8, 0x82, 0x12, 0x45, 0x11, 0x01,
   0x55, 0x27, 0x7a, 0x92, 0x14, 0xa2, 0xa8, 0x82, 0xf2, 0x44, 0x11, 0x01,
   0x65, 0x21, 0x2a, 0x82, 0x3e, 0xa2, 0x28, 0xc3, 0x17, 0x45, 0x11, 0x01,
   0x65, 0x21, 0x4a, 0x82, 0x22, 0xa2, 0x28, 0x43, 0x14, 0x45, 0x11, 0x01,
   0x45, 0xc1, 0x89, 0x82, 0x22, 0x22, 0x27, 0x42, 0xf4, 0x38, 0x0e, 0x01};


/*
 * "A SPECIFIC PREFERENCE"
 */
#define gprefsmsg3_width 104
#define gprefsmsg3_height 7
static unsigned char gprefsmsg3_bits[] = {
   0x04, 0x9c, 0xe7, 0x39, 0xbd, 0x1c, 0x3c, 0xcf, 0x7b, 0xef, 0x79, 0x93,
   0xf3, 0x04, 0xa2, 0x28, 0x44, 0x85, 0x22, 0x44, 0x51, 0x08, 0x21, 0x0a,
   0x53, 0x14, 0x0a, 0x82, 0x28, 0x04, 0x85, 0x02, 0x44, 0x51, 0x08, 0x21,
   0x0a, 0x55, 0x10, 0x0a, 0x9c, 0xe7, 0x04, 0x9d, 0x02, 0x3c, 0xcf, 0x39,
   0xe7, 0x39, 0x55, 0x70, 0x1f, 0xa0, 0x20, 0x04, 0x85, 0x02, 0x04, 0x45,
   0x08, 0xa1, 0x08, 0x59, 0x10, 0x11, 0xa2, 0x20, 0x44, 0x85, 0x22, 0x04,
   0x49, 0x08, 0x21, 0x09, 0x59, 0x14, 0x11, 0x9c, 0xe0, 0x39, 0x85, 0x1c,
   0x04, 0xd1, 0x0b, 0x2f, 0x7a, 0x91, 0xf3};

