
int ncurses_init(char);
int ncurses_run(char *);
