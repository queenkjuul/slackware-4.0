
// Base class for FAL tasks
// It incorporates the messaging base and also the wherewithall
// to parse VMS filenames and calculate CRCs
class fal_task
{
  public:
    fal_task(dap_connection &c, int v, fal_params &p):
	conn(c),
	verbose(v),
	crc(DAPPOLY, DAPINICRC),
	params(p)
	{}
    virtual bool process_message(dap_message *m)=0;
    virtual ~fal_task() {}
    void set_crc(bool);
    void calculate_crc(char *, int);

  protected:  
    dap_connection &conn;
    int             verbose;
    bool            vms_format;
    bool            need_crc;
    vaxcrc          crc;
    fal_params     &params;

    virtual bool send_file_attributes(char *, int, bool);
    
    void return_error();
    void return_error(int);
    void split_filespec(char *, char *, char *);
    void make_vms_filespec(const char *, char *, bool);
    void parse_vms_filespec(char *, char *, char *);
    void make_unix_filespec(char *, char *);
    void convert_vms_wildcards(char *);
    bool is_vms_name(char *);
    bool send_ack_and_unblock();
    
    // The pseudo device name we use
    static const char *sysdisk_name;
};
