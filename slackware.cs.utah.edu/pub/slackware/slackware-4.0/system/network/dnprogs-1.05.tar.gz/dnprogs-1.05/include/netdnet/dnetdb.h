/* DNLIB FUNCTIONS PROTOTYPING */
#ifndef NETDNET_DNLIB_H
#define NETDNET_DNLIB_H

#ifdef __cplusplus
extern "C"
{
#endif

extern  struct  dn_naddr        *dnet_addr(const char *);
extern  struct  dn_naddr        *getnodeadd(void);
extern  struct  nodeent         *getnodebyaddr(const unsigned char *, short , int);
extern  struct  nodeent         *getnodebyname(const char *name);
extern  char                    *dnet_htoa(const struct dn_naddr *);
extern  char                    *dnet_ntoa(const struct dn_naddr *);
extern  char                    *getexecdev(void);
extern  void                    setnodeent(int);

#ifdef __cplusplus
}
#endif

#endif
 
