/******************************************************************************
    (c) 1998 P.J. Caulfield               patrick@pandh.demon.co.uk
                                          pcaulfield@cix.co.uk
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 ******************************************************************************
 */
// connection.cc
#include <assert.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <signal.h>
#include <string.h>
#include <syslog.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <pwd.h>
#include <grp.h>
#include <regex.h>
#include <netdnet/dn.h>
#include <netdnet/dnetdb.h>
#ifdef SHADOW_PWD
#include <shadow.h>
#endif

#include "logging.h"
#include "connection.h"
#include "protocol.h"
#include "dn_endian.h"

#define min(a,b) (a)<(b)?(a):(b)

#define NO_PACKET_PATCH
#ifdef  NO_PACKET_PATCH
inline int DNread(int sock, char *buf, size_t len)
{
    int numbytes;
    ::ioctl(sock, FIONREAD, &numbytes);

    if (!numbytes) numbytes = len;

    return ::read(sock, buf, numbytes);
}
#else
#define DNread ::read
#endif

// Construct an un-connected object 
dap_connection::dap_connection(int verbosity)
{
    blocksize = MAX_READ_SIZE;
    initialise(verbosity);
    create_socket();
}

// Construct an already-connected object (called from waitfor())
dap_connection::dap_connection(int socket, int bs, int verbosity)
{
    initialise(verbosity);
    blocksize   = bs;
    sockfd      = socket;
}

// Generic initialisation process
void dap_connection::initialise(int verbosity)
{
    buf       = new char[MAX_READ_SIZE];
    bufptr    = 0;
    buflen    = 0;

    outbuf    = new char[MAX_READ_SIZE];
    outbufptr = 0;
    last_msg_start = 0;

    verbose     = verbosity;
    have_shadow = -1; // We don't know yet
    connected   = true;
    blocked     = false;

    listening   = false;

    proxy_db    = NULL;
    lasterror   = errstring;
    errstring[0]= '\0';
    closed      = false;

#ifdef NO_BLOCKING
    blocking_allowed = false; // More useful for debugging
#else
    blocking_allowed = true;
#endif

}

// Tidy up
dap_connection::~dap_connection()
{
    // Make sure the output buffer is flushed before we finish up
    if (!closed) close();
}

void dap_connection::close()
{
    if (outbufptr && blocked) set_blocked(false);
    if (sockfd) ::close(sockfd);
    
    delete[] buf;
    delete[] outbuf;
    closed = true;
}

// Create a DECnet socket
void dap_connection::create_socket()
{
    if ((sockfd=socket(AF_DECnet,SOCK_SEQPACKET,DNPROTO_NSP)) == -1) 
    {
        sprintf(errstring, "socket failed: %s", strerror(errno));
	lasterror = errstring;
	exit(1);
    }
}

// Connect to a named object
bool dap_connection::connect(char *node, char *user, char *password, 
			     char *object)
{
    struct sockaddr_dn	 sockaddr;
    
    sockaddr.sdn_family   = AF_DECnet;
    sockaddr.sdn_flags	  = 0x01;
    sockaddr.sdn_objnum	  = 0x00;
    
    if (strlen(object) > 16)
    {
	strcpy(errstring, "connect: object name too long");
	lasterror=errstring;
	return false;
    }
    memcpy(sockaddr.sdn_objname, object, strlen(object));
    sockaddr.sdn_objnamel = strlen(object);

    return do_connect(node, user, password, sockaddr);
}

// Connect to an object number
bool dap_connection::connect(char *node, char *user, char *password, 
			     int object)
{
    struct sockaddr_dn	 sockaddr;
    
    sockaddr.sdn_family   = AF_DECnet;
    sockaddr.sdn_flags	  = 0x00;
    sockaddr.sdn_objnum	  = object;
    sockaddr.sdn_objnamel = 0x00;
    
    return do_connect(node, user, password, sockaddr);
}


// Connect to an object number and a DECnet name specification.
// Returns the remaining filespec
bool dap_connection::connect(char *fspec, int object, char *tailspec)
{
    struct sockaddr_dn	 sockaddr;
    struct accessdata_dn accessdata;
    char   node[MAX_NODE+1];

    if (!parse(fspec, accessdata, node, tailspec)) return false;
    
    sockaddr.sdn_family   = AF_DECnet;
    sockaddr.sdn_flags	  = 0x00;
    sockaddr.sdn_objnum	  = object;
    sockaddr.sdn_objnamel = 0x00;
    
    return do_connect(node, 
		      (char *)accessdata.acc_user, 
		      (char *)accessdata.acc_pass, sockaddr);
}

// Connect to an object name and a DECnet name specification
// Return the trailing filespec
bool dap_connection::connect(char *fspec, char *object, char *tailspec)
{
    struct sockaddr_dn	 sockaddr;
    struct accessdata_dn accessdata;
    char node[MAX_NODE+1];

    if (!parse(fspec, accessdata, node, tailspec)) return false;
    
    
    sockaddr.sdn_family   = AF_DECnet;
    sockaddr.sdn_flags	  = 0x01;
    sockaddr.sdn_objnum	  = 0x00;
    
    if (strlen(object) > 16)
    {
	strcpy(errstring, "connect: object name too long");
	lasterror=errstring;
	return false;
    }
    memcpy(sockaddr.sdn_objname, object, strlen(object));
    sockaddr.sdn_objnamel = strlen(object);
    
    return do_connect(node, 
		      (char *)accessdata.acc_user, 
		      (char *)accessdata.acc_pass, sockaddr);
}



// Private connect method
bool dap_connection::do_connect(const char *node, const char *user, 
				const char *password, 
				struct sockaddr_dn &sockaddr)
{
    struct accessdata_dn accessdata;
    struct sockaddr_dn s = sockaddr;

    binadr = getnodebyname(node);
    if (!binadr)
    {
	strcpy(errstring, "Unknown node name");
	lasterror = errstring;
	return false;
    }

    memcpy(accessdata.acc_user, user, strlen(user));
    memcpy(accessdata.acc_pass, password, strlen(password));
    memcpy(s.sdn_add.a_addr, binadr->n_addr, 6);

    // Try very hard to get the local username for proxy access
    char *local_user = getlogin();
    if (!local_user || local_user == (char *)0xffffffff)
	local_user = getenv("LOGNAME");

    if (!local_user) local_user = getenv("USER");
    if (local_user)
    {
	strcpy((char *)accessdata.acc_acc, local_user);
	accessdata.acc_accl = strlen((char *)accessdata.acc_acc);
	makeupper((char *)accessdata.acc_acc);
    }
    else
        accessdata.acc_acc[0] = '\0';
    

    accessdata.acc_userl = strlen(user);
    accessdata.acc_passl = strlen(password);
    
    if (setsockopt(sockfd, DNPROTO_NSP, SO_CONACCESS, &accessdata,
		   sizeof(accessdata)) < 0) 
    {
        sprintf(errstring, "setsockopt failed: %s", strerror(errno));
	lasterror = errstring;
	return false;
    }
    
    if (::connect(sockfd, (struct sockaddr *)&s,
		  sizeof(sockaddr)) < 0) 
    {
        sprintf(errstring, "connect failed: %s", strerror(errno));
	lasterror = errstring;
	return false;
    }

// Make sure we get a blocking socket to start with
    int flags = fcntl(sockfd, F_GETFL, 0);
    fcntl(sockfd, F_SETFL, flags & ~O_NONBLOCK);

    bufptr = buflen = 0;
    connected = true;

    return true;
}

// Read a packet
int dap_connection::read(bool block)
{
    int flags=0;
    int saved_errno;

    if (!block)
    {
	flags = fcntl(sockfd, F_GETFL, 0);
	fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
    }

    buflen=DNread(sockfd, buf, blocksize);
    saved_errno = errno;

    // Reset flags
    if (!block)
    {
	fcntl(sockfd, F_SETFL, flags);
    }

    // No data and we were told not to block
    if (buflen < 0 && saved_errno == EAGAIN) return false; // No data

    if (buflen < 0) 
    {
	sprintf(errstring, "DAP read error: %s", strerror(saved_errno));
	lasterror = errstring;
	return false;
    }
    if (buflen == 0) 
    {
	lasterror = "Remote end closed connection";
	return false;
    }

    if (verbose > 2) DAPLOG((LOG_DEBUG, "read: read %d bytes\n", buflen));
    bufptr=0;
    end_of_msg = buflen; // Until told differently
    return true;
}

int dap_connection::read_if_necessary(bool block)
{
    if (bufptr >= buflen)
	return read(block);
    else
	return 1;
}

// Send a completed packet to the remote machine
int dap_connection::write()
{
    int er;

    if (outbuf[last_msg_start+1] & 0x02)
    { 
        // Add in length
	if (outbuf[last_msg_start+1] & 0x04) // LEN256 header
        {
	    *(unsigned short *)&outbuf[last_msg_start+2] = dn_htons(outbufptr - last_msg_start - 4);
	}
	else
        {
	    outbuf[last_msg_start+2] = outbufptr - last_msg_start - 3;
        }
    }

// If the caller wants blocked output and there's (probably) enough room
// then return now.
    
    if (blocked && outbufptr < blocksize-100) 
    {
	last_msg_start = outbufptr;
	return true;
    }
    
    er=::write(sockfd,outbuf,outbufptr);
    if (er < 0) 
    {
	sprintf(errstring, "DAP write error: %s", strerror(errno));
	lasterror = errstring;
	return false;
    }
    if (verbose >2) DAPLOG((LOG_DEBUG, "wrote %d bytes\n", er));

    outbufptr = 0;
    last_msg_start = 0;

    return true;
}

// Returns a pointer to a specific number of bytes in the buffer and
// increments the buffer pointer.
// Not the most C++ way of doing it but quick!
char *dap_connection::getbytes(int num)
{
    char *ptr;

    if (bufptr+num > buflen)
    {
	DAPLOG((0, "ATTEMPT TO READ PAST BUFFER. bufptr=%d, num=%d,buflen=%d\n",
		bufptr, num, buflen));
	*(int *)0 = 0xdeadbeef;
	return NULL;
    }

    ptr = &buf[bufptr];
    
    bufptr += num;

    return ptr;
}

// Returns true if there are 'num' bytes left in the message
bool dap_connection::have_bytes(int num)
{
    if (bufptr+num > end_of_msg)
	return false;
    else
	return true;
}

// Copy some bytes to the output buffer
int dap_connection::putbytes(void *bytes, int num)
{
    // If the next message won't fit in the block then send it all now
    if (blocked && outbufptr+num > blocksize)
    {
	if (!set_blocked(false)) return false;
	set_blocked(true);
    }

    memcpy(&outbuf[outbufptr], bytes, num);
    outbufptr += num;

    return true;
}

int  dap_connection::check_length(int needed)
{
    if (verbose > 3) DAPLOG((LOG_DEBUG, "check_length(): %d bytes needed\n", needed));
    if (!needed) return true;


    if (buflen < bufptr+needed)
    {
	// The required buffer size 
	int reqd_length = needed;
	int left = buflen - bufptr; /* what's left unread */

	/* Move what we have to the start of the buffer */
	memmove(buf, buf+bufptr, left);

	buflen = left;
	while (buflen < reqd_length)
        {
	  if (verbose > 2) 
	    DAPLOG((LOG_DEBUG, "check_length(): reading up to %d bytes to fill record. bufptr=%d, buflen=%d\n",
		    reqd_length - buflen, bufptr, buflen));

	  /* read enough to satisfy what's needed */
	   int readlen = DNread(sockfd, buf+buflen, reqd_length-buflen);
	   if (readlen < 0) 
	   {
	       sprintf(errstring, "read failed: %s", strerror(errno));
	       lasterror = errstring;
	       return false;
	   }
	   if (verbose > 2) DAPLOG((LOG_DEBUG, "check_length(): read %d bytes\n", readlen));
	   buflen += readlen;
        }
	bufptr=0;
    }

    // Use this to mark the end of the current DAP message.
    // bufptr will be 0 if we read a new block and non-zero otherwise.
    end_of_msg = bufptr + needed;

    return true;
}

// Set the maximum number of bytes to be read per block.
// usually called after a CONFIG negotiation.
void dap_connection::set_blocksize(int bs)
{
    blocksize = bs;
}

int dap_connection::get_blocksize()
{
    return blocksize;
}

// 
// Wait for an incoming connection
// Returns a constructed new dap_connection object
// Clients may call either this or connect() BUT NOT BOTH
dap_connection *dap_connection::waitfor()
{
    int                  status;
    unsigned int         len;
    struct sockaddr_dn	 sockaddr;

    // Set up the listing context
    if (!listening)
    {
	status = listen(sockfd, 5);
	if (status)
	{
	    sprintf(errstring, "listen failed: %s", strerror(errno));
	    lasterror = errstring;
	    return NULL;
	}
	listening = true;
    }

    // Wait for a connection
    status = accept(sockfd, (struct sockaddr *)&sockaddr, &len);
    if (status < 0 && errno != EINTR)
    {
        sprintf(errstring, "accept failed: %s", strerror(errno));
	lasterror = errstring;
	return NULL;
    }

    // We were interrupted, return a NULL pointer
    if (status < 0 && errno == EINTR) return NULL;

    // Return a new connection object
    return new dap_connection(status, blocksize, verbose);
}

// No prizes for guessing what this does.
// Returns are as for the syscall fork().
// Actually, it also sets the current directory too.
int dap_connection::fork_and_setuid()
{
    struct  accessdata_dn accessdata;
    char   *cryptpass;
    char    username[50];
    char    password[50];
    char    remote_user[50];
    char    nodename[50];
    struct  sockaddr_dn  sockaddr;
    unsigned int len = sizeof(accessdata);
    int      er;
    unsigned int namlen = sizeof(sockaddr);
    pid_t   newpid;
    uid_t   newuid;
    gid_t   newgid;

// Get the remote user spec.
    if (getsockopt(sockfd, DNPROTO_NSP, SO_CONACCESS, &accessdata,
		   &len) < 0) 
    {
        sprintf(errstring, "getsockopt failed: %s", strerror(errno));
	lasterror = errstring;
	return -1;
    }
    memcpy(username, accessdata.acc_user, accessdata.acc_userl);
    username[accessdata.acc_userl] = '\0';

    memcpy(password, accessdata.acc_pass, accessdata.acc_passl);
    password[accessdata.acc_passl] = '\0';

    memcpy(remote_user, accessdata.acc_acc, accessdata.acc_accl);
    remote_user[accessdata.acc_accl] = '\0';

    // Make the user names all lower case. I'm sorry if you have mixed
    // case usernames on your system, you'll just have to use the proxy
    // database; VMS usernames are case blind.
    makelower(remote_user);
    makelower(username);

    // Get the name (or address if we cant find the name) of the remote system.
    // (a) for logging and (b) for checking in the proxy database.
    er = getpeername(sockfd, (struct sockaddr *)&sockaddr, &namlen);
    if (!er)
    {
        strcpy(nodename, dnet_htoa(&sockaddr.sdn_add));
    }
    else
    {
	sprintf(nodename, "%d.%d", 
		(sockaddr.sdn_add.a_addr[1] >> 2),
		(((sockaddr.sdn_add.a_addr[1] & 0x03) << 8) |
		 sockaddr.sdn_add.a_addr[0]));
    }

    if (verbose) 
    {
	if (username[0])
	{
	    DAPLOG((LOG_DEBUG, "Connection from: %s\"%s password\"::%s\n", 
		    nodename, username, remote_user));
	}
	else
	{
	    DAPLOG((LOG_DEBUG, "Connection from: %s::%s\n", 
		    nodename, remote_user));
	}
    }

// Check proxy database if no local user was passed
// this overwrites 'username' with the proxied user
    bool use_proxy;
    if (username[0] == '\0')
    {
	use_proxy = check_proxy_database(nodename, remote_user, username);
    }
    else
    {
	use_proxy = false;
    }

    struct passwd *pw = getpwnam(username);
    if (!pw)
    {
	strcpy(errstring, "Unknown username - access denied");
	lasterror=errstring;
	return -1;
    }
    newuid = pw->pw_uid;
    newgid = pw->pw_gid;

// If we are using a proxy then we don't need to verify the password
    if (!use_proxy)
    {
#ifdef SHADOW_PWD
	// See if we REALLY have shadow passwords
	if (have_shadow == -1)
	{
	    struct stat shadstat;
	    if (stat("/etc/shadow", &shadstat) == 0)
		have_shadow = 1;
	    else
		have_shadow = 0;
	}

	if (have_shadow)
	{
	    struct spwd *spw = getspnam(username);
	    if (!spw)
	    {
		sprintf(errstring, "Error reading /etc/shadow entry for %s: %s", 
			username, strerror(errno));
		lasterror=errstring;
		DAPLOG((LOG_DEBUG, "UID is %d\n", getuid()));
		return -1;
	    }
	    endspent(); // prevent caching of passwords
 
           // Check the shadow password
	    cryptpass = crypt(password, spw->sp_pwdp);
	    if (strcmp(cryptpass, spw->sp_pwdp))
	    {
		sprintf(errstring, "Incorrect password for %s", username);
		lasterror=errstring;
		return -1;
	    }
	}
	else
#endif
	{
           // Check the (non-shadow) password
 	    cryptpass = crypt(password, pw->pw_passwd);
	    if (strcmp(cryptpass, pw->pw_passwd))
	    {
		sprintf(errstring, "Incorrect password for %s", username);
		lasterror=errstring;
		return -1;
	    }
	}
    }

// NO_FORK is just for testing. It creates a single-shot server that is 
// easier to debug.
#ifdef NO_FORK
    newpid = 0;
#else
    newpid = fork();
#endif

    switch (newpid)
    {
    case -1:
	sprintf(errstring, "fork failed: %s", strerror(errno));
	lasterror = errstring;
	break;

    case 0: // Child
#ifndef NO_FORK
        if (initgroups(username, newgid) < 0)
	{
	    error_return("init groups failed");
	    return -1;
	}
	if (setgid(newgid) < 0)
	{
	    error_return("setgid failed");
	    return -1;
	}
	if (setuid(newuid) < 0)
	{
	    error_return("setuid failed");
	    return -1;
	}
#endif
	chdir(pw->pw_dir);
	break;

    default: // Parent
	break;
    }
    return newpid;
}

// Bind to an object number
bool dap_connection::bind(int object)
{
    sockaddr_dn bind_sockaddr;

    memset(&bind_sockaddr, 0, sizeof(bind_sockaddr));
    bind_sockaddr.sdn_family    = AF_DECnet;
    bind_sockaddr.sdn_flags	= 0x00;
    bind_sockaddr.sdn_objnum	= object;
    bind_sockaddr.sdn_objnamel	= 0x00;

    int status = ::bind(sockfd,  (struct sockaddr *)&bind_sockaddr, 
			sizeof(bind_sockaddr));
    if (status)
    {
	sprintf(errstring, "bind failed: %s", strerror(errno));
	lasterror=errstring;
	return false;
    }
    return true;
}

// Bind to a named object
bool dap_connection::bind(char *object)
{
    sockaddr_dn bind_sockaddr;

    memset(&bind_sockaddr, 0, sizeof(bind_sockaddr));
    bind_sockaddr.sdn_family = AF_DECnet;
    bind_sockaddr.sdn_flags	= 0x01;
    bind_sockaddr.sdn_objnum	= 0x00;

    if (strlen(object) > 16)
    {
	strcpy(errstring, "bind: object name too long");
	lasterror=errstring;
	return false;
    }
    memcpy(bind_sockaddr.sdn_objname, object, strlen(object));
    bind_sockaddr.sdn_objnamel	= strlen(object);

    int status = ::bind(sockfd,  (struct sockaddr *)&bind_sockaddr, 
			sizeof(bind_sockaddr));
    if (status)
    {
	sprintf(errstring, "bind failed: %s", strerror(errno));
	lasterror=errstring;
	return false;
    }
    return true;
}

char *dap_connection::get_error()
{
    return lasterror;
}

// Returns remaining message length
int dap_connection::get_length()
{
    return buflen-bufptr;
}


// Enable/disable blocked requests.
// If blocking is being switched off we may also flush the buffer if there
// is something to send.
// Clients should ALWAYS check the return from this function.
int dap_connection::set_blocked(bool onoff)
{
    if (blocked == onoff) return true; // Nothing to do

    if (!blocking_allowed) return true;  // Remote end doesn't support it

    // Enabled blocked output
    if (!blocked && onoff)
    {
	if (verbose > 2) DAPLOG((LOG_INFO, "Blocked output is ON\n"));
	blocked = true;
	return true;
    }

    // Blocking is being switched off
    blocked = false;
    if (outbufptr == 0) return true; // Nothing to send;

    if (verbose > 2) 
	DAPLOG((LOG_INFO, "Blocked output is OFF, sending %d bytes\n", outbufptr));

    // Send what we have saved up.
    int er=::write(sockfd,outbuf,outbufptr);
    if (er < 0) 
    {
	sprintf(errstring, "DAP write error: %s", strerror(errno));
	lasterror = errstring;
	return false;
    }
    if (verbose > 2) DAPLOG((LOG_INFO, "wrote %d bytes\n", er));

    outbufptr = 0;
    last_msg_start = 0;
    return true;
}

// Check the proxy database for authentication
bool dap_connection::check_proxy_database(char *nodename, 
					  char *remoteuser, 
					  char *localuser)
{
// Re-read the proxy database 'cos it has changed.
    if (!proxy_db)
    {
	free_proxy();
	load_proxy_database();
    }

    // Look for the user and nodename in the list
    struct proxy *p = proxy_db;
    bool found = false;

    while (p && !found)
    {
	if (regexec(&p->node_r, nodename, 0, NULL, 0) == 0 &&
	    regexec(&p->remuser_r, remoteuser, 0, NULL, 0) == 0)
	{
	    found = true;
	    if (p->localuser[0] == '*')
	    {
		strcpy(localuser, remoteuser);
	    }
	    else
	    {
		strcpy(localuser, p->localuser);
	    }
	    if (verbose >1 ) DAPLOG((LOG_INFO, "Using proxy name %s\n", localuser));
	}
	p = p->next;
    }
    return found;
}

// Parse a filespec into its component parts
// Input is a transparent DECnet filespec in 'fname'
// Output is a completed accessdata structure
// and filespec
bool dap_connection::parse(const char *fname, 
			   struct accessdata_dn &accessdata,
			   char *node, char *filespec)
{
    enum  {NODE, USER, PASSWORD, ACCOUNT, NAME, FINISHED} state;
    int   n0=0;
    int   n1=0;

    memset(&accessdata, 0, sizeof(struct accessdata_dn));
    
    state = NODE; /* Node is mandatory */

    while (state != FINISHED)
    {
	switch (state)
	{
	case NODE:
	    if (fname[n0] != ':' && fname[n0] != '\"' && fname[n0] != '\'')
	    {
		if (n1 >= MAX_NODE || 
		    fname[n0] == ' ' || fname[n0] == '\n')
		{
		    lasterror = "File name parse error";
		    return false;
		}
		node[n1++] = fname[n0++];
	    }
	    else
	    {
		node[n1] = '\0';
		n1 = 0;
		if (fname[n0] == '\"')
		{
		    n0++;
		    state = USER;
		}
		else
		{
		    n0 += 2;
		    state = NAME;
		}
	    }
	    break;

	case USER:
	    if (fname[n0] != ' ' && fname[n0] != '\"' && fname[n0] != '\'')
	    {
		if (n1 >= MAX_USER)
		{
		    lasterror = "File name parse error";
		    return false;
		}
		accessdata.acc_user[n1++] = fname[n0++];
	    }
	    else
	    {
		accessdata.acc_user[n1] = '\0';
		n1 = 0;
		if (fname[n0] == ' ')
		{
		    state = PASSWORD;
		    n0++;
		}
		else /* Must be a quote */
		{
		    state = NAME;
		    /* Check for :: */
		    n0 += 3;
		}
	    }
	    break;

	case PASSWORD:
	    if (fname[n0] != ' ' && fname[n0] != '\"' && fname[n0] != '\'')
	    {
		if (n1 >= MAX_PASSWORD)
		{
		    lasterror = "File name parse error";
		    return false;
		}
		accessdata.acc_pass[n1++] = fname[n0++];
	    }
	    else
	    {
		accessdata.acc_pass[n1] = '\0';
		n1 = 0;
		if (fname[n0] == ' ')
		{
		    n0++;
		    state = ACCOUNT;
		}
		else /* Must be a quote */
		{
		    state = NAME;
		    /* Check for :: */
		    n0 += 3;
		}
	    }
	    break;

	case ACCOUNT:
	    if (fname[n0] != '\'' && fname[n0] != '\"')
	    {
		if (n1 >= MAX_ACCOUNT)
		{
		    lasterror = "File name parse error";
		    return false;
		}
		accessdata.acc_acc[n1++] = fname[n0++];
	    }
	    else
	    {
		accessdata.acc_acc[n1] = '\0';;
		state = NAME;
		n1 = 0;
		/* Check for :: */
		n0 += 3;
	    }
	    break;

	case NAME:
	    strcpy(filespec, fname+n0);
	    state = FINISHED;
	    break;

	case FINISHED: // To keep the compiler happy
	    break;
	} /* switch */
    }

    /* tail end validation */
    binadr = getnodebyname(node);
    if (!binadr)
    {
	lasterror = "Unknown or invalid node name ";
	return false;
    }

    /* Complete the accessdata structure */
    accessdata.acc_userl = strlen((char *)accessdata.acc_user);
    accessdata.acc_passl = strlen((char *)accessdata.acc_pass);
    accessdata.acc_accl  = strlen((char *)accessdata.acc_acc);
    return true;
}


// Read the proxy database into memory
void dap_connection::load_proxy_database()
{
    FILE         *f;
    char          buf[4096];
    int           line;
    struct proxy *new_proxy;
    struct proxy *last_proxy = NULL;

    f = fopen(proxy_filename, "r");
    if (!f)
    {
	DAPLOG((LOG_ERR, "Can't open proxy database: %s\n", strerror(errno)));
	return;
    }	

    line = 0;

    while (!feof(f))
    {
	line++;
	if (!fgets(buf, sizeof(buf), f)) break;

	// Skip whitespace
	char *bufp = buf;
	while (*bufp == ' ' || *bufp == '\t') bufp++;

	if (*bufp == '#') continue; // Comment

	// Remove trailing LF
	if (buf[strlen(buf)-1] == '\n') buf[strlen(buf)-1] = '\0';
	
	char *colons = strstr(bufp, "::");
	if (colons)
	{
	    // Look for the local user after a space or tab
	    char *space = strchr(colons, ' ');
	    if (!space) space = strchr(colons, '\t');
	    if (!space)
	    {
		DAPLOG((LOG_ERR, "Error on line %d of proxy file: no space\n", line));
		continue;
	    }
	    *colons = '\0';
	    if (strlen(bufp) > 20)
	    {
		DAPLOG((LOG_ERR, "Error on line %d of proxy file: nodename too long\n", line));
		continue;
	    }
	    *space='\0';
	    if (strlen(colons+2) > 65)
	    {
		DAPLOG((LOG_ERR, "Error on line %d of proxy file: remote username too long\n", line));
		continue;
	    }
	    if (strlen(space+1) > 65)
	    {
		DAPLOG((LOG_ERR, "Error on line %d of proxy file: local username too long\n", line));
		continue;
	    }

	    // Skip whitespace
	    char *local = space+1;
	    while (*local == ' ' || *local == '\t') local++;

	    // Terminate the localuser at another whitespace char or a hash
	    // to allow comments
	    char *end;
	    if ( ((end=strchr(local, ' '))) )  *end = '\0';
	    if ( ((end=strchr(local, '\t'))) ) *end = '\0';
	    if ( ((end=strchr(local, '#'))) )  *end = '\0';

	    if (strlen(local) == 0)
	    {
		DAPLOG((LOG_ERR, "Error on line %d of proxy file: no local username\n", line));
		continue;
	    }

	    new_proxy = new proxy;
	    memset(new_proxy, 0, sizeof(new_proxy)); // Needed to clear regexps

	    strcpy(new_proxy->node, bufp);
	    strcpy(new_proxy->remuser, colons+2);
	    strcpy(new_proxy->localuser, local);

	    // Compile the regular expressions
	    if (regcomp(&new_proxy->node_r, new_proxy->node, REG_ICASE))
	    {
		DAPLOG((LOG_ERR, "Error on line %d of proxy file: node regexp is invalid\n", line));
		delete new_proxy;
		continue;
	    }
	    if (regcomp(&new_proxy->remuser_r, new_proxy->remuser, REG_ICASE))
	    {
		DAPLOG((LOG_ERR, "Error on line %d of proxy file: remote user regexp is invalid\n", line));
		delete new_proxy;
		continue;
	    }

	    // Add to the list
	    if (last_proxy)
	    {
		last_proxy->next = new_proxy;
	    }
	    else
	    {
		proxy_db = new_proxy;
	    }
	    last_proxy = new_proxy;
	}
	else
	{
	    DAPLOG((LOG_ERR, "Error on line %d of proxy file: no ::\n", line));
	    continue;
	}
    }
}

// When talking to small systems that don't support blocking we can disable
// it altogether.
void dap_connection::allow_blocking(bool onoff)
{
    blocking_allowed = onoff;
}

// Send a CRC
int dap_connection::send_crc(unsigned short crc)
{
    char crcbuf[2] = {crc&0xff, crc>>8};

    return putbytes(crcbuf,2);
}

// Free up the proxy database structure so we can re-read it later.
// called from SIGHUP.
void dap_connection::free_proxy()
{
    struct proxy *p = proxy_db;
    struct proxy *next_p;

    while (p)
    {
	regfree(&p->node_r);
	regfree(&p->remuser_r);
	next_p=p->next;
	free(p);
	p=next_p;
    }
    proxy_db = NULL;
}

// A couple of general utility methods:
void dap_connection::makelower(char *s)
{
    for (unsigned int i=0; i<strlen(s); i++) s[i] = tolower(s[i]);
}

void dap_connection::makeupper(char *s)
{
    for (unsigned int i=0; i<strlen(s); i++) s[i] = toupper(s[i]);
}

// Always returns false. Sets the error string to strerror(errno)
bool dap_connection::error_return(char *txt)
{
    sprintf(errstring, "%s: %s", txt, strerror(errno));
    lasterror = errstring;
    return false;
}

// Exchange CONFIG messages with the other side.
bool dap_connection::exchange_config()
{
// Send our config message
    dap_config_message *newcm = new dap_config_message(MAX_READ_SIZE);
    if (!newcm->write(*this)) return false;
    delete newcm;
  
// Read the other end's config message
    dap_message *m=dap_message::read_message(*this, true);
    if (!m) // Comms error
    {
	DAPLOG((LOG_ERR, "%s\n", get_error()));
	return false;
    }

// Check it's OK and set the connection buffer size
    dap_config_message *cm = (dap_config_message *)m;
    if (m->get_type() == dap_message::CONFIG)
    {
	cm = (dap_config_message *)m;

	if (verbose > 1)
	    DAPLOG((LOG_DEBUG, "Remote buffer size is %d\n", cm->get_bufsize()));

	set_blocksize(min(MAX_READ_SIZE, cm->get_bufsize()));
	if (verbose > 1)
	    DAPLOG((LOG_DEBUG, "Using block size %d\n", get_blocksize()));

    }
    else
    {
	return false;
    }
    delete m;

    return true;
}



const char *dap_connection::proxy_filename = "/etc/decnet.proxy";

