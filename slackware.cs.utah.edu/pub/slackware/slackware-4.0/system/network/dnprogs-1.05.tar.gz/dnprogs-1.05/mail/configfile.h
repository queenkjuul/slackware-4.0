/* configfile.h */
void read_configfile(void);

extern char config_hostname[1024];
extern char config_vmsmailuser[1024];
extern char config_smtphost[1024];
