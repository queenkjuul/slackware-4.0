/* (c) 1998 Eduardo Marcelo Serrat

   Modifications (c) 1998 by Patrick Caulfield to set the Ethernet address
  */

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netdnet/dn.h>
#include <netdnet/dnetdb.h>
#include <netinet/in.h>
#include <net/if.h>


static int set_hwaddr(void);

struct 
{
    char	devname[5]; 
    char	exec_addr[6]; 
} if_arg;


int main(int argc, char *argv[])
{
  	int sockfd;
  	int er;
	unsigned char dn_hiord_addr[6] = {0xAA,0x00,0x04,0x00,0x00,0x00};

	char	*exec_dev;
	static  struct	dn_naddr	*binadr;

	if ((exec_dev=getexecdev()) == NULL)
	{
		printf("getexecdev: Invalid line in /etc/decnet.conf\n");
		exit (-1);
	}

	memcpy(&if_arg.devname,exec_dev,5);
	
	binadr=getnodeadd();
	if (binadr == NULL)
	{
		printf("dnet_addr: Invalid executor address in decnet.conf\n");
		exit (-1);
	}
	memcpy(&if_arg.exec_addr,dn_hiord_addr,6);
	if_arg.exec_addr[4]=binadr->a_addr[0];
	if_arg.exec_addr[5]=binadr->a_addr[1];

  	if ((sockfd=socket(AF_DECnet,SOCK_SEQPACKET,DNPROTO_NSP)) == -1) {
    		perror("socket");
    		exit(-1);
  	}

	if ((er=ioctl(sockfd, SIOCSIFADDR, (unsigned long)&if_arg)) < 0) {
		perror("ioctl");
		exit(-1);
	}		
	
  	if ( close(sockfd) < 0)
    		perror("close");

	if (argc > 1 && !strcmp(argv[1], "-hw"))
	{
	    return set_hwaddr();
	}
	return 0;
}


int set_hwaddr(void)
{
    struct ifreq ifr;
    int skfd;
    
    skfd = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    if (skfd == -1) return -1;
    
    strcpy(ifr.ifr_name, if_arg.devname);
    ifr.ifr_hwaddr.sa_family  = AF_UNIX;
    memcpy(ifr.ifr_hwaddr.sa_data, if_arg.exec_addr, 6);

    if (ioctl(skfd, SIOCSIFHWADDR, &ifr) < 0)
    {
	perror("error setting hw address");
	return -1;
    }

    close(skfd);
    return 0;
}
