/******************************************************************************
    (c) 1998 Eduardo.M Serrat             emserrat@hotmail.com

    Some Modifications 1999 By Patrick Caulfield.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 ******************************************************************************
*/
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>
#include <netdnet/dn.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/types.h>

struct	sockaddr_dn		sockaddr;
char				nodename[20],ibuf[4096];
int				sockfd,insock,len,readnum;
struct	optdata_dn		optdata;
/*-----------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    pid_t	pid;

    if (getuid() != 0)
    {
	fprintf(stderr, "Must be root to run dnmirror daemon");
	exit(2);
    }
#ifndef NO_FORK
    switch(pid=fork())
    {
    case -1 :
	perror("dnmirror cannot fork");
	exit(2);
    case  0 :
	setsid();
	close(0); close(1); close(2);
	chdir("/");
	break;
    default :
	exit(0);
    }
#endif
    
    if ((sockfd=socket(AF_DECnet,SOCK_SEQPACKET,DNPROTO_NSP)) == -1) 
    {
	syslog(LOG_WARNING, "dnmirror, socket failed: %m\n");
	exit(-1);
    }
    optdata.opt_sts=0x00;
    optdata.opt_optl=0x02;		/* two bytes for optdata */
    optdata.opt_data[0]=0x00;
    optdata.opt_data[1]=0x10;	/* We can loopback up to 4096 bytes */

    if ((setsockopt(sockfd,DNPROTO_NSP,SO_CONDATA,&optdata,sizeof(optdata))) < 0) 
    {
	syslog(LOG_WARNING, "dnmirror, setsockopt failed: %m\n");
	exit(-1);
    }

    sockaddr.sdn_family = AF_DECnet;
    sockaddr.sdn_flags	= 0x00;
    sockaddr.sdn_objnum	= 0x19;			/* MIRROR */
    sockaddr.sdn_objnamel	= 0x00;

    if (bind(sockfd, (struct sockaddr *)&sockaddr, 
	     sizeof(sockaddr)) < 0) 
    {
	syslog(LOG_WARNING, "dnmirror, bind failed: %m\n");
	exit(-1);
    }

    if (listen(sockfd,1) < 0)
    {
	syslog(LOG_WARNING, "dnmirror, listen failed: %m\n");
	exit(-1);
    }
    for (;;)
    {
	if ( (insock=accept(sockfd, (struct sockaddr *)&sockaddr, &len)) < 0)
	{
	    syslog(LOG_WARNING, "dnmirror, accept failed: %m\n");
	    exit(-1);
	}
	
	while ( (readnum=read(insock,ibuf,sizeof(ibuf))) > 0)
	{
	    ibuf[0]=0x01;
	    if (write(insock,ibuf,readnum) < 0)
	    {
		syslog(LOG_WARNING, "dnmirror, write failed: %m\n");
		close(insock);
		break;
	    }
	}
	close(insock);
    }
    close(sockfd);
    return 0;
}
/*-------------------------------------------------------------------------*/
