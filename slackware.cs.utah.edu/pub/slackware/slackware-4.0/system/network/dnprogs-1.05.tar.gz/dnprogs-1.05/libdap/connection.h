#ifndef LIBDAP_CONNECTION_H
#define LIBDAP_CONNECTION_H

// connection.h
//
// Encapsulates a DAP connection. Incoming and Outgoing
//


// Structure of an item in the DECnet proxy database
// These lengths are generous to allow for regular expressions
struct proxy
{
    char node[20];
    char remuser[65];
    char localuser[65];

    regex_t node_r;
    regex_t remuser_r;

    struct proxy *next;
};


class dap_connection
{
 public:
    dap_connection(int verbosity);
    dap_connection(int socket, int bs, int verbosity);
    ~dap_connection();

    bool connect(char *node,  char *user, char *password, char *object);
    bool connect(char *node,  char *user, char *password, int   object);
    bool connect(char *fspec, int   object, char *tailspec);
    bool connect(char *fspec, char *object, char *tailspec);

    bool bind(char *object);
    bool bind(int object);
    
    dap_connection *waitfor();
    

    char *getbytes(int num);
    int   putbytes(void *bytes, int num);
    int   check_length(int);
    int   get_length();
    int   read(bool);
    int   read_if_necessary(bool);
    int   write();
    int   send_crc(unsigned short);
    char *get_error();
    void  set_blocksize(int);
    int   get_blocksize();
    int   fork_and_setuid();
    bool  have_bytes(int);
    int   set_blocked(bool onoff);
    void  allow_blocking(bool onoff);
    int   verbosity() {return verbose;};
    bool  parse(const char *fname,
		struct accessdata_dn &accessdata, char *node, char *filespec);
    void free_proxy();
    void close();
    bool exchange_config();
    
// Static utility functions

    static void makelower(char *s);
    static void makeupper(char *s);
    
 private:
    char  *buf;
    char  *outbuf;
    int    sockfd;
    int    bufptr;
    int    outbufptr;
    int    buflen;
    int    blocksize;
    int    have_shadow;
    int    verbose;
    bool   connected;
    bool   listening;
    bool   blocked;
    bool   blocking_allowed;
    bool   closed;
    int    last_msg_start;
    int    end_of_msg;
    struct nodeent *binadr;
    
    char *lasterror;
    char  errstring[256];

    static const unsigned int MAX_READ_SIZE = 65535;
    static const char *proxy_filename;

    void create_socket();
    void initialise(int);
    bool check_proxy_database(char *, char *, char *);
    bool do_connect(const char *node, const char *user,
		    const char *password, sockaddr_dn &sockaddr);

    void load_proxy_database();
    bool error_return(char *);
    
    struct proxy *proxy_db;

/* DECnet phase IV limits */
    static const int MAX_NODE     = 6;
    static const int MAX_USER     = 12;
    static const int MAX_PASSWORD = 12;
    static const int MAX_ACCOUNT  = 12;

 public:
    // DECnet object numbers
    static const unsigned int FAL_OBJECT = 0x11;

};
#endif
