/******************************************************************************
    (c) 1998 Eduardo.M Serrat             emserrat@hotmail.com
    Username/Password additions by David G North 1999
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 ******************************************************************************
*/
/* dnping.c */

   
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <netdnet/dn.h>
#include <netdnet/dnetdb.h>
#include <sys/socket.h>

struct	sockaddr_dn		sockaddr;
struct	accessdata_dn		accessdata;
static  struct	nodeent		*np;
char				nodename[20],ibuf[40],obuf[40];
short				cnt,snd,rcv;
static int			sockfd,i;
/*-------------------------------------------------------------------------*/
static void makeupper(char *s)
{
    int i,j;
    for (i=0,j=strlen(s); i<j; i++) s[i] = toupper(s[i]);
}

static void init_accdata( char *user, char *password)
{
    char *local_user = getlogin();

    memcpy(accessdata.acc_user, user, strlen(user));
    memcpy(accessdata.acc_pass, password, strlen(password));

    /* Try very hard to get the local username for proxy access */
    if (!local_user || local_user == (char *)0xffffffff)
        local_user = getenv("LOGNAME");

    if (!local_user) local_user = getenv("USER");
    if (local_user)
    {
        strcpy((char *)accessdata.acc_acc, local_user);
        accessdata.acc_accl = strlen((char *)accessdata.acc_acc);
        makeupper((char *)accessdata.acc_acc);
    }
    else
        accessdata.acc_acc[0] = '\0';

    accessdata.acc_userl = strlen(user);
    accessdata.acc_passl = strlen(password);
}

/*-------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{

	if ((argc != 3) && (argc!=5)) {
		printf("Usage: dnping nodename [user pass] count\n");
		exit(0);
	}
	sprintf(nodename,"%s",argv[1]);
	cnt=atoi(argv[argc-1]);
	if ( (np=getnodebyname(nodename)) == NULL)
	{
	   printf("No entry in /etc/decnet.conf for %s\n",nodename);
	   exit(0);
	}
  	if ((sockfd=socket(AF_DECnet,SOCK_SEQPACKET,DNPROTO_NSP)) == -1) 
	{
    		perror("socket");
    		exit(-1);
  	}

	if (argc==5) {
	   init_accdata(argv[2], argv[3]);
	   if (setsockopt(sockfd, DNPROTO_NSP, SO_CONACCESS, &accessdata,
                   sizeof(accessdata)) < 0)
	   {
		perror("setsockopt");
		exit(-1);
	   }
	}

	sockaddr.sdn_family = AF_DECnet;
	sockaddr.sdn_flags	= 0x00;
	sockaddr.sdn_objnum	= 0x19;			/* MIRROR */
	sockaddr.sdn_objnamel	= 0x00;
	memcpy(sockaddr.sdn_add.a_addr, np->n_addr,2);

	if (connect(sockfd, (struct sockaddr *)&sockaddr, 
		sizeof(sockaddr)) < 0) 
	{
		perror("socket");
		exit(-1);
	}
	for (i = 0; i < 40; i++) obuf[i]=0x85;
	obuf[0]=0x00;
	snd=0; rcv=0;
	for (i = 0; i < cnt; i++)
	{
	  if ( (write(sockfd,obuf,sizeof(obuf))) < 0)
	  {
		perror("Write");
		exit(-1);
	  }
	  snd++;
	  if ( (read(sockfd,ibuf,sizeof(ibuf))) < 0)
	  {
		perror("Read");
		exit(-1);
	  }
	  if (memcmp(&obuf[1],&ibuf[1],39) != 0) 
		printf("Loopback Error\n");
	  else  rcv++;
	}
	close(sockfd);
	printf("Send %d packets, Received %d packets\n",snd,rcv);
	return 0;
}
