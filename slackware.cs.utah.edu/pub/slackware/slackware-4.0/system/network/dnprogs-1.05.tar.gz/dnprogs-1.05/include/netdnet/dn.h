/*


	DECnet Data Structures and Constants




*/

#ifndef	NETDNET_DN_H
#define NETDNET_DN_H

#define DNPROTO_NSP	2 /* This can't be the same as SOL_SOCKET */
#define SO_LINKINFO	7
#define DN_ADDL		2
#define DN_MAXADDL	2
#define DN_MAXOPTL	16
#define DN_MAXOBJL	16
#define DN_MAXACCL	40
#define DN_MAXALIASL	128
#define DN_MAXNODEL	256

/* SET/GET Socket options */
#define SO_CONDATA	1
#define SO_CONACCESS	2
#define SO_PROXYUSR	3
/* LINK States */
#define LL_INACTIVE	0
#define LL_CONNECTING	1
#define LL_RUNNING	2
#define LL_DISCONNECTING 3

/* DNLIB FUNCTIONS PROTOTYPING 
extern	struct	dn_naddr	*dnet_addr(char *);
extern	char 			*getexecdev(void);
extern	char 			*getnodeadd(void);
extern	char 			*getnodebyname(char *name);
*/
/* Structures */


struct dn_naddr 
{
	unsigned short		a_len;
	unsigned char a_addr[DN_MAXADDL];
};

struct sockaddr_dn
{
	unsigned short		sdn_family;
	unsigned char		sdn_flags;
	unsigned char		sdn_objnum;
	unsigned short		sdn_objnamel;
	unsigned char		sdn_objname[DN_MAXOBJL];
#define sdn_nodeaddrl	sdn_add.a_len		/* X11R6.4 compatibility */
	struct   dn_naddr	sdn_add;
};

struct optdata_dn
{
	unsigned char		opt_sts;
	unsigned char 		opt_optl;
	unsigned char		opt_data[DN_MAXOPTL];
};

struct accessdata_dn
{
	unsigned char		acc_accl;
	unsigned char		acc_acc[DN_MAXACCL];
	unsigned char 		acc_passl;
	unsigned char		acc_pass[DN_MAXACCL];
	unsigned char 		acc_userl;
	unsigned char		acc_user[DN_MAXACCL];
};

struct	nodeent	{
	char	*n_name;		/* name of node */
	unsigned short n_addrtype;	/* node address type */
	unsigned short n_length;	/* length of address */
	unsigned char	*n_addr;	/* address	*/
	unsigned char	*n_params;	/* node parameters */
	unsigned char	n_reserved[16];	/* reserved */
};

#ifdef __KERNEL__
struct dn_scp					/* Session Control Port */
{
	unsigned char		state;

#define	DN_O	 1			/* Open			*/
#define DN_CR	 2			/* Connect Receive	*/
#define DN_DR	 3			/* Disconnect Reject	*/
#define DN_DRC	 4			/* Discon. Rej. Complete*/
#define DN_CC	 5			/* Connect Confirm	*/
#define DN_CI	 6			/* Connect Initiate	*/
#define DN_NR	 7 			/* No resources		*/
#define DN_NC	 8			/* No communication	*/
#define DN_CD	 9			/* Connect Delivery	*/
#define DN_RJ	 10			/* Rejected		*/
#define DN_RUN	 11			/* Running		*/
#define DN_DI	 12			/* Disconnect Initiate  */
#define DN_DIC	 13			/* Disconnect Complete  */
#define DN_DN	 14			/* Disconnect Notificat */
#define DN_CL	 15			/* Closed		*/
#define DN_CN	 16			/* Closed Notification  */

	unsigned short		addrloc;	
	unsigned short		addrrem;
	unsigned short		numdat;
	unsigned short		numoth;
	int			status;
	unsigned short		numoth_rcv;
	unsigned short		numdat_rcv;
	unsigned short		ackxmt_dat;
	unsigned short		ackxmt_oth;
	unsigned short		ackrcv_dat;
	unsigned short		ackrcv_oth;
	unsigned char		flowrem_sw;
	unsigned char		flowloc_sw;
#define DN_SEND         2
#define DN_DONTSEND	1
#define DN_NOCHANGE     0
	unsigned short		retrans_count;
	unsigned short		exp_time;
	struct	 timer_list	timer;
	struct	 timer_list	keepalive_timer;
	struct	 optdata_dn	optdata;
	struct	 accessdata_dn	accessdata;
	struct	 sockaddr_dn	sockaddr;
	struct	 sk_buff	*xmt_skb;
};

#endif
#endif				/* NETDNET_DN_H */
