/******************************************************************************
    (c) 1998 P.J. Caulfield               patrick@pandh.demon.co.uk
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 ******************************************************************************
*/
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <stdio.h>
#include <syslog.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <regex.h>
#include <netdnet/dn.h>
#include <netdnet/dnetdb.h>

#include "logging.h"
#include "connection.h"
#include "protocol.h"
#include "dnetfile.h"


/*-------------------------------------------------------------------------*/
void dnetfile::dap_close_link()
{
    if (verbose > 2) DAPLOG((LOG_INFO, "in dap_close_link()\n"));
    conn.close();
}
/*-------------------------------------------------------------------------*/
int dnetfile::dap_get_reply(void)
{
    if (verbose > 2) DAPLOG((LOG_INFO, "in dap_get_reply()\n"));
    dap_message *m = dap_message::read_message(conn,true);
    if (m)
    {
	if (m->get_type() == dap_message::STATUS)
	    return dap_check_status(m,0);

	if (m->get_type() == dap_message::ACK)
	    return 0; // OK
	if (m->get_type() == dap_message::ACCOMP)
	    return 0; // OK

	DAPLOG((LOG_ERR, "dap_get_reply: got : %s(%d)\n", m->type_name(), m->get_type()));
	lasterror = "Unknown message type received";
	return -1;
    }
    DAPLOG((LOG_ERR, "dap_get_reply error: %s\n",conn.get_error()));

    return -1; 
}
/*-------------------------------------------------------------------------*/
int dnetfile::dap_send_access()
{
    dap_access_message acc;
    acc.set_accfunc(dap_access_message::OPEN);

    if (transfer_mode == MODE_BLOCK)
    {
	acc.set_fac( (1<<dap_access_message::FB$GET) ||
		     (1<<dap_access_message::FB$BIO) );
	acc.set_shr(1<<dap_access_message::FB$BRO); // No sharing PJC CHECK
    }

    if (writing)
    {
	acc.set_accfunc(dap_access_message::CREATE);
	acc.set_fac(dap_access_message::FB$PUT);
	acc.set_shr(1<<dap_access_message::FB$BRO); // No sharing PJC CHECK
    }
    else // We build our own attributes message when writing.
    {
	dap_attrib_message att;
	att.write(conn);
    }
    acc.set_display(dap_access_message::DISPLAY_MAIN_MASK |
		    dap_access_message::DISPLAY_PROT_MASK |
		    dap_access_message::DISPLAY_NAME_MASK);
    acc.set_filespec(filname);
    return !acc.write(conn); 
}

/*-------------------------------------------------------------------------*/

// Receive the attributes of a file for download or a newly created file
int dnetfile::dap_get_file_entry(int *rfm, int *rat)
{
    if (verbose > 2) DAPLOG((LOG_INFO, "in dap_get_file_entry()\n"));
    dirname[0] = volname[0] = filname[0] = '\0';

    dap_message *m;
    while ( ((m = dap_message::read_message(conn, true))) )
    {
	switch (m->get_type())
	{
	case dap_message::NAME:
	    {
		dap_name_message *nm = (dap_name_message *)m;
		switch (nm->get_nametype())
		{
		case dap_name_message::VOLUME:
		    strcpy(volname, nm->get_namespec());
		    break;

		case dap_name_message::DIRECTORY:
		    strcpy(dirname, nm->get_namespec());
		    break;

		case dap_name_message::FILENAME:
		    strcpy(filname, nm->get_namespec());
		    break;

		case dap_name_message::FILESPEC:
		    strcpy(filname, nm->get_namespec());
		    break;
		}
	    }
	    break;
	    
	case dap_message::ACCOMP:
	    return -2; // End of wildcard list

	case dap_message::ATTRIB:
	    {
		dap_attrib_message *am =(dap_attrib_message *)m;
		*rfm = am->get_rfm();
		*rat = am->get_rat(); 
	    }
	    break;
	case dap_message::PROTECT:
	    {
		dap_protect_message *pm =(dap_protect_message *)m;
		prot = pm->get_mode();
	    }
	    break;

	case dap_message::ACK:
	    return 0;

	case dap_message::STATUS:
	    {
		dap_status_message *sm = (dap_status_message *)m;
		if (sm->get_code() == 0x4030) // Locked
		{
		    dap_send_skip();
		    break;
		}
		return -1;
	    }

	default:
	    return m->get_type();
	}
	if (m) delete m;
    }
    return -1;
}
/*-------------------------------------------------------------------------*/
int dnetfile::dap_send_connect()
{
    if (verbose > 2) DAPLOG((LOG_INFO, "in dap_send_connect()\n"));

    dap_control_message ctl;

    ctl.set_ctlfunc(dap_control_message::CONNECT);
    ctl.write(conn);

    return dap_get_reply();

}
/*-------------------------------------------------------------------------*/
// Sends a CONTROL message with $GET or $PUT as the action
// Also enables block mode for reading files with -mblock requested.
// Note we don't really write files in block mode only read them.
// "Block" writes just create fixed-length record binary files.
int dnetfile::dap_send_get_or_put()
{
    if (verbose > 2) DAPLOG((LOG_INFO, "in dap_send_get_or_put(%s)\n",
	writing?"$PUT":"$GET"));

    dap_control_message ctl;
    ctl.set_ctlfunc(dap_control_message::GET);
    ctl.set_rac(dap_control_message::SEQFT);

    if (transfer_mode == MODE_BLOCK && !writing)
    {
	ctl.set_rac(dap_control_message::BLOCKFT);
    }

    if (writing)
    {
	ctl.set_ctlfunc(dap_control_message::PUT);
    }
    return !ctl.write(conn);
}
/*-------------------------------------------------------------------------*/

// Send Access Complete.
int dnetfile::dap_send_accomp()
{
    dap_accomp_message accomp;
    accomp.set_cmpfunc(dap_accomp_message::CLOSE);
    if (!accomp.write(conn)) return -1;

    if (writing) 
	return dap_get_reply();
    else
	return 0;
}
/*-------------------------------------------------------------------------*/
int dnetfile::dap_get_record(char *rec, int reclen)
{
    if (verbose > 2) DAPLOG((LOG_INFO, "in dap_get_record()\n"));

    dap_message *m = dap_message::read_message(conn,true);
    if (m)
    {
	if (m->get_type() == dap_message::STATUS)
	{
	    dap_status_message *sm = (dap_status_message *)m;
	    if ( (sm->get_code() & 0xFF) == 047)
	    {
		ateof = TRUE;
		return -1;
	    }
	    return dap_check_status(m,0);
	}

	if (m->get_type() == dap_message::ACK)
	{
	    return 0; //PJC Why need this ??
	}

	if (m->get_type() != dap_message::DATA)
	{
	    sprintf(errstring, "Wrong block type (%s) received", m->type_name());
	    lasterror = errstring;
	    return -1;
	}
	dap_data_message *dm = (dap_data_message *)m;
	unsigned int len = dm->get_datalen();
	rec[len] = 0;
	memcpy(rec, dm->get_dataptr(), len);
	
	return len;
    }
    lasterror = conn.get_error();
    return -1;
}

// Send a record to VMS
int dnetfile::dap_put_record(char *rec, int reclen)
{
    if (verbose > 2) DAPLOG((LOG_INFO, "in dap_put_record(%d bytes)\n", reclen));

    dap_data_message data;

    data.set_data(rec, reclen);
    data.write(conn); // Normal write with no length field

    // Check for out-of-band messages
    dap_message *d = dap_message::read_message(conn, false);
    if (d)
	return dap_check_status(d,0);
    return 0;
}

// Send the attributes for a newly created file
int dnetfile::dap_send_attributes()
{
    if (verbose > 2) DAPLOG((LOG_INFO, "in dap_send_attributes()\n"));

    dap_attrib_message att;
    dap_alloc_message  all;
    

    att.set_org(dap_attrib_message::FB$SEQ);
    att.set_rfm(dap_attrib_message::FB$STMLF);
    att.set_bls(512);
    att.set_mrs(user_bufsize);

// CR attributes on all but BLOCK mode sends
    if (transfer_mode != MODE_BLOCK)
    {
	att.set_rat_bit(dap_attrib_message::FB$CR);
    }

// Set the attributes of the uploaded file
    if (user_rat != RAT_DEFAULT)
    {
	if (user_rat == RAT_FTN) att.set_rat_bit(dap_attrib_message::FB$FTN);
	if (user_rat == RAT_CR)  att.set_rat_bit(dap_attrib_message::FB$CR);
	if (user_rat == RAT_PRN) att.set_rat_bit(dap_attrib_message::FB$PRN);
    }

    if (user_rfm != RFM_DEFAULT)
	att.set_rfm(user_rfm);

    conn.set_blocked(true);
    att.write(conn);
    all.write(conn);
    return conn.set_blocked(false);
}

int dnetfile::dap_send_name()
{
    if (verbose > 2) DAPLOG((LOG_INFO, "in dap_send_name() %s\n", name));

    dap_name_message nam;
    nam.set_nametype(dap_name_message::FILESPEC);
    nam.set_namespec(name);
    return !nam.write(conn);
}

// Skip to the next file. (used for skipping directories)
int dnetfile::dap_send_skip()
{
    dap_contran_message ct;
    ct.set_confunc(dap_contran_message::SKIP);
    return !ct.write(conn);
}

// Check a STATUS message. code 0225 is Success and 047 is EOF so we return a
// correct status code for those cases.
int dnetfile::dap_check_status(dap_message *m, int status)
{
    dap_status_message *sm = (dap_status_message *)m;
    if (m->get_type() != dap_message::STATUS) return -1;

    int code = sm->get_code() & 0xFF;
    delete m;

    if (code == 0225) return status; // Success
    if (code == 047)  return code;   // EOF
    lasterror = dap_error(code);
    return -1;
}

// Convert a DAP error code into a message
char *dnetfile::dap_error(int code)
{
    switch (code)
    {
    case 01: return "operation aborted.";
    case 02: return "F11-ACP could not access file.";
    case 03: return "\"FILE\" activity precludes operation.";
    case 04: return "bad area ID.";
    case 05: return "alignment options error.";
    case 06: return "allocation quantity too large or 0 value.";
    case 07: return "not ANSI \"D\" format.";
    case 010: return "allocation options error.";
    case 011: return "invalid (i.e., synch) operation at AST level.";
    case 012: return "attribute read error.";
    case 013: return "attribute write error.";
    case 014: return "bucket size too large.";
    case 015: return "bucket size too large.";
    case 016: return "\"BLN\" length error.";
    case 017: return "beginning of file detected.";
    case 020: return "private pool address.";
    case 021: return "private pool size.";
    case 022: return "internal RMS error condition detected.";
    case 023: return "cannot connect RAB.";
    case 024: return "$UPDATE changed a key without having attribute of XB$CHG set.";
    case 025: return "bucket format check-byte failure.";
    case 026: return "RSTS/E close function failed.";
    case 027: return "invalid or unsupported \"COD\" field.";
    case 030: return "F11-ACP could not create file (STV=sys err code).";
    case 031: return "no current  record  (operation  not  preceded  by GET/FIND).";
    case 032: return "F11-ACP deaccess error during \"CLOSE\".";
    case 033: return "data \"AREA\" number invalid.";
    case 034: return "RFA-Accessed record was deleted.";
    case 035: return "bad device, or inappropriate device type.";
    case 036: return "error in directory name.";
    case 037: return "dynamic memory exhausted.";
    case 040: return "directory not found.";
    case 041: return "device not ready.";
    case 042: return "device has positioning error.";
    case 043: return "\"DTP\" field invalid.";
    case 044: return "duplicate key detected, XB$DUP not set.";
    case 045: return "RSX-F11ACP enter function failed.";
    case 046: return "operation not selected in \"ORG$\" macro.";
    case 047: return "end-of-file.";
    case 050: return "expanded string area too short.";
    case 051: return "file expiration date not yet reached.";
    case 052: return "file extend failure.";
    case 053: return "not a valid FAB (\"BID\" NOT = FB$BID).";
    case 054: return "illegal FAC for REC-OP,0, or FB$PUT not  set  for \"CREATE\".";
    case 055: return "file already exists.";
    case 056: return "invalid file I.D.";
    case 057: return "invalid flag-bits combination.";
    case 060: return "file is locked by other user.";
    case 061: return "RSX-F11ACP \"FIND\" function failed.";
    case 062: return "file not found.";
    case 063: return "error in file name.";
    case 064: return "invalid file options.";
    case 065: return "DEVICE/FILE full.";
    case 066: return "index \"AREA\" number invalid.";
    case 067: return "invalid IFI value or unopened file.";
    case 070: return "maximum NUM(254) areas/key XABS exceeded.";
    case 071: return "$INIT macro never issued.";
    case 072: return "operation illegal or invalid for file organization.";
    case 073: return "illegal record encountered (with sequential files only).";
    case 074: return "invalid ISI value, on unconnected RAB.";
    case 075: return "bad KEY buffer address (KBF=0).";
    case 076: return "invalid KEY field (KEY=0/neg).";
    case 077: return "invalid key-of-reference ($GET/$FIND).";
    case 0100: return "KEY size too large.";
    case 0101: return "lowest-level-index \"AREA\" number invalid.";
    case 0102: return "not ANSI labeled tape.";
    case 0103: return "logical channel busy.";
    case 0104: return "logical channel number too large.";
    case 0105: return "logical extend error, prior extend still valid.";
    case 0106: return "\"LOC\" field invalid.";
    case 0107: return "buffer mapping error.";
    case 0110: return "F11-ACP could not mark file for deletion.";
    case 0111: return "MRN value=neg or relative key>MRN.";
    case 0112: return "MRS value=0 for fixed length records.  Also 0 for relative files.";
    case 0113: return "\"NAM\"  block  address  invalid  (NAM=0,  or   not accessible).";
    case 0114: return "not positioned to EOF (sequential files only).";
    case 0115: return "cannot allocate internal index descriptor.";
    case 0116: return "indexed file; no primary key defined.";
    case 0117: return "RSTS/E open function failed.";
    case 0120: return "XAB'S not in correct order.";
    case 0121: return "invalid file organization value.";
    case 0122: return "error in file's prologue (reconstruct file).";
    case 0123: return "\"POS\" field invalid (POS>MRS,STV=XAB indicator).";
    case 0124: return "bad file date field retrieved.";
    case 0125: return "privilege violation (OS denies access).";
    case 0126: return "not a valid RAB (\"BID\" NOT=RB$BID).";
    case 0127: return "illegal RAC value.";
    case 0130: return "illegal record attributes.";
    case 0131: return "invalid record  buffer  address  (\"ODD\",  or  not word-aligned if BLK-IO).";
    case 0132: return "file read error.";
    case 0133: return "record already exists.";
    case 0134: return "bad RFA value (RFA=0).";
    case 0135: return "invalid record format.";
    case 0136: return "target bucket locked by another stream.";
    case 0137: return "RSX-F11 ACP remove function failed.";
    case 0140: return "record not found.";
    case 0141: return "record not locked.";
    case 0142: return "invalid record options.";
    case 0143: return "error while reading prologue.";
    case 0144: return "invalid RRV record encountered.";
    case 0145: return "RAB stream currently active.";
    case 0146: return "bad record size (RSZ>MRS,  or  NOT=MRS  if  fixed length records).";
    case 0147: return "record too big for user's buffer.";
    case 0150: return "primary  key  out  of  sequence  (RAC=RB$SEQ  for $PUT).";
    case 0151: return "\"SHR\"  field  invalid  for  file  (cannot   share sequential files).";
    case 0152: return "\"SIZ field invalid.";
    case 0153: return "stack too big for save area.";
    case 0154: return "system directive error.";
    case 0155: return "index tree error.";
    case 0156: return "error in file type extension on FNS too big.";
    case 0157: return "invalid user buffer addr (0, odd, or if  BLK-IO not word aligned).";
    case 0160: return "invalid user buffer size (USZ=0).";
    case 0161: return "error in version number.";
    case 0162: return "invalid volume number.";
    case 0163: return "file write error (STV=sys err code).";
    case 0164: return "device is write locked.";
    case 0165: return "error while writing prologue.";
    case 0166: return "not a valid XAB (@XAB=ODD,STV=XAB indicator).";
    case 0167: return "default directory invalid.";
    case 0170: return "cannot access argument list.";
    case 0171: return "cannot close file.";
    case 0172: return "cannot deliver AST.";
    case 0173: return "channel assignment failure (STV=sys err code).";
    case 0174: return "terminal output ignored due to (CNTRL) O.";
    case 0175: return "terminal input aborted due to (CNTRL) Y.";
    case 0176: return "default filename string address error.";
    case 0177: return "invalid device I.D.  field.";
    case 0200: return "expanded string address error.";
    case 0201: return "filename string address error.";
    case 0202: return "FSZ field invalid.";
    case 0203: return "invalid argument list.";
    case 0204: return "known file found.";
    case 0205: return "logical name error.";
    case 0206: return "node name error.";
    case 0207: return "operation successful.";
    case 0210: return "record inserted had duplicate key.";
    case 0211: return "index update error occurred-record inserted.";
    case 0212: return "record locked but read anyway.";
    case 0213: return "record  inserted  in  primary  o.k.; may  not  be accessible by secondary keys or RFA.";
    case 0214: return "file was created, but not opened.";
    case 0215: return "bad prompt buffer address.";
    case 0216: return "async.  operation pending completion.";
    case 0217: return "quoted string error.";
    case 0220: return "record header buffer invalid.";
    case 0221: return "invalid related file.";
    case 0222: return "invalid resultant string size.";
    case 0223: return "invalid resultant string address.";
    case 0224: return "operation not sequential.";
    case 0225: return "operation successful.";
    case 0226: return "created file superseded existing version.";
    case 0227: return "filename syntax error.";
    case 0230: return "time-out period expired.";
    case 0231: return "FB$BLK record attribute not supported.";
    case 0232: return "bad byte size.";
    case 0233: return "cannot disconnect RAB.";
    case 0234: return "cannot get JFN for file.";
    case 0235: return "cannot open file.";
    case 0236: return "bad JFN value.";
    case 0237: return "cannot position to end-of-file.";
    case 0240: return "cannot truncate file.";
    case 0241: return "file is currently in an  undefined  state; access is denied.";
    case 0242: return "file must be opened for exclusive access.";
    case 0243: return "directory full.";
    case 0244: return "handler not in system.";
    case 0245: return "fatal hardware error.";
    case 0246: return "attempt to write beyond EOF.";
    case 0247: return "hardware option not present.";
    case 0250: return "device not attached.";
    case 0251: return "device already attached.";
    case 0252: return "device not attachable.";
    case 0253: return "sharable resource in use.";
    case 0254: return "illegal overlay request.";
    case 0255: return "block check or CRC error.";
    case 0256: return "caller's nodes exhausted.";
    case 0257: return "index file full.";
    case 0260: return "file header full.";
    case 0261: return "accessed for write.";
    case 0262: return "file header checksum failure.";
    case 0263: return "attribute control list error.";
    case 0264: return "file already accessed on LUN.";
    case 0265: return "bad tape format.";
    case 0266: return "illegal operation on file descriptor block.";
    case 0267: return "rename; 2 different devices.";
    case 0270: return "rename; new filename already in use.";
    case 0271: return "cannot rename old file system.";
    case 0272: return "file already open.";
    case 0273: return "parity error on device.";
    case 0274: return "end of volume detected.";
    case 0275: return "data over-run.";
    case 0276: return "bad block on device.";
    case 0277: return "end of tape detected.";
    case 0300: return "no buffer space for file.";
    case 0301: return "file exceeds allocated space -- no blks.";
    case 0302: return "specified task not installed.";
    case 0303: return "unlock error.";
    case 0304: return "no file accessed on LUN.";
    case 0305: return "send/receive failure.";
    case 0306: return "spool or submit command file failure.";
    case 0307: return "no more files.";
    case 0310: return "DAP file transfer Checksum error.";
    case 0311: return "Quota exceeded";
    case 0312: return "internal network error condition detected.";
    case 0313: return "terminal input aborted due to (CNTRL) C.";
    case 0314: return "data bucket fill size > bucket size in XAB.";
    case 0315: return "invalid expanded string length.";
    case 0316: return "illegal bucket format.";
    case 0317: return "bucket size of LAN NOT = IAN in XAB.";
    case 0320: return "index not initialized.";
    case 0321: return "illegal file attributes (corrupt file header).";
    case 0322: return "index bucket fill size > bucket size in XAB.";
    case 0323: return "key name buffer not readable or writeable in XAB.";
    case 0324: return "index bucket will not hold two keys  for  key  of reference.";
    case 0325: return "multi-buffer count invalid (negative value).";
    case 0326: return "network operation failed at remote node.";
    case 0327: return "record is already locked.";
    case 0330: return "deleted record successfully accessed.";
    case 0331: return "retrieved record exceeds specified key value.";
    case 0332: return "key XAB not filled in.";
    case 0333: return "nonexistent record successfully accessed.";
    case 0334: return "unsupported prologue version.";
    case 0335: return "illegal key-of-reference in XAB.";
    case 0336: return "invalid resultant string length.";
    case 0337: return "error updating rrv's, some paths to data  may  be lost.";
    case 0340: return "data types  other  than  string  limited  to  one segment in XAB.";
    case 0341: return "reserved";
    case 0342: return "operation not supported over network.";
    case 0343: return "error on write behind.";
    case 0344: return "invalid wildcard operation.";
    case 0345: return "working set full (can not lock buffers in working set.)";
    case 0346: return "directory listing -- error in reading  volume-set name, directory name, of file name.";
    case 0347: return "directory  listing  --  error  in  reading   file attributes.";
    case 0350: return "directory  listing  --  protection  violation  in trying  to read the volume-set, directory or file name.";
    case 0351: return "directory  listing  --  protection  violation  in trying to read file attributes.";
    case 0352: return "directory  listing  --  file  attributes  do  not exist.";
    case 0353: return "directory listing -- unable to recover  directory list after Continue Transfer (Skip).";
    case 0354: return "sharing not enabled.";
    case 0355: return "sharing page count exceeded.";
    case 0356: return "UPI bit not set when sharing with BRO set.";
    case 0357: return "error in access control string (poor man's  route through error).";
    case 0360: return "terminator not seen.";
    case 0361: return "bad escape sequence.";
    case 0362: return "partial escape sequence.";
    case 0363: return "invalid wildcard context value.";
    case 0364: return "invalid directory rename operation.";
    case 0365: return "user structure (FAB/RAB)  became  invalid  during operation.";
    case 0366: return "network file transfer made precludes operation.";
    }
    sprintf(errstring, "unknown error: 0%o", code);
    return errstring;
}
