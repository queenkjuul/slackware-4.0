/*
 * (C) 1998 Steve Whitehouse
 */
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/sysctl.h>

#include "netdnet/dn.h"


int setnodename(const char *name, size_t len)
{
#ifdef NET_DECNET_NODE_NAME
	int ctlname[3] = { CTL_NET, NET_DECNET, NET_DECNET_NODE_NAME };
	size_t nospace = 0;

	if (len > 6)
		return -1;

	return sysctl(ctlname, 3, NULL, &nospace, (void *)name, len);
#else
	return -1;
#endif
}


