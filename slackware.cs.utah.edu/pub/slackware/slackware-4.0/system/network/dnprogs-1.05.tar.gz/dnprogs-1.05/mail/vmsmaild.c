/******************************************************************************
    (c) 1998 P.J. Caulfield               patrick@pandh.demon.co.uk
                                          pcaulfield@cix.co.uk
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 ******************************************************************************
*/
////
// vmsmaild.c
// VMSmail processing daemon for Linux
////

#define MAIL_OBJECT 27

#include <stdio.h>
#include <syslog.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <pwd.h>
#include <netdnet/dn.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "configfile.h"
#include "receive.h"

void sigchild(int s);
void sigterm(int s);

static volatile int do_shutdown = 0;

// Global variables.
int verbosity = 0;

void usage(char *prog, FILE *f)
{
    fprintf(f,"\n%s options:\n", prog);
    fprintf(f," -v        Verbose messages\n");
    fprintf(f," -h        Show this help text\n");
    fprintf(f," -U        Don't check that reply user exists\n");
    fprintf(f," -V        Show version number\n\n");
}



int main(int argc, char *argv[])
{
    pid_t              pid;
    char               opt;
    struct sockaddr_dn sockaddr;
    struct optdata_dn  optdata;
    int		       sockfd,insock;
    int                len = sizeof(sockaddr);
    int                check_user=1;
    char               optdata_bytes[] = {0x03, 01, 00, 07, 00, 00, 00, 00,
					  0xa2, 02, 00, 00, 01, 00, 00, 00};

    // Set up syslog logging
    openlog("vmsmaild", LOG_PID, LOG_DAEMON);

    read_configfile();
    
    // Deal with command-line arguments. Do these before the check for root
    // so we can check the version number and get help without being root.
    opterr = 0;
    optind = 0;
    while ((opt=getopt(argc,argv,"?vVhu:U")) != EOF)
    {
	switch(opt) 
	{
	case 'h': 
	    usage(argv[0], stdout);
	    exit(0);

	case '?':
	    usage(argv[0], stderr);
	    exit(0);

	case 'v':
	    verbosity++;
	    break;

	case 'V':
	    printf("\nvmsmaild from dnprogs version %s\n\n", VERSION);
	    exit(1);
	    break;

	case 'U':
	    check_user=0;
	    break;
	}
    }

    if (getuid() != 0)
    {
	fprintf(stderr, "Must be root to run vmsmail daemon\n");
	exit(2);
    }

    // See if the vmsmail user exists on this system
    if (check_user)
    {
	if (!getpwnam(config_vmsmailuser))
	{
	    syslog(LOG_ERR, "user for vmsmail (%s) does not exist, change the user in /etc/vmsmail.conf or use the -U option to get rid of this message\n",
		   config_vmsmailuser);
	}
    }
    
#ifndef NO_FORK
    switch(pid=fork())
    {
    case -1:
	perror("vmsmaild cannot fork");
	exit(2);
	
    case 0:
	setsid();
	close(0); close(1); close(2);
	chdir("/");
	break;
	
    default:
	if (verbosity) syslog(LOG_INFO, "forked process %d\n", pid);
        exit(0);
    }
#endif
    
    if ((sockfd=socket(AF_DECnet,SOCK_SEQPACKET,DNPROTO_NSP)) == -1) 
    {
	perror("socket");
	exit(-1);
    }
    
    sockaddr.sdn_family   = AF_DECnet;
    sockaddr.sdn_flags	  = 0x00;
    sockaddr.sdn_objnum	  = MAIL_OBJECT;
    sockaddr.sdn_objnamel = 0x00;
    
/* Set SO_CONDATA to tell the remote end we can accept binary data */
    optdata.opt_sts = 0;
    memcpy(optdata.opt_data, optdata_bytes, sizeof(optdata_bytes));
    optdata.opt_optl = sizeof(optdata_bytes);
    if ((setsockopt(sockfd, DNPROTO_NSP, SO_CONDATA, &optdata, sizeof(optdata))) < 0) 
    {
	syslog(LOG_WARNING, "setsockopt(CONDATA) failed: %m. binary mail will not work\n");
    }

    if (bind(sockfd, (struct sockaddr *)&sockaddr, 
	     sizeof(sockaddr)) < 0) 
    {
	perror("Bind");
	exit(-1);
    }

    
    if (listen(sockfd,1) < 0)
    {
	perror("Listen");
	exit(-1);
    }

    // Set up signal handlers.
    signal(SIGCHLD, sigchild);
    signal(SIGTERM, sigterm);
    signal(SIGHUP,  SIG_IGN);

    
    do
    {
	if ( (insock=accept(sockfd, (struct sockaddr *)&sockaddr, &len)) < 0)
	{
	    if (errno == EINTR) continue;
	    syslog(LOG_INFO, "VMSMAILD: accept failed: %m\n");
	    perror("Accept");
	    exit(-1);
	}
#ifdef NO_FORK	
        receive_mail(insock);
#else
	switch(pid=fork())
	{
	case -1:
	    perror("vmsmaild cannot fork");
	    break;
	    
	case 0: // Child
	    receive_mail(insock);
	    close(insock);
	    exit(0);
	    break;
	    
	default: // Parent
	    if (verbosity) syslog(LOG_INFO, "created child process %d\n", pid);
	    close(insock);
	    break;
	}
#endif
    }
    while(!do_shutdown);
    syslog(LOG_INFO, "closing down\n");
    close(sockfd);
    return 0;
}


// Catch child process shutdown
void sigchild(int s)
{
    int status, pid;
    signal(SIGCHLD, sigchild);

    // Make sure we reap all children
    do 
    { 
	pid = waitpid(-1, &status, WNOHANG); 
    }
    while (pid > 0);
}

// Catch termination signal
void sigterm(int s)
{
    syslog(LOG_INFO, "SIGTERM caught, going down\n");
    do_shutdown = 1;
}
