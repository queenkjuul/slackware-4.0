/*
 * (C) 1998 Steve Whitehouse
 */
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/sysctl.h>

#include "netdnet/dn.h"

int getnodename(char *name, size_t len)
{
#ifdef NET_DECNET_NODE_NAME
	int ctlname[3] = { CTL_NET, NET_DECNET, NET_DECNET_NODE_NAME };


	return sysctl(ctlname, 3, (void *)name, &len, NULL, 0);
#else
	return -1;
#endif
}


