void new_phone_connection(int insock, int verbosity);
void accept_unix(int entry);
void accept_decnet(int entry);
void read_unix(int entry);
void read_decnet(int entry);
