// This is really just a struct.
// All the relevant command-line parameters are passed down
// to the work classes using this class.
class fal_params
{
 public:
    int   verbosity;
    enum  {GUESS_TYPE, CHECK_EXT, NONE} auto_type;
    char *auto_file;
    static const char default_file[]  = {"#\n\
.exe  b 512\n\
.txt  r\n\
.c    r\n\
.cc   r\n\
.com  r\n\
.lis  r\n\
.bck  b 8192\n\
.save b 8192\n\
# End of file"};
};
