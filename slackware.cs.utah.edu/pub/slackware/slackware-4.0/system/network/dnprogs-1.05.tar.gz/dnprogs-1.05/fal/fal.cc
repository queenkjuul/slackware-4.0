/******************************************************************************
    (c) 1998 P.J. Caulfield               patrick@pandh.demon.co.uk
                                          pcaulfield@cix.co.uk
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 ******************************************************************************
*/
////
// fal.cc
// DECnet File Access Listener for Linux
////
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <getopt.h>
#include <unistd.h>
#include <syslog.h>
#include <pwd.h>
#include <grp.h>
#include <regex.h>
#include <signal.h>
#include <string.h>
#include <netdnet/dn.h>
#include <netdnet/dnetdb.h>

#include "logging.h"
#include "connection.h"
#include "protocol.h"
#include "vaxcrc.h"
#include "params.h"
#include "task.h"
#include "server.h"

void usage(char *prog, FILE *f);
void sigchild(int s);
void sigterm(int s);

// This is the FAL object number
#define FAL_OBJECT 0x11

// The number of fork() fails we sill tolerate before going home
#define MAX_FORKS 10

static volatile bool do_shutdown = false;
static int verbose = 0;
static dap_connection *global_connection = NULL;

// You are here
int main(int argc, char *argv[])
{
    int    dont_fork = 0;
    char   opt;
    char   log_char = 'l'; // Default to syslog(3)
    struct fal_params p;

// Set defaults
    p.verbosity = 0;                // Softly-softly.
    p.auto_type = fal_params::NONE; // Do not guess file types
    p.auto_file = NULL;             // Use built-in defaults

#ifdef NO_FORK
    dont_fork = 1;
#endif

    // Deal with command-line arguments. Do these before the check for root
    // so we can check the version number and get help without being root.
    opterr = 0;
    optind = 0;
    while ((opt=getopt(argc,argv,"?vVhdl:a:f:")) != EOF)
    {
	switch(opt) 
	{
	case 'h': 
	    usage(argv[0], stdout);
	    exit(0);

	case '?':
	    usage(argv[0], stderr);
	    exit(0);

	case 'v':
	    p.verbosity++;
	    break;

	case 'd':
	    dont_fork++;
	    break;

	case 'V':
	    printf("\nfal from dnprogs version %s\n\n", VERSION);
	    exit(1);
	    break;

#ifdef AUTO_TYPE
	case 'a':
	    if (optarg[0] == 'g') p.auto_type = fal_params::GUESS_TYPE;
	    if (optarg[0] == 'e') p.auto_type = fal_params::CHECK_EXT;
	    if (p.auto_type == fal_params::NONE)
	    {
		fprintf(stderr, "Invalid auto type : '%s'\n", optarg);
		usage(argv[0], stderr);
		exit(2);
	    }
	    break;
#endif

	case 'l':
	    if (optarg[0] != 's' &&
		optarg[0] != 'm' &&
		optarg[0] != 'e')
	    {
		usage(argv[0], stderr);
		exit(2);
	    }
	    log_char = optarg[0];
	    break;

	case 'f':
	    p.auto_file = optarg;
	    break;
	    
	}
    }

    verbose = p.verbosity; // Our local copy

    // We must be root
    if (getuid() != 0)
    {
	fprintf(stderr, "fal must be run as root\n");
	exit(2);
    }

#ifdef AUTO_TYPES
    // Now we know are root, check for the types file
    if (p.auto_file)
    {
	struct stat st;
	if (stat(p.auto_file, &st))
	{
	    fprintf(stderr, "Unable to access types file '%s'\n", p.auto_file);
	    usage(argv[0], stderr);
	    exit(2);
	}
    }
#endif

    // Initialise logging
    init_logging(log_char, true);

    // Become a daemon
    if (!dont_fork)
    {
	pid_t pid;

	switch ( pid=fork() )
	{
	case -1:
	    perror("fal: can't fork");
	    exit(2);

	case 0: // child
	    setsid();
	    chdir("/");

	    // Open the syslog
	    openlog("fal", LOG_PID, LOG_DAEMON);

	    // Close our other FDs
	    close(0);
	    close(1);
	    close(2);
	    break;

	default: // Parent.
	    if (p.verbosity > 1) printf("fal: forked process %d\n", pid);
	    exit(0); 
	}
    }

    // Set up connections
    dap_connection c(p.verbosity); // Listening connection
    dap_connection *newone;        // Pointer to new connections.

    global_connection = &c;        // Accessible to signal handler

    // Bind to the FAL DECnet object
    if (!c.bind(FAL_OBJECT))
    {
	DAPLOG((LOG_ERR, "%s\n", c.get_error()));
	exit(1);
    }

    // Set up signal handlers.
    signal(SIGCHLD, sigchild);
    signal(SIGTERM, sigterm);
    signal(SIGHUP,  SIG_IGN);

    // Announce
    DAPLOG((LOG_INFO, "FAL v" VERSION " ready for connections\n"));

    // Main loop.
    do
    {
	int fork_fail = 0;

	// Wait for a new connection.
	newone = c.waitfor();
	if (newone)
	{
	    switch (newone->fork_and_setuid())
	    {
	    case -1:
		if (++fork_fail > MAX_FORKS)
		{
		    DAPLOG((LOG_ALERT, "fork failed too often. giving up\n"));
		    exit(100);
		}

		// Oh no, it all went horribly wrong.
		DAPLOG((LOG_ERR, "Fork_and_setuid failed: %s\n", newone->get_error()));
		delete newone;
		continue;

	    case 0: // child
		// This little block keeps the compiler happy
                // I like happy compilers.
		{
		    fal_server f(*newone, p);
		    f.run();
		    f.closedown();
		    newone->set_blocked(false);
		    delete newone;
#ifndef NO_FORK
		    exit(1);
#endif
		}
		break;

	    default: // parent, just tidy up and loop back
		fork_fail = 0;
		delete newone;
		break;
	    }
	}
    }
    while (!do_shutdown);

    DAPLOG((LOG_ERR, "FAL going down: %s\n", c.get_error() ));
    exit(3);
}


void usage(char *prog, FILE *f)
{
    fprintf(f,"%s options:\n", prog);
    fprintf(f," -d        Don't fork\n");
#ifdef AUTO_TYPE 
    fprintf(f," -a<type>  Auto file type: g(guess) or e(check extension)\n");
    fprintf(f," -f<file>  File containing types for -ae\n");
#endif
    fprintf(f," -l<type>  Logging type(s:syslog, e:stderr, m:mono)\n");
    fprintf(f," -v        Verbose (add more to increase verbosity)\n");
    fprintf(f," -V        Show version\n");
    fprintf(f," -h        Help\n");
}

// Catch child process shutdown
void sigchild(int s)
{
    int status, pid;
    signal(SIGCHLD, sigchild);

    // Make sure we reap all children
    do 
    { 
	pid = waitpid(-1, &status, WNOHANG); 
	if (pid > 0 && verbose > 1) DAPLOG((LOG_INFO, "Reaped child process %d\n", pid));
    }
    while (pid > 0);
}

// Catch termination signal
void sigterm(int s)
{
    do_shutdown = true;
    DAPLOG((LOG_INFO, "Caught SIGTERM, going down\n"));
}


