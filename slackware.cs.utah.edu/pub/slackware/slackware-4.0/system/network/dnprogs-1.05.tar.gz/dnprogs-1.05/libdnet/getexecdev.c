#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <netdnet/dn.h>
#include <netdnet/dnetdb.h>
static  char	nodetag[80],nametag[80],nodeadr[80],nodename[80];
static  char	linetag[80],devname[80];
/*--------------------------------------------------------------------------*/
char *getexecdev(void)
{
	FILE		*dnhosts;
	char		nodeln[80];

	if ((dnhosts = fopen("/etc/decnet.conf","r")) == NULL)
	{
		printf("getnodebyname: Can not open /etc/decnet.conf\n");
		exit(-1);
	}
	while (fgets(nodeln,80,dnhosts) != NULL)
	{
		sscanf(nodeln,"%s%s%s%s%s%s\n",nodetag,nodeadr,nametag,
		       nodename,linetag,devname);
		if (strncmp(nodetag,"#",1) != 0)	
		{
		   if (((strcmp(nodetag,"executor") != 0) &&
	    	       (strcmp(nodetag,"node")     != 0)) ||
		       (strcmp(nametag,"name")     != 0))
		   {
		       printf("getnodebyname: Invalid decnet.conf syntax\n");
		       exit(-1);
		   }
		   if (strcmp(linetag,"line") == 0) 
		   {
			fclose(dnhosts);
			return devname;
		    } 
		}
	}
	return 0;
}
/*--------------------------------------------------------------------------*/
