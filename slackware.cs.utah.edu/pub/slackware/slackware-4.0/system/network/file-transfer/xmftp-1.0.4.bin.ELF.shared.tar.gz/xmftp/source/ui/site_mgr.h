/* site_mgr.h - Site Manager */

/***************************************************************************/

/* Brings up the site manager dialog */
void site_manager(Widget w, XtPointer client_data, XtPointer call_data);

/***************************************************************************/
