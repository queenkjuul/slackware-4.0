/* toolbar.h - functions to setup the toolbar */

/*************************************************************************/

/* Create the toolbar section in the toolbar_form */
void add_toolbar_section(Widget toolbar_form, Main_CB *main_cb);

/*************************************************************************/
