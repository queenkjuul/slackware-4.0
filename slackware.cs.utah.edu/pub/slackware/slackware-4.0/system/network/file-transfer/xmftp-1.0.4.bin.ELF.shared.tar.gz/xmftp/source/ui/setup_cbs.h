/* setup_cbs.h - Setup some general callbacks */

/**************************************************************************/

#include "xmftp.h"

/**************************************************************************/

/* Setup general layout callbacks */
void setup_callbacks(Main_CB *main_callback);

/**************************************************************************/
