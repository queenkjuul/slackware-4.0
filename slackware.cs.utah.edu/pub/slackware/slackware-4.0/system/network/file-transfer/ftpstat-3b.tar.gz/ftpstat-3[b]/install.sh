#!/bin/sh

if [ `whoami` != "root" ]; then
	echo "please run this script as root"
	exit 1
fi

echo -n "copying ftpstat to /usr/local/sbin/ftpstat... "
	cp ftpstat /usr/local/sbin/ftpstat
echo "ok"
echo -n "copying adder to /usr/bin/adder... "
	cp adder /usr/bin/adder
echo "ok"
echo -n "copying welcome.stat /home/ftp/welcome.stat... "
	cp welcome.stat /home/ftp/welcome.stat
echo "ok"
echo -n "is it alright to install ftpstat to crontab? [yes]: "; read ans
if [ -z ${ans} ]; then
	echo "#** added by the ftpstat installation script" >> /var/spool/cron/crontabs/root
	echo "15,30,45,0 * * * /usr/local/sbin/ftpstat" >> /var/spool/cron/crontabs/root
	elif [ ${ans} = "y" ]; then
		echo "#** added by the ftpstat installation script" >> /var/spool/cron/crontabs/root
		echo "15,30,45,0 * * * /usr/local/sbin/ftpstat" >> /var/spool/cron/crontabs/root
fi
echo "done."

