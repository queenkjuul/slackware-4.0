/* adder.c - pipe variable addition program. for ftpstat by jason stiefel */
/* code by tymat <tymat@mayhem.erols.com> */
/* on linux, compile with 'gcc adder.c -o adder' */

#include <stdio.h>

main() 
{ 
	int hrmm = 0; 
	int werd; 
	do 
	{
		printf("\n%d", hrmm += werd); 
		scanf("%d", &werd); 
	}
	while (werd);
}

