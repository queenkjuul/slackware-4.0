#define PATCHLEVEL "0.0-h"
#define PACKAGEID "@(#)client.0.0-h"
#define COPYRIGHT "@(#)Copyright 1992, 1993 Philip G Richards.  All rights reserved.  NO WARRANTY!"
