
Read install.txt for instructions on how to install NFTP

NFTP is $25 shareware. 
If you think that it is not worth it, delete these files.

Build platforms:

CPU     Unix version    Distribution            Comment
------------------------------------------------------------------------
x86     Linux libc5     Slackware 3.6           libc 5.4.46
x86     Linux glibc2    RedHat 5.2              glibc 2.0.7
x86     FreeBSD 2.x     FreeBSD 2.2.8           a.out
x86     FreeBSD 3.x     FreeBSD 3.1-RELEASE     ELF
x86     Solaris         Solaris 7
SPARC   Solaris         Solaris 2.5.1 
Alpha   Linux           RedHat 5.2(?)           glibc 2.0.7              
Alpha   Digital Unix    OSF1 V4.0 564
