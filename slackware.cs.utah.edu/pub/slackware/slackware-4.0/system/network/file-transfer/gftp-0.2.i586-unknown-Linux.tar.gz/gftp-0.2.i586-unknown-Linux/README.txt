
                            Welcome to gFTP 0.2
                                      
Features

     * Distributed under the terms of the GNU Public License Agreement
     * Written in C and uses GTK+ 1.1.x+ for the GUI
     * Multithreaded to allow for simultaneous downloads
     * File transfer queues to allow for downloading multiple files
     * Extensive connection manager that allows having different
       categories, each containing multiple sites to help manage ftp site
       lists
     * Supports resuming interrupted file transfers
     * Supports associating icons with particular file extensions in the
       listboxes
     * I have some screen shots available: [1]main screen and
       [2]connection manager screenshots are available
       
Changes from 0.1 to 0.2

     * Completely rewritten in gtk instead of Motif
     * Fixed problems with parsing of some directory listings
     * Fixed problems with reading responses from certain FTP servers
     * Supports connecting to a FTP server via command line parameters.
       You can now type: gftp user:pass@ftp-site:port/directory. You
       don't have to specify all of the options, like user:pass, port and
       directory.
     * More informative error messages
     * Sorting capabilites in the listboxes
     * Colorized text in the log window
     * Allows saving the text in the log window to a file
     * Added disconnect from ftp server
     * Various code cleanups
     * Removed about dialog box
       
Requirements

     * gtk+ 1.1.x or higher. You can download gtk+ from
       [3]ftp://ftp.gtk.org/pub/gtk/v1.1. You can download the latest
       version of gtk and you will also need to download the latest glib
       from that same directory.
       
Quick and dirty installation instructions

     * If you do not want to compile this program yourself, you can check
       at the bottom of this page to see if there is a static binary for
       your particular system.
     * After you download the distribution and all all of the libraries
       you need, extract the files from the distribution with tar -zxvf
       gftp-0.2.tar.gz
     * Type make to make a binary for your machine
     * If the compile suceeds without any errors, you can type make
       install to install the binary in /usr/local/bin
       
The config file

     * You will need to make a directory in your home directory called
       .gftp. Once you do this, copy the contents of the sample.gftp
       directory to your ~/.gftp directory. You only have to make one
       change to the gftprc file. The first line has an email= line.
       Please set this to your email address. For example:
       email=foo@bar.org. You will not have to make any other changes to
       the config file unless you want to add anything else yourself.
     * You can register specific file extensions to a XPM file. If you
       want to register a file extension with a particular XPM file, the
       config file line has the following format:
        ext=file extension:xpm file
       The XPM files must be placed in the ~/.gftprc directory. For
       example, I included a file tar.xpm with this distribution, and if
       I would want to associate all .tar files with this icon, I would
       add this to the config file:
        ext=.tar:tar.xpm
     * You can also add hosts for the connection manager to the config
       file. You can add/remove these from within the ftp program inself,
       so you can skip this section if you want to. But if you want to
       add them manually yourself, the line has the following format:
        host=category:host descr:[host]:[port]:[dir]:[user]:[passwd]
       Inside the connection manager, you can have multiple categories,
       that each have multiple hosts associated with them. If you want
       multiple hosts to be contained in the same category, set their
       category name to be EXACTLY the same. The host description will
       show up inside the connection manager, and when you select it, it
       will fill in the host, port, directory, username and password
       fields. If you want your password field to contain your email
       address (i.e. when you're logging in as anonymous), just set your
       passwd field to be @EMAIL@. This allows for users to easily share
       their config files. Here is a few examples:
       
        host=Linux
            Sites:Sunsite:sunsite.unc.edu:21:/pub/Linux:anonymous:@EMAIL@
            host=Linux Sites:GNU
            Archive:prep.ai.mit.edu:21:/pub/gnu:anonymous:@EMAIL@
            host=Linux
            Sites:TSX-11:tsx-11.mit.edu:21:/pub/linux:anonymous:@EMAIL@
            host=X
            Windows:LessTif:ftp.hungry.com:21:/pub/hungry/lesstif:anonymo
            us:@EMAIL@
            host=X Windows:ftp.x.org:ftp.x.org:21:/pub:anonymous:@EMAIL@
            host=X Windows:KDE:ftp.kde.org:21:/pub:anonymous:@EMAIL@
            host=X Windows:Gnome:ftp.gnome.org:21:/pub:anonymous:@EMAIL@
            host=Other:Brian:brian:::brian:password
       
       As you can see from the last entry, some of the fields can be left
       blank. Although the category and host description fields cannot be
       left blank.
     * The last thing that you will have to do to the config file is
       type:
        chmod 0600 ~/.gftp/gftprc
       This will make sure that no one else can read your config file.
       Obviously you do not want other people to be able to see your
       passwords, and gFTP will NOT run if your permissions are set to
       anything else.
       
Precompiled Binaries

     * [4]Source distribution
     * [5]Linux ELF compiled against libc6. This also contains all of the
       source code. Please note: If you run this on a libc5 based system,
       you may experience problems.
     * If you can compile a binary for a system that is not listed,
       please mail it to me and I will post them here. You can type make
       staticdist to make a binary distribution for your particular
       system.
       
   If you like this program, I would appreciate it if you would send me a
   postcard, or even some money. Any money I get will help me develop
   more free software. And finally, I do hope you enjoy using this
   program, as I did enjoyed writing it!
   
   Brian Masney [6]masneyb@newwave.net
   1213 Lake Drive
   Daniels, WV 25832

References

   1. http://www.newwave.net/~masneyb/gftp.gif
   2. http://www.newwave.net/~masneyb/gftp-connmanager.gif
   3. ftp://ftp.gtk.org/pub/gtk/v1.1
   4. http://www.newwave.net/~masneyb/gftp-0.2.tar.gz
   5. http://www.newwave.net/~masneyb/gftp-0.2.i586-unknown-Linux.tar.gz
   6. mailto:masneyb@newwave.net
