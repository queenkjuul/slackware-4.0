/*****************************************************************************/
/*  mkdir_dialog.c - make directory dialog box and ftp routines              */
/*  Copyright (C) 1998 Brian Masney <masneyb@newwave.net>                    */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                */
/*****************************************************************************/

#include "ftp.h"

static void domkdir(GtkWidget *widget, gpointer data);
static void destroy_window(GtkWidget *widget, gpointer data);
static struct ftp_window_data *wdata;
static GtkWidget *edit, *dialog;

void mkdir_dialog(GtkWidget *widget, gpointer data) {
   wdata = (struct ftp_window_data *) data;

  if(wdata->local == -1) {
     ftp_log(LOG_MISC, "Mkdir: Not connected to a remote site\n");
     return;
  }
  edit = MakeEditDialog(&dialog, "Make Directory", "Enter name of directory to create",
      "Create", domkdir, edit,
      "Cancel", destroy_window, NULL);
}
/*****************************************************************************/
static void domkdir(GtkWidget *widget, gpointer data) {
   char edttext[MAXSTR];
   int success;
   
   strncpy(edttext, gtk_entry_get_text(GTK_ENTRY(edit)), sizeof(edttext));
   destroy_window(widget, data);
   if(wdata->local == 1) {
      success = mkdir(edttext, 488) == 0;
      if(!success) {
         ftp_log(LOG_MISC, "Error: Could not make directory %s: %s\n", edttext, sys_errlist[errno]);
      }
      else {
         ftp_log(LOG_MISC, "Successfully made directory %s\n", edttext);
      }
   }
   else success = ftp_mkdir(wdata, wdata->host, edttext);
   if(success) refresh(widget, (gpointer) wdata);
}
/*****************************************************************************/
static void destroy_window(GtkWidget *widget, gpointer data) {
   gtk_grab_remove(dialog);
   gtk_widget_destroy(dialog);
}
/*****************************************************************************/
int ftp_mkdir(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *newdir) {
   if(ftp_sendcommand(1, wdata, hdata, NULL, 0, "MKDIR %s\r\n", newdir) != '2') return(0);
   return(1);
}
/*****************************************************************************/
