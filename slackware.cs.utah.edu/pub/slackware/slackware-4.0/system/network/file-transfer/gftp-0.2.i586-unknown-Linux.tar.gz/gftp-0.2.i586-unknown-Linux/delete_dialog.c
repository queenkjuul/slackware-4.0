/*****************************************************************************/
/*  delete_dialog.c - the delete dialog                                      */
/*  Copyright (C) 1998 Brian Masney <masneyb@newwave.net>                    */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                */
/*****************************************************************************/

#include "ftp.h"

static void askdel(void);
static void yesCB(GtkWidget *widget, gpointer data);
static void noCB(GtkWidget *widget, gpointer data);
static void yesallCB(GtkWidget *widget, gpointer data);
static void noallCB(GtkWidget *widget, gpointer data);

static struct ftp_window_data *wdata;
static int doall, cur, leftitems;
static GtkWidget *dialog;
static struct ftp_file_data *curfle, *prevcurfle;

void delete_dialog(GtkWidget *widget, gpointer data) {
   wdata = (struct ftp_window_data *) data;
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Delete: Not connected to a remote site\n");
      return;
   }
   else if(wdata->numselected == 0) {
      ftp_log(LOG_MISC, "Delete: You must only have at least one item selected\n");
      return;
   }
   doall = 0;
   cur = 0;
   leftitems = wdata->numselected;
   curfle = prevcurfle = wdata->host->files;
   while(!wdata->items[cur]) {
      cur++;
      prevcurfle = curfle;
      curfle = curfle->next;
   }
   askdel();
}
/*****************************************************************************/
static void askdel(void) {
   char tempstr[MAXSTR];

   snprintf(tempstr, sizeof(tempstr), "Are you sure you want to delete %s?", curfle->file);
   tempstr[sizeof(tempstr)-1] = '\0';

   MakeYesNoDialog(&dialog, "Delete Files/Directories", tempstr, 4,
      yesCB, "Yes", NULL,
      noCB, "No", NULL,
      yesallCB, "Yes to All", NULL,
      noallCB, "No to All", NULL);
}
/*****************************************************************************/
static void yesCB(GtkWidget *widget, gpointer data) {
   struct ftp_file_data *tempfle;
   int success, i, skip;
   
   noallCB(widget, data);
   if(wdata->local == 0) {
      if(curfle->attribs[0] == 'd') success = ftp_rmdir(wdata, wdata->host, curfle->file);
      else success = ftp_rmfile(wdata, wdata->host, curfle->file);
   }
   else {
      if(curfle->attribs[0] == 'd') success = rmdir(curfle->file) == 0;
      else success = unlink(curfle->file) == 0;
      if(!success) {
         ftp_log(LOG_MISC, "Error: Could not remove %s %s: %s\n", curfle->attribs[0] == 'd' ? "directory" : "file", curfle->file, sys_errlist[errno]);
      }
      else {
         ftp_log(LOG_MISC, "Successfully removed %s %s\n", curfle->attribs[0] == 'd' ? "directory" : "file", curfle->file, curfle->file);
      }
   }
   if(success) {
      if(prevcurfle == curfle) wdata->host->files = wdata->host->files->next;
      else prevcurfle->next = curfle->next;
      tempfle = curfle;
      curfle = curfle->next;
      gtk_clist_remove(GTK_CLIST(wdata->listbox), cur);
      if(!wdata->items[cur+1]) skip = 1;
      else skip = 0;
      for(i=(skip ? cur+1 : cur); i<wdata->totalitems-1; i++) {
         wdata->items[i] = wdata->items[i+1];
      } 
      wdata->totalitems--;
      free(tempfle);
      if(skip) {
         cur++;
         prevcurfle = curfle;
         curfle = curfle->next;
      }
   }
   else {
      cur++;
      prevcurfle = curfle;
      curfle = curfle->next;
   }
   while(curfle != NULL && !wdata->items[cur]) {
      prevcurfle = curfle;
      curfle = curfle->next;
      cur++;
   }
   if(curfle != NULL && !doall) askdel();
}
/*****************************************************************************/
static void noCB(GtkWidget *widget, gpointer data) {
   noallCB(widget, data);
   cur++;
   prevcurfle = curfle;
   curfle = curfle->next;
   while(curfle != NULL && !wdata->items[cur]) {
      prevcurfle = curfle;
      curfle = curfle->next;
      cur++;
   }
   if(curfle != NULL) askdel();
}
/*****************************************************************************/
static void yesallCB(GtkWidget *widget, gpointer data) {
   doall = 1;
   while(cur < wdata->totalitems) yesCB(widget, data);
}
/*****************************************************************************/
static void noallCB(GtkWidget *widget, gpointer data) {
   gtk_grab_remove(dialog);
   gtk_widget_destroy(dialog);
}
/*****************************************************************************/
int ftp_rmdir(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *dir) {
   if(ftp_sendcommand(1, wdata, hdata, NULL, 0, "RMD %s\r\n", dir) != '2') return(0);
   return(1);
}
/*****************************************************************************/
int ftp_rmfile(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *file) {
   if(ftp_sendcommand(1, wdata, hdata, NULL, 0, "DELE %s\r\n", file) != '2') return(0);
   return(1);
}
/*****************************************************************************/
