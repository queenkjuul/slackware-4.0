/*
 *  qftp
 *  Copyright (C) 1997,1998 Peter Strand
 *  Distributed under the GNU Pulic Licence
 */

#ifndef _MISC_H_
#define _MISC_H_

int procargs(char *, char *[]);
char *split(char *, char *, char *);

#endif
