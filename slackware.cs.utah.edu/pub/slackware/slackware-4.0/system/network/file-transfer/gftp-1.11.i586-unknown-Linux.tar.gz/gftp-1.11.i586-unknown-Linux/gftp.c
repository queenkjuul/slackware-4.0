/*****************************************************************************/
/*  gftp.c - the main user interface for the ftp program                     */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"
#include "options.h"

int main(int argc, char *argv[]) {
   GtkWidget *window, *ui;

#ifdef GNOME
   gnome_init("gFTP", "1.1pre1", argc, argv);
#else
   gtk_init(&argc, &argv);
#endif
   if(argc > 1 && strcmp(argv[1], "--help") == 0) usage();

   read_config_file();
   window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
   gtk_signal_connect(GTK_OBJECT(window), "delete_event", GTK_SIGNAL_FUNC(exitCB), NULL);
   gtk_signal_connect(GTK_OBJECT(window), "destroy", GTK_SIGNAL_FUNC(exitCB), NULL);
   gtk_window_set_title(GTK_WINDOW(window), version);
   
   ui = CreateFTPWindows(window);
   gtk_container_add(GTK_CONTAINER(window), ui);
   gtk_widget_show(window);

   ftp_log(LOG_MISC, "%s, Copyright (C) 1998-1999 Brian Masney <", version);
   ftp_log(LOG_RECV, "masneyb@newwave.net");
   ftp_log(LOG_MISC, ">\nIf you have any questions, comments, or suggestions about this program, please feel free to email them to me.\ngFTP comes with ABSOLUTELY NO WARRANTY; for details, see the COPYING file. ");
   ftp_log(LOG_MISC, "This is free software, and you are welcome to redistribute it under certain conditions; for details, see the COPYING file\n");
   init_gftp(argc, argv, window);
   gtk_widget_show(window);
                
   add_local_files(&window1); 
   gtk_timeout_add(1000, update_downloads, NULL);

   gtk_main();
   return(0);
}  
/*****************************************************************************/
void init_gftp(int argc, char *argv[], GtkWidget *parent) {
   struct pix_ext *tempext;
   GtkWidget *sort_wid;
   struct utsname unme;
   struct passwd *pw;
   struct hostent *hent;

   window1.local = window2.local = -1;
   if(strcmp(emailaddr, "") == 0) {
      /* If there is no email address specified, then we'll just use the
         currentuser@currenthost */
      pw = getpwuid(geteuid());
      uname(&unme);
      if(strchr(unme.nodename, '.')) {
         g_snprintf(emailaddr, sizeof(emailaddr), "%s@%s", pw->pw_name, unme.nodename);
      }
      else {
         hent = gethostbyname(unme.nodename);
         if(hent != NULL) {
            g_snprintf(emailaddr, sizeof(emailaddr), "%s@%s", pw->pw_name, hent->h_name);
         }
         else {
            g_snprintf(emailaddr, sizeof(emailaddr), "%s@%s", pw->pw_name, unme.nodename);
         }
      }
      emailaddr[sizeof(emailaddr)-1] = '\0';
      write_config_file();
   }
                        
   open_xpm("dotdot.xpm", parent, &dotdot_pixmap, &dotdot_mask);
   open_xpm("dir.xpm", parent, &dir_pixmap, &dir_mask);
   open_xpm("linkdir.xpm", parent, &linkdir_pixmap, &linkdir_mask);
   open_xpm("linkfile.xpm", parent, &linkfile_pixmap, &linkfile_mask);
   open_xpm("exe.xpm", parent, &exe_pixmap, &exe_mask);
   open_xpm("doc.xpm", parent, &doc_pixmap, &doc_mask);
   open_xpm("up.xpm", parent, &up_pixmap, &up_mask);
   open_xpm("down.xpm", parent, &down_pixmap, &down_mask);
   
   if(window1.sortasds) sort_wid = gtk_pixmap_new(down_pixmap, down_mask);
   else sort_wid = gtk_pixmap_new(up_pixmap, up_mask);
   gtk_widget_show(sort_wid);
   gtk_clist_set_column_widget(GTK_CLIST(window1.listbox), 0, sort_wid);

   if(window2.sortasds) sort_wid = gtk_pixmap_new(down_pixmap, down_mask);
   else sort_wid = gtk_pixmap_new(up_pixmap, up_mask);
   gtk_widget_show(sort_wid);
   gtk_clist_set_column_widget(GTK_CLIST(window2.listbox), 0, sort_wid);

   tempext = registered_exts;
   while(tempext != NULL) {
      open_xpm(tempext->filename, parent, &tempext->pixmap, &tempext->mask);
      tempext = tempext->next;
   }
   if(argc > 2) usage();
   else if(argc == 2) {
      if(parse_ftp_url(window2.host, argv[1])) {
         fix_display();
         if(ftp_connect(&window2, window2.host, NULL)) {
            ftp_list_files(&window2, 1);
         }
      }
      else usage();
   }
}
/*****************************************************************************/
void usage(void) {
   printf("usage: gftp [[ftp://][user:pass@]ftp-site[:port][/directory]]\n");
   exit(0);
}
/*****************************************************************************/
GtkWidget *CreateFTPWindows(GtkWidget *ui) {
   GtkWidget *putbutton, *retrbutton, *box, *dlbox, *winpane, *dlpane;
   GtkWidget *logpane, *vscrollbar, *mainvbox, *menuitem;
   GtkItemFactory *factory;
   GtkAccelGroup *accel_group;
   char *dltitles[3] = {"Filename", "Progress", "Hostname"};
   GtkItemFactoryEntry menu_items[] = {
      {"/_FTP",			NULL,	0,		0,	"<Branch>"},
      {"/FTP/tearoff",		NULL,	0,		0,	"<Tearoff>"},
      {"/FTP/Ascii", 		NULL, 	change_setting,	5,	"<RadioItem>"},
      {"/FTP/Binary", 		NULL, 	change_setting,	6,	"/FTP/Ascii"},
      {"/FTP/sep", 		NULL, 	0, 		0,	"<Separator>"},
      {"/FTP/Use Cache",	NULL,	change_setting, 0,	"<CheckItem>"},
      {"/FTP/Start Transfers",	NULL,	change_setting, 1,	"<CheckItem>"},
      {"/FTP/Do only one transfer", NULL, change_setting, 2,	"<CheckItem>"},
      {"/FTP/Passive Transfers",NULL,	change_setting,	3,	"<CheckItem>"},
      {"/FTP/Save Geometry",	NULL,	change_setting,	4,	"<CheckItem>"},
      {"/FTP/Sort Dirs First",	NULL,	change_setting, 7,	"<CheckItem>"},
      {"/FTP/Smart Remote Symlinks",	NULL,	change_setting, 8,	"<CheckItem>"},
      {"/FTP/sep", 		NULL, 	0, 		0,	"<Separator>"},
      {"/FTP/_Quit", 		"<control>Q", 	exitCB,	0},
      {"/_Local",		NULL,	0,		0,	"<Branch>"},
      {"/Local/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Local/Change Filespec...", NULL, change_filespec, 0},
      {"/Local/Select All", 	NULL, 	selectall, 	0},
      {"/Local/Select All Files", 	NULL, 	selectallfiles, 	0},
      {"/Local/Deselect All", 	NULL, 	deselectall, 	0},
      {"/Local/sep",		NULL,	0,		0,	"<Separator>"},
      {"/Local/Change Directory", NULL,	chdirfunc, 	0},
      {"/Local/Make Directory...", NULL, mkdir_dialog, 	0},
      {"/Local/Rename...", 	NULL, 	rename_dialog, 	0},
      {"/Local/Delete...", 	NULL, 	delete_dialog, 	0},
      {"/Local/View...",	NULL,	view_dialog,	0},
      {"/Local/Refresh", 	NULL, 	refresh, 	0},
      {"/_Remote",		NULL,	0,		0,	"<Branch>"},
      {"/Remote/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Remote/_Connect...", 	"<control>C", 	connect_dialog, 0},
      {"/Remote/Open URL...",	NULL,	openurl_dialog,	0},
      {"/Remote/_Disconnect", 	"<control>D", 	disconnect, 	0},
      {"/Remote/sep",		NULL,	0,		0,	"<Separator>"},
      {"/Remote/Change Filespec...", NULL, change_filespec, 0},
      {"/Remote/Select All", 	NULL, 	selectall, 	0},
      {"/Remote/Select All Files", 	NULL, 	selectallfiles, 	0},
      {"/Remote/Deselect All", 	NULL, 	deselectall, 	0},
      {"/Remote/sep",		NULL,	0,		0,	"<Separator>"},
      {"/Remote/Change Directory", NULL, chdirfunc, 	0},
      {"/Remote/Make Directory...", NULL, mkdir_dialog,	0},
      {"/Remote/Rename...", 	NULL, 	rename_dialog, 	0},
      {"/Remote/Delete...", 	NULL, 	delete_dialog, 	0},
      {"/Remote/View...",	NULL,	view_dialog,	0},
      {"/Remote/Refresh", 	NULL, 	refresh, 	0},
      {"/_Transfers",		NULL,	0,		0,	"<Branch>"},
      {"/Transfers/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Transfers/Stop Transfer", NULL, stop_transfer,	0},
      {"/Transfers/sep",	NULL,	0,		0,	"<Separator>"},
      {"/Transfers/Retrieve Files", NULL,  retrmenu,	0},
      {"/Transfers/Put Files",	NULL,	putmenu,	0},
      {"/L_ogging",		NULL,	0,		0,	"<Branch>"},
      {"/Logging/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Logging/Clear", 	NULL, 	clearlog, 	0},
      {"/Logging/View log...", 	NULL, 	viewlog, 	0},
      {"/Logging/Save log...", 	NULL, 	savelog, 	0},
      {"/Tool_s",		NULL,	0,		0,	"<Branch>"},
      {"/Tools/tearoff",	NULL,	0,		0,	"<Tearoff>"},
      {"/Tools/Compare Windows", NULL, 	compare_windows,  0}};
      
   mainvbox = gtk_vbox_new(FALSE, 0);
   gtk_widget_show(mainvbox);

   accel_group = gtk_accel_group_new();
   factory = gtk_item_factory_new(GTK_TYPE_MENU_BAR, "<main>", accel_group);

   /* FTP Menu */
   gtk_item_factory_create_items(factory, 14, menu_items, &window2);
   /* Local Menu */
   gtk_item_factory_create_items(factory, 13, menu_items + 14, &window1);
   /* Remote Menu */
   gtk_item_factory_create_items(factory, 17, menu_items + 27, &window2);
   /* Transfers Menu */
   gtk_item_factory_create_items(factory, 6, menu_items + 44, NULL);
   /* Logging Menu */
   gtk_item_factory_create_items(factory, 5, menu_items + 50, NULL);
   /* Tools Menu */
   gtk_item_factory_create_items(factory, 3, menu_items + 55, NULL);
   
   gtk_accel_group_attach(accel_group, GTK_OBJECT(ui));
   gtk_box_pack_start(GTK_BOX(mainvbox), factory->widget, FALSE, FALSE, FALSE);
   gtk_widget_show(factory->widget);

   menuitem = gtk_item_factory_get_widget(factory, menu_items[2].path);
   gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(menuitem), FALSE);

   menuitem = gtk_item_factory_get_widget(factory, menu_items[3].path);
   gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(menuitem), TRUE);

   menuitem = gtk_item_factory_get_widget(factory, menu_items[5].path);
   gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(menuitem), use_cache);

   menuitem = gtk_item_factory_get_widget(factory, menu_items[6].path);
   gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(menuitem), start_file_transfers);

   menuitem = gtk_item_factory_get_widget(factory, menu_items[7].path);
   gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(menuitem), do_one_transfer_at_a_time);

   menuitem = gtk_item_factory_get_widget(factory, menu_items[8].path);
   gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(menuitem), passive_transfer);

   menuitem = gtk_item_factory_get_widget(factory, menu_items[9].path);
   gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(menuitem), save_geometry);

   menuitem = gtk_item_factory_get_widget(factory, menu_items[10].path);
   gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(menuitem), sort_dirs_first);

   menuitem = gtk_item_factory_get_widget(factory, menu_items[11].path);
   gtk_check_menu_item_set_state(GTK_CHECK_MENU_ITEM(menuitem), smart_remote_symlinks);

   winpane = gtk_hpaned_new();
   box = gtk_hbox_new(FALSE, 0);
   window1.local = 1;
   local_frame = CreateFTPWindow(&window1);
   window1.local = -1;

   gtk_box_pack_start(GTK_BOX(box), local_frame, TRUE, TRUE, FALSE);
   gtk_widget_show(local_frame);

   dlbox = gtk_vbox_new(FALSE, 0);
   gtk_container_border_width(GTK_CONTAINER(dlbox), 5);

   putbutton = gtk_button_new_with_label("->");
   gtk_box_pack_start(GTK_BOX(dlbox), putbutton, TRUE, FALSE, FALSE);
   gtk_signal_connect(GTK_OBJECT(putbutton), "clicked", GTK_SIGNAL_FUNC(putCB), (gpointer) NULL);
   gtk_widget_show(putbutton);

   retrbutton = gtk_button_new_with_label("<-");
   gtk_box_pack_start(GTK_BOX(dlbox), retrbutton, TRUE, FALSE, FALSE);
   gtk_signal_connect(GTK_OBJECT(retrbutton), "clicked", GTK_SIGNAL_FUNC(retrCB), (gpointer) NULL);
   gtk_widget_show(retrbutton);

   gtk_box_pack_start(GTK_BOX(box), dlbox, FALSE, FALSE, FALSE);
   gtk_widget_show(dlbox);
   gtk_widget_show(box);
   gtk_paned_add1(GTK_PANED(winpane), box);
   
   remote_frame = CreateFTPWindow(&window2);
   gtk_paned_add2(GTK_PANED(winpane), remote_frame);
   gtk_widget_show(remote_frame);
   gtk_widget_show(winpane);

   dlpane = gtk_vpaned_new();
   gtk_paned_add1(GTK_PANED(dlpane), winpane);

   transfer_scroll = gtk_scrolled_window_new(NULL, NULL);
   gtk_widget_set_usize(transfer_scroll, 1, transfer_height);
   gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(transfer_scroll),
      GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
   dlwdw = gtk_clist_new_with_titles(3, dltitles);
   gtk_container_add(GTK_CONTAINER(transfer_scroll), dlwdw);
   gtk_clist_set_column_width(GTK_CLIST(dlwdw), 0, 100);
   gtk_clist_set_column_width(GTK_CLIST(dlwdw), 1, 250);
   gtk_clist_set_column_width(GTK_CLIST(dlwdw), 2, 100);
   gtk_container_border_width(GTK_CONTAINER(dlwdw), 5);
   gtk_signal_connect(GTK_OBJECT(dlwdw), "select_row", GTK_SIGNAL_FUNC(selectdl), NULL);
   gtk_signal_connect(GTK_OBJECT(dlwdw), "unselect_row", GTK_SIGNAL_FUNC(unselectdl), NULL);
   gtk_paned_add2(GTK_PANED(dlpane), transfer_scroll);
   gtk_widget_show(dlwdw);
   gtk_widget_show(transfer_scroll);
   gtk_widget_show(dlpane);

   logpane = gtk_vpaned_new();
   gtk_paned_add1(GTK_PANED(logpane), dlpane);

   log_table = gtk_table_new(1, 2, FALSE);
   gtk_widget_set_usize(log_table, 1, log_height);
   logwdw = gtk_text_new(NULL, NULL);
   gtk_text_set_editable(GTK_TEXT(logwdw), FALSE);
   gtk_text_set_word_wrap(GTK_TEXT(logwdw), TRUE);
   gtk_table_attach(GTK_TABLE(log_table), logwdw, 0, 1, 0, 1,
      GTK_FILL | GTK_EXPAND, GTK_FILL | GTK_EXPAND | GTK_SHRINK, 0, 0);
   gtk_widget_show(logwdw);

   vscrollbar = gtk_vscrollbar_new (GTK_TEXT(logwdw)->vadj);
   gtk_table_attach(GTK_TABLE(log_table), vscrollbar, 1, 2, 0, 1,
      GTK_FILL, GTK_EXPAND | GTK_FILL | GTK_SHRINK, 0, 0);
   gtk_widget_show(vscrollbar);
   gtk_widget_show(log_table);
   
   gtk_paned_add2(GTK_PANED(logpane), log_table);
   gtk_widget_show(logpane);      
   gtk_box_pack_start(GTK_BOX(mainvbox), logpane, TRUE, TRUE, TRUE);

   return(mainvbox);
}   
/*****************************************************************************/
GtkWidget *CreateFTPWindow(struct ftp_window_data *wdata) {
   char *titles[7] = {"", "Filename", "Size", "User", "Group", "Date", "Attribs"};
   GtkTargetEntry possible_types[] = {
      {"STRING",			0,	0},
      {"text/plain", 			0, 	0},
      {"application/x-rootwin-drop", 	0, 	1}};
   GtkWidget *box, *scroll_list, *parent;

   strncpy(wdata->filespec, "*", sizeof(wdata->filespec));
   wdata->filespec[sizeof(wdata->filespec)-1] = '\0';
   wdata->host = mymalloc(sizeof(struct ftp_host_data));
   wdata->host->files = wdata->host->last = NULL;
   wdata->host->type = FTP_BINARY;
   wdata->host->firewall = use_firewall;
   memset(wdata->host->recvdata.recvdata, 0, MAXSTR);
   wdata->host->recvdata.pos = wdata->host->recvdata.recvdata;
         
   wdata->sortcol = 1;
   wdata->sortasds = 1;
   wdata->totalitems = wdata->numselected = 0;

   parent = gtk_frame_new(NULL);
   gtk_widget_set_usize(parent, wdata->local ? listbox_local_width : listbox_remote_width,
      listbox_file_height);
   gtk_container_border_width(GTK_CONTAINER(parent), 5);

   box = gtk_vbox_new(FALSE, 0);
   gtk_container_border_width(GTK_CONTAINER(box), 5);
   gtk_container_add(GTK_CONTAINER(parent), box);
   
   wdata->diredit = gtk_entry_new_with_max_length(MAXSTR);
   gtk_box_pack_start(GTK_BOX(box), wdata->diredit, FALSE, FALSE, FALSE);
   gtk_signal_connect(GTK_OBJECT(wdata->diredit), "activate", GTK_SIGNAL_FUNC(chdiredit), (gpointer) wdata);
   gtk_widget_show(wdata->diredit);
   
   wdata->hoststxt = gtk_label_new("Not connected");
   gtk_misc_set_alignment(GTK_MISC(wdata->hoststxt), 0, 0);
   gtk_box_pack_start(GTK_BOX(box), wdata->hoststxt, FALSE, FALSE, FALSE);
   gtk_widget_show(wdata->hoststxt);

   scroll_list = gtk_scrolled_window_new(NULL, NULL);
   gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scroll_list),
      GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
   wdata->listbox = gtk_clist_new_with_titles(7, titles);
   gtk_container_add(GTK_CONTAINER(scroll_list), wdata->listbox);
   gtk_drag_source_set(wdata->listbox, GDK_BUTTON2_MASK, possible_types, 3,
      GDK_ACTION_COPY | GDK_ACTION_MOVE);
   gtk_drag_dest_set(wdata->listbox, GTK_DEST_DEFAULT_ALL, possible_types, 2,
      GDK_ACTION_COPY | GDK_ACTION_MOVE);
   gtk_clist_set_selection_mode(GTK_CLIST(wdata->listbox), GTK_SELECTION_EXTENDED);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 0, 16);
   gtk_clist_set_column_justification(GTK_CLIST(wdata->listbox), 0, GTK_JUSTIFY_CENTER);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 1, listbox_filename_width);
   gtk_clist_set_column_justification(GTK_CLIST(wdata->listbox), 2, GTK_JUSTIFY_RIGHT);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 2, 85);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 3, 65);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 4, 65);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 5, 85);
   gtk_clist_set_column_width(GTK_CLIST(wdata->listbox), 6, 65);
   gtk_box_pack_start(GTK_BOX(box), scroll_list, TRUE, TRUE, TRUE);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "click_column", GTK_SIGNAL_FUNC(sortrows), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "select_row", GTK_SIGNAL_FUNC(selectrow), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "unselect_row", GTK_SIGNAL_FUNC(unselectrow), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "button_press_event", GTK_SIGNAL_FUNC(list_dblclick), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "drag_data_get", GTK_SIGNAL_FUNC(listbox_drag), (gpointer) wdata);
   gtk_signal_connect(GTK_OBJECT(wdata->listbox), "drag_data_received", GTK_SIGNAL_FUNC(listbox_get_drag_data), (gpointer) wdata);
   gtk_widget_show(wdata->listbox);
   gtk_widget_show(scroll_list);

   gtk_widget_show(box);
   gtk_widget_show(parent);

   return(parent);
}
/*****************************************************************************/
void listbox_drag(GtkWidget *widget, GdkDragContext *context, GtkSelectionData *selection_data, guint info, guint32 clk_time, gpointer data) {
   struct ftp_window_data *wdata;
   struct ftp_file_data *tempfle;
   char *str = NULL;
   size_t totlen = 0, oldlen;
   char tempstr[MAXSTR];
   
   wdata = (struct ftp_window_data *) data;
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Drag-N-Drop: Not connected to a remote site\n");
      return;
   }
   if(wdata->numselected == 0) {
      ftp_log(LOG_MISC, "Drag-N-Drop: You must have at least one item selected\n");
      return;
   }

   if((tempfle = get_next_selected_filename(wdata->host->files)) == NULL) {
      ftp_log(LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
      return;
   }

   while(tempfle != NULL) {
      if(totlen != 0) totlen--;
      oldlen = totlen;
      if(wdata->local == 1) {
          g_snprintf(tempstr, sizeof(tempstr), "%s/%s\n", wdata->host->dir, tempfle->file);
      }
      else {
         g_snprintf(tempstr, sizeof(tempstr), "ftp://%s:%s@%s:%ld%s/%s\n", 
            wdata->host->user, wdata->host->passwd, wdata->host->host, 
            wdata->host->port == 0 ? 21 : wdata->host->port,
            wdata->host->dir, tempfle->file);
      }
      tempstr[sizeof(tempstr)-1] = '\0';
      remove_double_slashes(tempstr+6);
      totlen += strlen(tempstr)+1;
      str = myrealloc(str, totlen);
      strcpy(str+oldlen, tempstr);
      tempfle = get_next_selected_filename(tempfle->next);
   }

   if(totlen > 1) str[totlen-2] = '\0';
   gtk_selection_data_set(selection_data, selection_data->target, 8,
      str, strlen(str));
   free(str);
}
/*****************************************************************************/
void listbox_get_drag_data(GtkWidget *widget, GdkDragContext *context, gint x, gint y, GtkSelectionData *selection_data, guint info, guint32 clk_time, struct ftp_window_data *wdata) {
   struct ftp_file_data *newfle;
   struct ftp_transfer_data *tdata, *newtdata, *temptdata, *new_file_transfers;
   char *newpos, *oldpos, *pos;
   char tempstr[MAXSTR];
   struct stat st;
   int len, ret, finish_drag;
   
   finish_drag = 0;
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Drag-N-Drop: Not connected to a remote site\n");
      return;
   }
   new_file_transfers = NULL;
   if((selection_data->length >= 0) && (selection_data->format == 8)) {
      if(!wdata->local) {
         tdata = create_new_tdata();
         *tdata->hdata = *(&window2)->host;
         tdata->hdata->files = tdata->hdata->last = NULL;
         tdata->hdata->totalfiles = 0;
         if(wdata->local) {
            tdata->flags |= TRANSFER_DIRECTION;
            tdata->wdata = &window2;
         }
         else {
            tdata->wdata = &window1;
         }
         tdata->curfle = NULL;
         tdata->next = new_file_transfers;
         new_file_transfers = tdata;
      }
      else tdata = NULL;
      oldpos = (char *) selection_data->data;
      while((newpos = strchr(oldpos, '\n')) || (newpos = strchr(oldpos, '\0'))) {
         len = newpos - oldpos + 1 > sizeof(tempstr) ? sizeof(tempstr) : newpos - oldpos + 1;
         strncpy(tempstr, oldpos, len);
         tempstr[len-1] = '\0';
         ret = strncmp(oldpos, "ftp://", 6);
         if(!wdata->local && ret == 0) {
            ftp_log(LOG_MISC, "Drag-N-Drop: Ignoring file %s: Cannot drag a ftp site to a ftp site\n", tempstr);
            if(*newpos == '\0') break;
            oldpos = newpos + 1;
            continue;
         }
         else if(wdata->local && ret != 0) {
            ftp_log(LOG_MISC, "Drag-N-Drop: Ignoring file %s: Cannot drag a local file to the local window\n", tempstr);
            if(*newpos == '\0') break;
            oldpos = newpos + 1;
            continue;
         }
         else {
            newfle = mymalloc(sizeof(struct ftp_file_data));
            if(wdata->local) {
               newtdata = create_new_tdata();
               newtdata->hdata->files = newtdata->hdata->last = NULL;
               newtdata->hdata->totalfiles = 0;
               if(wdata->local) {
                  newtdata->flags |= TRANSFER_DIRECTION;
                  newtdata->wdata = &window2;
               }
               else {
                  newtdata->wdata = &window1;
               }
               newtdata->curfle = NULL;
               newtdata->hdata->type = window2.host->type;
               if(!parse_ftp_url(newtdata->hdata, tempstr)) {
                  ftp_log(LOG_MISC, "Drag-N-Drop: Ignoring url %s: Not a valid url\n", tempstr);
                  if(*newpos == '\0') break;
                  oldpos = newpos + 1;
                  free(newtdata);
                  continue;
               }
               
               pos = strrchr(newtdata->hdata->dir, '/');
               if(pos == NULL) pos = newtdata->hdata->dir;
               if(wdata->local) {
                  strncpy(newfle->remote_file, newtdata->hdata->dir, sizeof(newfle->remote_file));
                  g_snprintf(newfle->file, sizeof(newfle->file), "%s/%s", window1.host->dir, pos);
               }
               else {
                  strncpy(newfle->file, newtdata->hdata->dir, sizeof(newfle->file));
                  g_snprintf(newfle->remote_file, sizeof(newfle->remote_file), "%s/%s", window1.host->dir, pos);
               }
               newfle->remote_file[sizeof(newfle->remote_file)-1] = '\0';
               newfle->file[sizeof(newfle->file)-1] = '\0';
               remove_double_slashes(newfle->file);
               newfle->size = 0;
               *pos = '\0';
               *newtdata->hdata->dir = '\0';
               temptdata = new_file_transfers;
               while(temptdata != NULL) {
                  if(compare_hdata_structs(temptdata->hdata, newtdata->hdata)) {
                     tdata = temptdata;
                     break;
                  }
                  temptdata = temptdata->next;
               }
               if(temptdata == NULL) {
                  newtdata->next = new_file_transfers;
                  new_file_transfers = newtdata;
                  tdata = newtdata;
               }
               else {
                  tdata = temptdata;
                  free(newtdata);
               }
            }
            else {
               stat(tempstr, &st);
               strncpy(newfle->file, tempstr, sizeof(newfle->file));
               newfle->size = st.st_size;
            }
            newfle->next = NULL;
            if(tdata->hdata->last == NULL) tdata->hdata->files = newfle;
            else tdata->hdata->last->next = newfle;
            tdata->hdata->last = newfle;
            tdata->hdata->totalfiles++;
            if(tdata->curfle == NULL) tdata->curfle = newfle;
            finish_drag = 1;
         }
         if(*newpos == '\0') break;
         oldpos = newpos + 1;
      }
   }
   if(finish_drag) {
      temptdata = new_file_transfers;
      while(temptdata != NULL) {
         dotrans(temptdata);
         temptdata = temptdata->next;
      }

      pthread_mutex_lock(&transfer_mutex);
      temptdata = file_transfers;
      if(temptdata == NULL) file_transfers = new_file_transfers;
      else {
         while(temptdata->next != NULL) temptdata = temptdata->next;
         temptdata->next = new_file_transfers;
      }
      pthread_mutex_unlock(&transfer_mutex);
   }
   gtk_drag_finish(context, finish_drag, FALSE, clk_time);
}
/*****************************************************************************/
void sortrows(GtkCList *clist, gint column, gpointer data) {
   struct ftp_file_data *tempfle, *prevfle, *curfle, *dirs, *files;
   struct ftp_window_data *wdata;
   GtkWidget *sort_wid;

   wdata = (struct ftp_window_data *) data;
   if(!wdata->host->files) return;
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Sort: Not connected to a remote site\n");
      return;
   }
   gtk_label_set(GTK_LABEL(wdata->hoststxt), "Sorting...");
   fix_display();
   if(column == 0) {
      wdata->sortasds = !wdata->sortasds;
      column = wdata->sortcol;
      if(wdata->sortasds) sort_wid = gtk_pixmap_new(down_pixmap, down_mask);
      else sort_wid = gtk_pixmap_new(up_pixmap, up_mask);
      gtk_widget_show(sort_wid);
      gtk_clist_set_column_widget(clist, 0, sort_wid);
   }
   else wdata->sortcol = column;
   dirs = files = NULL;
   while(wdata->host->files != NULL) {
      curfle = wdata->host->files;
      wdata->host->files = wdata->host->files->next;
      if(sort_dirs_first && curfle->flags & FILE_ISDIR) tempfle = prevfle = dirs;
      else tempfle = prevfle = files;
      if(column == 1) {
         while(tempfle != NULL && (wdata->sortasds ?
            strcmp(tempfle->file, curfle->file) <= 0 :
            strcmp(tempfle->file, curfle->file) >= 0)) {

            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if(column == 2) {
         while(tempfle != NULL && (wdata->sortasds ? 
            tempfle->size <= curfle->size : 
            tempfle->size >= curfle->size)) {

            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if(column == 3) {
         while(tempfle != NULL && (wdata->sortasds ?
            strcmp(tempfle->user, curfle->user) <= 0 :
            strcmp(tempfle->user, curfle->user) >= 0)) {

            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if(column == 4) {
         while(tempfle != NULL && (wdata->sortasds ?
            strcmp(tempfle->group, curfle->group) <= 0 :
            strcmp(tempfle->group, curfle->group) >= 0)) {

            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if(column == 5) {
         while(tempfle != NULL && (wdata->sortasds ? 
            strcmp(tempfle->sort_time, curfle->sort_time) <= 0 :
            strcmp(tempfle->sort_time, curfle->sort_time) >= 0)) {

            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      else if(column == 6) {
         while(tempfle != NULL && (wdata->sortasds ?
            strcmp(tempfle->attribs, curfle->attribs) <= 0 :
            strcmp(tempfle->attribs, curfle->attribs) >= 0)) {

            prevfle = tempfle;
            tempfle = tempfle->next;
         }
      }
      if(tempfle == NULL || tempfle == prevfle) {
         if(prevfle == tempfle) {
            if(sort_dirs_first && curfle->flags & FILE_ISDIR) {
               curfle->next = dirs;
               dirs = curfle;
            }
            else {
               curfle->next = files;
               files = curfle;
            }
         }
         else {
            curfle->next = NULL;
            prevfle->next = curfle;
         }
      }
      else {            
         curfle->next = prevfle->next;
         prevfle->next = curfle;
      }
   }
   if(dirs == NULL) wdata->host->files = files;
   else {
      tempfle = dirs;
      wdata->host->files = dirs;
      while(tempfle->next != NULL) tempfle = tempfle->next;
      tempfle->next = files;
   }
      
   gtk_clist_freeze(clist);
   deselectall(wdata);
   gtk_clist_clear(clist);
   tempfle = wdata->host->files;
   while(tempfle != NULL) {
      add_file_listbox(wdata, tempfle);
      tempfle = tempfle->next;
   }
   gtk_clist_thaw(clist);
   update_ftp_info(wdata);
}
/*****************************************************************************/
void delete_ftp_file_info(struct ftp_window_data *wdata) {
   gtk_clist_clear(GTK_CLIST(wdata->listbox));
   free_file_list(wdata->host->files);
   wdata->host->last = NULL;
}
/*****************************************************************************/
void queue_log(int type, char *format, ...) {
   struct ftp_log_queue *newlog, *templog;
   char tempstr[MAXSTR];
   va_list argp;
   
   newlog = mymalloc(sizeof(struct ftp_log_queue));
   newlog->type = type;
   va_start(argp, format);
   g_vsnprintf(tempstr, sizeof(tempstr), format, argp);
   tempstr[sizeof(tempstr)-1] = '\0';
   strncpy(newlog->msg, tempstr, sizeof(newlog->msg));
   newlog->next = NULL;
   pthread_mutex_lock(&log_mutex);
   if(file_transfer_logs == NULL) file_transfer_logs = newlog;
   else {
      templog = file_transfer_logs;
      while(templog->next != NULL) templog = templog->next;
      templog->next = newlog;
   }
   pthread_mutex_unlock(&log_mutex);
}
/*****************************************************************************/
void ftp_log(int type, char *format, ...) {
   char tempstr[MAXSTR];
   GdkColormap *cmap;
   GdkColor fore;
   va_list argp;
   guint pos;
   int upd;
   
   upd = GTK_TEXT(logwdw)->vadj->upper - GTK_TEXT(logwdw)->vadj->page_size == GTK_TEXT(logwdw)->vadj->value;
   cmap = gdk_colormap_get_system();
   fore.red = fore.green = fore.blue = 0;
   if(type == LOG_SEND) fore.green = 0x8600;
   else if(type == LOG_RECV) fore.blue = 0xffff;
   else fore.red = 0xffff;
   if(!gdk_color_alloc(cmap, &fore)) g_error("Could not allocate color for log window");
   gtk_text_freeze(GTK_TEXT(logwdw));
   pos = gtk_text_get_length(GTK_TEXT(logwdw));

   va_start(argp, format);
   g_vsnprintf(tempstr, sizeof(tempstr), format, argp);
   tempstr[sizeof(tempstr)-1] = '\0';
   gtk_text_insert(GTK_TEXT(logwdw), NULL, &fore, NULL, tempstr, -1);
   
   gtk_text_set_point(GTK_TEXT(logwdw), pos+strlen(tempstr));
   gtk_text_thaw(GTK_TEXT(logwdw));
   if(upd) {
      gtk_adjustment_set_value(GTK_TEXT(logwdw)->vadj, 
         GTK_TEXT(logwdw)->vadj->upper - GTK_TEXT(logwdw)->vadj->page_size);
   }
   fix_display();
}
/*****************************************************************************/
void update_ftp_info(struct ftp_window_data *wdata) {
   char tempstr[MAXSTR];
   
   if(wdata->local == 1) {
      g_snprintf(tempstr, sizeof(tempstr), "Local [%s]", strcmp(wdata->filespec, "*") == 0 ? "All Files" : wdata->filespec);
      tempstr[sizeof(tempstr)-1] = '\0';
      gtk_label_set(GTK_LABEL(wdata->hoststxt), tempstr);
      gtk_entry_set_text(GTK_ENTRY(wdata->diredit), wdata->host->dir);
   }
   else if(wdata->local == 0) {
      g_snprintf(tempstr, sizeof(tempstr), "%s%s [%s]", wdata->host->host, wdata->cached ? " (Cached)" : "", strcmp(wdata->filespec, "*") == 0 ? "All Files" : wdata->filespec);
      tempstr[sizeof(tempstr)-1] = '\0';
      gtk_label_set(GTK_LABEL(wdata->hoststxt), tempstr);
      gtk_entry_set_text(GTK_ENTRY(wdata->diredit), wdata->host->dir);
   }
   else {
      gtk_label_set(GTK_LABEL(wdata->hoststxt), "Not connected");
      gtk_entry_set_text(GTK_ENTRY(wdata->diredit), "");
   }
   fix_display();
}
/*****************************************************************************/
void change_setting(struct ftp_window_data *wdata, int menuitem, GtkWidget *checkmenu) {
   int state;
   
   state = GTK_CHECK_MENU_ITEM(checkmenu)->active;
   switch(menuitem) {
      case 0 : use_cache = state;
               break;
      case 1 : start_file_transfers = state;
               break;
      case 2 : do_one_transfer_at_a_time = state;
               break;
      case 3 : passive_transfer = state;
               break;
      case 4 : save_geometry = state;
               break;
      case 5 : if(wdata->host) wdata->host->type = FTP_ASCII;
               break;
      case 6 : if(wdata->host) wdata->host->type = FTP_BINARY;
               break;
      case 7 : sort_dirs_first = state;
               break;
      case 8 : smart_remote_symlinks = state;
               break;
   }
}
/*****************************************************************************/
void selectrow(GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data) {
   struct ftp_window_data *wdata;
   struct ftp_file_data *tempfle;
   int i;
   
   wdata = (struct ftp_window_data *) data;
   i = 0;
   tempfle = wdata->host->files;
   while(tempfle != NULL) {
      if(tempfle->flags & FILE_SHOWN) {
         if(i == row) {
            if(!(tempfle->flags & FILE_SELECTED)) wdata->numselected++;
            tempfle->flags |= FILE_SELECTED;
            break;
         }
         i++;
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void unselectrow(GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data) {
   struct ftp_window_data *wdata;
   struct ftp_file_data *tempfle;
   int i;
   
   wdata = (struct ftp_window_data *) data;
   i = 0;
   tempfle = wdata->host->files;
   while(tempfle != NULL) {
      if(tempfle->flags & FILE_SHOWN) {
         if(i == row) {
            if(tempfle->flags & FILE_SELECTED) wdata->numselected--;
            tempfle->flags &= ~(FILE_SELECTED);
            break;
         }
         i++;
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void selectall(struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   int i = 0;
   
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Select All: Not connected to a remote site\n");
      return;
   }
   tempfle = wdata->host->files;
   while(tempfle != NULL) {
      if(tempfle->flags & FILE_SHOWN) {
         if(strcmp(tempfle->file, "..") != 0) {
            gtk_clist_select_row(GTK_CLIST(wdata->listbox), i++, 0);
         }
         else {
            gtk_clist_unselect_row(GTK_CLIST(wdata->listbox), i++, 0);
         }
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void selectallfiles(struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   int i = 0;
   
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Select All Files: Not connected to a remote site\n");
      return;
   }
   tempfle = wdata->host->files;
   while(tempfle != NULL) {
      if(tempfle->flags & FILE_SHOWN) {
         if(tempfle->flags & FILE_ISDIR)  {
            gtk_clist_unselect_row(GTK_CLIST(wdata->listbox), i++, 0);
         }
         else {
            gtk_clist_select_row(GTK_CLIST(wdata->listbox), i++, 0);
         }
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void deselectall(struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   int i = 0;
   
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Deselect All: Not connected to a remote site\n");
      return;
   }
   tempfle = wdata->host->files;
   while(tempfle != NULL) {
      if(tempfle->flags & FILE_SHOWN) {
         gtk_clist_unselect_row(GTK_CLIST(wdata->listbox), i++, 0);
      }
      tempfle = tempfle->next;
   }
}
/*****************************************************************************/
void list_dblclick(GtkWidget *widget, GdkEventButton *event, gpointer data) {
   struct ftp_window_data *wdata;
   struct ftp_file_data *tempfle;
   
   wdata = (struct ftp_window_data *) data;
   if(wdata->local == -1 || wdata->numselected != 1) return;
   if(event->type == GDK_2BUTTON_PRESS) {
      if((tempfle = get_next_selected_filename(wdata->host->files)) == NULL) {
         ftp_log(LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
         return;
      }
      if((!wdata->local && ((tempfle->flags & FILE_ISDIR) || (tempfle->flags & FILE_ISLINK))) ||
         (wdata->local && tempfle->flags & FILE_ISDIR)) chdirfunc(data);
      else view_dialog(data);
   }
}
/*****************************************************************************/
void chdirfunc(struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Chdir: Not connected to a remote site\n");
      return;
   }
   else if(wdata->numselected != 1) {
      ftp_log(LOG_MISC, "Chdir: You must only have one item selected\n");
      return;
   }

   if((tempfle = get_next_selected_filename(wdata->host->files)) == NULL) {
      ftp_log(LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
      return;
   }
   if(wdata->local == 0 && ftp_chdir(wdata, wdata->host, tempfle->file)) {
      update_ftp_info(wdata);
      gtk_clist_freeze(GTK_CLIST(wdata->listbox));
      delete_ftp_file_info(wdata);
      ftp_list_files(wdata, 1);
      gtk_clist_thaw(GTK_CLIST(wdata->listbox));
   }
   else if(wdata->local == 1) {
      if(!chdir(tempfle->file)) {
         ftp_log(LOG_MISC, "Successfully changed local directory to %s\n", tempfle->file);
         update_ftp_info(wdata);
         gtk_clist_freeze(GTK_CLIST(wdata->listbox));
         delete_ftp_file_info(wdata);
         add_local_files(wdata);
         gtk_clist_thaw(GTK_CLIST(wdata->listbox));
      }
      else {
         ftp_log(LOG_MISC, "Could not change %s directory to %s: %s\n", 
            wdata->local == 1 ? "local" : "remote", tempfle->file, g_strerror(errno));
      }
   }
}
/*****************************************************************************/
void chdiredit(GtkWidget *widget, struct ftp_window_data *wdata) {
   char tempstr[MAXSTR];
   
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Chdir: Not connected to a remote site\n");
      return;
   }
   if(!expand_path(gtk_entry_get_text(GTK_ENTRY(wdata->diredit)), tempstr, sizeof(tempstr))) return;
   if(wdata->local == 0 && ftp_chdir(wdata, wdata->host, tempstr)) {
      update_ftp_info(wdata);
      gtk_clist_freeze(GTK_CLIST(wdata->listbox));
      delete_ftp_file_info(wdata);
      ftp_list_files(wdata, 1);
      gtk_clist_thaw(GTK_CLIST(wdata->listbox));
   }
   else if(wdata->local == 1) {
      if(!chdir(tempstr)) {
         ftp_log(LOG_MISC, "Successfully changed local directory to %s\n", tempstr);
         update_ftp_info(wdata);
         gtk_clist_freeze(GTK_CLIST(wdata->listbox));
         delete_ftp_file_info(wdata);
         add_local_files(wdata);
         gtk_clist_thaw(GTK_CLIST(wdata->listbox));
      }
      else {
         ftp_log(LOG_MISC, "Could not change %s directory to %s: %s\n", 
            wdata->local == 1 ? "local" : "remote", tempstr, g_strerror(errno));
      }
   }
}
/*****************************************************************************/
void refresh(struct ftp_window_data *wdata) {
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Refresh: Not connected to a remote site\n");
      return;
   }
   gtk_clist_freeze(GTK_CLIST(wdata->listbox));
   delete_ftp_file_info(wdata);
   if(wdata->local == 0) ftp_list_files(wdata, 0);
   else add_local_files(wdata);
   gtk_clist_thaw(GTK_CLIST(wdata->listbox));
   update_ftp_info(wdata);
}
/*****************************************************************************/
void disconnect(struct ftp_window_data *wdata) {
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Disconnect: Not connected to a remote site\n");
      return;
   }
   ftp_disconnect(wdata, wdata->host, 1);
}
/*****************************************************************************/
void fix_display(void) {
   while(gtk_events_pending()) gtk_main_iteration();
}
/*****************************************************************************/
gint update_downloads(gpointer data) {
   char *add_data[3] = {NULL, NULL, NULL}, *pos;
   struct ftp_transfer_data *temptdata, *prevtdata;
   struct ftp_log_queue *templog;
   char tempstr[MAXSTR];
   struct ftp_window_data *tempwdata;
   pthread_t tid;
   gint num, flag, i;
   
   if(file_transfer_logs != NULL) {
      while(file_transfer_logs != NULL) {
         templog = file_transfer_logs;
         file_transfer_logs = file_transfer_logs->next;
         ftp_log(templog->type, templog->msg);
         free(templog);
      }
   }
   if(file_transfers == NULL) {
      gtk_timeout_add(1000, update_downloads, data);
      return(0);
   }
   else {
      temptdata = prevtdata = file_transfers;
      num = 0;
      pthread_mutex_lock(&transfer_mutex);
      while(temptdata != NULL) {
         if(temptdata->flags & TRANSFER_SHOW) {
            i = 0;
            for(i=0; i<temptdata->num_dirs_to_be_made; i++) {
               if(temptdata->flags & TRANSFER_DIRECTION) {
                  mkdir(temptdata->dirs_to_be_made[i], 488);
               }
               else {
                  ftp_mkdir(temptdata->wdata, temptdata->hdata, temptdata->dirs_to_be_made[i]);
               }
               free(temptdata->dirs_to_be_made[i]);
            }
            free(temptdata->dirs_to_be_made);
            g_snprintf(temptdata->progressstr, sizeof(temptdata->progressstr), "Waiting... (%d file%s)", 
               temptdata->hdata->totalfiles, temptdata->hdata->totalfiles > 1 ? "s" : "");
            temptdata->progressstr[sizeof(temptdata->progressstr)-1] = '\0';
            gtk_clist_insert(GTK_CLIST(dlwdw), num,
               add_data);
            temptdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
            temptdata->flags |= TRANSFER_UPDATE | TRANSFER_CREATED | TRANSFER_NEED_UPDATED;
            temptdata->curfle = temptdata->hdata->files;
         }
         else if(temptdata->flags & TRANSFER_DONE) {
            tempwdata = (temptdata->flags & TRANSFER_DIRECTION) ? &window1 : &window2;
            if((temptdata->flags & TRANSFER_DIRECTION) || compare_hdata_structs(temptdata->hdata, tempwdata->host)) {
               refresh(tempwdata);
            }
            if(temptdata->flags & TRANSFER_CREATED) {
               /* We have to release the mutex because when the list item gets
                  deleted, it will call my deselect function. This func will
                  also lock the mutex */
               pthread_mutex_unlock(&transfer_mutex);
               gtk_clist_remove(GTK_CLIST(dlwdw), num);
               pthread_mutex_lock(&transfer_mutex);
            }

            if(temptdata->flags & TRANSFER_DONE_DO_VIEW) view_file(temptdata->hdata->files->file, 1, 1);

            free_hdata(temptdata->hdata);

            if(temptdata == prevtdata) {
               flag = 1;
               file_transfers = file_transfers->next;
            }
            else {
               flag = 0;
               prevtdata->next = temptdata->next;
            }
            if((temptdata->flags & TRANSFER_STARTED) && (do_one_transfer_at_a_time || file_transfers == NULL)) transfer_in_progress = 0;
            free(temptdata);
            if(flag) temptdata = prevtdata = file_transfers;
            else temptdata = prevtdata->next;
            continue;
         }

         if((temptdata->curfle != NULL) && (temptdata->flags & (TRANSFER_UPDATE | TRANSFER_NEED_UPDATED))) {
            if(!(temptdata->flags & TRANSFER_STARTED) && start_file_transfers && (!do_one_transfer_at_a_time || (do_one_transfer_at_a_time && !transfer_in_progress))) {
               temptdata->curfle = temptdata->hdata->files;
               transfer_in_progress = 1;
               temptdata->flags |= TRANSFER_STARTED;
               if(temptdata->flags & TRANSFER_DIRECTION) pthread_create(&tid, NULL, &ftp_get_files, temptdata);  
               else pthread_create(&tid, NULL, &ftp_put_files, temptdata);
            }            

            pos = strrchr(temptdata->curfle->file, '/');
            if(pos == NULL) pos = temptdata->curfle->file;
            else pos++;
            gtk_clist_set_text(GTK_CLIST(dlwdw), num, 0, pos);

            gtk_clist_set_text(GTK_CLIST(dlwdw), num, 1, temptdata->progressstr);

            g_snprintf(tempstr, sizeof(tempstr), "%s%s", temptdata->hdata->host, temptdata->hdata->dir);
            tempstr[sizeof(tempstr)-1] = '\0';
            gtk_clist_set_text(GTK_CLIST(dlwdw), num, 2, tempstr);
            temptdata->flags &= ~(TRANSFER_NEED_UPDATED);
         }
         num++;
         prevtdata = temptdata;
         temptdata = temptdata->next;
      }
      pthread_mutex_unlock(&transfer_mutex);
   }
   gtk_timeout_add(1000, update_downloads, data);
   return(0);
}
/*****************************************************************************/
void selectdl(GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data) {
   struct ftp_transfer_data *tdata;
   int i;
   
   tdata = file_transfers;
   if(tdata == NULL) return;
   for(i=0; i<row; i++) {
      tdata = tdata->next;
      if(tdata == NULL) return;
   }
   pthread_mutex_lock(&transfer_mutex);
   tdata->flags |= TRANSFER_SELECTED;
   pthread_mutex_unlock(&transfer_mutex);
}
/*****************************************************************************/
void unselectdl(GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data) {
   struct ftp_transfer_data *tdata;
   int i;
   
   tdata = file_transfers;
   if(tdata == NULL) return;
   for(i=0; i<row; i++) {
      tdata = tdata->next;
      if(tdata == NULL) return;
   }
   pthread_mutex_lock(&transfer_mutex);
   tdata->flags &= ~(TRANSFER_SELECTED);
   pthread_mutex_unlock(&transfer_mutex);
}
/*****************************************************************************/
void stop_transfer(GtkWidget *widget, gpointer data) {
   struct ftp_transfer_data *temptdata;

   if(file_transfer_logs != NULL) {
      ftp_log(LOG_MISC, "There are currently no file transfers in progress to stop\n");
      return;
   }
   pthread_mutex_lock(&transfer_mutex);
   temptdata = file_transfers;
   while(temptdata != NULL) {
      if(temptdata->flags & TRANSFER_SELECTED) {
         temptdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
         temptdata->flags |= (temptdata->flags & TRANSFER_STARTED) ? TRANSFER_CANCEL : TRANSFER_DONE;
         ftp_log(LOG_MISC, "Stopping the transfer of %s\n", temptdata->curfle->file);
      }
      temptdata = temptdata->next;
   }
   pthread_mutex_unlock(&transfer_mutex);
}
/*****************************************************************************/
int compare_hdata_structs(struct ftp_host_data *hdata1, struct ftp_host_data *hdata2) {
   if(hdata1->port == hdata2->port && strcmp(hdata1->host, hdata2->host) == 0 &&
      strcmp(hdata1->user, hdata2->user) == 0 && strcmp(hdata1->passwd, hdata2->passwd) == 0 &&
      strcmp(hdata1->dir, hdata2->dir) == 0) return(1);
   else return(0);
}
/*****************************************************************************/
void compare_windows(gpointer data) {
   struct ftp_file_data *curfle, *tempfle;
   gint num;

   if(window2.local == -1) {
      ftp_log(LOG_MISC, "Compare Windows: Not connected to a remote site\n");
      return;
   }
   
   deselectall(&window1);
   deselectall(&window2);
   
   /* Select the items in Window1 that aren't in Window2 */
   curfle = window1.host->files;
   num = 0;
   while(curfle != NULL) {
      tempfle = window2.host->files;
      if(!(curfle->flags & FILE_ISDIR)) {
         while(tempfle != NULL) {
            if(strcmp(tempfle->file, curfle->file) == 0 && tempfle->size == curfle->size) {
               break;
            }
            tempfle = tempfle->next;
         }
      }
      if(tempfle == NULL) gtk_clist_select_row(GTK_CLIST(window1.listbox), num, 0);
      num++;
      curfle = curfle->next;
   }

   /* Select the items in Window2 that aren't in Window1 */
   curfle = window2.host->files;
   num = 0;
   while(curfle != NULL) {
      tempfle = window1.host->files;
      if(!(curfle->flags & FILE_ISDIR)) {
         while(tempfle != NULL) {
            if(strcmp(tempfle->file, curfle->file) == 0 && tempfle->size == curfle->size) {
               break;
            }
            tempfle = tempfle->next;
         }
      }
      if(tempfle == NULL) gtk_clist_select_row(GTK_CLIST(window2.listbox), num, 0);
      num++;
      curfle = curfle->next;
   }
}
/*****************************************************************************/
