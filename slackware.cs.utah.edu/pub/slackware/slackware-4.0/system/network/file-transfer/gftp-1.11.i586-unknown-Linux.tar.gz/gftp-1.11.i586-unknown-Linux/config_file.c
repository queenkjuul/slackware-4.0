/*****************************************************************************/
/*  config_file.c - config file routines                                     */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

extern struct conn_categories *hostcat;
extern struct pix_ext *registered_exts;
extern char emailaddr[MAXSTR];
extern char firewall_host[MAXSTR], firewall_username[MAXSTR], firewall_password[MAXSTR];
extern int use_cache, use_firewall, firewall_port, start_file_transfers, do_one_transfer_at_a_time,
           listbox_local_width, listbox_remote_width, listbox_file_height,
           transfer_height, log_height, save_geometry, passive_transfer,
           listbox_filename_width, sort_dirs_first, smart_remote_symlinks,
           view_log_after_login_fail;

struct config_vars {
   char descr[30], type;
   void *var;
   int len;
   char comment[MAXSTR];
}; 

struct config_vars config_file_vars[] = {
   {"email", 'C', emailaddr, sizeof(emailaddr), "# (*) Enter your email address here"},
   {"usecache", 'I', &use_cache, 0, "# Do you want to use the cache?"},
   {"passive_transfer", 'I', &passive_transfer, 0, "# Send PASV command or PORT command for data transfers"},
   {"start_transfers", 'I', &start_file_transfers, 0, "# Automatically start the file transfers when they get queued?"},
   {"one_transfer", 'I', &do_one_transfer_at_a_time, 0, "# Do only one transfer at a time?"},
   {"sort_dirs_first", 'I', &sort_dirs_first, 0, "# Put the directories first then the files"},
   {"smart_remote_symlinks", 'I', &smart_remote_symlinks, 0, "# Set this if you want gFTP to try to resolve remote symlinks"},
   {"usefirewall", 'I', &use_firewall, 0, "# (*) Connect to the ftp server via a FTP Proxy.\n# 0 = Disable firewall support\n# 1 = Login firewall via SITE command\n# 2 = Login firewall via USER/PASS"},
   {"firewall_host", 'C', firewall_host, sizeof(firewall_host), "# (*) Firewall hostname"},
   {"firewall_port", 'I', &firewall_port, 0, "# (*) Port to connect to on the firewall"},
   {"firewall_username", 'C', firewall_username, sizeof(firewall_username), "# (*) Your firewall username"},
   {"firewall_password", 'C', firewall_password, sizeof(firewall_password), "# (*) Your firewall password"},
   {"save_geometry", 'I', &save_geometry, 0, "# Save the size of each widget for next startup"},
   {"listbox_local_width", 'I', &listbox_local_width, 0, "# The default width of the local files listbox"},
   {"listbox_remote_width", 'I', &listbox_remote_width, 0, "# The default width of the remote files listbox"},
   {"listbox_file_height", 'I', &listbox_file_height, 0, "# The default height of the local/remote files listboxes"},
   {"transfer_height", 'I', &transfer_height, 0, "# The default height of the transfer listbox"},
   {"log_height", 'I', &log_height, 0, "# The default height of the logging window"},
   {"filename_width", 'I', &listbox_filename_width, 0, "# (*) The width of the filename column in the file listboxes"},
   {"view_log_on_login_fail", 'I', &view_log_after_login_fail, 0, "# (*) Will view the session log after a login failure"},
   {"", 0, NULL}};

void read_config_file(void) {
   struct conn_categories *newcat, *tempcat, *prevcat;
   struct conn_hosts *newhost, *temphost, *prevhost;
   struct pix_ext *tempext;
   char tempstr[MAXSTR], temp1str[MAXSTR], category[MAXSTR], *curpos;
   FILE *conffile;
   int line=0, pos;
   
   hostcat = NULL;
   newhost = NULL;
   registered_exts = NULL;
   if(!expand_path(CONFIG_FILE, tempstr, sizeof(tempstr))) {
      printf("gFTP Error: Bad config file name %s\n", CONFIG_FILE);
      exit(0);
   }
   if(access(tempstr, F_OK) == -1) {
      expand_path(BASE_CONF_DIR, temp1str, sizeof(temp1str));
      if(access(temp1str, F_OK) == -1) {
         if(mkdir(temp1str, 488) != 0) {
            printf("gFTP Error: Could not make directory %s: %s\n", temp1str, g_strerror(errno));
            exit(-1);
         }
      }
      g_snprintf(temp1str, sizeof(temp1str), "%s/gftprc", SHARE_DIR);
      temp1str[sizeof(temp1str)-1] = '\0';
      if(access(temp1str, F_OK) == -1) {
         printf("gFTP Error: Cannot find master config file %s\n", temp1str);
         printf("Did you do a make install?\n");
         exit(-1);
      }
      copyfile(temp1str, tempstr);
      chmod(tempstr, S_IRUSR | S_IWUSR);
   }
   chmod(tempstr, S_IRUSR | S_IWUSR);
   conffile = fopen(tempstr, "r");
   if(conffile == NULL) {
      printf("gFTP Error: Cannot open config file %s: %s\n", CONFIG_FILE, g_strerror(errno));
      exit(0);
   }
   while(fgets(tempstr, sizeof(tempstr), conffile)) {
      if(tempstr[strlen(tempstr)-1] == '\n') {
         tempstr[strlen(tempstr)-1] = '\0';
         if(tempstr[strlen(tempstr)-2] == '\r') tempstr[strlen(tempstr)-2] = '\0';
      }
      line++;
      pos = 0;
      while(config_file_vars[pos].var != NULL) {
         if(strncmp(config_file_vars[pos].descr, tempstr, strlen(config_file_vars[pos].descr)) == 0) {
            curpos = tempstr + strlen(config_file_vars[pos].descr) + 1;
            if(config_file_vars[pos].type == 'C') {
               strncpy(config_file_vars[pos].var, curpos, config_file_vars[pos].len);
               ((char *) config_file_vars[pos].var)[config_file_vars[pos].len-1] = '\0';
               break;
            }
            else {
               *(int *) config_file_vars[pos].var = strtol(curpos, (char **) NULL, 10);
               break;
            }
         }
         pos++;
      }
      if(strncmp(tempstr, "host=", 5) == 0) {
         newhost = mymalloc(sizeof(struct conn_hosts));
         curpos = tempstr+5;
         parse_args(curpos, 8, line,
            category, sizeof(category),
            newhost->hostdescr, sizeof(newhost->hostdescr),
            newhost->hostname, sizeof(newhost->hostname),
            newhost->port, sizeof(newhost->port),
            newhost->dir, sizeof(newhost->dir),
            newhost->user, sizeof(newhost->user),
            newhost->pass, sizeof(newhost->pass),
            newhost->firewall, sizeof(newhost->firewall));
         newhost->next = NULL;
         if(newhost->firewall[0] == '\0') newhost->firewall[0] = '1';
         if(newhost->user[0] == '\0') {
            strncpy(newhost->user, ANON_LOGIN, sizeof(newhost->user));
            newhost->user[sizeof(newhost->user)-1] = '\0';
         }
         if(newhost->pass[0] == '\0') {
            strncpy(newhost->pass, "@EMAIL@", sizeof(newhost->pass));
            newhost->pass[sizeof(newhost->pass)-1] = '\0';
         }
         if(strcmp(category, "") == 0 || strcmp(newhost->hostdescr, "") == 0) {
            printf("gFTP Error: Error in config file on line %d: You must specify a category and a host\ndescription.\n", line);
            exit(0);
         }
         tempcat = prevcat = hostcat;          
         while(tempcat != NULL) {
            if(strcmp(tempcat->name, category) == 0) {
               temphost = prevhost = tempcat->hosts;
               while(temphost != NULL) {
                  if(strcmp(temphost->hostdescr, newhost->hostdescr) > 0) {
                     newhost->next = temphost;
                     if(temphost == prevhost) tempcat->hosts = newhost;
                     else prevhost->next = newhost;
                     break;
                  }
                  else {
                     prevhost = temphost;
                     temphost = temphost->next;
                  }
               }
               if(temphost == NULL) {
                  prevhost->next = newhost;
                  newhost->next = NULL;
               }
               break;
            }
            else if(strcmp(tempcat->name, category) > 0) {
               newcat = mymalloc(sizeof(struct conn_categories));
               newcat->next = tempcat;
               if(prevcat == tempcat) hostcat = newcat;
               else prevcat->next = newcat;
               strncpy(newcat->name, category, sizeof(newcat->name));
               newcat->name[sizeof(newcat->name)-1] = '\0';
               newcat->hosts = newhost;
               break;
            }
            prevcat = tempcat;
            tempcat = tempcat->next;
         }
         if(tempcat == NULL) {
            newcat = mymalloc(sizeof(struct conn_categories));
            if(hostcat == NULL) {
               newcat->next = hostcat;
               hostcat = newcat;
            }
            else {
               newcat->next = prevcat->next;;
               prevcat->next = newcat;
            }
            strncpy(newcat->name, category, sizeof(newcat->name));
            newcat->name[sizeof(newcat->name)-1] = '\0';
            newcat->hosts = newhost;
         }
      }
      else if(strncmp(tempstr, "ext=", 4) == 0) {
         curpos = tempstr+4;
         tempext = mymalloc(sizeof(struct pix_ext));
         parse_args(curpos, 2, line, 
            tempext->ext, sizeof(tempext->ext),
            tempext->filename, sizeof(tempext->filename));
         g_snprintf(tempstr, sizeof(tempstr), "%s/%s", SHARE_DIR, tempext->filename);
         tempstr[sizeof(tempstr)-1] = '\0';
         if(!expand_path(tempstr, temp1str, sizeof(temp1str))) {
            printf("gFTP Error: Bad file name %s in config file on line %d\n", tempext->filename, line);
            exit(0);
         }
         if(access(temp1str, F_OK) != 0) {
            g_snprintf(tempstr, sizeof(tempstr), "%s/%s", BASE_CONF_DIR, tempext->filename);
            tempstr[sizeof(tempstr)-1] = '\0';
            if(!expand_path(tempstr, temp1str, sizeof(temp1str))) {
               printf("gFTP Error: Bad file name %s in config file on line %d\n", tempext->filename, line);
               exit(0);
            }
            if(access(temp1str, F_OK) != 0) {
               printf("gFTP Error: Error on line %d: %s doesn't exist in %s or %s\n", line, tempext->filename, SHARE_DIR, BASE_CONF_DIR);
               exit(0);
            }
         }
         tempext->stlen = strlen(tempext->ext);
         tempext->next = registered_exts;
         registered_exts = tempext;
      }         
      else if(config_file_vars[pos].var == NULL && *tempstr != '#' && *tempstr != '\0') {
         printf("gFTP Warning: Skipping line %d in config file\n", line);
      }
   }
   return;
}
/*****************************************************************************/
void write_config_file(void) {
   struct conn_categories *tempcat;
   struct conn_hosts *temphost;
   struct pix_ext *tempext;
   char tempstr[MAXSTR];
   FILE *conffile;
   int pos;

   if(!expand_path(CONFIG_FILE, tempstr, sizeof(tempstr))) {
      printf("gFTP Error: Bad config file name %s\n", CONFIG_FILE);
      exit(0);
   }
   conffile = fopen(tempstr, "w+");
   if(conffile == NULL) {
      printf("gFTP Error: Cannot open config file %s: %s\n", CONFIG_FILE, g_strerror(errno));
      exit(0);
   }
   
   g_snprintf(tempstr, sizeof(tempstr), "# Config file for gFTP\n# Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);
   g_snprintf(tempstr, sizeof(tempstr), "# Warning: Any comments that you add to this file WILL be overwritten\n# If a entry has a (*) in it's comment, you can't change it inside gFTP\n\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);

   pos = 0;
   while(config_file_vars[pos].var != NULL) {
      fwrite(config_file_vars[pos].comment, 1, strlen(config_file_vars[pos].comment), conffile);
      fwrite("\n", 1, 1, conffile);
      if(config_file_vars[pos].type == 'C') {
         g_snprintf(tempstr, sizeof(tempstr), "%s=%s\n", 
            config_file_vars[pos].descr, (char *) config_file_vars[pos].var);
      }
      else {
         g_snprintf(tempstr, sizeof(tempstr), "%s=%d\n", 
            config_file_vars[pos].descr, *(int *) config_file_vars[pos].var);
      }
      tempstr[sizeof(tempstr)-1] = '\0';
      fwrite(tempstr, 1, strlen(tempstr), conffile);
      fwrite("\n", 1, 1, conffile);
      pos++;
   }

   g_snprintf(tempstr, sizeof(tempstr), "# host=Category:Host Descr:hostname:port:start dir:username:password:firewall\n# If you set the password to @EMAIL@, gFTP will automatically change that to\n# your email address.\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);
   g_snprintf(tempstr, sizeof(tempstr), "# If you set the firewall argument to 1, gFTP will try to connect to your\n# FTP proxy if you have one. It is usually best to leave this set at 1 because\n# gFTP won't use it if you don't have a FTP proxy\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);
   tempcat = hostcat;
   while(tempcat != NULL) {
      temphost = tempcat->hosts;
      while(temphost != NULL) {
         g_snprintf(tempstr, sizeof(tempstr), "host=%s:%s:%s:%s:%s:%s:%s:%c\n", tempcat->name, 
            temphost->hostdescr, temphost->hostname, temphost->port, temphost->dir, 
            temphost->user, temphost->pass, temphost->firewall[0]);
         tempstr[sizeof(tempstr)-1] = '\0';
         fwrite(tempstr, 1, strlen(tempstr), conffile);
         temphost = temphost->next;
      }
      tempcat = tempcat->next;
   }
   
   g_snprintf(tempstr, sizeof(tempstr), "\n# ext=file extenstion:XPM file\n");
   tempstr[sizeof(tempstr)-1] = '\0';
   fwrite(tempstr, 1, strlen(tempstr), conffile);
   tempext = registered_exts;
   while(tempext != NULL) {
      g_snprintf(tempstr, sizeof(tempstr), "ext=%s:%s\n", tempext->ext, tempext->filename);
      tempstr[sizeof(tempstr)-1] = '\0';
      fwrite(tempstr, 1, strlen(tempstr), conffile);
      tempext = tempext->next;
   }
   fclose(conffile);
}
/*****************************************************************************/
int copyfile(char *source, char *dest) {
   FILE *srcfd, *destfd;
   char buf[8192];
   size_t n;
   
   srcfd = fopen(source, "rb");
   if(srcfd == NULL) {
      return(0);
   }
   
   destfd = fopen(dest, "wb");
   if(destfd == NULL) {
      fclose(srcfd);
      return(0);
   }
   
   while((n = fread(buf, 1, sizeof(buf), srcfd)) > 0) {
      fwrite(buf, 1, n, destfd);
   }
   fclose(srcfd);
   fclose(destfd);
   return(1);
}
/*****************************************************************************/
int parse_args(char *str, int numargs, int lineno, char *first, ...) {
   char *curpos, *endpos, *dest;
   va_list argp;
   size_t len, newlen;
   int ret = 1;
   
   va_start(argp, first);
   curpos = str;
   
   dest = first;
   len = va_arg(argp, size_t);
   memset(dest, 0, len);
   while(numargs > 1) {
      endpos = strchr(curpos, ':');
      if(endpos == NULL) {
         printf("gFTP Warning: Line %d doesn't have enough arguments\n", lineno);
         ret = 0;
         break;
      }
      newlen = endpos-curpos+1 > len ? len : endpos-curpos+1;
      strncpy(dest, curpos, newlen);
      dest[newlen-1] = '\0';
      curpos = endpos + 1;
      dest = va_arg(argp, char *);
      len = va_arg(argp, size_t);
      memset(dest, 0, len);
      numargs--;
   }
   newlen = strlen(curpos) > len ? len : strlen(curpos)+1;
   strncpy(dest, curpos, newlen);
   dest[newlen-1] = '\0';
   va_end(argp);
   while(numargs > 1) {
      dest = va_arg(argp, char *);
      len = va_arg(argp, size_t);
      memset(dest, 0, len);
      numargs--;
   }
   return(1);
}
/*****************************************************************************/
