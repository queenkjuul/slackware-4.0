/*****************************************************************************/
/*  ftp.h - include file for the whole ftp program                           */
/*  Copyright (C) 1998 Brian Masney <masneyb@newwave.net>                    */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                */
/*****************************************************************************/

#ifndef __FTP_H
#define __FTP_H
#define _POSIX_SOURCE
#define _REENTRANT
#include <pthread.h>
#ifdef GNOME
   #include <gnome.h>
#else
   #include <gtk/gtk.h>
#endif
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <ctype.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/utsname.h>
#include <errno.h>

/* Some general settings */
#define BASE_CONF_DIR		"~/.gftp"
#define CONFIG_FILE		BASE_CONF_DIR "/gftprc"
#define FTP_ASCII               0
#define FTP_BINARY              1
#define MAXSTR			255
#define ANON_LOGIN		"anonymous"

/* These are the different colors for the logging window */
#define LOG_SEND		1 << 0
#define LOG_RECV		1 << 1
#define LOG_MISC		1 << 2

#define FILE_ISDIR		1 << 0 /* Is this a dir? */
#define FILE_ISEXE		1 << 1 /* Is this executable? */
#define FILE_ISLINK		1 << 2 /* Is this a symlink? */
#define FILE_RESTART		1 << 3 /* Are we going to restart this file
                                          transfer */
#define FILE_SHOWN		1 << 4 /* Is this file shown in the listbox */
#define FILE_SELECTED		1 << 5 /* Is this file selected */

#define TRANSFER_DOALL		1 << 0 /* For the Resume all/Overwrite all 
                                          buttons */
#define TRANSFER_OP             1 << 1 /* If the file exists, will we resume the 
                                          transfer (1) or just overwrite it (0) */
#define TRANSFER_DIRECTION      1 << 2 /* Are we dling (1) or uploading (0) */
#define TRANSFER_CREATED	1 << 3 /* This will be set when an entry is made 
                                          in the listbox for this file transfer. */
#define TRANSFER_SELECTED	1 << 4 /* Whether this item is selected in the 
                                          listbox or not */
#define TRANSFER_STARTED	1 << 5 /* Are we transfering these files? */
#define TRANSFER_NEW		1 << 6 /* We create a new structure...don't show or
                                          create it yet */
#define TRANSFER_SHOW		1 << 7 /* We can now show the transfer and start it
                                          if we can */
#define TRANSFER_UPDATE		1 << 8 /* Just update the status of the file 
                                          transfer */
#define TRANSFER_CANCEL		1 << 9 /* Cancel this transfer */
#define TRANSFER_DONE		1 << 10 /* Done with this transfer */
#define TRANSFER_DONE_DO_VIEW	1 << 11 /* When done, view this file */
#define TRANSFER_NEED_UPDATED	1 << 12 /* This will be set when we update the
                                           transfer status */
#define TRANSFER_SKIP_SAME	1 << 13 /* Skip the files that are the same on
                                           the remote and local computer */

#define FIREWALL_LOGIN_SITE	1 /* We have to issue the SITE cmd to
                                     login the firewall so we can
                                     login into the ftp server */
#define FIREWALL_LOGIN_USERPASS 2 /* We have to issue USER and PASS cmd
                                     to login the firewall so we can
                                     login into the ftp server */

struct ftp_file_data {
   /* File information */
   char file[MAXSTR], user[9], group[9], attribs[11], dt[15], strsize[20], 
        sort_time[20], remote_file[MAXSTR];
   unsigned long size, /* File size */
                 remote_size; /* Size of the remote file */
   unsigned int flags; /* Our flags for this file. See the FILE_* flags above */
   struct ftp_file_data *next; /* Our next file */
};

/* This is for the ftp_read_line() function. This stores the extra data for
   the next line that hasn't been read yet. */

struct ftp_queued_data {
   char recvdata[MAXSTR], /* Data read from the ftp server */
        *pos; /* Our current position in the recvdata field */
};

/* This structure will be contained in the ftp_window_data structure below.
   This should contain all of the information that will be needed about a 
   remote site. This structure will also be contained inside the 
   ftp_transfer_data structure for the multiple downloads. */
   
struct ftp_host_data {
   int type, /* Download type: FTP_BINARY, FTP_ASCII */
       totalfiles, /* How many files are here */
       totaldirs, /* How many directories are here */
       sockfd, /* Our socket descriptor */
       firewall; /* Are you going to connect through the firewall? */
   char host[MAXSTR], /* Current host (if any) connected to */
        user[MAXSTR], /* Our username */
        passwd[MAXSTR], /* Our password */
        dir[MAXSTR]; /* Our current directory */
   long port; /* Current port (if any) we are connected on */
   struct ftp_file_data *files, /* All of the files in the current directory */
                        *last; /* This is the last file. This makes it easier
                                  for adding files to the end of the list */
   struct ftp_queued_data recvdata; /* Our data being read */
};

/* There will be 2 of these created...one for the local side and one for the 
   remote side. When all of the callbacks are created, the proper structure
   will be passed to the function */
   
struct ftp_window_data {
   GtkWidget *diredit, /* Edit box for the user to enter a directory */
             *hoststxt, /* Show which directory we're in */
             *listbox, /* Our listbox showing the files */
             *logwdw, /* The text widget for logging */
             *dlwdw; /* The list widget for showing our downloads */
   int local, /* -1 = Not Connected, 0 = Remote, 1 = Local */
       totalitems,  /* How many items are in our list */
       numselected, /* How many items are selected in the list */
       sortcol, /* Which column we are sorting by */
       sortasds, /* Sorting ascending or descending */
       cached; /* Was this directory listing loaded from the cache or not */
   char filespec[20];
   struct ftp_host_data *host; /* The host that we are connected to */
};         

/* This will be the structure used for each thread in transfering files */

struct ftp_transfer_data {
   struct ftp_window_data *wdata;
   struct ftp_host_data *hdata; /* The host that we are connecting to */
   struct ftp_file_data *curfle, /* The current file that we are transferring */
                        *prevfle; /* The previous file in the list */
   struct ftp_transfer_data *next;
   unsigned long curtrans, /* How much of the file we actually transferred */
                 flags; /* Our flags. See the TRANSFER_* flags above */
   time_t starttime; /* The time that we started the transfer */
   char progressstr[MAXSTR], /* String to be displayed in the listbox under
                                the progress column */
        **dirs_to_be_made;
   int num_dirs_to_be_made;
};

/* This will be for queueing messages to the logging window. This will be
   used for the threads, since gtk is not thread safe, we cannot update the
   display inside the threads */
   
struct ftp_log_queue {
   char msg[MAXSTR]; /* Our message */
   int type; /* Logging type. LOG_MISC, LOG_SEND, or LOG_RECV */
   struct ftp_log_queue *next;
};

/* For registering file formats */

struct pix_ext {
   char ext[20], /* The file extension to register */
        filename[MAXSTR]; /* The xpm file to display */
   int stlen; /* How long is the file extension. */
   GdkPixmap *pixmap; /* Our pixmap */
   GdkBitmap *mask; /* Mask for the pixmap */
   struct pix_ext *next; /* Next file extension */
};

/* These next two are for the connection manager */

struct conn_hosts { /* This will be a host underneath a category */
   char hostdescr[MAXSTR], /* Our host description to be shown in the combo box */
        hostname[MAXSTR], /* Our actual internet hostname */
        dir[MAXSTR], /* Initial directory */
        user[MAXSTR], /* Username to log in as */
        pass[MAXSTR], /* Our password */
        port[6], /* Port to connect to */
        firewall[2]; /* Connect through the firewall? */
   struct conn_hosts *next; /* Next host in this category */
};

struct conn_categories { /* Each category will have one of these nodes */
   char name[MAXSTR]; /* Our category name */
   struct conn_hosts *hosts; /* Our hosts underneath this category */
   struct conn_categories *next; /* Our next category */
};


/* cache.c */
FILE *new_cache_entry(char *description);
FILE *find_cache_entry(char *description);
void clear_cache_files(void);

/* config_file.c */
void read_config_file(void);
void write_config_file(void);
int copyfile(char *source, char *dest);
int parse_args(char *str, int numargs, int lineno, char *first, ...);

/* connect_dialog.c */
void connect_dialog(struct ftp_window_data *wdata);
void openurl_dialog(struct ftp_window_data *wdata);

/* delete_dialog.c */
void delete_dialog(gpointer data);
int ftp_rmdir(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *dir);
int ftp_rmfile(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *file);

/* file_transfer.c */
void retrCB(GtkWidget *widget, gpointer data);
void retrmenu(gpointer data);
void putCB(GtkWidget *widget, gpointer data);
void putmenu(gpointer data);
void dotrans(struct ftp_transfer_data *tdata);
struct ftp_transfer_data *create_new_tdata(void);
void *ftp_get_files(void *ptr);
void *ftp_put_files(void *ptr);

/* ftp.c */
int ftp_connect(struct ftp_window_data *wdata, struct ftp_host_data *hdata, struct ftp_transfer_data *tdata);
int ftp_init_data_conn(struct ftp_window_data *wdata, struct ftp_host_data *hdata);
int ftp_accept_port_conn(struct ftp_window_data *wdata, struct ftp_host_data *hdata, int datafd);
int ftp_disconnect(struct ftp_window_data *wdata, struct ftp_host_data *hdata, int log);
int ftp_list_files(struct ftp_window_data *wdata, int usecache);
struct ftp_file_data *get_remote_files(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *path, int *total, int load_from_cache, int log, GtkLabel *up_wid);
char *ftp_pwd(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *dir, int len, int log);
int ftp_read_line(int sockfd, struct ftp_queued_data *qdata, char *buf, int size);
char ftp_sendcommand(int log, struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *destbuf, size_t destlen, char *command, ...);
char ftp_read_response(int log, struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *buf, size_t len);
int ftp_chdir(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *newdir);

/* gtp.c */
void init_gftp(int argc, char *argv[], GtkWidget *parent);
void usage(void);
GtkWidget *CreateFTPWindows(GtkWidget *ui);
GtkWidget *CreateFTPWindow(struct ftp_window_data *wdata);
void listbox_drag(GtkWidget *widget, GdkDragContext *context, GtkSelectionData *selection_data, guint info, guint32 time, gpointer data);
void listbox_get_drag_data(GtkWidget *widget, GdkDragContext *context, gint x, gint y, GtkSelectionData *selection_data, guint info, guint32 time, struct ftp_window_data *wdata);
void sortrows(GtkCList *clist, gint column, gpointer data);
void delete_ftp_file_info(struct ftp_window_data *wdata);
void queue_log(int type, char *format, ...);
void ftp_log(int type, char *format, ...);
void update_ftp_info(struct ftp_window_data *wdata);
void change_setting(struct ftp_window_data *wdata, int menuitem, GtkWidget *checkmenu);
void selectrow(GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data);
void unselectrow(GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data);
void selectall(struct ftp_window_data *wdata);
void selectallfiles(struct ftp_window_data *wdata);
void deselectall(struct ftp_window_data *wdata);
void list_dblclick(GtkWidget *widget, GdkEventButton *event, gpointer data);
void chdirfunc(struct ftp_window_data *wdata);
void chdiredit(GtkWidget *widget, struct ftp_window_data *wdata);
void refresh(struct ftp_window_data *wdata);
void disconnect(struct ftp_window_data *wdata);
void fix_display(void);
gint update_downloads(gpointer data);
void selectdl(GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data);
void unselectdl(GtkCList *clist, gint row, gint column, GdkEventButton *event, gpointer data);
void stop_transfer(GtkWidget *widget, gpointer data);
int compare_hdata_structs(struct ftp_host_data *hdata1, struct ftp_host_data *hdata2);
void compare_windows(gpointer data);
void show_flags(unsigned long flags);

/* misc.c */
void *mymalloc(size_t size);
void *myrealloc(void *ptr, size_t size);
char *insert_commas(unsigned long number, char *dest, int size);
void add_local_files(struct ftp_window_data *win);
struct ftp_file_data *get_local_files(char *path, int *total);
void add_file_listbox(struct ftp_window_data *wdata, struct ftp_file_data *fle);
long file_countlf(FILE *filefd, long endpos);
char *alltrim(char *str);
int ftp_parse_file_listing(struct ftp_file_data *fle, char *str);
int expand_path(char *src, char *dest, size_t size);
void remove_double_slashes(char *string);
char *make_temp_filename(char *destbuf, int size);
void free_file_list(struct ftp_file_data *filelist);
void free_hdata(struct ftp_host_data *hdata);
int match_filename_wildcard(char *filename, char *wildcard);
struct ftp_file_data *get_next_selected_filename(struct ftp_file_data *filelist);
int parse_ftp_url(struct ftp_host_data *hdata, char *url);
void open_xpm(char *filename, GtkWidget *parent, GdkPixmap **pixmap, GdkBitmap **mask);

/* misc_dialogs.c */
GtkWidget *MakeEditDialog(char *diagtxt, char *infotxt,
   char *oktxt, void (*okfunc)(), void *okptr,
   char *canceltxt, void (*cancelfunc)(), void *cancelptr);
GtkWidget *MakeYesNoDialog(char *diagtxt, char *infotxt, int num, ...);
void delete_modal_dialog(GtkWidget *widget, gpointer data);
void change_filespec(struct ftp_window_data *wdata);
void dochange_filespec(GtkWidget *widget, struct ftp_window_data *wdata);
void exitCB(gpointer data);
void doexit(GtkWidget *widget, gpointer data);
void viewlog(gpointer data);
void savelog(gpointer data);
void dosavelog(GtkWidget *widget, GtkFileSelection *fs);
void savelog_destroy(GtkWidget *widget, GtkWidget *dialog);
void clearlog(gpointer data);

/* mkdir_dialog.c */
void mkdir_dialog(gpointer data);
int ftp_mkdir(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *newdir);

/* rename_dialog.c */
void rename_dialog(gpointer data);
int ftp_rename(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *from, char *to);

/* view_dialog.c */
void view_dialog(gpointer data);
void view_file(char *filename, int del_file, int start_pos);

#endif
