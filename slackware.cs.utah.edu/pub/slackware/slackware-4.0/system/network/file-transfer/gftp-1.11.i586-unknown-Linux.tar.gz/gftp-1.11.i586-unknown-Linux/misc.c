/*****************************************************************************/
/*  misc.c - general purpose routines                                        */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

extern GdkPixmap *dotdot_pixmap, *dir_pixmap, *linkdir_pixmap, *linkfile_pixmap,
   *exe_pixmap, *doc_pixmap;
extern GdkBitmap *dotdot_mask, *dir_mask, *linkdir_mask, *linkfile_mask, 
   *exe_mask, *doc_mask;
extern struct pix_ext *registered_exts;
extern char emailaddr[MAXSTR];

void *mymalloc(size_t size) {
   void *mem;
   
   if((mem = malloc(size)) == NULL) {
      printf("\nError allocating memory. gFTP will be shut down\n");
      exit(0);
   }
   memset(mem, 0, size);
   return(mem);
}
/*****************************************************************************/
void *myrealloc(void *ptr, size_t size) {
   void *mem;
   
   if((mem = realloc(ptr, size)) == NULL) {
      printf("\nError allocating memory. gFTP will be shut down\n");
      exit(0);
   }
   else return(mem);
}
/*****************************************************************************/
char *insert_commas(unsigned long number, char *dest, int size) {
   char *frompos, *topos;
   char src[MAXSTR];
   int num, rem, i;
   
   g_snprintf(src, sizeof(src), "%ld", number);
   src[sizeof(src)-1] = '\0';
   num = strlen(src) / 3 - 1;
   rem = strlen(src) % 3;
   if(strlen(src) + num + (rem == 0 ? 0 : 1) + 1 > size) {
      if(strlen(src) < size) strncpy(dest, src, size);
      else memset(dest, 'X', size-1);
      dest[size-1] = '\0';
      return(dest);
   }
   frompos = src;
   topos = dest;
   for(i=0; i<rem; i++) *topos++ = *frompos++;
   if(*frompos != '\0') {
      if(rem != 0) *topos++ = ',';
      while(num > 0) {
         for(i=0; i<3; i++) *topos++ = *frompos++;
         *topos++ = ',';
         num--;
      }
      for(i=0; i<3; i++) *topos++ = *frompos++;
   }
   *topos = '\0';
   return(dest);
}
/*****************************************************************************/
void add_local_files(struct ftp_window_data *wdata) {
   char tempstr[MAXSTR];

   gtk_clist_freeze(GTK_CLIST(wdata->listbox));
   wdata->local = 1;
   wdata->cached = 0;
   wdata->totalitems = wdata->numselected = 0;
   wdata->host->files = get_local_files(NULL, &wdata->totalitems);

   strncpy(wdata->host->dir, getcwd(tempstr, sizeof(tempstr)), sizeof(wdata->host->dir));
   wdata->host->dir[sizeof(wdata->host->dir)-1] = '\0';
   update_ftp_info(wdata);

   sortrows(GTK_CLIST(wdata->listbox), wdata->sortcol, (gpointer) wdata);
   gtk_clist_thaw(GTK_CLIST(wdata->listbox));
}
/*****************************************************************************/
struct ftp_file_data *get_local_files(char *path, int *total) {
   struct ftp_file_data *files, *newfle, *lastfle;
   char tempstr[MAXSTR], curdir[MAXSTR];
   int isdotdot = 0;
   struct stat st;
   FILE *dir;
   
   *total = 0;
   if(path != NULL) {
      if(getcwd(curdir, sizeof(curdir)) == NULL) return(NULL);
      if(chdir(path) == -1) return(NULL);
   }
   files = lastfle = NULL;
   dir = popen("/bin/ls -al", "r");
   while(fgets(tempstr, sizeof(tempstr), dir)) {
      tempstr[strlen(tempstr)-1] = '\0';
      newfle = mymalloc(sizeof(struct ftp_file_data));
      if(ftp_parse_file_listing(newfle, tempstr) && strcmp(newfle->file, ".") != 0) {
         if(strcmp(newfle->file, "..") == 0) isdotdot = 1;
         stat(newfle->file, &st);
         newfle->flags = 0;
         if(S_ISDIR(st.st_mode)) newfle->flags |= FILE_ISDIR;
         if(newfle->attribs[0] == 'l') newfle->flags |= FILE_ISLINK;
         if((strchr(newfle->attribs, 'x') != NULL) && !(newfle->flags & FILE_ISDIR)
            && !(newfle->flags & FILE_ISLINK)) newfle->flags |= FILE_ISEXE;
         newfle->next = NULL;
         if(lastfle == NULL) files = newfle;
         else lastfle->next = newfle;
         lastfle = newfle;  
         (*total)++;
      }
      else free(newfle);
   }
   pclose(dir);
   if(!isdotdot && strcmp(path, "/") != 0) {
      newfle = mymalloc(sizeof(struct ftp_file_data));
      strcpy(newfle->file, "..");
      newfle->size = 0;
      newfle->user[0] = newfle->group[0] = newfle->attribs[0] = newfle->dt[0] = '\0';
      newfle->next = NULL;
      newfle->flags = FILE_ISDIR;
      if(lastfle == NULL) files = newfle;
      else lastfle->next = newfle;
      (*total)++;
   }
   if(path != NULL) chdir(curdir);
   return(files);
}
/*****************************************************************************/
void add_file_listbox(struct ftp_window_data *wdata, struct ftp_file_data *fle) {
   char *add_data[7] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL};
   struct pix_ext *tempext;
   size_t stlen;
   gint num;

   if(match_filename_wildcard(fle->file, wdata->filespec)) {
      fle->flags |= FILE_SHOWN;
   }
   else {
      fle->flags &= ~(FILE_SHOWN | FILE_SELECTED);
      return;
   }
   stlen = strlen(fle->file);
   num = gtk_clist_append(GTK_CLIST(wdata->listbox), add_data);
   if(fle->flags & FILE_SELECTED) {
      gtk_clist_select_row(GTK_CLIST(wdata->listbox), num, 0);
      wdata->numselected++;
   }
   if(strcmp(fle->file, "..") == 0) {
      gtk_clist_set_pixmap(GTK_CLIST(wdata->listbox), num, 0, dotdot_pixmap, dotdot_mask);
   }
   else if((fle->flags & FILE_ISLINK) && (fle->flags & FILE_ISDIR)) {
      gtk_clist_set_pixmap(GTK_CLIST(wdata->listbox), num, 0, linkdir_pixmap, linkdir_mask);
   }
   else if(fle->flags & FILE_ISLINK) {
      gtk_clist_set_pixmap(GTK_CLIST(wdata->listbox), num, 0, linkfile_pixmap, linkfile_mask);
   }
   else if(fle->flags & FILE_ISDIR) {
      gtk_clist_set_pixmap(GTK_CLIST(wdata->listbox), num, 0, dir_pixmap, dir_mask);
   }
   else if(fle->flags & FILE_ISEXE) {
      gtk_clist_set_pixmap(GTK_CLIST(wdata->listbox), num, 0, exe_pixmap, exe_mask);
   }
   else {
      tempext = registered_exts;
      while(tempext != NULL) {
         if(stlen >= tempext->stlen &&
            strcmp(&fle->file[stlen-tempext->stlen], tempext->ext) == 0) {

            gtk_clist_set_pixmap(GTK_CLIST(wdata->listbox), num, 0, tempext->pixmap, tempext->mask);
            break;
         }
         tempext = tempext->next;
      }
      if(tempext == NULL) {
         gtk_clist_set_pixmap(GTK_CLIST(wdata->listbox), num, 0, doc_pixmap, doc_mask);
      }
   }
   gtk_clist_set_text(GTK_CLIST(wdata->listbox), num, 1, fle->file);
   gtk_clist_set_text(GTK_CLIST(wdata->listbox), num, 2, fle->strsize);
   gtk_clist_set_text(GTK_CLIST(wdata->listbox), num, 3, fle->user);
   gtk_clist_set_text(GTK_CLIST(wdata->listbox), num, 4, fle->group);
   gtk_clist_set_text(GTK_CLIST(wdata->listbox), num, 5, fle->dt);
   gtk_clist_set_text(GTK_CLIST(wdata->listbox), num, 6, fle->attribs);
}
/*****************************************************************************/
long file_countlf(FILE *filefd, long endpos) {
   char tempstr[MAXSTR];
   long num = 0, curpos, mypos;
   size_t n;
   int i;
            
   curpos = ftell(filefd);
   fseek(filefd, 0, SEEK_SET);
   mypos = 0;
   while((n=fread(tempstr, 1, sizeof(tempstr), filefd)) > 0) {
      for(i=0; i<n; i++) {
         if((tempstr[i] == '\n') && (i > 0) && (tempstr[i-1] != '\r')
            && (endpos == 0 || mypos+i <= endpos)) ++num;
      }
      mypos += n;
   }
   fseek(filefd, curpos, SEEK_SET);
   return(num);
}
/*****************************************************************************/
char *alltrim(char *str) {
   char *pos, *newpos;
   int diff;

   pos = str+strlen(str);
   while(*pos == ' ') *pos-- = '\0';
   
   pos = str;
   diff = 0;
   while(*pos++ == ' ') diff++;

   pos = str+diff;
   newpos = str;
   while(*pos != '\0') *newpos++ = *pos++;
   *newpos = '\0';
   return(str);
}
/*****************************************************************************/
int ftp_parse_file_listing(struct ftp_file_data *fle, char *str) {
   char *startpos, *endpos, *datepos, tempstr[20];
   struct tm *curtime;
   time_t t;
   int len, year = 0, month = 0, day = 0, hour = 0, min = 0;

   startpos = str;
   if((endpos = strchr(startpos, ' ')) == NULL) return(0);
   len = endpos - startpos > sizeof(fle->attribs) ? sizeof(fle->attribs) : endpos - startpos + 1;
   strncpy(fle->attribs, startpos, len);
   fle->attribs[len-1] = '\0';
   
   startpos = endpos + 1;
   while(*startpos == ' ') startpos++;
   if(*startpos == '\0') return(0);
   if((startpos = strchr(startpos, ' ')) == NULL) return(0);
   while(*startpos == ' ') startpos++;
   
   if((endpos = strchr(startpos, ' ')) == NULL) return(0);
   len = endpos - startpos > sizeof(fle->user) ? sizeof(fle->user) : endpos - startpos + 1;
   strncpy(fle->user, startpos, len);
   fle->user[len-1] = '\0';

   startpos = endpos + 1;
   while(*startpos == ' ') startpos++;
   if(*startpos == '\0') return(0);
   if((endpos = strchr(startpos, ' ')) == NULL) return(0);
   len = endpos - startpos > sizeof(fle->group) ? sizeof(fle->group) : endpos - startpos + 1;
   strncpy(fle->group, startpos, len);
   fle->group[len-1] = '\0';

   startpos = endpos + 1;
   while(*startpos == ' ') startpos++;
   if(*startpos == '\0') return(0);
   if(fle->attribs[0] == 'b' || fle->attribs[0] == 'c') {
      if((endpos = strchr(startpos, ',')) == NULL) return(0);
      endpos++;
      while(*endpos == ' ') endpos++;
      if(*endpos == '\0') return(0);
      if((endpos = strchr(endpos, ' ')) == NULL) return(0);
   }
   else {
      if((endpos = strchr(startpos, ' ')) == NULL) return(0);
   }
   len = endpos - startpos > sizeof(tempstr) ? sizeof(tempstr) : endpos - startpos + 1;
   strncpy(tempstr, startpos, len);
   tempstr[len-1] = '\0';
   if(fle->attribs[0] == 'b' || fle->attribs[0] == 'c') {
      fle->size = 0;
      strncpy(fle->strsize, tempstr, sizeof(fle->strsize));
      fle->strsize[sizeof(fle->strsize)-1] = '\0';
   }
   else {
      fle->size = strtol(tempstr, (char **) NULL, 10);
      insert_commas(fle->size, fle->strsize, sizeof(fle->strsize));
   }
   
   startpos = endpos + 1;
   while(*startpos == ' ') startpos++;
   if(*startpos == '\0') return(0);
   if((endpos = strchr(startpos, ' ')) == NULL) return(0);
   while(*endpos == ' ') endpos++;
   if(*endpos == '\0') return(0);
   if((endpos = strchr(endpos, ' ')) == NULL) return(0);
   while(*endpos == ' ') endpos++;
   if(*endpos == '\0') return(0);
   if((endpos = strchr(endpos, ' ')) == NULL) return(0);
   len = endpos - startpos > sizeof(fle->dt) ? sizeof(fle->dt) : endpos - startpos + 1;
   strncpy(fle->dt, startpos, len);
   fle->dt[len-1] = '\0';

   strncpy(tempstr, fle->dt, sizeof(tempstr));
   tempstr[sizeof(tempstr)-1] = '\0';
   t = time(NULL);
   curtime = localtime(&t);
   datepos = tempstr;
   /* Parse the month */
   if(strncmp(tempstr, "Jan", 3) == 0) month = 1;
   else if(strncmp(tempstr, "Feb", 3) == 0) month = 2;
   else if(strncmp(tempstr, "Mar", 3) == 0) month = 3;
   else if(strncmp(tempstr, "Apr", 3) == 0) month = 4;
   else if(strncmp(tempstr, "May", 3) == 0) month = 5;
   else if(strncmp(tempstr, "Jun", 3) == 0) month = 6;
   else if(strncmp(tempstr, "Jul", 3) == 0) month = 7;
   else if(strncmp(tempstr, "Aug", 3) == 0) month = 8;
   else if(strncmp(tempstr, "Sep", 3) == 0) month = 9;
   else if(strncmp(tempstr, "Oct", 3) == 0) month = 10;
   else if(strncmp(tempstr, "Nov", 3) == 0) month = 11;
   else if(strncmp(tempstr, "Dec", 3) == 0) month = 12;
   else month = 0;

   datepos = tempstr+3;
   while(*datepos == ' ') datepos++;
   if(*datepos != '\0') {
      /* Parse the day */
      day = strtol(datepos, (char **) NULL, 10);

      while(*datepos != ' ') datepos++;
      while(*datepos == ' ' && *datepos != '\0') datepos++;

      /* Parse the year */
      if(*datepos != '\0') {
         if(strchr(tempstr, ':') != NULL) {
            year = curtime->tm_year+1900;
         }
         else {
            year = strtol(datepos, (char **) NULL, 10);
            while(*datepos != ' ') datepos++;
            while(*datepos == ' ' && *datepos != '\0') datepos++;
         }
         if(*datepos != '\0') {
            /* Now parse the time */
            if(strchr(tempstr, ':') == NULL) {
               hour = min = 0;
            }
            else {
               hour = strtol(datepos, (char **) NULL, 10);
               while(*datepos != ':' && *datepos != '\0') datepos++;
               if(*datepos != '\0' && *datepos++ != '\0') {
                  min = strtol(datepos, (char **) NULL, 10);
               }
            }
         }
      }
   }
   g_snprintf(fle->sort_time, sizeof(fle->sort_time), "%04d%02d%02d%02d%02d",
      year, month, day, hour, min);
   fle->sort_time[sizeof(fle->sort_time)-1] = '\0';
   
   startpos = endpos + 1;
   while(*startpos == ' ') startpos++;
   if(*startpos == '\0') return(0);
   len = endpos - startpos > sizeof(fle->file) ? sizeof(fle->file) : endpos - startpos + 1;
   strncpy(fle->file, startpos, len);
   fle->file[len-1] = '\0';
   if(fle->attribs[0] == 'l') {
      startpos = strchr(fle->file, '-');
      while(startpos != NULL) {
         if(*(startpos+1) == '>' && *(startpos-1) == ' ') {
            *(startpos-1) = '\0';
            break;
         }
         startpos = strchr(startpos+1, '-');
      }
   }
   return(1);
}
/*****************************************************************************/
int expand_path(char *src, char *dest, size_t size) {
   struct passwd *pw;
   char tempstr[20];
   char *pos;
   
   if(strcmp(src, "~") == 0 || strncmp(src, "~/", 2) == 0) pw = getpwuid(geteuid());
   else if(strncmp(src, "~", 1) == 0) {
      pos = strchr(src, '/');
      if(pos == NULL) {
         strncpy(tempstr, src+1, sizeof(tempstr));
         tempstr[sizeof(tempstr)-1] = '\0';
      }
      else {
         strncpy(tempstr, src+1, pos-src+1);
         tempstr[pos-src+1] = '\0';
      }
      pw = getpwnam(tempstr);
   }
   else {
      strncpy(dest, src, size);
      dest[size-1] = '\0';
      return(1);
   }
   
   if(pw == NULL) {
      *dest = '\0';
      return(0);
   }
   pos = strchr(src, '/');
   if(pos == NULL) {
      strncpy(dest, pw->pw_dir, size);
      dest[size-1] = '\0';
      return(1);
   }
   pos++;
   g_snprintf(dest, size, "%s/%s", pw->pw_dir, pos);
   dest[size-1] = '\0';
   return(1);
}
/*****************************************************************************/
void remove_double_slashes(char *string) {
   char *newpos, *oldpos;
   
   oldpos = newpos = string;
   while(*oldpos != '\0') {
      *newpos++ = *oldpos++;
      if(*oldpos == '\0') break;
      while(*(newpos-1) == '/' && *(oldpos) == '/') oldpos++;
   }
   *newpos = '\0';
}
/*****************************************************************************/
char *make_temp_filename(char *destbuf, int size) {
   char tempstr[MAXSTR];
   
   expand_path(BASE_CONF_DIR "/temp", tempstr, sizeof(tempstr));
   if(access(tempstr, F_OK) == -1) mkdir(tempstr, 0x1C0);

   srand(time(NULL));
   g_snprintf(destbuf, size, "%s/temp%ld", tempstr, 1+(long) (99999999.0*rand()/(RAND_MAX+1.0)));
   destbuf[size-1] = '\0';
   while(access(destbuf, F_OK) != -1) {
      g_snprintf(destbuf, size, "%s/temp%ld", tempstr, 1+(long) (99999999.0*rand()/(RAND_MAX+1.0)));
      destbuf[size-1] = '\0';
   }
   return(destbuf);
}
/*****************************************************************************/
void free_file_list(struct ftp_file_data *filelist) {
   struct ftp_file_data *tempfle;
   
   while(filelist != NULL) {
      tempfle = filelist;
      filelist = filelist->next;
      free(tempfle);
   }
}
/*****************************************************************************/
void free_hdata(struct ftp_host_data *hdata) {
   free_file_list(hdata->files);
   free(hdata);
}
/*****************************************************************************/
int match_filename_wildcard(char *filename, char *wildcard) {
   char *filepos, *wcpos, *pos, *newpos, search_str[20];
   int len;
   
   filepos = filename;
   wcpos = wildcard;
   if(*filepos == '\0' || *wcpos == '\0') return(0);
   while(1) {
      if(*wcpos == '\0') return(1);
      else if(*filepos == '\0') return(0);
      else if(*wcpos == '?') {
         wcpos++;
         filepos++;
      }
      else if(*wcpos == '*' && *(wcpos+1) == '\0') return(1);
      else if(*wcpos == '*') {
         pos = wcpos+1;
         newpos = search_str;
         while(*pos != '*' && *pos != '\0') *newpos++ = *pos++;
         *newpos = '\0';
         len = strlen(search_str);
         filepos = strstr(filepos, search_str);
         if(filepos == NULL) return(0);
         wcpos += len + 1;
         filepos += len;
      }
      else if(*wcpos++ != *filepos++) return(0);
   }
}
/*****************************************************************************/
struct ftp_file_data *get_next_selected_filename(struct ftp_file_data *filelist) {
   struct ftp_file_data *tempfle;
   
   tempfle = filelist;
   while(tempfle != NULL) {
      if((tempfle->flags & FILE_SHOWN) && (tempfle->flags & FILE_SELECTED)) {
         return(tempfle);
      }
      tempfle = tempfle->next;
   }
   return(NULL);
}
/*****************************************************************************/
int parse_ftp_url(struct ftp_host_data *hdata, char *url) {
   char tempstr[MAXSTR], *pos, *endpos;
   int len;

   hdata->port = 0;
   hdata->host[0] = hdata->dir[0] = '\0';
   strncpy(hdata->user, ANON_LOGIN, sizeof(hdata->user));
   hdata->user[sizeof(hdata->user)-1] = '\0';
   strncpy(hdata->passwd, emailaddr, sizeof(hdata->passwd));
   hdata->passwd[sizeof(hdata->passwd)-1] = '\0';
   pos = url;
   if(strncmp(pos, "ftp://", 6) == 0) pos += 6;
   if(strchr(pos, '@') != NULL) {
      /* A user/password was entered */
      if((endpos = strchr(pos, ':')) == NULL) return(0);
      len = endpos - pos + 1 > sizeof(hdata->user) ? sizeof(hdata->user) : endpos - pos + 1;
      strncpy(hdata->user, pos, len);
      hdata->user[len-1] = 0;

      pos = endpos+1;
      if((endpos = strchr(pos, '@')) == NULL) return(0);
      if(strchr(endpos+1, '@') != NULL) endpos = strchr(endpos+1, '@');
      len = endpos - pos + 1 > sizeof(hdata->passwd) ? sizeof(hdata->passwd) : endpos - pos + 1;
      strncpy(hdata->passwd, pos, len);
      hdata->passwd[len-1] = 0;
      pos = endpos+1;
   }
   /* Now get the hostname and an optional port and optional directory */
   if((endpos = strchr(pos, ':')) != NULL) {
      len = endpos - pos + 1 > sizeof(hdata->host) ? sizeof(hdata->host) : endpos - pos + 1;
   }
   else if((endpos = strchr(pos, '/')) != NULL) {
      len = endpos - pos + 1 > sizeof(hdata->host) ? sizeof(hdata->host) : endpos - pos + 1;
   }
   else len = sizeof(hdata->host);
   strncpy(hdata->host, pos, len);
   hdata->host[len-1] = 0;
   if((endpos = strchr(pos, ':')) != NULL) {
      /* A port was entered */
      pos = endpos + 1;
      if((endpos = strchr(pos, '/')) != NULL) {
         len = endpos - pos + 1 > sizeof(tempstr) ? sizeof(tempstr) : endpos - pos + 1;
      }
      g_snprintf(tempstr, len, pos);
      tempstr[len-1] = 0;
      hdata->port = strtol(pos, (char **) NULL, 10);
   }
   if((endpos = strchr(pos, '/')) != NULL) {
      strncpy(hdata->dir, endpos, sizeof(hdata->dir));
      hdata->dir[sizeof(hdata->dir)-1] = '\0';
   }
   return(1);
}
/*****************************************************************************/
void open_xpm(char *filename, GtkWidget *parent, GdkPixmap **pixmap, GdkBitmap **mask) {
   char tempstr[MAXSTR], temp1str[MAXSTR];
   GtkStyle *style;

   style = gtk_widget_get_style(parent);
   g_snprintf(temp1str, sizeof(temp1str), "%s/%s", SHARE_DIR, filename);
   temp1str[sizeof(temp1str)-1] = '\0';
   expand_path(temp1str, tempstr, sizeof(tempstr));
   if(access(tempstr, F_OK) != 0) {
      g_snprintf(temp1str, sizeof(temp1str), "%s/%s", BASE_CONF_DIR, filename);
      temp1str[sizeof(temp1str)-1] = '\0';
      expand_path(temp1str, tempstr, sizeof(tempstr));
      if(access(tempstr, F_OK) != 0) {
         printf("gFTP Error: Cannot find file %s in %s or %s\n", filename, SHARE_DIR, BASE_CONF_DIR);
         exit(-1);
      }
   }
   *pixmap = gdk_pixmap_create_from_xpm(parent->window, mask, &style->bg[GTK_STATE_NORMAL], tempstr);
   if(*pixmap == NULL) {
      printf("gFTP Error: Error opening file %s\n", tempstr);
      exit(-1);
   }
}
/*****************************************************************************/
