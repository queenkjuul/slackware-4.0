/*****************************************************************************/
/*  file_transfer.c - contains the ui and network routines for file transfer */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

extern struct ftp_transfer_data *file_transfers;
extern pthread_mutex_t transfer_mutex;
extern struct ftp_window_data window1, window2;
extern int use_firewall, passive_transfer;

static GtkWidget *ovr_but, *rest_but, *all_chk, *skip_same_chk, *dialog, *status;
static int skip_same_state;
static struct ftp_transfer_data *inittrans(int direction);
static void get_local_files_and_dirs(struct ftp_window_data *wdata, struct ftp_host_data *hdata,
   int local, char *path, struct ftp_file_data **files_and_dirs,  
   struct ftp_file_data **lastfle, char *dest, int *dirs, int *files,
   char ***dirs_to_be_made, int *num_dirs_to_be_made);
static void asktrans(struct ftp_transfer_data *tdata);
static void ok(GtkWidget *widget, struct ftp_transfer_data *tdata);
static void cancel(GtkWidget *widget, struct ftp_transfer_data *tdata);
 
void retrCB(GtkWidget *widget, gpointer data) {
   struct ftp_transfer_data *tdata;
   
   if(window2.local == -1) {
      ftp_log(LOG_MISC, "Retrieve Files: Not connected to a remote site\n");
      return;
   }
   else if(window2.numselected == 0) {
      ftp_log(LOG_MISC, "Retrieve Files: You must have at least one item selected\n");
      return;
   }
   tdata = inittrans(1);
   dotrans(tdata);
}
/*****************************************************************************/
void retrmenu(gpointer data) {
   retrCB(NULL, data);
}
/*****************************************************************************/
void putCB(GtkWidget *widget, gpointer data) {
   struct ftp_transfer_data *tdata;
   
   if(window2.local == -1) {
      ftp_log(LOG_MISC, "Put Files: Not connected to a remote site\n");
      return;
   }
   else if(window1.numselected == 0) {
      ftp_log(LOG_MISC, "Put Files: You must have at least one item selected\n");
      return;
   }
   tdata = inittrans(0);
   dotrans(tdata);
}
/*****************************************************************************/
void putmenu(gpointer data) {
   putCB(NULL, data);
}
/*****************************************************************************/
static struct ftp_transfer_data *inittrans(int direction) {
   struct ftp_file_data *newfle, *tempfle;
   struct ftp_transfer_data *tdata, *temptdata;
   char tempstr[MAXSTR], temp1str[MAXSTR];
   GtkWidget *tempwid, *vbox;
   
   skip_same_state = 0;
   dialog = NULL;
   pthread_mutex_lock(&transfer_mutex);
   tdata = create_new_tdata();
   if(direction) tdata->flags |= TRANSFER_DIRECTION;
   *tdata->hdata = *(&window2)->host;
   tdata->wdata = direction ? &window2 : &window1;
   tdata->hdata->totalfiles = tdata->wdata->numselected;
   tdata->hdata->totaldirs = 0;
   tdata->hdata->last = NULL;
   if((tempfle = get_next_selected_filename(tdata->wdata->host->files)) == NULL) {
      ftp_log(LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
      return(NULL);
   }
   while(tempfle != NULL) {
      if(strcmp(tempfle->file, "..") == 0) {
         ftp_log(LOG_MISC, "Transfer Files: Skipping the transfer of the .. directory\n");
         tempfle = tempfle->next;
         continue;
      }
      else if(tempfle->flags & FILE_ISDIR) {
         if(dialog == NULL) {
            dialog = gtk_window_new(GTK_WINDOW_DIALOG);
            gtk_grab_add(dialog);
            gtk_window_set_title(GTK_WINDOW(dialog), "Getting directory listings");
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
            gtk_signal_connect(GTK_OBJECT(dialog), "delete_event", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
            gtk_signal_connect(GTK_OBJECT(dialog), "destroy", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
    
            vbox = gtk_vbox_new(FALSE, 5);
            gtk_container_border_width(GTK_CONTAINER(vbox), 10);
            gtk_container_add(GTK_CONTAINER(dialog), vbox);
            gtk_widget_show(vbox);

            tempwid = gtk_label_new("Please wait while getting directory listings");
            gtk_box_pack_start(GTK_BOX(vbox), tempwid, TRUE, TRUE, FALSE);
            gtk_widget_show(tempwid);

            status = gtk_label_new("");
            gtk_box_pack_start(GTK_BOX(vbox), status, TRUE, TRUE, FALSE);
            gtk_widget_show(status);
            gtk_widget_show(dialog);
            fix_display();
         }

         if(direction) {
            g_snprintf(tempstr, sizeof(tempstr), "%s/%s", window2.host->dir, tempfle->file);
            g_snprintf(temp1str, sizeof(temp1str), "%s/%s", window1.host->dir, tempfle->file);
         }
         else {
            g_snprintf(temp1str, sizeof(temp1str), "%s/%s", window2.host->dir, tempfle->file);
            g_snprintf(tempstr, sizeof(tempstr), "%s/%s", window1.host->dir, tempfle->file);
         }
         tempstr[sizeof(tempstr)-1] = '\0';
         temp1str[sizeof(temp1str)-1] = '\0';
         get_local_files_and_dirs(tdata->wdata, tdata->hdata, tdata->flags & TRANSFER_DIRECTION,
            tempstr, &tdata->hdata->files, &tdata->hdata->last, temp1str,
            &tdata->hdata->totaldirs, &tdata->hdata->totalfiles, &tdata->dirs_to_be_made, &tdata->num_dirs_to_be_made);
         tdata->hdata->totaldirs++;
      }
      else {
         newfle = mymalloc(sizeof(struct ftp_file_data));
         *newfle = *tempfle;

         g_snprintf(newfle->file, sizeof(newfle->file), "%s/%s", window1.host->dir, tempfle->file);
         g_snprintf(newfle->remote_file, sizeof(newfle->remote_file), "%s/%s", window2.host->dir, tempfle->file);
         newfle->file[sizeof(newfle->file)-1] = '\0';
         newfle->remote_file[sizeof(newfle->remote_file)-1] = '\0';

         newfle->flags = 0;
         newfle->next = NULL;
         if(tdata->hdata->last == NULL) tdata->hdata->files = newfle;
         else tdata->hdata->last->next = newfle;
         tdata->hdata->last = newfle;
      }
      tempfle = get_next_selected_filename(tempfle->next);
   }
   tdata->curfle = tdata->prevfle = tdata->hdata->files;
   tdata->next = NULL;
   if(file_transfers == NULL) file_transfers = tdata;
   else {
      temptdata = file_transfers;
      while(temptdata->next != NULL) temptdata = temptdata->next;
      temptdata->next = tdata;
   }

   pthread_mutex_unlock(&transfer_mutex);
   if(dialog != NULL) delete_modal_dialog(NULL, dialog);
   return(tdata);
}
/*****************************************************************************/
static void get_local_files_and_dirs(struct ftp_window_data *wdata, struct ftp_host_data *hdata,
   int local, char *path, struct ftp_file_data **files_and_dirs,  
   struct ftp_file_data **lastfle, char *dest, int *dirs, int *files, 
   char ***dirs_to_be_made, int *num_dirs_to_be_made) {

   struct ftp_file_data *newfle, *tempfle;
   char newpath[MAXSTR], newdest[MAXSTR];
   int i;
   
   (*num_dirs_to_be_made)++;
   dirs_to_be_made[0] = myrealloc(*dirs_to_be_made, (*num_dirs_to_be_made) * sizeof(char *));
   dirs_to_be_made[0][(*num_dirs_to_be_made)-1] = mymalloc(strlen(dest)+1);
   strcpy(dirs_to_be_made[0][(*num_dirs_to_be_made)-1], dest);
   if(local) newfle = get_remote_files(wdata, hdata, path, &i, 1, 0, GTK_LABEL(status));
   else newfle = get_local_files(path, &i);
   tempfle = newfle;
   while(tempfle != NULL) {
      if(tempfle->flags & FILE_ISDIR && strcmp(tempfle->file, ".") != 0 && strcmp(tempfle->file, "..") != 0) {
         (*dirs)++;
         g_snprintf(newpath, sizeof(newpath), "%s/%s", path, tempfle->file);
         newpath[sizeof(newpath)-1] = '\0';
         g_snprintf(newdest, sizeof(newdest), "%s/%s", dest, tempfle->file);
         newdest[sizeof(newdest)-1] = '\0';
         tempfle = tempfle->next;
         get_local_files_and_dirs(wdata, hdata, local, newpath, files_and_dirs, lastfle, newdest, dirs, files, dirs_to_be_made, num_dirs_to_be_made);
      }
      else if(!(tempfle->flags & FILE_ISDIR)) {
         (*files)++;
         g_snprintf(newpath, sizeof(newpath), "%s/%s", path, tempfle->file);
         newpath[sizeof(newpath)-1] = '\0';
         g_snprintf(newdest, sizeof(newdest), "%s/%s", dest, tempfle->file);
         newdest[sizeof(newdest)-1] = '\0';
         if(local) {
            strncpy(tempfle->file, newdest, sizeof(tempfle->file));
            strncpy(tempfle->remote_file, newpath, sizeof(tempfle->remote_file));
         }
         else {
            strncpy(tempfle->file, newpath, sizeof(tempfle->file));
            strncpy(tempfle->remote_file, newdest, sizeof(tempfle->remote_file));
         }
         tempfle->file[sizeof(tempfle->file)-1] = '\0';
         tempfle->remote_file[sizeof(tempfle->remote_file)-1] = '\0';
         
         if(*lastfle == NULL) {
            *files_and_dirs = tempfle;
            tempfle = tempfle->next;
            (*files_and_dirs)->next = NULL;
            *lastfle = *files_and_dirs;
         }
         else {
            (*lastfle)->next = tempfle;
            tempfle = tempfle->next;
            *lastfle = (*lastfle)->next;
            (*lastfle)->next = NULL;
         }
      }
      else tempfle = tempfle->next;
   }
}
/*****************************************************************************/
struct ftp_transfer_data *create_new_tdata(void) {
   struct ftp_transfer_data *tdata;

   tdata = mymalloc(sizeof(struct ftp_transfer_data));
   tdata->hdata = mymalloc(sizeof(struct ftp_host_data));
   tdata->hdata->firewall = use_firewall;
   *tdata->hdata->recvdata.recvdata = '\0';
   tdata->hdata->recvdata.pos = tdata->hdata->recvdata.recvdata;
   tdata->flags = TRANSFER_NEW; /* Signal to make this listbox entry */
   tdata->curtrans = 0;
   tdata->starttime = time(NULL);
   tdata->dirs_to_be_made = mymalloc(sizeof(char *));;
   tdata->dirs_to_be_made = NULL;
   tdata->num_dirs_to_be_made = 0;
   return(tdata);
}
/*****************************************************************************/
void dotrans(struct ftp_transfer_data *tdata) {
   struct ftp_file_data *tempfle, *filelist = NULL;
   char *pos, origch, filelist_dir[MAXSTR];
   struct stat flestat;
   int total;
   
   pthread_mutex_lock(&transfer_mutex);
   while(tdata->curfle != NULL) {
      if(tdata->flags & TRANSFER_DIRECTION) {
         /* We are downloading these files */
         if(stat(tdata->curfle->file, &flestat) != -1) {
            tdata->curfle->remote_size = tdata->curfle->size;
            tdata->curfle->size = flestat.st_size;
            if(tdata->curfle->size == tdata->curfle->remote_size && (tdata->flags & TRANSFER_SKIP_SAME)) {
               /* These files are the same. Remove it from the list */
               if(tdata->curfle == tdata->prevfle) {
                  tdata->hdata->files = tdata->hdata->files->next;
                  free(tdata->curfle);
                  tdata->curfle = tdata->prevfle = tdata->hdata->files;
               }
               else {
                  tdata->prevfle->next = tdata->curfle->next;
                  free(tdata->curfle);
                  tdata->curfle = tdata->prevfle->next;
               }
               tdata->hdata->totalfiles--;
               continue;
            }
            else if(!(tdata->flags & TRANSFER_DOALL)) {
               pthread_mutex_unlock(&transfer_mutex);
               asktrans(tdata);
               return;
            }
            else if(tdata->flags & TRANSFER_OP) {
               tdata->curfle->flags |= FILE_RESTART;
            }
         }
      }
      else {
         /* We are uploading these files */
         pos = strrchr(tdata->curfle->remote_file, '/');
         if(pos == NULL) pos = tdata->curfle->remote_file;
         origch = *pos;
         *pos = '\0';
         if(strcmp(tdata->curfle->remote_file, window2.host->dir) == 0) {
            tempfle = window2.host->files;
         }
         else {
            if(filelist == NULL || strcmp(tdata->curfle->remote_file, filelist_dir) != 0) {
               free_file_list(filelist);
               strncpy(filelist_dir, tdata->curfle->remote_file, sizeof(filelist_dir));
               filelist_dir[sizeof(filelist_dir)-1] = '\0';
               filelist = get_remote_files(&window2, tdata->hdata, filelist_dir, &total, 1, 0, 0);
            }
            tempfle = filelist;
         }
         *pos++ = origch;
         while(tempfle != NULL) {
            if(strcmp(tempfle->file, pos) == 0) {
               tdata->curfle->remote_size = tempfle->size;
               if(tdata->curfle->size == tdata->curfle->remote_size && (tdata->flags & TRANSFER_SKIP_SAME)) {
                  if(tdata->curfle == tdata->prevfle) {
                     tdata->hdata->files = tdata->hdata->files->next;
                     free(tdata->curfle);
                     tdata->curfle = tdata->prevfle = tdata->hdata->files;
                  }
                  else {
                     tdata->prevfle->next = tdata->curfle->next;
                     free(tdata->curfle);
                     tdata->curfle = tdata->prevfle->next;
                  }
                  tdata->hdata->totalfiles--;
                  pthread_mutex_unlock(&transfer_mutex);
                  dotrans(tdata);
                  return;
               }
               else if(!(tdata->flags & TRANSFER_DOALL)) {
                  pthread_mutex_unlock(&transfer_mutex);
                  asktrans(tdata);
                  return;
               }
               else if(tdata->flags & TRANSFER_OP) {
                  tdata->curfle->flags |= FILE_RESTART;
                  tdata->prevfle = tdata->curfle;
                  if(tdata->curfle != NULL) tdata->curfle = tdata->curfle->next;
               }
               break;
            }
            tempfle = tempfle->next;
         }
         if(tempfle != NULL && !(tdata->flags & TRANSFER_DOALL)) {
            pthread_mutex_unlock(&transfer_mutex);
            asktrans(tdata);
            return;
         }
      }
      tdata->prevfle = tdata->curfle;
      if(tdata->curfle != NULL) tdata->curfle = tdata->curfle->next;
   }
   free_file_list(filelist);
   if(tdata->hdata->files != NULL) {
      tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
      tdata->flags |= TRANSFER_SHOW;
      pthread_mutex_unlock(&transfer_mutex);
   }
   else {
      pthread_mutex_unlock(&transfer_mutex);
      cancel(NULL, tdata);
   }
}
/*****************************************************************************/
static void asktrans(struct ftp_transfer_data *tdata) {
   GtkWidget *dialog, *mainvbox, *frame, *label, *hbox, *button;
   char tempstr[MAXSTR];
   GSList *group;

   dialog = gtk_dialog_new();
   gtk_grab_add(dialog);
   gtk_window_set_title(GTK_WINDOW(dialog), (tdata->flags & TRANSFER_DIRECTION) ? "Download Files" : "Upload Files");
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), 10);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->action_area), 15);
   gtk_box_set_homogeneous(GTK_BOX(GTK_DIALOG(dialog)->action_area), TRUE);
   gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
               
   frame = gtk_frame_new(NULL);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), frame, TRUE, TRUE, FALSE);
   gtk_widget_show(frame);
   
   mainvbox = gtk_vbox_new(FALSE, 0);
   gtk_container_border_width(GTK_CONTAINER(mainvbox), 10);
   gtk_box_set_spacing(GTK_BOX(mainvbox), 5);
   gtk_container_add(GTK_CONTAINER(frame), mainvbox);
   gtk_widget_show(mainvbox);

   g_snprintf(tempstr, sizeof(tempstr), "The following file exists both on the local and remote computer.");
   tempstr[sizeof(tempstr)-1] = '\0';
   label = gtk_label_new(tempstr);
   gtk_box_pack_start(GTK_BOX(mainvbox), label, TRUE, TRUE, FALSE);
   gtk_widget_show(label);

   g_snprintf(tempstr, sizeof(tempstr), "Local File: %s Size: %ld", tdata->curfle->file, tdata->curfle->size);
   tempstr[sizeof(tempstr)-1] = '\0';
   label = gtk_label_new(tempstr);
   gtk_box_pack_start(GTK_BOX(mainvbox), label, TRUE, TRUE, FALSE);
   gtk_widget_show(label);
      
   g_snprintf(tempstr, sizeof(tempstr), "Remote File: %s Size: %ld", tdata->curfle->remote_file, tdata->curfle->remote_size);
   tempstr[sizeof(tempstr)-1] = '\0';
   label = gtk_label_new(tempstr);
   gtk_box_pack_start(GTK_BOX(mainvbox), label, TRUE, TRUE, FALSE);
   gtk_widget_show(label);

   g_snprintf(tempstr, sizeof(tempstr), "What would you like to do?");
   tempstr[sizeof(tempstr)-1] = '\0';
   label = gtk_label_new(tempstr);
   gtk_box_pack_start(GTK_BOX(mainvbox), label, TRUE, TRUE, FALSE);
   gtk_widget_show(label);

   hbox = gtk_hbox_new(TRUE, 0);
   gtk_box_set_spacing(GTK_BOX(hbox), 5);
   gtk_box_pack_start(GTK_BOX(mainvbox), hbox, TRUE, TRUE, FALSE);
   gtk_widget_show(hbox);
   
   ovr_but = gtk_radio_button_new_with_label(NULL, "Overwrite File");
   gtk_box_pack_start(GTK_BOX(hbox), ovr_but, TRUE, TRUE, FALSE);
   gtk_widget_show(ovr_but);
   
   group = gtk_radio_button_group(GTK_RADIO_BUTTON(ovr_but));
   rest_but = gtk_radio_button_new_with_label(group, "Resume Transfer");
   gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(rest_but), TRUE);
   gtk_box_pack_start(GTK_BOX(hbox), rest_but, TRUE, TRUE, FALSE);
   gtk_widget_show(rest_but);

   all_chk = gtk_check_button_new_with_label("Do this for all files");
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), all_chk, TRUE, TRUE, FALSE);
   gtk_widget_show(all_chk);

   skip_same_chk = gtk_check_button_new_with_label("Skip files that are the same");
   gtk_toggle_button_set_state(GTK_TOGGLE_BUTTON(skip_same_chk), skip_same_state);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), skip_same_chk, TRUE, TRUE, FALSE);
   gtk_widget_show(skip_same_chk);
   
   button = gtk_button_new_with_label("Continue");
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button, TRUE, TRUE, TRUE);
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(ok), (gpointer) tdata);
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_show(button);

   button = gtk_button_new_with_label("Cancel");
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), button, TRUE, TRUE, TRUE);
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(cancel), (gpointer) tdata);
   gtk_signal_connect(GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_show(button);

   gtk_widget_show(dialog);
}
/*****************************************************************************/
static void ok(GtkWidget *widget, struct ftp_transfer_data *tdata) {
   int inc;

   pthread_mutex_lock(&transfer_mutex);
   if(GTK_TOGGLE_BUTTON(all_chk)->active) {
      tdata->flags |= TRANSFER_DOALL;
      if(GTK_TOGGLE_BUTTON(rest_but)->active) {
         tdata->flags |= TRANSFER_OP;
      }
   }
   else if(GTK_TOGGLE_BUTTON(rest_but)->active) {
      tdata->curfle->flags |= FILE_RESTART;
   }
   
   inc = 1;
   if(GTK_TOGGLE_BUTTON(skip_same_chk)->active) {
      skip_same_state = 1;
      if(tdata->curfle->size == tdata->curfle->remote_size) {
         inc = 0;
         if(tdata->curfle == tdata->prevfle) {
            tdata->hdata->files = tdata->hdata->files->next;
            free(tdata->curfle);
            tdata->curfle = tdata->prevfle = tdata->hdata->files;
         }
         else {
            tdata->prevfle->next = tdata->curfle->next;
            free(tdata->curfle);
            tdata->curfle = tdata->prevfle->next;
         }
         tdata->hdata->totalfiles--;
      }
      tdata->flags |= TRANSFER_SKIP_SAME;
   }
   else skip_same_state = 0;
   if(inc) {
      tdata->prevfle = tdata->curfle;
      if(tdata->curfle != NULL) tdata->curfle = tdata->curfle->next;
   }
   pthread_mutex_unlock(&transfer_mutex);
   dotrans(tdata);
}
/*****************************************************************************/
static void cancel(GtkWidget *widget, struct ftp_transfer_data *tdata) {
   pthread_mutex_lock(&transfer_mutex);
   tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
   tdata->flags |= TRANSFER_DONE;
   pthread_mutex_unlock(&transfer_mutex);
}
/*****************************************************************************/
void *ftp_get_files(void *ptr) {
   char tempstr[MAXSTR], buf[8192], gotstr[MAXSTR], ofstr[MAXSTR], *pos;
   struct ftp_transfer_data *tdata;
   int datafd, i, j=0;
   long startsize;
   FILE *writefd;
   float kbs;
   ssize_t n;
   int num;

   num = 0;
   tdata = (struct ftp_transfer_data *) ptr;
   pthread_detach(pthread_self());
   if(ftp_connect(tdata->wdata, tdata->hdata, tdata)) {
      if(ftp_sendcommand(0, tdata->wdata, tdata->hdata, NULL, 0, "TYPE %c\r\n", tdata->hdata->type == FTP_ASCII ? 'A' : 'I') != '2') {
         queue_log(LOG_MISC, "Error: Could not set %s mode\n", tdata->hdata->type == FTP_ASCII ? "ascii" : "binary");
      }
      else while(!(tdata->flags & TRANSFER_CANCEL) && tdata->curfle != NULL) {
         num++;
         if((datafd = ftp_init_data_conn(tdata->wdata, tdata->hdata)) == 0) break;

         writefd = fopen(tdata->curfle->file, tdata->curfle->flags & FILE_RESTART ? "a" : "w");
         if(!writefd) {
            queue_log(LOG_MISC, "Cannot create %s: %s\n", tdata->curfle->file , g_strerror(errno));
            break;
         }
         if(tdata->curfle->flags & FILE_RESTART) {
            startsize = tdata->curfle->size;
            if(tdata->hdata->type == FTP_ASCII) {
               pthread_mutex_lock(&transfer_mutex);
               startsize += file_countlf(writefd, startsize);
               pthread_mutex_unlock(&transfer_mutex);
            }
            g_snprintf(tempstr, sizeof(tempstr), "REST %ld\r\n", startsize);
            tempstr[sizeof(tempstr)-1] = '\0';
            queue_log(LOG_SEND, tempstr);
            if(ftp_sendcommand(0, tdata->wdata, tdata->hdata, buf, sizeof(buf), tempstr) != '3') {
               queue_log(LOG_RECV, "%s\n", buf);
               queue_log(LOG_MISC, "Cannot start file transfer at %ld for file %s from %s\n", startsize, tdata->curfle->remote_file, tdata->hdata->host);
               break;
            }
            queue_log(LOG_RECV, "%s\n", buf);
         }

         g_snprintf(tempstr, sizeof(tempstr), "RETR %s\r\n", tdata->curfle->remote_file);
         tempstr[sizeof(tempstr)-1] = '\0';
         queue_log(LOG_SEND, tempstr);
         if(ftp_sendcommand(0, tdata->wdata, tdata->hdata, buf, sizeof(buf), tempstr) != '1') {
            queue_log(LOG_RECV, "%s\n", buf);
            queue_log(LOG_MISC, "Cannot get file %s\n", tdata->curfle->remote_file);
            break;
         }
         queue_log(LOG_RECV, "%s\n", buf);
         if(!passive_transfer) datafd = ftp_accept_port_conn(tdata->wdata, tdata->hdata, datafd);

         /* The size of the file should be sent in ( ) with the return line
             after the RETR command */
         pos = strchr(buf, '(');

         pthread_mutex_lock(&transfer_mutex);
         if(pos == NULL) tdata->curfle->size = 0;
         else tdata->curfle->size = strtol(pos+1, (char **) NULL, 10);
         tdata->starttime = time(NULL);
         tdata->curtrans = 0;
         pthread_mutex_unlock(&transfer_mutex);
         insert_commas(tdata->curfle->size, ofstr, sizeof(ofstr));

         while(!(tdata->flags & TRANSFER_CANCEL) && (n = read(datafd, &buf, sizeof(buf))) > 0) {
            pthread_mutex_lock(&transfer_mutex);
            tdata->curtrans += n;
            if(tdata->curfle->flags & FILE_RESTART) insert_commas(tdata->curtrans+startsize,
               gotstr, sizeof(gotstr));
            else insert_commas(tdata->curtrans, gotstr, sizeof(gotstr));
            kbs = ((float) tdata->curtrans / 1024) / (float) (time(NULL)-tdata->starttime);
            g_snprintf(tdata->progressstr, sizeof(tdata->progressstr), "Recv %s of %s at %.2fkbs (%d of %d)",
               gotstr, ofstr, kbs, num, tdata->hdata->totalfiles);
            tdata->flags |= TRANSFER_NEED_UPDATED;
            pthread_mutex_unlock(&transfer_mutex);
            
            if(tdata->hdata->type == FTP_ASCII) { 
               for(i=0, j=0; i<n; i++) if(buf[i] != '\r') buf[j++] = buf[i];
               buf[j] = '\0';
            }
            if(!fwrite(buf, 1, tdata->hdata->type == FTP_ASCII ? j : n, writefd)) break;
         }   
         fclose(writefd);
         close(datafd);
         if(ftp_read_response(0, tdata->wdata, tdata->hdata, NULL, 0) != '2') {
            queue_log(LOG_MISC, "Could not download %s\n", tdata->curfle->remote_file);
         }
         else {
            queue_log(LOG_MISC, "Successfully downloaded %s\n", tdata->curfle->remote_file);
         }
         pthread_mutex_lock(&transfer_mutex);
         tdata->prevfle = tdata->curfle;
         tdata->curfle = tdata->curfle->next;
         pthread_mutex_unlock(&transfer_mutex);
      }
      ftp_disconnect(tdata->wdata, tdata->hdata, 0);
   }

   pthread_mutex_lock(&transfer_mutex);
   tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
   tdata->flags |= TRANSFER_DONE;
   pthread_mutex_unlock(&transfer_mutex);
   pthread_exit(NULL);
}
/*****************************************************************************/
void *ftp_put_files(void *ptr) {
   char tempstr[MAXSTR], buf[8192], gotstr[MAXSTR], ofstr[MAXSTR], *pos, *newbuf;
   struct ftp_transfer_data *tdata;
   int datafd, i, j=0, num;
   long startsize;
   FILE *readfd;
   float kbs;
   ssize_t n, newsize;

   num = 0;
   tdata = (struct ftp_transfer_data *) ptr;
   pthread_detach(pthread_self());
   if(ftp_connect(tdata->wdata, tdata->hdata, tdata)) {
      if(ftp_sendcommand(0, tdata->wdata, tdata->hdata, NULL, 0, "TYPE %c\r\n", tdata->hdata->type == FTP_ASCII ? 'A' : 'I') != '2') {
         queue_log(LOG_MISC, "Error: Could not set %s mode\n", tdata->hdata->type == FTP_ASCII ? "ascii" : "binary");
      }
      else while(!(tdata->flags & TRANSFER_CANCEL) && tdata->curfle != NULL) {
         num++;
         if((datafd = ftp_init_data_conn(tdata->wdata, tdata->hdata)) == 0) break;

         if(!(readfd = fopen(tdata->curfle->file, "r"))) {
            queue_log(LOG_MISC, "Error: Cannot open local file %s: %s\n", tdata->curfle->file, g_strerror(errno));
            break;
         }
         if(tdata->curfle->flags & FILE_RESTART) {
            if(ftp_sendcommand(0, tdata->wdata, tdata->hdata, buf, sizeof(buf), "SIZE %s\r\n", tdata->curfle->remote_file) != '2') {
               queue_log(LOG_MISC, "Cannot get size of %s on %s\n", tdata->curfle->remote_file, tdata->hdata->host);
               break;
            }

            pos = buf;
            pos += 4;
            pthread_mutex_lock(&transfer_mutex);
            startsize = strtol(pos, (char **) NULL, 10);
            if(tdata->hdata->type == FTP_ASCII) {
               startsize += file_countlf(readfd, startsize);
            }
            fseek(readfd, startsize, SEEK_SET);
            pthread_mutex_unlock(&transfer_mutex);
            g_snprintf(tempstr, sizeof(tempstr), "REST %ld\r\n", startsize);
            tempstr[sizeof(tempstr)-1] = '\0';
            queue_log(LOG_SEND, tempstr);
            if(ftp_sendcommand(0, tdata->wdata, tdata->hdata, buf, sizeof(buf), tempstr) != '3') {
               queue_log(LOG_RECV, "%s\n", buf);
               queue_log(LOG_MISC, "Cannot start file transfer at %ld for file %s from %s\n", startsize, tdata->curfle->remote_file, tdata->hdata->host);
               break;
            }
            queue_log(LOG_RECV, "%s\n", buf);
         }
         g_snprintf(tempstr, sizeof(tempstr), "STOR %s\r\n", tdata->curfle->remote_file);
         tempstr[sizeof(tempstr)-1] = '\0';
         queue_log(LOG_SEND, tempstr);
         if(ftp_sendcommand(0, tdata->wdata, tdata->hdata, buf, sizeof(buf), tempstr) != '1') {
            queue_log(LOG_RECV, "%s\n", buf);
            queue_log(LOG_MISC, "Cannot put file %s to %s\n", tdata->curfle->remote_file, tdata->hdata->host);
            break;
         }
         queue_log(LOG_RECV, "%s\n", buf);
         if(!passive_transfer) datafd = ftp_accept_port_conn(tdata->wdata, tdata->hdata, datafd);

         pthread_mutex_lock(&transfer_mutex);
         tdata->starttime = time(NULL);
         tdata->curtrans = 0;
         pthread_mutex_unlock(&transfer_mutex);
         insert_commas(tdata->curfle->size, ofstr, sizeof(ofstr));

         while(!(tdata->flags & TRANSFER_CANCEL) && (n = fread(&buf, 1, sizeof(buf), readfd)) > 0) {
            pthread_mutex_lock(&transfer_mutex);
            tdata->curtrans += n;
            if(tdata->curfle->flags & FILE_RESTART) insert_commas(startsize+tdata->curtrans,
               gotstr, sizeof(gotstr));
            else insert_commas(tdata->curtrans, gotstr, sizeof(gotstr));
            kbs = ((float) tdata->curtrans / 1024) / (float) (time(NULL)-tdata->starttime);
            g_snprintf(tdata->progressstr, sizeof(tdata->progressstr), "Sent %s of %s at %.2fkbs (%d of %d)",
               gotstr, ofstr, kbs, num, tdata->hdata->totalfiles);
            tdata->flags |= TRANSFER_NEED_UPDATED;
            pthread_mutex_unlock(&transfer_mutex);

            if(tdata->hdata->type == FTP_ASCII) { 
               newsize = 1;
               for(i=0; i<n; i++) {
                  newsize++;
                  if(i > 0 && buf[i] == '\n' && buf[i-1] != '\r') newsize++;
               }
               newbuf = mymalloc(newsize);
               for(i=0,j=0; i<n; i++) {
                  if(i > 0 && buf[i] == '\n' && buf[i-1] != '\r') newbuf[j++] = '\r';
                  newbuf[j++] = buf[i];
               }
               newbuf[newsize-1] = '\0';
            }
            else {
               newbuf = buf;
               newsize = n;
            }

            if(!write(datafd, newbuf, newsize)) {
               if(tdata->hdata->type == FTP_ASCII) free(newbuf);
               queue_log(LOG_MISC, "Cannot write %s to %s\n", tdata->curfle->file, tdata->hdata->host);
               break;
            }
            if(tdata->hdata->type == FTP_ASCII) free(newbuf);
         }   
         fclose(readfd);
         close(datafd);
         if(ftp_read_response(0, tdata->wdata, tdata->hdata, NULL, 0) != '2') {
            queue_log(LOG_MISC, "Could not upload %s to %s\n", tdata->curfle->remote_file, tdata->hdata->host);
         }
         else {
            queue_log(LOG_MISC, "Successfully uploaded %s to %s\n", tdata->curfle->remote_file, tdata->hdata->host);
         }
         pthread_mutex_lock(&transfer_mutex);
         tdata->prevfle = tdata->curfle;
         tdata->curfle = tdata->curfle->next;
         pthread_mutex_unlock(&transfer_mutex);
      }
      ftp_disconnect(tdata->wdata, tdata->hdata, 0);
   }

   pthread_mutex_lock(&transfer_mutex);
   tdata->flags &= ~(TRANSFER_NEW | TRANSFER_SHOW | TRANSFER_UPDATE | TRANSFER_DONE);
   tdata->flags |= TRANSFER_DONE;
   pthread_mutex_unlock(&transfer_mutex);
   pthread_exit(NULL);
}
/*****************************************************************************/
