#ifndef testlib_h
#define testlib_h
void handler(int test);
int stripHTML(char *pointer);
int parseResponseHeader(const char *pointer, char *&beginofhtml );
char *getLine(char *pointer, char*buffer, int buflen);
int sendRequest(char*machine, int port, char *request, char *buffer, int buflen);
int parseNorway(char *pointer, char *searchfile);
void parseFTPSearchanswer(int type, char *pointer, char *searchfile );
void search( char*file, char*buffer, int buflen);
int do_fork(char *file);
#endif
