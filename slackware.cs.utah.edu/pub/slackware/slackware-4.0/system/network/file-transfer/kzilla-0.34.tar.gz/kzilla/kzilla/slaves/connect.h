/*
*/

#include <sys/socket.h>

extern int advconnect(int s, struct sockaddr *sa, int sa_size);
