/* 
 * (C) 1998 Kling Dietmar
 */

#include "setupDlg.h"
#include "setupDlg.moc"
#define Inherited QDialog
#include <kapp.h>

#include <qlined.h>
#include <qgrpbox.h>
#include <qpushbt.h>

extern KApplication *TemplateApplication; 
setupDlg::setupDlg
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name, TRUE, 0 )
{
	
	KConfig *kc = TemplateApplication->getConfig();
        kc->setGroup("Configuration");    
    	
	if (  kc->readEntry("Destination") == NULL ) {
	kc->writeEntry("Destination", "/tmp");
        kc->sync();
        }  


	setCaption(i18n("Options"));

	QGroupBox* dlgedit_GroupBox_1;
	dlgedit_GroupBox_1 = new QGroupBox( this, "GroupBox_1" );
	dlgedit_GroupBox_1->setGeometry( 10, 10, 380, 60 );
	dlgedit_GroupBox_1->setMinimumSize( 10, 10 );
	dlgedit_GroupBox_1->setMaximumSize( 32767, 32767 );
	dlgedit_GroupBox_1->setFrameStyle( 49 );
	dlgedit_GroupBox_1->setTitle( "Destination" );
	dlgedit_GroupBox_1->setAlignment( 1 );

	dlgedit_LineEdit_1 = new QLineEdit( this, "LineEdit_1" );
	dlgedit_LineEdit_1->setGeometry( 20, 30, 360, 30 );
	dlgedit_LineEdit_1->setMinimumSize( 10, 10 );
	dlgedit_LineEdit_1->setMaximumSize( 32767, 32767 );
	dlgedit_LineEdit_1->setText( kc->readEntry("Destination") );
	dlgedit_LineEdit_1->setMaxLength( 32767 );
	dlgedit_LineEdit_1->setEchoMode( QLineEdit::Normal );
	dlgedit_LineEdit_1->setFrame( TRUE );

	QPushButton* dlgedit_PushButton_1;
	dlgedit_PushButton_1 = new QPushButton( this, "PushButton_1" );
	dlgedit_PushButton_1->setGeometry( 190, 260, 100, 30 );
	dlgedit_PushButton_1->setMinimumSize( 10, 10 );
	dlgedit_PushButton_1->setMaximumSize( 32767, 32767 );
	dlgedit_PushButton_1->setText( "OK" );
	dlgedit_PushButton_1->setAutoRepeat( FALSE );
	dlgedit_PushButton_1->setAutoResize( FALSE );

	QPushButton* dlgedit_PushButton_2;
	dlgedit_PushButton_2 = new QPushButton( this, "PushButton_2" );
	dlgedit_PushButton_2->setGeometry( 290, 260, 100, 30 );
	dlgedit_PushButton_2->setMinimumSize( 10, 10 );
	dlgedit_PushButton_2->setMaximumSize( 32767, 32767 );
	dlgedit_PushButton_2->setText( "Cancel" );
	dlgedit_PushButton_2->setAutoRepeat( FALSE );
	dlgedit_PushButton_2->setAutoResize( FALSE );
 
  
        connect(dlgedit_PushButton_1 , SIGNAL(released()),
            	this, SLOT(OnOk()));
        connect(dlgedit_PushButton_2 , SIGNAL(released()),
            	this, SLOT(accept()));
		
	dlgedit_PushButton_1->setFocus();           

	resize( 400,300 );
	setMinimumSize( 0, 0 );
	setMaximumSize( 32767, 32767 );
}
void
setupDlg::OnOk()
{
	KConfig *kc = TemplateApplication->getConfig();
        kc->setGroup("Configuration");    
    	
	kc->writeEntry(	"Destination",	
	 		dlgedit_LineEdit_1->text()
			);
        kc->sync();
	accept();
}

setupDlg::~setupDlg()
{
}
