/*
*/

void close_socket(int *s, int how);
