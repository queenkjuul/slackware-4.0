/**********************************************************************
 mainDlg - The main file for this project
 
 (C) 1998 Kling Dietmar
 
 Licensing is GPL
 *********************************************************************/

#ifndef mainView_included
#define mainView_included
#include <qwidget.h>
#include <qlined.h>
#include <qmlined.h>
#include <kapp.h>
#include <ktablistbox.h>
#include <kurl.h>
#include <qpushbt.h>
class mainView : public QWidget
{
    Q_OBJECT

public:

    mainView
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );
    void setupListBox();
    virtual ~mainView();
    QLineEdit*  dlgedit_LineEdit_1;
    QMultiLineEdit* dlgedit_MultiLineEdit_1;
    KTabListBox* ListBox;
    QPushButton* dlgedit_PushButton_1;
    int convertKdelnk(KURL &url);
    
public slots:
	void resizeEvent( QResizeEvent *);
	void dropslot(KDNDDropZone *z);
	void searchFTPEngines();
	void selection(int index, int column);
protected slots:


protected:

};

#endif // mainView_included
