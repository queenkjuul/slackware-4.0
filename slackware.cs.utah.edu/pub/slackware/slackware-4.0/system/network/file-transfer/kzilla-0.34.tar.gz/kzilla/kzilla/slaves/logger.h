/*
*/

#define LC_INFO		0	/* misc info */
#define LC_WARNING	1	/* warnings */
#define LC_FATAL	2	/* fatal errors */
#define LC_NONFATAL	3	/* non-fatal errors */
#define LC_REC		4	/* receive from server */
#define LC_SEND		5	/* send to server */

extern void openlogfile(char *filename);
extern void logit(int c, char *msg);
extern void logerror(int c, char *msg);
extern void logherror(int c, char *msg);
extern void closelogfile();
