#include "ftplib.h"
void 
main()
{
	netbuf* control;
	FtpConnect("localhost", control);
}
