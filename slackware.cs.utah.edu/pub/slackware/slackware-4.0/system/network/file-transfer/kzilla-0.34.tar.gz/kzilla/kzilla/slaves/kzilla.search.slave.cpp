/**********************************************************************
 main for kzilla.search.slave
 (C) 1998 Kling Dietmar
 *********************************************************************/



#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <stdlib.h>
#include <ctype.h>
#include "libtcp.h"
#include "supportlib.h"

void
main(int argc, char**argv)
{
 if ( argc != 2) { printf("ERROR NO ARGUMENT\n");exit(1);}
 
  char *file=argv[1];
  char *pointer;
  pointer = (char *)malloc(100*1024);
  search(file,pointer,100*1024);

  free(pointer);
}

