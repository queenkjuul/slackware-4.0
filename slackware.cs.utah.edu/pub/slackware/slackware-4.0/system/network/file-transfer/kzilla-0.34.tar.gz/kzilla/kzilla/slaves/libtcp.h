// Exported Function of libtcp

#ifndef __LIBTCP__
#define __LIBTCP__

int tcpConnect(int *socket,char *host, int port);

void tcpOpenLogFile(char *filename);
void tcpCloseLogFile();

#endif
