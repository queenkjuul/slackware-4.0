/* snarf, the Simple Non-interactive All-purpose Resource Fetcher
** Copyright (C) 1995 Zachary Beane
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public LIcense as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is dsitributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILIY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
** General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** The author of this program may be reached via email at
** xach@mint.net or via USPS at 17 Talmadge Rd., Waite, ME 04492, USA.
*/
/* simple.c */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include "protocol.h"
#include "url.h"
#include "option.h"
#include "misc.h"


#define MAXLEN 4096

int simple_get(struct url u, char *outfile)
{
  FILE *fp;
  int fd, s;

  char send_buf[256];
  char recv_buf[MAXLEN];

  /* hehe. is this suitably illegible? struct url u has all the info we need
     (about the host name, port, and such */
  s = tcp_connect(u);

  fd = open_output(outfile);

  /* fill send_buf with a valid request based on the service type */
  get_request(u, send_buf);

  /* send send_buf to the server */
  send(s, send_buf, strlen(send_buf), 0);

  /* while the server chats with us, write it down for later examination */

  dump_data(s, fd);
  /*  while((i = read(s, recv_buf, sizeof(recv_buf))) > 0){
    if(hash){
      fprintf(stderr, "#");
    }
    write(fd, recv_buf, i);
  } */
  
  return(1);
}

/*\
This function takes the url struct and returns a valid request string
to send to the server.
\*/

int get_request(struct url u, char send_buf[])
{
  switch(getport(u.u_service)){
  case FINGER:
    get_finger_request(u, send_buf);
    break;
  case GOPHER:
    get_gopher_request(u, send_buf);
    break;
  default:
    return(0);
  }

  return(1);
}

int get_finger_request(struct url u, char send_buf[])
{
  int i = 0;
  
  while(u.u_file[i] != '\0'){
    send_buf[i] = u.u_file[i];
    i++;
  }
  send_buf[i++] = '\r';
  send_buf[i++] = '\n';
  send_buf[i] = '\0';

  return(1);
}

int get_gopher_request(struct url u, char send_buf[])
{
  char *woop;

  if(strlen(u.u_path) > 1){
    woop = u.u_path;
    woop++;
    strcpy(send_buf, woop);
  } else {
    strcpy(send_buf, u.u_path);
  }

  strcat(send_buf, u.u_file);
  strcat(send_buf, "\r\n");

  return(1);
}
