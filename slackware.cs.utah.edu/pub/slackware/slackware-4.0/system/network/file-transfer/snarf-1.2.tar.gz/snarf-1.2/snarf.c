/* snarf, the Simple Non-interactive All-purpose Resource Fetcher
** Copyright (C) 1995, 1996 Zachary Beane
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public LIcense as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is dsitributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILIY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
** General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** The author of this program may be reached via email at
** xach@mint.net or via USPS at 17 Talmadge Rd., Waite, ME 04492, USA.
*/
/* snarf.c */
#include "url.h"
#include "protocol.h"
#include "snarf.h"
#include "simple.h"
#include "option.h"
#include <stdio.h>
#include <pwd.h>

#define MED_BUFFER_SIZE 100
#define BIG_BUFFER_SIZE 256

void print_usage(char *);


int main(int argc, char *argv[], char *environ[])
{
  struct url u;
  char string[BIG_BUFFER_SIZE];
  char outfile[BIG_BUFFER_SIZE];
  char config_file[MED_BUFFER_SIZE];
  char real_args[3][256];
  int argnum, realargnum = 0;
  extern int verbose, hash;
  struct passwd *pwd;

  /* the following hideous contraption does the following:
     1) it checks each argument to see if it is a flag.
     2) if it is a flag, pass it to set_options to set verbosity and hashes
     3) if it is not a flag, copy it to the real_args array to compensate
        for my lack of foresight in using argv[x] in everything
  */
  for(argnum = 0; argnum < argc; argnum++){
    if(argv[argnum][0] == '-' && strlen(argv[argnum]) > 1)
      set_options(argv[argnum]);
    else if(realargnum < 3)
      strncpy(real_args[realargnum++], (char *)argv[argnum], BIG_BUFFER_SIZE);
  }
  
  pwd = getpwuid(getuid());  

  if((char *)getenv("HOME") == NULL){
    if (!pwd)
      {
	fprintf(stderr, "Unable to find your home directory. Please report this bug!\n");
	exit(1);
      } /* pwd is valid but getenv("HOME") isn't */
    strcpy(config_file, pwd->pw_dir);
  } /* getenv("HOME") is valid */

  strcpy(config_file, (char *)getenv("HOME"));

  strcat(config_file, "/.snarfrc");

  if(realargnum < 2){
    print_usage(argv[0]);
    exit(1);
  }
  else
    if(!aliastourl(config_file, real_args[1], string)){
      strncpy(string, real_args[1], BIG_BUFFER_SIZE);
    }
	

  if(isurl(string))
    u = parse_url(string);
  else { 
    fprintf(stderr, "%s: not a recognized URL or alias.\n", string);
    exit(1);
  }


  /*\
this is a bit of a complex if statement...it boils down to opening
the same local file as the remote one by default, and stdout if the
third argument is -. If the remote file is null, for example, if you
wanted a finger for a site, it would open snarf.out for writing.
\*/
      if(realargnum < 3){
	if(strlen(u.u_file) < 1)
	  strcpy(outfile, "snarf.out");
	else
	  strcpy(outfile, u.u_file);
      }
      else
	strcpy(outfile, real_args[2]);

      if(getport(u.u_service) == 0){
	fprintf(stderr, "%s: unknown or unsupported service.\n", u.u_service);
	exit(1);
      }

      switch(getport(u.u_service)){
      case HTTP:
	http_get(u, outfile);
	break;
      case FTP:
	ftp_get(u, outfile);
	break;
      default:
	simple_get(u, outfile);
	break;
      }
	


	
      if(hash)
	fprintf(stderr, "\n");
    
      exit(0);
}

void print_usage(char *string)
{
  fprintf(stderr, "snarf version %s, Copyright (C) 1995, 1996 Zachary Beane\n", VERSION);
  fprintf(stderr, "snarf comes with ABSOLUTELY NO WARRANTY; see the file COPYING for details.\n");
  fprintf(stderr, "Send any bug reports, etc. to xach@mint.net\n\n");  
  fprintf(stderr, "Usage: %s [options] {url | alias} [localfile]\n\n", string);
  fprintf(stderr, "Example: %s http://www.unitedmedia.com/comics/dilbert/todays_dilbert.gif\n", string);
  fprintf(stderr, "Use a dash as the localfile to send data to standard output.\n");

}
