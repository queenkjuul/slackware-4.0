/* http.c
** just a stub right now w00
*/
#include <stdio.h>
#include <unistd.h>
#include "url.h"
#include "misc.h"
#define MAXLEN 4096

int http_get(struct url u, char *outfile)
{
  struct url proxy;
  char line[MAXLEN];
  char request[MAXLEN];
  int socket, output;

  /*  fprintf(stderr, "whoa, soon to die\n"); */
  if(get_proxy(&proxy)){
    /*    fprintf(stderr, "gotproxy\n"); */
    socket = tcp_connect(proxy);
    get_proxy_request(u, request);
  } else {
    /*    fprintf(stderr, "bleh\n"); */
    socket = tcp_connect(u);
    get_http_request(u, request);
  }
  
  output = open_output(outfile);

  send(socket, request, strlen(request), 0);

  /* skip that inconvenient http header */
  while(readline(socket, line)){
    if(line[1] == '\n'){
      break;
    }
  }
  dump_data(socket, output);
  
  return(1);
}

int get_proxy(struct url *u)
{
  char string[MAXLEN];

  if((char *)getenv("SNARF_PROXY") == NULL)
    return(0);
  strncpy(string, (char *)getenv("SNARF_PROXY"), MAXLEN);
  /*  fprintf(stderr, "about to segfault\n"); */
  *u = parse_url(string);
  /* fprintf(stderr, "apres le segfault\n"); */

  return(1);
}


int get_proxy_request(struct url u, char *request)
{
  char tmp[MAXLEN];
  request[0] = '\0';

  sprintf(tmp, "GET http://%s:%d%s%s HTTP/1.0\r\n\r\n", 
	  u.u_host, u.u_port, u.u_path, u.u_file);
  strncpy(request, tmp, MAXLEN);
  return(1);
}

int get_http_request(struct url u, char *request)
{
  char tmp[MAXLEN];
  request[0] = '\0';
  sprintf(tmp, "GET %s%s HTTP/1.0\r\n\r\n", u.u_path, u.u_file);
  strncpy(request, tmp, MAXLEN);
  return(1);
}
