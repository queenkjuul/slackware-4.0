/* option.c */
/* this file is covered by the license described in the file COPYING */

#include <stdio.h>
#include "option.h"
#include "snarf.h"

char popchar(char *);

int set_options(char *optstring)
{
  char opt;

  while(opt = popchar(optstring++)){
    switch(opt){
    case '-':
      break;
    case 'h':
      hash = 1;
      break;
    case 'v':
      verbose = 1;
      break;
    case 'r':
      resume = 1;
      break;
    }
  }
  return(1);
}      
  


char popchar(char *string){
  return(*string);
}
