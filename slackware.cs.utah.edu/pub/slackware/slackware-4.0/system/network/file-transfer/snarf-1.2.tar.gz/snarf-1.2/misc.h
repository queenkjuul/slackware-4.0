
int readline(int, char*);
int dump_data(int, int);
int tcp_connect(struct url);
int open_output(char *);
