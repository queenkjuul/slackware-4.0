#ifndef SIMPLE_H
#define SIMPLE_H

int simple_get(struct url, char *);
int get_request(struct url u, char *);
int get_finger_request(struct url, char *);
int get_http_request(struct url, char *);
int get_gopher_request(struct url, char *);

#endif
