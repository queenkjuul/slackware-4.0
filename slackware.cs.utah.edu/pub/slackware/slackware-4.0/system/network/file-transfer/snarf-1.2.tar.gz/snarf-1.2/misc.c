#include <sys/types.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include "protocol.h"
#include "url.h"
#include "option.h"
#include "misc.h"


#define BIG_BUFFER_SIZE 4096

/* Reads a \n terminated line (includes the \n) */
int readline (int fd, char *line) 
{
  int n, rc = 0;
  char c ;

  for (n = 1 ; n < BIG_BUFFER_SIZE ; n++)
    {
      if ((rc == read (fd, &c, 1)) != 1)
	{
	  *line++ = c ;
	  if (c == '\n')
	    break ;
	}
      else if (rc == 0)
	{
	  if (n == 1)
	    return 0 ; /* EOF */
	  else
	    break ; /* unexpected EOF */
	}
      else 
	return -1 ;
    }

  *line = 0 ;
  return n ;
}

int dump_data(int fd_in, int fd_out){
  int i;
  char recv_buf[BIG_BUFFER_SIZE];
  
  while(i = read(fd_in, recv_buf, sizeof(recv_buf)))
    write(fd_out, recv_buf, i);

  return(1);
}


int tcp_connect(struct url u){
  struct hostent *host;
  struct sockaddr_in sin;
  int sock_fd;


  /*  fprintf(stderr, "trying to connect to %s:%d\n", u.u_host, u.u_port); */

  if((host = gethostbyname(u.u_host)) == NULL) {
    fprintf(stderr, "%s: I couldn't find that host.\n", u.u_host);
    return(0);
  }

  /* get the socket */
  if((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    fprintf(stderr, "I tried to create a socket but couldn't.\n");
    return(0);
  }

  /* connect the socket, filling in the important stuff */
  sin.sin_family = AF_INET;
  sin.sin_port = htons(u.u_port);
  bcopy(host->h_addr, &sin.sin_addr, host->h_length);
  
  if(connect(sock_fd, (struct sockaddr *)&sin, sizeof(sin)) < 0){
    fprintf(stderr, "%s: connect failed.\n", u.u_host);
    return(0);
  }

  return sock_fd;
}

int open_output(char *outfile){
  int fd;

  /* get a file descriptor pointing at the right place */
  if(strcmp(outfile, "-") == 0)
    fd = 1;
  else
    if((fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0) {
      fprintf(stderr, "Unable to open output file %s for writing.\n", outfile);
      return(0);
    }

  return fd;
}
