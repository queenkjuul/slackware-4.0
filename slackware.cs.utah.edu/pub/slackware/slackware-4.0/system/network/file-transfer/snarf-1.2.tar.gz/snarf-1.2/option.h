/* option.h */

int verbose;
int hash;
int resume;

