#include <stdlib.h>
#include <iostream.h>
#include <stdio.h>

typedef struct record_typ {

  float transfer;
  char name[256];

} record, *record_ptr;

record Entries[1024];
int entries = 0;
float total = 0.0;

int findEntry(char *);
void orderEntries(void);

void main(int argc, char *argv[])
{

  FILE *File;
  char Line[256], *Ptr, Part1[256], Part2[256];
  int i;
  int numEntry;

  if(argc != 2) {
    cout << "Usage: listDownloads [file]\n";
    exit(-1);
  }

  File = fopen(argv[1], "r");
  
  while( (fgets(Line, 256, File)) != NULL ) {
    
    i = 0;

    Ptr = Line;
    while(*Ptr != ' ') {
      Part1[i++] = *Ptr;
      Ptr++;
    }

    Part1[i] = '\0';
    i=0;

    while( (*Ptr != '\n') ) {
      Part2[i++] = *Ptr;
      Ptr++;
    }

    Part2[i] = '\0';

    //    cout << "Login : " << Part2 << " Size : " << Part1 << '\n';

    numEntry = findEntry(Part2);

    strcpy(Entries[numEntry].name, Part2);
    Entries[numEntry].transfer += atof(Part1) / (1024.0 * 1024.0);

    //    cout  << "Login : " << Entries[numEntry].name << " Size : " << Entries[numEntry].transfer << "\n";

  }

  orderEntries();

  for(i=0;i<entries;i++) {
    printf("%-10s \t\t %.2f MB\n", Entries[i].name, Entries[i].transfer);
    total += Entries[i].transfer;
  }

  printf("\n\tTotal : %.2f MB\n", total);

}


int findEntry(char *Entry) {

  int i;

  for(i=0; i<entries; i++) {
    if(!strcmp(Entries[i].name, Entry))
      return i;
  }

  Entries[entries].transfer = 0;
  return entries++;

}


void orderEntries(void) {

  record tempEntry;
  int i;
  int numMoves;
  
  numMoves = 0;

  for(i=0;i<entries-1;i++) {
    
    if(Entries[i].transfer < Entries[i+1].transfer) {
      
      numMoves++;
      
      strcpy(tempEntry.name, Entries[i+1].name);
      tempEntry.transfer = Entries[i+1].transfer;

      Entries[i+1].transfer = Entries[i].transfer;
      strcpy(Entries[i+1].name, Entries[i].name);

      Entries[i].transfer = tempEntry.transfer;
      strcpy(Entries[i].name, tempEntry.name);
    }
  
  }

  if(numMoves != 0)
    orderEntries();

}
