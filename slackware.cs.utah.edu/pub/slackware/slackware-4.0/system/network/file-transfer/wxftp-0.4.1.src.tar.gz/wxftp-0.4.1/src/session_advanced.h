/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef SESSION_ADVANCED_H
#define SESSION_ADVANCED_H

#include"wxftp.h"
WXwidget create_session_advanced(WXwidget);

#endif /* SESSION_ADVANCED_H */
