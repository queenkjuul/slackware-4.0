/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef STATUS_H
#define STATUS_H

#include"wxftp.h"
WXwidget create_status(WXwidget);
void append_status(char *);

#endif /* STATUS_H */
