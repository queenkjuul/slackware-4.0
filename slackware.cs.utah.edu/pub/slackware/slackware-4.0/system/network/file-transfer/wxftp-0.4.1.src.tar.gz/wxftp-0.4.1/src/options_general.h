/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef OPTIONS_GENERAL_H
#define OPTIONS_GENERAL_H

#include"wxftp.h"
WXwidget create_options_general(WXwidget);

#endif /* OPTIONS_GENERAL_H */
