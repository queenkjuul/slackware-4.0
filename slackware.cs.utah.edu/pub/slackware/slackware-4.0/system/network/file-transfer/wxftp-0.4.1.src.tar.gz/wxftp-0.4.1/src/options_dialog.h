/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef OPTIONS_DIALOG_H
#define OPTIONS_DIALOG_H

#include"wxftp.h"

WXwidget create_options_dialog(WXwidget);

#endif /* OPTIONS_DIALOG_H */
