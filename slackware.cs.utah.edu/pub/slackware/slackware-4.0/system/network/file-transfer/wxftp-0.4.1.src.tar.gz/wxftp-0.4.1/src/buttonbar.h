/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef BUTTONBAR_H
#define BUTTONBAR_H

#include"wxftp.h"
WXwidget create_buttonbar(WXwidget);
#endif /* BUTTONBAR_H */
