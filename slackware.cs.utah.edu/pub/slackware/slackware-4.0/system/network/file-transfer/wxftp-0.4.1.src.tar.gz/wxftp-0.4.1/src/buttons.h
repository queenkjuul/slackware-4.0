/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef BUTTONS_H
#define BUTTONS_H

#include"wxftp.h"
WXwidget create_buttons(WXwidget,int);

#endif /* BUTTONS_H */
