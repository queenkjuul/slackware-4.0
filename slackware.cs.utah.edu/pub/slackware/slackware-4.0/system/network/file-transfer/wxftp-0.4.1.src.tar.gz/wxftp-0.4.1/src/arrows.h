/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef ARROWS_H
#define ARROWS_H

#include"wxftp.h"
WXwidget create_arrows(WXwidget);

#endif /* ARROWS_H */
