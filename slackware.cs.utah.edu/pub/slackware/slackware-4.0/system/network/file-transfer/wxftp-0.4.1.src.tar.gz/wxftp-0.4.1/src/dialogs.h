/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef DIALOGS_H
#define DIALOGS_H

#include"wxftp.h"
void make_dialogs(WXwidget);

#endif /* DIALOGS_H */
