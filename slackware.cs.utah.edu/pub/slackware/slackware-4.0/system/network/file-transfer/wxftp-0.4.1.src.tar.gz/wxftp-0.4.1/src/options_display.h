/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef OPTIONS_DISPLAY_H
#define OPTIONS_DISPLAY_H

#include"wxftp.h"
WXwidget create_options_display(WXwidget);

#endif /* OPTIONS_DISPLAY_H */
