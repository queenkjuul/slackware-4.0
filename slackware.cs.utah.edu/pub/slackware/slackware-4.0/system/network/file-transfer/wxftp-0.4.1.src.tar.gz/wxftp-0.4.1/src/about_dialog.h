/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef ABOUT_DIALOG_H
#define ABOUT_DIALOG_H

#include"wxftp.h"
WXwidget create_about_dialog(WXwidget);

#endif /* ABOUT_DIALOG_H */
