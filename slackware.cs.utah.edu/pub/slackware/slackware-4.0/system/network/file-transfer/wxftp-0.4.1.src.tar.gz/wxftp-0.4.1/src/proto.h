/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef PROTO_H
#define PROTO_H

#include"wxftp.h"
char get_proto_state(WXwidget);
WXwidget create_proto(WXwidget);

#endif /* PROTO_H */
