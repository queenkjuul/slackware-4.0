/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef SESSION_STARTUP_H
#define SESSION_STARTUP_H

#include"wxftp.h"
WXwidget create_session_startup(WXwidget);

#endif /* SESSION_STARTUP_H */
