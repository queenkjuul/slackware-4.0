/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef SESSION_GENERAL_H
#define SESSION_GENERAL_H

#include"wxftp.h"
WXwidget create_session_general(WXwidget);

#endif /* SESSION_GENERAL_H */
