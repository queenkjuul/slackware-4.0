/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef PANEL_H
#define PANEL_H

#include"wxftp.h"
WXwidget create_panel(WXwidget,int);

#endif /* PANEL_H */
