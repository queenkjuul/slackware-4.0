/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef READ_INIT_H
#define READ_INIT_H

extern char* session_file;
extern char* options_file;
extern char* anonymous_password;
extern char* log_file;
extern FILE* logfile;

int read_init();

#endif
