/* Copyright (c) 1998   Alexander Yukhimets. All rights reserved. */
#ifndef OPTIONS_SOUND_H
#define OPTIONS_SOUND_H

#include"wxftp.h"
WXwidget create_options_sound(WXwidget);

#endif /* OPTIONS_SOUND_H */
