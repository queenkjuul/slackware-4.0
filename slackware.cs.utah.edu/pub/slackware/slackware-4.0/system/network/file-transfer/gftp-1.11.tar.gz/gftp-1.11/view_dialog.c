/*****************************************************************************/
/*  view_dialog.c - view dialog box and ftp routines                         */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

extern struct ftp_window_data window1, window2;
extern struct ftp_transfer_data *file_transfers;
extern pthread_mutex_t transfer_mutex;

static void delete_file(GtkWidget *widget, char *fle);
static struct ftp_window_data *wdata;
static struct ftp_file_data *curfle;

void view_dialog(gpointer data) {
   struct ftp_transfer_data *newtdata, *temptdata;
   
   wdata = (struct ftp_window_data *) data;
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "View: Not connected to a remote site\n");
      return;
   }
   else if(wdata->numselected != 1) {
      ftp_log(LOG_MISC, "View: You must only have one item selected\n");
      return;
   }

   if((curfle = get_next_selected_filename(wdata->host->files)) == NULL) {
      ftp_log(LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
      return;
   }

   if(curfle->flags & FILE_ISDIR) {
      ftp_log(LOG_MISC, "View: %s is a directory. Cannot view it.\n", curfle->file);
      return;
   }
   
   if(wdata->local) view_file(curfle->file, 0, 1);
   else {
      newtdata = create_new_tdata();
      *newtdata->hdata = *(&window2)->host;
      newtdata->hdata->files = mymalloc(sizeof(struct ftp_file_data));
      *newtdata->hdata->files = *curfle;
      strncpy(newtdata->hdata->files->remote_file, newtdata->hdata->files->file, sizeof(newtdata->hdata->files->remote_file));
      make_temp_filename(newtdata->hdata->files->file, sizeof(newtdata->hdata->files->file));
      newtdata->hdata->files->next = NULL;
      newtdata->hdata->files->size = 0;
      newtdata->curfle = newtdata->hdata->files;
      newtdata->hdata->totalfiles = 1;
      newtdata->flags = TRANSFER_DIRECTION | TRANSFER_DONE_DO_VIEW | TRANSFER_SHOW;
      newtdata->hdata->type = FTP_ASCII;
      newtdata->wdata = &window2;

      pthread_mutex_lock(&transfer_mutex);
      if(file_transfers == NULL) file_transfers = newtdata;
      else {
         temptdata = file_transfers;
         while(temptdata->next != NULL) temptdata = temptdata->next;
         temptdata->next = newtdata;
      }
      pthread_mutex_unlock(&transfer_mutex);
   }
}
/*****************************************************************************/
void view_file(char *filename, int del_file, int start_pos) {
   GtkWidget *dialog, *view, *close, *table, *vscroll;
   char tempstr[MAXSTR], *fle;
   FILE *fd;

   fd = fopen(filename, "r");
   if(fd == NULL) {
      ftp_log(LOG_MISC, "View: Cannot open file %s: %s\n", filename, g_strerror(errno));
      return;
   }
   ftp_log(LOG_MISC, "Viewing file %s\n", filename);

   dialog = gtk_dialog_new();
   gtk_window_set_title(GTK_WINDOW(dialog), filename);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), 5);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->vbox), 5);
   gtk_box_set_homogeneous(GTK_BOX(GTK_DIALOG(dialog)->action_area), TRUE);

   table = gtk_table_new(1, 2, FALSE);
   gtk_widget_set_usize(table, 500, 400);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), table, TRUE, TRUE, FALSE);

   view = gtk_text_new(NULL, NULL);
   gtk_text_set_editable(GTK_TEXT(view), FALSE);
   gtk_text_set_word_wrap(GTK_TEXT(view), TRUE);
   gtk_table_attach(GTK_TABLE(table), view, 0, 1, 0, 1,
      GTK_FILL | GTK_EXPAND, GTK_FILL | GTK_EXPAND | GTK_SHRINK, 0, 0);
   gtk_widget_show(view);

   vscroll = gtk_vscrollbar_new(GTK_TEXT(view)->vadj);
   gtk_table_attach(GTK_TABLE(table), vscroll, 1, 2, 0, 1,
      GTK_FILL, GTK_EXPAND | GTK_FILL | GTK_SHRINK, 0, 0);
   gtk_widget_show(vscroll);
   gtk_widget_show(table);

   close = gtk_button_new_with_label("   Close   ");
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), close, FALSE, FALSE, FALSE);
   if(del_file) {
      fle = mymalloc(strlen(filename)+1);
      strcpy(fle, filename);
      gtk_signal_connect(GTK_OBJECT(close), "clicked", GTK_SIGNAL_FUNC(delete_file), (gpointer) fle);
   }
   gtk_signal_connect(GTK_OBJECT(close), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_show(close);

   memset(tempstr, 0, sizeof(tempstr));
   while(fread(tempstr, 1, sizeof(tempstr)-1, fd)) {
      gtk_text_insert(GTK_TEXT(view), NULL, NULL, NULL, tempstr, strlen(tempstr));
      memset(tempstr, 0, sizeof(tempstr));
   }
   fclose(fd);
   gtk_widget_show(dialog);
   if(!start_pos) {
      gtk_adjustment_set_value(GTK_TEXT(view)->vadj, 
         GTK_TEXT(view)->vadj->upper - GTK_TEXT(view)->vadj->page_size);
   }
}
/*****************************************************************************/
static void delete_file(GtkWidget *widget, char *fle) {
   unlink(fle);
   free(fle);
}
/*****************************************************************************/
