/*****************************************************************************/
/*  delete_dialog.c - the delete dialog                                      */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

static void askdel(void);
static void yesCB(GtkWidget *widget, gpointer data);
static void noCB(GtkWidget *widget, gpointer data);
static void yesallCB(GtkWidget *widget, gpointer data);

static struct ftp_window_data *wdata;
static int doall;
static struct ftp_file_data *curfle;

void delete_dialog(gpointer data) {
   wdata = (struct ftp_window_data *) data;
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Delete: Not connected to a remote site\n");
      return;
   }
   else if(wdata->numselected == 0) {
      ftp_log(LOG_MISC, "Delete: You must have at least one item selected\n");
      return;
   }
   doall = 0;
   if((curfle = get_next_selected_filename(wdata->host->files)) == NULL) {
      ftp_log(LOG_MISC, "Internal gFTP Error: Could not find a selected file. This is probably a bug. Please email masneyb@newwave.net about it\n");
      return;
   }
   askdel();
}
/*****************************************************************************/
static void askdel(void) {
   char tempstr[MAXSTR];

   g_snprintf(tempstr, sizeof(tempstr), "Are you sure you want to delete %s?", curfle->file);
   tempstr[sizeof(tempstr)-1] = '\0';

   MakeYesNoDialog("Delete Files/Directories", tempstr, 4,
      "Yes", yesCB, NULL,
      "No", noCB, NULL,
      "Yes to All", yesallCB, NULL,
      "No to All", NULL, NULL);
}
/*****************************************************************************/
static void yesCB(GtkWidget *widget, gpointer data) {
   struct ftp_file_data *tempfle;
   int success, num;
   
   while(curfle != NULL) {
      if(wdata->local == 0) {
         if(curfle->attribs[0] == 'd') success = ftp_rmdir(wdata, wdata->host, curfle->file);
         else success = ftp_rmfile(wdata, wdata->host, curfle->file);
      }
      else {
         if(curfle->attribs[0] == 'd') success = rmdir(curfle->file) == 0;
         else success = unlink(curfle->file) == 0;
         if(!success) {
            ftp_log(LOG_MISC, "Error: Could not remove %s %s: %s\n", curfle->attribs[0] == 'd' ? "directory" : "file", curfle->file, g_strerror(errno));
         }
         else {
            ftp_log(LOG_MISC, "Successfully removed %s %s\n", curfle->attribs[0] == 'd' ? "directory" : "file", curfle->file, curfle->file);
         }
      }
      if(success) {
         num = 0;
         tempfle = wdata->host->files;
         if(tempfle == curfle) {
            gtk_clist_remove(GTK_CLIST(wdata->listbox), 0);
            wdata->host->files = wdata->host->files->next;
            free(curfle);
            curfle = wdata->host->files;
         }
         else {
            while(tempfle->next != curfle) {
               if(tempfle->flags & FILE_SHOWN) num++;
               tempfle = tempfle->next;
            }
            num++;
            gtk_clist_remove(GTK_CLIST(wdata->listbox), num);
            tempfle->next = curfle->next;
            free(curfle);
            curfle = tempfle->next;
         }
         wdata->totalitems--;
      }
      else {
         curfle = curfle->next;
      }
      curfle = get_next_selected_filename(curfle);
      if(curfle != NULL && !doall) {
         askdel();
         return;
      }
   }
}
/*****************************************************************************/
static void noCB(GtkWidget *widget, gpointer data) {
   curfle = get_next_selected_filename(curfle->next);
   if(curfle != NULL) askdel();
}
/*****************************************************************************/
static void yesallCB(GtkWidget *widget, gpointer data) {
   doall = 1;
   yesCB(widget, data);
}
/*****************************************************************************/
int ftp_rmdir(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *dir) {
   if(ftp_sendcommand(1, wdata, hdata, NULL, 0, "RMD %s\r\n", dir) != '2') return(0);
   return(1);
}
/*****************************************************************************/
int ftp_rmfile(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *file) {
   if(ftp_sendcommand(1, wdata, hdata, NULL, 0, "DELE %s\r\n", file) != '2') return(0);
   return(1);
}
/*****************************************************************************/
