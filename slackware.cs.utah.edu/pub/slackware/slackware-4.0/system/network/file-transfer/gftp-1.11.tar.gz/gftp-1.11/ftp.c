/*****************************************************************************/
/*  ftp.c - contains most of the core network routines                       */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"

extern char firewall_host[MAXSTR], firewall_username[MAXSTR], firewall_password[MAXSTR];
extern int use_cache, use_firewall, firewall_port, passive_transfer, smart_remote_symlinks;

int ftp_connect(struct ftp_window_data *wdata, struct ftp_host_data *hdata, struct ftp_transfer_data *tdata) {
   struct sockaddr_in servaddr;
   struct servent *service;
   struct hostent *host;
   char tempstr[MAXSTR], resp, code[5];
   int conn, port, ok, curhost, ftp_proxy;

   ftp_proxy = hdata->firewall && use_firewall;
   if((hdata->sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
      g_snprintf(tempstr, sizeof(tempstr), "Error: Failed to create a socket: %s\n", g_strerror(errno));
      tempstr[sizeof(tempstr)-1] = '\0';
      if(tdata == NULL) ftp_log(LOG_MISC, tempstr);
      else queue_log(LOG_MISC, tempstr);
      return(0);
   }

   g_snprintf(tempstr, sizeof(tempstr), "Lookup up %s\n", 
      ftp_proxy ? firewall_host : hdata->host);
   tempstr[sizeof(tempstr)-1] = '\0';
   if(tdata == NULL) ftp_log(LOG_MISC, tempstr);
   else {
      strncpy(tdata->progressstr, tempstr, sizeof(tdata->progressstr));
      tdata->flags |= TRANSFER_NEED_UPDATED;
   }
   
   memset(&servaddr, 0, sizeof(servaddr));
   servaddr.sin_family = AF_INET;
   if(ftp_proxy) port = htons(firewall_port);
   else if(hdata->port != 0) port = htons(hdata->port);
   else {
      if((service = getservbyname("ftp", "tcp")) == NULL) {
         g_snprintf(tempstr, sizeof(tempstr), "Warning: Could not lookup default ftp port...using 21\n");
         tempstr[sizeof(tempstr)-1] = '\0';
         if(tdata == NULL) ftp_log(LOG_MISC, tempstr);
         else queue_log(LOG_MISC, tempstr);
         port = htons(21);
      }
      else port = service->s_port;
   }
   servaddr.sin_port = port;
   
   if(!(host = gethostbyname(ftp_proxy ? firewall_host : hdata->host))) {
      g_snprintf(tempstr, sizeof(tempstr), "Error: Cannot find host %s :%s\n",
         ftp_proxy ? firewall_host : hdata->host, g_strerror(errno));
      tempstr[sizeof(tempstr)-1] = '\0';
      if(tdata == NULL) ftp_log(LOG_MISC, tempstr);
      else queue_log(LOG_MISC, tempstr);
      return(0);
   }
   
   curhost = 0;
   while(host->h_addr_list[curhost] != NULL) {
      memcpy(&servaddr.sin_addr, host->h_addr_list[curhost], host->h_length);
      if(!ftp_proxy) strncpy(hdata->host, host->h_name, sizeof(hdata->host));
      g_snprintf(tempstr, sizeof(tempstr), "Trying %s:%d\n",
         ftp_proxy ? firewall_host : hdata->host, ntohs(port));
      tempstr[sizeof(tempstr)-1] = '\0';
      if(tdata == NULL) ftp_log(LOG_MISC, tempstr);
      else {
         strncpy(tdata->progressstr, tempstr, sizeof(tdata->progressstr));
         tdata->flags |= TRANSFER_NEED_UPDATED;
      }
      
      if((conn = connect(hdata->sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))) < 0) {
         g_snprintf(tempstr, sizeof(tempstr), "Error: Cannot connect to %s: %s\n",
            ftp_proxy ? firewall_host : hdata->host, g_strerror(errno));
         tempstr[sizeof(tempstr)-1] = '\0';
         if(tdata == NULL) ftp_log(LOG_MISC, tempstr);
         else queue_log(LOG_MISC, tempstr);
      }
      else break;
      curhost++;
   }
   if(host->h_addr_list[curhost] == NULL) {
      g_snprintf(tempstr, sizeof(tempstr), "Error: Tried connecting to all aliases of %s: Giving up\n",
         ftp_proxy ? firewall_host : hdata->host);
      tempstr[sizeof(tempstr)-1] = '\0';
      if(tdata == NULL) ftp_log(LOG_MISC, tempstr);
      else queue_log(LOG_MISC, tempstr);
      return(0);
   }

   g_snprintf(tempstr, sizeof(tempstr), "Connected to %s:%d\n",
      ftp_proxy ? firewall_host : hdata->host,
      ftp_proxy ? firewall_port : ntohs(port));
   tempstr[sizeof(tempstr)-1] = '\0';
   if(tdata == NULL) ftp_log(LOG_MISC, tempstr);
   else {
      strncpy(tdata->progressstr, tempstr, sizeof(tdata->progressstr));
      tdata->flags |= TRANSFER_NEED_UPDATED;
   }

   *code = '\0';
   do {
      ftp_read_line(hdata->sockfd, &hdata->recvdata, (char *) &tempstr, sizeof(tempstr));
      if(*code == '\0') {
         strncpy(code, tempstr, 4);
         code[4] = '\0';
      }
#ifdef DEBUG
      printf("(%d) <- %s\n", tdata == NULL, tempstr);
#endif
      if(tdata == NULL) ftp_log(LOG_RECV, "%s\n", tempstr);
         
   } while((strlen(tempstr) > 3 && (tempstr[0] == ' ' || tempstr[3] == '-')) || (strncmp(code, tempstr, 3) != 0));

   /* Log into firewall (if there is one) */
   ok = 0;
   if(ftp_proxy) {
      if(tdata != NULL) {
         strncpy(tdata->progressstr, "Logging into firewall", sizeof(tdata->progressstr));
         tdata->flags |= TRANSFER_NEED_UPDATED;
      }
      resp = ftp_sendcommand(tdata == NULL, wdata, hdata, NULL, 0, "USER %s\r\n", firewall_username);
      if(resp == '2') ok = 1;
      else if(resp == '3') {
         if(ftp_sendcommand(tdata == NULL, wdata, hdata, NULL, 0, "PASS %s\r\n", firewall_password) == '2') ok = 1;
      }
   }

   if(tdata != NULL) {
      strncpy(tdata->progressstr, "Logging into FTP server", sizeof(tdata->progressstr));
      tdata->flags |= TRANSFER_NEED_UPDATED;
   }

   if(hdata->firewall && use_firewall == FIREWALL_LOGIN_USERPASS && ok) {
      ok = 0;
      resp = ftp_sendcommand(tdata == NULL, wdata, hdata, NULL, 0, "USER %s@%s\r\n", hdata->user, hdata->host);
   }
   else if(hdata->firewall && use_firewall == FIREWALL_LOGIN_SITE && ok) {
      ok = 0;
      if(ftp_sendcommand(tdata == NULL, wdata, hdata, NULL, 0, "SITE %s\r\n", hdata->host) == '3') ok = 1;
   }

   if(!ftp_proxy || (hdata->firewall && use_firewall == FIREWALL_LOGIN_SITE)) {
      ok = 0;
      resp = ftp_sendcommand(tdata == NULL, wdata, hdata, NULL, 0, "USER %s\r\n", hdata->user);
   }

   if(resp == '2') ok = 1;
   else if(resp == '3') {
      if(ftp_sendcommand(tdata == NULL, wdata, hdata, NULL, 0, "PASS %s\r\n", hdata->passwd) == '2') ok = 1;
   }
   if(!ok) {
      g_snprintf(tempstr, sizeof(tempstr), "Error: Bad username/password\n");
      tempstr[sizeof(tempstr)-1] = '\0';
      if(tdata == NULL) {
         ftp_log(LOG_MISC, tempstr);
         viewlog(NULL);
      }
      else queue_log(LOG_MISC, tempstr);
      ftp_disconnect(wdata, hdata, tdata == NULL);
      return(0);
   }
   if(hdata->dir[0] != '\0') ftp_chdir(wdata, hdata, hdata->dir);
   return(1);
}   
/*****************************************************************************/
int ftp_init_data_conn(struct ftp_window_data *wdata, struct ftp_host_data *hdata) {
   char tempstr[MAXSTR], *pos, *pos1, resp;
   struct sockaddr_in data_addr;
   unsigned int datafd, i, data_addr_len, temp[6], use_port;
   unsigned char ad[6];

   use_port = 1;
   if((datafd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
      if(wdata->host == hdata) {
         ftp_log(LOG_MISC, "Error: Failed to create a socket: %s\n", g_strerror(errno));
      }
      return(0);
   }
   memset(&data_addr, 0, sizeof(data_addr));
   data_addr.sin_family = AF_INET;

   if(passive_transfer) {
      if((resp = ftp_sendcommand(wdata->host == hdata, wdata, hdata, tempstr, sizeof(tempstr), "PASV\r\n")) != '2') {
         if(resp != '5') {
            if(wdata->host == hdata) {
               ftp_log(LOG_MISC, "Error: Bad response from FTP server %s\n", hdata->host);
            }
            ftp_disconnect(wdata, hdata, wdata->host == hdata);
            return(0);
         }
      }
      else {
         use_port = 0;
         pos = tempstr;
         pos = pos+4;
         while(!isdigit(*pos) && *pos != '\0') pos++;
         if(*pos == '\0') {
            if(wdata->host == hdata) {
               ftp_log(LOG_MISC, "Error: Bad response from FTP server %s\n", hdata->host);
            }
            ftp_disconnect(wdata, hdata, wdata->host == hdata);
            return(0);
         }
         if(sscanf(pos, "%d,%d,%d,%d,%d,%d", &temp[0], &temp[1], &temp[2], &temp[3], &temp[4], &temp[5]) != 6) {
            if(wdata->host == hdata) {
               ftp_log(LOG_MISC, "Error: Bad response from FTP server %s\n", hdata->host);
            }
            ftp_disconnect(wdata, hdata, wdata->host == hdata);
            return(0);
         }
         for(i=0; i<6; i++) ad[i] = (unsigned char) (temp[i] & 0xff);

         memcpy(&data_addr.sin_addr, &ad[0], 4);
         memcpy(&data_addr.sin_port, &ad[4], 2);
         if(connect(datafd, (struct sockaddr *) &data_addr, sizeof(data_addr)) < 0) {
            if(wdata->host == hdata) {
               ftp_log(LOG_MISC, "Error: Cannot create data connection to %s: %s\n", hdata->host, g_strerror(errno));
            }
            ftp_disconnect(wdata, hdata, wdata->host == hdata);
            return(0);
         }
      }
   }

   if(use_port) {
      data_addr_len = sizeof(data_addr);
      getsockname(hdata->sockfd, &data_addr, &data_addr_len);
      data_addr.sin_port = 0;
      if(bind(datafd, &data_addr, sizeof(data_addr)) == -1) {
         if(wdata->host == hdata) {
            ftp_log(LOG_MISC, "Error: Cannot bind a port: %s\n", g_strerror(errno));
         }
         ftp_disconnect(wdata, hdata, wdata->host == hdata);
      }
      getsockname(datafd, &data_addr, &data_addr_len);
      if(listen(datafd, 1) == -1) {
         if(wdata->host == hdata) {
            ftp_log(LOG_MISC, "Error: Cannot listen on port %ld: %s\n", ntohs(data_addr.sin_port), g_strerror(errno));
         }
         ftp_disconnect(wdata, hdata, wdata->host == hdata);
      }
      pos = (char *) &data_addr.sin_addr;
      pos1 = (char *) &data_addr.sin_port;
      if(ftp_sendcommand(wdata->host == hdata, wdata, hdata, NULL, 0, "PORT %d,%d,%d,%d,%d,%d\r\n",
            pos[0] & 0xff, pos[1] & 0xff, pos[2] & 0xff, pos[3] & 0xff,
            pos1[0] & 0xff, pos1[1] & 0xff) != '2') {

         if(wdata->host == hdata) {
            ftp_log(LOG_MISC, "Error: Bad response from FTP server %s\n", hdata->host);
         }
         ftp_disconnect(wdata, hdata, wdata->host == hdata);
         return(0);
      }
   }
   return(datafd);
}
/*****************************************************************************/
int ftp_accept_port_conn(struct ftp_window_data *wdata, struct ftp_host_data *hdata, int datafd) {
   struct sockaddr_in cli_addr;
   unsigned int cli_addr_len, infd;

   cli_addr_len = sizeof(cli_addr);
   if((infd = accept(datafd, &cli_addr, &cli_addr_len)) == -1) {
      if(wdata->host == hdata) {
         ftp_log(LOG_MISC, "Error: Bad response from FTP server %s\n", hdata->host);
      }
      ftp_disconnect(wdata, hdata, wdata->host == hdata);
      return(0);
   }
   close(datafd);
   return(infd);
}
/*****************************************************************************/
int ftp_disconnect(struct ftp_window_data *wdata, struct ftp_host_data *hdata, int log) {
   int ret;
   
   if(ftp_sendcommand(log, wdata, hdata, NULL, 0, "QUIT\r\n") != '2') {
      if(log) {
         ftp_log(LOG_MISC, "Error: Bad response from FTP server %s\n", hdata->host);
      }
      ret = 0;
   }
   else ret = 1;
   close(hdata->sockfd);
   
   if(wdata->host == hdata) {
      delete_ftp_file_info(wdata);
      wdata->local = -1;
      update_ftp_info(wdata);
   }
   return(ret);
}
/*****************************************************************************/
int ftp_list_files(struct ftp_window_data *wdata, int load_from_cache) {
   gtk_clist_freeze(GTK_CLIST(wdata->listbox));
   wdata->totalitems = wdata->numselected = 0;
   wdata->local = 0;

   ftp_pwd(wdata, wdata->host, wdata->host->dir, sizeof(wdata->host->dir), 1);
   update_ftp_info(wdata);

   wdata->host->files = get_remote_files(wdata, wdata->host, NULL, &wdata->totalitems, load_from_cache, 1, GTK_LABEL(wdata->hoststxt));

   sortrows(GTK_CLIST(wdata->listbox), wdata->sortcol, (gpointer) wdata);
   update_ftp_info(wdata);
   gtk_clist_thaw(GTK_CLIST(wdata->listbox));
   return(wdata->host->files != NULL);
}
/*****************************************************************************/
struct ftp_file_data *get_remote_files(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *path, int *total, int load_from_cache, int log, GtkLabel *up_wid) {
   char tempstr[MAXSTR], logstr[MAXSTR], description[MAXSTR], commastr[20], curdir[MAXSTR];
   struct ftp_file_data *files, *newfle, *lastfle;
   struct ftp_queued_data qdata;
   int datafd, got, isdotdot = 0;
   size_t dltotal;
   time_t lasttime;
   FILE *fd = NULL;
   int cached;
   
   *total = 0;
   if(path != NULL) {
      strncpy(curdir, wdata->host->dir, sizeof(curdir));
      curdir[sizeof(curdir)-1] = '\0';
      if(!ftp_chdir(wdata, hdata, path)) return(NULL);
   }

   if(up_wid != NULL) {
      update_ftp_info(wdata);
      gtk_label_set(up_wid, "Receiving file names...");
      fix_display();
   }
   
   g_snprintf(description, sizeof(description), "ftp://%s:%s@%s:%ld%s", 
      hdata->user, hdata->passwd, hdata->host, 
      hdata->port == 0 ? 21 : hdata->port, path == NULL ? hdata->dir : path);
   description[sizeof(description)-1] = '\0';
   remove_double_slashes(description+6);

   if(use_cache && load_from_cache && (fd = find_cache_entry(description)) != NULL) {
      cached = 1;
   }
   else {
      cached = 0;
      if(use_cache) fd = new_cache_entry(description);
   }
   if(!cached) {
      if((datafd = ftp_init_data_conn(wdata, hdata)) == 0) {
         update_ftp_info(wdata);
         return(NULL);
      }
      if(ftp_sendcommand(1, wdata, hdata, NULL, 0, smart_remote_symlinks ? "LIST -L\r\n" : "LIST\r\n") != '1') {
         ftp_log(LOG_MISC, "Error: Cannot get directory listing\n");
         ftp_disconnect(wdata, hdata, 1);
         update_ftp_info(wdata);
         return(NULL);
      }
      if(!passive_transfer) datafd = ftp_accept_port_conn(wdata, hdata, datafd);
   }
   else datafd = 0; /* To hush gcc warnings */
   
   files = lastfle = NULL;
   lasttime = time(NULL);
   dltotal = 0;
   got = 0;
   memset(qdata.recvdata, 0, MAXSTR);
   qdata.pos = qdata.recvdata;
   while(cached ? (fgets(tempstr, sizeof(tempstr), fd) != NULL) :
      (got = ftp_read_line(datafd, &qdata, (char *) &tempstr, sizeof(tempstr))) > 0) {

      if(cached) tempstr[strlen(tempstr)-1] = '\0';
      else {
#ifdef DEBUG
         printf("Dir list: %s\n", tempstr);
#endif
         dltotal += got;
         if(up_wid != NULL && time(NULL)-lasttime >= 1) {
            insert_commas(dltotal, commastr, sizeof(commastr));
            g_snprintf(logstr, sizeof(logstr), "Retrieving file names...%s bytes", commastr);
            logstr[sizeof(logstr)-1] = '\0';
            gtk_label_set(up_wid, logstr);
            fix_display();
            lasttime = time(NULL);
         }
      }
      newfle = mymalloc(sizeof(struct ftp_file_data));
      if(ftp_parse_file_listing(newfle, tempstr) && strcmp(newfle->file, ".") != 0) {
         if(use_cache && !cached && fd != NULL) {
            fwrite(tempstr, 1, strlen(tempstr), fd);
            fwrite("\n", 1, 1, fd);
         }
         if(strcmp(newfle->file, "..") == 0) isdotdot = 1;
         newfle->flags = 0;
         if(strchr(newfle->attribs, 'd') != NULL) newfle->flags |= FILE_ISDIR;
         if(strchr(newfle->attribs, 'l') != NULL) newfle->flags |= FILE_ISLINK;
         if((strchr(newfle->attribs, 'x') != NULL) && !(newfle->flags & FILE_ISDIR)
            && !(newfle->flags & FILE_ISLINK)) newfle->flags |= FILE_ISEXE;
         newfle->next = NULL;
         if(lastfle == NULL) files = newfle;
         else lastfle->next = newfle;
         lastfle = newfle;
         (*total)++;
      }
      else free(newfle);
   }
   if(fd != NULL) fclose(fd);
   if(!isdotdot && strcmp(curdir, "/") != 0) {
      newfle = mymalloc(sizeof(struct ftp_file_data));
      strcpy(newfle->file, "..");
      newfle->size = 0;
      newfle->user[0] = newfle->group[0] = newfle->attribs[0] = newfle->dt[0] = '\0';
      newfle->flags = FILE_ISDIR;
      newfle->next = NULL;
      if(lastfle == NULL) files = newfle;
      else lastfle->next = newfle;
      (*total)++;
   }

   if(!cached) {
      close(datafd);
      if(ftp_read_response(1, wdata, hdata, NULL, 0) != '2') {
         ftp_log(LOG_MISC, "Error: Bad response from FTP server\n");
         ftp_disconnect(wdata, hdata, TRUE);
         update_ftp_info(wdata);
         return(NULL);
      }
   }
   if(wdata->host == hdata) wdata->cached = cached;
   if(path != NULL) if(!ftp_chdir(wdata, hdata, curdir)) return(NULL);
   return(files);
}
/*****************************************************************************/
char *ftp_pwd(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *dir, int len, int log) {
   char *pos;
      
   if(ftp_sendcommand(log, wdata, hdata, dir, len, "PWD\r\n") != '2') {
      ftp_log(LOG_MISC, "Error: Cannot get current directory\n;");
      ftp_disconnect(wdata, hdata, TRUE);
      return(0);
   }
   pos = strchr(dir, '"');
   if(pos != NULL) dir = pos+1;
   else *dir = '\0';

   pos = strchr(dir, '"');
   if(pos != NULL) *pos = '\0';
   else *dir = '\0';

   strncpy(hdata->dir, dir, sizeof(hdata->dir));
   return(dir);
}
/*****************************************************************************/
int ftp_read_line(int sockfd, struct ftp_queued_data *qdata, char *buf, int size) {
   int i;

   for(i=0; i<size-1; i++) {
      if(*qdata->pos == '\0') {
         memset(qdata->recvdata, 0, MAXSTR);
         if(!read(sockfd, qdata->recvdata, MAXSTR-1)) {
            if(i == 0) return(0);
            else break;
         }
         qdata->pos = qdata->recvdata;
      }
      if(*qdata->pos == '\n') {
         qdata->pos++;
         break;
      }
      else buf[i] = *qdata->pos++;
   }
   buf[i] = '\0';
   if(i > 0 && buf[i-1] == '\r') buf[i-1] = '\0';
   return(i);
}
/*****************************************************************************/
char ftp_sendcommand(int log, struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *destbuf, size_t destlen, char *command, ...) {
   char tempstr[MAXSTR];
   va_list argp;
   
   va_start(argp, command);
   g_vsnprintf(tempstr, sizeof(tempstr), command, argp);
   tempstr[sizeof(tempstr)-1] = '\0';
#ifdef DEBUG
   printf("(%d) -> %s", log, tempstr);
#endif
   if(log) {
      if(strncmp(tempstr, "PASS", 4) == 0) {
         ftp_log(LOG_SEND, "PASS xxxx\n");
      }
      else {
         if(strlen(tempstr) > 1 && tempstr[strlen(tempstr)-2] == '\r') {
            tempstr[strlen(tempstr)-2] = '\n';
            tempstr[strlen(tempstr)-1] = '\0';
         }
         ftp_log(LOG_SEND, "%s", tempstr);
      }
   }
   if(write(hdata->sockfd, tempstr, strlen(tempstr)) == -1) {
      ftp_log(LOG_MISC, "Error: Cannot write to socket: %s\n", g_strerror(errno));
      if(wdata->host == hdata) {
         delete_ftp_file_info(wdata);
         wdata->local = -1;
         update_ftp_info(wdata);
      }
      return(0);
   }
   return(ftp_read_response(log, wdata, hdata, destbuf, destlen));
}
/*****************************************************************************/
char ftp_read_response(int log, struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *buf, size_t len) {
   char tempstr[MAXSTR], code[4];
   
/*   strncpy(tempstr, "   -", sizeof(tempstr));
   ftp_read_line(hdata->sockfd, &hdata->recvdata, (char *) &tempstr, sizeof(tempstr));
   strncpy(code, tempstr, 3);
   code[3] = '\0';*/
   *code = '\0';
   do {
      ftp_read_line(hdata->sockfd, &hdata->recvdata, (char *) &tempstr, sizeof(tempstr));
      if(*code == '\0') {      
         strncpy(code, tempstr, 3);
         code[3] = '\0';
      }
#ifdef DEBUG
      printf("(%d) <- %s\n", log, tempstr);
#endif
      if(log) ftp_log(LOG_RECV, "%s\n", tempstr);
   } while((strlen(tempstr) > 3 && (tempstr[0] == ' ' || tempstr[3] == '-')) || (strncmp(code, tempstr, 3) != 0));

/*   } while((tempstr[0] == ' ' || (strlen(tempstr) > 2 && tempstr[3] == '-')) &&
        (ftp_read_line(hdata->sockfd, &hdata->recvdata, (char *) &tempstr, sizeof(tempstr)) > 0) &&
        strncmp(tempstr, resp, 3) == 0);*/

   if(buf != NULL) strncpy(buf, tempstr, len);
   return(tempstr[0]);
}   
/*****************************************************************************/
int ftp_chdir(struct ftp_window_data *wdata, struct ftp_host_data *hdata, char *newdir) {
   if(strcmp(newdir, "..") == 0) {
      if(ftp_sendcommand(wdata->host == hdata, wdata, hdata, NULL, 0, "CDUP\r\n") != '2') return(0);
   }
   else {
      if(ftp_sendcommand(wdata->host == hdata, wdata, hdata, NULL, 0, "CWD %s\r\n", newdir) != '2') return(0);
   }
   return(1);
}
/*****************************************************************************/
