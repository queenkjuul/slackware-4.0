/*****************************************************************************/
/*  misc_dialogs.c - various dialogs                                         */
/*  Copyright (C) 1998-1999 Brian Masney <masneyb@newwave.net>               */
/*                                                                           */
/*  This program is free software; you can redistribute it and/or modify     */
/*  it under the terms of the GNU General Public License as published by     */
/*  the Free Software Foundation; either version 2 of the License, or        */
/*  (at your option) any later version.                                      */
/*                                                                           */
/*  This program is distributed in the hope that it will be useful,          */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*  GNU General Public License for more details.                             */
/*                                                                           */
/*  You should have received a copy of the GNU General Public License        */
/*  along with this program; if not, write to the Free Software              */
/*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111 USA      */
/*****************************************************************************/

#include "ftp.h"
extern struct ftp_transfer_data *file_transfers;
extern int save_geometry, listbox_local_width, listbox_remote_width, 
   listbox_file_height, log_height, transfer_height;
extern GtkWidget *local_frame, *remote_frame, *log_table, *transfer_scroll,
   *logwdw;
static GtkWidget *edit;

GtkWidget *MakeEditDialog(char *diagtxt, char *infotxt, 
   char *oktxt, void (*okfunc)(), void *okptr,
   char *canceltxt, void (*cancelfunc)(), void *cancelptr) {
   
   GtkWidget *text, *edit, *ok, *cancel, *dialog;
   
   dialog = gtk_dialog_new();
   gtk_grab_add(dialog);
   gtk_window_set_title(GTK_WINDOW(dialog), diagtxt);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), 10);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->vbox), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->action_area), 15);
   gtk_box_set_homogeneous(GTK_BOX(GTK_DIALOG(dialog)->action_area), TRUE);
   gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
   if(cancelfunc) {
      gtk_signal_connect(GTK_OBJECT(dialog), "delete_event", GTK_SIGNAL_FUNC(cancelfunc), (gpointer) cancelptr);
      gtk_signal_connect(GTK_OBJECT(dialog), "destroy", GTK_SIGNAL_FUNC(cancelfunc), (gpointer) cancelptr);
   }
   gtk_signal_connect(GTK_OBJECT(dialog), "delete_event", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_signal_connect(GTK_OBJECT(dialog), "destroy", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   
   text = gtk_label_new(infotxt);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), text, TRUE, TRUE, FALSE);
   gtk_widget_show(text);
   
   edit = gtk_entry_new_with_max_length(MAXSTR);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), edit, TRUE, TRUE, FALSE);
   if(okfunc) {
      gtk_signal_connect(GTK_OBJECT(edit), "activate", GTK_SIGNAL_FUNC(okfunc), (gpointer) okptr);
   }
   gtk_signal_connect(GTK_OBJECT(edit), "activate", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_show(edit);

   ok = gtk_button_new_with_label(oktxt);
   GTK_WIDGET_SET_FLAGS(ok, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), ok, TRUE, TRUE, FALSE);
   if(okfunc) {
      gtk_signal_connect(GTK_OBJECT(ok), "clicked", GTK_SIGNAL_FUNC(okfunc), (gpointer) okptr);
   }
   gtk_signal_connect(GTK_OBJECT(ok), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   gtk_widget_grab_default(ok);
   gtk_widget_show(ok);
            
   cancel = gtk_button_new_with_label(canceltxt);
   GTK_WIDGET_SET_FLAGS(cancel, GTK_CAN_DEFAULT);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), cancel, TRUE, TRUE, FALSE);
   gtk_signal_connect(GTK_OBJECT(cancel), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
   if(cancelfunc) {
      gtk_signal_connect(GTK_OBJECT(cancel), "clicked", GTK_SIGNAL_FUNC(cancelfunc), (gpointer) cancelptr);
   }
   gtk_widget_show(cancel);

   gtk_widget_show(dialog);
   return(edit);
}         
/*****************************************************************************/
GtkWidget *MakeYesNoDialog(char *diagtxt, char *infotxt, int num, ...) {
   
   GtkWidget *text, *tempwid, *dialog;
   typedef void (*func)();
   func myfunc;
   va_list argp;
   char *tempstr;
   void *ptr;
   int i;
   
   dialog = gtk_dialog_new();
   gtk_grab_add(dialog);
   gtk_window_set_title(GTK_WINDOW(dialog), diagtxt);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), 10);
   gtk_container_border_width(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->vbox), 5);
   gtk_box_set_spacing(GTK_BOX(GTK_DIALOG(dialog)->action_area), 15);
   gtk_box_set_homogeneous(GTK_BOX(GTK_DIALOG(dialog)->action_area), TRUE);
   gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_MOUSE);
   
   text = gtk_label_new(infotxt);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), text, TRUE, TRUE, FALSE);
   gtk_widget_show(text);

   va_start(argp, num);
   for(i=0; i<num; i++) {
      tempstr = va_arg(argp, char *);
      myfunc = va_arg(argp, func);
      ptr = va_arg(argp, void *);
      
      tempwid = gtk_button_new_with_label(tempstr);
      gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area), tempwid, TRUE, TRUE, TRUE);
      if(myfunc) {
         gtk_signal_connect(GTK_OBJECT(tempwid), "clicked", GTK_SIGNAL_FUNC(myfunc), (gpointer) ptr);
      }
      gtk_signal_connect(GTK_OBJECT(tempwid), "clicked", GTK_SIGNAL_FUNC(delete_modal_dialog), (gpointer) dialog);
      gtk_widget_show(tempwid);
   }
            
   gtk_widget_show(dialog);
   return(dialog);
}         
/*****************************************************************************/
void delete_modal_dialog(GtkWidget *widget, gpointer data) {
   gtk_grab_remove((GtkWidget *) data);
   gtk_widget_destroy((GtkWidget *) data);
}
/*****************************************************************************/
void change_filespec(struct ftp_window_data *wdata) {
   if(wdata->local == -1) {
      ftp_log(LOG_MISC, "Change Filespec: Not connected to a remote site\n");
      return;
   }
   edit = MakeEditDialog("Change Filespec", "Enter the new file specification",
      "Change", dochange_filespec, wdata,
      "Cancel", NULL, NULL);
}
/*****************************************************************************/
void dochange_filespec(GtkWidget *widget, struct ftp_window_data *wdata) {
   struct ftp_file_data *tempfle;
   char edttext[20];

   strncpy(edttext, gtk_entry_get_text(GTK_ENTRY(edit)), sizeof(edttext));
   edttext[sizeof(edttext)-1] = '\0';
   if(*edttext == '\0') {
     ftp_log(LOG_MISC, "Change Filespec: Operation canceled...you must enter a string\n");
     return;
   }
   strncpy(wdata->filespec, edttext, sizeof(wdata->filespec));
   wdata->filespec[sizeof(wdata->filespec)-1] = '\0';
   wdata->numselected = 0;

   gtk_clist_freeze(GTK_CLIST(wdata->listbox));
   gtk_clist_clear(GTK_CLIST(wdata->listbox));
   tempfle = wdata->host->files;
   while(tempfle != NULL) {
      add_file_listbox(wdata, tempfle);
      tempfle = tempfle->next;
   }
   gtk_clist_thaw(GTK_CLIST(wdata->listbox));
   update_ftp_info(wdata);
}
/*****************************************************************************/
void exitCB(gpointer data) {
   if(file_transfers == NULL) doexit(NULL, NULL);
   else {
      MakeYesNoDialog("Exit", "There are file transfers in progress.\nAre you sure you want to exit?", 2,
         "Exit", doexit, NULL,
         "Don't Exit", NULL, NULL);
   }
}
/*****************************************************************************/
void doexit(GtkWidget *widget, gpointer data) {
   if(save_geometry) {
      listbox_local_width = GTK_WIDGET(local_frame)->allocation.width;
      listbox_remote_width = GTK_WIDGET(remote_frame)->allocation.width;
      listbox_file_height = GTK_WIDGET(remote_frame)->allocation.height;
      log_height = GTK_WIDGET(log_table)->allocation.height;
      transfer_height = GTK_WIDGET(transfer_scroll)->allocation.height;
   }
   write_config_file();
   clear_cache_files();
   gtk_main_quit();
}
/*****************************************************************************/
void viewlog(gpointer data) {
   char tempstr[MAXSTR], *txt;
   guint textlen;
   FILE *fd;

   make_temp_filename(tempstr, sizeof(tempstr));
   fd = fopen(tempstr, "w");
   if(fd == NULL) {
      ftp_log(LOG_MISC, "Error: Cannot open %s: %s\n", tempstr, g_strerror(errno));
      return;
   }
   textlen = gtk_text_get_length(GTK_TEXT(logwdw));
   txt = gtk_editable_get_chars(GTK_EDITABLE(logwdw), 0, -1);
   if(!fwrite(txt, 1, textlen, fd)) {
      ftp_log(LOG_MISC, "Error: Error writing to %s\n", tempstr);
   }
   fclose(fd);
   view_file(tempstr, 1, 0);
}
/*****************************************************************************/
void savelog(gpointer data) {
   GtkWidget *filew;
   
   filew = gtk_file_selection_new ("Save Log");

   gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button), "clicked", GTK_SIGNAL_FUNC(dosavelog), filew);
   gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button), "clicked", GTK_SIGNAL_FUNC(savelog_destroy), filew);
   gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->cancel_button), "clicked", GTK_SIGNAL_FUNC(savelog_destroy), filew);
   gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew), "gftp.log");
   gtk_widget_show(filew);
}
/*****************************************************************************/
void dosavelog(GtkWidget *widget, GtkFileSelection *fs) {
   char *filename, *txt;
   guint textlen;
   FILE *fd;

   filename = gtk_file_selection_get_filename(GTK_FILE_SELECTION (fs));
   fd = fopen(filename, "w");
   if(fd == NULL) {
      ftp_log(LOG_MISC, "Error: Cannot open %s: %s\n", filename, g_strerror(errno));
      return;
   }
   textlen = gtk_text_get_length(GTK_TEXT(logwdw));
   txt = gtk_editable_get_chars(GTK_EDITABLE(logwdw), 0, -1);
   if(!fwrite(txt, 1, textlen, fd)) {
      ftp_log(LOG_MISC, "Error: Error writing to %s\n", filename);
   }
   else {
      ftp_log(LOG_MISC, "Successfully wrote the log file to %s\n", filename);
   }
   fclose(fd);
   free(txt);
}
/*****************************************************************************/
void savelog_destroy(GtkWidget *widget, GtkWidget *dialog) {
   gtk_widget_destroy(dialog);
}
/*****************************************************************************/
void clearlog(gpointer data) {
   guint pos;
   
   pos = gtk_text_get_length(GTK_TEXT(logwdw));
   gtk_text_set_point(GTK_TEXT(logwdw), pos);
   gtk_text_backward_delete(GTK_TEXT(logwdw), pos);
}
/*****************************************************************************/
