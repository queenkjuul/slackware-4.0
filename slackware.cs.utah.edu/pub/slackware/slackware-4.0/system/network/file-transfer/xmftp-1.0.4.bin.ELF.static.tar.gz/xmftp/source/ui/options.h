/* options.h - Settings */

/* Bring up dialog for user settings */
void general_opts(Widget w, XtPointer client_data, XtPointer call_data);
