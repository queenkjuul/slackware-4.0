#include "forms.h"
#include "form.h"

int main(int argc, char *argv[])
{
   ClearSite();
   
   fl_initialize(&argc, argv, "FreeFly", 0, 0);

   create_the_forms();

   /* fill-in form initialization code */

   /* show the first form */
   fl_show_form(test,FL_PLACE_CENTER,FL_FULLBORDER,"FreeFly FTP");
   fl_addto_choice(TransferType, "ASCII|Binary|Local 8");
   fl_addto_choice(TransferMode, "Stream|Block|Compressed");
   fl_set_menu(Menu_File, "Open...|Close|Quit");
   fl_set_menu(Menu_Options, "General...");
   fl_set_input_return(CommandInput, FL_RETURN_END);
//   fl_set_slider_return(Slider, FL_RETURN_CHANGED);
   SliderChange(Slider, 0L);
   DoLocalCwd(".");
   for(;;)
     fl_do_forms();
   return 0;
}
