#include "forms.h"
#include "form.h"

#include <stdlib.h>
#include <stdarg.h>

#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <arpa/telnet.h>
#include <arpa/ftp.h>

#include <sys/stat.h>
#include <dirent.h>

struct {
   int Type;
   int ViewShown;
   int Mode;
   char * SiteName;
   FILE * Control;
   FILE * Data;
   unsigned long int host;
   int Connected;
   unsigned long PasvH;
   unsigned short PasvP;
   int Apsv;
   char CWD[256];
   double SliderVal;
} FTPState;

void DoList();
void DoLocalList();

void ClearSite()
{
   FTPState.Type=1;
   FTPState.ViewShown=0;
   FTPState.Mode=1;
   FTPState.SiteName=NULL;
   FTPState.Control=NULL;
   FTPState.Data=NULL;
   FTPState.host=-1;
   FTPState.Connected=0;
   FTPState.PasvH=-1;
   FTPState.PasvP=0;
   FTPState.Apsv=1;
   FTPState.SliderVal=0.0;
}

void SendCommand(const char * fmt, ...)
{
   char buf[256];
   char logbuf[256];
   va_list ap;
   va_start(ap, fmt);
   vsprintf(buf, fmt, ap);
   va_end(ap);
   fputs(buf, FTPState.Control);
   sprintf(logbuf, ">>> %s", buf);
   logbuf[strlen(logbuf)-1]=0;
   fl_add_browser_line(LogWindow, logbuf);
}

int GetReturn(int CheckPasv)
{
   char buf[256];
   int ret=0;
   
   while(fgets(buf, sizeof(buf)-1, FTPState.Control))
     {
	char log[256];
	sprintf(log, "<<< %s", buf);
	log[strlen(log)-1]=0;
	fl_add_browser_line(LogWindow, log);
	fl_set_browser_topline(LogWindow, fl_get_browser_maxline(LogWindow)-fl_get_browser_screenlines(LogWindow)+1);
	
	if(isdigit(buf[0])&&isdigit(buf[1])&&isdigit(buf[2])&&(buf[3]==' '))
	  {
	     int i;
	     ret=0;
	     ret+=buf[0]-'0';
	     ret<<=4;
	     ret+=buf[1]-'0';
	     ret<<=4;
	     ret+=buf[2]-'0';
	     if(CheckPasv)
	       {
		  /*
		   * Search for:
		   * 123,45,67,89,123,45
		   */
		  for(i=4; i!=strlen(buf); i++)
		    {
		       if(isdigit(buf[i]))
			 {
			    int j;
			    
			    for(j=i; j!=strlen(buf) && (isdigit(buf[j]) || buf[j]==','); j++);
			    if(j!=strlen(buf))
			      {
				 int x;
				 int y;
				 
				 FTPState.PasvP=FTPState.PasvH=0;
				 for(x=0, y=0; i!=j; i++)
				   {
				      if(buf[i]==',')
					{
					   x++;
					   if(x<=4)
					     {
						FTPState.PasvH<<=8;
						FTPState.PasvH+=y;
					     }
					   else
					     {
						FTPState.PasvP+=y;
						FTPState.PasvP<<=8;
					     }
					   y=0;
					}
				      else
					{
					   y*=10;
					   y+=(buf[i]-'0');
					}
#ifdef DEBUG_PASV
				      fprintf(stderr, "PASV connection now %X:%d (%d,%c)\n", FTPState.PasvH, FTPState.PasvP, y, buf[i]);
#endif
				   }
				 FTPState.PasvP+=y;
#ifdef DEBUG_PASV
				 fprintf(stderr, "PASV connection now %X:%d (%d,%c)\n", FTPState.PasvH, FTPState.PasvP, y, buf[i]);
#endif
			      }
			 }
		    }
	       }
	     return(ret);
	  }
     }
   return(0x421);
}

void ConnectPassive()
{
   int s;
   int ret;
   struct sockaddr_in sin;
   
   if(!FTPState.Apsv)
     {
	SendCommand("PASV\r\n");
	GetReturn(1);
     }
   
   s=socket(AF_INET, SOCK_STREAM, 0);
   if(s<0)
     {
	int err=errno;
	fl_set_cursor(FL_ObjWin(Slider), FL_DEFAULT_CURSOR);
	fl_show_alert("Local", "Couldn't create socket:", strerror(err), 0);
	return;
     }
   
   sin.sin_family=AF_INET;
   sin.sin_addr.s_addr=htonl(FTPState.PasvH);
   sin.sin_port=htons(FTPState.PasvP);
   if(0>connect(s, (struct sockaddr *)&sin, sizeof(sin)))
     {
	int err=errno;
	close(s);
	fl_set_cursor(FL_ObjWin(Slider), FL_DEFAULT_CURSOR);
	fl_show_alert("Local", "Couldn't connect to remote host:", strerror(err), 0);
	return;
     }
   FTPState.Data=fdopen(s, "r+");
}

void DoLocalCwd(const char * dir)
{
   chdir(dir);
   DoLocalList();
}

void DoCwd(const char * dir)
{
   SendCommand("CWD %s\r\n", dir);
   GetReturn(0);
   DoList();
}

void DoLocalView(const char * file)
{
   char buf[256];
   int froze=1;
   FILE * fp;

   fp=fopen(file, "r");
   if(!fp)
     return;
   sprintf(buf, "FreeFly  - Viewing %s", file);
   if(FTPState.ViewShown)
     fl_hide_form(viewform);
   fl_show_form(viewform,FL_PLACE_FREE,FL_FULLBORDER,buf);
   FTPState.ViewShown=1;
   fl_clear_browser(ViewWindow);
   fl_freeze_form(viewform);
   while(fgets(buf, sizeof(buf)-1, fp))
     {
	while((buf[strlen(buf)-1]=='\n')||(buf[strlen(buf)-1]=='\r'))
	  {
	     buf[strlen(buf)-1]=0;
	  }
	fl_add_browser_line(ViewWindow,buf);
	if((froze) && (fl_get_browser_maxline(ViewWindow) > fl_get_browser_screenlines(ViewWindow)))
	  {
	     froze=0;
	     fl_unfreeze_form(viewform);
	  }
     }
   if(froze)
     fl_unfreeze_form(viewform);
}

void DoView(const char * file)
{
   char buf[256];
   int ret;
   int froze=1;
   long len=0;
   long count=0;

   if(FTPState.Type!=1)
     {
	fl_show_alert("Local", "Cannot view binary file.", file, 0);
	return;
     }
   SendCommand("SIZE %s\r\n", file);
   if((GetReturn(0)&0xF00)==(COMPLETE<<8))
     {
	len=atol(fl_get_browser_line(LogWindow, fl_get_browser_maxline(LogWindow))+8);
     }
   ConnectPassive();
   if(!FTPState.Data)
     {
	fprintf(stderr, "No Cennection...\n");
	return;
     }
   SendCommand("RETR %s\r\n", file);
   ret=GetReturn(0);
   if((ret&0xF00)!=(PRELIM<<8))
     {
	fclose(FTPState.Data);
	return;
     }
   sprintf(buf, "FreeFly  - Viewing %s", file);
   if(FTPState.ViewShown)
     fl_hide_form(viewform);
   fl_show_form(viewform,FL_PLACE_FREE,FL_FULLBORDER,buf);
   FTPState.ViewShown=1;
   fl_clear_browser(ViewWindow);
   fl_freeze_form(viewform);
   if(len)
     {
	FTPState.SliderVal=((double)count)/((double)len);
	SliderChange(Slider, 0L);
     }
   while(fgets(buf, sizeof(buf)-1, FTPState.Data))
     {
	count+=strlen(buf);
	while((buf[strlen(buf)-1]=='\n')||(buf[strlen(buf)-1]=='\r'))
	  {
	     buf[strlen(buf)-1]=0;
	  }
	fl_add_browser_line(ViewWindow,strlen(buf)?buf:" ");
	if((froze) && (fl_get_browser_maxline(ViewWindow) > fl_get_browser_screenlines(ViewWindow)))
	  {
	     froze=0;
	     fl_unfreeze_form(viewform);
	  }
	if(len)
	  {
	     FTPState.SliderVal=((double)count)/((double)len);
	     SliderChange(Slider, 0L);
 	  }
     }
   if(froze)
     fl_unfreeze_form(viewform);
   GetReturn(0);
}

void DoLocalPwd()
{
   char buf[PATH_MAX];
   
   if(getcwd(buf, PATH_MAX))
     fl_set_object_label(LocalLoc, buf);
}

void DoPwd()
{
   int ret;
   SendCommand("PWD\r\n");
   ret=GetReturn(0);
   if((ret&0xF00)==(COMPLETE<<8))
     {
	const char * p=fl_get_browser_line(LogWindow, fl_get_browser_maxline(LogWindow));
	char * s;
	strcpy(FTPState.CWD, p+9);
	s=index(FTPState.CWD, '\"');
	*s=0;
	fl_set_object_label(RemoteLoc, FTPState.CWD);
     }
}

void DoPut(const char * file)
{
   char buf[256];
   int ret;
   long len=0, count=0;
   FILE * fp;
   struct stat st;
   
   fp=fopen(file, "r");
   if(!fp)
     {
	fprintf(stderr, "Cannot open file...\n");
	return;
     }
   stat(file, &st);
   len=st.st_size;
   ConnectPassive();
   if(!FTPState.Data)
     {
	fprintf(stderr, "No Cennection...\n");
	return;
     }
   SendCommand("STOR %s\r\n", file);
   ret=GetReturn(0);
   if((ret&0xF00)!=(PRELIM<<8))
     {
	fclose(FTPState.Data);
	return;
     }
   if(len)
     {
	FTPState.SliderVal=((double)count)/((double)len);
	SliderChange(Slider, 0L);
     }
   if(FTPState.Type==1)
     {
	while(fgets(buf, sizeof(buf)-1, fp))
	  {
	     count+=strlen(buf);
	     while((buf[strlen(buf)-1]=='\n')||(buf[strlen(buf)-1]=='\r'))
	       {
		  buf[strlen(buf)-1]=0;
	       }
	     strcat(buf, "\r\n");
	     fputs(buf, FTPState.Data);
	     if(len)
	       {
		  FTPState.SliderVal=((double)count)/((double)len);
		  SliderChange(Slider, 0L);
	       }
	  }
     }
   else
     {
	int i;
	while(i=fread(buf, 1, sizeof(buf)-1, fp))
	  {
	     count+=i;
	     fwrite(buf, 1, i, FTPState.Data);
	     if(len)
	       {
		  FTPState.SliderVal=((double)count)/((double)len);
		  SliderChange(Slider, 0L);
	       }
	  }
     }
   fclose(FTPState.Data);
   FTPState.Data=NULL;
   GetReturn(0);
}

void DoGet(const char * file)
{
   char buf[256];
   int ret;
   long len=0, count=0;
   FILE * fp;
   
   fp=fopen(file, "w");
   if(!fp)
     {
	fprintf(stderr, "Cannot open file...\n");
	return;
     }
   SendCommand("SIZE %s\r\n", file);
   if((GetReturn(0)&0xF00)==(COMPLETE<<8))
     {
	len=atol(fl_get_browser_line(LogWindow, fl_get_browser_maxline(LogWindow))+8);
     }
   ConnectPassive();
   if(!FTPState.Data)
     {
	fprintf(stderr, "No Cennection...\n");
	return;
     }
   SendCommand("RETR %s\r\n", file);
   ret=GetReturn(0);
   if((ret&0xF00)!=(PRELIM<<8))
     {
	fclose(FTPState.Data);
	return;
     }
   if(len)
     {
	FTPState.SliderVal=((double)count)/((double)len);
	SliderChange(Slider, 0L);
     }
   if(FTPState.Type==1)
     {
	while(fgets(buf, sizeof(buf)-1, FTPState.Data))
	  {
	     count+=strlen(buf);
	     while((buf[strlen(buf)-1]=='\n')||(buf[strlen(buf)-1]=='\r'))
	       {
		  buf[strlen(buf)-1]=0;
	       }
	     buf[strlen(buf)]='\n';
	     fputs(buf, fp);
	     if(len)
	       {
		  FTPState.SliderVal=((double)count)/((double)len);
		  SliderChange(Slider, 0L);
	       }
	  }
     }
   else
     {
	int i;
	while(i=fread(buf, 1, sizeof(buf)-1, FTPState.Data))
	  {
	     count+=i;
	     fwrite(buf, 1, i, fp);
	     if(len)
	       {
		  FTPState.SliderVal=((double)count)/((double)len);
		  SliderChange(Slider, 0L);
	       }
	  }
     }
   fclose(FTPState.Data);
   GetReturn(0);
}

void DoLocalList()
{
   DIR * dir;
   struct dirent * d;
   
   dir=opendir(".");

   if(!dir)
     return;
   
   fl_clear_browser(LocalDirsBrowser);
   fl_clear_browser(LocalFilesBrowser);
   while(d=readdir(dir))
     {
	struct stat st;
	
	if(stat(d->d_name, &st))
	  continue;

	if(st.st_mode&S_IFDIR)
	  {
	     fl_add_browser_line(LocalDirsBrowser, d->d_name);
	  }
	else
	  {
	     fl_add_browser_line(LocalFilesBrowser, d->d_name);
	  }
     }
   DoLocalPwd();
}

void DoList()
{
   char buf[256];
   int ret;
   ConnectPassive();
   if(!FTPState.Data)
     {
	fprintf(stderr, "No Connection...\n");
	return;
     }
   SendCommand("LIST -Ll\r\n");
   ret=GetReturn(0);
   if((ret&0xF00)!=(PRELIM<<8))
     {
	fclose(FTPState.Data);
	return;
     }
   fl_clear_browser(Browser_Dirs);
   fl_clear_browser(Browser_Files);
   while(fgets(buf, sizeof(buf)-1, FTPState.Data))
     {
	char * p=rindex(buf, ' ');
	
	if(!p)
	  continue;
	p++;
	while((buf[strlen(buf)-1]=='\n')||(buf[strlen(buf)-1]=='\r'))
	  {
	     buf[strlen(buf)-1]=0;
	  }
	if(buf[0]=='-')
	  {
	     fl_add_browser_line(Browser_Files, p);
	  }
	else if((buf[0]=='d')||(buf[0]=='l'))
	  {
	     fl_add_browser_line(Browser_Dirs, p);
	  }
     }
   fclose(FTPState.Data);
   FTPState.Data=NULL;
   ret=GetReturn(0);
   if((ret&0xF00)!=(COMPLETE<<8))
     {
	fprintf(stderr, "Error on d/l.\n");
	return;
     }
   DoPwd();
}

void DoClose()
{
   int ret;
   SendCommand("QUIT\r\n");
   ret=GetReturn(0);
   fclose(FTPState.Control);
   FTPState.Connected=0;
   FTPState.CWD[0]=0;
   fl_clear_browser(LogWindow);
   fl_clear_browser(Browser_Dirs);
   fl_clear_browser(Browser_Files);
   fl_set_object_label(RemoteLoc, "[Not Connected]");
}

void DoPass()
{
   const char * p=fl_show_input("Enter password:", "freefly@");
   
   if(!p)
     DoClose();
   else
     {
	int ret;
	SendCommand("PASS %s\r\n", p);
	ret=GetReturn(0);
	if((ret&0xF00)!=(COMPLETE<<8))
	  {
	     fl_show_alert("Server", "Cannot log in!", "(Bollocks)", 0);
	     DoClose();
	     return;
	  }
     }
}

void DoInit()
{
   int ret;
   SendCommand("APSV\r\n");
   /*
    * Request All PaSsiVe transfers.
    */
   ret=GetReturn(1);
   if((ret&0XF00)!=(COMPLETE<<8))
     FTPState.Apsv=0;
   SendCommand("SYST\r\n");
   ret=GetReturn(0);
   SendCommand("SITE CASE Y\n");
   ret=GetReturn(0);
   DoList();
}

void DoUser()
{
   const char * p=fl_show_input("Enter username:", "anonymous");
   
   if(!p)
     DoClose();
   else
     {
	int ret;
	SendCommand("USER %s\r\n", p);
	ret=GetReturn(0);
	if((ret&0xF00)==(CONTINUE<<8))
	  DoPass();
	else if((ret&0xF00)!=(COMPLETE<<8))
	  {
	     fl_show_alert("Server", "Cannot log in!", "(Bollocks)", 0);
	     DoClose();
	     return;
	  }
	DoInit();
     }
}

void OpenSite()
{
   fl_set_cursor(FL_ObjWin(Slider), XC_watch);
   if(FTPState.SiteName)
     {
	struct hostent * h=gethostbyname(FTPState.SiteName);
	if(h)
	  {
	     FTPState.host=*((unsigned long int *)h->h_addr);
	  }
	else
	  {
	     FTPState.host=inet_addr(FTPState.SiteName);
	  }
     }
   if(FTPState.host==-1)
     {
	fl_set_cursor(FL_ObjWin(Slider), FL_DEFAULT_CURSOR);   
	fl_show_alert("Local", "Address specified is invalid!", FTPState.SiteName, 0);
	return;
     }
   else
     {
	int s;
	int ret;
	struct sockaddr_in sin;

	s=socket(AF_INET, SOCK_STREAM, 0);
	if(s<0)
	  {
	     int err=errno;
	     fl_set_cursor(FL_ObjWin(Slider), FL_DEFAULT_CURSOR);
	     fl_show_alert("Local", "Couldn't create socket:", strerror(err), 0);
	     return;
	  }
	sin.sin_family=AF_INET;
	sin.sin_addr.s_addr=FTPState.host;
	sin.sin_port=htons(21);
	if(0>connect(s, (struct sockaddr *)&sin, sizeof(sin)))
	  {
	     int err=errno;
	     close(s);
	     fl_set_cursor(FL_ObjWin(Slider), FL_DEFAULT_CURSOR);
	     fl_show_alert("Local", "Couldn't connect to remote host:", strerror(err), 0);
	     return;
	  }
	FTPState.Control=fdopen(s, "r+");
	FTPState.Connected=1;

	ret=GetReturn(0);

	if((ret&(0xF00))!=(COMPLETE<<8))
	  {
	     DoClose();
	     fl_set_cursor(FL_ObjWin(Slider), FL_DEFAULT_CURSOR);
	     fl_show_alert("Server", "Server not accepting connections ATM", "(Bollocks)", 0);
	     return;
	  }
	DoUser();
     }
   fl_set_cursor(FL_ObjWin(Slider), FL_DEFAULT_CURSOR);   
}

/* callbacks for form test */
void file_select(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
   int selected=fl_get_menu(ob);
   if(selected==1)
     {
	const char * p=fl_show_input("Enter Site to open:", FTPState.SiteName?FTPState.SiteName:"localhost");
	if(!p)
	  return;
	if(FTPState.SiteName)
	  free(FTPState.SiteName);
	FTPState.SiteName=(char *)malloc(strlen(p)+1);
	strcpy(FTPState.SiteName, p);
	OpenSite();
     }
   else if(selected==2)
     {
	if(FTPState.Connected)
	  DoClose();
     }
   else if(selected==3)
     {
	if(FTPState.Connected)
	  DoClose();
	exit(0);
     }
}

void quit_now(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
   if(FTPState.Connected)
     DoClose();
   exit(0);
}

void ClockHit(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
   fprintf(stderr, "Clock hit...\n");
}

void ModeChange(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void options_select(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
   fprintf(stderr, "Options->General unimplemented\n");
}

void TypeChange(FL_OBJECT *obj, long data)
{
  /* fill-in code for callback */
   switch(fl_get_choice(obj))
     {
      case 1:
	if(FTPState.Type!=1)
	  {
	     SendCommand("TYPE A\r\n");
	     if((GetReturn(0)&0xF00)==(COMPLETE<<8))
	       FTPState.Type=1;
	     else
	       fl_set_choice(obj, FTPState.Type);
	  }
	break;
	
       case 2:
	if(FTPState.Type!=2)
	  {
	     SendCommand("TYPE I\r\n");
	     if((GetReturn(0)&0xF00)==(COMPLETE<<8))
	       FTPState.Type=2;
	     else
	       fl_set_choice(obj, FTPState.Type);
	  }
	break;
	
       case 3:
	if(FTPState.Type!=3)
	  {
	     SendCommand("TYPE L 8\r\n");
	     if((GetReturn(0)&0xF00)==(COMPLETE<<8))
	       FTPState.Type=3;
	     else
	       fl_set_choice(obj, FTPState.Type);
	  }
	break;
     }
}

void HandleCommandLine(FL_OBJECT *ob, const char * p)
{
   char buf[256];
   char * args[10];
   char * s;
   int i;
   if(p && strlen(p))
     {
	strcpy(buf, p);
	fl_set_input(ob, "");
	args[0]=buf;
	for(i=1; i!=10; i++)
	  {
	     if((s=index(args[i-1], ' ')))
	       {
		  *s=0;
		  args[i]=++s;
	       }
	     else
	       {
		  args[i]=NULL;
		  break;
	       }
	  }
	if(!strcasecmp(args[0], "open")) 
	  {
	     if(FTPState.Connected)
	       fl_show_alert("Local", "Already Connected!", FTPState.SiteName, 0);
	     else if(!args[1])
	       {
		  const char * z=fl_show_input("Enter Site to open:", FTPState.SiteName?FTPState.SiteName:"localhost");
		  if(!z)
		    return;
		  if(FTPState.SiteName)
		    free(FTPState.SiteName);
		  FTPState.SiteName=(char *)malloc(strlen(z)+1);
		  strcpy(FTPState.SiteName, z);
		  OpenSite();
	       }
	     else
	       {
		  if(FTPState.SiteName)
		    free(FTPState.SiteName);
		  FTPState.SiteName=(char *)malloc(strlen(args[1])+1);
		  strcpy(FTPState.SiteName, args[1]);
		  OpenSite();
	       }
	  } 
	else if(!strcasecmp(args[0], "close"))
	  {
	     if(FTPState.Connected)
	       DoClose();
	  }
     	else if(!strcasecmp(args[0], "cd"))
	  {
	     if(args[1])
	       DoCwd(args[1]);
	     else
	       RemoteLocChange(RemoteLoc, 0);
	  }
	else if(!strcasecmp(args[0], "site"))
	  {
	     char buf[256];
	     
	     if(args[1])
	       {
		  int i;
		  
		  strcpy(buf, "SITE");
		  for(i=0; args[i]; i++)
		    {
		       strcat(buf, " ");
		       strcat(buf, args[i]);
		    }
	       }
	     else
	       {
		  const char *p=fl_show_input("Enter SITE command:", "");
		  if(!p || !strlen(p))
		    return;
		  strcpy(buf, "SITE ");
		  strcat(buf, p);
	       }
	     SendCommand("%s\r\n", buf);
	     GetReturn(0);
	  }
     }
}

void CompleteCommandLine(FL_OBJECT *ob, const char * p)
{
   char buf[1024];
   sprintf(buf, "%s%s ", p, "raspberry");
   fl_set_input(ob, buf);
}

void DoCommandLine(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
   const XEvent * xev=fl_last_event();
   const char * p=fl_get_input(ob);
   
   if(p && strlen(p))
     {
	if(36==xev->xkey.keycode)
	  {
	     HandleCommandLine(ob, p);
	  }
	else if(23==xev->xkey.keycode)
	  {
	     CompleteCommandLine(ob, p);
	  }
     }
}

void DirBrowserHit(FL_OBJECT * obj, long data)
{
   DoCwd(fl_get_browser_line(obj, fl_get_browser(obj)));
}

void FileBrowserHit(FL_OBJECT * obj, long data)
{
   switch(fl_mouse_button())
     {
      case 1:
	DoGet(fl_get_browser_line(obj, fl_get_browser(obj)));
	break;
	
      case 3:
	DoView(fl_get_browser_line(obj, fl_get_browser(obj)));
     }
}

void LocalDirsBrowserHit(FL_OBJECT * obj, long data)
{
   DoLocalCwd(fl_get_browser_line(obj, fl_get_browser(obj)));
}

void LocalFilesBrowserHit(FL_OBJECT * obj, long data)
{
   switch(fl_mouse_button())
     {
      case 1:
	DoPut(fl_get_browser_line(obj, fl_get_browser(obj)));
	break;
	
      case 3:
	DoLocalView(fl_get_browser_line(obj, fl_get_browser(obj)));
     }
}

void RemoteLocChange(FL_OBJECT * obj, long data)
{
   const char * p=fl_show_input("Enter new location:", FTPState.CWD);
   if(p && strlen(p))
     DoCwd(p);
}

void LocalLocChanged(FL_OBJECT * obj, long data)
{
   char buf[PATH_MAX];
   const char * p=fl_show_input("Enter new location:", getcwd(buf, PATH_MAX)?buf:"");
   if(p && strlen(p))
     DoLocalCwd(p);
}

void CommandMenuSelect(FL_OBJECT * obj, long data)
{
}

void HelpMenuSelect(FL_OBJECT * obj, long data)
{
}

void SliderChange(FL_OBJECT * obj, long data)
{
   fl_set_slider_value(obj, FTPState.SliderVal);
}

const char * SliderFilter(FL_OBJECT * obj, double val, int prec)
{
   static char buf[10];
   int rv;
   
   if(val<0.0)
     val=0.0;
   if(val>1.0)
     val=1.0;
   
   rv=(int)(val*100);
   
   sprintf(buf, "%d%%", rv);
   
   return(buf);
}
