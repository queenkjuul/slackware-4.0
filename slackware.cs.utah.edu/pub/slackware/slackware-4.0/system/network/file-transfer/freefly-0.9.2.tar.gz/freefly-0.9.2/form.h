#ifndef FD_test_h_
#define FD_test_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void DirBrowserHit(FL_OBJECT *, long);
extern void file_select(FL_OBJECT *, long);
extern void quit_now(FL_OBJECT *, long);
extern void ClockHit(FL_OBJECT *, long);
extern void TypeChange(FL_OBJECT *, long);
extern void options_select(FL_OBJECT *, long);
extern void FileBrowserHit(FL_OBJECT *, long);
extern void ModeChange(FL_OBJECT *, long);
extern void DoCommandLine(FL_OBJECT *, long);
extern void LocalDirsBrowserHit(FL_OBJECT *, long);
extern void LocalFilesBrowserHit(FL_OBJECT *, long);
extern void RemoteLocChange(FL_OBJECT *, long);
extern void LocalLocChanged(FL_OBJECT *, long);
extern void CommandMenuSelect(FL_OBJECT *, long);
extern void HelpMenuSelect(FL_OBJECT *, long);
extern void SliderChange(FL_OBJECT *, long);
extern const char * SliderFilter(FL_OBJECT *, double, int);

/**** Forms and Objects ****/

extern FL_FORM *test;

extern FL_OBJECT
        *Browser_Dirs,
        *Menu_File,
        *Button_Quit,
        *Clock,
        *TransferType,
        *Menu_Options,
        *Browser_Files,
        *TransferMode,
        *CommandInput,
        *LocalDirsBrowser,
        *LocalFilesBrowser,
        *RemoteLoc,
        *LocalLoc,
        *CommandMenu,
        *HelpMenu,
        *Slider,
	*LogWindow,
	*ViewWindow,
        *TransferStruct;

extern FL_FORM *viewform;



/**** Creation Routine ****/

extern void create_the_forms(void);

#endif /* FD_test_h_ */
