/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "form.h"

FL_FORM *test;

FL_OBJECT
        *Browser_Dirs,
        *Menu_File,
        *Button_Quit,
        *Clock,
        *TransferType,
        *Menu_Options,
        *Browser_Files,
        *TransferMode,
        *CommandInput,
        *LocalDirsBrowser,
        *LocalFilesBrowser,
        *RemoteLoc,
        *LocalLoc,
        *CommandMenu,
        *HelpMenu,
        *Slider,
	*LogWindow,
	*ViewWindow,
        *TransferStruct;

void create_form_test(void)
{
  FL_OBJECT *obj;

  if (test)
     return;

  test = fl_bgn_form(FL_NO_BOX,580,640);
  obj = fl_add_box(FL_FLAT_BOX,0,0,580,640,"");
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
  Browser_Dirs = obj = fl_add_browser(FL_SELECT_BROWSER,280,60,300,180,"");
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_callback(obj,DirBrowserHit,0);
  Menu_File = obj = fl_add_menu(FL_PULLDOWN_MENU,0,0,90,30,"File");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE);
    fl_set_object_callback(obj,file_select,0);
  Button_Quit = obj = fl_add_button(FL_NORMAL_BUTTON,0,430,60,30,"Quit");
    fl_set_object_callback(obj,quit_now,0);
  Clock = obj = fl_add_clock(FL_DIGITAL_CLOCK,500,430,80,30,"");
    fl_set_object_boxtype(obj,FL_DOWN_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_BLACK);
    fl_set_object_lcolor(obj,FL_RED);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE);
    fl_set_object_callback(obj,ClockHit,0);
  TransferType = obj = fl_add_choice(FL_NORMAL_CHOICE2,140,430,70,30,"");
    fl_set_object_callback(obj,TypeChange,0);
  Menu_Options = obj = fl_add_menu(FL_PULLDOWN_MENU,190,0,90,30,"Options");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE);
    fl_set_object_callback(obj,options_select,0);
  Browser_Files = obj = fl_add_browser(FL_SELECT_BROWSER,280,240,300,190,"");
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_callback(obj,FileBrowserHit,0);
  TransferMode = obj = fl_add_choice(FL_NORMAL_CHOICE2,60,430,80,30,"");
    fl_set_object_callback(obj,ModeChange,0);
  CommandInput = obj = fl_add_input(FL_NORMAL_INPUT,0,610,580,30,"Input");
    fl_set_object_color(obj,FL_BLACK,FL_MCOL);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_FIXED_STYLE);
    fl_set_object_gravity(obj, FL_NorthWest, FL_SouthEast);
    fl_set_object_resize(obj, FL_RESIZE_X);
    fl_set_object_callback(obj,DoCommandLine,0);
  LocalDirsBrowser = obj = fl_add_browser(FL_SELECT_BROWSER,0,60,280,180,"");
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_callback(obj,LocalDirsBrowserHit,0);
  LocalFilesBrowser = obj = fl_add_browser(FL_SELECT_BROWSER,0,240,280,190,"");
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_callback(obj,LocalFilesBrowserHit,0);
  RemoteLoc = obj = fl_add_button(FL_NORMAL_BUTTON,280,30,300,30,"[Not Connected]");
    fl_set_object_boxtype(obj, FL_DOWN_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_callback(obj,RemoteLocChange,0);
  LocalLoc = obj = fl_add_button(FL_NORMAL_BUTTON,0,30,280,30,"");
    fl_set_object_boxtype(obj, FL_DOWN_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_callback(obj,LocalLocChanged,0);
  CommandMenu = obj = fl_add_menu(FL_PULLDOWN_MENU,90,0,90,30,"Commands");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE);
    fl_set_object_callback(obj,CommandMenuSelect,0);
  HelpMenu = obj = fl_add_menu(FL_PULLDOWN_MENU,480,0,100,30,"Help");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE);
    fl_set_object_callback(obj,HelpMenuSelect,0);
  LogWindow = obj = fl_add_browser(FL_NORMAL_BROWSER,0,460,580,150,"");
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_lsize(obj,FL_TINY_SIZE);
    fl_set_object_gravity(obj, FL_NorthWest, FL_SouthEast);
    fl_set_object_resize(obj, FL_RESIZE_X);
  Slider = obj = fl_add_valslider(FL_HOR_FILL_SLIDER,280,430,220,30,"");
    fl_set_object_color(obj,FL_MCOL,FL_COL1);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_BOLDITALIC_STYLE);
    fl_set_slider_filter(obj, SliderFilter);
    fl_set_object_callback(obj, SliderChange, 0);
  TransferStruct = obj = fl_add_choice(FL_NORMAL_CHOICE2,210,430,70,30,"");
  fl_end_form();
  fl_adjust_form_size(test);

}
/*---------------------------------------*/

FL_FORM *viewform;


void create_form_viewform(void)
{
  FL_OBJECT *obj;

  if (viewform)
     return;

  viewform = fl_bgn_form(FL_NO_BOX,580,540);
  obj = fl_add_box(FL_FLAT_BOX,0,0,580,540,"");
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
  ViewWindow = obj = fl_add_browser(FL_NORMAL_BROWSER,0,0,580,540,"");
  fl_end_form();
  fl_adjust_form_size(viewform);

}
/*---------------------------------------*/

void create_the_forms(void)
{
  create_form_test();
  create_form_viewform();
}

