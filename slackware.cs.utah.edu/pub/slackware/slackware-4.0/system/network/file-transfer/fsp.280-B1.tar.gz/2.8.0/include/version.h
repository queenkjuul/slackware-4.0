#ifndef _FSP_VERSION_H_
#define _FSP_VERSION_H_

#ifdef VMS
#define VERSION_STR "VMS Version 2.8.0 (BETA 1), August 4th, 1995"
#else
#define VERSION_STR "Version 2.8.0 (BETA 1), August 4th, 1995"
#endif

#endif /* _FSP_VERSION_H_ */
