#ifndef _FSP_BSD_EXTERN_H_
#define _FSP_BSD_EXTERN_H_

/* glob.c */
extern char **glob PROTO0((register char *));

#endif /* _FSP_BSD_EXTERN_H_ */
