/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */

static GtkWidget *clist;
static GtkWidget *clist_window;
static GtkWidget *console_popup_menu;

static gint console_last_row;

static gint clist_event_handler (GtkWidget * this_list, GdkEvent * event, gpointer data);
static void aff_message (char *this_message, GdkColor fg_color);

/* EOF */
