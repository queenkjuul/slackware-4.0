/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */


static char text_ext[2048];

static GtkWidget *clist;
static GtkWidget *button_ext_edit;
static GtkWidget *button_ext_delete;



static void text_ext_write (void);

static void add_ext (GtkWidget * widget, GtkWidget * entry);
static void add_ext_dialog (GtkWidget * widget, gpointer data);
static void delete_ext (GtkWidget * widget, gpointer data);
static void edit_ext (GtkWidget * widget, GtkWidget * entry);
static void edit_ext_dialog (GtkWidget * widget, gpointer data);

static void update_button_ext (GtkWidget * this_list, gint row, gint column, GdkEventButton * event, gpointer data);

/* EOF */
