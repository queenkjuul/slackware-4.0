/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */

#include <gdk/gdk.h>


const GdkColor LBLUE =
{0, 0x0000, 0x0000, 0xffff};
const GdkColor BLUE =
{0, 0x0000, 0x0000, 0x8000};
const GdkColor BLACK =
{0, 0x0000, 0x0000, 0x0000};
const GdkColor RED =
{0, 0x8000, 0x0000, 0x0000};
const GdkColor LRED =
{0, 0xffff, 0x0000, 0x0000};
const GdkColor LCYAN =
{0, 0xbb00, 0xccee, 0xffff};
const GdkColor LICE =
{0, 0xbefb, 0xc71b, 0xffff};
const GdkColor CYAN =
{0, 0x6000, 0xBB00, 0xFFFF};
const GdkColor WHITE =
{0, 0xffff, 0xffff, 0xffff};
const GdkColor YELLOW =
{0, 0xffff, 0x8888, 0x0000};
const GdkColor LYELLOW =
{0, 0xffff, 0xffff, 0xcccc};
const GdkColor LGREEN =
{0, 0x0000, 0xBB00, 0x0000};
const GdkColor GREEN =
{0, 0x0000, 0x8000, 0x0000};
const GdkColor GREYCYAN =
{0, 0xdd00, 0xdd00, 0xee00};
const GdkColor LGREY =
{0, 0xcc00, 0xcc00, 0xcc00};
const GdkColor GREY =
{0, 0x8800, 0x8800, 0x8800};
const GdkColor SLGREY =
{0, 0xd75c, 0xd75c, 0xd75c};
const GdkColor SGREY =
{0, 0xc71b, 0xc30b, 0xc71b};


/* EOF */
