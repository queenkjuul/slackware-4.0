/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */

#define NO_MORE_TRUE 2
#define FIREWALL_IS(a) (this_session.firewall_login_type==a)

static char USER_WANT_RECONNECT = FALSE;
static char IS_SLEEPING = FALSE;



static int IGLOO_set_type (char *filename);
static gint IGLOO_anti_idle (gpointer data);
static gint IGLOO_sleep_timeout (gpointer data);
static void IGLOO_sleep (int seconds);
/* EOF */
