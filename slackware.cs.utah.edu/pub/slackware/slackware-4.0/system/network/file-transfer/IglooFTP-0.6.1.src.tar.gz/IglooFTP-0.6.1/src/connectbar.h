/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */

static GtkWidget *handle_box;
static GtkWidget *combo_host;
static GtkWidget *combo_user;
static GtkWidget *entry_pass;
static GtkWidget *entry_port;
static GtkWidget *tmode_option_menu;
#define ENTRY_HOST GTK_ENTRY(GTK_COMBO (combo_host)->entry)
#define ENTRY_USER GTK_ENTRY(GTK_COMBO (combo_user)->entry)
#define ENTRY_PASS GTK_ENTRY (entry_pass)
#define ENTRY_PORT GTK_ENTRY (entry_port)


static char DONT_UPDATE_ENTRY_PASS = FALSE;

static GList *combo_host_items = NULL;



static void get_or_set_connect_info (void);
static void connect_entry_key_pressed (GtkWidget * entry, GdkEventKey * event, gpointer data);
static void combo_user_new_selection (GtkWidget * entry);
static void set_transfert_mode (GtkWidget * widget, gpointer data);
static void set_entry_port (unsigned short int this_port);

static void host_drag_data_received (GtkWidget * widget, GdkDragContext * context, gint x, gint y, GtkSelectionData * data, guint info, guint time);
/* EOF */
