/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */


#define QSTATUS_WAITING 0
#define QSTATUS_PROGRESS 1
#define QSTATUS_DONE 2
#define QSTATUS_DELAYED 3
#define QSTATUS_CANCELLED 4
#define QSTATUS_ERROR Qfile->status = (Qfile->status == QSTATUS_DELAYED && Qfile->retry >=  user_rc.queue_max_retries) ? QSTATUS_CANCELLED : QSTATUS_DELAYED


static GtkWidget *clist;
static GtkWidget *clist_window;
static int Qentries = 0;
static char QUEUE_SAVED = TRUE;
static char queue_current_name[256];


static void queue_drag_data_received (GtkWidget * widget, GdkDragContext * context, gint x, gint y, GtkSelectionData * data, guint info, guint time);

static gint clist_event_handler (GtkWidget * this_list, GdkEvent * event, gpointer data);
static void clist_row_select_unselect (GtkWidget * this_list, gint row, gint column, GdkEventButton * event, gpointer data);

static QUEUEfile *QUEUE_allocate_Qfile_struct (void);

static void QUEUE_save (char *queuename);
static void QUEUE_save_as (GtkWidget * widget, GtkWidget * entry);
static void QUEUE_load (char *queuename, char VERBOSE);
static void QUEUE_load_ok (GtkWidget * widget, gpointer data);

/* EOF */
