/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */


typedef struct
  {
    GtkWidget *queue;
    GtkWidget *xfer;
    GtkWidget *select;
    GtkWidget *selectf;
    GtkWidget *unselect;
    GtkWidget *undoselect;
    GtkWidget *view;
    GtkWidget *edit;
    GtkWidget *exec;
    GtkWidget *chmod;
    GtkWidget *ren;
    GtkWidget *move;
    GtkWidget *del;
    GtkWidget *mkdir;
    GtkWidget *chdir;
    GtkWidget *menu_radio_sort_by_name;
    GtkWidget *menu_radio_sort_by_date;
    GtkWidget *menu_radio_sort_by_size;
    GtkWidget *menu_radio_sort_by_perm;
    GtkWidget *menu_radio_sort_by_uid;
    GtkWidget *menu_radio_sort_by_gid;
    GtkWidget *menu_radio_sort_up;
    GtkWidget *menu_radio_sort_down;
  }
popup_menu;

static popup_menu local_popup;
static popup_menu remote_popup;
static GtkWidget *remote_sort_menu;
static GtkWidget *remote_select_menu;
static GtkWidget *remote_popup_refresh;
static GtkWidget *check_idle;
static GtkWidget *menu_item_smanager;
static GtkWidget *menu_item_connect;
static GtkWidget *menu_item_disconnect;
static GtkWidget *menu_item_reconnect;
static GtkWidget *menu_item_spawn_session;
static GtkWidget *menu_item_grp_add;
static GtkWidget *menu_item_grp_edit;
static GtkWidget *menu_item_grp_delete;
static GtkWidget *menu_item_site_add;
static GtkWidget *menu_item_site_edit;
static GtkWidget *menu_item_site_copy;
static GtkWidget *menu_item_site_delete;


static GtkWidget *menu_item_bookmark_add;
static GtkWidget *menu_item_bookmark_edit;
static GtkWidget *menu_item_bookmark_save_local_path;
static GtkWidget *menu_item_bookmark_save_remote_path;

static GtkWidget *menu_radio_toolbar_both;
static GtkWidget *menu_radio_toolbar_icons;
static GtkWidget *menu_radio_toolbar_text;

static GtkWidget *menu_console_welcome_msg;
static GtkWidget *menu_console_dir_msg;
static GtkWidget *menu_console_connexion_log;

static GtkWidget *menu_queue_add;
static GtkWidget *menu_queue_remove;
static GtkWidget *menu_queue_to_top;
static GtkWidget *menu_queue_to_bottom;
static GtkWidget *menu_queue_save;
static GtkWidget *menu_queue_clear;
static GtkWidget *menu_queue_info;
static GtkWidget *menu_queue_xfer;
static GtkWidget *menu_queue_xfer_log;

static GtkWidget *menu_item_compare_dir;

static GtkWidget *menu_commands_download;
static GtkWidget *menu_commands_upload;
static GtkWidget *menu_commands_view;
static GtkWidget *menu_commands_edit;
static GtkWidget *menu_commands_execute;
static GtkWidget *menu_commands_get_link;
static GtkWidget *menu_commands_manual_get;
static GtkWidget *menu_commands_delete;
static GtkWidget *menu_commands_rename;
static GtkWidget *menu_commands_move;
static GtkWidget *menu_commands_cd;
static GtkWidget *menu_commands_mkdir;

static GtkWidget *menu_commands_refresh;

static GtkWidget *check_menu_view_local;
static GtkWidget *check_menu_view_remote;


static GtkWidget *create_local_popup_menu (void);
static GtkWidget *create_remote_popup_menu (void);
static void update_commands_menu (gint selected_items);

static GtkWidget *create_check_menu_item (GtkWidget * menu, gchar * label, gint state_flag,
					  GtkSignalFunc this_func);
static GtkWidget *create_menu_radio_item (GtkWidget * menu, GtkWidget * last_radio, gchar * label,
	 GtkSignalFunc this_func, gpointer this_func_data, gint state_flag);
static GtkWidget *create_menu_in_menu (GtkWidget * menu, gchar * label);

/* EOF */
