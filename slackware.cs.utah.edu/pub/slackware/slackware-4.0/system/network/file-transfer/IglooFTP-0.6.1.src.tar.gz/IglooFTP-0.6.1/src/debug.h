/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */

#define LIST_DEBUG
#define DEBUG_LOG

#ifndef DEBUG_LOG
#ifdef LIST_DEBUG
#define DEBUG_LOG
#endif
#endif


#ifdef DEBUG_LOG
#define DEBUG(this_message);  debuglog (this_message);
void debuglog (char *this_message);
void close_user_debuglog (void);
#else
#define DEBUG(this_message);
#endif


#ifdef LIST_DEBUG
#define FTP_MISC_DEBUG(x);  DEBUG (x);
#else
#define FTP_MISC_DEBUG(x);
#endif

#ifdef LIST_DEBUG
#define FTP_MISC_DEBUG_LOG_THIS_LINE();	  {char msg_buf[1024];\
	    sprintf (msg_buf, "%s %s %s %s [%s] [%s]\n",\
		     this_file.name, this_file.date, this_file.size, this_file.attrib, this_file.uid, this_file.gid);\
	    DEBUG (msg_buf);}
#else
#define FTP_MISC_DEBUG_LOG_THIS_LINE();
#endif





#define HERE(x) printf("IglooFTP: [%i]\n",x)
#define _HERE(x) printf("IglooFTP: [%s]\n",x)

/* EOF */
