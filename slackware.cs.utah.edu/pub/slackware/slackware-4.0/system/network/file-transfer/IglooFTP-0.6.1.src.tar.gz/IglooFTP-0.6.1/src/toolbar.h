/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */


static GtkWidget *handle_box;
static GtkWidget *toolbar;
static GtkWidget *button_connect;
static GtkWidget *button_abort;
static GtkWidget *button_disconnect;
static GtkWidget *button_bookmark;
static GtkWidget *button_bookmark_path;
static GtkWidget *button_preferences;
static GtkWidget *button_queue_add;
static GtkWidget *button_queue_run;
static GtkWidget *button_queue_clear;
static GtkWidget *button_upload;
static GtkWidget *button_download;
//static GtkWidget *button_find_file;
//static GtkWidget *button_run_script;


/* EOF */
