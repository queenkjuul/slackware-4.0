/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */

static int fileperm;
static GtkWidget *alert_entry;
static GtkWidget *user_read, *group_read, *other_read;
static GtkWidget *user_write, *group_write, *other_write;
static GtkWidget *user_exec, *group_exec, *other_exec;

static char BUTTON_CALLBACK;
static char ENTRY_CALLBACK;


static void check_button_callback (GtkWidget * widget, int data);
static void new_mode_entered (GtkWidget * entry);
static GtkWidget *chmod_check_button (GtkWidget * this_vbox, char *this_label, int this_mode);
static GtkWidget *chmod_frame (GtkWidget * this_hbox, char *this_label);

/*EOF */
