/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */


#define USE_NETSCAPE user_rc.use_netscape
#define USE_INTERNAL_TXT_VIEWER 1
#define USE_INTERNAL_TXT_EDITOR !strcmp(user_rc.text_editor_command,INTERNAL_APP_TXT)

static char IS_REXEC = FALSE;

extern int mozilla_remote (char *command);

static void execute_command (char *command);
static void REXEC_execute_program (char *program, char *arg, char *filename);
static char find_associates_by_extension (char *file_extension, char *editor, char *viewer);
/* EOF */
