/* IglooFTP - Graphical and User Friendly FTP Client.
 * Copyright (c) 1998-1999 Jean-Marc Jacquet. 
 * All rights reserved.
 * 
 * THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE
 *
 * IglooFTP Original Packages, information and support,  
 * can be obtained at :
 *                              http://www.littleigloo.org
 * 
 *
 */


static GtkWidget *label_file;
static GtkWidget *label_speed;
static GtkWidget *label_elapsed;
static GtkWidget *label_remain;
static GtkWidget *progressbar;
static GtkWidget *pixmap_elapsed;
static GtkWidget *pixmap_remain;
static GtkWidget *pixmap_stat_download;
static GtkWidget *pixmap_stat_upload;
static GtkWidget *hbox_pixmap_info;


static long filesize;
static long resume_offset;

static char xfer_sec;
static char xfer_min;
static char xfer_hour;
static char BUSY;

static time_t elapsed_time;
static time_t last_elapsed_time;
static float transfert_speed;


/* EOF */
