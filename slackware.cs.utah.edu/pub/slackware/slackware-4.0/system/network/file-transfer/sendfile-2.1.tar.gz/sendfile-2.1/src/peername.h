/* returns the peername of the connecting host on stdin */
char *peername(int);
