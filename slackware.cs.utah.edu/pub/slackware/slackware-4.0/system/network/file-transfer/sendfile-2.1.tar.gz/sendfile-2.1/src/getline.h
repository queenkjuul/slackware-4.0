char *getpromptline(char *, int);
