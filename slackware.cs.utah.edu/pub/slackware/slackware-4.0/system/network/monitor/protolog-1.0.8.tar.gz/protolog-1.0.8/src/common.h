
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#include "defines.h"
#include "internet.h"

/* note: extern variables are explained where defined, just use grep. */
extern int flag_dont_resolve;
extern int flag_quiet;
extern char *progname;

/* Functions Prototypes */

/* common.c */
void init_signals( void);
void gobackground( void);
char *resolve_host_name( unsigned long int addr);
char *get_serv_name( unsigned short port, const char *proto);
void check_uid( void);
char *replicate( char c, int size);
int plog_inet_dtoa( char *mask, struct in_addr *inetmask);
void plog_parse_mask( char *mask, struct in_addr *inetmask);
void process_host_and_mask( char *str, struct in_addr *mask, struct in_addr *host);
char *plog_basename( char *name);
void *plog_calloc( int size);

