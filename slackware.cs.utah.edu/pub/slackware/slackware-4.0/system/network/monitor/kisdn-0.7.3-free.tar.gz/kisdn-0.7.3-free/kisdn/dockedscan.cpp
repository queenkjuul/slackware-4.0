/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: dockedscan.cpp,v 1.2 1998/11/21 12:34:33 twesthei Exp $
//
// $Log: dockedscan.cpp,v $
// Revision 1.2  1998/11/21 12:34:33  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//


#include <qevent.h>

#include <kapp.h>
#include <kiconloader.h>

#include "pppstatus.h"
#include "netinfo.h"
#include "kisdndata.h"
#include "scanmeter.h"
#include "dockedscan.h"


DockedScan::DockedScan(QWidget *parent, const char *name):QLabel(parent, name)
{
  Temp1 = new QPixmap(DOCKWIDTH, DOCKHEIGHT-DOCKOFFSET);
  Temp2 = new QPixmap(DOCKWIDTH, DOCKHEIGHT);

  KIconLoader *loader = kapp->getIconLoader();

  lyoff = new QPixmap(loader->loadIcon("ledyellowoff.xpm"));
  lyon  = new QPixmap(loader->loadIcon("ledyellowon.xpm"));
  lgoff = new QPixmap(loader->loadIcon("ledgreenoff.xpm"));
  lgon  = new QPixmap(loader->loadIcon("ledgreenon.xpm"));
  lroff = new QPixmap(loader->loadIcon("ledredoff.xpm"));
  lron  = new QPixmap(loader->loadIcon("ledredon.xpm"));

  Temp2->fill(QColor::QColor(black));
  setPixmap(*Temp2);

  oldrx  = oldtx = 0;
  off    = DOCKHEIGHT-DOCKOFFSET-2;
  opaque = true;			// hardcoded for testing

  resize( 25, 25 );
  setColors();
  slotBusy(0);
}


DockedScan::~DockedScan(void)
{
  delete (Temp1);
  delete (Temp2);
  delete (lyoff);
  delete (lyon);
  delete (lgoff);
  delete (lgon);
  delete (lroff);
  delete (lron);
}


void DockedScan::slotDialing(ushort ch)
{
  //  if (!ch)
  if (true) // we only have 1 LED, so we show it independent from the channel
  {
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 1,  1, lyon,  0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 7,  1, lgoff, 0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 13, 1, lroff, 0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 19, 1, lroff, 0, 0, 5, 5, CopyROP);

    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
  }
}


void DockedScan::slotBusy(ushort ch)
{
  //  if (!ch)
  if (true) // we only have 1 LED, so we show it independent from the channel
  {
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 1,  1, lyoff, 0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 7,  1, lgoff, 0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 13, 1, lroff, 0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 19, 1, lroff, 0, 0, 5, 5, CopyROP);

    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
  }
}


void DockedScan::slotOnline(ushort ch)
{
  if (!ch)
  {
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 1,  1, lyoff,  0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 7,  1, lgon, 0, 0, 5, 5, CopyROP);

    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
  }
}


void DockedScan::slotOffline(ushort ch)
{
  if (!ch)
  {
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 1,  1, lyoff,  0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 7,  1, lgoff, 0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 13, 1, lroff, 0, 0, 5, 5, CopyROP);
    bitBlt(Temp2, 19, 1, lroff,  0, 0, 5, 5, CopyROP);

    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
  }
}


void DockedScan::slotVoiceDown(ushort)
{
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 1,  1, lyoff,  0, 0, 5, 5, CopyROP);
    
    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
}


void DockedScan::slotVoiceIn(ushort)
{
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 1,  1, lyon,  0, 0, 5, 5, CopyROP);

    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
}


void DockedScan::slotReceiveOn(ushort ch)
{
  if (!ch)
  {
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 13, 1, lron, 0, 0, 5, 5, CopyROP);

    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
  }
}


void DockedScan::slotReceiveOff(ushort ch)
{
  if (!ch)
  {
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 13, 1, lroff, 0, 0, 5, 5, CopyROP);

    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
  }
}


void DockedScan::slotTransmitOn(ushort ch)
{
  if (!ch)
  {
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 19, 1, lron, 0, 0, 5, 5, CopyROP);

    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
  }
}


void DockedScan::slotTransmitOff(ushort ch)
{
  if (!ch)
  {
    Temp2->fill(QColor::QColor(black));
    bitBlt(Temp2, 0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKHEIGHT, CopyROP);

    bitBlt(Temp2, 19, 1, lroff, 0, 0, 5, 5, CopyROP);

    bitBlt(this->pixmap(), 0, 0, Temp2);
    repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);
  }
}

void DockedScan::slotNewRates(PPPInfo *info)
{
  QPainter  p;
  QPixmap   *leds = new QPixmap(DOCKWIDTH, DOCKOFFSET);
  float     rx    = info->inRate[0] + info->inRate[1];
  float     tx    = info->outRate[0] + info->outRate[1];

  Temp1->fill(QColor::QColor(black));
  leds->fill(QColor::QColor(black));
  bitBlt(leds,  0, 0, this->pixmap(), 0, 0, DOCKWIDTH, DOCKOFFSET, CopyROP);
  bitBlt(Temp1, 0, 0, this->pixmap(), 1, DOCKOFFSET, DOCKWIDTH-1, DOCKHEIGHT-DOCKOFFSET, CopyROP);

  p.begin(Temp1);

  if (opaque)
  {
    p.setPen(GraphColor[TYPEREC]);
    p.drawLine(DOCKWIDTH-1, DOCKHEIGHT-1, DOCKWIDTH-1, off - (uint) rx);
    p.setPen(GraphColor[TYPETRA]);
    p.drawLine(DOCKWIDTH-1, DOCKHEIGHT-1, DOCKWIDTH-1, off - (uint) tx);
  }
  else
  {
    p.setPen(GraphColor[TYPEREC]);
    p.drawLine(DOCKWIDTH-1, off-oldrx, DOCKWIDTH-1, off - (uint) rx);
    p.setPen(GraphColor[TYPETRA]);
    p.drawLine(DOCKWIDTH-1, off-oldtx, DOCKWIDTH-1, off - (uint) tx);
  }
  p.end();

  oldrx = (uint) rx;
  oldtx = (uint) tx;

  (this->pixmap())->fill(QColor::QColor(black));
  bitBlt(this->pixmap(), 0, 0, leds);
  bitBlt(this->pixmap(), 0, DOCKOFFSET, Temp1);
  repaint(0, 0, DOCKWIDTH, DOCKHEIGHT, false);

  delete (leds);
}


void DockedScan::setColors(void)
{
  ScannerData  *scandata = ISDNData.scannerData();

  GraphColor[TYPEREC] = scandata->graphColor(0, TYPEREC);
  GraphColor[TYPETRA] = scandata->graphColor(0, TYPETRA);
}


void DockedScan::mousePressEvent(QMouseEvent *event)
{
  switch (event->button())
  {
    case LeftButton : emit leftClick();
                      break;
    case RightButton: emit rightClick();
  }
}
