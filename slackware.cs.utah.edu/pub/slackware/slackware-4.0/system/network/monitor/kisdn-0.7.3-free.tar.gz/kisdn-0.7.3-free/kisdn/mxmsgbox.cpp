/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: mxmsgbox.cpp,v 1.1.1.1 1998/11/21 10:18:58 twesthei Exp $
//
// $Log: mxmsgbox.cpp,v $
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
//
// Revision 1.4  1998/10/27 19:35:59  twesthei
// New message box (No ISDN Support) and according pixmap
//
// Revision 1.3  1998/10/27 15:17:21  twesthei
// Added new message box (not implemented), answer call is already
// using it...
//
// Revision 1.2  1998/10/26 18:57:32  twesthei
// Added a a priori check for the sound driver and some
// error message boxes so problems with the sound driver
// will show up at startup
//
// Revision 1.1  1998/10/26 15:15:08  twesthei
// *** empty log message ***
//


#include <kapp.h>

#include "mxmsgbox.h"


MXMessageBox::MXMessageBox(mxpixmap pm, const QString& cap, const QString& txt, QWidget *parent, 
			   const char *name, bool modal) : QDialog(parent, name, modal),
			   				   _caption(cap),
			   		                   _text(txt),
					                   _distpmlabel(30),
					                   _distlogobutton(30),
					                   _paddingupper(30),
					                   _paddinglower(8),
					                   _margin(10)
{
  int      w1, w2;
  int      h = 0;
  int      tmp1, tmp2;
  QString  xpmfile;
    
  setCaption(_caption);  
    
  switch (pm)
  {
    case Phone     : xpmfile = "phone.xpm";
                     break;
    case Keys      : xpmfile = "keys.xpm";
                     break;
    case Soundcard : xpmfile = "soundcard.xpm";
                     break;
    case ISDNCard  : xpmfile = "isdncard.xpm";
                     break;
    case Screws    : xpmfile = "implemented.xpm";
  }
  
  _loader = kapp->getIconLoader();

  _pixmap = _loader->loadIcon(xpmfile);

  _pmlabel = new QLabel(this);
  _pmlabel->setPixmap(_pixmap);
  _pmlabel->adjustSize();
  
  _textlabel = new QLabel(_text, this);
  _textlabel->adjustSize();
  
  _etched = new QFrame(this);
  _etched->setFrameStyle(QFrame::HLine | QFrame::Sunken);
  _etched->setLineWidth(2);
  
  _logo = new MXLogo("millenniumx.gif", this);
  _logo->adjustSize();
  
  _button = new QPushButton("OK", this);
  _button->adjustSize();
      
  w1   = 2*_margin+_pmlabel->width()+_distpmlabel   +_textlabel->width();
  w2   = 2*_margin+_logo->width()   +_distlogobutton+_button->width();
  
  tmp1 = _pmlabel->height();
  tmp2 = _textlabel->height();
  
  h    = 2*_margin+((tmp1 > tmp2) ? tmp1 : tmp2)+_paddingupper+2+_paddinglower;
  
  tmp1 = _logo->height();
  tmp2 = _button->height();
  
  h   += (tmp1 > tmp2) ? tmp1 : tmp2;
  
  setFixedSize((w1 > w2) ? w1 : w2, h);
  
  connect(_button, SIGNAL(clicked()), this, SLOT(accept()));
}


void  MXMessageBox::resizeEvent(QResizeEvent *)
{
  int  w = width();
  int  tmp1, tmp2;
  int  etchedy;
  int  buty;
  
  _pmlabel->move(_margin, _margin);
  _textlabel->move(_margin+_pmlabel->width()+_distpmlabel, _margin);
  
  tmp1 = _pmlabel->height();
  tmp2 = _textlabel->height(); 
  
  etchedy = _margin+((tmp1 > tmp2) ? tmp1 : tmp2)+_paddingupper;
  
  _etched->setGeometry(_margin, etchedy, w-2*_margin, 2);
  
  tmp1 = _logo->height();
  tmp2 = _button->height();
  buty = etchedy+2+_paddinglower;
  
  _logo->move(_margin, buty+(tmp1-tmp2)/2);
  _button->move(w-_margin-_button->width(), buty);
}



