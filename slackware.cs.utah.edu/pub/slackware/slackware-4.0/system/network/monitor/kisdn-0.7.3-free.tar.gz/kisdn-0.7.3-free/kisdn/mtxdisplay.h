/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: mtxdisplay.h,v 1.2 1998/11/21 12:35:28 twesthei Exp $
//
// $Log: mtxdisplay.h,v $
// Revision 1.2  1998/11/21 12:35:28  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#ifndef __MTXDISPLAY_H
#define __MTXDISPLAY_H

#include <qpixmap.h>
#include <qstring.h>


class MatrixFont
{
  private:
  
    QPixmap  mtxspace, mtxperiod, mtxcomma, mtxlpar, mtxrpar, mtxss;
    QPixmap  mtx0, mtx1, mtx2, mtx3, mtx4;
    QPixmap  mtx5, mtx6, mtx7, mtx8, mtx9;
    QPixmap  mtxA, mtxB, mtxC, mtxD, mtxE, mtxF, mtxG, mtxH, mtxI, mtxJ;
    QPixmap  mtxK, mtxL, mtxM, mtxN, mtxO, mtxP, mtxQ, mtxR, mtxS, mtxT;
    QPixmap  mtxU, mtxV, mtxW, mtxX, mtxY, mtxZ;
    QPixmap  mtxAE, mtxOE, mtxUE;
    QPixmap  mtxa, mtxb, mtxc, mtxd, mtxe, mtxf, mtxg, mtxh, mtxi, mtxj;
    QPixmap  mtxk, mtxl, mtxm, mtxn, mtxo, mtxp, mtxq, mtxr, mtxs, mtxt;
    QPixmap  mtxu, mtxv, mtxw, mtxx, mtxy, mtxz;
    QPixmap  mtxae, mtxoe, mtxue;
    
    int      _width, _height;
    
  public:
  
    MatrixFont(const char *, int, int);
    ~MatrixFont() {}
  	       
    const QPixmap *letter(char);
    
    int width()  const { return _width;  }
    int height() const { return _height; }
};


class MatrixPixmap : public QPixmap
{
  private:
  
    QString     _text;    
    MatrixFont  *font;
    
  public:
  
    MatrixPixmap(MatrixFont *f) : font(f) {}
    MatrixPixmap(MatrixFont *, const char *);
    ~MatrixPixmap() {}
    
    const char  *text()  const { return _text.data(); }
    
    void  setText(const char *);
};


#endif
