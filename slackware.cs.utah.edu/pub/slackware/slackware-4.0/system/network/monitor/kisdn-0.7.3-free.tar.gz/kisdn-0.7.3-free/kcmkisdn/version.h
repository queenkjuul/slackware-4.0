#ifndef __KISDNVERSION
#define __KISDNVERSION

#define KISDNVERSION "0.7.3"

#endif
