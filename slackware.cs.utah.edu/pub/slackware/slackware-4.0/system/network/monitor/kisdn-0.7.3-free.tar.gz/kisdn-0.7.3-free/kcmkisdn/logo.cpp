/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#include <qpixmap.h>
#include <qtabbar.h>
#include <kapp.h>

#include "antialiasedimg.h"
#include "logo.h"


LogoTabDialog::LogoTabDialog(QWidget *parent, const char *name, bool modal) :
			     QTabDialog(parent, name, modal),
			     helpbut(0L),
			     applybut(0L)			
{
  Logo = new MXLogo( "mx.gif", this);
  Logo->move(10, 370);
}


LogoTabDialog::LogoTabDialog( QString filename, QWidget *parent, 
			      const char *name, bool modal) :
			     QTabDialog(parent, name, modal),
			     helpbut(0L),
			     applybut(0L)			
{
  Logo = new MXLogo( filename.data(), this);
  Logo->move(10, 370);
}


LogoTabDialog::LogoTabDialog(const char **XPM, QWidget *parent, const char *name, bool modal) :
			     QTabDialog(parent, name, modal),
			     helpbut(0L),
			     applybut(0L)
{
  KIconLoader  *loader = kapp->getIconLoader();

  Logo = new QLabel(this);
  Logo->setPixmap(QPixmap(loader->loadIcon(**XPM)));
  Logo->move(10, 370);
}


LogoTabDialog::LogoTabDialog(const char **XPM, uint x, uint y, QWidget *parent, const char *name,
			     bool modal) : QTabDialog(parent, name, modal),
			     		   helpbut(0L),
					   applybut(0L)
{
  KIconLoader  *loader = kapp->getIconLoader();

  Logo = new QLabel(this);
  Logo->setPixmap(QPixmap(loader->loadIcon(**XPM)));
  Logo->move(x, y);
}


LogoTabDialog::LogoTabDialog(uint x, uint y, QWidget *parent, const char *name, bool modal) :
			     QTabDialog(parent, name, modal),
			     helpbut(0L),
			     applybut(0L)
{
  AntiAliasedImage ai;
  QPixmap pm;

  Logo = new MXLogo( "mx.gif", this);
  Logo->move(x, y);
}


void LogoTabDialog::setHelpButton(const char *text)
{
  ushort  margin  = 5;

  helpbut = new QPushButton(text, this);
  helpbut->adjustSize();
  helpbut->move(Logo->x()+Logo->width()+margin, Logo->y());
  connect(helpbut, SIGNAL(clicked()), this, SLOT(help()));

  if (applybut) applybut->move(helpbut->x()+helpbut->width()+6, applybut->y());
}


void LogoTabDialog::setApplyButton(const char *text)
{
  ushort  margin  = 5;

  applybut = new QPushButton(text, this);
  applybut->adjustSize();
  applybut->move(Logo->x()+Logo->width()+margin, Logo->y());
  connect(applybut, SIGNAL(clicked()), this, SLOT(applyInternal()));

  if (helpbut) applybut->move(helpbut->x()+helpbut->width()+6, applybut->y());
}


void LogoTabDialog::addPage(QWidget *child, const QString &label, const QString &helpPage)
{
  if (!helpPage.isEmpty() && !helpbut) setHelpButton();

  helpNames.append(helpPage.data());
  QTabDialog::addTab(child, label);
}


void LogoTabDialog::setCaption(const QString& cap)
{
  QTabDialog::setCaption(cap.data());
}


void LogoTabDialog::help()
{
  QString name;

  name = helpNames.at(tabBar()->currentTab());
  kapp->invokeHTMLHelp(name, "");
}


void LogoTabDialog::addWidget( QWidget *widget )
{
  w = widget;
  w->setGeometry( 0, 0, width(), height() - Logo->height() - 10 );
  hasWidget = true;
}


void LogoTabDialog::resizeEvent(QResizeEvent *e)
{
  uint  margin   = 5;
  uint  h        = height()-margin-Logo->height() -1;
  int   leftmost = Logo->x()+Logo->width()+2*margin;

  QTabDialog::resizeEvent(e);
  Logo->move(2*margin, h);

  if (helpbut)
  {
    helpbut->move(leftmost, h-1);
    leftmost += helpbut->width()+6;
  }

  if (applybut) applybut->move(leftmost, h-1);
}
