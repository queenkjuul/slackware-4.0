#include <qapp.h>
#include <qfile.h>
#include <qfont.h>
#include <qmlined.h>
#include <qpixmap.h>
#include <qtextstream.h>
#include <qtimer.h>

#include "logo.h"
#include "splashscreen.h"

SplashScreen::SplashScreen( const char* pixmapPath, int sec ) :
  QLabel( 0, "splashscreen", WStyle_NoBorder | WStyle_Customize )
{
  QPixmap pxm;
  if( !pxm.load( pixmapPath ) )
  {
    debug( "Can't find splashscreen image" );
    return;
  }

  resize( pxm.size() );
  setPixmap( pxm );
  setMargin( 8 );
  setAlignment( AlignCenter );
  setFrameStyle ( WinPanel | Raised );
  move( (QApplication::desktop()->width() - width())/2,
  	(QApplication::desktop()->height() - height())/2 );

  QTimer::singleShot( sec * 1000, this, SLOT( finished() ) );

  show();
}


SplashScreen::SplashScreen( const char *docPath, int sec, bool cancelButton )
{
  QString text;

  dialog = new LogoTabDialog( this, "dialog", true );
  if ( cancelButton )
    dialog->setCancelButton();
  dialog->setGeometry( 0, 0, 500, 500 );

  QFont font;
  font.setFamily( "Courier" );
  font.setFixedPitch( true );
  QMultiLineEdit *viewer = new QMultiLineEdit( dialog, "viewer" );
  viewer->setReadOnly( true );
  viewer->setFont( font );
  dialog->addWidget( viewer );

  QFile f( docPath );
  if ( f.open( IO_ReadOnly ) )
  {
    QTextStream ts( &f );

    while ( !ts.eof() )
    {
      text = ts.readLine();
      viewer->append( text.data() );
    }
    f.close();
  }
}

void SplashScreen::finished()
{
  delete this;
}

bool SplashScreen::exec()
{
  return ( dialog->exec() != 0 );
}


SplashScreen::~SplashScreen()
{
}
