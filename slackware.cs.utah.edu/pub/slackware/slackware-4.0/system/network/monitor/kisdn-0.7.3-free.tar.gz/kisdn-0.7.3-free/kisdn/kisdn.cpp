/*
 *
 *
 *          kISDN - a frontend to the isdn4linux (i4l) package
 *		    for the K Desktop Environment including
 *		    setup, monitor, account managing and voice
 *		    phone module
 *
 * 			     Revision 0.7.1
 *			      Free Edition
 *
 *            		   Copyright (C)1998
 *
 *	Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *            Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 *
 */

// $Id: kisdn.cpp,v 1.5 1998/12/19 09:27:42 gis Exp $
//
// $Log: kisdn.cpp,v $
// Revision 1.5  1998/12/19 09:27:42  gis
//
// Fixed sessionmanagement for KDE 1.1 (Matthias broke something :-/)
// and updated po-files
//
// Revision 1.4  1998/12/16 09:52:44  gis
//
// background fix for help docs and fix for KFileDialog in audiowidget (wrong
// directory) and fixed TopWidget shown, when kisdn is restarted via SM
//
// Revision 1.3  1998/12/12 23:40:05  gis
//
// small fix for splashscreen not shown on first start (showSplashScreen not yet
// in kcmkisdnrc)
//
// Revision 1.2  1998/11/21 12:34:42  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/soundcard.h>

#include <qstrlist.h>

#include <kapp.h>
#include <kprocess.h>
#include <ktopwidget.h>
#include <kwm.h>

#include "adapter.h"
#include "connection.h"
#include "dockedwin.h"
#include "general.h"
#include "kdefrontend.h"
#include "kisdn.h"
#include "mdetectdlg.h"
#include "monitor.h"
#include "mykapp.h"
#include "root.h"
#include "splashscreen.h"
#include "version.h"

#define DEBUG


KISDN          *kISDNMainWidget = 0L;
KDEFrontEnd    *frontend        = 0L;
MyKApplication *myKApp          = 0L;


/*
 * Construction/destruction of KISDN
 ************************************/

KISDN::KISDN(const char *name) : KTopLevelWidget(name)
{
  resize( 0, 0 );
  int  i;

  DockWindow    = 0L;
  MonitorWindow = 0L;
  realUid       = getuid();

  for (i = 0; i < 6; i++) bufferedScripts[i] = false;

  setFilePermissions();

  if (!ISDNData.load())
  {
    ::message("*** FATAL ERROR ***");
    ::message("Unable to load configuration file, exiting now");
    exit(1);
  }

  isDocked = ISDNData.customData()->sessionDocked();

  connect(kapp, SIGNAL(shutDown()), this, SLOT(slotSessionClose()));

  isdnconfig = new ISDNConfig();
  connection = (Connection *) 0L;

  analyzeSetup();

  if (isdnconfig->ISDNsupported)
  {
    isdnctrl = new ISDNCtrl();
    netctrl  = new NetCtrl(isdnctrl, isdnconfig);
    isdninfo = new ISDNInfo(isdnctrl, netctrl, isdnconfig);

    connect(isdninfo, SIGNAL(sigDialing(ushort)),          this,    SLOT(slotDialing(ushort)));
    connect(isdninfo, SIGNAL(sigBusy(ushort)),             this,    SLOT(slotBusy(ushort)));
    connect(isdninfo, SIGNAL(sigLinkUp(ushort)),           this,    SLOT(slotLinkUp(ushort)));
    connect(isdninfo, SIGNAL(sigLinkDown(ushort)),         this,    SLOT(slotLinkDown(ushort)));
    connect(this,     SIGNAL(sigDoDDisengage()),           netctrl, SLOT(slotDoDDisengage()));
    connect(this,     SIGNAL(sigDoDEngage(AccountData *)), netctrl, SLOT(slotDoDEngage(AccountData *)));

    pppstatus  = new PPPStatus(isdninfo);
  }

  makeISPList();
  ispindex = -1;

#ifdef HAVE_GLOBAL_SHORTCUTS
  if (isdnconfig->ISDNsupported)
  {
    globalKeys = new KGlobalAccel();
    myKApp->setGlobalAccel( globalKeys );

    globalKeys->insertItem(i18n("Connect to active ISP"), "kISDN-Connect",
			   "CTRL+ALT+C");
    globalKeys->insertItem(i18n("Disconnect from ISP"),   "kISDN-Disconnect",
			   "CTRL+ALT+D");

    globalKeys->connectItem("kISDN-Connect",    this, SLOT(beDial()));
    globalKeys->connectItem("kISDN-Disconnect", this, SLOT(beHangup()));
    globalKeys->readSettings();
  }
#endif
}


KISDN::~KISDN()
{
  if (!MonitorWindow) delete MonitorWindow;
  else
  {
    if (!DockWindow) delete DockWindow;
  }

  if (connection != (Connection *) 0L)
  {
     delete connection;
  }

  if (isdnconfig->ISDNsupported)
  {
    delete pppstatus;
    delete isdnctrl;
    delete netctrl;
    delete isdninfo;
  }

  if (hadtoload && modloaded) removeISDNModules();

  delete isdnconfig;

  for (int i = 0; i < 6; i++)
  {
    if (bufferedScripts[i])
    {
      restoreScripts();
      break;
    }
  }
}


bool KISDN::isKISDNInternalAccount()
{
  return (ispindex >= isdnconfig->numext);
}


/*
 * Frontend <-> Backend interface
 *********************************/

void KISDN::slotCommandRcvd(ISDNCommand *isdncmd)
{
#ifdef DEBUG
  char  bekey[9][16] = {"NOCMD",  "ENGAGE", "ISPCHG", "DIAL",
                        "HANGUP", "DODON",  "DODOFF", "ISPLISTCHG", "QUIT"};

  fprintf(stderr, "kISDN: [BE_%s]\n", bekey[isdncmd->cmdCode()]);
#endif
  switch (isdncmd->cmdCode())
  {
    case BE_NOCMD      : break;
    case BE_ENGAGE     : beEngage(isdncmd);
    		 	 break;
    case BE_ISPCHG     : beISPChange(isdncmd);
    			 break;
    case BE_DIAL       : beDial();
    		 	 break;
    case BE_HANGUP     : beHangup();
    			 break;
    case BE_DODON      : beDoDOn();
    			 break;
    case BE_DODOFF     : beDoDOff();
    			 break;
    case BE_ISPLISTCHG : beISPListChange();
                         break;
    case BE_QUIT       : beQuit();
                         break;
    default            : fprintf(stderr, "kISDN: (BE) Unknown backend function call (%i)\n",
                                        isdncmd->cmdCode());
  }
}


void KISDN::beEngage(ISDNCommand *isdncmd)
{
  /*
   * Frontends are allowed to engage an ISP directly
   * only if we actually don't have an ISP (i.e. at startup)
   **********************************************************/

  if (ispindex == -1)
  {
    ::message("(BE) Valid request");
    engageISP(isdncmd->isp()); 		
  }
  else ::message("(BE) Ignored");
}


void KISDN::engageISP(int isp)
{
  ispindex  = isp;
  ispencaps = ispenclist[ispindex];

  if (ispindex >= isdnconfig->numtot) ::message("(BE) Invalid ISP index in beEngage");
  else
  {
    if (isKISDNInternalAccount())			
    {
      bufferScripts();

      if (ispencaps == PPPDEV)
      {
        strcpy(devmaster, isdnconfig->PPPDev);
        strcpy(devslave,  isdnconfig->PPPSlave);
	
	isdnconfig->setPPP(true);
      }
      else
      {
        strcpy(devmaster, isdnconfig->RawDev);
        strcpy(devslave,  isdnconfig->RawSlave);
	
	isdnconfig->setPPP(false);
      }

      AccountData  *acc = currentInternalAccount();

      if (!acc->enabledAccount())
      {
        ::message("Chosen account is disabled");
        ispindex = -1;
        return;
      }

      connection       = new Connection(acc, devmaster, devslave, netctrl, isdnctrl, isdnconfig);
      CustomData *cust = ISDNData.customData();

      if (cust->dialOnDemand()) emit sigDoDEngage(acc);
    }
    else strcpy(devmaster, isdnconfig->prename[ispindex]);

    ISDNData.setAccountIndex(ispindex);
  }
}


void KISDN::beISPChange(ISDNCommand *isdncmd)
{
  if (ispindex != isdncmd->isp())		
  {
    disengageISP();
    engageISP(isdncmd->isp());
  }
}


void KISDN::disengageISP()
{
  if (ispindex < 0) ::message("(BE) No device engaged");
  else
  {
    if (isKISDNInternalAccount() && (connection != (Connection *) 0L))
    {
      CustomData *cust = ISDNData.customData();

      if (cust->dialOnDemand()) emit sigDoDDisengage();

      delete connection;
      connection = 0L;
      restoreScripts();
    }
    ispindex = -1;
  }
}


void KISDN::beDial()
{
  if (ispindex < isdnconfig->numext) isdnctrl->Dial(devmaster);
  else
  {
    if (connection != 0L) connection->dialOut();
    else                  ::message("Connection not configured");
  }
}


void KISDN::beHangup()
{
  if (ispindex < isdnconfig->numext) isdnctrl->Hangup(devmaster);
  else
  {
    if (connection != 0L) connection->hangUp();
    else 		  ::message("Connection not configured");
  }
}


void KISDN::beDoDOn() 	 	
{
  if (ispindex >= isdnconfig->numtot) ::message("(BE) Invalid ISP index in beDoDOn");
  else
  {
    if (!isKISDNInternalAccount()) ::message("DoD not yet supported for external interfaces");		
    else						
    {	
      netctrl->setActIface(devmaster);		// This is a dirty hack...

      CustomData *cust = ISDNData.customData();

      cust->setDialOnDemand(true);
      emit sigDoDEngage(currentInternalAccount());
    }
  }
}


void KISDN::beDoDOff() 	 	
{
  CustomData *cust = ISDNData.customData();

  cust->setDialOnDemand(false);
  emit sigDoDDisengage();
}


void KISDN::beISPListChange()
{
  delete isplist;

  makeISPList();
  ispindex = -1;

  MonitorWindow->reloadAccounts(isplist, ispcount);
}


void KISDN::beQuit()
{
  slotQuit();
}


void KISDN::hangupEventually()
{
  if (isdnconfig->ISDNsupported)
  {
    if (isOnline()) beHangup();
    else            ::message("Not connected.");
  }
}


/*
 * Quitting the application + Sessionmanagement
 **********************************************/

// notify all the frontends that we get quitted now... they should
// save something now, if they have to do that
void KISDN::slotSessionClose()
{
  //  emit sigSessionClose(); // why do I get a segfault, when
  // saveSession in the frontends is called by a signal?
  // why does it work, when called normally????

  if (MonitorWindow != 0L) MonitorWindow->saveSession();
  else if (DockWindow != 0L) DockWindow->saveSession();

  shutDown(false); 	// don't force hangup
}

// now we're finally shut down. The frontends are NOT notified!
void KISDN::shutDown(bool forceHangup)
{
  if (isdnconfig->ISDNsupported)
  {
    if (isOnline())
    {
      if (ISDNData.customData()->disconnect() || forceHangup) beHangup();
    }
  }

  slotQuit();
}


void KISDN::slotQuit()
{
  ISDNData.customData()->setSessionDocked(isDocked);
  ISDNData.saveSession();

  delete this;
  kapp->quit();
}


/*
 * Frontend creation/destruction
 ********************************/

void KISDN::createFrontend()
{
  if (ISDNData.customData()->docking() || isDocked) createDockedMonitor();
  else 				                    createMonitor();

  if (isdnconfig->ISDNsupported) engageISP(ISDNData.accountIndex());
}


void KISDN::createDockedMonitor()
{
  bool haveISDNSupport = isdnconfig->ISDNsupported;

  isDocked = true;

  if (haveISDNSupport)
  {
    DockWindow = new DockedWin(isdnconfig, isdninfo, pppstatus, ispcount, isplist);
    CHECK_PTR(DockWindow);
    connect(netctrl, SIGNAL(sigDoDEngaged()),      DockWindow, SLOT(slotShowDoDEnabled()));
    connect(netctrl, SIGNAL(sigDoDDisengaged()),   DockWindow, SLOT(slotShowDoDDisabled()));
  }
  else
  {
    DockWindow = new DockedWin();
    CHECK_PTR(DockWindow);
  }

//  kapp->setMainWidget(DockWindow);
  KWM::setDockWindow(DockWindow->winId());

  connect(this,       SIGNAL(sigSessionClose()),                DockWindow, SLOT(saveSession()));
  connect(DockWindow, SIGNAL(sigCommand(ISDNCommand *)),        this,       SLOT(slotCommandRcvd(ISDNCommand *)));
  connect(DockWindow, SIGNAL(sigUndockMonitor()),               this,       SLOT(slotUndockMonitor()));

  DockWindow->show();
}


void KISDN::createMonitor()
{
  bool haveISDNSupport = isdnconfig->ISDNsupported;

  MonitorWindow = new Monitor(isdnconfig, isdninfo, frontend, ispcount, isplist);
  CHECK_PTR(MonitorWindow);

  if (haveISDNSupport)
  {
    connect(isdninfo, SIGNAL(sigBusy(ushort)),          MonitorWindow, SLOT(slotBusy(ushort)));
    connect(isdninfo, SIGNAL(sigDialing(ushort)),       MonitorWindow, SLOT(slotDial(ushort)));
    connect(isdninfo, SIGNAL(sigLinkDown(ushort)),      MonitorWindow, SLOT(slotLinkDown(ushort)));
    connect(isdninfo, SIGNAL(sigLinkUp(ushort)),        MonitorWindow, SLOT(slotLinkUp(ushort)));
    connect(isdninfo, SIGNAL(sigNewIPLocalA(char *)),   MonitorWindow, SLOT(slotNewIPLocalA(char *)));
    connect(isdninfo, SIGNAL(sigNewIPLocalB(char *)),   MonitorWindow, SLOT(slotNewIPLocalB(char *)));
    connect(isdninfo, SIGNAL(sigNewIPRemoteA(char *)),  MonitorWindow, SLOT(slotNewIPRemoteA(char *)));
    connect(isdninfo, SIGNAL(sigNewIPRemoteB(char *)),  MonitorWindow, SLOT(slotNewIPRemoteB(char *)));
    connect(isdninfo, SIGNAL(sigReceiveOff(ushort)),    MonitorWindow, SLOT(slotReceiveOff(ushort)));
    connect(isdninfo, SIGNAL(sigReceiveOn(ushort)),     MonitorWindow, SLOT(slotReceiveOn(ushort)));
    connect(isdninfo, SIGNAL(sigTransmitOff(ushort)),   MonitorWindow, SLOT(slotTransmitOff(ushort)));
    connect(isdninfo, SIGNAL(sigTransmitOn(ushort)),    MonitorWindow, SLOT(slotTransmitOn(ushort)));
    connect(netctrl,  SIGNAL(sigDoDDisengaged()),       MonitorWindow, SLOT(slotDoDOff()));
    connect(netctrl,  SIGNAL(sigDoDEngaged()),          MonitorWindow, SLOT(slotDoDOn()));

    connect(pppstatus,  SIGNAL(sigNewTransferRates(PPPInfo *)),   MonitorWindow, SLOT(slotNewScan(PPPInfo *)));
  }

  connect(MonitorWindow, SIGNAL(sigCommand(ISDNCommand *)), this, SLOT(slotCommandRcvd(ISDNCommand *)));
  MonitorWindow->wakeUp();

//  kapp->setMainWidget(MonitorWindow);
  connect(MonitorWindow, SIGNAL(sigDockMe()),       this,          SLOT(slotDockMonitor()));
  connect(this,          SIGNAL(sigSessionClose()), MonitorWindow, SLOT(saveSession()));

#ifdef HAVE_GLOBAL_SHORTCUTS
  MonitorWindow->passGlobalKeys(globalKeys);
#endif
  MonitorWindow->show();
}


void KISDN::slotDockMonitor()
{
  createDockedMonitor();

  delete MonitorWindow;
  MonitorWindow = 0L;
}


void KISDN::slotUndockMonitor()
{
  createMonitor();

  if (isDocked)
    delete DockWindow;

  isDocked = false;
  DockWindow = 0L;
}


void KISDN::slotLinkUp(ushort ch)
{
  QString  ID = isdninfo->queryCallerID(ch);

  if (!ISDNData.customData()->soundOnAuth()) playSound(CONNECT);

  // fix this!!! We need a better way to determine whether we are authenticated
  QTimer::singleShot(5000, this, SLOT(slotLinkAuthenticated()));
}


void KISDN::slotLinkAuthenticated()
{
  if (isOnline())
  {
    emit sigLinkAuthenticated(0); 		// 0 is just for consistency

    if (ISDNData.customData()->soundOnAuth()) playSound(CONNECT);

    // script execution

    if (isKISDNInternalAccount())
    {
      AccountData *acc = currentInternalAccount();

      if (acc->connectScripts()->isEnabled())
        executeScripts(acc->connectScripts()->scriptList(), ScriptData::PASTCONNECT);
    }
  }
  //  else // we're not online, and might say "Authentication failed, or sth...
}


void KISDN::slotLinkDown(ushort ch)
{
  CustomData *cust = ISDNData.customData();

  if (cust->dialOnDemand()) 			// I removed ...&& !forcedhangup, so DoD will persist!
  {
    if (!netctrl->routeHaveDefault(devmaster))
    {
      if (netctrl->restoreDoD()) ::message("DoD successfully restored");
      else                       ::message("Failed to restore DoD");
    }
    else ::message("We still have a default route");
  }

  if (isKISDNInternalAccount())
  {
    AccountData *acc = currentInternalAccount();

    if (acc->disconnectScripts()->isEnabled())
      executeScripts(acc->disconnectScripts()->scriptList(), ScriptData::PASTDISCONNECT);

    if ((acc->masterDevice()->protEncaps() == Device::SYNCPPP) && !cust->dialOnDemand())
      netctrl->resetIPAddresses(devmaster);
  }
  else if (isdnconfig->pretype[ispindex] == PPPDEV)
         netctrl->resetIPAddresses(isdnconfig->prename[ispindex]);
}


void  KISDN::slotBusy(ushort ch)
{
  playSound(BUSY);
}


/*
 * Initialization stuff
 ***********************/

void KISDN::dialogISDNModulesDetected(uint adtype)
{
  CustomData *cust = ISDNData.customData();

  if (cust->showHisaxDetect())
  {
    MDetectDialog  *detectdlg = new MDetectDialog(adtype);

    detectdlg->exec();
    cust->setShowHisaxDetect(!(detectdlg->showagain)->isChecked());
    delete detectdlg;
  }
}


void KISDN::analyzeSetup()
{
  GeneralData  *gen = ISDNData.generalData();

  modloaded = checkForISDNModules();
  hadtoload = false;

  if (gen->loadAsModule())
  {
    if (modloaded) dialogISDNModulesDetected(gen->adapterType());
    else           insertISDNModules();
  }

  if (!modloaded && !checkISDNBuiltIn())
  {
    isdnconfig->ISDNsupported = false;

    if (frontend->messageNoISDNSupport(this) == 0) exit(0);
  }

  isdnconfig->setTimRuSupport(checkForTimRuExtensions());

  if (isdnconfig->ISDNsupported) scanInterfaces();
}


bool KISDN::checkForModule(char *ModName)
{
  FILE  *fhandle;
  char  buffer[128], modkey[32];
  bool  localized = false;

  if ((bool) (fhandle = fopen("/proc/modules", "r")))
  {
    while (!feof(fhandle) && !localized)
    {
      fgets(buffer, 127, fhandle);
      sscanf(buffer, "%s", modkey);
      localized = !strcmp(modkey, ModName);
    }
    return (localized);				
  }
  else
  {
    frontend->messageCantOpenProcModules(this);		
    return false;
  }
}


bool KISDN::checkForTimRuExtensions()
{
  QString  path     = "/usr/src/linux/include/linux/isdn.h";
  bool     hastimru = false;
  FILE     *fhandle;
  char     buffer[14];
  char     search[] = "int  stopped;";
  int      i;

  if ((fhandle = fopen(path.data(), "r")))
  {
    fgets(buffer, 14, fhandle);

    while (!feof(fhandle) && !hastimru)
    {
      if (!strcmp(search, buffer)) hastimru = true;
      else
      {
	for (i = 1; i < 13; i++) buffer[i-1] = buffer[i];
	
	buffer[12] = fgetc(fhandle);
      }
    }

    fclose(fhandle);

    if (hastimru) ::message("Recent HiSax driver");
    else          ::message("Standard HiSax driver");
  }
  else cout << PROMPT << "Can't open " << path.data() << " (assume standard HiSax)" << endl;

  return hastimru;
}


bool KISDN::scanInterfaces()
{
  /* Scans /proc/net/dev for interfaces of the form ippp[n] and isdn[n]
   * Sets global interfaces PPPDev and RawDev that way, that kISDN
   * interfaces and preconfigured interfaces don't collide.
   * In addition, it fills in the fields prename[i] and pretype[i], the
   * former being the full name of the preconfigured interface i (for
   * example 'isdn0'), the latter it's type (RAWDEV/PPPDEV).
   *********************************************************************/

  bool    rawdev[MAXDEV], pppdev[MAXDEV];	// false = available, true = in use
  ushort  i, j, preind = 0;
  FILE    *fhd;
  char    buf[256], *p, ifname[16];
  uint    ifindex;

  memset(isdnconfig->PPPDev,   0, sizeof(isdnconfig->PPPDev));
  memset(isdnconfig->PPPSlave, 0, sizeof(isdnconfig->PPPSlave));
  memset(isdnconfig->RawDev,   0, sizeof(isdnconfig->RawDev));
  memset(isdnconfig->RawSlave, 0, sizeof(isdnconfig->RawSlave));

  for (i = 0; i < MAXDEV; i++)			
  {
    rawdev[i] = false;
    pppdev[i] = false;
  }

  fhd = fopen("/proc/net/dev", "r");

  if (fhd)
  {
    ::message("Scanning interfaces");

    while (!feof(fhd))
    {
      fgets(buf, 255, fhd);

      if ((p = strchr(buf, ':')))
      {
        *p = '\0';
        sscanf(buf, "%s", ifname);
	
        if (!strncmp(ifname, "ippp", 4))
        {
          sscanf(ifname, "ippp%i", &ifindex);
	
          if (!preind) fprintf(stderr, "\n");
	
          fprintf(stderr, "\t%s : PPP interface (index %i)\n", ifname, ifindex);
          pppdev[ifindex] = true;
          strncpy(isdnconfig->prename[preind], ifname, 7);	
          isdnconfig->prename[preind][7] = '\0';
          isdnconfig->pretype[preind++]  = PPPDEV;
        }
        else if (!strncmp(ifname, "isdn", 4))
        {
          sscanf(ifname, "isdn%i", &ifindex);
	
      	  if (!preind) fprintf(stderr, "\n");
	
          fprintf(stderr, "\t%s : Raw interface (index %i)\n", ifname, ifindex);
          rawdev[ifindex] = true;
          strncpy(isdnconfig->prename[preind], ifname, 7);
          isdnconfig->prename[preind][7] = '\0';
          isdnconfig->pretype[preind++]  = RAWDEV;
        }
      }
    }
    fclose(fhd);

    if (preind) fprintf(stderr, "\n");

    isdnconfig->numext = preind;

    for (i = 0; (i < MAXDEV) && pppdev[i]; i++);
    if (i < MAXDEV)
    {
      sprintf(isdnconfig->PPPDev, "ippp%i", i);
      fprintf(stderr, "kISDN: Gonna use PPP interface %s\n",
                        isdnconfig->PPPDev);
    }
    else ::message("No PPP interface available !");

    for (j = i+1; (j < MAXDEV) && pppdev[j]; j++);
    if (j < MAXDEV)
    {
      sprintf(isdnconfig->PPPSlave, "ippp%i", j);
      fprintf(stderr, "kISDN: Gonna use PPP slave %s\n", isdnconfig->PPPSlave);
    }
    else ::message("No PPP slave available !");

    for (i = 0; (i < MAXDEV) && rawdev[i]; i++);
    if (i < MAXDEV)
    {
      sprintf(isdnconfig->RawDev, "isdn%i", i);
      fprintf(stderr, "kISDN: Gonna use Raw interface %s\n",
                        isdnconfig->RawDev);
    }
    else ::message("No Raw interface available !");

    for (j = i+1; (j < MAXDEV) && rawdev[j]; j++);
    if (j < MAXDEV)
    {
      sprintf(isdnconfig->RawSlave, "isdn%i", j);
      fprintf(stderr, "kISDN: Gonna use Raw slave %s\n", isdnconfig->RawSlave);
    }
    else ::message("No PPP slave available !");

    return true;
  }
  else
  {
    ::message("Can't open /proc/net/dev in scanInterfaces");
    return false;
  }
}


bool KISDN::checkISDNBuiltIn()
{
  FILE  *fhandle;
  bool  builtin;

  builtin = (bool) (fhandle = fopen("/dev/isdninfo", "r"));

  if (builtin) fclose(fhandle);

  return builtin;
}


/*
 * Backend account management
 *****************************/

void KISDN::makeISPList()
{
  ushort       i;
  int          intstart = isdnconfig->numext;
  AccountData  *acc     = ISDNData.firstAccount();
  bool         changed  = false;
  QString      isp, changedAccounts;
  int          dummy;

  isplist = new QStrList();

  for (i = 0; (i < MAXISP) && (i < intstart); i++)
  {
    isp.sprintf("External (%s)", isdnconfig->prename[i]);
    isplist->insert(isplist->count(), isp);
    ispenclist[i] = isdnconfig->pretype[i];
  }

  for (i = intstart; (i < MAXISP) && (acc != (AccountData *) 0L); i++)
  {
    if (acc->accountChanged())
    {
      changedAccounts += acc->providerName() + "\n";
      changed = true;
    }

    isplist->insert(isplist->count(), acc->providerName());
    ispenclist[i] = (acc->masterDevice()->protEncaps() == Device::SYNCPPP) ? PPPDEV : RAWDEV;

    acc = ISDNData.nextAccount();
  }

  isdnconfig->numtot = ispcount = i;
  fprintf(stderr, "kISDN: Total number of configured devices = %i\n", ispcount);

  if ((dummy = ISDNData.accountIndex()) >= ispcount)
  {
    ISDNData.setAccountIndex(ispcount-1);
    ISDNData.save();
    cout << PROMPT << "Account index ajustment (" << dummy << " to " << ispcount-1 << ")" << endl;
  }

  if (changed)
  {
    if (!ISDNData.customData()->firstTimeUser())
      frontend->messageAccountHasChanged(0, changedAccounts);
  }
}


AccountData *KISDN::locateAccount(int item)
{
  return  ISDNData.account(item);
}


AccountData *KISDN::currentInternalAccount()
{
  return  locateAccount(ispindex-isdnconfig->numext);
}


/*
 * ISDN driver modules and system scripts
 *****************************************/

void KISDN::insertISDNModules()
{
  Adapter      ad;
  GeneralData  *gen = ISDNData.generalData();

  hadtoload = false;

  if (gen->adapterType() == 21)					// AVM B1
  {
    ::message("AVM B1 setup (experimental)");

    insertCAPIModules();
    modloaded = checkForCAPI();
		
    if (!modloaded) frontend->messageCAPILoadingFailed(this);
    else
    {	
      hadtoload = true;	

      capictrl = new AVMB1Ctrl();
      capictrl->addCard(gen->ioAddress1().data(), gen->interrupt());
      capictrl->loadFirmware("/lib/isdn/b1.t4", 1);		// hardcoded in test phase
    }
  }
  else								// HSCX/ISAC based cards
  {
    ::message("HiSax setup");

    insertHiSaxModule();				
    modloaded = checkForModule("hisax");

    if (!modloaded) frontend->messageLoadingHiSaxFailed(this);
    else hadtoload = true;
  }
}


void KISDN::removeISDNModules()
{
  GeneralData  *gen = ISDNData.generalData();

  if (gen->adapterType() == 21) removeCAPIModules();
  else		                removeHiSaxModule();
}


bool KISDN::checkForCAPI()
{
  bool  capi = checkForModule("capiutil") &&
               checkForModule("kernelcapi") &&
               checkForModule("capidrv") &&
               checkForModule("capi");

  return capi;
}


bool KISDN::checkForISDNModules()
{
  GeneralData  *gen = ISDNData.generalData();

  if (gen->adapterType() == 21) return checkForCAPI();

  return checkForModule("hisax");
}


void KISDN::insertHiSaxModule()
{
  char         buffer[128], mem[16] = "", io0[16] = "", io1[16] = "", irq[8] = "";
  GeneralData  *gen = ISDNData.generalData();
  Adapter      ad;
  ushort       adtype = ad.NewIndex(gen->adapterType());
  if (ad.NeedMem[adtype]) sprintf(mem, "mem=%s", gen->memBaseAddress().data());

  if (ad.NeedIO1[adtype])
  {
    if (!ad.NeedIO2[adtype]) sprintf(io0, "io=%s", gen->ioAddress1().data());
    else
    {
      sprintf(io0, "io0=%s", gen->ioAddress1().data());
      sprintf(io1, "io1=%s", gen->ioAddress2().data());
    }
  }

  if (ad.NeedIRQ[adtype]) sprintf(irq, "irq=%i", gen->interrupt());

  sprintf(buffer,"%s %s %s %s %s %s type=%i protocol=%i id=%s\n",
                 gen->modprobePath().data(),
	         (ad.HLDriver[adtype]).data(),
	         mem,
	         io0,
	         io1,
	         irq,
	         ad.Type[adtype],
	         (gen->protocol() == GeneralData::PROT_1TR6) ? 1 : 2,
	         (ad.Id[adtype]).data());

  ::message("Insert HiSax module...");

  cout << PROMPT << buffer;

  ::becomeRoot();
  system(buffer);
  modloaded  = true;
}	


void KISDN::insertCAPIModules()
{
  char         buffer[128];
  int          ret;
  GeneralData  *gen = ISDNData.generalData();

  sprintf(buffer, "%s capidrv", gen->modprobePath().data());
  ::becomeRoot();
  ret = system(buffer);

  if ((ret < 0) || (ret == 127))
  {
    ::message("modprobe capidrv failed, can't resume");
    return;
  }

  sprintf(buffer, "%s capi", gen->modprobePath().data());
  ::becomeRoot();
  ret = system(buffer);

  if ((ret < 0) || (ret == 127))
  {
    ::message("modprobe capi failed");
    return;
  }
}


void KISDN::removeHiSaxModule()
{
  char         buffer[128];
  GeneralData  *gen = ISDNData.generalData();
  Adapter      ad;
  ushort       adtype = ad.NewIndex(gen->adapterType());

  sprintf(buffer,"%s -r %s", gen->modprobePath().data(), (ad.HLDriver[adtype]).data());

  fprintf(stderr, "kISDN: Removing HiSax module ... ");
  fflush(stderr);
  ::becomeRoot();
  system(buffer);

  modloaded  = checkForModule("hisax");

  if (!modloaded) fprintf(stderr, "succeeded\n");
  else            fprintf(stderr, "failed\n");
}


void KISDN::removeCAPIModules()
{
  char         buffer[128];
  GeneralData  *gen = ISDNData.generalData();
  bool         havemodule;

  delete capictrl;

  sprintf(buffer,"%s -r capi", gen->modprobePath().data());

  fprintf(stderr, "kISDN: Removing module capi ... ");
  fflush(stderr);
  ::becomeRoot();
  system(buffer);

  havemodule = checkForModule("capi");

  if (!havemodule) fprintf(stderr, "succeeded.\n");
  else
  {
    fprintf(stderr, "failed !\n");
    return;
  }

  modloaded = false;	// We now miss one of two modules...

  sprintf(buffer,"%s -r capidrv", gen->modprobePath().data());

  fprintf(stderr, "kISDN: Removing module capidrv ... ");
  fflush(stderr);
  ::becomeRoot();
  system(buffer);

  havemodule = checkForModule("capidrv");

  if (!havemodule) fprintf(stderr, "succeeded\n");
  else             fprintf(stderr, "failed\n");
}


void KISDN::bufferScripts()
{
  GeneralData  *gen = ISDNData.generalData();

  bufferedScripts[0] = backupFile(DNSFILE,    DNSSAVE,  false);
  bufferedScripts[1] = backupFile(OPTFILE,    OPTSAVE,  false);
  bufferedScripts[2] = backupFile(PAPFILE,    PAPSAVE,  true);
  bufferedScripts[3] = backupFile(CHAPFILE,   CHAPSAVE, true);

  if (gen->bufferIpUpDown())
  {
    bufferedScripts[4] = backupFile(IPUPFILE,   IPUPSAVE,   false);
    bufferedScripts[5] = backupFile(IPDOWNFILE, IPDOWNSAVE, false);
  }
}


bool KISDN::backupFile(const char *orig, const char *backup, bool secret)
{
  bool  stat;

  cout << PROMPT << orig << " is";

  ::remove(backup);

  if (stat = (::rename(orig, backup) < 0)) cout << " not";

  cout << " saved";

  if (!stat && secret)
  {
    chown(backup, 0, 0);
    chmod(backup, S_IRUSR | S_IWUSR);

    cout << " and set read/write-only for root";
  }

  cout << endl;
  return !stat;
}


void KISDN::restoreScripts()
{
  GeneralData  *gen = ISDNData.generalData();
  bool         suc[6];
  int          i;

  for (i = 0; i < 6; i++) suc[i] = true;

  if (bufferedScripts[0]) suc[0] = restoreFile(DNSFILE,    DNSSAVE,    false);
  if (bufferedScripts[1]) suc[1] = restoreFile(OPTFILE,    OPTSAVE,    false);
  if (bufferedScripts[2]) suc[2] = restoreFile(PAPFILE,    PAPSAVE,    true);
  if (bufferedScripts[3]) suc[3] = restoreFile(CHAPFILE,   CHAPSAVE,   true);

  if (gen->bufferIpUpDown())
  {
    if (bufferedScripts[4]) suc[4] = restoreFile(IPUPFILE,   IPUPSAVE,   false);
    if (bufferedScripts[5]) suc[5] = restoreFile(IPDOWNFILE, IPDOWNSAVE, false);
  }

  for (i = 0; i < 6; i++) bufferedScripts[i] = !suc[i];

  for (i = 0; i < 6; i++)
  {
    if (bufferedScripts[i])
    {
      frontend->messageScriptRestoringFailed(this);
      break;
    }
  }
}


bool KISDN::restoreFile(const char *orig, const char *backup, bool secret)
{
  bool  stat;

  cout << PROMPT << orig << " is";

  if (stat = (::rename(backup, orig) < 0)) cout << " not";

  cout << " restored";

  if (!stat && secret)
  {
    chown(orig, 0, 0);
    chmod(orig, S_IRUSR | S_IWUSR);

    cout << " and set read/write-only for root";
  }

  cout << endl;
  return !stat;
}


void KISDN::setFilePermissions()
{
  QString fname = kapp->localconfigdir() + "/kisdnrc";

  if (chmod(fname.data(), S_IREAD | S_IWRITE) != 0) frontend->messageCantSetPermissions(this, fname);
}


/*
 * Script processing
 ********************/

void KISDN::executeScripts(QStrList scripts, uint index)
{
  QString  script;

  execProcessCount[index] = 0;

  for (script = scripts.first(); !script.isNull() && !script.isEmpty(); script = scripts.next())
  {
    cout << PROMPT << "Executing [" << script.data() << "]" << endl;

    p = new Process( realUid );
    CHECK_PTR(p);
    p->execute(script);

    execProcessCount[index]++;

    switch(index)
    {
      case ScriptData::PASTCONNECT    : connect(p,    SIGNAL(sigProcessFinished()),
                                                this, SLOT(slotRefreshProcessList0()));
                                        break;

      case ScriptData::PASTDISCONNECT : connect(p,    SIGNAL(sigProcessFinished()),
                                                this, SLOT(slotRefreshProcessList1()));
                                        break;
    }
  }
}


/*
 * we have one slot for every "scripts execution time", e.g. after connecting, after disconnecting....
 * the processes are counted in the array execProcessCount, corresponging to the execution time
 ******************************************************************************************************/

void KISDN::slotRefreshProcessList0()
{
  execProcessCount[0]--;
  ::message("User process finished");

  if (execProcessCount[0] == 0)
  {
    playSound(SCRIPTS);

    if (currentInternalAccount()->connectScripts()->pastExecution())
    {
      ::message("Last process after connect finished, I will hangup now");
      beHangup();
    }
  }
}


void KISDN::slotRefreshProcessList1()
{
  execProcessCount[1]--;
  ::message("User process finished");

  if (execProcessCount[1] == 0)
  {
    playSound(SCRIPTS);
    ::message("Last process after disconnect finished.");
  }
}


/*
 * Multimedia stuff
 *******************/

void KISDN::playSound(ushort sound)
{
  CustomData  *cust = ISDNData.customData();

  switch (sound)
  {
    case CONNECT    : if (cust->audioOnConnect())    frontend->playSound(cust->waveOnlinePath(),    true);
                      else                           kapp->beep();
                      break;
    case DISCONNECT : if (cust->audioOnDisconnect()) frontend->playSound(cust->waveOfflinePath(),   true);
                      else                           kapp->beep();
                      break;
    case DIALING    : if (cust->audioOnDialing())    frontend->playSound(cust->waveDialingPath(),   true);
                      break;
    case BUSY       : if (cust->audioOnBusy())       frontend->playSound(cust->waveBusyPath(),      true);
                      break;
    case SCRIPTS    : if (cust->audioOnScripting())  frontend->playSound(cust->waveScriptingPath(), true);
                      break;
    default         : kapp->beep();
  }
}


// ----------------------------- end class KISDN --------------------------


void signalHandler(int sigId)
{
  char sigstr[30][16] = {"", "SIGHUP",    "SIGINT",    "SIGQUIT", "SIGILL",  "SIGTRAP",
                             "SIGABRT",   "SIGUNUSED", "SIGFPE",  "SIGKILL", "SIGUSR1",
                             "SIGSEGV",   "SIGUSR2",   "SIGPIPE", "SIGALRM", "SIGTERM",
                             "SIGSTKFLT", "SIGCHLD",   "SIGCONT", "SIGTSTOP",
                             "SIGTSP",    "SIGTTIN",   "SIGTTOU", "SIGIO",   "SIGXCPU",
                             "SIGXFSZ",   "SIGVTALRM", "SIGPROF", "",        "SIGWINCH" };

  fprintf(stderr, "kISDN: Caught signal %s\n", sigstr[sigId]);

  if (sigId == 1) 			// SIGHUP, hangup line
  {
    message("Hanging up line...");
    kISDNMainWidget->hangupEventually();
    setSignalHandler(signalHandler);
  }

  else 					// all other signals...
  {
    setSignalHandler(SIG_DFL);

    message("cleaning up interfaces...");
    kISDNMainWidget->shutDown(true); // on segfault, force hangup line
  }
}


void setSignalHandler(void (*handler)(int))
{
  signal(SIGSEGV, handler);
  signal(SIGTERM, handler);
  signal(SIGQUIT, handler);
  signal(SIGHUP,  handler);
  signal(SIGINT,  handler);
}


/*
 * The main program
 *******************/

int main(int argc, char **argv)
{
  checkHomeDir(); // if $HOME is manipulated, abort!
  checkKisdnrc(); // if owner of global kcmkisdnrc and local kisdnrc differ, abort!


  SplashScreen  *spscreen;

  fprintf(stdout, "kISDN "KISDNVERSION" Free Edition\n");
  fprintf(stdout, "Copyright (C) Millennium X Software\n\n");
  fprintf(stdout, "kISDN comes with absolutely NO WARRANTY\n");
  fprintf(stdout, "We will refuse any liability for any\n");
  fprintf(stdout, "damage caused directly or indirectly\n");
  fprintf(stdout, "by kISDN\n\n");

  fprintf(stderr, "kISDN: Release "KISDNVERSION"\n");

  frontend = new KDEFrontEnd();  // get some #ifdefs here, for frontends
//  MyKApplication myKApp(argc, argv, "kisdn");
    myKApp = new MyKApplication( argc, argv, "kisdn" );
//  kapp->enableSessionManagement( false );

  KConfig *kc = kapp->getConfig();
  kc->setGroup("Customization");

  if (kc->readEntry("kISDN_FirstStart", "yes") == "yes")
  {
    QString licensepath = kapp->kde_datadir() + "/kisdn/LICENSE";

    spscreen = new SplashScreen(licensepath, 10, true);
    spscreen->setCaption("kISDN "KISDNVERSION" License");

    if (!spscreen->exec())
    {
      delete frontend;
      exit(0);
    }

    kc->writeEntry("kISDN_FirstStart", "no");
    kc->sync();
    delete spscreen;
  }
  else if (kc->readEntry("ShowSplashScreen", "yes") == "yes" ||
           !kc->hasKey("ShowSplashScreen" ) )
  {
    QString  sppath = kapp->kde_datadir() + "/kisdn/pics/kisdnsplash.gif";
    spscreen = new SplashScreen(sppath, 6);
  }

  kISDNMainWidget = new KISDN("mainwidget");
//  myKApp.setMainWidget(kISDNMainWidget);
//  myKApp.setGlobalAccel(kISDNMainWidget);

  setSignalHandler(signalHandler);

  if (kapp->isRestored())
    if (KTopLevelWidget::canBeRestored(1)) kISDNMainWidget->restore(1);

  kISDNMainWidget->hide();
  kISDNMainWidget->createFrontend();

  return myKApp->exec();
}
