/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: led.h,v 1.2 1998/11/21 12:35:23 twesthei Exp $
//
// $Log: led.h,v $
// Revision 1.2  1998/11/21 12:35:23  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
 
 
#ifndef __LED_H
#define __LED_H

#include <qlabel.h>
#include <qpixmap.h>

#include <kapp.h>
#include <kiconloader.h>


enum {YELLOW, GREEN, RED};
enum {OFF, ON, BLINK};


class LED : public QLabel
{
  private:
  
    ushort       state, color;
    QPixmap      green_on, green_off, yellow_on, yellow_off, red_on, red_off;
    KIconLoader	 *loader;
  
  public:
   
    LED(ushort, uint, uint, QWidget *parent = 0, const char *name = 0);
    void set();
    void clear();
    ushort LEDstate() {return (state);}
};

#endif
