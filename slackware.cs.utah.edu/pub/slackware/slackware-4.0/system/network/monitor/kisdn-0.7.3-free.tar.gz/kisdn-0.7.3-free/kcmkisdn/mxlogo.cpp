/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: mxlogo.cpp,v 1.1.1.1 1998/11/21 10:18:57 twesthei Exp $
//
// $Log: mxlogo.cpp,v $
// Revision 1.1.1.1  1998/11/21 10:18:57  twesthei
// Imported sources
//
// Revision 1.1  1998/10/27 21:31:35  gis
// *** empty log message ***
//
// Revision 1.1  1998/10/26 15:15:08  twesthei
// *** empty log message ***
//


#include <iostream.h>

#include <qcolor.h>
#include <qimage.h>
#include <qpalette.h>
#include <qpixmap.h>

#include <kapp.h>

#include "general.h"
#include "imgxform.h"
#include "mxlogo.h"


MXLogo::MXLogo(const char *filename, QWidget *parent, const char *name) : QLabel(parent, name)
{
  QImage       img, ximg;
  QImageIO     iio;
  QPalette     palette  = this->palette();
  QColorGroup  colgrp   = palette.normal();
  QColor       widgetbg = colgrp.background();
  QString      path     = kapp->kde_datadir()+"/kisdn/pics/"+filename;
  
  iio.setFileName(path);

  if (iio.read())
  {
    img = iio.image();
    ImageTransformation  xform(img);
    
    ximg = xform.getAntiAliasedImage(widgetbg);
    _pixmap.convertFromImage(ximg, QPixmap::Color); 
    setPixmap(_pixmap);   
  }
  else cout << PROMPT << "Can't open " << iio.fileName() << endl;
   
  adjustSize();
}

