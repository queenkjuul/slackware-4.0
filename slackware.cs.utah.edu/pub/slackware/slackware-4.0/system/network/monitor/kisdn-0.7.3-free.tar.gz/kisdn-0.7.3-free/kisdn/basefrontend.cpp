/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: basefrontend.cpp,v 1.2 1998/11/21 12:34:28 twesthei Exp $
//
// $Log: basefrontend.cpp,v $
// Revision 1.2  1998/11/21 12:34:28  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//

#include <stdio.h>

#include "basefrontend.h"
#include "general.h"


void BaseFrontend::connectISP()
{
  sendSimpleCommand(BE_DIAL);
}


void BaseFrontend::disconnectISP()
{
  sendSimpleCommand(BE_HANGUP);
}


void BaseFrontend::DoDChanged(bool engage)
{
  if (engage)
  {
    ::message("Engage DoD");
    sendSimpleCommand(BE_DODON);
  }
  else
  {
    ::message("Disengage DoD");
    sendSimpleCommand(BE_DODOFF);
  }
}


void BaseFrontend::ISPListChanged()
{
  sendSimpleCommand(BE_ISPLISTCHG);
}


void BaseFrontend::engageISP(int index)
{
  fprintf(stderr, "kISDN: Engage ISP #%i\n", index);
  isdnCommand = new ISDNCommand(BE_ENGAGE);
  isdnCommand->setISP(index);
  emitCommand(isdnCommand);
  delete isdnCommand;
}


void BaseFrontend::changeISP(int index)
{
  fprintf(stderr, "kISDN: Change ISP to #%i\n", index);

  isdnCommand = new ISDNCommand(BE_ISPCHG);
  isdnCommand->setISP(index);
  emitCommand(isdnCommand);
  delete isdnCommand;
}


/*
 * Frontend interface handling
 ******************************/

void BaseFrontend::sendSimpleCommand(int cmdcode)
{
  isdnCommand = new ISDNCommand(cmdcode);
  emitCommand(isdnCommand);
  delete isdnCommand;
}


// -------- you may reimplement these methods in your subclass --------


void BaseFrontend::saveSession()
{
  printf("BaseFrontend::saveSession()\n");
}
