/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <kapp.h>

#include "general.h"


void signalHandler(int sigId)
{
  char sigstr[30][16] = {"", "SIGHUP", "SIGINT", "SIGQUIT", "SIGILL", "SIGTRAP", "SIGABRT",
  		         "SIGUNUSED", "SIGFPE", "SIGKILL", "SIGUSR1", "SIGSEGV", "SIGUSR2",
		         "SIGPIPE", "SIGALRM", "SIGTERM", "SIGSTKFLT", "SIGCHLD", "SIGCONT",
		         "SIGTSTOP", "SIGTSP", "SIGTTIN", "SIGTTOU", "SIGIO", "SIGXCPU", "SIGXFSZ",
			 "SIGVTALRM", "SIGPROF", "", "SIGWINCH"};

  fprintf(stderr, "kISDN: Caught signal %s, cleaning up interfaces...\n", sigstr[sigId]);

  setSignalHandler(SIG_DFL);
  exit(1);
}


void setSignalHandler(void (*handler)(int))
{
  signal(SIGSEGV, handler);
  signal(SIGTERM, handler);
  signal(SIGQUIT, handler);
  signal(SIGHUP,  handler);
  signal(SIGINT,  handler);
}


// sets owner of given file to effective uid and permission to u+rw go=
bool setFilePermissionUserOnly( const char *fn )
{
  struct stat buf;
  bool ok = false;

  if ( lstat( fn, &buf ) == 0 ) {
    if ( S_ISREG( buf.st_mode ) ) {
      ok  = ( chown( fn, geteuid(), (gid_t) -1 ) == 0 );
      ok &= ( chmod( fn, S_IREAD | S_IWRITE ) == 0 );
    }
  }
  if ( !ok )
    fprintf( stderr, "kcmkisdn: Warning: couldn't set correct ownership/permissions\nfor file %s", fn );

  return ok;
}


void message(const char *msg)
{
  fprintf(stderr, "kISDN: %s\n", msg);
}
