/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

#include <sys/types.h>

#include <qstring.h>
#include "process.h"


Process::Process( uid_t uid )
{
  childProcess = new MyKProcess;
  childProcess->dropRoot( uid );
  CHECK_PTR(childProcess);
  connect(childProcess, SIGNAL(processExited(KProcess *)),
                        SLOT(slotProcessDead(KProcess *)));
}

Process::~Process()
{
  delete (childProcess);
}


void Process::execute( QString cl )
{
  int argIdx;
  QString param;

  cl = cl.simplifyWhiteSpace();

  // if this is a single executable without arguments
  if ( cl.find(" ") == -1 )
    *childProcess << cl.data();

  else
  {
    while( !cl.isEmpty() )
    {
      argIdx = cl.find(" ");
      param = cl.left( argIdx );

      *childProcess << param.data();

      if (argIdx == -1)
        argIdx = cl.length();

      cl = cl.remove( 0, argIdx + 1 );
    }
  }

  if (!childProcess->start(KProcess::NotifyOnExit, KProcess::NoCommunication))
  {
    // Process not started
    debug("Process not started");
    slotProcessDead( 0L );
  }
}


void Process::slotProcessDead( KProcess * )
{
//  disconnect( childProcess, SLOT(slotProcessDead(KProcess *)) );
  emit sigProcessFinished();
  delete this;
}
