/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: mykapp.h,v 1.6 1999/01/25 23:33:25 twesthei Exp $
//
// Revision 1.5  1999/01/20 11:23:10  gis
// a security fix, kisdndb update and compilation fix (KDE 1.0)
//
// Revision 1.4  1999/01/09 23:16:45  gis
// Some changes for global accels
//
// Revision 1.3  1998/10/17 18:16:48  gis
//
// Finally, global keys, including dialog work fine!
//
// Revision 1.2  1998/10/17 17:02:44  gis
//
// Global shortcuts work perfectly now.
//
// Revision 1.1  1998/10/16 23:11:26  gis
//
// Modified Files:
// 	kisdn.h kisdn.cpp
// Added Files:
// 	mykapp.h mykapp.cpp
// Added configuration keys CTRL-ALT-C for connecting and CTRL-ALT-D for
// disconnecting.
//


#ifndef MYKAPP_H
#define MYKAPP_H

#include <kapp.h>

#ifdef HAVE_GLOBAL_SHORTCUTS
#include <kglobalaccel.h>
#endif

class MyKApplication : public KApplication
{
  private:

#ifndef HAVE_GLOBAL_SHORTCUTS
    int           globalAccel;
#else
    KGlobalAccel  *globalAccel;
#endif

    bool          x11EventFilter( XEvent * );

  public:

    MyKApplication( int &argc, char **argv, char *name ) : KApplication(argc, argv, name) 
                                                           { globalAccel = 0L; }
    ~MyKApplication() {}

#ifdef HAVE_GLOBAL_SHORTCUTS
    void  setGlobalAccel( KGlobalAccel *accel ) { globalAccel = accel; }
#endif

};

#endif
