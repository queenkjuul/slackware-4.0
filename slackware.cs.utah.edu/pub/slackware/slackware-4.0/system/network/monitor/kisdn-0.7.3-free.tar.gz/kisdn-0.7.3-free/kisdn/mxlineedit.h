#ifndef MXLINEEDIT_H
#define MXLINEEDIT_H

#include <qevent.h>
#include <qlined.h>

class MXLineEdit : public QLineEdit
{
public:

  MXLineEdit( QWidget *parent=0, const char *name=0);
  ~MXLineEdit() {}
  
  void setReadOnly( bool enable ) { readOnly = enable; }

  
protected:

  void keyPressEvent( QKeyEvent * );
  
  
private:
  bool readOnly;
};


#endif
