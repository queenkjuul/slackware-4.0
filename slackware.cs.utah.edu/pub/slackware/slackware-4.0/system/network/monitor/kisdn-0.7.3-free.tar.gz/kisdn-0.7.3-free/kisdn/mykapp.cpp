/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: mykapp.cpp,v 1.7 1999/01/25 23:33:29 twesthei Exp $
//
// Revision 1.6  1999/01/09 23:16:44  gis
// Some changes for global accels
//
// Revision 1.5  1998/10/24 22:52:29  gis
//
// Segfault hunting... lots of debug messages added and removed :-}
//
// Revision 1.4  1998/10/22 17:55:34  gis
// *** empty log message ***
//
// Revision 1.3  1998/10/17 18:16:47  gis
//
// Finally, global keys, including dialog work fine!
//
// Revision 1.2  1998/10/17 17:02:43  gis
//
// Global shortcuts work perfectly now.
//
// Revision 1.1  1998/10/16 23:11:26  gis
//
// Added configuration keys CTRL-ALT-C for connecting and CTRL-ALT-D for
// disconnecting.
//

#ifdef HAVE_CONFIG_H
  #include "../config.h"
#endif

#include "mykapp.h"


bool  MyKApplication::x11EventFilter(XEvent *e)
{
#ifdef HAVE_GLOBAL_SHORTCUTS
  if (globalAccel)
  {
    if (globalAccel->x11EventFilter(e))
      return true;
  }
#endif

  return KApplication::x11EventFilter(e);
}

