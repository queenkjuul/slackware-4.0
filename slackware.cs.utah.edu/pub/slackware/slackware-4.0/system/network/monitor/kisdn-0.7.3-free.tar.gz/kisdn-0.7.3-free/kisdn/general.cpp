/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#include <errno.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <qstring.h>

#include <kapp.h>

#include "general.h"


void message(const char *msg)
{
  fprintf(stderr, "kISDN: %s\n", msg);
}


void setFilePermissionUserOnly( const char *fn )
{
//  (void) chmod( fn, S_IREAD | S_IWRITE );
}


void checkHomeDir()
{
  struct stat statBuf;
  bool valid = false;

  const char *home = getenv( "HOME" );
  if ( home )
  {
    if ( lstat( home, &statBuf ) == 0 )
    {
      if ( S_ISDIR( statBuf.st_mode ) && statBuf.st_uid == getuid() )
      {
        valid = true;
      }
    }
  }

  if ( !valid )
  {
    message("Your HOME-variable is invalid!\nFor security reasons, I'm aborting now." );

    exit(1);
  }
}

void checkKisdnrc()
{
  struct stat global, local;
  bool valid = false;

  QString globalConfig = kapp->kde_configdir().copy() + "/kcmkisdnrc";
  QString localConfig  = kapp->localconfigdir().copy() + "/kisdnrc";

  if ( (lstat( localConfig.data(), &local )) != 0 ) {
    if ( errno == ENOENT ) {
      return; // if there is no kisdnrc, continue
    }
  }

  else { // successfull stat on local kisdnrc, now compare with global
    if ( (stat( globalConfig.data(), &global )) == 0 ) {
      if ( global.st_uid == local.st_uid || local.st_uid == 0 ) {
        valid = true; // only valid, if both kcmkisdnrc and kisdnrc are ok
      }
    }
    else {
      if ( errno == ENOENT ) { // kisdnrc exists, but global kcmkisdnrc doesn't
        message( "Your kisdn configuration file is obviously not created via kcmkisdn.\nFor security reasons, I'm aborting now" );
        exit(1);
      }
    }
  }

  if ( !valid )
  {
//    message( "Your kisdn configuration file has wrong ownership,\nfor security reasons, I'm aborting now.");
//    exit(1);
  }
}
