/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#ifndef __kaudioplayer_h
#define __kaudioplayer_h

#include <iostream.h>
#include <stdlib.h>

#include <kapp.h>
#include <qfileinf.h>
#include <qstring.h>

extern "C"
{
  #include <mediatool.h>
}

#include <kaudio.h>


class KAudioPlayer
{
  private:

    KAudio *KAServer;
  
  public:

    KAudioPlayer::KAudioPlayer();
    KAudioPlayer::~KAudioPlayer();

    void playSound(const char *, bool);
};


#endif
