/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: dodbutton.cpp,v 1.2 1998/11/21 12:34:35 twesthei Exp $
//
// $Log: dodbutton.cpp,v $
// Revision 1.2  1998/11/21 12:34:35  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include <kapp.h>
#include <kiconloader.h>

#include "dodbutton.h"


DoDButton::DoDButton(ISDNConfig *cfg, QWidget *parent, const char *name) : 
	LEDPushButton(i18n("DoD"), QColor(0x00, 0x00, 0x80), QColor(0x40, 0xc0, 0xff), false, parent, name),
	isdnconfig(cfg)
{
  setFixedSize(68, 25);
  setActive(isdnconfig->activeDoD());
  
  connect(this, SIGNAL(clicked()), SLOT(slotDoDPressed()));
}


void DoDButton::slotDisable(ushort ch) 
{
  if (!ch) setEnabled(false);
}


void DoDButton::slotEnable(ushort ch)
{
  if (!ch) setEnabled(true);
}


