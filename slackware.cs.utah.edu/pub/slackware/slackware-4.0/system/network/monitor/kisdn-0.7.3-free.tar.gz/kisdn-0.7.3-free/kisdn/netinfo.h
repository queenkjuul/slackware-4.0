/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: netinfo.h,v 1.2 1998/11/21 12:35:31 twesthei Exp $
//
// $Log: netinfo.h,v $
// Revision 1.2  1998/11/21 12:35:31  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#ifndef __NETINFO_H
#define __NETINFO_H
 
#include <sys/time.h>

#include <qstring.h>
#include <qtimer.h>

#include "isdnconfig.h"
#include "isdnctrl.h"
#include "netctrl.h"

#define INFOBUFLEN 256

#define USGMODEM   2
#define USGNET     3
#define USGVOICE   4
#define USGEXCL    64
#define USGOUT	   128


class ISDNInfo : public QObject
{
  Q_OBJECT
  
  private:
  
    struct timeval  timenow;

    QString     _iploc[2], _iprem[2];

    bool        online[2], dialing[2], sending[2], receiving[2];	// Flags & Rates
    int         conndir[2];				
    bool	gotips[2];
    ulong       oldrate[2][2];
    long        uptime[2], laststart[2];
  
    uint        kernel;	  					
    char        Phone[2][32];					
    char        callerid[2][64];
    
    ISDNConfig  *isdnconfig;
    ISDNCtrl    *isdnctrl;
    NetCtrl     *netctrl;						// Pointer to i4l backend
  
    bool getHiSaxInterface(ushort, char *);				// Info fetching methods
    bool getInterface(ushort, char *);
    void getKernelVersion();
    bool getRates(char *, ulong *);
  
  public:

    QTimer  *clock;
  
    ISDNInfo(ISDNCtrl *, NetCtrl *, ISDNConfig *);
    ~ISDNInfo() {} 
    
    bool  queryDialing(ushort ch)   const { return dialing[ch];   }
    bool  queryOnline(ushort ch)    const { return online[ch];    }
    bool  queryLastStart(ushort ch) const { return laststart[ch]; }

    ulong           queryUptime(ushort ch)    const { return uptime[ch];   }
    const QString&  queryLocalIP(ushort ch)   const { return _iploc[ch];   }
    const QString&  queryRemoteIP(ushort ch)  const { return _iprem[ch];   }
    const char      *queryCallerID(ushort ch) const { return callerid[ch]; }
    
  signals:
  
    void sigBusy(ushort);				// Outgoing call not successful
    void sigDialing(ushort);
    void sigLinkDown(ushort);
    void sigLinkUp(ushort);
    void sigNewIPLocalA(char *);
    void sigNewIPLocalB(char *);
    void sigNewIPRemoteA(char *);
    void sigNewIPRemoteB(char *);
    void sigReceiveOff(ushort);
    void sigReceiveOn(ushort);
    void sigTransmitOff(ushort);
    void sigTransmitOn(ushort);
  
  public slots:
  
    void slotCheckState();
};


#endif
