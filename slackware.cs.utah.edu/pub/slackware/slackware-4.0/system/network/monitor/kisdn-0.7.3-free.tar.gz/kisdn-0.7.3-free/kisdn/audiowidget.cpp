/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: audiowidget.cpp,v 1.3 1998/12/16 09:52:43 gis Exp $
//
// $Log: audiowidget.cpp,v $
// Revision 1.3  1998/12/16 09:52:43  gis
//
// background fix for help docs and fix for KFileDialog in audiowidget (wrong
// directory) and fixed TopWidget shown, when kisdn is restarted via SM
//
// Revision 1.2  1998/11/21 12:34:26  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include "audiowidget.h"


AudioWidget::AudioWidget(CustomData *cust, QWidget *parent, const char *name) : QWidget(parent, name),
							                        customdata(cust)
{
  KIconLoader     *loader       = kapp->getIconLoader();
  static QPixmap  sound_xpm     = loader->loadIcon("wavsound.xpm");
  static QPixmap  audioplay_xpm = loader->loadIcon("audioplay.xpm");

  audioplayer = new KAudioPlayer();

  groupbox = new QGroupBox(this);
  groupbox->setGeometry(10, 8, 328, 314);
  groupbox->setTitle(i18n("Audio configuration"));

  pmSound = new QLabel(groupbox);
  pmSound->setPixmap(sound_xpm);
  pmSound->setGeometry(292, 30, 32, 29);

  connchk = new QCheckBox(i18n("Connected"), groupbox);
  connchk->adjustSize();
  connchk->setGeometry(15, 74, connchk->width(), connchk->height());
  connchk->setChecked(false);
  connect(connchk, SIGNAL(clicked()), SLOT(slotSetEnableAudioConn()));

  connectpath = new QLineEdit(groupbox);
  connectpath->setGeometry(125, 74, 143, 24);
  connectpath->setMaxLength(PATHSIZE);
  QToolTip::add( connectpath, i18n("You can also drop files from KFM onto the list"));

  testAudioConn = new QPushButton(groupbox);
  testAudioConn->setPixmap(audioplay_xpm);
  testAudioConn->setGeometry(270, 74, 24, 24);
  connect(testAudioConn, SIGNAL(clicked()), SLOT(slotTestAudioConn()));

  browse1 = new QPushButton(i18n("..."), groupbox);
  browse1->setGeometry(297, 74, 24, 24);
  connect(browse1, SIGNAL(clicked()), SLOT(slotBrowseWavConn()));

  discchk = new QCheckBox(i18n("Disconnected"), groupbox);
  discchk->adjustSize();
  discchk->setGeometry(15, 112, discchk->width(), discchk->height());
  discchk->setChecked( false );
  connect(discchk, SIGNAL(clicked()), SLOT(slotSetEnableAudioDisc()));

  disconnectpath = new QLineEdit(groupbox);
  disconnectpath->setGeometry(125, 112, 143, 24);
  disconnectpath->setMaxLength(PATHSIZE);

  testAudioDisc = new QPushButton(groupbox);
  testAudioDisc->setPixmap(audioplay_xpm);
  testAudioDisc->setGeometry(270, 112, 24, 24);
  connect(testAudioDisc, SIGNAL(clicked()), SLOT(slotTestAudioDisc()));

  browse2 = new QPushButton(i18n("..."), groupbox);
  browse2->setGeometry(297, 112, 24, 24);
  connect(browse2, SIGNAL(clicked()), SLOT(slotBrowseWavDisc()));

  dialchk = new QCheckBox(i18n("Dialing"), groupbox);
  dialchk->adjustSize();
  dialchk->setGeometry(15, 150, dialchk->width(), dialchk->height());
  dialchk->setChecked(false);
  connect(dialchk, SIGNAL(clicked()), SLOT( slotSetEnableAudioDial()));

  dialingpath = new QLineEdit(groupbox);
  dialingpath->setGeometry(125, 150, 143, 24);
  dialingpath->setMaxLength(PATHSIZE);

  testAudioDial = new QPushButton(groupbox);
  testAudioDial->setPixmap(audioplay_xpm);
  testAudioDial->setGeometry(270, 150, 24, 24);
  connect(testAudioDial, SIGNAL(clicked()), SLOT(slotTestAudioDial()));

  browse3 = new QPushButton(i18n("..."), groupbox);
  browse3->setGeometry(297, 150, 24, 24);
  connect(browse3, SIGNAL(clicked()), SLOT(slotBrowseWavDial()));

  busychk = new QCheckBox(i18n("Busy"), groupbox);
  busychk->adjustSize();
  busychk->setGeometry(15, 188, busychk->width(), busychk->height());
  busychk->setChecked( false );
  connect(busychk, SIGNAL(clicked()), SLOT(slotSetEnableAudioBusy()));

  busypath = new QLineEdit(groupbox);
  busypath->setGeometry(125, 188, 143, 24);
  busypath->setMaxLength(PATHSIZE);

  testAudioBusy = new QPushButton(groupbox);
  testAudioBusy->setPixmap(audioplay_xpm);
  testAudioBusy->setGeometry( 270, 188, 24, 24 );
  connect(testAudioBusy, SIGNAL(clicked()), SLOT(slotTestAudioBusy()));

  browse4 = new QPushButton(i18n("..."), groupbox);
  browse4->setGeometry(297, 188, 24, 24);
  connect(browse4, SIGNAL(clicked()), SLOT(slotBrowseWavBusy()));

  ringchk = new QCheckBox(i18n("Ring"), groupbox);
  ringchk->adjustSize();
  ringchk->setGeometry(15, 226, ringchk->width(), ringchk->height());
  ringchk->setChecked( false );

  ringpath = new QLineEdit(groupbox);
  ringpath->setGeometry(125, 226, 143, 24);
  ringpath->setMaxLength(PATHSIZE);

  testAudioRing = new QPushButton(groupbox);
  testAudioRing->setPixmap(audioplay_xpm);
  testAudioRing->setGeometry( 270, 226, 24, 24 );

  browse5 = new QPushButton(i18n("..."), groupbox);
  browse5->setGeometry(297, 226, 24, 24);

  ringchk->setEnabled(false);
  ringpath->setEnabled(false);
  testAudioRing->setEnabled(false);
  browse5->setEnabled(false);

  scriptschk = new QCheckBox(i18n("Scripts finished"), groupbox);
  scriptschk->adjustSize();
  scriptschk->setGeometry(15, 264, scriptschk->width(), scriptschk->height());
  scriptschk->setChecked( false );
  connect(scriptschk, SIGNAL(clicked()), SLOT(slotSetEnableAudioScripts()));

  scriptspath = new QLineEdit(groupbox);
  scriptspath->setGeometry(125, 264, 143, 24);
  scriptspath->setMaxLength(PATHSIZE);

  testAudioScripts = new QPushButton(groupbox);
  testAudioScripts->setPixmap(audioplay_xpm);
  testAudioScripts->setGeometry( 270, 264, 24, 24 );
  connect(testAudioScripts, SIGNAL(clicked()), SLOT(slotTestAudioScripts()));

  browse6 = new QPushButton(i18n("..."), groupbox);
  browse6->setGeometry(297, 264, 24, 24);
  connect(browse6, SIGNAL(clicked()), SLOT(slotBrowseWavScripts()));

  KDNDDropZone *conndropZone = new KDNDDropZone(connectpath , DndURL);
  CHECK_PTR(conndropZone);
  connect(conndropZone, SIGNAL(dropAction(KDNDDropZone *)), this, SLOT(slotDropEvent(KDNDDropZone *)));

  KDNDDropZone *discdropZone = new KDNDDropZone(disconnectpath , DndURL);
  CHECK_PTR(discdropZone);
  connect(discdropZone, SIGNAL(dropAction(KDNDDropZone *)), this, SLOT(slotDropEvent(KDNDDropZone *)));

  KDNDDropZone *dialdropZone = new KDNDDropZone(dialingpath , DndURL);
  CHECK_PTR(dialdropZone);
  connect(dialdropZone, SIGNAL(dropAction(KDNDDropZone *)), this, SLOT(slotDropEvent(KDNDDropZone *)));

  KDNDDropZone *busydropZone = new KDNDDropZone(busypath , DndURL);
  CHECK_PTR(busydropZone);
  connect(busydropZone, SIGNAL(dropAction(KDNDDropZone *)), this, SLOT(slotDropEvent(KDNDDropZone *)));

  KDNDDropZone *ringdropZone = new KDNDDropZone(ringpath , DndURL);
  CHECK_PTR(ringdropZone);
  connect(ringdropZone, SIGNAL(dropAction(KDNDDropZone *)), this, SLOT(slotDropEvent(KDNDDropZone *)));

  KDNDDropZone *scriptsdropZone = new KDNDDropZone(scriptspath , DndURL);
  CHECK_PTR(scriptsdropZone);
  connect(scriptsdropZone, SIGNAL(dropAction(KDNDDropZone *)), this, SLOT(slotDropEvent(KDNDDropZone *)));

  refreshSettings();
  slotSetEnableAudioConn();
  slotSetEnableAudioDisc();
  slotSetEnableAudioDial();
  slotSetEnableAudioBusy();
  slotSetEnableAudioScripts();
}


AudioWidget::~AudioWidget()
{
  delete audioplayer;
}


void AudioWidget::slotSetEnableAudioConn()
{
  bool onOff = connchk->isChecked();

  connectpath->setEnabled(onOff);
  testAudioConn->setEnabled(onOff);
  browse1->setEnabled(onOff);
  customdata->setAudioOnConnect(onOff);
}


void AudioWidget::slotSetEnableAudioDisc()
{
  bool onOff = discchk->isChecked();

  disconnectpath->setEnabled(onOff);
  testAudioDisc->setEnabled(onOff);
  browse2->setEnabled(onOff);
  customdata->setAudioOnDisconnect(onOff);
}


void AudioWidget::slotSetEnableAudioDial()
{
  bool onOff = dialchk->isChecked();

  dialingpath->setEnabled(onOff);
  testAudioDial->setEnabled(onOff);
  browse3->setEnabled(onOff);
  customdata->setAudioOnDialing(onOff);
}


void AudioWidget::slotSetEnableAudioBusy()
{
  bool onOff = busychk->isChecked();

  busypath->setEnabled(onOff);
  testAudioBusy->setEnabled(onOff);
  browse4->setEnabled(onOff);
  customdata->setAudioOnBusy(onOff);
}


void AudioWidget::slotSetEnableAudioScripts()
{
  bool onOff = scriptschk->isChecked();

  scriptspath->setEnabled(onOff);
  testAudioScripts->setEnabled(onOff);
  browse6->setEnabled(onOff);
  customdata->setAudioOnScripting(onOff);
}


void AudioWidget::slotBrowseWavConn()
{
  QString  tmp = fileBrowser(i18n("Choose Sound 'Connected'"));

  if (!tmp.isNull() && !tmp.isEmpty()) connectpath->setText(tmp);
}


void AudioWidget::slotBrowseWavDisc()
{
  QString  tmp = fileBrowser(i18n("Choose Sound 'Disconnected'"));

  if (!tmp.isNull() && !tmp.isEmpty()) disconnectpath->setText(tmp);
}


void AudioWidget::slotBrowseWavDial()
{
  QString  tmp = fileBrowser(i18n("Choose Sound 'Dialing'"));

  if (!tmp.isNull() && !tmp.isEmpty()) dialingpath->setText(tmp);
}


void AudioWidget::slotBrowseWavBusy()
{
  QString  tmp = fileBrowser(i18n("Choose Sound 'Busy'"));

  if (!tmp.isNull() && !tmp.isEmpty()) busypath->setText(tmp);
}


void AudioWidget::slotBrowseWavScripts()
{
  QString  tmp = fileBrowser(i18n("Choose Sound 'Scripts finished'"));

  if (!tmp.isNull() && !tmp.isEmpty()) scriptspath->setText(tmp);
}


QString AudioWidget::fileBrowser(QString caption)
{
  KFileDialog  *Browser = new KFileDialog(kapp->kde_datadir() + "/kisdn/sounds" , "*.wav", this, "", true);
  QString      wavesel;

  Browser->setCaption(caption);

  if (Browser->exec() == QDialog::Accepted) wavesel = Browser->selectedFile();

  return wavesel;
}


void AudioWidget::refreshSettings(void)
{
  connectpath->setText(customdata->waveOnlinePath().data());
  disconnectpath->setText(customdata->waveOfflinePath().data());
  dialingpath->setText(customdata->waveDialingPath().data());
  busypath->setText(customdata->waveBusyPath().data());
  scriptspath->setText(customdata->waveScriptingPath().data());

  connchk->setChecked(customdata->audioOnConnect());
  discchk->setChecked(customdata->audioOnDisconnect());
  dialchk->setChecked(customdata->audioOnDialing() );
  busychk->setChecked(customdata->audioOnBusy());
  scriptschk->setChecked(customdata->audioOnScripting());
}


void AudioWidget::slotDropEvent( KDNDDropZone *dropZone )
{
  QStrList&  urlList = dropZone->getURLList();
  QString    filename;		
  QString    url = urlList.first();

  if (url.right(1) == "/") 	// Refuse directories
  {
    QString  tmp(i18n("You can't drop directories\n" ));

    tmp += i18n("onto the filelist!\n\n");
    QMessageBox::warning(this, i18n("kISDN Drop Error"), tmp);
    return;
  }
  else 				
  {
    if (url.left(5) == "file:")
    {
      QLineEdit  *parent = (QLineEdit *) (dropZone->getWidget());

      filename = url.right((int) url.length()-5);
      parent->setText(filename);
    }
    else
    {
      QString  tmp( i18n("You can only drop local files\n"));

      tmp += i18n("onto the filelist!\n\n");
      QMessageBox::warning(this, i18n("kISDN Drop Error"), tmp);
    }
  }

  if (urlList.count() > 1)
  {
    QString  tmp( i18n("You can't drop multiple files!\n"));

    tmp += i18n("I only took the first one.\n\n");
    QMessageBox::warning(this, i18n("kISDN Drop Error"), tmp);
  }
}


void AudioWidget::resizeEvent(QResizeEvent *)
{
  ushort  margin     = 10;
  int     w          = width();
  int     h          = height();
  int     gboxw      = w-2*margin;
  int     gboxh      = h-2*margin;
  int     playw      = 24;
  int     playdx     = 2;
  int     smbrowsew  = 24;
  int     browseh    = 24;
  int     editlinex;
  int     editlinew;
  int     editlineh  = browseh;
  int     mindy      = 4;
  int     topy       = 4*margin+pmSound->height();
  int     remheight  = h-3*margin-topy-editlineh;
  int     editlinedy = (remheight-6*editlineh)/5;
  int     maxw       = 0;
  int     tmp, playx;
  int     smbrowsex;
  int     lgbrowsew, lgbrowsex;

  groupbox->resize(gboxw, gboxh);
  pmSound->move(gboxw-pmSound->width()-margin, 2*margin);

  tmp = editlineh+editlinedy;

  connchk->move(margin,    topy+(editlineh-connchk->height())/2);
  discchk->move(margin,    topy+tmp+(editlineh-discchk->height())/2);
  dialchk->move(margin,    topy+2*tmp+(editlineh-dialchk->height())/2);
  busychk->move(margin,    topy+3*tmp+(editlineh-busychk->height())/2);
  ringchk->move(margin,    topy+4*tmp+(editlineh-ringchk->height())/2);
  scriptschk->move(margin, topy+5*tmp+(editlineh-scriptschk->height())/2);

  maxw = (connchk->width()    > maxw) ? connchk->width()    : maxw;
  maxw = (discchk->width()    > maxw) ? discchk->width()    : maxw;
  maxw = (dialchk->width()    > maxw) ? dialchk->width()    : maxw;
  maxw = (busychk->width()    > maxw) ? busychk->width()    : maxw;
  maxw = (ringchk->width()    > maxw) ? ringchk->width()    : maxw;
  maxw = (scriptschk->width() > maxw) ? scriptschk->width() : maxw;

  editlinex = maxw+3*margin;

  if (editlinedy < browseh+2*mindy)
  {
    editlinew = gboxw-editlinex-margin-playw-smbrowsew-2*playdx;
    playx     = editlinex+editlinew+playdx;
    smbrowsex = playx+playw+playdx;

    testAudioConn->move(playx,    topy);
    testAudioDisc->move(playx,    topy+tmp);
    testAudioDial->move(playx,    topy+2*tmp);
    testAudioBusy->move(playx,    topy+3*tmp);
    testAudioRing->move(playx,    topy+4*tmp);
    testAudioScripts->move(playx, topy+5*tmp);

    browse1->setText("...");
    browse2->setText("...");
    browse3->setText("...");
    browse4->setText("...");
    browse5->setText("...");
    browse6->setText("...");

    browse1->setGeometry(smbrowsex, topy,       smbrowsew, browseh);
    browse2->setGeometry(smbrowsex, topy+tmp,   smbrowsew, browseh);
    browse3->setGeometry(smbrowsex, topy+2*tmp, smbrowsew, browseh);
    browse4->setGeometry(smbrowsex, topy+3*tmp, smbrowsew, browseh);
    browse5->setGeometry(smbrowsex, topy+4*tmp, smbrowsew, browseh);
    browse6->setGeometry(smbrowsex, topy+5*tmp, smbrowsew, browseh);
  }
  else
  {
    editlinew = gboxw-editlinex-margin;

    browse1->setText(i18n("Browse..."));
    browse2->setText(i18n("Browse..."));
    browse3->setText(i18n("Browse..."));
    browse4->setText(i18n("Browse..."));
    browse5->setText(i18n("Browse..."));
    browse6->setText(i18n("Browse..."));

    browse1->adjustSize();
    lgbrowsew = browse1->width()+16;
    lgbrowsex = gboxw-margin-lgbrowsew;
    playx     = lgbrowsex-playw-playdx;

    testAudioConn->move(playx,    topy+editlineh+mindy);
    testAudioDisc->move(playx,    topy+tmp+editlineh+mindy);
    testAudioDial->move(playx,    topy+2*tmp+editlineh+mindy);
    testAudioBusy->move(playx,    topy+3*tmp+editlineh+mindy);
    testAudioRing->move(playx,    topy+4*tmp+editlineh+mindy);
    testAudioScripts->move(playx, topy+5*tmp+editlineh+mindy);

    browse1->setGeometry(lgbrowsex, topy+editlineh+mindy,       lgbrowsew, browseh);
    browse2->setGeometry(lgbrowsex, topy+tmp+editlineh+mindy,   lgbrowsew, browseh);
    browse3->setGeometry(lgbrowsex, topy+2*tmp+editlineh+mindy, lgbrowsew, browseh);
    browse4->setGeometry(lgbrowsex, topy+3*tmp+editlineh+mindy, lgbrowsew, browseh);
    browse5->setGeometry(lgbrowsex, topy+4*tmp+editlineh+mindy, lgbrowsew, browseh);
    browse6->setGeometry(lgbrowsex, topy+5*tmp+editlineh+mindy, lgbrowsew, browseh);
  }

  connectpath->setGeometry(editlinex,    topy,       editlinew, editlineh);
  disconnectpath->setGeometry(editlinex, topy+tmp,   editlinew, editlineh);
  dialingpath->setGeometry(editlinex,    topy+2*tmp, editlinew, editlineh);
  busypath->setGeometry(editlinex,       topy+3*tmp, editlinew, editlineh);
  ringpath->setGeometry(editlinex,       topy+4*tmp, editlinew, editlineh);
  scriptspath->setGeometry(editlinex,    topy+5*tmp, editlinew, editlineh);
}
