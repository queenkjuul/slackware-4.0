/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#ifndef __DB_H
#define __DB_H

#include <fstream.h>
#include <sys/types.h>
#include <stdio.h>

#include <qstring.h>
#include <qstrlist.h>
#include <qlist.h>


class ParseStream
{
  private:

    ifstream  instream;
    uint      _token;
    char      _value[256], line[256];
    char      filename[256];
    uint      lineno;

    char  *eatSpaces(char *);
    void  readLine();
    
  public:
   
    ParseStream(char *);
    ~ParseStream() {}
   
    uint  atLine()    const { return lineno; }
    uint  token()     const { return _token; };
    char  *value()          { return _value; };
    
    void  nextLine();
};
   
   
class DBEntry
{
  public:
  
    bool      valid;
    
    QString   *name, *prefix;
    QString   *domain, *netmask;
    QStrList  *phone, *dns;
  
    uint      encaps, layer2;
  
    ushort    authtype;
    bool      assigndyn;
  
    QString   *logofile;
    
    DBEntry();
    DBEntry(ParseStream&);
    ~DBEntry();
};


class ProviderChain: public QList<DBEntry>
{
  public:
   
    ProviderChain() : QList<DBEntry>() {}
    ~ProviderChain() {}
};


class City
{
  private:
  
    QString        cityname;
    
    ProviderChain  ISPList;
    
  public:
  
    City(const char *name) : cityname(name) {}
    City(ParseStream& instream);
    ~City() {}
  
    const char      *name(void)       { return cityname.data(); }
    ProviderChain&  getProviderList() { return ISPList;         }

};


class CityChain: public QList<City>
{
  public:
   
    CityChain() : QList<City>() {}
    ~CityChain() {}
};


class Country
{
  private:
  
    QString    countryname;
    QString    *flagfile;
  
    CityChain  CityList;

  public:
  
    Country(const char * name) : countryname(name), flagfile(0L),CityList() {}
    Country(ParseStream& instream);
    ~Country();
  
    void        setFlagFile(const char *); 
    const char  *name(void) 		      { return countryname.data(); }
    const char  *flag(void)                   { return flagfile->data();   }
    bool        hasFlag(void)                 { return flagfile;           }    
    CityChain&  getCityList()                 { return CityList;           }
};


class CountryChain: public QList<Country>
{
  public:
   
    CountryChain(): QList<Country>() {}
    ~CountryChain() {}
};


class DB
{
  private:
  
    CountryChain  countryList;
      
    uint  readKey(char *, char *);
    uint  readControlKey(char *, char *);
    char  *eatSpaces(char *);
    // void  countryRegisterFlag(const char *);
 
  public:
  
    DB(char *);
    ~DB() {}
    
    CountryChain& getCountryList() { return countryList; }   
};


#endif
