/*
 *  This file is part of kISDN, Copyright (C) 1998, 1999 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: netinfo.cpp,v 1.12 1999/01/23 11:38:27 twesthei Exp $
//
// $Log: netinfo.cpp,v $
// Revision 1.12  1999/01/23 11:38:27  twesthei
// Applied changes to network code to make kISDN run on
// 2.2.0pre kernels; the changes should do no harm on 2.0.36
// machines, so it's going straight into CVS
//
// Revision 1.11  1999/01/17 23:53:44  twesthei
// !"�$%
//
// Revision 1.10  1999/01/08 13:16:17  twesthei
// I won't write it a second time, for sure
//
// Revision 1.9  1998/12/16 23:39:52  twesthei
// Changed a lot of things, for example: AOC no longer displayed
// since the concept was way too bad; introduced new class ISDNLogging
// that will do the frame maintenance (at the moment obsolete itself);
// more thoroughful frmae analysis and output (layer 3 now displayed
// with same accurance as layer 2) - in this way we'll be able to
// offer real D-channel tracing for the end-user; lots of changes
// I#ve simply forgotten, sorry for that.
//
// Revision 1.8  1998/12/13 15:27:57  twesthei
// Provisorial implementation of charge display (yes, really !);
// it seems to work at the moment, but I'm afraid things are
// much more complicated than one might have thought...
//
// Revision 1.7  1998/12/12 17:18:42  twesthei
// First steps to integrate Q.931 information into kISDN's
// codebase; at the time it is able to map channels and call
// references, AOCD and AOCE are displayed for a virtual channel
// as well (if you have these services)
//
// Revision 1.6  1998/11/27 18:39:39  twesthei
// Even more improvement for Q.931 analysis (cause and
// channel identification)
//
// Revision 1.5  1998/11/21 23:17:44  twesthei
// Started implementation of D channel monitoring; there
// seems to be a memory leak within allocation of
// DataFrame's...
//
// Revision 1.4  1998/11/10 23:27:42  twesthei
// Fixed some glitches in channel bundling code; it
// should work correct now, when terminated by pressing
// the bundle button and it should not matter, if the second
// channel was already connected or not

 
#include <ctype.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include <linux/isdn.h>

#include <kapp.h>

#include "general.h"
#include "kisdndata.h"
#include "netinfo.h"


ISDNInfo::ISDNInfo(ISDNCtrl *isdn, NetCtrl *net, ISDNConfig *cfg) : isdnconfig(cfg),
								    isdnctrl(isdn),
								    netctrl(net)
{
  gettimeofday(&timenow, NULL);
  
  for (ushort ch = 0; ch < 2; ch++)
  {
    online[ch]      = false;
    dialing[ch]     = false;
    conndir[ch]    = 0;
    gotips[ch]      = false;
    sending[ch]     = false;
    receiving[ch]   = false;
    oldrate[ch][0]  = 0;
    oldrate[ch][1]  = 0;
    uptime[ch]      = 0;
    laststart[ch]   = timenow.tv_sec;
    _iploc[ch]      = "0.0.0.0";
    _iprem[ch]      = "0.0.0.0";
  }  
  
  getKernelVersion();
  
  clock = new QTimer(this);
  connect(clock, SIGNAL(timeout()), this, SLOT(slotCheckState()));
  clock->start(125, true);
}


void ISDNInfo::getKernelVersion()
{
  FILE    *fhd;
  char    buf[32], drop[16];
  uint    major, minor;
  
  kernel = 0x200;
  
  fhd = fopen("/proc/version", "r");
  
  if (fhd)
  {
    fgets(buf, 31, fhd);
    sscanf(buf, "%s %s %i.%i", drop, drop, &major, &minor);
    fclose(fhd);
    kernel = ((major << 8) | minor);
    
    switch (kernel)
    {
      case 0x0200 : ::message("Detected kernel 2.0");
      	            break;
      case 0x0201 : ::message("Detected developer kernel");
                    break;
      case 0x0202 : ::message("Detected kernel 2.2");
                    break;
      default     : ::message("Can't determine kernel version, assume 2.0");
                    kernel = 0x0200;
    }
  }
  else ::message("Can't open /proc/version in getKernelVersion, assume kernel 2.0");
}


void ISDNInfo::slotCheckState()
{
  FILE    *fhd;
  char    fl[2][8];
  int     us[2];
  ushort  ch;
  ulong   actrate[2][2];
  char    ipl[32], ipr[32];
  char    buf[INFOBUFLEN];
  bool    flags = false, phone = false, usage = false, gotiface;  
  int     flg = 0;  
  
  fhd = fopen("/dev/isdninfo", "r");
  
  if (fhd)
  {
    while (!flags || !phone || !usage)
    {
      fgets(buf, INFOBUFLEN-1, fhd);
      
      if (strstr(buf, "usage:"))
      {
        sscanf(buf, "usage: %i %i", &us[0], &us[1]);
	usage = true;
      }
      else
      {
        if (strstr(buf, "flags:"))
        {
          sscanf(buf, "flags: %s %s", fl[0], fl[1]);
	  flags = true;
        }
        else if (strstr(buf, "phone:"))
        {
          sscanf(buf, "phone: %s %s", Phone[0], Phone[1]);
	  phone = true;
        }
      }
    }
    
    fclose(fhd);
    gettimeofday(&timenow, NULL);				   

    for (ch = 0; ch < 2; ch++) 
    { 
      if (online[ch]) uptime[ch] = timenow.tv_sec-laststart[ch];
      	    
      if (strcmp(Phone[ch], "???"))		// true, if channel is dialing/connected
      {
	flg = atoi(fl[0]);			
	
	if (flg & (1 << ch))			// true, if channel is connected
	{
	  if (!online[ch])			// true, if we have to signalize 'online'
	  {	    
	    online[ch]    = true;
	    dialing[ch]   = false;    
	    uptime[ch]    = 0;
            laststart[ch] = timenow.tv_sec;
	      
	    sprintf(callerid[ch], "%s", Phone[ch]);
	    emit sigLinkUp(ch);
	  }
	}
	else if (!dialing[ch])    		// true, if we have to signalize 'dialing'
	{	    
	  conndir[ch] = us[ch] & USGOUT;
	                    
	  online[ch]  = false;
	  dialing[ch] = true;
	  emit sigDialing(ch);
	}
      }
      else 					// true, if there's no more activity on this channel
      {	
        if (dialing[ch])			// true, if we should turn off the yellow LED
        {
          dialing[ch] = false;
	  emit sigBusy(ch);
        }
	else if (online[ch])			// true, if we should turn off the green LED
	{
          emit sigLinkDown(ch);
	  online[ch] = false;
	  gettimeofday(&timenow, NULL);
	  uptime[ch] = timenow.tv_sec-laststart[ch];	    
	  
	  _iploc[ch] = "0.0.0.0";		// Reset IP info...
	  _iprem[ch] = "0.0.0.0";
	
	  gotips[ch] = false;
	
          memset(ipl, 0, sizeof(ipl));					
	  memset(ipr, 0, sizeof(ipl));
	
	  strncpy(ipl, _iploc[ch].data(), sizeof(ipl)-1);
	  strncpy(ipr, _iprem[ch].data(), sizeof(ipr)-1);
	    
	  if (ch == 0)				
	  {
	    emit sigNewIPLocalA(ipl);		// and tell the rest of the world about this		
	    emit sigNewIPRemoteA(ipr);			
	  }
	  else
	  {
	    emit sigNewIPLocalB(ipl);
	    emit sigNewIPRemoteB(ipr);
	  }
	}
      }
    }
  }
  else fprintf(stderr, "ISDNInfo::slotCheckState : Can't open /dev/isdninfo\n");
  
  /* Check transfer state and IP's for both channels. In case of channel bundling this 
   * can't be done for the second channel since its interface is not known to the kernel 
   * and thus there is no /proc/net/dev entry for the slave device (the same applies for
   * IP addresses).
   ***************************************************************************************/
   
  for (ch = 0; ch < 2; ch++)
  {
    							  
    if (online[ch])
    {
      gotiface = getInterface(ch, buf);			// First search kISDN accounts...        
       
      if (!gotiface) gotiface = getHiSaxInterface(ch, buf);	// If not found, look into /proc/net/dev 
            
      if (gotiface)
      {
        if (!gotips[ch])					// Have we already got the IP's for ch ?       
	{
          memset(ipl, 0, sizeof(ipl));			// No, so let's ask NetCtrl if it has them
	  memset(ipr, 0, sizeof(ipl));
          
	  if (netctrl->getIPAddresses(buf, ipl, ipr))
	  {
	    if (strcmp("1.1.1.1", ipl) && strcmp("1.1.1.1", ipr))
	    {
	      gotips[ch] = true;				// It has them !
	    
	      _iploc[ch] = ipl;					// Save them for later queries
	      _iprem[ch] = ipr;
	    
	      if (ch == 0)
	      {
	        emit sigNewIPLocalA(ipl);			// So let's tell this to all
	        emit sigNewIPRemoteA(ipr);			// who want to know :-)
	      }
	      else
	      {
	        emit sigNewIPLocalB(ipl);
	        emit sigNewIPRemoteB(ipr);
	      }
	    }
	  }
	}
	
        if (getRates(buf, actrate[ch]))
        {
          if (actrate[ch][0] > oldrate[ch][0])
	  {
	    if (!sending[ch])
	    {
	      sending[ch] = true;
	      emit sigTransmitOn(ch);
	    }
	  }
	  else       
	  {
	    if (sending[ch])
	    {
              sending[ch] = false;
	      emit sigTransmitOff(ch);
	    }
	  }
	  
	  oldrate[ch][0] = actrate[ch][0];
	  
	  if (actrate[ch][1] > oldrate[ch][1])
	  {
	    if (!receiving[ch])
	    {
	      receiving[ch]  = true;
	      emit sigReceiveOn(ch);
	    }
	  }
	  else 
	  {
	    if (receiving[ch])
	    {
              receiving[ch] = false;
	      emit sigReceiveOff(ch);
	    }
	  }
	  
	  oldrate[ch][1] = actrate[ch][1];
	} 
	else fprintf(stderr, "Warning: Interface for /dev/%s not found in /proc/net/dev\n", buf);
      } 
      else fprintf(stderr, "Warning: No interface for channel %i found\n", ch);
    }
  }
  clock->start(125, true);  
}  
	
	
bool ISDNInfo::getRates(char *iface, ulong *rate)
{
  FILE  *fhd;
  bool  found = false;
  char  buf[256], token[32];
  ulong d;
  
  fhd = fopen("/proc/net/dev", "r");
  
  if (fhd)
  {
    do
    {
      fgets(buf, 255, fhd);
      if (strstr(buf, iface))
      {
        found = true;
	switch (kernel)
	{
	  case 0x0200 : sscanf(buf, "%s%li%li%li%li%li%li", 
	                       token, &rate[0], &d, &d, &d, &d, &rate[1]);
	  	  	break;
          case 0x0201 :
 	  case 0x0202 : sscanf(buf, "%s%li%li%li%li%li%li%li%li%li%li", 
	                       token, &d, &rate[0], &d, &d, &d, &d, &d, &d, &d, &rate[1]);
			break;
	  default     : fprintf(stderr, "kISDN: Unknown kernel revision number (%i.%i) in getRates\n",
	  				(kernel >> 8) && 0xFF, kernel && 0xFF);
	}
      }
    } while (!feof(fhd) && !found);
    fclose(fhd);
  }
  else fprintf(stderr, "ISDNInfo::getRates : Can't open /proc/net/dev\n");
  return found;
}


/* The following methods try to map a channel to an interface, i.e for a given
 * channel they return (on success) the interface that's using this channel.
 * The first stage method reads the phone number to which the channel is connected
 * and compares it to the phone numbers encountered in the accounts. If matching,
 * the interface, we're looking for, is the interface that was built for this
 * account. 
 * The second stage method uses a similar scheme, but it looks up the phone
 * numbers that are defined within the kernel interfaces; the advantage is that
 * this method will even work for external defined interfaces.   
 * WARNING: Both methods may fail if multiple accounts have the same phone number !    
 * Fritz once told me, he would add a line to /dev/isdninfo containing the corresponding
 * interfaces; as far as I know, this isn't even done in the 2.1.x kernels, so
 * we may expect the same problems in Linux 2.2 ...
 ****************************************************************************************/


bool ISDNInfo::getInterface(ushort ch, char *iface)
{
  /* First stage search method for mapping a channel to an interface */
  
  AccountData  *acc;
  Device       *device;
  ::Phone      *phone;
  bool         found = false;
  
  for (acc = ISDNData.firstAccount(); (acc != 0L) && !found; acc = ISDNData.nextAccount())
  {
    device = acc->masterDevice();
    
    for (phone = device->firstPhone(); (phone != 0L) && !found; phone = device->nextPhone())
    {      
      if (!strcmp(Phone[ch], phone->number().data()))
      {
        found = true;
	
	if (device->protEncaps() == Device::SYNCPPP) strcpy(iface, isdnconfig->PPPDev);
	else                                         strcpy(iface, isdnconfig->RawDev);
      }
    }
  }
  
  return found;
}


bool ISDNInfo::getHiSaxInterface(ushort ch, char *iface)
{
  /* Second stage search method for mapping a channel to an interface */
  
  FILE  *fhd;
  char  buf[256], ifname[16], *p;
  bool  found = false;
  
  fhd = fopen("/proc/net/dev", "r");
  
  if (!fhd) fprintf(stderr, "kISDN: Can't open /proc/net/dev\n");
  else
  {
    union phonenums  phones;
      
    while (!feof(fhd) && !found)
    {
      fgets(buf, 255, fhd);
	
      if ((p = strchr(buf, ':')))
      {
        *p = '\0';
	sscanf(buf, "%s", ifname);          
	strcpy(phones.phone.name, ifname);
        phones.phone.outgoing = 1; 
        
	isdnctrl->getPhoneNumbers(&phones);
	
	found = (bool) (strstr(phones.n, Phone[ch]));	    
      }
    }
      
    if (found) strcpy(iface, ifname);
      
    fclose(fhd);
  }
  
  return found;
}
