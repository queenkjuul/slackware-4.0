/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: avmb1ctrl.h,v 1.2 1998/11/21 12:35:05 twesthei Exp $
//
// $Log: avmb1ctrl.h,v $
// Revision 1.2  1998/11/21 12:35:05  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#ifndef __AVMB1CTRL_H
#define __AVMB1CTRL_H

#include <sys/types.h>


class AVMB1Ctrl
{
  private:
  
    bool  available;
    int   validports[8];
    int   validirqs[16];
  
    bool devExists(const char *);
    bool makeNode(const char *, uint, uint);
  
  public:
  
    AVMB1Ctrl();
  
    bool makeDevices();
    bool addCard(const char *, ushort);
    bool loadFirmware(const char *, uint);
    bool resetCard(uint);
    bool haveCAPI(void) { return (available); }
};


#endif

