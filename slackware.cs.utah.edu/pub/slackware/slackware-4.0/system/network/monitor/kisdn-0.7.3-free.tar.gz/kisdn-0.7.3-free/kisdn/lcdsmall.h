/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: lcdsmall.h,v 1.2 1998/11/21 12:35:21 twesthei Exp $
//
// $Log: lcdsmall.h,v $
// Revision 1.2  1998/11/21 12:35:21  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __LCDSMALL_H
#define __LCDSMALL_H

#include <qcolor.h>
#include <qpixmap.h>


class SmallLCDNumber : public QPixmap
{
  private:
  
    QColor  _bgcol, _dkcol, _lgcol;
    char    _letter;

    void  drawLetter();
    void  drawSegments(bool, bool, bool, bool, bool, bool, bool);
    
  public:
  
    SmallLCDNumber(const QColor&, const QColor&, const QColor&, char l = '0');
    ~SmallLCDNumber() {}
    
    void  setLetter(char);
    void  setBackGround(const QColor& bg)  { _bgcol  = bg; drawLetter(); }
    void  setDarkColor(const QColor& dk)   { _dkcol  = dk; drawLetter(); }
    void  setLightColor(const QColor& lg)  { _lgcol  = lg; drawLetter(); }
    
    char  letter() const { return _letter; }
};


#endif
