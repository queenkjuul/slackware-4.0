/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include "accdlg.h"


AuthWidget::AuthWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  QSize    size;
  int      wd, hg;
  AccData  *acc = ISDNData.Temp;
  
  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 316);
  GBox->setTitle(i18n("Authentication"));
  
  AuthGroup = new QButtonGroup(this);
  AuthGroup->setLineWidth(0);
  AuthVBox = new QVBoxLayout(AuthGroup, 10);
  AuthGroup->move(84, 60);

  NoneButton = new QRadioButton(AuthGroup);
  NoneButton->setText(i18n("None"));
  NoneButton->setChecked(!acc->UsePAP && !acc->UseCHAP);
  AuthVBox->addWidget(NoneButton);
  NoneButton->setMinimumSize(NoneButton->sizeHint());
  QToolTip::add(NoneButton, i18n("No authentication at all"));
  
  PAPButton = new QRadioButton(AuthGroup);
  PAPButton->setText(i18n("PAP Authentication"));
  PAPButton->setChecked((ISDNData.Temp)->UsePAP);
  AuthVBox->addWidget(PAPButton);
  PAPButton->setMinimumSize(PAPButton->sizeHint());
  QToolTip::add( PAPButton, i18n("Normal authentication"));
  
  CHAPButton = new QRadioButton(AuthGroup);
  CHAPButton->setText(i18n("CHAP Authentication"));
  CHAPButton->setChecked((ISDNData.Temp)->UseCHAP);
  AuthVBox->addWidget(CHAPButton);
  CHAPButton->setMinimumSize(CHAPButton->sizeHint());
  QToolTip::add(CHAPButton, i18n("Encrypted authentication"));
    
  AuthVBox->activate();

  connect(AuthGroup, SIGNAL(clicked(int)), SLOT(slotAuthChanged(int))); 

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap keys_xpm = loader->loadIcon("keys.xpm");

  pmKey = new QLabel(this);
  pmKey->setPixmap(keys_xpm);
  pmKey->setGeometry(289, 32, 32, 32);

  Userlabel = new QLabel(i18n("User Name:"), this);
  size = Userlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Userlabel->setGeometry(140-wd, 180+(24-hg)/2, wd, hg);
  
  User = new QLineEdit(this);
  User->setGeometry(150, 180, 100, 24);
  User->setMaxLength(NAMESIZE);
  User->setText((ISDNData.Temp)->username.data());

  Passwordlabel = new QLabel(i18n("Password:"), this);
  size = Passwordlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Passwordlabel->setGeometry(140-wd, 212+(24-hg)/2, wd, hg);
  
  Password = new QLineEdit(this);
  Password->setGeometry(150, 212, 100, 24);
  Password->setMaxLength(NAMESIZE);
  Password->setText((ISDNData.Temp)->password.data());
  Password->setEchoMode(QLineEdit::Password);

  setPhrasesEnabled(acc->UsePAP || acc->UseCHAP);
}    


void AuthWidget::slotAuthChanged(int type)
{
  AccData *acc = ISDNData.Temp;
  
  acc->UsePAP  = (type == 1);
  acc->UseCHAP = (type == 2);
  acc->UseNONE = (type == 0);
  
  setPhrasesEnabled(acc->UsePAP || acc->UseCHAP);
}


void AuthWidget::setPhrasesEnabled(bool state)
{
  Userlabel->setEnabled(state);
  User->setEnabled(state);
  Passwordlabel->setEnabled(state);
  Password->setEnabled(state);
}


void AuthWidget::resizeEvent(QResizeEvent *)
{
  ushort margin = 10;
  uint   w      = width();
  uint   h      = height();

  GBox->resize(w-2*margin, h-2*margin);
  pmKey->move(w-2*margin-pmKey->width()-4, pmKey->y());
} 
