/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: aboutwidget.cpp,v 1.2 1998/11/21 12:34:23 twesthei Exp $
//
// $Log: aboutwidget.cpp,v $
// Revision 1.2  1998/11/21 12:34:23  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <iostream.h>

#include <qbitmap.h>
#include <qcolor.h>

#include <kapp.h>

#include "aboutwidget.h"
#include "general.h"
#include "minsize.h"
#include "mxmsgbox.h"
#include "splashscreen.h"
#include "version.h"


AboutWidget::AboutWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  QColor    white = QColor(0xff, 0xff, 0xff);	// QColor::QColor(white) gave me brown last time...
  QColor    grey  = QColor(0xc0, 0xc0, 0xc0);
  QImageIO  iio;
  QImage    img;
  QPixmap   pm;
  QString   path = kapp->kde_datadir()+"/kisdn/pics/";
  QFont     linkfont;

  Frame = new QFrame(this);
  Frame->setBackgroundColor(white);
  Frame->setFrameStyle(QFrame::Panel | QFrame::Sunken);
  Frame->setLineWidth(2);

  Logo = new QLabel(Frame);

  iio.setFileName(path+"kisdnlogo.gif");

  if (iio.read())
  {
    img = iio.image();
    pm.convertFromImage(img, QPixmap::Color);
    Logo->setPixmap(pm);
    Logo->adjustSize();
  }
  else cout << PROMPT << "Can't open " << iio.fileName() << endl;

  Tux = new QLabel(Frame);

  iio.setFileName(path+"kisdntux.gif");

  if (iio.read())
  {
    img = iio.image();
    pm.convertFromImage(img, QPixmap::Color);
    Tux->setPixmap(pm);
    Tux->adjustSize();
  }
  else cout << PROMPT << "Can't open " << iio.fileName() << endl;

  Tux->setBackgroundColor(white);

  Version = new QLabel("Release "KISDNVERSION, Frame);
  Version->setFont(QFont("helvetica", 12, QFont::Bold));
  Version->adjustSize();
  Version->setBackgroundColor(white);

  Copy = new QLabel("Copyright (C) 1998", Frame);
  Copy->adjustSize();
  Copy->setBackgroundColor(white);

  MillenniumX = new QLabel("Millennium X Software", Frame);
  MillenniumX->adjustSize();
  MillenniumX->setBackgroundColor(white);

  Homepage = new KURLWidget("http://kisdn.headlight.de", Frame);

  linkfont.setUnderline(true);

  Homepage->setFont(linkfont);
  Homepage->adjustSize();
  Homepage->setBackgroundColor(white);

  License = new QPushButton(i18n("License"), Frame);
  License->adjustSize();
  License->setPalette(QPalette(grey));
  connect(License, SIGNAL(clicked()), this, SLOT(showLicense()));

  setMinimumSize(MINSIZEX, MINSIZEY);
  resize(MINSIZEX, MINSIZEY);
}


void  AboutWidget::showLicense()
{
  QString       licensepath = kapp->kde_datadir()+"/kisdn/LICENSE";
  SplashScreen  *ss         = new SplashScreen(licensepath, 0, false);

  ss->setCaption("kISDN "KISDNVERSION" License");
  ss->exec();

  delete ss;
}


QSize  AboutWidget::minimumSize()
{
  return  QSize(MINSIZEX, MINSIZEY);
}


void  AboutWidget::resizeEvent(QResizeEvent *)
{
  int  margin   = 10;
  int  w        = width();
  int  h        = height();
  int  framew   = w-2*margin;
  int  frameh   = h-2*margin;
  int  logoy    = 20;
  int  versiony = logoy+Logo->height()+20;
  int  copyy    = versiony+Version->height()+10;
  int  mlxy     = copyy+Copy->height()+4;
  int  licy     = frameh-margin-License->height();
  int  regy     = licy-4-License->height();
  int  urly     = regy-4-Homepage->height();
  int  tuxx     = framew-margin-Tux->width();
  int  tuxy     = frameh-margin-Tux->height();
  int  butplusw = 8;
  int  butw;

  Frame->setGeometry(margin, margin, framew, frameh);

  Logo->move((framew-Logo->width())/2,               logoy);
  Version->move((framew-Version->width())/2,         versiony);
  Copy->move((framew-Copy->width())/2,               copyy);
  MillenniumX->move((framew-MillenniumX->width())/2, mlxy);

  Tux->move(tuxx, tuxy);

  urly = regy + 6;
  Homepage->move(margin, urly);

  License->adjustSize();

  butw = License->width();
  butw = (butw > 80) ? butw+butplusw : 96;

  License->setGeometry(margin,  licy, butw, License->height());
}
