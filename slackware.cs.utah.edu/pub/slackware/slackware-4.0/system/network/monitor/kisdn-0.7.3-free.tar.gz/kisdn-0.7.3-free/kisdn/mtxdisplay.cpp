/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: mtxdisplay.cpp,v 1.2 1998/11/21 12:34:52 twesthei Exp $
//
// $Log: mtxdisplay.cpp,v $
// Revision 1.2  1998/11/21 12:34:52  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <kapp.h>
#include <kiconloader.h>

#include "mtxdisplay.h"


MatrixFont::MatrixFont(const char *rp, int w, int h) : _width(w), _height(h)
{
  QString      rpath   = rp;
  KIconLoader  *loader = kapp->getIconLoader();
  
  mtxspace  = loader->loadIcon(rpath+"/mtxspace.xpm");
  mtxperiod = loader->loadIcon(rpath+"/mtxperiod.xpm");
  mtxcomma  = loader->loadIcon(rpath+"/mtxcomma.xpm");
  mtxlpar   = loader->loadIcon(rpath+"/mtxlpar.xpm");
  mtxrpar   = loader->loadIcon(rpath+"/mtxrpar.xpm");
  mtxss     = loader->loadIcon(rpath+"/mtxss.xpm");
  mtx0      = loader->loadIcon(rpath+"/mtx0.xpm");
  mtx1      = loader->loadIcon(rpath+"/mtx1.xpm");
  mtx2      = loader->loadIcon(rpath+"/mtx2.xpm");
  mtx3      = loader->loadIcon(rpath+"/mtx3.xpm");
  mtx4      = loader->loadIcon(rpath+"/mtx4.xpm");
  mtx5      = loader->loadIcon(rpath+"/mtx5.xpm");
  mtx6      = loader->loadIcon(rpath+"/mtx6.xpm");
  mtx7      = loader->loadIcon(rpath+"/mtx7.xpm");
  mtx8      = loader->loadIcon(rpath+"/mtx8.xpm");
  mtx9      = loader->loadIcon(rpath+"/mtx9.xpm");

  mtxA      = loader->loadIcon(rpath+"/mtxA.xpm");
  mtxB      = loader->loadIcon(rpath+"/mtxB.xpm");
  mtxC      = loader->loadIcon(rpath+"/mtxC.xpm");
  mtxD      = loader->loadIcon(rpath+"/mtxD.xpm");
  mtxE      = loader->loadIcon(rpath+"/mtxE.xpm");
  mtxF      = loader->loadIcon(rpath+"/mtxF.xpm");
  mtxG      = loader->loadIcon(rpath+"/mtxG.xpm");
  mtxH      = loader->loadIcon(rpath+"/mtxH.xpm");
  mtxI      = loader->loadIcon(rpath+"/mtxI.xpm");
  mtxJ      = loader->loadIcon(rpath+"/mtxJ.xpm");
  mtxK      = loader->loadIcon(rpath+"/mtxK.xpm");
  mtxL      = loader->loadIcon(rpath+"/mtxL.xpm");
  mtxM      = loader->loadIcon(rpath+"/mtxM.xpm");
  mtxN      = loader->loadIcon(rpath+"/mtxN.xpm");
  mtxO      = loader->loadIcon(rpath+"/mtxO.xpm");
  mtxP      = loader->loadIcon(rpath+"/mtxP.xpm");
  mtxQ      = loader->loadIcon(rpath+"/mtxQ.xpm");
  mtxR      = loader->loadIcon(rpath+"/mtxR.xpm");
  mtxS      = loader->loadIcon(rpath+"/mtxS.xpm");
  mtxT      = loader->loadIcon(rpath+"/mtxT.xpm");
  mtxU      = loader->loadIcon(rpath+"/mtxU.xpm");
  mtxV      = loader->loadIcon(rpath+"/mtxV.xpm");
  mtxW      = loader->loadIcon(rpath+"/mtxW.xpm");
  mtxX      = loader->loadIcon(rpath+"/mtxX.xpm");
  mtxY      = loader->loadIcon(rpath+"/mtxY.xpm");
  mtxZ      = loader->loadIcon(rpath+"/mtxZ.xpm");
  mtxAE     = loader->loadIcon(rpath+"/mtxAE.xpm");
  mtxOE     = loader->loadIcon(rpath+"/mtxOE.xpm");
  mtxUE     = loader->loadIcon(rpath+"/mtxUE.xpm");

  mtxa      = loader->loadIcon(rpath+"/mtxa.xpm");
  mtxb      = loader->loadIcon(rpath+"/mtxb.xpm");
  mtxc      = loader->loadIcon(rpath+"/mtxc.xpm");
  mtxd      = loader->loadIcon(rpath+"/mtxd.xpm");
  mtxe      = loader->loadIcon(rpath+"/mtxe.xpm");
  mtxf      = loader->loadIcon(rpath+"/mtxf.xpm");
  mtxg      = loader->loadIcon(rpath+"/mtxg.xpm");
  mtxh      = loader->loadIcon(rpath+"/mtxh.xpm");
  mtxi      = loader->loadIcon(rpath+"/mtxi.xpm");
  mtxj      = loader->loadIcon(rpath+"/mtxj.xpm");
  mtxk      = loader->loadIcon(rpath+"/mtxk.xpm");
  mtxl      = loader->loadIcon(rpath+"/mtxl.xpm");
  mtxm      = loader->loadIcon(rpath+"/mtxm.xpm");
  mtxn      = loader->loadIcon(rpath+"/mtxn.xpm");
  mtxo      = loader->loadIcon(rpath+"/mtxo.xpm");
  mtxp      = loader->loadIcon(rpath+"/mtxp.xpm");
  mtxq      = loader->loadIcon(rpath+"/mtxq.xpm");
  mtxr      = loader->loadIcon(rpath+"/mtxr.xpm");
  mtxs      = loader->loadIcon(rpath+"/mtxs.xpm");
  mtxt      = loader->loadIcon(rpath+"/mtxt.xpm");
  mtxu      = loader->loadIcon(rpath+"/mtxu.xpm");
  mtxv      = loader->loadIcon(rpath+"/mtxv.xpm");
  mtxw      = loader->loadIcon(rpath+"/mtxw.xpm");
  mtxx      = loader->loadIcon(rpath+"/mtxx.xpm");
  mtxy      = loader->loadIcon(rpath+"/mtxy.xpm");
  mtxz      = loader->loadIcon(rpath+"/mtxz.xpm");
  mtxae     = loader->loadIcon(rpath+"/mtxae.xpm");
  mtxoe     = loader->loadIcon(rpath+"/mtxoe.xpm");
  mtxue     = loader->loadIcon(rpath+"/mtxue.xpm");
}


const QPixmap *MatrixFont::letter(char c)
{
  switch (c)
  {
    case '.' : return &mtxperiod;
    case ',' : return &mtxcomma;
    case '(' : return &mtxlpar;
    case ')' : return &mtxrpar;
    case '�' : return &mtxss;
    
    case '0' : return &mtx0;
    case '1' : return &mtx1;
    case '2' : return &mtx2;
    case '3' : return &mtx3;
    case '4' : return &mtx4;
    case '5' : return &mtx5;
    case '6' : return &mtx6;
    case '7' : return &mtx7;
    case '8' : return &mtx8;
    case '9' : return &mtx9;
    
    case 'A' : return &mtxA;
    case 'B' : return &mtxB;
    case 'C' : return &mtxC;
    case 'D' : return &mtxD;
    case 'E' : return &mtxE;
    case 'F' : return &mtxF;
    case 'G' : return &mtxG;
    case 'H' : return &mtxH;
    case 'I' : return &mtxI;
    case 'J' : return &mtxJ;
    case 'K' : return &mtxK;
    case 'L' : return &mtxL;
    case 'M' : return &mtxM;
    case 'N' : return &mtxN;
    case 'O' : return &mtxO;
    case 'P' : return &mtxP;
    case 'Q' : return &mtxQ;
    case 'R' : return &mtxR;
    case 'S' : return &mtxS;
    case 'T' : return &mtxT;
    case 'U' : return &mtxU;
    case 'V' : return &mtxV;
    case 'W' : return &mtxW;
    case 'X' : return &mtxX;
    case 'Y' : return &mtxY;
    case 'Z' : return &mtxZ;
    case '�' : return &mtxAE;
    case '�' : return &mtxOE;
    case '�' : return &mtxUE;
        
    case 'a' : return &mtxa;
    case 'b' : return &mtxb;
    case 'c' : return &mtxc;
    case 'd' : return &mtxd;
    case 'e' : return &mtxe;
    case 'f' : return &mtxf;
    case 'g' : return &mtxg;
    case 'h' : return &mtxh;
    case 'i' : return &mtxi;
    case 'j' : return &mtxj;
    case 'k' : return &mtxk;
    case 'l' : return &mtxl;
    case 'm' : return &mtxm;
    case 'n' : return &mtxn;
    case 'o' : return &mtxo;
    case 'p' : return &mtxp;
    case 'q' : return &mtxq;
    case 'r' : return &mtxr;
    case 's' : return &mtxs;
    case 't' : return &mtxt;
    case 'u' : return &mtxu;
    case 'v' : return &mtxv;
    case 'w' : return &mtxw;
    case 'x' : return &mtxx;
    case 'y' : return &mtxy;
    case 'z' : return &mtxz;
    case '�' : return &mtxae;
    case '�' : return &mtxoe;
    case '�' : return &mtxue;
    
    default  : return &mtxspace; 
  }
}


MatrixPixmap::MatrixPixmap(MatrixFont *f, const char *s) : font(f)
{
  fill(QColor::QColor(black));		
  setText(s);
}


void MatrixPixmap::setText(const char *s)
{
  _text = s;
  
  int  l   = _text.length();
  int  w   = font->width();
  int  h   = font->height();
  
  resize(l*(w+1)-1, font->height());
  fill(QColor::QColor(black));		// The well-known 'scramble fix'
  
  for (int i = 0; i < l; i++) bitBlt(this, i*(w+1), 0, font->letter(s[i]), 0, 0, w, h, CopyROP);
}



