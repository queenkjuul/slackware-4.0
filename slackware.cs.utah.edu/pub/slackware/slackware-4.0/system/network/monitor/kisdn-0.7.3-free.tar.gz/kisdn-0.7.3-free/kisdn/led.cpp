/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: led.cpp,v 1.2 1998/11/21 12:34:47 twesthei Exp $
//
// $Log: led.cpp,v $
// Revision 1.2  1998/11/21 12:34:47  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include <stdio.h>

#include "led.h"


LED::LED(ushort Color, uint xpos, uint ypos, QWidget *parent, const char *name):QLabel(parent, name)
{
  KIconLoader *loader = kapp->getIconLoader();

  yellow_on  = loader->loadIcon("LED_yellow_on.xpm");
  yellow_off = loader->loadIcon("LED_yellow_off.xpm");
  green_on   = loader->loadIcon("LED_green_on.xpm");
  green_off  = loader->loadIcon("LED_green_off.xpm");
  red_on     = loader->loadIcon("LED_red_on.xpm");
  red_off    = loader->loadIcon("LED_red_off.xpm");

  state  = OFF;
  switch (color = Color)
  {
    case YELLOW : setPixmap( yellow_off );
    	 	  break;
    case GREEN  : setPixmap( green_off );
    		  break;
    case RED    : setPixmap( red_off );
    		  break;
    default     : fprintf(stderr, "Bad color value for LED.\n");
  }   
  setGeometry(xpos, ypos, 16, 16);
}


void LED::set(void)
{
  if (state != ON)
  {
    state = ON;
    switch (color)
    {
      case YELLOW : setPixmap(yellow_on);
    	 	    break;
      case GREEN  : setPixmap(green_on);
    		    break;
      case RED    : setPixmap(red_on);
    		    break;
      default     : fprintf(stderr, "LED::set has bad color.\n");
    }
  }
}


void LED::clear(void)
{
  if (state != OFF)
  {
    state = OFF;
    switch (color)
    {
      case YELLOW : setPixmap(yellow_off);
    	 	    break;
      case GREEN  : setPixmap(green_off);
    		    break;
      case RED    : setPixmap(red_off);
    		    break;
      default     : fprintf(stderr, "LED::set has bad color.\n");
    }
  }
}
