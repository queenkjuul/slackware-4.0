/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: graphwidget.cpp,v 1.2 1998/11/21 12:34:38 twesthei Exp $
//
// $Log: graphwidget.cpp,v $
// Revision 1.2  1998/11/21 12:34:38  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <stdio.h>
#include <sys/time.h>

#include <kapp.h>
#include <kiconloader.h>

#include "graphwidget.h"
#include "kisdndata.h"


RateStamp::RateStamp()
{
  background = new QPixmap(STAMPDX, STAMPDY);
  foreground = new QPixmap(STAMPDX, STAMPDY);

  x = 0;
  y = 0;

  used = false;
}


RateStamp::~RateStamp()
{
  delete background;
  delete foreground;
}


GraphWidget::GraphWidget(bool _periodicChecking, bool _showRateStamps, bool _showGrid, ISDNInfo *info,
                         QWidget *parent, const char *name) : QLabel(parent, name)
{
  setMaximumWidth(MAXHISTORY);
  setAutoResize(false);

  periodicChecking = _periodicChecking;
  showRateStamps   = _showRateStamps;
  showGrid         = _showGrid;

  ScannerData  *scandata = ISDNData.scannerData();
  uint         i;
  float        dist, temp;	

  ScanDX = width();
  ScanDY = height();

  isdninfo = info;

  QPixmap *Temp = new QPixmap(ScanDX+30, ScanDY);
  Temp->fill(QColor::QColor(black));

  Shrink = 2;

  ScaleDist  = 25; // (uint) scandata->ScaleDist;		
  dist       = ScaleDist*Shrink;  		
  ScaleColor = scandata->scaleColor();
  policy     = 1;

  QPainter p;
  
  p.begin(Temp);
  temp = dist;
  p.setPen(ScaleColor);

  while (temp < ScanDY-20)
  {
    p.drawLine(0, (int) (ScanDY-11-temp), ScanDX-1, (int) (ScanDY-11-temp));
    temp += dist;
  }

  p.end();

  this->setPixmap(*Temp);
  delete Temp;

  for (ushort c = 0; c < 2; c++)
  {
    OldInRate[c]  = 0;
    ActInRate[c]  = 0;
    OldOutRate[c] = 0;
    ActOutRate[c] = 0;
    
    for (i = 0; i < MAXHISTORY; i++)
    {
      History[c][TYPEREC][i] = 0;
      History[c][TYPETRA][i] = 0;
      History[c][TYPETOT][i] = 0;
    }
  }
  
  setColors();

  KIconLoader  *loader = kapp->getIconLoader();

  DigitPoint    = new QPixmap(loader->loadIcon("point.xpm"));
  ClockSep      = new QPixmap(loader->loadIcon("sep.xpm"));
  ClockDigit[0] = new QPixmap(loader->loadIcon("dig0.xpm"));
  ClockDigit[1] = new QPixmap(loader->loadIcon("dig1.xpm"));
  ClockDigit[2] = new QPixmap(loader->loadIcon("dig2.xpm"));
  ClockDigit[3] = new QPixmap(loader->loadIcon("dig3.xpm"));
  ClockDigit[4] = new QPixmap(loader->loadIcon("dig4.xpm"));
  ClockDigit[5] = new QPixmap(loader->loadIcon("dig5.xpm"));
  ClockDigit[6] = new QPixmap(loader->loadIcon("dig6.xpm"));
  ClockDigit[7] = new QPixmap(loader->loadIcon("dig7.xpm"));
  ClockDigit[8] = new QPixmap(loader->loadIcon("dig8.xpm"));
  ClockDigit[9] = new QPixmap(loader->loadIcon("dig9.xpm"));

  EvDial = new QPixmap(loader->loadIcon("dialstart.xpm"));
  EvCall = new QPixmap(loader->loadIcon("inccall.xpm"));
  EvUp   = new QPixmap(loader->loadIcon("linkup.xpm"));
  EvDown = new QPixmap(loader->loadIcon("linkdown.xpm"));

  IndexRate = 2; 	// Print time index every 2 minutes
  Indexed   = false;	// There's no time mark yet
  drawnow   = 1;

  for (i = 0; i < NUMSTAMPS; i++) Stamp[i] = new RateStamp();
  slotFullRedraw();

  if (periodicChecking)
  {
    clock2 = new QTimer(this);
    connect(clock2, SIGNAL(timeout()), this, SLOT(slotCheckSizing()));
    clock2->start(500, true);
  }
}


GraphWidget::~GraphWidget()
{
  ushort i;

  delete DigitPoint;
  delete ClockSep;

  for (i = 0; i < 10; i++) delete ClockDigit[i];

  delete EvDial;
  delete EvUp;
  delete EvDown;

  for (i = 0; i < NUMSTAMPS; i++) delete Stamp[i];
}


void GraphWidget::drawStamps(QPixmap *screen, uint offset)
{
  if ( ScanDX <= 0 || ScanDY <= 0 ) return;

  float   dist = ScaleDist*Shrink, temp;	
  ushort  index = 0, dig0, dig1, dig2;
  uint    scale = ScaleDist;

  for (ushort i = 0; i < NUMSTAMPS; i++) Stamp[i]->used = false;

  temp = dist;

  while (temp < ScanDY-20)
  {
    Stamp[index]->used = true;

    Stamp[index]->x = STAMPX;
    Stamp[index]->y = (uint) (ScanDY-21-temp-STAMPDY/2);

    (Stamp[index]->foreground)->fill(QColor::QColor(0, 0, 128));

    bitBlt(Stamp[index]->background, 0, 0, screen, Stamp[index]->x,
                                                   Stamp[index]->y+offset,
                                                   STAMPDX, STAMPDY);

    dig0 = (scale/100) %10;
    dig1 = (scale/10) %10;						
    dig2 = scale%10;
    					
    if (dig0) bitBlt(Stamp[index]->foreground, 2, 2, ClockDigit[dig0], 0, 0, 5, 7, OrROP);
    else      bitBlt(Stamp[index]->foreground, 0, 0, Stamp[index]->background, 0, 0, 5, 11);

    bitBlt(Stamp[index]->foreground, 7, 2, ClockDigit[dig1], 0, 0, 5, 7, OrROP);
    bitBlt(Stamp[index]->foreground, 12, 2, DigitPoint, 0, 0, 5, 7, OrROP);
    bitBlt(Stamp[index]->foreground, 17, 2, ClockDigit[dig2], 0, 0, 5, 7, OrROP);
    bitBlt(screen, Stamp[index]->x, Stamp[index]->y+offset,
                   Stamp[index]->foreground, 0, 0, STAMPDX, STAMPDY);

    index++;

    temp  += dist;
    scale += (uint) (ScaleDist);
  }
}


void GraphWidget::undrawStamps(QPixmap *screen, uint offset)
{
  if ( ScanDX <= 0 || ScanDY <= 0 ) return;

  for (ushort i = 0; i < NUMSTAMPS; i++)
  {
    if (Stamp[i]->used)
      bitBlt(screen, Stamp[i]->x, Stamp[i]->y+offset, Stamp[i]->background, 0, 0, STAMPDX, STAMPDY);
  }
}


void GraphWidget::slotFullRedraw()
{
  if ( ScanDX <= 0 || ScanDY <= 0 ) return;

  ushort  ch, type;

  QPixmap *Temp = new QPixmap(ScanDX, ScanDY-20);
  Temp->fill(QColor::QColor(black));

  QPainter p;
  
  p.begin(Temp);
  drawScales(&p, 0);

  for (ch = 0; ch < 2; ch++)
  {
    if ((showChA && (ch == 0) || (showChB && (ch == 1)))) 			
    {
      for(type = 0; type < 3; type++)
      {
        switch (type)
      	{
      	  case TYPEREC : if (showRec) drawGraph(&p, ch, type);
                         break;
          case TYPETRA : if (showTra) drawGraph(&p, ch, type);
                         break;
      	  case TYPETOT : if (showTot) drawGraph(&p, ch, type);
      	}	
      }
    }
  }

  p.end();

  if (showRateStamps) drawStamps(Temp, 0);

  bitBlt(this->pixmap(), 0, 10, Temp);
  this->repaint(0, 10, ScanDX, ScanDY-20, false);

  delete Temp;
}


void GraphWidget::slotCheckSizing()
{
  ScannerData  *scandata = ISDNData.scannerData();
  bool         resized = false;

  if (scandata->scalingPolicy() == ScannerData::DYNAMIC)			
  {
    float   sh, sh1, sh2;
    ushort  ch;

    if (policy != scandata->scalingPolicy())		// User decided recently to resize automagically
    {
      ScaleDist = 25;
      Shrink    = 2;
      resized   = true;
    }

    for (ch = 0; ch < 2; ch++)				// Check if we have to zoom in
    {
      if (((sh = needShrink(ch)) < Shrink) &&
         (((ch == 0) && showChA) ||
          ((ch == 1) &&  showChB)))
      {
        Shrink  = sh;
        resized = true;
      }
    }

    if (!resized)					// Check if we have to zoom out
    {
      sh1 = needGrow(0);
      sh2 = needGrow(1);
      sh  = (sh1 > sh2) ? sh2 : sh1;

      if (sh > Shrink)
      {
        Shrink  = sh;
        resized = true;
      }
    }
  }
  else							// Check for scale changes (static display)
  {
    if (ScaleDist != scandata->scaleDistance() || ScaleRange != scandata->scaleRange())
    {
      ScaleDist  = (int) scandata->scaleDistance();
      ScaleRange = scandata->scaleRange();
      Shrink     = 100.0/ScaleRange;
      resized    = true; 	
    }
  }
  
  policy = scandata->scalingPolicy();
  
  if (resized) slotFullRedraw();
  
  clock2->start(500, true);
}


void GraphWidget::setColors()
{
  ScannerData  *scandata = ISDNData.scannerData();

  for (ushort c = 0; c < 2; c++)
  {
    GraphColor[c][TYPEREC] = scandata->graphColor(c, TYPEREC);
    GraphColor[c][TYPETRA] = scandata->graphColor(c, TYPETRA);
    GraphColor[c][TYPETOT] = scandata->graphColor(c, TYPETOT);
  }
  
  ScaleColor = scandata->scaleColor();
}


void GraphWidget::drawGraph(QPainter *p, ushort ch, ushort type)
{
  if ((ScanDX <= 0) || (ScanDY <= 0)) return;

  uint col;

  p->setPen(GraphColor[ch][type]);

  for (col = 1; col < ScanDX; col++)
    p->drawLine(col, (int) (ScanDY-21-History[ch][type][col-1]*10*Shrink),
                col, (int) (ScanDY-21-History[ch][type][col]*10*Shrink));
}


void GraphWidget::drawScales(QPainter *p, ushort offset)
{
  if ((ScanDX <= 0) || (ScanDY <= 0)) return;

  ScannerData  *scandata = ISDNData.scannerData();
  float        dist      = ScaleDist*Shrink, temp;	
  uint         x;

  temp = dist;
  p->setPen(ScaleColor);

  while (temp < ScanDY-20)
  {
    if (!scandata->dottedLines())
      p->drawLine(0, (int) (ScanDY-21+offset-temp), ScanDX-1, (int) (ScanDY-21+offset-temp));
    else
    {
      for (x = 0; x < ScanDX; x += 2)
        p->drawPoint(x+1-drawnow, (int)(ScanDY-21+offset-temp));
    }
    
    temp += dist;
  }
}


void GraphWidget::drawScanLine(QPainter *p, ushort ch, ushort type, float oldRate, float actRate)
{
  if ((ScanDX <= 0) || (ScanDY <= 0)) return;

  int ys = int (ScanDY-11-oldRate*10*Shrink);
  int ye = int (ScanDY-11-actRate*10*Shrink);

  ys = (ys < 20)              ? 20        : ys;
  ys = (ys > (int) ScanDY-10) ? ScanDY-10 : ys;

  ye = (ye < 20)              ? 20 	  : ye;
  ye = (ye > (int) ScanDY-10) ? ScanDY-10 : ye;

  p->setPen(GraphColor[ch][type]);
  p->drawLine(ScanDX-1, ys, ScanDX-1, ye);
}


void GraphWidget::slotDrawScanLine(PPPInfo *pppinfo)
{
  if ((ScanDX <= 0) || (ScanDY <= 0)) return;

  ScannerData  *scandata = ISDNData.scannerData();
  float        OldTotRate, ActTotRate;
  float        dist = ScaleDist*Shrink, temp;	

  if (showRateStamps) undrawStamps(this->pixmap(), 10);

  shiftHistory();

  QPixmap Temp(ScanDX+30, ScanDY);
  Temp.fill(QColor::QColor(black)); // Fix try for scrambled screen
  bitBlt(&Temp, 0, 0, this->pixmap(), 1, 0, ScanDX+29, ScanDY, CopyROP);

  QPainter p;
  
  p.begin(&Temp);

  temp = dist;
  p.setPen(ScaleColor);

  while (temp < ScanDY-20)
  {
    if (!scandata->dottedLines() || drawnow)
      p.drawPoint(ScanDX-1, (int) (ScanDY-11-temp));
    temp += dist;
  }
  
  drawnow = 1-drawnow;

  for (ushort c = 0; c < 2; c++)
  {
    OldInRate[c]  = ActInRate[c];
    ActInRate[c]  = pppinfo->inRate[c];
    OldOutRate[c] = ActOutRate[c];
    ActOutRate[c] = pppinfo->outRate[c];

    OldTotRate = OldInRate[c]+OldOutRate[c];
    ActTotRate = ActInRate[c]+ActOutRate[c];

    History[c][0][ScanDX-1] = ActInRate[c];
    History[c][1][ScanDX-1] = ActOutRate[c];
    History[c][2][ScanDX-1] = ActTotRate;

    if ((showChA && (c == 0) || (showChB && (c == 1)))) 			
    {
      if (showRec) drawScanLine(&p, c, 0, OldInRate[c], ActInRate[c]);
      if (showTra) drawScanLine(&p, c, 1, OldOutRate[c], ActOutRate[c]);
      if (showTot) drawScanLine(&p, c, 2, OldTotRate, ActTotRate);
    }
  }
  p.end();

  printTimeIndex(&Temp, pppinfo->timeHours, pppinfo->timeMins);

  if ( showRateStamps )
    drawStamps(&Temp, 10);

  (this->pixmap())->fill(QColor::QColor(black)); // Fix try for scrambled screen
  bitBlt(this->pixmap(), 0, 0, &Temp);
  this->repaint(0, 0, ScanDX, ScanDY, false);
}


float GraphWidget::needShrink(ushort ch)
{
  float  tolgrow = ScanDY*0.8;
  float  sh = Shrink;
  float  in = ActInRate[ch]*10, out = ActOutRate[ch]*10, tot = in+out;

  while (((in*sh > tolgrow) || (out*sh > tolgrow) || (tot*sh > tolgrow)) && (sh > 0.5)) sh *= 0.75;

  return (sh);
}


float GraphWidget::needGrow(ushort ch)
{
  float  tolgrow = ScanDY*0.4;
  float  sh = Shrink;
  uint   i;
  bool   mustgrow = true;

  while (mustgrow && (sh < 2))
  {
    for (i = 0; (i < ScanDX) && mustgrow; i++)
      mustgrow = !((History[ch][0][i]*10*sh > tolgrow) || (History[ch][1][i]*10*sh > tolgrow)
  	  	   || (History[ch][2][i]*10*sh > tolgrow));
    if (mustgrow) sh *= (float) 4/3;
  }
  return (sh);
}


void GraphWidget::printTimeIndex(QPixmap *pm, ushort hours, ushort mins)
{
  if ((ScanDX <= 0) || (ScanDY <= 0)) return;

  if ((mins % IndexRate == 0) && !Indexed)
  {
    bitBlt(pm, ScanDX-15, 1, ClockDigit[hours/10], 0, 0, 5, 7);		
    bitBlt(pm, ScanDX-9,  1, ClockDigit[hours%10], 0, 0, 5, 7);			
    bitBlt(pm, ScanDX-4,  1, ClockSep,             0, 0, 5, 7);
    bitBlt(pm, ScanDX,    1, ClockDigit[mins/10],  0, 0, 5, 7);
    bitBlt(pm, ScanDX+6,  1, ClockDigit[mins%10],  0, 0, 5, 7);
    Indexed = true;
  }
  else if (mins % IndexRate != 0) Indexed = false;
}


void GraphWidget::shiftHistory()
{
  ushort ch, type;
  uint   col;

  for (ch = 0; ch < 2; ch++)
    for (type = 0; type < 3; type++)
      for (col = 1; col < ScanDX; col++) History[ch][type][col-1] = History[ch][type][col];
}


void GraphWidget::setBlackBackground()
{
  QPixmap *Temp = new QPixmap(ScanDX+30, ScanDY);

  Temp->fill(QColor::QColor(black));
  this->setPixmap(*Temp);
  delete Temp;
}


void GraphWidget::printEvent(QPixmap *evpm)
{
  if ((ScanDX <= 0) || (ScanDY <= 0)) return;

  QPixmap Temp(ScanDX+30, 10);

  bitBlt(&Temp, 0, 0, this->pixmap(), 0, ScanDY-10, ScanDX+30, 10, CopyROP);
  bitBlt(&Temp, ScanDX-4, 2, evpm, 0, 0, 7, 4, CopyROP);
  bitBlt(this->pixmap(), 0, ScanDY-10, &Temp);

  this->repaint(0, ScanDY-10, ScanDX, 10, false);
}


void GraphWidget::resizeEvent(QResizeEvent *)
{
  ScanDX = this->width()-30;
  ScanDY = this->height();

  setBlackBackground();
  slotFullRedraw();
  repaint(false);
}

