/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: aboutwidget.h,v 1.1.1.1 1998/11/21 10:18:58 twesthei Exp $
//
// $Log: aboutwidget.h,v $
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
//
// Revision 1.5  1998/10/26 20:41:01  twesthei
// Improved 'About' dialog, including geometry management
//
// Revision 1.4  1998/10/26 16:48:45  twesthei
// Changed behavior and appearance of message boxes
// (registration failed/succeeded)
//
// Revision 1.3  1998/10/23 21:43:27  twesthei
// Changed the logo (hopefully all now) and implemented the
// registration class
//
// Revision 1.2  1998/10/22 22:17:53  twesthei
// Registration can now be reached from here...
//


#ifndef ABOUTWIDGET_H
#define ABOUTWIDGET_H

#include <qevent.h>
#include <qframe.h>
#include <qimage.h>
#include <qlabel.h>
#include <qpixmap.h>
#include <qpushbt.h>
#include <qsize.h>
#include <qwidget.h>

#include "kurlwidget.h"


class AboutWidget : public QWidget
{
  Q_OBJECT
  
  private:

    QFrame       *Frame;
    QLabel       *Logo, *Tux, *Version, *MillenniumX, *Copy;
    QPushButton  *License;
    KURLWidget   *Homepage;

    void  resizeEvent(QResizeEvent *);

  private slots:

    void  showLicense();
     
  public:

    AboutWidget(QWidget *parent = 0, const char *name = 0);
    ~AboutWidget() {}

    QSize  minimumSize();
};


#endif
