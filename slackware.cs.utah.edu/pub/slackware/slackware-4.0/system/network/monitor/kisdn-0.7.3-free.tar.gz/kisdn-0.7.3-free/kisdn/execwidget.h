/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: execwidget.h,v 1.2 1998/11/21 12:35:12 twesthei Exp $
//
// $Log: execwidget.h,v $
// Revision 1.2  1998/11/21 12:35:12  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
 
 
#ifndef __EXECWIDGET_H
#define __EXECWIDGET_H

#include <kapp.h>
#include <kiconloader.h>

#include <qbttngrp.h>
#include <qchkbox.h>
#include <qevent.h>
#include <qgrpbox.h>
#include <qlabel.h>
#include <qlined.h>
#include <qlistbox.h>
#include <qmsgbox.h>
#include <qpushbt.h>
#include <qtooltip.h>

#include "kisdndata.h"
#include "logo.h"

class ExecWidget : public QWidget
{
  Q_OBJECT

  private:
  
    QCheckBox     *execCheck, *discCheck;
    QGroupBox     *groupbox;
    QLabel        *pmExec, *execLabel, *execListLabel;
    QLineEdit     *execEdit;
    QPushButton   *addButton, *editButton, *remButton;
    bool          secondCheckBox;
    ScriptData    *sdata;

    void refreshListBox();

  private slots:

    void slotAddCommandLine();
    void slotEditCommandLine();
    void slotRemoveCommandLine();
    void slotDropEvent(KDNDDropZone *);
    void slotEnableExecution();
    void slotExecDisconnect();
    void resizeEvent(QResizeEvent *);
    
  public:

    ExecWidget(QString firstChBox, QString secondChBox, ScriptData *_sdata,
               QWidget *parent = 0, const char *name = 0 );
    ~ExecWidget() {}

    QListBox  *execList;
};

#endif
