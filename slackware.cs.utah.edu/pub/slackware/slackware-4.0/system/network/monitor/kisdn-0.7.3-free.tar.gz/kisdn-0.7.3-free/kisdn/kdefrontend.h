/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: kdefrontend.h,v 1.2 1998/11/21 12:35:18 twesthei Exp $
//
// $Log: kdefrontend.h,v $
// Revision 1.2  1998/11/21 12:35:18  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//


#ifndef __KDEFRONTEND_H
#define __KDEFRONTEND_H


#include <qmsgbox.h>
#include <qpixmap.h>
#include <qstring.h>
#include <qwidget.h>

#include <kapp.h>
#include <kmsgbox.h>

#include "kaudioplayer.h"
#include "kiconloader.h"
#include "kisdndata.h"


class KDEFrontEnd : public QObject
{
  Q_OBJECT


  private:

    KAudioPlayer  *ap;                                  // playing sound


  public:

    KDEFrontEnd();
    ~KDEFrontEnd() {};

    void  messageCAPILoadingFailed(QWidget *);           // Error message boxes
    void  messageCantOpenProc(QWidget *);
    void  messageCantOpenProcModules(QWidget *);
    void  messageCantSetPermissions(QWidget *, const QString);
    void  messageLoadingHiSaxFailed(QWidget *);
    int   messageNoISDNSupport(QWidget *);
    void  messageNokISDNAccounts(QWidget *);
    void  messageNoPreConfDevices(QWidget *);
    int   messageQuitHangup(QWidget *);
    void  messageScriptBufferingFailed(QWidget *);
    void  messageScriptRestoringFailed(QWidget *);
    void  messageAccountHasChanged(QWidget *, QString);

    void  messageNotImplementedYet();
    void  messageISDNUnsupported();
    void  messageInvalidKey();

    void  playSound(QString, bool);

  public slots:

    void  slotInvokeHelp();
};

#endif
