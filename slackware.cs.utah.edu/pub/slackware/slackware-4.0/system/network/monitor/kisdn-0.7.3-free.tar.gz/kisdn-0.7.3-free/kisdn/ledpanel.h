/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: ledpanel.h,v 1.2 1998/11/21 12:35:25 twesthei Exp $
//
// $Log: ledpanel.h,v $
// Revision 1.2  1998/11/21 12:35:25  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __LEDPANEL_H
#define __LEDPANEL_H

#include <stdio.h>

#include <qlabel.h>

#include "led.h"


class LEDPanel : public QWidget
{
  Q_OBJECT

  private:

    QLabel  *Label1, *Label2, *Label3, *Label4, *Label5, *Label6;
    LED     *Led[2][4];

    void setLEDState(ushort, ushort, ushort);
    void ToggleLED(ushort, ushort);

  public:

    LEDPanel(QWidget *parent = 0, const char *name = 0);

  public slots:

    void slotCallEvent(ushort ch)	 { setLEDState(ch, 0, 1); setLEDState(ch, 1, 0); }
    void slotHangupEvent(ushort ch)	 { setLEDState(ch, 0, 0); }
    void slotDialEvent(ushort ch)        { setLEDState(ch, 0, 1); setLEDState(ch, 1, 0); }
    void slotBusyEvent(ushort ch)        { setLEDState(ch, 0, 0); }
    void slotLinkUpEvent(ushort ch)      { setLEDState(ch, 0, 0); setLEDState(ch, 1, 1); }
    void slotLinkDownEvent(ushort ch)    { setLEDState(ch, 1, 0); setLEDState(ch, 2, 0); setLEDState(ch, 3, 0); }
    void slotTransmitOnEvent(ushort ch)  { setLEDState(ch, 3, 1); }
    void slotTransmitOffEvent(ushort ch) { setLEDState(ch, 3, 0); }
    void slotReceiveOnEvent(ushort ch)   { setLEDState(ch, 2, 1); }
    void slotReceiveOffEvent(ushort ch)  { setLEDState(ch, 2, 0); }
};

#endif
