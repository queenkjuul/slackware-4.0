/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#ifndef __ADAPTER_H
#define __ADAPTER_H

#include <qstring.h>

#define MAXADP 50


class Adapter
{
  private:
  
    uint  numadp, newindex[MAXADP];
  
    void addType(uint, const char *, const char *, const char *, bool, bool, bool, bool, ushort);
  
  public:

    uint     Index[MAXADP];
    QString  Name[MAXADP], Id[MAXADP], HLDriver[MAXADP];
    bool     NeedMem[MAXADP], NeedIO1[MAXADP], NeedIO2[MAXADP], NeedIRQ[MAXADP];
    ushort   Type[MAXADP];
  
    Adapter();
    ~Adapter() {}
    
    uint NumAdp(void)            { return numadp; }
    uint NewIndex(uint oldindex) { return newindex[oldindex]; }
};

#endif

