/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#ifndef __GENERAL_H
#define __GENERAL_H

#include <iostream.h>

#define PROMPT  "kcmkisdn: "


void message(const char *);
void signalHandler(int);
bool setFilePermissionUserOnly(const char *);
void setSignalHandler(void (*handler)(int));

#endif
