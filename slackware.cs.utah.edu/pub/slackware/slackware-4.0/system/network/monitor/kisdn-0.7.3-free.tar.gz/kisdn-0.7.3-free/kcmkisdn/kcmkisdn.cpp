/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#include <kmsgbox.h>

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "general.h"
#include "kcmkisdn.h"
#include "kisdndata.h"
#include "version.h"


KISDNConfigApplication::KISDNConfigApplication(int &argc, char **argv, const char *name) :
                                               kISDNConfigApplication(argc, argv, name)
{
  settingsApplied = false;
  //  connect(confdialog, SIGNAL(cancelButtonPressed()), this, SLOT(cancel()));

  pages      = getPageList();

  Account    = 0;
  General    = 0;
  Driver     = 0;
  About      = 0;

  if (runGUI())
  {
    ISDNData.Load();
    ISDNData.Backup();

    if (!pages || pages->contains("account"))
      addPage(Account = new AccountWidget(confdialog, "account"), i18n("&Account"), "account.html");

    if (!pages || pages->contains("general"))
      addPage(General = new GeneralWidget(confdialog, "general"), i18n("&General"), "config.html#allgemein");

    if (!pages || pages->contains("driver"))
      addPage(Driver  = new DriverWidget(confdialog, "driver"), i18n("&Driver"), "config.html#driver");

    if (!pages || pages->contains("about"))
      addPage(About = new AboutWidget(confdialog, "about"), i18n("A&bout"), "kcmkisdn.html");

    setTitle( i18n("kISDN Configuration") );
    confdialog->show();
  }
}


KISDNConfigApplication::~KISDNConfigApplication()
{

}


void KISDNConfigApplication::cancel()
{
  if (settingsApplied)
  {
    ISDNData.Restore();
    apply();
  }
}


void KISDNConfigApplication::init()
{
}


void KISDNConfigApplication::apply()
{
  GenData        *gen = ISDNData.General;

  while ((!Driver->isValidIOAddr(0) || 	// the user actually changed module parameters or not...
          !Driver->isValidIOAddr(1) ||
          !Driver->isValidInterrupt() ||
      	  !Driver->isValidMembase()
         ) && Driver->Modulechk->isChecked())
  {
    messageBadSysValues();
    confdialog->show();
  }

  gen->ipppdpath    = (General->ipppdpath)->text();
  gen->prefix       = (General->prefix)->text();
  gen->msnData      = (General->msnData)->text();
  gen->explicitEnable = (General->checkExplicit)->isChecked();
  gen->disableIpUpDown = (General->checkIpUp)->isChecked();
  gen->modprobepath = (Driver->Modprobe)->text();
  gen->iobase0      = (Driver->Ioaddr0)->text();
  gen->iobase1      = (Driver->Ioaddr1)->text();
  gen->interrupt    = atoi((Driver->Interrupt)->text());
  gen->membase      = (Driver->Membase)->text();


  ISDNData.Save();
  ISDNData.SaveUsers();

  settingsApplied = true;
}


// To be called when setup data of current ISP may be changed
// Notify all running kisdns with SIGHUP or sth like that
void KISDNConfigApplication::reconfigureISP()
{
/*
  if (ISPIndex >= numext && ISDNData.NumAcc) 	
  {	
    fprintf(stdout, "kISDN: Change setup for current provider\n");
    clearISP();						
    setISP();
    emit sigInterfaceChanged(Device);
  ServerCombo->setCurrentItem(ISPIndex);
  }
*/
}


void KISDNConfigApplication::messageBadSysValues()
{
  QString tmp;

  tmp  = i18n("I/O Address must be within 0x0000\n");
  tmp += i18n("and 0xFFFF, Interrupt must be a value\n");
  tmp += i18n("between 0 and 15.\n");
  tmp += i18n("Warning: Incorrect input can hang your\n");
  tmp += i18n("system!\n\n");

  KMsgBox::message(0, i18n( "Missing privileges"), tmp, 1);
}


/* ******************* (end of KISDNConfigApplication) ******************* */


bool canWriteConfig()
{
  QString    fn = kapp->kde_configdir() + "/kcmkisdnrc";
  QFileInfo  fi( fn.data() );

  if ( !fi.exists() )
  {
    // use KConfig to create the KDE filesystem structure ..kde/share/config
    // and create the kcmkisdnrc for us.
    KConfig *kc = new KConfig( fn );
    kc->sync();
    delete kc;

  }

  // force file permission to u+rw go=, and set owner to getuid()
  return ( ::setFilePermissionUserOnly( fn ) );
}


int main( int argc, char **argv )
{
  fprintf(stdout, "kISDN "KISDNVERSION" Copyright (C) Millennium X Software\n\n");
  fprintf(stdout, "kISDN comes with absolutely NO WARRANTY\n");
  fprintf(stdout, "We will will refuse any liability for any\n");
  fprintf(stdout, "damage caused directly or indirectly\n");
  fprintf(stdout, "by kISDN\n\n");

  KISDNConfigApplication app( argc, argv, "kcmkisdn" );

  //  app.setCaption(i18n("kISDN Configuration"));

  if ( app.runGUI() )
  {
    if ( canWriteConfig() )
    {
       return app.exec();
    }

    else      				// no permission to setup kisdn
    {
      QString msg = i18n("Sorry, you don't have read/write\n"
                         "permission to the kISDN setup file.");
      KMsgBox::message(0, i18n("Missing privileges"), msg);
    }
  }
  else // started with -init
  {
    app.init();
    return 0;
  }
}
