#ifndef KISDNCOMPAT_H
#define KISDNCOMPAT_H

#include <kconfig.h>

class KisdnCompat
{
public:

  KisdnCompat();
  ~KisdnCompat() {}
  
  static bool ensureCompatibility( KConfig *kc );
};



#endif
