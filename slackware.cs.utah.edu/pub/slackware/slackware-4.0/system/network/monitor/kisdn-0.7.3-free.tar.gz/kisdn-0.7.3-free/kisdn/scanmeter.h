/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: scanmeter.h,v 1.2 1998/11/21 12:35:35 twesthei Exp $
//
// $Log: scanmeter.h,v $
// Revision 1.2  1998/11/21 12:35:35  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __SCANMETER_H
#define __SCANMETER_H

#include <stdio.h>

#include <qbuttongroup.h>
#include <qcolor.h>
#include <qframe.h>
#include <qlabel.h>
#include <qpainter.h>
#include <qpixmap.h>
#include <qpushbt.h>
#include <qtimer.h>

#include "graphwidget.h"
#include "ledbutton.h"
#include "mtxdisplay.h"
#include "netinfo.h"
#include "pppstatus.h"
#include "throughput.h"

#define TYPEREC  0		// Some of these should move into the class, I think
#define TYPETRA  1
#define TYPETOT  2

#define SCANDX   376
#define SCANDY   120

#define STAMPX     10
#define STAMPDX    24
#define STAMPDY    11


class ScanMeter : public QWidget
{
  Q_OBJECT

  private:

    QButtonGroup  *scanbutgrp;
    QFrame        *EtchedFrame;
    QLabel        *UpTimeLabel;
    QPixmap       *ClockSep, *ClockDigit[10], *DigitPoint, *EvDial, *EvUp, *EvDown, *LegBack;
    QPixmap       *rcvon, *rcvoff, *traon, *traoff, *toton, *totoff;
    QPixmap       *chaon, *chaoff, *chbon, *chboff, *stmon, *stmoff;
    QTimer        *clock1;

    GraphWidget   *Screen;
    ThroughPut    *throughput;
    
    ISDNInfo      *isdninfo;
    MatrixFont    *mtxfont;
    float         OldInRate[2], ActInRate[2], OldOutRate[2], ActOutRate[2];
    float         History[2][3][SCANDX];
    float         Shrink;
    ushort        IndexRate, drawnow;
    bool          Indexed;

    void  drawGraph(QPainter *, ushort, ushort);
    void  drawScanLine(QPainter *, ushort, ushort, float, float);
    void  shiftHistory();
    void  printTimeIndex(QPixmap *, ushort, ushort);
    void  printEvent(QPixmap *);
    void  showThroughPut(float);
    void  drawScales(QPainter *, ushort);
    float needShrink(ushort);
    float needGrow(ushort);
    void  drawStamps(QPixmap *, uint);
    void  undrawStamps(QPixmap *, uint);
    void  resizeEvent( QResizeEvent * );
    void  updateFlags();

  private slots:

    void slotEventCall(ushort);
    void slotEventDial(ushort);
    void slotEventLinkUp(ushort);
    void slotEventLinkDown(ushort);
    void slotKeyPressed(int);
    void slotShowUptime();

  public:

    QColor         GraphColor[2][3], ScaleColor;
    LEDPushButton  *glowrcv, *glowtra, *glowtot, *glowcha, *glowchb, *glowstm; // Public ? Why ???
    bool           configChanged;
      
    ScanMeter(bool, ISDNInfo *, MatrixFont *, QWidget *parent = 0, const char *name = 0);
    ~ScanMeter();

  public slots:

    void settingsChanged();
    void slotDrawScanLine(PPPInfo *);
    
  signals:
  
    void sigRefreshUptimes();
};

#endif
