/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: ledbutton.cpp,v 1.2 1998/11/21 12:34:48 twesthei Exp $
//
// $Log: ledbutton.cpp,v $
// Revision 1.2  1998/11/21 12:34:48  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <iostream.h>

#include <qimage.h>
#include <qpalette.h>
#include <qpixmap.h>

#include "ledbutton.h"


void  LEDPushButton::drawButtonLabel(QPainter *painter)
{
  const QPixmap  *xpm  = pixmap();
  QPalette       pal   = palette();
  QColorGroup    cgrp  = pal.active();
  int            butw  = width(), buth = height();
  int            ledsz = _fixed ? 12 : (butw/5 < (buth-3)/2 ? butw/5 : (buth-3)/2) ;
  int            offs  = (isDown() ? 1 : 0);
  int            ledx  = butw-ledsz-4+offs, ledy = buth-ledsz-4+offs;
  
  painter->setPen(cgrp.dark());
  painter->drawLine(ledx+1, ledy+ledsz-2, ledx+ledsz-2, ledy+1);
  
  painter->setPen(cgrp.light());
  painter->drawLine(ledx, ledy+ledsz-1, ledx+ledsz-1, ledy+ledsz-1);
  painter->drawLine(ledx+ledsz-1, ledy, ledx+ledsz-1, ledy+ledsz-2);

  painter->setPen(_active ? _light : _dark);
  
  for (int i = 2; i < ledsz-1; i++) 
    painter->drawLine(ledx+i, ledy+ledsz-2, ledx+i, ledy+ledsz-i);

  if (isEnabled())
  {
    if (xpm != 0L)			// Draw pixmap instead of text
    {
      int  xpm_w = xpm->width();
      int  xpm_h = xpm->height();
      int  xpm_x = offs+2+(butw-4-xpm_w)/2+_xshift;
      int  xpm_y = offs+2+(buth-4-xpm_h)/2+_yshift;

      bitBlt(painter->device(), xpm_x, xpm_y, xpm, 0, 0, xpm_w, xpm_h, CopyROP);
    }
    else
    {
      painter->setPen(cgrp.text());
      painter->drawText(offs+2, offs+2, butw-ledsz-4, buth-4, AlignCenter, text());
    }
  }
  else
  {
    if (xpm != 0L)			// Draw pixmap instead of text
    {
      QImage  image     = xpm->convertToImage();
      QSize   imagesize = image.size();
      QRgb    rgb;
      int     x, y;
      int     w         = imagesize.width();
      int     h         = imagesize.height();
      int     xpm_w     = xpm->width();
      int     xpm_h     = xpm->height();
      int     xpm_x     = offs+2+(butw-4-xpm_w)/2+_xshift;
      int     xpm_y     = offs+2+(buth-4-xpm_h)/2+_yshift;
   
      for (y = 0; y < h; y++)
      {
        for (x = 0; x < w; x++)
        {
	  {
	    rgb = image.pixel(x, y);	
	
	    if (!(qRed(rgb) & qGreen(rgb) & qBlue(rgb))) 
	    { 
	      painter->setPen(cgrp.light());
	      painter->drawPoint(xpm_x+x+1, xpm_y+y+1);
	    }
       	  }
        }
      }
      
      for (y = 0; y < h; y++)
      {
        for (x = 0; x < w; x++)
        {
	  {
	    rgb = image.pixel(x, y);	
	
	    if (!(qRed(rgb) & qGreen(rgb) & qBlue(rgb))) 
	    {
	      painter->setPen(cgrp.mid());
 	      painter->drawPoint(xpm_x+x, xpm_y+y);
	    }
       	  }
        }
      }
    }
    else
    {
      painter->setPen(cgrp.light());
      painter->drawText(3, 3, butw-ledsz-4, buth-4, AlignCenter, text());
      painter->setPen(cgrp.mid());
      painter->drawText(2, 2, butw-ledsz-4, buth-4, AlignCenter, text());
    }
  }
}


/*
 * Public methods
 *****************/
 
void LEDPushButton::shiftPixmap(int dx, int dy)
{
  _xshift = dx;
  _yshift = dy;
  
  repaint();
}
