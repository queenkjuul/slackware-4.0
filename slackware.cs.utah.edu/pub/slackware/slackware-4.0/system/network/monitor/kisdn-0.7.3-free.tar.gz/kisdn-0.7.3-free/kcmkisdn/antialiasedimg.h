/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: antialiasedimg.h,v 1.1.1.1 1998/11/21 10:18:57 twesthei Exp $
//
// $Log: antialiasedimg.h,v $
// Revision 1.1.1.1  1998/11/21 10:18:57  twesthei
// Imported sources
//
// Revision 1.1  1998/10/26 13:46:35  gis
// *** empty log message ***
//
// Revision 1.1  1998/10/26 12:36:11  gis
// *** empty log message ***
//
// Revision 1.1  1998/10/23 19:05:42  twesthei
// Added a class to handle anti-aliased GIF images
//


#ifndef ANTIALIASEDIMG_H
#define ANTIALIASEDIMG_H

#include <qcolor.h>
#include <qimage.h>

#include <kapp.h>


class AntiAliasedImage : public QImage
{
  public:

    AntiAliasedImage();
    ~AntiAliasedImage() {}

    bool loadImage( QString );
    QImage getImage(const QColor&);
    QImage getImage() { return getImage( kapp->backgroundColor ); }
  
  private:
  
    QImage img;
};


#endif
