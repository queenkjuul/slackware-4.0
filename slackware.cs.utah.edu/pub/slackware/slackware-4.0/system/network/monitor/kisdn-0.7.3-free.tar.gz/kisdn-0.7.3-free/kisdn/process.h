/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#ifndef __PROCESS_H
#define __PROCESS_H

#include <mykprocess.h>


class Process : public QObject
{
  Q_OBJECT

  public:

    Process( uid_t uid = 0 );
    ~Process();

    MyKProcess *childProcess;

    void execute( QString );


  public slots:

    void slotProcessDead( KProcess * );

  signals:

    void sigProcessFinished();

  private:

    bool myDropRoot;

};

#endif
