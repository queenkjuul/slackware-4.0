/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#ifndef __KISDNDATA_H
#define __KISDNDATA_H

#include <stdlib.h>

#include <qcolor.h>
#include <qstrlist.h>

#include <kconfig.h>
#include <klocale.h>

#define INDXSIZE 2
#define ARGSIZE  64
#define PATHSIZE 128
#define TIMESIZE 8
#define PNUMSIZE 128  /* Phone numbers */
#define DEVSIZE  8    /* Devices       */
#define NAMESIZE 128
#define IPNMSIZE 16   /* IP numbers    */
#define DATMSIZE 2    /* Dial attempts */

#define PAPFILE  "/etc/ppp/pap-secrets"
#define CHAPFILE "/etc/ppp/chap-secrets"
#define DNSFILE  "/etc/resolv.conf"
#define OPTFILE  "/etc/ppp/ioptions"

#define PROTRAWIP  0
#define PROTIP     1
#define PROTCISCO  2
#define PROTETHER  3
#define PROTSYNC   4
#define PROTIPUI   5


class IP
{
  private:

    char  data[IPNMSIZE+1];
    bool  notnull;

  public:

    IP(const char *);
    ~IP() {}

    bool isValidIP();
    bool isNull() { return (!notnull); }   // Don't forget to call isValidIP
                                           // first ! In case of an
};					   //invalid ip the return value of
                                           // isNull is _undefined_ !


class PhoneData
{
  public:

    QString    number, tmp_number;
    PhoneData  *prev, *next;

    PhoneData();
    ~PhoneData() {}
};


class DNSData
{
  public:

    QString  ipaddress, tmp_ipaddress;
    DNSData  *prev, *next;

    DNSData();
    ~DNSData() {}
};


class DevData
{
  public:

    PhoneData  *FirstPhone, *LastPhone, *CurrPhone;
    uint       HupTimeout, tmp_HupTimeout;
    ushort     DialAttempts, tmp_DialAttempts;
    uint       Delay, tmp_Delay;
    ushort     Encaps, tmp_Encaps, Layer2, tmp_Layer2, Layer3, tmp_Layer3;
    DevData    *prev, *next;
    QString    Name;

    DevData();
    ~DevData() {}

    void Backup();
    void Restore();
    bool Load(KConfig *, uint, ushort, bool);
    void Save(KConfig *, uint, ushort, bool);
};


class AccData
{
  private:

    QString  toHexByte(char);
    char     fromHexByte(const char *);
    QString  toHexString(int, const char *);
    QString  fromHexString(int, const char *);

  public:

    int      cryptbyte;
    QString  providername, tmp_providername;
    ushort   device, tmp_device;
    DevData  MasterDevice, *FirstSlave, *LastSlave, *CurrDev;
    bool     ipdynamic, tmp_ipdynamic;
    QString  iplocaddress, tmp_iplocaddress, ipremaddress, tmp_ipremaddress;
    QString  subnetmask, tmp_subnetmask;
    QString  domain, tmp_domain;
    DNSData  *FirstDNS, *LastDNS, *CurrDNS;
    bool     UsePAP, tmp_UsePAP, UseCHAP, tmp_UseCHAP, UseNONE, tmp_UseNONE;
    QString  username, tmp_username, password, tmp_password;
    QStrList users, tmp_users;
    bool     isAccountEnabled, tmp_isAccountEnabled;
    bool     callback, tmp_callback, cbinit, tmp_cbinit, cbhangup, tmp_cbhangup;
    uint     huptime, tmp_huptime, cbtime, tmp_cbtime;
    bool     securemode, tmp_securemode;
    bool     vjcomp, tmp_vjcomp, vjconn, tmp_vjconn, adrctrl, tmp_adrctrl;
    bool     protfld, tmp_protfld, ipcpaccloc, tmp_ipcpaccloc, ipcpaccrem, tmp_ipcpaccrem;
    bool     strip0, tmp_strip0;
    QString  ingoingphone, tmp_ingoingphone;

    bool     changed; // internal, indicates, whether accdata has changed
    AccData  *prev, *next;

    AccData();
    ~AccData() {}

    void Backup();
    void Restore();
    bool Load(KConfig *, uint);
    void Save(KConfig *, uint, bool);
};


class AdvData
{
  public:

    bool    bsdcomp, tmp_bsdcomp, incdebug, tmp_incdebug;
    ushort  dbglevel, tmp_dbglevel;
    uint    mru, mtu, tmp_mru, tmp_mtu;

    AdvData();
    ~AdvData() {}

    void Backup();
    void Restore();
    bool Load(KConfig *);
    void Save(KConfig *);
};


class GenData
{
  public:

    QString  ipppdpath, tmp_ipppdpath;
    QString  prefix, tmp_prefix, msnData, tmp_msnData;
    bool     loadasmodule, tmp_loadasmodule;
    bool     explicitEnable, tmp_explicitEnable;
    bool     disableIpUpDown, tmp_disableIpUpDown;
    QString  modprobepath, tmp_modprobepath;
    ushort   adapter, tmp_adapter, protocol, tmp_protocol;
    QString  membase, tmp_membase, iobase0, iobase1, tmp_iobase0, tmp_iobase1;
    ushort   interrupt, tmp_interrupt;
    AdvData  Advanced, tmp_Advanced;

    GenData();
    ~GenData() {}

    bool  Load(KConfig *);
    void  Save(KConfig *);
    void  Backup();
    void  Restore();
};


class RootData
{
public:
  RootData();
  ~RootData() {}

  bool Load( KConfig * );
  void Save( KConfig * );
  
  QStrList allUsersList;
};


class kISDNData
{
  public:

    uint     AccLoaded;
    uint     NumAcc;
    bool     ISPListChanged;

    QString  rcRevision;
    GenData  *General;
    RootData *rootData;
    AccData  *FirstAccount, *LastAccount, *Current, *Temp;

    kISDNData();
    ~kISDNData();

    void setIpppdPath(const char *path) { General->ipppdpath   = *path;  }
    void setPrefix(const char *phone)   { General->prefix      = *phone; }
    void setMsnData(const char *phone)  { General->msnData     = *phone; }

    bool Load();
    void Save();
    void SaveUsers();
    void Backup();
    void Restore();

};


extern kISDNData ISDNData;

#endif
