/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: uptimenum.cpp,v 1.2 1998/11/21 12:35:02 twesthei Exp $
//
// $Log: uptimenum.cpp,v $
// Revision 1.2  1998/11/21 12:35:02  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <qpainter.h>

#include "uptimenum.h"


UpTimeNumber::UpTimeNumber(const QColor& bg, const QColor& dk, const QColor& lg, QWidget *parent, 
                           const char *name, int h, int m, int s) : QFrame(parent, name),
			   					    _hLCD(bg, dk, lg, this, 0, 100),
								    _mLCD(bg, dk, lg, this, 0, 60),
								    _sLCD(bg, dk, lg, this, 0, 60),
			                                            _hours(h),
						                    _mins(m),
						                    _secs(s)
{  
  _lcdw = _hLCD.width();
  _lcdh = _hLCD.height();
  
  setFixedSize(3*_lcdw+2*DPWIDTH, _lcdh);
  setBackgroundColor(bg);

  _hLCD.move(0, 0);
  _mLCD.move(_lcdw+DPWIDTH, 0);
  _sLCD.move(2*(_lcdw+DPWIDTH), 0);
  
  QPainter  p;
  QPixmap   dp_xpm(DPWIDTH, _lcdh);
  int       offs = (_lcdh-4-4)/2;
  
  dp_xpm.fill(bg);
  
  p.begin(&dp_xpm);
  
  p.setPen(lg);
  p.drawLine(2, offs,   3, offs);
  p.drawLine(2, offs+1, 3, offs+1);
  
  p.drawLine(2, _lcdh-offs-1, 3, _lcdh-offs-1);
  p.drawLine(2, _lcdh-offs-2, 3, _lcdh-offs-2);
   
  p.end();

  dp1label = new QLabel(this);
  dp1label->setPixmap(dp_xpm);
  dp1label->setGeometry(_lcdw, 0, DPWIDTH, _lcdh);
  
  dp2label = new QLabel(this);
  dp2label->setPixmap(dp_xpm);
  dp2label->setGeometry(2*_lcdw+DPWIDTH, 0, DPWIDTH, _lcdh);
}    


/*
 * Public methods
 *****************/
 
void  UpTimeNumber::setTime(int h, int m, int s)
{
  _hLCD.setTime(h);
  _mLCD.setTime(m);
  _sLCD.setTime(s);
}
