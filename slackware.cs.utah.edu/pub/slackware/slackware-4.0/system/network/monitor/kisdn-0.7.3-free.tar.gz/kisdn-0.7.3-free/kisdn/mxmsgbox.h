/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: mxmsgbox.h,v 1.1.1.1 1998/11/21 10:18:58 twesthei Exp $
//
// $Log: mxmsgbox.h,v $
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
//
// Revision 1.4  1998/10/27 19:36:00  twesthei
// New message box (No ISDN Support) and according pixmap
//
// Revision 1.3  1998/10/27 15:17:20  twesthei
// Added new message box (not implemented), answer call is already
// using it...
//
// Revision 1.2  1998/10/26 18:57:34  twesthei
// Added a a priori check for the sound driver and some
// error message boxes so problems with the sound driver
// will show up at startup
//
// Revision 1.1  1998/10/26 15:15:08  twesthei
// *** empty log message ***
//


#ifndef __MXMSGBOX_H
#define __MXMSGBOX_H

#include <qdialog.h>
#include <qevent.h>
#include <qframe.h>
#include <qpushbt.h>

#include <kiconloader.h>

#include "mxlogo.h"


class MXMessageBox : public QDialog
{
  Q_OBJECT
  
  public:
  
    enum  mxpixmap { Phone, Keys, Soundcard, ISDNCard, Screws };
    
  private:
  
    QString      _caption, _text;
    
    int          _distpmlabel;
    int          _distlogobutton;
    int          _paddingupper, _paddinglower;
    int          _margin;
   
    KIconLoader  *_loader;
    
    QFrame       *_etched;
    QLabel       *_pmlabel, *_textlabel, *_logolabel;
    QPixmap      _pixmap;
    QPushButton  *_button;
    MXLogo       *_logo;
    
    void  resizeEvent(QResizeEvent *);
    
  public:
  
    MXMessageBox(mxpixmap, const QString&, const QString&, QWidget *parent = 0, 
                 const char *name = 0, bool modal = true);
    ~MXMessageBox() {}
};


#endif


