/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: uptdisplay.cpp,v 1.2 1998/11/21 12:35:01 twesthei Exp $
//
// $Log: uptdisplay.cpp,v $
// Revision 1.2  1998/11/21 12:35:01  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <qtooltip.h>

#include <kapp.h>

#include "uptdisplay.h"


UptimeDisplay::UptimeDisplay(const QColor& txt, const QColor& bg, const QColor& dk, const QColor& lg, 
                             QWidget *parent, const char *name) : QFrame(parent, name),
			                                          _timeA(bg, dk, lg, this),
								  _timeB(bg, dk, lg, this)
{
  QColorGroup  colgrp;
  QPalette     txtpal;
  
  setFixedSize(378, 22);
  setLineWidth(2);
  setFrameStyle(QFrame::Panel | QFrame::Sunken);        
  setBackgroundColor(bg);

  colgrp = QColorGroup(txt, bg, txt, bg, txt, txt, bg);
  txtpal = QPalette(colgrp, colgrp, colgrp);

  _utlabel = new QLabel(i18n("Online time"), this);
  _utlabel->setPalette(txtpal);
  _utlabel->setFont(QFont::QFont("Helvetica", 10));
  _utlabel->adjustSize();
  _utlabel->move(4, 4);

  _chalabel = new QLabel(i18n("Channel A:"), this);
  _chalabel->setPalette(txtpal);
  _chalabel->setFont(QFont::QFont("Helvetica", 10));
  _chalabel->adjustSize();
  _chalabel->move(80, 4);

  _timeA.move(150, 4);
  QToolTip::add(&_timeA, i18n("Online time of channel A"));

  _chblabel = new QLabel(i18n("Channel B:"), this);
  _chblabel->setPalette(txtpal);
  _chblabel->setFont(QFont::QFont("Helvetica", 10));
  _chblabel->adjustSize();
  _chblabel->move(240, 4);

  _timeB.move(310, 4);
  QToolTip::add(&_timeB, i18n("Online time of channel B"));
}


/*
 * Public methods
 *****************/
 
void  UptimeDisplay::setUptime(int ch, int h, int m, int s)
{
  UpTimeNumber  *utn = (ch ? &_timeB : &_timeA);
  
  utn->setTime(h, m, s);
}
