/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: lcdtime.h,v 1.2 1998/11/21 12:35:22 twesthei Exp $
//
// $Log: lcdtime.h,v $
// Revision 1.2  1998/11/21 12:35:22  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __LCDTIME_H
#define __LCDTIME_H

#include <qframe.h>
#include <qlabel.h>

#include "lcdsmall.h"


class LCDTime : public QFrame
{
  private:
  
    SmallLCDNumber  _LCD1, _LCD2;
    int             _timeval, _limit;
    int             _lcdw, _lcdh;
    QLabel          *_lcdlabel[2];
      
  public:
  
    LCDTime(const QColor&, const QColor&, const QColor&, QWidget *parent = 0, const char *name = 0,
            int tval = 0, int limit = 100);
    ~LCDTime() {}
    
    void  setTime(int);
    void  setBackGround(const QColor&);
    void  setDarkColor(const QColor&);
    void  setLightColor(const QColor&);
};


#endif

