/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#ifndef __ACCDLG_H
#define __ACCDLG_H

#include <stdio.h>
#include <ctype.h>

#include <kapp.h>
#include <klocale.h>
#include <kiconloader.h>

#include <qbttngrp.h>
#include <qchkbox.h>
#include <qcombo.h>
#include <qframe.h>
#include <qgrpbox.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qlined.h>
#include <qlistbox.h>
#include <qmsgbox.h>
#include <qpushbt.h>
#include <qradiobt.h>
#include <qtabdlg.h>
#include <qtooltip.h>

#include "kisdndata.h"
#include "logo.h"

#define NEW   1
#define EDIT  2


class DevicesWidget : public QWidget
{
  Q_OBJECT
  
  private:
  
    QComboBox    *Encapsbox, *Layer2box, *Layer3box;
    QGroupBox    *GBox;
    QLabel       *Provlabel, *Remotelabel, *Listlabel, *Diallabel, *HupTimelabel, *Sec1label;
    QLabel       *pmPhone, *Encapslabel, *Layer2label, *Layer3label, *Delaylabel, *Sec2label;
    QListBox     *Phonelist;
    QPushButton  *Addbutton, *Removebutton;
    
    void  Backup();
    void  Restore();
    void  resizeEvent( QResizeEvent * );
    
  private slots:
  
    void  slotAddRemote();
    void  slotRemoveRemote();
    void  slotEncapsChanged(int);
    void  slotLayer2Changed(int);
    void  slotLayer3Changed(int);
  
  public:

    QLineEdit *Provider, *Attempts, *HupTime, *Remote, *Delay;
  
    DevicesWidget(QWidget *parent = 0, const char *name = 0); 
    ~DevicesWidget() {}
};


class IPWidget : public QWidget
{
  Q_OBJECT
  
  private:
  
    QButtonGroup  *IPGroup;
    QGroupBox     *GBox, *IPGBox;
    QLabel        *pmMail, *IPloclabel, *IPremlabel, *Masklabel;
    QRadioButton  *DynButton, *StatButton;
    QVBoxLayout   *IPVBox;
    
    void setIPStatic(bool);
    void resizeEvent( QResizeEvent * );
  
  private slots:
  
    void slotRButtonClicked(int);
 
  public:
  
    QLineEdit  *IPloc, *IPrem, *Mask;
  
    IPWidget(QWidget *parent = 0, const char *name = 0);
    ~IPWidget() {}
};


class DNSWidget : public QWidget
{
  Q_OBJECT
  
  private:
  
    QButtonGroup  *IPGroup;
    QGroupBox     *GBox;
    QLabel        *Domainlabel, *DNSlabel, *DNSListlabel, *pmDNS;
    QLineEdit     *DNS;
    QListBox      *DNSList;
    QPushButton   *AddButton, *RemButton;
  
    void messageBadIP();
    void resizeEvent( QResizeEvent * );
  
  private slots:
  
    void slotAddDNS();
    void slotRemoveDNS();
  
  public:

    QLineEdit  *Domain;
   
    DNSWidget(QWidget *parent = 0, const char *name = 0);
    ~DNSWidget() {}
};


class AuthWidget : public QWidget
{
  Q_OBJECT
  
  private:
  
    QButtonGroup  *AuthGroup;
    QFrame        *Etched;
    QGroupBox     *GBox;
    QLabel        *Userlabel, *Passwordlabel, *pmKey;
    QRadioButton  *NoneButton, *PAPButton, *CHAPButton;
    QVBoxLayout   *AuthVBox;
     
    void setPhrasesEnabled(bool);
    void resizeEvent( QResizeEvent * );
  
  private slots:
  
    void slotAuthChanged(int);
     
  public:
  
    QLineEdit  *User, *Password;
  
    AuthWidget(QWidget *parent = 0, const char *name = 0);
    ~AuthWidget() {}
};


class UsersWidget : public QWidget
{
  Q_OBJECT
  
  private:

    QCheckBox     *allowCheck;
    QGroupBox     *GBox;
    QLabel        *pmUsers, *usersLabel, *usersListLabel;
    QLineEdit     *usersEdit;
    QPushButton   *addButton, *editButton, *remButton;

    bool checkUser(QString);
    void refreshListBox();
    void resizeEvent( QResizeEvent * );

  private slots:

    void slotAddUser();
    void slotEditUser();
    void slotRemoveUser();
    void slotDropEvent(KDNDDropZone *);
    void slotEnableUsage();
    
  public:

    UsersWidget(QWidget *parent = 0, const char *name = 0);

    QListBox      *usersList;
};


class CallBackWidget : public QWidget
{
  Q_OBJECT

  private:
  
    QButtonGroup  *ingoinggroup;
    QGroupBox     *GBox, *ingoingbox, *initbox, *answerbox;
    QLabel        *ihuplabel, *ahuplabel, *iseclabel, *aseclabel, *pmCallBack;;
    QRadioButton  *otherbutton;
    QVBoxLayout   *ingoingvbox;
    
    void setDialogState(bool);
    void setIngoingState(bool);
    void setInitState(bool);
    void setAnswerState(bool);
    void resizeEvent(QResizeEvent *);
  
  private slots:
  
    void slotIngoingClicked(int);
    void slotCBStateChanged();
    void slotInitClicked();
    void slotAnswerClicked();
  
  public:

    QCheckBox     *cbcheck, *initcheck, *answercheck, *hupcheck;
    QLineEdit     *remin;
    QLineEdit     *ihangup, *ahangup;
    QRadioButton  *strip0button;
     
    CallBackWidget(QWidget *parent = 0, const char *name = 0);
    ~CallBackWidget() {}
};


class MoreWidget : public QWidget
{
  Q_OBJECT

  private:
  
    QGroupBox  *GBox, *IPPPDBox;
    QLabel     *pmAdd;

    void resizeEvent(QResizeEvent *);
  
  public:
  
    MoreWidget(QWidget *parent = 0, const char *name = 0);
    ~MoreWidget() {}
  
    QCheckBox  *securecheck;
    QCheckBox  *vjcheck, *vjconncheck, *adrctrlcheck;
    QCheckBox  *protfldcheck, *ipcpaccloccheck, *ipcpaccremcheck;
};

  
#endif
