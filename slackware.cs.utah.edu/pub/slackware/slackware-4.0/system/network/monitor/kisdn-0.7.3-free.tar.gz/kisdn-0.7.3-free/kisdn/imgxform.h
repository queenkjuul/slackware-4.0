/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: imgxform.h,v 1.1.1.1 1998/11/21 10:18:58 twesthei Exp $
//
// $Log: imgxform.h,v $
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
//
// Revision 1.1  1998/10/23 19:05:42  twesthei
// Added a class to handle anti-aliased GIF images
//


#ifndef __IMGXFORM_H
#define __IMGXFORM_H

#include <qcolor.h>
#include <qimage.h>
#include <qpixmap.h>


class ImageTransformation
{
  private:
      
    int     _width, _height;
    int     _numcolors;
    QImage  _image;
        
  public:
  
    ImageTransformation(const QImage&);
    ~ImageTransformation() {}
    
    QImage         getAntiAliasedImage(const QColor&);
    const QImage&  image() const { return _image; }
};


#endif


