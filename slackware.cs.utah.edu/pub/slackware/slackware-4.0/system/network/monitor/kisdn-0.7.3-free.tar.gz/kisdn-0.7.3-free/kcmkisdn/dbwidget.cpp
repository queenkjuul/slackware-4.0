/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#include <qpixmap.h>
#include <qmsgbox.h>

#include <kapp.h>
#include <kiconloader.h>
#include <klocale.h>

#include "antialiasedimg.h"
#include "dbwidget.h"


DBDialog::DBDialog(QWidget *parent, const char *name) : QDialog(parent, name, true)
{
  AntiAliasedImage ai;
  Country  *coptr;
  City     *ciptr;
  DBEntry  *ispptr;

  setMinimumSize(200, 150);
  resize(400, 400);
  setCaption(i18n("Provider setup from kISDN database"));

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap isp_xpm = loader->loadIcon("isp.xpm"),
		city_xpm = loader->loadIcon("city.xpm");
  static QPixmap flag_xpm, logo_xpm, pm;

  Logo = new QLabel(this);
  if ( ai.loadImage (kapp->kde_datadir()+"/kisdn/pics/millenniumx.gif") )
  {
    pm.convertFromImage(ai.getImage(), QPixmap::Color);
    Logo->setPixmap(pm);
    Logo->adjustSize();
  }
  Logo->move(10, 360);

  TreeList = new KTreeList(this);
  TreeList->setGeometry(10, 10, 380, 340);

  TreeList->setExpandButtonDrawing(true);
  TreeList->setTreeDrawing(TRUE);

  KTreeListItem *ispitem = new KTreeListItem(i18n("Providers"), &isp_xpm);

  TreeList->insertItem(ispitem, -1, FALSE);

  OK = new QPushButton(i18n("OK"), this);
  OK->setGeometry(222, 362, 80, 28);
  OK->setDefault(true);
  connect(OK, SIGNAL(clicked()), SLOT(accept()));

  Cancel = new QPushButton(i18n("Cancel"), this);
  Cancel->setGeometry(310, 362, 80, 28);
  connect(Cancel, SIGNAL(clicked()), SLOT(reject()));

  QString dbfile = KApplication::kde_datadir();
  dbfile.detach();
  dbfile += "/kisdn/kisdndb.txt";
  db = new DB( dbfile.data() );

  for (coptr=db->getCountryList().first(); coptr != 0; coptr=db->getCountryList().next() )
  {
    if (coptr->hasFlag()) flag_xpm = loader->loadIcon(coptr->flag());
    else                  flag_xpm = isp_xpm;

    country = new KTreeListItem(coptr->name(), &flag_xpm);
    ispitem->appendChild(country);

    for (ciptr=coptr->getCityList().first(); ciptr != 0; ciptr=coptr->getCityList().next())
    {
      city = new KTreeListItem(ciptr->name(), &city_xpm);
      country->appendChild(city);

      for (ispptr=ciptr->getProviderList().first(); ispptr != 0; ispptr=ciptr->getProviderList().next())
      {
	if (ispptr->logofile) logo_xpm = loader->loadIcon(ispptr->logofile->data());
      	else                  logo_xpm = isp_xpm;
	
        ispName = new KTreeListItem(ispptr->name->data(), &logo_xpm);
        city->appendChild(ispName);
      }
    }
  }
  TreeList->expandItem(0);
}


DBDialog::~DBDialog(void)
{
 delete db;
}


// this method is called, when someone presses the OK-Button
void DBDialog::accept()
{
  Country  *coptr;
  City     *ciptr;
  DBEntry  *ispptr;

  int index = TreeList->currentItem();

  if (index == -1)  // no provider selected
  {
    noProviderSelected();
    return;
  }
  else
  {
    KPath    *path;
    QString  ispspec[4];
    ushort   depth = 4;

    path = TreeList->itemPath(index);

    while (!path->isEmpty()) ispspec[--depth] = path->pop()->copy();
    delete (path);

    if (!depth)  // the selected entry is a provider
    {
      for (coptr=db->getCountryList().first(); coptr != 0; coptr=db->getCountryList().next() )
      {
        for (ciptr=coptr->getCityList().first(); ciptr != 0; ciptr=coptr->getCityList().next() )
        {
          for (ispptr=ciptr->getProviderList().first(); ispptr != 0; ispptr=ciptr->getProviderList().next() )
          {
            if (QString(coptr->name()) == ispspec[1]  && QString(ciptr->name()) == ispspec[2]
	        && *(ispptr->name) == ispspec[3])
            {
	      chosen = ispptr;
	    }
          }
        }
      }
    }
    else  // selected entry is no provider
    {
      noProviderSelected();
      return;
    }
    done(Accepted); // close the dialog and return that "Ok" was pressed.
  }
}


void DBDialog::noProviderSelected()
{
    QString tmp  = i18n("You should select a provider in the\n");
    tmp         += i18n("list and then press 'OK'.\n\n");
    tmp         += i18n("Choose 'Cancel' if you don't want to\n");
    tmp         += i18n("create a new account.");

    QMessageBox::warning(this, i18n("Select a provider"), tmp, "OK", 0);
}


void DBDialog::resizeEvent( QResizeEvent * )
{
  uint MARGIN = 5;
  uint w = width();
  uint wo = OK->width();
  uint wc = Cancel->width();
  uint wy = height() - MARGIN - Logo->height();

  Logo->move( 2*MARGIN, wy );
  OK->move( w - 3*MARGIN - wo - wc, wy );
  Cancel->move( w - 2*MARGIN - wc, wy );

  TreeList->resize( width() - 20, height() - 53 );
}
