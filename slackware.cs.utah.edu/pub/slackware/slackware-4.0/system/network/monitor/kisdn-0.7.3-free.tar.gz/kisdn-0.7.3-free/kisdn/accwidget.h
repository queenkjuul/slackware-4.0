/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: accwidget.h,v 1.2 1998/11/21 12:35:03 twesthei Exp $
//
// $Log: accwidget.h,v $
// Revision 1.2  1998/11/21 12:35:03  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
 
 
#ifndef __ACCWIDGET_H
#define __ACCWIDGET_H

#include <kapp.h>
#include <kfiledialog.h>
#include <kiconloader.h>

#include <qevent.h>
#include <qgrpbox.h>
#include <qlabel.h>
#include <qlistbox.h>
#include <qmsgbox.h>
#include <qpixmap.h>
#include <qpushbt.h>

#include "execwidget.h"
#include "logo.h"
#include "klistboxitem.h"
#include "kisdndata.h"


class AccountWidget : public QWidget
{
  Q_OBJECT
  
  public:
  
    enum  entertype { NEW, EDIT };
    
  private:
  
    QGroupBox    *GBox;
    QLabel       *costlabel, *pmScreen;
    QLineEdit    *costs;
    QListBox     *acclist;
    QPixmap      account_xpm;
    QPushButton  *pushedit, *pushcopy, *pushdel, *pushresetb;
    QString      _modestr;
    QTabDialog   *accdialog;

    ExecWidget	*ExecTab, *ExecTab2;
    bool        _isplistchanged;
  
    int   execAccDialog(AccountData *, entertype);
    void  fillIn();
    void  resizeEvent(QResizeEvent *);

  private slots:
  
    void  slotAccSelected(int); 
    void  slotChangeName(int);
    void  slotEditAccount();
    void  slotCopyAccount();
    void  slotDeleteAccount();
    void  slotSetCaption(const char *);
  
  public:
  
    AccountWidget(QWidget *parent = 0, const char *name = 0); 
    ~AccountWidget() {}

    bool  changedISPList() const { return _isplistchanged; }
};


#endif
