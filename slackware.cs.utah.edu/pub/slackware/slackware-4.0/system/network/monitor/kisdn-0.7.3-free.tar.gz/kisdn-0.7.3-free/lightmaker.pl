#!/usr/local/bin/perl

###################### lightmaker.pl ########################
#                                                           #
# creates the light-version of kISDN,                       #
# by reading all the sourcefiles, finding sections like     #
# ///start-light                                            #
# [ some code ]                                             #
# ///end-light                                              #
# and deleting them all. You then just have to              #
# make a tarball of that directory - that's the             #
# kisdn-light version.                                      #
#                                                           #
# 25/08/1998 Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de #
#############################################################

# some configuration

$start_pro = "\/\/\/start-pro";
$end_pro = "\/\/\/end-pro";
$define_header = "KISDN_LIGHT_VERSION";

#############################################################
# read every line coming from STDIN into a variable, test for 
# start-light and end-light and eventually delete the lines

if ( $define_header )
{
    print "#ifndef $define_header\n";
    print "#define $define_header\n";
    print "#endif\n\n";
}

while ( $_ = <STDIN> )
{
    if (/$start_pro/)
    {
	$_ = <STDIN>;
	while (!/$end_pro/) # read until $end-pro
	{
	    $_ = <STDIN>;
	}
    }

    else # not light-version related
    {
	print "$_";
    }
}
