/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: genwidget.h,v 1.2 1998/11/21 12:35:13 twesthei Exp $
//
// $Log: genwidget.h,v $
// Revision 1.2  1998/11/21 12:35:13  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __GENWIDGET_H
#define __GENWIDGET_H

#ifdef HAVE_CONFIG_H
  #include "../config.h"
#endif

#include <kapp.h>
#ifdef HAVE_GLOBAL_SHORTCUTS
  #include <kglobalaccel.h>
  #include <kkeydialog.h>
#endif
#include <kiconloader.h>

#include <qchkbox.h>
#include <qgrpbox.h>
#include <qlabel.h>
#include <qpixmap.h>
#include <qpushbutton.h>
#include <qsize.h>

#include "kisdndata.h"

class GeneralWidget : public QWidget
{
  Q_OBJECT

  private:

    QCheckBox    *shutchk, *dockchk, *authchk, *incchk, *splashchk;
    QGroupBox    *GBox;
    QLabel       *pmLinux;

#ifdef HAVE_GLOBAL_SHORTCUTS
    QPushButton  *keybutton;
#endif
  
    CustomData   *customdata;

  private slots:

    void  slotDisconnectChanged() { customdata->setDisconnect(shutchk->isChecked());          }
    void  slotDockChanged()       { customdata->setDocking(dockchk->isChecked());             }
    void  slotAuthChanged()       { customdata->setSoundOnAuth(authchk->isChecked());         }
    void  slotInCallChanged()     { customdata->setSignalizationEnabled(incchk->isChecked()); }
    void  slotSplashChanged()     { customdata->setShowSplash(splashchk->isChecked());        }
    void  slotConfigureKeys();


  public:

    GeneralWidget(CustomData *, QWidget *parent = 0, const char *name = 0);
    ~GeneralWidget() {};

    void   refreshSettings();
    void   resizeEvent(QResizeEvent *);

    QSize         minimumSize() const { return QSize(328, 314); }
#ifdef HAVE_GLOBAL_SHORTCUTS
    KGlobalAccel  *globalKeys;
#endif
};


#endif
