/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: throughput.cpp,v 1.2 1998/11/21 12:34:59 twesthei Exp $
//
// $Log: throughput.cpp,v $
// Revision 1.2  1998/11/21 12:34:59  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <qpalette.h>

#include <kapp.h>
#include <kiconloader.h>

#include "throughput.h"


ThroughPut::ThroughPut(MatrixFont *mf, QWidget *parent, const char *name) : 
							QFrame(parent, name),
							_text(" 0.0"),
							mtxfont(mf)
{
  QColor       yellow, black;
  QColorGroup  colgrp;
  QPalette     txtpal;
  
  setFixedSize(86 ,25);
  setLineWidth(2);
  setFrameStyle(QFrame::Panel | QFrame::Sunken);
  setBackgroundColor(QColor::QColor(black));
  
  yellow = QColor(0xf0, 0xec, 0x30);
  black  = QColor(black);
  colgrp = QColorGroup(yellow, black, yellow, black, yellow, yellow, black);
  txtpal = QPalette(colgrp, colgrp, colgrp);
  
  kbs = new QLabel(i18n("kB/s:"), this);
  kbs->setPalette(txtpal);
  kbs->setFont(QFont::QFont("Helvetica", 10));
  kbs->adjustSize();
  kbs->move(4, 6);
  
  display    = new QLabel(this);
  mtxdisplay = new MatrixPixmap(mtxfont, _text.data());
  display->setPixmap(*mtxdisplay);
  display->adjustSize();
  display->move(36, 6);
}


void ThroughPut::setText(const char *ratestr)
{
  if (QString(ratestr) != _text)			// Avoid flickering when there is no change
  {
    mtxdisplay->setText(ratestr);
    display->setPixmap(*mtxdisplay);
  }
  
  _text = QString(ratestr);
}


