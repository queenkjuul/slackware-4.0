#include <qstring.h>

#include "kisdncompat.h"
#include "version.h"


// Precondition: we're operating on a version of our rc-file, different from
// our current version.
// So we just check all incompatible changes, we have done so far
KisdnCompat::KisdnCompat()
{
}


bool KisdnCompat::ensureCompatibility( KConfig *kc )
{
  QString account;
  bool ipDynamic, pap, chap;
  bool changed = false;
  int msn;

  kc->setGroup( "General" );
  int numacc = kc->readNumEntry( "NumAccounts" );
  
  for (int i = 0; i < numacc; i++ )
  {
    account.sprintf( "Account%i", i );
    kc->setGroup( account.data() );

    // IPDynamic = yes|no has changed to AssignType = dynamic|static
    if ( !kc->hasKey( "AssignType" ) )
    {
      ipDynamic = (kc->readEntry( "IPDynamic" ) == "yes" );
      kc->writeEntry( "AssignType", ipDynamic ? "dynamic" : "static" );
      changed = true;
    }


    // UsePAP and UseCHAP = yes|no have changed to AuthType = pap|chap|none
    if ( !kc->hasKey( "AuthType" ) )
    {
      pap  = (kc->readEntry( "UsePAP" ) == "yes" );
      chap = (kc->readEntry( "UseCHAP" ) == "yes" );

      QString authType;
      if ( pap ) authType = "pap";
      else if ( chap ) authType = "chap";
      else authType = "none";

      kc->writeEntry( "AuthType", authType.data() );

      changed = true;
    }
  }


  // Msn has splitted into MsnForDataConnections and MsnForVoiceConnections
  kc->setGroup( "General" );
  msn = kc->readNumEntry( "Msn" );
  if ( !kc->hasKey( "MsnForDataConnections" ) )
  {
    kc->writeEntry( "MsnForDataConnections", msn );
    changed = true;
  }

  if ( !kc->hasKey( "MsnForVoiceConnections" ) )
  {
    kc->writeEntry( "MsnForVoiceConnections", msn );
    changed = true;
  }


  kc->setGroup( "Configuration" );
  kc->writeEntry( "Revision", KISDNVERSION );


  if ( changed )
  {
    kc->sync();
  }
  
  return changed;
}
