/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include <qpainter.h>

#include <klistboxitem.h>


KListBoxItem::KListBoxItem(QWidget *, const char *s, const QPixmap p) : QListBoxItem(), pm(p)
{
  setText(s);
}


void KListBoxItem::paint(QPainter *p)
{
  int yPos;                       // vertical text position

  p->drawPixmap(3, 2, pm);
  QFontMetrics fm = p->fontMetrics();
  
  if (pm.height() < fm.height()) yPos = fm.ascent() + fm.leading()/2;
  else                           yPos = pm.height()/2-fm.height()/2+fm.ascent();

  p->drawText(pm.width()+10, yPos+1, text());
}


int KListBoxItem::height(const QListBox *lb) const
{
  return QMAX(pm.height()+4, lb->fontMetrics().lineSpacing()+1);
}


int KListBoxItem::width(const QListBox *lb) const
{
  return pm.width()+lb->fontMetrics().width(text())+6;
}
