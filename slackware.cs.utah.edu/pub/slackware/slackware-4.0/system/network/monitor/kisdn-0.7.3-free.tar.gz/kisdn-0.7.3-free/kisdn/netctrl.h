/*  
 *  This file is part of kISDN, Copyright (C) 1998, 1999 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 *  Kernel 2.2 experimental version, T. Westheider Jan 23rd, 1999
 *
 *****************************************************************/
 
// $Id: netctrl.h,v 1.3 1999/01/23 11:38:24 twesthei Exp $
//
// $Log: netctrl.h,v $
// Revision 1.3  1999/01/23 11:38:24  twesthei
// Applied changes to network code to make kISDN run on
// 2.2.0pre kernels; the changes should do no harm on 2.0.36
// machines, so it's going straight into CVS
//
// Revision 1.2  1998/10/14 22:33:29  twesthei
// Added Id and Log headers
//

 
#ifndef __NETCTRL_H
#define __NETCTRL_H
 
#include <features.h>
 
#if defined __GLIBC__ && __GLIBC__ >=2
#include <net/if.h>
#include <netinet/if_ether.h>
#include <net/route.h>
#else
#include <linux/if.h>
#include <linux/if_ether.h>
#include <linux/route.h>
#endif
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>		/* struct sockaddr_in */

#include <qstring.h>

#include "isdnconfig.h"
#include "isdnctrl.h"
#include "kisdndata.h"

#define DEFAULT    "0.0.0.0"
#define MAXROUTES  64


struct route
{
  char	destIP[16], gateIP[16], mask[16];
  char  iface[16];
};


class NetCtrl : public QObject
{
  Q_OBJECT
  
  private:
  
    QString     _actiface;  
      
    int         skfd;
    ISDNConfig  *isdnconfig;
    ISDNCtrl    *isdnctrl;
    
    struct sockaddr  addr;			
    struct sockaddr  dstaddr;		

    bool  socketOpen() const { return (skfd >= 0); }

    bool  disableDoD();
    bool  enableDoD(AccountData *);
    
    bool  ifGetConfiguration(const char *);
    bool  ifClearFlag(const char *, short);

    bool  routeReadTable(struct route *, uint);
    bool  routeExists(char *); 
    bool  routeAddInterface(char *);

    bool  ipToSocketAddress(char *, struct sockaddr *);
    bool  socketAddressToIP(char *, struct sockaddr_in *);
    char  *hexToQuattedDot(char *, char *);
    uint  hexToInt(char *);
    char  *intToHex(ushort, char *);

    void  dumpSocketAddress(struct sockaddr_in *);
    void  dumpRoutingTable(struct route *);
  
  public:

    NetCtrl(ISDNCtrl *, ISDNConfig *);
    ~NetCtrl();
    
    const char  *getActIface()             { return _actiface.data(); }
    void        setActIface(const char *s) { _actiface = s; }
    
    bool  getIPAddresses(const char *, char *, char *);
    bool  resetIPAddresses(const char *);		  		// syncPPP only !!!
    
    bool  restoreDoD();

    bool  ifUp(const char *);   
    bool  ifDown(const char *); 
    bool  ifPointToPoint(const char *, char *, char *);
    bool  ifSetFlag(const char *, short);

    bool  routeHaveDefault(const char *);
    bool  routeHaveHost();
    bool  routeDelete(char *);
    bool  routeDelInterface(char *);
    bool  routeAddHost(char *, char *);
    bool  routeAddGateway(char *);
  
  public slots:
  
    void  slotDoDDisengage();
    void  slotDoDEngage(AccountData *);
   
  signals:
  
    void  sigDoDState(bool);
    void  sigDoDDisengaged();
    void  sigDoDEngaged();
};


#endif
