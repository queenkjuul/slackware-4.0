#ifndef __KLISTBOXITEM_H
#define __KLISTBOXITEM_H

#include <qlistbox.h>


class KListBoxItem : public QListBoxItem
{
  public:
  
  KListBoxItem( QWidget *, const char *, const QPixmap );
  ~KListBoxItem(){};

  protected:

  virtual void paint( QPainter * );
  virtual int height( const QListBox * ) const;
  virtual int width( const QListBox * ) const;
  virtual const QPixmap *pixmap() { return &pm; }

  private:
  
  QPixmap pm;
};

#endif
