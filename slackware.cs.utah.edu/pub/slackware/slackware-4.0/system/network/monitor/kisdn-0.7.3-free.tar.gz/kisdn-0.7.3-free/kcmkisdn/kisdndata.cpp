/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#include <ctype.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <pwd.h>
#include <string.h>

#include <qfile.h>
#include <qmsgbox.h>
#include <qstring.h>

#include <kapp.h>

#include "general.h"
#include "kisdncompat.h"
#include "kisdndata.h"
#include "version.h"


kISDNData ISDNData;


IP::IP(const char *ip)
{
  strncpy(data, ip, IPNMSIZE);
  data[IPNMSIZE] = '\0';
}


bool IP::isValidIP(void)
{
  char *bufferp = data;
  uint   temp;

  notnull = false;

  for (ushort i = 0; i < 4; i++)
  {
    while (*bufferp == ' ') bufferp++;

    if (!isdigit(*bufferp)) return false;

    temp = 0;

    while (isdigit(*bufferp))
    {
      temp *= 10;
      temp += *(bufferp++)-'0';
      if (temp > 255) return false;
    }

    notnull = notnull || (temp != 0);

    while (*bufferp == ' ') bufferp++;

    if ((i < 3) && (*bufferp != '.')) return false;
    else                              bufferp++;
  }

  bufferp--;

  while (*bufferp == ' ') bufferp++;

  if (*bufferp != '\0') return false;

  return true;
}


PhoneData::PhoneData()
{
  prev   = (PhoneData *) 0L;
  next   = (PhoneData *) 0L;
  number = "";
}


DNSData::DNSData()
{
  prev      = (DNSData *) 0L;
  next      = (DNSData *) 0L;
  ipaddress = "0.0.0.0";
}


DevData::DevData()
{
  prev       = (DevData *) 0L;
  next       = (DevData *) 0L;
  FirstPhone = (PhoneData *) 0L;
  LastPhone  = (PhoneData *) 0L;

  DialAttempts = 1;
  HupTimeout   = 600;
  Delay        = 30;
  Encaps       = 4;
  Layer2       = 3;
  Layer3       = 0;
  Name         = "Dummy";
}


void DevData::Backup()
{
  tmp_DialAttempts = DialAttempts;
  tmp_HupTimeout   = HupTimeout;
  tmp_Delay        = Delay;
  tmp_Encaps       = Encaps;
  tmp_Layer2       = Layer2;
  tmp_Layer3       = Layer3;
}


void DevData::Restore()
{
  DialAttempts = tmp_DialAttempts;
  HupTimeout   = tmp_HupTimeout;
  Delay        = tmp_Delay;
  Encaps       = tmp_Encaps;
  Layer2       = tmp_Layer2;
  Layer3       = tmp_Layer3;
}


bool DevData::Load(KConfig *kc, uint accindex, ushort devindex, bool master)
{
  char       buffer[32];
  ushort     phcnt = 0;
  PhoneData  *phone = (PhoneData *) 0L, *old;

  if (master) sprintf(buffer, "Account%i/Master", accindex);
  else        sprintf(buffer, "Account%i/Slave%i", accindex, devindex);

  kc->setGroup(buffer);
  HupTimeout   = kc->readNumEntry("HupTimeOut", 600);
  DialAttempts = kc->readNumEntry("DialAttempts", 1);

  if (!master)
  {
    Name  = kc->readEntry("Identifier", i18n("(unknown)"));
    Delay = kc->readNumEntry("Delay", 60);
  }

  Encaps = kc->readNumEntry("Encapsulation", 0);
  Layer2 = kc->readNumEntry("Layer2", 0);
  Layer3 = kc->readNumEntry("Layer3", 0);

  phcnt  = kc->readNumEntry("NumPhone", 0);

  if (phcnt > 0)
  {
    for (ushort i = 0; i < phcnt; i++)
    {
      old = phone;
      phone = new PhoneData();
      sprintf(buffer, "Phone%i", i);
      phone->number = kc->readEntry(buffer, "0");

      if (i == 0) FirstPhone = phone;
      else
      {
        old->next   = phone;
        phone->prev = old;
      }
    }

    LastPhone = phone;
  }

  return true; 		// We're optimists :-)
}


void DevData::Save(KConfig *kc, uint accindex, ushort devindex, bool master)
{
  char       buffer[32];
  ushort     phcnt = 0;
  PhoneData  *phone;

  if (master) sprintf(buffer, "Account%i/Master", accindex);
  else        sprintf(buffer, "Account%i/Slave%i", accindex, devindex);

  kc->setGroup(buffer);
  kc->writeEntry("HupTimeOut", HupTimeout);
  kc->writeEntry("DialAttempts", (int) DialAttempts);

  if (!master)
  {
    kc->writeEntry("Identifier", Name);
    kc->writeEntry("Delay", Delay);
  }

  kc->writeEntry("Encapsulation", (int) Encaps);
  kc->writeEntry("Layer2", (int) Layer2);
  kc->writeEntry("Layer3", (int) Layer3);

  phone = FirstPhone;

  while (phone != (PhoneData *) 0L)
  {
    sprintf(buffer, "Phone%i", phcnt++);
    kc->writeEntry(buffer, phone->number);
    phone = phone->next;
  }

  kc->writeEntry("NumPhone", (int) phcnt);
}


AccData::AccData() : cryptbyte(0x7c)
{
  prev       = (AccData *) 0L;
  next       = (AccData *) 0L;
  FirstSlave = (DevData *) 0L;
  LastSlave  = (DevData *) 0L;
  FirstDNS   = (DNSData *) 0L;
  LastDNS    = (DNSData *) 0L;

  providername = "";
  device       = 0;
  ipdynamic    = true;
  iplocaddress = "0.0.0.0";
  ipremaddress = "0.0.0.0";
  subnetmask   = "0.0.0.0";
  domain       = "";
  UsePAP       = true;
  UseCHAP      = false;
  UseNONE      = false;
  username     = "";
  password     = "";

  // Accounting

  users.clear();
  isAccountEnabled = true;

  // Callback parameters

  callback     = false;
  strip0       = true;
  ingoingphone = "";
  cbinit       = true;
  huptime      = 0;
  cbhangup     = false;
  cbtime       = 0;

  // Additional options

  securemode      = true;

  vjcomp	  = false;
  vjconn          = false;
  adrctrl         = false;
  protfld         = false;
  ipcpaccloc      = false;
  ipcpaccrem      = false;

  changed  = false;
}


void AccData::Backup()
{
  MasterDevice.Backup();
  tmp_providername     = providername.copy();
  tmp_device           = device;
  tmp_ipdynamic        = ipdynamic;
  tmp_iplocaddress     = iplocaddress.copy();
  tmp_ipremaddress     = ipremaddress.copy();
  tmp_subnetmask       = subnetmask.copy();
  tmp_domain           = domain.copy();
  tmp_UsePAP           = UsePAP;
  tmp_UseCHAP          = UseCHAP;
  tmp_UseNONE 	       = UseNONE;
  tmp_username         = username.copy();
  tmp_password         = password.copy();
  tmp_callback         = callback;
  tmp_strip0           = strip0;
  tmp_ingoingphone     = ingoingphone;
  tmp_cbinit           = cbinit;
  tmp_huptime          = huptime;
  tmp_cbhangup	       = cbhangup;
  tmp_cbtime           = cbtime;
  tmp_securemode       = securemode;
  tmp_vjcomp	       = vjcomp;
  tmp_vjconn           = vjconn;
  tmp_adrctrl          = adrctrl;
  tmp_protfld          = protfld;
  tmp_ipcpaccloc       = ipcpaccloc;
  tmp_ipcpaccrem       = ipcpaccrem;
  tmp_users            = users;
  tmp_isAccountEnabled = isAccountEnabled;
}


void AccData::Restore()
{
  MasterDevice.Restore();
  providername     = tmp_providername.copy();
  device           = tmp_device;
  ipdynamic        = tmp_ipdynamic;
  iplocaddress     = tmp_iplocaddress.copy();
  ipremaddress     = tmp_ipremaddress.copy();
  subnetmask       = tmp_subnetmask.copy();
  domain           = tmp_domain.copy();
  UsePAP           = tmp_UsePAP;
  UseCHAP          = tmp_UseCHAP;
  UseNONE 	   = tmp_UseNONE;
  username         = tmp_username.copy();
  password         = tmp_password.copy();
  callback         = tmp_callback;
  strip0           = tmp_strip0;
  ingoingphone     = tmp_ingoingphone;
  cbinit           = tmp_cbinit;
  huptime          = tmp_huptime;
  cbhangup         = tmp_cbhangup;
  cbtime           = tmp_cbtime;
  securemode       = tmp_securemode;
  vjcomp	   = tmp_vjcomp;
  vjconn           = tmp_vjconn;
  adrctrl          = tmp_adrctrl;
  protfld          = tmp_protfld;
  ipcpaccloc       = tmp_ipcpaccloc;
  ipcpaccrem       = tmp_ipcpaccrem;
  users            = tmp_users;
  isAccountEnabled = tmp_isAccountEnabled;

  changed          = false; // cancelled configuration, so nothing changed
}


bool AccData::Load(KConfig *kc, uint index)
{
  char     AccGroup[16], buffer[16];
  ushort   dnscnt, devcnt;
  DNSData  *dns = (DNSData *) 0L, *old;
  DevData  *dev = (DevData *) 0L, *olddev;
  bool     DevLoadSuccess = true;
  QString  un, pw;

  printf("kISDN: Load account #%i\n", index);

  sprintf(AccGroup, "Account%i", index);

  kc->setGroup(AccGroup);
  providername = kc->readEntry("Provider", i18n("(unknown)"));
  device       = kc->readNumEntry("Device", 0);

  ipdynamic    = (kc->readEntry("AssignType") == "dynamic");

  iplocaddress = kc->readEntry("LocalIPAddress", "");
  ipremaddress = kc->readEntry("RemoteIPAddress", "");
  subnetmask   = kc->readEntry("SubNetMask", "");
  domain       = kc->readEntry("Domain", "");

  UsePAP   = (kc->readEntry("AuthType") == "pap");
  UseCHAP  = (kc->readEntry("AuthType") == "chap");
  UseNONE  = !UsePAP && !UseCHAP;

  un = kc->readEntry("UserName", "");
  pw = kc->readEntry("Password", "");
  			
  // username = fromHexString(cryptbyte, un.data());
  username = kc->readEntry("UserName", "");
  password = fromHexString(cryptbyte, pw.data());

  dnscnt = kc->readNumEntry("NumDNS", 0);

  if (dnscnt > 0)
  {
    for (ushort i = 0; i < dnscnt; i++)
    {
      old = dns;
      dns = new DNSData();
      sprintf(buffer, "DNS%i", i);
      dns->ipaddress = kc->readEntry(buffer, "0.0.0.0");

      if (i == 0) FirstDNS = dns;
      else
      {
        old->next = dns;
        dns->prev = old;
      }
    }
    LastDNS = dns;
  }

  MasterDevice.Load(kc, index, 0, true);

  kc->setGroup(AccGroup);
  devcnt = kc->readNumEntry("NumSlaves", 0);

  if (devcnt > 0)
  {
    printf("We've got %i slaves to load\n", devcnt);

    for (uint i = 0; (i < devcnt) && DevLoadSuccess; i++)
    {
      olddev = dev;
      dev    = new DevData();
      DevLoadSuccess = DevLoadSuccess && dev->Load(kc, index, i, false);

      if (i == 0) FirstSlave = dev;
      else
      {
        olddev->next = dev;
        dev->prev    = olddev;
      }
    }

    LastSlave = dev;
  }

  // account enabled/disabled?

  isAccountEnabled = ( kc->readEntry("AccountEnabled") == "yes" );

  // load all the users who can use this account

  users.clear();
  uint usersCount = kc->readUnsignedNumEntry("NumberOfUsers");

  QString tmp;

  for (uint cnt = 0; (cnt < usersCount); cnt++)
  {
    tmp.sprintf("User_%i", cnt);
    users.append(kc->readEntry(tmp));
  }

  // Callback parameters

  callback     = (kc->readEntry("UseCallBack") == "yes");
  strip0       = (kc->readEntry("StripZeroes") == "yes");
  ingoingphone = kc->readEntry("IngoingPhone", "");
  cbinit       = (kc->readEntry("CBInit") == "yes");
  cbhangup     = (kc->readEntry("CBHangup") == "yes");

  huptime = kc->readNumEntry("CBHupTime", 0);
  cbtime = kc->readNumEntry("CBCallBackTime", 0);

  // Additional options

  securemode      = (kc->readEntry("SecureMode") == "on");

  vjcomp          = (kc->readEntry("DisVJCompression") == "yes");
  vjconn          = (kc->readEntry("DisVJConnIDOption") == "yes");
  adrctrl         = (kc->readEntry("DisAdrFieldCompression") == "yes");
  protfld         = (kc->readEntry("DiSProtFieldCompression") == "yes");
  ipcpaccloc      = (kc->readEntry("IPCPAcceptLocal") == "yes");
  ipcpaccrem      = (kc->readEntry("IPCPAcceptRemote") == "yes");

  return DevLoadSuccess;	
}


void AccData::Save(KConfig *kc, uint index, bool superUser)
{
  char     AccGroup[16], buffer[16];
  ushort   dnscnt = 0, devcnt = 0;
  DNSData  *dns;
  DevData  *dev;
  QString  un, pw;
  QString  tmp;

  sprintf(AccGroup, "Account%i", index);

  kc->setGroup(AccGroup);
  kc->writeEntry("Provider", providername);
  kc->writeEntry("Device", (int) device);
  kc->writeEntry("AssignType", ipdynamic ? "dynamic" : "static");
  kc->writeEntry("LocalIPAddress", iplocaddress);
  kc->writeEntry("RemoteIPAddress", ipremaddress);
  kc->writeEntry("SubNetMask", subnetmask);
  kc->writeEntry("Domain", domain);

  if ( UsePAP ) tmp = "pap";
  else if ( UseCHAP ) tmp = "chap";
  else tmp = "none";
  kc->writeEntry("AuthType", tmp.data());

  un = toHexString(cryptbyte, username.data());
  pw = toHexString(cryptbyte, password.data());

  // kc->writeEntry("UserName", un);		
  kc->writeEntry("UserName", username);		
  kc->writeEntry("Password", pw);			

  dns = FirstDNS;

  while (dns != (DNSData *) 0L)
  {
    sprintf(buffer, "DNS%i", dnscnt++);
    kc->writeEntry(buffer, dns->ipaddress);
    dns = dns->next;
  }

  kc->writeEntry("NumDNS", (int) dnscnt);

  MasterDevice.Save(kc, index, 0, true);

  dev = FirstSlave;

  while(dev != (DevData *) 0L)
  {
    dev->Save(kc, index, devcnt++, false);
    dev = dev->next;
  }

  kc->setGroup(AccGroup);
  kc->writeEntry("NumSlaves", (int) devcnt);

  // saving whether account is enabled or not

  kc->writeEntry("AccountEnabled", isAccountEnabled ? "yes" : "no" );

  // now save all the Users
  // the usernames should only appear in the global
  // $KDEDIR/share/config/kcmkisdnrc, not in every user's kisdnrc.

  if (superUser)
  {
    QString tmp;
    uint cnt = users.count();

    kc->writeEntry("NumberOfUsers", cnt);

    for (uint idx = 0; (idx < cnt); idx++)
    {
      tmp.sprintf("User_%i", idx);
      kc->writeEntry(tmp, users.at(idx));
    }
  }

  // Callback parameters

  kc->writeEntry("UseCallBack", callback ? "yes" : "no");
  kc->writeEntry("StripZeroes", strip0 ? "yes" : "no");
  kc->writeEntry("IngoingPhone", ingoingphone);
  kc->writeEntry("CBInit", cbinit ? "yes" : "no");
  kc->writeEntry("CBHupTime", huptime);
  kc->writeEntry("CBHangup", cbhangup ? "yes" : "no");
  kc->writeEntry("CBCallBackTime", cbtime);

  // Additional options

  kc->writeEntry("SecureMode", securemode ? "on" : "off" );

  kc->writeEntry("DisVJCompression", vjcomp ? "yes" : "no" );
  kc->writeEntry("DisVJConnIDOption", vjconn ? "yes" : "no" );
  kc->writeEntry("DisAdrFieldCompression", adrctrl ? "yes" : "no" );
  kc->writeEntry("DiSProtFieldCompression", protfld ? "yes" : "no" );
  kc->writeEntry("IPCPAcceptLocal", ipcpaccloc ? "yes" : "no" );
  kc->writeEntry("IPCPAcceptRemote", ipcpaccrem ? "yes" : "no" );

  kc->writeEntry("AccountHasChanged", changed ? "yes" : "no" );
}


QString  AccData::toHexByte(char c)
{
  QString  hexbyte = "";
  QString  hextab  = "0123456789ABCDEF";

  hexbyte += hextab.mid((c & 0xf0) >> 4, 1);
  hexbyte += hextab.mid(c & 0x0f, 1);

  return hexbyte;
}


char  AccData::fromHexByte(const char *s)
{
  uint  n = 0;
  char  c;

  for (ushort i = 0; i < 2; i++)
  {
    n *= 16;
    c  = toupper(s[i]);

    if (c < 'A') n += (uint) (c-'0');
    else         n += (10+(uint) (c-'A'));
  }

  return n;
}


QString  AccData::toHexString(int c, const char *s)
{
  QString  hexstr = "";

  while (*s)
  {
    hexstr += toHexByte(*s^c);
    s++;
  }

  return hexstr;
}


QString  AccData::fromHexString(int c, const char *s)
{
  QString  word = "";

  while (*s)
  {
    word += (fromHexByte(s)^cryptbyte);
    s    += 2;
  }

  return word;
}


AdvData::AdvData()
{
  bsdcomp    = false;
  incdebug   = false;
  dbglevel   = 0;
  mtu        = 0;
  mru        = 0;
}


void AdvData::Backup()
{
  tmp_bsdcomp    = bsdcomp;
  tmp_incdebug   = incdebug;
  tmp_dbglevel   = dbglevel;
  tmp_mru        = mru;
  tmp_mtu        = mtu;
}


void AdvData::Restore()
{
  bsdcomp    = tmp_bsdcomp;
  incdebug   = tmp_incdebug;
  dbglevel   = tmp_dbglevel;
  mru        = tmp_mru;
  mtu        = tmp_mtu;
}


bool AdvData::Load(KConfig *kc)
{
  kc->setGroup("AdvancedIPPPDOptions");

  bsdcomp  = (kc->readEntry("DisableBSDCompression") == "yes" );
  incdebug = (kc->readEntry("IncreaseDebugLevel") == "yes" );

  dbglevel = kc->readNumEntry("KernelDebugLevel", 0);
  mru      = kc->readNumEntry("MaxReceiveUnit", 0);
  mtu      = kc->readNumEntry("MaxTransferUnit", 0);

  return true;
}


void AdvData::Save(KConfig *kc)
{
  kc->setGroup("AdvancedIPPPDOptions");

  kc->writeEntry("DisableBSDCompression", bsdcomp ? "yes" : "no");
  kc->writeEntry("IncreaseDebugLevel", incdebug ? "yes" : "no");
  kc->writeEntry("KernelDebugLevel", (int) dbglevel);
  kc->writeEntry("MaxReceiveUnit", mru);
  kc->writeEntry("MaxTransferUnit", mtu);
}


GenData::GenData()
{
  ipppdpath    = "/sbin/ipppd";
  prefix       = "";
  msnData      = "";
  loadasmodule = false;
  explicitEnable      = false;
  modprobepath = "/sbin/modprobe";
  adapter      = 4;
  iobase0      = "0x0160";
  iobase1      = "";
  membase      = "";
  interrupt    = 5;
  protocol     = 1;			// Euro DSS1
  disableIpUpDown = true;
}


bool GenData::Load(KConfig *kc)
{
  kc->setGroup("General");

  ipppdpath = kc->readEntry("IpppdPath", "/sbin/ipppd");
  prefix    = kc->readEntry("Prefix", "");
  msnData   = kc->readEntry("MsnForDataConnections", "");
  loadasmodule = (kc->readEntry("LoadDriverAsModule") == "yes");
  explicitEnable = (kc->readEntry("ExplicitelyEnableInterface") == "yes");
  disableIpUpDown = (kc->readEntry( "OverrideIpUpDown") == "yes" );

  if (loadasmodule)
  {
    modprobepath = kc->readEntry("ModprobePath", "/sbin/modprobe");
    adapter      = kc->readNumEntry("Adapter", 4);
    iobase0      = kc->readEntry("IOBase0", "");
    iobase1      = kc->readEntry("IOBase1", "");
    interrupt    = kc->readNumEntry("Interrupt", 5);
    membase      = kc->readEntry("MemBase", "");
    protocol     = kc->readNumEntry("Protocol", 1);
  }

  Advanced.Load(kc);
  return true;
}


void GenData::Save(KConfig *kc)
{
  kc->setGroup("General");
  kc->writeEntry("IpppdPath", ipppdpath);
  kc->writeEntry("Prefix", prefix);
  kc->writeEntry("MsnForDataConnections", msnData);
  kc->writeEntry("LoadDriverAsModule", loadasmodule ? "yes" : "no");
  kc->writeEntry("ExplicitelyEnableInterface", explicitEnable ? "yes" : "no");
  kc->writeEntry( "OverrideIpUpDown", disableIpUpDown ? "yes" : "no" );

  if (loadasmodule)
  {
    kc->writeEntry("ModprobePath", modprobepath);
    kc->writeEntry("Adapter", (int) adapter);
    kc->writeEntry("IOBase0", iobase0);
    kc->writeEntry("IOBase1", iobase1);
    kc->writeEntry("Interrupt", (int) interrupt);
    kc->writeEntry("MemBase", membase);
    kc->writeEntry("Protocol", (int) protocol);
  }

  Advanced.Save(kc);
}


void GenData::Backup()
{
  tmp_ipppdpath	     = ipppdpath.data();
  tmp_prefix         = prefix.data();
  tmp_msnData        = msnData.data();
  tmp_loadasmodule   = loadasmodule;
  tmp_modprobepath   = modprobepath.data();
  tmp_adapter        = adapter;
  tmp_protocol       = protocol;
  tmp_membase        = membase.data();
  tmp_iobase0        = iobase0.data();
  tmp_iobase1        = iobase1.data();
  tmp_interrupt      = interrupt;
  tmp_explicitEnable = explicitEnable;
  tmp_disableIpUpDown = disableIpUpDown;

  tmp_Advanced.bsdcomp  = Advanced.bsdcomp;
  tmp_Advanced.incdebug = Advanced.incdebug;
  tmp_Advanced.dbglevel = Advanced.dbglevel;
}


void GenData::Restore()
{
  ipppdpath      = tmp_ipppdpath.data();
  prefix         = tmp_prefix.data();
  msnData        = tmp_msnData.data();
  loadasmodule   = tmp_loadasmodule;
  modprobepath   = tmp_modprobepath.data();
  adapter        = tmp_adapter;
  protocol       = tmp_protocol;
  membase        = tmp_membase.data();
  iobase0        = tmp_iobase0.data();
  iobase1        = tmp_iobase1.data();
  interrupt      = tmp_interrupt;
  explicitEnable = tmp_explicitEnable;
  disableIpUpDown = tmp_disableIpUpDown;

  Advanced.bsdcomp  = tmp_Advanced.bsdcomp;
  Advanced.incdebug = tmp_Advanced.incdebug;
  Advanced.dbglevel = tmp_Advanced.dbglevel;
}

// a class that just handles data only visible for Root (like the users list)
RootData::RootData()
{
}

bool RootData::Load( KConfig *kc )
{
  kc->setGroup( "Root Data" );
  (void) kc->readListEntry( "All Users", allUsersList );

  return true;
}

void RootData::Save( KConfig *kc )
{
  kc->setGroup( "Root Data" );
  kc->writeEntry( "All Users", allUsersList );
}


kISDNData::kISDNData()
{
  General      = new GenData();
  rootData     = new RootData();

  FirstAccount = (AccData *) 0L;
  LastAccount  = (AccData *) 0L;
  AccLoaded    = 0;

  ISPListChanged = false;
}


kISDNData::~kISDNData()
{
  AccData *Actual = FirstAccount, *ToDestroy;

  delete General;
  delete rootData;

  if (Actual != (AccData *) 0L)
  {
    do
    {
      ToDestroy = Actual;
      Actual    = Actual->next;
      delete ToDestroy;
    } while (Actual != (AccData *) 0L);
  }
}


bool kISDNData::Load()
{
  KConfig *kc = new KConfig(kapp->kde_configdir() + "/kcmkisdnrc");
  kc->setGroup("Configuration");

  rcRevision = kc->readEntry("Revision", "0.0.0.0");
  if ( rcRevision != KISDNVERSION )
  {
    KisdnCompat compat;
    compat.ensureCompatibility( kc );
  }

  bool     GenLoadSuccess, AccLoadSuccess = true, ScanLoadSuccess = true;
  AccData  *acc = (AccData *) 0L, *old;

  GenLoadSuccess  = General->Load(kc);
  rootData->Load( kc );

  kc->setGroup("General");
  NumAcc = kc->readNumEntry("NumAccounts", 0);

  if (NumAcc > 0)
  {
    for (uint i = 0; (i < NumAcc) && AccLoadSuccess; i++)
    {
      old = acc;
      acc = new AccData();
      AccLoadSuccess = AccLoadSuccess && acc->Load(kc, i);

      if (i == 0) FirstAccount = acc;
      else
      {
        old->next = acc;
        acc->prev = old;
      }

      if (AccLoadSuccess) AccLoaded++;
    }
    LastAccount = acc;
  }

  return (GenLoadSuccess && ScanLoadSuccess && AccLoadSuccess);
}


void kISDNData::Save()
{
  KConfig *kc = new KConfig(kapp->kde_configdir() + "/kcmkisdnrc");
  AccData  *acc;

  kc->writeEntry("Revision", KISDNVERSION);

  General->Save(kc);
  rootData->Save( kc );

  NumAcc = 0;
  acc    = FirstAccount;

  while(acc != (AccData *) 0L)
  {
    acc->Save(kc, NumAcc++, true);  // save the users, too (kcmkisdnrc!)
    acc = acc->next;
  }

  kc->setGroup("General");
  kc->writeEntry("NumAccounts", NumAcc);
  kc->sync();

  delete kc;
}


// loop thru all accounts and all users and save the accounts
// in the users' kisdnrc
void kISDNData::SaveUsers()
{
  if ( NumAcc <= 0 ) // if all accounts have been deleted, read all users'
  {                  // kisdnrc and write "NumAccounts = 0" into it
    QString file;
    KConfig *kc = 0L;;

    ::message("removing accounts from kisdnrcs");

    QStrList &uList = rootData->allUsersList;
    uList.setAutoDelete( true );

    for ( file = uList.first(); !(file.isEmpty() || file.isNull());
          file = uList.next() )
    {
      kc = new KConfig( (file + "/.kde/share/config/kisdnrc" ) );
      kc->setGroup( "General" );
      kc->writeEntry( "NumAccounts", 0 );
      General->Save(kc);
      kc->sync();

      delete kc;
    }

    // now clear and save the usersList
    uList.clear();
    kc = new KConfig(kapp->kde_configdir() + "/kcmkisdnrc");
    rootData->Save( kc );
    delete kc;

    return;
  }
    
  if ( !FirstAccount ) {
    ::message("no accounts configured");
    return;
  }
  
  QString user, configfile;

  AccData *acc = new AccData( *FirstAccount ); // operate on copy, not original
  AccData *tmpAcc = 0L;
  KConfig *kc = 0L;
  bool changed;

  // Loop thru all configured accounts

  while ( acc != (AccData *) 0L )
  {
    // Loop thru all users in the account

    while ( user = acc->users.first() ) // all items are deleted after saving,
    {                                   // so we always take the first item

      // We found a user in current userlist. Loop thru all other accounts,
      // find him and save them in this user's kisdnrc
      NumAcc = 0;
      changed = false;

      configfile = user + "/.kde/share/config/kisdnrc";
      kc = new KConfig( configfile.data() );

      tmpAcc = acc;

      do
      {
        while ( int idx = tmpAcc->users.find(user) != -1 ) // user found in list
        {
          idx--; // Qt-Bug? find() always returns one index larger than it shld.
	  if ( tmpAcc->changed )                // only save if necessary
            tmpAcc->Save( kc, NumAcc, false );  // save account
          NumAcc++;
          tmpAcc->users.remove( idx );          // remove user from userlist now
	  changed |= tmpAcc->changed;
        }

        tmpAcc = tmpAcc->next;
      } while ( tmpAcc != (AccData *) 0L );
	
      // finished looping thru all accounts of one user

      General->Save(kc);

      if ( changed || ISPListChanged )
      {
        kc->setGroup("General");
        kc->writeEntry("NumAccounts", NumAcc);
      }

      kc->sync();
      delete kc;

      ::setFilePermissionUserOnly( configfile.data() );
    }

    acc = acc->next;
  }

  delete acc;
}


void kISDNData::Backup()
{
  General->Backup();

  AccData  *acc = FirstAccount;

  while (acc != (AccData *) 0L)
  {
    acc->Backup();
    acc = acc->next;
  }
}


void kISDNData::Restore()
{
  General->Restore();

  AccData  *acc = FirstAccount;

  while (acc != (AccData *) 0L)
  {
    acc->Restore();
    acc = acc->next;
  }
}
