/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include "accdlg.h"


MoreWidget::MoreWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  AccData         *acc      = ISDNData.Temp;
  KIconLoader     *loader   = kapp->getIconLoader();
  static QPixmap  addon_xpm = loader->loadIcon("addon.xpm");

  GBox = new QGroupBox(this);
  GBox->setTitle(i18n("Additional Options"));
  GBox->setGeometry(10, 8, 328, 316);
  
  pmAdd = new QLabel(this);
  pmAdd->setPixmap(addon_xpm);
  pmAdd->setGeometry(292, 26, 31, 31);
  
  securecheck = new QCheckBox(i18n("Secure mode for incoming calls"), this);
  securecheck->adjustSize();
  securecheck->setGeometry(30, 44, securecheck->width(), securecheck->height());
  securecheck->setChecked(acc->securemode);
  
  IPPPDBox = new QGroupBox(this);
  IPPPDBox->setTitle("ipppd");
  IPPPDBox->setGeometry(20, 110, 308, 166);
  
  vjcheck = new QCheckBox(i18n("Disable VJ compression"), this);
  vjcheck->adjustSize();
  vjcheck->setGeometry(40, 140, vjcheck->width(), vjcheck->height());
  vjcheck->setChecked(acc->vjcomp);

  vjconncheck = new QCheckBox(i18n("Disable VJ connection ID option"), this);
  vjconncheck->adjustSize();
  vjconncheck->setGeometry(40, 160, vjconncheck->width(), vjconncheck->height());
  vjconncheck->setChecked(acc->vjconn);

  adrctrlcheck = new QCheckBox(i18n("Disable address/control compression"), this);
  adrctrlcheck->adjustSize();
  adrctrlcheck->setGeometry(40, 180, adrctrlcheck->width(), adrctrlcheck->height());
  adrctrlcheck->setChecked(acc->adrctrl);

  protfldcheck = new QCheckBox(i18n("Disable protocol field compression"), this);
  protfldcheck->adjustSize();
  protfldcheck->setGeometry(40, 200, protfldcheck->width(), protfldcheck->height());
  protfldcheck->setChecked(acc->protfld);
  
  ipcpaccloccheck = new QCheckBox(i18n("Accept local IP from peer"), this);
  ipcpaccloccheck->adjustSize();
  ipcpaccloccheck->setGeometry(40, 220, ipcpaccloccheck->width(), ipcpaccloccheck->height());
  ipcpaccloccheck->setChecked(acc->ipcpaccloc);

  ipcpaccremcheck = new QCheckBox(i18n("Accept remote IP from peer"), this);
  ipcpaccremcheck->adjustSize();
  ipcpaccremcheck->setGeometry(40, 240, ipcpaccremcheck->width(), ipcpaccremcheck->height());
  ipcpaccremcheck->setChecked(acc->ipcpaccrem);
}


void MoreWidget::resizeEvent(QResizeEvent *)
{
  ushort  margin = 10;
  uint    w      = width();
  uint    h      = height();

  GBox->resize(w-2*margin, h-2*margin);
  pmAdd->move(w-2*margin-pmAdd->width()-2, pmAdd->y()+2);
  IPPPDBox->resize(w-4*margin, h-4*margin-94);
}
