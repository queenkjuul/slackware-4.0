/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: ipdisplay.h,v 1.2 1998/11/21 12:35:15 twesthei Exp $
//
// $Log: ipdisplay.h,v $
// Revision 1.2  1998/11/21 12:35:15  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
 
 
#ifndef __IPDISPLAY_H
#define __IPDISPLAY_H

#include <qframe.h>
#include <qlabel.h>
#include <qlined.h>
#include <qpixmap.h>
#include <qpushbt.h>

#include "mtxdisplay.h"
#include "netinfo.h"


class IPDisplay : public QWidget
{
  Q_OBJECT
  
  private:
  
    QFrame        *frame;
    QLabel        *localip, *remoteip, *localbox, *remotebox;
    QPixmap       pmcha, pmchb;
    QPushButton   *chasel, *chbsel;
    ISDNInfo      *isdninfo;
    MatrixFont    *mtxfont;
    ushort        channelshown;
    MatrixPixmap  *mtxlocalip, *mtxremoteip;
    char          ipbuf[16], ip0[16];    
    
    char  *formatIP(char *);
    void  showChannel(ushort);
    
  private slots:
  
    void slotChAClicked();
    void slotChBClicked();

  public:
  
    IPDisplay(ISDNInfo *, MatrixFont *, QWidget *parent = 0, const char *name = 0);
    ~IPDisplay() {}
    
    void refreshIPs();
  
  public slots:
  
    void slotNewIPLocalA(char *);
    void slotNewIPRemoteA(char *);
    void slotNewIPLocalB(char *);
    void slotNewIPRemoteB(char *);
};

#endif
