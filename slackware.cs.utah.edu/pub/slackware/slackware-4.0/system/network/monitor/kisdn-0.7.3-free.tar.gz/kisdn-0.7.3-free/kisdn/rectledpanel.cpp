/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: rectledpanel.cpp,v 1.2 1998/11/21 12:34:57 twesthei Exp $
//
// $Log: rectledpanel.cpp,v $
// Revision 1.2  1998/11/21 12:34:57  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include "rectledpanel.h"


RectLEDPanel::RectLEDPanel(QWidget *parent, const char *name) : QWidget(parent, name)
{
  setFixedSize(98, 10);
  
  QColor  darkred    = QColor(0x70, 0x00, 0x00);
  QColor  lightred   = QColor(0xff, 0x24, 0x30);
  QColor  darkgreen  = QColor(0x00, 0x60, 0x00);
  QColor  lightgreen = QColor(0x40, 0xda, 0x40);
  
  _LED[0] = new RectLED(darkgreen, lightgreen, this);
  _LED[1] = new RectLED(darkred,   lightred,   this);
  _LED[2] = new RectLED(darkgreen, lightgreen, this);
  _LED[3] = new RectLED(darkred,   lightred,   this);
    
  _LED[0]->move(0,  0);
  _LED[1]->move(25, 0);
  _LED[2]->move(51, 0);
  _LED[3]->move(76, 0);  
}


/* 
 * Public methods
 *****************/
 
void  RectLEDPanel::setHiSaxState(bool b)
{
  _LED[0]->setState(b);
  _LED[1]->setState(!b);
}


void  RectLEDPanel::setVoiceState(bool b)
{
  _LED[2]->setState(b);
  _LED[3]->setState(!b);
}



