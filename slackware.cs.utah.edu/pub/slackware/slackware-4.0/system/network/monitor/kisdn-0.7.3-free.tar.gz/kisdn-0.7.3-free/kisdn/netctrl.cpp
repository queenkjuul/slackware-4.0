/*  
 *  This file is part of kISDN, Copyright (C) 1998, 1999 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 *  Kernel 2.2 experimental version, T. Westheider Jan 23rd, 1999
 *
 *****************************************************************/
 
// $Id: netctrl.cpp,v 1.8 1999/01/23 11:38:26 twesthei Exp $
//
// $Log: netctrl.cpp,v $
// Revision 1.8  1999/01/23 11:38:26  twesthei
// Applied changes to network code to make kISDN run on
// 2.2.0pre kernels; the changes should do no harm on 2.0.36
// machines, so it's going straight into CVS
//
// Revision 1.7  1998/12/20 22:05:30  twesthei
// Still profiling dual mode
//
// Revision 1.6  1998/11/22 14:59:24  twesthei
// One more step in Q.931 interpretation (information
// identifier field)
//
// Revision 1.5  1998/11/21 23:19:43  twesthei
// DoD is working again; it was broken because of upgrading
// to HiSax 3.1 (contained in Kernel 2.0.36)
//
// Revision 1.4  1998/10/20 14:55:12  twesthei
// Implemented 'Explicitly enable interface' option; not
// working yet, since we need recent HiSax headers (will there
// be problems ?)


#include <arpa/inet.h>
#include <asm/types.h>
#include <ctype.h>
#include <stdio.h>

#include <sys/ioctl.h>

#include "general.h"
#include "netctrl.h"


NetCtrl::NetCtrl(ISDNCtrl *ic, ISDNConfig *cfg) : _actiface(""), skfd(-1), isdnconfig(cfg), isdnctrl(ic)
{
  skfd = socket(AF_INET, SOCK_DGRAM, 0);
  
  if (!socketOpen()) ::message("Can't open TCP/IP socket");
}


NetCtrl::~NetCtrl()
{
  if (socketOpen()) close(skfd);
}


/*
 * IP addresses
 ***************/

bool NetCtrl::getIPAddresses(const char *ifname, char *iplocal, char *ipremote)
{
  bool  stat = false;
  
  if (ifGetConfiguration(ifname))
  {
    stat = ((socketAddressToIP(iplocal,  (struct sockaddr_in *) &addr)) &&
            (socketAddressToIP(ipremote, (struct sockaddr_in *) &dstaddr)));
  }
  
  if (!stat)
  {
    strcpy(iplocal,  "0.0.0.0");
    strcpy(ipremote, "0.0.0.0");
  }
  
  return stat;
}


bool NetCtrl::resetIPAddresses(const char *ifname)
{
  return ifPointToPoint(ifname, "1.1.1.1", "1.1.1.1");
}


/*
 * Dial on demand
 *****************/

bool NetCtrl::disableDoD()
{
  isdnctrl->setDialMode(_actiface, ISDNCtrl::MANUAL);		
  
  if (routeHaveDefault(_actiface)) 
  {
    if (routeDelete("0.0.0.0")) 
    {
      ::message("Dial on demand removed");
      isdnconfig->setActiveDoD(false); 
          
      return true;
    }
    else 
    {
      ::message("Dial on demand setup could not be removed");  
      
      return false;
    }
  }
  
  ::message("No defaultroute found");

  return true;
}


bool NetCtrl::enableDoD(AccountData *acc)
{
  char  local[16] = "1.1.1.1", remote[16] = "1.1.1.1";
  
  isdnctrl->setDialMode(_actiface, ISDNCtrl::AUTO);		

  if (routeHaveHost()) return (restoreDoD());
  else 
  {
    if (acc->masterDevice()->protEncaps() != Device::SYNCPPP)
    {
      strncpy(local,  acc->localIP().string().data(),  15);
      strncpy(remote, acc->remoteIP().string().data(), 15);

      local[15]  = '\0';
      remote[15] = '\0';    
    }

    if (ifPointToPoint(_actiface.data(), local, remote) && 
        ifSetFlag(_actiface.data(), (IFF_UP | IFF_RUNNING)))
    {
      if (routeAddInterface(_actiface.data())) 
      {
        ::message("Dial on demand established"); 
	
	isdnconfig->setActiveDoD(true);
	
        return true;
      }
    }
    
    ::message("Dial on demand setup failed");
    
    return false;
  }
}


bool NetCtrl::restoreDoD()
{
  struct route  rtable[MAXROUTES];
  ushort        tind = 0;
  bool          havegw = false;
  
  if (routeReadTable(rtable, MAXROUTES))
  {
    while (strlen(rtable[tind].iface) && (tind < MAXROUTES) && !havegw)
    {
      if (!strcmp(_actiface.data(), rtable[tind].iface) && strcmp("0.0.0.0", rtable[tind].destIP))
      {
        havegw = true;
	
	if (routeAddGateway(rtable[tind].destIP)) return true;
      }
      tind++;
    }
  }
  return false;
}


void NetCtrl::slotDoDDisengage()
{
  if (disableDoD())
  {
    CustomData  *cust = ISDNData.customData();
    
    cust->setDialOnDemand(false);
    emit sigDoDDisengaged();
  }
}


void NetCtrl::slotDoDEngage(AccountData *acc)
{
  if (enableDoD(acc))
  { 
    CustomData *cust = ISDNData.customData();
    
    cust->setDialOnDemand(true);
    emit sigDoDEngaged();
  }
}


/* 
 * Interface handling
 *********************/

bool NetCtrl::ifGetConfiguration(const char *ifname)
{
  struct ifreq  ifr;
  
  cout << PROMPT << "ifconfig " << ifname << endl;
  
  if (socketOpen())
  {
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ); 
    
    if (ioctl(skfd, SIOCGIFADDR, &ifr) < 0) 
    {
      memset((char *) &addr, 0, sizeof(struct sockaddr));
      cout << PROMPT << "SIOCGIFADDR failed in getIfConfig(" << ifname << ")" << endl;
    } 
    else memcpy((char *) &addr, (char *) &ifr.ifr_addr, sizeof(struct sockaddr));
  
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ);  
    
    if (ioctl(skfd, SIOCGIFDSTADDR, &ifr) < 0) 
    {
      memset((char *) &dstaddr, 0, sizeof(struct sockaddr));
      cout << PROMPT << "SIOCGIFDSTADDR failed in getIfConfig(" << ifname << ")" << endl;
    } 
    else memcpy((char *) &dstaddr, (char *) &ifr.ifr_dstaddr, sizeof(struct sockaddr));
    
    return true;
  }
  else ::message("Socket not open in ifGetConfiguration");
  
  return false;
}


bool NetCtrl::ifSetFlag(const char *ifname, short flag)
{
  struct ifreq  ifr;

  if (socketOpen())
  {
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
    
    if (ioctl(skfd, SIOCGIFFLAGS, &ifr) < 0) 
    {
      cout << PROMPT << "SIOCGIFFLAGS failed in ifSetFlag(" << ifname << ")" << endl;
      return false;
    }
    
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
    
    ifr.ifr_flags |= flag;

    if (ioctl(skfd, SIOCSIFFLAGS, &ifr) < 0) 
      cout << PROMPT << "SIOCSIFFLAGS failed in ifSetFlag(" << ifname << ")" << endl;
    else return true;
  } ::message("Socket not open in ifSetFlag");
  
  return false;
}


bool NetCtrl::ifClearFlag(const char *ifname, short flag)
{
  struct ifreq  ifr;

  if (socketOpen())
  {
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
    
    if (ioctl(skfd, SIOCGIFFLAGS, &ifr) < 0)
    {
      cout << PROMPT << "SIOCGIFFLAGS failed in ifClearFlag(" << ifname << ")" << endl;
      return false;
    }
    
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ);

    ifr.ifr_flags &= ~flag;

    if (ioctl(skfd, SIOCSIFFLAGS, &ifr) < 0) 
      cout << PROMPT << "SIOCSIFFLAGS failed in ifClearFlag(" << ifname << ")" << endl;
    else return true;
  } else ::message("Socket not open in ifClearFlag");
  
  return false;
}


bool NetCtrl::ifUp(const char *ifname)
{
  cout << PROMPT << "ifconfig " << ifname << " up" << endl;
  
  return ifSetFlag(ifname, (IFF_UP | IFF_RUNNING));
}


bool NetCtrl::ifDown(const char *ifname)
{
  cout << PROMPT << "ifconfig " << ifname << " down" << endl;
  
  return ifClearFlag(ifname, IFF_UP);
}

 
bool NetCtrl::ifPointToPoint(const char *ifname, char* local, char *remote)
{
  struct ifreq     ifr;
  struct sockaddr  sad;
  
  cout << PROMPT << "ifconfig " << ifname << " " << local << " pointopoint " << remote << endl;

  if (socketOpen())
  {  
    memset((char *) &sad, 0, sizeof(struct sockaddr));
    ipToSocketAddress(local, &sad);
    
    memset((char *) &ifr, 0, sizeof(struct ifreq));
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
    memcpy((char *) &ifr.ifr_addr, (char *) &sad, sizeof(struct sockaddr));
    
    if (ioctl(skfd, SIOCSIFADDR, &ifr) < 0)
    {
      ::message("SIOCSIFADDR failed in ifPointToPoint");
      return false;
    }

    memset((char *) &sad, 0, sizeof(struct sockaddr));
    ipToSocketAddress(remote, &sad);    
    
    memset((char *) &ifr, 0, sizeof(struct ifreq));
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
    memcpy((char *) &ifr.ifr_dstaddr, (char *) &sad, sizeof(struct sockaddr));
    
    if (ioctl(skfd, SIOCSIFDSTADDR, &ifr) < 0)
    {
      ::message("SIOCSIFDSTADDR failed in ifPointToPoint");
      return false;
    }

    return ifSetFlag(ifname, IFF_POINTOPOINT);
  } else ::message("Socket not open in ifPointToPoint");
  
  return false;
}


/*
 * Routing 
 **********/

bool NetCtrl::routeReadTable(struct route *rtable, uint tablen)
{
  FILE          *fhd;
  uint          tabindex = 0;
  char          buf[256], dip[10], gip[10], mask[10], iface[16], drop[8];
  struct route  *rt;
    
  memset(rtable, 0, tablen*sizeof(struct route));  
    
  fhd = fopen("/proc/net/route", "r");
  
  if (fhd)
  {
    fgets(buf, 255, fhd);			// Drop the title
    
    while (!feof(fhd) && (tabindex < tablen))
    {
      memset(buf, 0, sizeof(buf));
      fgets(buf, 255, fhd);
      
      if (strlen(buf))
      {
        sscanf(buf, "%s%s%s%s%s%s%s%s", iface, dip, gip, drop, drop, drop, drop, mask);
	
	rt = &(rtable[tabindex++]);
	
	strcpy(rt->iface,  iface);
        strcpy(rt->destIP, hexToQuattedDot(dip,  buf));
	strcpy(rt->gateIP, hexToQuattedDot(gip,  buf));
	strcpy(rt->mask,   hexToQuattedDot(mask, buf));
      }
    }
    
    if (!feof(fhd) && (tabindex >= tablen))
    {
      ::message("Routing table exceeds buffer length");
      
      fclose(fhd);
      return false;
    } 
    else 
    {
      fclose(fhd);
      return true;
    }
  }
  else 
  {
    ::message("Can't open /proc/net/route");
    
    return false;
  }
}


bool NetCtrl::routeHaveDefault(const char *ifname)
{
  struct route  rtable[MAXROUTES];
  ushort        tind = 0;
  
  if (routeReadTable(rtable, MAXROUTES))
  {
    while (strlen(rtable[tind].iface))
    {
      if (!strcmp("0.0.0.0", rtable[tind].destIP) && !strcmp(ifname, rtable[tind].iface)) return true;
      tind++;
    }
  }
  
  return false;
}


bool NetCtrl::routeHaveHost()  
{
  struct route  rtable[MAXROUTES];
  ushort        tind = 0;
  
  if (routeReadTable(rtable, MAXROUTES))
  {
    while (strlen(rtable[tind].iface) && (tind < MAXROUTES))
    {
      if (!strcmp(_actiface.data(), rtable[tind].iface) && strcmp("0.0.0.0", rtable[tind].destIP)) 
        return true;
	
      tind++;
    }
  }
  return false;
}


bool NetCtrl::routeDelete(char *addr) 
{
  struct sockaddr  sad;
  struct rtentry   rte;
  
  cout << PROMPT << "route del " << addr << endl;
  
  if (routeExists(addr))
  {
    memset((char *) &sad, 0, sizeof(struct sockaddr));
    
    if (ipToSocketAddress(addr, &sad))
    { 
      if (socketOpen())
      {      
        memset((char *) &rte, 0, sizeof(struct rtentry));	
	memcpy((char *) &rte.rt_dst, (char *) &sad, sizeof(struct sockaddr));
        
	rte.rt_flags = (RTF_UP | RTF_HOST);
	
	if (!strcmp(addr, "default") || !strcmp(addr, "0.0.0.0")) rte.rt_flags &= ~RTF_HOST;
	
	if (ioctl(skfd, SIOCDELRT, &rte) < 0) ::message("SIOCDELRT failed in routeDel");
	else return true;
      }
      else ::message("Socket not open in routeDelete");
    }
  }
  else ::message("No such route entry");
  
  return false;      
}


bool NetCtrl::routeExists(char *addr)
{
  struct route  rtable[MAXROUTES];
  ushort        tind = 0;
  
  if (routeReadTable(rtable, MAXROUTES))
  {
    while (strlen(rtable[tind].iface) && (tind < MAXROUTES))
    {
      if (!strcmp(addr, rtable[tind++].destIP)) return true;
    }
  }
  
  return false;  
}


bool NetCtrl::routeDelInterface(char *ifname)
{
  struct route  rtable[MAXROUTES];
  ushort        tind = 0;

  if (routeReadTable(rtable, MAXROUTES))
  {
    while (((bool) strlen(rtable[tind].iface)) && (tind < MAXROUTES))
    {
      if (!(bool) strcmp(ifname, rtable[tind].iface)) routeDelete(rtable[tind].destIP);
      
      tind++;
    }
    
    return true;
  }
  else return false;
}


bool NetCtrl::routeAddInterface(char *ifname)
{
  struct rtentry  rte;

  cout << PROMPT << "route add default dev " << ifname <<endl;
  
  memset((char *) &rte, 0, sizeof(struct rtentry));
  
  ipToSocketAddress("default", &(rte.rt_dst));
  
  rte.rt_flags = RTF_UP;
  rte.rt_dev   = ifname;
  
  if (socketOpen())
  {
    if (ioctl(skfd, SIOCADDRT, &rte) < 0) ::message("SIOCADDRT failed in routeAddInterface"); 
    else return true;
  } ::message("Socket not open in routeAddInterface");
  
  return false;
}
    
    
bool NetCtrl::routeAddHost(char *remote, char *ifname)
{
  struct rtentry  rte;

  cout << PROMPT << "route add -host " << remote << " dev " << ifname << endl;
  
  memset((char *) &rte, 0, sizeof(struct rtentry));
  
  ipToSocketAddress(remote, &(rte.rt_dst));
  
  rte.rt_flags = (RTF_UP | RTF_HOST);
  rte.rt_dev   = ifname;
  
  (((struct sockaddr_in *) &(rte.rt_genmask))->sin_addr.s_addr) = 0xffffffff;
  
  if (socketOpen())
  {
    if (ioctl(skfd, SIOCADDRT, &rte) < 0) ::message("SIOCADDRT failed in routeAddHost");
    else return true;
  } else ::message("Socket not open in routeAddHost");

  return false;
}
  
    
bool NetCtrl::routeAddGateway(char *gateway)
{
  struct rtentry  rte;

  cout << PROMPT << "route add default gw " << gateway << endl;
  
  memset((char *) &rte, 0, sizeof(struct rtentry));
  
  ipToSocketAddress("default", &(rte.rt_dst));
  ipToSocketAddress(gateway, &(rte.rt_gateway));
  
  rte.rt_flags  = (RTF_UP | RTF_GATEWAY);
  
  if (socketOpen())
  {
    if (ioctl(skfd, SIOCADDRT, &rte) < 0) ::message("SIOCADDRT failed in routeAddGateway");
    else return true;
  } else ::message("Socket not open in routeAddGateway");

  return false;
}    


/* 
 * Type conversion 
 ******************/

bool NetCtrl::ipToSocketAddress(char *name, struct sockaddr *sap)
{
  struct sockaddr_in  *sin = (struct sockaddr_in *) sap;
  
  sin->sin_family = AF_INET;
  sin->sin_port   = 0;

  if (!strcmp(name, "default") || !strcmp(name, "0.0.0.0")) 
  {
    sin->sin_addr.s_addr = INADDR_ANY;
    return true;
  }
  else 
  {
    if (inet_aton(name, &sin->sin_addr)) return true;
    else                                 ::message("Can't resolve IP address");
  }	
  
  return false;
}


bool NetCtrl::socketAddressToIP(char *ip, struct sockaddr_in *sin)
{
  strncpy(ip, inet_ntoa(sin->sin_addr), 15);

  return true;	       
}


char *NetCtrl::hexToQuattedDot(char *hexIP, char *buf)
{
  char  hex[3];
  uint  num[4];
  
  for (short i = 6; i > -1; i -= 2) num[3-i/2] = hexToInt(strncpy(hex, hexIP+i, 2));
  
  sprintf(buf, "%d.%d.%d.%d", num[0], num[1], num[2], num[3]);
  
  return buf;
}


uint NetCtrl::hexToInt(char *hexnum)
{
  uint  num = 0;
  char  c;
  
  for (ushort i = 0; i < 2; i++)
  {
    num *= 16;
    c = toupper(hexnum[i]);
    
    if (c < 'A') num += (uint) (c-'0');
    else         num += (10+(uint) (c-'A'));
  }
  
  return num;
}


char *NetCtrl::intToHex(ushort num, char *hexnum)
{
  char  hexstr[17] = "0123456789ABCDEF";
  
  hexnum[0] = hexstr[(num % 256) >> 4];
  hexnum[1] = hexstr[num % 16];
  hexnum[2] = '\0';
  
  return hexnum;
}


/* 
 * Debugging 
 ************/

void NetCtrl::dumpSocketAddress(struct sockaddr_in *sin)
{
  char  hexbuf[3];
  char  *bp = (char *) sin;
  
  fprintf(stderr, PROMPT" Socket address dump - ");
  
  for (ushort i = 0; i < sizeof(struct sockaddr_in); i++)
  {
    fprintf(stderr, "%s ", intToHex((ushort) bp[i], hexbuf));
  }
  
  fflush(stderr);
}


void NetCtrl::dumpRoutingTable(struct route *rtable)
{
  fprintf(stderr, PROMPT" Dump of kernel routing setup\n\n");
  
  while (strlen(rtable->iface))
  {
    fprintf(stderr, "Destination %s has gateway %s (netmask %s) and is bound to interface %s\n",
                    rtable->destIP, rtable->gateIP, rtable->mask, rtable->iface);
    rtable++; 
  }
}

