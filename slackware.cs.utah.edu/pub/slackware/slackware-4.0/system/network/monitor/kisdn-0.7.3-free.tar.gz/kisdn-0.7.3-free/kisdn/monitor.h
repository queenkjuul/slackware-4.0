/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: monitor.h,v 1.2 1998/11/21 12:35:27 twesthei Exp $
//
// $Log: monitor.h,v $
// Revision 1.2  1998/11/21 12:35:27  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __MONITOR_H
#define __MONITOR_H

#ifdef HAVE_CONFIG_H
  #include "../config.h"
#endif

#include <qcombo.h>			
#include <qframe.h>			
#include <qlabel.h>
#include <qpixmap.h>
#include <qpushbt.h>			
#include <qstrlist.h>

#include <kapp.h>
#include <kbutton.h>
#ifdef HAVE_GLOBAL_SHORTCUTS
  #include <kglobalaccel.h>
#endif
#include <ktopwidget.h>

#include "basefrontend.h"
#include "combackend.h"
#include "customdlg.h"
#include "dockedwin.h"
#include "dodbutton.h"
#include "ipdisplay.h"
#include "isdnconfig.h"
#include "kdefrontend.h"
#include "ledbutton.h"
#include "ledpanel.h"
#include "logo.h"
#include "mtxdisplay.h"
#include "rectledpanel.h"
#include "scanmeter.h"
#include "uptdisplay.h"


class Monitor : public KTopLevelWidget, public BaseFrontend
{
  Q_OBJECT

  private:

    QComboBox      *ServerCombo;		// Simple GUI elements
    QFrame         *Etched, *EtchedBottom;
    QLabel         *Label;
    QLabel         *Logo;
    QPixmap        connect_xpm, hangup_xpm;
    QPushButton    *PushVoice;
    QPushButton    *PushConnectHangup, *PushHelp;
    QPushButton    *PushCustomize;
    QPushButton    *PushNoteBook;
    QPushButton    *PushDock, *PushQuit;
#ifdef HAVE_GLOBAL_SHORTCUTS
    KGlobalAccel   *globalKeys;
#endif
  
    MatrixFont     *mtxfont;

    RectLEDPanel   *StatusPanel;
    DoDButton      *dodbutton;			// Complex GUI elements
    LEDPushButton  *dbutton, *bbutton;
    IPDisplay      *IPdisplay;
    LEDPanel       *Panel;
    UptimeDisplay  *UTDisplay;
    ScanMeter      *Meter;
    CustomDialog   *custDlg;

    ISDNConfig	   *isdnconfig;			// Account settings and general information (read-only)
    ISDNInfo       *isdninfo;			// i4l backend information (read-only)

    int            ispindex, ispcount;

    bool           forcedhangup;		// Flags
    bool           isdnsupport;
    
    void  closeEvent(QCloseEvent *);
    void  resizeEvent(QResizeEvent *);
    void  writeCombo(QStrList *);
    void  togglePushHangupButton();
    bool  isOnline()                   { return (isdninfo->queryOnline(0) || isdninfo->queryOnline(1)); }

  private slots:

    void  slotEnableConnect(ushort); 		// Connect button changes
    void  slotEnableHangup(ushort);

    void  slotISPChanged(int);			// ISP combo change

    void  slotRefreshUptimes();

    void  slotCustomize();                 	// PushButton bindings
    void  slotMinimize();
    void  slotQuit();			

  protected:

    void  emitCommand(ISDNCommand *);

  public:

    Monitor(ISDNConfig *, ISDNInfo *, KDEFrontEnd *, int, QStrList *, const char *name = 0);
    ~Monitor() {}

    void  reloadAccounts( QStrList *, int );
#ifdef HAVE_GLOBAL_SHORTCUTS
    void  passGlobalKeys( KGlobalAccel *accel ) { globalKeys = accel; }
#endif

  public slots:	
  						// KISDN->MonitorWindow bindings
						
    void  slotBusy(ushort u)           { emit sigBusy(u);          }
    void  slotCallerHungUp()	       { emit sigCallerHungUp();   }		
    void  slotDial(ushort u)           { emit sigDial(u);          }
    void  slotDoDOff()                 { emit sigDoDOff();         }
    void  slotDoDOn()                  { emit sigDoDOn();          }
    void  slotDoDChanged(bool);
    void  slotHangup(ushort u)         { emit sigHangup(u);        }
    void  slotLinkDown(ushort u)       { emit sigLinkDown(u);      }
    void  slotLinkUp(ushort u)         { emit sigLinkUp(u);        }
    void  slotNewIPLocalA(char *ip)    { emit sigNewIPLocalA(ip);  }
    void  slotNewIPLocalB(char *ip)    { emit sigNewIPLocalB(ip);  }
    void  slotNewIPRemoteA(char *ip)   { emit sigNewIPRemoteA(ip); }
    void  slotNewIPRemoteB(char *ip)   { emit sigNewIPRemoteB(ip); }
    void  slotNewScan(PPPInfo *info)   { emit sigNewScan(info);    }
    void  slotReceiveOff(ushort u)     { emit sigReceiveOff(u);    }
    void  slotReceiveOn(ushort u)      { emit sigReceiveOn(u);     }
    void  slotTransmitOff(ushort u)    { emit sigTransmitOff(u);   }
    void  slotTransmitOn(ushort u)     { emit sigTransmitOn(u);    }

    void  slotToggleLineState();		// Frontend dialup handling
    void  wakeUp();				// Initialization after construction

    void  saveSession();

  signals:

    void  sigBusy(ushort);			
    void  sigCallerHungUp();			
    void  sigDial(ushort);
    void  sigDoDOff();
    void  sigDoDOn();
    void  sigHangup(ushort);
    void  sigLinkDown(ushort);
    void  sigLinkUp(ushort);
    void  sigNewIPLocalA(char *);
    void  sigNewIPLocalB(char *);
    void  sigNewIPRemoteA(char *);
    void  sigNewIPRemoteB(char *);
    void  sigNewScan(PPPInfo *);
    void  sigReceiveOff(ushort);
    void  sigReceiveOn(ushort);
    void  sigTransmitOff(ushort);
    void  sigTransmitOn(ushort);

    void  sigCommand(ISDNCommand *);
    void  sigDockMe();			
    void  sigOnlineTime(QString);
};


#endif
