/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: connection.cpp,v 1.2 1998/11/21 12:34:30 twesthei Exp $
//
// $Log: connection.cpp,v $
// Revision 1.2  1998/11/21 12:34:30  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <qmsgbox.h>
#include <qstring.h>

#include <kapp.h>
#include <kconfig.h>
#include <kprocess.h>

#include "adapter.h"
#include "kisdndata.h"
#include "connection.h"
#include "general.h"


Connection::Connection(AccountData *acc, char *dev, char *slave, NetCtrl *net, ISDNCtrl *ctrl, 
                       ISDNConfig *config, QWidget *parent, const char *name) : QWidget(parent, name)
{
  char  ipneg[48], user[NAMESIZE+1], device[16], ipppd[PATHSIZE+1];
  char  buf[16];
    
  GeneralData      *gen    = ISDNData.generalData();
  AdvancedOptions  *adv    = gen->advancedOptions();
  Device           *master = acc->masterDevice();
  Adapter          ad;
  int              encapsulation;
  
  encaps   = master->protEncaps(); 
      
  switch (encaps)
  {
    case Device::RAWIP    : encapsulation = PROTRAWIP;
                            break;
    case Device::IP       : encapsulation = PROTIP;
                            break;
    case Device::CISCO    : encapsulation = PROTCISCO;
                            break;
    case Device::ETHERNET : encapsulation = PROTETHER;
                            break;
    case Device::SYNCPPP  : encapsulation = PROTSYNC;
                            break;
    case Device::IPUI     : encapsulation = PROTIPUI;
  } 
   
  strcpy(condev, dev);
  strcpy(conslave, slave);

  isdnctrl   = ctrl;
  isdnconfig = config;
  netctrl    = net;
  
  if (!writeScripts(acc)) ::message("Error writing system scripts");
  
  createInterface(acc, ad.Id[ad.NewIndex(gen->adapterType())].data());
   
  if (encaps == Device::SYNCPPP)
  {
    ::message("Starting ipppd for syncPPP interface");
    
    sprintf(user,   "%s",      acc->username().data()); 
    sprintf(device, "/dev/%s", condev);
    sprintf(ipppd,  "%s",      gen->ipppdPath().data());
  
    if (acc->assignType() == AccountData::DYNAMIC) sprintf(ipneg, "noipdefault");
    else sprintf(ipneg, "%s:%s", acc->localIP().string().data(), acc->remoteIP().string().data());
  
    IPPPD = new KProcess();
 
    *IPPPD << ipppd
           << ipneg
           << "user"
           << user;
	 
    if (acc->enabledCallback() && acc->callbackInit())
    {
      *IPPPD << "callback";
      sprintf(buf, "3,%s%s", gen->prefix().data(), gen->msnData().data());
      *IPPPD << buf;
    }
    
    if (adv->bsdCompression())         *IPPPD << "-bsdcomp";
    if (adv->increaseDebug())          *IPPPD << "debug";

    if (acc->disabledVJCompression())  *IPPPD << "-vj";
    if (acc->disabledVJConnection())   *IPPPD << "-vjccomp";
    if (acc->disabledACCompression())  *IPPPD << "-ac";
    if (acc->disabledPFCompression())  *IPPPD << "-pc";
    if (acc->ipcpAcceptLocal())        *IPPPD << "ipcp-accept-local";
    if (acc->ipcpAcceptRemote())       *IPPPD << "ipcp-accept-remote";

    if (adv->mru() != 0)
    {
      *IPPPD << "mru";
      sprintf(buf, "%i", adv->mru());
      *IPPPD << buf;
    }

    if (adv->mtu() != 0)
    {
      *IPPPD << "mtu";
      sprintf(buf, "%i", adv->mtu());
      *IPPPD << buf;
    }
  
    if (adv->debugLevel())
    {
      *IPPPD << "kdebug";
      sprintf(buf, "%i", adv->debugLevel());
      *IPPPD << buf;
    }
  
    *IPPPD << "-detach"
           << "lock"
           << "defaultroute"
           << device;
     
    if (!IPPPD->start()) QMessageBox::warning(this, "Fatal Error",
                                                    "ipppd could not be\n"
                                                    "started !\n\n", "OK", 0);
  }
}


Connection::~Connection()
{
  if (encaps == Device::SYNCPPP)
  { 
    ::message("Killing ipppd that was started for syncPPP interface");
    
    if (!IPPPD->kill(SIGKILL)) ::message("ipppd could not be killed");
    else 
    {
      deleteInterface();
      delete IPPPD;		// Possible memory leak before
    }
  }
  else deleteInterface();
}


void Connection::createInterface(AccountData *acc, const char *adapterID)
{
  char msn[64];
    
  GeneralData  *gen    = ISDNData.generalData();
  Device       *master = acc->masterDevice();
  Phone        *phone;
  
  fprintf(stderr, "kISDN: Setup interface %s\n", condev);
  
  isdnctrl->Addif(condev);
  isdnctrl->setDialMode(condev, ISDNCtrl::MANUAL);

  isdnctrl->Eaz(condev, strcat(strcpy(msn, gen->prefix().data()), gen->msnData().data()));
  
  if (master->phoneList().isEmpty()) QMessageBox::warning(this, "Fatal Error",
                                                                "No phone number supplied\n"
                                                                "for this ISP !\n\n", "OK", 0);

  else
  {
    for (phone = master->firstPhone(); phone != 0L; phone = master->nextPhone())
      isdnctrl->AddphoneOut(condev, phone->number().data());
    
    isdnctrl->Dialmax(condev,    master->dialAttempts());
    isdnctrl->Huptimeout(condev, master->hupTime());
    isdnctrl->Encaps(condev,     master->protEncaps());
    isdnctrl->L2_Prot(condev,    master->protLayer2());
    isdnctrl->L3_Prot(condev,    master->protLayer3());
    isdnctrl->Secure(condev,     (acc->secureMode() == AccountData::ON) ? true : false);
    
    if (acc->enabledCallback())
    {
      ushort  cbtype = (acc->callbackInit()) ? CBOUT : CBIN;  
       
      if (acc->stripZeroes())
      {
        QString  inphone;
	
        for (phone = master->firstPhone(); phone != 0L; phone = master->nextPhone())
        {
	  inphone = phone->number().copy();
	  
	  if (inphone.left(1) == "0") inphone = inphone.right(inphone.length()-1).copy();
	  
          isdnctrl->AddphoneIn(condev, inphone.data());
        }
      }
      else isdnctrl->AddphoneIn(condev, acc->ingoingPhone().data());
      
      isdnctrl->Callback(condev, cbtype);
      
      if (cbtype == CBOUT) isdnctrl->CBDelay(condev, acc->hangupTime());
      else
      {
        isdnctrl->CBHangup(condev, acc->callbackHangup());
	isdnctrl->CBDelay(condev,  acc->callbackTime());
      }
    }
    
    netctrl->ifPointToPoint(condev, "1.1.1.1", "1.1.1.1");
  } 
}


bool Connection::writeScripts(AccountData *acc)	
{
  FILE   *OutStream;
  bool   quote = (bool) strchr(acc->username().data(), '#');
  bool   quotePassword = (bool) strchr(acc->password().data(), '#');
  IP    *dns;
  QString user, pass;
    
  if (quote || quotePassword) 
  {
    ::message("Username/password contains the character '#' (e.g. T-Online)");
    ::message("I will quote it in ioptions and the secret files");
  }
    
  if ( quote )
    user = "\"" + acc->username() + "\"";
  else
    user = acc->username();

  if ( quotePassword )
    pass = "\"" + acc->password() + "\"";
  else
    pass = acc->password();

  if (acc->authType() == AccountData::PAP)
  {
    if ((OutStream = fopen(PAPFILE, "w")) != 0)
    {
      fprintf(stderr, "kISDN: Writing %s...\n", PAPFILE);
      
      fprintf(OutStream, "%s * %s\n", user.data(), pass.data());
	
      fclose(OutStream);
      
      chown(PAPFILE, 0, 0);
      chmod(PAPFILE, S_IRUSR | S_IWUSR);      
    }
    else 
    {
      messageCantOpenFile(PAPFILE);
      return false;
    }
  }
  else
  {
    if (acc->authType() == AccountData::CHAP)
    {
      if ((OutStream = fopen(CHAPFILE, "w")) != 0)
      {
        fprintf(stderr, "kISDN: Writing %s...\n", CHAPFILE);
	
	fprintf(OutStream, "%s * %s\n", user.data(), pass.data());
        
	fclose(OutStream);
      
        chown(CHAPFILE, 0, 0);
        chmod(CHAPFILE, S_IRUSR | S_IWUSR);      
      }
      else 
      {
        messageCantOpenFile(CHAPFILE);
        return false;
      }
    }
    else	// We don't need neither PAP nor CHAP so let's remove the secrets !
    {
      ::message("No authentication for this ISP");
      
      if ((OutStream = fopen(PAPFILE, "w")) != 0)
      {
        fprintf(stderr, "kISDN: Deleting %s...\n", PAPFILE);
        fclose(OutStream);
      }
      
      if ((OutStream = fopen(CHAPFILE, "w")) != 0)
      {
        fprintf(stderr, "kISDN: Deleting %s...\n", CHAPFILE);
        fclose(OutStream);
      }
      
    }
  }

  if ((OutStream = fopen(DNSFILE, "w")) != 0)
  {
    fprintf(stderr, "kISDN: Writing %s...\n", DNSFILE);
    fprintf(OutStream, "search %s\n", acc->domain().data());
    
    if (acc->firstDNS() != 0L)
    {
      for (dns = acc->firstDNS(); dns != 0L; dns = acc->nextDNS())
        fprintf(OutStream, "nameserver %s\n", dns->string().data());
          
      fclose(OutStream);
    }
    else
    {
      messageNoDNSSupplied();
      fclose(OutStream);
      return false;
    }
  }
  else 
  {
    messageCantOpenFile(DNSFILE);
    return false;
  }
  
  if ((OutStream = fopen(OPTFILE, "wb")) != 0)
  {
    fprintf(stderr, "kISDN: Writing %s...\n", OPTFILE);    
    
    fprintf(OutStream, "name %s\n", user.data());
      
    fclose(OutStream);
  }
  else 
  {
    messageCantOpenFile(OPTFILE);
    return false;
  }
  return true;
}


void Connection::deleteInterface(void)
{
  netctrl->ifDown(condev);			  
  isdnctrl->Delif(condev);
}


void Connection::dialOut(void)
{
  if (encaps != PROTSYNC)
  {
    AccountData  *acc = ISDNData.currentAccount();
    
    netctrl->ifPointToPoint(condev, acc->localIP().string().data(), acc->remoteIP().string().data());
    netctrl->ifSetFlag(condev, (IFF_UP | IFF_RUNNING));
    netctrl->routeAddHost(acc->remoteIP().string().data(), condev);
    netctrl->routeAddGateway(acc->remoteIP().string().data());
  }
   
  // if (!isdnconfig->activeDoD()) isdnctrl->setDialMode(condev, ISDNCtrl::MANUAL);
 
  isdnctrl->Dial(condev); 
}


void  Connection::hangUp(void)
{
  isdnctrl->Hangup(condev); 
  
  // if (!isdnconfig->activeDoD()) isdnctrl->setDialMode(condev, ISDNCtrl::OFF);

  if (netctrl->routeHaveDefault(condev)) netctrl->routeDelete("0.0.0.0");
}


/* 
 * Error message boxes 
 ***********************/

void  Connection::messageCantOpenFile(const char *fname)
{
  char buffer[128];
  
  sprintf(buffer, "Can't open file\n%s !\n\n", fname);
  QMessageBox::warning(this, i18n("I/O Error"), buffer, "OK", 0);
}


void  Connection::messageNoDNSSupplied(void)
{
  QString tmp;
  
  tmp  = i18n("You forgot to specify a\n");
  tmp += i18n("nameserver for this ISP\n\n");
  
  QMessageBox::warning(this, i18n("Can't connect"), tmp, "Ok", 0);
}


