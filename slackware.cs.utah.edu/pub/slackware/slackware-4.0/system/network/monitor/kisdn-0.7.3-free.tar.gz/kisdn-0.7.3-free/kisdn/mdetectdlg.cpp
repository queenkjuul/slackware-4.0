/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: mdetectdlg.cpp,v 1.2 1998/11/21 12:34:50 twesthei Exp $
//
// $Log: mdetectdlg.cpp,v $
// Revision 1.2  1998/11/21 12:34:50  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <kapp.h>
#include <kiconloader.h>

#include "mdetectdlg.h"


MDetectDialog::MDetectDialog(uint adtype, QWidget *parent, const char *name):QDialog(parent, name, true)
{
  QSize    size;
  QString  tmp;
  int      wd1, wd2, hg, mw;
  
  if (adtype == 21) setCaption(i18n("CAPI modules detected"));
  else              setCaption(i18n("HiSax module detected"));

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap puzzle_xpm = loader->loadIcon("puzzle.xpm");

  pmPuzzle = new QLabel(this);
  pmPuzzle->setPixmap(puzzle_xpm);
  pmPuzzle->setGeometry(22, 16, 32, 32);

  tmp  = i18n("kISDN has detected an already\n");
  
  if (adtype == 21) tmp += i18n("installed CAPI module, automatic\n");
  else              tmp += i18n("installed HiSax module, automatic\n");
  
  tmp += i18n("loading is therefore skipped.");

  label = new QLabel(tmp.data(), this);
  size  = label->sizeHint();
  wd1   = size.width();
  hg    = size.height();
  label->setGeometry(80, 12, wd1, hg);

  showagain = new QCheckBox(i18n("Don't show this message again"), this);
  size = showagain->sizeHint();
  wd2  = size.width();
  hg   = size.height();
  showagain->setGeometry(26, 84, wd2, hg);

  mw = ((wd1+96) > (wd2+42)) ? wd1+96 : wd2+42;
  setFixedSize(mw, 170);
  
  OK = new QPushButton(i18n("OK"), this);
  OK->setGeometry((mw-80)/2, 134, 80, 28);
  OK->setDefault(true);
  OK->setFocus();
  connect(OK, SIGNAL(clicked()), SLOT(accept()));
}

