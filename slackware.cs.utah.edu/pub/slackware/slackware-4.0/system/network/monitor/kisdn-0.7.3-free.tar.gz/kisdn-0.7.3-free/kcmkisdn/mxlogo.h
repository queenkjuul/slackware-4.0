/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: mxlogo.h,v 1.1.1.1 1998/11/21 10:18:57 twesthei Exp $
//
// $Log: mxlogo.h,v $
// Revision 1.1.1.1  1998/11/21 10:18:57  twesthei
// Imported sources
//
// Revision 1.1  1998/10/27 21:31:35  gis
// *** empty log message ***
//
// Revision 1.1  1998/10/26 15:15:08  twesthei
// *** empty log message ***
//


#ifndef __MXLOGO_H
#define __MXLOGO_H

#include <qlabel.h>
#include <qpixmap.h>


class MXLogo : public QLabel
{
  private: 
  
    QPixmap  _pixmap;
    
  public:
  
    MXLogo(const char *file = "millenniumx.gif", QWidget *parent = 0, const char *name = 0);
    ~MXLogo() {}
};


#endif
