/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: isdnctrl.cpp,v 1.2 1998/11/21 12:34:40 twesthei Exp $
//
// $Log: isdnctrl.cpp,v $
// Revision 1.2  1998/11/21 12:34:40  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/config.h>
#include <linux/isdnif.h>

#include "general.h"
#include "isdnctrl.h"


/*
 * Interface to /dev/isdnctrl
 *****************************/

ISDNCtrl::ISDNCtrl() : fd(-1), result(true)
{
  fd = open("/dev/isdnctrl", O_RDWR);
  
  if (fd < 0) ::message("Can't open /dev/isdnctrl");
}


ISDNCtrl::~ISDNCtrl() 
{
  if (fd >= 0) close(fd);
}


/*
 * Implementation of 'isdnctrl' from the isdn4kutils package
 ************************************************************/

bool ISDNCtrl::Dial(char *id)
{
  if (fd >= 0) 
  {
    result = ((ioctl(fd, IIOCNETDIL, id)) < 0);    
    
    cout << PROMPT << "Dialing of " << id;
    
    if (!result) cout << " triggered" << endl;
    else         cout << " failed"    << endl;
  }  
  else return false;
  
  return !result;
}
  
  
bool ISDNCtrl::Hangup(char *id)
{
  if (fd >= 0) 
  {
    result = ((ioctl(fd, IIOCNETHUP, id)) < 0);
    if (!result) cout << PROMPT << id << " hung up" << endl;
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::Addif(char *id)
{
  if (fd >= 0) 
  {
    result = ((ioctl(fd, IIOCNETAIF, id)) < 0);
    if (!result) cout << PROMPT << id << " added" << endl;
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::Delif(char *id)
{
  if (fd >= 0) 
  {
    result = ((ioctl(fd, IIOCNETDIF, id)) < 0);
    if (!result) cout << PROMPT << id << " deleted" << endl;
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::Encaps(char *id, ushort encaps)
{
  char  encstr[6][16] = {"rawip", "ip", "cisco_h", "ethernet", "syncppp", "uihdlc"};  
  int   encval[6]     = {ISDN_NET_ENCAP_RAWIP, ISDN_NET_ENCAP_IPTYP, ISDN_NET_ENCAP_CISCOHDLC,
  		         ISDN_NET_ENCAP_ETHER, ISDN_NET_ENCAP_SYNCPPP, ISDN_NET_ENCAP_UIHDLC};
		    
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);
  
    if (!result)
    {
      cfg.p_encap = encval[encaps];    
      result      = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);

      if (!result) 
        cout << PROMPT << "Encapsulation of " << cfg.name <<" is " << encstr[cfg.p_encap] << endl;
    }
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::L2_Prot(char *id, ushort l2prot)
{
  char  la2str[4][8]  = {"x75i", "x75ui", "x75bui", "hdlc"};
  int   la2val[4]     = {ISDN_PROTO_L2_X75I, ISDN_PROTO_L2_X75UI, ISDN_PROTO_L2_X75BUI,
  			 ISDN_PROTO_L2_HDLC};
		    
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);
  
    if (!result)
    {
      cfg.l2_proto = la2val[l2prot];    
      result       = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);

      if (!result) 
        cout << PROMPT << "Layer 2 protocol of " << cfg.name << " is " << la2str[cfg.l2_proto] << endl;
    }
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::L3_Prot(char *id, ushort l3prot)
{
  char  la3str[1][8] = {"trans"};  
  int   la3val[1]    = {ISDN_PROTO_L3_TRANS};
		    
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);
  
    if (!result)
    {
      cfg.l3_proto = la3val[l3prot];    
      result       = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);

      if (!result) 
        cout << PROMPT << "Layer 3 protocol of " << cfg.name << " is " << la3str[cfg.l3_proto] << endl;
    }
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::Dialmax(char *id, uint dmax)
{
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);
  
    if (!result)
    {
      cfg.dialmax = dmax;    
      result      = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);

      if (!result) 
        cout << PROMPT << "Max dial tries " << cfg.name << " set to " << cfg.dialmax << endl;
    }
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::Huptimeout(char *id, uint tout)
{
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);
  
    if (!result)
    {
      cfg.onhtime = tout;    
      result      = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);

      if (!result) 
        cout << PROMPT << "Hangup timeout for " << cfg.name << " is " << cfg.onhtime << " seconds" << endl;
    }
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::Addphone(char *id, char *pnum, ushort dir)
{
  result = true;
  
  if (fd >= 0) 
  {
    if (strlen(pnum) > 20) cout << PROMPT << "IIOCNETANM, phone number exceeds 20 characters" << endl;
    else
    {
      phone.outgoing = dir;   
      strcpy(phone.name, id);
      strcpy(phone.phone, pnum);
      result = ((ioctl(fd, IIOCNETANM, &phone)) < 0);
    
      if (!result) cout << PROMPT << "Added " << ((dir) ? "out" : "in") << "going phone number " 
	                << phone.phone << " for " << phone.name << endl;
    }
  }
  else return false;
  
  return !result;
} 



bool ISDNCtrl::Eaz(char *id, char *eaz)
{
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);
  
    if (!result)
    {
      strncpy(cfg.eaz, eaz, sizeof(cfg.eaz)-1);
      result = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);

      if (!result) cout << PROMPT << "EAZ/MSN for " << cfg.name << " is " << cfg.eaz << endl;
    }
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::Addslave(char *id, char *slave)
{
  char  buf[20];
  
  result = true;
	
  if (fd >= 0) 
  {
    if (strlen(slave) > 8) cout << PROMPT << "IIOCNETASL, slave name exceeds 8 characters" << endl; 
    else
    {
      sprintf(buf, "%s,%s", id, slave);
      result = ((ioctl(fd, IIOCNETASL, buf)) < 0);

      if (!result) cout << PROMPT << slave << " added as slave to " << id << endl;
    }
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::Sdelay(char *id, uint delay)
{
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);
  
    if (!result)
    {
      if (delay < 1)
      {
        cout << PROMPT << "IIOCNETSCF, slave activation delay must be >= 1" << endl;
        return false;
      }
    
      cfg.slavedelay = delay;
      result = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);

      if (!result) 
        cout << PROMPT << "Slave activation delay for " << cfg.name << " is " << cfg.slavedelay << " seconds" << endl;
    }
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::Callback(char *id, ushort type)
{
  char  cbtype[3][4] = {"OFF", "IN", "OUT"};
  
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);

    if (!result)
    {
      cfg.callback = type;
      result = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);  
      
      if (!result) 
        cout << PROMPT << "Callback mode for " << id << " is " << cbtype[cfg.callback] << endl;
    }
  }
  else return false;
  
  return !result;
} 


bool ISDNCtrl::CBHangup(char *id, bool mode)
{
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);

    if (!result)
    {
      cfg.cbhup = (mode) ? 1 : 0;
      result = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);  
      
      if (!result) 
        cout << PROMPT << "Callback hangup for " << id << " is " << ((cfg.cbhup) ? "ON" : "OFF") << endl;
    }
  }
  else return false;
  
  return !result;
}


bool ISDNCtrl::CBDelay(char *id, uint seconds)
{
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);

    if (!result)
    {
      cfg.cbdelay = seconds*5;
      result = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);  
      
      if (!result) 
        cout << PROMPT << "Callback delay for " << id << " is " << cfg.cbdelay/5 << endl;
    }
  }
  else return false;
  
  return !result;
}


bool ISDNCtrl::Secure(char *id, bool state)
{
  ushort  mode = (state) ? 1 : 0;
  
  if (fd >= 0) 
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);

    if (!result)
    {
      cfg.secure = mode;
      result = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);  
      
      if (!result) 
        cout << PROMPT << "Secure mode for " << id << " is " << ((cfg.secure) ? "ON" : "OFF") << endl;
    }
  }
  else return false;
  
  return !result;
}


/*
 * TIMRU extensions
 *******************/
 
bool ISDNCtrl::TStatus(const char *id, bool state)
{
  /*
  int  result = 0;

  if (fd >= 0)
  {
    strcpy(cfg.name, id);
    result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);

    if (!result)
    {
      cfg.stopped = !state;                             // state = false <--> st
atus OFF
      result = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);

      if (!result)
        cout << PROMPT << "Status for " << id << " is " << ((cfg.stopped) ? "OFF
" : "ON") << endl;
    }
  }
  else return false;
  */

  return false;
}


/*
 * HiSax 3.1
 ************/

bool ISDNCtrl::setDialMode(const char *id, dialmode mode)
{
#ifdef ISDN_NET_DM_OFF

  strcpy(cfg.name, id);
  result = ((ioctl(fd, IIOCNETGCF, &cfg)) < 0);

  if (result) return false;

  if      (mode == ISDNCtrl::OFF)    cfg.dialmode = ISDN_NET_DM_OFF;
  else if (mode == ISDNCtrl::MANUAL) cfg.dialmode = ISDN_NET_DM_MANUAL;
  else if (mode == ISDNCtrl::AUTO)   cfg.dialmode = ISDN_NET_DM_AUTO;
  else
  {
    ::message("Invalid dialmode");
    return false;
  }

  result = ((ioctl(fd, IIOCNETSCF, &cfg)) < 0);

  if (!result)
  {
    cout << PROMPT << "Dialmode for " << id << " is ";

    switch (cfg.dialmode)
    {
      case ISDN_NET_DM_OFF    : cout << "OFF";
                                break;
      case ISDN_NET_DM_MANUAL : cout << "MANUAL";
                                break;
      case ISDN_NET_DM_AUTO   : cout << "AUTO";
                                break;
      default                 : cout << "UNDEFINED";
    }

    cout << endl;
  }

  return !result;

#else
#error Need HiSax 3.1
#endif
}


/*
 * Methods used internally in other classes
 *******************************************/


bool ISDNCtrl::getPhoneNumbers(union phonenums *phones)     
{
  result = (ioctl(fd, IIOCNETGNM, &(phones->phone)) < 0);
  
  return !result; 
}
