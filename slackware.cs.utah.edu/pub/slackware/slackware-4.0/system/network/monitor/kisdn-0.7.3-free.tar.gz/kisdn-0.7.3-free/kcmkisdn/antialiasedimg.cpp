/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: antialiasedimg.cpp,v 1.1.1.1 1998/11/21 10:18:57 twesthei Exp $
//
// $Log: antialiasedimg.cpp,v $
// Revision 1.1.1.1  1998/11/21 10:18:57  twesthei
// Imported sources
//
// Revision 1.1  1998/10/26 13:46:35  gis
// *** empty log message ***
//
// Revision 1.1  1998/10/26 12:36:11  gis
// *** empty log message ***
//
// Revision 1.1  1998/10/23 19:05:42  twesthei
// Added a class to handle anti-aliased GIF images
//


#include <qstring.h>

#include "antialiasedimg.h"
#include "general.h"


AntiAliasedImage::AntiAliasedImage() : QImage()
{
}


QImage AntiAliasedImage::getImage(const QColor& bg)
{
  QRgb     curColor;
  QImage   imgcopy = img.copy();
  int      red, green, blue;
  int      bgred     = bg.red();
  int      bggreen   = bg.green();
  int      bgblue    = bg.blue();
  int      numcolors = img.numColors();

  for (int col = 0; col < numcolors; col++)
  {
    curColor = img.color(col);

    red      = qRed(curColor)   & bgred;
    green    = qGreen(curColor) & bggreen;
    blue     = qBlue(curColor)  & bgblue;

    imgcopy.setColor(col, qRgb(red, green, blue));
  }

  return imgcopy.convertDepth(32);
}


bool AntiAliasedImage::loadImage( QString filename )
{
  bool ret = false;

  if ( load( filename.data() ))
  {
    if (depth() != 8)
    {
      QString tmp = i18n("AntiAliasedImage: Converting to depth 8 (was depth ");
      tmp += depth() + ")";
      ::message( tmp.data() );

      img = convertDepth(8);
    }
    else img = *this;
    
    ret = true;
  }
  else
  {
    QString tmp = filename + i18n(" not found!");
    ::message( tmp.data() );
  }

  return ret;
}
