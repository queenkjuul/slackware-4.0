/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: kisdndata.cpp,v 1.2 1998/11/21 12:34:43 twesthei Exp $
//
// $Log: kisdndata.cpp,v $
// Revision 1.2  1998/11/21 12:34:43  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <qfile.h>
#include <qmsgbox.h>
#include <qstring.h>

#include <kapp.h>

#include <ctype.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <pwd.h>

#include <string.h>

#include "general.h"
#include "kisdncompat.h"
#include "kisdndata.h"
#include "version.h"


kISDNData ISDNData;


IP::IP(int a, int b, int c, int d)
{
  if (rangeOK(a) && rangeOK(b) && rangeOK(c) && rangeOK(d))
  {
    _field[0] = a;
    _field[1] = b;
    _field[2] = c;
    _field[3] = d;
  }
  else for (ushort i = 0; i < 4; i++) _field[i] = 0;
}


IP::IP(const QString& ip)
{
  if (!valid(ip.data())) for (ushort i = 0; i < 4; i++) _field[i] = 0;
}


QString  IP::string() const
{
  QString  s;

  s.sprintf("%i.%i.%i.%i", _field[0], _field[1], _field[2], _field[3]);

  return s;
}


bool  IP::valid(const char *s)
{
  for (ushort i = 0; i < 4; i++)
  {
    while (*s == ' ') s++;

    if (!isdigit(*s)) return false;

    _field[i] = 0;

    while (isdigit(*s))
    {
      _field[i] *= 10;
      _field[i] += *(s++)-'0';

      if (_field[i] > 255) return false;
    }

    while (*s == ' ') s++;

    if ((i < 3) && (*s != '.')) return false;
    else                        s++;
  }

  s--;

  while (*s == ' ') s++;

  return (*s == '\0');
}


Device::Device(QString name, int hup, int att, int delay,
	       encprotocol enc, l2protocol l2, l3protocol l3) : _name(name),
                                                                _huptime(hup),
	                                                        _dialattempts(att),
	                                                        _delay(delay),
	                                                        _encaps(enc),
	                                                        _layer2(l2),
	                                                        _layer3(l3)
{
  _phonelist.setAutoDelete(true);
  _phonelist.clear();
}
								

Device::Device(Device& dev) : _name(dev.name()),
                              _huptime(dev.hupTime()),
                              _dialattempts(dev.dialAttempts()),
                              _delay(dev.delay()),
			      _encaps(dev.protEncaps()),
                              _layer2(dev.protLayer2()),
                              _layer3(dev.protLayer3())			
{
  Phone  *phone;

  _phonelist.setAutoDelete(true);
  _phonelist.clear();

  // Make a deep copy of the phone list

  for (phone = dev.firstPhone(); phone != 0L; phone = dev.nextPhone())
    _phonelist.append(new Phone(*phone));
}


bool  Device::load(KConfig *kc, uint accindex, ushort devindex)
{
  char    buffer[32];
  ushort  phcnt = 0;

  sprintf(buffer, "Account%i/Master", accindex);
  kc->setGroup(buffer);

  _huptime      = kc->readNumEntry("HupTimeOut", 600);
  _dialattempts = kc->readNumEntry("DialAttempts", 1);

  _encaps = (encprotocol) kc->readNumEntry("Encapsulation", (int) SYNCPPP);
  _layer2 = (l2protocol)  kc->readNumEntry("Layer2",        (int) HDLC);
  _layer3 = (l3protocol)  kc->readNumEntry("Layer3",        (int) TRANS);

  phcnt  = kc->readNumEntry("NumPhone", 0);

  for (ushort i = 0; i < phcnt; i++)
  {
    sprintf(buffer, "Phone%i", i);
    _phonelist.append(new Phone(kc->readEntry(buffer, "0")));
  }

  return true;
}


void  Device::save(KConfig *kc, uint accindex, ushort devindex)
{
  char   buffer[32];
  int    phcnt = 0;
  Phone  *phone;

  sprintf(buffer, "Account%i/Master", accindex);
  kc->setGroup(buffer);

  kc->writeEntry("HupTimeOut",          _huptime);
  kc->writeEntry("DialAttempts",        _dialattempts);
  kc->writeEntry("Encapsulation", (int) _encaps);
  kc->writeEntry("Layer2",        (int) _layer2);
  kc->writeEntry("Layer3",        (int) _layer3);

  for (phone = _phonelist.first(); phone != 0L; phone = _phonelist.next())
  {
    sprintf(buffer, "Phone%i", phcnt++);
    kc->writeEntry(buffer, phone->number());
  }

  kc->writeEntry("NumPhone", (int) phcnt);
}


AccountData::AccountData() : _cryptbyte(0x7c),
			     _providername(""),
                             _iploc(QString("0.0.0.0")),
		             _iprem(QString("0.0.0.0")),
		             _subnetmask(QString("255.255.255.255")),
		             _domain(""),
		             _username(""),
		             _password(""),
		             _ingoingphone(""),
		             _device(0),
		             _huptime(60),
		             _cbtime(5),
		             _callback(false),
		             _cbinit(true),
		             _cbhangup(false),
		             _enabledacc(false),
                             _securemode(ON),
                             _vjcomp(false),
		             _vjconn(false),
		             _adrctrl(false),
                             _protfld(false),
		             _ipcpaccloc(false),
		             _ipcpaccrem(false),
                             _strip0(true),
                             _changedacc(false),
                             _assigntype(DYNAMIC),
                             _authtype(PAP)
{
  _dnslist.setAutoDelete(true);
  _dnslist.clear();

  _master         = new Device();
  _pastconnect    = new ScriptData(ScriptData::PASTCONNECT);
  _pastdisconnect = new ScriptData(ScriptData::PASTDISCONNECT);
}


AccountData::AccountData(AccountData& acc) : _cryptbyte(0x7c),
					     _providername(acc.providerName()),
                                             _iploc(acc.localIP()),
		                             _iprem(acc.remoteIP()),
		                             _subnetmask(acc.subnetMask()),
		                             _domain(acc.domain()),
		                             _username(acc.username()),
		                             _password(acc.password()),
		                             _ingoingphone(acc.ingoingPhone()),
		                             _device(acc.device()),
		                             _huptime(acc.hangupTime()),
		                             _cbtime(acc.callbackTime()),
		                             _callback(acc.enabledCallback()),
		                             _cbinit(acc.callbackInit()),
		                             _cbhangup(acc.callbackHangup()),
		                             _enabledacc(acc.enabledAccount()),
                                             _securemode(acc.secureMode()),
                                             _vjcomp(acc.disabledVJCompression()),
		                             _vjconn(acc.disabledVJConnection()),
		                             _adrctrl(acc.disabledACCompression()),
                                             _protfld(acc.disabledPFCompression()),
		                             _ipcpaccloc(acc.ipcpAcceptLocal()),
		                             _ipcpaccrem(acc.ipcpAcceptRemote()),
                                             _strip0(acc.stripZeroes()),
                                             _changedacc(acc.accountChanged()),
                                             _assigntype(acc.assignType()),
                                             _authtype(acc.authType())
{
  IP  *dns;

  _dnslist.setAutoDelete(true);
  _dnslist.clear();

  _master         = new Device(*(acc.masterDevice()));
  _pastconnect    = new ScriptData(*(acc.connectScripts()));
  _pastdisconnect = new ScriptData(*(acc.disconnectScripts()));

  // Make a deep copy of the DNS list

  for (dns = acc.firstDNS(); dns != 0L; dns = acc.nextDNS())
    _dnslist.append(new IP(*dns));
}


AccountData::~AccountData()
{
  delete _master;
  delete _pastconnect;
  delete _pastdisconnect;
}


QString  AccountData::toHexByte(char c)
{
  QString  hexbyte = "";
  QString  hextab  = "0123456789ABCDEF";

  hexbyte += hextab.mid((c & 0xf0) >> 4, 1);
  hexbyte += hextab.mid(c & 0x0f, 1);

  return hexbyte;
}


char  AccountData::fromHexByte(const char *s)
{
  uint  n = 0;
  char  c;

  for (ushort i = 0; i < 2; i++)
  {
    n *= 16;
    c  = toupper(s[i]);

    if (c < 'A') n += (uint) (c-'0');
    else         n += (10+(uint) (c-'A'));
  }

  return n;
}


QString  AccountData::toHexString(int c, const char *s)
{
  QString  hexstr = "";

  while (*s)
  {
    hexstr += toHexByte(*s^c);
    s++;
  }

  return hexstr;
}


QString  AccountData::fromHexString(int c, const char *s)
{
  QString  word = "";

  while (*s)
  {
    word += (fromHexByte(s)^_cryptbyte);
    s    += 2;
  }

  return word;
}


bool  AccountData::load(KConfig *kc, uint index)
{
  char     accgroup[16], buffer[16];
  int      dnscnt;
  QString  un, pw, tmp;

  cout << PROMPT << "Load account #" << index << endl;

  sprintf(accgroup, "Account%i", index);
  kc->setGroup(accgroup);

  _providername = kc->readEntry("Provider", i18n("(unknown)"));

  _enabledacc   = (kc->readEntry("AccountEnabled", "no" ) == "yes" );

  if (!_enabledacc)
  {
    _providername = "<disabled> (" + _providername + ")";	
    return true;
  }

  _device = kc->readNumEntry("Device", 0);			// Do we still need this ?

  _iploc      = IP(kc->readEntry("LocalIPAddress",  ""));
  _iprem      = IP(kc->readEntry("RemoteIPAddress", ""));
  _subnetmask = IP(kc->readEntry("SubNetMask",      ""));

  _domain     = kc->readEntry("Domain", "");

  un = kc->readEntry("UserName", "");
  pw = kc->readEntry("Password", "");		

  // _username = fromHexString(_cryptbyte, un.data());
  _username = kc->readEntry("UserName", "");
  _password = fromHexString(_cryptbyte, pw.data());

  _assigntype = (kc->readEntry("AssignType", "dynamic") == "dynamic") ? DYNAMIC : STATIC;

  tmp = kc->readEntry("AuthType", "pap");

  if (tmp == "pap") _authtype = PAP;
  else
  {
    if (tmp = "chap") _authtype = CHAP;
    else              _authtype = NONE;
  }

  dnscnt = kc->readNumEntry("NumDNS", 0);

  for (ushort i = 0; i < dnscnt; i++)
  {
    sprintf(buffer, "DNS%i", i);
    _dnslist.append(new IP(kc->readEntry(buffer, "0.0.0.0")));
  }

  _master->load(kc, index, 0);
  kc->setGroup(accgroup);

  _changedacc = (kc->readEntry("AccountHasChanged", "no") == "yes");

  // Loading script execution configuration

  _pastconnect->load(kc, index);
  _pastdisconnect->load(kc, index);

  // Callback parameters

  _callback     = (kc->readEntry("UseCallBack") == "yes");
  _strip0       = (kc->readEntry("StripZeroes") == "yes");
  _cbinit       = (kc->readEntry("CBInit")      == "yes");
  _cbhangup     = (kc->readEntry("CBHangup")    == "yes");

  _ingoingphone = kc->readEntry("IngoingPhone", "");

  _huptime      = kc->readNumEntry("CBHupTime",      0);
  _cbtime       = kc->readNumEntry("CBCallBackTime", 0);

  // Additional options

  _securemode  = (kc->readEntry("SecureMode") == "on") ? ON : OFF;

  _vjcomp      = (kc->readEntry("DisVJCompression")          == "yes");
  _vjconn      = (kc->readEntry("DisVJConnIDOption")         == "yes");
  _adrctrl     = (kc->readEntry("DisAdrFieldCompression")    == "yes");
  _protfld     = (kc->readEntry("DisProtFieldCompression")   == "yes");
  _ipcpaccloc  = (kc->readEntry("IPCPAcceptLocal")           == "yes");
  _ipcpaccrem  = (kc->readEntry("IPCPAcceptRemote")          == "yes");

  return true;	
}


void  AccountData::save(KConfig *kc, uint index)
{
  char     accgroup[16], buffer[16];
  ushort   dnscnt = 0;
  IP       *dns;
  QString  un, pw;

  if (!_enabledacc) return;

  sprintf(accgroup, "Account%i", index);
  kc->setGroup(accgroup);

  // Saving script execution configuration

  _pastconnect->save(kc, index);
  _pastdisconnect->save(kc, index);

  // Values from kcmkisdn

  kc->writeEntry("Provider", _providername);
  kc->writeEntry("Device",   (int) _device);				// Do we still need this ?		

  kc->writeEntry("LocalIPAddress",  _iploc.string());
  kc->writeEntry("RemoteIPAddress", _iprem.string());
  kc->writeEntry("SubNetMask",      _subnetmask.string());

  kc->writeEntry("Domain",   _domain);

  un = toHexString(_cryptbyte, _username.data());
  pw = toHexString(_cryptbyte, _password.data());

  // kc->writeEntry("UserName", un);	
  kc->writeEntry("UserName", _username);	
  kc->writeEntry("Password", pw);			

  kc->writeEntry("AssignType", (_assigntype == DYNAMIC) ? "dynamic" : "static");

  if (_authtype == PAP) kc->writeEntry("AuthType", "pap");
  else
  {
    if (_authtype == CHAP) kc->writeEntry("AuthType", "chap");
    else                   kc->writeEntry("AuthType", "none");
  }

  for (dns = _dnslist.first(); dns != 0L; dns = _dnslist.next())
  {
    sprintf(buffer, "DNS%i", dnscnt++);
    kc->writeEntry(buffer, dns->string());
  }

  kc->writeEntry("NumDNS", (int) dnscnt);

  _master->save(kc, index, 0);

  kc->setGroup(accgroup);

  // Saving account enabled state

  kc->writeEntry("AccountEnabled", _enabledacc ? "yes" : "no" );

  // Callback parameters

  kc->writeEntry("UseCallBack", _callback ? "yes" : "no");
  kc->writeEntry("StripZeroes", _strip0   ? "yes" : "no");
  kc->writeEntry("CBInit",      _cbinit   ? "yes" : "no");
  kc->writeEntry("CBHangup",    _cbhangup ? "yes" : "no");

  kc->writeEntry("IngoingPhone",   _ingoingphone);
  kc->writeEntry("CBHupTime",      _huptime);
  kc->writeEntry("CBCallBackTime", _cbtime);

  // Additional options

  kc->writeEntry("SecureMode",                (_securemode == ON) ? "on"  : "off");

  kc->writeEntry("AccountHasChanged", "no"); 	// Account is now known to kisdn

  kc->writeEntry("DisVJCompression",        _vjcomp     ? "yes" : "no" );
  kc->writeEntry("DisVJConnIDOption",       _vjconn     ? "yes" : "no" );
  kc->writeEntry("DisAdrFieldCompression",  _adrctrl    ? "yes" : "no" );
  kc->writeEntry("DiSProtFieldCompression", _protfld    ? "yes" : "no" );
  kc->writeEntry("IPCPAcceptLocal",         _ipcpaccloc ? "yes" : "no" );
  kc->writeEntry("IPCPAcceptRemote",        _ipcpaccrem ? "yes" : "no" );

  kc->setGroup("General");
  kc->writeEntry("NumAccounts", buffer);	// ?????????????
}


void  AccountData::replaceConnectScripts(ScriptData *s)
{
  delete _pastconnect;
  _pastconnect = s;
}


void  AccountData::replaceDisconnectScripts(ScriptData *s)
{
  delete _pastdisconnect;
  _pastdisconnect = s;
}


ScriptData::ScriptData(ScriptData& scr) : _exectime(scr.executionTime()),
                                          _enabled(scr.isEnabled()),
		                          _pastexec(scr.pastExecution())
{
  const char  *s;
  char        *c;

  _scripts.clear();

  // Make a deep copy of the script

  for (s = scr.firstLine(); s != 0L; s = scr.nextLine())
  {
    c = new char[strlen(s)+1];

    _scripts.append(strcpy(c, s));
  }
}


bool  ScriptData::load(KConfig *kc, uint accindex)
{
  /*
   * Syntax is String_%a_%b_%c :
   * where a = account
   *       b = script-index (after connect, after disconnect...
   *       c = counter of scripts
   *************************************************************/

  QString  tmp;
  uint     scnt;

  tmp.sprintf("ScriptsEnabled_%i_%i", accindex, _exectime);
  _enabled = (kc->readEntry(tmp.data(), "no") == "yes");

  tmp.sprintf("ScriptsDoAfterExecution_%i_%i", accindex, _exectime);
  _pastexec = (kc->readEntry(tmp.data(), "no") == "yes");

  // Load all the scripts

  _scripts.clear();
  tmp.sprintf("NumScripts_%i_%i", accindex, _exectime);
  scnt = kc->readNumEntry(tmp.data(), 0);

  for (uint idx = 0; idx < scnt; idx++)
  {
    tmp.sprintf("Script_%i_%i_%i", accindex, _exectime, idx);
    _scripts.append(kc->readEntry(tmp));
  }

  return true;
}


void  ScriptData::save(KConfig *kc, uint accindex)
{
  QString tmp;

  uint cnt = _scripts.count();

  tmp.sprintf("NumScripts_%i_%i", accindex, _exectime);
  kc->writeEntry(tmp.data(), cnt);

  tmp.sprintf("ScriptsEnabled_%i_%i", accindex, _exectime);
  kc->writeEntry(tmp.data(), _enabled ? "yes" : "no" );

  tmp.sprintf("ScriptsDoAfterExecution_%i_%i", accindex, _exectime);
  kc->writeEntry(tmp.data(), _pastexec ? "yes" : "no" );

  // Save all the scripts
  for (uint idx = 0; idx < cnt; idx++)
  {
    tmp.sprintf("Script_%i_%i_%i", accindex, _exectime, idx);
    kc->writeEntry(tmp, _scripts.at(idx));
  }
}


void  ScriptData::dump()
{
  const char  *s;

  cout << endl;

  for (s = _scripts.first(); s != 0L; s = _scripts.next())
    cout << "[" << s << "]" << endl;

  cout << endl;
}


bool  AdvancedOptions::load(KConfig *kc)
{
  kc->setGroup("AdvancedIPPPDOptions");

  _bsdcomp  = (kc->readEntry("DisableBSDCompression") == "yes" );
  _incdebug = (kc->readEntry("IncreaseDebugLevel") == "yes" );

  _dbglevel = kc->readNumEntry("KernelDebugLevel", 0);
  _mru      = kc->readNumEntry("MaxReceiveUnit", 0);
  _mtu      = kc->readNumEntry("MaxTransferUnit", 0);

  return true;
}


GeneralData::GeneralData() : _ipppdpath("/sbin/ipppd"),
                             _prefix(""),
			     _msndata(""),
			     _modprobepath("/sbin/modprobe"),
			     _membase("0x0000"),
			     _iobase0("0x0000"),
			     _iobase1("0x0000"),
			     _adapter(4),
			     _interrupt(5),
			     _protocol(PROT_EDSS1),
			     _loadasmodule(false),
			     _enableiface(false),
			     _ipupdown(false)
{
  _advanced = new AdvancedOptions();
}


GeneralData::GeneralData(GeneralData& gen) : _ipppdpath(gen.ipppdPath()),
                                             _prefix(gen.prefix()),
			                     _msndata(gen.msnData()),
			                     _modprobepath(gen.modprobePath()),
			                     _membase(gen.memBaseAddress()),
			                     _iobase0(gen.ioAddress1()),
			                     _iobase1(gen.ioAddress2()),
			                     _adapter(gen.adapterType()),
			                     _interrupt(gen.interrupt()),
			                     _protocol(gen.protocol()),
			                     _loadasmodule(gen.loadAsModule()),
					     _enableiface(gen.enableInterface()),
					     _ipupdown(gen.bufferIpUpDown())
{
  _advanced = new AdvancedOptions(*(gen.advancedOptions()));
}


GeneralData::~GeneralData()
{
  delete _advanced;
}


bool  GeneralData::load(KConfig *kc)
{
  kc->setGroup("General");

  _ipppdpath    = kc->readEntry("IpppdPath",   "/sbin/ipppd");
  _prefix       = kc->readEntry("Prefix",                 "");
  _msndata      = kc->readEntry("MsnForDataConnections",  "");

  _loadasmodule = (kc->readEntry("LoadDriverAsModule")             == "yes");
  _enableiface  = (kc->readEntry("ExplicitelyEnableInterface")     == "yes");
  _ipupdown     = (kc->readEntry("OverrideIpUpDown")               == "yes");
  
  if (_loadasmodule)
  {
    _modprobepath =                kc->readEntry("ModprobePath", "/sbin/modprobe");
    _iobase0      =                kc->readEntry("IOBase0",      "0x0000");
    _iobase1      =                kc->readEntry("IOBase1",      "0x0000");
    _membase      =                kc->readEntry("MemBase",      "0x0000");
    _adapter      =                kc->readNumEntry("Adapter",   4);
    _interrupt    =                kc->readNumEntry("Interrupt", 5);
    _protocol     = (dchannelprot) kc->readNumEntry("Protocol",  1);
  }

  _advanced->load(kc);

  return true;
}


CustomData::CustomData() : _firsttimeuser(true),
                           _showhisaxdetect(true),
                           _dialondemand(false),
			   _disconnect(true),
                           _docking(false),
			   _sessiondocked(false),
                           _showsplash(true),
                           _soundonauth(false),
			   _audioconnect(false),
                           _audiodisconnect(false),
			   _audiodialing(false),
                           _audiobusy(false),
                           _audioscripts(false)

{
  QString  sounddir = kapp->kde_datadir()+"/kisdn/sounds";

  _wavonlinepath  = sounddir + "/established.wav";
  _wavofflinepath = sounddir + "/closed.wav";
  _wavdialingpath = sounddir + "/dialing.wav";
  _wavbusypath    = sounddir + "/busy.wav";
  _wavscriptspath = sounddir + "/ding.wav";
}


bool  CustomData::load(KConfig *kc)
{
  QString  sounddir = kapp->kde_datadir()+"/kisdn/sounds";

  kc->setGroup("Customization");

  _firsttimeuser     = (kc->readEntry("FirstTimeUser",     "yes") == "yes");
  _showsplash        = (kc->readEntry("ShowSplashScreen",  "yes") == "yes");

  _showhisaxdetect   = (kc->readEntry("ShowHiSaxDetection")   == "yes");
  _dialondemand      = (kc->readEntry("DialOnDemand")         == "yes");
  _docking           = (kc->readEntry("DockInPanel")          == "yes");
  _sessiondocked     = (kc->readEntry("SessionDocked" )       == "yes");
  _disconnect        = (kc->readEntry("DisconnectOnShutdown") == "yes");
  _soundonauth       = (kc->readEntry("SoundOnAuthenticated") == "yes");

  _audioconnect      = (kc->readEntry("EnableAudioConnect")         == "yes");
  _audiodisconnect   = (kc->readEntry("EnableAudioDisconnect")      == "yes");
  _audiodialing      = (kc->readEntry("EnableAudioDialing")         == "yes");
  _audiobusy         = (kc->readEntry("EnableAudioBusy")            == "yes");
  _audioscripts      = (kc->readEntry("EnableAudioScriptsFinished") == "yes");

  _wavonlinepath     = kc->readEntry("WavConnect",         sounddir+"/established.wav");
  _wavofflinepath    = kc->readEntry("WavDisconnect",      sounddir+"/closed.wav");
  _wavdialingpath    = kc->readEntry("WavDialing",         sounddir+"/dialing.wav");
  _wavbusypath       = kc->readEntry("WavBusy",            sounddir+"/busy.wav");
  _wavscriptspath    = kc->readEntry("WavScriptsFinished", sounddir+"/ding.wav");

  return true;
}


void  CustomData::save(KConfig *kc)
{
  kc->setGroup("Customization");

  kc->writeEntry("FirstTimeUser", "no");

  kc->writeEntry("ShowHiSaxDetection",   _showhisaxdetect   ? "yes" : "no");
  kc->writeEntry("DialOnDemand",         _dialondemand      ? "yes" : "no");
  kc->writeEntry("DockInPanel",          _docking           ? "yes" : "no");
  kc->writeEntry("DisconnectOnShutdown", _disconnect        ? "yes" : "no");
  kc->writeEntry("ShowSplashScreen",     _showsplash        ? "yes" : "no");
  kc->writeEntry("SoundOnAuthenticated", _soundonauth       ? "yes" : "no");

  kc->writeEntry("EnableAudioConnect",         _audioconnect    ? "yes" : "no");
  kc->writeEntry("EnableAudioDisconnect",      _audiodisconnect ? "yes" : "no");
  kc->writeEntry("EnableAudioDialing",         _audiodialing    ? "yes" : "no");
  kc->writeEntry("EnableAudioBusy",            _audiobusy       ? "yes" : "no");
  kc->writeEntry("EnableAudioScriptsFinished", _audioscripts    ? "yes" : "no");

  kc->writeEntry("WavConnect",         _wavonlinepath);
  kc->writeEntry("WavDisconnect",      _wavofflinepath);
  kc->writeEntry("WavDialing",         _wavdialingpath);
  kc->writeEntry("WavBusy",            _wavbusypath);
  kc->writeEntry("WavScriptsFinished", _wavscriptspath);
}


ScannerData::ScannerData() : _scana(true),
			     _scanb(false),
			     _scanrec(true),
			     _scantra(true),
			     _scantot(false),
			     _showstamps(true),
			     _dottedlines(true),
			     _scanrate(2),
			     _scalingpolicy(DYNAMIC),
			     _scaledist(25),
			     _scalerange(100),
			     _scalecolor(QColor::QColor(lightGray))
{
  for (ushort c = 0; c < 2; c++)
  {
    _graphcolor[c][0] = QColor::QColor(green);
    _graphcolor[c][1] = QColor::QColor(red);
    _graphcolor[c][2] = QColor::QColor(yellow);
  }
}


bool  ScannerData::load(KConfig *kc)
{
  kc->setGroup("ScannerOptions");

  _scana       = (kc->readEntry("ScanChannelA")   == "yes");
  _scanb       = (kc->readEntry("ScanChannelB")   == "yes");
  _scanrec     = (kc->readEntry("ScanReceive")    == "yes");
  _scantra     = (kc->readEntry("ScanTransmit")   == "yes");
  _scantot     = (kc->readEntry("ScanTotal")      == "yes");
  _showstamps  = (kc->readEntry("ShowStamps")     == "yes");
  _dottedlines = (kc->readEntry("DottedDivision") == "yes");

  _scanrate      =                 kc->readNumEntry("ScanRate",          2);
  _scaledist     = (float)         kc->readNumEntry("ScaleLineDistance", 25);
  _scalerange    = (float)         kc->readNumEntry("ScaleRange",        100);
  _scalingpolicy = (scalingpolicy) kc->readNumEntry("ScalingPolicy",     DYNAMIC);

  /* Scanner colors */

  char     buffer[20];
  QString  tmp = "";
  ushort   c;

  for (ushort b = 0; b < 3; b++)
  {
    for (c = 0; c < 2; c++)
    {
      sprintf(buffer, "GraphColor_%i_%i", b, c);
      tmp = kc->readEntry(buffer, 0L);

      if (!tmp.isNull()) _graphcolor[c][b].setNamedColor(tmp);
    }
  }

  tmp = kc->readEntry("DivisionColor", 0L);

  if (!tmp.isNull()) _scalecolor.setNamedColor(tmp);

  return true;
}


void  ScannerData::save(KConfig *kc)
{
  kc->setGroup("ScannerOptions");

  kc->writeEntry("ScanChannelA",   _scana       ? "yes" : "no");
  kc->writeEntry("ScanChannelB",   _scanb       ? "yes" : "no");
  kc->writeEntry("ScanReceive",    _scanrec     ? "yes" : "no");
  kc->writeEntry("ScanTransmit",   _scantra     ? "yes" : "no");
  kc->writeEntry("ScanTotal",      _scantot     ? "yes" : "no");
  kc->writeEntry("ShowStamps",     _showstamps  ? "yes" : "no");
  kc->writeEntry("DottedDivision", _dottedlines ? "yes" : "no");

  kc->writeEntry("ScanRate",          (int) _scanrate);
  kc->writeEntry("ScaleLineDistance", (int) _scaledist);
  kc->writeEntry("ScaleRange",        (int) _scalerange);
  kc->writeEntry("ScalingPolicy",     (int) _scalingpolicy);

  /* Scanner colors */

  char     buffer[20];
  QString  color(10);
  ushort   c;

  for (ushort b = 0; b < 3; b++)
  {
    for (c = 0; c < 2; c++)
    {
      color.sprintf("#%02x%02x%02x",  _graphcolor[c][b].red(),
                                      _graphcolor[c][b].green(),
                                      _graphcolor[c][b].blue());

      sprintf(buffer, "GraphColor_%i_%i", b, c);
      kc->writeEntry(buffer, color);
    }
  }

  color.sprintf("#%02x%02x%02x",  _scalecolor.red(),
                                  _scalecolor.green(),
                                  _scalecolor.blue());
				
  kc->writeEntry("DivisionColor", color);
}


kISDNData::kISDNData() : _accindex(0),
                         _accloaded(0),
			 _numacc(0)
{
  _acclist.setAutoDelete(true);
  _acclist.clear();

  _general = new GeneralData();
  _custom  = new CustomData();
  _scanner = new ScannerData();
}


kISDNData::kISDNData(kISDNData& dta) : _accindex(dta.accountIndex()),
                                       _accloaded(dta.accountsLoaded()),
			               _numacc(dta.numberAccounts()),
				       _rcrevision(dta.rcRevision())
{
  AccountData  *acc;

  _acclist.setAutoDelete(true);
  _acclist.clear();

  _general = new GeneralData(*(dta.generalData()));
  _custom  = new CustomData(*(dta.customData()));
  _scanner = new ScannerData(*(dta.scannerData()));

  // Make a deep copy of the account list

  for (acc = dta.firstAccount(); acc != 0L; acc = dta.nextAccount())
    _acclist.append(new AccountData(*acc));
}


kISDNData::~kISDNData()
{
  delete _general;
  delete _custom;
  delete _scanner;
}


bool  kISDNData::load()
{
  KConfig      *kc = kapp->getConfig();
  bool         genloadsuccess, custloadsuccess;
  bool         accloadsuccess = true, scanloadsuccess;
  AccountData  *acc;

  kc->setGroup("Configuration");
  _accindex   = kc->readNumEntry("ISP", 0);
  _rcrevision = kc->readEntry("Revision", "0.0.0.0");
  if ( _rcrevision != KISDNVERSION )
  {
    KisdnCompat compat;
    compat.ensureCompatibility( kc );
  }

  genloadsuccess  = _general->load(kc);
  custloadsuccess = _custom->load(kc);
  scanloadsuccess = _scanner->load(kc);

  kc->setGroup("General");

  _numacc = kc->readNumEntry("NumAccounts", 0);

  _accloaded = 0;

  for (int i = 0; (i < _numacc) && accloadsuccess; i++)
  {
    acc = new AccountData();

    accloadsuccess = accloadsuccess && acc->load(kc, i);

    if (accloadsuccess)
    {
      _acclist.append(acc);
      _accloaded++;
    }
  }

  return (genloadsuccess && custloadsuccess && scanloadsuccess && accloadsuccess);
}


void  kISDNData::save()
{
  KConfig      *kc  = kapp->getConfig();
  AccountData  *acc;

  _numacc = 0;

  kc->setGroup("Configuration");

  kc->writeEntry("ISP",      _accindex);
  kc->writeEntry("Revision", KISDNVERSION);

  _custom->save(kc);
  _scanner->save(kc);

  for (acc = _acclist.first(); acc != 0L; acc = _acclist.next()) acc->save(kc, _numacc++);

  kc->setGroup("General");

  kc->writeEntry("NumAccounts", _numacc);
  kc->sync();
}


void  kISDNData::replaceCustomData(CustomData *custom)
{
  delete _custom;
  _custom = custom;
}


void  kISDNData::replaceScannerData(ScannerData *scanner)
{
  delete _scanner;
  _scanner = scanner;
}


void  kISDNData::saveSession()
{
  KConfig  *kc = kapp->getConfig();

  kc->setGroup("Customization");

  kc->writeEntry("SessionDocked", _custom->sessionDocked() ? "yes" : "no");
  kc->writeEntry("DialOnDemand",  _custom->dialOnDemand()  ? "yes" : "no");

  kc->sync();
}

