/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

#include "prefdlg.h"
#include "general.h"

GeneralWidget::GeneralWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  uint margin 	= 10;
  uint top    	= margin+70;
  uint labeltop = top+4;
  uint left  	= margin+10;
  uint right    = 340-margin;
  uint middle 	= 180;
  uint height 	= 24;
  uint mini  	= 5;
  uint next;

  GenData  *gen = ISDNData.General;

  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 340, 314);
  GBox->setTitle(i18n("General Setup"));

  prefixlabel = new QLabel(i18n("Prefix:"), GBox);
  prefixlabel->adjustSize();
  prefixlabel->move(middle-prefixlabel->width()-10, labeltop);

  next = prefixlabel->height()+margin+6;

  prefix = new QLineEdit(GBox);
  prefix->setGeometry(middle, top, middle-20, height);
  prefix->setMaxLength(PNUMSIZE);

  Protlabel = new QLabel(i18n("D Channel Protocol:"), GBox);
  Protlabel->adjustSize();
  Protlabel->move(middle-Protlabel->width()-10, labeltop+next);

  Protobox = new QComboBox(false, GBox);
  Protobox->insertItem("1TR6");
  Protobox->insertItem("Euro ISDN (EDSS1)");
  Protobox->insertItem(i18n("Leased Line"));

  uint item = gen->protocol;

  Protobox->setCurrentItem(item);
  Protobox->adjustSize();
  Protobox->setGeometry(middle, top+next, middle-20, height);
  connect(Protobox, SIGNAL(activated(int)), SLOT(slotProtocolChanged(int)));

  msnlabelData = new QLabel(i18n("MSN for data connections:"), GBox);
  msnlabelData->adjustSize();
  msnlabelData->move(middle-msnlabelData->width()-10, labeltop+2*next);

  msnData = new QLineEdit(GBox);
  msnData->setGeometry(middle, top+2*next, middle-20, height);
  msnData->setMaxLength(PNUMSIZE);

  eazlabel = new QLabel(i18n("EAZ:"), GBox);
  eazlabel->adjustSize();
  eazlabel->move(middle-eazlabel->width()-10, labeltop+4*next);

  eaz = new QLineEdit(GBox);
  eaz->setGeometry(middle, top+4*next, middle-20, height);
  eaz->setMaxLength(1);

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap linux_xpm = loader->loadIcon("linux.xpm");

  pmLinux = new QLabel(this);
  pmLinux->setPixmap(linux_xpm);
  pmLinux->setGeometry(272, 30, 41,48);

  ipppdpathlabel = new QLabel(i18n("ipppd Path:"), GBox);
  ipppdpathlabel->adjustSize();
  ipppdpathlabel->move(middle-ipppdpathlabel->width()-10, labeltop+5*next);

  ipppdpath = new QLineEdit(GBox);
  ipppdpath->setGeometry(middle, top+5*next, middle-50, height);
  ipppdpath->setMaxLength(PATHSIZE);

  browse = new QPushButton(i18n("..."), GBox);
  browse->setGeometry(middle+ipppdpath->width()+mini, top+5*next, 25, height);
  connect(browse, SIGNAL(clicked()), SLOT( slotBrowseIpppd()));

  QString tmp = i18n("Allow all users to notice incoming calls");
  cacb = new QCheckBox(tmp.data(), GBox);
  cacb->adjustSize();
  cacb->move(left, top+7*next-8);

  tmp = i18n("Disable /etc/ppp/ip-up and ip-down");
  checkIpUp = new QCheckBox( tmp, GBox );
  checkIpUp->adjustSize();
  checkIpUp->move( left, top+8*next-8 );
  
  QString tmp2 = i18n("Explicitely enable and disable interface");
  checkExplicit = new QCheckBox( tmp2.data(), GBox);
  checkExplicit->adjustSize();
  checkExplicit->move(left, top+9*next-18);
  checkExplicit->setEnabled( checkForTimRuExtensions() );

  advanced = new QPushButton(i18n("Advanced..."), GBox);
  advanced->setGeometry(right-100, top+10*next, 100, height);
  connect(advanced, SIGNAL(clicked()), SLOT(slotAdvanced()));

  slotProtocolChanged(item);
  refreshSettings();
}


void GeneralWidget::slotAdvanced()
{
  AdvancedDlg = new LogoTabDialog("millenniumx.gif", (QWidget *) 0,
				  (const char *) 0);
  AdvancedDlg->setCaption(i18n("Advanced kISDN Options"));
  AdvancedDlg->setCancelButton();
  AdvancedDlg->resize(365, 406);
  AdvancedDlg->setFixedSize(365, 406);

  Debug = new DebugWidget(AdvancedDlg);
  Units = new UnitsWidget(AdvancedDlg);

  AdvancedDlg->addTab(Debug, i18n("Debug"));
  AdvancedDlg->addTab(Units, i18n("Units"));

  AdvData *adv = &((ISDNData.General)->Advanced);

  adv->Backup();
  bool okpressed = AdvancedDlg->exec();

  if (!okpressed) adv->Restore();
  else
  {
    adv->dbglevel = atoi((Debug->Debuglevel)->text());
    adv->mru      = atoi((Units->MRU)->text());
    adv->mtu      = atoi((Units->MTU)->text());
  }

  delete AdvancedDlg;
}


void GeneralWidget::slotBrowseIpppd()
{
  QString  IpppdSel;

  KFileDialog *Browser = new KFileDialog("/sbin", "ipppd", this, "", true);
  Browser->setCaption(i18n("Choose ipppd Path"));

  if (Browser->exec() == QDialog::Accepted) IpppdSel = Browser->selectedFile();

  if (!IpppdSel.isNull())
  {
    ipppdpath->setText(IpppdSel.data());
    // emit a SIGNAL here ?
  }

  delete Browser;
}


void GeneralWidget::slotProtocolChanged(int protocol)
{
  bool  eazState;

  (ISDNData.General)->protocol = protocol;

  eazState = (protocol == 0);

  msnData->setEnabled(!eazState);
  eaz->setEnabled(eazState);
}


void GeneralWidget::refreshSettings()
{
  GenData  *gen = ISDNData.General;

  prefix->setText(gen->prefix.data());
  ipppdpath->setText(gen->ipppdpath.data());
  msnData->setText(gen->msnData.data());
  checkExplicit->setChecked( gen->explicitEnable );
  checkIpUp->setChecked( gen->disableIpUpDown );
}


bool GeneralWidget::checkForTimRuExtensions()
{
  QString  path     = "/usr/src/linux/include/linux/isdn.h";
  bool     hastimru = false;
  FILE     *fhandle;
  char     buffer[14];
  char     search[] = "int  stopped;";
  int      i;

  if ((fhandle = fopen(path.data(), "r")))
  {
    fgets(buffer, 14, fhandle);

    while (!feof(fhandle) && !hastimru)
    {
      if (!strcmp(search, buffer)) hastimru = true;
      else
      {
        for (i = 1; i < 13; i++) buffer[i-1] = buffer[i];

        buffer[12] = fgetc(fhandle);
      }
    }

    fclose(fhandle);

    if (hastimru) ::message("Recent HiSax driver");
    else          ::message("Standard HiSax driver");
  }
  else cout << "KISDN: Can't open " << path.data() << " (assume standard HiSax)" << endl;

  return hastimru;
}


QSize GeneralWidget::minimumSize()
{
  QSize s(328, 314); // fix this!
  return s;
}


void GeneralWidget::resizeEvent( QResizeEvent * )
{
  ushort margin = 10;
  uint   w      = width();
  uint   h      = height();
  uint   middle = (w-2*margin)/2;

  GBox->resize(w-2*margin, h-2*margin);
  pmLinux->move(w-2*margin-pmLinux->width()-4, pmLinux->y());

  prefixlabel->move(middle-prefixlabel->width()-10, prefixlabel->y());
  prefix->move(middle, prefix->y());
  prefix->resize(middle-2*margin, prefix->height());

  Protlabel->move(middle-Protlabel->width()-10, Protlabel->y());
  Protobox->move(middle, Protobox->y());
  Protobox->resize(middle-2*margin, Protobox->height());

  msnlabelData->move(middle-msnlabelData->width()-10, msnlabelData->y());
  msnData->move(middle, msnData->y());
  msnData->resize((middle-2*margin)/2, msnData->height());

  eazlabel->move(middle-eazlabel->width()-10, eazlabel->y());
  eaz->move(middle, eaz->y());
  eaz->resize(middle-2*margin, eaz->height());

  ipppdpathlabel->move(middle-ipppdpathlabel->width()-10, ipppdpathlabel->y());
  ipppdpath->move(middle, ipppdpath->y());
  ipppdpath->resize(middle-2*margin-30, ipppdpath->height());

  browse->move(w-2*margin-45, browse->y());

  advanced->move(w-2*margin-115, h-2*margin-39);
}
