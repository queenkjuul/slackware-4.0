/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include "accdlg.h"


IPWidget::IPWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  QSize    size;
  int      wd, hg;
  AccData  *acc = ISDNData.Temp;
  
  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 316);
  GBox->setTitle(i18n("IP Setup"));

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap mail_xpm = loader->loadIcon("mail.xpm");

  pmMail = new QLabel(this);
  pmMail->setPixmap(mail_xpm);
  pmMail->setGeometry(275, 30, 47, 25);

  IPGBox = new QGroupBox(this);
  IPGBox->setGeometry(35, 77, 275, 134);
  IPGBox->setTitle("        ");
  
  IPGroup = new QButtonGroup(this);
  IPGroup->setLineWidth(0);
  IPVBox = new QVBoxLayout(IPGroup, 10);
  IPGroup->move(44, 36);

  DynButton = new QRadioButton(IPGroup);
  DynButton->setText(i18n("Dynamic IP Address"));
  DynButton->setChecked(acc->ipdynamic);
  IPVBox->addWidget(DynButton);
  DynButton->setMinimumSize(DynButton->sizeHint());
  
  StatButton = new QRadioButton(IPGroup);
  StatButton->setText(i18n("Static IP Address"));
  StatButton->setChecked(!acc->ipdynamic);
  IPVBox->addWidget(StatButton);
  StatButton->setMinimumSize(StatButton->sizeHint());
  
  IPVBox->activate();

  connect(IPGroup, SIGNAL(clicked(int)), SLOT(slotRButtonClicked(int))); 

  IPloclabel = new QLabel(i18n("Local IP Address:"), this);
  size = IPloclabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  IPloclabel->setGeometry(180-wd, 100+(24-hg)/2, wd, hg);

  IPremlabel = new QLabel(i18n("Remote IP Address:"), this);
  size = IPremlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  IPremlabel->setGeometry(180-wd, 132+(24-hg)/2, wd, hg); 
  
  Masklabel = new QLabel(i18n("Subnet Mask:"), this);
  size = Masklabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Masklabel->setGeometry(180-wd, 170+(24-hg)/2, wd, hg);
  
  IPloc = new QLineEdit(this);
  IPloc->setGeometry(190, 100, 100, 24);
  IPloc->setMaxLength(IPNMSIZE);
 
  IPrem = new QLineEdit(this);
  IPrem->setGeometry(190, 132, 100, 24);
  IPrem->setMaxLength(IPNMSIZE);

  Mask = new QLineEdit(this);
  Mask->setGeometry(190, 170, 100, 24);
  Mask->setMaxLength(IPNMSIZE);
  
  setIPStatic(!acc->ipdynamic);
}


void IPWidget::setIPStatic(bool IPstatic)
{
  AccData  *acc = ISDNData.Temp;
  
  IPloclabel->setEnabled(IPstatic);
  IPloc->setEnabled(IPstatic);
  IPremlabel->setEnabled(IPstatic);
  IPrem->setEnabled(IPstatic);
  Masklabel->setEnabled(IPstatic);
  Mask->setEnabled(IPstatic);
  
  if (!IPstatic)
  {
    IPloc->setText("0.0.0.0");
    IPrem->setText("0.0.0.0");
    Mask->setText("0.0.0.0");
  }
  else
  {
    IPloc->setText(acc->iplocaddress.data());
    IPrem->setText(acc->ipremaddress.data());
    Mask->setText(acc->subnetmask.data());
  }
}


void IPWidget::slotRButtonClicked(int Button)
{
  AccData  *acc     = ISDNData.Temp;  
  bool     IPstatic = (bool) Button;
  
  acc->ipdynamic = !IPstatic;
  
  if (IPstatic)
  {
    acc->iplocaddress  = "";
    acc->ipremaddress  = "";
    acc->subnetmask    = "";
  }
  
  setIPStatic(IPstatic);
}  

void IPWidget::resizeEvent(QResizeEvent *)
{
  ushort margin = 10;
  uint w = width();
  uint h = height();

  GBox->resize(w-2*margin, h-2*margin);
  pmMail->move(w-2*margin-pmMail->width()-4, pmMail->y());
} 
