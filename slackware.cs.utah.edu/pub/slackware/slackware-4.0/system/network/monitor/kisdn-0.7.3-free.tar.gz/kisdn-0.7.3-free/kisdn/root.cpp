/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

/**
 * some tiny functions to gain / drop root privileges
 */

#include <unistd.h>
#include <stdio.h>

#include "root.h"

int _startUid = -1; // calling set[e]uid with -1 keeps the current uid

bool hasRootPrivileges()
{
  if ( geteuid() == 0 && getuid() == 0 )
    return true;

  else
    return false;
}


bool becomeRoot()
{
  if ( hasRootPrivileges() )
  {
    return true;
  }
  
  else
  {
    if ( _startUid == -1 )
    {
      _startUid = getuid(); // save original uid, who started the process
    }
    
    int ret = setuid( 0 );
    return ( ret == 0 );
  }
}


bool dropRoot()
{
  if ( hasRootPrivileges() )
  {
    int ret = seteuid( _startUid ); // set to real uid, who started the process
    return ( ret == 0 );
  }
  
  else // we don't have root privileges anyway
    return true;
}
