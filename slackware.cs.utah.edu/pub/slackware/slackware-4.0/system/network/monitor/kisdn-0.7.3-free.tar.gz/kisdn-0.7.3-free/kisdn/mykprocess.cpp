#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "mykprocess.h"


MyKProcess::MyKProcess() : KProcess()
{
  myUid = 0;
}


bool MyKProcess::start( RunMode runmode, Communication comm )
{
 uint n = arguments.count();
 char **arglist;

 if ( runs || n == 0 )
   return false;

 run_mode = runmode;
 status = 0;

 arglist = (char **) malloc( (n+1) * sizeof( char * ) );
 for ( uint i = 0; i < n; i++ )
   arglist[i] = arguments.at( i );

 arglist[n] = 0;

 if ( !setupCommunication( comm ) )
   debug("Communication setup failed");

 runs = true;

 pid = fork();

 switch( pid )
 {
 // child
 case 0:
 {
   if ( myUid != 0 ) {
     int k = setuid( myUid );

     if ( k < 0 && (getuid() == (uid_t) 0 || geteuid() == (uid_t) 0) ) {
       debug( "*** Warning: could not release root-rights. Aborting process.");
       exit( 1 );
     }
   }
   
   if ( !commSetupDoneC() )
     debug("Communication setup in child failed" );

   if ( run_mode == DontCare )
     setpgrp();

   execvp( arglist[0], arglist );
   perror( "cannot execute" );
   exit( 1 );
 }

 // error in fork
 case -1:
 {
   runs = false;
   free( arglist );
   return false;
 }

 default:
 {
   if ( !commSetupDoneP() )
     debug( "Communication Setup in Parent failed" );

   input_data = 0;

   if ( run_mode == Block )
   {
     waitpid( pid, &status, 0 );
     processHasExited( status );
   }
 }
 }

 free( arglist );
 return true;
}
