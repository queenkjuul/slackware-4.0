/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: ledpanel.cpp,v 1.2 1998/11/21 12:34:49 twesthei Exp $
//
// $Log: ledpanel.cpp,v $
// Revision 1.2  1998/11/21 12:34:49  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include <stdio.h>

#include <kapp.h>

#include "ledpanel.h"


LEDPanel::LEDPanel(QWidget *parent, const char *name) : QWidget(parent, name)
{
  QSize  size;
  int    wd;
  
  setFixedSize(136, 91);
  Label1 = new QLabel("A", this);			
  Label1->move(0, 23);					
  Label2 = new QLabel("B", this);
  Label2->move(0, 53);
  Label3 = new QLabel(i18n("Dial"), this);
  size   = Label3->sizeHint();
  wd     = size.width();
  Label3->move(28-wd/2, 0); 
  Label4 = new QLabel(i18n("Con"), this);
  size   = Label4->sizeHint();
  wd     = size.width();
  Label4->move(58-wd/2, 0);
  Label5 = new QLabel(i18n("Tx"), this);
  Label5->move(81, 0);
  Label6 = new QLabel(i18n("Rx"), this);
  Label6->move(106, 0);
  
  for (ushort ch = 0; ch < 2; ch++)
  {
    Led[ch][0] = new LED(YELLOW, 20, 31+ch*30, this);
    Led[ch][1] = new LED(GREEN, 50, 31+ch*30, this);
    Led[ch][2] = new LED(RED, 80, 31+ch*30, this);
    Led[ch][3] = new LED(RED, 105, 31+ch*30, this);
  }
}


void LEDPanel::setLEDState(ushort ch, ushort type, ushort state)
{
  LED *led = Led[ch][type];
  if (state == ON) led->set();    
  else led->clear();
}


void LEDPanel::ToggleLED(ushort ch, ushort type)
{
  LED *led = Led[ch][type];
  
  if (led->LEDstate() == ON) led->clear();
  else led->set();
}  

