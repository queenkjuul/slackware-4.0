/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: execwidget.cpp,v 1.2 1998/11/21 12:34:36 twesthei Exp $
//
// $Log: execwidget.cpp,v $
// Revision 1.2  1998/11/21 12:34:36  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <qstrlist.h>
#include <qtooltip.h>

#include "execwidget.h"
#include "minsize.h"


ExecWidget::ExecWidget(QString firstChBox, QString secondChBox, ScriptData *_sdata,
                       QWidget *parent, const char *name) : QWidget(parent, name),
		                                            sdata(_sdata)
{
  KIconLoader     *loader  = kapp->getIconLoader();
  static QPixmap  exec_xpm = loader->loadIcon("screxec.xpm");

  groupbox = new QGroupBox(this);
  groupbox->setTitle(i18n("Script processing"));

  pmExec = new QLabel(groupbox);
  pmExec->setPixmap(exec_xpm);
  pmExec->adjustSize();

  if (!firstChBox.isEmpty())
  {
    execCheck = new QCheckBox(i18n(firstChBox.data()), groupbox);
    execCheck->adjustSize();
    execCheck->setChecked(sdata->isEnabled());
    connect(execCheck, SIGNAL(clicked()), SLOT(slotEnableExecution()));
  }

  execLabel = new QLabel(i18n("Commandline:"), groupbox);
  execLabel->adjustSize();

  execEdit = new QLineEdit(groupbox);
  execEdit->adjustSize();
  execEdit->setMaxLength( PATHSIZE );
  QToolTip::add(execEdit, i18n("You can also drop files from KFM onto the list"));

  addButton = new QPushButton(i18n("Add"), groupbox);
  addButton->adjustSize();
  connect(addButton, SIGNAL(clicked()), SLOT(slotAddCommandLine()));

  execListLabel = new QLabel(i18n("Commandlist:"), groupbox);
  execListLabel->adjustSize();

  execList = new QListBox(groupbox);
  execList->adjustSize();

  editButton = new QPushButton( i18n("Edit..."), groupbox);
  editButton->adjustSize();
  connect(editButton, SIGNAL(clicked()), SLOT(slotEditCommandLine()));

  remButton = new QPushButton( i18n( "Remove" ), groupbox);
  remButton->adjustSize();
  connect(remButton, SIGNAL(clicked()), SLOT(slotRemoveCommandLine()));

  if (!secondChBox.isEmpty())
  {
    secondCheckBox = true;

    discCheck = new QCheckBox(i18n(secondChBox.data()), groupbox);
    discCheck->adjustSize();
    discCheck->setChecked(sdata->pastExecution());
    connect(discCheck, SIGNAL(clicked()), SLOT(slotExecDisconnect()));
  }
  else secondCheckBox = false;

  KDNDDropZone *dropZone = new KDNDDropZone(groupbox, DndURL);
  connect(dropZone, SIGNAL(dropAction(KDNDDropZone *)), this, SLOT(slotDropEvent(KDNDDropZone *)));

  execEdit->setFocus();

  refreshListBox();
  slotEnableExecution();

  setMinimumSize(MINSIZEX, MINSIZEY);
}


void ExecWidget::slotAddCommandLine()
{
  QString  commandLine = execEdit->text();

  if (commandLine.isEmpty()) return;

  execList->insertItem(commandLine);
  execEdit->setText("");
  execEdit->setFocus();
}


void ExecWidget::slotEditCommandLine()
{
  int  index = execList->currentItem();

  if (index > -1)
  {
    execEdit->setText(execList->text(index));
    slotRemoveCommandLine();
  }
}


void ExecWidget::slotRemoveCommandLine()
{
  int  index = execList->currentItem();  // the highlighted line

  if (index > -1) execList->removeItem(index);
}


void ExecWidget::slotDropEvent( KDNDDropZone *dropZone )
{
  QStrList&  urlList = dropZone->getURLList();
  QString    filename;		
  QString    url, tmp;

  for (url = urlList.first(); url != 0; url = urlList.next())
  {
    if (url.right(1) == "/") 		// Refuse directories
    {
      tmp  = i18n("You can't drop directories\n");
      tmp += i18n("onto the filelist!\n\n");

      QMessageBox::warning(this, i18n("kISDN Drop Error"), tmp);

      return;
    }
    else 	
    {
      if (url.left(5) == "file:")	// Cut URL prefix "file:"
      {
        filename = url.right((int) url.length()-5);
	if ( filename.length() <= PATHSIZE )
	  execList->insertItem(filename);
      }
      else
      {
        tmp  = i18n("You can only drop local files\n");
        tmp += i18n("onto the filelist!\n\n");
	
        QMessageBox::warning(this, i18n("kISDN Drop Error"), tmp);
      }
    }
  }
}


void ExecWidget::refreshListBox()
{
  QString   tmp;
  QStrList  scriptsList = sdata->scriptList();

  if (!scriptsList.isEmpty())
  {
    execList->clear();

    for (tmp = scriptsList.first(); tmp != 0L; tmp = scriptsList.next())
      execList->insertItem(tmp);
  }
}


void ExecWidget::slotEnableExecution()
{
  bool  status = execCheck->isChecked();

  execEdit->setEnabled(status);
  execList->setEnabled(status);
  addButton->setEnabled(status);
  remButton->setEnabled(status);
  editButton->setEnabled(status);
  execLabel->setEnabled(status);
  execListLabel->setEnabled(status);

  if (secondCheckBox) discCheck->setEnabled(status);

  sdata->setEnabled(status);

  execEdit->setFocus();
}


void ExecWidget::slotExecDisconnect()
{
  sdata->setPastExecution(discCheck->isChecked());
}


void ExecWidget::resizeEvent(QResizeEvent *)
{
  int  margin   = 10;
  int  w        = width();
  int  h        = height();
  int  framew   = w-2*margin;
  int  frameh   = h-2*margin;
  int  objdy    = 4;
  int  logox    = framew-margin-pmExec->width();
  int  logoy    = 2*margin;
  int  butw;
  int  buth     = 28;
  int  butplusw = 8;		// Additional button width
  int  butx;
  int  butdy    = 4;
  int  cbox1y   = 3*margin;
  int  cbox2y;
  int  linedity;
  int  linedith = 28;
  int  labeldy  = 2;
  int  cmdw;
  int  maxw     = 0;
  int  label1y;
  int  label2y;
  int  boxy;
  int  boxh;

  groupbox->setGeometry(margin, margin, framew, frameh);
  pmExec->move(logox, logoy);

  addButton->adjustSize();
  editButton->adjustSize();
  remButton->adjustSize();

  maxw = (addButton->width()  > maxw) ? addButton->width()  : maxw;
  maxw = (editButton->width() > maxw) ? editButton->width() : maxw;
  maxw = (remButton->width()  > maxw) ? addButton->width()  : maxw;

  butw = maxw+butplusw;
  butx = framew-margin-butw;

  label1y  = cbox1y+execCheck->height()+2*objdy;
  linedity = label1y+execLabel->height()+labeldy;
  cmdw     = butx-2*margin;
  label2y  = linedity+linedith+objdy;
  boxy     = label2y+execListLabel->height()+labeldy;

  if (secondCheckBox)
  {
    cbox2y = frameh-margin-discCheck->height();
    discCheck->move(margin, cbox2y);
  }
  else cbox2y = frameh;

  boxh = cbox2y-boxy-margin;

  execCheck->move(margin,       cbox1y);
  execLabel->move(margin,       label1y);
  execEdit->setGeometry(margin, linedity,        cmdw, linedith);
  execListLabel->move(margin,   label2y);
  execList->setGeometry(margin, boxy,            cmdw, boxh);
  addButton->setGeometry(butx,  linedity,        butw, linedith);
  editButton->setGeometry(butx, boxy,            butw, buth);
  remButton->setGeometry(butx,  boxy+buth+butdy, butw, buth);
}


