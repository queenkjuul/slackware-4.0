/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

#include <qstrlist.h>

#include "editdlg.h"
#include "prefdlg.h"
#include "userpassdlg.h"


AccountWidget::AccountWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  accMode = "";

  setMinimumSize(348, 334);

  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 314);
  GBox->setTitle(i18n("Account Setup"));

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap screen_xpm = loader->loadIcon("screen.xpm");
  account_xpm = loader->loadIcon("mini-account.xpm");

  pmScreen = new QLabel(this);
  pmScreen->setPixmap(screen_xpm);
  pmScreen->setGeometry(278, 26, 48, 48);

  acclist = new QListBox(this);
  acclist->setGeometry(30, 90, 180, 132);
  connect( acclist, SIGNAL( selected(int)),
           this,    SLOT(   slotChangeName(int) ));

  if (ISDNData.FirstAccount != (AccData *) 0L)
  {
    AccData *actual = ISDNData.FirstAccount;

    do
    {
      acclistItem = new KListBoxItem(this, actual->providername, account_xpm);
      acclist->insertItem(acclistItem);
      actual = actual->next;
    } while (actual != (AccData *) 0L);
  }

  pushnew = new QPushButton(i18n("New..."), this);
  pushnew->setGeometry(227, 90, 94, 28);
  connect(pushnew, SIGNAL(clicked()), SLOT(slotNewAccount()));

  pushedit = new QPushButton(i18n("Edit..."), this);
  pushedit->setGeometry(227, 125, 94, 28);
  connect(pushedit, SIGNAL(clicked()), SLOT(slotEditAccount()));

  pushcopy = new QPushButton(i18n("Copy"), this);
  pushcopy->setGeometry(227, 160, 94, 28);
  connect(pushcopy, SIGNAL(clicked()), SLOT(slotCopyAccount()));

  pushdel = new QPushButton(i18n("Delete"), this);
  pushdel->setGeometry(227, 195, 94, 28);
  connect(pushdel, SIGNAL(clicked()), SLOT(slotDeleteAccount()));

  pushdb = new QPushButton(i18n("Database..."), this);
  pushdb->setGeometry(201, 280, 120, 28);
  connect(pushdb, SIGNAL(clicked()), SLOT(slotDataBase()));
}


AccountWidget::~AccountWidget()
{
  // have to delete the KListBoxItems - any idea?
  // I just gave klistboxitem a QWidget *parent as parameter, hopefully Qt
  // deletes them automagically...
}


void AccountWidget::slotNewAccount()
{
  ISDNData.Temp = new AccData();

  if (execAccDialog(NEW) == QDialog::Accepted)
  {
    if (ISDNData.FirstAccount == (AccData *) 0L)
    {
      ISDNData.FirstAccount = ISDNData.Temp;
      ISDNData.LastAccount  = ISDNData.Temp;
    }
    else
    {
      (ISDNData.LastAccount)->next = ISDNData.Temp;
      (ISDNData.Temp)->prev        = ISDNData.LastAccount;
      ISDNData.LastAccount         = ISDNData.Temp;
    }
    acclistItem = new KListBoxItem(this, (ISDNData.Temp)->providername.data(), account_xpm);
    acclist->insertItem(acclistItem);
  }
  else delete ISDNData.Temp;
}


void AccountWidget::slotEditAccount()
{
  int help, index = acclist->currentItem();

  if (index > -1)
  {
    AccData *actual = ISDNData.FirstAccount;
    help = index;

    do
    {
      ISDNData.Temp = actual;
      actual        = actual->next;
      index--;
    } while ((index > -1) && (actual != (AccData *) 0L));

    (ISDNData.Temp)->Backup();

    if (execAccDialog(EDIT) != QDialog::Accepted) (ISDNData.Temp)->Restore();
    else
    {
      acclistItem = new KListBoxItem(this, (ISDNData.Temp)->providername.data(), account_xpm);
      acclist->changeItem(acclistItem, help);
    }
  }
}


void AccountWidget::slotCopyAccount()
{
  int        help, index = acclist->currentItem();
  QString    temp;
  AccData    *orig, *copy;
  DevData    *ordv, *cpdv;
  DNSData    *ordns, *cpdns, *dns;
  PhoneData  *orphone, *cpphone, *phone;

  if (index > -1)
  {
    AccData *actual = ISDNData.FirstAccount;
    help = index;

    do
    {
      ISDNData.Temp    = actual;
      actual           = actual->next;
      index--;
    } while ((index > -1) && (actual != (AccData *) 0L));

    orig = ISDNData.Temp;
    copy = new AccData();

    (ISDNData.LastAccount)->next = copy;
    copy->prev                   = ISDNData.LastAccount;
    ISDNData.LastAccount         = copy;

    temp                = orig->providername.copy();
    temp               += "_copy";
    copy->providername  = temp;
    copy->device        = orig->device;
    copy->ipdynamic     = orig->ipdynamic;
    copy->iplocaddress  = orig->iplocaddress.copy();
    copy->ipremaddress  = orig->ipremaddress.copy();
    copy->subnetmask    = orig->subnetmask.copy();
    copy->domain        = orig->domain.copy();
    copy->UsePAP        = orig->UsePAP;
    copy->UseCHAP       = orig->UseCHAP;
    copy->username      = orig->username.copy();
    copy->password      = orig->password.copy();

    // users

    copy->isAccountEnabled = orig->isAccountEnabled;
    copy->users            = orig->users;

    // Callback parameters

    copy->callback     = orig->callback;
    copy->strip0       = orig->strip0;
    copy->ingoingphone = orig->ingoingphone.copy();
    copy->cbinit       = orig->cbinit;
    copy->cbhangup     = orig->cbhangup;
    copy->huptime      = orig->huptime;
    copy->cbtime       = orig->cbtime;

    // Additional options

    copy->securemode      = orig->securemode;

    copy->vjcomp	  = orig->vjcomp;
    copy->vjconn          = orig->vjconn;
    copy->adrctrl         = orig->adrctrl;
    copy->protfld         = orig->protfld;
    copy->ipcpaccloc      = orig->ipcpaccloc;
    copy->ipcpaccrem      = orig->ipcpaccrem;

    ordv = &orig->MasterDevice;
    cpdv = &copy->MasterDevice;

    cpdv->HupTimeout   = ordv->HupTimeout;
    cpdv->DialAttempts = ordv->DialAttempts;
    cpdv->Encaps       = ordv->Encaps;

    // Phone list

    orphone = ordv->FirstPhone;
    cpphone = cpdv->FirstPhone;

    while (orphone != (PhoneData *) 0L)
    {
      phone = new PhoneData();

      if (cpphone == (PhoneData *) 0L) cpdv->FirstPhone = phone;
      else
      {
        phone->prev   = cpphone;
        cpphone->next = phone;
      }

      cpdv->LastPhone  = phone;
      phone->number    = orphone->number.copy();
      orphone          = orphone->next;
      cpphone          = phone;
    }

    ordns = orig->FirstDNS;
    cpdns = copy->FirstDNS;

    while (ordns != (DNSData *) 0L)
    {
      dns = new DNSData();

      if (cpdns == (DNSData *) 0L) copy->FirstDNS = dns;
      else
      {
        dns->prev   = cpdns;
        cpdns->next = dns;
      }
      copy->LastDNS  = dns;
      dns->ipaddress = ordns->ipaddress.copy();
      ordns          = ordns->next;
      cpdns          = dns;
    }

    copy->changed = true; // new account, so "changed" is true

    acclistItem = new KListBoxItem(this, copy->providername.data(), account_xpm);
    acclist->insertItem(acclistItem);
    acclist->setCurrentItem(acclist->count()-1);
  }
}


void AccountWidget::slotDeleteAccount()
{
  int help, index = acclist->currentItem();

  if (index > -1)
  {
    fprintf(stderr, "kISDN: About to delete account #%i\n", index);
    if (QMessageBox::warning(this, "Delete Account",
    				   "Do you really want to delete the\n"
				   "selected account ?\n\n",
				   "Delete", "Abort",
				   0, 1) == 0)
    {
      AccData *actual = ISDNData.FirstAccount;
      help = index;

      while (index > 0)
      {
        actual = actual->next;
        index--;
      }

      if (actual->next != (AccData *) 0L) (actual->next)->prev = actual->prev;
      else ISDNData.LastAccount = actual->prev;

      if (help == 0) ISDNData.FirstAccount = actual->next;
      else (actual->prev)->next = actual->next;

      delete actual;
      acclist->removeItem(help);

      ISDNData.ISPListChanged = true;
    }
  }
}


void AccountWidget::slotSetCaption(const char *pname)
{
  AccDialog->setCaption(accMode+" "+pname);
}


int AccountWidget::execAccDialog(ushort mode)
{
  bool iplocok = false, ipremok = false, mskok = false, ispok = false;
  int  Choice;
  char buffer[NAMESIZE+1], *bufferp = buffer;

  AccDialog = new LogoTabDialog(10, 370, (QWidget *) 0, (const char *) 0);

  if (mode == NEW)
  {
    accMode = i18n("New Account");
    slotSetCaption("");
  }
  else
  {
    accMode = i18n("Edit Account");
    slotSetCaption((ISDNData.Temp)->providername);
  }

  AccDialog->resize(360, 408);
  AccDialog->setCancelButton();

  DeviceTab = new DevicesWidget(AccDialog);
  connect(DeviceTab->Provider, SIGNAL(textChanged(const char *)), this, SLOT(slotSetCaption(const char *)));

  IPTab     = new IPWidget(AccDialog);
  DNSTab    = new DNSWidget(AccDialog);
  AuthTab   = new AuthWidget(AccDialog);
  UsersTab  = new UsersWidget(AccDialog);
  CBackTab  = new CallBackWidget(AccDialog);
  MoreTab   = new MoreWidget(AccDialog);

  QString tmp = "kcontrol/kisdn/account.html";
  AccDialog->addPage(DeviceTab, i18n("Remote"), tmp + "#isp");
  AccDialog->addPage(IPTab, "IP", tmp + "#ip" );
  AccDialog->addPage(DNSTab, "DNS", tmp + "#dns");
  AccDialog->addPage(AuthTab, "Auth", tmp + "#auth");
  AccDialog->addPage(UsersTab, "Users", tmp + "#user");
  AccDialog->addPage(CBackTab, i18n("Callback"), tmp + "#callback");
  AccDialog->addPage(MoreTab, i18n("More"), tmp + "#more");

  do
  {
    Choice = AccDialog->exec();

    if (Choice == QDialog::Accepted)
    {
      AccData *acc = ISDNData.Temp;

      IP *iploc = new IP((IPTab->IPloc)->text());
      iplocok   = iploc->isValidIP();
      IP *iprem = new IP((IPTab->IPrem)->text());
      ipremok   = iprem->isValidIP();
      IP *msk   = new IP((IPTab->Mask)->text());
      mskok = msk->isValidIP();

      if (!iplocok || !ipremok || !mskok)
        QMessageBox::warning(this, "Invalid IP number",
    	                             "You entered an invalid IP address.\n"    				 		                             "Remember that an IP consists of\n"
                                   "4 numbers in the range of 0..255,\n"
                                   "separated by dots\n\n", "OK", 0);
      else
      {
        acc->providername = (DeviceTab->Provider)->text();
      	acc->username     = AuthTab->User->text();
      	acc->password     = (AuthTab->Password)->text();
	

        DevData *master = &(acc->MasterDevice);

        master->DialAttempts = atoi((DeviceTab->Attempts)->text());
        master->HupTimeout   = atoi((DeviceTab->HupTime )->text());
	
      	if (iploc->isNull()) acc->iplocaddress = "";	
      	else                 acc->iplocaddress = (IPTab->IPloc)->text();
	
      	if (iprem->isNull()) acc->ipremaddress = "";
      	else                 acc->ipremaddress = (IPTab->IPrem)->text();
	
      	if (msk->isNull())   acc->subnetmask   = "";
      	else                 acc->subnetmask   = (IPTab->Mask)->text();

      	acc->domain = (DNSTab->Domain)->text();
        strncpy(buffer, acc->providername.data(), NAMESIZE);
      	buffer[NAMESIZE] = '\0';
	
      	while (*bufferp == ' ') bufferp++;
	
      	ispok = (*bufferp != '\0');	
	
      	if (!ispok) QMessageBox::warning(this, "No providername",
    	  		                       "You must enter a name for your\n"    				 		                               "internet provider.\n\n", "OK", 0);
      }

      delete iploc;
      delete iprem;
      delete msk;

      // Get the users from usersWidget
      acc->users.clear();
      QStrList &uList = ISDNData.rootData->allUsersList;

      for (ushort i = 0; i < UsersTab->usersList->count(); i++)
      {
	QString u = UsersTab->usersList->text(i);
        acc->users.append( u );

	// eventually add username to list of all users
	if ( uList.find( u ) == -1 ) // not found in list
	{
	  uList.append( u );
	}
      }

      // Fetch callback parameters
      acc->callback     = (CBackTab->cbcheck)->isChecked();
      acc->strip0       = (CBackTab->strip0button)->isChecked();
      acc->ingoingphone = (CBackTab->remin)->text();
      acc->cbinit       = (CBackTab->initcheck)->isChecked();
      acc->huptime      = atoi((CBackTab->ihangup)->text());
      acc->cbhangup     = (CBackTab->hupcheck)->isChecked();
      acc->cbtime       = atoi((CBackTab->ahangup)->text());

      // Additional options
      acc->securemode      = (MoreTab->securecheck)->isChecked();
      acc->vjcomp	   = (MoreTab->vjcheck)->isChecked();
      acc->vjconn          = (MoreTab->vjconncheck)->isChecked();
      acc->adrctrl         = (MoreTab->adrctrlcheck)->isChecked();
      acc->protfld         = (MoreTab->protfldcheck)->isChecked();
      acc->ipcpaccloc      = (MoreTab->ipcpaccloccheck)->isChecked();
      acc->ipcpaccrem      = (MoreTab->ipcpaccremcheck)->isChecked();

      acc->changed |= Choice; // if user pressed ok, assume he changed settings
    }
  } while ((Choice == QDialog::Accepted) && (!iplocok || !ipremok || !mskok || !ispok));

  delete AccDialog;
  return Choice;
}


void AccountWidget::slotDataBase()
{
  AccData    *curr;
  DevData    *dev;
  PhoneData  *phone;
  DNSData    *dns;
  DBEntry    *chosen;
  QString    *prefix;
  char       *temp;

  DBDialog  *dbdialog = new DBDialog();
  bool      okpressed = dbdialog->exec();

  if (okpressed && (dbdialog->chosenEntry() != (DBEntry *) 0L))
  {
    ISDNData.Temp = curr = new AccData();

    if (ISDNData.FirstAccount == (AccData *) 0L)
    {
      ISDNData.FirstAccount = curr;
      ISDNData.LastAccount  = curr;
    }
    else
    {
      (ISDNData.LastAccount)->next = curr;
      curr->prev                   = ISDNData.LastAccount;
      ISDNData.LastAccount         = curr;
    }

    dev    = &(curr->MasterDevice);
    chosen = dbdialog->chosenEntry();

    curr->providername = chosen->name->data();
    curr->ipdynamic    = chosen->assigndyn;

    if (chosen->domain != (QString *) 0L)
      curr->domain = chosen->domain->data();

    if ((chosen->netmask != (QString *) 0L) && !curr->ipdynamic)
      curr->subnetmask = chosen->netmask->data();

    curr->UsePAP  = !chosen->authtype;
    curr->UseCHAP = chosen->authtype;
    curr->UseNONE = !curr->UsePAP && !curr->UseCHAP;

    curr->FirstDNS = curr->LastDNS = curr->CurrDNS = (DNSData *) 0L;
    temp = chosen->dns->first();

    while (temp != (char *) 0L)
    {
      dns = new DNSData();
      dns->ipaddress = temp;

      if (curr->FirstDNS == (DNSData *) 0L) curr->FirstDNS = dns;
      if (curr->CurrDNS != (DNSData *) 0L)
      {
        dns->prev = curr->CurrDNS;
        dns->prev->next = dns;
      }
      curr->CurrDNS = dns;
      temp = chosen->dns->next();
    }

    curr->LastDNS = curr->CurrDNS;

    dev->Encaps = chosen->encaps;
    dev->Layer2 = chosen->layer2;	
	
    if (chosen->prefix == (QString *) 0L) prefix = new QString("");
    else                                  prefix = new QString(chosen->prefix->data());	

    temp = chosen->phone->first();
    dev->FirstPhone = dev->LastPhone = dev->CurrPhone = (PhoneData *) 0L;

    while (temp != (char *) 0L)
    {
      phone = new PhoneData();
      phone->number  = prefix->copy();
      phone->number += temp;

      if (dev->FirstPhone == (PhoneData *) 0L) dev->FirstPhone = phone;
      if (dev->CurrPhone != (PhoneData *) 0L)
      {
        phone->prev = dev->CurrPhone;
        phone->prev->next = phone;
      }
      dev->CurrPhone = phone;
      temp = chosen->phone->next();
    }
    dev->LastPhone = dev->CurrPhone;

    acclistItem = new KListBoxItem(this, curr->providername.data(), account_xpm);
    acclist->insertItem(acclistItem);

    UserPassDialog *userpassdlg = new UserPassDialog(curr->providername.data());
    userpassdlg->exec();

    // Add username and password to current account

    curr->username = userpassdlg->User->text();
    curr->password = userpassdlg->Password->text();

    curr->changed = true; // account has been created, so "changed" is true

    delete userpassdlg;
  }
  delete dbdialog;
}

void AccountWidget::slotChangeName( int item )
{
  QString pname = acclist->text( item );
  QString text = "New accountname: ";
  const char *caption = "Change Account Name";
  EditDialog *dlg = new EditDialog( text, pname.data(), caption,
                                    (QWidget *) 0, "", true );

  if ( dlg->exec() == QDialog::Accepted )
  {
    const char *newName = dlg->text();
    acclistItem = new KListBoxItem( this, newName, account_xpm);
    acclist->changeItem(acclistItem, item);

    AccData *actual = ISDNData.FirstAccount;
    do
    {
      ISDNData.Temp = actual;
      actual        = actual->next;
      item--;
    } while ((item > -1) && (actual != (AccData *) 0L));

    ISDNData.Temp->providername = newName;
  }
  delete dlg;
}

QSize AccountWidget::minimumSize()
{
  QSize s(328, 314); // fix this!
  return s;
}


void AccountWidget::resizeEvent(QResizeEvent *)
{
  ushort  margin    = 10;
  uint    w         = width();
  uint    h         = height();
  uint    butxalign = w-2*margin-104;

  float  yperc  = (float) (h-2*margin)/314;

  GBox->resize(w-2*margin, h-2*margin);
  pmScreen->move(w-2*margin-pmScreen->width(), pmScreen->y());

  pushnew->move(butxalign, 90);
  pushedit->move(butxalign, 125);
  pushcopy->move(butxalign, 160);
  pushdel->move(butxalign, 195);

  pushdb->move(butxalign-26, h-2*margin-38);

  acclist->resize(butxalign-50, yperc*132);
}
