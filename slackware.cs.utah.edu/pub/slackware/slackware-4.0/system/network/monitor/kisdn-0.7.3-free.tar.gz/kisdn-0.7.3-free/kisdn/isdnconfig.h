/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: isdnconfig.h,v 1.2 1998/11/21 12:35:16 twesthei Exp $
//
// $Log: isdnconfig.h,v $
// Revision 1.2  1998/11/21 12:35:16  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#ifndef __ISDNCONFIG_H
#define __ISDNCONFIG_H


#include <sys/types.h>


class ISDNConfig
{
  private:
  
    bool  _activedod;					// DoD switched off/on
    bool  _isppp;					// We have a PPP link to establish
    bool  _timrusupport;				// This kernel supports TimRu extensions
    
  public:
  
    ISDNConfig() : _activedod(false), 
		   _isppp(true),
		   _timrusupport(false),
		   ISDNsupported(true),
		   numext(0),
		   numtot(0) {}
		   
    ~ISDNConfig() {}

    bool    ISDNsupported;				// Indicates kernel support for ISDN
    
    ushort  numext;					// Total number of preconfigured devices
    int	    numtot;					// Total number of accounts (external+internal)
  
    char    prename[128][8];				// Information about preconfigured interfaces
    ushort  pretype[128];			

    char    PPPDev[8], RawDev[8];			// Interfaces used by kISDN
    char    PPPSlave[8], RawSlave[8];			// Slaves used by kISDN

    bool  activeDoD()	    const { return _activedod;    }
    bool  isPPP()           const { return _isppp;        }
    bool  hasTimRuSupport() const { return _timrusupport; }
    
    void  setActiveDoD(bool b)    { _activedod    = b; }  // would be a better way, but unfortunately
    void  setPPP(bool b)          { _isppp        = b; }  // Used by Connection 

    void  setTimRuSupport(bool b) { _timrusupport = b; }
};


#endif
