/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: kdefrontend.cpp,v 1.2 1998/11/21 12:34:41 twesthei Exp $
//
// $Log: kdefrontend.cpp,v $
// Revision 1.2  1998/11/21 12:34:41  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//


#include <qtimer.h>

#include <kapp.h>

#include "general.h"
#include "kdefrontend.h"
#include "mxmsgbox.h"
#include "version.h"


KDEFrontEnd::KDEFrontEnd()
{
}


void KDEFrontEnd::messageLoadingHiSaxFailed(QWidget *_parent)
{
  QString tmp;

  tmp  = i18n("Loading the HiSax module\n");
  tmp += i18n("was not successful.\n\n");

  QMessageBox::warning(_parent, i18n("Fatal Error"), tmp, "OK", 0);
}


void KDEFrontEnd::messageCAPILoadingFailed(QWidget *_parent)
{
  QString tmp;

  tmp  = i18n("Loading the AVM B1 CAPI modules\n");
  tmp += i18n("was not successful.\n\n");

  QMessageBox::warning(_parent, i18n("Fatal Error"), tmp, "OK", 0);
}


void KDEFrontEnd::messageCantOpenProc(QWidget *_parent)
{
  QString tmp;

  tmp  = i18n("Can't open directory /proc and\n");
  tmp += i18n("thus not determine if you're\n");
  tmp += i18n("already running an ipppd.\n\n");

  QMessageBox::warning(_parent, i18n("Fatal Error"), tmp, "OK", 0);
}


void KDEFrontEnd::messageCantOpenProcModules(QWidget *_parent)
{
  QString tmp;

  tmp  = i18n("Can't open file /proc/modules and\n");
  tmp += i18n("thus not determine if you already\n");
  tmp += i18n("loaded ISDN kernel modules.\n\n");

  QMessageBox::warning(_parent, i18n("Fatal Error"), tmp, "OK", 0);
}

void KDEFrontEnd::messageAccountHasChanged( QWidget *parent, QString text )
{
  QString tmp;

  tmp  = i18n("The following account(s) have been\n");
  tmp += i18n("reconfigured by the administrator:\n\n");
  tmp += text;
  tmp += i18n("\nPlease confirm that  your configuration\n");
  tmp += i18n("is still valid.\n");
  tmp += i18n("Eventually \"copied\" accounts are lost!\n");

  QMessageBox::information(parent, i18n("Reconfigured Account(s)"), tmp, "OK", 0);
}


int KDEFrontEnd::messageNoISDNSupport(QWidget *_parent)
{
  QString  tmp;
  int      choice;

  tmp  = i18n("This system lacks ISDN support (neither\n");
  tmp += i18n("kernel nor module support). You can, however,\n");
  tmp += i18n("tell kISDN to configure automatic driver\n");
  tmp += i18n("loading; in this case press 'Continue',\n");
  tmp += i18n("otherwise choose 'Abort'\n\n");

  choice = QMessageBox::warning(_parent, i18n("No ISDN Support"), tmp, "Abort", "Continue", 0, 1);
  return (choice);
}


void KDEFrontEnd::messageNoPreConfDevices(QWidget *_parent)
{
  QString tmp;

  tmp  = i18n("Preconfigured device chosen,\n");
  tmp += i18n("but there is none.\n");

  QMessageBox::warning(_parent, i18n("No Preconfigured Devices Found"), tmp, "OK", 0);
}


void KDEFrontEnd::messageNokISDNAccounts(QWidget *_parent)
{
  QString tmp;

  tmp  = i18n("kISDN acount chosen,\n");
  tmp += i18n("but none defined.\n");

  QMessageBox::warning(_parent, i18n("No kISDN Account Found"), tmp, "OK", 0);
}


void KDEFrontEnd::messageScriptBufferingFailed(QWidget *_parent)
{
  QString tmp;

  tmp  = i18n("An error occured when attempting\n");
  tmp += i18n("to backup system configuration files.\n");

  QMessageBox::warning(_parent, i18n("Can't backup configfiles"), tmp, "OK", 0);
}


void KDEFrontEnd::messageScriptRestoringFailed(QWidget *_parent)
{
  QString tmp;

  tmp  = i18n("An error occured when attempting\n");
  tmp += i18n("to restore system configuration files.\n");

  QMessageBox::warning(_parent, i18n("Can't restore configfiles"), tmp, "OK", 0);
}


void KDEFrontEnd::messageCantSetPermissions(QWidget *_parent, const QString fname)
{
  QString tmp;

  tmp  = i18n("I can't set the correct permission of the config file\n");
  tmp +=     (fname.data());
  tmp += i18n("\nIt should be unreadable, only writable by the owner,\n");
  tmp += i18n("because the passwords for your ISPs are stored there.");

  QMessageBox::warning(_parent, i18n("Bad file permission"), tmp, "Ok", 0);
}


int KDEFrontEnd::messageQuitHangup(QWidget *_parent)
{
  QString tmp;

  tmp  = i18n("A connection is still up.\n");
  tmp += i18n("Do you want to close it\n");
  tmp += i18n("before leaving kISDN?\n\n");

  return KMsgBox::yesNoCancel(0L, i18n("Close Connection?"), tmp.data(),
                              KMsgBox::QUESTION);
}


void KDEFrontEnd::messageNotImplementedYet()
{
  QString tmp;

  tmp  = i18n("Sorry, but this feature is not yet implemented\n");
  tmp += i18n("in kISDN ");
  tmp += KISDNVERSION;
  tmp += ".";
  tmp += i18n("Please wait for the\n");
  tmp += i18n("official 1.0 release, it will be implemented\n");
  tmp += i18n("there (or even before).");

  MXMessageBox  *msgbox = new MXMessageBox(MXMessageBox::Screws, i18n("Not yet implemented"), tmp);
  msgbox->exec();
  delete msgbox;					 	
}


void KDEFrontEnd::messageISDNUnsupported()
{
  QString tmp;

  tmp  = i18n("Sorry, there seems to be a problem with your ISDN\n");
  tmp += i18n("setup and you won't be able to use any of kISDN's\n");
  tmp += i18n("features until this problem is fixed. Please have\n");
  tmp += i18n("thorough look at kISDN's documentation if you don't\n");
  tmp += i18n("have a clue what's wrong.");

  MXMessageBox  *msgbox = new MXMessageBox(MXMessageBox::ISDNCard, i18n("No ISDN support"), tmp);
  msgbox->exec();
  delete msgbox;					 	
}


void KDEFrontEnd::messageInvalidKey()
{
  QString tmp = i18n("Your key for the kISDN Profession\n");
  tmp += i18n("is not valid.\n");
  tmp += i18n("You probably have deleted/renamed the keyfile\n");
  tmp += i18n("/usr/local/etc/kisdn.key.\n");
  tmp += i18n("Please contact kisdn@kisdn.headlight.de and\n");
  tmp += i18n("send in your personal key.\n\n");
  tmp += i18n("Notice, that this version runs in demo mode, now!");
  QMessageBox::warning( 0L, i18n("Key no longer valid"), tmp.data() ); 
}


void KDEFrontEnd::slotInvokeHelp()
{
  KApplication::getKApplication()->invokeHTMLHelp("kcontrol/kisdn/kisdn.html", "");
}


// playing audio files
void KDEFrontEnd::playSound( QString filename, bool beep )
{
  ap = new KAudioPlayer;
  ap->playSound( filename.data(), beep );
  delete ap;
}
