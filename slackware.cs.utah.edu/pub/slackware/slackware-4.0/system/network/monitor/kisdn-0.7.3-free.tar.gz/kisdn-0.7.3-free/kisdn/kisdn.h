/*  This file is a part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *	
 ****************************************************************/

// $Id: kisdn.h,v 1.2 1998/11/21 12:35:19 twesthei Exp $
//
// $Log: kisdn.h,v $
// Revision 1.2  1998/11/21 12:35:19  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __KISDN_H
#define __KISDN_H

#ifdef HAVE_CONFIG_H
  #include "../config.h"
#endif

#include <sys/types.h>

#ifdef HAVE_GLOBAL_SHORTCUTS
  #include <kglobalaccel.h>
#endif

#include "avmb1ctrl.h"
#include "combackend.h"
#include "connection.h"
#include "dockedscan.h"
#include "isdnconfig.h"
#include "isdnctrl.h"
#include "kisdndata.h"
#include "monitor.h"
#include "netctrl.h"
#include "netinfo.h"
#include "pppstatus.h"
#include "process.h"

#define RAWDEV  1
#define PPPDEV  2

#define MAXDEV  64		
#define MAXISP  32


enum { CONNECT, DISCONNECT, DIALING, BUSY, RING, SCRIPTS };


class KISDN : public KTopLevelWidget
{
  Q_OBJECT

  private:

    Monitor	     *MonitorWindow;		// Main widgets
    DockedWin        *DockWindow;

    AVMB1Ctrl	     *capictrl;			// i4l backend stuff
    ISDNConfig       *isdnconfig;
    ISDNCtrl         *isdnctrl;
    ISDNInfo         *isdninfo;
    NetCtrl          *netctrl;
    PPPStatus        *pppstatus;
    Connection       *connection;
    Process          *p;

#ifdef HAVE_GLOBAL_SHORTCUTS
    KGlobalAccel *globalKeys;
#endif

    QTimer           *teasetimer;

    uid_t       realUid;                        // real uid - who started us
    uint        execProcessCount[2];            // The number of scriptprocesses
                                                // started
    int		ispcount;			// Total number of ISP's available
    ushort	ispencaps;			// Encapsulation of current ISP
    ushort 	ispenclist[MAXISP];		// Encapsulation of valid ISP's
    int         ispindex;			// The actually engaged ISP (index to isplist)
    QStrList	*isplist;			// String list of ISP's names

    char        devmaster[8], devslave[8];	// Interface names for current ISP

    bool        modloaded, modchanged;		// Flags
    bool        hadtoload, preconfigured;
    bool        isDocked, bufferedScripts[6];

    KProcess    *IPPPD;				// Child process

    void  analyzeSetup();			// i4l/OSS backend related
    bool  checkForCAPI();
    bool  checkForISDNModules();
    bool  checkForModule(char *);
    bool  checkForTimRuExtensions();
    bool  checkISDNBuiltIn();
    void  createMonitor();
    void  createDockedMonitor();
    void  executeScripts(QStrList, uint);
    void  insertCAPIModules();
    void  insertHiSaxModule();
    void  insertISDNModules();
    void  removeCAPIModules();
    void  removeHiSaxModule();
    void  removeISDNModules();
    bool  scanInterfaces();

    void  beEngage(ISDNCommand *);		// Prepared backend functions
    void  beISPChange(ISDNCommand *);
    void  beDisengage();
    void  beDoDOn();
    void  beDoDOff();
    void  beISPListChange();
    void  beQuit();

    void  disengageISP();			// Used by backend functions
    void  engageISP(int);

    bool         isKISDNInternalAccount();	// Account management related
    void         bufferScripts();		
    bool         backupFile(const char *, const char *, bool);
    void         clearISP();				
    AccountData  *locateAccount(int);
    AccountData  *currentInternalAccount();
    void         makeISPList();
    void         reconfigureISP();
    void         registerISP(int);
    void         restoreScripts();
    bool         restoreFile(const char *, const char *, bool);
    void         setFilePermissions();
    void         setISP();

    void  dialogISDNModulesDetected(uint);
    void  playSound(ushort);
    void  writeCombo();

    bool  isOnline()          	{ return (isdninfo->queryOnline(0)  || isdninfo->queryOnline(1));  }
    bool  isDialing()         	{ return (isdninfo->queryDialing(0) || isdninfo->queryDialing(1)); }

  private slots:

    void  slotCommandRcvd(ISDNCommand *); // Frontend call for backend capabilities

    void  slotDockMonitor();
    void  slotUndockMonitor();

    void  slotBusy(ushort);            
    void  slotDialing(ushort)         { playSound(DIALING); }
    void  slotLinkDown(ushort);
    void  slotLinkUp(ushort);
    void  slotLinkAuthenticated();

    void  slotRefreshProcessList0();
    void  slotRefreshProcessList1();
    void  slotSessionClose();
    void  slotQuit();

  public:


    KISDN(const char *name = 0);
    ~KISDN();

    void  createFrontend();
    void  hangupEventually();
    void  shutDown(bool);


  public slots:

    void  beDial();
    void  beHangup();


  signals:

    void  sigDialing(ushort);
    void  sigDoDDisengage();			
    void  sigDoDEngage(AccountData *);
    void  sigHungUp();
    void  sigInterfaceChanged(char *);
    void  sigLinkDown(ushort);
    void  sigLinkUp(ushort);
    void  sigLinkAuthenticated(ushort);
    void  sigOnlineTime(QString);
    void  sigReceiveOff(ushort);
    void  sigReceiveOn(ushort);
    void  sigSessionClose();
    void  sigTransmitOff(ushort);
    void  sigTransmitOn(ushort);
};


void  signalHandler(int);
void  setSignalHandler(void (*handler)(int));


#endif
