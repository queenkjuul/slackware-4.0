/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: genwidget.cpp,v 1.2 1998/11/21 12:34:37 twesthei Exp $
//
// $Log: genwidget.cpp,v $
// Revision 1.2  1998/11/21 12:34:37  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include "genwidget.h"
#include "minsize.h"


GeneralWidget::GeneralWidget(CustomData *cust, QWidget *parent, const char *name) : QWidget(parent, name),
										    customdata(cust)
{
  KIconLoader  *loader           = kapp->getIconLoader();
  static       QPixmap linux_xpm = loader->loadIcon("linux.xpm");
  int          top               = 80;
  int          checkheight;

  setMinimumSize(MINSIZEX, MINSIZEY);

  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 314);
  GBox->setTitle(i18n("General Setup"));

  pmLinux = new QLabel(this);
  pmLinux->setPixmap(linux_xpm);
  pmLinux->setGeometry(16, 30, 41, 48);

  dockchk = new QCheckBox(i18n("Always dock in panel on startup"), GBox);
  dockchk->adjustSize();
  dockchk->move(20, top);
  connect(dockchk, SIGNAL(clicked()), SLOT(slotDockChanged()));

  checkheight = dockchk->height()+5; // General height of all checkboxes

  authchk = new QCheckBox(i18n("Connect-sound after authentication"), GBox);
  authchk->adjustSize();
  authchk->move(20, top+checkheight);
  connect(authchk, SIGNAL(clicked()), SLOT(slotAuthChanged()));

  shutchk = new QCheckBox(i18n("Disconnect on X-Server shutdown"),GBox);
  shutchk->adjustSize();
  shutchk->move(20, top+2*checkheight);
  connect(shutchk, SIGNAL(clicked()), SLOT(slotDisconnectChanged()));

  incchk = new QCheckBox(i18n("Show incoming calls"), GBox);
  incchk->adjustSize();
  incchk->move(20, top+3*checkheight);
  incchk->setChecked(false);
  incchk->setEnabled(false);

  splashchk = new QCheckBox(i18n("Show splashscreen on startup"), GBox);
  splashchk->adjustSize();
  splashchk->move(20, top+4*checkheight);
  connect(splashchk, SIGNAL(clicked()), SLOT(slotSplashChanged()));

#ifdef HAVE_GLOBAL_SHORTCUTS
  keybutton = new QPushButton(i18n("Key bindings..."), GBox);
  keybutton->adjustSize();
  keybutton->resize(keybutton->width(), keybutton->height()+4);
  connect(keybutton, SIGNAL(clicked()), SLOT(slotConfigureKeys()));
#endif

  refreshSettings();
  resize(MINSIZEX, MINSIZEY);
}


void GeneralWidget::slotConfigureKeys()
{
#ifdef HAVE_GLOBAL_SHORTCUTS
  if ( globalKeys )
    KKeyDialog::configureKeys( globalKeys );
#endif
}


void GeneralWidget::refreshSettings(void)
{
  shutchk->setChecked(customdata->disconnect());
  dockchk->setChecked(customdata->docking());
  authchk->setChecked(customdata->soundOnAuth());
//  incchk->setChecked(customdata->enabledSignalization());
  splashchk->setChecked(customdata->showSplash());
}


void GeneralWidget::resizeEvent(QResizeEvent *)
{
  ushort  margin = 10;
  int     w      = width();
  int     h      = height();

  GBox->resize(w-2*margin, h-2*margin);
  pmLinux->move(w-2*margin-pmLinux->width()-2, pmLinux->y());

#ifdef HAVE_GLOBAL_SHORTCUTS
  int     butw   = keybutton->width();
  int     buth   = keybutton->height();
  keybutton->move(w-3.5*margin-butw, h-3.5*margin-buth);
#endif
}

