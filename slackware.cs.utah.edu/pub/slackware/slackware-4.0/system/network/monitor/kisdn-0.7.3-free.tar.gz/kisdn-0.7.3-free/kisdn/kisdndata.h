/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: kisdndata.h,v 1.2 1998/11/21 12:35:20 twesthei Exp $
//
// $Log: kisdndata.h,v $
// Revision 1.2  1998/11/21 12:35:20  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __KISDNDATA_H
#define __KISDNDATA_H

#include <stdlib.h>

#include <qcolor.h>
#include <qstrlist.h>

#include <kapp.h>
#include <kconfig.h>

#define PATHSIZE   128
#define NAMESIZE   128

#define PAPFILE    "/etc/ppp/pap-secrets"
#define CHAPFILE   "/etc/ppp/chap-secrets"
#define DNSFILE    "/etc/resolv.conf"
#define OPTFILE    "/etc/ppp/ioptions"
#define PAPSAVE    "/etc/ppp/kisdn.pap-secrets"
#define CHAPSAVE   "/etc/ppp/kisdn.chap-secrets"
#define DNSSAVE    "/etc/kisdn.resolv.conf"
#define OPTSAVE    "/etc/ppp/kisdn.ioptions"

#define IPUPFILE   "/etc/ppp/ip-up"
#define IPDOWNFILE "/etc/ppp/ip-down"
#define IPUPSAVE   "/etc/ppp/kisdn.ip-up"
#define IPDOWNSAVE "/etc/ppp/kisdn.ip-down"

#define PROTRAWIP  0
#define PROTIP     1
#define PROTCISCO  2
#define PROTETHER  3
#define PROTSYNC   4
#define PROTIPUI   5


class IP
{
  private:

    int  _field[4];

    bool  rangeOK(int  x) const { return ((x >= 0) && (x <= 255)); }
    bool  valid(const char *);

  public:

    IP(int, int, int, int);
    IP(const QString&);
    ~IP() {};

    QString  string()     const;
    int      field(int i) const  { return _field[i]; }
};					


class Phone
{
  private:

    QString  _number;

  public:

    Phone(QString num = "") : _number(num) {}
    ~Phone() {};

    void  setNumber(QString& num)  { _number = num;  }

    const QString&  number() const { return _number; }
};


class Device
{
  public:

    enum  encprotocol { RAWIP, IP, CISCO, ETHERNET, SYNCPPP, IPUI };
    enum  l2protocol  { X75I, X75UI, X75BUI, HDLC };
    enum  l3protocol  { TRANS };

  private:

    QList<Phone>  _phonelist;
    QString       _name;
    int           _huptime, _dialattempts, _delay;
    encprotocol   _encaps;
    l2protocol    _layer2;
    l3protocol    _layer3;

  public:
	
    Device(QString      name  = "",
           int          hup   = 60,
	   int          att   = 10,
	   int          delay = 30,
	   encprotocol  enc   = SYNCPPP,
           l2protocol   l2    = HDLC,
	   l3protocol   l3    = TRANS);
	
    Device(Device&);
    ~Device() {};

    bool  load(KConfig *, uint, ushort);
    void  save(KConfig *, uint, ushort);
    void  save(uint a, ushort b)      	     { save(kapp->getConfig(), a, b); kapp->getConfig()->sync(); } 

    void  addPhone(const Phone *p)           { _phonelist.append(p); }
    void  removePhone(int i)                 { _phonelist.remove(i); }

    void  setName(QString& n)                { _name         = n; }
    void  setHupTime(int t)                  { _huptime      = t; }
    void  setDialAttempts(int a)             { _dialattempts = a; }
    void  setDelay(int d)                    { _delay        = d; }
    void  setEncaps(encprotocol p)           { _encaps       = p; }
    void  setProtLayer2(l2protocol p)        { _layer2       = p; }
    void  setProtLayer3(l3protocol p)        { _layer3       = p; }

    const QList<Phone>& phoneList()    const { return _phonelist;         }
    const QString&      name()         const { return _name;              }
    int                 hupTime()      const { return _huptime;           }
    int                 dialAttempts() const { return _dialattempts;      }
    int                 delay()        const { return _delay;             }
    encprotocol         protEncaps()   const { return _encaps;            }
    l2protocol          protLayer2()   const { return _layer2;            }
    l3protocol          protLayer3()   const { return _layer3;            }
    Phone               *firstPhone()        { return _phonelist.first(); }
    Phone               *nextPhone()         { return _phonelist.next();  }
};


class ScriptData
{
  public:

    enum  exectime { PASTCONNECT, PASTDISCONNECT };

  private:

    exectime  _exectime;
    bool      _enabled, _pastexec;
    QStrList  _scripts;

  public:

    ScriptData(exectime t) : _exectime(t),
                             _enabled(false),
		             _pastexec(false) {}
    ScriptData(ScriptData&);			
    ~ScriptData() {};

    bool  load(KConfig *, uint);
    void  save(KConfig *, uint);
    void  save(uint a)                   { save(kapp->getConfig(), a); kapp->getConfig()->sync(); } 
    void  dump();

    void  addLine(const char *line)      { _scripts.append(line); }
    void  clear()			 { _scripts.clear();      }

    void  setExecutionTime(exectime t)   { _exectime = t; }
    void  setEnabled(bool b)             { _enabled  = b; }
    void  setPastExecution(bool b)       { _pastexec = b; }

    exectime    executionTime()  const   { return _exectime;        }
    bool        isEnabled()      const   { return _enabled;         }
    bool        pastExecution()  const   { return _pastexec;        }
    QStrList&   scriptList()             { return _scripts;         }
    const char  *firstLine()             { return _scripts.first(); }
    const char  *nextLine()              { return _scripts.next();  }
};


class AccountData
{
  public:

    enum  assigntype { DYNAMIC, STATIC };
    enum  authtype   { NONE, PAP, CHAP };
    enum  state      { OFF, ON         };

  private:

    int         _cryptbyte;
    QString     _providername;
    IP          _iploc, _iprem;
    IP          _subnetmask;
    QString     _domain;
    QString     _username, _password;
    QString     _ingoingphone;
    ushort      _device;			// Check, if still needed
    uint        _huptime, _cbtime;
    bool        _callback, _cbinit, _cbhangup;
    bool        _enabledacc;
    state       _securemode;
    bool        _vjcomp, _vjconn, _adrctrl;
    bool        _protfld, _ipcpaccloc, _ipcpaccrem;
    bool        _strip0;
    bool        _changedacc;
    assigntype  _assigntype;
    authtype    _authtype;
    Device      *_master;
    QList<IP>   _dnslist;
    ScriptData  *_pastconnect, *_pastdisconnect;

    QString     toHexByte(char);
    char        fromHexByte(const char *);
    QString     toHexString(int, const char *);
    QString     fromHexString(int, const char *);

  public:

    AccountData();		
    AccountData(AccountData&);
    ~AccountData();

    bool  load(KConfig *, uint);
    void  save(KConfig *, uint);
    void  save(uint a)                      { save(kapp->getConfig(), a); kapp->getConfig()->sync(); }

    void  setProviderName(const QString& s) { _providername = s;  }
    void  setLocalIP(const IP& ip)          { _iploc        = ip; }
    void  setRemoteIP(const IP& ip)         { _iprem        = ip; }
    void  setSubnetMask(const IP& ip)       { _subnetmask   = ip; }
    void  setDomain(const QString& s)       { _domain       = s;  }
    void  setUsername(const QString& s)     { _username     = s;  }
    void  setPassword(const QString& s)     { _password     = s;  }
    void  setIngoingPhone(const QString& s) { _ingoingphone = s;  }
    void  setHanguptime(int t)              { _huptime      = t;  }
    void  setCallbackTime(int t)            { _cbtime       = t;  }
    void  setCallbackEnabled(bool b)        { _callback     = b;  }
    void  setCallbackInit(bool b)           { _cbinit       = b;  }
    void  setCallbackHangup(bool b)         { _cbhangup     = b;  }
    void  setAccountEnabled(bool b)         { _enabledacc   = b;  }
    void  setSecureMode(state s)            { _securemode   = s;  }
    void  setVJCompressionDisabled(bool b)  { _vjcomp       = b;  }
    void  setVJConnectionDisabled(bool b)   { _vjconn       = b;  }
    void  setACCompressionDisabled(bool b)  { _adrctrl      = b;  }
    void  setPFCompressionDisabled(bool b)  { _protfld      = b;  }
    void  setIPCPAcceptLocal(bool b)        { _ipcpaccloc   = b;  }
    void  setIPCPAcceptRemote(bool b)       { _ipcpaccrem   = b;  }
    void  setStripZeroes(bool b)            { _strip0       = b;  }
    void  setAccountChanged(bool b)         { _changedacc   = b;  }
    void  setAssignType(assigntype t)       { _assigntype   = t;  }
    void  setAuthType(authtype t)           { _authtype     = t;  }
    
    void  addDNS(const IP *dns)             { _dnslist.append(dns); }
    void  removeDNS(int i)                  { _dnslist.remove(i);   }

    void  replaceConnectScripts(ScriptData *);
    void  replaceDisconnectScripts(ScriptData *);

    IP          *firstDNS()                 { return _dnslist.first(); }
    IP          *nextDNS()                  { return _dnslist.next();  }
    ScriptData  *connectScripts()           { return _pastconnect;     }
    ScriptData  *disconnectScripts()        { return _pastdisconnect;  }
    Device      *masterDevice()             { return _master;          }

    const QString&  providerName()          const { return _providername; }
    const IP&       localIP()               const { return _iploc;        }
    const IP&       remoteIP()              const { return _iprem;        }
    const IP&       subnetMask()            const { return _subnetmask;   }
    const QString&  domain()                const { return _domain;       }
    const QString&  username()              const { return _username;     }
    const QString&  password()              const { return _password;     }
    const QString&  ingoingPhone()          const { return _ingoingphone; }
    int             device()		    const { return _device;       }
    int             hangupTime()            const { return _huptime;      }
    int             callbackTime()          const { return _cbtime;       }
    bool            enabledCallback()       const { return _callback;     }
    bool            callbackInit()          const { return _cbinit;       }
    bool            callbackHangup()        const { return _cbhangup;     }
    bool            enabledAccount()        const { return _enabledacc;   }
    state           secureMode()            const { return _securemode;   }
    bool            disabledVJCompression() const { return _vjcomp;       }
    bool            disabledVJConnection()  const { return _vjconn;       }
    bool            disabledACCompression() const { return _adrctrl;      }
    bool            disabledPFCompression() const { return _protfld;      }
    bool            ipcpAcceptLocal()       const { return _ipcpaccloc;   }
    bool            ipcpAcceptRemote()      const { return _ipcpaccrem;   }
    bool            stripZeroes()           const { return _strip0;       }
    bool            accountChanged()        const { return _changedacc;   }
    assigntype      assignType()            const { return _assigntype;   }
    authtype        authType()              const { return _authtype;     }
};


class AdvancedOptions
{
  private:

    bool    _bsdcomp, _incdebug;
    ushort  _dbglevel;
    uint    _mru, _mtu;

  public:

    AdvancedOptions() : _bsdcomp(false),
                        _incdebug(false),
			_dbglevel(0),
			_mru(0),
			_mtu(0) {}
			
    ~AdvancedOptions() {};

    bool  load(KConfig *);
    void  save(KConfig *);
    void  save()                    { save(kapp->getConfig()); kapp->getConfig()->sync(); }

    void  setBSDCompression(bool b) { _bsdcomp  = b; }
    void  setIncreaseDebug(bool b)  { _incdebug = b; }
    void  setDebugLevel(int l)      { _dbglevel = l; }
    void  setMRU(int u)             { _mru      = u; }
    void  setMTU(int u)             { _mtu      = u; }

    bool  bsdCompression() const { return _bsdcomp;  }
    bool  increaseDebug()  const { return _incdebug; }
    int   debugLevel()     const { return _dbglevel; }
    int   mru()            const { return _mru;      }
    int   mtu()            const { return _mtu;      }
};


class CustomData
{
  private:

    bool     _firsttimeuser, _showhisaxdetect;
    bool     _dialondemand, _disconnect;
    bool     _docking, _sessiondocked;
    bool     _showsplash, _callsignalenabled;
    bool     _soundonauth, _audioconnect;
    bool     _audiodisconnect, _audiodialing;
    bool     _audiobusy;
    bool     _audioscripts;
    QString  _wavonlinepath, _wavofflinepath;
    QString  _wavdialingpath, _wavbusypath;
    QString  _wavringpath, _wavscriptspath;

  public:

    CustomData();
    ~CustomData() {};

    bool  load(KConfig *);
    void  save(KConfig *);
    void  save()                                  { save(kapp->getConfig()); kapp->getConfig()->sync(); }

    void  setFirstTimeUser(bool b)                { _firsttimeuser     = b; }
    void  setShowHisaxDetect(bool b)              { _showhisaxdetect   = b; }
    void  setDialOnDemand(bool b)                 { _dialondemand      = b; }
    void  setDisconnect(bool b)                   { _disconnect        = b; }
    void  setDocking(bool b)                      { _docking           = b; }
    void  setSessionDocked(bool b)                { _sessiondocked     = b; }
    void  setShowSplash(bool b)                   { _showsplash        = b; }
    void  setSignalizationEnabled(bool b)         { _callsignalenabled = b; }
    void  setSoundOnAuth(bool b)                  { _soundonauth       = b; }
    void  setAudioOnConnect(bool b)               { _audioconnect      = b; }
    void  setAudioOnDisconnect(bool b)            { _audiodisconnect   = b; }
    void  setAudioOnDialing(bool b)               { _audiodialing      = b; }
    void  setAudioOnBusy(bool b)                  { _audiobusy         = b; }
    void  setAudioOnScripting(bool b)             { _audioscripts      = b; }
    void  setWaveOnlinePath(const QString & s)    { _wavonlinepath     = s; }
    void  setWaveOfflinePath(const QString & s)   { _wavofflinepath    = s; }
    void  setWaveDialingPath(const QString & s)   { _wavdialingpath    = s; }
    void  setWaveBusyPath(const QString & s)      { _wavbusypath       = s; }
    void  setWaveRingPath(const QString & s)      { _wavringpath       = s; }
    void  setWaveScriptingPath(const QString & s) { _wavscriptspath    = s; }

    bool            firstTimeUser()        const { return _firsttimeuser;     }
    bool            showHisaxDetect()      const { return _showhisaxdetect;   }
    bool            dialOnDemand()         const { return _dialondemand;      }
    bool            disconnect()           const { return _disconnect;        }
    bool            docking()              const { return _docking;           }
    bool            sessionDocked()        const { return _sessiondocked;     }
    bool            showSplash()           const { return _showsplash;        }
    bool            enabledSignalization() const { return _callsignalenabled; }
    bool            soundOnAuth()          const { return _soundonauth;       }
    bool            audioOnConnect()       const { return _audioconnect;      }
    bool            audioOnDisconnect()    const { return _audiodisconnect;   }
    bool            audioOnDialing()       const { return _audiodialing;      }
    bool            audioOnBusy()          const { return _audiobusy;         }
    bool            audioOnScripting()     const { return _audioscripts;      }
    const QString&  waveOnlinePath()       const { return _wavonlinepath;     }
    const QString&  waveOfflinePath()      const { return _wavofflinepath;    }
    const QString&  waveDialingPath()      const { return _wavdialingpath;    }
    const QString&  waveBusyPath()         const { return _wavbusypath;       }
    const QString&  waveScriptingPath()    const { return _wavscriptspath;    }
};


class ScannerData
{
  public:

    enum  scalingpolicy { DYNAMIC, STATIC };

  private:

    bool           _scana, _scanb, _scanrec, _scantra, _scantot;
    bool           _showstamps, _dottedlines;
    ushort         _scanrate;
    scalingpolicy  _scalingpolicy;
    float          _scaledist, _scalerange;
    QColor         _scalecolor, _graphcolor[2][3];

  public:

    ScannerData();
    ~ScannerData() {};

    bool  load(KConfig *);
    void  save(KConfig *);
    void  save()                  { save(kapp->getConfig()); kapp->getConfig()->sync(); }

    void  setScanA(bool b)                                 { _scana                = b; }
    void  setScanB(bool b)                                 { _scanb                = b; }
    void  setScanReceive(bool b)                           { _scanrec              = b; }
    void  setScanTransmit(bool b)                          { _scantra              = b; }
    void  setScanTotal(bool b)                             { _scantot              = b; }
    void  setShowStamps(bool b)                            { _showstamps           = b; }
    void  setDottedLines(bool b)                           { _dottedlines          = b; }
    void  setScanRate(ushort r)                            { _scanrate             = r; }
    void  setScalingPolicy(scalingpolicy p)                { _scalingpolicy        = p; }
    void  setScaleDistance(float d)                        { _scaledist            = d; }
    void  setScaleRange(float r)                           { _scalerange           = r; }
    void  setScaleColor(const QColor& c)                   { _scalecolor           = c; }
    void  setGraphColor(int ch, int type, const QColor& c) { _graphcolor[ch][type] = c; }

    bool           scanA()                      const { return _scana;                }
    bool           scanB()                      const { return _scanb;                }
    bool           scanReceive()                const { return _scanrec;              }
    bool           scanTransmit()               const { return _scantra;              }
    bool           scanTotal()                  const { return _scantot;              }
    bool           showStamps()                 const { return _showstamps;           }
    bool           dottedLines()                const { return _dottedlines;          }
    ushort         scanRate()                   const { return _scanrate;             }
    scalingpolicy  scalingPolicy()              const { return _scalingpolicy;        }
    float          scaleDistance()              const { return _scaledist;            }
    float          scaleRange()                 const { return _scalerange;           }
    QColor&        scaleColor()                       { return _scalecolor;           }
    QColor&        graphColor(int ch, int type)       { return _graphcolor[ch][type]; }
};


class GeneralData
{
  public:

    enum  dchannelprot { PROT_1TR6, PROT_EDSS1 };

  private:

    QString          _ipppdpath;
    QString          _prefix, _msndata;
    QString          _modprobepath;
    QString          _membase, _iobase0, _iobase1;
    ushort           _adapter;
    ushort           _interrupt;
    dchannelprot     _protocol;
    bool             _loadasmodule;
    bool             _enableiface;
    bool             _ipupdown;
    AdvancedOptions  *_advanced;

  public:

    GeneralData();
    GeneralData(GeneralData&);
    ~GeneralData();

    bool  load(KConfig *);

    void  setIPPPDPath(const QString& s)      { _ipppdpath    = s; }
    void  setPrefix(const QString& s)         { _prefix       = s; }
    void  setMSNData(const QString& s)        { _msndata      = s; }
    void  setModprobePath(const QString& s)   { _modprobepath = s; }
    void  setMemBaseAddress(const QString& s) { _membase      = s; }
    void  setIOAddress1(const QString& s)     { _iobase0      = s; }
    void  setIOAddress2(const QString& s)     { _iobase1      = s; }
    void  setAdapterType(ushort t)            { _adapter      = t; }
    void  setInterrupt(ushort i)              { _interrupt    = i; }
    void  setDChannelProt(dchannelprot p)     { _protocol     = p; }
    void  setLoadAsModule(bool b)             { _loadasmodule = b; }
    void  setEnableInterface(bool b)          { _enableiface  = b; }
    void  setBufferIpUpDown(bool b)           { _ipupdown     = b; }

    const QString&   ipppdPath()        const { return _ipppdpath;    }
    const QString&   prefix()           const { return _prefix;       }
    const QString&   msnData()          const { return _msndata;      }
    const QString&   modprobePath()     const { return _modprobepath; }
    const QString&   memBaseAddress()   const { return _membase;      }
    const QString&   ioAddress1()       const { return _iobase0;      }
    const QString&   ioAddress2()       const { return _iobase1;      }
    ushort           adapterType()      const { return _adapter;      }
    ushort           interrupt()        const { return _interrupt;    }
    dchannelprot     protocol()         const { return _protocol;     }
    bool             loadAsModule()     const { return _loadasmodule; }
    bool             enableInterface()  const { return _enableiface;  }
    bool             bufferIpUpDown()   const { return _ipupdown;     }

    AdvancedOptions  *advancedOptions()       { return _advanced;     }
};


class kISDNData
{
  private:

    int                 _accindex;
    int                 _accloaded, _numacc;
    GeneralData         *_general;
    CustomData          *_custom;
    ScannerData         *_scanner;
    AccountData         *_current;

    QList<AccountData>  _acclist;
    QString             _rcrevision;

  public:

    kISDNData();
    kISDNData(kISDNData&);
    ~kISDNData();

    bool  load();
    void  save();
    void  saveSession();

    void  setAccountIndex(int i)                 { _accindex  = i;          }
    void  setAccountsLoaded(int a)               { _accloaded = a;          }
    void  setNumberAccounts(int n)               { _numacc    = n;          }
    void  addAccount(AccountData *acc)           { _acclist.append(acc);    }
    void  insertAccount(int i, AccountData *acc) { _acclist.insert(i, acc); }
    void  removeAccount(int i)                   { _acclist.remove(i);      }
    void  setCurrentAccount(AccountData *a)      { _current   = a;          }

    void  replaceCustomData(CustomData *);
    void  replaceScannerData(ScannerData *);

    GeneralData  *generalData()             { return _general;         }
    CustomData   *customData()              { return _custom;          }
    ScannerData  *scannerData()             { return _scanner;         }

    AccountData  *firstAccount()            { return _acclist.first(); }
    AccountData  *nextAccount()             { return _acclist.next();  }
    AccountData  *account(int i)            { return _acclist.at(i);   }

    int             accountIndex()    const { return _accindex;   }
    int             accountsLoaded()  const { return _accloaded;  }
    int             numberAccounts()  const { return _numacc;     }
    const QString&  rcRevision()      const { return _rcrevision; }
    AccountData     *currentAccount()       { return _current;    }
};


extern kISDNData ISDNData;

#endif
