/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: dockedwin.cpp,v 1.2 1998/11/21 12:34:34 twesthei Exp $
//
// $Log: dockedwin.cpp,v $
// Revision 1.2  1998/11/21 12:34:34  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <qtimer.h>

#include "dockedwin.h"

extern bool  regflag;


// Constructor for DockedWin without ISDN-support
DockedWin::DockedWin( const char *name ) : QLabel( name ), BaseFrontend()
{
  config          = 0L;
  info            = 0L;
  pppStatus       = 0L;
  ispCount        = 0;
  ispIndex        = -1;
  haveIsdnSupport = false;

  constructDockedWin();
}

// Constructor with ISDN-support
DockedWin::DockedWin(ISDNConfig *_config, ISDNInfo *_info,
		     PPPStatus *_pppStatus, uint _ispCount,
                     QStrList *_ispList, const char *name) : QLabel(name)
{
  haveIsdnSupport = true;
  ispCount        = _ispCount;
  ispList         = _ispList;
  config  	  = _config;
  info            = _info;
  pppStatus       = _pppStatus;

  KConfig *kc = kapp->getConfig();
  kc->setGroup("Configuration");
  ispIndex    = kc->readNumEntry( "ISP", -1 );
  if (ispIndex >= (int) ispCount) ispIndex = ispCount-1;
  engageISP( ispIndex );

  constructDockedWin();

  // small hack: if we are online and _then_ dock kisdn, we don't get the
  // sigLinkUp() signal and can't show the green LED. So we check this ourself.
  if (isOnline()) graphWidget->slotOnline(0);

  // same for dialing
  if (isDialing()) graphWidget->slotDialing(0);

  connectGraph();
}


DockedWin::~DockedWin()
{
  delete graphWidget;
  delete menu;
}


void DockedWin::constructDockedWin()
{
  graphWidget = new DockedScan(this);

  KIconLoader *loader = kapp->getIconLoader();

  menu = new QPopupMenu();
  CHECK_PTR(menu);
  menu->setCheckable( true );

  subMenu = new QPopupMenu();
  CHECK_PTR( subMenu );
  connect( subMenu, SIGNAL( activated(int) ), SLOT( slotCallProvider(int) ) );

  const QPixmap config_xpm     = loader->loadIcon("mini-config.xpm");
  const QPixmap connect_xpm    = loader->loadIcon("mini-connect.xpm");
  const QPixmap disconnect_xpm = loader->loadIcon("mini-disconnect.xpm");
  const QPixmap exit_xpm       = loader->loadIcon("mini-exit.xpm");

  account_xpm = loader->loadIcon("mini-account.xpm");
  none_xpm    = loader->loadIcon("mini-None.xpm");

  undockItem = menu->insertItem(config_xpm, i18n("Open &Configuration"));
  menu->insertSeparator();
  dodItem = menu->insertItem( i18n("Dial on de&mand" ));
  menu->insertSeparator();
  connectItem = menu->insertItem(connect_xpm, i18n("Co&nnect..."), subMenu);
  disconnectItem = menu->insertItem(disconnect_xpm, i18n("&Disconnect"));

  menu->setItemEnabled( dodItem, haveIsdnSupport );
  menu->setItemEnabled( connectItem, false);
  menu->setItemEnabled( disconnectItem, false);

  menu->insertSeparator();
  quitItem = menu->insertItem(exit_xpm, i18n("&Quit"));

  connect( menu, SIGNAL( activated( int ) ),
           SLOT( slotPopupMenuActivated( int )) );
  connect(graphWidget, SIGNAL(rightClick()), this, SLOT(slotPopupMenu()));
}


void DockedWin::slotShowToolTip(QString) // (QString onlineTime)
{ /*
  if (info->isOnline())
  {
    QToolTip::remove( this );
    QToolTip::add( this, onlineTime );
  } */
}


void DockedWin::slotShowToolTip(float *) // (float *transfer)
{ /*
  QString tmp;

  if (info->isOnline())
  {
    float rx = transfer[0] + transfer[2];
    float tx = transfer[1] + transfer[3];

    tmp.sprintf("%s %.1f kBit/s %s %.1f kBit/s", i18n("Receive:"), rx, i18n("Transmit:"), tx);
  }
  else tmp.sprintf("kISDN %s - Offline", KISDNVERSION);
  QToolTip::remove( this );
  QToolTip::add( this, tmp );
*/
}


void DockedWin::slotPopupMenu()
{
  subMenu->clear();

  if ( haveIsdnSupport )
  {
    bool online  = isOnline();
    bool dialing = isDialing();

    if ( ispCount == 0 ) // no accounts configured
    {
      subMenu->insertItem(none_xpm, i18n("None configured"));
      subMenu->setItemEnabled(0, false);
      menu->setItemEnabled(connectItem, false);
      menu->setItemEnabled(dodItem, false);
    }

    else  // insert all the accounts into the popupmenu
    {
      QString tmp;
      for ( uint i = 0; i < ispCount; i++ )
      {
        tmp = ispList->at(i);
        subMenu->insertItem( account_xpm, tmp );
        subMenu->setItemEnabled( i, tmp.left( 10 ) != "<disabled>" );
      }

    }

    // Disable "Connect" when online or dialing
    menu->setItemEnabled( connectItem, ( !online & !dialing )  );
    // Enable hangup when online or dialing
    menu->setItemEnabled( disconnectItem, ( online | dialing ) );

    menu->setItemChecked( dodItem, config->activeDoD() );
  }

  else  // we have no isdn-support
  {
    subMenu->insertItem(none_xpm, i18n("No ISDN support"));
    subMenu->setItemEnabled(0, false);
    menu->setItemEnabled(disconnectItem, false);
  }

  menu->move(-1000,-1000);
  menu->show();
  menu->hide();
  QRect g = KWM::geometry( this->winId() );
  if ( g.x() > QApplication::desktop()->width()/2 &&
       g.y()+menu->height() > QApplication::desktop()->height() )
    menu->popup(QPoint( g.x(), g.y() - menu->height()));

  else menu->popup(QPoint( g.x() + g.width(), g.y() + g.height()));
}


void DockedWin::slotPopupMenuActivated( int choice )
{
  // somehow a case-statement won't work :o(
  // "case label `DockedWin::undockItem' does not reduce to an integer constant"

  if      ( choice == undockItem )     emit sigUndockMonitor();

  else if ( choice == dodItem )        slotDoDChanged( !menu->isItemChecked( dodItem ));
  else if ( choice == disconnectItem ) disconnectISP();
  else if ( choice == quitItem )       slotQuit();
}


void DockedWin::connectGraph()
{
  connect( info,        SIGNAL( sigDialing(ushort) ),
           graphWidget, SLOT( slotDialing(ushort) ) );
  connect( info,        SIGNAL( sigBusy(ushort) ),
           graphWidget, SLOT( slotBusy(ushort) ) );
  connect( info,        SIGNAL( sigLinkUp(ushort)),
           graphWidget, SLOT( slotOnline(ushort) ) );
  connect( info,        SIGNAL( sigLinkDown(ushort)),
           graphWidget, SLOT( slotOffline(ushort) ) );

  connect( info,        SIGNAL( sigTransmitOn(ushort) ),
           graphWidget, SLOT( slotTransmitOn(ushort) ) );
  connect( info,        SIGNAL( sigTransmitOff(ushort) ),
           graphWidget, SLOT( slotTransmitOff(ushort) ) );
  connect( info,        SIGNAL( sigReceiveOn(ushort) ),
           graphWidget, SLOT( slotReceiveOn(ushort) ) );
  connect( info,        SIGNAL( sigReceiveOff(ushort) ),
           graphWidget, SLOT( slotReceiveOff(ushort) ) );
  connect( pppStatus,   SIGNAL( sigNewTransferRates(PPPInfo *) ),
           graphWidget, SLOT( slotNewRates(PPPInfo *) ) );
}


// we might save some configuration here (no backend stuff)
void DockedWin::saveSession()
{
}

void DockedWin::slotQuit()
{
  saveSession();
  if ( haveIsdnSupport )
  {
    if ( isOnline() )
    {
      int i = frontend->messageQuitHangup( this );
      if (i == 1) disconnectISP();
      if (i == 3) return;
    }
  }
  sendSimpleCommand(BE_QUIT);
}


void DockedWin::slotCallProvider( int isp )
{
  changeISP(isp); // the backend decides whether it really changes the ISP
  QTimer::singleShot( 320, this, SLOT(slotDialWorkaround()));

  if ( isp != ispIndex ) // save as new default account
  {
    ispIndex = isp;
    KConfig  *kc = kapp->getConfig();

    kc->setGroup("Configuration");
    kc->writeEntry("ISP", ispIndex);			
    kc->sync();
  }
}

void DockedWin::slotDialWorkaround()
{
  connectISP();
}

void DockedWin::slotDoDChanged(bool enable)
{
  CustomData  *custom = ISDNData.customData();

  custom->setDialOnDemand(enable);
  DoDChanged(enable);
}


void DockedWin::slotShowDoDEnabled()
{
  menu->setItemChecked(dodItem, true);
}


void DockedWin::slotShowDoDDisabled()
{
  menu->setItemChecked(dodItem, false);
}


void DockedWin::emitCommand(ISDNCommand *isdnCommand)
{
  emit sigCommand(isdnCommand);
}
