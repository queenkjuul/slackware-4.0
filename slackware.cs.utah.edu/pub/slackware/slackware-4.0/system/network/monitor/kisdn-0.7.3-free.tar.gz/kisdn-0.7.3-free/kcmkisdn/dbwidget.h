/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#ifndef __DBWIDGET_H
#define __DBWIDGET_H

#include <qdialog.h>
#include <qlabel.h>
#include <qpushbt.h>

#include <ktreelist.h>

#include "db.h"


class DBDialog : public QDialog
{
  Q_OBJECT

  private:

    DB             *db;
    DBEntry        *chosen;
    
    KTreeList      *TreeList;
    KTreeListItem  *country, *city, *ispName;
  
    QLabel	   *Logo;
    QPushButton    *OK, *Cancel;

    void  noProviderSelected();
    void  resizeEvent(QResizeEvent *);
   
  private slots:
  
    void  accept();


  public:

    DBDialog(QWidget *parent = 0, const char *name = 0);
    ~DBDialog();

    DBEntry  *chosenEntry(void) { return chosen; }
};


#endif
