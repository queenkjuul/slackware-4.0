/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#ifndef __DOCKEDWIN_H
#define __DOCKEDWIN_H

#include <qlabel.h>
#include <qpixmap.h>
#include <qpopmenu.h>
#include <qstring.h>
#include <qstrlist.h>
#include <qtooltip.h>

#include <kapp.h>
#include <kiconloader.h>
#include <kwm.h>

#include "basefrontend.h"
#include "combackend.h"
#include "dockedscan.h"
#include "kdefrontend.h"
#include "kisdndata.h"
#include "netinfo.h"
#include "pppstatus.h"


extern KDEFrontEnd  *frontend;		// DockedWin relies on this !


class DockedWin : public QLabel, public BaseFrontend
{
  Q_OBJECT

  private:

    QPixmap     account_xpm, none_xpm;
    QPopupMenu  *menu, *subMenu;
    QStrList    *ispList;

    DockedScan  *graphWidget;
    PPPStatus   *pppStatus;
    ISDNCommand *isdncommand;
    ISDNConfig  *config;
    ISDNInfo    *info;

    bool        haveIsdnSupport;
    int         ispIndex;
    // popup menu indices
    int         undockItem, notebookItem, dodItem, connectItem, disconnectItem;
    int         quitItem;
    uint        ispCount;

    void  constructDockedWin();
    void  connectGraph();
    void  emitCommand(ISDNCommand *);

    bool  isOnline() { return (info->queryOnline(0) || info->queryOnline(1));  }
    bool  isDialing(){ return (info->queryDialing(0)|| info->queryDialing(1)); }

  private slots:

    void  slotPopupMenuActivated(int);
    void  slotCallProvider(int);
    void  slotDialWorkaround();


  public:

    DockedWin(const char *name = 0);
    DockedWin(ISDNConfig *config, ISDNInfo *info, PPPStatus *pppStatus,
	      uint _ispCount, QStrList *_ispList, const char *name = 0);
    ~DockedWin();

  public slots:

    void  slotShowDoDEnabled();
    void  slotShowDoDDisabled();
    void  slotDoDChanged(bool);
    void  slotCallerHungUp()	      { emit sigCallerHungUp();   }		
    void  slotShowToolTip(QString);
    void  slotShowToolTip(float *);
    void  slotPopupMenu();
    void  saveSession();
    void  slotQuit();

  signals:

    void  sigCommand(ISDNCommand *);
    void  sigUndockMonitor();
    void  sigCallerHungUp();
};


#endif
