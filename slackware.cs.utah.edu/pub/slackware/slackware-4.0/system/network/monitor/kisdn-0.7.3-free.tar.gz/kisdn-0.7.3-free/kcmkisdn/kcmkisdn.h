/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#ifndef __KCMKISDN_H
#define __KCMKISDN_H

#include <qfileinf.h>
#include <qstring.h>

#include "aboutwidget.h"
#include "kisdnconfapp.h"
#include "prefdlg.h"


class KISDNConfigApplication : public kISDNConfigApplication
{
  Q_OBJECT

  public:

    KISDNConfigApplication(int &argc, char **argv, const char *name);
    ~KISDNConfigApplication();

    void apply();
    void init();

  private:

    AccountWidget    *Account;
    GeneralWidget    *General;
    DriverWidget     *Driver;
    AboutWidget      *About;	
    LogoTabDialog    *PrefDlg;
    QStrList         *pages;

    bool 	     settingsApplied;

    void messageBadSysValues();
    void reconfigureISP();

  private slots:

    void cancel();
};


#endif
