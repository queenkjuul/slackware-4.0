/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

 
#include "kaudioplayer.h"

/** Audio (wav) playing made easy.
 *
 * Just create an instance of KAudioPlayer and call
 * playSound( absoluteFilename )
 * 
 * Don't forget to link against "mediatool" in your makefile!
 */


KAudioPlayer::KAudioPlayer()
{
  KAServer = new KAudio;
}


KAudioPlayer::~KAudioPlayer()
{
  delete KAServer;
}


void KAudioPlayer::playSound(const char *fileName, bool beep)
{
  QFileInfo fi(fileName);
  
  if (fi.isFile() &&
      fi.isReadable() &&
      fi.extension() == (QString) "wav")
  {
    KAServer->play((char *)fileName);
  }
  else
  {
    if (beep) kapp->beep();
  }
}
