/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: rectledpanel.h,v 1.2 1998/11/21 12:35:34 twesthei Exp $
//
// $Log: rectledpanel.h,v $
// Revision 1.2  1998/11/21 12:35:34  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
 
 
#ifndef __RECTLEDPANEL_H
#define __RECTLEDPANEL_H

#include "rectled.h"


class RectLEDPanel : public QWidget
{
  private:
  
    RectLED  *_LED[4];

  public:
  
    RectLEDPanel(QWidget *parent = 0, const char *name = 0);
    ~RectLEDPanel() {}
    
    void  setHiSaxState(bool);
    void  setVoiceState(bool);
};


#endif
