/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include "accdlg.h"


DevicesWidget::DevicesWidget(QWidget *parent, const char *name):QWidget(parent, name)
{
  char     buffer[8];
  QSize    size;
  int      wd, hg;
  AccData  *acc = ISDNData.Temp;
  
  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 316);
  GBox->setTitle(i18n("Remote Setup"));
  
  Provlabel = new QLabel(i18n("Provider Name:"), this);
  size = Provlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Provlabel->setGeometry(110-wd, 36+(24-hg)/2, wd, hg);
  
  Provider = new QLineEdit(this);
  Provider->setGeometry(120, 36, 140, 24);
  Provider->setMaxLength(NAMESIZE);
  Provider->setText(acc->providername);

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap phone_xpm = loader->loadIcon("phone.xpm");

  pmPhone = new QLabel(this);
  pmPhone->setPixmap(phone_xpm);
  pmPhone->setGeometry(289, 32, 34, 29);
  
  Remotelabel = new QLabel(i18n("Remote Phone:"), this);
  size = Remotelabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Remotelabel->setGeometry(110-wd, 74+(24-hg)/2, wd, hg);
  
  Remote = new QLineEdit(this);
  Remote->setGeometry(120, 76, 100, 24);
  Remote->setMaxLength(PNUMSIZE);
  
  Addbutton = new QPushButton(i18n("Add"), this);
  Addbutton->setGeometry(232, 75, 93, 28);
  
  Listlabel = new QLabel(i18n("Phone List:"), this);
  size = Listlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Listlabel->setGeometry(110-wd, 110+(24-hg)/2, wd, hg);
  
  Phonelist = new QListBox(this);
  Phonelist->setGeometry(120, 110, 100, 52);
  
  DevData *dev = &(acc->MasterDevice);
  if (dev->FirstPhone != (PhoneData *) 0L)
  {
    PhoneData *actual = dev->FirstPhone;
    
    while (actual != (PhoneData *) 0L)
    {
      Phonelist->insertItem(actual->number.data());
      actual = actual->next;
    }
  }  
  
  connect(Addbutton, SIGNAL(clicked()), SLOT(slotAddRemote()));  
  Removebutton = new QPushButton(i18n("Remove"), this);
  Removebutton->setGeometry(232, 110, 93, 28);
  connect(Removebutton, SIGNAL(clicked()), SLOT(slotRemoveRemote()));
  
  Encapslabel = new QLabel(i18n("Encapsulation:"), this);
  size = Encapslabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Encapslabel->setGeometry(110-wd, 172+(24-hg)/2, wd, hg);

  Encapsbox = new QComboBox(false, this, "encapsCombo");
  Encapsbox->insertItem(i18n("Raw IP"));  
  Encapsbox->insertItem(i18n("Internet Protocol"));
  Encapsbox->insertItem(i18n("Cisco / HDLC Mode")); 
  Encapsbox->insertItem(i18n("Ethernet"));
  Encapsbox->insertItem(i18n("Synchronous PPP")); 
  Encapsbox->insertItem(i18n("Raw IP + UI Header"));      
  Encapsbox->setGeometry(120, 172, 150, 24);
  Encapsbox->setCurrentItem((acc->MasterDevice).Encaps);
  connect(Encapsbox, SIGNAL(activated(int)), SLOT(slotEncapsChanged(int)));
 
  Layer2label = new QLabel(i18n("Layer 2:"), this);
  size = Layer2label->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Layer2label->setGeometry(110-wd, 200+(24-hg)/2, wd, hg);
  
  Layer2box = new QComboBox(false, this);
  Layer2box->insertItem(i18n("X75I"));  
  Layer2box->insertItem(i18n("X75UI"));
  Layer2box->insertItem(i18n("X75BUI")); 
  Layer2box->insertItem(i18n("HDLC"));
  Layer2box->setGeometry(120, 200, 100, 24);
  Layer2box->setCurrentItem((acc->MasterDevice).Layer2);
  connect(Layer2box, SIGNAL(activated(int)), SLOT(slotLayer2Changed(int)));
   
  Layer3label = new QLabel(i18n("Layer 3:"), this);
  size = Layer3label->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Layer3label->setGeometry(110-wd, 228+(24-hg)/2, wd, hg);
  
  Layer3box = new QComboBox(false, this);
  Layer3box->insertItem(i18n("Trans"));  
  Layer3box->setGeometry(120, 228, 100, 24);
  Layer3box->setCurrentItem((acc->MasterDevice).Layer3);
  connect(Layer3box, SIGNAL(activated(int)), SLOT(slotLayer3Changed(int)));

  Diallabel = new QLabel(i18n("Dial attempts:"), this);
  size = Diallabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Diallabel->setGeometry(110-wd, 262+(24-hg)/2, wd, hg);

  Attempts = new QLineEdit(this);
  Attempts->setGeometry(120, 262, 30, 24);
  Attempts->setMaxLength(DATMSIZE);
  sprintf(buffer, "%i", dev->DialAttempts);
  Attempts->setText(buffer);
   
  HupTimelabel = new QLabel(i18n("Timeout:"), this);
  size = HupTimelabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  HupTimelabel->setGeometry(214-wd, 262+(24-hg)/2, wd, hg);
  
  HupTime = new QLineEdit(this);
  HupTime->setGeometry(224, 262, 44, 24);
  HupTime->setMaxLength(TIMESIZE);
  sprintf(buffer, "%i", dev->HupTimeout);
  HupTime->setText(buffer);
  
  Sec1label = new QLabel(i18n("seconds"), this);
  size = Sec1label->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Sec1label->setGeometry(274, 262+(24-hg)/2, wd, hg);

}


void DevicesWidget::slotAddRemote(void)
{
  char     buffer[PNUMSIZE+1];
  uint     len;
  bool     invalidIP = false;
  AccData  *acc = ISDNData.Temp;
  
  strncpy(buffer, Remote->text(), PNUMSIZE+1);
  buffer[PNUMSIZE] = '\0';
  len=strlen(buffer);
  
  QString tmp = Remote->text();				/* ###### Subject to revision ###### */
  
  if (tmp.isEmpty()) invalidIP = true;

  for (uint i = 0; i < len; i++)
  {
    if (!isdigit(buffer[i]))
    {
      invalidIP = true;
      break;
    }
  }			     
	
  if ( invalidIP )
  {     
    QMessageBox::warning(this, "Invalid phone number",
                               "Please enter only legal phone\n"                                 
                               "numbers.\n\n", "OK", 0);
    return;
  }
  		     
  DevData *actdev = &(acc->MasterDevice);
  
  actdev->CurrPhone = new PhoneData();
  
  if (actdev->FirstPhone != (PhoneData *) 0L)
  {
    (actdev->CurrPhone)->prev = actdev->LastPhone;
    (actdev->LastPhone)->next = actdev->CurrPhone;
  }
  else actdev->FirstPhone = actdev->CurrPhone;
  
  actdev->LastPhone = actdev->CurrPhone;
  (actdev->CurrPhone)->number = Remote->text();
  Phonelist->insertItem((actdev->CurrPhone)->number.data());
  Remote->setText("");
  Remote->setFocus();
}
  
  
void DevicesWidget::slotRemoveRemote(void)
{
  AccData  *acc = ISDNData.Temp;
  
  int      help, index = Phonelist->currentItem();
  DevData  *currdev = &(acc->MasterDevice);
  
  if (index > -1)
  {
    PhoneData *actual = currdev->FirstPhone;
    help = index;
    
    while (index > 0)
    {
      actual = actual->next;
      index--;
    }
    
    if (actual->next != (PhoneData *) 0L) (actual->next)->prev = actual->prev;
    else                                  currdev->LastPhone = actual->prev;
    
    if (help == 0) currdev->FirstPhone = actual->next;
    else           (actual->prev)->next = actual->next;
    
    Phonelist->removeItem(help);
  }
}


void DevicesWidget::slotEncapsChanged(int Choice)
{
  ((ISDNData.Temp)->MasterDevice).Encaps = Choice;
}


void DevicesWidget::slotLayer2Changed(int Choice)
{
  ((ISDNData.Temp)->MasterDevice).Layer2 = Choice;  
}


void DevicesWidget::slotLayer3Changed(int Choice)
{
  ((ISDNData.Temp)->MasterDevice).Layer3 = Choice;  
}


void DevicesWidget::Backup(void)
{

}


void DevicesWidget::Restore(void)
{

}


void DevicesWidget::resizeEvent(QResizeEvent *)
{
  ushort margin = 10;
  uint w = width();
  uint h = height();

  GBox->resize(w-2*margin, h-2*margin);
  pmPhone->move(w-2*margin-pmPhone->width()-2, pmPhone->y());
}
