/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/



#ifndef __PREFDLG_H
#define __PREFDLG_H

#include <kapp.h>
#include <kfiledialog.h>
#include <kiconloader.h>
#include <klocale.h>

#include <stdio.h>
#include <ctype.h>

#include <qchkbox.h>
#include <qcombo.h>
#include <qevent.h>
#include <qframe.h>
#include <qgrpbox.h>
#include <qimage.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qlined.h>
#include <qlistbox.h>
#include <qlistview.h>
#include <qmsgbox.h>
#include <qpixmap.h>
#include <qpushbt.h>
#include <qradiobt.h>
#include <qsize.h>
#include <qtabdlg.h>

#include "accdlg.h"
#include "adapter.h"
#include "dbwidget.h"
#include "logo.h"
#include "kisdndata.h"
#include "klistboxitem.h"
#include "kurlwidget.h"

#define NEW  1			// Should move into the appropriate class definition
#define EDIT 2


class AccountWidget : public QWidget
{
  Q_OBJECT

  private:

    QGroupBox      *GBox;
    QLabel         *costlabel, *pmScreen;
    QLineEdit      *costs;
    QListBox       *acclist;
    QPixmap        account_xpm;
    QPushButton    *pushedit, *pushnew, *pushcopy, *pushdel, *pushreset, *pushdb;
    QString        accMode;
    LogoTabDialog  *AccDialog;

    KListBoxItem   *acclistItem;

    DevicesWidget   *DeviceTab;
    IPWidget        *IPTab;
    DNSWidget       *DNSTab;
    AuthWidget      *AuthTab;
    UsersWidget     *UsersTab;
    CallBackWidget  *CBackTab;
    MoreWidget      *MoreTab;
    DBDialog        *dbdialog;

    int execAccDialog(ushort);
    void resizeEvent( QResizeEvent * );

  private slots:

    void slotNewAccount();
    void slotEditAccount();
    void slotCopyAccount();
    void slotDeleteAccount();
    void slotChangeName(int);
    void slotSetCaption( const char * );
    void slotDataBase();

  public:

    AccountWidget(QWidget *parent = 0, const char *name = 0);
    ~AccountWidget();

    QSize           minimumSize();
};


class DebugWidget : public QWidget
{
  Q_OBJECT

  private:

    QGroupBox    *GBox;
    QLabel       *pmMagnify, *Dbglevellabel;

    void resizeEvent( QResizeEvent * );

  private slots:

    void slotBSDCompChanged();
    void slotIncDebugChanged();

  public:

    QCheckBox  *Bsdcheck, *Dbgcheck;
    QLineEdit  *Debuglevel;

    DebugWidget(QWidget *parent = 0, const char *name = 0);
    ~DebugWidget() {}
};


class UnitsWidget : public QWidget
{
  private:

    QGroupBox  *GBox;
    QLabel     *pmUnits, *MTULabel, *MRULabel, *Byte1Label, *Byte2Label;

    void resizeEvent( QResizeEvent * );

  public:

    QLineEdit  *MTU, *MRU;

    UnitsWidget(QWidget *parent = 0, const char *name = 0);
    ~UnitsWidget() {}
};


class GeneralWidget : public QWidget
{
  Q_OBJECT

  private:

    QComboBox    *Protobox;
    QGroupBox    *GBox;
    QLabel       *prefixlabel, *msnlabelData, *eazlabel, *seclabel;
    QLabel 	 *ipppdpathlabel, *Protlabel;
    QLabel       *pmLinux;
    QPushButton  *advanced, *browse;

    LogoTabDialog  *AdvancedDlg;
    DebugWidget    *Debug;
    UnitsWidget    *Units;

    bool checkForTimRuExtensions();
    void resizeEvent( QResizeEvent * );

  private slots:

    void slotAdvanced();
    void slotBrowseIpppd();
    void slotProtocolChanged(int);

  public:

    GeneralWidget(QWidget *parent = 0, const char *name = 0);
    ~GeneralWidget() {}

    QLineEdit  *prefix, *msnData, *eaz, *ipppdpath;
    QCheckBox  *checkExplicit, *checkIpUp;
    QCheckBox  *cacb;

    void   refreshSettings();
    QSize  minimumSize();
};


class DriverWidget : public QWidget
{
  Q_OBJECT

  private:

    QComboBox    *Adbox;
    QGroupBox    *GBox;
    QLabel       *Modprobelabel, *Adapterlabel, *Iolabel, *Intlabel;
    QLabel       *Memlabel, *Protlabel, *pmGear;
    QPushButton  *Browse;

    Adapter      ad;

    void setModState(bool);
    void setParamState();
    void messageBadIO();
    void resizeEvent( QResizeEvent * );

  private slots:

    void         slotModuleLoadChanged();
    void         slotBrowseModPath();
    void         slotAdapterChanged(int);

  public:

    DriverWidget(QWidget *parent = 0, const char *name = 0);
    ~DriverWidget() {}

    bool         isValidIOAddr(ushort);
    bool         isValidInterrupt();
    bool         isValidMembase();
    void         setIOBase(ushort, QString);
    void         setInterrupt(char *);
    void         setMembase(QString);
    QSize        minimumSize();

    QLineEdit    *Modprobe, *Ioaddr0, *Ioaddr1, *Interrupt, *Membase;
    QCheckBox    *Modulechk;
};


#endif
