/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: monitor.cpp,v 1.3 1998/12/19 10:42:52 gis Exp $
//
// $Log: monitor.cpp,v $
// Revision 1.3  1998/12/19 10:42:52  gis
//
// removed connect to sigBeingCalled()
//
// Revision 1.2  1998/11/21 12:34:51  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>

#include <linux/isdn.h>

#include <qbttngrp.h>
#include <qchkbox.h>
#include <qdir.h>             /* ...to work against the qfiledlg.h problem... */
#include <qevent.h>			
#include <qfont.h>			
#include <qgrpbox.h>
#include <qlayout.h>
#include <qlistbox.h>
#include <qradiobt.h>
#include <qstring.h>
#include <qtooltip.h>

#include <kapp.h>
#include <kiconloader.h>
#include <ktopwidget.h>
#include <kwm.h>

#include "general.h"
#include "kdefrontend.h"
#include "kisdn.h"
#include "kisdndata.h"
#include "led.h"
#include "ledbutton.h"
#include "ledpanel.h"
#include "monitor.h"
#include "netinfo.h"
#include "version.h"

extern KDEFrontEnd  *frontend;


/*
 * Monitor constructor definition
 *********************************/

Monitor::Monitor(ISDNConfig   *config,
                 ISDNInfo     *info,
                 KDEFrontEnd  *fe,
                 int          numisp,
                 QStrList     *isplist,
                 const char   *name) : KTopLevelWidget(name), BaseFrontend()
{
  bool            chdl[2], chup[2];
  KIconLoader     *loader = kapp->getIconLoader();
  static QPixmap  notebook_xpm  = loader->loadIcon("notebook.xpm");
  static QPixmap  phonecall_xpm = loader->loadIcon("phonecall.xpm");
  ushort          ch;
  bool            pppaction;
  
  connect_xpm  = loader->loadIcon("connect.xpm");
  hangup_xpm   = loader->loadIcon("hangup.xpm");

  setFixedSize(404, 377);

  setCaption("kISDN "KISDNVERSION" - Free Edition");

  isdnconfig   = config;
  isdninfo     = info;
  frontend     = fe;
  isdnsupport  = isdnconfig->ISDNsupported;
  ispcount     = numisp;

  ispindex = ISDNData.accountIndex();

  if (ispindex >= ispcount) ispindex = ispcount-1;

  Panel = new LEDPanel(this);
  Panel->move(18, 5);

  Label = new QLabel(i18n("Connect to"), this);
  Label->move(150, 5);

  PushConnectHangup = new QPushButton(this);
  PushConnectHangup->setPixmap(connect_xpm);
  PushConnectHangup->setGeometry(295, 32, 47, 44);
  PushConnectHangup->setEnabled(true);
  PushConnectHangup->setFocus();

  PushVoice = new QPushButton(this);
  PushVoice->setPixmap(phonecall_xpm);
  PushVoice->setGeometry(346, 32, 47, 44);
  PushVoice->setEnabled(false);
  
  StatusPanel = new RectLEDPanel(this);
  StatusPanel->move(295, 78);
  StatusPanel->setHiSaxState(isdnsupport);
  StatusPanel->setVoiceState(false);

  if (isdnsupport) connect(PushConnectHangup, SIGNAL(clicked()), this, SLOT(slotToggleLineState()));

  ServerCombo = new QComboBox(false, this);
  ServerCombo->setGeometry(150, 32, 140, 26);
  writeCombo(isplist);
  ServerCombo->setCurrentItem(ispindex);

  connect(ServerCombo, SIGNAL(activated(int)), SLOT(slotISPChanged(int)));
  ServerCombo->setEnabled(false);

  forcedhangup = false;

  dodbutton = new DoDButton(isdnconfig, this);
  dodbutton->move(150, 63);
  QToolTip::add(dodbutton, i18n("Dial on demand"));
  connect(dodbutton, SIGNAL(sigDoDChanged(bool)), this, SLOT(slotDoDChanged(bool)));
    
  connect(this, SIGNAL(sigDoDOn()),  dodbutton, SLOT(slotEngaged()));
  connect(this, SIGNAL(sigDoDOff()), dodbutton, SLOT(slotDisengaged()));
  
  Etched = new QFrame(this);
  Etched->setFrameStyle(0x34);
  Etched->setLineWidth(2);
  Etched->setGeometry(14, 93, 378, 2);

  mtxfont   = new MatrixFont("matrix", 10, 13);
  IPdisplay = new IPDisplay(isdninfo, mtxfont, this);
  IPdisplay->move(14, 99);

  EtchedBottom = new QFrame(this);
  EtchedBottom->setFrameStyle(0x34);
  EtchedBottom->setLineWidth(2);
  EtchedBottom->setGeometry(14, 329, 378, 2);

  PushHelp = new QPushButton(i18n("Help"), this);
  PushHelp->setGeometry(14, 339, 80, 32);
  PushHelp->setEnabled(true);
  connect(PushHelp, SIGNAL(clicked()), frontend, SLOT(slotInvokeHelp()));

  PushCustomize = new QPushButton(i18n("Customize"), this);
  PushCustomize->setGeometry(100, 339, 80, 32);
  connect(PushCustomize, SIGNAL(clicked()), this, SLOT(slotCustomize()));
  QToolTip::add(PushCustomize, i18n("User customization"));

  PushNoteBook = new QPushButton(this);
  PushNoteBook->setPixmap(notebook_xpm);
  PushNoteBook->setGeometry(186, 339, 40, 32);
  PushNoteBook->setEnabled(false);
  
  PushDock = new QPushButton(i18n("Hide"), this);
  PushDock->setGeometry(228, 339, 80, 32);
  connect(PushDock, SIGNAL(clicked()), SLOT(slotMinimize()));
  QToolTip::add(PushDock, i18n("Move to docking area"));

  PushQuit = new QPushButton(i18n("Quit"), this);
  PushQuit->setGeometry(310, 339, 80, 32);
  connect(PushQuit, SIGNAL(clicked()), this, SLOT(slotQuit()));

  UTDisplay = new UptimeDisplay(QColor(green), QColor(black), QColor(0x60, 0x60, 0x00),
                                QColor(0xf0, 0xec, 0x00), this);
  UTDisplay->move(14, 145);

  Meter = new ScanMeter(isdnsupport, isdninfo, mtxfont, this);
  Meter->move(14, 171);

  connect(Meter, SIGNAL(sigRefreshUptimes()), this, SLOT(slotRefreshUptimes()));

  if (isdnsupport)
  {
    connect(this, SIGNAL(sigDial(ushort)),          this, SLOT(slotEnableHangup(ushort)));
    connect(this, SIGNAL(sigBusy(ushort)),          this, SLOT(slotEnableConnect(ushort)));
    connect(this, SIGNAL(sigLinkDown(ushort)),      this, SLOT(slotEnableConnect(ushort)));

    connect(this, SIGNAL(sigDial(ushort)),          Panel, SLOT(slotDialEvent(ushort)));
    connect(this, SIGNAL(sigBusy(ushort)),          Panel, SLOT(slotBusyEvent(ushort)));
    connect(this, SIGNAL(sigHangup(ushort)),        Panel, SLOT(slotHangupEvent(ushort)));
    connect(this, SIGNAL(sigLinkUp(ushort)),        Panel, SLOT(slotLinkUpEvent(ushort)));
    connect(this, SIGNAL(sigLinkDown(ushort)),      Panel, SLOT(slotLinkDownEvent(ushort)));
    connect(this, SIGNAL(sigTransmitOn(ushort)),    Panel, SLOT(slotTransmitOnEvent(ushort)));
    connect(this, SIGNAL(sigTransmitOff(ushort)),   Panel, SLOT(slotTransmitOffEvent(ushort)));
    connect(this, SIGNAL(sigReceiveOn(ushort)),     Panel, SLOT(slotReceiveOnEvent(ushort)));
    connect(this, SIGNAL(sigReceiveOff(ushort)),    Panel, SLOT(slotReceiveOffEvent(ushort)));

    connect(this, SIGNAL(sigDial(ushort)),          Meter, SLOT(slotEventDial(ushort)));
    connect(this, SIGNAL(sigLinkDown(ushort)),      Meter, SLOT(slotEventLinkDown(ushort)));
    connect(this, SIGNAL(sigLinkUp(ushort)),        Meter, SLOT(slotEventLinkUp(ushort)));
    connect(this, SIGNAL(sigNewScan(PPPInfo *)),    Meter, SLOT(slotDrawScanLine(PPPInfo *)));

    connect(this, SIGNAL(sigDial(ushort)),          dodbutton, SLOT(slotDisable(ushort)));
    connect(this, SIGNAL(sigLinkDown(ushort)),      dodbutton, SLOT(slotEnable(ushort)));
    connect(this, SIGNAL(sigBusy(ushort)),          dodbutton, SLOT(slotEnable(ushort)));

    connect(this, SIGNAL(sigNewIPLocalA(char *)),  IPdisplay, SLOT(slotNewIPLocalA(char *)));
    connect(this, SIGNAL(sigNewIPRemoteA(char *)), IPdisplay, SLOT(slotNewIPRemoteA(char *)));
    connect(this, SIGNAL(sigNewIPLocalB(char *)),  IPdisplay, SLOT(slotNewIPLocalB(char *)));
    connect(this, SIGNAL(sigNewIPRemoteB(char *)), IPdisplay, SLOT(slotNewIPRemoteB(char *)));

    pppaction = false;

    for (ch = 0; ch < 2; ch++)
    {
      chdl[ch] = info->queryDialing(ch);
      chup[ch] = info->queryOnline(ch);

      pppaction   = pppaction   || chdl[ch] || chup[ch];
    }

    if (pppaction)
    {
      for (ch = 0; ch < 2; ch++)
      {
        if (chdl[ch]) Panel->slotDialEvent(ch);
	if (chup[ch])
	{
	  Panel->slotLinkUpEvent(ch);
	
	  if (chup[ch])
	  {
	    IPdisplay->slotNewIPLocalA(isdninfo->queryLocalIP(ch).data());
	    IPdisplay->slotNewIPRemoteA(isdninfo->queryRemoteIP(ch).data());
	  }
	  else
	  {
	    IPdisplay->slotNewIPLocalB(isdninfo->queryLocalIP(ch).data());
	    IPdisplay->slotNewIPRemoteB(isdninfo->queryRemoteIP(ch).data());
	  }
	}
      }

      if (pppaction)
      {
        slotEnableHangup(0);
        dodbutton->slotDisable(0);
      }
    }
  }
}


void Monitor::wakeUp()
{
  if (isdnsupport)
  {
    ServerCombo->setEnabled(true);
//    engageISP(ispindex); // this is done in KISDN::createFrontend()
  }
}


/*
 * Methods called on construction
 *********************************/

void Monitor::writeCombo(QStrList *isplist)
{
  ushort i;

  ServerCombo->clear();

  if (isdnsupport)
  {
    if (!ispcount)
    {
      ServerCombo->insertItem(i18n("None configured"));
      ServerCombo->setEnabled(false);
      PushConnectHangup->setEnabled(false);
      ispindex = 0;
    }
    else
    {
      for (i = 0; i < ispcount; i++) ServerCombo->insertItem(isplist->at(i)); 			

      ServerCombo->setEnabled(true);
      togglePushHangupButton();
    }
  }
  else ServerCombo->insertItem(i18n("No ISDN support"));
}


/*
 * User interaction related methods
 ***********************************/

void Monitor::slotISPChanged(int item)
{
  if (item != ispindex)
  {
    changeISP(ispindex = item);

    KConfig  *kc = kapp->getConfig();

    kc->setGroup("Configuration");
    kc->writeEntry("ISP", item);			
    kc->sync();

    ServerCombo->setCurrentItem(item);
    togglePushHangupButton();
  }
}


void Monitor::togglePushHangupButton()
{
  QString tmp = ServerCombo->currentText();
  PushConnectHangup->setEnabled(tmp.left(10) != "<disabled>");
}


void Monitor::slotToggleLineState()
{
  if (!isdnsupport) frontend->messageISDNUnsupported();
  else
  {
    if (!isdninfo->queryOnline(0)  && !isdninfo->queryOnline(1) &&
        !isdninfo->queryDialing(0) && !isdninfo->queryDialing(1))
    {
      ::message("Dialing out...");
      connectISP();
    }
    else
    {
      ::message("Hanging up...");
      disconnectISP();
    }
  }
}


void Monitor::slotRefreshUptimes()
{
  ulong  up;

  for (ushort ch = 0; ch < 2; ch++)
  {
    up = isdninfo->queryUptime(ch);

    UTDisplay->setUptime(ch, up/3600, (up%3600)/60, up%60);
  }
}


/*
 * Main window button slots
 ***************************/

void Monitor::slotCustomize()
{
  bool  okpressed;

  CustomData   *customdata  = new CustomData(*(ISDNData.customData()));
  ScannerData  *scannerdata = new ScannerData(*(ISDNData.scannerData()));

  custDlg = new CustomDialog(customdata, scannerdata);

#ifdef HAVE_GLOBAL_SHORTCUTS
  custDlg->passGlobalKeys(globalKeys );
#endif

  okpressed = custDlg->exec();

  if (okpressed)
  {
    ISDNData.replaceCustomData(customdata);
    ISDNData.replaceScannerData(scannerdata);

    Meter->settingsChanged();
    ISDNData.save();

    if (custDlg->changedISPList()) ISPListChanged();
  }
  else
  {
    delete customdata;
    delete scannerdata;
  }

  delete custDlg;  
}


void Monitor::slotMinimize()
{
  if (Meter->configChanged) saveSession();

  emit sigDockMe();
}


void Monitor::saveSession()
{
  ScannerData *scan = ISDNData.scannerData();
  KConfig     *kc   = kapp->getConfig();

  scan->setScanA(Meter->glowcha->isActive());
  scan->setScanB(Meter->glowchb->isActive());
  scan->setScanReceive(Meter->glowrcv->isActive());
  scan->setScanTransmit(Meter->glowtra->isActive());
  scan->setScanTotal(Meter->glowtot->isActive());
  scan->setShowStamps(Meter->glowstm->isActive());

  scan->save(kc);
  kc->sync();
}


void Monitor::slotQuit()
{
  if (isdnsupport)
  {
    if (isOnline())
    {
      int i = frontend->messageQuitHangup( this );
      if (i == 1) disconnect();
      if (i == 3) return;
    }
  }

  saveSession();
  sendSimpleCommand(BE_QUIT);
}


void Monitor::slotEnableConnect(ushort ch)
{
  if (!ch)
  {
    PushConnectHangup->setPixmap(connect_xpm);
    PushConnectHangup->setEnabled(true);
  }
}


void Monitor::slotEnableHangup(ushort)
{
  PushConnectHangup->setPixmap(hangup_xpm);
  PushConnectHangup->setEnabled(true);
}


void Monitor::closeEvent(QCloseEvent *)
{
  ::message("closeEvent");
  slotQuit();
}


void Monitor::resizeEvent(QResizeEvent *)
{
  const ushort border   = 12;
  const ushort allmarg  = 3;
  const ushort butwidth = 80;

  uint meterWidth  = width()-(2*border);
  uint meterHeight = height()-221;
  uint meterBottom = Meter->y()+meterHeight;
  uint rightBorder = meterWidth+border;

  // move widgets below ScanMeter (buttons + etched line)

  EtchedBottom->setGeometry(border, meterBottom+allmarg, meterWidth, 2);
  PushHelp->move(border, meterBottom+(2*allmarg)+5);
  PushCustomize->move(border+butwidth+allmarg, meterBottom+(2*allmarg)+5);
  PushNoteBook->move(border+2*(butwidth+allmarg), meterBottom+(2*allmarg)+5);
  PushDock->move(rightBorder-(2*butwidth)-allmarg, meterBottom+(2*allmarg)+5);
  PushQuit->move(rightBorder-butwidth, meterBottom+(2*allmarg)+5);

  Meter->resize(meterWidth, meterHeight);
}


void Monitor::slotDoDChanged(bool enable)
{
  DoDChanged(enable);
}


void Monitor::reloadAccounts( QStrList *isplist, int numisp )
{
  ispcount = numisp;
  if (ispindex >= ispcount) ispindex = ispcount-1;

  writeCombo(isplist);
  ServerCombo->setCurrentItem(ispindex);
}


void Monitor::emitCommand(ISDNCommand *ic)
{
  emit sigCommand(ic);
}
