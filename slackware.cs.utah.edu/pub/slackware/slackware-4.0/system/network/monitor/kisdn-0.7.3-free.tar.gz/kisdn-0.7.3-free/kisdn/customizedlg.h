/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: customizedlg.h,v 1.2 1998/11/21 12:35:10 twesthei Exp $
//
// $Log: customizedlg.h,v $
// Revision 1.2  1998/11/21 12:35:10  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
 
 
#ifndef __CUSTOMIZEDLG_H
#define __CUSTOMIZEDLG_H

#include <qbttngrp.h>
#include <qchkbox.h>
#include <qdialog.h>
#include <qevent.h>
#include <qgrpbox.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qpainter.h>
#include <qpushbt.h>
#include <qradiobt.h>

#include <kslider.h>

#include "accwidget.h"
#include "audiowidget.h"
#include "logo.h"


class ScanColorButton : public QPushButton
{
  private:
  
    QColor  _color;
    bool    _dotted;
    
  protected:
  
    void  drawButtonLabel(QPainter *);

  public:
  
    ScanColorButton(const QColor& col = QColor(green), uint x = 0, uint y = 0, bool dotted = false,
                    QWidget *parent = 0, const char *name = 0);
    ~ScanColorButton() {}
    
    void  setColor(const QColor&);
    void  setDotted(bool);
};


class CColorsWidget : public QWidget
{ 
  Q_OBJECT
  
  private:
  
    QCheckBox  *checkdotted;
    QFrame     *etched;
    QGroupBox  *groupbox;
    QLabel     *pmCustom, *txlabel, *rxlabel, *totlabel, *chalabel, *chblabel, *scalelabel;
  
    ScanColorButton  *grcolbutton[2][3], *scalecolor;
    ScannerData      *scandata;
    
    void  chooseColor(ushort, ushort);
    void  resizeEvent(QResizeEvent *);
  
  private slots:
  
    void  slotColorRxA()     { chooseColor(0, 0); }
    void  slotColorTxA()     { chooseColor(0, 1); }
    void  slotColorTotA()    { chooseColor(0, 2); }
    void  slotColorRxB()     { chooseColor(1, 0); }
    void  slotColorTxB()     { chooseColor(1, 1); }
    void  slotColorTotB()    { chooseColor(1, 2); }
    void  slotScaleColor();  
    void  slotDottedClicked();
  
  public:
  
    CColorsWidget(ScannerData *, QWidget *parent = 0, const char *name = 0);
};


class CScalesWidget : public QWidget
{ 
  Q_OBJECT
  
  private:
  
    QButtonGroup  *ScaleGroup;
    QGroupBox     *groupbox, *scalegbox;
    QLabel        *pmScales, *DistLabel, *FullLabel, *kB1Label, *kB2Label;
    QRadioButton  *AutoScaleButton, *ManScaleButton;
    QVBoxLayout   *ScaleVBox;

    KSlider       *DistSlider, *FullSlider;

    ScannerData   *scandata;

    void  setEnableHide(void);
    void  resizeEvent( QResizeEvent * );
  
  private slots:
  
    void  slotRButtonClicked(int);
    void  slotNewDistance(int);
    void  slotNewRange(int);
  
  public:
  
    CScalesWidget(ScannerData *, QWidget *parent = 0, const char *name = 0);
};


#endif
