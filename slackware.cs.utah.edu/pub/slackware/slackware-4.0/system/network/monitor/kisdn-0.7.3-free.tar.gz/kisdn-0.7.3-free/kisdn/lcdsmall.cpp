/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: lcdsmall.cpp,v 1.2 1998/11/21 12:34:44 twesthei Exp $
//
// $Log: lcdsmall.cpp,v $
// Revision 1.2  1998/11/21 12:34:44  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <qpainter.h>

#include "lcdsmall.h"


SmallLCDNumber::SmallLCDNumber(const QColor& bg, const QColor& dk, const QColor& lg, char l) :
			                                           QPixmap(7, 12),
			                                           _bgcol(bg),
								   _dkcol(dk),
			                                           _lgcol(lg),
								   _letter(l)
{
  drawLetter();
}


/*
 * Private methods
 ******************/
			       
void  SmallLCDNumber::drawLetter()
{
  fill(_bgcol);

  switch (_letter)
  {
    case '0' : drawSegments(true,  true,  true,  true,  true,  true,  false);
               break;
    case '1' : drawSegments(false, true,  true,  false, false, false, false);
               break;
    case '2' : drawSegments(true,  true,  false, true,  true,  false, true);
               break;
    case '3' : drawSegments(true,  true,  true,  true,  false, false, true);
               break;
    case '4' : drawSegments(false, true,  true,  false, false, true,  true);
               break;
    case '5' : drawSegments(true,  false, true,  true,  false, true,  true);
               break;
    case '6' : drawSegments(true,  false, true,  true,  true,  true,  true);
               break;
    case '7' : drawSegments(true,  true,  true,  false, false, false, false);
               break;
    case '8' : drawSegments(true,  true,  true,  true,  true,  true,  true);
               break;
    case '9' : drawSegments(true,  true,  true,  true,  false, true,  true);
               break;
    case 'E' : drawSegments(true,  false, false, true,  true,  true,  true);
               break;    
    default  : drawSegments(true,  true,  true,  true,  true,  true,  false);
               break;
  }
}


void  SmallLCDNumber::drawSegments(bool s0, bool s1, bool s2, bool s3, bool s4, bool s5, bool s6)
{
  QPainter p;
  
  p.begin(this);

  p.setPen(s0 ? _lgcol : _dkcol);
  p.drawLine(1, 0, 5, 0);
  p.drawLine(2, 1, 4, 1);
  
  p.setPen(s1 ? _lgcol : _dkcol);
  p.drawLine(5, 2, 5, 4);
  p.drawLine(6, 1, 6, 5);
  
  p.setPen(s2 ? _lgcol : _dkcol);
  p.drawLine(5, 7, 5, 9);
  p.drawLine(6, 6, 6, 10);
  
  p.setPen(s3 ? _lgcol : _dkcol);
  p.drawLine(2, 10, 4, 10);
  p.drawLine(1, 11, 5, 11);
  
  p.setPen(s4 ? _lgcol : _dkcol);
  p.drawLine(0, 6, 0, 10);
  p.drawLine(1, 7, 1, 9);
  
  p.setPen(s5 ? _lgcol : _dkcol);
  p.drawLine(0, 1, 0, 5);
  p.drawLine(1, 2, 1, 4);
  
  p.setPen(s6 ? _lgcol : _dkcol);
  p.drawLine(2, 5, 4, 5);
  p.drawLine(2, 6, 4, 6);
  
  p.end();
}

			       
/* 
 * Public methods
 *****************/
 
void  SmallLCDNumber::setLetter(char l)
{
  if (l != _letter)
  {
    _letter = l;
    drawLetter();
  }
}

