/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#ifndef __KISDNCONFAPP_H
#define __KISDNCONFAPP_H

#include <qpushbt.h>
#include <qstring.h>
#include <qstrlist.h>

#include <kapp.h>

#include "logo.h"


// class kISDNConfigApplication;


class kISDNConfigDialog : public LogoTabDialog
{
  Q_OBJECT

  friend  class kISDNConfigApplication;

  protected:

    void resizeEvent(QResizeEvent *);

 protected slots:

    virtual void  done(int);
    virtual void  help()  { emit helpButtonPressed(); }

  public:

    kISDNConfigDialog(QWidget *parent = 0, const char *name = 0);
    ~kISDNConfigDialog();

  signals:
  
    void helpButtonPressed();
  
};


class kISDNConfigApplication : public KApplication
{
  Q_OBJECT

  private:

    bool     swallowed;

  protected:

    kISDNConfigDialog  *confdialog;
    QStrList           *confpages;
    QStrList           htmlPages;

  public:

    kISDNConfigApplication(int& argc, char **argv, const char *name);
    ~kISDNConfigApplication();

    bool      runGUI();
    void      setTitle( const char * );
    QStrList  *getPageList()                 { return confpages;            }
    void      setCaption(const QString& cap) { confdialog->setCaption(cap); }

    void      addPage(QWidget *, const QString&, const QString&helpPage = 0);

  public slots:

    virtual void helpPressed();
    virtual void cancel();	
    virtual void apply(); // override this in your kcontrol module class
};


#endif
