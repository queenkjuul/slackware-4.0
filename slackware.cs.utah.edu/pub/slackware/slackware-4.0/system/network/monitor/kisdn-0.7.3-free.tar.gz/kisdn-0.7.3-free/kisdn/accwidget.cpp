/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: accwidget.cpp,v 1.2 1998/11/21 12:34:24 twesthei Exp $
//
// $Log: accwidget.cpp,v $
// Revision 1.2  1998/11/21 12:34:24  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <qpixmap.h>

#include "accwidget.h"
#include "editdlg.h"
#include "minsize.h"


AccountWidget::AccountWidget(QWidget *parent, const char *name) : QWidget(parent, name),
                                                                  _modestr(""),
								  _isplistchanged(false)
{
  KIconLoader     *loader     = kapp->getIconLoader();
  static QPixmap  screen_xpm  = loader->loadIcon("screen.xpm");

  setMinimumSize(MINSIZEX, MINSIZEY);

  account_xpm = loader->loadIcon("mini-account.xpm");

  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 314);
  GBox->setTitle(i18n("Account Setup"));

  pmScreen = new QLabel(this);
  pmScreen->setPixmap(screen_xpm);
  pmScreen->setGeometry(278, 26, 48, 48);

  acclist = new QListBox(this);
  acclist->setGeometry(30, 90, 180, 132);

  connect(acclist, SIGNAL(highlighted(int)), this, SLOT(slotAccSelected(int)));
  connect(acclist, SIGNAL(selected(int)),    this, SLOT(slotChangeName(int)));

  fillIn();

  pushedit = new QPushButton(i18n("Edit..."), this);
  pushedit->setGeometry(227, 90, 94, 28);
  connect(pushedit, SIGNAL(clicked()), SLOT(slotEditAccount()));

  pushcopy = new QPushButton(i18n("Copy"), this);
  pushcopy->setGeometry(227, 125, 94, 28);
  connect(pushcopy, SIGNAL(clicked()), SLOT(slotCopyAccount()));

  pushdel = new QPushButton(i18n("Delete"), this);
  pushdel->setGeometry(227, 160, 94, 28);
  connect(pushdel, SIGNAL(clicked()), SLOT(slotDeleteAccount()));

  resize(MINSIZEX, MINSIZEY);
}


void AccountWidget::fillIn()
{
  acclist->clear();

  for (AccountData *acc = ISDNData.firstAccount(); acc != 0L; acc = ISDNData.nextAccount())
    acclist->insertItem(new KListBoxItem(this, acc->providerName(), account_xpm));
}


void AccountWidget::slotAccSelected(int item)
{
  QString  pname = acclist->text(item);

  if (pname.left(10) == "<disabled>" ) 				// Account is disabled
  {
    pushedit->setEnabled(false);
    pushcopy->setEnabled(false);
  }
  else
  {
    pushedit->setEnabled(true);
    pushcopy->setEnabled(true);
  }
}


void AccountWidget::slotChangeName(int item)
{
  QString  pname = acclist->text(item);

  if (pname.left(10) != "<disabled>" ) 				// Account is enabled
  {
    QString     text     = "New accountname: ";
    const char  *caption = "Change Account Name";

    EditDialog  *dlg = new EditDialog(text, pname.data(), caption, 0L, "", true );

    if (dlg->exec() == QDialog::Accepted)
    {
      AccountData  *newacc = new AccountData(*(ISDNData.account(item)));

      newacc->setProviderName(dlg->text());

      ISDNData.removeAccount(item);
      ISDNData.addAccount(newacc);
      fillIn();
      acclist->setCurrentItem( item );
    }

    delete dlg;
  }
}

void AccountWidget::slotEditAccount()
{
  int  item = acclist->currentItem();

  if (item > -1)
  {
    AccountData  *newacc = new AccountData(*(ISDNData.account(item)));

    if (execAccDialog(newacc, EDIT) != QDialog::Accepted) delete newacc;
    else
    {
      ISDNData.removeAccount(item);
      ISDNData.insertAccount(item, newacc);
      fillIn();
      acclist->setCurrentItem( item );           
    }
  }
}


void AccountWidget::slotCopyAccount(void)
{
  int  item = acclist->currentItem();

  if (item > -1)
  {
    AccountData  *newacc = new AccountData(*(ISDNData.account(item)));

    newacc->setProviderName(newacc->providerName()+"_copy");
    ISDNData.addAccount(newacc);
    fillIn();
    acclist->setCurrentItem( item );           


    _isplistchanged = true;
  }
}


void AccountWidget::slotDeleteAccount()
{
  int  item = acclist->currentItem();

  if (item > -1)
  {
    if (QMessageBox::warning(this, "Delete Account",
    				   "Do you really want to delete the\n"
				   "selected account ?\n\n",
				   "Delete", "Abort",
				   0, 1) == 0)
    {
      ISDNData.removeAccount(item);
      fillIn();

      _isplistchanged = true;
    }
  }
}


void AccountWidget::slotSetCaption(const char *pname)
{
  accdialog->setCaption(_modestr+" "+pname);
}


int AccountWidget::execAccDialog(AccountData *acc, entertype mode)
{
  QString     tmp = i18n("Disconnect when all scripts terminated");
  int         choice;
  ushort      i;
  ScriptData  *connect, *disconnect;

  accdialog = new LogoTabDialog(10, 370);

  if (mode == NEW)
  {
    _modestr = i18n("New Account");
    slotSetCaption("");
  }
  else
  {
    _modestr = i18n("Edit Account");
    slotSetCaption(acc->providerName());
  }

  accdialog->resize(MINSIZEX, MINSIZEY);
  accdialog->setCancelButton();

  connect    = new ScriptData(*(acc->connectScripts()));
  disconnect = new ScriptData(*(acc->disconnectScripts()));
  ExecTab    = new ExecWidget(i18n("Execute on connection"), tmp, connect,    accdialog, 0);
  ExecTab2   = new ExecWidget(i18n("Execute after hangup"),   "", disconnect, accdialog, 0);

  accdialog->addTab(ExecTab,  i18n("Run"));
  accdialog->addTab(ExecTab2, i18n("Run 2"));

  choice = accdialog->exec();

  if (choice == QDialog::Accepted)
  {
    connect->clear();
    disconnect->clear();

    for (i = 0; i < ExecTab->execList->count(); i++)  connect->addLine(ExecTab->execList->text(i));
    for (i = 0; i < ExecTab2->execList->count(); i++) disconnect->addLine(ExecTab2->execList->text(i));

    acc->replaceConnectScripts(connect);
    acc->replaceDisconnectScripts(disconnect);
  }
  else
  {
    delete connect;
    delete disconnect;
  }

  delete accdialog;
  return choice;
}


void AccountWidget::resizeEvent(QResizeEvent *)
{
  int  margin = 10;
  int  w      = width();
  int  h      = height();
  int  buth   = pushedit->height();
  int  buty   = pushedit->y();
  int  maxw   = 0;
  int  butw, butx;

  GBox->resize(w-2*margin, h-2*margin);
  pmScreen->move(w-2*margin-pmScreen->width(), pmScreen->y());

  pushedit->adjustSize();
  pushcopy->adjustSize();
  pushdel->adjustSize();

  maxw = (pushedit->width() > maxw) ? pushedit->width() : maxw;
  maxw = (pushcopy->width() > maxw) ? pushcopy->width() : maxw;
  maxw = (pushdel->width()  > maxw) ? pushdel->width()  : maxw;

  butw = (maxw > 84) ? maxw+10 : 94;
  butx = w-3*margin-butw;

  acclist->resize(butx-5*margin, h/2);

  pushedit->setGeometry(butx, buty,            butw, buth);
  pushcopy->setGeometry(butx, buty+buth+4,     butw, buth);
  pushdel->setGeometry(butx,  buty+2*(buth+4), butw, buth);
}



