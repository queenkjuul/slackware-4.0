/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: timedate.h,v 1.2 1998/11/21 12:35:37 twesthei Exp $
//
// $Log: timedate.h,v $
// Revision 1.2  1998/11/21 12:35:37  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#ifndef __TIMEDATE_H
#define __TIMEDATE_H


#include <sys/time.h>

#include <qdatetime.h>
#include <qstring.h>


class TimeDate
{
  private:
  
    struct timeval  timenow;
    QDate           _date;
    QString         _timestr, _daystr, _datestr;
  
  public:
  
    TimeDate();
    ~TimeDate(){}

    const QString& getTimeString() const { return _timestr; }
    const QString& getDayString()  const { return _daystr;  }		
    const QString& getDateString() const { return _datestr; }		

    const QDate&   getDate()       const { return _date;    }
};


#endif
