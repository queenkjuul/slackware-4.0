#include "mxlineedit.h"


MXLineEdit::MXLineEdit( QWidget *parent, const char *name ) : 
  QLineEdit( parent, name )
{
  readOnly = false;
}


void MXLineEdit::keyPressEvent( QKeyEvent *e )
{
  if ( !readOnly )
    QLineEdit::keyPressEvent( e );
}
