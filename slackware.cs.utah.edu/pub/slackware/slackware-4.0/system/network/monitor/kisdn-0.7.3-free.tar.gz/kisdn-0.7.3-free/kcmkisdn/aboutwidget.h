/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: aboutwidget.h,v 1.1.1.1 1998/11/21 10:18:57 twesthei Exp $

#ifndef ABOUTWIDGET_H
#define ABOUTWIDGET_H

#include <qevent.h>
#include <qframe.h>
#include <qimage.h>
#include <qlabel.h>
#include <qpixmap.h>
#include <qpushbt.h>
#include <qsize.h>
#include <qwidget.h>

#include "kurlwidget.h"


class AboutWidget : public QWidget
{
  Q_OBJECT

  private:

    QFrame       *Frame;
    QLabel       *Logo, *Tux, *Version, *MillenniumX, *Copy;
    QPushButton  *License;
    KURLWidget   *Homepage;

    void  resizeEvent(QResizeEvent *);

  private slots:

    void  showLicense();

  public:

    AboutWidget(QWidget *parent = 0, const char *name = 0);
    ~AboutWidget() {}

    QSize  minimumSize();
};


#endif
