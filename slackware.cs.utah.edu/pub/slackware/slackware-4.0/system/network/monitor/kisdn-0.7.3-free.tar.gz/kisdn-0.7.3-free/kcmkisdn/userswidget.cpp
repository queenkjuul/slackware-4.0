/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#include <sys/types.h>
#include <sys/stat.h>

#include <unistd.h>

#include <qfileinf.h>
#include <qstrlist.h>

#include <kmsgbox.h>

#include "accdlg.h"


UsersWidget::UsersWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  AccData  *acc = ISDNData.Temp;

  GBox = new QGroupBox(this);
  CHECK_PTR( GBox );
  GBox->setTitle(i18n("Users of this account"));
  GBox->setGeometry(10, 8, 328, 316);

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap users_xpm = loader->loadIcon("users.xpm");

  pmUsers = new QLabel(this);
  pmUsers->setPixmap(users_xpm);
  pmUsers->setGeometry(291, 30, 32, 32);

  allowCheck = new QCheckBox(i18n("Enable Account"), this);
  CHECK_PTR(allowCheck);
  allowCheck->adjustSize();
  allowCheck->setGeometry(24, 40, allowCheck->width(), allowCheck->height());
  allowCheck->setChecked(acc->isAccountEnabled);
  connect(allowCheck, SIGNAL(clicked()), SLOT(slotEnableUsage()));

  usersLabel = new QLabel(i18n("User's Homedirectory:"), this);
  CHECK_PTR(usersLabel);
  usersLabel->adjustSize();
  usersLabel->setGeometry(24, 60, usersLabel->width(), 24);

  usersEdit = new QLineEdit(this);
  CHECK_PTR(usersEdit);
  usersEdit->setGeometry(24, 84, 200, 24);
  QToolTip::add(usersEdit, i18n("You can also drop the homedirectories from KFM onto the list"));

  addButton = new QPushButton(i18n("Add"), this);
  CHECK_PTR(addButton);
  addButton->setGeometry(236, 84, 89, 26);
  addButton->setDefault(true);
  connect(addButton, SIGNAL(clicked()), SLOT(slotAddUser()));

  usersListLabel = new QLabel(i18n("Users list:"), this);
  CHECK_PTR(usersListLabel);
  usersListLabel->adjustSize();
  usersListLabel->setGeometry(24, 120, usersListLabel->width(), 24 );

  usersList = new QListBox(this);
  CHECK_PTR(usersList);
  usersList->setGeometry(24, 144, 200, 120);

  editButton = new QPushButton(i18n("Edit"), this);
  CHECK_PTR(editButton);
  editButton->setGeometry(236, 144, 89, 26);
  connect(editButton, SIGNAL(clicked()), SLOT(slotEditUser()));

  remButton = new QPushButton(i18n("Remove"), this);
  CHECK_PTR(remButton);
  remButton->setGeometry(236, 178, 89, 26);
  connect(remButton, SIGNAL(clicked()), SLOT(slotRemoveUser()));

  KDNDDropZone *dropZone = new KDNDDropZone( this , DndURL);
  CHECK_PTR(dropZone);
  connect(dropZone, SIGNAL(dropAction(KDNDDropZone *)), this, SLOT(slotDropEvent(KDNDDropZone *)));

  usersEdit->setFocus();

  // insert all the users
  refreshListBox();

  // enable/disable the widgets
  slotEnableUsage();
}


void UsersWidget::slotAddUser()
{
  QString user = usersEdit->text();

  if (user.isEmpty()) return;

  // take care of an ending /
  if (user.right(1) == "/") user = user.left(user.length()-1);

  // "/" shouldn't be a homedirectory, tho
  if (user.isEmpty()) return;

  QString cfg = user+"/.kde/share/config/kisdnrc";

  // eventually create that file and move the user from QLineEdit to QListBox
  if (checkUser(cfg)) usersList->insertItem(user);

  usersEdit->setText("");
  usersEdit->setFocus();
}


void UsersWidget::slotEditUser()
{
  const int index = usersList->currentItem();

  if (index > -1)
  {
    usersEdit->setText(usersList->text(index));
    slotRemoveUser();
  }
}


void UsersWidget::slotRemoveUser()
{
  const int index = usersList->currentItem();  // the highlighted line

  if (index > -1) usersList->removeItem(index);
}


void UsersWidget::slotDropEvent(KDNDDropZone *dropZone)
{
  QStrList&  urlList = dropZone->getURLList();
  QString    filename, url;

  for (url = urlList.first(); url != 0; url = urlList.next())
  {
    if (url.right(1) != "/") // we only want directories!
    {
      QString tmp(i18n("You can only drop directories\n"));
      tmp += i18n("onto the userlist!\n\n");
      QMessageBox::warning(this, i18n("kISDN Drop Error"), tmp);

      return;
    }
    else // we got a directory
    {
      // cut url-prefix "file:"
      if (url.left(5) == "file:")
      {
        filename = url.right((int) url.length()-5);

	// take care of an ending /
        if (filename.right(1) == "/") filename = filename.left(filename.length()-1);
	
	// "/" shouldn't be a homedirectory
	if (filename.isEmpty()) return;

        QString cfg = filename+"/.kde/share/config/kisdnrc";
	
	// can we write the configfile for the user?
	if (checkUser(cfg)) usersList->insertItem(filename);
      }
      else
      {
        QString tmp( i18n("You can only drop local files\n"));
        tmp += i18n("onto the filelist!\n\n");
        QMessageBox::warning(this, i18n("kISDN Drop Error"), tmp);
      }
    }
  }
}


void UsersWidget::refreshListBox()
{
  AccData  *acc = ISDNData.Temp;

  if (!acc->users.isEmpty())
  {
    usersList->clear();
    QStrList list = acc->users;

    for (QString tmp = list.first(); tmp != 0L; tmp = list.next()) usersList->insertItem(tmp);
  }
}


void UsersWidget::slotEnableUsage()
{
  bool status = allowCheck->isChecked();

  // enable/disable all widgets in this tabdialog

  usersEdit->setEnabled(status);
  usersList->setEnabled(status);
  addButton->setEnabled(status);
  remButton->setEnabled(status);
  editButton->setEnabled(status);
  usersLabel->setEnabled(status);
  usersListLabel->setEnabled(status);

  (ISDNData.Temp)->isAccountEnabled = status;

  usersEdit->setFocus();
}


bool UsersWidget::checkUser(QString cfg)
{
  QFileInfo  fi(cfg.data());

  if (fi.exists())
  {
    if ( chmod( cfg.data(), S_IWRITE) == 0 ) return true;
  }
  else // file doesn't exist, check parent directory
  {
    QString tmp = fi.dirPath(true);

    // parent directory rwx for us?
    if ( access( tmp.data(), R_OK | W_OK | X_OK ) == 0 ) return true;
  }

  // otherwise....

  QString tmp = i18n("I can't write the configfile\n");
  tmp += cfg + "\n";
  tmp += i18n("\nMaybe the directory is missing,\n");
  tmp += i18n("or you don't have write permission.\n");

  (void) KMsgBox::message(this, i18n("Can't configure user"), tmp.data(), KMsgBox::STOP);
  return false;
}


void UsersWidget::resizeEvent(QResizeEvent *)
{
  ushort margin = 10;
  uint w = width();
  uint h = height();

  GBox->resize(w-2*margin, h-2*margin);
  pmUsers->move(w-2*margin-pmUsers->width()-6, pmUsers->y());
}
