/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: isdnctrl.h,v 1.2 1998/11/21 12:35:17 twesthei Exp $
//
// $Log: isdnctrl.h,v $
// Revision 1.2  1998/11/21 12:35:17  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
 
 
#ifndef __ISDNCTRL_H
#define __ISDNCTRL_H

#include <linux/isdn.h>

#define CBOFF 0
#define CBIN  1
#define CBOUT 2


union phonenums
{
  isdn_net_ioctl_phone  phone;
  char                  n[1024];
};


class ISDNCtrl
{
  public:

    enum dialmode  { OFF, MANUAL, AUTO };

  private:
  
    enum  {In, Out};
  
    isdn_net_ioctl_cfg    cfg;
    isdn_net_ioctl_phone  phone;

    int   fd;
    bool  result;
    
  public:
  
    ISDNCtrl();
    ~ISDNCtrl();
    
    bool Dial(char *);					// Standard commands
    bool Hangup(char *);
    bool Addif(char *);
    bool Delif(char *);
    bool Encaps(char *, ushort);
    bool L2_Prot(char *, ushort);
    bool L3_Prot(char *, ushort);
    bool Dialmax(char *, uint);
    bool Huptimeout(char *, uint);
    bool Addphone(char *, char *, ushort);
    bool AddphoneIn(char *id, char *ph)        	{ return Addphone(id, ph, In);  }
    bool AddphoneOut(char *id, char *ph)	{ return Addphone(id, ph, Out); }
    bool Eaz(char *, char *);
    bool Addslave(char *, char *);
    bool Sdelay(char *, uint);
    bool Callback(char *, ushort);
    bool CBHangup(char *, bool);
    bool CBDelay(char *, uint);
    bool Secure(char *, bool);
    bool TStatus(const char *, bool);			// TIMRU
    bool setDialMode(const char *, dialmode);
    
    bool getPhoneNumbers(union phonenums *);		// Internal use only
};


#endif
