/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

#include <qtabbar.h>

#include "kisdnconfapp.h"

kISDNConfigDialog::kISDNConfigDialog(QWidget *parent = 0, const char *name = 0) :
				     LogoTabDialog(parent, name, false)
{
  setHelpButton(i18n("Help"));
  setApplyButton(i18n("Apply"));
  setCancelButton(i18n("Cancel"));
}


kISDNConfigDialog::~kISDNConfigDialog()
{
}

void kISDNConfigDialog::done(int retval)
{
  hide();
  setResult(retval);
  kapp->quit();
}


void kISDNConfigDialog::resizeEvent(QResizeEvent *ev)
{
  LogoTabDialog::resizeEvent(ev);
}


// ---------------------------------------------------------------------------

kISDNConfigApplication::kISDNConfigApplication(int& argc, char **argv, const char *name) :
					       KApplication(argc, argv, name),
					       confdialog(0L),
					       confpages(0L)
{
  swallowed = false;

  confdialog = new kISDNConfigDialog();
  connect ( confdialog, SIGNAL( applyButtonPressed()),  this, SLOT(apply() ));
  connect ( confdialog, SIGNAL( cancelButtonPressed()), this, SLOT(cancel() ));
  connect ( confdialog, SIGNAL( helpButtonPressed()),   this, SLOT(helpPressed() ));

  setMainWidget(confdialog);
  confdialog->resize(480, 480);

  if (argc >= 3 && strcmp( argv[1], "-swallow" ) == 0)
  {
    swallowed = true;
    setCaption( argv[2] );
  }
}


kISDNConfigApplication::~kISDNConfigApplication()
{
  delete confdialog;
}


bool kISDNConfigApplication::runGUI()
{
  return true;
}

void kISDNConfigApplication::setTitle( const char *title )
{
  if ( !swallowed )
    setCaption( title );
}


void  kISDNConfigApplication::addPage(QWidget *child, const QString& label, const QString& helpPage)
{
  confdialog->addPage(child, label, helpPage);
  htmlPages.append(helpPage);
}


void kISDNConfigApplication::helpPressed()
{
  QString filename = htmlPages.at(confdialog->tabBar()->currentTab());
  kapp->invokeHTMLHelp( "kcontrol/kisdn/" + filename, "" );
}


void kISDNConfigApplication::cancel()
{
  debug("Cancel Settings - override this method");
}


void kISDNConfigApplication::apply()
{
  debug("Apply Settings - override this method");
}
