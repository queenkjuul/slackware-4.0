#ifndef SPLASHSCREEN_H
#define SPLASHSCREEN_H

#include <qlabel.h>

#include "logo.h"

class SplashScreen : public QLabel
{
  Q_OBJECT

public:
  SplashScreen( const char *, int );
  SplashScreen( const char *, int, bool );
  ~SplashScreen();

  bool exec();
  void setCaption( const char *t ) { dialog->setCaption( t ); }

private:
  LogoTabDialog *dialog;

private slots:
  void finished();
};

#endif
