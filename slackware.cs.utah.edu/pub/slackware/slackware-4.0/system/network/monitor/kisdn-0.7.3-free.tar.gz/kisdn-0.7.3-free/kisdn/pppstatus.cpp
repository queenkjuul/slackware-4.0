/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: pppstatus.cpp,v 1.2 1998/11/21 12:34:55 twesthei Exp $
//
// $Log: pppstatus.cpp,v $
// Revision 1.2  1998/11/21 12:34:55  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include <stdio.h>
#include <sys/types.h>
#include <sys/fcntl.h>
#include <sys/ioctl.h>

#include <kapp.h>

#include "pppstatus.h"


PPPStatus::PPPStatus(ISDNInfo *info) : fd(-1)
{
  ushort i;

  isdninfo = info;
  fd       = open("/dev/isdninfo", O_RDONLY | O_NDELAY);

  if (fd < 0)
  {
    fprintf(stderr, "Can't open /dev/isdninfo");
    kapp->quit();
  }

  for (i = 0; i < ISDN_MAX_CHANNELS; i++)
  {
    ioBytes[i].ibytes = 0;
    ioBytes[i].obytes = 0;
      
  }

  oldpppinfo = new PPPInfo();
  newpppinfo = new PPPInfo();
    
  gettimeofday(&TimeLast, NULL); 
  TimeNow = TimeLast;
  
  oldpppinfo->timeHours = (ushort) (TimeLast.tv_sec/3600);
  oldpppinfo->timeMins  = (ushort) (TimeLast.tv_sec%3600);
  
  (void) getCPS(oldpppinfo);
  
  for (i = 0; i < 2; i++)
  {
    oldpppinfo->totalBytesIn[i]  = 0;
    oldpppinfo->totalBytesOut[i] = 0;
  }
  
  *newpppinfo = *oldpppinfo;
    
  scantimer = new QTimer(this);
  connect(scantimer, SIGNAL(timeout()), this, SLOT(slotScanRates()));
  scantimer->start(2000, true);  
}


PPPStatus::~PPPStatus(void)
{
  if (fd > 0) close(fd);
  
  delete oldpppinfo;
  delete newpppinfo;
  delete scantimer;
}


bool PPPStatus::getCPS(PPPInfo *info)
{
  if (ioctl(fd, IIOCGETCPS, &ioBytes)) 
  {
    fprintf(stderr, "IOCTL error (IIOCGETCPS)\n");       
    return (false);
  } 
  else
  {
    for (ushort i = 0; i < 2; i++)
    {    
      info->totalBytesIn[i]  = ioBytes[i].ibytes;
      info->totalBytesOut[i] = ioBytes[i].obytes;
    }
    return (true);
  }
}


void PPPStatus::slotScanRates(void)
{
  float      deltaKBytes, Rate;
  int        secondsPassed;
  struct tm  *LocTime;
  
  gettimeofday(&TimeNow, NULL);
  LocTime = localtime((time_t *) &TimeNow);
  
  newpppinfo->timeHours = LocTime->tm_hour;
  newpppinfo->timeMins  = LocTime->tm_min;  
  
  secondsPassed   = (TimeNow.tv_sec+TimeNow.tv_usec/1000000)-(TimeLast.tv_sec+TimeLast.tv_usec/1000000);
  
  TimeLast = TimeNow; 
  
  *oldpppinfo = *newpppinfo;
  
  if (getCPS(newpppinfo))     
  {
    for (ushort i = 0; i < 2; i++)
    {
      if (newpppinfo->totalBytesIn[i]) 
      {
        deltaKBytes = (float)(newpppinfo->totalBytesIn[i] - oldpppinfo->totalBytesIn[i])/1024;	
	Rate        = deltaKBytes/secondsPassed;
	
	if (secondsPassed && (Rate < 30.0)) newpppinfo->inRate[i] = Rate; 
	else                                newpppinfo->inRate[i] = 0.0;
      }  
       
      if (newpppinfo->totalBytesOut[i]) 
      {
        deltaKBytes = (float)(newpppinfo->totalBytesOut[i] - oldpppinfo->totalBytesOut[i])/1024;
	Rate        = deltaKBytes/secondsPassed;
	
	if (secondsPassed && (Rate < 30.0)) newpppinfo->outRate[i] = deltaKBytes/secondsPassed; 
	else                                newpppinfo->outRate[i] = 0.0;
      }
  
      if (!isdninfo->queryOnline(i))
      {
        newpppinfo->inRate[i]  = 0;	// 'Cause HiSax returned strange transfer rates
        newpppinfo->outRate[i] = 0;	// when link is actually down...
      }
      
      if ((newpppinfo->inRate[i]  < 0) || (newpppinfo->inRate[i]  > 20)) newpppinfo->inRate[i]  = 0.0;	
      if ((newpppinfo->outRate[i] < 0) || (newpppinfo->outRate[i] > 20)) newpppinfo->outRate[i] = 0.0;	
    }
    emit sigNewTransferRates(newpppinfo);
  }   
  scantimer->start(2000, true);    
}
