/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: logo.h,v 1.1.1.1 1998/11/21 10:18:58 twesthei Exp $
//
// $Log: logo.h,v $
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
//
// Revision 1.2  1998/10/23 19:06:20  twesthei
// Implemented new logo (partially)
//


#ifndef __LOGO_H
#define __LOGO_H

#include <qevent.h>
#include <qlabel.h>
#include <qtabdlg.h>

#include <kapp.h>
#include <kiconloader.h>


class LogoTabDialog : public QTabDialog
{
  private:

    bool     hasWidget;
    
    QLabel   *Logo;
    QPixmap  pm;
    QWidget  *w;
    
#if QT_VERSION >= 140
    void  resizeEvent(QResizeEvent *);
#endif

  public:

    LogoTabDialog(QWidget *parent = 0, const char *name = 0, bool modal = true);
    LogoTabDialog(const char **, QWidget *parent = 0, const char *name = 0, bool modal = true);
    LogoTabDialog(const char **, uint, uint, QWidget *parent = 0, const char *name = 0, bool modal = true);
    LogoTabDialog(uint, uint, QWidget *parent = 0, const char *name = 0, bool modal = true);

    void  addWidget(QWidget *);
};

#endif

