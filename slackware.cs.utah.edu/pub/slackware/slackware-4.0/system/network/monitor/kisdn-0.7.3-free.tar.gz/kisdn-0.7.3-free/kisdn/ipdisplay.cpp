/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: ipdisplay.cpp,v 1.2 1998/11/21 12:34:39 twesthei Exp $
//
// $Log: ipdisplay.cpp,v $
// Revision 1.2  1998/11/21 12:34:39  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include <qpalette.h> 
#include <qtooltip.h>
 
#include <kapp.h>
#include <kiconloader.h>

#include "ipdisplay.h"
#include "mtxdisplay.h"


IPDisplay::IPDisplay(ISDNInfo *ii, MatrixFont *mf, QWidget *parent, const char *name) : 
	                                                            QWidget(parent, name),
								    isdninfo(ii),
								    mtxfont(mf),
								    channelshown(0)
{
  KIconLoader  *loader = kapp->getIconLoader();
  QColor       yellow, black;
  QColorGroup  colgrp;
  QPalette     txtpal;
  
  setFixedSize(378, 42);
  
  strcpy(ip0, "0.0.0.0");
  formatIP(ip0);
  
  mtxlocalip  = new MatrixPixmap(mtxfont, ip0);
  mtxremoteip = new MatrixPixmap(mtxfont, ip0);
  
  frame = new QFrame(this);
  frame->setLineWidth(2);
  frame->setFrameStyle(QFrame::Panel | QFrame::Sunken);
  frame->setGeometry(0, 0, 352, 42); 
  frame->setBackgroundColor(QColor::QColor(black));
  
  yellow = QColor(0xf0, 0xec, 0x30);
  black  = QColor(black);
  colgrp = QColorGroup(yellow, black, yellow, black, yellow, yellow, black);
  txtpal = QPalette(colgrp, colgrp, colgrp);
  
  localbox = new QLabel(i18n("IP address of local machine:"), frame);
  localbox->setPalette(txtpal);
  localbox->setFont(QFont::QFont("Helvetica", 10));
  localbox->adjustSize();
  localbox->move(4, 6);
  
  remotebox = new QLabel(i18n("IP address of remote machine:"), frame);
  remotebox->setPalette(txtpal);
  remotebox->setFont(QFont::QFont("Helvetica", 10));
  remotebox->adjustSize();
  remotebox->move(4, 22);
  
  localip = new QLabel(frame);
  localip->setPixmap(*mtxlocalip);
  localip->adjustSize();
  localip->move(181, 5);
  
  remoteip = new QLabel(frame);
  remoteip->setPixmap(*mtxremoteip);
  remoteip->adjustSize();
  remoteip->move(181, 23);
  
  pmcha = loader->loadIcon("cha.xpm");
  pmchb = loader->loadIcon("chb.xpm");

  chasel = new QPushButton(this);
  chasel->setPixmap(pmcha);
  chasel->setToggleButton(true);
  chasel->setGeometry(358, 0, 20, 20);
  chasel->setOn(true);
  connect(chasel, SIGNAL(clicked()), this, SLOT(slotChAClicked()));
  QToolTip::add(chasel, i18n("IP's for channel A"));
  
  chbsel = new QPushButton(this);
  chbsel->setPixmap(pmchb);
  chbsel->setToggleButton(true);
  chbsel->setGeometry(358, 22, 20, 20);  
  chbsel->setOn(false);
  connect(chbsel, SIGNAL(clicked()), this, SLOT(slotChBClicked()));
  QToolTip::add(chbsel, i18n("IP's for channel B"));
}


char *IPDisplay::formatIP(char *ipstr)
{
  int  a, b, c, d;
  
  sscanf(ipstr, "%i.%i.%i.%i", &a, &b, &c, &d);
  sprintf(ipstr, "%3i.%3i.%3i.%3i", a, b, c, d);
  
  return ipstr;
}


void IPDisplay::refreshIPs()
{
  strcpy(ipbuf, isdninfo->queryLocalIP(channelshown));
  formatIP(ipbuf);
  mtxlocalip->setText(ipbuf);	
  localip->setPixmap(*mtxlocalip);

  strcpy(ipbuf, isdninfo->queryRemoteIP(channelshown));
  formatIP(ipbuf);
  mtxremoteip->setText(ipbuf);	
  remoteip->setPixmap(*mtxremoteip);
}


void IPDisplay::slotNewIPLocalA(char *ip)
{
  if (!channelshown)
  {
    strcpy(ipbuf, ip);  
    formatIP(ipbuf);

    if (strcmp(ipbuf, mtxlocalip->text())) 
    {
      mtxlocalip->setText(ipbuf);
      localip->setPixmap(*mtxlocalip);
    }
  }
}


void IPDisplay::slotNewIPRemoteA(char *ip)
{ 
  if (!channelshown)
  {
    strcpy(ipbuf, ip);  
    formatIP(ipbuf);
  
    if (strcmp(ipbuf, mtxremoteip->text())) 
    {
      mtxremoteip->setText(ipbuf);
      remoteip->setPixmap(*mtxremoteip);
    } 
  }
}


void IPDisplay::slotNewIPLocalB(char *ip)
{
  if (channelshown)
  {
    strcpy(ipbuf, ip);  
    formatIP(ipbuf);

    if (strcmp(ipbuf, mtxlocalip->text())) 
    {
      mtxlocalip->setText(ipbuf);
      localip->setPixmap(*mtxlocalip);
    }
  }
}


void IPDisplay::slotNewIPRemoteB(char *ip)
{
  if (channelshown)
  {
    strcpy(ipbuf, ip);  
    formatIP(ipbuf);
  
    if (strcmp(ipbuf, mtxremoteip->text())) 
    {
      mtxremoteip->setText(ipbuf);
      remoteip->setPixmap(*mtxremoteip);
    } 
  }
}


void IPDisplay::slotChAClicked()
{
  bool newstate = chasel->isOn();
  
  chbsel->setOn(!newstate);
  
  channelshown = 1-channelshown;
  refreshIPs();
}


void IPDisplay::slotChBClicked()
{
  bool newstate = chbsel->isOn();
  
  chasel->setOn(!newstate);
  
  channelshown = 1-channelshown;
  refreshIPs();
}




