/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include "accdlg.h"


CallBackWidget::CallBackWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  AccData  *acc = ISDNData.Temp;
  QSize    size;
  int      wd, hg;
  QString  tmp;
  uint     top = 36;
  
  GBox = new QGroupBox(this);
  GBox->setTitle(i18n("Callback Setup"));
  GBox->setGeometry(10, 8, 328, 316);

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap callback_xpm = loader->loadIcon("callback.xpm");

  pmCallBack = new QLabel(this);
  pmCallBack->setPixmap(callback_xpm);
  pmCallBack->setGeometry(287, 28, 32, 32);
  
  cbcheck = new QCheckBox(i18n("Enable Callback"), this);
  size = cbcheck->sizeHint();
  wd   = size.width();
  hg   = size.height();
  cbcheck->setGeometry(20, top-4, wd, hg);
  cbcheck->setChecked(acc->callback);
  connect(cbcheck, SIGNAL(clicked()), this, SLOT(slotCBStateChanged()));
  
  ingoingbox = new QGroupBox(this);
  ingoingbox->setGeometry(20, top+24, 288, 86);
  ingoingbox->setTitle(i18n("Remote incoming phone numbers"));

  ingoinggroup = new QButtonGroup(ingoingbox);
  ingoinggroup->setLineWidth(0);
  
  ingoingvbox = new QVBoxLayout(ingoinggroup, 10);
  ingoinggroup->move(10, 16);
    
  strip0button = new QRadioButton(ingoinggroup);
  strip0button->setText(i18n("Strip leading 0's from outgoing numbers"));
  strip0button->setChecked(acc->strip0);
  ingoingvbox->addWidget(strip0button);
  strip0button->setMinimumSize(strip0button->sizeHint());
  
  otherbutton = new QRadioButton(ingoinggroup);
  otherbutton->setText(i18n("Other:"));
  otherbutton->setChecked(!acc->strip0);
  ingoingvbox->addWidget(otherbutton);
  otherbutton->setMinimumSize(otherbutton->sizeHint());
  
  ingoingvbox->activate();
  connect(ingoinggroup, SIGNAL(clicked(int)), SLOT(slotIngoingClicked(int))); 
  
  remin = new QLineEdit(ingoingbox);
  remin->setText(acc->ingoingphone);
  size  = remin->sizeHint();
  hg    = size.height();
  remin->setGeometry(140, otherbutton->y(), 140, hg);
  
  initbox = new QGroupBox(this);
  initbox->setGeometry(20, top+118, 288, 60);
  initbox->setTitle("        ");

  initcheck = new QCheckBox(i18n("Local machine initiates callback"), initbox);
  size = initcheck->sizeHint();
  wd   = size.width();
  hg   = size.height();
  initcheck->setGeometry(20, 0, wd, hg);
  initcheck->setChecked(acc->cbinit);
  connect(initcheck, SIGNAL(clicked()), this, SLOT(slotInitClicked()));
  
  ihuplabel = new QLabel(i18n("Hangup after"), initbox);
  size = ihuplabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  ihuplabel->setGeometry(130-wd, 8+(60-hg)/2, wd, hg);
  
  ihangup = new QLineEdit(initbox);
  size = ihangup->sizeHint();
  hg   = size.height();
  ihangup->setGeometry(140, 8+(60-hg)/2, 60, hg);
  tmp.sprintf("%i", acc->huptime);
  ihangup->setText(tmp.data());
  
  iseclabel = new QLabel(i18n("seconds"), initbox);
  size = iseclabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  iseclabel->setGeometry(210, 8+(60-hg)/2, wd, hg);

  answerbox = new QGroupBox(this);
  answerbox->setGeometry(20, top+188, 288, 90);
  answerbox->setTitle("        ");

  answercheck = new QCheckBox(i18n("Local machine answers callback"), answerbox);
  size = answercheck->sizeHint();
  wd   = size.width();
  hg   = size.height();
  answercheck->setGeometry(20, 0, wd, hg);
  answercheck->setChecked(!acc->cbinit);
  connect(answercheck, SIGNAL(clicked()), this, SLOT(slotAnswerClicked()));

  hupcheck = new QCheckBox(i18n("Hangup before calling back"), answerbox);
  size = hupcheck->sizeHint();
  wd   = size.width();
  hg   = size.height();
  hupcheck->setGeometry(20, 8+(60-hg)/2, wd, hg);
  hupcheck->setChecked(acc->cbhangup);
  
  ahuplabel = new QLabel(i18n("Callback after"), answerbox);
  size = ahuplabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  ahuplabel->setGeometry(130-wd, 38+(60-hg)/2, wd, hg);
  
  ahangup = new QLineEdit(answerbox);
  size = ahangup->sizeHint();
  hg   = size.height();
  ahangup->setGeometry(140, 38+(60-hg)/2, 60, hg);
  tmp.sprintf("%i", acc->cbtime);
  ahangup->setText(tmp.data());
  
  aseclabel = new QLabel(i18n("seconds"), answerbox);
  size = aseclabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  aseclabel->setGeometry(210, 38+(60-hg)/2, wd, hg);

  setDialogState(cbcheck->isChecked());  
}


void CallBackWidget::setDialogState(bool state)
{
  setIngoingState(state);
  setInitState(state && initcheck->isChecked());
  initcheck->setEnabled(state);
  setAnswerState(state && !initcheck->isChecked());
  answercheck->setEnabled(state);
} 

  
void CallBackWidget::setIngoingState(bool state)
{
  AccData  *acc = ISDNData.Temp;
  
  strip0button->setEnabled(state);
  otherbutton->setEnabled(state);
  remin->setEnabled(state && !acc->strip0);
}


void CallBackWidget::setInitState(bool state)
{
  ihuplabel->setEnabled(state);
  ihangup->setEnabled(state);
  iseclabel->setEnabled(state);
}


void CallBackWidget::setAnswerState(bool state)
{
  hupcheck->setEnabled(state);
  ahuplabel->setEnabled(state);
  ahangup->setEnabled(state);
  aseclabel->setEnabled(state);
}


void CallBackWidget::slotCBStateChanged(void)
{
  setDialogState(cbcheck->isChecked());
}


void CallBackWidget::slotIngoingClicked(int but)
{
  AccData  *acc = ISDNData.Temp;
  
  acc->strip0 = !(bool) but;
  setIngoingState(true);
}


void CallBackWidget::slotInitClicked(void)
{
  if (initcheck->isChecked())
  {
    setInitState(true);
    answercheck->setChecked(false);
    setAnswerState(false);
  }
  else 
  {
    setInitState(false);
    answercheck->setChecked(true);
    setAnswerState(true);
  }
}


void CallBackWidget::slotAnswerClicked(void)
{
  if (answercheck->isChecked())
  {
    initcheck->setChecked(false);
    setInitState(false);
    setAnswerState(true);
  }
  else
  {
    initcheck->setChecked(true);
    setInitState(true);
    setAnswerState(false);
  }
}


void CallBackWidget::resizeEvent(QResizeEvent *)
{
  ushort margin = 10;
  uint   w      = width();
  uint   h      = height();

  GBox->resize(w-2*margin, h-2*margin);
  pmCallBack->move(w-2*margin-pmCallBack->width()-4, pmCallBack->y());
 
  ingoingbox->resize(w-4*margin, ingoingbox->height());
  remin->move(remin->x(), 14+otherbutton->y()+(remin->height()-otherbutton->height())/2);
  initbox->resize(w-4*margin, initbox->height());
  answerbox->resize(w-4*margin, answerbox->height());
} 
