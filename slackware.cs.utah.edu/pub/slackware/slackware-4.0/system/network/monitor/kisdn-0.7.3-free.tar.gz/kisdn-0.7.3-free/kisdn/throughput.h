/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: throughput.h,v 1.2 1998/11/21 12:35:36 twesthei Exp $
//
// $Log: throughput.h,v $
// Revision 1.2  1998/11/21 12:35:36  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __THROUGHPUT_H
#define __THROUGHPUT_H

#include <qframe.h>
#include <qlabel.h>
#include <qstring.h>

#include "mtxdisplay.h"


class ThroughPut : public QFrame
{
  private:
  
    QLabel        *kbs, *display;
    QString       _text;
    MatrixFont    *mtxfont;
    MatrixPixmap  *mtxdisplay;

  public:
  
    ThroughPut(MatrixFont *, QWidget *parent = 0, const char *name = 0);
    ~ThroughPut() { delete display; }
    
    const char *text() const { return _text.data(); }
    
    void setText(const char *);
};


#endif
