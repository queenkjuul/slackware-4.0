/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: customizedlg.cpp,v 1.2 1998/11/21 12:34:32 twesthei Exp $
//
// $Log: customizedlg.cpp,v $
// Revision 1.2  1998/11/21 12:34:32  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include <kapp.h>
#include <kcolordlg.h>

#include "customizedlg.h"
#include "kisdndata.h"
#include "minsize.h"


ScanColorButton::ScanColorButton(const QColor& col, uint x, uint y, bool dotted, 
                                 QWidget *parent, const char *name) : QPushButton(parent, name),
				 				      _color(col),
								      _dotted(dotted)

{
  setGeometry(x, y, 56, 28);
}


/* 
 * Private methods of ScanColorButton
 *************************************/

void  ScanColorButton::drawButtonLabel(QPainter *painter)
{
  int  offs  = 4;
  int  w     = width()-2*offs;
  int  h     = height()-2*offs;
  int  liney = height()/2;
  
  painter->fillRect(offs, offs, w, h, QColor(black));
  painter->setPen(_color);
  
  if (!_dotted) painter->drawLine(offs, liney, offs+w-1, liney);
  else
    for (int i = 0; i < w; i += 2) painter->drawPoint(offs+i, liney);
}


/* 
 * Public methods of ScanColorButton
 ************************************/

void  ScanColorButton::setColor(const QColor& color)
{
  _color = color;
  repaint();
}


void  ScanColorButton::setDotted(bool dotted)
{
  _dotted = dotted;
  repaint();
}


CColorsWidget::CColorsWidget(ScannerData *scan, QWidget *parent, const char *name) : QWidget(parent, name),
										     scandata(scan)
{
  ushort          ch, type;
  KIconLoader     *loader    = kapp->getIconLoader();
  static QPixmap  custom_xpm = loader->loadIcon("custom.xpm");
  
  setMinimumSize(MINSIZEX, MINSIZEY);
  
  groupbox = new QGroupBox(this);
  groupbox->setGeometry(10, 8, 328, 314);
  groupbox->setTitle(i18n("Graph Colors"));
  
  pmCustom = new QLabel(groupbox);
  pmCustom->setPixmap(custom_xpm);
  pmCustom->setGeometry(290, 30, 29, 32);
  
  chalabel = new QLabel(i18n("Channel A:"), groupbox);
  chalabel->adjustSize();
  chalabel->move(20, 110);
  
  chblabel = new QLabel(i18n("Channel B:"), groupbox);
  chblabel->adjustSize();
  chblabel->move(20, 146);
  
  rxlabel  = new QLabel(i18n("Receive"), groupbox);
  rxlabel->adjustSize();
  rxlabel->move(113, 82);
  
  txlabel  = new QLabel(i18n("Transmit"), groupbox);
  txlabel->adjustSize();
  txlabel->move(180, 82);
  
  totlabel = new QLabel(i18n("Total"), groupbox);
  totlabel->adjustSize();
  totlabel->move(255, 82);
  
  QPainter p;
  
  for (ch = 0; ch < 2; ch++)
    for (type = 0; type < 3; type++)
      grcolbutton[ch][type] = new ScanColorButton(scandata->graphColor(ch, type), 
                                                  110+type*68, 110+ch*34, false, groupbox);
  etched = new QFrame(groupbox);
  etched->setFrameStyle(0x34);
  etched->setLineWidth(2);
  etched->setGeometry(10, 184, 284, 2);

  scalelabel = new QLabel(i18n("Division:"), groupbox);
  scalelabel->adjustSize();
  scalelabel->move(20, 218);
  
  scalecolor = new ScanColorButton(scandata->scaleColor(), 110, 228, scandata->dottedLines(), groupbox);
 
  checkdotted = new QCheckBox(i18n("Dotted Division Lines"), groupbox);
  checkdotted->adjustSize();
  checkdotted->move(20, 270);
  checkdotted->setChecked(scandata->dottedLines());
  
  connect(grcolbutton[0][0], SIGNAL(clicked()), this, SLOT(slotColorRxA()));
  connect(grcolbutton[0][1], SIGNAL(clicked()), this, SLOT(slotColorTxA()));
  connect(grcolbutton[0][2], SIGNAL(clicked()), this, SLOT(slotColorTotA()));
  connect(grcolbutton[1][0], SIGNAL(clicked()), this, SLOT(slotColorRxB()));
  connect(grcolbutton[1][1], SIGNAL(clicked()), this, SLOT(slotColorTxB()));
  connect(grcolbutton[1][2], SIGNAL(clicked()), this, SLOT(slotColorTotB()));
  connect(scalecolor,        SIGNAL(clicked()), this, SLOT(slotScaleColor()));
  connect(checkdotted,       SIGNAL(clicked()), this, SLOT(slotDottedClicked()));
}


void CColorsWidget::chooseColor(ushort ch, ushort type)
{
  QColor  color;  
  int     choice = KColorDialog::getColor(color);
  
  if (choice == 1)
  {
    scandata->setGraphColor(ch, type, color);
    
    grcolbutton[ch][type]->setColor(color);
    grcolbutton[ch][type]->setDotted(false);
  } 
}

  
void CColorsWidget::slotDottedClicked(void)
{
  scalecolor->setColor(scandata->scaleColor());
  scalecolor->setDotted(checkdotted->isChecked());
  
  scandata->setDottedLines(checkdotted->isChecked());
}


void CColorsWidget::slotScaleColor(void)
{
  QColor  color;
  int     choice = KColorDialog::getColor(color);
  
  if (choice == 1)
  {
    scandata->setScaleColor(color);

    scalecolor->setColor(color);
    scalecolor->setDotted(scandata->dottedLines());
  } 
}


void CColorsWidget::resizeEvent(QResizeEvent *)
{
  ushort  margin  = 10;
  int     w       = width();
  int     h       = height();
  int     boxw    = w-2*margin;
  int     boxh    = h-2*margin;
  int     etchedy = int(0.6*boxh);
  int     butx    = grcolbutton[0][0]->x();
  int     buty    = grcolbutton[0][0]->y();  
  int     butdx   = 8;
  int     butdy   = 4;
  int     butw    = (boxw-butx-2*margin-2*butdx)/3;
  int     buth    = (etchedy-buty-2*margin+butdy)/2;
  int     labeldy = 8;
  int     i, j;
  
  groupbox->resize(boxw, boxh);
  pmCustom->move(boxw-pmCustom->width()-2*margin, 3*margin);
  
  for (i = 0; i < 2; i++)
    for (j = 0; j < 3; j++)
      grcolbutton[i][j]->setGeometry(butx+j*(butw+butdx), buty+i*(buth+butdy), butw, buth);
  
  rxlabel->move(butx+(butw-rxlabel->width())/2, buty-labeldy-rxlabel->height());
  txlabel->move(butx+butw+butdx+(butw-txlabel->width())/2, buty-labeldy-txlabel->height());
  totlabel->move(butx+2*(butw+butdx)+(butw-totlabel->width())/2, buty-labeldy-totlabel->height());
  
  chalabel->move(2*margin, buty+(buth-chalabel->height())/2);
  chblabel->move(2*margin, buty+(buth-chblabel->height())/2+buth+butdy);
  
  etched->setGeometry(etched->x(), etchedy, boxw-2*margin, etched->height());
  scalecolor->setGeometry(butx, etchedy+2*margin, butw, buth);
  
  scalelabel->move(2*margin, etchedy+2*margin+(buth-scalelabel->height())/2);
  
  checkdotted->move(2*margin, boxh-checkdotted->height()-margin);
}


CScalesWidget::CScalesWidget(ScannerData *scan, QWidget *parent, const char *name) : QWidget(parent, name),
										     scandata(scan)
{
  char            buf[16];
  KIconLoader     *loader   = kapp->getIconLoader();
  static QPixmap  ruler_xpm = loader->loadIcon("ruler.xpm");
  
  setMinimumSize(MINSIZEX, MINSIZEY);
  
  groupbox = new QGroupBox(this);
  groupbox->setGeometry(10, 8, 328, 314);
  groupbox->setTitle(i18n("Graph Scaling"));
  
  pmScales = new QLabel(groupbox);
  pmScales->setPixmap(ruler_xpm);
  pmScales->setGeometry(284, 30, 41, 37);

  scalegbox = new QGroupBox(groupbox);
  scalegbox->setGeometry(20, 87, 288, 180);
  scalegbox->setTitle("        ");
  
  ScaleGroup = new QButtonGroup(groupbox);
  ScaleGroup->setLineWidth(0);

  ScaleVBox = new QVBoxLayout(ScaleGroup, 0);
  ScaleGroup->setGeometry(44, 67, 200, 50);

  AutoScaleButton = new QRadioButton(ScaleGroup);
  AutoScaleButton->setText(i18n("Automatic Resize"));
  AutoScaleButton->adjustSize();
  AutoScaleButton->setChecked(scandata->scalingPolicy() == ScannerData::DYNAMIC);
  ScaleVBox->addWidget(AutoScaleButton);
  
  ManScaleButton = new QRadioButton(ScaleGroup);
  ManScaleButton->setText(i18n("Static Display"));
  ManScaleButton->adjustSize();
  ManScaleButton->setChecked(scandata->scalingPolicy() == ScannerData::STATIC);
  ScaleVBox->addWidget(ManScaleButton);
  
  ScaleVBox->activate();

  connect(ScaleGroup, SIGNAL(clicked(int)), SLOT(slotRButtonClicked(int))); 
  
  DistLabel = new QLabel(i18n("Division Line Distance"), scalegbox);
  DistLabel->adjustSize();
  DistLabel->move(60, 130);

  DistSlider = new KSlider(4, 10, 1, 5, KSlider::Horizontal, scalegbox);
  DistSlider->setGeometry(60, 160, 100, 30); 
  DistSlider->setValue((int) (scandata->scaleDistance()/5));
  connect(DistSlider, SIGNAL(valueChanged(int)), this, SLOT(slotNewDistance(int)));
  
  kB1Label = new QLabel(scalegbox);
  kB1Label->move(220, 158);
  sprintf(buf, "% 2.1f kByte/s", scandata->scaleDistance()/10);
  kB1Label->setText(buf);
  kB1Label->adjustSize();
  
  FullLabel = new QLabel(i18n("Scanner Total Range"), scalegbox);
  FullLabel->adjustSize();
  FullLabel->move(60, 200);

  FullSlider = new KSlider(1, 4, 1, 2, KSlider::Horizontal, scalegbox);
  FullSlider->setGeometry(60, 230, 100, 30); 
  FullSlider->setValue((int) (scandata->scaleRange()/50));
  connect(FullSlider, SIGNAL(valueChanged(int)), this, SLOT(slotNewRange(int)));

  kB2Label = new QLabel(scalegbox);
  kB2Label->move(220, 228);
  sprintf(buf, "%2i.0 kByte/s", (int) scandata->scaleRange()/10);
  kB2Label->setText(buf);
  kB2Label->adjustSize();

  setEnableHide();
}


void CScalesWidget::setEnableHide(void)
{
  bool  state = ManScaleButton->isChecked();
  
  DistLabel->setEnabled(state);
  DistSlider->setEnabled(state);
  kB1Label->setEnabled(state);
  kB1Label->setEnabled(state);
  FullLabel->setEnabled(state);
  FullSlider->setEnabled(state);
  kB2Label->setEnabled(state);
}  


void CScalesWidget::slotRButtonClicked(int button)
{
  scandata->setScalingPolicy(!button ? ScannerData::DYNAMIC : ScannerData::STATIC);
  setEnableHide();
}


void CScalesWidget::slotNewDistance(int dist)
{
  char  buf[16];
  
  scandata->setScaleDistance((float) dist*5);
  sprintf(buf, "% 2.1f kByte/s", (float) (dist)/2);
  kB1Label->setText(buf);
}


void CScalesWidget::slotNewRange(int dist)
{
  char  buf[16];
  
  scandata->setScaleRange((float) dist*50);  
  sprintf(buf, "%2i.0 kByte/s", dist*5);
  kB2Label->setText(buf);
}


void CScalesWidget::resizeEvent(QResizeEvent *)
{
  ushort  margin    = 10;
  int     w         = width();
  int     h         = height();
  int     scaleboxw = w-6*margin;
  int     scaleboxh = h-scalegbox->y()-4*margin;
  int     sliderw   = (scaleboxw-4*margin)/2;
  int     sliderh   = scaleboxh/6;
  int     slidery   = scaleboxh/3;
  
  groupbox->resize(w-2*margin, h-2*margin);
  pmScales->move(w-4*margin-pmScales->width()-2, 3*margin);
  
  scalegbox->resize(scaleboxw, scaleboxh);
  DistSlider->setGeometry(2*margin, slidery, sliderw, sliderh);
  DistSlider->adjustSize();
  FullSlider->setGeometry(2*margin, 2*slidery, sliderw, sliderh);
  FullSlider->adjustSize();
  
  DistLabel->move(2*margin+(sliderw-DistLabel->width())/2, slidery+DistSlider->height());
  FullLabel->move(2*margin+(sliderw-DistLabel->width())/2, 2*slidery+FullSlider->height());
  
  kB1Label->move(6*margin+sliderw, slidery+(DistLabel->height()-kB1Label->height())/2);
  kB2Label->move(6*margin+sliderw, 2*slidery+(FullLabel->height()-kB2Label->height())/2);
}
