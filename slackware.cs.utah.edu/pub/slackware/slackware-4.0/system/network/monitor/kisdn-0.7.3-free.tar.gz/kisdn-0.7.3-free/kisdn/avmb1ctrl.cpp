/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: avmb1ctrl.cpp,v 1.2 1998/11/21 12:34:27 twesthei Exp $
//
// $Log: avmb1ctrl.cpp,v $
// Revision 1.2  1998/11/21 12:34:27  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/ioctl.h>

#include <linux/isdn.h>

#include <linux/b1lli.h>
#include <linux/capi.h>

#include "avmb1ctrl.h"
#include "general.h"


AVMB1Ctrl::AVMB1Ctrl(void)
{
  available = makeDevices();
  
  validports[0] = 0x150;
  validports[1] = 0x250;
  validports[2] = 0x300;
  validports[3] = 0x340;
  validports[4] = 0;
  
  validirqs[0]  = 3;
  validirqs[1]  = 4;
  validirqs[2]  = 5;
  validirqs[3]  = 6;
  validirqs[4]  = 7;
  validirqs[5]  = 9;
  validirqs[6]  = 10;
  validirqs[7]  = 11;
  validirqs[8]  = 12;
  validirqs[9]  = 15;
  validirqs[10] = 0; 
}


bool AVMB1Ctrl::devExists(const char *devname)
{
  int  fd = open(devname, O_RDONLY);

  if (fd)
  {
    close(fd);
    return (true);
  }
  else
  {
    if (fd != ENOENT) ::message("Unexpected error in AVMB1Ctrl::devexists");
    return (false);
  }
}


bool AVMB1Ctrl::makeNode(const char *devname, uint major, uint minor)
{
  char  buffer[64];
  int   success;
  
  fprintf(stderr, "kISDN: Creating device %s...", devname);  
  sprintf(buffer, "mknod %s c %i %i", devname, major, minor);
  success = system(buffer);
  
  if ((success < 0) || (success == 127)) fprintf(stderr, "failed\n");
  else                                   fprintf(stderr, "succeeded\n");
  
  return (success);
}


bool AVMB1Ctrl::makeDevices(void)
{
  char  dev[32];
  bool  success = true;
  
  ::message("Installing CAPI 2.0 devices");
  
  if (!devExists("/dev/capi20")) success = makeNode("/dev/capi20", 68, 0);
  
  for (ushort i = 0; (i < 20) && success; i++)
  {
    sprintf(dev, "/dev/capi20.%02i", i);    
    if (!devExists(dev)) success = success && makeNode(dev, 68, i+1);  
  }

  return (success);
}


bool AVMB1Ctrl::addCard(const char *portaddr, ushort irq)
{
  ushort                 i;
  int                    fd, port = atoi(portaddr);
  capi_manufacturer_cmd  ioctl_s;
  avmb1_carddef          newcard;
  	
  fd = open("/dev/capi20", O_RDWR);
  
  if (fd < 0) 
  {
    ::message("Error opening /dev/capi20");
    return (false);
  }

  for (i = 0; validports[i] && (port != validports[i]); i++);
  
  if (!validports[i]) 
  {
    fprintf(stderr, "kISDN: I/O address %s is invalid for AVM B1\n", portaddr);
    return (false);
  }
    
  for (i = 0; validirqs[i] && (irq != validirqs[i]); i++);
  
  if (!validirqs[i]) 
  {
    fprintf(stderr, "kISDN: IRQ %i is invalid for AVM B1\n", irq);
    return (false);
  }
  
  newcard.port = port;
  newcard.irq  = irq;
    
  ioctl_s.cmd  = AVMB1_ADDCARD;
  ioctl_s.data = &newcard;
  
  if ((ioctl(fd, CAPI_MANUFACTURER_CMD, &ioctl_s)) < 0) 
  {
    ::message("Can't add card");
    return (false);
  }
    
  close(fd);
  fprintf(stderr, "kISDN: AVM B1 added (I/O=%s, IRQ=%i)\n", portaddr, irq);
  return (true);
}


bool AVMB1Ctrl::loadFirmware(const char *fname, uint controller)
{
  capi_manufacturer_cmd  ioctl_s;
  avmb1_loaddef          ldef;
  struct stat            st;
  int                    fd, codefd;
  
  if (stat(fname, &st))
  {
    fprintf(stderr, "kISDN: There is no file %s\n", fname);
    return (false);
  }

  fd = open("/dev/capi20", O_RDWR);
  
  if (fd < 0) 
  {
    ::message("Error opening /dev/capi20");
    return (false);
  }
  
  codefd = open(fname, O_RDONLY);
  
  if (!codefd)
  {
    fprintf(stderr, "kISDN: Can't open %s for reading\n", fname);
    return (false);
  }
  
  ldef.contr       = controller;
  ldef.t4file.len  = st.st_size;
  ldef.t4file.data = (unsigned char *) mmap(0, st.st_size, PROT_READ, MAP_PRIVATE, codefd, 0);
  
  if (ldef.t4file.data == (unsigned char *) -1)
  {
    fprintf(stderr, "kISDN: Can't map %s to memory\n", fname);
    close(codefd);
    return (false);
  }
  
  fprintf(stderr, "kISDN: Loading boot code from %s ... ", fname);
  fflush(stderr);
  
  ioctl_s.cmd  = AVMB1_LOAD;
  ioctl_s.data = &ldef;
  
  if ((ioctl(fd, CAPI_MANUFACTURER_CMD, &ioctl_s)) < 0)
  {
    fprintf(stderr, "failed\n");
    close(codefd);
    close(fd);
    return (false);
  }
  
  munmap((char *)ldef.t4file.data, ldef.t4file.len);
  close(codefd);
  close(fd);
  fprintf(stderr, "succeeded\n");
  
  return (false);
}


bool AVMB1Ctrl::resetCard(uint controller)
{
  capi_manufacturer_cmd  ioctl_s;
  avmb1_resetdef         rdef;
  int                    fd;
  
  fd = open("/dev/capi20", O_RDWR);
  
  if (fd < 0) 
  {
    ::message("Error opening /dev/capi20");
    return (false);
  }

  rdef.contr = controller;
  
  ioctl_s.cmd  = AVMB1_RESETCARD;
  ioctl_s.data = &rdef;

  if ((ioctl(fd, CAPI_MANUFACTURER_CMD, &ioctl_s)) < 0)
  {
    fprintf(stderr, "kISDN: Reset of controller %i failed\n", controller);
    close(fd);
    return (false);
  }
  
  close(fd);
  fprintf(stderr, "kISDN: Controller %i successfully reset\n", controller);
  return (true);
}
