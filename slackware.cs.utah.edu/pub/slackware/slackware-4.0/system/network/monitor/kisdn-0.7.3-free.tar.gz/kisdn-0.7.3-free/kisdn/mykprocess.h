/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

#ifndef MYKPROCESS_H
#define MYKPROCESS_H

#include <sys/types.h>

#include <kprocess.h>

class MyKProcess : public KProcess
{
  Q_OBJECT

public:

  MyKProcess();
  virtual ~MyKProcess() {}

  void dropRoot( uid_t uid ) { myUid = uid; }
  virtual bool start(RunMode runmode = NotifyOnExit,
		     Communication comm = NoCommunication );


protected:
  uid_t myUid;

};


#endif
