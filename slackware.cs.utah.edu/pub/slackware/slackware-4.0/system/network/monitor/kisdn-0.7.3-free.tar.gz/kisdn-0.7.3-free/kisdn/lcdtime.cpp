/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: lcdtime.cpp,v 1.2 1998/11/21 12:34:46 twesthei Exp $
//
// $Log: lcdtime.cpp,v $
// Revision 1.2  1998/11/21 12:34:46  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include "lcdtime.h"


LCDTime::LCDTime(const QColor& bg, const QColor& dk, const QColor& lg, QWidget *parent, 
                 const char *name, int tval, int limit) : QFrame(parent, name),
		                                          _LCD1(bg, dk, lg),
							  _LCD2(bg, dk, lg),
		                                          _timeval(tval),
							  _limit(limit)
{
  _lcdw = _LCD1.width();
  _lcdh = _LCD1.height();
  
  setFixedSize(_lcdw*2+1, _lcdh);
  setBackgroundColor(bg);

  _lcdlabel[0] = new QLabel(this);
  _lcdlabel[0]->setPixmap(_LCD1);
  _lcdlabel[0]->setFixedSize(_lcdw, _lcdh);
  _lcdlabel[0]->move(0, 0);

  _lcdlabel[1] = new QLabel(this);
  _lcdlabel[1]->setPixmap(_LCD2);
  _lcdlabel[1]->setFixedSize(_lcdw, _lcdh);
  _lcdlabel[1]->move(_lcdw+1, 0);
}


/* 
 * Public methods
 *****************/

void  LCDTime::setTime(int tval)
{
  if (tval < _limit)
  {
    if (tval != _timeval)	// Avoid flickering
    {
      _timeval = tval;
      
      _LCD1.setLetter('0'+(tval%100)/10);
      _LCD2.setLetter('0'+(tval%10));
    }
  }
  else
  {
    _LCD1.setLetter('E');
    _LCD2.setLetter('E');
  }
  
  _lcdlabel[0]->setPixmap(_LCD1);
  _lcdlabel[1]->setPixmap(_LCD2);
}


void  LCDTime::setBackGround(const QColor& bg)
{
  _LCD1.setBackGround(bg);
  _LCD2.setBackGround(bg);
  _lcdlabel[0]->setPixmap(_LCD1);
  _lcdlabel[1]->setPixmap(_LCD2);
}


void  LCDTime::setDarkColor(const QColor& dk)
{
  _LCD1.setDarkColor(dk);
  _LCD2.setDarkColor(dk);
  _lcdlabel[0]->setPixmap(_LCD1);
  _lcdlabel[1]->setPixmap(_LCD2);
}


void  LCDTime::setLightColor(const QColor& lg)
{
  _LCD1.setLightColor(lg);
  _LCD2.setLightColor(lg);
  _lcdlabel[0]->setPixmap(_LCD1);
  _lcdlabel[1]->setPixmap(_LCD2);
}


