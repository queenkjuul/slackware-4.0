/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#ifndef __USERPASSDLG_H
#define __USERPASSDLG_H

#include <qdialog.h>
#include <qgrpbox.h>
#include <qlabel.h>
#include <qlined.h>


class UserPassDialog : public QDialog
{
  private:
  
    QGroupBox    *GBox;
    QLabel       *Userlabel, *Passwordlabel, *pmKey, *logo;
    QPushButton  *OK;
  
  public:

    UserPassDialog(const char *, QWidget *parent = 0, const char *name = 0);
    ~UserPassDialog() {}
  
    QLineEdit  *User, *Password;
};


#endif
