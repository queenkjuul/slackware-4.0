/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#ifndef __LOGO_H
#define __LOGO_H

#include <qevent.h>
#include <qglobal.h>
#include <qlabel.h>
#include <qpushbt.h>
#include <qtabdlg.h>

#include <kapp.h>
#include <kiconloader.h>

#include "mxlogo.h"

class LogoTabDialog : public QTabDialog
{
  Q_OBJECT

  private:

    QLabel  	 *Logo;
    QWidget      *w;
    bool         hasWidget;

  protected:

    QPushButton  *helpbut, *applybut;
    QStrList     helpNames;

    void          resizeEvent(QResizeEvent *);

    virtual void  setHelpButton(const char *text = i18n("Help"));
    virtual void  setApplyButton(const char *text = i18n("Apply"));

  protected slots:

    virtual void  apply()   {}
    virtual void  help();

  private slots:

    void applyInternal() { emit applyButtonPressed(); apply(); }

  public:

    LogoTabDialog(QWidget *parent = 0, const char *name = 0, bool modal = true);
    LogoTabDialog(QString, QWidget *parent = 0, const char *name = 0, bool modal = true);
    LogoTabDialog(const char **, QWidget *parent = 0, const char *name = 0, bool modal = true);
    LogoTabDialog(const char **, uint, uint, QWidget *parent = 0, const char *name = 0, bool modal = true);
    LogoTabDialog(uint, uint, QWidget *parent = 0, const char *name = 0, bool modal = true);

    void  addPage(QWidget *child, const QString& label, const QString& helpPage = 0);
    void  setCaption(const QString&);
    void  addWidget( QWidget * );
};

#endif

