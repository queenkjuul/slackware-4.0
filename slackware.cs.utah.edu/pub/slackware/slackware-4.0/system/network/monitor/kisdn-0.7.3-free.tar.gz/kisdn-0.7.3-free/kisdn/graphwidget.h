/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: graphwidget.h,v 1.2 1998/11/21 12:35:14 twesthei Exp $
//
// $Log: graphwidget.h,v $
// Revision 1.2  1998/11/21 12:35:14  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#ifndef __GRAPHWIDGET_H
#define __GRAPHWIDGET_H

#include <qcolor.h>
#include <qlabel.h>
#include <qpainter.h>
#include <qpixmap.h>
#include <qtimer.h>

#include "netinfo.h"
#include "pppstatus.h"

#define MAXHISTORY  1000

#define TYPEREC  0
#define TYPETRA  1
#define TYPETOT  2

#define STAMPX     10
#define STAMPDX    24
#define STAMPDY    11
#define NUMSTAMPS  16


class RateStamp
{
  public:
  
    RateStamp();
    ~RateStamp();
  
    QPixmap  *background, *foreground;
    uint     x, y;
    bool     used;
};


class GraphWidget : public QLabel
{
  Q_OBJECT

  private:
  
    QPixmap    *ClockSep, *ClockDigit[10], *DigitPoint;
    QPixmap    *EvDial, *EvCall, *EvUp, *EvDown, *LegBack;
    QTimer     *clock2;
  
    RateStamp  *Stamp[NUMSTAMPS];
    ISDNInfo   *isdninfo;
    float      OldInRate[2], ActInRate[2], OldOutRate[2], ActOutRate[2];
    float      History[2][3][MAXHISTORY];
    float      Shrink;
    ushort     IndexRate, drawnow, policy;
    bool       Indexed;
    bool       showTimeStamps, showGrid, periodicChecking;
    uint       ScaleDist;
    uint       ScanDX, ScanDY;
    float      ScaleRange;
    
    void   drawGraph(QPainter *, ushort, ushort);
    void   drawScanLine(QPainter *, ushort, ushort, float, float);
    void   shiftHistory();
    void   printTimeIndex(QPixmap *, ushort, ushort);
    void   printEvent(QPixmap *);
    void   drawScales(QPainter *, ushort);
    float  needShrink(ushort);
    float  needGrow(ushort);
    void   drawStamps(QPixmap *, uint);
    void   setBlackBackground();
    void   undrawStamps(QPixmap *, uint);
    void   resizeEvent(QResizeEvent *);
  
  private slots:
  
    void  slotCheckSizing();
  
  public:
  
    QColor     GraphColor[2][3], ScaleColor;
    bool       showChA, showChB, showRec, showTra, showTot, showRateStamps;
    
    GraphWidget(bool, 
                bool showRateStamps = false,
                bool showGrid = false,
                ISDNInfo *info = 0L,
                QWidget *parent = 0,
                const char *name = 0);
	      
    ~GraphWidget();

    void  setColors();
   
  public slots:
  
    void  eventCall()           { printEvent(EvCall); }
    void  eventDial()           { printEvent(EvDial); }
    void  eventLinkUp(ushort)   { printEvent(EvUp);   }
    void  eventLinkDown(ushort) { printEvent(EvDown); }
    
    void  slotDrawScanLine(PPPInfo *);
    void  slotFullRedraw();
};

#endif 
