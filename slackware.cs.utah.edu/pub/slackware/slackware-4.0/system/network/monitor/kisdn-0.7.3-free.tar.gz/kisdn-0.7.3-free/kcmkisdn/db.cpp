/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include <iostream.h>
#include <string.h>

#include "db.h"


enum {KEY_INVALID, KEY_FLAG, KEY_COMMENT, KEY_COUNTRY, KEY_CITY, KEY_BEGIN, KEY_END, KEY_NAME, KEY_PREFIX,
      KEY_ISDN, KEY_DOMAIN, KEY_DNS, KEY_ENCAPS, KEY_LAYER2, KEY_AUTH, 
      KEY_ASSIGN, KEY_NETMASK, KEY_LOGO, KEY_EOF};


ParseStream::ParseStream(char *name): instream(name), _token(0), lineno(0)
{  
  strncpy(filename, name, 255);
  
  *line   = '\0';
  *_value = '\0';
  
  if (!instream) cout << "DB: Can't open database file" << endl;
  
  nextLine();
}


void ParseStream::nextLine()
{
  do readLine();
  while (_token == KEY_COMMENT);
}


void ParseStream::readLine()
{

  char    *bufptr;
  char    key[256];
  ushort  i = 0;
  
  if (instream.eof())
  {
    _token  = KEY_EOF;
    *_value = '\0';
    return;
  }
  
  instream.getline(line, 255); 
  lineno++;
 
  if (!strlen(line)) 
  { 
    _token = KEY_COMMENT;
    return;
  }
    
  bufptr = line;   
  bufptr = eatSpaces(bufptr);
  
  if (*bufptr == '#') 
  {
    bufptr = eatSpaces(++bufptr);
    strcpy(_value, bufptr);
    _token = KEY_COMMENT;
    return;
  }
  
  if (*bufptr != '[')
  {
    fprintf(stderr, "DB: '[' expected in %s at line %i\n", filename, lineno);
    _token = KEY_INVALID;
    return;
  }

  bufptr = eatSpaces(++bufptr);
  memset(key, 0, sizeof(key));
  
  while ((*bufptr != ' ') && (*bufptr != ']')) key[i++] = *bufptr++;
  key[i] = '\0';
  
  bufptr = eatSpaces(bufptr);
  
  if (*bufptr != ']')
  {
    fprintf(stderr, "DB: ']' expected in %s at line %i\n", filename, lineno);
    _token = KEY_INVALID;
    return;
  }

  if (!strcmp("EOF", key)) 
  {
    _token = KEY_EOF;
    return;
  }
  
  bufptr = eatSpaces(++bufptr);
  strcpy(_value, bufptr);
  
  if (!strcmp("Country", key)) { _token = KEY_COUNTRY; return;}
  if (!strcmp("City", key))    { _token = KEY_CITY;    return;}
  if (!strcmp("Begin", key))   { _token = KEY_BEGIN;   return;}
  if (!strcmp("End", key))     { _token = KEY_END;     return;}
  if (!strcmp("Name", key))    { _token = KEY_NAME;    return;}
  if (!strcmp("Prefix", key))  { _token = KEY_PREFIX;  return;}
  if (!strcmp("ISDN", key))    { _token = KEY_ISDN;    return;}
  if (!strcmp("Domain", key))  { _token = KEY_DOMAIN;  return;}
  if (!strcmp("DNS", key))     { _token = KEY_DNS;     return;}
  if (!strcmp("Encaps", key))  { _token = KEY_ENCAPS;  return;}
  if (!strcmp("Layer2", key))  { _token = KEY_LAYER2;  return;}
  if (!strcmp("Auth", key))    { _token = KEY_AUTH;    return;}
  if (!strcmp("Assign", key))  { _token = KEY_ASSIGN;  return;}
  if (!strcmp("Netmask", key)) { _token = KEY_NETMASK; return;}
  if (!strcmp("Flag", key))    { _token = KEY_FLAG;    return;}
  if (!strcmp("Logo", key))    { _token = KEY_LOGO;    return;}
  
  cerr << "DB: Invalid key " << key << " in " << filename << " at line " << lineno << endl;
  _token = KEY_INVALID;
}


char *ParseStream::eatSpaces(char *bufptr)
{
  while ((*bufptr == ' ') || (*bufptr == '\t')) bufptr++;
  return bufptr;
}


DBEntry::DBEntry(void)
{
  valid    = false;
  name     = (QString *) 0L;
  prefix   = (QString *) 0L;
  phone    = new QStrList(TRUE);
  domain   = (QString *) 0L;
  dns      = new QStrList(TRUE);
  netmask  = (QString *) 0L;
  logofile = (QString *) 0L;
  
  encaps = layer2 = authtype = 0;
  assigndyn = true;

  phone->setAutoDelete(TRUE);
  dns->setAutoDelete(TRUE);  
}


DBEntry::DBEntry(ParseStream & instream)
{
  valid    = true;
  name     = (QString *) 0L;
  prefix   = (QString *) 0L;
  phone    = new QStrList(TRUE);
  domain   = (QString *) 0L;
  dns      = new QStrList(TRUE);
  netmask  = (QString *) 0L;
  logofile = (QString *) 0L;
  
  encaps = layer2 = authtype = 0;
  assigndyn = true;

  phone->setAutoDelete(TRUE);
  dns->setAutoDelete(TRUE);
  
  if (instream.token() != KEY_BEGIN) cerr << "DB: [Begin] expected at line " << instream.atLine() << endl;
  
  while(instream.token() != KEY_EOF && instream.token() != KEY_END)
  {
    switch(instream.token())
    {
      case KEY_LOGO    : logofile = new QString(instream.value());
	                 break;
      case KEY_NAME    : name = new QString(instream.value());
	  		 break;
      case KEY_PREFIX  : prefix = new QString(instream.value());
			 break;
      case KEY_ISDN    : phone->append(instream.value());
			 break;
      case KEY_DOMAIN  : domain = new QString(instream.value());
			 break;
      case KEY_DNS     : dns->append(instream.value());
			 break;
      case KEY_AUTH    : authtype = strcmp("PAP", instream.value());
	    		 break;
      case KEY_ENCAPS  : if (!strcmp("syncPPP", instream.value())) encaps = 4; 	/* syncPPP/RawIP only ! */
	    		 else encaps = 0;
			 break;
      case KEY_LAYER2  : if (!strcmp("HDLC", instream.value())) layer2 = 3;	/* HDLC only ! */
	    		 else encaps = 0;
			 break;
      case KEY_ASSIGN  : assigndyn = !strcmp("dynamic", instream.value());
	    		 break;
      case KEY_NETMASK : netmask = new QString(instream.value());
    }
    instream.nextLine();
  }
  
  if (instream.token() != KEY_END) cerr << "DB: [End] expected at line " << instream.atLine() << endl;

  instream.nextLine();
}


DBEntry::~DBEntry(void)
{
  if (name     != (QString *) 0L) delete(name);
  if (prefix   != (QString *) 0L) delete(prefix);
  if (domain   != (QString *) 0L) delete(domain);
  if (logofile != (QString *) 0L) delete(logofile);
  
  delete(phone);
  delete(dns); 
}


City::City(ParseStream & instream): cityname()
{
  if (instream.token() != KEY_CITY) cerr << "DB: [City] expected" << endl;
  
  ISPList.setAutoDelete(true);  
  cityname = instream.value();
  instream.nextLine();
  
  while(instream.token() != KEY_EOF && instream.token() != KEY_COUNTRY && instream.token() != KEY_CITY)
  {
    ISPList.append(new DBEntry(instream));
  }
}


void Country::setFlagFile(const char *name)
{
  if (flagfile != (QString *) 0L) delete flagfile;

  flagfile = new QString(name); 
}


Country::Country(ParseStream & instream): countryname(""), flagfile(0L),  CityList()
{
  if (instream.token() != KEY_COUNTRY) cerr << "DB: [Country] expected" << endl;
  
  CityList.setAutoDelete(true);  
  countryname = instream.value();
  instream.nextLine();

  while(instream.token() != KEY_EOF && instream.token() != KEY_COUNTRY)
  {
    switch (instream.token())
    {
      case KEY_FLAG : flagfile = new QString(instream.value());
                      instream.nextLine();
                      break;
      case KEY_CITY : CityList.append(new City(instream));
       		      break;
      default       : cerr << "[City] or [Flag] expected" << endl;	     	     
    }    
  }
}


Country::~Country()
{
  if (flagfile) delete flagfile;
}


DB::DB(char *fname) : countryList()
{  

  ParseStream  instream(fname);

  countryList.setAutoDelete(true);  
    
  while(instream.token() != KEY_EOF && instream.token() != KEY_COUNTRY) instream.nextLine();
  while(instream.token() != KEY_EOF) countryList.append(new Country(instream));
}
  
