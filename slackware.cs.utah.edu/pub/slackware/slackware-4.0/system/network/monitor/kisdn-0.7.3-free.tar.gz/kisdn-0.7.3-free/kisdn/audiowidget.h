/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: audiowidget.h,v 1.2 1998/11/21 12:35:04 twesthei Exp $
//
// $Log: audiowidget.h,v $
// Revision 1.2  1998/11/21 12:35:04  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//

 
#ifndef __AUDIOWIDGET_H
#define __AUDIOWIDGET_H

#include <kapp.h>
#include <kfiledialog.h>
#include <kiconloader.h>

#include <qchkbox.h>
#include <qevent.h>
#include <qgrpbox.h>
#include <qlabel.h>
#include <qlined.h>
#include <qmsgbox.h>
#include <qpixmap.h>
#include <qpushbt.h>
#include <qtooltip.h>

#include "logo.h"
#include "kaudioplayer.h"
#include "kisdndata.h"


class AudioWidget : public QWidget
{
  Q_OBJECT
  
  private:
    
    QCheckBox     *connchk, *discchk, *dialchk, *busychk, *ringchk, *scriptschk;
    QGroupBox     *groupbox;
    QLabel        *pmSound;
    QPushButton   *browse1, *browse2, *browse3, *browse4, *browse5, *browse6;
    QPushButton   *testAudioConn, *testAudioDisc, *testAudioDial, *testAudioBusy;
    QPushButton   *testAudioRing, *testAudioScripts;
    QString       fileBrowser(QString);

    KAudioPlayer  *audioplayer;
    
    CustomData    *customdata;
    
    void  resizeEvent(QResizeEvent *);
  
  private slots:
  
    void  slotSetEnableAudioConn();
    void  slotSetEnableAudioDisc();
    void  slotSetEnableAudioDial();
    void  slotSetEnableAudioBusy();
    void  slotSetEnableAudioScripts();

    void  slotBrowseWavConn();
    void  slotBrowseWavDisc();
    void  slotBrowseWavDial();
    void  slotBrowseWavBusy();
    void  slotBrowseWavScripts();
  
    void  slotTestAudioConn()    { audioplayer->playSound(connectpath->text(), true);    }
    void  slotTestAudioDisc()    { audioplayer->playSound(disconnectpath->text(), true); }
    void  slotTestAudioDial()    { audioplayer->playSound(dialingpath->text(), true);    }
    void  slotTestAudioBusy()    { audioplayer->playSound(busypath->text(), true);       }
    void  slotTestAudioScripts() { audioplayer->playSound(scriptspath->text(), true);    }

    void  slotDropEvent(KDNDDropZone *);

  public:
  
    AudioWidget(CustomData *, QWidget *parent = 0, const char *name = 0); 
    ~AudioWidget();
  
    QLineEdit  *connectpath, *disconnectpath, *dialingpath, *busypath;
    QLineEdit  *ringpath, *scriptspath;

    void  refreshSettings();  
};


#endif
