/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#include "prefdlg.h"
#include "adapter.h"


DriverWidget::DriverWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  char     buffer[4];
  QSize    size;
  int      wd, hg;
  GenData  *gen = ISDNData.General;

  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 314);
  GBox->setTitle(i18n("Driver Setup"));

  Modulechk = new QCheckBox(i18n("Load driver as a module"), this);
  Modulechk->adjustSize();
  Modulechk->setGeometry(30, 34, Modulechk->width(), Modulechk->height());
  Modulechk->setChecked(gen->loadasmodule);
  connect(Modulechk, SIGNAL(clicked()), SLOT(slotModuleLoadChanged()));

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap gear_xpm = loader->loadIcon("gear.xpm");

  pmGear = new QLabel(this);
  pmGear->setPixmap(gear_xpm);
  pmGear->setGeometry(290, 26, 38, 38);

  Modprobelabel = new QLabel(i18n("modprobe Path:"), this);
  size = Modprobelabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Modprobelabel->setGeometry(140-wd, 72+(24-hg)/2, wd, hg);

  Modprobe = new QLineEdit(this);
  Modprobe->setGeometry(150, 72, 176, 24);
  Modprobe->setMaxLength(PATHSIZE);
  Modprobe->setText(gen->modprobepath.data());

  Browse = new QPushButton(i18n("Browse..."), this);
  Browse->setGeometry(252, 104, 74, 25);
  connect(Browse, SIGNAL(clicked()), SLOT(slotBrowseModPath()));

  Adapterlabel = new QLabel(i18n("ISDN Adapter Type:"), this);
  size = Adapterlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Adapterlabel->setGeometry(140-wd, 144+(24-hg)/2, wd, hg);

  Adbox   = new QComboBox(false, this);
  for (ushort i = 0; i < ad.NumAdp(); i++) Adbox->insertItem((ad.Name[i]).data());
  Adbox->setGeometry(150, 144, 176, 24);
  Adbox->setCurrentItem(ad.NewIndex(gen->adapter));
  connect(Adbox, SIGNAL(activated(int)), SLOT(slotAdapterChanged(int)));

  Iolabel = new QLabel(i18n("I/O Base Addresses:"), this);
  size = Iolabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Iolabel->setGeometry(140-wd, 182+(24-hg)/2, wd, hg);

  Ioaddr0 = new QLineEdit(this);
  Ioaddr0->setGeometry(150, 182, 60, 24);
  Ioaddr0->setMaxLength(6);
  Ioaddr0->setText(gen->iobase0.data());

  Ioaddr1 = new QLineEdit(this);
  Ioaddr1->setGeometry(220, 182, 60, 24);
  Ioaddr1->setMaxLength(6);
  Ioaddr1->setText(gen->iobase1.data());

  Intlabel = new QLabel(i18n("Interrupt:"), this);
  size = Intlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Intlabel->setGeometry(140-wd, 214+(24-hg)/2, wd, hg);

  Interrupt = new QLineEdit(this);
  Interrupt->setGeometry(150, 214, 40, 24);
  Interrupt->setMaxLength(2);
  sprintf(buffer, "%i", gen->interrupt);
  Interrupt->setText(buffer);

  Memlabel = new QLabel(i18n("Membase:"), this);
  size = Memlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Memlabel->setGeometry(140-wd, 246+(24-hg)/2, wd, hg);

  Membase = new QLineEdit(this);
  Membase->setGeometry(150, 246, 60, 24);
  Membase->setMaxLength(8);
  Membase->setText(gen->membase.data());

  setParamState();
  setModState(gen->loadasmodule);
}


void DriverWidget::setModState(bool state)
{
  Modprobelabel->setEnabled(state);
  Modprobe->setEnabled(state);
  Browse->setEnabled(state);
  Adapterlabel->setEnabled(state);
  Adbox->setEnabled(state);

  if (!state)
  {
    Iolabel->setEnabled(state);
    Ioaddr0->setEnabled(state);
    Ioaddr1->setEnabled(state);
    Memlabel->setEnabled(state);
    Membase->setEnabled(state);
  }

  Intlabel->setEnabled(state);
  Interrupt->setEnabled(state);

  (ISDNData.General)->loadasmodule = state;
}


void DriverWidget::setParamState(void)
{
  ushort curr = Adbox->currentItem();

  Iolabel->setEnabled(ad.NeedIO1[curr]);
  Ioaddr0->setEnabled(ad.NeedIO1[curr]);
  Ioaddr1->setEnabled(ad.NeedIO2[curr]);
  Intlabel->setEnabled(ad.NeedIRQ[curr]);
  Interrupt->setEnabled(ad.NeedIRQ[curr]);
  Memlabel->setEnabled(ad.NeedMem[curr]);
  Membase->setEnabled(ad.NeedMem[curr]);
}


void DriverWidget::slotBrowseModPath(void)
{
  KFileDialog *Browser = new KFileDialog("/sbin", "modprobe", this, "", true);
  Browser->setCaption(i18n("Choose modprobe Path"));

  QString ModprobeSel;

  if (Browser->exec() == QDialog::Accepted) ModprobeSel = Browser->selectedFile();

  if (!ModprobeSel.isNull())
  {
    Modprobe->setText(ModprobeSel.data());
    // emit a SIGNAL here ?
  }

  delete (Browser);
}


void DriverWidget::slotModuleLoadChanged(void)
{
  setParamState();
  setModState(Modulechk->isChecked()); // Registration to ISDNData.General is done here.
}


void DriverWidget::slotAdapterChanged(int Adapter)
{
  (ISDNData.General)->adapter = ad.Index[Adapter];  // Ensure compatibility with kISDN < 0.5.0.5
  setParamState();
}


bool DriverWidget::isValidIOAddr(ushort port)
{
  char     buffer[8] = "0x0000", newaddr[8], addr[8], *ioaddr;
  ushort   addrlen = 0;
  Adapter  ad;
  GenData  *gen = ISDNData.General;

  if ((port == 0) && !(ad.NeedIO1[ad.NewIndex(gen->adapter)])) return true;
  if ((port == 1) && !(ad.NeedIO2[ad.NewIndex(gen->adapter)])) return true;

  if (port == 0) strncpy(addr, Ioaddr0->text(), 8);
  else           strncpy(addr, Ioaddr1->text(), 8);

  ioaddr = addr;

  while (*ioaddr == ' ') ioaddr++;

  if (*ioaddr != '\0')
  {
    if ((*(ioaddr++) == '0') && (*(ioaddr++) == 'x'))
    {
      while ((isxdigit(*ioaddr)) && (addrlen < 4)) newaddr[addrlen++] = toupper(*ioaddr++);
      newaddr[addrlen] = '\0';
    }
    else return false;
  }
  else return false;

  if (*ioaddr != '\0') return false;

  strncpy(buffer+6-addrlen, newaddr, addrlen);

  if (port == 0) gen->iobase0 = buffer;
  else           gen->iobase1 = buffer;

  fprintf(stderr, "kISDN: I/O Base %i changed to %s\n", port, buffer);
  return true;
}


bool DriverWidget::isValidInterrupt(void)
{
  uint tmpint = atoi(Interrupt->text());

  if (tmpint <= 15)
  {
    (ISDNData.General)->interrupt = tmpint;
    return true;
  }
  else return false;			
}


bool DriverWidget::isValidMembase(void)
{
  char     buffer[10] = "0x00000", newaddr[8], addr[8], *memaddr;
  ushort   addrlen = 0;
  Adapter  ad;

  if (!(ad.NeedMem[(ISDNData.General)->adapter])) return true;

  strncpy(addr, Membase->text(), 10);
  memaddr = addr;

  while (*memaddr == ' ') memaddr++;

  if (*memaddr != '\0')
  {
    if ((*(memaddr++) == '0') && (*(memaddr++) == 'x'))
    {
      while ((isxdigit(*memaddr)) && (addrlen < 5)) newaddr[addrlen++] = toupper(*memaddr++);
      newaddr[addrlen] = '\0';
    }
    else return false;
  }
  else return false;

  if (*memaddr != '\0') return false;

  strncpy(buffer+7-addrlen, newaddr, addrlen);
  (ISDNData.General)->membase = buffer;
  fprintf(stderr, "Membase changed to %s\n", buffer);
  return true;
}


void DriverWidget::setIOBase(ushort port, QString base)
{
  if (port == 0) Ioaddr0->setText(base.data());
  else           Ioaddr1->setText(base.data());
}


void DriverWidget::setInterrupt(char * inter)
{
  Interrupt->setText(inter);
}


void DriverWidget::setMembase(QString base)
{
  Membase->setText(base.data());
}


QSize DriverWidget::minimumSize()
{
  QSize s(328, 314); // fix this!
  return s;

}


void DriverWidget::resizeEvent(QResizeEvent *)
{
  ushort  margin  = 10; 
  QSize   size;  
  uint    w       = width();
  uint    h       = height();
  uint    wd, hg;
  int     xoff    = (w-328)/2;
  int     yoff    = (h-314)/2;
  
  
  GBox->resize(w-2*margin, h-2*margin);
  pmGear->move(w-2*margin-pmGear->width(), pmGear->y());
  
  size = Modprobelabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Modprobelabel->move(xoff+140-wd, yoff+72+(24-hg)/2);

  Modprobe->move(xoff+150, yoff+72);

  Browse->move(xoff+252, yoff+104);

  size = Adapterlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Adapterlabel->move(xoff+140-wd, yoff+144+(24-hg)/2);

  Adbox->move(xoff+150, yoff+144);

  size = Iolabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Iolabel->move(xoff+140-wd, yoff+182+(24-hg)/2);

  Ioaddr0->move(xoff+150, yoff+182);

  Ioaddr1->move(xoff+220, yoff+182);

  size = Intlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Intlabel->move(xoff+140-wd, yoff+214+(24-hg)/2);

  Interrupt->move(xoff+150, yoff+214);

  size = Memlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Memlabel->move(xoff+140-wd, yoff+246+(24-hg)/2);

  Membase->move(xoff+150, yoff+246);
}
