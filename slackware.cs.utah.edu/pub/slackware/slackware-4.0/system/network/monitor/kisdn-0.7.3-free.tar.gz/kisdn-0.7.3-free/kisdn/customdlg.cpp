/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: customdlg.cpp,v 1.2 1998/11/21 12:34:31 twesthei Exp $
//
// $Log: customdlg.cpp,v $
// Revision 1.2  1998/11/21 12:34:31  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include "customdlg.h"
#include "minsize.h"


CustomDialog::CustomDialog(CustomData *custom, ScannerData *scanner, QWidget *parent, const char *name) :
			   LogoTabDialog(parent, name),
			   customdata(custom),
			   scannerdata(scanner)
{
  setCaption(i18n("kISDN Customization"));
  setCancelButton();
  setMinimumSize(MINSIZEX, MINSIZEY);
  
  accWidget   = new AccountWidget(this);
  genWidget   = new GeneralWidget(customdata, this);
  audioWidget = new AudioWidget(customdata, this);
  colorWidget = new CColorsWidget(scannerdata, this);
  scaleWidget = new CScalesWidget(scannerdata, this);
  aboutwidget = new AboutWidget(this);
  
  addTab(accWidget,   i18n("Accounts"));
  addTab(genWidget,   i18n("General"));
  addTab(audioWidget, i18n("Audio"));
  addTab(colorWidget, i18n("Color"));
  addTab(scaleWidget, i18n("Scale"));
  addTab(aboutwidget, i18n("About"));
  
  resize(MINSIZEX, MINSIZEY);
}			   
