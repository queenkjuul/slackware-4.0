/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: uptdisplay.h,v 1.2 1998/11/21 12:35:38 twesthei Exp $
//
// $Log: uptdisplay.h,v $
// Revision 1.2  1998/11/21 12:35:38  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __UPTDISPLAY_H
#define __UPTDISPLAY_H

#include <qcolor.h>
#include <qframe.h>

#include "uptimenum.h"


class UptimeDisplay : public QFrame
{
  private:
  
    UpTimeNumber  _timeA, _timeB;
    int           _hours[2], _mins[2], _secs[2];
    QLabel        *_utlabel, *_chalabel, *_chblabel;
    
  public:
  
    UptimeDisplay(const QColor&, const QColor&, const QColor&, const QColor&, QWidget *parent = 0, 
                  const char *name = 0);
    ~UptimeDisplay() {}
    
    void  setUptime(int, int, int, int);
};


#endif
