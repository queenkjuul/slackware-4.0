/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: timedate.cpp,v 1.2 1998/11/21 12:35:00 twesthei Exp $
//
// $Log: timedate.cpp,v $
// Revision 1.2  1998/11/21 12:35:00  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#include "timedate.h"


TimeDate::TimeDate()
{
  struct tm *loctime;
  
  gettimeofday(&timenow, NULL);
  loctime = localtime((time_t *) &timenow);   
  
  _timestr.sprintf("%02i:%02i", loctime->tm_hour, loctime->tm_min);
  _datestr.sprintf("%02i.%02i.%4i", loctime->tm_mday, loctime->tm_mon+1, loctime->tm_year+1900);

  _date   = QDate(loctime->tm_year+1900, loctime->tm_mon+1, loctime->tm_mday);  
  _daystr = _date.dayName(_date.dayOfWeek());
}
