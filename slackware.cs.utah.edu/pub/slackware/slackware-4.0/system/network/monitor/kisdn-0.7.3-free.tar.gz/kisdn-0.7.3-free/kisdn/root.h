/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

/**
 * some tiny functions to gain / drop root privileges
 */

#ifndef ROOT_H
#define ROOT_H


bool 	hasRootPrivileges();

bool	becomeRoot();

bool	dropRoot();

#endif
