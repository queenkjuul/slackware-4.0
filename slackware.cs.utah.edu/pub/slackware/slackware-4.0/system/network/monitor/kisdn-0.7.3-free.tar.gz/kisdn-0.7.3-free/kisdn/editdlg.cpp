#include <qdialog.h>
#include <qlabel.h>
#include <qpushbt.h>
#include <qstring.h>

#include "editdlg.h"

EditDialog::EditDialog( QString text, const char *editText, const char *caption,                         QWidget *parent, const char *name, bool modal ) :
                                               QDialog( parent, name, modal )
{
  setCaption( caption );

  const ushort LEFT = 20;
  const ushort MARGIN = 5;
  const ushort LEWIDTH = 250;
  const ushort BWIDTH = 100;
  const ushort HEIGHT = 25;
  const ushort LENGTH = 300;

  QLabel *lb = new QLabel( text, this);
  lb->adjustSize();
  lb->move( LEFT, 20 );

  le = new QLineEdit( this );
  le->setMaxLength( LENGTH );
  le->setText( editText );
  le->setGeometry( LEFT, 40, LEWIDTH, HEIGHT );

  QPushButton *ok, *cancel;
  ok = new QPushButton( "Ok", this );
  ok->setDefault( true );
  ok->setGeometry( LEWIDTH - 2* BWIDTH - MARGIN, 80, BWIDTH, HEIGHT );
  connect( ok, SIGNAL(clicked()), SLOT(accept()) );

  cancel = new QPushButton( "Cancel", this );
  cancel->setGeometry( LEWIDTH - BWIDTH, 80, BWIDTH, HEIGHT );
  connect( cancel, SIGNAL(clicked()), SLOT(reject()) );

  le->setFocus();
  le->selectAll();

  setFixedSize( 300, 120 );
}

