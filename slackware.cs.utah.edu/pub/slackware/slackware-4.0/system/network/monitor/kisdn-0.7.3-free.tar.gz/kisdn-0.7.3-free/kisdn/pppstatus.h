/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: pppstatus.h,v 1.2 1998/11/21 12:35:32 twesthei Exp $
//
// $Log: pppstatus.h,v $
// Revision 1.2  1998/11/21 12:35:32  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#ifndef __PPPSTATUS_H
#define __PPPSTATUS_H

#include <sys/time.h>

#include <linux/isdn.h>

#include <qobject.h>
#include <qtimer.h>

#include "netinfo.h"


typedef struct
{
  ulong ibytes;
  ulong obytes;
} Siobytes;


typedef struct
{
  ulong   totalBytesIn[2];
  ulong   totalBytesOut[2];
  float   inRate[2], outRate[2];
  ushort  timeHours, timeMins;
} PPPInfo;  


class PPPStatus : public QObject
{
  Q_OBJECT

  private:
  
    int             fd;
    
    struct timeval  TimeLast, TimeNow;

    QTimer          *scantimer;

    Siobytes        ioBytes[ISDN_MAX_CHANNELS];
    ISDNInfo        *isdninfo;
    PPPInfo         *oldpppinfo, *newpppinfo;
  
    bool getCPS(PPPInfo *);
  
  private slots:
  
    void slotScanRates();
    
  public:
    
    PPPStatus(ISDNInfo *);
    ~PPPStatus();  
  
  signals:
  
    void sigNewTransferRates(PPPInfo *);
};


#endif
