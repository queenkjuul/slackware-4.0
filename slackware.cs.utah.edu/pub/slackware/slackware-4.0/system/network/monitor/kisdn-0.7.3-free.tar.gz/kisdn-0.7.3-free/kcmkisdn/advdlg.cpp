/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include "prefdlg.h"


DebugWidget::DebugWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  char     buffer[8];
  AdvData  *adv = &((ISDNData.General)->Advanced);
  
  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 314);
  GBox->setTitle(i18n("Debugging Options"));
  
  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap magnify_xpm = loader->loadIcon("magnify.xpm");

  pmMagnify = new QLabel(this);
  pmMagnify->setPixmap(magnify_xpm);
  pmMagnify->setGeometry(296, 30, 26, 27);
  
  Bsdcheck = new QCheckBox(i18n("Disable BSD Compression"), this);
  Bsdcheck->adjustSize();
  Bsdcheck->setGeometry(30, 70, Bsdcheck->width(), Bsdcheck->height() );
  Bsdcheck->setChecked(adv->bsdcomp);
  connect(Bsdcheck, SIGNAL(clicked()), SLOT(slotBSDCompChanged()));

  Dbgcheck = new QCheckBox(i18n("Increase debugging level"), this);
  Dbgcheck->adjustSize();
  Dbgcheck->setGeometry(30, 94, Dbgcheck->width(), Dbgcheck->height() );
  Dbgcheck->setChecked(adv->incdebug);
  connect(Dbgcheck, SIGNAL(clicked()), SLOT(slotIncDebugChanged()));

  Dbglevellabel = new QLabel(i18n("Kernel Debugging Level:"), this);
  Dbglevellabel->setGeometry(30, 148, 150, 24);
  
  Debuglevel = new QLineEdit(this);
  Debuglevel->setGeometry(190, 148, 40, 24);
  sprintf(buffer, "%i", adv->dbglevel);
  Debuglevel->setText(buffer);
}


void DebugWidget::slotBSDCompChanged(void)
{
  (ISDNData.General)->Advanced.bsdcomp = Bsdcheck->isChecked();
}


void DebugWidget::slotIncDebugChanged(void)
{
  (ISDNData.General)->Advanced.incdebug = Dbgcheck->isChecked();
}

void DebugWidget::resizeEvent(QResizeEvent *)
{
  ushort MARGIN = 10;
  uint w = width();
  uint h = height();

  GBox->resize(w-2*MARGIN, h-2*MARGIN);
  pmMagnify->move(w-2*MARGIN-pmMagnify->width(), pmMagnify->y());
}

UnitsWidget::UnitsWidget(QWidget *parent, const char *name):QWidget(parent, name)
{
  char      buffer[8];
  AdvData   *adv = &((ISDNData.General)->Advanced);
  QSize     size;
  int       wd, hg;

  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 314);
  GBox->setTitle(i18n("Transfer Units"));

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap units_xpm = loader->loadIcon("units.xpm");

  pmUnits = new QLabel(this);
  pmUnits->setPixmap(units_xpm);
  pmUnits->setGeometry(292, 30, 32, 32);

  MRULabel = new QLabel(i18n("Max. Receive Unit (MRU):"), this);
  size = MRULabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  MRULabel->setGeometry(196-wd, 90+(24-hg)/2, wd, hg);

  MRU = new QLineEdit(this);
  MRU->setGeometry(206, 90, 60, 24);
  sprintf(buffer, "%i", adv->mru);
  MRU->setText(buffer);

  Byte1Label = new QLabel("Bytes", this);
  size = Byte1Label->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Byte1Label->setGeometry(276, 90+(24-hg)/2, wd, hg);

  MTULabel = new QLabel(i18n("Max. Transfer Unit (MTU):"), this);
  size = MTULabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  MTULabel->setGeometry(196-wd, 124+(24-hg)/2, wd, hg);

  MTU = new QLineEdit(this);
  MTU->setGeometry(206, 124, 60, 24);
  sprintf(buffer, "%i", adv->mtu);
  MTU->setText(buffer);

  Byte2Label = new QLabel("Bytes", this);
  size = Byte2Label->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Byte2Label->setGeometry(276, 124+(24-hg)/2, wd, hg);
}

void UnitsWidget::resizeEvent(QResizeEvent *)
{
  ushort MARGIN = 10;
  uint w = width();
  uint h = height();

  GBox->resize(w-2*MARGIN, h-2*MARGIN);
  pmUnits->move(w-2*MARGIN-pmUnits->width(), pmUnits->y());
} 
