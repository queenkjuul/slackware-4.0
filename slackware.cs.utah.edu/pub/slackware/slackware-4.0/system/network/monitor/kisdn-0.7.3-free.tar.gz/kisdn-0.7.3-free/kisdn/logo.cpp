/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: logo.cpp,v 1.1.1.1 1998/11/21 10:18:58 twesthei Exp $
//
// $Log: logo.cpp,v $
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
//
// Revision 1.5  1998/10/26 15:54:10  twesthei
// Replace usage of class AntiAliasedImage with MXLogo since
// it's smarter and shorter
//
// Revision 1.4  1998/10/26 12:35:38  gis
//
// Introduced class AntiAliasedImage
//
// Revision 1.3  1998/10/23 21:43:31  twesthei
// Changed the logo (hopefully all now) and implemented the
// registration class
//


#include <qpixmap.h>

#include "general.h"
#include "logo.h"
#include "mxlogo.h"

#define LOGOXPOS  10
#define LOGOYPOS  364


LogoTabDialog::LogoTabDialog(QWidget *parent, const char *name, bool modal):QTabDialog(parent, name, modal)
{
  Logo = new MXLogo("millenniumx.gif", this);
  Logo->move(LOGOXPOS, LOGOYPOS);
  hasWidget = false;
}


LogoTabDialog::LogoTabDialog(const char **XPM, QWidget *parent, const char *name, bool modal):QTabDialog(parent, name, modal)
{
  KIconLoader *loader = kapp->getIconLoader();

  Logo = new QLabel(this);
  Logo->setPixmap(QPixmap(loader->loadIcon(**XPM)));
  Logo->move(LOGOXPOS, LOGOYPOS);

  hasWidget = false;
}


LogoTabDialog::LogoTabDialog(const char **XPM, uint x, uint y, QWidget *parent, const char *name, bool modal):QTabDialog(parent, name, modal)
{
  KIconLoader *loader = kapp->getIconLoader();

  Logo = new QLabel(this);
  Logo->setPixmap(QPixmap(loader->loadIcon(**XPM)));
  Logo->move(x, y);

  hasWidget = false;
}


LogoTabDialog::LogoTabDialog(uint x, uint y, QWidget *parent, const char *name, bool modal):QTabDialog(parent, name, modal)
{
  Logo = new MXLogo("millenniumx.gif", this);
  Logo->move(x, y);

  hasWidget = false;
}


void  LogoTabDialog::addWidget(QWidget *widget)
{
  w = widget;
  w->setGeometry(0, 0, width(), height()-Logo->height()-10);
  hasWidget = true;
}

#if QT_VERSION >= 140
void  LogoTabDialog::resizeEvent(QResizeEvent *ev)
{
  int  margin = 5;

  QTabDialog::resizeEvent(ev);

  Logo->move(2*margin, height()-margin-Logo->height());

  if (hasWidget) w->resize(width(), height()-Logo->height()-2*margin);
}
#endif
