/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include <stdio.h>

#include "adapter.h"


Adapter::Adapter(void)
{
  numadp = 0;
  
  addType(9,  "ASUS COM ISDNLink",             "asus_com",        "hisax", true,  false, true,  false, 12);
  addType(3,  "AVM A1 (Fritz!Classic)",        "avm_a1_classic",  "hisax", true,  false, true,  false, 5);
  addType(29, "AVM A1 PCI (Fritz!)",           "avm_a1_pci",      "hisax", false, false, false, false, 27);
  addType(28, "AVM A1 PCMCIA (Fritz!)",        "avm_a1_pcmcia",   "hisax", true,  false, true,  false, 26);
  addType(31, "AVM A1 PnP (Fritz!)",           "avm_a1_pnp",      "hisax", true,  false, true,  false, 27);
  addType(21, "AVM B1 (EXPERIMENTAL!)",        "avm_b1",          "capi",  true,  false, true,  false, 21);
  addType(16, "Compaq ISDN S0 ISA card",       "compaq_isa",      "hisax", true,  false, true,  true,  19);
  addType(2,  "Creatix/Teles PnP",             "teles_pnp",       "hisax", true,  false, true,  true,  4);
  addType(18, "Dr. Neuhaus Niccy PCI",         "neuh_pci",        "hisax", false, false, false, false, 24);
  addType(17, "Dr. Neuhaus Niccy PnP",         "neuh_pnp",        "hisax", true,  false, true,  false, 24);
  addType(6,  "Eicon.Diehl Diva ISA PnP",      "ed_diva_isapnp",  "hisax", true,  false, true,  false, 11);
  addType(14, "Eicon.Diehl Diva PCI",          "ed_diva_pci",     "hisax", false, false, false, false, 11);
  addType(24, "ELSA PCC/PCF (autodetect)",     "elsa_pcc_auto",   "hisax", false, false, false, false, 6);
  addType(25, "ELSA PCC/PCF (manual)",         "elsa_pcc_manual", "hisax", false, false, true,  false, 6);
  addType(26, "ELSA PCMCIA",                   "elsa_pcmcia",     "hisax", true,  false, true,  false, 10);
  addType(4,  "ELSA Quickstep 1000",           "elsa_qs1000",     "hisax", true,  false, true,  false, 7); 
  addType(15, "ELSA Quickstep 1000PCI",        "elsa_qs1000_pci", "hisax", false, false, false, false, 18);
  addType(32, "ELSA Quickstep 3000",           "elsa_qs3000",     "hisax", true,  false, true,  false, 7); 
  addType(33, "ELSA Quickstep 3000PCI",        "elsa_qs3000_pci", "hisax", false, false, false, false, 18);
  addType(10, "HFC-2BS0 based cards",          "hfc_2bs0",        "hisax", true,  false, true,  false, 13);
  addType(8,  "ITK ix1-micro Rev.2",           "itk_ix1m_r2",     "hisax", true,  false, true,  false, 9);
  addType(13, "MIC card",                      "mic_card",        "hisax", true,  false, true,  false, 17);
  addType(19, "NETjet PCI card",               "netjet_pci",      "hisax", false, false, false, false, 20);
  addType(11, "Sedlbauer Speed Card",          "sedl_sp_card",    "hisax", true,  false, true,  false, 15);
  addType(30, "Sedlbauer Speed Fax+",          "sedl_sp_fax",     "hisax", true,  false, true,  false, 28);
  addType(27, "Sedlbauer Speed Star (PCMCIA)", "sedl_pcmcia",     "hisax", true,  false, true,  false, 22);
  addType(1,  "Teles 8.0",                     "teles_8",         "hisax", true,  true,  false, false, 2);
  addType(0,  "Teles 16.0",                    "teles_16",        "hisax", true,  true,  true,  false, 1);
  addType(5,  "Teles 16.3 (non-PnP)",          "teles_16_3",      "hisax", true,  false, true,  false, 3);
  addType(7,  "Teles 16.3 PCMCIA",             "teles_16_pcmcia", "hisax", true,  false, true,  false, 8);
  addType(20, "Teles 16.3c PnP",               "teles_16_3c",     "hisax", true,  false, true,  false, 14);
  addType(22, "Teles PCI",                     "teles_pci",       "hisax", false, false, false, false, 21);
  addType(23, "Teles S0Box",                   "teles_s0box",     "hisax", true,  false, true,  false, 25);
  addType(12, "USR Sportster internal",        "usr_sp_int",      "hisax", true,  false, true,  false, 16);
}
  

void Adapter::addType(uint index, const char *modelname, const char *idstring, const char *hldriver,
                      bool needirq, bool needmem, bool needio1, bool needio2, ushort type)
{
  newindex[index]  = numadp;

  Index[numadp]    = index;
  Name[numadp]     = modelname;
  Id[numadp]       = idstring;
  HLDriver[numadp] = hldriver;
  NeedMem[numadp]  = needmem;
  NeedIO1[numadp]  = needio1;
  NeedIO2[numadp]  = needio2;
  NeedIRQ[numadp]  = needirq;
  Type[numadp++]   = type;   
}
