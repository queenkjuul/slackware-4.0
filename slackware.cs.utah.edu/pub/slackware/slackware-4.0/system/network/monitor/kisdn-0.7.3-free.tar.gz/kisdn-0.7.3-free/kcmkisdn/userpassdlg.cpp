/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#include "accdlg.h"
#include "antialiasedimg.h"
#include "userpassdlg.h"


UserPassDialog::UserPassDialog(const char *isp, QWidget *parent, const char *name) : QDialog(parent, name, true)
{
  AntiAliasedImage ai;
  QPixmap pm;
  QSize  size;
  int    wd, hg;

  setMinimumSize(320, 190);
  setMaximumSize(320, 190);
  setCaption(i18n("Enter user name and password"));

  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 300, 136);
  GBox->setTitle(isp);

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap keys_xpm = loader->loadIcon("keys.xpm");

  pmKey = new QLabel(this);
  pmKey->setPixmap(keys_xpm);
  pmKey->setGeometry(262, 28, 32, 32);

  Userlabel = new QLabel(i18n("User Name:"), this);
  size = Userlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Userlabel->setGeometry(120-wd, 70+(24-hg)/2, wd, hg);

  User = new QLineEdit(this);
  User->setGeometry(130, 70, 120, 24);
  User->setMaxLength(NAMESIZE);
  User->setText((ISDNData.Temp)->username.data());

  Passwordlabel = new QLabel(i18n("Password:"), this);
  size = Passwordlabel->sizeHint();
  wd   = size.width();
  hg   = size.height();
  Passwordlabel->setGeometry(120-wd, 102+(24-hg)/2, wd, hg);

  Password = new QLineEdit(this);
  Password->setGeometry(130, 102, 120, 24);
  Password->setMaxLength(NAMESIZE);
  Password->setText((ISDNData.Temp)->password.data());
  Password->setEchoMode(QLineEdit::Password);

  OK = new QPushButton(i18n("OK"), this);
  OK->setGeometry(230, 154, 80, 28);
  OK->setDefault(true);
  connect(OK, SIGNAL(clicked()), SLOT(accept()));

  logo = new QLabel(this);
  if ( ai.loadImage (kapp->kde_datadir()+"/kisdn/pics/millenniumx.gif") )
  {
    pm.convertFromImage(ai.getImage(), QPixmap::Color);
    logo->setPixmap(pm);
    logo->adjustSize();
  } 
  logo->move(10, 158);

  // The below commented out 'cause it appeared somewhere beneath the logo
  // Not time to fix it right now

/*
  QString str  = i18n("Don't forget to edit the account settings\n");
  str         += i18n("and assign the account to your user(s)!");

  QLabel *tmp = new QLabel( str, this );
  tmp->adjustSize();
  tmp->move( 10, 180 );
*/

  User->setFocus();
}
