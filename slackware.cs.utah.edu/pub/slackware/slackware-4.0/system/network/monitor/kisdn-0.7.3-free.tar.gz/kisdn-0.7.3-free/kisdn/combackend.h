/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
// $Id: combackend.h,v 1.2 1998/11/21 12:35:07 twesthei Exp $
//
// $Log: combackend.h,v $
// Revision 1.2  1998/11/21 12:35:07  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources

 
#ifndef __COMBACKEND_H
#define __COMBACKEND_H


#include <sys/types.h>


enum {BE_NOCMD, BE_ENGAGE, BE_ISPCHG, BE_DIAL, BE_HANGUP, BE_DODON, BE_DODOFF, 
      BE_ISPLISTCHG, BE_QUIT};


class ISDNCommand
{
  private:
  
    int   _cmdcode;
    bool  _ready;
  
    int   _isp;
    
  public:
  
    ISDNCommand(int cmd = BE_NOCMD) : _cmdcode(cmd), _ready(false) {}
  
    void  setReady()  	          { _ready    = true; }			
    void  setISP(int isp)         { _isp      = isp;  }
    
    int   cmdCode()         const { return _cmdcode;  }			
    int   isp()	            const { return _isp;      }
    bool  ready()           const { return _ready;    } 
};


#endif
