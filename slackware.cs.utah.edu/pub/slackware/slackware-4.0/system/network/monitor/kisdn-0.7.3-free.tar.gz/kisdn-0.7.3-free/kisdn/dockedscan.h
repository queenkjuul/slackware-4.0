/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/


#ifndef __DOCKEDSCAN_H
#define __DOCKEDSCAN_H

#define DOCKWIDTH   25
#define DOCKHEIGHT  25
#define DOCKOFFSET  7

#include <qcolor.h>
#include <qlabel.h>
#include <qpixmap.h>

#include "netinfo.h"
#include "pppstatus.h"


class DockedScan : public QLabel
{
  Q_OBJECT

  private:

    QColor    GraphColor[2];
    QPixmap   *lyoff, *lyon, *lgoff, *lgon, *lroff, *lron, *Temp1, *Temp2;
    uint      oldrx, oldtx, off;
    bool      opaque;

    void setColors();

  public:

    DockedScan(QWidget *parent = 0, const char *name = 0);
    ~DockedScan();

    void mousePressEvent(QMouseEvent *);

  public slots:

    void slotDialing(ushort);
    void slotBusy(ushort);
    void slotOnline(ushort);
    void slotOffline(ushort);
    void slotReceiveOn(ushort);
    void slotReceiveOff(ushort);
    void slotTransmitOn(ushort);
    void slotTransmitOff(ushort);
    void slotNewRates(PPPInfo *);
    void slotVoiceDown(ushort);
    void slotVoiceIn(ushort);
  
  signals:

    void rightClick();
    void leftClick();
};


#endif
