/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: customdlg.h,v 1.2 1998/11/21 12:35:09 twesthei Exp $
//
// $Log: customdlg.h,v $
// Revision 1.2  1998/11/21 12:35:09  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#ifndef __CUSTOMDLG_H
#define __CUSTOMDLG_H

#ifdef HAVE_CONFIG_H
  #include "../config.h"
#endif

#ifdef HAVE_GLOBAL_SHORTCUTS
  #include <kglobalaccel.h>
#endif

#include "aboutwidget.h"
#include "accwidget.h"
#include "customizedlg.h"
#include "genwidget.h"
#include "kisdndata.h"
#include "logo.h"



class CustomDialog : public LogoTabDialog
{
  private:

    CustomData     *customdata;
    ScannerData    *scannerdata;

    AccountWidget  *accWidget;
    GeneralWidget  *genWidget;
    AudioWidget    *audioWidget;
    CColorsWidget  *colorWidget;
    CScalesWidget  *scaleWidget;
    AboutWidget    *aboutwidget;

  public:

    CustomDialog(CustomData *, ScannerData *, QWidget *parent = 0, const char *name = 0);
    ~CustomDialog() {}

    bool  changedISPList() const { return accWidget->changedISPList(); }

#ifdef HAVE_GLOBAL_SHORTCUTS  
    void  passGlobalKeys(KGlobalAccel *accel) 
      { genWidget->globalKeys = accel; }
#endif
};


#endif
