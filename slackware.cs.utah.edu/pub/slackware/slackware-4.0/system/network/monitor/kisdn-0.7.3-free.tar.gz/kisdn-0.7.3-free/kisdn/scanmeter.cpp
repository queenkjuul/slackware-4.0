/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: scanmeter.cpp,v 1.2 1998/11/21 12:34:58 twesthei Exp $
//
// $Log: scanmeter.cpp,v $
// Revision 1.2  1998/11/21 12:34:58  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources


#include <stdio.h>
#include <sys/time.h>

#include <qtooltip.h>

#include <kapp.h>
#include <kiconloader.h>

#include "kisdndata.h"
#include "scanmeter.h"

#define GLOWWD  42
#define GLOWHG  25
#define GLOWX   0
#define GLOWY   SCANDY+8
#define GLOWDX  4
#define GLOWDY  4


ScanMeter::ScanMeter(bool ISDNsupported, ISDNInfo *info, MatrixFont *mf, QWidget *parent,
		     const char *name) : QWidget(parent, name),
		     			 isdninfo(info),
					 mtxfont(mf)
{  
  ScannerData  *scandata = ISDNData.scannerData();
  KIconLoader  *loader   = kapp->getIconLoader();

  static QPixmap rcvoff_xpm = loader->loadIcon("glowrcvoff.xpm");
  static QPixmap traoff_xpm = loader->loadIcon("glowtraoff.xpm");
  static QPixmap totoff_xpm = loader->loadIcon("glowtotoff.xpm");
  static QPixmap cha_xpm    = loader->loadIcon("cha.xpm");
  static QPixmap chb_xpm    = loader->loadIcon("chb.xpm");
  static QPixmap stmoff_xpm = loader->loadIcon("glowstmoff.xpm");

  configChanged = false;

  QColor  darkgreen  = QColor(0x00, 0x80, 0x00);
  QColor  lightgreen = QColor(0x40, 0xff, 0xc0);

  scanbutgrp = new QButtonGroup(this);
  scanbutgrp->setFixedSize(10+6*GLOWWD+5*GLOWDX, GLOWHG);
  scanbutgrp->setFrameStyle(QFrame::NoFrame);
  scanbutgrp->move(GLOWX, GLOWY);

  glowcha = new LEDPushButton(darkgreen, lightgreen, false, scanbutgrp);
  glowcha->setPixmap(cha_xpm);
  glowcha->shiftPixmap(-1, 1);
  glowcha->setGeometry(0, 0, GLOWWD, GLOWHG);
  QToolTip::add(glowcha, i18n("Channel A graph"));

  glowchb = new LEDPushButton(darkgreen, lightgreen, false, scanbutgrp);
  glowchb->setPixmap(chb_xpm);
  glowchb->shiftPixmap(-1, 0);
  glowchb->setGeometry(GLOWWD+GLOWDX, 0, GLOWWD, GLOWHG);
  QToolTip::add(glowchb, i18n("Channel B graph"));

  glowstm = new LEDPushButton(darkgreen, lightgreen, false, scanbutgrp);
  glowstm->setPixmap(stmoff_xpm);
  glowstm->shiftPixmap(-1, 0);
  glowstm->setGeometry(2*(GLOWWD+GLOWDX), 0, GLOWWD, GLOWHG);
  QToolTip::add(glowstm, i18n("Transfer rate labels"));

  glowrcv = new LEDPushButton(darkgreen, lightgreen, false, scanbutgrp);
  glowrcv->setPixmap(rcvoff_xpm);
  glowrcv->shiftPixmap(-1, 0);
  glowrcv->setGeometry(10+3*(GLOWWD+GLOWDX), 0, GLOWWD, GLOWHG);
  QToolTip::add(glowrcv, i18n("Receive (Rx) graph"));

  glowtra = new LEDPushButton(darkgreen, lightgreen, false, scanbutgrp);
  glowtra->setPixmap(traoff_xpm);
  glowtra->shiftPixmap(-1, 0);
  glowtra->setGeometry(10+4*(GLOWWD+GLOWDX), 0, GLOWWD, GLOWHG);
  QToolTip::add(glowtra, i18n("Transmit (Tx) graph"));

  glowtot = new LEDPushButton(darkgreen, lightgreen, false, scanbutgrp);
  glowtot->setPixmap(totoff_xpm);
  glowtot->shiftPixmap(-2, 1);
  glowtot->setGeometry(10+5*(GLOWWD+GLOWDX), 0, GLOWWD, GLOWHG);
  QToolTip::add(glowtot, i18n("Sum (Rx+Tx) graph"));

  connect(scanbutgrp, SIGNAL(clicked(int)), this, SLOT(slotKeyPressed(int)));

  isdninfo = info;

  glowcha->setActive(scandata->scanA());
  glowchb->setActive(scandata->scanB());
  glowstm->setActive(scandata->showStamps());
  glowrcv->setActive(scandata->scanReceive());
  glowtra->setActive(scandata->scanTransmit());
  glowtot->setActive(scandata->scanTotal());

  EtchedFrame = new QFrame(this);
  EtchedFrame->setLineWidth(2);
  EtchedFrame->setFrameStyle(QFrame::Panel | QFrame::Sunken);
  EtchedFrame->setGeometry(0, 0, SCANDX+2, SCANDY+4);	

  QWidget *tmp = new QWidget(EtchedFrame);
  tmp->setGeometry(2, 2, SCANDX-2, SCANDY);		

  Screen = new GraphWidget(ISDNsupported, glowstm->isActive(), true, info, tmp);
  Screen->setGeometry(0, 0, SCANDX+30, SCANDY);		
  Screen->setColors();

  updateFlags();

  throughput = new ThroughPut(mtxfont, this);
  throughput->move(292, GLOWY);
  QToolTip::add(throughput, i18n("Current transfer speed"));

  if (ISDNsupported)
  {
    clock1 = new QTimer(this);
    connect(clock1, SIGNAL(timeout()), this, SLOT(slotShowUptime()));
    clock1->start(1000, true);
  }
}


ScanMeter::~ScanMeter(void)
{

}


void ScanMeter::showThroughPut(float totrate)
{
  char buffer[8];

  sprintf(buffer, "%4.1f", totrate);
  throughput->setText(buffer);
}


void ScanMeter::slotShowUptime()
{
  emit sigRefreshUptimes();
  clock1->start(1000, true);
}


void ScanMeter::slotDrawScanLine(PPPInfo *pppinfo)
{
  float ActInRate[2], ActOutRate[2];

  for (ushort c = 0; c < 2; c++)
  {
    ActInRate[c]  = pppinfo->inRate[c];
    ActOutRate[c] = pppinfo->outRate[c];
  }

  showThroughPut(ActInRate[0]+ActOutRate[0]+ActInRate[1]+ActOutRate[1]);
  Screen->slotDrawScanLine(pppinfo);
}


void ScanMeter::slotEventDial(ushort)
{
  Screen->eventDial();
}


void ScanMeter::slotEventCall(ushort)
{
  Screen->eventCall();
}


void ScanMeter::slotEventLinkUp(ushort channel)
{
  Screen->eventLinkUp(channel);
}


void ScanMeter::slotEventLinkDown(ushort channel)
{
  ActInRate[channel]  = 0;
  ActOutRate[channel] = 0;
  Screen->eventLinkDown(channel);
}


void ScanMeter::slotKeyPressed(int key)
{
  ScannerData  *scandata = ISDNData.scannerData();

  configChanged = true;

  switch (key)
  {
    case 0 : glowcha->setActive(!glowcha->isActive());
             Screen->showChA = glowcha->isActive();
             scandata->setScanA(Screen->showChA);
             break; 
    case 1 : glowchb->setActive(!glowchb->isActive());
             Screen->showChB = glowchb->isActive();
             scandata->setScanB(Screen->showChB);
             break; 
    case 2 : glowstm->setActive(!glowstm->isActive());
             Screen->showRateStamps = glowstm->isActive();
             scandata->setShowStamps(Screen->showRateStamps);
             break; 
    case 3 : glowrcv->setActive(!glowrcv->isActive());
             Screen->showRec = glowrcv->isActive();
             scandata->setScanReceive(Screen->showRec);
             break; 
    case 4 : glowtra->setActive(!glowtra->isActive());
             Screen->showTra = glowtra->isActive();
             scandata->setScanTransmit(Screen->showTra);
             break; 
    case 5 : glowtot->setActive(!glowtot->isActive());
             Screen->showTot = glowtot->isActive();
             scandata->setScanTotal(Screen->showTot);
  }

  Screen->slotFullRedraw();
}


void ScanMeter::updateFlags()
{
  Screen->showChA        = glowcha->isActive();
  Screen->showChB        = glowchb->isActive();
  Screen->showRateStamps = glowstm->isActive();
  Screen->showRec        = glowrcv->isActive();
  Screen->showTra        = glowtra->isActive();
  Screen->showTot        = glowtot->isActive();

  Screen->slotFullRedraw();
}

void ScanMeter::settingsChanged()
{
  Screen->setColors();
  Screen->slotFullRedraw();
}


void ScanMeter::resizeEvent(QResizeEvent *)
{

}
