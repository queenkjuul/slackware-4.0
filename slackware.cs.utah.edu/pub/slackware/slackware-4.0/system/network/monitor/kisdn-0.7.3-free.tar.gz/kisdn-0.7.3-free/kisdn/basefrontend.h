/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: basefrontend.h,v 1.2 1998/11/21 12:35:06 twesthei Exp $
//
// $Log: basefrontend.h,v $
// Revision 1.2  1998/11/21 12:35:06  twesthei
// Free edition is compiling and running at first glance; DoD
// seems to be broken, but it is also in the Professional Edition...
// I suppose, this has something to do with Kernel 2.0.36 (i.e.
// HiSax 3.1), since there seems to be a new ioctl for locking/
// unlocking DoD...gotta explore this matter.
//


#ifndef __BASEFRONTEND_H
#define __BASEFRONTEND_H

#include "combackend.h"


/*
 * A base class for all KISDN-Frontends
 ***************************************/

class BaseFrontend
{
  protected:

    void  changeISP(int);			
    void  connectISP();
    void  disconnectISP();
    void  engageISP(int);
    void  DoDChanged(bool);   			  // DoD change
    void  ISPListChanged();			  // ISPList change
    void  sendSimpleCommand(int); 		  // Backend control shortcut

    virtual void  emitCommand(ISDNCommand *) = 0; // abstract!

    ISDNCommand  *isdnCommand;            	  // i4l backend control

  public:

    BaseFrontend()           {}
    virtual  ~BaseFrontend() {}

    virtual  void saveSession();               	  // default impl. does nothing
};


#endif
