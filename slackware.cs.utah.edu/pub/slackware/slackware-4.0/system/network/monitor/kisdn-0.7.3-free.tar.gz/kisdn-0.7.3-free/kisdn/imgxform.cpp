/*
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/

// $Id: imgxform.cpp,v 1.1.1.1 1998/11/21 10:18:58 twesthei Exp $
//
// $Log: imgxform.cpp,v $
// Revision 1.1.1.1  1998/11/21 10:18:58  twesthei
// Imported sources
//
// Revision 1.2  1998/10/28 00:12:58  twesthei
// Cosmetics...
//
// Revision 1.1  1998/10/23 19:05:42  twesthei
// Added a class to handle anti-aliased GIF images
//


#include <stdio.h>
#include <iostream.h>

#include "imgxform.h"


ImageTransformation::ImageTransformation(const QImage& image) : _width(image.width()),
								_height(image.height())									
{
  if (image.depth() != 8)
  {
    cout << "ImageTransformation: Converting to depth 8 (was depth " << image.depth() << ")" << endl;
    
    _image = image.convertDepth(8);
  }
  else _image = image.copy();
  
  _numcolors = _image.numColors();
}


QImage  ImageTransformation::getAntiAliasedImage(const QColor& bg)
{
  int      red, green, blue;
  QPixmap  pm;
  QRgb     color;
  QImage   imgcopy = _image.copy();
  int      bgred   = bg.red();
  int      bggreen = bg.green();
  int      bgblue  = bg.blue();
  
  for (int col = 0; col < _numcolors; col++)
  {
    color = _image.color(col);
     
    red   = qRed(color)   & bgred;
    green = qGreen(color) & bggreen;
    blue  = qBlue(color)  & bgblue;
    
    imgcopy.setColor(col, qRgb(red, green, blue));
  }  
    
  return imgcopy.convertDepth(32);
}
