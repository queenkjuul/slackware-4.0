/*  
 *  This file is part of kISDN, Copyright (C) 1998 by
 *
 *  Thorsten Westheider <twesthei@phya1.physik.uni-bielefeld.de>
 *  Carsten Pfeiffer <carpdjih@sp.zrz.tu-berlin.de>
 *
 ****************************************************************/
 
 
#include "accdlg.h"


DNSWidget::DNSWidget(QWidget *parent, const char *name) : QWidget(parent, name)
{
  AccData  *acc = ISDNData.Temp;

  GBox = new QGroupBox(this);
  GBox->setGeometry(10, 8, 328, 316);
  GBox->setTitle(i18n("DNS Setup"));

  KIconLoader *loader = kapp->getIconLoader();
  static QPixmap dns_xpm = loader->loadIcon( "dns.xpm" );

  pmDNS = new QLabel(this);
  pmDNS->setPixmap(dns_xpm);
  pmDNS->setGeometry(277, 32, 48, 39);
  
  Domainlabel = new QLabel(i18n("Domain:"), this);
  Domainlabel->setGeometry(70, 56, 60, 24);
  
  Domain = new QLineEdit(this);
  Domain->setGeometry(70, 80, 160, 24);
  Domain->setMaxLength(NAMESIZE);
  Domain->setText(acc->domain);
  
  DNSlabel = new QLabel(i18n("IP Address:"), this);
  DNSlabel->setGeometry(70, 120, 80, 24);
  
  DNS = new QLineEdit(this);
  DNS->setGeometry(70, 144, 138, 24);
  DNS->setMaxLength(IPNMSIZE);
  
  AddButton = new QPushButton(i18n("Add"), this);
  AddButton->setGeometry(224, 143, 95, 28);
  connect(AddButton, SIGNAL(clicked()), SLOT(slotAddDNS()));
  
  DNSListlabel = new QLabel(i18n("Address List:"), this);
  DNSListlabel->setGeometry(70, 178, 80, 24);
  
  DNSList = new QListBox(this);
  DNSList->setGeometry(70, 202, 138, 80);
  
  if (acc->FirstDNS != (DNSData *) 0L)
  {
    DNSData *actual = acc->FirstDNS;
    
    while (actual != (DNSData *) 0L)
    {
      DNSList->insertItem(actual->ipaddress.data());
      actual = actual->next;
    }
  }
  
  RemButton = new QPushButton(i18n("Remove"), this);
  RemButton->setGeometry(224, 202, 95, 28);
  connect(RemButton, SIGNAL(clicked()), SLOT(slotRemoveDNS()));
}


void DNSWidget::messageBadIP(void)
{
   QMessageBox::warning(this, "Invalid IP number",
    			      "An IP address consists of 4\n"    				   
		              "numbers in the range 0..255\n"
			      "separated by dots\n\n", "OK", 0);

}


void DNSWidget::slotAddDNS(void)
{   
  IP       *ip = new IP(DNS->text());
  AccData  *acc = ISDNData.Temp;
  
  if (!ip->isValidIP())
  {
    messageBadIP();
    return;
  }    
  
  delete ip;  
  acc->CurrDNS = new DNSData();
  
  if (acc->FirstDNS != (DNSData *) 0L)
  {
    (acc->CurrDNS)->prev = acc->LastDNS;
    (acc->LastDNS)->next = acc->CurrDNS;
  }
  else acc->FirstDNS = acc->CurrDNS;
  
  acc->LastDNS = acc->CurrDNS;
  (acc->CurrDNS)->ipaddress = DNS->text();
  DNSList->insertItem((acc->CurrDNS)->ipaddress.data());
  DNS->setText("");
  DNS->setFocus();
}
  
  
void DNSWidget::slotRemoveDNS(void)
{
  int      help, index = DNSList->currentItem();
  AccData  *acc = ISDNData.Temp;
  
  if (index > -1)
  {
    DNSData *actual = acc->FirstDNS;
    help = index;
    
    while (index > 0)
    {
      actual = actual->next;
      index--;
    }
    
    if (actual->next != (DNSData *) 0L) (actual->next)->prev = actual->prev;
    else                                acc->LastDNS = actual->prev;
    
    if (help == 0) acc->FirstDNS = actual->next;
    else           (actual->prev)->next = actual->next;
    
    delete actual;
    DNSList->removeItem(help);
  }
}


void DNSWidget::resizeEvent(QResizeEvent *)
{
  ushort margin = 10;
  uint w = width();
  uint h = height();

  GBox->resize(w-2*margin, h-2*margin);
  pmDNS->move(w-2*margin-pmDNS->width()-4, pmDNS->y());
}
