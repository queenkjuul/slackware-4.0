// This module defines a class used to help executing the program via the
// ParseProgram class. It is used both by wipld and by wiplcExec.
 
class ScriptExec:ParseProgram {
  // The shared memory area:
  ServerMem* ca;
  
  // The time of the packet we are updateing:
  Time packettime;
  
  // Cache of recently used MAC addresses and their location in ca.
  int last_used;
  int cache0_idx;
  mac_addr cache0_addr;
  int cache1_idx;
  mac_addr cache1_addr;
  
  // Gets the the index og af a MAC address and appends it to to ca if it does 
  // not exist. Returns -1 on error:
  int GetMacIdx(mac_addr&, char*& error);

  // Functions from ParseProgram:
  virtual int MACcardcnt() { return ca->curcardc; }
  virtual int MACcntcnt()  { return ca->Counterc; }
  virtual int MACgetidx(mac_addr m, char*& error) { int i=getMacIdx(m,error); return i==-1 ? 0 : i; }
  virtual mac_addr MACgetadr(int idx, char*& error);
  virtual void MACidxdel(int idx, char*& error);
  virtual int MACidxacc(int idx, char*& error);
  virtual void print(const char* string) { printf("%s",string); }  
  virtual int64* MACgetcnt(mac_addr, int counter, char*& error);
  
  protected:  
  // Get the index of a mac address and appends it if it does not exist.
  int getMacIdx(mac_addr& m, char*&error) {
    if(cache0_idx!=-1 && cache0_addr==m) { last_used=0; return cache0_idx; }
    else if(cache1_idx!=-1 &&  cache1_addr==m) { last_used=1; return cache1_idx; }
    int i=GetMacIdx(m,error);    
    if(last_used) { last_used=0; cache0_idx=i; cache0_addr=m; }
    else          { last_used=1; cache1_idx=i; cache1_addr=m; }
    if(i!=-1) ca->cards[i].updated=packettime;
    return i;
  }
      
  public:
  // Compiles the program and returns an error (is from base class)
  ParseProgram::setProgram;

  // This is called by setProgram. Can be used by the user to insert own
  // variabels:
  ParseProgram::getSymbol;
      
  // Consumes a packet returns 0 on succes and error message on fatal error.
  // The parameter should be the shared memory area:
  char* Consume(ServerMem* Ca, Time PacketTime);  
};
