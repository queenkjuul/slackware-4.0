// This module is by the wipld program to write the logfile.

class LogFile {
  static void hupFunc(void*);
  static void termFunc(void*);

  int logipchange,logbadpackets;
  int h;
  char* filename;
  
  public:
  LogFile();
  ~LogFile();
  
  enum logTypes { ipchange, badpacket, status, print };
  
  // Returns 0 or an error message:
  char* init(Config* cnf);
  
  // Log a message of the given type:
  void log(logTypes, const char* format,...);
  
  // This function closes all files except for the log file:
  void closeAllOtherFiles();
};
