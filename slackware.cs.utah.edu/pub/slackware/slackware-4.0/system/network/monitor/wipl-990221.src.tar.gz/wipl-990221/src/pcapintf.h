// This defines an interface to the pcap library. The library is used by
// daemon process to read packets from network device.

extern "C" {
  #include <pcap/pcap.h>
}

typedef int ip_port;

class PcapInterface {
  char interface[20];
  char errmsg[PCAP_ERRBUF_SIZE];
  int tcp_proto;
  int udp_proto;
  pcap_t *ph;
  bpf_program filter;
  int datalink;
  LogFile* lf;
  
  public:
  PcapInterface()  { ph=0;  tcp_proto=udp_proto=0; interface[0]='\x0'; }
  ~PcapInterface() { if(ph) pcap_close(ph); }

  struct Packet {
    mac_addr   maca_src;   // In network format
    mac_addr   maca_dst;   // In network format
    ip_addr    ip_src;     // In network format
    ip_addr    ip_dst;     // In network format
    ip_port    ipport_src; // In host format, 0 on no port
    ip_port    ipport_dst; // In host format, 0 on no port  
    int        ip_len;     // Length of IP part of packet
    Time       time;       // The timestamp of the packet
  };  
  
  // Print an ascii representation of the packet to buf:
  void printPacket(char* buf, int buflen, const Packet& p);

  // This inits this object.
  //   filter:  A filter expression. If 0 no filter is used.
  //   netdev:  The device to use. If 0 a default device is used.
  //   lf    :  A logfile to log error messages to
  // Returns an error message or 0
  char* init(char* filter, char* netdev, LogFile* lf);
  
  // After init is called these can be called:
  
  // Returns the name of the used device:
  char* getDev() { return interface; }
  
  // Sets the parameter to the next packet or returns an errormessage:
  char* nextPacket(Packet&);    
};