#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#include "common.h"
#include "shmem.h"
#include "config.h"
#include "parseprg.h"
#include "prgcommon.h"

//-----------------------------------------------------------------------------

int main(int argc, char* argv[]) {
  // Read parameters:
  char* ipcid=DEFAULT_DAEMONFILE;
  char* program;
  mac_addr adr;
  int base=argc>=1 ? 1 : 0; 
    
  // Read daemon file if any:
  if(argv[base] && (argv[base][0]=='-') && (argv[base][1]=='d')) {
    ipcid=argv[1]+2;
    base++;
  }
  
  // Read the program:
  DynString ds;
    
  if(argv[base] && (argv[base][0]=='-') && argv[base][1]=='e') {
    // An -e parameter is given:
    base++;
    program=argv[base];
    base++;
  } else {
    FILE* f;
    if(argv[base]) {
      // A filename is given:
      f=fopen(argv[base],"r");
      if(!f) {
        fprintf(stderr,"Could not open file: %s\n",argv[base]);
        return 1;
      }
      base++;
    } else {
      // A filename is not given - use stdin:
      f=stdin;
    }
    int c;
    while((c=getc(f))!=EOF) ds.add(c);
    program=ds.getString();
  }
  
  if(argv[base]) {
    fprintf(stderr,"Too many or unknown arguments\n");
    return 2;
  }	
      
  // The parameters are now read.
  
  // Try to compile the program:
  ScriptExec se;
  char* c=se.setProgram(1,program);
  if(c) {
    fprintf(stderr,"%s\n",c);
    return 1;
  }
  
  // The program is compiled - try to fetch and lock the shared memory
  // with write access:
  ShMemClient clnt;
  c=clnt.init(ipcid,0);
  if(c) {
    fprintf(stderr,"%s\n",c);
    return 1;
  }
  
  ServerMem* ca=(ServerMem*)clnt.Lock();
  if(ca==0) {
    fprintf(stderr,"%s\n",LockErrString);
    return 1;
  }

  // And execute the program:
  Time t;
  gettimeofday(&t.tv,0);
  c=se.Consume(ca,t);

  // Unlock the memory:
  clnt.UnLock(ca);  

  if(c) {    
    fprintf(stderr,"%s\n",c);
    return 1;
  }
}