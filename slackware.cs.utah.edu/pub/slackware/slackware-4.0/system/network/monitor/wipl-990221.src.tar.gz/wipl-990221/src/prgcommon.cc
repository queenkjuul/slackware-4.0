#include <stdio.h>
#include <stdlib.h>

#include "common.h"
#include "parseprg.h"
#include "prgcommon.h"

char* ScriptExec::Consume(ServerMem* Ca, Time PacketTime) {
  cache0_idx=cache1_idx=-1;
  ca=Ca; 
  packettime=PacketTime;
  return execProgram();
}

int ScriptExec::GetMacIdx(mac_addr& ma, char*& error) {
  // Try find the card in our table:
  CardInfo c; c.macaddr=ma; 
  CardInfo* a=(CardInfo*)bsearch(&c,&ca->cards,ca->curcardc,sizeof(CardInfo),CardInfo::compare_mac);

  if(a==0) {
    // The card could not be found - insert it:
    if(ca->curcardc>=ca->maxcardc) {
      if(!error) {
        snprintf(errmsg,sizeof(errmsg),"More than %i cards in table\n",ca->maxcardc);
        error=errmsg;
      }
      return -1;
    }
    
    // Find index to insert card at:
    int i;
    for(i=0; i<ca->curcardc; i++)
      if(mac_addr::compare(ca->cards[i].macaddr,ma)>=0) break;
    a=&ca->cards[i];
    
    // Insert the card at index i - move the other cards:
    int b;
    for(b=ca->curcardc; b>i; b--) ca->cards[b]=ca->cards[b-1];
    ca->curcardc++;
    
    // And insert the new card (make non-used counters zero, too)
    a->macaddr=ma;
    a->ipaddr.setZero();
    a->setZero();
    
    // Invalidate the cache:
    if(cache0_idx>=i) cache0_idx=-1;
    if(cache1_idx>=i) cache1_idx=-1;
  }
  
  return a-ca->cards;
}

int64* ScriptExec::MACgetcnt(mac_addr m, int counter, char*& error) {  
  int i=getMacIdx(m,error);
  if(i==-1 || counter>=maxcounterc || counter<0) {
    if(!error) error="Tried to access invalid counter";
    static int64 default_location=0;
    return &default_location;
  }
  return &ca->cards[i].Counters[counter];
}

void ScriptExec::MACidxdel(int idx, char*& error) {
  if(idx>=ca->curcardc || idx<0) {
    if(!error) error="Tried to delete non-existsing card";
    return;
  }

  // Copy the cards above this one position down:
  for(int i=idx+1; i<ca->curcardc; i++) {
    ca->cards[i-1]=ca->cards[i];
  }
  // Decrement the card count
  ca->curcardc--;

  // And invalidate the cache:
  if(cache0_idx>=idx) cache0_idx=-1;
  if(cache1_idx>=idx) cache1_idx=-1;  
}

int ScriptExec::MACidxacc(int idx, char*& error) {
  if(idx>=ca->curcardc || idx<0) {
    if(!error) error="Information read from non-existsing card";
    return 0;
  }
  return (int)(packettime-ca->cards[idx].updated);
}

mac_addr ScriptExec::MACgetadr(int idx, char*& error) {
  if(idx>=ca->curcardc || idx<0) {
    if(!error) error="MAC addres for non existing card tries read";
    mac_addr a; a.setZero(); return a;
  }
  return ca->cards[idx].macaddr;
}
