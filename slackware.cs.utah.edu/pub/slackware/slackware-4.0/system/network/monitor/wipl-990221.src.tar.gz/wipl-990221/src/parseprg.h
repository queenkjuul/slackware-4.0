// This module implements the parser for the programs given in the [program]
// section of the configurtion file. Currently only one instance of this class
// may exist.

class ParseProgram {
  public:
  static ParseProgram* instance; // Current instance of class or 0
                                 // The user should not modify this variabel

  // The possible types for symbols:
  enum types { tINT32,tINT64,tBOOL,tMAC,tIP,tUNKNOWN };
  
  ParseProgram();
  ~ParseProgram();
  
  // To set the program to execute call this funtion.
  // linebase should be set to linenumber of the first line in the program
  // prg should contain the program itself.
  // The function returns an error message or 0.
  // The getSymbol function is called for all encounterd symbols.
  char* setProgram(int linebase, char* prg);  

  // This is called by setProgram. Can be used by the user to insert own
  // variabels. If the user wants to insert a variabel location should be set
  // to it's location and the function should return the type of the variabel.
  // The function should return tUNKNOWN on an unknown variabel.
  // If INT32 is returned the variabel will be treated as an expression 
  // (rvalue) and not a variabel (lvalue). That is because integer variabels 
  // has 64 bits.
  virtual types getSymbol(char* name, void*& location) { return tUNKNOWN; }
  
  // If setProgram returned successfully this can be called as many times
  // as wanted to execute the program. Returns an error message on
  // runtime error:
  char* execProgram();
  
  // The following are called by execProgram when the corrosponding functions
  // are called by the userprogram.
  //
  // They can set the error parameter to an error message but should return
  // meaningfull values in all cases.
  
  virtual int MACcardcnt()=0;
  virtual int MACcntcnt()=0;
  virtual int MACgetidx(mac_addr, char*& error)=0;
  virtual mac_addr MACgetadr(int idx, char*& error)=0;
  virtual void MACidxdel(int idx, char*& error)=0;
  virtual int MACidxacc(int idx, char*& error)=0;
   
  // Executed on an expression of the form mac_addr[idx]
  virtual int64* MACgetcnt(mac_addr, int counter, char*& error)=0;
  
  // Should print the given string
  virtual void print(const char* string)=0;
};
