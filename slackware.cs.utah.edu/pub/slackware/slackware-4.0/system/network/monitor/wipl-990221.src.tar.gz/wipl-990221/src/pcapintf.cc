#include "common.h"
#include "config.h"
#include "logfile.h"
#include "pcapintf.h"

#include <netdb.h>
#include <string.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <unistd.h>

char* PcapInterface::init(char* strfilter, char* netdev, LogFile* l) {
  lf=l;
  
  // Find protocol numbers for udp and tcp:
  protoent* tcp_proto_ent=getprotobyname("tcp");
  if(!tcp_proto_ent) { 
    snprintf(errmsg,sizeof(errmsg),"Protocol tcp not found\n"); return errmsg; 
  }
  tcp_proto=tcp_proto_ent->p_proto;

  protoent* udp_proto_ent=getprotobyname("udp");
  if(!udp_proto_ent) { 
    snprintf(errmsg,sizeof(errmsg),"Protocol udp not found\n"); return errmsg; 
  }    
  udp_proto=udp_proto_ent->p_proto;  

  // Find network device to use:
  if(!netdev) {
    netdev=pcap_lookupdev(errmsg);
    if(!netdev)  return errmsg;
  }
  snprintf(interface,sizeof(interface),"%s",netdev);
  
  // Open the device:
  ph=pcap_open_live(netdev,40+sizeof(ether_header),1,-1,errmsg); // 40: Max size of header.
  if(!ph) { interface[0]='\x0'; return errmsg; }
  
  // Read the datalink type and check if it is supported:
  datalink=pcap_datalink(ph);
  if(datalink!=DLT_EN10MB) { // Currently only 10MB ethernet supported
    pcap_close(ph);
    snprintf(errmsg,sizeof(errmsg),"Pcap datalink layer #%i not support. Please add support for it.",datalink);
    return errmsg;
  }                   
  
  // Set filter if specified:
  if(strfilter) {
    // Compile the filter:
    int i=pcap_compile(ph,&filter,strfilter,1,0xffffffff);
    if(i==-1) { pcap_close(ph); ph=0; return "Syntax error in filter"; }
  
    // An attach it to the device:
    i=pcap_setfilter(ph,&filter);
    if(i==-1) { pcap_close(ph); ph=0; return "Syntax error in filter"; }
  }
  
  return 0; // On succes
}

char* PcapInterface::nextPacket(Packet& p) {
  for(;;) {
    // Read the next packet:
    struct pcap_pkthdr header;
    const unsigned char* data=pcap_next(ph,&header);
    if(!data) continue;
    
    // Set the packet time:
    p.time.tv=header.ts;
    
    // And interpret it
    if(datalink==DLT_EN10MB) {
      ether_header* eth=(ether_header*)data;
  
      // Ignore packet if not IP packet
      if(ntohs(eth->ether_type)!=ETHERTYPE_IP) continue;
      
      // Set MAC source and destination address:
      p.maca_dst=eth->ether_dhost;
      p.maca_src=eth->ether_shost;
      
      // Complain and ignore if packet has invalid checksum:
      iphdr* ip=(iphdr*)(eth+1);
      unsigned short c=0;
      unsigned short* ipu=(unsigned short*)ip;
      int orgchecksum=ip->check; ip->check=0;
      for(int a=0; a<ip->ihl*2; a++, ipu++) {
        unsigned short oldc=c;	
        c+=(*ipu); if(c<oldc) c++;	  
      }
      c=~c;
      if(c!=orgchecksum) {
        lf->log(LogFile::badpacket,"Packet from %s has wrong IP checksum and is ignored",p.maca_src.tostr());
	continue;
      }
	
      // Find the IP addresses and IP length:
      p.ip_src=ip->saddr;
      p.ip_dst=ip->daddr;
      p.ip_len=ntohs(ip->tot_len);

      // Set ipport_src og ipport_dst
      if(ip->protocol==tcp_proto) { // Note: protocol field is only 8 bit
        tcphdr* tcp=(tcphdr*)(((char*)ip)+ip->ihl*4);
        p.ipport_src=ntohs(tcp->source);
        p.ipport_dst=ntohs(tcp->dest);
      } else if(ip->protocol==udp_proto) {
        udphdr* udp=(udphdr*)(((char*)ip)+ip->ihl*4);
        p.ipport_src=ntohs(udp->source);
        p.ipport_dst=ntohs(udp->dest);
      } else {
        p.ipport_src=0;
        p.ipport_dst=0;
      }
    }    
    return 0;
  }    
}

void PcapInterface::printPacket(char* buf, int buflen, const Packet& p) {
  char macbuf[42];

  snprintf(buf,buflen,"%s(%s.%i) -> ",
    p.maca_src.tostr(),p.ip_src.tostr(),p.ipport_src);

  int plen=strlen(buf);
  buflen-=plen;
  
  snprintf(buf+plen,buflen,"%s(%s.%i)",
    p.maca_dst.tostr(),p.ip_dst.tostr(),p.ipport_dst);
}

