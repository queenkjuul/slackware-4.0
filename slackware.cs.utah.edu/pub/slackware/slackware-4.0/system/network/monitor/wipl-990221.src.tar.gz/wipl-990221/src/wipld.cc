// This is the wipld daemon process.
//
// Possible improvements: 
//
// 1) Make the process fork later making it possible to write error messages 
//    to the console instead of only to

#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/param.h>
#include <errno.h>
#include <sys/stat.h>
#include <stdio.h>

#include <sys/ioctl.h>
#include <fcntl.h>

#include "common.h"
#include "parseprg.h"
#include "shmem.h"
#include "config.h"
#include "logfile.h"
#include "pcapintf.h"
#include "sigctl.h"
#include "prgcommon.h"


// This class creates the shared memory area. When given packets to
// the consume function it then updates the area accordingly.
class CardCollect:ScriptExec {
  ShMemServer serv;
  LogFile* lf;      // File we log to
  int memsize;     // Used by getShMemSize()
  
  // Called on compilation:
  virtual types getSymbol(char* name, void*& location);
  
  // Called on running:
  char printbuffer[128]; // Buffer for printing
  virtual void print(const char* string);  

  int ct;  // If true program contains a variabel reference that requires
           // localtime to be called for each packet.
  tm time;

  // Update IP information of the given card:
  void updateIp(ServerMem* sa, mac_addr m, ip_addr& ip);

  public:
  
  // This inits the daemon.
  // Returns 0 or an error message
  char* init(Config*, LogFile*);    
  
  // After successfull call to init this can be called:
  int getShMemSize() { return memsize; }
  
  PcapInterface::Packet pack;

  // Consumes the packet pack. Returns 0 on success or an error message on
  // a fatal error.
  char* Consume();
};

ParseProgram::types CardCollect::getSymbol(char* name, void*& location) {
  if(!strcmp(name,"srcmac"))  { location=&pack.maca_src; return tMAC; }
  if(!strcmp(name,"dstmac"))  { location=&pack.maca_dst; return tMAC; }
  if(!strcmp(name,"srcip"))   { location=&pack.ip_src; return tIP; }
  if(!strcmp(name,"dstip"))   { location=&pack.ip_dst; return tIP; }
  if(!strcmp(name,"srcport")) { location=&pack.ipport_src; return tINT32; }
  if(!strcmp(name,"dstport")) { location=&pack.ipport_dst; return tINT32; }
  if(!strcmp(name,"size"))    { location=&pack.ip_len; return tINT32; }
 
  if(!strcmp(name,"hour"))    { location=&time.tm_hour; ct=1; return tINT32; }
  if(!strcmp(name,"min"))     { location=&time.tm_min;  ct=1; return tINT32; }
  if(!strcmp(name,"wday"))    { location=&time.tm_wday; ct=1; return tINT32; }
  if(!strcmp(name,"mday"))    { location=&time.tm_mday; ct=1; return tINT32; }
  
  // Else do default operation:
  return ScriptExec::getSymbol(name,location);
}  

char* CardCollect::init(Config* cnf, LogFile* l) {
  lf=l;
  int counterc=cnf->counterc();
  int maxcardc=cnf->maxcardc();
    
  // Check parameters:
  if(maxcardc<=0) return "At least one card should be allowed";
  if(counterc<=0 || counterc>=maxcounterc) {
    snprintf(errmsg,sizeof(errmsg),"Between 1 and %i counters must be defined",maxcounterc); return errmsg;
  }    
  
  // Compile program and return error message on error:
  ct=0;
  char* c=setProgram(cnf->prgline(),cnf->program());
  if(c) return c;
		      
  // Create the shared memory:
  void* memory;
  memsize=sizeof(ServerMem)+maxcardc*sizeof(CardInfo);
  c=serv.init(cnf->daemonfile(),memsize,memory);
  if(c) return c;
  
  // An initialize it:
  ServerMem* ca=(ServerMem*)memory;      
  ca->Counterc=counterc;
  for(int a=0; a<counterc; a++) {
    strncpy(ca->CounterNames[a],cnf->countername(a),MaxCounterNameLen);
    ca->CounterNames[a][MaxCounterNameLen]='\x0';
  }
  for(int a=counterc; a<maxcounterc; a++) {
    strcpy(ca->CounterNames[a],"(unused)");
  }
  
  ca->maxcardc=maxcardc;
  ca->curcardc=0;
  
  gettimeofday(&ca->start.tv,0); 
  serv.UnLock(ca);
  
  return 0;
}

char* CardCollect::Consume() {
  // Lock the shared memory:
  ServerMem* ca=(ServerMem*)serv.Lock();
  if(ca==0) return LockErrString;
  
  // Calculate the time value if used by the program:
  if(ct) time=*localtime(&pack.time.tv.tv_sec);
  
  // Execute the program:
  printbuffer[0]='\x0';
  char* error=ScriptExec::Consume(ca,pack.time);
  if(printbuffer[0]) { print("\n"); }
  
  // Look for ip address change. Note we do this after we executre the
  // program. So if the user for some reason changes the mac or ip
  // address of the packet the modfied information is updated
  updateIp(ca,pack.maca_src,pack.ip_src);
  updateIp(ca,pack.maca_dst,pack.ip_dst);

  // And unlock the memory:
  serv.UnLock(ca);
  
  if(error) return error;  
  return 0;
}  

void CardCollect::print(const char* string) {
  for(;;) {
    char* n=strchr(string,'\n');
    if(!n) {
      int bl=strlen(printbuffer);
      int bufrest=sizeof(printbuffer)-1-bl;
      int strrest=strlen(string);
      int tocopy=strrest<bufrest ? strrest : bufrest;
      strncpy(printbuffer+bl,string,tocopy); 
      printbuffer[bl+tocopy]='\x0';
      return;
    }              
    int l=n-string;
    lf->log(LogFile::print,"User program printed: %s%.*s",printbuffer, l, string);
    printbuffer[0]='\x0';
    string=n+1;
  }
}

void CardCollect::updateIp(ServerMem* sa, mac_addr m, ip_addr& ip) {
  char* foo=0;
  int idx=getMacIdx(m,foo);
  if(idx==-1) return;
  CardInfo* a=&sa->cards[idx];
  if(a->ipaddr!=ip) {
    // If address changed:
    char buf[40];
    snprintf(buf,40,"%s",ip.tostr());
    lf->log(LogFile::ipchange,
      "IP address for card %s changed from %s to %s",
      m.tostr(),a->ipaddr.tostr(),buf);
    a->ipaddr=ip;
  }
}
  
//-----------------------------------------------------------------------------

// Class used to create file with the process id of the daemon.
class PidFile {
  char* file;

  static void programAbort(void *p) {
    // Delete file:
    unlink(((PidFile*)p)->file);
  };
  
  public:
  PidFile()  : file(0) { registerSignalHandler(this,programAbort,signalTerm); }
  ~PidFile() { unregisterSignalHandler(this,programAbort); programAbort(this); delete[] file; }
  
  char* init(char* filename) {
    blockSignals();
    file=new char[strlen(filename)+1];
    strcpy(file,filename);
    unblockSignals();
    int h=open(filename,O_CREAT|O_WRONLY|O_APPEND,
       S_IRUSR|S_IWUSR|
       S_IRGRP|S_IWGRP|
       S_IROTH);
    if(h==-1) {    
      snprintf(errmsg,sizeof(errmsg),"Could not create pid file %s: %s",filename,strerror(errno));
      return errmsg;
    }
    char buf[40];
    snprintf(buf,sizeof(buf),"%i\n",(int)getpid());
    write(h,buf,strlen(buf));
    close(h);
    return 0;
  }
};

main(int argc, char*argv[]) {  
  // Find name of configuration file:
  char* conffile;
  if(argc==1)
    conffile=DEFAULT_CNFFILE;
  else if(argc==2)
    conffile=argv[1];
  else {
    fprintf(stderr,"Syntax: %s [conffile]\n",argv[0]);
    return 1;
  }
  
  // Read configuration file:
  Config* cnf=new Config();
  char* c=cnf->readConfFile(conffile);
  if(c) {
    fprintf(stderr,"%s\n",c);
    return 2;
  }
  
  // Open log file:
  LogFile lf;
  c=lf.init(cnf);
  if(c) {
    fprintf(stderr,"%s\n",c);
    return 2;
  }
  
  // We have now opened the logfile. Because of this we are able to write
  // errormssages to the log file instead of to the terminal. We can there-
  // fork and let the parent process exit. On the other hand we can't fork
  // later because of problems with destructor calls and other things.
  int i=fork();
  if(i==-1) { // On error:
    fprintf(stderr,"Could not fork: %s\n",strerror(errno));
    return 3;
  }
  if(i!=0) { // On sucess and parent process
    return 0;
  }
  
  // We are now the child process.
  
  // Change to root directory to allow unmount of cwd:
  chdir("/");
  
  // Disassociate from process group so we don't receive signals for the group:
  setpgrp();
  
  // Disassociate from controling terminal:
  int h;
  if(h=open("/dev/tty",O_RDWR)>=0) {
    ioctl(h,TIOCNOTTY,(char*)0);
    close(h);
  }
  
  // Close all filehandels except for the logfile:
  lf.closeAllOtherFiles();
  
  // Initialize daemon and compile program:
  CardCollect cc;
  c=cc.init(cnf,&lf);

  // Create pid file.
  PidFile pf;
  c || (c=pf.init(cnf->pidfile()));
  
  // Start reading from device:
  PcapInterface pi;  
  c || (c=pi.init(cnf->filter(),cnf->netdev(),&lf));
  
  lf.log(LogFile::status,"---");

  if(c) {
    lf.log(LogFile::status,"Daemon could not start: %s",c);
    return 1;
  }
  
  // Print status information:
  lf.log(LogFile::status,"Daemon initialized with pid %i and shared memory size %i",getpid(),cc.getShMemSize());
  lf.log(LogFile::status,"Device: %s, Logfile: %s, Pidfile: %s, Daemonfile: %s",pi.getDev(),cnf->logfile(),cnf->pidfile(),cnf->daemonfile());
  
  delete cnf; // Save a bit memory...
    
  for(;;) { 
    c=pi.nextPacket(cc.pack);
    c || (c=cc.Consume());
    if(c) {
      lf.log(LogFile::status,"Daemon terminated: %s",c);
      return 1;
    }
  }
}  
