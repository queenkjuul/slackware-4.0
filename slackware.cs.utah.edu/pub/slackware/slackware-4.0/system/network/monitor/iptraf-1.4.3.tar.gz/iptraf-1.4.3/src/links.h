#define LINK_ETHERNET		1
#define LINK_PPP		2
#define LINK_SLIP		3
#define LINK_PLIP		4
#define LINK_LOOPBACK		5
#define LINK_ISDN_RAWIP		6
#define LINK_ISDN_CISCOHDLC	7
#define LINK_FDDI		8
#define LINK_INVALID		0

