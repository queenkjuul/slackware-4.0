/***

stdwinset.h - prototype declaration for setting the standard window settings
for IPTraf

***/

#include <curses.h>

void stdwinset(WINDOW * win);
