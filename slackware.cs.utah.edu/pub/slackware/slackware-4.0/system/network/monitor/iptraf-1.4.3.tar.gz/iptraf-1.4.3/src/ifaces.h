/***

ifaces.h - prototype declaration for interface support determination
		routine.
		
***/

int iface_supported(char *iface);
void err_iface_unsupported(void);
void isdn_iface_check(int *fd, char *ifname);
