
/***

log.c - the iptraf logging facility
Written by Gerard Paul Java
Copyright (c) Gerard Paul Java 1997, 1998

This software is open source; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License in the included COPYING file for
details.

***/

#include <curses.h>
#include <panel.h>
#include <time.h>
#include <string.h>
#include <netinet/in.h>
#include <linux/if_ether.h>
#include <net/if_arp.h>
#include "dirs.h"
#include "error.h"
#include "tcptable.h"
#include "othptab.h"
#include "ifstats.h"
#include "serv.h"
#include "hostmon.h"
#include "links.h"
#include "mode.h"
#include "options.h"

volatile int rotate_flag;
char target_logname[80];

void openlogerr()
{
    int resp;
    errbox("Unable to open log file", ANYKEY_MSG, &resp);
}

void opentlog(FILE ** fd, char *logfilename)
{
    *fd = fopen(logfilename, "a");

    if (*fd == NULL)
	openlogerr();

    rotate_flag = 0;
    strcpy(target_logname, "");
}

void genatime(time_t now, char *atime)
{
    strncpy(atime, ctime(&now), 26);
    atime[strlen(atime) - 1] = '\0';
}

void writelog(int logging, FILE * fd, char *msg)
{
    char atime[28];

    if (logging) {
	genatime(time((time_t *) NULL), atime);
	fprintf(fd, "%s; %s\n", atime, msg);
    }
}

void writetcplog(int logging, FILE * fd, struct tcptableent *entry,
		 unsigned int pktlen, char *message)
{
    char msgbuf[240];

    if (logging) {
	sprintf(msgbuf, "TCP; %s; %u bytes; from %s:%s to %s:%s; %s",
		entry->ifname, pktlen, entry->s_fqdn, entry->s_sname,
		entry->d_fqdn, entry->d_sname, message);

	writelog(logging, fd, msgbuf);
    }
}

void write_tcp_unclosed(int logging, FILE * fd, struct tcptable *table)
{
    char msgbuf[160];

    struct tcptableent *entry = table->head;

    while (entry != NULL) {
	if ((entry->finsent == 0) && 
	   ((entry->stat & FLAG_RST) == 0) && 
	   (!(entry->inclosed))) {
	    sprintf(msgbuf, "TCP; %s; active; from %s:%s to %s:%s; %lu packets, %lu bytes",
		    entry->ifname, entry->s_fqdn, entry->s_sname,
	            entry->d_fqdn, entry->d_sname, entry->pcount, entry->bcount);
	    writelog(logging, fd, msgbuf);
	}
	entry = entry->next_entry;
    }
}

void writeothplog(int logging, FILE * fd, char *protname, char *description,
		  char *additional, int is_ip, int withmac,
		  struct othptabent *entry)
{
    char msgbuffer[160];
    char scratchpad[80];

    if (logging) {
	bzero(msgbuffer, 160);

	strcpy(msgbuffer, protname);
	strcat(msgbuffer, "; ");
	strcat(msgbuffer, entry->iface);
	sprintf(scratchpad, "; %u bytes;", entry->pkt_length);
	strcat(msgbuffer, scratchpad);
	if (is_ip) {
	    if (((entry->protocol == IPPROTO_UDP) && (!(entry->fragment))) 
	       || (entry->protocol == IPPROTO_TCP))
		sprintf(scratchpad, " from %s:%s to %s:%s",
			entry->s_fqdn, entry->un.udp.s_sname,
			entry->d_fqdn, entry->un.udp.d_sname);
	    else
		sprintf(scratchpad, " from %s to %s", entry->s_fqdn, entry->d_fqdn);
	} else
	    sprintf(scratchpad, " from %s to %s ", entry->smacaddr, entry->dmacaddr);

	strcat(msgbuffer, scratchpad);
	strcpy(scratchpad, "");
	if (strcmp(description, "") != 0) {
	    sprintf(scratchpad, "; %s", description);
	    strcat(msgbuffer, scratchpad);
	}
	strcpy(scratchpad, "");
	if (strcmp(additional, "") != 0) {
	    sprintf(scratchpad, " (%s)", additional);
	    strcat(msgbuffer, scratchpad);
	}
	writelog(logging, fd, msgbuffer);
    }
}

void writegstatlog(struct iftab *table, int unit, unsigned long nsecs, FILE * fd)
{
    struct iflist *ptmp = table->head;
    char atime[26];
    char unitstring[7];

    genatime(time((time_t *) NULL), atime);
    fprintf(fd, "\n*** General interface statistics log generated %s\n\n", atime);

    while (ptmp != NULL) {

	fprintf(fd, "%s: %llu total, %llu IP, %llu non-IP, %lu IP checksum errors",
		ptmp->ifname, ptmp->total, ptmp->iptotal, ptmp->noniptotal, ptmp->badtotal);

	if (nsecs > 5) {
	    dispmode(unit, unitstring);

	    if (unit == KBITS) {
	        fprintf(fd, ", average activity %.2f %s/s", (float) (ptmp->br * 8 / 1000) / (float) nsecs, unitstring);
	    } else {
	        fprintf(fd, ", average activity %.2f %s/s", (float) (ptmp->br / 1024) / (float) nsecs, unitstring);
	    }
	        
	    fprintf(fd, ", peak activity %.2f %s/s", ptmp->peakrate, unitstring);
	    fprintf(fd, ", last 5-second activity %.2f %s/s", ptmp->rate, unitstring);
	}
	fprintf(fd, "\n");

	ptmp = ptmp->next_entry;
    }

    fprintf(fd, "\n%lu seconds running time\n", nsecs);
}

void writedstatlog(char *ifname, int unit, float activity, float pps,
		   float peakactivity, float peakpps,
		   struct iftotals *ts, unsigned long nsecs,
		   FILE * fd)
{
    char atime[26];
    int i;
    char unitstring[7];
    
    dispmode(unit, unitstring);
        
    genatime(time((time_t *) NULL), atime);

    fprintf(fd, "\n*** Detailed statistics for interface %s, generated %s\n\n",
	    ifname, atime);

    fprintf(fd, "Total: %llu packets, %llu bytes\n", ts->total, ts->bytestotal);
    fprintf(fd, "IP: %llu packets, %llu bytes\n", ts->iptotal, ts->ipbtotal);
    fprintf(fd, "TCP: %llu packets, %llu bytes\n", ts->tcptotal, ts->tcpbtotal);
    fprintf(fd, "UDP: %llu packets, %llu bytes\n", ts->udptotal, ts->udpbtotal);
    fprintf(fd, "ICMP: %llu packets, %llu bytes\n", ts->icmptotal, ts->icmpbtotal);
    fprintf(fd, "Other IP: %llu packets, %llu bytes\n", ts->othtotal, ts->othbtotal);
    fprintf(fd, "Non-IP: %llu packets, %llu bytes\n\n", ts->noniptotal, ts->nonipbtotal);

    fprintf(fd, "Packet Size Counts\n");

    for (i = 0; i <= 15; i++)
	fprintf(fd, "%u to %u bytes: %lu\n", ts->brackets[i].floor,
		ts->brackets[i].ceil,
		ts->brackets[i].count);

    if (nsecs > 5) {
	fprintf(fd, "\nAverage activity: ");
	
	if (unit == KBITS)
	    fprintf(fd, "%.2f kbits/s, %.2f packets/s\n",
		((float) (ts->bytestotal * 8 / 1000) / (float) nsecs),
		((float) (ts->total) / (float) nsecs));
	else
	    fprintf(fd, "%.2f kbytes/s, %.2f packets/s\n",
		((float) (ts->bytestotal / 1024) / (float) nsecs),
		((float) (ts->total) / (float) nsecs));
	
	fprintf(fd, "Peak activity: %.2f %s/s, %.2f packets/s\n",
		peakactivity, unitstring, peakpps);

	fprintf(fd, "Last 5-second interface activity: %.2f %s/s, %.2f packets/s\n",
		activity, unitstring, pps);
    }
    fprintf(fd, "IP checksum errors: %lu\n\n", ts->badtotal);
    fprintf(fd, "Running time: %lu seconds\n", nsecs);
}

void writeutslog(struct portlistent *list, unsigned long nsecs, FILE * fd)
{
    char atime[26];
    struct portlistent *ptmp = list;

    genatime(time((time_t *) NULL), atime);

    fprintf(fd, "\n*** TCP/UDP traffic log, generated %s\n\n", atime);

    while (ptmp != NULL) {
	if (ptmp->protocol == IPPROTO_TCP)
	    fprintf(fd, "TCP/%s: ", ptmp->servname);
	else
	    fprintf(fd, "UDP/%s: ", ptmp->servname);

	fprintf(fd, "%llu packets, %llu bytes total; ", ptmp->count, ptmp->bcount);
	fprintf(fd, "%llu packets, %llu bytes incoming; ", ptmp->icount, ptmp->ibcount);
	fprintf(fd, "%llu packets, %llu bytes outgoing\n\n", ptmp->ocount, ptmp->obcount);

	ptmp = ptmp->next_entry;
    }

    fprintf(fd, "\nRunning time: %lu seconds\n", nsecs);
}

void writeethlog(struct ethtabent *list, int unit, unsigned long nsecs, FILE * fd)
{
    char atime[26];
    struct ethtabent *ptmp = list;
    char unitstring[7];
    
    dispmode(unit, unitstring);
        
    genatime(time((time_t *) NULL), atime);

    fprintf(fd, "\n*** LAN traffic log, generated %s\n\n", atime);

    while (ptmp != NULL) {
	if (ptmp->type == 0) {
	    if (ptmp->un.desc.linktype == LINK_ETHERNET)
		fprintf(fd, "\nEthernet address: %s", ptmp->un.desc.ascaddr);
	    else if (ptmp->un.desc.linktype == LINK_PLIP)
		fprintf(fd, "\nPLIP address: %s", ptmp->un.desc.ascaddr);
	    else if (ptmp->un.desc.linktype == LINK_FDDI)
		fprintf(fd, "\nFDDI address: %s", ptmp->un.desc.ascaddr);

	    if (ptmp->un.desc.withdesc)
		fprintf(fd, " (%s)", ptmp->un.desc.desc);

	    fprintf(fd, "\n");
	} else {
	    fprintf(fd, "\tIncoming total %llu packets, %llu bytes; %llu IP packets\n",
		    ptmp->un.figs.inpcount, ptmp->un.figs.inbcount, ptmp->un.figs.inippcount);
	    fprintf(fd, "\tOutgoing total %llu packets, %llu bytes; %llu IP packets\n",
		    ptmp->un.figs.outpcount, ptmp->un.figs.outbcount, ptmp->un.figs.outippcount);

	    fprintf(fd, "\tAverage rates: ");
	    if (unit == KBITS) 
	        fprintf(fd, "%.2f kbits/s incoming, %.2f kbits/s outgoing\n",
	            (float) (ptmp->un.figs.inbcount * 8 / 1000) / (float) nsecs,
	            (float) (ptmp->un.figs.outbcount * 8 / 1000) / (float) nsecs);
	    else
	        fprintf(fd, "%.2f kbytes/s incoming, %.2f kbytes/s outgoing\n",
	            (float) (ptmp->un.figs.inbcount / 1024) / (float) nsecs,
	            (float) (ptmp->un.figs.outbcount / 1024) / (float) nsecs);
	    
	    if (nsecs > 5)
		fprintf(fd, "\tLast 5-second rates: %.2f %s/s incoming, %.2f %s/s outgoing\n",
			ptmp->un.figs.inrate, unitstring,
			ptmp->un.figs.outrate, unitstring);
	}

	ptmp = ptmp->next_entry;
    }

    fprintf(fd, "\nRunning time: %lu seconds\n", nsecs);
}

void rotate_logfile(FILE ** fd, char *name)
{
    fclose(*fd);
    *fd = fopen(name, "a");
    rotate_flag = 0;
}


void announce_rotate_prepare(FILE * fd)
{
    writelog(1, fd, "***** USR1 signal received, preparing to reopen log file *****");
}

void announce_rotate_complete(FILE * fd)
{
    writelog(1, fd, "***** Logfile reopened *****");
}

void check_rotate_flag(FILE ** logfile, int logging)
{
    if ((rotate_flag == 1) && (logging)) {
	announce_rotate_prepare(*logfile);
	rotate_logfile(logfile, target_logname);
	announce_rotate_complete(*logfile);
	rotate_flag = 0;
    }
}
