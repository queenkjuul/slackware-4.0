/***
   menu.h - declaration file for my menu library
   Copyright (c) Gerard Paul R. Java 1997

***/

#define SELECTED 1
#define NOTSELECTED 0

#define SEPARATOR 0
#define REGULARITEM 1

struct ITEM {
    char option[39];
    char desc[80];
    unsigned int itemtype;
    struct ITEM *prev;
    struct ITEM *next;
};

struct MENU {
    struct ITEM *itemlist;
    struct ITEM *selecteditem;
    struct ITEM *lastitem;
    int itemcount;
    int postn;
    int x1, y1;
    int x2, y2;
    unsigned int menu_maxx;
    WINDOW *menuwin;
    PANEL *menupanel;
    WINDOW *descwin;
    PANEL *descpanel;
    char shortcuts[22];
};

extern void initmenu(struct MENU *menu, int y1, int x1, int y2, int x2);
extern void additem(struct MENU *menu, char *item, char *desc);
extern void showitem(struct MENU *menu, struct ITEM *itemptr, int selected);
extern void showmenu(struct MENU *menu);
extern void operatemenu(struct MENU *menu, int *row, int *aborted);
extern void destroymenu(struct MENU *menu);
