/*
 * Upgrade utility for 1.3.0 to 1.4.0
 *
 * Simply converts the MAC address database files to text format.
 */
 
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include "descrec.h"
#include "dirs.h"

void convert_addressfile(char *filename)
{
    int fd;
    FILE *target_fd;
    char target_newname[80];
    int br;
    struct descrec rec;
    
    strcpy(target_newname, filename);
    strcat(target_newname, "-1.3.0");
    
    rename(filename, target_newname);
    
    fd = open(target_newname, O_RDONLY);
    target_fd = fopen(filename, "w");
    
    do {
        br = read(fd, &rec, sizeof(struct descrec));
        if (br > 0)
            fprintf(target_fd, "%s:%s\n", rec.address, rec.desc);
    } while (br > 0);
    
    close(fd);
    fclose(target_fd);
}

int main(void)
{
    printf("\n****** Converting old MAC address databases to text format\n\n");
    
    printf("Converting Ethernet/PLIP database...");
    convert_addressfile(ETHFILE);
    printf("done\n");
    printf("Converting FDDI database...");
    convert_addressfile(FDDIFILE);
    printf("done\n\n");
    printf("Database conversion complete\n");
    return 0;
}
