#define T_WORKDIR	1
#define T_LOGDIR	2
#define T_EXECDIR	3

char *get_path(int dirtype, char *file);
