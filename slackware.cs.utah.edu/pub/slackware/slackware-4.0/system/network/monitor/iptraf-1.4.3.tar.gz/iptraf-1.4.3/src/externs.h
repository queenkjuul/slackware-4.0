
/***

externs.h - external routines used by the the iptraf module and some
others

***/

void ipmon(const struct OPTIONS *options, int filtered, struct filterlist *fl,
	   struct othpoptions *ofilter, unsigned int tm, int facilitytime);
void selectiface(char *ifname, int *aborted);
void ifstats(const struct OPTIONS *options, int facilitytime);
void detstats(char *iface, const struct OPTIONS *options, int facilitytime);
void servmon(char *iface, struct porttab *ports, const struct OPTIONS *options, int facilitytime);
void hostmon(const struct OPTIONS *options, int facilitytime);
void ethdescmgr(void);
void setoptions(struct OPTIONS *options, struct porttab **ports, int is_first_instance);
void loadoptions(struct OPTIONS *options);
void saveoptions(struct OPTIONS *options);
