/***

fltmgr.h - filter list management routine prototypes

Copyright (c) Gerard Paul Java 1998

***/

#define F_TCP 0
#define F_UDP 1

struct filterfileent {
    char desc[35];
    char filename[40];
};

struct hostparams {
    char s_fqdn[25];
    char d_fqdn[25];
    char s_mask[20];
    char d_mask[20];
    unsigned int sport;
    unsigned int dport;
    char reverse;
};

struct ffnode {
    struct filterfileent ffe;
    struct ffnode *next_entry;
    struct ffnode *prev_entry;
};

int loadfilterlist(unsigned int protocol, struct ffnode **fltfile);
void destroyfilterlist(struct ffnode *fltlist);

