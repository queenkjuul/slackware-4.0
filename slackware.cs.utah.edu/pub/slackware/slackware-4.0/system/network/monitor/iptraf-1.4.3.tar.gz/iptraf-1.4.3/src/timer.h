void printelapsedtime(time_t start, time_t now, int y, int x, WINDOW *win);
