#####################################################
#  gdip-conf.pl         Part of GnuDIP 2.0.6        #
#                                                   #
#    Common subs used by GnuDIP scripts             #
#                                                   #
#    See COPYING for licensing information          #
#                                                   #
#       Mike Machado <mike@innercite.com>           #
#       Ryan Wahle   <wahle@innercite.com>          #
#                                                   #
#####################################################


my $conffile = '/etc/gnudip.conf';

# Simple routines to read config information from a file
# Added to the Debian GnuDIP package by Randolph Chung <tausq@debian.org>
sub readconf {
  my $var = shift;
  my $result;

  open (CONF, "<$conffile");
  while (<CONF>) {
    if (/^$var\s*=\s*(.+)$/) {
      $result = $1;
    }
  }
  close CONF;
  return $result;
}

# Returns the date and time in a mysql format
sub getdatetime {
  my $today = localtime(time());
  my ($day,$mon,$dayofmon,$time,$year) = split(/\s+/,$today);
  my @datemonths = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");

  my $numidx = "01";
  my ($nummon);
  foreach my $mons (@datemonths) {
    if ($mon eq $mons) {
     $nummon = $numidx;
    }
    $numidx++;
  }

  return "$year-$nummon-$dayofmon $time";

}
