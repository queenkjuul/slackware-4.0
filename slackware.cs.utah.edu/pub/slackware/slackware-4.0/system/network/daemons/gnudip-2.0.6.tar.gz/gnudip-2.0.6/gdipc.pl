#!/usr/bin/perl
#####################################################
#  gdipc.pl         Part of GnuDIP 2.0.6            #
#                                                   #
#    The GnuDIP command line client                 #
#                                                   #
#    See COPYING for licensing information          #
#                                                   #
#       Mike Machado <mike@innercite.com>           #
#       Ryan Wahle   <wahle@innercite.com>          #
#                                                   #
#####################################################

  use Socket;
  use strict;

  #### Set up varialbes
  my ($haveconfig, $username, $pass, $encpass, $serverip, $newusername, $newpass, $newpass1, $newencpass, $newserverip);
  my $VER = "2.0.6";
  my $CONFIGFILE = "$ENV{'HOME'}/.GnuDIP2";
  my $server_port = "3495";

  #### Open users config file
  $haveconfig = open(CONFIG,"$CONFIGFILE") || "NO";
  if ($ARGV[0] eq '-h') {
     print "   gdipc.pl: Send your information to the server once your prefs have been set\n";
     print "   gdipc.pl -c: Change or create your preferences\n";
     print "   gdipc.pl -i: Interactive mode (reads from stdin rather than \$HOME/.GnuDIP2)\n";
     print "   gdipc.pl -r: Send a offline request to the server to not have your hostname point to anything until next login\n";
     print "   gdipc.pl -v: Show version information\n";
   } elsif ($ARGV[0] eq '-c') {
     print "   Changing prefernces:\n";

     print "     New Username: ";
     $newusername = <STDIN>;
     chop($newusername);
    
     my $salt = substr($newusername, 0, 2);
     system("stty -echo");

     my $notsamepass = 1;

     while($notsamepass) {
       print "     New Password: ";
       $newpass = <STDIN>;
       chop($newpass);

       print "\n     New Password Again: ";
       $newpass1 = <STDIN>;
       chop($newpass1);

       if(!checksame($newpass, $newpass1)) {
          print "\n\n  Please enter the same password twice!\n";
       } else {
          $notsamepass = 0;
       }

     }

     $newencpass = crypt($newpass, $salt);
     
     system("stty echo");
     print "\n     New GnuDIP Server: ";
     $newserverip = <STDIN>;
     chop($newserverip);


     open(CONFIG, ">$CONFIGFILE") || die "Cound not create prefs file $!\n";
     print CONFIG "$newusername:$newencpass:$newserverip";
     close(CONFIG);
     chmod 0600, $CONFIGFILE;

   } elsif ($ARGV[0] eq '-v') {
     print "   gdipc.pl: Version $VER\n";
     print "   See http://gnudip.cheapnet.net for more information\n";
     print "   or email the developers\n";
     print "   Mike Machado <mike\@innercite.com>\n";
     print "   Ryan Wahle <wahle\@innercite.com>\n";
   } elsif ($ARGV[0] eq '-i') {
     print "   Interactive Mode:\n";

     print "     Username: ";
     $username = <STDIN>;
     chop($username);
    
     system("stty -echo");
     print "     Password: ";
     my $pass = <STDIN>;
     chop($pass);

     system("stty echo");
     print "\n     GnuDIP Server: ";
     $serverip = <STDIN>;
     chop($serverip);

     $encpass = crypt($pass, substr($username, 0, 2));

     sendlogin($username, $encpass, $serverip, "0");


   } elsif ($ARGV[0] eq '-r') {
     if ($haveconfig eq 'NO') {
        print "   gdipc.pl: You must first set up your prefenrences with gdipc.pl -c\n";
        exit;
      } else {
        my $prefs = <CONFIG>;
        ($username, $encpass, $serverip) = split(/:/, $prefs);
        close(CONFIG);

        sendlogin($username, $encpass, $serverip, "1");
      }

   } else {
     if ($haveconfig eq 'NO') {
        print "   gdipc.pl: You must first set up your prefenrences with gdipc.pl -c\n";
        exit;
      } else {
        my $prefs = <CONFIG>;
        ($username, $encpass, $serverip) = split(/:/, $prefs);
        close(CONFIG);

        sendlogin($username, $encpass, $serverip, "0");
      }
   }


#### Sub to connect to server and send the data
sub sendlogin {
 my $username = shift;
 my $encpass = shift;
 my $serverip = shift;
 my $serveraction = shift;
 my $response;
       
 socket(SERVER, PF_INET, SOCK_STREAM, getprotobyname('tcp'));
 my $inet_addr = gethostbyname($serverip);
 my $paddr = sockaddr_in($server_port, $inet_addr);
 connect(SERVER, $paddr) || die "Could not connect to $serverip:$server_port\n";

 #### Change to non-buffer writes for our socket
 select(SERVER);
 $| = 1;
 select(STDOUT);


 chomp(my $salt = <SERVER>);
 my $securepass = crypt($encpass, substr($salt, 0, 2));
 print SERVER "$username:$securepass:$serveraction\n";

 chomp($response = <SERVER>);
 if ($response eq "0") {
    print " Successfully updated to new IP address \n";
 } elsif ($response eq "1") {
    print " Invalid login attempt\n";
 } elsif ($response eq "2") {
    print " Offline request successful \(login again to repoint your hostname\)\n";
 } else {
    print " Server did not respond to login attempt\n";
 }

 close(SERVER);

}


#### Check to see if the two passed in args are the same
sub checksame {
  my $arg1 = shift;
  my $arg2 = shift;

  return 1 if $arg1 eq $arg2;
  return 0;
}

