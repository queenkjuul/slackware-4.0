#!/usr/bin/perl 
#####################################################
#  gdips.pl             Part of GnuDIP 2.0.6        #
#                                                   #
#    This is the GnuDIP server daemon               #
#                                                   #
#    See COPYING for licensing information          #
#                                                   #
#       Mike Machado <mike@innercite.com>           #
#       Ryan Wahle   <wahle@innercite.com>          #
#                                                   #
#####################################################



use DBI;
use Socket;
use Symbol;
use POSIX;
use Getopt::Std;
use strict;
my ($i, $sth, $sqldatetime);
require 'gnudip-conf.pl';

my $VER = "2.0.6";

my $gnudip2user = readconf('gnudipuser');
my $gnudip2pass = readconf('gnudippassword');
my $gnudip2server = readconf('gnudipserver');
my $runasuser = readconf('runasuser');
my $runasgroup = readconf('runasgroup');
my $pidfile = readconf('pidfile');
my $PORT = "3495";

my %opts;
getopts('hl:', \%opts);
my $TIMEOUT = 3;

my $logging = 0;
my $log = '';
if (exists $opts{'l'}) {
  $logging = 1;
  $log = $opts{'l'};
}

if (exists $opts{'h'}) {
  print " gdips.pl [-l [logfile]]\n";
  exit(0);
}

if ($> != 0) {
  print "Must run as root!\n";
  exit 0;
}

preparelog();

open (PID, ">$pidfile");
print PID "$$\n";
close PID;

# Drop root priviledges....
my @pwent = getpwnam($runasuser);
($< = $> = $pwent[2]) || die "Cannot drop root permissions!";
my @grent = getgrnam($runasgroup);
($( = $) = $grent[2]) || die "Cannot drop root group permissions!";
    

my $dbh = DBI->connect("DBI:mysql:gnudip2:$gnudip2server", $gnudip2user, $gnudip2pass);

my @chars = ( "A" .. "Z", "a" .. "z", 0 .. 9);


socket(SERVER, PF_INET, SOCK_STREAM, getprotobyname('tcp'));
setsockopt(SERVER, SOL_SOCKET, SO_REUSEADDR, 1);

my $my_addr = sockaddr_in($PORT, INADDR_ANY);
bind(SERVER, $my_addr);

listen(SERVER, 10);

my $PREFORK = 3;
my $MAX_CLIENTS_PER_CHILD = 5;
my %children = ();
my $children = 0;

sub REAPER {
  $SIG{CHLD} = \&REAPER;
  my $pid = wait;
  $children--;
  delete $children{$pid};
}

sub HUNTSMAN {
  local($SIG{CHLD}) = 'IGNORE';
  kill 'INT' => keys %children;
  closelog();
  exit;
}

for (1 .. $PREFORK) {
  make_new_child();
}

$SIG{CHLD} = \&REAPER;
$SIG{INT} = \&HUNTSMAN;
$SIG{TERM} = \&HUNTSMAN;
$SIG{KILL} = \&HUNTSMAN; 

print STDERR "GnuDIP daemon $VER started\n";
while (1) {
  sleep;
  for ($i = $children; $i < $PREFORK; $i++) {
   make_new_child();
  }
}

sub make_new_child {
  my $pid;
  my $sigset;
  my $response;

  $sigset = POSIX::SigSet->new(SIGINT);
  sigprocmask(SIG_BLOCK, $sigset) or die "Cannot block SIGINT for fork: $!\n";
  
  die "fork: $!" unless defined ($pid = fork);

  if ($pid) {
 
     sigprocmask(SIG_UNBLOCK, $sigset) or die "Cannot unblock SIGINT after fork $!\n";
     $children{$pid} = 1;
     $children++;
     return;

  } else {
    
     $SIG{INT} = 'DEFAULT';
     sigprocmask(SIG_UNBLOCK, $sigset) or die "Cannot unblock SIGINT after fork $!\n";

     for ($i = 0; $i < $MAX_CLIENTS_PER_CHILD; $i++) {
       my $client_addr = accept(CLIENT, SERVER);
       my ($port, $packed_ip) = sockaddr_in($client_addr);
       my $ip = inet_ntoa($packed_ip);

       $sqldatetime = getdatetime();

       # print temp salt.
       select(CLIENT);
       $| = 1;
       select(STDOUT);
       my $salta = $chars [ rand @chars ];
       my $saltb = $chars [ rand @chars ];
       my $salt = $salta.$saltb;
       print CLIENT "$salt\n";


       my ($clientuser, $clientpass, $clientaction, $found);
       my $rin = '';
       vec($rin, fileno(CLIENT), 1) = 1;
       # only wait $TIMEOUT seconds for data, or else disconnect this session
       my $found = select($rin, undef, undef, $TIMEOUT);
       if ($found) {
          chomp($response = <CLIENT>);
          ($clientuser, $clientpass, $clientaction) = split(/:/, $response);
          $clientaction = "0" if $clientaction eq '';
       } else {
          $clientaction = "-1";
       }
       
       # a modify request
       if ($clientaction eq '0') {
          $sth = $dbh->prepare("select * from users where username = \"$clientuser\"");
          $sth->execute;
          my @clientinfo = $sth->fetchrow_array;
          my $checkpass = crypt($clientinfo[2], $salt);
          if ($clientinfo[0] eq '') {
              print CLIENT "1\n";
              writelog("Invalid login attemp from $ip: user $clientuser");
          } elsif (!($clientinfo[1] eq $clientuser && $checkpass eq $clientpass)) {
              print CLIENT "1\n";
              writelog("Invalid login attempt from $ip: user $clientuser");
          } else {
              my $prefref = getprefs();
              print CLIENT "0\n";
              $sth = $dbh->do("update users set currentip = \"$ip\", updated = \"$sqldatetime\" where username = \"$clientuser\"");
              $sth = $dbh->do("delete from queue where hostname = \"$clientuser\"");
              $sth = $dbh->do("insert into queue values \(\"\",\"$clientuser\",\"$ip\",\"MODIFY\"\)");
              writelog("User $clientuser successful update to ip $ip");
          } 

       # a offline request
       } elsif ($clientaction eq '1') {
          $sth = $dbh->prepare("select * from users where username = \"$clientuser\"");
          $sth->execute;
          my @clientinfo = $sth->fetchrow_array;
          my $checkpass = crypt($clientinfo[2], $salt);
          if ($clientinfo[0] eq '') {
              print CLIENT "1\n";
              writelog("Invalid login attemp from $ip: user $clientuser");
          } elsif (!($clientinfo[1] eq $clientuser && $checkpass eq $clientpass)) {
              print CLIENT "1\n";
              writelog("Invalid login attempt from $ip: user $clientuser");
          } else {
              my $prefref = getprefs();
              print CLIENT "2\n";
              $sth = $dbh->do("update users set currentip = \"0.0.0.0\", updated = \"$sqldatetime\" where username = \"$clientuser\"");
              $sth = $dbh->do("delete from queue where hostname = \"$clientuser\"");
              $sth = $dbh->do("insert into queue values \(\"\",\"$clientuser\",\"0.0.0.0\",\"REMOVE\"\)");
              writelog("User $clientuser successful remove from ip $ip");
          } 
       } elsif ($clientaction eq '-1') {
          writelog("Timed out receiving session data from $ip");
          print CLIENT "-1\n";
       } else {
          writelog("Unknown response from $ip");
          print CLIENT "-1\n";
       }
     }

     exit;
  }
}


#### Get prefs
sub getprefs {
 my %PREF;
 $sth = $dbh->prepare("select * from globalprefs");
 $sth->execute;
 while (my @prefs = $sth->fetchrow_array) {
   $PREF{$prefs[1]} = $prefs[2];
 }
 return \%PREF;

}           


### Prepare log
sub preparelog {

  if ($logging && $log ne '') {
    open(LOG,">>$log") || die "Could not open $log for append $!";
    select(LOG);
    $| = 1;
    select(STDOUT);
  }

}

### Write to the log, syslog or stdout
sub writelog {

  my $logstr = shift;
  my $today = getdatetime();

  if ($logging) {
    if ($log ne '') {
       print LOG "[$today] $logstr\n" || print "cannot write to log";
    } else {
       print STDOUT "[$today] $logstr\n";
    }
  }

}


# close open log file
sub closelog {

  if ($logging && $log ne '') {
    close(LOG);
  }

}
