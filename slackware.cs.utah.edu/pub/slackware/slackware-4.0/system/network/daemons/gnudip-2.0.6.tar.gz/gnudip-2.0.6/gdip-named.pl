#!/usr/local/bin/perl -Tw
########################################################
#   gdip-named.pl        Part of GnuDIP 2.0.6          #
#                                                      #
#        This program connects to the gnudip2          #
#        database and looks for any queued enries      #
#        and writes them to the named zone file        #
#                                                      #
#        See COPYING for licensing information         #
#                                                      #
########################################################


  use DBI;
  use strict;
  my (%PREF, %NEWRECS, $x, $space, $serial, $host, $rec, $addr, $dup, $newhost, $sth,  $writeip, $action);
  require 'gnudip-conf.pl';

  #### Set up some variables
  my $gnudip2user = readconf('gnudipuser');
  my $gnudip2pass = readconf('gnudippassword');
  my $gnudip2server = readconf('gnudipserver');
  my $tmpdir = readconf('tmpdir');


  #### Connect to the database
  my $dbh = DBI->connect("DBI:mysql:gnudip2:$gnudip2server",$gnudip2user,$gnudip2pass) || die "Cannot connect to database $!\n";

  #### Read prefs from database and store in an easy to use hash
  $sth = $dbh->prepare("select * from globalprefs");
  $sth->execute;
  while (my @prefs = $sth->fetchrow_array) {
    $PREF{$prefs[1]} = $prefs[2];
  }
  $sth->finish;
    
  my $zonefile = $PREF{'ZONEFILE'};
  my $ndc = $PREF{'NDC_PATH'};
  my $ZONETYPE = $PREF{'ZONETYPE'};

  #### Get queued entries
  $sth = $dbh->do("lock tables queue write") || die "Unable to lock table queue $!\n";
  $sth = $dbh->prepare("select * from queue");
  $sth->execute;

  #### Get all the queued entries and store them in a hash
  while (my @zonerecs = $sth->fetchrow_array) {
    $NEWRECS{$zonerecs[1]} = "$zonerecs[2]:$zonerecs[3]";
  }
  $sth->finish;
  $sth = $dbh->do("delete from queue");
  $sth = $dbh->do("unlock tables");

 #### If there were queued entries, 
 if (%NEWRECS ne 0) {

  die "Encountered symbolic link\n" if -l "$tmpdir/gnudip2.$$";

  open(ZONE,"$zonefile") || die "Could not open zone file\n";
  open(TEMP,">$tmpdir/gnudip2.$$") || die "Could not open temp file for writing\n";
  $x = 1;
    while (<ZONE>) {
      if ($x eq '2' && $ZONETYPE eq "STANDALONE") {
         ($space,$serial) = split(/\t+/);
         $serial++;
         print TEMP "\t\t\t$serial\t; serial  \n";
      } else {
         ($host,$rec,$addr) = split( /\t+/);  
         $dup = "NO";
         foreach $newhost (keys %NEWRECS) {
           if ($host eq $newhost) {
              $dup = "YES";
           }
         }
         if ($dup ne "YES") {
           print TEMP $_;
         }
      }
      $x++;
     }
     foreach $newhost (keys %NEWRECS) {
        # just dont print the line if its a REMOVE. do a split and and then an if for a REMOVE
       ($writeip, $action) = split(/:/, $NEWRECS{$newhost});
       print TEMP "$newhost\t\tA\t$writeip\n" if $action eq "MODIFY";
    }
  close(TEMP);
  close(ZONE);          
  system("/bin/cp","$tmpdir/gnudip2.$$","$zonefile");
  unlink("$tmpdir/gnudip2.$$");
  system($ndc,"reload");
 }
  

  $dbh->disconnect;
