#if 0
Thu Feb 24 14:17:50 MET 1994 (1.1)
Thu May  5 15:55:22 MET DST 1994 (1.2)
Sun Jun 12 23:08:07 MET DST 1994 (1.3)
#endif
#define VERSION "1.4"
