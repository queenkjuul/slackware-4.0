/*#define DEBUG*/
/*#define DDEBUG*/
#define VERSION "proxyrouted v0.10 by Delian Delchev \n"

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <malloc.h>
#include <ctype.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <linux/if.h>
#include <linux/if_ether.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <time.h>

#define MAX_PACK_LEN 2000
#define ETHER_HEADER_LEN 14
#define MAX_INTERFACES 16
#define ETHWTYPE 1
#define PATHROUTE "/proc/net/route"
#define ARPREQUEST 1
#define ARPREPLY 2
#define perr(s) fprintf(stderr,s)
#define TEMPSTR "NULL"

struct ether_hdr
       {
          u_char dst_mac[6],src_mac[6],pkt_type[2];
          u_short hw_type,pro_type;
          u_char hw_len,pro_len;
          u_short arp_op;
          u_char sender_eth[6],sender_ip[4];
          u_char target_eth[6],target_ip[4];
       };
union
       {
          u_char full_packet[MAX_PACK_LEN];
          struct ether_hdr ether_header;
       } a;
#define full_packet a.full_packet
#define ether_header a.ether_header

#ifdef DEBUG
void paddr(u_char *s)
{ printf("%d.%d.%d.%d",s[0],s[1],s[2],s[3]); }
void phwaddr(u_char *s)
{ printf("%.2x:%.2x:%.2x:%.2x:%.2x:%.2x",s[0],s[1],s[2],s[3],s[4],s[5]); }
#endif

int fd;

int promisc(char *device,int flag)
{
  struct ifreq if_data;

  strcpy(if_data.ifr_name,device);
  if (ioctl(fd,SIOCGIFFLAGS,&if_data)<0) return -1;
  if (flag) if_data.ifr_flags |= IFF_PROMISC;
     else if_data.ifr_flags &= ~IFF_PROMISC;
  if (ioctl(fd,SIOCSIFFLAGS,&if_data)<0) return -1;
#ifdef DEBUG
  printf("promisc %s\n",device);
#endif
  return 0;
}

void main(int argv,char **argc)
{
  int len,from_len,frame,i,j,interfaces;
  u_int mask,dest,ip,oldmask;
  char BOARD[MAX_INTERFACES][16],TEMP[5][16];
  char DEVICE[16],RDEVICE[16],buff[1023];
  FILE *f;
  struct ifconf ifc;
  struct ifreq ifr[MAX_INTERFACES],if_data;
  struct sockaddr from;

  if (getuid()!=0)
     { perr("You must be root to run this program!\n"); exit(0); }
  if ((fd=socket(AF_INET,SOCK_PACKET,htons(ETH_P_ARP)))<0)
     { perr("can't open socket!\n"); exit(0); }
  interfaces=0;
  if (argv>1) for(i=1;i<argv;i++) strcpy(BOARD[interfaces++],argc[i]);
     else {
#ifdef DEBUG
            printf("try to get all eth?? interfaces...\n");
#endif
            ifc.ifc_len=MAX_INTERFACES*sizeof(struct ifreq);
            ifc.ifc_buf=(char *)ifr;
            if (ioctl(fd,SIOCGIFCONF,&ifc)<0)
               { perr("ioctl failed! can't get interfaces...\n");exit(0);}
            for(i=0;i<MAX_INTERFACES;i++)
#ifdef DDEBUG
             {
               printf("Found interface: %s\n",ifr[i].ifr_name);
#endif
               if ((ifr[i].ifr_name[0]=='e')&&
                   (ifr[i].ifr_name[1]=='t')&&
                   (ifr[i].ifr_name[2]=='h')) strcpy(BOARD[interfaces++],ifr[i].ifr_name);
#ifdef DDEBUG
             }
#endif
          }
#ifdef DEBUG
            printf("found %d interfaces\n",interfaces);
#endif
  if (interfaces<1)
     { perr("You don't have ethernet interfaces!\n");exit(0);}
  for (i=0;i<interfaces;i++) promisc(BOARD[i],1);

  for(;;)
     {
        from_len=sizeof(from);
        len=recvfrom(fd,full_packet,MAX_PACK_LEN,0,&from,&from_len);
        if (len<=ETHER_HEADER_LEN) continue;
#ifdef DDEBUG
        printf("HW Type %d ",ntohs(ether_header.hw_type));
#endif
#ifdef DEBUG
        printf("I get ARP ");
        if (ntohs(ether_header.arp_op)==ARPREQUEST) printf("request");
        else printf("reply");
        printf(" from ");paddr(ether_header.sender_ip);printf(",");
        phwaddr(ether_header.sender_eth);printf(" to ");
        paddr(ether_header.target_ip);printf(" from device %s\n",from.sa_data);
#endif
        if ((ntohs(ether_header.hw_type)!=ETHWTYPE)||
            (ntohs(ether_header.arp_op)!=ARPREQUEST)) continue;
        for(i=0;i<interfaces;i++) if (strcmp(from.sa_data,BOARD[i])==0) break;
        if (i==interfaces) continue;
#ifdef DDEBUG
	printf("trying to open %s\n",PATHROUTE);
#endif
        if ((f=fopen(PATHROUTE,"r"))==NULL)
           { perr("can't open route file!\n");exit(0);}
        oldmask=0;strcpy(DEVICE,TEMPSTR);
        while(fgets(buff,1023,f))
           {
              i=sscanf(buff,"%s %X %s %s %s %s %s %X\n",
                  RDEVICE,&dest,TEMP[0],TEMP[1],TEMP[2],TEMP[3],TEMP[4],&mask);
              if (i!=8) continue;
              dest=ntohl(dest);mask=ntohl(mask);
#ifdef DDEBUG
            printf("read from routing table %s %.8X %.8X\n",RDEVICE,dest,mask);
            printf("operations: (%.8X&%.8X = %.8X) == %.8X\n",
                    ntohl(*(u_int *)&ether_header.target_ip[0]),
                    mask,
                    ntohl(*(u_int *)&ether_header.target_ip[0])&mask,
                    dest);
#endif
              if ((mask>oldmask)&&
                  ((ntohl(*(u_int *)&ether_header.target_ip[0])&mask)==dest))
                   {      
                      strcpy(DEVICE,RDEVICE);
                      oldmask=mask;
#ifdef DDEBUG
                      printf("found it at device %s\n",DEVICE);
#endif
                   }
           }
        fclose(f);
        if ((strcmp(DEVICE,TEMPSTR)!=0)&&(strcmp(DEVICE,from.sa_data)!=0))
           {
#ifdef DEBUG
              printf("found ");paddr(ether_header.target_ip);
              printf(" at my interface %s trying to send reply with ",DEVICE);
#endif 
              memcpy(ether_header.dst_mac,ether_header.src_mac,6);
              strcpy(if_data.ifr_name,from.sa_data);
              if (ioctl(fd,SIOCGIFHWADDR,&if_data)<0) perr("can't get HW addres of my interface!\n");
              memcpy(ether_header.src_mac,if_data.ifr_hwaddr.sa_data,6);
              memcpy(ether_header.target_eth,ether_header.src_mac,6);
#ifdef DEBUG
              phwaddr(ether_header.src_mac);printf(" address\n");
#endif
              ether_header.arp_op=htons(ARPREPLY);
              memcpy(buff,ether_header.sender_eth,10);
              memcpy(ether_header.sender_eth,ether_header.target_eth,10);
              memcpy(ether_header.target_eth,buff,10);
              if (sendto(fd,full_packet,len,0,&from,from_len)<0) perr("can't send arp reply!\n");              
           }
     }
}
