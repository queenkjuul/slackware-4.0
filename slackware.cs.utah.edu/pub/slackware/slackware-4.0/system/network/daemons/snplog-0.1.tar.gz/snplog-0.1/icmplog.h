/* icmplog.h - definitions and prototypes for icmplog.c */
#ifndef ICMPLOG_H
#define ICMPLOG_H

/* IP + ICMP packet header */
struct ippkt {
  struct iphdr ip;
  struct icmphdr icmp;
} pkt;

/* messages from <netinet/ip_icmp.h> */
static char *messages[] = {
  "echoreply", "", "", "dest_unreach", "source_quench",
  "redirect", "", "", "echo", "", "", "time_exceeded",
  "parameterprob", "timestamp", "timestampreply",
  "info_request", "info_reply",  "address",
  "addressreply"};
static char *unreach_messages[] = {
  "net_unreach", "host_unreach", "prot_unreach",
  "port_unreach", "frag_needed", "sr_failed",
  "net_unknown", "host_unknown", "host_isolated",
  "net_ano", "host_ano", "net_unr_tos",
  "host_unr_tos", "pkt_filtered", "prec_violation",
  "prec_cutoff"};
static char *redirect_messages[] = {
  "redir_net", "redir_host", "cmp_redir_nettos",
  "redir_hosttos"};
static char *time_exceeded_messages[] = {
  "exc_ttl", "exc_fragtime"};

void icmp_print (void);
void icmp_log (void);

#endif /* ICMPLOG_H */
