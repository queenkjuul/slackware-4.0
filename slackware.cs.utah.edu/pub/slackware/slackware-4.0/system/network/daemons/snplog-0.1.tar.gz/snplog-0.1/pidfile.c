/* pidfile.c - handling for a pidfile */
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include "util.h"
#include "pidfile.h"

/* reads *pidfile and returns 0 if no pidfile exists or pid if ok */
int read_pid (const char *pidfile) {
  FILE *f;
  int pid;

  if (! (f = (FILE *)fopen (pidfile, "r")))
    return 0;
  fscanf (f, "%d", &pid);
  fclose(f);
  return pid;
}

/* checks *pidfile and returns 0 if process already exists, otherwise pid */
int check_pid (const char *pidfile) {
  int pid = (int)read_pid(pidfile);

  /* Are we holding the file ? */
  if ((!pid) || (pid == getpid()))
    return 0;

  /* Hmm. Send fake kill and see if there is an error */
  if (kill(pid, 0) && errno == ESRCH)
    return 0;
  return pid;
}

/* writes pid to *pidfile and returns 0 if failed, otherwise pid */
int write_pid (const char *pidfile) {
  FILE *f;
  int fd, pid;

  /* create or open *pidfile */
  if (((fd = (int)open(pidfile, O_RDWR|O_CREAT, 0644)) == -1) ||
      ((f = (FILE *)fdopen (fd, "r+")) == NULL)) {
    fprintf (stderr, "Can't open or create pidfile %s.\n", pidfile);
    return 0;
  }

  /* lock *pidfile */
  if (flock (fd, LOCK_EX|LOCK_NB) == -1) {
    fscanf (f, "%d", &pid);
    fclose (f);
    printf ("Can't lock, lock is held by pid %d\n", pid);
    return 0;
  }

  /* write pid to *pidfile */
  pid = (int)getpid();
  if (! fprintf (f, "%d\n", pid)) {
    printf ("Can't write pid, %s.\n", strerror(errno));
    close (fd);
    return 0;
  }
  fflush (f);

  /* unlock *pidfile */
  if (flock (fd, LOCK_UN) == -1) {
    printf ("Can't unlock pidfile %s, %s.\n", pidfile, strerror(errno));
    close (fd);
    return 0;
  }
  close (fd);
  return pid;
}

/* removes pidfile and returns result from unlink(2) */
int remove_pid (const char *pidfile) {
  return (int)unlink(pidfile);
}
