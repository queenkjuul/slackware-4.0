/* tcplog.h - definitions and prototypes for tcplog.c */
#ifndef TCPLOG_H
#define TCPLOG_H

/* a UDP header */
struct ippkt {
  struct iphdr ip;
  struct udphdr udp;
} pkt;

void udp_print (void);
void udp_log (void);

#endif /* TCPLOG_H */
