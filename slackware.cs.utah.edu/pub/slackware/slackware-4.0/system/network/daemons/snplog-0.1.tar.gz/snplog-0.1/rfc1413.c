/* rfc1413.c - simple ident query */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netdb.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include "rfc1413.h"

#define BUFSIZE 512

/* does an auth query (RFC1413) and returns the remote username
   or NULL in case of an error or no data */
char *get_rfc1413_data(const int remote_port, const int local_port,
		       const unsigned long int remote_addr,
		       const unsigned long int local_addr) {
  int sock, on = 1;
  struct sockaddr_in sin;
  struct linger lin;
  char *buf, *ret = NULL;
  fd_set rs;
  struct timeval timeout;

  /* get space for buf, BUFSIZE bytes should be enough (?) */
  if ((buf = (char *)calloc(BUFSIZE, sizeof(char))) == NULL) {
    return ret;
  }

  /* open socket */
  if ((sock = socket(AF_INET, SOCK_STREAM, 0)) >= 0) {
    /* silently ignore errors if we can't change LINGER */
    lin.l_onoff = 0;
    lin.l_linger = 0;
    (void)setsockopt(sock, SOL_SOCKET, SO_LINGER,
		     (void *) &lin, sizeof (lin));
    (void)setsockopt(sock, SOL_SOCKET, SO_REUSEADDR,
		     (void *)&on, sizeof (on));

    bzero ((char *)&sin, sizeof (sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = local_addr;
    sin.sin_port = 0;

    /* assign name to sock */
    if (bind (sock, (struct sockaddr *) &sin, sizeof (sin)) == 0) {

      bzero ((char *)&sin, sizeof (sin));
      sin.sin_family = AF_INET;
      sin.sin_port = getservbyname("auth", "tcp")->s_port;
      sin.sin_addr.s_addr = remote_addr;

      /* connect to auth port ... */
      if (connect(sock, (struct sockaddr *) &sin, sizeof(sin)) == 0) {

	/* ... send to remote identd ... */
	sprintf(buf, "%d,%d\n", remote_port, local_port);
	write(sock, buf, strlen(buf));
	bzero(buf, BUFSIZE);

	timeout.tv_sec = 5;
	timeout.tv_usec = 0;
	FD_ZERO (&rs);
	FD_SET (sock, &rs);

	/* ... wait 5 seconds for input ... */
	if (select (FD_SETSIZE, &rs, (fd_set *)0,
		    (fd_set *)0, &timeout) > 0) {

	  /* ... and get an answer */
	  if (read(sock, buf, 256) > 0) {
	    ret = (char *)calloc(64, sizeof(char));

	    /* minimal parsing, we just want the username */
	    sscanf(buf,
		   "%*d , %*d : %*[^ \t\n\r:] : %*[^\t\n\r:] : %[^\n\r]",
		   ret);
	  }
	}
      }
    }
    close(sock);
  }
  if (buf) free (buf);
  return ret;
}
