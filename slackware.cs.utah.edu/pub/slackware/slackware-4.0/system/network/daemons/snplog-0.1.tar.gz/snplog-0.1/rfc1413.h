/* rfc1413.h - definitions and prototypes for rfc1413.c */
#ifndef RFC1413_H
#define RFC1413_H

char *get_rfc1413_data(const int, const int,
		       const unsigned long int,
		       const unsigned long int);

#endif /* RFC1413_H */
