/* tcplog.h - definitions and prototypes for tcplog.c */
#ifndef TCPLOG_H
#define TCPLOG_H

/* a tcp header */
struct ippkt {
  struct iphdr ip;
  struct tcphdr tcp;
} pkt;

void tcp_print (void);
void tcp_log (void);

#endif /* TCPLOG_H */
