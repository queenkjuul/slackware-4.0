/* icmplog.c - simple icmp header logging */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <syslog.h>
#include <errno.h>
#include <paths.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include "icmplog.h"
#include "util.h"

char *pidfile = _PATH_VARRUN "icmplogd.pid";
char *progname = "icmplogd";

/* logs a packet-type in human readable format */
void icmp_print (void) {
  char *sname;       /* Name of remote host */
  char *code = NULL; /* ICMP code */

  /* Get hostnames of sender */
  sname = (char *)hostlookup(pkt.ip.saddr);

  /* packet valid ? */
  if (pkt.icmp.type > 18 ||
      pkt.icmp.type == 1 || pkt.icmp.type == 2 ||
      pkt.icmp.type == 6 || pkt.icmp.type == 7 ||
      pkt.icmp.type == 9 || pkt.icmp.type == 10) {
    syslog (LOG_PRIORITY,
	    "unknown icmp packet (type: %d, code %d) from %s",
	    pkt.icmp.type, pkt.icmp.code, sname);
  }
  else {

    /* ICMP types without codes */
    if (pkt.icmp.type == 0  || pkt.icmp.type == 4  || pkt.icmp.type == 8 ||
	((pkt.icmp.type >= 12) && (pkt.icmp.type <= 18))) {
      syslog (LOG_PRIORITY, "icmp_%s from %s",
	      messages[pkt.icmp.type], sname);
    }

    /* ok, we also have to print the ICMP code */
    else {
      if (pkt.icmp.type == 3) {
	code = unreach_messages[pkt.icmp.code];
      }
      else if (pkt.icmp.type == 5) {
	code = redirect_messages[pkt.icmp.code];
      }
      else { /* pkt.icmp.type == 11 */
	code = time_exceeded_messages[pkt.icmp.code];
      }
      syslog (LOG_PRIORITY, "icmp_%s (code icmp_%s), from %s",
	      messages[pkt.icmp.type], code, sname);
    }
  }
  if (sname) free(sname);
}

/* infinite loop, reading from the raw socket */
void icmp_log (void) {
  int sock;
  struct protoent *pe;

  /* Do we know about icmp ? */
  pe = (struct protoent *)getprotobyname ("icmp");
  if (pe == NULL) {
    fprintf (stderr, "unknown protocol 'icmp'\n");
    terminate_daemon();
  }

  /* open the socket */
  sock = socket(AF_INET, SOCK_RAW, pe->p_proto);

  /* do the work */
  while (1) {
    /* We're only interested in Headers, so read
       just one ip header and one icmp header */
    read(sock, (struct ippkt *) &pkt, sizeof (struct ippkt));
    icmp_print ();
  }
}

/* guess what ;-) */
int main(void) {

  /* run as a daemon */
  daemonize();

  /* Go into infinite loop */
  icmp_log();

  /* We shouldn't reach this -> error */
  terminate_daemon();
  exit (1);
}
