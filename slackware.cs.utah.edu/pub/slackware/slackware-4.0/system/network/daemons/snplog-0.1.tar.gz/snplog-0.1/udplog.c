/* udplog.c - simple udp logging */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <syslog.h>
#include <errno.h>
#include <paths.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include "pidfile.h"
#include "udplog.h"
#include "util.h"

char *pidfile = _PATH_VARRUN "udplogd.pid";
char *progname = "udplogd";

/* logs packet-type in human readable format */
void udp_print (void) {
  char *rname = NULL; /* Name of the remote host */
  struct in_addr in;
  
  /* Don't log packets to syslog (514/udp) to syslog */
  if (ntohs(pkt.udp.dest) != 514) {

    /* get hostname of sender, dont't lookup domain packets,
       just write an ip address for them */
    if (ntohs(pkt.udp.source) == 53) {
      in.s_addr = pkt.ip.saddr;
      syslog (LOG_PRIORITY, "%s connection from %s:%d",
	      servlookup (pkt.udp.dest),
	      (char *)inet_ntoa(in), ntohs(pkt.udp.source));
    }

    /* Log with hostlookup */
    else {
      rname = (char *)hostlookup(pkt.ip.saddr);
      syslog (LOG_PRIORITY, "%s connection from %s:%d",
	      servlookup (pkt.udp.dest),
	      rname, ntohs(pkt.udp.source));
      if (rname) free (rname);
    }
  }
}

/* infinite loop, reading from the socket */
void udp_log (void) {
  int sock;
  struct protoent *pe;

  /* do we know udp ? */
  pe = (struct protoent *)getprotobyname ("udp");
  if (pe == NULL) {
    fprintf (stderr, "unknown protocol 'udp'\n");
    terminate_daemon();
  }

  /* open socket */
  sock = socket (AF_INET, SOCK_RAW, pe->p_proto);

  while (1) {
    /* We're only interested in headers, so read
       just one ip and one udp header */
    read (sock, (struct ippkt *) &pkt,  sizeof (struct ippkt));
    udp_print();
  }
}

/* guess what ;-) */
int main(void) {

  /* run as a daemon */
  daemonize();

  /* Go into infinite loop */
  udp_log();

  /* We shouldn't reach this -> error */
  terminate_daemon();
  exit(1);
}
