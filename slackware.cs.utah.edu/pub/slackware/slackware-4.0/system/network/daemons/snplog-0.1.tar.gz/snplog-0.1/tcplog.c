/* tcplog.c - simple tcp logging */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <syslog.h>
#include <errno.h>
#include <paths.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <netinet/ip.h>
#ifdef __GLIBC__
#include <netinet/tcp.h>
#else
#include <linux/tcp.h>
#endif
#include <signal.h>
#include "pidfile.h"
#include "rfc1413.h"
#include "tcplog.h"
#include "util.h"

char *pidfile = _PATH_VARRUN "tcplogd.pid";
char *progname = "tcplogd";

/* logs packet-type in human readable format */
void tcp_print (void) {
  char *rname;        /* Name of remote host */

#ifdef IDENT
  char *ruser = NULL; /* Name of remote user (from auth) */
#endif

  /* get hostname of sender */
  rname = (char *)hostlookup(pkt.ip.saddr);

  /* ignore ftp-data connections */
  if (ntohs(pkt.tcp.source) != 20) {

#ifdef IDENT
    /* don't man an auth connect for an auth connect
       to avoid 'auth wars' */
    if (ntohs(pkt.tcp.dest) != 113) {
      ruser = (char *)get_rfc1413_data (ntohs(pkt.tcp.source),
					ntohs(pkt.tcp.dest),
					pkt.ip.saddr,
					pkt.ip.daddr);
    }
    if (ruser) {
      syslog (LOG_PRIORITY, "%s connection from %s@%s:%d",
	      servlookup (pkt.tcp.dest),
	      ruser, rname, ntohs(pkt.tcp.source));
      free (ruser);
    }
    else {
#endif

      syslog (LOG_PRIORITY, "%s connection from %s:%d",
	      servlookup (pkt.tcp.dest),
	      rname, ntohs(pkt.tcp.source));

#ifdef IDENT
    }
#endif

  }
  if (rname) free (rname);
}

/* infinite loop, reading from the socket */
void tcp_log (void) {
  int sock;
  struct protoent *pe;
#ifdef IDENT
  int status;
#endif

  /* do we know tcp ? */
  pe = (struct protoent *)getprotobyname ("tcp");
  if (pe == NULL) {
    fprintf (stderr, "unknown protocol 'tcp'\n");
    terminate_daemon();
  }

  /* open socket */
  sock = socket (AF_INET, SOCK_RAW, pe->p_proto);

  /* Loop infinitely */
  while (1) {

    /* We're only interested in headers, so read
       just one ip and one tcp header */
    read (sock, (struct ippkt *) &pkt,  sizeof (struct ippkt));

    /* Only new connections */
    if (pkt.tcp.syn == 1 && pkt.tcp.ack == 0) {

#ifdef IDENT
      /* We have to fork here; ident lookups can take time
	 and we do want to log other connects meanwhile */
      if (! fork()) { /* double fork to avoid leaving zombies */
	if (! fork()) {
#endif
	  tcp_print();

#ifdef IDENT
	  exit (0);
	}
	else exit (0);
      }
      else wait (&status);
#endif

    }
  }
}

/* guess what ;-) */
int main(void) {

  /* run as a daemon */
  daemonize();

  /* Go into infinite loop */
  tcp_log();

  /* We shouldn't reach this -> error */
  terminate_daemon();
  exit(1);
}
