/* pidfile.h - definitions and prototypes for pidfile.c */
#ifndef PIDFILE_H
#define PIDFILE_H

#include <stdio.h>
#include <sys/types.h>
#include <signal.h>

int kill (pid_t, int);
FILE *fdopen (int, const char *);

int read_pid (const char *pidfile);
int check_pid (const char *pidfile);
int write_pid (const char *pidfile);
int remove_pid (const char *pidfile);


#endif /* PIDFILE_H */
