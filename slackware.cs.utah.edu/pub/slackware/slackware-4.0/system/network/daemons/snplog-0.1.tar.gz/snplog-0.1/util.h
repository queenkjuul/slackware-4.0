/* util.h - definitions and prototypes for util.c */
#ifndef UTIL_H
#define UTIL_H

#define LOG_FACILITY LOG_DAEMON
#define LOG_PRIORITY LOG_NOTICE

extern char *pidfile;
extern char *progname;

int setreuid (uid_t, uid_t);
char *strerror(int);
int getdtablesize(void);

char *hostlookup (const unsigned long int);
char *servlookup (const unsigned short);
void stop_daemon (int);
void terminate_daemon (void);
void daemonize (void);

#endif /* UTIL_H */
