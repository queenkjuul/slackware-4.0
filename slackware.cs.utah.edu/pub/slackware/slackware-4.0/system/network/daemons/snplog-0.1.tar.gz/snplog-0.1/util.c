/* util.c - help routines for icmplog.c and tcplog.c */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <syslog.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include "pidfile.h"
#include "util.h"

/* returns an allocated string with hostname or number */
char *hostlookup (const unsigned long int in) {
  char *temp, *ret;
  struct in_addr i;
  struct hostent *he;

  i.s_addr = in;
  he = (struct hostent *)gethostbyaddr((char *) &i,
				       sizeof(struct in_addr), AF_INET);
  if (he == NULL) {
    temp = (char *)inet_ntoa(i);
    if ((ret = (char *)calloc(strlen(temp)+1, sizeof (char))) == NULL) {
      syslog (LOG_PRIORITY, "calloc failed, no hostaddress");
      return ret;
    }
    strcpy (ret, temp);
  }
  else {
    temp = (char *)he->h_name;
    if ((ret = (char *)calloc(strlen(temp)+1, sizeof (char))) == NULL) {
      syslog (LOG_PRIORITY, "calloc failed, no hostname");
      return ret;
    }
    strcpy (ret, temp);
  }

  return ret;
}

/* returns an allocated string with service name or number */
char *servlookup (const unsigned short port) {
  struct servent *se;
  char *temp = NULL, *ret;

  se = getservbyport(port, "tcp");
  if (se == NULL) {
    if ((ret = (char *)calloc(10, sizeof (char))) == NULL) {
      syslog (LOG_PRIORITY, "calloc failed, no service number");
      return ret;
    }
    sprintf (ret, "%d", ntohs(port));
  }
  else {
    temp = (char *)se->s_name;
    if ((ret = (char *)calloc(strlen(temp)+1, sizeof(char))) == NULL) {
      syslog (LOG_PRIORITY, "calloc failed, no service name");
      return ret;
    }
    strcpy (ret, temp);
  }
  return ret;
}

/* Tries to exit cleanly if SIGSEGV received */
void kill_daemon (int sig) {
  syslog (LOG_PRIORITY, "Fatal ERROR: Caught SIGSEGV, terminating. Please report this bug.");
  sleep (1);
  closelog();
  (void)remove_pid (pidfile);
  exit (1);
}

/* just calls terminate_daemon() */
void stop_daemon (int sig) {
  terminate_daemon();
  return;
}

/* closes syslog and terminates tcplogd */
void terminate_daemon (void) {
  syslog (LOG_PRIORITY, "Caught signal, daemon terminated");
  sleep (1);
  closelog();
  (void)remove_pid (pidfile);
  exit (1);
}

/* cares about cleanly running as a daemon */
void daemonize (void) {
  int ch, fo, fl;
  int num_fds = (int)getdtablesize();
  

  /* We have to be root */
  if (setreuid (0,0) == -1) {
    fprintf (stderr, "can't suid to root, %s\n", strerror(errno));
    exit(1);
  }
  chdir("/");

  /* fork now */
  if (! check_pid (pidfile)) {
    fo = fork();
    if (fo < 0) {
      fprintf (stderr, "fork failed, %s\n", strerror(errno));
      exit (1);
    }
    else if (fo > 0)
      exit (0);

    /* ok, successfully forked */
    /* close all children's file descriptors */
    for (fl = 0; fl <= num_fds; ++fl)
      close (fl);
    
    errno = 0;
    setsid();
    umask(0);
  }
  else {
    /* We're already running -> exit */
    fprintf (stderr, "%s: already running (PID: %d).\n",
	     progname, read_pid (pidfile));
    exit (1);
  }

  /* write pidfile */
  if (! check_pid (pidfile)) {
    if (! write_pid (pidfile)) {
      fprintf (stderr, "%s: can't write pidfile (%s).\n",
	       progname, pidfile);
      exit(1);
    }
  }

  /* signal setup, nothing to reinitialize for the moment, so
     just code for stopping */
  for (ch = 1; ch < _NSIG; ++ch)
    signal (ch, SIG_IGN);
  signal (SIGINT, stop_daemon);
  signal (SIGKILL, stop_daemon);
  signal (SIGTERM, stop_daemon);
  signal (SIGHUP, stop_daemon);
  signal (SIGSTOP, stop_daemon);
  signal (SIGSEGV, kill_daemon);

  /* open output */
  openlog (progname, LOG_PID, LOG_FACILITY);
  syslog (LOG_PRIORITY, "daemon started");
}
