/*
 *  udp.c - functions logging UDP datagrams
 *
 *  Copyright (C) 1998-1999 Hugo Haas
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <pthread.h>

#include "defines.h"
#include "udp.h"
#include "netutils.h"
#include "log.h"
#include "filter.h"
#include "configuration.h"
#include "ident.h"

/* Socket */
int udp_socket;

extern unsigned short resolve_protocols;

struct loginfo udp_log;

/*
 * Structure of a UDP packet
 */

struct udppacket {
  struct iphdr ip;
  struct udphdr udp;
};

/*
 * log_udppacket & threaded_log_udppacket
 *
 * Log a UDP datagram
 */

void *log_udppacket(void *pkt) {
  char service[SERVICE_LENGTH];
  struct log_info info;

  /* Host filter */
  info = do_log(((struct udppacket *) pkt)->ip.saddr,
                ((struct udppacket *) pkt)->ip.daddr,
                ((struct udppacket *) pkt)->udp.dest,
		((struct udppacket *) pkt)->udp.source, IPPROTO_UDP);
  
  if (info.log == TRUE) {
    char details[DETAILS_LENGTH];
    char remote_host[HOST_LENGTH];
    *details ='\0';
    host_print(remote_host, ((struct udppacket *) pkt)->ip.saddr,
               info.resolve);
    service_lookup("udp", service, ((struct udppacket *) pkt)->udp.dest);
    if (info.logformat == LOGFORMAT_DETAILED) {
      get_details(details,
                  ((struct udppacket*) pkt)->ip.saddr,
                  ((struct udppacket*) pkt)->udp.source,
                  ((struct udppacket*) pkt)->ip.daddr,
                  ((struct udppacket*) pkt)->udp.dest);
    }
    switch (info.logformat) {
    case LOGFORMAT_SHORT:
      udp_log.log(udp_log.level_or_fd, "UDP %s - %s",
                  service, remote_host);
      break;
    case LOGFORMAT_NORMAL:
      udp_log.log(udp_log.level_or_fd, "%s UDP datagram from %s",
                  service, remote_host);
      break;
    case LOGFORMAT_DETAILED:
      udp_log.log(udp_log.level_or_fd, "%s UDP datagram from %s%s",
                  service, remote_host, details);
      break;
    }
  }
#ifdef _MULTITHREAD_
  free(pkt);
#endif
  return NULL;
}

#ifdef _MULTITHREAD_
void threaded_log_udppacket(struct tcppacket pkt) {
  pthread_attr_t attr_t;
  pthread_t t;
  __u8 *image;

  image = (__u8 *) malloc(sizeof(struct udppacket));
  memcpy(image, &pkt, sizeof(struct udppacket));
  pthread_attr_init(&attr_t);
  pthread_attr_setdetachstate(&attr_t, PTHREAD_CREATE_DETACHED);
  pthread_create(&t, &attr_t, log_udppacket, image);
  pthread_attr_destroy(&attr_t);
}
#endif

/*
 * log_udp
 *
 * Main thread logging UDP datagrams
 *
 */

void *log_udp(void *nobody) {
  struct udppacket pkt;

  pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
  pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

  udp_socket = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
  if (udp_socket <= 0)
    exit(1);

  setuid(((struct passwd *)nobody)->pw_uid);

  for(;;) {
    if (read(udp_socket, (struct udppacket *) &pkt, sizeof(struct udppacket)) == -1)
      exit(1);

    if (pkt.ip.ihl != 5) {
#ifdef _MULTITHREAD_
      threaded_log_suspicious((struct iphdr *) &pkt);
#else
      log_suspicious((void *) &pkt);
#endif
      continue;
    }

#ifdef _MULTITHREAD_
    threaded_log_udppacket(pkt);
#else
    log_udppacket((void *) &pkt);
#endif
  }
  /*@NOTREACHED@*/ 
  return NULL;
}
