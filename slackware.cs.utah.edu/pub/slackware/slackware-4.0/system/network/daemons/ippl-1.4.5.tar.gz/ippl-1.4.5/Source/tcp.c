/*
 *  tcp.c - functions logging TCP connections
 *
 *  Copyright (C) 1998-1999 Hugo Haas
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#if (__GNU_LIBRARY__ >= 6)
#include <netinet/tcp.h>
#else
#include <linux/tcp.h>
#endif
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <pthread.h>

#include "defines.h"
#include "tcp.h"
#include "netutils.h"
#include "log.h"
#include "filter.h"
#include "configuration.h"
#include "ident.h"

/* Socket */
int tcp_socket;

struct loginfo tcp_log;
extern unsigned short resolve_protocols;

/*
 * Structure of a TCP packet
 */

struct tcppacket {
  struct iphdr ip;
  struct tcphdr tcp;
};

/*
 * log_tcp_open & threaded_log_tcp_open
 *
 * Log TCP connections opened
 */

void *log_tcp_open(void *pkt) {
  char service[SERVICE_LENGTH];
  struct log_info info;

  /* Host filter */
  info = do_log(((struct tcppacket *) pkt)->ip.saddr,
                ((struct tcppacket *) pkt)->ip.daddr,
                ((struct tcppacket *) pkt)->tcp.dest,
		((struct tcppacket *) pkt)->tcp.source, IPPROTO_TCP);
  if (info.log) {
    char details[DETAILS_LENGTH];
    char remote_host[HOST_LENGTH];
    char * username = 0;
    *details ='\0';
    host_print(remote_host, ((struct tcppacket *) pkt)->ip.saddr,
               info.resolve);
    service_lookup("tcp", service, ((struct tcppacket *) pkt)->tcp.dest);
    if (info.logformat == LOGFORMAT_DETAILED) {
      get_details(details,
                  ((struct tcppacket*) pkt)->ip.saddr,
                  ((struct tcppacket*) pkt)->tcp.source,
                  ((struct tcppacket*) pkt)->ip.daddr,
                  ((struct tcppacket*) pkt)->tcp.dest);
    }
    if (info.ident && ((struct tcppacket*) pkt)->tcp.dest != IDENT_PORT) {
      username = get_ident_info(((struct tcppacket*) pkt)->tcp.dest,
                                ((struct tcppacket*) pkt)->tcp.source,
                                ((struct tcppacket*) pkt)->ip.daddr,
                                ((struct tcppacket*) pkt)->ip.saddr);
    }
    switch (info.logformat) {
    case LOGFORMAT_SHORT:
      if (info.ident && ((struct tcppacket*) pkt)->tcp.dest != IDENT_PORT) {
        tcp_log.log(tcp_log.level_or_fd, "TCP %s - %s@%s",
                    service, username, remote_host);
        free(username);
      } else {
        tcp_log.log(tcp_log.level_or_fd, "TCP %s - %s",
                    service, remote_host);
      }
      break;
    case LOGFORMAT_NORMAL:
      if (info.ident && ((struct tcppacket*) pkt)->tcp.dest != IDENT_PORT) {
        tcp_log.log(tcp_log.level_or_fd, "%s connection attempt from %s@%s",
                    service, username, remote_host);
        free(username);
      } else {
        tcp_log.log(tcp_log.level_or_fd, "%s connection attempt from %s",
                    service, remote_host);
      }
      break;
    case LOGFORMAT_DETAILED:
      if (info.ident && ((struct tcppacket*) pkt)->tcp.dest != IDENT_PORT) {
        tcp_log.log(tcp_log.level_or_fd, "%s connection attempt from %s@%s%s",
                    service, username, remote_host, details);
        free(username);
      } else {
        tcp_log.log(tcp_log.level_or_fd, "%s connection attempt from %s%s",
                    service, remote_host, details);
      }
      break;
    }
  }
#ifdef _MULTITHREAD_
  free(pkt);
#endif
  return NULL;
}

#ifdef _MULTITHREAD_
void threaded_log_tcp_open(struct tcppacket pkt) {
  pthread_attr_t attr_t;
  pthread_t t;
  __u8 *image;

  image = (__u8 *) malloc(sizeof(struct tcppacket));
  memcpy(image, &pkt, sizeof(struct tcppacket));
  pthread_attr_init(&attr_t);
  pthread_attr_setdetachstate(&attr_t, PTHREAD_CREATE_DETACHED);
  pthread_create(&t, &attr_t, log_tcppacket, image);
  pthread_attr_destroy(&attr_t);
}
#endif

/*
 * log_tcp_close & threaded_log_tcp_close
 *
 * Log TCP connections closed
 */

void *log_tcp_close(void *pkt) {
  char service[SERVICE_LENGTH];
  struct log_info info;

  /* Host filter */
  info = do_log(((struct tcppacket *) pkt)->ip.saddr,
                ((struct tcppacket *) pkt)->ip.daddr,
                ((struct tcppacket *) pkt)->tcp.dest,
		((struct tcppacket *) pkt)->tcp.source, IPPROTO_TCP);
  if (info.log && info.logclosing) {
    char details[DETAILS_LENGTH];
    char remote_host[HOST_LENGTH];
    *details ='\0';
    host_print(remote_host, ((struct tcppacket *) pkt)->ip.saddr,
               info.resolve);
    service_lookup("tcp", service, ((struct tcppacket *) pkt)->tcp.dest);
    if (info.logformat == LOGFORMAT_DETAILED) {
      get_details(details,
                  ((struct tcppacket*) pkt)->ip.saddr,
                  ((struct tcppacket*) pkt)->tcp.source,
                  ((struct tcppacket*) pkt)->ip.daddr,
                  ((struct tcppacket*) pkt)->tcp.dest);
    }
    switch (info.logformat) {
    case LOGFORMAT_SHORT:
      tcp_log.log(tcp_log.level_or_fd, "TCP %s closed - %s", service, remote_host);
      break;
    case LOGFORMAT_NORMAL:
      tcp_log.log(tcp_log.level_or_fd, "%s connection closed from %s", service, remote_host);
      break;
    case LOGFORMAT_DETAILED:
      tcp_log.log(tcp_log.level_or_fd, "%s connection closed from %s%s", service, remote_host, details);
      break;
    }
  }
#ifdef _MULTITHREAD_
  free(pkt);
#endif
  return NULL;
}

#ifdef _MULTITHREAD_
void threaded_log_tcp_close(struct tcppacket pkt) {
  pthread_attr_t attr_t;
  pthread_t t;
  __u8 *image;

  image = (__u8 *) malloc(sizeof(struct tcppacket));
  memcpy(image, &pkt, sizeof(struct tcppacket));
  pthread_attr_init(&attr_t);
  pthread_attr_setdetachstate(&attr_t, PTHREAD_CREATE_DETACHED);
  pthread_create(&t, &attr_t, log_tcppacket, image);
  pthread_attr_destroy(&attr_t);
}
#endif

/*
 * log_tcp
 *
 * Main thread logging TCP connections
 *
 */

void *log_tcp(void *nobody) {
  struct tcppacket pkt;
  sigset_t newmask;

  sigemptyset(&newmask);
  sigaddset(&newmask, SIGALRM);
  pthread_sigmask(SIG_UNBLOCK, &newmask, NULL);

  pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
  pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

  tcp_socket = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
  if (tcp_socket <= 0)
    exit(1);

  setuid(((struct passwd *)nobody)->pw_uid);

  for(;;) {
    if (read(tcp_socket, (struct tcppacket *) &pkt, sizeof(struct tcppacket)) == -1)
      exit(1);

    if (pkt.ip.ihl != 5) {
#ifdef _MULTITHREAD_
      threaded_log_suspicious((struct iphdr *) &pkt);
#else
      log_suspicious((void *) &pkt);
#endif
      continue;
    }

    if (pkt.tcp.syn == 1 && pkt.tcp.ack == 0) {
#ifdef _MULTITHREAD_
      threaded_log_tcp_open(pkt);
#else
      log_tcp_open((void *) &pkt);
#endif
      continue;
    }

    if (pkt.tcp.fin == 1) {
#ifdef _MULTITHREAD_
      threaded_log_tcp_close(pkt);
#else
      log_tcp_close((void *) &pkt);
#endif
      continue;
    }
  }
  /*@NOTREACHED@*/ 
  return NULL;
}
