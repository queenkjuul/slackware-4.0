/*=================================================================
FILE: conf.c

DESCRIPTION:
   configuration file routines.

AUTHOR:
   Tom Hendrick <thendri1@san.rr.com>
=================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <netdb.h>

#include "conf.h"

/*=================================================================
GLOBAL DATA DECLARATIONS
=================================================================*/
const struct Taglist taglist[] =
{
  { "interface", read_interface_line },
  { "router",    read_router_line },
  { "port",      read_port_line },
  { "\0",        NULL }
};

/*=================================================================
FUNCTION: void read_router_line

DESCRIPTION:
   Takes a non-comment line from the configuration file and parses
   it into tokens.
=================================================================*/
void read_router_line( struct Config *list, int lineno )
{
  struct hostent  *hostentry;
  struct Router   *ptr;
  /* Split the line into tokens */
  char *host;
  char *port_udp;
  char *port_tcp;
  /* A string for the delimiting chars */
  char *delimiters = " \t\n";

  /* Now, we step through the tokens, split by whitespace */
  host     = strtok( NULL, delimiters );
  port_udp = strtok( NULL, delimiters );
  port_tcp = strtok( NULL, delimiters );
  
  /* Error checking */
  if( host == NULL )
    {
      /* There was an error getting the name/address */
      fprintf( stderr, " [CONFIG-READ-ERROR: No host name/address  given on line %d, skipping]\n",
	      lineno );
      return;
    }
  /* Error-checking */
  if( port_udp == NULL )
    {
      /* There was an error getting the remote port */
      fprintf( stderr, " [CONFIG-READ-ERROR: No remote UDP port on line %d]\n",
	      lineno );
      return;
    }
  /* Error-checking */
  if( port_tcp == NULL )
    {
      /* There was an error getting the remote port */
      fprintf( stderr, " [CONFIG-READ-ERROR: No remote TCP port on line %d]\n",
	      lineno );
      return;
    }
  
  /* Allocate a new router entry */
  ptr = (struct Router *)malloc( sizeof( struct Router ) );
  /* Blank the memory */
  memset( ptr, '\0', sizeof( struct Router ) );
  /* Do some sanity-initializtions */
  strncpy( ptr->rtr_hostname, host, MAX_LINE );
  
  ptr->rtr_addr.sin_family = AF_INET;
  ptr->rtr_tcp_sock_fd_in  = -1;
  ptr->rtr_tcp_sock_fd_out = -1;
  ptr->rtr_next = NULL;
  
  /* Get the host address entry by name */
  hostentry = gethostbyname( host );
  /* Make sure we got the host by name */
  if( hostentry == NULL )
    {
      /* Error */
      fprintf( stderr, " [CONFIG-READ-ERROR: Unable to gethostbyname( %s ) : %s]\n",
	      host, strerror( errno ) );
      free( ptr );
      return;
    }

  /* Put the first address into the structure */
  memcpy( &(ptr->rtr_addr.sin_addr.s_addr),
	  hostentry->h_addr,
	  hostentry->h_length );
  /* See if we can find the port number to use */
  if( ( ptr->rtr_udp_port = atoi( port_udp ) ) < 0 )
    {
      /* Failure to convert port number */
      fprintf( stderr, " [CONFIG-READ-ERROR: Unable to use UDP port %d]\n",
	      ptr->rtr_udp_port );
      /* Free the memory currently allocated */
      free( ptr );
      
      return;
    }
  /* See if we can find the port number to use */
  if( ( ptr->rtr_tcp_port = atoi( port_tcp ) ) < 0 )
    {
      /* Failure to convert port number */
      fprintf( stderr, " [CONFIG-READ-ERROR: Unable to use TCP port %d]\n",
	      ptr->rtr_tcp_port );
      /* Free the memory currently allocated */
      free( ptr );
      
      return;
    }
  /* Success, print out the host information */
  fprintf( stdout, " [CONFIG-READ: Found host %s{%s}:%d,%d]\n",
          ptr->rtr_hostname,
          inet_ntoa( ptr->rtr_addr.sin_addr ),
          ptr->rtr_udp_port,
	  ptr->rtr_tcp_port);
  /* Now, add this router to the end of the list */
  if( list->cfg_routers != NULL )
    {
      /* Find the end of the list */
      struct Router *endptr;
      for( endptr = list->cfg_routers;
	   endptr->rtr_next != NULL;
	   endptr = endptr->rtr_next );
      /* Add to the end */
      endptr->rtr_next = ptr;
    }
  else
    {
      /* No elements in this list, start one */
      list->cfg_routers = ptr;
    }

  /* Return */
  return; 
}


/*=================================================================
FUNCTION: read_interface_line

DESCRIPTION:
   Splits a line from the configuration file into tokens and reads
   them in.  It then adds this interface to the interface list in
   list.  If no interface list exists, this function creates one.

ARGUMENTS:
   struct Config * - the configuration structure to add elements to
   int lineno      - the current line number.
=================================================================*/
void read_interface_line( struct Config *list, int lineno )
{
  /* We are looking for one argument here */
  char *arg;
  struct Ether *ptr;
  struct Ether *endptr;
  
  if( list->cfg_interfaces != NULL )
    {
      /* Assign the end ptr */
      for(endptr=list->cfg_interfaces;
	  endptr->eth_next;
	  endptr=endptr->eth_next);
    }

  /* Grab the argument from strtok */
  while( ( arg = strtok( NULL, "\t\n, " ) ) != NULL )
    {
      /* Allocate a new element */
      ptr = ( struct Ether * )malloc( sizeof( struct Ether ) );
      /* Blank the element */
      memset( ptr, '\0', sizeof( struct Ether ) );
      /* Assign the sock fd */
      ptr->eth_sock_fd = -1;
      /* Copy the device name */
      strncpy( ptr->eth_device_name, arg, IFNAMSIZ );
      /* Add this to the list */
      if( list->cfg_interfaces == NULL )
	{
	  /* No list, create one */
	  list->cfg_interfaces = ptr;
	  /* Assign the endptr */
	  endptr = ptr;
	}
      else
	{
	  /* The endptr is the end of the list */
	  endptr->eth_next = ptr;
	  /* Increment endptr */
	  endptr = endptr->eth_next;
	}
    }
  /* Finished */
  return;
}

/*=================================================================
FUNCTION: read_port_line( struct Config list, int lineno )

DESCRIPTION:
   Reads and parses the line containing the udp and tcp ports on
   which we listen.

ARGUMENTS:
   struct Config - the current configuration
   int           - the current line number
=================================================================*/
void read_port_line( struct Config *list, int lineno )
{
  /* We are looking for two required arguments */
  char *tcp_port;
  char *udp_port;

  /* Grab the tokens */
  udp_port = strtok( NULL, "\t\n, " );
  tcp_port = strtok( NULL, "\t\n, " );

  /* Error-check */
  if( udp_port == NULL )
    {
      /* Print an error message */
      fprintf( stderr, " [CONFIG-READ-ERROR: UDP port not specified on line %d]\n",
	      lineno);
      return;
    }
  /* Error-check */
  if( tcp_port == NULL )
    {
      fprintf( stderr, " [CONFIG-READ-ERROR: TCP port not specified on line %d]\n",
	      lineno);
      return;
    }

  /* Attempt to convert the port numbers */
  if( ( list->cfg_udp_port = atoi( udp_port ) ) < 0 )
    {
      /* Error */
      fprintf( stderr, " [CONFIG-READ-ERROR: UDP port %s unusable\n",
	      udp_port );
      return;
    }

  /* Attempt to convert port number */
  if( ( list->cfg_tcp_port = atoi( tcp_port ) ) < 0 )
    {
      /* Error */
      fprintf( stderr, " [CONFIG-READ-ERROR: TCP port %s unusable\n",
	      tcp_port );
      return;
    }
}

/*=================================================================
FUNCTION: ensure_defaults

DESCRIPTION:
   This is an after-the-fact check of the configuration struct to
   ensure that optional parameters have values if they were not
   specified.

ARGUMENTS:
   struct Config * - the configuration to be checked
=================================================================*/
void ensure_defaults( struct Config *config )
{
  /* Ensure there is at least one ethernet device */
  if( config->cfg_interfaces == NULL )
    {
      /* Inform the user */
      fprintf( stdout," [CONFIG-READ: no interfaces specified, using eth0]\n");
      /* Assign the default value */
      config->cfg_interfaces =
	( struct Ether * )malloc( sizeof( struct Ether ) );
      /* Make sure the memory is in a sane state */
      memset( config->cfg_interfaces, '\0', sizeof( struct Ether ) );
      /* copy the device name */
      strncpy( config->cfg_interfaces->eth_device_name, "eth0", IFNAMSIZ );
      /* Clear the socket fd */
      config->cfg_interfaces->eth_sock_fd = -1;
    }
  /* Ensure the port values are set to something */
  if( config->cfg_udp_port <= 0 )
    {
      /* Inform the user */
      fprintf( stdout, " [CONFIG-READ: no udp port found, using default 7777]\n" );
      /* Assign the port number */
      config->cfg_udp_port = 7777;
    }
  /* Ensure the port values are set to something */
  if( config->cfg_tcp_port <= 0 )
    {
      /* Inform the user */
      fprintf( stdout," [CONFIG-READ: no tcp port found, using default 7778]\n" );
      /* Assign the port number */
      config->cfg_udp_port = 7778;
    }
  /* Clear the socket file descriptors */
  config->cfg_tcp_sock_fd = -1;
  config->cfg_udp_sock_fd = -1;
}

/*=================================================================
FUNCTION: struct Config* read_config_file( char *fname );

DESCRIPTION:
   Reads and parses a configuration file, looking for tags and
   calls the appropriate function to parse the given line.  It
   returns NULL if it cannot open the file, otherwise it returns
   a configuration structure.
=================================================================*/
struct Config* read_config_file( char *fname )
{
  /* Declare some pointer vars for the configuration */
  struct Config* list;
  FILE *ipf;
  char *line;
  char *ptr;
  int lineno = 1;
  
  /* Start the task */
  fprintf( stdout, "[CONFIG-READ: Reading configuration file %s]\n", fname );

  /* Attempt to open the file */
  if( ( ipf = fopen( fname, "r+" ) ) == NULL )
    {
      /* Error, bail out */
      fprintf( stderr, " [CONFIG-READ-ERROR: Error opening configuration file->%s]\n",
	      strerror( errno ) );
      /* Exit, no clean-up necessary right now */
      exit ( 1 );
    }
  /* Message */
  fprintf( stdout, " [CONFIG-READ: File opened successfully]\n" );

  /* Allocate a new Config pointer */
  list = ( struct Config * )malloc( sizeof( struct Config ) );
  /* Zero the struct */
  memset( list, '\0', sizeof( struct Config ) );
  /* Check for errors */
  if( list == NULL )
    {
      fprintf( stderr, " [CONFIG-READ-ERROR: Error allocating memory->%s]\n",
	      strerror( errno ) );
      /* Bail out */
      exit( 1 );
    }
  
  /* Now, keep reading lines */
  do
    {
      /* Allocate a new line */
      line = (char *)malloc( MAX_LINE );
      /* Zero the line */
      memset( line, 0, MAX_LINE );
      /* Read a line from the file */
      fgets( line, MAX_LINE, ipf );
      /* Double-check feof, because it is funny sometimes */
      if( feof( ipf ) ) break;
      /* If the line starts with a '#' treat it as a comment */
      if( line[0] == '#' )
	{
	  /* De-allocate the line */
	  free( line );
	}
      /* Otherwise, split the line into tokens */
      else
	{
	  /* Grab the command */
	  ptr = strtok( line, "\t\n " );
	  /* Make sure there wasn't an error */
	  if( ptr != NULL )
	    {
	      /* Loop through the taglist */
	      int i = 0;
	      while( taglist[i].tl_parse_function != NULL )
		{
		  /* Is this the tag? */
		  if( strcmp( taglist[i].tl_tag, ptr ) == 0 )
		    {
		      /* Parse this line */
		      taglist[i].tl_parse_function( list, lineno );
		      /* Break from the loop */
		      break;
		    }
		  i++;
		}
	    }
	}
      /* Increment the line number */
      lineno++;
    } while( !feof( ipf ) );
   /* Task complete */
   fprintf( stdout, "[CONFIG-READ: Task Complete]\n" );
   /* Return the pointer to the list */
   return list;
}

/*=================================================================
CVS Log

  $Log: conf.c,v $
  Revision 1.3  1998/11/16 03:13:04  thomash
  tipxd.8
     Created manpage for tipxd
  Makefile
     Made minor change to clean man directory of emacs backup files
  include/util.h src/util.c
     Updated comments
  src/main.c src/net.c src/signal.c src/udp_com.c
     Updated to use better logging and to use fprintf instead of printf
  src/main.c
     Updated and added -e, -d, -h, and -H command-line switches.  Added code
     to run as daemon open logfiles and dup2 file descriptors.


=================================================================*/
