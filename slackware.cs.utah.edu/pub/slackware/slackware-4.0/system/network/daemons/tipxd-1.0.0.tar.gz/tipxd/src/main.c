/*=================================================================
FILE: main.c

DESCRIPTION:
   main executable portion of this program.

AUTHOR:
   Tom Hendrick <thendri1@san.rr.com>
=================================================================*/

/*-----------------------------------------------------------------
PREPROCESSOR INCLUDES
-----------------------------------------------------------------*/
#include <stdio.h>      /* Standard I/O */
#include <stdlib.h>     /* Standard Library */
#include <errno.h>      /* Error number and related */
#include <sys/time.h>   /* System time values */
#include <sys/types.h>  /* System data types */
#include <sys/stat.h>   /* File statistics */
#include <unistd.h>     /* Command-line options */
#include <fcntl.h>      /* FD-based file-control */

#include "ipxtunnel.h"    /* Host table structures and routines */
#include "conf.h"
#include "net.h"
#include "sig.h"
#include "register.h"
#include "udp_com.h"

/*-----------------------------------------------------------------
FUNCTION PROTOTYPE LIST
-----------------------------------------------------------------*/
int  main( int argc, char *argv[] );
void printVersion( );
void printUsage( );

/*-----------------------------------------------------------------
GLOBAL VARIABLES (yuk!) LIST
-----------------------------------------------------------------*/
struct Config *configuration;

static char *default_config_fname = "ipxtunnel.conf";

/*-----------------------------------------------------------------
FUNCTION: main

ARGUMENTS:
   int argc     - argument count
   char *argv[] - argument list

RETURN VALUE:
   (int)
-----------------------------------------------------------------*/
int main( int argc, char *argv[] )
{
  int  run_as_daemon = 0;
  char c;
  char *cfg_fname = NULL;
  char *log_fname = NULL;
  char *err_fname = NULL;
  struct Ether   *ether_ptr;
  struct Router *router_ptr;
  
  /* Print Version information */
  printVersion( );
  /* Initialize sockets to not-open */

  /* Parse out the command-line options */
  fprintf( stdout, "[COM-LINE: Processing command-line]\n" );
  /* Loop through with getopt */
  while( ( c = getopt( argc, argv, "de:f:l:i:hH" ) ) != -1 )
    {
      switch( c )
	{
	  /* Specified a differnt configuration file on
	     to use */
	case 'f':
	  {
	    /* Print the config file name */
	    fprintf( stdout, " [COM-LINE: Using config filename \"%s\"]\n", optarg );
	    /* Store the filename */
	    cfg_fname = optarg;
	  } break;
	case 'l':
	  {
	    /* Print the config file name */
	    fprintf( stdout, " [COM-LINE: Using log filename \"%s\"]\n", optarg );
	    /* Store the filename */
	    log_fname = optarg;
	  } break;
	case 'e':
	  {
	    /* Print the config file name */
	    fprintf( stdout, " [COM-LINE: Using log filename \"%s\"]\n", optarg );
	    /* Store the filename */
	    err_fname = optarg;
	  } break;
	case 'd':
	  {
	    /* Set up to run as a daemon */
	    fprintf( stdout, " [COM-LINE: running as deamon]\n" );
	    run_as_daemon++;
	  } break;
	case 'h':
	case 'H':
	default:
	  {
	    /* print the usage information and exit */
	    printUsage( );
	    /* Exit */
	    exit( 0 );
	  } break;
	}
    }
  /* See what we came up with */
  if( cfg_fname == NULL )
    {
      /* Warn the user */
      fprintf( stderr, " [COM-LINE-WARN: Using default config-file name: \"%s\"]\n",
	      default_config_fname );
      /* Assign the variable */
      cfg_fname = default_config_fname;
    }
  /* See if logging will be disabled */
  if( log_fname == NULL )
    {
      /* Warn the user */
      fprintf(stderr, " [COM-LINE-WARN: No log filename, using stdout]\n");
    }
  else
    {
      /* Attempt to open the file */
      int fd = open( log_fname, O_RDWR | O_CREAT,
		     S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH );
      /* Check for errors */
      if( fd < 0 )
	{
	  fprintf( stderr, " [COM-LINE-ERR: Unable to open logfile %s : %s\n",
		   log_fname, strerror( errno ) );
	}
      else
	{
	  /* dup the stdout to the logfile */
	  dup2( fd, STDOUT_FILENO );
	}
    }

  /* See if logging will be disabled */
  if( err_fname == NULL )
    {
      /* Warn the user */
      fprintf( stderr, " [COM-LINE-WARN: No error filename, using stderr]\n");
    }
  else
    {
      /* Attempt to open the file */
      int fd = open( err_fname, O_RDWR | O_CREAT,
		     S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH );
      /* Check for errors */
      if( fd < 0 )
	{
	  fprintf( stderr, " [COM-LINE-ERR: Unable to open logfile %s : %s\n",
		   err_fname, strerror( errno ) );
	}
      else
	{
	  /* dup the stderr to the logfile */
	  dup2( fd, STDERR_FILENO );
	}      
    }

  printf( "[COM-LINE: Task Complete]\n" );
  /* Attempt to read the config file */
  configuration = read_config_file( cfg_fname );
  
  /* Make sure we don't go on and seg-fault */
  if( configuration == NULL )
    {
      exit( 1 );
    }

  /* See if we need to run as a daemon */
  if( run_as_daemon > 0 )
    {
      /* Here is the trick, fork to a child */
      if( fork( ) == 0 )
	{
	  /* Set the process group */
	  setpgrp( );
	}
      else
	{
	  /* This will be the parent */
	  exit( 0 );
	}
    }
  
  /* Attempt to open the ipx 802.3 socket(s) */ 
  for( ether_ptr = configuration->cfg_interfaces;
       ether_ptr != NULL;
       ether_ptr = ether_ptr->eth_next )
    {
      /* Attempt to open the 802.3 socket */
      open_ipx_802_3_socket( ether_ptr );
      /* Attempt to set up the interface for promiscuous mode */
      set_if_promisc_mode( ether_ptr ); 
    }

  /* Establish a signal handler */
  printf( "[SIGNAL-INSTALL: Installing signal handlers]\n" );
  /* Install the handler function */ 
  signal( SIGINT, sig_int );
  printf( " [SIGNAL-INSTALL: installed handler for SIG-INT]\n" );
  /* Complete the task */
  printf( "[SIGNAL-INSTALL: Task complete]\n" );

  /* Attempt to open the TCP listening socket */
  open_tcp_listening_socket( configuration );

  /* Attempt to open the UDP control socket */
  open_udp_control_socket( configuration );

  /* Start main loop */
  printf( "[APP-MAIN-LOOP: Starting application main-loop]\n" );
  for( ; ; )
  {
     fd_set read_fds;
     int sel_val;
     int max;
     
     struct timeval select_timeout;
     select_timeout.tv_sec = 1;
     select_timeout.tv_usec = 0;
 
     /* Launch the remote connect broadcasts */
     broadcast_udp_connect( configuration );

     /* Clear the fd_set */
     FD_ZERO( &read_fds );
     /* Reset max */
     max = 0;

     /* Add the UDP/TCP sockets to the fd_set */
     FD_SET( configuration->cfg_udp_sock_fd, &read_fds );
     max = configuration->cfg_udp_sock_fd;

     FD_SET( configuration->cfg_tcp_sock_fd, &read_fds );
     /* Update Max */
     if( configuration->cfg_tcp_sock_fd > max )
       {
	 max = configuration->cfg_tcp_sock_fd;
       }

     /* Add all the 802.3 sockets to the fd_set */
     for( ether_ptr = configuration->cfg_interfaces;
	  ether_ptr != NULL;
	  ether_ptr = ether_ptr->eth_next )
       {
	 /* Add the FD to the set and update max */
	 FD_SET( ether_ptr->eth_sock_fd, &read_fds );
	 /* Update Max */
	 if( max < ether_ptr->eth_sock_fd )
	   max = ether_ptr->eth_sock_fd;
       }

     /* Add all the router TCP-IN sockets to the fd_set */
     for( router_ptr = configuration->cfg_routers;
	  router_ptr != NULL;
	  router_ptr = router_ptr->rtr_next )
       {
	 if( router_ptr->rtr_tcp_sock_fd_in > 0 )
	   {
	     /* Add the FD to the set and update max */
	     FD_SET( router_ptr->rtr_tcp_sock_fd_in, &read_fds );
	     /* Update Max */
	     if( max < router_ptr->rtr_tcp_sock_fd_in )
	       max = router_ptr->rtr_tcp_sock_fd_in;
	   }
       }

     /* Select on the file descriptors */
     sel_val = select( max + 1 , &read_fds, NULL, NULL, &select_timeout );
     /* Make sure there was activity */
     if( sel_val > 0 )
       {
	 /* Check the UDP command socket */
	 if( FD_ISSET( configuration->cfg_udp_sock_fd, &read_fds ) )
	   {
	     /* Attempt to receive the command */
	     recv_udp_command( configuration );
	   }
	 /* Check the TCP listening socket */
	 if( FD_ISSET( configuration->cfg_tcp_sock_fd, &read_fds ) )
	   {
	     /* Accept the connection */
	     accept_tcp_connection( configuration );
	   }
	 /* Loop through the interface list */
	 for( ether_ptr = configuration->cfg_interfaces;
	      ether_ptr != NULL;
	      ether_ptr = ether_ptr->eth_next )
	   {
	     /* Don't attempt to test if socket not open */
	     if( ether_ptr->eth_sock_fd > 0 )
	       {
		 if( FD_ISSET( ether_ptr->eth_sock_fd, &read_fds ) )
		   {
		     /* Read the packet */
		     recv_ipx_packet( configuration, ether_ptr );
		   }
	       }
	   }
	 /* Loop through the interface list */
	 for( router_ptr = configuration->cfg_routers;
	      router_ptr != NULL;
	      router_ptr = router_ptr->rtr_next )
	   {
	     if( router_ptr->rtr_tcp_sock_fd_in > 0 )
	       {
		 if( FD_ISSET( router_ptr->rtr_tcp_sock_fd_in, &read_fds ) )
		   {
		     /* Read the packet */
		     recv_tcp_packet( configuration, router_ptr );
		   }
	       }
	   }
       }
  }
}

/*-----------------------------------------------------------------
FUNCTION: printVersion

DESCRIPTION:
   A simple encapsulation for version string.  IF YOU PATCH THIS
   SOFTWARE, PLEASE NOTE YOUR CHANGES IN THE LOG, AND UPDATE THIS
   VERSION STRING.
-----------------------------------------------------------------*/
void printVersion( )
{
  static char *versionString = "1.0.0";
  /* Print the version string */
  printf( "[tipxd v%s]\n", versionString );
}

/*-----------------------------------------------------------------
FUNCTION: printUsage

DESCRIPTION:
   prints the usage information of this program.  This can be the
   result of providing the -[hH] option, or by providing an option
   the program does not recognize.
-----------------------------------------------------------------*/
void printUsage( )
{
   printf( "Usage:\n" );
   printf( " tipxd [-d] [-f conffile] [-l logfile] [-e errlog]\n" );
   printf( " tipxd [-h | -H]\n" );
   printf( "  -h          : print usage information and exit\n" );
   printf( "  -H          : print usage information and exit\n" );
   printf( "  -d          : run as a daemon\n" );
   printf( "  -f conffile : use configuration file <conffile>\n" );
   printf( "  -l logfile  : use logfile <logfile>  - default stdout\n" );
   printf( "  -e errlog   : use error log <errlog> - default stderr\n" );
   printf( "\n" );
   return;
}
