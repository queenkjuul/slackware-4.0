/*=================================================================
FILE: util.c

DESCRIPTION:
   Prototypes for several utilities.  These are used mostly to
   print out packets and addresses in special formats.

PUBLIC FUNCTIONS:
   void print_ether_address( char * );
   void print_ipx_packet( char * );

AUTHOR:
   Tom Hendrick
=================================================================*/
#include "util.h"

/*=================================================================
FUNCTION: print_ether_address

DESCRIPTION:
   Prints to stdout the an ethernet address.

ARGUMENTS:
   char * - the array containing the hw address

RETURN TYPE:
   char * - a string version of the hw_address 
=================================================================*/
char *print_ether_address( unsigned char *addr )
{
  static char buf[19];
  
  /* This is a little sprintf */
  snprintf( buf, 18, "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X",
	    addr[0], addr[1], addr[2],
	    addr[3], addr[4], addr[5] );
  /* Return the string */
  return buf;
}
