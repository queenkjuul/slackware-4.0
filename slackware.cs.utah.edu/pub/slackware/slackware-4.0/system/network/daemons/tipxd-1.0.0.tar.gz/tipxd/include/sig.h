/*=================================================================
FILE: sig.h

DESCRIPTION:
   Header file for signal-oriented routines.  Outlines function
   prototypes and preprocessor includes.

PUBLIC FUNCTIONS:
   extern void sig_int( int ); 

AUTHOR:
   Tom Hendrick
=================================================================*/
#ifndef _SIGNAL_H_
#define _SIGNAL_H_

/*=================================================================
PREPROCESSOR INCLUDES
=================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>

#include "ipxtunnel.h"
#include "udp_com.h"
#include "net.h"

/*=================================================================
PUBLIC FUNCTION PROTOTYPES
=================================================================*/
extern void sig_int( int signo );


#endif /* _SIG_H_ */
