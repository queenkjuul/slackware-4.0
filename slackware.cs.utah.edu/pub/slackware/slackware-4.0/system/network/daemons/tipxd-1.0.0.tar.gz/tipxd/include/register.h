/*=================================================================
FILE: register.h

DESCRIPTION:
   Contains function prototypes and data structure types for peer
   registration.  As each packet comes in, the peer is compared
   with is_peer_registered.  If the hw address is not currently
   registered, then register_peer is used to register the hw
   address.  Also, if the packet was received via TCP from the
   remote host, the hw_addr is PEER_REMOTE, so all packets received
   from the peer on the local socket will be assumed to be traffic
   from the remote site and will not be re-sent to the remote
   ipxtunnel.  If the packet is received on the local socket, then
   the hw address is PEER_LOCAL, and all traffic received from this
   peer will be re-broadcast to all remote ipxtunnels.

PUBLIC FUNCTIONS:
   int is_peer_registered( struct Peer *, char *hw_addr );
   void register_peer( struct Peer *, char *hw_addr, int loc );

AUTHOR:
   Tom Hendrick
=================================================================*/
#ifndef _REGISTER_H_
#define _REGISTER_H_

/*=================================================================
PREPROCESSOR INCLUDES
=================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ipxtunnel.h"
#include "util.h"

#define HW_ADDR_LEN  6

/*=================================================================
PUBLIC FUNCTION PROTOTYPES
=================================================================*/
extern struct Peer *get_peer_registration( struct Peer *, unsigned char *);
extern struct Peer *register_peer_local ( struct Peer *,
					  unsigned char *,
					  struct Ether * );
extern struct Peer *register_peer_remote( struct Peer *,
					  unsigned char *,
					  struct Router * );

#endif /* _REGISTER_H_ */
