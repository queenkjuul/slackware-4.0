/*=================================================================
FILE: udp_com.h

DESCRIPTION:
   This file contains the function prototypes and data structure
   use with the UDP control socket.

PUBLIC DATA TYPES
   struct UDP_ConnectCmd
   struct UDP_DisconnectCmd
   struct UDP_Command

PUBLIC FUNCTION PROTOTYPES
   void broadcast_udp_connect( struct Config * );
   void broadcast_udp_disconnect( struct Config * );
   void send_udp_connect( struct Ether * );
   void send_udp_disconnect( struct Ether * );
=================================================================*/
#ifndef _UDP_COM_H_
#define _UDP_COM_H_

/*=================================================================
PREPROCESSOR INCLUDES AND DEFINES
=================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "ipxtunnel.h"

/*=================================================================
PUBLIC DATA STRUCTURES
=================================================================*/
#define UDP_COMCONNECT     0x0001
#define UDP_COMDISCONNECT  0x0002


struct UDP_Command
{
  int   uc_comm_type;
  short uc_tcp_port;
};

/*=================================================================
PUBLIC FUNCTION PROTOTYPES
=================================================================*/
extern void broadcast_udp_connect( struct Config * );
extern void broadcast_udp_disconnect( struct Config * );
extern void send_udp_connect( struct Config *, struct Router * );
extern void send_udp_disconnect( struct Config *, struct Router * );
extern void recv_udp_command( struct Config * );
extern void recv_udp_connect( struct Config *, struct Router * );
extern void recv_udp_disconnect( struct Config *, struct Router * );
extern void accept_tcp_connection( struct Config *cfg );

#endif /* _UDP_COM_H_ */
