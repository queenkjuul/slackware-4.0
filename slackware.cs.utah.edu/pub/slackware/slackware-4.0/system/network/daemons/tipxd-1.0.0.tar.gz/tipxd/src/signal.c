/*=================================================================
FILE: signal.c

DESCRIPTION:
   Defines signal handlers for signal events.  Currently, this
   program will trap SIGINT( usually Ctrl-C ).

PUBLIC FUNCTIONS:
   void sig_int( int );

AUTHOR:
   Tom Hendrick
=================================================================*/
#include "sig.h"

/*=================================================================
FUNCTION: sig_int

DESCRIPTION:
   Function to handle the interrupt signal(SIGINT), and cleanup
   cleanly. Tries to close any open sockets, and de-allocate
   tables before it dies.

PARAMETERS:
   int signo - the signal number which occured.

RETURN TYPE:
   void
=================================================================*/
void sig_int( int signo )
{
  struct Ether  *ptr;
  struct Router *rtr;
  
  /* Start the clean-up task */
  fprintf( stdout, "[CLEAN-UP: Task started]\n" );
  /* Broadcast a disconnect */
  broadcast_udp_disconnect( configuration );
  /* Make sure not to close stuff that doesn't exist */
  if( configuration == NULL )
    {
      fprintf( stdout, "[CLEAN-UP: Task complete]\n" );
      exit( 0 );
    }
  /* Close TCP listening socket */
  if( configuration->cfg_tcp_sock_fd > 0 )
    {
      if( close( configuration->cfg_tcp_sock_fd ) )
	{
	  fprintf( stderr, " [CLEAN-UP: Error closing TCP listening socket]\n" );
	}
      else
	{
	  fprintf( stdout, " [CLEAN-UP: TCP listening socket closed]\n" );
	}
    }
  /* Close UDP control socket */
  if( configuration->cfg_udp_sock_fd > 0 )
    {
      if( close( configuration->cfg_udp_sock_fd ) )
	{
	  fprintf( stderr, " [CLEAN-UP: Error closing udp control socket]\n" );
	}
      else
	{
	  fprintf( stdout, " [CLEAN-UP: UDP control socket closed]\n" );
	}
    }
  /* Close all open file descriptors */
  for( ptr = configuration->cfg_interfaces;
       ptr != NULL;
       ptr = ptr->eth_next )
    {
      /* is the socket open? */
      if( ptr->eth_sock_fd > 0 )
	{
	  /* Remove the interface from promisc mode */
	  clr_if_promisc_mode( ptr );
	  /* attempt to close it */
	  if( close( ptr->eth_sock_fd ) )
	    {
	      /* Error, print it */
	      fprintf( stderr, " [CLEAN-UP: Error closing 802.3 socket %s]\n",
		      ptr->eth_device_name );
	    }
	  else
	    {
	      /* Success, print */
	      fprintf( stdout, " [CLEAN-UP: 802.3 socket on %s closed]\n",
		      ptr->eth_device_name );
	    }
	}
    }
  /* Close all open router socket descriptors */
  for( rtr = configuration->cfg_routers;
       rtr != NULL;
       rtr = rtr->rtr_next )
    {
      /* See if the fd is open */
      if( rtr->rtr_tcp_sock_fd_in > 0 )
	{
	  /* Attempt to close it */
	  if( close( rtr->rtr_tcp_sock_fd_in ) )
	    {
	      /* Error, but nothing serious */
	      fprintf( stderr, " [CLEAN-UP: Error closing IN-TCP socket to %s]\n",
		      rtr->rtr_hostname );
	    }
	  else
	    {
	      fprintf( stdout, " [CLEAN-UP: IN-TCP socket to %s closed]\n",
		      rtr->rtr_hostname );
	    }
	}
      else
	{
	  /* Socket not open, print it anyway */
	  fprintf( stdout, " [CLEAN-UP: IN-TCP socket to %s not open, ignoring]\n",
		  rtr->rtr_hostname );
	}
      /* See if the fd is open */
      if( rtr->rtr_tcp_sock_fd_out > 0 )
	{
	  /* Attempt to close it */
	  if( close( rtr->rtr_tcp_sock_fd_out ) )
	    {
	      /* Error, but nothing serious */
	      fprintf( stdout, " [CLEAN-UP: Error closing OUT-TCP socket to %s]\n",
		       rtr->rtr_hostname );
	    }
	  else
	    {
	      fprintf( stdout, " [CLEAN-UP: OUT-TCP socket to %s closed]\n",
		       rtr->rtr_hostname );
	    }
	}
      else
	{
	  /* Socket not open, print it anyway */
	  fprintf( stdout, " [CLEAN-UP: OUT-TCP socket to %s not open, ignoring]\n",
		  rtr->rtr_hostname );
	}
    }
  fprintf( stdout, "[CLEAN-UP: Task complete]\n" );
  /* Exit cleanly */
  exit( 0 );
}
