/*=================================================================
FILE: net.h

DESCRIPTION:
   Header file for network-oriented routines.  Outlines function
   prototypes and preprocessor includes.

PUBLIC FUNCTIONS:
   int open_ipx_802_3_socket( char * )
   int open_ipx_ipx_socket( char * )

AUTHOR:
   Tom Hendrick
=================================================================*/
#ifndef _NET_H_
#define _NET_H_

/*=================================================================
PREPROCESSOR INCLUDES
=================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <linux/if_ether.h>
#include <net/if.h>
#include <sys/ioctl.h>

#include "ipxtunnel.h"
#include "sig.h"
#include "util.h"

#define DEFAULT_MTU 1514

/*=================================================================
PUBLIC DATA TYPES
=================================================================*/
struct PacketHdr
{
  unsigned long ph_size;
  unsigned long ph_sequence;
};

/*=================================================================
PUBLIC FUNCTION PROTOTYPES
=================================================================*/
extern int  set_if_promisc_mode( struct Ether * );
extern int  clr_if_promisc_mode( struct Ether * );

extern void open_ipx_802_3_socket    ( struct Ether * );
extern void open_ipx_ipx_socket      ( struct Ether * );
extern void open_tcp_listening_socket( struct Config *config );
extern void open_udp_control_socket  ( struct Config *config );

extern void recv_tcp_packet( struct Config *, struct Router * );
extern void recv_ipx_packet( struct Config *, struct Ether * );

extern void send_packet_tcp_all( struct Config *, char * , int );
extern void send_packet_ipx_all( struct Config *, char * , int );
extern void send_packet_tcp    ( struct Router *, char * , int );
extern void send_packet_ipx    ( struct Ether * , char * , int );

#endif /* _NET_H_ */
