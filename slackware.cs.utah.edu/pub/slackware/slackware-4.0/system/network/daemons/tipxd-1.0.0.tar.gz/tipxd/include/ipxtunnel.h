/*=================================================================
FILE: ipxtunnel.h

DESCRIPTION:
   Outlines data structure types for tipxd.  Includes types for
   ethernet interfaces, remote routers, as well as the local global
   configuration for the entire program.

PUBLIC DATA TYPES:
   struct Ether
   struct Router
   struct Config
=================================================================*/
#ifndef _IPXTUNNEL_H_
#define _IPXTUNNEL_H_

/*=================================================================
PREPROCESSOR INCLUDES AND DEFINES
=================================================================*/
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <net/if.h>
#include <linux/if_ether.h>

#define PEER_NOT_REGISTERED -1
#define PEER_LOCAL           0
#define PEER_REMOTE          1

#define MAX_LINE     256

/*=================================================================
PUBLIC DATA TYPES
=================================================================*/

/*
 * Data structure for ethernet devices
 */
struct Ether
{
  signed char     eth_device_name[IFNAMSIZ + 1];
  signed int      eth_sock_fd;
  struct sockaddr eth_addr;
  struct Ether   *eth_next;
};

/*
 * Data structure for Remote hosts
 */
struct Router
{
  signed char        rtr_hostname[MAX_LINE];
  struct sockaddr_in rtr_addr;
  signed short       rtr_udp_port;
  signed short       rtr_tcp_port;
  signed int         rtr_tcp_sock_fd_in;
  signed int         rtr_tcp_sock_fd_out;
  signed long        rtr_sequence;
  struct Router     *rtr_next;
};

/*
 * Data structure for peer registration
 */
struct Peer
{
  unsigned char    reg_hwaddr[ETH_ALEN];
  int              reg_location;
  union {
    struct Router   *reg_router;
    struct Ether    *reg_ether;
  } reg_destination;
  struct Peer     *reg_next;
};

/*
 * Data structure for global configuration
 */
struct Config
{
  struct Ether  *cfg_interfaces;
  struct Router *cfg_routers;
  struct Peer   *cfg_peers;
  signed int     cfg_udp_sock_fd;
  signed int     cfg_tcp_sock_fd;
  signed short   cfg_udp_port;
  signed short   cfg_tcp_port;
};

extern struct Config *configuration;

#endif /* _IPXTUNNEL_H_ */
/*=================================================================
PVCS Log

$Log: ipxtunnel.h,v $
Revision 1.5  1998/11/06 01:55:16  thomash
conf/tipxd.conf.norritt2
   added multiple router configuration for norritt

include/ipxtunnel.h
   updated structures for improved routing.

include/register.h
   updated function prototypes for improved routing

src/conf.c
   Changed read of interfaces to read up to IFNAMSIZ instead of MAXLINE

src/net.c
   Updated send and recv routines to route packets only to the
    destinations that need them.

src/register.c
   Changed registration routines to register hosts with interfaces
    or specific routers, not just local or remote.  This allows us to
    route packets which go to them only to the destination routers
    that need to receive them.

Revision 1.4  1998/11/03 05:59:26  thomash
include/ipxtunnel.h
   added cfg_sequence member to 'struct Config' for sequencing packets
    between routers.  Helps to match packets between endpoints.
include/net.h
   added 'struct PacketHdr' structure to preceed packets on the TCP
    sockets.  Allows the receiving end to read the correct number of
    bytes, and also supplies a sequence number to match packets between
    endpoints.
src/net.c
   Updated TCP routines to use 'write' and 'read' instead of 'sendto' and
    'recvfrom' (thanks go to Peter Belding for this one) and the packet
    header structures.  Now we read a fixed size packet header, and then
    the variable sized packet from the stream.  Attempts to fix packet
    smashing(two packets read as a single packet).

Revision 1.3  1998/11/02 03:43:10  thomash
include/ipxtunnel.h
  added data 'eth_addr' member to struct Ether to keep the address
   for the sendto call in net.c::send_packet_ipx

src/net.c
  removed ioctl calls to get the MTU becuase operation is not supported
   by the socket types
  changed 'write' call to 'sendto' in send_packet_ipx

Revision 1.2  1998/11/02 01:30:09  thomash
include/ipxtunnel.h
   included linux/if_ether.h and used linux-system-defined constants
     for ethernet hw-addr length(ETH_ALEN)
include/net.h
   added function prototypes:
      recv_tcp_packet, send_packet_tcp_all, send_packet_tcp
      recv_ipx_packet, send_packet_ipx_all, send_packet_ipx
   removed (actually renamed to recv_ipx_packet) read_802_3_packet
include/util.h
   included linux/if_ether.h to use system defined constants
src/main.c
   added appropriate calls to recv_tcp_packet and recv_ipx_packet
src/net.c
   added functions:
      recv_tcp_packet, send_packet_tcp_all, send_packet_tcp
      recv_ipx_packet, send_packet_ipx_all, send_packet_ipx

=================================================================*/
