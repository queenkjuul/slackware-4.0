/*================================================================
FILE: net.c

DESCRIPTION:
   Routines to open and establish socket connections.

PUBLIC ROUTINES:


AUTHOR:
   Tom Hendrick
=================================================================*/
#include "net.h"
#include "util.h"
#include "register.h"

/*=================================================================
FUNCTION: open_ipx_802_3_socket

DESCRIPTION:
   Opens and establishes the IPX listening socket.  This program
   works with a 2-sided architecture.  There is a socket of type
   SOCK_PACKET that listens for IPX 802.3 framed packets.  Every
   time an IPX 802.3 packet is received, it is sent via UDP to
   all remote hosts.  Put simply:

   LAN <--IPX--> ipxtund <== TCP/IP WAN ==> ipxtund <--IPX--> LAN

   This function opens the "LAN <--IPX--> ipxtund" link and returns
   the file descriptor, or -1 on an error.

ARGUMENTS:
   none
   
RETURN TYPE:
   int - the fd of the open socket, or -1 on error.
=================================================================*/
void open_ipx_802_3_socket( struct Ether *eth )
{
   /* Local fd var for the fd */
   int sock_fd;
  
   /* Start the task */
   fprintf( stdout, "[IPX-802.3-OPEN: Task started]\n" );
   /* Attempt to open the socket */
   sock_fd = socket( AF_INET, SOCK_PACKET, htons( ETH_P_802_3 ) );
   /* Check for error */
   if( sock_fd < 0 )
   {
      /* Error occured */
      fprintf( stderr, " [IPX-802.3-OPEN-ERROR: Error opening socket : %s]\n",
              strerror( errno ) );
      /* Return an error */
      exit( -1 );
   }
   fprintf( stdout, " [IPX-802.3-OPEN: 802.3 socket open on file descriptor %d]\n",
           sock_fd );
   /* Bind the socket to an address */
   eth->eth_addr.sa_family = AF_UNIX;
   /* Clear the memory before copying */
   memset( eth->eth_addr.sa_data, '\0', sizeof( struct sockaddr_in ) );
   /* Strcpy the interface name into the address */
   strncpy( eth->eth_addr.sa_data, eth->eth_device_name, 14 );
   /* Attempt to bind the socket to the interface */
   if( bind( sock_fd, &eth->eth_addr, sizeof( struct sockaddr ) ) != 0 )
   {
      /* Bind problem, close socket and return */
      fprintf( stderr, " [IPX-802.3-OPEN: Unable to bind 802.3 socket : %s]\n",
              strerror( errno ) );
      /* Close the socket */
      close( sock_fd );
      return;
   }
   fprintf( stdout, " [IPX-802.3-OPEN: 802.3 socket bound to %s]\n",
             eth->eth_device_name );
   fprintf( stdout, "[IPX-802.3-OPEN: Task Complete]\n" );
   /* Return the file descriptor */
   eth->eth_sock_fd = sock_fd;
   return;
}

/*=================================================================
FUNCTION: set_if_promisc_mode

DESCRIPTION:
   Sets the interface to promiscuous mode.

ARGUMENTS:
   int   fd     - the file descriptor open to the interface
   char *ifname - the name of the interface
=================================================================*/
int set_if_promisc_mode( struct Ether *eth )
{
   struct ifreq req;
   
   /* Start the task */
   fprintf( stdout, "[CONFIG-INTERFACE: Task Started]\n" );
   /* We need to get the current set of flags */ 
   strncpy( req.ifr_name, eth->eth_device_name, IFNAMSIZ );
   /* Get the flags */
   if( ioctl( eth->eth_sock_fd, SIOCGIFFLAGS, &req) < 0 )
   {
      fprintf( stderr, " [CONFIG-INTERFACE: Unable to get interface flags: %s]\n",
              strerror( errno ) );
      return -1;
   }
   /* Inform user */
   fprintf( stdout, " [CONFIG-INTERFACE: Retrieved interface flags]\n" );
   /* Insert the flag */
   req.ifr_flags |= IFF_PROMISC;
   /* Request again */
   if( ioctl( eth->eth_sock_fd, SIOCSIFFLAGS, &req ) < 0 ) 
   {
      /* Print a message */
      fprintf( stderr, " [CONFIG-INTERFACE: Unable to set interface flags: %s]\n",
              strerror( errno ) );
      return -1;
   }
   fprintf( stdout, " [CONFIG-INTERFACE: Interface flag set]\n" );
   fprintf( stdout, "[CONFIG-INTERFACE: Task Complete]\n" );

 return 0;
}


/*=================================================================
FUNCTION: clr_if_promisc_mode

DESCRIPTION:
   Removes the interface from promiscuous mode.

ARGUMENTS:
   struct Ether * - the ether device to take care of
=================================================================*/
int clr_if_promisc_mode( struct Ether *eth )
{
   struct ifreq req;
   
   /* Start the task */
   fprintf( stdout, "[CONFIG-INTERFACE: Task Started]\n" );
   /* We need to get the current set of flags */ 
   strncpy( req.ifr_name, eth->eth_device_name, IFNAMSIZ );
   /* Get the flags */
   if( ioctl( eth->eth_sock_fd, SIOCGIFFLAGS, &req) < 0 )
   {
      fprintf( stderr, " [CONFIG-INTERFACE: Unable to get interface flags: %s]\n",
              strerror( errno ) );
      return -1;
   }
   /* Inform user */
   fprintf( stdout, " [CONFIG-INTERFACE: Retrieved interface flags]\n" );
   /* Insert the flag */
   req.ifr_flags &= ~IFF_PROMISC;
   /* Request again */
   if( ioctl( eth->eth_sock_fd, SIOCSIFFLAGS, &req ) < 0 ) 
   {
      /* Print a message */
      fprintf( stderr, " [CONFIG-INTERFACE: Unable to set interface flags: %s]\n",
              strerror( errno ) );
      return -1;
   }
   fprintf( stdout, " [CONFIG-INTERFACE: Interface flag cleared]\n" );
   fprintf( stdout, "[CONFIG-INTERFACE: Task Complete]\n" );

 return 0;
}

/*=================================================================
FUNCTION: recv_ipx_packet

DESCRIPTION:
   Reads a packet on the 802.3 file descriptor given, and returns
   it as a set of bytes.

ARGUMENTS:
   struct Ether * - the ethernet interface to read from

RETURNS:
   int    - the size of the packet
=================================================================*/
void recv_ipx_packet( struct Config *cfg, struct Ether *eth )
{
  int            bytes;
  int            mtu;
  int            location_src;
  char           buf[DEFAULT_MTU];
  struct Peer   *peer_src;
  struct Peer   *peer_dst;
  struct ethhdr *packet_overlay;

  /* Make sure the socket is open */
  if( eth->eth_sock_fd < 0 )
    {
      return;
    }
  
  /* Set default MTU */
  mtu = DEFAULT_MTU;

  /* Attempt a read */
  bytes = read( eth->eth_sock_fd, buf, mtu );

  /* See if there is a problem */
  if( bytes < 0 )
    {
      fprintf( stderr, " [RECV-IPX-PACKET: Read error : %s]\n", strerror( errno ) );
      return;
    }
  
  /* Overlay over the buf variable for convienience */
  packet_overlay = ( struct ethhdr * )buf;

  /* Print the header information */
  fprintf( stdout, " [RECV-IPX-PACKET: %s->",
	  print_ether_address( packet_overlay->h_source ) );
  fprintf( stdout, "%s]\n",
	  print_ether_address( packet_overlay->h_dest ) );
  
  /* Now, we need to route the packet to all the appropriate destinations
     Here is the routing table[Remember, all packets received are considered
     to be received LOCALLY]:
     
     SRC      DST         ACTION
     local    local       Ignore
     local    remote      Send-All-TCP
     unreg    unreg       reg-source, Send-All-TCP
     local    unreg       Send-All-TCP
     remote   local       Ignore-Error
     remote   remote      Ignore-Error
     
  */
  
  /* Get the locations */
  peer_src = get_peer_registration( cfg->cfg_peers, packet_overlay->h_source );
  peer_dst = get_peer_registration( cfg->cfg_peers, packet_overlay->h_dest );
  
  /* Now, register source if not already registered */
  if( NULL == peer_src )
    {
      fprintf( stdout, " [RECV-IPX-PACKET: Address %s registered->%s]\n",
	      print_ether_address( packet_overlay->h_source ),
	      eth->eth_device_name );
      /* Register this peer */
      cfg->cfg_peers = 
	register_peer_local( cfg->cfg_peers, packet_overlay->h_source, eth );
      /* Set the location */
      location_src = PEER_LOCAL;
    }
  else
    {
      /* Set the source location */
      location_src = peer_src->reg_location;
    }
  
  /* Now, check for local registration */
  if( location_src == PEER_LOCAL )
    {
      /* Now, if the destination is registered remote, or not registered,
	 we send to all remote tcp sockets */
      if ( NULL == peer_dst )
	{
	  /* Send to all TCP */
	  send_packet_tcp_all( cfg, buf, bytes );
	}
      else if( PEER_REMOTE == peer_dst->reg_location )
	{
	  /* Send to only necessary TCP */
	  send_packet_tcp( peer_dst->reg_destination.reg_router, 
			   buf,
			   bytes );
	}
    }
  
  return;
}


/*=================================================================
FUNCTION: open_tcp_listening_socket

DESCRIPTION:
   Attempts to open, bind and listen for connections on a TCP
   socket.  It places the file descriptor for the socket into the
   Config structure.

ARGUMENTS:
   struct Config* the configuration structure
=================================================================*/
void open_tcp_listening_socket( struct Config *config )
{
  struct sockaddr_in addr;
  
  fprintf( stdout, "[OPEN-TCP-LISTENING-SOCKET: Task started]\n" );

  /* Attempt to create a new socket */
  config->cfg_tcp_sock_fd = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
  /* Error check */
  if( config->cfg_tcp_sock_fd < 0 )
    {
      fprintf( stderr, " [OPEN-TCP-LISTENING-SOCKET: Error creating socket %s]\n",
	      strerror( errno ) );
      /* Bail out */
      sig_int( 0 );
    }
  /* Success, print it */
  fprintf( stdout, " [OPEN-TCP-LISTENING-SOCKET: Socket open on descriptor %d]\n",
	  config->cfg_tcp_sock_fd );

  /* We need to get the interface address to bind to */
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = htonl(INADDR_ANY);
  addr.sin_port = htons( config->cfg_tcp_port );
  
  /* Otherwise, attempt to bind it to and adress */
  if(bind(config->cfg_tcp_sock_fd,(struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
      fprintf( stderr, " [OPEN-TCP-LISTENING-SOCKET: Error binding socket %s]\n",
	      strerror( errno ) );
      /* Bail out */
      sig_int( 0 );
    }
  /* Succes, print */
  fprintf( stdout, " [OPEN-TCP-LISTENING-SOCKET: socket bound to local port %d]\n",
	  config->cfg_tcp_port );
  
  /* Attempt to starting listening on the socket */
  if( listen( config->cfg_tcp_sock_fd, 10 ) < 0 )
    {
      /* Error */
      fprintf( stderr, " [OPEN-TCP-LISTENING-SOCKET: Error listening on socket %s]\n",
	      strerror( errno ) );
      sig_int( 0 );
    }
  
  fprintf( stdout, " [OPEN-TCP-LISTENING-SOCKET: Listening started on socket]\n" );
  fprintf( stdout, "[OPEN-TCP-LISTENING-SOCKET: Task Complete]\n" );

  return;
}

/*=================================================================
FUNCTION: open_udp_control_socket

DESCRIPTION:
   Attempts to open, bind and listen for connections on a UDP
   socket.  It places the file descriptor for the socket into the
   Config structure.

ARGUMENTS:
   struct Config* the configuration structure
=================================================================*/
void open_udp_control_socket( struct Config *config )
{
  struct sockaddr_in addr;
  
  fprintf( stdout, "[OPEN-UDP-CONTROL-SOCKET: Task started]\n" );

  /* Attempt to create a new socket */
  config->cfg_udp_sock_fd = socket( AF_INET, SOCK_DGRAM, 0 );
  /* Error check */
  if( config->cfg_udp_sock_fd < 0 )
    {
      fprintf( stderr, " [OPEN-UDP-CONTROL-SOCKET: Error creating socket %s]\n",
	      strerror( errno ) );
      /* Bail out */
      sig_int( 0 );
    }
  /* Succes, print him */
  fprintf( stdout, " [OPEN-UDP-CONTROL-SOCKET: Socket open on descriptor %d]\n",
	  config->cfg_udp_sock_fd );

  /* We need to get the interface address to bind to */
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = htonl(INADDR_ANY);
  addr.sin_port = htons( config->cfg_udp_port );
  
  /* Otherwise, attempt to bind it to and adress */
  if(bind(config->cfg_udp_sock_fd,(struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
      fprintf( stderr, " [OPEN-UDP-CONTROL-SOCKET: Error binding socket %s]\n",
	      strerror( errno ) );
      /* Bail out */
      sig_int( 0 );
    }
  /* Succes, print */
  fprintf( stdout, " [OPEN-UDP-CONTROL-SOCKET: socket bound to local port %d]\n",
	  config->cfg_udp_port );
  
  fprintf( stdout, "[OPEN-UDP-CONTROL-SOCKET: Task Complete]\n" );

  return;
}

/*=================================================================
FUNCTION: send_packet_tcp_all

DESCRIPTION:
   Sends the given packet to all remote TCP listening hosts.

ARGUMENTS:
   struct Config * - the current configuration
   char *          - the packet data
   int             - the size in bytes of the packet data

RETURN TYPE:
   void
=================================================================*/
void send_packet_tcp_all( struct Config *cfg, char *pack, int p_size )
{
  /* Now, we loop through each interface and send the packet */
  struct Router *rtr;
  struct PacketHdr header;
  
  /* Formulate the packet header */
  header.ph_size = htonl( p_size );
  
  /* Loop through all remote routers */
  for( rtr = cfg->cfg_routers; rtr != NULL; rtr = rtr->rtr_next )
    {
      /* Set the router sequence number */
      header.ph_sequence = htonl( rtr->rtr_sequence );
      /* Now, if the socket is open, send it */
      if( rtr->rtr_tcp_sock_fd_out > 0 )
	{
	  /* Send the packet header to the remote host */
	  if( write( rtr->rtr_tcp_sock_fd_out,
		     &header, sizeof( struct PacketHdr ) ) < 0 )
	    {
	      /* Error sending */
	      fprintf( stderr, " [SEND-PACKET-TCP: Error sending header to %s:%s]\n",
		      rtr->rtr_hostname, strerror( errno ) );
	      /* Ignore */
	      continue;
	    }
	  /* Send the entire packet to the socket */
	  if( write( rtr->rtr_tcp_sock_fd_out,pack, p_size ) < 0 )
	    {
	      /* Error sending */
	      fprintf( stderr, " [SEND-PACKET-TCP: Error sending packet to %s:%s]\n",
		      rtr->rtr_hostname, strerror( errno ) );
	      continue;
	    }
	  /* Print confirmation */
	  fprintf( stdout, "[SEND-PACKET-TCP: (Seq:%ld, %d bytes)Packet sent to %s]\n",
		  rtr->rtr_sequence, p_size, rtr->rtr_hostname );
	  /* Increment the router sequence number */
	  rtr->rtr_sequence++;
	}
    }
}

/*=================================================================
FUNCTION: send_packet_tcp_all

DESCRIPTION:
   Sends the given packet to all remote TCP listening hosts.

ARGUMENTS:
   struct Config * - the current configuration
   char *          - the packet data
   int             - the size in bytes of the packet data

RETURN TYPE:
   void
=================================================================*/
void send_packet_tcp( struct Router *rtr, char *pack, int p_size )
{
  /* Now, we loop through each interface and send the packet */
  struct PacketHdr header;
  
  /* Now, if the socket is open, send it */
  if( rtr->rtr_tcp_sock_fd_out > 0 )
    {
      /* Formulate the packet header */
      header.ph_size = htonl( p_size );
      header.ph_sequence = htonl( rtr->rtr_sequence );
      
      /* Send the packet header to the remote host */
      if( write( rtr->rtr_tcp_sock_fd_out,
		 &header, sizeof( struct PacketHdr ) ) < 0 )
	{
	      /* Error sending */
	  fprintf( stderr, " [SEND-PACKET-TCP: Error sending header to %s:%s]\n",
		  rtr->rtr_hostname, strerror( errno ) );
	  /* Ignore */
	  return;
	}
      /* Send the entire packet to the socket */
      if( write( rtr->rtr_tcp_sock_fd_out,pack, p_size ) < 0 )
	{
	  /* Error sending */
	  fprintf( stderr, " [SEND-PACKET-TCP: Error sending packet to %s:%s]\n",
		  rtr->rtr_hostname, strerror( errno ) );
	  return;
	}
      /* Print confirmation */
      fprintf( stdout, "[SEND-PACKET-TCP: (Seq:%ld, %d bytes)Packet sent to %s]\n",
	      rtr->rtr_sequence, p_size, rtr->rtr_hostname );
      /* Increment router sequence number */
      rtr->rtr_sequence++;
    }
}

/*=================================================================
FUNCTION: recv_tcp_packet

DESCRIPTION:
   Reads a packet from the router file descriptor given, and returns
   it as a set of bytes.

ARGUMENTS:
   struct Config * - the current configuration
   struct Router * - the router to read from

RETURNS:
   void
=================================================================*/
void recv_tcp_packet( struct Config *cfg, struct Router *rtr )
{
  int              bytes;
  int              mtu;
  int              location_src;
  struct Peer     *peer_src;
  struct Peer     *peer_dst;
  int              addr_len;
  char             buf[DEFAULT_MTU];
  struct ethhdr   *packet_overlay;
  struct PacketHdr header;
   
  /* Make sure the socket is open */
  if( rtr->rtr_tcp_sock_fd_in < 0 )
    {
      return;
    }
  
  /* Set buffer size */
  mtu = DEFAULT_MTU;
  
  /* Set the size of the address */
  addr_len = sizeof( struct sockaddr );

  /* Read the packet header structure */
  bytes = read( rtr->rtr_tcp_sock_fd_in, &header, sizeof( struct PacketHdr ) );
  
  /* See if there is a problem */
  if( bytes < 0 )
    {
      fprintf( stderr, " [RECV-TCP-PACKET: Read error : %s]\n",
	       strerror( errno ) );
      return;
    }
  
  /* Now, adjust the network byte-ordering */
  header.ph_size = ntohl( header.ph_size );
  header.ph_sequence = ntohl( header.ph_sequence );
  
  /* Now read the packet data */
  bytes = read( rtr->rtr_tcp_sock_fd_in, buf, header.ph_size );

  /* See if there is a problem */
  if( bytes < 0 )
    {
      fprintf( stderr, " [RECV-TCP-PACKET: Read error : %s]\n",
	       strerror( errno ) );
      return;
    }
  
  /* Overlay over the buf variable for convienience */
  packet_overlay = ( struct ethhdr * )buf;
  
  /* Print the header information */
  fprintf( stdout, " [RECV-TCP-PACKET: (Seq:%ld, %d bytes)%s->",
	  header.ph_sequence,
	  bytes,
	  print_ether_address( packet_overlay->h_source ) );
  fprintf( stdout, "%s]\n",
	  print_ether_address( packet_overlay->h_dest ) );
  
  /* Now, we need to route the packet to all the appropriate destinations
     Here is the routing table[Remember, all packets received are considered
     to be received REMOTELY]:
     
     SRC      DST         ACTION
     local    --ANY--     Ignore-Error
     remote   unreg       Send-All-IPX
     remote   local       Send-All-IPX
     remote   remote      Ignore
     unreg    unreg       reg-source, Send-All-IPX
     unreg    local       reg-source, Send-All-IPX
     unreg    remote      reg-source, Ingore packet
     
  */
  
  /* Get the locations */
  peer_src = get_peer_registration( cfg->cfg_peers, packet_overlay->h_source );
  peer_dst = get_peer_registration( cfg->cfg_peers, packet_overlay->h_dest );
  
  /* Now, register source if not already registered */
  if( peer_src == NULL )
    {
      /* Register this peer */
      cfg->cfg_peers = 
	register_peer_remote( cfg->cfg_peers, packet_overlay->h_source, rtr );
      /* Print information */
      fprintf( stdout, " [RECV-TCP-PACKET: Address %s registered->%s]\n",
	       print_ether_address( packet_overlay->h_source ),
	       rtr->rtr_hostname );
      /* Set the location */
      location_src = PEER_REMOTE;
    }
  else
    {
      /* Set the source location */
      location_src = peer_src->reg_location;
    }
  
  /* Now, check for remote registration */
  if( location_src == PEER_REMOTE )
    {
      /* Now, if the destination is not registered,
	 we send to all local IPX sockets */
      if( NULL == peer_dst )
	{
	  /* Send to all IPX */
	  send_packet_ipx_all( cfg, buf, bytes );
	}
      else if( peer_dst->reg_location == PEER_LOCAL )
	{
	  /* Send to only the interface necessary */
	  send_packet_ipx( peer_dst->reg_destination.reg_ether,
			   buf,
			   bytes );
	}
    }

  return;
}

/*=================================================================
FUNCTION: send_packet_ipx_all

DESCRIPTION:
   Sends the given packet to all remote IPX listening hosts.

ARGUMENTS:
   struct Config * - the current configuration
   char *          - the packet data
   int             - the size in bytes of the packet data

RETURN TYPE:
   void
=================================================================*/
void send_packet_ipx_all( struct Config *cfg, char *pack, int p_size )
{
  /* Now, we loop through each interface and send the packet */
  struct Ether *eth;

  for( eth = cfg->cfg_interfaces; eth != NULL; eth = eth->eth_next )
    {
      /* Now, if the socket is open, send it */
      if( eth->eth_sock_fd > 0 )
	{
	  send_packet_ipx (eth,pack,p_size);
	}
    }
}

/*=================================================================
FUNCTION: send_packet_ipx

DESCRIPTION:
   Sends the given packet to the specified local interface socket

ARGUMENTS:
   struct Ether *  - the local interface
   char *          - the packet data
   int             - the size in bytes of the packet data

RETURN TYPE:
   void
=================================================================*/
void send_packet_ipx( struct Ether *eth, char *pack, int p_size )
{
  /* Send the packet to the remote host */
  int bytes;
  
  /* Send the packet */
  bytes = sendto( eth->eth_sock_fd, pack, p_size, 0,
		  &(eth->eth_addr), sizeof( struct sockaddr ));
  
  /* Now, make sure we sent correctly */
  if( bytes < 0 )
    {
      /* Error, print */
      fprintf( stderr, " [SEND-PACKET-IPX: Error sending packet to %s : %s]\n",
	      eth->eth_device_name , strerror( errno ) );
    }
  else
    {
      fprintf( stderr, " [SEND-PACKET-IPX: Packet sent to %s]\n",
	      eth->eth_device_name );
    }
  /* Done, return */
  return;
}


