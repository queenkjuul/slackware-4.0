/*=================================================================
FILE: register.c

DESCRIPTION:
   Routines to the handle the registration of peers.

AUTHOR:
   Tom Hendrick
=================================================================*/
#include "register.h"

/*=================================================================
FUNCTION: get_peer_registration

DESCRIPTION:
   Searches the given Peer list for the given hardware address.  If
   it is found in the list, this function returns a pointer to its
   entry.  Otherwise, this function returns NULL.

ARGUMENTS:
   struct Peer *reg - the register to be searched
   char *hw_addr - the hardware(MAC) address of the peer

RETURN TYPE:
   int
=================================================================*/
struct Peer *get_peer_registration( struct Peer *reg, unsigned char *hw_addr )
{
   /* This is a simple loop and compare */
   struct Peer *ptr = reg;
   
   if( hw_addr == NULL )
   {
      return NULL;
   }
 
   /* I want to make this loop as tight as possible,
      so if anyone can see ways to improve it, be my guest. */
   while( ptr != NULL )
   {
      /* Memory compare the ethernet address */
      if( memcmp( ptr->reg_hwaddr, hw_addr, HW_ADDR_LEN ) == 0 )
      {
         return ptr;
      } 
      /* Increment the pointer */
      ptr = ptr->reg_next;
   }
   /* If we get here, we are in trouble */
   return NULL;
}

/*=================================================================
FUNCTION: register_peer_local

DESCRIPTION:
   Registers the given hardware address with the given location,
   and adds it to the list reg.  If reg is NULL, a new list is
   created and a pointer to it is returned.  If reg is not NULL,
   then the hardware address is added to the end of the list
   pointed to by reg and reg is returned.

ARGUMENTS:
   struct Peer *reg - the register to be used, or NULL
   unsigned char *hw_addr - the hardware address to be added, or NULL
   struct Ether *ether - the ether device for this peer

RETURN:
   struct Peer* - if reg is NULL, points to a newly created list
                      if reg is !NULL, points to reg
=================================================================*/
struct Peer *register_peer_local( struct Peer     *reg, 
				  unsigned char   *hw_addr,
				  struct Ether    *eth )
{
   /* Some local vars */
   struct Peer *ptr;
   struct Peer *endptr;
 
   /* Ignore if hw_addr points to null */
   if( hw_addr == NULL )
   {
      /* Failure, return reg no matter what */
      return reg;
   }

   /* Allocate a new list element */
   ptr = (struct Peer *)malloc( sizeof( struct Peer ) );
   /* Blank the element */
   memset( ptr, '\0', sizeof( struct Peer ) );
   /* Copy the hw_addr and loc */
   memcpy( ptr->reg_hwaddr, hw_addr, HW_ADDR_LEN );
   ptr->reg_location = PEER_LOCAL;
   /* Now, set the ether interface for this device */
   ptr->reg_destination.reg_ether = eth;

   /* If reg is NULL, allocate a new list */
   if( reg == NULL )
   {
      /* Return the pointer */
      return ptr;
   }
   else
   {
      /* We need to add this to the end of the list */
      for( endptr = reg; endptr->reg_next != NULL; endptr = endptr->reg_next );
      /* So endptr should point to the last element in the list */
      endptr->reg_next = ptr;
      /* Return the original pointer */
      return reg;
   }
} 

/*=================================================================
FUNCTION: register_peer_remote

DESCRIPTION:
   Registers the given hardware address with the given location,
   and adds it to the list reg.  If reg is NULL, a new list is
   created and a pointer to it is returned.  If reg is not NULL,
   then the hardware address is added to the end of the list
   pointed to by reg and reg is returned.

ARGUMENTS:
   struct Peer *reg - the register to be used, or NULL
   unsigned char *hw_addr - the hardware address to be added, or NULL
   struct Router *rtr - the remote site to forward packet to

RETURN:
   struct Peer* - if reg is NULL, points to a newly created list
                      if reg is !NULL, points to reg
=================================================================*/
struct Peer *register_peer_remote( struct Peer     *reg, 
				   unsigned char   *hw_addr,
				   struct Router   *rtr )
{
   /* Some local vars */
   struct Peer *ptr;
   struct Peer *endptr;
 
   /* Ignore if hw_addr points to null */
   if( hw_addr == NULL )
   {
      /* Failure, return reg no matter what */
      return reg;
   }

   /* Allocate a new list element */
   ptr = (struct Peer *)malloc( sizeof( struct Peer ) );
   /* Blank the element */
   memset( ptr, '\0', sizeof( struct Peer ) );
   /* Copy the hw_addr and loc */
   memcpy( ptr->reg_hwaddr, hw_addr, HW_ADDR_LEN );
   ptr->reg_location = PEER_REMOTE;
   /* Now, set the ether interface for this device */
   ptr->reg_destination.reg_router = rtr;

   /* If reg is NULL, allocate a new list */
   if( reg == NULL )
   {
      /* Return the pointer */
      return ptr;
   }
   else
   {
      /* We need to add this to the end of the list */
      for( endptr = reg; endptr->reg_next != NULL; endptr = endptr->reg_next );
      /* So endptr should point to the last element in the list */
      endptr->reg_next = ptr;
      /* Return the original pointer */
      return reg;
   }
} 
