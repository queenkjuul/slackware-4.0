/*=================================================================
FILE: util.h

DESCRIPTION:
   Prototypes for several utilities.  These are used mostly to
   print out packets and addresses in special formats.

PUBLIC FUNCTIONS:
   char *print_ether_address( char * );

AUTHOR:
   Tom Hendrick
=================================================================*/
#ifndef _UTIL_H_
#define _UTIL_H_

/*=================================================================
PREPROCESSOR INCLUDES
=================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <linux/if_ether.h>

enum log_file_enum
{
   log_task = 0,
   log_packet,
   no_of_logs
};

/*=================================================================
PUBLIC FUNCTIONS
=================================================================*/
/* Utility functions */
extern char *print_ether_address( unsigned char * );

#endif /* _UTIL_H_ */
