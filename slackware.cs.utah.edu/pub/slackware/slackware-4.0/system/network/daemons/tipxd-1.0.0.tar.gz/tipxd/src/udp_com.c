/*=================================================================
FILE: udp_com.h

DESCRIPTION:
   Contains routines for communicating on the UDP command socket,
   including broadcasting connect and disconnect requests to all
   remote hosts.

PUBLIC FUNCTIONS:
   void broadcast_udp_connect( struct Config * )
   void broadcast_udp_disconnect( struct Config * )
   void send_udp_connect( struct Router * )
   void send_udp_disconnect( struct Router * )
   void recv_udp_command( struct Config *, struct Router * )
   void recv_udp_connect( struct Config *, struct Router * )
   void recv_udp_disconnect( struct Config *, struct Router * )

AUTHOR:
   Tom Hendrick
=================================================================*/

/*=================================================================
PREPROCESSOR INCLUDES
=================================================================*/
#include "udp_com.h"

/*=================================================================
FUNCTION: broadcast_udp_connect

DESCRIPTION:
   Broadcasts the to all remote routers over the UDP command socket
   that the local tcp socket is ready and accepting connections.

ARGUMENTS:
   struct Config * - the program configuration

RETURN TYPE:
   void
=================================================================*/
void broadcast_udp_connect( struct Config *cfg )
{
  /* We need to loop through all the routers */
  struct Router *rtr;
  
  /* Loop through the entire Configuration list */
  for( rtr = cfg->cfg_routers; rtr != NULL ; rtr = rtr->rtr_next )
    {
      /* Is this guy already connected to us? */
      if( rtr->rtr_tcp_sock_fd_in < 0 )
	{
	  /* No, he is not, so send a command to him */
	  send_udp_connect( cfg, rtr );
	}
    }
}

/*=================================================================
FUNCTION: broadcast_udp_disconnect

DESCRIPTION:
   Broadcasts the to all remote routers over the UDP command socket
   that the local tcp socket is closing and they should close their
   connection to this router.

ARGUMENTS:
   struct Config * - the program configuration

RETURN TYPE:
   void
=================================================================*/
void broadcast_udp_disconnect( struct Config *cfg )
{
  /* We need to loop through all the routers */
  struct Router *rtr;
  /* Loop through the entire Configuration list */
  for( rtr = cfg->cfg_routers; rtr != NULL ; rtr = rtr->rtr_next )
    {
      /* Is this guy already connected to us? */
      if( rtr->rtr_tcp_sock_fd_in > 0 )
	{
	  /* Yes, he is so send a command to him */
	  send_udp_disconnect( cfg, rtr );
	}
    }
}

/*=================================================================
FUNCTION: send_udp_connect

DESCRIPTION:
   Sends a UDP packet to a single remote router informing the
   router to attempt to connect to the local TCP listening socket.

ARGUMENTS:
   struct Config * - the current configuration
   struct Router * - the router to send the command to

RETURN TYPE:
   void
=================================================================*/
void send_udp_connect( struct Config *cfg, struct Router *rtr )
{
  /* We need to format a packet to send to the router */
  struct UDP_Command command;
  
  /* Set the command type */
  command.uc_comm_type = htons( UDP_COMCONNECT );
  /* Set the TCP port number */
  command.uc_tcp_port = htons( cfg->cfg_tcp_port );
  /* Assign the UDP port number in the address */
  rtr->rtr_addr.sin_port = htons( rtr->rtr_udp_port );

  /* Now, we need to send this to the remote address */
  sendto( cfg->cfg_udp_sock_fd, &command, sizeof( struct UDP_Command ),
	  0, &(rtr->rtr_addr), sizeof( rtr->rtr_addr ) );
}

/*=================================================================
FUNCTION: send_udp_connect

DESCRIPTION:
   Sends a UDP packet to a single remote router informing the
   router to attempt to connect to the local TCP listening socket.

ARGUMENTS:
   struct Config * - the current configuration
   struct Router * - the router to send the command to

RETURN TYPE:
   void
=================================================================*/
void send_udp_disconnect( struct Config *cfg, struct Router *rtr )
{
  /* We need to format a packet to send to the router */
  struct UDP_Command command;
  
  /* Set the command type */
  command.uc_comm_type = htons( UDP_COMDISCONNECT );
  /* Set the TCP port number */
  command.uc_tcp_port = htons( cfg->cfg_tcp_port );
  /* Assign the UDP port number in the address */
  rtr->rtr_addr.sin_port = htons( rtr->rtr_udp_port );
  
  /* Now, we need to send this to the remote address */
  sendto( cfg->cfg_udp_sock_fd, &command, sizeof( struct UDP_Command ),
	  0, &(rtr->rtr_addr), sizeof( rtr->rtr_addr ) );
}

/*=================================================================
FUNCTION: recv_udp_command

DESCRIPTION:
   Receives a udp command from the udp control socket.  This
   attempts to match the data received with a router currently
   registered.  If not, the command is ignored.

ARGUMENTS:
   struct Config * - the current configuration

RETURN TYPE:
   void
=================================================================*/
void recv_udp_command( struct Config *cfg )
{
  int bytes;
  struct UDP_Command command;
  int commandlen;
  struct sockaddr_in addr;
  int addrlen;
  struct Router *rtr;

  /* Initialize the structure sizes */
  commandlen = sizeof( struct UDP_Command );
  addrlen = sizeof( struct sockaddr_in );
  
  /* Read the message from the socket */
  bytes = recvfrom( cfg->cfg_udp_sock_fd, &command, commandlen, 0, &addr, &addrlen );
  /* Check for errors */
  if( bytes < 0 )
    {
      return;
    }
  else
    {
      /* Otherwise, we need to see if we can match the address */
      for( rtr = cfg->cfg_routers; rtr != NULL; rtr=rtr->rtr_next )
	{
	  /* Now, compare the from address to the router address.  This
	   * should be okay because both of these are in network-byte-order
	   */
	  if( rtr->rtr_addr.sin_addr.s_addr == addr.sin_addr.s_addr )
	    {
	      /* Its from this router, process it */
	      switch( ntohs( command.uc_comm_type ) )
		{
		case UDP_COMCONNECT:
		  {
		    /* It is a connect request */
		    recv_udp_connect( cfg, rtr );
		  } break;
		case UDP_COMDISCONNECT:
		  {
		    /* It is a disconnect request */
		    recv_udp_disconnect( cfg, rtr );
		  } break;
		default:
		  {
		    /* Ignore */
		    fprintf( stderr, " [RECV-UDP-COMMAND: Unknown command received, ignored]\n" );
		  }
		}
	    }
	}
    }
}

/*=================================================================
FUNCTION: recv_udp_connect

DESCRIPTION:
   Handles a UDP_COMCONNECT message from a router by attempting to
   connect to that router's TCP listening socket.

ARGUMENTS:
   struct Config * - the configuration
   struct Router * - the router the command was recv'd from
=================================================================*/
void recv_udp_connect( struct Config *cfg, struct Router *rtr )
{
  int bufsize = 8192;

  /* Do a little print here */
  fprintf( stdout, " [RECV-UDP-CONNECT: UDP_COMCONNECT from %s]\n",
	  rtr->rtr_hostname);
  /* Make sure we are not already connected to the host */
  if( rtr->rtr_tcp_sock_fd_out > 0 )
    {
      /* Already connected */
      return;
    }
  /* Format the address */
  rtr->rtr_addr.sin_family = AF_INET;
  rtr->rtr_addr.sin_port = htons( rtr->rtr_tcp_port );
  /* Attempt to establish a TCP connection with the remote host */
  rtr->rtr_tcp_sock_fd_out = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
  /* See if we opened the socket okay */
  if( rtr->rtr_tcp_sock_fd_out < 0 )
    {
      /* Print the error */
      fprintf( stderr, "[RECV-UDP-CONNECT: error opening socket to %s : %s]\n",
	      rtr->rtr_hostname, strerror( errno ) );
      /* Return */
      return;
    }
  /* Attempt to make the connection */
  if( connect( rtr->rtr_tcp_sock_fd_out,
	       (struct sockaddr *)(&rtr->rtr_addr),
	       sizeof( struct sockaddr ) ) != 0 )
    {
      /* Error */
      fprintf( stderr, "[RECV-UDP-CONNECT: error connecting socket to %s : %s]\n",
	      rtr->rtr_hostname, strerror( errno ) );
      /* close the socket */
      close( rtr->rtr_tcp_sock_fd_out );
      /* Reset the socket variable */
      rtr->rtr_tcp_sock_fd_out = -1;
      /* return */
      return;
    }
  /* Now, set the socket buffer sizes to something larger */
  if( setsockopt( rtr->rtr_tcp_sock_fd_out, SOL_SOCKET, SO_SNDBUF,
                  (char *)&bufsize, sizeof( int ) ) != 0 )
  {
     /* Error, non-fatal */
     fprintf( stderr, "[RECV-UDP-CONNECT: warning-unable to increase send buffer size]\n" );
  }

  /* Otherwise, we are connected */
  fprintf( stdout, "[RECV-UDP-CONNECT: TCP connection to %s established]\n",
	  rtr->rtr_hostname );
  /* exit */
  return;
}

/*=================================================================
FUNCTION: recv_udp_disconnect

DESCRIPTION:
   Handles a UDP_COMCONNECT message from a router by attempting to
   disconnect from that router's TCP listening socket.

ARGUMENTS:
   struct Config * - the configuration
   struct Router * - the router the command was recv'd from
=================================================================*/
void recv_udp_disconnect( struct Config *cfg, struct Router *rtr )
{
  /* Do a little print here */
  fprintf( stdout, " [RECV-UDP-CONNECT: UDP_COMDISCONNECT from %s]\n",
	  rtr->rtr_hostname);
  /* Close the socket it is open */
  if( rtr->rtr_tcp_sock_fd_out > 0 )
    {
      /* Close the socket */
      close( rtr->rtr_tcp_sock_fd_out );
    }
  /* Set the fd back to -1 */
  rtr->rtr_tcp_sock_fd_out = -1;
 /* Close the socket it is open */
  if( rtr->rtr_tcp_sock_fd_in > 0 )
    {
      /* Close the socket */
      close( rtr->rtr_tcp_sock_fd_in );
    }
  /* Set the fd back to -1 */
  rtr->rtr_tcp_sock_fd_in = -1;
}

/*=================================================================
FUNCTION: accept_tcp_connection

DESCRIPTION:
   If the listening socket is waiting for connections, this function
   is called to accept the connection and set up the socket.

ARGUMENTS:
   struct Config * - the configuration

RETURN TYPE:
   void
=================================================================*/
void accept_tcp_connection( struct Config *cfg )
{
  /* Start the task */
  int sock_fd;
  int length;
  int bufsize;
  struct sockaddr_in addr;
  struct Router *rtr;
  
  /* Buffer size */
  bufsize = 8192;
  /* Start the task */
  fprintf( stdout, "[ACCEPT-TCP-CONNECTION: Task started]\n" );
  /* Initialize the length argument */
  length = sizeof( struct sockaddr_in );
  /* Accept the connection */
  sock_fd = accept( cfg->cfg_tcp_sock_fd, &addr, &length);
  /* Check for errors */
  if( sock_fd < 0 )
    {
      /* Problem */
      fprintf( stderr, "[ACCEPT-TCP-CONNECTION: error on accept %s]\n",
	      strerror( errno ));
      /* Now, just leave */
      return;
    }
  /* Okay, see who it was from */
  for( rtr = cfg->cfg_routers; rtr != NULL;rtr = rtr->rtr_next )
    {
      /* Is this the person? */
      if( rtr->rtr_addr.sin_addr.s_addr == addr.sin_addr.s_addr )
	break;
    }
  /* If they were not found, do not accept the connect */
  if( rtr == NULL )
    {
      /* Drop the connection */
      fprintf(stderr, 
	      "[ACCEPT-TCP-CONNECTION: connect from unregistered router %s]\n",
	      inet_ntoa( addr.sin_addr ) );
      /* Drop the connection */
      close( sock_fd );
      return;
    }
  /* Okay, now, we have a connection, and the host it came from */
  if( rtr->rtr_tcp_sock_fd_in > 0 )
    {
      /* They already have a socket open, we need to drop it */
      fprintf( stderr, "[ACCEPT-TCP-CONNECTION: connect from %s when socket already open]\n",
	      rtr->rtr_hostname );
      /* Drop the old connection, it was probably bad */
      close( rtr->rtr_tcp_sock_fd_in );
    }
  /* Save the connection */
  rtr->rtr_tcp_sock_fd_in = sock_fd;

  /* Now, set the socket buffer sizes to something larger */
  if( setsockopt( rtr->rtr_tcp_sock_fd_in, SOL_SOCKET, SO_RCVBUF,
                  (char *)&bufsize, sizeof( int ) ) != 0 )
  {
     /* Error, non-fatal */
     fprintf( stderr, "[RECV-UDP-CONNECT: warning-unable to increase recv buffer size]\n" );
  }

  /* Print the status */
  fprintf( stdout, "[ACCEPT-TCP-CONNECTION: TCP connection established to %s on fd %d]\n",
	  rtr->rtr_hostname, sock_fd );
  return;
}

