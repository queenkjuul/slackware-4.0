/*=================================================================
FILE: conf.h

DESCRIPTION:
   Outlines function prototypes and data structure types for the
   configuration file subsystem.

PUBLIC DATA TYPES:
   typedef void (*parse_func_ptr)( struct Config *, int );
   struct Taglist
=================================================================*/
#ifndef _CONF_H_
#define _CONF_H_

/*=================================================================
  PREPROCESSOR INCLUDES
=================================================================*/
#include "ipxtunnel.h"

/*=================================================================
PUBLIC DATA TYPES
=================================================================*/
/*
 * Function pointer type for parsing lines
 */
typedef void (*parse_func_ptr)( struct Config *, int );

/*
 * Structure type for parse tags
 */
struct Taglist
{
   char *tl_tag;
   parse_func_ptr tl_parse_function;
};

/*=================================================================
PUBLIC FUNCTION PROTOTYPES
=================================================================*/
extern struct Config* read_config_file( char *fname );
extern void read_interface_line( struct Config *, int );
extern void read_router_line( struct Config *, int );
extern void read_port_line( struct Config *, int );

#endif /* _CONF_H_ */
