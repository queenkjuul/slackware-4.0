
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/telnet.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/poll.h>
#include <time.h>
#include <termios.h>
#include <errno.h>
#include <string.h>
#include <syslog.h>

#include "common.h"

#undef DEBUG
#define BUFSIZE 512

typedef struct _conn {
     int pty;
     int network;
     char name[15];
     pid_t pid;
     struct _conn *next;
     struct pollfd polldat;
} conn;

void tn_init(int incoming);
void tn_recv_opt(unsigned char *opt, int net, conn *client);
void tn_subneg(unsigned char *opt, int net, conn *client);
int tn_simple_opt(unsigned char opt, unsigned char state, int net);
void kiddie_clean(int sig);
void finish(int sig);
void clean_buffer(char *buffer, int size);
int pty_open(char *pts_name);
conn *start_pty(int netsock);
int end_pty(conn *connected);
conn *try_new(int netsock);

int quit;
struct sockaddr_in sockad;
int socksize = sizeof(struct sockaddr_in);
conn *connects;
char **bin;

main(int ac, char *av[]) {
     
     conn *connect1;
     int port;
     int mainsock;
     int x;
     int sockopts;
     struct timeval timeout;
     unsigned char buffer[BUFSIZE];
     int len;
     int debug;

     signal(SIGCHLD, kiddie_clean);
     signal(SIGHUP, finish);
     signal(SIGTERM, finish);
     signal(SIGINT, finish);

     connects = NULL;
     quit = 0;


     if(ac < 3) {
	  printf("usage: %s <port> <program>\n", av[0]);
	  exit(254);
     }

     if((port = atoi(av[1])) == 0) {
	  printf("Please specify a valid decimal port number.\n");
	  exit(127);
     }

     bin = av;
     bin += 2;

     /* begin to prepare our listening socket. */

     mainsock = socket(AF_INET, SOCK_STREAM, 0);

     sockad.sin_family = AF_INET;
     sockad.sin_port = htons(port);
     sockad.sin_addr.s_addr = inet_addr("0.0.0.0");

     x = 1; 
     if(setsockopt(mainsock, SOL_SOCKET, SO_REUSEADDR, &x, sizeof(x)) < 0) {
	  printf("Unable to properly configure socket.\n");
	  exit(127);
     }

     if(bind(mainsock, (struct sockaddr *)&sockad, socksize) != 0) {
	  printf("Couldn't bind to socket.\n");
	  exit(127);
     }

     if(listen(mainsock, 5) != 0) {
	  printf("Couldn't listen on socket.\n");
	  exit(127);
     }

     /* wait for one second on each select() to try to be nice to the
	CPU.  this might be too long. */

     timeout.tv_sec = 1;
     timeout.tv_usec = 0;

     /* alright, now fork off if they're in not in debug mode. */
#ifndef DEBUG
     if(fork() != 0)
	  return;
#endif

     while(quit == 0) {
	  conn *incoming = NULL;
	  fd_set fds;
	  int maxfd = 0;
	  int sel = 0;
	  
	  FD_ZERO(&fds);
	  x = 0;
	  FD_SET(mainsock, &fds); 
	  maxfd = mainsock;
	  connect1 = connects;
	  while(connect1 != NULL) {
	       FD_SET(connect1->pty, &fds);
	       if(connect1->pty > maxfd)
		    maxfd = connect1->pty;
	       FD_SET(connect1->network, &fds);
	       if(connect1->network > maxfd)
		    maxfd = connect1->network;
	       connect1 = connect1->next;
	  }
	  
	  sel = select(maxfd+1, &fds, NULL, NULL, NULL); 

	  /* printf("select: %d\n", sel); */
	  if(sel > 0) {
	       connect1 = connects;
	       while(connect1 != NULL) {
		    if(FD_ISSET(connect1->pty, &fds)) {
			 FD_CLR(connect1->pty, &fds);
			 if((len = read(connect1->pty, buffer,
					BUFSIZE)) < 1) {
			      conn *connect2;
			      conn *prev;
			      /* child died. */
			      shutdown(connect1->network, 2);
			      close(connect1->pty);
			      close(connect1->network);
			      /* and now mend the connects. */
			      connect2 = connects;
			      prev = NULL;
			      while(connect2 != connect1) {
				   prev = connect2;
				   connect2 = connect2->next;
			      }
			      if(prev == NULL) 
				   connects = connect2->next;
			      else
				   prev->next = connect2->next;
			      free(connect2);
			      connect1 = connect1->next;
			      continue;
			 }   else {
			      write(connect1->network, buffer, len);
			 }
		    }
		    if(FD_ISSET(connect1->network, &fds)) {
			 conn *prev;
			 conn *connect2;
			 FD_CLR(connect1->network, &fds);
			 if((len = read(connect1->network, buffer,
					BUFSIZE)) < 1) {
			      /* network connection died. */
			      shutdown(connect1->network, 2);
			      close(connect1->network);
			      end_pty(connect1);
			      close(connect1->pty);
			      /* should free. */
			      connect2 = connects;
			      prev = NULL;
			      while(connect2 != connect1) {
				   prev = connect2;
				   connect2 = connect2->next;
			      }
			      if(prev == NULL) {
				   connects = connect2->next;
			      }
			      else
				   prev->next = connect2->next;
			      free(connect2);
			      connect1 = connect1->next;
			      continue;
			 } else {
			      if(buffer[0] == IAC) {
				   tn_recv_opt(buffer,
					       connect1->network,
					       connect1);
				   continue;
			      }
			      /* for some fucked up reason, the
				 terminals like to send a \0 after a
				 \n.  why, I don't know. */
			      if(buffer[len-1] == 0)
				   len--;
			      write(connect1->pty, buffer, len);
			 }
		    }
		    
		    connect1 = connect1->next;
	       }
	       
	       if(FD_ISSET(mainsock, &fds)) {
		    if((incoming = try_new(mainsock)) == NULL)
			 continue;
		    else
			 connects = incoming;
	       }
	  }
	  
     }
}

conn *try_new(int netsock) {

     int incoming;
     static conn *ret;
     char buf[10];
     struct sockaddr_in insock;
     int socksize;

     socksize = sizeof(struct sockaddr);

     if((incoming = accept(netsock, (struct sockaddr *)&insock,
			   &socksize)) == -1) {
#ifdef DEBUG
	  printf("nothing.  NULL back\n");
#endif
	  return NULL;
     }
#ifdef DEBUG     
     printf("Connection on %d\n", incoming);
#endif DEBUG
     syslog(LOG_DAEMON | LOG_INFO, "Connection from %s\n", inet_ntoa(insock.sin_addr.s_addr));

     /* send out some telnet commands to try to bang them into a
	happier mode.  with any luck. */

     ret = start_pty(incoming);
     return ret;
 
}

/* opens up a pty, and fires off the BBS on it. */

conn *start_pty(int netsock) {

     conn *ret;

     ret = malloc(sizeof(conn));
     
     /* begin prepping our connection structure */
     ret->network = netsock;
     ret->pty = pty_open(ret->name);
#ifdef DEBUG
     printf("pty on fd %d\n", ret->pty);
#endif DEBUG
     ret->next = connects;
     if(ret->pty == -1) {
	  free(ret);
	  return NULL;
     }

     if((ret->pid = fork()) == -1) {
	  printf("Fork failure!");
	  free(ret);
	  return(NULL);
     }
#ifdef DEBUG
     printf("fork success %d\n",ret->pid);
#endif DEBUG
     if(ret->pid == 0) {
	  /* We're the child.  So, prepare to evecve, beeeeeeatch. */
	  struct termios tty_term;
	  int ourtty;
	  char nawsing[15];

	  if((ourtty = open(ret->name, O_RDWR)) == -1)
	       exit(0);

	  /* become our own session leader */
	  printf("setsid: %d\n", setsid());

	  /* become the controlling tty */
	  if(ioctl(ourtty, TIOCSCTTY,  ourtty) == -1) {
	       printf("fork TIOCSCTTY failed %d\n",errno);
	       /* exit(0); */
	  }

	  /* fix up some termios bits. */
	  if(tcgetattr(ourtty, &tty_term) == -1)
	       printf("Couldn't get termios data.\n");
	  tty_term.c_lflag |= NOFLSH;
	  tty_term.c_lflag |= ISIG;
	  if(tcsetattr(ourtty, TCSANOW, &tty_term) == -1)
	       printf("Couldn't set termios data.\n");
#ifdef DEBUG	  
	  printf("preparing telnet options.\n");
#endif 
	  tn_init(netsock);
	  /* alright, do telnet NAWS negotiation, and set up our
	     window size. */
#ifdef DEBUG
	  printf("asking for NAWS\n");
#endif 
	  if(tn_simple_opt(TELOPT_NAWS, DO, netsock) == 1) {
	       read(netsock, nawsing, 15);
#ifdef DEBUG
	       printf("read reply to NAWS data\n");
#endif
	       tn_subneg(nawsing, netsock, ret);
	  }
#ifdef DEBUG
	  printf("about to f0rk\n");
#endif  
	  /* configure stdin/out/err */
	  dup2(ourtty, 0);
	  dup2(ourtty, 1);
	  /* dup2(ourtty, 2); */
#ifdef DEBUG
	  fprintf(stderr, "duped onto my %s.\n", ret->name);
#endif
	  execv(bin[0], bin);
	  /* if we're here, there was an error. :( */
	  fprintf(stderr, "exec failed %d %s\n", errno,bin[0]);
	  exit(0);
	  
     }
          
     return ret;

}

int end_pty(conn *connect) {
     int ret;
     char buffer[10];

     printf("sending signal to %d\n", connect->pid);
     kill(connect->pid, SIGINT);
#ifdef DEBUG
     printf("SIGQUITted, waiting for child to eat shit.\n");
#endif
     buffer[0] = '\177';
     write(connect->pty, buffer, 1);
     sleep(2); /* if we've not been SIGCHLD'd off in 2 seconds, fuck it. */

     return 0;
}

     
int pty_open(char *pts_name) {

     int ptyfd;
     char *ptr1, *ptr2;

     strcpy(pts_name, "/dev/ptyXY");

     /* now sweep for available pty devices... */
     /* this is the naming convention that my devices have in linux... */

     for(ptr1 = "pqrstuvwxyzabede" ; *ptr1 != 0 ; ptr1++) {
          pts_name[8] = *ptr1;
          for(ptr2 = "0123456789abcdef" ; *ptr2 != 0 ; ptr2++) {
               pts_name[9] = *ptr2;
               /* ok, try to actually open it */

               if((ptyfd = open(pts_name, O_RDWR)) < 0) {
                    if(errno == ENOENT) /* ran out of existing devs.  drat. */
                         return -1;
                    else
                         continue;
               }

	       pts_name[5] = 't';
               return ptyfd;
          }
     }

     return -1;  /* exhausted our search space. */

}

/* ok, kids.  It's bath time... */

void kiddie_clean(int sig) {

     wait(NULL);
     signal(SIGCHLD, kiddie_clean);
}

void finish(int sig) {

     conn *cleanme;
     
     cleanme = connects;
     while(cleanme != NULL) {
	  end_pty(cleanme);
	  shutdown(cleanme->network, 2);
	  close(cleanme->network);
	  close(cleanme->pty);
	  cleanme = cleanme->next;
     }

     exit(0);
}

     
void tn_init(int incoming) {

     char xmit[10];
     char in[30];
     
     int flags;
     char buffer[512];

     /* now, this shit is lame, and it adds an unpleasant 1 second
	delay to every connection, but, by god, it makes sure the
	telnet options get negotiated.  Now, the question is, why the
	fuck is there even data there to pull out of the buffer? */

     flags = fcntl(incoming, F_GETFL);
     flags |= O_NONBLOCK;
     fcntl(incoming, F_SETFL, flags);

     while(read(incoming, buffer, 512) != -1)
          continue;
     sleep(1);
     while(read(incoming, buffer, 512) != -1)
          continue;

     flags ^= O_NONBLOCK;
     fcntl(incoming, F_SETFL, flags);


     tn_simple_opt(TELOPT_ECHO, WILL, incoming);
     tn_simple_opt(TELOPT_SGA, WILL,incoming);  
     tn_simple_opt(TELOPT_SGA, DO, incoming);

     if(tn_simple_opt(TELOPT_TTYPE, DO, incoming) == 1) {
#ifdef DEBUG
	  printf("negotiating terminal type.\n");
#endif
	  xmit[0] = IAC;
	  xmit[1] = SB;
	  xmit[2] = TELOPT_TTYPE;
	  xmit[3] = TELQUAL_SEND;
	  xmit[4] = IAC;
	  xmit[5] = SE;
	  write(incoming, xmit, 6);
	  read(incoming, in, 30);
	  tn_subneg(in, incoming, NULL);
     }
	  
     return;
     

}

/* this handles what we do when the other end sends us a request to do
   something with a telnet option. */

void tn_recv_opt(unsigned char *opt, int net, conn *client) {

     unsigned char resp[5];

     resp[0] = IAC;
     
     if(opt[0] != IAC)
	  return;
     
     switch(opt[1]) {
     case DO:
     case DONT:
	  resp[1] = WONT;
	  resp[2] = opt[2];
	  write(net, resp, 3);
	  return;
     case WILL:
     case WONT:
	  resp[1] = DONT;
	  resp[2] = opt[2];
	  write(net, resp, 3);
	  return;
     case SB:
	  tn_subneg(opt, net, client);
	  return;


     }
}

/* subnegotiates a given telnet option.  moved here for clarity. */
/* we need to have the connection sent in case we need to SIGWINCH
   it. */

void tn_subneg(unsigned char *opt, int net, conn *client) {
     
     /* naws vars */
     struct winsize winmod;
     /* termtype's */
     char term[20];
     char termbreak[2] = {255 , 0};

     if((opt[0] != IAC) && (opt[1] != SB)) {
#ifdef DEBUG
	  printf("subneg didn't get IAC SB\n");
	  printf("looks like %d %d\n", opt[0], opt[1]);
#endif
	  return;
     }

     switch(opt[2]) {
     case TELOPT_NAWS:
/* time to modify the window size. */
	  opt += 3;
	  winmod.ws_row = opt[3];
	  winmod.ws_col = opt[1];
#ifdef DEBUG
	  fprintf(stderr, "NAWSing..  %dx%d\n", winmod.ws_col, winmod.ws_row);
#endif
	  if(ioctl(client->pty, TIOCSWINSZ, (char *)&winmod) < 0)
	       fprintf(stderr, "couldn't ioctl() out the window size.\n");
	  kill(client->pid, SIGWINCH);
	  return;
     case TELOPT_TTYPE:
	  /* they want to tell us what kind of terminal they've got */
	  opt += 4;
	  strcpy(term, strsep(&opt, termbreak));
#ifdef DEBUG
	  fprintf(stderr, "they claim to have a %s terminal\n", term);
#endif 
	  setenv("TERM", term, 1);
     }

}

/* sends out an option which doesn't requre subnegotiation. */
/* state describes the type of change to make. */

int tn_simple_opt(unsigned char opt, unsigned char state, int net) {

     unsigned char xmit[5];
     unsigned char inbound[5];
     
     xmit[0] = IAC;
     xmit[1] = state;
     xmit[2] = opt;
     
     write(net, xmit, 3);
     read(net, inbound, 3);

     if(inbound[0] != IAC)
	  return -1;
     switch(state) {
     case DO:
     case DONT:
	  if(inbound[1] == WILL)
	       return 1;
	  else if(inbound[1] == WONT)
	       return 0;
	  else 
	       return -1;
     case WILL:
     case WONT:
	  if(inbound[1] == DO)
               return 1;
          else if(inbound[1] == DONT)
               return 0;
          else
               return -1;
	  
     }

     /* if we're here, something's fucked up. */

     return -1;
     
}

