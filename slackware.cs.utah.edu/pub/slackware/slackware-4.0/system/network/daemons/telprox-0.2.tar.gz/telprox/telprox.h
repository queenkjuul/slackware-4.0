
/*
 *
 * telprox -- a simple telnet proxy daemon
 *
 * This software is free, go ahead and use it! It is
 * distributed under the GNU General Public License
 *
 * Author: faramir@drunken.scots.net  1997
 *
 * please see the file 'README'
 */

#ifndef TELPROX_H
#define TELPROX_H

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#include <netdb.h>
#include <sys/ioctl.h>
#include <ctype.h>


#define BUFSIZE 16384
#define GREET_MSG "telprox -- telnet proxying for lagsters  faramir@drunken.scots.net\n\r"
#define VERS_MSG "version 0.1\n\r"

#ifndef TRUE
#define TRUE 1
#define FALSE !TRUE
#endif

typedef char bool;
int default_port = 1536;
int port = 0;
char proxy_host[] = "000.000.000.000";
static int proxy_port = 23;

fd_set fd_start, fd_read;
struct timeval tv;
int timeout = 0, child_pid = 0, socket_plr = 0;
bool proxy_up;

int socket_in, socket_in2, socket_mud, socket_size;
int sockoptions = 0xffffffff;
struct linger hang_around  = { 1, 5 };  /* 5 secs  */
struct sockaddr_in s, s2, out_s;
FILE * configfile;
char configname[] = "telprox.conf";

bool relay_buffer( int, int );
void clear_fds();
int proxy_init();
int net_main();
void manage_connections();

#endif /* TELPROX_H */
