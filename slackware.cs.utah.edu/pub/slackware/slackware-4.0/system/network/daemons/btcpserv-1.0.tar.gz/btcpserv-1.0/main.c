/*
 * btcpserv. A simple tcp server that binds to specified addresses
 * and ports. 
 *
 * Copyright (C) 1998 Joe Vaughan <joev@freddyfrog.com>
 * 
 * See README file for info and COPYING file for copying policy.
 *
 * Revision History:
 *
 * 12 Sept 1998 - 1.0 Original Revision 
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <signal.h>
#include <wait.h>
#include <unistd.h>
#include <sys/time.h>

#define PROGN "btcpserv"

#define socket_perror(a) syslog(LOG_ERR,a)

void init_sighandles();
void usage();

handle_sig_child(int sig) {
	int status;
	waitpid (-1 , &status, WNOHANG );
	syslog(LOG_NOTICE,"reaping child");
	init_sighandles();
}

void init_sighandles()
{
  signal(SIGCHLD,(void *) handle_sig_child);
}

int main(argc,argv,envp)
	 int argc;
	 char **argv;
	 char **envp;
{
  struct hostent *hostentry;
  struct sockaddr_in sin,sin2;
  struct linger mylinger;
  char *program,*address=NULL,*portstr=NULL,*handler=NULL;
  struct timeval tv;
  int socketfd,listenfd,n,on=1,retval,PORT,c;

  char *optstring="a:p:x:";

  extern void initsetproctitle __P((int, char **, char **));

  tv.tv_sec = 1;
  tv.tv_usec = 0;

  if (argc < 2) usage();
  
  /* Get optional arguments */
  while((c = getopt(argc,argv,optstring))!=-1) {
        switch(c) {
        case 'a':
          address=optarg;
          break;
        case 'p':
          portstr=optarg;
          break;
		case 'x':
		  handler=optarg;
		  break;
        case '?':
		  printf("no such option : %c\n",c);
          usage();

          break;
        }
  }

  /* have to save the handler prog because setproctitle munges the command line */

  program = (char *)malloc(strlen(handler)+1);
  strcpy (program,handler);

  /* Initialise program */

  initsetproctitle(argc, argv, envp);

  init_sighandles();

  openlog(PROGN,LOG_PID | LOG_CONS, LOG_DAEMON);

  
  /* set up listening socket... */
  listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if (listenfd < 0) {
	socket_perror("can't open listening socket");
	exit(-1);
  }

  PORT=atol(portstr);

  /*
   *  Set the "REUSEADDR" option on this socket. This will allow us
   *  to bind() to it EVEN if there already connections in progress
   *  on this port number. Otherwise, we would get an "Address already
   *  in use" error.
   */
  
  if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0) {
	fprintf(stderr,"%s: setsockopt\n",PROGN);
	exit(-1);
  }
  
  /*
   *  Create a "sockaddr_in" structure which describes the port we
   *  want to listen to. Address INADDR_ANY means we will accept
   *  connections to any of our local IP addresses.
   */
  
  sin.sin_family = AF_INET;
  sin.sin_addr.s_addr = inet_addr(address);
  sin.sin_port = htons(PORT);
  
  /*
   *  Bind to that address...
   */
  
  if (bind(listenfd, &sin, sizeof (sin)) < 0) {
	fprintf(stderr,"%s: bind failed\n",PROGN);
	exit(-1);
  }
  
  /*
   * Fork... we're a real server goddammit!
   */
  if (fork()) 
	exit(0);
  
  syslog(LOG_NOTICE,"started, listening on %s",address);
  /*
   *  Declare to the kernel that we want to listen for connections
   *  on this port, and that the kernel may queue up to five such
   *  connections for us.
   */
  
  if (listen(listenfd, 128) < 0) {
	socket_perror("listen failed");
	exit(-1);
  }
  
  setproctitle(PROGN,"awaiting connections on %s port %i",address,PORT);

  for(;;) {
	/*
	 * Call accept to accept a new connection. This 'peels'
	 * a connection off of the original socket and returns to us
	 * a new channel to the connection. We could now close
	 * down the original socket if we didn't want to handle
	 * more connections.
	 */
	
	n = sizeof(sin2);		/* Pass in the length */
	
	socketfd = accept(listenfd, &sin2, &n);
	if (socketfd < 0) {
	  socket_perror("accept failed");
	  close(socketfd);
	}
	else {
	  retval = handle_connection(listenfd,socketfd,sin2,program);
	}
	close(socketfd);
  }
}  

int handle_connection(int listenfd, int socketfd, struct sockaddr_in name, const char *handler)
{
  pid_t pid;
  int namelen=sizeof(name);
  int buffering_type=_IOLBF;
  struct linger slinger;

  /* Now fork the accepting process */
  
  pid = fork();
  
  /* Handle the child process */
  
  if (pid == 0)
	{
	  
	  if (getpeername(socketfd, (struct sockaddr *)&name, &namelen) < 0) {
		syslog(LOG_ERR,"getpeername failed");
		exit (-1);
	  }
	  else
		syslog(LOG_INFO,"connection accepted from %s",inet_ntoa(name.sin_addr));
			  
	  /* Close listening socket */
	  shutdown(listenfd,2);
	  close(listenfd);
		
	  /* set socket linger option */
	  slinger.l_onoff=1;
	  slinger.l_linger=1;
	  setsockopt(socketfd,SOL_SOCKET,SO_LINGER,&slinger,sizeof(slinger));

	  setproctitle(PROGN,"connection from %s",inet_ntoa(name.sin_addr));
	  
	   // invoke some deep magic here...
	  close(0); close(1); close(2);
	  if(dup(socketfd) != 0 || dup(socketfd) != 1 || dup(socketfd) != 2 ) {
		socket_perror("Error duping socketfd to stdin/stdout.");
		return -1;
	  }
   	  close(socketfd);

	  setvbuf( stdin,  NULL, buffering_type, 0 );
	  setvbuf( stdout, NULL, buffering_type, 0 );
	  setvbuf( stderr, NULL, buffering_type, 0 );
	  syslog(LOG_NOTICE,"Execing command:%s",handler);
	  // is there a cleaner way do do this?
	  execl( "/bin/sh", "/bin/sh", "-c", (const char*)handler, NULL );

	  socket_perror ("Somebody pinch me so I know I'm not dreaming...");
	  socket_perror ("You shouldn't be able to get here.");
	  exit(1);
	}
  waitpid (-1 , &namelen, WNOHANG );
  return(0); 
}

void usage()
{
 printf("usage: %s -a <address to bind to> -p <port> -e <execute command>\n",PROGN);
 exit(1);
} 
