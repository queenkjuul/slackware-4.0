/*
 * $Id: common.h,v 1.2 1998/06/16 18:21:23 ams Exp $
 * Copyright 1998 ams@wiw.org (Abhijit Menon-Sen)
 */

#include <ctype.h>
#include <getopt.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syslog.h>
#include <sys/types.h>

#include "global.h"

/* maximum line length in configuration file */
#define MAXLINE 80

#define MTU 4352

/* command line parameters */
static struct option par[]={ {"file", 1, 0, 0},
                             {"no-resolve", 0, 0, 0},
                             {"version", 0, 0, 0},
                             {0, 0, 0, 0}
                           };

/* functions in common.c */

extern int background(void);
extern int excepted(unsigned long int addr, char *str);
extern char *gethost(unsigned long int addr);
extern short int loglevel(char *str);
extern short int facility(char *str);
