/*
 * $Id: global.h,v 1.3 1998/06/16 18:22:14 ams Exp $
 * Copyright 1998 ams@wiw.org (Abhijit Menon-Sen)
 */

#include <unistd.h>

#define IGNORE 0

/* list of hosts to ignore */
struct ex {
    char *host;
    struct ex *link;
} root;
