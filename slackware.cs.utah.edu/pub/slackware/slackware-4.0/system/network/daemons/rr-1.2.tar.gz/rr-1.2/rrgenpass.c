/* Matt Hartley
   hartlw@rpi.edu
   http://www.rpi.edu/~hartlw

   26 Sep 97
   This is the remote reboot password generation program.

   */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "menc.h"
#include "config.h"

void main(void) {
  char wholeword[MAXWORDLEN]="\0";
  char cryptword[MAXWORDLEN]="\0";
  char finalword[MAXWORDLEN*MAXNETMULT*2]="\0";
  char salt[2];
  
  FILE *rrpassfile;
  
  if (!OVERRIDEROOT) {
    printf("Error.  Please consult the README and config.h for help.\n");
    exit(1);
  }
  
  printf("Please enter your word:\n");
  scanf("%s",&wholeword);
  
  /* Generate a pseudo-random salt */
  salt[0]=65+(int)(26.0*rand()/(RAND_MAX+1.0));
  salt[1]=97+(int)(26.0*rand()/(RAND_MAX+1.0));
  
  /* Crypt and then encode it */
  strcpy(cryptword,crypt(wholeword,salt));
  CompleteEncode(cryptword,finalword);

  /* Write it to a file */
  rrpassfile=fopen(EXTPASSWDFILE,"w");
  if (rrpassfile==NULL) {
    perror("Error opening file.");
    exit(1);
  }
  fprintf(rrpassfile,"%c%c%s\n",salt[0],salt[1],finalword);
  fclose(rrpassfile);
}
 
