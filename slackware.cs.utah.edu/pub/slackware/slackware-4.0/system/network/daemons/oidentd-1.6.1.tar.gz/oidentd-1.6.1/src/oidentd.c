/*
** oidentd - ojnk ident daemon
** Copyright (C)1998,1999 Odin (odin@ojnk.nu)
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA
*/

#include <config.h>
#include <oidentd.h>

#if defined(__linux__) && defined(MASQ_SUPPORT)
int fwdport = DEFAULT_PORT;
u_long proxy;
#endif
char *charset = NULL;
u_int flags = 0;

int main(int argc, char **argv) {
	uid_t uid = -2;
	gid_t gid = -2;
	u_long addr = htonl(INADDR_ANY);
	u_int timeout = DEFAULT_TIMEOUT, wtimeout = DEFAULT_WTIMEOUT;
	int port = DEFAULT_PORT;
	int opt;

#if defined(__linux__) && defined(MASQ_SUPPORT)
	while ((opt = getopt(argc, argv, "a:Ac:def:g:himnNop:P:rsSt:T:u:vVwW")) != EOF)
#else
	while ((opt = getopt(argc, argv, "a:Ac:deg:hinNop:rsSt:T:u:vVwW")) != EOF)
#endif
{
		switch (opt) {
			case 'a':
				if (get_addr(optarg, &addr) == -1) {
					fprintf(stderr, "Fatal: Unknown host: %s\n", optarg);
					exit(-1);
				}
				break;
			case 'A':
				flags |= ALL;
				break;
			case 'c':
				charset = optarg;
				break;
			case 'd':
				flags |= DEBUG;
				break;
			case 'e':
				flags |= HIDEE;
				break;
#if defined(__linux__) && defined(MASQ_SUPPORT)
			case 'f':
				flags |= FWD;
				if (valid_number(optarg)) {
					fwdport = atoi(optarg);
					if (!VALID_PORT(fwdport)) {
						fprintf(stderr, "Bad port: %s\n", optarg);
						exit(-1);
					}
				} else {
					fprintf(stderr, "Bad port: %s\n", optarg);
					exit(-1);
				}
				break;
#endif
			case 'g':
				flags |= GID;
				if (valid_number(optarg))
					gid = (gid_t) atol(optarg);
				else {
					struct group *gr = getgrnam(optarg);
					if (gr == NULL) {
						fprintf(stderr, "Unknown group: %s\n", optarg);
						exit(-1);
					}
					gid = gr->gr_gid;
				}
				break;
			case 'i':
				flags |= INETD;
				break;
#if defined(__linux__) && defined(MASQ_SUPPORT)
			case 'm':
				flags |= MASQ;
				break;
#endif
			case 'n':
				flags |= NUMERIC;
				break;
			case 'N':
				flags |= NOIDENT;
				break;
			case 'o':
				flags |= HIDEO;
				break;
			case 'p':
				if (valid_number(optarg)) {
					port = atoi(optarg);
					if (!VALID_PORT(port)) {
						fprintf(stderr, "Bad port: %s\n", optarg);
						exit(-1);
					}
				} else {
					fprintf(stderr, "Bad port: %s\n", optarg);
					exit(-1);
				}
				break;
#if defined(__linux__) && defined(MASQ_SUPPORT)
			case 'P':
				flags |= PROXY;
				if (get_addr(optarg, &proxy) == -1) {
					fprintf(stderr, "Fatal: Unknown host: %s\n", optarg);
					exit(-1);
				}
#endif
				break;
			case 'r':
				flags |= RANDOM;
				break;
			case 's':
				flags |= SPOOF;
				break;
			case 'S':
				flags |= (SPOOF | REVSPOOF);
				break;
			case 't':
				timeout = (u_int) atoi(optarg);
				break;
			case 'T':
				wtimeout = (u_int) atoi(optarg);
				break;
			case 'u':
				flags |= UID;
				if (valid_number(optarg))
					uid = (uid_t) atol(optarg);
				else {
					struct passwd *pw = getpwnam(optarg);
					if (pw == NULL) {
						fprintf(stderr, "Unknown user: %s\n", optarg);
						exit(-1);
					}
					uid = pw->pw_uid;
				}
				break;
			case 'v':
			case 'V':
				print_version();
				exit(0);
			case 'w':
				flags |= WAIT;
				break;
			case 'W':
				flags |= WRAPPED;
				break;
			case 'h':
			default:
				print_usage(argv[0]);
				exit(0);
		}
	}

	main_loop(uid, gid, port, timeout, wtimeout, addr);

	/* not reached */

	exit(0);
}

/*
** Setup the daemon and handle new connections.
*/

void main_loop(uid_t uid, gid_t gid, int port, u_int timeout, u_int wtimeout, u_long addr) {
	int listenfd = -1, connectfd, len = sizeof(struct sockaddr);
	struct sockaddr cliaddr;

	if (!(flags & INETD)) {
		listenfd = setup_listen(port, addr);

		if (listenfd == -1) {
			fprintf(stderr, "Fatal: Unable to setup listening socket.\n");
			exit(-1);
		}

		if (go_background(listenfd) == -1) {
			fprintf(stderr, "Fatal: Couldn't properly fork into the back.\n");
			exit(-1);
		}

		if (drop_privs(uid, gid) == -1) {
			fprintf(stderr, "Fatal: Couldn't drop privileges.\n");
			exit(-1);
		}
	}

	openlog("oidentd", LOG_PID | LOG_CONS | LOG_NDELAY, FACILITY);

	if (flags & RANDOM) {
		struct timeval tv;
		gettimeofday(&tv, NULL);
		srandom(tv.tv_sec ^ (tv.tv_usec << 11));
	}

#ifdef USE_KMEM
	if (k_open()) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: Can't open kernel memory device, exiting");
		exit(-1);
	}
#endif

	signal(SIGALRM, sigalrm);
	signal(SIGCHLD, sigchld);

	if (!(flags & INETD)) {
		for (;;) {
			connectfd = accept(listenfd, &cliaddr, &len);

			if (connectfd == -1)
				continue;

			if (!fork()) {
				close(listenfd);
				alarm(timeout);
				service_request(connectfd);
				exit(0);
			}
			close(connectfd);
		}
	} else {
		if (!(flags & WAIT)) {
			if (drop_privs(uid, gid) == -1) {
				if (flags & DEBUG)
					syslog(DPRI, "Fatal: Couldn't drop privs.");
				exit(-1);
			}
			alarm(timeout);
			service_request(fileno(stdin));
			close(0);
			exit(0);
		} else {
			int ret = -1;
			fd_set readfds;
			struct timeval tv;

			service_request(fileno(stdin));

			listenfd = fileno(stdin);

			if (listen(listenfd, 3) == -1) {
				if (flags & DEBUG)
					syslog(DPRI, "Fatal: listen: %m");
				exit(-1);
			}

			if (drop_privs(uid, gid) == -1) {
				if (flags & DEBUG)
					syslog(DPRI, "Fatal: Couldn't drop privs.");
				exit(-1);
			}

			for (;;) {
				do {
					FD_ZERO(&readfds);
					FD_SET(listenfd, &readfds);

					tv.tv_sec = wtimeout;
					tv.tv_usec = 0;

					ret = select(listenfd + 1, &readfds, NULL, NULL, &tv);
				} while (ret < 0 && errno == EINTR);

				if (ret == 0)
					exit(0);
				else {
					connectfd = accept(listenfd, &cliaddr, &len);

					if (connectfd == -1)
						continue;

					if (!fork()) {
						close(listenfd);
						alarm(timeout);
						service_request(connectfd);
						exit(0);
					}
					close(connectfd);
				}
			}
		}
	}
}

/*
** Setup the listening socket.
*/

int setup_listen(int port, u_long addr) {
	const int one = 1;
	int listenfd;
	struct sockaddr_in sin;

	memset(&sin, 0, sizeof(sin));

	sin.sin_family = AF_INET;
	sin.sin_port = htons(port);
	sin.sin_addr.s_addr = addr;

	listenfd = socket(AF_INET, SOCK_STREAM, 0);

	if (listenfd == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: socket: %m");
		return (-1);
	}

	if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: setsockopt: %m");
		return (-1);
	}

	if (bind(listenfd, (struct sockaddr *) &sin, sizeof(struct sockaddr)) == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: bind: %m");
		return (-1);
	}

	if (listen(listenfd, 3) == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: listen: %m");
		return (-1);
	}

	return (listenfd);
}

/*
** Drop privileges and run with specified uid/gid.
*/

char drop_privs(uid_t uid, gid_t gid) {

	if (flags & UID) {
		struct passwd *pw = getpwuid(uid);

		if (pw == NULL) {
			if (flags & DEBUG)
				syslog(DPRI, "Error: getpwuid(%u): %m", uid);
			return (-1);
		}

		if (initgroups(pw->pw_name, ((flags & GID) ? gid : pw->pw_gid)) == -1) {
			if (flags & DEBUG)
				syslog(DPRI, "Error: initgroups(%s, %u): %m", pw->pw_name, gid);
			return (-1);
		}
	}

	if (flags & GID) {
		if (setgid(gid) == -1) {
			if (flags & DEBUG)
				syslog(DPRI, "Error: setgid(%u): %m", gid, gid);
			return (-1);
		}
	}

	if (flags & UID) {
		if (setuid(uid) == -1) {
			if (flags & DEBUG)
				syslog(DPRI, "Error: setuid(%u): %m", uid, uid);
			return (-1);
		}
	}
	
	return (0);
}

/*
** Handle the client's request: read the client data and send the identd reply.
*/

int service_request(int sock) {
	char line[64];
	char suser[MAX_ULEN], orig_suser[MAX_ULEN];
	int lport = 0, fport = 0, uid = -1, len = sizeof(struct sockaddr_in);
	struct sockaddr_in sin;
	struct in_addr laddr, faddr;
	struct passwd *pw = NULL;
	uid_t orig_uid;

	if (getpeername(sock, (struct sockaddr *) &sin, &len) == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: getpeername: %m");
		return (-1);
	}

	faddr = sin.sin_addr;

	if (!(flags & WRAPPED)) {
		syslog(PRIORITY, "Connection from %s:%d",
			hostlookup(sin.sin_addr.s_addr), htons(sin.sin_port));
	}

	if (getsockname(sock, (struct sockaddr *) &sin, &len) == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: getsockname: %m");
		return (-1);
	}

	laddr = sin.sin_addr;

	len = sockread(sock, line, sizeof(line));

	if (len <= 0)
		return (-1);

	len = sscanf(line, "%d , %d", &lport, &fport);

	if (len < 2 || !VALID_PORT(fport) || !VALID_PORT(fport)) {
		dprintf(sock, "%d , %d : ERROR : %s\r\n",
			lport, fport, ERROR("INVALID-PORT"));
		syslog(PRIORITY, "[%s] %d , %d : ERROR : INVALID-PORT",
			inet_ntoa(faddr), lport, fport);
		return (0);
	}

#ifdef __linux__
	uid = get_user(lport, fport, &laddr, &faddr);
#else
	uid = get_user(htons(lport), htons(fport), &laddr, &faddr);
#endif

	if (uid == -1) {
#if defined(__linux__) && defined(MASQ_SUPPORT)
		if (flags & MASQ) {
			if (!masq(sock, lport, fport, &faddr))
				return (0);
		}
#endif
		dprintf(sock, "%d , %d : ERROR : %s\r\n",
			lport, fport, ERROR("NO-USER"));
		syslog(PRIORITY, "[%s] %d , %d : ERROR : NO-USER",
			inet_ntoa(faddr), lport, fport);
		return (0);
	}

	pw = getpwuid(uid);

	if (pw == NULL) {
		dprintf(sock, "%d , %d : ERROR : UNKNOWN-ERROR\r\n", lport, fport);
		syslog(PRIORITY, "[%s] %d , %d : ERROR : getpwuid",
			inet_ntoa(faddr), lport, fport);
		return (0);
	}
	
	if (flags & NUMERIC)
		snprintf(suser, sizeof(suser), "%d", pw->pw_uid);
	else {
		strncpy(suser, pw->pw_name, sizeof(suser));
		suser[sizeof(suser) - 1] = '\0';
	}

	strncpy(orig_suser, suser, sizeof(orig_suser));
	orig_suser[sizeof(orig_suser) - 1] = '\0';

	orig_uid = pw->pw_uid;

	if (flags & NOIDENT) {
		if (check_noident(pw->pw_dir)) {
			syslog(PRIORITY, "[%s] %d , %d : ERROR : HIDDEN-USER (%s)",
				inet_ntoa(faddr), lport, fport, pw->pw_name);
			dprintf(sock, "%d , %d : ERROR : %s\r\n",
				lport, fport, ERROR("HIDDEN-USER"));
			return (0);
		}
	}

	if (flags & SPOOF) {
		if (!pw->pw_uid || check_perm(pw->pw_name)) {
			char *spath = NULL;
			int fd;

			spath = xmalloc(strlen(pw->pw_dir) + sizeof(ISPOOF) + 1);
			strcpy(spath, pw->pw_dir);
			strcat(spath, ISPOOF);

			fd = open_ispoof(spath, pw);

			if (fd != -1) {
				char *temp = NULL;

				len = read(fd, suser, sizeof(suser) - 1);
				close(fd);
				if (len > 0) {
					suser[len] = '\0';

					temp = strchr(suser, '\n');

					if (temp != NULL)
						*temp = '\0';
				} else {
					if (flags & DEBUG)
						syslog(DPRI, "Error reading file \"%s\" : %m", spath);
					strncpy(suser, fix_ident(pw->pw_uid, pw->pw_name), sizeof(suser));
				}
			} else
				strncpy(suser, fix_ident(pw->pw_uid, pw->pw_name), sizeof(suser));
			free(spath);
		} else
			strncpy(suser, fix_ident(pw->pw_uid, pw->pw_name), sizeof(suser));

		if (pw->pw_uid) {
			struct passwd *check = NULL;
			check = getpwnam(suser);

			if (check && check->pw_uid != orig_uid) {
				syslog(LOG_CRIT, "User %s tried to masquerade as user %s.",
					orig_suser, check->pw_name);
				strncpy(suser, fix_ident(orig_uid, orig_suser), sizeof(suser));
			}

			if (fport < 1024 && !(flags & ALL))
				strncpy(suser, fix_ident(orig_uid, orig_suser), sizeof(suser));
		}
	}

	if (flags & RANDOM && !(flags & SPOOF))
		strncpy(suser, fix_ident(pw->pw_uid, pw->pw_name), sizeof(suser));

	dprintf(sock, "%d , %d : USERID : %s%s%s : %s\r\n", lport, fport,
		OS("UNIX"), (charset != NULL ? " , " : ""),
		(charset != NULL ? charset : ""), suser);

	syslog(PRIORITY, "[%s] Successful lookup: %d , %d : %s (%s)",
		inet_ntoa(faddr), lport, fport, suser, orig_suser);

	return (0);
}

/*
** Read a line from the identd.spoof file.  If too long, return empty
** Strips leading and trailing whitespace
** Returns EOF or 0
*/

int read_permline(FILE *f, char *buf, int bufl) {
	int c,i;
	bufl--;		/* Reserve space for \0 */

	for (i = 0 ; ;) {
		c = getc(f);

		switch (c) {
			case EOF:
				if (!i)
					return EOF;
				/* FALLTHROUGH */
			case '\n':
				if (i >= bufl)
					i = 0;
				while (i && isspace(buf[i - 1]))
					i--;
				buf[i] = '\0';
				return (0);
			default:
				if (!i && isspace(c))
					break;
				if (i < bufl)
					buf[i++] = c;
		}
	}
	/* NOTREACHED */
	return (0);
}

/*
** Check to make sure user is authorized to spoof identd replies
** (is in the /etc/identd.spoof file).
*/

char check_perm(const char *name) {
	FILE *fp = NULL;
	char line[24];
	int found = 0;

	fp = fopen(USERFILE, "r");

	if (fp == NULL) {
		if (flags & DEBUG)
			syslog(DPRI, "Cannot open file: %s: %m", USERFILE);
		return ((flags & REVSPOOF) ? 1 : 0);
	}

	while (read_permline(fp, line, sizeof(line)) != EOF) {
		if (*line == '#')
			continue;
		if (!strcmp(line, name)) {
			found = 1;
			break;
		}
	}

	fclose(fp);
	return ((flags & REVSPOOF) ? !found : found);
}

/*
** Generate a pseudo-random identd reply or toss pw_name back 
** depending on the value of the randomize flag.
*/

const char *fix_ident(uid_t uid, const char *nam) {
	static char suser[MAX_ULEN];
#ifdef NEW_RANDOM
	u_short i;
	const char valid[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
#endif

	if (!(flags & RANDOM)) {
		if (flags & NUMERIC) {
			snprintf(suser, sizeof(suser), "%d", uid);
			return (suser);
		} else
			return (nam);
	}

	if (!(flags & INETD)) {
		if (flags & RANDOM) {
			struct timeval tv;
			gettimeofday(&tv, NULL);
			srandom(tv.tv_sec ^ (tv.tv_usec << 11));
		}
	}

#ifndef NEW_RANDOM
	snprintf(suser, sizeof(suser), "%s%u", UPREFIX, random() % 100000);
#else
	for (i = 0 ; i < sizeof(suser) - 1 ; i++)
		suser[i] = valid[random() % (sizeof(valid) - 1)];
	suser[i] = '\0';
#endif
	return (suser);
}

/*
** Open an ".ispoof" file if it exists and matches the uid of the requestee.
*/

int open_ispoof(const char *path, const struct passwd *pw) {
	struct stat st;
	int fd;

	if (stat(path, &st) == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: stat: %s: %m", path);
		return (-1);
	}

	if (st.st_uid != pw->pw_uid) { /* someone's up to NO GOOD */
		syslog(LOG_CRIT,
			"Refused to read \"%s\" during request for %s (owner is UID %d)",
			path, pw->pw_name, st.st_uid);
		return (-1);
	}

	fd = open(path, O_RDONLY);

	if (fd == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error reading file \"%s\" : %m", path);
		return (-1);
	}

	if (fstat(fd, &st) == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: stat: %s: %m", path);
		close(fd);
		return (-1);
	}

	if (st.st_uid != pw->pw_uid) { /* close the stat-open race */
		syslog(LOG_CRIT,
			"Refused to read \"%s\" during request for %s (owner is UID %d)",
			path, pw->pw_name, st.st_uid);
		close(fd);
		return (-1);
	}

	return (fd);
}

/*
** Read a socket. (UNP v2)
*/

ssize_t sockread(int fd, char *buf, size_t len) {
	char c;
	u_int i;
	ssize_t ret;

	if (!buf)
		return (-1);

	for (i = 1; i < len ; i++) {
		ojnk:
			if ((ret = read(fd, &c, 1)) == 1) {
				*buf++ = c;
				if (c == '\n')
					break;
			} else if (ret == 0) {
				if (i == 1)
					return (0);
				else
					break;
			} else {
				if (errno == EINTR)
					goto ojnk;
				return (-1);
			}
	}
	*buf = '\0';

	return (i);
}

/*
** Check the existence of a ".noident" file.
*/

char check_noident(const char *homedir) {
	char *file = NULL;
	struct stat sbuf;

	file = (char *) xmalloc(strlen(homedir) + sizeof(NOIDENTF) + 1);
	strcpy(file, homedir);
	strcat(file, NOIDENTF);

	if (!lstat(file, &sbuf)) {
		free(file);
		return (1);
	}

	free(file);
	return (0);
}

/*
** Go background.
*/

char go_background(int ignore) {
	int fd;
	
	switch (fork()) {
		case -1:
			return (-1);
		case 0:
			break;
		default:
			_exit(0);
	}

	if (setsid() == -1)
		return (-1);

	chdir("/");
	umask(DEFAULT_UMASK);

	fd = open("/dev/null", O_RDWR);
	
	if (fd == -1)
		return (-1);

	dup2(fd, 0);
	dup2(fd, 1);
	dup2(fd, 2);

	for (fd = 3; fd < 64 ; fd++) {
		if (fd != ignore)
			(void) close(fd);
	}
	
	return (0);
}

void *xmalloc(size_t size) {
	void *temp = malloc(size);

	if (temp == NULL) {
		if (flags & DEBUG)
			syslog(DPRI, "fatal: malloc: no memory left.");
		exit(-1);
	}

	return (temp);
}

#ifndef HAVE_DPRINTF
int dprintf(int fd, const char *fmt, ...) {
	u_char buf[BUFSIZ];
	va_list ap;

	va_start(ap, fmt);
	vsnprintf(buf, sizeof(buf), fmt, ap);
	va_end(ap);

	return (write(fd, buf, strlen(buf)));
}
#endif

/*
** Return an IP address and/or hostname.
** NOTE: returns pointer to static space
*/

u_char *hostlookup(u_long addr) {
	static char hostname[256];
	struct hostent *host = NULL;
	struct in_addr in;

	in.s_addr = addr;

	host = gethostbyaddr((char *) &in, sizeof(struct in_addr), AF_INET);

	if (host != NULL) {
		if (strlen(host->h_name) <
			(sizeof(hostname) - sizeof(" (123.123.123.123)"))) {
				snprintf(hostname, sizeof(hostname), "%s (%s)",
					host->h_name, inet_ntoa(in));
			return (hostname);
		}
	}

	strncpy(hostname, inet_ntoa(in), sizeof(hostname));
	hostname[sizeof(hostname) - 1] = '\0';

	return (hostname);
}

/*
** Return a 32-bit, network byte ordered ipv4 address.
*/

int get_addr(const char *const hostname, u_long *addr) {
	struct in_addr in;

	if (inet_aton(hostname, &in)) {
		*addr = in.s_addr;
		return (0);
	} else {
		struct hostent *host = gethostbyname(hostname);
		if (host) {
			*addr = *((u_long *) host->h_addr);
			return (0);
		}
	}

	return (-1);
}

/*
** Returns non-zero if p points to a valid decimal number
*/

int valid_number(const char *p) {
/*
** Make sure that the user isn't really trying to specify an octal
** number... the only valid number that starts with zero is zero
** itself
**/
	if (*p == '0')
		return (p[1] == '\0');
	if (*p == '-')
		p++;
	if (*p == '\0' || *p == '0')
		return (0);
	for (; *p != '\0' ; p++) {
		if (!isdigit(*p))
			return (0);
	}

	return (1);
 }

/*
** Handle SIGCHLD.
*/

void sigchld(int stat) {
	while (waitpid(-1, &stat, WNOHANG) > 0);
	signal(SIGCHLD, sigchld);

	return;
}

/*
** Handle SIGALRM.
*/

void sigalrm(int sig) {
	(void) sig;
	syslog(PRIORITY, "Timeout for request.  Closing connection.");
	exit(0);
}

void print_usage(const char *whoami) {
	print_version();
	printf("Usage: %s [options]\n"
"  -a <address>\tBind to <address>. (Defaults to INADDR_ANY)\n"
"  -A\t\tWhen spoofing is enabled, enable users to spoof\n"
"    \t\tident on connections to privileged ports.\n"
"  -c <charset>\tSpecify an alternate charset. (Defaults to \"US-ASCII\")\n"
"  -d\t\tEnable debugging.\n"
"  -e\t\tReturn \"UNKNOWN-ERROR\" for all errors.\n"
#if defined(__linux__) && defined(MASQ_SUPPORT)
"  -f <port>\tForward requests for masqueraded hosts to the host on <port>\n"
#endif
"  -g <gid>\tRun with specified gid. (standalone and wait modes)\n"
"  -i\t\tRun from inetd.\n"
#if defined(__linux__) && defined(MASQ_SUPPORT)
"  -m\t\tEnable support for IP masquerading.\n"
#endif
"  -n\t\tReturn UIDs instead of usernames\n"
"  -N\t\tAllow identd hiding via \".noident\"\n"
"  -o\t\tReturn \"OTHER\" instead of the operating system.\n"
"  -p <port>\tListen for connections on specified port. (Defaults to %d)\n"
#if defined(__linux__) && defined(MASQ_SUPPORT)
"  -P <host>\t<host> acts as a proxy, forwarding connections to us.\n"
#endif
"  -r\t\tRandomize identd replies.\n"
"    \t\t\tNote: The -n and -r options are incompatible.\n"
"  -s\t\tAllow identd spoofing.\n"
"  -S\t\tSame as -s but allow all users but those listed in\n"
"    \t\t " USERFILE " to spoof replies.\n"
"  -t <seconds>\tWait for <seconds> before closing connection. (Defaults to %d)\n"
"  -T <seconds>\toidentd will remain accepting connections when run\n"
"    \t\twith -w for <seconds>.\n"
"  -u <uid>\tRun with specified uid. (standalone and wait modes)\n"
"  -v/-V\t\tDisplay version information and exit.\n"
"  -w\t\tDo not exit after handling requests. (Wait) (To be used with -i)\n"
"  -W\t\toidentd is wrapped. (tcp wrappers)\n"
"  -h\t\tThis help message.\n", whoami, DEFAULT_PORT, DEFAULT_TIMEOUT);
}

void print_version(void) {
	printf("%s version %s by Odin (odin@ojnk.nu, %s)\n",
		PACKAGE, VERSION, URL);
}
