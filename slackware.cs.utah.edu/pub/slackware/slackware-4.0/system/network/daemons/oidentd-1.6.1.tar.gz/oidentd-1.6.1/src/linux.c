/*
** oidentd - ojnk ident daemon
** Copyright (C)1998,1999 Odin (odin@ojnk.nu)
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA
*/

#include <config.h>
#include <oidentd.h>

#ifdef MASQ_SUPPORT
extern u_long proxy;
extern int fwdport;
#endif
extern char *charset;
extern u_int flags;

/*
** Determine the owner of the connection.
*/

int get_user(int lport, int fport, const struct in_addr *laddr, const struct in_addr *faddr) {
	int uid, portl, portf;
	FILE *fp = NULL;
	char buf[1024];
	struct in_addr remote, local;

	fp = fopen(CFILE, "r");

	if (fp == NULL) {
		if (flags & DEBUG)
			syslog(DPRI, "fopen: %s: %m", CFILE);
		return (-1);
	}

	fgets(buf, sizeof(buf) - 1, fp);

/*
** The line should never be longer than 1024 chars, so fgets should be OK.
*/
	while (fgets(buf, sizeof(buf) - 1, fp)) {
		if (sscanf(buf, "%*d: %lX:%x %lX:%x %*x %*X:%*X %*x:%*X %*x %d %*d %*d",
			(long *) &local, &portl, (long *) &remote, &portf, &uid) == 5) {
#ifdef MASQ_SUPPORT
			if (flags & PROXY) {
				if (faddr->s_addr == proxy && remote.s_addr != proxy
					&& lport == portl && fport == portf) {
					fclose(fp);
					return (uid);
				} else if (local.s_addr == laddr->s_addr && portl == lport
					&& remote.s_addr == faddr->s_addr && portf == fport) {
						fclose(fp);
						return (uid);
				}
			} else if (local.s_addr == laddr->s_addr && portl == lport
				&& remote.s_addr == faddr->s_addr && portf == fport) {
				fclose(fp);
				return (uid);
			}
#else
			if (local.s_addr == laddr->s_addr && portl == lport
				&& remote.s_addr == faddr->s_addr && portf == fport) {
					fclose(fp);
					return (uid);
			}
#endif
		}
	}

	fclose(fp);
	return (-1);
}

#ifdef MASQ_SUPPORT
/*
** Forward an ident request to another machine, return the response to the
** client that has connected to us and requested it.
*/

char fwd_request(int sock, int lport, int fport, const struct in_addr *remote) {
	int fsock;
	char buf[128], user[16];
	struct sockaddr_in sin;

	fsock = socket(AF_INET, SOCK_STREAM, 0);

	if (fsock == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: socket: %m");
		return (-1);
	}

	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(fwdport);
	sin.sin_addr.s_addr = remote->s_addr;
	
	if (connect(fsock, (struct sockaddr *) &sin, sizeof(sin)) == -1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: connect: %m");
		close(fsock);
		return (-1);
	}

	if (dprintf(fsock, "%d , %d\r\n", lport, fport) < 1) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: write: %m");
		close(fsock);
		return (-1);
	}

	if (sockread(fsock, buf, sizeof(buf)) < 1) {
		close(fsock);
		return (-1);
	}

	close(fsock);

	if (sscanf(buf, "%*d , %*d : %*s : %*s : %15s", user) != 1) {
		if (flags & DEBUG)
			syslog(DPRI, "[%s] Bad response: %s", inet_ntoa(*remote), buf);
		close(fsock);
		return (-1);
	}

	dprintf(sock, "%d , %d : USERID : %s%s%s : %s\r\n",
		lport, fport, OS("UNIX"),
		(charset != NULL ? " , " : ""),
		(charset != NULL ? charset : ""), user);

	syslog(PRIORITY,
		"[%s] (Forwarded) Successful lookup: %d , %d : USERID : %s : %s",
		inet_ntoa(*remote), lport, fport, OS("UNIX"), user);

	return (0);
}

/*
** Handle a request to a host that's IP masquerading through us.
*/

char masq(int sock, int lport, int fport, const struct in_addr *remote) {
	FILE *fp = NULL;
	char buf[1024], proto[12];
	char os[24], user[16];
	int mport, lportm, fportm;
	struct in_addr localm, remotem;

	fp = fopen(MASQFILE, "r");

	if (fp == NULL) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: %s: %m", MASQFILE);
		return (-1);
	}

	fgets(buf, sizeof(buf) - 1, fp);
	
	while (fgets(buf, sizeof(buf) - 1, fp)) {
		if (sscanf(buf, "%11s %lX:%X %lX:%X %X %*X %*d %*d %*u", proto,
			(long *) &localm, &lportm, (long *) &remotem, &fportm, &mport) != 6)
				continue;

		if (!strcmp(proto, "TCP") && mport == lport && fportm == fport
			&& remotem.s_addr == ntohl(remote->s_addr)) {
			if (flags & FWD) {
				struct in_addr fhost;

				fhost.s_addr = htonl(localm.s_addr);

				if (!fwd_request(sock, lportm, fportm, &fhost)) {
					return (0);
				} else {
					if (flags & DEBUG) {
						syslog(DPRI, "Forward to %s (%d %d) failed.",
							inet_ntoa(fhost), lportm, fportm);
					}
				}
			}
			if (!find_entry(htonl(localm.s_addr), user, sizeof(user) - 1,
				os, sizeof(os) - 1)) {
					dprintf(sock, "%d , %d : USERID : %s%s%s : %s\r\n",
						lport, fport, OS(os),
						(charset != NULL ? " , " : ""),
						(charset != NULL ? charset : ""), user);
					syslog(PRIORITY,
						"[%s] (Masqueraded) Successful lookup: %d , %d : USERID : %s : %s",
						inet_ntoa(*remote), lport, fport, OS(os), user);
					fclose(fp);
					return (0);
			}
		}
	}
	
	fclose(fp);
	return (-1);
}

/*
** Parse the masquerading map.
*/

char find_entry(u_long host, char *user, size_t ursz, char *os, size_t osz) {
	int c = 0;
	u_int i = 0;
	u_long addr = 0, mask = 0, mask2 = 0;
	FILE *fp = NULL;
	char buf[1024], *temp;
	
	fp = fopen(MAP, "r");

	if (fp == NULL) {
		if (flags & DEBUG)
			syslog(DPRI, "Error: fopen: %s: %m", MAP);
		return (-1);
	}

	for (;; i = 0) {
		while (i < sizeof(buf) - 1) {
			c = getc(fp);
			if (c == EOF)
				goto eof;
			if (c == '\n') {
				i = 0;
				continue;
			}
			if (c == '#' && i == 0)
				goto newline;
			if (isblank(c)) {
				if (i > 0)
					break;
				continue;
			}
			buf[i++] = c;
		}

		buf[i] = '\0';

		if (strlen(buf) == sizeof(buf)) {
			if (flags & DEBUG)
				syslog(DPRI, "Long line in %s.\n", MAP);
			while (!isspace(getc(fp)))
				;
		}
		
		temp = strchr(buf, '/');
		if (temp != NULL) {
			*temp++ = '\0';
			if (strchr(temp, '.') || !isdigit(*temp)) {
				if (get_addr(temp, &mask2) == -1) {
					if (flags & DEBUG)
						syslog(DPRI,
							"Error: %s: Invalid mask: %s/%s", MAP, buf, temp);
					goto newline;
				}
			} else {
				mask = strtoul(temp, NULL, 10);
				if (mask > 32) {
					if (flags & DEBUG)
						syslog(DPRI,
							"Error: %s: Invalid mask: %s/%s", MAP, buf, temp);
					goto newline;
				}
			}
		}

		if (get_addr(buf, &addr) == -1)
			goto newline;

		if (mask)
			mask2 = (1 << mask) - 1;
		if (mask2) {
			addr &= mask2;
			host &= mask2;
		}

		if (host != addr)
			goto newline;

		for (i = 0 ; i < ursz ;) {
			c = getc(fp);
			if (c == EOF)
				goto eof;
			if (c == '\n') {
				i = 0;
				goto newline;
			}
			if (isblank(c)) {
				if (i > 0)
					break;
				continue;
			}
			user[i++] = c;
		}

		user[i] = '\0';

		if (strlen(user) == ursz) {
			if (flags & DEBUG)
				syslog(DPRI, "Long line in %s.\n", MAP);
			while (!isspace(getc(fp)))
				;
		}

		for (i = 0 ; i < osz ;) {
			c = getc(fp);
			if (c == EOF)
				goto eof;
			if (c == '\n') {
				if (i)
					break;
				goto newline;
			}
			if (isblank(c)) {
				if (i)
					break;
				continue;
			}
			os[i++] = c;
		}

		os[i] = '\0';
		return (0);

newline:
		for (;;) {
			c = getc(fp);
			if (c == EOF)
				goto eof;
			if (c == '\n')
				break;
		}
	}

eof:
	fclose(fp);
	return (-1);
}

#endif /* masq */
