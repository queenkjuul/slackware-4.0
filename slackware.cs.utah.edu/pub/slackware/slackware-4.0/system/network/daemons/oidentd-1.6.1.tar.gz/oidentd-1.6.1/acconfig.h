/* See src/oidentd.h for more user-configurable values */
#undef PACKAGE
#undef VERSION
#undef USE_KMEM

/*
** Define this if you want random chars of the set [0-9A-Za-z] instead of
** UPREFIXxxxxx
*/
#undef NEW_RANDOM

/*
** Include support for the handling of requests for IP Masqueraded
** connections. (Linux only)
*/
#undef MASQ_SUPPORT

/*
** File containing connection information for IP masqueraded connections.
*/
#define MASQFILE "/proc/net/ip_masquerade"

/*
** File containing the identd replies to be used for hosts that masq through
** us.
*/
#define MAP "/etc/oidentd.users"

/*
** File containing connection information. (Linux)
*/
#define CFILE "/proc/net/tcp"

/*
** Name of file that contains the spoofed identd reply. The file should be
** in the user's home directory.
*/
#define ISPOOF "/.ispoof"

/*
** String prepended to a random number when the -r flag is specified
*/
#define UPREFIX "user"

/*
** If this file exists, in a user's home directory, identd replies will not
** be returned for that user.
*/
#define NOIDENTF "/.noident"

/*
** File containing the list of users allowed to spoof identd replies.
*/
#define USERFILE "/etc/identd.spoof"
