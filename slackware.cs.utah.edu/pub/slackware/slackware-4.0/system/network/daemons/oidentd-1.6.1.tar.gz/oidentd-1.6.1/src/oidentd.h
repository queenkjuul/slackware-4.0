/*
** oidentd - ojnk ident daemon
** Copyright (C)1998,1999 Odin (odin@ojnk.nu)
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA
*/

/*
** See ../config.h for user-configurable values.
*/

#ifndef __OIDENTD_H_
#define __OIDENTD_H_

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <syslog.h>
#include <signal.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <netdb.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define WAIT 0x01
#define REVSPOOF 0x02
#define HIDEO 0x04
#define HIDEE 0x08
#define INETD 0x10
#define SPOOF 0x20
#define RANDOM 0x40
#define ALL 0x80
#define WRAPPED 0x100
#define DEBUG 0x200 
#define UID 0x400
#define GID 0x800
#define NOIDENT 0x1000
#define NUMERIC 0x2000
#define MASQ 0x4000
#define FWD 0x8000
#define PROXY 0x10000

/* Maximum length of identd replies */
#define MAX_ULEN 10

#define DEFAULT_PORT 113
#define DEFAULT_TIMEOUT 30
#define DEFAULT_WTIMEOUT 120
#define DEFAULT_UMASK 022

#define FACILITY LOG_DAEMON
#define PRIORITY LOG_INFO
#define DPRI LOG_DEBUG

#define ERROR(x) ((flags & HIDEE) ? "UNKNOWN-ERROR" : (x))
#define OS(x) ((flags & HIDEO) ? "OTHER" : (x))
#define VALID_PORT(p) ((p != 0 && ((p & 0xffff) == p)))

#define URL "http://www.ojnk.nu/~odin"

int get_user(int, int, const struct in_addr *, const struct in_addr *);
int open_ispoof(const char *, const struct passwd *);
int setup_listen(int, u_long);
int service_request(int);
#ifndef HAVE_DPRINTF
int dprintf(int, const char *, ...);
#endif
void print_usage(const char *);
void print_version(void);
void main_loop(uid_t, gid_t, int, u_int, u_int, u_long);
void sigchld(int);
void sigalrm(int);
void *xmalloc(size_t);
__inline__ char drop_privs(uid_t, gid_t);
#if defined(__linux__) && defined(MASQ_SUPPORT)
char masq(int, int, int, const struct in_addr *);
char find_entry(u_long, char *, size_t ursz, char *, size_t);
char fwd_request(int, int, int, const struct in_addr *);
#endif /* __linux && masq */
#if !defined(__linux__)
int k_open(void);
#endif /* __linux__ */
char check_noident(const char *);
char check_perm(const char *);
char go_background(int);
u_char *hostlookup(u_long);
int get_addr(const char *const, u_long *);
ssize_t sockread(int, char *, size_t);
const char *fix_ident(uid_t, const char *);
int valid_number(const char *);
int read_permline(FILE *, char *, int);
#endif /* __OIDENTD_H_ */
