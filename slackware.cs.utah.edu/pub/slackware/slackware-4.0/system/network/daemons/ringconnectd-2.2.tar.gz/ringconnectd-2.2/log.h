#ifndef _LOG_H
#define _LOG_H

#ifndef AND_A_VOICE_BOOMS_OUT_THIS_IS_LOG_C_CALLING
// SHH! we don't want log.c to hear this!
extern void log(const char* format, ...);
extern void fatal(const char* format, ...);
extern void write_fd(int fd, const char* format, ...);
extern void write_perror(const char* format, ...);
extern void write_error(int is_fatal, const char* format, ...);
#endif

void mode_syslog(char** argv);

#endif
