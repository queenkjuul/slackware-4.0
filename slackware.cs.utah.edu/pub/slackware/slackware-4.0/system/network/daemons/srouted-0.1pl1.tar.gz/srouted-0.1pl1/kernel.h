/* kernel.h -- interface to kernel routing mechanisms */

/*
 *	$Id: kernel.h,v 1.1 1995/01/27 04:44:50 buhr Exp $
 */

#ifndef INC_KERNEL_H
#define INC_KERNEL_H

void kr_getifconf( void );
void kr_delroute( int route );
void kr_addroute( int route );

#endif INC_KERNEL_H
