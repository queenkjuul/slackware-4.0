/* input.h -- input processing */

/*
 *	$Id: input.h,v 1.1 1995/01/27 04:44:50 buhr Exp $
 */

#ifndef INC_INPUT_H
#define INC_INPUT_H

#include <sys/socket.h>
#include <sys/types.h>
#include <protocols/routed.h>

void in_processrip( struct rip *rip, int length, struct sockaddr *safrom);
int in_countentries( int length );

#endif INC_INPUT_H
