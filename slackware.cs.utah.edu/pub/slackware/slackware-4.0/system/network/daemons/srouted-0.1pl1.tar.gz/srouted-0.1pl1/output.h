/* output.h -- RIP output */

/*
 *	$Id: output.h,v 1.2 1995/02/15 02:22:11 buhr Exp $
 */

#ifndef INC_OUTPUT_H
#define INC_OUTPUT_H

#include "table.h"

#include <sys/socket.h>
#include <sys/types.h>
#include <protocols/routed.h>

#define OUT_MAXPACKETLEN	512

void out_rip( struct rip *rip, int length, struct tb_address *dest,
	     u_char ripcmd );
void out_update( int route );
void out_table( struct tb_address *dest );
void out_gettable( struct rip *rip, int maxlength );

#endif INC_OUTPUT_H
