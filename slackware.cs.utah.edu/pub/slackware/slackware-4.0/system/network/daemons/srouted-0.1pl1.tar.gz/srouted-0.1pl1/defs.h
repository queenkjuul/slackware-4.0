/* defs.h -- definitions required everywhere */

/*
 *	$Id: defs.h,v 1.2 1995/02/16 03:46:45 buhr Exp $
 */

#ifndef INC_DEFS_H
#define INC_DEFS_H

#include "error.h"
#include "timer.h"

#include <errno.h>

#ifndef DEFEXTS
#define EXTERN extern
#else
#define EXTERN
#endif DEFEXTS

#define PAGESIZE 4096
EXTERN char page[PAGESIZE];
EXTERN unsigned short g_routedport
#ifdef DEFEXTS
= 520
#endif
;
EXTERN int g_rs;  /* route socket */
EXTERN int g_tracelevel
#ifdef DEFEXTS
= 1
#endif
;
EXTERN int g_tracenlevel
#ifdef DEFEXTS
= 0
#endif
;
#undef EXTERN

#endif INC_DEFS_H
