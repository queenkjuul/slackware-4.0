char version[] = "Universal NFS Server 2.2beta23";
