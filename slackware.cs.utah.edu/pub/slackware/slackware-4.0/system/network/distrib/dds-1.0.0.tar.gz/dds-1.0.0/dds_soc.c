/*
 * dds_soc.c  Peter F Gray  Feb 98
 * Socket routines for the Distributed Dependancy System
*/
#include <sys/types.h>
#include <sys/socket.h>
/* #include <linux/in.h> */
#include <netinet/in.h>
#include "dds_soc.h"

int sock_recv (int sock, struct sockmess *buff)
{
   int i, elen, alen;
   i = recv (sock,buff,sizeof(buff->len),0); /* get the 2 bytes (len) */
   if (i <= 0) return (i);
   elen = htons(buff->len);
   alen = recv (sock,buff->data,elen,0);
   if (alen <= 0) return (alen);
   return (alen);
}
