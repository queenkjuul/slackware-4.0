#ifndef __dds_job_h_
#define __dds_job_h_
#include <time.h>
#include <unistd.h>

/* codes for JOB.stat */
enum DDS_JOB_STAT {UNKNOWN,HOLD,WAIT,READY,SEND,RUN,COMP,FAIL};
char *DDS_JSD[]={"Unknown","Hold","Wait","Ready","Send","Run",
     "Completed","Failed"};

struct JOB {
   char num[5];               /* job number         */
   enum DDS_JOB_STAT stat;    /* current status     */
   char name[16];             /* job name           */
   uid_t uid;                 /* user ID            */
   char host[16];             /* target host        */
   char group[16];            /* job group          */
   char command[32];          /* job command        */
   char output[32];           /* job output         */
   int cstat;                 /* completion status  */
   time_t start;              /* time run requested */
   time_t complete;           /* completion time    */
   char ohost[16];            /* originating host   */
};

#endif
