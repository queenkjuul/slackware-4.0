#ifndef __dds_fio_h_
#define __dds_fio_h_

int lock_last (FILE *f, int recsize, char *lockname, char *lockdir,
	       int *lockid);
int lock_and_read (FILE *f, int recnum, int recsize, char *buff,
		   char *lockname, char *lockdir, int *lockid);
int lock_and_write (FILE *f, int recnum, int recsize, char *buff,
		   char *lockname, char *lockdir, int *lockid);
int read_only (FILE *f, int recnum, int recsize, char *buff);
int write_only (FILE *f, int recnum, int recsize, char *buff);

#endif
