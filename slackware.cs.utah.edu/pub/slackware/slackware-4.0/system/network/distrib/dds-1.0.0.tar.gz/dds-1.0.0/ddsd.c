/*
 * ddsd.c  Peter F Gray  Feb 98
 * The Scheduler daemon for the Distributed Dependancy System
*/
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pwd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include "dds_job.h"
#include "dds_dep.h"
#include "dds_lck.h"
#include "dds_fio.h"

#define JOBFILE "JOB.DAT"
#define DEPFILE "DEP.DAT"
#define SHUTFILE "shutdown.dds"

void dds_init(char *lockdir, char *jobfile, char *depfile);
FILE *dds_open_job (char *filename);
FILE *dds_open_dep (char *filename);
int check_deps (FILE *job, FILE *dep, char *jobuser, char *jobname, uid_t completed);
int find_job (FILE *job, char *user, char *name);
int strncmp2 (char *str1, char *str2, int max);

static int dds_shutdown = 0;
static int debug = 0;
static int multi = 0;
char *dds_host, *dds_port, *data_path;
char lockdir[50];

int main (int argc, char *argv[])
{
   FILE *job, *dep, *shut;
   time_t now;
   int l, recnum = 1, lockid, deps;
   struct JOB jobrec;
   struct DEP deprec;
   struct passwd *passwd_ptr;
   struct timeval tv;
   char jobfile[50], depfile[50], syscommand[50], shutfile[50],timebuff[100];
   char juser[8];
   
   dds_init(lockdir,jobfile,depfile);
   if (dds_host && dds_port) {
      sprintf (syscommand,"ddsnet &");
      if (debug) printf("Command is %s\n",syscommand);
      l = system (syscommand);
      if (l != 0) printf ("Failed to start ddsnet: %d\n",l);
   }
   if (data_path) strcpy (shutfile,data_path);
   strcat (shutfile,SHUTFILE);
   job = dds_open_job(jobfile);
   dep = dds_open_dep(depfile);
   if (debug) printf ("JOB recsize is %d, DEP is %d\n",sizeof(jobrec),sizeof(deprec));
   while (!dds_shutdown) {
      if ((shut=fopen(shutfile,"r"))!=NULL) dds_shutdown = 1;
      while ((l=read_only(job,recnum,sizeof(jobrec),jobrec.num))==1) {
	 if (strncmp(jobrec.num,"00000",sizeof(jobrec.num))!=0) {
	    if (debug) printf ("Processing %5.5s ",jobrec.num);
	    passwd_ptr = getpwuid(jobrec.uid);
	    strncpy(juser,passwd_ptr->pw_name,sizeof(juser));
	    if (debug) printf ("%s %16.16s %s\n",juser,jobrec.name,DDS_JSD[jobrec.stat]);
	    if ((jobrec.stat == READY && (jobrec.uid == getuid() || multi)) ||
		(jobrec.stat == WAIT &&
		 (deps=check_deps(job,dep,juser,jobrec.name,jobrec.complete))==0)) {
	       jobrec.start = time(NULL);
	       strftime(timebuff,100,"%X %x",localtime(&jobrec.start));
	       if (strncmp("        ",jobrec.host,8)!=0)
		 printf ("%s Ready to Run %16.16s for %8s (%8s)\n",timebuff,jobrec.name,juser,jobrec.host);
	       else
		 printf ("%s Ready to Run %16.16s for %8s\n",timebuff,jobrec.name,juser);
	       jobrec.stat = RUN;
	       l = lock_and_write (job,recnum,sizeof(jobrec),jobrec.num,JOBFILE,lockdir,&lockid);
	       fflush (job);
	       if (l==1) {
		  if (multi && jobrec.uid != getuid())
		    sprintf (syscommand,"su -c\"ddsr %d &\" %s",recnum,juser);
		  else
		    sprintf (syscommand,"ddsr %d &",recnum);
		  if (debug) printf("Command is %s\n",syscommand);
		  l = system (syscommand);
		  if (l != 0) printf ("Failed to initiate run: %d\n",l);
	       }
	       else
		 printf ("Could not initiate run: %d %d\n",l,errno);
	    }
	    l = remove_lock(JOBFILE,lockdir,recnum,lockid);
	 }
	 recnum++;
      }
      if (debug) printf("(%d) Sleeping\n",errno);
      sleep(15);
      recnum = 1;
   }
   fclose(job);
   fclose(dep);
   now = time(NULL);
   printf ("DDS: Shutdown on %s",ctime(&now));
   return 0;
}

void dds_init (char *lockdir, char *jobfile, char *depfile)
{
   char *dds_debug, *dds_multi, *ddslck;
   time_t now;

   now = time(NULL);
   printf ("DDS: Startup on %s",ctime(&now));
   dds_debug = getenv("DDSDEBUG");
   if (dds_debug)
     if (*dds_debug == 'y' || *dds_debug == 'Y') debug = 1;
   if (debug) printf("dds_init: debug is on\n");
   dds_multi = getenv("DDSMULTI");
   if (dds_multi)
     if (*dds_multi == 'y' || *dds_multi == 'Y') multi = 1;
   if (debug && dds_multi) printf ("Multi flag is on\n");
   ddslck = getenv("DDSLCK");
   if (ddslck) strcpy(lockdir,ddslck);
   if (debug)
     if (ddslck)
       printf("Lock Directory is %s\n",lockdir);
     else
       printf ("Lock Directory unspecified\n");
   dds_host = getenv("DDSHOST");
   dds_port = getenv("DDSPORT");
   if (debug)
     if (dds_host && dds_port)
       printf("DDS Host is %s, port %s\n",dds_host,dds_port);
     else
       printf("DDS mode is standalone\n");
   data_path = getenv("DDSDAT");
   if (data_path) strcpy (jobfile,data_path);
   strcat (jobfile,JOBFILE);
   if (debug) printf ("Job file is %s\n",jobfile);
   if (data_path) strcpy (depfile,data_path);
   strcat (depfile,DEPFILE);
   if (debug) printf ("Dependancy file is %s\n",depfile);
   return;
}

FILE *dds_open_job (char *jobfile)
{
   FILE *job;
   if ((job = fopen(jobfile,"r+")) == NULL) {
      perror ("Cannot open Job file");
      dds_shutdown = 1;
   }
   return job;
}

FILE *dds_open_dep (char *depfile)
{
   FILE *dep;
   
   if ((dep = fopen(depfile,"r+")) == NULL)
     perror ("Cannot open Dependancy file");
   return dep;
}

int check_deps (FILE *job, FILE *dep, char *juser, char *jname, uid_t completed)
{
   int i, recnum, stat;
   struct JOB tmpjob;
   struct DEP deprec;
   
   rewind (dep);
   recnum = 1;
   if (debug) printf ("Checking Deps for: %8.8s %16.16s\n",juser,jname);
   while ((stat=read_only(dep,recnum,sizeof(deprec),deprec.name))==1) {
      if (debug) printf ("DEP(Seq) %8.8s %16.16s\n",deprec.user,deprec.name);
      if (strncmp2(deprec.user,juser,sizeof(deprec.user))==0
	  && strncmp2(deprec.name,jname,sizeof(deprec.name))==0) {
	 i = find_job(job,deprec.auser,deprec.aname);
	 if (i!=0) stat = read_only(job,i,sizeof(tmpjob),tmpjob.num);
	 if (i!=0 && (tmpjob.stat != COMP ||
		      difftime(tmpjob.complete,completed)<=0)) {
	    if (debug) printf ("Deps NOT met\n");
	    return recnum;
	 }
      }
      recnum++;
   }
   return 0;
}

int find_job (FILE *job, char *user, char *name)
{
   int recnum = 1, l;
   struct JOB jobtmp;
   uid_t juid;
   struct passwd *passwd_ptr;
   char u[9];
   
   for (l=0; user[l] != 0 && user[l] != ' ' && l<9; l++) u[l] = user[l];
   u[l] = 0;
   if (debug) printf ("Find job: %16s for %8s\n",name,u);
   if ((passwd_ptr = getpwnam(u)) == NULL) return 0;
   juid = passwd_ptr->pw_uid;
   if (debug) printf ("UID is %d\n",juid);
   while ((l=read_only(job,recnum,sizeof(jobtmp),jobtmp.num))==1) {
      if (jobtmp.uid == juid && strncmp2(name,jobtmp.name,sizeof(jobtmp.name))==0)
	return recnum;
      recnum++;
   }
   return 0;
}

int strncmp2 (char *str1, char *str2, int max)
{
   int i, eos1 = 0, eos2 = 0;
   
   for (i=0; i<max; i++) {
      if (eos1==0 && (str1[i]==' ' || str1[i]==0)) eos1 = 1;
      if (eos2==0 && (str2[i]==' ' || str2[i]==0)) eos2 = 1;
      if (eos1==1 && eos2==1) return 0;
      if (eos1==1 && str2[i] != ' ') return 1;
      if (eos2==1 && str1[i] != ' ') return 2;
      if (eos1==0 && eos2==0 && str1[i] != str2[i]) return 3;
   }
   return 0;
}
