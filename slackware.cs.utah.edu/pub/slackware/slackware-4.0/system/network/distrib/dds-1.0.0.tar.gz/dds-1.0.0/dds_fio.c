/*
 * dds_fio.c  Peter F Gray  Feb 98
 * File I/O routines for the Distributed Dependancy System
*/
#include <stdio.h>
#include "dds_lck.h"
#include "dds_fio.h"
#define DDSFIODEBUG 0

int lock_last (FILE *f, int recsize, char *lockname, char *lockdir,
	       int *lockid)
{
   int l, r;
   
   l = fseek(f,0L,SEEK_END);
   if (l!=0) return 0;
   l = ftell(f);
   if (DDSFIODEBUG) printf ("lock_last: l=%d, recsiz=%d\n",l,recsize);
   r = (l/recsize)+1;
   *lockid = make_lock(lockname,lockdir,r);
   if (*lockid==0) return 0;
   return r;
}
   
int lock_and_read (FILE *f, int recnum, int recsize, char *buff,
		   char *lockname, char *lockdir, int *lockid)
{
   int l;
   
   *lockid = make_lock (lockname,lockdir,recnum);
   if (*lockid==0) return 0;
   l = fseek (f,(recnum-1)*recsize,SEEK_SET);
   if (l!=0) return l;
   l = fread (buff,recsize,1,f);
   return l;
}

int lock_and_write (FILE *f, int recnum, int recsize, char *buff,
		   char *lockname, char *lockdir, int *lockid)
{
   int l;
   
   *lockid = make_lock (lockname,lockdir,recnum);
   if (*lockid==0) return 0;
   l = fseek (f,(recnum-1)*recsize,SEEK_SET);
   if (l!=0) return l;
   l = fwrite (buff,recsize,1,f);
   return l;
}

int read_only (FILE *f, int recnum, int recsize, char *buff)
{
   int l;
   
   l = fseek (f,(recnum-1)*recsize,SEEK_SET);
   if (l!=0) return l;
   l = fread (buff,recsize,1,f);
   return l;
}

int write_only (FILE *f, int recnum, int recsize, char *buff)
{
   int l;
   
   l = fseek (f,(recnum-1)*recsize,SEEK_SET);
   if (l!=0) return l;
   l = fwrite (buff,recsize,1,f);
   return l;
}
