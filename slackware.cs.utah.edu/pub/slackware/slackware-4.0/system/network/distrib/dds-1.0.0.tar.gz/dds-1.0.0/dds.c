/*
 * dds.c  Peter F Gray  Feb 98
 * The User Interface for the Distributed Dependancy System
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pwd.h>
#include <sys/types.h>
#include "dds_job.h"
#include "dds_dep.h"
#include "dds_lck.h"
#include "dds_fio.h"

#define DDSDEBUG 0
#define JOBFILE "JOB.DAT"
#define DEPFILE "DEP.DAT"
#define INSUFF 1
#define BADARG 2
#define NOAUTH 3
#define BADUSE 4
#define JOBEXI 5
#define BADJOB 6
#define NOTNET 7

FILE *job, *dep;
char lockdir[50], *dds_host, *dds_port;
struct JOB jobrec;
struct DEP deprec;
int multi = 0;

FILE *dds_open_job (char *lockdir);
FILE *dds_open_dep (void);
int find_job (uid_t uid, char *jobname);
void usage_error (int error_code);
void add_term (char *in, int size, char *out);

int main (int argc, char *argv[])
{
   int lockid, ll, c, l = 1, ro, recnum, brief = 0, all = 0, user = 0;
   struct passwd *pass_ptr;
   uid_t our_uid, root_uid;
   char *dds_multi, *dds_host, tbuff[255];
   FILE *tmp;
   
   if (argc==1) {
      usage_error(INSUFF); return INSUFF;
   }
   if ((job = dds_open_job(lockdir)) == NULL) {
      perror ("Cannot open JOB");
      return 1;
   }
   our_uid = getuid();
   pass_ptr = getpwnam("root");
   if (pass_ptr) root_uid=pass_ptr->pw_uid;
   dds_multi = getenv("DDSMULTI");
   if (dds_multi)
     if (*dds_multi == 'y' || *dds_multi == 'Y') multi = 1;
   dds_host = getenv("DDSHOST");
   dds_port = getenv("DDSPORT");
   dep = dds_open_dep();
   switch ((int) *argv[1]) {
    case 'a':
      if (argc < 5) {
	 usage_error(INSUFF); return INSUFF; 
      }
      ll = lock_last (job,sizeof(jobrec),JOBFILE,lockdir,&lockid);
      if (ll==0) {
	 printf ("File in use - Try again later\n");
	 return 2;
      }
      sprintf (jobrec.num,"%5d",ll);
      strncpy (jobrec.host,"        ",sizeof(jobrec.host));
      for (c=2; c!=argc; c++) {
	 switch ((int) *(argv[c]+1)) {
	  case 'n':
	    strncpy (jobrec.name, argv[c]+2,sizeof(jobrec.name));
	    break;
	  case 'c':
	    strncpy (jobrec.command, argv[c]+2,sizeof(jobrec.command));
	    break;
	  case 'o':
	    strncpy (jobrec.output, argv[c]+2,sizeof(jobrec.output));
	    break;
	  case 'g':
	    strncpy (jobrec.group, argv[c]+2, sizeof(jobrec.group));
	    break;
	  case 'h':
	    if (dds_host == NULL || dds_port == NULL) {
	       usage_error (NOTNET);
	       l = remove_lock (JOBFILE,lockdir,ll,lockid);
	       return (NOTNET);
	    }
	    strncpy (jobrec.host, argv[c]+2, sizeof(jobrec.host));
	    break;
	  case 'u':
	    pass_ptr = getpwnam(argv[c]+2);
	    if (pass_ptr) {
	       user = 1;
	       jobrec.uid = pass_ptr->pw_uid;
	    }
	    else {
	       usage_error (BADUSE);
	       l = remove_lock (JOBFILE,lockdir,ll,lockid);
	       return (BADUSE);
	    }
	    break;
	  default:
	    l = remove_lock (JOBFILE,lockdir,ll,lockid);
	    usage_error(BADARG);
	    return BADARG;
	 }
      }
      if (user && (our_uid != root_uid || !multi)) {
	 usage_error (NOAUTH);
	 l = remove_lock (JOBFILE,lockdir,ll,lockid);
	 return (NOAUTH);
      }
      if (!user) jobrec.uid = our_uid;
      if (find_job(jobrec.uid,jobrec.name) != 0) {
	 usage_error (JOBEXI);
	 l = remove_lock (JOBFILE,lockdir,ll,lockid);
	 return JOBEXI;
      }
      jobrec.stat = UNKNOWN;
      l = write_only (job,ll,sizeof(jobrec),jobrec.num);
      if (l!=1)
	perror ("Could not add job");
      else {
	 l = remove_lock (JOBFILE,lockdir,ll,lockid);
	 printf ("Job %d added\n",ll);
      }
      return 0;
      break;
    case 'n':
      if (argc < 5) {
	 usage_error(INSUFF); return INSUFF; 
      }
      pass_ptr = getpwnam(argv[3]);
      if (pass_ptr==NULL) {
	 usage_error(BADUSE); return BADUSE;
      }
      if (pass_ptr->pw_uid != our_uid && (our_uid != root_uid || !multi)) {
	 usage_error(NOAUTH); return NOAUTH;
      }
      ll = lock_last (dep,sizeof(deprec),DEPFILE,lockdir,&lockid);
      strncpy (deprec.name,argv[2],sizeof(deprec.name));
      if ((l=find_job(pass_ptr->pw_uid,deprec.name))==0) {
	 usage_error(BADJOB);
	 l = remove_lock (DEPFILE,lockdir,ll,lockid);
	 return BADJOB;
      }
      strncpy (deprec.user,pass_ptr->pw_name,sizeof(deprec.user));
      strncpy (deprec.aname,argv[4],sizeof(deprec.aname));
      strncpy (deprec.auser,argv[5],sizeof(deprec.auser));
      pass_ptr = getpwnam(argv[5]);
      if (pass_ptr==NULL) {
	 usage_error(BADUSE);
	 l = remove_lock (DEPFILE,lockdir,ll,lockid);
	 return BADUSE;
      }
      if ((l=find_job(pass_ptr->pw_uid,deprec.aname))==0) {
	 usage_error(BADJOB);
	 l = remove_lock (DEPFILE,lockdir,ll,lockid);
	 return BADJOB;
      }
      l = write_only (dep,ll,sizeof(deprec),deprec.name);
      if (l!=1)
	perror ("Could not add record");
      else
	 printf ("Dependancy %d added\n",ll);
      l = remove_lock (DEPFILE,lockdir,ll,lockid);
      break;
    case 'r':
      if (argc < 3) {
	 usage_error(INSUFF); return INSUFF; 
      }
      if (argc == 4) {
	 pass_ptr = getpwnam(argv[3]);
	 if (pass_ptr==NULL) {
	    usage_error(BADUSE); return BADUSE;
	 }
	 if (pass_ptr->pw_uid != our_uid && (our_uid != root_uid || !multi)) {
	    usage_error(NOAUTH); return NOAUTH;
	 }
	 jobrec.uid = pass_ptr->pw_uid;
      }
      else
	jobrec.uid = our_uid;
      if ((recnum = find_job(jobrec.uid,argv[2])) == 0) {
	 printf ("Cannot run - Job not found\n");
	 return 4;
      }
      if ((l=lock_and_read(job,recnum,sizeof(jobrec),jobrec.num,JOBFILE,lockdir,&lockid))==1) {
	 if (jobrec.stat != RUN || our_uid == root_uid || jobrec.uid == our_uid) {
	    jobrec.stat = READY;
	    if ((l=write_only (job,recnum,sizeof(jobrec),jobrec.num))!=1)
	      perror ("Could not update file");
	    else
	      printf ("Run requested for %s\n",jobrec.name);
	 }
	 else
	   printf ("Job is already running\n");
      }
      l = remove_lock (JOBFILE,lockdir,recnum,lockid);
      break;
    case 'g':
      if (argc < 3) {
	 usage_error(INSUFF); return INSUFF;
      }
      if (argc==4)
	if (strncmp(argv[3],"-a",2)==0)
	  if (our_uid == root_uid)
	    all = 1;
          else {
	    usage_error(NOAUTH); return NOAUTH;
	  }
      recnum = 1;
      while ((ro = read_only(job,recnum,sizeof(jobrec),jobrec.num))==1) {
	 if ((jobrec.uid == our_uid || all) &&
	     strncmp(jobrec.group,argv[2],sizeof(jobrec.group))==0 &&
	     (jobrec.stat == COMP || jobrec.stat == FAIL || jobrec.stat == UNKNOWN)) {
	    jobrec.stat = WAIT;
	    l = lock_and_write (job,recnum,sizeof(jobrec),jobrec.num,JOBFILE,lockdir,&lockid);
	    if (l==1)
	      printf ("Group start job: %16.16s\n",jobrec.name);
	    else
	      printf ("Could not group start job %16.16s (%d)\n",jobrec.name,errno);
	    l = remove_lock (JOBFILE,lockdir,recnum,lockid);
	 }
	 recnum++;
      }
      break;
    case 'j':
      if (argc!=1) {
	 for (c=2; c!=argc; c++) {
	    switch ((int) *(argv[c]+1)) {
	     case 'b':
	       brief = 1;
	       break;
	     case 'a':
	       all = 1;
	       break;
	     default:
	       break;
	    }
	 }
      }
      recnum = 1;
      printf ("Job#  Name             User     Status          Group            Host\n");
      while ((l=read_only(job,recnum,sizeof(jobrec),jobrec.num))==1) {
	 if (all || jobrec.uid==our_uid) {
	    pass_ptr = getpwuid(jobrec.uid);
	    printf ("%5.5s ",jobrec.num);
	    printf ("%16.16s ",jobrec.name);
	    printf ("%8.8s ",pass_ptr->pw_name);
	    printf ("%9.9s %5d %16.16s %8.8s\n",DDS_JSD[jobrec.stat],jobrec.cstat,jobrec.group,jobrec.host);
	    if (!brief) {
	       printf ("%32.32s %32.32s\n",jobrec.command,jobrec.output);
	       if (jobrec.start)
		 printf ("Started:   %s",ctime(&jobrec.start));
	       else
	         printf ("Started:   %s\n","Never");
	       if (jobrec.complete)
	         printf ("Completed: %s",ctime(&jobrec.complete));
	       else
	         printf ("Completed: %s\n","Never");
	    }
	 }
	 recnum++;
      }
      printf ("\n%d jobs exist\n",recnum-1);
      return 0;
    case 'd':
      rewind (dep);
      recnum = 1;
      printf ("Job Name         User      Runs after\n");
      while ((l=read_only(dep,recnum,sizeof(deprec),deprec.name))==1) {
	 printf ("%16.16s %8.8s   %16.16s %8.8s\n",deprec.name,deprec.user,
		 deprec.aname,deprec.auser);
	 recnum++;
      }
      printf ("\n%d dependancies\n",recnum-1);
      return 0;
    case 's':
      recnum = 1;
      if ((tmp = fopen("script.dds","w"))==NULL) {
	 perror ("Could not create script");
	 break;
      }
      else {
	 while ((l=read_only(job,recnum,sizeof(jobrec),jobrec.num))==1) {
	    if (strncmp(jobrec.num,"00000",5)!=0) {
	       add_term(jobrec.name,16,tbuff);
	       fprintf(tmp,"dds a -n%s ",tbuff);
	       add_term(jobrec.output,32,tbuff);
	       fprintf(tmp,"-o%s ",tbuff);
	       add_term(jobrec.command,32,tbuff);
	       fprintf(tmp,"-c%s ",tbuff);
	       add_term(jobrec.group,16,tbuff);
	       fprintf(tmp,"-g%s ",tbuff);
	       if (strncmp(jobrec.host,"        ",sizeof(jobrec.host))!=0) {
		  add_term(jobrec.host,8,tbuff);
		  fprintf(tmp,"-h%s ",tbuff);
	       }
	       pass_ptr = getpwuid(jobrec.uid);
	       if (pass_ptr)
		 fprintf(tmp,"-u%s\n",pass_ptr->pw_name);
	       else
		 fprintf(tmp,"\n");
	    }
	    recnum++;
	 }
	 recnum = 1;
	 while ((l=read_only(dep,recnum,sizeof(deprec),deprec.name))==1) {
	    add_term(deprec.name,16,tbuff);
	    fprintf(tmp,"dds n %s ",tbuff);
	    add_term(deprec.user,8,tbuff);
	    fprintf(tmp,"%s ",tbuff);
	    add_term(deprec.aname,16,tbuff);
	    fprintf(tmp,"%s ",tbuff);
	    add_term(deprec.auser,8,tbuff);
	    fprintf(tmp,"%s\n",tbuff);
	    recnum++;
	 }
	 fclose (tmp);
      }
      printf ("Script produced\n");
      break;
    default:
      printf ("Unknown argument: %c\n",*argv[1]);
      return 2;
   }
/*   ro = read_only(job,recnum,sizeof(jobrec),jobrec.num);
   if (ro==1) l = lock_and_read (job,recnum,sizeof(jobrec),jobrec.num,JOBFILE,lockdir,&lockid);
   if (l==1) {
      printf ("Job Num:");
      scanf ("%5c",jobrec.num);
      if (ro==1) {
         l = write_only (job,recnum,sizeof(jobrec),jobrec.num);
         if (l!=1) perror ("Could not write");
      }
      else {
	 l = lock_and_write (job,recnum,sizeof(jobrec),jobrec.num,JOBFILE,lockdir,&lockid);
	 if (l!=1) perror ("Could not add");
      }
      l = remove_lock (JOBFILE,lockdir,recnum,lockid);
   }
   else {
     printf ("Lock&Read %d\n",l);
     perror("Could not lock_and_read");
     } */
   return 0;
}

void usage_error (error_code)
{
   switch (error_code) {
    case INSUFF:
      printf ("Insufficient Arguments\n");
      break;
    case BADARG:
      printf ("Invalid Argument\n");
      break;
    case NOAUTH:
      printf ("You are not authorized to perform this\n");
      break;
    case BADUSE:
      printf ("Bad user specified\n");
      break;
    case JOBEXI:
      printf ("Cannot add - Job already exists\n");
      break;
    case BADJOB:
      printf ("Bad Job (or Job/User) specified\n");
      break;
    case NOTNET:
      printf ("DDS has not been Network enabled\n");
      break;
    default:
      break;
   }
   if (error_code > BADARG) return;
   printf ("Usage: dds [command] [arguments]\n\n");
   printf ("commands function        arguments\n");
   printf (" a       add job         -njobname -ooutputfile -ccommand -ggroup -uuser -hhost\n"
	   " g       group start     groupname -all_users\n"
	   " r       run job         jobname [username]\n"
	   " n       new dependancy  jobname username jobname username\n"
	   " j       list jobs       -brief -all_users\n"
	   " s       create script\n"
	   " d       list dependancies\n");
}

int find_job (uid_t uid, char *jobname)
{
   int recnum = 1, l;
   struct JOB jobtmp;
   
   if (DDSDEBUG) printf("find_job: %d %s\n",uid,jobname);
   while ((l=read_only(job,recnum,sizeof(jobtmp),jobtmp.num))==1) {
      if (jobtmp.uid == uid && strncmp(jobname,jobtmp.name,sizeof(jobtmp.name)) == 0)
	return recnum;
      if (DDSDEBUG) printf("find_job %d %s\n",jobtmp.uid,jobtmp.name);
      recnum++;
   }
   return 0;
}

FILE *dds_open_job (char *lockdir)
{
   char *data_path,*ddslck;
   char jobfile[50];
   FILE *job;

   ddslck = getenv("DDSLCK");
   if (ddslck) strcpy(lockdir,ddslck);
   data_path = getenv("DDSDAT");
   if (data_path) strcpy (jobfile,data_path);
   strcat (jobfile,JOBFILE);
   job = fopen(jobfile,"r+");
   return job;
}

FILE *dds_open_dep (void)
{
   char *data_path;
   char depfile[50];
   FILE *dep;

   data_path = getenv("DDSDAT");
   if (data_path) strcpy (depfile,data_path);
   strcat (depfile,DEPFILE);
   dep = fopen(depfile,"r+");
   return dep;
}

void add_term (char *in, int size, char *out)
{
   strncpy (out,in,size);
   out[size] = 0;
}
