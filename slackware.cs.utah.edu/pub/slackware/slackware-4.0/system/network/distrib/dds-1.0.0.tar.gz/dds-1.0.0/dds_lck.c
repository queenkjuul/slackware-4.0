/*
 * dds_lck.c  Peter F Gray  Feb 98
 * Locking routines for the Distributed Dependancy System
*/
#include <stdio.h>
#include <string.h>
#include <sys/file.h>
#define DDSLCKDEBUG 0

int make_lock (char *fnam, char *lockdir, int recnum)
{
   char flocknam[50], srec[9];
   int l;
   
   sprintf (srec,".%8.8d",recnum);
   strcpy (flocknam,lockdir);
   strcat (flocknam,fnam);
   strcat (flocknam,srec);
   l = open (flocknam,O_RDWR|O_CREAT|O_EXCL);
   if (DDSLCKDEBUG) {
      printf ("make_lock: %d\n",l);
      printf ("make_lock: %s\n",flocknam);
   }
   if (l<0) return 0;
   return l;
}

int remove_lock (char *fnam, char *lockdir, int recnum, int lockid)
{
   int i;
   char flocknam[50], srec[9];
   
   sprintf (srec,".%8.8d",recnum);
   strcpy (flocknam,lockdir);
   strcat (flocknam,fnam);
   strcat (flocknam,srec);
   i = close (lockid);
   i = remove (flocknam);
   return i;
}
