#ifndef __dds_soc_h_
#define __dds_soc_h_

#define SOCKMESS_MAX 4000

struct sockmess
{
   int len;
   char data[SOCKMESS_MAX];
};

#endif
