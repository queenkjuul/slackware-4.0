/*
 * ddsnet.c  Peter F Gray  Feb 98
 * The network comms daemon for the Distributed Dependancy System
*/
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pwd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include "dds_job.h"
#include "dds_dep.h"
#include "dds_lck.h"
#include "dds_fio.h"
#include "dds_soc.h"

#define JOBFILE "JOB.DAT"
#define DEPFILE "DEP.DAT"
#define SHUTFILE "shutdown.dds"

void dds_init(char *lockdir, char *jobfile, char *depfile);
FILE *dds_open_job (char *filename);
FILE *dds_open_dep (char *filename);
int find_job (FILE *job, char *user, char *name);
int strncmp2 (char *str1, char *str2, int max);
void run_request (FILE *job, struct JOB *jobrec);
void status_message (FILE *job, struct JOB jobrec);

int get_free_socket();

static int dds_shutdown = 0;
static int debug = 0;
static int multi = 0;
char *dds_host, *dds_port, *data_path;
int sockx;
struct sockaddr_in sockx_in;
struct sockaddr_in remote_addr;
struct hostent hostentstruct;
struct hostent *hostx;
#define MAX_CONNECTIONS FD_SETSIZE
struct sockmess sockmessfrom, sockmessto;
int server_sock[MAX_CONNECTIONS];
fd_set fdlist, fdlisttest;
char lockdir[50];

int main (int argc, char *argv[])
{
   FILE *job, *dep, *shut;
   time_t now;
   int l, ilen, istat, recnum = 1, lockid, deps, dds_connected = 0, namelen,
     sock, ls;
   struct JOB jobrec;
   struct DEP deprec;
   struct passwd *passwd_ptr;
   struct timeval tv;
   char jobfile[50], depfile[50], syscommand[50], shutfile[50];
   char juser[8];
   
   dds_init(lockdir,jobfile,depfile);
   if (data_path) strcpy (shutfile,data_path);
   strcat (shutfile,SHUTFILE);
   job = dds_open_job(jobfile);
   dep = dds_open_dep(depfile);
   FD_ZERO (&fdlist);
   if (debug) printf ("ddsnet: JOB recsize is %d, DEP is %d\n",sizeof(jobrec),sizeof(deprec));
   while (!dds_shutdown) {
      if (dds_host && dds_port) {
	 if (!dds_connected) {
	    if (debug) printf("ddsnet: Attempting to connect to net\n");
	    if ((sockx = socket (AF_INET, SOCK_STREAM, 0))==-1)
	      perror ("ddsnet: Control socket creation failed");
	    else {
	       if ((hostx=gethostbyname(dds_host))==NULL)
		 perror ("ddsnet: Failed to get host");
	       else {
		  hostentstruct = *hostx;
		  sockx_in.sin_family = hostentstruct.h_addrtype;
		  sockx_in.sin_port = htons(atoi(dds_port));
		  sockx_in.sin_addr = * ((struct in_addr *) hostentstruct.h_addr);
		  l = bind (sockx, (struct sockaddr *) &sockx_in, sizeof(sockx_in));
		  if (l==-1)
		    perror ("ddsnet: Could not bind");
		  else {
		     if ((l=listen(sockx,5))<0)
		       perror ("ddsnet: Listen failed");
		     else {
			server_sock[0] = sockx;
			namelen = sizeof (remote_addr);
			dds_connected = 1;
		     }
		  }
	       }
	    }
	 }
	 if (!dds_connected)
	   return 1;
	 else {
	    if (debug) printf("ddsnet: Waiting for message\n");
	    for (l=0; l<FD_SETSIZE; l++)
	      if (server_sock[l]) FD_SET (server_sock[l],&fdlist);
	    fdlisttest = fdlist;
	    ls = select (FD_SETSIZE,&fdlisttest,(fd_set *)0,(fd_set *)0,(struct timeval *)0);
	    if ((shut=fopen(shutfile,"r"))!=NULL) dds_shutdown = 1;
	    if (debug) printf ("ddsnet: %d socket(s) responded\n",ls);
	    if (ls == -1) {
	       perror ("ddsnet: Select failed");
	       return (2);
	    }
	    if (FD_ISSET(server_sock[0],&fdlisttest)) {
	       printf ("ddsnet: Connection request...\n");
	       l = get_free_socket();
	       if (l) {
		  if (debug) printf ("ddsnet: Slot %d will be used\n",l);
		  namelen = sizeof (remote_addr); /* accept resets it !!! */
		  sock = accept (server_sock[0],(struct sockaddr *) &remote_addr,&namelen);
		  if (sock == -1) {
		    perror ("ddsnet: Accept failed");
		  }
		  else {
		     server_sock[l] = sock;
		     if (debug) printf ("ddsnet: Sock is %d\n",server_sock[l]);
		  }
	       }
	       else
		 printf ("ddsnet: Ignoring - no free sockets\n");
	    }
	    else /* not a connection request... */ {
	       for (l=1; l<MAX_CONNECTIONS; l++) {
		  if (FD_ISSET(server_sock[l],&fdlisttest)) {
		     printf ("ddsnet: Msg on slot %d (sock %d)\n",l,server_sock[l]);
		     if ((istat = sock_recv (server_sock[l],&sockmessfrom))<=0) {
			perror ("ddsnet: Recv");
			FD_CLR(server_sock[l],&fdlist);
		        server_sock[l]=0;
		        printf ("ddsnet: Slot %d is now marked as free\n",l);
		     }
		     else {
			if (debug) printf ("ddsnet: Processing (%d data bytes)\n",istat);
			memcpy (jobrec.num,sockmessfrom.data,sizeof(jobrec));
			printf ("ddsnet: Job Num %5.5s, Jobname %16.16s\n",jobrec.num,jobrec.name);
			memcpy (sockmessto.data,sockmessfrom.data,sizeof(sockmessto.data));
			if (jobrec.stat==SEND)        /* run request        */
			  run_request (job,&jobrec);
			else                          /* job status message */
			  status_message (job,jobrec);
			memcpy (sockmessto.data,jobrec.num,sizeof(jobrec));
			ilen = sizeof(sockmessto.len) + sizeof(jobrec);
		        sockmessto.len = htons (sizeof(jobrec));
			if (debug) printf ("ddsnet: Sending ACK\n");
			if (debug) printf ("ddsnet: cstat is now %d\n",jobrec.cstat);
		        if ((istat = send (server_sock[l],&sockmessto,ilen,0))<0) {
			   perror ("ddsnet: Sending ACK");
			   server_sock[l] = 0;
			   printf ("ddsnet: Slot is now marked as free\n");
			}
		     }
		  }
	       }
	    }
	    if (debug) printf("ddsnet: Sleep (%d, %d)\n",l,errno);
	    sleep(5);
	 }
      }
   }
   now = time(NULL);
   printf ("ddsnet: Shutdown on %s",ctime(&now));
   fclose(job);
   fclose(dep);
   return 0;
}

void dds_init (char *lockdir, char *jobfile, char *depfile)
{
   char *dds_debug, *dds_multi, *ddslck;
   time_t now;

   now = time(NULL);
   printf ("ddsnet: Startup on %s",ctime(&now));
   dds_debug = getenv("DDSDEBUG");
   if (dds_debug)
     if (*dds_debug == 'y' || *dds_debug == 'Y') debug = 1;
   if (debug) printf("ddsnet_init: debug is on\n");
   dds_multi = getenv("DDSMULTI");
   if (dds_multi)
     if (*dds_multi == 'y' || *dds_multi == 'Y') multi = 1;
   if (debug && dds_multi) printf ("ddsnet: Multi flag is on\n");
   ddslck = getenv("DDSLCK");
   if (ddslck) strcpy(lockdir,ddslck);
   if (debug)
     if (ddslck)
       printf("ddsnet: Lock Directory is %s\n",lockdir);
     else
       printf ("ddsnet: Lock Directory unspecified\n");
   dds_host = getenv("DDSHOST");
   dds_port = getenv("DDSPORT");
   if (debug)
     if (dds_host && dds_port)
       printf("ddsnet: DDS Host is %s, port %s\n",dds_host,dds_port);
     else
       printf("ddsnet: DDS mode is standalone\n");
   data_path = getenv("DDSDAT");
   if (data_path) strcpy (jobfile,data_path);
   strcat (jobfile,JOBFILE);
   if (debug) printf ("ddsnet: Job file is %s\n",jobfile);
   if (data_path) strcpy (depfile,data_path);
   strcat (depfile,DEPFILE);
   if (debug) printf ("ddsnet: Dependancy file is %s\n",depfile);
   return;
}

FILE *dds_open_job (char *jobfile)
{
   FILE *job;
   if ((job = fopen(jobfile,"r+")) == NULL) {
      perror ("ddsnet: Cannot open Job file");
      dds_shutdown = 1;
   }
   return job;
}

FILE *dds_open_dep (char *depfile)
{
   FILE *dep;
   
   if ((dep = fopen(depfile,"r+")) == NULL)
     perror ("ddsnet: Cannot open Dependancy file");
   return dep;
}

void run_request (FILE *job, struct JOB *jobrec)
{
   struct passwd *passwd_ptr;
   int i, l = 1, lockid;
   
   if (debug) printf ("ddsnet: Remote Run Request received\n");
   passwd_ptr = getpwuid(jobrec->uid);
   if (passwd_ptr) {
      if ((l = find_job(job,passwd_ptr->pw_name,jobrec->name)) == 0)
	l = lock_last(job,sizeof(struct JOB),JOBFILE,lockdir,&lockid);
      jobrec->stat = READY;
      if (l!=0) {
	 i = write_only (job,l,sizeof(struct JOB),jobrec->num);
	 if (i==1) jobrec->stat = RUN;  /* to return to originating system */
      }
      fflush(job);
      remove_lock (JOBFILE,lockdir,l,lockid);
   }
   else {
     printf ("ddsnet: UID %d (job %16.16s) does not exist\n",jobrec->uid,jobrec->name);
     jobrec->stat = FAIL;       /* to return to originating system */
     jobrec->cstat = -99;
   }
}

void status_message (FILE *job, struct JOB jobrec)
{
   struct passwd *passwd_ptr;
   int l, lockid, recnum;

   if (debug) printf ("ddsnet: Status Message received\n");
   passwd_ptr = getpwuid(jobrec.uid);
   if (passwd_ptr) {
      if ((recnum = find_job(job,passwd_ptr->pw_name,jobrec.name)) != 0)
	l = lock_and_write (job,recnum,sizeof(jobrec),jobrec.num,JOBFILE,lockdir,&lockid);
      fflush(job);
      l = remove_lock (JOBFILE,lockdir,recnum,lockid);
   }
}

int find_job (FILE *job, char *user, char *name)
{
   int recnum = 1, l;
   struct JOB jobtmp;
   uid_t juid;
   struct passwd *passwd_ptr;
   char u[9];
   
   for (l=0; user[l] != 0 && user[l] != ' ' && l<9; l++) u[l] = user[l];
   u[l] = 0;
   if (debug) printf ("ddsnet: Find job: %16s for %8s\n",name,u);
   if ((passwd_ptr = getpwnam(u)) == NULL) return 0;
   juid = passwd_ptr->pw_uid;
   if (debug) printf ("ddsnet: UID is %d\n",juid);
   while ((l=read_only(job,recnum,sizeof(jobtmp),jobtmp.num))==1) {
      if (jobtmp.uid == juid && strncmp2(name,jobtmp.name,sizeof(jobtmp.name))==0)
	return recnum;
      recnum++;
   }
   return 0;
}

int strncmp2 (char *str1, char *str2, int max)
{
   int i, eos1 = 0, eos2 = 0;
   
   for (i=0; i<max; i++) {
      if (eos1==0 && (str1[i]==' ' || str1[i]==0)) eos1 = 1;
      if (eos2==0 && (str2[i]==' ' || str2[i]==0)) eos2 = 1;
      if (eos1==1 && eos2==1) return 0;
      if (eos1==1 && str2[i] != ' ') return 1;
      if (eos2==1 && str1[i] != ' ') return 2;
      if (eos1==0 && eos2==0 && str1[i] != str2[i]) return 3;
   }
   return 0;
}

int get_free_socket()
{
   int i;
   for (i=1; i<MAX_CONNECTIONS; i++)
     if (!server_sock[i]) return (i);
   return (0);
}
