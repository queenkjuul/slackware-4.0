#ifndef __dds_lck_h_
#define __dds_lck_h_

int make_lock (char *lockname, char *lockdir, int recnum);
int release_lock (char *lockname, char *lockdir, int recnum, int lockid);

#endif
