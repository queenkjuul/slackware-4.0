/*
 * ddsr.c  Peter F Gray  Feb 98
 * The run-control program for the Distributed Dependancy System
*/
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "dds_job.h"
#include "dds_lck.h"
#include "dds_fio.h"
#include "dds_soc.h"

#define JOBFILE "JOB.DAT"
#define DDSRDEBUG 0

void dds_init(char *lockdir, char *jobfile);
FILE *dds_open_job (char *filename);
int con_send_ack (char *dds_host,char *dds_port,struct JOB *jobrec);

static int debug = 0, pop_job = 0;
char *dds_host, *dds_port;

int main (int argc, char *argv[])
{
   FILE *job, *dep;
   time_t now;
   int l, send_remote = 0, recnum = 1, stat = 0, lockid, sock;
   struct JOB jobrec;
   char lockdir[50], jobfile[50], syscommand[50];
   struct passwd *passwd_ptr;
   
   dds_init(lockdir,jobfile);
   now = time(NULL);
   if ((job = dds_open_job(jobfile)) == NULL) stat = 1;
   if (argc > 1)
     recnum = atoi (argv[1]);
   else
     stat = 2;
   l = lock_and_read (job,recnum,sizeof(jobrec),jobrec.num,JOBFILE,lockdir,&lockid);
   if (l!=1) stat = 3;
   if (jobrec.stat == RUN) {
      if (getuid() == jobrec.uid) {
	 if (strncmp(jobrec.host,"        ",sizeof(jobrec.host))==0) {
	    sprintf (syscommand,"%s>%s",jobrec.command,jobrec.output);
	    l = system (syscommand);
	 }
	 else {
	    if (dds_host != NULL && dds_port != NULL) {
/* if target host is not us...
 * connect to remote ddsd, send job details, wait for ACK, set job to 'sent'
 * (actually, to whatever the remote ddsd tells us) */
	       if (strncmp(dds_host,jobrec.host,sizeof(jobrec.host))!=0) {
		  strncpy (jobrec.ohost,dds_host,sizeof(jobrec.ohost));
		  jobrec.stat = SEND;
		  pop_job = 1;
		  l = con_send_ack(jobrec.host,dds_port,&jobrec);
	       }
	       else {
/* target host is us...
 * run job as normal, update status, send results back to remote ddsd */
		  sprintf (syscommand,"%s>%s",jobrec.command,jobrec.output);
		  l = system (syscommand);
		  send_remote = 1;
	       }
	    }
	    else { /* fail: we have a net job, but no net details */
	       stat = 6;
	    }
	 }
      }
      else
	stat = 4;
   }
   else
     stat = 5;
   if (!pop_job) {
      if (jobrec.stat == SEND)
	stat = 0;
      else {
	 jobrec.complete = time(NULL);
	 jobrec.stat = FAIL;
	 if (stat==0 && l==0) jobrec.stat = COMP;
	 jobrec.cstat = l;
      }
   }
   else
     stat = 0;
   if (DDSRDEBUG) printf ("ddsr: stat=%d l=%d\n",stat,l);
   if (send_remote) l = con_send_ack(jobrec.ohost,dds_port,&jobrec); 
   if (stat==0) l = write_only (job,recnum,sizeof(jobrec),jobrec.num);
   if (stat==0 || stat >3) l = remove_lock(JOBFILE,lockdir,recnum,lockid);
   fclose(job);
}

void dds_init (char *lockdir, char *jobfile)
{
   char *dds_debug;
   char *data_path, *ddslck;

   dds_debug = getenv("DDSDEBUG");
   if (dds_debug)
     if (*dds_debug == 'y' || *dds_debug == 'Y') debug = 1;
   ddslck = getenv("DDSLCK");
   if (ddslck) strcpy(lockdir,ddslck);
   data_path = getenv("DDSDAT");
   if (data_path) strcpy (jobfile,data_path);
   strcat (jobfile,JOBFILE);
   dds_host = getenv("DDSHOST");
   dds_port = getenv("DDSPORT");
   return;
}

FILE *dds_open_job (char *jobfile)
{
   FILE *job;
   job = fopen(jobfile,"r+");
   return job;
}

int con_send_ack (char *host, char *port, struct JOB *jobrec)
{
   int i, sockx;
   struct sockaddr_in sockx_in;
   struct sockaddr_in remote_addr;
   struct hostent hostentstruct;
   struct hostent *hostx;
   struct sockmess sockmessfrom, sockmessto;
   
   if ((sockx=socket(AF_INET,SOCK_STREAM,0))==-1) return -1;
   if ((hostx=gethostbyname(host))==NULL) return -2;
   hostentstruct = *hostx;
   sockx_in.sin_family = hostentstruct.h_addrtype;
   sockx_in.sin_port = htons(atoi(port));
   sockx_in.sin_addr = * ((struct in_addr *) hostentstruct.h_addr);
   if (debug) printf ("ddsr:connecting\n");
   if ((i=connect(sockx,(struct sockaddr *) &sockx_in,sizeof(sockx_in)))==-1) return -3;
   if (debug) printf ("ddsr:connected (%s) %d\n",host,i);
   sockmessto.len = htons(sizeof(struct JOB));
   memcpy (sockmessto.data,jobrec->num,sizeof(struct JOB));
   if (debug) printf ("ddsr:send\n");
   if ((i=send(sockx,&sockmessto,sizeof(sockmessto.len)+sizeof(struct JOB),0))<0) return -4;
   if (debug) printf ("ddsr:recv\n");
   if ((i=sock_recv(sockx,&sockmessfrom))<0) return -5;
/* if we've requested a run, let the remote ddsdnet tell us what happened */
   if (pop_job) memcpy (jobrec->num,sockmessfrom.data,sizeof(struct JOB));
   if (debug) printf ("ddsr:done\n");
   return 0;
}
