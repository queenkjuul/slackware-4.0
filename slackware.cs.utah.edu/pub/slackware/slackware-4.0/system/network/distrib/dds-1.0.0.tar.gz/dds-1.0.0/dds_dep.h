#ifndef __dds_dep_h_
#define __dds_dep_h_
#include <unistd.h>

struct DEP {
   char name[16];             /* job name           */
   char user[8];              /* user name          */
                              /* runs after job...  */
   char aname[16];
   char auser[8];
};

#endif
