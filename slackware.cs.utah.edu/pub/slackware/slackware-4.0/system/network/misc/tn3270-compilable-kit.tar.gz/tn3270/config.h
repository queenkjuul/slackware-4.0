/* Print screen defines */
#define PRINTCMD "lpr"
#define PRINTDIR "/temp"
