/*
*	gettime.c
*	
*	
*	(c) 1994 - Todd Lawrence, LoD Communications.
*
*	Version:	V1.02-00
*	Author :	Todd Lawrence 
*	Date   :	October 3, 1994
*	
*	Copyright notice --
*
*	Copyright (c) 1994, LoD Communications.
*	
*	Permission to copy, modify and distribute this program is
*	hereby given, provided that this and the above text, and refrence
*	to the original author(s) remains in any copy or modification
*	of the following code.
*	
*
*	gettime.c	
*	
*	Bind to a given systems service port 13, steal the time/date
*	and print it to stdout. 
*	
*	Usage - "gettime <hostname>"
*	
*	example: "bash$ gettime att.com"
*	
*	returns
*	
*	"Mon Oct  3 20:05:02 1994" 
*	
*
*/

#include <stdio.h>	
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 

main(int argc, char **argv)
{
  struct hostent *hp;
  struct in_addr ad;
  struct sockaddr_in s;
  int p;	


  if(argc < 2){
    printf("usage: gettime <hostname>\n");
    return(1);
  }
  hp = gethostbyname(argv[1]);
  if(!hp) {
   return(1);
  } else {
    	bcopy(hp->h_addr, &ad, sizeof(struct in_addr));
    	p=socket(s.sin_family=2,1,0);
    	s.sin_port=htons(13);
    	s.sin_addr.s_addr=inet_addr( inet_ntoa(ad));
    	connect(p,&s,16);
    	while(write(1,&s,read(p,&s,1)));
    }
}


