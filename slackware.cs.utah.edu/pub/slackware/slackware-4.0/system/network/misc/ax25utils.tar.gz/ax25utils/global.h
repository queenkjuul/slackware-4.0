/* In listen.c */
void data_dump(unsigned char *, int);
int  get16(unsigned char *);
int  get32(unsigned char *);

/* In kiss.c */
void ki_dump(unsigned char *, int);

/* ax25dump.c */
void ax25_dump(unsigned char *, int);
char *pax25(char *, unsigned char *);

/* In nrdump.c */
void netrom_dump(unsigned char *, int);

/* In arpdump.c */
void arp_dump(unsigned char *, int);

/* In ipdump.c */
void ip_dump(unsigned char *, int);

/* In icmpdump.c */
void icmp_dump(unsigned char *, int);

/* In udpdump.c */
void udp_dump(unsigned char *, int);

/* In tcpdump.c */
void tcp_dump(unsigned char *, int);
