#ifndef __MAKEUDP_FUNC_H
#define __MAKEUDP_FUNC_H

/* File   : makeudp_func.h                                                  */
/* Purpose: Definitions and include files needed by makeudp_func.c.         */

#include <netinet/udp.h>  /* UDP header struct    */

/* Data Structures */
struct full_udphdr {
  unsigned long source;
  unsigned long destination;
  char zero;
  char protocol;
  unsigned short length;
  struct udphdr packet;
};

/* Function Prototypes */
struct full_udphdr *new_udp_packet(void);

#endif  /* __MAKEUDP_FUNC_H */
