#ifndef __MAKETCP_CONF_H
#define __MAKETCP_CONF_H

/* File   : maketcp_conf.h                                                  */
/* Purpose: User configurable options for the maketcp program.              */

/* Define the default window size                                           */
#define TCP_DEFAULT_WINDOW_SIZE 512

/************ The following probably need not be changed ********************/

/* Default protocol number (6 = TCP).                                       */
#define TCP_DEFAULT_PROTOCOL 6

/* Default minimum number of bytes in a TCP header.                         */
#define TCP_DEFAULT_HEADER_SIZE 20

/* Default number of bytes in a TCP pseudo-header, (used for checksum       */
/* calculations).                                                           */
#define TCP_PSEUDO_HEADER_SIZE 12

#endif  /* __MAKETCP_CONF_H */
