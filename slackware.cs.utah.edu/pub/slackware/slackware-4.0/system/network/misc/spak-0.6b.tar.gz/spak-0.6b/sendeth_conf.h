#ifndef __SENDETH_CONF_H
#define __SENDETH_CONF_H

/* File   : sendeth_conf.h                                                  */
/* Purpose: User configurable options for the sendeth program.              */

/* Default interface to send data through.  If this is undefined, then the  */
/* interface used will be attempted to be selected automatically.  To       */
/* undefine this option, add a /* before #define.                           */
#define DEF_ETH_DEVICE "eth0"  /* */

#endif  /* __SENDETH_CONF_H */
