#ifndef __MAKEIP_FUNC_H
#define __MAKEIP_FUNC_H

/* File   : makeip_func.h                                                   */
/* Purpose: Definitions and include files needed by makeip_func.c.          */

/* Function prototypes */
struct ip *new_ip_packet(void);

#endif  /* __MAKEIP_FUNC_H */
