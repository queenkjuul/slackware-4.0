#ifndef __MAKEARP_FUNC_H
#define __MAKEARP_FUNC_H

/* File   : makearp_func.h                                                  */
/* Purpose: Definitions and include files needed by makearp_func.c.         */

#ifdef SunOS
#include <sys/types.h>   /* u_short         */
#include <sys/socket.h>  /* struct sockaddr */
#endif  /* SunOS */

#ifdef BSDI31
#include <sys/types.h>   /* u_short         */
#include <sys/socket.h>  /* struct sockaddr */
#endif  /* BSDI31 */

#include <net/if_arp.h>  /* struct arphdr */


/* Function Prototypes */
struct arphdr *new_arp_packet(void);
int get_resize_len(void *);

#endif  /* __MAKEARP_FUNC_H */
