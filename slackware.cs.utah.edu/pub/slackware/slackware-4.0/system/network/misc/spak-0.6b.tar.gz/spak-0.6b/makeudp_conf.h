#ifndef __MAKEUDP_CONF_H
#define __MAKEUDP_CONF_H

/* File   : makeudp_config.h                                                */
/* Purpose: User configurable options for the makeudp program.              */

/* Define the default source port.                                          */
#define UDP_DEFAULT_SOURCE_PORT 0

/************ The following probably should not be changed ******************/

/* Define the default protocol (UDP = 17).                                  */
#define UDP_DEFAULT_PROTOCOL 17

/* Default minimum number of bytes in a UDP header.                         */
#define UDP_DEFAULT_HEADER_SIZE 8

/* Default number of bytes in a UDP pseudo-header, (used for checksum       */
/* calculations).                                                           */
#define UDP_PSEUDO_HEADER_SIZE 12

#endif  /* __MAKEUDP_CONF_H */
