#ifndef __ETHER_FUNC_H
#define __ETHER_FUNC_H

/* File   : ether_func.h                                                    */
/* Purpose: Definitions for the ether_func.c program.                       */

#include "config.h"
#include <net/if.h>  /* struct ifreq */

/* Definitions */
#define IP 1
#define MAC 2

/* Function Prototypes */
int get_default(struct ifreq *, int);
int hwaddread (unsigned char [], char *);
int ipaddread(char *, char *);
int typeread (char *);

#endif  /* __ETHER_FUNC_H */
