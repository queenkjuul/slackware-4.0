#ifndef __MAKETCP_FUNC_H
#define __MAKETCP_FUNC_H

/* File   : maketcp_func.h                                                  */
/* Purpose: Definitions and include files needed by maketcp_func.c.         */

#include <netinet/tcp.h>  /* TCP header struct    */


/* Data Structures */
struct full_tcphdr {
  unsigned long source;
  unsigned long destination;
  char zero;
  char protocol;
  unsigned short length;
  struct tcphdr packet;
};

/* Function Prototypes */
struct full_tcphdr *new_tcp_packet(void);

#endif  /* __MAKETCP_FUNC_H */
