/* This is the configuration file for Spak.  Please read this file entirely */
/* and make any changes to it as needed.                                    */

/* Select the operating system (OS) for which you are compiling Spak.  To   */
/* select a system, remove the leading /* before the #define statement      */
/* corresponding to the appropriate OS.  Be sure that only one OS is        */
/* defined, (in other words, all other #define statements other than the    */
/* one you want are preceeded by /*).                                       */
/*#define SunOS /* */
/*#define BSDI31 /* */
#define LINUX /* */

/* If AUTO_OPT_PAD is defined, then options will automatically be padded so */
/* that they end on a 32-bit boundry.  This should be enabled unless you    */
/* know what you are doing.                                                 */
#define AUTO_OPT_PAD
/* #undef AUTO_OPT_PAD /* */

/***** You should not need to change anything below this line ***************/

#ifdef SunOS
#undef INET_ATON
#endif

#ifdef BSDI31
#define INET_ATON
#endif

#ifdef LINUX
#define INET_ATON
#endif
