#ifndef __MAKEUDP_SYSCONF_H
#define __MAKEUDP_SYSCONF_H

/* File   : makeudp_sysconfig.h                                             */
/* Purpose: System configuration options for the makeudp program.           */

#include "config.h"

#ifdef SunOS
#define UDP_FIELD_DEST uh_dport
#define UDP_FIELD_CSUM uh_sum
#define UDP_FIELD_LEN uh_ulen
#define UDP_FIELD_SRC uh_sport
#endif  /* SunOS */

#ifdef BSDI31
#define UDP_FIELD_DEST uh_dport
#define UDP_FIELD_CSUM uh_sum
#define UDP_FIELD_LEN uh_ulen
#define UDP_FIELD_SRC uh_sport
#endif  /* BSDI31 */

#ifdef LINUX
#define UDP_FIELD_DEST dest
#define UDP_FIELD_CSUM check
#define UDP_FIELD_LEN len
#define UDP_FIELD_SRC source
#endif  /* LINUX */

#endif  /* __MAKEUDP_SYSCONF_H */
