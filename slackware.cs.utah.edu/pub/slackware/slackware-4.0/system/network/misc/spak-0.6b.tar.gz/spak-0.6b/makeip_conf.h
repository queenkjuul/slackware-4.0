#ifndef __MAKEIP_CONF_H
#define __MAKEIP_CONF_H

/* File   : makeip_conf.h                                                   */
/* Purpose: User configurable options for the makeip program.               */

/* Default protocol - 1=ICMP, 6=TCP, 14=Telnet, 17=UDP - See RFC 790.       */
#define IP_DEFAULT_PROTOCOL 6

/* Default TTL for the IP header.                                           */
#define IP_DEFAULT_TTL 64

/************ The following probably need not be changed ********************/

/* Default version of the IP protocol being used.                           */
#define IP_DEFAULT_VERSION 4

/* Default number of bytes in a bare IP header.                             */
#define IP_DEFAULT_HEADER_SIZE 20

#endif  /* __MAKEIP_CONF_H */
