/* Port scanner ver 1.02
   Written by Alexey Semenov (c) 1997-98

   swaj_@geocities.com
   alexey_semenov@hotmail.com

   Copying-policy - GPL
*/
 
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>

int list_mode=1;
int a;

main (argc,argv)
     int argc;
     char *argv[];
{
  unsigned long w_addr, w1_addr;
  struct hostent *h;

print_banner ();

if (argc > 1) {
  a=strcmp (*(argv+1),"-f");
         if (a==0) {
             argc--;
             list_mode=0;
             argv++; }
}

if ((argc!=2) && (argc!=3)) {
         printf ("Usage: tcpscan [-f] [hostname || IP_address]\n");
         printf ("       tcpscan [-f] [first_IP_address] [last_IP_address]\n");
              exit (1); } 
//------------------------------
w_addr=inet_addr ( *++argv);
if (argc==3) w1_addr=inet_addr (*++argv);

if ( argc==3) {
 
 if ((w_addr==-1) || (w1_addr==-1)) {
      printf ("\nBoth args must be IP addresses\n");
      exit (1); }
  
 if  ( (w_addr & 0xffffff)!=(w1_addr & 0xffffff) ) {
      printf ("\nBoth addresses must be within one `C` network\n");
      exit (0); }

 for (;;) {
     open_tcp_array (w_addr); 
     printf ("\n**************************************");
     if (w_addr==w1_addr) { break; } ;
     w_addr=w_addr+256*256*256; }
     printf ("\n");
 exit (0);
}

if ( w_addr!=-1) {

  open_tcp_array (w_addr);

           exit (0);
}
//-----------------
h=gethostbyname (*argv);

if (h==NULL) {
  printf ("Failed to resolve hostname: `%s`\n",*argv);
  exit (1); 
} 
printf ("%s -> %s \n",*argv,inet_ntoa(*((struct in_addr *)h->h_addr_list[0])));

open_tcp_array (*((struct in_addr *)h->h_addr_list[0]));
exit (0);
}
//-----------------
open_tcp_array (host_addr) {

  char *ports_descr[]={
"tcpmux","echo","discard","systat","daytime",
"netstat","qotd","chargen","ftp-data","ftp",
"ssh",
"telnet","smtp","time","whois","tacacs",
"domain",
"mtp","gopher","rje","finger","http/www",
"link","kerberos","supdup","hostnames","iso-tsap",
"x400","x400-snd","csnet-ns","pop-2","pop-3/pop",
"sunrpc","auth","sftp","uucp-path","nntp",
"ntp","netbios-ns","netbios-dgm","netbios-ssn","imap",
"NeWS","exec","login","shell","printer",
"efs","tempo","courier","conference","netnews",
"uucp","klogin","kshell","remotefs","pcserver",
"kerberos-adm","kerberos-sec","kerberos-master","krb5_prop","Socks/WinGate",
"listen",
"nterm","kpop","ingreslock","tnet","cfinger",
"eklogin","squid-proxy","krb524","irc","irc","irc",
"dos","X-font-server","realauduo"," "};  

  unsigned int ports_array [] = {
1,7,9,11,13,
15,17,19,20,21,
22,
23,25,27,43,49,
53,
57,70,77,79,80,
87,88,95,101,102,
103,104,105,109,110,
111,113,115,117,119,
123,137,138,139,143,
144,512,513,514,515,
520,526,530,531,532,
540,543,544,556,600,
749,750,751,754,1080,
1025,
1026,1109,1524,1600,2003,
2105,3128,4444,6666,6667,6668,
7000,7100,7070,0};

int i=0, res;

    printf ("\n");

  while (ports_array[i]!=0) {
    res=open_tcp_sock (host_addr,ports_array[i] );

     if ( (res!=-1) || (list_mode==0) ) {    
	 printf ("(%s",ports_descr[i]);
         printf (")");
 			}
     i++;
  }
    printf ("\n");
}
//------------------------------------------------------
open_tcp_sock (some_addr,some_port) {

  struct in_addr {
    unsigned long s_addr;
  };
  struct sockaddr_in {
    short int            sin_family;      // Adress family
    unsigned short int   sin_port;        // Port number
    struct in_addr       sin_addr;        // Internet address
    unsigned char        sin_zero[8];     // Same size ...
  };
int sockfd, result;

struct sockaddr_in my_addr;

   sockfd = socket (AF_INET, SOCK_STREAM, 0);

my_addr.sin_family = AF_INET;
my_addr.sin_port = htons (some_port);
my_addr.sin_addr.s_addr = some_addr;
bzero ( &(my_addr.sin_zero), 8);

result=connect (sockfd,(struct sockaddr *) &my_addr, sizeof(struct sockaddr) );

close (sockfd);

if ( (list_mode==0) || ( (list_mode==1) && (result!=-1) ) ) {
  printf ("\nhost %s",inet_ntoa(some_addr));
  printf ("  port %d",some_port);
  printf (" "); 
        if (result==-1)  printf ("fail  ");
        else printf ("done  ");
}

return (result) ;
} 
//-----------------------------------------------------------
     print_banner() {

printf ("\n--------------------------------------------------------");
printf ("\nTCP port scanner ver. 1.02");
printf ("\nWas written by (c) Alexey Semenov, 1997-98.\n");
printf ("\nEmail: swaj_@geocities.com");
printf ("\n       alexey_semenov@hotmail.com");
printf ("\nURL:   http://www.geocities.com/SiliconValley/Way/7914/");
printf ("\n--------------------------------------------------------\n");
return ;
}
//--->end
