/* HAVE_SYS_ERRLIST_DECL and SYS_SIGLIST_DECLARED will be undefined if
   you have the strerror and strsignal functions, even if your system
   have such declarations.  We don't check for them if not needed.  */
@TOP@

/* Define if you have the inet_aton declaration.  */
#undef HAVE_INET_ATON_DECL

/* Define if you have the errno declaration.  */
#undef HAVE_ERRNO_DECL

/* Define if you have the sys_errlist declaration.  */
#undef HAVE_SYS_ERRLIST_DECL

/* Define if you have the strsignal declaration.  */
#undef HAVE_STRSIGNAL_DECL

/* Define if you have the gethostname function.  */
#undef HAVE_GETHOSTNAME

/* Define if you have the socket function.  */
#undef HAVE_SOCKET

/* Define if you have the strerror function.  */
#undef HAVE_STRERROR

/* Define if you have the strsignal function.  */
#undef HAVE_STRSIGNAL

/* Define if your hosts data base have a non-standard path.  */
#undef HOSTS_PATH
