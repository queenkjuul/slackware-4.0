/*
 * Northrop Grumman ACC286 Device Driver
 *
 */

/* Control Register 1 
 * Determines base address of the sliding window in host PC memory
 *
 */
#define WINDOW_BASE_MASK   0xfc   /* Window base adress high 6 bits */
#define WINDOW_SIZE_MASK   0x03   /* window size low 2 bits */
#define WINDOW_SIZE_8K     0x00   /* 8K Bytes */
#define WINDOW_SIZE_16K    0x01   /* 16K Bytes */
#define WINDOW_SIZE_32K    0x02   /* 32K Bytes */
#define WINDOW_SIZE_64K    0x03   /* 64K Bytes */

/* Control Register 2
 * Indicates window location in card memory.
 * All 8 bits are used.
 */

/* Control Register 3
 * All bits readable & writeable, reset to zero on power up.
 */
#define ACC_PROC_MASK       0x80   /* bit 7 reset v53 processor */
#define ACC_PROC_RESET      0x00   /* bit 7 reset on low */
#define ACC_PROC_RUN        0x80   /* bit 7 reset on high */

#define BUS_XFER_MASK       0x20   /* bit 5 bus transfer width */
#define BUS_XFER_16BIT      0x20   /* bit 5 16 bit bus transfer mode */
#define BUS_XFER_8BIT       0x00   /* bit 5 8 bit bus transfer mode */

#define HIGH_WINDOW_MASK    0x08   /* Bit 3 PC window base */
#define HIGH_WINDOW_ENABLE  0x08   /* Bit 3 PC window base 880000h  (8.5-9M)*/
#define HIGH_WINDOW_DISABLE 0x00   /* Bit 3 PC window base 80000h  (512K-1M)*/

#define IRQ_SELECT_MASK     0x07   /* Bits 0-2 interrupt select mask */
#define IRQ_SELECT_DISABLED 0x00   /* interupts disabled */
#define IRQ_SELECT_5        0x01   /* card uses IRQ 5 to interrupt host */
#define IRQ_SELECT_6        0x02   /* card uses IRQ 6 to interrupt host */
#define IRQ_SELECT_7        0x03   /* card uses IRQ 7 to interrupt host */
#define IRQ_SELECT_10       0x04   /* card uses IRQ 10 to interrupt host */
#define IRQ_SELECT_11       0x05   /* card uses IRQ 11 to interrupt host */
#define IRQ_SELECT_14       0x06   /* card uses IRQ 14 to interrupt host */
#define IRQ_SELECT_15       0x07   /* card uses IRQ 15 to interrupt host */

/* Control Register 4
 * Bit 7 -- window enable   -- read/write
 * Bit 6,5  not used
 * Bit 4 -- interrupt test  -- read/write
 * bit 3 -- interrupt clear -- write-only
 * Bit 2 -- pc attention    -- read-only
 * Bit 1 -- V53 INTP1       -- write-only
 * Bit 0 -- V53 NMI         -- read-write
 */
#define WINDOW_ENABLE_MASK 0x80    /* Bit 7 window enable */
#define WINDOW_ENABLE      0x80    /* Bit 7 window enable on high */
#define WINDOW_DISABLE     0x00    /* Bit 7 window disable on low */

#define IRQ_TEST_MASK      0x10    /* Bit 4 auto generate irq to host */ 
#define IRQ_TEST_GEN       0x10    /* Bit 4 auto generate irq to host */ 
#define IRQ_TEST_CLEAR     0x00    /* Bit 4 clear of auto generated irq */

#define IRQ_CLEAR          0x08    /* Bit 3 clears bits 2 and 4 */
#define HOST_ATTN_MASK     0x04    /* Bit 2 pc attention */
#define V53_INTP1          0x02    /* Bit 1 gen interrupt to V53 */

#define V53_NMI_MASK       0x01    /* Bit 0 gen NMI to V53 */
#define V53_NMI_GEN        0x01    /* Bit 0 gen NMI to V53 */
#define V53_NMI_CLEAR      0x00    /* Bit 0 clear NMI from V53 */


#define ACC286_CR_BASE_DEFAULT 0x033c  /* default control reg base */
#define ACC286_CR_EXTENT      4       /* 4 control regs total */

#define ACC286_CR_BASE        (acc286.cr_base) 
#define ACC286_CR1_PORT       (acc286.cr_base+0) /* CR1 */
#define ACC286_CR2_PORT       (acc286.cr_base+1) /* CR2 */
#define ACC286_CR3_PORT       (acc286.cr_base+2) /* CR3 */
#define ACC286_CR4_PORT       (acc286.cr_base+3) /* CR4 */

/* ---------------- end of file -------------- */
