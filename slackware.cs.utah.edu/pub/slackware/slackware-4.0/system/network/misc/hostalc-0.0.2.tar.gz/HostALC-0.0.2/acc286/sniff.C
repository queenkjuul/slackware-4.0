
//
// sniff.C
//
// Sniff test program for acc286 device driver
//

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

main () {


   int fd = open ("/dev/acc286",  O_RDWR);
   if (-1 == fd) {
      int norr = errno;
      printf ("open oops: %d %s \n", norr, strerror (norr));
      exit (1);
   }

   printf ("opened file descriptor %d \n", fd);

   char buff[100];

   for (int i=0; i<10; i++) {
      int retval = read (fd, buff, 100);

      if (-1 == retval) {
         int norr = errno;
         printf ("read oops: %d %s \n", norr, strerror (norr));
         exit (1);
      }
   
      buff[99] = 0x0;
      printf ("read %s \n", buff);

      sprintf (buff, "loop %d ", i);
   
      retval = write (fd, buff, strlen (buff));
      if (-1 == retval) {
         int norr = errno;
         printf ("write oops: %d %s \n", norr, strerror (norr));
         exit (1);
      }
   
   }

   sleep (100);
}
