/*******************************************************************
 * Airline2tcp.c  get Airline messages and pass them to the Unix world
 *
 * Configueration file entry in: /wnet/al2tcp.cfg are:
 * Hostname Service     dpm_device
 *
 *  This software is provided on an AS-IS basis.
 *
 * This software was originally developed by Fulko Hew of Westinghouse
 * Canada,  and was distributed by Westinghouse, and later, Northrup 
 * Grumman, as part of thier programming guide for the W9600.  This
 * software contans no copyright notices.  Although it is labelled 
 * "proprietary", it is freely distributed on thier web server at 
 * http://www.wecan.com/netprod/ipgw_prog.guide
 *
 *******************************************************************/

#include <sys/param.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <fcntl.h>
#include <signal.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <pwd.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define nap(x) usleep(x*1000)    /* i dunno ... is nap in milliseconds ???  */

#include "ahost-tr.h"

#define OPTIONS     "RWxw"
#define LOG_ERR     0
#define LOG_WARN    5
#define LOG_DEBUG   9
#define LOG_TRACE   9

#define NEW     1
#define RESURRECT   2

#define ERR     -1
#define BUG     0
#define EOS     '\0'
#define L_SET       0       /* Absolute seek */
#define STDIN       0
#define STDOUT      1

#define  PROTOCOL   0x05
#define  BUFFER_SIZE    5120
#define  EOM        0x51            /* after ascii->ipars->mangle */
#define  CONFNAME   "./al2tcp.cfg"

char logname[50] = "\0";
char deflogname[] = "./al2tcp.log";
char albuf[BUFFER_SIZE];            /* Big Airline buf */
char unixbuf[BUFFER_SIZE];          /* Big Unix buf */

struct  sockaddr_in daemon_addr = { sizeof(daemon_addr), AF_INET };
struct  sockaddr_in hisaddr;
struct  sockaddr_in my_addr = { sizeof(my_addr), AF_INET };

struct  in_addr my_machine_addr;    /* inet addresses of the two machines */
struct  in_addr his_machine_addr;
char    hostname[MAXHOSTNAMELEN];
char    *his_name, *my_machine_name;
int isockt;
int osockt;

/* Prototypes */

static  void    do_ahost_copy(void);
static  void    dispatch(int) ;
static  void    do_uhost_copy(void);
static  int read_ahost(char *msg);
static  void    dpm_iopen(void);
static  void    dpm_oopen(void);
static  void    tr_unix_msg(char *msg);
static  void    tr_host_msg(uchar *msg, int len);
static  char    *tr(int *tr, uchar *t, uchar *f, int len);
static  void    die(int exit_rc);
static  void    config();
static  void    sig_action (int);
static  void    new_child (int);
static  void    write_ahost() ;
static  int     send_unix( char *s,int len);
static void     open_osockt();
static void     open_isockt();

static  char    *DPM_channel = "/dev/dpm/dpma13";
static  int DPM_ofd = ERR;
static  int DPM_ifd = ERR;
static  int Wait_open = 1;
static  int App_Mode = 0;
static  uchar   A_msg[BUFFER_SIZE];
static  int A_len;
static  uchar   U_msg[BUFFER_SIZE];
static  pid_t   Child_pid;
static  pid_t   Pid = 0;

int check_all = 0;
int Debug = 0;

/* Configuration file structure used by config() */

struct  altab {
    char    *di_host;       /* name of host */
    char    *di_service;        /* name of service */
    char    *di_dpm;        /* name of dpm_device */
    struct  altab *di_next;
} *altab;

struct  servent *sp;
struct  hostent *hp;

FILE    *fconfig = NULL;
struct  altab al;       /* The configuration read, could be */
                /* expanded later for multiple connections */
char    line[256];
char    *skip(), *nextline();

/* airline addresses */

static  short   s_hld;
static  short   d_hld;
static  uchar   a1,a2,a3;
static  long    a123;

main(int argc, char *argv[])
{
   extern int opterr, optind;
   int _check_rhosts_file;
   int ch, on = 1, fromlen,len;
   struct sockaddr_in from;
   extern char *optarg;
   struct altab *sep;
   
   while ((ch = getopt(argc, argv, OPTIONS)) != EOF)
       {
       switch (ch)
           {
           case 'R':
               App_Mode = ch;
               break;
           case 'W':
               App_Mode = ch;
               break;
           case 'x':
               Debug = atoi(optarg);
               break;
           case 'w':
               Wait_open = 1;
               break;
           case '?':
           default:
               usage(argv[0]);
               exit(2);
           }
       }
   signal(SIGTERM, sig_action);
   signal(SIGHUP,SIG_IGN);
   signal(SIGINT,sig_action);
   signal(SIGQUIT,sig_action);
   signal(SIGKILL,sig_action);
   signal(SIGCLD,new_child);
   
   config();               /* read configuration file */
   DPM_channel = al.di_dpm;

   switch (fork())             /* Become a true daemon */
       {
       case -1:
           msglog(LOG_ERR, "Can't fork");
           exit(2);
           break;
       case 0:             /* child process */
           sleep(60);
           break;
       default:            /* parent process should just die */
           _exit(0);
       }
   
   switch (App_Mode)
       {
       case 0:             /* normal read/write mode */
           dispatch(NEW);
           break;
   
       case 'R':           /* ahost->uhost mode */
           DPM_ifd = STDIN;
           do_ahost_copy();
           break;

       case 'W':           /* uhost->ahost mode */
           DPM_ofd = STDOUT;
           do_uhost_copy();
           break;
       }
   return 0;
}

/* read host messages translate them and send to Unix */

static void do_ahost_copy (void)
{
   int len,rc;
   
   while (1) {              /* Start the main loop */
      len = read_ahost(albuf);
      if (len) {
         tr_host_msg(albuf, len);
         msglog(LOG_DEBUG,U_msg);
         while(1) {
            /* If error try to reestablish connection */
            rc = send_unix(U_msg,len);
            if (rc == 0)
               break;
            else
            {
               Debug = 9;
               msglog(LOG_ERR,"send_unix rc = %d",rc);
               Debug = 0;
               open_osockt();
            }
         }
     }
     nap(100);   /* this is neccessary */
   }
}

/* Do separate 1st read to optain host address so we can fork The writer */

static void do_1stahost_copy (void)
{
   int len,rc;
   
   dpm_iopen();
   open_osockt();
   
   len = read_ahost(albuf);            /* Start the main loop */
   while (1) {
       if (len) {
           tr_host_msg(albuf, len);
           msglog(LOG_DEBUG,U_msg);
           while (1) {
               /* If error try to reestablish connection */
               rc = send_unix(U_msg,len);
               if (rc == 0)
                   break;
               else
                   open_osockt();
           }
       break;
       }
   nap(100);   /* this is neccessary */
   }
}

/* read unix message from socket translate and write to host */
static void do_uhost_copy (void)
{
   int ac,len;
   
   dpm_oopen();
   open_isockt();
   
   while (1)                   /* Start the main loop */
       {
       if ((ac = accept(isockt,(struct sockaddr *)0, (int *)0)) == -1)
               msglog(LOG_ERR,"accept failed %d",errno);
       if ((len = read(ac,unixbuf, sizeof(unixbuf))) == -1)
               msglog(LOG_ERR,"read failed %d",errno);
       unixbuf[len] = '%';
       unixbuf[len+1] = '\0';
       msglog(LOG_DEBUG,"len %d",len);
       close(ac);
   
       tr_unix_msg(unixbuf);           /* sets A_buf, A_len */
       A_msg[A_len++] = EOM_CH;
       A_msg[A_len] = EOS;
       write_ahost();
   }
}

/*  dispatch -- start both uhost and ahost translators as 2 processes */

static void dispatch (int flg)
{
   msglog(LOG_DEBUG, "Debug level: %d", Debug);
   
   /* 1 message must be read for the return addresses before we can fork */
   if (flg == NEW)
       do_1stahost_copy();
   else
       {
       dpm_iopen();
       open_osockt();
   }
   
   if ((Child_pid = fork()) < 0) {
       msglog(LOG_ERR, "Can't fork");
       exit(2);
   }
   
   if (Child_pid == 0) {
       /* child, translate uhost messages */
       if (Pid != ERR) Pid = getpid();
       Wait_open = 0;  /* child doesn't wait */
       sleep(15);  /* So it be */
       do_uhost_copy();
   }
   else                    /* parent, translate ahost messages */
       do_ahost_copy();
}

usage (char *s) {
   fprintf(stderr,"Usage: %s -%s\n",s,OPTIONS);
   fprintf(stderr,"       -R do only host to Unix\n");
   fprintf(stderr,"       -W do only  Unix to Host\n");
   fprintf(stderr,"       -x Debuglevel 0-9\n");
   fprintf(stderr,"       -w No waitopen\n");
}

/* dpm_iopen -- used to open the DPM device.  The sleep 45 is used  */
/*  to slow the opens down in case of failure.          */

static void dpm_iopen(void)
{
   while (1) {
      DPM_ifd = open(DPM_channel,O_RDONLY , 0);
      if (DPM_ifd != ERR)
          {
          msglog(LOG_TRACE, "ahost:Ready %s -> %d", DPM_channel, DPM_ifd);
          return;
      }
      msglog(LOG_ERR, "Fatal: open %s failed: %d=%s",
          DPM_channel, errno, strerror(errno));
      if (Wait_open) sleep(45);
   }
}

/* dpm_oopen -- used to open the DPM device.  The sleep 45 is used  */
/*  to slow the opens down in case of failure.          */

static void dpm_oopen(void)
{
   while (1) {
      DPM_ofd = open(DPM_channel, O_WRONLY, 0);
      if (DPM_ofd != ERR)
          {
          msglog(LOG_TRACE, "ahost:Ready %s -> %d", DPM_channel, DPM_ofd);
          return;
          }
      msglog(LOG_ERR, "Fatal: open %s failed: %d=%s",
          DPM_channel, errno, strerror(errno));
      if (Wait_open)
          sleep(45);
   }
}

/* read_ahost -- used to read a single message from the DPM device. */

static int read_ahost(char *msg)
{
   int len = 0;
   
   while ((len = read(DPM_ifd, msg, BUFFER_SIZE)) <= 0)
       {
       msglog(LOG_ERR, "a-host read failure on %s: %d=%s",
           DPM_channel, errno, strerror(errno));
       die (RESURRECT);
       }
   msglog(LOG_DEBUG,"read_ahost %d ",len);
   return len;
}

/* tr_unix_msg -- take the unix msg and translate it to a host message */

static void tr_unix_msg(char *msg)
{
   uchar *p;
   
   msglog(LOG_TRACE, "Send: %s", msg);
   
   p = A_msg;
   *p++ = (uchar)PROTOCOL;
   
   *p++ = (uchar)(d_hld >> 8); /* swap src/dst */
   *p++ = (uchar) d_hld;
   
   *p++ = (uchar)(s_hld >> 8);
   *p++ = (uchar) s_hld;
   
   *p++ = (uchar)Ipars_To_Mangle[(a123 >> 24) & 0xFF]; /* a1 */
   *p++ = (uchar)Ipars_To_Mangle[(a123 >> 16) & 0xFF]; /* a2 */
   *p++ = (uchar)Ipars_To_Mangle[(a123 >>  8) & 0xFF]; /* a3 */
   
   p = (uchar *) tr(Ascii_To_Mangle, p, msg, strlen(msg));
   A_len = p - A_msg;
   msglog(LOG_DEBUG,"A_len %d",A_len);
}

/* tr_host_msg -- translate a host message to a unix msg    */

static void tr_host_msg(uchar *msg, int len)
{
   uchar   *p, *end;
   uchar   protocol;
   
       /* len < protocol+shld+dhld+a123d+xx+msg==1 */
   if (len < 1+2+2+4+2+1)
       {
       msglog(LOG_TRACE, "Short message from a-host len=%d", len);
       *U_msg = EOS;
       return;
       }
   
   p = msg;
   protocol = *p++;        /* TODO assert protocol == PROTOCOL */
   
   s_hld = (short)((*p <<8) + p[1]); p += 2;   /* high/low byte order */
   d_hld = (short)((*p <<8) + p[1]); p += 2;   /* high/low byte order */
   
   a1 = (uchar)Mangle_To_Ipars[*p++];
   a2 = (uchar)Mangle_To_Ipars[*p++];
   a3 = (uchar)Mangle_To_Ipars[*p++];
   if (App_Mode != 'T') {          /* don't strip this if testing */
       p++;                /* cmd */
       p++;                /* la */
       }
   a123 = (a1 << 24) | (a2 << 16) | (a3 << 8);
   
   end = U_msg;
   
   len -= p-msg;               /* skip past the header */
   p = tr(Mangle_To_Ascii, end, p, len-1); /* translate all but last character */
   *p ++ = '\n';               /* (the eom) */
   *p = EOS;
}


/* tr -- used to do a "TRanslate" on a block of data.           */
/*  The translate table is in tr.                   */
/*  t is where to translate to.                 */
/*  f is where to translate form.                   */
/*  len is the length to translate.                 */
/*  The translate table support DEL_CH to remove characters.    */

static char * tr(int *tr, uchar *t, uchar *f, int len)
{
   uchar   *end = f+len;
   int c;
   
   for (; f < end; ++f)
       {
       c = tr[*f & 0x7F];      /* translate low 7bits  */
       if (c & EOM_CH)         /* End of Message character */
           {
           if (f < end-1) {    /* valid only at end */
               c = tr[' '];
               }
           }
       if (c & DEL_CH) continue;   /* delete character? */
       *t++ = (uchar)c;        /* save translated value */
       }
   *t = EOS;
   return t;
}

/* die -- called instead of exit so that we can kill the child process. */

static void die(int rc)
{
   close(DPM_ifd);
   close(DPM_ofd);
   close(isockt);
   close(osockt);
   if (Child_pid)
       {
       kill(Child_pid, SIGTERM);
       Child_pid = 0;
       }
   if (Wait_open)
       sleep(45);
   if (rc == RESURRECT)
       dispatch(RESURRECT);
   else
       exit(rc);
}

setconfig()
{
   if (fconfig != NULL) {
      fseek(fconfig, 0L, L_SET);
      return (1);
   }
   fconfig = fopen(CONFNAME, "r");
   return (fconfig != NULL);
}

void endconfig(void)
{
   if (fconfig) {
      (void) fclose(fconfig);
      fconfig = NULL;
   }
}

struct altab *getconfigent()
{
   struct altab *sep = &al;
   int argc;
   char *cp, *arg, *newstr();
   
   while ((cp = nextline(fconfig)) && *cp == '#')
       ;
   if (cp == NULL)
       return ((struct altab *)0);
   bzero((char *)sep, sizeof *sep);
   
   sep->di_host = newstr(skip(&cp));
   sep->di_service = newstr(skip(&cp));
   sep->di_dpm = newstr(skip(&cp));
   return (sep);
}

freeconfig (struct altab *cp) {
   if (cp->di_host) free(cp->di_host);
   if (cp->di_service) free(cp->di_service);
   if (cp->di_dpm) free(cp->di_dpm);
}

char *skip( char **cpp)
{
   char *cp = *cpp;
   char *start;
   
   if (*cpp == NULL) return ((char *)0);
   
   while (1) {
      while (*cp == ' ' || *cp == '\t') cp++;
   
      if (*cp == '\0') {
          int c;
   
          c = getc(fconfig);
          (void)ungetc(c, fconfig);
          if (c == ' ' || c == '\t') {
              cp = nextline(fconfig);
              if (cp) continue;
          } 
          *cpp = (char *)0;
          return ((char *)0);
      }
   }

   start = cp;
   while (*cp && *cp != ' ' && *cp != '\t') cp++;
   if (*cp != '\0') *cp++ = '\0';
   *cpp = cp;
   return (start);
}

char *nextline(FILE *fd) {
   char *cp;
   
   if (fgets(line, sizeof (line), fd) == NULL)
       return ((char *)0);
   cp = index(line, '\n');
   if (cp)
       *cp = '\0';
   return (line);
}

char *newstr (char *cp) {
   if (cp = strdup(cp ? cp : ""))
       return(cp);
   syslog(LOG_ERR, "strdup: %m");
   exit(-1);
}

void config (void)
{
   struct altab *sep, *cp, **sepp;
   struct altab *getconfigent(), *enter();
   long omask;
   int n;
   int port;
   
   if (!setconfig())
       {
       msglog(LOG_ERR, "%s: %m", CONFNAME);
       return;
       }
   msglog(LOG_TRACE, "config file openned succefuly");
   while (cp = getconfigent())
       {
       port = htons(atoi(cp->di_service));
       msglog(LOG_WARN,"%s %s %s", cp->di_host,
       cp->di_service, cp->di_dpm);
       if (!port)
           {
           sp = getservbyname(cp->di_service, "tcp");
           if (sp == 0)
               {
               msglog(LOG_ERR, "%s/%s: unknown service",
                   cp->di_service, "tcp");
               continue;
               }
           port = sp->s_port;
           }
       msglog(LOG_TRACE,"port no %d found",port);
       }
   endconfig();
}

static void open_osockt (void)
{
   int length;
   int on = 1;
   
   Debug = 9;
   msglog(LOG_ERR,"open_osock");
   Debug = 0;
   gethostname(hostname, sizeof (hostname));
   my_machine_name = hostname;
   msglog(LOG_TRACE,"mymachine is %s",my_machine_name);
   hp = gethostbyname(my_machine_name);
   if (hp == NULL)
       {
       msglog(LOG_ERR,"gethostbyname failed %s",al.di_host);
       exit(-1);
       }
   msglog(LOG_DEBUG,"get my host by name succeeded ");
   bcopy(hp->h_addr, (char *)&my_machine_addr, hp->h_length);
   my_addr.sin_addr = my_machine_addr;
   my_addr.sin_port = sp->s_port;
   
   osockt = socket(AF_INET, SOCK_STREAM, 0);
   if (osockt <= 0)
       {
       msglog(LOG_ERR,"Bad socket");
       exit(1);
       }
   msglog(LOG_TRACE,"socket succeeded");
   bzero((char *)&hisaddr, sizeof (hisaddr));
   hisaddr.sin_addr.s_addr = inet_addr(al.di_host);
   if (hisaddr.sin_addr.s_addr != -1)
       {
   
       hisaddr.sin_family = AF_INET;
       (void) strncpy(hostname, al.di_host, sizeof(hostname));
       }
   else
       {
       hp = gethostbyname(al.di_host);
       if (hp == NULL)
           {
           msglog(LOG_ERR,"gethostbyname failed %s",al.di_host);
           exit(-1);
           }
       hisaddr.sin_family = hp->h_addrtype;
       bcopy(hp->h_addr_list[0], (caddr_t)&hisaddr.sin_addr, hp->h_length);
       (void) strncpy(hostname, hp->h_name, sizeof(hostname));
       }
   hisaddr.sin_port = sp->s_port;
   while (1)
       {
       int cc;
       cc = connect(osockt, (struct sockaddr *)&hisaddr, sizeof (hisaddr));
       if (cc  < 0)
           {           /* The other machine might be down */
           msglog("cannot connect socket errno %d",errno);
           sleep(10);
           }
       else
           break;
       }
   
   if (getsockname(osockt, (struct sockaddr *)&my_addr, &length) == -1)
           msglog(LOG_ERR,"Bad address for socket %d",errno);
   
   if(setsockopt(0, SOL_SOCKET, SO_KEEPALIVE, (char *)&on,sizeof(on)) < 0)
           msglog(LOG_ERR,"sotsock faild t %d",errno);
}


static void open_isockt(void)
{
   int length;
   int on = 1;
   
   gethostname(hostname, sizeof (hostname));
   my_machine_name = hostname;
   msglog(LOG_TRACE,"open_isock mymachine is %s",my_machine_name);
   hp = gethostbyname(my_machine_name);
   if (hp == NULL)
       {
       msglog(LOG_ERR,"gethostbyname failed %s",al.di_host);
       exit(-1);
       }
   bcopy(hp->h_addr, (char *)&my_machine_addr, hp->h_length);
   my_addr.sin_addr = my_machine_addr;
   my_addr.sin_port = sp->s_port;
   
   isockt = socket(AF_INET, SOCK_STREAM, 0);
   
   if (isockt <= 0)
       {
       msglog(LOG_ERR,"Bad socket");
       exit(1);
       }
   if (bind(isockt, (struct sockaddr *)&my_addr, sizeof(my_addr)) != 0)
       msglog(LOG_ERR,"Binding local socket %d",errno);
   length = sizeof(my_addr);
   
   if ((listen(isockt,5)) == -1)
       msglog(LOG_ERR,"listen failed local socket %d",errno);
   if (getsockname(isockt, (struct sockaddr *)&my_addr, &length) == -1)
       msglog(LOG_ERR,"Bad address for socket %d",errno);
   if (setsockopt(0, SOL_SOCKET, SO_KEEPALIVE, (char *)&on,sizeof(on)) < 0)
       msglog(LOG_ERR,"sotsock faild t %d",errno);
}

static int send_unix( char *s,int len)
{
   if(write(osockt,s,len) != len)
       {
       msglog(LOG_ERR,"send %d",errno);
       return(errno);
       }
   return(0);
}

static void sig_action (int signum)
{
   msglog(LOG_WARN,"Signal exiting ! ");
   close(isockt);
   close(osockt);
   die(0);
}

/* write_ahost -- used to write an a-host message to the DPM device */

static void write_ahost (void)
{
   char *cp;
   if (A_len == 0)
       {
       msglog(LOG_ERR, "Write request size == 0");
       return;
   }
   
   while (write(DPM_ofd, A_msg, A_len) != A_len)
       {
       msglog(LOG_ERR, "Write failure to %s: %s len=%d",
           DPM_channel, strerror(errno), A_len);
       die(1);
    }
}

/* close the DPM_fd reopen and reactivate the daemon */

static void new_child (int signum)
{
   close(DPM_ifd);
   close(DPM_ofd);
   close(isockt);
   close(osockt);
   dispatch(RESURRECT);
}

/* =================== end of file ================ */
