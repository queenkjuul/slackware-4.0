/*
 * Northrop Grumman ACC286 Device Driver
 *
 * This code has never been tested!
 * Many functions are only partially implemented!
 * This is pre-alpha-test code !!
 * ***** YOU HAVE TO WRITE MICROCODE TO DO ANYTHING USEFUL!    *****
 * ***** THIS CARD NEEDS MICROCODE TO RUN ! NONE IS SUPPLIED ! *****
 *
 * features: 
 * Its a loadable module:
 * To load, list and unload the module, do the following:
 * /sbin/insmod /lib/modules/2.1.26/misc/acc286.o
 * /sbin/lsmod
 * /sbin/rmmod acc286
 *
 * we randomly steal minor device number 62
 * from major device 10 (misc) (used mostly for mice & etc.)
 * 
 * to create the entry in /dev, do the following:
 * mknod acc286- c 10 62 &&
 * chown root:sys acc286- &&
 * chmod 666 acc286- &&
 * mv acc286- acc286
 *
 * Uses proc file system for easy programming:
 * cat /proc/acc286 to see stats 
 * echo "reset" > /proc/acc286    to perform general reset
 * echo "stop" > /proc/acc286      to halt running microcode
 * echo "run" > /proc/acc286      to start running microcode
 * echo "irq nn" > /proc/acc286
 * echo "cr_base nn" > /proc/acc286
 * echo "window_size 0xnnn" > /proc/acc286
 * echo "window_base 0xnnn" > /proc/acc286
 * echo "window_enable" > /proc/acc286
 * echo "window_disable" > /proc/acc286
 * cat microcode.exe > /proc/acc286  to download microcode
 *
 * window must be disabled to set its size or base.
 * window size must be set before base.
 *
 * to be more compatible with other unixes, most of these proc 
 * functions should be moved to  ioctl and/or /dev/acc286_ctl
 *
 *
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program; if not, write to the Free Software
 *     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#include <linux/module.h>

#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/signal.h>
#include <linux/errno.h>
#include <linux/mm.h>
#include <linux/poll.h>
#include <linux/malloc.h>
#include <linux/miscdevice.h>
#include <linux/random.h>
#include <linux/delay.h>
#include <linux/ioport.h>
#include <linux/string.h>

#ifdef CONFIG_PROC_FS
#include <linux/stat.h>
#include <linux/proc_fs.h>
#endif

#include <asm/io.h>
#include <asm/uaccess.h>
#include <asm/system.h>
#include <asm/irq.h>

#include <stdlib.h> /* is this legal ?? */

#include "acc286.h"

#define ACC286_MINOR_DEVICE   62      /* minor device number */
#define ACC286_DEFAULT_IRQ    10      /* default IRQ */
#define ACC286_BUFFER_SIZE    4096    /* internal buffer size */
#define ACC286_DEFAULT_WINDOW_BASE   0x80000  
#define ACC286_DEFAULT_WINDOW_EXTENT 0x10000    /* 65536 */

struct acc286_status {
   unsigned int cr_base;        /* control reg base */
   short present;        /* hardware is present and detected */
   short downloaded;     /* microcode has been loaded */
   short ready;
   short active;         /* device has been opened */

   short window_enabled;        /* sliding window location, in host mem */
   unsigned int window_base;    /* sliding window base, in host mem */
   unsigned int window_extent;  /* sliding window extent, in host mem */

   char * loco;
   struct wait_queue *waitq;
};

static struct acc286_status acc286;
static int acc286_irq = ACC286_DEFAULT_IRQ;


/* ================================================ */

static int acc286_util_reset (void) 
{
   char cr3, cr4;

   /* test for presence of hardware by masking interrupts, 
    * using interrupt self test */
   cr3 = 0x0;
   cr3 |= ACC_PROC_RESET;    /* make sure nothing is running */
   cr3 |= HIGH_WINDOW_DISABLE;   /* don't use high mem window */
   cr3 |= BUS_XFER_16BIT;    /* use 16 bit xfers */ 
   cr3 &= ~IRQ_SELECT_MASK;  /* disable programmable inttrrupt */
   outb(cr3, ACC286_CR3_PORT);

   cr4 = 0;
   cr4 |= WINDOW_DISABLE;
   cr4 |= IRQ_CLEAR;       /* clear any garbage */
   outb(cr4, ACC286_CR4_PORT);

   cr4 = 0;
   cr4 |= WINDOW_DISABLE;
   cr4 |= IRQ_TEST_GEN;       /* generate interrupt */
   outb(cr4, ACC286_CR4_PORT);

   cr4 = inb (ACC286_CR4_PORT);
/*
   if (!(cr4 & HOST_ATTN_MASK)) {
      acc286.present = 0;
      return -EIO;
   }
*/

   /* clear the irq garbage we just created */
   cr4 = 0;
   cr4 |= WINDOW_DISABLE;
   cr4 |= IRQ_CLEAR;       /* clear any garbage */
   outb(cr4, ACC286_CR4_PORT);

   return 0;
}

/* ================================================ */

static void acc286_util_set_irq (int irq) 
{
   char cr3;

   cr3 = inb(ACC286_CR3_PORT); 

   /* set programmable interrupt */
   cr3 &= ~IRQ_SELECT_MASK;
   switch (irq) {
      case 5: cr3 |= IRQ_SELECT_5; break;
      case 6: cr3 |= IRQ_SELECT_6; break;
      case 7: cr3 |= IRQ_SELECT_7; break;
      case 10: cr3 |= IRQ_SELECT_10; break;
      case 11: cr3 |= IRQ_SELECT_11; break;
      case 14: cr3 |= IRQ_SELECT_14; break;
      case 15: cr3 |= IRQ_SELECT_15; break;
      default:
         return;  /* not a valid irq, return */
   }

   acc286_irq = irq;

   outb(cr3, ACC286_CR3_PORT);
}

/* ================================================ */

static void acc286_util_run_ucode (void) 
{
   char cr3;
   cr3 = inb(ACC286_CR3_PORT); 
   cr3 &= ACC_PROC_MASK;
   cr3 |= ACC_PROC_RUN;    /* start  running microcode */
   outb(cr3, ACC286_CR3_PORT);
}

/* ================================================ */

static void acc286_util_stop_ucode (void) 
{
   char cr3;
   cr3 = inb(ACC286_CR3_PORT); 
   cr3 &= ACC_PROC_MASK;
   cr3 |= ACC_PROC_RESET;    /* halt microcode */
   outb(cr3, ACC286_CR3_PORT);
}

/* ================================================ */

static void acc286_util_set_window_base (unsigned int base) 
{
   char cr1;

   /* window must be disabled for this to have effect */
   if (acc286.window_enabled) return;
   if ((0x80000 > base) || (0x100000 < base)) return;

   /* region must be properly aligned */
   if (base % acc286.window_extent) return;

   acc286.window_base = base;
   base -= 0x80000;
   base /= 0x2000;

   cr1 = inb(ACC286_CR1_PORT); 
   cr1 &= WINDOW_BASE_MASK;
   cr1 |= WINDOW_SIZE_MASK & (base <<2);
   outb(cr1, ACC286_CR1_PORT);

   return;
}

/* ================================================ */

static void acc286_util_set_window_size (unsigned int size) 
{
   char sz=0, cr1;

   /* window must be disabled for this to have effect */
   if (acc286.window_enabled) return;

   switch (size) {
      case 0x2000: sz = WINDOW_SIZE_8K; break;
      case 0x4000: sz = WINDOW_SIZE_16K; break;
      case 0x8000: sz = WINDOW_SIZE_32K; break;
      case 0x10000: sz = WINDOW_SIZE_64K; break;
      default: return;
   }
   acc286.window_extent = size;

   cr1 = inb(ACC286_CR1_PORT); 
   cr1 &= WINDOW_SIZE_MASK;
   cr1 |= sz & WINDOW_SIZE_MASK;
   outb(cr1, ACC286_CR1_PORT);
}

/* ================================================ */

static int acc286_util_window_enable (void) 
{
   char cr4;

   if (acc286.window_enabled) return 0;

   cr4 = inb(ACC286_CR4_PORT); 
   cr4 &= WINDOW_ENABLE_MASK;
   cr4 |= WINDOW_ENABLE;
   outb(cr4, ACC286_CR4_PORT);

   acc286.window_enabled = 1;

   return 0;
}

/* ================================================ */

static void acc286_util_window_disable (void) 
{
   char cr4;

   if (!acc286.window_enabled) return;

   cr4 = inb(ACC286_CR4_PORT); 
   cr4 &= WINDOW_ENABLE_MASK;
   cr4 |= WINDOW_DISABLE;
   outb(cr4, ACC286_CR4_PORT);

   acc286.window_enabled = 0;

   return;
}

/* ================================================ */

static void acc286_util_set_maddress (char ma) 
{
   outb(ma, ACC286_CR2_PORT);
}

/* ================================================ */

static int acc286_util_download_ucode
                      (const char *buffer, unsigned long len) 
{
   int i;
   unsigned int curr_host_addr;
   unsigned char microaddress;  /* AKA sliding address */
   unsigned char tmpbuf [0x2000];

   acc286_util_window_enable ();


   microaddress = 0x0;
   curr_host_addr = acc286.window_base;

   for (i=0; i<len; i+= 0x2000) {

      acc286_util_set_maddress (microaddress);
      copy_from_user (tmpbuf, buffer, 0x2000);

      /* I really don't understand this virtual/real addres crap 
       * it seems like a lot of net drivers use this memcopy, without 
       * doing anything to clue the kernel in on the memory address 
       * Is this safe because the region is under 1Meg, and the kernel 
       * knows not to put virtual mem under 1 Meg? */
      memcpy_toio (curr_host_addr, tmpbuf, 0x2000); 

      curr_host_addr += 0x2000;
      curr_host_addr %= acc286.window_extent;  
      if (!curr_host_addr) curr_host_addr = acc286.window_base;

      microaddress ++;
   }

   acc286.downloaded = 1;
   return 0;
}

/* ================================================ */

#ifdef CONFIG_PROC_FS

/* 
 * in order to get the module to load, we need to export
 * two ksyms not currently exported:
 * proc_readdir and proc_lookup, in
 * in fs/proc/ksyms.c
 * have to edit that to do this.
 */

long acc286_proc_read (struct inode*, struct file *, char *, unsigned long);
long acc286_proc_write (struct inode*, struct file *, const char *, unsigned long);

static struct file_operations acc286_proc_operations = {
        NULL,                  /* lseek */
        acc286_proc_read,      /* acc286 read */
        acc286_proc_write,     /* acc286 write */
        proc_readdir,          /* generic readdir */
        NULL,                  /* poll */
        NULL,                  /* ioctl */
        NULL,                  /* mmap */
        NULL,                  /* no special open code */
        NULL,                  /* no special release code */
        NULL                   /* can't fsync */
};

static struct inode_operations acc286_inode_ops = {
        &acc286_proc_operations, /* default base directory file-ops */
        NULL,                   /* create */
        proc_lookup,            /* generic lookup */
        NULL,                   /* link */
        NULL,                   /* unlink */
        NULL,                   /* symlink */
        NULL,                   /* mkdir */
        NULL,                   /* rmdir */
        NULL,                   /* mknod */
        NULL,                   /* rename */
        NULL,                   /* readlink */
        NULL,                   /* follow_link */
        NULL,                   /* readpage */
        NULL,                   /* writepage */
        NULL,                   /* bmap */
        NULL,                   /* truncate */
        NULL                    /* permission */

};

static struct proc_dir_entry acc286_proc_entry = 
{
        0,                      /* .low_ino */
        sizeof("acc286") - 1,   /* .namelen */
        "acc286",               /* .name */
        S_IFREG | S_IRUGO | S_IWUSR,  /* .mode regular file, 0644 perms */
        1,                      /* .nlink */
        0,                      /* .uid */
        0,                      /* .gid */
        0,                      /* .size */
        &acc286_inode_ops,      /* .ops */
        NULL,                   /* .get_info */
        NULL,                   /* .fill_node */
        NULL,                   /* .next */
        NULL,                   /* .parent */
        NULL,                   /* .subdir */
        NULL,                   /* .data */
};

/* 4K page size but put in some slack for overruns */
#define PROC_BLOCK_SIZE (3*1024)      

int acc286_proc_report (char*, off_t, int);

long acc286_proc_read (struct inode* inode, struct file* file, 
                    char *buf, unsigned long count) 
{
   unsigned long page;
   int length, end;

   page = __get_free_page (GFP_KERNEL);
   if (!page) return -ENOMEM;

   if (PROC_BLOCK_SIZE < count) count = PROC_BLOCK_SIZE;
   length = acc286_proc_report ((char *)page, file->f_pos, count);

   if (length < 0) {
      free_page(page);
      return length;
   }

    /* Static 4kB (or whatever) block capacity */
    if (file->f_pos >= length) {
       free_page(page);
       return 0;
    }

    if (count + file->f_pos > length) count = length - file->f_pos;
    end = count + file->f_pos;
    copy_to_user (buf, (char *) page + file->f_pos, count);
    file->f_pos = end;
    free_page(page);

    return count;
}

long acc286_proc_write (struct inode* inode, struct file* file, 
                      const char *buffer, unsigned long len) 
{
   int retval = 0;
   unsigned long count;
   if (!acc286.loco) return -ENOMEM;

   if (3>len) return -EINVAL;

   /* copy in first page of stuff from /proc/acc286 */
   memset (acc286.loco, 0, ACC286_BUFFER_SIZE);
   count = len;
   if (ACC286_BUFFER_SIZE <= count) count = ACC286_BUFFER_SIZE-1;
   retval = copy_from_user (acc286.loco, buffer, count);
   if (retval) return -EFAULT;

   if (3>len) return -EINVAL;
   if (!strncmp ("run", acc286.loco, 3)) {
      acc286_util_stop_ucode ();
      acc286_util_run_ucode ();
      return 0;
   }

   if (4>len) return -EINVAL;
   if (!strncmp ("stop", acc286.loco, 4)) {
      acc286_util_stop_ucode ();
      return 0;
   }

   if (5>len) return -EINVAL;
   if (!strncmp ("reset", acc286.loco, 5)) {
      acc286_util_stop_ucode ();
      retval = acc286_util_reset ();
      return retval;
   }

   if (!strncmp ("irq", acc286.loco, 3)) {
      int irq; /* = atoi (&acc286.loco[4]); /* calling atoi not legal */
      acc286_util_set_irq (irq);
      return 0;
   }

   if (8>len) return -EINVAL;
   if (!strncmp ("cr_base", acc286.loco, 6)) {
      /* hack alert - not implemented */
      return 0;
   }

   if (13>len) return -EINVAL;
   if (!strncmp ("window_enable", acc286.loco, 13)) {
      int retval = acc286_util_window_enable (); 
      return retval;
   }

   if (14>len) return -EINVAL;
   if (!strncmp ("window_base 0x", acc286.loco, 14)) {
      char base; /* = atoi (&acc286.loco[14]);  /* calling atoi not legal */
      acc286_util_set_window_base (base); 
      return 0;
   }

   if (!strncmp ("window_size 0x", acc286.loco, 14)) {
      char base; /* = atoi (&acc286.loco[14]);  /* calling atoi not legal */
      acc286_util_set_window_size (base); 
      return 0;
   }

   if (!strncmp ("window_disable", acc286.loco, 14)) {
      acc286_util_window_disable (); 
      return 0;
   }


   /* unrecognized, treat as microcode */
   /* maybe we should check for a signature byte ... */
   retval = acc286_util_download_ucode (buffer, len); 
   if (retval) return retval;

   return 0;
}

/*
 * nice utility ... just be careful not to overrun 4K
 * if more than 4K needed, then alloc more pages above.
 * should check length, to be safe ...
 */

int acc286_proc_report (char* buf, off_t fpos, int length)
{

   int len=0;
   len += sprintf (buf+len, "Northrop-Grumman ACC286 Device Driver \n");
   len += sprintf (buf+len, "present=%d ucode-loaded=%d ready=%d active=%d \n", 
                                   acc286.present, acc286.downloaded,
                                   acc286.ready, acc286.active);
   len += sprintf (buf+len, "using IRQ %d CR Base 0x%x \n", 
                             acc286_irq, acc286.cr_base);
   len += sprintf (buf+len, " buff=%s \n", acc286.loco);
   return len;
}

#endif

/* 
 * need to add to init/main.c the following lines:
 * extern void acc286_setup(char *str, int *ints);
 * and in profile_setup, 
 * {"acc286=", acc286_setup },
 */

void acc286_setup(char *str, int *ints)
{
   if (ints[0] > 0)
      acc286_irq=ints[1];
}

static void acc286_interrupt(int irq, void *dev_id, struct pt_regs *regs)
{

   /* OK, we caught an interrupt. Do the i/o to the board. */

   /* if someone did a select() on us, let them know we are here. */
   wake_up_interruptible(&acc286.waitq);
}

/*
 * close access to the acc286
 */

static void close_acc286(struct inode * inode, struct file * file)
{
   MOD_DEC_USE_COUNT;
   if (--acc286.active) return;

   /* free  irq only if use count is down to zero */
   free_irq(acc286_irq, NULL);
}

/*
 * open access to the acc286
 */

static int open_acc286(struct inode * inode, struct file * file)
{
   char cr3 = 0;

/*
   if (!acc286.present) return -ENXIO;
   if (!acc286.downloaded) return -ENOPKG;
*/

   /* if not the first open, then we are done */
   MOD_INC_USE_COUNT;
   if (acc286.active++) return 0;

   /* do this stuff only for the very first open */
   if (request_irq(acc286_irq, acc286_interrupt, 0, "acc286", NULL)) {
      acc286.active--;
      MOD_DEC_USE_COUNT;
      return -EBUSY;
   }

   /* cr3 = inb(ACC286_CR3_PORT); */
   cr3 = 0x0;
   cr3 |= ACC_PROC_RUN;    /* start  running microcode */
   cr3 |= HIGH_WINDOW_DISABLE;   /* don't use high mem window */
   cr3 |= BUS_XFER_16BIT;    /* use 16 bit xfers */ 
   outb(cr3, ACC286_CR3_PORT);

   /* set programmable interrupt */
   acc286_util_set_irq (acc286_irq); 


   acc286.ready = 1;
   return 0;
}

/*
 * get stuff from user
 */

static long write_acc286(struct inode * inode, struct file * file,
   const char * buffer, unsigned long count)
{
   int i=0;

   if (!acc286.loco) return -ENOMEM;

   if (ACC286_BUFFER_SIZE <= count) count = ACC286_BUFFER_SIZE-1;
   for (i=0; i<count; i++){
      get_user (acc286.loco[i], &buffer[i]);
   }
   acc286.loco[i] = 0x0;

   return 0;
}

/*
 * read acc286 data.  Currently never blocks.
 */

static long read_acc286(struct inode * inode, struct file * file,
   char * buffer, unsigned long count)
{
   int r;
   int lbufflen = 0;

   if (count < 3) return -EINVAL;
   if ((r = verify_area(VERIFY_WRITE, buffer, count))) return r;
   if (!acc286.ready) return -EAGAIN;
   if (!acc286.loco) return -ENOMEM;

   if (file->f_flags & O_NONBLOCK) {}
   
   /*
    * Interrupts are only disabled while 
    * obtaining the parameters, NOT during the puts_fs_byte() calls,
    * so paging in put_user() does not effect acc286 tracking.
    */
   
   
   /* save_flags(flags); cli();   / * disable interrupts */
   
   disable_irq(acc286_irq);
   acc286.ready = 0;
   enable_irq(acc286_irq);
   
   /* restore_flags(flags);       / * enable interrupts */

   udelay(1000L);  /* no particular reason, lets just go slow */

   acc286.ready = 1;

   lbufflen = strlen (acc286.loco);

   if (ACC286_BUFFER_SIZE -20 < lbufflen) lbufflen = ACC286_BUFFER_SIZE-20;
   sprintf (&acc286.loco[lbufflen], "active %d ", acc286.active);
   lbufflen = strlen (acc286.loco);

   for (r = 0; r < lbufflen; r++) {
      put_user(acc286.loco[r], buffer + r);
   }
   for (; r < count; r++) {
      put_user(0x0, buffer + r);
    }

   return r;
}

/*
 * poll for acc286 input
 */
static unsigned int acc286_poll(struct file *file, poll_table * wait)
{
   /* put ourselves on the queue */
   poll_wait(&acc286.waitq, wait);

   /* let select() know our mask */
   if (acc286.ready) return POLLIN | POLLOUT | POLLRDNORM | POLLWRNORM;
   return 0;
}

struct file_operations acc286_fops = {
   NULL,            /* seek */
   read_acc286,
   write_acc286,
   NULL,            /* readdir */
   acc286_poll,     /* poll */
   NULL,            /* ioctl */
   NULL,            /* mmap */
   open_acc286,
   close_acc286,
   NULL,            /* fsync */
   NULL,            /* fasync */
   NULL,            /* media change */
   NULL,            /* revalidate */
};


static struct miscdevice acc286_device = {
   ACC286_MINOR_DEVICE, "acc286", &acc286_fops
};


int acc286_init(void)
{
   int retval;

   /* initialize our structures */
   acc286.cr_base = ACC286_CR_BASE_DEFAULT;
   acc286.loco = 0x0;
   acc286.present = 0;
   acc286.downloaded = 0;
   acc286.active = 0;
   acc286.ready = 0;
   acc286.waitq = NULL;
   acc286.window_enabled = 0;
   acc286.window_base = ACC286_DEFAULT_WINDOW_BASE;
   acc286.window_extent = ACC286_DEFAULT_WINDOW_EXTENT;

   if (check_region(ACC286_CR_BASE, ACC286_CR_EXTENT)) {
      acc286.present = 0;
      return -EIO;
   }

   request_region(ACC286_CR_BASE, ACC286_CR_EXTENT, "acc286");

   /* test for presence of hardware, reset hardware */ 
   retval = acc286_util_reset ();
   if (retval) return retval;

   acc286.present = 1;
   printk(KERN_INFO "ACC286 device detected, using IRQ %d.\n",
          acc286_irq);

   acc286_util_window_disable ();
   acc286_util_set_window_size (acc286.window_extent);
   acc286_util_set_window_base (acc286.window_base);

   /* grab other assorted resources, register */
   acc286.loco = (char *) kmalloc (ACC286_BUFFER_SIZE, GFP_KERNEL);
   if (!acc286.loco) return -ENOMEM;
   acc286.loco[0] = 0x0;

#ifdef CONFIG_PROC_FS
   proc_register_dynamic (&proc_root, &acc286_proc_entry);
#endif 
   misc_register(&acc286_device);

   return 0;
}

#ifdef MODULE

int init_module(void)
{
   return acc286_init();
}

void cleanup_module(void)
{
   kfree_s (acc286.loco, ACC286_BUFFER_SIZE);
   acc286.loco = 0;

#ifdef CONFIG_PROC_FS
   proc_unregister (&proc_root, acc286_proc_entry.low_ino);
#endif 

   misc_deregister(&acc286_device);
   release_region(ACC286_CR_BASE, ACC286_CR_EXTENT);
}
#endif
