#!/usr/bin/perl
# client program

($them,$port) = @ARGV;
$port = 6600 unless $port;
$them = 'lab122' unless $them;

$AF_INET = 2;
$SOCK_STREAM = 1;

$SIG{'INT'} = 'dokill';
sub dokill {
	kill 9, $child if $child;
	print "shuting down\n";
	close DPM;
	shutdown(S,2);
}

sub proctoterm {
	$obuf = "";
	$len1 = length $_;
	for ($c = 0; $c < $len1; $c = $c +3) {
		$y = substr($_, $c, 2);
		$x = pack ('H2', $y);
		$obuf = $obuf.$x;
	}
}

sub proctohost {
	$obuf = "";
	for ($c = 0; $c < $len; $c++) {
		$y = substr($buf, $c, 1);
		$x = unpack ('H2', $y);
		$obuf = $obuf.$x." ";
	}
 }

$sockaddr = 'S n a4 x8';

chop($hostname = `hostname`);

($name, $aliases, $proto) = getprotobyname('tcp');
($name, $aliases, $port) = getservbyname($port,'tcp')
	unless $port =~ /^\d+$/;;
($name, $aliases, $type, $len, @thisaddr) = gethostbyname($hostname);
($name, $aliases, $type, $len, $thataddr) = gethostbyname($them);

$thataddr = (gethostbyname($them))[4];

	($a, $b, $c, $d) = unpack('C4', $thisaddr[0]);
	printf "us  : %d.%d.%d.%d\n", $a, $b, $c, $d;
	($a, $b, $c, $d) = unpack('C4', $thataddr[0]);
	printf "them: %d.%d.%d.%d\n", $a, $b, $c, $d;

$this = pack($sockaddr, $AF_INET, 0, $thisaddr);
$that = pack($sockaddr, $AF_INET, $port, $thataddr);

	($one, $two, @three, $four) = unpack ($sockaddr, $that);
	($a, $b, $c, $d) = unpack('C4', $three[0]);
	printf "%d %d %d.%d.%d.%d %x\n", $one, $two, $a, $b, $c, $d, $four;


if (socket(S, $AF_INET, $SOCK_STREAM, $proto)) {  # make the socket filehandle
	print "socket ok\n";
}
else {
	die $!;
}

if (bind(S, $this)) {				# give the socket an address
	print "bind ok\n";
}
else {
	die $!;
}

if (connect(S,$that)) {				#call up the server
	print "connect ok\n";
}
else {
	die $!;
}

#set socket to be command buffered

select(S); $| = 1; select(STDOUT);
open (DPM, "+</dev/dpm/dpmb13");

#avoid deadlock by forking

if ($child = fork) {
	while (1) {
		$len = sysread(DPM,$buf,8000);
		if ($len == 0) {
			exit 0;
		}
		proctohost();
		print S "$obuf\n";
	}
}
else {
	while(<S>) {
	#print "$_";
		proctoterm();
		$len1--;
		$len1 = $len1 / 3;
		syswrite(DPM,$obuf,$len1);
	#print "len: $len1, xxx:$obuf\n";
	}
}

# ---------------- end of file ----------------
