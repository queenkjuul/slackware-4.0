/*
 * Ipars/Ascii translate tables
 *   Auto generated Sun Nov 13 05:52:19 EST 1994
 */
typedef unsigned char uchar;

#define DEL_CH  0x100
#define EOM_CH  0x200

/*
 *  ipars   mangle  disp
 */
int Mangle_To_Ipars[] = {
    DEL_CH, /* 00   NUL  */
    DEL_CH, /* 01   NUL  */
    DEL_CH, /* 02   NUL  */
    DEL_CH, /* 03   NUL  */
    DEL_CH, /* 04   NUL  */
    DEL_CH, /* 05   NUL  */
    DEL_CH, /* 06   NUL  */
    DEL_CH, /* 07   NUL  */
    DEL_CH, /* 08   NUL  */
    DEL_CH, /* 09   NUL  */
    DEL_CH, /* 0A   NUL  */
    DEL_CH, /* 0B   NUL  */
    DEL_CH, /* 0C   NUL  */
    DEL_CH, /* 0D   NUL  */
    DEL_CH, /* 0E   NUL  */
    DEL_CH, /* 0F   NUL  */

    DEL_CH, /* 10   NUL  */
    DEL_CH, /* 11   NUL  */
    DEL_CH, /* 12   NUL  */
    DEL_CH, /* 13   NUL  */
    DEL_CH, /* 14   NUL  */
    DEL_CH, /* 15   NUL  */
    DEL_CH, /* 16   NUL  */
    DEL_CH, /* 17   NUL  */
    DEL_CH, /* 18   NUL  */
    DEL_CH, /* 19   NUL  */
    DEL_CH, /* 1A   NUL  */
    DEL_CH, /* 1B   NUL  */
    DEL_CH, /* 1C   NUL  */
    DEL_CH, /* 1D   NUL  */
    DEL_CH, /* 1E   NUL  */
    DEL_CH, /* 1F   NUL  */

    DEL_CH, /* 20   NUL  */
    DEL_CH, /* 21   NUL  */
    DEL_CH, /* 22   NUL  */
    DEL_CH, /* 23   NUL  */
    DEL_CH, /* 24   NUL  */
    DEL_CH, /* 25   NUL  */
    DEL_CH, /* 26   NUL  */
    DEL_CH, /* 27   NUL  */
    DEL_CH, /* 28   NUL  */
    DEL_CH, /* 29   NUL  */
    DEL_CH, /* 2A   NUL  */
    DEL_CH, /* 2B   NUL  */
    DEL_CH, /* 2C   NUL  */
    DEL_CH, /* 2D   NUL  */
    DEL_CH, /* 2E   NUL  */
    DEL_CH, /* 2F   NUL  */

    DEL_CH, /* 30   NUL  */
    DEL_CH, /* 31   NUL  */
    DEL_CH, /* 32   NUL  */
    DEL_CH, /* 33   NUL  */
    DEL_CH, /* 34   NUL  */
    DEL_CH, /* 35   NUL  */
    DEL_CH, /* 36   NUL  */
    DEL_CH, /* 37   NUL  */
    DEL_CH, /* 38   NUL  */
    DEL_CH, /* 39   NUL  */
    DEL_CH, /* 3A   NUL  */
    DEL_CH, /* 3B   NUL  */
    DEL_CH, /* 3C   NUL  */
    DEL_CH, /* 3D   NUL  */
    DEL_CH, /* 3E   NUL  */
    DEL_CH, /* 3F   NUL  */

     0x3F,  /* 40   --   */
     0x1F,  /* 41   ,    */
     0x2F,  /* 42   (    */
     0x0F,  /* 43   DC2  */
     0x37,  /* 44   G    */
     0x17,  /* 45   X    */
     0x27,  /* 46   P    */
     0x07,  /* 47   7    */
     0x3B,  /* 48   .    */
     0x1B,  /* 49   #    */
     0x2B,  /* 4A   >    */
     0x0B,  /* 4B   *    */
     0x33,  /* 4C   C    */
     0x13,  /* 4D   T    */
     0x23,  /* 4E   L    */
     0x03,  /* 4F   3    */

     0x3D,  /* 50   --   */
     0x1D,  /* 51   EOMc(%)  */
     0x2D,  /* 52   ;    */
     0x0D,  /* 53   $    */
     0x35,  /* 54   E    */
     0x15,  /* 55   V    */
     0x25,  /* 56   N    */
     0x05,  /* 57   5    */
     0x39,  /* 58   I    */
     0x19,  /* 59   Z    */
     0x29,  /* 5A   R    */
     0x09,  /* 5B   9    */
     0x31,  /* 5C   A    */
     0x11,  /* 5D   /    */
     0x21,  /* 5E   J    */
     0x01,  /* 5F   1    */

     0x3E,  /* 60   --   */
     0x1E,  /* 61   --   */
     0x2E,  /* 62   )    */
     0x0E,  /* 63   =    */
     0x36,  /* 64   F    */
     0x16,  /* 65   W    */
     0x26,  /* 66   O    */
     0x06,  /* 67   6    */
     0x3A,  /* 68   EOMi(?)  */
     0x1A,  /* 69   -    */
     0x2A,  /* 6A   :    */
     0x0A,  /* 6B   0    */
     0x32,  /* 6C   B    */
     0x12,  /* 6D   S    */
     0x22,  /* 6E   K    */
     0x02,  /* 6F   2    */

     0x3C,  /* 70   --   */
     0x1C,  /* 71   space    */
     0x2C,  /* 72   +    */
     0x0C,  /* 73   NL   */
     0x34,  /* 74   D    */
     0x14,  /* 75   U    */
     0x24,  /* 76   M    */
     0x04,  /* 77   4    */
     0x38,  /* 78   H    */
     0x18,  /* 79   Y    */
     0x28,  /* 7A   Q    */
     0x08,  /* 7B   8    */
     0x30,  /* 7C   &    */
     0x10,  /* 7D   '    */
     0x20,  /* 7E   @    */
     0x00,  /* 7F   NUL  */

};

/*
 *  mangle  ipars   disp
 */
int Ipars_To_Mangle[] = {
     0x7F,  /* 00   NUL  */
     0x5F,  /* 01   1    */
     0x6F,  /* 02   2    */
     0x4F,  /* 03   3    */
     0x77,  /* 04   4    */
     0x57,  /* 05   5    */
     0x67,  /* 06   6    */
     0x47,  /* 07   7    */
     0x7B,  /* 08   8    */
     0x5B,  /* 09   9    */
     0x6B,  /* 0A   0    */
     0x4B,  /* 0B   *    */
     0x73,  /* 0C   NL   */
     0x53,  /* 0D   $    */
     0x63,  /* 0E   =    */
     0x43,  /* 0F   DC2  */

     0x7D,  /* 10   '    */
     0x5D,  /* 11   /    */
     0x6D,  /* 12   S    */
     0x4D,  /* 13   T    */
     0x75,  /* 14   U    */
     0x55,  /* 15   V    */
     0x65,  /* 16   W    */
     0x45,  /* 17   X    */
     0x79,  /* 18   Y    */
     0x59,  /* 19   Z    */
     0x69,  /* 1A   -    */
     0x49,  /* 1B   #    */
     0x71,  /* 1C   space    */
     0x51,  /* 1D   EOMc(%)  */
     0x61,  /* 1E   --   */
     0x41,  /* 1F   ,    */

     0x7E,  /* 20   @    */
     0x5E,  /* 21   J    */
     0x6E,  /* 22   K    */
     0x4E,  /* 23   L    */
     0x76,  /* 24   M    */
     0x56,  /* 25   N    */
     0x66,  /* 26   O    */
     0x46,  /* 27   P    */
     0x7A,  /* 28   Q    */
     0x5A,  /* 29   R    */
     0x6A,  /* 2A   :    */
     0x4A,  /* 2B   >    */
     0x72,  /* 2C   +    */
     0x52,  /* 2D   ;    */
     0x62,  /* 2E   )    */
     0x42,  /* 2F   (    */

     0x7C,  /* 30   &    */
     0x5C,  /* 31   A    */
     0x6C,  /* 32   B    */
     0x4C,  /* 33   C    */
     0x74,  /* 34   D    */
     0x54,  /* 35   E    */
     0x64,  /* 36   F    */
     0x44,  /* 37   G    */
     0x78,  /* 38   H    */
     0x58,  /* 39   I    */
     0x68,  /* 3A   EOMi(?)  */
     0x48,  /* 3B   .    */
     0x70,  /* 3C   --   */
     0x50,  /* 3D   --   */
     0x60,  /* 3E   --   */
     0x40,  /* 3F   --   */

    DEL_CH, /* 40   --   */
    DEL_CH, /* 41   --   */
    DEL_CH, /* 42   --   */
    DEL_CH, /* 43   --   */
    DEL_CH, /* 44   --   */
    DEL_CH, /* 45   --   */
    DEL_CH, /* 46   --   */
    DEL_CH, /* 47   --   */
    DEL_CH, /* 48   --   */
    DEL_CH, /* 49   --   */
    DEL_CH, /* 4A   --   */
    DEL_CH, /* 4B   --   */
    DEL_CH, /* 4C   --   */
    DEL_CH, /* 4D   --   */
    DEL_CH, /* 4E   --   */
    DEL_CH, /* 4F   --   */

    DEL_CH, /* 50   --   */
    DEL_CH, /* 51   --   */
    DEL_CH, /* 52   --   */
    DEL_CH, /* 53   --   */
    DEL_CH, /* 54   --   */
    DEL_CH, /* 55   --   */
    DEL_CH, /* 56   --   */
    DEL_CH, /* 57   --   */
    DEL_CH, /* 58   --   */
    DEL_CH, /* 59   --   */
    DEL_CH, /* 5A   --   */
    DEL_CH, /* 5B   --   */
    DEL_CH, /* 5C   n/a  */
    DEL_CH, /* 5D   n/a  */
    DEL_CH, /* 5E   n/a  */
    DEL_CH, /* 5F   n/a  */

    DEL_CH, /* 60   --   */
    DEL_CH, /* 61   --   */
    DEL_CH, /* 62   --   */
    DEL_CH, /* 63   --   */
    DEL_CH, /* 64   --   */
    DEL_CH, /* 65   --   */
    DEL_CH, /* 66   --   */
    DEL_CH, /* 67   --   */
    DEL_CH, /* 68   --   */
    DEL_CH, /* 69   --   */
    DEL_CH, /* 6A   --   */
    DEL_CH, /* 6B   --   */
    DEL_CH, /* 6C   --   */
    DEL_CH, /* 6D   --   */
    DEL_CH, /* 6E   --   */
    DEL_CH, /* 6F   --   */

    DEL_CH, /* 70   --   */
    DEL_CH, /* 71   --   */
    DEL_CH, /* 72   --   */
    DEL_CH, /* 73   --   */
    DEL_CH, /* 74   --   */
    DEL_CH, /* 75   --   */
    DEL_CH, /* 76   --   */
    DEL_CH, /* 77   --   */
    DEL_CH, /* 78   --   */
    DEL_CH, /* 79   --   */
    DEL_CH, /* 7A   --   */
    DEL_CH, /* 7B   --   */
    DEL_CH, /* 7C   --   */
    DEL_CH, /* 7D   --   */
    DEL_CH, /* 7E   --   */
    DEL_CH, /* 7F   --   */

};

/*
 *   Mangle to ascii translate table
 *
 *  ascii   mangle  ipars   disp */
static int Mangle_To_Ascii[] = {
    DEL_CH, /* 00   --  --   */
    DEL_CH, /* 01   --  --   */
    DEL_CH, /* 02   --  --   */
    DEL_CH, /* 03   --  --   */
    DEL_CH, /* 04   --  --   */
    DEL_CH, /* 05   --  --   */
    DEL_CH, /* 06   --  --   */
    DEL_CH, /* 07   --  --   */
    DEL_CH, /* 08   --  --   */
    DEL_CH, /* 09   --  --   */
    DEL_CH, /* 0A   --  --   */
    DEL_CH, /* 0B   --  --   */
    DEL_CH, /* 0C   --  --   */
    DEL_CH, /* 0D   --  --   */
    DEL_CH, /* 0E   --  --   */
    DEL_CH, /* 0F   --  --   */

    DEL_CH, /* 10   --  --   */
    DEL_CH, /* 11   --  --   */
    DEL_CH, /* 12   --  --   */
    DEL_CH, /* 13   --  --   */
    DEL_CH, /* 14   --  --   */
    DEL_CH, /* 15   --  --   */
    DEL_CH, /* 16   --  --   */
    DEL_CH, /* 17   --  --   */
    DEL_CH, /* 18   --  --   */
    DEL_CH, /* 19   --  --   */
    DEL_CH, /* 1A   --  --   */
    DEL_CH, /* 1B   --  --   */
    DEL_CH, /* 1C   --  --   */
    DEL_CH, /* 1D   --  --   */
    DEL_CH, /* 1E   --  --   */
    DEL_CH, /* 1F   --  --   */

    DEL_CH, /* 20   --  --   */
    DEL_CH, /* 21   --  --   */
    DEL_CH, /* 22   --  --   */
    DEL_CH, /* 23   --  --   */
    DEL_CH, /* 24   --  --   */
    DEL_CH, /* 25   --  --   */
    DEL_CH, /* 26   --  --   */
    DEL_CH, /* 27   --  --   */
    DEL_CH, /* 28   --  --   */
    DEL_CH, /* 29   --  --   */
    DEL_CH, /* 2A   --  --   */
    DEL_CH, /* 2B   --  --   */
    DEL_CH, /* 2C   --  --   */
    DEL_CH, /* 2D   --  --   */
    DEL_CH, /* 2E   --  --   */
    DEL_CH, /* 2F   --  --   */

    DEL_CH, /* 30   --  --   */
    DEL_CH, /* 31   --  --   */
    DEL_CH, /* 32   --  --   */
    DEL_CH, /* 33   --  --   */
    DEL_CH, /* 34   --  --   */
    DEL_CH, /* 35   --  --   */
    DEL_CH, /* 36   --  --   */
    DEL_CH, /* 37   --  --   */
    DEL_CH, /* 38   --  --   */
    DEL_CH, /* 39   --  --   */
    DEL_CH, /* 3A   --  --   */
    DEL_CH, /* 3B   --  --   */
    DEL_CH, /* 3C   --  --   */
    DEL_CH, /* 3D   --  --   */
    DEL_CH, /* 3E   --  --   */
    DEL_CH, /* 3F   --  --   */

    DEL_CH, /* 40   3F  --   */
     0x2C,  /* 41   1F  ,    */
     0x28,  /* 42   2F  (    */
     0x12,  /* 43   0F  DC2  */
     0x47,  /* 44   37  G    */
     0x58,  /* 45   17  X    */
     0x50,  /* 46   27  P    */
     0x37,  /* 47   07  7    */
     0x2E,  /* 48   3B  .    */
     0x23,  /* 49   1B  #    */
     0x3E,  /* 4A   2B  >    */
     0x2A,  /* 4B   0B  *    */
     0x43,  /* 4C   33  C    */
     0x54,  /* 4D   13  T    */
     0x4C,  /* 4E   23  L    */
     0x33,  /* 4F   03  3    */

    DEL_CH, /* 50   3D  --   */
     0x25,  /* 51   1D  EOMc(%)  */
     0x3B,  /* 52   2D  ;    */
     0x24,  /* 53   0D  $    */
     0x45,  /* 54   35  E    */
     0x56,  /* 55   15  V    */
     0x4E,  /* 56   25  N    */
     0x35,  /* 57   05  5    */
     0x49,  /* 58   39  I    */
     0x5A,  /* 59   19  Z    */
     0x52,  /* 5A   29  R    */
     0x39,  /* 5B   09  9    */
     0x41,  /* 5C   31  A    */
     0x2F,  /* 5D   11  /    */
     0x4A,  /* 5E   21  J    */
     0x31,  /* 5F   01  1    */

    DEL_CH, /* 60   3E  --   */
    DEL_CH, /* 61   1E  --   */
     0x29,  /* 62   2E  )    */
     0x3D,  /* 63   0E  =    */
     0x46,  /* 64   36  F    */
     0x57,  /* 65   16  W    */
     0x4F,  /* 66   26  O    */
     0x36,  /* 67   06  6    */
     0x3F,  /* 68   3A  EOMi(?)  */
     0x2D,  /* 69   1A  -    */
     0x3A,  /* 6A   2A  :    */
     0x30,  /* 6B   0A  0    */
     0x42,  /* 6C   32  B    */
     0x53,  /* 6D   12  S    */
     0x4B,  /* 6E   22  K    */
     0x32,  /* 6F   02  2    */

    DEL_CH, /* 70   3C  --   */
     0x20,  /* 71   1C  space    */
     0x2B,  /* 72   2C  +    */
     0x8A,  /* 73   0C  NL   */
     0x44,  /* 74   34  D    */
     0x55,  /* 75   14  U    */
     0x4D,  /* 76   24  M    */
     0x34,  /* 77   04  4    */
     0x48,  /* 78   38  H    */
     0x59,  /* 79   18  Y    */
     0x51,  /* 7A   28  Q    */
     0x38,  /* 7B   08  8    */
     0x26,  /* 7C   30  &    */
     0x27,  /* 7D   10  '    */
     0x40,  /* 7E   20  @    */
     0x80,  /* 7F   00  NUL  */

};

/*
 *   Ascii to mangle translate table
 *
 *  mangle  ascii   ipars   disp */
static int Ascii_To_Mangle[] = {
     0x7F,  /* 00   00  NUL  */
     0x71,  /* 01   --       */
     0x71,  /* 02   --       */
     0x71,  /* 03   --       */
     0x71,  /* 04   --       */
     0x71,  /* 05   --       */
     0x71,  /* 06   --       */
     0x71,  /* 07   --       */
     0x71,  /* 08   --       */
     0x71,  /* 09   --       */
     0x73,  /* 0A   0C  NL   */
     0x71,  /* 0B   --       */
     0x71,  /* 0C   --       */
    DEL_CH, /* 0D   --  --   */
     0x71,  /* 0E   --       */
     0x71,  /* 0F   --       */

     0x71,  /* 10   --       */
     0x71,  /* 11   --       */
     0x43,  /* 12   0F  DC2  */
     0x71,  /* 13   --       */
     0x71,  /* 14   --       */
     0x71,  /* 15   --       */
     0x71,  /* 16   --       */
     0x71,  /* 17   --       */
     0x71,  /* 18   --       */
     0x71,  /* 19   --       */
     0x71,  /* 1A   --       */
     0x71,  /* 1B   --       */
     0x71,  /* 1C   --       */
     0x71,  /* 1D   --       */
     0x71,  /* 1E   --       */
     0x71,  /* 1F   --       */

     0x71,  /* 20   1C  space    */
     0x71,  /* 21   --       */
     0x71,  /* 22   --       */
     0x49,  /* 23   1B  #    */
     0x53,  /* 24   0D  $    */
    0x251,  /* 25   1D  EOMc(%)  */
     0x7C,  /* 26   30  &    */
     0x7D,  /* 27   10  '    */
     0x42,  /* 28   2F  (    */
     0x62,  /* 29   2E  )    */
     0x4B,  /* 2A   0B  *    */
     0x72,  /* 2B   2C  +    */
     0x41,  /* 2C   1F  ,    */
     0x69,  /* 2D   1A  -    */
     0x48,  /* 2E   3B  .    */
     0x5D,  /* 2F   11  /    */

     0x6B,  /* 30   0A  0    */
     0x5F,  /* 31   01  1    */
     0x6F,  /* 32   02  2    */
     0x4F,  /* 33   03  3    */
     0x77,  /* 34   04  4    */
     0x57,  /* 35   05  5    */
     0x67,  /* 36   06  6    */
     0x47,  /* 37   07  7    */
     0x7B,  /* 38   08  8    */
     0x5B,  /* 39   09  9    */
     0x6A,  /* 3A   2A  :    */
     0x52,  /* 3B   2D  ;    */
     0x71,  /* 3C   --       */
     0x63,  /* 3D   0E  =    */
     0x4A,  /* 3E   2B  >    */
    0x268,  /* 3F   3A  EOMi(?)  */

     0x7E,  /* 40   20  @    */
     0x5C,  /* 41   31  A    */
     0x6C,  /* 42   32  B    */
     0x4C,  /* 43   33  C    */
     0x74,  /* 44   34  D    */
     0x54,  /* 45   35  E    */
     0x64,  /* 46   36  F    */
     0x44,  /* 47   37  G    */
     0x78,  /* 48   38  H    */
     0x58,  /* 49   39  I    */
     0x5E,  /* 4A   21  J    */
     0x6E,  /* 4B   22  K    */
     0x4E,  /* 4C   23  L    */
     0x76,  /* 4D   24  M    */
     0x56,  /* 4E   25  N    */
     0x66,  /* 4F   26  O    */

     0x46,  /* 50   27  P    */
     0x7A,  /* 51   28  Q    */
     0x5A,  /* 52   29  R    */
     0x6D,  /* 53   12  S    */
     0x4D,  /* 54   13  T    */
     0x75,  /* 55   14  U    */
     0x55,  /* 56   15  V    */
     0x65,  /* 57   16  W    */
     0x45,  /* 58   17  X    */
     0x79,  /* 59   18  Y    */
     0x59,  /* 5A   19  Z    */
    DEL_CH, /* 5B   --  --   */
     0x71,  /* 5C   --       */
     0x71,  /* 5D   --       */
     0x71,  /* 5E   --       */
     0x71,  /* 5F   --       */

     0x71,  /* 60   --       */
     0x5C,  /* 61   31  a    */
     0x6C,  /* 62   32  b    */
     0x4C,  /* 63   33  c    */
     0x74,  /* 64   34  d    */
     0x54,  /* 65   35  e    */
     0x64,  /* 66   36  f    */
     0x44,  /* 67   37  g    */
     0x78,  /* 68   38  h    */
     0x58,  /* 69   39  i    */
     0x5E,  /* 6A   21  j    */
     0x6E,  /* 6B   22  k    */
     0x4E,  /* 6C   23  l    */
     0x76,  /* 6D   24  m    */
     0x56,  /* 6E   25  n    */
     0x66,  /* 6F   26  o    */
     0x46,  /* 70   27  p    */
     0x7A,  /* 71   28  q    */
     0x5A,  /* 72   29  r    */
     0x6D,  /* 73   12  s    */
     0x4D,  /* 74   13  t    */
     0x75,  /* 75   14  u    */
     0x55,  /* 76   15  v    */
     0x65,  /* 77   16  w    */
     0x45,  /* 78   17  x    */
     0x79,  /* 79   18  y    */
     0x59,  /* 7A   19  z    */
     0x71,  /* 7B   --       */
     0x71,  /* 7C   --       */
     0x71,  /* 7D   --       */
     0x71,  /* 7E   --       */
     0x71,  /* 7F   --       */

};
