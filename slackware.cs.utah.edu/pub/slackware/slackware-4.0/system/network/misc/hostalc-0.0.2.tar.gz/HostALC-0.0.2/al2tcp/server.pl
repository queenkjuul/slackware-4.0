#!/usr/bin/perl
# Appendix B - Sample Perl Code (Server)

($port) = @ARGV;
$port = 6600 unless $port;

sub flip {
$hex = substr($_,3,6);
$hen = substr($_,9,6);
$ostr = sprintf "%s",$_;
substr($ostr,3,6) = $hen;
substr($ostr,9,6) = $hex;
substr($ostr,24,0) = "5D 33 ";
substr($ostr,-4,0) = "33 21 ";
}

$AF_INET =2;
$SOCK_STREAM =1;
$sockaddr = 'S n a4 x8';
($name, $aliases, $proto) = getprotobyname('tcp');
if ($port !~ /^\d+$/) {
    ($name, $aliases, $port) = getservbyport($port, 'tcp');
}

print "Port = $port\n";

$this = pack($sockaddr, $AD_INET, $port, "\0\0\0\0");
select(NS); $| = 1; select(stdout);

socket(S, $AF_INET, $SOCK_STREAM, $proto) || die "socket: $!";
bind(S,$this) || die "bind: $!";
listen(S,5) || die "connect: $!";

select(S); $| =1; select(stdout);

for($con = 1; ; $con++) {
    printf("Listening for connection %d....\n",$con);
    ($addr = accept(NS,S)) || die $!;

    if (($child = fork()) == 0) {
        print "accept ok\n";

        ($af,$port,$inetaddr) = unpack($sockaddr,$addr);
        @inetaddr = unpack('C4',$inetaddr);
        print "$con: $af $port @inetaddr\n";

        while (<NS>) {
            print "$con: $_";
			select(NS);
			flip();
			print "$ostr";
			select(stdout);
        }
        close(NS);
        exit;
    }
    close(NS);
}

