
#include "config.h"

/* Device controlling */
extern int dev_init(void);
extern void fork_sender(void (*sender)(void));
extern void send_block(char *block, int len);
extern int recv_block(char *block);

extern char *in_dev, *out_dev, *chat_prog;
extern int ack_timer;

/* Zipper controlling */
extern void zip_unpackinit(void);
extern void zip_unpackcleanup(void);
extern void zip_packinit(void);
extern void zip_packcleanup(void);
extern int zip_pack(char *in, int inlen, char *out);
extern int zip_unpack(char *in, int inlen, char *out);

/* Changeserver interface */
void sender_chsv(int (*r)(void *p, int l));
void sender_alrm(int s);
void chsv(void *p, int l);
