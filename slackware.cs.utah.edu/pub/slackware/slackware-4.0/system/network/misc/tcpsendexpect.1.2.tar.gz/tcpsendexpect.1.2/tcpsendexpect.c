/*
	tcpsendexpect.c - make a TCP/IP connection and use command line parameters
	                  for a send/expect style chat

	author: Giuseppe Zanetti (beppe@profuso.com, beppe@dei.unipd.it, beppe@iperv.it)
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>

#include <errno.h>

#include "bsocket.h"

extern int errno;

int verbose=0;
int dooutput=0;
int doinput=0;
int bold=0;
int bit7=0;

void usage(char *argv0)
{
	fprintf(stderr,"Usage: %s [-options] send1 expect1 send2 expect2 ...\n",argv0);
	fprintf(stderr,"\n");
	fprintf(stderr,"   -hhost     the address of the remote host to use\n");
	fprintf(stderr,"   -pport     the remote TCP port to use (default=9000, see docs)\n");
	fprintf(stderr,"   -ffilename use the file <filename> for reading chat (see README)\n");
	fprintf(stderr,"   -v         be verbose (use -v -v to be more verbose)\n");
	fprintf(stderr,"   -o         write remote output to stdout (redirection via > is a good idea)\n");
	fprintf(stderr,"   -i         write my input to stdout (redirection via > is a good idea)\n");
	fprintf(stderr,"   -I         as -1, but write in bold on a vt100 compatible terminal\n");
	fprintf(stderr,"   -7         use 7 bits\n");
	fprintf(stderr,"   -?         this help\n");
	fprintf(stderr,"\n");
	fprintf(stderr,"   in send you can use these escape codes:\n");
	fprintf(stderr,"   \\n        Line Feed (ASCII 10)\n");
	fprintf(stderr,"   \\r        Carriage return (ASCII 13)\n");
	fprintf(stderr,"   \\[        send ESC (ASCII 27)\n");
	fprintf(stderr,"   \\o        enable output (see -o)\n");
	fprintf(stderr,"   \\f        disable output\n");
	fprintf(stderr,"\n");
	fprintf(stderr,"by Giuseppe Zanetti (beppe@profuso.com, beppe@dei.unipd.it, beppe@iperv.it)\n");
	exit(1);
}

tcp_send(int soc, char *s)
{
	int j;
	char cmd[10240];
	int cmdp=0;

	if(verbose) fprintf(stderr,"SEND %s\n",s);

	if(strcmp(s,"") != 0)
	{
		cmdp=0;

		for(j=0;j<strlen(s); j++)
		{
			if(s[j] == '\\')
			{
				j++;
				switch(s[j])
				{
					case '[':		cmd[cmdp++]=27;
									break;

					case 'n':		cmd[cmdp++]=10;
									break;

					case 'r':		cmd[cmdp++]=13;
									break;

					case 'o':		dooutput=1;
									break;

					case 'f':		dooutput=0;
									break;

					default:		cmd[cmdp++]='\\';
									break;
				}
			}
			else
			{
				cmd[cmdp++]=s[j];
			}
		}
		cmd[cmdp++]='\0';

		write(soc, cmd, strlen(cmd));

		if(doinput)
		{
			if(bold) printf("\033[4m");
			printf("%s",cmd);
			if(bold) printf("\033[0m");
		}
	}
}

tcp_expect(int soc, char *expected)
{
	char received[10240];
	char s[10240];
	int r=0;
	int c;

	strcpy(received,"");

	if(verbose) fprintf(stderr,"EXPECT %s ... ",expected);
	if(verbose>1) fprintf(stderr,"\n");

	while(1)
	{
		r=read(soc,s,1);
		s[1]='\0';

		if(bit7) s[0]=s[0] & 127;

		c=s[0]; if(r<=0) break;

		if(dooutput) printf("%c",c);

		if(verbose>1) fprintf(stderr,"%c",c);
		if(verbose>2) fprintf(stderr,"(%d) ",c);

		strcat(received,s);
		if(strstr(received,expected) != NULL) break;
	}

	if(verbose>1) fprintf(stderr,"\n");
	if(verbose) fprintf(stderr,"OK\n");
}



int main(int argc, char *argv[])
{
	int i,j;
	char host[512];
	int port=9000;
	int soc;
	FILE *f;
	char filename[1024];
	char s[1024];
	int send;

	strcpy(filename,"");

	for(i=1;i<argc;i++)
	{
		if (argv[i][0] == '-')
		{
			switch(argv[i][1])
			{
				case 'v':	verbose++;
							break;

				case 'o':	dooutput=1;
							break;

				case 'i':	doinput=1;
							break;

				case 'I':	doinput=1;
							bold=1;
							break;

				case 'p':	port=atoi(argv[i]+2);
							break;

				case 'f':	strcpy(filename,argv[i]+2);
							break;

				case 'h':	strcpy(host,argv[i]+2);
							break;

				case '?':	usage(argv[0]);
							break;

				case '7':	bit7=1;
							break;

				default:	break;
			}
		}
	}

	if(verbose) fprintf(stderr,"Connecting with %s, port %d ... ",host, port);

	/* open the socket */

	soc=net_connect(host,port);

	if(verbose) fprintf(stderr,"OK\n");

	/* make the chat */

	send=1;

	if(strcmp(filename,"")==0)
	{
		for(i=1;i<argc;i++)
		{
			if (argv[i][0] != '-')
			{
				if(send)
				{
					tcp_send(soc,argv[i]);
					send=0;
				}
				else
				{
					tcp_expect(soc,argv[i]);
					send=1;
				}
			}
		}
	}
	else
	{
		f=fopen(filename,"r");
		if (f==NULL)
		{
			fprintf(stderr,"Cannot open chat file %s\n",filename);
			exit(1);
		}

		while(1)
		{
	        if(feof(f)) break;
	        fgets(s,10240,f); if(feof(f)) break;
	        if(strchr(s,'\n')!=NULL) *(strchr(s,'\n'))='\0';

			if(send)
			{
				tcp_send(soc,s);
				send=0;
			}
			else
			{
				tcp_expect(soc,s);
				send=1;
			}
		}

		fclose(f);
	}

	net_close(soc);

	return(0);
}


