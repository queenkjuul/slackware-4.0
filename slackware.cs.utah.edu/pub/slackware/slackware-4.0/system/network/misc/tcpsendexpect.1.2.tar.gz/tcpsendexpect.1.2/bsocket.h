/*
	bsocket - socket library

	author: Giuseppe Zanetti (beppe@dei.unipd.it, beppe@iperv.it)

	BUGS: my (very) bad english
*/

#ifdef BEPPESOCKET_H
int net_init();
int connect_to(char *buf, int port);
int net_sendline(int sockfd, char *buf);
int net_connect(int sockfd, char *host, int port);
void cause_int();
int net_getchar(int sockfd, char *c);
int net_getline(int sockfd, char *buf,int len,long timeout);
int net_putchar(int sockfd, int c);
int net_gets(int sockfd, char *buf, int len);
int net_close(int sockfd);
#endif

