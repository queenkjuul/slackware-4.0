/*
	bsocket - socket library

	author: Giuseppe Zanetti (beppe@dei.unipd.it, beppe@iperv.it)

	BUGS: my (very) bad english
*/


#include <sys/types.h>
#include <stdio.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pwd.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>

#include <netinet/in.h>
#include <netdb.h>

#include "bsocket.h"

/*
	open a TCP/IP socket with host/port
	returns the file descriptor for the socket
*/

int net_connect(char *host, int port)
{
    extern int lflag;
    register FILE *fp;
    register int c, lastc;
    struct in_addr defaddr;
    struct hostent *hp, def;
    struct sockaddr_in sin;
    int newport;
    char *alist[1], *rindex();
    u_long inet_addr();
    struct servent *sp;

    char cmd[10240];
	int soc;

	int r;

    if (!(hp = gethostbyname(host)))
	{
    	defaddr.s_addr = inet_addr(host);

    	if (defaddr.s_addr == -1)
		{
    	    fprintf(stderr, "unknown host: %s\n", host);
    	    return;
    	}

    	def.h_name = host;
    	def.h_addr_list = alist;
    	def.h_addr = (char *)&defaddr;
    	def.h_length = sizeof(struct in_addr);
    	def.h_addrtype = AF_INET;
    	def.h_aliases = 0;
    	hp = &def;
    }

    sin.sin_family = hp->h_addrtype;
    bcopy(hp->h_addr, (char *)&sin.sin_addr, hp->h_length);

	if (!(sp = getservbyname("www", "tcp")))
	{
		sp = getservent();
    }

    sin.sin_family = hp->h_addrtype;
    bcopy(hp->h_addr, (char *)&sin.sin_addr, hp->h_length);

    /* if (port==80) goto skip; */

    newport=calcport(port);

	/* printf("NEWPORT=%d\n",newport); */
	/* printf("A"); fflush(stdout); */

    sp->s_port=newport;

	/* printf("B"); fflush(stdout); */

skip:

    sin.sin_port = sp->s_port;

	/* printf("PORT=%d\n",sin.sin_port); */

    if ((soc = socket(hp->h_addrtype, SOCK_STREAM, 0)) < 0)
	{
		fprintf(stderr, "socket() error\n");
		return;
    }

    if (connect(soc, (struct sockaddr *)&sin, sizeof(sin)) < 0)
	{
		fprintf(stderr, "connect() error\n");
    	close(soc);
    	return;
    }

	return(soc);
}

/* close the socket */

int net_close(int soc)
{
    close(soc);
}

/* used by net_connect() */

int calcport(x)
int x;
{
	int r,c;

	r=rint(x / 256);
	c = ((x-(256*r)) * 256) + r;

	return(c);
}

/* send a line (terminated with \n) to the remote host */

int net_sendline(int sockfd, char *buf)
{
	int i;
   
	i = write(sockfd, buf, strlen(buf));
	write(sockfd, "\n", 1);

	if (i<0) return(i);

	return (i + 1);
}

/* a nop signal handler */

void cause_int()
{
	;
}

/* get a char from the remote host */

int net_getchar(int sockfd, char *c)
{
	int err;

	err=read(sockfd,c,1);

	if (err != 1) return(-1);

	return(0);
}

/* get a line from the remote host */

int net_getline(int sockfd, char *buf,int len,long timeout)
{
	int got=0;
	int err;
	signal(SIGALRM,cause_int);
	alarm(timeout);

	while(1)
	{
		if(got==len) return(-2);

		err=read(sockfd,&buf[got],1);

		if(err!=1)
		{
			perror("getline");
			if(errno!=EINTR) return(-1);
			return(-3);
		}

		if(buf[got]=='\n')
		{
			if(got>0 && buf[got-1]=='\r')
				buf[got-1]=0;
			else
				buf[got]=0;

			return(0);
		}
		got++;
	}
}

/* put a char to the remote host */

int net_putchar(int sockfd, int c)
{
	int i;
	char tmp[2];
	
	tmp[0]=(char) c;
	tmp[1]='\0';

	i = write(sockfd, tmp, 1);
   
	return (i >= 0) ? (i + 1) : i;
}

/* write a string to the remote host */

int net_write(int sockfd, char *buffer, int size)
{
	return(write(sockfd, buffer, size));
}

/* get a string from the remote host */

int net_gets (int fd, char *msg, int maxsize )
{
	char c;
	char msgp;
	int r;
	int stop;

	strcpy(msg,"");
	msgp=0;
	stop=0;

	while(1)
	{
		r=read(fd, &c, 1);

		if(r==0) break;
		if(r<0) continue;

		/* printf("%c",c); fflush(stdout); */

		switch(c)
		{
			case 13:	break;

			case '\n':	stop=1;
						break;

			default:	msg[msgp++]=c;
						msg[msgp]=0;

						if(msgp>=maxsize-1) stop=1;

						break;
		}

		if(stop==1) break;
	}

	return r;
}


