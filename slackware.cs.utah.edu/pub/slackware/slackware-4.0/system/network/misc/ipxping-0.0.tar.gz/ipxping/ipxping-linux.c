/***************************************************************************/
/*                                                                         */
/*   Program: IPXPING                                                      */
/*   Authors: Stephen Clover and Justin Hoon                               */
/*   Purpose: Ping a node on a Novell network from a Sun machine           */
/*   Last modified: 02/05/94                                               */
/*   Compile: gcc -o ipxping ipxping.c                                     */
/*                                                                         */
/***************************************************************************/

/***************************************************************************/
/*                                                                         */
/*   Program: ipxping-linux                                                */
/*   Patched to compile on Linux by Wong Tsang Han                         */
/*   Purpose: Ping a node on a Novell network from a Linux machine         */
/*   Last modified: 26/03/97                                               */
/*   Compile: gcc -o ipxping-linux ipxping-linux.c                         */
/*                                                                         */
/***************************************************************************/
#include <stdio.h>		/* for file i/o */
#include <unistd.h>
#include <errno.h>		/* in case of error */
#include <signal.h>
#include <sys/time.h>
#include <sys/timeb.h>
#include <sys/socket.h>		/* for sockaddr */
#include <linux/ipx.h>

/* the Sigfunc signal is lifted straigh from                */
/* Richard Stevens' Advance Programming in Unix Environment */

typedef void Sigfunc (int);	/* for signal handlers */

Sigfunc *
signal (int signo, Sigfunc * func)
{
  struct sigaction act, oact;
  act.sa_handler = func;
  sigemptyset (&act.sa_mask);
  act.sa_flags = 0;
  if (signo == SIGALRM)
  {
#ifdef SA_INTERRUPT
    act.sa_flags |= SA_INTERRUPT;
#endif
  }
  else
  {
#ifdef SA_RESTART
    act.sa_flags |= SA_RESTART;
#endif
  }
  if (sigaction (signo, &act, &oact) < 0)
    return (SIG_ERR);
  return (oact.sa_handler);
}

void
sig_alarm (int signo)
{
  fprintf (stderr, "Time out.\n");
  exit (0);
}

int
main (int argc, char **argv)
{
  /* error message parts 1 & 2 to display when arguments are wrong */
  const char errmsg1[] = "ipxping <dest network> <dest machine>";

  int responsetime, i, j, s, len, ndata;
  unsigned int a, b, c, d, e, f;
  unsigned int n;
  short dt;
  char data[70], buf[6];
  struct sockaddr_ipx sipx;
  struct timeb starttime, stoptime;

  if (argc != 3)
  {
    fprintf (stderr, "%s\n\n", errmsg1);
    exit (1);
  }

  /* get arguments from command line and store them */
  /* clear them first to avoid errors */

  if (sscanf (argv[2], "%02X:%02X:%02X:%02X:%02X:%02X",
	      &a, &b, &c, &d, &e, &f) != 6)
  {
    fprintf (stderr, "%s: node syntax error.\n", argv[0]);
    exit (1);
  }

  if (sscanf (argv[1], "%X", &n) != 1)
  {
    fprintf (stderr, "%s: network number error.\n", argv[0]);
    exit (1);
  }


  memset (&sipx, 0, sizeof (sipx));
  sipx.sipx_family = AF_IPX;
  sipx.sipx_port = htons (0x456);

  if ((s = socket (AF_IPX, SOCK_DGRAM, 0)) == -1)
  {
    perror ("error: socket");
    exit (1);
  }

  if (bind (s, (struct sockaddr *) &sipx, sizeof (sipx)) == -1)
  {
    perror ("bind");
    exit (1);
  }

  buf[0] = a;
  buf[1] = b;
  buf[2] = c;
  buf[3] = d;
  buf[4] = e;
  buf[5] = f;

  memcpy (sipx.sipx_node, buf, 6);
  sipx.sipx_network = htonl (n);

  memset (data, 0x0, 70);

  signal (SIGALRM, sig_alarm);
  alarm (3);

  ftime (&starttime);

  if (sendto (s, data, 70, 0, (struct sockaddr *) &sipx, sizeof (sipx)) < 0)
  {
    perror ("error: ipx_send");
    exit (1);
  }
  else
  {
    printf ("ipxping packet send.\n");
  }

  if ((ndata = recvfrom (s, data, 70, 0, (struct sockaddr *) &sipx, &len)) < 0)
  {
    perror ("error: ipx_recv");
  }
  else
  {
    ftime (&stoptime);

    printf ("%08X:%02X%02X%02X%02X%02X%02X is alive.\n", n, a, b, c, d, e, f);
    dt = (short) stoptime.millitm - (short) starttime.millitm;
    if (dt < 0)
    {
      dt = 1000 + dt;
    }
    printf ("RTT: %d ms\n", dt);
    printf ("%d bytes returned\n", ndata);
    for (i = 0; i < ndata; i++)
    {
      printf ("%02X ", data[i]);
    }
    printf ("\n");
  }
  return (0);
}
