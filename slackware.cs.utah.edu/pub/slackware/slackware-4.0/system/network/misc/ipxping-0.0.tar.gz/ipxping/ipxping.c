/***************************************************************************/
/*                                                                         */
/*   Program: IPXPING                                                      */
/*   Authors: Stephen Clover and Justin Hoon                               */
/*   Purpose: Ping a node on a Novell network from a Sun machine           */
/*   Last modified: 02/05/94                                               */
/*   Compile: gcc -o ipxping ipxping.c                                     */
/*                                                                         */
/***************************************************************************/

#include <memory.h>            /* for memory operations */
#include <errno.h>             /* in case of error */
#include <fcntl.h>
#include <stropts.h>           /* for strioctl */
#include <stdio.h>             /* for file i/o */
#include <malloc.h>            /* for memory allocation */
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stdtypes.h>
#include <sys/time.h>
#include <sys/timeb.h>
#include <sys/socket.h>        /* for sockaddr */
#include <sys/stat.h>          /* for stat */
#include <net/if.h>            /* for ifreq */
#include <net/nit_if.h>        /* for nit interface routines */
#include <net/nit_buf.h>       /* for nit interface buffering routines */
#include <netinet/in.h>        /* for if_ether.h */
#include <netinet/if_ether.h>  /* for ether_addr */
#include <sys/uio.h>

/* actually packet length value. could possibly change to 0x8137 for use under
   the Ethernet-II standard -- see man pages for more details */
#define PROTOCOL 0x0064


/* ipxpingpckt: my very own pingpacket structure, including ethernet framing
   header. fields are arranged in the order they go out onto the ethernet  */
struct ipxpingpkt {
   struct ether_header header;       /* ethernet header frame */
   short  checksum, length;          /* 2byte checksum, 2byte length */
   u_char transctrl, pckttype;       /* 1byte transport control, packet type */
   int	  dest_netwk;                /* 4byte destination network */
   u_char dest_host[6];              /* 6byte destination host */
   short  dest_socket;               /* 2byte destination socket */
   int    src_netwk;                 /* 4byte host network */
   u_char src_host[6];               /* 6byte host host */
   short  src_socket;                /* 2byte host socket */
   char   datafield[70];             /* 70byte data field */
};


char              my_netwk[12],      /* char arrays to hold cmdline fields */
                  frame_dest[18],
                  dest_netwk[12], 
                  enet_dest[18];
char              *buf[1000];	     /* read buffer                     */
int               nitd;              /* NIT stream file handle          */
struct ipxpingpkt pingpacket;        /* the IPX ping packet             */
struct strbuf     control,           /* control/data stream buffers for */
                  data;              /* writing packet onto ethernet    */
struct timeval    *resptime;         /* response time of ping response  */

/* my own routine designed to emulate the ether_aton call. returns a 32bit
   value equivalent to the translated value of the ascii network address
   passed to it (xx.xx.xx.xx). */

unsigned int netwk_aton( netwk_ch )
char netwk_ch[12];
{
   unsigned int retval = 0;
   int h, m1, m2, l;

   /* get the 4 hex pairs into 4 integers */
   sscanf( netwk_ch, "%x:%x:%x:%x", &h, &m1, &m2, &l );

   /* calculate the 32bit value using sinple bit shifts */
   retval = ( h << 24 ) + ( m1 << 16 ) + ( m2 << 8 ) + l;
   return( retval );
}


/* store current system time in timeb structure pointed to by timevar */
void get_time( timevar )
struct timeb *timevar;
{
   ftime( timevar );
}


/* open and configure the NIT device */
void open_nit()
{
   u_long  if_flags  = NI_TIMESTAMP,  /* prepend timestamp field to packets */
           snaplen   = 60,            /* snapshot length is 60 */
           chunksize = 100;           /* read chunksize is 100 */

   struct timeval timeout;            
   struct strioctl si;                /* perform ioctl commands on a stream */
   struct ifreq    enet;              /* our NIT interface ifreq */


   /* gain access to /dev/nit */
   nitd = open( "/dev/nit", O_RDWR );
   if( nitd < 0 ) 
   {
      perror( "open /dev/nit failed " );
      exit( 0 );
   }

   /* Configure for le0 */
   strcpy( enet.ifr_name, "le0" );
   si.ic_cmd = NIOCBIND;             /* Set command to bind to interface */
   si.ic_timout = 0;
   si.ic_len = sizeof( enet );
   si.ic_dp  = (char *)&enet;
   if( ioctl( nitd, I_STR, (char *)&si ) < 0 ) 
   {
      perror( "ioctl I_STR (NIOCBIND) failed" );
      exit( 0 );
   }

   /* Get the ethernet interface address */
   strcpy( enet.ifr_name, "le0" );
   si.ic_cmd = SIOCGIFADDR;             /* Request interface address */
   si.ic_timout = 0;
   si.ic_len = sizeof( enet );
   si.ic_dp  = (char *)&enet;
   if( ioctl( nitd, I_STR, (char *)&si ) < 0 ) 
   {
      perror( "ioctl I_STR (SIOCGIFADDR) failed");
      exit( 0 );
   }

   /* store the source ethernet address (my owm address) */
   memcpy( pingpacket.header.ether_shost.ether_addr_octet, 
           &enet.ifr_addr.sa_data[0], sizeof( struct ether_addr ) );

   /* Arrange to get discrete messages from the stream. */
   ioctl( nitd, I_SRDOPT, (char *)RMSGD );

   si.ic_timout = INFTIM;

   /* Push and configure the buffering module. */
   ioctl( nitd, I_PUSH, "nbuf" );

   timeout.tv_sec = 1;
   timeout.tv_usec = 0;
   si.ic_cmd = NIOCSTIME;
   si.ic_len = sizeof( timeout );
   si.ic_dp = (char *)&timeout;
   ioctl( nitd, I_STR, (char *)&si );

   /* Configure the nit device, binding it to the proper underlying 
      interface, set the snapshot length, and set nit_if-level flags */

   /* set chunksize */
   si.ic_cmd = NIOCSCHUNK;
   si.ic_len = sizeof( chunksize );
   si.ic_dp = (char *)&chunksize;
   ioctl( nitd, I_STR, (char *)&si );

   /* set snaplength */
   si.ic_cmd = NIOCSSNAP;
   si.ic_len = sizeof snaplen;
   si.ic_dp = (char *)&snaplen;
   ioctl( nitd, I_STR, (char *)&si );

   /* set nit_if-level flags */
   si.ic_cmd = NIOCSFLAGS;
   si.ic_len = sizeof( if_flags );
   si.ic_dp = (char *)&if_flags;
   ioctl( nitd, I_STR, (char *)&si );

   /* Flush the read queue, to get rid of anything that accumulated
      before the device reached its final configuration. */
   ioctl( nitd, I_FLUSH, (char *)FLUSHR );
}


/* construct the ethernet packet */
void setup_pckt()
{
   struct sockaddr sock_header;       /* sockaddr structure used to write
                                         ethernet frame onto ethernet */

   /* store the destination ethernet address, calling ether_aton */
   memcpy( pingpacket.header.ether_dhost.ether_addr_octet,
           (char *)ether_aton( frame_dest ), sizeof( struct ether_addr ) );

   /* the ethernet header thinks it wants a packet type field (Ethernet-II),
      but we are using IEEE802.3 standard so it's a length field */
   pingpacket.header.ether_type = htons(PROTOCOL);

   /* construct the sockaddr header for control part of putmsg */
   sock_header.sa_family = AF_UNSPEC;

   /* copy ethernet header structure into control sockaddr structure */
   memcpy( sock_header.sa_data,
           &pingpacket.header,
           sizeof( pingpacket.header ) );
   control.buf = (char *) &sock_header;
   control.len = sizeof( sock_header );

   /* construct the ethernet data packet for the data part of putmsg */
   /* point data to first part of IPX packet, set size to equal size
      of ipxpingpacket minus the size of ethernet header structure */
   data.buf = (char *) &pingpacket.checksum;
   data.len = sizeof( pingpacket ) - 16;

   /* construct remainder of IPX ping packet */
   pingpacket.checksum    = 0xFFFF;
   pingpacket.length      = 0x64;
   pingpacket.transctrl   = 0x0;
   pingpacket.pckttype    = 0x4;
   pingpacket.dest_socket = 0x0456;
   pingpacket.src_socket  = 0x0456;

   /* construct network/ethernet address of destination machine */
   memcpy( pingpacket.dest_host, (char *)ether_aton( enet_dest ), 
           sizeof( struct ether_addr ) );

   pingpacket.dest_netwk = netwk_aton( dest_netwk );

   /* construct network/ethernet address of source machine */
   memcpy( pingpacket.src_host,
           pingpacket.header.ether_shost.ether_addr_octet, 
           sizeof( struct ether_addr ) );

   pingpacket.src_netwk = netwk_aton( my_netwk );

   /* set datafield to 70 zero's */
   memset( pingpacket.datafield, 0x0, 70 );
}


/* send the IPX ping packet */
void send_pckt()
{
   if( putmsg( nitd, &control, &data, 0 ) < 0 ) 
   {
      perror("putmsg failed ");
      exit(0);
   }
}


/* read packets from ethernet interface. either timeout, or return a pointer
   to the reply packet in buf */
char *read_pckt()
{
   int              cc,  i,
                    timedout = 0;         /* boolean flag */
   u_char *addr,    *bufcmp;
   struct nit_iflen *nlp;
   struct timeb     current,
                    endtime;

   /* calculate the time to timeout, and store as endtime */
   get_time( &current );
   endtime.millitm = current.millitm + 500;
   endtime.time = current.time;
   if( endtime.millitm > 999 )
   {
      endtime.millitm -= 1000;
      endtime.time++;
   }

   /* read until timeout = 1 */
   while( !timedout )
   {
      /* read -- if successful, process packet */
      if( ( cc = read( nitd, buf, 100 ) ) >= 0 )    /* chunksize is 100 */
      {
         register u_char *bp = (u_char *)buf,
                         *bufstop = (u_char *)buf + cc;

         /* loop through each message in the chunk */
         while( bp < bufstop ) 
         {
            register u_char     *cp = bp;
            struct nit_bufhdr   *hdrp;
            u_long              pktlen;

            /* compare the destination address of the packet, to our address.
               if they are the same, we have our response. this is because 
               you'll never see an IPX packet with the address of our own 
               host machine on the network normally */

            /* destination address is the 6 bytes starting at position 40 */
            bufcmp = &bp[40];
            addr = (u_char *)&pingpacket.header.ether_shost.ether_addr_octet;

            /* compare the two. if successful, point resptime structure to
               the timestamp field at position 8 in the packet, exit, and 
               return pointer to start of packet */
            if( memcmp( bufcmp, addr, 6 ) == 0 )
            {
               resptime = (struct timeval *)(bp + 8);
               return( bp );
	    }

            /* calculate end of packet and move bp to point to next packet */
            hdrp = (struct nit_bufhdr *)cp;
            cp += sizeof *hdrp;
            nlp = (struct nit_iflen *)cp;
            cp += sizeof *nlp;
            pktlen = nlp->nh_pktlen;
            bp += hdrp->nhb_totlen;
         }
      }

      /* get the time. if greater than endtime then timeout */
      get_time( &current );
      if( current.time > endtime.time )
         timedout = 1;
      else
         if((current.time==endtime.time)&&(current.millitm>=endtime.millitm))
            timedout = 1;
   }
   return( 0 );
}


/* close the device */
void close_nit()
{
   close(nitd);
}


int main( argc, argv )
int argc;
char *argv[];
{
   /* error message parts 1 & 2 to display when arguments are wrong */
   const char   errmsg1[] = "ipxping <host network> <router/dest machine> ";
   const char   errmsg2[] = "<dest network> <dest machine>";

   int          responsetime, i, j;
   u_char       *pt, *pcktbuf;
   struct timeb starttime;                /* store time ping packet sent */


   /* if we got the right number of arguments, do it! */
   if( argc > 4 )
   {
      open_nit();

      /* get arguments from command line and store them */
      /* clear them first to avoid errors */
      memset( my_netwk, 0x0, 12 );
      memset( frame_dest, 0x0, 18 );
      memset( dest_netwk, 0x0, 12 );
      memset( enet_dest, 0x0, 18 );
      strncpy( my_netwk, argv[1], 11 );
      strncpy( frame_dest, argv[2], 17 );
      strncpy( dest_netwk, argv[3], 11 );
      strncpy( enet_dest, argv[4], 17 );

      setup_pckt();              /* create the IPX ping packet */
      get_time( &starttime );    /* store time the packet is sent */
      send_pckt();               /* send the packet */
      
      pcktbuf = read_pckt();     /* get response, or timeout */
      if( pcktbuf )              /* if pointer value returned */
      {
         /* calculate responsetime and display */
         resptime->tv_usec /= 1000;
         while( ( resptime->tv_usec - starttime.millitm ) < 0 )
	 {
            resptime->tv_usec += 1000;
            resptime->tv_sec  -=1;
         }
         responsetime = ( resptime->tv_sec  - starttime.time ) + 
                        ( resptime->tv_usec - starttime.millitm );
         printf( "%dms ", responsetime );

         /* display the configuration information is contained in the
            response packet. before the data is a byte containing the number
            of bytes data to read -- check and store this first, and if > 0
            display the information */

         pt = &pcktbuf[64];           /* point to length byte */
         j = (int)*pt;                /* get length */
         for( i = 0; i < j ; i++ )    /* display information */
 	 {
            pt++;                     /* point to next byte */
            printf( "%02X ", *pt );   /* display it */
         }
         printf( "\n\n" );
      }
      /* we've timed out -- display message */
      else
         printf( "no response\n" );

      close_nit();     /* close the device */
   }

   /* we got incorrect parameters -- display error message(s) */
   else 
      printf( "%s%s\n\n", errmsg1, errmsg2 );

   /* return successful completion either way */
   return(0);
}

