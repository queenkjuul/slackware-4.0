/*
 *  Copyright (C) 1998 Christian Zagrodnick
 *  $Id: inetdial-wrapper.cc,v 1.4 1999/01/30 10:22:34 zagy Exp $
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *  Wrapper for inetdial (since v3.0)
 *  Don't know how secure it is. Using system() in fact IS a security hole.
 *  Could somebody fix it? <g>
 */


#define DIAL_SCRIPT "/root/bin/online"
#define HANGUP_SCRIPT "/root/bin/offline"

#include <stdlib.h>
#include <unistd.h>
#include <String.h>
#include <iostream.h>
#include <errno.h>
#include <fstream.h>
#include <getopt.h>
#include <stdio.h>



#define DIAL 1
#define HANGUP 2
int ACTION=0;
String INTERFACE;
bool AUTOHANGUP=false;


/*
 * cmdline parser
 */
void cmdline(int args, char **argv);

int main(int argc, char **argv)
{
  cmdline(argc, argv);
  if ((ACTION==0) || (INTERFACE.matches(""))) {
	cerr << "No Interface and/or Action given!" << endl;
	return 100;
    }
    
    if (setuid(0) == -1) {
	cerr << "Can't setuid(0)." << endl;
	return 101;
    }
    
    if (ACTION==DIAL) {
	if (AUTOHANGUP) {
	    ofstream *f = new ofstream(INTERFACE);
	    *f << "\n";
	    delete(f);
	}
	String cmd = (String)(DIAL_SCRIPT) + " " + INTERFACE;

      	system(cmd);
	return 0;
    }
    if (ACTION==HANGUP) {
	system((String) (HANGUP_SCRIPT) + " " + INTERFACE);
	return 0;
    }
}

void cmdline(int argc, char **argv)
{
    int c;
    while (1) {
	c = getopt(argc, argv, "Aa:i:");
	if (c == -1) break;
	switch (c) {
	
	case 'i':
	    INTERFACE=optarg;
	    break;
	    
	case 'a':
	    ACTION=(int)(*optarg)-48; // works for the moment...
	    break;

	case 'A':
	    AUTOHANGUP=true;
	    break;

	default:
	    printf("?? getopt returned character code 0%o ??\n", c);
	}
    }
}
