#if defined(__osf__) && defined(__alpha)
# define HAVE_STDARG_H
#endif 

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <netdb.h>
#include <syscall.h>
#ifdef HAVE_STDARG_H
# include <stdarg.h>
#else
# include <varargs.h>
#endif

#ifndef TRUE
# define TRUE		(1 == 1)
#endif
#ifndef FALSE 
# define FALSE		(1 == 0)
#endif

#define CONST		const
#define VOID_FUNC	void
#define VOID_PTR	void*

typedef int		t_boolean;

char			*getenv();
extern char		*sys_errlist[];
extern int		errno;

t_boolean		alt_inited = FALSE;
struct sockaddr_in	alt_addr;
char			*alt_host = NULL;
char			*alt_port = NULL;

VOID_FUNC	error_proc(data,sys,where,procname,comment)
VOID_PTR	data;
t_boolean	sys;
char		*where;
char		*procname;
char		*comment;
{
  fprintf(stderr,"alt_connect: ERROR: %s: %s: %s",where,procname,comment);
  if (sys)
    fprintf(stderr,": %s\n",sys_errlist[errno]);
  else
    fprintf(stderr,"\n");
}

#ifdef HAVE_STDARG_H
VOID_FUNC	error(t_boolean sys,char *where,char *procname,
		      char *fmt,...)
#else
VOID_FUNC	error(sys,where,procname,fmt,va_alist)
t_boolean	sys;
char		*where;
char		*procname;
char		*fmt;
va_dcl
#endif
{
  va_list	ap;
  char		buf[BUFSIZ];
  
  if (fmt != NULL)
    {
#ifdef HAVE_STDARG_H
      va_start(ap,fmt);
#else
      va_start(ap);
#endif
      vsprintf(buf,fmt,ap);
      error_proc(NULL,sys,where,procname,buf);
    }
  else
    error_proc(NULL,sys,where,procname,"");
  va_end(ap);
}

int			inet_get_port(name,proto)
char			*name;
char			*proto;
{
  struct servent	*serventry;
  int			port;

  if (isdigit(name[0]))
    port = atoi(name);
  else
    {
      setservent(0);
      if (serventry = getservbyname(name,proto))
	{
	  port = serventry->s_port;
	}
      else
	{
	  error(FALSE,"inet_get_port","getservbyname",
		"can't find service `%s/%s'",name,proto);
	  port = -1;
	}
      endservent();
    }
  return (port);
}

char			*inet_get_port_name(port,proto,warn)
int			port;
char			*proto;
t_boolean		warn;
{
  struct servent	*serventry;
  char			*name;

  setservent(0);
  if (serventry = getservbyport(port,proto))
    {
      name = serventry->s_name;
    }
  else
    {
      if (warn)
	error(FALSE,"int_get_port","getservbyport",
	      "can't find service `%d/%s'",port,proto);
      name = NULL; 
    }
  endservent();
  return (name);
}

int			inet_get_proto(name)
char			*name;
{
  struct protoent	*protoentry;
  int			proto;

  if (isdigit(name[0]))
    proto = atoi(name);
  else
    {
      setprotoent(0);
      if (protoentry = getprotobyname(name))
	{
	  proto = protoentry->p_proto;
	}
      else
	{
	  error(FALSE,"inet_get_proto","getprotobyname",
		"can't find protocol `%s'",name);
	  proto = -1;
	}
      endprotoent();
    }
  return (proto);
}

char			*inet_get_proto_name(proto)
int			proto;
{
  struct protoent	*protoentry;
  char			*name;

  setprotoent(0);
  if (protoentry = getprotobynumber(proto))
    {
      name = protoentry->p_name;
    }
  else
    {
      error(FALSE,"inet_get_proto_name",
	    "getprotobynumber","can't find protocol %d",proto);
      name = NULL;
    }
  endprotoent();
  return (name);
}

char			*inet_get_addr_name(addr)
struct in_addr		*addr;
{
  return (inet_ntoa(*addr));
}

CONST char		*inet_get_host_name(addr)
struct in_addr		*addr;
{
  char			*host;
  struct hostent	*hostentry;
  int			any;
  
  any = INADDR_ANY; 
  if (!bcmp(addr,&any,sizeof (struct in_addr)))
    return ("(any)");
  if ((hostentry = gethostbyaddr((char *)addr,sizeof (struct in_addr),
				 AF_INET)) == NULL)
    {
      error(FALSE,"inet_get_host","gethostbyaddr","can't resolv `%s'",
	    inet_get_addr_name(addr));
      return (NULL);
    }
  return (hostentry->h_name);
}

CONST char		*inet_sin_to_str(sin)
struct sockaddr_in	*sin;
{
  static char		buf[BUFSIZ];
  CONST char		*host_name;
  char			*port_name;

  host_name = inet_get_host_name(&(sin->sin_addr));
  host_name = host_name?host_name:"(unresolved)";
  port_name = inet_get_port_name(ntohs(sin->sin_port),"tcp",FALSE);
  port_name = port_name?port_name:"(unknown)";
  sprintf(buf,"%s(%s):%s(%d)",
	  host_name,inet_get_addr_name(&(sin->sin_addr)),
	  port_name,ntohs(sin->sin_port));
  return (buf);
}

VOID_FUNC		inet_fill_addr_any(addr,port,proto)
struct sockaddr_in	*addr;
char			*port;
char			*proto;
{
   addr->sin_family = AF_INET;
   addr->sin_port = htons(inet_get_port(port,proto));
   addr->sin_addr.s_addr = INADDR_ANY;
}

struct in_addr		*inet_get_in_addr(host)
char			*host;
{
  struct hostent	*hostentry;
  static struct in_addr	in_addr;
  struct sockaddr_in	addr;
   
  addr.sin_addr.s_addr = inet_addr(host);
  if (addr.sin_addr.s_addr == -1)
    {
      if ((hostentry = gethostbyname(host)) == NULL)
	{
	  error(FALSE,"inet_get_in_addr","gethostbyname",
		"can't resolve host name=`%s'",host);
	 return (NULL);
      }
      if (hostentry->h_addrtype != AF_INET)
      {
	 error(FALSE,"inet_get_in_addr","","h_addrtype!=AF_INET: host=`%s'",
	       host);
	 return (NULL);
      }
      bcopy(hostentry->h_addr_list[0],&in_addr,hostentry->h_length);
   }
  else
    bcopy(&(addr.sin_addr),&in_addr,sizeof (struct in_addr));
  return (&in_addr);
}

int			inet_fill_addr(addr,host,port,proto)
struct sockaddr_in	*addr;
char			*host;
char			*port;
char			*proto;
{
   struct hostent	*hostentry;
   
   addr->sin_family = AF_INET;
   addr->sin_port = htons(inet_get_port(port,proto));
   addr->sin_addr.s_addr = inet_addr(host);
   if (addr->sin_addr.s_addr == -1)
   {
      if ((hostentry = gethostbyname(host)) == NULL)
      {
	 error(FALSE,"inet_fill_addr","gethostbyname",
	       "Can't resolve host name=`%s'",host);
	 return (-1);
      }
      if (hostentry->h_addrtype != AF_INET)
      {
	 error(FALSE,"inet_fill_addr","","h_addrtype!=AF_INET: host=`%s'",
	       host);
	 return (-1);
      }
      bcopy(hostentry->h_addr_list[0],
	    &(addr->sin_addr),hostentry->h_length);
   }
   return (0);
}

int		alt_init()
{
  alt_host = getenv("ALT_HOST");
  alt_port = getenv("ALT_PORT");
  if (alt_port == NULL)
    alt_port = "0";
  if (alt_host == NULL)
    inet_fill_addr_any(&alt_addr,alt_port,"tcp");
  else
    inet_fill_addr(&alt_addr,alt_host,alt_port,"tcp");
  alt_inited = TRUE;
}

int		connect(fd,addr,addr_len)
int		fd;
struct sockaddr	*addr;
int		addr_len;
{
  int		fd_addr;
  int		fd_addr_len;

  if (!alt_inited)
    alt_init();
  fd_addr_len = sizeof (fd_addr);
  if (getsockname(fd,&fd_addr,&fd_addr_len) < 0)
    {
      error(TRUE,"connect","getsockname","pb");
    }
  if (bind(fd,(struct sockaddr *)(&alt_addr),sizeof (alt_addr)) < 0)
    {
      error(TRUE,"connect","bind","pb");
    }
  return (syscall(SYS_connect,fd,addr,addr_len));
}
