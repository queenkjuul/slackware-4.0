
/*
 * (c) 1988 by George Kyriazis
 */

/*
 * main subroutine call for the ray-tracer
 *	Use:  % ray scenename resolution outfile
 */

#include	<stdio.h>
#include    <stdlib.h>
#include    <iostream.h>
#include    <builtin.h>
#include    "W.h"
#include	"ray.h"
#include    "timer.i"

void readfile(char *);
void raytrace(char *, int, int);
void fillPicture(int ax, int ay, int bx, int by);
void w_box(int ax, int ay, int bx, int by, int c, int fill);
void writePictureToFile(char *fname);

int	noo;          /* number of objects */
int	tries;        /* number of tries per pixel */
int	xres, yres;   /* resolution */
int	bgflag;       /* background cuing info */

/* eye viewing stuff */
struct	vector	hor, ver, eye_dir, eye, up;
double	fov;
struct	light	light;

double	time1, time2;	/* time limits */
double	Time;			/* current time */

struct	obj	obj[MAX_NOO];      /* the array of spheres */

int       blocksx, blocksy;
int       picture[MAX_SIZE][MAX_SIZE];

// --------------------------------------------------------
// --------------------------------------------------------
char *allScenes[] = { "./test-files/test.1",
					  "./test-files/test.2", 
					  "./test-files/test.3",
					  "./test-files/test.4",
					  "./test-files/test.5"};
char    *scenefile = NULL;
int     draw       = 0;
int     output     = 0;
int     res        = 300;

void print_usage(char *prog) {
  cout << "Usage: " << prog << " [-s scenename] [-r resolution] [-o outfile] [-d]\n" << ::endl;
  cout << "defaults:\tresolution = 300" << ::endl;
  cout << "\t\tall scene" << ::endl;
  cout << "\t\t-d (draw) is off" << ::endl << ::flush;
}

void getAndSetArgs(int argc, char *argv[]) {
  char c;
  while ((c = getopt(argc, argv, "s:r:od")) != -1) {
	switch (c) {
	case 's':
	  scenefile = optarg;
	  break;
	case 'r':
	  res = atoi(optarg);
	  res = (res < 1000) ? res : 1000;
	  break;
	case 'o':
	  output  = 1;
	  break;
	case 'd':
	  draw = 1;
	  break;
	default :
	  fprintf(stderr, "unrecognized option %c\n", c);
	  print_usage(argv[0]);
	  exit(1);
	}
  }
}

void main(int argc, char *argv[]) {
  char    outfile[100];

  getAndSetArgs(argc, argv);
  xres = yres = res;

  if (draw)
	W_init(" parallel ray trace ", xres, yres);

  int   allFiles = (scenefile == NULL);
  if (!allFiles) {
	cout << "Press <Enter> to start" << ::flush;
	(void)cin.get();
  }

  Timer   timer;
  int   sceneNo = 0;
  do {
	if (allFiles)
	  scenefile = allScenes[sceneNo % 5];
	readfile(scenefile);
	sprintf(outfile, "%s.out", scenefile);
	if (draw)
	  w_box(0, 0, xres, yres, 0, 1);
	cout << "tracing " << scenefile << " ..." << ::flush;
	timer.start();
	raytrace(outfile, output, draw);
	timer.stop();
	cout << timer << ::endl << ::flush;
	if (draw)
	  fillPicture(0, 0, xres, yres);
	if (output)
	  writePictureToFile(outfile);
	sceneNo++;
  } while (allFiles);

  if (draw) {
	cout << "Press <Enter> to quit" << ::flush;
	(void)cin.get();
  }
}

