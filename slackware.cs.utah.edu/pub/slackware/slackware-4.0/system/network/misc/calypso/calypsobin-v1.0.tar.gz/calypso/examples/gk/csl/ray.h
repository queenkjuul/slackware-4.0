
/*
 * (c) 1988 by George Kyriazis
 */

/*
 * include file for the ray-tracer
 */

#ifndef	NULL
#define	NULL 0
#endif

#ifndef	FALSE
#define	FALSE	0
#endif

#ifndef	TRUE
#define	TRUE	!FALSE
#endif

#define	MINT	1e-5

#define	ABS(a)	( ((a) > 0 ) ? (a) : -(a) )
#define	MIN(a, b)	( (a) < (b) ? (a) : (b) )

#define	MAXLEVEL	3	/* maximum recursion level */

#define	SPHERE		0
#define	SQUARE		1

struct	vector	{double x,y,z;};

/* the color structure */
struct	color	{
		double	r,g,b;
		};

#define MAX_NOO   100
/* the object structure */
struct	obj	{
		int	type;		/* type of object */
		union data {
			struct	sphere {	/* sphere definition */
				struct	vector	center;
				double	radius;
				} sphere;
			struct	quad {		/* quad definition */
				struct	vector	p1;
				struct	vector	p2;
				struct	vector	p3;
				} quad;
			} data;
		double	reflection;	/* precentage reflection */
		double	refraction;	/* percentage refraction */
		struct	color	refl_color;	/* reflective color */
		struct	color	refr_color;	/* refractive color */
		struct	color	ambient;	/* ambient color */
		struct	color	diffuse;		/* diffuse color */
		struct	color	specular;	/* specular color */
		double	width;		/* specular width factor */
		double	index;		/* index of refraction */
		double	refl_diffuse;	/* circle of diffusion in reflection */
		double	refr_diffuse;	/* circle of diffusion in refraction */
		struct	vector	time;	/* motion coefficients */
		};

/* light source */
struct	light {
	struct	vector	org;
	double	angle;
};

#define	NONE	0
#define	X	1
#define	Y	2
#define	Z	3

/* the ray structure */
struct	ray	{
		struct	vector	pos;	/* origin */
		struct	vector	dir;	/* direction */
		struct	obj	*obj;	/* where the ray comes from */
		double	theta;		/* the diffusion angle */
		};

/* the intersection structure */
struct	intersect	{
		struct	obj	*obj;	/* which object */
		double	t;		/* where in the ray */
		struct	vector	n;	/* the normal at that point */
		};

#define MAX_SIZE 1000

