
/*
 * (c) 1988 by George Kyriazis
 */

/*
 * the background color.
 * can be changed to have any kind of background texturing.  (hint hint)
 */

#include "ray.h"

extern  int	noo;          /* number of objects */
extern  int	tries;        /* number of tries per pixel */
extern  int	xres, yres;   /* resolution */
extern  int	bgflag;       /* background cuing info */
  /* eye viewing stuff */
extern  struct	vector	hor, ver, eye_dir, eye, up;
extern  double	fov;
extern  struct	light	light;
extern  double	time1, time2;	/* time limits */
extern  double	Time;			/* current time */
extern  struct	obj	obj[MAX_NOO];      /* the array of spheres */
extern  int       blocksx, blocksy;
extern  int       picture[MAX_SIZE][MAX_SIZE];

struct	color	bgcolor(ray r)
{
	struct	color	c;

/* if it is above the appropriate axis just give a grey value */
/* if below give a gradually whiter color                     */
	switch( bgflag ) {
		case NONE:
			c.r = c.g = c.b = 0.2;
			break;
		case X:
			if( r.dir.x > 0.0 )
				c.r = c.g = c.b = 0.2;
			else
				c.r = c.g = c.b = 0.2 - 0.8 * r.dir.x;
			break;
		case Y:
			if( r.dir.y > 0.0 )
				c.r = c.g = c.b = 0.2;
			else
				c.r = c.g = c.b = 0.2 - 0.8 * r.dir.y;
			break;
		case Z:
			if( r.dir.z > 0.0 )
				c.r = c.g = c.b = 0.2;
			else
				c.r = c.g = c.b = 0.2 - 0.8 * r.dir.z;
			break;
	}

	return c;
}
