
/*
 * (c) 1988 by George Kyriazis
 */

/*
 * definitions for the vector routines used in other files
 */

struct	vector	vadd(struct	vector a, struct vector	b);
struct	vector	vsub(struct	vector a, struct vector	b);
struct	vector	vneg(struct	vector a);
struct	vector	svproduct(double k, struct	vector a);
double	vdot(struct	vector a, struct vector	b);
struct	vector	vcross(struct	vector a, struct vector	b);
struct	vector	norm(struct	vector a);


