#define	__CALYPSO__	1
#ifndef NULL
#define NULL 0
#endif
typedef void (*FunctionPtr)(int, int);
typedef int  (*BoolFunctionPtr)(void);
extern int _true();
void calypso_main(int argc, char *argv[]);
void calypso_pt_initialize();
void calypso_pt_addJob(int numberOfThreads, FunctionPtr pre, FunctionPtr post=NULL, FunctionPtr func=NULL);
void calypso_pt_flush();
void calypso_manageParallelJobs(BoolFunctionPtr guard = _true);
static void f1_0_0(int numThreads, int tid) ;
// -------------------------------------------------------------
// matrix multiplication
//     Command line options:
//     -nN : NxN is the size of each matrix.
//     -sS : S = random number generator seed. 
//     -wN : N = number of workers.
//     -c  : Check the result.
//     -o  : Print the matricies.
//     -h  : Print out command line options.
// -------------------------------------------------------------

#include <stdlib.h>
#include <string.h>
#include <iostream.h>
#include <sys/time.h>
#include <math.h>
#ifdef  __GNUC__
#include <builtin.h>
#endif

#include "calypso.H"
#include "timer.i"


const int	SIZE         = 500;
long	    seed         = 0;
int	        checkResult  = 0;
int	        outputResult = 0;
int	        workers      = 1;

typedef	float	Matrix[SIZE][SIZE];

typedef struct {
void		*_calypso_swizzle_in[1423];
# 33 "mmult.csl"

  int	size;
  Matrix	A, B, C;
void		*_calypso_swizzle_out[1832];
# 36 "mmult.csl"
} Shared;
Shared *shared = new Shared;
caddr_t _beginShared = (caddr_t)shared->_calypso_swizzle_in;
caddr_t _endShared = (caddr_t)shared->_calypso_swizzle_out;
# 36 "mmult.csl"



int iszero(float a) {
  return abs(a) < 0.001;
}


// -------------------------------------------------------------------------
void printUsage(char *prog_name) {
  cout << "Usage:\t" << prog_name << " <options>" << endl;
  cout << "\t-nN : NxN is the size of each matrix." << endl;
  cout << "\t-sS : S = random number generator seed." << endl;
  cout << "\t-wN : N = number of workers." << endl;
  cout << "\t-c  : Check the result." << endl;
  cout << "\t-o  : Print the matricies." << endl;
  cout << "\t-h  : Print out command line options." << endl;
}

void getAndSetArgs(int argc, char *argv[]) {
  char		c;

  while ((c = getopt(argc, argv, "n:s:w:coh")) != -1) {
	switch(c) {
	case 'n':	shared->size = atoi(optarg);
	  if (shared->size > SIZE) {
		cout << "matricies must be smaller than ";
		cout << SIZE <<"X" << SIZE << "." << endl;
		exit(0);
	  }
	  break;
	case 's':	seed = atoi(optarg);
	  break;
	case 'w':	workers = atoi(optarg);
	  if (workers < 1) {
		cout << "There must be at least one worker." << endl;
		exit(0);
	  }
	  break;
	case 'c':	checkResult = 1;
	  break;
	case 'o':	outputResult = 1;
	  break;
	case 'h':
	default :	printUsage(argv[0]);
	  exit(0);
	}
  }
}

// -------------------------------------------------------------------------
void randomFill(Matrix m) {
  for (int i=0; i<shared->size; i++)
	for (int j=0; j<shared->size; j++)
	  m[i][j] = (drand48() - 0.5) * 1000.;
}

void print(Matrix m, int size) {
  cout.setf(ios::scientific, ios::floatfield);
  for (int i=0; i<size; i++) {
	for (int j=0; j<size; j++)
	  cout << m[i][j] << "\t";
	cout << endl;
  }
}

int matrixEq(Matrix A, Matrix B, int rows, int cols) {
  for (int i=0; i<rows; i++)
	for (int j=0; j<cols; j++)
	  if (!iszero(A[i][j] - B[i][j]))
		return 0;
  return 1;
}

void transpose(Matrix A, int size) {
  float		temp;
  for (int i=0; i<size; i++)
	for (int j=i+1; j<size; j++) {
	  temp = A[i][j];
	  A[i][j] = A[j][i];
	  A[j][i] = temp;
	}
}

void mm(Matrix A, Matrix B, Matrix C, int dim1, int dim2, int dim3) {
  for (int i=0; i<dim1; i++) {
	for (int j=0; j<dim3; j++) {
	  C[i][j] = 0.;
	  for (int k=0; k<dim2; k++)
		C[i][j] += (A[i][k] * B[k][j]); 
	}
  }
}

void mm_cm(Matrix A, Matrix B, Matrix C, int fromRow, int toRow, int dim2, int dim3) {
  for (int i=fromRow; i<toRow; i++) {
	for (int j=0; j<dim3; j++) {
	  C[i][j] = 0.;
	  for (int k=0; k<dim2; k++)
		C[i][j] += (A[i][k] * B[j][k]); 
	}
  }
}

// -------------------------------------------------------------------------
void calypso_main(int argc, char *argv[]) {
  shared->size = SIZE;
  getAndSetArgs(argc, argv);

  if (workers > 1)
	calypso_spawnWorkers(workers);

  Matrix		D;
  srand48(seed);
  randomFill(shared->A);
  randomFill(shared->B);

  if (checkResult)
	mm(shared->A, shared->B, D, shared->size, shared->size, shared->size);

  transpose(shared->B, shared->size);

  Timer     timer;
  cout << "Press return to start" << ::flush;
  (void)cin.get();

  cout << "multiplication..." << ::flush;
  timer.start();
  calypso_pt_initialize();

	# 165 "mmult.csl"
calypso_pt_addJob(500, &f1_0_0 );

  calypso_manageParallelJobs( ); calypso_pt_flush();
# 170 "mmult.csl"

  timer.stop();
  cout << "done in " << timer.time() << " sec." << ::endl;

  if (checkResult) {
	cout << "Checking the results..." << flush;
	if (matrixEq(shared->C, D, shared->size, shared->size))
	  cout << "succeeded." << endl << flush;
	else
	  cout << "failed." << endl << flush;
  }

  cout << "Press return to continue" << ::flush;
  (void)cin.get();
  if (outputResult) {
	cout << "Matrix A:" << endl;
	print(shared->A, shared->size);
	cout << "Matrix B:" << endl;
	print(shared->B, shared->size);
	cout << "Matrix AXB:" << endl;
	print(shared->C, shared->size);
  }
}

# 165 "mmult.csl"
static void f1_0_0(int numThreads, int tid) {
# 165 "mmult.csl"

	   int     from = tid * (SIZE/numThreads);
	   int     to = from + (SIZE/numThreads);
	   mm_cm(shared->A, shared->B, shared->C, from, to, shared->size, shared->size);
    }


