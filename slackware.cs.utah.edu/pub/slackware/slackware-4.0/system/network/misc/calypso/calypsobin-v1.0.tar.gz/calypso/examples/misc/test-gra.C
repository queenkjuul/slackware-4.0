// file donohing.C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iostream.h>
#include <builtin.h>

#include "gra.H"

int ft      = 1;
int workers = 0;


void printUsage(char *prog) {
  cout << "Usage: " << prog << " [-w <n>] [-f]" << ::endl;
  cout << "Where" << ::endl;
  cout << "   -w <n> -- Ask the global resource allocator (gra) to allocate" << ::endl;
  cout << "             up to <n> workers for this process.  This option implicitly" << ::endl;
  cout << "             implies that this is the manager." << ::endl;
  cout << "   -f     -- Indicate this is _not_ a fault-tolerant application" << ::endl;
}


main(int ac, char* av[]) {
  char   c;
  while ((c = getopt(ac, av, "w:f")) != -1) {
	switch(c) {
	case 'w':
	  workers = atoi(optarg);
	  break;
	case 'f':
	  ft = 0;
	  break;
	default:
	  printUsage(av[0]);
	  exit(1);
	}
  }

  // if this is a worker...
  if (workers == 0) {
	for (int i=0; i<30; i++) {
	  cout << ".";
	  sleep(2);
	}
	cout << ::endl;
	exit(0);
  }

  // if this is a manager...
  char   commandLine[200];
  sprintf(commandLine, "%s", av[0]);
  if (ft)
	initialize_gra(commandLine, workers, FAULT_TOLERANT);
  else
	initialize_gra(commandLine, workers);
  
  cout << "manager starting and requesting " << workers << " workers." << ::endl << ::flush;
  for (int i=0; i<300; i++) {
	sleep(2);
	cout << "." << ::flush;
  }
}

