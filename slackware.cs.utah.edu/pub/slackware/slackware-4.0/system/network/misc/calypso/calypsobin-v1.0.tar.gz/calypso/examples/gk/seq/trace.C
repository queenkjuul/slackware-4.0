/*
 * (c) 1988 by George Kyriazis
 */

/* 
 * This is the actual ray-tracing part
 */

#include    <stdlib.h>
#include	<stdio.h>
#include	<math.h>
#include    <iostream.h>
#include    "W.h"
#include    "calypso.H"
#include	"ray.h"

extern "C" {
#include	"vector.h"
}
struct	color	shade(struct intersect i, struct ray r, int n);
struct	color	bgcolor(ray r);
struct	intersect	intersect(ray r);

extern  int	noo;          /* number of objects */
extern  int	tries;        /* number of tries per pixel */
extern  int	xres, yres;   /* resolution */
extern  int	bgflag;       /* background cuing info */
/* eye viewing stuff */
extern  struct	vector	hor, ver, eye_dir, eye, up;
extern  double	fov;
extern  struct	light	light;
extern  double	time1, time2;	/* time limits */
extern  double	Time;			/* current time */
extern  struct	obj	obj[MAX_NOO];      /* the array of spheres */
extern  int       blocksx, blocksy;
extern  int       picture[MAX_SIZE][MAX_SIZE];

extern int draw;
// ----------------------------------------------------------
//int	raycount = 0;	    /* total number of rays */
//int	shadowcount;		/* total number of shadow rays traced */
//int	reflectcount;		/* total number of reflected rays */
//int	refractcount;		/* total number of refracted rays */
//int	intersectcount;		/* total number of object intersections */
//int	objtestcount;		/* total number of intersection tests */

//int	rayline = 0;	    /* rays / line */
//int	shadowline;		    /* shadow rays / line */
//int	reflectline;		/* reflected rays / line */
//int	refractline;		/* refracted rays / line */
//int	intersectline;		/* object intersections / line */
//int	objtestline;		/* object intersection tests / line */
// ----------------------------------------------------------

double	quickcos(double x)
{
  double	val;

  val = 1 - x*x/2.4684;

  return val;
}

double	quickinvcos(double x)
{
  double	val;

  val = sqrt(2.4684*(1-x));

  return val;
}

/*
 * floating point random number generator
 */
double	rnd()
{
  double	t;

  t = (double)( random() & 0xffffff ) / 16777215;

  return t;
}

/*
 * Random number between -1 and 1
 */
double	rand1()
{
  return ( (rnd()-.5) * 2);
}

/*
 * approximate a gaussian random number generator between -1 and 1
 */
double	grand()
{
  double	t;

  /* get a random number between -1 and 1 */
  t = ( rnd() - .5 ) * 2;

  /* and then square it.  DOn't lose the sign! */
  return (t*ABS(t));
}

/*
 * pick a random ray somewhere inside the solid angle
 */
struct	ray	sample_ray(ray r, double theta)
{
  double	phi1, phi2;
  struct	vector	c;	/* directional cosines */
  struct	ray	r2;

  /*
   * adds the following 2 angles in 2 of the 3 angles specified by the
   * directional cosines
   */
  phi1 = grand() * theta;
  phi2 = grand() * theta;

  c = r.dir;

  /* choose two of them that are linearly independent */
  if( c.x > .5 ) {
	c.x = quickcos(quickinvcos(c.x) + phi1);
	c.y = quickcos(quickinvcos(c.y) + phi2);
  } else
	if( c.y < .5 ) {
	  c.y = quickcos(quickinvcos(c.y) + phi1);
	  c.z = quickcos(quickinvcos(c.z) + phi2);
	} else {
	  c.z = quickcos(quickinvcos(c.z) + phi1);
	  c.x = quickcos(quickinvcos(c.x) + phi2);
	}

  /* the third directional cosine is fixed when normalizing */
  r2.pos = r.pos;
  r2.dir = norm( c );
  r2.theta = 0;
  r2.obj = r.obj;

  return r2;
}

/*
 * trace a single strait ray
 */
struct	color	trace_a_ray(ray r, int n) /* n is the  recursion level */
{
  struct	intersect	inter;
  struct	color	col;
  double	m;

  /* update stats */
  //rayline++;
  /* check for intersection with the object */
  inter = intersect(r);
  /* if no intersection, return some background color */
  if( inter.obj == NULL )
	return bgcolor(r);
  /* more stats */
  //intersectline++;
  /* else calculate the shading function there */
  col = shade(inter, r, n);
  /* if the color > 1, that means that the components are too big. Normalize. */
  m = col.r;
  if( col.g > m )
	m = col.g;
  if( col.b > m )
	m = col.b;
  if( m > 1 ) {
	/* overflow condition */
	/* normalize it! */
	col.r /= m;
	col.g /= m;
	col.b /= m;
  }
  return col;
}

/*
 * Trace a ray within the specified solid angle
 */
struct	color	trace(ray r, int n)
{
  struct	ray	r2;

  r2 = sample_ray(r, r.theta);

  return ( trace_a_ray(r2, n) );
}


// ----------------------------------------------------------
// ------------------ drawing routines ----------------------
void rgb2color(int r, int g, int b, int &color) {
  color  = ((r << 16) & 0xFF0000);
  color |= ((g << 8) & 0xFF00);
  color |= (b & 0xFF);
}

void color2rgb(int color, int &r, int &g, int &b) {
  r = ((color >> 16) & 0xFF);
  g = ((color >> 8) & 0xFF);
  b = (color & 0xFF);
}

void fillPicture(int ax, int ay, int bx, int by) {
  int   r, g, b;
  for (int i=ay; i<by; i++) {
	for (int j=ax; j<bx; j++) {
	  color2rgb(picture[i][j], r, g, b);
	  W_color(r, g, b);
	  W_vector(j, i, j, i);
	}
  }
  W_sync();
}

void w_box(int ax, int ay, int bx, int by, int c, int fill) {
  W_color(c, c, c);
  if (fill) {
	W_box(ax, ay, bx, by);
  } else {
	W_vector(ax, ay, bx, ay);
	W_vector(bx, ay, bx, by);
	W_vector(bx, by, ax, by);
	W_vector(ax, by, ax, ay);
  }
}

void id2range(int num, int id, int &ax, int &ay, int &bx, int &by) {
  ax = ((int)(id % blocksx)) * (xres / blocksx);
  ay = ((int)(id / blocksx)) * (yres / blocksy);
  bx = ax + (xres / blocksx);
  by = ay + (yres / blocksy);
}

void drawPicture(int num, int id) {
  int   ax, ay, bx, by;
  if (!draw)
	return;
  id2range(num, id, ax, ay, bx, by);
  fillPicture(ax, ay, bx, by);
}

void drawFrame(int num, int id) {
  int   ax, ay, bx, by;
  if (!draw)
	return;
  id2range(num, id, ax, ay, bx, by);
  w_box(ax, ay, bx-1, by-1, 65535, 0);
  W_sync();
}

void writePictureToFile(char *fname) {
  FILE	*f = NULL;
  f = fopen(fname, "w");
  if (f != NULL) {
	fwrite(&xres, sizeof(int), 1, f);
	fwrite(&yres, sizeof(int), 1, f);

	int   r, g, b;
	for (int i=0; i<yres; i++) {
	  for (int j=0; j<xres; j++) {
		color2rgb(picture[i][j], r, g, b);
		putc(r,f);
		putc(g,f);
		putc(b,f);
	  }
	}
	fclose(f);
  }
}

/*
 * raytrace the whole scene
 */
void raytrace(char *fname, int output, int draw) {
  hor = norm( vcross(up, eye_dir) );	/* the x screen vector */
  ver = norm( vcross( eye_dir, hor) );	/* the y screen vector */

  blocksx = 2 + rand() % 10;
  blocksy = 2 + rand() % 10;

  int     c;
  struct	color	col, color;
  double	p_w = fov / MIN(xres, yres);	/* pixel width in radians */

  struct	ray	ray, r2;
  ray.pos = eye;		/* eye is the beginning of the ray */
  ray.obj = NULL;		/* not coming from an object */

  for(int x = 0; x < xres; x++) {
	double xr = -1 + x * (2. / xres);
	for(int y = 0; y < yres; y++) {
	  double   yr = 1. - (y * 2. / yres);

	  /* ray direction calculations */
	  ray.dir = vadd( svproduct(xr*fov, hor),
					  svproduct(yr*fov, ver) );
	  ray.dir = norm( vadd( ray.dir, eye_dir) );
	  ray.theta = 0;
	  col.r = col.g = col.b = 0;

	  /* the time blur has to be done in linear time and not randomly */
	  /* randomization is used so we won't get the strobo effect      */
	  for(int i = tries; i--; ) {
		Time = (time2+time1)/2 +
		  (time2-time1)*(i+rand1())/tries;
		r2 = sample_ray(ray, p_w);
		color = trace_a_ray(r2, 0);
		/* sum all the intensities together */
		col.r += color.r / tries;
		col.g += color.g / tries;
		col.b += color.b / tries;
	  }

	  /* calc the integer value to be put to the file */
	  rgb2color((int)(col.r * 255), (int)(col.g * 255), (int)(col.b * 255), c);
	  picture[y][x] = c;
	}
  }
}

