#define	__CALYPSO__	1
#ifndef NULL
#define NULL 0
#endif
typedef void (*FunctionPtr)(int, int);
typedef int  (*BoolFunctionPtr)(void);
extern int _true();
void calypso_main(int argc, char *argv[]);
void calypso_pt_initialize();
void calypso_pt_addJob(int numberOfThreads, FunctionPtr func, FunctionPtr post=NULL, FunctionPtr pre=NULL);
void calypso_pt_flush();
void calypso_manageParallelJobs(BoolFunctionPtr guard = _true);
static void f1_0_0(int num, int id) ;
/*
 * (c) 1988 by George Kyriazis
 */

/* 
 * This is the actual ray-tracing part
 */

#include    <stdlib.h>
#include	<stdio.h>
#include	<math.h>
#include    <iostream.h>
#include    "W.h"
#include    "calypso.H"
#include	"ray.h"

extern "C" {
#include	"vector.h"
}
struct	color	shade(struct intersect i, struct ray r, int n);
struct	color	bgcolor(ray r);
struct	intersect	intersect(ray r);

typedef struct {
void		*_calypso_swizzle_in[1423];
# 24 "trace.csl"

  int	noo;          /* number of objects */
  int	tries;        /* number of tries per pixel */
  int	xres, yres;   /* resolution */
  int	bgflag;       /* background cuing info */

  /* eye viewing stuff */
  struct	vector	hor, ver, eye_dir, eye, up;
  double	fov;
  struct	light	light;

  double	time1, time2;	/* time limits */
  double	Time;			/* current time */

  struct	obj	obj[MAX_NOO];      /* the array of spheres */

  int       blocksx, blocksy;
  int       picture[MAX_SIZE][MAX_SIZE];
void		*_calypso_swizzle_out[1832];
# 42 "trace.csl"
} Shared;
extern struct Shared *shared;
# 42 "trace.csl"


extern int draw;
// ----------------------------------------------------------
//int	raycount = 0;	    /* total number of rays */
//int	shadowcount;		/* total number of shadow rays traced */
//int	reflectcount;		/* total number of reflected rays */
//int	refractcount;		/* total number of refracted rays */
//int	intersectcount;		/* total number of object intersections */
//int	objtestcount;		/* total number of intersection tests */

//int	rayline = 0;	    /* rays / line */
//int	shadowline;		    /* shadow rays / line */
//int	reflectline;		/* reflected rays / line */
//int	refractline;		/* refracted rays / line */
//int	intersectline;		/* object intersections / line */
//int	objtestline;		/* object intersection tests / line */
// ----------------------------------------------------------

double	quickcos(double x)
{
  double	val;

  val = 1 - x*x/2.4684;

  return val;
}

double	quickinvcos(double x)
{
  double	val;

  val = sqrt(2.4684*(1-x));

  return val;
}

/*
 * floating point random number generator
 */
double	rnd()
{
  double	t;

  t = (double)( random() & 0xffffff ) / 16777215;

  return t;
}

/*
 * Random number between -1 and 1
 */
double	rand1()
{
  return ( (rnd()-.5) * 2);
}

/*
 * approximate a gaussian random number generator between -1 and 1
 */
double	grand()
{
  double	t;

  /* get a random number between -1 and 1 */
  t = ( rnd() - .5 ) * 2;

  /* and then square it.  DOn't lose the sign! */
  return (t*ABS(t));
}

/*
 * pick a random ray somewhere inside the solid angle
 */
struct	ray	sample_ray(ray r, double theta)
{
  double	phi1, phi2;
  struct	vector	c;	/* directional cosines */
  struct	ray	r2;

  /*
   * adds the following 2 angles in 2 of the 3 angles specified by the
   * directional cosines
   */
  phi1 = grand() * theta;
  phi2 = grand() * theta;

  c = r.dir;

  /* choose two of them that are linearly independent */
  if( c.x > .5 ) {
	c.x = quickcos(quickinvcos(c.x) + phi1);
	c.y = quickcos(quickinvcos(c.y) + phi2);
  } else
	if( c.y < .5 ) {
	  c.y = quickcos(quickinvcos(c.y) + phi1);
	  c.z = quickcos(quickinvcos(c.z) + phi2);
	} else {
	  c.z = quickcos(quickinvcos(c.z) + phi1);
	  c.x = quickcos(quickinvcos(c.x) + phi2);
	}

  /* the third directional cosine is fixed when normalizing */
  r2.pos = r.pos;
  r2.dir = norm( c );
  r2.theta = 0;
  r2.obj = r.obj;

  return r2;
}

/*
 * trace a single strait ray
 */
struct	color	trace_a_ray(ray r, int n) /* n is the  recursion level */
{
  struct	intersect	inter;
  struct	color	col;
  double	m;

  /* update stats */
  //rayline++;
  /* check for intersection with the object */
  inter = intersect(r);
  /* if no intersection, return some background color */
  if( inter.obj == NULL )
	return bgcolor(r);
  /* more stats */
  //intersectline++;
  /* else calculate the shading function there */
  col = shade(inter, r, n);
  /* if the color > 1, that means that the components are too big. Normalize. */
  m = col.r;
  if( col.g > m )
	m = col.g;
  if( col.b > m )
	m = col.b;
  if( m > 1 ) {
	/* overflow condition */
	/* normalize it! */
	col.r /= m;
	col.g /= m;
	col.b /= m;
  }
  return col;
}

/*
 * Trace a ray within the specified solid angle
 */
struct	color	trace(ray r, int n)
{
  struct	ray	r2;

  r2 = sample_ray(r, r.theta);

  return ( trace_a_ray(r2, n) );
}


// ----------------------------------------------------------
// ------------------ drawing routines ----------------------
void rgb2color(int r, int g, int b, int &color) {
  color  = ((r << 16) & 0xFF0000);
  color |= ((g << 8) & 0xFF00);
  color |= (b & 0xFF);
}

void color2rgb(int color, int &r, int &g, int &b) {
  r = ((color >> 16) & 0xFF);
  g = ((color >> 8) & 0xFF);
  b = (color & 0xFF);
}

void fillPicture(int ax, int ay, int bx, int by) {
  int   r, g, b;
  for (int i=ay; i<by; i++) {
	for (int j=ax; j<bx; j++) {
	  color2rgb(shared->picture[i][j], r, g, b);
	  W_color(r, g, b);
	  W_vector(j, i, j, i);
	}
  }
  W_sync();
}

void w_box(int ax, int ay, int bx, int by, int c, int fill) {
  W_color(c, c, c);
  if (fill) {
	W_box(ax, ay, bx, by);
  } else {
	W_vector(ax, ay, bx, ay);
	W_vector(bx, ay, bx, by);
	W_vector(bx, by, ax, by);
	W_vector(ax, by, ax, ay);
  }
}

void id2range(int num, int id, int &ax, int &ay, int &bx, int &by) {
  ax = ((int)(id % shared->blocksx)) * (shared->xres / shared->blocksx);
  ay = ((int)(id / shared->blocksx)) * (shared->yres / shared->blocksy);
  bx = ax + (shared->xres / shared->blocksx);
  by = ay + (shared->yres / shared->blocksy);
}

void drawPicture(int num, int id) {
  int   ax, ay, bx, by;
  if (!draw)
	return;
  id2range(num, id, ax, ay, bx, by);
  fillPicture(ax, ay, bx, by);
}

void drawFrame(int num, int id) {
  int   ax, ay, bx, by;
  if (!draw)
	return;
  id2range(num, id, ax, ay, bx, by);
  w_box(ax, ay, bx-1, by-1, 65535, 0);
  W_sync();
}

void writePictureToFile(char *fname) {
  FILE	*f = NULL;
  f = fopen(fname, "w");
  if (f != NULL) {
	fwrite(&(shared->xres), sizeof(int), 1, f);
	fwrite(&(shared->yres), sizeof(int), 1, f);

	int   r, g, b;
	for (int i=0; i<shared->yres; i++) {
	  for (int j=0; j<shared->xres; j++) {
		color2rgb(shared->picture[i][j], r, g, b);
		putc(r,f);
		putc(g,f);
		putc(b,f);
	  }
	}
	fclose(f);
  }
}

/*
 * raytrace the whole scene
 */
void raytrace(char *fname, int output, int draw) {
  shared->hor = norm( vcross(shared->up, shared->eye_dir) );	/* the x screen vector */
  shared->ver = norm( vcross( shared->eye_dir, shared->hor) );	/* the y screen vector */

  shared->blocksx = 2 + rand() % 10;
  shared->blocksy = 2 + rand() % 10;
  //shared->blocksx = 1;
  //shared->blocksy = shared->yres;

  calypso_pt_initialize();

	# 297 "trace.csl"
calypso_pt_addJob(shared->blocksx * shared->blocksy, &f1_0_0 ,&drawFrame, &drawPicture);

  calypso_manageParallelJobs( ); calypso_pt_flush();
# 341 "trace.csl"

}

# 297 "trace.csl"
static void f1_0_0(int num, int id) {
# 297 "trace.csl"

	//routine[shared->blocksx * shared->blocksy](int num, int id) {
	int   ax, ay, bx, by;
	id2range(num, id, ax, ay, bx, by);

	int     c;
	struct	color	col, color;
	double	p_w = shared->fov / MIN(shared->xres, shared->yres);	/* pixel width in radians */

	struct	ray	ray, r2;
	ray.pos = shared->eye;		/* eye is the beginning of the ray */
	ray.obj = NULL;		/* not coming from an object */

	for(int y = ay; y < by; y++) {
	  double   yr = 1. - (y * 2. / shared->yres);
	  for(int x = ax; x < bx; x++) {
		double xr = -1 + x * (2. / shared->xres);

		/* ray direction calculations */
		ray.dir = vadd( svproduct(xr*shared->fov, shared->hor),
						svproduct(yr*shared->fov, shared->ver) );
		ray.dir = norm( vadd( ray.dir, shared->eye_dir) );
		ray.theta = 0;
		col.r = col.g = col.b = 0;

		/* the time blur has to be done in linear time and not randomly */
		/* randomization is used so we won't get the strobo effect      */
		for(int i = shared->tries; i--; ) {
		  shared->Time = (shared->time2+shared->time1)/2 +
			(shared->time2-shared->time1)*(i+rand1())/shared->tries;
		  r2 = sample_ray(ray, p_w);
		  color = trace_a_ray(r2, 0);
		  /* sum all the intensities together */
		  col.r += color.r / shared->tries;
		  col.g += color.g / shared->tries;
		  col.b += color.b / shared->tries;
		}

		/* calc the integer value to be put to the file */
		rgb2color((int)(col.r * 255), (int)(col.g * 255), (int)(col.b * 255), c);
		shared->picture[y][x] = c;
	  }
	}
  }


