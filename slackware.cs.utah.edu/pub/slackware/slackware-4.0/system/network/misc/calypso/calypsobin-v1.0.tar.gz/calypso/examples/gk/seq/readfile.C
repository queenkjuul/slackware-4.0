
/*
 * (c) 1988 by George Kyriazis
 */

/*
 * read the input file of the ray-tracer
 */

#include	<stdio.h>
#include	<math.h>
#include	"ray.h"

extern  int	noo;          /* number of objects */
extern  int	tries;        /* number of tries per pixel */
extern  int	xres, yres;   /* resolution */
extern  int	bgflag;       /* background cuing info */
  /* eye viewing stuff */
extern  struct	vector	hor, ver, eye_dir, eye, up;
extern  double	fov;
extern  struct	light	light;
extern  double	time1, time2;	/* time limits */
extern  double	Time;			/* current time */
extern  struct	obj	obj[MAX_NOO];      /* the array of spheres */
extern  int       blocksx, blocksy;
extern  int       picture[MAX_SIZE][MAX_SIZE];

void readfile(char	*fname)
{
	FILE	*f;
	int	i, j;
	int	nos, nosq;
	char	s[10];

	f = fopen(fname,"r");
	if(f == NULL) {
		perror("fopen");
		exit(1);
	}

/* file format is:
 *	<fov> field of view
 *	<eyex eyey eyez> position of the eye
 *	<dirx diry dirz> dorection of view
 *	<upx upy upz> up vector
 *	<time1 time2> time limits
 *	<#> background cuing
 *	<iter> number of iterations per pixel
 *	<x y z angle> coordinates and angle of the light source
 *	number or spheres  number of squares
 * 	<x y z r [ambient] [diff] [spec] refl r g b refr r g b
 *		width index refl_diffuse refr_diffuse tx ty tz> 
 *		for every sphere
 *	<x y z x y z x y z [ambient] [diff] [spec]
 *		refl r g b refr r g b with index 
 *		refl_diffuse refr_diffuse tx ty tz>
 *		  for every square
 */

/* viewing transform */
	fscanf(f, "%lf", &fov);
	fov = tan( fov * M_PI / 180 ) / sqrt(2.0);
	fscanf(f, "%lf %lf %lf", &eye.x, &eye.y, &eye.z);
	fscanf(f, "%lf %lf %lf", &eye_dir.x, &eye_dir.y, &eye_dir.z);
	fscanf(f, "%lf %lf %lf", &up.x, &up.y, &up.z);

/* time information */
	fscanf(f, "%lf %lf", &time1, &time2);

/* the background flag */
	fscanf(f, "%s", s);
	if( *s == 'n' ) bgflag = NONE;
	if( *s == 'x' ) bgflag = X;
	if( *s == 'y' ) bgflag = Y;
	if( *s == 'z' ) bgflag = Z;

/* how many samples per pixel? */
	fscanf(f, "%d", &tries);

/* now the light source */
	fscanf(f, "%lf %lf %lf %lf", &light.org.x, &light.org.y,
		&light.org.z, &light.angle);
	light.angle *= M_PI/180;

	fscanf(f, "%d %d", &nos, &nosq);
	noo = nos + nosq;

	//obj = (struct obj *)malloc(noo * sizeof(struct obj) ); -ab.
	//if(obj == NULL) {
	//	perror("malloc");
	//	exit(1);
	//}

	struct obj *objPtr;
	i = 0;
	for(j = 0; j < nos; j++) {
		objPtr = &(obj[i]);
		objPtr->type = SPHERE;
		fscanf(f, "%lf %lf %lf %lf", &(objPtr->data.sphere.center.x),
			&(objPtr->data.sphere.center.y),
			&(objPtr->data.sphere.center.z),
			&(objPtr->data.sphere.radius) );
		fscanf(f, "%lf %lf %lf", &(objPtr->ambient.r),
			&(objPtr->ambient.g),
			&(objPtr->ambient.b));
		fscanf(f, "%lf %lf %lf", &(objPtr->diffuse.r),
			&(objPtr->diffuse.g),
			&(objPtr->diffuse.b));
		fscanf(f, "%lf %lf %lf", &(objPtr->specular.r),
			&(objPtr->specular.g),
			&(objPtr->specular.b));
		fscanf(f, "%lf %lf %lf %lf", &(objPtr->reflection),
			&(objPtr->refl_color.r),
			&(objPtr->refl_color.g),
			&(objPtr->refl_color.b));
		fscanf(f, "%lf %lf %lf %lf", &(objPtr->refraction),
			&(objPtr->refr_color.r),
			&(objPtr->refr_color.g),
			&(objPtr->refr_color.b));
		fscanf(f, "%lf %lf", &(objPtr->width), &(objPtr->index));
		fscanf(f, "%lf %lf", &(objPtr->refl_diffuse),
				&(objPtr->refr_diffuse));
			objPtr->refl_diffuse *= M_PI / 180;
			objPtr->refr_diffuse *= M_PI / 180;
		fscanf(f, "%lf %lf %lf", &(objPtr->time.x),
			&(objPtr->time.y), &(objPtr->time.z));
		i++;
	}

	for( j = 0; j < nosq; j++) {
		objPtr = &(obj[i]);
		objPtr->type = SQUARE;
		fscanf(f, "%lf %lf %lf", &(objPtr->data.quad.p1.x),
			&(objPtr->data.quad.p1.y),
			&(objPtr->data.quad.p1.z));
		fscanf(f, "%lf %lf %lf", &(objPtr->data.quad.p2.x),
			&(objPtr->data.quad.p2.y),
			&(objPtr->data.quad.p2.z));
		fscanf(f, "%lf %lf %lf", &(objPtr->data.quad.p3.x),
			&(objPtr->data.quad.p3.y),
			&(objPtr->data.quad.p3.z));
		fscanf(f, "%lf %lf %lf", &(objPtr->ambient.r),
			&(objPtr->ambient.g),
			&(objPtr->ambient.b));
		fscanf(f, "%lf %lf %lf", &(objPtr->diffuse.r),
			&(objPtr->diffuse.g),
			&(objPtr->diffuse.b));
		fscanf(f, "%lf %lf %lf", &(objPtr->specular.r),
			&(objPtr->specular.g),
			&(objPtr->specular.b));
		fscanf(f, "%lf %lf %lf %lf", &(objPtr->reflection),
			&(objPtr->refl_color.r),
			&(objPtr->refl_color.g),
			&(objPtr->refl_color.b));
		fscanf(f, "%lf %lf %lf %lf", &(objPtr->refraction),
			&(objPtr->refr_color.r),
			&(objPtr->refr_color.g),
			&(objPtr->refr_color.b));
		fscanf(f, "%lf %lf", &(objPtr->width), &(objPtr->index));
		fscanf(f, "%lf %lf", &(objPtr->refl_diffuse),
				&(objPtr->refr_diffuse));
			objPtr->refl_diffuse *= M_PI / 180;
			objPtr->refr_diffuse *= M_PI / 180;
		fscanf(f, "%lf %lf %lf", &(objPtr->time.x),
			&(objPtr->time.y), &(objPtr->time.z));
		i++;
	}

}
