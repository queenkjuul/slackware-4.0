/*
 * file W.h
 * "@(#) $Id: W.h,v 1.2 1997/02/28 10:04:09 baratloo Exp $"
 */

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define TIME_CLICK 256
#define TABLET_PEN 257
#define LEFT_MOUSE_BUTTON (TABLET_PEN + 1)
#define MIDDLE_MOUSE_BUTTON (TABLET_PEN + 2)
#define RIGHT_MOUSE_BUTTON (TABLET_PEN + 3)
#define MOUSE_MOTION (TABLET_PEN + 4)

#ifdef __cplusplus
extern "C" {
#endif __cplusplus

    /* GET THE NEXT INPUT EVENT */
extern void W_event(long *key, long *x, long *y, long *z);

    /* DRAW BOX ONTO INTERNAL IMAGE */
extern void W_box(long ax, long ay, long bx, long by);

    /* DRAW VECTOR ONTO INTERNAL IMAGE */
extern void W_vector(long ax, long ay, long bx, long by);

    /* INITIALIZATION */
extern void W_init(char *winname, long width, long height);

    /* SET THE DRAWING COLOR */
extern void W_color(unsigned short red, unsigned short green, 
		    unsigned short blue);

    /* SET THE GRAY SCALE 256=white, 0=black */
extern void W_grey_scale(unsigned short grey);

    /* UPDATE SCREEN FROM INTERNAL IMAGE */
extern void W_sync();

    /* POLYGON ROUTINES */
extern void W_new_path();
extern void W_add_vertex(int x, int y);
extern void W_polygon();

#ifdef __cplusplus
};
#endif __cplusplus

