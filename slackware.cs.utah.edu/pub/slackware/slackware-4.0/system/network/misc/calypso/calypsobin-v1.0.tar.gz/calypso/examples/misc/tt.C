#include <stdlib.h>
#include "timer.i"

void main(int ac, char *av[]) {
  Timer timer;

  timer.start();
  for (int i=0; i<1000; i++) {
	for (int j=0; j<1000; j++) {
	  for (int k=0; k<50; k++) {
		int x = rand();
	  }
	}
  }
  timer.stop();
  cout << "finished in " << timer << ::endl;
}

