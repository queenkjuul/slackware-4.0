// file mand.csl
// -------------------------------------------------------------
// Mandelbroth
//     Command line options:
//     -nN : NxN is size the matrix.
//     -eN : N = limit (resolution).
//     -dD : D = bound for divergence.
//     -lD : D = left boundry.
//     -rD : D = right boundry.
//     -tD : D = top boundry.
//     -bD : D = bottom boundry.
//     -iN : N = number of iterations.
//     -wN : N = number of workers to use (gra).
//     -g  : Grayscale.
//     -h  : Print out command line options.
// -------------------------------------------------------------

#include <stdlib.h>
#include <iostream.h>
#include <sys/time.h>
#include <math.h>
#ifdef  __GNUC__
#include <builtin.h>
#endif

#include "gra.H"

const int       LIMIT      = 255;
const int       SIZE       = 520;
const int       ITERATIONS = 10;
const double    Left       = -2.;
const double    Top        = 1.25;
const double    Right      = .5;
const double    Bottom     = -1.25;
const double    Bound      = 2.;

typedef short Grid[SIZE][SIZE];


Grid	grid;
int   size;
double left;
double right;
double top;
double bottom;
double bound;
int   blocksx;
int   blocksy;

int    limit      = LIMIT;
int    iterations = ITERATIONS;
int    grayscale  = 0;
int    workers    = 0;

// -----------------------------------------------------------------
// -----------------------------------------------------------------
class Complex {
private:
  double	re, im;
public:

  Complex(double r=0.0, double i = 0.0) {
    set(r, i);
  };

  inline void set(double r, double i) {
    re=r; im=i;
  };

  inline double real() {
	return re;
  }

  inline double imaginary() {
	return im;
  }

  inline double	len() {
    return(sqrt(re*re + im*im));
  };

  inline Complex &operator= (const Complex &a) {
    re = a.re;
    im = a.im;
    return *this;
  };

  inline friend Complex     operator+(Complex a, Complex b) {
    return Complex(a.re+b.re, a.im+b.im);
  };

  inline friend Complex     operator*(Complex a, Complex b) {
    return Complex((a.re*b.re - a.im*b.im), (a.re*b.im + a.im*b.re));
  };
};


// -----------------------------------------------------------------
// -----------------------------------------------------------------
void printUsage(char *prog_name) {
  cout << "Usage:\t" << prog_name << " <options>" << endl;
  cout << "\t-nN : NxN is size the matrix." << endl;
  cout << "\t-eN : N = limit (resolution)." << endl;
  cout << "\t-dD : D = bound for divergence." << endl;
  cout << "\t-lD : D = left boundry." << endl;
  cout << "\t-rD : D = right boundry." << endl;
  cout << "\t-tD : D = top boundry." << endl;
  cout << "\t-bD : D = bottom boundry." << endl;
  cout << "\t-iN : N = number of iterations." << endl;
  cout << "\t-wN : N = N = number of workers to use (gra)." << endl;
  cout << "\t-h  : Print out command line options." << endl;
}

void getAndSetArgs(int argc, char *argv[]) {
  char		c;
  while ((c = getopt(argc, argv, "n:e:d:l:r:t:b:i:w:hg")) != -1) {
    switch(c) {
    case 'n':	size = atoi(optarg);
      if (size > SIZE) {
		cout << "matrix must be smaller than ";
		cout << SIZE <<"X" << SIZE << "." << endl;
		exit(0);
      }
      break;
    case 'e':	limit = atoi(optarg);
      if (limit > LIMIT) {
		cout << "Resolution must be less than " << LIMIT << endl;
		exit(0);
      }
      break;
    case 'd':	bound = atof(optarg);
      break;
    case 'l':	left = atof(optarg);
      break;
    case 'r':	right = atof(optarg);
      break;
    case 't':	top = atof(optarg);
      break;
    case 'b':	bottom = atof(optarg);
      break;
    case 'i':   iterations = atoi(optarg);
      break;
	case 'w':   workers = atoi(optarg);
	  break;
	case 'g':   grayscale = 1;
	  break;
    case 'h':
    default :	printUsage(argv[0]);
      exit(0);
    }
  }
}


// -----------------------------------------------------------------
// -----------------------------------------------------------------
#include "W.h"

inline void w_initialize(int sizex, int sizey, char *title) {
  W_init(title, sizex, sizey);	/* initialize window system */
}

inline void w_sync() {
  W_sync();
}

inline void w_setColor(int r, int g, int b) {
  W_color(r, g, b);
}

inline void w_setGrayScale(short gray) {
  W_grey_scale(gray);
}

inline void w_line(int ax, int ay, int bx, int by) {
  W_vector(ax, ay, bx, ay);
}

inline void w_point(int x, int y) {
  w_line(x, y, x, y);
}

inline void w_box(int ax, int ay, int bx, int by, int c, int fill) {
  w_setColor(c, c, c);
  if (fill) {
	W_box(ax, ay, bx, by);
  } else {
	W_vector(ax, ay, bx, ay);
	W_vector(bx, ay, bx, by);
	W_vector(bx, by, ax, by);
	W_vector(ax, by, ax, ay);
  }
  w_sync();
}


// -----------------------------------------------------------------
// -----------------------------------------------------------------
inline void short2color(short c, int &r, int &g, int &b) {
  r = (c & 0x1F) * 32;
  c = c >> 2;
  g = (c & 0x1F) * 32;
  c = c >> 2;
  b = (c & 0x1F) * 32;
}

void xy2complex(int winLeft, int winTop, int winRight, int winBottom,
				int x, int y, 
				double regionLeft, double  regionTop, double regionRight, double regionBottom, 
				Complex &z) {

  double   pX = (double)(x - winLeft) / (double)(winRight - winLeft);
  double   r  = regionLeft + (regionRight - regionLeft) * pX;

  double   pY = (double)(y - winTop) / (double)(winBottom - winTop);
  double   i  = regionTop - (regionTop - regionBottom) * pY;

  z.set( r , i );
}

void operation(Complex &z, Complex &c) {
  z = z * z + c;
}

int point(Complex &c) {
  int		count;
  Complex	z(0., 0.);
  
  for (count = 0; (count < LIMIT) && (z.len() < bound); count++)
    operation(z, c);
  return count;
}


// -------------------------------------------------------------------------
// -------------------------------------------------------------------------
void drawFrame(int , int id) {
  int ax = ((int)(id % blocksx)) * (size / blocksx);
  int ay = ((int)(id / blocksx)) * (size / blocksy);
  int bx = ax + (size / blocksx);
  int by = ay + (size / blocksy);

  w_box(ax, ay, bx-1, by-1, 65535, 0);
}

void drawPicture(int , int id) {
  int ax = ((int)(id % blocksx)) * (size / blocksx);
  int ay = ((int)(id / blocksx)) * (size / blocksy);
  int bx = ax + (size / blocksx);
  int by = ay + (size / blocksy);

  int r, g, b;
  for (int x=ax; x<bx; x++)
    for (int y=ay; y<by; y++) {
	  if (grayscale) {
		w_setGrayScale(grid[x][y]);
	  } else {
		short2color(grid[x][y], r, g, b);
		w_setColor(r, g, b);
	  }
	  w_point(x, y);
	}
  w_sync();
}

void mand(Grid grid, int ax, int ay, int bx, int by) {
  Complex		z;

  for (int x=ax; x<bx; x++)
    for (int y=ay; y<by; y++) {
      xy2complex(0, 0, size, size, x, y, 
				 left, top, right, bottom, z);
      grid[x][y] = point(z);
    }
}

int tryAgain() {
  long   x1, y1, x2, y2, z;
  int    done=0;
  while (!done) {
	long key, x, y, z;
	W_event(&key, &x, &y, &z);
	switch (key) {
    case 'q':
    case 'Q':
    	done = 1;
	case LEFT_MOUSE_BUTTON:
	  x1 = x;
	  y1 = y;
	  break;
	case MIDDLE_MOUSE_BUTTON:
	  x2 = x;
	  y2 = y;
	  break;
	case RIGHT_MOUSE_BUTTON:
	  left   = Left;
	  top    = Top;
	  right  = Right;
	  bottom = Bottom;
	  return 1;
	}
  }
  Complex   z1, z2;
  xy2complex(0, 0, size, size, x1, y1,
			 left, top, right, bottom, z1);
  xy2complex(0, 0, size, size, x2, y2,
			 left, top, right, bottom, z2);
  left   = z1.real();
  top    = z1.imaginary();
  right  = z2.real();
  //bottom = z.imaginary();
  bottom = top - (right - left);
  cout << left << "," << top << endl;
  cout << right << "," << bottom << endl;
  return 1;
}

void main(int argc, char *argv[]) {
  size   = SIZE;
  left   = Left;
  top    = Top;
  right  = Right;
  bottom = Bottom;
  bound  = Bound;
  getAndSetArgs(argc, argv);
  
  w_initialize(size, size, "Mandelbrot");

  for (int count=0; count<iterations; count++) {
    blocksx = 2 + rand() % 10;
    blocksy = 2 + rand() % 10;

	for (int id = 0; id < blocksx*blocksy; id++) {
	  drawFrame(blocksx*blocksy, id);
	  int ax = ((int)(id % blocksx)) * (size / blocksx);
	  int ay = ((int)(id / blocksx)) * (size / blocksy);
	  int bx = ax + (size / blocksx);
	  int by = ay + (size / blocksy);
	  mand(grid, ax, ay, bx, by);
	  drawPicture(blocksx*blocksy, id);
	}

	//if (!tryAgain())
	//  exit(0);
	sleep(2);
    w_box(0, 0, size, size, 0, 1);
  }

  w_sync();
  cout << "Done. Press <Enter> to continue..." << ::endl << ::flush;
  (void)cin.get();
}

