#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "W.h"

#define MAX_COLS   800

void printUsage(char *prog) {
  printf("Usage: %s <file>\n", prog);
}


void main(int ac, char *av[]) {
  if (ac != 2) {
	printUsage(av[0]);
	exit(1);
  }

  FILE *ifile;
  ifile = fopen(av[1], "r");
  if(ifile == NULL) {
	printf("Can't open %s\n", av[1]);
	printUsage(av[0]);
	exit(1);
  }

  int rows, cols;
  fread(&rows, sizeof(int), 1, ifile);
  fread(&cols, sizeof(int), 1, ifile);
  if (cols > MAX_COLS)
	cols = MAX_COLS;
  if (rows > MAX_COLS)
	rows = MAX_COLS;


  unsigned short   r, g, b;
  char             colors[3*MAX_COLS];
  W_init(av[1], rows, cols);

  for (int i=0; i<rows; i++) {
	fread(colors, sizeof(char), 3*cols, ifile);
	for (int j=0; j<cols; j++) {
	  r = (unsigned short)colors[3*j];
	  g = (unsigned short)colors[3*j+1];
	  b = (unsigned short)colors[3*j+2];
	  W_color(r, g, b);
	  W_vector(j, i, j, i);
	}
	W_sync();
  }
  close((int)ifile);

  printf("done!\n");
  int    done=0;
  while (!done) {
	long key, x, y, z;
	W_event(&key, &x, &y, &z);
	switch (key) {
    case 'q':
    case 'Q':
    	done = 1;
	}
  }
}
