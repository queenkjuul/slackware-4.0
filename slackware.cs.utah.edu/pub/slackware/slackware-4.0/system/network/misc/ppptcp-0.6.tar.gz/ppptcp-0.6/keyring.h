/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "types.h"

/* Key option structure */
typedef struct keyring {
	char *hostpat;			/* Host wildcard pattern */
	char *portpat;			/* Port wildcard pattern */
	char *ppp_options;		/* Options for pppd */
	char *public_key;		/* Base64 encoded RSA public key */
	char *private_key;		/* Base64 encoded RSA private key */
	fourbyte seed_in;		/* Random seed for next input key */
	fourbyte seed_out;		/* Random seed for next output key */
	unsigned char des_in[8];	/* DES key for next input packet */
	unsigned char des_out[8];	/* DES key for next output packet */
	char  hostip[20];		/* Filled in for the current key */
	int   hostport;			/* Filled in for the current key */
	struct keyring *next;
} keyring;

extern keyring *LoadKeys(char *keyfile);
extern keyring *FindKey(keyring *ring, char *hostip, int port);
extern void DestroyKeys(keyring *ring);
