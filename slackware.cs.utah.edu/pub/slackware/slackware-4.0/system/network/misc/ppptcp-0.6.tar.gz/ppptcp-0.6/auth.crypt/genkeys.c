/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>

/* Local includes */
#include "types.h"
#include "packet.h"
#include "rsacrypt.h"

#define KEYSIZE	512

#define RSATEXT	"RSA encryption/decryption test succeeded."

static void WritePubKey(R_RSA_PUBLIC_KEY *key);
static void WritePrivKey(R_RSA_PRIVATE_KEY *key);

main(int argc, char *argv[])
{
	struct timeval now;
	unsigned int bytesleft; unsigned char randbyte;
	R_RANDOM_STRUCT weewee;
	R_RSA_PROTO_KEY protoKey;
	R_RSA_PUBLIC_KEY public_orig, public_key;
	R_RSA_PRIVATE_KEY private_orig, private_key;
	packet *public_encoded, *private_encoded;
	packet *public_decoded, *private_decoded;
	packet *rsatext;

	/* Initialize silly random struct */
	R_RandomInit(&weewee);
	gettimeofday(&now, NULL);
	srand(now.tv_usec);
	for ( R_GetRandomBytesNeeded(&bytesleft, &weewee);
						bytesleft > 0; --bytesleft ) {
		randbyte = (rand()%256);
		R_RandomUpdate(&weewee, &randbyte, 1);
	}
  
	protoKey.bits = KEYSIZE;
	protoKey.useFermat4 = 1;
  
	/* Create the set of public/private keys */
	if (R_GeneratePEMKeys(&public_orig,&private_orig,&protoKey,&weewee)) {
		fprintf(stderr, "Couldn't generate RSA keys!\n");
		exit(1);
	}
	memcpy(&public_key, &public_orig, sizeof(public_key));
	memcpy(&private_key, &private_orig, sizeof(private_key));

	/* Encode the keys, decode them, verify */
	public_encoded = encode_public_key(&public_key);
	if ( public_encoded == NULL ) {
		perror("Unable to encode public key");
		exit(1);
	}
	public_decoded = copy_pkt(public_encoded);
	if ( public_decoded == NULL ) {
		perror("Unable to copy public key");
		exit(1);
	}
	if ( decode_public_key(public_decoded, &public_key) == NULL ) {
		fprintf(stderr, "Bad encoding of public key\n");
		exit(1);
	}
	if ( memcmp(&public_orig, &public_key, sizeof(public_key)) != 0 ) {
		fprintf(stderr, "Decoded public key didn't match original!\n");
		fprintf(stderr, "Original key:\n");
		WritePubKey(&public_orig);
		fprintf(stderr, "Decoded key:\n");
		WritePubKey(&public_key);
		exit(1);
	}
	private_encoded = encode_private_key(&private_key);
	if ( private_encoded == NULL ) {
		perror("Unable to encode private key");
		exit(1);
	}
	private_decoded = copy_pkt(private_encoded);
	if ( private_decoded == NULL ) {
		perror("Unable to copy private key");
		exit(1);
	}
	if ( decode_private_key(private_decoded, &private_key) == NULL ) {
		fprintf(stderr, "Bad encoding of private key\n");
		exit(1);
	}
	if ( memcmp(&private_orig, &private_key, sizeof(private_key)) != 0 ) {
		fprintf(stderr, "Decoded private key didn't match original!\n");
		fprintf(stderr, "Original key:\n");
		WritePrivKey(&private_orig);
		fprintf(stderr, "Decoded key:\n");
		WritePrivKey(&private_key);
		exit(1);
	}

	/* Check the RSA encryption in one encrypt/decrypt pass */
	rsatext = alloc_pkt(0);
	if ( RSAencrypt(rsatext, public_encoded->buf, RSATEXT, strlen(RSATEXT))
									< 0 )
		exit(1);
	if ( RSAdecrypt(rsatext, private_encoded->buf) < 0 )
		exit(1);
	if ( strcmp(rsatext->buf, RSATEXT) != 0 ) {
		fprintf(stderr, 
		"RSA encrypted/decrypted text doesn't match original!\n");
		exit(1);
	}
	free_pkt(rsatext);
	
	/* Print the key combinations */
	printf("# Alter this pattern to match your host/port combinations\n");
	printf("*:*\n");
	printf("# RSA public key\n");
	printf("%s", public_encoded->buf);
	printf(
	"# RSA private key (only used by client)\n");
	printf("%s", private_encoded->buf);
	printf("###\n\n");
	exit(0);
}

static void WriteBigInt(FILE *output, char *label, char *bigint, int size)
{
	fprintf(output, "\t/* %s */ { ", label);
	while ( size-- > 0 )
		fprintf(output, "0x%.2X, ", (*(bigint++)&0xFF));
	fprintf(output, "},\n");
}

static void WritePubKey(R_RSA_PUBLIC_KEY *key)
{
	FILE *output = stderr;

	fprintf(output, "/* RSA Public Key */\n\n");
	fprintf(output, "static R_RSA_PUBLIC_KEY public_key = {\n");
	fprintf(output, "\t/* bits */ %d,\n", key->bits);
	WriteBigInt(output, "modulus", key->modulus, sizeof(key->modulus));
	WriteBigInt(output, "exponent", key->exponent, sizeof(key->exponent));
	fprintf(output, "};\n\n");
}
static void WritePrivKey(R_RSA_PRIVATE_KEY *key)
{
	FILE *output = stderr;

	fprintf(output, "/* RSA Private Key */\n\n");
	fprintf(output, "static R_RSA_PRIVATE_KEY private_key = {\n");
	fprintf(output, "\t/* bits */ %d,\n", key->bits);
	WriteBigInt(output, "modulus", key->modulus, sizeof(key->modulus));
	WriteBigInt(output, "public exponent", key->publicExponent,
					sizeof(key->publicExponent));
	WriteBigInt(output, "exponent", key->exponent, sizeof(key->exponent));
	fprintf(output, "{\n");
	WriteBigInt(output, "prime 1", key->prime[0], sizeof(key->prime[0]));
	WriteBigInt(output, "prime 2", key->prime[1], sizeof(key->prime[1]));
	fprintf(output, "},\n{\n");
	WriteBigInt(output, "prime exponent 1", key->primeExponent[0],
					sizeof(key->primeExponent[0]));
	WriteBigInt(output, "prime exponent 2", key->primeExponent[1],
					sizeof(key->primeExponent[1]));
	fprintf(output, "},\n");
	WriteBigInt(output, "coefficient", key->coefficient,
					sizeof(key->coefficient));
	fprintf(output, "};\n\n");
}
