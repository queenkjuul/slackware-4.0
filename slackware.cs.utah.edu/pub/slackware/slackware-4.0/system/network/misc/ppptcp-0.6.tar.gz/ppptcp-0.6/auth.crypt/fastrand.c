
/* PUBLIC DOMAIN

This is Andrew Welch's implementation of a random function, modified for PPPTCP.
It has been placed in the public domain by Andrew Welch.

Andrew Welch : andrew@ambrosiasw.com
*/

#include <sys/time.h>
#include "types.h"

static fourbyte randomSeed;

fourbyte SeedRandom(fourbyte Seed)
{
	struct timeval tv;

	if ( ! Seed ) {
		gettimeofday(&tv, (void *)0);
		Seed = ((tv.tv_usec<<16)|((tv.tv_sec^tv.tv_usec)&0xFFFF));
	}
	randomSeed = Seed;
	return(randomSeed);
}

fourbyte GetRandSeed(void)
{
	return(randomSeed);
}

/* This magic is wholly the result of Andrew Welch, not me. :-) */
twobyte FastRandom(twobyte range)
{
	twobyte		   result;
	register fourbyte  calc;
	register fourbyte  regD0;
	register fourbyte  regD1;
	register fourbyte  regD2;

	calc = randomSeed;
	regD0 = 0x41A7;
	regD2 = regD0;
	
	regD0 *= calc & 0x0000FFFF;
	regD1 = regD0;
	
	regD1 = regD1 >> 16;
	
	regD2 *= calc >> 16;
	regD2 += regD1;
	regD1 = regD2;
	regD1 += regD1;
	
	regD1 = regD1 >> 16;
	
	regD0 &= 0x0000FFFF;
	regD0 -= 0x7FFFFFFF;
	
	regD2 &= 0x00007FFF;
	regD2 = (regD2 << 16) + (regD2 >> 16);
	
	regD2 += regD1;
	regD0 += regD2;
	
	randomSeed = regD0;
	
	if ((regD0 & 0x0000FFFF) == 0x8000)
		regD0 &= 0xFFFF0000;

/* -- Now that we have our pseudo random number, pin it to the range we want */

	regD1 = range;
	regD1 *= (regD0 & 0x0000FFFF);
	regD1 = (regD1 >> 16);
	
	result = regD1;
	
	return result;
}
