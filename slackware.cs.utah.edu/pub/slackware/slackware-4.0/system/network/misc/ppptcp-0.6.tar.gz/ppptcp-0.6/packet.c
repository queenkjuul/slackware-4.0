/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* Routines to read/write packets to a TCP socket */

#include <stdio.h>
#include <sys/types.h>
#include <netinet/in.h>			/* For ntohs() and friends */
#include "types.h"
#include "packet.h"

packet *alloc_pkt(twobyte len)
{
	packet *pkt;

	/* Allocate the packet */
	pkt = (packet *)malloc(sizeof(packet));
	if ( pkt == NULL )
		return(NULL);

	/* Fill it */
	pkt->maxlen = len;
	if ( len > 0 ) {
		pkt->buf = (char *)malloc(len);
		if ( pkt->buf == NULL ) {
			free_pkt(pkt);
			return(NULL);
		}
	} else
		pkt->buf = NULL;
	pkt->len = 0;
	
	return(pkt);
}
int expand_pkt(packet *pkt, twobyte len, int savedata)
{
	char *newbuf;

	/* Expand if desired size is greater than actual size */
	if ( len > pkt->maxlen ) {
		/* Align the length in 1024 byte chunks */
		len = ((len/1024)+1)*1024;
		newbuf = (char *)malloc(len);
		if ( newbuf == NULL )
			return(-1);
		pkt->maxlen = len;
		if ( pkt->buf != NULL ) {
			if ( savedata )
				memcpy(newbuf, pkt->buf, pkt->len);
			else
				pkt->len = 0;
			free(pkt->buf);
		}
		pkt->buf = newbuf;
	}
	return(len);
}
packet *copy_pkt(packet *in)
{
	packet *out;

	out = alloc_pkt(in->maxlen);
	if ( out == NULL )
		return(NULL);
	if ( in->len > 0 ) {
		memcpy(out->buf, in->buf, in->len);
		out->len = in->len;
	}
	return(out);
}
void setbuf_pkt(packet *pkt, char *buf, twobyte len)
{
	if ( pkt->buf != NULL )
		free(pkt->buf);
	pkt->buf = buf;
	pkt->len = len;
	pkt->maxlen = len;
}
void free_pkt(packet *pkt)
{
	if ( pkt ) {
		if ( pkt->buf != NULL )
			free(pkt->buf);
		free(pkt);
	}
}
int readn(int fd, char *buf, twobyte len)
{
	int total;

	total = 0;
	while ( len > 0 ) {
		int readed;
		readed = read(fd, buf, len);
#ifdef DEBUG_PACKETS
		fprintf(stderr, "Read %d bytes (want %d more)\n", readed,
								len-readed);
#endif
		if ( readed <= 0 )	/* Assuming blocking read */
			return(-1);
		len -= readed;
		buf += readed;
		total += readed;
	}
	return(total);
}
int read_pkt(int fd, packet *pkt)
{
	char *buf;
	twobyte len;

	/* Read the length from the network */
	if ( read(fd, &len, 2) != 2 )
		return(-1);
	len = ntohs(len);

	/* Expand the packet buffer if necessary */
	if ( expand_pkt(pkt, len, 0) < 0 )
		return(-1);
	pkt->len = len;

	/* Read the packet from the network */
	return(readn(fd, pkt->buf, pkt->len));
}
int writen(int fd, char *buf, twobyte len)
{
	int total;

	total = 0;
	while ( len > 0 ) {
		int written;
		written = write(fd, buf, len);
#ifdef DEBUG_PACKETS
		fprintf(stderr, "Wrote %d bytes (want %d more)\n", written,
								len-written);
#endif
		if ( written < 0 )
			return(-1);
		len -= written;
		buf += written;
		total += written;
	}
	return(total);
}
int write_pkt(int fd, packet *pkt)
{
	char *buf;
	twobyte len;

	/* Get the data to write */
	buf = pkt->buf;
	len = pkt->len;

	/* Write the length to the network */
	len = htons(len);
	if ( write(fd, &len, 2) != 2 )
		return(-1);
	len = ntohs(len);

	/* Write the packet to the network */
	return(writen(fd, buf, len));
}
