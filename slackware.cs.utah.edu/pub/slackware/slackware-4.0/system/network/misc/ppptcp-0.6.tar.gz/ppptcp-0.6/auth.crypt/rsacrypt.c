/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* Translate RSA public and private keys to/from base64 encoding */

#include <stdio.h>
#include <sys/time.h>
#include <netinet/in.h>			/* For ntohl() and friends */

#include "types.h"
#include "packet.h"
#include "rsacrypt.h"

/* Convert to Base64 encoding */
static char base64[64] = {
	'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 
	'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 
	'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 
	'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 
	'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' 
	};
#define PAD	'='		/* Trailing pad character */


packet *base64_encode(unsigned char *data, int len)
{
	packet *out;
	twobyte outchars;
	int i;

	/* Every 3 bytes of input translates into 4 bytes of output */
	outchars = (len/3 + (len%3 ? 1 : 0))*4;
	/* Every 64 bytes of output we output a newline, plus a final newline */
	outchars += (outchars/64 + 1);
	/* Then we have a trailing null */
	++outchars;
	out = alloc_pkt(outchars);
	if ( out == NULL )
		return(NULL);
	outchars = 0;

	while ( len > 0 ) {
		fourbyte trollop;

		/* Set the 24 bit quantity */
		switch (len) {
			case 1:
				trollop = data[1];
			case 2:
				trollop = ((data[0]<<8)|data[1]);
			default:
				trollop = ((data[0]<<16)|(data[1]<<8)|data[2]);
		}
		/* Expand to base64 encoding */
		for ( i=3; i>=0; --i ) {
			out->buf[out->len+i] = 
					base64[(unsigned char)(trollop&0x3F)];
			trollop >>= 6;
		}
		/* Update variables */
		out->len += 4;
		outchars += 4;
		data += 3;
		len -= 3;

		/* Pad, if necessary */
		while ( len < 0 ) {
			out->buf[out->len+len] = PAD;
			++len;
		}

		/* Add newline at every 64 output characters */
		if ( (outchars % 64) == 0 )
			out->buf[out->len++] = '\n';
	}
	if ( out->buf[out->len-1] != '\n' )
		out->buf[out->len++] = '\n';
	out->buf[out->len] = '\0';
	return(out);
}

/* Decode a base64 packet in-place */
packet *base64_decode(packet *in)
{
	fourbyte trollop;
	byte     accum;
	int      outlen;
	unsigned char *input;
	unsigned char *output;
	int      i;

	input = in->buf;
	output = in->buf;
	outlen = 0;
	accum = 0;
	while ( in->len > 0 ) {
		if ( (*input >= 'A') && (*input <= 'Z') ) {
			trollop <<= 6;
			trollop |= (*input-'A');
			++accum;
		} else
		if ( (*input >= 'a') && (*input <= 'z') ) {
			trollop <<= 6;
			trollop |= (*input-'a')+26;
			++accum;
		} else
		if ( (*input >= '0') && (*input <= '9') ) {
			trollop <<= 6;
			trollop |= (*input-'0')+52;
			++accum;
		} else
		if ( *input == '+' ) {
			trollop <<= 6;
			trollop |= 62;
			++accum;
		} else
		if ( *input == '/' ) {
			trollop <<= 6;
			trollop |= 63;
			++accum;
		} else
		if ( *input == '=' ) {
			switch (accum) {
				case 0:
				case 1:
					/* Corrupt data */
					return(NULL);
				case 2:
					trollop <<= 12;
					--accum;
					in->len = 0;
					goto flush64;
				case 3:
					trollop <<= 6;
					in->len = 0;
					goto flush64;
				default:
					/* Never reached */
			}
		}
		--in->len;
		++input;

		if ( accum == 4 ) {
		  flush64:
			for ( i=2; i>=0; --i ) {
				output[i] = trollop&0xFF;
				trollop >>= 8;
			}
			output += (accum/2)+1;
			outlen += (accum/2)+1;
			accum = 0; 
		}
	}
	if ( accum != 0 ) {
		/* Corrupt data */
		return(NULL);
	}
	/* Return the decoded input packet */
	in->len = outlen;
	return(in);
}

#ifdef TEST_BASE64
main(int argc, char *argv[])
{
	packet *pkt, *newpkt;
	char    buf[1024];
	int     len;

	if ( argc != 2 ) {
		fprintf(stderr, "Usage: %s [-encode|-decode]\n", argv[0]);
		exit(1);
	}

	/* Suck all the input */
	pkt = alloc_pkt(1024);
	if ( pkt == NULL ) {
		perror("Couldn't allocate packet\n");
		exit(3);
	}
	while ( (len=read(0, buf, 1024)) > 0 ) {
		if ( expand_pkt(pkt, pkt->len+len, 1) < 0 ) {
			perror("Couldn't expand packet");
			exit(3);
		}
		memcpy(pkt->buf+pkt->len, buf, len);
		pkt->len += len;
	}

	/* Perform the appropriate function */
	if ( strcmp(argv[1], "-encode") == 0 ) {
		newpkt = base64_encode(pkt->buf, pkt->len);
		if ( newpkt == NULL ) {
			fprintf(stderr, "Couldn't encode packet!\n");
			exit(2);
		}
		free_pkt(pkt);
	} else
	if ( strcmp(argv[1], "-decode") == 0 ) {
		newpkt = base64_decode(pkt);
		if ( newpkt == NULL ) {
			fprintf(stderr, "Couldn't encode packet!\n");
			exit(2);
		}
	} else {
		fprintf(stderr, "Usage: %s [-encode|-decode]\n", argv[0]);
		exit(1);
	}

	/* Write the output */
	if ( fwrite(newpkt->buf, newpkt->len, 1, stdout) != 1 ) {
		perror("Couldn't write output");
		exit(3);
	}
	free_pkt(newpkt);
	exit(0);
}
#else

static int public_keylen(R_RSA_PUBLIC_KEY *key)
{
	fourbyte bits;
	int rawlen;

	rawlen = 0;
	rawlen += sizeof(bits);
	rawlen += sizeof(key->modulus);
	rawlen += sizeof(key->exponent);
	return(rawlen);
}
/* Returns a new packet that must be freed */
packet *encode_public_key(R_RSA_PUBLIC_KEY *key)
{
	packet *encoded;
	fourbyte bits;
	int rawlen;
	unsigned char *rawdata;
	unsigned char *dataptr;

	/* Allocate space for the raw key data */
	rawlen = public_keylen(key);
	rawdata = (char *)malloc(rawlen);
	if ( rawdata == NULL )
		return(NULL);

	/* Copy the key into the raw data */
	dataptr = rawdata;
	bits = key->bits; /* Separate step in case sizeof(key->bits) != 4 */
	bits = htonl(bits);
	memcpy(dataptr, &bits, sizeof(bits));
	dataptr += sizeof(bits);
	memcpy(dataptr, key->modulus, sizeof(key->modulus));
	dataptr += sizeof(key->modulus);
	memcpy(dataptr, key->exponent, sizeof(key->exponent));

	/* Encode it into a base64 representation */
	encoded = base64_encode(rawdata, rawlen);
	free(rawdata);
	return(encoded);
}
static int private_keylen(R_RSA_PRIVATE_KEY *key)
{
	fourbyte bits;
	int rawlen;

	rawlen = 0;
	rawlen += sizeof(bits);
	rawlen += sizeof(key->modulus);
	rawlen += sizeof(key->publicExponent);
	rawlen += sizeof(key->exponent);
	rawlen += sizeof(key->prime[0]);
	rawlen += sizeof(key->prime[1]);
	rawlen += sizeof(key->primeExponent[0]);
	rawlen += sizeof(key->primeExponent[1]);
	rawlen += sizeof(key->coefficient);
	return(rawlen);
}
/* Returns a new packet that must be freed */
packet *encode_private_key(R_RSA_PRIVATE_KEY *key)
{
	packet *encoded;
	fourbyte bits;
	int rawlen;
	unsigned char *rawdata;
	unsigned char *dataptr;

	/* Allocate space for the raw key data */
	rawlen = private_keylen(key);
	rawdata = (char *)malloc(rawlen);
	if ( rawdata == NULL )
		return(NULL);

	/* Copy the key into the raw data */
	dataptr = rawdata;
	bits = key->bits; /* Separate step in case sizeof(key->bits) != 4 */
	bits = htonl(bits);
	memcpy(dataptr, &bits, sizeof(bits));
	dataptr += sizeof(bits);
	memcpy(dataptr, key->modulus, sizeof(key->modulus));
	dataptr += sizeof(key->modulus);
	memcpy(dataptr, key->publicExponent, sizeof(key->publicExponent));
	dataptr += sizeof(key->publicExponent);
	memcpy(dataptr, key->exponent, sizeof(key->exponent));
	dataptr += sizeof(key->exponent);
	memcpy(dataptr, key->prime[0], sizeof(key->prime[0]));
	dataptr += sizeof(key->prime[0]);
	memcpy(dataptr, key->prime[1], sizeof(key->prime[1]));
	dataptr += sizeof(key->prime[1]);
	memcpy(dataptr, key->primeExponent[0], sizeof(key->primeExponent[0]));
	dataptr += sizeof(key->primeExponent[0]);
	memcpy(dataptr, key->primeExponent[1], sizeof(key->primeExponent[1]));
	dataptr += sizeof(key->primeExponent[1]);
	memcpy(dataptr, key->coefficient, sizeof(key->coefficient));

	/* Encode it into a base64 representation */
	encoded = base64_encode(rawdata, rawlen);
	free(rawdata);
	return(encoded);
}
R_RSA_PUBLIC_KEY *decode_public_key(packet *encoded, R_RSA_PUBLIC_KEY *key)
{
	fourbyte bits;
	packet *decoded;
	char   *dataptr;
	int     rawlen;

	/* Decode the base64 portion */
	decoded = base64_decode(encoded);
	if ( decoded == NULL )
		return(NULL);

	/* Check the size of the packet */
	if ( decoded->len != public_keylen(key) )
		return(NULL);

	/* Unpack the data into the key */
	dataptr = decoded->buf;
	memcpy(&bits, dataptr, sizeof(bits));
	bits = ntohl(bits);
	key->bits = bits;
	dataptr += sizeof(bits);
	memcpy(key->modulus, dataptr, sizeof(key->modulus));
	dataptr += sizeof(key->modulus);
	memcpy(key->exponent, dataptr, sizeof(key->exponent));
	return(key);
}
R_RSA_PRIVATE_KEY *decode_private_key(packet *encoded, R_RSA_PRIVATE_KEY *key)
{
	fourbyte bits;
	packet *decoded;
	char   *dataptr;
	int     rawlen;

	/* Decode the base64 portion */
	decoded = base64_decode(encoded);
	if ( decoded == NULL )
		return(NULL);

	/* Check the size of the packet */
	if ( decoded->len != private_keylen(key) )
		return(NULL);

	/* Unpack the data into the key */
	dataptr = decoded->buf;
	memcpy(&bits, dataptr, sizeof(bits));
	bits = ntohl(bits);
	key->bits = bits;
	dataptr += sizeof(bits);
	memcpy(key->modulus, dataptr, sizeof(key->modulus));
	dataptr += sizeof(key->modulus);
	memcpy(key->publicExponent, dataptr, sizeof(key->publicExponent));
	dataptr += sizeof(key->publicExponent);
	memcpy(key->exponent, dataptr, sizeof(key->exponent));
	dataptr += sizeof(key->exponent);
	memcpy(key->prime[0], dataptr, sizeof(key->prime[0]));
	dataptr += sizeof(key->prime[0]);
	memcpy(key->prime[1], dataptr, sizeof(key->prime[1]));
	dataptr += sizeof(key->prime[1]);
	memcpy(key->primeExponent[0], dataptr, sizeof(key->primeExponent[0]));
	dataptr += sizeof(key->primeExponent[0]);
	memcpy(key->primeExponent[1], dataptr, sizeof(key->primeExponent[1]));
	dataptr += sizeof(key->primeExponent[1]);
	memcpy(key->coefficient, dataptr, sizeof(key->coefficient));
	return(key);
}

/* RSA encryption/decryption routines */

extern int RSAPublicEncrypt (
	unsigned char *output,	/* output block */
	unsigned int *outputLen,/* length of output block */
	unsigned char *input,	/* input block */
	unsigned int inputLen,	/* length of input block */
	R_RSA_PUBLIC_KEY *publicKey,	/* RSA public key */
	R_RANDOM_STRUCT *randomStruct	/* random structure */
);

int RSAencrypt(packet *storage, char *keystring, char *data, int len)
{
	packet *keypkt;
	R_RSA_PUBLIC_KEY public_key;
	struct timeval now;
	R_RANDOM_STRUCT  weewee;
	unsigned int  bytesleft;
	unsigned char randbyte;

	/* Try to expand the packet to the max encrypted size */
	if ( expand_pkt(storage, MAX_ENCRYPTED_KEY_LEN, 0) < 0 ) {
		fprintf(stderr, "Couldn't expand storage packet.\n");
		return(-1);
	}

	/* Put the key string into a packet */
	keypkt = alloc_pkt(strlen(keystring)+1);
	if ( keypkt == NULL ) {
		fprintf(stderr, "Couldn't allocate key packet.\n");
		return(-1);
	}
	strcpy(keypkt->buf, keystring);
	keypkt->len = strlen(keystring);

	/* Extract the key */
	if ( decode_public_key(keypkt, &public_key) == NULL ) {
		fprintf(stderr, "Couldn't decode public key.\n");
		free_pkt(keypkt);
		return(-1);
	}
	free_pkt(keypkt);

	/* Get some randomness into the mix */
	R_RandomInit(&weewee);
	gettimeofday(&now, NULL);
	srand(now.tv_usec);
	for ( R_GetRandomBytesNeeded(&bytesleft, &weewee);
					bytesleft > 0; --bytesleft ) {
		randbyte = (rand()%256);
		R_RandomUpdate(&weewee, &randbyte, 1);
	}

	/* Encrypt! */
	if ( RSAPublicEncrypt(storage->buf, &bytesleft, 
				data, len, &public_key, &weewee) != 0 ) {
		fprintf(stderr, "Couldn't perform RSA encryption.\n");
		return(-1);
	}
	storage->len = bytesleft;
	return(0);
}

int RSAdecrypt(packet *storage, char *keystring)
{
	packet *keypkt;
	R_RSA_PRIVATE_KEY private_key;
	unsigned int bytesleft;
	char *data;

	/* Allocate space for the unencrypted data */
	data = (char *)malloc(MAX_ENCRYPTED_KEY_LEN);
	if ( data == NULL ) {
		fprintf(stderr, "Couldn't allocate space for decryption\n");
		return(-1);
	}

	/* Put the key string into a packet */
	keypkt = alloc_pkt(strlen(keystring)+1);
	if ( keypkt == NULL ) {
		fprintf(stderr, "Couldn't allocate key packet.\n");
		return(-1);
	}
	strcpy(keypkt->buf, keystring);
	keypkt->len = strlen(keystring);

	/* Extract the key */
	if ( decode_private_key(keypkt, &private_key) == NULL ) {
		fprintf(stderr, "Couldn't decode private key.\n");
		free_pkt(keypkt);
		return(-1);
	}
	free_pkt(keypkt);

	/* Just DecryptIt (tm) :-) */
	if ( RSAPrivateDecrypt(data, &bytesleft, storage->buf, storage->len,
							&private_key) != 0 ) {
		fprintf(stderr, "Couldn't perform RSA decryption.\n");
		return(-1);
	}
	storage->len = bytesleft;
	setbuf_pkt(storage, data, storage->len);
	storage->maxlen = MAX_ENCRYPTED_KEY_LEN;
	return(0);
}

#endif /* TEST_BASE64 */
