/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* Translate RSA public and private keys to/from base64 encoding */

/* RSAref includes */
#include <global.h>
#include <rsaref.h>

/* These functions return a new packet that must be freed */
extern packet *encode_public_key(R_RSA_PUBLIC_KEY *key);
extern packet *encode_private_key(R_RSA_PRIVATE_KEY *key);

/*
 * These functions are passed a packet created by encode_*_key() and
 * an appropriate key structure which is filled with the decoded key.
 */
extern R_RSA_PUBLIC_KEY *decode_public_key(packet *encoded,
						R_RSA_PUBLIC_KEY *key);
extern R_RSA_PRIVATE_KEY *decode_private_key(packet *encoded,
						R_RSA_PRIVATE_KEY *key);

/*
 * These functions encrypt/decrypt data using RSA public key encryption.
 * They return 0 if successful, or print an error and return -1 if they fail.
 */
extern int RSAencrypt(packet *storage, char *keystring, char *data, int len);
extern int RSAdecrypt(packet *storage, char *keystring);

