/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <netinet/in.h>		/* For ntohs() and friends */

#include "libdes.h"		/* From the libdes directory */

#include "version.h"
#include "types.h"
#include "packet.h"
#include "auth.h"
#include "keyring.h"
#include "fastrand.h"
#include "rsacrypt.h"

/* Set before authenticate() is called, for the current connection */
extern keyring *current_key;

/* Strip any authentication/cryptography related arguments */
int authargs(int argc, char *argv[])
{
	int typesOK;

	/* Check the size of our datatypes */
	typesOK = 1;
	if ( sizeof(fourbyte) != 4 ) {
		fprintf(stderr, "Warning: 4 byte quantity is really %d bytes\n",
							sizeof(fourbyte));
		typesOK = 0;
	}
	if ( sizeof(twobyte) != 2 ) {
		fprintf(stderr, "Warning: 2 byte quantity is really %d bytes\n",
							sizeof(twobyte));
		typesOK = 0;
	}
	if ( sizeof(byte) != 1 ) {
		fprintf(stderr, "Warning: 1 byte quantity is really %d bytes\n",
							sizeof(byte));
		typesOK = 0;
	}
	if ( ! typesOK ) {
		printf("Please edit \"types.h\" and recompile %s\n", argv[0]);
		exit(1);
	}
	return(argc);
}

#ifdef DEBUG_RANDOM
static void PrintFour(fourbyte value)
{
	printf("0x%.2x%.2x%.2x%.2x", 
			((char *)&value)[0]&0xFF, ((char *)&value)[1]&0xFF,
			((char *)&value)[2]&0xFF, ((char *)&value)[3]&0xFF);
}
static void PrintEight(char *value)
{
	printf("0x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x",
		value[0], value[1], value[2], value[3],
		value[4], value[5], value[6], value[7]);
}
#endif

/* The protocol:
	The client sends a version byte.
	If the server supports the version, it returns the byte and 'Y'
	If the server doesn't support the version, it returns the byte and 'N'
	If the high bit of the byte is set, encryption is supported.
	If the version byte (without encryption) is 0x7F, then it indicates
	extended version/option negotiation, currently undefined.
*/
int authenticate(char *isclient, int netfd)
{
	char version[2];

	if ( isclient ) {
		/* If we have a public key, but no private key, exit. */
		if ( current_key->public_key && ! current_key->private_key ) {
			fprintf(stderr,
			"Rule matched,\n%s:%s %s\n... has no private key!\n",
						current_key->hostpat,
						current_key->portpat,
						current_key->ppp_options);
			return(-1);
		}

		/* Send version */
		version[0] = PPPTCP_VERSION;
		if ( current_key->public_key )
			version[0] |= 0x80;
		write(netfd, version, 1);

		/* Wait for reply */
		version[1] = PROTO_UNSUPPORTED;	/* In case read() fails */
		read(netfd, version, 2);
	} else {
		/* Wait for client to send version */
		read(netfd, version, 1);

		/* If they want encryption, and we don't support it, deny */
		if ( (version[0]&0x80) && (current_key->public_key == NULL) ) {
			version[1] = PROTO_UNSUPPORTED;
		} else
		/* If they don't want encryption, and we support it, deny */
		if ( !(version[0]&0x80) && (current_key->public_key != NULL) ) {
			version[1] = PROTO_UNSUPPORTED;
		} else {
			/* Check the version */
			version[0] &= 0x7F;
			if ( version[0] == PPPTCP_VERSION )
				version[1] = PROTO_SUPPORTED;
			else
				version[1] = PROTO_UNSUPPORTED;
		}
		write(netfd, version, 2);
	}
	/* Currently we don't handle extended option negotiation */
	if ( (version[1] != PROTO_SUPPORTED) ||
				 ((version[0]&0x7F) != PPPTCP_VERSION) ) {
		fprintf(stderr,
		"PPPTCP protocol version %d (%s) not supported by remote\n",
			PPPTCP_VERSION,
			current_key->public_key ? "encrypted" : "unencrypted");
		return(-1);
	}

	/* We're done, if we have an unencrypted connection */
	if ( current_key->public_key == NULL )
		return(0);

	/* Now the client sends its public key */
	if ( isclient ) {
		packet *keypkt;
		int     length;
		fourbyte seed;

		/* Allocate and send the key packet */
		length = strlen(current_key->public_key);
		keypkt = alloc_pkt(length);
		if ( keypkt == NULL ) {
			perror("Couldn't allocate network packet");
			return(-1);
		}
		keypkt->len = length;
		memcpy(keypkt->buf, current_key->public_key, length);
		if ( write_pkt(netfd, keypkt) < 0 ) {
			perror("Network write error");
			free_pkt(keypkt);
			return(-1);
		}

		/* Wait for an acknowledgement */
		if ( read_pkt(netfd, keypkt) <= 0 ) {
			perror("Network read error");
			free_pkt(keypkt);
			return(-1);
		}

		/* The last character should be PROTO_SUPPORTED */
		--keypkt->len;
		if ( keypkt->buf[keypkt->len] != PROTO_SUPPORTED ) {
			fprintf(stderr, "Public key rejected by server\n");
			free_pkt(keypkt);
			return(-1);
		}

		/* Decrypt the packet */
		if ( RSAdecrypt(keypkt, current_key->private_key) < 0 ) {
			free_pkt(keypkt);
			return(-1);
		}
		if ( keypkt->len != sizeof(seed) ) {
			fprintf(stderr,
		"Server sent bad seed (len was %d, should have been %d).\n",
						keypkt->len, sizeof(seed));
			free_pkt(keypkt);
			return(-1);
		}
		memcpy(&seed, keypkt->buf, sizeof(seed));
		free_pkt(keypkt);

		/* Generate the random seeds for DES encryption */
		SeedRandom(ntohl(seed));
		/* First generate seed for packets from server (in) */
		FastRandom(0xFFFF);
		current_key->seed_in = GetRandSeed();
		/* Then generate seed for packets to server (out) */
		FastRandom(0xFFFF);
		current_key->seed_out = GetRandSeed();
#ifdef DEBUG_RANDOM
		printf("Seed sent by server: "); PrintFour(seed); printf("\n");
		printf("Initial input seed: ");
			PrintFour(current_key->seed_in); printf("\n");
		printf("Initial output seed: ");
			PrintFour(current_key->seed_out); printf("\n");
#endif
	} else {
		packet *keypkt;
		int     length;
		fourbyte seed;
		keyring *prev_key = NULL;		/* Jason addition */

		/* Allocate an empty packet for reception */
		keypkt = alloc_pkt(0);
		if ( keypkt == NULL ) {
			perror("Couldn't allocate network packet");
			return(-1);
		}

		/* Verify that the client key is acceptable */
		if ( read_pkt(netfd, keypkt) <= 0 ) {
			perror("Network read error");
			free_pkt(keypkt);
			return(-1);
		}
		do {
			if ( (keypkt->len == strlen(current_key->public_key)) &&
		     		(memcmp(keypkt->buf, current_key->public_key,
							keypkt->len) == 0) ) {
				break;
			} else {
				/* More Jason additions */
				if (prev_key == current_key) {
					current_key = current_key->next;
					current_key->hostport
							= prev_key->hostport;
					strcpy(current_key->hostip,
							prev_key->hostip);
				} else {
					prev_key = current_key;
				}
			}
			current_key = FindKey(current_key,
						current_key->hostip,
						current_key->hostport);
		} while ( current_key != NULL);

		if ( (current_key == NULL) ||
			(strcasecmp(current_key->ppp_options,"deny") == 0) ) {
			if ( expand_pkt(keypkt, 1, 0) < 0 ) {
				perror("Couldn't expand network packet");
				free_pkt(keypkt);
				return(-1);
			}
			keypkt->buf[0] = PROTO_UNSUPPORTED;
			keypkt->len = 1;
			write_pkt(netfd, keypkt);
			fprintf(stderr, "Public key not accepted.\n");
			free_pkt(keypkt);
			return(-1);
		}

		/* Encrypt the seed with the public key and send it off */
		seed = htonl(SeedRandom(0));
		if ( RSAencrypt(keypkt, current_key->public_key,
					(char *)&seed, sizeof(seed)) < 0 ) {
			free_pkt(keypkt);
			return(-1);
		}
		if ( expand_pkt(keypkt, keypkt->len+1, 1) < 0 ) {
			free_pkt(keypkt);
			return(-1);
		}
		keypkt->buf[keypkt->len++] = PROTO_SUPPORTED;
		if ( write_pkt(netfd, keypkt) < 0 ) {
			perror("Network write failed");
			free_pkt(keypkt);
			return(-1);
		}
		free_pkt(keypkt);

		/* Generate the random seeds for DES encryption */
		SeedRandom(ntohl(seed));
		/* First generate seed for packets to client (out) */
		FastRandom(0xFFFF);
		current_key->seed_out = GetRandSeed();
		/* Then generate seed for packets from client (in) */
		FastRandom(0xFFFF);
		current_key->seed_in = GetRandSeed();
#ifdef DEBUG_RANDOM
		printf("Seed sent to client: "); PrintFour(seed); printf("\n");
		printf("Initial input seed: ");
			PrintFour(current_key->seed_in); printf("\n");
		printf("Initial output seed: ");
			PrintFour(current_key->seed_out); printf("\n");
#endif
	}
	return(0);
}

static void CycleInputKey(keyring *key)
{
	int i;
	twobyte randtwo;

#ifdef DEBUG_RANDOM
	static int in_sequence = 0;
	printf("Input Sequence #%d: \n", ++in_sequence);
	printf("\tinput seed is "); PrintFour(key->seed_in); printf("\n");
#endif
	/* Fill the input DES key */
	SeedRandom(key->seed_in);
	for ( i=0; i<8; ) {
		randtwo = htons(FastRandom(0xFFFF));
		key->des_in[i++] = ((char *)&randtwo)[0];
		key->des_in[i++] = ((char *)&randtwo)[1];
	}
	key->seed_in = GetRandSeed();
	des_setparity(key->des_in);
#ifdef DEBUG_RANDOM
	printf("\tinput DES key is "); PrintEight(key->des_in); printf("\n");
#endif
}
static void CycleOutputKey(keyring *key)
{
	int i;
	twobyte randtwo;

#ifdef DEBUG_RANDOM
	static int out_sequence = 0;
	printf("Output Sequence #%d: \n", ++out_sequence);
	printf("\toutput seed is "); PrintFour(key->seed_out); printf("\n");
#endif
	/* Fill the input DES key */
	SeedRandom(key->seed_out);
	for ( i=0; i<8; ) {
		randtwo = htons(FastRandom(0xFFFF));
		key->des_out[i++] = ((char *)&randtwo)[0];
		key->des_out[i++] = ((char *)&randtwo)[1];
	}
	key->seed_out = GetRandSeed();
	des_setparity(key->des_out);
#ifdef DEBUG_RANDOM
	printf("\toutput DES key is "); PrintEight(key->des_out); printf("\n");
#endif
}

/* Packet encryption/decryption routines */
int packet_encrypt(packet *pkt)
{
	static unsigned char ovec[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };

	if ( current_key->public_key ) {
		twobyte pktlen;
		char *data;
		int   length;

		/* Pad to a multiple of 8 bytes, appending a packet length */
		length = pkt->len;
		if ( length % 8 )
			length = ((length/8)+1)*8;
		if ( expand_pkt(pkt, length+sizeof(pktlen), 1) < 0 ) {
			perror("Couldn't expand output packet");
			return(-1);
		}
		data = pkt->buf + pkt->len;
		memset(data, 0, length - pkt->len);
		data += (length-pkt->len);
		pktlen = htons(pkt->len);
		memcpy(data, &pktlen, sizeof(pktlen));

		/* Encrypt the packet */
		CycleOutputKey(current_key);
		cbc_crypt(current_key->des_out, pkt->buf, length,
							DES_ENCRYPT, ovec);
		pkt->len = length+sizeof(pktlen);
	}
	return(pkt->len);
}
int packet_decrypt(packet *pkt)
{
	static unsigned char ivec[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };

	if ( current_key->public_key ) {
		twobyte pktlen;
		char   *data;
		int     length;

		/* Find out how large the data is */
		pkt->len -= sizeof(pktlen);
		memcpy(&pktlen, pkt->buf+pkt->len, sizeof(pktlen));
		pktlen = ntohs(pktlen);
		if ( pktlen > pkt->len ) {
			fprintf(stderr,
		"Truncated network packet (expected %d bytes, got %d bytes)\n",
							pktlen, pkt->len);
			return(-1);
		}

		/* Make sure the length is a multiple of 8 bytes */
		if ( pkt->len % 8 ) {
			fprintf(stderr,
			"Encrypted packet not a multiple of 8 bytes!\n");
			return(-1);
		}

		/* Decrypt the packet */
		CycleInputKey(current_key);
		cbc_crypt(current_key->des_in, pkt->buf, pkt->len,
							DES_DECRYPT, ivec);
		pkt->len = pktlen;
	}
	return(pkt->len);
}
