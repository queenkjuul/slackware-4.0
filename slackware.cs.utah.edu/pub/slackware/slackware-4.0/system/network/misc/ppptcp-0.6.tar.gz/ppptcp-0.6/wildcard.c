/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* Simple routine to implement wildcard string matching */
/* Syntax:
	'*'		Match any sequence of characters
	'?'		Match any single character
	'\c'		Match the literal character 'c'
	'[nmop]' 	Match a single character in the set 'n' 'm' 'o' 'p'
	'[n-p]' 	Match a single character in the range 'n' to 'p'
	'n'		Match exactly one character 'n'
*/

int wildmatch(char *string, char *wild)
{
	while ( *string && *wild ) {
		switch (*wild) {
			case '*':
				/* Match until character after '*' */
				while ( *string ) {
					if ( wildmatch(++string, wild+1) )
						return(1);
				}
				return(0);
			case '?':
				/* Match any single character */
				++string; ++wild;
				break;
			case '\\':
				++wild;
				if ( *string != *wild )
					return(0);
				++string; ++wild;
				break;
			case '[':
				/* No '[' at end of pattern */
				++wild;
				if ( wild[0] == '\0' )
					return(0);

				if ( wild[1] == '-' ) {
					/* Range of characters "a-b]" */
					if ( (wild[2] == '\0') || 
							(wild[3] != ']') )
						return(0);
					if ( (*string < wild[0]) ||
							(*string > wild[2]) )
						return(0);
				} else {
					/* List of matching characters */
					while ( *wild && (*wild != ']') ) {
						if ( *wild == *string )
							break;
						++wild;
					}
					if ( !*wild || (*wild == ']') )
						return(0);
				}
				++string;
				while ( *wild != ']' )
					++wild;
				++wild;
				break;
			default:
				/* Match literal characters */
				if ( *string != *wild )
					return(0);
				++string; ++wild;
				break;
		}
	}
	while ( *wild == '*' ) /* Trailing '*' matches end of string */
		++wild;

	/* If string and pattern end at same time, match okay */
	if ( (*string == '\0') && (*wild == '\0') )
		return(1);
	return(0);
}
