/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* Simple program to run PPP over an arbitrary TCP connection (tunnel) 

	Well, it used to be simple. :-)
*/

#include <sys/time.h>
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>
#include <ctype.h>
#include <signal.h>
#include <setjmp.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>

#ifdef __sun__
#ifndef __svr4__
/* SunOS requires this for TCP_NODELAY */
#include <netinet/tcp.h>
#endif
#endif /* __sun__ */

#ifndef INADDR_NONE
#define INADDR_NONE 0xFFFFFFFF
#endif

#include "types.h"
#include "packet.h"
#include "auth.h"
#include "keyring.h"


/* Global variables, possibly used by the authentication module */
keyring *keys;				/* List of keys available */
keyring *current_key;			/* Set for the encryption module */
char *ppp_cmd;				/* The pppd command line */

/* Static key -- default match if there are no other key matches */
static keyring default_key;

/* Timeout routines */
static jmp_buf timeout;
void timedout(int sig)
{
	longjmp(timeout, sig);
}

/* Collect any children */
void heaven(int sig)
{
	signal(sig, heaven);
	wait(NULL);
}

/* Create a client or server TCP socket */
int Network(char *hostname, char *portname)
{
	int fd;
	struct sockaddr_in server;
	int port;
	int no_nagle = 1;

	/* Create the socket */
	fd = socket(AF_INET, SOCK_STREAM, 0);
	if ( fd < 0 ) {
		perror("Can't create socket");
		return(-1);
	}

	/* Choose your port */
	port = 0;
	if ( portname && isdigit(*portname) )
		port = atoi(portname);
	else {
		fprintf(stderr, "No port specified\n");
		return(-1);
	}

	/* Bind/Connect the socket */
	if ( hostname ) {       /* Create a client connection */

		/* Resolve hostname */
		memset(&server, 0, sizeof(server));
		server.sin_addr.s_addr = inet_addr(hostname);
		if ( server.sin_addr.s_addr == INADDR_NONE ) {
			struct hostent *hp;

			hp = gethostbyname(hostname);
			if ( hp == NULL ) {
				fprintf(stderr,
					"Couldn't resolve hostname '%s'\n",
								hostname);
				return(-1);
			}
			memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
		}
		server.sin_port = htons(port);
		server.sin_family = AF_INET;

		/* Connect to the server, timing out */
		if ( setjmp(timeout) > 0 ) {
			fprintf(stderr, "Connection timed out\n");
			return(-1);
		}
		signal(SIGALRM, timedout);
		alarm(30);	      /* 30 second timeout */
		if ( connect(fd, (struct sockaddr *)&server, sizeof(server))
									< 0 ) {
			alarm(0);
			perror("Can't connect to server");
			return(-1);
		}
		alarm(0);

		/* Disable Nagle algorithm (don't buffer packets) */
		if ( setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &no_nagle, 
							sizeof(no_nagle)) < 0 )
			perror("Warning: Couldn't set socket options");
		return(fd);

	} else {		/* Create a server connection */

		/* Bind to our local address */
		memset(&server, 0, sizeof(server));
		server.sin_addr.s_addr = htonl(INADDR_ANY);
		server.sin_port = htons(port);
		server.sin_family = AF_INET;
		if (bind(fd, (struct sockaddr *)&server, sizeof(server)) < 0) {
			perror("Couldn't bind socket to local address");
			return(-1);
		}
		if ( listen(fd, 3) < 0 ) {
			perror("Couldn't set up listening on socket");
			return(-1);
		}

		/* Listen for any children so they don't become zombies */
		signal(SIGCLD, heaven);

		/* Now, wait for a connection
		   We return the file descriptor of the connection as a
		   child process.  The parent will never return.
		 */
		while ( 1 ) {
			int newfd;
			struct sockaddr_in client;
			int clilen;

			/* Accept the connection */
			clilen = sizeof(client);
			newfd = accept(fd, (struct sockaddr *)&client, &clilen);
			if ( newfd < 0 )
				continue;

			/* Return the file descriptor as a child */
			switch (fork()) {
				case 0:	 /* Child */
					/* Disable packet buffering */
					setsockopt(newfd, IPPROTO_TCP,
						TCP_NODELAY, &no_nagle, 
							sizeof(no_nagle));
					return(newfd);
					break;
				default:	/* Parent */
					close(newfd);
					break;
			}
#ifdef INTERACTIVE_CHAT
			/* Allow only one chat process at once */
			while ( wait(NULL) > 0 )
				/* Wait for the child */;
#endif
		}
		/* Never reached */
	}
	/* Never reached */
}


/* Execute a command string using execvp() */
void Execute(const char *cmdstr)
{
	/* Allow a maximum of 255 arguments */
	char *argv[256];
	int   argc;
	char *cmd, *run;

	/* Allocate a string we can chew */
	cmd = (char *)malloc(strlen(cmdstr)+1);
	if ( cmd == NULL ) {
		perror("Couldn't allocate command string");
		exit(255);
	}
	strcpy(cmd, cmdstr);

	/* tokenize the string */
	argc = 0;
	for ( run=cmd; *run; ) {
		while ( *run && isspace(*run) ) ++run;
		if ( *run && (argc < 255) )
			argv[argc++] = run;
		while ( *run && ! isspace(*run) ) ++run;
		if ( *run ) {
			*run = '\0';
			++run;
		}
	}
	argv[argc] = NULL;

	if ( argc == 0 ) {
		fprintf(stderr, "Execute() error: nothing to run\n");
		exit(255);
	}
	execvp(argv[0], argv);
	fprintf(stderr, "Couldn't execute '%s': ", cmd);
	perror("");
	exit(255);
}

/* Run the PPPD command and return a file descriptor to it */
int RunPPP(char *cmd, int *errfd)
{
	int cmdfd;
	int ptyfd;
	/* You'll have to modify the function if you change this string */
	static char ptyname[] = "/dev/ptyXY";
	static char ptychar[] = "pqrst";
	static char hexdigit[] = "0123456789abcdef";
	struct stat sb;
	int l, m, found;

#ifdef INTERACTIVE_CHAT
	/* Run as an interactive chat program, instead of PPP */
	return(open("/dev/tty", O_RDWR, 0));
#endif

	/* Allocate a pseudo tty */
	found = 0;
	for ( l=0; ptychar[l] && ! found; ++l ) {
		for ( m=0; hexdigit[m] && ! found; ++m ) {
			ptyname[8] = ptychar[l];
			ptyname[9] = hexdigit[m];
			/* Look for it */
			if ( stat(ptyname, &sb) < 0 )
				continue;
			/* Open the master */
			cmdfd = open(ptyname, O_RDWR, 0);
			if ( cmdfd < 0 )
				continue;
			/* Open the slave */
			ptyname[5] = 't';
			ptyfd = open(ptyname, O_RDWR, 0);
			if ( access(ptyname, R_OK|W_OK) < 0 ) {
				close(cmdfd);
				ptyname[5] = 'p';
				continue;
			}
			/* Yay! */
			found = 1;
		}
	}
	if ( ! found ) {
		fprintf(stderr, "Couldn't find a free pseudo-tty.\n");
		return(-1);
	}

	/* Get ready to clean any zombie children */
	signal(SIGCLD, heaven);

	/* Fork and run the program under the pseudo-tty */
	switch (fork()) {
		case -1:
			perror("Couldn't fork()");
			return(-1);
		case 0:
			/* Drop controlling tty */
			setsid();
			/* Open pty slave -- it becomes controlling terminal */
			ptyfd = open(ptyname, O_RDWR, 0);
			if ( ptyfd < 0 ) {
				fprintf(stderr, "Couldn't open slave pty!\n");
				exit(255);
			}
			/* Close master side of pty and route fds to slave */
			close(cmdfd);
			close(0); dup(ptyfd);
			close(1); dup(ptyfd);
			close(2);
			if ( errfd ) {
				dup(errfd[1]);
				close(errfd[0]);
				close(errfd[1]);
			} else
				dup(ptyfd);
			close(ptyfd);
			Execute(cmd);
			/* Not reached */
		default:
			/* Close slave side of pty and return channel */
			close(ptyfd);
			if ( errfd ) {
				close(errfd[1]);
				errfd[1] = -1;
			}
#ifdef DEBUG_PPPD
			fprintf(stderr, "Running PPPD: %s\n", cmd);
#endif
			return(cmdfd);
	}
	/* Not reached */
}


static void Usage(char *program)
{
	fprintf(stderr,
#ifdef PARANIOD_PPPTCP
	/* The keyring is not optional if we are paranoid */
	"Usage: %s -keyring <file> [hostname] portnum [-- <pppd options>]\n",
#else
	"Usage: %s [-keyring <file>] [hostname] portnum [-- <pppd options>]\n",
#endif
								program);
}

/* The main banana */
int main(int argc, char *argv[])
{
	int netfd, pppfd, errfd[2];
	int maxfd, i;
	char *hostname;
	char *portname;
	packet *pkt;
	int exitcode;

	/* Create an error pipe for the PPP process */
	if ( pipe(errfd) < 0 ) {
		perror("Couldn't create error pipe");
		exit(2);
	}

	/* Allocate memory for a packet with MTU approx. 1500-sizeof(tcphdr) */
	pkt = alloc_pkt(0);
	if ( (pkt == NULL) || (expand_pkt(pkt, 1456, 0) < 0) ) {
		perror("Couldn't create network packet");
		exitcode = 2;
		goto quit;
	}
	netfd = -1; pppfd = -1;

	/* Set up the default key:
		Match all hosts, set encryption off, and allow them.
	*/
	memset(&default_key, 0, sizeof(default_key));
	default_key.hostpat = "*";
	default_key.portpat = "*";
#ifdef PARANIOD_PPPTCP
	/* This should probably be the default */
	default_key.ppp_options = "deny";
#else
	default_key.ppp_options = "";
#endif

	/* Get command line arguments */
	keys = NULL;
	if ( (argc >= 3) && (strcmp(argv[1], "-keyring") == 0) ) {
		/* Load the keyring */
		keys = LoadKeys(argv[2]);
		if ( keys == NULL )
			printf("Warning: Empty keyring in %s\n", argv[2]);

		/* Slide the arguments over */
		argc -= 2;
		for ( i=1; argv[i+2]; ++i )
			argv[i] = argv[i+2];
		argv[i] = NULL;
	}
	ppp_cmd = NULL;
	for ( i=1; argv[i]; ++i ) {
		if ( strcmp(argv[i], "--") == 0 ) {
			int j, len;

			len = strlen(SBIN_PPPD);
			for ( j=i+1; argv[j]; ++j )
				len += (1+strlen(argv[j]));
			len += 1;
			ppp_cmd = (char *)malloc(len);
			if ( ppp_cmd == NULL ) {
				perror("Couldn't allocate space for ppp_cmd");
				exitcode = 4;
				goto quit;
			}
			strcpy(ppp_cmd, SBIN_PPPD);
			for ( j=i+1; argv[j]; ++j ) {
				strcat(ppp_cmd, " ");
				strcat(ppp_cmd, argv[j]);
			}
			argc = i;
			argv[argc] = NULL;
		}
	}
	if ( ppp_cmd == NULL ) {
		ppp_cmd = (char *)malloc(strlen(SBIN_PPPD)+1);
		if ( ppp_cmd == NULL ) {
			perror("Couldn't allocate space for ppp_cmd");
			exitcode = 4;
			goto quit;
		}
		strcpy(ppp_cmd, SBIN_PPPD);
	}
	switch (argc) {
		case 2:
			hostname = NULL;
			portname = argv[1];
			break;
		case 3:
			hostname = argv[1];
			portname = argv[2];
			break;
		default:
			Usage(argv[0]);
			exitcode = 1;
			goto quit;
	}
	/* The port should be numeric */
	if ( ! isdigit(*portname) ) {
		Usage(argv[0]);
		fprintf(stderr,
			"\tPort should be numeric, not '%s'\n", portname);
		exitcode = 1;
		goto quit;
	}

	/* Create network connection */
	netfd = Network(hostname, portname);
	if ( netfd < 0 ) {
		exitcode = 2;
		goto quit;
	}

	/* Check the keyring for a deny on this host */
	{
		char hostip[20];
		struct sockaddr_in remote;
		int                rlen;

		/* Get the IP address of the remote host */
		rlen = sizeof(remote);
		if (getpeername(netfd, (struct sockaddr *)&remote, &rlen) < 0) {
			perror("getpeername() failed");
			exitcode = 3;
			goto quit;
		}
		sprintf(hostip, "%u.%u.%u.%u",
				((unsigned char *)&remote.sin_addr.s_addr)[0],
				((unsigned char *)&remote.sin_addr.s_addr)[1],
				((unsigned char *)&remote.sin_addr.s_addr)[2],
				((unsigned char *)&remote.sin_addr.s_addr)[3]);
		fprintf(stderr, "Remote connection at %s\n", hostip);

		/* Look up the key for this host/port pair */
		current_key = FindKey(keys, hostip, atoi(portname));
		if ( current_key == NULL )
			current_key = &default_key;

		/* Check for deny */
		if (strcasecmp(current_key->ppp_options,"deny") == 0) {
			/* We matched a 'deny' rule */
			fprintf(stderr, "Connection not allowed in keyring\n");
			exitcode = 3;
			goto quit;
		}
	}

	/* Perform any authentication on the client here, timing out */
	if ( setjmp(timeout) > 0 ) {
		fprintf(stderr, "Authentication timed out\n");
		exitcode = 3;
		goto quit;
	}
	signal(SIGALRM, timedout);
	alarm(300);	      /* 5 minute timeout for authentication */
	if ( authenticate(hostname, netfd) < 0 ) {
		fprintf(stderr, "Authentication failed\n");
		exitcode = 3;
		goto quit;
	}
	alarm(0);

	/* Create PPP connection */
	if ( current_key && *(current_key->ppp_options) ) {
		free(ppp_cmd);
		ppp_cmd = (char *)
		 malloc(strlen(SBIN_PPPD)+1+strlen(current_key->ppp_options)+1);
		if ( ppp_cmd == NULL ) {
			perror("Couldn't allocate space for ppp_cmd");
			exitcode = 4;
			goto quit;
		}
		sprintf(ppp_cmd, "%s %s", SBIN_PPPD, current_key->ppp_options);
	}
	pppfd = RunPPP(ppp_cmd, errfd);
	if ( pppfd < 0 ) {
		close(netfd);
		exitcode = 2;
		goto quit;
	}

	/* Which is larger? */
	maxfd = ((netfd > pppfd) ? netfd : pppfd);
	maxfd = ((maxfd > errfd[0]) ? maxfd : errfd[0]);

	/* Link the two, passing data back and forth */
	while ( 1 ) {
		fd_set fdset;

		/* Wait for data */
		FD_ZERO(&fdset);
		FD_SET(netfd, &fdset);
		FD_SET(pppfd, &fdset);
		FD_SET(errfd[0], &fdset);
		if ( select(maxfd+1, &fdset, NULL, NULL, NULL) < 0 )
			break;

		/* Check for errors from pppd */
		if ( FD_ISSET(errfd[0], &fdset) ) {
			char errmesg[BUFSIZ];
			int  errlen;

			errlen = read(errfd[0], errmesg, BUFSIZ-1);
			if ( errlen > 0 ) {
				errmesg[errlen] = '\0';
				fprintf(stderr, "%s", errmesg);
			}
		}

		/* Always check network connection first */
		if ( FD_ISSET(netfd, &fdset) ) {
			/* Read, decrypt, write */
			if ( read_pkt(netfd, pkt) < 0 )
				break;  /* End of transmission */
			if ( packet_decrypt(pkt) < 0 )
				break;  /* Decryption failure? */
			if ( writen(pppfd, pkt->buf, pkt->len) < 0 )
				break;  /* Write error */
		}
		/* If the network connection is still alive.. */
		if ( FD_ISSET(pppfd, &fdset) ) {
			int  len;

			/* Read, encrypt, write */
			len = read(pppfd, pkt->buf, pkt->maxlen);
			if ( len <= 0 )
				break;  /* End of transmission */
			pkt->len = len;
			if ( packet_encrypt(pkt) < 0 )
				break;  /* Encryption failure? */
			if ( write_pkt(netfd, pkt) < 0 )
				break;  /* Write error */
		}
	}
quit:
	free_pkt(pkt);
	if ( netfd >= 0 )
		close(netfd);
	if ( pppfd >= 0 )
		close(pppfd);
	if ( ppp_cmd )
		free(ppp_cmd);
	if ( errfd[0] >= 0 )
		close(errfd[0]);
	if ( errfd[1] >= 0 )
		close(errfd[0]);
	DestroyKeys(keys);
	exit(exitcode);
}
