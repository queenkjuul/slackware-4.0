#!/bin/sh
#
# Run ppptcp in client mode in the background while monitoring both
# the network and the process, restarting ppptcp if either go down.

# Set the path
PATH="/sbin:/usr/sbin:/bin:/usr/bin:."
export PATH

respawn=1
respawn_delay=15

Usage="
Usage: $0 [--respawn[=N]] [--delay=N]
			[-keyring <file>] host port [-- pppd options]
"

# Function to check network connectivity
function network_ok
{
	remote_host=$1
	num_packets="5"

	# The ping command needs to be modified for your system
	# - Linux
	ping="ping -c $num_packets $remote_host"
	# - HPUX
	#ping="ping $remote_host -n $num_packets"
	# - SunOS and Solaris
	#ping="ping $remote_host"

	$ping >/dev/null
}
# Function to check if ppptcp has died (remote connection killed?)
function ppptcp_ok
{
	ppptcp_pid=$1

	kill -0 $ppptcp_pid 2>/dev/null
}

# Parse command-line options
while [ $# -gt 0 ]
do case $1 in
	--ppptcp=*)
		# Set the location of ppptcp
		ppptcp=`echo $1 | awk -F= '{print $2}'`
		;;
	--respawn*)
		# Respawn ppptcp
		respawn_count=`echo $1 | awk -F= '{print $2}'`
		if [ "$respawn_count" = "" ]; then
			respawn_count=0
		fi
		shift
		;;
	--delay=*)
		# Amount of time between restarts of ppptcp
		respawn_delay=`echo $1 | awk -F= '{print $2}'`
		shift
		;;
	*)	# ppptcp options -- verify
		if [ "$1" = "-keyring" ]; then
			if [ "$2" = "" ]; then
				echo "$Usage" >&2
				exit 1
			fi
			keyring_opts="$1 $2";
			shift; shift;
		fi
		if [ "$1" != "" -a "$1" != "--" ]; then
			host=$1; shift
		fi
		if [ "$1" != "" -a "$1" != "--" ]; then
			port=$1; shift
		fi
		if [ "$1" != "" -a "$1" != "--" ]; then	
			echo "$Usage" >&2
			exit 1
		fi
		pppd_opts="$*"
		while [ $# -gt 0 ]; do shift; done
		;;
   esac
done

# Check for host and port
if [ "$host" = "" -o "$port" = "" ]; then
	echo "$Usage" >&2
	exit 1
fi

# Try to find ppptcp
if [ "$ppptcp" = "" ]; then
	# 'which' doesn't reliably return errors :-/
	ppptcp=`which ppptcp 2>/dev/null | awk '{print $1}' | fgrep "/"`
fi
if [ "$ppptcp" = "" ]; then
	echo "Couldn't find ppptcp in $PATH" >&2
	exit 1
fi

# Check the network initially
if ! network_ok $host; then
   echo "The network connection to $host is currently down."
   echo "- waiting for it to come back up..."
   while ! network_ok $host;
   do sleep 10;
   done
fi

# Run ppptcp in the background
ppptcp_cmd="$ppptcp $keyring_opts $host $port $pppd_opts"
date
echo "Starting PPPTCP"
echo "$ppptcp_cmd"
$ppptcp_cmd & child=$!

# Monitor the network and ppptcp
while [ $respawn -gt 0 ];
do sleep $respawn_delay

   # Check network connectivity
   if ! network_ok $host; then
	while ! network_ok $host;
	do sleep 10;
	done
	kill $child
   fi

   # Check to see if ppptcp is running
   if ! ppptcp_ok $child; then
	if [ "$respawn_count" != "" ]; then
		if [ $respawn_count -gt 0 ]; then
			respawn_count=`expr $respawn_count - 1`
			if [ $respawn_count -eq 0 ]; then
				respawn_count=""
			fi
		fi
	else
		respawn=0
	fi
	if [ $respawn -gt 0 ]; then
		date
		echo "Restarting PPPTCP"
		$ppptcp_cmd & child=$!
	fi
   fi
done
