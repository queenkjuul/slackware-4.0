/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* A network packet structure */
typedef struct packet {
	char   *buf;		/* The data in the packet */
	twobyte len;		/* The amount of data in buf */
	twobyte maxlen;		/* The max data that can be stored in buf */
} packet;


/* Allocate a new packet, with length 0 and maximum length 'len' */
extern packet * alloc_pkt(twobyte len);

/* Expand a the maximum length of a packet to 'len' */
extern int expand_pkt(packet *pkt, twobyte len, int savedata);

/* Allocate and return a duplicate of the given packet */
extern packet *copy_pkt(packet *in);

/* Set the buf of the packet to a malloc'd buffer */
extern void setbuf_pkt(packet *pkt, char *buf, twobyte len);

/* Free a used packet */
extern void free_pkt(packet *pkt);

/* Read/Write N bytes from a file descriptor */
extern int readn(int fd, char *buf, twobyte len);
extern int writen(int fd, char *buf, twobyte len);

/* Read/Write a packet to/from a TCP socket */
extern int read_pkt(int fd, packet *pkt);
extern int write_pkt(int fd, packet *pkt);
