
/* PUBLIC DOMAIN

This is Andrew Welch's implementation of a random function, modified for PPPTCP.
It has been placed in the public domain by Andrew Welch.

Andrew Welch : andrew@ambrosiasw.com
*/

/* If 'Seed' is zero, a seed is created based on the current time and pid */
extern fourbyte SeedRandom(fourbyte Seed);

/* Get the current four byte random seed */
extern fourbyte GetRandSeed(void);

/* Return a random number in the range 0-'range' */
extern twobyte FastRandom(twobyte range);

