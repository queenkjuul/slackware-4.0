/*
    PPPTCP -- an implementation of PPP over TCP, with possible encryption.

    Copyright (C) 1997  Sam Lantinga		(slouken@devolution.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* Routines to load and work with a keyring in memory */

#include <stdio.h>
#include <ctype.h>
#include "keyring.h"
#include "wildcard.h"


/* Load a single key from the keyring */
/*
The general format of the client's keyring file is as follows:

# Comment
remotehost:remoteport [pppd options]
# Comment
Public Key
# Comment
Private Key
##
... more records of the same format ...
*/
static char *eatcomments(char *buf, int len, FILE *fp, int *lineno)
{
	do {
		buf = fgets(buf, len, fp);
		if ( buf && lineno )
			++(*lineno);
	} while ( buf && (*buf == '#') );
	return(buf);
}
static char *readkey(char *buf, int len, FILE *fp, int *lineno)
{
	char *line, *key;

	/* Read the key */
	key = NULL;
	line = eatcomments(buf, len, fp, lineno);
	if ( line && (*line != '\r') && (*line != '\n') ) {
		do {
			char *memptr;

			/* Copy in the line */
			if ( key != NULL ) {
				memptr = key;
				key = (char *)
					malloc(strlen(memptr)+strlen(line)+1);
				if ( key )
					strcpy(key, memptr);
				free(memptr);
			} else {
				key = (char *)malloc(strlen(line)+1);
				if ( key )
					*key = '\0';
			}
			if ( key == NULL ) {
				perror("Warning: Can't allocate key");
				return(NULL);
			}
			strcat(key, line);

			/* Trim trailing whitespace */
			memptr=(key+strlen(key));
			for ( --memptr; isspace(*memptr); --memptr )
				*memptr = '\0';

			/* Read next line */
			line = fgets(buf, len, fp);
			if ( line && lineno )
				++*lineno;
		} while ( line && 
			(*line != '#') && (*line != '\r') && (*line != '\n') );
	}
	return(key);
}
static keyring *LoadKey(FILE *keyfp, int *lineno)
{
	keyring *ring;
	char     buf[BUFSIZ];
	char *line, *offset;

	/* Allocate space for the keyring */
	ring = (keyring *)malloc(sizeof(keyring));
	if ( ring == NULL ) {
		perror("Can't allocate keyring");
		return(NULL);
	}
	memset(ring, 0, sizeof(keyring));

	/* Read the host/port pattern and pppd options */
	do {
		line = eatcomments(buf, BUFSIZ-1, keyfp, lineno);
	} while ( line && ((*line == '\r') || (*line == '\n')) );
	if ( line == NULL ) {	/* EOF at the beginning of a key */
		DestroyKeys(ring);
		return(NULL);
	}
	offset = (char *)strchr(line, ':');
	if ( offset == NULL ) {
		fprintf(stderr, "Error parsing keyfile (line %d):\n", *lineno);
		fprintf(stderr,
			"\tExpected 'remotehost:remoteport [pppd options]'\n");
		DestroyKeys(ring);
		return(NULL);
	}

	/* Copy the options and drop them into the keyring */
	ring->hostpat = (char *)malloc(strlen(line)+1);
	if ( ring->hostpat == NULL ) {
		perror("Can't allocate keyring");
		DestroyKeys(ring);
		return(NULL);
	}
	strcpy(ring->hostpat, line);
	offset = (ring->hostpat+(offset-line));
	*(offset++) = '\0';	/* NULL terminate the host pattern */
	ring->portpat = offset;
	while ( *offset && !isspace(*offset) ) ++offset;
	*(offset++) = '\0';	/* NULL terminate the port pattern */
	if ( ! *ring->portpat ) {
		fprintf(stderr, "Error parsing keyfile (line %d):\n", *lineno);
		fprintf(stderr,
			"\tExpected 'remotehost:remoteport [pppd options]'\n");
		DestroyKeys(ring);
		return(NULL);
	}
	while ( *offset && isspace(*offset) ) ++offset;
	ring->ppp_options = offset;
	if ( *offset ) {	/* Strip trailing whitespace */
		offset += strlen(offset);
		for ( --offset; isspace(*offset); --offset )
			*offset = '\0';
	}

	/* Read the public and private keys */
	ring->public_key = readkey(buf, BUFSIZ-1, keyfp, lineno);
	ring->private_key = readkey(buf, BUFSIZ-1, keyfp, lineno);
	return(ring);
}

keyring *LoadKeys(char *keyfile)
{
	FILE *keyfp;
	keyring *keys, *lastkey, *nextkey;
	int lineno;

	/* Open the keyring */
	keyfp = fopen(keyfile, "r");
	if ( keyfp == NULL ) {
		fprintf(stderr, "Couldn't open %s: ", keyfile);
		perror("");
		return(NULL);
	}
	lineno = 0;

	/* Load all the keys */
	keys = NULL;
	while ( ! feof(keyfp) ) {
		nextkey = LoadKey(keyfp, &lineno);
		if ( nextkey == NULL )
			break;

		/* Add the key to the keyring */
		if ( keys == NULL )
			keys = lastkey = nextkey;
		else {
			lastkey->next = nextkey;
			lastkey = nextkey;
		}
	}
	if ( ! feof(keyfp) ) {
		DestroyKeys(keys);
		keys = NULL;
	}
	fclose(keyfp);
	return(keys);
}

keyring *FindKey(keyring *ring, char *host, int port)
{
	char port_s[128];

	sprintf(port_s, "%d", port);
	while ( ring ) {
		if ( wildmatch(host, ring->hostpat) &&
					wildmatch(port_s, ring->portpat) ) {
			ring->hostport = port;
			strcpy(ring->hostip, host);
			return(ring);
		}
		ring = ring->next;
	}
	return(NULL);
}

void DestroyKeys(keyring *ring)
{
	if ( ring == NULL )
		return;

	/* Free everything and destroy the next key in the ring */
	if ( ring->hostpat )	/* memory chunk holds portpat and ppp_options */
		free(ring->hostpat);
	if ( ring->public_key )
		free(ring->public_key);
	if ( ring->private_key )
		free(ring->private_key);
	DestroyKeys(ring->next);
	ring->next = NULL;		/* Try to minimize reuse errors */
	free(ring);
}
