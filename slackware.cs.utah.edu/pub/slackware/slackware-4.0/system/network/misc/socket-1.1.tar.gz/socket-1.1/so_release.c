char *so_release () {
  static char release[] = "Socket-1.1 (Wed Sep  9 19:11:19 1992 by nickel@cs.tu-berlin.de)";
  return release;
}
