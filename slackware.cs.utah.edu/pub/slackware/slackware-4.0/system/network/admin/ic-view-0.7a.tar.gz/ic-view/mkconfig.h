# Linux

CC=gcc
CCFLAG=-O -fpic
LDFLAG=-O -s
AR=ar rs
RANLIB=touch
XINCLUDE=-I/usr/X11R6/include
SYSLIB=-lXpm -L/usr/X11R6/lib -lX11 -lm
