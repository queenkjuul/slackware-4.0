#ifndef FD_ic_view_about_h_
#define FD_ic_view_about_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void XForms_LIB(FL_OBJECT *, long);
extern void GNU_GPL(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *ic_view_about;
	FL_OBJECT *XForms;
	FL_OBJECT *GNU_GPL;
	FL_OBJECT *Text;
	void *vdata;
	long ldata;
} FD_ic_view_about;

extern FD_ic_view_about * create_form_ic_view_about(void);

#endif /* FD_ic_view_about_h_ */
