/* Form definition file generated with fdesign. */

#include "forms.h"
#include "ic-view-about.h"

FD_ic_view_about *create_form_ic_view_about(void)
{
  FL_OBJECT *obj;
  FD_ic_view_about *fdui = (FD_ic_view_about *) fl_calloc(1, sizeof(FD_ic_view_about));

  fdui->ic_view_about = fl_bgn_form(FL_NO_BOX, 550, 300);
  obj = fl_add_box(FL_UP_BOX,0,0,550,300,"");
  obj = fl_add_text(FL_NORMAL_TEXT,150,220,250,30,"CopyRight (C) 1996  Timur Fanshteyn");
    fl_set_object_color(obj,FL_COL1,FL_ORCHID);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,150,250,250,40,"IC-View v.7a");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
    fl_set_object_lstyle(obj,FL_TIMES_STYLE+FL_EMBOSSED_STYLE);
  fdui->XForms = obj = fl_add_button(FL_NORMAL_BUTTON,330,190,190,30,"Based on XForms Library");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);
    fl_set_object_callback(obj,XForms_LIB,0);
  fdui->GNU_GPL = obj = fl_add_button(FL_NORMAL_BUTTON,30,190,190,30,"Pretected by GNU GPL");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);
    fl_set_object_callback(obj,GNU_GPL,0);
  fdui->Text = obj = fl_add_browser(FL_NORMAL_BROWSER,30,50,490,130,"");
  obj = fl_add_button(FL_NORMAL_BUTTON,130,10,280,30,"Back to  IC-View");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESBOLD_STYLE);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

