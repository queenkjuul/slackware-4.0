#include "forms.h"
#include "ic-view-about.h"

FD_ic_view_about *fd_ic_view_about;	/* Form definition */

void XForms_LIB(FL_OBJECT *obj, long arg)
{
  fl_clear_browser(fd_ic_view_about->Text);
  fl_add_browser_line(fd_ic_view_about->Text,"All GUI in this program is done using ");
  fl_add_browser_line(fd_ic_view_about->Text,"XForms Library (C) T.C. ZHao and Mark Overmars");
  fl_add_browser_line(fd_ic_view_about->Text,"To get your copy of the library, please see");
  fl_add_browser_line(fd_ic_view_about->Text,"ftp://bloch.phys.uwm.edu/pub/xforms or");
  fl_add_browser_line(fd_ic_view_about->Text,"ftp://ftp.cs.ruu.nl/pub/XFORMS");
}

void GNU_GPL(FL_OBJECT *obj, long arg)
{
  fl_clear_browser(fd_ic_view_about->Text);
  fl_add_browser_line(fd_ic_view_about->Text,"This program is FREE software, you can redistribute it and/or modify it under ");
  fl_add_browser_line(fd_ic_view_about->Text,"it under the terms of the GNU General Public License as published by");
  fl_add_browser_line(fd_ic_view_about->Text,"the Free Software Foundation. This program is distributed in the hope");
  fl_add_browser_line(fd_ic_view_about->Text,"that it will be useful, but WITHOUT ANY WARRANTY; without even the");
  fl_add_browser_line(fd_ic_view_about->Text,"implied warranty of MERCHANTABILITY  or FITNESS FOR A PARTICULAR ");
  fl_add_browser_line(fd_ic_view_about->Text,"PURPOSE. See the GNU General Public License for more details");

  fl_add_browser_line(fd_ic_view_about->Text," ");

  fl_add_browser_line(fd_ic_view_about->Text,"You should have received a copy of the GNU General Public License");
  fl_add_browser_line(fd_ic_view_about->Text,"along with this program; if not, write to the Free Software Foundation, Inc.");
  fl_add_browser_line(fd_ic_view_about->Text,"675 Mass Ave, Cambridge, MA 02139, USA.");
}

void start_ic_about()
{
  fd_ic_view_about = create_form_ic_view_about();
  
  fl_set_browser_fontsize(fd_ic_view_about->Text,FL_NORMAL_SIZE);
  fl_clear_browser(fd_ic_view_about->Text);
  fl_show_form(fd_ic_view_about->ic_view_about, FL_PLACE_SIZE, FL_FULLBORDER, "IC View v.1.0");
  fl_do_forms();
  fl_hide_form(fd_ic_view_about->ic_view_about);
}


