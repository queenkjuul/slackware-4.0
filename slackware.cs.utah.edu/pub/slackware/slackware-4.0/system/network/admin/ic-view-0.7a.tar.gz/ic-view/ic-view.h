#ifndef FD_ic_view_h_
#define FD_ic_view_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void empty_callback(FL_OBJECT *, long);
extern void GType_callback(FL_OBJECT *, long);
extern void DType_callback(FL_OBJECT *, long);
extern void main_menu_callback(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *ic_view;
	FL_OBJECT *Chart;
	FL_OBJECT *Browser;
	FL_OBJECT *GType;
	FL_OBJECT *Monthly;
	FL_OBJECT *Weekly;
	FL_OBJECT *Daily;
	FL_OBJECT *DType;
	FL_OBJECT *dText;
	FL_OBJECT *dChart;
	FL_OBJECT *Main;
	FL_OBJECT *Date;
	FL_OBJECT *HitCount;
	FL_OBJECT *TotPercent;
	FL_OBJECT *BestDay;
	FL_OBJECT *BestWeek;
	FL_OBJECT *BestMonth;
	FL_OBJECT *SiteName;
	FL_OBJECT *StartDate;
	FL_OBJECT *TotalCount;
	void *vdata;
	long ldata;
} FD_ic_view;

extern FD_ic_view * create_form_ic_view(void);

#endif /* FD_ic_view_h_ */
