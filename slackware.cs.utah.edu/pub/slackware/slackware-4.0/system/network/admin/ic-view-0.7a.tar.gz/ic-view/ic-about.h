#ifndef __IC_VIEW_ABOUT__
#define __IC_VIEW_ABOUT__

void start_ic_about();

#endif
