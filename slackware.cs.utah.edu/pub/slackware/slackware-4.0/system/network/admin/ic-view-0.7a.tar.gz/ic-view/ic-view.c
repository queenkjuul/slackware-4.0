/* Form definition file generated with fdesign. */

#include "forms.h"
#include "ic-view.h"

FD_ic_view *create_form_ic_view(void)
{
  FL_OBJECT *obj;
  FD_ic_view *fdui = (FD_ic_view *) fl_calloc(1, sizeof(FD_ic_view));

  fdui->ic_view = fl_bgn_form(FL_NO_BOX, 920, 540);
  obj = fl_add_box(FL_BORDER_BOX,0,0,920,540,"");
  fdui->Chart = obj = fl_add_chart(FL_BAR_CHART,20,50,570,380,"Site Activity");
    fl_set_object_boxtype(obj,FL_SHADOW_BOX);
    fl_set_object_color(obj,FL_CYAN,FL_DARKVIOLET);
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE+FL_ENGRAVED_STYLE);
  fdui->Browser = obj = fl_add_browser(FL_MULTI_BROWSER,20,50,570,380,"Site Activity");
    fl_set_object_lsize(obj,FL_HUGE_SIZE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,empty_callback,0);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,630,170,260,170,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,630,350,260,90,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,630,450,260,70,"");
    fl_set_object_color(obj,FL_COL1,FL_DARKGOLD);
  obj = fl_add_text(FL_NORMAL_TEXT,650,240,80,30,"Best Day:");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,630,490,260,30,"Statistics for");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_frame(FL_SHADOW_FRAME,430,490,150,40,"");
  obj = fl_add_frame(FL_SHADOW_FRAME,150,490,240,40,"");

  fdui->GType = fl_bgn_group();
  fdui->Monthly = obj = fl_add_roundbutton(FL_RADIO_BUTTON,310,500,80,20,"Monthly");
    fl_set_object_color(obj,FL_MCOL,FL_DOGERBLUE);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,GType_callback,2);
  fdui->Weekly = obj = fl_add_roundbutton(FL_RADIO_BUTTON,230,500,70,20,"Weekly");
    fl_set_object_color(obj,FL_MCOL,FL_DOGERBLUE);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,GType_callback,1);
  fdui->Daily = obj = fl_add_roundbutton(FL_RADIO_BUTTON,160,500,80,20,"Daily");
    fl_set_object_color(obj,FL_MCOL,FL_DOGERBLUE);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,GType_callback,0);
  fl_end_group();


  fdui->DType = fl_bgn_group();
  fdui->dText = obj = fl_add_roundbutton(FL_RADIO_BUTTON,510,500,60,20,"Text");
    fl_set_object_color(obj,FL_MCOL,FL_DOGERBLUE);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,DType_callback,1);
  fdui->dChart = obj = fl_add_roundbutton(FL_RADIO_BUTTON,440,500,80,20,"Chart");
    fl_set_object_color(obj,FL_MCOL,FL_DOGERBLUE);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,DType_callback,0);
  fl_end_group();

  fdui->Main = obj = fl_add_menu(FL_PULLDOWN_MENU,20,490,100,40,"Main");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,main_menu_callback,0);
  obj = fl_add_text(FL_NORMAL_TEXT,650,380,80,30,"Hit Count:");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,650,350,80,30,"Total %:");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,650,180,80,30,"Best Month:");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,650,210,80,30,"Best Week:");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_box(FL_FLAT_BOX,630,130,80,20,"Sunday");
    fl_set_object_color(obj,FL_WHITE,FL_LEFT_BCOL);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_box(FL_FLAT_BOX,720,130,80,20,"Monday");
    fl_set_object_color(obj,FL_CYAN,FL_LEFT_BCOL);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_box(FL_FLAT_BOX,810,130,80,20,"Tuesday");
    fl_set_object_color(obj,FL_MAGENTA,FL_LEFT_BCOL);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_box(FL_FLAT_BOX,630,90,80,20,"Wednsday");
    fl_set_object_color(obj,FL_BLUE,FL_LEFT_BCOL);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_box(FL_FLAT_BOX,720,90,80,20,"Thursday");
    fl_set_object_color(obj,FL_YELLOW,FL_LEFT_BCOL);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_box(FL_FLAT_BOX,810,90,80,20,"Friday");
    fl_set_object_color(obj,FL_GREEN,FL_LEFT_BCOL);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_box(FL_FLAT_BOX,720,50,80,20,"Saterday");
    fl_set_object_color(obj,FL_RED,FL_LEFT_BCOL);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,650,410,80,30,"Date:");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  fdui->Date = obj = fl_add_text(FL_NORMAL_TEXT,730,410,160,30,"Monday, 10/10/1996");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->HitCount = obj = fl_add_text(FL_NORMAL_TEXT,730,380,160,30,"100");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->TotPercent = obj = fl_add_text(FL_NORMAL_TEXT,730,350,160,30,"10.32 %");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->BestDay = obj = fl_add_text(FL_NORMAL_TEXT,730,240,150,30,"Wednsday, 1/1/1996");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->BestWeek = obj = fl_add_text(FL_NORMAL_TEXT,730,210,150,30,"10/10/1996");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->BestMonth = obj = fl_add_text(FL_NORMAL_TEXT,730,180,150,30,"October 1996");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->SiteName = obj = fl_add_text(FL_NORMAL_TEXT,640,460,240,30,"My Home Page");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER);
  obj = fl_add_text(FL_NORMAL_TEXT,650,300,80,30,"Log Started:");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  fdui->StartDate = obj = fl_add_text(FL_NORMAL_TEXT,730,300,150,30,"Monday, 10/10/1996");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  obj = fl_add_text(FL_NORMAL_TEXT,650,270,80,30,"Total Count::");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  fdui->TotalCount = obj = fl_add_text(FL_NORMAL_TEXT,730,270,150,30,"1324");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

