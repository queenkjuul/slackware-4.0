#include <time.h>

#define ic_error_cantopen 1
#define ic_error_wrongheader 2

struct st_rec {
  struct tm dt;
  long count;
  struct st_rec *next;
};

typedef struct st_rec *st_rec_p;

int check_file(FILE **f, char *fname);
int get_accnt_name(FILE *f, char *accntname);
int create_slist(FILE *f, st_rec_p *stlist, char *error);
int empty_list(st_rec_p *slist);

