
/*
** Distributed with 'dig' version 2.0 from University of Southern
** California Information Sciences Institute (USC-ISI). 9/1/90
*/

/*
#define PARAMH	 "param.h"
*/
#define PARAMH   <sys/param.h>


/*
#define RESOLVH  <resolv.h>
#define RESOLVH  <arpa/resolv.h>
#define NAMESERH <arpa/nameser.h>
*/
#define RESOLVH  "resolv.h"
#define NAMESERH "nameser.h"

/*
#define NETDBH   <netdb.h>
*/
#define NETDBH   "netdb.h"

