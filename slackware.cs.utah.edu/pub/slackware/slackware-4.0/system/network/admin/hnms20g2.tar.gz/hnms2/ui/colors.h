/*
 *
 *	color.h
 *
 *	Colormap for HNMS user interface.
 *
 *	HNMS User Interface
 *	Version 2.0
 *
 *	February 1994
 *
 *	Leslie Schlecht
 *	Computer Sciences Corporation
 *	Numerical Aerodynamic Simulation Systems Division
 *	NASA Ames Research Center
 *
 *	Copyright (c) 1994 Leslie Schlecht
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#define		RED_COMPONENT	0
#define		GREEN_COMPONENT	1
#define		BLUE_COMPONENT	2

unsigned	int	colors[][3] = 	{
			{	0,	0,	0},	/* black */
			{   25000,  25000,  25000},	/* grey */
			{   60000,  60000,  60000},	/* white */
			{   60000,	0,	0},	/* red */
			{	0,  60000,	0},	/* green */
			{   60000,  60000,	0},	/* yellow */
			{   60000,	0,  60000},	/* magenta */
			{	0,	0,  60000},	/* blue */
			{	0,  60000,  60000},	/* cyan */
			{   60000,  40000,      0},	/* orange */
			{       0,	0,  39000},	/* violet */
			{       0,	0,  46000},	/* violet */
			{       0,	0,  53000},	/* violet */
			{	0,      0,  60000},	/* blue */
			{	0,   4000,  60000},	/* blue */
			{	0,  11000,  60000},	/* blue */
			{	0,  18000,  60000},	/* blue */
			{	0,  25000,  60000},	/* blue */
			{	0,  32000,  60000},	/* blue */
			{	0,  39000,  60000},	/* blue */
			{	0,  46000,  60000},	/* blue */
			{	0,  53000,  60000},	/* blue */
			{	0,  60000,  60000},	/* cyan */
			{	0,  60000,  53000},	/* cyan */
			{	0,  60000,  46000},	/* cyan */
			{	0,  60000,  39000},	/* cyan */
			{	0,  60000,  32000},	/* cyan */
			{	0,  60000,  25000},	/* cyan */
			{	0,  60000,  18000},	/* cyan */
			{	0,  60000,  11000},	/* cyan */
			{	0,  60000,   4000},	/* cyan */
			{	0,  60000,	0},	/* green */
			{    4000,  60000,	0},	/* green */
			{   11000,  60000,	0},	/* green */
			{   18000,  60000,	0},	/* green */
			{   25000,  60000,	0},	/* green */
			{   32000,  60000,	0},	/* green */
			{   39000,  60000,	0},	/* green */
			{   46000,  60000,	0},	/* green */
			{   53000,  60000,	0},	/* green */
			{   60000,  60000,	0},	/* yellow */
			{   60000,  53000,	0},	/* yellow */
			{   60000,  46000,	0},	/* yellow */
			{   60000,  39000,	0},	/* yellow */
			{   60000,  32000,	0},	/* yellow */
			{   60000,  25000,	0},	/* yellow */
			{   60000,  18000,	0},	/* yellow */
			{   60000,  11000,	0},	/* yellow */
			{   60000,   4000,	0},	/* yellow */
			{   60000,	0,	0},	/* red */
			{   53000,	0,	0},	/* red */
			{   46000,	0,	0},	/* red */
			{   39000,	0,	0},	/* red */
			};
