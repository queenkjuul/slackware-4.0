/*\
 *	DISTRIBUTION: HNMS v2.0
 *	FILE: hnmslib/stdhnms.h
 *
 *	Standard #includes for hnms code.
 *
 *	Jude George
 *	NAS Facility, NASA Ames Research Center
 *
 *	Copyright (c) 1994 Jude George
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
\*/

#include <ppkt.h>
#include <psap.h>
#include <UNIV-types.h>

#include "HNMP-types.h"

/*\
 *  Do not alter the order of the includes.
\*/
#ifndef OIDS_H
#define OIDS_H
#include "oids.h"
#endif
#ifndef ALLOC_H
#define ALLOC_H
#include "alloc.h"
#endif
#ifndef PARAM_H
#define PARAM_H
#include "param.h"
#endif
#ifndef HNMPDEFS_H
#define HNMPDEFS_H
#include "hnmpdefs.h"
#endif
#ifndef SESSION_H
#define SESSION_H
#include "session.h"
#endif
#ifndef PRESENTATION_H
#define PRESENTATION_H
#include "presentation.h"
#endif
#ifndef PEER_H
#define PEER_H
#include "peer.h"
#endif
#ifndef HNMSDEFS_H
#define HNMSDEFS_H
#include "hnmsdefs.h"
#endif
#ifndef HNMS_H
#define HNMS_H
#include "hnms.h"
#endif
#ifndef OBJ_H
#define OBJ_H
#include "obj.h"
#endif
#ifndef MIBDEFS_H
#define MIBDEFS_H
#include "mibdefs.h"
#endif
#ifndef MIB_H
#define MIB_H
#include "mib.h"
#endif
#ifndef AUX_H
#define AUX_H
#include "aux.h"
#endif
#ifndef CONSTANTS_H
#define CONSTANTS_H
#include "constants.h"
#endif
