/*\
 *	DISTRIBUTION: HNMS v2.0
 *	FILE: hnmslib/param.h
 *
 *	Prototypes for hnmslib/param.c.
 *
 *	Jude George
 *	NAS Facility, NASA Ames Research Center
 *
 *	Copyright (c) 1994 Jude George
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
\*/

int PARAM_init();
void PARAM_set_pe();
void PARAM_set_int();
void PARAM_set_str();
PE PARAM_get_pe();
int PARAM_get_int();
char *PARAM_get_str();
void PARAM_unset();
void PARAM_iterate();
void PARAM_print();
