/*\
 *	DISTRIBUTION: HNMS v2.0
 *	FILE: hnmslib/obj.h
 *
 *	Prototypes for hnmslib/obj.c.
 *
 *	Jude George
 *	NAS Facility, NASA Ames Research Center
 *
 *	Copyright (c) 1994 Jude George
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
\*/

char *OBJ_make_uname();
int OBJ_add();
int OBJ_delete();
int OBJ_exists();
int OBJ_find();
int OBJ_find_by_vbl();
char *OBJ_get_uname();
int OBJ_get_agent_id();
const VarBindList OBJ_get_vbl();
const PE OBJ_get();
const PE OBJ_set();
int OBJ_set_list();
int OBJ_set_hnmsvars();
int OBJ_unset();
void OBJ_iterate();
void OBJ_print();
void OBJ_print_all();
