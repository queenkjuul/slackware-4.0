/*
 *
 *	servercomm.h
 *
 *	HNMS User Interface
 *	HNMS 2.0
 *
 *	February 1994
 *
 *	Leslie Schlecht
 *	Computer Sciences Corporation
 *	Numerical Aerodynamic Simulation Systems Division
 *	NASA Ames Research Center
 *
 *	Copyright (c) 1994 Leslie Schlecht
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

void	CancelConnect();
int	CloseHNMP();
void	ConfigureServerPanel();
void	CreateServerPanel();
void	HNMP_open_callback();
void	HNMP_close_callback();
void	HNMP_Message_process();
void	HNMS_err();
void	InitializeHNMP();
char*	i2s();
void	LoadServerHostFile();
void	LogStatistics();
int	OpenHNMP();
void	OpenServerPanel();
void	RemoveConnect();
void	RestartConnect();
void	SaveServerPanel();
void	SelectConnect();
void	ServerConnect();
void	ServerEvent();
void	SetQueueCount();
void	StartConnect();
void	SubHNMPData();
void	SubHNMPRelations();
void	TryConnect();
void	UnsubHNMPData();
void	UnsubHNMPRelations();
void	UpdateServerPanel();
