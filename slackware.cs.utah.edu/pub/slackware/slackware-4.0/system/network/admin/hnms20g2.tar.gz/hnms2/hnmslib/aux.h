/*\
 *	DISTRIBUTION: HNMS v2.0
 *	FILE: hnmslib/aux.h
 *
 *	Prototypes for hnmslib/aux.c.
 *
 *	Miscellaneous auxiliary functions for HNMS.
 *
 *	Jude George
 *	NAS Facility, NASA Ames Research Center
 *
 *	Copyright (c) 1994 Jude George
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
\*/

PE pe_create_null();
unsigned int fixed_prim2num();
OID fixed_str2oid();
struct qbuf *int2qb();
int qb2int();
char *ipaddr_pe2str();
PE ipaddr_int2pe();
int ipaddr_pe2int();
char *ipaddr_int2str();
int oid_cmp_n();
int oid_cmp_tree();
int oid_is_hnms();
unsigned int get_int_time();
char *time_int2str();
void time_int2hms();
void time_str2tm();
void date_str2tm();
