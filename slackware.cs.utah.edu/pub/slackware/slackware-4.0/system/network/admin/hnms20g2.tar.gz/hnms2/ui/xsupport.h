/*
 *
 *	xsupport.h
 *
 *	HNMS User Interface
 *	HNMS 2.0
 *
 *	February 1994
 *
 *	Leslie Schlecht
 *	Computer Sciences Corporation
 *	Numerical Aerodynamic Simulation Systems Division
 *	NASA Ames Research Center
 *
 *	Copyright (c) 1994 Leslie Schlecht
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

int	AllocateStatusColors();
void	Beep();
void	ClockTick();
int	ColorScreen();
void	DestroyX();
void	FindShell();
void	FlashIt();
void	GetShellDimensions();
int	InitializeX();
void	InitializePixmaps();
Pixmap	GetPixmap();
XtWorkProcId	LaunchProc();
void	MainLoop();
Widget	MakeShell();
void	PostPopupMenu();
void	RaiseWidget();
void	SetBeep();
void	SetShellDimensions();
void	SetShellLocation();
void	TimerProc();
int	WidgetColor();
void	WorkProc();
void	SetWorkProc();
Widget	labeled_list();
Widget	labeled_text();
Widget	pbutton();
Widget	cbutton();
void	TextGainFocus();
void	TextLoseFocus();
int	GetColor();
void	FreePixmap();
void	ClearBitmap();
void	BitmapLines();
void	CopyPixmap();
Pixmap	CreateBitmap();
Pixmap	CreatePixmap();
void	SetColor();
void	SetLineWidth();
void	SetBackgroundColor();
void	CopyBitmap();
void	ClearXQ();
void	ClearWindow();
int	ScreenWidth();
int	ScreenHeight();
void	DrawArrowHead();
void	DrawCircle();
void	DrawArc();
void	DrawDot();
void	DrawLine();
void	DrawBlock();
void	StrToList();
int	FontAscent();
void	SetFont();
void	DrawAngledText();
void	DrawText();
int	GetTextExtents();
int	TextWidth();
void	WidgetPixmap();
