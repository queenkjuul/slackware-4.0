/*\
 *	DISTRIBUTION: HNMS v2.0
 *	FILE: hnmslib/constants.h
 *
 *	Externs for printable strings for HNMS.
 *
 *	Jude George
 *	NAS Facility, NASA Ames Research Center
 *
 *	Copyright (c) 1994 Jude George
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
\*/

extern const char	*hnms_err_strs[];
extern const char	*hnmp_msg_strs[];
extern const char	*if_types[];
extern const char	*rt_types[];
extern const char	*rt_protocols[];
extern const char	*status_strs[];
extern const char	*obj_class_names[];
extern const char	*module_type_strs[];
