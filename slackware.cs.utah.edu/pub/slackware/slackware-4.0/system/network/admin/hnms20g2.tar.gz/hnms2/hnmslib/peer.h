/*\
 *	DISTRIBUTION: HNMS v2.0
 *	FILE: hnmslib/peer.h
 *
 *	Prototypes for hnmslib/peer.c.
 *
 *	Jude George
 *	NAS Facility, NASA Ames Research Center
 *
 *	Copyright (c) 1994 Jude George
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
\*/

int PEER_connect_server();
int PEER_open();
int PEER_close();
int PEER_welcome();
int PEER_announce_object();
int PEER_announce_one_to_all();
int PEER_announce_all_to_one();
int PEER_send_data();
int PEER_send_relations();
int PEER_delete_one_to_all();
int PEER_unsub_object();
int PEER_add_sub();
int PEER_drop_sub();
int PEER_add_rel_sub();
int PEER_drop_rel_sub();
const VarBindList PEER_get_sub();
const VarBindList PEER_get_sub_out();
int PEER_fill_subs();
int PEER_fill_rel_subs();
int PEER_merge_subs();
