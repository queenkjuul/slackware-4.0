/*\
 *	DISTRIBUTION: HNMS v2.0
 *	FILE: hnmslib/presentation.h
 *
 *	Prototypes for hnmslib/presentation.c.
 *
 *	Jude George
 *	NAS Facility, NASA Ames Research Center
 *
 *	Copyright (c) 1994 Jude George
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
\*/

Message Message_create();
int Message_set();
caddr_t Message_get();
void Message_free();
void Message_print();
const PE VarBindList_get();
const PE VarBindList_getnext();
const PE VarBindList_set();
int VarBindList_unset();
const PE VarBindList_walk();
int VarBindList_mergelists();
int VarBindList_subtractlists();
int VarBindList_cmplists();
VarBindList VarBindList_copylist();
VarBindList VarBindList_copylist_null();
void VarBindList_free();
void VarBindList_iterate();
void VarBindList_print();
