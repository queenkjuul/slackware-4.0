/*\
 *	DISTRIBUTION: HNMS v2.0
 *	FILE: hnmslib/session.h
 *
 *	Prototypes for hnmslib/session.c.
 *
 *	Jude George
 *	NAS Facility, NASA Ames Research Center
 *
 *	Copyright (c) 1994 Jude George
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 1, or (at your option)
 *	any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program; if not, write to the Free Software
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
\*/

int HNMP_init();
int HNMP_open();
int HNMP_Message_enqueue();
void HNMP_close();
int HNMP_send();
int HNMP_sessions();
int HNMP_listen();
int HNMP_printstats();
