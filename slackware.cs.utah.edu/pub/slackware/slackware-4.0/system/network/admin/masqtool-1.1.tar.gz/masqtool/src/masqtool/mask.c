#include <stdio.h>

int masking(char *netmask)
{
   int x=0,y=0;

   if ( strtok(netmask,".") )
   {
      x=atoi(netmask);
      if (x != 0)
      {
         while ( x != 1 )
         {
            if ( (x % 2) == 1)
               y++;
            x=(x/2);
         }
         y++;
      }

      (int)netmask=strtok(NULL,".");
      x=atoi(netmask);
      if (x != 0)
      {
         while ( x != 1 )
         {
            if ( (x % 2) == 1)
               y++;
            x=(x/2);
         }
         y++;
      }
   
      (int)netmask=strtok(NULL,".");
      x=atoi(netmask);
      if (x != 0)
      {
         while ( x != 1 )
         {
            if ( (x % 2) == 1)
               y++;
            x=(x/2);
         }
         y++;
      }

      (int)netmask=strtok(NULL,".");
      x=atoi(netmask);
      if (x != 0)
      {
         while ( x != 1  )
         {
            if ( (x % 2) == 1)
               y++;
            x=(x/2);
         }
         y++;
      }
   }   
   return y;
}
