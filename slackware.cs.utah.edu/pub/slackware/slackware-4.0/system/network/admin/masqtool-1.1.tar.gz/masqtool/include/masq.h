struct sendmasq {
#ifdef client
   WINDOW *winhandle;
   WINDOW *frame1;
   WINDOW *frame2;
   WINDOW *frame3;
   int    LINES;
   int    COLUMNS;
   char   hostmasqd[128];
   int    hostport;
#endif
   char   msqlHOST[128];
   char   DBname[128];
   char   currentsrcprot[4];
   char   currentsrcaddr[16];
   char   currentsrcmask[16];
   int    currentsrcport;
   char   dest[16];
   char   dest_mask[16];
   int    dest_port;
   char   masq_file[128];
   int    current;
   int    f1current;
   int    f2current;
   int    totalhosts;
   int    desthosts;
   int    frame;
};

typedef struct sendmasq sendmasq;

void protocol(sendmasq *m1);
void source(sendmasq *m1,int hn);
void source_mask(sendmasq *m1);
void source_port(sendmasq *m1);
void dest(sendmasq *m1,int hn);
void dest_mask(sendmasq *m1);
void dest_port(sendmasq *m1);

int trunkreaddata(sendmasq *m1);
int branchread(sendmasq *m1);
int deleterec(sendmasq *m1);
int insertrec(sendmasq *m1);
void createfile(sendmasq *m1);
void drawscreen(sendmasq *m1);
void selecthost(sendmasq *m1);
void hostmasqd(sendmasq *m1);
void hostport(sendmasq *m1);
void dbname(sendmasq *m1);
void createdb(sendmasq *m1);
