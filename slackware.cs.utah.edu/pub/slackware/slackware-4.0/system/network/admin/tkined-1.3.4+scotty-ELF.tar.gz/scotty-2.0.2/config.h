/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Handcrafted version -- autoheader is too magic.  */

/* Define if we want to debug memory problems */
/* #undef TCL_MEM_DEBUG */

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef WORDS_BIGENDIAN */

/* Define if we should include the SNMP extension.  */
#define HAVE_SNMP 1

/* Define if we should support the SNMP USEC SNMPv2 version.  */
/* #undef SNMP_USEC */

/* Define if we should include the BONES extension.  */
/* #undef HAVE_BONES */

/* Define if we should include the OSIMIS extension.  */
/* #undef HAVE_OSIMIS */

/* Define if we should include the GDMO extension.  */
/* #undef HAVE_GDMO */

/* Define if we should include the extended Tcl extension.  */
/* #undef HAVE_TCLX */

/* Define if we should include the tcl interface to the msql database.  */
/* #undef HAVE_MSQL */

/* Define if you have the getmntent function.  */
#define HAVE_GETMNTENT 1

/* Define if you have IP multicast support.  */
#define HAVE_MULTICAST 1

/* Define if we have gethostent.  */
#define HAVE_GETHOSTENT 1

/* Define if you have the getnetent function.  */
#define HAVE_GETNETENT 1

/* Define if you have the getprotoent function.  */
#define HAVE_GETPROTOENT 1

/* Define if you have the getservent function.  */
#define HAVE_GETSERVENT 1

/* Define if you have the getrpcent function.  */
#define HAVE_GETRPCENT 1

/* Define if we have struct rpcent.  */
#define HAVE_RPCENT 1

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H 1

/* Define if you have the <sys/select.h> header file.  */
/* #undef HAVE_SYS_SELECT_H */
