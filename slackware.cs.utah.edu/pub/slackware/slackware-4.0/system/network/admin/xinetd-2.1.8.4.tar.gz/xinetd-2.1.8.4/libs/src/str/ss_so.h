/*
 * (c) Copyright 1992, 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */

#ifndef SS_SO_H
#define SS_SO_H

/*
 * $Id: ss_so.h,v 3.1 1993/06/13 02:46:47 panos Exp $
 */

struct so_header
{
	wide_int *mask ;
	wide_int offset_mask ;
} ;

#endif 	/* SS_SO_H */
