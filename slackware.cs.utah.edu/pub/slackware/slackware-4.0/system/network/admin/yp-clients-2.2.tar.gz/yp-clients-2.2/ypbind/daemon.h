/* 
 * $Log: daemon.h,v $
 * Revision 1.1  1995/07/25 14:27:37  swen
 * ypbind version 2.0.
 *
 * Revision 2.2  1995/01/24  12:24:23  swen
 * Added RCS keywords.
 *
 */

extern void daemon_start(void);
