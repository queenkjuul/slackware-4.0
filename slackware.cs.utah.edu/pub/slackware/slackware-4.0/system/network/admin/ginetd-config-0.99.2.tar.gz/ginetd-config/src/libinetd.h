/*
 * libinetd.h
 * headers of the 3 main function of the libraries.
 * Copyright (c) 1999, Bruno Clermont <kain@linuxbox.com>.
 */
#ifndef __LIBINETD_H__

#define __LIBINETD_H__

/* if the apps run uid root the output file is /etc/inetd.conf and the
   backup file is /etc/inetd.conf.bak
   whenever else the output file (inetd.conf and inetd.conf.bak)
   is in the user's home directory (like "/home/joe/inetd.conf" ) */

/* call it to save the result of the service list */
extern void inetd_config_save( void );
/* restore the backup */
extern void inetd_config_revert( void );

/* the main part, it return a vbox, so just pack it where you want, like :
   gtk_container_add( GTK_CONTAINER( misc_frame ), gui_inetd() ); */
extern GtkWidget *inetd_config_gui( void );

/* to quit it, just destroy the widget, but restoring the backup file
   can be usefull */

#endif