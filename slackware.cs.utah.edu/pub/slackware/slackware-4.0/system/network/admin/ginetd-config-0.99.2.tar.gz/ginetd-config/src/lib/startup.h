/*
 * lib/startup.h
 * header of the startup function, and the name of the filename used to save
 * the inetd.conf file is it run at a users uid
 * Copyright (c) 1999, Bruno Clermont <kain@linuxbox.com>.
 */
#ifndef __STARTUP__

#define __STARTUP_H__

#include<glib.h>

extern gchar *FileNameOriginal, *FileNameBackup;

GString *startup_check( void );

#endif