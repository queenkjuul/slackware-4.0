/*
 * lib/gui_event.h
 * definition of the event called by widget
 * Copyright (c) 1999, Bruno Clermont <kain@linuxbox.com>.
 */
#ifndef __GUI_EVENT_H__

#define __GUI_EVENT_H__

#include<gtk/gtk.h>

void unselect( void );
void clist_selection( GtkWidget *, gint, gint, GdkEventButton *, gpointer );
void clist_unselection( GtkWidget *, gint, gint, GdkEventButton *, gpointer );
void button_clicked_server( void );
void button_clicked_argument( void );
void button_clicked_save( void );
void button_clicked_edit( void );
void button_clicked_new( void );
void button_clicked_remove( void );
void button_toggle_wait( void );
void button_toggle_rpc( void );

#endif