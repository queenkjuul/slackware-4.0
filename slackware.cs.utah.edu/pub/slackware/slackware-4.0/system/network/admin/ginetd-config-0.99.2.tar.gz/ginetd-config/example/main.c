/*
 * example of incorporate inetd-config in someone else apps
 */
#include<gtk/gtk.h>

/* put the correct path of the headers file */
#include"../src/libinetd.h"

int main( int argc, char *argv[] )
{
    GtkWidget *window;

    gtk_init( &argc, &argv );

    window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    gtk_signal_connect( GTK_OBJECT( window ), "destroy",
                        GTK_SIGNAL_FUNC( gtk_main_quit ), NULL );
    gtk_window_set_title( GTK_WINDOW( window ), "Inetd Config");

  /* inetd_config_gui() return a vbox, just pack it, or add it somewhere
     and destroy the parent or the widget to quit it, but dont
     forget to restore the backup file with inetd_config_revert() before */
      gtk_container_add( GTK_CONTAINER( window ), inetd_config_gui() );

    gtk_widget_show( window );

    gtk_main();

  return 0;
}