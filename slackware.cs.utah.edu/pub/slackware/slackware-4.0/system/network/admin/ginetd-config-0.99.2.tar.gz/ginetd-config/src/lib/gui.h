/*
 * lib/gui.h
 * definition of all manipulable widget
 * Copyright (c) 1999, Bruno Clermont <kain@linuxbox.com>.
 */
#ifndef __GUI_H__

#define __GUI_H__

#include<gtk/gtk.h>

extern GtkWidget *EntryServer, *EntryArgument, *SpinButtonWait, *HBoxWait,
                 *CheckButtonRPC, *CheckButtonEnable, *CheckButtonWait,
		 *ComboServicesName, *ComboSocketsType, *ComboProtocols,
		 *ComboUsers, *ComboGroups, *ComboRPC, *CListServices,
		 *FrameEditService, *HBoxButtons, *HBoxVersion, *EntryVersion;

GtkWidget *inetd_config_gui( void );

#endif