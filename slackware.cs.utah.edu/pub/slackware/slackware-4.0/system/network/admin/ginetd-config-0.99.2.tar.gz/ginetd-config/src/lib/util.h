/*
 * lib/util.h
 * headers of the various usefull functions of util.c
 * Copyright (c) 1999, Bruno Clermont <kain@linuxbox.com>.
 */
#ifndef __UTIL_H__

#define __UTIL_H__

#include<glib.h>

GString *clean( GString *, gboolean );
GString *get_word( GString *, guint );
GString *find_services_port( GString * );
GString *g_list_item( GList *, guint );

GList *load_raw_file( gchar *, gboolean );
GList *load_file( gchar * );

gboolean if_numeric( GString * );

#endif