/*
 * lib/inetd_conf.h
 * headers of the function of reading, and saving of the inetd.conf file
 * Copyright (c) 1999, Bruno Clermont <kain@linuxbox.com>.
 */
#ifndef __INETD_CONF_H__

#define __INETD_CONF_H__

#include<gtk/gtk.h>

void parse_inetd_conf( GtkWidget * );
void save_inetd_conf( gchar * );
#endif