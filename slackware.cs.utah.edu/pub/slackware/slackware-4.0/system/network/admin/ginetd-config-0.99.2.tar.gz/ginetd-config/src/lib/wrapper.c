/*
 * lib/wrapper.c
 * link beetween other apps, and the core of inetd-config
 * Copyright (c) 1999, Bruno Clermont <kain@linuxbox.com>.
 */
#include"inetd_conf.h"
#include"startup.h"
#include"gui.h"
#include<stdio.h>

void inetd_config_save( void )
{
  if( CListServices != NULL )
    save_inetd_conf( FileNameOriginal );
}

void inetd_config_revert( void )
{
  remove( FileNameOriginal );
  rename( FileNameBackup, FileNameOriginal );
}