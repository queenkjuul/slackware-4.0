LOGTIME 1.21	Linux and Windows time logging facility
Copyright (c) 1996 by Christopher S L Heng. All rights reserved.
----------------------------------------------------------------

$Id: readme.txt 1.10 1996/10/05 17:39:41 chris Exp $ /*


This is the README file for installing and upgrading the Windows version
of LOGTIME. Read the README.Linux (readme.lin) file for the installation
and upgrading information on the Linux version of LOGTIME.


CONTENTS
--------

INTRODUCTION
GUIDE TO DOCUMENTATION
INSTALLING FOR WINDOWS
UPGRADING FROM A PREVIOUS VERSION
WHERE TO GET THE LATEST VERSION
CONTACTING THE AUTHOR



INTRODUCTION
------------

LOGTIME was designed to allow users to keep track of the amount of time
taken and the charges accumulated when logging into an internet service
provider ("ISP"). This might be useful if you use an ISP that charges
you for the time you take when logged onto your account.

For a better idea of LOGTIME's features, see the online help file
LOGTIME.HLP. If you have not installed LOGTIME, you can read it by
running "winhelp logtime.hlp" from Program Manager. If you have already
installed LOGTIME, you can simply press the F1 key.



GUIDE TO DOCUMENTATION
----------------------

Where to find information about:

Installing/Upgrading for Windows		readme.txt
Installing/Upgrading for Linux			README.Linux (or
						readme.lin)

What's New in this version			whatsnew.txt
List of files in this package			packing.lst
Licensing/Copying terms				license.txt

How to Configure and Use Logtime for Windows	logtime.hlp
How to Use Logtime for Linux			logtime.1

To read the logtime.hlp file, either run "winhelp logtime.hlp" from
the Program Manager in Windows or press the F1 key after installing
LOGTIME for Windows.

To read the logtime.1 file, either install the Linux version of
LOGTIME per the instructions in the README.Linux (or readme.lin) file
and run "man logtime" after the installation, or temporarily copy
logtime.1 to your manual directory and run "man logtime".



INSTALLING FOR WINDOWS
----------------------

1. Copying the files into a directory

To install LOGTIME for Windows, simply copy all the LOGTIME files into a
directory on your hard disk.

For example, if you wish to place LOGTIME in the C:\LOGTIME directory of
your hard disk, simply create the directory C:\LOGTIME (you may do this
under DOS by typing "MKDIR \LOGTIME" while you are at the C:\> prompt)
and copy all the LOGTIME files into that directory (you may do this
under DOS by typing "COPY *.* C:\LOGTIME" if your current directory
contains the only the LOGTIME files).

2. Configuring your winsock dialler

Next you will need to find some way so that LOGTIME is executed each
time you connect to and disconnect from your Internet Service Provider
("ISP"). If you run a winsock package that executes a script file, place
a call to

	logtime -b

in your login script file when there is a successful login; and a call
to

	logtime -e

in your logout script file when your winsock program logs off from the
ISP. You will have to put the full path name of the location where you
placed LOGTIME if you did not put LOGTIME in a directory on your path.
For example, you may have to use "c:\logtime\logtime" instead of "logtime"
in the above examples. The -b parameter tells LOGTIME starts the clock to
time the session, and the -e parameter instructs LOGTIME stops the timer.

Please note that your dialler may require you to prefix the above
command line with a specific script command to inform it to execute an
external program. Please read your dialler's documentation for more
information about this.

If you use Trumpet winsock 2.1f, I am told that the exact command is

	exec c:\\logtime\\logtime -b

to start the logging (if you installed logtime in c:\logtime); and

	exec c:\\logtime\\logtime -e

to stop the logging (again, this example assumes that you installed
logtime in c:\logtime). Substitute the correct path for your system.
Note that Trumpet requires that you place two backslashes for each
backslash in your directory specification, so if you want
d:\logtime\logtime, you need to specify d:\\logtime\\logtime.

If your winsock package does not execute script files, you need to
invoke LOGTIME manually each time you log in and log out. It might be
convenient to associate an item in a Program Manager group with the
command

	c:\logtime\logtime -b

and place the text "Begin logging" as the description for that item; and
an item for the command

	c:\logtime\logtime -e

and place the text "End logging" for the description for that item. Again,
you should substitute the correct path in place of c:\logtime if you
installed LOGTIME elsewhere.

This way, each time you get a successful connection with your winsock
dialer, just double-click the "Begin logging" icon in your Program
Manager to start the logging; and once you log out, double-click the
"End logging" icon in your Program Manager.

This is rather inconvenient, but this is probably the only way of doing
it with the current version of LOGTIME. You probably have to do it this
way if you use Chameleon Sampler 3.X as your Internet dialler.

3. Adding a LOGTIME icon to the Program Manager

You should add a LOGTIME icon to a group in your Program Manager. This
will allow you to check your usage log, print results, maintain the log
file and otherwise configure LOGTIME. Note that this item should be a
separate item from the "Begin logging" and "End logging" items you
created above (if at all) and it should not have the "-b" or "-e"
parameters.

4. Using LOGTIME on both Windows and Linux

If you wish to share the same configuration and data files for both your
Linux and Windows system, install LOGTIME for Windows and its
accompanying files to a directory that is mounted by Linux. In your
Linux SLIP/PPP script, specify that directory using the -D option to the
Linux logtime . For more information about this, see the file README.Linux
(or readme.lin).

5. Configuring LOGTIME

Please note that you must configure LOGTIME before you can use it in any
meaningful way. Run LOGTIME and type F1 and go to the How to Configure
LOGTIME for more details.

6. Testing LOGTIME

Run your dialler and log into your ISP. If you did not configure your
dialler to run LOGTIME, or your dialler did not have a script capability
for you to use to execute LOGTIME, you should start the LOGTIME logging
facility by double-clicking the "Begin logging" icon installed in the
above instructions. After your successfully login, read your mail or
news or whatever you wish to do, and log out. Again, if LOGTIME is not
automatically invoked on logging out by your script, invoke it manually
by clicking the "End logging" icon created above.

Once you have logged out, you can run LOGTIME by clicking the LOGTIME
icon created above. Press the first (leftmost) button on the button bar,
or choose the Current month item from the File menu. If you have correctly
installed and configured LOGTIME, the Usage Log displayed should show
the amount of time and charges you accumulated in your last session.



UPGRADING FROM A PREVIOUS VERSION
---------------------------------

Before upgrading, make sure that no version of LOGTIME is currently
running. If a LOGTIME window is open, close it before upgrading.

You can upgrade your Windows version of LOGTIME by simply copying 
the files in this version into the directory where you installed the 
previous version.

You may want to read the WHATSNEW.TXT file for a list of new features in 
this release and configure LOGTIME to take advantage of the new facilities,
if any. To configure LOGTIME, start the program and use the Options menu.
You can invoke the online help for more information about the options
available.



WHERE TO GET THE LATEST VERSION
-------------------------------

At present, I upload new versions of LOGTIME to the following sites:
	ftp://ftp.simtel.net/pub/simtelnet/win3/telecomm/
	ftp://ftp.winsite.com/pub/pc/win3/winsock/

The filename is of the form "ltXXX.zip" where XXX stands for the version
number with the decimal points removed. For example, version 1.21 of
LOGTIME will be uploaded with a filename of "lt121.zip" (without the
quotes).

I also try to update my home page with the latest information about
LOGTIME. If you wish to know which is the latest version, you can always
check out
	http://www.singnet.com.sg/~cyfheng/

My ISP is sometimes down, so if you are unable to connect to the site,
just try again later.

I often try to upload LOGTIME to sunsite.unc.edu too. However, I find
it difficult to connect to sunsite to upload the file, so the copy
of LOGTIME on sunsite may not always be the latest. You can find the
tar.gz version of LOGTIME there. The contents of the tar archive are
identical with those in the zip archive; only the archiving method is
different.
	ftp://sunsite.unc.edu/pub/Linux/system/Serial/

The filename has the format "logtime-X.XX.tar.gz", where X.XX is the
version number of LOGTIME. For example, version 1.21 of LOGTIME will
be uploaded as "logtime-1.21.tar.gz" (without the quotes).



CONTACTING THE AUTHOR
---------------------

If you wish to contact me about LOGTIME , you may email me on the
Internet via one of the addresses given below (if one of the addresses
fail, try the other). Please note that while I generally would like to
hear from you if you are using the program, and I certainly would like
to know if you discover any bugs in the program, I am under no
obligation to fix any bugs. In fact, I make no promises about even
replying.

My current internet email addresses and web page:
	cyfheng@singnet.com.sg
	ChristopherHeng@pobox.org.sg
	http://www.singnet.com.sg/~cyfheng/

Please furnish me the following information when emailing (even if
you are simply emailing me to request new features). This will enable
me to answer your questions/problems/requests more relevantly.

1.	The version of LOGTIME you are using, eg Version 1.21.
2.	The platform (or platforms) on which you are running LOGTIME:
	ie whether Windows or Linux or both.
3.	If you are running LOGTIME on Windows, include the name and
	the version number of the winsock package that you are using
	(eg Chameleon, Trumpet, etc).
4.	If you are running LOGTIME on Linux, indicate whether you are
	using it with PPP or SLIP.
5.	Any other information that might be relevant.

