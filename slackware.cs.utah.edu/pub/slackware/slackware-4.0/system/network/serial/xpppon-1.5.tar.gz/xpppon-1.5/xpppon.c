/*
   xpppon Copyright (c) 1997 James Bailie
   ==================================================================
   
   xpppon is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2, or (at
   your option) any later version.

   xpppon is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   Although xpppon is licensed under the Free Software
   Foundation's GNU General Public License, xpppon is not produced
   by, nor is it endorsed by the Free Software Foundation. The Free
   Software Foundation is not responsible for developing,
   distributing, or supporting Xpppon in any way. Anyone may place
   software they own the copyright to, under the GNU General Public
   License.

   The GNU General Public License is included in the xpppon 
   distribution archive in a file called COPYING. If you do
   not have a copy of the license, you can download one from
   ftp://prep.ai.mit.edu, or you can write to the Free Software
   Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

   =====================================================================
*/

#include "EZ.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define BUFFER_SIZE 256

EZ_Widget *grid, *frame, *listbox, *exit_button, *kill_button,
    *on_button, *off_button;

int messages_fd;
FILE *messages = NULL;

char line_buffer[ BUFFER_SIZE ], second_buffer[ BUFFER_SIZE ],
    log_file[ BUFFER_SIZE ];
const char *name = "xpppon";

void file_callback( EZ_Input *input, void *data, int fd, int mask )
{
    char *line_pointer;
    
    strcpy( second_buffer, line_buffer );
    if ( fgets( line_buffer, BUFFER_SIZE, messages ) == NULL )
	    return;

    if ( !strcmp( line_buffer, second_buffer ))
        return;

    if ( strstr( second_buffer, "assword:" ) &&
         strstr( line_buffer, "send (" ))
        {
            line_pointer = strrchr( line_buffer, '(' );

            while( *( ++line_pointer ) != ')' )
                *line_pointer = '*';

        }

    EZ_AppendListBoxItem( listbox, line_buffer );
    EZ_ListBoxSelectItem( listbox, line_buffer );

    return;
}

void ppp_off_callback( EZ_Widget *widget, void *data )
{
    system( "ppp-off" );
    return;
}

void ppp_on_callback( EZ_Widget *widget, void *data )
{
    system( "ppp-on" );
    return;
}

void escape_hatch( EZ_Widget *widget, void *data )
{
    EZ_Shutdown();
    exit( EXIT_SUCCESS );
}

void kill_callback( EZ_Widget *widget, void *data )
{
    unsigned pid;
    char *line_pointer, local_buffer[ BUFFER_SIZE ];

    strcpy( local_buffer, line_buffer );
    if ((( line_pointer = strstr( local_buffer, "chat" )) != NULL ) ||
        (( line_pointer = strstr( local_buffer, "pppd" )) != NULL ))
    {
        line_pointer = line_pointer + 5;
        pid = atoi( strtok( line_pointer, "]" ));
        sprintf( local_buffer, "kill %d", pid );
        system( local_buffer );
    }

    return;
}

int main( int argc, char **argv[] )
{
    EZ_Initialize( argc, (char **)argv, 0 );
    EZ_DisableSliderDepression();
    
    grid = EZ_CreateWidget( EZ_WIDGET_GRID_BAG, NULL,
			    EZ_HEIGHT, 175,
			    EZ_WIDTH, 500,
			    EZ_GRID_CONSTRAINS, EZ_ROW, 0, 75, 10, 10,
			    EZ_GRID_CONSTRAINS, EZ_ROW, 1, 20, 1, 0,
			    EZ_GRID_CONSTRAINS, EZ_COLUMN, 0, 100, 1, 10,
			    EZ_FILL_MODE, EZ_FILL_BOTH,
			    0 );

    listbox = EZ_CreateWidget( EZ_WIDGET_LIST_BOX, grid,
			       EZ_GRID_CELL_GEOMETRY, 0, 0, 1, 1,
			       EZ_GRID_CELL_PLACEMENT, EZ_FILL_BOTH, EZ_CENTER,
                               0 );

    frame = EZ_CreateFrame( grid, NULL );

    EZ_ConfigureWidget( frame,
			EZ_GRID_CELL_GEOMETRY, 0, 1, 1, 1,
			EZ_GRID_CELL_PLACEMENT, EZ_FILL_BOTH, EZ_CENTER,
			EZ_FILL_MODE, EZ_FILL_BOTH,
			0 );
    
    exit_button = EZ_CreateWidget( EZ_WIDGET_NORMAL_BUTTON, frame,
                                   EZ_HEIGHT, 20,
                                   EZ_WIDTH, 60,
                                   EZ_LABEL_STRING, "exit",
                                   EZ_CALLBACK, escape_hatch,
                                   0 );

    kill_button = EZ_CreateWidget( EZ_WIDGET_NORMAL_BUTTON, frame,
                                   EZ_HEIGHT, 20,
                                   EZ_WIDTH, 60,
                                   EZ_LABEL_STRING, "kill",
                                   EZ_CALLBACK, kill_callback,
                                   0 );

    on_button = EZ_CreateWidget( EZ_WIDGET_NORMAL_BUTTON, frame,
                                 EZ_HEIGHT, 20,
                                 EZ_WIDTH, 60,
                                 EZ_LABEL_STRING, "ppp-on",
                                 EZ_FOREGROUND, "ForestGreen",
                                 EZ_CALLBACK, ppp_on_callback,
                                 0 );
    
    off_button = EZ_CreateWidget( EZ_WIDGET_NORMAL_BUTTON, frame,
                                  EZ_HEIGHT, 20,
                                  EZ_WIDTH, 60,
                                  EZ_LABEL_STRING, "ppp-off",
                                  EZ_FOREGROUND, "DarkRed",
                                  EZ_CALLBACK, ppp_off_callback,
                                  0 );

    if ( argc < 2 )
        strcpy( log_file, "/var/log/messages" );
    else
        strcpy( log_file, ( char *)argv[ 1 ] );

    line_buffer[ 0 ] == second_buffer[ 0 ] == '\0';

    if (( messages_fd = open( log_file, O_RDONLY )) == -1 )
    {
        perror( name );
        exit( EXIT_FAILURE );
    }

    if (( messages = fdopen( messages_fd, "r" )) == NULL )
    {
        perror( name );
        exit( EXIT_FAILURE );
    }

    if ( fseek( messages, -256, SEEK_END ) == -1 )
    {
        perror( name );
        exit( EXIT_FAILURE );
    }

    fgets( line_buffer, BUFFER_SIZE, messages );
    
    EZ_AddInput( messages_fd, EZ_READABLE_MASK, file_callback, NULL );
    EZ_SetApplicationName( "xpppon 1.5" );
    EZ_DisplayWidget( grid );
    EZ_EventMainLoop();

    /* not reached */
    return 0;
}
