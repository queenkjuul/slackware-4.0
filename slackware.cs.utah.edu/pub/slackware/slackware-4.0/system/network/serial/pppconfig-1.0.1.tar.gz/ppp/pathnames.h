/*
 * pathnames	This file contains the definitions of the path names used
 *		by the NET base distribution.  Do not change the values!
 *
 * Version:	@(#)pathnames.h	1.30	09/06/93
 *
 * Author:	Fred N. van Kempen, <waltje@uwalt.nl.mugnet.org>
 */



#ifdef FSSTND
#define _PATH_DIP_PID		"/var/run/bmdial.pid"
#define _PATH_LOCKD		"/var/lock"	        /* lock files	*/
#else
#define _PATH_DIP_PID		"/etc/bmdial.pid"
#define _PATH_LOCKD		"/usr/spool/uucp"	/* lock files	*/
#endif

/* This one is outdated - now locks are owned by whoever invoked DIP */
#define _UID_UUCP		"uucp"			/* owns locks	*/

/* End of pathnames.h */
