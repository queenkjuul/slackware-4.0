/*
 * dip		A program for handling dialup IP connecions.
 *		Handle the process of going into the background.
 *
 * Version:	@(#)daemon.c	3.3.3	08/16/93
 *
 * Author:      Fred N. van Kempen, <waltje@uWalt.NL.Mugnet.ORG>
 *		Copyright 1988-1993 MicroWalt Corporation
 *
 * Modified:    Uri Blumenthal, <uri@watson.ibm.com>
 *              Copyright 1994
 *
 *		Paul Cadach, <paul@paul.east.alma-ata.su>
 *		(C) 1994
 *
 *		This program is free software; you can redistribute it
 *		and/or  modify it under  the terms of  the GNU General
 *		Public  License as  published  by  the  Free  Software
 *		Foundation;  either  version 2 of the License, or  (at
 *		your option) any later version.
 */
#include "dip.h"

static int forked = 0;
static int catched = 0;
static int do_exit = 0;

extern int tty_lock(char *path, int mode);
static void (*oldalrmsig)(int);

/* Catch any signals. */
static void
sig_catcher(int sig)
{
  /* Don't let SIGHUP from terminal bother us here */
if (opt_v)
  fprintf(stderr, "sig_catcher();\n");
  (void) signal(SIGHUP, SIG_IGN); 

  (void) signal (SIGALRM, oldalrmsig);
  alarm (0);

#ifdef NE_PAUL
  (void) tty_close();
#else
  (void) cleanup();
#endif
  exit(0);
}


/* Record the current processID in a file. */
static void
dip_record(void)
{
  FILE *fp;

if (opt_v)
  fprintf(stderr, "dip_record ();\n");
  fp = fopen(_PATH_DIP_PID, "w");
  if (fp == NULL) {
    syslog(LOG_ERR, "DIP: cannot create %s: %s\n",
	   _PATH_DIP_PID, strerror(errno));
    fprintf(stderr, "DIP: cannot create %s: %s\n",
	    _PATH_DIP_PID, strerror(errno));
    return;
  }
  fprintf(fp, "%d", getpid());
  (void) fclose(fp);
}


int
dip_daemon(struct dip *dip)
{
  int i;

  /* First of all, if not forked yet - fork off a sub-process. */
if (opt_v)
  fprintf(stderr, "dip_daemon ();\n");
  if (!forked) {
    if ((i = fork()) < 0) return(-1);
    if (i != 0) exit(0);
  } 

  /* Make tty the control terminal, detect DCD loss from now. */
  if ((i = tty_notlocal()) < 0)
  	return i;

  if (!forked) {

    /* Record our PID. */
    dip_record();
 
    for (i = 0; i < 3; i++)
	close(i);

    /* Disable screen output... */
    (void) open("/dev/null", O_RDONLY);  /* stdin  */
    (void) open("/dev/null", O_WRONLY);  /* stdout */
    (void) dup(1);                       /* stderr */

    /* Make the IP address visible via "ps" command */
    setproctitle("-bmdial");

    /* Re-acquire the lock */
    (void)tty_lock("no_matter", 2);

    forked = 1;
    while (1)
      sleep(100);
  }

  return(1);
}
