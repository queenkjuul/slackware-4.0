#include "dialtty.h"
#include "config.h"


int main(int argc, char *argv[])
{
  if (argc == 2)
    switch(argv[1][0])
      {  case 'r':
	   printf("%d", RING_COUNT);
           break;

         case 'd':
	   printf("%o", DEBUG_MODE);
	   break;

         case 'i':
	   {  char*  s;
	      for(s = INIT_STR; *s; s++)
		switch(*s)
		  {  case '&':
		       printf("\\&");
		       break;
		     case '/':
		       printf("\\/");
		       break;
		     case '\\':
		       printf("\\\\\\\\");
		       break;
		     default:
		       printf("%c", *s);
		       break;
		  }
	   }
	   break;
      }
  return 0;
}
