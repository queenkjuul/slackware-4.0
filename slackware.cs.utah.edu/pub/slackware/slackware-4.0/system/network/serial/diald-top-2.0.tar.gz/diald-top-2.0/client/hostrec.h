/*
 * $Id: hostrec.h,v 2.0 1997/09/28 21:21:09 gjhurlbu Exp $
 *
 * DialD Packet Statistics Program
 * (c) 1995 Gavin J. Hurlbut
 * gjhurlbu@beirdo.uplink.on.ca
 *
 */

#ifndef _hostrec_h
#define _hostrec_h

/* Included Header Files */
#include <netinet/in.h>

struct hostrec {
	struct in_addr addr;
	char *name;
	char *trunc;
	struct hostrec *next;
};

#endif
