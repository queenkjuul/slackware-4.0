#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	_STATE	258
#define	_INTERFACE	259
#define	_STATUS	260
#define	_LOAD	261
#define	_MESSAGE	262
#define	_QUEUE	263
#define	_ENDQUEUE	264
#define	_TIME	265
#define	_NUM	266
#define	_IP	267
#define	_NEWLINE	268
#define	_PORT	269
#define	_STRING	270
#define	_WOULDBLOCK	271


extern YYSTYPE yylval;
