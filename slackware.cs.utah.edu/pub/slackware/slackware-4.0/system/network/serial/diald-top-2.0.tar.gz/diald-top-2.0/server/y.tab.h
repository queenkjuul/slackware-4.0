#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	_USERID	258
#define	_IP	259
#define	_NEWLINE	260


extern YYSTYPE yylval;
