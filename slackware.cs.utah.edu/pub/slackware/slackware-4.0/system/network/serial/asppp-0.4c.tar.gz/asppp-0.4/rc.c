#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "asppp.h"

char *dialprog, *hupprog, *statprog;
int lineno = 1;
extern char *progname;
extern int VERBOSE, WHARF, NOFORK, DELAY;
extern Display *dpy;
extern Window aspppWindow;
extern XpmIcon *Dial, *HUP, *Stat, *Exit;

void SetExecParams(int which, XpmIcon * icon, char *execname)
{
    execname = strtok(NULL, "\n");
    if (execname != NULL) {
	switch (which) {
	case 0:
	    strcpy(dialprog, execname);
	    break;
	case 1:
	    strcpy(hupprog, execname);
	    break;
	case 2:
	    strcpy(statprog, execname);
	    break;
	}
    } else {
	fprintf(stderr, "%s: error in config file\nline %i: must specify a program after Exec\n",
		progname, lineno);
	exit(1);
    }
}

void LoadXpmFile(char *fname, XpmIcon * icon)
{
    struct stat buf;

    if (fname == NULL) {
	fprintf(stderr, "%s: error in config. must specify a file after Pixmap option\n",
		progname);
	exit(1);
    } else if ((stat(fname, &buf)) != 0) {
	fprintf(stderr, "%s: ", progname);
	perror(fname);
    } else {
	if (XpmReadFileToPixmap(dpy, aspppWindow, fname, &icon->pixmap,
				&icon->mask, &icon->attributes)) {
	    fprintf(stderr, "%s: error loading \'%s\'\n", progname,
		    fname);
	}
	/* check mask - from asmail */
	if (icon->mask == 0) {
	    fprintf(stderr, "%s: \'%s\' does not have any tranparent pixels.\nUsing default icon\n",
		    progname, fname);
	    icon->otherXpm = 0;
	} else {
	    icon->otherXpm = 1;
	}
    }
}

void rc(char *rcfname)
{
    char *line = calloc(1, 128), *tmp = calloc(1, 128);
    FILE *rcfile;
    struct stat buf;

    if (stat(rcfname, &buf) != 0) {
	fprintf(stderr, "%s: ", progname);
	perror(rcfname);
    } else {
	rcfile = fopen(rcfname, "r");
	statprog = calloc(1, 128);
	hupprog = calloc(1, 128);
	dialprog = calloc(1, 128);
	fgets(line, 128, rcfile);

	while (!feof(rcfile)) {
	    strcpy(tmp, line);

	    if ((strcmp(tmp, "\n") != 0) && (tmp != NULL) && (strncmp(tmp, "#", 1))) {
		if (strcmp(tmp, "Wharf\n") == 0) {
		    WHARF = 1;
		} else if (strcmp(tmp, "NoWharf\n") == 0) {
		    WHARF = 0;
		} else if (strcmp(tmp, "Verbose\n") == 0) {
		    VERBOSE = 1;
		} else if (strcmp(tmp, "NoVerbose\n") == 0) {
		    VERBOSE = 0;
		} else if (strcmp(tmp, "Fork\n") == 0) {
		    NOFORK = 0;
		} else if (strcmp(tmp, "NoFork\n") == 0) {
		    NOFORK = 1;
		} else {
		    tmp = strtok(tmp, " ");
		    if (strcmp(tmp, "DialExec") == 0) {
			SetExecParams(0, Dial, tmp);
		    } else if (strcmp(tmp, "HupExec") == 0) {
			SetExecParams(1, HUP, tmp);
		    } else if (strcmp(tmp, "StatExec") == 0) {
			SetExecParams(2, Stat, tmp);
		    } else if (strcmp(tmp, "DialPixmap") == 0) {
			tmp = strtok(NULL, "\n");
			LoadXpmFile(tmp, Dial);
		    } else if (strcmp(tmp, "HupPixmap") == 0) {
			tmp = strtok(NULL, "\n");
			LoadXpmFile(tmp, HUP);
		    } else if (strcmp(tmp, "StatPixmap") == 0) {
			tmp = strtok(NULL, "\n");
			LoadXpmFile(tmp, Stat);
		    } else if (strcmp(tmp, "ExitPixmap") == 0) {
			tmp = strtok(NULL, "\n");
			LoadXpmFile(tmp, Exit);
		    } else if (strcmp(tmp, "Delay") == 0) {
			DELAY = atoi(strtok(NULL, "\n"));
		    } else {
			fprintf(stderr, "%s: error in config file ( %s )\nline number %i: %s\n",
				progname, rcfname, lineno, line);
			exit(1);
		    }
		}
	    }
	    fgets(line, 128, rcfile);
	    lineno += 1;
	}
	fclose(rcfile);
    }
}
