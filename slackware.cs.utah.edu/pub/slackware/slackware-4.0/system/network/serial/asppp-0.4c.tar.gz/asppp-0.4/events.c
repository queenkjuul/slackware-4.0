#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/StringDefs.h>
#include <X11/extensions/shape.h>
#include <X11/xpm.h>
#include <stdlib.h>
#include <unistd.h>

#include "asppp.h"

extern XpmIcon *current, *Dial, *HUP, *Stat, *logo, *Exit;

extern char *progname, *stattext, *ipaddr;
extern FILE *pppfd;
extern int STAT, VERBOSE, WHARF, ppp, DELAY, statMap;
extern Display *dpy;
extern GC aspppGC;
extern Window aspppWindow;
extern Widget mainWindow;
extern XtAppContext asppp;
extern XtIntervalId aspppTimeout;
extern XTextItem xtext;

/* event handlers */
void Cleanup(void)
{
    XtUnmapWidget(mainWindow);
    fclose(pppfd);
    XtRemoveTimeOut(aspppTimeout);
    exit(0);
}

void ExposureHandler(Widget W, XtPointer P, XEvent * E)
{
    if (!WHARF)
	XCopyArea(dpy, logo->pixmap, XtWindow(mainWindow), aspppGC, 0, 0,
		  logo->attributes.width, logo->attributes.height, 48, 0);
    windowRedraw();
}

void ButtonHandler(Widget W, XtPointer P, XEvent * E)
{
    if (E->xbutton.button == 1 && (E->xbutton.x < 48)) {
	if (current->clickfunc != NULL) {
	    current->clickfunc();
	}
    }
    if (E->xbutton.button == 3 && (E->xbutton.x < 48))
	current = (XpmIcon *) current->next_xpm;

    XtRemoveTimeOut(aspppTimeout);
    aspppTimeout = XtAppAddTimeOut(asppp, DELAY * 1000,
				   (XtTimerCallbackProc) UpdatePPP, NULL);
    windowRedraw();
}

void UpdatePPP(XtPointer P, XtIntervalId * I)
{
    ppp = pppcheck(pppfd);

    if (ppp == 1) {
	current = HUP;
	if (WHARF) {
	    (XpmIcon *) HUP->next_xpm = Stat;
	    (XpmIcon *) Stat->next_xpm = HUP;
	} else {
	    (XpmIcon *) HUP->next_xpm = Stat;
	    (XpmIcon *) Stat->next_xpm = Exit;
	    (XpmIcon *) Exit->next_xpm = HUP;
	}
    } else {
	current = Dial;
	if (WHARF) {
	    (XpmIcon *) Dial->next_xpm = Stat;
	    (XpmIcon *) Stat->next_xpm = Dial;
	} else {
	    (XpmIcon *) Dial->next_xpm = Stat;
	    (XpmIcon *) Stat->next_xpm = Exit;
	    (XpmIcon *) Exit->next_xpm = Dial;
	}
    }

    windowRedraw();

    aspppTimeout = XtAppAddTimeOut(asppp, DELAY * 1000,
				   (XtTimerCallbackProc) UpdatePPP, NULL);
}

/* window redraw */
void windowRedraw(void)
{
    if (WHARF) {
	XShapeCombineMask(dpy, XtWindow(mainWindow), ShapeBounding, 0, 0,
			  current->mask, ShapeSet);
    } else {
	XCopyArea(dpy, logo->pixmap, XtWindow(mainWindow), aspppGC, 0, 0, logo->attributes.width, logo->attributes.height, 48, 0);
    }

    XCopyArea(dpy, current->pixmap, XtWindow(mainWindow), aspppGC, 0, 0,
	      48, 48, 0, 0);

    if (STAT && WHARF) {
	XDrawText(dpy, XtWindow(mainWindow), aspppGC, 2, 7, &xtext, 1);
    } else if (STAT && !WHARF) {
	xtext.chars = stattext;
	xtext.nchars = strlen(stattext);
	XDrawText(dpy, XtWindow(mainWindow), aspppGC, 52, 10, &xtext, 1);

	xtext.chars = ipaddr;
	xtext.nchars = strlen(ipaddr);
	XDrawText(dpy, XtWindow(mainWindow), aspppGC, 52, 22, &xtext, 1);

	xtext.chars = __asppp_version;
	xtext.nchars = strlen(__asppp_version);
	XDrawText(dpy, XtWindow(mainWindow), aspppGC, 64, 38, &xtext, 1);
    }
}
