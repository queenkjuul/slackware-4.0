#include <X11/Intrinsic.h>
#include <X11/xpm.h>
#include <stdlib.h>
#include <stdio.h>

#include "asppp.h"
#include "xpm/dial.xpm"
#include "xpm/hangup.xpm"
#include "xpm/stat.xpm"
#include "xpm/exit.xpm"
#include "xpm/logo-bk.xpm"

extern char *progname;
extern int WHARF, ppp;
extern Display *dpy;
extern Window aspppWindow;
extern XpmIcon *current, *Dial, *HUP, *Stat, *logo, *Exit;

void XPMError(int errcode)
{
    switch (errcode) {
    case 0:
	break;
    case 1:
    case -4:
	fprintf(stderr, "%s: not enough free color cells\n",
		progname);
	break;
    case -1:
    case -2:
	fprintf(stderr, "%s: could not load xpm\n", progname);
	break;
    case -3:
	fprintf(stderr, "%s: not enough memory free for xpm\n",
		progname);
	break;
    default:
	fprintf(stderr, "%s: unknown xpm error\n", progname);
	break;
    }

    if (errcode != 0)
	exit(1);
}

void XPMDefaults(void)
{
    /* Dial Icon */
    if (!Dial->otherXpm)
	XPMError(XpmCreatePixmapFromData(dpy, aspppWindow, dial_xpm,
			 &Dial->pixmap, &Dial->mask, &Dial->attributes));

    /* HUP Icon */
    if (!HUP->otherXpm)
	XPMError(XpmCreatePixmapFromData(dpy, aspppWindow, hangup_xpm,
			    &HUP->pixmap, &HUP->mask, &HUP->attributes));

    /* Stat Icon */
    if (!Stat->otherXpm)
	XPMError(XpmCreatePixmapFromData(dpy, aspppWindow, stat_xpm,
			 &Stat->pixmap, &Stat->mask, &Stat->attributes));

    if (!Exit->otherXpm)
	XPMError(XpmCreatePixmapFromData(dpy, aspppWindow, exit_xpm,
			 &Exit->pixmap, &Exit->mask, &Exit->attributes));

    if (!WHARF) {
	XPMError(XpmCreatePixmapFromData(dpy, aspppWindow, logo_bk_xpm,
			 &logo->pixmap, &logo->mask, &logo->attributes));
	logo->clickfunc = NULL;
    }
    Dial->clickfunc = execDial;
    Stat->clickfunc = Statistics;
    HUP->clickfunc = execHUP;;
    Exit->clickfunc = Cleanup;

    if (ppp == 1) {
	current = HUP;
	if (WHARF) {
	    (XpmIcon *) HUP->next_xpm = Stat;
	    (XpmIcon *) Stat->next_xpm = HUP;
	    (XpmIcon *) Dial->next_xpm = Stat;
	} else {
	    (XpmIcon *) HUP->next_xpm = Stat;
	    (XpmIcon *) Stat->next_xpm = Exit;
	    (XpmIcon *) Exit->next_xpm = HUP;
	    (XpmIcon *) Dial->next_xpm = Stat;
	}
    } else {
	current = Dial;
	if (WHARF) {
	    (XpmIcon *) Dial->next_xpm = Stat;
	    (XpmIcon *) Stat->next_xpm = Dial;
	    (XpmIcon *) HUP->next_xpm = Stat;
	} else {
	    (XpmIcon *) Dial->next_xpm = Stat;
	    (XpmIcon *) Stat->next_xpm = Exit;
	    (XpmIcon *) Exit->next_xpm = Dial;
	    (XpmIcon *) HUP->next_xpm = Stat;
	}
    }
}
