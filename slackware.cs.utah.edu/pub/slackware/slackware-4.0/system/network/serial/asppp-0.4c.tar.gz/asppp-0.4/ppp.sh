#!/bin/sh
#
# ~/cmd/ppp
# this script automatically updates /etc/hosts 
# (which should be linked to /usr/local/etc/hosts w/ -rw-rw---- permissions)

# cat ~bhughes/cmd/hosts > /usr/local/etc/hosts
echo "127.0.0.1		localhost" > /usr/local/etc/hosts
export IP=`/sbin/ifconfig ppp0 | grep inet |cut -f 12 -d" " | cut -f 2 -d:`
echo $IP"	"`cat /etc/HOSTNAME`" "`hostname` >> /usr/local/etc/hosts
# lrwxrwxrwx   1 root     root           20 Dec 13 13:14 /etc/hosts -> /usr/local/etc/hosts
# -rw-rw----   1 root     root           64 Feb  6 14:15 /usr/local/etc/hosts
