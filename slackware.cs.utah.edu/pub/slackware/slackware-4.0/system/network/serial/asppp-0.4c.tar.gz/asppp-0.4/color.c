#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/xpm.h>
#include <stdio.h>
#include "asppp.h"

extern char *progname;
extern Display *dpy;
extern Widget mainWindow;

Pixel getcolor(char *name)
{
    XColor color;
    XWindowAttributes attributes;

    XGetWindowAttributes(dpy, XtWindow(mainWindow), &attributes);
    color.pixel = 0;
    if (!XParseColor(dpy, attributes.colormap, name, &color)) {
	fprintf(stderr, "%s: parse error: %s", progname, name);
    } else if (!XAllocColor(dpy, attributes.colormap, &color)) {
	fprintf(stderr, "%s: alloc error: %s", progname, name);
    }
    return color.pixel;
}
