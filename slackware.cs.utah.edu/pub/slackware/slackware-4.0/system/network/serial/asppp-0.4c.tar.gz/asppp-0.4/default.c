/* default.c
 *    Tim Ward - modified by Brad Hughes (for asppp extern's)
 * 
 * checks /proc/net/route and determines and finds the default route
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include "asppp.h"

extern char *progname, *pppfile;
extern int VERBOSE, check, STAT, ppp;
extern char *device;
int change, last, x, y;

int pppcheck(FILE * pppfd)
{
    char *line, *defroute;
    struct stat buf;

    device = NULL;
    line = malloc(256);

    if (feof(pppfd))
	rewind(pppfd);

    if (stat("/var/run/ppp0.pid", &buf) == 0) {
	check = 0;
	ppp = 1;
	if (last == 0)
	    last = 1;
    } else {
	check = 1;
    }

    last = check;

    if (check) {
	fread(line, 1, 256, pppfd);
	device = strpbrk("ppp0", line);
	if (device != NULL) {
	    if (strcmp(device, "ppp0") != 0) {
		if (VERBOSE)
		    fprintf(stderr, "%s: no device found\n", progname);
		ppp = 0;
	    } else {
		if (VERBOSE)
		    fprintf(stderr, "%s: Device found: %s - route: ",
			    progname, device);

		/* we found the device we want: ppp0    */
		/* now how bout the default route on it */

		defroute = strpbrk("00000000", line);
		if (strcmp(defroute, "00000000") == 0) {
		    if (VERBOSE)
			fprintf(stderr, "Default route.\n");
		    ppp = 1;
		} else {
		    if (VERBOSE)
			fprintf(stderr, "NON DEFAULT!\n");
		    ppp = 0;
		}
	    }
	}
	free(line);
    }
    if (ppp != x && check != y) {
	sleep(2);
	STAT = 1;
	Statistics();
	STAT = 0;
	Statistics();
    }
    x = ppp;
    y = check;
    return (ppp);
}
