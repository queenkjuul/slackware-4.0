/* asppp version 0.4b BETA */

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/StringDefs.h>
#include <X11/extensions/shape.h>
#include <X11/Xaw3d/Box.h>
#include <X11/xpm.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

#include "asppp.h"

XpmIcon *current, *Dial, *HUP, *Stat, *logo, *Exit;

/* global flags */
char *dialprog, *hupprog, *statprog, *ipaddr;
char *device, *progname, *pppfile = "/proc/net/route", *rcfilename = NULL;
int STAT = 0, NOFORK = 0, VERBOSE = 0, WHARF = 0, DELAY = 10, ppp, check;
Display *dpy;
FILE *pppfd = NULL;
GC aspppGC;
XGCValues gcv;
Window aspppWindow;
Widget mainWindow;
unsigned long gcm;
XtAppContext asppp;
XtIntervalId aspppTimeout;

extern int change, last;

/* main */
int main(int argc, char **argv)
{
    char *rcpath = (char *) calloc(1, 128);
    int i, aspppPID;

    last = 1;
    progname = argv[0];

    mainWindow = XtVaOpenApplication(&asppp, "asppp", NULL, 0, &argc, argv,
				     NULL, sessionShellWidgetClass, NULL);

    dpy = XtDisplay(mainWindow);
    aspppWindow = RootWindow(dpy, DefaultScreen(dpy));

    XtAddEventHandler(mainWindow, ExposureMask, FALSE,
		      (XtEventHandler) ExposureHandler, NULL);
    XtAddEventHandler(mainWindow, ButtonPressMask, FALSE,
		      (XtEventHandler) ButtonHandler, NULL);

    pppfd = fopen(pppfile, "r");
    if (!pppfd)
	perror("fdopen");

    ppp = pppcheck(pppfd);

    logo = (XpmIcon *) calloc(1, sizeof(XpmIcon));
    Dial = (XpmIcon *) calloc(1, sizeof(XpmIcon));
    HUP = (XpmIcon *) calloc(1, sizeof(XpmIcon));
    Stat = (XpmIcon *) calloc(1, sizeof(XpmIcon));
    Exit = (XpmIcon *) calloc(1, sizeof(XpmIcon));

    rcfilename = (char *) calloc(1, 255);
    rcpath = getenv("HOME");
    memcpy(rcfilename, rcpath, strlen(rcpath));
    rcfilename = strcat(rcfilename, "/.asppprc");

    rc(rcfilename);

    for (i = 1; i < argc; i++) {
	if (strcmp("-wharf", argv[i]) == 0)
	    WHARF = 1;
	if (strcmp("-nowharf", argv[i]) == 0)
	    WHARF = 0;
	if (strcmp("-v", argv[i]) == 0)
	    VERBOSE = 1;
	if (strcmp("--version", argv[i]) == 0)
	    fprintf(stderr, "%s: %s\n", progname, __asppp_version);
	if (strcmp("-delay", argv[i]) == 0) {
	    DELAY = atoi(argv[i + 1]);
	    i++;
	}
	if (strcmp("-nofork", argv[i]) == 0)
	    NOFORK = 1;
	if (strcmp("-fork", argv[i]) == 0)
	    NOFORK = 0;
    }

    if (WHARF) {
	free(logo);
    }
    XPMDefaults();

    if (VERBOSE) {
	fprintf(stderr, "%s: %s\n", progname, __asppp_version);
	fprintf(stderr, "%s: parsed route file \'%s\'\n", progname,
		pppfile);
	fprintf(stderr, "%s: loaded default pixmaps\n", progname);
	fprintf(stderr, "%s: loaded rcfile: \'%s\'\n", progname, rcfilename);
	fprintf(stderr, "%s: parsed command line\n", progname);
	fprintf(stderr, "%s: option \'verbose\'\n", progname);
	if (NOFORK == 1)
	    fprintf(stderr, "%s: option \'nofork\'\n", progname);
	if (WHARF == 1)
	    fprintf(stderr, "%s: option \'wharf\'\n", progname);
	fprintf(stderr, "%s: ppp route check delay: %i\n", progname,
		DELAY);
    }
    if (WHARF) {
	XtVaSetValues(mainWindow, XtNwidth, 48, XtNheight, 48, NULL);
    } else {
	XtVaSetValues(mainWindow, XtNwidth, 48 * 4, XtNheight, 48, NULL);
    }
    XtRealizeWidget(mainWindow);

    gcm = GCForeground | GCBackground | GCGraphicsExposures;

    gcv.foreground = getcolor("white");
    gcv.background = getcolor("black");
    if (WHARF) {
	gcv.font = XLoadFont(dpy, "-*-helvetica-medium-r-*-*-9-*-*-*-*-*-*-*");
    } else {
	gcv.font = XLoadFont(dpy, "-*-helvetica-medium-r-*-*-10-*-*-*-*-*-*-*");
    }

    gcv.graphics_exposures = 0;
    aspppGC = XCreateGC(dpy, aspppWindow, gcm, &gcv);

    if (VERBOSE)
	fprintf(stderr, "%s: mapping asppp window\n", progname);

    XtVaSetValues(mainWindow, XtNbackground, gcv.background, NULL);
    XtMapWidget(mainWindow);
    Statistics();
    windowRedraw();

    aspppTimeout = XtAppAddTimeOut(asppp, DELAY * 1000,
				   (XtTimerCallbackProc) UpdatePPP, NULL);


    if (NOFORK) {
	if (VERBOSE)
	    fprintf(stderr, "%s: fork() overridden\n", progname);
    } else {
	aspppPID = fork();
	if (aspppPID > 0) {
	    if (VERBOSE)
		fprintf(stderr, "%s: fork()'d into background\n",
			progname);
	    exit(255);
	}
    }

    XtAppMainLoop(asppp);
    return (0);
}
