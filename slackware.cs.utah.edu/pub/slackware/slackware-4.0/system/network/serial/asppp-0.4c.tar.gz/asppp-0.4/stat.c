#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/xpm.h>
#include <stdio.h>
#include <stdlib.h>
#include "asppp.h"

char *stattext = "Down";

extern char *progname, *statprog, *ipaddr;
extern int STAT, VERBOSE, WHARF, ppp;
extern GC aspppGC;
extern Display *dpy;
extern XGCValues gcv;
extern Widget mainWindow;
extern XpmIcon *logo;
XTextItem xtext;

void Statistics(void)
{
    FILE *ipfd;

    if (!STAT) {
	if (VERBOSE)
	    fprintf(stderr, "%s: showing statistics\n",
		    progname);
	xtext.font = gcv.font;
	if (WHARF) {
	    if (ppp) {
		stattext = "Connected";
	    } else {
		stattext = "Down";
	    }

	    xtext.chars = stattext;
	    xtext.nchars = strlen(stattext);
	    XDrawText(dpy, XtWindow(mainWindow), aspppGC, 2, 7, &xtext, 1);
	} else {
	    if (ppp) {
		system(statprog);
		stattext = "STATUS: Connected";
		ipaddr = calloc(1, 128);
		if ((ipfd = fopen("/tmp/asppp.IP", "r")) == NULL) {
		    fprintf(stderr, "%s: ", progname);
		    perror("/tmp/asppp.IP");
		}
		fgets(ipaddr, 128, ipfd);
		if (VERBOSE)
		    fprintf(stderr, "%s: got ip: %s", progname, ipaddr);
	    } else {
		stattext = "STATUS: Not connected";
		ipaddr = "inet addr: none";
	    }
	}
	STAT = 1;
	windowRedraw();
    } else {
	STAT = 0;
	if (VERBOSE)
	    fprintf(stderr, "%s: removing statistics from window\n", progname);
	windowRedraw();
    }
}
