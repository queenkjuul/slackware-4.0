#ifndef __asppp_h
#define __asppp_h
#define __asppp_version "version 0.4c BETA"

#include <stdio.h>			/* for typedef FILE */
#include <X11/Intrinsic.h>
#include <X11/xpm.h>

typedef struct {
        Pixmap pixmap;
        Pixmap mask;
        XpmAttributes attributes;
	void (*clickfunc)();
	int otherXpm;
        struct XpmIcon *next_xpm;
} XpmIcon;        

extern void ButtonHandler(Widget W, XtPointer P, XEvent *E);
extern void ExposureHandler(Widget W, XtPointer P, XEvent *E);
extern void UpdatePPP(XtPointer P, XtIntervalId *I);
extern void windowRedraw(void);  
extern int pppcheck(FILE *pppfd);
extern void rc(char *rcfname);
extern Pixel getcolor(char *name);
extern void XPMDefaults(void);

extern int confirm(char *windowname);
extern void Cleanup(void);
extern void Statistics(void);
extern void execDial(void);
extern void execHUP(void);

#endif /* __asppp_h */
