#include <stdio.h>
#include <stdlib.h>
#include "asppp.h"

extern char *progname, *dialprog, *hupprog;
extern int VERBOSE;

void execDial(void)
{
    if (VERBOSE)
	fprintf(stderr, "%s: executing \'%s\'\n", progname, dialprog);
    system(dialprog);
}

void execHUP(void)
{
    if (VERBOSE)
	fprintf(stderr, "%s: executing \'%s\'\n", progname, hupprog);
    system(hupprog);
}
