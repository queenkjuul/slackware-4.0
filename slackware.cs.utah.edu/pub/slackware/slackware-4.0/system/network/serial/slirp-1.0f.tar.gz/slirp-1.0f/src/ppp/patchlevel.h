/* $Id: patchlevel.h,v 1.14 1995/06/12 11:22:52 paulus Exp $ */
#define	PATCHLEVEL	0

#define VERSION		"2.2"
#define IMPLEMENTATION	""
#define DATE		"17 August 95"
