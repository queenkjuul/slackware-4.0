/*
 * Motif-PPP for Linux, Version 1.03 Beta
 * Copyright (C) 1997 Seiji Eto, All Right Reserved.
 *
 * Motif-PPP is an X-based dial-up ppp connection setup utility
 * program that is capable of automatically configuring and triggering for
 * the ppp daemon to be executed. Inspite of configuring ppp connection
 * manually, which causes some people a trouble, this utility allows users
 * to avoid such troublesome and to configure the settings automatically.
 *
 */ 

#include <Xm/XmAll.h>
#include <Xm/Display.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/cursorfont.h>
#include <ctype.h>
#include <varargs.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <sys/file.h>
#include <unistd.h>
#include <signal.h>

#define TRUE 1
#define FALSE 0

String fallback[] = {
"Motif-PPP*help_message*translations:        #override\
        <Btn2Down>:                     ",
"Motif-PPP*about_message*translations:        #override\
        <Btn2Down>:                     ",
"Motif-PPP*config_help_message*translations:        #override\
        <Btn2Down>:                     ",
"Motif-PPP*fontList:	-adobe-helvetica-bold-r-*-*-12-*",
"Motif-PPP*menubar*fontList:	-adobe-helvetica-bold-r-*-*-12-*",
"Motif-PPP*passwd_w*fontList:	-adobe-helvetica-medium-r-*-*-12-*",
"Motif-PPP*phone_number_w*fontList:	-adobe-helvetica-medium-r-*-*-11-*",
"Motif-PPP*login_name_w*fontList:	-adobe-helvetica-medium-r-*-*-11-*",
"Motif-PPP*pppd_dir_w*fontList:	-adobe-helvetica-medium-r-*-*-11-*",
"Motif-PPP*domain_w*fontList:	-adobe-helvetica-medium-r-*-*-11-*",
"Motif-PPP*nameserver_w*fontList:	-adobe-helvetica-medium-r-*-*-11-*",
"Motif-PPP*list_w*fontList:	-adobe-helvetica-medium-r-*-*-11-*",
"Motif-PPP*foreground:	black",
"Motif-PPP*background:	grey",
"Motif-PPP*phone_number_w*background:	white",
"Motif-PPP*login_name_w*background:	white",
"Motif-PPP*pppd_dir_w*background:	white",
"Motif-PPP*domain_w*background:	white",
"Motif-PPP*nameserver_w*background:	white",
"Motif-PPP*passwd_w*background:	white",
"Motif-PPP*list_w*background:	white",
"Motif-PPP*help_message*messageString:\
	Motif-PPP is a dial-up ppp connection setup\\n\
	utility. After you specify all information needed\\n\
	to run ppp daemon, press the connect button.\\n\\n\
	Note: You must make entries not only on the\\n\
	main panel but also on the ppp configuration\\n\
	dialog.",
"Motif-PPP*config_help_message*messageString:\
	Speed: modem speed in bps.\\n\
	Device: device port to which modem connected.\\n\
	pppd Directory: directory in which pppd resides.\\n\
	Domain Name: domain server name.\\n\
	Name Server: name server IP address.",
"Motif-PPP*about_message*messageString:\
	Motif-PPP for Linux, Version 1.03 Beta\\n\
	Copyright (C) 1997 Seiji Eto, All Rights Reserved.\\n\
	For bug report, write to:  seto@Slip.Net",
"Motif-PPP*error_message*messageString:\
	You must make an entry for every\\n\
	single text box in both main and\\n\
	configuration dialogs, except for\\n\
	the nameserver input box.",
"Motif-PPP*timeout_message*messageString:\
	A connection could not be made.\\n\
	Try it again later.",
"Motif-PPP*dialog_frame2*background:	white",
"Motif-PPP*dialog_frame2*fontList:	-adobe-helvetica-medium-r-*-*-11-*",
NULL
};

char *labels[] = { "Phone Number:", "Login Name:"};
char *resolv_conf_tmpl[] = { "domain", "search", "nameserver" };
char *chat_tmpl[] = {
	"#! /bin/sh\n",
	"PHONE=",
	"USER=",
	"PASSWORD=",
	"/chat \\\n",
	"TIMEOUT 60 \\\n",
	"ABORT	\"BUSY\" \\\n",
	"ABORT	\"NO ANSWER\" \\\n",
	"ABORT	\"NO CARRIER\" \\\n",
	"\"\"	ATDT$PHONE \\\n",
	"CONNECT \"\" \\\n",
	"\"\"	\"\" \\\n",
	"TIMEOUT 3 \\\n",
	"\"ogin:-BREAK\" $USER \\\n",
	"\"serid:-BREAK\" $USER \\\n",
	"\"ogin:-BREAK\" $USER \\\n",
	"\"assword:-BREAK\" $PASSWORD \\\n",
	"\"serid:-BREAK\" $USER \\\n",
	"\"assword?-BREAK\" $PASSWORD \\\n",
	"\"\" ppp\n"
};
char *options_tmpl[] = {
	" crtscts modem\n",
	"noipdefault\n",
	"defaultroute\n",
	"kdebug 2\n",
	"connect /etc/ppp/chat\n"
};

void get_values();
void check_passwd();
void help_cb();
void help_dialog();
void about_dialog();
void config_cb();
void config_ok_cb();
void speed_option_cb();
void device_option_cb();
void destroy_widget();
void config_help_dialog();
void connect_pushed();
void ppp_connected();
void disconnect_pushed();
void xs_wprintf();
void update_time();
void create_files();
void create_error_dialog();
void timeout_cursors();
void focuscallback();
void kill_pppd();
void time_out();
void add_pushed();
void add_item();
void remove_item();
void get_selected_item_number();
void set_cursor_position_last();

Boolean check_for_interrupt();

char	*phone_number = NULL,
	*login_name = NULL,
	*pppd_dir = NULL,
	*domain = NULL,
	*nameserver = NULL,
	*passwd = NULL,
	*speed_text = NULL,
	*device_text = NULL,
	*astr_passwd = NULL;

char 	*file_chat = "/etc/ppp/chat",
	*file_resolv_conf = "/etc/resolv.conf",
	*file_options = "/etc/ppp/options";

char	*nameservers[10];

Widget toplevel, timer, phone_number_w, login_name_w, passwd_w,
       pppd_dir_w, domain_w, nameserver_w, list_w,
       option_menu1, option_menu2, remove_pb,
       wait_dialog;

XtAppContext  app;
long start_time;
int  speed_no, device_no, pppd_pid, selected_item,
     item_selected = False, DNS_count = 0;

XmStringCharSet charset = XmSTRING_DEFAULT_CHARSET;

main(argc, argv) /* main panel */
int argc;
char *argv[];
{
    Widget      main_w, main_w2, text_w, text, form3,
		menubar, w, w2, rc_frame2, rc_frame, form, rowcol, 
		widget, netconfig, quit, pixmap, label, rc, pb;
    XmString	config, help, about, btn_text, quit_acc, config_acc,
		help_acc, about_acc;
    int		i;

    printf("Motif-PPP for Linux, Version 1.03 Beta\n");
    printf("Copyright (C) 1997 Seiji Eto, All Rights Reserved.\n");

    if(access("/var/run/ppp0.pid", 0) == 0){
        printf("\n/var/run/ppp0.pid exists.\n");
        printf("Another pppd might be running.\n");
	exit(0);
    }

    get_values();

    toplevel = XtVaAppInitialize(&app, "Motif-PPP",
        NULL, 0, &argc, argv, fallback, NULL);

    main_w = XtVaCreateManagedWidget("main_w",
        xmMainWindowWidgetClass,   toplevel,
        NULL);

    main_w2 = XtVaCreateManagedWidget("main_w2",
        xmRowColumnWidgetClass,   main_w,
	XmNorientation,		XmVERTICAL,
        NULL);

    rc_frame2 = XtVaCreateManagedWidget("frame2",
        xmFrameWidgetClass, main_w2,
        XmNshadowType,      XmSHADOW_ETCHED_IN,
        NULL);

    form3 = XtVaCreateWidget("form3", xmFormWidgetClass, rc_frame2,
        XmNfractionBase,  100,
        NULL);

    /* Now create label using pixmap */
    pixmap = XmGetPixmap(XtScreen(form3), 
        "/usr/include/X11/pixmaps/phone3.xpm", NULL, NULL);
    label = XtVaCreateManagedWidget("label", xmLabelWidgetClass, form3,
        XmNlabelType,   XmPIXMAP,
        XmNlabelPixmap, pixmap,
        XmNtopAttachment,    XmATTACH_FORM,
        XmNbottomAttachment, XmATTACH_FORM,
        XmNleftAttachment,  XmATTACH_POSITION,
        XmNleftPosition,     13,
        XmNalignment,        XmALIGNMENT_END,
        NULL);

    text = XtVaCreateManagedWidget("PPP Connection Setup Utility",
        xmLabelGadgetClass, form3,
        XmNtopAttachment,  XmATTACH_POSITION,
	XmNtopPosition,	     34,
        XmNrightAttachment,  XmATTACH_FORM,
        XmNleftAttachment,   XmATTACH_POSITION,
        XmNleftPosition,     35,
        NULL);

    rc_frame = XtVaCreateManagedWidget("frame1",
        xmFrameWidgetClass, main_w2,
        XmNshadowType,      XmSHADOW_ETCHED_IN,
        NULL);

    /* Create a simple MenuBar that contains three menus */
    config = XmStringCreateSimple("Config");
    help = XmStringCreateSimple("Help");
    menubar = XmVaCreateSimpleMenuBar(main_w, "menubar",
        XmVaCASCADEBUTTON, config, 'C',
        XmVaCASCADEBUTTON, help, 'H',
        NULL);
    XmStringFree(config);

    netconfig = XmStringCreateSimple("PPP Configuration");
    quit = XmStringCreateSimple("Exit");
    quit_acc = XmStringCreateSimple("Alt+Q");
    config_acc = XmStringCreateSimple("Alt+P");
    XmVaCreateSimplePulldownMenu(menubar, "config_menu", 0, config_cb,
        XmVaPUSHBUTTON, netconfig, 'P', "Alt<Key>p", config_acc,
        XmVaSEPARATOR,
        XmVaPUSHBUTTON, quit, 'x', "Alt<Key>q", quit_acc,
        NULL);
    XmStringFree(netconfig);
    XmStringFree(quit);
    XmStringFree(quit_acc);
    XmStringFree(config_acc);

    /* Third menu is the help menu -- callback is help_cb() */
    about = XmStringCreateSimple("About");
    help_acc = XmStringCreateSimple("Alt+E");
    about_acc = XmStringCreateSimple("Alt+A");
    XmVaCreateSimplePulldownMenu(menubar, "help_menu", 1, help_cb,
        XmVaPUSHBUTTON, help, 'e', "Alt<Key>e", help_acc,
        XmVaSEPARATOR,
        XmVaPUSHBUTTON, about, 'A', "Alt<Key>a", about_acc,
        NULL);
    XmStringFree(about);
    XmStringFree(help_acc);
    XmStringFree(about_acc);
    {
        /* Identify the Help Menu for the MenuBar */
        Widget *cascade_btns;
        int num_btns;
        XtVaGetValues(menubar,
            XmNchildren,      &cascade_btns,
            XmNnumChildren,   &num_btns,
            NULL);
        XtVaSetValues(menubar,
            XmNmenuHelpWidget, cascade_btns[num_btns-1],
            NULL);
    }
    XmStringFree(help); /* we're done with it; now we can free it */
    XtManageChild(menubar);

    rowcol = XtVaCreateWidget("rowcol",
        xmRowColumnWidgetClass, rc_frame, NULL);

        form = XtVaCreateWidget("form", xmFormWidgetClass, rowcol,
            XmNheight,       32,  
            XmNfractionBase,  100,
            NULL);
        XtVaCreateManagedWidget("Phone Number:",
            xmLabelGadgetClass, form,
            XmNtopAttachment,    XmATTACH_FORM,
            XmNbottomAttachment, XmATTACH_FORM,
            XmNleftAttachment,  XmATTACH_POSITION,
            XmNleftPosition,     3,
            XmNalignment,        XmALIGNMENT_END,
            NULL);
        phone_number_w = XtVaCreateManagedWidget("phone_number_w",
            xmTextFieldWidgetClass, form,
	    XmNvalue,		phone_number,
	    XmNcursorPosition,	strlen(phone_number),
            XmNtraversalOn,      True,
            XmNwidth,        215,
            XmNheight,       31, 
            XmNresizePolicy, XmNONE, /* remain this a fixed size */
            XmNrightAttachment,  XmATTACH_FORM,
            XmNleftAttachment,   XmATTACH_POSITION,
            XmNleftPosition,     44,
            NULL);

        XtAddCallback(phone_number_w, XmNactivateCallback,
            connect_pushed, NULL);
        XtAddCallback(phone_number_w, XmNactivateCallback,
            XmProcessTraversal, XmTRAVERSE_NEXT_TAB_GROUP);
        XtAddCallback(phone_number_w, XmNfocusCallback,
            focuscallback, phone_number_w);

        XtManageChild(form);
    
        form = XtVaCreateWidget("form", xmFormWidgetClass, rowcol,
            XmNheight,       32,
            XmNfractionBase,  100,
            NULL);
        XtVaCreateManagedWidget("Login Name:",
            xmLabelGadgetClass, form,
            XmNtopAttachment,    XmATTACH_FORM,
            XmNbottomAttachment, XmATTACH_FORM,
            XmNleftAttachment,  XmATTACH_POSITION,
            XmNleftPosition,     3,
            XmNalignment,        XmALIGNMENT_END,
            NULL);
        login_name_w = XtVaCreateManagedWidget("login_name_w",
            xmTextFieldWidgetClass, form,
	    XmNvalue,		login_name,
            XmNcursorPositionVisible,   False,
            XmNtraversalOn,      True,
            XmNwidth,        215,
            XmNheight,       31,
            XmNresizePolicy, XmNONE, /* remain this a fixed size */
            XmNrightAttachment,  XmATTACH_FORM,
            XmNleftAttachment,   XmATTACH_POSITION,
            XmNleftPosition,     44,
            NULL);

        XtAddCallback(login_name_w, XmNactivateCallback,
            connect_pushed, NULL);
        XtAddCallback(login_name_w, XmNactivateCallback,
            XmProcessTraversal, XmTRAVERSE_NEXT_TAB_GROUP);
        XtAddCallback(login_name_w, XmNfocusCallback,
            focuscallback, login_name_w);

        XtManageChild(form);


        form = XtVaCreateWidget("form", xmFormWidgetClass, rowcol,
            XmNheight,       32,  
            XmNfractionBase,  100,
            NULL);
        XtVaCreateManagedWidget("Password:",
            xmLabelGadgetClass, form, 
            XmNtopAttachment,    XmATTACH_FORM,
            XmNbottomAttachment, XmATTACH_FORM,
            XmNleftAttachment,  XmATTACH_POSITION,
            XmNleftPosition,     3,
            XmNalignment,        XmALIGNMENT_END,
            NULL);
        passwd_w = XtVaCreateManagedWidget("passwd_w",
            xmTextFieldWidgetClass, form,
	    XmNvalue,		astr_passwd,
            XmNcursorPositionVisible,   False,
            XmNtraversalOn,      True,
            XmNwidth,        215, 
            XmNheight,       31,  
            XmNresizePolicy, XmNONE, /* remain this a fixed size */
            XmNrightAttachment,  XmATTACH_FORM,
            XmNleftAttachment,   XmATTACH_POSITION,
            XmNleftPosition,     44,
            NULL);

        XtAddCallback(passwd_w, XmNmodifyVerifyCallback, check_passwd, NULL);
        XtAddCallback(passwd_w, XmNactivateCallback, check_passwd, NULL);
        XtAddCallback(passwd_w, XmNfocusCallback,
            focuscallback, passwd_w);
        XtManageChild(form);
        XtManageChild(form3);

    rc = XtVaCreateWidget("rc", 
	    xmFormWidgetClass, main_w2, 
            NULL);
    btn_text = XmStringCreateSimple ("Connect");
    pb = XtVaCreateManagedWidget("button", 
	    xmPushButtonWidgetClass, rc, 
            XmNleftAttachment, XmATTACH_FORM,
            XmNrightAttachment, XmATTACH_FORM,
            XmNheight,       33,  
	    XmNlabelString,	btn_text,
            XmNalignment,        XmALIGNMENT_CENTER,
	    NULL);

	XmStringFree(btn_text);
        XtAddCallback(pb, XmNactivateCallback, connect_pushed, NULL);

    	XtManageChild(rc);
    	XtManageChild(pb);
    	XtManageChild(rowcol);

    XtRealizeWidget(toplevel);
    XtAppMainLoop(app);
}

void
check_passwd(passwd_w, unused, cbs) /* control password unvisible and input */
Widget        passwd_w;
XtPointer     unused;
XmTextVerifyCallbackStruct *cbs;
{
    char *new;
    int len;

    /* For debug purpose */
    /*if (cbs->reason == XmCR_ACTIVATE) {
        printf("Password: %s\n", passwd);
        return;
    }*/

    if (cbs->text->ptr == NULL) { /*backspace*/
        cbs->endPos = strlen(passwd);  /*delete from here to end */
        passwd[cbs->startPos] = 0; /* backspace--terminate */
        return;
    }

    if (cbs->text->length > 1) {
        cbs->doit = False; /* don't allow "paste" operations */
        return; /* make the user *type* the password! */
    }

    new = XtMalloc(cbs->endPos + 2); /* new char + NULL terminator */
    if (passwd) {
        strcpy(new, passwd);
        XtFree(passwd);
    } else
        new[0] = NULL;
    passwd = new;
    strncat(passwd, cbs->text->ptr, cbs->text->length);
    passwd[cbs->endPos + cbs->text->length] = 0;

    for (len = 0; len < cbs->text->length; len++)
        cbs->text->ptr[len] = '*';
}

void
config_cb(w, item_no, cbs) /* configuration panel */
Widget w;
int item_no;
XmAnyCallbackStruct *cbs;
{
    static Widget dialog;
    int i;
    Widget	config_dialog, label, rc1, rc2, rc2_frame, rc, rc3,
		form, text, pixmap, add_pb, rc_list_w;

    if (item_no == 1)
        exit(0);

    if (item_no == 0){
    Arg args[10];
    XmString	dialog_title, temp, ok_label, cancel_label, help_label,
		speed_option_menu, speed0, speed1, speed2, speed3,
		speed4, speed5, speed6, speed7, speed8, device_option_menu,
		device0, device1, device2, device3, btn_text;

    dialog_title = XmStringCreateLocalized("Motif-PPP");
    ok_label = XmStringCreateLocalized("OK");
    cancel_label = XmStringCreateLocalized("Cancel");
    help_label = XmStringCreateLocalized("Help");

    XtSetArg(args[0], XmNdialogTitle, dialog_title);
    XtSetArg(args[1], XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL);
    XtSetArg(args[2], XmNokLabelString, ok_label);
    XtSetArg(args[3], XmNcancelLabelString, cancel_label);
    XtSetArg(args[4], XmNhelpLabelString, help_label);
    XtSetArg(args[5], XmNmarginHeight, 1);
    XtSetArg(args[6], XmNmarginWidth, 0);
    config_dialog = XmCreateTemplateDialog(toplevel, "config_dialog",
	args, 7);

    XtAddCallback(config_dialog, XmNokCallback,
                  (XtCallbackProc) config_ok_cb, NULL);
    XtAddCallback(config_dialog, XmNhelpCallback,
                  (XtCallbackProc) config_help_dialog, NULL);

    XmStringFree(dialog_title);
    XmStringFree(ok_label);
    XmStringFree(cancel_label);
    XmStringFree(help_label);

    rc1 = XtVaCreateManagedWidget("rc1",
        xmRowColumnWidgetClass,   config_dialog,
	XmNorientation,		XmVERTICAL,
        NULL);

    XtManageChild(rc1);

    rc2_frame = XtVaCreateManagedWidget("frame2",
        xmFrameWidgetClass, rc1,
        XmNshadowType,      XmSHADOW_ETCHED_IN,
        XmNfractionBase,  2,
        NULL);

    rc2 = XtVaCreateManagedWidget("rc2", 
	xmRowColumnWidgetClass, rc2_frame,
	XmNorientation,		XmHORIZONTAL,
	NULL);

    speed_option_menu = XmStringCreateSimple("Speed:");
    speed0 = XmStringCreateSimple("2,400 bps");
    speed1 = XmStringCreateSimple("4,800 bps");
    speed2 = XmStringCreateSimple("9,600 bps");
    speed3 = XmStringCreateSimple("14,400 bps");
    speed4 = XmStringCreateSimple("19,200 bps");
    speed5 = XmStringCreateSimple("28,800 bps");
    speed6 = XmStringCreateSimple("38,400 bps");
    speed7 = XmStringCreateSimple("57,600 bps");
    speed8 = XmStringCreateSimple("115,200 bps");
    option_menu1 = XmVaCreateSimpleOptionMenu(rc2, "option_menu1",
        speed_option_menu, NULL, speed_no, speed_option_cb,
        XmVaPUSHBUTTON, speed0, NULL, NULL, NULL,
        XmVaPUSHBUTTON, speed1, NULL, NULL, NULL,
        XmVaPUSHBUTTON, speed2, NULL, NULL, NULL,
        XmVaPUSHBUTTON, speed3, NULL, NULL, NULL,
        XmVaPUSHBUTTON, speed4, NULL, NULL, NULL,
        XmVaPUSHBUTTON, speed5, NULL, NULL, NULL,
        XmVaPUSHBUTTON, speed6, NULL, NULL, NULL,
        XmVaPUSHBUTTON, speed7, NULL, NULL, NULL,
        XmVaPUSHBUTTON, speed8, NULL, NULL, NULL,
        NULL);
    XmStringFree(speed0);
    XmStringFree(speed1);
    XmStringFree(speed2);
    XmStringFree(speed3);
    XmStringFree(speed4);
    XmStringFree(speed5);
    XmStringFree(speed6);
    XmStringFree(speed7);
    XmStringFree(speed8);
    XmStringFree(speed_option_menu);

    XtManageChild(option_menu1);

    device_option_menu = XmStringCreateSimple("Device:");
    device0 = XmStringCreateSimple("/dev/cua0");
    device1 = XmStringCreateSimple("/dev/cua1");
    device2 = XmStringCreateSimple("/dev/cua2");
    device3 = XmStringCreateSimple("/dev/cua3");
    option_menu2 = XmVaCreateSimpleOptionMenu(rc2, "option_menu2",
        device_option_menu, NULL, device_no, device_option_cb,
        XmVaPUSHBUTTON, device0, NULL, NULL, NULL,
        XmVaPUSHBUTTON, device1, NULL, NULL, NULL,
        XmVaPUSHBUTTON, device2, NULL, NULL, NULL,
        XmVaPUSHBUTTON, device3, NULL, NULL, NULL,
        NULL);
    XmStringFree(device0);
    XmStringFree(device1);
    XmStringFree(device2);
    XmStringFree(device3);
    XmStringFree(device_option_menu);

    XtManageChild(option_menu2);
    XtManageChild(rc2);
    XtManageChild(rc2_frame);

    rc2_frame = XtVaCreateManagedWidget("frame2",
        xmFrameWidgetClass, rc1,
        XmNshadowType,      XmSHADOW_ETCHED_IN,
        NULL);

    rc = XtVaCreateManagedWidget("rc",
        xmRowColumnWidgetClass,   rc2_frame,
	XmNorientation,		XmVERTICAL,
        NULL);

    rc2 = XtVaCreateManagedWidget("rc2",
        xmFormWidgetClass, rc,
        XmNheight,       32,  
        XmNfractionBase,  100,
        NULL);

    temp = XmStringCreateLocalized("pppd Directory:");
    label = XtVaCreateManagedWidget("label", 
	xmLabelGadgetClass, rc2,
    	XmNlabelString, temp,
        XmNtopAttachment,    XmATTACH_FORM,
        XmNbottomAttachment, XmATTACH_FORM,
        XmNleftAttachment,  XmATTACH_POSITION,
        XmNleftPosition,     2,
        XmNalignment,        XmALIGNMENT_END,
	NULL);
    XtManageChild(label);
    XmStringFree(temp);

    pppd_dir_w = XtVaCreateManagedWidget("pppd_dir_w", 
	xmTextFieldWidgetClass, rc2,
    	XmNvalue, 	pppd_dir,
        XmNcursorPositionVisible,   False,
        XmNtraversalOn,      True,
        XmNwidth,        200,
        XmNheight,       31, 
        XmNresizePolicy, XmNONE, 
        XmNrightAttachment,  XmATTACH_FORM,
        XmNleftAttachment,   XmATTACH_POSITION,
        XmNleftPosition,     35,
	NULL);

    XtAddCallback(pppd_dir_w, XmNfocusCallback,
            focuscallback, pppd_dir_w);

    XtManageChild(pppd_dir_w);
    XtManageChild(rc2);

    rc2 = XtVaCreateManagedWidget("rc2", 
        xmFormWidgetClass, rc,
        XmNheight,       32,    
        XmNfractionBase,  100,
        NULL);

    temp = XmStringCreateLocalized("Domain Name:");
    label = XtVaCreateManagedWidget("domain", 
        xmLabelGadgetClass, rc2,
        XmNlabelString, temp,
        XmNtopAttachment,    XmATTACH_FORM,
        XmNbottomAttachment, XmATTACH_FORM,
        XmNleftAttachment,  XmATTACH_POSITION,
        XmNleftPosition,     2,
        XmNalignment,        XmALIGNMENT_END,
        NULL);

    XtManageChild(label);
    XmStringFree(temp);

    domain_w = XtVaCreateManagedWidget("domain_w",
        xmTextFieldWidgetClass, rc2,
    	XmNvalue, 	domain,
        XmNcursorPositionVisible,   False,
        XmNtraversalOn,      True,
        XmNheight,       31,    
        XmNresizePolicy, XmNONE, 
        XmNrightAttachment,  XmATTACH_FORM,
        XmNleftAttachment,   XmATTACH_POSITION,
        XmNleftPosition,     35,
        NULL);  

    XtAddCallback(domain_w, XmNfocusCallback,
            focuscallback, domain_w);

    XtManageChild(domain_w);
    XtManageChild(rc2);

    rc2 = XtVaCreateManagedWidget("rc2",
        xmFormWidgetClass, rc,
        XmNheight,       88,
        XmNfractionBase,  100,
        NULL);

    temp = XmStringCreateLocalized("Name Server:");
    label = XtVaCreateManagedWidget("nameserver",
        xmLabelGadgetClass, rc2,
        XmNlabelString, temp,
        XmNtopAttachment,    XmATTACH_POSITION,
        XmNtopPosition,     7,
        XmNleftAttachment,  XmATTACH_POSITION,
        XmNleftPosition,     2,
        XmNalignment,        XmALIGNMENT_END,
        NULL);

    XtManageChild(label);
    XmStringFree(temp);

    nameserver_w = XtVaCreateManagedWidget("nameserver_w",
        xmTextFieldWidgetClass, rc2,
        XmNvalue,       nameserver,
        XmNcursorPositionVisible,   False,
        XmNtraversalOn,      True,
        XmNwidth,        60,
        XmNheight,       31,
        XmNresizePolicy, XmNONE,
        XmNleftAttachment,   XmATTACH_POSITION,
        XmNleftPosition,     35,
        XmNrightAttachment,   XmATTACH_POSITION,
        XmNrightPosition,     67,
        NULL);

    XtAddCallback(nameserver_w, XmNfocusCallback,
            focuscallback, nameserver_w);

    XtManageChild(nameserver_w);

    rc_list_w = XtVaCreateManagedWidget("rc_list_w",
        xmRowColumnWidgetClass, rc2,
        XmNtopAttachment,    XmATTACH_FORM,
        XmNbottomAttachment, XmATTACH_FORM,
        XmNrightAttachment, XmATTACH_FORM,
        XmNleftAttachment,   XmATTACH_POSITION,
        XmNleftPosition,     67,
	NULL);

    XtSetArg(args[0], XmNvisibleItemCount, 5);
    list_w = XmCreateScrolledList(rc_list_w, "list_w", args, 1);

        for(i=0; i<DNS_count; i++)
	    add_item(nameservers[i]);
        XtManageChild(list_w);

    rc3 = XtVaCreateManagedWidget("rc3",
        xmFormWidgetClass, rc2,
        XmNfractionBase,  5,
        XmNtopAttachment,   XmATTACH_POSITION,
        XmNtopPosition,     35,
        XmNbottomAttachment,   XmATTACH_POSITION,
        XmNbottomPosition,     70,
        XmNleftAttachment,   XmATTACH_POSITION,
        XmNleftPosition,     35,
        XmNrightAttachment,   XmATTACH_POSITION,
        XmNrightPosition,     67,
        NULL);

    btn_text = XmStringCreateSimple ("Add");
    add_pb = XtVaCreateManagedWidget("add_button",
            xmPushButtonWidgetClass, rc3,
            XmNlabelString,     btn_text,
            XmNheight,       29,
            XmNleftAttachment,   XmATTACH_FORM,
            XmNrightAttachment,  XmATTACH_POSITION,
            XmNrightPosition,    2,
            XmNalignment,        XmALIGNMENT_CENTER,
            NULL);

    XtAddCallback(add_pb, XmNactivateCallback, add_pushed, NULL);

    XmStringFree(btn_text);

    btn_text = XmStringCreateSimple ("Remove");
    remove_pb = XtVaCreateManagedWidget("remove_button",
            xmPushButtonWidgetClass, rc3,
            XmNheight,       29,
            XmNleftAttachment,  XmATTACH_POSITION,
            XmNleftPosition,    2,
            XmNrightAttachment,   XmATTACH_FORM,
            XmNlabelString,     btn_text,
            NULL);

    XtAddCallback(remove_pb, XmNactivateCallback, remove_item, NULL);
    XtSetSensitive(remove_pb, FALSE);

    XmStringFree(btn_text);

    XtManageChild(rc2);

    XtManageChild(rc2_frame);
    XtManageChild(rc);
    }
  XtManageChild(config_dialog);
}

void
help_cb(w, item_no, cbs) /* help dialog */
Widget w;
int item_no;  /* pulldown menu item number */
XmAnyCallbackStruct *cbs;  /* unused here */
{
    static Widget dialog = NULL;
    Arg           args[5];
    XmString dialog_title;

    dialog_title = XmStringCreateLocalized("Motif-PPP");
    XtSetArg(args[0], XmNdialogTitle, dialog_title);
    XtSetArg(args[1], XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL);
    XtSetArg(args[2], XmNmarginHeight, 3);

    if (item_no == 0){
    dialog = XmCreateInformationDialog(toplevel, "help_message",
                                        args, 3);
    }

    if (item_no == 1){
    dialog = XmCreateInformationDialog(toplevel, "about_message",
                                      args, 3);
    }
    XtUnmanageChild( XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON) );
    XtUnmanageChild( XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON) );
    XmStringFree(dialog_title);
    XtManageChild(dialog);
}

void
speed_option_cb(menu_item, item_no, cbs) /* setup string for speed */
Widget menu_item;
int item_no;
XmAnyCallbackStruct *cbs;
{
    speed_text = (char *) malloc (30);
    switch(item_no){
	case	0:
	   speed_text = "2400";
	   speed_no = 0;
	   break;
	case	1:
	   speed_text= "4800";
	   speed_no = 1;
	   break;
	case	2:
	   speed_text = "9600";
	   speed_no = 2;
	   break;
	case	3:
	   speed_text = "14400";
	   speed_no = 3;
	   break;
	case	4:
	   speed_text = "19200";
	   speed_no = 4;
	   break;
	case	5:
	   speed_text = "28800";
	   speed_no = 5;
	   break;
	case	6:
	   speed_text = "38400";
	   speed_no = 6;
	   break;
	case	7:
	   speed_text = "57600";
	   speed_no = 7;
	   break;
	case	8:
	   speed_text = "115200";
	   speed_no = 8;
    }
}

void
device_option_cb(menu_item, item_no, cbs) /* setup string for device */
Widget menu_item;
int item_no;
XmAnyCallbackStruct *cbs;
{
    device_text = (char *) malloc (30);
    switch(item_no){
	case	0:
	   device_text = "/dev/cua0";
	   device_no = 0;
	   break;
	case	1:
	   device_text= "/dev/cua1";
	   device_no = 1;
	   break;
	case	2:
	   device_text = "/dev/cua2";
	   device_no = 2;
	   break;
	case	3:
	   device_text = "/dev/cua3";
	   device_no = 3;
    }
}

void
config_ok_cb() /* after ok in config panel pressed, set all settings */
{
    char *temp;
    int i;
    XmString *strlist;

    *nameserver = NULL;
    *nameservers = NULL;

    XtVaGetValues(list_w,
        XmNitemCount, &DNS_count,
        XmNitems,     &strlist,
        NULL);

    for(i=0; i<DNS_count; i++){
	XmStringGetLtoR(strlist[i], charset, &temp);
    	nameservers[i] = (char *) malloc (30);
	nameservers[i] = temp;
    }

    pppd_dir = (char *) malloc (30);
    domain = (char *) malloc (30);
    speed_text = (char *) malloc (30);
    device_text = (char *) malloc (30);

    pppd_dir = XmTextFieldGetString(pppd_dir_w);
    domain = XmTextFieldGetString(domain_w);

    switch(speed_no){
	case	0:
	   speed_text = "2400";
	   break;
	case	1:
	   speed_text= "4800";
	   break;
	case	2:
	   speed_text = "9600";
	   break;
	case	3:
	   speed_text = "14400";
	   break;
	case	4:
	   speed_text = "19200";
	   break;
	case	5:
	   speed_text = "28800";
	   break;
	case	6:
	   speed_text = "38400";
	   break;
	case	7:
	   speed_text = "57600";
	   break;
	case	8:
	   speed_text = "115200";
    }
    switch(device_no){
	case	0:
	   device_text = "/dev/cua0";
	   break;
	case	1:
	   device_text= "/dev/cua1";
	   break;
	case	2:
	   device_text = "/dev/cua2";
	   break;
	case	3:
	   device_text = "/dev/cua3";
    }
}

void
destroy_widget(widget) /* destroy widget */
Widget widget;
{
    XtDestroyWidget(widget);
    /*unlink(file_chat);
    unlink(file_resolv_conf);
    unlink(file_options);*/
}

void
config_help_dialog() /* config help will appear */
{
    static Widget dialog = NULL;
    Arg           args[5];
    XmString dialog_title;
    int           n;

    dialog_title = XmStringCreateLocalized("Motif-PPP");
    XtSetArg(args[0], XmNdialogTitle, dialog_title);
    XtSetArg(args[1], XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL);
    XtSetArg(args[2], XmNmarginHeight, 3);
    dialog = XmCreateInformationDialog(toplevel, "config_help_message",
                                      args, 3);
    XtUnmanageChild( XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON) );
    XtUnmanageChild( XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON) );
    XmStringFree(dialog_title);
    XtManageChild(dialog);
}

void
create_files() /* creates files used for pppd to be executed */
{
    FILE *outfile;
    int  i;
    char *buf[BUFSIZ];

    unlink(file_chat);
    unlink(file_resolv_conf);
    unlink(file_options);

    phone_number = (char *) malloc (30);
    phone_number = XmTextFieldGetString(phone_number_w);
    login_name = (char *) malloc (30);
    login_name = XmTextFieldGetString(login_name_w);

    /* Make a file "/etc/ppp/chat" */
    *buf = NULL;
    if ((outfile = open(file_chat,
        O_WRONLY|O_CREAT, 0744)) < 0){
        printf("open failed.");
        exit(0);
    }
    for(i=0; i<20; i++){
    if(i == 4)
	strcat(buf, pppd_dir);
/* comment out for high speed modem setting. */
/*    if(i == 7)
	strcat(buf, speed_text);*/
    strcat(buf, chat_tmpl[i]);
    if(i == 1){
	strcat(buf, phone_number);
	strcat(buf, "\n");
	}
    if(i == 2){
	strcat(buf, login_name);
	strcat(buf, "\n");
	}
    if(i == 3){
	strcat(buf, passwd);
	strcat(buf, "\n");
	}
    }
    write(outfile, buf, strlen(buf));
    close(outfile);

    /* Make a file "/etc/resolv.conf" */
    *buf = NULL;
    if ((outfile = open(file_resolv_conf,
        O_WRONLY|O_CREAT, 0644)) < 0){
        printf("open failed.");
        exit(0);
    }

    strcat(buf, resolv_conf_tmpl[0]);
    strcat(buf, " ");
    strcat(buf, domain);
    strcat(buf, "\n");

    strcat(buf, resolv_conf_tmpl[1]);
    strcat(buf, " ");
    strcat(buf, domain);
    strcat(buf, "\n");

    for(i=0; i<DNS_count; i++){
        strcat(buf, resolv_conf_tmpl[2]);
        strcat(buf, " ");
        strcat(buf, nameservers[i]);
	strcat(buf, "\n");
    }

    write(outfile, buf, strlen(buf));
    close(outfile);

    /* Make a file "/etc/ppp/options" */
    *buf = NULL;
    if ((outfile = open(file_options,
        O_WRONLY|O_CREAT, 0644)) < 0){
        printf("open failed.");
        exit(0);
    }
    for(i=0; i<5; i++){
    if(i == 0){
        strcat(buf, device_text);
	strcat(buf, " ");
        strcat(buf, speed_text);
        }
    strcat(buf, options_tmpl[i]);
    }
    write(outfile, buf, strlen(buf));
    close(outfile);
}

void
create_error_dialog() /* creates error dialog for non-entry field */
{
    Widget        error_dialog;
    XmString      dialog_title;
    Arg           args[10];

    dialog_title = XmStringCreateLocalized("Motif-PPP");
    XtSetArg(args[0], XmNdialogTitle, dialog_title);
    XtSetArg(args[1], XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL);
    XtSetArg(args[2], XmNmarginHeight, 3);
    error_dialog = XmCreateErrorDialog(toplevel, "error_message", args, 3);
    XtAddCallback(error_dialog, XmNokCallback,
            (XtCallbackProc) destroy_widget, error_dialog);
    XmStringFree(dialog_title);
    XtUnmanageChild( XmMessageBoxGetChild (error_dialog,
          XmDIALOG_HELP_BUTTON) );
    XtUnmanageChild( XmMessageBoxGetChild (error_dialog,
          XmDIALOG_CANCEL_BUTTON) );
    XtManageChild(error_dialog);
    XtPopup(XtParent(error_dialog), XtGrabNone);
}

void
connect_pushed(w, cbs) /* process when connect button pressed */
XmAnyCallbackStruct *cbs;  /* unused here */
{
    char    *cat_cmd,
            *cmd = "/pppd",
            *buf[BUFSIZ];
    FILE    *pp, *popen();
    int	    interrupted = False, count=0, item_count;

    if(access("/var/run/ppp0.pid", 0) == 0){
        printf("\n/var/run/ppp0.pid exists.\n");
        printf("Another pppd might be running.\n");
        exit(0);
    }

    create_files();
   
    /*XtVaGetValues(list_w, XmNitemCount, &item_count, NULL);*/
    if(*phone_number == NULL || *login_name == NULL ||
        	*passwd == NULL || *pppd_dir == NULL ||
		*domain == NULL || *nameservers == NULL)
       create_error_dialog();
    else{
       *buf = NULL;
       strcat(buf, pppd_dir);
       cat_cmd = (char *) malloc (30);
       cat_cmd = strcat(buf, cmd);
       /*if (!(pp = popen(cat_cmd, "w"))) {
          fprintf(stderr, "Can't execute");
          perror(cat_cmd);
          return;
       }*/
       if((pppd_pid = fork()) < 0){
	  perror("fork");
	  exit(1);
       }
       if(pppd_pid == 0){
	  execl(cat_cmd, "", NULL);
	  perror("exec");
	  exit(1);
       }
       while(wait((int *) 0) != pppd_pid);
	  
       timeout_cursors(True, True);
       while(access("/var/run/ppp0.pid", 0) != 0){
          sleep(1);
	  count++;
	  if(count == 60)
	      time_out();
          if (check_for_interrupt()) {
	      interrupted = True;
              /*puts("Interrupt!");*/
              XtDestroyWidget(wait_dialog);
              break;
          }
       }
       if(!interrupted){
          XtDestroyWidget(wait_dialog);
          ppp_connected();
       }
       timeout_cursors(False, NULL);
    }
}

static Boolean stopped;

void
timeout_cursors(on, interruptable) /* process during pppd executing */
int on, interruptable;
{
    static int locked;
    static Cursor cursor;
    XSetWindowAttributes attrs;
    Display *dpy = XtDisplay(toplevel);
    XEvent event;
    Arg args[10];
    XmString  dialog_title, stop_text, message_text;

    on? locked++ : locked--;
    if (locked > 1 || locked == 1 && on == 0)
        return;

    stopped = False;
    if (!cursor)
        cursor = XCreateFontCursor(dpy, XC_watch);

    attrs.cursor = on? cursor : None;

    XChangeWindowAttributes(dpy, XtWindow(toplevel), CWCursor, &attrs);

    XFlush(dpy);

    if (on) {
        dialog_title = XmStringCreateLocalized("Motif-PPP");
        message_text = XmStringCreateSimple("Trying to make a connection...");
        XtSetArg(args[0], XmNdialogTitle, dialog_title);
        XtSetArg(args[1], XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL);
        XtSetArg(args[2], XmNmessageString, message_text);
        XtSetArg(args[3], XmNmarginHeight, 3);

        wait_dialog = XmCreateWorkingDialog(toplevel, "working", args, 4);

        XtUnmanageChild(  /* no need for the ok button */
           /*XmMessageBoxGetChild(wait_dialog, XmDIALOG_OK_BUTTON));*/
           XmMessageBoxGetChild(wait_dialog, XmDIALOG_CANCEL_BUTTON));
        if (interruptable) {
            stop_text = XmStringCreateSimple("Cancel");
            /*XtVaSetValues(wait_dialog, XmNcancelLabelString, stop_text, NULL);*/
            XtVaSetValues(wait_dialog, XmNokLabelString, stop_text, NULL);
            XmStringFree(stop_text);
            XtAddCallback(wait_dialog, XmNokCallback,
		kill_pppd, NULL);
        } else
        XtUnmanageChild(
                /*XmMessageBoxGetChild(wait_dialog, XmDIALOG_OK_BUTTON));*/
                XmMessageBoxGetChild(wait_dialog, XmDIALOG_CANCEL_BUTTON));
        XtUnmanageChild(  /* no need for the help button */
           XmMessageBoxGetChild(wait_dialog, XmDIALOG_HELP_BUTTON));
        XtManageChild(wait_dialog);
        } else {
            while (XCheckMaskEvent(dpy,
                ButtonPressMask | ButtonReleaseMask | ButtonMotionMask
                | PointerMotionMask | KeyPressMask, &event)) {;
            }
          XtDestroyWidget(wait_dialog);
          }
}

Boolean
check_for_interrupt() /* checks cancellation during pppd executing */
{
    Display *dpy = XtDisplay(toplevel);
    Window win = XtWindow(wait_dialog);
    XEvent event;

    /* Make sure all our requests get to the server */
    XFlush(dpy);

    /* Let motif process all pending exposure events for us. */
    XmUpdateDisplay(toplevel);

    /* Check the event loop for events in the dialog ("Stop"?) */
    while (XCheckMaskEvent(dpy,
            ButtonPressMask | ButtonReleaseMask | ButtonMotionMask |
            PointerMotionMask | KeyPressMask | KeyReleaseMask, &event)) {
        /* got an "interesting" event. */
        if (event.xany.window == win)
            XtDispatchEvent(&event); /* it's in our dialog.. */
        else /* uninteresting event--throw it away and sound bell */
            XBell(dpy, 50);
    }
    return stopped;
}

void
ppp_connected(w) /* when ppp connected */
Widget w;
{
    Widget dialog, main_w, frame, frame2, rc2, rc3, pixmap, text, form,
           label, rc, pb;
    XmString btn_text;
    Arg args[10];
    Display *display;

    XtUnmapWidget(toplevel);

    display = XtDisplay(toplevel);

    XtSetArg(args[0], XmNscreen, ScreenOfDisplay(display, 0));
    XtSetArg(args[1], XmNtitle,  "Motif-PPP");
    XtSetArg(args[2], XmNdeleteResponse, XmDESTROY);
    XtSetArg(args[3], XmNwidth,        315);
    XtSetArg(args[4], XmNheight,       75);
    dialog = XtCreatePopupShell("Motif-PPP", 
	topLevelShellWidgetClass, toplevel, args, 5);

    main_w = XtVaCreateManagedWidget("main_w",
        xmRowColumnWidgetClass,   dialog,
        XmNorientation,         XmVERTICAL,
        NULL);

    frame = XtVaCreateManagedWidget("frame",
        xmFrameWidgetClass, main_w,
        XmNshadowType,      XmSHADOW_ETCHED_IN,
        NULL);

    rc2 = XtVaCreateManagedWidget("dialog_rc",
        xmRowColumnWidgetClass,   frame,
        XmNorientation,         XmHORIZONTAL,
        NULL);

    form = XtVaCreateWidget("form", xmFormWidgetClass, rc2,
        XmNfractionBase,  100,
        NULL);

    label = XtVaCreateManagedWidget("Time Elapsed:", 
	xmLabelWidgetClass, form,
        XmNtopAttachment,    XmATTACH_FORM,
        XmNbottomAttachment, XmATTACH_FORM,
        XmNleftAttachment,  XmATTACH_POSITION,
        XmNleftPosition,     8,
        XmNalignment,        XmALIGNMENT_END,
        NULL);

    frame2 = XtVaCreateManagedWidget("dialog_frame2",
        xmFrameWidgetClass, form,
        XmNshadowType,      XmSHADOW_IN,
        XmNleftAttachment,  XmATTACH_POSITION,
        XmNleftPosition,     80,
        XmNheight,        38,
        XmNalignment,        XmALIGNMENT_END,
        NULL);

    rc3 = XtVaCreateManagedWidget("dialog_rc",
        xmRowColumnWidgetClass,   frame2,
        NULL);

    timer = XtVaCreateManagedWidget ("timer",
        xmLabelWidgetClass, rc3,
        XmNalignment,        XmALIGNMENT_END,
        NULL);

    rc = XtVaCreateWidget("rc", 
        xmFormWidgetClass, main_w, 
        NULL);

    btn_text = XmStringCreateSimple ("Disconnect");
    pb = XtVaCreateManagedWidget("button", 
            xmPushButtonWidgetClass, rc, 
            XmNheight,       29,  
            XmNleftAttachment, XmATTACH_FORM,
            XmNrightAttachment, XmATTACH_FORM,
            XmNlabelString,     btn_text,
            XmNalignment,        XmALIGNMENT_CENTER,
            NULL);

    XtAddCallback(pb, XmNactivateCallback, disconnect_pushed, NULL);

    XmStringFree(btn_text);
    XtManageChild(rc);
    XtManageChild(pb);
    XtManageChild(form);

    XtManageChild(main_w);

    time(&start_time);
    update_time(timer, NULL);

    XtPopup(dialog, XtGrabNone);
}

void
disconnect_pushed() /* when disconnect button pressed */
{
   char    *cat_cmd,
	   *cmd = "/ppp-off",
           *buf[BUFSIZ];
   FILE    *pp, *popen();

   *buf = NULL;
   strcat(buf, pppd_dir);
   cat_cmd = (char *) malloc (30);
   cat_cmd = strcat(buf, cmd);
   if (!(pp = popen(cat_cmd, "w"))) {
      fprintf(stderr, "Can't execute");
      perror(cat_cmd);
      return;
    }

    exit(0);
}

void
xs_wprintf(va_alist) /* puts string in X dialog */
    va_dcl
{
    Widget	w;
    char	*format;
    va_list	args;
    char	str[1000];
    Arg		wargs[10];
    XmString	xmstr;

    va_start(args);

    w = va_arg(args, Widget);
    if(!XtIsSubclass(w, xmLabelWidgetClass))
	XtError("xs_wprintf() requires a Label Widget");

    format = va_arg(args, char *);

    vsprintf(str, format, args);
    xmstr = XmStringLtoRCreate(str, XmSTRING_DEFAULT_CHARSET);

    XtSetArg(wargs[0], XmNlabelString, xmstr);
    XtSetValues(w, wargs, 1);

    XmStringFree(xmstr);

    va_end(args);
}

void
update_time(w, id) /* counting for timer, 1 sec */
Widget w;
XtIntervalId id;
{
    long elapsed_time, time_interval = 1000;
    int hours, minutes, seconds, current_time;

    time(&current_time);
    elapsed_time = current_time - start_time;
    hours = (elapsed_time / (60 * 60)) % 12;
    minutes = (elapsed_time / 60) % 60;
    seconds = elapsed_time % 60;
    if (access("/var/run/ppp0.pid", 0) == 0){
       xs_wprintf(timer, "%02d:%02d:%02d", hours, minutes, seconds);
       XtAppAddTimeOut(app, time_interval, update_time, NULL);
    }
    else{
       exit(0);
    }
}

void
get_values() /* gets values from existing files */
{
    FILE *infile;
    int i=0, j=0, k=0, l=0, m=0,
	line=0, space=0,
	first_equal_phone, first_equal_user, first_equal_passwd;
    char c, *temp;


    phone_number = (char *) malloc (30);
    login_name = (char *) malloc (30);
    pppd_dir = (char *) malloc (30);
    domain = (char *) malloc (30);
    nameserver = (char *) malloc (30);
    passwd = (char *) malloc (30);
    astr_passwd = (char *) malloc (30);
    speed_text = (char *) malloc (30);
    device_text = (char *) malloc (30);

    if ((infile = fopen(file_resolv_conf, "r")) != NULL){
       while ((c = getc(infile)) != EOF){
	  if(c == ' ')
	     space++;
	  if(c == '\n')
	     line++;
	  if(space == 1 && line == 0 && c != ' '){
	     domain[i] = c;
	     i++;
	  }
	  if(space == 2 && c == '\n')
	     domain[i] = NULL;
	  if(space >= DNS_count+3 && line >= DNS_count+2 && c != ' '){
	     nameserver[j] = c;
	     j++;
	  }
	  if(space >= DNS_count+3 && line >= DNS_count+3){
	     nameserver[j-1] = NULL;
    	     temp = (char *) malloc (30);
	     strcpy(temp, nameserver);
    	     nameservers[DNS_count] = (char *) malloc (30);
	     nameservers[DNS_count] = temp;
	     DNS_count++;
	     j=0;
	  }
       }
    fclose(infile);
    }
    else{
	domain[0] = NULL;
	nameserver[0] = NULL;
	nameservers[0] = NULL;
    }

    line = 0;
    i=0;
    j=0;
    k=0;
    first_equal_phone = FALSE;
    first_equal_user = FALSE;
    first_equal_passwd = FALSE;

    if ((infile = fopen(file_chat, "r")) != NULL){
       while ((c = getc(infile)) != EOF){
	  if(c == '\n'){
	     line++;
	  }
	  if(line == 1 && c == '=')
	     first_equal_phone = TRUE;
	  if(first_equal_phone && c != '\n'){
	     phone_number[i] = c;
	     i++;
	  }
	  if(line == 2 && c == '\n'){
	     phone_number[i] = NULL;
	     first_equal_phone = FALSE;
             for(m=0; m<=i; m++)
                phone_number[m] = phone_number[m+1];
	  }
	  if(line == 2 && c == '=')
	     first_equal_user = TRUE;
	  if(first_equal_user && c != '\n'){
	     login_name[j] = c;
	     j++;
	  }
	  if(line == 3 && c == '\n'){
	     login_name[j] = NULL;
	     first_equal_user = FALSE;
             for(m=0; m<=j; m++)
                login_name[m] = login_name[m+1];
	  }
	  if(line == 3 && c == '=')
	     first_equal_passwd = TRUE;
	  if(first_equal_passwd && c != '\n'){
	     passwd[k] = c;
	     astr_passwd[k] = '*';
	     k++;
	  }
	  if(line == 4 && c == '\n'){
	     passwd[k] = NULL;
	     astr_passwd[k] = NULL;
	     first_equal_passwd = FALSE;
             for(m=0; m<=k; m++){
                passwd[m] = passwd[m+1];
                astr_passwd[m] = astr_passwd[m+1];
	     }
	  }
	  if(line == 4 && c != '\n'){
	     pppd_dir[l] = c;
	     l++;
	     if(line == 4 && c == '\\')
	        pppd_dir[l-7] = NULL;
	  }
       }
    fclose(infile);
    }
    else{
	phone_number[0] = NULL;
	login_name[0] = NULL;
	pppd_dir[0] = NULL;
	passwd[0] = NULL;
	astr_passwd[0] = NULL;
    }
    space = 0;
    line = 0;
    i=0;
    j=0;
    if ((infile = fopen(file_options, "r")) != NULL){
       while ((c = getc(infile)) != EOF){
          if(c == ' ')
             space++;
	  if(c == '\n')
	     line++;
	  if(space == 0 && line == 0){
	     device_text[i] = c;
	     i++;
	  }
	  if(space == 1 && line == 0){
	     speed_text[j] = c;
	     j++;
	  }
       }
    device_text[i] = NULL;
    speed_text[j] = NULL;
    for(m=0; m<=j; m++)
       speed_text[m] = speed_text[m+1];
    fclose(infile);
    }
    else{
	device_text[0] = NULL;
	speed_text[0] = NULL;
    }

    if(strcmp(speed_text, "2400") == 0) speed_no = 0;
    if(strcmp(speed_text, "4800") == 0) speed_no = 1;
    if(strcmp(speed_text, "9600") == 0) speed_no = 2;
    if(strcmp(speed_text, "14400") == 0) speed_no = 3;
    if(strcmp(speed_text, "19200") == 0) speed_no = 4;
    if(strcmp(speed_text, "28800") == 0) speed_no = 5;
    if(strcmp(speed_text, "38400") == 0) speed_no = 6;
    if(strcmp(speed_text, "57600") == 0) speed_no = 7;
    if(strcmp(speed_text, "115200") == 0) speed_no = 8;

    if(strcmp(device_text, "/dev/cua0") == 0) device_no = 0;
    if(strcmp(device_text, "/dev/cua1") == 0) device_no = 1;
    if(strcmp(device_text, "/dev/cua2") == 0) device_no = 2;
    if(strcmp(device_text, "/dev/cua3") == 0) device_no = 3;
}

void
set_cursor_position_last(widget) /* set cursor position last */
Widget widget;
{
       XmTextSetCursorPosition(widget, 
		XmTextGetLastPosition(widget));
}

void
focuscallback(widget) /* adjusts focus window cursor */
Widget widget;
{

    if(widget == phone_number_w){
       set_cursor_position_last(phone_number_w);
       XtVaSetValues(login_name_w, XmNcursorPositionVisible, False, NULL);
       XtVaSetValues(passwd_w, XmNcursorPositionVisible, False, NULL);
    }
    if(widget == login_name_w){
       set_cursor_position_last(login_name_w);
       XtVaSetValues(phone_number_w, XmNcursorPositionVisible, False, NULL);
       XtVaSetValues(passwd_w, XmNcursorPositionVisible, False, NULL);
    }
    if(widget == passwd_w){
       set_cursor_position_last(passwd_w);
       XtVaSetValues(phone_number_w, XmNcursorPositionVisible, False, NULL);
       XtVaSetValues(login_name_w, XmNcursorPositionVisible, False, NULL);
    }
    if(widget == pppd_dir_w){
       set_cursor_position_last(pppd_dir_w);
       XtVaSetValues(domain_w, XmNcursorPositionVisible, False, NULL);
       XtVaSetValues(nameserver_w, XmNcursorPositionVisible, False, NULL);
    }
    if(widget == domain_w){
       set_cursor_position_last(domain_w);
       XtVaSetValues(pppd_dir_w, XmNcursorPositionVisible, False, NULL);
       XtVaSetValues(nameserver_w, XmNcursorPositionVisible, False, NULL);
    }
    if(widget == nameserver_w){
       set_cursor_position_last(nameserver_w);
       XtVaSetValues(pppd_dir_w, XmNcursorPositionVisible, False, NULL);
       XtVaSetValues(domain_w, XmNcursorPositionVisible, False, NULL);
    }
    XtVaSetValues(widget, XmNcursorPositionVisible, True, NULL);
}

void
kill_pppd() /* kills pppd */
{
   char    *cmd = "kill `ps -xj | grep -v \"grep\" | egrep \"chat|pppd\" | awk '{print $2}'`";
   FILE    *pp, *popen();

   stopped = True;

   if (!(pp = popen(cmd, "w"))) {
      fprintf(stderr, "Can't execute");
      perror(cmd);
      return;
    }
}

void
time_out() /* dialog after 30 sec in pppd not made */
{
    static Widget dialog = NULL;
    Arg           args[5];
    XmString dialog_title;

    XtDestroyWidget(wait_dialog);
    kill_pppd();

    dialog_title = XmStringCreateLocalized("Motif-PPP");
    XtSetArg(args[0], XmNdialogTitle, dialog_title);
    XtSetArg(args[1], XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL);
    XtSetArg(args[2], XmNmarginHeight, 3);

    dialog = XmCreateErrorDialog(toplevel, "timeout_message",
                                      args, 3);
    XtUnmanageChild( XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON) );
    XtUnmanageChild( XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON) );
    XmStringFree(dialog_title);
    XtManageChild(dialog);
}

void
add_pushed() /* add button pushed for adding DNS */
{
    char *item = XmTextFieldGetString(nameserver_w);
    add_item(item);
}

void
add_item(newtext) /* adds DNS no to list box */
char *newtext;
{
    char *text, *temp;
    XmString str, *strlist;
    int u_bound, l_bound = 0, no_add = False;


    /* newtext is the text typed in the TextField widget */
    if (!newtext || !*newtext) {
        /* non-null strings must be entered */
        XtFree(newtext);  /* XtFree() checks for NULL */
        return;
    }
    /* get the current entries (and number of entries) from the List */
    XtVaGetValues(list_w,
        XmNitemCount, &u_bound,
        XmNitems,     &strlist,
        NULL);
    u_bound--;
    /* perform binary search */
    while (u_bound >= l_bound) {
        int i = l_bound + (u_bound - l_bound)/2;
        /* convert the compound string into a regular C string */
        if (!XmStringGetLtoR(strlist[i], charset, &text))
            break;
        if (strcmp(text, newtext) > 0)
            u_bound = i-1; /* newtext comes before item */
        else
            l_bound = i+1; /* newtext comes after item */
        if (strcmp(text, newtext) == 0)
	    no_add = True;
        XtFree(text); /* XmStringGetLtoR() allocates memory ... yuk */
    }

    str = XmStringCreateSimple(newtext); /* convert text to compound string
####*/
    	     temp = (char *) malloc (30);
	     strcpy(temp, newtext);
    	     nameservers[l_bound] = (char *) malloc (30);
	     nameservers[l_bound] = temp;
    
    XtFree(newtext);
    /* positions indexes start at 1, so increment accordingly */
    if(!no_add)
        XmListAddItemUnselected(list_w, str, l_bound+1);
    XmStringFree(str);
    XmTextFieldSetString(nameserver_w, "");
    XtAddCallback(list_w, XmNbrowseSelectionCallback,
	get_selected_item_number, NULL);
    no_add = False;
}

void
get_selected_item_number(list_w, client_data, cbs) /* get sellected item no in DNS list box */
Widget list_w;
XtPointer client_data;
XmListCallbackStruct *cbs;
{
	item_selected = True;
	XtSetSensitive(remove_pb, TRUE);
	selected_item = cbs->item_position;
}

void
remove_item() /* remove DNS not needed */
{
	if(item_selected){
	    XmListDeletePos(list_w, selected_item);
	}
	item_selected = False;
        XmTextFieldSetString(nameserver_w, "");
}
