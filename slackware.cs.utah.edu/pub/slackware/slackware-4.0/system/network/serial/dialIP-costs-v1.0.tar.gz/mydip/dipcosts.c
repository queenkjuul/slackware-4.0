/************************************************************************
All files distributed in this package are
Copyright (c) 1996 by H. Lucic <lucich@fly.cc.fer.hr>
ALL RIGHTS RESERVED.

Permission to use, copy, and distribute this software in its entirety
for non-commercial purposes and without fee, is hereby granted, provided
that the above copyright notice and this permission notice appear
in all copies and their documentation.

This software is provided "as is" without expressed or implied
warranty of any kind.

*************************************************************************/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>

#define COST_PER_UNIT 0.21
#define CURRENCY "Kn "
#define DIP_FILE "/etc/dip.pid"
#define PROVIDER1 "hpt"     /* use lower case for providers */
#define PROVIDER2 "srce"
#define TMP_PID_FILE "/tmp/dip-costs.pid"
#define TOTAL_FILE ".dip-costs"

	void go_time(void);
	void term_signal_handler(int);
	void hup_signal_handler(int);
	void reset_time(void);
	void time_on_line(void);
	void take_price(char *);
	void take_look_on_your_file(char);
        void outfit (void);
	
	typedef struct tm CURRENT_TIME;
        
pid_t my_pid;   /* this program pid */
CURRENT_TIME *current_time; /* as it says for itself */ 
char filename[80]; /* TMP_PID_FILE */
long now,impuls = 1; 
long units = 0;         /* how long a 1 imp.  takes*/
short secs = 0;   /* counting variables */  
short mins = 0;
short hrs = 0;
long tics = 1;        /* same as secs, auxiliary */
float money = COST_PER_UNIT;


 int main (int argc,char *argv[])
 {
   FILE *dip_file,*fp_pid,*fp_ps;
   char provider[10];   /* your providers */
   char *pok; /* miscelanous */
   char pid_chr[12];
   char ps_filename[64];
   
   
      
      
 	if (argc != 2) {
 	  	fprintf(stderr,"\nUsage: dialIP-costs provider-name\n");
 	  	fprintf(stderr,"for more suitable output start it with \"dipc\"\n");
 	  	sleep(2);
 	  return 1;
       }
       
      my_pid = getpid();   /* get this process ID ?*/
      sprintf(filename,"%s/" TOTAL_FILE, getenv("HOME")); /* your calculation file */
     strcpy(provider,argv[1]);
     pok = provider;
     while (*pok != '\0') {
     	*pok = (char) tolower(*pok);
     	pok++;
     	}
     	 if(strcmp(provider,PROVIDER1) && strcmp(provider,PROVIDER2)) {
		fprintf(stderr,"Wrong provider name !");
 	  	sleep(5);
 	  return 1;
 	 }
      if ((fp_pid = fopen(TMP_PID_FILE,"r"))) {
          fprintf(stderr,"File "TMP_PID_FILE" exists.\nProccess already running!\n");
          fprintf(stderr,"Delete it.");
          sleep(6);
        return(1);
      }      
    if (!(fp_pid = fopen(TMP_PID_FILE,"w"))) {
          fprintf(stderr,"Can not create "TMP_PID_FILE"\n");
          sleep(4);
        return(1);
     }  
    fprintf(fp_pid,"%d",my_pid);
    fclose(fp_pid); 
     
     signal(SIGTERM,term_signal_handler); /* I wanna use my signals here */
     signal(SIGHUP,hup_signal_handler);  /* I hope that something would 
                                	not overide this */
     outfit(); 		/* display screen */
    
        
  /* main loops here !!!!! */
 
 shit_happens:   
 
    while(1) { 
            	           	
             	while( !(dip_file = fopen(DIP_FILE,"r")) ) {
                   sleep(1);   
		     ;     /*  what are you doing here ?? :-))))) */
                  		/* loop here while you are down */
    	        }
        fgets(pid_chr,12,dip_file); 
     	fclose(dip_file);
                strcpy(ps_filename,"/proc/");
                strcat(ps_filename,pid_chr);
                strcat(ps_filename,"/stat");
                  if ( !(fp_ps = fopen(ps_filename,"r")))
                  	 goto shit_happens; /* lets gamble here :-)()()*/
                 
            fclose(fp_ps);     
    
    	while((fp_ps = fopen(ps_filename,"r")) ) {  /* I don't know how to check this */
    		fclose(fp_ps);		    /*  file 's exictance */
    		take_price(provider);  /* take this because time is changing */
    		;     /* take some 1mic.sec and do notning, loop here while you are up */ 
    		sleep(1);
    		go_time();
          }
             	
       take_look_on_your_file(0);   /* put some values in your file */
      reset_time();   /* & other variables */ 
      outfit(); 		/* display screen */
 
    }
 return 0;
 }
 
 /*-------------------------------------------------------------------------------
        	Change it , for your provider's costs 
 ---------------------------------------------------------------------------------*/                
 void take_price(char *provider)
 {
   	time(&now);
   	current_time = localtime(&now);
   	if (!strcmp(provider,PROVIDER1)) {    /* I'm using 2 providers */ 
                units = 30;  /* 0.5 min */
   	 }				   
   	if (!strcmp(provider,PROVIDER2)) {
   	    if( current_time->tm_wday == 0 || current_time->tm_wday == 6 )
		 units = 360;  /* 6 min */
	     else {                         /* at different time, different prices */ 
	          if(current_time->tm_hour > 21 || current_time->tm_hour < 7)
	              units = 360;   /* 6 min */
	          if(current_time->tm_hour > 15 && current_time->tm_hour < 22)
	             units = 240;    /* 4 min */
	          if(current_time->tm_hour > 6 && current_time->tm_hour < 16)
	             units = 180;    /* 3 min */
	     }
	}     	    	       
     
 return;
 }
 
 void time_on_line(void)
 {
   fprintf(stderr,"ONLINE: %.2ld:%.2ld:%.2ld  (%.3ld impuls, %6.2f "CURRENCY")\r",hrs,mins,secs,impuls,money);
   
 return;
 }
 
 void reset_time(void) /* and money ! */
 {
  secs = -1;    /* here he swallows 1 sec, but what a hell */
  mins = 0;	/* it looks better on the screen	*/
  hrs = 0;
  money = COST_PER_UNIT;
  impuls = 1;
  tics = 0;    /* tics were preety shitty for debugging !?@#@ */
   
   return;
 }

 
 void go_time(void)
 {
      if(tics/units) {
      	    tics = 0;
      	    impuls++;
      	    money += COST_PER_UNIT;
      	 }   
	
    	secs++; tics++;
    	if (secs == 60) {
    		secs = 0;
    		mins++;
    		}
    	if (mins == 60) {
    		mins = 0;
    		hrs++;
    		}
    	if(hrs == 24) hrs = 0;
    	time_on_line();    /* show online time */
    					
  return;
 }    
 
/* ---------------------------------------------------------------------
	   	When any of these signals arrive ,
	                  do a clean-up .
------------------------------------------------------------------------*/	   	
 void term_signal_handler(sig) 
  {
     remove(TMP_PID_FILE);
     take_look_on_your_file(1); /* what if signal come when you at least expect */
     signal(sig,SIG_DFL);   
     kill(my_pid,SIGTERM);

    return;
  }
  
  void hup_signal_handler(sig) 
  {
     remove(TMP_PID_FILE);
     take_look_on_your_file(1); /* what if signal come when you at least expect */
     signal(sig,SIG_DFL);  
     kill(my_pid,SIGHUP);
     
    return;
  }
  
  void take_look_on_your_file(char flag)
  {
   FILE *fp_costs;    /* your $(HOME)/.dip-costs file */
   long old_impuls = 0;
   float old_money = 0;
    	
     /* if there isn't any , creat it !! */	
   if( (fp_costs = fopen(filename,"rb")) != NULL) {
       fscanf(fp_costs,"%ld\n%f",&old_impuls,&old_money);
       fprintf(stderr,"%.6ld impuls,%7.2f "CURRENCY"\n",old_impuls,old_money);
       fclose(fp_costs);  
      }  
     if( (fp_costs = fopen(filename,"wb")) == NULL) {
         fprintf(stderr,"Could not open HOME/"TOTAL_FILE"\n");
        return;
        }

     impuls += old_impuls;
     money += old_money;
                                                	/* don't cheat here ! */
     if(flag) fprintf(fp_costs,"%.6ld\n%7.2f\n",impuls - 1,money - COST_PER_UNIT); 
     else fprintf(fp_costs,"%.6ld\n%7.2f\n",impuls,money);   /* Are you going to shoot out 
                                               over a milion impulses over mounth ? :-(( */
   fflush(NULL);		/* Flush all that shit ! */
   fclose(fp_costs);
   
  return;
  }
  
 void outfit (void)
 {

  FILE *fp_costs;    /* your $(HOME)/.dip-costs file */
  long old_impuls = 0;
  float old_money = 0;
  
      fprintf(stderr, "\"dialIP - Costs\" 1.0 (c) @Luciano ,Dec.'96\n");
      fprintf(stderr, "Total: ");
       
        if( (fp_costs = fopen(filename,"rb")) != NULL) {
           fscanf(fp_costs,"%ld\n%f",&old_impuls,&old_money);
           fclose(fp_costs); 
         }
         
      fprintf(stderr,"%.6ld impuls,%7.2f "CURRENCY"\n",old_impuls,old_money);
      fprintf(stderr,"Offline.\r");     
      
  return;
 }     
