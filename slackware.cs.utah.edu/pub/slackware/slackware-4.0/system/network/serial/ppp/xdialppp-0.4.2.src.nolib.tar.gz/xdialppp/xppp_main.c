#include "forms.h"
#include "xppp.h"

int main(int argc, char *argv[])
{

   fl_initialize(&argc, argv, 0, 0, 0);

   create_the_forms();

   initializeForms();


   /* show the first form */

   fl_show_form(xppp_launch,FL_PLACE_CENTER,FL_FULLBORDER,"Xdialppp");

   fl_do_forms();
   return 0;
}
