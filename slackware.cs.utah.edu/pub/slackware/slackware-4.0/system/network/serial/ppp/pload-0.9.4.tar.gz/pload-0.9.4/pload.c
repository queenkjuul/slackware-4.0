/*
    This file is part of pload - a program to monitor ppp activity for X
    Copyright (C) 1999  Matt Smith <mdsmith@engr.utk.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/StringDefs.h>
#include <X11/Xaw/Cardinals.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/StripChart.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "pload.h"
#include "pload.xbm"

/************* Function Prototypes ********/
void GetIChartPoint(Widget,XtPointer,XtPointer);
void GetOChartPoint(Widget,XtPointer,XtPointer);
void Usage(void);
void HandleExit(void);
void CheckForWMExit(Widget, XtPointer, XEvent*, Boolean*);
void CheckForIconState(Widget, XtPointer, XEvent*, Boolean*);
void update(XtPointer, XtIntervalId*);


/************* Global Variables **********/
static char		progver[]= VERSION;
static char		buff[128];
static if_data 		ifd;
static XtAppContext 	context;
static Widget		toplevel, topform, iform, oform;
static Widget		ilabel, ichart, ochart, olabel;
static Arg		arglist[8];
static int		i;
static Atom 		wm_delete_window;
static char		*Progname;
static int		iconstate;
static XrmOptionDescRec options[] =
{
{"-minscale",	"*minScale",		XrmoptionSepArg,	NULL},
{"-indiv",	"*inDiv",		XrmoptionSepArg,	(XtPointer)1024},
{"-outdiv",	"*outDiv",		XrmoptionSepArg,	(XtPointer)1024},
{"-hl",		"*highlight",		XrmoptionSepArg,	NULL},
{"-jumpscroll",	"*jumpScroll",		XrmoptionSepArg,	NULL},
{"-update",	"*update",		XrmoptionSepArg,	NULL},
{"-in",		"*showOut",		XrmoptionNoArg,		"False"},
{"-out",	"*showIn",		XrmoptionNoArg,		"False"},
{"-nolabel",	"*showLabel",		XrmoptionNoArg,		"False"},
{"-device",	"*device",		XrmoptionSepArg,	NULL},
{"-incolor",	"*ichart.foreground",	XrmoptionSepArg,	NULL},
{"-outcolor",	"*ochart.foreground",	XrmoptionSepArg,	NULL},
{"-average",	"*averagePoints",	XrmoptionSepArg,	(XtPointer)10},
{"-horiz",	"*horiz",		XrmoptionNoArg,		"True"},
{"-nochart",	"*showChart",		XrmoptionNoArg,		"False"},
{"-logscale",	"*logScale",		XrmoptionNoArg,		"True"},
#ifdef LINUXPROC
{"-noproc",	"*useProc",		XrmoptionNoArg,		"False"},
#endif
};
static String default_resources[] =
{
#if 0
	"*minscale		:	3",
	"*ilabel.background	:	red",
	"*olabel.background	:	lightblue",
	"*ochart.background	:	pink",
	"*ichart.background	:	yellow",
#endif
	"*update		:	1",
	"*ichart.foreground	:	red",
	"*ichart.jumpScroll	:	1",
	"*ochart.foreground	:	darkgreen",
	"*ochart.jumpScroll	:	1",
	"*topform*borderWidth	:	0",
/*	"*topform*font		:	fixed",   */
/*	"*Pload.geometry	:	180x200", */	 /* vertical   */
/*	"*Pload.geometry	:	300x120", */	/* horizontal */
/*	"*Pload.geometry	:	180x35",  */	/* labels only */
	"*showIn		:	True",
	"*showOut		:	True",
	"*device		:	ppp0",
	"*showLabel		:	True",
	"*averagePoints		:	10",
	"*inDiv			:	1024",
	"*outDiv		:	1024",
	"*horiz			:	False",
	"*showChart		:	True",
	"*logScale		:	False",
#ifdef LINUXPROC
	"*useProc		:	True",
#endif
NULL};

typedef struct
{
	String device;
	Boolean showIn;
	Boolean showOut;
	Boolean showLabel;
	Boolean horiz;
	Boolean showChart;
#ifdef LINUXPROC
	Boolean useProc;
#endif
	Boolean logScale;
	int avgpts;
	int indiv;
	int outdiv;
	int update;
} PloadResources;

/* another global */
static PloadResources resources;

static XtResource pload_resources[] = {
{
	"averagePoints",		/* Resource name */
	"AveragePoints",		/* Resource class */
	XtRInt,				/* Represenation type */
	sizeof(int),			/* size of representation type */
     	XtOffsetOf(PloadResources, avgpts), /* Offset from base */
	XtRImmediate,			/* Representation of specified default */
	(XtPointer)10			/* Address of default resource */
},
{
	"logScale",		
	XtCBoolean,			
	XtRBoolean,			
	sizeof(Boolean),	
     	XtOffsetOf(PloadResources, logScale), 
	XtRImmediate,		
	(XtPointer)False
},
{
	"showChart",		
	XtCBoolean,			
	XtRBoolean,			
	sizeof(Boolean),	
     	XtOffsetOf(PloadResources, showChart), 
	XtRImmediate,		
	(XtPointer)True
},
{
	"update",
	"Update",
	XtRInt,
	sizeof(int),
     	XtOffsetOf(PloadResources, update),
	XtRImmediate,
	(XtPointer)1
},
#ifdef LINUXPROC
{
	"useProc",
	XtCBoolean,
	XtRBoolean,
	sizeof(Boolean),
     	XtOffsetOf(PloadResources, useProc),
	XtRImmediate,	
	(XtPointer)True
},
#endif
{
	"horiz",
	XtCBoolean,
	XtRBoolean,
	sizeof(Boolean),
     	XtOffsetOf(PloadResources, horiz),
	XtRImmediate,	
	(XtPointer)False
},
{
	"inDiv",
	"InDiv",
	XtRInt,
	sizeof(int),
     	XtOffsetOf(PloadResources, indiv),
	XtRImmediate,
	(XtPointer)1024
},
{
	"outDiv",
	"OutDiv",
	XtRInt,
	sizeof(int),
     	XtOffsetOf(PloadResources, outdiv),
	XtRImmediate,
	(XtPointer)1024
},
{
	"device",			
	XtCString,		
	XtRString,		
	sizeof(String),		
     	XtOffsetOf(PloadResources, device),
	XtRString,		
	"ppp0"				
},
{
	"showLabel",			
	XtCBoolean,		
	XtRBoolean,			
	sizeof(Boolean),		
     	XtOffsetOf(PloadResources, showLabel), 
	XtRImmediate,			
	(XtPointer)True		
},
{
	"showIn",		
	XtCBoolean,			
	XtRBoolean,			
	sizeof(Boolean),	
     	XtOffsetOf(PloadResources, showIn), 
	XtRImmediate,		
	(XtPointer)True
},
{
	"showOut",
	XtCBoolean,
	XtRBoolean,
	sizeof(Boolean),
     	XtOffsetOf(PloadResources, showOut),
	XtRImmediate,
	(XtPointer)True
}
};

/************* Main () ******************/
int main (int argc, char *argv[])
{
	Progname = argv[0];
	
	toplevel = XtAppInitialize (
		&context,			/* context */
		"Pload",			/* app name, class */
		options,			/* options */
		XtNumber(options),		/* num_options */
		&argc, argv,			/* command line */
		default_resources,		/* fallback resources */
		NULL, ZERO);
	
	/* all command line options are handled as X resources,
	   if an unknown option, like "-help" is found, show usage
	   and exit */	
	if (argc != 1) Usage();
	
	XtGetApplicationResources(
		toplevel,			/* widget */
		(XtPointer) &resources, 	/* where to put */
		pload_resources,		/* XtResourceList */
		XtNumber(pload_resources),	/* Cardinal num_resources */
		NULL, ZERO);
	
	/* set the title to reflect the device monitored */
	i=0;
	sprintf(buff, "%s: %s", "Pload", resources.device);
	XtSetArg(arglist[i], XtNtitle, buff); i++;
	XtSetValues(toplevel, arglist, i);
	
	/* set the device to monitor */
	ifd.device = resources.device;
	ifd.history_size = resources.avgpts;
#ifdef STREAMS	
	/* note: It is assumed that the device number
	   is just the 4th character.  This currently
	   isn't a problem because dev_n is only used
	   in the stream based interface. I only know
	   how to get ppp statistics from streams. */
	ifd.dev_n = atoi(resources.device+3);	/* the X of pppX */
#endif	
#ifdef LINUXPROC
	if (resources.useProc)
		ifd.getstats = proc_stat;	/* use /proc/net/dev */
	else
		ifd.getstats = ioctl_stat;	/* use ioctl() */
#else
	ifd.getstats = ioctl_stat;	/* non-linuxproc gets ioctl always */
#endif
	
	/* allocate the arrays to average points over */
	if (resources.avgpts < 1) Usage();
	ifd.in_history =  (double *)calloc(ifd.history_size, sizeof(double));
	ifd.out_history = (double *)calloc(ifd.history_size, sizeof(double));
	
	if ((ifd.in_history == NULL) || (ifd.out_history == NULL))
		die("calloc");
		
	/* set the default icon */
	i=0;
	XtSetArg(
		arglist[i],				/* Arg */
		XtNiconPixmap,				/* String name */
		XCreateBitmapFromData(			/* XtArgVal */
			XtDisplay(toplevel),		/* Display* */
			XtScreen(toplevel)->root,	/* Drawable d */
			(char *)pload_bits,		/* char *data */
			pload_width,			/* unsigned */
			pload_height)); i++;		/* unsigned */
	
	XtSetValues(toplevel, arglist, i);
	
	/* get notified of a change in icon state */
	XtAddEventHandler(
			toplevel,		/* Widget w */
			StructureNotifyMask,	/* EventMask mask */
			False,			/* Boolean nonmaskable */
			CheckForIconState,	/* XtEventHandler proc */
			NULL);			/* XtPointer client_data */
			
	/******* create the topform widget *************/
	i=0;
	XtSetArg(arglist[i], XtNdefaultDistance, 0); i++;
	topform = XtCreateManagedWidget (
		"topform", formWidgetClass,
		toplevel,
		arglist, i);
	
	/******* create two more forms ***************/
	if (resources.showIn)
	{
		i=0;
		XtSetArg(arglist[i], XtNdefaultDistance, 0); i++;
		XtSetArg(arglist[i], XtNbottom, XawRubber); i++;
		XtSetArg(arglist[i], XtNresizable, True); i++;
		
		iform = XtCreateManagedWidget (
			"iform", formWidgetClass,
			topform,
			arglist, i);
	}
	if (resources.showOut)
	{
		i=0;
		XtSetArg(arglist[i], XtNdefaultDistance, 0); i++;
		XtSetArg(arglist[i], XtNtop, XawRubber); i++;
		XtSetArg(arglist[i], XtNresizable, True); i++;
		if (resources.showIn)
		{
			if (resources.horiz)
			{
				XtSetArg(arglist[i], XtNfromHoriz, iform);
				i++;
			}
			else
			{
				XtSetArg(arglist[i], XtNfromVert, iform);
				i++;
			}
		}
		oform = XtCreateManagedWidget (
			"oform", formWidgetClass,
			topform,
			arglist, i);
	}
	/* Gee, were those if statements tacked on later ? */
	if (resources.showIn)
	{
		if (resources.showLabel)
		{
	/* create a label widget */
	i=0;
	XtSetArg(arglist[i], XtNlabel, "starting..."); i++;
	XtSetArg(arglist[i], XtNjustify, XtJustifyLeft); i++;
	XtSetArg(arglist[i], XtNbottom, XawChainTop); i++;
	XtSetArg(arglist[i], XtNtop, XawChainTop); i++;
	XtSetArg(arglist[i], XtNresizable, True); i++; 
	ilabel = XtCreateManagedWidget (
		"ilabel", labelWidgetClass,	/* name, widgetclass */
		iform,				/* parent */
		arglist, i );			/* arglist, num_args */
		}
		if (resources.showChart)
		{
	/* create a stripchart widget */
	i=0;
	if (resources.showLabel)
	{
		XtSetArg(arglist[i], XtNfromVert, ilabel); i++;
	}
	XtSetArg(arglist[i], XtNtop, XawChainTop); i++;
	ichart = XtCreateManagedWidget (
		"ichart", stripChartWidgetClass,/* name, widgetclass */
		iform,				/* parent */
		arglist, i );			/* arglist, num_args */
	
	/* add a callback for the stripchart */
	XtAddCallback(
		ichart,				/* widget */
		XtNgetValue,			/* callback name */
		GetIChartPoint,			/* callback proc */
		NULL );				/* client data */
		}
	}
		
	if (resources.showOut)
	{
		if (resources.showLabel)
		{
	/***********************************************************/
	/* create another label widget */
	i=0;
	XtSetArg(arglist[i], XtNlabel, "starting..."); i++;
	XtSetArg(arglist[i], XtNjustify, XtJustifyLeft); i++;
	XtSetArg(arglist[i], XtNbottom, XawChainTop); i++;
	XtSetArg(arglist[i], XtNtop, XawChainTop); i++;
	XtSetArg(arglist[i], XtNresizable, True); i++;
	olabel = XtCreateManagedWidget (
		"olabel", labelWidgetClass,	/* name, widgetclass */
		oform,				/* parent */
		arglist, i );			/* arglist, num_args */
		}
	/**********************************************************/
	/* add another stripchart */
		if (resources.showChart)
		{
	i=0;
	if (resources.showLabel)
	{
		XtSetArg(arglist[i], XtNfromVert, olabel); i++;
	}
	XtSetArg(arglist[i], XtNtop, XawChainTop); i++;
	ochart = XtCreateManagedWidget (
		"ochart", stripChartWidgetClass,/* name, widgetclass */
		oform,				/* parent */
		arglist, i );			/* arglist, num_args */
	/* add a callback for the stripchart */
	XtAddCallback(
		ochart,				/* widget */
		XtNgetValue,			/* callback name */
		GetOChartPoint,			/* callback proc */
		NULL );				/* client data */
		}
	}
	
	/* manage and realize initial widget tree */
	XtRealizeWidget(toplevel);
	
	/* register interest in WM_DELETE_WINDOW */
	HandleExit();
	
	/* manually update */
	update(0,0);
	
	/* submit to the great X */
	XtAppMainLoop(context);
	return 0;
}

void update(XtPointer data, XtIntervalId *id)
{
	
	get_stat(&ifd);
	
	if ( 	(resources.showLabel && resources.showIn) ||
		(iconstate == IconicState) )
	{
		if (ifd.in_bytes == 0) sprintf(buff,"No Connection");
		else
		{
			if (ifd.in_bytes < 1024)
				sprintf(buff, "%0.0f b",
					(double)ifd.in_bytes);
			else if (ifd.in_bytes < (1024*1024))
				sprintf(buff, "%0.2f k",
					(double)ifd.in_bytes/1024.0);
			else if (ifd.in_bytes < (1024*1024*1024))
				sprintf(buff, "%0.2f M",
					(double)ifd.in_bytes/1024.0/1024.0);
			else
				sprintf(buff, "%0.2f G",
					(double)ifd.in_bytes/1024.0/1024.0/1024.0);
		
			if (ifd.in_rate < 1024.0)
				sprintf(buff, "%s %0.0f b/s in",
					buff, ifd.in_rate);
			else if (ifd.in_rate < (1024.0*1024.0))
				sprintf(buff, "%s %0.2f k/s in",
					buff, ifd.in_rate/1024.0);
			else if (ifd.in_rate < (1024.0*1024.0*1024.0))
				sprintf(buff, "%s %0.2f M/s in",
					buff, ifd.in_rate/1024.0/1024.0);
			else	/* yeah right, > 1 G/s rate :)  */
				sprintf(buff, "%s %0.2f G/s in",
					buff, ifd.in_rate/1024.0/1024.0/1024.0);
		}
	}
	
	if ( resources.showLabel && resources.showIn )	
		XtVaSetValues(ilabel, XtNlabel, buff, NULL);
	
	if (iconstate == IconicState)
		XtVaSetValues(toplevel, XtNiconName, buff, NULL);
		
	if (resources.showLabel && resources.showOut)
	{
		if (ifd.out_bytes == 0) sprintf(buff,"No Connection");
		else
		{
			if (ifd.out_bytes < 1024)
				sprintf(buff, "%0.0f b",
					(double)ifd.out_bytes);
			else if (ifd.out_bytes < (1024*1024))
				sprintf(buff, "%0.2f k",
					(double)ifd.out_bytes/1024.0);
			else if (ifd.out_bytes < (1024*1024*1024))
				sprintf(buff, "%0.2f M",
					(double)ifd.out_bytes/1024.0/1024.0);
			else
				sprintf(buff, "%0.2f G",
					(double)ifd.out_bytes/1024.0/1024.0/1024.0);
		
			if (ifd.out_rate < 1024.0)
				sprintf(buff, "%s %0.0f b/s out",
					buff, ifd.out_rate);
			else if (ifd.out_rate < (1024.0*1024.0))
				sprintf(buff, "%s %0.2f k/s out",
					buff, ifd.out_rate/1024.0);
			else if (ifd.out_rate < (1024.0*1024.0*1024.0))
				sprintf(buff, "%s %0.2f M/s out",
					buff, ifd.out_rate/1024.0/1024.0);
			else
				sprintf(buff, "%s %0.2f G/s out",
					buff, ifd.out_rate/1024.0/1024.0/1024.0);
		}
		XtVaSetValues(olabel, XtNlabel, buff, NULL);
	}
	
	XtAppAddTimeOut(context, 1000*resources.update, update, NULL);
	return;
}

void GetIChartPoint( Widget w,			/* not used */
		    XtPointer client_data,	/* not used */
		    XtPointer call_data)	/* *double point to return */
{
	/* the update function handles refreshing the interface data */
	double d = ifd.in_rate / (double)resources.indiv;
	
	if (resources.logScale) d = (d < 1.0) ? 0.0 : log10(d);
	
	*(double *)call_data = d;
 	return;
}

void GetOChartPoint( Widget w,			/* not used */
		    XtPointer client_data,	/* not used */
		    XtPointer call_data)	/* *double point to return */
{
	double d = ifd.out_rate / (double)resources.outdiv;
	
	if (resources.logScale) d = (d < 1.0) ? 0.0 : log10(d);
	
	*(double *)call_data = d;
	return;
}


void HandleExit()
{
	wm_delete_window = XInternAtom(
		XtDisplay(toplevel),		/* Display *display */
		"WM_DELETE_WINDOW",		/* char *atom_name */
		False);				/* Bool only_if_exits */
	(void)XSetWMProtocols(		
		XtDisplay(toplevel),		/* Display *display */
		XtWindow(toplevel),		/* Window w */
		&wm_delete_window,		/* Atom *protocols */
		1);				/* int count */
	XtAddEventHandler(			
		toplevel,			/* Widget w */
		NoEventMask,			/* EventMask mask */
		True,				/* Bool nonmaskable */
		CheckForWMExit,			/* XtEventHandler */
		NULL);				/* XtPointer client_data */
}

void CheckForIconState(	Widget w, 
			XtPointer client_data, 
			XEvent *event, 
			Boolean *dispatch)
{
	switch(event->type)
	{
		case UnmapNotify:	iconstate = IconicState; break;
		case MapNotify:		iconstate = NormalState;
		default:		break;
	}
}

void CheckForWMExit(	Widget w, 
			XtPointer client_data, 
			XEvent *event, 
			Boolean *dispatch)
{
	if ((event->type == ClientMessage) &&
	(event->xclient.data.l[0] == wm_delete_window))
	{
		/* unload */
		free(ifd.in_history);
		free(ifd.out_history);
		XtDestroyApplicationContext(XtWidgetToApplicationContext(w));
		exit(EXIT_SUCCESS);
	}
	return;
}	

void Usage()
{
	fprintf(stderr,
	"\n%s : show data for a network interface (ppp)\n", progver);
	fprintf(stderr,
	"Usage: %s [options]\n", Progname);
	fprintf(stderr,
	" where options includes, in addition to standard toolkit options,\n");
	fprintf(stderr,
	" option            default     description\n");
	fprintf(stderr,
	" -indiv <n>       : 1024      : show dividing lines every n bytes/s for in data\n");
	fprintf(stderr,
	" -outdiv <n>      : 1024      : show dividing lines every n bytes/s for out data\n");
	fprintf(stderr,
	" -logscale        : False     : use base 10 logarithmic scale for rate charts\n");
	fprintf(stderr,
	" -minscale <n>    : 1         : minimum chart scale n\n");
	fprintf(stderr,
	" -jumpscroll <n>  : 1         : jump n pixels on new data, 1 for smooth\n");
	fprintf(stderr,
	" -update <n>      : 1         : update chart every n seconds\n");
	fprintf(stderr,
	" -in              : False     : only show receive chart\n");
	fprintf(stderr,
	" -out             : False     : only show send chart\n");
	fprintf(stderr,
	" -horiz           : False     : arrange horizontally\n");
	fprintf(stderr,
	" -nolabel         : False     : don't show text labels\n");
	fprintf(stderr,
	" -nochart         : False     : don't show charts (labels only)\n");
	fprintf(stderr,
	" -average <n>     : 10        : average data over n points, 1 for no average\n");
	fprintf(stderr,
	" -device <X>      : ppp0      : monitor device X\n");
	fprintf(stderr,
	" -hl <color>      : default   : chart highlight color\n");
	fprintf(stderr,
	" -incolor <color> : red       : receive chart foreground color\n");
	fprintf(stderr,
	" -outcolor <color>: darkgreen : send chart foreground color\n");
	fprintf(stderr,
	" -fg <color>      : default   : foreground color\n");
	fprintf(stderr,
	" -bg <color>      : default   : background color\n");
	fprintf(stderr,
	" -fn <fontspec>   : default   : label font\n");
#ifdef LINUXPROC
	fprintf(stderr,
	" -noproc          : False     : don't use proc interface, use ioctl\n");
#endif
	fprintf(stderr,
	"\nsee the manual page for more information\n\n");
	
	exit(EXIT_FAILURE);
}

