
#ifndef __xppp_init_h__
#define __xppp_init_h__

#include "forms.h"
#include "xppp.h"


FILE * ppps, *dials, *xppprc, *aux, *spec;
FL_FORM * lastDeactForm;
char pppScript[80], dialScript[80];
char options[24][40];
char variables[24][40];
int parsed;

  char dirname[255];	//directory used
  char fname1[255];	//ppp-init
  char fname2[255];	//ppp-on-dialer
  char configrc[255];	//configuration file
  char temporal[255];	//temporal file
  char disconn[255];	//disconnection file
  char messages[255];	//messages handled by syslogd
  char specific[255];	//specific file name
  char conname[255];	//connection name
  char prefix[255];	//first part of conname

  char xpmline0[255];	//pixmap
  char xpmline1[255];	//pixmap
  char xpmline2[255];	//pixmap
  char xpmline3[255];	//pixmap
  char xpmline4[255];	//pixmap
  char xpmline5[255];	//pixmap
  char xpmline6[255];	//pixmap
  char xpmline7[255];	//pixmap
  char xpmdial0[255];	//pixmap
  char xpmdial1[255];	//pixmap
  char xpmdial2[255];	//pixmap
  char xpmmysite[255];	//pixmap
  char xpmmyISP[255];	//pixmap
  char xpmnoline[255];	//pixmap
  char xpmdaemon[255];	//pixmap

  int mutex;		//Mutual exclusion ???


void initializeForms();
void initXppp();
void initIPa();
void initAo();
void initLaunch();

void restoreIPa();
void restoreAo();

int  checknum(char *);
int  isIP(char *);


void doStop(char*, FL_FORM*);




int postHandler(FL_OBJECT *, int ,FL_Coord, FL_Coord, int, void *);




#endif
