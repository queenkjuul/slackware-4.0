#include "xppp_init.h"

#ifndef FD_Xppp_Configurator_h_
#define FD_Xppp_Configurator_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void phoneC(FL_OBJECT *, long);
extern void pro1C(FL_OBJECT *, long);
extern void ans1C(FL_OBJECT *, long);
extern void pro2C(FL_OBJECT *, long);
extern void ans2C(FL_OBJECT *, long);
extern void ans22C(FL_OBJECT *, long);
extern void pro3C(FL_OBJECT *, long);
extern void ans3C(FL_OBJECT *, long);
extern void pro4C(FL_OBJECT *, long);
extern void ans4C(FL_OBJECT *, long);
extern void ipaC(FL_OBJECT *, long);
extern void advC(FL_OBJECT *, long);
extern void genC(FL_OBJECT *, long);
extern void quiC(FL_OBJECT *, long);
extern void helC(FL_OBJECT *, long);

extern void locC(FL_OBJECT *, long);
extern void remC(FL_OBJECT *, long);
extern void netC(FL_OBJECT *, long);
extern void ipokC(FL_OBJECT *, long);
extern void ipcanC(FL_OBJECT *, long);
extern void ipresC(FL_OBJECT *, long);
extern void aonoiC(FL_OBJECT *, long);
extern void aodefC(FL_OBJECT *, long);
extern void preC(FL_OBJECT *, long);
extern void posC(FL_OBJECT *, long);

extern void aodiaC(FL_OBJECT *, long);
extern void aovolC(FL_OBJECT *, long);
extern void aortsC(FL_OBJECT *, long);
extern void aodevC(FL_OBJECT *, long);
extern void aotimC(FL_OBJECT *, long);
extern void aoasyC(FL_OBJECT *, long);
extern void aoescC(FL_OBJECT *, long);
extern void aookC(FL_OBJECT *, long);
extern void aoresC(FL_OBJECT *, long);
extern void aocanC(FL_OBJECT *, long);
extern void speC(FL_OBJECT *, long);
extern void aospeC(FL_OBJECT *, long);

extern void stitleC(FL_OBJECT *, long);
extern void stextC(FL_OBJECT *, long);
extern void sokC(FL_OBJECT *, long);

extern void hOKC(FL_OBJECT *, long);

extern void cconC(FL_OBJECT *, long);
extern void cquiC(FL_OBJECT *, long);
extern void cdisC(FL_OBJECT *, long);
extern void cconnC(FL_OBJECT *, long);
extern void cselC(FL_OBJECT *, long);


/**** Forms and Objects ****/

extern FL_FORM *Xppp_Configurator;

extern FL_OBJECT
        *phone,
        *pro1,
        *ans1,
        *pro2,
        *ans2,
        *ans22,
        *pro3,
        *ans3,
        *pro4,
        *ans4,
        *ipaB,
        *advB,
        *genB,
        *quiB,
        *helB;

extern FL_FORM *Xppp_IP_Addresses;

extern FL_OBJECT
        *locI,
        *remI,
        *netI,
        *ipokB,
        *ipcanB,
        *ipresB,
        *aonoiB,
        *aodefB,
        *preI,
        *posI;

extern FL_FORM *Xppp_Advanced_options;

extern FL_OBJECT
        *dialmode,
        *aotonB,
        *aopulB,
        *vollevel,
        *aovol0,
        *aovol1,
        *aovol2,
        *aovol3,
        *aortsB,
        *aodevI,
        *aotimI,
        *aoasyI,
        *aoescI,
        *aookB,
        *aoresB,
        *aocanB,
        *commspeed,
        *s115,
        *s57,
        *s38,
        *s19,
        *s9,
        *soth,
        *aospeI;

extern FL_FORM *stoping;

extern FL_OBJECT
        *stitle,
        *stext,
        *sokB;

extern FL_FORM *helping;

extern FL_OBJECT
        *hokB;

extern FL_FORM *xppp_launch;

extern FL_OBJECT
        *logBrowser,
        *cconB,
        *cquiB,
        *cdisB,
        *cconnB,
        *ppptext,
        *dialtext,
        *cselB,
        *mysite,
        *myISP,
        *phoneline;



/**** Creation Routine ****/

extern void create_the_forms(void);

#endif /* FD_Xppp_Configurator_h_ */
