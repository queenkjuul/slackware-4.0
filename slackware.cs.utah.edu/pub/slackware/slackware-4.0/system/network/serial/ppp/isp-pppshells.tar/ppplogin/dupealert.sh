
date >> /etc/ppp/dupes.log
echo $LOGNAME >> /etc/ppp/dupes.log
echo " " >> /etc/ppp/dupes.log

echo "

Your account is currently in use from another line.

Only one concurrent login per account is allowed.

If this occurance happens persistantly, your account will
be terminated.

If you suspect someone has gained access to your account
password, please contact customer support immediatly at
(XXX) XXX-XXXX.

Goodbye.


"
