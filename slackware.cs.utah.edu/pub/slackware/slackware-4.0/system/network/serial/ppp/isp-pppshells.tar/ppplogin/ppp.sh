
term=vt100
TERM=vt100
export term TERM


case $LOGNAME in

# The following login names receive a static IP
"THIS_USERNAME_GETS_A_STATIC_IP") MYIP="200.0.0.0" ;;
"SO_DOES_THIS_ONE") MYIP="200.0.0.1" ;;
"MIKE") MYIP="200.0.0.2" ;;

*)
MYPORT=`who am i | /usr/bin/awk -f /etc/ppp/pppport.awk`

# The following ports assign IP dynamically based on the login port
case $MYPORT in

  "ttyC0") MYIP="200.0.0.120" ;;
  "ttyC1") MYIP="200.0.0.121" ;;
  "ttyC2") MYIP="200.0.0.122" ;;
  "ttyC3") MYIP="200.0.0.123" ;;
  "ttyC4") MYIP="200.0.0.124" ;;
  "ttyC5") MYIP="200.0.0.125" ;;
  "ttyC6") MYIP="200.0.0.126" ;;
  "ttyC7") MYIP="200.0.0.127" ;;

esac
;;

esac



echo
echo "Welcome to RAHRAH INTERNET!!!.  Your IP Address is : $MYIP"
echo

# Change the line below to the IP address of this server 
# or the default gateway you wish to extend to the user.
# Mine is set up with the IP of the dial-up box this file is installed on.
/usr/sbin/pppd -detach crtscts modem mtu 296 proxyarp defaultroute 200.0.0.10:$MYIP
