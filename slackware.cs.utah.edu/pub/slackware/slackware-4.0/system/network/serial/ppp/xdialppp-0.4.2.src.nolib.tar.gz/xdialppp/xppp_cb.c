#include "forms.h"
#include "xppp.h"
#include "mytokens.h"
#include<string.h>
#include <stdlib.h>


/* callbacks for form Xppp_Configurator */
void phoneC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void pro1C(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void ans1C(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void pro2C(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void ans2C(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void ans22C(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void pro3C(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void ans3C(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void pro4C(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void ans4C(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void ipaC(FL_OBJECT *ob, long data)
{
  fl_deactivate_form(Xppp_Configurator);
  lastDeactForm=Xppp_Configurator;
  fl_show_form(Xppp_IP_Addresses,FL_PLACE_CENTER,FL_TRANSIENT,"Xdialppp IP addresses");
}

void advC(FL_OBJECT *ob, long data)
{
  fl_deactivate_form(Xppp_Configurator);
  lastDeactForm=Xppp_Configurator;
  fl_show_form(Xppp_Advanced_options,FL_PLACE_CENTER,FL_FULLBORDER,"Xdialppp Connection options");
}

void genC(FL_OBJECT *ob, long data)
{
  char tmp[255];
  char * temp;
  int i,allR;
  allR=0;


  strcpy(options[0],fl_get_input(phone));
  if(strlen(options[0])==0)
  {
	doStop("Phone unknown !\nPlease enter the phone number of your ISP." ,Xppp_Configurator);
	return;	
  }
  if(!checknum(options[0]))
  {
	//doStop("Phone should be a number.\n No letters or symbols are allowed." ,Xppp_Configurator);
	if(!fl_show_question("The phone should contain only numbers !\n(Answer yes if you have specified any pause, or outside dial #)\nDo you want to continue anyway?",1))
		return;
  }
  strcpy(options[1],fl_get_input(pro1));
  if(strlen(options[1])==0)
  {
	doStop("First prompt unknown !\nPlease enter the first prompt that your ISP issues you.\nThis is usually one of these : <Username:> , <Login:> , etc.\nDo not include the <> symbols" ,Xppp_Configurator);
	return;	
  }
  strcpy(options[2],fl_get_input(ans1));
  if(strlen(options[2])==0)
  {
	doStop("Username unknown !\nPlease enter your username." ,Xppp_Configurator);
	return;	
  }
  strcpy(options[3],fl_get_input(pro2));
  if(strlen(options[3])==0)
  {
	doStop("Second prompt unknown !\nPlease enter the second prompt that your ISP issues you.\nThis is usually one of these : <Password:> , <Passwd:> , etc.\nDo not include the <> symbols" ,Xppp_Configurator);
	return;	
  }

  if(! strcmp(fl_get_input(ans2),fl_get_input(ans22)))	/* password check */
	  strcpy(options[4],fl_get_input(ans2));
  else
  	{
		doStop("Your password does not match !\nPlease re-enter your password in the two password boxes." ,Xppp_Configurator);
		return;	
  	}
  if(strlen(options[4])==0)
  {
	doStop("Password unknown !\nPlease enter your password in both boxes." ,Xppp_Configurator);
	return;
  }

  strcpy(options[5],fl_get_input(pro3));
  strcpy(options[6],fl_get_input(ans3));
  if((strlen(options[5])>0) && (strlen(options[6])==0))
  {
	doStop("Please enter the answer to the first extra prompt that your ISP issues you.\nThis is not usefull for everyone, but some ISP's prompt a\n 'Server1>' or something like that after identifying you.\nThey may be expecting a 'ppp' command." ,Xppp_Configurator);
	return;	
  }

  strcpy(options[7],fl_get_input(pro4));
  strcpy(options[8],fl_get_input(ans4));
  if((strlen(options[7])>0) && (strlen(options[8])==0) && (strlen(options[5])>0))
  {
	doStop("Please enter the answer to the second extra prompt that your ISP issues you.\nThis is not usefull for everyone.\nI really don't imagine what other thing your ISP can ask you... If you use this feature, please email me: d.rodrigo@computer.org." ,Xppp_Configurator);
	return;	
  }



  if(!strlen(temp=fl_show_simple_input("Enter a name for the connection :",conname)))
	fl_show_alert("You should have entered a valid name !","","",1);
  else
  {
     strcpy(conname,temp);
     if(!(temp=fl_show_fselector("Save configuration file as :", dirname, "*.xppprc", specific)))
	fl_show_alert("You should have entered a valid file name !", "", "",0);
     else
	{
		if(!(spec=fopen(temp,"w")))
			fl_show_alert("Couldn't open specified file :",temp,"", 0);
		else
		{
			strcpy(specific,temp);
			if(!(xppprc=fopen(configrc,"w")))
			{
				fl_show_alert("Cannot open file :",configrc,"Check permissions.",0);
			}
			else
			{
				fprintf(xppprc,specific);
				fclose(xppprc);
				sprintf(fname1,"%s.ppp-init",strtok(specific, "."));
				sprintf(fname2,"%s.ppp-dialer",strtok(specific,"."));
				fprintf(spec,"PPP_SCRIPT=%s\n", fname1);
				fprintf(spec,"DIAL_SCRIPT=%s\n", fname2);
				fprintf(spec,"CONNAME=\'%s\'\n",conname);
				fprintf(spec,"# Automatically generated file - DO NOT EDIT !\n");
				fclose(spec);
			  	if(!(ppps=fopen(fname1,"w")))
					fl_show_alert("Cannot open file :",fname1,"Check permissions.",0);
				else
				{
					fprintf(ppps,"#!/bin/bash \n#-----------------------------------------------------------------------\n# ppp connection script generated by xdialppp\n#\txdialppp : programmed by Diego Rodrigo\td.rodrigo@computer.org\n#\thttp://www.geocities.com/MotorCity/5501/xdialppp.html\n#\n#\t\tAutomatically generated file - Please do not edit.\n#-----------------------------------------------------------------------\n#\n");
					fprintf(ppps,"#Parameters\n");
					fprintf(ppps,"export %s\'%s\'\t#Telephone to call.\n",variables[0],options[0]);
					fprintf(ppps,"export %s\'%s\'\t#How does your ISP asks you your username?\n",variables[1],options[1]);
					fprintf(ppps,"export %s\'%s\'\t#Your username.\n",variables[2],options[2]);
					fprintf(ppps,"export %s\'%s\'\t#How does your ISP asks you your passwd?\n",variables[3],options[3]);
					fprintf(ppps,"export %s\'%s\'\t#Your password.\n",variables[4],options[4]);
					if(strlen(options[5]))
					{
						fprintf(ppps,"export %s\'%s\'\t#Additional prompt.\n",variables[5],options[5]);
						fprintf(ppps,"export %s\'%s\'\t#Answer to that prompt.\n",variables[6],options[6]);
					}
					if(strlen(options[7]))
					{
						fprintf(ppps,"export %s\'%s\'\t#Additional prompt #2.\n",variables[7],options[7]);
						fprintf(ppps,"export %s\'%s\'\t#Additional answer #2.\n",variables[8],options[8]);
					}
	
					fprintf(ppps,"export %s\'%s\'\t#Local IP if needed. Dynamic : 0.0.0.0\n",variables[9],options[9]);
					fprintf(ppps,"export %s\'%s\'\t#Remote IP if needed. Typically 0.0.0.0\n",variables[10],options[10]);
					fprintf(ppps,"export %s\'%s\'\t#Netmask. 255.255.255.0 works in most cases.\n",variables[11],options[11]);
					fprintf(ppps,"export %s\'%s\'\t#Device used to perform the connection.\n",variables[12],options[12]);
					fprintf(ppps,"export %s\'%s\'\t#Connection speed [bps].\n",variables[13],options[13]);
					fprintf(ppps,"export %s\'%s\'\t#Timeout to get connection.\n",variables[14],options[14]);
					fprintf(ppps,"export DIALER_SCRIPT=\'%s\'\t#Script that dials...\n",fname2);
					fprintf(ppps,"export %s\'%s\'\t#Dialing mode  (Tone/Pulse)\n",variables[15],options[15]);
					fprintf(ppps,"export %s\'%s\'\t#Modem speaker volume (0|1|2|3)\n",variables[16],options[16]);
					fprintf(ppps,"export %s\'%s\'\t#Flow control\n",variables[17],options[17]);
					fprintf(ppps,"export %s\'%s\'\t#Asyncmap\n",variables[18],options[18]);
					fprintf(ppps,"export %s\'%s\'\t#Escape secuences\n",variables[19],options[19]);
					fprintf(ppps,"export %s\'%s\'\t#No IP default\n",variables[20],options[20]);
					fprintf(ppps,"export %s\'%s\'\t#Add peer's address to default route\n",variables[21],options[21]);
					fprintf(ppps,"#\n#\n#Start the connection ...\n\n");
					fprintf(ppps,"exec /usr/sbin/pppd debug lock modem %s $DEVICE $SPEED \\\n", options[17]);

					if (strlen(options[18]))
						fprintf(ppps,"\t asyncmap %s ",options[18]);
					if (strlen(options[19]))
						fprintf(ppps," escape %s ",options[19]);	
					fprintf(ppps," kdebug 0 ");
					fprintf(ppps," $LOCALIP:$REMOTEIP \\\n");
					fprintf(ppps,"\t %s netmask $NETMASK %s connect $DIALER_SCRIPT",options[20],options[21]);
					fclose(ppps);

			 		if (chmod(fname1, ((long)7)<<6))
						fl_show_alert("Error executing chmode system call for script", fname1 ,"Check directory flags.",0);
					else
					{

					  	if (!(dials=fopen(fname2,"w")))
							fl_show_alert("Cannot open file :",fname2,"Check permissions.",0);
						else
  						{
							fprintf(dials,"#!/bin/sh\n# Second part of ppp connection script.\n#\n#\tby Diego Rodrigo\td.rodrigo@computer.org\n#\nexec chat -v \t\\\n\t\tTIMEOUT\t3\t\\\n");
							fprintf(dials,"\t\tABORT\t\'\\nBUSY\\r\'\t\\\n");
							fprintf(dials,"\t\tABORT\t\'\\nNO ANSWER\\r\'\t\\\n");
							fprintf(dials, "\t\tABORT\t\'\\nRINGING\\r\\n\\r\\nRINGING\\r\'\t\\\n");
							fprintf(dials,"\t\t\'\'\t\\rAT\t\\\n");
							fprintf(dials,"\t\t\'OK-+++\\c-OK\'\tATH0\t\\\n");
							fprintf(dials,"\t\tTIMEOUT\t$TIMEOUT\t\\\n");
							fprintf(dials, "\t\tOK\tAT%sD%s$PHONE\t\\\n",options[16],options[15]);
							fprintf(dials,"\t\tCONNECT\t\'\'\t\\\n");
							fprintf(dials,"\t\t$PROMPT1\t$USERNAME\t\\\n");
							fprintf(dials,"\t\t$PROMPT2\t$PASSWORD");
							if (strlen(options[5]))
							fprintf(dials,"\t\\\n  \t\t$PROMPT3\t$ANSWER3");
							if (strlen(options[7]))
								fprintf(dials,"\t\\\n  \t\t$PROMPT4\t$ANSWER4");
							fclose(dials);

						 	 if(chmod(fname2, ((long)7)<<6))
								fl_show_alert("Error executing chmode system call for script", fname2, "Check directory flags.",0);
							else
							{

								initLaunch();
								fl_hide_form(Xppp_Configurator);
								fl_activate_form(xppp_launch);
								fl_activate_object(cconnB);
							}//all done
						}//fname2 opened & closed & chmod'ed (dials)
					}//fname1 chmod'ed
				}//fname1 opened & closed (ppps)
			}//specific file opened & closed
		}//filename (specific) entered correctly
	}//connection name entered
   }//configrc file opened
}

void quiC(FL_OBJECT *ob, long data)
{
  fl_hide_form(Xppp_Configurator);
  fl_activate_form(xppp_launch);
}

void helC(FL_OBJECT *ob, long data)
{
  lastDeactForm=Xppp_Configurator;
  fl_deactivate_form(Xppp_Configurator);
  fl_show_form(helping,FL_PLACE_CENTER,FL_TRANSIENT,"Xdialppp Help");
}



/* callbacks for form Xppp_IP_Addresses */
void locC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void remC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void netC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void ipokC(FL_OBJECT *ob, long data)
{
   char tmp[255];

   if(!strlen(strcpy(tmp,fl_get_input(locI))))
	strcpy(tmp,"0.0.0.0");
   if(!isIP(tmp))
   {
	doStop("Local IP is not a valid IP address.\nIt should be in the form : aaa.bbb.ccc.ddd\nwhere aaa, bbb, ccc and ddd are numbers between 0 and 255.\nNo letters or symbols are allowed." ,Xppp_Configurator);
	return;
   }
   else
	strcpy(options[9],tmp);


   if(!strlen(strcpy(tmp,fl_get_input(remI))))
	strcpy(tmp,"0.0.0.0");
   if(!isIP(tmp))
   {
	doStop("Remote IP is not a valid IP address.\nIt should be in the form : aaa.bbb.ccc.ddd\nwhere aaa, bbb, ccc and ddd are numbers between 0 and 255.\nNo letters or symbols are allowed." ,Xppp_Configurator);
	return;
   }
   else
	strcpy(options[10],tmp);

   if(!strlen(strcpy(tmp,fl_get_input(netI))))
	strcpy(tmp,"255.255.255.0");
   if(!isIP(tmp))
   {
	doStop("Netmask is not a valid IP address.\nIt should be in the form : aaa.bbb.ccc.ddd\nwhere aaa, bbb, ccc and ddd are numbers between 0 and 255.\nNo letters or symbols are allowed." ,Xppp_Configurator);
	return;
   }
   else
	strcpy(options[11],tmp);

  if(fl_get_button(aonoiB)==1)
	strcpy(options[20],"noipdefault");
  else
	strcpy(options[20],"");

  if(fl_get_button(aodefB)==1)
	strcpy(options[21],"defaultroute");
  else
	strcpy(options[21],"");

   if(strlen(strcpy(tmp,fl_get_input(preI))))
	strcpy(options[22],tmp);

   if(strlen(strcpy(tmp,fl_get_input(posI))))
	strcpy(options[23],tmp);

   fl_hide_form(Xppp_IP_Addresses);
   fl_activate_form(lastDeactForm);

}

void ipcanC(FL_OBJECT *ob, long data)
{
	restoreIPa();
  	fl_hide_form(Xppp_IP_Addresses);
  	fl_activate_form(lastDeactForm);
}

void ipresC(FL_OBJECT *ob, long data)
{
	initIPa();	/*restore default values for this form*/
}

void aonoiC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void aodefC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void preC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void posC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}



/* callbacks for form Xppp_Advanced_options */
void aodiaC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void aovolC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void aortsC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void aodevC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void aotimC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void aoasyC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void aoescC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void aookC(FL_OBJECT *ob, long data)
{
  char tmp[255];
  if(!strlen(strcpy(tmp,fl_get_input(aodevI))))
  {
	doStop("Device unknown !\nPlease enter the device you use to connect to your ISP.\nIt can be one of these:\n/dev/modem , /dev/cua0 , /dev/cua1 , etc." ,Xppp_Configurator);
	return;
  }
  else
	strcpy(options[12],tmp);

  if (fl_get_button(s115))
	strcpy(options[13],"115200");
  else
	if (fl_get_button(s57))
		strcpy(options[13],"57600");
	else
		if(fl_get_button(s38))
			strcpy(options[13],"38400");
		else
			if (fl_get_button(s19))
				strcpy(options[13],"19200");
			else
				if (fl_get_button(s9))
					strcpy(options[13],"9600");
				else
					if(strlen(strcpy(tmp,fl_get_input(aospeI))))
					{
						if(checknum(tmp))
							strcpy(options[13],tmp);
						else
						{
							doStop("Connection speed unknown !\nPlease enter the connection speed for your modem.\nIf you have selected 'Other' , please specify it." ,Xppp_Configurator);
							return;
						}
  					}
					else
					{
						doStop("Speed should be a number (bps).\nNo letters or symbols are allowed." ,Xppp_Configurator);
						return;
					}


  if(!strlen(strcpy(tmp,fl_get_input(aotimI))))
  {
	doStop("Timeout unknown !\nPlease enter the timeout for the connection." ,Xppp_Configurator);
	return;
  }
  else
  	if(!checknum(tmp))
  	{
		doStop("Timeout should be a number (seconds).\nNo letters or symbols are allowed." ,Xppp_Configurator);
		return;
  	}
	else
		strcpy(options[14],tmp);

  if(fl_get_button(aotonB)==1)
	strcpy(options[15],"T");
  else
	strcpy(options[15],"P");
  
  if(fl_get_button(aovol0)==1)
	strcpy(options[16],"L0");
  else
	if(fl_get_button(aovol1)==1)
		strcpy(options[16],"L1");
	else
		if(fl_get_button(aovol2)==1)
			strcpy(options[16],"L2");
		else
			strcpy(options[16],"L3");

  if(fl_get_button(aortsB)==1)
	strcpy(options[17],"crtscts");

  strcpy(options[18],fl_get_input(aoasyI));

  strcpy(options[19],fl_get_input(aoescI));

  fl_hide_form(Xppp_Advanced_options);
  fl_activate_form(lastDeactForm);

}

void aoresC(FL_OBJECT *ob, long data)
{
	initAo();	/*initialize values for this form*/
}

void aocanC(FL_OBJECT *ob, long data)
{
	restoreAo();	/*restore values for this form  */
	fl_hide_form(Xppp_Advanced_options);
  	fl_activate_form(lastDeactForm);
}

void speC(FL_OBJECT *ob, long data)
{
   if (data)
	fl_activate_object(aospeI);
   else
	fl_deactivate_object(aospeI);
}

void aospeC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}



/* callbacks for form stoping */
void stitleC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void stextC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void sokC(FL_OBJECT *ob, long data)
{
	fl_hide_form(stoping);
	fl_activate_form(lastDeactForm);
}



/* callbacks for form helping */
void hOKC(FL_OBJECT *ob, long data)
{
	fl_hide_form(helping);
	fl_activate_form(lastDeactForm);
}



/* callbacks for form xppp_launch */
void cconC(FL_OBJECT *ob, long data)
{
  fl_deactivate_form(xppp_launch);
  fl_show_form(Xppp_Configurator,FL_PLACE_CENTER,FL_FULLBORDER,"Xdialppp Configurator");
}

void cquiC(FL_OBJECT *ob, long data)
{
  exit(0);
}

void cdisC(FL_OBJECT *ob, long data)
{
  long myPID;
  if((aux=fopen(disconn,"r")))
  {
	fclose(aux);
  	myPID=fl_exe_command(disconn,1);
	fl_end_all_command();//todavia no lo probe !!!
	fl_activate_object(cconnB);
	fl_deactivate_object(cdisB);
	fl_insert_browser_line(logBrowser,13,"PPP connection closed.");
  }
  else
	fl_show_alert("Can not disconnect ! File not found :",disconn, "You should handle disconnection by yourself.\nTry ppp-off (generally in /usr/sbin).",0);
}

void cconnC(FL_OBJECT *ob, long data)
{
 char message[255],matador[255],tmp[255];
 FILE * log, *PID2kill;
 int i=1,j,flag=0, level=0,mode=0;
 long myPID,myPID2,onePID,daemonPID=-1,chatPID=-1;

 if (mutex-1>=0)		//test mutual exclusion ???
 {
  mutex--;			// If OK, then decrement mutex and continue

  fl_clear_browser(logBrowser);
  fl_deactivate_object(cconnB);
  fl_deactivate_object(cconB);
  fl_deactivate_object(cquiB);
  sprintf(tmp,"touch %s",temporal);
  fl_exe_command(tmp,1);   /*wait for the file creation */
  if (chmod(temporal, ((long)6)<<6))
	if(!(fl_show_question("Couldn't chmod temporal file.\nIf you continue, your password could be seen by strangers.\nDo you want to continue anyway?",1)))
	{
		sprintf(tmp,"rm %s",temporal);
		return;
	}
  sprintf(tmp,"tail -n0 -f %s > %s",messages,temporal);
  myPID=fl_exe_command(tmp,0);    /*don't wait*/
  myPID2=fl_exe_command(pppScript,0);
  fl_add_browser_line(logBrowser,"Attempting to start ppp daemon");
  if (!(log=fopen(temporal,"r")))
  {
	fl_show_alert("Couldn't open temporary log file","Unable to track connection progress.","Check permissions in current directory",0);
  }
  else
  {
	while (!flag)
	{
	//fl_add_browser_line(logBrowser,"");//!!!!!!!!!!!!!!!!!!!!!!!!1

	   if (fgets(message,250,log))
	   {
		if (level==0 && findSubStr(message,"pppd")!=-1)
			if (findSubStr(message,"started")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"PPP daemon started.");
				level=1;
				fl_set_pixmap_file(mysite,xpmdaemon);
				getToken(tmp,message,"[");
				daemonPID=atol(tmp);
				//printf("--%ld--\n",daemonPID);
				mode=0;
			}

		if (level==1 && findSubStr(message,"chat")!=-1)
			{
				i++;
				getToken(tmp,message,"[");
				chatPID=atol(tmp);
				//printf("--%ld--\n",chatPID);
				mode=0;
				level=2;
			}


		if (level==2 && findSubStr(message,"chat")!=-1 && findSubStr(message,"send")!=-1 &&  findSubStr(message,"AT")!=-1  &&  findSubStr(message,"D")!=-1 )
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"Dialing ...");
				level=3;
				mode=0;
			}

		if (level==3 && findSubStr(message,"chat")!=-1)
			if (findSubStr(message,"CONNECT --")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"Handshaking whith ISP's modem.");
				level=4;
				mode=0;
				fl_set_pixmap_file(mysite,xpmmysite);
			}

		if (level==4 && findSubStr(message,"chat")!=-1)
		{
			if (findSubStr(message,"9600")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"Connection speed:9600 bps.");
			}
			if (findSubStr(message,"19200")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"Connection speed:19200 bps.");
			}
			if (findSubStr(message,"38400")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"Connection speed:38400 bps.");
			}
			if (findSubStr(message,"57600")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"Connection speed:57600 bps.");
			}
			if (findSubStr(message,"115200")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"Connection speed:115200 bps.");
			}
		}


		if (findSubStr(message,"pppd")!=-1)
			if (findSubStr(message,"erial connection established")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"Serial connection established.");
				level=5;
				fl_set_pixmap_file(phoneline,xpmnoline);
			}
		if (findSubStr(message,"pppd")!=-1)
			if (findSubStr(message,"local")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,message);
				if(level==7)
					flag=1;
				else
					level=6;
			}
		if (findSubStr(message,"pppd")!=-1)
			if (findSubStr(message,"remote")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,message);
				if (level=6)
					flag=1;
				else
					level=7;
			}



		if (findSubStr(message,"chat")!=-1)
			if (findSubStr(message,"NO DIALTONE")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"No dial tone, waiting for pppd to terminate.");
				fl_set_pixmap_file(mysite,xpmmysite);
				fl_set_pixmap_file(phoneline,xpmnoline);
				flag=-1;
			}
		if (findSubStr(message,"pppd")!=-1)
			if (findSubStr(message,"evice")!=-1 && findSubStr(message,"locked")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"Device is locked, waiting for pppd to terminate.");
				fl_set_pixmap_file(mysite,xpmmysite);
				fl_set_pixmap_file(phoneline,xpmnoline);
				flag=-1;
			}
		if (findSubStr(message,"pppd")!=-1)
			if (findSubStr(message,"Exit")!=-1)
			{
				i++;
				fl_insert_browser_line(logBrowser,i,"PPP daemon terminated.");
				fl_set_pixmap_file(mysite,xpmmysite);
				fl_set_pixmap_file(phoneline,xpmnoline);
				flag=-1;
			}
	   }
	   else
	   {
		if (level==3)
		{
			if (mode<=10)
			{
				fl_set_pixmap_file(mysite,xpmdial0);
				mode++;
			}
			else if (mode >10 && mode <=20)
			{
				fl_set_pixmap_file(mysite,xpmdial1);
				mode++;
			}
			else if (mode >20)
			{
				fl_set_pixmap_file(mysite,xpmdial2);
				mode++;
				if(mode>=30)
					mode=0;
			}
		}
		else if (level==4)
		{
			if(mode==0)
			{
				fl_set_pixmap_file(phoneline,xpmline0);
				mode++;
			}
			else if(mode==1)
			{
				fl_set_pixmap_file(phoneline,xpmline1);
				mode++;
			}
			else if(mode==2)
			{
				fl_set_pixmap_file(phoneline,xpmline2);
				mode++;
			}
			else if(mode==3)
			{
				fl_set_pixmap_file(phoneline,xpmline3);
				mode++;
			}
			else if(mode==4)
			{
				fl_set_pixmap_file(phoneline,xpmline4);
				mode++;
			}
			else if(mode==5)
			{
				fl_set_pixmap_file(phoneline,xpmline5);
				mode++;
			}
			else if(mode==6)
			{
				fl_set_pixmap_file(phoneline,xpmline6);
				mode++;
			}
			else if(mode==7)
			{
				fl_set_pixmap_file(phoneline,xpmline7);
				mode=0;
			}
		}
	   }//else
	   if(level==5 && options[9]==NULL && options[10]==NULL)
		flag=1;
	   else if(level==6 && options[10]==NULL)
		flag=1;
	   else if(level==7 && options[9]==NULL)
		flag=1;
	   else 
		usleep(100);
	} //while

	fclose(log);



	//kill the tail process and all its children (why so many tail's ???)
	sprintf(matador,"kill -9 %d",myPID);
	fl_exe_command(matador,1);
	if(!(PID2kill=popen("ps -ax|grep /var/log/messages|grep tail|grep n0|grep f","r")))
		fl_show_alert("Cannot fork in order to kill child processes","Please do a \'ps\' and find out the zombie ones.","Report this incident !",1);
	else
	{
		while(!feof(PID2kill))
		{
			fgets(tmp,250,PID2kill);		//get a line from ps|grep
			sscanf(tmp,"%ld",&onePID);		//find the PID
			sprintf(tmp,"kill -9 %ld",onePID);	//make a kill command with it
			fl_exe_command(tmp,1);			//DO IT
		}
		pclose(PID2kill);
	}




	if (flag==1)
		fl_activate_object(cdisB);	//to be able to disconnect
	if (flag==-1)
	{
		char tmp[255];
		fl_activate_object(cconnB);	//to be able to re-connect
		sprintf(tmp,"rm %s",temporal);	//remove temporal file
		fl_exe_command(tmp,1);		//DO IT
		if (chatPID>1)				//kill chatPID if exists
		{
			sprintf(tmp,"kill -9 %ld",chatPID);
			fl_exe_command(tmp,1);
			//kill(chatPID,-15);	//may be better, bun doesn't
				//let pppd write via syslog ...
		}
		if(daemonPID>1)			//kill daemonPID if exists
		{
			//kill(daemonPID,-15);
			sprintf(tmp,"kill -9 %ld",daemonPID);
			fl_exe_command(tmp,1);
		}
		fl_end_command(myPID2);		//kill script if still exists
		fl_end_all_command();		//and all processes (I'm sick of them all?)
	}

	//fl_end_command(myPID);		//has been already killed !
	//fl_end_command(myPID2);
	//fl_end_all_command();		//all killed.

  }

  fl_activate_object(cconB);
  fl_activate_object(cquiB);
  mutex++;		//restore value of mutex and leave critical zone ???
 }

}

void cselC(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}



