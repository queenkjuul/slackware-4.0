#! /bin/bash
#
#######################################################
#
#  ppp-multidial.sh
#  
# Copyright (C) 1997 by John P. Weiss
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the Artistic License, included as the file
# "LICENSE" in the source code archive.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# You should have received a copy of the file "LICENSE", containing
# the License John Weiss originally placed this program under.
#
#######################################################
#
#
#  NOTE!  NOTE!  NOTE!  NOTE!  NOTE!  NOTE!  NOTE!
#
#  There are no user servicable parts in here!  If you want to twiddle
#  something, edit the file /etc/ppp/ppp-multidial.rc
#
#  Do feel free, however, to use this script as an example of how to
#  operate 'chat' and the ppp-daemon, as well as an example of
#  shell-script programming.
#
#  Enjoy!
#
#  -jpw, 8/16/96 [weissjp@colorado.edu]
#
#######################################################



###############
#
# Global Variables
#
###############

# Extend the path - locally - in this script for the purpose of
# searching for various binaries.
PATH="${PATH}:/usr/sbin/:/sbin/"

#  Alas, /bin/sh isn't as good at passing/returning values as, say,
#  perl, so I'll use some global vars for this purpose.  Hey, at least
#  a Bourne-shell script will run on any Unix system, regardless of
#  setup.  :)

RCFILE="/etc/ppp/ppp-multidial.rc"

#  Variables read by the .rc file.  Declared here so that they exist,
#  even if they get commented out in the .rc file.
#
GLOBAL_USERNAME=""
GLOBAL_PASSWD=""

PHONE1=""
PHONE2=""
PHONE3=""
PHONE4=""
PHONE5=""

USERNAME1=""
USERNAME2=""
USERNAME3=""
USERNAME4=""
USERNAME5=""

PASSWD1=""
PASSWD2=""
PASSWD3=""
PASSWD4=""
PASSWD5=""

MODEM_INIT_STR="ATE1Q0V1X4&C1&D2S0=0S11=55S6=4S95=47"
STTY_MODEM="-parenb cs8 -cstopb"
EXTRA_PPP_OPTIONS=""
EXTRA_CHAT_LOGIN_COMMANDS=""
CHAT_VERBOSE=""

# These could be set/reset in the .rc file.  They all must have a
# default value.
#
CALL_WAITING_BLOCK_PREFIX="*70,"
					   # this one is valid in most areas of the US
MODEM="modem"               # omit the /dev/ - it's assumed.
DEFAULT_TIMEOUT="60"
DIAL_TIMEOUT="120"
MODEM_RESET_STR="ATZ"
POSTCONNECT_TIMEOUT="120"
USERPROMPT="sername:"
PASSWDPROMPT="assword:"
PPPCMDPROMPT="nnex:"
PPPSTARTCMD="ppp"
MODEM_LOCKFILE_STEM="/var/lock/LCK.."
PPPD_LOCKFILE="/var/run/ppp0.pid"

# You might want to set these to something else if "which" can't find
# them.
#
CHATBIN=`which chat`
PSBIN=`which ps`
PPP_DAEMON=`which pppd`
GREP_CMD=`which grep`
SEDCMD=`which sed`
TTYCMD=`which tty`
STTYCMD=`which stty`


# None of these should be touched
#
CHAT_CMD="${CHATBIN} ${CHAT_VERBOSE}"
PS_CMD="${PSBIN} -aux"
LOGFILE="/tmp/ppp-multidial.dial-log"
STTY_DEFAULTS="38400 -tostop hupcl hup crtscts"
BCW_FLAG=""
BCW_PREFIX=""
ONENUM_FLAG=""
ONLY_USE=""
DIAL_STYLE="attack"
REPEAT_TIMES=1
SKIP_NEXT_PARAM="n"
FULL_DIALIN_LIST=""
CHAT_SCRIPT=""
MODEM_DEV=""
MODEM_LOCKFILE=""


###############
#
# Functions
#
###############



#
#  Process the .rc file
#
loadrc ()
{
    if [ -f ${RCFILE} ] ; then
	   source ${RCFILE}
    else
	   echo "!"
	   echo "FATAL ERROR!  Can't find config file ${RCFILE}!"
	   echo " "
	   exit -10
    fi
    
    if [ "${BCW_FLAG}" = "y" ] ; then
	   echo "Blocking call-waiting."
	   BCW_PREFIX=${CALL_WAITING_BLOCK_PREFIX}
    else
	   BCW_PREFIX=""
    fi

    # Set Global Username, if specified
    #
    if [ "${GLOBAL_USERNAME}" != "" ] ; then
	   USERNAME1=${GLOBAL_USERNAME}
	   USERNAME2=${GLOBAL_USERNAME}
	   USERNAME3=${GLOBAL_USERNAME}
	   USERNAME4=${GLOBAL_USERNAME}
	   USERNAME5=${GLOBAL_USERNAME}
    fi

    # Set Global Password, if specified
    #
    if [ "${GLOBAL_PASSWD}" != "" ] ; then
        PASSWD1=${GLOBAL_PASSWD}
        PASSWD2=${GLOBAL_PASSWD}
        PASSWD3=${GLOBAL_PASSWD}
        PASSWD4=${GLOBAL_PASSWD}
        PASSWD5=${GLOBAL_PASSWD}
    fi

    # Now assemble the dialup list using the defined phone numbers and
    # their corresponding username & password.  If there is no
    # username or password specified, skip that phone number.
    #
    # Additionally, use sed to strip any "-" from the phonenumbers,
    # since chat will gag on these.
    #
    echo -n "Getting dial-in lines: "
    if [ "${PHONE1}" != "" -a "${USERNAME1}" != "" -a "${PASSWD1}" != "" ] ; 
    then
	   phone1_s="${BCW_PREFIX}`echo ${PHONE1} | ${SEDCMD} 's/-//'`"
	   dlst1="${phone1_s} ${USERNAME1} ${PASSWD1}"
	   echo -n "1 "
    else
	   dlst1=""
    fi
    #
    if [ "${PHONE2}" != "" -a "${USERNAME2}" != "" -a "${PASSWD2}" != "" ] ;
    then
	   phone2_s="${BCW_PREFIX}`echo ${PHONE2} | ${SEDCMD} 's/-//'`"
        dlst2="${phone2_s} ${USERNAME2} ${PASSWD2}"
	   echo -n "2 "
    else
        dlst2=""
    fi
    #
    if [ "${PHONE3}" != "" -a "${USERNAME3}" != "" -a "${PASSWD3}" != "" ] ;
    then
	   phone3_s="${BCW_PREFIX}`echo ${PHONE3} | ${SEDCMD} 's/-//'`"
        dlst3="${phone3_s} ${USERNAME3} ${PASSWD3}"
	   echo -n "3 "
    else
        dlst3=""
    fi
    #
    if [ "${PHONE4}" != "" -a "${USERNAME4}" != "" -a "${PASSWD4}" != "" ] ;
    then
	   phone4_s="${BCW_PREFIX}`echo ${PHONE4} | ${SEDCMD} 's/-//'`"
        dlst4="${phone4_s} ${USERNAME4} ${PASSWD4}"
	   echo -n "4 "
    else
        dlst4=""
    fi
    #
    if [ "${PHONE5}" != "" -a "${USERNAME5}" != "" -a "${PASSWD5}" != "" ] ;
    then
	   phone5_s="${BCW_PREFIX}`echo ${PHONE5} | ${SEDCMD} 's/-//'`"
        dlst5="${phone5_s} ${USERNAME5} ${PASSWD5}"
	   echo -n "5 "
    else
        dlst5=""
    fi
    echo "."
    

    # Lastly, assemble the full list.
    #
    if [ "${dlst1}" = "" -a "${dlst2}" = "" -a "${dlst3}" = "" -a \
    "${dlst4}" = "" -a "${dlst5}" = "" ] ; then
	   echo "!"
	   echo "Error!  No phone numbers, usernames, or passwords"
	   echo "specified in ${RCFILE}."
	   echo "Nothing to dial."
	   echo " "
	   exit -11
    elif [ "${ONENUM_FLAG}" = "y" ] ; then
	   fdl=""
	   onlylist="`echo ${ONLY_USE} | ${SEDCMD} 's/,/ /g'`"
	   echo -n "Using lines: "
	   for ii in ${onlylist}; do
		  case ${ii} in 
			 1)
				fdl="${fdl} ${dlst1}"
				echo -n "1, "
				;;
			 2)
				fdl="${fdl} ${dlst2}"
				echo -n "2, "
				;;
			 3)
				fdl="${fdl} ${dlst3}"
				echo -n "3, "
				;;
			 4)
				fdl="${fdl} ${dlst4}"
				echo -n "4, "
				;;
			 5)
				fdl="${fdl} ${dlst5}"
				echo -n "5, "
				;;
			 *)
				echo " "
				echo " "
				echo "Number(s) specified in '-only' flag must be"
				echo "between 1 and 5 in a comma-separated list."
				exit -12
				;;
		  esac
	   done
	   FULL_DIALIN_LIST="${fdl}"

	   if [ "x${FULL_DIALIN_LIST}" = "x" ] ; then
		  echo "Error:  Phone number(s) '${ONLY_USE}' don't exist!"
		  exit -13
	   fi
	   echo "."
    else
	   FULL_DIALIN_LIST="${dlst1} ${dlst2} ${dlst3} ${dlst4} ${dlst5}"
	   echo "Using all lines."
    fi

## End of loadrc ##
}


#
#  Print out a usage description and exit.
#
usage ()
{
    echo " "
    echo " "
    echo "Usage:  ppp-multidial [-ncw -once -repeat n -only n]"
    echo " "
    echo "Dials an ISP and connects via PPP"
    echo " "
    echo "-ncw = block call-waiting"
    echo "-once = perform only one dialing cycle"
    echo "-repeat n = repeat the dialing cycle 'n' times"
    echo "-only n = only use phone number 'n'.  'n' may be a"
    echo "          comma-separated list."
    echo " "
    echo "Default is attack-dialing until a connection is made."
    echo " "
    exit 0

## End of usage ##
}


#
# Check to see if the ppp daemon is running.
#
checkpppd ()
{
    stat=`${PS_CMD} | ${GREP_CMD} ${PPP_DAEMON} | ${GREP_CMD} -v ${GREP_CMD}`
    if [ "x${stat}" = "x" ]; then
	   return 1
    else
	   return 0
    fi
}


#
#  Assembles the chat script.  Requires 3 arguments:
#  phone# username passwd
#
makechat ()
{
    # The \\\\ is to protect parts of the dialin script from the eval
    #  command.  The echo command will translate \\\\ into \\ which
    #  eval then turns into a single \

    phonenum=$1
    username=$2
    passwd=$3
    null="''"
    t_o="TIMEOUT"

    abort1="ABORT BUSY"
    abort2="ABORT NO\\\\sCARRIER"
    abort3="ABORT NOT\\\\sCONNECTED"
    connect="REPORT CONNECT"

    dial_to="${t_o} ${DIAL_TIMEOUT}"
    postconn_to="${t_o} ${POSTCONNECT_TIMEOUT}"
    default_to="${t_o} ${DEFAULT_TIMEOUT}"

    reset="${null} ${MODEM_RESET_STR}"
    okay="OK \\\\d"
    dialin="${null} ATDT${phonenum}"
    remoteconn="CONNECT \\\\n"
    xtraret="${null} \\\\n"
    logincmd1="${null} \\\\n"
    logincmd2="${USERPROMPT}--${USERPROMPT} ${username}"
    logincmd3="${PASSWDPROMPT}--${PASSWDPROMPT} \\\\q${passwd}"
    logincmd4=${EXTRA_CHAT_LOGIN_COMMANDS}

    startppp="${PPPCMDPROMPT}--${PPPCMDPROMPT} ${PPPSTARTCMD}"

    # assemble the chat script
    #

    echo -n "${abort1} ${abort2} ${abort3} ${connect} "
    echo -n "${default_to} ${reset} ${okay} "
    echo -n "${dial_to} ${dialin} ${remoteconn} "
    echo -n "${postconn_to} ${xtraret} ${logincmd1} ${logincmd2} "
    echo -n "${xtraret} ${logincmd3} ${logincmd4} "
    echo -n "${startppp} "

## End of makechat ##
}


#
#  Prints a verbal reason for chat failure.
#
failmesg ()
{
echo -n "           > "

case $1 in
    3)
	   echo -n "Connection Timeout"
	   ;;
    4)
	   echo -n "Busy"
	   ;;
    5)
	   echo -n "No Carrier"
	   ;;
    6)
	   echo -n "Not Connected"
	   ;;
    *)
	   echo -n "chat Failure: $1"
	   ;;
esac
echo " <"
}


#
#  Performs a single dialup.
#  Arguments are phone#, username, passwd
#
dialonce ()
{
    stdout="`eval ${TTYCMD}`"
    CHAT_SCRIPT="`makechat $1 $2 $3`"

    echo -n "     Dialing..."

    echo "" >> ${LOGFILE}
    echo "----" >> ${LOGFILE}



    # MUST use the "eval" command to parse the null string.
    # Otherwise, the '' is passed to chat, and chat sits there waiting
    # for the modem to send it a pair of quotes.  :P
    #
    (
	   ${STTYCMD} ${STTY_DEFAULTS} ${STTY_MODEM}
	   eval ${CHAT_CMD} ${CHAT_SCRIPT}
	   stat=$?
	   
	   if [ ${stat} -eq 0 ] ; then
		  connected="yes"
	   else
		  connected="no"
	   fi

	   if [ "${connected}" = "yes" ] ; then
		  echo "" > ${stdout}
		  echo -n "     !!! Connection Established." > ${stdout}
		  sleep 2s
		  echo "  Starting pppd." > ${stdout}
		  ${PPP_DAEMON} ${MODEM_DEV} ${EXTRA_PPP_OPTIONS} &
		  echo -n "         Please wait..." > ${stdout}
		  sleep 10s
		  checkpppd
		  stat=$?
		  if [ ${stat} -eq 0 ]; then
			 echo "     Daemon Started." > ${stdout}
		  else
			 echo "     Daemon has died!" > ${stdout}
			 echo "Dead daemon.  Removing lockfiles." >>${LOGFILE}
			 rm -f ${MODEM_LOCKFILE} ${PPPD_LOCKFILE} 2>&1 >>${LOGFILE}
		  fi
	   fi

	   return ${stat}
    ) < ${MODEM_DEV} > ${MODEM_DEV} 2>>${LOGFILE}

## End of dialonce ##
}


#
#  Dials a list of phone numbers.
#  The list of arguments consists of triplets containing:
#    phone# username passwd
#  ...in that order.
#
diallist ()
{
    connected="no"
    while [ "$3" != "" -a "${connected}" = "no" ]; do
	   phonenum=$1
	   username=$2
	   passwd=$3
	   shift 3
	   
	   echo -n "     Attempting line: ${phonenum}"
	   dialonce ${phonenum} ${username} ${passwd}
	   stat=$?

	   if [ ${stat} -eq 0 ] ; then
		  connected="yes"
	   else
		  failmesg ${stat}
		  echo "     Connection Failed."
		  connected="no"
	   fi
    done

    if [ "${connected}" = "yes" ] ; then
	   return 0
    else
	   return 1
    fi

## End of diallist ##
}


#
#  Keeps dialing until it gets a connection
#
repeat-dial ()
{
    connected="no"
    i="0"

    while [ "${connected}" = "no" -a ${i} != ${REPEAT_TIMES} ]; do
	   echo -n "${i}: "
	   diallist ${FULL_DIALIN_LIST}

        if [ $? -eq 0 ] ; then
            connected="yes"
        else
            connected="no"
        fi
	   
	   i=`expr ${i} + 1`
    done

    if [ "${connected}" = "yes" ] ; then
	   return 0
    else
	   return 1
    fi

## End of connect_ppp ##
}


#
#  Keeps dialing until it gets a connection
#
attack-dial ()
{
    connected="no"
    while [ "${connected}" = "no" ]; do
	   diallist ${FULL_DIALIN_LIST}
        if [ $? -eq 0 ] ; then
            connected="yes"
        else
            connected="no"
        fi
    done

    if [ "${connected}" = "yes" ] ; then
	   return 0
    else
	   return 1
    fi

## End of connect_ppp ##
}


#
#  Initialize the modem
#
modem-init ()
{
    # First, set some variables.
    MODEM_DEV="/dev/${MODEM}"
    MODEM_LOCKFILE="${MODEM_LOCKFILE_STEM}${MODEM}"

    # check to make sure we don't have an active connection 
    # running.
    echo -n "Checking modem status..."
    if [ -f ${PPPD_LOCKFILE} -o -f ${MODEM_LOCKFILE} ]; then
	   echo "lockfile(s) present.  Checking for running daemon."
	   checkpppd
	   if [ $? -eq 0 ]; then
		  echo ""
		  echo "PPP daemon present and running."
		  echo "If your net connection isn't working, wait a bit."
		  echo "If things still don't work, try disconnecting your"
		  echo "current connection before redialing."
		  echo "Aborting dialin script."
		  echo ""
		  exit 1
	   else
		  echo -n "No running daemon present.  "
		  if [ -f ${PPPD_LOCKFILE} ]; then
			 echo -n "Removing stale PPP lockfile.  "
			 rm -f ${PPPD_LOCKFILE}
		  fi

		  if [ -f ${MODEM_LOCKFILE} ]; then
			 echo -n "Removing stale modem lockfile."
			 rm -f ${MODEM_LOCKFILE}
		  fi
		  echo ""
	   fi
    fi

    #  Here, we DON'T want to use eval, since it will attempt to
    #  interpret some of the command characters being sent to the
    #  modem.  Since we can send the '' directly, we don't need to use
    #  the eval command, anyway.
    #
    if [ -f ${LOGFILE} ] ; then
	   rm -f ${LOGFILE}
    fi
    echo "" > ${LOGFILE}
    chmod a+w ${LOGFILE}
    chown --silent nobody.dip ${LOGFILE}

    echo "Initializing the modem."
    (
	   ${STTYCMD} ${STTY_DEFAULTS} ${STTY_MODEM}
	   ${CHAT_CMD} '' ${MODEM_INIT_STR}
    ) < ${MODEM_DEV} > ${MODEM_DEV} 2>>${LOGFILE}

    echo "||||||||" >> ${LOGFILE}

## End of modem-init ##
}



###############
#
# Main
#
###############


# Option Processing
#
for i in $*; do
    case $i in
	    -ncw)
		    BCW_FLAG="y"
		    shift
		    ;;
	    -once)
		    DIAL_STYLE="repeat"
		    REPEAT_TIMES=1
		    shift
		    ;;
	    -repeat)
		    DIAL_STYLE="repeat"
		    shift
		    REPEAT_TIMES=$1
		    SKIP_NEXT_PARAM="y"
		    shift
		    ;;
	    -only)
		    ONENUM_FLAG="y"
		    shift
		    ONLY_USE=$1
		    SKIP_NEXT_PARAM="y"
		    shift
		    ;;
	    *)
		    if [ "${SKIP_NEXT_PARAM}" = "y" ] ; then
			 SKIP_NEXT_PARAM="n"
		    else
			 usage
		    fi
		    ;;	    
    esac
done



loadrc
modem-init

if [ "${DIAL_STYLE}" = "repeat" ] ; then
    echo "Performing ${REPEAT_TIMES} attempts."
    repeat-dial
else
    echo "Performing attack dialing."
    attack-dial
fi

if [ $? -eq 0 ] ; then
    echo ""
    echo "~^~^~^~^~^~^~^~^~^~^~^~^~^~^~^~"
    echo ""
    echo "Success."
else
    echo ""
    echo "_._._._._._._._._._._._._._._._"
    echo ""
    echo "Failure."
fi


