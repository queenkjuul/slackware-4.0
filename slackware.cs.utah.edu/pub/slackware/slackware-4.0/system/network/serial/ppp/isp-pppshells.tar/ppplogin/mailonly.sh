
echo "This account is for email only and cannot be used
for login access."
