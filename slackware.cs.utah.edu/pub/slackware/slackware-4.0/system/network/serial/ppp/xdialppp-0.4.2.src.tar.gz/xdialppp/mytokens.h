#ifndef __mytokens_h__
#define __mytokens_h__

/*  -------------------------------------------------------------------------
	findSubStr(const char *thestring, const char *pattern)
 
		function :
			tries to find pattern in thestring
		return :
			the position where the pattern finishes + 1 if pattern 
				is found in thestring
			-1 else
    ------------------------------------------------------------------------- */

int findSubStr(const char *thestring, const char *pattern);


/*  -------------------------------------------------------------------------
	getToken(const char *message, const char *prompt)
 
		function :
			Returns a pointer to the string starting at the
			point where prompt finishes.
		return :
			a char *
			NULL if prompt is not found
		How the hell do you use it ?
			Example: you have the string "PHONE=264896"
			you call getToken(string,"PHONE=")
			and returns 264896
    ------------------------------------------------------------------------- */

char *getToken(char * dest, const char *message, const char *prompt);


int beginsWith(const char *message, char c);


char * removeToken(char *dest, char * mystring, char c);



#endif
