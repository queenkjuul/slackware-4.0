#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <syslog.h>
#include "config.h"



int main(int argc, char **argv)
{   
    char command[1024];
    char tty[50];
    char n=0;
    char **args = malloc(sizeof(char *) * (argc + 1));
    
    strcpy(tty,ttyname(0));
    
    args[0] = PATH_PPPD;
    args[1] = tty; 
    n = 1;
    while (argv[n] != NULL) {
      args[n+1] = argv[n];
      n++; 
    }
    args[n+1] = NULL;  
    openlog("ppplogin",LOG_PID,LOG_LOCAL2);
    
    sprintf(command,"/usr/sbin/pppchkmulti %s %d &",tty,getpid());
    system(command); 
    syslog(LOG_INFO,"firing up pppd");
    execv(PATH_PPPD,args); 
  /*  execl(PATH_PPPD,PATH_PPPD,tty,PPPD_OPTIONS); */
    return 0; /* not reached */
    
}   

