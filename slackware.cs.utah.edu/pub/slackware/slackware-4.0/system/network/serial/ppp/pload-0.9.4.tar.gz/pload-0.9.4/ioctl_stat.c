/*
    This file is part of pload - a program to monitor ppp activity for X
    Copyright (C) 1999  Matt Smith <mdsmith@engr.utk.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

/* ioctl_stat.c */

#include <stdio.h>		/* sprintf */
#include <string.h>		/* memset */
#include <unistd.h>
#include <sys/types.h>		/* socket */
#include <sys/stat.h>		/* open */
#include <fcntl.h>		/* open */
#include <sys/ioctl.h>		/* ioctl */
#include <errno.h>

#ifndef STREAMS			/* Linux, FreeBSD, NetBSD, Ultrix */
#	include <sys/socket.h>	/* socket */
#	ifndef linux
#		include <net/if.h>
#		include <net/ppp_defs.h>
#		include <net/if_ppp.h>
#	else /* linux */
#		if __GLIBC__ >= 2 
#			include <net/if.h>
#			include <net/ppp_defs.h>
#			include <net/if_ppp.h>
#		else
#			include <linux/if.h>
#			include <linux/ppp_defs.h>
#			include <linux/if_ppp.h>
#		endif /* GLIBC */
#	endif /* linux */
#else /* STREAMS */		/* Solaris, SunOS, OSF/1, SVR4 */
#	include <net/ppp_defs.h>
#	include <net/pppio.h>
#endif /* STREAMS */

#include "pload.h"

/* global variables */
static int s = -1;		/* socket or fd */
extern int errno;

#ifndef STREAMS /***************************************/

void getsocket()
{
	if ((s = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
		die("socket");
	return;
}

void ioctl_stat(if_data *ifd)
{
	struct ifpppstatsreq req;
	
	if (s < 0) getsocket();
	
	memset(&req, 0, sizeof(req));
#ifdef linux
#undef ifr_name
#define ifr_name ifr__name
	req.stats_ptr = (caddr_t) &req.stats;
#endif
	sprintf(req.ifr_name, ifd->device);
	
	if (ioctl(s, SIOCGPPPSTATS, &req) != 0)
	{
		/* non-existant device? */
		ifd->in_bytes = 0UL;
		ifd->out_bytes = 0UL;
		return;
	}
	
	ifd->in_bytes = (unsigned long)req.stats.p.ppp_ibytes;
	ifd->out_bytes = (unsigned long)req.stats.p.ppp_obytes;
	
	return;
}

#else /*STREAMS */ /******************************************/

void getsocket()	/* not really a socket... */
{
#ifdef osf
	if ((s = open("/dev/streams/ppp", O_RDONLY)) == -1)
		die("couldn't open /dev/streams/ppp");
#else
	if ((s = open("/dev/ppp", O_RDONLY)) == -1)
		die("couldn't open /dev/ppp");
#endif
	return;
}

void ioctl_stat(if_data *ifd)
{
	struct ppp_stats req;
	
	if (s < 0) getsocket();
	
	memset(&req, 0, sizeof(req));
	if (strioctl(s, PPPIO_GETSTAT, &req, 0, sizeof(req)) == -1)
	{
		if (errno == EINVAL) /* connection dropped */
		{
			/* try again */
			(void)strioctl(s, PPPIO_ATTACH, 
			&ifd->dev_n, sizeof(ifd->dev_n), 0);
		}
		/* no connection */
		ifd->in_bytes = 0UL;
		ifd->out_bytes = 0UL;
		return;
	}
	
	ifd->in_bytes = (unsigned long)req.p.ppp_ibytes;
	ifd->out_bytes = (unsigned long)req.p.ppp_obytes;
	
	return;
}

#endif /*STREAMS */ /******************************************/
