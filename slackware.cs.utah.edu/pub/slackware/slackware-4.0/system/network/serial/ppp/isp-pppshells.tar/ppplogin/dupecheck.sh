numlogins=`who |
egrep "$LOGNAME" |
wc -l`
case $numlogins in
 *"0"*|*"1"*) /etc/ppp/ppp.sh
 ;;
 *) /etc/ppp/dupealert.sh
 ;;
esac

    

