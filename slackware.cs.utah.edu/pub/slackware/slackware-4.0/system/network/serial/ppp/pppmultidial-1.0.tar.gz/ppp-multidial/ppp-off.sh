#!/bin/sh
# ppp-multidial.sh is Copyright (C) 1997 by John P. Weiss
##################
#
# I've actually adapted a different ppp-shutoff script to work
# together with "ppp-multidial.sh."  You can alter this as you wish.

DEVICE=ppp0
LOGFILE="/tmp/ppp-multidial.dial-log"


# Need to do this so that there is no lingering logfile around.
#
if [ -f ${LOGFILE} ] ; then
    rm -f ${LOGFILE}
fi

#
# If the ppp0 pid file is present then the program is running. Stop it.
if [ -r /var/run/$DEVICE.pid ]; then
        kill -INT `cat /var/run/$DEVICE.pid`
#
# If the kill did not work then there is no process running for this
# pid. It may also mean that the lock file will be left. You may wish
# to delete the lock file at the same time.
        if [ ! "$?" = "0" ]; then
                rm -f /var/run/$DEVICE.pid
                echo "Found stale pid file.  Removing..."
                exit 1
        fi
#
# Success. Let pppd clean up its own junk.
        echo "PPP link to $DEVICE terminated."
        exit 0
fi
#
# The PPP process is not running for ppp0
echo "PPP link is not active on $DEVICE"
exit 1
