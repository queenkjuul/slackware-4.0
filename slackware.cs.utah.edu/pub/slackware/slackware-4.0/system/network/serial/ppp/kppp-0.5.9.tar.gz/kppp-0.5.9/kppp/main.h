/* -*- C++ -*-
 *
 *            kPPP: A pppd front end for the KDE project
 *
 * $Id: main.h,v 1.3 1997/07/13 06:21:29 wuebben Exp $
 * 
 *            Copyright (C) 1997 Bernd Johannes Wuebben 
 *                   wuebben@math.cornell.edu
 *
 * based on EzPPP:
 * Copyright (C) 1997  Jay Painter
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this program; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#ifndef _MAIN_H_
#define _MAIN_H_

// this include is needed since gcc sometimes gets 
// confused if qdir.h is included later (strange error)
#include <qdir.h>


#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

#include <qapp.h>
#include <qchkbox.h>
#include <qdialog.h>
#include <qlabel.h>
#include <qwidget.h>
#include <qpushbt.h>
#include <qcombo.h>
#include <qtimer.h>
#include <qlcdnum.h>
#include <qpainter.h>
#include <qtabdlg.h>
#include <qradiobt.h>
#include <qchkbox.h> 
#include <qpixmap.h> 
#include <qchkbox.h>

#include <kapp.h>

#include "accounting.h"


#include "conwindow.h"
#include "general.h"
#include "accounts.h"
#include "connect.h"
#include "debug.h"
#include "pppstatdlg.h"

class XPPPWidget : public QWidget {

Q_OBJECT

public:

  XPPPWidget( QWidget *parent=0, const char *name=0 );
  ~XPPPWidget() {}

  void resetaccounts();
  friend void dieppp(int);              // if the pppd daemon dies...

  void startAccounting();
  void stopAccounting();

private slots:
  void newdefaultaccount(int);
  void expandbutton();
  void connectbutton();
  void quitbutton();
  void helpbutton();
  void setup();

public slots:
  void disconnect();

  //void lost_all_windows();

  void log_window_toggled(bool on);

signals:
  void begin_connect();
  void cmdl_start();

public:
  //  QCheckBox *log;
  QCheckBox *log;
  bool connected;
  DebugWidget *debugwindow;
  QString con_speed;
  ConnectWidget *con;
  ConWindow *con_win;
  PPPStatsDlg *stats;
  Accounting accounting;
  

private:

  QPushButton *quit_b;
  QPushButton *help_b;
  QPushButton *setup_b;
  QFrame *fline;
  QPushButton *connect_b;
  QComboBox *connectto_c;
  QLabel *label1;
  QLabel *label2;  
  QLabel *label3;
  QLabel *label4;
  QLabel *label5;
  QLabel *label6;
  QLabel *radio_label;


  QTabDialog *tabWindow;
  AccountWidget *accounts;
  GeneralWidget *general;
  ModemWidget *modem;
  AboutWidget *about;
};

extern XPPPWidget *p_xppp;
extern void killppp();
void dieppp(int);

#endif
