#ifndef __CONFIG_H
#define __CONFIG_H

#define PATH_PPPD "/usr/sbin/pppd" 
#define PPPLOGIN_CONF "/etc/ppp/ppplogin.conf"
#define DEFAULT_MAXLOGIN 1


#endif