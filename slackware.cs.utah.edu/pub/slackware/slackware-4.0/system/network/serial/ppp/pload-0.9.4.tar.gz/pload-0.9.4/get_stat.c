/*
    This file is part of pload - a program to monitor ppp activity for X
    Copyright (C) 1999  Matt Smith <mdsmith@engr.utk.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/


/* get_stat.c */
#include <stdio.h>		/* perror */
#include <stdlib.h>		/* exit */
#include <unistd.h>		/* gettimeofday */
#include <sys/time.h>		/* gettimeofday */
#include <errno.h>
#include "pload.h"

/* global variables */
extern int errno;
static unsigned long in_old = 0UL;
static unsigned long out_old = 0UL;

void get_stat(if_data *ifd)
{
	double delta_t;
	double rate;
	double sum;
	int i;
	
	/* get in_bytes and out_bytes */
	ifd->getstats(ifd);
	
	if (gettimeofday(&ifd->curr_time, NULL) != 0)
		die("gettimeofday");
	
	/* double seconds */	
	delta_t = (double)
		((ifd->curr_time.tv_sec - ifd->prev_time.tv_sec) * 1000000L
		+(ifd->curr_time.tv_usec - ifd->prev_time.tv_usec)) / 1000000.0;
	
	/******** in rate ******************/
	if ((in_old == 0UL) || (in_old > ifd->in_bytes))
		/* first time around or hangups */
		rate = 0.0;
	else
		rate =(double)(ifd->in_bytes - in_old) / delta_t;
	
	sum = 0.0;
	for (i=0;i<=ifd->history_size-2;i++)	/* doesn't happen if size==1 */
	{
		ifd->in_history[i] =
			ifd->in_history[i+1];	/* shift all past values down */
		sum +=ifd->in_history[i];	/* keep a running total */
	}
	
	ifd->in_history[ifd->history_size-1] = rate;	/* put current at end */
	
	/* averaged rate */
	ifd->in_rate = (sum + ifd->in_history[ifd->history_size-1])
		 / (double)ifd->history_size;
	/***********************************/
	
	/******** out rate ******************/
	if ((out_old == 0UL) || (out_old > ifd->out_bytes))
		/* first time around or hangups */
		rate = 0.0;
	else
		rate =(double)(ifd->out_bytes - out_old) / delta_t;
	
	sum = 0.0;
	for (i=0;i<=ifd->history_size-2;i++)	/* doesn't happen if size==1 */
	{
		ifd->out_history[i] = 
			ifd->out_history[i+1];	/* shift all past values down */
		sum +=ifd->out_history[i];	/* keep a running total */
	}
	
	ifd->out_history[ifd->history_size-1] = rate;	/* put current at end */
	
	/* averaged rate */
	ifd->out_rate = (sum + ifd->out_history[ifd->history_size-1])
		 / (double)ifd->history_size;
	/***********************************/
	
	
	/* old = new */
	memcpy(&ifd->prev_time, &ifd->curr_time, sizeof(struct timeval));
	in_old = ifd->in_bytes;
	out_old = ifd->out_bytes; 
	
	return;
}


void die(char *m)
{
	perror(m);
	exit(EXIT_FAILURE);
}

