/* $Id: patchlevel.h,v 1.32 1998/03/25 01:29:43 paulus Exp $ */
#define	PATCHLEVEL	4

#define VERSION		"2.3"
#define IMPLEMENTATION	""
#define DATE		"25 March 1998"
