
echo "

Your account has been turned off due to non-payment.

To re-establish your service, please contact us at
(XXX) XXX-XXXX. Thank you.

"
