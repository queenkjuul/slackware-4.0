/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "xppp.h"

FL_FORM *Xppp_Configurator;

FL_OBJECT
        *phone,
        *pro1,
        *ans1,
        *pro2,
        *ans2,
        *ans22,
        *pro3,
        *ans3,
        *pro4,
        *ans4,
        *ipaB,
        *advB,
        *genB,
        *quiB,
        *helB;

void create_form_Xppp_Configurator(void)
{
  FL_OBJECT *obj;

  if (Xppp_Configurator)
     return;

  Xppp_Configurator = fl_bgn_form(FL_NO_BOX,460,500);
  obj = fl_add_box(FL_UP_BOX,0,0,460,500,"");
  obj = fl_add_box(FL_FRAME_BOX,10,20,440,70,"");
  obj = fl_add_box(FL_FRAME_BOX,10,90,440,230,"");
  obj = fl_add_text(FL_NORMAL_TEXT,20,30,420,20,"ISP Information");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  phone = obj = fl_add_input(FL_NORMAL_INPUT,180,60,150,20,"Telephone");
    fl_set_object_callback(obj,phoneC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,20,100,420,20,"Account Information");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,120,320,40,"This consists in a set of prompts and answers.\nFor example : <prompt> = \"Username:\" -- <answer> = \"bbunny\".\n                      <prompt> = \"Password:\" -- <answer> = \"carrot\"");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  pro1 = obj = fl_add_input(FL_NORMAL_INPUT,80,200,140,20,"Prompt1");
    fl_set_object_callback(obj,pro1C,0);
  obj = fl_add_text(FL_NORMAL_TEXT,30,180,190,20,"Enter here \"Username:\" , \"Login:\" ,etc.");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  ans1 = obj = fl_add_input(FL_NORMAL_INPUT,290,200,140,20,"Answer1");
    fl_set_object_callback(obj,ans1C,0);
  obj = fl_add_text(FL_NORMAL_TEXT,240,180,190,20,"Enter here your username.");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  pro2 = obj = fl_add_input(FL_NORMAL_INPUT,80,250,140,20,"Prompt2");
    fl_set_object_callback(obj,pro2C,0);
  obj = fl_add_text(FL_NORMAL_TEXT,30,230,190,20,"Enter here \"Password:\" ,\"Passwd:\" ,etc.");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  ans2 = obj = fl_add_input(FL_SECRET_INPUT,290,250,140,20,"Answer2");
    fl_set_object_callback(obj,ans2C,0);
  obj = fl_add_text(FL_NORMAL_TEXT,240,230,190,20,"Enter here your password.");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  ans22 = obj = fl_add_input(FL_SECRET_INPUT,290,290,140,20,"Again !");
    fl_set_object_callback(obj,ans22C,0);
  obj = fl_add_text(FL_NORMAL_TEXT,240,270,190,20,"Enter again your password.");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  obj = fl_add_box(FL_FRAME_BOX,10,320,440,130,"");
  obj = fl_add_text(FL_NORMAL_TEXT,20,330,420,20,"Extra commands");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,350,320,30,"If your ISP expects you to issue any other command  like a \"ppp\"\nafter connecting, you can enter it here.");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  pro3 = obj = fl_add_input(FL_NORMAL_INPUT,80,390,140,20,"Prompt3");
    fl_set_object_callback(obj,pro3C,0);
  ans3 = obj = fl_add_input(FL_NORMAL_INPUT,290,390,140,20,"Answer3");
    fl_set_object_callback(obj,ans3C,0);
  pro4 = obj = fl_add_input(FL_NORMAL_INPUT,80,420,140,20,"Prompt4");
    fl_set_object_callback(obj,pro4C,0);
  ans4 = obj = fl_add_input(FL_NORMAL_INPUT,290,420,140,20,"Answer4");
    fl_set_object_callback(obj,ans4C,0);
  ipaB = obj = fl_add_button(FL_NORMAL_BUTTON,10,470,80,20,"IP Addresses");
    fl_set_object_color(obj,FL_COL1,FL_CYAN);
    fl_set_object_callback(obj,ipaC,0);
  advB = obj = fl_add_button(FL_NORMAL_BUTTON,100,470,80,20,"Connection");
    fl_set_object_color(obj,FL_COL1,FL_CYAN);
    fl_set_object_callback(obj,advC,0);
  genB = obj = fl_add_button(FL_NORMAL_BUTTON,280,470,80,20,"OK");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,genC,0);
  quiB = obj = fl_add_button(FL_NORMAL_BUTTON,370,470,80,20,"Quit");
    fl_set_object_color(obj,FL_COL1,FL_RIGHT_BCOL);
    fl_set_object_lcol(obj,FL_WHITE);
    fl_set_object_callback(obj,quiC,0);
  helB = obj = fl_add_button(FL_NORMAL_BUTTON,190,470,80,20,"Help");
    fl_set_object_color(obj,FL_COL1,FL_GREEN);
    fl_set_object_callback(obj,helC,0);
  fl_end_form();

}
/*---------------------------------------*/

FL_FORM *Xppp_IP_Addresses;

FL_OBJECT
        *locI,
        *remI,
        *netI,
        *ipokB,
        *ipcanB,
        *ipresB,
        *aonoiB,
        *aodefB,
        *preI,
        *posI;

void create_form_Xppp_IP_Addresses(void)
{
  FL_OBJECT *obj;

  if (Xppp_IP_Addresses)
     return;

  Xppp_IP_Addresses = fl_bgn_form(FL_NO_BOX,460,540);
  obj = fl_add_box(FL_UP_BOX,0,0,460,540,"");
  obj = fl_add_box(FL_FRAME_BOX,10,10,440,170,"");
  obj = fl_add_box(FL_FRAME_BOX,10,280,440,210,"");
  obj = fl_add_text(FL_NORMAL_TEXT,20,290,420,20,"Pre & post connection commands");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  locI = obj = fl_add_input(FL_NORMAL_INPUT,180,70,150,20,"Local IP");
    fl_set_object_callback(obj,locC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,20,40,420,30,"By default, dynamic IP is assumed. Do not change these settings if not sure.\nChange only if  you need to specify static IP address.");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  remI = obj = fl_add_input(FL_NORMAL_INPUT,180,100,150,20,"Remote IP");
    fl_set_object_callback(obj,remC,0);
  netI = obj = fl_add_input(FL_NORMAL_INPUT,180,150,150,20,"Netmask");
    fl_set_object_callback(obj,netC,0);
  ipokB = obj = fl_add_button(FL_NORMAL_BUTTON,60,510,80,20,"OK");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,ipokC,0);
  ipcanB = obj = fl_add_button(FL_NORMAL_BUTTON,300,510,80,20,"Cancel");
    fl_set_object_callback(obj,ipcanC,0);
  ipresB = obj = fl_add_button(FL_NORMAL_BUTTON,180,510,80,20,"Reset");
    fl_set_object_callback(obj,ipresC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,20,130,420,20,"By default, C class network is assumed. Change if needed.");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  obj = fl_add_box(FL_FRAME_BOX,10,180,440,100,"");
  obj = fl_add_text(FL_NORMAL_TEXT,20,190,420,20,"Routing Options");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  aonoiB = obj = fl_add_lightbutton(FL_PUSH_BUTTON,320,220,100,20,"No IP default");
    fl_set_object_callback(obj,aonoiC,0);
  aodefB = obj = fl_add_lightbutton(FL_PUSH_BUTTON,320,250,100,20,"Default route");
    fl_set_object_callback(obj,aodefC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,30,220,290,20,"Dinamic IP assignament (Turn off for static IP addresses)");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  obj = fl_add_text(FL_NORMAL_TEXT,30,250,290,20,"Add the ISP's address as default getaway.");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  preI = obj = fl_add_input(FL_NORMAL_INPUT,20,370,420,20,"");
    fl_set_object_callback(obj,preC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,20,310,420,40,"If you need to issue any command before attempting connection, you can enter it here.\nFor example, I need to delete the default gateway from the kernel routing table.\nTo do it , you should enter :' route del default'");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,350,200,20,"Pre connection command:");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_ENGRAVED_STYLE);
  posI = obj = fl_add_input(FL_NORMAL_INPUT,20,460,420,20,"");
    fl_set_object_callback(obj,posC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,20,400,420,40,"If you need to issue any command after closing connection, you can enter it here.\nFor example, I need to restore my default gateway to the kernel routing table.\nTo do it , you should enter :' route add default gw <Gateway IP> metric 1'");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,440,200,20,"Post connection command:");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,20,420,20,"IP addresses");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  fl_end_form();

}
/*---------------------------------------*/

FL_FORM *Xppp_Advanced_options;

FL_OBJECT
        *dialmode,
        *aotonB,
        *aopulB,
        *vollevel,
        *aovol0,
        *aovol1,
        *aovol2,
        *aovol3,
        *aortsB,
        *aodevI,
        *aotimI,
        *aoasyI,
        *aoescI,
        *aookB,
        *aoresB,
        *aocanB,
        *commspeed,
        *s115,
        *s57,
        *s38,
        *s19,
        *s9,
        *soth,
        *aospeI;

void create_form_Xppp_Advanced_options(void)
{
  FL_OBJECT *obj;

  if (Xppp_Advanced_options)
     return;

  Xppp_Advanced_options = fl_bgn_form(FL_NO_BOX,460,390);
  obj = fl_add_box(FL_UP_BOX,0,0,460,390,"");
  obj = fl_add_box(FL_FRAME_BOX,10,10,440,340,"");
  obj = fl_add_text(FL_NORMAL_TEXT,20,20,420,20,"Modem Options");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);

  dialmode = fl_bgn_group();
  obj = fl_add_box(FL_FRAME_BOX,200,90,100,60,"Dialing Mode");
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
  aotonB = obj = fl_add_checkbutton(FL_RADIO_BUTTON,210,100,80,20,"Tone Dialing");
    fl_set_object_callback(obj,aodiaC,0);
  aopulB = obj = fl_add_checkbutton(FL_RADIO_BUTTON,210,120,80,20,"Pulse Dialing");
    fl_set_object_callback(obj,aodiaC,1);
  fl_end_group();

  obj = fl_add_box(FL_FRAME_BOX,320,90,100,100,"Speaker volume");
    fl_set_object_lalign(obj,FL_ALIGN_TOP);

  vollevel = fl_bgn_group();
  aovol0 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,330,100,80,20,"0-Off");
    fl_set_object_color(obj,FL_COL1,FL_BLUE);
    fl_set_object_callback(obj,aovolC,0);
  aovol1 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,330,120,80,20,"1-Low");
    fl_set_object_color(obj,FL_COL1,FL_GREEN);
    fl_set_object_callback(obj,aovolC,1);
  aovol2 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,330,140,80,20,"2-Mid");
    fl_set_object_callback(obj,aovolC,2);
  aovol3 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,330,160,80,20,"3-High");
    fl_set_object_color(obj,FL_COL1,FL_RED);
    fl_set_object_callback(obj,aovolC,3);
  fl_end_group();

  aortsB = obj = fl_add_lightbutton(FL_PUSH_BUTTON,320,250,80,20,"RTS/CTS");
    fl_set_object_callback(obj,aortsC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,220,250,100,20,"Use flow control ?");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  aodevI = obj = fl_add_input(FL_NORMAL_INPUT,190,50,110,20,"Device");
    fl_set_object_callback(obj,aodevC,0);
  aotimI = obj = fl_add_input(FL_NORMAL_INPUT,100,250,40,20,"Timeout");
    fl_set_object_callback(obj,aotimC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,20,290,420,20,"It's better to leave the following options unchanged unless you know what you are doing!");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
  aoasyI = obj = fl_add_input(FL_NORMAL_INPUT,90,320,120,20,"Asyncmap");
    fl_set_object_callback(obj,aoasyC,0);
  aoescI = obj = fl_add_input(FL_NORMAL_INPUT,300,320,120,20,"Escape");
    fl_set_object_callback(obj,aoescC,0);
  aookB = obj = fl_add_button(FL_NORMAL_BUTTON,40,360,80,20,"OK");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,aookC,0);
  aoresB = obj = fl_add_button(FL_NORMAL_BUTTON,190,360,80,20,"Reset");
    fl_set_object_callback(obj,aoresC,0);
  aocanB = obj = fl_add_button(FL_NORMAL_BUTTON,340,360,80,20,"Cancel");
    fl_set_object_callback(obj,aocanC,0);

  commspeed = fl_bgn_group();
  obj = fl_add_box(FL_FRAME_BOX,40,90,150,140,"Connection speed");
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
  s115 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,50,100,90,20,"115200");
    fl_set_object_color(obj,FL_COL1,FL_RED);
    fl_set_object_callback(obj,speC,0);
  s57 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,50,120,90,20,"57600");
    fl_set_object_color(obj,FL_COL1,FL_DARKORANGE);
    fl_set_object_callback(obj,speC,0);
  s38 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,50,140,90,20,"38400");
    fl_set_object_callback(obj,speC,0);
  s19 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,50,160,90,20,"19200");
    fl_set_object_callback(obj,speC,0);
  s9 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,50,180,90,20,"9600");
    fl_set_object_color(obj,FL_COL1,FL_GREEN);
    fl_set_object_callback(obj,speC,0);
  soth = obj = fl_add_checkbutton(FL_RADIO_BUTTON,50,200,90,20,"Other :");
    fl_set_object_color(obj,FL_COL1,FL_CYAN);
    fl_set_object_callback(obj,speC,1);
  fl_end_group();

  aospeI = obj = fl_add_input(FL_INT_INPUT,110,200,70,20,"");
    fl_set_object_callback(obj,aospeC,0);
  fl_end_form();

}
/*---------------------------------------*/

FL_FORM *stoping;

FL_OBJECT
        *stitle,
        *stext,
        *sokB;

void create_form_stoping(void)
{
  FL_OBJECT *obj;

  if (stoping)
     return;

  stoping = fl_bgn_form(FL_NO_BOX,420,160);
  obj = fl_add_box(FL_UP_BOX,0,0,420,160,"");
  stitle = obj = fl_add_text(FL_NORMAL_TEXT,40,10,340,30,"Stop");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,stitleC,0);
  stext = obj = fl_add_text(FL_NORMAL_TEXT,20,50,380,60,"");
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_callback(obj,stextC,0);
  sokB = obj = fl_add_button(FL_NORMAL_BUTTON,160,130,90,20,"OK");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,sokC,0);
  fl_end_form();

}
/*---------------------------------------*/

FL_FORM *helping;

FL_OBJECT
        *hokB;

void create_form_helping(void)
{
  FL_OBJECT *obj;

  if (helping)
     return;

  helping = fl_bgn_form(FL_NO_BOX,460,450);
  obj = fl_add_box(FL_UP_BOX,0,0,460,450,"");
  obj = fl_add_text(FL_NORMAL_TEXT,20,10,420,30,"About Xdialppp");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,40,420,90,"X front end to configurate and manage ppp connections - version 0.4.2 .\nProgrammed by Diego Rodrigo.\n d.rodrigo@computer.org\nhttp://www.geocities.com/MotorCity/5501/xdialppp.html\n\nBuilt with Xforms designer and xforms library.\nFor information about xforms, visit : http://bragg.phys.uwm.edu/xforms");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,170,420,30,"Help");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,200,420,210,"Sorry, no help is currently available.\n\n\n\nThere will be a FAQ soon.\n\n\n\nFeel free to e-mail the author for comments or suggestions.");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
  hokB = obj = fl_add_button(FL_NORMAL_BUTTON,180,420,90,20,"OK");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
    fl_set_object_callback(obj,hOKC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,50,140,360,20,"Diego Rodrigo            d.rodrigo@computer.org");
    fl_set_object_lsize(obj,FL_MEDIUM_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_ENGRAVED_STYLE);
  fl_end_form();

}
/*---------------------------------------*/

FL_FORM *xppp_launch;

FL_OBJECT
        *logBrowser,
        *cconB,
        *cquiB,
        *cdisB,
        *cconnB,
        *ppptext,
        *dialtext,
        *cselB,
        *mysite,
        *myISP,
        *phoneline;

void create_form_xppp_launch(void)
{
  FL_OBJECT *obj;

  if (xppp_launch)
     return;

  xppp_launch = fl_bgn_form(FL_NO_BOX,460,440);
  obj = fl_add_box(FL_UP_BOX,0,0,460,440,"");
  obj = fl_add_box(FL_FRAME_BOX,10,290,440,110,"");
  obj = fl_add_box(FL_FRAME_BOX,10,10,440,280,"");
  obj = fl_add_text(FL_NORMAL_TEXT,20,20,420,30,"ppp connection log");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  logBrowser = obj = fl_add_browser(FL_NORMAL_BROWSER,20,70,420,180,"");
/*Five lines off*/
//  obj = fl_add_text(FL_NORMAL_TEXT,370,260,70,20,"00:00:00");
//    fl_set_object_boxtype(obj,FL_DOWN_BOX);
//    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
//  obj = fl_add_text(FL_NORMAL_TEXT,260,260,100,20,"Connection time :");
//    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);

  cconB = obj = fl_add_button(FL_NORMAL_BUTTON,250,410,90,20,"Configurate");
    fl_set_object_callback(obj,cconC,0);
  cquiB = obj = fl_add_button(FL_NORMAL_BUTTON,360,410,90,20,"Quit");
    fl_set_object_color(obj,FL_COL1,FL_RIGHT_BCOL);
    fl_set_object_lcol(obj,FL_WHITE);
    fl_set_object_callback(obj,cquiC,0);
  cdisB = obj = fl_add_button(FL_NORMAL_BUTTON,120,410,90,20,"Disconnect");
    fl_set_object_color(obj,FL_COL1,FL_RED);
    fl_set_object_callback(obj,cdisC,0);
  cconnB = obj = fl_add_button(FL_NORMAL_BUTTON,10,410,90,20,"Connect");
    fl_set_object_color(obj,FL_COL1,FL_GREEN);
    fl_set_object_lcol(obj,FL_RIGHT_BCOL);
    fl_set_object_callback(obj,cconnC,0);
  obj = fl_add_text(FL_NORMAL_TEXT,20,340,100,20,"Configuration file");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,370,100,20,"Configuration name");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,300,420,30,"Connection configuration file");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_MCOL,FL_MCOL);
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_NORMAL_STYLE+FL_EMBOSSED_STYLE);
  ppptext = obj = fl_add_text(FL_NORMAL_TEXT,120,340,190,20,"");
    fl_set_object_boxtype(obj,FL_DOWN_BOX);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  dialtext = obj = fl_add_text(FL_NORMAL_TEXT,120,370,190,20,"");
    fl_set_object_boxtype(obj,FL_DOWN_BOX);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  cselB = obj = fl_add_button(FL_NORMAL_BUTTON,340,370,90,20,"Select");
    fl_set_object_lcol(obj,FL_RIGHT_BCOL);
    fl_set_object_callback(obj,cselC,0);
  mysite = obj = fl_add_pixmap(FL_NORMAL_PIXMAP,20,250,90,40,"");
  myISP = obj = fl_add_pixmap(FL_NORMAL_PIXMAP,180,250,80,40,"");
  phoneline = obj = fl_add_pixmap(FL_NORMAL_PIXMAP,110,250,70,40,"");

/*Two lines off */
//  obj = fl_add_text(FL_NORMAL_TEXT,340,330,100,40,"Press 'Select'\nto choose another\nconfig file");
//    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);

  fl_end_form();

}
/*---------------------------------------*/

void create_the_forms(void)
{
  create_form_Xppp_Configurator();
  create_form_Xppp_IP_Addresses();
  create_form_Xppp_Advanced_options();
  create_form_stoping();
  create_form_helping();
  create_form_xppp_launch();
}

