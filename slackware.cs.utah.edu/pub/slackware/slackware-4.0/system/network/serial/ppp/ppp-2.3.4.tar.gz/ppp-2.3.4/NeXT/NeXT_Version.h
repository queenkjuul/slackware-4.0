/*
* ppp-2.3 port to the NeXT
* version_string 0.5.1
*
* $Id: NeXT_Version.h,v 1.1 1998/03/26 02:51:41 paulus Exp $
*/
#define PPPVERSION "0.5.1"
