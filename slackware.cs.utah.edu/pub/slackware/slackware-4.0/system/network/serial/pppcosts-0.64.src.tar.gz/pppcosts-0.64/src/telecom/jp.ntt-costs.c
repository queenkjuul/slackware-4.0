/* 
	This file is part of PPPCOSTS.
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2. No warranty.
	
	Modified by Dennis McMurchy for Japan NTT rates 11/96
	<denismcm@gol.com>
	
 	This is the costs file for the Japan NTT.
	Local Area prices.
	
	Please modify this file for your phone company's prices
	and send it to tst@bigfoot.com. Thanks a lot! 
*/

/* FYI this unit cost of 10 Japanese yen = 0.13 DM = 0.09 US$*/

#include "costs.h"

char DECIMALS= '0';
float INITIAL_COST=0;
char CURRENCY_AFTER_COST=0;
char CURRENCY[10]="JY";
float COSTS_PER_UNIT=10;

/* This defines zero decimals -> no decimal point is displayed,
   as with the Yen, it would always be .00 ;) */ 

int getunitlength(time_t tt){
	int unitsecs;
	struct tm* ct;
	/* Phone unit lengths for Japan NTT - hardcoded. */
	ct=localtime(&tt);
	/*	printf(" It's %u o'clock.\n", ct->tm_hour); */
	/* weekend discount does not affect local calls at all */
	if(ct->tm_hour < 8 || ct->tm_hour == 23) 	unitsecs=240;
	else    unitsecs=180;
	return unitsecs;
 }
	

