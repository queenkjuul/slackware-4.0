/* 
	This file is part of PPPCOSTS.
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2. No warranty.

	Costs file for Mobilcom 01019freenet Internet By Call
 
*/

#include "costs.h"

char DECIMALS= '2';
float INITIAL_COST=0;
char CURRENCY_AFTER_COST=0;
char CURRENCY[10]="DM ";
float COSTS_PER_UNIT=0.06;     

#define MOBILCOM_TAKT    60

int getunitlength(time_t tt){
   int unitsecs;
   unitsecs=MOBILCOM_TAKT;
   return unitsecs;
   
}
