/* 
	This file is part of PPPCOSTS.
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2. No warranty.

 	Phone costs for the Polish phone company Telekomunikacja
        Polska SA.  Valid from 1 June 1997.

	Local Area prices, with or without taxes.

	Adapted by Witold Kulinski <wkulin@ikp.atm.com.pl>.
	
	This is the most simple costfile. It seems strange
	to me that the unit prices don't depend on the time
	of the day.
	If this costfile is incorrect, please let me know.

	Please modify this file for your phone company's prices
	and send it to tst@bigfoot.com. Thanks a lot! 
*/

#include "costs.h"

char DECIMALS= '2';
float INITIAL_COST=0;
char CURRENCY_AFTER_COST=1;
char CURRENCY[10]=" PLN";

/* You may select whether you want taxes included... */
float COSTS_PER_UNIT=0.1926;		/* incl. VAT = 7% */
/* float COSTS_PER_UNIT=0.18;		/* excl. VAT */

int getunitlength(time_t tt)
 {
	int unitsecs;
	unitsecs=180;	
	return unitsecs;
 }
