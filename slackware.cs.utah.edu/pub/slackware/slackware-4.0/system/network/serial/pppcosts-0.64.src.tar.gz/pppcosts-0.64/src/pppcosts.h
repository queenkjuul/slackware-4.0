/* BEEP VALUES */	
int beep_before=10;
long maxtotal=0;
/*
 * if you want to be warned (continuous beeping) when you've been online
 * for too long, then assign a value to maxtotal. With the below value
 * pppcosts starts beeping when your total cost has reached 50 (DM, $
 * or whatever).
 * 
 long maxtotal=500;
 *
*/
long maxsession=20;

/*  Uncomment for an alternative log format
 *  #define ISOLOG */

/* ADD "Connection terminated." DISPLAY */

/* #define TELL_CONNECTION_TERMINATED */

/* TIME MODEM TAKES TO DIAL */

/* #define DIAL_TIME 10 */
