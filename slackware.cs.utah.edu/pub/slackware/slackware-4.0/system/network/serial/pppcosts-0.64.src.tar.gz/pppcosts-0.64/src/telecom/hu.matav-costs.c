/* 
	This file is part of PPPCOSTS.
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2.

	Modified by BaLi of IBMPC
	<tothbali@lisa.njszki.hu>

 	This is the cost file for the Hungarian phone company MATAV.
	Local Area prices.
	
	Please modify this file for your phone company's prices
	and send it to tst@bigfoot.com. Thanks a lot! 
*/

#include "costs.h"

char DECIMALS= '2';
float INITIAL_COST=0;
char CURRENCY_AFTER_COST=1;
char CURRENCY[10]=" Ft";
float COSTS_PER_UNIT=11.25;

int getunitlength(time_t tt){
	int unitsecs;
	struct tm* ct;
	/* Phone unit lengths for Hungarian Telephone Company (MATAV) - hardcoded. */
	ct=localtime(&tt);
	/*	printf(" It's %u o'clock.\n", ct->tm_hour); */
	if(*ctime(&tt)=='S'){  /* Smart way to check for weekends ;-) */
		
			
		if(ct->tm_hour>=5 &&  ct->tm_hour<22)   unitsecs=230;

	} else {
	
		
		if(((ct->tm_hour>=5 &&  ct->tm_hour<7)) || ((ct->tm_hour>=18 && ct->tm_hour<22))) unitsecs=230;
		if(((ct->tm_hour>=7 &&  ct->tm_hour<9)) || ((ct->tm_hour>=15 && ct->tm_hour<18))) unitsecs=110;
		if(ct->tm_hour>=9 &&  ct->tm_hour<15)   unitsecs= 90;

        }
        
	if(ct->tm_hour>= 22  || ct->tm_hour <5)  unitsecs=420;	
      		
	return unitsecs;
 }
	

