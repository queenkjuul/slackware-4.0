#include <time.h>

char  DECIMALS;
char  CURRENCY_AFTER_COST;
char  CURRENCY[10];

float COSTS_PER_UNIT;
float INITIAL_COST;
float MIN_COST;
char  PRICE_PER_MIN;

int getunitlength(time_t tt);
