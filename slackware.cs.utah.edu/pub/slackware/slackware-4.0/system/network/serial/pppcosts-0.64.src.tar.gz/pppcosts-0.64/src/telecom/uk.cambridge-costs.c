/* 
	This file is part of PPPCOSTS.
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2. No warranty.

	Modified by Anthony Dien Yiu Cheng
	<A.D.Y.Cheng@damtp.cam.ac.uk>

	This is the cost file for the Cambridge Cable Phone 
	Company, Cambridge, England.
	Local area prices.
	
	Warning: this costfile does not yet take advantage
        of the new per-minute price calculation. Results will
        be inaccurate.

	Please modify this file for your phone company's prices
	and send it to tst@bigfoot.com. Thanks a lot! 
*/

#include "costs.h"

char DECIMALS= '2';      
float INITIAL_COST=0;
char CURRENCY_AFTER_COST=1;
char CURRENCY[10]="UKpences "; 
float COSTS_PER_UNIT=0.069;

int getunitlength(time_t tt){
	int unitsecs;
	struct tm* ct;
	ct=localtime(&tt);
	/*	printf(" It's %u o'clock.\n", ct->tm_hour); */
	if(*ctime(&tt)=='S'){  /* Smart way to check for weekends ;-) */
		
			
		if(ct->tm_hour < 8)	 	 	unitsecs=6;
		if(ct->tm_hour>=8 &&  ct->tm_hour<18)   unitsecs=6;
		if(ct->tm_hour> 18) 		        unitsecs=6;	

	} else {
	
		
		if(ct->tm_hour < 8)	 	 	unitsecs=6;
		if(ct->tm_hour>=8 &&  ct->tm_hour<18)   unitsecs=1.45;
		if(ct->tm_hour> 18) 		        unitsecs=6;	
        }
	return unitsecs;
 }

