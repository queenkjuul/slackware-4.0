/*
	This file is part of PPPCOSTS, version 0.05
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2. No warranty.

	Modified by Luc Janssen <ljanssen@pi.net>
	30-jun-97
	 * new rates are used according to the `BelBasis' and 
	   `BelPlus' choice of PTT Telecom in the Netherlands.

        Modified by Erwin Waterlander <waterlan@xs4all.nl>
	25-mar-1999
	 * Tarif changes per 1-jul-1998
	   (Name changed from PTT to KPN)

       --------------------------------------------------------------
       Calls are subject to start charge of 9.9875ct and include VAT.
                                           (8.5ct excl. VAT (BTW))
       Prices are per minute. Payments are per second!

       Two types of charging: `BelBasis' and `BelPlus':

                                BelBasis           BelPlus
                             local  regional    local  regional 
       mon-fri 0800-1759     5.5ct  17.0ct      5.5ct  17.0ct     piek
       Other days and time   2.8ct   8.5ct      2.1ct   6.4ct     dal

       For calls which run over one charge period, each part of the call 
       will be charged pro rata. Normal charges apply on all holidays,
       Christmas and New Year.
       ----------------------------------------------------------------
	From 1-jul-1998 new tarifs (incl. BTW)
	
	start charge: 10ct
	
	prices per minute:
	
	Three types of charging: `BelBasis' and `BelPlus' and 'BelBudget'

                                BelBasis           BelPlus             BelBudget

                             binnen  buiten      binnen   buiten     binnen  buiten  
                             regio   regio       regio    regio      regio   regio  

       mon-fri 0800-1959     6.0ct   14.5ct      6.0ct    14.5ct     20.0ct  60.0ct   piek
       Other days and time   3.0ct    7.25ct     2.5ct     5.44ct    10.0ct  30.0ct   dal


       ----------------------------------------------------------------

	Please modify this file for your phone company's prices
	and send it to tst@bigfoot.com. Thanks a lot! 
*/

#include "costs.h"

char DECIMALS= '2';          /* eg 2 for 5.55 */
float INITIAL_COST = 0.10;  /* Necessary for the start charge of 10ct. */
char CURRENCY_AFTER_COST = 0;
char CURRENCY[10]="f ";       /* Dutch guilders */

/* Define what type of charging is in use for you: */
/* #define NL_BELBASIS */
#define NL_BELPLUS
/* #define NL_BUDGET */

/* define the rate for your IAP's area code */ 
#define NL_BINNEN_REGIO       
/* #define NL_BUITEN_REGIO */ 

/*-----------------------------------------------------------------------*/
/* The following prices are guilders per second and include VAT (BTW)    */

#ifdef NL_BELBASIS
#  ifdef NL_BINNEN_REGIO
#    define NL_DAL         0.0005
#    define NL_PEAK        0.001   
#  endif

#  ifdef NL_BUITEN_REGIO
#    define NL_DAL         0.0012083
#    define NL_PEAK        0.0024167
#  endif
#endif

#ifdef NL_BELPLUS
#  ifdef NL_BINNEN_REGIO
#    define NL_DAL         0.0004167
#    define NL_PEAK        0.001
#  endif

#  ifdef NL_BUITEN_REGIO
#    define NL_DAL         0.0009067
#    define NL_PEAK        0.0024167
#  endif
#endif

#ifdef NL_BUDGET
#  ifdef NL_BINNEN_REGIO
#    define NL_DAL         0.0016667
#    define NL_PEAK        0.0033333
#  endif

#  ifdef NL_BUITEN_REGIO
#    define NL_DAL         0.005
#    define NL_PEAK        0.01
#  endif
#endif

#define PRICE_PER_MIN

int getunitlength(time_t tt){
        struct tm* ct;
        /* Costs per minute for British Telecom - hardcoded. */
        ct=localtime(&tt);
        /*      printf(" It's %u o'clock.\n", ct->tm_hour); */
        if(*ctime(&tt)=='S'){     /* Smart way to check for weekends ;-) */
                                    COSTS_PER_UNIT=NL_DAL;
        } else {       
                if(ct->tm_hour>=8 
                && ct->tm_hour<20 ) COSTS_PER_UNIT=NL_PEAK;
                  else COSTS_PER_UNIT=NL_DAL;
        }

#ifdef DISCOUNT
        COSTS_PER_UNIT=COSTS_PER_UNIT * DISCOUNT;
#endif 
        return (1);
 }

/* eof */
