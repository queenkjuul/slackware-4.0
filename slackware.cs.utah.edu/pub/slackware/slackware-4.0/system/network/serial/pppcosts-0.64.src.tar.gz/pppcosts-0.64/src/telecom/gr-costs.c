/* 
	This file is part of PPPCOSTS.
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2. No warranty.

	Modified by Dimitrios P. Bouras
	<dbouras@hol.gr>

	Phone costs for the Hellenic Telecom (OTE A.E.), local area prices.
 
*/

#include "costs.h"

char DECIMALS= '0';
float INITIAL_COST=0;
char CURRENCY_AFTER_COST=1;
char CURRENCY[10]=" GDR";
float COSTS_PER_UNIT=13.57;       /* 11.5 + 18% VAT */

#define GR_PEAK     180
#define GR_OFF_PEAK 480

int getunitlength(time_t tt){
   int unitsecs;
   struct tm* ct;
   ct=localtime(&tt);
   
	if(ct->tm_hour < 8 || ct->tm_hour == 23)
		unitsecs = GR_OFF_PEAK;
	else
		unitsecs = GR_PEAK;
	return unitsecs;
}

