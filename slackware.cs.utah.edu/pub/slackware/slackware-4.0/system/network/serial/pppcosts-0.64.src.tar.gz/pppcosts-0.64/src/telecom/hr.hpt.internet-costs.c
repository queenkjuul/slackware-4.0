/* 
	This file is part of PPPCOSTS.
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2. No warranty.

	Modified by Davor Perkovac <perkovac@fly.cc.fer.hr>
	1998-10-19

	Phone costs for Croatian Telecom - Internet Services
	(HPT Internet to those who are familiar)

	Cost per unit = 0.1677 Kn + 22% (PDV / VAT) = 0.2046 Kn
	Units are always the same regardles of Sunday / Hollyday
	and are valid for the whole Croatian teritory.
 
	Please modify this file for your phone company's prices
	and send it to tst@bigfoot.com. Thanks a lot! 
 */

#include "costs.h"

char DECIMALS= '2';
float INITIAL_COST=0;
char CURRENCY_AFTER_COST=1;
char CURRENCY[10]=" Kn";
float COSTS_PER_UNIT=0.2046;

#define COSTS_PER_UNIT 0.2046

#define CURRENCY " Kn"

#define DECIMALS "2"

#define CURRENCY_AFTER_COST

int getunitlength(time_t tt){
   int unitsecs;
   struct tm* ct;
   /* Phone unit lengths for Croatian Telecom (HPT Internet only)- hardcoded. */
   ct=localtime(&tt);
   /*	printf(" It's %u o'clock.\n", ct->tm_hour); */
   
   
/* if (!strncmp(ctime(&tt), "Sun", 3))
     unitsecs=120;
   else{
*/
      if (ct->tm_hour < 7) unitsecs=120;
      if (ct->tm_hour >=7 && ct->tm_hour<22) unitsecs=60;
      if (ct->tm_hour >= 22) unitsecs=120;
/*     }
*/
   
   return unitsecs;
}
