/* 
	This file is part of PPPCOSTS.
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2. No warranty.

	Modified by Aky
	<aky@mail.nevtron.si>

	Corrections by Gasper Fele
	<gasper.fele@guest.arnes.si>
	
	Phone costs for the Slovene Telekom.
	Local area prices.
 
	I think (as well) that

	******   THE SLOVENE TELEKOM SUCKS BIGTIME !    ******

	Please modify this file for your phone company's prices
	and send it to tst@bigfoot.com. Thanks a lot! 
 */

#include "costs.h"

char DECIMALS= '2';
float INITIAL_COST=0;
char CURRENCY_AFTER_COST=1;
char CURRENCY[10]=" SIT";
float COSTS_PER_UNIT=3.54;

int getunitlength(time_t tt){
   int unitsecs;
   struct tm* ct;
   /* Phone unit lengths for Slovene Telecom - hardcoded. */
   ct=localtime(&tt);
   /*	printf(" It's %u o'clock.\n", ct->tm_hour); */
   
   
   if (!strncmp(ctime(&tt), "Sun", 3))
     unitsecs=240;
   else{
      if (ct->tm_hour < 7) unitsecs=240;
      if (ct->tm_hour >=7 && ct->tm_hour<19) unitsecs=120;
      if (ct->tm_hour >= 19) unitsecs=240;
   }
   
   return unitsecs;
}
