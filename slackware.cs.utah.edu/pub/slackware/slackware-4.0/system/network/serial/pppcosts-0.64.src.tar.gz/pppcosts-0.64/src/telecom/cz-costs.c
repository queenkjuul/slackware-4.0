/* 
	This file is part of PPPCOSTS.
	Copyright (c) 1996,97 Tillmann Steinbrecher.
	May be distributed according to the terms of the GNU
	General Public License version 2. No warranty.

	Phone costs for the SPT TELECOM, a.s.
	Local Area ("mistni") prices as of 5 May 1997.
	(Weekends: 2.25 Kc / 6-minute impulse,
	 Weekdays 7.00-17.59: 2.25 Kc / 3-minute impulse,
	 Weekdays 0.00-6.59 & 18.00-23.59: 2.25 Kc / 6-minute impulse)
	
	Please modify this file for your phone company's prices
	and send it to tst@bigfoot.com. Thanks a lot! 
*/

#include "costs.h"

char DECIMALS= '2';
float INITIAL_COST=0;
char CURRENCY_AFTER_COST=0;
char CURRENCY[10]="CZK";
float COSTS_PER_UNIT=2.25;

int getunitlength(time_t tt) {
	int unitsecs;
	struct tm* ct;
	/* Phone unit lengths for SPT TELECOM, a.s. - hardcoded. */
	ct=localtime(&tt);
	/*	printf(" It's %u o'clock.\n", ct->tm_hour);  */
	if(*ctime(&tt)=='S'){  /* Smart way to check for weekends ;-) */
		
		unitsecs=360;
	
	} else {
	
		if(ct->tm_hour < 7)	 	 	unitsecs=360;
		if(ct->tm_hour>=7 &&  ct->tm_hour<18)   unitsecs=180;
		if(ct->tm_hour>=18)			unitsecs=360;
        }
	return unitsecs;
 }


