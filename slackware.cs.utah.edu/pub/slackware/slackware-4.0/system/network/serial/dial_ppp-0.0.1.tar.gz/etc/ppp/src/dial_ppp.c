
/* /etc/ppp/suid_ppp_script */

#include <unistd.h>
#include <errno.h>
#include <stdio.h>

main( int argc, char ** argv, char ** envp )
{
	if( setgid(getegid()) ) perror( "setgid" );
	if( setuid(geteuid()) ) perror( "setuid" );
	execve( "/etc/ppp/dial_ppp.sh", argv, envp );
	perror( argv[0] );
	return errno;
}
