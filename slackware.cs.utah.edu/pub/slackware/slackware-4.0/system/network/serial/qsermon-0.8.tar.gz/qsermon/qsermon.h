/*
    $Id: qsermon,v 0.8 1997/17/07 21:56:00 Exp $

    qsermon is an system-utility to watch the activities on a given serial
    port. The current state of the TX,RX,CTS,RTS,DTR,DSR,DCD and RI lines are
    shown by some kind of LEDs. Furthermore, the current TX/RX transfer rates
    are visualisized using bars and within an osziloscope. Additionaly,
    the amount of received and transmitted data since programm start
    is displayed.
    
    This utility is set on top of the kernelpatch done by sermon-20 from
    Peter Fox (fox@roestock.demon.co.uk).
    
    portions:   Copyright (C) 1997 Bernhard Kuhn   
                                   kuhn@eikon.e-technik.tu-muenchen.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/



// include several header files

#include <qwidget.h>
#include <qframe.h>
#include <qdrawutl.h>
#include <qlabel.h> 
#include <qdatetm.h> 
#include <qpixmap.h>



// -------------------------- led ------------------------------

// define standard colors for enabled and disabled leds

#define LED_STD_SET red
#define LED_STD_CLR black

// define class for led-widget (used for TX,RX,CTS,RTS,DTR,DSR,DCD and RI)

class led : public QWidget {

  // this class is an QOBJECT
  Q_OBJECT
  
public:

  // constructor for led-widget
  led(QWidget* parent=0,char* name="",bool initstate=false,
    QColor setColor=LED_STD_SET,QColor clrColor=LED_STD_CLR);
  
  // change state of led
  void setLed(bool newstate=true);
  
protected:

  // what to do when widget should be repainted
  void paintEvent(QPaintEvent*);
  
private:

  // state of led
  bool ledOn;
  
  // pointer to current led brush
  QBrush* ledBrush;
  
  // brush for enabled led
  QBrush setBrush;
  
  // brush for disabled led
  QBrush clrBrush;
    
  // painter for the widget
  QPainter p;
};



// -------------------------- bar ------------------------------

// define standard colors for bar

#define BAR_STD_SET green
#define BAR_STD_CLR black

// define class for bar-widget

class bar: public QWidget {

  // this class is an QOBJECT
  Q_OBJECT;
  
public:

  // constructor
  bar(QWidget* parent=0,char* name="",
    QColor setColor=BAR_STD_SET,QColor clrColor=BAR_STD_CLR);

  // change bar value
  void setBar(float value);

protected:

  // what to to when bar should be repainted
  void paintEvent(QPaintEvent*);
  
private:

  // current state (0 <= value <= 1)
  float value;

  // brush for enabled part of bar
  QBrush setBrush;
  
  // brush for disabled part of bar
  QBrush clrBrush;
  
  // Painter for the widget
  QPainter p;
};



// -------------------------- osziloscope ----------------------

// define standard color for osziloscope

#define OSZI_STD_CLR black
#define OSZI_STD_Y1 green
#define OSZI_STD_Y2 green

// define osziloscope widget

class oszi : public QWidget {

  // this widget is Q-Object
  Q_OBJECT;
  
public:

  // constructor
  oszi(QWidget* parent=0,char* name="",
    QColor y1c=OSZI_STD_Y1,QColor y2c=OSZI_STD_Y2,QColor clrColor=OSZI_STD_CLR);

  // set value of first Channel
  void setY1(float newValue);
  
  // set value of second Channel
  void setY2(float newValue);  

protected:

  // what to do when widget have to be repainted
  void paintEvent(QPaintEvent*);
  
  // what to do when widget have to be resized
  void resizeEvent(QResizeEvent*);
  
private:

  // current and old channel values (0 <= y1,y2 <= 1)
  float y1,y2,o1,o2;

  // background brush
  QBrush clrBrush;

  // background color
  QColor clrColor;
  
  // color for first channel
  QColor y1Color;

  // color for second channel
  QColor y2Color;

  // painter for the widget
  QPainter p;
  
  // buffer-pixmap
  QPixmap* pmap;
};



// ----------------------- qsermon main window -----------------



// number if LEDs

#define NUM_LEDS 8



// declare qsermon class

class sermon : public QWidget {

  // this is an qobject
  Q_OBJECT
  
public:

  // constructor asumes serial port 1 and max transfer rate of 8000 Bytes/Sec
  sermon(QWidget* parent,char* name="",char* device="/dev/ttyS1",
    float maxrate=8000);
    
protected:

  // what to do when widget should be repainted
  void paintEvent(QPaintEvent*);
  
  // what to do when widget should be resized
  void resizeEvent(QResizeEvent*);

  // timer event (occurs approximatly every 100 ms)
  void timerEvent(QTimerEvent*);

private:

  //
  void chTXRX();

  // leds
  led* statLed[NUM_LEDS];

  // labels for leds
  QLabel* ledLabel[NUM_LEDS];

  // file-descriptor for serial line to watch
  int fd;
  
  // current and previsious RX/TX transfer amounts
  int tx,rx,oldtx,oldrx;

  //
  QLabel* txrxtext;

  // bar to show TX-rate
  bar* txbar;

  // bar to show RX-rate
  bar* rxbar;

  // oszilograph for TX/RX
  oszi* txrxoszi;

  // timer to for exact time difference determination
  QTime timer;

  // maximum displayable transfer-rate
  float maxrate;
};
