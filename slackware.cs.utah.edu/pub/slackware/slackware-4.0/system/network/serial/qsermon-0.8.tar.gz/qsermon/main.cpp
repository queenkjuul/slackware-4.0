/*
    $Id: qsermon,v 0.8 1997/17/07 21:56:00 Exp $

    qsermon is an system-utility to watch the activities on a given serial
    port. The current state of the TX,RX,CTS,RTS,DTR,DSR,DCD and RI lines are
    shown by some kind of LEDs. Furthermore, the current TX/RX transfer rates
    are visualisized using bars and within an osziloscope. Additionaly,
    the amount of received and transmitted data since programm start
    is displayed.
    
    This utility is set on top of the kernelpatch done by sermon-20 from
    Peter Fox (fox@roestock.demon.co.uk).
    
    portions:   Copyright (C) 1997 Bernhard Kuhn   
                                   kuhn@eikon.e-technik.tu-muenchen.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/



// get some standard header files
#include <stdlib.h>
#include <string.h>

#include <iostream.h>
#include <qapp.h>
#include "qsermon.h"



// main program

int main(int argc,char **argv) {

  // assume maximal 8000 bytes/sec on serial line /dev/ttyS1
  char* device="/dev/ttyS1";
  int maxrate=8000;
  
  // check given arguments
  for(int i=1;i<argc;i++) {
    
    // check device parameter
    if((strcmp(argv[i],"-d")==0) && (++i<argc)) {
      device=argv[i];
    };

    // check max. rate parameter
    if((strcmp(argv[i],"-r")==0) && (++i<argc)) {
      maxrate=atoi(argv[i]);
    };
    
    // check usage request
    if(strcmp(argv[i],"-h")==0) {
      cout << "QSermon Version 0.8\n";
      cout << "Usage: qsermon [-d <device>]";
      cout << "[-r <maximum asumed transfer rate>] [-h]\n";
      exit(1);
    };
  };
  
  // init widget/application and overgive control to Qt main-loop
  QApplication app(argc,argv);
  sermon window(0,"QSermon",device,maxrate);
  window.resize(200,100);
  app.setMainWidget(&window);
  window.show();
  return app.exec();
};
