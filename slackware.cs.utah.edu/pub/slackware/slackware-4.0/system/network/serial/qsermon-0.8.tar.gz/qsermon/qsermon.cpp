/*
    $Id: qsermon,v 0.8 1997/17/07 21:56:00 Exp $

    qsermon is an system-utility to watch the activities on a given serial
    port. The current state of the TX,RX,CTS,RTS,DTR,DSR,DCD and RI lines are
    shown by some kind of LEDs. Furthermore, the current TX/RX transfer rates
    are visualisized using bars and within an osziloscope. Additionaly,
    the amount of received and transmitted data since programm start
    is displayed.
    
    This utility is set on top of the kernelpatch done by sermon-20 from
    Peter Fox (fox@roestock.demon.co.uk).
    
    portions:   Copyright (C) 1997 Bernhard Kuhn   
                                   kuhn@eikon.e-technik.tu-muenchen.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/



// include several C-standard header files for ioctl

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <termios.h>

// we have to define this to use the sermon-extensions in linux/serial.h

#define __KERNEL__
#include <linux/serial.h>

// get class definitions

#include "qsermon.h"



// -------------------------- led ------------------------------



// constructor (default: led=off)

led::led(QWidget* parent=0,char* name="",bool initstate=false,
  QColor setColor=LED_STD_SET,QColor clrColor=LED_STD_CLR)
  : QWidget(parent,name) {
  
  // set brushes 
  setBrush=QBrush(setColor);
  clrBrush=QBrush(clrColor);
  
  // initialize state
  setLed(initstate);
};




// set led state

void led::setLed(bool newstate=true) {

  // store new value
  ledOn=newstate;

  // select brush for future drawing
  ledBrush=(ledOn)?&setBrush:&clrBrush;
};



// repaint event

void led::paintEvent(QPaintEvent*) {

  // no comment
  p.begin(this);
  qDrawShadePanel(&p,0,0,width(),height(),colorGroup(),TRUE,2,ledBrush);
  p.end();
};



// -------------------------- bar ------------------------------



// constructor

bar::bar(QWidget* parent=0,char* name="",
  QColor setColor=BAR_STD_SET,QColor clrColor=BAR_STD_CLR)
  : QWidget(parent,name),value(0) {  
  
  // set brushes
  setBrush=QBrush(setColor);
  clrBrush=QBrush(clrColor);
};
  


// change value of bar

void bar::setBar(float newValue) {

  // store new value
  value=newValue;
};



// paint event

void bar::paintEvent(QPaintEvent*) {

  // determine dimensions of inner rectangle
  int w4=width()-4,h4=height()-4;

  // begin drawing
  p.begin(this);

  // draw the inner bar
  if(value<0) {
    // all clear, if value < 0
    p.fillRect(2,2,w4,h4,clrBrush);
  } else if(value>1) {
    // all set, if value > 1
    p.fillRect(2,2,w4,h4,setBrush);   
  } else {
    // partialy clr & set if value between 0 and 1
    int y=(int)((float)h4*(1-value));
    p.fillRect(2,2,w4,y,clrBrush);
    p.fillRect(2,2+y,w4,h4-y,setBrush);   
  };
  
  // draw the frame around the bar & end close drawing
  qDrawShadePanel(&p,0,0,width(),height(),colorGroup(),TRUE,2,0);
  p.end();
};




// -------------------------- osziloscope -----------------------




// constructor

oszi::oszi(QWidget* parent=0,char* name="",
  QColor y1c=OSZI_STD_Y1,QColor y2c=OSZI_STD_Y2,QColor clrColor=OSZI_STD_CLR)
  : QWidget(parent,name),y1(0),y2(0),o1(0),o2(0),
    clrColor(clrColor),y1Color(y1c),y2Color(y2c),pmap(0) {

  // osziloscope background
  clrBrush=QBrush(clrColor);
};




// change value for channel 1

void oszi::setY1(float newValue) {
  y1=newValue;
};



// change value for channel 2

void oszi::setY2(float newValue) {
  y2=newValue;
};



// paint event

void oszi::paintEvent(QPaintEvent*) {
  int w5=width()-5;
  float h5=height()-5;

  // scroll pixmap-buffer on unit to the left
  bitBlt(pmap,-1,0,pmap);
  
  // begin drawing onto pixmap-buffer
  p.begin(pmap);
  
  // clear the most right column
  p.setPen(clrColor);
  p.drawLine(w5,0,w5,(int)h5);

  // draw channel 1
  p.setPen(y1Color);
  p.drawLine(w5,(int)(h5*(1-o1)),w5,(int)(h5*(1-y1)));
  o1=y1;
  
  // drae channel 2
  p.setPen(y2Color);
  p.drawLine(w5,(int)(h5*(1-o2)),w5,(int)(h5*(1-y2)));
  o2=y2;
  
  // stop drawing onto pixmap-buffer
  p.end();

  // transfer pixmap-buffer to foreground
  bitBlt(this,2,2,pmap);

  // draw frame around oszi
  p.begin(this);
  qDrawShadePanel(&p,0,0,width(),height(),colorGroup(),TRUE,2,0);
  p.end();
};



// resize event

void oszi::resizeEvent(QResizeEvent*) {

  // free old buffer-pixmap (if none-zero)
  delete pmap;
  
  // create new buffer-pixmap & set background
  pmap=new QPixmap(width()-4,height()-4);
  pmap->fill(clrColor);
};



// -------------------------- sermon ---------------------------



// define led positions

#define LED_TX  0
#define LED_RX  1
#define LED_RTS 2
#define LED_CTS 3
#define LED_DTR 4
#define LED_DSR 5
#define LED_DCD 6
#define LED_RI  7

// define texts of led-labels

const char* labelText[NUM_LEDS]={"TX","RX","RTS","CTS","DTR","DSR","DCD","RI"};



// constructor

sermon::sermon(QWidget* parent,char* name="",char* device="/dev/ttyS1",
  float maxrate=8000)
  : QWidget(parent,name),tx(0),rx(0),oldtx(0),oldrx(0),maxrate(maxrate) {

  // open device
  fd=open(device,O_NONBLOCK | O_RDONLY);

  // init leds & labels
  for(int i=0;i<NUM_LEDS;i++) {
    statLed[i]=new led(this);
    ledLabel[i]=new QLabel(labelText[i],this);
    ledLabel[i]->setFont(QFont("System",8,QFont::Normal));
    ledLabel[i]->setAutoResize(true);
  };

  // init TX/RX amount label
  txrxtext=new QLabel("Text",this);
  txrxtext->setFont(QFont("System",10,QFont::Bold));
  txrxtext->setAutoResize(true);

  // crate bars for TX/RX-rate  
  txbar=new bar(this,"TX-Bar",blue);
  rxbar=new bar(this,"RX-Bar",green);

  // create osziloscope for TX/RX-rate  
  txrxoszi=new oszi(this,"TX/RX-Oszi",blue,green);

  // window/widget title
  setCaption("QSermon");

  // start timer
  timer.restart();
  
  // set timer event period to 100 ms
  startTimer(100);
};



// 1K and 1M edge

#define CHTXRX1K 1000
#define CHTXRX1M 1000000



// TX/RX amount Label modifikation

void sermon::chTXRX() {

  // determine TX amount
  QString txbuffer;
  if(tx<CHTXRX1K) {
    txbuffer.sprintf("%i",tx); 
  }
  else if(tx<CHTXRX1M) {
    txbuffer.sprintf("%3.1f k",(float)tx/CHTXRX1K);
  }
  else {
    txbuffer.sprintf("%3.1f M",(float)tx/CHTXRX1M); 
  };

  // determine RX amount
  QString rxbuffer;
  if(rx<CHTXRX1K) {
    rxbuffer.sprintf("%i",rx);
  }
  else if(rx<CHTXRX1M) {
    rxbuffer.sprintf("%3.1f k",(float)rx/CHTXRX1K);
  }
  else {
    rxbuffer.sprintf("%3.1f M",(float)rx/CHTXRX1M); 
  };

  // construct whole text & modify label 
  QString buffer="TX: "+txbuffer+"   RX: "+rxbuffer;
  txrxtext->setText(buffer);
};



// resize event

void sermon::resizeEvent(QResizeEvent*) {
  int w=width();
  int h=height();

  // change led and led-label dimensions
  for(int i=0;i<NUM_LEDS;i++) {
    statLed[i]->setGeometry((3*i+1)*w/25,h/10,2*w/25,h/10);
    int lh=ledLabel[i]->fontMetrics().height();
    int lw=ledLabel[i]->fontMetrics().width(ledLabel[i]->text());
    ledLabel[i]->move((3*i+2)*w/25-lw/2,h/10-lh);
  };

  // move TX/RX label
  txrxtext->move(1*w/25,2*h/9);

  // change TX/RX bars dimensions
  txbar->setGeometry(1*w/25,2*h/5,2*w/25,h/2);
  rxbar->setGeometry(4*w/25,2*h/5,2*w/25,h/2); 

  // change TX/RX osziloscope dimensions
  txrxoszi->setGeometry(7*w/25,2*h/5,17*w/25,h/2);
};



// timer event (occurs approximatly every 100 ms)

void sermon::timerEvent(QTimerEvent*) {

  // find out _real_ time-difference since last event
  float timediff=(float)timer.restart()/1000;

  // get line status
  int arg;
  ioctl(fd,TIOCMGET,&arg);

  // set/reset the apropriate leds
  statLed[LED_RTS]->setLed((arg&TIOCM_RTS)?true:false);
  statLed[LED_CTS]->setLed((arg&TIOCM_CTS)?true:false);
  statLed[LED_DTR]->setLed((arg&TIOCM_DTR)?true:false);
  statLed[LED_DSR]->setLed((arg&TIOCM_DSR)?true:false);
  statLed[LED_DCD]->setLed((arg&TIOCM_CAR)?true:false);
  statLed[LED_RI ]->setLed((arg&TIOCM_RNG)?true:false);

  // get line transfer amounts
  struct async_struct info;
  ioctl(fd,TIOCSERGSTRUCT,&info);

  // change TX
  int newtx=info.tx_char_count;
  int txdiff=newtx-tx;
  statLed[LED_TX]->setLed(txdiff>0);
  oldtx=tx;
  tx=newtx;
  float txrate=(float)txdiff/timediff/maxrate;
  txbar->setBar(txrate);
  txrxoszi->setY1(txrate);

  // change RX
  int newrx=info.rx_char_count;
  int rxdiff=newrx-rx;
  statLed[LED_RX]->setLed(rxdiff>0);
  oldrx=rx;
  rx=newrx;
  float rxrate=(float)rxdiff/timediff/maxrate;
  rxbar->setBar(rxrate);
  txrxoszi->setY2(rxrate);
  
  // change text
  chTXRX();

  // update windget
  repaint(false);
};



// paint event

void sermon::paintEvent(QPaintEvent*) {
  for(int i=0;i<NUM_LEDS;i++) {
    statLed[i]->repaint(false);
  };
  txrxtext->repaint(false);
  txbar->repaint(false);
  rxbar->repaint(false);
  txrxoszi->repaint(false);
};

