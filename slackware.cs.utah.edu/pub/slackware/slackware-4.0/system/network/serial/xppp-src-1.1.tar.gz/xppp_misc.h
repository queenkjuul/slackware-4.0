/* XPPP
 *
 * File:      xppp_misc.h
 * Purpose:   Misc Data Types
 * Author:    Peter Hofmann (970522)
 *
 */

#ifndef XPPP_MISC_H
#define XPPP_MISC_H

#ifdef __GNUC__
#pragma interface
#endif

#include <String.h>

// *** convert long int to String

extern String itoa(long i);

// *** aux function, remove const from datatype

inline char *removeConst(const char* c)
{
  return const_cast<char*>(c);
}

#endif // XPPP_MISC_H
