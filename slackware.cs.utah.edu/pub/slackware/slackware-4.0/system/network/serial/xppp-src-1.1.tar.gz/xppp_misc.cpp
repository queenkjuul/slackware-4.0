/* XPPP
 *
 * File:      xppp_misc.cpp
 * Purpose:   Misc Data Types
 * Author:    Peter Hofmann (970522)
 *
 */

#include "xppp_misc.h"

#include <String.h>
#include <stdio.h>

// *** convert long int to String

String itoa(long i)
{
  static char buf[20];
  sprintf(buf,"%ld",i);
  return buf;
}
