/*
** rusers.c  main function for rusers
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Author: Thorsten Kukuk <kukuk@uni-paderborn.de>
**
*/

static char rcsid[] = "$Id: rusers.c,v 1.1 1996/06/06 17:49:15 kukuk Exp $";

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <sys/types.h>

#include <rpc/rpc.h>

#include "rusers.h"

#define MAXHOSTLEN 20
#define USERNAMELEN 8

static void broadcast(void);
static void query_host(char *);
static void print_sorted(void);

static int print_all = 0;
static int print_long = 0;
static int do_sort = 0;

int main(int argc, char *argv[])
{
  char c;
  int i;

  while((c=getopt(argc, argv, "ahluv"))!=EOF)
    {
      switch (c) 
        {
	case 'a':
	  print_all = 1;
	  break;
	case 'h':
	  do_sort = 1;
	  break;
	case 'l':
	  print_long = 1;
	  break;
	case 'u':
	  do_sort = 2;
	  break;
        case 'v':
	  printf("rusers version 1.0\n");
	  return 0;
          break;
        default:
	  fprintf(stderr,"Usage: rusers [-ahlu] [[hosts] ...]\n");
	  return 1;
        }
    }
  argc-=optind;
  argv+=optind;

  if(argc == 0)
    {
      broadcast();
    }
  else
    for(i = 0; i < argc; i++)
      query_host(argv[i]);

  return 0;
}

struct data_list
{
  char *hostname;
  utmp_array *v3;
  struct utmpidlearr *v2;
  struct data_list *next;
};

static struct data_list *data = NULL;

static void add_data(char *host, struct utmpidlearr *v2, utmp_array *v3)
{
  struct data_list *new, *tmp, *old;
  int i;

  if((new = malloc(sizeof(struct data_list)))==NULL)
    {
      fprintf(stderr,"ERROR: not enough memory!\n");
      exit(1);
    }
  new->hostname = strdup(host);

  if(v2 != NULL)
    {
      new->v3 = NULL;
      new->v2 = v2;
      new->next = data;
    }

  if(v3 != NULL)
    {
      new->v2 = NULL;
      new->v3 = malloc(sizeof(utmp_array));
      new->v3->utmp_array_len = v3->utmp_array_len;
      new->v3->utmp_array_val = malloc(v3->utmp_array_len*sizeof(rusers_utmp));
      for(i = 0; i < v3->utmp_array_len; i++)
	{
	  new->v3->utmp_array_val[i].ut_user = 
	    strdup(v3->utmp_array_val[i].ut_user);
	  new->v3->utmp_array_val[i].ut_line = 
	    strdup(v3->utmp_array_val[i].ut_line);
	  new->v3->utmp_array_val[i].ut_host = 
	    strdup(v3->utmp_array_val[i].ut_host);
	  new->v3->utmp_array_val[i].ut_type=v3->utmp_array_val[i].ut_type;
	  new->v3->utmp_array_val[i].ut_time=v3->utmp_array_val[i].ut_time;
	  new->v3->utmp_array_val[i].ut_idle=v3->utmp_array_val[i].ut_idle;
	}
      new->next = NULL;

      if(data == NULL)
	{
	  data = new;
	  return;
	}

      switch(do_sort)
	{
	case 1:
	  if(strcmp(host,data->hostname) < 0)
	    {
	      new->next = data;
	      data = new;
	    }
	  else
	    {
	      old = data;
	      tmp = data->next;
	      if(tmp == NULL)
		{
		  old->next = new;
		  return;
		}
	      while(tmp)
		{
		  if(strcmp(host,tmp->hostname) < 0)
		    {
		      old->next = new;
		      new->next = tmp;
		      return;
		    }
		  old = tmp;
		  tmp = tmp->next;
		}
	      old->next = new;
	    }
	  break;
	case 2:
	  if(new->v3->utmp_array_len < data->v3->utmp_array_len)
	    {
	      new->next = data;
	      data = new;
	    }
	  else
	    {
	      old = data;
	      tmp = data->next;
	      if(tmp == NULL)
		{
		  old->next = new;
		  return;
		}
	      while(tmp)
		{
		  if(new->v3->utmp_array_len < tmp->v3->utmp_array_len)
		    {
		      old->next = new;
		      new->next = tmp;
		      return;
		    }
		  old = tmp;
		  tmp = tmp->next;
		}
	      old->next = new;
	    }
	  break;
	default:
	  fprintf(stderr,"ERROR (do_sort = %d) not implemented!\n",do_sort);
	  new->next = data;
	  data = new;
	  break;
	}
    }
}

struct addr_list
{
  struct in_addr addr;
  struct addr_list *next;
};

static struct addr_list *answerd = NULL;

static void add_addr(struct in_addr addr)
{
  struct addr_list *new;

  if((new = malloc(sizeof(struct addr_list)))==NULL)
    {
      fprintf(stderr,"ERROR: not enough memory!\n");
      exit(1);
    }
  new->addr.s_addr = addr.s_addr;
  new->next = answerd;
  answerd = new;
}

static int have_addr(struct in_addr addr)
{
  struct addr_list *ptr;

  if(answerd != NULL)
    {
      ptr = answerd;

      while(ptr)
	{
	  if(ptr->addr.s_addr == addr.s_addr)
	    return 1;
	  ptr = ptr->next;
	}
    }

  return 0;
}

static char *idle2str(unsigned int idle)
{
  static char buf[32];
  int days, hours, minutes, seconds;

  if(idle==0)
    return "";

  seconds = idle;
  days = seconds/(60*60*24);
  seconds %= (60*60*24);
  hours = seconds/(60*60);
  seconds %= (60*60);
  minutes = seconds/60;
  seconds %= 60;

  if(days != 0)
    sprintf(buf,"%d days, %d:%02d:%02d",
	    days, hours, minutes, seconds);
  else
    if(hours != 0)
      sprintf(buf,"%d:%02d:%02d", hours, minutes, seconds);
    else
      if(minutes != 0)
	sprintf(buf,"%2d:%02d", minutes, seconds);
      else
	sprintf(buf,":%02d", seconds);

  return buf;
}

static void print_v2(char *hostname, struct utmpidlearr *u)
{ 
  int i;

  if(print_long)
    {
      for(i = 0; i < u->uia_cnt; i++)
	{
	  printf("%-*.*s %.*s:%-*.8s %-12.12s %8.8s",
		 USERNAMELEN,USERNAMELEN,
		 u->uia_arr[i]->ui_utmp.ut_name,
		 MAXHOSTLEN, hostname,
		 strlen(hostname) > MAXHOSTLEN ? 8 : MAXHOSTLEN - 
		 strlen(hostname)+8, u->uia_arr[i]->ui_utmp.ut_line,
		 &(ctime((time_t*)&u->uia_arr[i]->ui_utmp.ut_time)[4]),
		 idle2str(u->uia_arr[i]->ui_idle));
	  if(strlen(u->uia_arr[i]->ui_utmp.ut_host) != 0)
	    {
	      printf(" (%.16s)\n",u->uia_arr[i]->ui_utmp.ut_host);
	    }
	  else
	    printf("\n");
	}
    }
  else
    {
      printf("%-*.*s ",MAXHOSTLEN,MAXHOSTLEN,hostname);
  
      for(i = 0; i < u->uia_cnt; i++)
	{
	  printf("%.*s ",USERNAMELEN,u->uia_arr[i]->ui_utmp.ut_name);
	}      
      printf("\n");
    }
}
static void print_v3(char *hostname, utmp_array *ua)
{  
  int i;

  if(print_long)
    {
      for(i = 0; i < ua->utmp_array_len; i++)
	{
	  printf("%-*.*s %.*s:%-*.8s %-12.12s %8.8s",
		 USERNAMELEN,USERNAMELEN,
		 ua->utmp_array_val[i].ut_user,
		 MAXHOSTLEN, hostname,
		 strlen(hostname) > MAXHOSTLEN ? 8 : MAXHOSTLEN - 
		 strlen(hostname)+8, ua->utmp_array_val[i].ut_line,
		 &(ctime((time_t*)&ua->utmp_array_val[i].ut_time)[4]),
		 idle2str(ua->utmp_array_val[i].ut_idle));
	  if(strlen(ua->utmp_array_val[i].ut_host) != 0)
	    {
	      printf(" (%.16s)\n",ua->utmp_array_val[i].ut_host);
	    }
	  else
	    printf("\n");
	}
    }
  else
    {
      printf("%-*.*s",MAXHOSTLEN,MAXHOSTLEN,hostname);
      for(i = 0; i < ua->utmp_array_len; i++)
	{
	  printf(" %.*s",USERNAMELEN,ua->utmp_array_val[i].ut_user);
	}      
      printf("\n");
    }
}

/*
** print data from data_list and give memory free
*/
static void print_sorted()
{
  struct data_list *tmp;

  while(data != NULL)
    {
      tmp = data;
      if(tmp->v2 != NULL)
	print_v2(tmp->hostname,tmp->v2);
      else
	print_v3(tmp->hostname,tmp->v3);
      data = data->next;
      free(tmp);
    }
}

static int add_v2_entry(char *argp, struct sockaddr_in *addr)
{
  struct hostent *hp;
  char *hostname;
  struct utmpidlearr *u;

  if(have_addr(addr->sin_addr) == 1)
    return 0;

  u  = (struct umptidlearr *)argp;

  if(!print_all && (u->uia_cnt == 0))
    return 0;

    add_addr(addr->sin_addr);

  if((hp = gethostbyaddr((char *)&addr->sin_addr.s_addr, 
		     sizeof(struct in_addr), AF_INET)) != NULL)
    hostname = hp->h_name;
  else
    hostname = inet_ntoa(addr->sin_addr);

  if(do_sort)
    add_data(hostname,u,NULL);
  else
    print_v2(hostname,u);

  return 0;
}

static int add_v3_entry(char *argp, struct sockaddr_in *addr)
{
  struct hostent *hp;
  char *hostname;
  utmp_array *ua;

  if(have_addr(addr->sin_addr) == 1)
    return 0;

  ua = (struct utmp_array *) argp;

  if(!print_all && ua->utmp_array_len == 0)
    return 0;

  add_addr(addr->sin_addr);

  if((hp = gethostbyaddr((char *)&addr->sin_addr.s_addr, 
		     sizeof(struct in_addr), AF_INET)) != NULL)
    hostname = hp->h_name;
  else
    hostname = inet_ntoa(addr->sin_addr);

  if(do_sort)
    add_data(hostname,NULL,ua);
  else
    print_v3(hostname, ua);

  return 0;
}

static void broadcast(void)
{
  struct utmpidlearr ru_v2;
  struct rusers_utmp ru_v3;
  enum clnt_stat status;

  bzero((char *)&ru_v3, sizeof(ru_v3));
  printf("Trying protocol version %d\n",RUSERSVERS);

  status = clnt_broadcast(RUSERSPROG, RUSERSVERS, RUSERSPROC_NAMES,
		       xdr_void, NULL, xdr_utmp_array, &ru_v3,
		       add_v3_entry);

  if(status != RPC_TIMEDOUT && status != RPC_SUCCESS)
    {
      fprintf(stderr,"ERROR: %s\n", clnt_sperrno(status));
      exit(1);
    }

  if(do_sort)
    print_sorted();

  bzero((char *)&ru_v2, sizeof(ru_v2));
  printf("Trying protocol version %d\n",RUSERSVERS_IDLE);

  status = clnt_broadcast(RUSERSPROG, RUSERSVERS_IDLE, RUSERSPROC_NAMES,
		       xdr_void, NULL, xdr_utmpidlearr, &ru_v2,
		       add_v2_entry);

  if(status != RPC_TIMEDOUT && status != RPC_SUCCESS)
    {
      fprintf(stderr,"ERROR: %s\n",clnt_sperrno(status));
      exit(1);
    }

  if(do_sort)
    print_sorted();
}

static void query_host(char *hostname)
{
  CLIENT *clnt;
  struct utmpidlearr ru_v2;
  struct rusers_utmp ru_v3;
  struct sockaddr_in saddr;
  struct hostent *hp;
  struct timeval timeout = { 25, 0 };
  enum clnt_stat status;
  struct rpc_err rpcerr;
  int maxvers, minvers;

  if((hp = gethostbyname(hostname)) == NULL)
    {
      fprintf(stderr,"ERROR: unknown host \"%s\"\n",hostname);
      exit(1);
    }

  bzero((char *)&ru_v3,sizeof(ru_v3));
  if((clnt = clnt_create(hostname,RUSERSPROG, RUSERSVERS,"udp")) == NULL)
    {
      clnt_pcreateerror("rusers");
      exit(1);
    }

  status = clnt_call(clnt,RUSERSPROC_NAMES, (xdrproc_t)xdr_void, 
	       NULL, (xdrproc_t)xdr_utmp_array, &ru_v3, timeout);

  if(status == RPC_SUCCESS)
    {
      clnt_destroy(clnt);

      saddr.sin_addr.s_addr = *(int *)hp->h_addr;
      add_v3_entry((char *)&ru_v3, &saddr);

      if(do_sort)
	print_sorted();

      return;
    }

  if(status != RPC_PROGVERSMISMATCH)
    {
      clnt_perror(clnt, "rusres");
      exit(1);
    }

  clnt_geterr(clnt, &rpcerr);
  maxvers = rpcerr.re_vers.high; /* highest version supported */
  minvers = rpcerr.re_vers.low;  /* lowest version supported */

  if(RUSERSVERS < minvers || RUSERSVERS_IDLE > maxvers)
    {
      clnt_perror(clnt, "version mismatch");
      exit(1);
    }
  /* This versin is not supported, try older version */
  clnt_destroy(clnt);

  bzero((char *)&ru_v2,sizeof(ru_v2));
  if((clnt = clnt_create(hostname,RUSERSPROG, RUSERSVERS_IDLE,"udp")) == NULL)
    {
      clnt_pcreateerror("rusers");
      exit(1);
    }

  status = clnt_call(clnt,RUSERSPROC_NAMES, (xdrproc_t)xdr_void, 
	       NULL, (xdrproc_t)xdr_utmpidlearr, &ru_v2, timeout);

  if(status == RPC_SUCCESS)
    {
      clnt_destroy(clnt);

      saddr.sin_addr.s_addr = *(int *)hp->h_addr;
      add_v2_entry((char *)&ru_v2, &saddr);

      if(do_sort)
	print_sorted();

      return;
    }
  else
    {
      clnt_perror(clnt, "rusers");
      exit(1);
    }
}
