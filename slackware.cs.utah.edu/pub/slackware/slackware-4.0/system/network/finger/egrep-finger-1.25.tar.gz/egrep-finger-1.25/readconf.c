/*
 *
 * $Id: readconf.c,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 *  efinger(1) program by Andrew Pitman.
 *  `extended' finger client somewhat akin to egrep
 *
 * egrep-finger:  Functions to parse the config files.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */


#ifndef __CONFIG_H
#include <config.h>
#endif

#ifndef __readconf_h
#include "readconf.h"
#endif


/* Returns 1 if relaying allowed in conf_file, 0 otherwise. */
int allow_relay(char *conf_file)
{
int relay = 0, count;
FILE *conf;
char buf[BUFLEN];

  memset (buf, 0, BUFLEN);

#ifdef DEBUG
  if ((conf = fopen ("conf/conf", "r")) == NULL) {
#else
  if ((conf = fopen (conf_file, "r")) == NULL) {
#endif
	perror("fopen()");
	exit(1);
  }

  /* Clear error conditions for stream conf */
  clearerr (conf);

  do {
    fgets (buf, BUFLEN, conf);

    for (count = 0; count < BUFLEN; count++) {
      if (buf[count] != ' ')
	break;
    }

    if (buf[count] == '#') {
	/* This is a comment            */
	/* we'll go on to the next line */
    } else if (strlen (buf+count) > 0) {
	if (!strncasecmp (buf+count, "relaying", 8)) {
	    if (strstr (buf+count+8, "yes")) {
		relay = 1;
#ifdef DEBUG
		printf("Relaying allowed\n");
#endif
		return relay;
	    } else {
		relay = 0;
#ifdef DEBUG
		printf("Relaying disallowed\n");
#endif
		return relay;
	    }
	}
    }

  } while ((!feof (conf)) && (!ferror (conf)));

  if (ferror (conf)) {
      fprintf(stderr, "Error parsing config file: %s\n", conf_file);
      exit(1);
  }

return relay;
}

/* Returns a struct feature_enable filled in according
   to the contents of conf_file (/etc/efinger/conf)    */
struct feature_enable allow_features(char *conf_file)
{
int count;
FILE *conf;
char buf[BUFLEN];
struct feature_enable features = { 0, 0, 0, 0 };

  memset (buf, 0, BUFLEN);

#ifdef DEBUG
  if ((conf = fopen ("conf/conf", "r")) == NULL) {
#else
  if ((conf = fopen (conf_file, "r")) == NULL) {
#endif
	perror("fopen()");
	exit(1);
  }

  /* Clear error conditions for stream conf */
  clearerr (conf);

  do {
    fgets (buf, BUFLEN, conf);

    for (count = 0; count < BUFLEN; count++) {
      if (buf[count] != ' ')
	break;
    }

    if (buf[count] == '#') {
	/* This is a comment            */
	/* we'll go on to the next line */
    } else if (strlen (buf+count) > 0) {
	if (!strncasecmp (buf+count, "directories", 11)) {
	    if (strstr (buf+count+11, "yes")) {
	      features.dir = 1;
#ifdef DEBUG
	      printf("Show directories\n");
#endif
	    }
	} else if (!strncasecmp (buf+count, "idletime", 8)) {
	    if (strstr (buf+count+8, "yes")) {
	      features.idle = 1;
#ifdef DEBUG
	      printf("Show idle time\n");
#endif
	    }
	} else if (!strncasecmp (buf+count, "shell", 5)) {
	    if (strstr (buf+count+5, "yes")) {
	      features.shell = 1;
#ifdef DEBUG
	      printf("Show login shell\n");
#endif
	    }
	} else if (!strncasecmp (buf+count, "tfhourformat", 12)) {
	    if (strstr (buf+count+12, "yes")) {
	      features.tfhour = 1;
#ifdef DEBUG
	      printf("24 hour format\n");
#endif
	    }
	}
    }

  } while ((!feof (conf)) && (!ferror (conf)));

  if (ferror (conf)) {
      fprintf(stderr, "Error parsing config file: %s\n", conf_file);
      exit(1);
  }

return features;
}

struct feature_enable rd_usrconf (char *homedir)
{
int count;
FILE *usrconf;
char buf[BUFLEN];
char cf_file[256];

/* Set these all to 1 because we're going to do a
   bitwise and with the features currently enabled. */
struct feature_enable features = { 1, 1, 1, 1 };

  memset (buf, 0, BUFLEN);

  snprintf(cf_file, 256, "%s/%s", homedir, usrconf_file);

  /* Regain root privs, if possible, to read in
     the user's .efingerrc file.                */
  if ((getuid() == 0) && (geteuid() == NOBODY_UID) &&
  				(setreuid (NOBODY_UID, 0))) {
        /* Swap real/effective UIDs */
  	perror("setreuid()");
  	exit(1);
  }

  if ((usrconf = fopen (cf_file, "r")) == NULL) {
	/* It's OK if the file doesn't exist.
	   Just return features (all 1's)     */
	return features;
  }

  /* Clear error conditions for stream conf */
  clearerr (usrconf);

  do {
    fgets (buf, BUFLEN, usrconf);

    for (count = 0; count < BUFLEN; count++) {
      if (buf[count] != ' ')
        break;
    }

    if (buf[count] == '#') {
        /* This is a comment            */
        /* we'll go on to the next line */
    } else if (strlen (buf+count) > 0) {
        if (!strncasecmp (buf+count, "directories", 11)) {
            if (strstr (buf+count+11, "no")) {
              features.dir = 0;
            }
        } else if (!strncasecmp (buf+count, "shell", 5)) {
            if (strstr (buf+count+5, "no")) {
              features.shell = 0;
            }
        }
    }

  } while ((!feof (usrconf)) && (!ferror (usrconf)));

  if (ferror (usrconf)) {
      fprintf(stderr, "Error parsing config file: %s\n", cf_file);
      exit(1);
  }

  /* Change back to nobody if we are root (euid == 0). */
  if ((getuid() == NOBODY_UID) || (geteuid() == 0)) {
  	if (setreuid(0, NOBODY_UID) < 0) {
  	    perror("setreuid()");
  	    exit(1);
        }
  }

return features;
}

/* Holds contents of deny file */
char *denies[256];

/* Fills in global array of char * containing usernames
   not to show in output.  Returns -1 on error          */
int getdenies(char *deny_file)
{
int count, index = 0, n;
FILE *deny;
char *temp, buf[BUFLEN];

  memset (buf, 0, BUFLEN);

#ifdef DEBUG
  if ((deny = fopen ("conf/deny", "r")) == NULL) {
#else
  if ((deny = fopen (deny_file, "r")) == NULL) {
#endif
        perror("fopen()");
        return -1;
  }

  /* Clear error conditions for stream conf */
  clearerr (deny);

  do {
    fgets (buf, BUFLEN, deny);

    for (count = 0; count < BUFLEN; count++) {
      if (buf[count] != ' ')
        break;
    }

    if (buf[count] == '#') {
        /* This is a comment            */
        /* we'll go on to the next line */
    } else if (strlen (buf+count) > 0) {
	if (buf[count] != '\n') {
	  denies[index] = strdup (buf+count);
	  if ((temp = strchr (denies[index], '#')) != NULL) {
		denies[index][temp-denies[index]] = '\0';
	  }
	  for (n = strlen(denies[index])-1; n >= 0; n++) {
		if ((denies[index][n] == '\n') || (denies[index][n] == ' '))
			denies[index][n] = '\0';
		else
			break;
	  }
	  index++;
	}
    }

  } while ((!feof (deny)) && (!ferror (deny)) && (index < 255));

  if (ferror (deny)) {
      fprintf(stderr, "Error parsing denies file: %s\n", deny_file);
      return -1;
  }

  denies[index] = NULL;

return 0;
}


