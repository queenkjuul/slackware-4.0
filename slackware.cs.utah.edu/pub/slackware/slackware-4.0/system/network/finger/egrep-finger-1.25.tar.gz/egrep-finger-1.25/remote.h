/*
 *
 * $Id: remote.h,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 * egrep-finger: Functions that perform lookups on remote servers.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef __remote_h
#define __remote_h

#define MAXUSERSTRLEN        256
#define MAXUSERNAMELEN       8

#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN       256
#endif

/* From WKS */
#define FINGER_PORT     79
#define MAXDATA         512000

/*  Booleans!!!!!...  */
#ifndef TRUE
#define TRUE            1
#endif

#ifndef FALSE
#define FALSE           0
#endif


/* Connect to server and output the results. */
int remote_lookup(char *entry_username, char *entry_hostname, char *extra);

/* See if remote host is running efinger.  If
   it is, send the whole expression at once.
   If not, return (and do it the old fashioned
   way in remote_lookup()                      */
int efinger_lookup(char *regexp, char *host, char *extra);


#endif


