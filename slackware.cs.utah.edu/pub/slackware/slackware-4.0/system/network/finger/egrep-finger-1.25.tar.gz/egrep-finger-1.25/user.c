/*
 *
 * $Id: user.c,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 * egrep-finger:
 * Functions to print who's currently logged into the localhost.
 * Needed because in.efingerd calls efinger(1) when a connection is made
 * to port 79 or for lookups on the same system.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/* Configuration settings */
#ifndef __CONFIG_H
#include <config.h>
#endif

#ifndef __user_h
#include "user.h"
#endif

#ifndef __readconf_h
#include "readconf.h"
#endif

#include <utmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The following are needed for getpwnam()/getpwent(), etc */
#include <pwd.h>
#include <sys/types.h>

/* These are in config.h */
extern char utmp_filename[];
extern char wtmp_filename[];

/* These are in <time.h> */
extern char *tzname[2];
extern int daylight;

/* These are in readconf */
extern char *denies[256];

/* This is in main.c */
extern int daemon_mode;


/* Returns 0 on success, -1 on general error,
   -2 if the user does not exist, -3 if suppressed by deny file. */
int get_usrinfo (char *username, int match_real, int suppressp)
{
char buf[256], plan_file[FILENAME_MAX], project_file[FILENAME_MAX];
struct passwd *pwent;
static struct utmp *current = NULL;
static struct utmp *lastlog = NULL;
struct stat tty_info;
const struct tm *timeptr;
char *token, *real_name, *office, *phone;
char *lower_username, *lower_realname;
char tty_line[UT_LINESIZE], *idle_str;
char saved_hostname[UT_HOSTSIZE];
char *login_time, *lastlogin_time, tz[4];
int retnval = -2, j, n, found = 0, denied;
int plan_fd, project_fd, length;
int delta_time = 0, bufsize = MAXLOGTMFLD, nmatch = 0;
int nbytes, bytes = MAXLOGTMFLD, done = 0, next = 0;
static int first = 1;
struct feature_enable feat, usrfeat;

  /* Parse config file for proper behavior */
  feat = allow_features (conf_file);

  lower_username = strdup (username);

  for (j = 0; j < strlen(lower_username); j++) {
      lower_username[j] = tolower(lower_username[j]);
  }

  /* Rewind passwd file. */
  setpwent();

  while ((!next) && ((pwent = getpwent()) != NULL)) {

	token     = strdup (pwent->pw_gecos);
	real_name = strtok (token, (const char *) ",");
	office    = strtok (NULL,  (const char *) ",");
	phone     = strtok (NULL,  (const char *) ",");


	lower_realname = strdup (real_name);

	for (j = 0; j < strlen(lower_realname); j++) {
	    lower_realname[j] = tolower(lower_realname[j]);
	}

	if ((match_real) && (strstr (lower_realname, lower_username))) {
		nmatch = 1;
	}

	n = denied = 0;
  	if (daemon_mode) {
	  do {
	      if ((denies[n]) &&
	        (!strncasecmp (lower_username, denies[n],
					strlen(lower_username)))) {
		  denied++;
	  	  retnval = -3;
		  break;
	      }
	      n++;
	  } while (denies[n-1] != NULL);
	}

	if ((!denied) && (strlen(username) > 0) &&
	     ((!strncmp (pwent->pw_name, username, strlen(pwent->pw_name)+1)) ||
			((!denied) && (match_real) && (nmatch))))   {
	  retnval = 0;
	  nmatch  = 0;

	  if (real_name) {
	    if ((daemon_mode) && (!first)) {
	        printf("\nLogin:  %-25sIn real life: %-15s\n", pwent->pw_name,
                                real_name);
	    } else {
	        printf("Login:  %-25sIn real life: %-15s\n", pwent->pw_name,
                                real_name);
		first = 0;
	    }
	  } else {
	    if (daemon_mode) {
	        printf("\nLogin:  %-25sIn real life: ???\n", pwent->pw_name);
	    } else {
	        printf("Login:  %-25sIn real life: ???\n", pwent->pw_name);
	    }
	  }

	  if ((office) && (phone)) {
	    printf("Office: %-25sPhone:        %-15s\n", office, phone);
	  } else if (office) {
	    printf("Office: %-25sPhone:        ???\n", office);
	  } else if (phone) {
	    printf("Office: ???Phone:        %-15s\n", phone);
	  } else {
	    printf("Office: ???                      Phone:        ???\n");
	  }

#ifdef __USER_CONF
	usrfeat = rd_usrconf (pwent->pw_dir);
#endif

#ifdef __SHOW_DIR
#ifdef __USER_CONF
	if (feat.dir & usrfeat.dir) {
#else
	if (feat.dir) {
#endif
	  printf("\nDirectory: %-25s\n", pwent->pw_dir);
	}
#endif

#ifdef __SHOW_SHELL
#ifdef __USER_CONF
	if (feat.shell & usrfeat.shell) {
#else
	if (feat.shell) {
#endif
	  printf("\nShell:     %-25s\n", pwent->pw_shell);
	}
#endif


	/* If the user is not logged in, print info
	   on the last time they logged into the system. */
	if (!isloggedin(username)) {

	  endutent();
	  /* utmp_filename is going to be the path to wtmp */
	  if (wtmp_filename) {
	        utmpname(wtmp_filename);
	  } else {

#ifdef _PATH_WTMP
	        utmpname(_PATH_WTMP);
#else
	        utmpname("/var/log/wtmp");
#endif

	  }
	  setutent();

	  do {
		lastlog = getutent();

		if ((lastlog != NULL) && (lastlog->ut_type == USER_PROCESS) &&
                        (!strncmp (pwent->pw_name, lastlog->ut_user,
                                                        UT_NAMESIZE))) {
		found = 1;

                lastlogin_time = (char *) malloc (bufsize);

		timeptr = localtime(&lastlog->ut_time);
                if (timeptr->tm_isdst) {
#ifdef DEBUG
  printf("%s, %s\n", (char *) tzname[0], (char *) tzname[1]);
#endif
	            snprintf(tz, 4, "%s", tzname[1]);
                } else {
#ifdef DEBUG
  printf("%s, %s\n", tzname[0], tzname[1]);
#endif
	            snprintf(tz, 4, "%s", tzname[0]);
                }

	if (feat.tfhour) {
		bytes = MAXLOGTMFLD;
		bufsize = MAXLOGTMFLD;

                nbytes = strftime(lastlogin_time, bytes, "%b %d  %H:%M",
                                        timeptr);
	} else {
		bytes = MAXLOGTMFLD;
		bufsize = MAXLOGTMFLD;

                nbytes = strftime(lastlogin_time, bytes, "%b %d %I:%M %p",
                                        timeptr);
                if (lastlogin_time[7] == '0') {
                    lastlogin_time[7] = ' ';
                }
	}
        if (lastlogin_time[4] == '0') {
        	lastlogin_time[4] = ' ';
        }

	strncpy (saved_hostname, lastlog->ut_host, UT_HOSTSIZE);

        } /* if */

	  } while (lastlog != NULL);

	  if (!found) {
		printf("\nNever logged in.\n");
	  } else {
                if (strlen (saved_hostname) > 0) {
                    printf("\nLast login on %s %s from %.16s\n", lastlogin_time,
                                        tz, saved_hostname);
                } else {
                    printf("\nLast login on %s %s.\n", tz, lastlogin_time);
                }
                free (lastlogin_time);
	  }

	  /* Put things back the way they were. */
	  endutent();
	  /* utmp_filename is the name of utmp file, of course! */
	  if (utmp_filename) {
	        utmpname(utmp_filename);
	  } else {

#ifdef _PATH_UTMP
	        utmpname(_PATH_UTMP);
#else
	        utmpname("/var/run/utmp");
#endif

	  }
	  setutent();

	} else {
	  /* Here, we'll print any current instances (login's) of
	     the user, as well as idle time, if applicable.       */

          /* We use getutent to glean login time and idle time. */
	  /* Reset utmp file pointer. */
	  setutent();

  	  do {
             current = getutent();

	     if ((current != NULL) && (current->ut_type == USER_PROCESS) &&
			(!strncmp (pwent->pw_name, current->ut_user,
							UT_NAMESIZE))) {

#ifdef __SHOW_IDLE
	if (feat.idle) {
            /* Calculate idle time by stat()ing the user's tty
               device, and comparing st_atime with the current
               time returned by time() as a time_t.            */
            snprintf(tty_line, UT_LINESIZE, "/dev/%s", current->ut_line);

            if (stat ((const char *) tty_line, &tty_info)) {
                perror("stat()");
                exit(1);
            }

            delta_time = time(NULL)-tty_info.st_atime;
            idle_str = timestr (delta_time, 1);
	}
#endif

            timeptr = localtime(&current->ut_time);
            if ((timeptr) && (timeptr->tm_isdst)) {
	        snprintf(tz, 4, "%s", tzname[1]);
            } else {
	        snprintf(tz, 4, "%s", tzname[0]);
            }

            if (timeptr) {
              do {

                login_time = (char *) malloc (bufsize);
	if (feat.tfhour) {
		bytes = MAXLOGTMFLD;
		bufsize = MAXLOGTMFLD;

                nbytes = strftime(login_time, bytes, "%b %d  %H:%M",
                                        timeptr);
	} else {
		bytes = MAXLOGTMFLD;
		bufsize = MAXLOGTMFLD;

                nbytes = strftime(login_time, bytes, "%b %d %I:%M %p",
                                        timeptr);
                if (login_time[7] == '0') {
                    login_time[7] = ' ';
                }
	}
        if (login_time[4] == '0') {
        	login_time[4] = ' ';
        }

                if (nbytes == bufsize) {
                    free (timestr);
                    bytes++;  bufsize++;
                } else {
                    done = 1;
                }

              } while (!done);
            } else {
                login_time = "unknown";
            }

#ifdef __SHOW_IDLE
                if (strlen (idle_str) > 0) {
		  if (strlen (current->ut_host) > 0) {
                    printf("\nOn since %s %s on %s from %.16s\n%s.\n",
		    login_time, tz,
                    current->ut_line, current->ut_host, idle_str);
		  } else {
                    printf("\nOn since %s %s on %s\n%s.\n", login_time, tz,
                    current->ut_line, idle_str);
		  }
		} else {
		  if (strlen (current->ut_host) > 0) {
                    printf("\nOn since %s %s on %s from %.16s\n", login_time,
                    tz, current->ut_line, current->ut_host);
		  } else {
                    printf("\nOn since %s %s on %s.\n", login_time, tz,
                    current->ut_line);
		  }
		}
#endif

	   } /* if */

	  } while (current != NULL);
	}

	/* If we weren't called with -p */
	if (!suppressp) {

	  /* Now print the contents of .plan and .project files
						(if they exist). */
	  next = 1;
	  snprintf (plan_file, FILENAME_MAX-1, "%s/.plan", pwent->pw_dir);

	  /* Change to root so we can read .plan/.project  */
	  if ((getuid() == 0) && (geteuid() == NOBODY_UID) &&
				(setreuid (NOBODY_UID, 0))) {
				/* Swap real/effective UIDs */
		  perror("setreuid()");	
		  exit(1);
	  }

	  /* Check if file exists. */
	  if ((plan_fd = open(plan_file, O_RDONLY)) < 0) {
		printf("\nNo plan.\n");

	    } else {
		if (daemon_mode) {
	  	    fflush(stdout);
	  	    printf("\n\nPlan:\n");
		} else {
	  	    printf("\nPlan:\n");
		}
	  	fflush(stdout);

	  	while ((length = read(plan_fd, buf, sizeof(buf))) > 0)
          	{
		  fflush(stdout);
         	  if (write(STDOUT_FILENO, buf, length) != length)
        	  {
          	     perror("write()");
          	     return -1;
        	  }

        	  if (length < 0)
        	  {
          	     perror("read()");
          	     return -1;
        	  }
         	}

  	  	close(plan_fd);
	  }
	  /* Don't drop root privs after this, go on to .project. */

	  snprintf (project_file, FILENAME_MAX-1, "%s/.project", pwent->pw_dir);

          /* Check if file exists. */
          if ((project_fd = open(project_file, O_RDONLY)) < 0) {
                printf("\nNo project.\n");

          } else {
	  	printf("\nProject:\n");
	  	fflush(stdout);


	  	while ((length = read(project_fd, buf, sizeof(buf))) > 0)
          	{
		  fflush(stdout);
         	  if (write(STDOUT_FILENO, buf, length) != length)
        	  {
          	     perror("write()");
          	     return -1;
        	  }

        	  if (length < 0)
        	  {
          	      perror("read()");
          	      return -1;
        	  }
         	}
	 	close(project_fd);
		
	  }

	  /* Change back to nobody if we are root (euid=0). */
	  if ((getuid() == NOBODY_UID) || (geteuid() == 0)) {
		if (setreuid(0, NOBODY_UID) < 0) {
		   perror("setreuid()");
		   exit(1);
		}
	  }

	/* if (!suppressp) */
	} else {
	  if (token != NULL) {
		free (token);
	  }
	  printf("\n");
	  /* Write out pending output */
	  fflush(stdout);
	  return 0;
	}

	 if (token != NULL) {
		free (token);
	 }
	 printf("\n");

	}
    }

  endpwent();

  /* Write out pending output */
  fflush(stdout);

return retnval;
}

/* Returns 0 on success, -1 on general error. */
int printutmp(int long_listing, int suppressp)
{
static struct utmp *current = NULL;
struct passwd *pwent = NULL;
struct stat tty_info;
const struct tm *timeptr;
char line[256], tty_line[UT_LINESIZE];
char usrvect[MAXUSERS][UT_NAMESIZE+1];
char *fullname, *idle_str, *login_time, sav_currusr[UT_NAMESIZE+1];
int skipbanner = 0, j, bufsize = MAXLOGTMFLD;
int nbytes, bytes = MAXLOGTMFLD, done = 0;
int delta_time = 0, uvcount = 0, seen_already = 0;
struct feature_enable feat;
char tmp_name[UT_NAMESIZE+1];

   /* If we're keeping track of which users we've seen already,
      set our vector to NULL's                                  */
   if (long_listing) {
	memset (usrvect, '\0', MAXUSERS*(UT_NAMESIZE+1));
   }
   /* Set sav_currusr to NULL, regardless. */
   memset (sav_currusr, '\0', UT_NAMESIZE+1);

   /* And tmp_name....  */
   memset (tmp_name, '\0', UT_NAMESIZE+1);

   /* Which features are enabled? */
   feat = allow_features (conf_file);


  /* Reset utmp file. */
  setutent();

  do {
	current = getutent();
	if ((current != NULL) && (current->ut_type == USER_PROCESS)) {
	  if ((!long_listing) && (!skipbanner)) {
	    printf("Login    Real Name             Tty    Idle     Login Time\n");
	    printf("-----    ---------             ---    ----     ----------\n");
	    skipbanner++;
	  }

	    if (long_listing) {
		for (j = 0; j < uvcount; j++) {
			if (!strncmp (usrvect[j], current->ut_user,
				UT_NAMESIZE))
				seen_already = 1;
		}
		if ((!seen_already) &&
		    (strncpy(sav_currusr, current->ut_user, UT_NAMESIZE)) &&
		    (strncpy(tmp_name, current->ut_user, UT_NAMESIZE)) &&
				(get_usrinfo (tmp_name, 0, suppressp))) {
		    fprintf(stderr,
		     "get_usrinfo(): could not look up user %s\n", sav_currusr);
		    exit(1);
		}
		if ((!seen_already) && (sav_currusr) &&
			 ((strncpy (usrvect[uvcount], sav_currusr, UT_NAMESIZE))
								== NULL)) {
			fprintf(stderr, "Couldn't save username %s.",
				sav_currusr);
			exit(1);
		}
		if (!seen_already) {
		    setutent();
		    uvcount++;
		}
		seen_already = 0;
	    } else {

	    	/* Now that we know the username, look up other info
	    	   using getpwnam.                                   */
		strncpy(tmp_name, current->ut_user, UT_NAMESIZE);
	    	if ((pwent = getpwnam(tmp_name)) == NULL) {
			perror("getpwnam()");
			exit(1);
	    	}
	    	fullname = strdup(pwent->pw_gecos);
	    	for (j = 0; j < strlen(fullname); j++) {
		    if (fullname[j] == ',') {
		        fullname[j] = '\0';
		        break;
		    }
	    	}
	   }

	   if (!long_listing) {

#ifdef __SHOW_IDLE
	    /* Calculate idle time by stat()ing the user's tty
	       device, and comparing st_atime with the current
	       time returned by time() as a time_t.            */
	    snprintf(tty_line, UT_LINESIZE, "/dev/%s", current->ut_line);

	    if (stat ((const char *) tty_line, &tty_info)) {
		perror("stat()");
		exit(1);
	    }

	    delta_time = time(NULL)-tty_info.st_atime;
	    idle_str = timestr (delta_time, 0);

#endif

	    timeptr = localtime(&current->ut_time);

	    if (timeptr) {
	      do {

	        login_time = (char *) malloc (bufsize);
	if (feat.tfhour) {
		nbytes = strftime(login_time, bytes, "%b %d  %H:%M", 
					timeptr);
	} else {
		nbytes = strftime(login_time, bytes, "%b %d %I:%M %p", 
					timeptr);
		if (login_time[7] == '0') {
		    login_time[7] = ' ';
		}
	}
	if (login_time[4] == '0') {
		login_time[4] = ' ';
	}

		if (nbytes == bufsize) {
		    free (timestr);
		    bytes++;  bufsize++;
		} else {
		    done = 1;
		}

	      } while (!done);
	    } else {
		login_time = "";
	    }


	/* Check st_mode against S_IWGRP to see if we need to print
	   a `*' character before the name of the tty (meaning that
	   the user has messages turned off.                        */

#ifdef __SHOW_IDLE
		if (strlen (current->ut_host) > 0) {

            	  if (tty_info.st_mode & S_IWGRP) {

	            snprintf((char *) line, MAXLINESIZE,
		    "%-8s %-20s  %-6s %-8s %-12s (%1.14s)", tmp_name, 
		    fullname, current->ut_line, idle_str, login_time,
		    current->ut_host);

		  } else {

	            snprintf((char *) line, MAXLINESIZE,
		    "%-8s %-20s *%-6s %-8s %-12s (%1.14s)", tmp_name, 
		    fullname, current->ut_line, idle_str, login_time,
		    current->ut_host);

		  }

		} else {

            	  if (tty_info.st_mode & S_IWGRP) {

	            snprintf((char *) line, MAXLINESIZE,
		    "%-8s %-20s  %-6s %-8s %-12s", tmp_name, 
		    fullname, current->ut_line, idle_str, login_time);

		  } else {

	            snprintf((char *) line, MAXLINESIZE,
		    "%-8s %-20s *%-6s %-8s %-12s", tmp_name, 
		    fullname, current->ut_line, idle_str, login_time);

		  }

		}
#else
		if (strlen (current->ut_host) > 0) {

            	  if (tty_info.st_mode & S_IWGRP) {

	    	    snprintf((char *) line, MAXLINESIZE,
		    "%-8s %-20s  %-6s %-12s (%1.14s)", tmp_name,
		    fullname, current->ut_line, login_time,
		    current->ut_host);

		  } else {

	    	    snprintf((char *) line, MAXLINESIZE,
		    "%-8s %-20s *%-6s %-12s (%1.14s)", tmp_name,
		    fullname, current->ut_line, login_time,
		    current->ut_host);

		  }

		} else {

            	  if (tty_info.st_mode & S_IWGRP) {

	    	    snprintf((char *) line, MAXLINESIZE,
		    "%-8s %-20s  %-6s    %-12s", tmp_name,
		    fullname, current->ut_line, login_time);

		  } else {

	    	    snprintf((char *) line, MAXLINESIZE,
		    "%-8s %-20s *%-6s    %-12s", tmp_name,
		    fullname, current->ut_line, login_time);

		  }

		}
#endif

	    printf("%s\n", line);
	  }
	} else if ((current == NULL) && (!long_listing) && (!skipbanner)) {
            printf("No one logged in.\n");
	}

  } while (current != NULL);


  /* Flush buffers. */
  fflush(stdout);

return 0;
}

/* Returns 0 if user `username ' is not logged in,
   1 if logged in                                  */
int isloggedin(char *username)
{
static struct utmp *current = NULL;
int retnstatus = 0;

  /* Reset utmp file pointer. */
  setutent();

  do {

	/* Iterate through the utmp file to see if
	   the given user id present on the system. */
	current = getutent();
	if ((current) && (current->ut_type == USER_PROCESS) &&
		(!strncmp (current->ut_user, username, UT_NAMESIZE))) {
	    retnstatus = 1;
	}

  } while (current != NULL);

return retnstatus;
}

/* Convert from time_t delta_time (seconds) to a string
   giving days, hours, and minutes.                     */
char *timestr(time_t delta_time, int long_output)
{
char *tmstr;
int days, hrs, mins;

  if (delta_time < 60) {
	/* Blank field */
	return "";
  }

  if (long_output) {
	tmstr = (char *) malloc (32);
  } else {
	tmstr = (char *) malloc (16);
  }

  if ((days = delta_time/86400) > 0) {
	delta_time %= 86400;
  }

  if ((hrs = delta_time/3600) > 0) {
	delta_time %= 3600;
  }

  mins = delta_time/60;

  if (long_output) {
    if (days > 0) {
	if ((days == 1) && (hrs == 1))
	  snprintf(tmstr, 32, "%d day, %d hour idle time", days, hrs);
	else if (days == 1)
	  snprintf(tmstr, 32, "%d day, %d hours idle time", days, hrs);
	else if (hrs == 1)
	  snprintf(tmstr, 32, "%d days, %d hour idle time", days, hrs);
	else
	  snprintf(tmstr, 32, "%d days, %d hours idle time", days, hrs);
    } else if (hrs > 0) {
	if (hrs == 1)
	  snprintf(tmstr, 32, "%d hour, %d min idle time", hrs, mins);
	else
	  snprintf(tmstr, 32, "%d hrs, %d min idle time", hrs, mins);
    } else if (mins > 0) {
	snprintf(tmstr, 32, "%d min idle time", mins);
    } else {
	/* Blank field */
	/* We should never get here, if our math's correct */
	free (tmstr);
	tmstr = "";
    }

  } else {
    if ((days > 0) &&(hrs > 0)) {
	snprintf(tmstr, 16, "%dd %dh", days, hrs);
    } else if (days > 0) {
	snprintf(tmstr, 16, "%dd", days);
    } else if (hrs > 0) {
	snprintf(tmstr, 16, "%dh:%dm", hrs, mins);
    } else if (mins > 0) {
	snprintf(tmstr, 16, "%d min", mins);
    } else {
	/* Blank field */
	/* We should never get here, if our math's correct */
	free (tmstr);
	tmstr = "";
    }
  }


return tmstr;
}



