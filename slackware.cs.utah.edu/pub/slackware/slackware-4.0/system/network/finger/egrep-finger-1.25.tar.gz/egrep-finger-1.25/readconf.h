/*
 *
 * $Id: readconf.h,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 *  efinger(1) program by Andrew Pitman.
 *  `extended' finger client somewhat akin to egrep
 *
 * egrep-finger:  Functions to parse the config files.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef __readconf_h
#define __readconf_h


/* fopen, fgets, fclose */
#include <stdio.h>

#include <string.h>


#define BUFLEN          256

/* Returned by allow_features() */
struct feature_enable {
	int dir,
	    idle,
	    shell,
	    tfhour;
};

/* Return 1 if relaying allowed, 0 if not allowed */
int allow_relay(char *conf_file);

/* Returns a struct feature_enable filled in according
   to the contents of conf_file (/etc/efinger/conf)    */
struct feature_enable allow_features(char *conf_file);

/* Returns a struct feature_enable that can be bitwise
   anded with the current settings to allow users to
   selectively `turn off' showing certain information. */
struct feature_enable rd_usrconf (char *homedir);

/* Fills in global array of char * containing usernames
   not to show in output.  Returns -1 on error          */
int getdenies(char *deny_file);

#endif


