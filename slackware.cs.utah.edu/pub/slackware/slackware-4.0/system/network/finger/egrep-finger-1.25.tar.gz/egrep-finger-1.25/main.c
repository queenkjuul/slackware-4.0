/*
 *
 * $Id: main.c,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 *  efinger(1) program by Andrew Pitman.
 *  `extended' finger client somewhat akin to egrep
 *
 * egrep-finger:  Main function/signal handlers.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */ 

#ifndef lint
static char copyright[] =
"@(#) Copyright (C) 1998, 1999 Andrew J. Pitman.\nThis program is free software and comes with NO WARRANTY.\n";
static char *rcsid = "$Id: main.c,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $";
#endif

/* Current version */
static char version[]= "egrep-finger v1.25";

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <syslog.h>

#include <popt.h>

#include <utmp.h>

#ifndef __CONFIG_H

#define __NEED_FILENAMES
/* define this so we can get at utmp_filename/ wtmp_filename */
#include <config.h>
#undef  __NEED_FILENAMES

#endif

#ifndef __remote_h
#include "remote.h"
#endif

#ifndef __shandlers_h
#include "shandlers.h"
#endif

#ifndef __user_h
#include "user.h"
#endif

#ifndef __efinger_h
#include "efinger.h"
#endif

#ifndef __readconf_h
#include "readconf.h"
#endif


/* Print usage information */
void usage(char *progname)
{
  fprintf(stderr, "Usage: %s [-fis] [--fast] [--ignore_case] [--silent] [[user][@host]] ...\n", progname);
  fprintf(stderr, "       %s [-lps] [--long] [--no_plan] [--silent]     [[user][@host]] ...\n", progname);
  fprintf(stderr, "       %s [-d]   [--daytime]\n", progname);
  fprintf(stderr, "       %s [-hv]  [--help] [--version]\n", progname);
  fprintf(stderr, "\nFor help:    %s [-h] [--help]\n", progname);
}


/* Global data... sue me. */

char hostname[MAXHOSTNAMELEN];
char username[MAXUSERSTRLEN+1];

/* Our filehandle. */
extern int csocket;

/* Daemon mode */
int daemon_mode = 0;


/* We'll use popt for argument parsing here,
   since that'll make things MUCH more flexible in the end.... */
int main(int argc, char *argv[])
{
int check = 0, count = 0, x = 0, hoststart=0, have_extra_opts = 0;
int fflag = 0, iflag = 0, lflag = 0, pflag = 0;
int sflag = 0, dflag = 0, index = 0;
char extra[12];
char *new_argv, *saved_argv0;
char *localhost;

#ifdef __CONSTRUCT_FQDN
char *localdomain, *localfqdn;
#endif

int new_argc, done_regexp = 0;

/* POSIX signal handling. */
struct sigaction s_act;

/* options holds table of possible arguments, args is
   the context for the command-line set.              */
struct poptOption  options[32];
struct poptContext *args;
int poptretn = 0;

/* Local time info. */
struct tm *localt;
char lt[MAXBANTMFLD], *lz;
int timep;
/* In time.h */
extern char *tzname[2];
extern int daylight;


  /* Set our signal handlers. */
  memset (&s_act, 0, sizeof(struct sigaction));
  s_act.sa_handler = s_handler; 

  if ((sigaction (SIGTERM, &s_act, NULL)) ||
			(sigaction (SIGINT, &s_act, NULL))) {
	perror ("sigaction()");
	exit(1);
  }


  /* If we are called as root, we drop root privs by changing
     the effective UID to nobody (to restore to root later from
     the real UID).                                             */

  if (((getuid() == 0) || (geteuid() == 0)) &&
		(setreuid (0, NOBODY_UID) < 0)) {
	perror ("setreuid()");
	exit(1);
  }

#ifdef DEBUG
	if ((getuid() == NOBODY_UID) && (geteuid() == NOBODY_UID)) {
		printf("Successfully changed to UID %d.\n", NOBODY_UID);
	} else {
		printf("UID not changed, UID is %d.\n", geteuid());
	}
#endif

  /* Read contents of /etc/efinger/deny to compare later */
  if ((getdenies(deny_file)) == -1) {
	fprintf(stderr, "Warning, no excluded users.\n");
  }

  /* Initialize these to all NULL's */
  memset(hostname, '\0', MAXHOSTNAMELEN);
  memset(username, '\0', MAXUSERSTRLEN+1);

  /* Find the first nonoption cmdline argument to find new_argc */
  for (new_argc = 1; new_argc < argc; new_argc++) {
	if (argv[new_argc][0] != '-')
	  break;
  }

  /* Save a copy of argv[0] */
  saved_argv0 = strdup(argv[0]);

  /* Set up popt options.... */
  options[0].longName  = "fast";
  options[0].shortName = 'f';
  options[0].argInfo   = POPT_ARG_NONE;
  options[0].arg       = NULL;
  options[0].val       = 1;
  options[1].longName  = "ignore_case";
  options[1].shortName = 'i';
  options[1].argInfo   = POPT_ARG_NONE;
  options[1].arg       = NULL;
  options[1].val       = 2;
  options[2].longName  = "long";
  options[2].shortName = 'l';
  options[2].argInfo   = POPT_ARG_NONE;
  options[2].arg       = NULL;
  options[2].val       = 3;
  options[3].longName  = "no_plan";
  options[3].shortName = 'p';
  options[3].argInfo   = POPT_ARG_NONE;
  options[3].arg       = NULL;
  options[3].val       = 4;
  options[4].longName  = "version";
  options[4].shortName = 'v';
  options[4].argInfo   = POPT_ARG_NONE;
  options[4].arg       = NULL;
  options[4].val       = 5;
  options[5].longName  = "help";
  options[5].shortName = 'h';
  options[5].argInfo   = POPT_ARG_NONE;
  options[5].arg       = NULL;
  options[5].val       = 6;
  options[6].longName  = "silent";
  options[6].shortName = 's';
  options[6].argInfo   = POPT_ARG_NONE;
  options[6].arg       = NULL;
  options[6].val       = 7;
  options[7].longName  = "daytime";
  options[7].shortName = 'd';
  options[7].argInfo   = POPT_ARG_NONE;
  options[7].arg       = NULL;
  options[7].val       = 8;
  options[8].longName  = "daemon";
  options[8].shortName = 0;
  options[8].argInfo   = POPT_ARG_NONE;
  options[8].arg       = NULL;
  options[8].val       = 9;
  options[9].longName  = NULL;
  options[9].shortName = 0;
  options[9].argInfo   = 0;
  options[9].arg       = NULL;
  options[9].val       = 0;

  /* Get poptContext args so we can update flags below. */
  args = poptGetContext ("finger", argc, argv, options, 0);


  /* Finally, we update the flags. */
  do {
     poptretn = poptGetNextOpt(args);

	switch (poptretn)  {

	  case 1:   fflag = 1;
		break;
	  case 2:   iflag = 1;
		break;
	  case 3:   lflag = 1;
		break;
	  case 4:   pflag = 1;
		break;
	  case 5:   /* Print version and exit */

#ifndef lint
		printf("This is %s\n%s", version, copyright);
#else
		printf("This is egrepfinger %s\n", version);
#endif

		/* Free poptcontext */
		poptFreeContext(args);

		exit(0);

	  case 6:   /* Print help info and exit */
	    usage(argv[0]);
	    poptFreeContext(args);

	    exit(0);

	  case 7:   /* Suppress reporting of non-matches */
	    sflag = 1;
	    break;
	  case 8:   /* Print banner with time of day and exit */
	    dflag = 1;
	    break;
	  case 9:  /* make stderr the same as stdout */
  	    if (dup2 (1, 2) == -1) {
        	perror("dup2()");
        	exit(1);
  	    }
	    daemon_mode = 1;

	};
  } while (poptretn > 0);


  /* Handle errors returned by poptGetNextOpt() */
  switch (poptretn) {
	case POPT_ERROR_BADOPT:
	  usage(argv[0]);
	  exit(1);
	case POPT_ERROR_OPTSTOODEEP:
	  (void) fflush (stdout);
	  fprintf(stderr, "%s: options nested too deeply!\n", argv[0]);
	  (void) fflush (stderr);
	  exit(1);
	case POPT_ERROR_BADQUOTE:
	  (void) fflush (stdout);
	  fprintf(stderr, "%s: Unmatched quote.\n", argv[0]);
	  (void) fflush (stderr);
	  exit(1);
  };

  /* And save any leftovers (user, user@host, @host, etc.). */
  new_argv = poptGetArgs(args);
  if (new_argv) {
      have_extra_opts = 1;
      argv = strdup(new_argv);
  }
  new_argc = argc-new_argc;
  /* new argv now contains ONLY extra, non-option type stuff. */
  /* argv[0] is now the first nonoption cmdline arg. */
  /* We must free the dynamically allocated stuff in Context args,
     now that we're done with argv (a pointer to within it).       */
  poptFreeContext(args);

#ifdef __USE_SYSLOG
  /* Log query string to the syslog facility, */
  /* if we were called from a remote machine. */
  /* The last option will always be the whole */
  /* thing, if the query is coming from the   */
  /* in.efingerd daemon.                      */

#ifndef __LOG_LOCAL_QUERIES
  if (daemon_mode) {
#endif
      openlog ("efinger", LOG_CONS | LOG_PID, LOG_USER);
      if ((have_extra_opts) && (argv[0]) &&
			(strlen (argv[0]) > 0)) {
          syslog  (LOG_INFO, "egrep-finger query, expr='%s'\n", argv[0]);
      } else {
          syslog  (LOG_INFO, "egrep-finger query, userlist\n");
      }
      closelog();
#ifndef __LOG_LOCAL_QUERIES
  }
#endif

#endif

  /* Print banner telling users this is efinger. */
  /* Get info on local time/timezone. */
  lz = (char *) malloc (4);

  timep = time(NULL);
  localt = localtime(&timep);

#ifdef __TF_HOUR
  strftime(lt, MAXBANTMFLD, "%b %d %H:%M", localt);
#else
  strftime(lt, MAXBANTMFLD, "%b %d %I:%M %p", localt);
  if (lt[7] == '0')
	lt[7] = ' ';
#endif
  /* Poke out a leading '0' in the date, regardless */
  if (lt[4] == '0')
	lt[4] = ' ';

  if (localt->tm_isdst) {
	snprintf(lz, 4, "%s", tzname[1]);
  } else {
	snprintf(lz, 4, "%s", tzname[0]);
  }

  /* Get name of this host. */
  localhost = (char *) malloc (MAXLOCALHOSTLEN);
  if (gethostname (localhost, MAXLOCALHOSTLEN)) {
	perror("gethostname()");
	exit(1);
  }

#ifdef __CONSTRUCT_FQDN
  localdomain = (char *) malloc (MAXDOMAINNAMELEN);
  if (getdomainname (localdomain, MAXDOMAINNAMELEN)) {
	perror("getdomainname()");
	exit(1);
  }
  localfqdn = (char *) malloc (MAXFQDNLEN);
  snprintf(localfqdn, MAXFQDNLEN, "%s.%s", localhost, localdomain);

  printf("\n--> efinger@%s (%s %s) <--\n\n", localfqdn, lt, lz);
  free (localdomain);
  free (localfqdn);
#else
  printf("\n--> efinger@%s (%s %s) <--\n\n", localhost, lt, lz);
#endif

  free (localhost);
  free (lz);

  /* If called with `-d', exit here */
  if (dflag) {
	exit(0);
  }

  /* utmp_filename is the name of utmp file, of course! */
  if (utmp_filename) {
        utmpname(utmp_filename);
  } else {

#ifdef _PATH_UTMP
        utmpname(_PATH_UTMP);
#else
        utmpname("/var/run/utmp");
#endif

  }
  setutent();

  if (new_argv == NULL) {
	if (lflag) {
	    check = printutmp(TRUE, pflag);
	} else {
	    check = printutmp(FALSE, pflag);
	}
	if (check == -1) {
	  perror("printutmp()");
	  exit(1);
	}
   }


  count = 0;

  while ((!done_regexp) && (count < new_argc) && (argv[count]) &&
						(strlen (argv[count]) > 0)) {
	if ((strncpy((char *) username, argv[count],
			 MAXUSERSTRLEN-1)) == NULL) {
	  perror("strncpy()");
	  exit(1);
	}
        /* Poke a NULL in, ending the username part */
	for (x = 0; x < MAXUSERSTRLEN; x++) {
	  if (username[x] == '@') {	
		username[x] = '\0';
		hoststart = x+1;
	  }
	}


	if ((strncpy((char *) hostname, argv[count], 
				MAXHOSTNAMELEN)) == NULL) {
          	perror("strncpy()");
          	exit(1);
        }
	if ((strchr ((char *) hostname, '@')) != NULL) {

	    for (x = 0; x < MAXHOSTNAMELEN; x++) {
		hostname[x] = hostname[x+hoststart];
	    }	

	} else {
	    hostname[0] = '\0';
	}

	    /* For long listing, noplan, date */
            memset(extra, 0, 12);
            if (lflag) {
              extra[index] = '/';
              extra[index+1] = 'W';
	      index += 2;
            }
	    if (pflag) {
	      extra[index] = '/';
              extra[index+1] = 'P';
	      index += 2;
	    }
	    if (dflag) {
	      extra[index] = '/';
              extra[index+1] = 'D';
	      index += 2;
	    }
	    extra[index] = '\0';


	/* Here, we're going to go through in.efingerd even
	   though we're doing a local lookup.  Will print
	   plan and profile files for users with non
	   world-readable home dirs.  (in.efingerd calls
	   efinger(1) with root privs, as inetd runs as root. */

	if (strlen (hostname) > 0) {

	    check = remote_lookup (username, hostname, extra);
	    if (check == -1) {
	      if (hostname != NULL) {
		fprintf(stderr, "Remote lookup failed for host: %s\n", hostname);
	      } else if (check == -2) {
		fprintf(stderr, "%s: error resolving hostname %s\n",
                                        saved_argv0, hostname);
	      } else {
		fprintf(stderr, "Remote lookup failed\n");
	      }
	    }

	} else {
	  /* No network sockets are involved, look up the username on
	     THIS system.                                             */

	  if ((username) && (strlen(username) > 0) &&
	       ((strchr (username, '?')) ||
		(strchr (username, '*')) || (strchr (username, '+')) || 
		(strchr (username, '{')) || (strchr (username, '|')) ||
		(strchr (username, '(')) || (strchr (username, ')'))))   {

	    /* Do extended regular expression pattern matching on the
	       string */
	    if ((xregexp_lookup (username, fflag, iflag, pflag)) &&
							  (!sflag)) {
	        (void) fflush (stdout);
		fprintf(stderr, "No match.\n");
	        (void) fflush (stderr);
		exit(1);
	    }

	    /* We're done looking up stuff, since we just dealt with
	       the whole expression, which should be the rest of the
	       command-line arguments.                               */
	    done_regexp = 1;

	  } else if (username) {
	    check = get_usrinfo((char *) username, 1, pflag);
	    if (check == -1) {
	      fprintf(stderr, "Unable to lookup user: %s\n", (char *) username);
	    } else if ((!sflag) && ((check == -2) || (check == -3))) {
	      fprintf(stderr, "%s: No such user.\n", (char *) username);
	    }
	  }

        } /* if/else */
	count++;

  } /* while */

  endutent();

return 0;
}


