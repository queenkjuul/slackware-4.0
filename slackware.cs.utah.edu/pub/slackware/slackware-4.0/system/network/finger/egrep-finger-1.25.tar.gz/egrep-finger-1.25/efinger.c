/*
 * $Id: efinger.c,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 * egrep-finger: Perform lookups (local and remote) on `extended' strings.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef __CONFIG_H
#include <config.h>
#endif

#ifndef __efinger_h
#include "efinger.h"
#endif

#ifndef __user_h
#include "user.h"
#endif


#include <stdio.h>

#include <pwd.h>
#include <sys/types.h>


/* Use egrep-style pattern matching to find the user
   on this system (searching through the passwd file).
   Then, use get_usrinfo() to print info on the
   matching user.                                      */
int xregexp_lookup (const char *full_regexp_entry, int fast, int icase,
							int suppressp)
{
struct passwd *pwent;
regex_t regex_comp;
regmatch_t regex_match[2048];  /* Unused as of now. */
int matches_name, matches_gcos, error_code;
int done = 0, status, retnstat = -1;
char errbuf[RX_ERRORSIZE], *full_name, *temp;
char *username, *saved_username;


  /* Compile our precompiled pattern buffer with
     appropriate flags as per the command-line opts. */
  if ((fast) && (icase)) {

	if ((error_code = (regcomp (&regex_comp, full_regexp_entry,
		REG_EXTENDED | REG_ICASE | REG_NOSUB | REG_NEWLINE)))) {
	    regerror(error_code, &regex_comp, errbuf, RX_ERRORSIZE);
	    exit(1);
	}

  } else if (fast) {

	if ((error_code = (regcomp (&regex_comp, full_regexp_entry,
		REG_EXTENDED | REG_NOSUB | REG_NEWLINE)))) {
	    regerror(error_code, &regex_comp, errbuf, RX_ERRORSIZE);
	    exit(1);
	}

  } else if (icase) {

	if ((error_code = (regcomp (&regex_comp, full_regexp_entry,
		REG_EXTENDED | REG_ICASE | REG_NEWLINE)))) {
	    regerror(error_code, &regex_comp, errbuf, RX_ERRORSIZE);
	    exit(1);
	}

  } else {

	if ((error_code = (regcomp (&regex_comp, full_regexp_entry,
				REG_EXTENDED | REG_NEWLINE)))) {
	    regerror(error_code, &regex_comp,
			"Cannot compile pattern buffer", 32);
	    exit(1);
	}

  }

  /* Reset passwd file. */
  setpwent();

#ifdef DEBUG
  printf("Now in xregexp_lookup(), string is: %s\n", full_regexp_entry);
  if (fast) {
	printf("Fast lookup.\n");
  }
  if (icase) {
	printf("Ignoring case.\n");
  }
#endif

  do {
    matches_name = 0;
    matches_gcos = 0;
    /* If we've marked our place, reset and find the next
       entry after where we left off.                     */
    if (saved_username) {
      setpwent();
      do {
	pwent = getpwent();
      } while ((pwent) && (strncmp (saved_username, pwent->pw_name,
					strlen(pwent->pw_name))));
	if (pwent == NULL) {
		done = 1;
	}
	pwent = getpwent();
	free (saved_username);
	saved_username = NULL; /* saved username points to pure nothingness */
    } else {
      pwent = getpwent();
    }

    if (pwent) {
	/* We only want to deal with the user's full name,
	   not Office, Office Phone, or Home Phone as well. */
	full_name = strdup(pwent->pw_gecos);
	if ((temp = strchr (full_name, ',')) != NULL) {
	    full_name[temp-full_name] = '\0';
	}
#ifdef DEBUG
	printf("\n%s\n%s\n", pwent->pw_name, full_name);
#endif

        if ((!regexec (&regex_comp, pwent->pw_name, matches_name,
	    regex_match, 0)) || (!regexec (&regex_comp, full_name,
	    matches_gcos, regex_match, 0)) || (matches_name) ||
	    (matches_gcos)) {
	   retnstat = 0;  /* We've found something. */
	   if (username) {
		free (username);
	   }
	   if (saved_username) {
		free (saved_username);
	   }
	   username       = strdup(pwent->pw_name);
	   saved_username = strdup(pwent->pw_name);
	   if ((status = get_usrinfo (username, 0, suppressp)) < 0) {
		if (status == -1) {
		    fprintf(stderr, "get_usrinfo: could not lookup user %s!\n",
			saved_username);
			exit(1);
		}
		if (status == -2) {
		    fprintf(stderr, "get_usrinfo: user %s does not exist!\n",
			saved_username);
			exit(1);
		}
	   }
	   fflush(stdout);
        }

	if (full_name) {
	    free (full_name);
	}
    }

  } while ((!done) && (pwent != NULL));

  /* We're done with /etc/passwd */
  endpwent();

  if (saved_username) {
	free (saved_username);
  }

  /* Free the precompiled pattern buffer */
  regfree (&regex_comp);

return retnstat;
}


