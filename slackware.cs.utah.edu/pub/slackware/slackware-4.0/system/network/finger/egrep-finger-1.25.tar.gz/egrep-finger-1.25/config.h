/*
 *
 * $Id: config.h,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 *  efinger(1) program by Andrew Pitman.
 *  `extended' finger client somewhat akin to egrep
 *
 * egrep-finger:  config.h
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */ 

#ifndef __CONFIG_H
#define __CONFIG_H


/* UID of user nobody, or alternatively, a
   special user just for finger such as `finger' */
#define NOBODY_UID        99

/* Filehandles for stdin and stdout */
/* (Leave alone) */
#ifndef STDIN_FILENO
#define STDIN_FILENO 0
#endif

#ifndef STDOUT_FILENO
#define STDOUT_FILENO 1
#endif


/* Locations of config files for egrep-finger */
static char conf_file[]="/etc/efinger/conf";
		/* Global config file */

static char usrconf_file[]=".efingerrc";
		/* Per user config file */

#ifndef __IN_EFINGERD
static char deny_file[]="/etc/efinger/deny";
		/* Global deny file */
#endif


#ifdef __IN_EFINGERD

/* Path to the in.efingerd daemon */
/* You might want to have this point to where the
   program will actually reside after a
   `make install'  ;)   Inetd usually looks in
   /usr/sbin, so you may not want to change this  */
const char path_efingerd[]="/usr/sbin/in.efingerd";

/* Path to efinger(1) as specified for make install. */
const char path_efinger[]="/usr/local/bin/efinger";

#endif

#ifdef __NEED_FILENAMES

/* Locations of respective files on your system */
const char utmp_filename[]="/var/run/utmp";
const char wtmp_filename[]="/var/log/wtmp";

#endif

#endif

