/*
 *
 * $Id: remote.c,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 * egrep-finger: Functions that perform lookups on remote servers.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>


#ifndef __CONFIG_H
#include <config.h>
#endif

#ifndef __remote_h
#include "remote.h"
#endif


/* Our filehandle. */
int csocket;

/* Returns 0 when successful, -1 on general error,
   -2 on hostname lookup failure.                  */
int remote_lookup(char *entry_username, char *entry_hostname, char *extra)
{
int check = 0, mult_lu = 0, done = 0, j;
int print_banner = 1;
struct hostent *server = NULL;
struct sockaddr_in server_sin = { 0 };
char senddat[MAXUSERSTRLEN+12];
char buff[MAXDATA];
char *usrnam_sav, *usrnam_tmp;
int finger_port;

#ifdef __LOOKUP_PORT
struct servent *serv;

  serv = getservbyname("finger", "tcp");
  finger_port = serv->s_port;
#else
  finger_port = FINGER_PORT;
#endif

	/* Init the buffer to '\0's */
	memset (senddat, 0, MAXUSERSTRLEN+12);

	if (efinger_lookup (entry_username, entry_hostname, extra)) {
		exit(0);
	} else {
		extra[2] = '\0';
	}

	/* Replace any `|'s with ` 's */
	if (strchr (entry_username, '|')) {
	 for (j = 0; (j < MAXUSERSTRLEN) && (entry_username[j] != '\0'); j++) {
		  if (entry_username[j] == '|')
		      entry_username[j] = ' ';
	 }
	    usrnam_sav = strdup (entry_username);
	    usrnam_tmp = strdup (entry_username);
	    mult_lu = 1;
	    j = -1;
	    do {
		j++;
	    } while (usrnam_tmp[j] != ' ');
	    usrnam_tmp[j] = '\0';
	} else {
	    done = 1;
	}

  do {
          csocket = 0;
          csocket = socket (AF_INET, SOCK_STREAM, 0);
          if (csocket == -1) {
            perror("socket()");
            return -1;
          }
          server = gethostbyname ((char *) entry_hostname);
          if (server == NULL) {
            server = gethostbyaddr (entry_hostname,
			strlen((char *) entry_hostname), AF_UNIX);
            if (server == NULL) {
                return -1;
            }
          }

          server_sin.sin_family = AF_INET;
          server_sin.sin_port = htons(finger_port);
          memcpy(&server_sin.sin_addr, server->h_addr, server->h_length);

          check = connect(csocket, &server_sin, sizeof(struct sockaddr_in));
          if (check == -1) {
            perror("connect()");
            return -1;
          }
	  if (print_banner) {
	      if (!strcmp (server->h_name, "localhost")) {
                  printf("Connecting...\n[127.0.0.1]\n");
	      } else {
                  printf("Connecting...\n[%s]\n", server->h_name);
	      }
	      print_banner--;
	  }

	if (mult_lu) {
	    if ((usrnam_sav == NULL) || (usrnam_tmp == NULL)) {
		done = 1;
	    } else {
		memset (senddat, 0, MAXUSERSTRLEN+12);
		sprintf(senddat, "%s %s\n\r", extra, usrnam_tmp);
		free (usrnam_tmp);
		if (usrnam_sav) {
			usrnam_sav = strchr (usrnam_sav, ' ');
			if ((usrnam_sav) && (usrnam_sav[0] == ' ')) {
			  usrnam_sav++;
			  usrnam_tmp = strdup (usrnam_sav);
			} else if (usrnam_sav) {
			  usrnam_tmp = strdup (usrnam_sav);
			} else {
			  usrnam_tmp = NULL;
			  done = 1;
			}
		   if (usrnam_tmp) {
			j = -1;
            		do {
            		    j++;
            		} while ((usrnam_tmp[j] != ' ') &&
					(usrnam_tmp[j] != '\0'));
            		usrnam_tmp[j] = '\0';
		   }
		} else {
			free (usrnam_sav);
			usrnam_sav = NULL;
		}
	    }
	} else {
          sprintf(senddat, "%s %s\n\r", extra, entry_username);
	}

          check = write (csocket, (char *) senddat, sizeof(senddat));
          if (check == -1) {
            perror("write()");
            return -1;
          }

          check = read (csocket, buff, MAXDATA);
          do {
            if (check == -1) {
                perror("read()");
                return -1;
            } else {
                buff[check-1] = '\0';
            }
	  for (j = 0; j < strlen(buff); j++) {
		/* Replace CR with a space */
		if (buff[j] == '\r')
		    buff[j] = ' ';
	  }
          printf("%s", buff);
          } while (((check = read (csocket, buff, MAXDATA)) <= MAXDATA) &&
                        (check > 0));

          if (check == -1) {
                perror("read()");
                return -1;
          }

	  /* Separate each batch with whitespace. */
	  printf("\n");

  close (csocket);
  } while (!done);

  return 0;
}


int efinger_lookup(char *regexp, char *host, char *extra)
{
int check = 0, retnstatus = FALSE;
struct hostent *server = NULL;
struct sockaddr_in server_sin = { 0 };
char senddat[MAXUSERSTRLEN+12];
char buff[MAXDATA];
int finger_port;

#ifdef __LOOKUP_PORT
struct servent *serv;

  serv = getservbyname("finger", "tcp");
  finger_port = serv->s_port;
#else
  finger_port = FINGER_PORT;
#endif

          csocket = 0;
          csocket = socket (AF_INET, SOCK_STREAM, 0);
          if (csocket == -1) {
            perror("socket()");
            exit(1);
          }
          server = gethostbyname ((char *) host);
          if (server == NULL) {
            server = gethostbyaddr (host,
                        strlen((char *) host), AF_UNIX);
            if (server == NULL) {
		fprintf(stderr, "Host not found: %s\n", host);
                exit(1);
            }
          }

          server_sin.sin_family = AF_INET;
          server_sin.sin_port = htons(finger_port);
          memcpy(&server_sin.sin_addr, server->h_addr, server->h_length);

          check = connect(csocket, &server_sin, sizeof(struct sockaddr_in));
          if (check == -1) {
            perror("connect()");
            exit(1);
          }
	  check = write (csocket, (char *) "ARE*YOU*EFINGER?\n", 17);
          if (check == -1) {
            perror("write()");
            exit(1);
          } 
	  check = read (csocket, buff, MAXDATA);
          if (check == -1) {
            perror("read()");
            exit(1);
          }

	  if (!strncasecmp (buff, "YES*I*AM*EFINGER.", 17)) {
		
		/* Now, we'll send the whole shebang to the
		   remote host, since we've confirmed that
		   it's running efinger.                    */
#ifdef DEBUG
	printf("Remote host is running efinger.\n");
#endif
	        if (!strcmp (server->h_name, "localhost")) {
                    printf("Connecting...\n[127.0.0.1]\n");
                } else {
                    printf("Connecting...\n[%s]\n", server->h_name);
                }

		snprintf(senddat, MAXUSERSTRLEN+12, "%s %s\n", regexp, extra);
		check = write (csocket, senddat, strlen(senddat));
		if (check == -1) {
            	   perror("write()");
            	   exit(1);
          	}

	  /* Read data sent back from host and print */
          check = read (csocket, buff, MAXDATA);
          do {
            if (check == -1) {
                perror("read()");
                exit(1);
            } else {
                buff[check-1] = '\0';
            }
          printf("%s", buff);
          } while (((check = read (csocket, buff, MAXDATA)) <= MAXDATA) &&
                        (check > 0));
	  printf("\n");

	  retnstatus = TRUE;

	  } else {
#ifdef DEBUG
	printf("Remote host not running efinger.\n");
#endif
		/* close the socket (below) and exit with -1 */	
		retnstatus = FALSE;
	  }

  close (csocket);

return retnstatus;
}


