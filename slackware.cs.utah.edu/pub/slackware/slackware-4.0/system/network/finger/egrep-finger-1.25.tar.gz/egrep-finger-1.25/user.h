/*
 *
 * $Id: user.h,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 * egrep-finger:
 * Functions to print who's currently logged into the localhost.
 * Needed because in.efingerd calls efinger(1) when a connection is made
 * to port 79 or for lookups on the same system.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef __user_h
#define __user_h

#include <stdio.h>
#include <time.h>

/* Should be defined in stdio.h */
#ifndef FILENAME_MAX
#define FILENAME_MAX          256
#endif

/* Set a maximum for the length of a line. */
#define MAXLINESIZE           256

/* Max for login time field */
#define MAXLOGTMFLD           16
/* Max for banner time field */
#define MAXBANTMFLD           24

/* Max number of possible users on the system
   (set this pretty high)                     */
#define MAXUSERS              2048

/* Max's for printing local hostname, domain, and FQDN */
#define MAXLOCALHOSTLEN       32
#define MAXDOMAINNAMELEN      64
#define MAXFQDNLEN            96

/* tolower() */
#include <ctype.h>

/* File I/O stuff....  */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#ifndef STDOUT_FILENO
#define STDOUT_FILENO 1
#endif

/* We won't mess with the defaults:
#define UT_LINESIZE           12
#define UT_NAMESIZE           8
#define UT_HOSTSIZE           16
   we'll leave them alone! */

/* We define NOBODY_UID on the command line out of the Makefile. */
/*NOBODY_UID                    99*/


/* Lookup username on the local system. */
int get_usrinfo (char *username, int match_real, int suppressp);

/* long_listing is 0 for normal, 1 for long listing. */
int printutmp (int long_listing, int suppressp);

/* Returns 0 if user `username ' is not logged in,
   1 if logged in                                  */
int isloggedin(char *username);

/* Takes a time in seconds (time_t) and returns a char
   string with days, hrs, mins.....                    */
/* if (long) make a verbose string.                    */
char *timestr (time_t delta_time, int long_output);

#endif


