/*
 * $Id: efingerd.c,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 * efingerd:  in.efingerd daemon for egrep-finger.  Reads from stdin and
 * exec()'s efinger(1) with the appropriate cmdline args.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>


#ifndef __IN_EFINGERD
#define __IN_EFINGERD

#include <config.h>
#include <readconf.h>


#define BUFLEN                256

/* Location of global config file */
extern char conf_file[];

/* The daemon part, read from stdin....  Check for /W /P and /D options,
   truncate the string at '@' to prevent relaying, and call efinger(1)
   with the appropriate cmdline args.                                    */
int main()
{
int n, lflag = 0, pflag = 0, dflag = 0, bytec, relay = 0;
char buf[BUFLEN], *temp;             /* relay will be set according to      */
int exec_argc = 0;                   /* the contents of /etc/efinger/conf   */
char *exec_argv[32];

  /* make stderr the same as stdout */
  if (dup2 (1, 2) == -1) {
	perror("dup2()");
	exit(1);
  }

  /* Purge any pending input. */
  (void) fflush (stdin);

  if ((bytec = read (STDIN_FILENO, buf, BUFLEN)) == -1) {
        perror("read()");
        exit(1);
  }
  buf[bytec-1] = '\0';
  if (!strncasecmp (buf, "ARE*YOU*EFINGER?", 16)) {
        if ((write (STDOUT_FILENO, "YES*I*AM*EFINGER.\n", 18)) == -1) {
            perror("write()");
            exit(1);
        }

	/* Read another line, then send everything
	   to efinger at once                      */
        if ((bytec = read (STDIN_FILENO, buf, BUFLEN)) == -1) {
                perror("read()");
                exit(1);
        }
	buf[bytec-1] = '\0';
	if ((temp = strstr (buf, "/W")) != NULL) {
	    lflag = 1;
	    buf[temp-buf] = ' ';
	    buf[temp-buf+1] = ' ';
	}
	if ((temp = strstr (buf, "/P")) != NULL) {
	    pflag = 1;
	    buf[temp-buf] = ' ';
	    buf[temp-buf+1] = ' ';
	}
	if ((temp = strstr (buf, "/D")) != NULL) {
	    dflag = 1;
	    buf[temp-buf] = ' ';
	    buf[temp-buf+1] = ' ';
	}

#ifdef __NO_FINGER_RELAY
	relay = allow_relay (conf_file);
	if ((!relay) && ((temp = strchr (buf, '@')) != NULL)) {
		printf("Sorry, no relaying allowed.\n");
		(void) fflush (stdout);
		exit(0);
	}
#endif

	for (n = strlen(buf)-2; n >= 0; n--) {
	    if ((buf[n] == '\n') || (buf[n] == '\r') || (buf[n] == ' ')) {
		buf[n] = '\0';
	    } else {
		break;
	    }
	}

	do {
	  if (!exec_argc) {
		exec_argv[exec_argc] = "efinger";
	  } else if (exec_argc == 1) {
		exec_argv[exec_argc] = "--daemon";
	  } else if (exec_argc == 2) {
	     if (dflag) {
		exec_argv[exec_argc] = "-d";
	     } else if ((lflag) && (pflag)) {
		exec_argv[exec_argc] = "-lp";
	     } else if (lflag) {
		exec_argv[exec_argc] = "-l";
	     } else if (pflag) {
		exec_argv[exec_argc] = "-p";
	     } else {
		for (n = strlen(buf)-1; n >= 0; n--) {
		    if ((buf[n] == '\n') || (buf[n] == '\r') ||
						(buf[n] == ' ')) {
			buf[n] = '\0';
		    } else {
			break;
		    }
		}
		if ((buf) && ((strlen (buf)) > 0)) {
		    exec_argv[exec_argc] = buf;
		    exec_argv[exec_argc+1] = NULL;
		} else {
		    exec_argv[exec_argc] = NULL;
		}
		fflush (stdout);
#ifdef DEBUG
	printf("'%s'\n", buf);
		if (execvp ("efinger", exec_argv)) {
#else
		if (execv  (path_efinger, exec_argv)) {
#endif
		    perror("Could not exec efinger");
		    exit(1);
		}
	     }
	  } else if (exec_argc == 2) {
		exec_argv[exec_argc] = "--daemon";
	  } else if (exec_argc == 3) {
		if ((buf) && (strlen (buf) > 0)) {
		  exec_argv[exec_argc] = strtok (buf, (const char *) " \n");
		} else {
		  exec_argv[exec_argc] = NULL;
		}
	  } else {
		exec_argv[exec_argc] = strtok (NULL, (const char *) " \n");
	  }
	  exec_argc++;
	} while ((exec_argv[exec_argc-1] != NULL) && (exec_argc < 32));
	exec_argv[exec_argc-1] = NULL;

	/* Call efinger (1); */

	fflush (stdout);
#ifdef DEBUG
		printf("%s, %s, %s\n", exec_argv[0], exec_argv[1], exec_argv[2]);
		if (execvp ("efinger", exec_argv)) {
#else
		if (execv  (path_efinger, exec_argv)) {
#endif
		    perror("Could not exec efinger");
		    exit(1);
		}

  } else if ((temp = strstr (buf, "/W")) != NULL) {
#ifdef DEBUG
	printf("Long listing: %s\n", buf);
#endif
	buf[temp-buf] = ' ';
	buf[temp-buf+1] = ' ';

#ifdef __NO_FINGER_RELAY
	relay = allow_relay (conf_file);
	if ((!relay) && ((temp = strchr (buf, '@')) != NULL)) {
                printf("Sorry, no relaying allowed.\n");
                (void) fflush (stdout);
                exit(0);
	}
#endif

	do {
	  if (!exec_argc) {
		exec_argv[exec_argc] = "efinger";
	  } else if (exec_argc == 1) {
		exec_argv[exec_argc] = "-l";
	  } else if (exec_argc == 2) {
		exec_argv[exec_argc] = "--daemon";
	  } else if (exec_argc == 3) {
		if ((buf) && (strlen (buf) > 0)) {
		  exec_argv[exec_argc] = strtok (buf,  (const char *) "\r");
		  do {
		    if (exec_argv[exec_argc][0] == ' ')
			exec_argv[exec_argc]++;
		  } while (exec_argv[exec_argc][0] == ' ');
		  for (n = strlen (exec_argv[exec_argc]); n >= 0; n--) {
		    if (exec_argv[exec_argc][n] == ' ')
			exec_argv[exec_argc][n] = '\0';
		  }
		  if (strlen (exec_argv[exec_argc]) == 0)
			exec_argv[exec_argc] = NULL;
		} else {
		  exec_argv[exec_argc] = NULL;
		}
	  } else {
		exec_argv[exec_argc] = strtok (NULL, (const char *) "\r");
	  }
	  exec_argc++;
	} while ((exec_argv[exec_argc-1] != NULL) && (exec_argc < 32));
	exec_argv[exec_argc-1] = NULL;

	fflush (stdout);
#ifdef DEBUG
	if (execvp ("efinger", exec_argv)) {
#else
	if (execv  (path_efinger, exec_argv)) {
#endif
	    perror("Could not exec efinger");
	    exit(1);
	}
  } else {
	/* Just call efinger with any arguments given,
	   without supplying the -l option.            */
                exec_argv[0] = "efinger";
                for (n = strlen(buf)-1; n >= 0; n--) {
                    if ((buf[n] == '\n') || (buf[n] == '\r') ||
						(buf[n] == ' ')) {
                        buf[n] = '\0';
                    } else {
                        break;
                    }
                }
		exec_argv[1] = "--daemon";
		if ((buf) && (strlen (buf) == 0)) {
		    exec_argv[2] = NULL;
		} else {

#ifdef __NO_FINGER_RELAY
	relay = allow_relay (conf_file);
	if ((!relay) && ((temp = strchr (buf, '@')) != NULL)) {
                printf("Sorry, no relaying allowed.\n");
                (void) fflush (stdout);
                exit(0);
	}
#endif
                    exec_argv[2] = buf;
                    exec_argv[3] = NULL;
		}

		fflush (stdout);
#ifdef DEBUG
        	if (execvp ("efinger", exec_argv)) {
#else
        	if (execv  (path_efinger, exec_argv)) {
#endif
      		      perror("Could not exec efinger");
     		      exit(1);
		}
  } /* if/else */

/* We should never get to this point */
return 1;
}

#endif


