/*
 * $Id: efinger.h,v 1.25 1999/04/12 05:25:57 ap1 Exp ap1 $
 *
 * egrep-finger: Perform lookups (local and remote) on `extended' strings.
 *
 * Copyright (C) 1998, 1999 Andrew J. Pitman
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef __efinger_h
#define __efinger_h

/* Routines to match strings with regexps.                 */
/* This most likely includes rx.h, GNU's version of regex. */
#include <regex.h>

#define RX_ERRORSIZE          32


/* malloc*/
#include <stdlib.h>
/* strdup, strchr */
#include <string.h>

/* Use egrep-style pattern matching to find the user
   on this system (searching through the passwd file).
   Then, use get_usrinfo() to print info on the
   matching user.                                      */
int xregexp_lookup (const char *full_regexp_entry, int fast, int icase,
							int suppressp);

#endif


