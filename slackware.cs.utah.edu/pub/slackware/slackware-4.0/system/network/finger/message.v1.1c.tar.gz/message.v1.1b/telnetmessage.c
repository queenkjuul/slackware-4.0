/*

Telnet.message, version 1.1

Disc-lamer:
Use this program at your own risk, is anything goes wrong it's not my fault

                                                                [R. Deckard]
                                                                
Install and compile is quite simple and goes as follows:
compile:

  $ gcc -o telnet.message telnetmessage.c
# now to strip the binary
  $ strip telnet.message
      
install:
      
su to root and do the following:
  $ cp telnet.message /usr/sbin
        
edit your /etc/inetd.conf and edit the telnet line so it looks like this:
  telnet  stream  tcp     nowait  nobody  /usr/sbin/tcpd  telnet.message          

Now do a kill -HUP <pid of inetd> and it's up and running :)
          
PS if you configured your /etc/hosts.allow add the line:
telnet.message:ALL:ALLOW
          
Please send comments to: deckard@shadowmere.student.utwente.nl

*/
          






#include <stdio.h>

int main(void){

	FILE	*fd1;
	char	temp1[256];
	
	fd1 = popen("uname -n","r");
        fgets(temp1, 256, fd1);
        pclose(fd1);

printf("\n\r============================================================\n\r");
printf(" Welcome to %s ", temp1);
printf("\r on this system the telnet login option has been disabled\n\r"
       " Please use Secure shell to connect to this system.\n\r\n\r"
       "                                   Disconnecting now... bye!\n\r\n\r"
       "============================================================\n\r\n\r");
       
return 0;

}