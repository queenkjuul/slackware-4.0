/*

Finger.message, version 1.1

Disc-lamer:
Use this program at your own risk, is anything goes wrong it's not my fault

								[R. Deckard]

Install and compile is quite simple and goes as follows:
compile:
  
  $ gcc -o finger.message fingermessage.c
  # now to strip the binary
  $ strip finger.message

install:

su to root and do the following:
  $ cp finger.message /usr/sbin

edit your /etc/inetd.conf and edit the finger line so it looks like this:
  finger          stream  tcp     nowait  nobody  /usr/sbin/tcpd finger.message

Now do a kill -HUP <pid of inetd> and it's up and running :)

PS if you configured your /etc/hosts.allow add the line:
finger.message:ALL:ALLOW 

Please send comments to: deckard@shadowmere.student.utwente.nl

*/



#include <stdio.h>

int main(void) {

	FILE	*fd1;
	FILE    *fd2;
	char	temp1[256];
	char    temp2[256];
	
	fd1 = popen("uname -srnm","r");
        fd2 = popen("date" , "r");
        fgets(temp1, 256, fd1);
        fgets(temp2, 256, fd2);
        pclose(fd1);
        pclose(fd2);
                                
        
        printf("---------------------------------------------------\n"); 
	printf(" System:          %s", temp1);                                
        printf(" Local Date/Time: %s", temp2);
        printf(" - - - - - - - - - - - - - - - - - - - - - - - - -\n"
               "    To find out more about users on this server,\n"
               "     please contact them via electronic mail!\n"
               "----------------------------------------[The Root]-\n");
return 0;

}

/*

--------------------------------------------------
 System:           Linux 2.0.34
 Local Date/Time:  Sun blah blah blah
 - - - - - - - - - - - - - - - - - - - - - - - - -
      To find out about users on this server,
     please contact them via electronic mail!
-------------------------------------------[Deck]-


*/