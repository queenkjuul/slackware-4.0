#define MAX_SOCK_LENGTH		100

#define EFINGER_LIST		"/etc/efinger/efinger-list"
#define EFINGER_LUSER		"/etc/efinger/efinger-luser"
#define EFINGER_NOUSER		"/etc/efinger/efinger-nouser"

#define EFINGER_USER_FILE	".efinger"


/* maximum time we should wait for ident reply */
#define IDENT_TIME	10

/* how much time we give to user processes */
#define TIME_UNTIL_INT		10

/* how much time we give to users processes if they do not react to INT 
 * signal */
#define TIME_UNTIL_KILL		3


/* uncomment following, if you do not have libident installed */
/* #define DONT_HAVE_LIBIDENT */

/* uncomment following, if you do not have snprintf on your system */
/* #define DONT_HAVE_SNPRINTF */
