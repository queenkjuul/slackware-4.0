/* Copyright (C) 1995 -- Joel Katz -- Stimpson@CyberPlus.com */
/* All rights reserved except as specified in included      */
/* file "main.c".				 	   */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

/* This code is slated to be rewritten. */
/* It is expected that conditional conditionals will soon be supported. */

char *str_lower(char *f)
{
 char *g=f;
 while((*g)!=0)
 {
  *g=tolower(*g);
  g++;
 }
 return f;
}

extern int auth, log, mail, ttys, idletime, remote;
extern int plan, project, param, headers;
extern char prog_fnm[], plan_fnm[], project_fnm[], subd_fnm[], *subname;

#define matches(a,b) (!strcmp((a),(b)))
#define DCM(strng,var) { if(matches(cmmd,strng)) { var=1; return; }\
                          if(matches(cmmd, "no" strng)) { var=0; return; } }

void do_command(char *cmmd, char *arg)
{
 char *j="";
 if(arg==NULL) arg=j;
 DCM("mail",mail)
 DCM("auth",auth)
 DCM("idle",idletime)
 DCM("log",log)
 DCM("remote",remote)
 DCM("parm",param)
 DCM("param",param)
 DCM("subname",param)
 DCM("header",headers)
 DCM("headers",headers)
 DCM("ttys",ttys)
 DCM("tty",ttys)
 DCM("plan",plan)
 DCM("proj",project)
 DCM("project",project)
 if(matches(cmmd,"progfnm")) { strcpy(prog_fnm,arg); return; }
 if(matches(cmmd,"program")) { strcpy(prog_fnm,arg); return; }
 if(matches(cmmd,"planfnm")) { strcpy(plan_fnm,arg); return; }
 if(matches(cmmd,"projfnm")) { strcpy(project_fnm,arg); return; }
 if(matches(cmmd,"projectfnm")) { strcpy(project_fnm,arg); return; }
 if(matches(cmmd,"subfnm")) { strcpy(subd_fnm,arg); return; }
 if(matches(cmmd,"subdfnm")) { strcpy(subd_fnm,arg); return; }
 if(matches(cmmd,"subdir")) { strcpy(subd_fnm,arg); return; }
 if(matches(cmmd,"subdirfnm")) { strcpy(subd_fnm,arg); return; }
}

int specs(char *cmd, char *qual, const char *hn, const char *ip)
{
 if matches(cmd,"ip=")
  return matches(qual,ip);
 if matches(cmd,"hn=")
  return matches(qual,hn);
 if matches(cmd,"ip!")
  return !matches(qual,ip);
 if matches(cmd,"hn!")
  return !matches(qual,hn);
 if matches(cmd,"sn=")
  return matches(qual,subname);
 if matches(cmd,"sn!")
  return !matches(qual,subname);
 if matches(cmd,"sn1")
  return (*subname)!=0;
 if matches(cmd,"sn0")
  return (*subname)==0;
 return 0;
}

void parse(const char *hnm, const char *hip)
{ /* Note: .fingerrc DOES NOT need to be world readable! */
 FILE *a;
 char buf[256];
 char *host_name=(char *)hnm, *host_ip=(char *)hip;
 int i;
 char p1[256],p2[256],p3[256],p4[256],p5[256];
 a=fopen(".fingerrc","r");
 if(a==NULL) return; /* If no rc file, use defaults */
 while(fgets(buf,256,a)!=NULL)
 {
  if((buf[0]!='#')&&(buf[0]!=' ')&&(strlen(buf)>3))
  {
   i=sscanf(buf,"%s %s %s %s %s",p1,p2,p3,p4,p5);
   switch(i)
   {
    case 1: /* command w/o param */
    		do_command(str_lower(p1),NULL);
    		break;
    case 2: /* command with param */
    		do_command(str_lower(p1),p2);
    		break;
    case 3: /* qualifier, qual spec, command */
            /*       -- or --		     */
            /* HNR|IPR, from, to             */
    		str_lower(p1);
    		if(matches(p1,"hnr"))
    		 {
    		  if(matches(p2,host_name))
    		  {
    		   host_name=(char *)malloc(strlen(p3)+1);
    		   strcpy(host_name,p3);
    		  }
    		 }
    		else if(matches(p1,"ipr"))
    		 {
    		  if(matches(p2,host_ip))
    		  {
    		   host_ip=(char *)malloc(strlen(p3)+1);
    		   strcpy(host_ip,p3);
    		  }
    		 }
    		else if(specs(p1,p2,host_name,host_ip))
    		 do_command(str_lower(p3),NULL);
    		break;
    case 4: /* qualifier, qual spec, command, arg */
    		if(specs(str_lower(p1),p2,host_name,host_ip))
    		 do_command(str_lower(p3),p4);
    		break;
    case 5: /* qualifier, qual spec, HNR|IPR, from, to */
    		if(specs(str_lower(p1),p2,host_name,host_ip))
    		{
    		 if(matches(p3,"hnr"))
    		  {
    		   if(matches(p4,host_name))
    		   {
    		    host_name=(char *)malloc(strlen(p5)+1);
    		    strcpy(host_name,p5);
    		   }
    		  }
    		 else if(matches(p3,"ipr"))
    		  {
    		   if(matches(p5,host_ip))
    		   {
    		    host_ip=(char *)malloc(strlen(p5)+1);
    		    strcpy(host_ip,p5);
    		   }
    		  }
    		}
    		break;
   }
  }
 }
 fclose(a);
}
