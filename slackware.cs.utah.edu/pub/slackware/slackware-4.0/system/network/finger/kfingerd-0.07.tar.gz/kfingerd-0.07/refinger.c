#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

/* This file is part of kfingerd-0.07 by Joel Katz (Stimpson@CyberPlus.COM) */
/* I know this is ugly, but it works and it works better than the old one */

void main(int argc, char **argv)
{
 char *j, *k;
 int arg_count=0, remote;
 char *args[128];
 argc--;
 args[0]=malloc(128);
 strcpy(args[0],"finger.bsd");
 while(argc>0)
 {
  remote=0;
  j=argv[arg_count+1];
  k=args[arg_count+1]=malloc(512);
  if((*j=='-')||*j==('/')) remote=1;
  while (*j!=0)
  {
   *k=*j;
   if(*k=='@') remote=1;
   k++;
   j++;
  }
  if(!remote) *(k++)='@';
  *k=0;
  argc--;
  arg_count++;
 }
 args[arg_count+1]=NULL;
 execvp("finger.bsd",args);
}
