#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include "ssl.h"

int sslError(int err, char* estr)
   {
   return err;
   }

int selCipher(ssllib* ssl, u_long *cipher, u_short len)
   {
   int i, j, found = 0, cnt = len / 4;
   int which[10];
   u_long *ptr;

   if (len % 4)
      return sslError(-1,"");
   for (i=0;i<cipherCnt;i++)
      {
      ptr = cipher;
      for (j=0;j<cnt;j++)
	 {
	 if (*ptr == cipherTypes[i].type)
	    which[found++] = i;
	 ptr++;
	 }
      }
   if (!found)
      return sslError(-11,"");
   ptr = ssl->cph;
   for (i=0;i<found;i++)
      {
      *ptr = cipherTypes[which[i]].type;
      ptr++;
      }
   ssl->cphLen = found * 4;
   return which[0];
   }

void MakeKeys(ssllib *ssl)
   {
   crypto *crypt = ssl->sid->crypt;
   (*crypt->mkKey)(ssl, crypt, ssl->server);
   }

sidRec * findSID(ssllib *ssl, u_char *buf, int len)
   {
#ifdef BLOCK
   int fd = ssl->wfile->desc;
#else
   int fd = ssl->fd;
#endif
   u_char newsid[MD5_LEN];
   u_char name[32 - MD5_LEN];
   if (!buf || !len)
      { /*from cli in send hello */
      ssl->sid = (sidRec*) malloc(sizeof(sidRec));
      if (noRSA)
	 {
	 len = privSID(newsid, fd);
	 }
      return ssl->sid;
      }
   else
      { /* from srv in recv hello */
      
      }
   ssl->hit = 0;
   return 0;
   }

int chkSID(sidRec *sid, u_char *buf, int len)
   {
   if (!sid->sid || !sid->sidLen)
      {
      sid->sid = (u_char*) malloc(len);
      memcpy(sid->sid, buf, len);
      sid->sidLen = len;
      addSID(sid);
      }
   if (memcmp(sid->sid, buf, len))
      return sslError(-1,"");
   return 0;
   }

int chkChal(ssllib *ssl, u_char *buf, int len)
   {
   if (ssl->chalLen != len)
      return sslError(-1,"");
   if (memcmp(ssl->chal, buf, len))
      return sslError(-1,"");
   return 0;
   }

u_char * Copy(u_char *to, u_char *from, int len)
   {
   if (len < 1)
      return (u_char*)len;
   if (to)
      to = (u_char*) realloc(to, len);
   else
      to = (u_char*) malloc( len);
   if (to == NULL)
      sslError(-2,"");
   memcpy(to,from,len);
   return to;
   }

int chkCID(ssllib *ssl, u_char *buf, int len)
   {
   if (ssl->cidLen != len)
      return sslError(-1,"");
   if (memcmp(ssl->cid, buf, len))
      return sslError(-1,"");
   return 0;
   }

void addSID(sidRec *sid)
   {
   
   }

int mkCert()
   {
   return 0;
   }

int mkAuth()
   {
   return 0;
   }

int chkCert(ssllib *ssl, char type, u_char *cert, u_short len)
   {
   return 0;
   }

int chkAuth(ssllib *ssl, int type, u_char *auth, int len)
   {
   return 0;
   }








