/*                               -*- Mode: C -*- 
 * srvmain.c -- 
 * Copyright (c) 1995 Shaun Savage.
 * All rights reserved.
 *
 * Author          : Shaun Savage
 * Created On      : Sun May  7 17:16:19 1995
 * Last Modified By: Shaun Savage
 * Last Modified On: Sun May  7 17:16:31 1995
 * Update Count    : 1
 * Status          : Unknown, Use with caution!
 * PURPOSE
 * 	|>Description of modules purpose<|
 * TABLE OF CONTENTS
 * 
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
#include <signal.h>
#include "tcplib.h"
#include "ssl.h"

extern int opensrv(ssllib *ssl, int sock);
extern void runsrv(ssllib *ssl);
extern crypto dummyCrypt;
extern crypto des3Crypt;

int hit_cnt = 0;
u_char UAuth[16] = "";
u_char UKey[16] = "";
int noRSA = 1;
certRec cert[] = {{0,"",0}};
Ciphers cipherTypes[] = {
/*   {SSL_CK_DES_192_EDE3_CBC_WITH_MD5,"DES3",&des3Crypt},*/
   {SSL_CK_NULL,"DUMMY", &dummyCrypt}
};
short cipherCnt = 2;


int main (argc, argv)
   int argc;
   char *argv [];
   {
   int lsock, rsock, childPid, port;

   strcpy(pname, argv[0]);
   if (argc != 2) {
      printf("usage: sslsrv <port>\n");
      exit(-1);
      }
   port = atoi(argv[1]);

   signal(SIGCHLD,SIG_IGN);

   lsock = TCPListen(port);

   for (;;)
      {
      if ((rsock = TCPAccept( lsock)) < 0)
	 sslError(-9,"");
      
      hit_cnt++;
/*      if ((childPid = fork()) < 0)
	 return sslError(-6,"");
	 
      else if (childPid == 0)*/
	 {
	 ssllib myssl;
	 if (opensrv(&myssl, rsock) < 0)
	    exit(0);;
	 
	 runsrv(&myssl);
	 exit(0);
	 }
      }
   }

int opensrv(ssllib* ssl, int sock)
   {
   srv_init(ssl);
   ssl->fd = sock;
   return srv_handshake(ssl);
   }

int accnt(char * buf, int len)
   {
   sprintf(buf, "Access %d", hit_cnt);
   return 0;
   }

int uptime(char * buf, int len)
   {
   sprintf(buf,"uptime");
   return 0;
   }

struct _test {
   char *str;
   int  (*proc)();
} mytest[] = {
   { "1"  , accnt},
   { "2"  , uptime},
   { NULL , 0}
};

char * parseIn(char *buf, int len)
   {
   struct _test *t;
   
   for (t = mytest;t->str;t++ )
      {
      if (!strcmp(buf, t->str))
	 return (char*)t->proc;
      }
   return NULL;
   }

void runsrv(ssllib *ssl)
   {
   int rslt, len, done = 0;
   char buf[1024], *ptr;
   int (*proc)();
   
   while (!done)
      {
      if ((len = rdMsg(ssl, buf, 1023)) < 0)
	 return;
      buf[len] = 0;
      if (!(proc = parseIn(buf,len)))
	  return;
      rslt = (*proc)(buf, len);
      wrMsg(ssl, buf, strlen(buf)+1);
      done = 1;
      }
   }









