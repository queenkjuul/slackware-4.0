#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include "ssl.h"
#include "rsa20/rsaref.h"
#include "rsa20.rsa.h"

typedef struct _rsacx {
   R_RSA_PUBLIC_KEY  *mypub;
   R_RSA_PRIVATE_KEY *myprv;
   R_RANDOM_STRUCT   *rand;
   R_RSA_PUBLIC_KEY  *pub;
   R_RSA_PRIVATE_KEY *prv;
} rsacx;

static
int Init(crypto *crypt,u_char *key, u_char *arg, int type)
   {
   return 0;
   }

static
int Update(crypto *crypt, u_char *obuf, u_char *ibuf, int len)
   {
   return 0;
   }

static
int Finish(crypto *crypt, u_char *buf, int len)
   {
   return 0;
   }

static
int enCrypt(crypto *crypt, u_char *buf, int len)
   {
   u_char tbuf[8] = "HEMPHEMP";
   Init(crypt, crypt->mKey, crypt->arg, EN0);
   Update(crypt, buf, buf, len);
   Finish(crypt, tbuf, 0);
   return 0;
   }

static
int deCrypt(crypto *crypt, u_char *buf, int len)
   {
   u_char tbuf[8] = "HEMPHEMP";
   Init(crypt, crypt->mKey, crypt->arg, DE1);
   Update(crypt, buf, buf, len);
   Finish(crypt, tbuf, 0);
   return 0;
   }

static
int mkKey(ssllib *ssl, crypto *crypt, int srv)
   {
   u_int i, cnt, buf[64];

   R_RANDOM_STRUCT *rand;
   rsacx *cx = (rsacx*) malloc(sizeof(rsacx));
   rand = (R_RANDOM_STRUCT*) malloc( sizeof(R_RANDOM_STRUCT));
   cx->rand = rand;

   R_RandomInit(rand);
   R_GetRandomByteNeeded(cnt,rand);
   R_RandomUpdate(rand, buf, 64); 

   u_char km[3][MD5_LEN];
   
   crypt->mKey = ssl->key;
   crypt->mkeyLen = ssl->keyLen;
   crypt->arg  = ssl->arg;
   crypt->argLen  = ssl->argLen;
   keyMaterial(ssl, km[0], "0");

   return 0;
   }

crypto dummyCrypt = {
   {0,0,0},
   0,
   0, NULL,
   0, NULL,
   0, NULL, NULL,
   0, NULL,
   Init,
   Update,
   Finish,
   enCrypt,
   deCrypt,
   mkKey
};

