/*                               -*- Mode: C -*- 
 * security.h -- 
 * Copyright (c) 1995 Shaun Savage.
 * All rights reserved.
 *
 * Author          : Shaun Savage
 * Created On      : Fri Feb  3 10:00:46 1995
 * Last Modified By: Shaun Savage
 * Last Modified On: Sun May  7 17:22:29 1995
 * Update Count    : 38
 * Status          : Unknown, Use with caution!
 * PURPOSE
 *
 * TABLE OF CONTENTS
 *
 * 
 */
#ifndef _TCPLIB_H
#define _TCPLIB_H

typedef int Bool;
typedef int bool;

#define TRUE 1
#define FALSE 0
#define YES  1
#define NO 0
#define ERR -1

#define  INET_ADDR u_long

#define TCPEDIESC	(0xff)	/* escape charactor for TCP stream */
#define TCPEDISTX	(0x01)	/* start of EDI block */
#define TCPEDIDLE	(0x08)	/* indicates ESC char is in EDI block */
#define	TCPEDIETX	(0x02)	/* end of EDI block */

struct TcpBufferingInfo{
  size_t	InPtr;		/* current write point in buffer */
  size_t	OutPtr;		/* current read point in buffer */
  size_t	BufSize;	/* total capacity of buffer */
  bool		cont;		/* flag that convert is continuing */
  int		desc;		/* file descriptor of stream */
  /* any timeouts or the like would go here */
  char		Buf[1];		/* TCP out buffer */
};

typedef struct TcpBufferingInfo StreamInfo;


extern int  TCPOpen(u_long IPAddr, u_short Port);
extern int  TCPListen(u_short Port);
extern int  TCPAccept(int lsock);
extern int TCPClose(int fd);
extern int  TCPWrite();
extern int  TCPRead();
extern INET_ADDR get_firsthost_addr(char *name);

#endif /* _TCPLIB_H */





