/*                               -*- Mode: C -*- 
 * climain.c -- 
 * Copyright (c) 1995 Shaun Savage.
 * All rights reserved.
 *
 * Author          : Shaun Savage
 * Created On      : Sun May  7 17:17:33 1995
 * Last Modified By: Shaun Savage
 * Last Modified On: Sun May  7 17:17:40 1995
 * Update Count    : 1
 * Status          : Unknown, Use with caution!
 * PURPOSE
 * 	|>Description of modules purpose<|
 * TABLE OF CONTENTS
 * 
 */

#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include "tcplib.h"
#include "ssl.h"

extern int opencli(int);
extern crypto dummyCrypt;
extern crypto des3Crypt;

ssllib myssl;
u_char UAuth[16] = "";
u_char UKey[16] = "";
int noRSA = 1;
certRec cert[] = {{0,"",0}};
Ciphers cipherTypes[] = {
/*   {SSL_CK_DES_192_EDE3_CBC_WITH_MD5,"DES3",&des3Crypt},*/
   {SSL_CK_NULL,"DUMMY", &dummyCrypt}
};
short cipherCnt = 2;

int main (argc, argv)
   int argc;
   char *argv [];
   {
   int rsock;
   u_long srvaddr;
   char srvname[80];
   short srvport;

   strcpy(pname, argv[0]);

   if (argc < 3)
      return sslError(-1,"");
     
   
   strcpy(srvname,argv[1]);
   srvport = atoi(argv[2]); 

   srvaddr = get_firsthost_addr(srvname);
   host_info( srvname,"TEST");

   if ((rsock = TCPOpen(htonl(srvaddr), srvport)) < 0)
      exit(rsock);
   
   if (opencli(rsock) >= 0)
      {
      int len;
      char buf[1024];
      
      if (argc == 4)
	 {
	 strcpy(buf,argv[3]);
	 wrMsg(&myssl, buf, strlen(buf));
	 len = rdMsg(&myssl, buf, 1023);
	 printf("Result %d >%s<\n", len, buf);
	 }
      }

   TCPClose(rsock);
   exit(0);
   }

int opencli(int rsock)
   {
   cli_init(&myssl);
   myssl.fd = rsock;
   return cli_handshake(&myssl);
   }


