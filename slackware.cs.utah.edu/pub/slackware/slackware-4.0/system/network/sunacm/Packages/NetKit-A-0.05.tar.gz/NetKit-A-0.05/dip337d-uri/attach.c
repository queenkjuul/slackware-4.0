/*
 * dip		A program for handling dialup IP connecions.
 *		This module handles setting the interface and
 *		its routing table entry.
 *
 * Version:	@(#)attach.c	3.3.4	05/29/94
 *
 * Author:      Fred N. van Kempen, <waltje@uWalt.NL.Mugnet.ORG>
 *		Copyright 1988-1993 MicroWalt Corporation
 *
 * Modified:    Uri Blumenthal, <uri@watson.ibm.com>
 *              (C) 1994
 *
 *		This program is free software; you can redistribute it
 *		and/or  modify it under  the terms of  the GNU General
 *		Public  License as  published  by  the  Free  Software
 *		Foundation;  either  version 2 of the License, or  (at
 *		your option) any later version.
 */
#include "dip.h"


int
attach(char *name, struct dip *dip)
{
  char buff[1024];

  /* Set up for "upping" the desired interface. */
  sprintf(buff, "%s %s %s pointopoint ", _PATH_BIN_IFCONFIG,
	name, inet_ntoa(dip->loc_ip));
  sprintf(&buff[strlen(buff)], "%s mtu %d ",
	  inet_ntoa(dip->rmt_ip), dip->mtu);
  if (dip->netmask[0] != '\0') 
     sprintf(&buff[strlen(buff)], " netmask %s",
             dip->netmask);
  if (opt_v)
    syslog(LOG_INFO, ">>> ATTACH \"%s\"\n", buff);
  if (system(buff) != 0) return(-1);

  sprintf(buff, "%s add %s %s", _PATH_BIN_ROUTE, 
	  inet_ntoa(dip->rmt_ip), name);
  if (opt_v)
    syslog(LOG_INFO, ">>> ATTACH \"%s\"\n", buff);
  if (system(buff) != 0) return(-1);

  if (dip->rtdefault == 1) {
     sprintf(buff, "%s add -net default gw %s metric %1d %s", 
	     _PATH_BIN_ROUTE, inet_ntoa(dip->rmt_ip), 1, name);
     if (opt_v)
       syslog(LOG_INFO, ">>> ATTACH \"%s\"\n", buff);
     if (system(buff) != 0) return(-1);
  } else {
    sprintf(buff, "%s add -host %s %s", _PATH_BIN_ROUTE, 
	    inet_ntoa(dip->loc_ip), name);
    if (opt_v)
      syslog(LOG_INFO, ">>> ATTACH \"%s\"\n", buff);
    if (system(buff) != 0) return(-1);    
  }
  
  return(0);
}


void
detach(char *name)
{
  char buff[1024];

  /* Set up for "downing" the desired interface. */
  sprintf(buff, "%s %s down", _PATH_BIN_IFCONFIG, name);
  syslog(LOG_INFO, ">>> DETACH \"%s\"\n", buff);
  (void) system(buff);
}
