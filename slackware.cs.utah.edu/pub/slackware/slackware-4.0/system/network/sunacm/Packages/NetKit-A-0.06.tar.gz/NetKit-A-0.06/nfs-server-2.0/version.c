char version[] = "Universal NFS Server, version 2.0";
