char version[] = "Version wu-2.2(1) Thu Mar 31 15:33:10 CST 1994";
