#ifndef LINT
static char rcsid[] = "$Id: putenv.c,v 1.3 1994/06/06 09:08:03 vixie Exp $";
#endif

#include "../../conf/portability.h"

/*
 *  To give a little credit to Sun, SGI,
 *  and many vendors in the SysV world.
 */

#if !defined(NEED_PUTENV)
int __bindcompat_putenv;
#else
int
putenv(str)
	char *str;
{
	register char *tmp;

	for (tmp = str; *tmp && (*tmp != '='); tmp++)
		;

	return (setenv(str, tmp, 1));
}
#endif
