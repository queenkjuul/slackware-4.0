#ifndef lint
static char Version[] = "@(#)vers.c	e07@nikhef.nl (Eric Wassenaar) 940623";
#endif

char *version = "940623";

#if defined(apollo)
int h_errno = 0;
#endif
