$set 7  #rarp

$ #_invalid Original Message:(Invalid Ethernet address: %s\n)
# Adresse Ethernet incorrecte: %s\n

$ #_unkn_host Original Message:(rarp: %s: unknown host\n)
# rarp: %s: h�te inconnu\n

$ #_noentry Original Message:(No ARP entry for %s\n)
# Pas d'entr�e ARP pour %s\n

$ #_usage1 Original Message:(Usage: rarp -a                   List Entries in cache.     \n)
# Syntaxe: rarp -a                      Liste les entr�es dans le cache.     \n

$ #_usage2 Original Message:(       rarp -d hostname          Delete hostname from cache.\n)
#          rarp -d nom_de_h�te          Efface le nom de h�te du cache.\n

$ #_usage3 Original Message:(       rarp -s hostname hw_addr  Add hostname to cache.\n)
#          rarp -s nom_de_h�te adr_mat  Ajoute le nom de h�te dans le cache.\n

$ #_unkn_hw Original Message:(rarp: %s: unknown hardware type.\n)
# rarp: %s: type de mat�riel inconnu.\n
