$set 18  #slip

$ #_slip Original Message:(Serial Line IP)
# Ligne S�rie IP

$ #_cslip Original Message:(VJ Serial Line IP)
# Ligne S�rie `VJ' IP

$ #_slip6 Original Message:(6-bit Serial Line IP)
# Ligne S�rie `6-bits' IP

$ #_cslip6 Original Message:(VJ 6-bit Serial Line IP)
# Ligne S�rie `VJ 6-bits' IP

$ #_adaptive Original Message:(Adaptive Serial Line IP)
# Ligne S�rie `Adaptative' IP

