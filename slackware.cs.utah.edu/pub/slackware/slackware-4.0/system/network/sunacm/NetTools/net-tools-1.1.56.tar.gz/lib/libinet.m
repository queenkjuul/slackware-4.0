$ #0 Original Message:(config.h)
# config.h

$ #1 Original Message:(support.h)
# support.h

$ #2 Original Message:(pathnames.h)
# pathnames.h

$ #3 Original Message:(AX.25)
# AX.25

$ #4 Original Message:(config.h)
# config.h

$ #5 Original Message:(support.h)
# support.h

$ #6 Original Message:(pathnames.h)
# pathnames.h

$ #7 Original Message:(-%d)
# -%d

$ #8 Original Message:([NONE SET])
# [NONE SET]

$ #9 Original Message:(Invalid callsign)
# Invalid callsign

$ #10 Original Message:(ax25_input(%s): %s !\n)
# ax25_input(%s): %s !\n

$ #11 Original Message:(Callsign too long)
# Callsign too long

$ #12 Original Message:(ax25_input(%s): %s !\n)
# ax25_input(%s): %s !\n

$ #13 Original Message:(ax25_input(%s): )
# ax25_input(%s): 

$ #14 Original Message:(%02X )
# %02X 

$ #15 Original Message:(\n)
# \n

$ #16 Original Message:(%s\n)
# %s\n

$ #17 Original Message:(%s: %s\n)
# %s: %s\n

$ #18 Original Message:([NONE SET])
# [NONE SET]

$ #19 Original Message:(KISS_set_disc(%d): %s\n)
# KISS_set_disc(%d): %s\n

$ #20 Original Message:(ax25",	"AMPR AX.25)
# ax25",	"AMPR AX.25

$ #21 Original Message:(ax25",	"AMPR AX.25)
# ax25",	"AMPR AX.25

$ #22 Original Message:(Ethernet)
# Ethernet

$ #23 Original Message:(config.h)
# config.h

$ #24 Original Message:(support.h)
# support.h

$ #25 Original Message:(pathnames.h)
# pathnames.h

$ #26 Original Message:(%02X:%02X:%02X:%02X:%02X:%02X)
# %02X:%02X:%02X:%02X:%02X:%02X

$ #27 Original Message:([NONE SET])
# [NONE SET]

$ #28 Original Message:(in_ether(%s): invalid ether address!\n)
# in_ether(%s): invalid ether address!\n

$ #29 Original Message:(in_ether(%s): invalid ether address!\n)
# in_ether(%s): invalid ether address!\n

$ #30 Original Message:(in_ether(%s): trailing : ignored!\n)
# in_ether(%s): trailing : ignored!\n

$ #31 Original Message:(in_ether(%s): trailing junk!\n)
# in_ether(%s): trailing junk!\n

$ #32 Original Message:(in_ether(%s): %s\n)
# in_ether(%s): %s\n

$ #33 Original Message:(ether",	"10Mbps Ethernet)
# ether",	"10Mbps Ethernet

$ #34 Original Message:(config.h)
# config.h

$ #35 Original Message:(support.h)
# support.h

$ #36 Original Message:(pathnames.h)
# pathnames.h

$ #37 Original Message:(config.h)
# config.h

$ #38 Original Message:(support.h)
# support.h

$ #39 Original Message:(pathnames.h)
# pathnames.h

$ #40 Original Message:(%lX)
# %lX

$ #41 Original Message:(Burped on '%s'\n)
# Burped on '%s'\n

$ #42 Original Message:(config.h)
# config.h

$ #43 Original Message:(support.h)
# support.h

$ #44 Original Message:(pathnames.h)
# pathnames.h

$ #45 Original Message:(INET)
# INET

$ #46 Original Message:(config.h)
# config.h

$ #47 Original Message:(support.h)
# support.h

$ #48 Original Message:(pathnames.h)
# pathnames.h

$ #49 Original Message:(default)
# default

$ #50 Original Message:(rresolve: unsupport address family %d !\n)
# rresolve: unsupport address family %d !\n

$ #51 Original Message:(default)
# default

$ #52 Original Message:(*)
# *

$ #53 Original Message:(%d.%d.%d.%d)
# %d.%d.%d.%d

$ #54 Original Message:(%d.%d.%d.%d)
# %d.%d.%d.%d

$ #55 Original Message:([NONE SET])
# [NONE SET]

$ #56 Original Message:(inet",	"DARPA Internet)
# inet",	"DARPA Internet

$ #57 Original Message:(config.h)
# config.h

$ #58 Original Message:(support.h)
# support.h

$ #59 Original Message:(pathnames.h)
# pathnames.h

$ #60 Original Message:(%02X-)
# %02X-

$ #61 Original Message:([NONE SET])
# [NONE SET]

$ #62 Original Message:(unspec",	"UNSPEC)
# unspec",	"UNSPEC

$ #63 Original Message:(loop",	"Local Loopback)
# loop",	"Local Loopback

$ #64 Original Message:(config.h)
# config.h

$ #65 Original Message:(support.h)
# support.h

$ #66 Original Message:(pathnames.h)
# pathnames.h

$ #67 Original Message:(You cannot start PPP with this program.\n)
# You cannot start PPP with this program.\n

$ #68 Original Message:(ppp",	"Point-Point Protocol)
# ppp",	"Point-Point Protocol

$ #69 Original Message:(config.h)
# config.h

$ #70 Original Message:(support.h)
# support.h

$ #71 Original Message:(pathnames.h)
# pathnames.h

$ #72 Original Message:(SLIP_set_disc(%d): %s\n)
# SLIP_set_disc(%d): %s\n

$ #73 Original Message:(SLIP_set_encap(%d): %s\n)
# SLIP_set_encap(%d): %s\n

$ #74 Original Message:(slip",	"Serial Line IP)
# slip",	"Serial Line IP

$ #75 Original Message:(cslip",	"VJ Serial Line IP)
# cslip",	"VJ Serial Line IP

$ #76 Original Message:(slip6",	"6-bit Serial Line IP)
# slip6",	"6-bit Serial Line IP

$ #77 Original Message:(cslip6",	"VJ 6-bit Serial Line IP)
# cslip6",	"VJ 6-bit Serial Line IP

$ #78 Original Message:(adaptive",	"Adaptive Serial Line IP)
# adaptive",	"Adaptive Serial Line IP

$ #79 Original Message:(config.h)
# config.h

$ #80 Original Message:(support.h)
# support.h

$ #81 Original Message:(pathnames.h)
# pathnames.h

$ #82 Original Message:(%02X-)
# %02X-

$ #83 Original Message:([NONE SET])
# [NONE SET]

$ #84 Original Message:([NONE SET])
# [NONE SET]

$ #85 Original Message:(unix",	"UNIX Domain)
# unix",	"UNIX Domain

$ #86 Original Message:(unspec",	"UNSPEC)
# unspec",	"UNSPEC

