$set 8  #slattach

$ #_user_unkn Original Message:(slattach: tty_lock: UUCP user %s unknown!\n)
# slattach: tty_lock: UUCP user %s unknown!\n

$ #_drop Original Message:(slattach: tty_hangup(DROP): %s\n)
# slattach: tty_hangup(DROP): %s\n

$ #_raise Original Message:(slattach: tty_hangup(RAISE): %s\n)
# slattach: tty_hangup(RAISE): %s\n

$ #_cant_state Original Message:(slattach: tty_open: cannot get current state!\n)
# slattach: tty_open: cannot get current state!\n

$ #_cant_disc Original Message:(slattach: tty_open: cannot get current line disc!\n)
# slattach: tty_open: cannot get current line disc!\n

$ #_cant_raw Original Message:(slattach: tty_open: cannot set RAW mode!\n)
# slattach: tty_open: cannot set RAW mode!\n

$ #_cant_bps Original Message:(slattach: tty_open: cannot set %s bps!\n)
# slattach: tty_open: cannot set %s bps!\n

$ #_cant_8n1 Original Message:(slattach: tty_open: cannot set 8N1 mode!\n)
# slattach: tty_open: cannot set 8N1 mode!\n

$ #_usage1 Original Message:(Usage: slattach [-ehlLmnqv] [-c cmd] [-s speed] [-p protocol] tty | -\n)
# Usage: slattach [-ehlLmnqv] [-c cmd] [-s speed] [-p protocol] tty | -\n

$ #_unsupp Original Message:(slattach: unsupported protocol %s\n)
# slattach: unsupported protocol %s\n

$ #_started Original Message:(%s started)
# %s started

$ #_on Original Message:( on %s)
#  on %s

$ #_iface Original Message:( interface %s\n)
#  interface %s\n
