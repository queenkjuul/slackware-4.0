#define RELEASE "NET-3 Base Utilities release tools-1.1.95"
