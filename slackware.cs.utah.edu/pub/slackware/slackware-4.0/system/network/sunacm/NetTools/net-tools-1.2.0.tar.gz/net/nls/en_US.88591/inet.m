$set 14  #inet

$ #_debug1 Original Message:(rresolve: unsupport address family %d !\n)
# rresolve: unsupport address family %d !\n

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_darpa Original Message:(DARPA Internet)
# DARPA Internet

