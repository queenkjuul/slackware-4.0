/*
 * Copyright (c) 1994
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the Computer Systems
 *	Engineering Group at Lawrence Berkeley Laboratory.
 * 4. Neither the name of the University nor of the Laboratory may be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * @(#) $Header: pcap-int.h,v 1.7 94/06/14 20:03:33 leres Exp $ (LBL)
 */

#ifndef pcap_int_h
#define pcap_int_h

#include <pcap.h>

#define TCPDUMP_MAGIC		0xa1b2c3d4
#define SNOOP_MAGIC		"\x73\x6E\x6F\x6F\x70\x00\x00\x00"

/* See RFC 1761 */
#define SNOOP_TYPE_8023			0
#define SNOOP_TYPE_8024			1
#define SNOOP_TYPE_8025			2
#define SNOOP_TYPE_8026			3
#define SNOOP_TYPE_ETHERNET		4
#define SNOOP_TYPE_HDLC			5
#define SNOOP_TYPE_SYNCHRONOUS		6
#define SNOOP_TYPE_IBMCHAN		7
#define SNOOP_TYPE_FDDI			8
#define SNOOP_TYPE_OTHER		9
#define SNOOP_TYPE_UNASSIGNED		10

#define DLS_IEEE802		1518
#define DLS_EN10MB		1518
#define DLS_FDDI		8192

extern int link_type[];
extern int snoop_type[];
extern int snoop_size[];

#ifndef DEFAULT_SNAPLEN
#define DEFAULT_SNAPLEN 68
#endif

#define	SWAPLONG(y) \
((((y)&0xff)<<24) | (((y)&0xff00)<<8) | (((y)&0xff0000)>>8) | (((y)>>24)&0xff))
#define	SWAPSHORT(y) \
	( (((y)&0xff)<<8) | (((y)&0xff00)>>8) )

/*
 * read file
 */
struct pcap_rf {
	FILE *rfile;
	int swapped;
	int version_major;
	int version_minor;
	u_char *base;
	int format;
};

/*
 * write file
 */
struct pcap_dumper {
	FILE *wfile;
	int format;
	int swapped;
};

struct pcap_md {
	struct pcap_stat stat;
#ifdef PCAP_PF
	int use_bpf;
	u_long	TotPkts;	/* can't oflow for 79 hrs on ether */
	u_long	TotAccepted;	/* count accepted by filter */
	u_long	TotDrops;	/* count of dropped packets */
	long	TotMissed;	/* missed by i/f during this run */
	long	OrigMissed;	/* missed by i/f before this run */
#endif
};

struct pcap {
	int fd;
	int snapshot;
	int linktype;
	int tzoff;		/* timezone offset */

	struct pcap_rf rf;
	struct pcap_md md;

	/*
	 * Read buffer.
	 */
	int bufsize;
	u_char *buffer;
	u_char *bp;
	int cc;

	/*
	 * Place holder for pcap_next().
	 */
	u_char *pkt;

	/*
	 * Placeholder for filter code if bpf not in kernel.
	 */
	struct bpf_program fcode;

	char errbuf[PCAP_ERRBUF_SIZE];
};

void swap_snoop(struct pcap_file_snoop_header *hp);

#endif
