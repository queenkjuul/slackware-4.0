/* A stripped-down version of tcpdump that accepts a filter expression
 * and outputs its binary program in network byte order.
 * Length comes first and then an array of BPF instructions.
 */

#include <stdio.h>
#include <string.h>

#ifdef __STDC__
#include <stdlib.h>
#endif
#include <unistd.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include "interface.h"

#include <order.h>
#include <pcap.h>

#include "fddi.h"
int        fddipad = FDDIPAD;	/* yek, keep gencode.o references happy */

int tflag = 1;					/* yek, keep util.o references happy */

char *program_name;
int thiszone;

extern void bpf_dump(struct bpf_program *, int);


int main(int argc, char **argv)
{
	extern char *optarg;
	extern int optind, opterr;

	int op, i, len;
	int dflag = 0, Oflag = 1;
	int linktype = DLT_EN10MB, snaplen = DEFAULT_SNAPLEN;
	u_long netmask = 0;
	char *cp, *cmdbuf;
	struct bpf_program fcode;

	if ((cp = strrchr(argv[0], '/')) != NULL)
		program_name = cp + 1;
	else
		program_name = argv[0];

	opterr = 0;
	while ((op = getopt(argc, argv, "di:m:Os:")) != EOF)
		switch (op) {
		case 'd':
			++dflag;
			break;
		case 'i':
			linktype = atoi(optarg);
			break;
		case 'm':
			netmask = inet_addr(optarg);
			break;
		case 'O':
			Oflag = 0;
			break;
		case 's':
			snaplen = atoi(optarg);
			break;
		default:
			usage();
		}

	cmdbuf = copy_argv(&argv[optind]);

	if (pcap_compile_offline(cmdbuf, &fcode, Oflag, linktype, netmask, snaplen) < 0)
	{
		fprintf(stderr, "error compiling filter expression\n");
		exit(1);
	}

	if (dflag) {
		bpf_dump(&fcode, dflag);
		return 0;
	}

	len = fcode.bf_len;			/* save in case we are going to swap */
	if (byteorder() != BIG_ENDIAN)
	{
		for (i = 0; i < fcode.bf_len; i++)
		{
			SWAP_INT16(fcode.bf_insns[i].code);
			SWAP_INT32(fcode.bf_insns[i].k);
		}
		SWAP_INT32(fcode.bf_len);
	}

	fwrite(&fcode.bf_len, sizeof(fcode.bf_len), 1, stdout);
	for (i = 0; i < len; i++)
		fwrite(&fcode.bf_insns[i], sizeof(fcode.bf_insns[i]), 1, stdout);

	return 0;
}

void usage()
{
	fprintf(stderr,
"usage: compile [-dO] [-i interface] [-m netmask] [-s snaplen] [expr]\n");
	exit(1);
}
