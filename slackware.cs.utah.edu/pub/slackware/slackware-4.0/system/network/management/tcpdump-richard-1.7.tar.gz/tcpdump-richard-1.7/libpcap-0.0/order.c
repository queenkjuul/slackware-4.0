#include "order.h"

typedef int int32;

int order = -1;

int byteorder(void)
{
int32 test = 0x01020304;

	if (order != -1)
		return order;

	if (*(char *)&test == 0x01)
		order = BIG_ENDIAN;
	else
		order = LITTLE_ENDIAN;

	return order;
}
