#ifndef _ORDER_H
#define _ORDER_H

#ifndef BIG_ENDIAN
#define BIG_ENDIAN 4321
#define LITTLE_ENDIAN 1234
#endif

#define SWAP_INT16(i)	(i) = (((i) & 0xff) << 8) | (((i) & 0xff00) >> 8)
#define SWAP_INT32(i)	(i) = (((i) & 0xff) << 24) | (((i) & 0xff00) << 8) | (((i) & 0xff0000) >> 8) | (((i) & 0xff000000) >> 24)

int byteorder(void);

#endif
