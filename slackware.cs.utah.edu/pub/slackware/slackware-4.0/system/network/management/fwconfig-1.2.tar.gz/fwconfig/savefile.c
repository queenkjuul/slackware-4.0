/*
Copyright (C) 1998 Open Professionals 

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

//#define DEBUG
void GetPOSTData (void);
void SwapChar (char *pszOriginal, char cBad, char cGood);
static int IntFromHex (char *pszChars);
void URLDecode (unsigned char *pszEncoded);
void PrintMIMEHeader (void);
void PrintHTMLHeader (void);
void PrintHTMLTrailer (void);
void PrintOut (char *VarVal, FILE * fp);
void PrintPOSTData (void);
void CreateRules (FILE * fp);

char rgInputBuffer[4096];	/* Global storage for input */
char services[1024];
char outservice[1024];
char mservices[1024];
char zservices[2048];
char dst[1024];

/*--------------------------------------------*/
/* main()                                     */
/*--------------------------------------------*/
int
main ()
{
  char *pszReqMet;

  pszReqMet = getenv ("REQUEST_METHOD");
  if (pszReqMet == NULL)
    {
      printf ("This is a CGI Program, can't run from command line\n");
      exit (1);
    }
  else if (strcmp (pszReqMet, "GET") == 0)
    {
      PrintMIMEHeader ();
      PrintHTMLHeader ();
      printf ("Only POST method is supported.\n");
      PrintHTMLTrailer ();
      exit (1);
    }
  else if (strcmp (pszReqMet, "POST") == 0)
    {
      PrintMIMEHeader ();
      PrintHTMLHeader ();
      GetPOSTData ();
      PrintPOSTData ();
      PrintHTMLTrailer ();
    }
  else
    {
      PrintMIMEHeader ();
      PrintHTMLHeader ();
      printf ("Only POST method is supported.\n");
      PrintHTMLTrailer ();
      exit (1);
    }
  /* Flush the output */
  fflush (stdout);
  return EXIT_SUCCESS;
}

/*--------------------------------------------*/
/* GetPOSTData()                              */
/*--------------------------------------------*/
void
GetPOSTData (void)
{
  char *pszContentLength;	/* pointer to CONTENT_LENGTH */
  int iContentLength;		/* value of CONTENT_LENGTH */
  int i;			/* local counter */
  int x;			/* generic char variable */

  /* First retrieve a pointer to the CONTENT_LENGTH variable */
  pszContentLength = getenv ("CONTENT_LENGTH");

  /* If variable exists, convert it to an integer */
  if (pszContentLength != NULL)
    {
      iContentLength = atoi (pszContentLength);
    }
  else
    {
      iContentLength = 0;
    }

  /* Make sure specified length isn't greater than the size */
  /* of our rgInputBuffer */
  if (iContentLength > sizeof (rgInputBuffer) - 1)
    {
      iContentLength = sizeof (rgInputBuffer) - 1;
    }

  /* Now read iContentLength bytes from STDIN */
  i = 0;
  while (i < iContentLength)
    {
      x = fgetc (stdin);
      if (x == EOF)
	break;
      rgInputBuffer[i++] = x;
    }

  /* Terminate the string */
  rgInputBuffer[i] = '\0';

  /* And update iContentLength */
  iContentLength = i;
}

/*--------------------------------------------*/
/* SwapChar()                                 */
/*--------------------------------------------*/
void
SwapChar (char *pszOriginal, char cBad, char cGood)
{
  int i;

  i = 0;
  while (pszOriginal[i])
    {
      if (pszOriginal[i] == cBad)
	pszOriginal[i] = cGood;
      i++;
    }
}

/*--------------------------------------------*/
/* IntFromHex()                               */
/*--------------------------------------------*/
static int
IntFromHex (char *pszChars)
{
  int Hi;
  int Lo;
  int Result;

  /* Get the value of the first byte to Hi */
  Hi = pszChars[0];
  if ('0' <= Hi && Hi <= '9')
    {
      Hi -= '0';
    }
  else if ('a' <= Hi && Hi <= 'f')
    {
      Hi -= ('a' - 10);
    }
  else if ('A' <= Hi && Hi <= 'F')
    {
      Hi -= ('A' - 10);
    }

  /* Get the value of the second byte to Lo */
  Lo = pszChars[1];
  if ('0' <= Lo && Lo <= '9')
    {
      Lo -= '0';
    }
  else if ('a' <= Lo && Lo <= 'f')
    {
    }
  else if ('A' <= Lo && Lo <= 'F')
    {
      Lo -= ('A' - 10);
    }
  Result = Lo + (16 * Hi);
  return (Result);
}

/*--------------------------------------------*/
/* URLDecode()                                */
/*--------------------------------------------*/
void
URLDecode (unsigned char *pszEncoded)
{
  char *pszDecoded;

  /* Change plus signs to spaces */
  SwapChar (pszEncoded, '+', ' ');

  /* Now loop through looking for escapes */
  pszDecoded = pszEncoded;
  while (*pszEncoded)
    {
      if (*pszEncoded == '%')
	{
	  pszEncoded++;
	  if (isxdigit (pszEncoded[0]) && isxdigit (pszEncoded[1]))
	    {
	      *pszDecoded++ = (char) IntFromHex (pszEncoded);
	      pszEncoded += 2;
	    }
	}
      else
	{
	  *pszDecoded++ = *pszEncoded++;
	}
    }
  *pszDecoded = '\0';
}

/*--------------------------------------------*/
/* PrintMIMEHeader()                          */
/*--------------------------------------------*/
void
PrintMIMEHeader (void)
{
  printf ("Content-type: text/html\n\n");
}

/*--------------------------------------------*/
/* PrintHTMLHeader()                          */
/*--------------------------------------------*/
void
PrintHTMLHeader (void)
{
  printf (
	   "<html>\n"
	   "<head><title>FW CONFIG</title></head>\n"
	   "<body text=\"#C0C0C0\" bgcolor=\"#2F2F4F\" link=\"#0000EE\" vlink=\"#551A8B\" alink=\"#FF0000\">\n"
    );
}

/*--------------------------------------------*/
/* PrintHTMLTrailer()                         */
/*--------------------------------------------*/
void
PrintHTMLTrailer (void)
{
  printf (
	   "</body>\n"
	   "</html>\n"
    );
}

/*--------------------------------------------*/
/* PrintOut()                                 */
/*--------------------------------------------*/
void
PrintOut (char *VarVal, FILE * fp)
{
  char *pszEquals;		/* pointer to equals sign */
  int i, n;

  pszEquals = strchr (VarVal, '=');	/* find the equals sign */
  if (pszEquals != NULL)
    {
      *pszEquals++ = '\0';	/* terminate the variable name */
      URLDecode (VarVal);	/*decode the variable name */

      /* Convert the name to uppercase */
      i = 0;
      while (VarVal[i])
	{
	  VarVal[i] = toupper (VarVal[i]);
	  i++;
	}

      /* Decode the value associated with this Var name */
      URLDecode (pszEquals);

      /* print out the var=val pair */
      if (*VarVal == 'S' || *VarVal == 'E' || *VarVal == 'D' || *VarVal == 'N' || *VarVal == 'A' || *VarVal == 'L' || *VarVal == 'I')
	{
	  setenv (VarVal, pszEquals, 1);
	  fprintf (fp, "%s=\"%s\"\n", VarVal, pszEquals);
	}
    }
  setenv (VarVal, pszEquals, 1);
  if (*VarVal == 'S' || *VarVal == 'E' || *VarVal == 'D' || *VarVal == 'N' || *VarVal == 'A' || *VarVal == 'L' || *VarVal == 'I')
    ;
  else
    {
      strcat (services, " ");
      strcat (mservices, " ");
      strcat (outservice, " ");
      if (*VarVal == 'M')
	{
	  if (strcmp (VarVal, "MASQ") == 0)
	    ;
	  else
	    strncat (mservices, getenv (VarVal), 1024);
	}
      else if (*VarVal == 'C')
	{
	  if (strcmp (getenv (VarVal), "domain") == 0 || strcmp (getenv (VarVal), "icmp") == 0)
	    {
	      strncat (outservice, getenv (VarVal), 1024);
	      for (n = strlen (services) - 1; services[n] == ' '; n--);
	      services[++n] = '\0';
	      strcat (services, " ");
	    }

	  strncat (services, getenv (VarVal), 1024);
	}
      else if (*VarVal == 'O')
	strncat (outservice, getenv (VarVal), 1024);
      else if (*VarVal == 'Z')
	{
	  if (strcmp (VarVal, "ZDSTADDR") == 0)
	    strcat (zservices, "-D ");
	  if (strcmp (getenv (VarVal), "no logging") == 0)
	    {
	      strcat (zservices, "\n");
	    }
	  else
	    {
	      if (strcmp (getenv (VarVal), "-o") == 0)
		{
		  strcat (zservices, "\n");
		}
	      strncat (zservices, getenv (VarVal), 1024);
	      strncat (zservices, " ", 1204);
	    }
	}
    }
}

/*--------------------------------------------*/
/* PrintPOSTData()                            */
/*--------------------------------------------*/
void
PrintPOSTData (void)
{
  FILE *fp;
  char *pszToken;
  char temp[1024];
  time_t time_of_day;
  int n;
  int j = 0;

  printf ("<CENTER>\n");
  printf ("<font size=+1>FW CONFIG</font>\n<br>");
  printf ("<font size=+2>Firewall Script Created</font>\n<br><br>\n");
  printf ("<FORM METHOD=\"GET\" ACTION=\"fwconfig.html\">\n");
  printf ("<INPUT TYPE=\"submit\" VALUE=\"Back\"></FORM>\n");
  printf ("</CENTER>\n");

  fp = fopen ("fw-init", "w");
  if (fp == NULL)
    {
      perror ("Error: ");
      exit (1);
    }
  fprintf (fp, "#!/bin/sh\n");
  fprintf (fp, "# Firewall Script\n");
  time_of_day = time (NULL);
  fprintf (fp, "# Script created %s\n", ctime (&time_of_day));
  fprintf (fp, "# Set up variables\n");
  setenv ("ANYWHERE", "0.0.0.0/0", 1);
  setenv ("PORTS", "1024:65535", 1);

  pszToken = strtok (rgInputBuffer, "&");
  while (pszToken != NULL)
    {
      PrintOut (pszToken, fp);
      pszToken = strtok (NULL, "&");
    }

  fprintf (fp, "ANYWHERE=\"%s\"\n", getenv ("ANYWHERE"));
  fprintf (fp, "PORTS=\"%s\"\n\n", getenv ("PORTS"));

/*------------------------------------*/
/* Take leading and trailing spaces   */
/* out of string.                     */
/*------------------------------------*/
  for (n = 0; services[n] == ' '; n++);
  while ((temp[j++] = services[n++]));
  strncpy (services, temp, 1024);

  for (n = strlen (services) - 1; services[n] == ' '; n--);
  services[++n] = '\0';

/*------------------------------------*/
/* Take leading and trailing spaces   */
/* out of string.                     */
/*------------------------------------*/
  j = 0;
  for (n = 0; mservices[n] == ' '; n++);
  while ((temp[j++] = mservices[n++]));
  strncpy (mservices, temp, 1024);

  for (n = strlen (mservices) - 1; mservices[n] == ' '; n--);
  mservices[++n] = '\0';

/*------------------------------------*/
/* Take leading and trailing spaces   */
/* out of string.                     */
/*------------------------------------*/
  j = 0;
  for (n = 0; outservice[n] == ' '; n++);
  while ((temp[j++] = outservice[n++]));
  strncpy (outservice, temp, 1024);

  for (n = strlen (outservice) - 1; outservice[n] == ' '; n--);
  outservice[++n] = '\0';

/*------------------------------------*/
/* Take leading and trailing spaces   */
/* out of string.                     */
/*------------------------------------*/
  j = 0;
  for (n = 0; zservices[n] == ' '; n++);
  while ((temp[j++] = zservices[n++]));
  strncpy (zservices, temp, 1024);

  for (n = strlen (zservices) - 1; zservices[n] == ' '; n--);
  zservices[++n] = '\0';

  setenv ("TCP_ALLOWIN", services, 1);
  setenv ("MASQ_ALLOWIN", mservices, 1);
  setenv ("TCP_ALLOWOUT", outservice, 1);
  fprintf (fp, "TCP_ALLOWIN=\"%s\"\n", getenv ("TCP_ALLOWIN"));
  fprintf (fp, "MASQ_ALLOWIN=\"%s\"\n", getenv ("MASQ_ALLOWIN"));
  fprintf (fp, "TCP_ALLOWOUT=\"%s\"\n", getenv ("TCP_ALLOWOUT"));
  fprintf (fp, "\n");
  CreateRules (fp);
  fclose (fp);
  chmod ("fw-init", 00755);
}

/*--------------------------------------------*/
/* CreateRules()                              */
/*--------------------------------------------*/
void
CreateRules (FILE * fp)
{
  char *rules;
  char *pszToken;
  int rules_len;
  /* Most of the variables used in this section
     will be environment variables */

  rules = getenv ("TCP_ALLOWIN");
  rules_len = strlen (rules);
  if (rules_len > 2)
    {
      fprintf (fp,
	       "#  =====================================\n"
	       "#  ========== Incoming Rules ===========\n"
	       "#  =====================================\n\n"

	       "# Flush previous rules\n"
	       "ipfwadm -I -f\n\n"

	       "# Set default policy to deny\n"
	       "ipfwadm -I -p deny\n\n"

	       "# Unlimited traffic within the local network\n"
	       "ipfwadm -I -a accept -V \"$INTERNALIP\" -S \"$NETWORKIP\" -D \"$ANYWHERE\"\n\n");

      fprintf (fp, "# =====Deny spoofed packets and log denied requests\n"
	       "ipfwadm -I -a deny -V \"$EXTERNALIP\" -S \"$NETWORKIP\" -D \"$ANYWHERE\" -o\n\n");

      if (getenv ("ALOGGING") != NULL)
	{
	  fprintf (fp, "# Target\n");
	  fprintf (fp, "for SERVICES in `echo $TCP_ALLOWIN` ; do\n"
		   "	  /sbin/ipfwadm -I -a accept -P tcp -V \"$EXTERNALIP\" -S \"$ANYWHERE\" \\\n"
		   "	    \"$PORTS\" -D \"$EXTERNALIP\" \"$SERVICES\" \"$ALOGGING\" \n"
		   "done\n\n");
	  fprintf (fp, "# Return\n");
	  fprintf (fp, "for SERVICES in `echo $TCP_ALLOWOUT` ; do\n"
		   "      /sbin/ipfwadm -I -a accept -P tcp -S \"$ANYWHERE\" \"$SERVICES\" \\\n"
		   "	-D \"$EXTERNALIP\" \"$PORTS\" \"$ALOGGING\" \n"
		   "done\n\n");
	}
      else
	{
	  fprintf (fp, "# Target\n");
	  fprintf (fp, "for SERVICES in `echo $TCP_ALLOWIN` ; do\n"
		   "      /sbin/ipfwadm -I -a accept -P tcp -V \"$EXTERNALIP\" -S \"$ANYWHERE\" \\\n"
		   "        \"$PORTS\" -D \"$EXTERNALIP\" \"$SERVICES\" \n"
		   "done\n\n");
	  fprintf (fp, "# Return\n");
	  fprintf (fp, "for SERVICES in `echo $TCP_ALLOWOUT` ; do\n"
		   "	/sbin/ipfwadm -I -a accept -P tcp -S \"$ANYWHERE\" \"$SERVICES\" \\\n"
		   "	-D \"$EXTERNALIP\" \"$PORTS\" \n"
		   "done\n\n");
	}

      if (getenv ("ICMP") != NULL)
	{
	  fprintf (fp, "# Allow ping requests\n");
	  fprintf (fp, "/sbin/ipfwadm -I -a accept -P icmp -V \"$EXTERNALIP\" -S \"$ANYWHERE\" \\\n"
		   "	-D \"$EXTERNALIP\" \n\n");
	}

      if (getenv ("CDNS") != NULL)
	{
	  fprintf (fp, "# DNS\n");
	  fprintf (fp, "/sbin/ipfwadm -I -a accept -P udp -V \"$EXTERNALIP\" -S \"$ANYWHERE\" \\\n"
		   "	-D \"$EXTERNALIP\" \n");
	  fprintf (fp, "/sbin/ipfwadm -I -a accept -V \"$LOOPBACK\" -S \"$ANYWHERE\" -D \"$ANYWHERE\" \n\n");
	}

      if (getenv ("DLOGGING") != NULL || getenv ("ALOGGING") != NULL)
	{
	  fprintf (fp, "# Log the rest\n");
	  fprintf (fp, "/sbin/ipfwadm -I -a deny -S \"$ANYWHERE\" -D \"$ANYWHERE\" \"$DLOGGING\" \n\n");
	}
    }
  else
    {
      fprintf (fp,
	       "#  =====================================\n"
	       "#  ========== Incoming Rules ===========\n"
	       "#  =====================================\n\n"

	       "# Flush previous rules\n"
	       "ipfwadm -I -f\n\n"

	       "# Set default policy to deny\n"
	       "ipfwadm -I -p deny\n\n");
    }

  rules = getenv ("TCP_ALLOWOUT");
  rules_len = strlen (rules);
  if (rules_len > 2)
    {
      fprintf (fp,
	       "#  =====================================\n"
	       "#  ========== Outgoing Rules ===========\n"
	       "#  =====================================\n\n"

	       "# Flush previous rules\n"
	       "ipfwadm -O -f\n\n"

	       "# Set default policy to deny\n"
	       "ipfwadm -O -p deny\n\n"

	       "# Unlimited traffic within the local network\n"
	       "ipfwadm -O -a accept -V \"$INTERNALIP\" -S \"$ANYWHERE\" -D \"$NETWORKIP\" \n\n");

      if (getenv ("DLOGGING") != NULL || getenv ("ALOGGING") != NULL)
	{
	  fprintf (fp, "# Logging\n");
	  fprintf (fp,
		   "/sbin/ipfwadm -O -a deny -V \"$EXTERNALIP\" -S \"$ANYWHERE\" -D \"$NETWORKIP\" -o\n"
		   "/sbin/ipfwadm -O -a deny -V \"$EXTERNALIP\" -S \"$NETWORKIP\" -D \"$ANYWHERE\" -o\n\n");
	}

      if (getenv ("ALOGGING") != NULL)
	{
	  fprintf (fp, "# Target\n");
	  fprintf (fp, "for SERVICES in `echo $TCP_ALLOWOUT`; do\n"
		   "	/sbin/ipfwadm -O -a accept -P tcp -S \"$EXTERNALIP\" \"$PORTS\" \\\n"
		   "	-D \"$ANYWHERE\" \"$SERVICES\" \"$ALOGGING\" \n\n"
		   "done\n\n");

	  if (getenv ("ICMP") != NULL)
	    {
	      fprintf (fp, "# ICMP\n");
	      fprintf (fp, "/sbin/ipfwadm -O -a accept -P icmp -V \"$EXTERNALIP\" -S \"$EXTERNALIP\" \\\n"
		       "	-D \"$ANYWHERE\" \n\n");
	    }

	  fprintf (fp, "# Return\n");
	  fprintf (fp, "for SERVICES in `echo $TCP_ALLOWIN`; do\n"
		   "	/sbin/ipfwadm -O -a accept -P tcp -S \"$EXTERNALIP\" \"$SERVICES\" \\\n"
		   "	-D \"$ANYWHERE\" \"$PORTS\" -o \n"
		   "done\n\n");
	}
      else
	{
	  fprintf (fp, "# Target\n");
	  fprintf (fp, "for SERVICES in `echo $TCP_ALLOWOUT`; do\n"
		   "	/sbin/ipfwadm -O -a accept -P tcp -S \"$EXTERNALIP\" \"$PORTS\" \\\n"
		   "	-D \"$ANYWHERE\" \"$SERVICES\" \n\n"
		   "done\n\n");

	  if (getenv ("ICMP") != NULL)
	    {
	      fprintf (fp, "# ICMP\n");
	      fprintf (fp, "/sbin/ipfwadm -O -a accept -P icmp -V \"$EXTERNALIP\" -S \"$EXTERNALIP\" \\\n"
		       "    -D \"$ANYWHERE\" \n\n");
	    }

	  fprintf (fp, "# Return\n");
	  fprintf (fp, "for SERVICES in `echo $TCP_ALLOWIN`; do\n"
		   "      /sbin/ipfwadm -O -a accept -P tcp -S \"$EXTERNALIP\" \"$SERVICES\" \\\n"
		   "      -D \"$ANYWHERE\" \"$PORTS\" \n"
		   "done\n\n");
	}
      if (getenv ("CDNS") != NULL)
	{
	  fprintf (fp, "# DNS\n");
	  fprintf (fp, "/sbin/ipfwadm -O -a accept -P udp -V \"$EXTERNALIP\" -S \"$EXTERNALIP\" \\\n"
		   "    -D \"$ANYWHERE\" \n");
	  fprintf (fp, "/sbin/ipfwadm -O -a accept -V \"$LOOPBACK\" -S \"$ANYWHERE\" -D \"$ANYWHERE\" \n\n");
	}

      if (getenv ("DLOGGING") != NULL || getenv ("ALOGGING") != NULL)
	{
	  fprintf (fp, "# Log the rest\n");
	  fprintf (fp, "/sbin/ipfwadm -O -a deny -S \"$ANYWHERE\" -D \"$ANYWHERE\" -o\n\n");
	}
    }
  else
    {
      fprintf (fp,
	       "#  =====================================\n"
	       "#  ========== Outgoing Rules ===========\n"
	       "#  =====================================\n\n"

	       "# Flush previous rules\n"
	       "ipfwadm -O -f\n\n"

	       "# Set default policy to deny\n"
	       "ipfwadm -O -p deny\n\n");
    }

  fprintf (fp,
	   "#  =====================================\n"
	   "#  ======== Misc Rules go here =========\n"
	   "#  =====================================\n\n");

  pszToken = strtok (zservices, "\n");
  while (pszToken != NULL)
    {
      if (strlen (pszToken) > 36)
	{
	  fprintf (fp, "ipfwadm %s\n", pszToken);
	}
      pszToken = strtok (NULL, "\n");
    }
/*
   if (strlen (zservices) > 350) {
   zservices[strlen(zservices)-9]='\0';
   fprintf(fp,"ipfwadm %s\n", zservices);
   }
 */

  fprintf (fp, "\n");
  if (getenv ("MASQ") != NULL)
    {
      fprintf (fp,
	       "#  ======================================\n"
	       "#  ========== Forwarded Rules ===========\n"
	       "#  ======================================\n\n"

	       "# Flush previous rules\n"
	       "ipfwadm -F -f\n\n"

	       "# Set default policy to deny\n"
	       "ipfwadm -F -p deny\n\n");

      fprintf (fp, "for MSERVICES in `echo $MASQ_ALLOWIN`; do\n"
	       "	/sbin/ipfwadm -F -a m -P tcp -S \"$NETWORKIP\" -D \"$ANYWHERE\" $MSERVICES\n"
	       "done\n\n");

      fprintf (fp, "# DNS\n");
      fprintf (fp, "/sbin/ipfwadm -F -a m -P udp -S \"$NETWORKIP\" -D \"$ANYWHERE\" domain\n\n");

      if (getenv ("DLOGGING") != NULL || getenv ("ALOGGING") != NULL)
	{
	  fprintf (fp, "# Log the rest\n");
	  fprintf (fp, "/sbin/ipfwadm -F -a deny -S \"$ANYWHERE\" -D \"$ANYWHERE\" -o\n");
	}
    }
  else
    {
      fprintf (fp,
	       "#  ======================================\n"
	       "#  ========== Forwarded Rules ===========\n"
	       "#  ======================================\n\n"

	       "# Flush previous rules\n"
	       "ipfwadm -F -f\n\n"

	       "# Set default policy to deny\n"
	       "ipfwadm -F -p deny\n\n");
    }
}
