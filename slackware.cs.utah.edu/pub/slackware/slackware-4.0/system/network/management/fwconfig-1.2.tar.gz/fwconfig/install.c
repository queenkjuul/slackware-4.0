/*
Copyright (C) 1998 Open Professionals 

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

void GetPOSTData (void);
void SwapChar(char *pszOriginal, char cBad, char cGood);
static int IntFromHex(char *pszChars);
void URLDecode(unsigned char *pszEncoded);
void PrintMIMEHeader(void);
void PrintHTMLHeader(void);
void PrintHTMLTrailer(void);
void PrintOut(char *VarVal);
void PrintPOSTData(void);

char rgInputBuffer[4096];  /* Global storage for input */

/*--------------------------------------------*/
/* main()                                     */
/*--------------------------------------------*/
int main ()
{
  char *pszReqMet;

  pszReqMet = getenv ("REQUEST_METHOD");
  if (pszReqMet == NULL)
    {
      printf("This is a CGI Program, can't run from command line\n");
      exit (1);
    }
  else if (strcmp (pszReqMet, "GET") == 0)
    {
      PrintMIMEHeader();
      PrintHTMLHeader();
      printf("Only POST method is supported.\n");
      PrintHTMLTrailer();
      exit (1);
    }
  else if (strcmp (pszReqMet, "POST") == 0)
    {
      PrintMIMEHeader();
      PrintHTMLHeader();
      GetPOSTData ();
      PrintPOSTData();
      PrintHTMLTrailer();
    }
  else
    {
      PrintMIMEHeader();
      PrintHTMLHeader();
      printf("Only POST method is supported.\n");
      PrintHTMLTrailer();
      exit (1);
    }
  /* Flush the output */
  fflush (stdout);
  return EXIT_SUCCESS;
}

/*--------------------------------------------*/
/* GetPOSTData()                              */
/*--------------------------------------------*/
void GetPOSTData (void)
{
  char *pszContentLength;	/* pointer to CONTENT_LENGTH */
  int iContentLength;		/* value of CONTENT_LENGTH */
  int i;			/* local counter */
  int x;			/* generic char variable */

  /* First retrieve a pointer to the CONTENT_LENGTH variable */
  pszContentLength = getenv ("CONTENT_LENGTH");

  /* If variable exists, convert it to an integer */
  if (pszContentLength != NULL)
    {
      iContentLength = atoi (pszContentLength);
    }
  else
    {
      iContentLength = 0;
    }

  /* Make sure specified length isn't greater than the size */
  /* of our rgInputBuffer */
  if (iContentLength > sizeof (rgInputBuffer) - 1)
    {
      iContentLength = sizeof (rgInputBuffer) - 1;
    }

  /* Now read iContentLength bytes from STDIN */
  i = 0;
  while (i < iContentLength)
    {
      x = fgetc (stdin);
      if (x == EOF)
	break;
      rgInputBuffer[i++] = x;
    }

  /* Terminate the string */
  rgInputBuffer[i] = '\0';

  /* And update iContentLength */
  iContentLength = i;
}

/*--------------------------------------------*/
/* SwapChar()                                 */
/*--------------------------------------------*/
void SwapChar(char *pszOriginal, char cBad, char cGood)
{
  int i;

  i=0;
  while(pszOriginal[i]) {
    if(pszOriginal[i] == cBad)
      pszOriginal[i] = cGood;
    i++;
  }
}

/*--------------------------------------------*/
/* IntFromHex()                               */
/*--------------------------------------------*/
static int IntFromHex(char *pszChars)
{
  int Hi;
  int Lo;
  int Result;

  /* Get the value of the first byte to Hi */
  Hi = pszChars[0];
  if ('0' <= Hi && Hi <= '9') {
    Hi -= '0';
  } else
  if ('a' <= Hi && Hi <= 'f') {
    Hi -= ('a' - 10);
  } else
  if ('A' <= Hi && Hi <= 'F') {
    Hi -= ('A' - 10);
  }

  /* Get the value of the second byte to Lo */
  Lo = pszChars[1];
  if ('0' <= Lo && Lo <= '9') {
    Lo -= '0';
  } else
  if ('a' <= Lo && Lo <= 'f') {
  } else
  if ('A' <= Lo && Lo <= 'F') {
    Lo -= ('A' - 10);
  }
  Result = Lo + (16 * Hi);
  return (Result);
}

/*--------------------------------------------*/
/* URLDecode()                                */
/*--------------------------------------------*/
void URLDecode(unsigned char *pszEncoded)
{ 
  char *pszDecoded;

  /* Change plus signs to spaces */
  SwapChar (pszEncoded, '+', ' ');

  /* Now loop through looking for escapes */
  pszDecoded = pszEncoded;
  while (*pszEncoded) {
    if (*pszEncoded=='%') {
      pszEncoded++;
      if (isxdigit(pszEncoded[0]) && isxdigit(pszEncoded[1])) {
        *pszDecoded++ = (char) IntFromHex(pszEncoded);
        pszEncoded += 2;
      }
    } else {
        *pszDecoded ++ = *pszEncoded++;
    }
  }
  *pszDecoded = '\0';
}

/*--------------------------------------------*/
/* PrintMIMEHeader()                          */
/*--------------------------------------------*/
void PrintMIMEHeader(void)
{
  printf("Content-type: text/html\n\n");
}

/*--------------------------------------------*/
/* PrintHTMLHeader()                          */
/*--------------------------------------------*/
void PrintHTMLHeader(void)
{
  printf(
    "<html>\n"
    "<head><title>FW CONFIG</title></head>\n"
    "<body text=\"#C0C0C0\" bgcolor=\"#2F2F4F\" link=\"#0000EE\" vlink=\"#551A8B\" alink=\"#FF0000\">\n"
    );
}

/*--------------------------------------------*/
/* PrintHTMLTrailer()                         */
/*--------------------------------------------*/
void PrintHTMLTrailer(void)
{
  printf(
    "</body>\n"
    "</html>\n"
  );
}

/*--------------------------------------------*/
/* PrintOut()                                 */
/*--------------------------------------------*/
void PrintOut(char *VarVal)
{
  char *pszEquals; /* pointer to equals sign */
  int i;

  pszEquals = strchr(VarVal, '='); /* find the equals sign */
  if (pszEquals != NULL) {
    *pszEquals++ = '\0'; /* terminate the variable name */
    URLDecode(VarVal); /*decode the variable name */

    /* Convert the name to uppercase */
    i = 0;
    while (VarVal[i]) {
      VarVal[i] = toupper(VarVal[i]);
      i++;
    }

    /* Decode the value associated with this Var name */
    URLDecode(pszEquals);

    /* print out the var=val pair */
    printf("%s=\"%s\"\n",VarVal,pszEquals);
  }
}

/*--------------------------------------------*/
/* PrintPOSTData()                            */
/*--------------------------------------------*/
void PrintPOSTData(void)
{
  char *pszToken;

  printf("<CENTER>\n");
  printf("<font size=+1>FW CONFIG</font>\n<br>");
  printf("<font size=+2>Firewall Script Installed</font>\n<br><br>\n");
  printf("<FORM METHOD=\"GET\" ACTION=\"fwconfig.html\">\n");
  printf("<INPUT TYPE=\"submit\" VALUE=\"Back\"></FORM>\n");
  printf("</CENTER>\n");

  system("./fw-init");

  fflush(stdout);
  while (pszToken != NULL) {
      PrintOut(pszToken);
      pszToken=strtok(NULL,"&");
  }
}
