#ifndef STATIC
#define STATIC static
#endif

STATIC zsbhdr(int len, int type, register char *hdr);
STATIC zsbh32(int len, register char *hdr, int type, int flavour);
STATIC zshhdr(int len, int type, register char *hdr);
STATIC zsdata(register char *buf, int length, int frameend);
STATIC zsda32(register char *buf, int length, int frameend);
STATIC zrdata(register char *buf, int length);
STATIC zrdat32(register char *buf, int length);
STATIC garbitch(void);
STATIC zgethdr(char* hdr, int eflag);
STATIC zrbhdr(register char *hdr);
STATIC zrbhd32(register char *hdr);
STATIC zrhhdr(char *hdr);
STATIC zputhex(register int c);
STATIC zsendline(int c);
STATIC zgethex(void);
STATIC zgeth1(void);
STATIC zdlread(void);
STATIC noxrd7(void);
STATIC stohdr(unsigned long pos);
STATIC unsigned long rclhdr(register char *hdr);
STATIC init_zm(void);

