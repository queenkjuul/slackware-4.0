/* Special definitions for BSD.SSLtelnet, processed by autoheader.
 */

/* Define the canonical hostname */
#undef CANONICAL_HOST

/* Define if we want to use LINEMODE */
#undef LINEMODE

/* Define if struct utmp has member ut_host */
#undef HAVE_UT_HOST

/* Define if not have login -p */
#undef NO_LOGIN_P

/* Define if sys/file.h needs sys/types.h */
#undef PARAM_INCS_TYPES

/* Define if system is SCO */
#undef SCO

/* Define if setpgrp(void) is correct */
#undef SETPGRP_VOID

/* Define if system is SOLARIS */
#undef SOLARIS

/* Define if we have STREAMS */
#undef STREAMSPTY

/* Define if we have TERMCAP */
#undef TERMCAP

/* Define if socks should be used */
#undef USE_SOCKS

/* Define if ssl should be used */
#undef USE_SSL

/* Define if we have TERMIO */
#undef USE_TERMIO
