#ifndef STATIC
#define STATIC static
#endif

STATIC void bibi(int n);
int rz(int argc, char *argv[]);
STATIC usage(void);
STATIC wcreceive(int argc, char **argp);
STATIC wcrxpn(char *rpn);
STATIC wcrx(void);
STATIC wcgetsec(char *rxbuf, int maxtime);
STATIC procheader(char *name);
STATIC openit(char *name, char *openmode);
STATIC make_dirs(register char *pathname);
STATIC putsec(char *buf, register n);
STATIC char *substr(register char *s, register char *t);
STATIC chkinvok(char *s);
STATIC checkpath(char *name);
STATIC void ackbibi(void);
STATIC tryz(void);
STATIC rzfiles(void);
STATIC rzfile(void);
STATIC closeit(void);
STATIC sys2(register char *s);
STATIC exec2(register char *s);
STATIC init_rz(void);

