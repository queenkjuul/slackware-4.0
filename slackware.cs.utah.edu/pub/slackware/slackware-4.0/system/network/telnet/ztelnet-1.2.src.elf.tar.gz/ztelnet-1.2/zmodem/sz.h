#ifndef STATIC
#define STATIC static
#endif

STATIC void bibi(int);
STATIC void onintr(int);
int sz(int argc, char *argv[]);
STATIC void saybibi(void);
STATIC wcsend(int argc, char *argp[]);
STATIC wcs(char* oname);
STATIC wctxpn(char *name);
STATIC getnak(void);
STATIC wctx(unsigned long flen);
STATIC wcputsec(char* buf, int sectnum, int cseclen);
STATIC filbuf(register char *buf, int count);
STATIC zfilbuf(void);
STATIC fooseek(FILE *fptr, unsigned long pos, int whence);
STATIC char *substr(register char *s, register char *t);
STATIC usage(void);
STATIC getzrxinit(void);
STATIC sendzsinit(void);
STATIC zsendfile(char *buf, int blen);
STATIC zsendfdata(void);
STATIC getinsync(int flag);
STATIC zsendcmd(char *buf, int blen);
STATIC chkinvok(char *s);
STATIC countem(int argc, register char **argv);
STATIC init_sz(void);
