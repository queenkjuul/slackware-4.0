/* 	$Id: strdup.c,v 1.2 1996/01/31 10:02:49 martin Exp $	 */

#ifndef lint
static char vcid[] = "$Id: strdup.c,v 1.2 1996/01/31 10:02:49 martin Exp $";
#endif /* lint */

#include <string.h>
#include <malloc.h>

#if defined(_AIX)
char *strdup(char *s)
#else
char *strdup(const char *s)
#endif
{
  char *new;

  new = malloc(strlen(s) + 1);
  strcpy(new, s);

  return new;
}
