/* $Id$
   kirc Module handling file, by Alex Zepeda <garbanzo@hooked.net>
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "kdynlib.h"
#include "modules.h"
#include "irc.h"

#include <stdio.h>

#include <qobject.h>

#include <kdebug.h>

/* Hook Entry */
Hook::Hook(int type,QString description,void *function,QString t_hm,int num)
{
	hook_type=type;
	func=function;
	numeric=num;
	trigger_hostmask=t_hm.copy();
	descr=description;
	owner=0;
	trigger_channel.clear();
}

/* Module Entry */
moduleEnt::moduleEnt(const char *title)
{
  name = QString(title);
  return;
}

modLoader::modLoader(){
  modules.clear();
}

/* Module Loader */

bool modLoader::load_module(const char *name)
{
  int tempid=0; unsigned int count;
  Function_Exec xfunc;
  void *handle = KDynamicLibrary::loadLibrary(name,KDynamicLibrary::ResolveStrict);
  void *sym;

  if (!handle) {
    kdebug(KDEBUG_ERROR,4012,"dlerror: %s",dlerror());
    return false;
  }

  modules.append(new moduleEnt(name));
  modules.last()->handle = handle;

  sym = find_symbol(modules.count()-1,"kirc_uninit");
  if (sym)
	modules.last()->unload=sym;
  else
	modules.last()->unload=NULL;

  if (Settings::debug)
	kdebug(KDEBUG_INFO,4012,"Looking for init/register function in %s",name);
  sym = find_symbol(modules.count()-1,"kirc_register"); 
  if (!sym) {
    kdebug(KDEBUG_ERROR,4012,"Couldn't load: %s (no init/register function)",modules.last()->name.data());
    unload_module(name);
    return false;
  }

  xfunc = (Function_Exec)sym;
  tempid = (int)xfunc((void *)this);
  modules.last()->id = -1;

  if (Settings::debug)
	kdebug(KDEBUG_INFO,4012,"Looking for duplicate modules.");
  for (count=0;count<modules.count();count++) /* Check for duplicate modules */
  {
    if (modules.at(count)->id == tempid) {
      kdebug(KDEBUG_ERROR,4012,"Duplicate module attempt (%s).",modules.last()->name.data());
      unload_module(name);
      return false;
    }
  }

  modules.last()->id = tempid;

  kdebug(KDEBUG_INFO,4012,"loaded module: %s",modules.last()->name.data());
  return true;
}

bool modLoader::unload_module(const char *name)
{
  Function unloader;
  unsigned int count,o_count;
  kdebug(KDEBUG_INFO,4012,"unload_module(char*)");
  for (count=0;count<modules.count();count++)
    {
      if (! strcmp(modules.at(count)->name.data(),name) ){
	if (modules.at(count)->unload) {
		unloader=(Function)modules.at(count)->unload;
		unloader();
	}
	/* We've gotta destroy the hooks too */
	for (o_count=0;o_count<Hooks.count();o_count++) {
		if (Hooks.at(o_count)->owner == modules.at(count)->id) {
			Hooks.remove(o_count);
		}
	}
	KDynamicLibrary::unloadLibrary(modules.at(count)->handle);
	modules.remove(count);
	return true;
      }
    }
  return false;
}

bool modLoader::unload_module(int id)
{
  unsigned int count;
  if (Settings::debug)
    kdebug(KDEBUG_INFO,4012,"unload_module");
  for (count=0;count<modules.count();count++)
    {
      if (id==modules.at(count)->id)
	{
	dlclose(modules.at(count)->handle);
	/* We've gotta destroy the hooks too */
	modules.remove(count);
	return true;
      }
    }
  return false;
}

void * modLoader::find_symbol(int id, const char *symbol)
{
  void *sym;
  sym = KDynamicLibrary::getSymbol(modules.at(id)->handle,symbol);
  if (!sym) {
    if (Settings::debug)
#ifdef HAVE_DLFCN_H
      kdebug(KDEBUG_WARN,4012,"find_symbol: %s",dlerror());
#else
      kdebug(KDEBUG_WARN,4012,"find_symbol(%s) failed",symbol);
#endif
   }
   return sym;
}

void modLoader::add_hook(Hook *ho)
{
   if (ho->descr.isEmpty())
	emit Loaded_Module (QString("No description available").data());
   else
	emit Loaded_Module (ho->descr.data()) ;
   Hooks.append(ho);
   kdebug(KDEBUG_INFO,4012,"Hook added");
}

#include "modules.moc"
