/* The horribly split up server parsing stuff
   so I can do hooks in here.  I know there's
   a better way to do this, but I want to get
   this all released, and then fix it up.
   - alex blarf@undernet  */

#include "client.h"
#include "irc.h"
#include "ircapp.h"
#include "hooks.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define c_hook kircModules->Hooks.at(count)

// Ugly mofo of a prototype, I know!
extern "C" {
	int wild_match_per();
}

bool Client::Match_Hook(Hook *hook, const char *hostmask, const char *chan)
{
  short non_matches=0, matches=0; unsigned int count;

printf("match: %s\n",hostmask);
printf("match: %s\n",chan);
  if ( (!wild_match_per(hook->trigger_hostmask.data(),hostmask))
     && (hostmask) && (!hook->trigger_hostmask.isEmpty()) )
	non_matches++;

  for (count=0;count<hook->trigger_channel.count();count++) {
	if (wild_match_per(hook->trigger_channel.at(count)->data(),chan))
		matches++;
  }

  if (!matches && chan)
	non_matches++;
  if (non_matches)
	return false;
  return true;
}

void Client::Handle_Numeric(int numeric,const char *server,const char *data)
{
  unsigned int count;
  Numeric *param = new Numeric;
  Function_Hook exec_func;

  param->numeric=numeric;
  param->server=QString(server);
  param->text=QString(data);

  for (count=0;count<kircModules->Hooks.count();count++)
  {
    /* This is a really gnarly hack, but it should work since we're only comparing ints */
    if ( (c_hook->hook_type == Hook::Numeric) && 
	 ((numeric == c_hook->numeric) || (c_hook->numeric == -1)) ) {
	exec_func=(Function_Hook)c_hook->func;
	exec_func((void *)param);
    }
  }
}

void Client::HandleCTCP_Reply(const char *nick, const char *address, const char *ctcp, const
	char *data)
{
  unsigned int count;
  CTCP_Reply *param = new CTCP_Reply;
  Function_Hook exec_func;

  QString out(1024),CTCP;

  param->from.hostmask=QString(QString(nick)+QString("!")+QString(address));
  param->from.nick=QString(nick);
  param->from.address=QString(address);
  param->client=this;

  param->ctcp=QString(ctcp);
  param->rest=QString(data);
  CTCP=QString(ctcp);

  for (count=0;count<kircModules->Hooks.count();count++)
  {
    if (kircModules->Hooks.at(count)->hook_type == Hook::CTCPReply) {
      if (Match_Hook(c_hook,param->from.hostmask.data(),NULL)) {
        exec_func=(Function_Hook)kircModules->Hooks.at(count)->func;
        exec_func((void *)param);
      }
    }
  }

  if (CTCP.lower() == "ping") {
	unsigned int oldTime = (unsigned int)(atoi(data));
	time_t currentTime = time(NULL);
	unsigned int pingTime = (unsigned int)currentTime - oldTime;
	out.sprintf("%s PING reply: %u seconds", nick, pingTime);
  } else {
	out.sprintf ("CTCP %s Reply from %s: %s", CTCP.data(), nick, data);
  }

  Output(Output::NOTICE, NULL, out);
  delete param;
}

void Client::Handle_Notice(const char *nick, const char *address, const char *data)
{
  /* FIXME */
  unsigned int count;
  Notice *param = new Notice;
  Function_Hook exec_func=NULL;

  param->client=this;
  param->chan=0;
  param->from.nick=QString(nick);
  param->from.address=QString(address);
  param->from.hostmask=QString(QString(nick)+QString("!")+QString(address));
  param->message=QString(data);
  QString out(1024);
  for (count=0;count<kircModules->Hooks.count();count++) {
    if (c_hook->hook_type == Hook::Notice) {
      if (Match_Hook(c_hook,QString(QString(nick)+QString("!")+QString(address)),NULL)) {
	exec_func=(Function_Hook)c_hook->func;
	exec_func((void *)param);
      }
    }
  }

  out.sprintf ("Notice from %s: %s", nick, data);
  Output(Output::NOTICE, NULL, out);
  delete param;
}

void Client::Handle_ServerPong(const char *server,const char *data)
{
  unsigned int count;
  Pong *param = new Pong;
  Function_Hook exec_func=NULL;

  param->client=this;
  param->type=Pong::SPong;
  param->text=QString(data);
  param->server=QString(server);

  QString out(1024);

  for (count=0;count<kircModules->Hooks.count();count++)
  {
    if (c_hook->hook_type == Hook::ServerPong) {
      if (wild_match_per(c_hook->trigger_hostmask.data(),server)) {
	exec_func=(Function_Hook)c_hook->func;
	exec_func((void *)param);
      }
    }
  }

  out.sprintf("Got PONG (%s) from %s.", data,server);
  Output(Output::NOTICE, CONSOLENAME, out);
  delete param;
}

void Client::Handle_ServerPing(const char *data)
{
  unsigned int count;
  Ping *param = new Ping;
  Function_Hook exec_func=NULL;

  param->client=this;
  param->type=Ping::SPing;
  param->text=QString(data); /* FIXME */

  QString out(1024);

  for (count=0;count<kircModules->Hooks.count();count++) {
    if (c_hook->hook_type == Hook::ServerPing) {
      if (wild_match_per(c_hook->trigger_hostmask.data(),data)) {
	exec_func=(Function_Hook)c_hook->func;
	exec_func((void *)param);
      }
    }
  }

  out.sprintf("PONG %s\r\n", data);
  HandleEvent(Event::SOCKET_WRITE, out);
  delete param;
}

void Client::Handle_Join(const char *nick, const char *address, const char *channel)
{
  unsigned int count;
  Join *param = new Join;
  Function_Hook exec_func=NULL;

  QString out(1024);

  param->client=this;
  param->reason=0;
  param->nick.hostmask=QString(QString(nick)+QString("!")+QString(address));
  param->nick.address=QString(address);
  param->nick.nick=QString(nick);
  param->chan=QString(channel);

  for (count=0;count<kircModules->Hooks.count();count++) {
    if (kircModules->Hooks.at(count)->hook_type == Hook::Join) {
      if (Match_Hook(c_hook,QString(QString(nick)+QString("!")+QString(address)),channel)) {
	  exec_func=(Function_Hook)kircModules->Hooks.at(count)->func;
	  exec_func((void *)param);
      }
    }
  }

  if (QString(nick).lower() == Settings::myNick.lower()) {
	IrcApp::channels.append(new QString(channel));
	out.sprintf("MODE %s\r\n",channel);
	HandleEvent(Event::SOCKET_WRITE,out);
	HandleEvent(Event::JOIN_CHANNEL, channel);
  }

  out.sprintf("%s [%s] has joined the channel.", nick,address);
  Output(Output::NOTICE, channel, out);
  HandleEvent(Event::ADD_NICK, channel, nick);
  delete param;
}

void Client::Handle_Part(const char *nick,const char *address,const char *channel,const char *reason)
{
  unsigned int count;
  Part *param = new Part;
  Function_Hook exec_func=NULL;

  QString out(1024);

  param->client=this;
  param->reason=QString(reason);
  param->nick.nick=QString(nick);
  param->nick.address=QString(address);
  param->chan=QString(channel);

  for (count=0;count<kircModules->Hooks.count();count++)
  {
	if (kircModules->Hooks.at(count)->hook_type == Hook::Part) {
          if (Match_Hook(c_hook,QString(QString(nick)+QString("!")+QString(address)),channel)) {
	    exec_func=(Function_Hook)kircModules->Hooks.at(count)->func;
	    exec_func((void *)param);
	  }
	}
  }

  if (QString(nick).lower() != Settings::myNick.lower()) {
	out.sprintf("%s [%s] has left the channel.", nick, address);
	Output(Output::NOTICE, channel, out);
	HandleEvent(Event::REMOVE_NICK, channel, nick);
  } else {
	for (count=0;count<IrcApp::channels.count();count++) {
		if (!strcasecmp(channel,IrcApp::channels.at(count)->data()))
			IrcApp::channels.remove(count);
	}
	HandleEvent(Event::CLOSE_WINDOW,channel);
  }
  delete param;
}

void Client::Handle_Kick(const char *victim, const char *kicker, const char *channel, const char *reason)
{
  unsigned int count;
  Kick *param = new Kick;
  Function_Hook exec_func;

  QString out(1024);

  param->client=this;
  param->chan=QString(channel);
  param->reason=QString(reason);
  param->kicked=QString(victim);

  for (count=0;count<kircModules->Hooks.count();count++)
  {
	if (kircModules->Hooks.at(count)->hook_type == Hook::Kick) {
	  exec_func=(Function_Hook)kircModules->Hooks.at(count)->func;
	  exec_func((void *)param);
	}
  }

  if (QString(victim).lower() != Settings::myNick.lower()) {
	out.sprintf("%s was kicked by %s (%s)", victim, kicker, reason);
	Output(Output::NOTICE, channel, out);
	HandleEvent(Event::REMOVE_NICK, channel, victim);
  } else {
	out.sprintf("You were kicked off channel %s by %s (%s).  Attempting to rejoin...",channel,kicker,reason);
	for (count=0;count<IrcApp::channels.count();count++) {
		if (!strcasecmp(channel,IrcApp::channels.at(count)->data()))
			IrcApp::channels.remove(count);
	}
	Output(Output::ERROR, channel, out);
	if (Settings::autoRejoin) {
	  out.sprintf("JOIN %s\r\n", channel);
	  HandleEvent(Event::SOCKET_WRITE, out);
	}
  }
  delete param;
}

void Client::Handle_Nick(const char *from, const char *to)
{
  unsigned int count;
  NickChange *param = new NickChange;
  Function_Hook exec_func;

  for (count=0;count<kircModules->Hooks.count();count++)
  {
	if (kircModules->Hooks.at(count)->hook_type == Hook::NickChange) {
	  exec_func=(Function_Hook)kircModules->Hooks.at(count)->func;
	  exec_func((void *)param);
	}
  }

  if (QString(from).lower() == Settings::myNick.lower())
	HandleEvent(Event::CHANGE_MY_NICK, to);
  else
	HandleEvent(Event::CHANGE_NICK, from, to);
  return;
}

void Client::Handle_Quit(const char *nick, const char *reason)
{
  unsigned int count;
  Quit *param = new Quit;
  Function_Hook exec_func;

  param->client=this;
  param->chan=0;
  param->reason=QString(reason);
  param->nick.nick=QString(nick);

  for (count=0;count<kircModules->Hooks.count();count++)
  {
	if (kircModules->Hooks.at(count)->hook_type == Hook::Quit) {
	  exec_func=(Function_Hook)kircModules->Hooks.at(count)->func;
	  exec_func((void *)param);
	}
  }

  HandleEvent(Event::SIGNOFF, nick, reason);
  delete param;
}

void Client::Handle_Topic(const char *channel, const char *topic,const char *nick,const char *address)
{
  unsigned int count;
  TopicChange *param = new TopicChange;
  Function_Hook exec_func;
  QString out(1024);

  param->chan=QString(channel);
  param->topic=QString(topic);
  param->nick.nick=QString(nick);
  param->nick.address=QString(address);

  for (count=0;count<kircModules->Hooks.count();count++)
  {
	if (kircModules->Hooks.at(count)->hook_type == Hook::TopicChange) {
	  exec_func=(Function_Hook)kircModules->Hooks.at(count)->func;
	  exec_func((void *)param);
	}
  }

  out.sprintf("%s has changed the channel topic to \"%s\"", nick, topic);
  Output(Output::NOTICE,channel,out);
  HandleEvent(Event::TOPIC,channel,topic);
  delete param;
  return;
}

void Client::Handle_Invite(const char *nick,const char *address, const char *chan)
{  
  unsigned int count;
  Invite *param = new Invite;
  Function_Hook exec_func;
  QString out(1024);

  param->nick.nick = QString(nick);
  param->nick.address = QString(address);
  param->chan = QString(chan);
  param->client = this;

  for (count=0;count<kircModules->Hooks.count();count++)
  {
	if (kircModules->Hooks.at(count)->hook_type == Hook::Invite) {
	  exec_func=(Function_Hook)kircModules->Hooks.at(count)->func;
	  exec_func((void *)param);
	}
  }

  out.sprintf("%s (%s) invites you to join channel %s", nick, address, chan);
  Output(Output::INFO, NULL, out);
  delete param;
  return;
}

void Client::Handle_Error(const char *err)
{
  unsigned int count;
  Error *param = new Error;
  Function_Hook exec_func;

  param->text = QString(err);
  param->client = this;

  for (count=0;count<kircModules->Hooks.count();count++)
  {
	if (kircModules->Hooks.at(count)->hook_type == Hook::Invite) {
	  exec_func=(Function_Hook)kircModules->Hooks.at(count)->func;
	  exec_func((void *)param);
	}
  }
 
  Output(Output::ERROR,NULL,err);
  delete param;
  return;
}

void Client::Handle_Wallops(const char *sender,const char *wallops)
{
  QString out(1024);
  out.sprintf("!%s! %s",sender,wallops);
  Output(Output::NOTICE,CONSOLENAME,out);
}


void IrcApp::Event_Registered()
{
  unsigned int count;
  Client_Registered *param = new Client_Registered;
  Function_Hook exec_func;
  QString modes = QString("MODE ");

  param->client=client;

  for (count=0;count<client->kircModules->Hooks.count();count++)
  {
	if (client->kircModules->Hooks.at(count)->hook_type == Hook::Registered) {
	  exec_func=(Function_Hook)client->kircModules->Hooks.at(count)->func;
	  exec_func((void *)param);
	}
  }

  windowView->HandleEvent(Event::REGISTERED, NULL);
  ExecuteScript(GetFile(Settings::startupFile));
  app->DoNotify();
  notifyTimer->start(10000); // update every 10 secs
  modes.sprintf("%s %s ",modes.data(),Settings::myNick.data());
  if (Settings::defaultModeI)
	modes+="+i";
  if (Settings::defaultModeS)
	modes+="+s";
  if (Settings::defaultModeW)
	modes+="+w";
  modes+="\r\n";
  HandleEvent(Event::SOCKET_WRITE, modes);
}
