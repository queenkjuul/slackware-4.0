/**********************************************************************

	--- Dlgedit generated file ---

	File: GeneralOptions.h
	Last generated: Mon Aug 4 12:33:15 1997

 *********************************************************************/

#ifndef GeneralOptions_included
#define GeneralOptions_included

#include "GeneralOptionsData.h"
#include <qlist.h>
#include <qstring.h>
#include "server.h"
#include "user.h"
#include "irc.h"


class GeneralOptions : public GeneralOptionsData
{
    Q_OBJECT

public:

    GeneralOptions
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~GeneralOptions();
public slots:
    void SaveAll();
protected slots:
    virtual void serverSelected(int);
private:
    void LoadServerList();
    void SaveServerList();
    QList<QString> *serverList;
    void AddServer(const char *);

};
#endif // GeneralOptions_included
