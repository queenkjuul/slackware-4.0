/*
  kdynlib.cpp  -  A class for dynamic loading of libraries.

  written 1997 by Matthias Hoelzer
  
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   
  */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "kdynlib.h"
#include <qfile.h>
#include <kapp.h>
#include <klocale.h>
#include <qmsgbox.h>

#include <errno.h>

#ifdef HAVE_DLFCN_H
extern "C" { // this is necessary, because the libc on Alpha/Linux is broken
#include <dlfcn.h> 
}
#endif

#ifdef HAVE_SHLOAD
#include <dl.h>
#endif

KDynamicLibrary::KDynamicLibrary() {}
KDynamicLibrary::~KDynamicLibrary() {}

KDynamicHandle KDynamicLibrary::loadLibrary(QString fileName, LoadOption opt)
{
    QFile libfile(fileName);
    if (!libfile.exists()) {
	warning(klocale->translate("No such file \"%s\"!"), 
		 fileName.data());
    }

#ifdef HAVE_DLFCN_H

    return (KDynamicHandle)dlopen(fileName.data(), 
	  (opt == ResolveLazy) ? RTLD_LAZY : RTLD_NOW);

#elif HAVE_SHLOAD

  return (KDynamicHandle)shl_load(fileName.data(),
          (opt == ResolveLazy) ?
		BIND_DEFERRED : BIND_IMMEDIATE || BIND_NONFATAL, 0);
#endif

    return 0; // shouldn't happen
}

void *KDynamicLibrary::getSymbol(KDynamicHandle handle, QString symName)
{

#ifdef HAVE_DLFCN_H
    if (handle)
	return dlsym(handle, symName.data());
    else
	return 0L;

#elif  HAVE_SHLOAD

  void *address = 0;
		
  if (handle)
    if (shl_findsym((shl_t *)&handle, symName.data(), TYPE_UNDEFINED, &address) == 0)
      return address;

  return 0L;

#endif

    return 0L; // shouldn't happen
}
  
void KDynamicLibrary::unloadLibrary(KDynamicHandle handle)
{
#ifdef HAVE_DLFCN_H
    if (handle)
	dlclose(handle);
#endif

#ifdef HAVE_SHLOAD
  if (handle)
    shl_unload((shl_t)handle);
#endif

}
