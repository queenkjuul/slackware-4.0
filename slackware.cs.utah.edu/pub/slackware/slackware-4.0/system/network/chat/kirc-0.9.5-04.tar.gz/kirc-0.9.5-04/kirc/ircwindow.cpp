//$Id: ircwindow.cpp,v 1.8 1997/12/12 13:47:10 parallax Exp $

#ifdef CONFIG_H
#include "config.h"
#endif

#include "irc.h"
#include "ircapp.h"
#include "ircwindow.h"
#include "IrcWindowConfig.h"

#include <qkeycode.h>
#include <qclipbrd.h>
#include <string.h>                    
#include <qmlined.h>
#include <time.h>
#include <qregexp.h>
#include <qpopmenu.h>
#include <qdatetm.h>
#include <qcolor.h>

int GetMircNumber(QString str, int &index)
{
    QString num;
    for (int i=0; i<2; i++)
    {
        if (str[index] > 47 && str[index] < 58)
        {
            num+=str[index];
            index++;
        }
    }
    if (num.isEmpty())
        return -1;
    else
        return (atoi(num.data()));
}
            
            
CommandEntry::CommandEntry ( QWidget *parent, const char *n)
        : QLineEdit ( parent, n )
{
    history = new QList<QString>();
    CHECK_PTR(history);
    history->setAutoDelete(true);
    connect(this, SIGNAL(returnPressed()), SLOT(slotReturnPressed()) );
}

CommandEntry::~CommandEntry()
{
    delete history;
}



void CommandEntry::keyPressEvent( QKeyEvent *e ) 
{
    if ( e->state() & ControlButton ) {
        QString txt = text();
        switch ( e->key() ) {
            case Key_B:
                txt += 0x02;
                setText(txt);
                break;
            case Key_C:
                txt += 0x03;
                setText(txt);
                break;
            case Key_U:
                txt += 0x1F;
                setText(txt);
                break;
            case Key_I:
                txt += 0x16;
                setText(txt);
                break;
            case Key_K:
                txt += 0x03;
                setText(txt);
                break;
            case Key_O:
                txt += 0x0F;
                setText(txt);
                break;
            default:
                QLineEdit::keyPressEvent(e);
        }
        return;
    }
       
    if (e->key() == Key_Up)
    {
        QString *str = history->prev();
        if (str)
            setText(*str);
        else
            history->first();
        return;
    }
    
    if (e->key() == Key_Down)
    {
        QString *str = history->next();
        if (str)
                setText(*str);
        else
            history->last();   
        return;
    }
    
    if (e->key() == Key_PageUp)
    {
	emit PageUp();
	return;
    }   
    
    if (e->key() == Key_PageDown)
    {
	emit PageDown();
	return;
    }
    
    
    QLineEdit::keyPressEvent(e); 

}

void CommandEntry::slotReturnPressed()
{
    if (history->count() > (unsigned int)HISTORY_LENGTH)
        history->remove((unsigned int)0);
    history->remove(history->getLast()); // remove the ""
    history->append(new QString(text()));
    history->append(new QString(""));
}


IrcWindow::IrcWindow( QWidget *parent, const char *n)
        : QWidget ( parent, n)
{
    if (!strcasecmp(name(),CONSOLENAME))
    	logFileName = "Console.log";
    else {
    	logFileName = QString(name());
	logFileName.append(".log");
    }
    logNotices = false;
    logEnabled = false;
    logInternalMessages = false;
    logInfo = false;
    logActions = false;
    logOwn = false;
    logPrivMessages = false;
    logExclamation = false;
    logErrors = false;
    logServerMessages = false;
    logChatter = false;

    // Let's setup logging first
    logFile = NULL;
    configureLogging();
    UpdateCaption();
    setFocusPolicy(StrongFocus);
    commandArea = new CommandEntry (this, "commandArea");
//    commandArea->setFrame(FALSE);
    connect(commandArea, SIGNAL(returnPressed()), this, SLOT(HandleCommand()) );
    outputArea = new OutputWidget(this, "output Area");
    connect(commandArea, SIGNAL(PageUp()), outputArea, SLOT(PrevPage()));
    connect(commandArea, SIGNAL(PageDown()), outputArea, SLOT(NextPage()));
    // default in case we have no theme
    outputArea->setBackgroundColor(QColor(white));
    mdiWin = NULL;
}

void IrcWindow::SetMDIWindow(MDIWindow *w)
{
    mdiWin = w;
}

IrcWindow::~IrcWindow()
{
    
}

void IrcWindow::ApplyTheme()
{
     if (mdiWin)
        SetMDIThemeProperties();
     IrcApp::SetThemeProperties(commandArea, Settings::theme.commandLine);
     IrcApp::SetThemeProperties(outputArea, Settings::theme.chatArea);
}

void IrcWindow::SetMDIThemeProperties()
{
    IrcApp::SetThemeProperties(mdiWin, Settings::theme.channelWindows);
    QLabel *caption = mdiWin->Caption();
    IrcApp::SetThemeProperties(caption, Settings::theme.titleBars);
}

void IrcWindow::ReceiveOutput(KProcess *, char *buff, int len)
{
    QString str(buff, len);
//    ParseInput(str);
}

void IrcWindow::Output ( const char *string, int messageType )
{
    QColor bgc, c;
    QString s(string);
    if (Settings::timestamp)
    {
        if (messageType != Output::SERVER_MESSAGE && messageType != Output::INFO \
            && messageType != Output::INTERNAL_MESSAGE)
        {
            QString tm;
            tm.sprintf("[%s] ", (QTime::currentTime()).toString().data());
            s.prepend(tm);
        }
    }

    // Logging, whee!
    fflush(logFile);
    if (logFile && logEnabled) {
    	switch (type)
	{
		case Output::SERVER_MESSAGE:
			if (logServerMessages)
			  AddToLog(string);
		case Output::PRIVMESSAGE:
			if (logPrivMessages)
			  AddToLog(string);
		case Output::EXCLAMATION:
			if (logExclamation)
			  AddToLog(string);
		case Output::OWN:
			if (logOwn)
			  AddToLog(string);
		case Output::CHAN:
			if (logChatter)
			  AddToLog(string);
		case Output::INFO:
			if (logInfo)
			  AddToLog(string);
		case Output::ACTION:
			if (logActions)
			  AddToLog(string);
		case Output::INTERNAL_MESSAGE:
			if (logInternalMessages)
			  AddToLog(string);
		case Output::NOTICE:
			if (logNotices)
			  AddToLog(string);
		case Output::ERROR:
			if (logErrors)
			  AddToLog(string);
		case Output::NORMAL:
			  AddToLog(string);
			  break;
		default:
			break;
	}
	
	fflush(logFile);
    }

    const char *color = 0;
    const char *bgcolor = 0;
    const char *icon = 0;
    QFont f = outputArea->font();
    switch (messageType)
    {
        case Output::ACTION:
            f = IrcApp::ThemeFont(outputArea, Settings::theme.actionTxt);        
            icon = "star.gif";
            // icon = true;
            color = Settings::theme.actionTxt.textColor;
	    bgcolor = Settings::theme.actionTxt.backgroundColor;
            break;

        case Output::NOTICE:
            f = IrcApp::ThemeFont(outputArea, Settings::theme.noticeTxt);        
            icon = "notice.gif";
            //icon = true;
            // color = 0x00f80000;
            color =  Settings::theme.noticeTxt.textColor;
	    bgcolor = Settings::theme.noticeTxt.backgroundColor;
            break;

        case Output::SERVER_MESSAGE:
            f = IrcApp::ThemeFont(outputArea, Settings::theme.serverTxt);    
            icon = "server.gif";
            color = Settings::theme.serverTxt.textColor;
	    bgcolor = Settings::theme.serverTxt.backgroundColor;
            // icon = true;
            //color = 0x0000f8f8;
            break;
            
        case Output::OWN:
            f = IrcApp::ThemeFont(outputArea, Settings::theme.ownTxt);
            color = Settings::theme.ownTxt.textColor;
	    bgcolor = Settings::theme.ownTxt.backgroundColor;
            break;

        case Output::INFO:
        case Output::INTERNAL_MESSAGE:
            icon = "info.gif";
            // icon = true;
            f = IrcApp::ThemeFont(outputArea, Settings::theme.internalTxt);
            color = Settings::theme.internalTxt.textColor;
            break;

        case Output::PRIVMESSAGE:
             f = IrcApp::ThemeFont(outputArea, Settings::theme.privmsgTxt);
            color = Settings::theme.privmsgTxt.textColor;
	    bgcolor = Settings::theme.privmsgTxt.backgroundColor;
            break;

        case Output::ERROR:
            icon ="error.gif";
             f = IrcApp::ThemeFont(outputArea, Settings::theme.errorTxt);
            color = Settings::theme.errorTxt.textColor;
	    bgcolor = Settings::theme.errorTxt.backgroundColor;
            break;
	case Output::NORMAL:
	    color = Settings::theme.chatArea.textColor;
	    bgcolor = Settings::theme.chatArea.backgroundColor;
    }


    if (color)
	    c = QColor(color);
    else
	    c = QColor(white);

    if (bgcolor)
	    bgc = QColor(bgcolor);
    else
	    bgc = QColor(black);

    outputArea->SetCurrentColor(c);
    outputArea->SetCurrentBgColor(bgc);
     if (icon)
    {
        QString str = "icons/";
        str += icon;
        outputArea->InsertPixmap(IrcApp::GetFile(str));
    }
     QString str;
    // now deal with all those control characters
     outputArea->SetCurrentFont(f);
    int i=0;
    while (s[i])
    {
        if (s[i] < 0x20)
        { // must be a control character
            outputArea->InsertText(str);
            str = "";
            switch (s[i])
            {
		case 0x01:
		    break;
                case 0x02: // CTRL-B is bold
                    f.setBold(!f.bold());
                    break;
                case 0x16: //CTRL-V is inverse
                    outputArea->SetInverse(!(outputArea->IsInverse()));
                    break;
                case 0x1F:   // CTRL-_ toggles underline on/off
                    f.setUnderline(!f.underline());
                    break;
                case 0x0F: // CTRL-O turns everything off
                    f.setBold(false);
                    f.setUnderline(false);
                    outputArea->SetInverse(false);
                    break;
                case 0x03: // MIRC colors; Gawd I hate this shit...
                    i++;
                    int num1, num2;num2=-1;num1=-1;
                    num1 = GetMircNumber(s, i);
                    if (s[i] == ',')
                    {
                        i++;
                        num2 = GetMircNumber(s, i);
                    } 

                    if ( (num1 != -1) && (num2 != -1) ) {
			outputArea->SetCurrentColor(mircToQColor(num1));
			outputArea->SetCurrentBgColor(mircToQColor(num2));
		    } else if ( (num1 !=-1) && (num2 == -1) ) {
			outputArea->SetCurrentColor(mircToQColor(num1));
		    } else if ( (num1 == -1) && (num2 == -1) ) {
 		       outputArea->SetCurrentColor(c);
		       outputArea->SetCurrentBgColor(bgc);
		    }
		    i--;
		    break;
                default:
                    //kdebug(KDEBUG_WARN, 4016, "Unknown control character: %d", s[i]);
                    str += s[i];
            }
            outputArea->SetCurrentFont(f);
        }
        else
               str += s[i];
        i++;
    }
    outputArea->InsertText(str);
    outputArea->UpdateLastRow();
    outputArea->NewLine();
    // now reset to defaults
    f = outputArea->CurrentFont();
    f.setBold(FALSE);
    f.setUnderline(FALSE);
    outputArea->SetCurrentFont(f);
    outputArea->SetInverse(FALSE);
    
    if (Settings::debug)
        kdebug(KDEBUG_INFO, 4016, "for the hell of it: %s", s.data());
}

void IrcWindow::resizeEvent ( QResizeEvent * )
{
    int windowWidth = width();
    commandArea->setGeometry ( 0, (height() - COMMAND_AREA_HEIGHT ),
                               windowWidth,
                               COMMAND_AREA_HEIGHT );
    outputArea->setGeometry(0,0,windowWidth, height()-COMMAND_AREA_HEIGHT );
}

void IrcWindow::HandleFocus()
{
    commandArea->setFocus();
}

void IrcWindow::UpdateCaption()
{
    if (!caption())
    setCaption(name());
}
        
void IrcWindow::ScreenInput(const char *newText)
{
    if ((QString(newText)).right(1) == "\n") // wait for an endline, then process command
        HandleCommand();
}

void IrcWindow::HandleCommand( )
{
    QString text = commandArea->text();
    commandArea->setText(NULL); // now clear our minds like a table...
    // if (text.right(2) == "\r\n")
    if (text != "" && text != "\n")
        ParseInput((const char *)text);    
}


void IrcWindow::ParseInput (const char *input)
{
    if (input[0] == '/')
    {
        input++;
        IrcApp::HandleEvent(Event::PARSE_INPUT, input, name());
    }
}

void IrcWindow::configureLogging()
{
	KConfig *config = KApplication::getKApplication()->getConfig();
	QString str;
	
	config->setGroup(QString(QString(name()) + "Settings").lower());
	
	if (config->readEntry("Log Name"))
		logFileName = config->readEntry("Log Name");
	
	str = config->readEntry ("Log Enabled");
	if (!str.isNull())
		logEnabled = (atoi(str));
		
	if (logEnabled)
	  logFile=fopen(logFileName,"a");
	
	str = config->readEntry ("Log Internal Messages");
	if (!str.isNull())
		logInternalMessages = (atoi(str));

	str = config->readEntry ("Log Info");
	if (!str.isNull())
		logInfo = (atoi(str));

	str = config->readEntry ("Log Actions");
	if (!str.isNull())
		logActions = (atoi(str));

	str = config->readEntry ("Log Private Messages");
	if (!str.isNull())
		logPrivMessages = (atoi(str));

	str = config->readEntry ("Log Own Text");
	if (!str.isNull())
		logOwn = (atoi(str));

	str = config->readEntry ("Log Channel Chatter");
	if (!str.isNull())
		logChatter = (atoi(str));

	str = config->readEntry ("Log Exclamations");
	if (!str.isNull())
		logExclamation = (atoi(str));

	str = config->readEntry ("Log Server Messages");
	if (!str.isNull())
		logServerMessages = (atoi(str));
}

void IrcWindow::saveConfig()
{
	KConfig *config = KApplication::getKApplication()->getConfig();
	QString str;
	
	config->setGroup(QString(QString(name()) + "Settings").lower());
	//config->setGroup(QString(name()).lower());

	config->writeEntry("Log Name", logFileName);
		
	str.sprintf("%d",logEnabled);
	config->writeEntry("Log Enabled", str);
	
	str.sprintf("%d",logInternalMessages);
	config->writeEntry("Log Internal Messages", str);	

	str.sprintf("%d",logInfo);
	config->writeEntry("Log Info", str);
	
	str.sprintf("%d",logActions);
	config->writeEntry("Log Actions", str);
	
	str.sprintf("%d", logPrivMessages);
	config->writeEntry("Log Private Messages",str);
	
	str.sprintf("%d", logOwn);
	config->writeEntry("Log Own Text", str);
	
	str.sprintf("%d", logChatter);
	config->writeEntry("Log Channel Chatter", str);
	
	str.sprintf("%d", logExclamation);
	config->writeEntry("Log Exclamations", str);
	
	str.sprintf("%d", logServerMessages);
	config->writeEntry("Log Server Messages", str);
	
	config->sync();
}

void IrcWindow::Configure()
{
	IrcWindowConfig *dialog = new IrcWindowConfig(this, name());
	kdebug(KDEBUG_INFO, 4016, "Configure called");
	dialog->exec();
	dialog->close();
	delete dialog;
	saveConfig();
	configureLogging();
}

void IrcWindow::AddToLog(const char *text)
{
  if (!logFile)
	return;
  fprintf(logFile,"[%s][%s] %s\n",
	QTime::currentTime().toString().data(),name(), text);
  fflush(logFile);
}

QColor IrcWindow::mircToQColor (int color)
{
	switch (color) {
		case 0:
			return QColor(white);
			break;
		case 1:
			return QColor(black);
			break;
		case 2:
			return QColor(darkBlue);
			break;
		case 3:
			return QColor(darkGreen);
			break;
		case 4:
			return QColor(darkRed);
			break;
		case 5:
			return QColor(yellow);  // FIXME: Should be a good brown color
			break;
		case 6:
			return QColor(darkMagenta);
			break;
		case 7:
			return QColor(red);
			break;
		case 8:
			return QColor(yellow);
			break;
		case 9:
			return QColor(green);
			break;
		case 10:
			return QColor(darkCyan);
			break;
		case 11:
			return QColor(cyan);
			break;
		case 12:
			return QColor(blue);
			break;
		case 13:
			return QColor(magenta);
			break;
		case 14:
			return QColor(darkGray);
			break;
		case 15:
			return QColor(gray);
			break;
		default:
			return QColor(black);
			break;
	}
	return QColor(black);
}

#include "ircwindow.moc"
