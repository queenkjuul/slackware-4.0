/**********************************************************************

	--- Dlgedit generated file ---

	File: ServerOptions.cpp
	Last generated: Mon Aug 4 01:29:32 1997

 *********************************************************************/

#include "ServerOptions.h"

#define Inherited ServerOptionsData

ServerOptions::ServerOptions
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
}


ServerOptions::~ServerOptions()
{
}
