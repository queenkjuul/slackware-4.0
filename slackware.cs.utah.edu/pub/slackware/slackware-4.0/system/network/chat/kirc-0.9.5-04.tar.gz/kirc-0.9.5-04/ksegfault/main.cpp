//main.cpp
//Aaron Granick

#include <iostream.h>

#include <qstring.h>

#include <kapp.h>
#include <kmsgbox.h>


QString appName;
QString extraText="";

void ParseArguments ( int &argc, char **argv )
{
    if (argc < 2)
    {
        warning("Useage: ksegfault [appname] [extra text]");
        exit (0);
    }

    appName = argv[1];
    for ( int i = 2; i < argc; i ++)
    {
        extraText += argv[i];
        extraText += " "; // manually add the space
    }// end for
}

int main( int argc, char **argv)
{
    ParseArguments(argc, argv);
    KApplication app(argc, argv);
    QString out(extraText.length() + 512); // this should be enough
    out.sprintf("This program has received a segmentation fault signal, and will be terminated.\n%s", \
                extraText.data());
    if (KMsgBox::message(0, appName, out.data(), KMsgBox::EXCLAMATION))
        exit(0);
    return app.exec();
}
