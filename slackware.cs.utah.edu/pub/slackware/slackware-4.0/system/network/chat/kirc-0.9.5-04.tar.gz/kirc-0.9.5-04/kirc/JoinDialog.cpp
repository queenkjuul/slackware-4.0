/**********************************************************************

	--- Dlgedit generated file ---

	File: JoinDialog.cpp
	Last generated: Wed Aug 6 00:45:38 1997

 *********************************************************************/

#include "JoinDialog.h"
#include "JoinDialogData.moc"
#include "JoinDialog.moc"

#define Inherited JoinDialogData

JoinDialog::JoinDialog
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
    setCaption("Join Channel");
    channelEdit->setFocus();
    okButton->setDefault(true);
}

const char *JoinDialog::Channel()
{
    return channelEdit->text();
}

void JoinDialog::slotJoinChannel()
{
    accept();
}

JoinDialog::~JoinDialog()
{
}
