/**********************************************************************

	--- Qt Architect generated file ---

	File: ClientOptions.h
	Last generated: Sat Mar 7 16:53:24 1998

 *********************************************************************/

#ifndef ClientOptions_included
#define ClientOptions_included

#include "ClientOptionsData.h"

class ClientOptions : public ClientOptionsData
{
    Q_OBJECT

public:

    ClientOptions
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~ClientOptions();
    void SaveAll();
};
#endif // ClientOptions_included
