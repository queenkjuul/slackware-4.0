#include <qregexp.h>
#include <qstring.h>

#include "irc.h"
#include "client.h"
#include "identifiers.h"

QString ExpandIdentifiers(
	QString text,
	QString nick,
	QString chan,
	QString rest)
{
int i=0;
QRegExp reg;
QString temp, ret, args;
ret = QString(text);
if (rest)
  args = QString(rest);
else
  args = QString("");

// %nick
if (!nick)
  temp = QString("");
else
  temp = QString(nick);
reg = QRegExp("%nick");
ret.replace(reg, temp.data());

// %channel and %chan
if (!chan)
  temp = QString("");
else
  temp = QString(chan);
reg = QRegExp("%channel");
ret.replace(reg, temp.data());
reg = QRegExp("%chan");
ret.replace(reg, temp.data());

// %server (server name)
reg = QRegExp("%server");
ret.replace(reg, Settings::serverName);

// %mynick (Current nickname)
reg = QRegExp("%mynick");
ret.replace(reg, Settings::myNick);

// %port (server port)
reg = QRegExp("%port");
temp.sprintf("%d", Settings::serverPort);
ret.replace(reg, temp);

// %rest
reg = QRegExp("%rest");
ret.replace(reg, args.data());


// Individual args
while (args.find(" ") != -1) {
	i++;
	temp.sprintf("%%%d", i);
	reg = QRegExp(temp.data());
	ret.replace(reg, args.left(args.find(" ")).data());

	temp.sprintf("%%arg%d", i);
	reg = QRegExp(temp.data());
	ret.replace(reg, args.left(args.find(" ")).data());

	args.remove(0, args.find(" ")+1);
}
i++;
temp.sprintf("%%%d", i);
reg = QRegExp(temp.data());
ret.replace(reg, args.left(args.find(" ")).data());

temp.sprintf("%%arg%d", i);
reg = QRegExp(temp.data());
ret.replace(reg, args.left(args.find(" ")).data());

return ret.copy();
}
