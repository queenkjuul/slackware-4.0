#ifndef MESSAGES_H
#define MESSAGES_H

class Message : public QString
{
public:
    Message(const char *txt=0, int type=Output::NORMAL);
    int Type(); // returns the message type
private:
    int type;
};

class MessageSender : public QObject
{
public:
    MessageSender(QObject *parent=0, const char *name=0);
public slots:
    void AddMessage(int type, const char *txt); 
private:
    QList<Message> *messages;
};

class MessageList : public MDIWindow
{
public:
    MessageList(QObject *parent=0, const char *name=0);
public slots:
    void NewMessage(int type, const char *sender, const char *txt);
private:
    QListBox *listBox;
    QList<MessageSender> *people;
protected:
    void resizeEvent(QResizeEvent *);
};


#endif
