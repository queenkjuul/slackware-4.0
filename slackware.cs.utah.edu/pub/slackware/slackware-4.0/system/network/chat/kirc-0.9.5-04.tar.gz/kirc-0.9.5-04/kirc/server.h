//server.h
//handles socket connections, messages to server
//Aaron Granick

#ifndef _SERVER_H_
#define _SERVER_H_

#include "user.h"
#include "irc.h"
#include <qsocknot.h>


class Server : public QObject {
    Q_OBJECT
public:
    Server ( QObject *parent =0, const char *serverName=0, int serverPort=DEFAULT_PORT);	// with more info
    void SetPort ( int p ) { port = p; }
    int Port () { return port; }
public slots:
    int Connect ( );	// connect to the server
    void Disconnect (const char *);
    bool isConnected() { return connected; }
    int Send ( const char * ); // send a message to the server
    void ReadData ();
    void WriteData ();
protected:
    void ParseNumeric( int, char*, char*);
    void ParseWord( char*, char*, char*);  

    // Numeric messages
    void handleNickInUse( char *, char *);
    void handleStandardNumeric( char *, char *);
    void handleAmountNumeric( char *, char *);
    void handleNoColon( char *, char *);
    void handleOperator( char *, char *);
    void handleIsOn( char *, char *);
    void handleLinks( int, char *, char *);
    void handleList(int, char *, char *);
    void handleWhois( int, char *, char *);
    
    // Numeric channel messages
    void handleChannelTopic( int, char *);
    void handleNicklist( char *, char *);
    void handlePrivmsg( char *, char *, char *, char *);
    void handlePart( char *, char *, char *);
    void handleKick( char *, char *, char *, char *);
    void handleNick( char *, char *);
    void handleQuit( char *, char *);
    void handleMode( char *, char *);
    void handleTopic( char *, char *, char *);
    void handleInvite(char *, char *);
private:
    bool registered;
    bool connected; // holds connnection state
    void ProcessData( const char *);
    int port;	// server port
    QString address;
    QString group;
    QSocketNotifier *rsn, *wsn; //socket notifiers make our job MUCH easier   
    QString incomplete; // sometimes lag means we don't get the whole thing
// signals:
//     void SendEvent( int type, const char *data );
//     void SendEvent ( int type, const char *data1, const char *data2);
//     void SendToWindow ( int type, const char *win, const char *dat );
//     void TakeABreak(); // emit to allow windows to be redrawn, etc.  If we were running threaded we wouldn't need this
};

#endif

