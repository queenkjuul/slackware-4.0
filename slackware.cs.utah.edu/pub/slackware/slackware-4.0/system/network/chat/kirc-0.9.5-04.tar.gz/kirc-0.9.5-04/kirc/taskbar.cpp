//$Id: taskbar.cpp,v 1.8 1997/12/12 13:47:12 parallax Exp $

#include "taskbar.h"
#include "ircwindow.h"
#include "ircapp.h"
#include <qstrlist.h>

const int BORDER = 0;
const int STATUS_HEIGHT= 20;
#define BUTTON_HEIGHT 20

#define ID_WHOIS 4
#define ID_QUERY 5
#define ID_PING 6
#define ID_PART 7
#define ID_CLOSE 8
#define ID_VERSION 9
#define ID_ADD_TO_NOTIFY 10
#define ID_REMOVE_FROM_NOTIFY 11

TaskBar::TaskBar ( QWidget *parent, const char *name )
        : QFrame (parent, name)
{
//    setFrameStyle(QFrame::WinPanel | QFrame::Raised);
//    buttons = new QList<TaskBarButton>();
    mainFrame = new QFrame(this, "main frame");
    //  mainFrame->setFrameStyle(QFrame::WinPanel | QFrame::Sunken);
    channelLabel = new QLabel(mainFrame, "window label");
    channelLabel->setFrameStyle(QFrame::Box | QFrame::Sunken);
    notifyLabel = new QLabel(mainFrame, "notify label");
    notifyLabel->setFrameStyle(QFrame::Box | QFrame::Sunken);
    channelLabel->setText("Channels");
    channels = new ColorListBox(mainFrame, "channels");
    connect(channels, SIGNAL(highlighted(const char *)), SLOT(SlotSelectWindow(const char *)));
    connect(channels, SIGNAL(highlighted(const char *)), SLOT(ChannelsSelected(const char *)));

    channelsPopup = new KPopupMenu();
    SetupChannelsPopup();    

    notifyList = new ColorListBox(mainFrame, "notify List");
    notifyLabel->setText("Notify List");
    notifyPopup = new KPopupMenu();
    notifyPopup->insertItem("Whois", ID_WHOIS);
    notifyPopup->insertItem("Query", ID_QUERY);
    notifyPopup->insertItem("Ping", ID_PING);
    notifyPopup->insertItem("Version", ID_VERSION);
    notifyPopup->insertItem("Remove from notify", ID_REMOVE_FROM_NOTIFY);
    connect(notifyList, SIGNAL(Popup()), SLOT(ShowPopup()));
    connect(notifyPopup, SIGNAL(activated(int)), SLOT(PopupItemSelected(int)));
    
    messagesLabel = new QLabel(mainFrame, "mesages label");
    messagesLabel->setFrameStyle(QFrame::Box | QFrame::Sunken);
    messagesLabel->setText("Messages");
    messages = new ColorListBox(mainFrame, "messages");
    connect(messages, SIGNAL(highlighted(const char *)), SLOT(SlotSelectWindow(const char *)));
    connect(messages, SIGNAL(highlighted(const char *)), SLOT(MessagesSelected(const char *)));
    messagesPopup = new KPopupMenu();
    messagesPopup->insertItem("Whois", ID_WHOIS);
    messagesPopup->insertItem("Ping", ID_PING);
    messagesPopup->insertItem("Version", ID_VERSION);
    messagesPopup->insertItem("Add to notify", ID_ADD_TO_NOTIFY);
    messagesPopup->insertItem("Close", ID_CLOSE);
    connect(messages, SIGNAL(Popup()), SLOT(ShowPopup()));
    connect(messagesPopup, SIGNAL(activated(int)), SLOT(PopupItemSelected(int)));
//    buttons->setAutoDelete(true);
}

void TaskBar::ApplyTheme()
{
    IrcApp::SetThemeProperties(messages, Settings::theme.taskBar);
    IrcApp::SetThemeProperties(channels, Settings::theme.taskBar);
    IrcApp::SetThemeProperties(notifyList, Settings::theme.taskBar);
}

void TaskBar::AddWindow ( MDIWindow *w )
{
    IrcWindow *iw = (IrcWindow *)(w->Child());
    if (iw->inherits("Channel"))
        channels->insertItem(w->name());
    else if (iw->inherits("MessageWindow"))
        messages->insertItem(w->name());

    connect(w, SIGNAL(Closed(MDIWindow *)), SLOT(RemoveWindow(MDIWindow*)));
    connect(w, SIGNAL(Selected(MDIWindow *)), SLOT(HandleFocus(MDIWindow *)) );
    connect(w, SIGNAL(Minimized(MDIWindow *)), SLOT(HandleMinimize(MDIWindow *)) );
}

void TaskBar::UpdateNotify(const char *l)
{
    QStrList list;
    QString str(l);
    int s = str.find(' ');
    while (s != -1)
    {
        QString tmp = str.left(s);
        str.remove(0, s+1);
        list.append(tmp.data());
        s = str.find(' ');
    }
    if (!str.isEmpty())
        list.append(str.data());
    notifyList->setAutoUpdate(FALSE);
    QString selected = notifyList->text(notifyList->currentItem());
    notifyList->clear();
    notifyList->insertStrList(&list);
    int i = Util::FindListBoxItem(notifyList, selected);
    notifyList->setCurrentItem(i);
    notifyList->setAutoUpdate(TRUE);
    notifyList->repaint();
}

void TaskBar::resizeEvent (QResizeEvent *)
{
    // RecreateLayout();
    QRect r = contentsRect();
    mainFrame->setGeometry(r.x(), r.y(),  r.width(), r.height());
    r = mainFrame->contentsRect();
    channelLabel->setGeometry(r.x(), r.y(), r.width(), 20);
    channels->setGeometry(r.x(), r.y() + channelLabel->height(), r.width(), \
                            (r.height()/3)-channelLabel->height());
    messagesLabel->setGeometry(r.x(), channels->y() + channels->height(), r.width(), 20);
    messages->setGeometry(r.x(), messagesLabel->y() + messagesLabel->height(), r.width(), \
                            r.height()/3 - messagesLabel->height());
    notifyLabel->setGeometry(r.x(), messages->y() + messages->height(), r.width(), 20);
    notifyList->setGeometry(r.x(), notifyLabel->y() + notifyLabel->height(), r.width(), \
                         r.height() - notifyLabel->y() - notifyLabel->height());
   
}

void TaskBar::RemoveWindow ( MDIWindow *w )
{
    IrcWindow *iw = (IrcWindow *)(w->Child());
    QListBox *lb;
    if (iw->inherits("Channel"))
        lb = channels;
    else if (iw->inherits("MessageWindow"))
        lb = messages;
    else
        return;
    Util::RemoveListBoxItem(lb, iw->name());
}

void TaskBar::UpdateName(MDIWindow *w)
{
   IrcWindow *iw = (IrcWindow *)(w->Child());
   QListBox *lb;
   if (iw->inherits("Channel"))
       lb = channels;
   else if (iw->inherits("MessageWindow"))
       lb = messages;
   else
       return;
   int i = Util::FindListBoxItem(lb, iw->name());
   lb->changeItem(iw->name(), i);
}

void TaskBar::SlotSelectWindow(const char *n)
{
    emit SelectWindow(n);
}

void TaskBar::HandleFocus(MDIWindow *w)
{
    IrcWindow *iw = (IrcWindow *)(w->Child());
    QListBox *lb;
    if (iw->inherits("Channel"))
        lb = channels;
    else if (iw->inherits("MessageWindow"))
        lb = messages;
    else
    {
        // must be the console
        channels->setSelected(channels->currentItem(), 0);
        messages->setSelected(messages->currentItem(), 0);
        return;
    }
    int i = Util::FindListBoxItem(lb, iw->name());
    lb->setCurrentItem(i);
}

void TaskBar::HandleMinimize(MDIWindow *w)
{
    QString n = w->name();
    if (n.lower() == QString(channels->text(channels->currentItem())).lower())
    {        
        channels->setSelected(channels->currentItem(), 0);
        return;
    }
    if (n.lower() == QString(messages->text(messages->currentItem())).lower())
    {        
        messages->setSelected(messages->currentItem(), 0);
        return;
    }
}

void TaskBar::MessagesSelected(const char *)
{
    channels->setSelected(channels->currentItem(), 0);
}

void TaskBar::ChannelsSelected(const char *)
{
    messages->setSelected(messages->currentItem(), 0);
}

void TaskBar::ShowPopup()
{
    QPoint pt = QCursor::pos();
    if (sender() == notifyList)
    {
        notifyPopup->setTitle(notifyList->text(notifyList->currentItem()));
        notifyPopup->popup(pt);
    }
    else if (sender() == messages)
    {
        messagesPopup->setTitle(messages->text(messages->currentItem()));
        messagesPopup->popup(pt);
    }
    else if (sender() == channels)
     {
         if (!channelsPopup)
	   SetupChannelsPopup();
         channelsPopup->setTitle(channels->text(channels->currentItem()));
         channelsPopup->popup(pt);
     }
}

void TaskBar::SetupChannelsPopup(const char *filename)
{
	keys = new QList<QString>();
	if (channelsPopup)
		delete channelsPopup;
	channelsPopup = new KPopupMenu();
	channelsPopup->setTitle(channels->text(channels->currentItem()));
        channelsPopup->insertItem("Part", ID_PART);
        channelsPopup->insertItem("Ping", ID_PING);
        channelsPopup->insertItem("Version", ID_VERSION);
	channelsPopup->insertSeparator(-1);
        connect(channels, SIGNAL(Popup()), SLOT(ShowPopup()));
        connect(channelsPopup, SIGNAL(activated(int)), SLOT(PopupItemSelected(int)));
	chanPopupList = Alias::LoadAliasList(IrcApp::GetFile(Settings::chanPopupsFile), 97, keys);
	if (!chanPopupList)
		return;
	QPopupMenu *subMenu = NULL;
	int iD = 0;
	for ( QString *a=keys->first(); a!=0; a=keys->next()) {
          QString str = a->copy();
          if (str.left(1) == ".") {
            str.remove(0, 1); // get rid of the .
            if (str.isEmpty()) // just a '.' means end of menu
            {
                channelsPopup->insertItem(subMenu->name(), subMenu, iD);
                subMenu = NULL;
            }
            else
            {
                if (subMenu)
                    subMenu->insertItem(str, iD);
                else
                    channelsPopup->insertItem(str, iD);
            }
          }
          else {
            if (subMenu)
                channelsPopup->insertItem(subMenu->name(), subMenu, iD);
            subMenu = new QPopupMenu(NULL, str);
	    connect(subMenu, SIGNAL(activated(int)), SLOT(ChanPopupSelected(int)));
          }
          iD++;
        }
     if (subMenu)
        channelsPopup->insertItem(subMenu->name(), subMenu);
}

void TaskBar::ChanPopupSelected(int id)
{
    if (!channelsPopup)
    {
        kdebug(KDEBUG_ERROR, 4019, "Attempt to call Channel::PopupSelected(int) with NULL popupList.");
        return;
    }
    QString key = *(keys->at(id));
    QString str;
    str.sprintf("%s", chanPopupList->find(key));
    if (str.left(1) == "/")
	str.remove(0,1);
    IrcApp::HandleEvent(Event::PARSE_INPUT, str, channels->text(channels->currentItem()));
}

void TaskBar::PopupItemSelected(int id)
{
    QString out, target;
    if (sender() == notifyPopup)
        target = notifyPopup->title();
    else if (sender() == messagesPopup)
        target = messagesPopup->title();
    else if (sender() == channelsPopup)
        target = channelsPopup->title();
    else
        return;
    
    switch(id)
    {
        case ID_WHOIS:
            out.sprintf("WHOIS %s", target.data());
            break;
        case ID_QUERY:
            out.sprintf("QUERY %s", target.data());
            break;
        case ID_PING:
            out.sprintf("PING %s", target.data());
            break;
        case ID_PART:
            out.sprintf("PART %s", target.data());
            break;
        case ID_CLOSE:
            out.sprintf("CLOSE %s", target.data());
            break;
        case ID_VERSION:
            out.sprintf("CTCP %s VERSION", target.data());
            break;
        case ID_ADD_TO_NOTIFY:
            out.sprintf("NOTIFY add %s", target.data());
            break;
        case ID_REMOVE_FROM_NOTIFY:
            out.sprintf("NOTIFY REMOVE %s", target.data());
            break;
    }
    if (!out.isEmpty())
        IrcApp::HandleEvent(Event::PARSE_INPUT, out); 
}
    
#include "taskbar.moc"
