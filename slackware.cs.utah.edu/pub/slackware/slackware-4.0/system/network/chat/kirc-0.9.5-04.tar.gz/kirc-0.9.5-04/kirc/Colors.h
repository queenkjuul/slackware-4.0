/**********************************************************************

	--- Dlgedit generated file ---

	File: Colors.h
	Last generated: Tue Nov 4 17:26:05 1997

 *********************************************************************/

#ifndef Colors_included
#define Colors_included

#include "ColorsData.h"

class Colors : public ColorsData
{
    Q_OBJECT

public:

    Colors
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~Colors();

};
#endif // Colors_included
