//ircuser.cpp
//irc user class
//Aaron Granick

#include "user.h"
#include <string.h>
#include <iostream.h>

User::User ( QString nk, QString inf, QString nm )
{
    nick = nk;
    info = inf;
    nm = name;
}

		
		
	

	
		
		


