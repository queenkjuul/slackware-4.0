/**********************************************************************

	--- Dlgedit generated file ---

	File: DCCOptions.h
	Last generated: Tue Nov 4 21:48:16 1997

 *********************************************************************/

#ifndef DCCOptions_included
#define DCCOptions_included

#include "DCCOptionsData.h"

class DCCOptions : public DCCOptionsData
{
    Q_OBJECT

public:

    DCCOptions
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~DCCOptions();
 public slots:
    void SaveAll();

};
#endif // DCCOptions_included
