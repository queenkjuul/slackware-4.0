// this file contains various settings which can be tweaked if it doesn't
// work quite right

#ifndef IRC_CONFIG_H
#define IRC_CONFIG_H

#define APPNAME			"kIRC"
#define IRCDIR			"share/apps/kirc"
#define ICONDIR			"share/apps/kirc/icons"
#define IRCHOMEDIR		".kde/share/apps/kirc"
#define DEFAULT_NICK		"kircuser"
#define DEFAULT_SECONDARY_NICK	"kircuser_"
#define DEFAULT_USER_NAME	"beavis"
#define DEFAULT_REAL_NAME	"I am using kirc, but not very well"
#define DEFAULT_PORT		6667
#define DEFAULT_SERVER		"irc.phoenix.net"
#define DEFAULT_QUIT_REASON	"Leaving."
#define DEFAULT_KICK_REASON	"kIRC baby!"
#define DEFAULT_VERSION_REPLY	"Boredom offramp"
#define DEFAULT_ALIASES_FILE	"aliases"
#define DEFAULT_SERVERS_FILE	"servers"
#define DEFAULT_STARTUP_FILE	"startup"
#define DEFAULT_NICK_COMPLETION	"Normal"
#define DEFAULT_THEME_FILE	"themes/default"
#define CONSOLENAME		"- Console -" // this should have spaces in it so it isn't confused with nicks/channels
#define ALIAS_HASH_SIZE		199  // MUST be a prime number

#define DEFAULT_NICK_POPUPS_FILE	"nick.popups"
#define DEFAULT_CHAN_POPUPS_FILE	"chan.popups"

#endif
