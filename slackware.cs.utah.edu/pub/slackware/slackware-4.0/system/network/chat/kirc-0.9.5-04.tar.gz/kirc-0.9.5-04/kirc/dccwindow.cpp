//$Id: dccwindow.cpp,v 1.3 1997/11/30 03:41:31 parallax Exp $

#include "dccwindow.h"
#include "ircapp.h"

DCCWindow::DCCWindow(QWidget *p, const char *n)
        : MessageWindow(p, n)
{

}

DCCWindow::~DCCWindow()
{
    IrcApp::HandleEvent(Event::CLOSE_DCC_CHAT, name());
}

void DCCWindow::UpdateCaption()
{
    QString c;
    c.sprintf("DCC chat with %s", name());
    setCaption(c);
}

void DCCWindow::ParseInput(const char *input)
{
    QString inp(input);
    // special handling for actions
    if (inp.left(4).lower() == "/me ")
    {
        inp.remove(0, 4);
        QString out(512);
        out.sprintf("%s %s", Settings::myNick.data(), inp.data());
        Output(out, Output::ACTION);
        out = "";
        out.sprintf("%cACTION %s%c\n", 0x01, inp.data(), 0x01);
        IrcApp::HandleEvent(Event::OUTPUT_DCC_CHAT, name(), out);
        return;
    }
    if (input[0] == '/')
        MessageWindow::ParseInput(input);
    else
    {
        QString out(512);
        out.sprintf("<%s> %s", Settings::myNick.data(), input);
        Output(out, Output::OWN);
        out = input;
        out += "\n";
        IrcApp::HandleEvent(Event::OUTPUT_DCC_CHAT, name(), out);
    }
}

#include "dccwindow.moc"
