//$Id: dccwindow.h,v 1.1 1997/11/30 02:15:57 parallax Exp $
#ifndef DCC_WINDOW_H
#define DCC_WINDOW_H

#include "message.h"

class DCCWindow : public MessageWindow
{
    Q_OBJECT
public:
    DCCWindow(QWidget *parent=0, const char *name=0);
    virtual ~DCCWindow();
public slots:
    virtual void ParseInput(const char *);
    virtual void UpdateCaption();
};

#endif
