//$Id: colorlistbox.h,v 1.2 1997/12/01 05:49:48 parallax Exp $
#ifndef COLOR_LIST_BOX
#define COLOR_LIST_BOX

#include <qlistbox.h>

class ColorListBox : public QListBox
{
    Q_OBJECT
public:
    ColorListBox(QWidget *parent=0, const char *name=0);
signals:
    void Popup();
protected:
    virtual void paintEvent(QPaintEvent *);
    virtual void setBackgroundPixmap(const QPixmap &p) { bgPixmap = p; }
    virtual void paintCell(QPainter *, int row, int);
    void mousePressEvent(QMouseEvent *);
    void DrawBackground(QPainter *, int row);
private:
    QPixmap bgPixmap;
};
#endif
