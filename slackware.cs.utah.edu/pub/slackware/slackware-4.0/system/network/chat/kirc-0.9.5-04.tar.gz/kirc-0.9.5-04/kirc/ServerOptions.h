/**********************************************************************

	--- Dlgedit generated file ---

	File: ServerOptions.h
	Last generated: Mon Aug 4 01:29:32 1997

 *********************************************************************/

#ifndef ServerOptions_included
#define ServerOptions_included

#include "ServerOptionsData.h"

class ServerOptions : public ServerOptionsData
{
    Q_OBJECT

public:

    ServerOptions
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~ServerOptions();

};
#endif // ServerOptions_included
