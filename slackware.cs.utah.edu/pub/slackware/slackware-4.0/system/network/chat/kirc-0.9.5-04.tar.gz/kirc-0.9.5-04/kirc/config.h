//$Id: config.h,v 1.1 1997/11/24 10:13:16 parallax Exp $
//$Log: config.h,v $
//Revision 1.1  1997/11/24 10:13:16  parallax
//Added class Config-doesn't work yet
//

#include <qdict.h>
#include <qfile.h>
#include <qtstream.h>
#include <qstring.h>

typedef QDict<char> CharDict;

class Config
{
public:
    Config (const char *filename);
    void GetConfig();
    void SetGroup(const char *grp);
    void WriteEntry(const char *buff1, const char *buff2);
    const char *ReadEntry(const char *);
private:
    QDict<CharDict> *dict;
    QString fileName;
};
    
