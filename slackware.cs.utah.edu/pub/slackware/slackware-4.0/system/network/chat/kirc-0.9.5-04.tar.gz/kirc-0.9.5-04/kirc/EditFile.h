/**********************************************************************

	--- Dlgedit generated file ---

	File: EditFile.h
	Last generated: Thu Aug 7 11:28:21 1997

 *********************************************************************/

#ifndef EditFile_included
#define EditFile_included

#include "EditFileData.h"
#include <qstring.h>

class EditFile : public EditFileData
{
    Q_OBJECT

public:

    EditFile
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~EditFile();
    void setFileName ( QString nm );
    QString getFileName () { return fileName; }
    
protected slots:

    virtual void slotClear();
    virtual void slotSave();
    virtual void slotBrowse();
    virtual void slotFileNameChanged();
    virtual void slotReload();
    
private:
    QString fileName;
};
#endif // EditFile_included
