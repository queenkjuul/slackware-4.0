/**********************************************************************

	--- Dlgedit generated file ---

	File: Colors.cpp
	Last generated: Tue Nov 4 17:26:05 1997

 *********************************************************************/

#include "Colors.h"

#define Inherited ColorsData

Colors::Colors
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
}


Colors::~Colors()
{
}
