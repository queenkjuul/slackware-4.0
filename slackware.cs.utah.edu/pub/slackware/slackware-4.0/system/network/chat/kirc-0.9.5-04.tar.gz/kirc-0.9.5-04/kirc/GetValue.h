/**********************************************************************

	--- Dlgedit generated file ---

	File: GetValue.h
	Last generated: Thu Nov 6 00:08:29 1997

 *********************************************************************/

#ifndef GetValue_included
#define GetValue_included

#include "GetValueData.h"

class GetValue : public GetValueData
{
    Q_OBJECT

public:

    GetValue
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~GetValue();
    void SetLabel(const char *txt);
    const char *Value();
protected slots:
    void slotReturnPressed();
private:
    QString value;
};
#endif // GetValue_included
