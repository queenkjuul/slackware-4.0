//$Id: theme.cpp,v 1.4 1997/11/24 21:12:05 parallax Exp $
#include <qfile.h>
#include <qdir.h>
#include "theme.h"

void Error(int line, const char *err)
{
    warning("LoadTheme: Parse error at line %d.(%s)", line, err);
}

void ParseObject(const char *txt, const char *value, ThemeObject *obj)
{
    QString str(txt);
    if (str == "backgroundPic")
        obj->backgroundPic = value;
    else if (str == "backgroundColor")
        obj->backgroundColor = value;
    else if (str == "baseColor")
        obj->baseColor = value;
    else if (str == "widgetPic")
        obj->widgetPic = value;
    else if (str == "widgetColor")
        obj->widgetColor = value;
    else if (str == "textColor")
        obj->textColor = value;
    else if (str == "fontFamily")
        obj->fontFamily = value;
    else if (str == "fontSize")
        obj->fontSize = value;
    else if (str == "fontWeight")
        obj->fontWeight = value;
    else if (str == "isItalic")
        obj->isItalic = value;
    else if (str == "style")
        obj->style = value;
    else if (str == "icon")
        obj->icon = value;
    else
        warning("LoadTheme: invalid type: %s", str.data());
}       

Theme::Theme(const char *n)
{
    name = n;
}

const char *Theme::Name()
{
    return name;
}
   
    
bool Theme::Load(const char *filename)
{
    QFile file(filename);
    QDir dir(filename);
    if (dir.exists())
        return false;
    if (!file.open(IO_ReadOnly))
    {
        warning("Could not open theme file %s for reading.", filename);
        return NULL;
    }
    char buff[512];
    int line = 1;
    while (!file.atEnd())
    {
        bzero (buff, 512);
        if (file.readLine(buff, 512) > 0)
        {
            QString str(buff);
            if (!str.isEmpty() && str[0] != '#' && str != "\n")
            {
                int e = str.find('=');
                if (e == -1)
                {
                    Error(line, "no equals sign found.");
                    return false;
                }
                QString part1 = str.left(e);
                str.remove(0, e+1);
                part1 = part1.stripWhiteSpace();
                str = str.stripWhiteSpace();
                int period = part1.find('.');
                QString obj;
                if (period == -1)
                {
                    Error(line, "no period found.");
                    return false;
                }
                
                obj = part1.left(period);
                part1.remove(0, period+1);
                if (obj == "app")
                    ParseObject(part1, str, &app);
                else if (obj == "mainWindow")
                    ParseObject(part1, str,  &mainWindow);
                 else if (obj == "mdi")
                    ParseObject(part1, str,  &mdi);
                else if (obj == "taskBar")
                    ParseObject(part1, str, &taskBar);
                else if (obj == "channelWindows")
                    ParseObject(part1, str,  &channelWindows);
                else if (obj == "titleBars")
                    ParseObject(part1, str,  &titleBars);
                else if (obj == "chatArea")
                    ParseObject(part1, str,  &chatArea);
                else if (obj == "nickList")
                    ParseObject(part1, str,  &nickList);
                else if (obj == "commandLine")
                    ParseObject(part1, str,  &commandLine );
                else if (obj == "serverTxt")
                    ParseObject(part1, str,  &serverTxt);
                else if (obj == "ownTxt")
                    ParseObject(part1, str,  &ownTxt);
                else if (obj == "noticeTxt")
                    ParseObject(part1, str,  &noticeTxt);
                else if (obj == "channelEventTxt")
                    ParseObject(part1, str,  &channelEventTxt);
                else if (obj == "privmsgTxt")
                    ParseObject(part1, str,  &privmsgTxt);
                else if (obj == "actionTxt")
                    ParseObject(part1, str,  &actionTxt);
                else if (obj == "internalTxt")
                    ParseObject(part1, str,  &internalTxt);
                else if (obj == "errorTxt")
                    ParseObject(part1, str,  &errorTxt);
                else
                {
                    Error(line, "undefined object type");
                    //return false;
                }
            } // end if string is not empty
        }// end if read string
        line++; // advance to next line
    } // end while file is not empty
    return TRUE;
} // end load theme
