/* $Id$
   kirc Module handling file, by Alex Zepeda <garbanzo@hooked.net>
   */

#ifndef MODULES_H
#define MODULES_H

#include <qobject.h>
#include <qlist.h>
#include <qstring.h>

class Hook {
public:
  Hook(){};
  Hook::Hook(int,QString,void *,QString,int numeric=0);
  ~Hook(){};
  enum {
	// Server hooks
	Action,Command,CTCPReply,DCC,Describe,
	Invite,Join,Kick,ModuleLoad,ModuleUnload,NickChange,
	Notice,Numeric,Part,PrivMsg,PubMsg,Quit,Raw,
	ServerPing,ServerPong,TopicChange,Wallops,

	// General Hooks (ircapp::)
	Registered
  };

  int hook_type, owner, numeric;
  void *func;
  QString descr;

  // For matching
  QString trigger_hostmask;
  QList<QString> trigger_channel;
};

class HookCmd {
public:
  QString cmd;
  void *function;
};

class moduleEnt {
public:
  moduleEnt(const char *);
  ~moduleEnt(){};
  int id;
  QString name;
  QString path;
  void *handle, *unload;
};

class modLoader : public QObject
{
Q_OBJECT
public:
  modLoader();
  ~modLoader(){};
  bool load_module(const char *);
  bool unload_module(int);
  bool unload_module(const char *);
  void * find_symbol(int, const char *);
  void add_hook(Hook *);
  QList<Hook> Hooks;
signals:
  void Loaded_Module(const char *);
protected:
  QList<moduleEnt> modules;
};

typedef int (*Function)();
typedef int (*Function_Exec)(void *);
typedef int (*Function_Hook)(void *);

#endif
