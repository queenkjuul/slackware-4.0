/**********************************************************************

	--- Qt Architect generated file ---

	File: ClientOptions.cpp
	Last generated: Sat Mar 7 16:53:24 1998

 *********************************************************************/

#include <ircapp.h>

#include "ClientOptions.h"
#include "ClientOptions.moc"
#include "ClientOptionsData.moc"

#define Inherited ClientOptionsData

ClientOptions::ClientOptions
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
	chkPublicAway->setChecked(Settings::publicAway);
}


ClientOptions::~ClientOptions()
{
}


void ClientOptions::SaveAll()
{
	Settings::publicAway = chkPublicAway->isChecked();
}
