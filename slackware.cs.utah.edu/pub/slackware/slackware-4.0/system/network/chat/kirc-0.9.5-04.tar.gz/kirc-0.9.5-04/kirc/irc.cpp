//$Id: irc.cpp,v 1.3 1997/11/25 11:46:30 parallax Exp $
#include <qdir.h>
#include "irc.h"
#include "ircapp.h"
#include <iostream.h>
#include <signal.h>
//KDE
#include <kapp.h>

// set flags to defaults
bool Settings::debug = FALSE;
bool Settings::echo = FALSE;
bool Settings::connectAtStart = FALSE;
bool Settings::reconnectOnDisconnect = FALSE;
bool Settings::noShowOptions = FALSE;

bool Settings::logEnabled = false;
QString Settings::logFile = QString("kIRC.log");
bool Settings::logInternal_Message = false;
bool Settings::logNotice = false;
bool Settings::logInfo = false;
bool Settings::logAction = false;
bool Settings::logOwn = false;
bool Settings::logPrivMessage = false;
bool Settings::logExclamation = false;
bool Settings::logError = false;
bool Settings::logServerMessage = false; 
bool Settings::logNormal = false;
bool Settings::logChannel = false;

bool Settings::defaultModeI = false;
bool Settings::defaultModeS = false;
bool Settings::defaultModeW = false;
bool Settings::createDetached = false;
bool Settings::timestamp = true;
bool Settings::autoRejoin = true;
bool Settings::publicAway = true;

QString Settings::primaryNick = DEFAULT_NICK;
QString Settings::secondaryNick = DEFAULT_SECONDARY_NICK;
QString Settings::myNick = Settings::primaryNick.copy();
QString Settings::serverName = DEFAULT_SERVER;
int Settings::serverPort = DEFAULT_PORT;
QString Settings::serverPassword = "";
QString Settings::quitMessage = DEFAULT_QUIT_REASON;
QString Settings::userName = DEFAULT_USER_NAME;
QString Settings::realName = DEFAULT_REAL_NAME;
QString Settings::nickPopupsFile = DEFAULT_NICK_POPUPS_FILE;
QString Settings::chanPopupsFile = DEFAULT_CHAN_POPUPS_FILE;
QString Settings::aliasesFile = DEFAULT_ALIASES_FILE;
QString Settings::startupFile = DEFAULT_STARTUP_FILE;
QString Settings::serverListFile = DEFAULT_SERVERS_FILE;
QString Settings::fileDir = ".";
QString Settings::sysFileDir = "";
QString Settings::nickCompletionExtra = DEFAULT_NICK_COMPLETION;
QString Settings::defaultKickReason = DEFAULT_KICK_REASON;
QString Settings::versionReply = NULL;
QString Settings::notifyList = "";
QString Settings::themeFile = DEFAULT_THEME_FILE;
Theme Settings::theme;

//DCC options
bool Settings::dccAutoGet = FALSE;
QString Settings::dccDirectory = QDir::homeDirPath();

int Util::FindListBoxItem(QListBox *lb, const char *txt)
{
    for (unsigned int i=0; i< lb->count(); i++)
    {
        if (QString(txt).lower() == QString(lb->text(i)).lower())
            return i;
    }
    return -1;
}

void Util::RemoveListBoxItem(QListBox *lb, const char *txt)
{
    int i = Util::FindListBoxItem(lb, txt);
    if (i != -1)
    {
        lb->removeItem(i);
    }
}

void ParseArguments ( int &argc, char **argv )
{
    for ( int i = 1; i < argc; i ++)
    {
        if (!strcmp (argv[i], "-?") || !strcmp(argv[i], "-h"))
        {
            warning("%s takes the following command line parameters:", APPNAME);
            warning("-debug: prints debugging information.");
            warning("-echo: echos server messages to stdout.");
            exit (0);
        }
       
        if (!strcmp(argv[i], "-debug"))
        {
            Settings::debug = TRUE;
            warning("Printing debug information.");
            goto ok;
        }
        if (!strcmp(argv[i], "-echo"))
        {
            Settings::echo = TRUE;
            warning("Echoing to stdout.");
            goto ok;
        }
      
        // if we got here, something is wrong
        warning("Bad command line parameter.  Try -h or -? for listing of commands.");
        exit (0);

      ok:		
        // we are ok
        ;    
    }// end for
}

// cool little segfault handler
void HandleSegFault(int)
{
    warning("%s  has received a segmentation fault.  If you believe"\
            " this is due to a bug, \nemail garbanzo@hooked.net"\
            " with a complete bug report (preferably with a"\
            " gdb backtrace).\nYou can also try running %s"\
            " with the -echo or -debug flags to pinpoint the bug.", APPNAME, APPNAME);
    // now try to popup a little note
    QString out(512);
    out.sprintf("ksegfault %s   \"email Aaron Granick at parallax@ucsd.edu with a complete bug report,"\
                "preferably with a gdb backtrace.\nYou can also try running %s with the -echo or -debug flags"\
                "to pinpoint the bug\"", APPNAME, APPNAME);
   system(out.data());
}

IrcApp *app;
int main( int argc, char **argv )
{
    ParseArguments(argc, argv);
    Settings::fileDir.sprintf("%s/%s", QDir::homeDirPath().data(), IRCHOMEDIR);
    Settings::sysFileDir.sprintf("%s/%s", KApplication::kdedir().data(), IRCDIR);
    app = new IrcApp( argc, argv, "kirc");
    //signal (SIGSEGV, HandleSegFault); // redirect our segfaults
    app->Go();
    return app->exec();
}
