#ifndef IRC_WINDOW_H
#define IRC_WINDOW_H

//$Id: ircwindow.h,v 1.5 1997/12/12 13:47:10 parallax Exp $
// IrcWindow is an abstract class that serves as the base for channel, status, and message windows

#include "mdi.h"
#include "output.h"
#include "alias.h"
#include "colorlistbox.h"
#include <qfont.h>
#include <qlined.h>                                                 
#include <qpushbt.h>
#include <qlistbox.h>
#include <qscrbar.h>
#include <qlabel.h>
#include <qmenubar.h>
#include <qpopmenu.h>
#include <qlist.h>
#include <qfile.h>
#include <qlined.h>
//KDE
#include <kpopmenu.h>
#include <kprocess.h>

class IrcWindow;

const int COMMAND_AREA_HEIGHT = 22;              
const int SCROLLBAR_WIDTH = 16;
const int HISTORY_LENGTH = 100;

class CommandEntry : public QLineEdit
{
    Q_OBJECT
public:
    CommandEntry (QWidget *parent=0, const char *name=0);
    virtual ~CommandEntry();
protected:
    void keyPressEvent (QKeyEvent *);
private:
    QList <QString> *history; // command history (like bash)
signals:
    void PageUp();
    void PageDown();
private slots:
    void slotReturnPressed();
};
                                                  
class IrcWindow : public QWidget
{
    Q_OBJECT;
public:
    IrcWindow( QWidget *parent=0, const char *name=0);
    virtual ~IrcWindow();
    MDIWindow *MDIWin() { return mdiWin; }
    int Type() {return type;}
    void AddToLog(const char *);
public: // Data
    enum WindowType {CONSOLE, CHANNEL, MESSAGE, DCC};
    bool logNotices,logInternalMessages,logInfo,logActions,logOwn,logPrivMessages;
    bool logExclamation, logErrors, logServerMessages, logChatter, logEnabled;
    QString logFileName;
signals:
    void RemoveWindow ( const char * );
    void MessageWaiting ( IrcWindow * ); // emitted when the window is minimized, and there is a new message
public slots:
    void Output ( const char *buff, int type ); // output a message in the output area
    void HandleFocus();
    virtual void ParseInput(const char *);
    virtual void ApplyTheme();
    void SetMDIWindow(MDIWindow *);
    void SetMDIThemeProperties();
    void ReceiveOutput(KProcess *, char *, int);
    virtual void UpdateCaption();
    virtual void Configure();
    virtual void saveConfig();
protected slots:
    void ScreenInput(const char *);
    virtual void HandleCommand();
protected:
    virtual void resizeEvent ( QResizeEvent *);	// overload resize event handler
    OutputWidget *outputArea;	// area where channel dialog takes place
    CommandEntry *commandArea;	// whre the user enters commands
    MDIWindow *mdiWin;
    QColor mircToQColor(int);
    // logging stuff
    FILE *logFile;
    void configureLogging();
    int type;
};

#endif
