//$Id: client.h,v 1.5 1997/11/30 12:16:42 parallax Exp $
//class Client actually handles the guts of IRC parsing

#ifndef CLIENT_H
#define CLIENT_H

#include <stdio.h>
#include <qlist.h>
#include <qobject.h>
#include <qsocknot.h>
#include <qstring.h>

#include "dcc.h"
#include "modules.h"
#include "alias.h"

//KDE
#include <kprocess.h>

class BanRequest
{
protected:
    QString nick;
    QString channel;
    QString reason;
    int type;
public:
    enum { NORMAL, HOST, DOMAIN, NICK };
    BanRequest(const char *n, const char *c, const char *r=0, int t=NORMAL) { nick = n; channel = c; reason = r; type = t;}
    const char *Nick() { return nick; }
    const char *Channel() { return channel; }
    const char *Reason() { return reason; }
    int Type() { return type; }
};

class Client : public QObject {
    Q_OBJECT
friend class IrcApp;
public: /* Procedures */
    Client(QObject *parent=0, const char *name=0);
    virtual ~Client(); 
    void ConnectClient(int fd); // connects the client to the server connection
    bool Connected() { return connected; }
    static int ConnectToServer(const char *server, int port);
    bool DisconnectFromServer(const char *msg);
    void ParseServer(const char *data);
    void ParseUser(const char *data, const char *win);
    bool Registered() { return registered; }
    bool SendToServer(const char *buff);
    QString UnixTimeToDate ( const char *);
    const char *Version() { return version; }
    void Output(int type, const char *window, const char *txt);   
    void AddToLog(const char *str);
    void closeLog();
    void openLog();
    bool isAway() {return away;}

protected slots:
    void ReadData(); // read data from the socket
    void WriteData(); // write data to the socket
    void clear(const char *);
    void Added_Module(const char *);

protected: /* Procedures */
    void ParseNumeric(int, char *, char *);
    void ParseWord(char *, char *, char *);
    void HandleEvent(int, const char *, const char *arg2=0);
    void HandlePrivmsg(const char *, const char *, const char *, const char *);
    void HandleMode(const char *, const char *);
    bool HandleAlias ( const char *, const char *, const char *);
    bool HandleHookedCommand ( const char *, const char *, const char *);
    bool HandleBuiltInCommand ( const char *, const char *, const char *);

protected: /* Data */
    QSocketNotifier *rsn, *wsn; //socket notifiers make our job MUCH easier   
    bool registered,away;
    FILE *logFile;		// For that nifty doodle logging
    modLoader *kircModules;	// for modules support
    int mnudtaFile, mnudtaAboutMods;
    QList<HookCmd> hookedCommands;
//    QList<QString> channels;

public:
    static const char *LocalAddress() { return localAddress; }
    static void ReloadAliases(const char *aliasFile=NULL);
    static QString getServerName() {return serverName.copy();}
    static QString getServerPort() {return serverPort.copy();}
protected:
    static AliasList *aliasList;
    static QList<QString> *aliases;
    static QString serverName;	// holds the servername;
    static QString serverPort;	// and port
    static QString version;	// ??
    static QString localAddress;

public:
    bool connected;	// holds connnection state
    QString incomplete;	// sometimes lag means we don't get the whole thing
    QList<BanRequest> *kickBanList;

// dcc.cpp:
public:
    void CloseDCCChat(const char *nick);
    void SendToDCCChat(const char *nick, const char *buff);
protected:
    void DoDCC(const char *);
    void DCCSend(const char *, const char *);
    void DCCGet(const char *);
    void DCCChat(const char *);
    int CreateDCCPassiveConnection(int &port); // creates a listening socket, returns fd, fills in the value for port
    QList <DCCChatSession> *dccChats;
    QList <DCCOffer> *dccOffers;
    QList <KProcess> *dccProcs;
    QList <KProcess> *processes;
    QList <QString> *procNames;
    QSocketNotifier *dccChatRead;//, *dccChatWrite;    
protected slots:
    void DCCProcessExited(KProcess *);
    void ProcessExited(KProcess *);
    void ReceiveDCCChatData(KProcess *, char *, int);

// handleserver.cpp:
protected:
    bool Match_Hook(Hook *hook, const char *, const char *);
    void Handle_Numeric(int, const char *, const char *);
    void HandleCTCP_Reply(const char *, const char *, const char *, const char *);
    void Handle_Notice(const char *, const char*, const char *);
    void Handle_ServerPong(const char *, const char *);
    void Handle_ServerPing(const char *);
    void Handle_Join(const char *, const char *, const char *);
    void Handle_Part(const char *, const char *, const char *, const char *);
    void Handle_Kick(const char *, const char *, const char *, const char *);
    void Handle_Nick(const char *, const char *);
    void Handle_Quit(const char *, const char *);
    void Handle_Topic(const char *, const char *, const char *, const char *);
    void Handle_Invite(const char *, const char *, const char *);
    void Handle_Error(const char *);
    void Handle_Wallops(const char *, const char *);
// ircapp.cpp:
protected:
    void Event_Registered();
};
#endif
