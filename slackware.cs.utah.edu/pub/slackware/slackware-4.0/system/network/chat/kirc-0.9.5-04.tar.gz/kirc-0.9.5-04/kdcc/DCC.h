/**********************************************************************

	--- Dlgedit generated file ---

	File: DCC.h
	Last generated: Thu Oct 30 23:25:06 1997

 *********************************************************************/

#ifndef DCC_included
#define DCC_included

#include "DCCData.h"

#include <qfile.h>
#include <qsocknot.h>
#include <qtimer.h>

class DCC : public DCCData
{
    Q_OBJECT

public:

    DCC
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~DCC();
protected:
    void cancelPressed();
    void Send();
    void Get();
    int Connect(const char *addr, int port);
    QSocketNotifier *rsn, *wsn; // read and write socket notifiers
    QSocketNotifier *stdIn;
protected slots:
    void ReadData();
    void WriteData();
    void ReadStdin();
    void Done();
    int Listen(); // creates a listening socket, awaiting a connection
    void ShowSpeed();
private:
    int bytesRead; 
    int bytesWritten; // for DCC SEND
    int bytesReceived; // bytes received by other side
    QFile *file;
    QTimer *timer;
    QTimer *speedTimer;
    // the progress bar only works well with numbers close to 100
    // this multiplier makes it all work out
    float multiplier;
    int secondsElapsed;
};
#endif // DCC_included
