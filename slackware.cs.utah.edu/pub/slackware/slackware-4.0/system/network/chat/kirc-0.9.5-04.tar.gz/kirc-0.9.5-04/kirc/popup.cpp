#include "popup.h"

Popup::Popup ( const char *aliasFile, const char *title )
{
    if (aliasFile)
    {
        popupList = Alias::LoadAliasList(aliasFile);
        QPopupMenu popup;
        QPopupMenu current;
        &current = &popup;
        if (title)
        {
            popup.insertItem(title);
            popup.insertSeparator();
        }

        QString str;
        for ( Alias *a=popupList->first(); a!=0; a=popupList->next())
        {
             str = (const char *)a->Command();
             if (str.left(1) == ".")
             {
                 str.remove(0, 1); // get rid of the .
                 current->insertItem((const char *)str, a, SLOT(DoAction()) );
                 connect ( a, SIGNAL(Execute(const char *)), win, SLOT(slotSelected(const char*)) );
                 
             }
             else
             {
                 current = new QPopupMenu();
                 popup->insertItem((const char *)str, current);
             }
         }
            
        popup->setItemEnabled(popup->idAt(0), false);
        QPoint pos = e->pos();
        pos = mapToGlobal(pos);
        popup->move(pos.x(), pos.y() );
        popup->show();
      
    }
    
