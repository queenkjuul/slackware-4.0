/**********************************************************************

	--- Dlgedit generated file ---

	File: GeneralOptions.cpp
	Last generated: Mon Aug 4 12:33:15 1997

 *********************************************************************/

#include <qdir.h>
#include "GeneralOptions.h"

#define Inherited GeneralOptionsData

#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>

#include <qfile.h>

#include <kdebug.h>
#include <kmsgbox.h>

#include "ircapp.h"
#include "defs.h"

GeneralOptions::GeneralOptions
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
    
    serverList = new QList<QString>();
    serverList->setAutoDelete(true);
    LoadServerList();
   
    connectAtStartupButton->setChecked(Settings::connectAtStart);
    autoReconnectButton->setChecked(Settings::reconnectOnDisconnect);
    QString str;
    str.sprintf("%d",Settings::serverPort);
    portEdit->setText(str);
    primaryNickEdit->setText(Settings::primaryNick);
    secondaryNickEdit->setText(Settings::secondaryNick);
    userEdit->setText(Settings::userName);
    quitMsg->setText(Settings::quitMessage);
    nameEdit->setText(Settings::realName);
    // showDialogCheckBox->setChecked(Settings::noShowOptions);
    passwordEdit->setText(Settings::serverPassword);

    chkModeI->setChecked(Settings::defaultModeI);
    chkModeS->setChecked(Settings::defaultModeS);
    chkModeW->setChecked(Settings::defaultModeW);

    //now get our tabs straight
    setTabOrder(serverNameEdit, portEdit);
    setTabOrder(portEdit, passwordEdit);
    setTabOrder(passwordEdit, connectAtStartupButton);
    setTabOrder(connectAtStartupButton, autoReconnectButton);
    setTabOrder(autoReconnectButton, primaryNickEdit);
    setTabOrder(primaryNickEdit, secondaryNickEdit);
    setTabOrder(secondaryNickEdit, userEdit);
    setTabOrder(userEdit, nameEdit);

    // setTabOrder(nameEdit, showDialogCheckBox);
}

void GeneralOptions::SaveAll()
{
    SaveServerList();
    Settings::connectAtStart = connectAtStartupButton->isChecked();
    Settings::reconnectOnDisconnect = autoReconnectButton->isChecked();
    Settings::primaryNick = primaryNickEdit->text();
    Settings::secondaryNick = secondaryNickEdit->text();
    Settings::userName = userEdit->text();
    Settings::realName = nameEdit->text();
    Settings::serverName = serverNameEdit->currentText();
    Settings::serverPort = atoi(portEdit->text());
    Settings::serverPassword = passwordEdit->text();
    Settings::quitMessage = quitMsg->text();
    Settings::defaultModeI = chkModeI->isChecked();
    Settings::defaultModeS = chkModeS->isChecked();
    Settings::defaultModeW = chkModeW->isChecked();
}

void GeneralOptions::LoadServerList()
{
    //kdebug(KDEBUG_INFO, 4010, Settings::serverListFile.data());
    QString fileStr = IrcApp::GetFile(Settings::serverListFile);
    QFile file(fileStr.data());
    QDir d(fileStr);
    if (d.exists())
        return;
     if (!file.open(IO_ReadOnly))
//         KMsgBox::message(0, "Error", "Could not load server list.\n\
//Check your resource file to make sure you have specified a valid server list file.", \
  //                        KMsgBox::EXCLAMATION);
         warning("could not load server list");
     else
     {
         char buff[512];
         QString str;
         while (!file.atEnd())
         {
             bzero(buff, 512);
             file.readLine(buff, 511);
             str = buff;
             int i = 0;
             if (!str.isEmpty())
             {
                 int endline = str.find('\n');
                 if (endline >-1)
                     str.remove(endline, 1);
                 serverList->append(new QString(str.data()));
                 int colon = str.find(':');
                 QString port;
		 port.sprintf("%d",DEFAULT_PORT);
                 if (colon > -1)
                 {
                     QString tmp = str.left(colon);
                     str.remove(0, colon+1);
                     port = str.copy();
                     str = tmp.copy();
                 }
                 QString test;
                 serverNameEdit->insertItem(str);
                 i++;
             }
         }
         QString current;
         current.sprintf("%s:%d", Settings::serverName.data(), Settings::serverPort);
         AddServer(current);
         file.close();
     }
}

void GeneralOptions::SaveServerList()
{
    QString fileStr = IrcApp::GetFile(Settings::serverListFile);
    QFile file(fileStr.data());
    QDir d(fileStr);
    if (d.exists())
        return;
     if (!file.open(IO_WriteOnly | IO_Truncate))
//         KMsgBox::message(0, "Error", "Could not save server list.\n\
//Check your resource file to make sure you have specified a valid server list file,\n\
//and that you have the proper file permissions", KMsgBox::EXCLAMATION);
         warning("could not save server list");
     else
     {
         for (unsigned int i=0; i < serverList->count(); i++)
         {
             QString out = (serverList->at(i))->data();
             out += "\n";
             file.writeBlock(out, out.length());
         }
         
         file.close();
     }
    
}
    
GeneralOptions::~GeneralOptions()
{
}

void GeneralOptions::serverSelected ( int index )
{
    QString txt = (serverList->at(index))->data();
    int colon = txt.find(':');
    QString port;
    if (colon > -1)
    {
        txt.remove(0, colon+1);
        port = txt.copy();
    }
    else
        port.sprintf("%d", DEFAULT_PORT);
    portEdit->setText(port);
//      kdebug(KDEBUG_INFO, 4010, "serverSelected %s", serverNameEdit->text(index));
}

// adds a server to the linked list (will also get saved upon exit)
void GeneralOptions::AddServer(const char *svr)
{
//    kdebug(KDEBUG_INFO, 4010, "adding server %s", svr);
    for (unsigned int i=0; i<serverList->count(); i++)
    {
        if ((serverList->at(i))->lower() == (QString(svr)).lower())
        {
            //          kdebug(KDEBUG_INFO, 4010, "GeneralOptions::AddServer server is already added");
            serverNameEdit->setCurrentItem(i); // if we already have the server, just select it instead
            return;
        }
    }
    QString tmp = svr;
    int colon = tmp.find(':');
    if (colon > -1)
        tmp = tmp.left(colon);
    serverList->insert(0, (new QString(svr)));
    serverNameEdit->insertItem(tmp, 0);

}

#include "GeneralOptions.moc"
#include "GeneralOptionsData.moc"
