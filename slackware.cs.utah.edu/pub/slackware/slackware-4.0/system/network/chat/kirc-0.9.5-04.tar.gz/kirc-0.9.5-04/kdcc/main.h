#ifndef MAIN_H
#define MAIN_H

#include <qstring.h>

class Settings {
public:
    static QString fileName;
    static QString fileSize;
    static QString mode;
    static QString nick;
    static QString address;
    static QString port;
};
#endif
