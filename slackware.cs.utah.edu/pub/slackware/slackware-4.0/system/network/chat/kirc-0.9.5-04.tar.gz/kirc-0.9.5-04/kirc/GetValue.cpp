/**********************************************************************

	--- Dlgedit generated file ---

	File: GetValue.cpp
	Last generated: Thu Nov 6 00:08:29 1997

 *********************************************************************/

#include "GetValue.h"
#include "GetValueData.moc"
#include "GetValue.moc"

#define Inherited GetValueData

GetValue::GetValue
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
    lineEdit->setFocus();
}

const char *GetValue::Value()
{
    return value;
}

GetValue::~GetValue()
{
}

void GetValue::SetLabel(const char *txt)
{
    label->setText(txt);
    label->adjustSize();
    lineEdit->resize(label->width(), lineEdit->height());
    adjustSize();
}

void GetValue::slotReturnPressed()
{
    value = lineEdit->text();
    if (!value.isEmpty())
        accept();
}
