//$Id: dcc.h,v 1.3 1997/11/30 02:14:24 parallax Exp $
#ifndef DCC_H
#define DCC_H

#include <qstring.h>
#include "kprocess.h"
// a convenient little class

class DCCOffer {
private:
    QString nick, file, address, port, fileSize;
    int type;
public:
    enum Type { SEND, CHAT };
    DCCOffer ( const char *_nick, const char *_file, const char *_address, const char *_port, const char *_fileSize, Type t = SEND)
        { nick = _nick; file = _file; address = _address; port = _port; fileSize = _fileSize; type = t; }
    int Type() { return type; }
    const char *Nick() { return nick; }
    const char *File() { return file; }
    const char *Address() { return address; }
    const char *Port() { return port; }
    const char *FileSize() { return fileSize; }
};

class DCCChatSession {
private:
    KProcess *proc;
    int fd;
    QString nick;
    bool isOpen;
public:
    DCCChatSession(const char *n=0, KProcess *p=0, int fD=-1) { proc = p; nick = n; fd = fD; }
    ~DCCChatSession() { if (proc) proc->kill(); }
    const char *Nick() { return nick; }
    KProcess *Process() { return proc; }
    int Socket() { return fd; }
    void SetSocket(int f) { fd =f; }
    void SetProcess(KProcess *p) { proc = p; }
    void SetNick ( const char *n) { nick = n; }
    void SetOpen(bool yn) { isOpen = yn; }
    bool IsOpen() { return isOpen; }
};
#endif
