//$Id: message.cpp,v 1.1 1997/11/30 02:15:57 parallax Exp $

#include "message.h"
#include "irc.h"
#include "ircapp.h"

MessageWindow::MessageWindow(QWidget *parent, const char *name)
        : IrcWindow(parent, name)
{
	type = IrcWindow::MESSAGE;
}

MessageWindow::~MessageWindow()
{

}

void MessageWindow::mousePressEvent(QMouseEvent *ev)
{
    if (ev->button() == RightButton)
            emit Popup(QCursor::pos());
}

void MessageWindow::ParseInput(const char *input)
{
    if (input[0] != '/')
    {
        QString str = "<";
        str += (const char *)Settings::myNick;
        str += "> ";
        str += input;
        if  (str.right(2) == "\r\n")
            str.remove(str.size()-2, 2);
        Output((const char *)str, Output::OWN);
        
        QString msg(1600);
        msg.sprintf("PRIVMSG %s :%s\r\n", name(), input);
        IrcApp::HandleEvent(Event::SOCKET_WRITE, msg);
    }
    else
        IrcWindow::ParseInput(input);
}
        
void MessageWindow::UpdateCaption()
{
    QString c;
    c.sprintf("Conversation with %s", name());
    setCaption(c);
}

void MessageWindow::ChangeNick ( const char *n1, const char *n2)
{
    if (QString(n1).lower() == QString(name()).lower())
    {
        IrcApp::HandleEvent(Event::UPDATE_WINDOW_NAME, n1, n2);
    }
}


void MessageWindow::HandleSignoff ( const char *nick, const char *msg)
{
    if (QString(nick).lower() == QString(name()).lower())
    {
        QString disp(512);
        disp.sprintf("Signoff: %s (%s)", nick, msg);
        Output(disp, Output::NOTICE);
    }
}

#include "message.moc"
