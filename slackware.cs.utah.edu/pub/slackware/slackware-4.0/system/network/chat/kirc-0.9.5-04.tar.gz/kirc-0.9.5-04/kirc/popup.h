//class Popup defines a popup menu (usually as a result of right click)

#ifndef POPUP_H
#define POPUP_H

#include "alias.h"

class Popup {
public:
    Popup(const char *aliasFile=0);
signals:
    void ItemSelected ( const char * );
private slots:
    void slotSelected ( const char * );
private:
    QList<Alias> *popupList;
};

#endif
