extern "C" {
	QString ExpandIdentifiers(QString, QString, QString, QString);
}

