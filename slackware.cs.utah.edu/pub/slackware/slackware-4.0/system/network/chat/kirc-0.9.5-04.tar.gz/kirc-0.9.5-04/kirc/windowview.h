//$Id: windowview.h,v 1.4 1997/12/12 13:47:13 parallax Exp $

#ifndef WINDOWVIEW_H
#define WINDOWVIEW_H

#include <qlabel.h>
#include <qdialog.h>
#include <qmenubar.h>
#include <qaccel.h>

#include "ircwindow.h"
#include "message.h"
#include "channel.h"
#include "console.h"
#include "dccwindow.h"
#include "irc.h"
#include "mdi.h"
#include "taskbar.h"

#include "GeneralOptions.h"
#include "EditFile.h"
#include "Appearance.h"
#include "DCCOptions.h"
#include "ClientOptions.h"

class WindowView : public QWidget
{
    Q_OBJECT;
public:
    WindowView ( QWidget *parent=0, const char *name=0 );
    ~WindowView ();
//    enum WindowType { CONSOLE, CHANNEL, MESSAGE, DCC };
    TaskBar *getTaskBar() {return taskBar;}
public slots:
    void OutputToWindow( int type, const char *name, const char *buff);
    void OutputToAll(int type, const char *buff);
    void AddWindow ( const char *name, int type, bool isMinimized=FALSE );
    void CloseWindow (const char *name);
    void JoinChannel ( );
    void HandleEvent ( int, const char *data1, const char *data2=0);
    void Connect();
    void Disconnect();
    IrcWindow *GetWindowByName ( const char *name );
    void Close();
    void Options();
    void UpdateCaption (const char *, const char *);
    void ChangeServer ( const char *);
    void ChangeMyNick ( const char *);
    void HelpAbout ();
    void slotApplyChanges();
    void SlotApplyTheme();
    void SelectWindow(const char *);
signals:
    void ChangeNick ( const char *, const char *);
    void RemoveNick ( const char *);
    void Signoff ( const char *, const char *);
    void NewMessage(int type, const char *sender, const char *msg);
    void Rejoin(); // emitted after we have been disconnected, and then reconnected
    void CloseAll(); // emitted to all windows when we wish all windows closed
    void OutputToAllWindows(const char *, int); // sends the message to all windows
    void ApplyTheme();
protected:
    void closeEvent ( QCloseEvent * );
    void resizeEvent ( QResizeEvent *);  
    QMenuBar *menu; // the main menu
    // KToolBar *tool;
    // KStatusBar *status;
    QPopupMenu *file;
    QPopupMenu *help;
    QPopupMenu *window;
    QPopupMenu *commands;
    QAccel *accel;
    TaskBar *taskBar;
    QFrame *status;
    QMenuBar *tool;
    QFrame *taskbarFrame;
    MDIManager *mdi;

protected:
    // dialogs
    GeneralOptions *general;
    Appearance *appearance;
    EditFile *aliases, *startup, *npopups, *cpopups;
    DCCOptions *dccOptions;
    ClientOptions *clientOptions;

private slots:
    void RemoveWindow(MDIWindow *);
    void RemoveWindow ( const char * );
    void SetNick();
    void SetServer();
    void ShowConsole();
};

#endif
