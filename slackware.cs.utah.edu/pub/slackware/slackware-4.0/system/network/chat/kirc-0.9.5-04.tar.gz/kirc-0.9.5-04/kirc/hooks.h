#ifndef HOOKS_H
#define HOOKS_H

#include <qstring.h>

/* Base classes
   no real reason to use these for much */
class C_HookBase
{
public:
	Client *client;
};

class Hostmask
{
public:
	QString nick, address, hostmask;
};


class Command :
	public C_HookBase
{
public:
	QString command,args,window;
};

class Numeric :
	public C_HookBase
{
public:
	int numeric;
	QString server,text;
};

class Invite :
	public C_HookBase
{
public:
	QString chan;
	Hostmask nick;
};

class NickChange :
	public C_HookBase
{
public:
	QString from, to;
};

class TopicChange :
	public C_HookBase
{
public:
	QString chan,topic;
	Hostmask nick;
};

class CTCP_Reply :
	public C_HookBase
{
public:
	QString ctcp,rest;
	Hostmask from;
};

class Msg :
	public C_HookBase
{
public:
	QString chan,message;
	Hostmask from;
};

class Part :
	public C_HookBase
{
public:
	QString chan,reason;
	Hostmask nick;
};

class Kick :
	public C_HookBase
{
public:
	Hostmask kicker;
	QString kicked,chan,reason;
};

class Error :
	public C_HookBase
{
public:
	QString text;
};

class Ping :
	public C_HookBase
{
public:
	QString text;
	int type;
	enum Type {SPing,SPong};
};

class Pong :
	public Ping
{
public:
	QString server;
};

class Wallop :
	public Ping
{
public:
	QString sender,wallop;
};

typedef Part Join; /* There is no reason */
typedef Part Quit; /* There is no channel */
typedef Msg Notice; /* If it's not to a channel chan==0 */
typedef Msg Action;
typedef C_HookBase I_HookBase;

/* for IrcApp events */
class Client_Registered :
	public I_HookBase
{
public:
	QString foo;
};

#endif
