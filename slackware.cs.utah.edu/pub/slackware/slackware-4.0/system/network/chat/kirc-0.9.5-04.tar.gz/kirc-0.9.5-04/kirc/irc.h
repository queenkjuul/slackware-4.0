//$Id: irc.h,v 1.7 1997/11/30 02:14:25 parallax Exp $

// This file holds all the definitions for common stuff
//Aaron Granick

#ifndef _IRC_H_
#define _IRC_H_

#include <qstring.h>

#include "../config.h"
#include "defs.h"
#include <qcolor.h>
#include <qlistbox.h>
#include "theme.h"

class Settings {
public:
    // flags
    static bool debug; // show debugging info?
    static bool echo; // echo raw data to stdout?
    static bool connectAtStart; // should we connect right away?
    static bool reconnectOnDisconnect; // reconnect when we have been disconnected?
    static bool noShowOptions; // show options  on startup

    /* Logging Options */
    static QString logFile;
    static bool logEnabled;
    static bool logInternal_Message;
    static bool logNotice;
    static bool logInfo;
    static bool logAction;
    static bool logOwn;
    static bool logPrivMessage;
    static bool logExclamation;
    static bool logError;
    static bool logServerMessage;
    static bool logNormal;
    static bool logChannel;

    static bool autoRejoin;
    static bool publicAway;
    static bool createDetached; // do we create windows detached by default?
    static bool timestamp;

    // Server stuff
    static QString myNick;
    static QString primaryNick;
    static QString secondaryNick;
    static QString quitMessage;
    static QString serverName;
    static int serverPort;
    static QString serverPassword;
    static QString userName;
    static QString realName;
    static QString chanPopupsFile;
    static QString nickPopupsFile;
    static QString aliasesFile;
    static QString startupFile;
    static QString serverListFile;
    static QString fileDir; // the location of the users config files, etc.
    static QString sysFileDir; // the location of system wide files
    static QString nickCompletionExtra; // extra characters added before and after nick completion to make it cool
    static QString defaultKickReason;
    static QString versionReply;
    static QString notifyList; // a comma separated list of nicks

    // Default modes
    static bool defaultModeI;
    static bool defaultModeS;
    static bool defaultModeW;

    // DCC settings
    static bool dccAutoGet;
    static QString dccDirectory;

    // graphical stuff
    static QString themeFile;
    static Theme theme;
};

// list of events we know how to handle

class Event {
public:
    enum { NEW_MESSAGE, NICK_CHANGE, SOCKET_WRITE, \
           JOIN_CHANNEL,  PART_CHANNEL, ADD_NICK, REMOVE_NICK, CHANGE_NICK, \
           CHANGE_MY_NICK, CHANGE_SERVER,  \
           CLOSE_ALL_WINDOWS,  CLOSE_WINDOW, CONNECT, DISCONNECT, \
           CONNECTED, REGISTERED,  DISCONNECTED, QUIT,  TOPIC, OUTPUT, \
           NICK_IN_USE, QUERY,  SIGNOFF, NICK_MODE, WRITE_CONFIG, \
           UPDATE_WINDOW_NAME, PARSE_INPUT, ISON, ADD_NOTIFY, \
           REMOVE_NOTIFY, CREATE_DCC_WINDOW, CLOSE_DCC_CHAT, OUTPUT_DCC_CHAT };
};

// list of ouptput types
class Output {
public:
    enum { INTERNAL_MESSAGE, NOTICE, INFO, ACTION, OWN, PRIVMESSAGE, \
           EXCLAMATION, ERROR, SERVER_MESSAGE, NORMAL,CHAN };
};

//helper class
class Util
{
public:
    static int FindListBoxItem(QListBox *, const char *);
    static void RemoveListBoxItem(QListBox *, const char *);
};

class IrcApp;
extern IrcApp *app;
#endif
