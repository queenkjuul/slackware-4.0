//$Id: ircapp.cpp,v 1.7 1997/12/01 05:49:48 parallax Exp $

#include <qdir.h>

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "ircapp.h"
#include "windowview.h"
#include "client.h"
#include "GetValue.h"

#include <unistd.h>

#include <X11/Xlib.h>

#include <qfile.h>
#include <qregexp.h>

//KDE
#include <kmsgbox.h>
#include <kdebug.h>

QList<QString> IrcApp::channels;
QFont IrcApp::defaultFont;
QPalette IrcApp::defaultPalette;
int IrcApp::posX;
int IrcApp::posY;
int IrcApp::width;
int IrcApp::height;
bool IrcApp::userQuit;
Client *IrcApp::client;
WindowView *IrcApp::windowView;
AliasList *IrcApp::aliases;
QTimer *IrcApp::notifyTimer;

void MakeDirError(const char *dir)
{
    QString out;
    out.sprintf("Could not create directory %s.\nCheck your directory permissions..", dir);
    KMsgBox::message(0, "Warning", out.data(), KMsgBox::EXCLAMATION);
}

IrcApp::IrcApp (int& argc, char** argv, const char *appName)
	: KApplication ( argc, argv, appName)
{
      // let's set the defaults 
    width = 740;
    height = 480;
    posX = 0;
    posX = 0;

    CopyFiles(); // make sure we have everything we need
    ReadConfig();
    defaultPalette = *(palette());
    defaultFont = *(font());
    userQuit = false;
    notifyTimer = new QTimer(this);
    connect(notifyTimer, SIGNAL(timeout()), this, SLOT(DoNotify()));
}

IrcApp::~IrcApp()
{
    // delete server;
    // delete windowview;
    delete client;
}

void IrcApp::Go()
{
    aliases = Alias::LoadAliasList(GetFile(Settings::aliasesFile));
    client = new Client();
    //connect(client, SIGNAL(Event(int, const char *, const char *)), this, SLOT(HandleEvent(int, const char *, const char *)) );
    
    windowView = new WindowView();
    //connect(windowView, SIGNAL(ApplyThemeGlobal()), this, SLOT(ApplyTheme()));
    connect(windowView, SIGNAL(NewMessage(int, const char *, const char *)), \
            SLOT(HandleNewMessage(int, const char *, const char *)) );
    //connect(windowView, SIGNAL(Event(int, const char *, const char *)), this, SLOT(HandleEvent( int, const char *, const char *)) );
    //connect(client, SIGNAL(Output(int, const char *, const char *)), windowView, SLOT(OutputToWindow(int, const char *, const char *)) );
    setMainWidget ( windowView );
    windowView->setGeometry ( posX, posY, width, height );
    windowView->setCaption(APPNAME);
    windowView->setIconText(APPNAME);
    windowView->show();
    // for some reason we have to do it again
    windowView->setGeometry ( posX, posY, width, height );
    windowView->AddWindow ( CONSOLENAME, IrcWindow::CONSOLE); // our status channel
    
    if (!Settings::noShowOptions)
        windowView->Options();
    if (Settings::connectAtStart)
        HandleEvent(Event::CONNECT, NULL);    
}

void IrcApp::ApplyTheme()
{
    if (!Settings::themeFile.isEmpty())
        Settings::theme.Load(GetFile(Settings::themeFile));
    QWidget *w = new QWidget();
    w->setPalette(defaultPalette);
    w->setFont(defaultFont);
    SetThemeProperties(w, Settings::theme.app);
    setPalette(w->palette(), true); // set global palette
    setFont(w->font()); // and global font
    delete w;
}

void IrcApp::UpdateAll ( )
{
    processEvents(); // make sure everything is handled
}

void IrcApp::SetThemeProperties(QWidget *w, ThemeObject &o)
{
    QColorGroup og = w->colorGroup();
    QColor base = og.base();
    QColor widgetColor = og.background();
    QColor textColor = og.text();
    
    if (!o.baseColor.isEmpty())
        base = QColor(o.baseColor);
        
    if (!o.widgetColor.isEmpty())
        widgetColor = QColor(o.widgetColor);
        
    if (!o.textColor.isEmpty())
        textColor = QColor(o.textColor);
  
    QColorGroup norm(textColor, widgetColor, widgetColor.light(), widgetColor.dark(), widgetColor.dark(125), textColor, base);
    QColorGroup dis(widgetColor.dark(), widgetColor, widgetColor.light(), widgetColor.dark(), widgetColor.dark(125), widgetColor.dark(), widgetColor);
    QPalette p(norm, dis,norm);
    SetPaletteRecursive(w, p);
    w->setPalette(p);
    QFont f = ThemeFont(w, o);
    SetFontRecursive(w,f);
    w->setFont(f);
    if (!o.backgroundColor.isEmpty())
        w->setBackgroundColor((QColor(o.backgroundColor)));
    if (o.backgroundPic.isEmpty())
    {
        QPixmap p;
        SetBackgroundPicRecursive(w, &p); // empty pixmap
    }
    else
    {
        QPixmap p;
        p.load(GetFile(o.backgroundPic));
        SetBackgroundPicRecursive(w, &p);
    }
    // w->setPalette(p);
}

void IrcApp::SetPaletteRecursive(QWidget *widget, const QPalette &p)
{
    QList<QObject> *list = (QList<QObject> *)(widget->children());
    if (list)
    {
        for (unsigned int i=0; i< list->count(); i++)
        {
            QObject *o = list->at(i);
            if (o->isWidgetType())
                SetPaletteRecursive((QWidget *)o, p);
        }
    }
    widget->setPalette(p);
}


void IrcApp::SetFontRecursive(QWidget *widget, const QFont  &f)
{
    QList<QObject> *list = (QList<QObject> *)(widget->children());
    if (list)
    {
        for (unsigned int i=0; i< list->count(); i++)
        {
            QObject *o = list->at(i);
            if (o->isWidgetType())
                SetFontRecursive((QWidget *)o, f);
        }
    }
    widget->setFont(f);
}

void IrcApp::SetBackgroundPicRecursive(QWidget *widget, const QPixmap  *p)
{
    QList<QObject> *list = (QList<QObject> *)(widget->children());
    if (list)
    {
        for (unsigned int i=0; i< list->count(); i++)
        {
            QObject *o = list->at(i);
            if (o->isWidgetType())
                SetBackgroundPicRecursive((QWidget *)o, p);
        }
    }
    widget->setBackgroundPixmap(*p);
    widget->update();
}
QFont IrcApp::ThemeFont(QWidget *w, ThemeObject &o)
{
     QFont f = w->font();
    if (!o.fontFamily.isEmpty())
        f.setFamily(o.fontFamily);
    if (!o.fontSize.isEmpty())
        f.setPointSize(atoi(o.fontSize));
    if (!o.fontWeight.isEmpty())
        f.setWeight(atoi(o.fontWeight));
    if (!o.isItalic.isEmpty())
        f.setItalic(atoi(o.isItalic));
    return f;
}

// this is the main event handling routine.  This receives all events from the client
// and deals with them appropriately
void IrcApp::HandleEvent ( int type, const char *data1, const char *data2)
{
    KConfig *config = KApplication::getKApplication()->getConfig();
    switch (type)
    {
        case Event::QUERY:
            windowView->AddWindow ( data1, IrcWindow::MESSAGE );
            if (*data2)
            {
                QString msg(512);
                msg.sprintf("<%s> %s", Settings::myNick.data(), data2);
                windowView->OutputToWindow ( Output::OWN, data1, msg.data());
            }
            break;
        case Event::NICK_CHANGE:
        {
            QString msg;
            msg.sprintf("NICK %s\r\n", data1);
            client->SendToServer (msg);
        }
        break;
        case Event::SOCKET_WRITE:
            client->SendToServer(data1);
            break;
        case Event::JOIN_CHANNEL:
            windowView->AddWindow(data1, IrcWindow::CHANNEL);
            break;
        case Event::PART_CHANNEL: {
	   QString msg;
	   msg.sprintf("PART %s\r\n",data1);
           HandleEvent(Event::SOCKET_WRITE, msg.data());
	   //client->SendToServer(msg);
	   break; }
        case Event::CLOSE_WINDOW:
            windowView->CloseWindow ( data1 );
            break;
        case Event::CONNECT:
        {
            if (client->Connected())
                windowView->OutputToWindow(Output::INTERNAL_MESSAGE, \
                                           NULL, "You are already connected.  Use /SERVER to change servers.");
            else
            {
                userQuit = false;
                windowView->HandleEvent(Event::CONNECT, NULL);
                QString out;
                out.sprintf("Connecting to %s port %d.", Settings::serverName.data(), \
                            Settings::serverPort);
                windowView->OutputToWindow(Output::INTERNAL_MESSAGE, NULL, out);
                int fd = Client::ConnectToServer(Settings::serverName, Settings::serverPort);
                if (fd != -1)
                    client->ConnectClient(fd);
                else
                    windowView->HandleEvent(Event::DISCONNECTED, NULL);
            }
        }
        break;
        case Event::DISCONNECT:
        {
            QString msg = data1;
            if (msg.isEmpty())
                msg = "Leaving.";
            userQuit = true;
            client->DisconnectFromServer(msg);         
        }
        break;
        case Event::CONNECTED:
            windowView->OutputToAll( Output::INTERNAL_MESSAGE, "Connected.");
            //  status = windowView->GetWindowByName("Status");
            //  status->Update();
            break;
        case Event::DISCONNECTED:
            windowView->HandleEvent (Event::DISCONNECTED, NULL);
            windowView->OutputToAll(Output::INTERNAL_MESSAGE, "Disconnected.");
            if (Settings::reconnectOnDisconnect && !userQuit)
            {
                HandleEvent(Event::CONNECT, NULL);
            }
            notifyTimer->stop();
            break;
        case Event::QUIT:
	    config->setGroup("General Options");
	    config->writeEntry("Last Ran Version",VERSION);
	    config->sync();
            userQuit = true;
            app->WriteConfig();
            HandleEvent(Event::DISCONNECT, data1);
//            app->quit();
            break;
        case Event::NICK_IN_USE:
            // if we haven't registered yet, and our first name is rejected, try our secondary
            if (QString(data1).lower() == Settings::primaryNick.lower() && !(client->Registered()))
            {
                Settings::myNick = Settings::secondaryNick.copy();
                QString out;
                out.sprintf("NICK %s\r\n ", Settings::secondaryNick.data());
                HandleEvent(Event::SOCKET_WRITE, out);
            }
            else
            {
                if (!(client->Registered()))
                {
                    GetValue d(NULL, "Nick in use.");
                    d.setCaption("Nick in use");
                    d.SetLabel("The nick you have chosen is in use.  Enter a new nickname:");
                    d.exec();
                    if (d.result())
                    {
                        QString out;
                        out.sprintf("NICK %s\r\n ", d.Value());
                        HandleEvent(Event::SOCKET_WRITE, out);
                    }
                }
            }
            //  windowView->OutputToWindow(Output::NOTICE, NULL, data1);
            break;
        case Event::REGISTERED:
	    Event_Registered();
//            windowView->HandleEvent(Event::REGISTERED, NULL);
//            ExecuteScript(GetFile(Settings::startupFile));
//            app->DoNotify(); // do a notify right off the bat
//            notifyTimer->start(10000); // update every 10 secs
            break;
        case Event::CHANGE_MY_NICK:
        {
            QString msg;
            msg.sprintf("You are now known as %s", data1);
            windowView->OutputToAll(Output::INFO, msg);
            windowView->HandleEvent(Event::CHANGE_MY_NICK, data1);
            Settings::myNick = data1;
        }
        break;
        case Event::WRITE_CONFIG:
            app->WriteConfig();
            break;
        case Event::CHANGE_SERVER:
        {
            QString serv, port;
            QString str(data1);
            int sep = str.find(':'); // you can use a colon or a space to specify the port
            if (sep < 0)
                sep = str.find(' ');
            if (sep > -1)
            {
                serv = str.left(sep);
                str.remove(0, sep+1);
                port = str.copy();
                if (port.isEmpty())
                    port.sprintf("%d", DEFAULT_PORT);
            }
            else
            {
                serv = str.copy();
                port.sprintf("%d", DEFAULT_PORT);
            }
            QString out;
            out.sprintf("Changing servers to %s port %s", serv.data(), port.data());
            windowView->OutputToWindow(Output::INTERNAL_MESSAGE, NULL, out);
            int fd = Client::ConnectToServer(serv, atoi(port)); // we make sure we can connect first
            if (fd)
            {
                HandleEvent(Event::DISCONNECT, "Changing servers");
                Settings::serverName = serv;
                Settings::serverPort = atoi(port);
                windowView->HandleEvent(Event::CHANGE_SERVER, serv);
                client->ConnectClient(fd);
            }
            else
                windowView->OutputToWindow(Output::INTERNAL_MESSAGE, \
                                           NULL, "Change servers failed, not disconnecting.");
        }
        break;
        case Event::PARSE_INPUT:
            client->ParseUser(data1, data2);
            break;
        case Event::ADD_NOTIFY:
            Settings::notifyList += " ";
            Settings::notifyList += data1;
            app->DoNotify();
            break;
        case Event::REMOVE_NOTIFY:
        {
            QString tmp = Settings::notifyList.copy();
            QString newList;
            int s = tmp.find(' ');
            while (s != -1)
            {
                QString test = tmp.left(s);
                tmp.remove(0, s+1);
                if (test.lower() != QString(data1).lower())
                {
                    newList += test;
                    newList += " ";
                }
                s = tmp.find(' ');
            }
            if (tmp.lower() != QString(data1).lower())
                newList += tmp;
            Settings::notifyList = newList.copy();
        }
        app->DoNotify();
        break;
        case Event::CREATE_DCC_WINDOW:
            windowView->AddWindow ( data1, IrcWindow::DCC); // dcc chat window
            break;
        case Event::CLOSE_DCC_CHAT:
            client->CloseDCCChat(data1);
            break;
        case Event::OUTPUT_DCC_CHAT:
            client->SendToDCCChat(data1, data2);
            break;
        case Event::TOPIC:
        case Event::NICK_MODE:
        case Event::UPDATE_WINDOW_NAME:
        case Event::ADD_NICK:
        case Event::REMOVE_NICK:
        case Event::SIGNOFF:
        case Event::CHANGE_NICK:
            windowView->HandleEvent(type, data1, data2);
	    break;
        case Event::ISON:
	    windowView->getTaskBar()->UpdateNotify(data1);
            break;
        default:
            warning("IrcApp:HandleEvent: UNKNOWN %d %s %s", type, data1, data2);
            break;
    }
    
}

void IrcApp::ExecuteScript (const char *script)
{
    QFile file(script);
    QDir d(script);
    if (d.exists())
        return;
    if (!file.open(IO_ReadOnly))
    {
        kdebug(KDEBUG_WARN,4015,"could not execute startup script");
        return;
    }
    char buff[512];
    IrcWindow *status = windowView->GetWindowByName(CONSOLENAME);
    while (!file.atEnd())
    {
        bzero (buff, 512);
        if (file.readLine(buff, 512) > 0)
        {
            if (strcmp(buff, "\n"))
            {
                if (Settings::debug)
                    kdebug(KDEBUG_INFO,4015,"Read from script: %s", buff);
               //  if ((QString(buff).left(5)).lower() == "alias")
//                 {
//                     char alias[512];
//                     bzero(alias, 512);
//                     sscanf(buff, "alias %[^\r\n]", alias);
//                     AddAlias ( alias );
//                 }
//                 else
                    status->ParseInput(buff);
            }
        }
    }
}

void IrcApp::DoNotify()
{
    QString str = Settings::notifyList.copy();
    str = str.simplifyWhiteSpace();
    if (str.isEmpty())
    {
        windowView->HandleEvent(Event::ISON, ""); // to clear it out
        return;
    }
    QString out;
    out.sprintf("ISON %s\r\n", str.data());
    HandleEvent(Event::SOCKET_WRITE, out);
}
    
void IrcApp::HandleNewMessage(int type, const char *sender, const char *txt)
{
    windowView->AddWindow(sender, IrcWindow::MESSAGE, TRUE);
    windowView->OutputToWindow(type, sender, txt);
      // ring bell
    XBell(getDisplay(),100);
}

void IrcApp::CopyFiles()
{
    // this stuff installs files if the do not exist...probably should be more flexible, but that's life
    char msg[512];

    // this little snippet of code will create the personal file directories, if they don't exist
    QDir ircdir(Settings::fileDir);
    if (!ircdir.exists())
    {
        QString str = Settings::fileDir.copy();
        QString dir;
        while(!str.isEmpty())
        {
            int slash = str.find('/',1);
            if (slash > -1)
                dir += str.left(slash);
            else
                dir += str;
            if (!ircdir.exists(dir))
            {
                kdebug(KDEBUG_WARN, 4015, "directory %s does not exist.", dir.data());
                if (!ircdir.mkdir(dir))
                {
                    MakeDirError(dir );
                    return; // all else will fail past here as well
                }
            }
            str.remove(0,slash);
        }            
    }
    if (!ircdir.exists("aliases"))
    {
        kdebug(KDEBUG_INFO, 4015, "Installing default aliases.");
        bzero(msg, 512);
        sprintf(msg, "cp %s/aliases %s", Settings::sysFileDir.data(), ircdir.path());
        system(msg);
    }

    if (!ircdir.exists("chan.popups"))
    {
        kdebug(KDEBUG_INFO, 4015, "Installing popups.");
        bzero(msg, 512);
        sprintf(msg, "cp %s/*.popups %s", Settings::sysFileDir.data(), ircdir.path());
        system(msg);
    }

    if (!ircdir.exists("startup"))
    {
        kdebug(KDEBUG_INFO, 4015, "Installing startup script");
        bzero(msg, 512);
        sprintf(msg, "cp %s/startup %s", Settings::sysFileDir.data(), ircdir.path());
        system(msg);
    }        
    if (!ircdir.exists("servers"))
    {
        kdebug(KDEBUG_INFO, 4015, "Installing servers file");
        bzero(msg, 512);
        sprintf(msg, "cp %s/servers %s", Settings::sysFileDir.data(), ircdir.path());
        system(msg);
    }
    if (!ircdir.exists("servers"))
    {
        kdebug(KDEBUG_INFO, 4015, "Installing servers file");
        bzero(msg, 512);
        sprintf(msg, "cp %s/servers %s", Settings::sysFileDir.data(), ircdir.path());
        system(msg);
    }
    // create the logs directory, if necessary
     if(!ircdir.cd("logs"))
    {
        kdebug(KDEBUG_INFO, 4015, "Creating log directory.");
        if (!ircdir.mkdir("logs"))
            MakeDirError("logs");
    }
    ircdir.cdUp();

     if(!ircdir.cd("themes/"))
    {
        kdebug(KDEBUG_INFO, 4015, "Creating themes directory.");
        if (!ircdir.mkdir("themes"))
            MakeDirError("themes");
    } 
     if (!ircdir.exists("default"))
     {
         kdebug(KDEBUG_INFO, 4015, "Installing default theme.");
         bzero(msg, 512);
         sprintf(msg, "cp %s/themes/* %s", Settings::sysFileDir.data(), ircdir.path());
         system(msg);
     } 
}


void IrcApp::WriteConfig ()
{
    KConfig * config  = getConfig();

    // General Options
    config->setGroup("General Options");
    QString str;
    str.sprintf("%d", Settings::createDetached);
    config->writeEntry("Create Detached", str);
    config->writeEntry("Nick Completion", Settings::nickCompletionExtra);
    config->writeEntry("Kick Reason", Settings::defaultKickReason);
    config->writeEntry("Version Reply", Settings::versionReply);

    str.sprintf("%d", Settings::defaultModeI);
    config->writeEntry("Mode I", str);
    str.sprintf("%d", Settings::defaultModeS);
    config->writeEntry("Mode S", str);
    str.sprintf("%d", Settings::defaultModeW);
    config->writeEntry("Mode W", str);

    // Appearance
    config->setGroup("Appearance");
    str.sprintf("%d", Settings::noShowOptions );
    config->writeEntry("Show Options", str);
    str = "";
    str.sprintf("%d", windowView->x() );
    config->writeEntry("XPos", str);   
    str = "";
    str.sprintf("%d", windowView->y() );
    config->writeEntry("YPos", str);
    str = "";
    str.sprintf("%d", windowView->width() );
    config->writeEntry("Width",  str);
    str = "";
    str.sprintf("%d", windowView->height() );
    config->writeEntry("Height",  str);
    str = "";
    str.sprintf("%d", Settings::timestamp);
    config->writeEntry("Timestamp", str);
    
    // Servers
    config->setGroup("Servers");
    str  = "";
    str.sprintf("%d", Settings::connectAtStart);
    config->writeEntry("Connect At Start", str);
    str = "";
    str.sprintf("%d", Settings::reconnectOnDisconnect);
    config->writeEntry("Auto Reconnect", str);
    config->writeEntry("Name", Settings::serverName);
    str.sprintf("%d", Settings::serverPort);
    config->writeEntry("Port", str);
    config->writeEntry("Password", Settings::serverPassword);

    // User info
    config->setGroup ( "User Info" );
    config->writeEntry("Primary Nick", Settings::primaryNick);
    config->writeEntry("Secondary Nick", Settings::secondaryNick);
    config->writeEntry("User Name", Settings::userName);
    config->writeEntry("Real Name", Settings::realName);
    config->writeEntry("Quit Message", Settings::quitMessage);

    // Files
    config->setGroup("Files");
    config->writeEntry("Nick List Popups File", Settings::nickPopupsFile);
    config->writeEntry("Aliases File", Settings::aliasesFile);
    config->writeEntry("Script File", Settings::startupFile);
    config->writeEntry("Theme File", Settings::themeFile);
    
    // Logging
    config->setGroup("Logging");
    str = "";
    str.sprintf("%d", Settings::logEnabled);
    config->writeEntry("Logging Enabled", str);
    str = "";
    str=Settings::logFile.copy();
    config->writeEntry("Log To", str);
    str = "";
    str.sprintf("%d", Settings::logInternal_Message);
    config->writeEntry("Log Internal Messages", str);
    str = "";
    str.sprintf("%d", Settings::logNotice);
    config->writeEntry("Log Notices", str);
    str = "";
    str.sprintf("%d", Settings::logInfo);
    config->writeEntry("Log Informational Stuff", str);
    str = "";
    str.sprintf("%d", Settings::logAction);
    config->writeEntry("Log CTCP Actions", str);
    str = "";
    str.sprintf("%d", Settings::logOwn);
    config->writeEntry("Log Stuff you say", str);
    str = "";
    str.sprintf("%d", Settings::logPrivMessage);
    config->writeEntry("Log Private Messages", str);
    str = "";
    str.sprintf("%d", Settings::logExclamation);
    config->writeEntry("Log Extra Important Stuff", str);
    str = "";
    str.sprintf("%d", Settings::logError);
    config->writeEntry("Log Errors", str);
    str = "";
    str.sprintf("%d", Settings::logServerMessage);
    config->writeEntry("Log Server Messages", str);
    str = "";
    str.sprintf("%d", Settings::logNormal);
    config->writeEntry("Log Normal Stuff", str);
    str = "";
    str.sprintf("%d", Settings::logChannel);
    config->writeEntry("Log Channel Chatter", str);

    // DCC
    config->setGroup("DCC");
    config->writeEntry("Default Directory", Settings::dccDirectory);
    str = "";
    str.sprintf("%d", Settings::dccAutoGet);
    config->writeEntry("Auto Get", str);
    // Notify List
    config->setGroup("Notify List");
    config->writeEntry("Notify", Settings::notifyList);

    // Client stuff
    str = "";
    str.sprintf("%d", Settings::publicAway);
    config->setGroup("Client");
    config->writeEntry("Public Away Actions", str);

    config->sync();  
}

void IrcApp::ReadConfig()
{
    QString str;

    // read in the config file
    KConfig *config = getConfig();

    // General Options
    config->setGroup("General Options");

    str = config->readEntry("Create Detached");
    if (!str.isNull())
        Settings::createDetached = atoi(str.data());
    str = config->readEntry("Nick Completion");
    if (!str.isNull())
        Settings::nickCompletionExtra = str.copy();
    str = config->readEntry("Kick Reason");
    if (!str.isNull())
        Settings::defaultKickReason = str.copy();
    str = config->readEntry("Version Reply");
    if (!str.isNull())
        Settings::versionReply = str.copy();

    str = config->readEntry ("Mode I");
    if (!str.isNull())
        Settings::defaultModeI = (atoi(str));
    str = config->readEntry ("Mode S");
    if (!str.isNull())
        Settings::defaultModeS = (atoi(str));
    str = config->readEntry ("Mode W");
    if (!str.isNull())
        Settings::defaultModeW = (atoi(str));

    // Servers
    config->setGroup ( "Servers" );
    str = config->readEntry ( "Name" );
    if ( !str.isNull() )
    {
        Settings::serverName = str.copy();
    }
    str = config->readEntry ( "Port" );
    if ( !str.isNull() )
    {
        Settings::serverPort = atoi(str.copy());
    }
    str = config->readEntry("Password");
    if (!str.isNull())
    {
        Settings::serverPassword = str.copy();
    }
    str = config->readEntry ( "Connect At Start" );
    if (!str.isNull() )
        Settings::connectAtStart = ( atoi(str) );
    str = config->readEntry ( "Auto Reconnect" );
    if (!str.isNull() )
        Settings::reconnectOnDisconnect = ( atoi(str) );

    // User Info
    config->setGroup ( "User Info" );
    str = config->readEntry ( "Primary Nick" );
    if ( !str.isNull() )
    {
        Settings::primaryNick = str.copy();
        Settings::myNick = str.copy();
    }
    str = config->readEntry ( "Secondary Nick" );
    if ( !str.isNull() )
        Settings::secondaryNick = str.copy();
    str = config->readEntry ( "Real Name" );
    if ( !str.isNull() )
        Settings::realName = str.copy();
    str = config->readEntry ( "User Name" );
    if ( !str.isNull() )
        Settings::userName = str.copy();
    str = config->readEntry ( "Quit Message" );
    if ( !str.isNull() )
        Settings::quitMessage = str.copy();

    //Appearance
    config->setGroup("Appearance");
    str = config->readEntry("Show Options");
    if ( !str.isNull() )
        Settings::noShowOptions = atoi(str.data());
    str = config->readEntry("XPos");
    if ( !str.isNull() )
        posX = atoi(str.data());
    str = config->readEntry("YPos");
    if ( !str.isNull() )
        posY = atoi(str.data());
    str = config->readEntry("Width");
    if ( !str.isNull() )
        width = atoi(str.data());
    str = config->readEntry("Height");
    if ( !str.isNull() )
        height = atoi(str.data());
    str = config->readEntry("Timestamp");
    if (!str.isNull())
        Settings::timestamp = atoi(str.data());
    
    // Files
    config->setGroup("Files");
    str=config->readEntry("Nick List Popups File");
    if ( !str.isNull() )
        Settings::nickPopupsFile = str.copy();
    str=config->readEntry("Aliases File");
    if ( !str.isNull() )
        Settings::aliasesFile = str.copy();
    str=config->readEntry("Startup Script");
    if ( !str.isNull() )
        Settings::startupFile = str.copy();
    str=config->readEntry("Theme File");
    if ( !str.isNull())
        Settings::themeFile = str.copy();
    
    // Logging
    config->setGroup("Logging");
    str=config->readEntry("Logging Enabled");
    if ( !str.isEmpty() )
        Settings::logEnabled = atoi(str);
    str=config->readEntry("Log To");
    if ( !str.isEmpty() )
        Settings::logFile = str.copy();
    str=config->readEntry("Log Internal Messages");
    if ( !str.isNull() )
        Settings::logInternal_Message = atoi(str);
    str=config->readEntry("Log Notices");
    if ( !str.isNull() )
        Settings::logNotice = atoi(str);
    str=config->readEntry("Log Informational Stuff");
    if ( !str.isNull() )
        Settings::logInfo = atoi(str);
    str=config->readEntry("Log CTCP Actions");
    if ( !str.isNull() )
        Settings::logAction = atoi(str);
    str=config->readEntry("Log Stuff you say");
    if ( !str.isNull() )
        Settings::logOwn = atoi(str);
    str=config->readEntry("Log Private Messages");
    if ( !str.isNull() )
        Settings::logPrivMessage = atoi(str);
    str=config->readEntry("Log Extra Important Stuff");
    if ( !str.isNull() )
        Settings::logExclamation = atoi(str);
    str=config->readEntry("Log Errors");
    if ( !str.isNull() )
        Settings::logError = atoi(str);
    str=config->readEntry("Log Server Messages");
    if ( !str.isNull() )
        Settings::logServerMessage = atoi(str);
    str=config->readEntry("Log Normal Stuff");
    if ( !str.isNull() )
        Settings::logNormal = atoi(str);
    str=config->readEntry("Log Channel Chatter");
    if ( !str.isNull() )
        Settings::logChannel = atoi(str);

    // DCC
    config->setGroup("DCC");
    str=config->readEntry("Default Directory");
    if ( !str.isNull())
        Settings::dccDirectory = str.copy();
    str=config->readEntry("Auto Get");
    if ( !str.isNull())
        Settings::dccAutoGet = atoi(str);

    //Notify List
    config->setGroup("Notify List");
    str = config->readEntry("Notify");
    if (!str.isNull())
        Settings::notifyList = str.copy();

    // Client stuff
    config->setGroup("Client");
    str = config->readEntry("Public Away Actions");
    if (!str.isNull()) 
	Settings::publicAway = atoi(str);
}

// GetFile() searches in your home directory first, then in the systemwide directory
QString IrcApp::GetFile(const char *nm)
{
    QString str(nm);
    if (str[0] == '/')
        return str;
    else
    {
        // first try the home directory
//        QString dir = kapp->localkdedir().copy() + "/share/apps/kirc/";
        QString dir = Settings::fileDir.copy() + "/";
         str.prepend(dir);
        QDir d(str);
         if (QFile::exists(str) && !d.exists())
             return str;

         else
         {
             QString dir = Settings::sysFileDir.copy() + "/";
             str = nm;
             str.prepend(dir);
             return str;
         }
    }
}

#include "ircapp.moc"
