//$Id: config.cpp,v 1.1 1997/11/24 10:13:16 parallax Exp $
//$Log: config.cpp,v $
//Revision 1.1  1997/11/24 10:13:16  parallax
//Added class Config-doesn't work yet
//

#include "config.h"

#define HASH_SIZE 101

Config::Config ( const char *filename )
{
    fileName = filename;
    dict = new QDict<CharDict> (101);
}

void Config::GetConfig()
{

    QFile file(fileName);
    if (!file.exists())
    {
        warning("File %s does not exist.", fileName.data());
        return;
    }
    if (!file.open(IO_ReadOnly))
    {
        warning("Could not open file %s for reading.", fileName.data());
        return;
    }
    QTextStream ts(&file);
    while (!ts.eof())
    {
        QString str = ts.readLine();
    }
}

void Config::SetGroup(const char *)
{


}

void Config::WriteEntry(const char *, const char *)
{

}

const char *Config::ReadEntry(const char *)
{

}


    
