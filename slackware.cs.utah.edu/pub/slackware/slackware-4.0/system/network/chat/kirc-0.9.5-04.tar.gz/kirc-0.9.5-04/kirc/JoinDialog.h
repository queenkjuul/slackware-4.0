/**********************************************************************

	--- Dlgedit generated file ---

	File: JoinDialog.h
	Last generated: Wed Aug 6 00:45:38 1997

 *********************************************************************/

#ifndef JoinDialog_included
#define JoinDialog_included

#include "JoinDialogData.h"

class JoinDialog : public JoinDialogData
{
    Q_OBJECT

public:

    JoinDialog
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    const char *Channel();
    virtual ~JoinDialog();
protected slots:
    void slotJoinChannel();



};
#endif // JoinDialog_included
