//$Id: alias.h,v 1.3 1997/11/24 10:06:05 parallax Exp $
#ifndef ALIAS_H
#define ALIAS_H

#include <qdict.h>
#include <qlist.h>
#include <qstring.h>

typedef QDict<char> AliasList;

class Alias
{
public:
    static AliasList *LoadAliasList(const char *, int len=97, QList<QString> *keys=NULL);
};
    
#endif
