//$Id: console.h,v 1.1 1997/11/30 02:15:57 parallax Exp $
#ifndef CONSOLE_H
#define CONSOLE_H

#include "ircwindow.h" 

class Console : public IrcWindow
{
public:
    Console (QWidget *parent=0, const char *name=0) : IrcWindow(parent, name) {type = IrcWindow::CONSOLE;}
protected:
    void closeEvent(QCloseEvent *e) { e->ignore(); }
};     

#endif
