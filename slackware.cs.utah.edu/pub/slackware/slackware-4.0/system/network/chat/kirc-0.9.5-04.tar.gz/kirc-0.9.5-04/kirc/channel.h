//$Id: channel.h,v 1.1 1997/11/30 02:15:57 parallax Exp $
#ifndef CHANNEL_H
#define CHANNEL_H

#include "ircwindow.h"
#include "message.h"

class Channel : public MessageWindow
{
    Q_OBJECT
public:
    Channel(QWidget *parent=0, const char *name=0);
    virtual ~Channel();
    int GetNickIndex (const char *);
    const char *Topic() { return topic; }
    const char *Modes() { return chan_modes; }
    const char *Key() { return chan_key; }
    unsigned long Limit() { return limit; }
    void HandleNickMode (const char *, const char *mode);
    void ClearModes();
public slots:
    void RemoveNick (const char *);
    void AddNick(const char *);
    void Rejoin(); // to rejoin the channel if we were unexpectedly disconnected
    void SetTopic(const char *t=0);
    virtual void ApplyTheme();
    virtual void ParseInput(const char *);
    virtual void ChangeNick (const char *, const char *);
    virtual void HandleSignoff (const char *, const char *);
    virtual void UpdateCaption();
protected slots:
    void NickPopup();
    void OAPopup(QPoint);
    void PopupSelected(int);
    int PlaceNick (const char *nick); // places the nick in the list to keep it alphabe
protected:
    void Configure();
    virtual void closeEvent(QCloseEvent *);
    virtual void resizeEvent(QResizeEvent *);
    ColorListBox *nickArea;
    QString topic, chan_key, chan_modes;
    KPopupMenu *nickPopup;
    AliasList *nickPopupList;
    QList<QString> *keys;
    unsigned long limit;
};



#endif
