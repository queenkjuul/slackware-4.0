#ifndef THEME_H
#define THEME_H
//$Id: theme.h,v 1.3 1997/11/24 10:06:08 parallax Exp $
// Handles themes for kIRC
// Aaron Granick

#include <qstring.h>

class ThemeObject
{
public:
    QString backgroundPic;
    QString backgroundColor;
    QString baseColor;
    QString widgetPic;
    QString widgetColor;
    QString textColor;
    QString fontFamily;
    QString fontSize;
    QString fontWeight;
    QString isItalic;
    QString style; // motif or windows
    QString icon; // only used by a few things
};


class Theme
{
public:
    Theme(const char *name=0);
    const char *Name();
     bool Load(const char *filename); // loads a theme from disk, returns a pointer to a theme object
    ThemeObject app;
    ThemeObject mainWindow;
    ThemeObject mdi;
    ThemeObject taskBar;
    ThemeObject channelWindows;
    ThemeObject titleBars;
    ThemeObject chatArea;
    ThemeObject nickList;
    ThemeObject commandLine;
    ThemeObject  serverTxt;
    ThemeObject  ownTxt;
    ThemeObject  noticeTxt;
    ThemeObject  channelEventTxt;
    ThemeObject  privmsgTxt;
    ThemeObject  actionTxt;
    ThemeObject  internalTxt;
    ThemeObject  errorTxt;
private:
    QString name;
};

#endif
