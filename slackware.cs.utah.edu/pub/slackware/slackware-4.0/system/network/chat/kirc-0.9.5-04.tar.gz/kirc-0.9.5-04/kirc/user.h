//user.h
//defines a user for kirc
//Aaron Granick
#ifndef _USER_H
#define _USER_H

#include <qstring.h>

class User {

public:
    User ( QString nick=0, QString info=0, QString name=0);
    QString Nick() { return nick; }
    QString Info() { return info; }
    QString Name() { return name; }
    void setName(QString n) { name = n; }
    void setNick(QString n) { nick = n; }
    void setInfo(QString i) { info = i; }
private:
    QString address; // the piece that really counts
    QString nick;
    QString info;
    QString name;
};

#endif
