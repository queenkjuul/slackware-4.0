//$Id: channel.cpp,v 1.4 1997/12/01 05:49:48 parallax Exp $

#include "channel.h"
#include "ircapp.h"
#include "ChannelConfig.h"
#include "identifiers.h"

#include <kdebug.h>

const int TOPIC_BORDER = 3;
const int TOPIC_WIDTH = 300;
const int TOPIC_OFFSET = 120;
const int NICK_AREA_WIDTH = 110;
const int POPUP_OFFSET_Y = 20;
const int POPUP_OFFSET_X = 0;

extern "C" {
    int IsOp(const char *);
    int IsVoice(const char *);
}

int IsOp (const char *nick)
{
  if (!nick)
    return false;
  if (nick[0] == '@')
    return true;
  return false;
}

int IsVoice (const char *nick)
{
  if (!nick)
    return false;
  if (nick[0] == '+')
    return true;
  return false;
}

Channel::Channel(QWidget *parent, const char *n)
        : MessageWindow(parent, n)
{   
    limit = 0;
    topic = QString("");
    chan_key = QString("");
    chan_modes = QString("");

    keys = new QList<QString>();
    keys->setAutoDelete(true);
    nickArea = new ColorListBox(this,name() );
    nickArea->setAutoBottomScrollBar(false); // we have left enough room...barely
    connect (nickArea, SIGNAL(Popup()), SLOT(NickPopup()) );
    connect (outputArea, SIGNAL(Popup(QPoint)),SLOT(OAPopup(QPoint)));
    nickPopup = NULL;
    nickPopupList = NULL;
    type = IrcWindow::CHANNEL;
}

Channel::~Channel()
{
    if (nickPopup)
        delete nickPopup;
    if (nickPopupList)
        delete nickPopupList;
    if (keys)
        delete keys;
}

void Channel::ApplyTheme()
{
    MessageWindow::ApplyTheme();
    IrcApp::SetThemeProperties(nickArea, Settings::theme.nickList);
    nickArea->update();
}

void Channel::UpdateCaption()
{
    QString c;
    c.sprintf("%s",name());
    if ( (!chan_modes.isEmpty()) || (limit) || (!chan_key.isEmpty()) ) {
	c.sprintf("%s [+%s", c.data(), chan_modes.data());

	if (limit)
	  c.append("l");

	if (!chan_key.isEmpty())
	  c.append("k");

	if (limit)
	  c.sprintf("%s %ld", c.data(), limit);

	if (!chan_key.isEmpty());
	  c.sprintf("%s %s", c.data(), chan_key.data());

	c = c.stripWhiteSpace().data();
	c.append("]");
    }
    if (!topic.isEmpty())
	c.sprintf("%s: %s", c.data(), topic.data());
    if (strcmp(c, this->caption()))
      setCaption(c);
}

void Channel::SetTopic (const char *t)
{
    topic = t;
}

void Channel::ParseInput(const char *txt)
{
    QString text(txt);
    int space = text.find(' ');
    int colon = text.find(':');        
    if ((colon < space && colon > 0) || (colon > 0 && space == -1)) // this means the we have a colon occuring before any white space
    {
        QString partialNick = text.left(colon); // everything but the colon
        QString completeNick;
        int index = 0;
        while (completeNick.isEmpty())
        {
            if (nickArea->count() == (unsigned int)index)
                completeNick = partialNick.copy();
            else
            {
                QString tmp = nickArea->text(index);
                for (int t=0; t<2; t++)
                {
                    if (tmp.left(1) == "@" || tmp.left(1) == "+") // screen out ops and v's
                        tmp.remove(0,1);
                }
		if (Settings::debug)
                    kdebug(KDEBUG_INFO, 4013, "Comparing %s with %s", partialNick.data(), tmp.left(partialNick.length()).data());
                if ((tmp.left(partialNick.length())).lower() == partialNick.lower())
                {
                    char extra = 0;
                    if (Settings::nickCompletionExtra == "Bold")
                        extra = 0x02;
                        if (Settings::nickCompletionExtra == "Underline")
                            extra = 0x1F;
                        if (Settings::nickCompletionExtra == "Inverse")
                            extra = 0x16;
                        if (!extra)
                            completeNick = tmp.copy();
                        else
                            completeNick.sprintf("%c%s%c", extra, tmp.data(), extra);
                }
            }
            index++;
        }
        // now we should have the complete nick (if any)
        text.remove(0, colon); // remove the partial nick
        text.prepend(completeNick);
    }
    MessageWindow::ParseInput(text);
}
    
void Channel::RemoveNick ( const char *nick)
{
    int index = GetNickIndex ( nick );
    if (index == -1)
    {
        warning("Channel::RemoveNick error: no such nick %s.", nick);
        return;
    }
    QString selected;
    int c = nickArea->currentItem();
    if (c != -1)
        selected = nickArea->text(c);
    nickArea->removeItem(index);
    if (index == c)
        nickArea->setSelected(nickArea->currentItem(), false);
    else
    {
        if (selected)
            nickArea->setSelected(GetNickIndex(selected), true);
    }
}    

void Channel::ClearModes()
{
	chan_modes=QString("");
}

void Channel::HandleNickMode ( const char *n,  const char *mode )
{
    QString c_nick, l_nick, nick;
    nick = QString(n);
    int index,c,i=0;

    bool add=true;
    while (mode[i])
    {
        switch(mode[i])
        {
            case  '+':
                add = true;
                break;
            case  '-':
                add = false;
                break;                   
	    case 'l':
		if (!add) {
		   limit = 0;
		   break;
		}
		// Fetch the next nick
		if (nick.isEmpty()) {
		   kdebug(KDEBUG_WARN, 4013, "Nick is empty!");
		   break; // Yes, something's broken here
		}
		if (nick.find(" ") <= 0)
		   l_nick = nick.copy();
		else {
		   l_nick = nick.left(nick.find(" "));
		   nick.remove(0,nick.find(" ")+1);
		}
		if (atol(l_nick)<=0) {
			kdebug(KDEBUG_WARN, 4013, "Ugh, limit shouldn't be zero!");
		}
		limit = atol(l_nick);
		break;
	    case 'k':
		if (!add) {
		   chan_key = QString("");
		   break;
		}
		// Fetch the next nick
		if (nick.isEmpty()) {
		   kdebug(KDEBUG_WARN, 4013, "Nick is empty!");
		   break; // Yes, something's broken here
		}
		if (nick.find(" ") <= 0)
		   l_nick = nick.copy();
		else {
		   l_nick = nick.left(nick.find(" "));
		   nick.remove(0,nick.find(" ")+1);
		}
		chan_key = QString(l_nick);
		break;
            case 'v':
            case 'o':
            {
		// Fetch the next nick
		if (nick.isEmpty()) {
		   kdebug(KDEBUG_WARN, 4013, "Nick is empty!");
		   break; // Yes, something's broken here
		}
		if (nick.find(" ") <= 0)
		   l_nick = nick.copy();
		else {
		   l_nick = nick.left(nick.find(" "));
		   nick.remove(0,nick.find(" ")+1);
		}
		index = GetNickIndex(l_nick);
		if (index == -1) {
		   kdebug(KDEBUG_WARN, 4013, "We have no record of nick!");
		   break;  // Again, another broken something, we shouldn't be here
		}
		c_nick = nickArea->text(index);

                if (add)
                {
                    if ( (!IsOp(c_nick)) && (mode[i] == 'o') )
			c_nick.sprintf("@%s",l_nick.data());
                    if ( (!IsOp(c_nick)) && (mode[i] == 'v') )
			c_nick.sprintf("+%s",l_nick.data());
                }
                else
                {
		    if ( (IsOp(c_nick)) && (mode[i] == 'o') )
			c_nick = l_nick.copy();
		    if ( (!IsOp(c_nick)) && (mode[i] == 'v') )
			c_nick = l_nick.copy();
                }
		c = nickArea->currentItem();
		nickArea->removeItem(index);
		nickArea->setSelected(c, true);
		if (index == c) // we don;t want the selection jumping around
		nickArea->setSelected(PlaceNick(c_nick), true);
		else
		  PlaceNick(c_nick);
                break;
		case  'm': // Moderated
		case  'i': // Invite only
		case  'n': // No external messages
		case  't': // only ops can set Topic
		case  's': // Secret
		case  'p': // Private
			if (add) {
			  if (chan_modes.find(mode[i]) <= 0)
				chan_modes+=mode[i];
			} else {
			  if ( (chan_modes.find(mode[i]) > 0) && (!chan_modes.isEmpty()) )
				chan_modes.remove(chan_modes.find(mode[i]),1);
			}
			break;
		case 'b':  // Do SOMETHING later...
			break;
		default:
			kdebug(KDEBUG_ERROR, 4013, "I got some unknown mode %s%c!\nPlease report this!", (add) ? "+" : "-", mode[i]);
			break;
            }
        }
        i++; // parse the next character
    }
    UpdateCaption();
}

void Channel::ChangeNick(const char *n1, const char *n2)
{
    int index = GetNickIndex ( n1);
    if (index == -1)
    {
	if (Settings::debug)
          kdebug(KDEBUG_ERROR, 4013, "nick %s not found", n1);
        return;
    }
    QString str(n2);
    char extra = (nickArea->text(index))[0];
    if ( extra == '@' )
        str.prepend("@");
    if ( extra == '+' )
        str.prepend("+");
    QString selected;
    int c = nickArea->currentItem();
    nickArea->removeItem(index);
    nickArea->setSelected(c, true);
    if (index == c) // we don;t want the selection jumping around
        nickArea->setSelected(PlaceNick(str), TRUE);
    else      
    {
        PlaceNick(str);
    }
    if (QString(n1).lower() != Settings::myNick.lower())
    {
        QString msg(512);
        msg.sprintf("%s is now known as %s", n1, n2);
        Output ( msg, Output::INFO );
    }
}

void Channel::AddNick (const char *nick)
{
    if (Settings::debug)
        kdebug(KDEBUG_INFO, 4013, "Adding nick: %s", nick);
    
    const char *nickptr = nick;
    if (nick[0] == '@' || nick[0] == '+')
        nickptr++;
    if (nick[1] == '@' || nick[1]== '+')
        nickptr++;
    int i = GetNickIndex(nickptr);
    if (i == -1)
            PlaceNick(nick);
    else
    {
        int c = nickArea->currentItem();
        nickArea->removeItem(i);
        nickArea->setSelected(c, true);
        if (i == c)
            nickArea->setSelected(PlaceNick(nick), true);
        else
            PlaceNick(nick);
    }

}

int Channel::PlaceNick (const char *nick)
{
    int index = 0;
    QString str;
    QString selected;
    int c = nickArea->currentItem();
    if (c != -1)
        selected = nickArea->text(c);
    while(nickArea->text(index))
    {
        str = nickArea->text(index);
     
        // now compare nick with the one currently there

        if ((const char *)(QString(nick).lower()) < str.lower())
        {
            nickArea->insertItem(nick, index);
            return index;
        }
       
        index++;
    }
    // must be the first
    nickArea->insertItem(nick, index);
    if (selected)
        nickArea->setSelected(GetNickIndex(selected), true);
    return index;
}

int Channel::GetNickIndex (const char *nick)
{
    QString str;
    QString name(nick);
    for (int i=0; i< ((int)(nickArea->count())); i++)
    {     
        str = nickArea->text(i);
        if ( str.left(1) == "@" || str.left(1) == "+")
            str.remove(0,1);
        if ( str.left(1) == "@" || str.left(1) == "+") // repeat
            str.remove(0,1);

        if (str.lower() == name.lower())
        { // we have a match
            return i;
        }
      
    }

    return -1; //no match
}

void Channel::HandleSignoff(const char *nick, const char *msg)
{
    if (GetNickIndex(nick) != -1)
    {
        QString disp(512);
        disp.sprintf("Signoff: %s (%s)", nick, msg);
        Output(disp, Output::NOTICE);
        RemoveNick(nick);
    }
}

void Channel::Rejoin()
{
    QString out;
    out.sprintf("JOIN %s\r\n", name());
    IrcApp::HandleEvent(Event::SOCKET_WRITE, out);
    nickArea->clear(); // get a new list of names
}

void Channel::NickPopup()
{
    QString temp;
    keys->clear();
    nickPopupList = Alias::LoadAliasList(IrcApp::GetFile(Settings::nickPopupsFile), 97, keys);
    if (!nickPopupList)
    {
        warning("could not load nickname popupList");
        return;
    }

    temp=QString( nickArea->text(nickArea->currentItem()) );
    if ((!strcmp(temp.left(1),"@")) || (!strcmp(temp.left(1),"+")))
      temp.remove(0,1);
    nickPopup = new KPopupMenu(temp.data());
    connect(nickPopup, SIGNAL(activated(int)), SLOT(PopupSelected(int)));
    QPopupMenu *subMenu = NULL;
    int iD = 0;
    for ( QString *a=keys->first(); a!=0; a=keys->next())
    {
        QString str = a->copy();
        if (str.left(1) == ".")
        {                
            str.remove(0, 1); // get rid of the .
            if (str.isEmpty()) // just a '.' means end of menu
            {
                nickPopup->insertItem(subMenu->name(), subMenu, iD);
                subMenu = NULL;
            }
            else
            {
                if (subMenu)
                    subMenu->insertItem(str, iD);
                else
                    nickPopup->insertItem(str, iD);
            }
        }
        else
        {
            if (subMenu)
                nickPopup->insertItem(subMenu->name(), subMenu, iD);
            subMenu = new QPopupMenu(NULL, str);
            connect(subMenu, SIGNAL(activated(int)), SLOT(PopupSelected(int)));
        }
        iD++;
    }
    if (subMenu)
        nickPopup->insertItem(subMenu->name(), subMenu);
    QPoint pt = QCursor::pos();
    nickPopup->popup(pt);

}

void Channel::OAPopup(QPoint point)
{
        (IrcApp::WindowViewObj())->getTaskBar()->channelsPopup->setTitle(name());
        (IrcApp::WindowViewObj())->getTaskBar()->channelsPopup->popup(point);
}

void Channel::PopupSelected (int iD)
{
    if (!nickPopupList)
    {
        kdebug(KDEBUG_ERROR, 4013, "Attempt to call Channel::PopupSelected(int) with NULL popupList.");
        return;
    }
    QString key = *(keys->at(iD));
    QString str;
    str.sprintf("%s", nickPopupList->find(key));
    QString nick = nickPopup->title();
    if (nick.left(1)=="@" || nick.left(1) == "+")
        nick.remove(0,1);
    if (nick.left(1)=="@" || nick.left(1) == "+")
        nick.remove(0,1);

    str = ExpandIdentifiers(str, nick, name(), NULL);

    ParseInput(str);
    delete nickPopupList;
    delete nickPopup;
    nickPopupList = NULL;
    nickPopup = NULL;
}

void Channel::Configure()
{
	ChannelConfig *dialog = new ChannelConfig(this, name());
	dialog->exec();
	dialog->close();
	delete dialog;
	saveConfig();
	configureLogging();
}

void Channel::closeEvent(QCloseEvent *e)
{
    QString msg;            
    unsigned int count;
    for (count=0;count<IrcApp::channels.count();count++)
    {
	if (!strcmp(IrcApp::channels.at(count)->lower().data(), QString(name()).lower()))
	{
	    msg.sprintf("PART %s\r\n", name() ); 
	    IrcApp::HandleEvent(Event::SOCKET_WRITE, msg);
	}
    }
    e->accept();
}

void Channel::resizeEvent(QResizeEvent *)
{
     int windowWidth = width() - NICK_AREA_WIDTH;
     nickArea->setGeometry ( (width()  - NICK_AREA_WIDTH),
                             0,
                             NICK_AREA_WIDTH,
                             height());
     commandArea->setGeometry ( 0, (height() - COMMAND_AREA_HEIGHT ),
                                windowWidth,
                                COMMAND_AREA_HEIGHT );
     outputArea->setGeometry(0,0,windowWidth, height()-COMMAND_AREA_HEIGHT );
}

#include "channel.moc"
