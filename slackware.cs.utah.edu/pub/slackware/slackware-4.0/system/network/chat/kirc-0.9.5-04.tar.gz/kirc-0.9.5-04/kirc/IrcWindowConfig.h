/**********************************************************************

	--- Qt Architect generated file ---

	File: IrcWindowConfig.h
	Last generated: Thu Mar 12 22:38:00 1998

 *********************************************************************/

#ifndef IrcWindowConfig_included
#define IrcWindowConfig_included

#include "IrcWindowConfigData.h"

class IrcWindowConfig : public IrcWindowConfigData
{
    Q_OBJECT

public:

    IrcWindowConfig
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~IrcWindowConfig();

protected slots:
    void ApplyChanges();
    void cmdOK_Clicked();
    void cmdCancel_Clicked();
};
#endif // IrcWindowConfig_included
