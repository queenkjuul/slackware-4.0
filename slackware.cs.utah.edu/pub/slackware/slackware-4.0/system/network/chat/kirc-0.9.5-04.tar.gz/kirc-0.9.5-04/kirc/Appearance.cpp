/**********************************************************************

	--- Qt Architect generated file ---

	File: Appearance.cpp
	Last generated: Fri Dec 12 04:08:41 1997

 *********************************************************************/

#include "Appearance.h"

#define Inherited AppearanceData

Appearance::Appearance
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
    tree->insertItem("Application", NULL, 0);
    tree->expandItem(0);
    tree->addChildItem("Main Window", NULL, 0);
    tree->addChildItem("Root Window", NULL, 0);
    tree->addChildItem("Window List", NULL, 0);
    KPath p;
    p.setAutoDelete(true);
    p.push(new QString("Application"));
    tree->addChildItem("Chat Windows", NULL, &p);
    p.push(new QString("Chat Windows"));
    tree->addChildItem("Titlebar", NULL, &p);
    tree->addChildItem("Chat Area", NULL, &p);
    tree->addChildItem("Nick List", NULL, &p);
    tree->addChildItem("Command Line", NULL, &p);
    p.push(new QString("Chat Area"));
    tree->addChildItem("Server Text", NULL, &p);
    tree->addChildItem("Your Text", NULL, &p);
    tree->addChildItem("Notices", NULL, &p);
    tree->addChildItem("Channel Events", NULL, &p);
    tree->addChildItem("Messages", NULL, &p);
    tree->addChildItem("Actions", NULL, &p);
    tree->addChildItem("Internal Messages", NULL, &p);
    tree->addChildItem("Error Messages", NULL, &p);
}


Appearance::~Appearance()
{
}

void Appearance::SaveAll()
{

}

#include "Appearance.moc"
#include "AppearanceData.moc"
