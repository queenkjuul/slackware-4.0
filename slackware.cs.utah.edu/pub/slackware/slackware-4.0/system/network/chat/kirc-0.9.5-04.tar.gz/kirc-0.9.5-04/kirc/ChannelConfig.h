/**********************************************************************

	--- Qt Architect generated file ---

	File: ChannelConfig.h
	Last generated: Sat Mar 14 22:18:46 1998

 *********************************************************************/

#ifndef ChannelConfig_included
#define ChannelConfig_included

#include "ChannelConfigData.h"

class ChannelConfig : public ChannelConfigData
{
    Q_OBJECT

public:

    ChannelConfig
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~ChannelConfig();
protected slots:
    void ApplyChanges();
    void cmdOK_Clicked();
    void cmdCancel_Clicked();
    void cbModeP_Clicked();
    void cbModeS_Clicked();
protected:
    bool error;
};
#endif // ChannelConfig_included
