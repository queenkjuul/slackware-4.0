/**********************************************************************

	--- Dlgedit generated file ---

	File: DCCOptions.cpp
	Last generated: Tue Nov 4 21:48:16 1997

 *********************************************************************/

#include "DCCOptions.h"
#include "DCCOptions.moc"
#include "DCCOptionsData.moc"
#include "irc.h"

#define Inherited DCCOptionsData

DCCOptions::DCCOptions
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
    autoGetCheckBox->setChecked(Settings::dccAutoGet);
    defaultDirEdit->setText(Settings::dccDirectory);
}

DCCOptions::~DCCOptions()
{
}

void DCCOptions::SaveAll()
{
    Settings::dccAutoGet = autoGetCheckBox->isChecked();
    Settings::dccDirectory = defaultDirEdit->text();
}
