//$Id: ircapp.h,v 1.3 1997/11/25 11:46:30 parallax Exp $

#ifndef _IRCAPP_H
#define _IRCAPP_H

#include "alias.h"
#include "irc.h"
#include "windowview.h"
#include <qapp.h>
#include <qfont.h>
#include <qpalette.h>
#include <qstring.h>
#include <qdict.h>
#include <qtimer.h>
//KDE
#include <kapp.h>

class Client;

class IrcApp : public KApplication {    
   Q_OBJECT
public:
    IrcApp (int& argc, char** argv, const char *name=0);	// default constructor
    ~IrcApp ( );
    void Go(); // actually gets things started (call this only once)
    static void HandleEvent ( int type, const char *data1, const char *data2=0);
    static QString GetFile(const char *); // returns the complete filename
    static void SetThemeProperties(QWidget *w, ThemeObject &obj);
    static QFont ThemeFont(QWidget *w, ThemeObject &obj);
    static void ApplyTheme();
    static QPalette DefaultPalette() { return defaultPalette; }
    static QFont DefaultFont() { return defaultFont; }
    static void SetPaletteRecursive(QWidget *, const QPalette &);
    static void SetFontRecursive(QWidget *, const QFont &);
    static void SetBackgroundPicRecursive(QWidget *, const QPixmap *);
    static Client *ClientObj() { return client; }
    static WindowView *WindowViewObj() { return windowView; }
    static AliasList *Aliases() { return aliases; }
    static void ExecuteScript ( const char *script );
    static QList<QString> channels;
public slots:
    void DoNotify();
    void HandleNewMessage(int type, const char *sender, const char *txt);
    void UpdateAll ( );	// update server, etc.

private:
    void ReadConfig ( ); // read settings from config file
    void WriteConfig ( ); // write settings to config file
    static void CopyFiles();
    static int posX;
    static int posY;
    static int width;
    static int height;
    static bool userQuit;
    static Client *client; // our client
    static WindowView *windowView; // the gui
    static QPalette defaultPalette;
    static QFont defaultFont;
    static QDict<char> *aliases;
    static QTimer *notifyTimer;
private:
    static void Event_Registered();
};
#endif
