//$Id: message.h,v 1.1 1997/11/30 02:15:57 parallax Exp $
#ifndef MESSAGE_H
#define MESSAGE_H

#include "ircwindow.h"

class MessageWindow : public IrcWindow
{
    Q_OBJECT
public:
    MessageWindow(QWidget *parent = 0, const char *name = 0);
    virtual ~MessageWindow();
public slots:
    virtual void ChangeNick (const char *, const char *);
    virtual void HandleSignoff (const char *, const char *);
    virtual void ParseInput(const char *);
    virtual void UpdateCaption();
signals:
    void Popup(QPoint);
protected:
    virtual void mousePressEvent(QMouseEvent *);
};

#endif
