#include "DCC.h"
#include "main.h"

#include <kapp.h>

QString Settings::mode;
QString Settings::fileName;
QString Settings::nick;
QString Settings::fileSize;
QString Settings::address;
QString Settings::port;

void BadParameter()
{

    warning("useage: kdcc [-s] [-g] [-c] nick filename filesize address port");
    exit(0);
}

void ParseArguments ( int &argc, char **argv )
{
    if (argc < 7)
        BadParameter();
    
    if (QString(argv[1]) == "-s")
        Settings::mode = "SEND";
    else if (QString(argv[1]) == "-g")
        Settings::mode = "GET";
    else if (QString(argv[1]) == "-c")
             Settings::mode = "CHAT";
    else
        BadParameter();

    Settings::nick = argv[2];
    Settings::fileName = argv[3];
    Settings::fileSize = argv[4];
    Settings::address = argv[5];
    Settings::port = argv[6];
}

int main ( int argc, char **argv)
{
    ParseArguments(argc, argv);
    KApplication app(argc, argv);
    DCC mainWindow;
    if (Settings::mode != "CHAT")
        mainWindow.show();
    app.setMainWidget(&mainWindow);
    return app.exec();
}
