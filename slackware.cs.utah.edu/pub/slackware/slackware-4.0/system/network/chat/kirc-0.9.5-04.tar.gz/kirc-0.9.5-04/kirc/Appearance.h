/**********************************************************************

	--- Qt Architect generated file ---

	File: Appearance.h
	Last generated: Fri Dec 12 04:08:41 1997

 *********************************************************************/

#ifndef Appearance_included
#define Appearance_included

#include "AppearanceData.h"

class Appearance : public AppearanceData
{
    Q_OBJECT

public:

    Appearance
    (
        QWidget* parent = NULL,
        const char* name = NULL
    );

    virtual ~Appearance();
        
    void SaveAll ();

};
#endif // Appearance_included
