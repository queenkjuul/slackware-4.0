#include <stdio.h>

#include "client.h"
#include "ircapp.h"
#include "modules.h"
#include "hooks.h"

#define MODULE_ID 1234
#define MODULE_NAME "Example Module"

/* You NEED this for C++ not to mangle symbols.  Thanks Mike */
extern "C" {
	int kirc_uninit();
	int kirc_register(void *);
	void hook_exec(void *);
}

/* This is called right before the module's hooks are unloaded */
int kirc_uninit()
{
	printf("UNLOADED!\n");
}

int kirc_register (void *owner)
{
	Hook *hook = new Hook(Hook::Notice,
		MODULE_NAME,(void *)hook_exec,0,0);
	hook->trigger_channel.clear();		// Clear out the channel list
	hook->trigger_hostmask=QString("*");	// All users
	hook->owner=MODULE_ID;
	((modLoader *)owner)->add_hook(hook);
}

void hook_exec(void *param) /* When the hook is triggered */
{
	Notice *foo=(Notice *)param;
	if (!wild_match_per("*blah*",foo->message.data())) /* If it's not what I want */
		return;
	printf("Foo, I ran\n");
	printf("name: %s\n",foo->message.data());
	foo->client->Output( Output::NOTICE, CONSOLENAME , QString("I ran!"));
}
