/**********************************************************************

	--- Qt Architect generated file ---

	File: ChannelConfig.cpp
	Last generated: Sat Mar 14 22:18:46 1998

 *********************************************************************/

#include "ircapp.h"
#include "ircwindow.h"
#include "ChannelConfig.h"
#include "ChannelConfig.moc"
#include "ChannelConfigData.moc"

#include <stdio.h>

#include <kdebug.h>

#define Inherited ChannelConfigData

ChannelConfig::ChannelConfig
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
        IrcWindow *w;
        w = (IrcApp::WindowViewObj())->GetWindowByName(name);
        if (!w) // If there is no such window
                return;
        connect(cmdOK,SIGNAL(clicked()),this,SLOT(cmdOK_Clicked()));
        connect(cmdCancel,SIGNAL(clicked()),this,SLOT(cmdCancel_Clicked()));
        connect(cmdApply,SIGNAL(clicked()),this,SLOT(ApplyChanges()));
	cbModeI->setChecked(QString(((Channel *)w)->Modes()).find("i") >= 0 ? 1 : 0);
	cbModeM->setChecked(QString(((Channel *)w)->Modes()).find("m") >= 0 ? 1 : 0);
	cbModeS->setChecked(QString(((Channel *)w)->Modes()).find("s") >= 0 ? 1 : 0);
	connect(cbModeS,SIGNAL(clicked()),this,SLOT(cbModeS_Clicked()));
	cbModeP->setChecked(QString(((Channel *)w)->Modes()).find("p") >= 0 ? 1 : 0);
	connect(cbModeP,SIGNAL(clicked()),this,SLOT(cbModeP_Clicked()));
	cbModeT->setChecked(QString(((Channel *)w)->Modes()).find("t") >= 0 ? 1 : 0);
	cbModeN->setChecked(QString(((Channel *)w)->Modes()).find("n") >= 0 ? 1 : 0);
	cbModeK->setChecked(!QString(((Channel *)w)->Key()).isEmpty() ? 1 : 0);
	cbModeL->setChecked( ((Channel *)w)->Limit() > 0 ? 1 : 0 );
	if (cbModeK->isChecked())
		edKey->setText(((Channel *)w)->Key());
	else
		edKey->setText("");

	if (cbModeL->isChecked()) {
		QString str;
		str.sprintf("%d",((Channel *)w)->Limit());
		edLimit->setText(str.data());
	} else
		edLimit->setText("");
	if (((Channel *)w)->Topic())
		edTopic->setText(((Channel *)w)->Topic());
	else
		edTopic->setText("");
	error=false;
}


ChannelConfig::~ChannelConfig()
{
}

void ChannelConfig::ApplyChanges()
{
	QString str;
        IrcWindow *w;
        w = (IrcApp::WindowViewObj())->GetWindowByName(name());
        if (!w) // If there is no such window
                return;
	error=false;

	str.sprintf("MODE %s ",name());

	if (cbModeI->isChecked()) {
		if ( QString(((Channel *)w)->Modes()).find("i") <= 0 )
		    str.append("+i");
	} else {
		if ( QString(((Channel *)w)->Modes()).find("i") > -1 )
		    str.append("-i");
	}

	if (cbModeM->isChecked()) {
		if ( QString(((Channel *)w)->Modes()).find("m") <= 0 )
		    str.append("+m");
	} else {
		if ( QString(((Channel *)w)->Modes()).find("m") > -1 )
		    str.append("-m");
	}

	if (cbModeS->isChecked()) {
		if ( QString(((Channel *)w)->Modes()).find("s") <= 0 )
		    str.append("+s");
	} else {
		if ( QString(((Channel *)w)->Modes()).find("s") > -1 )
		    str.append("-s");
	}

	if (cbModeP->isChecked()) {
		if ( QString(((Channel *)w)->Modes()).find("p") <= 0 )
		    str.append("+p");
	} else {
		if ( QString(((Channel *)w)->Modes()).find("p") > -1 )
		    str.append("-p");
	}

	if (cbModeT->isChecked()) {
		if ( QString(((Channel *)w)->Modes()).find("t") <= 0 )
		    str.append("+t");
	} else {
		if ( QString(((Channel *)w)->Modes()).find("t") > -1 )
		    str.append("-t");
	}

	if (cbModeN->isChecked()) {
		if ( QString(((Channel *)w)->Modes()).find("b") <= 0 )
		    str.append("+n");
	} else {
		if ( QString(((Channel *)w)->Modes()).find("b") > -1 )
		    str.append("-n");
	}

	str.append("\r\n");
	IrcApp::HandleEvent(Event::SOCKET_WRITE,str);

	if ( (edTopic->text()) && 
	     ( strcmp( ((Channel *)w)->Topic() , edTopic->text() ) )
	   ) {
		str.sprintf("TOPIC %s :%s\r\n",name(),edTopic->text());
		IrcApp::HandleEvent(Event::SOCKET_WRITE,str);
	}

	if (cbModeL->isChecked()) {
	  if ( (edLimit->text()) && (atoi(edLimit->text()) != ((Channel *)w)->Limit()) ) {
		str.sprintf("MODE %s +l %s\r\n",name(),edLimit->text());
		IrcApp::HandleEvent(Event::SOCKET_WRITE,str);
	  }


	}

	if (cbModeK->isChecked()) {
	  if ( (edKey->text()) && (edKey->text() != ((Channel *)w)->Key()) ) {
	  	if (((Channel *)w)->Key() != "") {
			str.sprintf("MODE %s -k %s\r\n",name(),((Channel *)w)->Key());
			IrcApp::HandleEvent(Event::SOCKET_WRITE,str);
		}
		str.sprintf("MODE %s +k %s\r\n",name(),edKey->text());
		IrcApp::HandleEvent(Event::SOCKET_WRITE,str);
	  }
	} else {
	  	if (((Channel *)w)->Key() != "") {
			str.sprintf("MODE %s -k %s\r\n",name(),((Channel *)w)->Key());
			IrcApp::HandleEvent(Event::SOCKET_WRITE,str);
		}
	}

	Inherited::ApplyChanges();
}

void ChannelConfig::cmdOK_Clicked()
{
	ApplyChanges();
	if (error)
	   return;
	Inherited::cmdOK_Clicked();
}

void ChannelConfig::cmdCancel_Clicked()
{
	Inherited::cmdCancel_Clicked();
}

void ChannelConfig::cbModeS_Clicked()
{
	if (cbModeS->isChecked() && cbModeP->isChecked())
		cbModeS->setChecked(false);
}

void ChannelConfig::cbModeP_Clicked()
{
	if (cbModeS->isChecked() && cbModeP->isChecked())
		cbModeP->setChecked(false);
}

