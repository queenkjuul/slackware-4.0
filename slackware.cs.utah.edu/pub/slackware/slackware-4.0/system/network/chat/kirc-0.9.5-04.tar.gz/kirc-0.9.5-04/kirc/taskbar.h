//$Id: taskbar.h,v 1.5 1997/11/25 11:46:31 parallax Exp $

#ifndef TASKBAR_H
#define TASKBAR_H

#include "mdi.h"
#include "colorlistbox.h"
#include "alias.h"

#include <qframe.h>
#include <qlabel.h>
#include <qlistbox.h>


//KDE
#include <kpopmenu.h>



// a task bar to manage our windows
class TaskBar : public QFrame
{
    Q_OBJECT;
public:
    TaskBar::TaskBar ( QWidget *parent=0, const char *name=0);
    /* Ew, I don't like doing this */
    KPopupMenu *notifyPopup;
    KPopupMenu *channelsPopup;
    KPopupMenu *messagesPopup;
    ColorListBox *channels;
    ColorListBox *notifyList;
    ColorListBox *messages;
    void SetupChannelsPopup(const char *filename=0);
public slots:
    void AddWindow ( MDIWindow * );
    void RemoveWindow ( MDIWindow *);
    void UpdateName(MDIWindow *);
signals:
    void SelectWindow(const char *);    
protected:
    void resizeEvent ( QResizeEvent *);
    QLabel *channelLabel, *notifyLabel, *messagesLabel;
    QFrame *mainFrame;
    AliasList *chanPopupList;
    QList<QString> *keys;
public slots:
    void ApplyTheme();
    void UpdateNotify(const char *);
protected slots:
    void SlotSelectWindow (const char *);
    void HandleFocus(MDIWindow *);
    void HandleMinimize(MDIWindow *);
    void MessagesSelected(const char *);
    void ChannelsSelected(const char *);
    void ShowPopup();
    void PopupItemSelected(int);
    void ChanPopupSelected(int);
};

#endif
