/**********************************************************************

	--- Qt Architect generated file ---

	File: IrcWindowConfig.cpp
	Last generated: Thu Mar 12 22:38:00 1998

 *********************************************************************/

#include "ircapp.h"
#include "ircwindow.h"
#include "IrcWindowConfig.h"
#include "IrcWindowConfig.moc"
#include "IrcWindowConfigData.moc"

#define Inherited IrcWindowConfigData

IrcWindowConfig::IrcWindowConfig
(
	QWidget* parent,
	const char* name
)
	:
	Inherited( parent, name )
{
	IrcWindow *w;
	QString cap = QString( QString("Options for ") + name);
	setCaption(cap.data());
	w = (IrcApp::WindowViewObj())->GetWindowByName(name);
	if (!w) // If there is no such window
		return;
	cbLogEnabled->setChecked(w->logEnabled);
	edLogFile->setText(w->logFileName.data());
	cbActions->setChecked(w->logActions);
	cbChatter->setChecked(w->logChatter);
	cbErrors->setChecked(w->logErrors);
	cbExclamation->setChecked(w->logExclamation);
	cbInfo->setChecked(w->logInfo);
	cbInternalMessages->setChecked(w->logInternalMessages);
	cbNotices->setChecked(w->logNotices);
	cbOwn->setChecked(w->logOwn);
	cbPrivMessages->setChecked(w->logPrivMessages);
	cbServerMessages->setChecked(w->logServerMessages);
	connect(cmdOK,SIGNAL(clicked()),this,SLOT(cmdOK_Clicked()));
	connect(cmdCancel,SIGNAL(clicked()),this,SLOT(cmdCancel_Clicked()));
	connect(cmdApply,SIGNAL(clicked()),this,SLOT(ApplyChanges()));
}


IrcWindowConfig::~IrcWindowConfig()
{
}

void IrcWindowConfig::cmdOK_Clicked()
{
	ApplyChanges();
	done(0);
}

void IrcWindowConfig::cmdCancel_Clicked()
{
  	done(0);
}

void IrcWindowConfig::ApplyChanges()
{
	IrcWindow *w;
	w = (IrcApp::WindowViewObj())->GetWindowByName(name());
	if (!w)
		return;
	w->logFileName = QString(edLogFile->text());
	w->logActions = cbActions->isChecked();
	w->logEnabled = cbLogEnabled->isChecked();
	w->logChatter = cbChatter->isChecked();
	w->logErrors = cbErrors->isChecked();
	w->logExclamation = cbExclamation->isChecked();
	w->logInfo = cbInfo->isChecked();
	w->logInternalMessages = cbInternalMessages->isChecked();
	w->logNotices = cbNotices->isChecked();
	w->logOwn = cbOwn->isChecked();
	w->logPrivMessages = cbPrivMessages->isChecked();
	w->logServerMessages = cbServerMessages->isChecked();
}
