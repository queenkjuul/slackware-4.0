#include "options.h"
#include "options.moc"
#include <qpushbt.h>

const int LIST_WIDTH = 100;
const int BUTTON_WIDTH = 100;
const int BUTTON_HEIGHT = 30;
const int BORDER = 10;
const int BOTTOM_HEIGHT = BUTTON_HEIGHT + 2*BORDER + 50;

OptionsDialog::OptionsDialog(QWidget * parent=0, const char * name=0, bool modal, WFlags f)
        : QDialog(parent, name, modal, f)
{
    list = new QListBox(this, "list");
    connect(list, SIGNAL(highlighted(const char *)), SLOT(ShowDialog(const char *)) );
    dialogs = new QList<QWidget>();
    okButton = new QPushButton("Ok", this);
    connect(okButton, SIGNAL(clicked()), SLOT(accept()) );
    connect(okButton, SIGNAL(clicked()), SLOT(ApplyPressed()) );
    applyButton = new QPushButton("Apply", this);
    connect(applyButton, SIGNAL(clicked()), SLOT(ApplyPressed()) );
    cancelButton = new QPushButton("Cancel", this);
    connect(cancelButton, SIGNAL(clicked()), SLOT(reject()) );
    separator = new KSeparator(this, "separator");
    showDialog = new QCheckBox(this, "show dialog");
    viewWidth = 0;
    viewHeight = 0;
}

void OptionsDialog::AddDialog(QWidget *dlg, const char *name, int index)
{
    CHECK_PTR(dlg);
    dlg->recreate(this, 0, QPoint(LIST_WIDTH, 0), TRUE); 
    if (index != -1)
        dialogs->insert(index, dlg); // in the right place
    else
	dialogs->append(dlg);
    list->insertItem(name, index);
    list->setCurrentItem(0); // we always want to start with the first
    if (dlg->width() > viewWidth)
	viewWidth = dlg->width();
    if (dlg->height() > viewHeight)
	viewHeight = dlg->height();
    resize(viewWidth + LIST_WIDTH, viewHeight + BOTTOM_HEIGHT);
    ShowDialog(list->text(0));
}
    
void OptionsDialog::resizeEvent(QResizeEvent *)
{
    list->setGeometry(0,0,LIST_WIDTH, viewHeight);
    QRect rect(LIST_WIDTH,0, viewWidth, viewHeight);
    for (unsigned int i=0; i<dialogs->count(); i++)
        (dialogs->at(i))->setGeometry(rect); // resize each dialog the same
    separator->setGeometry(0, list->height() + BORDER/4, width(), separator->height());
    showDialog->move(BORDER, separator->y() + separator->height() + BORDER/4);
    // now place the buttons
    okButton->setGeometry(BORDER, height() - BUTTON_HEIGHT-BORDER,
                          BUTTON_WIDTH, BUTTON_HEIGHT);
    applyButton->setGeometry(2*BORDER+BUTTON_WIDTH, \
                             height()-BUTTON_HEIGHT-BORDER,  BUTTON_WIDTH, \
                             BUTTON_HEIGHT);
    cancelButton->setGeometry(3*BORDER+2*BUTTON_WIDTH, \
                              height()-BUTTON_HEIGHT-BORDER, \
                              BUTTON_WIDTH, BUTTON_HEIGHT);
    
}


void OptionsDialog::ShowDialog(const char *which)
{
    // hide all dialogs except ours
    for (unsigned int i=0; i<dialogs->count(); i++)
    {
        if (QString(list->text(i)) == QString(which))
        {
            dialogs->at(i)->raise();
        }
        //   else
        //  (dialogs->at(i))->hide();
    }
}

void OptionsDialog::ApplyPressed()
{
    SaveAll();
    emit ApplyButtonPressed();
}

void OptionsDialog::SaveAll()
{
    Settings::noShowOptions = showDialog->isChecked();
}
