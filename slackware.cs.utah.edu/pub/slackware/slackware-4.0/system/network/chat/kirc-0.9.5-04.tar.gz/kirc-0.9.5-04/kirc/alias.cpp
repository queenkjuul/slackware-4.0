//$Id: alias.cpp,v 1.4 1997/12/01 05:49:47 parallax Exp $

#include "alias.h"
#include "irc.h"

#include <qdir.h>
#include <qfile.h>
#include <qtstream.h>

#include <kdebug.h>

AliasList * Alias::LoadAliasList ( const char *filename, int len, QList<QString> *keys)
{
    QString str = filename;
    QDir d(filename);
    if (d.exists())
        return NULL;
    QFile file((const char *)str);
    if (!file.open(IO_ReadOnly))
        return NULL;
    AliasList *list = new AliasList(len);
    QTextStream ts(&file);
    while (!ts.eof())
    {
        QString str = ts.readLine();
        if (str[0] != '#')
        {
            int space = str.find(' ');
            QString key;
            if (space != -1)
            {
                key = str.left(space);
                str.remove(0, space+1);
            }
            else
            {
                key = str.copy();
                str = "";
            }
            if (!key.isEmpty())
            {
                QString *ins = new QString(str.data());
                list->insert(key, (*ins));
		if (Settings::debug)
                  kdebug(KDEBUG_INFO, 4010, "Inserting: %s, %s", key.data(), str.data());
                if (keys)
                    keys->append(new QString(key.data()));
            }
        }
    }     
     file.close();
     return list;
}
