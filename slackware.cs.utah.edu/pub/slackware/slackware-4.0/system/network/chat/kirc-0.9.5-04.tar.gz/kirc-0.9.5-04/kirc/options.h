// the options dialog
// Aaron Granick
#ifndef OPTIONSDIALOG_H
#define OPTIONSDIALOG_H

#include "GeneralOptions.h"
#include "EditFile.h"
//#include "VisualOptions.h"
#include <qdialog.h>
#include <qlistbox.h>
#include <qlist.h>
#include <qwidget.h>
#include <qchkbox.h>

//KDE
#include "kseparator.h"

class OptionsDialog : public QDialog
{
    Q_OBJECT
public:
    OptionsDialog(QWidget * parent=0, const char * name=0, bool modal=TRUE, WFlags f=0);
    void AddDialog(QWidget *dlg, const char *name, int index = -1);
    void SaveAll();
signals:
    void ApplyButtonPressed(); // emitted when apply or close are pressed
protected:
    void resizeEvent(QResizeEvent *);
protected slots:
    void ShowDialog(const char *);
    void ApplyPressed();
private:
    KSeparator *separator;
    QListBox *list;
    QList<QWidget> *dialogs;
    QPushButton *okButton;
    QPushButton *applyButton;
    QPushButton *cancelButton;
    QCheckBox *showDialog;
    int viewWidth;
    int viewHeight;
};

#endif
