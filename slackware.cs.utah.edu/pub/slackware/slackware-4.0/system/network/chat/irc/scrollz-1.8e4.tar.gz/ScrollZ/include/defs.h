/* include/defs.h.  Generated automatically by configure.  */
/* include/defs.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if on AIX 3.
   System headers sometimes define this.
   We just want to avoid a redefinition error message.  */
#ifndef _ALL_SOURCE
/* #undef _ALL_SOURCE */
#endif

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef gid_t */

/* Define if you have the strftime function.  */
#define HAVE_STRFTIME 1

/* Define if you have <sys/wait.h> that is POSIX.1 compatible.  */
#define HAVE_SYS_WAIT_H 1

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef mode_t */

/* Define if your C compiler doesn't accept -c and -o together.  */
/* #undef NO_MINUS_C_MINUS_O */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef pid_t */

/* Define if the system does not provide POSIX.1 features except
   with this defined.  */
/* #undef _POSIX_1_SOURCE */

/* Define if you need to in order for stat and other things to work.  */
/* #undef _POSIX_SOURCE */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define on System V Release 4.  */
/* #undef SVR4 */

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef uid_t */

/* define if allow sys/time.h with time.h */
#define TIME_WITH_SYS_TIME 1

/* define this if you are using BSD wait union thigs */
/* #undef BSDWAIT */

/* define this if you are using sigaction() instead of signal() */
#define USE_SIGACTION 1

/* define this if you are using sigset() instead of signal() */
/* #undef USE_SIGSET */

/* define this if you are using system V (unreliable) signals */
/* #undef SYSVSIGNALS */

/* define this if termcap(3) requires it */
/* #undef INCLUDE_TERM_H */

/* define this if you are using -lcurses, or if termcap(3) requires it */
#define INCLUDE_CURSES_H 1

/* define this if wait3() is declared */
/* #undef WAIT3_DECLARED */

/* define this if waitpid() is declared */
#define WAITPID_DECLARED 1

/* define this if waitpid() is unavailable */
/* #undef NEED_WAITPID */

/* define this to the name of the AMS mail file */
/* #undef AMS_MAIL */

/* define this if you have scandir() */
#define HAVE_SCANDIR 1

/* define this if you have memmove() */
#define HAVE_MEMMOVE 1

/* define this if you have setsid() */
#define HAVE_SETSID 1

/* define this if you have getsid() */
#define HAVE_GETSID 1

/* define this if you have getpgid() */
#define HAVE_GETPGID 1

/* define this if your getpgrp() doesn't take a pid argument */
/* #undef BROKEN_GETPGRP */

/* define this if you need getcwd() */
/* #undef NEED_GETCWD */ 

/* define this if you have hpux version 7 */
/* #undef HPUX7 */

/* define this if you have hpux version 8 */
/* #undef HPUX8 */

/* define this if you have an unknown hpux version (pre ver 7) */
/* #undef HPUXUNKNOWN */

/* define this if an unsigned long is 32 bits */
#define UNSIGNED_LONG32 1

/* define this if an unsigned int is 32 bits */
/* #undef UNSIGNED_INT32 */

/* define this if you are unsure what is is 32 bits */
/* #undef UNKNOWN_32INT */

/* define this if you are on a svr4 derivative */
/* #undef SVR4 */

/* define this if you are on solaris 2.x */
/* #undef __solaris__ */

/* define this if you don't have struct linger */
/* #undef NO_STRUCT_LINGER */

/* define this if you are on svr3/twg */
/* #undef WINS */

/* define this if you need fchmod */
/* #undef NEED_FCHMOD */

/* define this to the location of normal unix mail */
#define UNIX_MAIL "/var/spool/mail"

/* define this to be the name[:port] of the default server */
/* #undef DEFAULT_SERVER */

/* define this if your header files declare sys_errlist */
#define SYS_ERRLIST_DECLARED 1

/* define this if you have uname(2) */
#define HAVE_UNAME 1

/* define this if you need strerror(3) */
/* #undef NEED_STRERROR */

/* define this if you have posix strftime(3) */
#define HAVE_STRFTIME 1

/* define this if you have (working) POSIX (O_NONBLOCK) non-blocking */
#define NBLOCK_POSIX 1

/* define this if you have BSD (O_NDELAY) non-blocking */
/* #undef NBLOCK_BSD */

/* define this if you have SYSV (FIONBIO) non-blocking */
/* #undef NBLOCK_SYSV */

/* Define this if compiling with SOCKS (the firewall traversal library).
   Also, you must define connect, getsockname, bind, accept, listen, and
   select to their R-versions. */
/* #undef SOCKS */
/* #undef connect */
/* #undef getsockname */
/* #undef bind */
/* #undef accept */
/* #undef listen */
/* #undef select */

/*
 * Are we doing non-blocking connects?  Note:  SOCKS support precludes
 * us from using this feature.
 */
#if (defined(NBLOCK_POSIX) || defined(NBLOCK_BSD) || defined(NBLOCK_SYSV)) && \
	!defined(SOCKS)
# define NON_BLOCKING_CONNECTS
#endif

/* Define if you have the <dirent.h> header file.  */
#define HAVE_DIRENT_H 1

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <limits.h> header file.  */
#define HAVE_LIMITS_H 1

/* Define if you have the <memory.h> header file.  */
#define HAVE_MEMORY_H 1

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <netdb.h> header file.  */
#define HAVE_NETDB_H 1

/* Define if you have the <process.h> header file.  */
/* #undef HAVE_PROCESS_H */

/* Define if you have the <sgtty.h> header file.  */
/* #undef HAVE_SGTTY_H */

/* Define if you have the <stdarg.h> header file.  */
#define HAVE_STDARG_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/fcntl.h> header file.  */
#define HAVE_SYS_FCNTL_H 1

/* Define if you have the <sys/file.h> header file.  */
#define HAVE_SYS_FILE_H 1

/* Define if you have the <sys/ioctl.h> header file.  */
#define HAVE_SYS_IOCTL_H 1

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the <sys/ptem.h> header file.  */
/* #undef HAVE_SYS_PTEM_H */

/* Define if you have the <sys/select.h> header file.  */
/* #undef HAVE_SYS_SELECT_H */

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/twg_config.h> header file.  */
/* #undef HAVE_SYS_TWG_CONFIG_H */

/* Define if you have the <sys/un.h> header file.  */
#define HAVE_SYS_UN_H 1

/* Define if you have the <sys/wait.h> header file.  */
#define HAVE_SYS_WAIT_H 1

/* Define if you have the <termcap.h> header file.  */
#define HAVE_TERMCAP_H 1

/* Define if you have the <termio.h> header file.  */
/* #undef HAVE_TERMIO_H */

/* Define if you have the <termios.h> header file.  */
#define HAVE_TERMIOS_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <varargs.h> header file.  */
/* #undef HAVE_VARARGS_H */

/* Define if you have the sun library (-lsun).  */
/* #undef HAVE_LIBSUN */

/**************************** PATCHED by Flier ******************************/
/* Define this if you have gettimeofday(), most systems do */
#define HAVETIMEOFDAY 1

/* Define this if you want client with ANSI (color) support */
#define WANTANSI 1

/* Define this if you want high ascii client, shows on MSGs, /MAP
   ,/ME and on /LINKS for now */
#define HIGHASCII 1

/* Define this if you want OperVision support in the client */
/* #undef OPERVISION */

/* Define this if you want following optional stuff:
 - /AUTOINV   - Invites on Notify    - /LOGO
 - /FIND      - /SVER                - /BKT
 - /DIRLMK    - /DIRLNK              - /BKI
 - /MODELOCK  - /MODEUNLOCK          - Mode Lock Checking
 - /LLOOKUP   - /LLOOK               - /RANLK
 - /MN        - /ML                  - /TERMINATE
 - /MSAY      - /DOBANS */
/* #undef EXTRAS */

/* Define this if you want more accurate timer, NOT WORKING OK YET !!! */
/* #undef BETTERTIMER */

/* Defines this if you want fet's /ME and friend stuff in /WHOIS
   after server line */
/* #undef FET */

/* Define this if you want formatted /CSCAN */
/* undef NEWCSCAN */

/* Define this if you feel users should be invited to non +i channels on
   notify signon */
/* undef ACID */

/* Define this if you want sorted nicks in /CSCAN and old style of MSGs */
/* undef MGS */

/* Define this if you want scatter kicks */
/* #undef SCKICKS */

/* Define this if you want to compile the Toolie C-BOX */
/* #undef TOOLIE */

/* Define this if you want HyperDCC by Annatar in the client */
/* #undef HYPERDCC */

/* Define this if you don't want ScrollZ trademarks in KICK, ... */
/* #undef VILAS */

/* Define this if you want better /NEWHOST */
/* #undef JIMMIE */

/* Define this if you want CTCP PAGE for friends by BiGhEaD */
/* #undef CTCPPAGE */
/****************************************************************************/
