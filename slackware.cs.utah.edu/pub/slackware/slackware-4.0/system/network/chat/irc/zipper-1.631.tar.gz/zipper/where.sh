#!/bin/sh
PRG=`type -p $0` >/dev/null 2>&1     
dirname $PRG
