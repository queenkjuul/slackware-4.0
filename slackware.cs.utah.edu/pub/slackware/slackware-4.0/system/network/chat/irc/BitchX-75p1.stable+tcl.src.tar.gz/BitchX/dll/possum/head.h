#ifndef HEAD_H
#define HEAD_H 1

#include <ctype.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/time.h>

#include <signal.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define   NOSTR           ((char *) 0)    /* Null string pointer */
#define   LINESIZE        BUFSIZ          /* max readable line width */


struct headline {
char    *l_from;     
char    *l_tty;
char    *l_date; 
};
                        

int ishead(char []);
void fail(char [], char []);
void parse(char *line, struct headline *hl, char *pbuf);
char *copyin(char *src, char **space);
int isdate(char *date);
int cmatch(char *cp, char *tp);
char *nextword(char *wp, char *wbuf);
                
#endif