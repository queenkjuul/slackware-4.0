#ifndef _mystructs_h_
#define _mystructs_h_

/* don't change!! */
#define mybufsize     1024
/* don't change!! */
#define HASHTABLESIZE 10
/* change to number of autoreply nicks */
#define AUTOREPLYSIZE 5

/* don't change!! */
#ifdef WANTANSI
#ifdef OPERVISION
#define NUMCMDCOLORS  24
#else /* OPERVISION */
#define NUMCMDCOLORS  23
#endif /* OPERVISION */
#define NUMCOLORS     21
#endif /* WANTANSI */

struct friends {
     struct friends *next;
     char *userhost;
     char *channels;
     char *passwd;
     int privs;
     int number;
};

struct autobankicks {
     struct autobankicks *next;
     char *userhost;
     char *reason;
     char *channels;
     int shit;
};

struct list {
     struct list *next;
     char *nick;
     char *userhost;
};

struct words {
     struct words *next;
     char *channels;
     char *word;
     char *reason;
};

struct nicks {
     struct nicks *next;
     char *nick;
};

struct wholeftch {
   struct wholeftch *next;
   char *channel;
   struct list *nicklist;
};

struct wholeftstr {
   struct wholeftstr *next;
   char *splitserver;
   int print;
   int count;
   int total;
   time_t time;
   struct wholeftch *channels;
};

struct delayop {
   struct delayop *next;
   char *channel;
   char *nick;
   int  server;
   time_t time;
};

struct delaynotify {
    struct delaynotify *next;
    char *nick;
    int  server;
    time_t time;
};

struct splitstr {
    struct splitstr *next;
    char *servers;
};

struct mapstr {
    struct mapstr *next;
    char *server;
    char *uplink;
    int  distance;
};

struct bans {
    struct bans *next;
    char *ban;
    char *who;
    time_t when;
};

#ifdef WANTANSI
struct colorstr {
    char *color1;
    char *color2;
    char *color3;
    char *color4;
    char *color5;
    char *color6;
};
#endif

#endif /* _mystructs_h_ */
