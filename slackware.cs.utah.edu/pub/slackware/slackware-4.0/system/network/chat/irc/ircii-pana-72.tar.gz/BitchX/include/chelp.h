/*
 * Written and CopyRight by Colten Edwards 03-09-96
 * 
 *
 */

#ifndef __chelp_h
#define __chelp_h

extern void chelp _((char *, char *, char *));

#endif
