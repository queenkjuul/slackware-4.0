/* 
 * IRC-II (C) 1990, 1995 Michael Sandroff, Matthew Green
 * This file (C) 1993, 1995 Aaron Gifford and Jeremy Nelson
 *
 * array.h -- header file for array.c
 * See the COPYRIGHT file for copyright information
 *
 */

#ifndef ARRAY_H
#define ARRAY_H

#include "irc_std.h"

char *function_indextoitem (char *);
char *function_itemtoindex (char *);
char *function_igetitem (char *);
char *function_getitem (char *);
char *function_setitem (char *);
char *function_finditem (char *);
char *function_matchitem (char *);
char *function_rmatchitem (char *);
char *function_getmatches (char *);
char *function_getrmatches (char *);
char *function_delitem (char *);
char *function_numitems (char *);
char *function_getarrays (char *);
char *function_numarrays (char *);
char *function_delarray (char *);
char *function_ifinditem (char *);
char *function_ifindfirst (char *);
char *function_listarray (char *);
char *function_gettmatch (char *);
char *function_igetmatches(char *);
char *function_igetrmatches (char *);
void delete_all_arrays(void);

#endif
