
/* PM specific stuff */
#ifndef _PMBITCHX_H
#define _PMBITCHX_H

#define FONTDIALOG          256

#define IDM_MAINMENU        1024

#define IDM_MAIN            1025
#define IDM_JOIN            1026
#define IDM_USER            1027
#define IDM_SERVER          1028
#define IDM_CDCC            1029

/* Main menu, resource IDs 1100-> */
#define IDM_M_QUIT          1100
#define IDM_M_FONT          1101

/* Window menu, resource IDs 1200-> */
#define IDM_W_NEW           1200
#define IDM_W_REFRESH       1201

/* Window data, located at QWP_USER */
typedef struct {
  HVPS    hvps;
  Screen *screen;
} MYWINDATA, *PMYWINDATA;

#define QWP_USER 0
#endif
