#!/bin/sh
echo $1 > /tmp/chef.tmp
chef < /tmp/chef.tmp|tr '\n' '  '
rm /tmp/chef.tmp
