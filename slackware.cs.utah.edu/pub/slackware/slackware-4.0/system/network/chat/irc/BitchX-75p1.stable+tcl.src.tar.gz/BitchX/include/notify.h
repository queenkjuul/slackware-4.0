/*
 * notify.h: header for notify.c
 *
 * Written By Michael Sandrof
 *
 * Copyright(c) 1990 
 *
 * See the COPYRIGHT file, or do a HELP IRCII COPYRIGHT 
 *
 * @(#)$Id: notify.h,v 1.12 1995/08/31 03:51:48 scottr Exp $
 */

#ifndef __notify_h_
#define __notify_h_

	void	show_notify_list (int);
	void	notify (char *, char *, char *, char *);
	void	do_notify (void);
	void	notify_mark (char *, char *, int, int);
	void	save_notify (FILE *);
	void	set_notify_handler (Window *, char *, int);
	void	make_notify_list (int);
	int	hard_uh_notify (int, char *, char *, char *);
extern	char	*get_notify_nicks (int, int, char *, int);
	void	add_delay_notify (int);
			
#endif /* __notify_h_ */
