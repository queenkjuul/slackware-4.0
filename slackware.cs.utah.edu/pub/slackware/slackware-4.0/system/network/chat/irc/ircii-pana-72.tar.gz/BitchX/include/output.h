/*
 * output.h: header for output.c 
 *
 * Written By Michael Sandrof
 *
 * Copyright(c) 1990 
 *
 * See the COPYRIGHT file, or do a HELP IRCII COPYRIGHT 
 *
 * @(#)$Id: output.h,v 1.13 1995/09/06 22:05:07 scottr Exp $
 */

#ifndef __output_h_
#define __output_h_

	void	put_it (const char *, ...) __A(1);
	void	send_to_server (const char *, ...) __A(1);
	void	my_send_to_server (int, const char *, ...) __A(2);
	void	say (const char *, ...) __A(1);
	void	bitchsay (const char *, ...) __A(1);
	void	serversay (int, const char *, ...) __A(2);
	void	yell (const char *, ...) __A(1);
	void	help_put_it (const char *, const char *, ...) __A(2);

	void	refresh_screen _((unsigned char, char *));
	int	init_screen _((void));
	void	put_file _((char *));

extern	FILE	*irclog_fp;

#endif /* __output_h_ */
