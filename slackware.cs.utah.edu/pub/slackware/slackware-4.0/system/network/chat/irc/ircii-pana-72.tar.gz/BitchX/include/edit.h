/*
 * edit.h: header for edit.c 
 *
 */

#ifndef __edit_h_
#define __edit_h_

#include "irc_std.h"

extern	char	*sent_nick;
extern	char	*sent_body;
extern	char	*recv_nick;

	void	load _((char *, char *, char *));
	void	send_text _((char *, char *, char *, int, int));
	void	eval_inputlist _((char *, char *));
	int	parse_command _((char *, int, char *));
	void	parse_line _((char *, char *, char *, int, int));
	void	edit_char _((unsigned char));
	void	execute_timer _((void));
	void	ison_now _((char *, char *));
	void	query _((char *, char *, char *));
	void	quote_char _((char, char *));
	void	type_text _((char, char *));
	void	parse_text _((char, char *));
	void	irc_clear_screen _((char, char *));
	int	check_wait_command _((char *));
	void	ExecuteTimers _((void));
	void	my_clear _((char *, char *, char *));
	void	reconnect_cmd _((char *, char *, char *));			
extern	void	e_hostname _((char *, char *, char *));
	int	check_mode_lock _((char *, char *, int));
	void	away _((char *, char *, char *));
	void	e_quit _((char *, char *, char *));
	void	destroy_call_stack _((void));
	void	unwind_stack _((void));
	void	wind_stack _((char *));
		
		
#define AWAY_ONE 0
#define AWAY_ALL 1

#define STACK_POP 0
#define STACK_PUSH 1
#define STACK_SWAP 2

#define TRACE_OPER	0x01
#define TRACE_SERVER	0x02
#define TRACE_USER	0x04

#define STATS_LINK	0x001
#define STATS_CLASS	0x002
#define STATS_ILINE	0x004
#define STATS_KLINE	0x008
#define STATS_YLINE	0x010
#define STATS_OLINE	0x020
#define STATS_HLINE	0x040
#define STATS_UPTIME	0x080
#define STATS_MLINE	0x100


extern IrcCommandDll *dll_commands;

#endif /* __edit_h_ */
