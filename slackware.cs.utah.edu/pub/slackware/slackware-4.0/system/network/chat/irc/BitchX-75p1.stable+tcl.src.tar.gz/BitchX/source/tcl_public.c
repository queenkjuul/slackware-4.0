
#ifdef WANT_TCL
#include <tcl.h>
#include "irc.h"
#include "struct.h"
#include "screen.h"
#include "server.h"
#include "tcl_bx.h"


/* 
 * I wish to thank vore!vore@domination.ml.org for pushing me 
 * todo something like this, although by-Tor requested 
 * something like this as well but not so succintly
 */


int tcl_bots STDVAR;
int tcl_ircii STDVAR;
int tcl_validuser STDVAR;
int tcl_pushmode STDVAR;
int tcl_flushmode STDVAR;
int Tcl_LvarpopCmd STDVAR;
int Tcl_LemptyCmd STDVAR;
int Tcl_LmatchCmd STDVAR;
int Tcl_KeyldelCmd STDVAR;
int Tcl_KeylgetCmd STDVAR;
int Tcl_KeylkeysCmd STDVAR;
int Tcl_KeylsetCmd STDVAR;
int tcl_maskhost STDVAR;
int tcl_onchansplit STDVAR;
int tcl_servers STDVAR;
int tcl_chanstruct  STDVAR;
int tcl_channel STDVAR;
int tcl_channels STDVAR;
int tcl_isop  STDVAR;
int tcl_getchanhost  STDVAR;
int matchattr  STDVAR;
int tcl_finduser  STDVAR;
int tcl_findshit  STDVAR;
int tcl_date  STDVAR;
int tcl_getcomment  STDVAR;
int tcl_setcomment  STDVAR;
int tcl_time  STDVAR;
int tcl_ctime  STDVAR;
int tcl_onchan  STDVAR;
int tcl_chanlist STDVAR;
int tcl_unixtime  STDVAR;
int tcl_putlog STDVAR;
int tcl_putloglev  STDVAR;
int tcl_rand   STDVAR;
int tcl_timer  STDVAR;
int tcl_killtimer  STDVAR;
int tcl_utimer   STDVAR;
int tcl_killutimer  STDVAR;
int tcl_timers  STDVAR;
int tcl_utimers  STDVAR;
int tcl_putserv  STDVAR;
int tcl_putscr  STDVAR;
int tcl_putdcc  STDVAR;
int tcl_putbot  STDVAR;
int tcl_putallbots  STDVAR;
int tcl_bind  STDVAR;
int tcl_tellbinds  STDVAR;
int tcl_bind  STDVAR;
int tcl_strftime  STDVAR;
int tcl_cparse  STDVAR;
int tcl_userhost  STDVAR;
int tcl_getchanmode  STDVAR;
int tcl_msg  STDVAR;
int tcl_say  STDVAR;
int tcl_desc   STDVAR;
int tcl_notice  STDVAR;
int tcl_bots  STDVAR;
int tcl_clients  STDVAR;
int tcl_alias  STDVAR;
int tcl_get_var  STDVAR;
int tcl_set_var  STDVAR;
int tcl_fget_var  STDVAR;
int tcl_fset_var  STDVAR;
int tcl_aliasvar STDVAR;
extern void add_tcl_alias (Tcl_Interp *, void *, void *);















#if 0
void init_ircii_vars(Tcl_Interp *intp)
{
	for (
}
#endif

void init_public_tcl(Tcl_Interp *intp)
{
	Tcl_CreateCommand(intp, "ircii",	tcl_ircii,	NULL,NULL);
/* 
 * a couple of these have been borrowed from TclX as they are useful and not
 *  everyone has tclx installed on there system.
 */
	Tcl_CreateCommand(intp, "validuser",	tcl_validuser, NULL, NULL);
	Tcl_CreateCommand(intp, "pushmode",	tcl_pushmode, NULL, NULL);
	Tcl_CreateCommand(intp, "flushmode",	tcl_flushmode, NULL, NULL);
	Tcl_CreateCommand(intp, "lvarpop",	Tcl_LvarpopCmd, NULL, NULL);
	Tcl_CreateCommand(intp, "lempty",	Tcl_LemptyCmd, NULL, NULL);
	Tcl_CreateCommand(intp, "lmatch",	Tcl_LmatchCmd, NULL, NULL);
	Tcl_CreateCommand(intp, "keyldel",	Tcl_KeyldelCmd, NULL, NULL);
        Tcl_CreateCommand(intp, "keylget",	Tcl_KeylgetCmd, NULL, NULL);
        Tcl_CreateCommand(intp, "keylkeys",	Tcl_KeylkeysCmd, NULL, NULL);
        Tcl_CreateCommand(intp, "keylset",	Tcl_KeylsetCmd, NULL, NULL);
	Tcl_CreateCommand(intp, "maskhost",	tcl_maskhost,	NULL,NULL);
	Tcl_CreateCommand(intp, "onchansplit",	tcl_onchansplit,NULL,NULL);
	Tcl_CreateCommand(intp, "servers",	tcl_servers,	NULL,NULL);
	Tcl_CreateCommand(intp, "chanstruct",	tcl_chanstruct,	NULL,NULL);
	Tcl_CreateCommand(intp, "channel",	tcl_channel,	NULL,NULL);
	Tcl_CreateCommand(intp, "channels",	tcl_channels,	NULL,NULL);
	Tcl_CreateCommand(intp, "isop",		tcl_isop,	NULL,NULL);
	Tcl_CreateCommand(intp, "getchanhost",	tcl_getchanhost,NULL,NULL);
	Tcl_CreateCommand(intp, "matchattr",	matchattr,	NULL,NULL);
	Tcl_CreateCommand(intp, "finduser",	tcl_finduser,	NULL,NULL);
	Tcl_CreateCommand(intp, "findshit",	tcl_findshit,	NULL,NULL);
	Tcl_CreateCommand(intp, "date",		tcl_date,	NULL,NULL);
	Tcl_CreateCommand(intp, "getcomment",	tcl_getcomment, NULL,NULL);
	Tcl_CreateCommand(intp, "setcomment",	tcl_setcomment, NULL,NULL);
	Tcl_CreateCommand(intp, "time",		tcl_time,	NULL,NULL);
	Tcl_CreateCommand(intp, "ctime",	tcl_ctime,	NULL,NULL);
	Tcl_CreateCommand(intp, "onchan",	tcl_onchan,	NULL,NULL);
	Tcl_CreateCommand(intp, "chanlist",	tcl_chanlist,	NULL,NULL);
	Tcl_CreateCommand(intp, "unixtime",	tcl_unixtime,	NULL,NULL);
	Tcl_CreateCommand(intp, "putlog",	tcl_putlog,	NULL,NULL);
	Tcl_CreateCommand(intp, "putloglev",	tcl_putloglev,	NULL,NULL);
	Tcl_CreateCommand(intp, "rand",		tcl_rand,	NULL,NULL);
	Tcl_CreateCommand(intp, "timer",	tcl_timer,	NULL,NULL);
	Tcl_CreateCommand(intp, "killtimer",	tcl_killtimer,	NULL,NULL);
	Tcl_CreateCommand(intp, "utimer",	tcl_utimer,	NULL,NULL);
	Tcl_CreateCommand(intp, "killutimer",	tcl_killutimer,	NULL,NULL);
	Tcl_CreateCommand(intp, "timers",	tcl_timers,	NULL,NULL);
	Tcl_CreateCommand(intp, "utimers",	tcl_utimers,	NULL,NULL);
	Tcl_CreateCommand(intp, "putserv", 	tcl_putserv, 	NULL, NULL);
	Tcl_CreateCommand(intp, "putscr",	tcl_putscr,	NULL, NULL);
	Tcl_CreateCommand(intp, "putdcc",	tcl_putdcc,	NULL, NULL);
	Tcl_CreateCommand(intp, "putbot",	tcl_putbot,	NULL, NULL);
	Tcl_CreateCommand(intp, "putallbots",	tcl_putallbots,	NULL, NULL);
	Tcl_CreateCommand(intp, "bind",		tcl_bind,	(ClientData)0,NULL);
	Tcl_CreateCommand(intp, "binds",	tcl_tellbinds,	(ClientData)0,NULL);
	Tcl_CreateCommand(intp, "unbind",	tcl_bind,	(ClientData)1,NULL);
	Tcl_CreateCommand(intp, "strftime",	tcl_strftime,	NULL,NULL);
	Tcl_CreateCommand(intp, "cparse",	tcl_cparse,	NULL,NULL);
	Tcl_CreateCommand(intp, "userhost",	tcl_userhost,	NULL,NULL);
	Tcl_CreateCommand(intp, "getchanmode",	tcl_getchanmode,NULL,NULL);
	Tcl_CreateCommand(intp, "msg",		tcl_msg,	NULL,NULL);
	Tcl_CreateCommand(intp, "say",		tcl_say,	NULL,NULL);
	Tcl_CreateCommand(intp, "desc",		tcl_desc,	NULL,NULL);
	Tcl_CreateCommand(intp, "notice",	tcl_msg,	NULL,NULL);
	Tcl_CreateCommand(intp, "bots",		tcl_bots,	NULL, NULL);
	Tcl_CreateCommand(intp, "clients",	tcl_clients,	NULL, NULL);
	Tcl_CreateCommand(intp, "rword",	tcl_alias, NULL, NULL);

	Tcl_CreateCommand(intp, "get_var",	tcl_get_var, NULL, NULL);
	Tcl_CreateCommand(intp, "set_var",	tcl_set_var, NULL, NULL);
	Tcl_CreateCommand(intp, "fget_var",	tcl_fget_var, NULL, NULL);
	Tcl_CreateCommand(intp, "fset_var",	tcl_fset_var, NULL, NULL);
	add_tcl_alias(intp, tcl_alias, tcl_aliasvar);
}

typedef struct _tcl_var {
	char	*name;
	char	*var;
	int	length;
	int	flags;
} TclVars;

TclVars tcl_vars[] =
{
/*	{ "realname",	realname,	REALNAME_LEN,	TCL_GLOBAL_ONLY},*/
	{ "username",	username,	NAME_LEN,	TCL_GLOBAL_ONLY},
	{ "nickname",	nickname,	NICKNAME_LEN,	TCL_GLOBAL_ONLY},
	{ "version",	(char *)irc_version,29,		TCL_GLOBAL_ONLY},
	{ NULL,		NULL,		0,		0}
};

extern char *ircii_rem_str(ClientData *, Tcl_Interp *, char *, char *, int);
void init_public_var(Tcl_Interp *intp)
{
int i;
	for (i = 0; tcl_vars[i].name; i++)
		Tcl_SetVar(intp, tcl_vars[i].name, tcl_vars[i].var, tcl_vars[i].flags);
	if (current_window && current_window->current_channel)
		Tcl_SetVar(intp,"curchan",current_window->current_channel, TCL_GLOBAL_ONLY);
	if (from_server > -1)
	{
		Tcl_SetVar(intp,"server",server_list[from_server].name,TCL_GLOBAL_ONLY);
		Tcl_SetVar(intp,"botnick",get_server_nickname(from_server),TCL_GLOBAL_ONLY);
		Tcl_SetVar(intp,"nick",get_server_nickname(from_server),TCL_GLOBAL_ONLY);
	}
	else
		Tcl_SetVar(intp, "server", "none", TCL_GLOBAL_ONLY);
}
#endif
 