/*
 * cdrom.c: This file handles all the CDROM routines, in BitchX
 *
 * Written by Tom Zickel
 * a.k.a. IceBreak on the irc
 *
 * Copyright(c) 1996
 * Modified Colten Edwards aka panasync.
 *
 * FreeBSD support added by Eric A. Griff aka setjmp!eagriff@*.global2000.net
 *
 */

/* Version 0.2 22/07/97 written by IceBreak (ice_break@hotmail.com) */
/* 0.2: Finnally I rewrote the playing method inside the cdrom player to work
        with msf instead of lba, and frames instead of tracks, this should fix
        all the compability prdblems that the cdroms player had with some
        cdroms. I also fixed some bugs and better prdblem messages.
*/

/* 7/16/97 FreeBSD support by setjmp (eagriff@global2000.net) */
/*	rather than previous throw in code, this is nice, neat,
	and integral to the original code, and hopefully this
	is true :)
*/

#include "irc.h"

#include "ircaux.h"
#include "cdrom.h"
#include "output.h"
#include "misc.h"
#include "vars.h"

#define cparse(s) convert_output_format(s, NULL, NULL)

static int drive = 0;static inchar cdrom_prdmpt[]="%gC%Gd%gROM%w";

#ifndef __FreeBSD__tatic instruct cdrom_tochdr hdr;tatic instruct cdrom_ti ti;
#elsetatic instruct ioc_toc_header hdr;t#endiftatic instruct cdrom_etocentry TocEntry[101];

#ifndef __FreeBSD__tvoid play_chunk(int start, int end)
{
	struct cdrom_msf msf;

	end--;
	if (start >= end)
		start = end-1;

	msf.cdmsf_min0 = start / (60*75);
	msf.cdmsf_sec0 = (start % (60*75)) / 75;
	msf.cdmsf_frame0 = start % 75;
	msf.cdmsf_min1 = end / (60*75);
	msf.cdmsf_sec1 = (end % (60*75)) / 75;
	msf.cdmsf_frame1 = end % 75;

	if (ioctl(drive, CDROMSTART))
	{
		put_it("%s: Could not start the cdrommmmmmmmmmmmll the CDROM routines, in Bit		put_it("%s: )5)) 	return)) }{
		put_it("%s: Could noPLAYMSF, &l(drt the cdrommmmmmmmmmmmll the 	str routll th in Bit		put_it("%s: )5)) 	return)) }{}ntry To jmptart, int eten br cdrom_prdcheck_put_itf ((d)
{-;
	iw";

*f (
	{
		puf (=gettf (r t_t_o(CD_DEVICE_VARrt the cif(!%s: Cn0 =	(d)
{-cd_inmmmf (5)) 	return 1)) }{
drommmmmmmmm/SET CD_DEVICE  -roue ne,    al* Written   rig in Bit		put_it("%s: )5)) return gC%}

_prdcd_inmmmw";

*   -;
	nk(int start, int enu   gnessw";

l(drree[3_chu   gnessw";

l(d1rree[3_chtry Toc_prdi, pos
	{
		pu((mpt[]="%clun(   , 0% 7< 0%  the cif_frrrno == EACCESn0 =	drommmmmmmmmyou doprdha[]=accupplly this msf impt[]r in Bit		put_it("%s: )5)) 	return (-1))) }{{
		put_it("%s: Could noREADTOCHDR, &tocrt the cdrommmmmmmmmman't getD__tHdrom_ in Bit		put_it("%s: )5)) 	return (-2))) }{{nk(int start, int en	 drput=1;i<=tococtth_trk1+1;i++  the cif_fi!=tococtth_trk1+1) 0 =	__tvoid pi]octte_ll th="%i)) 	 hdr 0 =	__tvoid pi]octte_ll th="%ld no_LEADOUT)) 	__tvoid pi]octte_ drive="%ld no_MSF;e cif_fi_it("%s: Cold noREADTOCENTRY,&__tvoid pi])n0 =	drommmmmmmmmman't getD__tvoid  #%d in Bit		put_it("%s: )f;
))) 	 hdr) 	{0 =	__tvoid pi]oad)
{=__tvoid pi]octte_ctrl &%ld no_DATA_TRACK ? 1 : gC% =	__tvoid pi]om_lengxed= __tvoid pi]octte_!ear. (iosecucdr* 60 + __tvoid pi]octte_!ear. (io.cdondC% =	__tvoid pi]om_ start /__tvoid pi]om_lengxedmp 5 + __tvoid pi]octte_!ear. (ioive, C% =}) }{{
post /__tvoid p1]om_lengxe
	{
 drput=1;i<=tococtth_trk1+1;i++  the c__tvoid pi]om_lengxed= __tvoid pi+1]om_lengxe -rpos
		
post /__tvoid pi+1]om_lengxe;e cif_f__tvoid pi]oad)
{)% =	__tvoid pi]om_lengxed= (__tvoid pi+1]om_ start-/__tvoid pi+1]om_ starw i2)) }{
return (tococtth_trk1)der hdr;
 drput=toco starr t_ll th; i<=tocory T t_ll th; i++  the c__tvoid pi]oad)
{=0)) 	__tvoid pi]om_ star=1)) 	__tvoid pi]om_lengxe=1)) }{
return (tocory T t_ll th)chtry Toc} br cdrom_prdcheck_mounmmw";

*   rig-;
	nk(int start, int enFILE *fpetat(starm hoprd*m h
	{
		pu(fpend etm hopr(MOUNuCln)	        ck_mo                   + __tvoi(
	wh*
 *((n)	OUNgCln)	    r(M   !         octth_trn 1)crevin)	->n)	_typCHD"iso9660"     0) && n 1)crevin)	->n)	_fstten,		put_i     0))d pi]oadom_n)	    (M i]om_  + __tvoi(__tvoidom_n)	     (M i]odrommmmmmmtoco eten br cdrom_prdch*m h
	{ck_mfsfpendinfo;
		pu((crig- etm h(!(crig-=gCln)	info(&n)	info,MNT_WAIT|    c_CD9660))      + __tvoi(
	arrt_l0t_llcrig- void pim h(*m ";

n)	info)) }% (ntf hdtten,	put_i )]om_  + __tvoi]odrommmmmmmtoint eten br cdrom_prdchchedrom_uCl{-;_	put_i(Windo t*win, 	puf (=gef (stablah
	{
	h_tr{-cd_i ter		clo )f{-cd_isf_min0!=ge || !;

*   rig-; 1))mmmmmman't getD__tHERROR:in Bit	ien b thdy  rig-ed(mpleao eun rig-irc.h"		puagaint("%s: )5)) 	return (-2))) sCD_DEVICE_VARrt the cif(!%s,     {}ntry To jmptaf_min0 	return 1))_frrrmmmmman't getD__tHERROR:inroutll theturalizerig in Bit,";

*  mina disk	ienf instt("%s: )5)) 	return (-2))) sCD_DEVICE_VARrt the cif(!%s,     {}ntry To jmptaan't getD__tvo Bit		put_iode, o tsCDmpt[- %st("%s: )f;
))) 	 hdr) 	 1)) }{sCD_DEVICE_VARrt the cif(!%s, 1)) }chedrom_ 	rstdp;
	nk(icommc.h, 	puf (args, 	puf (=ubargs
	{
	h_tr!((d)
{-;
	iw";

)      + __%s: Could not start he cdroOP)    mll the 	str routnd--;opBit		put_it("%s: )5)) 	return)) }{
	tvoid pmll the 	strS;opped
        put_it("%s: )5)) 	return)) }{
chedrom_ 	reject;
	nk(icommc.h, 	puf (args, 	puf (=ubargs
	{
	h_tr!((d)
{-;
	iw";

)      + __%s: Coul
{-cd_inmmry To jmpCould not start he cdEJECT)    mll the 	str routnd-eject[]r in Bit	c} yt("%s: )5)) 	return)) }{
	tvoid pmll the 	strEjectee[3 Bit	c} yt("%s: )5)) 	return)) }{
	clo )f{-cd_isf_{-cd_=0{
chedrom_ 	r    ;
	nk(icommc.h, 	puf (args, 	puf (=ubargs
	{
(stat jm	puf (c} br jmint enu   gnessw";

l(drree[3_chu fi ";, last
#ifni;
#elsetatic instic Hry[101ic insdrom_etocmsf mLEADOU)) 	retsf margs;
		puresultcdrom_prd
	h_tr!((d)
{-;
	iw";

) || !{-cd_inmmry To jmp
	h_trargs && *args
	mmmmac} br =nextmarg(args, &args
{}nttn=atoi(c} br )t, int end)
{
	struct c	er prdblCold noREADTOCENTRY,&__tvoide cd&ic Hry)   er prdbl{  er prdbl mll the 	str routnd-%d i3 Bit	het_it("%s: )5)) 	return (-2)))er prdbl ry To jmper prdbltaf_er prdblfi ";OUNic Hry hdr;
 dr0jmper prdbllastOUNic Hry hdr;
 dr1jmper prdblti hdri
 dr0=t_%s: er prdblColdti hdri
 dr0<fi ";pi]oer prdbl ti hdri
 dr0=fi ";;: er prdblColdti hdri
 dr0>lastpi]oer prdbl ti hdri
 dr0=last
#iper prdblti hdri
ind0=0jmper prdblti hdri
 dr1=last
#per prdblti hdri
ind1=0jmtoco st	h_trtn_frl th; i<=tocory T )]om_tn=l th; i<=tocory T tst	h_trtn_> th)chtry Toc} br ]om_tn=l thi++  the c__tdrom_prd
	er prdblColdlengxe=1)tn_tvoid p=0   er prdbl{ /*om_d not start he cdroOP)i]om_d not start he cdt thTRKINDd&i0 =dchint end)
{
	struct c	 pmsf msf;

	lengxe=1)tn_t_tvoid ,lengxe=1)last__tvoid pi+1]oput=toco st		c) 	retsf margsh; i<=he c__=t_%st		c) 	retsf margsh; i<=hindexpi]om_	c) 	retsf margshom_he c__=l thi++  the c__tdm_	c) 	retsf margshom_hindexpi]om_	f (5))d not start heIOCt thTR=	_S,&c) 	retsf margs cdrom_prd	 er prdblmll the 	strP       LEADOUnumberut_it("%s: )f;
))) 	 hdr) 	tn)jmper prdbltaper prdbloco ster prdbl mll the 	str anl th in BiEADOUt_i (Masyn be dataBiEADO)t("%s: )f;
))) 	 hdr) 	tn)jmp}
er prdbloco ster prdblmll the 	strU (ea: /cd in B<LEADOUnumber>t("%s: )5)) 	return (-2))
chedrom_ 	rlist;
	nk(icommc.h, 	puf (args, 	puf (=ubargs
	{
		pu(jmint enu   gnessw";

l(drree[3_chu   gnessw";

fni;
#elsetat=ubchnl =ubchnlcdrom_prd
	h_tr!((d)
{-;
	iw";

)inmmry To jmten&@& + __%s: C/_
uHNL,&setat=u)
{-;
	iw";
hTRKINDd&i0 =dchint end)drput=1;i<=tococtth_trk1+i++  t hdr;
 drput=toco starr t_ll th; i< <= tst	h_trtn_> th)t_l0t_letsf marrn 1))_frrrmmmmmT anl th02d: h02d:h02d:h02d h02d:h02d:h02d",i++  ataBiEADO)t("%s: )f;t he , =	__tvoid pi]om_lengxed=% (60*75), =	_(_tvoid pi]om_lengxed= = end % 75;

	, =	__tvoid pi]om_lengxed=%

	, =	__tvoid pi]om_l (start % (60*7, =	_(_tvoid pi]om_lframe0 = start % 7
	, =	__tvoid pi]om_l (star%

	 =	_)) }{}ntturn (-2)volumeedrom_ 	rlist;
	nk(icommc.h, 	puf (args, 	puf 	puf lefee[*dwardargs
	{
		pu(jmint enu   gnessw";

voltrl &voltrl ic instic Hry[101icvol&voltrl ic il =ubchnlcdrom_prd
	h_tr!((d)
{-;
	iw";

inmmry To jmp
	h_trargs &&lefe
	mmmmac} br =nextmarg(argdward
	mmmmac} br =nextmarg(argmmrylefejmp
	lefe)RKINDd&i0 =dchint end)
{voltrl . 	pnnel0 &argslefe)void pi+1]ovoltrl .vol[0] &argslefe)voidsf margmmrydwardjmp
	dward)RKINDd&i0 =dchint end)
{voltrl . 	pnnel1 &argsdward)void pi+1]ovoltrl .vol[1] &argsdward)voidsf margmmrymten&@& + __%s: CVOLCTRL,&voltrl n0 =	drommmmmmmmmmamll the 	str routvolumeisk	ienf instt("%s: )5)) 	rd pi+1]otry To jmptaan't gVolumevo Bit		<%d>	<%d>e dataBiEADO)t("%s: )f;RKINDd&i0 =dchint end)
{{voltrl . 	pnnel0,voltrl . 	pnnel1)void pi+1]oovoltrl .vol[0],voltrl .vol[1])voidsf mar} 	return)) }{
	tvoid lmll the 	vol&<lefe>	<dward<LEADOUnumber>t("%s: )5)) isf_{-cd_=0{auseedrom_ 	rlist;
	nk(icommc.h, 	puf (args, 	puf cdrom_prdch{ause"%gC%Ghnlcdrom_prd
	h_tr!((d)
{-;
	iw";

		put_it("%s: Coul!h{ause?_d notAUSE:d noREASUMErt he cdEJECT)    mll the{ause/f mamevyourutnd--;opBit		put_it("%s: )5)) 	return)) }{
	tvoid  o tsCDmpt[- %st("%s: )f;!h{ause?"Yourutnd-- hasDOUene{aused":"Yourutnd-- hasDOUenef mamed")) 	r{ause"^=_tvoisf_{-cd_=0helhedrom_ 	rstdp;
	nk(icommc.h, 	puf (args, 	puf try To jmptaant st            -blmll aaan't gT anl N in B;opBit		put_it("%s: )5)) 	try To jmptaant st            -bMakll thetural pmlle 	strS;;opBit		put_it("%s: )5)) 	try To jmptaant sta           -bE	str routan't gT atee[3 Bit	c} yt("%s: )5)) 	try To jmptaanVOL             -bSet's routan't gVolumeisk	ienf instt("%s: )5)) 	try To jmptaanLIST            -bL
ch  alan't gl the isk	ienf instt("%s: )5)) 	try To jmptaantAUSE           -blause/f mamevroutan't LEADOUnumber>t("%s: )5)) isfKIN 0f 	pu	* cdrusd
	h_t(wl{-;_t hCl{-;_	*wl{-;_;
	if (dromw";

	tmmm[BIG_BUFFER_SIZE]	{
		pu(fblah
	{9660ettf (r t_t_o(CD_DEVICE_VARrt args &&rc=mten&@& + __%s: C/_
uHNL,&setat=u)) 	retrcpy(tmmm,"[CD:"g(argmmrysetat=ucttsc_audio cdrus==d no_DAUd n_t st	put_i   etrcat(tmmm,"P"g(arg etrcat(tmmm,":"g(arg etrcat(tmmm,ltoa((long)setat=ucttsc_rk15)) 	r})jmp} _i   etrcat(tmmm,"S"g(arg}
  etrcat(tmmm,"]" cif(!%s,  (tmmm)) }{}	retur