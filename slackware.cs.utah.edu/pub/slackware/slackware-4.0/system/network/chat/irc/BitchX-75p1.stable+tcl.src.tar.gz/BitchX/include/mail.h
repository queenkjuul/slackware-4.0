/*
 * mail.h: header for mail.c
 *
 * Written By Michael Sandrof
 *
 * Copyright(c) 1990 
 *
 * See the COPYRIGHT file, or do a HELP IRCII COPYRIGHT 
 *
 * @(#)$Id: mail.h,v 1.7 1995/08/31 03:51:44 scottr Exp $
 */

#ifndef __mail_h_
#define __mail_h_

	char	*check_mail (void);
	int	check_mail_status (void);

#endif /* __mail_h_ */
