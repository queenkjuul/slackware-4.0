
#include <config.h>
#include <janbot.h>

/* GLOBALS */

struct user_t *users=NULL;

struct chat_t *chatlist=NULL;

struct dcc_t *dcclist=NULL;
struct deathrow_t *deathrow=NULL;
struct dccqueue_t *dccqueue=NULL;

struct server_t *current_server=NULL;
struct servconn_t sconn;
struct servmsg_t *msgqueue=NULL;

/* The configuration container. */
struct cfg_t cfg;

time_t bot_uptime;

int background=1;

int dcclimit=10;
int autodcc=1;
int resume=0;

#ifdef DEBUG
int traceflag=0;
int function_level=0;
#endif

/* Some filedescriptors */
int userfd; /* Descriptor for the userlist file. */
int logfd; /* Descriptor for the log file. */
int parent; /* Descriptor for communication with the parent process */

/* For publishing the argument list */
int p_argc;
char **p_argv;

#ifdef USE_RATIOS
int ratio;
unsigned long long ul;
unsigned long long dl;
unsigned long long cred;
#endif

struct in_addr hostaddr;
char hostname[256];
unsigned long local_ip;
struct hostent *local_hp;

/* This is some oddstuff for the user add command. */
struct uhost_query uhquery;

/* List of commands */
/* Currently the only valid levels are 0, 1 and 2. */
/* Should be alphabetically sorted, as binary search might be added later. */
struct cmd_t cmdlist[]={
{ "ADD",	cmd_add,	 1 },
#ifdef USE_RATIOS
{ "ADJUST",	cmd_adjust,	 2 },
#endif
{ "CD",		cmd_cd,		 0 },
{ "CUTCON",	cmd_cutcon,	 1 },
{ "DEL",	cmd_del,	 2 },
{ "DIR",	cmd_dir,	 0 },
#ifdef USE_RATIOS
{ "DONATE",	cmd_donate,	 0 },
#endif
{ "GET",	cmd_send,	 0 },
{ "HELP",	cmd_help,	 0 },
{ "HINT",	cmd_hint,	 0 },
{ "KILLDCC",	cmd_killdcc,	 0 },
{ "KILLQ",	cmd_killq,	 0 },
{ "LIMIT",	cmd_limit,	 0 },
{ "LS",		cmd_dir,	 0 },
{ "MKDIR",	cmd_mkdir,	 0 },
{ "NEXT",	cmd_next,	 0 },
{ "PASSWD",	cmd_passwd,	 0 },
#ifdef USE_RATIOS
{ "RATIO",	cmd_ratio,	 2 },
#endif
{ "REHASH",	cmd_rehash,	 2 },
{ "RELEVEL",	cmd_relevel,	 2 },
{ "RETIRE",	cmd_retire,	 2 },
{ "SEND",	cmd_send,	 0 },
{ "SERVER",	cmd_server,	 2 },
{ "SET",	cmd_set,	 0 },
{ "SETPASS",	cmd_setpass,	 2 },
{ "SHOWDCC",	cmd_showdcc,	 0 },
{ "SHOWQ",	cmd_showq,	 0 },
{ "STATUS",	cmd_status,	 2 },
#ifdef DEBUG
{ "TEST",	cmd_test,	 2 },
#endif
{ "USERS",	cmd_users,	 0 },
{ "WHO",	cmd_who,	 1 },
{ "WHOAMI",	cmd_whoami,	 0 },

{ NULL,		NULL,		-1 } /* Marks end of array */
};

/* These comments are from the previous JanBot, the ircII bot. */
char *toolowlist[]={
"Are you insane?\n",
"You fail to invent a new command.\n",
"Maybe you should try HELP?\n",
"The hideous lag monster swallows your command. Try again.\n",
"Yes, and may banana peels fall out your butt.\n",
"Hmmm... I need more exact instructions.\n",
"You just called me a bastard, didn't you?!\n",
"You really need some spell amelioration...\n",
"My language is English, what is your's?\n",
"?oot era uoy ebyam ,sdrawkcab gniklat m'I\n",
"There's only one word for people like you: Supercalifragilisticexpialidocious.\n",
"Is this a trick question?\n",
"Gee, your spelling is so bad you must be from Germany!\n",
"?\n",
"Oh yeah, you and what army?\n",
"Exsqueeze me? Baking powder?\n",
"I'm not taking any orders from you!\n",
"You're damned if you do and you're damned if you don't!\n",
"There should be a neat comment here, but I can't think of one right now.\n",
"[Funny comment goes here]\n",
"I can't believe you said that!\n",
"What we have here is a failure to communiucate.\n",
"Shaddap, or I'll smack you!\n",
"Oh, sorry, I wasn't paying attention...\n",
"You know it's funny, I heard that exact same comment the other day.\n",
"Your puny hacking attempt has been logged by the FBI.\n",
"Sorry, I don't do requests.\n",
"Commands, who needs them?!\n",
"Something successfully did not happen.\n",
"Oh yeah? What do I look like, a psychic? You want me to guess what you want?\n",
"Go away, can't you see we're closed?!\n",
"Please insert coin.\n",
"Don't make me resort to violence.\n",
"Don't make me laugh.\n",
"Stop sex talking me!\n",
"Please keep your ass tight.\n",
"Duc Duc Gnouf?\n",
"Whahaha!!\n",
"Oink... ddup dup!\n",
"Run that by me again?\n",
"You didn't say \"please\".\n",
NULL
};


