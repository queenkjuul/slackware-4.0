#ifndef _myvars_h_
#define _myvars_h_

#include "mystructs.h"

#ifdef WANTANSI
/* Index of colors in Colors table */
#define COLOFF       0
#define COLBOLD      1
#define COLUNDERLINE 2
#define COLFLASH     3
#define COLREV       4
#define COLBLACK     5
#define COLRED       6
#define COLGREEN     7
#define COLYELLOW    8
#define COLBLUE      9
#define COLPURPLE    10
#define COLCYAN      11
#define COLWHITE     12
#define COLBLACKBG   13
#define COLREDBG     14
#define COLGREENBG   15
#define COLYELLOWBG  16
#define COLBLUEBG    17
#define COLPURPLEBG  18
#define COLCYANBG    19
#define COLWHITEBG   20
/* Index of commands in CmdsColors table */
#define COLWARNING   0
#define COLJOIN      1
#define COLMSG       2
#define COLNOTICE    3
#define COLNETSPLIT  4
#define COLINVITE    5
#define COLMODE      6
#define COLSETTING   7
#define COLHELP      8
#define COLLEAVE     9
#define COLNOTIFY    10
#define COLCTCP      11
#define COLKICK      12
#define COLDCC       13
#define COLWHO       14
#define COLWHOIS     15
#define COLPUBLIC    16
#define COLCDCC      17
#define COLLINKS     18
#define COLDCCCHAT   19
#define COLCSCAN     20
#define COLNICK      21
#define COLME        22
#ifdef OPERVISION
#define COLOV        23
#endif
#endif

#define SAVEMSG         1
#define SAVENOTICE      2
#define SAVEMASS        4
#define SAVECOLL        8
#define SAVECDCC       16
#define SAVEDCC        32
#define SAVEPROT       64
#define SAVEHACK      128
#define SAVESRVM      256
#define SAVECTCP      512
#define SAVEFLOOD    1024
#define SAVEINVITE   2048
#define SAVEKILL     4096
#define SAVEKICK     8192
#define SAVESERVER  16384
#define SAVEFAKE    32768
#define SAVEAREPLY  65536
#define SAVECHAT   131072
#define SAVEALL    262143

extern struct friends *frlist;
extern struct autobankicks *abklist;
extern struct words *wordlist;
extern struct nicks *nicklist,*nickcur;
extern struct wholeftstr *wholist;
extern struct delayop *delayoplist;
extern struct delaynotify *delaynotifylist;
extern struct splitstr *splitlist,*splitlist1;
/*extern struct list *nickwatchlist,*tmpnickwatch;*/
extern struct nicks *arlist,*arcur;
#ifdef WANTANSI
extern struct colorstr CmdsColors[NUMCMDCOLORS];
extern char   *Colors[NUMCOLORS];
#endif
extern char   defban;
extern char   bold;
/****** Coded by Zakath ******/
#ifdef TOOLIE
extern char   *ToolieA;
extern char   *ToolieB;
extern char   *ToolieVersion;
#endif
/*****************************/
extern char   *mydefaultserver;
extern char   *CToolzstr;
extern char   *CToolzver;
extern char   *CToolzlame;
extern char   *LastMessage;
extern char   *LastNotice;
#ifdef EXTRA_STUFF
extern char   *EString;
#endif
extern char   *DefaultServer;
extern char   *DefaultSignOff;
extern char   *DefaultSetAway;
extern char   *DefaultSetBack;
extern char   *DefaultUserinfo;
extern char   *DefaultFinger;
extern char   *AutoJoinChannels;
extern char   *ModeLockString;
extern char   *CdccUlDir;
extern char   *CdccDlDir;
extern char   *WhoKilled;
extern char   *InviteChannels;
extern char   *CdccChannels;
extern char   *AutoRejoinChannels;
extern char   *MDopWatchChannels;
extern char   *ShowFakesChannels;
extern char   *KickOnFloodChannels;
extern char   *KickWatchChannels;
extern char   *NHProtChannels;
extern char   *NickWatchChannels;
extern char   *ShowAwayChannels;
extern char   *KickOpsChannels;
extern char   *KickOnBanChannels;
extern char   *BitchChannels;
extern char   *FriendListChannels;
extern char   *EncryptPassword;
extern char   *StatsFilter;
extern char   *LastJoin;
extern char   *AutoReplyBuffer;
extern char   *OrigNick;
extern char   *LastMessageSent;
extern char   *LastNoticeSent;
extern char   *CurrentNick;
extern char   *LastChat;
extern char   *CurrentDCC;
extern char   *DefaultK;
extern char   *DefaultBK;
extern char   *DefaultBKI;
extern char   *DefaultBKT;
extern char   *DefaultFK;
extern char   *DefaultLK;
extern char   *DefaultABK;
extern char   *DefaultSK;
extern char   *PermUserMode;
extern char   *AutoReplyString;
extern int    usersloaded;
extern int    unban;
extern int    inFlierWI;
extern int    inFlierWho;
extern int    inFlierNotify;
extern int    inFlierLinks;
extern int    inFlierFKill;
extern int    inFlierNickCompl;
extern int    inFlierTrace;
extern int    ExtMes;
extern int    NHProt;
extern int    NHDisp;
extern int    AutoGet;
extern int    DeopSensor;
extern int    KickSensor;
extern int    NickSensor;
extern int    AutoAwayTime;
extern int    NickWatch;
extern int    MDopWatch;
extern int    KickWatch;
extern int    NickTimer;
extern int    MDopTimer;
extern int    KickTimer;
extern int    IgnoreTime;
extern int    ShitIgnoreTime;
extern int    AutoRejoin;
extern int    AutoJoinOnInv;
extern int    FloodProt;
extern int    FloodMessages;
extern int    FloodSeconds;
extern int    CdccIdle;
extern int    CdccLimit;
#ifdef EXTRA_STUFF
extern int    RenameFiles;
#endif
extern int    Security;
extern int    ServerNotice;
extern int    CTCPCloaking;
extern int    ShowFakes;
extern int    ShowAway;
extern int    AutoOpDelay;
extern int    LagTimer;
extern int    KickOps;
extern int    KickOnFlood;
extern int    KickOnBan;
extern int    NickChange;
#ifdef SCKICKS
extern int    NumberOfScatterKicks;
#endif
extern int    NumberOfSignOffMsgs;
extern int    ShowNick;
extern int    PlistTime;
extern int    LinksNumber;
extern int    AwaySaveSet;
extern int    ShowWallop;
extern int    AutoReplyEntries;
extern int    LongStatus;
extern long   BytesReceived;
extern long   BytesSent;
extern int    FriendList;
extern int    OrigNickChange;
extern int    IRCQuit;
extern int    NotifyMode;
extern int    URLCatch;
extern int    Ego;
extern int    LogOn;
extern int    ShowDCCStatus;
extern int    DCCDone;
extern int    AutoNickCompl;
extern int    Bitch;
extern int    CdccStats;
#ifdef WANTANSI
extern int    DisplaymIRC;
#endif
/****** Coded by Zakath ******/
extern char   *SPingServers;
extern int    CdccPackNum;
extern int    CdccSendNum;
extern int    CdccRecvNum;
extern int    AwayMsgNum;
extern char   *URLBuffer;
extern char   *VirtualHost;
#if defined(EXTRAS) || defined(FLIER)
extern int    AutoInv;
#endif
#if defined(OPERVISION) && defined(WANTANSI)
extern int    OperV;
#endif
#ifdef TOOLIE
extern int    SentAway;
#endif
#ifdef HAVETIMEOFDAY
extern struct timeval SPingTime;
#else
extern time_t SPingTime;
#endif
/*****************************/
extern time_t LastCheck;
extern time_t LastPlist;
extern time_t LastServer;
extern time_t LastNick;
extern int  from_server;
extern char *FromUserHost;
extern int  set_away;
#ifndef __EMX__
extern struct in_addr local_ip_address;
extern char *channel_join;
#endif

#endif /* _myvars_h_ */
