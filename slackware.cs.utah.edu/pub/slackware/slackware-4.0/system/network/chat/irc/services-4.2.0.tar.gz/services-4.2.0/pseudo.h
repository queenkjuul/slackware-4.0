/* Include extra includes needed by most/all pseudo-clients.
 *
 * Services is copyright (c) 1996-1999 Andy Church.
 *     E-mail: <achurch@dragonfire.net>
 * This program is free but copyrighted software; see the file COPYING for
 * details.
 */

#include "commands.h"
#include "language.h"
#include "timeout.h"
#include "encrypt.h"
#include "datafiles.h"
