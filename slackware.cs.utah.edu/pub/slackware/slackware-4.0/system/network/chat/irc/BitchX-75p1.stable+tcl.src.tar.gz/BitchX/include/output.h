/*
 * output.h: header for output.c 
 *
 * Written By Michael Sandrof
 *
 * Copyright(c) 1990 
 *
 * See the COPYRIGHT file, or do a HELP IRCII COPYRIGHT 
 *
 * @(#)$Id: output.h,v 1.13 1995/09/06 22:05:07 scottr Exp $
 */

#ifndef __output_h_
#define __output_h_

	void	put_echo (char *);
	void	put_it (const char *, ...);
	void	send_to_server (const char *, ...);
	void	my_send_to_server (int, const char *, ...);
	void	say (const char *, ...);
	void	bitchsay (const char *, ...);
	void	serversay (int, int, const char *, ...) __A(3);
	void	yell (const char *, ...) __A(1);
	void	error (const char *, ...) __A(1);
	
	void	help_put_it (const char *, const char *, ...) __A(2);

	void	refresh_screen (unsigned char, char *);
	int	init_screen (void);
	void	put_file (char *);

	void	charset_ibmpc (void);
	void	charset_lat1 (void);
	void	charset_graf (void);

extern	FILE	*irclog_fp;

#endif /* __output_h_ */
