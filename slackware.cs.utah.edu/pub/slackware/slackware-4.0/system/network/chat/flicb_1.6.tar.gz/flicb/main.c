/* Fairlight's ICB Client                                                    */
/* Copyright 1994, Mark Luljak <fairlite@arcadia.aldridge.sol.net>           */
/*                                                                           */

extern int errno;

#include "flicb.h"

int main(argc,argv)
int argc;
char *argv[];
{
     int s,a,y,b,c,input_x,error=0;
     char buffer[STRINGSIZE],*mptr,buff2[STRINGSIZE];
     char inbuffer[STRINGSIZE];
     char *ibptr,*cptr;
     int ibflag=1;
     unsigned char in_chr;
     int inresult=0,rex=0;
     char *qptr;
     unsigned char buflen;
     struct passwd *pwptr;
     WINDOW *mainwin, *inputwin,*blankwin;
     char tmpbuf[STRINGSIZE],tmp2buf[STRINGSIZE];
     char nick[12],group[8],*nickptr,*gpptr;
     char trebuf[STRINGSIZE],*treptr;
     unsigned char l;
     fd_set pending;
     struct infoback mninfo;
     struct infoback *mnptr;
     char statline[80];
     time_t *stmptr;
     int totalinchr=0;
     int ox=0,bx=0;
     char *bbuf,*obuf,oldbuf[STRINGSIZE],backbuf[BACK_BUFF_SIZE];
     char rebuf[STRINGSIZE];
     char *reptr,*reoptr;
     int pauseflag=0;
     char pchar;
     int histbit=1,histon=0,histlen=0,hcpy=0;
     char *hist1,histbuf[14],*hisptr;
     char *tnptr,tmpnick[20],tmpgroup[20];
     int tnumber=0;
     struct timeval yoda;
     struct timeval *yodaptr;

     if (! argv[1]) {
          printf("Usage: flicb nickname [group]\n");
          exit(1);
     }
     sprintf(tmpnick,"%s",argv[1]);
     sprintf(nick,"");
     tnptr=tmpnick;
     for (tnumber=0;tnumber < 12 && *tnptr;tnumber++) {
          sprintf(nick,"%s%c",nick,*tnptr);
          tnptr++;
     }    
     if (!argv[2]) {                          /* See if there's a group as */
          sprintf(group,"1");                 /* Argument one.  Quit if no */
     } else {
          sprintf(tmpgroup,"%s",argv[2]);
          sprintf(group,"");
          tnptr=tmpgroup;
          for (tnumber=0;tnumber < 8 && *tnptr;tnumber++) {
               sprintf(group,"%s%c",group,*tnptr);
               tnptr++;
          }    
     }

     printf("Waiting for server connection...\n");
     nickptr=nick;
     gpptr=group; 
     yodaptr=&yoda;
     yodaptr->tv_sec=60;
     yodaptr->tv_usec=0;
     mnptr=&mninfo;
     mnptr->yres=y;
     mnptr->nickinfo=nick;
     mnptr->groupinfo=group;
     mnptr->dopage=1;
     alertmes=0;
     mnptr->linesup=0;
     mnptr->pageflag=0;
     time((time_t *)&stmptr);
     sprintf(statline,"Nick: %-13s  Group: %-8s  | /h - Help | FLICB %s |  Time: %-6s",mnptr->nickinfo,mnptr->groupinfo,FLICB_VER,ampm(stmptr,0));
     fcntl(fileno(stdin),F_SETFL,O_NDELAY);

     pwptr=getpwuid(getuid());

     s = connecticb();                        /* Make s a socket to server */

     login(s,pwptr->pw_name,nick,group);
     signal(SIGINT,SIG_IGN);
     initscr();
     noecho();
     cbreak();
#ifdef _M_XENIX
     nl();
#endif
     input_x=0;
     y = 0;
     mainwin = newwin(WINSIZE,80,0,0);
     blankwin = newwin(WINSIZE+4,80,0,0);
     flushok(mainwin,TRUE);
     scrollok(mainwin,TRUE);
     leaveok(mainwin,TRUE);
     inputwin = newwin(4,80,20,0);
     flushok(inputwin,TRUE);
     scrollok(inputwin,FALSE);
     flushok(blankwin,TRUE);
     scrollok(blankwin,FALSE);
     savetty();
     hioutput(statline,0,0,inputwin);
     wclear(mainwin);
     wrefresh(mainwin); 
     for (;;) {
          resetty();
          yodaptr->tv_sec=60;
          yodaptr->tv_usec=0;
          time((time_t *)&stmptr);
          sprintf(statline,"Nick: %-13s  Group: %-8s  | /h - Help | FLICB %s |  Time: %-6s",mnptr->nickinfo,mnptr->groupinfo,FLICB_VER,ampm(stmptr,0));
          wrefresh(mainwin);
          hioutput(statline,0,0,inputwin);
          wmove(inputwin,2,input_x);
          wrefresh(inputwin);
          FD_ZERO(&pending);
          FD_SET(fileno(stdin), &pending);
          FD_SET(s, &pending);
          if (select(s + 1, &pending, NULL, NULL, yodaptr) < 0) {
               perror("mainloop: select");
          }
          if (FD_ISSET(s, &pending)) {
               a=read(s,&buflen,sizeof(unsigned char));
               if (a>0) {
                    c=(int)buflen;
                    b=read(s,buffer,c*sizeof(char));
                    for (;b<c;) {
                         if (b != -1) {
                              c-=b;
                         }
                         b=read(s,buff2,c*sizeof(char));
                         sprintf(buffer,"%s%s",buffer,buff2);
                         for (qptr=buff2;*qptr;qptr++) {
                              *qptr='\0';
                         }
                         if (b != -1) {
                              c-=b;
                         }
                    }
                    mnptr=(struct infoback *)in_packet_handle(s,buffer,y,mainwin,inputwin,nickptr,gpptr,mnptr->dopage,mnptr->pageflag); 
                    y+=mnptr->yres;
                    nickptr=mnptr->nickinfo;
                    gpptr=mnptr->groupinfo;
                    time((time_t *)&stmptr);
                    sprintf(statline,"Nick: %-13s  Group: %-8s  | /h - Help | FLICB %s |  Time: %-6s",mnptr->nickinfo,mnptr->groupinfo,FLICB_VER,ampm(stmptr,0));
                    hioutput(statline,0,0,inputwin);
                    wrefresh(inputwin);
                    for (qptr=buffer;*qptr;qptr++) {
                         *qptr='\0';
                    }
               }      
          }

          wmove(inputwin,2,input_x);
          wrefresh(inputwin);
          if (FD_ISSET(fileno(stdin), &pending)) {
               wmove(inputwin,2,input_x);
               wrefresh(inputwin);
               if (ibflag) {
                    ibflag=0;
                    ibptr=inbuffer;
               }
               inresult=read(fileno(stdin),&in_chr,sizeof(unsigned char));
               if (inresult>0) {
                    if (in_chr == '\n') {
                         *ibptr='\0';
                         ibptr++;
                         for (qptr=ibptr;*qptr;qptr++) {
                              *qptr='\0';
                         }
                         input_x=0;
                         histbit=1;
                         histon=0;
                         totalinchr=0;
                         wmove(inputwin,2,input_x);
                         if (strlen(inbuffer) != 0) {
                              cptr=inbuffer;
                              if (*cptr == '/') {
                                   cptr++;
                                   #ifdef SYSLOG
                                   openlog("flicb",LOG_PID,LOG_USER);
                                   syslog(LOG_INFO,"cptr= %s",cptr);
                                   #endif  
                                   mnptr=(struct infoback *)out_packet_handle(s,cptr,y,mainwin,0,inputwin,nickptr,gpptr,mnptr->dopage,mnptr->pageflag,mnptr->linesup);
                                   if (mnptr->yres != 9999) {
                                        y+=mnptr->yres;
                                   } else {y=0;}
                                   nickptr=mnptr->nickinfo;
                                   gpptr=mnptr->groupinfo;
                                   time((time_t *)&stmptr);
                                   sprintf(statline,"Nick: %-13s  Group: %-8s  | /h - Help | FLICB %s |  Time: %-6s",mnptr->nickinfo,mnptr->groupinfo,FLICB_VER,ampm(stmptr,0));
                                   hioutput(statline,0,0,inputwin);
                                   wrefresh(inputwin);
                              } else {
                                   mnptr=(struct infoback *)out_packet_handle(s,cptr,y,mainwin,1,inputwin,nickptr,gpptr,mnptr->dopage,mnptr->pageflag,mnptr->linesup);
                                   if (mnptr->yres != 9999) {
                                        y+=mnptr->yres;
                                   } else {y=0;}
                                   time((time_t *)&stmptr);
                                   sprintf(statline,"Nick: %-13s  Group: %-8s  | /h - Help | FLICB %s |  Time: %-6s",mnptr->nickinfo,mnptr->groupinfo,FLICB_VER,ampm(stmptr,0));
                                   hioutput(statline,0,0,inputwin);
                                   wrefresh(inputwin);
                              }
                         }
                         for (qptr=inbuffer;*qptr;qptr++) {
                              *qptr='\0';
                         }
                         for (qptr=histbuf;*qptr;qptr++) {
                              *qptr='\0';
                         }
                         ibflag=1;
                         wmove(inputwin,2,input_x);
                         wclrtoeol(inputwin);
                         wmove(inputwin,2,input_x);
                         wrefresh(inputwin);
                    } else {
                         if (CTRLCHECK('H') == in_chr || in_chr == DELETE
			     || CTRLCHECK('L') == in_chr
                             || CTRLCHECK('A') == in_chr
                             || CTRLCHECK('N') == in_chr
                             || CTRLCHECK('W') == in_chr
                             || CTRLCHECK('P') == in_chr 
                             || CTRLCHECK('X') == in_chr
                             || CTRLCHECK('I') == in_chr) {
                              if (CTRLCHECK('P') == in_chr) {
                                        wmove(inputwin,0,0);
                                        wclrtoeol(inputwin);
                                        center("                         -< PRESS ANY KEY TO RESUME >-                          ",0,inputwin,1);
                                        wrefresh(inputwin);
                                   for (pauseflag=0;!pauseflag;) {
                                        FD_ZERO(&pending);
                                        FD_SET(fileno(stdin), &pending);
                                        if (select(s + 1, &pending, NULL, NULL, NULL) < 0) {
                                              perror("mainloop: select");
                                        }
                                        if (FD_ISSET(fileno(stdin), &pending)) {
                                             read(fileno(stdin),&pchar,1*sizeof(char));
                                             pauseflag=1;
                                        }
                                   }
                                        time((time_t *)&stmptr);
                                        sprintf(statline,"Nick: %-13s  Group: %-8s  | /h - Help | FLICB %s |  Time: %-6s",mnptr->nickinfo,mnptr->groupinfo,FLICB_VER,ampm(stmptr,0));
                                        hioutput(statline,0,0,inputwin);
                                        wrefresh(inputwin);
                              }
                              if (CTRLCHECK('N') == in_chr) {
                                   if (mnptr->dopage==0) {
                                        mnptr->dopage=1;
                                        center("Auto-Hold:  On",3,inputwin,1);
                                   } else {
                                        center("Auto-Hold:  Off",3,inputwin,1);
                                        mnptr->dopage=0;
                                   }
                                   wrefresh(inputwin);
                                   sleep(2);
                                   wmove(inputwin,3,0);
                                   wclrtoeol(inputwin);
                                   wmove(inputwin,2,input_x);
                                   wrefresh(inputwin);
                                   resetty();
                              }
 
                              if (CTRLCHECK('A') == in_chr) {
                                   if (alertmes==0) {
                                        alertmes=1;
                                        center("Message Alert:  On",3,inputwin,1);
                                   } else {
                                        center("Message Alert:  Off",3,inputwin,1);
                                        alertmes=0;
                                   }
                                   wrefresh(inputwin);
                                   sleep(2);
                                   wmove(inputwin,3,0);
                                   wclrtoeol(inputwin);
                                   wmove(inputwin,2,input_x);
                                   wrefresh(inputwin);
                                   resetty();
                              }
 
			      if (CTRLCHECK('L') == in_chr) {
                                   touchwin(blankwin);
				   wrefresh(blankwin);
                                   resetty();
                                   touchwin(mainwin);
				   wrefresh(mainwin);
                                   resetty();
                                   wmove(inputwin,2,input_x);
                                   touchwin(inputwin);
				   wrefresh(inputwin); 
                                   resetty();
			      }
                              if ((CTRLCHECK('W') == in_chr)) {
                              while (in_chr && input_x > 0 && in_chr != ' ') {
                                   input_x--;
                                   ibptr--;
                                   totalinchr--;
                                   if ((totalinchr > BACK_BUFF_SIZE) && (input_x  < BACK_BUFF_SIZE)) {
                                        wmove(inputwin,2,0);
                                        wclrtoeol(inputwin);
                                        input_x=IN_SEGMENT_SIZE-3;
                                        reptr=rebuf;
                                        reoptr=ibptr;
                                        for (rex=IN_SEGMENT_SIZE-3;rex>0;rex--) {
                                             reoptr--;
                                        }
                                        for (rex=IN_SEGMENT_SIZE-2;rex>0;rex--) {
                                             *reptr=*reoptr;
                                             reptr++;
                                             reoptr++;
                                        }
                                        output(rebuf,2,0,inputwin);
                                   }
                                   wmove(inputwin,2,input_x);
                                   waddch(inputwin,' ');
                                   wrefresh(inputwin);
                                   if( input_x >= 1 ) {
                                        in_chr = *(ibptr-1);
                                   } else {
                                        in_chr = *ibptr;
                                   }
                              }}
 
                              if (CTRLCHECK('X') == in_chr) {
                                   for (qptr=inbuffer;*qptr;qptr++) {
                                        *qptr='\0';
                                   }
                                   ibptr=inbuffer;
                                   input_x=0;
                                   totalinchr=0;
                                   histbit=1;
                                   histon=0;
                                   wmove(inputwin,2,input_x);
                                   wclrtoeol(inputwin);
                                   wmove(inputwin,2,input_x); 
                                   wrefresh(inputwin);
                              }
                              if (CTRLCHECK('I') == in_chr && histbit==1) {
                                   if (histcount()) {
                                   if (histon==1) {
                                        totalinchr=0;
                                        input_x=0;
                                        wmove(inputwin,2,0);  
                                        wclrtoeol(inputwin);
                                        wrefresh(inputwin);
                                   } else {
                                        histon=1;
                                   }
                                   ibflag=0;
                                   for (qptr=inbuffer;*qptr;qptr++) {
                                        *qptr='\0';
                                   }
                                   for (qptr=histbuf;*qptr;qptr++) {
                                        *qptr='\0';
                                   }
                                   hist1=(char *)histget();
                                   sprintf(histbuf,"/m %s ",hist1);
                                   histlen=strlen(histbuf);
                                   ibptr=inbuffer;
                                   hisptr=histbuf;
                                   for (hcpy=0;hcpy<histlen-1;hcpy++) {
                                        *ibptr=*hisptr;
                                        ibptr++;
                                        hisptr++;
                                   }
                                   *ibptr=' ';
                                   ibptr++;
                                   for (qptr=ibptr;*qptr;qptr++) {
                                        *qptr='\0';
                                   }
                                   #ifdef SYSLOG
                                   openlog("flicb",LOG_PID,LOG_USER);
                                   syslog(LOG_INFO,"tabhist histbuf %s",histbuf);
                                   syslog(LOG_INFO,"tabhist inbuf %s",inbuffer);
                                   closelog();
                                   #endif 
                                   output(histbuf,2,0,inputwin);
                                   totalinchr+=histlen;
				   input_x+=histlen;
                                   wmove(inputwin,2,input_x);
                                   wrefresh(inputwin);
                                   for (qptr=histbuf;*qptr;qptr++) {
                                        *qptr='\0';
                                   }
                              }}
			      if ((CTRLCHECK('H') == in_chr) || (in_chr 
                                   == DELETE)) {
                              if (in_chr && input_x > 0) {
                                   input_x--;
                                   if (input_x == 0) {
                                        histbit=1;
                                   }
                                   ibptr--;
                                   totalinchr--;
                                   if ((totalinchr > BACK_BUFF_SIZE) && (input_x < BACK_BUFF_SIZE)) {
                                        wmove(inputwin,2,0);
                                        wclrtoeol(inputwin);
                                        input_x=IN_SEGMENT_SIZE-3;
                                        treptr=trebuf;
                                        reoptr=ibptr;
                                        for (rex=IN_SEGMENT_SIZE-3;rex>0;rex--) {
                                             reoptr--;
                                        }     
                                        for (rex=IN_SEGMENT_SIZE-2;rex>0;rex--) {
                                             *treptr=*reoptr;
                                             treptr++;
                                             reoptr++;
                                        }
                                        output(trebuf,2,0,inputwin);
                                   }
                                   wmove(inputwin,2,input_x);
                                   waddch(inputwin,' ');
                                   wrefresh(inputwin);
                              } else {
                                   input_x=0;
                                   totalinchr=0;
                                   histbit=1;
                                   histon=0;
                                   wmove(inputwin,2,input_x);
                                   wrefresh(inputwin);
                              }}
                         } else {
                              histbit=0;
                              if (totalinchr == MAXMSGSTRLEN) {
                                   wmove(inputwin,2,79);
                                   waddch(inputwin,'\007');
                                   wrefresh(inputwin);
                                   wmove(inputwin,2,79);
                                   waddch(inputwin,' ');
                                   wmove(inputwin,2,input_x);
                                   wrefresh(inputwin);
                              } else {
                              totalinchr++;
                              if (input_x == IN_SEGMENT_SIZE-2) {
                                   input_x=0;
                                   wmove(inputwin,2,input_x);
                                   wclrtoeol(inputwin);
                                   wmove(inputwin,2,input_x);
                                   wrefresh(inputwin);
                                   bbuf=backbuf;
                                   obuf=ibptr;
                                   for (ox=BACK_BUFF_SIZE;ox>0;ox--) {
                                        obuf--;
                                   }
                                   for (bx=BACK_BUFF_SIZE;bx>0;bx--) {
                                        *bbuf=*obuf;
                                        bbuf++;
                                        obuf++;
                                   }
                                   bbuf=backbuf;
                                   output(bbuf,2,input_x,inputwin);
                                   input_x+=BACK_BUFF_SIZE;
                                   wmove(inputwin,2,input_x);
                                   wrefresh(inputwin);
                              #ifdef SYSLOG
                              openlog("flicb",LOG_PID,LOG_USER);
                              syslog(LOG_INFO,"got to next region: letter= %c",in_chr);
                              closelog();
                              #endif

                              }
                              wmove(inputwin,2,input_x);
                              waddch(inputwin,in_chr);
                              input_x++;
                              wmove(inputwin,2,input_x);
                              wrefresh(inputwin);
                              *ibptr=in_chr;
                              #ifdef SYSLOG
                              openlog("flicb",LOG_PID,LOG_USER);
                              syslog(LOG_INFO,"chr= %c inbuffer= %s",in_chr,inbuffer);
                              closelog();
                              #endif
                              ibptr++;
                              inresult=0;
                              }
                         }
                    }
               }
          }
     }                                    
     exit(0);                            
}
