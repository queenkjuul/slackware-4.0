/* Fairlight's ICB Client                                                    */
/* Copyright 1994, Mark Luljak <fairlite@arcadia.aldridge.sol.net>           */
/*                                                                           */

#include "flicb.h"

int help(whelp)
WINDOW *whelp;
{
     char *options[] = {
          "/w [.|groupname] - Who Is On",
          "/n nickname - Change Nickname",
          "/m nickname mesg - Private MSG",
          "/b nickname - Beep Nickname",
          "/k nickname - Kick Nickname",
          "/p nickname - Pass Nickname",
          "/t [topic] - Topic [Change To]",
          "/g group - Join Group",
          "/i nickname - Invite To Group",
          "/s [i|v|s|m|r] - Change Status",
	  "/e command - Send results to ICB",
          "/h - This Help Screen",
          "/c - Clear Screen",
          "CONTROL-L - Redraw Screen",
          "CONTROL-P - Pause Screen",
          "CONTROL-N - Toggle /w AutoPause",
          "CONTROL-A - Toggle Message Alert",
          "CONTROL-X - Kill Line",
          "CONTROL-W - Kill Word",
	  "<TAB> - /m history control",
          NULL
     };
     int number_of_ops, count, column, row, flag, flag2, pos;

/*  Determine Number of Options  */

     for (number_of_ops = 0; options[number_of_ops++] != NULL;) {
     }
     number_of_ops--;

/*  End Determination */
     touchwin(whelp);
     flag = flag2 = 0;
     center(HELPTITLE, 0, whelp, 1);
     row = INIT_ROW;
     column = 3;
     for (count = 0; count < number_of_ops; count++)  {
          if ((count > (number_of_ops / 2)) && ! flag) {
               column = 41;
               row = INIT_ROW;
               flag = flag2 = 1;
          }
          if (((count == (number_of_ops / 2)) && !(number_of_ops % 2)) && ! flag2) {
               column = 41;
               row = INIT_ROW;
               flag = flag2 = 1;
          }
          noutput(options[count], row++, column, whelp);
     }
     center("***********************************************",12,whelp,1);
     center("*           FairLight's ICB Client            *",13,whelp,1);
     center("*                                             *",14,whelp,1);
     center("*           Written and Designed by           *",15,whelp,1);
     center("*                 Mark Luljak                 *",16,whelp,1);
     center("*       (C) 1994 Braindead Software Ltd.      *",17,whelp,1);
     center("***********************************************",18,whelp,1);
     center("Press any key to return to FLICB", 23, whelp, 1);
     wrefresh(whelp);
#ifndef NOANNOY
     spinner("Dedicated with love to my wife, Kelly!",whelp,20,1);
     center("Press any key to return to FLICB", 23, whelp, 1);
#endif
     return(0);
}

