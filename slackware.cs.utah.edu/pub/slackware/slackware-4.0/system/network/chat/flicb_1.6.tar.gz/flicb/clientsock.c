/* Fairlight's ICB Client  v1.0                                              */
/* Copyright 1994, Mark Luljak <fairlite@arcadia.aldridge.sol.net>           */
/*                                                                           */
/* This Function written by Steven Grimm (koreth@hyperion.com)               */
/* Thanks, Steven...couldn't have done it without you...                     */

#include "flicb.h"

int clientsock(host, port)
char *host;
int port;
{
	int	sock;
	struct	sockaddr_in server;
	struct	hostent *hp, *gethostbyname();

	bzero(&server, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(port);

	if (isdigit(host[0]))
		server.sin_addr.s_addr = inet_addr(host);
	else
	{
		hp = gethostbyname(host);
		if (hp == NULL)
			return -9999;
		bcopy(hp->h_addr, &server.sin_addr, hp->h_length);
	}

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
		return -errno;

	if (connect(sock,(struct sockaddr *) &server, sizeof(server)) < 0)
	{
		close(sock);
		return -errno;
	}

	return sock;
}
