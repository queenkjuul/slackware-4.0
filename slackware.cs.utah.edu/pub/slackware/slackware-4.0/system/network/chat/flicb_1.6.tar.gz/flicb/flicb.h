/* Fairlight's ICB Client                                                    */
/* Copyright 1994, Mark Luljak <fairlite@arcadia.aldridge.sol.net>           */
/*                                                                           */


#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <ctype.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <time.h>
#include <signal.h>
#include <curses.h>
#ifdef SYSLOG
#include <syslog.h>
#endif
/* The following are for clientsock.c */
/*#define FD_ZERO(p)      bzero((char *)(p), sizeof(*(p))) */


#define SERVERNAME "crater.unm.edu"
#define ICBPORT 7326
#define STRINGSIZE 30000
#define WINSIZE 20
#define BOXCHAR '*'
#define SEPCHR "\001"
#define CTRLCHECK(c) ((c)&0x1f)    /* Define Control Char Check Macro */
#define DELETE (char)0x7f          /* Define Delete Char */
#define IN_SEGMENT_SIZE 75
#define BACK_BUFF_SIZE 4
#define MAXMSGSTRLEN 250

struct infoback {
     int yres;
     char *nickinfo;
     char *groupinfo;
     int dopage;
     int linesup;
     int pageflag;
};

typedef struct Strlist {
        struct Strlist *next, *prev;
        char str[1];
} STRLIST;
 
int alertmes;

#define INIT_ROW 2
#define HELPTITLE "FLICB Help Screen"
#define FLICB_VER "v1.6"
#ifdef _M_XENIX
#define usleep(X) nap(X/1000);
#endif
 
