Welcome to the fetish club. The DJ spins the best of everything you want
to hear.  It's open 24 hours a day.  So if you wanna dance at noon you can.
Now what a club!
