This is the bar.  You must be 21 to enter this establishment.  If you are not
then please go back to The_Club.
