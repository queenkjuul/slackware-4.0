You are in the lounge where all wearied chatters come to rest for a short
while. Pull an armchair up to the fire and relax your tired feet a while.
