This is the wizroom where only those privileged few can come and relax
away from the hustle and bustle of the rest of the talker. Large comfy
armchairs are placed around the room and there is a large fur rug in front
of a warm crackling fire. Pictures of old long forgotten ex-wizzes scowl
down from the flock wallpapered walls, not surprising really since a lot
seem to have been used as dartboards.
