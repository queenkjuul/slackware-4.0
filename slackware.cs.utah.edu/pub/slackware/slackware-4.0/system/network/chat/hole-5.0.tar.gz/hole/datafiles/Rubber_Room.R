You wake up in a strange jacket that doesn't feel right. You are in a strange
room that is completely empty. You try to scream but no one hears you. You
feel like you have gone crazy.
