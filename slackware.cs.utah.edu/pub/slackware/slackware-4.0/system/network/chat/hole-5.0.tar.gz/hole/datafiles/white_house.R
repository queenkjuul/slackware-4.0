You are not sure of where you are. Just looks quite rich looking.
