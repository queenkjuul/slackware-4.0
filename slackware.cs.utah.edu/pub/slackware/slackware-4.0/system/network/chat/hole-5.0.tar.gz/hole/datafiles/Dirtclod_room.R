Heya welcome to the dirt clod throwing room. Invite some friends and take
out your aggressions by throwing a few dirt clods at them. Well have fun
and be sure not to lose, bad things happen to losers.
NOTE: IF YOU GET KNOCKED OUT OF THIS ROOM BY ANOTHER
USER YOU MUST STAY IN THE DARK ROOM FOR 3 MINUTES OR
YOU WILL BE DEMOTED.
