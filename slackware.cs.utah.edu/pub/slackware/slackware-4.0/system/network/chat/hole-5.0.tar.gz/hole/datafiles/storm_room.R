	Welcome to the Storm Room. You better hope the winds don't decide to
pick up or else you will become one with the storm.
