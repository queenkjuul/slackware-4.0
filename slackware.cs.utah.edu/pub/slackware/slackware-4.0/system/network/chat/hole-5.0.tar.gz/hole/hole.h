/********************** Header file for HOLE version 5.0 **********************/

#define DATAFILES "datafiles"
#define FORTUNEDIR "fortune"
#define HELPFILES "helpfiles"
#define MAILSPOOL "mailspool"
#define MOTDDIR "motds"
#define PICTDIR "pictdir"
#define TXTDIR "txtdir"
#define USERFILES "userfiles"

#define CONFIGFILE "datafiles/config"
#define HOLE_PIDFILE "hole.pid"
#define MAPFILE "datafiles/mapfile"
#define NEWSFILE "datafiles/newsfile"
#define NOLOGINFILE "datafiles/nologin"
#define SITELOG "datafiles/sitelog"
#define SYSLOG "datafiles/syslog"
#define TEMPFILE "tempfile"

#define ALLOWDOMAINS "datafiles/allowdomains"
#define DOMAINBANS "datafiles/domainbans"
#define NEWDOMAINBANS "datafiles/newdomainbans"
#define SWBANS "datafiles/swbans"
#define USERBANS "datafiles/userbans"

#define HVERSION "5.0"
#define NVERSION "3.3.3"

#define ARR_SIZE 2500
#define COLNUM 22
#define CONV_LINES 15
#define MAX_LINES 20
#define MAX_WORDS 10
#define OUT_BUFF_SIZE 80
#define PAGEWIDTH 22
#define WORD_LEN 80

#define BUFSIZE 1000
#define FILENAME_LEN 80
#define MAX_LINKS 10
#define PASS_MIN_LEN 5
#define PASS_MAX_LEN 20
#define PHRASE_LEN 25
#define ROOM_DESC_LEN ARR_SIZE
#define ROOM_LABEL_LEN 5
#define ROOM_NAME_LEN 20
#define SERV_NAME_LEN 20
#define SITE_NAME_LEN 80
#define TOPIC_LEN 60
#define USER_DESC_LEN 25
#define USER_NAME_LEN 15
#define VERIFY_LEN 20
/* DNL (Date Number Length) will have to become 12 on Sun Sep 9 02:46:40 2001
   when all the unix timers will flip to 1000000000 :) */
#define DNL 11
#define NAMESTRING "~n"
#define PTSTR "-_-~-+-_-~-+-_-~-+-_-~-+--_-~-+-_-~-+-_-~-+-_-~-+-_--~-+-_-~-+-_-~-+-_-~-_-~-_-~\n"

#define PUBLIC 0
#define PRIVATE 1
#define FIXED_PUBLIC 2
#define FIXED_PRIVATE 3
#define HIDDEN 4

#define AWOL 0
#define PRIVATE 1
#define CORPORAL 2
#define CAPTAIN 3
#define COLONEL 4
#define COMMANDER 5
#define GENERAL 6

#define USER_TYPE 0
#define CLONE_TYPE 1
#define REMOTE_TYPE 2
#define CLONE_HEAR_NOTHING 0
#define CLONE_HEAR_SWEARS 1
#define CLONE_HEAR_ALL 2

#define T_ECHO 1
#define T_SGA 3
#define T_EC 247
#define T_WILL 251
#define T_WONT 252
#define T_DO 253
#define T_DONT 254
#define T_IAC 255

#define DAY_LEN 3
#define FIRST_MISSING_DAY 639787
#define HEAD_SEP 2
#define MAXDAYS 42
#define NUMBER_MISSING_DAYS 11
#define SATURDAY 6
#define SPACE -1
#define THURSDAY 4
#define WEEK_LEN 21

#define	centuries_since_1700(yr) \
((yr)>1700 ? (yr)/100-17 : 0)

#define	leap_year(yr) \
((yr)<=1752 ? !((yr)%4) : \
(!((yr)%4) && ((yr)%100)) || !((yr)%400))

#define	leap_years_since_year_1(yr) \
((yr)/4-centuries_since_1700(yr)+quad_centuries_since_1700(yr))

#define	quad_centuries_since_1700(yr) \
((yr)>1600?((yr)-1600)/400 : 0)

int days_in_month[2][13]={
{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
{0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
};

int sep1752[MAXDAYS]={
SPACE,	SPACE,	1,	2,	14,	15,	16,
17,	18,	19,	20,	21,	22,	23,
24,	25,	26,	27,	28,	29,	30,
SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,
SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,
SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,
}, empty[MAXDAYS]={
SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,
SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,
SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,
SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,
SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,
SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,	SPACE,
};

char day_headings[]=" S  M Tu  W Th  F  S ";
char *full_month[12];

char *level_name[]={
"AWOL","PRIVATE","CORPORAL","CAPTAIN","COLONEL","COMMANDER","GENERAL","*"
};

/* The elements vis, listen, prompt, command_mode etc could all be bits in
   one flag variable as they're only ever 0 or 1, but I tried it and it
   made the code unreadable. Better to waste a few bytes */
struct user_struct {
	char *malloc_end;
	char *malloc_start;
	char addemail[36];
	char addname[USER_NAME_LEN+1];
	char addpass2[PASS_MAX_LEN+6];
	char addpass[PASS_MAX_LEN+6];
	char afkmesg[81];
	char age[6];
	char alias1[3];
	char alias2[20];
	char allcolor[50];
	char answer[2];
	char arrdesc[USER_DESC_LEN+1];
	char bakedesc[USER_DESC_LEN+1];
	char bakename[USER_NAME_LEN+1];
	char bigdesc[USER_DESC_LEN+1];
	char bigname[USER_NAME_LEN+1];
	char board[17];
	char buff[BUFSIZE];
	char colstr2[50];
	char colstr[50];
	char conv_lines[CONV_LINES][502];
	char croncom[ARR_SIZE];
	char desc[USER_DESC_LEN+1];
	char draggee[USER_NAME_LEN+1];
	char email[36];
	char gender[7];
	char gobackto[USER_NAME_LEN+1];
	char guessed[27];
	char hangword[20];
	char homeroom[ROOM_NAME_LEN+1];
	char hunted[USER_NAME_LEN+1];
	char ignoreset[USER_NAME_LEN+1];
	char in_phrase[PHRASE_LEN+1];
	char inpstr_old[ARR_SIZE];
	char invisname[USER_NAME_LEN+1];
	char last[81];
	char last_site[SITE_NAME_LEN+1];
	char listenset[USER_NAME_LEN+1];
	char lostto[USER_NAME_LEN+1];
	char lprofile[ARR_SIZE];
	char mail_to[USER_NAME_LEN+1];
	char md[3];
	char merlyn[USER_NAME_LEN+1];
	char morphed[USER_NAME_LEN+1];
	char mplayer1[USER_NAME_LEN+1];
	char mplayer2[USER_NAME_LEN+1];
	char mplayer3[USER_NAME_LEN+1];
	char mplayer4[USER_NAME_LEN+1];
	char name[USER_NAME_LEN+1];
	char newpass[PASS_MAX_LEN+6];
	char out_phrase[PHRASE_LEN+1];
	char page_file[80];
	char pass[PASS_MAX_LEN+6];
	char passwd[USER_NAME_LEN+1];
	char pickcol[USER_NAME_LEN+1];
	char setlogin[USER_NAME_LEN+1];
	char setlogout[USER_NAME_LEN+1];
	char setpro[USER_NAME_LEN+1];
	char site[SITE_NAME_LEN+1];
	char stalker[USER_NAME_LEN+1];
	char talkbackto[USER_NAME_LEN+1];
	char talkto[USER_NAME_LEN+1];
	char tgobackto[USER_NAME_LEN+1];
	char tleader[USER_NAME_LEN+1];
	char toggleset[USER_NAME_LEN+1];
	char tplayer[USER_NAME_LEN+1];
	char tradeto[USER_NAME_LEN+1];
	char tsquare[10][2];
	char url[57];
	char vanswer2[80];
	char vanswer[80];
	char vgobackto[USER_NAME_LEN+1];
	char vplayer1[USER_NAME_LEN+1];
	char vplayer2[USER_NAME_LEN+1];
	char vplayer3[USER_NAME_LEN+1];
	char vplayer4[USER_NAME_LEN+1];
	char whichsquare[2];
	char word[MAX_WORDS][WORD_LEN+1];
	char write_to[ROOM_NAME_LEN+1];
	char yused[20];
	float percentage;
	int accreq;
	int afk;
	int afklog;
	int agree;
	int annoy;
	int anvil;
	int arrlevel;
	int arrows;
	int astage;
	int attempts;
	int autoread;
	int bake;
	int baked;
	int beepline;
	int beeplogin;
	int big;
	int booted;
	int bought;
	int bounce;
	int breakin;
	int buffpos;
	int channel;
	int charcnt;
	int charmode_echo;
	int cln;
	int clone_hear;
	int closeonce;
	int cntplay;
	int color;
	int colorize;
	int command_mode;
	int committed;
	int cron;
	int cronsec;
	int ctrl_last;
	int dark;
	int dirtclod;
	int dirttime;
	int doublecnt;
	int doubles;
	int edit_line;
	int edit_op;
	int endoffile;
	int error;
	int examine;
	int exd;
	int filepos;
	int fmail;
	int fpc;
	int fromcnt;
	int frozen;
	int game;
	int gen;
	int gopass;
	int gossamer;
	int greet;
	int hangman;
	int hangmode;
	int hid;
	int hroom;
	int hunt;
	int hunting;
	int idlemin;
	int idlemsg;
	int il;
	int income;
	int incomp;
	int jail;
	int jailcnt;
	int jeep;
	int jeepcnt;
	int jeeprooms;
	int join;
	int last_login_len;
	int ldidit;
	int leader;
	int level;
	int lineedit;
	int listen;
	int listen_store;
	int locked;
	int login;
	int losing;
	int lstage;
	int mesg;
	int misc_op;
	int money;
	int monopoly;
	int morelines1;
	int morelines;
	int motdpause;
	int muzzled;
	int noidle;
	int notcomplete;
	int notyet;
	int numpages;
	int numplay;
	int numrooms;
	int old_op;
	int origpos;
	int pay;
	int pictell;
	int playernum;
	int pnq;
	int port;
	int printcolors;
	int prompt;
	int pstage;
	int ptmisc_op;
	int ptpos;
	int question;
	int quiet;
	int quitin2;
	int quitin3;
	int quitting;
	int quizcnt;
	int ready;
	int remote_com;
	int reply;
	int respawn;
	int revdisp;
	int rooms;
	int scommand_mode;
	int score;
	int selfdestructing;
	int shout;
	int signon;
	int site_port;
	int sleepstage;
	int smail;
	int smoke;
	int socials;
	int socket;
	int space;
	int sstage;
	int talking;
	int talkready;
	int tday;
	int tdiff;
	int tdiffhour;
	int tell;
	int thour;
	int tmday;
	int tmin;
	int tmonth;
	int total;
	int trade1;
	int trade2;
	int trade1prop;
	int trade2prop;
	int trading;
	int tready;
	int trig;
	int trigonce;
	int tsec;
	int tsign;
	int ttime;
	int ttt;
	int turn;
	int turniton;
	int twday;
	int tyear;
	int type;
	int vanity;
	int vcntplay;
	int vgame;
	int vgoon;
	int vis;
	int vleader;
	int vmyturn;
	int vnumplay;
	int vplayernum;
	int vready;
	int vsecond;
	int vspace;
	int vturn;
	int waiting;
	int warned;
	int which;
	int whichcol1;
	int whichcol2;
	int whichcol3;
	int whichcol;
	int whichtalk;
	int whichtrig;
	int wizroom;
	int woohoo;
	int wordcnt;
	int wordwrap;
	int wordwraplen;
	int xval;
	int yahtzee;
	int yahtzee2;
	int yahtzeevars[13];
	int ycount;
	int ydice[5];
	int yval;
	struct netlink_struct *netlink,*pot_netlink;
	struct room_struct *room,*invite_room,*readroom;
	struct space_struct {
		int amount,cost,hasall,mortgaged,numhouses,property;
		char name[30],owner[USER_NAME_LEN+1];
		} spaces[41];
	struct user_struct *prev,*next,*owner;
	time_t afktime;
	time_t baketime;
	time_t boottime;
	time_t br_time;
	time_t crontime;
	time_t darktime;
	time_t jeeptime;
	time_t last_input;
	time_t last_login;
	time_t logintime;
	time_t makeemread;
	time_t motdpausetime;
	time_t quitin1;
	time_t read_mail;
	time_t read_sentmail;
	time_t sleeptime;
	time_t total_login;
	time_t vanitytime;
	};

typedef struct user_struct *UR_OBJECT;
UR_OBJECT user_first,user_last;

struct cave_struct {
	int has_a_bat,has_a_pit;
	int tunnel[3];
	} cave[26];

struct room_struct {
	char desc[ROOM_DESC_LEN+1];
	char label[ROOM_LABEL_LEN+1];
	char link_label[MAX_LINKS][ROOM_LABEL_LEN+1];
	char name[ROOM_NAME_LEN+1];
	char netlink_name[SERV_NAME_LEN+1];
	char topic[TOPIC_LEN+1];
	int access;
	int hid;
	int inlink;
	int level;
	int mesg_cnt;
	struct netlink_struct *netlink;
	struct room_struct *link[MAX_LINKS];
	struct room_struct *prev,*next;
	};

typedef struct room_struct *RM_OBJECT;
RM_OBJECT room_first,room_last;

#define UNCONNECTED 0
#define INCOMING 1
#define OUTGOING 2
#define DOWN 0
#define VERIFYING 1
#define UP 2
#define ALL 0
#define IN 1
#define OUT 2

struct netlink_struct {
	FILE *mailfile;
	char buffer[ARR_SIZE*2];
	char mail_from[USER_NAME_LEN+1];
	char mail_to[USER_NAME_LEN+1];
	char remote_ver[11];
	char service[SERV_NAME_LEN+1];
	char site[SITE_NAME_LEN+1];
	char verification[SERV_NAME_LEN+1];
	int allow;
	int connected;
	int keepalive_cnt;
	int lastcom;
	int port;
	int socket;
	int stage;
	int type;
	int ver_major;
	int ver_minor;
	int ver_patch;
	int warned;
	struct netlink_struct *prev,*next;
	struct room_struct *connect_room;
	struct user_struct *mesg_user;
	time_t last_recvd;
	};

typedef struct netlink_struct *NL_OBJECT;
NL_OBJECT nl_first,nl_last;

char *edprompt="~OL~FGSave~RS, ~OL~FYredo~RS from ~OL~FBline~RS, ~OL~FMview~RS, or ~OL~FRabort~RS (~OL~FGs~RS/~OL~FYr~RS/~OL~FBl~RS/~OL~FMv~RS/~OL~FRa~RS): ";
char *invisenter="A presence enters the room...\n";
char *invisleave="A presence leaves the room.\n";
char *invisname="A presence";
char *noleader="Unable to locate leader.\n";
char *nosuchroom="There is no such room.\n";
char *nosuchuser="There is no such user.\n";
char *noswearing="Swearing is not allowed here.\n";
char *notloggedon="There is no one of that name logged on.\n";
char *syserror="Sorry, a system error has occurred";

char *command[]={
".accreq","-ack","/addroom","/addtime","/addtsign",
"/adduser",".afk",".afklog","/afks",".alias",
"/allclones","/allcolor","/annoy","/annoyem","-anvil",
"/append","/arrest","/atmos","/autohide","/autologin",
".autoread","/avalanche",".awho","/bake","/ban",
"/bcast","-beat",".becho",".beepline","/beeplines",
"/beeplogin","/beeplogins",".beeptell",".bemote","/bigs",
"/blast",".board","/boot","/bounce","-brb",
".bsay",".bsecho",".bsemote",".bshout",".btell",
".buy",".cal",".calc",".channel",".charecho",
"/charechos",".chemote","/clearline","/clhear","/clone",
"/clrev","/clrevclr",".cls","/clsay",".colorize",
"/commit",".complain","-confuse","/connect","/corporal",
"/count",".cron","/crons","/dark",".dchallenge",
".dchannel","/dcomplain",".decolorize","/deliver","/delroom",
"/demote",".desc","/destroy","/destroyall","/destruct",
"/difflogin",".dirtclod","/disconnect",".dmail","-doh",
"/drag",".dsentmail","/dshouts","/dsuggest","/dwiz",
".earmuffs",".echo","-eek","-eh",".emote",
".entpro","/entpros",".examine","/exs","/fakelogoff",
".femote","/fix","-flowers",".fmail",".fortune",
".forward","/fpc","/freeze","/freezeall",".friends",
"/friendstime",".from",".ftell","/games","/garble",
".go","/goingdown",".gossamer","/gossamers","/grant",
".granted",".greet","/greets",".guess",".hangman",
"/hehe",".help","/hide","-highfive","-hmm",
".holers",".home",".homeroom","/homewoom","/hour",
"-howl","-huggle",".hunt","/hunts","-idea",
"/idle",".ignore",".iguser",".incompetent","-innocent",
".inphr","/inphrs","/invis",".invite","/jeep",
".join","/kill","/killall","-kiss",".last",
".laston","/lban",".letmein","/level","/lilmurder",
".listen","/listens","/load","/loadlil","/lock",
"/logging",".login","/loginplace","/logins",".logout",
"/logouts","-lol",".look","/looks",".macro",
".map",".massemote",".massmail",".masstell",".merlyn",
"/minlogin",".mirror","/mirrors",".mode","/modes",
".monopoly","/morph",".mortgage","/motd",".move",
"/moveall","/moves","-muhaha","-mumble","/muzzle",
"/myclones","/netdata","/netstat",".news","-nod",
".noidle","/nologin","/nopromos",".number",".outphr",
"/outphrs","-panic",".passwd","/passwds",".paste",
".pemote","/people",".pickcol","/pickcols",".pictell",
"/pictells",".pinfo","-ping","-poke","-pong",
".private",".profile","/profiles","/promote",".prompt",
".property",".public","-puke",".put","/quiet",
".quit",".quitin","/quits",".quiz",".ranks",
"/rcomplain",".read","/reboot",".recap","/redesc",
"/rename",".reroll","/resetquiz",".respawn","/respawns",
".revchannel",".revclr","/revclrall",".review","/revoke",
".revshout",".revtell","/revwiz","/rlook",".rmail",
".rmsn",".rmst","-rofl",".roll","-rolls",
"/roomadd","/roomdel","/roomdesc","/rstat",".rsuggest",
".rules","/samesite",".say","/scloseall",".scommand",
"/scommands","-scream","/sdestruct",".search","/searchsite",
".secho",".sell",".semote",".sentmail",".set",
"/setdesc","/sets",".sfrom","-shake",".shoot",
".shout","/shouts","/showhidden","-shrug","/shutdown",
"-sigh","-sing","/site","-sledge","-sleep",
".smail","/smailall","/smails","/smban","-smoke",
"/smokes","/socialb",".socials","/special","/specialsite",
"/specialtoo",".spell","/stalk",".status","/staythere",
"-sthink","/stop","/stopuser","/su","/subtime",
"/subtsign",".suggest",".suicide","/suicides","-swat",
"/swban",".swho","/switch","/sysbans","/sysmail",
".sysstat","/system","-tag",".talk","-tap",
".tell","-thank","-think","-throw","-thwap",
"-tickle",".tictactoe",".timediff","-tinkle",".topic",
"/topicall","/tornado",".trade",".trigger",".txt",
"/unafk","/unannoy","/unannoyem","/unarrest","/unbake",
"/unban","/unbigs","/unbounce","/uncommit","/undark",
"/undrag","/unfix","/unfreeze","/unfreezeall","/unhide",
"/unlock",".unmortgage","/unmuzzle","/unrespawn","/unstalk",
".unwoohoo",".ustat",".vacation",".vanity",".version",
"/viewlog","/viewsite","-violin","/vis",".wake",
"/warn","-wave","-welcome","-whistle",".who",
"/whobtg","/whois","/whologin","-whyme","/winattack",
"/wipe","/wipeall","/wizemote",".wizhelp","/wizshout",
".wizwho",".woohoo",".write","/writeall","/writesock",
".yahtzee","-yippee",".1",".2",".3",
".4",".5",".6",".7",".8",
".9",".10","*"
};

int com_level[]={
PRIVATE,CORPORAL,COMMANDER,COLONEL,COMMANDER,
GENERAL,CORPORAL,CORPORAL,COLONEL,CORPORAL,
COLONEL,GENERAL,COMMANDER,GENERAL,CORPORAL,
GENERAL,CAPTAIN,GENERAL,COMMANDER,COMMANDER,
CORPORAL,COLONEL,CORPORAL,COLONEL,COMMANDER,
CAPTAIN,CORPORAL,CORPORAL,CORPORAL,COLONEL,
COLONEL,COLONEL,CORPORAL,CORPORAL,COLONEL,
COMMANDER,CORPORAL,GENERAL,COLONEL,CORPORAL,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
COLONEL,CORPORAL,COMMANDER,COLONEL,COLONEL,
COLONEL,COLONEL,CORPORAL,COLONEL,CORPORAL,
COLONEL,CORPORAL,CORPORAL,GENERAL,CAPTAIN,
GENERAL,CORPORAL,COLONEL,COMMANDER,CORPORAL,
CORPORAL,COMMANDER,CORPORAL,CAPTAIN,COMMANDER,
COMMANDER,CORPORAL,COLONEL,COMMANDER,GENERAL,
COLONEL,CORPORAL,GENERAL,PRIVATE,CORPORAL,
CAPTAIN,PRIVATE,CAPTAIN,COLONEL,COLONEL,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
PRIVATE,GENERAL,CORPORAL,COLONEL,COMMANDER,
CORPORAL,COMMANDER,CORPORAL,CORPORAL,CORPORAL,
CORPORAL,COMMANDER,CAPTAIN,COLONEL,CORPORAL,
GENERAL,CORPORAL,CORPORAL,COLONEL,GENERAL,
CORPORAL,GENERAL,CORPORAL,GENERAL,GENERAL,
CORPORAL,CORPORAL,COLONEL,CORPORAL,CORPORAL,
GENERAL,PRIVATE,COLONEL,CORPORAL,CORPORAL,
CORPORAL,PRIVATE,CORPORAL,COLONEL,GENERAL,
CORPORAL,CORPORAL,CAPTAIN,COLONEL,CORPORAL,
GENERAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
CORPORAL,COMMANDER,CAPTAIN,CORPORAL,COMMANDER,
CORPORAL,COLONEL,COMMANDER,CORPORAL,CORPORAL,
CORPORAL,COMMANDER,CORPORAL,GENERAL,GENERAL,
CORPORAL,GENERAL,GENERAL,GENERAL,GENERAL,
GENERAL,CORPORAL,GENERAL,GENERAL,CORPORAL,
GENERAL,CORPORAL,PRIVATE,CAPTAIN,CORPORAL,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
COLONEL,CORPORAL,CAPTAIN,PRIVATE,GENERAL,
CORPORAL,COLONEL,CORPORAL,GENERAL,CAPTAIN,
COMMANDER,CAPTAIN,CORPORAL,CORPORAL,CAPTAIN,
COLONEL,GENERAL,GENERAL,PRIVATE,CORPORAL,
GENERAL,GENERAL,GENERAL,CORPORAL,CORPORAL,
COMMANDER,CORPORAL,CORPORAL,COMMANDER,CORPORAL,
CORPORAL,COMMANDER,CORPORAL,COMMANDER,CORPORAL,
COLONEL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
CORPORAL,CORPORAL,COMMANDER,COMMANDER,PRIVATE,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,GENERAL,
AWOL,CORPORAL,GENERAL,CORPORAL,CORPORAL,
COMMANDER,PRIVATE,GENERAL,CORPORAL,GENERAL,
GENERAL,CORPORAL,GENERAL,CORPORAL,COMMANDER,
CORPORAL,CORPORAL,COMMANDER,CORPORAL,GENERAL,
CORPORAL,CORPORAL,COLONEL,CAPTAIN,PRIVATE,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
COMMANDER,COMMANDER,COMMANDER,COMMANDER,CORPORAL,
PRIVATE,COLONEL,PRIVATE,GENERAL,CORPORAL,
GENERAL,CORPORAL,GENERAL,CORPORAL,COLONEL,
CORPORAL,CORPORAL,CORPORAL,PRIVATE,CORPORAL,
GENERAL,GENERAL,PRIVATE,CORPORAL,CAPTAIN,
CORPORAL,COLONEL,GENERAL,CORPORAL,GENERAL,
CORPORAL,CORPORAL,COLONEL,CORPORAL,CORPORAL,
CORPORAL,GENERAL,COLONEL,COMMANDER,CAPTAIN,
COLONEL,GENERAL,CORPORAL,GENERAL,GENERAL,
GENERAL,CORPORAL,CAPTAIN,CORPORAL,GENERAL,
CORPORAL,GENERAL,GENERAL,GENERAL,COMMANDER,
COMMANDER,CORPORAL,AWOL,COLONEL,CORPORAL,
GENERAL,CORPORAL,COLONEL,COLONEL,COLONEL,
CORPORAL,COLONEL,CORPORAL,CORPORAL,CORPORAL,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
CAPTAIN,GENERAL,CORPORAL,CORPORAL,CORPORAL,
COMMANDER,COMMANDER,GENERAL,COMMANDER,COLONEL,
COMMANDER,COLONEL,COLONEL,COLONEL,GENERAL,
CAPTAIN,COMMANDER,CAPTAIN,COLONEL,COLONEL,
GENERAL,CORPORAL,CAPTAIN,COMMANDER,CAPTAIN,
COMMANDER,CORPORAL,CORPORAL,CORPORAL,PRIVATE,
GENERAL,GENERAL,CORPORAL,CAPTAIN,CORPORAL,
COLONEL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
COLONEL,GENERAL,COLONEL,CORPORAL,GENERAL,
COMMANDER,GENERAL,COLONEL,CAPTAIN,COLONEL,
CORPORAL,CORPORAL,CORPORAL,GENERAL,GENERAL,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
CORPORAL,CORPORAL,CORPORAL,CORPORAL,CORPORAL,
CORPORAL,CORPORAL
};

enum comvals {
ACCREQ,ACK,ADDROOM,ADDTIME,ADDTSIGN,
ADDUSER,AFK,AFKLOG,OAFK,ALIAS,
ALLCLONES,ALLCOLOR,ANNOY,ANNOYEM,ANVIL,
APPEND,ARREST,ATMOS,AUTOHIDE,AUTOLOGIN,
AUTOREAD,AVALANCHE,AWHO,BAKE,BAN,
BCAST,BEAT,BECHO,BEEPLINE,OBEEPLINE,
BEEPLOGIN,OBEEPLOGIN,BEEPTELL,BEMOTE,BIG,
BLAST,BOARD,BOOTEM,BOUNCE,BRB,
BSAY,BSECHO,BSEMOTE,BSHOUT,BTELL,
BUY,CALENDAR,CALC,CHANNEL,CHARECHO,
OCHARECHO,CHEMOTE,CLEARLINE,CLHEAR,CREATE,
CLREV,CLREVCLR,CLS,CLSAY,COLORIZE,
COMMIT,COMPLAIN,CONFUSE,CON,CORP,
COUNT,CRON,SUPERCRON,DARK,DCHALLENGE,
DCHANNEL,DCOMPLAIN,DECOLORIZE,DELIVER,DELROOM,
DEMOTE,DESC,DESTROY,DESTROYALL,DESTRUCT,
NODIFFLOGIN,DIRTCLOD,DISCON,DMAIL,DOH,
DRAG,DSMAIL,DSHOUTS,DSUGGEST,DWIZ,
IGNORE,ECHOIT,EEK,EH,EMOTE,
ENTPRO,SETPRO,EXAMINE,EX,FAKELOGOFF,
FEMOTE,FIX,FLOWERS,FMAIL,FORTUNE,
FORWARD,FPC,FREEZE,FREEZEALL,FRIENDS,
FRIENDSTIME,FROM,FTELL,NOGAMES,GARBLE,
GO,GOINGDOWN,GOSSAMEREM,GOSSAMER,GRANT,
GRANTED,GREET,NOGREETS,GUESS,HANGMAN,
HEHEHE,HELP,HIDE,HIFIVE,HMM,
HOLERS,HOME,HOMEROOM,HOMEWOOM,HOUR,
HOWL,HUGGLE,IHUNT,NOHUNTING,IDEA,
IDLE,TOGGLE_OIGNORE,IGUSER,INCOMPETENT,INNOCENT,
INPHRASE,OINPHR,INVIS,INVITE,JEEP,
JOIN,KILL,KILLALL,KISS,LAST,
LASTON,LBAN,LETMEIN,LEVEL,LILMURDER,
LISTEN,TOGGLE_OLISTEN,LOAD,LOADEM,LOCK,
LOGGING,LOGIM,LOGINPLACE,OLOGIM,LOGOM,
OLOGOM,LOL,LOOK,WLOOK,MACRO,
MAP,MASSEMOTE,MASSMAIL,MASSTELL,MERLYN,
MINLOGIN,MIRROR,OMIRROR,MODE,OMODE,
MONOPOLY,MORPH,MORTGAGE,MOTD,MHUNT,
MOVEALL,MOVE,MUHAHA,MUMBLE,MUZZLE,
MYCLONES,NETDATA,NETSTAT,NEWS,NOD,
DONTIDLEME,NOLOGIN,NOPROMOS,NUMBER,OUTPHRASE,
OOUTPHR,PANIC,PASSWD,OPASSWD,PASTE,
PEMOTE,PEOPLE,PICKCOL,PICKCOLS,PICTELL,
NOPICTELLS,PINFO,PING,POKE,PONG,
PRIVCOM,PROFILE,PROFILES,PROMOTE,PROMPT,
PROPERTY,PUBCOM,PUKE,PUT,QUIET,
QUIT,QUITIN,NOQUIT,QUIZ,RANKS,
RCOMPLAIN,READ,REBOOT,RECAP,REDESC,
RENAME,REROLL,RESETQUIZ,RESPAWN,ORESPAWN,
REVCHANNEL,REVCLR,REVCLRALL,REVIEW,REVOKE,
REVSHOUT,REVTELL,REVWIZ,RLOOK,RMAIL,
RMSN,RMST,ROFL,ROLL,ROLLS,
ROOMADD,ROOMDEL,ROOMDESC,RSTAT,RSUGGEST,
RULES,SAMESITE,SAY,SCLOSEALL,SCOMMAND,
OSCOMMAND,SCREAM,SELFDESTRUCT,SEARCH,SEARCHSITE,
SECHO,SELL,SEMOTE,SENTMAIL,SET,
SETDESC,OSET,SFROM,SHAKE,SHUNT,
SHOUT,NOSHOUTS,SHOWHIDDEN,SHRUG,SHUTDOWN,
SIGH,SING,SITE,SLEDGE,SLEEP,
SMAIL,SMAILALL,NOSMAIL,SMBAN,SMOKE,
NOSMOKES,NOSOCIALS,SOCIALS,SPECIAL,SPECIALSITE,
SPECIALTOO,SPELL,STALK,STATUS,STAYTHERE,
STHINK,STOP_COM,STOPUSER,SU,SUBTIME,
SUBTSIGN,SUGGEST,SUICIDE,NOSUICIDES,SWAT,
SWBAN,SWHO,SWITCH,SYSBANS,SYSMAIL,
SYSSTAT,SYSTEM,TAG,TALK,TAP,
TELL,THANK,THINK,THROW,THWAP,
TICKLE,TICTACTOE,TIMEDIFF,TINKLE,TOPIC,
TOPICALL,TORNADO,TRADE,TRIGGER,TXT,
OUNAFK,UNANNOY,UNANNOYEM,UNARREST,UNBAKE,
UNBAN,UNBIG,UNBOUNCE,UNCOMMIT,UNDARK,
UNDRAG,UNFIX,UNFREEZE,UNFREEZEALL,UNHIDE,
UNLOCK,UNMORTGAGE,UNMUZZLE,UNRESPAWN,UNSTALK,
UNWOOHOO,USTAT,VACATION,VANITY,VER,
VIEWLOG,VIEWSITE,VIOLIN,VIS,WAKE,
WARN,WAVE,WELCOME,WHISTLE,WHO,
WHOBTG,WHOIS,WHOLOGIN,WHYME,WINATTACK,
WIPE,WIPEALL,WIZEMOTE,WIZHELP,WIZSHOUT,
WIZWHO,WOOHOO,WRITE,WRITEALL,WRITESOCK,
YAHTZEE,YIPPEE,ONE,TWO,THREE,
FOUR,FIVE,SIX,SEVEN,EIGHT,
NINE,TEN
} com_num;

char *colcode[]={
"\033[0m","\033[1m","\033[5m","\033[7m",
"\033[30m","\033[31m","\033[32m","\033[33m",
"\033[34m","\033[35m","\033[36m","\033[37m",
"\033[40m","\033[41m","\033[42m","\033[43m",
"\033[44m","\033[45m","\033[46m","\033[47m",
"\07","\033[4m"
};

char *colcom[]={
"RS","OL","LI","RV",
"FK","FR","FG","FY",
"FB","FM","FT","FW",
"BK","BR","BG","BY",
"BB","BM","BT","BW",
"PZ","UL"
};

char *day[7]={
"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"
};

char *gen1[3]={"his","her","its"};
char *gen2[3]={"him","her","it"};
char *gen3[3]={"he","she","it"};

char *month[12]={
"January","February","March","April","May","June",
"July","August","September","October","November","December"
};

char *noyes1[]={" NO","YES"};
char *noyes2[]={"NO ","YES"};

char *swear_words[]={
"fuck","shit","cunt","pussy","asshole","dick","*"
};

char allcolor[50];
char annoystring[ARR_SIZE];
char confile[40];
char croncom[ARR_SIZE];
char cronuser[USER_NAME_LEN+1];
char killem[USER_NAME_LEN+1];
char md[3];
char motd[ARR_SIZE];
char progname[40];
char text[ARR_SIZE];
char thisdomain[40];
char thishost[40];
char verification[SERV_NAME_LEN+1];
char wholeaddy[80];
char word[MAX_WORDS][WORD_LEN+1];
char wrd[8][81];
int atmos;
int auto_connect;
int ban_games;
int ban_greets;
int ban_hunting;
int ban_pictells;
int ban_quitting;
int ban_shouting;
int ban_smailing;
int ban_smoking;
int ban_socials;
int ban_suicides;
int ban_swearing;
int ban_willkill;
int bigcatstage;
int color_def;
int config_line;
int crash_action;
int cron_check_hour;
int cron_check_min;
int crononce;
int cronset;
int destructed;
int difflogin;
int force_listen;
int garbled;
int gatecrash_level;
int goingdown;
int goingdown2;
int goingdown3;
int goingdown4;
int gossamer;
int heartbeat;
int hehehe;
int hour;
int ignore_mp_level;
int ignore_sigterm;
int keepalive_interval;
int listen_sock[4];
int login_idle_time;
int loginplace;
int lplace;
int max_clones;
int max_users;
int mesg_check_hour;
int mesg_check_min;
int mesg_life;
int midnight;
int midnighthour;
int min_private_users;
int minlogin_level;
int net_idle_time;
int nologin;
int num_of_logins;
int num_of_users;
int password_echo;
int port[4];
int prompt_def;
int rem_user_deflevel;
int rem_user_maxlevel;
int staythere;
int sys_mail;
int system_logging;
int tday;
int tempstore;
int thour;
int time_out_afks;
int tmday;
int tmin;
int tmonth;
int tsec;
int ttime;
int twday;
int tyear;
int user_idle_time;
int whologin;
int willkill;
int wizport_level;
int word_count;
jmp_buf jmpvar;
time_t bigcattime;
time_t boot_time;
time_t goingdown1;
