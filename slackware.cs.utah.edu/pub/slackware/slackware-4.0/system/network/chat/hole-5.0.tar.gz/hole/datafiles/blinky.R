[5;41;37m                       Welcome to the annoying blink room!                                                [0m
[5;47;34m          For your Entertainment Pleasure.. I present you this fun place.                                 [0m
[5;44;31m                         IT'S BLINKY LAND, OH NO!!! HAHAHAHA                                              [0m
[5;40;30m[1;40;33m               I hope you find this place as annoying as I do.                                  [0m
[5;45;37m                               Have a nice Day :)                                                        
[0m
