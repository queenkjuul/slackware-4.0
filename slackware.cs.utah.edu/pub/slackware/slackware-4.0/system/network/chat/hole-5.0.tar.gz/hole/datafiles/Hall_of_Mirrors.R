...sdrawkcab eb ot smees gnihtyrevE !srorriM_fo_llaH eht deretne evah uoY
