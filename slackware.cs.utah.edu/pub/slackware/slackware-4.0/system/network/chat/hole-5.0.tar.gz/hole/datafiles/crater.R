You are in a very deep crater. Red rocks and large dirtclods face you along
with giant fire ants that are about to eat you. Beyond them is a white haze
where this particular reality ends and death begins.
