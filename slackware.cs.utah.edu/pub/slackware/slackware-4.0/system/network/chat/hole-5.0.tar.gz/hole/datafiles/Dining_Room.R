This is the dining room. In the next room you can see the chef cooking up
something mighty delicious. Hmm, must be done.
