As you enter the rowdy sports_room you hear a loud cheer erupt from those
already there watching the big game on the big screen TV. You see a bartender
serving drinks to all who want one because everyone has to stay loose and
casual. There is plenty of room, so come in, relax, and root for you favorite
team to bring home a victory!
