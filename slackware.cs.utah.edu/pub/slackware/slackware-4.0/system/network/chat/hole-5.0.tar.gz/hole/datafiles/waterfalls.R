As you stand upon the little bridge you feel as if you may fall any moment
into the gushing water.
