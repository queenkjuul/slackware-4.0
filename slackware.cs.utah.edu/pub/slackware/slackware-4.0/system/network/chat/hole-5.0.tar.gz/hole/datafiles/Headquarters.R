Welcome to Headquarters, This is where the Generals sleep at night until
they can afford a better place to stay.
