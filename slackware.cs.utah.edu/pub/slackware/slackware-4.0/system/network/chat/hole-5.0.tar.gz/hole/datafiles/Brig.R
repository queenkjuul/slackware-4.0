                             You're in Jail

You wake up face down on the red and pink checked E-Z-Kleen linoleum floor.
You recognize the pattern, it's the type preferred in the internal briefing
security cells. When you look around, you see that you are alone in a small
jail cell. You wonder if you will make it out alive.
