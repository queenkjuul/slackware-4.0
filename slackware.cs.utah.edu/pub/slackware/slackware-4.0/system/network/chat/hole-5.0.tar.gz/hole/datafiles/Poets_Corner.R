You have just entered a room dedicated to poetry.  On the walls you can see
many photos of the great poets of our time.  The message board in this room
is HOLE's place for your personal and original poetry.  So please feel free
to add something original to the board.  Then sit back on the black leather
sofa and enjoy.
