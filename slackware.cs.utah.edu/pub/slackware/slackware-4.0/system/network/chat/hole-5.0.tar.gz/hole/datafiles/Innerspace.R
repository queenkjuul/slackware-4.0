You have just been injected into Martin Short.. hold on tight!
