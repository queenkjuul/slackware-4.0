It's kind of foggy in here and I haven't the foggiest as to why.
