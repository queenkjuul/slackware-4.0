You have entered AVALANCHE_WORLD. You can see dead bodies under piles of
rocks everywhere. You better be very, very quiet or you might end up like
them.
