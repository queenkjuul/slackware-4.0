It's very dark and moist in here. You hear water dripping in the distance.
drip drip drip drip  Insanity is calling your name. Bats flutter around you
as you begin to panic... Something touches your back.. do you dare turn around?
Maybe not.. but if you do.. Boo!!!!!!!!!!!!!!!
