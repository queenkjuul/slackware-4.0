/*************************************************************************/
/*                  VChat interactive IP-level chat system               */
/*-----------------------------------------------------------------------*/
/*  (c) '93/'94 by Andreas S. Wetzel (mickey@deadline.bln.sub.org)       */
/*                 All rights reserverd.                                 */ 
/*-----------------------------------------------------------------------*/
/* See the file COPYRIGHT in the top level directory of VChat for        */
/* copyright notices and further disclaimers.                            */ 
/*************************************************************************/

/* If you want color support for linux console  */
/* to be compiled in uncomment the following:   */

#define	HAS_COLOR_CONSOLE

/* If you expect to run the vping server under  */
/* the inetd super-server, uncomment the this:  */

#define	VPING_INETD

/* This define is currently for test purposes   */
/* only, and does actually not work correctly.  */

/* #define VSERVER_INETD */

/* Uncomment the following if you want audio    */
/* support to be compiled in.                   */
/* Audio support should work on FreeBSD and	*/
/* Linux systems using the sound driver 2.0	*/
/* or higher.					*/

#define	AUDIO

/* The following defines should not be changed  */
/* until really necessary. The portnumbers for  */
/* the vserver and vping are dafaults, and can  */
/* be overridden in non-inetd mode via the "-p" */
/* commandline option of vserver and vping!     */

#define		MAXCLIENTS	25		/* Maximum number of clients	*/
#define		SERVER_PORT	1168		/* Default vserver port number	*/
#define		PING_PORT	1169		/* Default vping port number	*/
#define		SVMSGBUF	8192		/* Buffersize for server msgs.  */
#define		MAXUSERS	256		/* Max. number of users in who  */


/* The following enables absolute alpha code	*/
/* to fix a bug where the communication breaks	*/
/* down on SLIP connections if the server or	*/
/* client cannot get the complete amount of	*/
/* data requested within a given time.		*/
/* -------------------------------------------- */
/* This code uses the SO_RCVTIMEO socket option */
/* to increase the socket receive inactivity	*/
/* timer to a value reasonable for slow SLIP	*/
/* connections.					*/
/* -------------------------------------------- */
/* WARNING: This is known not to function on    */
/*          Linux systems, so don't bother if	*/
/*          you get odd results using Linux.	*/

#define		SLIP_FIX			/* !!!!! USES ALPHA CODE !!!! */

#define		RCVTMOUT_SEC	6		/* Socket receive timeout (sec) */
#define		RCVTMOUT_USEC	0		/* Socket receive timeout (usec)*/
