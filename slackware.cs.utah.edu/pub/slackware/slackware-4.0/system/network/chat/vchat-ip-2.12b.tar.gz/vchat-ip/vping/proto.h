/*************************************************************************/
/*                  VChat interactive IP-level chat system               */
/*-----------------------------------------------------------------------*/
/*  (c) '93/'94 by Andreas S. Wetzel (mickey@deadline.bln.sub.org)       */
/*                 All rights reserverd.                                 */ 
/*-----------------------------------------------------------------------*/
/* See the file COPYRIGHT in the top level directory of VChat for        */
/* copyright notices and further disclaimers.                            */ 
/*************************************************************************/

/****** vping.c *****/

void	main(int argc, char *argv[]);
void	ping(int fd, struct ping_cmd *pcmd, char *arg);
void	who(int fd);
char	*logged_in(char *user);

/***** audio.c *****/

void	audio_out(void);
int	get_param(int d);

/******* subr.c ******/

void	init(int argc, char *argv[]);
void	usage(char *fmt, ...);
void	log(int pri, char *fmt, ...);
void	put_sysinf(int fd);
