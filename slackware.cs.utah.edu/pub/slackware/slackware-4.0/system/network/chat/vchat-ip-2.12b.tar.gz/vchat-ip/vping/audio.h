/*************************************************************************/
/*                  VChat interactive IP-level chat system               */
/*-----------------------------------------------------------------------*/
/*  (c) '93/'94 by Andreas S. Wetzel (mickey@deadline.bln.sub.org)       */
/*                 All rights reserverd.                                 */ 
/*-----------------------------------------------------------------------*/
/* See the file COPYRIGHT in the top level directory of VChat for        */
/* copyright notices and further disclaimers.                            */ 
/*************************************************************************/

#define		DEADSNDID		0x4a02b6d2

#define		STEREO			0x1
#define		MONO			0x0

#define		DEF_DSP_MODE		MONO
#define		DEF_DSP_SPEED		8000
#define		DEF_SAMPLESIZE		8
#define		DEF_8_DEVICE		"/dev/dsp"
#define		DEF_12_DEVICE		"/dev/dsp1"
#define		DEF_16_DEVICE		"/dev/dsp16"
