#ifndef lint
static char RCS_id[] = "$Id: readctl.c,v 1.2 1991/12/03 15:43:56 christos Exp $";
#endif

/*
 * $Log: readctl.c,v $
 * Revision 1.2  1991/12/03  15:43:56  christos
 * Working version for 1.02
 *
 * Revision 1.1  1991/12/03  15:14:18  christos
 * Initial revision
 *
 */
#include "defs.h"
#include "../common.h"

/*
 *  Read a message on the control socket and act upon it.
 */

readctl()
{
    int     ack;		/* = 1 if this is a good message */
    int     r;			/* number of chars read */
    char    buf[512];		/* input buffer */
    int     len;		/* length of return address */
    struct sockaddr_in from;

    len = sizeof(from);
    if ((r = recvfrom(ctl, buf, 512, 0, &from, &len)) == 0) {
	error(0, "read: control socket");
	return;
    }

    if (*buf != ESC) {		/* bad control packet */
	error(0, "malformed control packet");
	return;
    }

    buf[r] = '\0';

    ack = buf[2] == ACK;

    switch (buf[1]) {		/* command character */
    case CALLING:
	if (!ack)		/* can't call a user */
	    delete(buf + 3);
	putmessage(buf + 8);
	break;

    case PAGE:
	if (!ack) {		/* couldn't place call */
	    pending--;
	    putmessage(buf + 3);
	}
	break;

    case INQUIRE:
	break;			/* don't do anything */

    case DAEMON:
	break;			/* and again */

    case MESSAGE:
	message(buf + 3);	/* show message */
	break;

    case ANSWER:
	delete(buf + 3);	/* someone answered a call */
	if (Debug) {
	    char    mbuf[80];

	    sprintf(mbuf, "Answer on id >>%s<<", buf + 3);
	    putmessage(mbuf);
	}
	break;
    }
}
