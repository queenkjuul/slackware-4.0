/*
 * $Header: /usr/share/src/local/common/bin/phone/client/RCS/defs.h,v 1.2 1991/12/03 15:43:56 christos Exp $
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define BUFFER      512		/* internal character buffer size */

extern char *strsave();
extern char *malloc();
extern char *basename();
extern char *expalias();

extern char *login;		/* user's login name       */
extern char *tty;		/* tty he's on             */
extern char *home;		/* home directory          */
extern char *shell;		/* preferred shell         */
extern char host[];		/* local host name         */
extern char realname[];		/* from password file      */
extern int maxx;		/* max legal x coordinate  */
extern int maxy;		/* max legal y coordinate  */
extern int stream;		/* stream socket filedes   */
extern int ctl;			/* control socket fd       */
extern int reading;		/* currently reading kb?   */
extern char buf[];		/* general-use buffer      */
extern int pending;		/* number of pending calls */
extern int connected;		/* number of connected people */
extern int touched25;		/* message changed line 25 */
extern struct sockaddr_in locaddr;	/* localhost address   	   */
extern char convaddr[];		/* conversation address    */
extern int port;		/* phoned socket port      */
extern int users;		/* number of users connected */

#ifndef	ESC
#define	ESC		'\033'
#endif

#define PROMPT  "Command> "

#define ctrl(C)     (C-'@')
#define isdigit(c)  ('0' <= c && c <= '9')
#define	equal(a,b)  (strcmp (a,b) == 0)


/*
 *  Various oft-used flags.
 */

extern int Interval;		/* seconds between messages */
extern int Inverse;		/* allow use of inverse video */
extern int Stop;		/* print "Stopped" to socket on ^Z */
extern int Debug;		/* verbose tracing stuff */
extern int Bells;		/* let ^G come through as bell */
extern int Hold;		/* send input to child process */
extern int Echo;		/* send input to socket when running prog */
