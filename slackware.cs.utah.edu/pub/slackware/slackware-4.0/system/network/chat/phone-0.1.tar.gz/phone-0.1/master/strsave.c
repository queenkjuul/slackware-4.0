#ifndef lint
static char     RCSid[] = "$Id: strsave.c,v 1.2 1991/12/03 15:10:18 christos Exp $";
#endif

/*
 * $Log: strsave.c,v $
 * Revision 1.2  1991/12/03  15:10:18  christos
 * Indented
 * 
 * Revision 1.1  85/10/28  17:38:36  broome
 * Initial revision
 * 
 */

/*
 * Allocate enough space for the given string and copy it over.
 */

char           *
strsave(s)
    char           *s;
{
    char           *malloc();
    char           *new;

    if (new = malloc(strlen(s) + 1))
	strcpy(new, s);
    return (new);
}
