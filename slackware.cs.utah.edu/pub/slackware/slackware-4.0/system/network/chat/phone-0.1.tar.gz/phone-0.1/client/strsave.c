#ifndef lint
static char RCS_id[] = "$Id: strsave.c,v 1.2 1991/12/03 15:43:56 christos Exp $";
#endif

/*
 * $Log: strsave.c,v $
 * Revision 1.2  1991/12/03  15:43:56  christos
 * Working version for 1.02
 *
 * Revision 1.1  1991/12/03  15:14:18  christos
 * Initial revision
 *
 */
#include <signal.h>
#include <stdio.h>

/*
 *  Allocate enough space for the given string and copy it over.
 */

char   *
strsave(s)
char   *s;
{
    register char *new;
    char   *malloc();

    if (s != NULL) {
	if (new = malloc((unsigned) (strlen(s) + 1)))
	    strcpy(new, s);
	else
	    error(1, "strsave: cannot malloc memory");

	return (new);
    }
    else
	return (NULL);
}
