#ifndef lint
static char RCS_id[] = "$Id: readrc.c,v 1.2 1991/12/03 15:43:56 christos Exp $";
#endif

/*
 * $Log: readrc.c,v $
 * Revision 1.2  1991/12/03  15:43:56  christos
 * Working version for 1.02
 *
 * Revision 1.1  1991/12/03  15:14:18  christos
 * Initial revision
 *
 */
#include "../common.h"
#include "defs.h"
#include <stdio.h>

#ifndef PHONERC
#define PHONERC	"/.phonerc"
#endif


/*
 *  Open the .phonerc and do the stuff in it.
 */

readrc()
{
    char    line[BUFSIZ];
    char   *i;
    FILE   *rc;

    strcpy(buf, home);
    strcat(buf, PHONERC);

    if ((rc = fopen(buf, "r")) == (FILE *) 0)
	return;

    while (fgets(line, BUFSIZ, rc)) {
	if (Debug)
	    printf("Rc: %s", line);
	if (*line == '#' || *line == '\n')
	    continue;
	if (i = index(line, '\n'))
	    *i = '\0';
	execute(line);
    }
    fclose(rc);
}
