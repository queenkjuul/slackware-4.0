#ifndef lint
static char RCS_id[] = "$Id: version.c,v 1.2 1991/12/03 15:43:56 christos Exp $";
#endif

/*
 * $Log: version.c,v $
 * Revision 1.2  1991/12/03  15:43:56  christos
 * Working version for 1.02
 *
 * Revision 1.1  1991/12/03  15:14:18  christos
 * Initial revision
 *
 */
char   *version_string = "1.02";
