#ifndef lint
static char RCS_id[] = "$Id: stop.c,v 1.2 1991/12/03 15:43:56 christos Exp $";
#endif

/*
 * $Log: stop.c,v $
 * Revision 1.2  1991/12/03  15:43:56  christos
 * Working version for 1.02
 *
 * Revision 1.1  1991/12/03  15:14:18  christos
 * Initial revision
 *
 */
#include <signal.h>
#include <curses.h>
#include "defs.h"

/*
 *  Routine to handle SIGTSTP and the like.
 */

sigstop()
{
#ifdef SIGTSTP
    extern int stream;
    extern int maxy;

    SIG_TYPE(*func) ();


    func = signal(SIGTSTP, SIG_DFL);	/* save old SIGTSTP routine */

    if (Stop)
	(void) write(stream, "\n[ Stopped ]", 12);

#ifndef hpux
    tstp();			/* curses routine to stop and restart */
#else
    _tstp();
#endif

    if (Stop)
	(void) write(stream, "\r\f", 2);	/* clear this line */

    signal(SIGTSTP, func);	/* and restore SIGTSTP routine */
#endif
}

#ifdef aiws
#define _sigvec_
#endif				/* aiws */

#ifdef hpux
#define _sigvec_
#endif				/* hpux */

#ifdef _sigvec_
/* turn into bsd signals */
SIG_TYPE(*
	 signal(s, a)) ()
int     s;

SIG_TYPE(*a) ();
{
    struct sigvec osv,
            sv;

#ifdef aiws
    sigvec(s, 0, &osv);
#else
    sigvector(s, 0, &osv);
#endif				/* aiws */
    sv = osv;
    sv.sv_handler = a;
#ifdef aiws
    sv.sv_onstack = SIG_STK;
#else
    sv.sv_flags = SV_BSDSIG;
#endif				/* aiws */
#ifdef aiws
    if (sigvec(s, &sv, 0) < 0)
#else
    if (sigvector(s, &sv, 0) < 0)
#endif				/* aiws */
	return (BADSIG);
    return (osv.sv_handler);
}

#endif				/* _sigvec_ */
