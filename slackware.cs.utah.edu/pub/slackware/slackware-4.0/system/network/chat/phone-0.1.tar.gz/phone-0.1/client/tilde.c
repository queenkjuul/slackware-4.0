#ifndef lint
static char RCS_id[] = "$Id: tilde.c,v 1.2 1991/12/03 15:43:56 christos Exp $";
#endif

/*
 * $Log: tilde.c,v $
 * Revision 1.2  1991/12/03  15:43:56  christos
 * Working version for 1.02
 *
 * Revision 1.1  1991/12/03  15:14:18  christos
 * Initial revision
 *
 */
#include <pwd.h>
#include "../common.h"
#include "defs.h"

/*
 *  Expand a name containing a tilde to the full pathname.
 */

char   *
exptilde(str)
char   *str;
{
    char    buf[512];
    char    name[20];
    char   *i;
    char   *getenv(),
           *strsave();
    struct passwd *pw,
           *getpwnam();

    if (*str != '~')		/* doesn't contain a tilde */
	return (strsave(str));

    if (i = index(str, '/'))	/* find slash, if any */
	*i = '\0';

    strcpy(name, str + 1);	/* copy name after tilde */

    if (*name == '\0')		/* was "~/" */
	strcpy(buf, getenv("HOME"));	/* so use our home */
    else {
	if ((pw = getpwnam(name)) == (struct passwd *) 0) {
	    sprintf(buf, "Unknown user: %s", name);
	    putmessage(buf);
	    return ((char *) 0);
	}
	strcpy(buf, pw->pw_dir);/* fill in that user's home */
    }
    if (i) {
	*i = '/';		/* and put back trailing pathname */
	strcat(buf, i);
    }
    return (strsave(buf));
}
