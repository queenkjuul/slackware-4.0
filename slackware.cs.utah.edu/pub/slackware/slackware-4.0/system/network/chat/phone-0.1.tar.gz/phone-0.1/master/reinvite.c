#ifndef lint
static char     RCSid[] = "$Id: reinvite.c,v 1.2 1991/12/03 15:10:18 christos Exp $";
#endif

/*
 * $Log: reinvite.c,v $
 * Revision 1.2  1991/12/03  15:10:18  christos
 * Indented
 * 
 * Revision 1.1  85/10/28  17:38:35  broome
 * Initial revision
 * 
 */

#include "../common.h"
#include "defs.h"

/*
 * Reinvite the given invitation by resetting the `rings' field to zero.
 */

reinvite(argv, sin)
    char          **argv;
    struct sockaddr_in sin;
{
    register INV   *inv;
    register int    found = 0;

    for (inv = invitations; inv; inv = inv->next) {
	if (strcmp(inv->id, *argv) == 0 &&
	  bcmp((char *) &sin, (char *) &(inv->ctladdr), sizeof(sin)) == 0) {
	    inv->rings = 0;
	    found = 1;
	    break;
	}
    }
    sprintf(buf, "%c%c%c%s", ESC, REINVITE, found ? ACK : NAK, *argv);
    sendto(misc, buf, strlen(buf), 0, &sin, sizeof(sin));
}
