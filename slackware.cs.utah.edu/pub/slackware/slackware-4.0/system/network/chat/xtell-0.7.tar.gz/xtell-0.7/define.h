/*
 * Port to bind to.
 */
#define XTELL_DEFAULT_PORT      4224

#define MAX_MSG_LENGTH		1024
#define MAX_LUSERNAME_LENGTH	20
#define MAX_TTY_LENGTH		8
#define MAX_HOSTNAME		255
#define MAX_SOCK_LENGTH		(MAX_MSG_LENGTH+MAX_LUSERNAME_LENGTH*2+MAX_TTY_LENGTH+5)

#define ID_VERSION              "v0.7"

/* uncomment following, if you do not have libident installed */
/* #define DONT_HAVE_LIBIDENT */

/* uncomment following, if you do not have snprintf on your system */ 
/* #define DONT_HAVE_SNPRINTF  */