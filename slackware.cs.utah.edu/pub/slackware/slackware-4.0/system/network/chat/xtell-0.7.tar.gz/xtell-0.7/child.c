/* ==================================================================
 *	CHILD.C
 *	-------
 *
 *	This module is responsible for running 
 *	xtell as a child service of inetd.
 *	It cares for this child like a good parent should,
 *	providing vital nutrients, love, support, child
 *	reapers, and built in functionality to have the
 *	child kill itself if it stays alive too long.
 *
 * ================================================================== 
 */


#include "xtelld.h"
#ifdef DONT_HAVE_LIBIDENT 
#define ident_id(a,b) NULL
#else
#include "ident.h"
#endif

static int s_in = -1, s_out = -1;

/* ------------------------------------------------------------------
 * lookup_addr:
 *      if resolve_addr, try to reverse resolve the address.
 *              else return the numerical ip.
 *      else return the numerical ip.
 * ------------------------------------------------------------------
 */
static char	*lookup_addr (struct in_addr in)
{
	static char addr[100];
	struct hostent *he;
      
	if (resolve_addr) {
		he = gethostbyaddr ((char *)&in, sizeof(struct in_addr), AF_INET);
		if (he == NULL)
			strcpy(addr, inet_ntoa(in));
		else
			strcpy(addr, he->h_name);
	}
	else
		strcpy (addr, inet_ntoa (in));
      
	return addr;
}
           

                                                                                                                                                                                   
/* ----------------------------------------------------------------
 * killtic:
 *	kill this process after a pre-determined
 *	timeout period. (SIGALRM handler)
 * ----------------------------------------------------------------
 */
void xtell_killtic (int s)
{
	killsock (s_in);
	killsock (s_out);
	exit (0);
}


/* ------------------------------------------------------------------
 * inetd_service:
 *	this function does the actual pipe handling
 *	user lookups, replies, etcetera. if called
 *	by the daemon, sd_in and sd_out will be
 *	the same descriptor, if a child of inetd,
 *	sd_in will be stdin, sd_out will be stdout
 * ------------------------------------------------------------------
 */
void inetd_service (int sd_in, int sd_out)
{
	struct in_addr laddr, raddr;
	struct sockaddr_in sin;
	char  buffer[MAX_SOCK_LENGTH];
	int sinsize = sizeof (struct sockaddr_in);
	int reqstat;
	unsigned int msgcount;

					
	s_in = sd_in;
	s_out = sd_out;
	
	if (getpeername (sd_in, (struct sockaddr *)&sin, &sinsize) == -1) {
		syslog (LOG_NOTICE, "error: getpeername: %s", strerror(errno));
		client_reply (sd_out, "401 getpeername failed\r\n");
		return;		/* the error implies the net is down, but try */
	}
	raddr = sin.sin_addr;

	if (getsockname (sd_in, (struct sockaddr *)&sin, &sinsize) == -1) {
		syslog (LOG_ERR, "error: getsockname: %s", strerror(errno));
                client_reply (sd_out, "402 getsockname failed\r\n");
		return;
	}
	laddr = sin.sin_addr;
	

	msgcount = 0;				
	reqstat = get_request (sd_in, buffer, MAX_SOCK_LENGTH);
	
	while ((reqstat >= 0) && (strncasecmp (buffer,"quit",4))) {
		if (reqstat) { 
			switch (parse_and_write(buffer, ident_id(sd_in,5), lookup_addr (raddr), ++msgcount)) {
			case 0 : client_reply (sd_out, "200 OK, sent. \r\n"); break; /* OK */
			case -1: client_reply (sd_out, "403 User is not here.\r\n"); break; /* not logged in */
			case -2: client_reply (sd_out, "404 User does not want you.\r\n"); break; /* not logged in */
			case -3: client_reply (sd_out, "404 Cannot write to that user's tty.\r\n"); break; /* mesg n or bad tty given*/
			case -4: client_reply (sd_out, "400 Ehhh?\r\n"); break; /* other error */
			}
		}

		reqstat = get_request (sd_in, buffer, MAX_SOCK_LENGTH);
			
	}

}
