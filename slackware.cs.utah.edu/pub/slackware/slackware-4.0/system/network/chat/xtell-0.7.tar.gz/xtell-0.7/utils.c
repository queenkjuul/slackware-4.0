#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#ifdef DONT_HAVE_SNPRINTF

int snprintf(char * str,int maxlen,const char * format,...)
{
  va_list ap;
  int len;
  char * ptr;
  int count=0;

  ptr=strdup(format);
  va_start(ap,format);
  do {
    ptr=strchr(ptr,'%');
    if (ptr!=NULL) {
      ptr++;
      count++;
    }
  } while(ptr);
  if (count==1) {
    sprintf(str,format,va_arg(ap,char *));
  }
  else if (count==2) {
    sprintf(str,format,va_arg(ap,char *),va_arg(ap,char *));
  }
  va_end(ap);
  *(str+maxlen)='\0';
  free(ptr);
}

#endif
