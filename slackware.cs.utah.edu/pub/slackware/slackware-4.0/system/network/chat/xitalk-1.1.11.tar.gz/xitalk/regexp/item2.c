#include <config.h>
#include <stdio.h>
#include <regexp.h>

/* ARGSUSED */
main(argc, argv)
int argc;
char *argv[];
{
	char one[] = "one";
	char two[] = "one";
	regexp *r;
	int i;
	char *pointer;
	
	r = nregcomp(one);
	if (r == NULL)
		fprintf(stderr,"nregcomp failure");
	
	if (argc > 2) {
		i = nregexec(r, argv[2]);
		printf("%d", i);
		for (i = 1; i < NSUBEXP; i++)
			if (r->startp[i] != NULL && r->endp[i] != NULL)
				{
				printf(" \\%d", i);
				printf("substring? is ");
				pointer = r->startp[i];
				while(pointer != r->endp[i])
					printf("%c",*pointer++);
				printf("\n");
					
				}
		printf("\n");
	}

}

