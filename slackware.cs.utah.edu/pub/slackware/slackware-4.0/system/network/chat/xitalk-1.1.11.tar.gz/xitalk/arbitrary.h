#ifndef HEAD_THING
#define HEAD_THING
#define MAX_TITLE 4096
#define MAX_COMMAND 4096
#define MAX_PATTERN 4096
#define MAX_PICTURE 4096

/*used for atoi the (Px) jazz*/
#define BIT_BUCKET 255  

/*max length of an input string*/
#define MAX_SPAM 20000

  /* "/dev/[pt]tyXY" = 10 chars + null byte */
#define MAX_PTY_NAME_LENGTH 10

/*size by which the size of the who list will jump when it has to*/
#define WHO_LIST_INC 11

/*to be userdefinable*/
#define MAX_NUM_COMMANDS 10

/*length of username*/
#define USRNAMLEN 8

/*length of configuration line*/
#define LINELEN 2048

/*length of a file*/
#define MAXFILELEN 2048

/*default mail file check time*/
#define DEFAULT_INTERVAL 8
#endif
