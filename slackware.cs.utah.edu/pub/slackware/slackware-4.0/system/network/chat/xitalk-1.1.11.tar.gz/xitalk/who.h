#ifndef WHO_HEADER
#define WHO_HEADER
int who(void);
void add_who_tty(char *,char *);

/*rather swish reallocation macro from sced*/
/*variable,type,newsize*/
#define Increase(x, t, n) (t*)realloc((char*)x, sizeof(t) * (n))


/*tum te tum*/
extern int who_alarm_on;
extern char **who_list;
extern char **tty_list;
extern int who_tty_list_size;
extern int who_tty_list_number;

#endif WHO_HEADER
