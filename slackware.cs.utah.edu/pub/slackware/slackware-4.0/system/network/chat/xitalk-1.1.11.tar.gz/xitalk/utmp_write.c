#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>

#include <X11/Xlib.h>

char pty_name[12]="/dev/ttyXX";
char *tty = pty_name + 5;


Display *temp_d=NULL;

void write_user_into_utmp(char *display)
	{
	/*
	struct passwd *my_pass;
	my_pass = getpwuid(getuid());
	Wtmp(my_pass->pw_name,tty+3,getpid(),USER_PROCESS,tty,DisplayString(temp_d));
	*/

	makeutent (tty, display );	
	}


void write_user_outof_utmp(void)
	{
	/*
	struct passwd *my_pass;
	my_pass = getpwuid(getuid());
	Wtmp(my_pass->pw_name,tty+3,getpid(),DEAD_PROCESS,tty,DisplayString(temp_d));
	*/
	cleanutent();	
	}
