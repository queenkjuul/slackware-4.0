void write_user_into_utmp(char *);
void write_user_outof(void);
