#ifndef QWERTY_HISTORY
#define QWERTY_HISTORY

#include "arbitrary.h"

struct random
    {
    struct random *last;
    char command[MAX_COMMAND];
    struct random *next;
    };

typedef struct random entry;

struct top
    {
    entry *top;
    entry *last;
    entry *current;
    int max_entries;
    int current_entries;
    int snap_current_to_newest;
    int autopop;
    int consider_last_entry_temp;
    };

typedef struct top list;

int max_number_of_list_entries;


#define NO_MAX_IN_LIST -1

void init_list(list *,int ,int ,int);
int add_to_end(list *,const char *);
int remove_from_top(list *);
int remove_from_end(list *);
int forward_current(list *);
int backward_current(list *);
const char * return_current(list *);
void list_error(char *,int );
void write_list(list *);
#endif
