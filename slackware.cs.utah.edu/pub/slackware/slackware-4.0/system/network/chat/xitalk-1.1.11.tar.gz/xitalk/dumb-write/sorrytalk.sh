#!/bin/sh
if [ "$2" = hostname -f ]; then
/bin/echo -e " Sorry but im not actually here at the moment \\n \
your request is currently being replied to by xitalk \\n \
coz ive no intention of doing it myself \\n \
please mail caolan@skynet.csn.ul.ie to leave a message \\n \
Caolan \\n "| dwrite $1 
fi
