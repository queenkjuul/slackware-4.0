#include <signal.h>


/*Xlib*/
#include <X11/Xlib.h>

/*Xt*/
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include "main.h"


typedef struct	{
	int fd;
	int *autoanswer;
	int *autorun;
	Widget log_widget;
	Widget EditResponse;
	Widget respond;
	Widget ack;
	Widget command;
	node *head;
	det_node *det_head;
	init_info *init;
	mail_node *mail;
	}fd_and_widgets;

typedef struct {
	Widget toplevel;
	XtAppContext app;
	config_node *config_head;
	node *head;
	det_node *det_head;
    init_info *init;
	mail_node *mail;
	Widget autorun;
	Widget autoanswer;
	Widget autorefresh;
	}app_wid_pid;

typedef struct {
	Widget one;
	Widget two;
	}widget_pair;

typedef struct {
    app_wid_pid *info;
	fd_and_widgets *F_W;
    char *filename;
    }silly_c;

typedef struct {
	fd_and_widgets *F_W;
	mail_node *mail;
	}
	silly_b;

void open_window(int ,char **,int,int);
void read_pty_input(fd_and_widgets *);
void clear_activity(Widget,init_info*,XtPointer );
void respond(Widget,fd_and_widgets *,XtPointer );
void quit(Widget ,app_wid_pid *,XtPointer );
void die_die(XtPointer );
Widget create_popup(Widget ,XtAppContext *,int ,Widget,node *,det_node *,config_node *,init_info *,mail_node*,fd_and_widgets *);
void popup_thing(Widget ,Widget ,XtPointer );
void popdown_thing(Widget ,Widget ,XtPointer );    
void popdown(Widget ,widget_pair *,XtPointer );
Widget create_dialog(Widget ,app_wid_pid *,XtPointer );
void up_arrow(Widget ,fd_and_widgets *,XtPointer );
void down_arrow(Widget ,fd_and_widgets *W_P,XtPointer );
void autorun(Widget ,fd_and_widgets *,XtPointer );
void autoanswer(Widget ,fd_and_widgets *,XtPointer );
void refresh(Widget ,XtPointer ,XtPointer );
void autorefresh(Widget ,XtPointer ,XtPointer );
void popdown_dialog(Widget ,Widget,XtPointer );
void popup_temp(Widget ,Widget ,XtPointer );
void QuitAction();
void CloseAction();
void xterrorthing(void);
int xioerror(Display *);
int xerror(Display *, register XErrorEvent *);
void ActionToCallback(Widget, XEvent *,String *, Cardinal *);
void who_signal(int );
void determine_tty(Widget ,XtPointer ,XtPointer );
void determine_who(void);
void begin_comm(Widget ,char *,XtPointer );
void create_default_patterns(node *,det_node *,config_node *,init_info *,mail_node*);
void get_picture(node *);
void CreateCommand(app_wid_pid *);
void CreateConfigs(app_wid_pid *,fd_and_widgets *);
void PurgeCommands(app_wid_pid *);
void PurgeConfigs(app_wid_pid *,fd_and_widgets *F_W);
void free_up(app_wid_pid * );
void re_init(Widget , silly_c *, XtPointer );
void fix_pics(node *,char *);
void fix_init(app_wid_pid *);
void mainpic(init_info *);
void get_mainpic(init_info *);
void organize_filewatch(fd_and_widgets *);
void proc(silly_b*);
void get_mailpic(mail_node *,char *);
void get_mail_picture(mail_node *);
void do_sound(char *,char *,char *);

int ParsePattern (node *);
int ParseConfig(config_node *);
int ParseMenu(det_node *);
int Parse(FILE *,node *,det_node *,config_node *,init_info *,mail_node *);
int ParseMail(mail_node *);




