#include <config.h>
#include <stdio.h>

void
regerror(s)
char *s;
{
	fprintf(stderr, "xitalk:pattern match regexp(3): %s\n", s);
	/* REACHED , might be a real problem*/
}
