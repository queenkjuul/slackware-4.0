int pty_master(void);
int pty_slave(int);
