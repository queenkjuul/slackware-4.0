/*    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package au.com.bowerbird.firecat;

import java.lang.*;
import java.io.*;
import java.net.*;

/**
 * Handles the writing sending of status updates.
 *
 * @author Matthew Parry <a href="mailto:mettw@bowerbird.com.au">mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class TFPRegisterUser {
  public TFPRegisterUser(UserStatus us, String email, String url, 
			 String uname) 
    throws UnknownHostException, IOException {
    Socket socket;
    TFPRecord tfpr;
    String input = new String();

    socket = new Socket(us.getHost(), 7173);
    tfpr = new TFPRecord(socket.getInputStream(), socket.getOutputStream());

      tfpr.PutRecord("TFP 1.3");
      input = tfpr.GetRecord();
      if((input.trim()).equalsIgnoreCase("TFP 1.3")){
	  tfpr.PutRecord("NEWACC " + us.getTFA());
	  tfpr.PutRecord("PASSWORD " + us.getPassword());
	  tfpr.PutRecord("USERNAME " + uname);
	  tfpr.PutRecord("EMAIL " + email);
	  tfpr.PutRecord("URL " + url);

	  //read in reply here
      }else{
	  tfpr.PutRecord("SORRY 102, Unknown TFP version");
      }
    socket.close();
  }
}





