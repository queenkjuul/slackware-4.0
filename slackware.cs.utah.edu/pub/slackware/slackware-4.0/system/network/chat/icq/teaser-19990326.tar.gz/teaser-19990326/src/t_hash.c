/*
 * Teaser - A copyleft implimentation of RVP
 * Copyright (C) 1998, 1999 Matthew Parry <mettw@bowerbird.com.au
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Non-Consultants' License as published by
 * Bowerbird Computing; either version 1.2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Non-Consultants' License for more details.
 *
 * You should have received a copy of the Non-Consultants' License
 * along with this program; if not, write to Bowerbird Computing,
 * PO Box 247, Nowra NSW, Australia, 2541.
 */

#include <teaser.h>

typedef struct {
  char *key;
  char *value;
  Hashtab *atts;
} datum;

int
__hashcmp(datum *dt1, datum *dt2){

  return strcmp(dt1->key, dt2->key);
}

unsigned long
__hashstr(datum *dt){

  return strhash(dt->key);
}

Hashtab*
__get_atts_hashtab(Hashtab *ht, char *key){
  datum *result;
  datum dt = {key, NULL, NULL};

  result = hash_lookup(ht, &dt);

  return result->atts;
}

Hashtab*
t_hash_create(void){
  return hash_create(__hashstr, __hashcmp);
}

void
t_hash_destroy(Hashtab *ht){
  hash_destroy(ht);
}

char*
t_hash_get(Hashtab *ht, char *key){
  datum *result;
  datum dt = { key, NULL, NULL};

  result = hash_lookup(ht, &dt);

  if(result != NULL)
    return result->value;
  else
    return NULL;
}

int
t_hash_put(Hashtab *ht, char *key, char *value){
  datum dt;
  void *ret;

  asprintf(&dt.key, "%s", key);
  asprintf(&dt.value, "%s", value);

  ret = hash_install(ht, &dt, sizeof(dt));

  if(ret == NULL)
    return 0;
  else
    return 1;
}

int
t_hash_att_put(Hashtab *ht, char *key, char *att_key, char *att_value){
  datum dt = {key, NULL, NULL};
  datum att_dt = {att_key, att_value, NULL};
  datum *result;
  Hashtab *atts_ht;
  void *ret;
  
  result = hash_lookup(ht, &dt);
  
  if(result->atts == NULL){
    result->atts = hash_create(__hashstr, __hashcmp);
    hash_uninstall(ht, &dt);
    hash_install(ht, &result, sizeof(result));
  }

  ret = (void*) hash_install(result->atts, &att_dt, sizeof(att_dt));

  if(ret == NULL)
    return 0;
  else
    return 1;
}

char*
t_hash_att_get(Hashtab *ht, char *key, char *att_key){
  datum *result;
  datum *att_result;
  datum dt = { key, NULL, NULL};
  datum att_dt = {att_key, NULL, NULL};

  result = hash_lookup(ht, &dt);
  att_result = hash_lookup(result->atts, &att_dt);

  return att_result->value;
}

int
t_hash_delete(Hashtab *ht, char *key){
  datum dt;

  dt.key = key;

  dt.value = t_hash_get(ht, key);
  
  dt.atts = __get_atts_hashtab(ht, key);
  
  return hash_uninstall(ht, &dt);
}

