/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <teaser.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <fcntl.h>

void  firecat_updstat();
void  firecat_reqstat();
void  teaser_reqstat();
void teaser_updstat();
void teaser_stpstat();
void  firecat_stpstat();
void  newacc();
void  updacc();
void  reqemail();
void requrl();
void  reqipa();
void requname();

void disconnect_from_terminal();
void help();
void sigterm_handler();
void child_sigterm_handler();
void get_pid_file();
void get_lock_file();

struct sigaction child_death = {
  NULL,
  0,
  SA_NOCLDSTOP|SA_RESTART,
  NULL};

int
main (int argc, char **argv){
  boolean break_from_terminal = TRUE;
  boolean open_log_file = FALSE;
  db_functions db_funct[12];
  
  db_funct[0] = firecat_updstat;
  db_funct[1] = firecat_reqstat;
  db_funct[2] = teaser_reqstat;
  db_funct[3] = teaser_updstat;
  db_funct[4] = teaser_stpstat;
  db_funct[5] = firecat_stpstat;
  db_funct[6] = newacc;
  db_funct[7] = updacc;
  db_funct[8] = reqemail;
  db_funct[9] = requrl;
  db_funct[10] = reqipa;
  db_funct[11] = requname;

  port.port_num = 7173;

  /* First up, parse the command line options:
   * - if an alternative
   * log file is given then open it for writing instead.
   * - If -d is given then print all error messages to stderr (ie,
   * set logfd = -1.) and don't fork into the background.
   * - if --help|-h is given then print the usage message and exit.
   * ---Should really use getopt(), maybe later.
   */

  switch(argc){
  case 1:
    open_log_file = TRUE;
    break;
  case 2:
    if(strcmp(argv[1], "-d") == 0){
      logfd = -1;
      break_from_terminal = FALSE;
      break;
    }else if(strcmp(argv[1], "-h") == 0){
      help();
      exit(0);
    }
  default:
    help();
    exit(1);
  }

  /* We need to fork into the background and then make
   * sure we don't get any signals from the terminal or
   * reconnect to it.
   */
  if(break_from_terminal)
    disconnect_from_terminal();
  
  if(open_log_file)
    logfd = open("/var/log/teaser.log", 
		 O_WRONLY|O_CREAT|O_APPEND, 0600);

  t_error("Daemon started", FALSE);

  signal(SIGTERM, sigterm_handler);
  signal(SIGINT, sigterm_handler);
  signal(SIGQUIT, sigterm_handler);
  signal(SIGABRT, sigterm_handler);  
  signal(SIGFPE, sigterm_handler);
  signal(SIGILL, sigterm_handler);
  signal(SIGSEGV, sigterm_handler);
  sigaction(SIGCHLD, &child_death, NULL);

  get_pid_file();
  get_lock_file();

  /* Open a socket and set all the neccesary options on it.
   */

  if(open_server_socket(&port))
    t_error("couldn't open port", TRUE);

  /* Now continuously listen for connections and then handle
   * the IO.
   */

  if( -1 == listen(port.server_socket, BACK_LOG))
    t_error("Can't listen on port", TRUE);

  while(1){
    unsigned int status;
    int pid;

    struct client_info slave_socket = { 0 };
    
    /*    slave_socket.client_name = { 0 };*/
    slave_socket.client_length = sizeof(slave_socket.client_name);

    (void) memset(&slave_socket.client_name, 0, 
		  slave_socket.client_length);

    slave_socket.socket = accept(port.server_socket, 
				 (struct sockaddr *) 
				 &slave_socket.client_name,
				 &slave_socket.client_length);
    if(slave_socket.socket == -1)
      t_error("couldn't accept connection", FALSE);

    pid = fork();

    switch(pid){
    case -1:
      t_error("Couldn't fork child", TRUE);
    case 0: /* child process */
      signal(SIGTERM, child_sigterm_handler); 
      signal(SIGINT, child_sigterm_handler); 
      signal(SIGQUIT, child_sigterm_handler); 
      signal(SIGABRT, child_sigterm_handler); 
      signal(SIGFPE, child_sigterm_handler);
      signal(SIGILL, child_sigterm_handler);
      signal(SIGSEGV, child_sigterm_handler);

      handle_connection(slave_socket, db_funct);
      
      close(slave_socket.socket);
      exit(0);
    default: /* parent process */
      close(slave_socket.socket);
    }
  }
}

/* Forks the server into the background and then makes sure that
 * we don't get any signals from the terminal and that we can't
 * reconnect to it.
 *
 * This is only used in main()
 */

void
disconnect_from_terminal(){
  int tmpid;
  int tmpfd;
  int i;
  struct rlimit resource_limit = { 0 };
  
  tmpid = fork();

  /* fork into the background.
   */
  
  switch(tmpid){
  case -1:
    t_error("Couldn't do first fork()", TRUE);
  case 0: /* child */
    break;
  default: /* parent */
    exit(0);
  }

  resource_limit.rlim_max = 0;

  if(getrlimit(RLIMIT_NOFILE, &resource_limit) == -1)
    t_error("Problem with getrlimit()", TRUE);

  if(resource_limit.rlim_max == 0)
    t_error("Max number of file descs is 0.", TRUE);

  for(i = 0; i < resource_limit.rlim_max; i++)
    close(i);

  /* create a new group leader */
#if BSD
  {
    int bsdfd;

    stgrep(0, getpid());

    bsdfd = open("/dev/tty", O_RDWR);
    if(bsdfd != -1){
      ioctl(bsdfd, TIOCNOTTY, 0);
      close(bsdfd);
    }
  }
#elif SVR4
  setpgrp();
#else
  if(setsid() == -1)
    t_error("Error executing setsid()", TRUE);
#endif

  tmpid = fork();

  /* Now fork again so we have a new group leader and
   * therefore won't receive any signals from the shell.
   */
  switch(tmpid){
  case -1:
    t_error("couldn't do second fork", TRUE);
  case 0: /* child */
    break;
  default:
    exit(0);
  }

  /* chdir to root so we can unmount the filesystem the
   * program was launched on if we want to.
   */
  chdir("/");
  umask(0);

  /* Now reopen stdin/stduot/stderr pointing to /dev/null
   * incase some function need one of them.
   */
  tmpfd = open("/dev/null", O_RDWR); 
  dup(tmpfd);
  dup(tmpfd);
  
}

void
help(){

  fprintf(stderr, "usage: teaser -d|-h\n");
  fprintf(stderr, "-d\tDon't fork from the terminal and print\n");
  fprintf(stderr, "\tall logs to stderr.\n");
  fprintf(stderr, "-h\tPrint this error message.\n");
}

void
sigterm_handler(int sig){
  int status;

  switch(sig){
  case SIGTERM:
    t_error("SIGTERM caught, exiting...", FALSE);
    break;
  case SIGINT:
    t_error("SIGINT caught, exiting...", FALSE);
    break;
  case SIGQUIT:
    t_error("SIGQUIT caught, exiting...", FALSE);
    break;
  case SIGABRT:
    t_error("SIGABRT caught, exiting...", FALSE);
    break;
  case SIGFPE:
    t_error("SIGFPE caught, exiting...", FALSE);
    break;
  case SIGILL:
    t_error("SIGILL caught, exiting...", FALSE);
    break;
  case SIGSEGV:
    t_error("SIGSEGV caught, exiting...", FALSE);
    break;
  }

  unlink("/var/run/teaser.pid");
  close(teaserdb_lock);
  unlink("/var/lock/teaserdb.lock");
  t_error("Parent process exited.", FALSE);
  close(logfd);
  exit(sig);
}

void
child_sigterm_handler(int sig){

  switch(sig){
  case SIGTERM:
    t_error("SIGTERM caught by child, exiting...", FALSE);
    break;
  case SIGINT:
    t_error("SIGINT caught by child, exiting...", FALSE);
    break;
  case SIGQUIT:
    t_error("SIGQUIT caught by child, exiting...", FALSE);
    break;
  case SIGABRT:
    t_error("SIGABRT caught by child, exiting...", FALSE);
    break;
  case SIGFPE:
    t_error("SIGFPE caught by child, exiting...", FALSE);
    break;
  case SIGILL:
    t_error("SIGILL caught by child, exiting...", FALSE);
    break;
  case SIGSEGV:
    t_error("SIGSEGV caught by child, exiting...", FALSE);
    break;
  }

  exit(sig);
}

/* Try to get a pid file so we don't have more than one copy of
 * Teaser running at once.
 */

void
get_pid_file(){
  int fd;
  char pid[10];

  fd = open("/var/run/teaser.pid", O_RDONLY, NULL);

  if(fd == -1){
    fd = open("/var/run/teaser.pid", 
	      O_WRONLY|O_CREAT, 0644);
    if(fd == -1)
      t_error("Couldn't open pid file (/var/run/teaser.pid)", TRUE);
    
    sprintf(pid, "%d", getpid());
    write(fd, pid, strlen(pid));
    close(fd);
  }else{
    char *buf;

    read(fd, pid, 10);
    buf = malloc((strlen("Pid file (/var/run/teaser.pid) exists and contains pid ") + strlen(pid) + 1 )*sizeof(char));
    strcpy(buf, "Pid file (/var/run/teaser.pid) exists and contains pid ");
    strcat(buf, pid);
    t_error(buf, FALSE);
    exit(1);
  }
}

void
get_lock_file(){
 
  teaserdb_lock = open("/var/lock/teaserdb.lock", O_RDONLY, NULL);

  if(teaserdb_lock == -1){
    teaserdb_lock = open("/var/lock/teaserdb.lock", 
			 O_WRONLY|O_CREAT, 0644);
    if(teaserdb_lock == -1)
      t_error("Couldn't open database lock file (/var/lock/teaserdb.lock)", 
	      TRUE);
  }else{
    t_error("Database lockfile (/var/lock/teaserdb.lock) already exists",
	    FALSE);
    exit(1);
  }
}
