/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


package au.com.bowerbird.TFP;

import java.lang.*;
import java.awt.*;

/**
 * holds all of the relevant info about a particular user/contact.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * since alpha-i
 */

public class UserStatus{
  public boolean isFirecat;
  String TFA = new String();
  String reqTFA = new String();
  String host = new String();
  String password = new String();
  String status = new String();
  String domain_name = new String();
  Button user_button = new Button();

  /**
   * Constructor method.
   *
   * @param ifarg true if a firecat is using the class, false if a teaser.
   * @param tfaarg TFA to use.
   * @param sarg status of the user.
   * @param parg if a firecat the user password, if teaser then domain name.
   * @param harg Host to contact.
   */

  public UserStatus(boolean ifarg, String tfaarg, String sarg, String parg,
		    String harg){
    isFirecat = ifarg;
    TFA = tfaarg;
    status = sarg;
    host = harg;
    if(isFirecat){
      password = parg;
    }else{
      domain_name = parg;
    }
  }

  public UserStatus(boolean ifarg, String tfaarg, String harg, String rarg){
    isFirecat = ifarg;
    TFA = tfaarg;
    reqTFA = rarg;
    host = harg;
    user_button.setLabel(rarg);
  }

  /**
   * @return the button object for the user
   */
  
  public Button getButton(){
    return user_button;
  }

  /**
   * @return TFA of the user
   */

  public String getTFA(){
    return TFA;
  }

  /**
   * @return TFA of the user whos status is being requested.
   */

  public String getRequestedTFA(){
    return reqTFA;
  }

  /**
   * @return the host to contact.
   */

  public String getHost(){
    return host;
  }

  /**
   * @return password of the user
   */

  public String getPassword(){
    return password;
  }

  /**
   * @return status of the user
   */

  public String getStatus(){
    return status;
  }

  /**
   * @param sarg status of the user
   */

  public void setStatus(String sarg){
    status = sarg;
  }

  /**
   * @return the domain name of the teaser.
   */

  public String getDomainName(){
    return domain_name;
  }
}
