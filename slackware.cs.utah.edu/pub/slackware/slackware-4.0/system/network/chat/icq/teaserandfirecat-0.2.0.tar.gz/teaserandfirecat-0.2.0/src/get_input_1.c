/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <tfp.h>
#include <signal.h>

struct input get_user_input(int, struct input);
struct input get_account_input(int, struct input, boolean);

int fd;

/* handles the reading of input over the socket for
 * TFP 1.3
 */

struct input
get_input_1(int slave_socket){
  char *buf;
  char *field;
  struct input client_input;

  fd = slave_socket;

  do{
    buf = read_record(slave_socket);

    if(buf != NULL){

      field = get_field(buf, 1, NULL);
      if(field != NULL){

	if(0 == strcmp(field, "USER")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0';
	    hashloc++;
	    sprintf(client_input.tfa, "tfp://%s@%s", field, 
		    hashloc);
	    client_input = get_user_input(slave_socket, client_input);
	    free(field);
	    free(buf);
	    return client_input;
	  }
	}else if(0 == strcmp(field, "NEWACC")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0'; hashloc++;
	    sprintf(client_input.tfa, "tfp://%s@%s", field, 
		    hashloc);
	    client_input.connect_reason = 6;
	    client_input = get_account_input(slave_socket, client_input, TRUE);
	    free(field);
	    free(buf);
	    return client_input;
	  }
	}else if(0 == strcmp(field, "UPDACC")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0'; hashloc++;
	    sprintf(client_input.tfa, "tfp://%s@%s", field, 
		    hashloc);
	    client_input.connect_reason = 7;
	    client_input = get_account_input(slave_socket, client_input, 
					     FALSE);
	    free(field);
	    free(buf);
	    return client_input;
	  }
	}else if(0 == strcmp(field, "REQEMAIL")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.req_tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0'; hashloc++;
	    sprintf(client_input.req_tfa, "tfp://%s@%s", field, 
		    hashloc);
	    client_input.connect_reason = 8;
	    free(field);
	    free(buf);
	    return client_input;
	  }
	}else if(0 == strcmp(field, "REQURL")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.req_tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0'; hashloc++;
	    sprintf(client_input.req_tfa, "tfp://%s@%s", field, 
		    hashloc);
	    client_input.connect_reason = 9;
	    free(field);
	    free(buf);
	    return client_input;
	  }
	}else if(0 == strcmp(field, "REQIPA")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.req_tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0'; hashloc++;
	    sprintf(client_input.req_tfa, "tfp://%s@%s", field, 
		    hashloc);
	    client_input.connect_reason = 10;
	    free(field);
	    free(buf);
	    return client_input;
	  }
	}else if(0 == strcmp(field, "REQUNAME")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.req_tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0'; hashloc++;
	    sprintf(client_input.req_tfa, "tfp://%s@%s", field, 
		    hashloc);
	    client_input.connect_reason = 11;
	    free(field);
	    free(buf);
	    return client_input;
	  }
	}else if(0 == strcmp(field, "REQSTAT")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.req_tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0'; hashloc++;
	    sprintf(client_input.req_tfa, "tfp://%s@%s", field, 
		    hashloc);
	    client_input.connect_reason = 2;
	    free(field);
	    free(buf);
	    return client_input;
	  }
	}else if(0 == strcmp(field, "UPDSTAT")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.req_tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0'; hashloc++;
	    sprintf(client_input.req_tfa, "tfp://%s@%s", field, 
		    hashloc);
	    free(buf);
	    buf = read_record(slave_socket);
	    if(buf != NULL){
	      free(field);
	      field = get_field(buf, 1, NULL);
	      if(field != NULL){
		client_input.status = malloc((strlen(field)+1)*sizeof(char));
		strcpy(client_input.status, field);
	      }
	      client_input.connect_reason = 3;
	      free(field);
	      free(buf);
	      return client_input;
	    }
	  }
	}else if(0 == strcmp(field, "STPSTAT")){
	  free(field);
	  field = get_field(buf, 2, NULL);
	  if(field != NULL){
	    char *hashloc = index(field, '#');
	    client_input.req_tfa = malloc((strlen(field)+7)*sizeof(char));
	    hashloc[0] = '\0'; hashloc++;
	    sprintf(client_input.req_tfa, "tfp://%s@%s", field, 
		    hashloc);
	    client_input.connect_reason = 4;
	    free(field);
	    free(buf);
	    return client_input;
	  }
	}
      }
    }
  }while(buf == NULL);

  free(buf);
  free(field);
  /* if we make it this far then an error has occured */
  client_input.connect_reason = -1;
  return client_input;
}

/* Reads in input from the slave socket for any connection
 * starting with "USER <tfa>".  ie, a Firecat changing status,
 * requesting status of other user or requesting that the
 * teaser stop sending status updates for a particular user.
 */

struct input
get_user_input(int slave_socket, struct input client_input){
  char *buf;
  char *field;
  
  do{
    buf = read_record(slave_socket);

    if(buf != NULL){
      field = get_field(buf, 1, NULL);

      if(field != NULL){
	if(0 == strcmp(field, "PASSWORD")){
	  free(field);
	  field = get_field(buf, 2, NULL);

	  if(field != NULL){
	    client_input.password = malloc((strlen(field)+1)*sizeof(char));
	    strcpy(client_input.password, field);
	    do{
	      free(buf);
	      buf = read_record(slave_socket);

	      if(buf != NULL){
		free(field);
		field = get_field(buf, 1, NULL);

		if(field != NULL){
		  if(0 == strcmp(field, "PORT")){
		    free(field);
		    field = get_field(buf, 2, NULL);

		    if(field != NULL){
		      client_input.port =  malloc((strlen(field)+1) *
						  sizeof(char));
		      strcpy(client_input.port,
			     field);
	    
		      do{
			free(buf);
			buf = read_record(slave_socket);

			if(buf != NULL){
			  free(field);
			  field = get_field(buf, 1, NULL);

			  if(field != NULL){
			    if(0 == strcmp(field, "STATUS")){
			      free(field);
			      field = get_field(buf, 2, NULL);

			      if(field != NULL){
				client_input.status = malloc((strlen(field)+1)
							     * sizeof(char));
				strcpy(client_input.status,
				       field);
				client_input.connect_reason = 0;
				free(buf);
				free(field);
				return client_input;
			      }
			    }else if(0 == strcmp(field, "REQSTAT")){
			      free(field);
			      field = get_field(buf, 2, NULL);

			      if(field != NULL){
				char *hashloc = index(field, '#');
				client_input.req_tfa = malloc((strlen(field) +
							       7 ) *
							       sizeof(char));
				hashloc[0] = '\0'; hashloc++;
				sprintf(client_input.req_tfa, "tfp://%s@%s", 
					field, hashloc);
				client_input.connect_reason = 1;
				free(field);
				free(buf);
				return client_input;
			      }
			    }else if(0 == strcmp(field, "STPSTAT")){
			      free(field);
			      field = get_field(buf, 2, NULL);

			      if(field != NULL){
				char *hashloc = index(field, '#');
				client_input.req_tfa = malloc((strlen(field) +
							       7 ) *
							       sizeof(char));
				hashloc[0] = '\0'; hashloc++;
				sprintf(client_input.req_tfa, "tfp://%s@%s", 
					field, hashloc);
				client_input.connect_reason = 5;
				free(field);
				free(buf);
				return client_input;
			      }
			    }
			  }
			}
		      }while(buf == NULL);
		    }
		  }
		}
	      }
	    }while(buf == NULL);
	  }
	}
      }
    }
  }while(buf == NULL);

  free(field);
  free(buf);

  /* if we make it this far than an error has occured */
  client_input.connect_reason = -1;
  return client_input;
}

/* Reads in input from the slave socket for both new accounts
 * and updates to existing accounts.
 */

struct input
get_account_input(int slave_socket, struct input client_input, 
		  boolean isnewacc){
  char *buf;
  char *field;
  
  do{	
    buf = read_record(slave_socket);

    if(buf != NULL){
      field = get_field(buf, 1, NULL);

      if(field != NULL){
	if(0 == strcmp(field, "PASSWORD")){
	  free(field);
	  field = get_field(buf, 2, NULL);

	  if(field != NULL){
	    client_input.password = malloc((strlen(field) + 1)*sizeof(char));
	    strcpy(client_input.password, field);
	    
	  firstfield:
	    do{
	      buf = read_record(slave_socket);

	      if(buf != NULL){
		field = get_field(buf, 1, NULL);

		if(field != NULL){

		  if(!isnewacc){
		    if(0 == strcmp(field, "NPASSWORD")){
		      free(field);
		      field = get_field(buf, 2, NULL);
		  
		      if(field != NULL){
			client_input.new_password = malloc((strlen(field)+1) *
							   sizeof(char));
			strcpy(client_input.new_password, field);
		      }
		      goto firstfield;
		    }
		  }
		  
		  if(0 == strcmp(field, "USERNAME")){
		    free(field);
		    field = get_field(buf, 2, NULL);
		  
		    if(field != NULL){
		      client_input.uname = malloc((strlen(field) + 1) * 
						  sizeof(char));
		      strcpy(client_input.uname, field);
		    
		      do{
			buf = read_record(slave_socket);
		      
			if(buf != NULL){
			  field = get_field(buf, 1, NULL);
			
			  if(field != NULL){
			    if(0 == strcmp(field, "EMAIL")){
			      free(field);
			      field = get_field(buf, 2, NULL);
			      
			      if(field != NULL){
				client_input.email = 
				  malloc((strlen(field)+1)*sizeof(char));
				strcpy(client_input.email, field);
		    
				do{
				  buf = read_record(slave_socket);
		      
				  if(buf != NULL){
				    field = get_field(buf, 1, NULL);
				    
				    if(field != NULL){
				      if(0 == strcmp(field, "URL")){
					free(field);
					field = get_field(buf, 2, NULL);
					
					if(field != NULL){
					  client_input.url = 
					    malloc((strlen(field)+1) * 
						   sizeof(char));
					  strcpy(client_input.url, field);
					  free(field);
					  free(buf);
					  return client_input;
					}
				      }
				    }
				  }
				}while(buf == NULL);
			      }
			    }
			  }
			}
		      }while(buf == NULL);
		    }
		  }
		}
	      }
	    }while(buf == NULL);
	  }
	}
      }
    }
  }while(buf == NULL);
  
  free(field);
  free(buf);

  /* if we make it this far than an error has occured */
  client_input.connect_reason = -1;
  return client_input;
}
