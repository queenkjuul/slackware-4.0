/*
 * Teaser - A copyleft implimentation of RVP
 * Copyright (C) 1998, 1999 Matthew Parry <mettw@bowerbird.com.au
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Non-Consultants' License as published by
 * Bowerbird Computing; either version 1.2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Non-Consultats' License for more details.
 *
 * You should have received a copy of the Non-Consultants' License
 * along with this program; if not, write to Bowerbird Computing,
 * PO Box 247, Nowra NSW, Australia, 2541.
 */



#include <teaser.h>

struct input
default_url_resolver(struct input client_input){

  /** parse out `rvp' and return RVP_BAD_REQUEST
   ** if not found.
   **
   ** parse out host name and chack that it matches that
   ** for this machine.  If it matches one of our aliases
   ** then give a RVP_REFER
   ** If it doesn't match any then give RVP_BAD_REQUEST (??)
   **
   ** then parse path and append to document-root to give
   ** us client_input.resolved_url.
   **/ 

  return client_input;
}

struct input
default_method_processor(struct input client_input){
  client_input.rvp_return = RVP_NOT_IMPLIMENTED;

  return client_input;
}
