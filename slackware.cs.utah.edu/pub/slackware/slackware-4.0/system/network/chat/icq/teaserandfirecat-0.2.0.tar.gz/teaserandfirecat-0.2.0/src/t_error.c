/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <teaser.h>
#include <time.h>

void
t_error(char *error_msg, boolean exit_prog){
  time_t t;
  char *stime;

  t = time(NULL);
  stime = ctime(&t);
  stime[strlen(stime)-1] = '\0';

  if(logfd == -1)
    fprintf(stderr, "%s * Teaser: %s\n", stime, error_msg);
  else{
    char *buf;

    buf = malloc((strlen(stime) + strlen(" * Teaser: ") +
		  strlen(error_msg)+1)*sizeof(char));
    strcpy(buf, stime);
    strcat(buf, " * Teaser: ");
    strcat(buf, error_msg);
    strcat(buf, "\n");

    write(logfd, buf, strlen(buf));

    free(buf);
  }


  if(exit_prog){
    close(logfd);
    unlink("/var/run/teaser.pid");
    exit(1);
  }
}
