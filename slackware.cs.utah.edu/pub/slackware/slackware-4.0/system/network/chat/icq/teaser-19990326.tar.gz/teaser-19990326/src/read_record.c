/*
 * Teaser - A copyleft implimentation of RVP
 * Copyright (C) 1998, 1999 Matthew Parry <mettw@bowerbird.com.au
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Non-Consultants' License as published by
 * Bowerbird Computing; either version 1.2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Non-Consultants' License for more details.
 *
 * You should have received a copy of the Non-Consultants' License
 * along with this program; if not, write to Bowerbird Computing,
 * PO Box 247, Nowra NSW, Australia, 2541.
 */

#include <teaser.h>

/* reads in from the file descriptor fd untill a newline
 */

char*
read_record(int fd){
  char cbuf;
  char *buf;
  ssize_t status;
  ssize_t size = 1;

  buf = malloc(size*sizeof(char));
  do{
    status = read(fd, &cbuf, 1);
    if(status == -1){
      free(buf);
      return NULL;
    }else if(status != 0){
      size++;
      buf = realloc(buf, size*sizeof(char));
      buf[size - 2] = cbuf;
      buf[size - 1] = '\0';
    }
  } while(buf[size - 2] != '\n' && buf[size - 3] != '\r' && status != 0);

  return buf;
}

/* Gets a field from the record passed to it.  fs is a string of
 * characters to use as field separators, if NULL then any non-printing
 * character is used.
 */

char*
get_field(char* record, int field, char* fs){
  char *ret;
  int i = 0;
  int f_num = 1;
  int length;

  if(record == NULL)
    return NULL;

  length = strlen(record);

  ret = malloc(sizeof(char));

  if(length == 0){
    free(ret);
    return NULL;
  }

  if(fs == NULL){ /* user any non-printing character for the FS */

    /* skip forward untill we find the start of the requested field */
    while(f_num < field && i < length){
      /* skip past any leading whitespace */
      while(record[i] < '\041' || record[i] > '\176' && i < length){
	i++;
      }

      /* skip past the unwanted field */
      while(record[i] > '\040' && record[i] < '\177' && i < length){
	i++;
      }
      f_num++;
    }

    /* skip past any leading whitespace */
    while(record[i] < '\041' || record[i] > '\176' && i < length){
      i++;
    }
      
    if(i < length){
      f_num = i;
      /* read in the field untill we find a non-printing character */
      while(record[i] > '\040' && record[i] < '\177' && i < length){
	ret = realloc(ret, (i - f_num + 1)*sizeof(char));
	ret[i - f_num] = record[i];
	i++;
      }
      
      ret = realloc(ret, (i - f_num + 1)*sizeof(char));
      ret[i - f_num] = '\0';

      return ret;
    }
  } else if (strlen(fs) == 1) {

    /* skip forward untill we find the start of the requested field */
    while(f_num < field && i < length){
      /* skip past any leading FSs */
      while(record[i] == fs[0] && i < length){
	i++;
      }

      /* skip past the unwanted field */
      while(record[i] != fs[0] && i < length){
	i++;
      }
      f_num++;
    }

    /* skip past any leading whitespace */
    while(record[i] == fs[0] && i < length){
      i++;
    }
      
    if(i < length){
      f_num = i;
      /* read in the field untill we find a non-printing character */
      while(record[i] != fs[0] && i < length){
	ret = realloc(ret, (i - f_num + 1)*sizeof(char));
	ret[i - f_num] = record[i];
	i++;
      }
      
      ret = realloc(ret, (i - f_num + 1)*sizeof(char));
      ret[i - f_num] = '\0';

      return ret;
    }
  }
  /* need to write the rest some time...
   * fs is a string of characters to use as Field Separators.
   */

  free(ret);
  return NULL;
}

void
t_tolower(char *str){
  int i;
  int len = strlen(str);

  for (i = 0; i < len; i++)
    str[i] = tolower(str[i]);

}
