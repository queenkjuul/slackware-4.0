/*    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package au.com.bowerbird.teaser;

import java.lang.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import au.com.bowerbird.TFP.*;

/**
 * handles the individual socket connection.
 *
 * Calls TFP objects to communicate with the teaser/firecat and
 * then updates the database.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class TeaserSocket extends Thread {
  Socket s;
  OutputStream ostream;
  InputStream istream;
  TFPHandler tfph;

  /**
   * All we need to know is what socket to use.
   *
   * @param argsocket The Socket we should listen on.
   */

  public TeaserSocket(Socket argsocket){
    s = argsocket;

    try{ostream = s.getOutputStream();}
    catch(IOException ioe){
      System.out.println(ioe.getMessage());
      return;
    }

    try{istream = s.getInputStream();}
    catch(IOException ioe){
      System.out.println(ioe.getMessage());
      return;
    }

    tfph = new TFPHandler(istream, ostream);

  }

  /**
   * Open a TFP connection, determine what we are talking to and
   * then call either HandleTeaser or HandleFirecat.
   */

  public void run (){
    String requestor_type;

    try{tfph.getHeader();}
    catch(TFPNotTFPException tfpe){
      try{s.close();}
      catch(IOException ioe){
	System.out.println(ioe.getMessage());
      }
      return;
    }
    catch(TFPBadInputException tfpbi){
      tfph.TFPerror();
      try{s.close();}
      catch(IOException ioe){
	System.out.println(ioe.getMessage());
      }
      return;
    }
    
    requestor_type = tfph.getRequestorType();

    if(requestor_type.equalsIgnoreCase("Teaser")){
      this.HandleTeaser();
    } else if (requestor_type.equalsIgnoreCase("Firecat")){
      this.HandleFirecat();
    } else { // it's a firecat meowing
      this.HandleMeow();
    }

    try{s.close();}
    catch(IOException ioe){
      System.out.println(ioe.getMessage());
      return;
    }
    return;
  }

  /**
   * Gets the relevant info, updates the database and sends
   * appropriate reply.
   */

  private void HandleTeaser() {
    String connect_reason = new String(tfph.getReasonForConnection());
    TeaserDB tdb = new TeaserDB("jdbc:postgresql:teaserdb", "teaser", "");
    
    System.out.println("***TEASER***");
    System.out.println(connect_reason);
    
    if (connect_reason.equalsIgnoreCase("REQSTAT")){
      tfph.sendStatus(tdb.getStatus(tfph));
      System.out.println("domain name = " + tfph.getDomainName());
      System.out.println("requested TFA = " + tfph.getRequestedStatusTFA());
    }else if (connect_reason.equalsIgnoreCase("UPDSTAT")){
      if(tdb.updateStatus(tfph))
	tfph.TFPok();
      else
	tfph.TFPerror();
      System.out.println("domain name = " + tfph.getDomainName());
      System.out.println("requested TFA = " + tfph.getRequestedStatusTFA());
      System.out.println("status = " + tfph.getStatus());
    }else if (connect_reason.equalsIgnoreCase("STPSTAT")){
      if(tdb.stopStatus(tfph))
	tfph.TFPok();
      else
	tfph.TFPerror();
      System.out.println("domain name = " + tfph.getDomainName());
      System.out.println("requested TFA = " + tfph.getRequestedStatusTFA());
    }else{
      System.out.println("this should never happen");
    }

    System.out.println("******");
  }

  /**
   * Gets the relevant info, updates the database and sends
   * appropriate reply.
   */

  private void HandleFirecat() {
    String connect_reason = new String(tfph.getReasonForConnection());
    TeaserDB tdb = new TeaserDB("jdbc:postgresql:teaserdb", "teaser", "");
    
    System.out.println("***FIRECAT***");
    System.out.println(connect_reason);
    
    if(connect_reason.equalsIgnoreCase("UPDSTAT")){
      if(tdb.updateStatus(tfph))
	tfph.TFPok();
      else
	tfph.TFPerror();
      System.out.println("user = " + tfph.getTFA());
      System.out.println("password = " + tfph.getPassword());
      System.out.println("status = " + tfph.getStatus());
    }else if(connect_reason.equalsIgnoreCase("REQSTAT")){
      tfph.sendStatus(tdb.getStatus(tfph));
      System.out.println("user = " + tfph.getTFA());
      System.out.println("requested user = " + tfph.getRequestedStatusTFA());
    }else if(connect_reason.equalsIgnoreCase("NEWACC")){
      if(tdb.newAccount(tfph))
	tfph.TFPok();
      else
	tfph.TFPerror();
      System.out.println("user = " + tfph.getTFA());
      System.out.println("password = " + tfph.getPassword());
      System.out.println("email address = " + tfph.getEmailAddress());
      System.out.println("url = " + tfph.getURL());
    }else if(connect_reason.equalsIgnoreCase("UPDACC")){
      if(tdb.updateAccount(tfph))
	tfph.TFPok();
      else
	tfph.TFPerror();
      System.out.println("user = " + tfph.getTFA());
      System.out.println("password = " + tfph.getPassword());
      System.out.println("email address = " + tfph.getEmailAddress());
      System.out.println("url = " + tfph.getURL());
    }else {
      System.out.println("this should never happen");
    }

    System.out.println("******");
  }

  /**
   * Gets the TFA of the firecat meowing and updates the database.
   *
   */

  private void HandleMeow(){
    TeaserDB tdb = new TeaserDB("jdbc:postgresql:teaserdb", "teaser", "");

    tdb.updateMeow(tfph);
    System.out.println("***MEOW***");
    System.out.println(tfph.getReasonForConnection());
    System.out.println(tfph.getTFA());
    System.out.println("******");
  }
}
