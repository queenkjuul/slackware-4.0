/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <teaser.h>

PGconn *pg_conn;

void
teaser_stpstat(struct client_info slave_socket, struct input client_input){
  PGresult *result;
  char *pgexec;
  char *value;
  char *str_location;

  /* Open a connection to the database */
  pg_conn = PQsetdb("localhost", NULL, NULL, NULL, "teaserdb");
  /* check it opened OK */
  if(PQstatus(pg_conn) == CONNECTION_BAD){
	t_error(PQerrorMessage(pg_conn), TRUE);
  }


  /* delete the client from the requested user's list of contacts */

  /* get the requested user's list of contacts */
  pgexec = malloc((strlen("SELECT contacts FROM Status WHERE tfa = '") +
		   strlen(client_input.req_tfa) +
		   strlen("';")+1) * sizeof(char));
  strcpy(pgexec, "SELECT contacts FROM Status WHERE tfa = '");
  strcat(pgexec, client_input.req_tfa);
  strcat(pgexec, "';");

  t_error(pgexec, FALSE);
  result = db_exec(pg_conn, pgexec);
  if(PQresultStatus(result) == PGRES_TUPLES_OK && PQntuples(result) == 1){
    value = PQgetvalue(result, 0, 0);
  }else{
    tfp_error(slave_socket.socket, 201);
    t_error(PQerrorMessage(pg_conn), FALSE);
    free(pgexec);
    PQfinish(pg_conn);
    return;
  }


  /* if the user is in the list of contacts */
  str_location = strstr(value, inet_ntoa(slave_socket.client_name.sin_addr));

  if(str_location != NULL){
    
    free(pgexec);
    
    pgexec = malloc((strlen("UPDATE Status SET contacts = '") +
		     strlen(value) - 1 /* - `}' */
		     - strlen(inet_ntoa(slave_socket.client_name.sin_addr))
		     - 3 /* - `,' - `"' - `"' */
		     + strlen("' WHERE tfa = '") +
		     strlen(client_input.req_tfa) + strlen("';")+1) * 
		    sizeof(char));
    strcpy(pgexec, "UPDATE Status SET contacts = '");
    *(str_location - 2) = '\0';
    strcat(pgexec, value);
    strcat(pgexec,(char *)(str_location + 
			   strlen(inet_ntoa(slave_socket.client_name.sin_addr))
			   + 1 ));
    strcat(pgexec, "' WHERE tfa = '");
    strcat(pgexec, client_input.req_tfa);
    strcat(pgexec, "';");

    t_error(pgexec, FALSE);
    db_exec(pg_conn, pgexec);

  } else{
    tfp_error(slave_socket.socket, 402);
    t_error(PQerrorMessage(pg_conn), FALSE);
    
    free(pgexec);
    PQfinish(pg_conn);
    free(value);
    return;
  }

  write(slave_socket.socket, "OK\n", strlen("OK\n"));

  
  free(pgexec);
  free(value);
  PQfinish(pg_conn);
}
