/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <teaser.h>
#include <sys/file.h>

/* eliminates race conditions in the database
 */

PGresult*
db_exec(PGconn *conn, char *query){
  PGresult *result;

  switch(flock(teaserdb_lock, LOCK_EX)){
  case -1:
    t_error("couldn't lock /var/lock/teaserdb.lock", FALSE);
    exit(1);
  default:
    result = PQexec(conn, query);
    switch(flock(teaserdb_lock, LOCK_UN)){
    case -1:
      t_error("Couldn't unlock /var/lock/teaserdb.lock", FALSE);
      exit(1);
    default:
      return result;
    }
  }
}

