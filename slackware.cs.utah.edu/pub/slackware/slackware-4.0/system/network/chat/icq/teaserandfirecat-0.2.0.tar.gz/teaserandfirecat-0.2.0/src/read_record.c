/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <tfp.h>

/* reads in from the file descriptor fd untill a newline
 */

char*
read_record(int fd){
  char cbuf;
  char *buf;
  ssize_t status;
  ssize_t size = 1;

  buf = malloc(size*sizeof(char));

  do{
    status = read(fd, &cbuf, 1);
    if(status == -1){
      free(buf);
      return NULL;
    }else if(status != 0){
      size++;
      buf = realloc(buf, size*sizeof(char));
      buf[size - 2] = cbuf;
      buf[size - 1] = '\0';
    }
  } while(cbuf != '\n' && status != 0);

  return buf;
}
