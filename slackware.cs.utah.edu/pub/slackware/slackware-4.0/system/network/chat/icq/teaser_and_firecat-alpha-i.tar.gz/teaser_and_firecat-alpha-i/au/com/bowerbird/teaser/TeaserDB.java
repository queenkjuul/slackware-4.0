/*    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package au.com.bowerbird.teaser;

import java.sql.*;
import au.com.bowerbird.TFP.*;

/**
 * Does all of the database interface stuff.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class TeaserDB{
  Connection dbcon;

  /**
   * Constructor method.
   *
   * @param url the URL of the database
   * @param user user name to use when connecting to database
   * @param password password for connecting to database
   */

  public TeaserDB(String url, String user, String password){
    try {Class.forName("postgresql.Driver");} 
    catch(Exception je) {
      System.out.println("teaser: error opening database: " + je.getMessage());
      System.exit(1);
    }
    try{
      dbcon = DriverManager.getConnection(url, user, password);
    }
    catch(SQLException sqle){
      System.out.println("teaser: got SQLException: " + sqle.getMessage());
    }
  }

  /**
   * Get a user's status from the DB.
   *
   * Not done yet.
   *
   * @param tfph TFPHandler object that got the input
   * @return ONLINE|OFFLINE|...
   */

  public String getStatus(TFPHandler tfph){
    ResultSet rs;
    String ret = new String();

    try{
      Statement stm = dbcon.createStatement();
      
      rs = stm.executeQuery("SELECT status FROM USER_STATUS WHERE tfa = '" +
		       tfph.getRequestedStatusTFA() + "';");
      closeDB();
      rs.next();
      ret = rs.getString(1);
      /*    int numcols = rs.getMetaData().getColumnCount();
      while (rs.next()){
	for (int i=1; i<=numcols;i++)
	  System.out.println(rs.getString(i) + " | ");
	  }*/

      System.out.println(ret);
    }
    catch(SQLException sqle){
      System.out.println("teaser: got Exception accessing DB: " + 
			 sqle.getMessage());
      return "SORRY";
    }
    return ret;
    
  }

  /**
   * Updates the status of the user in the database
   *
   * @param tfph TFPHandler object that got the input.
   *
   * @return true if DB update was OK, else false.
   */

  public boolean updateStatus(TFPHandler tfph){
    try{
      Statement stm = dbcon.createStatement();

      stm.executeUpdate("UPDATE USER_STATUS SET status = '" +
			tfph.getStatus() + "' WHERE tfa = '" +
			tfph.getTFA() + "';");
      closeDB();
    }
    catch(SQLException sqle){
      System.out.println("teaser: got Exception accessing DB: " + 
			 sqle.getMessage());
      return false;
    }
    return true;
  }

  /**
   * Deletes a teaser from the list of teasers to update.
   *
   * @param tfph TFPHandler object that got the input.
   * @return true if the DB update was OK, else false.
   */

  public boolean stopStatus(TFPHandler tfph){
    closeDB();
    return true;
  }

  /**
   * Place a new account in the database.
   *
   * This doesn't handle the MEOWing stuff yet.
   *
   * @param tfph the TFPHandler object that got the input.
   * @return true if updated OK, else false
   */

  public boolean newAccount(TFPHandler tfph){

    try{
      Statement stm = dbcon.createStatement();

      stm.executeUpdate("INSERT INTO USER_STATUS VALUES ('" + tfph.getTFA() +
			"','" + tfph.getStatus() + "','" + 
			tfph.getEmailAddress() +
			"','" + tfph.getURL() + "','" + tfph.getPassword() +
			"','0','" + tfph.getDomainName() + "','{}');");
      closeDB();
    }
    catch(SQLException sqle){
      System.out.println("teaser: got Exception accessing DB: " + 
			 sqle.getMessage());
      return false;
    }
    return true;
  }

  /**
   * Updates the user's account info (email and URL) in the database.
   *
   * @param tfph the TFPHandler object that got the input.
   * @return true if updated OK, else false
   */

  public boolean updateAccount(TFPHandler tfph){

    try{
      Statement stm = dbcon.createStatement();

      stm.executeUpdate("UPDATE USER_STATUS SET email = '" +
			tfph.getEmailAddress() + "', url = '" +
			tfph.getURL() + "';");
      closeDB();
    }
    catch(SQLException sqle){
      System.out.println("teaser: got Exception accessing DB: " + 
			 sqle.getMessage());
      return false;
    }
    return true;
  }

  /**
   * I'm not sure yet how this will work.
   *
   * @param tfph TFPHandler object that got the input.
   */

  public void updateMeow(TFPHandler tfph){
    closeDB();
  }

  /**
   * close our connection to the database.
   */

  void closeDB(){
    try{dbcon.close();}
    catch(SQLException sqle){
      System.out.println("teaser: got SQLException: " + sqle.getMessage());
    }
  }
}
