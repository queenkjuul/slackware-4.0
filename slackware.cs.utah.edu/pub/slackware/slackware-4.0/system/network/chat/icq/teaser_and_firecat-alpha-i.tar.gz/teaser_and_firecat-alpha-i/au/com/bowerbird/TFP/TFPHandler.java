/*    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package au.com.bowerbird.TFP;

import java.lang.*;
import java.io.*;

/**
 * Does all of the Teaser and Firecat Protocol stuff.
 *
 * Used by both Teaser and Firecat, it can handle all types
 * of connection.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class TFPHandler {
  InputStream istream;
  OutputStream ostream;
  TFPRecord tfpr;
  String requestor_type = new String();
  String TFA = new String();
  String password = new String();
  String url = new String();
  String email = new String();
  String status = new String();
  String reqstat_TFA = new String();
  String connect_reason = new String();
  String domain_name = new String();

  /**
   * Don't get the whole socket, just the IO streams.
   *
   * This seemed like a good idea at the time but now
   * I really don't think it makes much difference.
   *
   * @param iarg Socket input stream.
   * @param oarg Socket output stream.
   */

  public TFPHandler(InputStream iarg, OutputStream oarg){
    istream = iarg;
    ostream = oarg;
    tfpr = new TFPRecord(istream, ostream);
  }

  /**
   * Negotiates a TFP version and then calls other methods to read
   * in all of the information.  The receiving teaser or
   * firecat then gets the data recieved through the
   * other methods.
   *
   * @exception TFPNotTFPException Fatal - Not talking to a Teaser or Firecat.
   * @exception TFPBadInputException Fatal - Teaser or Firecat didn't follow the TFP version they said they would.
   */

  public void getHeader() throws TFPNotTFPException, TFPBadInputException {
    String istring = new String();

    // Find out what we are talking to.
    istring = tfpr.GetRecord();

    try{requestor_type = tfpr.GetField(istring.trim(), 1);}
    catch(TFPEndOfRecordException e){
      throw new TFPNotTFPException();
    }
    
    // Now call a method that knows how to get all of the other data.
    if(requestor_type.equalsIgnoreCase("teaser")){
      this.GetTeaserInput();
    }else if(requestor_type.equalsIgnoreCase("firecat")){
      this.GetFirecatInput();
    }else if(requestor_type.equalsIgnoreCase("meow")){
      try{TFA = tfpr.GetField(istring.trim(), 2);}
      catch(TFPEndOfRecordException e){
	throw new TFPNotTFPException();
      }
      connect_reason = "MEOW";
    } else{
      throw new TFPNotTFPException();
    }
      
    return;
  }

  /**
   * Reply to the teaser/firecat with the status requested.
   *
   * @param sarg the status to send: ONLINE|OFFLINE|...
   */

  public void sendStatus(String sarg){
    tfpr.PutRecord(sarg);
  }

  /**
   * Send an error message to the connecting teaser/firecat.
   *
   * At the moment it only says "SORRY" for all errors.
   */

  public void TFPerror(){
    tfpr.PutRecord("SORRY");
  }

  /**
   * Send an error message to the connecting teaser/firecat.
   *
   * At the moment it only says "SORRY" for all errors.
   */

  public void TFPok(){
    tfpr.PutRecord("OK");
  }

  /**
   * Handles all of the input from a firecat.
   *
   * This is the part that needs to know about the TFP.  It
   * sets the variables TFA, password, url, email, status,
   * reqstat_TFA and connect_reason.
   *
   * @exception TFPBadInputException thrown when the input doesn't comply with the TFP.
   */

  private void GetFirecatInput() throws TFPBadInputException {
    String istring = new String();
    String field_tmp = new String();

    istring = tfpr.GetRecord();

    try{field_tmp = tfpr.GetField(istring.trim(), 1);}
    catch(TFPEndOfRecordException e){
      throw new TFPBadInputException();
    }

    if(field_tmp.equalsIgnoreCase("USER")){
      try{TFA = tfpr.GetField(istring.trim(), 2);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }

      istring = tfpr.GetRecord();
      try{field_tmp = tfpr.GetField(istring.trim(), 1);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
      if(field_tmp.equalsIgnoreCase("PASSWORD")){
	connect_reason = "UPDSTAT";
	try{password = tfpr.GetField(istring.trim(), 2);}
	catch(TFPEndOfRecordException e){
	  throw new TFPBadInputException();
	}

	istring = tfpr.GetRecord();
	try{field_tmp = tfpr.GetField(istring.trim(), 1);}
	catch(TFPEndOfRecordException e){
	  throw new TFPBadInputException();
	}
	if(field_tmp.equalsIgnoreCase("STATUS")){
	  try{ status = tfpr.GetField(istring.trim(), 2);}
	  catch(TFPEndOfRecordException e){
	    throw new TFPBadInputException();
	  }
	}else{
	  throw new TFPBadInputException();
	}
      }else if(field_tmp.equalsIgnoreCase("REQSTAT")){
	connect_reason = "REQSTAT";
	try{reqstat_TFA = tfpr.GetField(istring.trim(), 2);}
	catch(TFPEndOfRecordException e){
	  throw new TFPBadInputException();
	}
      }else{
	throw new TFPBadInputException();
      }

    }else if(field_tmp.equalsIgnoreCase("NEWACC")){
      connect_reason = "NEWACC";
      try{TFA = tfpr.GetField(istring.trim(), 2);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }

      istring = tfpr.GetRecord();
      try{field_tmp = tfpr.GetField(istring.trim(), 1);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
      if(field_tmp.equalsIgnoreCase("PASSWORD")){
	try{password = tfpr.GetField(istring.trim(), 2);}
	catch(TFPEndOfRecordException e){
	  throw new TFPBadInputException();
	}
      }else{
	throw new TFPBadInputException();
      }

      istring = tfpr.GetRecord();
      try{field_tmp = tfpr.GetField(istring.trim(), 1);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
      if(field_tmp.equalsIgnoreCase("EMAIL")){
	try{email = tfpr.GetField(istring.trim(), 2);}
	catch(TFPEndOfRecordException e){
	  throw new TFPBadInputException();
	}
      }else{
	throw new TFPBadInputException();
      }

      istring = tfpr.GetRecord();
      try{field_tmp = tfpr.GetField(istring.trim(), 1);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
      if(field_tmp.equalsIgnoreCase("URL")){
	try{url = tfpr.GetField(istring.trim(), 2);}
	catch(TFPEndOfRecordException e){
	  throw new TFPBadInputException();
	}
      }else{
	throw new TFPBadInputException();
      }
    }else if(field_tmp.equalsIgnoreCase("UPDACC")){
      connect_reason = "UPDACC";
      try{TFA = tfpr.GetField(istring.trim(), 2);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }

      istring = tfpr.GetRecord();
      try{field_tmp = tfpr.GetField(istring.trim(), 1);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
      if(field_tmp.equalsIgnoreCase("PASSWORD")){
	try{password = tfpr.GetField(istring.trim(), 2);}
	catch(TFPEndOfRecordException e){
	  throw new TFPBadInputException();
	}
      }else{
	throw new TFPBadInputException();
      }

      istring = tfpr.GetRecord();
      try{field_tmp = tfpr.GetField(istring.trim(), 1);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
      if(field_tmp.equalsIgnoreCase("EMAIL")){
	try{email = tfpr.GetField(istring.trim(), 2);}
	catch(TFPEndOfRecordException e){
	  throw new TFPBadInputException();
	}
      }else{
	throw new TFPBadInputException();
      }

      istring = tfpr.GetRecord();
      try{field_tmp = tfpr.GetField(istring.trim(), 1);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
      if(field_tmp.equalsIgnoreCase("URL")){
	try{url = tfpr.GetField(istring.trim(), 2);}
	catch(TFPEndOfRecordException e){
	  throw new TFPBadInputException();
	}
      }else{
	throw new TFPBadInputException();
      }
    }else{
      throw new TFPBadInputException();
    }
  }

  /**
   * Handles all of the input from a teaser.
   *
   * This is the part that needs to know about the TFP.  It
   * sets the variables TFA, status, reqstat_TFA, domain_name,
   * and connect_reason.
   *
   * @exception TFPBadInputException thrown when the input doesn't comply with the TFP.
   */

  private void GetTeaserInput() throws TFPBadInputException {
    String istring = new String();
    String field_tmp = new String();

    istring = tfpr.GetRecord();

    try{field_tmp = tfpr.GetField(istring.trim(), 1);}
    catch(TFPEndOfRecordException e){
      throw new TFPBadInputException();
    }

    if(field_tmp.equalsIgnoreCase("DN")){
      try{domain_name = tfpr.GetField(istring.trim(), 2);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
    }else{
      throw new TFPBadInputException();
    }

    istring = tfpr.GetRecord();

    try{field_tmp = tfpr.GetField(istring.trim(), 1);}
    catch(TFPEndOfRecordException e){
      throw new TFPBadInputException();
    }

    if(field_tmp.equalsIgnoreCase("REQSTAT")){
      connect_reason = "REQSTAT";
      try{reqstat_TFA = tfpr.GetField(istring.trim(), 2);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
    }else if(field_tmp.equalsIgnoreCase("STPSTAT")){
      connect_reason = "STPSTAT";
      try{reqstat_TFA = tfpr.GetField(istring.trim(), 2);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
    }else if(field_tmp.equalsIgnoreCase("UPDSTAT")){
      connect_reason = "UPDSTAT";
      try{reqstat_TFA = tfpr.GetField(istring.trim(), 2);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
      istring = tfpr.GetRecord();
      try{status = tfpr.GetField(istring.trim(), 1);}
      catch(TFPEndOfRecordException e){
	throw new TFPBadInputException();
      }
    }
  }

  /**
   * Tells calling method what we are talking to.
   *
   * The behavior of the teaser will depend on whether it is
   * talking to a teaser or firecat.  The firecat will probably
   * need to know this too when I add chat capabilities to it.
   *
   * @return String "TEASER" or "FIRECAT" depending on what we are talking to.
   */

  public String getRequestorType(){
    return requestor_type;
  }

  /**
   * @return The TFA of who is talking to us.
   */

  public String getTFA(){
    return TFA;
  }

  /**
   * @return The password of who is talking to us.
   */

  public String getPassword(){
    return password;
  }

  /**
   * @return The url requested.
   */

  public String getURL(){
    return url;
  }

  /**
   * @return The email requested.
   */

  public String getEmailAddress(){
    return email;
  }

  /**
   * @return The status of who is talking to us.
   */

  public String getStatus(){
    return status;
  }

  /**
   * @return The TFA that a status request was made for..
   */

  public String getRequestedStatusTFA(){
    return reqstat_TFA;
  }

  /**
   * @return The reason for the connection.
   */

  public String getReasonForConnection(){
    return connect_reason;
  }

  /**
   * @return The Domain Name of the teaser we're talking to.
   */

  public String getDomainName(){
    return domain_name;
  }
}
