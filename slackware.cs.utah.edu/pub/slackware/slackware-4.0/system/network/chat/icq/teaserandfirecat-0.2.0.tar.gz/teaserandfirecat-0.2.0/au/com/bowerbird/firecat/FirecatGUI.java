/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


package au.com.bowerbird.firecat;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;


/**
 * The GUI interface for Firecat.
 *
 * The default constructor is used.  Call show() to get the
 * GUI.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class FirecatGUI {
    Choice status_widget = new Choice(); //choose what your status is
    Frame main_window = new Frame("Firecat");
    MenuBar menubar_widget = new MenuBar();
    Menu menu_widget = new Menu("File", /*tearoff*/ false);
    Menu help_menu = new Menu("Help", false);
    FileActionListener fal = new FileActionListener();
    Panel contacts_panel = new Panel();
    CardLayout contacts_cl = new CardLayout();// holds all contact panels.
    Panel contacts_pl = new Panel();
    Panel button_panel = new Panel();
    Button online_button = new Button("Online");
    Button offline_button = new Button("Offline");
    Button busy_button = new Button("Busy");
    Button backinfive_button = new Button("Back in Five");
    Panel online_contacts = new Panel();// online contacts,
    Panel offline_contacts = new Panel();//and so on...
    Panel busy_contacts = new Panel();
    Panel backinfive_contacts = new Panel();
    Label online_label = new Label("Online");   //says that the contacts
    Label offline_label = new Label("Offline"); //listed below are
    Label busy_label = new Label("Busy");       // online/offline/...
    Label backinfive_label = new Label("Back in five");
    StatusItemListener sil = new StatusItemListener();
    CardLayoutActionListener clal = new CardLayoutActionListener();

    /**
     * Creates the GUI.
     */

    public void show() {
	Enumeration hasht;

	/* The "File" menu at the top of the Frame 
	 */
	menu_widget.add(new MenuItem("Identity")); // change email, url, etc
	menu_widget.add(new MenuItem("Execs"));
	menu_widget.add(new MenuItem("Add Contact"));
	menu_widget.add(new MenuItem("Delete Contact"));
	menu_widget.add(new MenuItem("Exit"));
	menu_widget.addActionListener(fal);
	menubar_widget.add(menu_widget);

	help_menu.add(new MenuItem("About"));
	help_menu.addActionListener(new ActionListener(){
	    public void actionPerformed(ActionEvent e){
		Main.fgui.help();
	    }
	});
	menubar_widget.add(help_menu);

	main_window.setMenuBar(menubar_widget);
	main_window.setLayout(new BorderLayout());

	main_window.add("Center", contacts_panel);
	contacts_panel.setLayout(new GridLayout(2,1));
	contacts_panel.add(button_panel);
	contacts_panel.add(contacts_pl);
	button_panel.setLayout(new GridLayout(1,4));
	button_panel.add(online_button);
	button_panel.add(offline_button);
	button_panel.add(busy_button);
	button_panel.add(backinfive_button);
	contacts_pl.setLayout(contacts_cl);
	contacts_pl.add("Online", online_contacts);
	contacts_pl.add("Offline", offline_contacts);
	contacts_pl.add("Busy", busy_contacts);
	contacts_pl.add("Back in Five", backinfive_contacts);
	main_window.add("South", status_widget);

	/* add an item listener to each online_button/etc to show
	 * the appropriate panel when pressed.
	 */
	online_button.addActionListener(clal);
	offline_button.addActionListener(clal);
	busy_button.addActionListener(clal);
	backinfive_button.addActionListener(clal);

	online_contacts.setLayout(new GridLayout(1,1));
	online_contacts.add(online_label);
	offline_contacts.setLayout(new GridLayout(1,1));
	offline_contacts.add(offline_label);
	busy_contacts.setLayout(new GridLayout(1,1));
	busy_contacts.add(busy_label);
	backinfive_contacts.setLayout(new GridLayout(1,1));
	backinfive_contacts.add(backinfive_label);
	
	// Add a button for each contact
	hasht = Main.contact_status.elements();
	while(hasht.hasMoreElements()){
	    addContact((UserStatus) hasht.nextElement());
	}

	status_widget.addItem("Online");
	status_widget.addItem("Offline");
	status_widget.addItem("Busy");
	status_widget.addItem("Back in five");
	// If there is no firecat.rc file then we start off as OFFLINE
	if(((String) Main.user_status.getStatus()).equalsIgnoreCase("OFFLINE")){
	    status_widget.select("Offline");
	    getIdentity(true);
	    getExecs();
	}
	status_widget.addItemListener(sil);
 
	main_window.pack();
	main_window.show();
    }

  /**
   * add a contact to the GUI.
   *
   * This does not call pack() as this shouldn't be done when our
   * contacts are added on startup.
   *
   * @param us UserStatus of contact to add
   */

  public  void addContact(UserStatus us){

    if((us.getStatus()).equalsIgnoreCase("ONLINE")){
      online_contacts.setLayout(new GridLayout(online_contacts.getComponentCount() + 1, 1));
      online_contacts.add(us.getButton());
    }else if((us.getStatus()).equalsIgnoreCase("OFFLINE")){
      offline_contacts.setLayout(new GridLayout(offline_contacts.getComponentCount() + 1, 1));
      offline_contacts.add(us.getButton());
    }else if((us.getStatus()).equalsIgnoreCase("BUSY")){
      busy_contacts.setLayout(new GridLayout(busy_contacts.getComponentCount() + 1, 1));
      busy_contacts.add(us.getButton());
    }else if((us.getStatus()).equalsIgnoreCase("BACKINFIVE")){
      backinfive_contacts.setLayout(new GridLayout(backinfive_contacts.getComponentCount() + 1, 1));
      backinfive_contacts.add(us.getButton());
    }
  }

  /**
   * Add a new contact to our list of contacts.
   * 
   * After getting the contact's TFA from the user, addContact(UserStatus)
   * is called and the main window is re-pack()ed
   */

  public void addContact(){
    final Frame foo = new Frame();
    Label tfa_label = new Label("TFA: ");
    final TextField tfa_tf = new TextField(20);
    Button ok_b = new Button("OK");
    Button cancel_b = new Button("Cancel");
    final Integer i = new Integer(Main.props.getProperty("firecat.contacts.num"));

    // Set up the child window to get the new contact's TFA from the user.
    foo.setLayout(new GridLayout(2,2));
    foo.add(tfa_label);
    foo.add(tfa_tf);
    foo.add(ok_b);
    foo.add(cancel_b);

    cancel_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  foo.dispose();
      }
    });

    ok_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){

	// Add the contact to firecat's hash table of contacts
	Main.contact_status.put(tfa_tf.getText(), 
				new UserStatus(true, Main.props.getProperty("firecat.password"), Main.user_status.getPort(), Main.props.getProperty("firecat.tfa"), Main.props.getProperty("firecat.host"), tfa_tf.getText()));
	try{
	  // Find the contact's status
	  new TFPgetStatus((UserStatus) 
			   Main.contact_status.get(tfa_tf.getText()));
	}
	catch(Exception ex){
	  System.out.println("Firecat: Exception: " + ex.getMessage());
	}

	if((((UserStatus) Main.contact_status.get(tfa_tf.getText())).getStatus()).equalsIgnoreCase("SORRY")){
	  Main.contact_status.remove(tfa_tf.getText());
	}else{
	  // Add the contact to firecat's properties.
	  Main.props.put("firecat.contacts.num", i.toString(i.intValue() +1));
	  Main.props.put("firecat.contacts." + i.toString(i.intValue() + 1),
			 tfa_tf.getText());
	  
	  // Now add the contact to the window.
	  addContact((UserStatus) Main.contact_status.get(tfa_tf.getText()));
	}
	main_window.pack();
	main_window.show();
	foo.dispose();    
      }
    });
    
    foo.pack();
    foo.show();
  }

  /**
   * Delete a contact.
   *
   * Sets up a dialog to get the contact's TFA.
   */

  public void deleteContact(){
    final Frame foo = new Frame();
    Label tfa_label = new Label("TFA: ");
    final TextField tfa_tf = new TextField(20);
    Button ok_b = new Button("OK");
    Button cancel_b = new Button("Cancel");
    final Integer i = new Integer(Main.props.getProperty("firecat.contacts.num"));
    
    foo.setLayout(new GridLayout(2,2));
    foo.add(tfa_label);
    foo.add(tfa_tf);
    foo.add(ok_b);
    foo.add(cancel_b);
    
    cancel_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  foo.dispose();
      }
    });

    ok_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	int ii;

	/* Tell our teaser to stop the updates */
	try{new TFPstopStatus((UserStatus) 
			      Main.contact_status.get(tfa_tf.getText()));}
	catch(Exception ee){
	    System.out.println(ee.getMessage());
	}

	/* Remove the button from the GUI.
	 *
	 * This isn't in a seperate method like addContact(UserStatus)
	 * as there isn't any reason this to be done from anywhere
	 * else.
	 */
	if((((UserStatus) Main.contact_status.get(tfa_tf.getText())).getStatus()).equalsIgnoreCase("ONLINE")){
	  online_contacts.setLayout(new GridLayout(online_contacts.getComponentCount() - 1, 1));
	  online_contacts.remove(((UserStatus) Main.contact_status.get(tfa_tf.getText())).getButton());
	}else if((((UserStatus) Main.contact_status.get(tfa_tf.getText())).getStatus()).equalsIgnoreCase("OFFLINE")){
	  offline_contacts.setLayout(new GridLayout(offline_contacts.getComponentCount() - 1, 1));
	  offline_contacts.remove(((UserStatus) Main.contact_status.get(tfa_tf.getText())).getButton());
	}else if((((UserStatus) Main.contact_status.get(tfa_tf.getText())).getStatus()).equalsIgnoreCase("BUSY")){
	  busy_contacts.setLayout(new GridLayout(busy_contacts.getComponentCount() - 1, 1));
	  busy_contacts.remove(((UserStatus) Main.contact_status.get(tfa_tf.getText())).getButton());
	}else if((((UserStatus) Main.contact_status.get(tfa_tf.getText())).getStatus()).equalsIgnoreCase("BACKINFIVE")){
	  backinfive_contacts.setLayout(new GridLayout(backinfive_contacts.getComponentCount() - 1, 1));
	  backinfive_contacts.remove(((UserStatus) Main.contact_status.get(tfa_tf.getText())).getButton());
	}
	
	main_window.pack();
	main_window.show();
	
	/* Delete to contact from the firecat properties and
	 * rename the other contacts' keys appropriately.
	 */
	for(ii = 1; ii <= i.intValue(); ii++){
	  // Scan through till we find the contact to delete
	  if(((String) Main.props.get("firecat.contacts." + i.toString(ii))).equalsIgnoreCase(tfa_tf.getText())){
	    /* now move each contact down one: ie, firecat.contacts.5
	     * becomes firecat.contacts.4 and so on, overwriting the
	     * contact to be deleted in the process.
	     */
	    for(; ii <= i.intValue(); ii++){
	      if(ii != i.intValue())
		Main.props.put("firecat.contacts." + i.toString(ii),
			       Main.props.get("firecat.contacts." + 
					      i.toString(ii+1)));
	    }
	  }
	}
	/* The last contact has been copied to the previous
	 * firecat.contacts.xx so delete it.
	 */
	Main.props.remove("firecat.contacts." + i.toString());
	Main.props.put("firecat.contacts.num", i.toString(i.intValue() -1));

	// remove the contact from our hash table of UserStatus objects.
	Main.contact_status.remove(tfa_tf.getText());

	foo.dispose();    
      }
    });
    
    foo.pack();
    foo.show();
  }

  /**
   * Move a contact button from the old status widget to the new one.
   *
   * @param us UserStatus
   */

  public  void setContactStatus(UserStatus us){
    Panel old_panel = (Panel) (us.getButton()).getParent();
    int i;

    i = old_panel.getComponentCount();

    old_panel.remove(us.getButton());
    old_panel.setLayout(new GridLayout(i-1,1));


    if((us.getStatus()).equalsIgnoreCase("ONLINE")){
      i = online_contacts.getComponentCount();
      online_contacts.setLayout(new GridLayout(i+1,1));
      online_contacts.add(us.getButton());
    }else if((us.getStatus()).equalsIgnoreCase("OFFLINE")){
      i = offline_contacts.getComponentCount();
      offline_contacts.setLayout(new GridLayout(i+1,1));
      offline_contacts.add(us.getButton());
    }else if((us.getStatus()).equalsIgnoreCase("BUSY")){
      i = busy_contacts.getComponentCount();
      busy_contacts.setLayout(new GridLayout(i+1,1));
      busy_contacts.add(us.getButton());
    }else if((us.getStatus()).equalsIgnoreCase("BACKINFIVE")){
      i = backinfive_contacts.getComponentCount();
      backinfive_contacts.setLayout(new GridLayout(i+1,1));
      backinfive_contacts.add(us.getButton());
    }

    main_window.pack();
    main_window.show();
  }

  /**
   * Get the user's email etc.
   *
   * Sets up a dialog to get the info from the user.
   *
   * @param isnewacc true if the user doesn't have an account (ie doesn't have a firecat.rc)
   */

  public void getIdentity(final boolean isnewacc){
    final Frame foo = new Frame();
    Label tfa_label = new Label("TFA: ");
    Label email_label = new Label("Email: ");
    Label url_label = new Label("URL: ");
    Label passwd_label = new Label("Password: ");
    Label uname_label = new Label("User Name: ");
    final TextField tfa_tf = new TextField(20);
    final TextField email_tf = new TextField(20);
    final TextField url_tf = new TextField(20);
    final TextField passwd_tf = new TextField(20);
    final TextField uname_tf = new TextField(20);
    Button ok_b = new Button("OK");
    Button cancel_b = new Button("Cancel");

    /* If the user doesn't have an account then the properties either have
     * a null value or meaningless ones.
     */ 
    if(!isnewacc){
      tfa_tf.setText(Main.props.getProperty("firecat.tfa"));
      email_tf.setText(Main.props.getProperty("firecat.email"));
      url_tf.setText(Main.props.getProperty("firecat.url"));
      passwd_tf.setText(Main.props.getProperty("firecat.password"));
      uname_tf.setText(Main.props.getProperty("firecat.uname"));
    }

    foo.setLayout(new GridLayout(6,2));
    foo.add(tfa_label);
    foo.add(tfa_tf);
    foo.add(passwd_label);
    passwd_tf.setEchoChar('*');
    foo.add(passwd_tf);
    foo.add(email_label);
    foo.add(email_tf);
    foo.add(url_label);
    foo.add(url_tf);
    foo.add(uname_label);
    foo.add(uname_tf);
    foo.add(ok_b);
    foo.add(cancel_b);

    ok_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	Main.props.put("firecat.tfa", tfa_tf.getText());
	Main.props.put("firecat.password", passwd_tf.getText());
	Main.props.put("firecat.email", email_tf.getText());
	Main.props.put("firecat.url", url_tf.getText());
	Main.props.put("firecat.uname", uname_tf.getText());
	Main.props.put("firecat.host", (tfa_tf.getText()).substring((tfa_tf.getText()).indexOf('#') + 1));
	foo.dispose();
	// Register the user with the teaser.
	Main.registerUser(isnewacc);
      }
    });

    cancel_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ce){
	foo.dispose();
      }
    });

    foo.pack();
    foo.show();
  }

  /**
   * Get the user's email client etc.
   *
   * Sets up a dialog to get the info from the user.
   *
   */

  public void getExecs(){
    final Frame foo = new Frame();
    Label email_label = new Label("Email Client: ");
    Label www_label = new Label("WWW Client: ");
    Label talk_label = new Label("Talk Client: ");
    Label ftp_label = new Label("FTP Client: ");
    final TextField email_tf = new TextField(20);
    final TextField www_tf = new TextField(20);
    final TextField talk_tf = new TextField(20);
    final TextField ftp_tf = new TextField(20);
    Button ok_b = new Button("OK");
    Button cancel_b = new Button("Cancel");

    email_tf.setText("emacs -f mail");
    www_tf.setText("netscape");
    talk_tf.setText("rxvt -e talk");
    ftp_tf.setText("rxvt -e ftp");

    foo.setLayout(new GridLayout(5,2));
    foo.add(email_label);
    foo.add(email_tf);
    foo.add(www_label);
    foo.add(www_tf);
    foo.add(talk_label);
    foo.add(talk_tf);
    foo.add(ftp_label);
    foo.add(ftp_tf);
    foo.add(ok_b);
    foo.add(cancel_b);

    ok_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	Main.props.put("firecat.client.email", email_tf.getText());
	Main.props.put("firecat.client.www", www_tf.getText());
	Main.props.put("firecat.client.talk", talk_tf.getText());
	Main.props.put("firecat.client.ftp", ftp_tf.getText());
	foo.dispose();
      }
    });

    cancel_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ce){
	foo.dispose();
      }
    });

    foo.pack();
    foo.show();
  }

    /** Display copyright info 
     */

    public void help(){
	final Frame foo = new Frame();
	TextArea ta = new TextArea(18,80);
	Button b = new Button("OK");

	foo.setLayout(new FlowLayout());
	foo.add(ta);
	foo.add(b);

	ta.setEditable(false);
	ta.append(" \n");
	ta.append(" Firecat - and ICQ like client for the Server `Teaser'.\n");
	ta.append(" Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>\n");
	ta.append(" \n");
	ta.append(" This program is free software; you can redistribute it and/or modify\n");
	ta.append(" it under the terms of the GNU General Public License as published by\n");
	ta.append(" the Free Software Foundation; either version 2 of the License, or\n");
	ta.append(" (at your option) any later version.\n");
	ta.append(" \n");
	ta.append(" This program is distributed in the hope that it will be useful,\n");
	ta.append(" but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
	ta.append(" MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
	ta.append(" GNU General Public License for more details.\n");
	ta.append(" \n");
	ta.append(" You should have received a copy of the GNU General Public License\n");
	ta.append(" along with this program; if not, write to the Free Software\n");
	ta.append(" Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n");

	b.addActionListener(new ActionListener(){
	    public void actionPerformed(ActionEvent ce){
		foo.dispose();
	    }
	});

	foo.pack();
	foo.show();
    }

}








