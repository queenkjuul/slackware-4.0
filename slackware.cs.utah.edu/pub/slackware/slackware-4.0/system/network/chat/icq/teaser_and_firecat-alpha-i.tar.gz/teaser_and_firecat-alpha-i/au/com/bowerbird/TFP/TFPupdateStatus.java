/*    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package au.com.bowerbird.TFP;

import java.lang.*;
import java.io.*;
import java.net.*;

/**
 * Handles the writing sending of status updates.
 *
 * @author Matthew Parry <a href="mailto:mettw@bowerbird.com.au">mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class TFPupdateStatus {
  public TFPupdateStatus(UserStatus us) throws UnknownHostException,
  IOException {
    Socket socket;
    TFPRecord tfpr;

    socket = new Socket(us.getHost(), 7173);
    tfpr = new TFPRecord(socket.getInputStream(), socket.getOutputStream());

    if(us.isFirecat){
      tfpr.PutRecord("FIRECAT 1.0");
      tfpr.PutRecord("USER " + us.getTFA());
      tfpr.PutRecord("PASSWORD " + us.getPassword());
      tfpr.PutRecord("STATUS " + us.getStatus());
    }else{
      tfpr.PutRecord("TEASER 1.0");
      tfpr.PutRecord("DN " + us.getDomainName());
      tfpr.PutRecord("UPDSTAT " + us.getTFA());
      tfpr.PutRecord(us.getStatus());
    }
    //read in reply here
    socket.close();
  }
}

