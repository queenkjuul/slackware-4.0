/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


package au.com.bowerbird.firecat;

import java.lang.*;
import java.awt.*;

/**
 * holds all of the relevant info about a particular user/contact.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * since alpha-i
 */

public class UserStatus{
  public boolean isFirecat;
  String TFA = new String();
  String reqTFA = new String();
  String host = new String();
  String password = new String();
  String status = new String();
    String new_password = new String();
  int port;
  Button user_button = new Button();
    ButtonActionListener bal = new ButtonActionListener();

  /**
   * Constructor method.
   *
   * @param ifarg true if a firecat is using the class, false if a teaser.
   * @param tfaarg TFA to use.
   * @param sarg status of the user.
   * @param parg if a firecat the user password, if teaser then domain name.
   * @param harg Host to contact.
   * @portarg the port the firecat is listening on.
   */

  public UserStatus(boolean ifarg, int portarg, String tfaarg, String sarg,
		    String parg, String harg, String npassarg){
    isFirecat = ifarg;
    TFA = tfaarg;
    status = sarg;
    host = harg;
    port = portarg;
    password = parg;
    new_password = npassarg;
  }

  public UserStatus(boolean ifarg, String parg, int portarg, String tfaarg,
		    String harg, String rarg){
    isFirecat = ifarg;
    password = parg;
    TFA = tfaarg;
    reqTFA = rarg;
    host = harg;
    port = portarg;
    user_button.setLabel(rarg);
    user_button.addActionListener(bal);
  }

  /**
   * @return the button object for the user
   */
  
  public Button getButton(){
    return user_button;
  }

  /**
   * @return TFA of the user
   */

  public String getTFA(){
    return TFA;
  }

  /**
   * @return TFA of the user whos status is being requested.
   */

  public String getRequestedTFA(){
    return reqTFA;
  }

  /**
   * @return the host to contact.
   */

  public String getHost(){
    return host;
  }

  /**
   * @return password of the user
   */

  public String getPassword(){
    return password;
  }

  /**
   * @return new password of the user
   */

  public String getNewPassword(){
    return new_password;
  }

  /**
   * @return status of the user
   */

  public String getStatus(){
    return status;
  }

  /**
   * @param sarg status of the user
   */

  public void setStatus(String sarg){
    status = sarg;
  }

  /**
   * @return the port the firecat is listening on.
   */

  public int getPort(){
    return port;
  }
}
