/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <teaser.h>

void contact_firecat(char*, char*, char*, PGconn*);

void
notify_contacts(char *tfa, char *status, PGconn *pg_conn){
  PGresult *result;
  char *pgexec;
  char *contact = NULL;
  int i;

  i = 1;
  

  /* get the user's list of contacts */
  do{
    char istr[10];

    sprintf(istr, "%d", i);
    pgexec = malloc((strlen("SELECT Status.contacts[") +
		     strlen(istr) + 
		     strlen("] FROM Status WHERE tfa = '") +
		     strlen(tfa) +
		     strlen("';")+1) * sizeof(char));
    strcpy(pgexec, "SELECT Status.contacts[");
    strcat(pgexec, istr);
    strcat(pgexec, "] FROM Status WHERE tfa = '");
    strcat(pgexec, tfa);
    strcat(pgexec, "';");

    t_error(pgexec, FALSE);
    result = db_exec(pg_conn, pgexec);

    if(result == NULL){
      free(pgexec);
      return;
    }

    if(PQresultStatus(result) == PGRES_TUPLES_OK && PQntuples(result) == 1){
      if(contact != NULL)
	free(contact);
      contact = PQgetvalue(result, 0, 0);
    }else{
      t_error(PQerrorMessage(pg_conn), FALSE);
      
      free(pgexec);
      return;
    }

    if(strlen(contact) > 0){
      char *tmp;

      tmp = strchr(contact, '@');
      if(tmp != NULL){ /* the contact is a firecat */
	contact_firecat(contact, status, tfa, pg_conn);
      }else{ /* The contact is a teaser */
	tfp_updstat(contact, NULL, tfa, status);
      }
      
    }
    free(pgexec);
    i++;
  }while(strlen(contact) > 0);

  free(contact);
  
}

void
contact_firecat(char *contact, char *status, char *tfa, PGconn *pg_conn){
  char *contact_status;
  char *pgexec;
  PGresult *result;

  /* find out if the contact is online */
  pgexec = malloc((strlen("SELECT status FROM Status WHERE tfa = '") +
		   strlen(contact) +
		   strlen("';")+1) * sizeof(char));
  strcpy(pgexec, "SELECT status FROM Status WHERE tfa = '");
  strcat(pgexec, contact);
  strcat(pgexec, "';");

  t_error(pgexec, FALSE);
  /* the next command seems to segfault a lot if the contact
   * is offline - but not for all users.
   */
  result = db_exec(pg_conn, pgexec);

  if(result == NULL){
    free(pgexec);
    return;
  }

  if(PQresultStatus(result) == PGRES_TUPLES_OK && 
     PQntuples(result) == 1){
    contact_status = PQgetvalue(result, 0, 0);
  }else{
    t_error(PQerrorMessage(pg_conn), FALSE);
    
    free(pgexec);
    return;
  }

  /* If the contact is not OFFLINE then tell them about the
   * status change.
   */
  if(strcmp(contact_status, "OFFLINE") != 0){
    
    free(pgexec);

    pgexec = malloc((strlen("SELECT ipaddr, port FROM Auth WHERE tfa = '") +
		     strlen(contact) +
		     strlen("';")+1) * sizeof(char));
    strcpy(pgexec, "SELECT ipaddr, port FROM Auth WHERE tfa = '");
    strcat(pgexec, contact);
    strcat(pgexec, "';");
	
    t_error(pgexec, FALSE);
    result = db_exec(pg_conn, pgexec);

    if(result == NULL){
      free(pgexec);
      return;
    }

    if(PQresultStatus(result) == PGRES_TUPLES_OK && 
       PQntuples(result) == 1){
      tfp_updstat(PQgetvalue(result, 0, 0), PQgetvalue(result, 0, 1), 
		  tfa, status);
    }else{
      t_error(PQerrorMessage(pg_conn), FALSE);
    
      free(pgexec);
      return;
    }

  }

  
  free(pgexec);
  free(contact_status);
}
