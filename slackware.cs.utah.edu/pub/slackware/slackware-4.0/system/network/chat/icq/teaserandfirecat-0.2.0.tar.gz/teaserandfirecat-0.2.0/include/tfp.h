/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au
 *
 *This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _TFP_H_
#define _TFP_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/utsname.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#define _XOPEN_SOURCE
#include <unistd.h>

typedef int boolean;
#define TRUE 1
#define FALSE 0

typedef void (*db_functions)();
    
#define BACK_LOG 5 /* This is probably overly conservative */

int teaserdb_lock;

struct client_info{
  struct sockaddr_in client_name;
  int socket;
  int client_length;
};

struct input{
  char *tfa;
  char *password;
  char *new_password;
  char *status;
  char *req_tfa;
  char *uname;
  char *url;
  char *email;
  char *port; /* convert to an int when needed */
  int connect_reason; /* -1 = error
		       * 0 = firecat updstat
		       * 1 = firecat reqstat
		       * 2 = teaser reqstat
		       * 3 = teaser updstat
		       * 4 = teaser stpstat
		       * 5 = firecat stpstat
		       * 6 = newacc
		       * 7 = updacc
		       * 8 = reqemail
		       * 9 = requrl
		       * 10 = reqipa
		       * 11 = requname
		       */
};

struct port {
  int port_num;
  char hostname[80];
  int server_socket;
  struct hostent *host_ptr;
  struct sockaddr_in server_name;
};

int open_server_socket(struct port *);
void handle_connection(struct client_info, db_functions*);
char* read_record(int);
char* get_field(char*, int, char*);
void tfp_error(int, int);
int tfp_updstat(char*, char*, char*, char*);
char* tfp_reqstat(char*, char*);

#endif
