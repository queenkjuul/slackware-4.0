/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <teaser.h>

PGconn *pg_conn;

void
firecat_reqstat(struct client_info slave_socket, struct input client_input){
  PGresult *result;
  char *pgexec;
  char *value;

  /* Open a connection to the database */
  pg_conn = PQsetdb("localhost", NULL, NULL, NULL, "teaserdb");
  /* check it opened OK */
  if(PQstatus(pg_conn) == CONNECTION_BAD){
    t_error(PQerrorMessage(pg_conn), TRUE);
  }

  /* check that the password is OK */
  pgexec = malloc((strlen("SELECT password FROM Auth WHERE tfa = '") +
		   strlen(client_input.tfa) + strlen("';")+1) *
		  sizeof(char));
  strcpy(pgexec, "SELECT password FROM Auth WHERE tfa = '");
  strcat(pgexec, client_input.tfa);
  strcat(pgexec, "';");

  t_error(pgexec, FALSE);
  result = db_exec(pg_conn, pgexec);

  if(result == NULL){
    tfp_error(slave_socket.socket, 402);
    t_error(PQerrorMessage(pg_conn), FALSE);
    free(pgexec);
    PQfinish(pg_conn);
    return;
  }

  if(PQresultStatus(result) == PGRES_TUPLES_OK && PQntuples(result) == 1){
    
    if(strcmp(client_input.password, PQgetvalue(result, 0, 0)) != 0){
      tfp_error(slave_socket.socket, 300);
      t_error(PQerrorMessage(pg_conn), FALSE);
      
      free(pgexec);
      PQfinish(pg_conn);
      return;
    }
  
  }else{
    tfp_error(slave_socket.socket, 201);
    t_error(PQerrorMessage(pg_conn), FALSE);
    
    free(pgexec);
    PQfinish(pg_conn);
    return;
  }
  
  
  free(pgexec);

  /* get the user's status */
  pgexec = malloc((strlen("SELECT status FROM Status WHERE tfa = '") +
		   strlen(client_input.req_tfa) +
		   strlen("';")+1) * sizeof(char));
  strcpy(pgexec, "SELECT status FROM Status WHERE tfa = '");
  strcat(pgexec, client_input.req_tfa);
  strcat(pgexec, "';");

  t_error(pgexec, FALSE);
  result = db_exec(pg_conn, pgexec);

  if(result == NULL){
    tfp_error(slave_socket.socket, 402);
    t_error(PQerrorMessage(pg_conn), FALSE);
    free(pgexec);
    PQfinish(pg_conn);
    return;
  }

  if(PQresultStatus(result) == PGRES_TUPLES_OK && PQntuples(result) == 1){
    value = PQgetvalue(result, 0, 0);
  }else{
    char *host;
    boolean islocal = FALSE;
    int i = 0;

    /* check if the user is on another teaser and do a
     * reqtfa to that teaser.
     */
    host = index(client_input.req_tfa, '@');

    if(strcmp(port.host_ptr->h_name, (host+1)) == 0)
      islocal = TRUE;
    while(port.host_ptr->h_aliases[i] != NULL){
      if(strcmp(port.host_ptr->h_aliases[i], (host+1)) == 0)
	islocal = TRUE;
      i++;
    }

    if(!islocal){
      value = tfp_reqstat((host+1), client_input.req_tfa);

      /* also add the requested user to the DB.
       */

      
      free(pgexec);

      pgexec = malloc((strlen("INSERT INTO Status VALUES ('") +
		       strlen(client_input.req_tfa) +
		       strlen("', '") +
		       strlen(value) +
		       strlen("', '{}');")+1) * 
		      sizeof(char));
      strcpy(pgexec, "INSERT INTO Status VALUES ('");
      strcat(pgexec, client_input.req_tfa);
      strcat(pgexec, "', '");
      strcat(pgexec, value);
      strcat(pgexec, "', '{}');");

      t_error(pgexec, FALSE);
      result = db_exec(pg_conn, pgexec);
    }else{
      tfp_error(slave_socket.socket, 201);
      
      free(pgexec);
      free(value);
      free(host);
      PQfinish(pg_conn);
      return;
    }
    free(host);
  }
  
  write(slave_socket.socket, value, strlen(value));
  write(slave_socket.socket, "\n", strlen("\n"));

  /* add the client to the requested user's list of contacts */
  
  free(pgexec);

  pgexec = malloc((strlen("SELECT contacts FROM Status WHERE tfa = '") +
		   strlen(client_input.req_tfa) +
		   strlen("';")+1) * sizeof(char));
  strcpy(pgexec, "SELECT contacts FROM Status WHERE tfa = '");
  strcat(pgexec, client_input.req_tfa);
  strcat(pgexec, "';");

  t_error(pgexec, FALSE);
  result = db_exec(pg_conn, pgexec);
  if(PQresultStatus(result) == PGRES_TUPLES_OK && PQntuples(result) == 1){
    value = PQgetvalue(result, 0, 0);
  }else{
    tfp_error(slave_socket.socket, 402);
    t_error(PQerrorMessage(pg_conn), FALSE);
    
    free(pgexec);
    free(value);
    PQfinish(pg_conn);
    return;
  }
  
  /* if the user isn't already in the list of contacts */
  if(strstr(value, client_input.tfa) == NULL){
    char *initial_str;

    
    free(pgexec);
    
    if(strlen(value) == 2){
      initial_str = malloc(2*sizeof(char));
      strcpy(initial_str, "\"");
    }else{
      initial_str = malloc(3*sizeof(char));
      strcpy(initial_str, ",\"");
    }

    pgexec = malloc((strlen("UPDATE Status SET contacts = '") +
		     strlen(value) - 1 + strlen(initial_str) + 
		     strlen(client_input.tfa) + strlen("\"}'") +
		     strlen(" WHERE tfa = '") +
		     strlen(client_input.req_tfa) + strlen("';")+1) * 
		    sizeof(char));
    strcpy(pgexec, "UPDATE Status SET contacts = '");
    strncat(pgexec, value, strlen(value) - 1);
    strcat(pgexec, initial_str);
    strcat(pgexec, client_input.tfa);
    strcat(pgexec, "\"}'");
    strcat(pgexec, " WHERE tfa = '");
    strcat(pgexec, client_input.req_tfa);
    strcat(pgexec, "';");

    t_error(pgexec, FALSE);
    db_exec(pg_conn, pgexec);

    free(initial_str);
    
    free(pgexec);
  }

  PQfinish(pg_conn);
}
