/*
 * Teaser - A copyleft implimentation of RVP
 * Copyright (C) 1998, 1999 Matthew Parry <mettw@bowerbird.com.au
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Non-Consultants' License as published by
 * Bowerbird Computing; either version 1.2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Non-Consultants' License for more details.
 *
 * You should have received a copy of the Non-Consultants' License
 * along with this program; if not, write to Bowerbird Computing,
 * PO Box 247, Nowra NSW, Australia, 2541.
 */

#ifndef _T_HASHTABLE_H_
#define _T_HASHTABLE_H_

#include <publib.h>

Hashtab* t_hash_create(void);
void t_hash_destroy(Hashtab*);
char* t_hash_get(Hashtab*, char*);
int t_hash_put(Hashtab*, char*, char*);
int t_hash_delete(Hashtab*, char*);
int t_hash_atts_put(Hashtab*, char*, char*, char*);
char* t_hash_atts_get(Hashtab*, char*, char*);

#endif
