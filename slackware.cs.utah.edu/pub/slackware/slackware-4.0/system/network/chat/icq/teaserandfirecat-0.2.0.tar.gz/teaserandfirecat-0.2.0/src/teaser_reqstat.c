/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <teaser.h>

PGconn *pg_conn;

void
teaser_reqstat(struct client_info slave_socket, struct input client_input){
  PGresult *result;
  char *pgexec;
  char *value;

  /* Open a connection to the database */
  pg_conn = PQsetdb("localhost", NULL, NULL, NULL, "teaserdb");
  /* check it opened OK */
  if(PQstatus(pg_conn) == CONNECTION_BAD){
	t_error(PQerrorMessage(pg_conn), TRUE);
  }


  /* get the user's status */
  pgexec = malloc((strlen("SELECT status FROM Status WHERE tfa = '") +
		   strlen(client_input.req_tfa) +
		   strlen("';")+1) * sizeof(char));
  strcpy(pgexec, "SELECT status FROM Status WHERE tfa = '");
  strcat(pgexec, client_input.req_tfa);
  strcat(pgexec, "';");

  t_error(pgexec, FALSE);
  result = db_exec(pg_conn, pgexec);

  if(result == NULL){
    tfp_error(slave_socket.socket, 402);
    t_error(PQerrorMessage(pg_conn), FALSE);
    free(pgexec);
    PQfinish(pg_conn);
    return;
  }

  if(PQresultStatus(result) == PGRES_TUPLES_OK && PQntuples(result) == 1){
    value = PQgetvalue(result, 0, 0);
  }else{
    tfp_error(slave_socket.socket, 201);
    t_error(PQerrorMessage(pg_conn), FALSE);
    
    free(pgexec);
    return;
  }

  write(slave_socket.socket, value, strlen(value));
  write(slave_socket.socket, "\n", strlen("\n"));

  /* add the client to the requested user's list of contacts */
  
  free(pgexec);

  pgexec = malloc((strlen("SELECT contacts FROM Status WHERE tfa = '") +
		   strlen(client_input.req_tfa) +
		   strlen("';")+1) * sizeof(char));
  strcpy(pgexec, "SELECT contacts FROM Status WHERE tfa = '");
  strcat(pgexec, client_input.req_tfa);
  strcat(pgexec, "';");

  t_error(pgexec, FALSE);
  result = db_exec(pg_conn, pgexec);
  if(PQresultStatus(result) == PGRES_TUPLES_OK && PQntuples(result) == 1){
    value = PQgetvalue(result, 0, 0);
  }else{
    tfp_error(slave_socket.socket, 402);
    t_error(PQerrorMessage(pg_conn), FALSE);
    
    free(pgexec);
    PQfinish(pg_conn);
    return;
  }

  /* if the user isn't already in the list of contacts */
  if(strstr(value, inet_ntoa(slave_socket.client_name.sin_addr)) == NULL){  
    char *initial_str;

    
    free(pgexec);
    
    if(strlen(value) == 2){
      initial_str = malloc(2*sizeof(char));
      strcpy(initial_str, "\"");
    }else{
      initial_str = malloc(3*sizeof(char));
      strcpy(initial_str, ",\"");
    }

    pgexec = malloc((strlen("UPDATE Status SET contacts = '") +
		     strlen(value) - 1 + strlen(initial_str) + 
		     strlen(inet_ntoa(slave_socket.client_name.sin_addr))
		     + strlen("\"}'") +
		     strlen(" WHERE tfa = '") +
		     strlen(client_input.req_tfa) + strlen("';")+1) * 
		    sizeof(char));
    strcpy(pgexec, "UPDATE Status SET contacts = '");
    strncat(pgexec, value, strlen(value) - 1);
    strcat(pgexec, initial_str);
    strcat(pgexec, inet_ntoa(slave_socket.client_name.sin_addr));
    strcat(pgexec, "\"}'");
    strcat(pgexec, " WHERE tfa = '");
    strcat(pgexec, client_input.req_tfa);
    strcat(pgexec, "';");

    t_error(pgexec, FALSE);
    db_exec(pg_conn, pgexec);

    free(initial_str);
  }

  
  free(pgexec);
  free(value);
  PQfinish(pg_conn);
}
