/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <tfp.h>

/* Gets a field from the record passed to it.  fs is a string of
 * characters to use as field separators, if NULL then any non-printing
 * character is used.
 */

char*
get_field(char* record, int field, char* fs){
  char *ret;
  int i = 0;
  int f_num = 1;
  int length = strlen(record);

  ret = malloc(sizeof(char));

  if(length == 0){
    free(ret);
    return NULL;
  }

  if(fs == NULL){ /* user any non-printing character for the FS */

    /* skip forward untill we find the start of the requested field */
    while(f_num < field && i < length){
      /* skip past any leading whitespace */
      while(record[i] < '\041' || record[i] > '\176' && i < length){
	i++;
      }

      /* skip past the unwanted field */
      while(record[i] > '\040' && record[i] < '\177' && i < length){
	i++;
      }
      f_num++;
    }

    /* skip past any leading whitespace */
    while(record[i] < '\041' || record[i] > '\176' && i < length){
      i++;
    }
      
    if(i < length){
      f_num = i;
      /* read in the field untill we find a non-printing character */
      while(record[i] > '\040' && record[i] < '\177' && i < length){
	ret = realloc(ret, (i - f_num + 1)*sizeof(char));
	ret[i - f_num] = record[i];
	i++;
      }
      
      ret = realloc(ret, (i - f_num + 1)*sizeof(char));
      ret[i - f_num] = '\0';

      return ret;
    }
  }
  /* need to write the rest some time...
   * fs is a string of characters to use as Field Separators.
   */

  free(ret);
  return NULL;
}
