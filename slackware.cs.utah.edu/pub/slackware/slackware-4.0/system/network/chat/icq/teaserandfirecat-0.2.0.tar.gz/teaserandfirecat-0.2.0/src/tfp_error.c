/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <tfp.h>

/* handles the writing of error messages over the socket for
 * TFP 1.2
 */

void
tfp_error(int slave_socket, int error_id){
  
  switch(error_id){
  case 100:
    write(slave_socket, "SORRY 100, Not TFP\n", 
	  strlen("SORRY 100, Not TFP\n"));
    break;
  case 101:
    write(slave_socket, "SORRY 101, Didn't follow declared TFP version\n",
	  strlen("SORRY 101, Didn't follow declared TFP version\n"));
    break;
  case 102:
    write(slave_socket, "SORRY 102, Unknown TFP version\n",
	  strlen("SORRY 102, Unknown TFP version\n"));
    break;
  case 200:
    write(slave_socket, "SORRY 200, Malformed TFA\n",
	  strlen("SORRY 200, Malformed TFA\n"));
    break;
  case 201:
    write(slave_socket, "SORRY 201, Unknown user\n", 
	  strlen("SORRY 201, Unknown user\n"));
    break;
  case 202:
    write(slave_socket, "SORRY 202, You contacted the wrong Teaser\n", 
	  strlen("SORRY 202, You contacted the wrong Teaser\n"));
    break;
  case 300:
    write(slave_socket, "SORRY 300, Request not permitted\n", 
	  strlen("SORRY 300, Request not permitted\n"));
    break;
  case 301:
    write(slave_socket, "SORRY 301, Requested info not available\n", 
	  strlen("SORRY 301, Requested info not available\n"));
    break;
  case 400:
    write(slave_socket, "SORRY 400, Couldn't contact Teaser\n", 
	  strlen("SORRY 400, Couldn't contact Teaser\n"));
    break;
  case 401:
    write(slave_socket, "SORRY 401, Service temporarily unavailable\n", 
	  strlen("SORRY 401, Service temporarily unavailable\n"));
    break;
  case 402:
    write(slave_socket, "SORRY 402, Internal error handling request\n", 
	  strlen("SORRY 402, Internal error handling request\n"));
    break;
  case 403:
    write(slave_socket, "SORRY 403, Unknown host\n", 
	  strlen("SORRY 403, Unknown host\n"));
    break;
  default:
    write(slave_socket, "SORRY\n", 
	  strlen("SORRY\n"));
  }
}

