/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


package au.com.bowerbird.firecat;

import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;

/**
 * ActionListener for the contact's buttons.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * @since alpha-iii
 */

public class ButtonActionListener implements ActionListener {
  public void actionPerformed(ActionEvent ae){
    final String command = new String(ae.getActionCommand());
    final Frame foo = new Frame();
    Button email_b = new Button("Email");
    Button www_b = new Button("WWW");
    Button talk_b = new Button("Talk");
    Button dip_email_b = new Button("DynIP Email");
    Button dip_www_b = new Button("DynIP WWW");
    Button dip_ftp_b = new Button("DynIP FTP");
    Button cancel_b = new Button("Cancel");

    foo.setTitle(ae.getActionCommand());
    foo.setLayout(new GridLayout(7,1));
    foo.add(email_b);
    foo.add(www_b);
    foo.add(talk_b);
    foo.add(dip_email_b);
    foo.add(dip_www_b);
    foo.add(dip_ftp_b);
    foo.add(cancel_b);

    email_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  String emailaddr = new String();
	  TFPgetUserInfo tfpgui = new TFPgetUserInfo();
	  Runtime rt = Runtime.getRuntime();

	  try{emailaddr = tfpgui.getUserInfo((UserStatus)
				       Main.contact_status.get(command),
				       "REQEMAIL");}
	  catch(Exception ee){
	      System.out.println(ee.getMessage());
	      foo.dispose();
	      return;
	  }
	  
	  showEmailAddr(emailaddr);

	  try{rt.exec((String) Main.props.get("firecat.client.email"));}
	  catch(IOException ioe){
	      System.out.println("Got exception execing email client: " +
				 ioe.getMessage());
	  }
      }
    });

    www_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  String url = new String();
	  TFPgetUserInfo tfpgui = new TFPgetUserInfo();
	  Runtime rt = Runtime.getRuntime();

	  try{url = tfpgui.getUserInfo((UserStatus)
				       Main.contact_status.get(command),
				       "REQURL");}
	  catch(Exception ee){
	      System.out.println(ee.getMessage());
	      foo.dispose();
	      return;
	  }
	  
	  try{rt.exec(Main.props.get("firecat.client.www") +
			  " " + url.trim());}
	  catch(IOException ioe){
	      System.out.println("Got exception execing WWWbowser: " +
				 ioe.getMessage());
	  }
	  foo.dispose();
      }
    });

    talk_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  String url = new String();
	  String uname = new String();
	  TFPgetUserInfo tfpgui = new TFPgetUserInfo();
	  Runtime rt = Runtime.getRuntime();

	  try{url = tfpgui.getUserInfo((UserStatus)
				       Main.contact_status.get(command),
				       "REQIPA");}
	  catch(Exception ee){
	      System.out.println(ee.getMessage());
	      foo.dispose();
	      return;
	  }
	  
	  try{uname = tfpgui.getUserInfo((UserStatus)
				       Main.contact_status.get(command),
				       "REQUNAME");}
	  catch(Exception ee){
	      System.out.println(ee.getMessage());
	      foo.dispose();
	      return;
	  }

	  try{rt.exec(Main.props.get("firecat.client.talk") +
			  " " + uname.trim() + "@" + url.trim());}
	  catch(IOException ioe){
	      System.out.println("Got exception execing talk client: " +
				 ioe.getMessage());
	  }
	  foo.dispose();
      }
    });

    dip_email_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  String ipaddr = new String();
	  String uname = new String();
	  TFPgetUserInfo tfpgui = new TFPgetUserInfo();
	  Runtime rt = Runtime.getRuntime();

	  try{ipaddr = tfpgui.getUserInfo((UserStatus)
				       Main.contact_status.get(command),
				       "REQIPA");}
	  catch(Exception ee){
	      System.out.println(ee.getMessage());
	      foo.dispose();
	      return;
	  }
	  
	  try{uname = tfpgui.getUserInfo((UserStatus)
				       Main.contact_status.get(command),
				       "REQUNAME");}
	  catch(Exception ee){
	      System.out.println(ee.getMessage());
	      foo.dispose();
	      return;
	  }

	  showEmailAddr( uname.trim() + "@" + ipaddr.trim());
	  try{rt.exec((String) Main.props.get("firecat.client.email"));}
	  catch(IOException ioe){
	      System.out.println("Got exception execing email client: " +
				 ioe.getMessage());
	  }
	  foo.dispose();
      }
    });

    dip_www_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  String url = new String();
	  String uname = new String();
	  TFPgetUserInfo tfpgui = new TFPgetUserInfo();
	  Runtime rt = Runtime.getRuntime();

	  try{url = tfpgui.getUserInfo((UserStatus)
				       Main.contact_status.get(command),
				       "REQIPA");}
	  catch(Exception ee){
	      System.out.println(ee.getMessage());
	      foo.dispose();
	      return;
	  }
	  
	  try{uname = tfpgui.getUserInfo((UserStatus)
				       Main.contact_status.get(command),
				       "REQUNAME");}
	  catch(Exception ee){
	      System.out.println(ee.getMessage());
	      foo.dispose();
	      return;
	  }

	  try{rt.exec(Main.props.get("firecat.client.www") +
		      " http://" + url.trim() + "/~" + uname.trim() +
		      "/");}
	  catch(IOException ioe){
	      System.out.println("Got exception execing WWW client: " +
				 ioe.getMessage());
	  }
	  foo.dispose();
      }
    });

    dip_ftp_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  String url = new String();
	  TFPgetUserInfo tfpgui = new TFPgetUserInfo();
	  Runtime rt = Runtime.getRuntime();

	  try{url = tfpgui.getUserInfo((UserStatus)
				       Main.contact_status.get(command),
				       "REQIPA");}
	  catch(Exception ee){
	      System.out.println(ee.getMessage());
	      foo.dispose();
	      return;
	  }
	  
	  try{rt.exec(Main.props.get("firecat.client.ftp") +
			  " " + url.trim());}
	  catch(IOException ioe){
	      System.out.println("Got exception execing ftp client: " +
				 ioe.getMessage());
	  }
	  foo.dispose();
      }
    });

    cancel_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  foo.dispose();
      }
    });


    foo.pack();
    foo.show();
  }

    public void showEmailAddr(String emailaddr){
	final Frame foo = new Frame();
	Label email_label = new Label("Email address is: " + emailaddr + " ");
	Button ok_b = new Button("OK");

    foo.setLayout(new GridLayout(2,1));
    foo.add(email_label);
    foo.add(ok_b);

    ok_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	  foo.dispose();
      }
    });


    foo.pack();
    foo.show();
    }
}
