/*
 * Teaser - A copyleft implimentation of RVP
 * Copyright (C) 1998, 1999 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Non-Consultants' License as published by
 * Bowerbird Computing; either version 1.2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Non-Consultants' License for more details.
 *
 * You should have received a copy of the Non-Consultants' License
 * along with this program; if not, write to Bowerbird Computing,
 * PO Box 247, Nowra NSW, Australia, 2541.
 */


#include <teaser.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <guile/gh.h>

void load_conf_file();
void disclaimer();
void disconnect_from_terminal();
void help();
void sigterm_handler();
void child_sigterm_handler();
void get_pid_file();
int open_server_socket(struct port *);
boolean handle_connection(struct client_info);

char *log_file;
int rvp_port;

char *teaser_version = "19990326";

struct sigaction child_death = {
  NULL,
  0,
  SA_NOCLDSTOP|SA_RESTART,
  NULL};

int __main(int, char**);

int
main (int argc, char **argv){
  /* Boot the scheme interpreter
   */

  gh_enter(argc, argv, __main);
  return 0; /* never reached */

}

int
__main (int argc, char **argv){
  boolean break_from_terminal = TRUE;
  boolean open_log_file = FALSE;

  /* First up, parse the command line options:
   * - if an alternative
   * log file is given then open it for writing instead.
   * - If -d is given then print all error messages to stderr (ie,
   * set logfd = -1.) and don't fork into the background.
   * - if --help|-h is given then print the usage message and exit.
   * ---Should really use getopt(), maybe later.
   */

  switch(argc){
  case 1:
    open_log_file = TRUE;
    break;
  case 2:
    if(strcmp(argv[1], "-d") == 0){
      logfd = -1;
      break_from_terminal = FALSE;
      break;
    }else if(strcmp(argv[1], "-h") == 0){
      help();
      exit(0);
    }
  default:
    help();
    exit(1);
  }


  /* Load the rc file - this just defines some variables, and
   * should NOT be edited.
   */

  gh_load(RC_FILE);

  /* Load in the configuration file
   */
  load_conf_file();

  /* We need to fork into the background and then make
   * sure we don't get any signals from the terminal or
   * reconnect to it.
   */
  if(break_from_terminal)
    disconnect_from_terminal();

  port.port_num = rvp_port;

  if(open_log_file)
    logfd = open(log_file, 
		 O_WRONLY|O_CREAT|O_APPEND, 0600);
  disclaimer();

  t_error(FALSE, "pid-file = %s", pid_file);
  t_error(FALSE, "log-file = %s", log_file);
  t_error(FALSE, "rvp-port = %d", rvp_port);

  t_error(FALSE, "Daemon started");

  signal(SIGTERM, sigterm_handler);
  signal(SIGINT, sigterm_handler);
  signal(SIGQUIT, sigterm_handler);
  signal(SIGABRT, sigterm_handler);  
  signal(SIGFPE, sigterm_handler);
  signal(SIGILL, sigterm_handler);
  signal(SIGSEGV, sigterm_handler);
  sigaction(SIGCHLD, &child_death, NULL);

  get_pid_file();

  /* Open a socket and set all the neccesary options on it.
   */

  /**
   ** Need to allow UDP connections as well.
   **/

  if(open_server_socket(&port))
    t_error(TRUE, "couldn't open port");

  /* Now continuously listen for connections and then handle
   * the IO.
   */

  if( -1 == listen(port.server_socket, BACK_LOG))
    t_error(TRUE, "Can't listen on port");

  while(1){
    unsigned int status;
    int pid;
    struct client_info slave_socket = { 0 };
    
    /*    slave_socket.client_name = { 0 };*/
    slave_socket.client_length = sizeof(slave_socket.client_name);

    (void) memset(&slave_socket.client_name, 0, 
		  slave_socket.client_length);

    slave_socket.socket = accept(port.server_socket, 
				 (struct sockaddr *) 
				 &slave_socket.client_name,
				 &slave_socket.client_length);
    if(slave_socket.socket == -1)
      t_error(FALSE, "couldn't accept connection");

    pid = fork();

    switch(pid){
    case -1:
      t_error(TRUE, "Couldn't fork child");
    case 0: /* child process */

      umask(0000);
      signal(SIGTERM, child_sigterm_handler); 
      signal(SIGINT, child_sigterm_handler); 
      signal(SIGQUIT, child_sigterm_handler); 
      signal(SIGABRT, child_sigterm_handler); 
      signal(SIGFPE, child_sigterm_handler);
      signal(SIGILL, child_sigterm_handler);
      signal(SIGSEGV, child_sigterm_handler);

      t_error(FALSE, "Connection opened by %s", 
	      inet_ntoa(slave_socket.client_name.sin_addr));
      while(handle_connection(slave_socket));

      exit(0);
      
    default: /* parent process */
      close(slave_socket.socket);
    }
  }
}

void
load_conf_file(void){
  int lenp_p, lenp_l;

  gh_load(CONF_FILE);

  pid_file = gh_scm2newstr(gh_eval_str("pid-file"), &lenp_p);
  log_file = gh_scm2newstr(gh_eval_str("log-file"), &lenp_l);
  rvp_port = (int) gh_scm2ulong(gh_eval_str("rvp-port"));

  if(log_file == NULL || pid_file == NULL)
    t_error(TRUE, "log or pid file is null");
}
      

/* Forks the server into the background and then makes sure that
 * we don't get any signals from the terminal and that we can't
 * reconnect to it.
 *
 * This is only used in main()
 */

void
disconnect_from_terminal(){
  int tmpid;
  int tmpfd;
  int i;
  struct rlimit resource_limit = { 0 };
  
  tmpid = fork();

  /* fork into the background.
   */
  
  switch(tmpid){
  case -1:
    t_error(TRUE, "Couldn't do first fork()");
  case 0: /* child */
    break;
  default: /* parent */
    exit(0);
  }

  resource_limit.rlim_max = 0;

  if(getrlimit(RLIMIT_NOFILE, &resource_limit) == -1)
    t_error(TRUE, "Problem with getrlimit()");

  if(resource_limit.rlim_max == 0)
    t_error(TRUE, "Max number of file descs is 0.");

  for(i = 0; i < resource_limit.rlim_max; i++)
    close(i);

  /* create a new group leader */
#if BSD
  {
    int bsdfd;

    stgrep(0, getpid());

    bsdfd = open("/dev/tty", O_RDWR);
    if(bsdfd != -1){
      ioctl(bsdfd, TIOCNOTTY, 0);
      close(bsdfd);
    }
  }
#elif SVR4
  setpgrp();
#else
  if(setsid() == -1)
    t_error(TRUE, "Error executing setsid()");
#endif

  tmpid = fork();

  /* Now fork again so we have a new group leader and
   * therefore won't receive any signals from the shell.
   */
  switch(tmpid){
  case -1:
    t_error(TRUE, "couldn't do second fork");
  case 0: /* child */
    break;
  default:
    exit(0);
  }

  /* chdir to root so we can unmount the filesystem the
   * program was launched on if we want to.
   */
  chdir("/");
  umask(0);

  /* Now reopen stdin/stduot/stderr pointing to /dev/null
   * incase some function need one of them.
   */
  tmpfd = open("/dev/null", O_RDWR); 
  dup(tmpfd);
  dup(tmpfd);
  
}

void
help(){

  fprintf(stderr, "usage: teaser -d|-h\n"
	  "-d\tDon't fork from the terminal and print\n"
	  "\tall logs to stderr.\n"
	  "-h\tPrint this error message.\n");
}

void
disclaimer(){
  t_error(FALSE, "\nTeaser version %s, Copyright (C) 1999 Matthew Parry"
	  "\nThis program is distributed in the hope that it will be useful,"
	  "\nbut WITHOUT ANY WARRANTY; without even the implied warranty of"
	  "\nMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the"
	  "\nNon-Consultants' License for more details."
	  "\n"
	  "\nYou should have received a copy of the Non-Consultants' License"
	  "\nalong with this program; if not, write to Bowerbird Computing,"
	  "\nPO Box 247, Nowra NSW, Australia, 2541.", 
	  teaser_version);

}

void
sigterm_handler(int sig){
  int status;

  switch(sig){
  case SIGTERM:
    t_error(FALSE, "SIGTERM caught, exiting...");
    break;
  case SIGINT:
    t_error(FALSE, "SIGINT caught, exiting...");
    break;
  case SIGQUIT:
    t_error(FALSE, "SIGQUIT caught, exiting...");
    break;
  case SIGABRT:
    t_error(FALSE, "SIGABRT caught, exiting...");
    break;
  case SIGFPE:
    t_error(FALSE, "SIGFPE caught, exiting...");
    break;
  case SIGILL:
    t_error(FALSE, "SIGILL caught, exiting...");
    break;
  case SIGSEGV:
    t_error(FALSE, "SIGSEGV caught, exiting...");
    break;
  }

  unlink(pid_file);
  t_error(FALSE, "Parent process exited.");
  close(logfd);
  exit(sig);
}

void
child_sigterm_handler(int sig){

  switch(sig){
  case SIGTERM:
    t_error(FALSE, "SIGTERM caught by child, exiting...");
    break;
  case SIGINT:
    t_error(FALSE, "SIGINT caught by child, exiting...");
    break;
  case SIGQUIT:
    t_error(FALSE, "SIGQUIT caught by child, exiting...");
    break;
  case SIGABRT:
    t_error(FALSE, "SIGABRT caught by child, exiting...");
    break;
  case SIGFPE:
    t_error(FALSE, "SIGFPE caught by child, exiting...");
    break;
  case SIGILL:
    t_error(FALSE, "SIGILL caught by child, exiting...");
    break;
  case SIGSEGV:
    t_error(FALSE, "SIGSEGV caught by child, exiting...");
    break;
  }

  exit(sig);
}

/* Try to get a pid file so we don't have more than one copy of
 * Teaser running at once.
 */

void
get_pid_file(){
  int fd;
  char *pid;

  fd = open(pid_file, O_RDONLY, NULL);

  if(fd == -1){
    fd = open(pid_file, 
	      O_WRONLY|O_CREAT, 0644);
    if(fd == -1)
      t_error(TRUE, "Couldn't open pid file %s", pid_file);
    
    asprintf(&pid, "%d", getpid());
    write(fd, pid, strlen(pid));
    close(fd);
    free(pid);
  }else{
    char pidchar;
    int i = 0;

    pid = malloc(sizeof(char));
    while( read(fd, &pidchar, 1) != 0){
      pid = realloc(pid, (i+2)*sizeof(char));
      pid[i] = pidchar;
      i++;
      pid[i] = '\0';
    }

    t_error(FALSE, 
	    "Pid file %s exists and contains pid %s", pid_file, pid);
    free(pid);
    exit(1);
  }
}

/* Opens a socket on the local machine
 */

int get_hostname(struct port*);
int bind_port(struct port*);

int
open_server_socket (struct port *port){

  /* open a TCP socket
   */

  port->server_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

  if(port->server_socket == -1){
    t_error(FALSE, "Couldn't get socket");
    return 1;
  }

  /* turn off bind address checking so we don't have to wait for
   * TIME_WAIT to timeout the port.
   */
  {
    boolean reuse_addr = TRUE;

    if(setsockopt(port->server_socket, SOL_SOCKET, SO_REUSEADDR,
		  (const char *) &reuse_addr, sizeof(reuse_addr)) == -1)
      t_error(FALSE, "couldn't set SO_REUSEADDR");
    
  }

  /* all of the connections are short so we shouldn't have
   * to linger on the port after the connection has been closed.
   */
  {
    struct linger linger = { 0 };

    linger.l_onoff = 0;
    
    if(setsockopt(port->server_socket, SOL_SOCKET, SO_LINGER, 
		  (const char *) &linger, sizeof(linger)) == -1)
      t_error(FALSE, "couldn't turn off lingering");

  }

  /* Find out what the hostname of this machine is.
   */
  
  if(get_hostname(port))
    return 1;

  /* Now bind the hostname and port to our socket
   */
  if(bind_port(port))
    return 1;

  return 0;
}


/* Get the host name and then the FQDN via gethostbyname().
 * We don't use gethostname() because this is apparently
 * unsupported or deprecated on some unices.
 */

int
get_hostname(struct port *port){
  struct utsname system_name = { 0 };

  /* set hostname
   */
  if(uname(&system_name) != -1)
    (void) strncpy(port->hostname, system_name.nodename,
		   sizeof(port->hostname));
  else{
    t_error(FALSE, "couldn't determine hostname");
    return 1;
  }

  port->host_ptr = gethostbyname(port->hostname);

  /* This should only happen on my own (dialup) box while I'm
   * testing teaser.
   */

  if(port->host_ptr == NULL){
    t_error(FALSE, "Couldn't determine FQDN, using hostname instead");
    port->host_ptr->h_name = port->hostname;
    port->host_ptr->h_aliases = NULL;
    /*    port->host_ptr->h_addrtype = BAF_INETP;*/
    port->host_ptr->h_length = sizeof(port->hostname);
    port->host_ptr->h_addr_list = malloc(2*sizeof(int));
    port->host_ptr->h_addr_list[0] = port->hostname;
    port->host_ptr->h_addr_list[1] = NULL;
    port->host_ptr->h_addr = port->hostname;
  }

  (void) memset(&port->server_name, 0, sizeof(port->server_name));
  (void) memcpy(&port->server_name.sin_addr, port->host_ptr->h_addr,
		port->host_ptr->h_length);

  return 0;
}


/* Bind the socket to a particular port
 */

int
bind_port(struct port *port){

  port->server_name.sin_family = AF_INET;
  port->server_name.sin_port = htons(port->port_num);
  if(-1 == bind(port->server_socket, (struct sockaddr *) &port->server_name,
		sizeof(port->server_name)))
    return 1;

  return 0;
}

/* Handles all communication for the teaser.
 */

struct input get_input(int);

boolean
handle_connection(struct client_info slave_socket){
  struct input client_input = { 0 };
  boolean keep_connection_open = TRUE;

  client_input = get_input(slave_socket.socket);
  if(client_input.rvp_return != 0)
    rvp_error(slave_socket.socket, client_input.rvp_return);
  else{
    char *function = NULL;
    int lenp;

    /* Resolve the url into a file on our machine and also do
     * some checking to see if the protocol/hostname is
     * correct.
     */

    do{  
      if(function != NULL)
	free(function);
      function = gh_scm2newstr(gh_eval_str("(car url-resolve-hooks)"), &lenp);
      t_error(FALSE, "function = %s", function);
      if(lenp == 0)
	t_error(TRUE, "No hook for URL resolving!");

      if(strcmp(function, "default") == 0)
	client_input = default_url_resolver(client_input);
      else{
	gh_load(function);
	/* if the function gave a reply then
	 * stop passing the request to other
	 * fuctions.
	 */
	if (client_input.rvp_return != 0){
	  free(function);
	  asprintf(function, "%s", "default");
	}
      }
    
      lenp = 0;
    }while(strcmp(function, "default") != 0);

    /* Method hooks.
     */
    do{
      if(function != NULL)
	free(function);
      function = gh_scm2newstr(gh_eval_str("(car rvp-method-process-hooks)"), 
			       &lenp);
      t_error(FALSE, "function = %s", function);
      if(lenp == 0)
	t_error(TRUE, "No hook for method processing!");

      if(strcmp(function, "default") == 0)
	client_input = default_method_processor(client_input);
      else{
	gh_load(function);
	/* If the function gave an RVP reply then stop
	 * sending the request to other functions.
	 */
	if (client_input.rvp_return != 0){
	  free(function);
	  asprintf(function, "%s", "default");
	}
      }

      lenp = 0;
    }while(strcmp(function, "default") != 0);

    if(function != NULL)
      free(function);

    rvp_error(slave_socket.socket, client_input.rvp_return);
  }

  /* Keep a persistent connection unless the client sent a
   * Connection: close
   * in the header.
   * The getfield() is to get rid of any leading whitespace.
   */
  if(client_input.header != NULL){
    char *value = t_hash_get(client_input.header, "connection");

    if(value != NULL){
      if(strcmp(get_field(value, 1, NULL), "close") == 0){
	close(slave_socket.socket);
	t_error(FALSE, "Connection to %s closed by server",
		inet_ntoa(slave_socket.client_name.sin_addr));
	keep_connection_open = FALSE;
      }
    }
    free(value);
  }

  if(client_input.url != NULL)
    free(client_input.url);
  if(client_input.resolved_url != NULL)
    free(client_input.resolved_url);
  if(client_input.header != NULL)
    t_hash_destroy(client_input.header);

  if(client_input.body != NULL){
    int i;

    for (i = 0; client_input.body[i] != NULL; i++)
      free(client_input.body[i]);
  }

  return keep_connection_open;
}

/* handles the reading of input over the socket for RVP.
 */

struct input
get_input(int slave_socket){
  char *buf;
  char *field;
  struct input client_input = { 0 };
  int fd;

  fd = slave_socket;

  buf = read_record(slave_socket);
  if(buf != NULL){
    buf = realloc(buf, (strlen(buf) - 2) * sizeof(char));
    t_error(FALSE, "<%s", buf);
    
    field = get_field(buf, 1, "\040");
    if(field != NULL){

      /* Find the method */
      if(strcmp(field, "GET") == 0)
	client_input.method = METHOD_GET;
      else if (strcmp(field, "PUT") == 0)
	client_input.method = METHOD_PUT;
      else if (strcmp(field, "MKCOL") == 0)
	client_input.method = METHOD_MKCOL;
      else if (strcmp(field, "RMCOL") == 0)
	client_input.method = METHOD_RMCOL;
      else if (strcmp(field, "ACL") == 0)
	client_input.method = METHOD_ACL;
      else if (strcmp(field, "SUBSCRIBE") == 0)
	client_input.method = METHOD_SUBSCRIBE;
      else if (strcmp(field, "UNSUBSCRIBE") == 0)
	client_input.method = METHOD_UNSUBSCRIBE;
      else if (strcmp(field, "NOTIFY") == 0)
	client_input.method = METHOD_NOTIFY;
      else
	client_input.rvp_return = RVP_NOT_IMPLIMENTED; 

      free(field);
    } else {
      free(buf);
      client_input.rvp_return = RVP_BAD_REQUEST;
      return client_input;
    }
      
    /* Get URL */
    client_input.url = get_field(buf, 2, "\040");

    if(client_input.url == NULL)
      client_input.rvp_return = RVP_BAD_REQUEST;

    /* Get RVP version */
    {
      char *fielda, *fieldb;

      field = get_field(buf, 3, NULL);
      fielda = get_field(field, 1, "/");
      fieldb = get_field(field, 3, "/");

      if(field != NULL && strcmp(fielda, "RVP") == 0 && fieldb == NULL){
	free(fielda);
	client_input.rvp_version = atof(get_field(field, 2, "/"));
      }else{
	free(fielda);
	if(fieldb != NULL)
	  free(fieldb);
	client_input.rvp_return = RVP_BAD_REQUEST;
      }
    }

    if (get_field(buf, 4, NULL) != NULL)
      client_input.rvp_return = RVP_BAD_REQUEST;

  }

  if(client_input.rvp_return == RVP_BAD_REQUEST)
    return client_input;

  /*
   * Read in header 
   */

  client_input.header = t_hash_create();

  free (buf);
  buf = read_record(slave_socket);
  {
    char *value = NULL;
    char *key;

    while (strcmp(buf, "\r\n") != 0){
  
      if (buf != NULL){
	t_error(FALSE, "<%s", buf);

	/* If we don't have a continuing field... ie
	 * To: foo@bar.com, gee@whiz.com,
	 *   blue@cow.net
	 * ...in which the continuing line meets the 
	 * pattern CRLF 1*(SP|HT)
	 */

	if((index(buf, ' ') - buf) != 0 && index(buf, '\t') - buf != 0){

	  /**
	   ** Also need to parse the `attributes' (or whatever they're
	   ** called) like `Content-type: text/xml; charset="utf-8"'
	   ** and put the key/value pair charset/utf-8 into the
	   ** atts Hashtab for Content-type.
	   **/

	  if(value != NULL){
	    t_error(FALSE, "hash_put.key=%s", key);
	    t_error(FALSE, "hash_put.value=\"%s\"", value);
	    t_hash_put(client_input.header, key, value);
	    free(value);
	    free(key);
	  }

	  key = get_field(buf, 1, ":");
	  t_tolower(key);
	  value = index(buf, ':');
	  if(value != NULL && key != NULL){
	    asprintf(&value, "%s", (char *) (value + 1));
	    value[strlen(value) - 2] = '\0';
	  }else{
	    if(strcmp(buf, "\r\n") != 0){
	      client_input.rvp_return = RVP_BAD_REQUEST;
	      if(key != NULL)
		free(key);
	      if(value != NULL)
		free(value);
	      free(buf);
	      return client_input;
	    }
	  }
	  
	}else{
	  asprintf(&value, "%s%s", value, buf);
	  value[strlen(value) - 2] = '\0';
	}

	free(buf);
      }

      buf = read_record(slave_socket);
    }

    /* Put the final value into the hashtable.
     */
    t_error(FALSE, "hash_put.key=\"%s\"", key);
    t_error(FALSE, "hash_put.value=\"%s\"", value);
    t_hash_put(client_input.header, key, value);
    free(value);
    free(key);
    free(buf);
  }


  /*
   * Read in body 
   */

  /* Don't need to wory about utf-16 and the like as this is an
   * 8-bit clean protocol.
   */

  {
    int content_lines_count = 1;
    int content_length_count = 0;
    int content_length;
    char *c_length = t_hash_get(client_input.header, "content-length");
    int num_wchars;

    if(c_length == NULL){
      client_input.rvp_return = RVP_BAD_REQUEST;
      return client_input;
    }else
      content_length = atoi(c_length);

    t_error(FALSE, "content-length = %d", content_length);
    client_input.body = NULL;

    do{
      buf = read_record(slave_socket);
      content_length_count += strlen(buf);

      client_input.body = realloc(client_input.body, content_lines_count *
				  sizeof(int));

      /* With UTF-8 the maximun possible number of wchars needed will be
       * the same as the number of bytes read in.
       */
      client_input.body[content_lines_count - 1] = 
	malloc(strlen(buf) * sizeof(wchar_t));

      num_wchars = mbstowcs(client_input.body[content_lines_count - 1], buf, 
			    strlen(buf));

      /* To save memory we now realloc this line down to the size
       * actually required.
       */
      client_input.body[content_lines_count - 1] = 
	realloc(client_input.body[content_lines_count - 1], num_wchars *
		sizeof(wchar_t));

      content_lines_count++;
      t_error(FALSE, "<%s", buf);
      free(buf);
      /**
       ** Need to set a timeout incase the client sends too little
       ** data or if we have a bad link.
       **/
    }while(content_length_count < content_length);

    if (content_length_count > content_length)
      client_input.rvp_return = RVP_BAD_REQUEST;

    client_input.body = realloc(client_input.body, content_lines_count *
				sizeof(int));
    client_input.body[content_lines_count - 1 ] = NULL;

    free(c_length);
  }
  free(buf);

  return client_input;
}
