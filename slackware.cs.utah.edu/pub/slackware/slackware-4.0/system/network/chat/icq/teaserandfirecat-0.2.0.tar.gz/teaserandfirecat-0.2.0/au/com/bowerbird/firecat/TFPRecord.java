/*    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package au.com.bowerbird.firecat;

import java.lang.*;
import java.io.*;

/**
 * Handles the writing and reading of strings to the socket.
 *
 * @author Matthew Parry <a href="mailto:mettw@bowerbird.com.au">mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class TFPRecord {
  InputStream istream;
  OutputStream ostream;

  /**
   * Constructor method.
   *
   * @param iarg input stream for the socket
   * @param oarg output stream for the socket
   */

  TFPRecord(InputStream iarg, OutputStream oarg){
    istream = iarg;
    ostream = oarg;
  }

  /**
   * Read in a string up to a newline character from Socket.
   *
   * @return String read from the socket.
   */

  public String GetRecord(){
    StringBuffer ibuffer = new StringBuffer();
    char c;

    do{
      try{ c = (char) istream.read();}
      catch(IOException ioe){
	System.out.println(ioe.getMessage());
	return "NULL";
      }
      ibuffer.append(c);
    }while(ibuffer.charAt(ibuffer.length() - 1) != '\n');
    
    return ibuffer.toString();
  }

  /**
   * Write a record to the output stream
   *
   * @param ostring The string to be written to the output stream.
   */

  public void PutRecord(String ostring){
    int i;

    for(i=0;i < ostring.length(); i++){
	try{ostream.write(ostring.charAt(i));}
      catch(IOException ioe){
	  System.out.println(ioe.getMessage());
	return;
      }
    }

    try{ostream.write(10);}
    catch(IOException ioe){
      System.out.println(ioe.getMessage());
      return;
    }

    return;
  }

  /**
   * Get a field from the record passed to the method.
   *
   * This is very inefficient, but it was easier to write
   * it this way.
   *
   * @param istring The record to parse
   * @param field The field to return
   * @exception TFPEndOfRecordException Thrown when the specified field doesn't exist.
   */

  public String GetField(String istring, int field) throws TFPEndOfRecordException {
    int i = 1, ii=0;
    char c = 'a'; //to stop the compiler complaining
    StringBuffer sb = new StringBuffer();

    // Skip forward untill we get to the desired field.
    while(i < field){
      try{c = istring.charAt(ii);}
      catch(StringIndexOutOfBoundsException e){
	throw new TFPEndOfRecordException();
      }

      // if it is non-whitespace then we've found the end of the field
      if(c < '\u0021' || c > '\u007E'){
	i++;

	// skip forward past the white space to the next field
	do{
	  ii++;
	  try{c = istring.charAt(ii);}
	  catch(StringIndexOutOfBoundsException e){
	    throw new TFPEndOfRecordException();
	  }
	}while(c < '\u0021' || c > '\u007E');
      }else{
	ii++;
      }
    }

    /* the previous section of code reads in the first character
     * of the field, but that code isn't run if the first field
     * is requested so we need to read in the first character
     * here.
     */
    if(i == 1){
      try{c = istring.charAt(ii);}
      catch(StringIndexOutOfBoundsException e){
	throw new TFPEndOfRecordException();
      }
    }

    // Read in the rest of the field.
    do{
      sb.append(c);
      ii++;
      try{c = istring.charAt(ii);}
      catch(StringIndexOutOfBoundsException e){}
    }while(ii < istring.length() && c > '\u0020' && c < '\u007F');
 
    return sb.toString();
  }
}

