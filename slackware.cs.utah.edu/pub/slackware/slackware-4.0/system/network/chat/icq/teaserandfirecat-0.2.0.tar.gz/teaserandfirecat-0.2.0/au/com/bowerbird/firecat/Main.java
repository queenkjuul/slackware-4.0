/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


package au.com.bowerbird.firecat;

import java.lang.*;
import java.util.*;
import java.io.*;


/**
 * A Client for the Teaser and Firecat System.
 *
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class Main {
  public static UserStatus user_status; 
  public static Hashtable contact_status = new Hashtable(); 
  public static FirecatGUI fgui = new FirecatGUI(); 
  public static Properties props = new Properties(); 
  public static int port = 7174;

  public static void main (String[] args) {
    int i;
    Integer num_contacts;

    /* load the properties from the file $HOME/firecat_properties 
     */
    try{
      props.load(new BufferedInputStream(new FileInputStream(System.getProperty("user.home") + System.getProperty("file.separator") + "firecat.rc")));

      /* fork a thread to listen on a port for ststus updates.
       */

      new UpdstatSocket().start();

      /* load the user's properties into his UserStatus Object 
       */
      user_status = new UserStatus(true, port, 
				   props.getProperty("firecat.tfa"), "ONLINE", 
				   props.getProperty("firecat.password"), 
				   props.getProperty("firecat.host"),
				   props.getProperty("firecat.tfa"));
    }
    catch(FileNotFoundException e){
      /* If there is no firecat.rc file then fill user_status with
       * some meaningless, temporary fillers.
       */
      props.put("firecat.tfa", "nobody");
      props.put("firecat.password", "nothing");
      props.put("firecat.host", "nowhere");
      props.put("firecat.contacts.num", "0");
      user_status = new UserStatus(true, port, 
				   props.getProperty("firecat.tfa"), 
				   "OFFLINE", 
				   props.getProperty("firecat.password"), 
				   props.getProperty("firecat.host"),
				   props.getProperty("firecat.password"));
    }
    catch(IOException eio){
      System.out.println("IOException: " + eio.getMessage());
      System.exit(0);
    }

    // Don't attempt this if there was no firecat.rc
    if(!((String) props.getProperty("firecat.host")).equalsIgnoreCase("nowhere")){
      /* tell our firecat about our status change 
       */
      try{ new TFPupdateStatus(user_status);}
      catch(Exception e){
	System.out.println("TFPUpdateStatus: " + e.getMessage());
	System.exit(0);
      }
    }

    /* get the number of contacts from the properties file 
     */
    num_contacts = new Integer(props.getProperty("firecat.contacts.num"));

    /* create a new UserStatus Object for each contact and then
     * ask our teaser what thier status is.
     */
    for(i = 0; i < num_contacts.intValue(); i++){
      contact_status.put(props.getProperty("firecat.contacts." 
					   + num_contacts.toString(i+1)),
			 new UserStatus(true, 
					props.getProperty("firecat.password"),
					user_status.getPort(),
					props.getProperty("firecat.tfa"),
					props.getProperty("firecat.host"),
					props.getProperty("firecat.contacts." 
							  + num_contacts.toString(i+1))));

      /* get the status of the contact
       */
      try{new TFPgetStatus((UserStatus) contact_status.get(props.getProperty("firecat.contacts." + num_contacts.toString(i+1))));}
      catch(Exception e){
	System.out.println("TFPgetStatus: " + e.getMessage());
      }
    }

    fgui.show();

  }

  /**
   * run when firecat.rc couldn't be found.
   *
   * gets some user info and then registers the user.
   *
   * @param isnewacc true if a new account is being registered, false if an existing one is being updated.
   */

  public static void registerUser(boolean isnewacc){
    
    /* load the user's properties into his UserStatus Object 
     */

    user_status = new UserStatus(true, user_status.getPort(), props.getProperty("firecat.tfa"),
				 "ONLINE", 
				 props.getProperty("firecat.password"), 
				 props.getProperty("firecat.host"),
				 props.getProperty("firecat.password"));

    if(isnewacc){
      // We don't have any contacts yet.
      props.put("firecat.contacts.num", "0");
      //         vvvvvvvv
      try{new TFPRegisterUser(user_status, props.getProperty("firecat.email"),
			      props.getProperty("firecat.url"),
			      props.getProperty("firecat.uname"));}
      catch(Exception e){
	System.out.println(e.getMessage());
	System.exit(1);
      }
    }else{
      //         vvvvvv
      try{new TFPUpdateUser(user_status, props.getProperty("firecat.email"),
			      props.getProperty("firecat.url"),
			      props.getProperty("firecat.uname"));}
      catch(Exception e){
	System.out.println(e.getMessage());
	System.exit(1);
      }
    }
  }

  /**
   * Set status to OFFLINE and save properties to file.
   */

  public static void exit(){

    user_status.setStatus("OFFLINE");
    try{new TFPupdateStatus(user_status);}
    catch(Exception e){
      System.out.println(e.getMessage());
    }

    try{
      props.save(
		 new BufferedOutputStream(
					  new FileOutputStream(
							       System.getProperty("user.home") + System.getProperty("file.separator") + "firecat.rc",
							       false),
					  1), 
		 "# Firecat properties");
    }
    catch(Exception e){
      System.out.println(e.getMessage());
    }

    System.exit(1);
  }
}


