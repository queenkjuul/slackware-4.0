/*
 * Teaser - A copyleft implimentation of RVP
 * Copyright (C) 1998, 1999 Matthew Parry <mettw@bowerbird.com.au
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Non-Consultants' License as published by
 * Bowerbird Computing; either version 1.2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Non-Consultants' License for more details.
 *
 * You should have received a copy of the Non-Consultants' License
 * along with this program; if not, write to Bowerbird Computing,
 * PO Box 247, Nowra NSW, Australia, 2541.
 */


#include <teaser.h>
#include <time.h>

void
rvp_error(int socket, int response){

  switch(response){
  case RVP_SUBSCRIBE:
    write(socket, "RVP/1.1 207 SUBSCRIBE\r\n", 
	  strlen("RVP/1.1 207 SUBSCRIBE\r\n"));
    t_error(FALSE, ">RVP/1.1 207 SUBSCRIBE");
    break;
  case RVP_REFER:
    write(socket, "RVP/1.1 ??? REFER\r\n", 
	  strlen("RVP/1.1 ??? REFER\r\n"));
    t_error(FALSE, ">RVP/1.1 ??? REFER");
    break;
  case RVP_BAD_REQUEST:
    write(socket, "RVP/1.1 400 BAD REQUEST\r\n", 
	  strlen("RVP/1.1 400 BAD REQUEST\r\n"));
    t_error(FALSE, ">RVP/1.1 400 BAD REQUEST");
    break;
  case RVP_UNAUTHORIZED:
    write(socket, "RVP/1.1 401 UNAUTHORIZED\r\n", 
	  strlen("RVP/1.1 401 UNAUTHORIZED\r\n"));
    t_error(FALSE, ">RVP/1.1 401 UNAUTHORIZED");
    break;
  case RVP_FORBIDDEN:
    write(socket, "RVP/1.1 402 FORBIDDEN\r\n", 
	  strlen("RVP/1.1 402 FORBIDDEN\r\n"));
    t_error(FALSE, ">RVP/1.1 402 FORBIDDEN");
    break;
  case RVP_NOT_FOUND:
    write(socket, "RVP/1.1 404 NOT FOUND\r\n", 
	  strlen("RVP/1.1 404 NOT FOUND\r\n"));
    t_error(FALSE, ">RVP/1.1 404 NOT FOUND");
    break;
  case RVP_SERVICE_UNAVAILABLE:
    write(socket, "RVP/1.1 503 SERVICE UNAVAILABLE\r\n", 
	  strlen("RVP/1.1 503 SERVICE UNAVAILABLE\r\n"));
    t_error(FALSE, ">RVP/1.1 503 SERVICE UNAVAILABLE");
    break;
  default: /* RVP_NOT_IMPLIMENTED */
    write(socket, "RVP/1.1 501 NOT IMPLIMENTED\r\n", 
	  strlen("RVP/1.1 501 NOT IMPLIMENTED\r\n"));
    t_error(FALSE, ">RVP/1.1 501 NOT IMPLIMENTED");
  }
}
