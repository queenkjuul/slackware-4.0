/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <teaser.h>

PGconn *pg_conn;

void
newacc(struct client_info slave_socket, struct input client_input){
  PGresult *result;
  char *pgexec;

  /* Open a connection to the database */
  pg_conn = PQsetdb("localhost", NULL, NULL, NULL, "teaserdb");
  /* check it opened OK */
  if(PQstatus(pg_conn) == CONNECTION_BAD){
	t_error(PQerrorMessage(pg_conn), TRUE);
  }


  /* check if the user already exists */
  pgexec = malloc((strlen("SELECT password FROM Auth WHERE tfa = '") +
		   strlen(client_input.tfa) + strlen("';")+1) *
		  sizeof(char));
  strcpy(pgexec, "SELECT password FROM Auth WHERE tfa = '");
  strcat(pgexec, client_input.tfa);
  strcat(pgexec, "';");

  t_error(pgexec, FALSE);
  result = db_exec(pg_conn, pgexec);

  if(result == NULL){
    tfp_error(slave_socket.socket, 402);
    t_error(PQerrorMessage(pg_conn), FALSE);
    free(pgexec);
    PQfinish(pg_conn);
    return;
  }

  if(PQresultStatus(result) == PGRES_TUPLES_OK && PQntuples(result) == 1){
    /* there is an entry for this user */
    tfp_error(slave_socket.socket, 300);
    t_error(PQerrorMessage(pg_conn), FALSE);
    
    free(pgexec);
    PQfinish(pg_conn);
    return;
  }else{

    
    free(pgexec);

    /* update the user status */
    pgexec = malloc((strlen("INSERT INTO Status VALUES ('") +
		     strlen(client_input.tfa) +
		     strlen("', 'OFFLINE', '{}');")+1) * sizeof(char));
    strcpy(pgexec, "INSERT INTO Status VALUES ('");
    strcat(pgexec, client_input.tfa);
    strcat(pgexec, "', 'OFFLINE', '{}');");

    t_error(pgexec, FALSE);
    result = db_exec(pg_conn, pgexec);
    
    if(result == NULL){
      tfp_error(slave_socket.socket, 402);
      t_error(PQerrorMessage(pg_conn), FALSE);
      free(pgexec);
      PQfinish(pg_conn);
      return;
    }
    
    free(pgexec);

    /* update the user status */
    pgexec = malloc((strlen("INSERT INTO Url VALUES ('") +
		     strlen(client_input.tfa) +
		     strlen("', '{\"smtp\", \"http\", \"uname\"}', '{{\"") + 
		     strlen(client_input.email) +
		     strlen("\"}, {\"") +
		     strlen(client_input.url) +
		     strlen("\"}, {\"") +
		     strlen(client_input.uname) +
		     strlen("\"}}', '{{}}');")+1) * sizeof(char));
    strcpy(pgexec, "INSERT INTO Url VALUES ('");
    strcat(pgexec, client_input.tfa);
    strcat(pgexec, "', '{\"smtp\", \"http\", \"uname\"}', '{{\"");
    strcat(pgexec, client_input.email);
    strcat(pgexec, "\"}, {\"");
    strcat(pgexec, client_input.url);
    strcat(pgexec, "\"}, {\"");
    strcat(pgexec, client_input.uname);
    strcat(pgexec, "\"}}', '{{}}');");

    t_error(pgexec, FALSE);
    result = db_exec(pg_conn, pgexec);
    
    if(result == NULL){
      tfp_error(slave_socket.socket, 402);
      t_error(PQerrorMessage(pg_conn), FALSE);
      free(pgexec);
      PQfinish(pg_conn);
      return;
    }
    
    free(pgexec);

    /* update the user status */
    pgexec = malloc((strlen("INSERT INTO Auth VALUES ('") +
		     strlen(client_input.tfa) +
		     strlen("', 0, '', '") + 
		     strlen(client_input.password) +
		     strlen("', '');")+1) * sizeof(char));
    strcpy(pgexec, "INSERT INTO Auth VALUES ('");
    strcat(pgexec, client_input.tfa);
    strcat(pgexec, "', 0, '', '");
    strcat(pgexec, client_input.password);
    strcat(pgexec, "', '');");

    t_error(pgexec, FALSE);
    result = db_exec(pg_conn, pgexec);
    
    if(result == NULL){
      tfp_error(slave_socket.socket, 402);
      t_error(PQerrorMessage(pg_conn), FALSE);
      free(pgexec);
      PQfinish(pg_conn);
      return;
    }
    
    write(slave_socket.socket, "OK\n", strlen("OK\n"));
  }

  
  free(pgexec);
  PQfinish(pg_conn);
}

