/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <tfp.h>
#include <sys/file.h>

struct input get_input_1(int);
int negotiate_tfp_version(int);

int fd;

/* Handles all TFP communication for the teaser or firecat (server part).
 */

void
handle_connection(struct client_info slave_socket, db_functions *dbfuncts){
  int tfp_version;
  struct input client_input = { 0 };
  
  fd = slave_socket.socket;

  tfp_version = negotiate_tfp_version(fd);

  switch(tfp_version){
  case 0: /* we got a nonsense TFP version */
    tfp_error(slave_socket.socket, 102);
    break;
  case 1: /* TFP 1.3 */
    client_input = get_input_1(slave_socket.socket);
    if(client_input.connect_reason == -1){
      tfp_error(slave_socket.socket, 101);
    }else
      dbfuncts[client_input.connect_reason](slave_socket, client_input);
    break;
  case 2: /* TFP 2.0 */
    tfp_error(slave_socket.socket, 102);
    break;
  default: /* we didn't get any TFP input */
    tfp_error(slave_socket.socket, 100);
    break;
  }
  
  close(slave_socket.socket);
}

/* Works out which TFP version of TFP should be used over
 * the connection.
 */

int
negotiate_tfp_version(int slave_socket){
  char *input_buf;
  char *field;
  double tfp_version;

  do{
    input_buf = read_record(slave_socket);

    if(input_buf == NULL)
      return -1;
    field = get_field(input_buf, 1, NULL);

    if(field != NULL){
      if(0 == strcmp(field, "TFP")){
	tfp_version = strtod(get_field(input_buf, 2, NULL), (char **)NULL);
	
	if(tfp_version == 1.3){
	  write(slave_socket, "TFP 1.3\n", 8);
	  free(input_buf);
	  free(field);
	  return 1;
	}else if(tfp_version == 2.0){ 
	  write(slave_socket, "TFP 2.0\n", 8);
	  free(input_buf);
	  free(field);
	  return 2;
	}else if(tfp_version > 2.0){ 
	  write(slave_socket, "TFP 1.3\n", 8);
	  tfp_version = negotiate_tfp_version(slave_socket);
	  free(input_buf);
	  free(field);
	  return tfp_version;
	}else{/* a nonsense TFP version */
	  free(input_buf);
	  free(field);
	  return 0;
	}
      }

      /* else we're not recieving TFP input */
      free(input_buf);
      free(field);
      return -1;
    }
  }while(field == NULL);
}

