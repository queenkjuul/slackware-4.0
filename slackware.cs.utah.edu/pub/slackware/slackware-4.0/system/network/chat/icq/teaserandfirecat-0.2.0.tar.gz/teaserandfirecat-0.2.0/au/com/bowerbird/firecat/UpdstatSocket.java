/*    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package au.com.bowerbird.firecat;

import java.lang.*;
import java.net.*;
import java.io.*;

/**
 * Listens for connections from the Teaser about status updates.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * @since beta-i
 */

public class UpdstatSocket extends Thread {
    ServerSocket ss;

    /**
     * Open a TFP connection, determine what we are talking to and
     * then call either HandleTeaser or HandleFirecat.
     */

    public void run (){
	String requestor_type;
	Socket socket;
    
	try{ss = new ServerSocket(7174);}
	catch(IOException e){
	    System.out.println(e.getMessage());
	    return;
	}

    listen: while (true) {
	try {socket = ss.accept();}
	catch(IOException e){
	    System.out.println(e.getMessage());
	    continue listen;
	}
	try{HandleConnection(socket.getInputStream(), 
			     socket.getOutputStream());}
	catch(Exception ee){
	    System.out.println(ee.getMessage());
	}
	try{socket.close();}
	catch(Exception ee){
	    System.out.println(ee.getMessage());
	}
	    
    }
    }

    void HandleConnection(InputStream istream, OutputStream ostream){
	String buf = new String();
	String tfa = new String();
	String status = new String();
	TFPRecord tfpr = new TFPRecord(istream, ostream); ;
	UserStatus us;
	
	buf = tfpr.GetRecord();

	if((buf.trim()).equalsIgnoreCase("TFP 1.3")){
	    tfpr.PutRecord("TFP 1.3");
	    buf = tfpr.GetRecord();
	    try{tfa = tfpr.GetField(buf, 2);}
	    catch(Exception e){
		System.out.println(e.getMessage());
		return;
	    }
	    buf = tfpr.GetRecord();
	    status = buf.trim();

	    us = (UserStatus) Main.contact_status.get(tfa);
	    us.setStatus(status);
	    Main.fgui.setContactStatus(us);
	}

	return;
    }

}
