/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <tfp.h>

int get_hostname(struct port*);
int bind_port(struct port*);

/* Opens a socket on the local machine
 */

int
open_server_socket (struct port *port){

  /* open a TCP socket
   */

  port->server_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

  if(port->server_socket == -1){
    t_error("Couldn't get socket", FALSE);
    return 1;
  }

  /* turn off bind address checking so we don't have to wait for
   * TIME_WAIT to timeout the port.
   */
  {
    boolean reuse_addr = TRUE;

    if(setsockopt(port->server_socket, SOL_SOCKET, SO_REUSEADDR,
		  (const char *) &reuse_addr, sizeof(reuse_addr)) == -1)
      t_error("couldn't set SO_REUSEADDR", FALSE);
    
  }

  /* all of the connections are short so we shouldn't have
   * to linger on the port after the connection has been closed.
   */
  {
    struct linger linger = { 0 };

    linger.l_onoff = 0;
    
    if(setsockopt(port->server_socket, SOL_SOCKET, SO_LINGER, 
		  (const char *) &linger, sizeof(linger)) == -1)
      t_error("couldn't turn off lingering", FALSE);

  }

  /* Find out what the hostname of this machine is.
   */
  
  if(get_hostname(port))
    return 1;

  /* Now bind the hostname and port to our socket
   */
  if(bind_port(port))
    return 1;

  return 0;
}


/* Get the host name and then the FQDN via gethostbyname().
 * We don't use gethostname() because this is apparently
 * unsupported or deprecated on some unices.
 */

int
get_hostname(struct port *port){
  struct utsname system_name = { 0 };

  /* set hostname
   */
  if(uname(&system_name) != -1)
    (void) strncpy(port->hostname, system_name.nodename,
		   sizeof(port->hostname));
  else{
    t_error("couldn't determine hostname", FALSE);
    return 1;
  }

  port->host_ptr = gethostbyname(port->hostname);

  /* This should only happen on my own (dialup) box while I'm
   * testing teaser.
   */

  if(port->host_ptr == NULL){
    t_error("Couldn't determine FQDN, using hostname instead", FALSE);
    port->host_ptr->h_name = port->hostname;
    port->host_ptr->h_aliases = NULL;
    /*    port->host_ptr->h_addrtype = BAF_INETP;*/
    port->host_ptr->h_length = sizeof(port->hostname);
    port->host_ptr->h_addr_list = malloc(2*sizeof(int));
    port->host_ptr->h_addr_list[0] = port->hostname;
    port->host_ptr->h_addr_list[1] = NULL;
    port->host_ptr->h_addr = port->hostname;
  }

  (void) memset(&port->server_name, 0, sizeof(port->server_name));
  (void) memcpy(&port->server_name.sin_addr, port->host_ptr->h_addr,
		port->host_ptr->h_length);

  return 0;
}


/* Bind the socket to a particular port
 */

int
bind_port(struct port *port){

  port->server_name.sin_family = AF_INET;
  port->server_name.sin_port = htons(port->port_num);
  if(-1 == bind(port->server_socket, (struct sockaddr *) &port->server_name,
		sizeof(port->server_name)))
    return 1;

  return 0;
}
