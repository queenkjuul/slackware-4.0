/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


package au.com.bowerbird.firecat;

import java.lang.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

/**
 * ItemListener for the status Choice widget.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class StatusItemListener implements ItemListener {
  public void itemStateChanged (ItemEvent ie) {
    Object o = new Object();
    o = ie.getItem();
    String ie_command = new String(o.toString());
    
    if(ie_command.equalsIgnoreCase("Online"))
      Main.user_status.setStatus("ONLINE");
    else if(ie_command.equalsIgnoreCase("Offline"))
      Main.user_status.setStatus("OFFLINE");
    else if(ie_command.equalsIgnoreCase("Busy"))
      Main.user_status.setStatus("BUSY");
    else if(ie_command.equalsIgnoreCase("Back in five"))
      Main.user_status.setStatus("BACKINFIVE");

    try{new TFPupdateStatus(Main.user_status);}
    catch(Exception e){
      System.out.println(e.getMessage());
      System.exit(0);
    }
  }
}
