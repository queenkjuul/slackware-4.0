/*
 * Teaser - A copyleft implimentation of RVP
 * Copyright (C) 1998, 1999 Matthew Parry <mettw@bowerbird.com.au
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Non-Consultants' License as published by
 * Bowerbird Computing; either version 1.2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Non-Consultants' License for more details.
 *
 * You should have received a copy of the Non-Consultants' License
 * along with this program; if not, write to Bowerbird Computing,
 * PO Box 247, Nowra NSW, Australia, 2541.
 */

#ifndef _TEASER_H_
#define _TEASER_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/utsname.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <signal.h>
#include <t_hashtable.h>

#define _XOPEN_SOURCE
#include <unistd.h>

typedef int boolean;
#define TRUE 1
#define FALSE 0

#define BACK_LOG 5 /* This is probably overly conservative */

#define METHOD_GET         0
#define METHOD_PUT         1
#define METHOD_MKCOL       2
#define METHOD_RMCOL       3
#define METHOD_ACL         4
#define METHOD_SUBSCRIBE   5
#define METHOD_UNSUBSCRIBE 6
#define METHOD_NOTIFY      7

/* Responses */

#define RVP_SUBSCRIBE            207
#define RVP_REFER                -1
#define RVP_BAD_REQUEST          400
#define RVP_UNAUTHORIZED         401
#define RVP_FORBIDDEN            402
#define RVP_NOT_FOUND            404
#define RVP_NOT_IMPLIMENTED      501
#define RVP_SERVICE_UNAVAILABLE  503

struct client_info{
  struct sockaddr_in client_name;
  int socket;
  int client_length;
};

struct input{
  int method;
  int rvp_return;
  char *url;
  char *resolved_url;
  double rvp_version;
  Hashtab *header;
  wchar_t **body;
};

struct port {
  int port_num;
  char hostname[80];
  int server_socket;
  struct hostent *host_ptr;
  struct sockaddr_in server_name;
};

#define CONF_FILE "/etc/teaser/rvp-conf.scm"
#define RC_FILE "/etc/teaser/teaserrc.scm"

int logfd;
struct port port;
char *pid_file;

char* read_record(int);
char* get_field(char*, int, char*);
void t_tolower(char*);
void rvp_error(int, int);
void t_error(boolean, char *, ...);
struct input default_url_resolver(struct input);
struct input default_method_processor(struct input);

#endif
