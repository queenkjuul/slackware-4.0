/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


package au.com.bowerbird.firecat;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import au.com.bowerbird.TFP.*;

/**
 * The GUI interface for Firecat.
 *
 * The default constructor is used.  Call show() to get the
 * GUI.
 *
 * @author Matthew Parry <a href=mailto:mettw@bowerbird.com.au>mettw@bowerbird.com.au</a>
 * @since alpha-i
 */

public class FirecatGUI {
  Choice status_widget = new Choice(); //choose what your status is
  Frame main_window = new Frame("Firecat");
  MenuBar menubar_widget = new MenuBar();
  Menu menu_widget = new Menu("File", /*tearoff*/ false);
  FileActionListener fal = new FileActionListener();
  Panel contacts_panel = new Panel();// panel to hold all contact panels.
  Panel online_contacts = new Panel();// online contacts,
  Panel offline_contacts = new Panel();//and so on...
  Panel busy_contacts = new Panel();
  Panel backinfive_contacts = new Panel();
  Label online_label = new Label("Online");   //says that the contacts
  Label offline_label = new Label("Offline"); //listed below are
  Label busy_label = new Label("Busy");       // online/offline/...
  Label backinfive_label = new Label("Back in five");
  StatusItemListener sil = new StatusItemListener();

  /**
   * Creates the GUI.
   */

  public void show() {
    Enumeration hasht;

    /* The "File" menu at the top of the Frame 
     */
    menu_widget.add(new MenuItem("Identity")); // change email, url, etc
    menu_widget.add(new MenuItem("Add Contact"));
    menu_widget.add(new MenuItem("Delete Contact"));
    menu_widget.add(new MenuItem("Exit"));
    menu_widget.addActionListener(fal);
    menubar_widget.add(menu_widget);

    main_window.setMenuBar(menubar_widget);
    main_window.setLayout(new BorderLayout());

    main_window.add("Center", contacts_panel);
    contacts_panel.setLayout(new GridLayout(4,1));
    contacts_panel.add(online_contacts);
    contacts_panel.add(offline_contacts);
    contacts_panel.add(busy_contacts);
    contacts_panel.add(backinfive_contacts);
    main_window.add("South", status_widget);

    online_contacts.setLayout(new GridLayout(1,1));
    online_contacts.add(online_label);
    offline_contacts.setLayout(new GridLayout(1,1));
    offline_contacts.add(offline_label);
    busy_contacts.setLayout(new GridLayout(1,1));
    busy_contacts.add(busy_label);
    backinfive_contacts.setLayout(new GridLayout(1,1));
    backinfive_contacts.add(backinfive_label);

    // Add a button for each contact
    hasht = Main.contact_status.elements();
    while(hasht.hasMoreElements()){
      addContact((UserStatus) hasht.nextElement());
    }

    status_widget.addItem("Online");
    status_widget.addItem("Offline");
    status_widget.addItem("Busy");
    status_widget.addItem("Back in five");
    // If there is no firecat.rc file then we start off as OFFLINE
    if(((String) Main.user_status.getStatus()).equalsIgnoreCase("OFFLINE")){
      status_widget.select("Offline");
      getIdentity(true);
    }
    status_widget.addItemListener(sil);
 
    main_window.pack();
    main_window.show();
  }

  /**
   * add a contact to the GUI.
   *
   * This does not call pack() as this shouldn't be done when our
   * contacts are added on startup.
   *
   * @param us UserStatus of contact to add
   */

  public  void addContact(UserStatus us){

    if((us.getStatus()).equalsIgnoreCase("ONLINE")){
      online_contacts.setLayout(new GridLayout(online_contacts.getComponentCount() + 1, 1));
      online_contacts.add(us.getButton());
    }else if((us.getStatus()).equalsIgnoreCase("OFFLINE")){
      offline_contacts.setLayout(new GridLayout(offline_contacts.getComponentCount() + 1, 1));
      offline_contacts.add(us.getButton());
    }else if((us.getStatus()).equalsIgnoreCase("BUSY")){
      busy_contacts.setLayout(new GridLayout(busy_contacts.getComponentCount() + 1, 1));
      busy_contacts.add(us.getButton());
    }else if((us.getStatus()).equalsIgnoreCase("BACKINFIVE")){
      backinfive_contacts.setLayout(new GridLayout(backinfive_contacts.getComponentCount() + 1, 1));
      backinfive_contacts.add(us.getButton());
    }
  }

  /**
   * Add a new contact to our list of contacts.
   * 
   * After getting the contact's TFA from the user, addContact(UserStatus)
   * is called and the main window is re-pack()ed
   */

  public void addContact(){
    final Frame foo = new Frame();
    Label tfa_label = new Label("TFA: ");
    final TextField tfa_tf = new TextField(20);
    Button ok_b = new Button("OK");
    final Integer i = new Integer(Main.props.getProperty("firecat.contacts.num"));

    // Set up the child window to get the new contact's TFA from the user.
    foo.setLayout(new GridLayout(2,2));
    foo.add(tfa_label);
    foo.add(tfa_tf);
    foo.add(ok_b);

    ok_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	// Add the contact to firecat's properties.
	Main.props.put("firecat.contacts.num", i.toString(i.intValue() +1));
	Main.props.put("firecat.contacts." + i.toString(i.intValue() + 1),
		       tfa_tf.getText());

	// Add the contact to firecat's hash table of contacts
	Main.contact_status.put(tfa_tf.getText(), 
				new UserStatus(true, Main.props.getProperty("firecat.tfa"), Main.props.getProperty("firecat.host"), tfa_tf.getText()));
	try{
	  // Find the contact's status
	  new TFPgetStatus((UserStatus) 
			   Main.contact_status.get(tfa_tf.getText()));
	}
	catch(Exception ex){
	  System.out.println("Firecat: Exception: " + ex.getMessage());
	}
	// Now add the contact to the window.
	addContact((UserStatus) Main.contact_status.get(tfa_tf.getText()));
	main_window.pack();
	main_window.show();
	foo.dispose();    
      }
    });
    
    foo.pack();
    foo.show();
  }

  /**
   * Delete a contact.
   *
   * Sets up a dialog to get the contact's TFA.
   */

  public void deleteContact(){
    final Frame foo = new Frame();
    Label tfa_label = new Label("TFA: ");
    final TextField tfa_tf = new TextField(20);
    Button ok_b = new Button("OK");
    final Integer i = new Integer(Main.props.getProperty("firecat.contacts.num"));
    
    foo.setLayout(new GridLayout(2,2));
    foo.add(tfa_label);
    foo.add(tfa_tf);
    foo.add(ok_b);
    
    ok_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	int ii;
	
	/* Remove the button from the GUI.
	 *
	 * This isn't in a seperate method like addContact(UserStatus)
	 * as there isn't any reason this to be done from anywhere
	 * else.
	 */
	if((((UserStatus) Main.contact_status.get(tfa_tf.getText())).getStatus()).equalsIgnoreCase("ONLINE")){
	  online_contacts.setLayout(new GridLayout(online_contacts.getComponentCount() - 1, 1));
	  online_contacts.remove(((UserStatus) Main.contact_status.get(tfa_tf.getText())).getButton());
	}else if((((UserStatus) Main.contact_status.get(tfa_tf.getText())).getStatus()).equalsIgnoreCase("OFFLINE")){
	  offline_contacts.setLayout(new GridLayout(offline_contacts.getComponentCount() - 1, 1));
	  offline_contacts.remove(((UserStatus) Main.contact_status.get(tfa_tf.getText())).getButton());
	}else if((((UserStatus) Main.contact_status.get(tfa_tf.getText())).getStatus()).equalsIgnoreCase("BUSY")){
	  busy_contacts.setLayout(new GridLayout(busy_contacts.getComponentCount() - 1, 1));
	  busy_contacts.remove(((UserStatus) Main.contact_status.get(tfa_tf.getText())).getButton());
	}else if((((UserStatus) Main.contact_status.get(tfa_tf.getText())).getStatus()).equalsIgnoreCase("BACKINFIVE")){
	  backinfive_contacts.setLayout(new GridLayout(backinfive_contacts.getComponentCount() - 1, 1));
	  backinfive_contacts.remove(((UserStatus) Main.contact_status.get(tfa_tf.getText())).getButton());
	}
	
	main_window.pack();
	main_window.show();
	
	/* Delete to contact from the firecat properties and
	 * rename the other contacts' keys appropriately.
	 */
	for(ii = 1; ii <= i.intValue(); ii++){
	  // Scan through till we find the contact to delete
	  if(((String) Main.props.get("firecat.contacts." + i.toString(ii))).equalsIgnoreCase(tfa_tf.getText())){
	    /* now move each contact down one: ie, firecat.contacts.5
	     * becomes firecat.contacts.4 and so on, overwriting the
	     * contact to be deleted in the process.
	     */
	    for(; ii <= i.intValue(); ii++){
	      if(ii != i.intValue())
		Main.props.put("firecat.contacts." + i.toString(ii),
			       Main.props.get("firecat.contacts." + 
					      i.toString(ii+1)));
	    }
	  }
	}
	/* The last contact has been copied to the previous
	 * firecat.contacts.xx so delete it.
	 */
	Main.props.remove("firecat.contacts." + i.toString());
	Main.props.put("firecat.contacts.num", i.toString(i.intValue() -1));

	// remove the contact from our hash table of UserStatus objects.
	Main.contact_status.remove(tfa_tf.getText());

	foo.dispose();    
      }
    });
    
    foo.pack();
    foo.show();
  }

  /**
   * Move a contact button from the old status widget to the new one.
   *
   * @param us UserStatus
   */

  public  void setContactStatus(UserStatus us){
    Panel old_panel = (Panel) (us.getButton()).getParent();
    int i = old_panel.getComponentCount();

    old_panel.remove(us.getButton());
    old_panel.setLayout(new GridLayout(i-1,1));

    if((us.getStatus()).equalsIgnoreCase("ONLINE")){
      i = busy_contacts.getComponentCount();
      online_contacts.add(us.getButton());
      busy_contacts.setLayout(new GridLayout(i+1,1));
    }else if((us.getStatus()).equalsIgnoreCase("OFFLINE")){
      i = busy_contacts.getComponentCount();
      offline_contacts.add(us.getButton());
      busy_contacts.setLayout(new GridLayout(i+1,1));
    }else if((us.getStatus()).equalsIgnoreCase("BUSY")){
      i = busy_contacts.getComponentCount();
      busy_contacts.add(us.getButton());
      busy_contacts.setLayout(new GridLayout(i+1,1));
    }else if((us.getStatus()).equalsIgnoreCase("BACKINFIVE")){
      i = busy_contacts.getComponentCount();
      backinfive_contacts.add(us.getButton());
      busy_contacts.setLayout(new GridLayout(i+1,1));
    }

    main_window.pack();
    main_window.show();
  }

  /**
   * Get the user's email etc.
   *
   * Sets up a dialog to get the info from the user.
   *
   * @param isnewacc true if the user doesn't have an account (ie doesn't have a firecat.rc)
   */

  public void getIdentity(final boolean isnewacc){
    final Frame foo = new Frame();
    Label tfa_label = new Label("TFA: ");
    Label email_label = new Label("Email: ");
    Label url_label = new Label("URL: ");
    Label passwd_label = new Label("Password: ");
    Label host_label = new Label("Host: ");
    final TextField tfa_tf = new TextField(20);
    final TextField email_tf = new TextField(20);
    final TextField url_tf = new TextField(20);
    final TextField passwd_tf = new TextField(20);
    final TextField host_tf = new TextField(20);
    Button ok_b = new Button("OK");

    /* If the user doesn't have an account then the properties either have
     * a null value or meaningless ones.
     */ 
    if(!isnewacc){
      tfa_tf.setText(Main.props.getProperty("firecat.tfa"));
      email_tf.setText(Main.props.getProperty("firecat.email"));
      url_tf.setText(Main.props.getProperty("firecat.url"));
      passwd_tf.setText(Main.props.getProperty("firecat.password"));
      host_tf.setText(Main.props.getProperty("firecat.host"));
    }

    foo.setLayout(new GridLayout(6,2));
    foo.add(tfa_label);
    foo.add(tfa_tf);
    foo.add(passwd_label);
    passwd_tf.setEchoChar('*');
    foo.add(passwd_tf);
    foo.add(host_label);
    foo.add(host_tf);
    foo.add(email_label);
    foo.add(email_tf);
    foo.add(url_label);
    foo.add(url_tf);
    foo.add(ok_b);

    ok_b.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
	Main.props.put("firecat.tfa", tfa_tf.getText());
	Main.props.put("firecat.password", passwd_tf.getText());
	Main.props.put("firecat.email", email_tf.getText());
	Main.props.put("firecat.url", url_tf.getText());
	Main.props.put("firecat.host", host_tf.getText());
	foo.dispose();
	// Register the user with the teaser.
	Main.registerUser(isnewacc);
      }
    });


    foo.pack();
    foo.show();
  }


}








