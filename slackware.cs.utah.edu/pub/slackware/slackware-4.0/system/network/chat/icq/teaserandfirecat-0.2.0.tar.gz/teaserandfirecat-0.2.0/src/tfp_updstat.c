/*
 * Teaser - an ICQ like server for the client `firecat'.
 * Copyright (C) 1998 Matthew Parry <mettw@bowerbird.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <teaser.h>
#include <signal.h>

int cget_hostname(struct port*);
int send_update(int, char*, char*);
int cnegotiate_tfp_version(int);

int fd;

/* Opens a connection to a server.
 */

int
tfp_updstat (char *host, char *port, char *ntfa, char *status){
  struct port client_port = { 0 };
  char *tfa;

  tfa = rindex(ntfa, '/');
  tfa++;
  index(tfa, '@')[0] = '#';

  if(port == NULL) /* We're contacting a teaser */
    client_port.port_num = 7173;
  else
    client_port.port_num = atoi(port); /* We're contacting a Firecat */

  strcpy(client_port.hostname, host);

  /* open a TCP socket
   */

  client_port.server_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

  if(client_port.server_socket == -1){
    t_error("Couldn't get socket", FALSE);
    return 1;
  }

  /* Find out what the hostname of this machine is.
   */
  
  if(cget_hostname(&client_port) == 1)
    return 1;

  /* Now connect to the port
   */
  t_error(client_port.hostname, FALSE);
  t_error(port, FALSE);
  t_error(tfa, FALSE);
  if(connect(client_port.server_socket, 
	     (struct sockaddr*) &client_port.server_name,
	     sizeof(client_port.server_name)) == -1){
    t_error("Couldn't connect to server\n", FALSE);
    return 1;
  }

  fd = client_port.server_socket;

  if(send_update(client_port.server_socket, tfa, status) == -1)
    return 1;

  return 0;
}


/* Get the host name and then the FQDN via gethostbyname().
 * We don't use gethostname() because this is apparently
 * unsupported or deprecated on some unices.
 */

int
cget_hostname(struct port *port){
  struct utsname system_name = { 0 };

  port->host_ptr = gethostbyname(port->hostname);

  /* This should only happen on my own (dialup) box while I'm
   * testing teaser.
   */

  if(port->host_ptr == NULL){
    port->host_ptr = gethostbyaddr(port->hostname, strlen(port->hostname),
				   AF_INET);
    if(port->host_ptr == NULL){
      t_error("Invalid hostname\n", FALSE);
      return 1;
    }
  }

  port->server_name.sin_family = AF_INET;
  port->server_name.sin_port = htons(port->port_num);
  (void) memcpy(&port->server_name.sin_addr, port->host_ptr->h_addr,
		port->host_ptr->h_length);

  return 0;
}

/* write the status update to the socket.
 */

int
send_update(int socket, char *tfa, char *status){
  char *buf;
  int tfp_version;

  tfp_version = cnegotiate_tfp_version(socket);

  switch(tfp_version){
  case 0: /* we got a nonsense TFP version */
    tfp_error(socket, 102);
    close(socket);
    return -1;
  case 1: /* TFP 1.3 */
    /* I really should have another function here, but this is
     * only beta stuff.
     */
    break;
  default: /* we didn't get any TFP input */
    tfp_error(socket, 100);
    close(socket);
    return -1;
  }

  /* move this into another function at some later stage so we can
   * handle different TFP versions.
   */

  buf = malloc((strlen("UPDSTAT \n") + strlen(tfa)+1)*sizeof(char));

  strcpy(buf, "UPDSTAT ");
  strcat(buf, tfa);
  strcat(buf, "\n");

  write(socket, buf, strlen(buf));
  write(socket, status, strlen(status));
  write(socket, "\n", 1);

  free(buf);

  buf = read_record(socket);

  /* should check if it was recieved OK here.
   */

  free(buf);
  close(socket);
  
  return 0;
}

/* Works out which TFP version of TFP should be used over
 * the connection.
 */

int
cnegotiate_tfp_version(int slave_socket){
  char *input_buf;
  char *field;
  double tfp_version;

  write(slave_socket, "TFP 1.3\n", 8);

  do{
    input_buf = read_record(slave_socket);
    field = get_field(input_buf, 1, NULL);

    if(field != NULL){
      if(0 == strcmp(field, "TFP")){
	tfp_version = strtod(get_field(input_buf, 2, NULL), (char **)NULL);
	
	if(tfp_version == 1.3){
	  free(input_buf);
	  free(field);
	  return 1;
	}else{/* a nonsense TFP version */
	  free(input_buf);
	  free(field);
	  return 0;
	}
      }

      /* else we're not recieving TFP input */
      free(input_buf);
      free(field);
      return -1;
    }
  }while(field == NULL);
}
