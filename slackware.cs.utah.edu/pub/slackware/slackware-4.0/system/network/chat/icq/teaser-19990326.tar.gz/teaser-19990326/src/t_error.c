/*
 * Teaser - A copyleft implimentation of RVP
 * Copyright (C) 1998, 1999 Matthew Parry <mettw@bowerbird.com.au
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the Non-Consultants' License as published by
 * Bowerbird Computing; either version 1.2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Non-Consultants' License for more details.
 *
 * You should have received a copy of the Non-Consultants' License
 * along with this program; if not, write to Bowerbird Computing,
 * PO Box 247, Nowra NSW, Australia, 2541.
 */



#include <teaser.h>
#include <time.h>
#include <stdarg.h>

void
t_error(boolean exit_prog, char *fmt, ...){
  time_t t;
  va_list args;
  char *error_msg;
  char *stime;
  char *pid;
  char *buf;
  int stlen;

  asprintf(&pid, "(%d) ", getpid());

  t = time(NULL);
  stime = ctime(&t);
  stlen = strlen(stime);
  stime[stlen-1] = ' ';

  va_start(args, fmt);
  vasprintf(&error_msg, fmt, args);
  va_end(args);

  if(logfd == -1)
    fprintf(stderr, "%s * Teaser%s%s\n", stime, pid, error_msg);
  else{
    asprintf(&buf, "%s * Teaser%s%s\n", stime, pid, error_msg);
    write(logfd, buf, strlen(buf));

    free(buf);
    
  }

  free(pid);

  if(exit_prog){
    close(logfd);
    unlink(pid_file);
    exit(1);
  }
}
