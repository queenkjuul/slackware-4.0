/* this symbol was not defined in autoconf 1.5 standard acconfig.h. */
#undef CRAY_STACKSEG_END

/* define if your compiler handles __FUNCTION__ macro (gcc v2.xx) */
#undef HAVE_FUNCTION_MACRO

/* define if size_t is defined in stddef.h */
#undef HAVE_SIZE_T_IN_STDDEF_H

/* define if size_t is defined in sys/types.h */
#undef HAVE_SIZE_T_IN_TYPES_H

/* define if time_t is defined in time.h */
#undef HAVE_TIME_T_IN_TIME_H

/* define if time_t is defined in sys/types.h */
#undef HAVE_TIME_T_IN_TYPES_H
