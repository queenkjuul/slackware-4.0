# This file show which TUA specific commands are available
#
# do_option "long-option-name"
#   This command is the same as putting "+long-option-name" on the
#   command line.
#   It is valid only for those options that do not require an argument
#
# port_alias "port-name" "its-alias"
#   Like +port-alias port-name=its-alias
#
# glob_port_alias "port-name" "its-globbing-alias"
#   Like +port-glob-alias port-name=its-globbing-alias
#
# kill_port "port-name"
#   Like +kill-port port-name
#
# sys_alias "sys-name" "its-alias"
#   Like +sys-alias sys-name=its-alias
#
# glob_sys_alias "sys-name" "its-globbing-alias"
#   Like +sys-glob-alias sys-name=its-globbing-alias
#
# kill_sys "sys-name"
#   Like +kill-sys sys-name
#
# user_alias "user-name" "its-alias"
#   Like +user-alias user-name=its-alias
#
# glob_user_alias "user-name" "its-globbing-alias"
#   Like +user-glob-alias user-name=its-globbing-alias
#
# kill_user "user-name"
#   Like +kill-user user-name
# 

