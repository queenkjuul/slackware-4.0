/* This file is part of the Project Athena Zephyr Notification System.
 * Created by: Mark W. Eichin <eichin@athena.mit.edu>
 * $Source: /mit/zephyr/src/zwgc/RCS/debug.c,v $
 * $Author: eichin $
 *
 *	Copyright (c) 1988 by the Massachusetts Institute of Technology.
 *	For copying and distribution information, see the file
 *	"mit-copyright.h". 
 */
#include <zephyr/mit-copyright.h>
#ifndef lint
static char rcsid[] = "$Header: debug.c,v 2.1 88/06/18 08:45:36 eichin Exp $";
#endif lint

global_debug()
{
  printf("zwgc:debug [Insert debugging message here]\n");
  printf("zwgc:debug continuing...\n");
}
