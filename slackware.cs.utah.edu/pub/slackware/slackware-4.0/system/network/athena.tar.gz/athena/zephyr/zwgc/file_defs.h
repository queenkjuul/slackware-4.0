/* This file is part of the Project Athena Zephyr Notification System.
 * It contains headers for the windowgram COMPILER.
 *
 *	Created by:	Mark W Eichin
 *
 *	$Source: /mit/zephyr/src/zwgc/RCS/file_defs.h,v $
 *	$Author: jtkohl $
 *
 *	Copyright (c) 1987 by the Massachusetts Institute of Technology.
 *	For copying and distribution information, see the file
 *	"mit-copyright.h". 
 */

#include <zephyr/mit-copyright.h>

#define USRXRCS ".Xresources"
#define DEFXRCS "/.Xresources"

#define USRDESC ".zephyr.desc"

#ifndef DEFDESC
#define DEFDESC "/etc/athena/zephyr.desc"
#endif

#ifndef ZCTLPROG
#define	ZCTLPROG "/usr/athena/zctl"
#endif

extern char panic_desc[];

