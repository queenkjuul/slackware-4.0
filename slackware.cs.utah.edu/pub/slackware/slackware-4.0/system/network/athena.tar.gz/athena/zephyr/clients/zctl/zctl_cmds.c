/* zctl_cmds.c - automatically generated from zctl_cmds.ct */
#include <ss/ss.h>

#ifndef __STDC__
#define const
#endif

static char const * const ssu00001[] = {
"file",
    (char const *)0
};
extern void set_file __SS_PROTO;
static char const * const ssu00002[] = {
"cancel",
    (char const *)0
};
extern void cancel_subs __SS_PROTO;
static char const * const ssu00003[] = {
"load",
    "ld",
    (char const *)0
};
extern void load_subs __SS_PROTO;
static char const * const ssu00004[] = {
"unload",
    "unld",
    (char const *)0
};
extern void load_subs __SS_PROTO;
static char const * const ssu00005[] = {
"list",
    "ls",
    (char const *)0
};
extern void load_subs __SS_PROTO;
static char const * const ssu00006[] = {
"subscribe",
    "sub",
    (char const *)0
};
extern void subscribe __SS_PROTO;
static char const * const ssu00007[] = {
"unsubscribe",
    "unsub",
    (char const *)0
};
extern void subscribe __SS_PROTO;
static char const * const ssu00008[] = {
"add",
    (char const *)0
};
extern void sub_file __SS_PROTO;
static char const * const ssu00009[] = {
"add_unsubscription",
    "add_un",
    (char const *)0
};
extern void sub_file __SS_PROTO;
static char const * const ssu00010[] = {
"delete",
    "del",
    "dl",
    (char const *)0
};
extern void sub_file __SS_PROTO;
static char const * const ssu00011[] = {
"delete_unsubscription",
    "del_un",
    (char const *)0
};
extern void sub_file __SS_PROTO;
static char const * const ssu00012[] = {
"retrieve",
    "ret",
    (char const *)0
};
extern void current __SS_PROTO;
static char const * const ssu00013[] = {
"defaults",
    "defs",
    (char const *)0
};
extern void current __SS_PROTO;
static char const * const ssu00014[] = {
"save",
    (char const *)0
};
extern void current __SS_PROTO;
static char const * const ssu00015[] = {
"show",
    (char const *)0
};
extern void show_var __SS_PROTO;
static char const * const ssu00016[] = {
"set",
    (char const *)0
};
extern void set_var __SS_PROTO;
static char const * const ssu00017[] = {
"unset",
    (char const *)0
};
extern void unset_var __SS_PROTO;
static char const * const ssu00018[] = {
"wg_read",
    (char const *)0
};
extern void wgc_control __SS_PROTO;
static char const * const ssu00019[] = {
"wg_shutdown",
    (char const *)0
};
extern void wgc_control __SS_PROTO;
static char const * const ssu00020[] = {
"wg_startup",
    (char const *)0
};
extern void wgc_control __SS_PROTO;
static char const * const ssu00021[] = {
"hm_flush",
    (char const *)0
};
extern void hm_control __SS_PROTO;
static char const * const ssu00022[] = {
"new_server",
    (char const *)0
};
extern void hm_control __SS_PROTO;
static char const * const ssu00023[] = {
"flush_locs",
    (char const *)0
};
extern void flush_locations __SS_PROTO;
static char const * const ssu00024[] = {
"hide",
    (char const *)0
};
extern void do_hide __SS_PROTO;
static char const * const ssu00025[] = {
"unhide",
    (char const *)0
};
extern void do_hide __SS_PROTO;
static char const * const ssu00026[] = {
"list_requests",
    "lr",
    "?",
    (char const *)0
};
extern void ss_list_requests __SS_PROTO;
static char const * const ssu00027[] = {
"quit",
    "exit",
    "q",
    (char const *)0
};
extern void ss_quit __SS_PROTO;
static ss_request_entry ssu00028[] = {
    { ssu00001,
      set_file,
      "Set default subscriptions file.",
      0 },
    { ssu00002,
      cancel_subs,
      "Cancel all subscriptions.",
      0 },
    { ssu00003,
      load_subs,
      "Subscribe to a subscriptions file.",
      0 },
    { ssu00004,
      load_subs,
      "Unsubscribe to a subscriptions file.",
      0 },
    { ssu00005,
      load_subs,
      "List a subscriptions file.",
      0 },
    { ssu00006,
      subscribe,
      "Subscribe to a class/class instance.",
      0 },
    { ssu00007,
      subscribe,
      "Unsubscribe to a class/class instance.",
      0 },
    { ssu00008,
      sub_file,
      "Subscribe and add to subscriptions file.",
      0 },
    { ssu00009,
      sub_file,
      "Unsubscribe and add to subscriptions file\n                         as un-subscription.",
      0 },
    { ssu00010,
      sub_file,
      "Unsubscribe and delete subscription from\n                         subscriptions file.",
      0 },
    { ssu00011,
      sub_file,
      "Delete un-subscription from subscriptions file.",
      0 },
    { ssu00012,
      current,
      "Retrieve current subscriptions.",
      0 },
    { ssu00013,
      current,
      "Retrieve system-wide default subscriptions.",
      0 },
    { ssu00014,
      current,
      "Save current subscriptions (replacing existing file).",
      0 },
    { ssu00015,
      show_var,
      "Show a variable's value.",
      0 },
    { ssu00016,
      set_var,
      "Set a variable's value.",
      0 },
    { ssu00017,
      unset_var,
      "Delete a variable's value.",
      0 },
    { ssu00018,
      wgc_control,
      "Get the WindowGram to reread it's description file.",
      0 },
    { ssu00019,
      wgc_control,
      "Tell the WindowGram not to react to incoming notices.",
      0 },
    { ssu00020,
      wgc_control,
      "Tell the WindowGram to react to incoming notices.",
      0 },
    { ssu00021,
      hm_control,
      "Tell the server to flush information about this host.",
      0 },
    { ssu00022,
      hm_control,
      "Tell the HostManager to find a new server.",
      0 },
    { ssu00023,
      flush_locations,
      "Flush all location information.",
      0 },
    { ssu00024,
      do_hide,
      "Hide your location.",
      0 },
    { ssu00025,
      do_hide,
      "Show (un-hide) your location.",
      0 },
    { ssu00026,
      ss_list_requests,
      "List available commands.",
      0 },
    { ssu00027,
      ss_quit,
      "Quit.",
      0 },
    { 0, 0, 0, 0 }
};

ss_request_table zctl_cmds = { 2, ssu00028 };
