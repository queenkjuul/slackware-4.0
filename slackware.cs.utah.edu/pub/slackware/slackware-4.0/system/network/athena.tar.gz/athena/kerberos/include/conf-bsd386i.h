/*
 * $Source: /afs/athena.mit.edu/astaff/project/kerberos/src/include/RCS/conf-bsd386i.h,v $
 * $Author: jtkohl $
 * $Header: /afs/athena.mit.edu/astaff/project/kerberos/src/include/RCS/conf-bsd386i.h,v 4.0 89/12/19 13:26:55 jtkohl Exp $
 *
 * Copyright 1989 by the Massachusetts Institute of Technology.
 *
 * For copying and distribution information, please see the file
 * <mit-copyright.h>.
 *
 * Machine-type definitions: Sun 386i using SunOS (~BSD)
 */

#include <mit-copyright.h>

#define BITS32
#define BIG
#define LSBFIRST
#define BSDUNIX

