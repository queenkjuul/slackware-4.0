#define COMMAND_TABLE 257
#define REQUEST 258
#define UNKNOWN 259
#define UNIMPLEMENTED 260
#define END 261
#define STRING 262
#define FLAGNAME 263
#define OPTIONS 264
typedef union {
	char *dynstr;
	long flags;
} YYSTYPE;
extern YYSTYPE yylval;
