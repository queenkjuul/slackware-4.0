/* This file is part of the Project Athena Zephyr Notification System.
 * It contains functions for the experimental ZWGC browser.
 *
 *	Created by:	Mark W. Eichin
 *
 *	$Source: /mit/zephyr/src/zwgc/zbrowser/RCS/zbrowser_body.c,v $
 *	$Author: jtkohl $
 *
 *	Copyright (c) 1988 by the Massachusetts Institute of Technology.
 *	For copying and distribution information, see the file
 *	"mit-copyright.h". 
 */
  Widget top;
  Widget view;
  Widget panes;
  Widget cmds;
  Widget quit;
  Widget map;
  Widget unmap;
  Widget delete;
  Arg xtargv[5];
  int xtargc;
  XtCallbackRec xtcalls[2]; /* 2 pair of NULLS */
top  = XtInitialize("main", "cnct", NULL, 0, &argc, argv);
xtargc = 0;
XtSetArg(xtargv[xtargc], XtNresizable, True ); xtargc++;
XtSetArg(xtargv[xtargc], XtNallowVert, True ); xtargc++;
XtSetArg(xtargv[xtargc], XtNforceBars, True ); xtargc++;
view  = XtCreateManagedWidget("viewport", viewportWidgetClass, top,
				xtargv, xtargc);
xtargc = 0;
panes  = XtCreateManagedWidget("box", boxWidgetClass, view,
				xtargv, xtargc);
xtargc = 0;
XtSetArg(xtargv[xtargc], XtNtop,XtChainTop ); xtargc++;
XtSetArg(xtargv[xtargc], XtNbottom,XtChainTop ); xtargc++;
cmds  = XtCreateManagedWidget("form", formWidgetClass, panes,
				xtargv, xtargc);
xtargc = 0;
XtSetArg(xtargv[xtargc], XtNlabel,"quit" ); xtargc++;
XtSetArg(xtargv[xtargc], XtNfromHoriz,NULL ); xtargc++;
XtSetArg(xtargv[xtargc], XtNright,XtChainLeft ); xtargc++;
XtSetArg(xtargv[xtargc], XtNleft,XtChainLeft ); xtargc++;
xtcalls[0].callback =  quitFn ;
xtcalls[0].closure =  NULL ;
XtSetArg(xtargv[xtargc], XtNcallback, xtcalls); xtargc++;
quit  = XtCreateManagedWidget("command", commandWidgetClass, cmds,
				xtargv, xtargc);
xtargc = 0;
XtSetArg(xtargv[xtargc], XtNlabel,"map" ); xtargc++;
XtSetArg(xtargv[xtargc], XtNfromHoriz,quit ); xtargc++;
XtSetArg(xtargv[xtargc], XtNright,XtChainLeft ); xtargc++;
XtSetArg(xtargv[xtargc], XtNleft,XtChainLeft ); xtargc++;
xtcalls[0].callback =  mapFn ;
xtcalls[0].closure =  NULL ;
XtSetArg(xtargv[xtargc], XtNcallback, xtcalls); xtargc++;
map  = XtCreateManagedWidget("command", commandWidgetClass, cmds,
				xtargv, xtargc);
xtargc = 0;
XtSetArg(xtargv[xtargc], XtNlabel,"unmap" ); xtargc++;
XtSetArg(xtargv[xtargc], XtNfromHoriz,map ); xtargc++;
XtSetArg(xtargv[xtargc], XtNright,XtChainLeft ); xtargc++;
XtSetArg(xtargv[xtargc], XtNleft,XtChainLeft ); xtargc++;
xtcalls[0].callback =  unmapFn ;
xtcalls[0].closure =  NULL ;
XtSetArg(xtargv[xtargc], XtNcallback, xtcalls); xtargc++;
unmap  = XtCreateManagedWidget("command", commandWidgetClass, cmds,
				xtargv, xtargc);
xtargc = 0;
XtSetArg(xtargv[xtargc], XtNlabel,"delete" ); xtargc++;
XtSetArg(xtargv[xtargc], XtNfromHoriz,unmap ); xtargc++;
XtSetArg(xtargv[xtargc], XtNright,XtChainLeft ); xtargc++;
XtSetArg(xtargv[xtargc], XtNleft,XtChainLeft ); xtargc++;
xtcalls[0].callback =  deleteFn ;
xtcalls[0].closure =  NULL ;
XtSetArg(xtargv[xtargc], XtNcallback, xtcalls); xtargc++;
delete  = XtCreateManagedWidget("command", commandWidgetClass, cmds,
				xtargv, xtargc);
