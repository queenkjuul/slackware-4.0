/* $Id: sock.h,v 1.1 1998/08/01 16:03:14 dg8xt Exp $ */

#define IN      0               /* standard input */
#define OUT     1               /* standard output */

int open_connection(char*, int);
int connect_to(char*, int, char*);

