/* $Id: usage.h,v 1.1 1998/08/01 16:03:14 dg8xt Exp $ */

int usage();
int usage_long();

