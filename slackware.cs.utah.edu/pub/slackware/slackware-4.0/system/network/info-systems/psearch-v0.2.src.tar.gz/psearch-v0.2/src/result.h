/* $Id: result.h,v 1.1 1998/08/01 16:03:14 dg8xt Exp $ */

void print_result(int opt_w, char *line, char *hostname);

