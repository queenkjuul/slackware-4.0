/* $Id: search.h,v 1.1 1998/08/01 16:03:14 dg8xt Exp $ */

void search(int opt_w, char *search_for, char *data_file);

