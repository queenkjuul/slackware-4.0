From seanu@plaza.ds.adp.comTue May  2 18:27:26 1995
Date: Tue, 2 May 1995 17:59:20 -0700
From: Sean Utt <seanu@plaza.ds.adp.com>
To: seanu@adpgate.plaza.ds.adp.com

#!/usr/local/bin/perl -- -*-perl-*-

# ------------------------------------------------------------
# Form-mail.pl, by Reuven M. Lerner (reuven@the-tech.mit.edu).
#
# Last updated: March 14, 1994
#
# Form-mail provides a mechanism by which users of a World-
# Wide Web browser may submit comments to the webmasters
# (or anyone else) at a site.  It should be compatible with
# any CGI-compatible HTTP server.
# 
# Please read the README file that came with this distribution
# for further details.
# ------------------------------------------------------------

# ------------------------------------------------------------
# This package is Copyright 1994 by The Tech. 

# Form-mail is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.

# Form-mail is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Form-mail; see the file COPYING.  If not, write to the Free
# Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# ------------------------------------------------------------

# ------------------------------------------------------------
# This Package further modified by Sean Utt to allow for multiple               
# mailto: entries, allowing for a checkbox mailer, and generic                  
# use by all persons on the system for forms based mail..                       
# included with this should be sample .html files for a mass listing            
# and for idividual use.                                                        
#                                                                               
# Also, there should be perl scripts to maintain those files.                   
# A packing list will be included here later..                                  
# This version for the electronic timesheet for ADP                             
#                                                                               
# ------------------------------------------------------------
# Define fairly-constants
# This should match the mail program on your system.
$mailprog = '/usr/lib/sendmail';

# Print out a content-type for HTTP/1.0 compatibility
print "Content-type: text/html\n\n";

# Print a title and initial heading
print "<Head><Title>Thank you</Title></Head>";
print "<Body><H1>Thank you</H1>";

# Get the input
read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
#print "$buffer<P>\n";  #DEBUG LINE
# Split the name-value pairs
    $counter=0;
@pairs = split(/&/, $buffer);
foreach $pair (@pairs)
{
    ($name, $value) = split(/=/, $pair);
    # Un-Webify plus signs and %-encoding
    $value =~ tr/+/ /;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

    # Stop people from using subshells to execute commands
    # Not a big deal when using sendmail, but very important
    # when using UCB mail (aka mailx).
    # $value =~ s/~!/ ~!/g; 

    # Uncomment for debugging purposes
#     print "Setting $name to $value<P>";  #DEBUG LINE
    $FORM[$counter] = $value;
    $counter++;
}
$counter = ($counter -1);
#print "$counter<P>";  #DEBUG LINE
# assign all the $FORM[] entries to mailable values
$SupervisorName=$FORM[$counter - 44];
#print "$SupervisorName<P>"; #DEBUG LINE
$State=$FORM[$counter - 43];
#print "$State<P>"; #DEBUG LINE
#print "$PayPeriod<P>"; #DEBUG LINE
$BeginDate=$FORM[$counter - 42];
#print "$BeginDate<P>"; #DEBUG LINE
$EndDate=$FORM[$counter - 41];
#print "$EndDate<P>"; #DEBUG LINE
$NameOne=$FORM[$counter - 40];
#print "$NameOne<P>"; #DEBUG LINE
$SSNumber=$FORM[$counter - 39];
#print "$SSNumber<P>"; #DEBUG LINE
$FileNumber=$FORM[$counter - 38];
#print "$FileNumber<P>"; #DEBUG LINE
$Date1=$FORM[$counter - 37];
#print "$Date1<P>"; #DEBUG LINE
$Hours1=$FORM[$counter - 36];
#print "$Hours1<P>"; #DEBUG LINE
$Date2=$FORM[$counter - 35];
#print "$Date2<P>"; #DEBUG LINE
$Hours2=$FORM[$counter - 34];
#print "$Hours2<P>"; #DEBUG LINE
$Date3=$FORM[$counter - 33];
#print "$Date3<P>"; #DEBUG LINE
$Hours3=$FORM[$counter - 32];
#print "$Hours3<P>"; #DEBUG LINE
$Date4=$FORM[$counter - 31];
#print "$Date4<P>"; #DEBUG LINE
$Hours4=$FORM[$counter - 30];
#print "$Hours4<P>"; #DEBUG LINE
$Date5=$FORM[$counter - 29];
#print "$Date5<P>"; #DEBUG LINE
$Hours5=$FORM[$counter - 28];
#print "$Hours5<P>"; #DEBUG LINE
$Date6=$FORM[$counter - 27];
#print "$Date6<P>"; #DEBUG LINE
$Hours6=$FORM[$counter - 26];
#print "$Hours6<P>"; #DEBUG LINE
$Date7=$FORM[$counter - 25];
#print "$Date7<P>"; #DEBUG LINE
$Hours7=$FORM[$counter - 24];
#print "$Hours7<P>"; #DEBUG LINE
$WeekOne=$FORM[$counter - 23];
#print "$WeekOne<P>"; #DEBUG LINE
$SubTotalOne=$FORM[$counter - 22];
#print "$SubTotalOne<P>"; #DEBUG LINE
$Date8=$FORM[$counter - 21];
#print "$Date8<P>"; #DEBUG LINE
$Hours8=$FORM[$counter - 20];
#print "$Hours8<P>"; #DEBUG LINE
$Date9=$FORM[$counter - 19];
#print "$Date9<P>"; #DEBUG LINE
$Hours9=$FORM[$counter - 18];
#print "$Hours9<P>"; #DEBUG LINE
$Date10=$FORM[$counter - 17];
#print "$Date10<P>"; #DEBUG LINE
$Hours10=$FORM[$counter - 16];
#print "$Hours10<P>"; #DEBUG LINE
$Date11=$FORM[$counter - 15];
#print "$Date11<P>"; #DEBUG LINE
$Hours11=$FORM[$counter - 14];
#print "$Hours11<P>"; #DEBUG LINE
$Date12=$FORM[$counter - 13];
#print "$Date12<P>"; #DEBUG LINE
$Hours12=$FORM[$counter - 12];
#print "$Hours12<P>"; #DEBUG LINE
$Date13=$FORM[$counter - 11];
#print "$Date13<P>"; #DEBUG LINE
$Hours13=$FORM[$counter - 10];
#print "$Hours13<P>"; #DEBUG LINE
$Date14=$FORM[$counter - 9];
#print "$Date14<P>"; #DEBUG LINE
$Hours14=$FORM[$counter - 8];
#print "$Hours14<P>"; #DEBUG LINE
$WeekTwo=$FORM[$counter - 7];
#print "$WeekTwo<P>"; #DEBUG LINE
$SubTotalTwo=$FORM[$counter - 6];
#print "$SubTot<P>"; #DEBUG LINE
$TotalHours=$FORM[$counter - 5];
#print "$TotalHours<P>"; #DEBUG LINE
$ReturnAddress=$FORM[$counter - 4];
#print "$ReturnAdress<P>"; #DEBUG LINE
$EmployeeName=$FORM[$counter - 3];
#print "$EmployeeName<P>"; #DEBUG LINE
$CostCenter=$FORM[$counter - 2];
#print "$CostCenter<P>"; #DEBUG LINE
$Mailto=$FORM[$counter - 1];
#print "$Mailto<P>"; #DEBUG LINE
$HomeFront=$FORM[$counter];
#print "$HomeFront<P>"; #DEBUG LINE

# Now send mail to $Mailto:
#print "$Mailto<P>";  #DEBUG LINE
open (MAIL, "|$mailprog $Mailto") || die "Can't open $mailprog!\n";
print MAIL "Reply-to:  $ReturnAddress ( $EmployeeName )\n";
print MAIL "Subject: Timesheet  (Forms Submission)\n\n";
print MAIL "$ReturnAddress ( $EmployeeName )sent the following\n";
print MAIL "Timesheet information:\n\n";
print MAIL  "------------------------------------------------------------\n";
print MAIL "EXEMPT EMPLOYEE SHIFT DIFFERENTIAL -- 8%\n\n";
print MAIL "COST CENTER: $CostCenter\n";
print MAIL "STATE RESIDENCE: $State\n";
print MAIL "PAY PERIOD: $PayPeriod\n";
print MAIL "FROM: $BeginDate   TO: $EndDate\n";
print MAIL "NAME: $NameOne   SS#: $SSNumber\n";
print MAIL "FILE#: $FileNumber\n\n";
print MAIL "\tDATE:\t\tHOURS:\n";
print MAIL "\t$Date1\t\t$Hours1\n";
print MAIL "\t$Date2\t\t$Hours2\n";
print MAIL "\t$Date3\t\t$Hours3\n";
print MAIL "\t$Date4\t\t$Hours4\n";
print MAIL "\t$Date5\t\t$Hours5\n";
print MAIL "\t$Date6\t\t$Hours6\n";
print MAIL "\t$Date7\t\t$Hours7\n\n\n";
print MAIL "WEEK OF: $WeekOne\n";
print MAIL "HOURS: $SubTotalOne\n";
print MAIL "\tDATE:\t\tHOURS:\n";
print MAIL "\t$Date8\t\t$Hours8\n";
print MAIL "\t$Date9\t\t$Hours9\n";
print MAIL "\t$Date10\t\t$Hours10\n";
print MAIL "\t$Date11\t\t$Hours11\n";
print MAIL "\t$Date12\t\t$Hours12\n";
print MAIL "\t$Date13\t\t$Hours13\n";
print MAIL "\t$Date14\t\t$Hours14\n\n\n";
print MAIL "WEEK OF: $WeekTwo\n";
print MAIL "HOURS: $SubTotalTwo\n\n\n";
print MAIL "TOTAL HOURS = $TotalHours\n\n";
print MAIL "Employee: $EmployeeName\t\t Supervisor: $SupervisorName\n\n";
print MAIL "\n------------------------------------------------------------\n";
close (MAIL);

# Make the person feel good for writing to us
print "Thank you for flying <I>NTS</I>!<P>";
print "Return to our <A HREF=\"/index.html\">home page</A>, if you want.<P>";

# ------------------------------------------------------------
mightymouse:~/httpd/cgi-bin
#

