From seanu@mightymouse.adp.comTue May  2 18:37:46 1995
Date: Tue, 2 May 1995 18:28:45 -0700
From: Sean Utt <seanu@mightymouse.adp.com>
To: seanu@adpgate.plaza.ds.adp.com

#!/usr/local/bin/perl
# -w
# script to compute the days of the week for the timesheet so I can
# be a showoff.  
# This script will be run from cron to update an html file in /usr/local/etc/httpd/htdocs/workplace 
# called timesheet.html
# A file containing the last date of the end of the pay period will be 
# kept in /usr/local/etc/httpd/htdocs/misc
# this script will update that file as necessary.
#
chop($PayPeriod = `cat /usr/local/etc/httpd/htdocs/misc/paydate|cut -c0-10`);
#print "$PayPeriod\n"; ## DEBUG LINE
# Test first to see if the file is up to date
chop($TestToday = `date +%j`);
#print "$TestToday\n"; ## DEBUG LINE
chop($TestThisYear = `date |cut -c0-11,25-28|tr -s " "|cut -f4 -d " "`);
#print "$TestThisYear\n"; ## DEBUG LINE
chop($TestPeriodYear = `cat /usr/local/etc/httpd/htdocs/misc/paydate|cut -f4 -d" "`);
#print "$TestPeriodYear\n"; ## DEBUG LINE
chop($TestPeriodDay = `date --date '$PayPeriod' +%j`);
#print "$TestPeriodDay\n"; ## DEBUG LINE
if ($TestPeriodYear > $TestThisYear) {do PrintPayPeriod();print "Year test exit\n";exit 0;};
if ($TestToday <= $TestPeriodDay) {do PrintPayPeriod();print "Week end test exit\n";exit 0;};
#print "made it here\n"; ## DEBUG LINE
do UpdatePayPeriodDay();print "Updated pay period\n";
exit 0;
# sub routines
#
#
sub UpdatePayPeriodDay {
`date --date '2 weeks 1 day $PayPeriod'|cut -c0-11,25-28|tr -s " ">/usr/local/etc/httpd/htdocs/misc/paydate`;
do PrintPayPeriod();
};
sub PrintPayPeriod {
chop($Day1 = `date --date '13 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day2 = `date --date '12 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day3 = `date --date '11 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day4 = `date --date '10 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day5 = `date --date '9 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day6 = `date --date '8 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day7 = `date --date '7 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day8 = `date --date '6 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day9 = `date --date '5 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day10 = `date --date '4 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day11 = `date --date '3 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day12 = `date --date '2 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day13 = `date --date '1 days ago $PayPeriod'|cut -c0-11,25-28`);
chop($Day14 = `date --date '0 days ago $PayPeriod'|cut -c0-11,25-28`);
#print "$Day1\n$Day2\n$Day3\n$Day4\n$Day5\n$Day6\n$Day7\n$Day8\n$Day9\n$Day10\n$Day11\n$Day12\n$Day13\n$Day14\n"; ## DEBUG LINE
do MakePage();
};
sub MakePage {
open (HTML, ">/usr/local/etc/httpd/htdocs/workplace/timesheet.html") || die "can't open $HTML $!";
print HTML "<HTML>";
# Print a title and initial heading
print HTML "<Head><Title>Time Sheet</Title></Head>";
print HTML "<Body><H1>Time Sheet Form for NSS</H1>";
print HTML "<Form method=POST action=\"/cgi-bin/time-total-calc.pl\">";
print HTML "<P>";
print HTML "If you need to enter dates and hours for a different time period,";
print HTML "use the <A HREF=\"/workplace/timesheet-form.html\">generic </A> time";
print HTML "sheet.<P>";
print HTML "EXEMPT EMPLOYEE SHIFT DIFFERENTIAL -- 8%<P>";
print HTML "<P>";
print HTML "COST CENTER:   083<P>";
print HTML "Supervisor:<inPUT NAME=\"SupervisorName\" default=\" \"><P>";
print HTML "STATE RESIDENCE: <inPUT NAME=\"State\" default=\" \"><P>";
print HTML "PAY PERIOD: FROM: $Day1 TO: $Day14<P>";
print HTML "NAME:<inPUT NAME=\"NameOne\" default=\" \"><P>";
print HTML "SS#:<inPUT NAME=\"SSNumber\" default=\" \"><P>";
print HTML "FILE#:<inPUT NAME=\"FileNumber\" default=\" \"><P>";
print HTML "<P>";
print HTML "Enter your hours here, and submit the form, it will add up the hours for you, and send it to Sharon Ward. 
if you need to enter fractions of hours, use decimal, not fractions, i.e: .5 not 1/2 <P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day1\">DATE: $Day1 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day2\">DATE: $Day2 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day3\">DATE: $Day3 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day4\">DATE: $Day4 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day5\">DATE: $Day5 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day6\">DATE: $Day6 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day7\">DATE: $Day7 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day8\">DATE: $Day8 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day9\">DATE: $Day9 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day10\">DATE: $Day10 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day11\">DATE: $Day11 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day12\">DATE: $Day12 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day13\">DATE: $Day13 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Date\" VALUE=\"$Day14\">DATE: $Day14 HOURS: <inPUT NAME=\"Hours\" default=\" \"><P>";
print HTML "Please enter your login name: <inPUT NAME=\"ReturnAddress\" default=\" \"> it will add this to @plaza.ds.adp.com to send you a copy. <P>";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"CostCenter\" Value=\"083\">";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"Mailto\" Value=\"sha@plaza.ds.adp.com\">";
print HTML "<INPUT TYPE=\"hidden\" NAME=\"HomeFront\" VALUE=\"/workplace/timesheet-form.html\">";
print HTML "<P>";
print HTML "<Input TYPE=\"submit\" VALUE=\"Submit Timesheet\">";
print HTML "<Input TYPE=\"reset\" VALUE=\"Reset Timesheet\"><p>";
print HTML "</Form>";
print HTML "<Address><A HREF=\"/index.html\">ADP National Tech Support </A></Address>";
print HTML "</Body>";
print HTML "</HTML>";
close(HTML);
};

