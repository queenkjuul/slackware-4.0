/* $Id: misc.h,v 1.1 1998/08/01 16:03:14 dg8xt Exp $ */

void check_search(char *search_for);
void convert_lower_to_upper(char *buf, int len);

