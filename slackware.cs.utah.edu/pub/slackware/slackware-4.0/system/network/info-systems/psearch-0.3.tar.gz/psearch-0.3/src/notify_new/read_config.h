/* $Id: read_config.h,v 1.1 1999/03/27 14:18:33 dg8xt Exp $ */

int read_config(char *);
