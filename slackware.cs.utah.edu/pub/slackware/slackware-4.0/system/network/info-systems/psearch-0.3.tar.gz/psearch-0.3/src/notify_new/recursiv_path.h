/* $Id */

struct recursive_pathname
{
   char name[255];
   struct recursive_pathname *next;
};

struct recursive_pathname *Recursive_pathname;

int add_entry_recursive_pathname(char *);
int check_entry_recursive_pathname(char *);

