/* $Id */

struct filename
{
   char name[255];
   struct filename *next;
};

struct filename *Filename;

int add_entry_filename(char *);
int check_entry_filename(char *);

