/* $Id: parse_input.h,v 1.1 1999/03/27 14:18:33 dg8xt Exp $ */

FILE *out;

void parse_input(char *, char *);
