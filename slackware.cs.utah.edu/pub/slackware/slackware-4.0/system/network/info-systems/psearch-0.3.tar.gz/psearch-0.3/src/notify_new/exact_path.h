/* $Id */

struct exact_pathname
{
   char name[255];
   struct exact_pathname *next;
};

struct exact_pathname *Exact_pathname;

int add_entry_exact_pathname(char *);
int check_entry_exact_pathname(char *);

