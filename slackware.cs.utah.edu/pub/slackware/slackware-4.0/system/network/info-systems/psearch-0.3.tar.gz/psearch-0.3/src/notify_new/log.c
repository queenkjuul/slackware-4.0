/* $Id: log.c,v 1.1 1999/03/27 14:18:33 dg8xt Exp $ */

#include <stdio.h>
#include <syslog.h>

const char progname[16]="notify_new";

void error_log(char *s1, char *s2)
{
   extern int debug;
   if(debug)
      openlog(progname,LOG_PERROR,0);
   else
      openlog(progname,0,0);
   syslog(3, "%s %s", s1, s2); /* LOG_ERR */
   closelog();
}

