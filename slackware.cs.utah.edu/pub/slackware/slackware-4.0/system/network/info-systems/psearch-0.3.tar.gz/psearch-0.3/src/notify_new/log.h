/* $Id: log.h,v 1.1 1999/03/27 14:18:33 dg8xt Exp $ */

void error_log(char *, char *);

