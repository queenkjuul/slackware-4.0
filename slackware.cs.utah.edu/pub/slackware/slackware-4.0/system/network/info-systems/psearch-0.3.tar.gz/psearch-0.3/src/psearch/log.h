/* $Id: log.h,v 1.1 1998/08/01 16:03:14 dg8xt Exp $ */

void check_root();
void error_log(char *error_desc);

