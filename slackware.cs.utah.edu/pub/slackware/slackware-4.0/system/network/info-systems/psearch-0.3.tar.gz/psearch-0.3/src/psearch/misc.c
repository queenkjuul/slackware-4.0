/* $Id: misc.c,v 1.1 1998/08/01 16:03:14 dg8xt Exp $ */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* check the search string */
void check_search(char *search_for)
{
   if ( (!strspn(search_for, "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") == 1)
   || (strlen(search_for) < 2) )
   {
      puts("Sorry. Your request is faulty.");
      puts("There are minimal 2 characters required and");
      puts("the first character must be an alphanumeric.");
      exit (2);
   }
}   

/* convert lowercase into uppercase */
void convert_lower_to_upper(char *buf, int len)
{
   while (len--) {
   *buf = toupper(*buf);
   buf++;
   }
}

