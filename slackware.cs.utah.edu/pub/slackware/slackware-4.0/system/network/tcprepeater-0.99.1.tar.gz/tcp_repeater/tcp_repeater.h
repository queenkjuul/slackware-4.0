/*
 * $Id: tcp_repeater.h,v 1.2 1998/04/13 13:45:41 cic Exp $
 * 
 * $Log: tcp_repeater.h,v $
 * Revision 1.2  1998/04/13 13:45:41  cic
 * The initial revisio, just the version number is here.
 *
 */

#ifndef __REPEATER__

#define __REPEATER__

#define REPEATER_VERSION "0.99.1"

#endif
