/*
 * This file is written by Timotej Ecimovic from the scratch.
 * Copyrights apply, 1998.
 *
 * $Id: tcp_repeater.c,v 1.12 1998/04/13 13:45:58 cic Exp $
 *
 * $Log: tcp_repeater.c,v $
 * Revision 1.12  1998/04/13 13:45:58  cic
 * The version number and the header file are added.
 *
 * Revision 1.11  1998/04/13 13:41:12  cic
 * Removed the revision number. Hm....
 *
 * Revision 1.10  1998/04/13 13:38:54  cic
 * Added revision number to the usage.
 *
 * Revision 1.9  1998/04/13 12:47:22  cic
 * Changed valentincic to localhost for default hostname.
 *
 * Revision 1.8  1998/04/13 12:21:16  cic
 * I have enabled the logfilename in the form: |something, which
 * means that the log stream is the pipe to the command 'something',
 * created by popen() system call. Might be usefull eventually.
 *
 * Revision 1.7  1998/04/04 13:38:57  cic
 * Ok. Logging is done as well. Additional switches to the executable are
 * -nolog switch and -logfile <filename> switch. Default to the latter is
 * repeater.log and '-' is possible for stdout. Otherwise the log is
 * there, it could be somewhat more beautiful, but it works anyway!
 * I guess this could be like the 1.0 version of this thing, as all the
 * initial goals are achieved.
 *
 * Revision 1.6  1998/04/03 16:24:22  cic
 * Ok. Basic functionality is there. It works as was proven with
 * Xdesigner. THe default listening port is changed to 6017, the default
 * xlmd port, since X-Designer wouldn't want to connect to 6018. Don't
 * know why, but now the xlmd should start with -p 18 switch to put it on
 * 6018 port. The necessary things done should be a full log of a
 * session. So far only some dump uncomprehensible gibberish is printed
 * out. This should be done soon and then extensively tested.
 *
 * Revision 1.5  1998/04/03 12:30:04  cic
 * The skeleton of the main loop is done. DEBUG is added. All that needs
 * be done now are the socket functions for actuall work. And the logging
 * of the transmitted data, but that comes after the thing actually
 * works.
 *
 * Revision 1.4  1998/04/03 02:14:10  cic
 * Changed dummy value for listen-socket creation from success to
 * failure.
 *
 * Revision 1.3  1998/04/03 02:11:36  cic
 * The basic select() loop has been created. A structure ComPar has been
 * done, which contains all the file descriptors. Client (xdesigner) and
 * server (xlmd) sockets are stored in arrays fd_clients and fd_servers
 * in the ComPar and connections contains the number of elements. The
 * index of client and server must match in the array. The file
 * descriptor sets are contained in sets[] array, where first two are for
 * reading (one for container and other for working array for select())
 * then two for writing (do we need them at all?) and two for exceptions.
 *
 * Revision 1.2  1998/04/02 17:26:44  cic
 * Command line parameters parsing is done:
 *   -host <hostname>
 *   -connectport <port>
 *   -listenport  <port>
 *
 * Revision 1.1  1998/04/02 17:10:46  cic
 * Initial revision
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <strings.h>
#include <ctype.h>

#include "tcp_repeater.h"

#ifndef DEBUG
#define D(string) {}
#else
#define D(string) {fprintf ( stderr, string );}
#endif

typedef struct {
  char *hostname;
  char *logname;
  FILE *logfile;
  int listenport;
  int connectport;
  
  int fd_listen;
  int *fd_clients;
  int *fd_servers;
  int connections;
} ComPar;
ComPar *global_compar_copy;

char hostname[200];
char logname[200];
int connectport=6018;
int listenport=6017;
int logmode=1;     /* 0 - nolog, 1 - log */

/*
 * This function prints out the usage on the stdout and then exits
 */
void 
usage( char *prog )
{
  D( "usage()\n" );
  fprintf ( stderr, "Usage: %s [parameters]\n", prog );
  fprintf ( stderr, "Valid parameters are:\n" );
  fprintf ( stderr, "  -host    <hostname>   Default: localhost\n" );
  fprintf ( stderr, "  -connectport <port>   Default: 6018\n" );
  fprintf ( stderr, "  -listenport  <port>   Default: 6017\n" );
  fprintf ( stderr, "  -logfile <file>       Default: repeater.log\n" );
  fprintf ( stderr, "  -nolog\n" );
  fprintf ( stderr, "  -nofork\n" );
  fprintf ( stderr, "\nThis is tcp_repeater version %s.\n", REPEATER_VERSION );
  exit(EXIT_FAILURE);
}

#define log_flush(a) fflush(a->logfile)

void
log_timestamp ( ComPar *compar )
{
  time_t result;
  static char timestr[100];

  time (&result);
  strftime ( timestr, 100, "%c: ", localtime(&result) );
  fprintf ( compar->logfile, timestr );
}

void
start_log ( ComPar *compar )
{
  D ( "start_log()" );
  if ( !strcmp ( compar->logname, "-" ) )
    compar->logfile = stdout;
  else if ( compar->logname[0] == '|' )
      compar->logfile = popen ( (compar->logname)+1, "w" );
  else
    compar->logfile = fopen ( compar->logname, "a" );
  if ( compar->logfile == NULL )
    {
      perror ( "Opening logfile:" );
      exit (EXIT_FAILURE);
    }
  log_timestamp ( compar );
  fprintf ( compar->logfile, "Log started.\n" );
  log_flush ( compar );
}

void
stop_log ( ComPar *compar )
{
  D( "stop_log()" );

  log_timestamp ( compar );
  fprintf ( compar->logfile, "Log finished.\n" );
  log_flush ( compar );
  if ( compar->logname[0] == '|' )
    pclose ( compar->logfile );
  else if ( compar->logfile != stdout )
    fclose ( compar->logfile );
}

/* 
 * This function creates the listening socket and sets the compar element
 * to this value. It returns 1 on success and 0 on failure.
 */
int 
create_listen_socket (ComPar *compar)
{
  int sock;
  struct sockaddr_in name;

  D ( "create_listen_socket()\n" );
  sock=socket ( PF_INET, SOCK_STREAM, 0);
  if ( sock<0 )
    {
      perror ( "socket" );
      return 0;
    }
  name.sin_family = AF_INET;
  name.sin_port = htons ( compar->listenport );
  name.sin_addr.s_addr = htonl ( INADDR_ANY );
  if (bind (sock, (struct sockaddr *) &name, sizeof (name)) < 0)
    {
      perror ("bind");
      return 0;
    }
  if (listen ( sock, 10 ) < 0 )
    {
      perror ( "listen" );
      return 0;
    }
  compar->fd_listen=sock;
  return 1;
}

/*
 * Function accepts the new client and at the same time opens the new
 * server connection. Both new filedescriptors are saved into the
 * compar, and the index of the fds into the array in compar is
 * returned, so the fds can be used for sets in the main block.
 * -1 is returned on error.
 */
int 
accept_new_client_and_connect_new_server ( ComPar *compar )
{
  int client,server;
  struct sockaddr_in clientname;
  struct sockaddr_in servername;
  int size=sizeof ( clientname );
  int i;

  D ( "accept_new_client_and_connect_new_server()\n" );
  
  client=accept ( compar->fd_listen, (struct sockaddr *) &clientname, &size);
  if ( client < 0 )
    {
      perror ( "Client accept" );
      return -1;
    }
  server = socket ( PF_INET, SOCK_STREAM, 0 );
  if ( server < 0 )
    {
      perror ( "socket" );
      return -1;
    }
  else
    {
      struct hostent *hostinfo;

      /*      if ( bind ( server, (struct sockaddr *) &clientname, sizeof(clientname) ) < 0 )
	{
	  perror ( "server bind" );
	} */
      servername.sin_family = AF_INET;
      servername.sin_port = htons ( compar->connectport );
      hostinfo = gethostbyname ( compar->hostname );
      if ( hostinfo == NULL )
	{
	  fprintf ( stderr, "Unknown host: %s\n", compar->hostname );
	  return -1;
	}
      servername.sin_addr = *(struct in_addr *)(hostinfo->h_addr);
      if ( connect (server, (struct sockaddr *)&servername, sizeof(servername) ) < 0 )
	{
	  if ( logmode )
	    {
	      log_timestamp (compar);
	      fprintf ( compar->logfile, "New client connected, but server declined connection.\n" );
	      log_flush(compar);
	    }
	  close(client);
	  return -1;
	}      
    }
  /* ok, here I have 'server' and 'client' which are the fds to connect to
     xlmd (server) and from xdesigner (client) */
  if ( compar->connections==0 ) 
    {
      compar->fd_clients=malloc(sizeof(int));
      compar->fd_servers=malloc(sizeof(int));
      compar->connections=1;
      compar->fd_clients[0]=client;
      compar->fd_servers[0]=server;
      return 0;
    }
  for ( i=0; i<compar->connections; i++ )
    {
      if ( compar->fd_clients[i] == -1 )
	{
	  compar->fd_clients[i]=client;
	  compar->fd_servers[i]=server;
	  return i;
	}
    }
  compar->connections++;
  compar->fd_clients = realloc (compar->fd_clients, sizeof(int)*compar->connections );
  compar->fd_servers = realloc (compar->fd_servers, sizeof(int)*compar->connections );
  compar->fd_clients[compar->connections-1]=client;
  compar->fd_servers[compar->connections-1]=server;
  return compar->connections-1;
}

/*
 * Sends the thing into background.
 */
void 
forkanddive()
{
    pid_t childpid;
    
    D ( "forkanddive()\n" );
    childpid=fork();
    if ( childpid==0 )
        {
            setsid();
            return;
        }
    else if ( childpid==-1 )
        {
            perror ( "Server error in fork()" );
            exit ( EXIT_FAILURE );
        }
    else
        exit ( EXIT_SUCCESS );
}

/*
 * Transmits data. I is the index of client-server connection and
 * mode is 1 if data goes from client to server, and 2 if vice-verso.
 */
int 
transmit_data ( ComPar *compar, int indx, int mode )
{
  char buffer[1000];
  int n,i;
  int src,dest;
  D ( "transmit_data()\n" );

  if ( mode==1 )
    {
      src =compar->fd_clients[indx];
      dest=compar->fd_servers[indx];
    }
  else if ( mode == 2 )
    {
      dest=compar->fd_clients[indx];
      src =compar->fd_servers[indx];
    }
  else
    {
      fprintf ( stderr, "Internal inconsistency in transmit_data.\n" );
      exit(EXIT_FAILURE);
    }
  n=read ( src, buffer, 1000 );
  if ( n==-1 )
    perror ( "write" );
  if ( n==0 ) /* Close socket */
    {
      shutdown ( src,  2 );
      shutdown ( dest, 2 );
    }
  else
    {
      if ( (write ( dest, buffer, n ) != n) && logmode )
	{
	  log_timestamp (global_compar_copy);
	  fprintf ( global_compar_copy->logfile, "Insufficient data written.\n" );
	  log_flush (global_compar_copy);
	}
    }
  if ( logmode )
    {
      log_timestamp (global_compar_copy);
      
      fprintf ( global_compar_copy->logfile, 
		"Data flow on connection %d from %s to %s, %d bytes:\n",
		indx, (mode==1)?"client":"server", (mode==1)?"server":"client", n );
      for ( i=0; i<n; i++ )
	{
	  if ( isprint ( buffer[i] ) )
	    fprintf ( global_compar_copy->logfile, "%2c%c", buffer[i],
		      ((i+1)%16)?' ':'\n' );
	  else
	    fprintf ( global_compar_copy->logfile, "%2.2x%c", 0xff & (unsigned int)buffer[i],
		      ((i+1)%16)?' ':'\n' );
	}
      fprintf ( global_compar_copy->logfile, "\n" );
      log_flush (global_compar_copy);
    }
  return n;
}

/*
 * This function transmits exceptions from the source filedescriptor 
 * to the destination one. 
 */
int 
handle_exception ( int src, int dest )
{
  D ( "handle_exception()\n" );
  return 0;
}

/* Atexit function */
void 
_log_finish ()
{
  stop_log ( global_compar_copy );
}

void 
main ( int argc, char **argv )
{
  ComPar compar;
  int c=1;
  fd_set *sets;
  int dontfork=0;

  strcpy (hostname, "localhost");
  strcpy (logname, "repeater.log");
  while ( c<argc )
    {
      if ( !strcmp ( argv[c], "-host" ) )
	{
	  if ( ++c==argc ) usage(argv[0]);
	  strncpy(hostname, argv[c++],200);
	}
      else if ( !strcmp ( argv[c], "-logfile" ) )
	{
	  if ( ++c==argc ) usage(argv[0]);
	  strncpy(logname, argv[c++],200);
	}
      else if ( !strcmp ( argv[c], "-connectport" ) )
	{
	  if ( ++c==argc ) usage(argv[0]);
	  connectport=atoi(argv[c++]);
	}
      else if ( !strcmp ( argv[c], "-listenport" ) )
	{
	  if ( ++c==argc ) usage(argv[0]);
	  listenport=atoi(argv[c++]);
	}
      else if ( !strcmp ( argv[c], "-nofork" )) 
	{
	  dontfork=1;
	  c++;
	}
      else if ( !strcmp ( argv[c], "-nolog" ))
	{
	  logmode=0;
	  c++;
	}
      else
	usage(argv[0]);
    }

  if ( !dontfork) forkanddive();
  compar.hostname=hostname;
  compar.logname=logname;
  compar.listenport=listenport;
  compar.connectport=connectport;
  compar.connections=0;
  if ( logmode )
    start_log ( &compar );
  global_compar_copy = &compar;
  if ( logmode )
    atexit ( _log_finish );
  
  if ( !create_listen_socket(&compar) )
    {
      perror ( "create_listen_socket:" );
      exit(EXIT_FAILURE);
    }

  /* Sets has 6 elements: 2x read, 2x write and 2x exception. */
  sets=(fd_set *)malloc(sizeof(fd_set)*6);
  for ( c=0; c<6; c++ ) FD_ZERO (sets+c);

  FD_SET ( compar.fd_listen, sets );
  while(1) {
    int selected;

    sets[1]=sets[0];
    sets[3]=sets[2];
    sets[5]=sets[4];
    
    D( "select..." );
    selected=select ( FD_SETSIZE, sets+1, sets+3, sets+5, NULL );
    D( "done.\n"   );
    if ( FD_ISSET ( compar.fd_listen, sets+1 ) )
      { /* The new client has connected. */
	int index;
	
	/* As the new client is accepted a new connection is done to the server. */
	index=accept_new_client_and_connect_new_server(&compar);
	if ( index == -1 )
	  {
	    perror ( "accept_new_client_and_connect_new_server" );
	  }
	else
	  {
	    /* Both new fds are marked for reading and exception events. */
	    if ( logmode )
	      {
		log_timestamp ( &compar );
		fprintf ( compar.logfile, "New client %d.\n", index );
		log_flush ( (&compar) );
	      }
	    FD_SET(compar.fd_clients[index], sets);
	    FD_SET(compar.fd_servers[index], sets);
	    FD_SET(compar.fd_clients[index], sets+4);
	    FD_SET(compar.fd_servers[index], sets+4);
	  }
      }
    else
      {
	int i,ret;
	for ( i=0; i<compar.connections; i++ )
	  {
	    if ( compar.fd_clients[i] == -1 ) continue;
	    if ( FD_ISSET ( compar.fd_clients[i], sets+1 ) )
	      { /* The i'th client is sending data. */
		ret=transmit_data ( &compar, i, 1 );
		if ( ret==0 ) 
		  {
		    FD_CLR ( compar.fd_clients[i], sets );
		    FD_CLR ( compar.fd_servers[i], sets );
		    compar.fd_clients[i]=compar.fd_servers[i]=-1;
		    if ( logmode )
		      {
			log_timestamp ( &compar );
			fprintf ( compar.logfile, "Client %d disconnected.\n", i );
			log_flush ( (&compar) );
		      }
		  }
	      } 
	    if ( FD_ISSET ( compar.fd_servers[i], sets+1 ) )
	      { /* The i'th server is sending data. */
		ret=transmit_data ( &compar, i, 2 );
		if ( ret==0 ) 
		  {
		    FD_CLR ( compar.fd_clients[i], sets );
		    FD_CLR ( compar.fd_servers[i], sets );
		    compar.fd_clients[i]=compar.fd_servers[i]=-1;
		    if ( logmode )
		      {
			log_timestamp ( &compar );
			fprintf ( compar.logfile, "Server %d disconnected.\n", i );
			log_flush ( (&compar) );
		      }
		  }
	      }
	    if ( FD_ISSET ( compar.fd_clients[i], sets+5 ) )
	      { /* The i'th client is making exception. */
		ret=handle_exception ( compar.fd_clients[i], compar.fd_servers[i] );
	      }
	    if ( FD_ISSET ( compar.fd_servers[i], sets+5 ) )
	      { /* The i'th server is making exception. */
		ret=handle_exception ( compar.fd_servers[i], compar.fd_clients[i] );
	      }
	  } /* for */
      } /* if */
  } /* while(1) */
}


