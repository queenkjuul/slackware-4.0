This is a patch from nic.funet.fi
	/pub/OS/Linux/kernel/src/net-source/mail/elm-2.4.24.dif
for Linux.  To apply, cd to your Elm directory and patch < thisfile


--- lib/opt_utils.c
+++ lib/opt_utils.c	1995/08/11 08:59:03
@@ -89,7 +89,9 @@
 # endif
 #endif
 
-#ifndef GETHOSTNAME
+#include <netdb.h>
+
+#if ! defined( GETHOSTNAME) && ! defined(__linux__)
 
 gethostname(cur_hostname,size) /* get name of current host */
 char *cur_hostname;
@@ -140,7 +142,7 @@
 char *hostdom;
 int size;
 {
-	char    buf[64];
+	char    buf[128];
 	FILE    *fp;
 	char    *p;
 
@@ -156,10 +158,18 @@
 	    *p = '\0';
 	}
 	else {
-#ifdef USEGETDOMAINNAME
-	  if (getdomainname(buf, sizeof(buf)) != 0)
-#endif
-	    strfcpy(buf, DEFAULT_DOMAIN, sizeof(buf));
+	  if (gethostname(buf, sizeof(buf)) != 0)
+	    strfcpy(buf, ".no.domain.at.all", sizeof(buf));
+	  else {
+	    struct hostent * hp;
+	    char *tmp;
+	    if ((hp = gethostbyname(buf))) {
+	      tmp = strchr(hp->h_name, '.');
+	      /* We should do something better in case of 'tmp == NULL'.
+		 But this will happen only on misconfigured hosts. */
+	      strfcpy(buf, tmp? tmp : ".no.domain.at.all", sizeof(buf));
+	    } else strfcpy(buf, ".no.domain.at.all", sizeof(buf));
+	  }
 	}
 	if (buf[0] != '\0' && buf[0] != '.') {
 	  *hostdom++ = '.';
