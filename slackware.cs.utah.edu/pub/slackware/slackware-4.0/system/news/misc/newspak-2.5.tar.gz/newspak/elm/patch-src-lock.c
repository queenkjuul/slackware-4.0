This is a patch from nic.funet.fi
        /pub/OS/Linux/kernel/src/net-source/mail/elm-2.4.24.dif
for Linux.  To apply, cd to your Elm directory and patch < thisfile

--- src/lock.c
+++ src/lock.c	1995/08/11 08:59:03
@@ -474,6 +474,7 @@
 	switch (Grab_the_file (flock_fd)) {
 
 	case	FLOCKING_OK:
+	    errno = 0;
 	    goto    EXIT_RETRY_LOOP;
 
 	case	FLOCKING_FAIL:
