/*
global.c: global variables for selectnews

Copyright (C) 1993 Eugene Eric Kim

LAST REVISION: August 25, 1993
*/

#include "global.h"

char alpha[] = "abcdefghijklmnopqrstuvwxyz";

WINDOW *leftscr,*rightscr;
