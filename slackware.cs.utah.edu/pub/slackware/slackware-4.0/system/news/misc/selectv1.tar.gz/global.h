/*
global.h: header file for global.c

Copyright (C) 1993 Eugene Eric Kim

LAST REVISION: September 4, 1993
*/

#ifdef NCURSES
#include <ncurses.h>
#else
#include <curses.h>
#endif

#define VERSION "version 1.0"
#define LEN 65

extern char alpha[];

extern WINDOW *leftscr, *rightscr;
