#!/bin/sh
#
#  ** Script Package for Suck & INN (sp4si) **
#             Read Manual for more
#
# install.news by Peter Sobisch <petersob@gmx.net>
# Syntax: install.sh
# Description: installs the sp4si Package from the current directory.
# Parameters: none
# 

unset NEWSHOME                                  # clear UNSET var
[ -z $HOSTNAME ] && HOSTNAME=`hostname`		# set hostname
DIRECTORIES="${HOME}/etc /var/lib/news/etc /var/news/etc /etc/news/etc /etc/news"
abort ()
{
   echo "Installation aborted."
   echo
   exit 1
}

check_path ()
{
   TEXT=$1      # the question
   DEF=$2       # default value
   VAR=$3       # variable to set
   while true; do
      if [ -s "$DEF" ];then
         eval $VAR=$DEF
         break
      fi
      echo -n "$TEXT : "; read DEF      # redefine DEF
      ([ -n "$DEF" ] && [ ! -s "$DEF" ]) && echo "File '$DEF' not found. Try again!"
   done
}

cat <<EOF

 ******************************************************************************

                     Script Package for suck & INN v0.95b 

 ******************************************************************************

     This package contains some shell scripts, which make your news spool
                   and news admin working a lot easier. 

   This install script will try to include automatically the 'innshellvars'
                  file from the following directories:
              ${DIRECTORIES}.
             If this fails, you have to answer some questions.

  NOTE: you should to run this install.sh script as user 'news', because
            avoiding any permissions troubles in the future !

                   Your current user logname is: $LOGNAME

 ------------------------------------------------------------------------------

EOF

if [ "$LOGNAME" != "news" ]; then
   echo "You must run `basename $0` as 'news' user !"
   abort
fi

echo -n "Trying to include the innshellvars file..."
for DIR in $DIRECTORIES; do
   if [ -z "$NEWSHOME" ]; then
      [ -s "$DIR/innshellvars" ] && . $DIR/innshellvars	1>/dev/null 2>&1
   fi
done
if [ -z "$NEWSHOME" ]; then		# is innshellvars included ?
   echo "not found."
   echo "Sorry, but you have now to answer some questions."
else
   echo "done."
fi

echo

#
# set configuration paths and vars
#

[ -z $NEWSHOME ] && NEWSHOME=`grep ^news /etc/passwd | cut -f6 -d:`
BASE_DIR=${NEWSHOME}/sp4si		# the destination
echo -n "Enter install directory [${BASE_DIR}] : "; read ANS
[ -n "$ANS" ] && BASE_DIR=$ANS

check_path "Enter the INN bin directory" "$NEWSBIN" "INNBIN_DIR"
check_path "Enter full path to active file" "$ACTIVE" "ACTIVE"
check_path "Enter full path to newsfeeds file" "$NEWSFEEDS" "NEWSFEEDS"
check_path "Enter spool main directory" "$SPOOL" "SPOOL_DIR"
check_path "Enter out.going spool directory" "$BATCH" "OUTGOING_DIR"
check_path "Enter UUCP bin directory" "/usr/lib/uucp" "UUCPBIN_DIR"

#
# define filenames to install
#

SITE_DIR=${BASE_DIR}/site
LOG_DIR=${BASE_DIR}/log
DIRECTORIES="$BASE_DIR $SITE_DIR $LOG_DIR"
SCRIPTS="install.sh get.active rebuild.active subscribe\
         spool.news nntp.down nntp.up uucp.batch uucp.cico out.filter"
MANUALS="README ANNOUNCE CHANGES sp4si_de.html sp4si_en.html"

#
# create directories and install files
#

echo 
for DIR in $DIRECTORIES; do
   if [ ! -d "$DIR" ]; then	# only if directory not exists
      echo -n "Creating $DIR..."
      mkdir $DIR
      if [ $? -ne 0 ]; then
         echo "** ERROR: can't make $DIR directory."
         echo "File may exists or permission denied."
         abort
      fi
      echo "done."
   else
      echo "Directory $DIR already exists."
   fi
done

echo
for FILE in $SCRIPTS; do
   echo -n "Installing Script $FILE..."
   cp $FILE ${BASE_DIR}/${FILE}
   if [ $? -ne 0 ]; then
      echo "** ERROR: can't copy $FILE to ${BASE_DIR}."
      echo "Check for destination path and permissions."
      abort
   fi
   chmod 750 ${BASE_DIR}/${FILE}
   echo "done."
done

for FILE in $MANUALS; do
   echo -n "Installing Manual $FILE..." # copy file
   cp $FILE ${BASE_DIR}/${FILE}
   if [ $? -ne 0 ]; then
      echo "** ERROR occured copying $FILE to ${BASE_DIR}."
      echo "Check for destination path and permissions."
      abort
   fi
   chmod 664 ${BASE_DIR}/${FILE}
   echo "done."
done
echo

#
# create config files
#

echo -n "Creating env file..."
cat <<EOF >${BASE_DIR}/env
#!/bin/sh
#
#  ** Script Package for Suck & INN (sp4si) **
#             Read Manual for more
#
# Description: configuration file, will be set during installation 
#              You can change it manually. 
#
# path environment
#
# DON'T REMOVE IT ! This is absolute necessery for running of sp4si.
# If you want to change any path values, you have to mov the correspondent 
# files to the right directory.
BASE_DIR=$BASE_DIR		# location directory of scripts
SITE_DIR=$SITE_DIR	# location of site's active and newsgroups files
LOG_DIR=$LOG_DIR		# directory for log files
SPOOL_DIR=$SPOOL_DIR	# spool directory
NEWSFEEDS=$NEWSFEEDS	# path to newsfeeds file
ACTIVE=$ACTIVE		# path to active file
OUTGOING_DIR=$OUTGOING_DIR      # location of the newsfeeds, rpost need this
PATH=\$PATH:$BASE_DIR:$INNBIN_DIR:$UUCPBIN_DIR	# path for binaries and scripts
# end of path environment

#
# configuration settings
#
# Each entry may be changed. If you remove an entry, the default value will
# be used. If you want to change the following values, so you have to use
# the discriptions beside the options or the manual. All option's names are
# in upper and all values are in lower case. An exception are string options
# such a FILTER_STRIP parameter.
#

#
# spool.news settings
#
MULTI=yes	# 'yes' = multitasking spool (asynchronous), 'no' = synchronous
MAIL_REPORT=error	# 'error'=only error, 'yes'=ever send, 'no'=no mail
MAIL_TO=news		# email address of the report recipient 
NEWS_REPORT=yes		# 'error'=only error, 'yes'=ever send, 'no'=no news
NEWS_TO=${HOSTNAME}.spool	# newsgroups to send the report to

#
# filter settings
#
# the following header fields will be stripped from outgoing messages
FILTER_STRIP='Path: NNTP-Posting-Host: Xref: X-Server-Date'

#
# subscribe settings
#
# 'yes' enables and 'no' disables an option :-)
NEWSRC=yes		# for .newsrc file, it works with the most news reader
NEWSRC_KRN=no		# for krn (kde) news reader 
NEWSRC_XSP4SI=no	# for xsp4si (the GUI for sp4si) GUI subcribing
LAST=-10		# count of articles to download if new subscribed

#
# nntp.down settings
#
SUCK_OPTIONS="" 	# insert additional options or parameters (man suck)
LOCAL_POST="rnews"	# how to post articles locally: 'rnews' or 'innxmit'

# end of env file
EOF
echo "done."

ANS=Y
if [ -s "${BASE_DIR}/newshosts" ]; then
   echo -n "File ${BASE_DIR}/newshosts exists. Overwrite [y/N] : "; read ANS
fi
#
if [ "$ANS" = "y" -o "$ANS" = "Y" ]; then
   echo -n "Creating newshosts file..."
   cat <<EOF >${BASE_DIR}/newshosts
#
#  ** Script Package for Suck & INN (sp4si) **
#          Read Manual for more
#
# Description: includes hosts table with the correspondent site names
#              and other additional options.
#        NOTE: THE SITENAMES SHOULD BE THE SAME AS IN YOUR NEWSFEEDS FILE !
#
# Entry syntax: 
# <site> <hostname> [up/down] [ [packer] [ [gupmail] [passwd] ] ]
#
# where:
#     <site> - site name,   
# <hostname> - DNS name or address of the remote news host
#  <up/down> - up/down method: nntp or uucp separated by '/'.
#              f.e: nntp/uucp posts the outgoing articles to remote host
#              with nntp and downloads new articles via uucp.
#              Only one uucp or nntp spools up AND down the specified method.
#              If none, nntp will be choosen.
# uucp options:
#     <pack> - the packer, should be used to pack outgoing uucp batches:
#              valid entries are: 'compress', 'gzip' and 'cat'.
#              Each other will be set to default: 'compress'.
#  <gupmail> - eMail address of the providers gup running on the news server
#   <passwd> - your sites password for your gup account (ask your provider)  
#
# Examples:
#
# stardiv  news.stardiv.de
# allcon   news.allcon.net  nntp/uucp  gzip     gup@news.allcon.net  secret12
# myuucp   uucp.domain.com  uucp       compress gup@uucp.domain.com  gup4me
#
# After you have add a new host you should rerun 'get.active' script
# to get the active files.
#
EOF
   echo "done."
else
   echo "Skiped."
fi

#
# create local newsgroup
#

ANS=Y
if [ -s "${SITE_DIR}/localhost.active" ]; then
   echo -n "File ${SITE_DIR}/localhost.active exists. Overwrite [y/N] : "
   read ANS
fi
#
if [ "$ANS" = "y" -o "$ANS" = "Y" ]; then
   echo -n "Creating localhost.active file..."
   cat <<EOF >${SITE_DIR}/localhost.active
$HOSTNAME.test 0000000000 0000000001 y
$HOSTNAME.spool 0000000000 0000000001 y
EOF
   echo "done."
else
   echo "Skiped."
fi

ANS=Y
if [ -s "${SITE_DIR}/localhost.newsgroups" ]; then
   echo -n "File ${SITE_DIR}/localhost.newsgroups exists. Overwrite [y/N] : "
   read ANS
fi
#
if [ "$ANS" = "y" -o "$ANS" = "Y" ]; then
   echo -n "Creating localhost.newsgroups file..."
   cat <<EOF >${SITE_DIR}/localhost.newsgroups
$HOSTNAME.test		local test newsgroup, it's very useable 
$HOSTNAME.spool		local newsgroup, where the spool reports will be sent
EOF
   echo "done."
else
   echo "Skiped."
fi

echo -n "Setting permissions..."
chmod 664 ${BASE_DIR}/env ${BASE_DIR}/newshosts \
          ${SITE_DIR}/localhost.newsgroups ${SITE_DIR}/localhost.newsgroups
echo "done."

echo
echo -e "\rInstallation DONE. Now read the manual...please :-)"
