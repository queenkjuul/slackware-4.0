/*  VER 106   TAB P   $Id: doit.c,v 1.8 1996/11/14 17:09:25 src Exp $
 *
 *  an NNTP posting client
 */

#include "postit.h"
#include "proto.h"
#include "nntp.h"

#include <signal.h>

/*
 *  local functions
 */
static void do_authinfo(char *username,char *password);
static void do_mode_reader();
static void set_signals();

/*
 *  do it
 */
int doit()
{
    int ret;
#ifdef SPEEDSTATS
    time_t starttime, endtime;
#endif
    char *article_name;

    log_open();

    log_msg(L_DEBUG,"server: %s, spool: %s", hostname, spoolname);

    /* see if there are any articles batched up */
    if (!(article_name = despool_line())) {
	log_msg(L_DEBUG,"nothing in spool queue");
    }

    /* set up the connection to the server */
    if (!noaction_flag) switch (ret = open_server(hostname)) {
    case -1 :
	return 3;
    case OK_CANPOST:
	++post_allowed;
	log_msg(L_DEBUG,"OK, can post");
	break;
    case OK_NOPOST:
	log_msg(L_DEBUG,"OK, but cannot post");
	break;
    default:
	log_msg(L_ERR,"can't talk to '%s': got response code %d", hostname, ret);
	return 4;
    }

    /* if authinfo details supplied, then use 'em */
    if (ai_username)
	do_authinfo(ai_username,ai_password);

    /* switch INN to nnrpd instead of innd if needed */
    if (mode_reader_flag)
	do_mode_reader();

#ifdef SPEEDSTATS
    starttime = time((time_t *) 0);
#endif

    set_signals();

    /* now put the actual articles */
    if (article_name)
	despool(article_name);

#if 0 /* BUG: */
#ifdef SPEEDSTATS
    endtime = time((time_t *) 0);
#endif
#endif

#ifdef SPEEDSTATS
    endtime = time((time_t *) 0);
#endif

    /* time for goodbye */
    if (!noaction_flag)
	close_server();

    log_msg(L_INFO,"posted %d article%s, %d duplicate%s, %d missing",
			    newart, newart==1 ? "":"s",
			    dupart, dupart==1 ? "":"s",
			    misart);

#ifdef SPEEDSTATS
    if (totalsize > 0) {
	log_msg(L_INFO,"average transfer speed %ld cps",
		totalsize / (starttime == endtime ? 1 : endtime - starttime));
    }
#endif

    /* reached so far: everything is all right */
    return 0;
}

/*
 *  check in the authinfo username and password with the
 *  server 
 */
static void do_authinfo(char *username,char *password)
{
    char buf[NNTP_STRLEN];

    /* send the username to the server */
    sprintf(buf, "AUTHINFO USER %s", username);
    put_server_nntp(buf);
    if (noaction_flag) return;

    /* get the response and check it's okay */
    get_server_nntp(buf, sizeof(buf));
    if (atoi(buf) != NEED_AUTHDATA) {
	log_msg(L_ERR,"NNTP authinfo protocol error: got '%s'", buf);
	unlock_exit(4);
    }
		    
    /* send the password to the server */
    sprintf(buf, "AUTHINFO PASS %s", password);
    put_server_nntp(buf);

    /* get the response and check it's okay */
    get_server_nntp(buf, sizeof(buf));
    if (atoi(buf) != OK_AUTH) {
	log_msg(L_ERR,"NNTP authorization failed: got '%s'", buf);
	unlock_exit(4);
    }
}


/*
 *  send mode reader command to INN to switch to nnrpd
 *  so we can do a NEWNEWS.
 */
static void do_mode_reader()
{
    char buf [NNTP_STRLEN];

    /* send the command to the server */
    put_server_nntp("MODE READER");
    if (noaction_flag) return;

    /* get the response and check it's okay */
    get_server_nntp(buf,sizeof(buf));

    switch (atoi(buf)) {
    case OK_CANPOST :
    case OK_NOPOST :
	break;
    default :
	log_msg(L_ERR,"NNTP mode reader protocol error: got '%s'", buf); 
	unlock_exit(4);
    }
}

/*
 *  signal handler to report signal in log and possibly
 *  submit remaining batch to news and dump uncollected message ids.
 */
static RETSIGTYPE interrupt(int signo)
{
    log_msg(L_ERR,"received signal %d", signo);

    /* remove any locks */
    unlock_exit(1);
}

/*
 *  set up signal handler to catch appropriate signals.
 */
static void set_signals()
{
    signal(SIGHUP, interrupt);
    signal(SIGINT, interrupt);
    signal(SIGQUIT, interrupt);
    signal(SIGTERM, interrupt);
}

