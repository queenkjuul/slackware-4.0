/*  VER 100   TAB P   $Id: main.c,v 1.13 1996/11/14 17:09:25 src Exp $
 *
 *  an NNTP posting client
 *
 *  by:
 *   Egil Kvaleberg
 *   Husebybakken 14A
 *   0379 OSLO 
 *   Norway    
 *   egilk@sn.no
 */

#include "postit.h"
#include "proto.h"

#include <getopt.h>

static void pickargs(int argc,char *argv[]);

/*
 *  main 
 */
int main(int argc, char **argv)
{
    char *p;
    int ok;

    /* initialize and set the name of the program */
    for (pname=argv[0]; (p=strchr(pname,'/')); ) pname = p+1;
    spooldir = SPOOLDIR;

    /* there may be an environment variable */
    hostname = getenv("NNTPSERVER");

    /* parse the args */
    pickargs(argc,argv);

    ok = doit();

    /* remove locks */
    unlock();

    return ok;
}

/*
 * pick arguments from command line
 */
static void pickargs(int argc,char *argv[])
{
    int c;
    char *p;
	
    while ((c = getopt(argc, argv, "a:df:il:mnoprs:t:v")) != EOF) {
	switch (c) {
	case 'a':			/* do an authinfo */
	    if ((p=strchr(optarg, '/'))) {
		ai_username = optarg;
		*p++ = '\0';
		ai_password = p;
	    } else {
		fprintf(stderr, "invalid username/password");
		goto usage;
	    }
	    break;
	case 'd':			/* debugging on */
	    debug_flag++;
	    break;
	case 'f':			/* folder */
	    folder = optarg;  
	    break;
	case 'i':			/* inn mode */
	    inn_flag++;
	    break;
	case 'l':			/* logfile */
	    logfile = optarg; 
	    break;
	case 'n':			/* do nothing */
	    noaction_flag++;
	    break;
	case 'm':			/* skip message ID */
	    nomsgid_flag++;
	    break;
	case 'o':			/* keep .old */
	    keep_old_flag++;
	    break;
	case 'p':			/* keep "Path" */
	    keep_path_flag++;
	    break;
	case 'r':			/* do a 'MODE READER' */
	    mode_reader_flag++;
	    break;
	case 's':			/* spool */
	    spooldir = optarg;			       
	    break;
	case 't':			/* timeout in seconds */
	    timeout = atoi(optarg);		       
	    break;
	case 'u':			/* no unlock by force */
	    noforce_flag++;
	    break;
	case 'v':			/* version */
	    printf("%s version %s\n", argv[0], VERSION);
	    unlock_exit(0); /* that's ok */
	    break;
	default:
	  usage:
	    fprintf(stderr,"usage: %s [-a username/password]\n", pname);
	    fprintf(stderr,"       [-d] [-v] [-r] server {spool}\n");
	    unlock_exit(2);
	}
    }

    /* get server name */
    if (optind >= argc) {
	if (!hostname) {
	    fprintf(stderr, "server name missing\n");
	    goto usage;
	}
    } else {
	hostname = argv[optind++];
    
	/* get spool name */
	if (optind < argc) {
	    spoolname = argv[optind++];
	} else {
	    spoolname = hostname;
	}

	if (optind < argc) {
	    fprintf(stderr, "excess arguments\n");
	    goto usage;
	}
    }
}
