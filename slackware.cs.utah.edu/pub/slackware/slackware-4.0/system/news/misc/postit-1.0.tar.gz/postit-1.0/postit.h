/*  VER 048  TAB P   $Id: postit.h,v 1.14 1996/11/14 17:09:25 src Exp $
 *
 *  common header file
 */

#if HAVE_CONFIG_H
#include "config.h"
#endif

#include "version.h"
#include "postitconf.h"

/* standard stuff */
#include <stdio.h>
#include <sys/types.h>
#include <ctype.h>

#if STDC_HEADERS
  #include <stdlib.h>
  #include <string.h>
#else 
  #if HAVE_STRINGS_H
    #include <strings.h>
  #endif
#endif

#if HAVE_UNISTD_H
  #include <unistd.h>
#endif

#if HAVE_LIMITS_H
  #include <limits.h>
#endif

#if TIME_WITH_SYS_TIME
  #include <time.h>
  #include <sys/time.h>
#else
  #if HAVE_SYS_TIME_H
    #include <sys/time.h>
  #else
    #include <time.h>
  #endif
#endif

/* 
 *  names
 */
char *hostname; 		/* current NNTP server */
char *spoolname;		/* outgoing spool */
char *pname;			/* this program */
char *spooldir; 		/* news spool */

/* 
 *  article counters 
 */
int dupart;			/* duplicate articles */
int misart;			/* missing articles */
int newart;			/* new articles */
long totalsize; 		/* total size of articles */

/* 
 *  options 
 */
int debug_flag;
int noaction_flag;
int nomsgid_flag;
int no_id_load_flag;
int inn_flag;
int mode_reader_flag;
int keep_old_flag;
int keep_path_flag;
char *ai_username;
char *ai_password;
char *logfile;
char *folder;
int timeout;
int noforce_flag;

/* 
 *  misc
 */
int post_allowed;

/* 
 *  log message types 
 */
#define L_ERR	 '?'
#define L_ERRno  '!'
#define L_INFO	 '&'
#define L_DEBUG  '='
#define L_DEBUG3 '3'
#define L_GET	 '<'
#define L_PUT	 '>'
