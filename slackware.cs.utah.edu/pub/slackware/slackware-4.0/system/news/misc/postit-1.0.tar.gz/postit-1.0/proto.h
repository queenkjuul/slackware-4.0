/*  VER 012  TAB P   $Id: proto.h,v 1.5 1996/11/14 17:09:25 src Exp $
 *
 *  postit function prototypes
 */

/* doit.c */
int doit();

/* despool.c */
void despool(char *article_name);
char *despool_line(void);

/* putarticle.c */
char *submit_article(char *articlename);

/* lock.c */
void lock(char *dir_name,char *lock_name);
int force_unlock(char *name);
void unlock(void);
void build_filename(char *where,char *arg1,...);  
void unlock_exit(int n);

/* logmsg.c */
void log_open();
void log_msg(int type, const char *fmt, ...);

/* server.c */
int open_server(char *hostname);
void close_server();
void get_server_nntp(char *line, int size);
void put_server_nntp(char *line);
void put_server_msg(char *line,int add_crlf);

/* socket.c */
int socket_open(char *hostname, char *service, FILE *socket_f[]);
void socket_close(FILE *socket_f[]);
void gets_socket(char *line, int size, FILE *socket_f[]);
void put_socket(char *line, int crlf, FILE *socket_f[]);

