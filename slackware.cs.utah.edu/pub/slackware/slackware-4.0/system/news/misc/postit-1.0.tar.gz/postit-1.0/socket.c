/*  VER 030  TAB P   $Id: socket.c,v 1.6 1996/07/14 17:46:46 src Exp $
 *
 *  NOTE: must rewrite...
 *
 *  open a socket connection and read/write to nntp server
 *
 */

#include "postit.h"
#include "proto.h"
#include "nntp.h"

#include <errno.h>
#include <signal.h>
#include <setjmp.h>

#if !(HAVE_SOCKET)
#error program requires socket functionality
#endif

#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#ifndef INADDR_NONE
  #define INADDR_NONE 0xffffffff
#endif

/*
 * tcp_open - Open a tcp connection to 'host' for service 'service',
 * returning a file descriptor for the socket.
 */
int tcp_open(char *host, char *service)
{
    int sockfd;
    int on = 1;
    unsigned long inaddr;
    struct servent *sp;
    struct hostent *hp;

    struct sockaddr_in serv_addr;
    struct servent serv_info;
    struct hostent host_info;

    memset(&serv_addr, 0, sizeof (serv_addr));
    serv_addr.sin_family = AF_INET;

    /* get service information */
    if ((sp = getservbyname(service, "tcp")) == NULL) {
	log_msg(L_ERR,"unknown service %s/tcp", service);
	return -1;
    }
    serv_info = *sp;
    serv_addr.sin_port = sp->s_port;

    /* try to convert host name as dotted decimal */
    if ((inaddr = inet_addr (host)) != INADDR_NONE) {
	memcpy (&serv_addr.sin_addr, &inaddr, sizeof (inaddr));
	host_info.h_name = NULL;
    } else {
	/* if that failed, then look up the host name */
	if ((hp = gethostbyname(host)) == NULL) {
	    log_msg(L_ERR,"host name error: '%s'", host);
	    return -1;
	}
	host_info = *hp;
	memcpy (&serv_addr.sin_addr, hp->h_addr, hp->h_length);
    }

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	log_msg(L_ERRno,"can't create TCP socket");
	return -1;
    }

    if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) {
	log_msg(L_ERRno,"can't connect to server '%s'", host);
	close(sockfd);
	return -1;
    }

    if (setsockopt(sockfd, SOL_SOCKET, SO_KEEPALIVE,	  
					(char *) &on, sizeof (on)) < 0)
	log_msg(L_ERRno,"can't set KEEPALIVE on socket");

    return sockfd;
}

/*
 *  open a TCP/IP socket 
 */
int socket_open(char *hostname, char *service, FILE *socket_f[])
{
    int r_fd;
    int w_fd;

    /* make the connection */
    if ((r_fd = tcp_open(hostname, service)) < 0)
	return -1;
    w_fd = dup(r_fd);

    /* enable buffering of data */
    if ((socket_f[0] = fdopen(r_fd, "r")) == NULL) {
	log_msg(L_ERRno,"can't fdopen socket for read");
	close(r_fd);
	close(w_fd);
	return -1;
    }

    if ((socket_f[1] = fdopen(w_fd, "w")) == NULL) {
	log_msg(L_ERRno,"can't fdopen socket for write");
	fclose(socket_f[0]);
	close(w_fd);
	return -1;
    }
	
    return 0;
}

/*
 *  close a socket 
 */
void socket_close(FILE *socket_f[])
{
    fclose(socket_f[0]);
    fclose(socket_f[1]);
}

/*
 *  alarm handler
 */
static jmp_buf env_alrm;

static void sig_alrm(int signo)
{
    longjmp(env_alrm, 1);
}

/*
 *  read from socket
 *  strip CRLF 
 */
void gets_socket(char *line, int size, FILE *socket_f[])
{
    int e;
    static int tcp_time; 

    /* set up an alarm to handle socket timeout */
    if (setjmp(env_alrm)) {
	alarm(0);			/* reset alarm clock */
	signal(SIGALRM, SIG_DFL);
	errno = EPIPE;
	log_msg(L_ERR,"read error on server socket");
	unlock_exit(1);
    }

    signal(SIGALRM, sig_alrm);
    tcp_time = timeout ? timeout : TIMEOUT;
    alarm(tcp_time);

    /* read line */
    fgets(line, size, socket_f[0]);

    /* reset the alarm */
    e = errno;
    alarm(0);
    signal(SIGALRM, SIG_DFL);
    errno = e;

    /* report any error */
    if (ferror(socket_f[0])) {
	log_msg(L_ERRno,"read error on server socket");
	unlock_exit(1);
    }
}

/*
 *  write to a socket
 *  possibly with CRLF
 */
void put_socket(char *line, int crlf, FILE *socket_f[])
{
    fputs(line,socket_f[1]);
    if (crlf) fputs("\r\n",socket_f[1]);
    fflush(socket_f[1]);

    if (ferror(socket_f[1])) {
	log_msg(L_ERRno,"write error on server socket");
	unlock_exit(1);
    }
}
