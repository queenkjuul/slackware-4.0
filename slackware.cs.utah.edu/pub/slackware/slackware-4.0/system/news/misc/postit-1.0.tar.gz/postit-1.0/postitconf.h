/*  TAB P   VER 021   $Id: postitconf.h,v 1.4 1996/11/14 17:09:25 src Exp $
 *
 *  postit configuration
 *  tune as required
 */

/*
 *  timeouts
 */
#define TIMEOUT     600     /* for TCP/IP operations: 10 minutes */
#define LOCKTIME    600     /* for lockfile: 10 minutes */
#define LOCKDELTA     5     /* poll cycle: 5 seconds */

/*
 *  time transfers?
 */
#define SPEEDSTATS	 

