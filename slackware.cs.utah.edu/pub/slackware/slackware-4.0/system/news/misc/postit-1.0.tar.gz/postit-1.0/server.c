/*  VER 030  TAB P   $Id: server.c,v 1.5 1996/07/14 17:46:46 src Exp $
 *
 *  NNTP server interface
 */

#include "postit.h"
#include "proto.h"
#include "nntp.h"

#include <errno.h>

/*
 *  currently open socket pair, for read and write
 */
FILE *socket_f[2];

/*
 *  open an NNTP server connection
 *  returns servers initial response code  
 */
int open_server(char *hostname)
{
    char line[NNTP_STRLEN];

    /* first try and make the connection */
    if ((socket_open(hostname, "nntp", socket_f)) < 0)
	return -1;
	
    log_msg(L_INFO,"connected to nntp server at %s", hostname);

    /* greeting */
    get_server_nntp(line,sizeof (line));

    /* banner code */
    return atoi(line);
}

/*
 *  close NNTP connection
 */
void close_server()
{
    char line[NNTP_STRLEN];

    put_server_nntp("QUIT");
    get_server_nntp(line,sizeof(line));

    socket_close(socket_f);
}

/*
 *  read a line from server
 */
void get_server_nntp(char *line, int size)
{
    char *p;

    if (noaction_flag) return;

    gets_socket(line, size, socket_f);

    /* no CRLF */
    if ((p = strchr(line,'\r'))) *p = '\0';
    if ((p = strchr(line,'\n'))) *p = '\0';

    log_msg(L_GET,"%s", line);
}

/*
 *  write an NNTP command line to server
 */
void put_server_nntp(char *line)
{
    log_msg(L_PUT,"%s", line);
    if (noaction_flag) return;

    put_socket(line, 1, socket_f);
}

/*
 *  write message part to server, 
 *  a newline may or may not be added
 */
void put_server_msg(char *line,int add_crlf)
{
    if (debug_flag >= 2) log_msg(L_PUT,"%s",line);
    if (noaction_flag) return;

    put_socket(line, add_crlf, socket_f);
}
