/*  VER 004  TAB P   $Id: news.h,v 1.2 1996/11/14 17:09:25 src Exp $
 *
 *  news system filename "common knowlegde"
 *
 *  NOTE: shouldn't normally need to change these
 */

/* 
 *  outgoing  
 */
#define OUT_GOING	"/out.going/"
#define C_TOGO		"/togo" 	/* Cnews */
#define C_LOCK		"LOCKb" 	/* Cnews */
#define I_LOCK		"LOCK." 	/* Inn */

/* 
 *  general
 */
#define _TMP		".tmp"
#define _OLD		".old"

