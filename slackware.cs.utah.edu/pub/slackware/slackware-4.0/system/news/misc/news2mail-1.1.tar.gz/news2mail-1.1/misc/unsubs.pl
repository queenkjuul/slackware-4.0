#!/usr/local/bin/perl
# $Id: unsubs.pl,v 1.2 1997/11/09 11:48:55 alexsh Exp $
#
# Syntax:
# unsubs groupfile group email
#

require "$ENV{HOME}/news2mail/misc.pl";

##########################################################################
################################# Main

$cfgfile = shift;
&ReadConfig($cfgfile);

$group = shift;
$email = shift;

exit if(!defined $emails{$group});
@emails = grep(!/^$email$/, @{$emails{$group}});
if($#emails == -1)
    { delete $emails{$group}; }
else
    { $emails{$group} = \@emails; }

&WriteConfig($cfgfile);
