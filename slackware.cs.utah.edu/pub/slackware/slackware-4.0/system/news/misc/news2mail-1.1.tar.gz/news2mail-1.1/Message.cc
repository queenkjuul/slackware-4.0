#include <string.h>
#include "Message.h"
#include "defines.h"

void CMessage::GetHeader(const char *header, char *buf)
{
    head.Rewind();

    char line[BUFSIZE];
    while(!head.eof())
    {
        head.getline(line, BUFSIZE-1);
        if(strncmp(line, header, strlen(header)) == 0)
            break;
    }
    if(head.eof())
        buf[0] = '\0';
    else
        strcpy(buf, line + strlen(header));
}
