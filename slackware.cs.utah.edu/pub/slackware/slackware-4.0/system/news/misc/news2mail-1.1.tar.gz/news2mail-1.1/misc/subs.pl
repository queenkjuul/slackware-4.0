#!/usr/local/bin/perl
# $Id: subs.pl,v 1.1 1997/11/09 02:13:16 alexsh Exp $
#
# Syntax:
# subs groupfile group email
#

require "$ENV{HOME}/news2mail/misc.pl";

##########################################################################
################################# Main

$grpfile = shift;
$group = shift;
$email = shift;
&ReadConfig($grpfile);

if($DEFMETHOD eq "newnews")
{
    chop($date = `date +%y%m%d`);
    chop($time = `date +%H%M%S`);

    if(!defined $emails{$group})
    {
	$dates{$group} = $date;
	$times{$group} = $time;
    }
} elsif($DEFMETHOD eq "artnum") {
    $artnums{$group} = -1;
}
push @{$emails{$group}}, $email;

&WriteConfig($grpfile);
