#ifndef __SOCKET_H__AS
#define __SOCKET_H__AS

#include <stdarg.h>

#define READ_TIMEOUT 180  // The timeout for the Receive function

class CSocket
{
public:
    CSocket() {}
    ~CSocket() {}

    int Connect(const char *host, unsigned short port);
    int Disconnect();

    int Send(char *str, ...);
    int Receive(char *str);

protected:
    int sockfd;
};

#endif //__SOCKET_H__AS

