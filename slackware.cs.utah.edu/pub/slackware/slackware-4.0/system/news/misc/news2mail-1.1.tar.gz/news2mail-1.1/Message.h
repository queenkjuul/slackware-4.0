#ifndef __MESSAGE_H
#define __MESSAGE_H

#include "Temp.h"

class CMessage
{
public:
    // (Con|De)structors
    CMessage() {}
    ~CMessage() {}

    // Methods
    void Init();

    void GetHeader(const char *header, char *buf);

    // Data
    CTemp head, body;
};

inline void CMessage::Init()
{
    head.Clear();
    body.Clear();
}

#endif //__MESSAGE_H
