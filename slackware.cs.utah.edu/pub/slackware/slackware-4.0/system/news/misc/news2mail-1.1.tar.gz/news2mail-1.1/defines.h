#ifndef __DEFINES_H
#define __DEFINES_H

// Configurable options
//#define USE_VSNPRINTF

// General definitions
#define BUFSIZE 4096

#define CONFIG_FILE "config.txt"
#define GROUPS_FILE "groups.txt"

// Exit codes
#define NOCFGFILE        1
#define NOGRPFILE        2
#define CCNSERVER        3
#define CCSSERVER        4
#define NSERVERERROR        5
#define SSERVERERROR        6

#endif //__DEFINES_H
