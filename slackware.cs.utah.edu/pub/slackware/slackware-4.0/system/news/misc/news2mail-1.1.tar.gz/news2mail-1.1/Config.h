#ifndef __CONFIG_H
#define __CONFIG_H

#include "Log.h"
#include "Group.h"

class CConfig
{
public:
    // (Con|De)structors
    CConfig() : nntpserver(NULL), nntpport(0),
        smtpserver(NULL), smtpport(0),
        from(NULL), to(NULL), logfile(NULL) {}
    ~CConfig();

    // Methods
    int ReadConfig(const char* filename);
    int ReadGroups(const char* filename);
    int WriteGroups(const char* filename);

    // Data
    char *nntpserver;
    unsigned short nntpport;
    char *smtpserver;
    unsigned short smtpport;
    char *from, *to;
    char *logfile;
    CList<CGroup> groups;
};

#endif //__CONFIG_H
