/*
SimpleNews   NNTP reader for USENET news
Copyright (C) 1997  J. Howard Benson

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


flames, praise, job offers to:

  J. Howard Benson
  PO Box 60731
  Fairbanks, AK  99706

  hbenson@polarnet.fnsb.ak.us

*/

#include "defs.h"
#include "defines.h"
#include "net.h"
#include "server.h"


int server_window(void)
{
  char line[256];
  char rc_file[80];
  int in, count;
  char result_text[128] = "";
  int result_code, temp;
  static short int current_server;
  static char server_list[10][STRINGSIZE];
  static int last_server;
  extern char call_message[80];
  extern char return_message[80];
  extern char organization[STRINGSIZE];
  extern char email[STRINGSIZE];
  extern char true_email[STRINGSIZE];
  extern char name[STRINGSIZE];
  extern char sig_file[STRINGSIZE];
  extern char server[STRINGSIZE];
  extern char *home;
  extern int lines, columns;
  extern FILE *in_stream, *mainrc;
  extern short int posting, mainrc_open;


  if(!strcmp(call_message, "start"))
    {
      if((strlen(home) + strlen(RCFILE)) > 80)
	{
	  strcpy(return_message, "error: can not open ~");
	  strcat(return_message, RCFILE);
	  return 0;
	}

      sprintf(rc_file, "%s%s", home, RCFILE);
      if(open_file(&mainrc, rc_file, "a+", &mainrc_open))
	{
	  sprintf(return_message, "error: can not open ~%s" , RCFILE);
	  return 0;
	}
      rewind(mainrc);
      for(current_server = 0; current_server <= 9; current_server++)
	server_list[current_server][0] = 0;
      current_server = 0;
      last_server = -1;
      while(fgets(line, 80, mainrc) != NULL)
	{
	  count = strlen(line);
	  line[count - 1] = 0;          /*  kill newline */
	  if(!strncmp(line, "server ", 7))
	    {
	      strncpy(server_list[current_server], line + 7, STRINGSIZE);
	      server_list[current_server][STRINGSIZE - 1] = '\0';
	      if(current_server < 9)
		last_server = ++current_server - 1;
	    }
	  if(!strncmp(line, "organization ", 13))
	    {
	      strncpy(organization, line + 13, STRINGSIZE);
	      organization[STRINGSIZE - 1] = '\0';
	    }
	  if(!strncmp(line, "email ", 6))
	    {
	      strncpy(email, line + 6, STRINGSIZE);
	      email[STRINGSIZE - 1] = '\0';
	    }
	  if(!strncmp(line, "name ", 5))
	    {
	      strncpy(name, line + 5, STRINGSIZE);
	      name[STRINGSIZE - 1] = '\0';
	    }
	  if(!strncmp(line, "sig_file ", 9))
	    {
	      strncpy(sig_file, line + 9, STRINGSIZE);
	      sig_file[STRINGSIZE - 1] = '\0';
	    }
	}

      current_server = 0;

      if(last_server < 0)
	{
	  erase();
	  move((lines - 1), 0);
	  addstr("enter NNTP server: ");
	  refresh();
	  echo();
	  wgetnstr(stdscr, line, STRINGSIZE - 1);
	  noecho();
	  if(*line)
	    {
	      last_server = 0;
	      strcpy(server_list[0], line);
	    }
	  else
	    {
	      endwin();
	      exit(1);
	    }
	}
	  

      close_file(mainrc, &mainrc_open);
      if(getenv("LOGNAME") != NULL)
	strncpy(true_email, getenv("LOGNAME"), STRINGSIZE - 2);
      else
	strncpy(true_email, getenv("USER"), STRINGSIZE - 2);
      strcat(true_email, "@");
      if(!gethostname(line, sizeof(line)))
	{
	  strncat(true_email, line, (STRINGSIZE - strlen(true_email)));
	  true_email[STRINGSIZE - 1] = '\0';
	}
      if(!*email)
	strcpy(email, true_email);

    }
  else if(!strcmp(call_message, "q"))     /* q is for quit */
    {
      if(update_rcfile(server_list))
	strcat(return_message, "error: file error");
      manage_connection(1, result_text, sizeof(result_text));
      return 0;
    }
  else                     /* we're returning from the group screen.. */
    manage_connection(1, result_text, sizeof(result_text));

  strcpy(server, VERSION);  /* this shows the program name and version */

  update_screen(current_server, server_list, result_text);
  for(;;)
    {
      in = getch();
      switch(in) {

      case ERR:
	strcpy(return_message, "error: keyboard input");
	return 0;

      case KEY_UP:
      case 'k':
	if(current_server > 0)
	  current_server--;
	update_screen(current_server, server_list, "");
	break;

      case KEY_DOWN:
      case 'j':
	if(current_server < last_server)
	  current_server++;
	update_screen(current_server, server_list, "");
	break;

      case 'a':
	if(last_server < 9)
	  {
	    update_screen(current_server, server_list,
			  "enter new NNTP server: ");
	    echo();
	    wgetnstr(stdscr, line, STRINGSIZE - 1);
	    noecho();
	    if(*line)
	      {
		current_server = ++last_server;
		strcpy(server_list[current_server], line);
	      }
	    update_screen(current_server, server_list, "");

	  }
	else
	  update_screen(current_server, server_list,
			"10 servers maximum");
	break;

      case 'e':
	update_screen(current_server, server_list,
		      "enter your e-mail address: ");
	echo();
	wgetnstr(stdscr, line, STRINGSIZE - 1);
	noecho();
	if(*line)
	  strcpy(email, line);
	update_screen(current_server, server_list, "");
	break;

      case 'h':
	server_help_screen();
	getch();              /* press any key to continue..  */
	update_screen(current_server, server_list, "");
	break;

      case 'n':
	update_screen(current_server, server_list,
		      "enter your name: ");
	echo();
	wgetnstr(stdscr, line, STRINGSIZE - 1);
	noecho();
	if(*line)
	  strcpy(name, line);
	update_screen(current_server, server_list, "");
	break;

      case 'o':
	update_screen(current_server, server_list,
		      "enter your organization: ");
	echo();
	wgetnstr(stdscr, line, STRINGSIZE - 1);
	noecho();
	strcpy(organization, line);
	update_screen(current_server, server_list, "");
	break;

      case 'q':
	if(update_rcfile(server_list))
	  strcpy(return_message, "error: file error");
	else
	  strcpy(return_message, "");
	return 0;

      case 'r':
	if(last_server == -1)
	  break;
	for(count = current_server; count < last_server; count++)
	  strcpy(server_list[count], server_list[count+1]);
	strcpy(server_list[last_server], "");
	if(--last_server != -1)
	  {
	    if(current_server > last_server)
	      current_server--;
	  }
	update_screen(current_server, server_list, "");
	break;

      case 's':
	update_screen(current_server, server_list,
		      "enter your signature file: ");
	echo();
	wgetnstr(stdscr, line, STRINGSIZE - 1);
	noecho();
	if(line[0] == '~')
	  sprintf(sig_file, "%s%s", home, line+1);
	else
	  strcpy(sig_file, line);
	update_screen(current_server, server_list, "");
	break;

      case KEY_RIGHT:
      case '\n':
      case '\r':
	if(last_server == -1)
	  {
	    update_screen(current_server, server_list, "no servers defined");
	    break;
	  }

	display_footer("connecting to server");
	strcpy(server, server_list[current_server]);

	switch(manage_connection(0, server_list[current_server], STRINGSIZE)) {
	case 0:
	  if(fgets(line, sizeof(line), in_stream) == NULL)
	    {
	      strcpy(return_message, "error: network error");
	      return 0;   /* He's dead, Jim.. */
	    }

	  strncpy(result_text, line, 3);
	  result_text[3] = '\0';
	  result_code = atoi(result_text);
	  if(result_code == 200)
	    {
	      posting = 1;
	      strcpy(call_message, server_list[current_server]);
	      return 2;
	    }
	  if(result_code == 201)
	    {
	      posting = 0;
	      strcpy(call_message, server_list[current_server]);
	      return 2;
	    }
	  if(columns <= sizeof(line))
	    temp = columns;
	  else
	    temp = sizeof(line);
	  for(count = 0; count < temp; count++)
	    if(line[count] == '\r' || line[count] == '\n')
	      line[count] = '\0';
	  line[temp - 1] = '\0';        /* clip long lines */


	  update_screen(current_server, server_list, line);
	  break;
	case 1:
	  update_screen(current_server, server_list, "bad host name");
	  break;
	case 2:
	  update_screen(current_server, server_list, "can not get socket");
	  break;
	case 3:
	  update_screen(current_server, server_list, "can not get connection");
	  break;
	case 4:
	  update_screen(current_server, server_list, "can not open stream");
	  break;
	}
	break;

      default:
	update_screen(current_server, server_list, "unknown command");
	break;
      }
    }
}

int update_rcfile(char s[][STRINGSIZE])
{
  int count;
  char line[80];
  char rc_file[80];
  extern FILE *mainrc;
  extern char organization[STRINGSIZE];
  extern char email[STRINGSIZE];
  extern char name[STRINGSIZE];
  extern char sig_file[STRINGSIZE];
  extern char *home;
  extern short int mainrc_open;

  sprintf(rc_file, "%s%s", home, RCFILE);
  if(open_file(&mainrc, rc_file, "w", &mainrc_open))
     return 1;

  for(count = 0; count < 9; count++)
    {
      if(!*s[count])
	break;
      sprintf(line, "server %s\n", s[count]);
      if(fputs(line, mainrc) == EOF)
	{
	  close_file(mainrc, &mainrc_open);
	  return 1;
	}
    }
  if(*email)
    {
      sprintf(line, "email %s\n", email);
      if(fputs(line, mainrc) == EOF)
	{
	  close_file(mainrc, &mainrc_open);
	  return 1;
	}
    }
  if(*name)
    {
      sprintf(line, "name %s\n", name);
      if(fputs(line, mainrc) == EOF)
	{
	  close_file(mainrc, &mainrc_open);
	  return 1;
	}
    }
  if(*organization)
    {
      sprintf(line, "organization %s\n", organization);
      if(fputs(line, mainrc) == EOF)
	{
	  close_file(mainrc, &mainrc_open);
	  return 1;
	}
    }
  if(*sig_file)
    {
      sprintf(line, "sig_file %s\n", sig_file);
      if(fputs(line, mainrc) == EOF)
	{
	  close_file(mainrc, &mainrc_open);
	  return 1;
	}
    }
  close_file(mainrc, &mainrc_open);
  return 0;
}


void update_screen(int active, char s[][STRINGSIZE], char *message)
{
  int count;
  int x = 0;
  int y = 0;
  extern int lines;
  extern char organization[STRINGSIZE];
  extern char email[STRINGSIZE];
  extern char name[STRINGSIZE];
  extern char sig_file[STRINGSIZE];
  char *h2 = "Servers and Identity";
  char *h3 = "\"h\" for help ";

  display_header(h2, h3);
  attrset(A_NORMAL);
  y++;
  move(y, x);
  clrtoeol();
  y++;
  move(y, x);
  for(count = 0; count < 10; count++)
    {
      if(count == active && *s[count])
	addstr("--> ");
      else
	addstr("    ");
      addstr(s[count]);
      clrtoeol();
      y++;
      move(y, x);
    }

  for(; y < (lines - 6); y++)
    {
      move(y ,x);
      clrtoeol();
    }

  move((lines-6), x);
  printw("E-mail address:  %s", email);
  clrtoeol();
  move((lines-5), x);
  printw("Name:            %s", name);
  clrtoeol();
  move((lines-4), x);
  printw("Organization:    %s", organization);
  clrtoeol();
  move((lines-3), x);
  printw("Signature file:  %s", sig_file);
  clrtoeol();
  move((lines-2), x);
  clrtoeol();
  move((lines-1), x);
  addstr(message);
  clrtoeol();
  refresh();
}

int manage_connection(int cmd, char *str, size_t str_size)
{
  struct hostent *host = NULL;
  struct sockaddr_in name;
  static int in_fd, out_fd, connection;
  short int error1, error2, count;
  short int ex = 0;
  extern FILE *out_stream, *in_stream;

  switch(cmd) {

  case 0:                             /* make connection */
      bzero(&name, sizeof(name));
      name.sin_family = AF_INET;
      name.sin_port = htons(NNTP_PORT);
      host = gethostbyname(str);
      if(host == NULL)
	{
	  ex = 1;
	  break;
	}
      bcopy(host->h_addr, &name.sin_addr.s_addr, 4);
      connection = socket(AF_INET, SOCK_STREAM, IP);
      if(connection < 0)
	{
	  ex = 2;
	  break;
	}
      if(connect(connection, &name, sizeof(name)))
	{
	  close(connection);
	  ex = 3;
	  break;
	}
      out_fd = dup(connection);
      in_fd = dup(connection);
      if(!(in_stream = fdopen(in_fd, "r"))
	 || !(out_stream = fdopen(out_fd, "w")))
	{
	ex = 4;
	break;
	}
      break;

  case 1:                            /* polite exit */
      display_footer("closing connection..");
      fprintf(out_stream, "quit\r\n");
      fflush(out_stream);
      fgets(str, str_size, in_stream);
      for(count = 0; count < (str_size - 1) &&
	    str[count] != '\r' && str[count] != '\n'; count++);
      str[count] = '\0';
      display_footer(str);
      error1 = fclose(in_stream) || fclose(out_stream);
      error2 = close(connection);
      ex = (error1 || error2);
      break;

  case 2:                             /* pull the plug exit */
      error1 = fclose(in_stream) || fclose(out_stream);
      error2 = close(connection);
      ex = (error1 || error2);
      break;

  }
  return ex;
}


void display_header(char *head2, char *head3)
{
  char h2[100];
  int count, temp;
  int x = 0;
  int y = 0;
  extern int columns;
  extern char server[STRINGSIZE];

  temp = (columns-4) - (strlen(server) + strlen(head3));
  strcpy(h2, head2);
  h2[temp] = '\0';      /* if head2 is long, chop without mercy */

  temp = (columns-1) - (strlen(server) + strlen(h2) + strlen(head3));
  attrset(A_STANDOUT);
  mvaddstr(y, x, server);
  for(count = 0; count < (temp / 2); count++)
    addch(' ');
  addstr(h2);
  for(count = 0; count < (temp - (temp /2)); count++)
    addch(' ');
  addstr(head3);
  refresh();
}

void server_help_screen(void)
{

  /* pay attention to array size and screen position if you change this! */

  extern int lines;
  int y;
  char help_text[14][60] = {
    "KEY                    FUNCTION",
    " ",
    "a                      add new NNTP server",
    "e                      enter e-mail address",
    "h                      display this help text",
    "n                      enter your name",
    "o                      enter your organization",
    "q                      quit SimpleNews (polite exit)",
    "r                      remove current NNTP server",
    "s                      specify signature file",
    "enter, right arrow     connect to server",
    "k, up arrow            select previous server",
    "j, down arrow          select next server",
    "ctrl-c                 unconditional exit (rude exit)"
  };

  clear();
  attrset(A_NORMAL);
  for(y = 0; y < 14; y++)
    {
      move((y + 2), 5);
      addstr(help_text[y]);
    }
  move(lines - 1, 0);
  addstr("press any key to continue");
  refresh();
  return;
}
