/*
SimpleNews   NNTP reader for USENET news
Copyright (C) 1997  J. Howard Benson

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


flames, praise, job offers to:

  J. Howard Benson
  PO Box 60731
  Fairbanks, AK  99706

  hbenson@polarnet.fnsb.ak.us

*/

#include "defines.h"

struct group_status {
  unsigned short int result_code;
  unsigned int their_estimate, our_estimate;
  long int beginning;
  long int end;
};

struct article {
  long int sequence;
  char read;
  char from[30];
  char subject[50];
  char date[35];
  char lines[5];
  char messageid[50];
  unsigned short int xpost;
};

struct header {
  char path[80];
  char newsgroups[MAX_GROUPS][80];
  char subject[80];
  char sender[80];
  char newsreader[80];
  char references[1024];
  char originator[80];
};


#include "defs.h"
#include "article.h"


int article_window(void)
{
  extern char editor[80];

  extern char call_message[128];
  extern char email[STRINGSIZE];
  extern char return_message[128];
  extern char sig_file[128];
  extern char temp_group_filename[128];
  extern char temp_post_filename[128];
  extern char temp_sort_filename[128];
  extern char newsrc_filename[128];
  extern char history_filename[128];
  extern char *home;
  extern FILE *out_stream, *in_stream, *newsrc, *group, *post, *sort, *hist;
  extern short int posting, newsrc_open, group_open, post_open, sort_open, hist_open;
  extern int lines, columns;
  extern long int selected_article;
  extern char current_group[256];
  extern unsigned short int xpost_threshold;
  char line[8192];
  char line1[2048];
  char *lpnt;
  char result_text[24];
  int in, index, result_code;
  int count, count1, retrieve, temp, temp1;
  long int current_article;
  long int lo, hi;
  short int display_limit, first_time, temp2, temp3;
  short int count2, display_read_article;
  static short int toggle;
  static int current_line, start_line;
  static char group_line[8192];
  static struct group_status gs;
  static struct article art[MAX_ARTICLES];
  struct header hdr;
  FILE *sig;


  if(!strcmp(call_message, "q"))
    {
      for(count = 0; count < MAX_ARTICLES && !art[count].sequence ; count++);
      temp = 0;
      if(count < MAX_ARTICLES)
	temp = mark_read_articles(&art[0], group_line, sizeof(group_line),
				  art[count].sequence);
      if(temp)
	strcpy(return_message, "error: can not update .newsrc");
      return 2;
    }

  else if(!strcmp(call_message, "text"))
    {
      display_limit = update_article_display(&art[0], start_line, current_line, toggle);
      if(*return_message)
	display_footer(return_message);
    }


  else      /* this block executes if control comes from the group screen */
    {

      toggle = 0;     /* start with unread articles first */


      /* the only goto that points here can be found in the key
	 input processing loop at case 't':  */

    get_articles:

      for(rewind(newsrc); fgets(group_line, sizeof(group_line), newsrc) != NULL;)
	{
	  if(!strncmp(current_group, group_line, strlen(current_group)))
	    {
	      for(count = 0; group_line[count] != ':' && group_line[count] != '!'; count++);
	      if(count == strlen(current_group))
		break;
	    }
	}

      display_footer("getting group status");

      if(get_group_status(&gs))
	{
	  strcpy(call_message, "q");
	  strcpy(return_message, "error: server error");
	  return 2;
	}


      if(gs.result_code != 211)
	{
	  strcpy(call_message, "article");
	  strcpy(return_message, "error: group missing from server..  yikes!");
	  return 2;
	}

      if(toggle)
	count = gs.our_estimate;

      else
	{

	  /* get the (estimated) actual number of unread articles on the
	     server this will work even if the user re-enters a group
	     that has had new articles come in. Canceled articles may
	     cause inflated values.
	     This code is shamelessly copied from update_group_file() */

	  temp = 0;
	  lo = 0;
	  hi = 0;
	  count++;
	  get_next_read(group_line, count);   /* set up pointer */
	  count = gs.our_estimate;

	  if(count)
	    for(;;)
	      {
		hi = lo = get_next_read(group_line, 0);
		if(!lo)
		  break;
		if(lo < 0)
		  {
		    lo *= -1;
		    hi = get_next_read(group_line, 0);
		  }
		if(hi < gs.beginning)
		  continue;
		temp = (hi - gs.beginning) + 1;
		if(lo > gs.beginning)
		  temp -= lo - gs.beginning;
		count -= temp;
	  }
	}

      if(toggle)
	retrieve = count;
      else
	retrieve = count > RETRIEVE_LIMIT ? RETRIEVE_LIMIT : count;

      if(retrieve > MAX_ARTICLES)
	retrieve = MAX_ARTICLES;

      if((retrieve > (RETRIEVE_LIMIT / 2)) || toggle)
	{
	  sprintf(line, "Max articles to retrieve [%d]: ", retrieve);
	  display_footer(line);
	  echo();
	  wgetnstr(stdscr, line, sizeof(line));
	  noecho();
	  if(*line)
	    retrieve = atoi(line);
	}
      if(retrieve > MAX_ARTICLES)
	retrieve = MAX_ARTICLES;

      for(count = 0; count < MAX_ARTICLES; count++)
	{
	  art[count].sequence = 0;
	  art[count].read = ' ';
	}

      for(current_article = gs.end, index = MAX_ARTICLES, first_time = 1;
	  retrieve;)
	{
	  if(first_time)
	    {
	      long_to_string(line1, current_article, 16);
	      while(line1[0] == '0')             /* strip leading zeros */
		for(temp = 0; temp < 16; temp++)
		  line1[temp] = line1[temp + 1];
	      fprintf(out_stream, "stat %s\r\n", line1);
	      fflush(out_stream);
	      fgets(line, sizeof(line), in_stream);
	      strncpy(result_text, line, 3);
	      result_text[3] = '\0';
	      result_code = atoi(result_text);
	      if(result_code != 223)
		{                                 /* should never happen */
		  if(--current_article < gs.beginning)
		    break;
		  continue;
		}
	      first_time = 0;
	    }
	  else
	    {
	      fputs("last\r\n", out_stream);
	      fflush(out_stream);
	      fgets(line, sizeof(line), in_stream);
	      strncpy(result_text, line, 3);
	      result_text[3] = '\0';
	      result_code = atoi(result_text);
	      if(result_code != 223)
		break;

	      lpnt = line;
	      for(lpnt += 3; *lpnt == ' '; lpnt++);    /* strip whitespace */
	      sscanf(lpnt, "%s", result_text);
	      current_article = atol(result_text);
	    }

	  for(count = 0; count < sizeof(group_line) &&
		group_line[count] != ':'; count++);
	  count++;
	  get_next_read(group_line, count);   /* set up pointer */

	  for(;;)
	    {
	      hi = lo = get_next_read(group_line, 0);
	      if(lo < 0)
		{
		  lo *= -1;
		  hi = get_next_read(group_line, 0);
		}
	      if(!lo)
		break;
	      if(current_article >= lo && current_article <= hi)
		break;
	    }

	  display_read_article = 0;

	  if(lo)
	    {
	      if(toggle)
		display_read_article = 1;  /* list 'em all, read ones marked */
	      else
		{
		  if(lo == 1)
		    break;     /* this shortens the wait when there are
				  no more unread articles */
		  else
		    continue;
		}
	    }

	  --index;

	  if(display_read_article)
	    art[index].read = '>';

	  twirl(line1);
	  strcat(line1, " retrieving list of articles");
	  display_footer(line1);
	  fprintf(out_stream, "head\r\n"); 
	  fflush(out_stream);
	  fgets(line, sizeof(line), in_stream);
	  strncpy(result_text, line, 3);
	  result_text[3] = '\0';
	  result_code = atoi(result_text);
	  if(result_code != 221)
	    continue;
	  temp = sizeof(art[0].from);
	  temp1 = (columns - 1) - temp;
	  if(temp1 > sizeof(art[0].subject))
	    temp1 = sizeof(art[0].subject);
	  temp2 = sizeof(art[0].date);
	  temp3 = sizeof(art[0].lines);

	  for(;;)
	    {
	      fgets(line, sizeof(line), in_stream);

	      /* echo non printing stuff except \n and \r as a space
		 real nerds don't use tabs in usenet postings */
	      for(count = 0; count < sizeof(line); count++)
		{
		  if(line[count] < ' ' && line[count] != '\r'
		     && line[count] != '\n' && line[count])
		    line[count] = ' ';
		}

	      if(line[0] == '.')
		{
		  if(line[1] == '\r' || line[1] == '\n')
		    break;
		}
	      if(!strncmp(line, "From: ", 6))
		{
		  get_email_address(line + 6, (sizeof(line) - 10));
		  strncpy(art[index].from, line + 6, temp);
		  for(count = 0;
		      art[index].from[count] != '\0' &&
			art[index].from[count] != '\r' &&
			art[index].from[count] != '\n' &&
			count < (temp - 1); count++);
		  for(;count < (temp - 1); count++)
		    art[index].from[count] = ' ';
		  art[index].from[count] = '\0';
		}
	      if(!strncmp(line, "Subject: ", 9))
		{
		  strncpy(art[index].subject, line + 9, temp1);
		  for(count = 0;
		      art[index].subject[count] != '\r' &&
			art[index].subject[count] != '\n' &&
			count < (temp1 - 1); count++);
		  for(;count < (temp1 - 1); count++)
		    art[index].subject[count] = ' ';
		  art[index].subject[count] = '\0';
		}
	      if(!strncmp(line, "Date: ", 6))
		{
		  strncpy(art[index].date, line + 6, temp2);
		  for(count = 0;
		      art[index].date[count] != '\r' &&
			art[index].date[count] != '\n' &&
			count < (temp2 - 1); count++);
		  for(;count < (temp2 - 1); count++)
		    art[index].date[count] = ' ';
		  art[index].date[count] = '\0';
		}
	      if(!strncmp(line, "Lines: ", 7))
		{
		  strncpy(art[index].lines, line + 7, temp3);
		  for(count = 0;
		      art[index].lines[count] != '\r' &&
			art[index].lines[count] != '\n' &&
			count < (temp3 - 1); count++);
		  for(;count < (temp3 - 1); count++)
		    art[index].lines[count] = ' ';
		  art[index].lines[count] = '\0';
		}
	      if(!strncmp(line, "Newsgroups: ", 12))
		{
		  art[index].xpost = 1;
		  for(count = 0;
		      line[count] != '\r' &&
			line[count] != '\n' &&
			count < sizeof(line); count++)
		    if(line[count] == ',')
		      art[index].xpost++;
		}
	      if(!strncmp(line, "Message-ID: ", 12))
		{
		  for(count1 = 0; line[count1] != '<' &&
			count1 < (sizeof(line) - 1); count1++);
		  count1++;
		  for(count2 = 0; line[count1] != '>' &&
			count1 < (sizeof(line) - 1) &&
			count2 < (sizeof(art[0].messageid) - 1); count1++, count2++)
		    art[index].messageid[count2] = line[count1];
		  art[index].messageid[count2] = 0;
		}
	    }
	  if(xpost_threshold && (art[index].xpost > xpost_threshold))
	    {
	      art[index].read = '$';
	      if(toggle)
		retrieve--;
	    }
	  else if(detect_dup(art[index].messageid))
	    {
	      art[index].read = '*';
	      if(toggle)
		retrieve--;
	    }
	  else
	    retrieve--;
	  art[index].sequence = current_article;

	}

      current_line = 2;
      start_line = 1;

      display_limit = update_article_display(&art[0], start_line, current_line, toggle);
    }

  /* begin key input processing loop */

  for(;;)
    {
      in = getch();
      switch(in) {

      case 'h':
	article_help_screen();
	getch();              /* press any key to continue..  */
	display_limit = update_article_display(&art[0], start_line, current_line, toggle);
	break;

      case 'p':
	if(!posting)
	  {
	    display_footer("Sorry...  posting not allowed on this server right now");
	    break;
	  }
	display_footer("post new article? ");
	echo();
	wgetnstr(stdscr, line, sizeof(line));
	noecho();
	if(strncmp(line, "y", 1))
	  {
	    display_footer("");
	    break;
	  }
	if(!strlen(email))
	  {
	    display_footer("e-mail address must be set");
	    break;
	  }
	new_header(&hdr);

	if(open_file(&post, temp_post_filename, "a", &post_open))
	  {
	    strcpy(call_message, "q");
	    strcpy(return_message, "error: can not open post file");
	    return 2;
	  }

	    /* no need to keep track of the sig file..
	       so doing a direct fopen/fclose here is ok */

	sig = fopen(sig_file, "r");
	if(sig != NULL)
	  {
	    fprintf(post, "\n---\n");
	    while(fgets(line, sizeof(line), sig) != NULL)
	      fputs(line, post);
	    fclose(sig);
	  }
	close_file(post, &post_open);

	sprintf(line, "%s %s", editor, temp_post_filename);

	endwin();

	if(system(line))
	  {
	    strcpy(call_message, "q");
	    sprintf(return_message, "error: unable to run \"sh -c %s %s\"",
		    editor, temp_post_filename);
	    return 2;
	  }

	initscr();
	cbreak();
	noecho();
	idlok(stdscr, TRUE);
	scrollok(stdscr, TRUE);
	keypad(stdscr, TRUE);
	erase();
	display_footer("really post it? ");
	echo();
	wgetnstr(stdscr, line, sizeof(line));
	noecho();
	if(strncmp(line, "y", 1))
	  {
	    strcpy(line, home);
	    strcat(line, "/dead_post");
	    rename(temp_post_filename, line);
	    display_limit = update_article_display(&art[0], start_line, current_line, toggle);
	    display_footer("text saved in \"dead_post\"");
	    break;
	  }

	temp = post_it(&hdr);
	if(temp == 1)
	  {
	    strcpy(call_message, "q");
	    strcpy(return_message, "error: file error");
	    return 2;
	  }
	if(temp == 2)
	  {
	    strcpy(call_message, "q");
	    strcpy(return_message, "error: can not make new connection");
	    return 2;
	  }

	  
	display_limit = update_article_display(&art[0], start_line, current_line, toggle);
	display_footer(hdr.references);   /* more sleaze */
	break;

      case 'q':
	for(count = 0; count < MAX_ARTICLES && !art[count].sequence; count++);
	temp = 0;
	if(count < MAX_ARTICLES)
	  temp = mark_read_articles(&art[0], group_line, sizeof(group_line),
				    art[count].sequence);
	strcpy(call_message, "q");
	if(temp)
	  strcpy(return_message, "error: can not update .newsrc");
	else
	  strcpy(return_message, "");
	return 2;

      case 't':
	toggle = toggle ? 0 : 1;   /* toggle all/unread */
	for(count = 0; count < MAX_ARTICLES && !art[count].sequence ; count++);
	temp = 0;
	if(count < MAX_ARTICLES)
	  temp = mark_read_articles(&art[0], group_line, sizeof(group_line),
				    art[count].sequence);
	if(temp)
	  {
	    strcpy(call_message, "q");
	    strcpy(return_message, "error: can not update .newsrc");
	    return 2;
	  }

	goto get_articles;  /* No!! Mr. Spock, I really tried not to use a goto..
			       ... your agonizer please.. */

      case '\n':
      case '\r':
      case KEY_RIGHT:
	if(!selected_article)
	  break;
	for(count = 0; selected_article != art[count].sequence; count++);
	if(art[count].read != '*')
	  art[count].read = '>';
	return 4;

      case 'r':
	strcpy(line1, current_group);
	strcat(line1, ": 1-");
	long_to_string(result_text, gs.end, 12);
	while(result_text[0] == '0')
	  for(temp = 0; temp < (sizeof(result_text) - 1); temp++)
	    result_text[temp] = result_text[temp + 1];
	strcat(line1, result_text);
	strcat(line1, "\n");

	if(open_file(&sort, temp_sort_filename, "w+", &sort_open))
	  {
	    strcpy(return_message, "error: can not open temp file");
	    strcpy(call_message, "q");
	    return 2;
	  }
	rewind(newsrc);

	for(;;)
	  {
	    if(fgets(line, sizeof(line), newsrc) == NULL)
	      break;
	    temp = 0;
	    if(!strncmp(line, current_group, strlen(current_group)))
	      {
		for(count = 0; line[count] != ':'; count++);
		if(count == strlen(current_group))
		  temp = 1;
	      }
	    if(temp)
	      fputs(line1, sort);
	    else
	      fputs(line, sort);
	  }
	close_file(newsrc, &newsrc_open);
	close_file(sort, &sort_open);
	rename(temp_sort_filename, newsrc_filename);

	if(open_file(&newsrc, newsrc_filename, "r", &newsrc_open))
	  {
	    strcpy(return_message, "error: can not open .newsrc file");
	    strcpy(call_message, "q");
	    return 2;
	  }

	if(open_file(&sort, temp_sort_filename, "w+", &sort_open))
	  {
	    strcpy(return_message, "error: can not open temp file");
	    strcpy(call_message, "q");
	    return 2;
	  }
	rewind(group);
	for(;;)
	  {
	    if(fgets(line, sizeof(line), group) == NULL)
	      break;
	    temp = 0;
	    if(!strncmp(line, current_group, strlen(current_group)))
	      {
		for(count = 0; line[count] != ' '; count++);
		if(count == strlen(current_group))
	      temp = 1;
	      }
	    if(temp)
	      fprintf(sort, "%s %8d %8d\n", current_group, 0, gs.our_estimate);
	    else
	      fputs(line, sort);
	  }

	close_file(group, &group_open);
	close_file(sort, &sort_open);
	rename(temp_sort_filename, temp_group_filename);
	if(open_file(&group, temp_group_filename, "r", &group_open))
	  {
	    strcpy(return_message, "error: can not open group file");
	    strcpy(call_message, "q");
	    return 2;
	  }

	/* update history file */

	if(open_file(&sort, temp_sort_filename, "w", &sort_open))
	  {
	    strcpy(return_message, "error: can not open temp file");
	    strcpy(call_message, "q");
	    return 2;
	  }
	count1 = 0;
	for(count = 0; count < MAX_ARTICLES; count++)
	  {
	    if(!art[count].sequence || art[count].read == '*')
	      continue;
	    sprintf(line, "%s\n", art[count].messageid);
	    if(fputs(line, sort) == EOF)
	      {
		strcpy(return_message, "error: can not write to temp file");
		strcpy(call_message, "q");
		return 2;
	      }
	    count1++;
	  }

	rewind(hist);

	for(; count1 < MAX_HISTORY; count1++)
	  {
	    if(fgets(line, sizeof(line), hist) == NULL)
	      break;
	    if(fputs(line, sort) == EOF)
	      {
		strcpy(return_message, "error: can not write to temp file");
		strcpy(call_message, "q");
		return 2;
	      }
	  }
	close_file(hist, &hist_open);
	close_file(sort, &sort_open);
	rename(temp_sort_filename, history_filename);
	if(open_file(&hist, history_filename, "r", &hist_open))
	  {
	    strcpy(return_message, "error: can not open history file");
	    strcpy(call_message, "q");
	    return 2;
	  }

	strcpy(call_message, "article");
	strcpy(return_message, "");
	return 2;
	

      case '<':
      case KEY_LEFT:
	for(count = 0; count < MAX_ARTICLES && !art[count].sequence ; count++);
	temp = 0;
	if(count <  MAX_ARTICLES)
	  temp = mark_read_articles(&art[0], group_line, sizeof(group_line),
				    art[count].sequence);
	if(temp)
	  {
	    strcpy(call_message, "q");
	    strcpy(return_message, "error: can not update .newsrc");
	    return 2;
	  }

	for(temp1 = count = 0; count < MAX_ARTICLES; count++)
	  if(art[count].sequence && art[count].read != '>' &&
	     art[count].read != '*' && art[count].read != '$')
	    temp1++;

	if(open_file(&sort, temp_sort_filename, "w+", &sort_open))
	  {
	    strcpy(return_message, "error: can not open temp file");
	    strcpy(call_message, "q");
	    return 2;
	  }
	rewind(group);
	for(;;)
	  {
	    if(fgets(line, sizeof(line), group) == NULL)
	      break;
	    temp = 0;
	    if(!strncmp(line, current_group, strlen(current_group)))
	      {
		for(count = 0; line[count] != ' '; count++);
		if(count == strlen(current_group))
		  temp = 1;
	      }
	    if(temp)
	      fprintf(sort, "%s %8d %8d\n", current_group, temp1, gs.our_estimate);
	    else
	      fputs(line, sort);
	  }

	close_file(group, &group_open);
	close_file(sort, &sort_open);
	rename(temp_sort_filename, temp_group_filename);
	if(open_file(&group, temp_group_filename, "r", &group_open))
	  {
	    strcpy(return_message, "error: can not open group file");
	    strcpy(call_message, "q");
	    return 2;
	  }

	strcpy(call_message, "article");
	strcpy(return_message, "");
	return 2;

      case 'j':
      case KEY_DOWN:
	if(display_limit)
	  {
	    if(current_line < display_limit)
	      current_line++;
	    else
	      break;
	  }
	else
	  {
	    if(current_line < (lines - 2))
	      current_line++;
	    else
	      start_line++;;
	  }
	display_limit = update_article_display(&art[0], start_line, current_line, toggle);
	break;

      case 'k':
      case KEY_UP:
	if(current_line > 2)
	  current_line--;
	else if(start_line > 1)
	  start_line--;
	else
	  break;
	display_limit = update_article_display(&art[0], start_line, current_line, toggle);
	break;

      case 'b':
      case KEY_PPAGE:
	current_line = 2;
	start_line -= (lines - 4);
	if(start_line < 1)
	  start_line = 1;
	display_limit = update_article_display(&art[0], start_line, current_line, toggle);
	break;

      case 'f':
      case KEY_NPAGE:
	if(display_limit)
	  break;
	start_line += (lines - 4);
	current_line = 2;
	display_limit = update_article_display(&art[0], start_line, current_line, toggle);
	break;

      default:
	strcpy(line1, "unknown command");
	move((lines-1), 0);
	attrset(A_STANDOUT);
	addstr(line1);
	clrtoeol();
	refresh();

      }
    }


  return 0;
}

int update_article_display(struct article *artp, int start, int current, short int toggle)
{
  extern int lines;
  extern long int selected_article;
  extern char current_group[256];
  int count, array_count, x, y;
  int end_lines = 0;
  char l[80];
  char *h3 = "\"h\" for help ";
  struct article *a;

  a = artp;
  selected_article = -1;
  array_count = 1;
  for(count = 0; count < start; count++)
    {
      while((!artp->sequence ||
	     ((artp->read == '$' || artp->read == '*')  && !toggle)) &&
	    array_count <= MAX_ARTICLES)
	{
	  artp++;
	  array_count++;
	}
      artp++;
      array_count++;
    }
  artp--;
  array_count--;

  display_header(current_group, h3);

  move(1,0);
  attrset(A_BOLD);
  addch(' ');
  addstr("Author");
  for(count = 0; count < 24; count++)
    addch(' ');
  addstr("Subject");
  clrtoeol();

  x = 0;

  attrset(A_NORMAL);

  for(y = 2; y < (lines - 1); y++)
    {
      move(y, x);
      if(array_count > MAX_ARTICLES)
	  clrtoeol();
      else
	{
	  if(current == y)
	    {
	      attrset(A_STANDOUT);
	      selected_article = artp->sequence;
	      sprintf(l, "%s Lines: %s Xpost: %d", artp->date, artp->lines, artp->xpost);
	    }
	  else
	    attrset(A_NORMAL);
	  move(y, x);
	  addch(artp->read);
	  addstr(artp->from);
	  addch(' ');
	  addstr(artp->subject);

	  do {
	    artp++;
	    array_count++;
	  } while((!artp->sequence ||
		   ((artp->read == '$' || artp->read == '*')  && !toggle)) &&
		  array_count <= MAX_ARTICLES);

	  if(array_count > MAX_ARTICLES)
	    end_lines = y;
	}
    }

  move((lines-1), x);
  attrset(A_STANDOUT);

  for(count = 0; count < MAX_ARTICLES &&
	(!a->sequence || ((a->read == '$' || a->read == '*') && !toggle)); a++, count++);
  if(count ==  MAX_ARTICLES)
    {
      addstr("no articles");
      selected_article = 0;
    }
  else
    addstr(l);
  clrtoeol();
  refresh();
  return end_lines;
}


void get_email_address(char *lp, size_t max)
{
  short int count, temp, temp1;

  for(count = 0; count < max && lp[count] != '@'; count++);
  if(count == max)
    return;     /* not an e-mail address - return some garbage */
  for(; lp[count] != '<' && count > 0; count--);
  if(lp[count] == '<')
    count++;

  /* lp[count] is now hopefully the first character of a valid e-mail address */


  for(temp = 0; temp < count; temp++)
    for(temp1 = 0; temp1 < (max - 1); temp1++)
      lp[temp1] = lp[temp1 + 1];

  for(count = 0; lp[count] != ' ' && lp[count] != '>' && lp[count] != '\r'
	&& lp[count] != '\n' && lp[count] != '('; count++);
  lp[count] = '\0';
  return;
}


/* recieve a pointer to the article structure array, the appropriate line
   from .newsrc as a character array (with sizeof(array)) and the sequence
   number from the first article */

int mark_read_articles(struct article *artp, char *gl, size_t max, long int start)
{
  extern char temp_sort_filename[128];
  extern char newsrc_filename[128];
  extern char history_filename[128];
  extern char current_group[256];
  extern short int hist_open, newsrc_open, sort_open;
  extern FILE *newsrc, *sort, *hist;
  char digits[16];
  char line[256];
  char line1[256];
  long int lo[READ_ARRAY_SIZE];
  long int hi[READ_ARRAY_SIZE];
  int count, count1, count2, temp;
  short int state;

  for(count = 0; count < READ_ARRAY_SIZE; count++)
    {
      lo[count] = 0;
      hi[count] = 0;
    }


  for(count = 0; count < max && gl[count] != ':'; count++);
  count++;
  get_next_read(gl, count);   /* set up pointer */

  count = 0;
  if(start > 1)
    {
      lo[count] = 1;
      hi[count] = start - 1;
      count++;
    }

  while(count < READ_ARRAY_SIZE)
    {
      hi[count] = lo[count] =  get_next_read(gl, 0);
      if(!hi[count])
	break;
      if(lo[count] < 0)
	{
	  lo[count] *= -1;
	  hi[count] = get_next_read(gl, 0);
	}

      if(!count)
	{
	  count++;          /* if you're here, start must be 1 */
	  continue;
	}

      if(hi[count] < start)
	{
	  hi[count] = lo[count] = 0;
	  continue;
	}

      if((hi[count] - hi[0]) == 1)
	{
	  hi[0]++;
	  hi[count] = lo[count] = 0;
	  continue;
	}

      if((lo[count] - hi[0]) < 2)
	{
	  hi[0] = hi[count];
	  hi[count] = lo[count] = 0;
	  continue;
	}

      count++;
    }

  for(count = 0; count < MAX_ARTICLES; count++, artp++)
    {
      if(artp->read != '>' && artp->read != '*' && artp->read != '$')
	continue;


      /* check to see if article is already marked read */

      temp = 0;
      for(count1 = 0; count1 < READ_ARRAY_SIZE; count1++)
	if(artp->sequence >= lo[count1] && artp->sequence <= hi[count1])
	  temp = 1;
      if(temp)
	continue;

      /* add the Message-ID to the history file (if it is not already there) */

      if(artp->read == '>' || artp->read == '$')
	{
	  if(open_file(&sort, temp_sort_filename, "w", &sort_open))
	    return 1;
	  fprintf(sort, "%s\n", artp->messageid);
	  rewind(hist);
	  for(count1 = 1; count1 < MAX_HISTORY; count1++)
	    {
	      if(fgets(line1, sizeof(line1), hist) == NULL)
		break;
	      if(fputs(line1, sort) == EOF)
		return 1;
	    }
	  close_file(hist, &hist_open);
	  close_file(sort, &sort_open);
	  rename(temp_sort_filename, history_filename);
	  if(open_file(&hist, history_filename, "r", &hist_open))
	    return 1;
	}

      /* back to the tricky business of .newsrc maintainence.. */

      if(!hi[0])
	{
	  state = 0;
	  goto switch_state;
	}     

      for(count1 = (READ_ARRAY_SIZE - 1); count1 >= 0; count1--)
	{
	  if(!hi[count1])
	    continue;
	  if(artp->sequence > hi[count1])
	    break;
	}

      if(count1 < 0)
	{
	  state = 1;
	  goto switch_state;
	}

      if(artp->sequence - hi[count1] > 1)
	if(lo[count1 + 1] == 0 || lo[count1 + 1] - artp->sequence > 1)
	  state = 2;

      if(artp->sequence - hi[count1] > 1)
	if(lo[count1 + 1] - artp->sequence == 1)
	  state = 3;

      if(artp->sequence - hi[count1] == 1)
	if(lo[count1 + 1] == 0 || lo[count1 + 1] - artp->sequence > 1)
	  state = 4;

      if(artp->sequence - hi[count1] == 1)
	if(lo[count1 + 1] - artp->sequence == 1)
	  state = 5;

    switch_state:
      switch(state) {

      case 0:
	hi[0] = lo[0] = artp->sequence;   /* we have a clean slate */
	break;                            /* start = 1 */

      case 1:
	for(count2 = (READ_ARRAY_SIZE - 1); count2 > 0; count2--)
	  {
	    lo[count2] = lo[count2 - 1];  /* start = 1 here too */
	    hi[count2] = hi[count2 - 1];
	  }
	hi[0] = lo[0] = artp->sequence;
	break;
	

      case 2:
	for(count2 = (READ_ARRAY_SIZE - 1); count2 > (count1 + 1); count2--)
	  {
	    lo[count2] = lo[count2 - 1];
	    hi[count2] = hi[count2 - 1];
	  }
	lo[count1 + 1] = artp->sequence;
	hi[count1 + 1] = artp->sequence;
	break;

      case 3:
	lo[count1 + 1] = artp->sequence;
	break;

      case 4:
	hi[count1] = artp->sequence;
	break;

      case 5:
	hi[count1] = hi[count1 + 1];
	for(count2 = (count1 + 1); count2 < (READ_ARRAY_SIZE - 1); count2++)
	  {
	    lo[count2] = lo[count2 + 1];
	    hi[count2] = hi[count2 + 1];
	  }
      }
    }

  strcpy(line1, current_group);
  strcat(line1, ":");
  if(lo[0])
    strcat(line1, " ");
  for(count = 0; count < sizeof(hi); count++)
    {
      if(!lo[0])
	{
	  strcat(line1, "\n");
	  break;
	}

      if(lo[count] < hi[count])
	{
	  long_to_string(digits, lo[count], 12);
	  while(digits[0] == '0')
	    for(temp = 0; temp < (sizeof(digits) - 1); temp++)
	      digits[temp] = digits[temp + 1];
	  strcat(line1, digits);
	  strcat(line1, "-");
	}
      long_to_string(digits, hi[count], 12);
      while(digits[0] == '0')
	for(temp = 0; temp < (sizeof(digits) - 1); temp++)
	  digits[temp] = digits[temp + 1];
      strcat(line1, digits);

      if(!lo[count+1])
	{
	  strcat(line1, "\n");
	  break;
	}

      strcat(line1, ",");
    }

  if(open_file(&sort, temp_sort_filename, "w+", &sort_open))
    return 1;
  rewind(newsrc);

  for(;;)
    {
      if(fgets(line, sizeof(line), newsrc) == NULL)
	break;
      temp = 0;
      if(!strncmp(line, current_group, strlen(current_group)))
	 {
	   for(count = 0; line[count] != ':'; count++);
	   if(count == strlen(current_group))
	     temp = 1;
	 }
      if(temp)
	fputs(line1, sort);
      else
	fputs(line, sort);
    }
  close_file(newsrc, &newsrc_open);
  close_file(sort, &sort_open);
  rename(temp_sort_filename, newsrc_filename);
  if(open_file(&newsrc, newsrc_filename, "r", &newsrc_open))
    return 1;
  return 0;
}

void article_help_screen(void)
{

  /* pay attention to array size and screen position if you change this! */

  extern int lines;
  int y;
  char help_text[14][60] = {
    "KEY                    FUNCTION",
    " ",
    "h                      display this help text",
    "p                      post new article",
    "q                      quit SimpleNews (polite exit)",
    "r                      mark all articles as read",
    "t                      toggle all/unread",
    "<, left arrow          go back to group screen",
    "enter, right arrow     display text of article",
    "k, up arrow            select previous article",
    "j, down arrow          select next article",
    "f, page down           scroll forward one screen",
    "b, page up             scroll back one screen",
    "ctrl-c                 unconditional exit (rude exit)"
  };

  clear();
  attrset(A_NORMAL);
  for(y = 0; y < 14; y++)
    {
      move((y + 2), 5);
      addstr(help_text[y]);
    }
  move(lines - 1, 0);
  addstr("press any key to continue");
  refresh();
  return;
}

void new_header(struct header *hdrp)
{
  extern char current_group[256];
  extern char email[STRINGSIZE];
  extern char true_email[STRINGSIZE];
  char line[256];
  char line1[80];
  char name[80];
  short int count, flag;

  gethostname(name, sizeof(name));
  strcpy(hdrp->path, name);
  echo();
  display_footer("Subject: ");
  wgetnstr(stdscr, hdrp->subject, sizeof(hdrp->subject));
  sprintf(line, "Newsgroups: [%s] ", current_group);
  display_footer(line);
  wgetnstr(stdscr, line1, sizeof(line1));
  if(*line1)
    strcpy(hdrp->newsgroups[0], line1);
  else
    strcpy(hdrp->newsgroups[0], current_group);
  for(count = 1, flag = 1; count < MAX_GROUPS; count++)
    {
      if(flag)
	{
	  display_footer("Newsgroups: (cr to quit) ");
	  wgetnstr(stdscr, line1, sizeof(line1));
	  if(*line1)
	    strcpy(hdrp->newsgroups[count], line1);
	  else
	    {
	      strcpy(hdrp->newsgroups[count], "");
	      flag = 0;
	    }
	}
      else
	strcpy(hdrp->newsgroups[count], "");
    }

  /*
  date = popen("date -u \'+%d %b %Y %T GMT\'", "r");
  fgets(hdrp->date, sizeof(hdrp->date), date);
  pclose(date);

  for(count = 0; hdrp->date[count] && hdrp->date[count] != '\r' &&
	hdrp->date[count] != '\n'; count++);
  hdrp->date[count] = 0;
  */

  strcpy(hdrp->references, "");
  strcpy(hdrp->sender, "");
  
  /* If the strip-mining spam-bots ever get smart enough to
     check the 'Sender:' line, comment the following stuff out */

  if(strcmp(email, true_email))
    strcpy(hdrp->sender, true_email);


  sprintf(hdrp->newsreader, "%s  %s/%s", VERSION, getenv("OSTYPE"), getenv("HOSTTYPE"));

  noecho();
  return;
}

int post_it(struct header *hdrp)
{
  char line[1024];
  char result_text[6];
  short int count, result_code;
  short int flag = 0;
  extern char email[STRINGSIZE];
  extern char *home;
  extern char name[STRINGSIZE];
  extern char organization[STRINGSIZE];
  extern char temp_post_filename[128];
  extern char post_out_filename[128];
  extern short int post_open, post_out_open;
  extern FILE *out_stream, *in_stream, *post, *post_out;

again:

  fputs("post\r\n", out_stream);
  fflush(out_stream);
  fgets(line, sizeof(line), in_stream);
  strncpy(result_text, line, 3);
  result_text[3] = '\0';
  result_code = atoi(result_text);
  if(result_code == 340)
    {
      display_footer("posting article...");
      if(open_file(&post_out, post_out_filename, "w+", &post_out_open))
	return 1;
      fprintf(post_out, "Path: %s\n", hdrp->path);
      fprintf(post_out, "From: %s <%s>\n", name, email);
      fprintf(post_out, "Newsgroups: %s", hdrp->newsgroups[0]);
      for(count = 1; count < MAX_GROUPS; count++)
	if(*hdrp->newsgroups[count])
	  fprintf(post_out, ",%s", hdrp->newsgroups[count]);
      fprintf(post_out, "\n");
      fprintf(post_out, "Subject: %s\n", hdrp->subject);

      /*
      fprintf(post_out, "Date: %s\n", hdrp->date);
      */

      fprintf(post_out, "Organization: %s\n", organization);
      if(*hdrp->references)
	fprintf(post_out, "References: %s\n", hdrp->references);
      if(*hdrp->sender)
	fprintf(post_out, "Sender: %s\n", hdrp->sender);
      fprintf(post_out, "X-Newsreader: %s\n\n", hdrp->newsreader);

      if(open_file(&post, temp_post_filename, "r", &post_open))
	{
	  close_file(post_out, &post_out_open);
	  remove(post_out_filename);
	  return 1;
	}
      while(fgets(line, sizeof(line), post) != NULL)
	fputs(line, post_out);
      close_file(post, &post_open);
      remove(temp_post_filename);

      rewind(post_out);
      while(fgets(line, sizeof(line), post_out) != NULL)
	{
	  for(count = 0; line[count] && line[count] != '\r' && line[count] != '\n'; count++);
	  line[count] = 0;                /* strip newline */
	  if(!strcmp(line, "."))
	    strcat(line, ".");
	  fprintf(out_stream, "%s\r\n", line);
	}
      fprintf(out_stream, ".\r\n");    /* single . signals end of input */
      fflush(out_stream);
      close_file(post_out, &post_out_open);
      fgets(line, sizeof(line), in_stream);
      for(count = 0; line[count] && line[count] != '\r' && line[count] != '\n'; count++);
      line[count] = 0;                /* strip newline */

    }
  else if(result_code == 440)
    {
      sprintf(line, "%s/dead_post", home);
      rename(temp_post_filename, line);
      strcpy(line, "Server is not accepting posts. Text saved in \"dead_post\".");
    }
  else
    {
      if(++flag > 1)
	return 2;
      if(re_connect(line))
	return 2;
      goto again;
    }


  /* this is a sleazy way to pass a string back to the caller */
  strcpy(hdrp->references, line);

  return 0;
}

int detect_dup(char *id)
{
  extern FILE *hist;
  char line[60];
  register short int count;
  register short int compare;
  short int status = 0;

  rewind(hist);
  while(fgets(line, sizeof(line), hist) != NULL)
    {
      for(compare = count = 0; id[count]; count++)
	{
	  if(id[count] == line[count])
	    continue;
	  compare++;
	  break;
	}
      if(compare)
	continue;
      status++;
      break;
    }
  return status;
}
