int server_window(void);

int manage_connection(int cmd, char *str, size_t str_size);

void display_header(char *head2, char *head3);

int update_rcfile(char s[][50]);

void update_screen(int active, char s[][50], char *message);

void display_footer(char *string);

void server_help_screen(void);
