#include <unistd.h>


int group_window(void);

long int get_next_read(char *s, int pnt);

void remove_group(void);

int update_group_screen(int current, int active, char *message, FILE *lst);

void display_header(char *head2, char *head3);

int update_group_file(FILE *newsrc, FILE *group, char *message);

void long_to_string(char *s, long int temp, int digits);

int sort_text_file(size_t max, FILE *control, FILE * chaos);

int get_group_status(struct group_status *gsp);

void display_footer(char *string);

void group_help_screen(void);

void twirl(char *string);

int re_connect(char *message);
