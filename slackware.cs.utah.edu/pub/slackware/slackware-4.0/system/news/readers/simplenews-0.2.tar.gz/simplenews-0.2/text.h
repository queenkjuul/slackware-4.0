#include <unistd.h>

int text_window(void);

void display_header(char *head2, char *head3);

int update_text_screen(char *message, FILE *txt);

void long_to_string(char *s, long int temp, int digits);

void twirl(char *string);

void display_footer(char *string);

void text_help_screen(void);

int post_it(struct header *hdrp);

void followup_header(struct header *hdrp, FILE *text, char *ng, char *ref);

int re_connect(char *message);
