/*
SimpleNews   NNTP reader for USENET news
Copyright (C) 1997  J. Howard Benson

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


flames, praise, job offers to:

  J. Howard Benson
  PO Box 60731
  Fairbanks, AK  99706

  hbenson@polarnet.fnsb.ak.us

*/

struct group_status {
  unsigned short int result_code;
  unsigned int their_estimate, our_estimate;
  long int beginning;
  long int end;
};

#include "defs.h"
#include "defines.h"
#include "group.h"

int group_window(void)
{

  extern char call_message[128];
  extern char return_message[128];
  extern char *home;
  extern FILE *out_stream, *in_stream, *list, *newsrc, *group, *sort;
  extern short int posting, group_open, list_open, newsrc_open, sort_open;
  extern unsigned short int xpost_threshold;
  extern int lines;
  extern char current_group[256];
  extern char temp_group_filename[128];
  extern char temp_list_filename[128];
  extern char temp_sort_filename[128];
  extern char newsrc_filename[128];
  char line[8192];
  char line1[256];
  char result_text[16];
  char string[80];
  int in, display_limit;
  int temp, temp1;
  short int result_code;
  long int byte_count = 0;
  unsigned int count, all_group_count;
  static short int list_requested = 0;
  static short int active;
  static int current_line;
  static FILE *display;

  if(!strcmp(call_message, "q"))
    return 1;

  else if(!strcmp(call_message, "article"))
    {
      display = group;
      display_limit = update_group_screen(current_line, active, return_message, display);
    }
  else
    {
      sprintf(newsrc_filename, "%s/.newsrc.%s", home, call_message);
      if(open_file(&newsrc, newsrc_filename, "a+", &newsrc_open))
	{
	  strcpy(return_message, "error: can not open .newsrc file");
	  strcpy(call_message, "q");
	  return 1;    /* clean up and die */
	}

      if(open_file(&group, temp_group_filename, "w+", &group_open))
	{
	  strcpy(return_message, "error: can not open group file");
	  strcpy(call_message, "q");
	  return 1;
	}
      if(ftell(newsrc) == 0)
	if(!fprintf(newsrc, "news.announce.newusers:\n"))
	  {
	    strcpy(return_message, "error: can not write .newsrc file");
	    strcpy(call_message, "q");
	    return 1;
	  }
      temp = ftell(newsrc);
  
      rewind(newsrc);
      rewind(group);
      if(update_group_file(newsrc, group, " retrieving list of subscribed newsgroups..."))
	{
	  strcpy(call_message, "q");
	  return 1;
	}
      rewind(group);
      display = group;
      current_line = 2;
      active = 1;
      if(posting)
	display_limit = update_group_screen(current_line, active, "Posting OK", display);
      else
	display_limit = update_group_screen(current_line, active, "No Posting", display);

    }

  for(;;)
    {
      in = getch();
      switch(in) {

      case 'c':
	if(xpost_threshold)
	  sprintf(line, "Reject articles posted to more than X groups. Enter X: [%d] ", xpost_threshold);
	else
	  strcpy(line, "Reject articles posted to more than X groups. Enter X: ");
	display_footer(line);
	echo();
	wgetnstr(stdscr, line, sizeof(line));
	noecho();
	if(*line)
	  xpost_threshold = atoi(line);
	display_limit = update_group_screen(current_line, active, "", display);
	break;

      case 'g':
	if(active)
	  break;
	active = 1;
	rewind(newsrc);
	close_file(group, &group_open);
	if(open_file(&group, temp_group_filename, "w+", &group_open))
	  {
	    strcpy(return_message, "error: can not open group file");
	    strcpy(call_message, "q");
	    return 1;
	  }

	if(update_group_file(newsrc, group, " updating list of subscribed newsgroups..."))
	  {
	    strcpy(call_message, "q");
	    return 1;
	  }
	rewind(group);
	current_line = 2;
	display = group;
	display_limit = update_group_screen(current_line, active, "", display);
	break;

      case 'h':
	group_help_screen();
	getch();              /* press any key to continue..  */
	display_limit = update_group_screen(current_line, active, "", display);
	break;

      case 'l':
	if(!active)
	  break;
	active = 0;
	if(!list_requested)
	  {
	    list_requested = 1;
	    if(open_file(&list, temp_list_filename, "w+", &list_open))
	       {
		 strcpy(return_message, "error: can not open list file");
		 strcpy(call_message, "q");
		 return 1;
	       }

	    if(open_file(&sort, temp_sort_filename, "w+", &sort_open))
	       {
		 strcpy(return_message, "error: can not open sort file");
		 strcpy(call_message, "q");
		 return 1;
	       }

	    temp = 0;

	  retry:

	    display_footer("sending list request..");
	    fprintf(out_stream, "list\r\n");
	    fflush(out_stream);
	    fgets(line, sizeof(line), in_stream);
	    strncpy(result_text, line, 3);
	    result_text[3] = '\0';
	    result_code = atoi(result_text);
	    if(result_code != 215)
	      {
		if(++temp > 1)
		  {
		    strcpy(return_message, "error: can not make new connection");
		    strcpy(call_message, "q");
		    return 1;
		  }
		if(re_connect(line))
		  {
		    strcpy(return_message, "error: can not make new connection");
		    strcpy(call_message, "q");
		    return 1;
		  }
		goto retry;
	      }

	    for(count = 0;;count++)
	      {
		fgets(line, sizeof(line), in_stream);
		temp = strlen(line);
		byte_count += temp;

		/* exit condition test below */

		if(line[0] == '.')
		  {
		    if(line[1] == '\r' || line[1] == '\n')
		      break;
		  }


		if(count % 50 == 0)
		  {
		    twirl(string);
		    strcat(string, " retrieving list of all newsgroups");
		    display_footer(string);
		  }

		fputs(line, sort);
	      }

	    all_group_count = count;
	    temp = sort_text_file((size_t)byte_count, list, sort);
	    sprintf(string, "%d groups", all_group_count);

	    switch(temp) {

	    case 0:
	      close_file(sort, &sort_open);

	      /* This would be a good time to remove from .newsrc the old groups
		 which have been deleted from the server.

		 If a group in .newsrc exists in the big list, write it to
		 a temp file. Rename the temp file to .newsrc when done.  */

	      temp1 = 0;
	      rewind(list);
	      rewind(newsrc);
	      if(open_file(&sort, temp_sort_filename, "w+", &sort_open))
		 {
		   strcpy(return_message, "error: can not open sort file");
		   strcpy(call_message, "q");
		   return 1;
		 }

	      for(; fgets(line, sizeof(line), newsrc) != NULL;)
		{
		  for(count = 0; line[count] != ':' && line[count] != '!'; count++);
		  for(;;)
		    {
		      if(!temp1)
			if(fgets(line1, sizeof(line1), list) == NULL)
			  break;
		      if(temp1)
			temp1 = 0;
		      if(!strncmp(line, line1, count))
			{
			  fputs(line, sort);
			  break;
			}
		      if(strncmp(line, line1, count) < 0)
			{
			  temp1 = 1;
			  break;
			}
		    }
		}
	      close_file(newsrc, &newsrc_open);
	      close_file(sort, &sort_open);
	      rename(temp_sort_filename, newsrc_filename);
	      if(open_file(&newsrc, newsrc_filename, "r", &newsrc_open))
		 {
		   strcpy(return_message, "error: can not open .newsrc file");
		   strcpy(call_message, "q");
		   return 1;
		 }

	      rewind(list);
	      current_line = 2;
	      display = list;
	      display_limit = update_group_screen(current_line, active, string, display);
	      break;

	    case 1:
	      close_file(list, &list_open);
	      close_file(sort, &sort_open);
	      rename(temp_sort_filename, temp_list_filename);
	      if(open_file(&list, temp_list_filename, "r", &list_open))
		 {
		   strcpy(return_message, "error: can not open list file");
		   strcpy(call_message, "q");
		   return 1;
		 }

	      current_line = 2;
	      display = list;
	      display_limit = update_group_screen(current_line, active, "List is unsorted", display);
	      break;

	    case 2:
	      strcpy(return_message, "error: can't write list file");
	      strcpy(call_message, "q");
	      return 1;
	    }
	  }
	else   /* if(list_requested) */
	  {

	    rewind(list);
	    current_line = 2;
	    display = list;
	    display_limit = update_group_screen(current_line, active, "", display);
	  }
	break;

      case 'q':
	strcpy(call_message, "q");
	return 1;

      case 'a':
	if(!active)
	  break;
	display_footer("enter single newsgroup: ");
	echo();
	wgetnstr(stdscr, line, sizeof(line));
	noecho();

	for(temp = count = 0; line[count]; count++)
	  if(line[count] == ' ')
	    temp = 1;
	if(temp)
	  {
	    display_footer("bad input");
	    break;
	  }
	else
	  strcpy(current_group, line);

	temp = 0;

      over:

	display_footer("looking up group");
	fprintf(out_stream, "group %s\r\n", current_group);
	fflush(out_stream);
	fgets(line, sizeof(line), in_stream);
	strncpy(result_text, line, 3);
	result_text[3] = '\0';
	result_code = atoi(result_text);
	if(result_code == 411)
	  {
	    display_footer("no such group");
	    break;
	  }
	if(result_code != 211)
	  {
	    if(++temp > 1)
	      {
		strcpy(return_message, "error: can not make new connection");
		strcpy(call_message, "q");
		return 1;
	      }
	    if(re_connect(line))
	      {
		strcpy(return_message, "error: can not make new connection");
		strcpy(call_message, "q");
		return 1;
	      }
	    goto over;
	  }


	/* note the absence of a break statement here */
	

      case 's':
	if(active && in == 's')
	  break;
	rewind(newsrc);
	if(open_file(&sort, temp_sort_filename, "w+", &sort_open))
	   {
	     strcpy(return_message, "error: can not open sort file");
	     strcpy(call_message, "q");
	     return 1;
	   }

	temp = strlen(current_group);
	temp1 = 1;
	byte_count = 0;

	for(;;)
	  {
	    if(fgets(line, sizeof(line), newsrc) == NULL)
	      break;
	    if(!strncmp(line, current_group, (size_t)temp))
	      {
		for(count = 0; line[count] != ':' && line[count] != '!' && count < sizeof(line); count++);
		if(count == temp)
		  {
		    for(count = 0; count < strlen(line); count++)
		      if(line[count] == '!')
			line[count] = ':';
		    temp1 = 0;
		  }
	      }
	    byte_count += strlen(line);
	    if(fputs(line, sort) == EOF)
	      {
		strcpy(return_message, "error: can't write temp file");
		strcpy(call_message, "q");
		return 1;
	      }
	  }
	if(temp1)
	  {
	    sprintf(line, "%s:\n", current_group);
	    byte_count += strlen(line);
	    if(fputs(line, sort) == EOF)
	      {
		strcpy(return_message, "error: can't write temp file");
		strcpy(call_message, "q");
		return 1;
	      }
	  }

	close_file(newsrc, &newsrc_open);
	if(open_file(&newsrc, newsrc_filename, "w+", &newsrc_open))
	   {
	     strcpy(return_message, "error: can not open newsrc file");
	     strcpy(call_message, "q");
	     return 1;
	   }


	/* The conversions before and after sort_text_file are
	   necessary to preserve the traditional .newsrc format
	   which uses ':' to denote a subscribed group.
	   Unfortunately, ':' is higher than '.' and it screws
	   up the sort. The fix sucks but it works.  */

	rewind(sort);
	for(;;)
	  {
	    temp1 = fgetc(sort);
	    if(temp1 == EOF)
	      break;
	    if(temp1 == ':')
	      fputc('"', newsrc);
	    else
	      fputc(temp1, newsrc);
	  }

	temp = sort_text_file((size_t)byte_count, sort, newsrc);

	switch(temp) {

	case 0:
	  close_file(newsrc, &newsrc_open);
	  if(open_file(&newsrc, newsrc_filename, "w+", &newsrc_open))
	     {
	       strcpy(return_message, "error: can not open .newsrc file");
	       strcpy(call_message, "q");
	       return 1;
	     }

	  rewind(sort);
	  for(;;)
	    {
	      temp1 = fgetc(sort);
	      if(temp1 == EOF)
		break;
	      if(temp1 == '"')
		fputc(':', newsrc);
	      else
		fputc(temp1, newsrc);
	    }
	  close_file(sort, &sort_open);
	  if(in == 'a')
	    {
	      rewind(newsrc);
	      close_file(group, &group_open);
	      if(open_file(&group, temp_group_filename, "w+", &group_open))
		{
		  strcpy(return_message, "error: can not open group file");
		  strcpy(call_message, "q");
		  return 1;
		}

	      if(update_group_file(newsrc, group, " adding group.."))
		{
		  strcpy(call_message, "q");
		  return 1;
		}
	      rewind(group);
	      current_line = 2;
	      display = group;
	      display_limit = update_group_screen(current_line, active, "", display);
	    }
	  else
	    display_footer("group subscribed");

	  break;

	case 1:
	case 2:
	  rewind(newsrc);
	  close_file(sort, &sort_open);
	  if(open_file(&sort, temp_sort_filename, "w+", &sort_open))
	     {
	       strcpy(return_message, "error: can not open sort file");
	       strcpy(call_message, "q");
	       return 1;
	     }

	  for(;;)
	    {
	      temp1 = fgetc(newsrc);
	      if(temp1 == EOF)
		break;
	      if(temp1 == '"')
		fputc(':', newsrc);
	      else
		fputc(temp1, sort);
	    }
	  close_file(newsrc, &newsrc_open);
	  close_file(sort, &sort_open);
	  rename(temp_sort_filename, newsrc_filename);
	  if(temp == 1)
	    strcpy(return_message, "error: sizeof(size_t)<4 or out of memory");
	  else
	    strcpy(return_message, "error: can't write list file");
	  strcpy(call_message, "q");
	  return 1;
	}
	break;
	    
      case 'u':
	if(!active)
	  break;
	rewind(newsrc);
	if(open_file(&sort, temp_sort_filename, "w+", &sort_open))
	   {
	     strcpy(return_message, "error: can not open sort file");
	     strcpy(call_message, "q");
	     return 1;
	   }

	temp = strlen(current_group);
	for(;;)
	  {
	    if(fgets(line, sizeof(line), newsrc) == NULL)
	      break;
	    if(!strncmp(line, current_group, (size_t)temp))
	      {
		for(count = 0; count < strlen(line); count++)
		  if(line[count] == ':')
		    line[count] = '!';
	      }
	    if(fputs(line, sort) == EOF)
	      {
		strcpy(return_message, "error: can't write temp file");
		strcpy(call_message, "q");
		return 1;
	      }
	  }

	close_file(newsrc, &newsrc_open);
	close_file(sort, &sort_open);
	rename(temp_sort_filename, newsrc_filename);
	if(open_file(&newsrc, newsrc_filename, "r", &newsrc_open))
	   {
	     strcpy(return_message, "error: can not open newsrc file");
	     strcpy(call_message, "q");
	     return 1;
	   }

	close_file(group, &group_open);
	if(open_file(&group, temp_group_filename, "w+", &group_open))
	   {
	     strcpy(return_message, "error: can not open group file");
	     strcpy(call_message, "q");
	     return 1;
	   }

	if(update_group_file(newsrc, group, " removing group..."))
	  {
	    strcpy(call_message, "q");
	    return 1;
	  }
	rewind(group);
	display = group;
	current_line = 2;
	display_limit = update_group_screen(current_line, active, "", display);
	break;

      case '\n':
      case '\r':
      case KEY_RIGHT:
	if(!active)
	  {
	    display_footer("Hit 'g' to go to the subscribed group screen first");
	    break;
	  }
	strcpy(call_message, "group");
	strcpy(return_message, "");
	return 3;

      case '<':
      case KEY_LEFT:
	if(!active)
	  {
	    display_footer("Hit 'g' to go to the subscribed group screen first");
	    break;
	  }
	close_file(group, &group_open);
	close_file(newsrc, &newsrc_open);
	if(list_requested)
	  close_file(list, &list_open);
	list_requested = 0;
	strcpy(call_message, " ");
	return 1;

      case 'k':
      case KEY_UP:
	if(current_line > 2)
	  current_line--;
	else
	  {
	    if(ftell(display) == 0)
	      break;
	    for(;;)
	      {
		if(ftell(display) < 2)
		  {
		    rewind(display);
		    break;
		  }
		fseek(display, -2, SEEK_CUR);
		if(fgetc(display) == '\n')
		  break;
	      }
	  }
	display_limit = update_group_screen(current_line, active, "", display);
	break;

      case 'j':
      case KEY_DOWN:
	if(display_limit)
	  {
	    if(current_line < display_limit)
	      current_line++;
	    else
	      break;
	  }
	else
	  {
	    if(current_line < (lines - 2))
	      current_line++;
	    else
	      for(;fgetc(display) != '\n';);
	  }
	display_limit = update_group_screen(current_line, active, "", display);
	break;

      case 'b':
      case KEY_PPAGE:
	current_line = 2;
	for(count = 0; count < (lines - 4); count++)
	  {
	    if(ftell(display) == 0)
	      break;
	    for(;;)
	      {
		if(ftell(display) < 2)
		  {
		    rewind(display);
		    break;
		  }
		fseek(display, -2, SEEK_CUR);
		if(fgetc(display) == '\n')
		  break;
	      }
	  }
	display_limit = update_group_screen(current_line, active, "", display);
	break;
	
      case 'f':
      case KEY_NPAGE:
	if(display_limit)
	  break;
	for(count = 0; count < (lines - 4); count++)
	  for(;fgetc(display) != '\n';);
	current_line = 2;
	display_limit = update_group_screen(current_line, active, "", display);
	break;

      case 'B':
	for(count = 0; count < 200;)
	  {
	    if(ftell(display) < 2)
	      {
		rewind(display);
		break;
	      }
	    fseek(display, -2, SEEK_CUR);
	    if(fgetc(display) == '\n')
	      count++;
	  }
	current_line = 2;
	display_limit = update_group_screen(current_line, active, "", display);
	break;


      case 'F':
	for(count = 0; count < 200;)
	  {
	    temp = fgetc(display);
	    if(temp == '\n')
	      count++;
	    if(temp == EOF)
	      break;
	  }
	if(temp == EOF)
	  {
	    for(count = 0; count < (lines - 3);)
	      {
		if(ftell(display) < 2)
		  {
		    rewind(display);
		    break;
		  }
		fseek(display, -2, SEEK_CUR);
		if(fgetc(display) == '\n')
		  count++;
	      }
	  }
	current_line = 2;
	display_limit = update_group_screen(current_line, active, "", display);
	break;
		


      default:
	strcpy(line1, "unknown command");
	move((lines-1), 0);
	attrset(A_STANDOUT);
	addstr(line1);
	clrtoeol();
	refresh();

      }
    }
}

long int get_next_read(char *s, int pnt)
{
  int temp;
  short int flag = 1;
  long int result;
  char text[16];
  static int p;

  if(pnt)
    {
      p = pnt;                     /* this just sets up the static pointer */
      return 0;
    }

  for(;s[p] == ' '; p++);

  if(s[p] == '\n')
    return 0;                      /* end of line....  done */

  for(temp = 0; temp < sizeof(text); temp++)
    {
      text[temp] = s[p];
      p++;
      if(s[p] == '\n')
	break;
      if(s[p] == ',')
	{
	  p++;
	  break;
	}
      if(s[p] == '-')
	{
	  p++;
	  flag = -1;
	  break;
	}
    }
  text[++temp] = 0;
  result = atol(text);
  result *= flag;
  return result;
}


/* file pointer is set to beginning of the first line to be displayed before
   update_group_screen is called. "Current" is the line number on the screen
   which is selected (and highlighted). Name of selected group is placed in
   current_group. File position indicator is reset to original value  */

int update_group_screen(int current, int active, char *message, FILE *lst)
{
  extern int lines, columns;
  extern char current_group[256];
  int count, char_count, temp, length, padding, flag, ret;
  int x, y;
  int end_lines = 0;
  long int file_position;
  char *h3 = "\"h\" for help ";

  if(active)
    {
      display_header("Subscribed Groups", h3);
      move(1,0);
      attrset(A_BOLD);
      addstr("Newsgroup");
      for(count = 0; count < (columns - 38); count++)
	addch(' ');
      addstr("(estimated)  Unread    Total");
      clrtoeol();
    }

  else
    {
      display_header("All Groups", h3);
      move(1,0);
      attrset(A_BOLD);
      addstr("Newsgroup");
      for(count = 0; count < (columns - 39); count++)
	addch(' ');
      addstr("<last> <first> <posting flag>");
      clrtoeol();
    }

  x = 0;
  file_position = ftell(lst);
  for(y = 2; y < (lines - 1); y++)
    {
      if(current == y)
	attrset(A_STANDOUT);
      else
	attrset(A_NORMAL);
      temp = fgetc(lst);
      if(temp == EOF)
	{
	  end_lines = y - 1;
	  for(; y < (lines - 1); y++)
	    {
	      move(y, x);
	      clrtoeol();
	    }
	  break;
	}
      for(length = 1, ret = 0; ; length++)
	{
	  temp = fgetc(lst);
	  if(temp == '\n')
	    break;
	  if(temp == '\r')
	    ret++;
	}
      fseek(lst, -(length + 1), SEEK_CUR);
      padding = (columns - 1) - length;
      padding += ret;
      if(padding < 0)
	padding = 0;

      move(y, x);
      for(char_count = 0, flag = 1; char_count < (columns - 1); char_count++)
	{
	  temp = fgetc(lst);
	  if(temp != '\r')
	    addch((chtype)temp);


	  /*  As each line is displayed on the screen, rows are padded with
	      spaces to align the columns and the name of the highlighted
	      group is saved in current_group. */


	  if(flag)
	    {
	      if(current == y)
		{
		  if((char)temp == ' ')
		    current_group[char_count] = '\0';
		  else
		    current_group[char_count] = temp;
		}
	      if((char)temp == ' ')
		{
		  for(count = 0; count < padding; count++)
		    {
		      addch(' ');
		      char_count++;
		    }
		  flag--;
		}
	    }
	}

/* who is the asshole who created this group?? -> alt.binaries.pictures.erotica.bestiality.hamster.duct-tape.d 
... sure does screw up the display.. */

      for(; fgetc(lst) != '\n';);
    }

  if(!end_lines)
    {
      temp = fgetc(lst);
      if(temp == EOF)
	end_lines = y - 1;
      else
	ungetc(temp, lst);
    }

  move((lines-1), x);
  attrset(A_STANDOUT);
  addstr(message);
  clrtoeol();
  refresh();

  fseek(lst, file_position, SEEK_SET);
  return end_lines;
}

int update_group_file(FILE *newsrc, FILE *group, char *message)
{
  char string[8192];
  char footer[80];
  int temp, count;
  long int lo, hi;
  unsigned short int point, subscribed;
  extern char current_group[256];
  extern char return_message[128];
  struct group_status gs;

  for(;;)
    {
      twirl(footer);
      strcat(footer, message);
      display_footer(footer);
      if(fgets(string, sizeof(string), newsrc) == NULL)
	break;
      for(point = 0;;point++)
	{
	  if(string[point] == ':')
	    {
	      subscribed = 1;   /* subscribed group */
	      break;
	    }
	  if(string[point] == '!')
	    {
	      subscribed = 0;   /* unsubscribed.... */
	      break;
	    }
	  current_group[point] = string[point];
	}
      current_group[point] = '\0';
      point++;

      if(subscribed)
	{
	  if(get_group_status(&gs))
	    {
	      strcpy(return_message, "error: server error");
	      return 1;
	    }

	  if(gs.result_code == 211)
	    {
	      count = (gs.end - gs.beginning) + 1;
	      if(!gs.their_estimate)
		count = 0;

	      /* point now points to the space between
		 the newsgroup name and the number of the first
		 article which has been read */

	      temp = 0;
	      lo = 0;
	      hi = 0;
	      get_next_read(string, point);    /* pass pointer only */
	      if(count)
		for(;;)
		  {
		    hi = lo = get_next_read(string, 0);
		    if(!lo)
		      break;
		    if(lo < 0)
		      {
			lo *= -1;
			hi = get_next_read(string, 0);
		      }
		    if(hi < gs.beginning)
		      continue;
		    temp = (hi - gs.beginning) + 1;
		    if(lo > gs.beginning)
		      temp -= lo - gs.beginning;
		    count -= temp;
		  }
	      count = count < 0 ? 0 : count;
	      fprintf(group, "%s %8d %8d\n", current_group, count, gs.our_estimate);
	    }
	}
    }
  return 0;
}

void long_to_string(char *s, long int temp, int digits)
{
  int count;
  long int power, temp1;

  power = 10;
  for(count = (digits - 1); count >= 0; count--)
    {
      temp1 = temp / power;
      temp1 *= power;
      temp1 = temp - temp1;
      s[count] = temp1 / (power / 10) + 48;   /* convert to ascii and store */
      temp -= temp1;
      power *= 10;
    }
  s[digits] = '\0';
  return;
}




int sort_text_file(size_t max, FILE *control, FILE *chaos)
{
  char *sort_list;
  char *sort_insert_pointer;
  char *sort_test_pointer;
  char *sort_end_pointer;
  char *sort_hi;
  char *sort_lo;
  char line[256];
  char line1[256];
  char line2[256];
  char string[60];
  short int count, temp, tw;

  if(sizeof(size_t) < 4)
    return 1;
  else
    {
      sort_list = malloc(max + 10);
      if(sort_list == NULL)
	return 1;
    }

  rewind(chaos);
  rewind(control);
  sort_insert_pointer = sort_list;
  sort_end_pointer = sort_insert_pointer; /* to prevent warnings from gcc */
  strcpy(line, " ");  /* everything should be higher than this */

  for(tw = 0;;tw++)
    {
      if(tw % 250 == 0)
	{
	  twirl(string);
	  strcat(string, " sorting..");
	  display_footer(string);
	}

      if(fgets(line1, sizeof(line1), chaos) == NULL)
	break;
      temp = strlen(line1);
      if(strcmp(line, line1) < 0)
	{
	  bcopy(line1, sort_insert_pointer, temp);
	  strcpy(line, line1);
	  sort_insert_pointer += temp;
	  sort_end_pointer = sort_insert_pointer;
	}
      else
	{

	  sort_lo = sort_list;
	  sort_hi = sort_end_pointer;
	  sort_insert_pointer = sort_lo + (sort_hi - sort_lo) / 2;

	  for(;;)
	    {
	      for(; sort_insert_pointer > sort_list; sort_insert_pointer--)
		{
		  if(*sort_insert_pointer == '\n')
		    {
		      sort_insert_pointer++;
		      break;
		    }
		}
	      sort_test_pointer = sort_insert_pointer;
	      count = 0;
	      do {
		line2[count++] = *sort_test_pointer;
		sort_test_pointer++;
	      } while(line2[count - 1] != '\n');
	      line2[count] = 0;
	      if(strcmp(line2, line1) > 0)
		{
		  sort_hi = sort_insert_pointer;
		  sort_insert_pointer = sort_lo + (sort_hi - sort_lo) / 2;
		}
	      else
		{
		  sort_lo = sort_test_pointer;
		  sort_insert_pointer = sort_lo + (sort_hi - sort_lo) / 2;
		}
	      if(sort_lo == sort_hi)
		break;
	    }


	  memmove(sort_insert_pointer + temp, sort_insert_pointer, sort_end_pointer - sort_insert_pointer);
	  bcopy(line1, sort_insert_pointer, temp);
	  sort_end_pointer += temp;
	  sort_insert_pointer = sort_end_pointer;
	}
    }

  for(sort_insert_pointer = sort_list; sort_insert_pointer < sort_end_pointer; sort_insert_pointer++)
    {
      if(fputc((int)*sort_insert_pointer, control) == EOF)
	{
	  free(sort_list);
	  return 2;
	}
    }
  free(sort_list);
  return 0;
}

void group_help_screen(void)
{

  /* pay attention to array size and screen position if you change this! */

  extern int lines;
  int y;
  char help_text[19][60] = {
    "KEY                    FUNCTION",
    " ",
    "a                      subscribe to single newsgroup",
    "c                      set cross-post threshold",
    "g                      show subscribed groups",
    "h                      display this help text",
    "l                      show all groups (may be slow)",
    "q                      quit SimpleNews (polite exit)",
    "s                      subscribe selected group",
    "u                      unsubscribe selected group",
    "<, left arrow          go back to server screen",
    "enter, right arrow     go to selected group",
    "k, up arrow            select previous group",
    "j, down arrow          select next group",
    "f, page down           scroll forward one screen",
    "b, page up             scroll back one screen",
    "F                      scroll forward 200 groups",
    "B                      scroll back 200 groups",
    "ctrl-c                 unconditional exit (rude exit)"
  };

  clear();
  attrset(A_NORMAL);
  for(y = 0; y < 19; y++)
    {
      move((y + 1), 5);
      addstr(help_text[y]);
    }
  move(lines - 1, 0);
  addstr("press any key to continue");
  refresh();
  return;
}
