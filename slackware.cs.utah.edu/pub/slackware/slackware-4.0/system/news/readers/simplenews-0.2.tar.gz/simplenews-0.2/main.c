/*
SimpleNews   NNTP reader for USENET news
Copyright (C) 1997  J. Howard Benson

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


flames, praise, job offers to:

  J. Howard Benson
  PO Box 60731
  Fairbanks, AK  99706

  hbenson@polarnet.fnsb.ak.us

*/

#include "defs.h"
#include "defines.h"
#include <signal.h>
#include <unistd.h>
#include <ctype.h>

/* global variables defined here */

short int posting;

short int group_open = 0;
short int hist_open = 0;
short int mainrc_open = 0;
short int newsrc_open = 0;
short int list_open = 0;
short int post_open = 0;
short int post_out_open = 0;
short int sort_open = 0;
short int text_open = 0;

unsigned short int xpost_threshold = 0;
int lines, columns;
long int selected_article;
char current_group[256];

char temp_group_filename[128];
char temp_list_filename[128];
char temp_post_filename[128];
char post_out_filename[128];
char temp_sort_filename[128];
char temp_text_filename[128];
char newsrc_filename[128];
char history_filename[128];

char editor[80];

char call_message[128];
char return_message[128];
char *home;
char *pointer;
char organization[STRINGSIZE] = "";
char email[STRINGSIZE] = "";
char true_email[STRINGSIZE] = "";
char name[STRINGSIZE] = "";
char sig_file[128] = "";
char server[STRINGSIZE];
FILE *out_stream, *hist, *in_stream, *list, *newsrc, *group;
FILE *mainrc, *post, *post_out, *sort, *text;

struct group_status {
  unsigned short int result_code;
  unsigned int their_estimate, our_estimate;
  long int beginning;
  long int end;
};


int server_window(void);
int group_window(void);
int article_window(void);
int text_window(void);
int get_group_status(struct group_status *gsp);
void twirl(char *string);
void display_footer(char *string);
int re_connect(char *message);
int manage_connection(int cmd, char *str, size_t str_size);
void panic_button();
void cleanup_files(void);


int main(void)
{
  char *buffer;
  char *termtype;
  char *ed;
  int next;
  short int count;
 
  signal(SIGINT, panic_button);
  home = getenv("HOME");

  sprintf(temp_group_filename, "%s/.simplenews.group", home);
  sprintf(temp_list_filename, "%s/.simplenews.list", home);
  sprintf(temp_post_filename, "%s/.simplenews.post", home);
  sprintf(temp_sort_filename, "%s/.simplenews.sort", home);
  sprintf(temp_text_filename, "%s/.simplenews.text", home);
  sprintf(post_out_filename, "%s/last_post", home);
  sprintf(history_filename, "%s/.simplenews.history", home);

  if(open_file(&hist, history_filename, "a+", &hist_open))
    {
      fprintf(stderr, "can not open history file\n");
      exit(1);
    }

  buffer = malloc(1024);    /* for BSD compatability */
  if(buffer == NULL)
    {
      fprintf(stderr, "out of memory\n");
      exit(1);
    }

  ed = getenv("EDITOR");
  if(ed == NULL)
    ed = getenv("VISUAL");
  if(ed == NULL)
    strcpy(editor, DEFAULT_EDITOR);
  else
    strcpy(editor, ed);

  /* check editor for strange characters to prevent any
     possibile  monkey business */

  for(count = 0; count < sizeof(editor) && editor[count]; count++)
    {
      if(islower(editor[count]))
	continue;
      strcpy(editor, DEFAULT_EDITOR);
      break;
    }

  termtype = getenv("TERM");
  if(termtype == NULL)
    {
      fprintf(stderr, "TERM environment variable not set\n");
      exit(1);
    }
  if(tgetent(buffer, termtype) != 1)
    {
      fprintf(stderr, "can not get termcap entry\n");
      exit(1);
    }
  lines = tgetnum("li");
  columns = tgetnum("co");
  free(buffer);

  initscr();
  cbreak();
  noecho();
  idlok(stdscr, TRUE);
  scrollok(stdscr, TRUE);
  keypad(stdscr, TRUE);

  strcpy(call_message, "start");
  next = server_window();

  for(;;)
    {
      switch(next) {
      case 0:
	erase();
	refresh();
	endwin();
	cleanup_files();
	if(!strncmp(return_message, "error:", 6))
	  {
	    fprintf(stderr, "\n%s\n", return_message);
	    exit(1);
	  }
	else
	  exit(0);
      case 1:
	next = server_window();
	break;
      case 2:
	next = group_window();
	break;
      case 3:
	next = article_window();
	break;
      case 4:
	next = text_window();
	break;
      }
    }

}


int get_group_status(struct group_status *gsp)
{
  char line[256];
  char line1[256];
  char result_text[16];
  int temp, temp1;
  short int count, result_code;
  short int flag = 0;
  extern int columns;
  extern short int posting;
  extern char server[STRINGSIZE];
  extern FILE *out_stream;
  extern FILE *in_stream;

redo:

  fprintf(out_stream, "group %s\r\n", current_group);
  fflush(out_stream);
  fgets(line, sizeof(line), in_stream);

  strncpy(result_text, line, 3);
  result_text[3] = '\0';
  gsp->result_code = atoi(result_text);
  if(gsp->result_code == 211)
    {
      for(temp = 3; line[temp] == ' '; temp++);
      for(temp1 = 0; temp1 < sizeof(result_text); temp1++)
	{
	  result_text[temp1] = line[temp];
	  if(line[++temp] == ' ')
	    break;
	}
      result_text[++temp1] = '\0';
      gsp->their_estimate = atoi(result_text);
      for(; line[temp] == ' '; temp++);
      for(temp1 = 0; temp1 < sizeof(result_text); temp1++)
	{
	  result_text[temp1] = line[temp];
	  if(line[++temp] == ' ')
	    break;
	}
      result_text[++temp1] = '\0';
      gsp->beginning = atol(result_text);
      for(; line[temp] == ' '; temp++);
      for(temp1 = 0; temp1 < sizeof(result_text); temp1++)
	{
	  result_text[temp1] = line[temp];
	  if(line[++temp] == ' ')
	    break;
	}
      result_text[++temp1] = '\0';
      gsp->end = atol(result_text);

      gsp->our_estimate = gsp->their_estimate ?
	(gsp->end - gsp->beginning) + 1 : 0;

    }
  else if(gsp->result_code != 411)
    {
      if(++flag > 1)
	return 1;
      manage_connection(2, "", 0);       /* bad server response - pull the plug */
      sprintf(line1, "bad server response: %s", line);
      for(count = 0; count < columns; count++)
	if(line1[count] == '\r' || line1[count] == '\n')
	  line1[count] = 0;
      line1[columns] = 0;
      display_footer(line1);
      sleep(1);
      display_footer("connecting to server..");
      if(manage_connection(0, server, STRINGSIZE))
	return 1;
      fgets(line, sizeof(line), in_stream);
      strncpy(result_text, line, 3);
      result_text[3] = 0;
      result_code = atoi(result_text);
      if(result_code == 200)
	posting = 1;
      if(result_code == 201)
	posting = 0;
      goto redo;
    }
  return 0;
}

void twirl(char *string)
{

  static short int state = 0;

	  /* This produces a gopher style twirling display to fool the
	     user into thinking that time is passing productively.. */

	  switch(state) {

	  case 0:
	    strcpy(string, "|");
	    break;
	  case 1:
	    strcpy(string, "/");
	    break;
	  case 2:
	    strcpy(string, "-");
	    break;
	  case 3:
	    strcpy(string, "\\");
	    break;
	  }
	  state = state < 3 ? state + 1 : 0;

	  return;
}

void display_footer(char *string)
{
  extern int lines;

  move((lines-1), 0);
  attrset(A_STANDOUT);
  addstr(string);
  clrtoeol();
  refresh();
  return;
}
void panic_button()
{
  endwin();
  cleanup_files();
  fprintf(stderr, "\nterminated by user\n");
  exit(1);
}

int re_connect(char *message)
{
  extern int columns;
  extern char current_group[256];
  extern char server[STRINGSIZE];
  extern short int posting;
  extern FILE *in_stream, *out_stream;
  char result_text[16];
  char string[256];
  short int count, result_code;

  sprintf(string, "unexpected response from server: %s", message);
  for(count = 0; count < columns; count++)
    if(string[count] == '\r' || string[count] == '\n')
      string[count] = 0;
  string[columns] = 0;
  display_footer(string);
  manage_connection(2, "", 0);       /* pull the plug */
  sleep(2);
  display_footer("connecting to server..");
  if(manage_connection(0, server, STRINGSIZE))
    return 1;
  fgets(string, sizeof(string), in_stream);
  strncpy(result_text, string, 3);
  result_text[3] = '\0';
  result_code = atoi(result_text);
  if(result_code == 200)
    posting = 1;
  if(result_code == 201)
    posting = 0;

  fprintf(out_stream, "group %s\r\n", current_group);
  fflush(out_stream);
  fgets(string, sizeof(string), in_stream);
  strncpy(result_text, string, 3);
  result_text[3] = '\0';
  result_code = atoi(result_text);
  if(result_code != 211)
    return 1;
  return 0;
}

int open_file(FILE **fp, char *name, char *mode, short int *flag)
{
  signal(SIGINT, SIG_IGN);     /* ignore SIGINT while we open file */
  if(*flag)
    return 1;
  if((*fp = fopen(name, mode)) == NULL)
    return 1;
  *flag = 1;
  signal(SIGINT, panic_button);
  return 0;
}

int close_file(FILE *fp, short int *flag)
{
  int result = 1;

  signal(SIGINT, SIG_IGN);     /* ignore SIGINT while we close file */
  if(*flag)                    /* close only open files */
    result = fclose(fp);
  *flag = 0;
  signal(SIGINT, panic_button);
  return result;
}

void cleanup_files(void)
{
  extern char temp_group_filename[128];
  extern char temp_list_filename[128];
  extern char temp_post_filename[128];
  extern char post_out_filename[128];
  extern char temp_sort_filename[128];
  extern char temp_text_filename[128];
  extern FILE *group, *hist, *list, *mainrc, *newsrc, *post, *post_out, *sort, *text;
  extern short int group_open, hist_open, list_open, mainrc_open, newsrc_open;
  extern short int post_open, post_out_open, sort_open, text_open;

  close_file(group, &group_open);
  close_file(hist, &hist_open);
  close_file(list, &list_open);
  close_file(mainrc, &mainrc_open);
  close_file(newsrc, &newsrc_open);
  close_file(post, &post_open);
  close_file(post_out, &post_out_open);
  close_file(sort, &sort_open);
  close_file(text, &text_open);

  remove(temp_group_filename);
  remove(temp_list_filename);
  remove(temp_post_filename);
  remove(post_out_filename);
  remove(temp_sort_filename);
  remove(temp_text_filename);

  return;
}
