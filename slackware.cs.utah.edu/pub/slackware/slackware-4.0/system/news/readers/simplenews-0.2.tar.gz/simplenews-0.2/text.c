/*
SimpleNews   NNTP reader for USENET news
Copyright (C) 1997  J. Howard Benson

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


flames, praise, job offers to:

  J. Howard Benson
  PO Box 60731
  Fairbanks, AK  99706

  hbenson@polarnet.fnsb.ak.us

*/

#include "defines.h"

struct header {
  char path[80];
  char newsgroups[MAX_GROUPS][80];
  char subject[80];
  char sender[80];
  char newsreader[80];
  char references[1024];
  char originator[80];
};

#include "defs.h"
#include "text.h"

int text_window(void)
{
  extern FILE *out_stream, *in_stream, *text, *post;
  extern char *home;

  extern char editor[80];

  extern char call_message[128];
  extern char current_group[256];
  extern char email[STRINGSIZE];
  extern char return_message[128];
  extern char sig_file[128];
  extern char temp_post_filename[128];
  extern char temp_text_filename[128];
  extern int lines, columns;
  extern long int selected_article;
  extern short int posting, post_open, text_open;
  char ref[8180];
  char ng[8180];
  char line[8192];
  char line1[80];
  char result_text[16];
  char save_file[128];
  int in, end;
  int count, count1, temp, temp1;
  short int result_code, flag;
  struct header fhdr;
  FILE *sig, *save;


  display_footer("contacting server");
  if(open_file(&text, temp_text_filename, "w+", &text_open))
    {
      strcpy(return_message, "error: can not open text file");
      strcpy(call_message, "q");
      return 3;
    }

  long_to_string(line1, selected_article, 16);
  while(line1[0] == '0')
    for(temp = 0; temp < (sizeof(line1) - 1); temp++)
      line1[temp] = line1[temp + 1];
  fprintf(out_stream, "article %s\r\n", line1);
  fflush(out_stream);
  fgets(line, sizeof(line), in_stream);
  strncpy(result_text, line, 3);
  result_text[3] = '\0';
  result_code = atoi(result_text);
  if(result_code != 220)
    {
      if(re_connect(line))
	{
	  strcpy(call_message, "q");
	  strcpy(return_message, "error: can not make new connection");
	  return 3;
	}
      fprintf(out_stream, "article %s\r\n", line1);
      fflush(out_stream);
      fgets(line, sizeof(line), in_stream);
      strncpy(result_text, line, 3);
      result_text[3] = '\0';
      result_code = atoi(result_text);
      if(result_code != 220)
	{
	  strcpy(call_message, "q");
	  strcpy(return_message, "error: can not make new connection");
	  return 3;
	}
    }

  flag = 1;     /* 1 = header, 0 = body */
  ref[0] = 0;

  for(count1 = 0;;count1++)
    {
      if(count1 % 20 == 0)
	{
	  twirl(line1);
	  strcat(line1, " recieving text");
	  display_footer(line1);
	}

      fgets(line, sizeof(line), in_stream);

      /* echo non printing stuff except \n and \r as a space
       real nerds don't use tabs in usenet postings */
      for(count = 0; count < sizeof(line); count++)
	{
	  if(line[count] < ' ' && line[count] != '\r'
	     && line[count] != '\n' && line[count])
	    line[count] = ' ';
	}

      /* first empty line signals end of header */

      if(line[0] == '\r' || line[0] == '\n')
	flag = 0;

      /* here we save the Newsgroups: and References: lines because
	 unwrapping them is difficult should they be needed to
	 generate a header for a followup article. */

      if(flag)
	{
	  if(!strncmp(line, "References: ", 12))
	    {
	      strcpy(ref, line+12);
	      for(count = 0; ref[count] && ref[count] != '\r' &&
		ref[count] != '\n'; count++);
	      ref[count] = 0;
	    }
	  if(!strncmp(line, "Newsgroups: ", 12))
	    {
	      strcpy(ng, line+12);
	      for(count = 0; ng[count] && ng[count] != '\r' &&
		    ng[count] != '\n'; count++);
	      ng[count] = 0;
	    }
	}

      if(line[0] == '.')
	{
	  if(line[1] == '\r' || line[1] == '\n')
	    break;
	}
      temp = strlen(line);
      while(temp > columns)    /* wrap long lines on word boundaries */
	{
	  count = (columns - 1);
	  while(line[count] != ' ' && line[count] != '!' && line[count] != ',')
	    {
	      count--;
	      if(!count)
		break;
	    }

	  count = count ? count + 1 : columns;
	  temp -= count;
	  for(; count; count--)
	    {
	      fputc((int)line[0], text);
	      for(temp1 = 0; temp1 < sizeof(line); temp1++)
		line[temp1] = line[temp1 + 1];
	    }
	  fputc('\n', text);
	}
      for(count = 0; count < strlen(line); count++)
	if(line[count] != '\r')
	  fputc((int)line[count], text);
    }

  rewind(text);
  end = update_text_screen("", text);

  for(;;)
    {
      in = getch();
      switch(in) {

      case 'h':
	text_help_screen();
	getch();              /* press any key to continue..  */
	end = update_text_screen("", text);
	break;


      case 'p':
	if(!posting)
	  {
	    display_footer("Sorry...  posting not allowed on this server right now");
	    break;
	  }
	display_footer("post followup article? ");
	echo();
	wgetnstr(stdscr, line, sizeof(line));
	noecho();
	if(strncmp(line, "y", 1))
	  {
	    display_footer("");
	    break;
	  }
	if(!strlen(email))
	  {
	    display_footer("e-mail address must be set");
	    break;
	  }
	followup_header(&fhdr, text, ng, ref);
	display_footer("include original text? ");
	echo();
	wgetnstr(stdscr, line, sizeof(line));
	noecho();
	if(!strncmp(line, "y", 1))
	  {
	    if(open_file(&post, temp_post_filename, "w", &post_open))
	      {
		strcpy(return_message, "error: can not open post file");
		strcpy(call_message, "q");
		return 3;
	      }
	    fprintf(post, "in %s,\n", current_group);
	    fprintf(post, "%s wrote:\n", fhdr.originator);
	    rewind(text);
	    for(;;)    /* strip header from article */
	      {
		temp = fgetc(text);
		if(temp == EOF)
		  break;
		if(temp == '\n')
		  {
		    temp = fgetc(text);
		    if(temp == '\r')
		      temp = fgetc(text);
		    if(temp == '\n')
		      break;
		  }
	      }
	    fputc('>', post);
	    temp = fgetc(text);
	    for(;;)             /*  mark included text with >  */
	      {
		temp1 = fgetc(text);
		if(temp1 == EOF)
		  break;
		if(temp != '\r')
		  {
		    fputc(temp, post);
		    if(temp == '\n')
		      fputc('>', post);
		    temp = temp1;
		  }
	      }
	    fputc('\n', post);
	    close_file(post, &post_open);
	  }

	if(open_file(&post, temp_post_filename, "a", &post_open))
	  {
	    strcpy(return_message, "error: can not open post file");
	    strcpy(call_message, "q");
	    return 3;
	  }
	sig = fopen(sig_file, "r");
	if(sig != NULL)
	  {
	    fprintf(post, "\n---\n");
	    while(fgets(line, sizeof(line), sig) != NULL)
	      fputs(line, post);
	    fclose(sig);
	  }
	close_file(post, &post_open);
	sprintf(line, "%s %s", editor, temp_post_filename);
	endwin();

	if(system(line))
	  {
	    strcpy(call_message, "q");
	    sprintf(return_message, "error: unable to run \"sh -c %s %s\"",
		    editor, temp_post_filename);
	    return 2;
	  }

	initscr();
	cbreak();
	noecho();
	idlok(stdscr, TRUE);
	scrollok(stdscr, TRUE);
	keypad(stdscr, TRUE);
	erase();
	display_footer("really post it? ");
	echo();
	wgetnstr(stdscr, line, sizeof(line));
	noecho();
	if(strncmp(line, "y", 1))
	  {
	    sprintf(line, "%s/dead_post", home);
	    rename(temp_post_filename, line);
	    rewind(text);
	    end = update_text_screen("text saved in \"dead_post\"", text);
	    break;
	  }

	temp = post_it(&fhdr);
	if(temp == 1)
	  {
	    strcpy(call_message, "q");
	    strcpy(return_message, "error: file error");
	    return 3;
	  }
	if(temp == 2)
	  {
	    strcpy(call_message, "q");
	    strcpy(return_message, "error: can not make new connection");
	    return 2;
	  }

	rewind(text);
	end = update_text_screen(fhdr.references, text);  /* sleaze is good */
	break;



      case 'q':
	strcpy(call_message, "q");
	strcpy(return_message, "");
	return 3;

      case 's':
	display_footer("save article as: ");
	echo();
	wgetnstr(stdscr, line, STRINGSIZE - 1);
	noecho();
	if(line[0] == '~')
	  sprintf(save_file, "%s%s", home, line+1);
	else if(*line)
	  strcpy(save_file, line);
	else
	  {
	    rewind(text);
	    end = update_text_screen("", text);
	    break;
	  }

	strcpy(line, "article saved");
	if((save = fopen(save_file, "w")) == NULL)
	  strcpy(line, "sorry.. can not create file");
	else
	  {
	    rewind(text);
	    while((temp = fgetc(text)) != EOF)
	      if(fputc(temp, save) == EOF)
		{
		  strcpy(line, "error writing file");
		  break;
		}
	  }
	fclose(save);
	rewind(text);
	end = update_text_screen(line, text);

	break;
	


      case '<':
      case KEY_LEFT:
	close_file(text, &text_open);
	strcpy(call_message, "text");
	strcpy(return_message, "");
	return 3;

      case 'k':
      case KEY_UP:
	for(;;)
	  {
	    if(ftell(text) < 2)
	      {
		rewind(text);
		break;
	      }
	    fseek(text, -2, SEEK_CUR);
	    if(fgetc(text) == '\n')
	      break;
	  }
	end = update_text_screen("", text);
	break;

      case 'j':
      case KEY_DOWN:
	if(end)
	  break;
	while(fgetc(text) != '\n');
	end = update_text_screen("", text);
	break;

      case 'b':
      case KEY_PPAGE:
	for(count = 0; count < (lines - 3); count++)
	  {
	    if(ftell(text) == 0)
	      break;
	    for(;;)
	      {
		if(ftell(text) < 2)
		  {
		    rewind(text);
		    break;
		  }
		fseek(text, -2, SEEK_CUR);
		if(fgetc(text) == '\n')
		  break;
	      }
	  }
	end = update_text_screen("", text);
	break;

      case 'f':
      case KEY_NPAGE:
	if(end)
	  break;
	for(count = 0; count < (lines - 3); count++)
	  for(;fgetc(text) != '\n';);
	end = update_text_screen("", text);
	break;

      default:
	display_footer("unknown command");
	break;
      }
    }
}

int update_text_screen(char *message, FILE *txt)
{
  extern int lines;
  int temp;
  int x, y;
  int flag = 0;
  long int file_position;
  char *h3 = "\"h\" for help ";

  display_header("Article Text", h3);

  attrset(A_NORMAL);
  x = 0;
  file_position = ftell(txt);
  for(y = 1; y < (lines - 1); y++)
    {
      move(y, x);
      if(!flag)
	{
	  for(;;)
	    {
	      temp = fgetc(txt);
	      if(temp == EOF)
		{
		  flag++;
		  clrtoeol();
		  break;
		}
	      else if(temp != '\r' && temp != '\n')
		addch((chtype)temp);
	      else
		{
		  clrtoeol();
		  break;
		}
	    }
	}
      else
	clrtoeol();
    }

  move((lines-1), x);
  attrset(A_STANDOUT);
  addstr(message);
  clrtoeol();
  refresh();

  fseek(txt, file_position, SEEK_SET);
  return flag;
}

void text_help_screen(void)
{

  /* pay attention to array size and screen position if you change this! */

  extern int lines;
  int y;
  char help_text[12][60] = {
    "KEY                    FUNCTION",
    " ",
    "h                      display this help text",
    "p                      post followup to article",
    "q                      quit SimpleNews (polite exit)",
    "s                      save article to file",
    "<, left arrow          go back to article screen",
    "k, up arrow            scroll up one line",
    "j, down arrow          scroll down one line",
    "f, page down           scroll forward one screen",
    "b, page up             scroll back one screen",
    "ctrl-c                 unconditional exit (rude exit)"
  };

  clear();
  attrset(A_NORMAL);
  for(y = 0; y < 12; y++)
    {
      move((y + 2), 5);
      addstr(help_text[y]);
    }
  move(lines - 1, 0);
  addstr("press any key to continue");
  refresh();
  return;
}

void followup_header(struct header *hdrp, FILE *text, char *ng, char *ref)
{
  extern char email[STRINGSIZE];
  extern char true_email[STRINGSIZE];
  char line[128];
  char line1[128];
  char line2[140];
  char name[80];
  short int count, count1, count2, flag;


  gethostname(name, sizeof(name));
  strcpy(hdrp->path, name);
  echo();

begin:

  for(count = count1 = 0; ng[count]; count++)
    if(ng[count] == ',')
      count1++;               /* count up the cross postings */

  if(count1 >= MAX_GROUPS)    /* and enforce some netiquette */
    {
      sprintf(line1, "Select no more than %d groups", MAX_GROUPS);
      display_footer(line1);
      sleep(2);
    }

  for(count = 0; count < MAX_GROUPS; count++)
    strcpy(hdrp->newsgroups[count], "");

  flag = 1;
  count = count1 = 0;
  while(flag)
    {
      count2 = 0;
      for(;;count++, count2++)
	{
	  if(ng[count] == ',')
	    {
	      count++;
	      break;
	    }
	  if(!ng[count])
	    {
	      flag = 0;
	      break;
	    }
	  line1[count2] = ng[count];
	}
      line1[count2] = 0;       /* make it a null terminated string */
      sprintf(line2, "post to \"%s\"? ", line1);
      display_footer(line2);
      wgetnstr(stdscr, line, sizeof(line));
      if(!strncmp(line, "y", 1))
	{
	  strcpy(hdrp->newsgroups[count1], line1);
	  if(++count1 == MAX_GROUPS)
	    flag = 0;
	}
    }
  if(!*hdrp->newsgroups[0])
    {
      display_footer("Please make a selection");
      sleep(2);
      goto begin;
    }

  rewind(text);
  while(fgets(line, sizeof(line), text) != NULL)
    {
      if(line[0] == '\r' || line[0] == '\n')
	break;

      if(!strncmp(line, "Subject: ", 9))
	{
	  strcpy(hdrp->subject, "Re: ");
	  if(strncmp(line+9, "Re: ", 4) && strncmp(line+9, "RE: ", 4))
	    strcat(hdrp->subject, line+9);
	  else
	    strcat(hdrp->subject, line+13);
	  for(count = 0; hdrp->subject[count] && hdrp->subject[count] != '\r' &&
		hdrp->subject[count] != '\n'; count++);
	  hdrp->subject[count] = 0;
	}

      if(!strncmp(line, "From: ", 6))
	{
	  strcpy(hdrp->originator, line+6);
	  for(count = 0; hdrp->originator[count] && hdrp->originator[count] != '\r' &&
		hdrp->originator[count] != '\n'; count++);
	  hdrp->originator[count] = 0;
	}

      if(!strncmp(line, "Message-ID: ", 12))
	{
	  sscanf(line+12, "%s", hdrp->references);
	  if(ref[0])
	    {
	      strcat(hdrp->references, " ");
	      strcat(hdrp->references, ref);
	    }
	}
    }

  /*
  date = popen("date -u \'+%d %b %Y %T GMT\'", "r");
  fgets(hdrp->date, sizeof(hdrp->date), date);
  pclose(date);

  for(count = 0; hdrp->date[count] && hdrp->date[count] != '\r' &&
	hdrp->date[count] != '\n'; count++);
  hdrp->date[count] = 0;
  */

  strcpy(hdrp->sender, "");
  
  /* If the strip-mining spam-bots ever get smart enough to
     check the 'Sender:' line, comment the following two lines out
     to make effective address munging possible */

  if(strcmp(email, true_email))
    strcpy(hdrp->sender, true_email);



  sprintf(hdrp->newsreader, "%s  %s/%s", VERSION, getenv("OSTYPE"),
	  getenv("HOSTTYPE"));

  noecho();
  return;
}
