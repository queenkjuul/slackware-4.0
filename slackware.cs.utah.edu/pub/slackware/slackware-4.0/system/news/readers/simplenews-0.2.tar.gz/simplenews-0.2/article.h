#include <unistd.h>

int article_window(void);

int get_group_status(struct group_status *gsp);

long int get_next_read(char *s, int pnt);

void long_to_string(char *s, long int temp, int digits);

int update_article_display(struct article *artp, int start, int current, short int toggle);

void display_header(char *head2, char *head3);

void get_email_address(char *lp, size_t max);

int mark_read_articles(struct article *artp, char * gl, size_t max, long int start);

void twirl(char *string);

void article_help_screen(void);

void display_footer(char *string);

void new_header(struct header *hdrp);

int post_it(struct header *hdrp);

int re_connect(char *message);

int detect_dup(char *id);
