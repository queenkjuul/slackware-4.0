#define RCFILE "/.simplenewsrc"
#define VERSION "SimpleNews-0.2"
#define DEFAULT_EDITOR "vi"        /* insert your favorite editor here
				      or set EDITOR in your environment */
#define STRINGSIZE 50
#define IP 0
#define MAX_ARTICLES 1000          /* absolute maximum articles to retrieve
				      trim this if you're short on memory */
#define RETRIEVE_LIMIT 200         /* (default) max articles to retrieve */
#define READ_ARRAY_SIZE 350        /* max allowed number of numeric entries
				      on each line of .newsrc */
#define NNTP_PORT 119              /* TCP port for news server */
#define MAX_HISTORY 20000          /* max entries in history file */

/*
MAX_GROUPS is small to prevent abuse by cross-posting spam generating scum..
if you're one of these and you change this, hang your head in shame
*/
#define MAX_GROUPS 3

