#include <curses.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termcap.h>

int open_file(FILE **fp, char *name, char *mode, short int *flag);

int close_file(FILE *fp, short int *flag);
