/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "peruser.h"
#include<unistd.h>
#include "update.h"

/*
 * Constructor.
 */

void update_init( void *this )
{
   np_buttons_object *buttons;
   np_update_object *update;


   buttons = ( np_buttons_object *)this;
   update = ( np_update_object *)buttons->update_object;

   update->parent = buttons;

   update->callback = update_callback;
   update->show_message = update_show_message;

   update->do_group = update_do_group;
   update->expire_group = update_expire_group;
   update->update_newsgroup = update_update_newsgroup;
   update->update_folder = update_update_folder;
   update->update_inbox = update_update_inbox;
   update->radio_callback = update_radio_callback;
   update->iterate = update_iterate;
   update->do_virtual = update_do_virtual;
   update->send_mail = update_send_mail;
   update->virtual_frame_callback = update_virtual_frame_callback;

   update->open_server = update_open_server;
   update->ask_what = update_ask_what;
   update->authenticating = update_authenticating;
   update->grey_slider = update_grey_slider;
   update->ungrey_slider = update_ungrey_slider;

   update->progress_callback = update_progress_callback;
   update->filter_progress_callback = update_filter_progress_callback;
   update->disable_interface = update_disable_interface;
   update->interrupt_callback = update_interrupt_callback;
   update->connect_callback = update_connect_callback;

   return;
}

/*
 * Called from ln_update_group() with stats for interface to give feedback to
 * user while library is downloading.
 */

int update_progress_callback( void *this, char *group,
                              unsigned int lines,
                              unsigned int begin, 
                              unsigned int current, 
                              unsigned int end )
{
   np_update_object *update;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ], *pointer;
   float  numerator, denominator, percent;


   update = ( np_update_object *)this;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)update->parent )->parent;

   numerator = current;
   denominator = end - begin; 

   if ( update->interrupt )
      return 1;

   if ( group[ 0 ] == ':' )
      pointer = group + 1;
   else
      pointer = group;

   percent = numerator / denominator * 100;
   if ( !lines )
      if (( ( unsigned int )percent ) % 5 )
         return 0;

   if ( !lines )
      snprintf( buffer, LN_BUFFER_SIZE, "Updating: %s: %2.0f%%", pointer,
                percent );
   else
      snprintf( buffer, LN_BUFFER_SIZE, "Updating: %s: %2.0f%%: "
                "long article: %d lines read", pointer,
                percent, lines );

   newsreader->show_message( newsreader, buffer );

   return 0;
}

/* 
 * Determines whether a server requires authentication by reading its entries
 * in ~/.peruser3-config, and if server does require authentication, copies the
 * appropriate username and password into the character arrays pointed to by
 * the value-result arguments user and pass.
 */

int update_authenticating( void *this, unsigned int j, 
                           char *user, char *pass )
{
   np_update_object *update;
   np_newsrc_object *newsrc;

   char buffer[ LN_BUFFER_SIZE ];
   int i;
   FILE *config;


   update = ( np_update_object *)this;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)update->parent )->newsrc_object;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config", getenv( "HOME" ));
   if (( config = fopen( buffer, "r" )) == NULL )
      if ( errno == ENOENT )
         return -1;
      else
         fatal_error();

   fgets( buffer, LN_BUFFER_SIZE, config );
   fgets( buffer, LN_BUFFER_SIZE, config );
   fgets( buffer, LN_BUFFER_SIZE, config );

   while( j-- )
   {
      for( i = 0; i < 3; ++i )
         if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
         {
            fclose( config );

            strcpy( ln_error_message, "premature end of ~/.peruser3-config" );
            newsrc->confirm( newsrc, ln_error_message, NP_DONE );
            newsrc->answer = 0;
            while( !newsrc->answer )
               EZ_WaitAndServiceNextEvent();

            return -1;
         }
   }

   for( i = 0; i < 3; ++i )
   {
      if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
      {
         strcpy( ln_error_message, "premature end of ~/.peruser3-config" );
         newsrc->confirm( newsrc, ln_error_message, NP_DONE );
         newsrc->answer = 0;
         while( !newsrc->answer )
            EZ_WaitAndServiceNextEvent();

         fclose( config );
         return -1;
      }

      switch( i )
      {
         case 0:
            if ( buffer[ 0 ] == '0' )
            {
               fclose( config );
               return 0;
            }
            break;

         case 1:
            if ( strtok( buffer, "\n" ) == NULL )
            {
               fclose( config );
               strcpy( buffer, "You have not entered a user name for\n"
                       "this server in the general setup window" );
               newsrc->confirm( newsrc, buffer, NP_DONE );
               newsrc->answer = 0;
               while( !newsrc->answer )
                  EZ_WaitAndServiceNextEvent();

               return -1;
            }

            strcpy( user, buffer );
            break;

         case 2:
            if ( strtok( buffer, "\n" ) == NULL )
            {
               fclose( config );
               strcpy( buffer, "You have not entered a password for\n"
                       "this server in the general setup window." );
               newsrc->confirm( newsrc, buffer, NP_DONE );
               newsrc->answer = 0;
               while( !newsrc->answer )
                  EZ_WaitAndServiceNextEvent();

               return -1;
            }

            strcpy( pass, buffer );
            break;
      }
   }    

   return 1;
}

int update_connect_callback( void *data, int expired )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_update_object *update;

   char buffer[ 40 ];
   
   update = ( np_update_object *)data;
   buttons = ( np_buttons_object *)update->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;

   if ( update->interrupt )
      return -1;

   snprintf( buffer, LN_BUFFER_SIZE, "Waiting for connection to complete: "
             "%d seconds", expired );
   newsreader->show_message( newsreader, buffer );

   return 0;
}

/*
 * Attempts to open a connection to the desired server, get welcome
 * message, and if necessary, authenticate.
 */

int update_open_server( void *this, char *server, unsigned int j )
{
   np_update_object *update;
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_newsrc_object *newsrc;

   char buffer[ LN_BUFFER_SIZE ], *test;
   char user[ LN_BUFFER_SIZE ], pass[ LN_BUFFER_SIZE ];

   int i, result;


   update = ( np_update_object *)this;
   buttons = ( np_buttons_object *)update->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   update->interrupt = 0;

   snprintf( buffer, LN_BUFFER_SIZE, "Connecting to %s...", server );
   newsreader->show_message( newsreader, buffer );

   update->connect = 1;
   if (( result = ln_open_server( server, &update->stream, 
                                  update->connect_callback, update )))
   {
      if ( result == -10 )
      {
         strcpy( buffer, "Connection cancelled." );
         update->disable_interface( newsreader, 0 );
      }
      else
         snprintf( buffer, LN_BUFFER_SIZE, 
               "Cannot connect to server:\n%s", server );

      newsrc->confirm( newsrc, buffer, NP_DONE );
      newsrc->answer = 0;
      while( !newsrc->answer )
         EZ_WaitAndServiceNextEvent();

      update->what = LN_CANCEL;
      return -1;
   }

   if ( update->what == LN_NOTHING )
   {
      test = "200";
      i = 3;
   }
   else
   {
      test = "20";
      i = 2;
   }

   if ( ln_fgets( buffer, LN_BUFFER_SIZE, update->stream ) == NULL )
   {
      if ( errno == ETIMEDOUT )
         snprintf( buffer, LN_BUFFER_SIZE, "Server has not responded "
                   "after %d seconds.\nClosing connection.", LN_SECONDS );
      else
         strcpy( buffer, "Connection closed by server." );

      newsrc->answer = 0;
      newsrc->confirm( newsrc, buffer, NP_DONE );
      while( !newsrc->answer )
         EZ_WaitAndServiceNextEvent();

      fclose( update->stream );
      update->what = LN_CANCEL;
      return -1;
   }

   if ( strncmp( buffer, test, i ))
   {
      snprintf( buffer, LN_BUFFER_SIZE, 
                "%s\nresponded with a non-welcoming message.", server );
      newsrc->confirm( newsrc, buffer, NP_DONE );
      newsrc->answer = 0;
      if ( !newsrc->answer )
         EZ_WaitAndServiceNextEvent();

      fclose( update->stream );
      update->what = LN_CANCEL;
      return -1;
   }


   if ( ( result = update->authenticating( update, j, ( char *)&user, 
                                           ( char *)&pass )))
   {
      if ( result == -1 )
      {
         strcpy( buffer, 
                 "You haven't configured this server. Press the \"setup\""
                 "button and choose the \"general.\" menu item." );
         newsrc->confirm( newsrc, buffer, NP_DONE );
         newsrc->answer = 0;
         while( !newsrc->answer )
            EZ_WaitAndServiceNextEvent();

         update->what = LN_CANCEL;
         return -1;
      }

      fprintf( update->stream, "authinfo user %s\r\n", user );
      fgets( buffer, LN_BUFFER_SIZE, update->stream );
      if ( strncmp( buffer, "381", 3 ) )
      {
         snprintf( buffer, LN_BUFFER_SIZE, "%s\nrejected user name %s", 
                   server, user );
         newsrc->confirm( newsrc, buffer, NP_DONE );
         newsrc->answer = 0;
         while( !newsrc->answer )
            EZ_WaitAndServiceNextEvent();

         update->what = LN_CANCEL;
         return -1;
      }

      fprintf( update->stream, "authinfo pass %s\r\n", pass );
      fgets( buffer, LN_BUFFER_SIZE, update->stream );
      if ( strncmp( buffer, "281", 3 ) )
      {
         snprintf( buffer, LN_BUFFER_SIZE, "%s\nrejected password", server );
         newsrc->confirm( newsrc, buffer, NP_DONE );
         newsrc->answer = 0;
         while( !newsrc->answer )
            EZ_WaitAndServiceNextEvent();

         update->what = LN_CANCEL;
         return -1;
      }
   }

   fputs( "mode reader\r\n", update->stream );
   fgets( buffer, LN_BUFFER_SIZE, update->stream );
   if ( strncmp( buffer, test, i ))
      if ( strncmp( buffer, "500", 3 ))
      {
         snprintf( buffer, LN_BUFFER_SIZE, "%s: %s", server, buffer );
         newsrc->confirm( newsrc, buffer, NP_DONE );
         newsrc->answer = 0;
         while( !newsrc->answer )
            EZ_WaitAndServiceNextEvent();

         update->what = LN_CANCEL;
         return -1;
      }

   return 0;
}

int update_do_virtual( void *this )
{
   np_update_object *update;
   np_newsrc_object *newsrc;

   EZ_Widget *frame, *button_frame, *update_button, *radio_frame;


   update = ( np_update_object *)this;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)update->parent )->newsrc_object;

   frame = EZ_CreateFrame( NULL, "Update Virtual Group(s)" );

   EZ_ConfigureWidget( frame,
                       EZ_HEIGHT, 300,
                       EZ_WIDTH, 300,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_IPADY, 5,
                       0 );

   radio_frame = EZ_CreateFrame( frame, "Choose one:" );

   EZ_ConfigureWidget( radio_frame,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_HEIGHT, 200,
                       EZ_WIDTH, 200,
                       EZ_IPADY, 0,
                       0 ); 

   update_button = EZ_CreateRadioButton( radio_frame, 
                                         "Run filter(s)", 0, 0, 0 );

   EZ_ConfigureWidget( update_button,
                       EZ_CALLBACK, update->virtual_frame_callback, update,
                       EZ_HEIGHT, 30,
                       EZ_CLIENT_INT_DATA, 0,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       0 );

   EZ_ConfigureWidget( EZ_CreateRadioButton( radio_frame, 
                                             "Retrieve requests", 0, 0,
                                             1 ),
                       EZ_CALLBACK, update->virtual_frame_callback, update,
                       EZ_HEIGHT, 30,
                       EZ_CLIENT_INT_DATA, 1,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       0 );

   button_frame = EZ_CreateFrame( frame, NULL );

   EZ_ConfigureWidget( button_frame,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( button_frame, "go", 0 ),
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, update->virtual_frame_callback, update,
                       EZ_CLIENT_INT_DATA, 2,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( button_frame, "cancel", 0 ),
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, update->virtual_frame_callback, update,
                       EZ_CLIENT_INT_DATA, 3,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       0 );

   EZ_SetRadioButtonGroupVariableValue( update_button, 0 );

   newsrc->answer = 0;
   update->quantity = -1;
   EZ_DisplayWidget( frame );
   EZ_SetGrab( frame );

   while( update->quantity == -1 )
      EZ_WaitAndServiceNextEvent();

   EZ_DestroyWidget( frame );

   if ( !( update->quantity ))
      newsrc->answer = 2;

   return newsrc->answer;
}

void update_virtual_frame_callback( EZ_Widget *widget, void *data )
{
   np_update_object *update;
   np_newsrc_object *newsrc;


   update = ( np_update_object *)data;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)update->parent )->newsrc_object;

   switch( EZ_GetWidgetIntData( widget ))
   {
      case 0:
         newsrc->answer = 0;
         break;

      case 1:
         newsrc->answer = 1;
         break;

      case 2:
         update->quantity = 1;
         break;

      case 3:
         newsrc->answer = 2;
         update->quantity = 0;
         break;
   }
   
   return;
}

void update_disable_interface( void *newsreader_object, char i )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_update_object *update;


   newsreader = ( np_newsreader_object *)newsreader_object;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   update = ( np_update_object *)buttons->update_object;

   if ( i )
   {
      EZ_DisableWidget( buttons->help_button );
      EZ_DisableWidget( buttons->setup_button );
      EZ_DisableWidget( buttons->update_button );
      EZ_DisableWidget( buttons->request_button );
      EZ_DisableWidget( buttons->compose_button );
      EZ_DisableWidget( buttons->edit_menu_button );
      EZ_DisableWidget( buttons->toggle_button );
      EZ_DisableWidget( buttons->mark_button );
      EZ_DisableWidget( buttons->pack_button );
      EZ_DisableWidget( buttons->expire_button );
      EZ_DisableWidget( buttons->decode_button );
      EZ_DisableWidget( buttons->summary_button );
      EZ_DisableWidget( buttons->search_button );
      EZ_DisableWidget( buttons->export_button );

      EZ_ConfigureWidget( buttons->quit_button,
                          EZ_LABEL_STRING, "stop",
                          EZ_FOREGROUND, "DarkRed",
                          EZ_CALLBACK, update->interrupt_callback, update,
                          0 );
   }
   else
   {
      EZ_EnableWidget( buttons->help_button );
      EZ_EnableWidget( buttons->setup_button );
      EZ_EnableWidget( buttons->update_button );
      EZ_EnableWidget( buttons->request_button );
      EZ_EnableWidget( buttons->compose_button );
      EZ_EnableWidget( buttons->edit_menu_button );
      EZ_EnableWidget( buttons->toggle_button );
      EZ_EnableWidget( buttons->mark_button );
      EZ_EnableWidget( buttons->pack_button );
      EZ_EnableWidget( buttons->expire_button );
      EZ_EnableWidget( buttons->decode_button );
      EZ_EnableWidget( buttons->summary_button );
      EZ_EnableWidget( buttons->search_button );
      EZ_EnableWidget( buttons->export_button );

      EZ_ConfigureWidget( buttons->quit_button,
                          EZ_LABEL_STRING, "quit",
                          EZ_FOREGROUND, "black",
                          EZ_CALLBACK, escape_hatch, newsreader,
                          0 );
   }

   return;
}

/*
 * Launches the appropriate function to perform an action (pack, expire,
 * update) on a group, depending upon its type or the user's response to a
 * prompt. If a server has been selected this function will iterate through
 * all of that server's groups.
 */

void update_iterate( void *this, void *summary_object, void *tree_object,
                     np_action action, int i, unsigned int j,
                     char *elapsed_time )
{
   np_update_object *update;
   np_summary_object *summary;
   np_tree_object *tree;
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_newsrc_object *newsrc;

   char buffer[ LN_BUFFER_SIZE ];


   update = ( np_update_object *)this;
   summary = ( np_summary_object *)summary_object;
   tree = ( np_tree_object *)tree_object;
   newsreader = ( np_newsreader_object *)tree->parent;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   if( i < 0 )
      if ( tree->server_state[ j ] == NP_NOT_SHOWN )
      {
         EZ_ListTreeWidgetSelectNode( tree->tree, tree->server_nodes[ j ], 
                                      NULL );
         tree->normal_callback( tree->tree, tree );
      }

   update->server = tree->server_list[ j ].server;
   update->server_idx = j;

   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));

   if ( action == NP_UPDATE )
   {
      if ( i >= 0 && !strncmp( tree->group_list[ i ].group, "Posted", 6 ))
      {
         EZ_NormalCursor( newsreader->app_frame );
         return;
      }

      if ( i >= 0 && !strncmp( tree->group_list[ i ].group, "Follow-ups", 10 ))
      {
         if ( !tree->server_list[ j ].follow_ups )
         {
            snprintf( buffer, LN_BUFFER_SIZE,
                      "There are no follow-ups on file for:\n%s\n"
                      "to be posted.", tree->server_list[ j ].server );
            newsrc->confirm( newsrc, buffer, NP_DONE );
            newsrc->answer = 0;
            while( !newsrc->answer )
               EZ_WaitAndServiceNextEvent();

            EZ_NormalCursor( newsreader->app_frame );
            return;
         }

         if ( update->open_server( update, tree->server_list[ j ].server,
                                   j ))
         {
            EZ_NormalCursor( newsreader->app_frame );
            return;
         }
      }
      else
         if ( strncmp( update->server, "Virtual", 7 ))
         {                                                           
            if ( strncmp( update->server, "Mailboxes", 9 ))
            {
               update->ask_what( update, update->server );

               if ( update->what == LN_CANCEL )                         
               {
                  EZ_NormalCursor( newsreader->app_frame );
                  return;                                               
               }
            }
         }
         else
            switch( update->do_virtual( update ))
            {
               case 0:
                  break;

               case 1:
                  buttons->folder_requests_callback( NULL, buttons );
                  return;
                  break;

               case 2:
                  EZ_NormalCursor( newsreader->app_frame );
                  return;
                  break;
            }
   }

   update->show_message( newsreader, action, update->server );
   update->interrupt = 0;

   if ( action == NP_PACK || action == NP_EXPIRE )
      update->connect = 2;

   if ( i < 0 )
   {
      for( i = 0; i < tree->groups; ++i )
      {
         if ( j == tree->group_list[ i ].server_idx )
            update->do_group( update, summary, tree, action, i, elapsed_time,
                              tree->group_list[ i ].server,
                              tree->group_list[ i ].group );

         if ( update->interrupt )
            break;
      }
   }
   else
      update->do_group( update, summary, tree, action, i, elapsed_time,
                        tree->group_list[ i ].server,
                        tree->group_list[ i ].group );


   if ( action == NP_UPDATE && 
        strncmp( tree->server_list[ j ].server, "Virtual", 7 ) &&
        strncmp( tree->server_list[ j ].server, "Mailboxes", 9 ))
   {
      fputs( "quit\r\n", update->stream );
      fclose( update->stream );
      update->stream = NULL;
   }

   newsreader->show_message( newsreader, NULL );
   EZ_NormalCursor( newsreader->app_frame );

   return;
}

/*
 * Callback of update_button on main frame. Determines level of selection in
 * group tree and launches update_iterate with appropriate arguments.
 */

void update_callback( EZ_Widget *widget, void *data )
{
   np_update_object *update;
   np_newsreader_object *newsreader;
   np_newsrc_object *newsrc;
   np_tree_object *tree;
   np_summary_object *summary;
   np_buttons_object *buttons;

   EZ_TreeNode *selected, *subject;
   EZ_Item *item;

   static char elapsed_time[ 25 ];
   char buffer[ LN_BUFFER_SIZE ];
   long int i;
   unsigned int j, idx;
   FILE *config;
   enum{ NO, YES }found = NO;
   enum{ root, server, group }what;
   np_action action;


   update = ( np_update_object *)data;
   buttons = ( np_buttons_object *)update->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      return;

   /*
    * Close the currently-selected group's spool file, if it's open.
    */

   ln_get_message_text( NULL, 0, 0, 0, NULL );

   item = EZ_TreeNodeGetItem( selected );
   i = EZ_GetItemIntData( item );

   if ( ( subject = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         != NULL )
      idx = ( unsigned int)EZ_GetItemIntData( EZ_TreeNodeGetItem( subject ));

   if ( summary->summary_onscreen )
      summary->done_callback( NULL, summary );

   if ( widget == buttons->expire_button )
      action = NP_EXPIRE;
   else
      if ( widget == buttons->pack_button )
         action = NP_PACK;
      else
         if ( widget == buttons->update_button )
            action = NP_UPDATE;

   if ( action == NP_EXPIRE )
   {
      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config", 
                getenv( "HOME" ));
      if (( config = fopen( buffer, "r" )) == NULL )
         if ( errno == ENOENT )
         {
            EZ_NormalCursor( newsreader->app_frame );
            return;
         }
         else
            fatal_error();

      fgets( buffer, LN_BUFFER_SIZE, config );
      fgets( buffer, LN_BUFFER_SIZE, config );
      fgets( buffer, LN_BUFFER_SIZE, config );

      snprintf( elapsed_time, sizeof elapsed_time,
            "000000%02d000000", atoi( buffer ));
   }
   else
      elapsed_time[ 0 ] = '\0';

   /* root */

   update->disable_interface( newsreader, 1 );
   
   if ( selected == tree->root_node )
   {
      found = YES;

      what = root;

      for( j = 0; j < tree->servers; ++j )
      {
         if ( !strncmp( tree->server_list[ j ].server, "Folders", 7 ))
            continue;

         i = -1;
         update->iterate( update, summary, tree, action, i, j, elapsed_time );

         if ( update->what == LN_CANCEL )
            continue;
      }
   }

   /* server */

   if ( !found )
      if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      {
         found = YES;
         what = server;

         if ( !strncmp( tree->server_list[ i ].server, "Folders", 7 ))
         {
            EZ_NormalCursor( newsreader->app_frame );
            return;
         }

         j = i;
         i = -1;
         update->iterate( update, summary, tree, 
                          action, i, j, elapsed_time );
      }

   /* group */

      else
      {
         what = group;

         if ( !strncmp( tree->group_list[ i ].server, "Folders", 7 ))
         {
            EZ_NormalCursor( newsreader->app_frame );
            return;
         }

         update->iterate( update, summary, tree, action, i, 
                          tree->group_list[ i ].server_idx, 
                          elapsed_time );
      }

   tree->update_lists( tree );
   tree->set_tree( tree );

   update->disable_interface( newsreader, 0 );
   
   switch( what )
   {
      case root:
         EZ_ListTreeWidgetSelectNode( tree->tree, tree->root_node, NULL );
         break;

      case server:
         EZ_ListTreeWidgetSelectNode( tree->tree, tree->server_nodes[ j ], 
                                      NULL );
         break;

      case group:
         EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ i ], 
                                      NULL );
         break;
   }

   if ( subject != NULL && summary->stats.total
        && idx <= summary->stats.total )
      EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                   summary->node_list[ idx ], NULL );

   return;
}

/*
 * Expires a particular newsgroup, by removing articles with a date header
 * specifying a date older that the number of days specified in
 * line 4 of ~/.peruser3-config.
 */

void update_expire_group( np_tree_object *tree, np_summary_object *summary,
                          unsigned int i, char folder, char *elapsed_time )
{
   np_newsreader_object *newsreader;

   unsigned int j;


   newsreader = ( np_newsreader_object *)summary->parent;

   if ( summary->local_times == NULL )
   {
      if (( summary->local_times = calloc( summary->stats.total,
                                           sizeof *summary->local_times ))
            == NULL )
         fatal_error();

      for( j = 0; j < summary->stats.total; ++j )
         if ( ln_convert_date( summary->contents[ j ].date, 
                               &summary->local_times[ j ] ) == -1 )
            lib_error();
   }

   if ( ln_expire_spool( tree->group_list[ i ].group, folder,
                         elapsed_time, summary->stats.total, 
                         summary->local_times, 
                         &tree->group_list[ i ].total ))
      lib_error();

   if ( ln_thread_spool( tree->group_list[ i ].group ) == - 1 )
      lib_error();

   for( j = 0; j < summary->stats.total; ++j )
      free( summary->local_times[ j ] );

   free( summary->local_times );
   summary->local_times = NULL;

   return;
}

/*
 * Displays a feedback message.
 */

void update_show_message( void *newsreader_object, 
                          np_action action, char *server )
{
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ];


   newsreader = ( np_newsreader_object *)newsreader_object;

   switch( action )
   {
      case NP_EXPIRE:
         snprintf( buffer, LN_BUFFER_SIZE, "Expiring: %s...", server );
         break;

      case NP_PACK:
         snprintf( buffer, LN_BUFFER_SIZE, "Packing: %s...", server );
         break;

      case NP_UPDATE:
         snprintf( buffer, LN_BUFFER_SIZE, "Updating: %s...", server );
         break;
   }

   newsreader->show_message( newsreader, buffer );
   EZ_DisplayWidget( newsreader->app_frame );

   return;
}

/*
 * Queries the user as to what he or she would like to download from a news
 * server: a specific quantity, or all, new headers or full articles; the
 * requests on file, or just to mark ~/.peruser3_newsrc as "caught up." 
 */

void update_ask_what( void *this, char *server )
{
   np_update_object *update;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;

   EZ_Widget *articles_button, *requests_button, *mid_frame, *radio_frame,
      *none_button, *button_frame;


   update = ( np_update_object *)this;
   buttons = ( np_buttons_object *)update->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;

   /* update->frame */

   update->frame = EZ_CreateFrame( NULL, "Transfer Articles" );

   EZ_ConfigureWidget( update->frame,
                       EZ_HEIGHT, 330,
                       EZ_WIDTH, 400,
                       EZ_IPADY, 5,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( update->frame, server ),
                       EZ_TEXT_LINE_LENGTH, 80,
                       EZ_HEIGHT, 30,
                       EZ_FONT_NAME, newsreader->header_font,
                       0 );

   /* mid frame */

   mid_frame = EZ_CreateFrame( update->frame, NULL );

   EZ_ConfigureWidget( mid_frame,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   /* radio frame */

   radio_frame = EZ_CreateFrame( mid_frame, "Retrieve:" );

   EZ_ConfigureWidget( radio_frame,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       0 );

   update->slider_frame = EZ_CreateFrame( mid_frame, "Specific Quantity:" );

   EZ_ConfigureWidget( update->slider_frame,
                       EZ_FILL_MODE, EZ_FILL_VERTICALLY,
                       0 );

   update->headers_button = EZ_CreateRadioButton( radio_frame, "headers",
                                                  0, 0, LN_HEADERS );

   EZ_ConfigureWidget( update->headers_button,
                       EZ_CALLBACK, update->ungrey_slider, update,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       0 );

   articles_button = EZ_CreateRadioButton( radio_frame, "articles", 0, 0, 
                                           LN_ARTICLES );

   EZ_ConfigureWidget( articles_button,
                       EZ_CALLBACK, update->ungrey_slider, update,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       0 );

   requests_button = EZ_CreateRadioButton( radio_frame, "requests", 0, 0, 
                                           LN_REQUESTS );

   EZ_ConfigureWidget( requests_button,
                       EZ_CALLBACK, update->grey_slider, update,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       0 );

   none_button = EZ_CreateRadioButton( radio_frame, "catch-up", 0, 0,
                                       LN_CATCHUP );

   EZ_ConfigureWidget( none_button,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       EZ_CALLBACK, update->grey_slider, update,
                       0 );

   /* midframe */

   update->quantity_slider = EZ_CreateSlider( update->slider_frame, NULL,
                                              0, 500, 1,
                                              EZ_WIDGET_VERTICAL_SLIDER );

   EZ_ConfigureWidget( update->quantity_slider,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_SLIDER_RESOLUTION, 1.0,
                       0 );

   EZ_SetSliderValue( update->quantity_slider, 0 );


   /* button frame */

   button_frame = EZ_CreateFrame( update->frame, NULL );

   EZ_ConfigureWidget( button_frame,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( button_frame, "yes", 0 ),
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_WIDTH, 75,
                       EZ_HEIGHT, 30,
                       EZ_CALLBACK, update->radio_callback, update,
                       0 );

   update->cancel_button = EZ_CreateButton( button_frame, "no", 0 );

   EZ_ConfigureWidget( update->cancel_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, update->radio_callback, update,
                       EZ_WIDTH, 75,
                       EZ_HEIGHT, 30,
                       0 );

   EZ_SetRadioButtonGroupVariableValue( update->headers_button, 
         LN_HEADERS );
   EZ_DisplayWidget( update->frame );
   EZ_SetGrab( update->frame );

   update->what = LN_NOTHING;
   while( update->what == LN_NOTHING )
      EZ_WaitAndServiceNextEvent();

   return;
}

/*
 * Pass outgoing mail to sendmail.
 */

void update_send_mail( void *this, unsigned int i )
{
   np_update_object *update;
   np_tree_object *tree;
   np_buttons_object *buttons;
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ], *home;
   FILE *pipe, *outbox, *sent;
   unsigned int j;
   

   update = ( np_update_object *)this;
   buttons = ( np_buttons_object *)update->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   if ( !tree->group_list[ i ].total )
      return;
  
   newsrc->answer = -1;
   newsrc->confirm( newsrc, "Send mail in Outbox?", NP_YESNO );
   while( newsrc->answer == -1 )
      EZ_WaitAndServiceNextEvent();
   
   if ( !newsrc->answer )
      return;
   
   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/::Outbox", 
             home = getenv( "HOME" ));
   
   if (( outbox = fopen( buffer, "r+" )) == NULL )
   {
      if ( errno == ENOENT )
      {
         newsrc->answer = -1;
         newsrc->confirm( newsrc, "Outbox is empty.", NP_DONE );
         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();

         tree->group_list[ i ].total = 0;
         return;
      }

      fatal_error();
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/::Sent-Mail",
             home );
   if (( sent = fopen( buffer, "a" )) == NULL )
      fatal_error();

   rewind( outbox );
   
   for( j = 0; j < tree->group_list[ i ].total; ++j )
   {
      if ( !( pipe = popen( "sendmail -t", "w" )))
      {
         fclose( outbox );
         fclose( sent );
         
         newsrc->answer = -1;
         newsrc->confirm( newsrc, strerror( errno ), NP_DONE );
         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();
         return;
      }

      while( fgets( buffer, LN_BUFFER_SIZE, outbox ) != NULL )
      {
         fputs( buffer, sent );
         
         if( strncmp( buffer, ".\r\n", 3 ))
            fputs( buffer, pipe );
         else
            break;
      }
      
      pclose( pipe );
   }

   ftruncate( fileno( outbox ), 0 );
   fclose( outbox );
   fclose( sent );

   return;
}

/*
 * Called by update_iterate.
 */

void update_do_group( void *this, void *summary_object, void *tree_object, 
                      np_action action, unsigned int i, char *elapsed_time,
                      char *server, char *group )
{
   np_update_object *update;
   np_tree_object *tree;
   np_summary_object *summary;
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;

   char folder;
   unsigned int count;


   update = ( np_update_object *)this;
   tree = ( np_tree_object *)tree_object;
   summary = ( np_summary_object *)summary_object;
   newsreader = ( np_newsreader_object *)summary->parent;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)newsreader->buttons_object )->newsrc_object;

   update->group = tree->group_list[ i ].group;

   EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ i ], NULL );

   if ( !strncmp( server, "Virtual", 7 ))
      folder = 1;
   else 
      folder = 0;

   if ( summary->local_times != NULL )
   {
      for( i = 0; i < summary->stats.total; ++i )
         if ( summary->local_times[ i ] != NULL )
            free( summary->local_times[ i ] );

      free( summary->local_times );
      summary->local_times = NULL;
   }

   switch( action )
   {
      case NP_EXPIRE:
      case NP_PACK:
         if ( tree->group_list[ i ].total && strncmp( group, "Posted", 6 ) &&
              strncmp( group, "::Sent-Mail", 11 ) &&
              strncmp( group, "::Outbox", 8 ) &&
              strncmp( group, "Follow-Ups", 10 ))
            if ( action == NP_EXPIRE )
               update->expire_group( tree, summary, i, folder, elapsed_time );
            else
            {
               if ( ln_pack_spool( group, folder ) == -1 )
                  lib_error();
               if ( ln_thread_spool( group ) == -1 )
                  lib_error();
            }
         break;

      case NP_UPDATE:

         if ( !strncmp( group, "Posted", 6 ) ||
              !strncmp( group, "::Sent-Mail", 11 ))
            break;

         if ( folder )
         {
            update->update_folder( update );
            if ( ln_sort_spool( group ) == -1 )
               lib_error();
            if ( ln_thread_spool( group ) == -1 )
               lib_error();

            break;
         }

         if ( !strncmp( group, "Follow-ups", 10 ))
         {
            char buffer[ LN_BUFFER_SIZE ];

            if ( !tree->group_list[ i ].total )
               return;

            snprintf( buffer, LN_BUFFER_SIZE, "Post follow-ups for\n%s?",
                      update->server );
            newsrc->answer = -1;
            newsrc->confirm( newsrc, buffer, NP_YESNO );
            while( newsrc->answer == -1 )
               EZ_WaitAndServiceNextEvent();

            if ( !newsrc->answer )
            {
               EZ_NormalCursor( newsreader->app_frame );
               return;
            }

            update->what = LN_NOTHING;

            if ( ln_post_messages( update->stream, server, &count ) == -1 )
               lib_error();
         }
         else
            if ( !strncmp( update->server, "Mailboxes", 9 ))
            {
               if ( !strncmp( group, "::Outbox", 8 ))
                  update->send_mail( update, i );
               else                  
                  update->update_inbox( group, newsrc );

               break;
            }

         update->requests = tree->group_list[ i ].requests;
         update->update_newsgroup( update );

         break;
   }

   return;
}

void update_interrupt_callback( EZ_Widget *widget, void *data )
{
   np_update_object *update;
   np_newsreader_object *newsreader;


   update = ( np_update_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)update->parent )->parent;

   update->interrupt = 1;

   switch( update->connect )
   {
      case 0:
         newsreader->show_message( newsreader, 
             "Aborting transfer after current article has been processed..." );
         break;

      case 1:
         newsreader->show_message( newsreader,
               "Aborting connection..." );
         break;

      case 2:
         newsreader->show_message( newsreader,
               "Aborting after current group..." );
         break;
   }

   return;
}

/*
 * Callback for update->frame. Determines whether user wants to download
 * headers, full articles, requests on file, and quantities if applicable,
 * then opens connection to server.
 */

void update_radio_callback( EZ_Widget *widget, void *data )
{
   np_update_object *update;
   np_newsreader_object *newsreader;


   update = ( np_update_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)update->parent )->parent;

   if ( widget == update->cancel_button )
   {
      update->what = LN_CANCEL;
      EZ_DestroyWidget( update->frame );

      return;
   }

   update->what
      = EZ_GetRadioButtonGroupVariableValue( update->headers_button );

   if ( !( update->quantity = EZ_GetSliderValue( update->quantity_slider )) )
      update->quantity = -1;

   EZ_DestroyWidget( update->frame );
   EZ_DisplayWidget( newsreader->app_frame );

   if ( update->open_server( update, update->server, update->server_idx ))
   {
      newsreader->show_message( newsreader, NULL );
      return;
   }

   if ( update->what == LN_HEADERS )
      update->xover = ln_has_xover( update->stream );

   return;
}

/*
 * Called by update_do_group to update an group that represents an actual
 * Usenet newsgroup.
 */

void update_update_newsgroup( void *this )
{
   np_update_object *update;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_newsrc_object *newsrc;


   update = ( np_update_object *)this;
   buttons = ( np_buttons_object *)update->parent;
   newsreader= ( np_newsreader_object *)buttons->parent;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   update->connect = 0;
   switch( ln_update_group( update->group, update->stream, update->what, 
                            update->xover, update->requests, 
                            update->quantity, update->progress_callback,
                            update ))
   {
      case -5:
         newsrc->answer = -1;
         newsrc->confirm( newsrc, "Timed-out while waiting\n"
                          "for data from server", NP_DONE );
         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();
         return;

         break;

      case -3:
         newsrc->answer = -1;
         newsrc->confirm( newsrc, "This news server requires authentication", 
                          NP_DONE );
         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();

         return;

         break;

      case -2:
         return;
         break;

      case -1:
         lib_error();
         break;

      case 0:
         break;
   }

   if ( update->what != LN_CATCHUP )
   {
      if ( ln_sort_spool( update->group ) == -1 )
         lib_error();
      if ( ln_thread_spool( update->group ) == -1 )
         lib_error();
   }

   return;
}

/*
 * Called by ln_update_folder to display progress of filter to user.
 */

int update_filter_progress_callback( void *this, unsigned int i, char *filter,
                                     char *group )
{
   np_update_object *update;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ];


   update = ( np_update_object *)this;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)update->parent )->parent;

   if ( i && i % 200 )
      return 0;

   snprintf( buffer, LN_BUFFER_SIZE, "%s: processing %s...", 
             ++filter, group );
   newsreader->show_message( newsreader, buffer );
   
   if ( update->interrupt )
      return 1;

   return 0;
}

/*
 * Called by update_do_group to update virtual newsgroups. All header lines
 * in actual newsgroups are compared against the regular expression associated 
 * with the virtual newsgroup. Articles with matches are copied into the
 * virtual group's spoolfile.
 */

void update_update_folder( void *this )
{
   np_update_object *update;
   np_newsreader_object *newsreader;
   np_tree_object *tree;

   unsigned int i, j;


   update = ( np_update_object *)this;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)update->parent )->parent;
   tree = ( np_tree_object *)newsreader->tree_object;

   for( i = 0; i < tree->groups; ++i )
   {
      if ( !strncmp( tree->group_list[ i ].group, "Follow-ups", 10 ) ||
           !strncmp( tree->group_list[ i ].group, "Posted", 6 ))
         continue;

      j = tree->group_list[ i ].server_idx;

      if ( !strncmp( tree->server_list[ j ].server, "Virtual", 7 ) ||
           !strncmp( tree->server_list[ j ].server, "Folders", 7 ) ||
           !strncmp( tree->server_list[ j ].server, "Mailboxes", 9 ))
         break;

      update->connect = 2;
      if ( ln_update_folder( update->group, tree->group_list[ i ].group,
                             update->filter_progress_callback, update ) 
            == -1 )
         lib_error();
   }

   return;
}

/*
 * Disables quantity slider on update->frame when the user chooses the
 * requests or catchup buttons.
 */

void update_grey_slider( EZ_Widget *widget, void *data )
{
   np_update_object *update;


   update = ( np_update_object *)data;

   EZ_ConfigureWidget( update->slider_frame,
                       EZ_LABEL_STRING, "disabled",
                       EZ_FOREGROUND, "DarkGrey",
                       0 );
   EZ_DisableWidget( update->quantity_slider );

   return;
}

/*
 *  Enables quantity slider on update->frame, when the user chooses the
 *  headers or the articles button.
 */

void update_ungrey_slider( EZ_Widget *widget, void *data )
{
   np_update_object *update;


   update = ( np_update_object *)data;

   EZ_ConfigureWidget( update->slider_frame,
                       EZ_LABEL_STRING, "Specific Quantity:",
                       EZ_FOREGROUND, "Black",
                       0 );
   EZ_EnableWidget( update->quantity_slider );

   return;
}

void update_update_inbox( char *inbox, void *newsrc_object )
{
   np_newsrc_object *newsrc;

   int result;


   newsrc = ( np_newsrc_object *)newsrc_object;

   if (( result = ln_update_inbox( inbox )))
   {
      if ( result == -3 )
      {
         newsrc->answer = -1;
         newsrc->confirm( newsrc, "Cannot get lock on maildrop.\n"
                          "Try again later.", NP_DONE );
         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();

         return;
      }

      if ( result == -1 )
         lib_error();
   }

   if ( ln_sort_spool( inbox ) == -1 )
      lib_error();

   if ( ln_thread_spool( inbox ) == -1 )
      lib_error();

   return;
}
