/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "libnews.h"

/*
 * retrieves the text of article at specified offset in spoolfile of specified
 * group. The ln_message struct is defined in libnews.h.
 */

int ln_get_message_text( char *group_name, ln_type type, long int offset,
                         long int size, ln_message *message )
{
   char buffer[ LN_BUFFER_SIZE ], *home, *big_buffer;
   
   static char old_name[ LN_BUFFER_SIZE ] = { '\0' };

   unsigned int header_count, body_count;

   static FILE *spool_stream = NULL;


   if ( group_name == NULL )
   {
      if ( spool_stream != NULL )
      {
         fclose( spool_stream );
         spool_stream = NULL;
      }
      return 0;
   }

   message->header = message->body = NULL;

   if ( spool_stream == NULL || strcmp( group_name, old_name ))
   {
      if ( spool_stream != NULL )
      {
         fclose( spool_stream );
         spool_stream = NULL;
      }

      home = getenv( "HOME" );
      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", 
                home, group_name );
      if (( spool_stream = fopen( buffer, "r" )) == NULL )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE, 
                   "libnews: ln_get_message_text: could not open file: %s.", 
                   buffer );
         return -1;
      }

      strcpy( old_name, group_name );
   }

   if ( fseek( spool_stream, offset, SEEK_SET ))
   {
      fclose( spool_stream );
      spool_stream = NULL;
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_get_message_text: %s: premature end of spool.",
                group_name );
      return -1;
   }

   if (( big_buffer = malloc( size + 1 )) == NULL )
      ln_allocation_error();

   if ( fread( big_buffer, 1, size, spool_stream ) != size )
   {
      if ( ferror( spool_stream ))
      {
         fclose( spool_stream );
         spool_stream = NULL;
         snprintf( ln_error_message, LN_BUFFER_SIZE, 
                   "libnews: ln_get_message_text: %s: error reading from"
                   " spool.", group_name );
      }

      if ( feof( spool_stream ))
      {
         fclose( spool_stream );
         spool_stream = NULL;
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_get_message_text: %s: "
                   "premature end of spool.", group_name );
      }

      return -1;
   }

   big_buffer[ size ] = '\0';

   if ( type == LN_HEADER )
   {
      if (( message->header = malloc( size - 2 )) == NULL )
         ln_allocation_error();

      strncpy( message->header, big_buffer, size - 3 );
      message->header[ size - 3 ] = '\0';
      message->body = NULL;
   }
   else
   {
      header_count = strstr( big_buffer, "\r\n\r\n" ) - big_buffer + 2;
      if (( message->header = malloc( header_count + 1 )) == NULL )
         ln_allocation_error();

      strncpy( message->header, big_buffer, header_count );
      message->header[ header_count ] = '\0';

      body_count = size - header_count - 2;
      if (( message->body = malloc( body_count - 2 )) == NULL )
         ln_allocation_error();

      strncpy( message->body, big_buffer + header_count + 2, body_count - 3 );
      message->body[ body_count - 3 ] = '\0';
   }
   
   free( big_buffer );

   return 0;
}
