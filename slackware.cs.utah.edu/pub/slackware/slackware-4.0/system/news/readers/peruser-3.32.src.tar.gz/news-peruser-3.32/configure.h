/*
 * Prototypes.
 */

void configure_init( void *parent );
void configure_callback( EZ_Widget *widget, void *data );
void configure_done_callback( EZ_Widget *widget, void *data );
void configure_check_buttons_callback( EZ_Widget *widget, void *data );
