/*
   News Peruser Copyright (c) 1996-1998 James Bailie
   ==================================================================

   News Peruser is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2, or (at
   your option) any later version.

   News Peruser is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   Although News Peruser is licensed under the Free Software
   Foundation's GNU General Public License, Peruser is not produced
   by, nor is it endorsed by the Free Software Foundation. The Free
   Software Foundation is not responsible for developing,
   distributing, or supporting Peruser in any way. Anyone may place
   software they own the copyright to, under the GNU General Public
   License.

   The GNU General Public License is included in the News Peruser 
   distribution archive in a file called COPYING. If you do
   not have a copy of the license, you can download one from
   ftp://prep.ai.mit.edu, or you can write to the Free Software
   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.

   =====================================================================
*/

#include "libnews.h"
#include<time.h>

/*
 * External function in ln_convert_date.c. Adjusts discrete time values out of
 * range.
 */

void ln_adjust_time( int *hours, int *minutes, int *seconds,
                     int *day, int *month, int *year );

/*
 * Removes articles from spoolfile which have a Date header specifying a time
 * older that the number of days specified in line 3 of ~/.peruser3-config.
 */

int ln_expire_spool( char *group_name, char folder,
                     char *elapsed, unsigned int total, char **local_times,
                     unsigned int *expired )
{
   char buffer[ LN_BUFFER_SIZE ], test[ 25 ], *home;
   char spool_path[ LN_BUFFER_SIZE ], read_path[ LN_BUFFER_SIZE ],
   temp_path[ LN_BUFFER_SIZE ], temp_read_path[ LN_BUFFER_SIZE ],
   ids_path[ LN_BUFFER_SIZE ], temp_ids_path[ LN_BUFFER_SIZE ];

   FILE *spool, *read, *temp, *temp_read, *ids, *temp_ids;

   time_t t;
   struct tm *bt;

   int year, month, day, hours, minutes, seconds;
   unsigned int i;


   if ( strlen( elapsed ) < 14 )
   {
      strcpy( ln_error_message,
              "libnews: ln_expire_spool: "
              "malformed time string passed as first argument." );
      return -1;
   }

   time( &t );
   bt = localtime( &t );

   buffer[ 0 ] = elapsed[ 0 ];
   buffer[ 1 ] = elapsed[ 1 ];
   buffer[ 2 ] = elapsed[ 2 ];
   buffer[ 3 ] = elapsed[ 3 ];
   buffer[ 4 ] = '\0';

   year = atoi( buffer );

   buffer[ 0 ] = elapsed[ 4 ];
   buffer[ 1 ] = elapsed[ 5 ];
   buffer[ 2 ] = '\0';

   month = atoi( buffer );

   buffer[ 0 ] = elapsed[ 6 ];
   buffer[ 1 ] = elapsed[ 7 ];

   day = atoi( buffer );

   buffer[ 0 ] = elapsed[ 8 ];
   buffer[ 1 ] = elapsed[ 9 ];

   hours = atoi( buffer );

   buffer[ 0 ] = elapsed[ 10 ];
   buffer[ 1 ] = elapsed[ 11 ];

   minutes = atoi( buffer );

   buffer[ 0 ] = elapsed[ 12 ];
   buffer[ 1 ] = elapsed[ 13 ];

   seconds = atoi( buffer );

   bt->tm_year += 1900;
   bt->tm_year -= year;
   bt->tm_mon -= month;
   bt->tm_mon++;  
   bt->tm_mday -= day;
   bt->tm_hour -= hours;
   bt->tm_min -= minutes;
   bt->tm_sec -= seconds;

   ln_adjust_time( &bt->tm_hour, &bt->tm_min, &bt->tm_sec, 
                   &bt->tm_mday, &bt->tm_mon, &bt->tm_year );

   snprintf( test, LN_BUFFER_SIZE, "%4d%02d%02d%02d%02d%02d", bt->tm_year,
             bt->tm_mon, bt->tm_mday, bt->tm_hour, bt->tm_min, bt->tm_sec );

   home = getenv( "HOME" );
   snprintf( spool_path, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", 
             home, group_name );
   if (( spool = fopen( spool_path, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_expire_spool: could not open file %s.",
                spool_path );
      return -1;
   }

   snprintf( read_path, LN_BUFFER_SIZE, "%s:read", spool_path );
   if (( read = fopen( read_path, "r" )) == NULL )
   {
      fclose( spool );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_expire_spool: could not open file %s.",
                read_path );
      return -1;
   }

   snprintf( temp_path, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:temp", 
             home, group_name );
   if (( temp = fopen( temp_path, "w" )) == NULL )
   {
      fclose( spool );
      fclose( read );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_expire_spool: could not open file %s.",
                temp_path );
      return -1;
   }

   snprintf( temp_read_path, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:read:temp", 
             home, group_name );
   if (( temp_read = fopen( temp_read_path, "w" )) == NULL )
   {
      fclose( spool );
      fclose( read );
      fclose( temp );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_expire_spool: could not open file %s.",
                temp_read_path );
      return -1;
   }

   if ( folder )
   {
      snprintf( ids_path, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:ids",
                home, group_name );
      if ( ( ids = fopen( ids_path, "r" )) == NULL )
      {
         fclose( spool );
         fclose( temp );
         fclose( read );
         fclose( temp_read );
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_expire_spool: could not open file %s.", 
                   ids_path );
         return -1;
      }

      strcpy( temp_ids_path, ids_path );
      strcat( temp_ids_path, ".temp" );

      if ( ( temp_ids = fopen( temp_ids_path, "w" )) == NULL )
      {
         fclose( spool );
         fclose( temp );
         fclose( read );
         fclose( temp_read );
         fclose( ids );
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_expire_spool: could not open file %s.",
                   temp_ids_path );
         return -1;
      }
   }

   for( i = 0; i < total; ++i )
      if ( strcmp( local_times[ i ], test ) > 0 )
      {
         do
         {
            if ( fgets( buffer, LN_BUFFER_SIZE, spool ) == NULL )
            {
               snprintf( ln_error_message, LN_BUFFER_SIZE,
                         "libnews: ln_expire_spool: premature end of spool %s",
                         group_name );
               return -1;
            }
            fputs( buffer, temp );
         }
         while( strncmp( buffer, ".\r\n", 3 ));

         if ( fgets( buffer, LN_BUFFER_SIZE, read ) != NULL )
            fputs( buffer, temp_read );

         if ( folder )
         {
            fgets( buffer, LN_BUFFER_SIZE, ids );
            fputs( buffer, temp_ids );
         }
      }
      else
      {
         ( *expired )--;

         do
            if ( fgets( buffer, LN_BUFFER_SIZE, spool ) == NULL )
            {
               snprintf( ln_error_message, LN_BUFFER_SIZE,
                         "libnews: ln_expire_spool: premature end of spool %s",
                         group_name );
               return -1;
            }
         while( strncmp( buffer, ".\r\n", 3 ));

         fgets( buffer, LN_BUFFER_SIZE, read );

         if ( folder )
            fgets( buffer, LN_BUFFER_SIZE, ids );
      }

   fclose( spool );
   fclose( read );
   fclose( temp );
   fclose( temp_read );

   rename( temp_path, spool_path );
   rename( temp_read_path, read_path );

   if ( folder )
   {
      fclose( ids );
      fclose( temp_ids );
      rename( temp_ids_path, ids_path );
   }

   return 0;
}
