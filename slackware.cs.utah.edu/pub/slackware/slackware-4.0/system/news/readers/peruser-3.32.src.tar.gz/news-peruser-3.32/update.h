/*
 * Prototypes.
 */

void update_init( void *parent );
void update_callback( EZ_Widget *widget, void *data );
void update_show_message( void *newsreader_object, np_action action,
                          char *server );
void update_do_group( void *this, void *summary_object, void *tree_object,
                      np_action action,
                      unsigned int i, char *elapsed_time,
                      char *server, char *group );
void update_expire_group( np_tree_object *tree,  
                          np_summary_object *summary,
                          unsigned int i,
                          char folder,
                          char *elapsed_time );
void update_update_group( void *this, void *tree_object, unsigned int group,
                          char *server );
void update_update_folder( void *this );
void update_update_newsgroup( void *this );
void update_ask_what ( void *this, char *server );
int update_open_server( void *this, char *server, unsigned int j );
int update_authenticating( void *this, unsigned int j, char *user, char *pass );
void update_iterate( void *this, void *summary_object, void *tree_object,
                     np_action action, int i, unsigned int j,
                     char *elapsed_time );
void update_radio_callback( EZ_Widget *widget, void *data );
void update_grey_slider( EZ_Widget *widget, void *data );
void update_ungrey_slider( EZ_Widget *widget, void *data );
int update_progress_callback( void *data, char *group, unsigned int lines,
                              unsigned int begin,
                              unsigned int current, unsigned int end );
int update_filter_progress_callback( void *data, unsigned int i, char *filter,
                                     char *group );
void update_interrupt_callback( EZ_Widget *widget, void *data );
void update_disable_interface( void *newsreader_object, char i );
int update_do_virtual( void *this );
void update_virtual_frame_callback( EZ_Widget *widget, void *data );
int update_connect_callback( void *data, int expired );
void update_update_inbox( char *inbox, void *newsrc_object );
void update_send_mail( void *this, unsigned int i );
