/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "libnews.h"

#include<signal.h>
#include<sys/wait.h>
#include<unistd.h>

/*
 * Wrapper function. Does a case-insensitive comparison between two strings,
 * ignoring the initial character of a string if it is: '"', or '('.
 */

int ln_compare( const void *a, const void *b )
{
   int result;
   unsigned int i, l;
   char *c, *d;


   if (( c = malloc( ( l = strlen( *( char **)a )) + 1 )) == NULL )
      ln_allocation_error();

   if ( **( char **)a == '"' || **( char **)a == '(' )
      strcpy( c, *( char **)a + 1 );
   else
      strcpy( c, *( char **)a );

   for( i = 0; i < l; ++i )
      c[ i ] = tolower( c[ i ] );

   if (( d = malloc( ( l = strlen( *( char **)b )) + 1 )) == NULL )
      ln_allocation_error();

   if ( **( char **)b == '"' || **( char **)b == '(' )
      strcpy( d, *( char **)b + 1 );
   else
      strcpy( d, *( char **)b );

   for( i = 0; i < l; ++i )
      d[ i ] = tolower( d[ i ] );

   result = strcmp( c, d );

   free( c );
   free( d );

   return result;

}

typedef struct
{
   char *subject;
   char *date;
   unsigned int position;
}
ln_subject;

void ln_destroy_subject_array( ln_subject *subject, 
                               unsigned int article_count )
{
   unsigned int i;

   for( i = 0; i < article_count; ++i )
   {
      if ( subject->subject != NULL )
         free( subject->subject );

      if ( subject->date != NULL )
         free( subject->date );
   }

   free( subject );

   return;
}

/* 
 * Sorts the articles in a spool file, using the Subject header as the sort
 * key.
 */

int ln_sort_spool( char *group_name )
{
   char spool_path[ LN_BUFFER_SIZE ], temp_spool_path[ LN_BUFFER_SIZE ],
      read_path[ LN_BUFFER_SIZE ], temp_read_path[ LN_BUFFER_SIZE ];

   FILE *spool_file, *read_file, *temp_read_file, *temp_spool_file;

   char buffer[ LN_BUFFER_SIZE ], *home, *line_pointer, found, *temp;

   ln_subject *subject, *start;

   unsigned int article_count, i, j, count, second_i, length;


   home = getenv( "HOME" );

   snprintf( spool_path, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", 
             home, group_name );

   if (( spool_file = fopen( spool_path, "r" )) == NULL )
   {
      if ( errno == ENOENT )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_sort_spool: could not open file %s.",
                   read_path );
         return -2;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE,
               "libnews: ln_sort_spool: fopen() returned error: %s",
               strerror( errno ));
      return -1;
   }

   article_count = 0;

   while( fgets( buffer, LN_BUFFER_SIZE, spool_file ) != NULL )
      if ( !strncmp( buffer, ".\r\n", 3 ))
         ++article_count;

   if ( !article_count )
   {
      fclose( spool_file );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_sort_spool: %s: empty spool.",
                group_name );
      return -2;
   }

   if ( article_count < 2 )
   {
      fclose( spool_file );
      return 0;
   }

   rewind( spool_file );

   if (( subject = calloc( article_count, sizeof *subject )) == NULL )
      ln_allocation_error();

   for( i = 0; i < article_count; ++i )
      subject[ i ].subject = NULL;

   found = 0;
   for( i = 0; i < article_count; ++i)
   {
      do
      {
         if ( fgets( buffer, LN_BUFFER_SIZE, spool_file ) == NULL )
         {
            fclose( spool_file );
            ln_destroy_subject_array( subject, article_count );

            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_sort_spool: premature end of spool: %s.",
                      group_name );
            return -1;
         }

         if ( !strncasecmp( buffer, "Subject: ", 9 ))
         {
            ++found;

            subject[ i ].position = i;

            if (( subject[ i ].subject = malloc( strlen( buffer + 9 ) + 3 )) 
                  == NULL )
               ln_allocation_error();

            strcpy( subject[ i ].subject, buffer + 9 );
            continue;
         }

         if ( !strncasecmp( buffer, "Date: ", 6 ))
         {
            ++found;

            if ( ln_convert_date( buffer + 6, &subject[ i ].date ))
               subject[ i ].date = "";
         }
      }
      while( found < 2 );

      found = 0;

      do
         if ( fgets( buffer, LN_BUFFER_SIZE, spool_file ) == NULL )
         {
            fclose( spool_file );

            ln_destroy_subject_array( subject, article_count );

            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_sort_subject: premature end of spool: %s.",
                      group_name );
            return -1;
         }
      while( strncmp( buffer, ".\r\n", 3 ));
   }

   for( i = 0; i < article_count; i++ )
   {
      if ( !strncmp( subject[ i ].subject, "Re: ", 4 ))
      {
         strcpy( buffer, subject[ i ].subject + 4 );
         line_pointer = strrchr( buffer, '\r' );
         strcpy( line_pointer, " a\r\n" );
         strcpy( subject[ i ].subject, buffer );
      }

      length = strlen( subject[ i ].subject );
      for( second_i = 0; second_i < length; second_i++ ) 
      {
         subject[ i ].subject[ second_i ] =
            tolower( subject[ i ].subject[ second_i ] );
      }
   }

   qsort( subject, article_count, sizeof *subject, ln_compare );

   if ( article_count > 1 )
   {
      start = NULL;
      count = 0;

      for( i = 1; i < article_count; ++i )
      {
         if ( !strcmp( subject[ i ].date, subject[ i - 1 ].date ))
            if ( start == NULL )
            {
               if ( !count )
                  count = 2;
               else
                  ++count;

               start = &subject[ i - 1 ];
            }
            else
               if ( count )
               {
                  for( j = 0; j < count; ++j )
                  {
                     temp = subject[ j ].subject;
                     subject[ j ].subject = subject[ j ].date;
                     subject[ j ].date = temp;
                  }

                  qsort( start, count, sizeof *subject, ln_compare );

                  count = 0;
                  start = NULL;
               }
      }

      if ( count )
      {
         for( j = 0; j < count; ++j )
         {
            temp = subject[ j ].subject;
            subject[ j ].subject = subject[ j ].date;
            subject[ j ].date = temp;
         }

         qsort( start, count, sizeof *subject, ln_compare );

         count = 0;
         start = NULL;
      }

   }

   snprintf( temp_spool_path, LN_BUFFER_SIZE, "%s/.peruser_spool/spool.temp", 
             home );
   if (( temp_spool_file = fopen( temp_spool_path, "w" )) == NULL )
   {
      fclose( spool_file );

      ln_destroy_subject_array( subject, article_count );

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_sort_spool: could not open file %s.",
                temp_spool_path );
      return -1;
   }

   snprintf( read_path, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:read", 
             home, group_name );
   if (( read_file = fopen( read_path, "r" )) == NULL )
   {
      if ( errno != ENOENT )
      {
         fclose( spool_file );
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_sort_spool: could not open file %s.",
                   read_path );
         return -1;
      }
   }

   snprintf( temp_read_path, LN_BUFFER_SIZE, "%s:temp", read_path );
   if (( temp_read_file = fopen( temp_read_path, "w" )) == NULL )
   {
      fclose( spool_file );
      if ( read_file != NULL )
         fclose( read_file );

      ln_destroy_subject_array( subject, article_count );

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_sort_spool: could not open file %s.",
                temp_read_path );
      return -1;
   }

   for( i = 0; i < article_count; i++ )
   {
      rewind( spool_file );
      if ( read_file != NULL )
         rewind( read_file );

      if ( subject[ i ].subject != NULL )
         free( subject[ i ].subject );
      subject[ i ].subject = NULL;

      if ( subject[ i ].date != NULL )
         if ( *( subject[ i ].date ) != '\0' )
            free( subject[ i ].date );
      subject[ i ].date = NULL;

      while( subject[ i ].position )
      {
         do
            if ( fgets( buffer, LN_BUFFER_SIZE, spool_file ) == NULL )
            {
               fclose( spool_file );
               if ( read_file != NULL )
                  fclose( read_file );
               ln_destroy_subject_array( subject, article_count );

               snprintf( ln_error_message, LN_BUFFER_SIZE,
                     "libnews: ln_sort_spool: premature end of spool: %s.",
                     group_name );
               return -1;
            }
         while( strncmp( buffer, ".\r\n", 3 ));

         if ( read_file != NULL )
            fgets( buffer, LN_BUFFER_SIZE, read_file );

         subject[ i ].position--;
      }

      do
      {
         if ( fgets( buffer, LN_BUFFER_SIZE, spool_file ) == NULL )
         {
            fclose( spool_file );
            if ( read_file != NULL )
               fclose( read_file );
            ln_destroy_subject_array( subject, article_count );

            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_sort_spool: premature end of spool: %s.",
                      group_name );
            return -1;
         }

         fputs( buffer, temp_spool_file );
      }
      while( strncmp( buffer, ".\r\n", 3 ));

      if ( read_file != NULL )
         fgets( buffer, LN_BUFFER_SIZE, read_file );
      else
      {
         buffer[ 0 ] = 'r';
         buffer[ 1 ] = '\0';
      }

      fputs( buffer, temp_read_file );
   }

   free( subject );

   fclose( temp_spool_file );
   fclose( temp_read_file );

   if ( read_file != NULL )
      fclose( read_file );
   fclose( spool_file );

   remove( spool_path );
   rename( temp_spool_path, spool_path );

   if ( read_file != NULL )
      remove( read_path );
   rename( temp_read_path, read_path );

   return 0;
}
