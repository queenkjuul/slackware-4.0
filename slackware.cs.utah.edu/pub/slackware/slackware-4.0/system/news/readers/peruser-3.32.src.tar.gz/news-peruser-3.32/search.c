/*
 *  News Peruser Copyright (c) 1996-1998 James Bailie
 *  ==================================================================
 *
 *  News Peruser is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2, or (at
 *  your option) any later version.
 *
 *  News Peruser is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  Although News Peruser is licensed under the Free Software
 *  Foundation's GNU General Public License, Peruser is not produced
 *  by, nor is it endorsed by the Free Software Foundation. The Free
 *  Software Foundation is not responsible for developing,
 *  distributing, or supporting Peruser in any way. Anyone may place
 *  software they own the copyright to, under the GNU General Public
 *  License.
 *
 *  The GNU General Public License is included in the News Peruser 
 *  distribution archive in a file called COPYING. If you do
 *  not have a copy of the license, you can download one from
 *  ftp://prep.ai.mit.edu, or you can write to the Free Software
 *  Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *  =====================================================================
 */

#include "peruser.h"
#include<sys/types.h>
#include<regex.h>
#include "search.h"

/*
 * Constructor.
 */

void search_init( void *this )
{
   np_buttons_object *buttons;
   np_search_object *search;
   np_tree_object *tree;


   buttons = ( np_buttons_object *)this;
   search = ( np_search_object *)buttons->search_object;
   tree = ( np_tree_object *)
      (( np_newsreader_object *)buttons->parent )->tree_object;

   search->changed_headers = 0;
   search->parent = buttons;

   search->indices = NULL;
   search->search_onscreen = 0;

   search->callback = search_callback;
   search->done_callback = search_done_callback;
   search->entry_callback = search_entry_callback;
   search->list_motion_callback = search_list_motion_callback;

   return;
}

/*
 * Callback of newsreader->search_button. Displays search frame.
 */

void search_callback( EZ_Widget *widget, void *data )
{
   np_search_object *search;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;

   EZ_Widget *done, *entry_frame, *search_button;
   EZ_TextProperty *property;
   EZ_Item *item;


   search = ( np_search_object *)data;
   buttons = ( np_buttons_object *)search->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;

   if ( search->search_onscreen )
      return;

   search->search_onscreen = 1;

   if ( !newsreader->long_headers )
   {
      search->changed_headers = 1;
      newsreader->long_headers_callback( buttons->long_headers_button,
                                         newsreader );
   }
   
   /* search frame */

   search->search_frame = EZ_CreateFrame( NULL, "Search" );

   EZ_ConfigureWidget( search->search_frame,
                       EZ_HEIGHT, 400,
                       EZ_WIDTH, 600,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_IPADY, 10,
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( search->search_frame,
                                       "regular expression:" ),
                       EZ_HEIGHT, 20,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       0 );

   /* search entry */

   entry_frame = EZ_CreateFrame( search->search_frame, NULL );

   EZ_ConfigureWidget( entry_frame,
                       EZ_HEIGHT, 30,
                       EZ_PADX, 10,
                       0 );

   search->search_entry = EZ_CreateEntry( entry_frame, NULL );

   EZ_ConfigureWidget( search->search_entry,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_CALLBACK, search->entry_callback, search,
                       0 );

   search_button = EZ_CreateButton( entry_frame, "search", 0 );

   EZ_ConfigureWidget( search_button,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_CALLBACK, search->entry_callback, search,
                       0 );

   /* search label */

   search->search_label = EZ_CreateLabel( search->search_frame,
                                          "result:" ),

   EZ_ConfigureWidget( search->search_label,
                       EZ_HEIGHT, 20,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       0 );

   /* search list */

   search->search_list = EZ_CreateFancyListBox( search->search_frame, 
         1, 1, 2, 1 );

   EZ_ConfigureWidget( search->search_list,
                       EZ_FONT_NAME, newsreader->bold_font,
                       EZ_IPADY, 10,
                       EZ_IPADX, 5,
                       EZ_MOTION_CALLBACK, 
                       search->list_motion_callback, search,
                       0 );

   EZ_SetHScrollbarDiscreteSpeed( search->search_list, 10 );
   EZ_SetVScrollbarDiscreteSpeed( search->search_list, 10 );

   property = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font,
                                  0 );

   item = EZ_CreateLabelItem( "matching line", property );

   EZ_SetFancyListBoxHeader( search->search_list, &item, 1 );

   /* done */

   done = EZ_CreateButton( search->search_frame, "done", 0 );

   EZ_ConfigureWidget( done,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, search->done_callback, search,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       0 );

   EZ_DisplayWidget( search->search_frame );

   return;
}

/*
 * Callback of search->done_button. Destroys search frame.
 */

void search_done_callback( EZ_Widget *widget, void *data )
{
   np_search_object *search;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   

   search = ( np_search_object *)data;
   buttons = ( np_buttons_object *)search->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;

   if ( search->changed_headers )
   {
      search->changed_headers = 0;
      newsreader->long_headers_callback( buttons->long_headers_button,
                                         newsreader );
   }
   
   EZ_DestroyWidget( search->search_frame );

   search->search_onscreen = 0;

   if ( search->indices != NULL )
   {
      free( search->indices );
      search->indices = NULL;
   }

   return;
}

/*
 * Callback of search->search_entry. Does a line-by-line regular expression
 * search of spool contents against the contents of the regular expression
 * input widget.
 */

void search_entry_callback( EZ_Widget *widget, void *data )
{
   np_search_object *search;
   np_buttons_object *buttons;
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_summary_object *summary;

   EZ_Item *item;

   regex_t regex;

   char string[ LN_BUFFER_SIZE ], buffer[ LN_BUFFER_SIZE ];
   const char *home;
   int result;
   unsigned int i, article, line, total;
   FILE *spool;


   search = ( np_search_object *)data;
   buttons = ( np_buttons_object *)search->parent;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   tree = ( np_tree_object *)newsreader->tree_object;

   strcpy( string, EZ_GetEntryString( search->search_entry ));
   if ( !strlen( string ))
      return;

   if ( search->indices != NULL )
   {
      free( search->indices );
      search->indices = NULL;
   }

   if ( ( result = regcomp( &regex, string, REG_EXTENDED | REG_NOSUB )))
   {
      regerror( result, &regex, string, LN_BUFFER_SIZE );
      newsrc->answer = -1;
      newsrc->confirm( newsrc, string, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
      return;
   }

   EZ_FancyListBoxClear( search->search_list );
   EZ_FreezeWidget( search->search_list );

   EZ_ConfigureWidget( search->search_label,
                       EZ_FONT_NAME, 
                       "-*-helvetica-bold-o-*-*-14-*-*-*-*-*-*-*",
                       EZ_FOREGROUND, "DarkRed",
                       EZ_LABEL_STRING, "searching...",
                       0 );

   XFlush( EZ_GetDisplay() );

   home = getenv( "HOME" );
   total = 0;

   EZ_WaitCursor( search->search_frame, EZ_GetCursor( XC_watch ));
   if ( summary->summary_onscreen )
      EZ_WaitCursor( summary->summary_frame, EZ_GetCursor( XC_watch ));
   XFlush( EZ_GetDisplay() );

   for( i = 0; i < tree->groups; ++i )
   {
      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home, 
                tree->group_list[ i ].group );
      if (( spool = fopen( buffer, "r" )) == NULL )
         if ( errno == ENOENT )
            continue;
         else
            fatal_error();

      article = 0;
      line = -1;
      while( fgets( buffer, LN_BUFFER_SIZE, spool ) != NULL )
      {
         ++line;

         if ( buffer[ 0 ] == '@' )
            continue;

         if ( !strncmp( buffer, ".\r\n", 3 ))
         {
            line = -1;
            ++article;
            continue;
         }

         if (( result = regexec( &regex, buffer, 0, NULL, 0 )))
            if ( result == REG_NOMATCH )
               continue;
            else
            {
               regerror( result, &regex, buffer, LN_BUFFER_SIZE );
               newsrc->confirm( newsrc, buffer, NP_DONE );

               EZ_UnFreezeWidget( search->search_list );
               EZ_ConfigureWidget( search->search_label,
                                   EZ_FONT_NAME, 
                                   newsreader->medium_font,
                                   EZ_LABEL_STRING, "result:",
                                   EZ_FOREGROUND, "Black",
                                   0 );
            }

         if (( search->indices 
               = realloc( search->indices, 
                          ( total + 1 ) * sizeof *search->indices ))
               == NULL )
            fatal_error();

         search->indices[ total ].group = i;
         search->indices[ total ].article = article;
         search->indices[ total ].line = line;

         item = EZ_CreateLabelItem( buffer, NULL );

         EZ_ConfigureItem( item,
                           EZ_TEXT_LINE_LENGTH, 120,
                           EZ_FONT_NAME, newsreader->medium_font,
                           0 );

         EZ_FancyListBoxInsertRow( search->search_list, &item, 1, ++total );
      }

      fclose( spool );
   }

   regfree( &regex );

   EZ_UnFreezeWidget( search->search_list );

   snprintf( buffer, LN_BUFFER_SIZE, "result: %d matches", total );
   EZ_ConfigureWidget( search->search_label,
                       EZ_FONT_NAME,
                       newsreader->medium_font,
                       EZ_LABEL_STRING, buffer,
                       EZ_FOREGROUND, "Black",
                       0 );

   EZ_NormalCursor( search->search_frame );
   if ( summary->summary_onscreen )
      EZ_NormalCursor( summary->summary_frame );
   XFlush( EZ_GetDisplay() );

   return;
}

/*
 * Motion callback of search->search_list. Makes the currently-selected
 * article in the main frame, the article that contains the line just
 * clicked-on in search->search_list's list of lines that match the current
 * regular expression, and highlights that line in the article.
 */

void search_list_motion_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_search_object *search;
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_summary_object *summary;
   np_message_object *message;

   EZ_Widget *text;

   int r, c;
   unsigned int group, article, line, temp;


   search = ( np_search_object *)data;
   buttons = ( np_buttons_object *)search->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   message = ( np_message_object *)newsreader->message_object;
   tree = ( np_tree_object *)newsreader->tree_object;

   EZ_GetFancyListBoxSelectionIdx( search->search_list, &r, &c );

   r--;
   group = search->indices[ r ].group;
   article = search->indices[ r ].article;
   line = search->indices[ r ].line;

   /* show group */

   if ( tree->group_state[ group ] == NP_INACTIVE )
   {
      EZ_ListTreeWidgetSelectNode( tree->tree, 
                    tree->server_nodes[ tree->group_list[ group ].server_idx ],
                                   NULL );
      tree->normal_callback( tree->tree, tree );
   }

   if ( EZ_GetListTreeWidgetSelection( tree->tree )
         == tree->group_nodes[ group ] )
      tree->motion_callback( tree-tree, tree );
   else
      EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ group ], 
                                   NULL );

   /* article */

   if ( summary->node_state[ article ] == NP_INACTIVE )
   {
      temp = article;
      while( summary->node_state[ temp ] == NP_INACTIVE )
         summary->node_state[ temp-- ] = NP_ACTIVE;

      summary->update_tree( summary, summary->thread_tree );
   }

   if ( EZ_GetListTreeWidgetSelection( summary->thread_tree )
         == summary->node_list[ article ] )
      summary->tree_motion_callback( summary->thread_tree, summary );
   else
      EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                   summary->node_list[ article ], NULL ); 

   /* line */

   if ( line > summary->contents[ article ].h_lines )
   {
      line -= summary->contents[ article ].h_lines;
      text = message->body_text;
   }
   else
      text = message->header_text;

   EZ_TextBeginningOfBuffer( text );

   EZ_FreezeWidget( text );

   if ( text == message->body_text || !summary->contents[ article ].is_article )
   {
      if ( line )
         while( --line )
            EZ_TextNextLine( text );
   }
   else
      while( line-- )
         EZ_TextNextLine( text );

   EZ_TextSetMarker( text );
   EZ_TextEndOfLine( text );

   EZ_TextSetRegionBackground( text, "White" );
   EZ_UnFreezeWidget( text );

   return;
}
