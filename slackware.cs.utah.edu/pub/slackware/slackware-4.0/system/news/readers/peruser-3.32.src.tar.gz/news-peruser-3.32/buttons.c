/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 * 
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "peruser.h"
#include "edit.h"
#include "newsrc.h"
#include "configure.h"
#include "search.h"
#include "folders.h"
#include "buttons.h"

#include<math.h>
#include<sys/types.h>
#include<regex.h>
#include<unistd.h>
#include<ctype.h>

#include "next_group.xpm"
#include "next_unread.xpm"
#include "next_article.xpm"
#include "next_server.xpm"
#include "next_non_empty_group.xpm"
#include "prev_server.xpm"
#include "prev_group.xpm"
#include "prev_article.xpm"
#include "prev_unread.xpm"
#include "prev_non_empty_group.xpm"

#include "jimmy-fish0.xpm"
#include "jimmy-fish1.xpm"
#include "jimmy-fish2.xpm"
#include "jimmy-fish5.xpm"
#include "jimmy-fish6.xpm"
#include "jimmy-fish7.xpm"
#include "jimmy-fish8.xpm"
#include "jimmy-fish11.xpm"
#include "title.xpm"

/*
 * Constructor.
 */

void buttons_init( void *this )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_message_object *message;
   np_tree_object *tree;
   
   char buffer[ LN_BUFFER_SIZE ];


   newsreader = ( np_newsreader_object *)this;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   summary = ( np_summary_object *)newsreader->summary_object;
   message = ( np_message_object *)newsreader->message_object;
   tree = ( np_tree_object *)newsreader->tree_object;

   buttons->parent = newsreader;
   buttons->destroy = buttons_destroy;
   buttons->pattern_onscreen = 0;

   buttons->next_group_pixmap
      = EZ_CreateLabelPixmapFromXpmData( next_group_xpm );
   buttons->prev_group_pixmap 
      = EZ_CreateLabelPixmapFromXpmData( prev_group_xpm );
   buttons->next_article_pixmap
      = EZ_CreateLabelPixmapFromXpmData( next_article_xpm );
   buttons->next_server_pixmap
      = EZ_CreateLabelPixmapFromXpmData( next_server_xpm );
   buttons->prev_server_pixmap
      = EZ_CreateLabelPixmapFromXpmData( prev_server_xpm );
   buttons->prev_article_pixmap
      = EZ_CreateLabelPixmapFromXpmData( prev_article_xpm );
   buttons->prev_unread_pixmap
      = EZ_CreateLabelPixmapFromXpmData( prev_unread_xpm );
   buttons->next_unread_pixmap
      = EZ_CreateLabelPixmapFromXpmData( next_unread_xpm );
   buttons->next_non_empty_group_pixmap
      = EZ_CreateLabelPixmapFromXpmData( next_non_empty_group_xpm );
   buttons->prev_non_empty_group_pixmap
      = EZ_CreateLabelPixmapFromXpmData( prev_non_empty_group_xpm );

   buttons->jimmy_fish0
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish0_xpm );
   buttons->jimmy_fish1
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish1_xpm );
   buttons->jimmy_fish2
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish2_xpm );
   buttons->jimmy_fish3
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish1_xpm );
   buttons->jimmy_fish4
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish0_xpm );
   buttons->jimmy_fish5
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish5_xpm );
   buttons->jimmy_fish6
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish6_xpm );
   buttons->jimmy_fish7
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish7_xpm );
   buttons->jimmy_fish8
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish8_xpm );
   buttons->jimmy_fish9
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish7_xpm );
   buttons->jimmy_fish10
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish6_xpm );
   buttons->jimmy_fish11
      = EZ_CreateLabelPixmapFromXpmData( jimmy_fish11_xpm );
   buttons->title 
      = EZ_CreateLabelPixmapFromXpmData( title_xpm );

   buttons->position = 500;
   buttons->pixmap = buttons->jimmy_fish0;

   buttons->navigation_callback = buttons_navigation_callback;
   buttons->request_callback = buttons_request_callback;
   buttons->toggle_request = buttons_toggle_request;

   buttons->mark_callback = buttons_mark_callback;
   buttons->mark_group = buttons_mark_group;
   buttons->mark_pattern = buttons_mark_pattern;
   buttons->mark_thread = buttons_mark_thread;

   buttons->folder_requests_callback = buttons_folder_requests_callback;
   buttons->extract_newsgroup = buttons_extract_newsgroup;
   buttons->update_folder = buttons_update_folder;
   buttons->compare_subjects = buttons_compare_subjects;
   buttons->request_references = buttons_request_references;
   buttons->pattern_callback = buttons_pattern_callback;
   buttons->launch_pattern = buttons_launch_pattern;

   buttons->export_callback = buttons_export_callback;
   buttons->file_selector_callback = buttons_file_selector_callback;
   buttons->decode_selector_callback = buttons_decode_selector_callback;
   buttons->cancel_callback = buttons_cancel_callback;
   buttons->decode_callback = buttons_decode_callback;
   buttons->message_decode_wrapper = buttons_message_decode_wrapper;
   buttons->get_missing_parts = buttons_get_missing_parts;

   buttons->help_callback = buttons_help_callback;
   buttons->help_done_callback = buttons_help_done_callback;
   buttons->about_callback = buttons_about_callback;
   buttons->about_done_button_callback = buttons_about_done_button_callback;
   buttons->go_home_callback = buttons_go_home_callback;
   buttons->check_for_running_netscape = buttons_check_for_running_netscape;
   buttons->animate = buttons_animate;
   buttons->selectively_disable_interface
      = buttons_selectively_disable_interface;

   /* newsrc object */

   if (( buttons->newsrc_object = malloc( sizeof *buttons->newsrc_object ))
       == NULL )
      fatal_error();

   buttons->newsrc_object->init = newsrc_init;
   buttons->newsrc_object->init( buttons );

   /* search object */

   if (( buttons->search_object = malloc( sizeof *buttons->search_object ))
       == NULL )
      fatal_error();

   buttons->search_object->init = search_init;
   buttons->search_object->init( buttons );

   /* configure object */

   if (( buttons->configure_object
         = malloc( sizeof *buttons->configure_object )) == NULL )
      fatal_error();

   buttons->configure_object->init = configure_init;
   buttons->configure_object->init( buttons );

   /* update object */

   if (( buttons->update_object 
         = malloc( sizeof *buttons->update_object )) == NULL )
      fatal_error();

   buttons->update_object->init = update_init;
   buttons->update_object->init( buttons );

   /* folders object */

   if (( buttons->folders_object
         = malloc( sizeof *buttons->folders_object )) == NULL )
      fatal_error();

   buttons->folders_object->init = folders_init;
   buttons->folders_object->init( buttons );

   /* edit object */

   if (( buttons->edit_object
         = malloc( sizeof *buttons->edit_object )) == NULL )
      fatal_error();

   buttons->edit_object->init = edit_init;
   buttons->edit_object->init( buttons );

   /* navigation buttons */                                               
                                                                          
   buttons->navigation_frame = EZ_CreateFrame( newsreader->bottom_frame,
                                               NULL );
   
   EZ_ConfigureWidget( buttons->navigation_frame,  
                       EZ_FILL_MODE, EZ_FILL_NONE,                
                       EZ_HEIGHT, 32,
                       EZ_IPADY, 0,                                        
                       EZ_IPADX, 0,                                        
                       0 );                                               
                                                                          
   buttons->prev_unread_button 
      = EZ_CreateButton( buttons->navigation_frame, "h", 0 );

   EZ_ConfigureWidget( buttons->prev_unread_button,
                       EZ_LABEL_PIXMAP, buttons->prev_unread_pixmap,
                       EZ_CLIENT_INT_DATA, 2,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );

   buttons->prev_article_button 
      = EZ_CreateButton( buttons->navigation_frame, "j", 0 );   

   EZ_ConfigureWidget( buttons->prev_article_button,
                       EZ_LABEL_PIXMAP, buttons->prev_article_pixmap,     
                       EZ_CLIENT_INT_DATA, 1,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );                                               

   buttons->prev_group_button 
      = EZ_CreateButton( buttons->navigation_frame, "b", 0 );                          
   EZ_ConfigureWidget( buttons->prev_group_button, 
                       EZ_LABEL_PIXMAP, buttons->prev_group_pixmap,       
                       EZ_CLIENT_INT_DATA, 0,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );                               

   buttons->prev_non_empty_group_button
      = EZ_CreateButton( buttons->navigation_frame, "1", 0 );

   EZ_ConfigureWidget( buttons->prev_non_empty_group_button,
                       EZ_LABEL_PIXMAP, buttons->prev_non_empty_group_pixmap,
                       EZ_CLIENT_INT_DATA, 8,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );

   buttons->prev_server_button
      = EZ_CreateButton( buttons->navigation_frame, "z", 0 );

   EZ_ConfigureWidget( buttons->prev_server_button,
                       EZ_LABEL_PIXMAP, buttons->prev_server_pixmap,
                       EZ_CLIENT_INT_DATA, 6,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );

   buttons->next_server_button
      = EZ_CreateButton( buttons->navigation_frame, "v", 0 );

   EZ_ConfigureWidget( buttons->next_server_button,
                       EZ_LABEL_PIXMAP, buttons->next_server_pixmap,
                       EZ_CLIENT_INT_DATA, 7,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );

   buttons->next_non_empty_group_button
      = EZ_CreateButton( buttons->navigation_frame, "2", 0 );

   EZ_ConfigureWidget( buttons->next_non_empty_group_button,
                       EZ_LABEL_PIXMAP, buttons->next_non_empty_group_pixmap,
                       EZ_CLIENT_INT_DATA, 9,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );

   buttons->next_group_button 
      = EZ_CreateButton( buttons->navigation_frame, "f", 0 );      

   EZ_ConfigureWidget( buttons->next_group_button,
                       EZ_LABEL_PIXMAP, buttons->next_group_pixmap,       
                       EZ_CLIENT_INT_DATA, 5,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );                                               

   buttons->next_article_button 
      = EZ_CreateButton( buttons->navigation_frame, "k", 0 );   
   
   EZ_ConfigureWidget( buttons->next_article_button,
                       EZ_LABEL_PIXMAP, buttons->next_article_pixmap,     
                       EZ_CLIENT_INT_DATA, 4,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );                                               
                                                                          
   buttons->next_unread_button 
      = EZ_CreateButton( buttons->navigation_frame, "l", 0 );

   EZ_ConfigureWidget( buttons->next_unread_button,
                       EZ_LABEL_PIXMAP, buttons->next_unread_pixmap,
                       EZ_CLIENT_INT_DATA, 3,
                       EZ_HEIGHT, 32,
                       EZ_CALLBACK, buttons->navigation_callback, buttons,
                       0 );

   /* quit */

   buttons->quit_button
      = EZ_CreateButton( newsreader->button_frame, "quit", 0 );

   EZ_ConfigureWidget( buttons->quit_button, 
                       EZ_CLIENT_INT_DATA, 0,
                       EZ_CALLBACK, escape_hatch, newsreader,
                       0 );

   /* help */

   buttons->help_button
      = EZ_CreateButton( newsreader->button_frame, "help", -1 );

   EZ_ConfigureWidget( buttons->help_button, 
                       EZ_FOREGROUND, "Black",
                       EZ_CLIENT_INT_DATA, 0,
                       EZ_CALLBACK, buttons->help_callback, buttons,
                       0 );

   /* setup menu */

   buttons->setup_button
      = EZ_CreateMenuButton( newsreader->button_frame, "setup", 3 );

   EZ_ConfigureWidget( buttons->setup_button,
                       EZ_BORDER_TYPE, EZ_BORDER_RAISED,
                       0 );

   buttons->setup_menu = EZ_CreateMenu( NULL );

   EZ_ConfigureWidget( buttons->setup_menu,
                       EZ_MENU_TEAR_OFF, False,
                       0 );

   EZ_SetMenuButtonMenu( buttons->setup_button, buttons->setup_menu );

   buttons->configure_button
      = EZ_CreateMenuNormalButton( buttons->setup_menu, "general", 0, 0 );

   EZ_ConfigureWidget( buttons->configure_button,
                       EZ_CALLBACK, buttons->configure_object->callback, 
                       buttons->configure_object,
                       0 );

   buttons->newsrc_button
      = EZ_CreateMenuNormalButton( buttons->setup_menu, 
                                   "servers/groups", 0, 1 );

   EZ_ConfigureWidget( buttons->newsrc_button,
                       EZ_CALLBACK, buttons->newsrc_object->callback, 
                       buttons->newsrc_object,
                       0 );

   buttons->virtual_button
      = EZ_CreateMenuNormalButton( buttons->setup_menu,
                                   "virtual groups", 0, 3 );

   EZ_ConfigureWidget( buttons->virtual_button,
                       EZ_CALLBACK, buttons->folders_object->callback,
                       buttons->folders_object,
                       0 );

   buttons->folders_button
      = EZ_CreateMenuNormalButton( buttons->setup_menu, "folders", 0, 4 );

   EZ_ConfigureWidget( buttons->folders_button,
                       EZ_CALLBACK, 
                       buttons->folders_object->persistent_callback,
                       buttons->folders_object,
                       0 );

   EZ_CreateMenuSeparator( buttons->setup_menu );
   
   buttons->inboxes_button
      = EZ_CreateMenuNormalButton( buttons->setup_menu,
                                   "inboxes", 0, 5 );

   EZ_ConfigureWidget( buttons->inboxes_button,
                       EZ_CALLBACK, buttons->folders_object->callback,
                       buttons->folders_object,
                       0 );

   buttons->addresses_button
      = EZ_CreateMenuNormalButton( buttons->setup_menu, "addresses", 0, 6 );
   
   EZ_ConfigureWidget( buttons->addresses_button,
                       EZ_CALLBACK, buttons->edit_object->addresses_callback,
                       buttons->edit_object,
                       0 );
   
   EZ_CreateMenuSeparator( buttons->setup_menu );

   buttons->about_button
      = EZ_CreateMenuNormalButton( buttons->setup_menu, "about", 1, 5 );

   EZ_ConfigureWidget( buttons->about_button,
                       EZ_CALLBACK, buttons->about_callback, buttons,
                       0 );

   /* update */

   buttons->update_button
      = EZ_CreateButton( newsreader->button_frame, "transfer", 2 );

   EZ_ConfigureWidget( buttons->update_button,
                       EZ_CALLBACK, buttons->update_object->callback,
                       buttons->update_object,
                       EZ_FOREGROUND, "ForestGreen",
                       0 );

   /* request */

   buttons->request_button 
      = EZ_CreateMenuButton( newsreader->button_frame, "request", 0 );

   EZ_ConfigureWidget( buttons->request_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_BORDER_TYPE, EZ_BORDER_RAISED,
                       0 );

   buttons->request_menu = EZ_CreateMenu( NULL );

   EZ_ConfigureWidget( buttons->request_menu,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_MENU_TEAR_OFF, False,
                       0 );

   EZ_SetMenuButtonMenu( buttons->request_button, buttons->request_menu );

   buttons->current_button 
      = EZ_CreateMenuNormalButton( buttons->request_menu, "current header", 
                                   8, 0 );

   EZ_ConfigureWidget( buttons->current_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->request_callback, buttons,
                       0 );

   buttons->request_thread_button
      = EZ_CreateMenuNormalButton( buttons->request_menu, "current thread", 
                                   8, 0 );

   EZ_ConfigureWidget( buttons->request_thread_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->request_callback, buttons,
                       0 );

   EZ_CreateMenuSeparator( buttons->request_menu );

   buttons->request_pattern_button
      = EZ_CreateMenuNormalButton( buttons->request_menu, "pattern", 0, 0 );

   EZ_ConfigureWidget( buttons->request_pattern_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->request_callback, buttons,
                       0 );

   buttons->references_button                            
      = EZ_CreateMenuNormalButton( buttons->request_menu,
                                   "missing references", 0, 0 );                

   EZ_ConfigureWidget( buttons->references_button,       
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->request_callback, buttons,
                       0 );                                            

   EZ_CreateMenuSeparator( buttons->request_menu );

   buttons->all_messages_button
      = EZ_CreateMenuNormalButton( buttons->request_menu, 
                                   "all headers", 0, 0 );

   EZ_ConfigureWidget( buttons->all_messages_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->request_callback, buttons,
                       0 );

   buttons->clear_button
      = EZ_CreateMenuNormalButton( buttons->request_menu,
                                   "clear requests", 0, 0 );

   EZ_ConfigureWidget( buttons->clear_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->request_callback, buttons,
                       0 );
   
   /* compose menu */

   buttons->compose_button
      = EZ_CreateMenuButton( newsreader->button_frame, "compose", 0 );

   EZ_ConfigureWidget( buttons->compose_button, 
                       EZ_BORDER_TYPE, EZ_BORDER_RAISED,
                       EZ_FOREGROUND, "ForestGreen",
                       0 );

   buttons->compose_menu = EZ_CreateMenu( NULL );

   EZ_ConfigureWidget( buttons->compose_menu,
                       EZ_MENU_TEAR_OFF, False,
                       0 );

   EZ_SetMenuButtonMenu( buttons->compose_button, buttons->compose_menu );

   buttons->original_button
      = EZ_CreateMenuNormalButton( buttons->compose_menu, "news article", 
                                   0, 0 );

   EZ_ConfigureWidget( buttons->original_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->edit_object->compose_callback, 
                       buttons->edit_object,
                       0 );

 
   buttons->follow_up_button
      = EZ_CreateMenuNormalButton( buttons->compose_menu, "follow-up", 0, 1 );

   EZ_ConfigureWidget( buttons->follow_up_button, 
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->edit_object->compose_callback, 
                       buttons->edit_object,
                       0 );

   EZ_CreateMenuSeparator( buttons->compose_menu );
   
   buttons->mail_button
      = EZ_CreateMenuNormalButton( buttons->compose_menu, "mail message",
                                   0, 1 );
   
   EZ_ConfigureWidget( buttons->mail_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->edit_object->compose_callback,
                       buttons->edit_object,
                       0 );
   
   buttons->reply_button
      = EZ_CreateMenuNormalButton( buttons->compose_menu, "reply", 0, 2 );

   EZ_ConfigureWidget( buttons->reply_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->edit_object->compose_callback,
                       buttons->edit_object,
                       0 );

   buttons->forward_button
      = EZ_CreateMenuNormalButton( buttons->compose_menu, "forward", 0, 7 );

   EZ_ConfigureWidget( buttons->forward_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK,
                       buttons->edit_object->compose_callback,
                       buttons->edit_object,
                       0 );

   EZ_CreateMenuSeparator( buttons->compose_menu );

   buttons->cancel_button                                                    
      = EZ_CreateMenuNormalButton( buttons->compose_menu, "cancel", 0, 3 );    
                                                                             
   EZ_ConfigureWidget( buttons->cancel_button,                               
                       EZ_FOREGROUND, "ForestGreen",                         
                       EZ_CALLBACK,                                          
                       buttons->edit_object->cancel_message_callback,        
                       buttons->edit_object,                                 
                       0 );                                                  
                                                                             
   buttons->supersede_button                                                 
      = EZ_CreateMenuNormalButton( buttons->compose_menu, "supersede", 0, 4 ); 
                                                                             
   EZ_ConfigureWidget( buttons->supersede_button,                            
                       EZ_FOREGROUND, "ForestGreen",                         
                       EZ_CALLBACK, buttons->edit_object->supersede_callback,
                       buttons->edit_object,                                 
                       0 );                                                  

   /* edit */

   buttons->edit_menu_button
      = EZ_CreateMenuButton( newsreader->button_frame, "edit", 0 );

   EZ_ConfigureWidget( buttons->edit_menu_button, 
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_BORDER_TYPE, EZ_BORDER_RAISED,
                       0 );

   buttons->edit_menu = EZ_CreateMenu( NULL );

   EZ_ConfigureWidget( buttons->edit_menu,
                       EZ_MENU_TEAR_OFF, False,
                       0 );

   EZ_SetMenuButtonMenu( buttons->edit_menu_button, buttons->edit_menu );

   buttons->edit_button
      = EZ_CreateMenuNormalButton( buttons->edit_menu, "edit current", 5, 0 );

   EZ_ConfigureWidget( buttons->edit_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->edit_object->edit_callback, 
                       buttons->edit_object,
                       0 );

   EZ_CreateMenuSeparator( buttons->edit_menu );
   
   buttons->delete_button
      = EZ_CreateMenuNormalButton( buttons->edit_menu,
                                   "un/mark current deleted",
                                   0, 1 );

   EZ_ConfigureWidget( buttons->delete_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_TEXT_LINE_LENGTH, 80,
                       EZ_CALLBACK, buttons->edit_object->delete_callback,
                       buttons->edit_object,
                       0 );

   buttons->delete_all_button
      = EZ_CreateMenuNormalButton( buttons->edit_menu,
                                   "un/mark all deleted",
                                   7, 2 );

   EZ_ConfigureWidget( buttons->delete_all_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->edit_object->delete_callback,
                       buttons->edit_object,
                       0 );

   buttons->expunge_button 
      = EZ_CreateMenuNormalButton( buttons->edit_menu, "expunge marked deleted",
                                   0, 3 );
   
   EZ_ConfigureWidget( buttons->expunge_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, buttons->edit_object->expunge_callback,
                       buttons->edit_object,
                       0 );
   
   EZ_CreateMenuSeparator( buttons->edit_menu );

   buttons->split_message_button
      = EZ_CreateMenuNormalButton( buttons->edit_menu, "fragment message",
                                   0, 4 );

   EZ_ConfigureWidget( buttons->split_message_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CALLBACK, 
                       buttons->edit_object->split_message_callback,
                       buttons->edit_object,
                       EZ_CLIENT_INT_DATA, 1,
                       0 );
   /* toggle */

   buttons->toggle_button
      = EZ_CreateMenuButton( newsreader->button_frame, "toggle", 0 );

   EZ_ConfigureWidget( buttons->toggle_button,
                       EZ_BORDER_STYLE, EZ_BORDER_RAISED,
                       EZ_FOREGROUND, "DarkRed",
                       0 );

   buttons->toggle_menu = EZ_CreateMenu( NULL );

   EZ_ConfigureWidget( buttons->toggle_menu,
                       EZ_MENU_TEAR_OFF, False,
                       0 );

   buttons->auto_decode_button 
      = EZ_CreateMenuNormalButton( buttons->toggle_menu,
                                   (( newsreader->auto_decode ) ?
                                    "+ auto display images" :
                                    "  auto display images" ),
                                   2, 0 );

   EZ_ConfigureWidget( buttons->auto_decode_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, newsreader->decode_callback, newsreader,
                       0 );

   buttons->fixed_button
      = EZ_CreateMenuNormalButton( buttons->toggle_menu,
                                   (( newsreader->fixed_width ) ?
                                    "+ fixed width font" :
                                    "  fixed width font" ), 
                                   2, 0 );

   EZ_ConfigureWidget( buttons->fixed_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, newsreader->fixed_callback, newsreader,
                       0 );

   buttons->large_fonts_button
      = EZ_CreateMenuNormalButton( buttons->toggle_menu,
                                   (( newsreader->large_fonts ) ?
                                    "+ large fonts" : "  large fonts" ),
                                   2, 0 );

   EZ_ConfigureWidget( buttons->large_fonts_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, newsreader->set_fonts, newsreader,
                       0 );

   buttons->hide_seen_button
      = EZ_CreateMenuNormalButton( buttons->toggle_menu,
                                   (( newsreader->hide_seen ) ?
                                    "+ hide seen" : "  hide seen" ),
                                   2, 0 );

   EZ_ConfigureWidget( buttons->hide_seen_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, newsreader->hide_callback, newsreader,
                       0 );

   buttons->hide_headers_button
      = EZ_CreateMenuNormalButton( buttons->toggle_menu,
                                   (( newsreader->hide_headers ) ?
                                    "+ hide headers" : "  hide headers" ),
                                   3, 0 );

   EZ_ConfigureWidget( buttons->hide_headers_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, newsreader->hide_callback, newsreader,
                       0 );

   buttons->long_headers_button
      = EZ_CreateMenuNormalButton( buttons->toggle_menu,
                                   (( newsreader->long_headers ) ?
                                    "  minimal headers" :
                                    "+ minimal headers" ),
                                   3, 0 );

   EZ_ConfigureWidget( buttons->long_headers_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, newsreader->long_headers_callback,
                       newsreader,
                       0 );
   
   if ( newsreader->split )
      snprintf( buffer, LN_BUFFER_SIZE,
                "+ fragment long messages (> %d lines)",
                newsreader->split );

   buttons->split_button
      = EZ_CreateMenuNormalButton( buttons->toggle_menu,
                                   (( newsreader->split ) ?
                                    buffer :
                                    "  fragment long messages" ),
                                   4, 0 );

   EZ_ConfigureWidget( buttons->split_button,
                       EZ_TEXT_LINE_LENGTH, 120,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, newsreader->split_button_callback, 
                       newsreader,
                       EZ_CLIENT_INT_DATA, 0,
                       0 );

   /* autoexpire */

   buttons->auto_expire_button
      = EZ_CreateMenuNormalButton( buttons->toggle_menu, 
                                   (( newsreader->auto_expire ) ?
                                    "+ auto expire on exit" :
                                    "  auto expire on exit" ),
                                   8, 0 );

   EZ_ConfigureWidget( buttons->auto_expire_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, newsreader->auto_expire_callback, 
                       newsreader,
                       0 );

   EZ_SetMenuButtonMenu( buttons->toggle_button, buttons->toggle_menu );

   /* mark */

   buttons->mark_button
      = EZ_CreateMenuButton( newsreader->button_frame, "mark", 0 );

   EZ_ConfigureWidget( buttons->mark_button,
                       EZ_BORDER_STYLE, EZ_BORDER_RAISED,
                       EZ_FOREGROUND, "DarkRed",
                       0 );

   buttons->mark_menu = EZ_CreateMenu( NULL );

   EZ_ConfigureWidget( buttons->mark_menu,
                       EZ_MENU_TEAR_OFF, False,
                       0 );

   buttons->read_button
      = EZ_CreateMenuNormalButton( buttons->mark_menu, "seen", 0, 0 );

   EZ_ConfigureWidget( buttons->read_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, buttons->mark_callback, buttons,
                       0 );

   buttons->unread_button
      = EZ_CreateMenuNormalButton( buttons->mark_menu, "unseen", 0, 1 );

   EZ_ConfigureWidget( buttons->unread_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, buttons->mark_callback, buttons,
                       0 );

   EZ_CreateMenuSeparator( buttons->mark_menu );

   buttons->mark_pattern_seen_button
      = EZ_CreateMenuNormalButton( buttons->mark_menu, "pattern seen", 0, 0 );

   EZ_ConfigureWidget( buttons->mark_pattern_seen_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, buttons->mark_callback, buttons,
                       0 );
   
   buttons->mark_pattern_unseen_button
      = EZ_CreateMenuNormalButton( buttons->mark_menu, "pattern unseen", 1, 
                                   0 );

   EZ_ConfigureWidget( buttons->mark_pattern_unseen_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, buttons->mark_callback, buttons,
                       0 );

   EZ_CreateMenuSeparator( buttons->mark_menu );

   buttons->mark_thread_seen_button
      = EZ_CreateMenuNormalButton( buttons->mark_menu, "thread seen", 0, 0 );

   EZ_ConfigureWidget( buttons->mark_thread_seen_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, buttons->mark_callback, buttons,
                       0 );

   buttons->mark_thread_unseen_button
      = EZ_CreateMenuNormalButton( buttons->mark_menu, "thread unseen", 1, 0 );

   EZ_ConfigureWidget( buttons->mark_thread_unseen_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, buttons->mark_callback, buttons,
                       0 );

   EZ_SetMenuButtonMenu( buttons->mark_button, buttons->mark_menu );


   /* pack */

   buttons->pack_button
      = EZ_CreateButton( newsreader->button_frame, "pack", 0 );

   EZ_ConfigureWidget( buttons->pack_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, buttons->update_object->callback,
                       buttons->update_object,
                       0 );

   /* expire */

   buttons->expire_button
      = EZ_CreateButton( newsreader->button_frame, "expire", 1 );

   EZ_ConfigureWidget( buttons->expire_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, buttons->update_object->callback, 
                       buttons->update_object,
                       0 );

   /* decode */

   buttons->decode_button
      = EZ_CreateMenuButton( newsreader->button_frame, "decode", 0 );

   EZ_ConfigureWidget( buttons->decode_button,
                       EZ_BORDER_STYLE, EZ_BORDER_RAISED,
                       EZ_FOREGROUND, "DarkBlue",
                       0 );

   buttons->decode_menu = EZ_CreateMenu( NULL );

   EZ_ConfigureWidget( buttons->decode_menu,
                       EZ_MENU_TEAR_OFF, False,
                       0 );

   buttons->decode_current_button 
      = EZ_CreateMenuNormalButton( buttons->decode_menu,
                                   "decode embedded data to disk", 
                                   0, 1 );

   EZ_ConfigureWidget( buttons->decode_current_button,
                       EZ_FOREGROUND, "DarkBlue",
                       EZ_CALLBACK, buttons->decode_callback, buttons,
                       0 );

   buttons->view_button
      = EZ_CreateMenuNormalButton( buttons->decode_menu, 
                                   "display encoded image", 12, 2 );

   EZ_ConfigureWidget( buttons->view_button,
                       EZ_FOREGROUND, "DarkBlue",
                       EZ_CALLBACK, buttons->message_decode_wrapper, buttons,
                       0 );

   EZ_SetMenuButtonMenu( buttons->decode_button, buttons->decode_menu );

   /* summary */

   buttons->summary_button
      = EZ_CreateButton( newsreader->button_frame, "summary", 6 );

   EZ_ConfigureWidget( buttons->summary_button,
                       EZ_FOREGROUND, "DarkBlue",
                       EZ_CALLBACK, summary->callback, summary,
                       0 );

   /* search */

   buttons->search_button
      = EZ_CreateButton( newsreader->button_frame, "search", 0 );

   EZ_ConfigureWidget( buttons->search_button, 
                       EZ_FOREGROUND, "DarkBlue",
                       EZ_CALLBACK, buttons->search_object->callback, 
                       buttons->search_object,
                       0 );

   buttons->export_button
      = EZ_CreateButton( newsreader->button_frame, "export", 3 );

   EZ_ConfigureWidget( buttons->export_button,
                       EZ_FOREGROUND, "DarkBlue",
                       EZ_CALLBACK, buttons->export_callback, buttons,
                       0 );

   return;
}

/*
 * Destructor.
 */

void buttons_destroy( void *this )
{
   np_buttons_object *buttons;
   np_newsrc_object *newsrc;


   buttons = ( np_buttons_object *)this;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   EZ_FreeLabelPixmap( buttons->next_group_pixmap );
   EZ_FreeLabelPixmap( buttons->prev_group_pixmap );
   EZ_FreeLabelPixmap( buttons->next_article_pixmap );
   EZ_FreeLabelPixmap( buttons->prev_article_pixmap );
   EZ_FreeLabelPixmap( buttons->next_unread_pixmap );
   EZ_FreeLabelPixmap( buttons->prev_unread_pixmap );
   EZ_FreeLabelPixmap( buttons->prev_server_pixmap );
   EZ_FreeLabelPixmap( buttons->next_server_pixmap );
   EZ_FreeLabelPixmap( buttons->prev_non_empty_group_pixmap );
   EZ_FreeLabelPixmap( buttons->next_non_empty_group_pixmap );

   EZ_FreeLabelPixmap( buttons->jimmy_fish0 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish1 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish2 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish3 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish4 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish5 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish6 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish7 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish8 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish9 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish10 );
   EZ_FreeLabelPixmap( buttons->jimmy_fish11 );
   EZ_FreeLabelPixmap( buttons->title );

   EZ_FreeLabelPixmap( newsrc->confirm_pixmap );
   EZ_FreeLabelPixmap( newsrc->query_pixmap );
   EZ_FreeLabelPixmap( newsrc->animate_pixmap_0 );
   EZ_FreeLabelPixmap( newsrc->animate_pixmap_1 );
   EZ_FreeLabelPixmap( newsrc->animate_pixmap_2 );
   EZ_FreeLabelPixmap( newsrc->animate_pixmap_3 );
   EZ_FreeLabelPixmap( newsrc->animate_pixmap_4 );
   EZ_FreeLabelPixmap( newsrc->animate_pixmap_5 );
   EZ_FreeLabelPixmap( newsrc->animate_pixmap_6 );

   free( buttons->newsrc_object );
   free( buttons->search_object );
   free( buttons->update_object );
   free( buttons->configure_object );
   free( buttons->folders_object );

   if ( buttons->edit_object->message.header != NULL )
      free( buttons->edit_object->message.header );
   if ( buttons->edit_object->message.body != NULL )
      free( buttons->edit_object->message.body );

   free( buttons->edit_object );

   return;
}

/*
 * returns copy of the contents of the Newsgroups header in message->message.
 */

char *buttons_extract_newsgroup( void *this, unsigned int i )
{
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_message_object *message;

   char *value, *pointer, buffer[ LN_BUFFER_SIZE ];
   unsigned int l;
   enum{ NO, YES }found;

   buttons = ( np_buttons_object *)this;
   summary = ( np_summary_object *)
      (( np_newsreader_object *)buttons->parent )->summary_object;
   message = ( np_message_object *)
      (( np_newsreader_object *)buttons->parent )->message_object;

   EZ_ListTreeWidgetSelectNode( summary->thread_tree, summary->node_list[ i ],
                                NULL );

   if ( summary->contents[ i ].is_article )
      pointer = message->message.header - 1;
   else
      pointer = strchr( message->message.header, '\n' );

   found = NO;
   value = NULL;

   while( *( ++pointer ) )
   {
      if ( !strncmp( pointer, "Newsgroups: ", 12 ))
      {
         found = YES;
         break;
      }

      pointer = strchr( pointer, '\n' );
   }

   if ( found )
   {
      l = strcspn( pointer, "\n" );
      strncpy( buffer, pointer, l );
      buffer[ l ] = '\0';

      pointer = buffer + 12 + strspn( buffer + 12, " \t" );
      strtok( pointer, ", \t\r\n" );

      if (( value = strdup( pointer )) == NULL )
         fatal_error();
   }

   return value;
}  

/*
 * Adds or removes a request for full article text from the currently-selected
 * newsgroup's :requests file.
 */

void buttons_toggle_request( void *this, void *summary_object, char folder, 
                             unsigned int i, unsigned int j )
{
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_tree_object *tree;

   unsigned int k, l;
   char *group_name, c;
   np_order radio_value;

   EZ_Item **items, *item;

   buttons = ( np_buttons_object *)this;
   summary = ( np_summary_object *)summary_object;
   tree = ( np_tree_object *)
      (( np_newsreader_object *)summary->parent )->tree_object;

   if ( summary->contents[ i ].is_article )
      return;

   if ( folder )
      group_name = buttons->extract_newsgroup( buttons, i );
   else
      group_name = NULL;

   if ( ln_toggle_request( summary->group_name,
                           summary->contents[ i ].offset, 
                           folder, group_name ) == -1 )
      lib_error();

   if ( group_name != NULL )
      free( group_name );

   if ( ( summary->contents[ i ].is_requested ^= 1 ) )
   {
      summary->stats.requests++;
      tree->group_list[ j ].requests++;
   }
   else
   {
      summary->stats.requests--;
      tree->group_list[ j ].requests--;
   }

   if ( summary->node_list[ i ] != NULL &&
        ( item = EZ_TreeNodeGetItem( summary->node_list[ i ] )) != NULL )
      EZ_ConfigureItem( item,
                        EZ_FOREGROUND,
                        (( summary->contents[ i ].is_requested ) ? 
                         summary->requested_colour :
                         summary->header_colour ),
                        0 );

   if ( summary->summary_onscreen )
   {
      l = i + 1;

      for( k = 0; k < summary->stats.total; ++k )
         if ( summary->positions[ k ] == l )
            break;

      EZ_FancyListBoxSelectItemUsingIdx( summary->summary_list, ++k, 0, NULL );

      radio_value = 
         EZ_GetRadioButtonGroupVariableValue( summary->subject_button );

      items = EZ_GetFancyListBoxSelection( summary->summary_list );

      switch( radio_value )
      {
         case NP_SUBJECT:
            c = 0;
            break;

         case NP_POSTER:
            c = 2;
            break;

         case NP_DATE:
            c = 1;
            break;
      }

      EZ_ConfigureItem( items[ c ],
                        EZ_FOREGROUND, 
                        (( summary->contents[ i ].is_requested ) ?
                         summary->requested_colour : summary->header_colour ),
                        0 );
   }

   return;
}

/*
 * Adds reference requests to currently-selected newsgroup's :references
 * file.
 */

void buttons_request_references( void *this, void *summary_object,
                                 char folder, unsigned int i, unsigned int j )
{
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_summary_object *summary;
   np_message_object *message;
   np_tree_object *tree;

   char *pointer, *group_name, buffer[ LN_BUFFER_SIZE ];
   enum{ NO, YES }found, success;
   int result;
   unsigned int l, rl, count;
   FILE *file;


   buttons = ( np_buttons_object *)this;
   summary = ( np_summary_object *)summary_object;
   newsreader = ( np_newsreader_object *)buttons->parent;
   message = ( np_message_object *)newsreader->message_object;
   tree = ( np_tree_object *)newsreader->tree_object;

   if ( summary->contents[ j ].is_article )
      pointer = message->message.header - 1;
   else
      pointer = strchr( message->message.header, '\n' );

   while( *( ++pointer ))
   {
      if ( !strncmp( pointer, "References: ", 12 ))
      {
         found = YES;
         break;
      }

      pointer = strchr( pointer, '\n' );
   }

   if ( !found )
      return;

   buffer[ 0 ] = '\0';
   rl = l = 0;

   do
   {
      l = strcspn( pointer, "\n" );
      strncat( buffer, pointer, l );
      rl += l;
      buffer[ rl - 1 ] = ' ';
      buffer[ rl ] = '\0';
   }
   while( isspace( *( pointer += l + 1 )));
   strcat( buffer, "\n" );

   success = NO;

   if ( folder )
      group_name = buttons->extract_newsgroup( buttons, j );
   else
      group_name = NULL;

   strtok( buffer, " \t\r\n" );
   while(( pointer = strtok( NULL, " \t\r\n" )) != NULL )
   {
      found = NO;
      for( l = 0; l < summary->stats.total; ++l )
         if ( !strcmp( summary->contents[ l ].message_id, pointer ))
         {
            found = YES;
            break;
         }

      if ( found )
         continue;

      if (( result = ln_toggle_reference( summary->group_name, folder,
                                          summary->contents[ j ].message_id, 
                                          pointer, group_name )) == -1 )
         lib_error();
   }

   if ( group_name != NULL )
      free( group_name );

   /*
    * Since we do not know exactly whether the calls to ln_toggle_reference
    * added or removed reference requests we must read the group's requests
    * file for the count. It would be better for ln_toggle_reference to
    * return the count in a value-return argument.
    */ 
   
   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests",
             getenv( "HOME" ), tree->group_list[ i ].group );
   
   if (( file = fopen( buffer, "r" )) == NULL )
      if ( errno != ENOENT )
         fatal_error();

   count = 0; 
   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
      ++count;
   fclose( file );
   
   tree->group_list[ i ].requests = summary->stats.requests = count;
   summary->contents[ j ].has_ref_requests = 1;

   /* reset the thread tree */

   summary->set_tree( summary, summary->thread_tree, 
                      tree->group_list[ i ].group, 
                      tree->group_list[ i ].total, i );

   EZ_ListTreeWidgetSelectNode( summary->thread_tree, summary->node_list[ j ],
                                NULL );

   return;
}

/*
 * Used by buttons_request_callback to mark headers in current thread
 * requested. If thread relationships do not exist, then Subject headers are
 * compared.
 */

int buttons_compare_subjects( char *one, char *two )
{
   char one_buffer[ LN_BUFFER_SIZE ], two_buffer[ LN_BUFFER_SIZE ];
   int offset = 0;


   if ( !strncmp( one, "Re: ", 4 ) || !strncmp( one, "re: ", 4 ))
      offset = 4;

   strcpy( one_buffer, one + offset );

   offset = 0;
   if ( !strncmp( two, "Re: ", 4 ) || !strncmp( two, "re:", 4 ))
      offset = 4;

   strcpy( two_buffer, two + offset );

   offset = -1;
   while( one_buffer[ ++offset ] )
      one_buffer[ offset ] = tolower( one_buffer[ offset ] );

   offset = -1;
   while( two_buffer[ ++offset ] )
      two_buffer[ offset ] = tolower( two_buffer[ offset ] );
     
   return strcmp( one_buffer, two_buffer );
}

/*
 * Marks articles with Subject headers matching a user-supplied regular
 * expression as seen.
 */

void buttons_mark_pattern( void *this, void *tree_object, void *summary_object, 
                           unsigned int i, unsigned int j, char seen )
{
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_summary_object *summary;
   np_newsreader_object *newsreader;

   unsigned int old;


   buttons = ( np_buttons_object *)this;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   tree = ( np_tree_object *)newsreader->tree_object;

   if ( seen )
   {
      if ( !summary->contents[ j ].is_unread )
         return;

      old = tree->group_list[ i ].unread;

      if ( ln_mark_read( tree->group_list[ i ].group, j + 1 ) == -1 )
         lib_error();

      tree->group_list[ i ].unread++;
      if ( !old )
         EZ_ConfigureItem( EZ_TreeNodeGetItem( tree->group_nodes[ i ] ),
                           EZ_FONT_NAME, newsreader->medium_font,
                           0 );

      summary->contents[ j ].is_unread = 0;
      EZ_ConfigureItem( EZ_TreeNodeGetItem( summary->node_list[ j ] ),
                        EZ_FONT_NAME, newsreader->medium_font, 0 );
   }
   else
   {
      if ( summary->contents[ j ].is_unread )
         return;

      if ( ln_mark_unread( tree->group_list[ i ].group, j + 1 ) == -1 )
         lib_error();

      if ( !( --tree->group_list[ i ].unread ))
         EZ_ConfigureItem( EZ_TreeNodeGetItem( tree->group_nodes[ i ] ),
                           EZ_FONT_NAME, newsreader->bold_font,
                           0 );

      summary->contents[ j ].is_unread = 1;
      summary->stats.unread++;

      EZ_ConfigureItem( EZ_TreeNodeGetItem( summary->node_list[ j ] ),
                        EZ_FONT_NAME, newsreader->bold_font,
                        0 );
   }

   return;
}

/*
 * Callback for pattern entry frame.
 */

void buttons_pattern_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_newsrc_object *newsrc;
   np_summary_object *summary;
   np_newsreader_object *newsreader;

   EZ_Widget *button;

   regex_t regex;

   char buffer[ LN_BUFFER_SIZE ];
   unsigned int i, j, result;


   buttons = ( np_buttons_object *)data;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   buffer[ 0 ] = '\0';
   strcpy( buffer, EZ_GetEntryString( widget ));

   i = EZ_GetWidgetIntData( widget );
   button = EZ_GetWidgetPtrData( widget );

   EZ_DestroyWidget( buttons->frame );
   EZ_NormalCursor( newsreader->app_frame );

   if ( buffer[ 0 ] == '\0' )
      return;

   if (( result = regcomp( &regex, buffer, REG_EXTENDED | REG_NOSUB )))
   {
      regerror( result, &regex, buffer, LN_BUFFER_SIZE );
      regfree( &regex );
      newsrc->answer = -1;
      newsrc->confirm( newsrc, buffer, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
      return;
   }

   for( j = 0; j < summary->stats.total; ++j )
   {
      if (( result = regexec( &regex, 
                              summary->contents[ j ].subject, 0, NULL, 0 )))
         if ( result == REG_NOMATCH )
            continue;
         else
         {
            regerror( result, &regex, buffer, LN_BUFFER_SIZE );
            newsrc->answer = -1;
            newsrc->confirm( newsrc, buffer, NP_DONE );
            while( newsrc->answer == -1 )
               EZ_WaitAndServiceNextEvent();
         }

      if ( button == buttons->request_pattern_button )
         buttons->toggle_request( buttons, summary, 0, j, i );
      else
         if ( button == buttons->mark_pattern_seen_button )
            buttons->mark_pattern( buttons, tree, summary, i, j, ( char )1 );
         else
            if ( button == buttons->mark_pattern_unseen_button )
               buttons->mark_pattern( buttons, tree, summary, i, j, 
                                      ( char )0 );
   }

   regfree( &regex );
   buttons->pattern_onscreen = 0;

   return;
}

/*
 * Displays pattern entry frame and associates entry with callback based on
 * button passed as argument.
 */

void buttons_launch_pattern( void *this, unsigned int i, EZ_Widget *button )
{
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;

   EZ_Widget *entry;


   buttons = ( np_buttons_object *)this;
   newsreader = ( np_newsreader_object *)buttons->parent;

   buttons->frame = EZ_CreateFrame( NULL, "Regular Expression:" );

   EZ_ConfigureWidget( buttons->frame,
                       EZ_HEIGHT, 100,
                       EZ_WIDTH, 500,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   entry = EZ_CreateEntry( buttons->frame, NULL );

   EZ_ConfigureWidget( entry,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 450,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_CLIENT_INT_DATA, i,
                       EZ_CLIENT_PTR_DATA, button,
                       EZ_CALLBACK, buttons->pattern_callback,
                       buttons,
                       0 );

   buttons->pattern_onscreen = 1;
   EZ_DisplayWidget( buttons->frame );
   EZ_SetGrab( buttons->frame );
   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));

   while( buttons->pattern_onscreen )
      EZ_WaitAndServiceNextEvent();

   return;
}

/*
 * Callback for all items on the request menu.
 */

void buttons_request_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_newsreader_object *newsreader;
   np_tree_object *tree;

   EZ_TreeNode *selected, *parent;
   EZ_Item *item;

   unsigned int i, j, k;
   enum{ current, thread, pattern, references, all, clear }what;
   char folder, node_type, buffer[ LN_BUFFER_SIZE ];


   buttons = ( np_buttons_object *)data;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   tree = ( np_tree_object *)newsreader->tree_object;

   if ( ( selected = EZ_GetListTreeWidgetSelection( tree->tree ))
         == NULL )
      return;

   if ( !summary->stats.total )
      return;

   item = EZ_TreeNodeGetItem( selected );

   if (( node_type = *( char *)EZ_GetItemPtrData( item )) == 's' )
      return;

   i = EZ_GetItemIntData( item );

   if ( !strncmp( tree->group_list[ i ].server, "Folders", 7 ) ||
        !strncmp( tree->group_list[ i ].server, "Mailboxes", 9 ))
      return;

   if ( !strncmp( tree->group_list[ i ].server, "Virtual", 7 ))
      folder = 1;
   else
      folder = 0;

   if ( widget == buttons->current_button )
      what = current;
   else
      if ( widget == buttons->request_thread_button )
         what = thread;
      else
         if ( widget == buttons->request_pattern_button )
            what = pattern;
         else
            if ( widget == buttons->references_button )
               what = references;
            else
               if ( widget == buttons->all_messages_button )
                  what = all;
               else
                  if ( widget == buttons->clear_button )
                     what = clear;
                  else  
                     return;

   if ( ( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         != NULL )
      j = ( unsigned int)EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

   switch( what )
   {
      case current:

         if ( selected == NULL )
            return;

         if ( summary->contents[ j ].is_article )
            return;

         buttons->toggle_request( buttons, summary, folder, j, i );
         break;

      case thread:

         if ( selected == NULL || selected == summary->root )
            return;

         while( ( parent = EZ_TreeNodeGetParent( selected )) != summary->root )
            selected = parent;

         j = ( unsigned int)EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

         k = j;

         do
            buttons->toggle_request( buttons, summary, folder, k++, i );
         while( ( k < summary->stats.total ) && 
                summary->contents[ k ].threading );

         while( k < summary->stats.total )      
            if ( !buttons->compare_subjects( summary->contents[ j ].subject,
                                             summary->contents[ k ].subject ))                          
            {                                                                
               buttons->toggle_request( buttons, summary, folder, k, i );      

               if ( summary->contents[ k++ ].queue )                           
                  while( k < summary->stats.total &&                         
                        summary->contents[ k ].threading )                 
                     buttons->toggle_request( buttons, summary, folder, k++, 
                                              i );
            }
            else
               ++k;

         if ( j > 0 )
            for( k = 0; k < j; ++k )
               if ( !buttons->compare_subjects( summary->contents[ j ].subject,
                                               summary->contents[ k ].subject ))
               {
                  buttons->toggle_request( buttons, summary, folder, k, i );

                  if( summary->contents[ k ].queue )
                     while( ++k < j && summary->contents[ k ].threading )
                        buttons->toggle_request( buttons, summary, 
                                                 folder, k, i );
               }

         EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                      summary->node_list[ j ], NULL );
         break;

      case pattern:

         buttons->launch_pattern( buttons, i, buttons->request_pattern_button );
         
         break;

      case references:

         if ( selected == NULL )
            return;

         buttons->request_references( buttons, summary, folder, i, j ); 
         break;

      case all:

         if ( !summary->stats.total )
            return;

         for( j = 0; j < summary->stats.total; ++j )
            if ( !summary->contents[ j ].is_article )
               buttons->toggle_request( buttons, summary, folder, j, i );

         break;

      case clear:

         snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests",
                   getenv( "HOME" ), tree->group_list[ i ].group );
         remove( buffer );

         tree->update_lists( tree );
         tree->set_tree( tree );

         EZ_ListTreeWidgetSelectNode( tree->tree, 
                                      tree->group_nodes[ i ], NULL );
         if ( selected != NULL )
            EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                         summary->node_list[ j ], NULL ); 
         break;
   }

   if ( summary->summary_onscreen )
      summary->show_stats( summary );

   return;
}

/*
 * Called by buttons_mark_callback to mark all articles in a group as seen.
 */

void buttons_mark_group( void *this, unsigned int i, EZ_Widget *widget )
{
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_summary_object *summary;

   unsigned int j;

   
   buttons = ( np_buttons_object *)this;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   if ( widget == buttons->read_button )
   {
      if ( !tree->group_list[ i ].unread )
         return;

      if ( ln_mark_read( tree->group_list[ i ].group, 0 ) == -1 )
         lib_error();

      tree->group_list[ i ].unread = 0;
      for( j = 0; j < summary->stats.total; ++j )
         summary->contents[ j ].is_unread = 0;
      summary->stats.unread = 0;

      EZ_ConfigureItem( EZ_TreeNodeGetItem( tree->group_nodes[ i ] ),
                        EZ_FONT_NAME, newsreader->medium_font, 
                        0 );
   } 
   else
   {
      if ( tree->group_list[ i ].unread == tree->group_list[ i ].total ) 
         return;

      if ( ln_mark_unread( tree->group_list[ i ].group, 0 ) == -1 )
         lib_error();

      tree->group_list[ i ].unread = tree->group_list[ i ].total;
      for( j = 0; j < summary->stats.total; ++j )
         summary->contents[ j ].is_unread = 1;
      summary->stats.unread = summary->stats.total;

      EZ_ConfigureItem( EZ_TreeNodeGetItem( tree->group_nodes[ i ] ),
                        EZ_FONT_NAME, newsreader->bold_font,
                        0 );
   }

   return;
}

void buttons_mark_thread( void *this, EZ_Widget *widget, unsigned int i )
{
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_newsreader_object *newsreader;
   np_tree_object *tree;

   int( *function )( char *string, unsigned int position );
   unsigned int j, k, old, count = 0;

   EZ_TreeNode *selected, *parent;


   buttons = ( np_buttons_object *)this;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         == NULL || selected == summary->root )
      return;

   if ( widget == buttons->mark_thread_seen_button )
      function = ln_mark_read;
   else
      function = ln_mark_unread;

   while(( parent = EZ_TreeNodeGetParent( selected )) != summary->root )
      selected = parent;

   j = ( unsigned int)EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));
   k = j;

   old = summary->stats.unread;

   while(( k < summary->stats.total ) && summary->contents[ k ].threading )
   {
      ++count;
      summary->contents[ k ].is_unread ^= 1;
      if ( function( tree->group_list[ i ].group, ++k ) == -1 )
         lib_error();
   }

   while( k < summary->stats.total )
      if ( !buttons->compare_subjects( summary->contents[ j ].subject,
                                       summary->contents[ k ].subject ))
      {
         ++count;
         summary->contents[ k ].is_unread ^= 1;
         if ( function( tree->group_list[ i ].group, k + 1 ) == -1 )
            lib_error();

         if ( summary->contents[ k++ ].queue )
            while( k < summary->stats.total &&
                   summary->contents[ k ].threading )
            {
               ++count;
               summary->contents[ k ].is_unread ^= 1;
               if ( function( tree->group_list[ i ].group, ++k ) == -1 )
                  lib_error();
            }
      }
      else
         ++k;

   if ( j > 0 )
      for( k = 0; k < j; ++k )
         if ( !buttons->compare_subjects( summary->contents[ j ].subject,
                                          summary->contents[ k ].subject ))
         {
            ++count;
            summary->contents[ k ].is_unread ^= 1;
            if ( function( tree->group_list[ i ].group, k + 1 ) == -1 )
               lib_error();

            if ( summary->contents[ k++ ].queue )
               while( k < j && summary->contents[ k ].threading )
               {
                  ++count;
                  summary->contents[ k ].is_unread ^= 1;
                  if ( function( tree->group_list[ i ].group, ++k ) == -1 )
                     lib_error();
               }
         }

   if ( function == ln_mark_read )
      if ( !( tree->group_list[ i ].unread = summary->stats.unread -= count ))
         EZ_ConfigureItem( EZ_TreeNodeGetItem( tree->group_nodes[ i ] ),
                           EZ_FONT_NAME, newsreader->medium_font,
                           0 );
   else
   {
      tree->group_list[ i ].unread = summary->stats.unread += count;
      if ( !old )
         EZ_ConfigureWidget( EZ_TreeNodeGetItem( tree->group_nodes[ i ] ),
                             EZ_FONT_NAME, newsreader->bold_font,
                             0 );
   }

   if ( function == ln_mark_read )
      EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                   summary->node_list[ j ], NULL );

   return;
}

/*
 * Callback for items on mark menu.
 */

void buttons_mark_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_summary_object *summary;
   np_newsreader_object *newsreader;

   EZ_TreeNode *selected, *summary_node;
   EZ_Item *item;

   unsigned int i, j, old;
   enum{ ROOT, SERVER, GROUP, PATTERN, THREAD }what;
   enum{ NO, YES }found;

   buttons = ( np_buttons_object *)data;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   EZ_FreezeWidget( tree->tree );
   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      return;

   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));

   found = NO;

   if ( widget == buttons->mark_pattern_seen_button ||
        widget == buttons->mark_pattern_unseen_button )
   {
      item = EZ_TreeNodeGetItem( selected );
      if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      {
         EZ_NormalCursor( newsreader->app_frame );
         return;
      }

      i = EZ_GetItemIntData( item );
      buttons->launch_pattern( buttons, i, widget );
      what = PATTERN;
      found = YES;
   }
   else
      if ( widget == buttons->mark_thread_seen_button ||
           widget == buttons->mark_thread_unseen_button )
      {
         item = EZ_TreeNodeGetItem( selected );
         if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
         {
            EZ_NormalCursor( newsreader->app_frame );
            return;
         }         
         i = EZ_GetItemIntData( item );
         buttons->mark_thread( buttons, widget, i );

         what = THREAD;
         found = YES;
      }

   if ( !found && selected == tree->root_node )
   {
      what = ROOT;

      for( i = 0; i < tree->groups; ++i )
      {
         if ( !tree->group_list[ i ].total )
            continue;

         buttons->mark_group( buttons, i, widget );
      }

      found = YES;
   }

   if ( !found )
   {
      item = EZ_TreeNodeGetItem( selected );
      i = EZ_GetItemIntData( item );

      if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      {
         what = SERVER;

         for( j = 0; j < tree->groups; ++j )
            if ( tree->group_list[ j ].server_idx == i )
            {
               if ( ! tree->group_list[ j ].total )
                  continue;

               buttons->mark_group( buttons, j, widget );
            }

         found = YES;
      }
   }

   if ( !found )
   {
      what = GROUP;

      if ((( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
            == NULL ) ||
            widget == buttons->read_button )
         buttons->mark_group( buttons, i, widget );
      else
      {
         j = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

         if ( !summary->contents[ j ].is_unread )
         {
            if ( ln_mark_unread( tree->group_list[ i ].group, j + 1 ) == -1 )
               lib_error();
            summary->contents[ j ].is_unread = 1;
            tree->group_list[ i ].unread++;
            old = summary->stats.unread++;
 
            if ( !old )
               EZ_ConfigureItem( item,
                                 EZ_FONT_NAME, newsreader->bold_font,
                                 0 );
         }
      }
   }

   switch( what )
   {
      case ROOT:
         selected = tree->root_node;
         break;

      case SERVER:
         selected = tree->server_nodes[ i ];
         break;

      case GROUP:
         selected = tree->group_nodes[ i ];

      case PATTERN:
         selected = EZ_GetListTreeWidgetSelection( tree->tree );
         break;
         
      case THREAD:
         selected = tree->group_nodes[ i ];
         break;
   }

   summary_node = EZ_GetListTreeWidgetSelection( summary->thread_tree );
   EZ_ListTreeWidgetSelectNode( tree->tree, NULL, NULL );
   EZ_ListTreeWidgetSelectNode( tree->tree, selected, NULL );
   if ( summary_node != NULL )
      EZ_ListTreeWidgetSelectNode( summary->thread_tree, summary_node, NULL );

   EZ_NormalCursor( newsreader->app_frame );
   EZ_UnFreezeWidget( tree->tree );

   return;
}

/*
 * Callback for virtual button. Gets requested articles for virtual
 * newsgroup(s).
 */

void buttons_folder_requests_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;
   np_summary_object *summary;

   EZ_TreeNode *selected;
   EZ_Item *item;

   unsigned int i, j;
   long int k;
   enum{ SERVER, GROUP }what;
   char *pointer, *home, buffer[ LN_BUFFER_SIZE ];


   buttons = ( np_buttons_object *)data;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   if ( ( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      return;

   item = EZ_TreeNodeGetItem( selected );
   i = ( unsigned int )EZ_GetItemIntData( item );

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         == NULL )
      k = -1;
   else
      k = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

   if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      what = SERVER;
   else
      what = GROUP;

   if ( what == SERVER )
      pointer = tree->server_list[ i ].server;
   else
      pointer = tree->group_list[ i ].server;

   if ( strncmp( pointer, "Virtual", 7 ))
   {
      newsrc->answer = -1;
      newsrc->confirm( newsrc, "Select a virtual group,\n"
                       "or the \"Virtual\" node\n"
                       "in the server tree, first.", NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
      
      return;
   }

   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));

   if ( ln_get_message_text( NULL, 0, 0, 0, NULL ))
      lib_error();

   home = getenv( "HOME" );

   if ( what == GROUP )
   {
      buttons->okay = 0;
      buttons->update_folder( buttons, tree->group_list[ i ].group );

      if ( buttons->okay )
      {
         if ( ln_sort_spool( tree->group_list[ i ].group ) == -1 )
            lib_error();
         if ( ln_thread_spool( tree->group_list[ i ].group ) == -1 )
            lib_error();

         snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests",
                   home, tree->group_list[ i ].group );
         truncate( buffer, 0 );
      }
   }
   else
   {
      for( j = 0; j < tree->groups; ++j )
      {
         if ( strncmp( tree->group_list[ j ].server, "Virtual", 7 ))
            continue;

         buttons->okay = 0;
         buttons->update_folder( buttons, tree->group_list[ j ].group );

         if ( buttons->okay )
         {
            if ( ln_sort_spool( tree->group_list[ j ].group ) == -1 )
               lib_error();
            if ( ln_thread_spool( tree->group_list[ j ].group ) == -1 )
               lib_error();

            snprintf( buffer, LN_BUFFER_SIZE, 
                      "%s/.peruser_spool/%s:requests",
                      home, tree->group_list[ j ].group );
            truncate( buffer, 0 );
         }
      }
   }

   EZ_NormalCursor( newsreader->app_frame );
   newsreader->show_message( newsreader, NULL );

   tree->update_lists( tree );
   tree->set_tree( tree );

   if ( what == GROUP )
   {
      EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ i ], NULL );
      if ( k >= 0 )
         EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                      summary->node_list[ k ], NULL );
   }
   else
      EZ_ListTreeWidgetSelectNode( tree->tree, tree->server_nodes[ i ], NULL );


   return;
}

/*
 * Retrieves requests for a virtual newsgroup.
 */

void buttons_update_folder( void *this, char *folder )
{
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_update_object *update;
   np_newsreader_object *newsreader;

   ln_requests_list *list;

   unsigned int i, count;
   char *open, buffer[ LN_BUFFER_SIZE ];


   buttons = ( np_buttons_object *)this;
   update = buttons->update_object;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;

   open = "";

   for( i = 0; i < tree->groups; ++i )
   {
      if ( !strncmp( tree->group_list[ i ].server, "Virtual", 7 ))
         break;

      if ( ln_get_folder_list( tree->group_list[ i ].group, 
                               folder, &list, &count ) == -1 )
         lib_error();

      if ( !count )
         continue;

      if ( strcmp( tree->group_list[ i ].server, open ))
      {
         if ( *open )
         {
            fputs( "quit\r\n", update->stream );
            fclose( update->stream );
         }

         if ( update->open_server( update, tree->group_list[ i ].server, 
                                   tree->group_list[ i ].server_idx ))
            return;

         buttons->okay = 1;
         open = tree->group_list[ i ].server;
      }

      fprintf( update->stream, "group %s\r\n", tree->group_list[ i ].group );
      fgets( buffer, LN_BUFFER_SIZE, update->stream );
      if ( strncmp( buffer, "211", 3 ))
      {
         newsreader->show_message( newsreader, buffer );
         ln_destroy_requests_list( list, count );
         continue;
      }

      if ( ln_retrieve_requests( folder, update->stream, 
                                 list, count, 1, update->progress_callback,
                                 update ) == -1 )
         lib_error();

      ln_destroy_requests_list( list, count );
   }

   if ( *open )
   {
      fputs( "quit\r\n", update->stream );
      fclose( update->stream );
   }

   return;
}

/*
 * Exports full header and article text of currently-selected article to file.
 */

void buttons_export_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_summary_object *summary;

   EZ_Widget *selection_entry, *dir_list, *file_list,
       *ok_button, *filter_button, *cancel_button;

   EZ_TreeNode *selected;
   EZ_Item *item;

   unsigned int i;


   buttons = ( np_buttons_object *)data;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;

   if ( ( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         == NULL )
      return;

   item = EZ_TreeNodeGetItem( selected );
   i = ( unsigned int)EZ_GetItemIntData( item );

   if ( summary->contents[ i ].is_article )
      buttons->is_article = 1;
   else
      buttons->is_article = 0;

   buttons->export_frame 
       = EZ_CreateFrame( NULL, (( widget == buttons->decode_button ) ?
                                "Decode to Disk" :
                                "Export Article" ));
   
   EZ_ConfigureWidget( buttons->export_frame,
                       EZ_HEIGHT, 450,
                       EZ_WIDTH, 500,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   buttons->file_selector
       = EZ_CreateFileSelector( buttons->export_frame, "*" );

   EZ_ConfigureWidget( buttons->file_selector,
                       EZ_CALLBACK, (( widget == buttons->decode_button ) ?
                       buttons->decode_selector_callback : 
                       buttons->file_selector_callback ), buttons,
                       0 );

   EZ_GetFileSelectorWidgetComponents( buttons->file_selector,
                                       &buttons->filter_entry,
                                       &selection_entry,
                                       &dir_list,
                                       &file_list,
                                       &ok_button,
                                       &filter_button,
                                       &cancel_button );

   EZ_ConfigureWidget( buttons->filter_entry, 
                       EZ_HEIGHT, 50,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   EZ_ConfigureWidget( selection_entry,
                       EZ_HEIGHT, 50,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   if ( widget == buttons->decode_button )
       EZ_SetEntryString( selection_entry, buttons->item->filename );

   EZ_ConfigureWidget( ok_button,
                       EZ_HEIGHT, 30,
                       EZ_UNDERLINE, -1,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_LABEL_STRING, "done",
                       0 );

   EZ_ConfigureWidget( filter_button,
                       EZ_HEIGHT, 30,
                       EZ_UNDERLINE, -1,
                       EZ_LABEL_STRING, "filter",
                       0 );

   EZ_ConfigureWidget( cancel_button,
                       EZ_LABEL_STRING, "cancel",
                       EZ_FOREGROUND, "DarkRed",
                       EZ_UNDERLINE, -1,
                       EZ_HEIGHT, 30,
                       0 );

   EZ_AddWidgetCallBack( cancel_button, 
                         EZ_CALLBACK, buttons->cancel_callback, buttons, 1 );

   EZ_DisplayWidget( buttons->export_frame );
   EZ_SetGrab( buttons->export_frame );
   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));

   return;
}

/*
 * for export frame.
 */

void buttons_cancel_callback( EZ_Widget *widget, void *data )
{
    np_buttons_object *buttons;
    np_newsreader_object *newsreader;

    buttons = ( np_buttons_object *)data;
    newsreader = ( np_newsreader_object *)buttons->parent;

    EZ_DestroyWidget( buttons->export_frame );
    EZ_NormalCursor( newsreader->app_frame );

    buttons->decoded = 1;
    
    return;
}

/*
 * For decoding.
 */

void buttons_decode_selector_callback( EZ_Widget *widget, void *data )
{
    np_buttons_object *buttons;
    np_newsrc_object *newsrc;
    
    char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
      *end;
    int result, overwrite;
    

    buttons = ( np_buttons_object *)data;
    newsrc = ( np_newsrc_object *)buttons->newsrc_object;
    
    strcpy( second_buffer, EZ_GetEntryString( buttons->filter_entry ));
    if (( end = strrchr( second_buffer, '/' )) != NULL )
       *end = '\0';

    if ( chdir( second_buffer ))
    {
       newsrc->answer = -1;
       snprintf( buffer, LN_BUFFER_SIZE, "Could not change to directory:\n"
                 "%s", second_buffer ); 
       newsrc->confirm( newsrc, buffer, NP_DONE );
       while( newsrc->answer == -1 )
          EZ_WaitAndServiceNextEvent();
    }

    strcpy( buffer, EZ_GetFileSelectorSelection( buttons->file_selector ));

    /*
     * Decode to file.
     */

    overwrite = 1;

AGAIN:

    if ( UUSetOption( UUOPT_OVERWRITE, overwrite ^= 1, NULL ) != UURET_OK )
    {
       newsrc->answer = -1;
       newsrc->confirm( newsrc, "Could not set UUDeview option", NP_DONE );
       while( newsrc->answer == -1 )
          EZ_WaitAndServiceNextEvent();
       return;
    }

    if (( result = UUDecodeFile( buttons->item, buffer )) != UURET_OK )
    {
       if ( result == UURET_EXISTS )
       {
          newsrc->answer = -1;
          newsrc->confirm( newsrc, "Filename exists.\nOverwrite?", NP_YESNO );
          while( newsrc->answer == -1 )
             EZ_WaitAndServiceNextEvent();

          if ( !newsrc->answer )
             return;

          goto AGAIN;
       }

       strcpy( buffer, (( result == UURET_IOERR ) ?
               strerror( UUGetOption( UUOPT_ERRNO, NULL, NULL, 0 )) :
               UUstrerror( result )));
       newsrc->answer = -1;
       newsrc->confirm( newsrc, buffer, NP_DONE );
       while( newsrc->answer == -1 )
          EZ_WaitAndServiceNextEvent();
    }

    if ( result == UURET_OK )
    {
       snprintf( buffer, LN_BUFFER_SIZE, "%s\nsuccessfully decoded ",
             buttons->item->filename );
       newsrc->answer = -1;
       newsrc->confirm( newsrc, buffer, NP_DONE );
       while( newsrc->answer == -1 )
          EZ_WaitAndServiceNextEvent();
    }

    buttons->decoded = 1;
    EZ_DestroyWidget( buttons->export_frame );

    return;
}

/*
 * For export frame. 
 */

void buttons_file_selector_callback( EZ_Widget *widget, void *data )
{
    np_buttons_object *buttons;
    np_newsrc_object *newsrc;
    np_newsreader_object *newsreader;
    np_summary_object *summary;
    np_message_object *message;

    EZ_TreeNode *selected;
    unsigned int i;
    
    char *pointer, buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
      *end;

    FILE *file;
    int length;


    buttons = ( np_buttons_object *)data;
    newsrc = ( np_newsrc_object *)buttons->newsrc_object;
    newsreader = ( np_newsreader_object *)buttons->parent;
    summary = ( np_summary_object *)newsreader->summary_object;
    message = ( np_message_object *)newsreader->message_object;


    strcpy( second_buffer, EZ_GetEntryString( buttons->filter_entry ));
    if (( end = strrchr( second_buffer, '/' )) != NULL )
       *end = '\0';

    if ( chdir( second_buffer ))
    {
       newsrc->answer = -1;
       snprintf( buffer, LN_BUFFER_SIZE, "Could not change to directory:\n"
                 "%s", second_buffer ); 
       newsrc->confirm( newsrc, buffer, NP_DONE );
       while( newsrc->answer == -1 )
          EZ_WaitAndServiceNextEvent();
    }

    strcpy( buffer, EZ_GetFileSelectorSelection( buttons->file_selector ));

    if (( file = fopen( buffer, "w" )) == NULL )
    {
       newsrc->answer = -1;
       newsrc->confirm( newsrc, "Could not open filename", NP_DONE );
       while( newsrc->answer == -1 )
          EZ_WaitAndServiceNextEvent();
        return;
    }

    EZ_DestroyWidget( buttons->export_frame );

    /* Write header, converting \r\n into \n */

    pointer = message->message.header - 1;
    while( *( ++pointer ))
    {
        length = strcspn( pointer, "\n" );
        strncpy( buffer, pointer, length );
        buffer[ length - 1 ] = '\n';
        buffer[ length ] = '\0';

       if ( pointer[ 0 ] != '@' )
          fputs( buffer, file );
        pointer += length;
    }

    /* Write body, converting \r\n to \n */

    if ( buttons->is_article )
    {
        fputs( "\n", file );

        pointer = message->message.body - 1;
        while( *( ++pointer ))
        {
            length = strcspn( pointer, "\n" );
            strncpy( buffer, pointer, length );
            buffer[ length - 1 ] = '\n';
            buffer[ length ] = '\0';

            fputs( buffer, file );
            pointer += length;
        }
    }

    fclose( file );

    selected = EZ_GetListTreeWidgetSelection( summary->thread_tree );
    i = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

    newsrc->answer = -1;
    strncpy( buffer, summary->contents[ i ].subject, 35 );
    buffer[ 35 ] = '\0';
    strcat( buffer, "...\nsuccessfully exported" ); 
    newsrc->confirm( newsrc, buffer, NP_DONE );
    while( newsrc->answer == -1 )
        EZ_WaitAndServiceNextEvent();

    EZ_NormalCursor( newsreader->app_frame );

    return;
}

/*
 * Callback for arrow buttons.
 */

void buttons_navigation_callback( EZ_Widget *widget, void *data )
{
    np_buttons_object *buttons;
    np_tree_object *tree;
    np_summary_object *summary;
    np_newsreader_object *newsreader;

    EZ_TreeNode *selected;
    EZ_Item *item;

    enum{ NO, YES }found, was_server, not_root;
    long int group, temp, article, i, int_data, server_idx;


    buttons = ( np_buttons_object *)data;
    newsreader = ( np_newsreader_object *)buttons->parent;
    tree = ( np_tree_object *)newsreader->tree_object;
    summary = ( np_summary_object *)newsreader->summary_object;

    if ( !tree->groups )
        return;

    was_server = NO;
    not_root = YES;

    EZ_FreezeWidget( tree->tree );
    EZ_FreezeWidget( summary->thread_tree );

    /*
     * Which button?
     */

    int_data = EZ_GetWidgetIntData( widget );

    /*
     * Which node in thread tree is selected?
     */

    selected = EZ_GetListTreeWidgetSelection( tree->tree );

    if ( selected == NULL || selected == tree->root_node )
    {
       not_root = NO;

        if ( int_data < 3 )
            i = tree->groups - 1;
        else 
            i = 0;
    
        /*
         * If no group node is selected, or the root node is selected, then
         * select the very first, or very last group node, depending on the
         * direction the button pointed to by widget moves the selection.
         */

        EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ i ], 
                                     NULL );

        if (( selected = tree->group_nodes[ i ] ) == NULL )
        {
           EZ_UnFreezeWidget( tree->tree );
           EZ_UnFreezeWidget( summary->thread_tree );
           return;
        }
    }

    /*
     * If a server node is selected, select the first group node in the
     * server's subtree.
     */

    if ( *( char *)EZ_GetItemPtrData( item = EZ_TreeNodeGetItem( selected ))
         == 's' )
    {
       was_server = YES;
        temp = ( unsigned int)EZ_GetItemIntData( item );
        for( i = 0; i < tree->groups; ++i )
            if ( !strcmp( tree->server_list[ temp ].server,
                          tree->group_list[ i ].server ))
            {
                EZ_ListTreeWidgetSelectNode( tree->tree,
                                             tree->group_nodes[ i ], 
                                             NULL );

                selected = tree->group_nodes[ i ];
                break;
            }
    }

    /*
     * Get the currently-selected group and article's ordinal positions.
     */

    group = ( unsigned int)EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));
    if ( group >= tree->groups )
    {
       EZ_UnFreezeWidget( tree->tree );
       EZ_UnFreezeWidget( summary->thread_tree );
       return;
    }

    server_idx = tree->group_list[ group ].server_idx;

    if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
        != NULL )
        article = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));
    else
        article = -1;


    switch( int_data )
    {
        /* previous group */

    case 0:
        if ( group > 0 )
            EZ_ListTreeWidgetSelectNode( tree->tree, 
                                         tree->group_nodes[ --group ], 
                                         NULL );
        break;

        /* previous article */

    case 1:

        /* if no article is currently selected */

        if ( article < 0 )
        {
            if (( temp = summary->stats.total ))
            {
                while( --temp && summary->node_list[ temp ] == NULL );

                if ( summary->node_list[ temp ] != NULL )
                    EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                                 summary->node_list[ temp ], 
                                                 NULL );
            }
            break;
        }

        /* If there is a currently-selected article. */

        if ( article > 0 )
        {
            temp = article;
            while( --temp && summary->node_list[ temp ] == NULL );

            if ( summary->node_list[ temp ] != NULL )
                EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                             summary->node_list[ temp ], 
                                             NULL );
            break;
        }

        /*
         * If no previous article was found in this group, step into
         * previous groups.
         */

        if ( group > 0 )
        {
            found = NO;
            temp = group;

            while( --temp && !tree->group_list[ temp ].total );

            if ( tree->group_list[ temp ].total )
            {
                EZ_ListTreeWidgetSelectNode( tree->tree, 
                                             tree->group_nodes[ temp ],
                                             NULL );
                found = YES;
            }

            if ( found )
            {
                temp = summary->stats.total;
                while( summary->node_list[ --temp ] == NULL ); 

                EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                             summary->node_list[ temp ],
                                             NULL );
            }
        }

        break;

        /* previous unread article */

    case 2:
        if ( summary->stats.unread )
        {
            if ( article < 0 )
            {
                temp = summary->stats.total;
                while( !summary->contents[ --temp ].is_unread );

                if ( summary->node_state[ temp ] == NP_NOT_SHOWN ||
                     summary->node_list[ temp ] == NULL )
                {
                   unsigned int z = temp;

                   while( summary->node_state[ z ] == NP_NOT_SHOWN )
                      summary->node_state[ z-- ] = NP_SHOWN;

                   summary->update_tree( summary, summary->thread_tree );
                }

                EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                             summary->node_list[ temp ], 
                                             NULL );
                break;
            }

            temp = article;
            while( temp && !summary->contents[ --temp ].is_unread );

            if ( summary->contents[ temp ].is_unread )
            {
                if ( summary->node_state[ temp ] == NP_NOT_SHOWN ||
                     summary->node_list[ temp ] == NULL )
                {
                   unsigned int z = temp;

                   while( summary->node_state[ z ] == NP_NOT_SHOWN )
                      summary->node_state[ z-- ] = NP_SHOWN;

                   summary->update_tree( summary, summary->thread_tree );
                }

                EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                             summary->node_list[ temp ], 
                                             NULL );
                break;
            }
        }

        if ( !group )
            break;

        temp = group;
         
        while( temp && !tree->group_list[ --temp ].unread );

        if ( tree->group_list[ temp ].unread )
        {
           EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ temp ],
                                        NULL );

           temp = summary->stats.total;

           while( !summary->contents[ --temp ].is_unread );

           if ( summary->node_state[ temp ] == NP_NOT_SHOWN ||
                summary->node_list[ temp ] == NULL )
           {
              unsigned int z = temp;

              while( summary->node_state[ z ] == NP_NOT_SHOWN )
                 summary->node_state[ z-- ] = NP_SHOWN;

              summary->update_tree( summary, summary->thread_tree );
           }

           EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                        summary->node_list[ temp ], 
                                        NULL );
        }

        break;

        /* next unread article */

    case 3:
        if ( summary->stats.unread )
        {
            if ( article < 0 )
            {
                temp = -1;
                while( !summary->contents[ ++temp ].is_unread );

                if ( summary->node_state[ temp ] == NP_NOT_SHOWN ||
                     summary->node_list[ temp ] == NULL )
                {
                   unsigned int z = temp;

                   while( summary->node_state[ z ] == NP_NOT_SHOWN )
                      summary->node_state[ z-- ] = NP_SHOWN;

                   summary->update_tree( summary, summary->thread_tree );
                }

                EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                             summary->node_list[ temp ], 
                                             NULL );
                break;
            }

            temp = article;
            while( temp < summary->stats.total - 1 && 
                   !summary->contents[ ++temp ].is_unread );

            if ( summary->contents[ temp ].is_unread )
            {
               if ( summary->node_state[ temp ] == NP_NOT_SHOWN ||
                    summary->node_list[ temp ] == NULL )
               {
                  unsigned int z = temp;

                  while( summary->node_state[ z ] == NP_NOT_SHOWN )
                     summary->node_state[ z-- ] = NP_SHOWN;

                  summary->update_tree( summary, summary->thread_tree );
               }

                EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                             summary->node_list[ temp ],
                                             NULL );
                break;
            }

        }

        temp = group;
        while( temp < tree->groups - 1 && !tree->group_list[ ++temp ].unread );

        if ( tree->group_list[ temp ].unread )
        {
            EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ temp ],
                                         NULL );

            temp = -1;
            while( !summary->contents[ ++temp ].is_unread );

            if ( summary->node_state[ temp ] == NP_NOT_SHOWN ||
                 summary->node_list[ temp ] == NULL )
            {
               unsigned int z = temp;

               while( summary->node_state[ z ] == NP_NOT_SHOWN )
                  summary->node_state[ z-- ] = NP_SHOWN;

               summary->update_tree( summary, summary->thread_tree );
            }

            EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                         summary->node_list[ temp ], 
                                         NULL );
        }

        break;

        /* next article */

    case 4:

        /* If there is no currently-selected article */

        if ( article < 0 )
            if ( summary->stats.total )
            {
                temp = -1;
                while( summary->node_list[ ++temp ] == NULL );

                EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                             summary->node_list[ temp ], 
                                             NULL );
                break;
            }

        /* If there is a currently-selected article. */

        if ( summary->stats.total )
        {
            if ( article < summary->stats.total - 1 )
            {
                temp = article;
                while( temp < summary->stats.total - 1 &&
                       summary->node_list[ ++temp ] == NULL );

                if ( summary->node_list[ temp ] != NULL )
                {
                    EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                                 summary->node_list[ temp ],
                                                 NULL );
                    break;
                }
            }
        }

        /* if no node was found in the currently-selected group. */

        if ( group < tree->groups - 1 )
        {
            found = NO;
            temp = group;

            while( temp < tree->groups - 1 && 
                   !tree->group_list[ ++temp ].total );

            if ( tree->group_list[ temp ].total )
            {
                EZ_ListTreeWidgetSelectNode( tree->tree, 
                                             tree->group_nodes[ temp ], 
                                             NULL );
                found = YES;
            }

            if ( found )
            {
                temp = -1;
                while( summary->node_list[ ++temp ] == NULL );

                EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                             summary->node_list[ temp ],
                                             NULL );
            }
        }
        break;

        /* next group */

    case 5:
        if ( !was_server && not_root )
           ++group;

        if ( group < tree->groups )
            EZ_ListTreeWidgetSelectNode( tree->tree,
                                         tree->group_nodes[ group ], 
                                         NULL );
         break;

         /* previous server */

    case 6:
       if ( !server_idx )
       {
          EZ_ListTreeWidgetSelectNode( tree->tree, tree->root_node, NULL );
          break;
       }
                                       
         if ( was_server && server_idx > 0 )
            --server_idx;

         EZ_ListTreeWidgetSelectNode( tree->tree,
                                      tree->server_nodes[ server_idx ],
                                      NULL );
         break;

         /* next server */

    case 7:
         if ( not_root && ( server_idx < tree->servers - 1 ))
            ++server_idx;

         EZ_ListTreeWidgetSelectNode( tree->tree,
                                      tree->server_nodes[ server_idx ],
                                      NULL );
         break;

         /* previous non-empty group. */

    case 8:
         while( group > 0 && !tree->group_list[ --group ].total );

         EZ_ListTreeWidgetSelectNode( tree->tree,
                                      tree->group_nodes[ group ],
                                      NULL );
         break;

         /* next non-empty group. */

    case 9:
         if (( !not_root || was_server )
             && group == tree->server_list[ server_idx ].first
             && tree->group_list[ group ].total )
            break;

         while( group < tree->groups - 1 &&
                !tree->group_list[ ++group ].total );

         EZ_ListTreeWidgetSelectNode( tree->tree,
                                      tree->group_nodes[ group ],
                                      NULL );
         break;
   }
        
   EZ_UnFreezeWidget( tree->tree );
   EZ_UnFreezeWidget( summary->thread_tree );
   return;
}

/*
 * Callback for all help buttons on all frames.
 */

void buttons_help_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;

   EZ_Widget **frame, *help_text;

   char *helpfile, *title, buffer[ LN_BUFFER_SIZE ];
   int i;


   buttons = ( np_buttons_object *)data;
   newsreader = ( np_newsreader_object *)buttons->parent;

   switch( i = EZ_GetWidgetIntData( widget ))
   {
   case 0:
      if ( buttons->main_help_onscreen )
         return;

      title = "Main Help Window";
      frame = &buttons->main_help_frame;
      buttons->main_help_onscreen = 1;
      break;

   case 1:
      if ( buttons->config_help_onscreen )
         return;

      title = "Configuration Help";
      frame = &buttons->config_help_frame;
      buttons->config_help_onscreen = 1;
      break;

   case 2:
      if ( buttons->newsrc_help_onscreen )
         return;

      title = "Servers/Groups Help";
      frame = &buttons->newsrc_help_frame;
      buttons->newsrc_help_onscreen = 1;
      break;

   case 3:
      if ( buttons->virtual_help_onscreen )
         return;

      title = "Virtual Groups Help";
      frame = &buttons->virtual_help_frame;
      buttons->virtual_help_onscreen = 1;
      break;

   case 4:
      if ( buttons->folders_help_onscreen )
         return;

      title = "Persistent Folders Help";
      frame = &buttons->folders_help_frame;
      buttons->folders_help_onscreen = 1;
      break;

   case 5:
      if ( buttons->create_help_onscreen )
         return;

      title = "Create Article Help";
      frame = &buttons->create_help_frame;
      buttons->create_help_onscreen = 1;
      break;

   case 6:
      if ( buttons->inboxes_help_onscreen )
         return;

      title = "Inboxes Help";
      frame = &buttons->inboxes_help_frame;
      buttons->inboxes_help_onscreen = 1;
      break;
      
   case 7:
      if ( buttons->addresses_help_onscreen )
         return;

      title = "Addresses Help";
      frame = &buttons->addresses_help_frame;
      buttons->addresses_help_onscreen = 1;
      break;
   }

   *frame = EZ_CreateFrame( NULL, title );

   EZ_ConfigureWidget( *frame,
                       EZ_HEIGHT, 550,
                       EZ_WIDTH, 600,
                       EZ_IPADY, 10,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       0 );

   help_text = EZ_CreateTextWidget( *frame, 0, 1, 1 );

   EZ_SetScrollbarDiscreteSpeed( *frame, 10 );
   EZ_SetScrollbarDiscreteSpeed( *frame, 10 );

   EZ_ConfigureWidget( help_text,
                       EZ_FONT_NAME, newsreader->bold_font,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( *frame, "done", -1 ),
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_CLIENT_INT_DATA, i,
                       EZ_CALLBACK, buttons->help_done_callback, buttons,
                       0 );

   switch( i )
   {
   case 0:
      helpfile = "main.help";
      break;

   case 1:
      helpfile = "config.help";
      break;

   case 2:
      helpfile = "newsrc.help";
      break;

   case 3:
      helpfile = "virtual.help";
      break;

   case 4:
      helpfile = "folders.help";
      break;

   case 5:
      helpfile = "create.help";
      break;

   case 6:
      helpfile = "inboxes.help";
      break;
      
   case 7:
      helpfile = "addresses.help";
      break;
      
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", SHARE_PATH, helpfile );
   EZ_TextLoadAnnotatedFile( help_text, buffer );

   EZ_ReleaseGrab();
   EZ_DisplayWidget( *frame );
   EZ_SetGrab( *frame );
   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));

   return;
}

/*
 * Callback for the done button on all help frames.
 */

void buttons_help_done_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;

   EZ_Widget **frame;


   buttons = ( np_buttons_object *)data;
   newsreader = ( np_newsreader_object *)buttons->parent;

   switch( EZ_GetWidgetIntData( widget ))
   {
      case 0:
         frame = &buttons->main_help_frame;
         buttons->main_help_onscreen = 0;
         break;

      case 1:
         frame = &buttons->config_help_frame;
         buttons->config_help_onscreen = 0;
         break;

      case 2:
         frame = &buttons->newsrc_help_frame;
         buttons->newsrc_help_onscreen = 0;
         break;

      case 3:
         frame = &buttons->virtual_help_frame;
         buttons->virtual_help_onscreen = 0;
         break;

      case 4:
         frame = &buttons->folders_help_frame;
         buttons->folders_help_onscreen = 0;
         break;

      case 5:
         frame = &buttons->create_help_frame;
         buttons->create_help_onscreen = 0;
         break;

   case 6:
      frame = &buttons->inboxes_help_frame;
      buttons->inboxes_help_onscreen = 0;
      break;

   case 7:
      frame = &buttons->addresses_help_frame;
      buttons->addresses_help_onscreen = 0;
      break;
   }
         
   EZ_DestroyWidget( *frame );
   EZ_NormalCursor( newsreader->app_frame );

   return;
}

/*
 * Search server for missing parts of encoded binaries.
 */

int buttons_get_missing_parts( void *this, uulist *item, char *newsgroup )
{
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_update_object *update;
   np_newsrc_object *newsrc;
   np_tree_object *tree;

   regex_t regex;
   regmatch_t *matches;

   FILE *temp, *spool, *readfile;
   unsigned int i, result, lines, count, got = 1;
   char *home, small_buffer[ 10 ],
      buffer[ LN_BUFFER_SIZE ], temp_filename[ LN_BUFFER_SIZE ];
   enum{ NO, YES }xpat, found;


   buttons = ( np_buttons_object *)this;
   update = ( np_update_object *)buttons->update_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;

   /*
    * Ask nicely.
    */

   snprintf( buffer, LN_BUFFER_SIZE, "%s\nis missing one or more parts. "
             "May I connect\nto the server and attempt to find them?", 
             item->filename );
   newsrc->answer = -1;
   newsrc->confirm( newsrc, buffer, NP_YESNO );
   while( newsrc->answer == -1 )
      EZ_WaitAndServiceNextEvent();

   if ( !newsrc->answer )
      return -1;

   /*
    * Find server by searching for group.
    */

   for( i = 0; i < tree->groups; ++i )
      if ( !strcmp( tree->group_list[ i ].group, newsgroup ))
         break;

   if ( i == tree->groups )
   {
      snprintf( buffer, LN_BUFFER_SIZE, "%s\nis no longer in your group tree.\n"
                "I cannot tell what server to query.", newsgroup );
      newsrc->answer = -1;
      newsrc->confirm( newsrc, buffer, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      return -1;
   }
                
   /*
    * Open connection. Change to group.
    */

   if ( update->open_server( update, tree->group_list[ i ].server, i ))
      return -1;

   fprintf( update->stream, "group %s\r\n", newsgroup );
   fgets( buffer, LN_BUFFER_SIZE, update->stream );

   if ( strncmp( buffer, "211", 3 ))
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "Server responded to group command with:\n%s", buffer );
      newsrc->answer = -1;
      newsrc->confirm( newsrc, ln_error_message, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      return -1;
   }

   /*
    * Check for xpat support.
    */

   fputs( "help\r\n", update->stream );
   fgets( buffer, LN_BUFFER_SIZE, update->stream );

   if ( strncmp( buffer, "100", 3 ))
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "Server responded to help command with:\n%s", buffer );
      newsrc->answer = -1;
      newsrc->confirm( newsrc, ln_error_message, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      return -1;
   }

   xpat = NO;
   do
   {
      fgets( buffer, LN_BUFFER_SIZE, update->stream );
      if ( strstr( buffer, "xpat" ))
         xpat = YES;
   }
   while( strncmp( buffer, ".\r\n", 3 ));

   if ( !xpat )
   {
      snprintf( buffer, LN_BUFFER_SIZE, 
                "%s\ndoes not support the xpat extension", 
                tree->group_list[ i ].server );
      newsrc->answer = -1;
      newsrc->confirm( newsrc, buffer, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      return -1;
   }

   /*
    * Give xpat command, searching for occurences of item->filename.
    */

   fprintf( update->stream, "xpat Subject 0- *%s*\r\n", item->filename );
   fgets( buffer, LN_BUFFER_SIZE, update->stream );

   if ( strncmp( buffer, "221", 3 ))
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "Server responded to xpat command with:\n%s", buffer );
      newsrc->answer = -1;
      newsrc->confirm( newsrc, ln_error_message, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      return -1;
   }

   /*
    * Dump responses to temporary file.
    */

   snprintf( temp_filename, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", 
             home = getenv( "HOME" ));
   if (( temp = fopen( temp_filename, "w+" )) == NULL )
      fatal_error();
   
   count = 0;
   do
   {
      fgets( buffer, LN_BUFFER_SIZE, update->stream );
      fputs( buffer, temp );
      ++count;
   }
   while( strncmp( buffer, ".\r\n", 3 ));
   --count;

   fflush( temp );
   rewind( temp );

   /* 
    * Compile regular expression to parse out part number from responses,
    * assuming the convention of putting [part/total] in the Subject header.
    */

   if (( result = regcomp( &regex, "[\\[(]([0-9]+)/[0-9]+[])]", REG_EXTENDED )))

   {
      regerror( result, &regex, ln_error_message, LN_BUFFER_SIZE );
      newsreader->show_message( newsreader, buffer );
      fclose( temp );
      remove( temp_filename );
      return -1;
   }

   if (( matches = calloc( regex.re_nsub + 1, sizeof *matches )) == NULL )
      fatal_error();

   /*
    * Open spool and read file for appending.
    */

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", 
             home, newsgroup );
   if (( spool = fopen( buffer, "a" )) == NULL )
      fatal_error();

   strcat( buffer, ":read" );
   if (( readfile = fopen( buffer, "a" )) == NULL )
      fatal_error();

   found = NO;
   while( fgets( buffer, LN_BUFFER_SIZE, temp ) != NULL )
   {
      if ( buffer[ 0 ] == '.' )
         break;

      /*
       * Compare each response against compiled regular expression.
       */

      if (( result = regexec( &regex, buffer, regex.re_nsub + 1, matches, 0 )))
      {
         if ( result == REG_NOMATCH )
            continue;

         regerror( result, &regex, ln_error_message, LN_BUFFER_SIZE );
         newsreader->show_message( newsreader, buffer );
         fclose( temp );
         remove( temp_filename );
         fclose( spool );

         regfree( &regex );
         free( matches );
         return -1;
      }

      /*
       * Parse out the part number, if it exists, embedded in the response.
       */

      strncpy( small_buffer, buffer + matches[ 1 ].rm_so, 
               ( result = matches[ 1 ].rm_eo - matches[ 1 ].rm_so ));
      small_buffer[ result ] = '\0';

      /*
       * Compare this part number against the list of missing parts, or
       * the list of parts we have, if we're trying to find missing parts
       * of a message that does not conform completely to RFC2046, regarding
       * messages of with Content-Type: multipart/partial, and indicating
       * part numbers.
       */

      i = 0;
      if (( result = atoi( small_buffer )))
         if ( item->misparts != NULL )
            while( item->misparts[ i ] )
            {
               if ( result != item->misparts[ i++ ] )
                  continue;

               fprintf( update->stream, "article %s\r\n", 
                        strtok( buffer, " \t" ));

               fgets( buffer, LN_BUFFER_SIZE, update->stream );
               if ( strncmp( buffer, "220", 3 ))
                  break;

               found = YES;
               lines = 0;
               got = 1;

               do
               {
                  fgets( buffer, LN_BUFFER_SIZE, update->stream );
                  fputs( buffer, spool );
                  if ( !( ++lines % 20 ))
                     update->progress_callback( update, newsgroup, 
                                                (( lines > 100 ) ? lines : 0 ),
                                                1, got, count );
               }
               while( strncmp( buffer, ".\r\n", 3 ));

               ++got;
               update->progress_callback( update, newsgroup, 0, 1, got, 
                                          count );

               fputs( "u\n", readfile );
               break;
            }
         else
            if ( item->haveparts != NULL )
            {
               while( item->haveparts[ i ] )
                  if ( item->haveparts[ i++ ] == result )
                  {
                     --i;
                     break;
                  }
                  else
                     continue;

               if ( !( item->haveparts[ i ] ))
               {
                  fprintf( update->stream, "article %s\r\n", 
                           strtok( buffer, " \t" ));
                  fgets( buffer, LN_BUFFER_SIZE, update->stream );
                  if ( strncmp( buffer, "220", 3 ))
                     break;

                  lines = 0;
                  found = YES;
                  got = 1;

                  do
                  {
                     fgets( buffer, LN_BUFFER_SIZE, update->stream );
                     fputs( buffer, spool );
                     if ( !( ++lines % 100 ))
                        update->progress_callback( update, newsgroup, lines, 1,
                                                   got, count );
                  }
                  while( strncmp( buffer, ".\r\n", 3 ));

                  ++got;
                  update->progress_callback( update, newsgroup, 0 , 1, got, 
                                             count );
                  fputs( "u\n", readfile );
                  break;
               }
            }
   }

   /*
    * Remove the temporary file.
    */

   fclose( temp );
   remove( temp_filename );
   fclose( spool );
   fclose( readfile );

   /*
    * If we downloaded any articles, sort and thread the spoolfile.
    */

   if ( found )
   {
      if ( ln_sort_spool( newsgroup ) == -1 )
         lib_error();

      if ( ln_thread_spool( newsgroup ) == -1 )
         lib_error();
   }

   regfree( &regex );
   free( matches );

   return 0;
}

void buttons_message_decode_wrapper( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_message_object *message;
   np_summary_object *summary;

   buttons = ( np_buttons_object *)data;
   newsreader = ( np_newsreader_object *)buttons->parent;
   message = ( np_message_object *)newsreader->message_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   if ( EZ_GetListTreeWidgetSelection( summary->thread_tree ) == NULL )
      return;

   message->decode( message );

   newsreader->show_message( newsreader, NULL );

   return;
}

/*
 * This function decodes encoded binaries. It has two (2), count 'em
 * two, dreaded goto's, and so I hereby dedicate it to Niklaus Wirth.
 *
 * Here's how it's supposed to work: the first pass through the
 * UUDeview library function UULoadfile() is to check for encoded
 * binaries in the currently-selected article. If a binary is found,
 * but missing one or more parts, then we reset the UUDeview library,
 * which deletes the temporary file we dumped to the current article
 * into, and feed UULoadfile() the entire spoolfile of the
 * currently-selected newsgroup. If we still can't find missing parts,
 * we call UUSmerge(), which can find parts with slightly munged
 * names. If that fails, we call buttons->get_missing_parts() to use
 * the xpat NNTP extension to search for the missing articles on the
 * appropriate server in the appropriate newsgroup. If we get a
 * response, we download and append the articles to the
 * currently-selected newsgroup's spoolfile, and feed the spoolfile to
 * UULoadfile() again. If that fails, we try UUSmerge() one more time,
 * and then if we're still missing parts, we give up.
 *
 * Seems to work.
 */

void buttons_decode_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_tree_object *tree;
   np_newsrc_object *newsrc;
   np_update_object *update;
   np_message_object *message;
   np_newsreader_object *newsreader;

   EZ_TreeNode *selected;

   regex_t regex;
   regmatch_t *matches;

   unsigned int i, j, result, count;
   char buffer[ LN_BUFFER_SIZE ], small_buffer[ 10 ],
      *pointer, *group, *home, *filename = NULL, last_try = 0;
   FILE *file;
   enum{ NO, YES, ERROR }found;

   uulist *item;


   buttons = ( np_buttons_object *)data;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   update = ( np_update_object *)buttons->update_object;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   tree = ( np_tree_object *)newsreader->tree_object;
   message = ( np_message_object *)newsreader->message_object;

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         == NULL )
      return;

   i = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));
   if ( !summary->contents[ i ].is_article )
      return;

   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", 
             getenv( "HOME" ));
   if (( file = fopen( buffer, "w" )) == NULL )
      fatal_error();

   fprintf( file, "%s\r\n%s", 
            message->message.header, message->message.body );
   fclose( file );

   buttons->missing = 0;

   if (( result = regcomp( &regex, "[\\[(][0-9]+/([0-9]+)[])]", 
                           REG_EXTENDED )))
   {
      regerror( result, &regex, ln_error_message, LN_BUFFER_SIZE );
      newsreader->show_message( newsreader, ln_error_message );
      EZ_NormalCursor( newsreader->app_frame );
      UUCleanUp();
      return;
   }

   if (( matches = calloc( regex.re_nsub + 1, sizeof *matches )) == NULL )
      fatal_error();

   update->interrupt = 0;
   update->connect = 2;
   update->disable_interface( newsreader, 1 );

SECOND_PASS:

   /* Initialize library */

   if ( UUInitialize() != UURET_OK )
      fatal_error();

   /* Do not overwrite existing files. */

   if ( UUSetOption( UUOPT_OVERWRITE, 0, NULL ) != UURET_OK )
   {
      newsrc->answer = -1;
      newsrc->confirm( newsrc, "Could not set UUDeview option.", NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
      EZ_NormalCursor( newsreader->app_frame );
      UUCleanUp();
      update->disable_interface( newsreader, 0 );
      return;
   }

   /* Scan for encoded data. */

   if (( result = UULoadFile( buffer, NULL, !buttons->missing )) != UURET_OK )
   {
      strcpy( buffer, (( result == UURET_IOERR ) ?
                       strerror( UUGetOption( UUOPT_ERRNO, NULL, NULL, 0 )) :
                       UUstrerror( result )));
      newsrc->answer = -1;
      newsrc->confirm( newsrc, buffer, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      EZ_NormalCursor( newsreader->app_frame );
      UUCleanUp();
      update->disable_interface( newsreader, 0 );
      return;
   }

   /* decode each encoded file found. */

THIRD_PASS:

   found = NO;
   j = 0;
   while(( item = UUGetFileListItem( j++ )) != NULL )
   {
      if ( item->filename == NULL )
         continue;

      if ( buttons->missing && filename != NULL )
         if ( strcmp( item->filename, filename ))
         {
            free( filename );
            filename = NULL;
            continue;
         }

         /* 
          * UUDeview can report no missing parts, when there clearly are
          * judging by the Subject header of a message, if the message does
          * not contain proper RFC2046 part number information in it's
          * Content-Type header parameters. This hack below uses regular
          * expressions to try and detect these cases. It only works if the
          * article follows the convention of putting fractional part numbers
          * in brackets or parentheses, such as, (1/9), or [4/4], in the
          * Subject header.
          */

      if ( item->state & UUFILE_OK )
      {
         if (( result = regexec( &regex, 
                                 summary->contents[ i ].subject, 
                                 regex.re_nsub + 1, matches, 0 )))
            if ( result != REG_NOMATCH )
            {
               regerror( result, &regex, ln_error_message, LN_BUFFER_SIZE );
               newsreader->show_message( newsreader, ln_error_message );
               UUCleanUp();

               regfree( &regex );
               free( matches );
               update->disable_interface( newsreader, 0 );
               return;
            }

         if ( !result )
         {
            strncpy( small_buffer, 
                     summary->contents[ i ].subject + matches[ 1 ].rm_so,
                     result = matches[ 1 ].rm_eo - matches[ 1 ].rm_so );
            small_buffer[ result ] = '\0';
            
            count = 0;
            if ( !( item->haveparts[ 0 ] ))
               ++count;

            while( item->haveparts[ count ] )
               ++count;

            if ( atoi( small_buffer ) > count )
            {
               item->state |= UUFILE_MISPART;
               item->state ^= UUFILE_OK;
            }
         }
      }

      if (( item->state & UUFILE_MISPART ) || 
            ( item->state & UUFILE_NOEND ) ||
            ( item->state & UUFILE_NOBEGIN ))
      {
         switch( buttons->missing )
         {
            case 0:
               break;

               /* 
                * Attempt a smart merge of parts that may be related.
                */

            case 1:
            case 3:
               UUSmerge( 0 );
               UUSmerge( 1 );
               UUSmerge( 99 );
               buttons->missing++;
               goto THIRD_PASS;
               break;

               /*
                * Attempt to find missing parts on server.
                */

            case 2:
               if (( result
                        = buttons->get_missing_parts( buttons, item, group )))
               {
                  if ( result != -2 )
                     snprintf( buffer, LN_BUFFER_SIZE, 
                           "Could not find missing parts for\n"
                           "%s", 
                           item->filename );
                  else
                     strcpy( buffer, "Download Cancelled" );

                  newsrc->answer = -1;
                  newsrc->confirm( newsrc, buffer, NP_DONE );
                  while( newsrc->answer == -1 )
                     EZ_WaitAndServiceNextEvent();

                  found = ERROR;
               }
               else
               {
                  UUCleanUp();
                  buttons->missing++;

                  if (( selected = EZ_GetListTreeWidgetSelection( tree->tree ))
                        != NULL )
                  {
                     int k
                         = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

                     tree->update_lists( tree );
                     tree->set_tree( tree );

                     EZ_ListTreeWidgetSelectNode( tree->tree, 
                                                  tree->group_nodes[ k ],
                                                  NULL );
                  }

                  goto SECOND_PASS;
               }
               break;
         }

         /* 
          * If all five passes fail, give up.
          */

         if ( buttons->missing )
            break;

         /*
          * From here on down to the goto is executed only when
          * buttons->missing = 0. This code finds the name of the
          * originating newsgroup for the current article and gives the
          * coresponding spoolfile to uudeview again, so it can look for
          * missing parts.
          */

TRY_AND_TRY_AGAIN:

         if ( !strncmp( tree->group_list[ summary->group ].server,
                  "Virtual", 7 ) ||
               !strncmp( tree->group_list[ summary->group ].server,
                  "Folders", 7 ) ||
               !strncmp( tree->group_list[ summary->group ].server,
                  "Mailboxes", 9 ))
         {
            if (( group = buttons->extract_newsgroup( buttons, i )) == NULL )
            {
               strcpy( buffer, "Cannot determine actual newsgroup\n"
                     "for article in virtual group because\n"
                     "the articles has no Newsgroups: header" );
               newsrc->answer = -1;
               newsrc->confirm( newsrc, buffer, NP_DONE );
               while( newsrc->answer == -1 )
                  EZ_WaitAndServiceNextEvent();

               found = ERROR;
               break;
            }
         }
         else
            group = summary->group_name;

         if ( item != NULL && item->filename != NULL )
            filename = strdup( item->filename );

         last_try = 1;
         home = getenv( "HOME" );

         if ( !strncmp( group, "Follow-ups", 10 ))
            snprintf( buffer, LN_BUFFER_SIZE, 
                      "%s/.peruser_spool/%s-FOLLOW-UPS",
                      home, tree->group_list[ summary->group ].server );
         else
            if ( !strncmp( group, "Posted", 6 ))
               snprintf( buffer, LN_BUFFER_SIZE, 
                         "%s/.peruser_spool/%s-POSTED", 
                         home, tree->group_list[ summary->group ].server );
            else
               snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s",
                         home );
         UUCleanUp();
         buttons->missing = 1;
         goto SECOND_PASS;
      }
      else
          if ( !( item->state & UUFILE_OK ))
          {
              if ( item->state & UUFILE_NODATA )
                  pointer = "No encoded data found.";
              else
                  if ( item->state & UUFILE_ERROR )
                      pointer = "An error occurred (probably I/O).";
                  else 
                      if ( item->state & UUFILE_DECODED )
                          pointer = "File already decoded.";

              snprintf( buffer, LN_BUFFER_SIZE, "%s:\n%s", item->filename,
                        pointer );
              newsrc->confirm( newsrc, buffer, NP_DONE );
              while( newsrc->answer == -1 )
                  EZ_WaitAndServiceNextEvent();

              continue;
          }

      buttons->decoded = 0;
      buttons->item = item;
      buttons->export_callback( buttons->decode_button, buttons );
      while( !( buttons->decoded ))
          EZ_WaitAndServiceNextEvent();

      found = YES;
      continue;
   }
   
   if ( found == NO )
   {
      if ( !last_try )
         goto TRY_AND_TRY_AGAIN;

      newsrc->answer = -1;
      newsrc->confirm( newsrc, "No encoded data found.", NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
   }
   
   UUCleanUp();
   if ( filename != NULL )
      free( filename );

   newsreader->show_message( newsreader, NULL );
   EZ_NormalCursor( newsreader->app_frame );

   free( matches );
   regfree( &regex );
   update->disable_interface( newsreader, 0 );
   return;
}

void buttons_about_done_button_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;


   buttons = ( np_buttons_object *)data;

   if ( buttons->timer != NULL )
      EZ_CancelTimer( buttons->timer );

   buttons->position = 500;
   buttons->pixmap = buttons->jimmy_fish0;

   EZ_DestroyWidget( EZ_GetWidgetPtrData( widget ));

   return;
}

int buttons_check_for_running_netscape()
{
   FILE *ps_stream;
   char buffer[ LN_BUFFER_SIZE ];
   int launched;

   launched = 0;

   if ( ! ( ps_stream = popen( "ps", "r" )))
   {
      perror( "popen" );
      return 0;
   }

   while( fgets( buffer, LN_BUFFER_SIZE, ps_stream ) != NULL )
   {
      if ( strstr( buffer, "netscape" ) != NULL )
      {
         launched = 1;
         break;
      }
   }
   pclose( ps_stream );

   return launched;
}

void buttons_go_home_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;

   
   buttons = ( np_buttons_object *)data;

   if ( buttons->check_for_running_netscape() )
      system( "netscape -remote "
       "'openURL(http://www.wwdc.com/~jbailie/peruser-index.html)' -raise &" );
   else
      system( "netscape 'http://www.wwdc.com/~jbailie/peruser-index.html' &" );

   return;
}

void buttons_animate( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;

   static int frame = 0, direction = 0, limit;


   buttons = ( np_buttons_object *)data;

   switch( frame )
   {
      case 0:
         buttons->pixmap = (( direction ) ? buttons->jimmy_fish6 :
                            buttons->jimmy_fish0 );
         break;

      case 1:
         buttons->pixmap = (( direction ) ? buttons->jimmy_fish7 :
                            buttons->jimmy_fish1 );
         break;

      case 2:
         buttons->pixmap = (( direction ) ? buttons->jimmy_fish8 :
                            buttons->jimmy_fish2 );
         break;

      case 3:
         buttons->pixmap = (( direction ) ? buttons->jimmy_fish9 :
                             buttons->jimmy_fish3 );
         break;

      case 4:
         buttons->pixmap = (( direction ) ? buttons->jimmy_fish10 :
                            buttons->jimmy_fish4 );
         break;

      case 5:
         buttons->pixmap = (( direction ) ? buttons->jimmy_fish11 :
                            buttons->jimmy_fish5 );
         break;
   }

   if ( ++frame > 5 )
      frame = 0;

   if ( direction )
   { 
      limit = 1000;
      buttons->position += 8;
   }
   else
   {
      limit = -300;
      buttons->position -= 8;
   }

   if ( direction )
   {
      if ( buttons->position > limit )
         direction ^= 1;
   }
   else
      if ( buttons->position < limit )
         direction ^= 1;

   EZ_ConfigureWidget( buttons->picture,
                       EZ_X, buttons->position,
                       EZ_LABEL_PIXMAP, buttons->pixmap,
                       0 );

   return;
}

void buttons_about_callback( EZ_Widget *widget, void *data )
{
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;

   EZ_Widget *frame, *button_frame, *label, *done_button, *go_button;


   buttons = ( np_buttons_object *)data;
   newsreader = ( np_newsreader_object *)buttons->parent;

   frame = EZ_CreateFrame( NULL, NULL );

   EZ_ConfigureWidget( frame,
                       EZ_HEIGHT, 350,
                       EZ_WIDTH, 500,
                       EZ_BACKGROUND, "#0D0070",
                       EZ_FOREGROUND, "LightGray",
                       EZ_ORIENTATION, EZ_VERTICAL,
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( frame, NULL ),
                       EZ_LABEL_PIXMAP, buttons->title,
                       0 );

   label = EZ_CreateLabel( frame, 
                           "Version:  3.32\n"
                           "Released: Thursday, October 22, 1998\n"
                           "Author:   James Bailie <jbailie@wwdc.com>" );

   EZ_ConfigureWidget( label,
                       EZ_TEXT_LINE_LENGTH, 100,
                       EZ_FOREGROUND, "Gray80",
                       EZ_Y, 90,
                       EZ_FONT_NAME, newsreader->fixed_font,
                       0 );

   buttons->picture = EZ_CreateFreeLabel( frame, NULL );

   EZ_ConfigureWidget( buttons->picture,
                       EZ_Y, 150,
                       0 );

   button_frame = EZ_CreateFrame( frame, NULL );

   EZ_ConfigureWidget( button_frame,
                       EZ_Y, 300,
                       EZ_IPADX, 20,
                       EZ_HEIGHT, 35,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   go_button = EZ_CreateButton( button_frame, "goto website", 0 );

   EZ_ConfigureWidget( go_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_BACKGROUND, "LightGray",
                       EZ_CALLBACK, buttons->go_home_callback, buttons,
                       EZ_WIDTH, 150,
                       EZ_HEIGHT, 35,
                       0 );

   done_button = EZ_CreateButton( button_frame, "done", 0 );

   EZ_ConfigureWidget( done_button,
                       EZ_CLIENT_PTR_DATA, frame,
                       EZ_BACKGROUND, "LightGray",
                       EZ_CALLBACK, buttons->about_done_button_callback, 
                       buttons,
                       EZ_WIDTH, 75,
                       EZ_HEIGHT, 35,
                       0 );

   buttons->timer = EZ_CreateTimer( 0, 60000, -1, buttons->animate, 
                                    buttons, 0 );
   EZ_DisplayWidget( frame );

   return;
}

void buttons_selectively_disable_interface( void *this )
{
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_newsreader_object *newsreader;
   np_update_object *update;

   EZ_TreeNode *selected;
   EZ_Item *item;
   
   unsigned int i;

   enum { UPDATE, ORIGINAL, REQUEST, FOLLOW_UP, REPLY, FORWARD,
          SUPERSEDE, CANCEL, EDIT_MENU, MARK, EXPIRE, PACK,
          DECODE, SUMMARY, EXPORT, MAIL, SPLIT, EDIT } state;

   static char states[ 18 ] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                                1, 1, 1, 1, 1, 1, 1 };
   char folder;
   
   /*
    * Shuts the compiler up.
    */

   state = UPDATE;
   
   buttons = ( np_buttons_object *)this;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   update = ( np_update_object *)buttons->update_object;

   selected = EZ_GetListTreeWidgetSelection( tree->tree );
   if (( item = EZ_TreeNodeGetItem( selected )) != tree->root_node )
      i = EZ_GetItemIntData( item );
   
   folder = 0;
   
   if ( selected == NULL )
   {
      if ( states[ UPDATE ] )
      {
         EZ_DisableWidget( buttons->update_button );
         states[ UPDATE ] ^= 1;
      }
      
      if ( states[ REQUEST ] )
      {
         EZ_DisableWidget( buttons->request_button );
         states[ REQUEST ] ^= 1;
      }
   
      if ( states[ ORIGINAL ] )
      {
         EZ_DisableWidget( buttons->original_button );
         states[ ORIGINAL ] ^= 1;
      }
      
      if ( states[ FOLLOW_UP ] )
      {
         EZ_DisableWidget( buttons->follow_up_button );
         states[ FOLLOW_UP ] ^= 1;
      }
         
      if ( states[ REPLY ] )
      {
         EZ_DisableWidget( buttons->reply_button );
         states[ REPLY ]  ^= 1;
      }
      
      if ( states[ FORWARD ] )
      {
         EZ_DisableWidget( buttons->forward_button );
         states[ FORWARD ] ^= 1;
      }
      
      if ( states[ SUPERSEDE ] )
      {
         EZ_DisableWidget( buttons->supersede_button );
         states[ SUPERSEDE ] ^= 1;
      }
      
      if ( states[ CANCEL ] )
      {
         EZ_DisableWidget( buttons->cancel_button );
         states[ CANCEL ] ^= 1;
      }
      
      if ( states[ EDIT_MENU ] )
      {
         EZ_DisableWidget( buttons->edit_menu_button );
         states[ EDIT_MENU ] ^= 1;
      }
      
      if ( states[ MARK ] )
      {
         EZ_DisableWidget( buttons->mark_button );
         states[ MARK ] ^= 1;
      }
      
      if ( states[ EXPIRE ] )
      {
         EZ_DisableWidget( buttons->expire_button );
         states[ EXPIRE ] ^= 1;
      }
      
      if ( states[ PACK ] )
      {
         EZ_DisableWidget( buttons->pack_button );
         states[ PACK ] ^= 1;
      }
      
      if ( states[ DECODE ] )
      {
         EZ_DisableWidget( buttons->decode_button );
         states[ DECODE ] ^= 1;
      }
      
      if ( states[ SUMMARY ] )
      {
         EZ_DisableWidget( buttons->summary_button );
         states[ SUMMARY ] ^= 1;
      }
      
      if ( states[ EXPORT ] )
      {
         EZ_DisableWidget( buttons->export_button );
         states[ EXPORT ] ^= 1;
      }
   
      if ( !states[ MAIL ] )
      {
         EZ_EnableWidget( buttons->mail_button );
         states[ MAIL ] ^= 1;
      }
      
      if ( !states[ SPLIT ] )
      {
         EZ_EnableWidget( buttons->split_message_button );
         states[ SPLIT ] ^= 1;
      }
      
      if ( !states[ EDIT ] )
      {
         EZ_EnableWidget( buttons->edit_button );
         states[ EDIT ] ^= 1;
      }
   }
   else
      if ( selected == tree->root_node ||
           *( char *)EZ_GetItemPtrData( item ) == 's' )
      {
         if ( states[ REQUEST ] )
         {
            EZ_DisableWidget( buttons->request_button );
            states[ REQUEST ] ^= 1;
         }
         
         if ( states[ ORIGINAL ] )
         {
            EZ_DisableWidget( buttons->original_button );
            states[ ORIGINAL ] ^= 1;
         }
         
         if ( states[ FOLLOW_UP ] )
         {
            EZ_DisableWidget( buttons->follow_up_button );
            states[ FOLLOW_UP ] ^= 1;
         }
         
         if ( states[ REPLY ] )
         {
            EZ_DisableWidget( buttons->reply_button );
            states[ REPLY ] ^= 1;
         }
         
         if ( states[ FORWARD ] )
         {
            EZ_DisableWidget( buttons->forward_button );
            states[ FORWARD ] ^= 1;
         }
         
         if ( states[ SUPERSEDE ] )
         {
            EZ_DisableWidget( buttons->supersede_button );
            states[ SUPERSEDE ] ^= 1;
         }
         
         if ( states[ CANCEL ] )
         {
            EZ_DisableWidget( buttons->cancel_button );
            states[ CANCEL ] ^= 1;
         }
            
         if ( states[ EDIT_MENU ] )
         {
            EZ_DisableWidget( buttons->edit_menu_button );
            states[ EDIT_MENU ] ^= 1;
         }
         
         if ( states[ DECODE ] )
         {
            EZ_DisableWidget( buttons->decode_button );
            states[ DECODE ] ^= 1;
         }
         
         if ( states[ SUMMARY ] )
         {
            EZ_DisableWidget( buttons->summary_button );
            states[ SUMMARY ] ^= 1;
         }
         
         if ( states[ EXPORT ] )
         {
            EZ_DisableWidget( buttons->export_button );
            states[ EXPORT ] ^= 1;
         }
         
         if ( states[ SPLIT ] )
         {
            EZ_DisableWidget( buttons->split_message_button );
            states[ SPLIT ] ^= 1;
         }
            
         if ( !strncmp( tree->server_list[ i ].server, "Folders", 7 ))
         {
            if ( states[ UPDATE ] )
            {
               EZ_DisableWidget( buttons->update_button );
               states[ UPDATE ] ^= 1;
            }
            
            if ( states[ MARK ] )
            {
               EZ_DisableWidget( buttons->mark_button );
               states[ MARK ] ^= 1;
            }

            if ( states[ PACK ] )
            {
               EZ_DisableWidget( buttons->pack_button );
               states[ PACK ] ^= 1;
            }

            if ( states[ EXPIRE ] )
            {
               EZ_DisableWidget( buttons->expire_button );
               states[ EXPIRE ] ^= 1;
            }
         }
         else
         {
            if ( !states[ UPDATE ] )
            {
               EZ_EnableWidget( buttons->update_button );
               states[ UPDATE ] ^= 1;
            }
         
            if ( !states[ MARK ] )
            {
               EZ_EnableWidget( buttons->mark_button );
               states[ MARK ] ^= 1;
            }

            if ( !states[ PACK ] )
            {
               EZ_EnableWidget( buttons->pack_button );
               states[ PACK ] ^= 1;
            }

            if ( !states[ EXPIRE ] )
            {
               EZ_EnableWidget( buttons->expire_button );
               states[ EXPIRE ] ^= 1;
            }
         }
         
         if ( !states[ MAIL ] )
         {
            EZ_EnableWidget( buttons->mail_button );
            states[ MAIL ] ^= 1;
         }
         
         if ( !states[ EDIT ] )
         {
            EZ_EnableWidget( buttons->edit_button );
            states[ EDIT ] ^= 1;
         }
      }
      else
         if ( !strncmp( tree->group_list[ i ].group, "Follow-ups", 11 ))
         {
            if ( states[ REQUEST ] )
            {
               EZ_DisableWidget( buttons->request_button );
               states[ REQUEST ] ^= 1;
            }
            
            if ( states[ ORIGINAL ] )
            {
               EZ_DisableWidget( buttons->original_button );
               states[ ORIGINAL ] ^= 1;
            }
            
            if ( states[ FOLLOW_UP] )
            {
               EZ_DisableWidget( buttons->follow_up_button );
               states[ FOLLOW_UP ] ^= 1;
            }
            
            if ( states[ REPLY ] )
            {
               EZ_DisableWidget( buttons->reply_button );
               states[ REPLY ] ^= 1;
            }
            
            if ( !states[ FORWARD ] )
            {
               EZ_EnableWidget( buttons->forward_button );
               states[ FORWARD ] ^= 1;
            }
            
            if ( states[ SUPERSEDE ] )
            {
               EZ_DisableWidget( buttons->supersede_button );
               states[ SUPERSEDE ] ^= 1;
            }
            
            if ( states[ CANCEL ] )
            {
               EZ_DisableWidget( buttons->cancel_button );
               states[ CANCEL ] ^= 1;
            }
            
            if ( states[ MARK ] )
            {
               EZ_DisableWidget( buttons->mark_button );
               states[ MARK ] ^= 1;
            }
            
            if ( states[ PACK ] )
            {
               EZ_DisableWidget( buttons->pack_button );
               states[ PACK ] ^= 1;
            }
            
            if ( states[ EXPIRE ] )
            {
               EZ_DisableWidget( buttons->expire_button );
               states[ EXPIRE ] ^= 1;
            }
            
            if ( !states[ UPDATE ] )
            {
               EZ_EnableWidget( buttons->update_button );
               states[ UPDATE ] ^= 1;
            }
               
            if ( !states[ EDIT_MENU ] )
            {
               EZ_EnableWidget( buttons->edit_menu_button );
               states[ EDIT_MENU ] ^= 1;
            }
            
            if ( !states[ DECODE ] )
            {
               EZ_EnableWidget( buttons->decode_button );
               states[ DECODE ] ^= 1;
            }
            
            if ( !states[ SUMMARY ] )
            {
               EZ_EnableWidget( buttons->summary_button );
               states[ SUMMARY ] ^= 1;
            }
            
            if ( !states[ EXPORT ] )
            {
               EZ_EnableWidget( buttons->export_button );
               states[ EXPORT ] ^= 1;
            }
   
            if ( !states[ MAIL ] )
            {
               EZ_EnableWidget( buttons->mail_button );
               states[ MAIL ] ^= 1;
            }
            
            if ( !states[ SPLIT ] )
            {
               EZ_EnableWidget( buttons->split_message_button );
               states[ SPLIT ] ^= 1;
            }
            
            if ( !states[ EDIT ] )
            {
               EZ_EnableWidget( buttons->edit_button );
               states[ EDIT ] ^= 1;
            }
         }
         else
            if ( !strncmp( tree->group_list[ i ].group, "Posted", 6 ))
            {
               if ( states[ UPDATE ] )
               {
                  EZ_DisableWidget( buttons->update_button );
                  states[ UPDATE ] ^= 1;
               }
               
               if ( states[ REQUEST ] )
               {
                  EZ_DisableWidget( buttons->request_button );
                  states[ REQUEST ] ^= 1;
               }
               
               if ( states[ ORIGINAL ] )
               {
                  EZ_DisableWidget( buttons->original_button );
                  states[ ORIGINAL ] ^= 1;
               }
               
               if ( states[ FOLLOW_UP ] )
               {
                  EZ_DisableWidget( buttons->follow_up_button );
                  states[ FOLLOW_UP ] ^= 1;
               }
               
               if ( states[ REPLY ] )
               {
                  EZ_DisableWidget( buttons->reply_button );
                  states[ REPLY ] ^= 1;
               }
               
               if ( !states[ FORWARD ] )
               {
                  EZ_EnableWidget( buttons->forward_button );
                  states[ FORWARD ] ^= 1;
               }
               
               if ( states[ MAIL ] )
               {
                  EZ_DisableWidget( buttons->mail_button );
                  states[ MAIL ] ^= 1;
               }
               
               if ( !states[ EDIT_MENU ] )
               {
                  EZ_EnableWidget( buttons->edit_menu_button );
                  states[ EDIT_MENU ] ^= 1;
               }
                  
               if ( states[ EDIT ] )
               {
                  EZ_DisableWidget( buttons->edit_button );
                  states[ EDIT ] ^= 1;
               }
               
               if ( states[ SPLIT ] )
               {
                  EZ_DisableWidget( buttons->split_message_button );
                  states[ SPLIT ] ^= 1;
               }
               
               if ( states[ MARK ] )
               {
                  EZ_DisableWidget( buttons->mark_button );
                  states[ MARK ] ^= 1;
               }
               
               if ( states[ PACK ] )
               {
                  EZ_DisableWidget( buttons->pack_button );
                  states[ PACK ] ^= 1;
               }
               
               if ( states[ EXPIRE ] )
               {
                  EZ_DisableWidget( buttons->expire_button );
                  states[ EXPIRE ] ^= 1;
               }
               
               if ( !states[ SUPERSEDE ] )
               {
                  EZ_EnableWidget( buttons->supersede_button );
                  states[ SUPERSEDE ] ^= 1;
               }
               
               if ( !states[ SUMMARY ] )
               {
                  EZ_EnableWidget( buttons->summary_button );
                  states[ SUMMARY ] ^= 1;
               }
               
               if ( !states[ EXPORT ] )
               {
                  EZ_EnableWidget( buttons->export_button );
                  states[ EXPORT ] ^= 1;
               }
               
               if ( !states[ DECODE ] )
               {
                  EZ_EnableWidget( buttons->decode_button );
                  states[ DECODE ] ^= 1;
               }
               
               if ( !states[ CANCEL ] )
               {
                  EZ_EnableWidget( buttons->cancel_button );
                  states[ CANCEL ] ^= 1;
               }
            }
            else
               if (( !strncmp( tree->group_list[ i ].server, "Mailboxes", 9 )
                     && strncmp( tree->group_list[ i ].group, "::Outbox" , 8 ))
                   || !strncmp( tree->group_list[ i ].server, "Folders", 7 ))
               {
                  if ( !strncmp( tree->group_list[ i ].server, "Folders", 7 ))
                  {
                     folder = 1;
                     if ( states[ UPDATE ] )
                     {
                        EZ_DisableWidget( buttons->update_button );
                        states[ UPDATE ] ^= 1;
                     }
                  }
                  else
                     if ( !states[ UPDATE ] )
                     {
                        EZ_EnableWidget( buttons->update_button );
                        states[ UPDATE ] ^= 1;
                     }
                  
                  if ( states[ REQUEST ] )
                  {
                     EZ_DisableWidget( buttons->request_button );
                     states[ REQUEST ] ^= 1;
                  }
                  
                  if ( states[ ORIGINAL ] )
                  {
                     EZ_DisableWidget( buttons->original_button );
                     states[ ORIGINAL ] ^= 1;
                  }

                  if ( states[ FOLLOW_UP ] )
                  {
                     EZ_DisableWidget( buttons->follow_up_button );
                     states[ FOLLOW_UP ] ^= 1;
                  }
                  
                  if ( states[ CANCEL ] )
                  {
                     EZ_DisableWidget( buttons->cancel_button );
                     states[ CANCEL ] ^= 1;
                  }
                  
                  if ( states[ SUPERSEDE ] )
                  {
                     EZ_DisableWidget( buttons->supersede_button );
                     states[ SUPERSEDE ] ^= 1;
                  }
                  
                  if ( !states[ EDIT_MENU ] )
                  {
                     EZ_EnableWidget( buttons->edit_menu_button );
                     states[ EDIT_MENU ] ^= 1;
                  }
                  
                  if ( states[ EDIT ] )
                  {
                     EZ_DisableWidget( buttons->edit_button );
                     states[ EDIT ] ^= 1;
                  }
                  
                  if ( !states[ FORWARD ] )
                  {
                     EZ_EnableWidget( buttons->forward_button );
                     states[ FORWARD ] ^= 1;
                  }
                  
                  if ( states[ SPLIT ] )
                  {
                     EZ_DisableWidget( buttons->split_message_button );
                     states[ SPLIT ] ^= 1;
                  }
                  
                  if ( !states[ MAIL ] )
                  {
                     EZ_EnableWidget( buttons->mail_button );
                     states[ MAIL ] ^= 1;
                  }
                  
                  if ( !states[ SUMMARY ] )
                  {
                     EZ_EnableWidget( buttons->summary_button );
                     states[ SUMMARY ] ^= 1;
                  }

                  if ( strncmp( tree->group_list[ i ].group, "::Sent-Mail",
                                11 ))
                  {
                     if ( !states[ REPLY ] )
                     {
                        EZ_EnableWidget( buttons->reply_button );
                        states[ REPLY ] ^= 1;
                     }

                     if ( folder )
                     {
                        if ( states[ MARK ] )
                        {
                           EZ_DisableWidget( buttons->mark_button );
                           states[ MARK ] ^= 1;
                        }

                        if ( states[ PACK ] )
                        {
                           EZ_DisableWidget( buttons->pack_button );
                           states[ PACK ] ^= 1;
                        }

                        if ( states[ EXPIRE ] )
                        {
                           EZ_DisableWidget( buttons->expire_button );
                           states[ EXPIRE ] ^= 1;
                        }
                     }
                     else
                     {
                        if ( !states[ MARK ] )
                        {
                           EZ_EnableWidget( buttons->mark_button );
                           states[ MARK ] ^= 1;
                        }

                        if ( !states[ EXPIRE ] )
                        {
                           EZ_EnableWidget( buttons->expire_button );
                           states[ EXPIRE ] ^= 1;
                        }
                  
                        if ( !states[ PACK ] )
                        {
                           EZ_EnableWidget( buttons->pack_button );
                           states[ PACK ] ^= 1;
                        }
                     }
                  }
                  else
                  {
                     if ( states[ UPDATE ] )
                     {
                        EZ_DisableWidget( buttons->update_button );
                        states[ UPDATE ] ^= 1;
                     }
                     
                     if ( states[ REPLY ] )
                     {
                        EZ_DisableWidget( buttons->reply_button );
                        states[ REPLY ] ^= 1;
                     }
                     
                     if ( states[ MARK ] )
                     {
                        EZ_DisableWidget( buttons->mark_button );
                        states[ MARK ] ^= 1;
                     }

                     if ( states[ EXPIRE ] )
                     {
                        EZ_DisableWidget( buttons->expire_button );
                        states[ EXPIRE ] ^= 1;
                     }

                     if ( states[ PACK ] )
                     {
                        EZ_DisableWidget( buttons->pack_button );
                        states[ PACK ] ^= 1;
                     }
                  }

                  if ( !states[ DECODE ] )
                  {
                     EZ_EnableWidget( buttons->decode_button );
                     states[ DECODE ] ^= 1;
                  }
                  
                  if ( !states[ EXPORT ] )
                  {
                     EZ_EnableWidget( buttons->export_button );
                     states[ EXPORT ] ^= 1;
                  }
               }
               else   
                  if ( !strncmp( tree->group_list[ i ].group, "::Outbox", 8 ))
                  {
                     if ( !states[ SPLIT ] )
                     {
                        EZ_EnableWidget( buttons->split_message_button );
                        states[ SPLIT ] ^= 1;
                     }
                     
                     if ( states[ REQUEST ] )
                     {
                        EZ_DisableWidget( buttons->request_button );
                        states[ REQUEST ] ^= 1;
                     }
                     
                     if ( states[ ORIGINAL ] )
                     {
                        EZ_DisableWidget( buttons->original_button );
                        states[ ORIGINAL ] ^= 1;
                     }
                     
                     if ( states[ FOLLOW_UP ] )
                     {
                        EZ_DisableWidget( buttons->follow_up_button );
                        states[ FOLLOW_UP ] ^= 1;
                     }
                     
                     if ( states[ REPLY ] )
                     {
                        EZ_DisableWidget( buttons->reply_button );
                        states[ REPLY ] ^= 1;
                     }
                     
                     if ( states[ FORWARD ] )
                     {
                        EZ_DisableWidget( buttons->forward_button );
                        states[ FORWARD ] ^= 1;
                     }
                     
                     if ( states[ CANCEL ] )
                     {
                        EZ_DisableWidget( buttons->cancel_button );
                        states[ CANCEL ] ^= 1;
                     }

                     if ( states[ SUPERSEDE ] )
                     {
                        EZ_DisableWidget( buttons->supersede_button );
                        states[ SUPERSEDE ] ^= 1;
                     }
                     
                     if ( !states[ EDIT ] )
                     {
                        EZ_EnableWidget( buttons->edit_button );
                        states[ EDIT ] ^= 1;
                     }
                     
                     if ( !states[ SPLIT ] )
                     {
                        EZ_EnableWidget( buttons->split_message_button );
                        states[ SPLIT ] ^= 1;
                     }
                     
                     if ( !states[ EDIT_MENU ] )
                     {
                        EZ_EnableWidget( buttons->edit_menu_button );
                        states[ EDIT_MENU ] ^= 1;
                     }
                     
                     if ( states[ MARK ] )
                     {
                        EZ_DisableWidget( buttons->mark_button );
                        states[ MARK ] ^= 1;
                     }
                     
                     if ( states[ EXPIRE ] )
                     {
                        EZ_DisableWidget( buttons->expire_button );
                        states[ EXPIRE ] ^= 1;
                     }
                     
                     if ( states[ PACK ] )
                     {
                        EZ_DisableWidget( buttons->pack_button );
                        states[ PACK ] ^= 1;
                     }
                     
                     if ( !states[ DECODE ] )
                     {
                        EZ_EnableWidget( buttons->decode_button );
                        states[ DECODE ] ^= 1;
                     }
                     
                     if ( !states[ SUMMARY ] )
                     {
                        EZ_EnableWidget( buttons->summary_button );
                        states[ SUMMARY ] ^= 1;
                     }
                     
                     if ( !states[ EXPORT ] )
                     {
                        EZ_EnableWidget( buttons->export_button );
                        states[ EXPORT ] ^= 1;
                     }
                     
                     if ( !states[ MAIL ] )
                     {
                        EZ_EnableWidget( buttons->mail_button );
                        states[ MAIL ] ^= 1;
                     }
                     
                     if ( !states[ UPDATE ] )
                     {
                        EZ_EnableWidget( buttons->update_button );
                        states[ UPDATE ] ^= 1;
                     }
                  }
                  else
                  {
                     if ( !states[ UPDATE ] )
                     {
                        EZ_EnableWidget( buttons->update_button );
                        states[ UPDATE ] ^= 1;
                     }
                     
                     if ( !states[ ORIGINAL ] )
                     {
                        EZ_EnableWidget( buttons->original_button );
                        states[ ORIGINAL ] ^= 1;
                     }
                     
                     if ( !states[ REQUEST ] )
                     {
                        EZ_EnableWidget( buttons->request_button );
                        states[ REQUEST ] ^= 1;
                     }
                     
                     if ( !states[ FOLLOW_UP ] )
                     {
                        EZ_EnableWidget( buttons->follow_up_button );
                        states[ FOLLOW_UP ] ^= 1;
                     }
                     
                     if ( !states[ REPLY ] )
                     {
                        EZ_EnableWidget( buttons->reply_button );
                        states[ REPLY ] ^= 1;
                     }
                     
                     if ( !states[ FORWARD ] )
                     {
                        EZ_EnableWidget( buttons->forward_button );
                        states[ FORWARD ] ^= 1;
                     }
                     
                     if ( states[ SUPERSEDE ] )
                     {
                        EZ_DisableWidget( buttons->supersede_button );
                        states[ SUPERSEDE ] ^=1;
                     }
                     
                     if ( states[ CANCEL ] )
                     {
                        EZ_DisableWidget( buttons->cancel_button );
                        states[ CANCEL ] ^= 1;
                     }
                     
                     if ( states[ EDIT_MENU ] )
                     {
                        EZ_DisableWidget( buttons->edit_menu_button );
                        states[ EDIT_MENU ] ^= 1;
                     }
                     
                     if ( !states[ MARK ] )
                     {
                        EZ_EnableWidget( buttons->mark_button );
                        states[ MARK ] ^= 1;
                     }
                     
                     if ( !states[ EXPIRE ] )
                     {
                        EZ_EnableWidget( buttons->expire_button );
                        states[ EXPIRE ] ^= 1;
                     }
                     
                     if ( !states[ PACK ] )
                     {
                        EZ_EnableWidget( buttons->pack_button );
                        states[ PACK ] ^= 1;
                     }
                     
                     if ( !states[ DECODE ] )
                     {
                        EZ_EnableWidget( buttons->decode_button );
                        states[ DECODE ] ^= 1;
                     }
                     
                     if ( !states[ SUMMARY ] )
                     {
                        EZ_EnableWidget( buttons->summary_button );
                        states[ SUMMARY ] ^= 1;
                     }
                     
                     if ( !states[ EXPORT ] )
                     {
                        EZ_EnableWidget( buttons->export_button );
                        states[ EXPORT ] ^= 1;
                     }
                     
                     if ( !states[ MAIL ] )
                     {
                        EZ_EnableWidget( buttons->mail_button );
                        states[ MAIL ] ^= 1;
                     }
                     
                     if ( states[ SPLIT ] )
                     {
                        EZ_DisableWidget( buttons->split_message_button );
                        states[ SPLIT ] ^= 1;
                     }
                     
                     if ( states[ EDIT ] )
                     {
                        EZ_DisableWidget( buttons->edit_button );
                        states[ EDIT ] ^= 1;
                     }
                  }
   
   return;
}
