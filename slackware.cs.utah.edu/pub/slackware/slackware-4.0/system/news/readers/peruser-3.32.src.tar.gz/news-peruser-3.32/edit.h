/*
 * Prototypes.
 */

void update_init( void *parent );
void update_callback( EZ_Widget *widget, void *data );
void update_show_message( void *newsreader_object, np_action action,
                          char *server );
void update_do_group( void *this, void *summary_object, void *tree_object,
                      np_action action,
                      unsigned int i, char *elapsed_time,
                      char *server, char *group );
void update_expire_group( np_tree_object *tree,  
                          np_summary_object *summary,
                          unsigned int i,
                          char folder,
                          char *elapsed_time );
void update_update_group( void *this, void *tree_object, unsigned int group,
                          char *server );
void update_update_folder( void *this );
void update_update_newsgroup( void *this );
void update_ask_what ( void *this, char *server );
int update_open_server( void *this, char *server, unsigned int j );
int update_authenticating( void *this, unsigned int j, char *user, char *pass );
void update_iterate( void *this, void *summary_object, void *tree_object,
                     np_action action, int i, unsigned int j,
                     char *elapsed_time );
void update_radio_callback( EZ_Widget *widget, void *data );
void update_grey_slider( EZ_Widget *widget, void *data );
void update_ungrey_slider( EZ_Widget *widget, void *data );
int update_progress_callback( void *data, char *group, unsigned int lines,
                              unsigned int begin,
                              unsigned int current, unsigned int end );

/*
 * Prototypes.
 */

void buttons_init( void *this );
void buttons_destroy( void *this );
void buttons_request_callback( EZ_Widget *widget, void *data );
void buttons_mark_pattern( void *this, void *tree, void *summary, 
                           unsigned int i, unsigned int j, char seen );
void buttons_launch_pattern( void *this, unsigned int i, EZ_Widget *button );
void buttons_pattern_callback( EZ_Widget *widget, void *data );
void buttons_toggle_request( void *this, void *summary_object, char folder,
                             unsigned int i, unsigned int j );
void buttons_interrupt_callback( EZ_Widget *widget, void *data );
void buttons_navigation_callback( EZ_Widget *widget, void *data );
void buttons_mark_callback( EZ_Widget *widget, void *data );
void buttons_mark_group( void *this, unsigned int i, EZ_Widget *widget );
void buttons_update_node( void *this, unsigned int i );
void buttons_folder_requests_callback( EZ_Widget *widget, void *data );
char *buttons_extract_newsgroup( void *this, unsigned int i );
void buttons_update_folder( void *this, char *folder );
int buttons_compare_subjects( char *one, char *two );
void buttons_request_references( void *this, void *summary_object, char folder,
                                 unsigned int i, unsigned int j );
void buttons_export_callback( EZ_Widget *widget, void *data );
void buttons_file_selector_callback( EZ_Widget *widget, void *data );
void buttons_cancel_callback( EZ_Widget *widget, void *data );
void buttons_decode_callback( EZ_Widget *widget, void *data );
void buttons_unmark_callback( EZ_Widget *widget, void *data );
void buttons_help_callback( EZ_Widget *widget, void *data );
void buttons_help_done_callback( EZ_Widget *widget, void *data );
/*
 * Prototypes.
 */

void edit_init( void *parent );
void edit_whine( void *this, char what );
void edit_compose_callback( EZ_Widget *widget, void *data );
void edit_compose_mail_callback( EZ_Widget *widget, void *data );
void edit_create_message( void *this, ln_origin origin, char *from );
void edit_edit_callback( EZ_Widget *widget, void *data );
void edit_get_text( void *this, ln_origin origin, char *from );
void edit_replace_message( void *this );
void edit_text_callback( EZ_Widget *widget, void *data );
void edit_delete_callback( EZ_Widget *widget, void *data );
char *edit_get_email( void *this );
void edit_cancel_message_callback( EZ_Widget *widget, void *data );
void edit_supersede_callback( EZ_Widget *widget, void *data );
void edit_split_message_callback( EZ_Widget *widget, void *data );
char *edit_get_header( void *this, char object, char *header, int size );
void edit_crosspost_callback( EZ_Widget *widget, void *data );
void edit_crosspost_frame_callback( EZ_Widget *widget, void *data );
void edit_attach_callback( EZ_Widget *widget, void *data );
void edit_attachment_frame_callback( EZ_Widget *widget, void *data );
void edit_expunge_callback( EZ_Widget *widget, void *data );
void edit_crosspost_lists_callback( EZ_Widget *widget, void *data );
void edit_destroy_newsgroup_list( np_newsgroup_list *list );
void edit_addresses_callback( EZ_Widget *widget, void *data );
void edit_add_address_callback( EZ_Widget *widget, void *data );
void edit_replace_address_callback( EZ_Widget *widget, void *data );
void edit_sort_addresses_callback( EZ_Widget *widget, void *data );
void edit_remove_address_callback( EZ_Widget *widget, void *data );
void edit_addresses_done_callback( EZ_Widget *widget, void *data );
void edit_address_list_callback( EZ_Widget *widget, void *data );
void edit_update_addresses( void *this );
void edit_address_list_motion_callback( EZ_Widget *widget, void *data );
int edit_address_dnd_reorder_encoder( EZ_Item *item, void *data,
                                      char **message, int *length,
                                      int *needfree );
int edit_address_dnd_reorder_decoder( EZ_Item *item, void *data,
                                      char *message, int length );
int edit_address_dnd_add_decoder( EZ_Widget *widget, void *data,
                                  char *message, int length );
int edit_get_recipients( void *this, EZ_Widget *list, char *keyword );
void edit_addresses_cancel_callback( EZ_Widget *widget, void *data );
void edit_grab_address_callback( EZ_Widget *widget, void *data );
