/*  News Peruser Copyright (c) 1996-1998 James Bailie
 *  ==================================================================
 *
 *  News Peruser is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2, or (at
 *  your option) any later version.
 *
 *  News Peruser is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  Although News Peruser is licensed under the Free Software
 *  Foundation's GNU General Public License, Peruser is not produced
 *  by, nor is it endorsed by the Free Software Foundation. The Free
 *  Software Foundation is not responsible for developing,
 *  distributing, or supporting Peruser in any way. Anyone may place
 *  software they own the copyright to, under the GNU General Public
 *  License.
 *
 *  The GNU General Public License is included in the News Peruser 
 *  distribution archive in a file called COPYING. If you do
 *  not have a copy of the license, you can download one from
 *  ftp://prep.ai.mit.edu, or you can write to the Free Software
 *  Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *  =====================================================================
 */

#include "libnews.h"
#include<sys/types.h>
#include<dirent.h>
#include<math.h>
#include<stdlib.h>
#include<signal.h>
#include<unistd.h>
#include<fcntl.h>

/*
 * Wrapper for fgets().
 */

char *ln_fgets( char *buffer, int size, FILE *stream )
{
   if ( ln_signal( SIGALRM, ln_sigalrm_handler ))
      return NULL;

   alarm( LN_SECONDS );

   if ( fgets( buffer, size, stream ) == NULL )
   {
      if ( errno == EINTR )
      {
         if ( !strcmp( ln_error_message, "SIGALRM!" ))
         {
            errno = ETIMEDOUT;
            strcpy( ln_error_message, 
                    "libnews: ln_fgets: timed-out in fgets()." );
         }
         else
            strcpy( ln_error_message,
                    "libnews: ln_fgets: fgets() interrupted by signal." );

         return NULL;
      }
      else
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE, 
                   "libnews: ln_fgets: %s.", strerror( errno ));
         return NULL;
      }
   }

   alarm( 0 );

   return buffer;
}

/*
 * Gets the article number from ~/.peruser3-newsrc of the last article
 * downloaded for the specified group.
 */

int ln_get_last_spooled( char *group_name, unsigned int *last_spooled )
{
   int idx;
   char *home, buffer[ LN_BUFFER_SIZE ];
   char *pointer;
   FILE *newsrc;


    home = getenv( "HOME" );

    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", home );
    if (( newsrc = fopen( buffer, "r" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_get_last_spooled: could not open file: %s.",
                  buffer );
        return -1;
    }

    do
    {
        if ( fgets( buffer, LN_BUFFER_SIZE, newsrc ) == NULL )
        {
            fclose( newsrc );
            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_get_last_spooled: %s: "
                      "no such group in ~/.peruser-newsrc.", group_name );
            return -1;
        }

        if ( buffer[ 0 ] != ' ' && buffer[ 0 ] != '\t' )
            buffer[ 0 ] = '#';

    }
    while( strncmp( buffer + strspn( buffer, " \t" ), group_name, 
                    strlen( group_name ) ));

    fclose( newsrc );

    idx = strcspn( buffer, ":" );

    if (( pointer = strtok( buffer + ++idx, "\n" )) == NULL )
        *last_spooled = 0;
    else
        *last_spooled = strtol( pointer, NULL, 10 );


    return 0;
}

/*
 * Returns a list of ln_request_list structs, containing the requests on file
 * for the specified group.
 */

int ln_get_requests_list( char *group_name, ln_requests_list **list,
                          unsigned int total )
{
    char buffer[ LN_BUFFER_SIZE ];
    char *home;
    unsigned int i;
    FILE *requests;


    if ( !total )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_get_requests_list: %s no requests on file.",
                  group_name );
        return -1;
    }

    home = getenv( "HOME" );
    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests", 
              home, group_name );
    if (( requests = fopen( buffer, "r" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_get_requests_list: could not open file: %s.",
                  buffer );
        return -1;
    }


    if (( *list = calloc( total, sizeof **list )) == NULL )
        ln_allocation_error();

    for( i = 0; i < total; ++i )
    {
        (*list)[ i ].found = not;

        if ( fgets( buffer, LN_BUFFER_SIZE, requests ) == NULL )
        {
            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_get_requests_list: "
                      "premature end of file %s:requests.",
                      group_name );
            return -1;
        }

        if (( ( *list)[ i ].request = strdup( strtok( buffer, ":\n" ))) 
              == NULL )
            ln_allocation_error();
    }

    fclose( requests );

    return 0;
}

/*
 * Frees the linked list of requests.
 */

void ln_destroy_requests_list( ln_requests_list *list, unsigned int total )
{
    while( total-- )
        free( list[ total ].request );

    free( list );

    return;
}

/*
 * 430: no such article. 
 * 423: bad article number.
 * 22[01]: successful article request.
 */

int ln_check_response( char *buffer )
{
    if ( !strncmp( buffer, "430", 3 ) || 
         !strncmp( buffer, "423", 3 ))
        return 1;

    if ( strncmp( buffer, "22", 2 ))
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_check_response: %s.",
                  buffer );
        return -1;
    }

    return 0;
}

/*
 * Copies one article from spool stream to temp stream.
 */

int ln_add_article( FILE *spool, FILE *temp )
{
    char buffer[ LN_BUFFER_SIZE ];

    do
    {
        if ( fgets( buffer, LN_BUFFER_SIZE, spool ) == NULL )
            return -1;

        fputs( buffer, temp );
    }
    while( strncmp( buffer, ".\r\n", 3 ));

    return 0;
}

/*
 * Replaces header-only articles with the full header and article text of the
 * same article, if both are on file in the specified group's spoolfile, and
 * the full article comes second in order in the spoolfile.
 */

int ln_replace_headers( char *group_name, ln_requests_list *list, 
                        unsigned int total )
{
    char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ], *home;
    char *pointer;
    unsigned int i;
    FILE *spool, *temp, *read, *temp_read, *requests;

    home = getenv( "HOME" );
    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home, 
              group_name );

    if (( spool = fopen( buffer, "r" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_replace_headers: could not open file %s.",
                  buffer );
        return -1;
    }

    strcat( buffer, ":temp" );
    if (( temp = fopen( buffer, "w" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_replace_headers: could not open file %s.",
                  buffer );
        return -1;
    }

    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:read", 
              home, group_name );
    if (( read = fopen( buffer, "r" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_replace_headers: could not open file %s.",
                  buffer );
        return -1;
    }

    strcat( buffer, ":temp" );
    if (( temp_read = fopen( buffer, "w" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_replace_headers: could not open file %s.",
                  buffer );
        return -1;
    }

    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", home );
    if (( requests = fopen( buffer, "r" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_replace_headers: could not open file %s.",
                  buffer );
        return -1;
    }

    while( fgets( buffer, LN_BUFFER_SIZE, spool ) != NULL )
    {
        if ( buffer[ 0 ] != '@' )
        {
            fputs( buffer, temp );

            fgets( buffer, LN_BUFFER_SIZE, read );
            fputs( buffer, temp_read );

            if ( ln_add_article( spool, temp ))
            {
                fclose( spool );
                fclose( temp );
                fclose( read );
                fclose( temp_read );
                fclose( requests );

                snprintf( ln_error_message, LN_BUFFER_SIZE,
                          "libnews: ln_replace_headers: "
                          "premature end of spool %s.",
                          group_name );
                return -1;
            }
            continue;
        }

        strcpy( second_buffer, buffer );
        pointer = strtok( strrchr( second_buffer, ' ' ) + 1, ":" );

        for( i = 0; i < total; ++i )
        {
            if ( list[ i ].request[ 0 ] == '<' )
                continue;
            
            if ( !strcmp( pointer, list[ i ].request ))
                if ( list[ i ].found == found )
                {
                    do
                        fgets( buffer, LN_BUFFER_SIZE, spool );
                    while( strncmp( buffer, ".\r\n", 3 ));

                    fgets( buffer, LN_BUFFER_SIZE, read );

                    if ( ln_add_article( requests, temp ))
                    {
                        fclose( spool );
                        fclose( temp );
                        fclose( read );
                        fclose( temp_read );
                        fclose( requests );
                 
                        snprintf( ln_error_message, LN_BUFFER_SIZE,
                                  "libnews: ln_replace_headers: "
                                  "premature end of spool %s.",
                                  group_name );
                        return -1;
                    }                        
                    fputs( "u\n", temp_read );

                    break;
                }
        }

        if ( i == total )
        {
            fputs( buffer, temp );

            fgets( buffer, LN_BUFFER_SIZE, read );
            fputs( buffer, temp_read );

            if ( ln_add_article( spool, temp ))
            {
                fclose( spool );
                fclose( temp );
                fclose( read );
                fclose( temp_read );
                fclose( requests );

                snprintf( ln_error_message, LN_BUFFER_SIZE,
                          "libnews: ln_replace_headers: "
                          "premature end of spool %s.",
                          group_name );
                return -1;
            }
        }
    }

    fclose( spool );
    fclose( temp );
    fclose( read );
    fclose( temp_read );
    fclose( requests );

    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home, 
              group_name );
    remove( buffer );
    snprintf( second_buffer, LN_BUFFER_SIZE, "%s:temp", buffer );
    rename( second_buffer, buffer );

    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:read", 
              home, group_name );
    remove( buffer );
    snprintf( second_buffer, LN_BUFFER_SIZE, "%s:temp", buffer );
    rename( second_buffer, buffer );

    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", home );
    remove( buffer );

    return 0;
}

/*
 * Parses server replies to the XOVER command, and saves header lines to
 * spool.
 */

int ln_retrieve_xover_data( char *group_name, FILE *server,
                            unsigned int last_spooled, unsigned int last,
                            int ( *callback )( void *data, char *group,
                                               unsigned int lines,
                                               unsigned int begin,
                                               unsigned int current,
                                               unsigned int end ),
                            void *data )
{
    char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ], *home;
    char *pointer, *old_pointer;
    FILE *spool, *read;
    int length, copy_length;
    unsigned int i;


    home = getenv( "HOME" );
    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home, 
              group_name );
    if (( spool = fopen( buffer, "a" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_retrieve_xover_data: could not open file %s.",
                  buffer );
        return -1;
    }

    strcat( buffer, ":read" );
    if (( read = fopen( buffer, "a" )) == NULL )
    {
        fclose( spool );
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_retrieve_xover_data: could not open file %s.",
                  buffer );
        return -1;
    } 

    if ( ++last_spooled - last == 0 )
        fprintf( server, "xover %d\r\n", last );
    else
        fprintf( server, "xover %d-%d\r\n", last_spooled, last );

    if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
    {
        fclose( spool );
        fclose( read );
        if ( errno == EINTR )
           return -2;

        return -1;
    }

    if ( strncmp( buffer, "224", 3 ))
    {
        fclose( spool );
        fclose( read );
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_retrieve_xover_data: "
                  "server replied with error to xover command:\n%s.",
                  buffer );
        return -1;
    }

    for( i = 0; ; ++i )
    {
        if ( callback != NULL )
           if ( callback( data, group_name, 0, last_spooled - 1, i, last ))
              break;

        if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
        {
            fclose( spool );
            fclose( read );
            if ( errno == EINTR )
               return -2;

            return -1;
        }

        if ( !strncmp( buffer, ".\r\n", 3 ))
            break;

        fputs( "u\n", read );

        if ( ( pointer = strstr( buffer, "\t\t" )) == NULL )
            strcpy( second_buffer, buffer );
        else
        {
            old_pointer = buffer;
            second_buffer[ 0 ] = '\0';
            copy_length = length = 0;

            do
            {
                length = pointer - old_pointer;
                copy_length += strlen( second_buffer ) + length;

                strncat( second_buffer, old_pointer, length );
                second_buffer[ copy_length ] = '\0';
                strcat( second_buffer, "\t(empty)" );

                old_pointer = ++pointer;
            }
            while(( pointer = strstr( pointer, "\t\t" )) != NULL );

            if ( *( old_pointer + 1 ) == '\r' )
                strcat( second_buffer, "\t(empty)\r\n" );
            else
                strcat( second_buffer, old_pointer );
        }

        if (( pointer = strtok( second_buffer, "\t" )) == NULL )
        {
            fputs( ".\r\n", spool );
            continue; 
        }
        fprintf( spool, "@header of article number %s:\r\n", pointer );
        fprintf( spool, "Newsgroups: %s\r\n", group_name );
                  
        if (( pointer = strtok( NULL, "\t" )) == NULL )
        {
            fputs( ".\r\n", spool );
            continue;
        }
        fprintf( spool, "Subject: %s\r\n", pointer );

        if (( pointer = strtok( NULL, "\t" )) == NULL )
        {
            fputs( ".\r\n", spool );
            continue;
        }
        fprintf( spool, "From: %s\r\n", pointer );

        if (( pointer = strtok( NULL, "\t" )) == NULL )
        {
            fputs( ".\r\n", spool );
            continue;
        }
        fprintf( spool, "Date: %s\r\n", pointer );

        if (( pointer = strtok( NULL, "\t" )) == NULL )
        {
            fputs( ".\r\n", spool );
            continue;
        }
        fprintf( spool, "Message-ID: %s\r\n", pointer );

        if (( pointer = strtok( NULL, "\t" )) == NULL )
        {
            fputs( ".\r\n", spool );
            continue;
        }

        if ( strncmp( pointer, "(empty)", 7 ))
            fprintf( spool, "References: %s\r\n", pointer );

        if (( pointer = strtok( NULL, "\t" )) == NULL )
        {
            fputs( ".\r\n", spool );
            continue;
        }
        fprintf( spool, "Bytes: %s\r\n", pointer );

        if (( pointer = strtok( NULL, "\t\r\n" )) == NULL )
        {
            fputs( ".\r\n", spool );
            continue;
        }
        fprintf( spool, "Lines: %s\r\n", pointer );
        fputs( ".\r\n", spool );
    }

    fclose( spool );
    fclose( read );

    return 0;
}

/*
 * Retrieves full articles or headers from the specified server stream, saving
 * them to the spoolfile for the specified group.
 */

int ln_retrieve_articles( char *group_name, FILE *server,
                          unsigned int last_spooled, unsigned int last,
                          char *command, 
                          int ( *callback )( void *data, char *group,
                                             unsigned int lines,
                                             unsigned int begin,
                                             unsigned int current,
                                             unsigned int end ),
                          void *data )
{
    char buffer[ LN_BUFFER_SIZE ], *home;
    unsigned int i, count;
    FILE *spool, *read;


    home = getenv( "HOME" );
    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home, 
              group_name );
    if (( spool = fopen( buffer, "a" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_retrieve_articles: could not open spool: %s.",
                  group_name );
        return -1;
    }

    strcat( buffer, ":read" );
    if (( read = fopen( buffer, "a" )) == NULL )
    {
        fclose( spool );
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_retrieve_articles: "
                  "could not open read file: %s:read.",
                  group_name );
        return -1;
    }

    for( i = last_spooled + 1; i <= last; ++i )
        fprintf( server, "%s %d\r\n", command, i );

    for( i = last_spooled + 1; i <=last; ++i )
    {
        if ( callback != NULL )
           if ( callback( data, group_name, last_spooled, 
                          i - last_spooled, last, 0 ))
              break;

        if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
        {
            fclose( spool );
            fclose( read );
            if ( errno == EINTR )
               return -2;

            return -1;
        }

        switch( ln_check_response( buffer ))
        {
        case -1:
            fclose( spool );
            fclose( read );
            return -1;
            break;

        case 0:
            break;

        case 1:
            continue;
        }

        fputs( "u\n", read );

        if ( command[ 0 ] == 'h' )
            fprintf( spool, "@Header of article %d:\r\n", i );

        count = 0;
        do
        {
            if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
            {
                fclose( spool );
                fclose( read );
                if ( errno == EINTR )
                   return -2;

                return -1;
            }
            fputs( buffer, spool );

            if ( callback != NULL )
               if ( !( ++count % 100 ))
                  callback( data, group_name, count, last_spooled, 
                            i - last_spooled, last );
        }
        while( strncmp( buffer, ".\r\n", 3 ));
    }

    fclose( spool );
    fclose( read );

    return 0;
}

/*
 * Retrieves the full articles corresponding to the Message-IDs and article
 * numbers in the :requests file for the specified group, appending them to
 * the specfied group's spoolfile.
 */

int ln_retrieve_requests( char *group_name, FILE *server,
                          ln_requests_list *list, unsigned int total,
                          char folder,
                          int ( *callback )( void *data, char *group,
                                             unsigned int lines,
                                             unsigned int begin,
                                             unsigned int current,
                                             unsigned int end ),
                          void *data )
{
    char buffer[ LN_BUFFER_SIZE ], *home;
    unsigned int i, count;
    FILE *spool, *read, *temp;


    home = getenv( "HOME" );
    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", home );
    if (( temp = fopen( buffer, "w" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_retrieve_requests: could not open file %s.",
                  group_name );
        return -1;
    }

    snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home,
              group_name );
    if (( spool = fopen( buffer, "a" )) == NULL )
    {
        fclose( temp );
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_retrieve_requests: could not open file %s.",
                  buffer );
        return -1;
    }

    strcat( buffer, ":read" );
    if (( read = fopen( buffer, "a" )) == NULL )
    {
        fclose( temp );
        fclose( spool );
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_retrieve_requests: could not open file %s.",
                  buffer );
        return -1;
    }
        
    for( i = 0; i < total; ++i )
        fprintf( server, "article %s\r\n", list[ i ].request );


    for( i = 0; i < total; ++i )
    {
        if ( callback != NULL )
           if ( callback( data, group_name, 0, 0, i, total ))
              break;
        
        if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
        {
            fclose( temp );
            fclose( spool );
            fclose( read );
            if ( errno == EINTR )
               return -2;

            return -1;
        }

        switch( ln_check_response( buffer ))
        {
        case -1:
            fclose( temp );
            fclose( spool );
            fclose( read );
            return -1;
            break;

        case 0:
            break;

        case 1:
            continue;
            break;
        }

        list[ i ].found = found;

        count = 0;
        do
        {
            if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
            {
                fclose( temp );
                fclose( spool );
                fclose( read );
                if ( errno == EINTR )
                   return -2;

                return -1;
            }

            if ( callback != NULL )
               if ( !( ++count % 100 ))
                  callback( data, group_name, count, 0, i, total );

            if ( list[ i ].request[ 0 ] == '<' )
                {
                    fputs( buffer, spool );
                    fputs( "u\n", read );
                }
            else
                fputs( buffer, temp );
        }
        while( strncmp( buffer, ".\r\n", 3 ));
    }

    fclose( spool );
    fclose( temp );
    fclose( read );
    
    if ( ln_replace_headers( group_name, list, total ) )
        return -1;
    
    if ( !folder )
    {
        snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests", 
                  home, group_name );
        truncate( buffer, 0 );
    }

    return 0;
}

/*
 * Checks for present of XOVER command in server's command set.
 */

int ln_has_xover( FILE *server )
{
    char buffer[ LN_BUFFER_SIZE ];
    ln_xover xover;


    xover = LN_NO;

    fputs( "help\r\n", server );
    fgets( buffer, LN_BUFFER_SIZE, server );

    if ( !strncmp( buffer, "100", 3 ))
       for( ; ; )
       {
          if ( !strncmp( ln_fgets( buffer, LN_BUFFER_SIZE, server ), 
                         ".\r\n", 3 ))
             break;

          if ( strstr( buffer, "xover" ))
             xover = LN_YES;
       }

    return ( int)xover;
}

/*
 * Updates ~/.peruser3-newsrc to list variable last as the last article number
 * downloaded for specified group.
 */

int ln_rewrite_newsrc( char *group_name, unsigned int last )
{
    char buffer[ LN_BUFFER_SIZE ], old_path[ LN_BUFFER_SIZE ],
        new_path[ LN_BUFFER_SIZE ];
    FILE *old_newsrc, *new_newsrc;

    snprintf( old_path, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", 
              getenv( "HOME" ));
    if (( old_newsrc = fopen( old_path, "r" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_rewrite_newsrc: could not open file: %s.",
                  old_path );
        return -1;
    }

    snprintf( new_path, LN_BUFFER_SIZE, "%s:temp", old_path );
    if (( new_newsrc = fopen( new_path, "w" )) == NULL )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_rewrite_newsrc: could not open file %s.",
                  new_path );
        return -1;
    }

    while( fgets( buffer, LN_BUFFER_SIZE, old_newsrc ) != NULL )
    {
        if ( !isspace( buffer[ 0 ] ))
        {
            fputs( buffer, new_newsrc );
            continue;
        }

        if ( !strcmp( buffer + strspn( buffer, " \t" ), group_name ))
        {
            fprintf( new_newsrc, "\t%s: %d\n", group_name, last );

            while( fgets( buffer, LN_BUFFER_SIZE, old_newsrc ) != NULL )
                fputs( buffer, new_newsrc );

            break;
        }

        fputs( buffer, new_newsrc );
    }

    fflush( new_newsrc );
    fclose( new_newsrc );

    fclose( old_newsrc );

    remove( old_path );
    rename( new_path, old_path );

    return 0;
}

/*
 * Top level wrapper function. Changes the currently-selected group on the
 * server and launches helper function to retrieve data. The ln_what
 * enumeration is defined in libnews.h
 */

int ln_update_group( char *group_name, FILE *server, ln_what what,
                     ln_xover xover, unsigned int requests, int quantity,
                     int ( *callback )( void *data, char *group,
                                        unsigned int lines,
                                        unsigned int begin,
                                        unsigned int current,
                                        unsigned int end ), 
                     void *data )
{
    char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ], *home;
    char *command;
    unsigned int last_spooled, total, first, last, result;
    ln_requests_list *list;

    list = NULL;
    home = getenv( "HOME" );

    switch( what )
    {
    case LN_HEADERS:
    case LN_ARTICLES:
        if ( quantity < 0 )
            if ( ln_get_last_spooled( group_name, &last_spooled ))
                return -1;
        break;

    case LN_REQUESTS:
        if ( ln_get_requests_list( group_name, &list, requests ))
            return -2;

        break;

    case LN_CATCHUP:
    case LN_NOTHING:
    case LN_CANCEL:
        break;
    }

    fprintf( server, "group %s\r\n", group_name );
    if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
    {
        if ( list != NULL )
            ln_destroy_requests_list( list, total );

        if ( errno == EINTR )
           return -5;

        return -1;
    }

    if ( strncmp( buffer, "211", 3 ))
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_update_group: %s: %s.",
                  group_name, strtok( buffer, "\r\n" ));

        if ( list != NULL )
            ln_destroy_requests_list( list, total );

        if ( !strncmp( buffer, "411", 3 ))
        {
           snprintf( ln_error_message, LN_BUFFER_SIZE, 
                     "libnews: ln_update_group: server does not carry group: "
                     "%s.", group_name );
            return -2;
        }

        if ( !strncmp( buffer, "480", 3 ))
        {
           strcpy( ln_error_message,
                   "libnews: ln_update_group: server requires"
                   " authentication." );
           return -3;
        }

        return -1;
    }

    strtok( buffer, " " );
    strcpy( second_buffer, " " );
    strcat( second_buffer, strtok( NULL, " " ));
    total = strtol( second_buffer, NULL, 10 );

    strcpy( second_buffer, " " );
    strcat( second_buffer, strtok( NULL, " " ));
    first = strtol( second_buffer, NULL, 10 );

    strcpy( second_buffer, " " );
    strcat( second_buffer, strtok( NULL, " " ));
    last  = strtol( second_buffer, NULL, 10 );

    if ( !total )
    {
        snprintf( ln_error_message, LN_BUFFER_SIZE,
                  "libnews: ln_update_group: %s: no articles on server.",
                  group_name );
        if ( list != NULL )
            ln_destroy_requests_list( list, total );
        return -2;
    }

    if ( what != LN_REQUESTS )
    {
        if ( quantity == 0 )
            return ln_rewrite_newsrc( group_name, last );

        if ( quantity > 0 )
            last_spooled = last - quantity;

        if ( last_spooled == last )
        {
            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_update_group: %s: "
                      "no new articles on server.", group_name );
            return -2;
        }

        if ( last_spooled == 0 || last_spooled > last || last_spooled < first )
            last_spooled = last - total;
    }

    if ( what == LN_HEADERS )
        command = "head";
    else
        command = "article";

    switch( what )
    {
    case LN_HEADERS:
        if ( xover )
        {
            if ( ln_retrieve_xover_data( group_name, 
                                         server, last_spooled, last,
                                         callback, data ))
                return -1;
            break;
        }

        /* no break */

    case LN_ARTICLES:
        if (( result = ln_retrieve_articles( group_name, server,
                                             last_spooled, last, command,
                                             callback, data )))
           if ( result == -2 )
              return -5;
           else
              return -1;
        break;

    case LN_REQUESTS:
        if (( result =  ln_retrieve_requests( group_name, server, list, 
                                              requests, 0, callback, data )))
        {
           ln_destroy_requests_list( list, requests );

           if ( result == -2 )
              return -5;

           return -1;
        }
        break;

    case LN_CATCHUP:
    case LN_NOTHING:
    case LN_CANCEL:
        break;
    }

    if ( what != LN_REQUESTS )
        return ln_rewrite_newsrc( group_name, last );

    return 0;
}

int ln_is_all_space( char *buffer )
{
   int i, l;

   if ( !( l = strlen( buffer )))
      return 1;
        
   for( i = 0; i < l; ++i )
      if ( !isspace( buffer[ i ] ))
         return 0;

   return 1;
}

int ln_update_inbox( char *inbox )
{
   char buffer[ LN_BUFFER_SIZE ], lock[ LN_BUFFER_SIZE ],
      spool_path[ LN_BUFFER_SIZE ], *home, *pointer;

   FILE *spool, *maildrop, *read;
   DIR *dir;
   struct dirent *entry;
   
   struct flock lock_struct;
   int count, length, first_pass, subject, date, passed_header, message_id;


   /*
    * Open ~/.peruser3-inboxes.
    */

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-inboxes", 
             home = getenv( "HOME" ));
   if (( spool = fopen( buffer, "r" )) == NULL )
   {
      if ( errno == ENOENT )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE, 
                   "libnews: ln_update_inbox: %s does not exist.", buffer );
         return -2;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "libnews: ln_update_inbox: could not open file %s.", buffer );
      return -1;
   }

   /*
    * Find specified inbox's entry.
    */

   count = 0;
   pointer = NULL;
   length = strlen( inbox );

   while( fgets( buffer, LN_BUFFER_SIZE, spool ) != NULL )
   {
      ++count;

      if ( strtok( buffer, " \t" ) == NULL )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE, 
                   "libnews: ln_update_inbox: "
                   "malformed line %d in ~/.peruser3-inboxes.", count );
         fclose( spool );
         return -1;
      }

      /*
       * Get associated maildrop path.
       */
      
      if ( !strncmp( buffer, inbox, length ))
      {
         if (( pointer = strtok( NULL, " \t" )) == NULL )
         {
            snprintf( ln_error_message, LN_BUFFER_SIZE, 
                      "libnews: ln_update_inbox: "
                      "malformed line %d in ~/.peruser3-inboxes.", count );
            fclose( spool );
            return -1;
         }

         if ( strtok( pointer, "\n" ) == NULL )
         {
            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_update_inbox: "
                      "malformed line %d in ~/.peruser3-inboxes.", count );
            return -1;
         }

         break;
      }
   }

   fclose( spool );

   /*
    * If not found.
    */

   if ( pointer == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_update_inbox: "
              "%s not in ~/peruser3-inboxes.", inbox );
      return -1;
   }

   /*
    * Check for lockfile.
    */

   strcpy( spool_path, pointer );
   if (( pointer = strrchr( spool_path, '/' )) == NULL )
      return -1;
   
   snprintf( lock, LN_BUFFER_SIZE, "%s.lock", pointer + 1 );

   strcpy( buffer, spool_path );
   if (( pointer = strrchr( buffer, '/' )) == NULL )
      return -1;

   *pointer = '\0';
   if (( dir = opendir( buffer )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_update_inbox: "
                "could not open spool directory: %s.", buffer );
      return -1;
   }

   while(( entry = readdir( dir )) != NULL )
      if ( !strcmp( entry->d_name, lock ))
      {
         strcpy( ln_error_message, "libnews: ln_update_inbox: "
                 "lockfile for spool exists" );
         return -3;
      }

   closedir( dir );

   /*
    * Open maildrop.
    */

   if (( maildrop = fopen( spool_path, "r+" )) == NULL )
   {
      if ( errno == ENOENT )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE, 
                   "libnews: ln_update_inbox: maildrop %s does not exist.",
                   pointer );
         return -2;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_update_inbox: "
                "could not open maildrop %s.", pointer );
      return -1;
   }

   /*
    * Open spool and read files.
    */

   snprintf( spool_path, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home, inbox );
   if (( spool = fopen( spool_path, "a" )) == NULL )
   {
      fclose( maildrop );
      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_update_inbox "
                "could not open file %s.", buffer );
      return -1;
   }

   strcat( spool_path, ":read" );
   if (( read = fopen( spool_path, "a" )) == NULL )
   {
      fclose( spool );
      fclose( maildrop );
      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_update_inbox "
                "could not open file %s.", spool_path );
      return -1;
   }

   /*
    * Get read lock.
    */

   lock_struct.l_type = F_WRLCK;
   lock_struct.l_whence = SEEK_SET;
   lock_struct.l_start = 0;
   lock_struct.l_len = 0;

   if ( fcntl( fileno( maildrop ), F_SETLK, &lock_struct ))
   {
      fclose( spool );
      fclose( read );
      fclose( maildrop );

      if ( errno == EACCES || errno == EAGAIN )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_update_inbox: "
                   "could not get lock on maildrop: %s.", inbox );
         return -3;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "libnews: ln_update_inbox: fcntl failed" );
      return -1;
   }

   /*
    * Copy articles over.
    */

   subject = date = message_id = 0;
   passed_header = 0;
   first_pass = 1;
   
   while( fgets( buffer, LN_BUFFER_SIZE, maildrop ) != NULL )
   {
   AGAIN:
         
      if ( first_pass || 
           buffer[ 0 ] == '\n' || buffer[ 0 ] == '\r' ||
           ln_is_all_space( buffer ))
      {
         if ( !first_pass )
            if ( fgets( buffer, LN_BUFFER_SIZE, maildrop ) == NULL )
               break;

         if ( !strncmp( buffer, "From ", 5 ))
         {
            passed_header = 0;
            subject = date = message_id = 0;

            if ( !first_pass )
            {
               fputs( ".\r\n", spool );
               fputs( "u\n", read );
            }

            first_pass = 0;
         }
         else
            if ( !passed_header )
            {
               passed_header = 1;
               if ( !subject )
                  fputs( "Subject: (no subject)\r\n", spool );

               if ( !date )
                  fputs( "Date: (no date)\r\n", spool );

               if ( !message_id )
                  fputs( "Message-ID: (no Message-ID)\r\n", spool );

               fputs( "\r\n", spool );
               goto AGAIN;
            }
            else
            {
               fputs( "\r\n", spool );
               goto AGAIN;
            }
      }

      if ( !passed_header )
         if ( !strncasecmp( buffer, "Subject:", 8 ))
            subject = 1;
         else
            if ( !strncasecmp( buffer, "Date:", 5 ))
               date = 1;
            else
               if ( !strncasecmp( buffer, "Message-ID:", 11 ))
                  message_id = 1;
      
      if ( strtok( buffer, "\r\n" ) == NULL )
         fputs( "\r\n", spool );
      else
         fprintf( spool, "%s\r\n", buffer );
   }

   if ( !first_pass )
   {
      fputs( ".\r\n", spool );
      fputs( "u\n", read );
   }

   fclose( spool );
   fclose( read );

   if ( ftruncate( fileno( maildrop ), 0 ))
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "libnews: ln_update_inbox: could not truncate: %s.", inbox );
      return -2;
   }

   if ( fcntl( fileno( maildrop ), F_UNLCK ))
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_update_inbox: "
                "fcntl F_UNLCK failed: %s.", strerror( errno ));
      return -1;
   }

   fclose( maildrop );

   return 0;
}
