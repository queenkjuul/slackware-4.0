/*
   News Peruser Copyright (c) 1996-1998 James Bailie
   ==================================================================

   News Peruser is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2, or (at
   your option) any later version.

   News Peruser is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   Although News Peruser is licensed under the Free Software
   Foundation's GNU General Public License, Peruser is not produced
   by, nor is it endorsed by the Free Software Foundation. The Free
   Software Foundation is not responsible for developing,
   distributing, or supporting Peruser in any way. Anyone may place
   software they own the copyright to, under the GNU General Public
   License.

   The GNU General Public License is included in the News Peruser 
   distribution archive in a file called COPYING. If you do
   not have a copy of the license, you can download one from
   ftp://prep.ai.mit.edu, or you can write to the Free Software
   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.

   =====================================================================
*/

#include "libnews.h"
#include<sys/types.h>
#include<unistd.h>
#include<regex.h>
#include<time.h>

/*
 * Returns a pointer to a line in the passed ln_message struct header field
 * that begins with the string pointed to by line.
 */

char *ln_get_line( char *line, ln_message *message )
{
   int l, rl;
   char buffer[ LN_BUFFER_SIZE ];
   char *pointer, *value;


   pointer = message->header - 1;
   l = strlen( line );

   while( *( ++pointer ))
   {
      if ( !strncasecmp( pointer, line, l ))
         break;

      pointer = strchr( pointer, '\n' );
   }

   if ( !( *pointer ) )
      return NULL;

   pointer += l;
   l = strcspn( pointer, "\r\n" );
   strncpy( buffer, pointer, l );
   buffer[ l ] = '\0';

   rl = 0;
   pointer = strchr( pointer, '\n' );

   while( isspace( *( ++pointer )))
   {
      l = strcspn( pointer, "\r\n" );
      strncat( buffer, pointer, l );

      rl += l;
      buffer[ rl ] = '\0';
      pointer = strchr( pointer, '\n' );
   }

   if (( value = strdup( buffer )) == NULL )
      ln_allocation_error();

   return value;
}

/*
 * Creates a minimal Usenet header for outgoing articles.
 */

int ln_create_header( char *group_name, char *NNTP_addr, char *email_addr,
                      ln_origin origin, ln_message *message )
{
   regex_t regex;
   regmatch_t *matches;
   int result, length;

   time_t unix_time;
   struct tm *lt;
   ldiv_t div_result;
   long int tzhh, tzmm;

   pid_t pid;
   
   char *month, *wkdy, *day, *hms, *year, *pointer, *id_pointer, 
   *ref_pointer, zone_buf[ 25 ];

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
      to[ LN_BUFFER_SIZE ],
      path[ LN_BUFFER_SIZE ],
      newsgroups[ LN_BUFFER_SIZE ],
      date[ LN_BUFFER_SIZE ],
      subject[ LN_BUFFER_SIZE ],
      message_id[ LN_BUFFER_SIZE ],
      references[ LN_BUFFER_SIZE ],
      from[ LN_BUFFER_SIZE ],
      cancel[ LN_BUFFER_SIZE ],
      supersedes[ LN_BUFFER_SIZE ];

   long int i;

   if (( origin == LN_FOLLOW_UP || origin == LN_CANCEL_MESSAGE ) 
         && message->header == NULL )
   {
      strcpy( ln_error_message, 
              "libnews: ln_create_header: "
              "can't follow-up to NULL message->header." );
      return -1;
   }

   to[ 0 ] = '\0';
   path[ 0 ] = '\0';
   newsgroups[ 0 ] = '\0';
   date[ 0 ] = '\0';
   subject[ 0 ] = '\0';
   message_id[ 0 ] = '\0';
   references[ 0 ] = '\0';
   from[ 0 ] = '\0';
   cancel[ 0 ] = '\0';

   if ( origin == LN_MAIL || origin == LN_FORWARD )
      strcpy( to, "To: (replace with address(es))\n" );

   if ( origin == LN_REPLY )
   {
      if (( pointer = ln_get_line( "Reply-To:", message )) == NULL )
         if (( pointer = ln_get_line( "From:", message )) == NULL )
         {
            strcpy( ln_error_message, "libnews: ln_create_header: "
                    "Message being replied-to has to Reply-To, nor"
                    " From header." );
            return -1;
         }
      
      snprintf( to, LN_BUFFER_SIZE, "To: %s\r\n", pointer );
      free( pointer );
   }
   
   /* Newsgroups: */

   if ( origin == LN_FOLLOW_UP || origin == LN_CANCEL_MESSAGE ||
        origin == LN_SUPERSEDE )
   {
      if (( pointer = ln_get_line( "Newsgroups: ", message )) == NULL )
      {
         strcpy( ln_error_message, "libnews: ln_create_header: "
                 "Message being followed-up has no Newsgroups: header." );
         return -1;
      }

      snprintf( newsgroups, LN_BUFFER_SIZE, "Newsgroups: %s\r\n", pointer );
      free( pointer );
   }
   else
      if ( origin != LN_MAIL && origin != LN_REPLY && origin != LN_FORWARD &&
           group_name != NULL )
         snprintf( newsgroups, LN_BUFFER_SIZE, "Newsgroups: %s\r\n", 
                   group_name );

   /* Date: */

   unix_time = time( NULL );
   lt        = localtime( &unix_time );
   strcpy( buffer, asctime( lt ));
   wkdy      = strtok( buffer, " " );
   month     = strtok( NULL, " " );
   day       = strtok( NULL, " " );
   hms       = strtok( NULL, " " );
   year      = strtok( NULL, "\n" );

   div_result    = ldiv( timezone, 3600 );
   tzhh          = div_result.quot;
   div_result    = ldiv( div_result.rem, 60 );
   tzmm          = div_result.quot;

   snprintf( zone_buf, sizeof zone_buf, "%c%0.2u%0.2u",
             (( tzhh <= 0 ) ? '+' : '-' ), labs( tzhh ), labs( tzmm ));

   snprintf( date, LN_BUFFER_SIZE, "Date: %s, %s %s %s %s %s\r\n",
             wkdy, day, month, year, hms, zone_buf );

   /* Subject: */

   switch( origin )
   {
      case LN_ORIGINAL:
      case LN_MAIL:
         strcpy( subject, "Subject: (no subject)\r\n" );
         break;

      case LN_FOLLOW_UP:
      case LN_REPLY:
   case LN_FORWARD:
         if (( pointer = ln_get_line( "Subject: ", message )) == NULL )
         {
            strcpy( ln_error_message,
                    "libnews: ln_create_header: "
                    "message being follow-up has no subject." );
            return -1;
         }

         if ( !strncmp( pointer, "Re: ", 4 ) ||
              !strncmp( pointer, "re: ", 4 ))
            pointer += 4;

         if ( origin == LN_FORWARD )
            snprintf( subject, LN_BUFFER_SIZE,
                      "Subject: Forwarded Message: %s\r\n", pointer );
         else
            snprintf( subject, LN_BUFFER_SIZE, "Subject: Re: %s\r\n",
                      pointer );

         free( pointer );
         break;

      case LN_CANCEL_MESSAGE:
         if (( pointer = ln_get_line( "Message-ID: ", message )) == NULL )
         {
            strcpy( ln_error_message, "libnews: ln_create_header: message "
                    "being cancelled has no Message-ID." );
            return -1;
         }
         snprintf( subject, LN_BUFFER_SIZE, "Subject: cancel %s\r\n", 
                   pointer );
         snprintf( cancel, LN_BUFFER_SIZE, "Control: cancel %s\r\n", pointer );
         free( pointer );
         break;

      case LN_SUPERSEDE:
         if (( pointer = ln_get_line( "Subject: ", message )) == NULL )
         {
            strcpy( ln_error_message, "libnews: ln_create_header: message "
                    "being superseded has no Subject." );
            return -1;
         }
         snprintf( subject, LN_BUFFER_SIZE, "Subject: %s\r\n", pointer );
         free( pointer );

         if (( pointer = ln_get_line( "Message-ID: ", message )) == NULL )
         {
            strcpy( ln_error_message, "libnews: ln_create_header: message "
                    "being superceded has no Message-ID." );
            return -1;
         }
         snprintf( supersedes, LN_BUFFER_SIZE, "Supersedes: %s\r\n", pointer );
         free( pointer );
         break;

      case LN_EDIT:
         break;
   }

   /* Message-ID */

   srand( pid = getpid() );
   snprintf( message_id, LN_BUFFER_SIZE,
             "Message-ID: <NewsPeruser-3.0-%x-%x.%x@%s>\r\n",
             ( long unsigned int)( 100 * rand() * pid ), 
             unix_time, pid, NNTP_addr );

   /* Path */

   if ( origin != LN_MAIL && origin != LN_REPLY &&
        origin != LN_FORWARD && group_name != NULL )
   {
      strcpy( buffer, "(.*<| *)(.+@.+)(>|[ \t]*\\(?)" );
      if (( result = regcomp( &regex, buffer, REG_EXTENDED )))
      {
         strcpy( ln_error_message, "libnews: ln_create_header: " );
         regerror( result, &regex, buffer, LN_BUFFER_SIZE );
         strcat( ln_error_message, buffer );
         return -1;
      }

      if (( matches = calloc( regex.re_nsub + 1, sizeof *matches )) == NULL )
         ln_allocation_error();

      if (( result = 
            regexec( &regex, email_addr, regex.re_nsub + 1, matches, 0 )))
      {
         strcpy( ln_error_message, "libnews: ln_create_header:" );
         regerror( result, &regex, buffer, LN_BUFFER_SIZE );
         strcat( ln_error_message, buffer );
         regfree( &regex );
         free( matches );
         return -1;
      }

      length = strcspn( email_addr + matches[ 2 ].rm_so, "@" );
      strncpy( second_buffer, email_addr + matches[ 2 ].rm_so, length );
      second_buffer[ length ] = '\0';
      snprintf( path, LN_BUFFER_SIZE, "Path: %s\r\n", second_buffer );
      regfree( &regex );
      free( matches );
   }

   /* References */

   switch( origin )
   {
      case LN_ORIGINAL:
      case LN_MAIL:
   case LN_FORWARD:
         break;

      case LN_FOLLOW_UP:
      case LN_REPLY:
         strcpy( references, "References: " );

         ref_pointer = ln_get_line( "References: ", message );
         id_pointer  = ln_get_line( "Message-ID: ", message );

         if ( id_pointer != NULL )
         {
            if ( ref_pointer != NULL )
            {
               strcat( references, ref_pointer );

               if ( ( strlen( references ) + strlen( id_pointer )) > 998 )
                  snprintf( buffer, LN_BUFFER_SIZE, "\r\n            %s\r\n",
                            id_pointer );
               else
                  snprintf( buffer, LN_BUFFER_SIZE, " %s\r\n", id_pointer );

               strcat( references, buffer );
               free( ref_pointer );
            }
            else
            {
               snprintf( buffer, LN_BUFFER_SIZE, "%s\r\n", id_pointer );   
               strcat( references, buffer );
            }

            free( id_pointer );
         }
         break;

      case LN_CANCEL_MESSAGE:
      case LN_SUPERSEDE:
      case LN_EDIT:
         break;
   }

   /* From */

   snprintf( from, LN_BUFFER_SIZE, "From: %s\r\n", email_addr );

   /* return new header */

   if ( origin == LN_FOLLOW_UP || origin == LN_REPLY || 
        origin == LN_CANCEL_MESSAGE || origin == LN_SUPERSEDE )
      free( message->header );

   i = strlen( to ) + 
      strlen( path ) +
      strlen( newsgroups ) +
      strlen( date ) +
      strlen( subject ) +
      strlen( message_id ) +
      strlen( references ) +
      strlen( from ) + 
      strlen( cancel ) +
      strlen( supersedes ) + 1;

   if (( message->header = ( char *)malloc( i )) == NULL )
      ln_allocation_error();

   message->header[ 0 ] = '\0';


   strcpy( message->header, path );
   strcat( message->header, newsgroups );
   strcat( message->header, date );
   strcat( message->header, to );
   strcat( message->header, subject );
   strcat( message->header, from );
   strcat( message->header, message_id );

   if ( references[ 0 ] )
      strcat( message->header, references );

   if ( origin == LN_CANCEL_MESSAGE )
      strcat( message->header, cancel );

   if ( origin == LN_SUPERSEDE )
      strcat( message->header, supersedes );

   return 0;
}
