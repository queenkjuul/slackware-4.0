/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "libnews.h"
#include<signal.h>

void ln_sort_queues( ln_node *list );

/*
 * Similar to strtok(). Returns one complete, zero-terminated Message-ID from
 * the passed string argument, which is assumed to the the contents of a
 * References header line. Successive calls passing NULL for the value of
 * string return the next Message-ID, until the string is exhausted, when this
 * function will return NULL.
 */

char *ln_get_reference( char *string )
{
   char *test;
   static char *token, *remainder, *temp;
   size_t length;

   if ( string != NULL )
   {
      if (( token = malloc( strlen( string ) + 1 )) == NULL )
         ln_allocation_error();

      if (( remainder = malloc( strlen( string ) + 1 )) == NULL )
         ln_allocation_error();

      if (( temp = malloc( strlen( string ) + 1 )) == NULL )
         ln_allocation_error();

      test = strchr( string, '<' );
   }
   else
      test = strchr( remainder, '<' );

   if ( test != NULL )
   {
      strcpy( temp, test );
      length = strcspn( temp, " \t\r\n" );
      strncpy( token, temp, length );
      token[ length ] = '\0';
      strcpy( remainder, temp + length );

      return( token );
   }
   else
   {
      free( token );
      free( remainder );
      free( temp );

      return( NULL );
   }
}

/*
 * Recursively writes an article corresponding to a thread tree node, and all
 * of its children to a new spoolfile.
 */

int ln_save_node( ln_node *node, unsigned int depth, FILE *spool, FILE *read, 
                  FILE *temp, FILE *temp_read, FILE *thread )
{
   ln_node *local_pointer;
   char local_buffer[ LN_BUFFER_SIZE ], *big_buffer;
   unsigned int idx;

   if ( read != NULL )
      rewind( read );

   /*
    * Advance the spool to the current article's position.
    */

   fseek( spool, node->offset, SEEK_SET );

   /*
    * Copy it over to a temporary file.
    */

   if (( big_buffer = malloc( node->size + 1 )) == NULL )
      ln_allocation_error();

   if ( fread( big_buffer, 1, node->size, spool ) != node->size )
   {
      if ( ferror( spool ))
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "ln_save_node: error doing fread():%s.",
                   strerror( errno ));
         return -1;
      }

      if ( feof( spool ))
      {
         strcpy( ln_error_message, "ln_save_node: premature end of spool." );
         return -1;
      }

      return -1;
   }

   big_buffer[ node->size ] = '\0';
   fputs( big_buffer, temp );
   free( big_buffer );

   /*
    * Copy over its seen status to a temporary :read file.
    */

   if ( read != NULL )
   {
      while( node->position-- )
         fgets( local_buffer, LN_BUFFER_SIZE, read );

      fgets( local_buffer, LN_BUFFER_SIZE, read );
      fputs( local_buffer, temp_read );
   }

   /*
    * Save article's threading information to group's :threading file. The
    * articles are saved in threaded order, but the interface needs to know
    * the relationships between articles to create the thread tree. The first
    * number indicates whether the corresponding article is part of a thread
    * or not. A zero indicates the article is not a follow-up to any article
    * on file, a one indicates it is the direct precursor of the previous
    * article in the spool, a two indicates it is the grandchild of the
    * previous article and its parent is missing from the spool, and so on...
    * The second number is the quantity of follow-ups this article itself has.
    */

   idx = depth + node->gap;
   fprintf( thread, "%u:%u\n", idx, node->queue_count );

   local_pointer = node->queue_head;

   if ( local_pointer != NULL )
      ++idx;

   /*
    * Save my children.
    */

   while( local_pointer != NULL )
   {
      ln_save_node( local_pointer, idx, spool, read, temp, temp_read, 
                    thread );
      local_pointer = ( ln_node *)local_pointer->queue_next;
   }

   return 0;
}

/*
 * Initializes empty tree node.
 */

void ln_init_node( ln_node *node, unsigned int position, 
                   long int offset, long int size,
                   char *my_id, char *my_subject, char *my_date, char *my_refs )
{
   char *one_ref;
   ln_reference *list_pointer, *previous;

   node->position = position;
   node->offset = offset;
   node->size = size;
   node->gap = node->queue_count = 0;
   node->queued = no;

   node->queue_head = node->queue_tail = node->queue_next = 
      node->queue_prev = NULL;

   if (( node->message_id = strdup( strtok( my_id, "\r\n" ))) == NULL )
      ln_allocation_error();
   
   if (( node->subject = strdup( strtok( my_subject, "\r\n" ))) == NULL )
      ln_allocation_error();

   ln_convert_date( my_date, &node->converted_date );

   if ( my_refs != NULL && ( one_ref = ln_get_reference( my_refs )) != NULL )
   {
      if (( node->references = malloc( sizeof *node->references )) == NULL )
         ln_allocation_error();

      if (( node->references->current_ref = strdup( one_ref )) == NULL )
         ln_allocation_error();

      node->references->prev_ref = NULL;
      list_pointer = node->references;
      while(( one_ref = ln_get_reference( NULL )) != NULL )
      {
         if (( list_pointer->next_ref = malloc( strlen( one_ref ) + 1 ))
               == NULL )
            ln_allocation_error();

         previous = list_pointer;
         list_pointer = ( ln_reference *)list_pointer->next_ref;
         list_pointer->prev_ref = previous;

         if (( list_pointer->current_ref = strdup( one_ref )) == NULL )
            ln_allocation_error();
      }

      list_pointer->next_ref = NULL;
   }
   else
      node->references = NULL;

   return;
}

/*
 * Destroys tree node.
 */

void ln_destroy_node( ln_node *node )
{
   ln_reference *list_pointer, *previous;

   free( node->message_id );
   free( node->converted_date );
   free( node->subject );

   if ( node->references != NULL )
   {
      list_pointer = node->references;

      while( list_pointer->next_ref )
         list_pointer = ( ln_reference *)list_pointer->next_ref;

      do 
      {
         previous = ( ln_reference *)list_pointer->prev_ref;

         free( list_pointer->current_ref );
         free( list_pointer );

         list_pointer = previous;
      }
      while( list_pointer != NULL );
   }

   free( node );

   return;
}

/*
 * Initializes tree nodes as doubly-linked list in spoolfile order.
 */

ln_node *ln_get_article_list( char *group_name, FILE *spool )
{
   char *current_message_id, *current_subject, *current_date, 
      *current_references, *references_buffer;

   long int offset, temp;

   char buffer[ LN_BUFFER_SIZE ];

   enum { no, yes }last_line_was_reference_header;

   ln_node *article_list, *current_article, *previous_article;

   unsigned int counter, tab;

   article_list = NULL;
   counter = 0;
   offset = 0;

   current_article = previous_article = NULL;

   do
   {
      current_message_id = current_references = NULL;

      for ( ; ; )
      {
         fgets( buffer, LN_BUFFER_SIZE, spool );
         if ( feof( spool )
               || !strncmp( buffer, "\r\n", 2 )
               || !strncmp( buffer, ".\r\n", 3 ))
            break;

         if ( isspace( buffer[ 0 ] ) &&
               last_line_was_reference_header )
         {
            if (( references_buffer
                  = malloc( strlen( buffer ) +
                        strlen( current_references ) + 1 )) == NULL )
               ln_allocation_error();

            strcpy( references_buffer, 
                    strtok( current_references, "\r\n" ));
            strcat( references_buffer, buffer );

            free( current_references );

            if (( current_references = strdup( references_buffer )) == NULL )
               ln_allocation_error();

            free( references_buffer );
            continue;
         }

         last_line_was_reference_header = no;

         if ( !strncasecmp( buffer, "Message-ID:", 11 ))
         {
            tab = strspn( buffer + 11, " \t" );
            if (( current_message_id = strdup( buffer + 11 + tab )) 
                  == NULL )
               ln_allocation_error();
            else
               continue;
         }

         if ( !strncasecmp( buffer, "Subject:", 8 ))
         {
            tab = strspn( buffer + 8, " \t" );
            if (( current_subject = strdup( buffer + 8 + tab )) 
                  == NULL )
               ln_allocation_error();
            else
               continue;
         }
              
         if ( !strncasecmp( buffer, "Date:", 5 ))
         {
            tab = strspn( buffer + 5, " \t" );
            if (( current_date = strdup( buffer + 5 + tab )) 
                  == NULL )
               ln_allocation_error();
            else
               continue;
         }

         if ( !strncmp( buffer, "References:", 11 ))
         {
            tab = strspn( buffer + 11, " \t" );
            if (( current_references = strdup( buffer + 11 + tab )) 
                  == NULL )
               ln_allocation_error();
            else
            {
               last_line_was_reference_header = yes;
               continue;
            }
         }
      }

      if ( !feof( spool ))
      {
         while( strncmp( buffer, ".\r\n", 3 ))
            fgets( buffer, LN_BUFFER_SIZE, spool );

         previous_article = current_article;

         if (( current_article = malloc( sizeof *current_article )) == NULL )
            ln_allocation_error();

         temp = offset;
         offset = ftell( spool );

         ln_init_node( current_article, counter, temp, offset - temp, 
                       current_message_id, current_subject, current_date, 
                       current_references );

         ++counter;

         if ( article_list == NULL )
            article_list = current_article;

         current_article->prev_node = previous_article;
         current_article->next_node = NULL;

         if ( previous_article != NULL )
            previous_article->next_node = current_article;

         if ( current_message_id != NULL )
         {
            free( current_message_id );
            current_message_id = NULL;
         }
         
         if ( current_subject != NULL )
         {
            free( current_subject );
            current_subject = NULL;
         }
         
         if ( current_date != NULL )
         {
            free( current_date );
            current_date = NULL;
         }
         
         if ( current_references != NULL )
            free( current_references );
      }
   }
   while( !feof( spool ));

   return article_list;
}

/*
 * Threads the list.
 */

void ln_thread_list( ln_node *article_list )
{
   ln_node *current_article, *other_article, *queue_pointer;

   ln_reference *references_pointer;

   unsigned int gap_count;


   /* 
    * Step though list in spool order 
    */

   for( current_article = article_list;
        current_article != NULL;
        current_article = (ln_node *)current_article->next_node )
   {
      if ( current_article->references == NULL )
         continue;

      references_pointer = current_article->references;

      /*
       * If node has references, search for them in list, starting with the
       * last reference and continuing backwards, until one or none are found.
       */

      while( references_pointer->next_ref != NULL )
         references_pointer = references_pointer->next_ref;

      for( gap_count = 0; 
           references_pointer != NULL; 
           references_pointer = references_pointer->prev_ref ) 
      { 
         for( other_article = article_list; 
              other_article != NULL; 
              other_article = ( ln_node *)other_article->next_node ) 

            /*
             * Ignore myself.
             */

            if ( other_article == current_article ) 
               continue; 
            else 
                  
               /*
                * If found, add this article to the other article's child
                * queue.
                */
                  
               if ( !strcmp( other_article->message_id,
                             references_pointer->current_ref )) 
               {

                  /*
                   * If the other article has no queue, make one.
                   */

                  if ( other_article->queue_head == NULL )
                     other_article->queue_head = other_article->queue_tail =
                        current_article; 

                  /*
                   * If the other article has a queue, iterate over the queue
                   * placing this node at the end of the other article's child
                   * list if it is a direct precursor, or if it is a granchild
                   * node, place it at the head of the list, with the
                   * grandchildren ordered from the most
                   * generationally-distant node to the least
                   * generationally-distant node.
                   */

                  else 
                  {
                     for( queue_pointer = ( ln_node *)other_article->queue_head;
                          queue_pointer != NULL;
                          queue_pointer = ( ln_node*)queue_pointer->queue_next )
                        if ( gap_count >= (( ln_node *)queue_pointer )->gap )
                        {

                           /* 
                            * If we're going to put the node at the head of
                            * the other article's queue, we need to change the
                            * value of the other article's queue->head.
                            */

                           if ( queue_pointer == other_article->queue_head )
                           {
                              other_article->queue_head = current_article;
                              current_article->queue_next = queue_pointer;
                              current_article->queue_prev = NULL;
                              queue_pointer->queue_prev = current_article;
                           }
                           
                           /*
                            * Otherwise, insert the node into the list at this
                            * position.
                            */

                           else
                           {
                              (( ln_node *)queue_pointer->queue_prev )
                                 ->queue_next = current_article;
                              current_article->queue_prev
                                 = queue_pointer->queue_prev;
                              queue_pointer->queue_prev = current_article;
                           }

                           current_article->queue_next = queue_pointer;
                           break;
                        }

                     /* 
                      * If we couldn't find a place to insert the node into
                      * the queue, add it to the end.
                      */

                     if ( ( ln_node *)queue_pointer == NULL )
                     {
                        (( ln_node *)other_article->queue_tail )->queue_next
                           = current_article;
                        current_article->queue_prev
                           = other_article->queue_tail;
                        other_article->queue_tail = current_article;
                     }
                  }

                  /*
                   * These variables are used in ln_save_node.
                   */

                  current_article->queued = yes;
                  current_article->gap = gap_count;

                  other_article->queue_count++;
                  break;
               }

         if ( current_article->queued )
            break;

         /* 
          * If we cannot find this references advance to the next one, and
          * look for it, until match is found or list is exhausted.
          */

         ++gap_count;
      }
   }

   return;
}

/*
 * Deallocate entire tree.
 */

void ln_destroy_article_list( ln_node *article_list )
{
   ln_node *previous_article;

   while( article_list->next_node != NULL )
      article_list = article_list->next_node;

   do
   {
      previous_article = article_list->prev_node;
      ln_destroy_node( article_list );
      article_list = previous_article;
   }
   while( article_list != NULL );

   return;
}

/*
 * Top level wrapper function. 
 */

int ln_thread_spool( char *group_name )
{
   char spool_path[ LN_BUFFER_SIZE ], temp_spool_path[ LN_BUFFER_SIZE ], 
   read_path[ LN_BUFFER_SIZE ], temp_read_path[ LN_BUFFER_SIZE ], 
   thread_path[ LN_BUFFER_SIZE ];

   FILE *spool, *read, *temp, *temp_read, *thread;

   ln_node *article_list, *current_article;


   snprintf( spool_path, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", 
             getenv( "HOME" ), group_name );

   if (( spool = fopen( spool_path, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_thread_spool: could not open file %s.",
                spool_path );
      return -2;
   }

   if (( article_list = ln_get_article_list( group_name, spool )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_thread_spool: empty spool: %s.", group_name );
      return -2;
   }

   /*
    * Thread the list
    */

   ln_thread_list( article_list );
   ln_sort_queues( article_list );

   snprintf( temp_spool_path, LN_BUFFER_SIZE, "%s:temp", spool_path );
   if (( temp = fopen( temp_spool_path, "w" )) == NULL )
   {
      ln_destroy_article_list( article_list );
      fclose( spool );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_thread_spool: could not open file %s.",
                temp_spool_path );
      return -1;
   }

   snprintf( read_path, LN_BUFFER_SIZE, "%s:read", spool_path );
   if (( read = fopen( read_path, "r" )) == NULL )
   {
      if ( errno != ENOENT )
      {
         ln_destroy_article_list( article_list );
         fclose( spool );
         fclose( temp );
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_thread_spool: could not open file %s.",
                   read_path );
         return -1;
      }
   }

   snprintf( temp_read_path, LN_BUFFER_SIZE, "%s:temp", read_path );
   if (( temp_read = fopen( temp_read_path, "w" )) == NULL )
   {
      ln_destroy_article_list( article_list );
      fclose( spool );
      fclose( temp );
      if ( read != NULL )
         fclose( read );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_thread_spool: could not open file %s.",
                temp_read_path );
      return -1;
   }

   snprintf( thread_path, LN_BUFFER_SIZE, "%s:threading", spool_path );
   if (( thread = fopen( thread_path, "w" )) == NULL )
   {
      ln_destroy_article_list( article_list );
      fclose( spool );
      if ( read != NULL )
         fclose( read );
      fclose( temp );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_thread_spool: could not open file %s.",
                thread_path );
      return -1;
   }

   for( current_article = article_list;
        current_article != NULL;
        current_article = current_article->next_node )
   {
      if ( current_article->queued )
         continue;

      if ( ln_save_node( current_article, 0, 
                         spool, read, temp, temp_read, thread ))
      {
         fclose( temp );
         fclose( temp_read );
         fclose( spool );
         if ( read != NULL )
            fclose( read );

         remove( temp_spool_path );
         remove( temp_read_path );
         fclose( thread );

         ln_destroy_article_list( article_list );
         return -1;
      }
   }

   fclose( temp );
   fclose( spool );

   remove( spool_path );
   rename( temp_spool_path, spool_path );

   fclose( temp_read );
   if ( read != NULL )
      fclose( read );

   remove( read_path );
   rename( temp_read_path, read_path );

   fclose( thread );

   ln_destroy_article_list( article_list );

   return 0;
}

void ln_sort_this_queue( ln_node *node, unsigned int queue_count, 
                         char toplevel )
{
   ln_node *current_article, *temp_list;

   struct {

      char *date;
      unsigned int ordinal;

   } *array;

   unsigned int i, j;


   current_article = node;

   if ( !toplevel )
      for( current_article = node;
           current_article != NULL;
           current_article = ( ln_node *)current_article->queue_next )
         if ( current_article->queue_count )
            ln_sort_this_queue( current_article->queue_head, 
                                current_article->queue_count, 0 );

   if ( queue_count < 2 )
      return;

   if (( array = calloc( queue_count, sizeof *array )) == NULL )
      ln_allocation_error();

   if (( temp_list = calloc( queue_count, sizeof *temp_list )) == NULL )
      ln_allocation_error();

   current_article = node;
   for( i = 0; i < queue_count; ++i )
   {
      array[ i ].date = current_article->converted_date;
      array[ i ].ordinal = i;
      
      /* struct assignment */

      temp_list[ i ] = *current_article;

      current_article 
         = (( toplevel ) ? ( ln_node *)current_article->next_node :
                           ( ln_node *)current_article->queue_next );
   }

   qsort( array, queue_count, sizeof *array, ln_compare );
   
   current_article = node;
   for( i = 0; i < queue_count; ++i )
   {
      j = array[ i ].ordinal;

      current_article->position       = temp_list[ j ].position;
      current_article->size           = temp_list[ j ].size;
      current_article->offset         = temp_list[ j ].offset;
      current_article->gap            = temp_list[ j ].gap;
      current_article->queue_count    = temp_list[ j ].queue_count;
      current_article->queued         = temp_list[ j ].queued;
      current_article->message_id     = temp_list[ j ].message_id;
      current_article->subject        = temp_list[ j ].subject;
      current_article->converted_date = temp_list[ j ].converted_date;
      current_article->references     = temp_list[ j ].references;

      current_article->queue_head = temp_list[ j ].queue_head;
      current_article->queue_tail = temp_list[ j ].queue_tail;

      current_article =
         (( toplevel ) ? ( ln_node *)current_article->next_node :
                         ( ln_node *)current_article->queue_next );
   }

   free( array );
   free( temp_list );

   return;
}

void ln_sort_queues( ln_node *article_list )
{
   ln_node *current_article;


   for( current_article = article_list;
        current_article != NULL;
        current_article = ( ln_node *)current_article->next_node )
   {
      if ( current_article->queued )
         continue;
      
      if ( current_article->queue_count )
         ln_sort_this_queue( ( ln_node *)current_article->queue_head,
                             current_article->queue_count, 0 );
   }

   return;
}
