/*
   News Peruser Copyright (c) 1996-1998 James Bailie
   ==================================================================

   News Peruser is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2, or (at
   your option) any later version.

   News Peruser is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   Although News Peruser is licensed under the Free Software
   Foundation's GNU General Public License, Peruser is not produced
   by, nor is it endorsed by the Free Software Foundation. The Free
   Software Foundation is not responsible for developing,
   distributing, or supporting Peruser in any way. Anyone may place
   software they own the copyright to, under the GNU General Public
   License.

   The GNU General Public License is included in the News Peruser 
   distribution archive in a file called COPYING. If you do
   not have a copy of the license, you can download one from
   ftp://prep.ai.mit.edu, or you can write to the Free Software
   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.

   =====================================================================
*/

#include "libnews.h"
#include<sys/types.h>
#include<regex.h>
#include<unistd.h>

/*
 * Wrapper functions.
 */

int ln_add_inbox( char *new )
{
   return ln_add_line( ".peruser3-inboxes", new );
}

int ln_add_folder( char *new )
{
   return ln_add_line( ".peruser3-folders", new );
}

int ln_add_persistent( char *new )
{
   return ln_add_line( ".peruser3-persistent", new );
}

int ln_add_address( char *new )
{
   return ln_add_line( ".peruser3-addresses", new );
}

/*
 * Adds a specified line to a text file.
 */

int ln_add_line( char *filename, char *new )
{
   char buffer[ LN_BUFFER_SIZE ];
   FILE *file;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", getenv( "HOME" ), filename );
   if (( file = fopen( buffer, "a" )) == NULL )
   {
      if ( errno == ENOENT )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
               "libnews: ln_add_line: ~/%s does not exist.", buffer );
         return -2;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE,
            "libnews: ln_add_line: could not open file %s.",
            buffer );
      return -1;
   }

   fprintf( file, "%s\n", new );

   fclose( file );

   return 0;
}

/*
 * Wrapper functions.
 */

int ln_remove_inbox( char *old )
{
   return ln_remove_line( ".peruser3-inboxes", old );
}

int ln_remove_folder( char *old )
{
   return ln_remove_line( ".peruser3-folders", old );
}

int ln_remove_persistent( char *old )
{
   return ln_remove_line( ".peruser3-persistent", old );
}

int ln_remove_address( char *old )
{
   return ln_remove_line( ".peruser3-addresses", old );
}

/*
 * Removes a specified line from a text file.
 */

int ln_remove_line( char *filename, char *old )
{
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
   *home;
   FILE *file, *temp;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", home = getenv( "HOME" ),
             filename );
   if (( file = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_remove_line: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ".tmp" );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( file );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_remove_line: could not open file %s.",
                buffer );
      return -1;
   }

   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
   {
      if ( !strcmp( strtok( buffer, "\n" ), old ))
         continue;

      fprintf( temp, "%s\n", buffer );
   }

   fclose( file );
   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", home, filename );
   strcpy( second_buffer, buffer );
   strcat( second_buffer, ".tmp" );
   rename( second_buffer, buffer );
   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", 
             home, strtok( old, "\t" ));
   remove( buffer );

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s:ids", buffer );
   remove( second_buffer );

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s:requests", buffer );
   remove( second_buffer );
   
   snprintf( second_buffer, LN_BUFFER_SIZE, "%s:threading", buffer );
   remove( second_buffer );

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s:read", buffer );
   remove( second_buffer );

   return 0;
}

/*
 * Wrapper functions.
 */

int ln_sort_inboxes()
{
   return ln_sort_file( ".peruser3-inboxes" );
}

int ln_sort_folders()
{
   return ln_sort_file( ".peruser3-folders" );
}

int ln_sort_persistent()
{
   return ln_sort_file( ".peruser3-persistent" );
}

int ln_sort_addresses()
{
   return ln_sort_file( ".peruser3-addresses" );
}

/*
 * Sorts lines in a text file. Filename path must be relative to home
 * directory.
 */

int ln_sort_file( char *filename )
{
   unsigned int i, count;
   char **array, buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
   *home;
   FILE *file, *temp;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", home = getenv( "HOME" ),
             filename );
   if (( file = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_sort_file: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ".tmp" );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( file );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_sort_file: could not open file %s.",
                buffer );
      return -1;
   }

   count = 0;
   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
      ++count;

   if (( array = calloc( count, sizeof *array )) == NULL )
      ln_allocation_error();

   rewind( file );
   for( i = 0; i < count; ++i )
   {
      fgets( buffer, LN_BUFFER_SIZE, file );

      if (( array[ i ] = malloc( sizeof( buffer ) + 1 )) == NULL )
         ln_allocation_error();

      strcpy( array[ i ], buffer );
   }

   fclose( file );

   qsort( array, count, sizeof *array, ln_compare );

   for( i = 0; i < count; ++i )
   {
      fputs( array[ i ], temp );
      free( array [ i ] );
   }

   free( array );

   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", home, filename );
   strcpy( second_buffer, buffer );
   strcat( second_buffer, ".tmp" );

   rename( second_buffer, buffer );

   return 0;
}

/*
 * Wrapper functions. 
 */

int ln_replace_inbox( char *old, char *new )
{
   return ln_replace_line( ".peruser3-inboxes", old, new );
}

int ln_replace_folder( char *old, char *new )
{
   return ln_replace_line( ".peruser3-folders", old, new );
}

int ln_replace_persistent( char *old, char *new )
{
   return ln_replace_line( ".peruser3-persistent", old, new );
}

int ln_replace_address( char *old, char *new )
{
   return ln_replace_line( ".peruser3-addresses", old, new );
}

/*
 * Replaces specified line in text file.
 */

int ln_replace_line( char *filename, char *old, char *new )
{
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
   *home;
   FILE *file, *temp;
   int length;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", 
         home = getenv( "HOME" ), filename );
   if (( file = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_replace_line: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ".tmp" );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( file );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_replace_line: could not open file %s.",
                buffer );
      return -1;
   }

   length = strlen( old );

   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
   {
      if ( !strncmp( buffer, old, length ))
      {
         fprintf( temp, "%s\n", new );
         continue;
      }

      fputs( buffer, temp );
   }

   fclose( temp );
   fclose( file );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", home, filename );
   strcpy( second_buffer, buffer );
   strcat( second_buffer, ".tmp" );

   rename( second_buffer, buffer );

   return 0;
}

/*
 * Wrapper functions. 
 */

int ln_move_inbox( unsigned int leader, unsigned int follower )
{
   return ln_move_line( leader, follower, ".peruser3-inboxes" );
}

int ln_move_folder( unsigned int leader, unsigned int follower )
{
   return ln_move_line( leader, follower, ".peruser3-folders" );
}

int ln_move_persistent( unsigned int leader, unsigned int follower )
{
   return ln_move_line( leader, follower, ".peruser3-persistent" );
}

int ln_move_address( unsigned int leader, unsigned int follower )
{
   return ln_move_line( leader, follower, ".peruser3-addresses" );
}

/*
 * Compares article headers in a newsgroup spool against a regular expression
 * associated with a virtual newsgroup, copying articles which have a match
 * into the virtual newsgroup's spool.
 */

int ln_update_folder( char *folder_name, char *group, 
                      int ( *callback )( void *data, unsigned int i, 
                                         char *filter, char *folder ),
                      void *data )
{
   FILE *spool, *read, *temp, *folder, *ids;
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
   *home, *pointer;
   enum{ NO, YES }found, dup;

   regex_t regex;
   int result;
   unsigned int i;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-folders", 
             home = getenv( "HOME" ) );
   if (( folder = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_update_folder: could not open file %s.",
                buffer );
      return -1;
   }

   found = NO;
   while( fgets( buffer, LN_BUFFER_SIZE, folder ) != NULL )
   {
      if ( !strcmp( strtok( buffer, "\t" ), folder_name ))
      {
         found = YES;
         break;
      }
   }

   fclose( folder );

   if ( !found )
   {
      strcpy( ln_error_message, "libnews: ln_update_folder: folder name "
              "not found in ~/.peruser3-folders." );
      return -2;
   }

   if (( result = regcomp( &regex, strtok( NULL, "\n" ), REG_EXTENDED )))
   {
      strcpy( ln_error_message, "libnews: ln_update_folder: " );
      regerror( result, &regex, buffer, LN_BUFFER_SIZE );
      strcat( ln_error_message, buffer );
      return -2;
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home, 
             folder_name );
   if (( folder = fopen( buffer, "a+" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_update_folder: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ":read" );
   if (( read = fopen( buffer, "a+" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_update_folder: could not open file %s.",
                buffer );
      fclose( folder );
      return -1;
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", home );
   if (( temp = fopen( buffer, "w+" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_update_folder: could not open file %s.",
                buffer );
      fclose( folder );
      fclose( read );
      return -1;
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s",
             home, group );
   if (( spool = fopen( buffer, "r" )) == NULL )
   {
      fclose( folder );
      fclose( read );
      fclose( temp );

      if ( errno == ENOENT )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_update_folder: spool does not exist: %s.",
                   buffer );
         return -2;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_update_folder: could not open file %s.",
                buffer );

      return -1;
   }

   if ( fgets( buffer, LN_BUFFER_SIZE, spool ) == NULL )
   {
      fclose( spool );
      fclose( read );
      fclose( folder );
      fclose( temp );

      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_update_folder:"
                " empty spool: %s.", group );
      return -2;
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:ids", home, 
             folder_name );
   if (( ids = fopen( buffer, "a+" )) == NULL )
   {
      fclose( spool );
      fclose( read );
      fclose( folder );
      fclose( temp );

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_update_folder: could not open file %s.",
                buffer );
      return -1;
   }

   rewind( spool );

   i = 0;
   while( fgets( buffer, LN_BUFFER_SIZE, spool ) != NULL )
   {
      if ( callback != NULL )
         if ( callback( data, ++i, folder_name, group ))
            break;

      while( strncmp( buffer, ".\r\n", 3 ) && strncmp( buffer, "\r\n", 2 ))
      {
         fputs( buffer, temp );

         if ( fgets( buffer, LN_BUFFER_SIZE, spool ) == NULL )
         {
            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_update_folder:"
                      " premature end of spool: %s", group );
            fclose( spool );
            fclose( read );
            fclose( temp );
            fclose( folder );
            return -1;
         }
      }

      fputs( buffer, temp );
      fflush( temp );
      rewind( temp );

      found = NO;
      while( fgets( buffer, LN_BUFFER_SIZE, temp ) != NULL )
      {
         if (( result = regexec( &regex, buffer, 0, NULL, 0 )))
         {
            if ( result == REG_NOMATCH )
               continue;

            strcpy( ln_error_message, "libnews: ln_update_folder: " );
            regerror( result, &regex, buffer, LN_BUFFER_SIZE );
            strcat( ln_error_message, buffer );

            fclose( temp );
            fclose( read );
            fclose( spool );
            fclose( folder );
            return -1;
         }

         rewind( ids );
         rewind( temp );

         while( strncmp( fgets( buffer, LN_BUFFER_SIZE, temp ),
                         "Message-ID: ", 12 ));
         pointer = strchr( buffer, '<' );

         dup = NO;
         while( fgets( second_buffer, LN_BUFFER_SIZE, ids ) != NULL )
            if ( !strcmp( pointer, second_buffer ))
            {
               dup = YES;
               break;
            }

         if ( dup )
         {
            while( fgets( buffer, LN_BUFFER_SIZE, temp ) != NULL );
            break;
         }

         fflush( ids );
         fseek( ids, 0, SEEK_END );
         fputs( pointer, ids );
         fflush( ids );

         rewind( temp );
         while( fgets( buffer, LN_BUFFER_SIZE, temp ) != NULL )
            fputs( buffer, folder );

         fputs( "u\n", read );

         found = YES;
         break;
      }

      if ( buffer[ 0 ] != '.' )
         do
         {
            fgets( buffer, LN_BUFFER_SIZE, spool );
            if ( found )
               fputs( buffer, folder );
         }
         while( strncmp( buffer, ".\r\n", 3 ));

      ftruncate( fileno( temp ), 0 );
      rewind( temp );
   }

   fclose( temp );
   fclose( read );
   fclose( spool );
   fclose( folder );
   fclose( ids );

   regfree( &regex );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", home );
   remove( buffer );

   return 0;
}

/*
 * Returns a pointer to list of requests on file for a virtual newsgroup in
 * value-result argument list.
 */

int ln_get_folder_list( char *group, char *folder, ln_requests_list **list,
      unsigned int *count )
{
   char *pointer, buffer[ LN_BUFFER_SIZE ];

   FILE *file;
   ln_requests_list *list_pointer;


   *count = 0;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests",
             getenv( "HOME" ), folder );
   if (( file = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "libnews: ln_get_folder_list: "
                "could not open file %s.", buffer );

      return -2;
   }

   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
   {
      pointer = strrchr( buffer, ':' );
      if ( !strcmp( strtok( ++pointer, "\n" ), group ))
         ++( *count );
   }

   if ( !( *count ))
   {
      *list = NULL;
      fclose( file );
      return -2;
   }

   if ( ( *list = calloc( *count, sizeof **list )) == NULL )
      ln_allocation_error();

   list_pointer = *list;
   rewind( file );

   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
   {
      pointer = strrchr( buffer, ':' );
      if ( !strcmp( strtok( ++pointer, "\n" ), group ))
      {
         if (( list_pointer->request = strdup( strtok( buffer, ":" ))) 
               == NULL )
            ln_allocation_error();

         list_pointer->found = not;
         list_pointer++;
      }
   }

   fclose( file );

   return 0;
}

/*
 * Copies specifed article from spool file to persistent folder.
 */

int ln_file_article( char *group_name, char *server, unsigned int i, 
                     char *folder_name ) 
{
   char *home, buffer[ LN_BUFFER_SIZE ];
   FILE *spool, *folder;


   home = getenv( "HOME" );
   if ( !strncmp( group_name, "Posted", 6 ))
      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-POSTED",
                home, server );
   else
      if ( !strncmp( group_name, "Follow-ups", 10 ))
         snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-FOLLOW-UPS",
                   home, server );
      else
         snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s",
                   home, group_name );

   if (( spool = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_file_article: "
                "could not open file %s.", buffer );
      return -1;
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home,
             folder_name );
   if (( folder = fopen( buffer, "a" )) == NULL )
   {
      fclose( spool );

      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_file_article: "
                "could not open file %s.", buffer );
      return -1;
   }

   while( i-- )
      do
         if ( fgets( buffer, LN_BUFFER_SIZE, spool ) == NULL )
         {
            fclose( spool );
            fclose( folder );

            strcpy( ln_error_message, "libnews: ln_file_article: "
                    "premature end of spool." );
            return -1;
         }
      while( strncmp( buffer, ".\r\n", 3 ));

   do
   {
      if ( fgets( buffer, LN_BUFFER_SIZE, spool ) == NULL )
      {
         fclose( spool );
         fclose( folder );

         strcpy( ln_error_message, "libnews: ln_file_article: "
                 "premature end of spool." );
         return -1;
      }

      fputs( buffer, folder );
   }
   while( strncmp( buffer, ".\r\n", 3 ));

   fclose( spool );
   fclose( folder);

   return 0;
}
