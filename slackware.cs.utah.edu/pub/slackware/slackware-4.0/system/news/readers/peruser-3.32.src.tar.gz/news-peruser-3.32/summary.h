/*
 * Prototypes.
 */

void tree_init( void *this, void *parent, EZ_Widget *frame,
      void *newsreader );
void tree_set_tree( void *this );
void tree_destroy( void *this );
void tree_destroy_lists( unsigned int groups, ln_group_list *list,
                         unsigned int servers, ln_server_list *server_list );
void tree_update_lists( void *tree_object );
void tree_collapse_server( void *this, unsigned int server );
void tree_update_node( void *this, EZ_Widget *list, np_group_state state );
void tree_normal_callback( EZ_Widget *list_tree, void *this );
void tree_motion_callback( EZ_Widget *list_tree, void *this );
int tree_dnd_encoder( EZ_Item *item, void *data, char **message,
                      int *length, int *needfree );
int tree_dnd_reorder_decoder( EZ_Item *item, void *data, char *message, 
                              int length );
int tree_dnd_add_decoder( EZ_Item *item, void *data, char *message,
                          int length );
int tree_dnd_folders_decoder( EZ_Item *item, void *data, char *message,
                              int length );

/* 
 * Prototypes.
 */

void summary_init( void *this, void *parent );
void summary_show_stats( void *this );
void summary_set_tree( void *this, EZ_Widget *tree, 
                       char *group_name, unsigned int total, 
                       unsigned int group );
void summary_tree_motion_callback( EZ_Widget *tree, void *data );
void summary_tree_normal_callback( EZ_Widget *tree, void *data );
void summary_update_tree( void *this, EZ_Widget *tree );
unsigned int summary_dive_for_the_unseen( void *this, unsigned int i, 
                                          unsigned int *unread );
unsigned int summary_dive_and_alter_threading( void *this, unsigned int i, 
                                               char top );
unsigned int summary_dive_and_change_state( void *this, unsigned int i,
                                            np_node_state state );
unsigned int summary_dive_for_the_count( void *this, unsigned int i );
void summary_hide_headers( void *this );
void summary_clear_tree( void *this );
void summary_update_summary( void *this );
void summary_create_local_times( void *this );
void summary_contents_destroy( ln_group_summary *contents,
                               unsigned int total );
void summary_recursively_descend_thread( void *this,
                                         unsigned int depth,
                                         np_toplevel *toplevel,
                                         EZ_Item *item,
                                         EZ_TreeNode **tree_node );
void summary_toplevel_stack( np_toplevel *toplevel, np_stack_op what );
EZ_Item *summary_create_missing_item();
void summary_destroy( void *this );
void summary_callback( EZ_Widget *widget, void *data );
void summary_subject_callback( EZ_Widget *widget, void *data );
void summary_poster_callback( EZ_Widget *widget, void *data );
void summary_date_callback( EZ_Widget *widget, void *data );
void summary_list_callback( EZ_Widget *widget, void *data );
void summary_reorder( np_order order, void *data );
void summary_done_callback( EZ_Widget *widget, void *data );
int summary_dnd_encoder( EZ_Item *item, void *data, char **message,
                         int *length, int *needfree );
