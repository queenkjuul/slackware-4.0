/*
 * Prototypes.
 */

void newsrc_init( void *parent );
void newsrc_callback( EZ_Widget *widget, void *data );
void newsrc_done_callback( EZ_Widget *widget, void *data );
void newsrc_tree_normal_callback( EZ_Widget *widget, void *data );
void newsrc_tree_motion_callback( EZ_Widget *widget, void *data );
void newsrc_animate( EZ_Widget *widget, void *data );
void newsrc_confirm( void *this, char *message, 
                     np_button_type button  );
void newsrc_confirm_callback( EZ_Widget *widget, void *data );
void newsrc_new_group_callback( EZ_Widget *widget, void *data );
void newsrc_new_server_callback( EZ_Widget *widget, void *data );
void newsrc_remove_server_config( void *this, unsigned int i );
void newsrc_radio_callback( EZ_Widget *widget, void *data );
void newsrc_list_button_callback( EZ_Widget *widget, void *data );
void newsrc_sort_callback( EZ_Widget *widget, void *data );
void newsrc_kill_callback( EZ_Widget *widget, void *data );
void newsrc_list_normal_callback( EZ_Widget *widget, void *data );
void newsrc_search_callback( EZ_Widget *widget, void *data );
void newsrc_select_node( void *tree_object );
void newsrc_authinfo_callback( EZ_Widget *widget, void *data );
