/*
 * Prototypes.
 */

void search_init( void *parent );
void search_callback( EZ_Widget *widget, void *data );
void search_done_callback( EZ_Widget *widget, void *data );
void search_entry_callback( EZ_Widget *widget, void *data );
void search_list_motion_callback( EZ_Widget *widget, void *data );
