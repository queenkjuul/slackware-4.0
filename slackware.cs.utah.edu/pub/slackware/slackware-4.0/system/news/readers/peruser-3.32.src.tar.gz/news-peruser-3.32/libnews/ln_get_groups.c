/*
   News Peruser Copyright (c) 1996-1998 James Bailie
   ==================================================================

   News Peruser is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2, or (at
   your option) any later version.

   News Peruser is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   Although News Peruser is licensed under the Free Software
   Foundation's GNU General Public License, Peruser is not produced
   by, nor is it endorsed by the Free Software Foundation. The Free
   Software Foundation is not responsible for developing,
   distributing, or supporting Peruser in any way. Anyone may place
   software they own the copyright to, under the GNU General Public
   License.

   The GNU General Public License is included in the News Peruser 
   distribution archive in a file called COPYING. If you do
   not have a copy of the license, you can download one from
   ftp://prep.ai.mit.edu, or you can write to the Free Software
   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.

   =====================================================================
*/

#include "libnews.h"

#include<errno.h>
#include<string.h>

/*
 * Called when malloc or calloc returns NULL.
 */

void ln_allocation_error()
{
   fprintf( stderr, "libnews: out of memory, aborting.\n" );
   exit( EXIT_FAILURE );
}

/*
 * Returns total number of articles in specified group.
 */

unsigned int ln_get_total( char *group_name, char *home, char *server )
{
   unsigned int result;
   char buffer[ LN_BUFFER_SIZE ];
   FILE *spool;


   if ( !strncmp( group_name, "Follow-ups", 10 ))
      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-FOLLOW-UPS",
                home, server );
   else
      if ( !strncmp( group_name, "Posted", 6 ))
         snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-POSTED",
                   home, server );
      else
         snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", 
                   home, group_name );

   if (( spool = fopen( buffer, "r" )) == NULL )
      if ( errno == ENOENT )
         return 0;
      else
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "Could not open file %s.", buffer );
         return -1;
      }

   result = 0;
   while( fgets( buffer, LN_BUFFER_SIZE, spool ) != NULL )
      if ( !strncmp( buffer, ".\r\n", 3 ))
         ++result;

   fclose( spool );

   return result;
}

/*
 * Returns number of requests on file for specified group.
 */

unsigned int ln_count_requests( char *group_name, char *home )
{
   char buffer[ LN_BUFFER_SIZE ];
   FILE *requests;
   unsigned int result;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests",
             home, group_name );
   if (( requests = fopen( buffer, "r" )) == NULL )
      if ( errno == ENOENT )
         return 0;
      else
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_count_requests: could not open file %s.",
                   buffer );
         return -1;
      }

   result = 0;

   while( fgets( buffer, LN_BUFFER_SIZE, requests ) != NULL )
      ++result;

   fclose( requests );

   return result;
}

/*
 * Returns number of unseen articles in specified group.
 */

unsigned int ln_get_unread( char *group_name, char *home )
{
   char buffer[ LN_BUFFER_SIZE ];
   FILE *read;
   unsigned int result;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:read", home, 
             group_name );
   if (( read = fopen( buffer, "r" )) == NULL )
      if ( errno == ENOENT )
         return 0;
      else
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_get_unread: could not open file %s.",
                   buffer );
         return -1;
      }

   result = 0;

   while( fgets( buffer, LN_BUFFER_SIZE, read ) != NULL )
      if ( buffer[ 0 ] == 'u' )
         result++;

   fclose( read );
   return result;
}

/*
 * Returns number of original, as-yet-unposted unposted articles on file for a
 * server.
 */

int ln_get_follow_ups( char *server )
{
   int result = 0;
   char buffer[ LN_BUFFER_SIZE ];
   FILE *file;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-FOLLOW-UPS",
             getenv( "HOME" ), server );

   if (( file = fopen( buffer, "r" )) == NULL )
      if ( errno == ENOENT )
         return result;
      else
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_get_follow_ups: could not open file %s.",
                   buffer );
         return -1;
      }

   if ( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
      result = 1;

   fclose( file );

   return result;
}

/*
 * Creates entries in the passed ln_group_list and ln_server_list arrays for
 * the two phony groups that hold outgoing articles, the Follow-ups group and
 * the Posted group.
 */

int ln_make_outgoing( unsigned int i, unsigned int j, 
                      ln_group_list **l_pointer, 
                      ln_server_list **s_pointer, char *home )
{
   ln_group_list *list_pointer;
   ln_server_list *server_pointer;

   long int result;


   list_pointer = *l_pointer;
   server_pointer = *s_pointer;

   /* Follow-ups */

   if (( list_pointer[ i ].group = strdup( "Follow-ups" )) == NULL )
      ln_allocation_error();

   if (( list_pointer[ i ].server = strdup( server_pointer[ j - 1 ].server ))
         == NULL )
      ln_allocation_error();

   if (( result = ln_get_total( list_pointer[ i ].group, home, 
                                list_pointer[ i ].server )) < 0 )
      return -1;

   list_pointer[ i ].total = result;
   list_pointer[ i ].server_idx = j - 1;
   list_pointer[ i ].unread = 0;
   list_pointer[ i++ ].requests = 0;

   /* Posted */

   if (( list_pointer[ i ].group = strdup( "Posted" )) == NULL )
      ln_allocation_error();

   if (( list_pointer[ i ].server = strdup( server_pointer[ j - 1 ].server ))
         == NULL )
      ln_allocation_error();

   if (( result = ln_get_total( list_pointer[ i ].group, home,
         list_pointer[ i ].server )) < 0 )
      return -1;

   list_pointer[ i ].total = result;
   list_pointer[ i ].server_idx = j - 1;
   list_pointer[ i ].unread = 0;
   list_pointer[ i++ ].requests = 0;

   return 0;

}

int ln_make_outboxes( unsigned int i, unsigned int j,
                      ln_group_list **groups, ln_server_list **servers, 
                      char *home )
{
   int result;

   ln_group_list *group_list;
   ln_server_list *server_list;

   group_list = *groups;
   server_list = *servers;


   if (( group_list[ i ].group = strdup( "::Outbox" )) == NULL )
      ln_allocation_error();

   if (( group_list[ i ].server = strdup( server_list[ j ].server )) == NULL )
      ln_allocation_error();

   if (( result = ln_get_total( group_list[ i ].group, home, 
                                group_list[ i ].server )) < 0 )
      return -1;

   group_list[ i ].total = result;
   group_list[ i ].server_idx = j;
   group_list[ i ].unread = 0;
   group_list[ i ].requests = 0;

   if (( group_list[ ++i ].group = strdup( "::Sent-Mail" )) == NULL )
      ln_allocation_error();
   
   if (( group_list[ i ].server = strdup( server_list[ j ].server )) == NULL )
      ln_allocation_error();

   if (( result = ln_get_total( group_list[ i ].group, home,
                                group_list[ i ].server )) < 0 )
      return -1;

   group_list[ i ].total = result;
   group_list[ i ].server_idx = j;
   group_list[ i ].unread = 0;
   group_list[ i ].requests = 0;
   
   return 0;
}

/*
 * Returns an ln_group_list array, and an ln_server_list array. Both structs
 * are defined in libnews.h.
 */

int ln_get_groups( unsigned int *count, ln_group_list **list,
                   unsigned int *servers, ln_server_list **server_list )
{
   unsigned int i, j, idx, server_count;
   long int result;
   char buffer[ LN_BUFFER_SIZE ], *pointer, *home;
   FILE *newsrc;

   ln_group_list *list_pointer;  
   ln_server_list *server_pointer;

   home = getenv( "HOME" );
   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", home );
   if (( newsrc = fopen( buffer, "r" )) == NULL ) 
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_get_groups: could not open file: %s.",
                buffer );

      *count = 0;
      *servers = 0;
      *list = NULL;
      *server_list = NULL;
      
      return -2;
   }

   *servers = 0;

   for( *count = 1; !feof( newsrc ); ( *count )++ ) 
   {
      if ( fgets( buffer, LN_BUFFER_SIZE, newsrc ) == NULL ||
            buffer[ 0 ] == '\n' )
      {
         ( *count )--;
         break;
      }

      if ( strtok( buffer, ":" ) == NULL )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_get_groups: "
                   "malformed line %d in ~/.peruser3-newsrc.",
                   *count );

         *count = 0;
         fclose( newsrc );
         return -1;
      }

      if ( !( strspn( buffer, " \t" )))
      {
         --( *count );
         ++( *servers );
      }
   }

   if ( !( *servers ) )
   {
      strcpy( ln_error_message,
              "libnews: ln_get_groups: "
              "zero servers in ~/.peruser3-newsrc.\n" );
      fclose( newsrc );
      *list = NULL;
      *server_list = NULL;

      return -2;
   }

   rewind( newsrc );

   *count += ( *servers ) * 2;

   if (( list_pointer = *list = calloc( *count, sizeof **list ))
         == NULL )
      ln_allocation_error();

   if (( server_pointer
         = *server_list = calloc( *servers, sizeof **server_list )) == NULL )
      ln_allocation_error();

   j = i = server_count = 0 ;

   while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
   {
      if ( buffer[ 0 ] == '\n' )
         break;

      if ( !( idx = strspn( buffer, " \t" )))
      {
         if (( server_pointer[ j ].server 
               = strdup( strtok( buffer, "\n" ))) == NULL )
            ln_allocation_error();

         if ( j )
         {
            server_pointer[ j - 1 ].groups = server_count + 2;
            server_pointer[ j - 1 ].first =
               (( j == 1 ) ? 0 : i + 1 - server_count );
         }

         server_pointer[ j ].follow_ups
            = ln_get_follow_ups( server_pointer[ j ].server );

         if ( i )
         {
            if ( ln_make_outgoing( i, j, &list_pointer, &server_pointer, 
                                   home ))
            {
               fclose( newsrc );
               return -1;
            }
            i += 2;
         }

         server_count = 0;
         j++;

         continue;
      }

      pointer = buffer;
      while( idx-- )
         pointer++;

      if (( list_pointer[ i ].group = strdup( strtok( pointer, ":" ))) 
            == NULL )
         ln_allocation_error();

      if (( list_pointer[ i ].server = 
            strdup( server_pointer[ j - 1 ].server )) == NULL )
         ln_allocation_error();

      if (( result = ln_get_total( list_pointer[ i ].group, home, NULL )) < 0 )
         return -1;

      list_pointer[ i ].total = result;

      if (( result = ln_get_unread( list_pointer[ i ].group, home )) < 0 )
         return -1;

      list_pointer[ i ].unread = result;

      if (( result = ln_count_requests( list_pointer[ i ].group, home )) < 0 )
         return -1;

      list_pointer[ i ].requests = result;
      list_pointer[ i ].server_idx = j - 1;

      list_pointer[ i ].delete = 0;
      
      ++server_count;
      ++i;
   }

   fclose( newsrc );

   server_pointer[ j - 1 ].groups = server_count + 2;
   server_pointer[ j - 1 ].first = i - server_count;
   if ( ln_make_outgoing( i, j, &list_pointer, &server_pointer, home ))
      return -1;

   return 0;
}

/*
 * Adds entries for any virtual groups the user has created to both a passed
 * array of ln_server_list structs and a passed array of ln_group_list
 * structs.
 */

int ln_get_virtual( unsigned int *groups, ln_group_list **group_list,
                    unsigned int *servers, ln_server_list **server_list )
{
   char buffer[ LN_BUFFER_SIZE ], *home;
   FILE *file;
   unsigned int i, old_groups;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-folders", 
         home = getenv( "HOME" ));
   if (( file = fopen( buffer, "r" )) == NULL )
   {
      if ( errno == ENOENT )
      {
         strcpy( ln_error_message,
                 "libnews: ln_get_virtual: "
                 "~/.peruser3-folders does not exist." );
         return -2;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_get_virtual: could not open file %s.", buffer );
      return -1;
   }

   if ( fgets( buffer, LN_BUFFER_SIZE, file ) == NULL )
   {
      fclose( file );
      strcpy( ln_error_message,
              "libnews: ln_get_virtual: empty ~/.peruser3-folders" );
      return -2;
   }

   old_groups = *groups;

   do 
      ++( *groups );
   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL );

   rewind( file );

   if (( *server_list
         = realloc( *server_list, ++( *servers ) * sizeof **server_list ))
         == NULL )
      ln_allocation_error();

   if (( ( *server_list )[ *servers - 1 ].server = strdup( "Virtual" ))
         == NULL )
      ln_allocation_error();

   ( *server_list )[ *servers - 1 ].groups = *groups - old_groups;
   ( *server_list )[ *servers - 1 ].first = old_groups;

   if (( *group_list = realloc( *group_list, *groups * sizeof **group_list ))
         == NULL )
      ln_allocation_error();

   for( i = old_groups; i < *groups; ++i )
   {
      if ( fgets( buffer, LN_BUFFER_SIZE, file ) == NULL )
      {
         strcpy( ln_error_message,
                 "libnews: ln_get_virtual: "
                 "premature end of ~/.peruser3-folders." );
         fclose( file );
         return -1;
      }

      if (( ( *group_list )[ i ].group = strdup( strtok( buffer, "\t" )))
            == NULL )
         ln_allocation_error();

      if (( ( *group_list )[ i ].server = strdup( "Virtual" )) == NULL )
         ln_allocation_error();

      ( *group_list )[ i ].total = ln_get_total( buffer, home, NULL );
      ( *group_list )[ i ].unread = ln_get_unread( buffer, home );
      ( *group_list )[ i ].server_idx = *servers - 1;
   }

   return 0;
}

/* 
 * Adds entries for any persistent folders the user has create to both a
 * passed array of ln_group_list structs and a passed array of ln_server_list
 * structs.
 */

int ln_get_folders( unsigned int *groups, ln_group_list **group_list,
                    unsigned int *servers, ln_server_list **server_list )
{
   char buffer[ LN_BUFFER_SIZE ], *home;
   FILE *file;
   unsigned int i, old_groups;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-persistent",
             home = getenv( "HOME" ));
   if (( file = fopen( buffer, "r" )) == NULL )
   {
      if ( errno == ENOENT )
      {
         strcpy( ln_error_message, "libnews: ln_get_folders: "
                 "~/.peruser3-persistent does not exist." );
         return -2;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE, "libnews: ln_get_folders: "
                "could not open file %s.", buffer );
      return -1;
   }

   if ( fgets( buffer, LN_BUFFER_SIZE, file ) == NULL )
   {
      fclose( file );
      strcpy( ln_error_message, "libnews: ln_get_folders: "
              "empty ~/.peruser-persistent." );
      return -2;
   }

   old_groups = *groups;

   do
      ++( *groups );
   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL );

   rewind( file );

   if (( *server_list
         = realloc( *server_list, ++( *servers ) * sizeof **server_list ))
         == NULL )
      ln_allocation_error();

   if (( ( *server_list )[ *servers - 1 ].server = strdup( "Folders" ))
         == NULL )
      ln_allocation_error();

   ( *server_list )[ *servers - 1 ].groups = *groups - old_groups;
   ( *server_list )[ *servers - 1 ].first = old_groups;

   if (( *group_list = realloc( *group_list, *groups * sizeof **group_list ))
         == NULL )
      ln_allocation_error();

   for( i = old_groups; i < *groups; ++i )
   {
      if ( fgets( buffer, LN_BUFFER_SIZE, file ) == NULL )
      {
         strcpy( ln_error_message, "libnews: ln_get_folders: "
                 "premature end of ~/.peruser3-persistent." );
         fclose( file );
         return -1;
      }

      if (( ( *group_list )[ i ].group = strdup( strtok( buffer, "\n" )))
            == NULL )
         ln_allocation_error();

      if (( ( *group_list )[ i ].server = strdup( "Folders" )) == NULL )
         ln_allocation_error();

      ( *group_list )[ i ].total = ln_get_total( buffer, home, NULL );
      ( *group_list )[ i ].unread = ln_get_unread( buffer, home );
      ( *group_list )[ i ].server_idx = *servers - 1;
      ( *group_list )[ i ].delete = 0;
   }

   return 0;
}

int ln_get_inboxes( unsigned int *groups, ln_group_list **group_list,
                    unsigned int *servers, ln_server_list **server_list )
{
   char buffer[ LN_BUFFER_SIZE ], *home, no_inboxes;
   FILE *file;
   unsigned int i, old_groups;


   no_inboxes = 0;
   
   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-inboxes",
             home = getenv( "HOME" ));
   if (( file = fopen( buffer, "r" )) == NULL )
      if ( errno == ENOENT )
      {
         strcpy( ln_error_message, "libnews: ln_get_inboxes: "
                 "~/.peruser3-inboxes does not exist." );
         no_inboxes = 1;
      }
      else
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE, 
                   "libnews: ln_get_inboxes: "
                   "could not open file %s.", buffer );
         return -1;
      }
   
   if ( !no_inboxes )
      if ( fgets( buffer, LN_BUFFER_SIZE, file ) == NULL )
      {
         fclose( file );
         strcpy( ln_error_message, "libnews: ln_get_inboxes: "
                 "empty ~/.peruser3-inboxes." );
         no_inboxes = 1;
      }

   old_groups = *groups;

   if ( !no_inboxes )
      do
         ++( *groups );
      while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL );

   *groups += 2;

   if (( *server_list
            = realloc( *server_list, ++( *servers ) * sizeof **server_list ))
         == NULL )
      ln_allocation_error();

   if (( ( *server_list )[ *servers - 1 ].server = strdup( "Mailboxes" ))
         == NULL )
      ln_allocation_error();

   ( *server_list )[ *servers - 1 ].groups = *groups - old_groups;
   ( *server_list )[ *servers - 1 ].first = old_groups;

   if (( *group_list = realloc( *group_list, *groups * sizeof **group_list ))
         == NULL )
      ln_allocation_error();

   if ( !no_inboxes )
   {
      rewind( file );
      for( i = old_groups; i < *groups - 2; ++i )
      {
         if ( fgets( buffer, LN_BUFFER_SIZE, file ) == NULL )
         {
            strcpy( ln_error_message, "libnews: ln_get_inboxes: "
                    "premature end of ~/.peruser3-inboxes." );
            fclose( file );
            return -1;
         }

         if (( ( *group_list )[ i ].group = strdup( strtok( buffer, " \t" )))
             == NULL )
            ln_allocation_error();

         if (( ( *group_list )[ i ].server = strdup( "Mailboxes" )) == NULL )
            ln_allocation_error();

         ( *group_list )[ i ].total = ln_get_total( buffer, home, NULL );
         ( *group_list )[ i ].unread = ln_get_unread( buffer, home );
         ( *group_list )[ i ].server_idx = *servers - 1;
         ( *group_list )[ i ].delete = 0;
      }
      
      fclose( file );
   }
   else
      i = *groups - 2;
   
   if ( ln_make_outboxes( i, *servers - 1, group_list, server_list, home ))
      return -1;

   return 0;
}
