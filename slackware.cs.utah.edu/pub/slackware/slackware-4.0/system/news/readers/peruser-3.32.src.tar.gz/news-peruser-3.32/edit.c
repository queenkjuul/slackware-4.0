/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include<time.h>
#include<sys/stat.h>
#include<unistd.h>
#include "peruser.h"
#include "edit.h"
#include "uudeview.h"

/*
 * Constructor.
 */

void edit_init( void *parent )
{
   np_edit_object *edit;


   edit = ( np_edit_object *)(( np_buttons_object *)parent )->edit_object;
   edit->parent = ( np_buttons_object *)parent;

   edit->newsgroups = NULL;
   edit->attached = 0;
   edit->boundary = "-------------_-Kd4.,2fAbM:L((?+-------------";
   
   edit->whine = edit_whine;
   edit->compose_callback = edit_compose_callback;
   edit->edit_callback = edit_edit_callback;
   edit->create_message = edit_create_message;
   edit->get_text = edit_get_text;
   edit->replace_message = edit_replace_message;
   edit->text_callback = edit_text_callback;
   edit->get_email = edit_get_email;

   edit->delete_callback = edit_delete_callback;
   edit->expunge_callback = edit_expunge_callback;

   edit->crosspost_callback = edit_crosspost_callback;
   edit->crosspost_frame_callback = edit_crosspost_frame_callback;
   edit->crosspost_lists_callback = edit_crosspost_lists_callback;
   edit->destroy_newsgroup_list = edit_destroy_newsgroup_list;

   edit->attach_callback = edit_attach_callback;
   edit->attachment_frame_callback = edit_attachment_frame_callback;
   edit->cancel_message_callback = edit_cancel_message_callback;
   edit->supersede_callback = edit_supersede_callback;
   edit->split_message_callback = edit_split_message_callback;
   edit->get_header = edit_get_header;

   edit->addresses_callback = edit_addresses_callback;
   edit->add_address_callback = edit_add_address_callback;
   edit->address_list_motion_callback = edit_address_list_motion_callback;
   edit->replace_address_callback = edit_replace_address_callback;
   edit->sort_addresses_callback = edit_sort_addresses_callback;
   edit->remove_address_callback = edit_remove_address_callback;
   edit->addresses_done_callback = edit_addresses_done_callback;
   edit->address_list_callback = edit_address_list_callback;
   edit->update_addresses = edit_update_addresses;
   edit->address_dnd_reorder_encoder = edit_address_dnd_reorder_encoder;
   edit->address_dnd_reorder_decoder = edit_address_dnd_reorder_decoder;
   edit->address_dnd_add_decoder = edit_address_dnd_add_decoder;
   edit->get_recipients = edit_get_recipients;
   edit->addresses_cancel_callback = edit_addresses_cancel_callback;
   edit->grab_address_callback = edit_grab_address_callback;
   
   return;
}

/*
 * callback for items on compose menu.
 */

void edit_compose_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_newsreader_object *newsreader;
   np_summary_object *summary;
   np_tree_object *tree;
   np_buttons_object *buttons;
   np_newsrc_object *newsrc;
   np_message_object *message;

   EZ_TreeNode *selected;
   EZ_Item *item;

   char *from, *pointer, newsgroup[ LN_BUFFER_SIZE ];
   enum{ NO, YES }followup_to, folder;
   unsigned int i, j;
   ln_origin origin;

   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   tree = ( np_tree_object *)newsreader->tree_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   message = ( np_message_object *)newsreader->message_object;

   edit->editing = 0;

   /*
    * Close the currently-selected group's spoolfile, if it's open. 
    */

   ln_get_message_text( NULL, 0, 0, 0, NULL );

   if ( widget == buttons->original_button )
      origin = LN_ORIGINAL;
   else
      if ( widget == buttons->follow_up_button )
         origin = LN_FOLLOW_UP;
      else
         if ( widget == buttons->reply_button )
            origin = LN_REPLY;
         else
            if ( widget == buttons->forward_button )
               origin = LN_FORWARD;
            else
               origin = LN_MAIL;

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      if ( origin != LN_MAIL )
      {
         edit->whine( edit, 0 ); 
         return;
      }

   if ( selected == tree->root_node && origin != LN_MAIL )
      return;

   if ( origin != LN_MAIL )
   {
      item = EZ_TreeNodeGetItem( selected );
      i = ( unsigned int)EZ_GetItemIntData( item );

      if ( origin != LN_MAIL && *( char *)EZ_GetItemPtrData( item ) == 's' )
      {
         edit->whine( edit, 0 ); 
         return;
      }
   }

   if ( origin != LN_MAIL &&
        ( !strncmp( tree->group_list[ i ].group, "Follow-ups", 10 ) ||
          !strncmp( tree->group_list[ i ].group, "Posted", 6 ) ||
          (( !strncmp( tree->group_list[ i ].server, "Folders", 7 ) ||
             !strncmp( tree->group_list[ i ].server, "Virtual", 7 )) &&
           origin == LN_ORIGINAL )))
   {
      edit->whine( edit, 3 );
      return;
   }

   if ( origin == LN_FOLLOW_UP || origin == LN_REPLY || origin == LN_FORWARD )
   {
      if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
            == NULL )
      {
         edit->whine( edit, 1 );
         return;
      }

      j = ( unsigned int)EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

      if ( !summary->contents[ j ].is_article )
      {
         edit->whine( edit, 2 );
         return;
      }

      from = summary->contents[ j ].from;
   }
   else
      from = NULL;

   folder = NO;

   if ( origin != LN_MAIL )
      if ( !strncmp( tree->group_list[ i ].server, "Virtual", 7 ) ||
           !strncmp( tree->group_list[ i ].server, "Folders", 7 ))
      {                                                               
         folder = YES;
         if (( edit->group = edit->get_header( edit, 0, "Newsgroups: ", 12 ))
               == NULL || !( *edit->group ))
            return;
         else
            strcpy( newsgroup, edit->group );

         for( pointer = strtok( newsgroup, " ,\r\n" );
               pointer != NULL;
               pointer = strtok( NULL, " ,\t\n" ))
            for( i = 0; i < tree->groups; ++i )                          
               if ( !strcmp( tree->group_list[ i ].group, pointer ))   
                  break;                                                 
      }                                                               

   followup_to = NO;
   
   if ( origin == LN_MAIL || origin == LN_REPLY || origin == LN_FORWARD )
      edit->group = "::Outbox";
   else
      if ( origin == LN_ORIGINAL )
         edit->group = tree->group_list[ i ].group;
      else
         if (( edit->group = edit->get_header( edit, 0, "Followup-To: ", 13 ))
               != NULL )
            followup_to = YES;
         else
            if ( folder )
               edit->group = newsgroup;
            else
               edit->group = tree->group_list[ i ].group;

   edit->server = tree->group_list[ i ].server;
   edit->create_message( edit, origin, from );

   if ( followup_to )
      free( edit->group );

   return;
}

/*
 * Returns a copy of the contents of the header line of current article that
 * starts with the text in the header argument. Searches the message->message
 * struct if object is zero, otherwise searches the edit->message struct 
 * instead. 
 */

char *edit_get_header( void *this, char object, char *header, int size )
{
   np_edit_object *edit;
   np_message_object *message;

   char *pointer, *value, buffer[ LN_BUFFER_SIZE ];
   enum{ NO, YES }found;
   int l;


   edit = ( np_edit_object *)this;
   message = ( np_message_object *)
      (( np_newsreader_object *)
       (( np_buttons_object *)edit->parent )->parent )->message_object;

   found = NO;

   if ( object )
      pointer = edit->message.header;
   else
      pointer = message->message.header;

   if ( pointer == NULL )
   {
      strcpy( ln_error_message,
              "edit_get_header: dereferencing NULL pointer." );
      fatal_error();
   }

   --pointer;
   while( *( ++pointer ))
   {
      if ( !strncmp( pointer, header, size ))
      {
         found = YES;
         break;
      }

      pointer = strchr( pointer, '\n' );
   }

   if ( found )
   {
      l = strcspn( pointer, "\n" );
      strncpy( buffer, pointer, l );
      buffer[ l ] = '\0';

      pointer = buffer + size + strspn( buffer + size, " \t" );
      strtok( pointer, "\r\n" );

      if (( value = strdup( pointer )) == NULL )
         fatal_error();
   }
   else
      value = NULL;
      
   return value;
}

/*
 * Show error messages to user.
 */

void edit_whine( void *this, char what )
{
   np_edit_object *edit;
   np_newsrc_object *newsrc;

   char buffer[ LN_BUFFER_SIZE ];

   edit = ( np_edit_object *)this;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)edit->parent )->newsrc_object;

   switch( what )
   {
   case 0:
      strcpy( buffer, "Select a message, first." );
      break;

   case 1:
      strcpy( buffer, "Select an article to follow-up." );
      break;

   case 2:
      strcpy( buffer, "I won't let you create a follow-up to a header."
              "\nRetrieve and read the article, first." );
      break;

   case 3:
      strcpy( buffer, "You cannot compose an article for\n"
              "a virtual group, or a folder." );
      break;
   }

   newsrc->answer = -1;
   newsrc->confirm( newsrc, buffer, NP_DONE );
   while( newsrc->answer == -1 )
      EZ_WaitAndServiceNextEvent();
   
   return;
}

/*
 * Gets email address from ~/.peruser3-config.
 */

char *edit_get_email( void *this )
{
   np_edit_object *edit;
   np_newsrc_object *newsrc;

   char buffer[ LN_BUFFER_SIZE ], *home, *value;
   FILE *file;


   edit = ( np_edit_object *)this;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)edit->parent )->newsrc_object;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config",        
             home = getenv( "HOME" ));                                  
   if (( file = fopen( buffer, "r" )) == NULL )                    
   {                                                             
      if ( errno == ENOENT )                                      
      {                                                              
         strcpy( buffer,                                              
                 "You haven't configured Peruser, yet. Press the \"setup\""
                 "button, then choose the \"general\" menu item, and fill" 
                 "out the configuration form that appears." );             
         newsrc->confirm( newsrc, buffer, NP_DONE );                  
         return NULL;                                                      
      }                                                              

      fatal_error();                                              
   }                                                             

   fgets( buffer, LN_BUFFER_SIZE, file );                          
   fclose( file );                                                 

   if (( value = strdup( strtok( buffer, "\n" ))) == NULL )
      fatal_error();

   return value;
}

/*
 * Creates new or follow-up article.
 */

void edit_create_message( void *this, ln_origin origin, char *from )
{
   np_edit_object *edit;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_newsrc_object *newsrc;
   np_message_object *message;   
   
   char *email, *host;


   edit = ( np_edit_object *)this;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   message = ( np_message_object *)newsreader->message_object;

   if ( origin == LN_FOLLOW_UP || origin == LN_REPLY || origin == LN_FORWARD )
      if (( edit->message.header = strdup( message->message.header )) 
          == NULL )
         fatal_error();

   if (( email = edit->get_email( edit )) == NULL )
      return;

   if ( origin == LN_MAIL || origin == LN_REPLY || origin == LN_FORWARD )
   {
      if (( host = malloc( LN_BUFFER_SIZE )) == NULL )
         fatal_error();

      if ( gethostname( host, LN_BUFFER_SIZE ))
      { 
         free( host );
         if (( host = strdup( "localhost" )) == NULL )
            fatal_error();
      }
   }
   else
      host = edit->server;

   if ( ln_create_header( edit->group, host, email, origin, &edit->message ))
      lib_error();

   free( email );
   if ( origin == LN_MAIL || origin == LN_REPLY || origin == LN_FORWARD )
      free( host );

   edit->get_text( edit, origin, from );

   return;
}

/*
 * Launches external editor.
 */

void edit_edit_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_summary_object *summary;

   EZ_TreeNode *selected;
   EZ_Item *item;

   unsigned int i, j;


   edit = ( np_edit_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)edit->parent )->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      return;

   if ( selected == tree->root_node )
      return;

   edit->editing = 1;

   item = EZ_TreeNodeGetItem( selected );
   i = ( unsigned int)EZ_GetItemIntData( item );

   if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      return;

   if ( strncmp( tree->group_list[ i ].group, "Follow-ups", 10 ) &&
        strncmp( tree->group_list[ i ].group, "::Outbox", 8 ))
      return;

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
       == NULL )
      return;

   j = ( unsigned int)EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

   edit->position = j;
   edit->server = tree->group_list[ i ].server;
   edit->group = tree->group_list[ i ].group;

   edit->get_text( edit, LN_EDIT, NULL );

   return;
}

/*
 * Displays editing frame.
 */

void edit_get_text( void *this, ln_origin origin, char *from )                        
{                                                                    
   np_edit_object *edit;
   np_newsreader_object *newsreader;
   np_message_object *message;
   np_buttons_object *buttons;

   EZ_Widget *button_frame;

   char outbox, *pointer, buffer[ LN_BUFFER_SIZE ];
   int length, i;
   FILE *sig;


   edit = ( np_edit_object *)this;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   message = ( np_message_object *)newsreader->message_object;

   edit->edit_frame = EZ_CreateFrame( NULL, "Compose/Edit" );

   EZ_ConfigureWidget( edit->edit_frame,
                       EZ_HEIGHT, 550,
                       EZ_WIDTH, 600,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       0 );

   edit->header_text = EZ_CreateTextWidget( edit->edit_frame, 1, 1, 1 );

   EZ_ConfigureWidget( edit->header_text,
                       EZ_HEIGHT, 150,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   EZ_CreatePaneHandle( edit->edit_frame );

   edit->body_text = EZ_CreateTextWidget( edit->edit_frame, 1, 1, 1 );

   EZ_ConfigureWidget( edit->body_text,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   button_frame = EZ_CreateFrame( edit->edit_frame, NULL );

   EZ_ConfigureWidget( button_frame,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   edit->done_button = EZ_CreateButton( button_frame, "done", 0 );

   if ( origin == LN_MAIL || origin == LN_REPLY )
      i = 1;
   else 
      i = 0;

   EZ_ConfigureWidget( edit->done_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_CLIENT_INT_DATA, i,
                       EZ_CALLBACK, edit->text_callback, edit,
                       0 );

   edit->edit_button = EZ_CreateButton( button_frame, "external editor", 0 );

   EZ_ConfigureWidget( edit->edit_button,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 140,
                       EZ_CALLBACK, edit->text_callback, edit,
                       0 );

   if ( !strncmp( edit->group, "::Outbox", 8 ))
      outbox = 1;
   else
      outbox = 0;
   
   edit->crosspost_button = EZ_CreateButton( button_frame,
                                             (( outbox ) ? "addresses" :
                                              "newsgroups" ), 0 );

   EZ_ConfigureWidget( edit->crosspost_button,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 100,
                       EZ_CALLBACK, (( outbox ) ? edit->addresses_callback :
                                     edit->crosspost_callback ), edit,
                       0 );

   edit->attach_button = EZ_CreateButton( button_frame, "attach file", 0 );

   EZ_ConfigureWidget( edit->attach_button,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 85,
                       EZ_CALLBACK, edit->attach_callback, edit,
                       0 );
      
   edit->help_button = EZ_CreateButton( button_frame, "help", 0 );

   EZ_ConfigureWidget( edit->help_button,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_CALLBACK, buttons->help_callback, buttons,
                       EZ_CLIENT_INT_DATA, 5,
                       0 );

   edit->cancel_button = EZ_CreateButton( button_frame, "cancel", 0 );

   EZ_ConfigureWidget( edit->cancel_button,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CALLBACK, edit->text_callback, edit,
                       0 );

   if ( origin == LN_EDIT )
   {
      EZ_TextInsertString( edit->header_text, message->message.header );

      pointer = message->message.body - 1;
      while ( *( ++pointer ))
      {
         length = strcspn( pointer, "\n" );
         strncpy( buffer, pointer, length );
         buffer[ length - 1 ] = '\n';
         buffer[ length ] = '\0';

         EZ_TextInsertString( edit->body_text, buffer );
         pointer += length;
      }
   }
   else
      EZ_TextInsertString( edit->header_text, edit->message.header );

   EZ_TextBeginningOfBuffer( edit->header_text );

   if (( origin == LN_FOLLOW_UP ||
         origin == LN_REPLY ||
         origin == LN_FORWARD ) && message->message.body != NULL )
   {                                                              
      if ( origin != LN_FORWARD )
      {
         snprintf( buffer, LN_BUFFER_SIZE, "%s wrote:\n\n", from );  
         EZ_TextInsertString( edit->body_text, buffer );             
      }
      else
      {
         EZ_TextInsertString( edit->body_text,
                              "Text of forwarded message follows:\n\n" );

         pointer = message->message.header - 1;
         while( *( ++pointer ))
         {
            strcpy( buffer, ">" );
            length = strcspn( pointer, "\n" );
            strncat( buffer, pointer, length );
            buffer[ length + 1 ] = '\n';
            buffer[ length + 2 ] = '\0';

            EZ_TextInsertString( edit->body_text, buffer );
            pointer += length;
         }
      }
      
      pointer = message->message.body - 1;                        
      while( *( ++pointer ) )                                     
      {                                                           
         strcpy( buffer, "> " );                                  
         length = strcspn( pointer, "\n" );                   
         strncat( buffer, pointer, length );                      
         buffer[ length + 1 ] = '\n';                                 
         buffer[ length + 2 ] = '\0';

         EZ_TextInsertString( edit->body_text, buffer );          
         pointer += length;
      }                                                           
   }                                                              

   if ( origin != LN_EDIT )
   {
      snprintf( buffer, LN_BUFFER_SIZE, "%s/.signature", getenv( "HOME" ));
      if (( sig = fopen( buffer, "r" )) == NULL )
      {
         if ( errno != ENOENT )
            fatal_error();
      }
      else
      {
         while( fgets( buffer, LN_BUFFER_SIZE, sig ) != NULL )
            EZ_TextInsertString( edit->body_text, buffer );

         fclose( sig );
         EZ_TextBeginningOfBuffer( edit->body_text );
      }
   }

   EZ_DisplayWidget( edit->edit_frame );
   EZ_SetGrab( edit->edit_frame );
   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));

   return;
}

/*
 * Retrieves currently-selected article in Follow-ups group for editing.
 */

void edit_text_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_summary_object *summary;
   np_newsrc_object *newsrc;

   char *home, buffer[ LN_BUFFER_SIZE ], *server;
   FILE *spool, *file;
   long int i, j, k;
   unsigned int lines = 0;

   EZ_TreeNode *group, *article;


   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   if ( widget == edit->cancel_button )
   {
      EZ_DestroyWidget( edit->edit_frame );
      EZ_NormalCursor( newsreader->app_frame );
      return;
   }

   home = getenv( "HOME" );
   if ( widget == edit->edit_button )
   {
      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-text", home );
      EZ_TextSaveText( edit->body_text, buffer );

      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config", home );
      if (( file = fopen( buffer, "r" )) == NULL )
      {
         if ( errno == ENOENT )
         {
            strcpy( buffer, "You haven't configured Peruser"
                    "yet. \nPress the \"setup\" button and choose the"
                    " \"general\" menu item." );
            newsrc->confirm( newsrc, buffer, NP_DONE );
            return;
         }

         fatal_error();
      }

      fgets( buffer, LN_BUFFER_SIZE, file );
      fgets( buffer, LN_BUFFER_SIZE, file );
      fclose( file );

      if ( buffer[ 0 ] == '\n' )
         return;

      strtok( buffer, "\n" );
      strcat( buffer, " " );
      strcat( buffer, home );
      strcat( buffer, "/.peruser3-text" );
      system( buffer );

      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-text", home );
      EZ_TextLoadFile( edit->body_text, buffer );
      return;
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-text", home );      
   EZ_TextSaveText( edit->header_text, buffer );

   if (( !strncmp( edit->group, "Follow-ups", 10 ) ||
         !strncmp( edit->group, "::Outbox", 8 )) && edit->editing )
   {
      if ( ln_get_message_text( NULL, 0, 0, 0, NULL ));
      edit->replace_message( edit );
   }
   else
   {
      if (( file = fopen( buffer, "r" )) == NULL )                        
         fatal_error();                                                   

      if ( EZ_GetWidgetIntData( widget ))
         snprintf( buffer, LN_BUFFER_SIZE, 
                   "%s/.peruser_spool/::Outbox", home );
      else
         snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-FOLLOW-UPS",
                   home, edit->server );

      if (( spool = fopen( buffer, "a" )) == NULL )                       
         fatal_error();                                                   

      while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )              
      {
         ++lines;
         if ( buffer[ 0 ] == '\n' )
            fputs( "\r\n", spool );
         else
            fprintf( spool, "%s\r\n", strtok( buffer, "\n" ));
      }

      fclose( file );

      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-text", home );
      EZ_TextSaveText( edit->body_text, buffer );
      if (( file = fopen( buffer, "r" )) == NULL )                        
         fatal_error();                                                   

      fputs( "\r\n", spool );
      ++lines;

      while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
      {
         ++lines;
         if ( buffer[ 0 ] == '\n' )
            fputs( "\r\n", spool );
         else
            fprintf( spool, "%s\r\n", strtok( buffer, "\n" ));
      }

      fputs( ".\r\n", spool );

      fclose( file );                                                     
      fclose( spool );                                                    
   }

   edit->attached = 0;
   EZ_DestroyWidget( edit->edit_frame );
   EZ_NormalCursor( newsreader->app_frame );

   if (( group = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
       i = -1;
   else
       i = EZ_GetItemIntData( EZ_TreeNodeGetItem( group ));

   if (( article = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
           == NULL )
       j = -1;
   else
       j = EZ_GetItemIntData( EZ_TreeNodeGetItem( article ));

   tree->update_lists( tree );
   tree->set_tree( tree );

   if ( newsreader->split && lines > newsreader->split )
   {
      newsreader->show_message( newsreader, "Fragmenting message..." );

      server = tree->group_list[ i ].server;
      for( k = 0; k < tree->groups; ++k )
      {
         if ( !strcmp( tree->group_list[ k ].server, server ))
            if ( !strncmp( tree->group_list[ k ].group, "Follow-ups", 10 ))
               break;
      }

      if ( k != tree->groups )
      {
         EZ_ListTreeWidgetSelectNode( tree->tree, 
                                      tree->group_nodes[ k ], NULL );
         EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                             summary->node_list[ summary->stats.total - 1 ], 
                             NULL );
         edit->split_message_callback( buttons->split_message_button,
                                       edit );
      }

      newsreader->show_message( newsreader, NULL );
   }

   if ( -1 < i )
   {
      EZ_ListTreeWidgetSelectNode( tree->tree, 
                                   tree->group_nodes[ i ], NULL );

      if ( -1 < j ) 
         EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                      summary->node_list[ j ],
                                      NULL );
   }

   edit->group = NULL;
   
   return;
}

/*
 * Replaces message in Follow-ups group with edited version.
 */

void edit_replace_message( void *this )
{
   np_edit_object *edit;

   char *home, buffer[ LN_BUFFER_SIZE ], new_path[ LN_BUFFER_SIZE ],
      old_path[ LN_BUFFER_SIZE ];
   FILE *spool, *temp, *text;


   edit = ( np_edit_object *)this;

   if ( !strncmp( edit->group, "::Outbox", 8 ))
      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/::Outbox",
                home = getenv( "HOME" ));
   else
      snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-FOLLOW-UPS",
                home = getenv( "HOME" ), edit->server );

   strcpy( new_path, buffer);
   
   if (( spool = fopen( buffer, "r" )) == NULL )
      fatal_error();

   strcat( buffer, ".tmp" );
   strcpy( old_path, buffer );
   
   if (( temp = fopen( buffer, "w" )) == NULL )
      fatal_error();

   while( edit->position-- )
      do
      {
         fgets( buffer, LN_BUFFER_SIZE, spool );
         fputs( buffer, temp );
      }
      while( strncmp( buffer, ".\r\n", 3 ));

   do
      if ( fgets( buffer, LN_BUFFER_SIZE, spool ) == NULL )
         break;
   while( strncmp( buffer, ".\r\n", 3 ));

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-text", home );

   if (( text = fopen( buffer, "r" )) == NULL )
      fatal_error();

   while( fgets( buffer, LN_BUFFER_SIZE, text ) != NULL )
      if ( buffer[ 0 ] == '\n' )
         fputs( "\r\n", temp );
      else
         fprintf( temp, "%s\r\n", strtok( buffer, "\r\n" ));

   fputs( "\r\n", temp );
   fclose( text );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-text", home );
   EZ_TextSaveText( edit->body_text, buffer );

   if (( text = fopen( buffer, "r" )) == NULL )
      fatal_error();

   while( fgets( buffer, LN_BUFFER_SIZE, text ) != NULL )
      if ( buffer[ 0 ] == '\n' )
         fputs( "\r\n", temp );
      else
         fprintf( temp, "%s\r\n", strtok( buffer, "\r\n" ));

   fputs( ".\r\n", temp );
   fclose( text );

   while( fgets( buffer, LN_BUFFER_SIZE, spool ) != NULL )
      fputs( buffer, temp );

   fclose( temp );
   fclose( spool );

   rename( old_path, new_path );

   return;
}

/* 
 * Callback of items on the edit menu. Delete the currently-selected article
 * if the currently-selected newsgroup is either a Follow-ups, Posted, or
 * Folder group.
 */

void edit_delete_callback( EZ_Widget *widget, void *data )
{
   np_summary_object *summary;
   np_edit_object *edit;
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;

   EZ_TreeNode *selected;
   EZ_Item *item;

   long int k;
   unsigned int i, j;
   char buffer[ LN_BUFFER_SIZE ], *string;


   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      return;

   if ( selected == tree->root_node )
      return;

   /*
    * Close the currently-selected group's spoolfile, it it's open.
    */

   item = EZ_TreeNodeGetItem( selected );
   if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      return;

   i = ( unsigned int)EZ_GetItemIntData( item );
   if ( !strncmp( tree->group_list[ i ].group, "Follow-ups", 10 ))
      edit->follow_ups = 0;
   else
      if ( !strncmp( tree->group_list[ i ].server, "Folders", 7 ))
         edit->follow_ups = 1;
      else
         if ( !strncmp( tree->group_list[ i ].group, "Posted", 6 ))
            edit->follow_ups = 2;
         else
            if ( !strncmp( tree->group_list[ i ].server, "Mailboxes", 9 ))
               edit->follow_ups = 1;
            else
               return;

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         != NULL )
      k = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));
   else
      k = -1;

   EZ_FreezeWidget( summary->thread_tree );
                                                   
   if ( widget == buttons->delete_all_button )
   {
      if ( summary->stats.total )
      {
         char *delete;

         if (( delete = calloc( summary->stats.total, sizeof *delete )) 
               == NULL )
            fatal_error();

         for( j = 0; j < summary->stats.total; ++j )
         {
            if ( summary->node_list[ j ] != NULL )
            {
               item = EZ_TreeNodeGetItem( summary->node_list [ j ] );
               EZ_GetLabelItemStringInfo( item, &string, NULL );
               if ( summary->contents[ j ].delete )
               {
                  string += 2;
                  buffer[ 0 ] = '\0';
               }
               else
                  strcpy( buffer, "D " );

               strcat( buffer, string );

               EZ_ConfigureItem( item,
                                 EZ_LABEL_STRING, buffer,
                                 0 );
            }

            delete[ j ] = summary->contents[ j ].delete ^= 1;
         }

         tree->group_list[ i ].delete = 1;

         for( j = 0; j < summary->stats.total; ++j )
            if ( !delete[ j ] )
            {
               tree->group_list[ i ].delete = 0;
               break;
            }
         
         free( delete );
      }
   }
   else
   {
      if ( k < 0 )
      {
         newsrc->answer = -1;
         newsrc->confirm( newsrc, "Select an article in the\n"
                          "thread tree, first.", NP_DONE );
         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();
         
         EZ_UnFreezeWidget( summary->thread_tree );
         return;
      }

      item = EZ_TreeNodeGetItem( selected );
      EZ_GetLabelItemStringInfo( item, &string, NULL );
      if ( summary->contents[ k ].delete )
      {
         string += 2;
         buffer[ 0 ] = '\0';
      }
      else
         strcpy( buffer, "D " );

      strcat( buffer, string );
      
      EZ_ConfigureItem( item,
                        EZ_LABEL_STRING, buffer,
                        0 );
      
      if ( !( summary->contents[ k ].delete ^= 1 ))
         tree->group_list[ i ].delete = 0;
      
   }

   EZ_UnFreezeWidget( summary->thread_tree );

   /*
   EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ i ], NULL );
   */

   if ( -1 < k )
      EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                   summary->node_list[ k ], NULL );

   return;
}

void edit_expunge_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_summary_object *summary;
   
   EZ_TreeNode *selected;
   EZ_Item *item;
   
   unsigned int i, result;
   

   edit = ( np_edit_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)edit->parent )->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;
   
   /*
    * If we're being called by summary->set_tree, the selection has been
    * changed in the group tree.
    */

   if ( widget != NULL )
   {
      if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
         return;

      if ( selected == tree->root_node )
         return;

      item = EZ_TreeNodeGetItem( selected );

      if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
         return;

      i = EZ_GetItemIntData( item );
   }
   else
      i = summary->group;

   if ( !strncmp( tree->group_list[ i ].group, "Follow-ups", 10 ))
      edit->follow_ups = 0;
   else
      if ( !strncmp( tree->group_list[ i ].server, "Folders", 7 ))
         edit->follow_ups = 1;
      else
         if ( !strncmp( tree->group_list[ i ].group, "Posted", 6 ))
            edit->follow_ups = 2;
         else
            if ( !strncmp( tree->group_list[ i ].server, "Mailboxes", 9 ))
               edit->follow_ups = 1;
            else
               return;

   /*
    * Close the currently-selected group's spoolfile, it it's open.
    */

   ln_get_message_text( NULL, 0, 0, 0, NULL );

   if ( tree->group_list[ i ].delete )
   {
      if ( ln_truncate_spool( tree->group_list[ i ].server,
                              tree->group_list[ i ].group, edit->follow_ups ))
         lib_error();
      tree->group_list[ i ].total = 0;
   }
   else
      if ( tree->group_list[ i ].total )
      {
         if (( result = ln_delete_articles( tree->group_list[ i ].server,
                                            tree->group_list[ i ].group, 
                                            summary->contents, 
                                            summary->stats.total,
                                            edit->follow_ups )) == -1 )
            lib_error();
      
         if ( tree->group_list[ i ].total )
            tree->group_list[ i ].total -= result;
      }

   tree->update_lists( tree );
   tree->set_tree( tree );

   EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ i ], NULL );

   return;
}

/*
 * Generate a cancel message for the currently-selected article in the
 * Posted group.
 */

void edit_cancel_message_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_tree_object *tree;
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_newsreader_object *newsreader;
   np_message_object *message;

   unsigned int i, j;
   char *email, buffer[ LN_BUFFER_SIZE ], body[ LN_BUFFER_SIZE ];
   FILE *file;

   EZ_TreeNode *selected;
   EZ_Item *item;


   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   tree = ( np_tree_object *)newsreader->tree_object;
   message = ( np_message_object *)newsreader->message_object;

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      return;

   if ( selected == tree->root_node )
      return;

   /*
    * Close the currently-selected group's spoolfile, if it's open.
    */

   ln_get_message_text( NULL, 0, 0, 0, NULL );

   item = EZ_TreeNodeGetItem( selected );
   if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      return;

   i = ( unsigned int)EZ_GetItemIntData( item );
   if ( strncmp( tree->group_list[ i ].group, "Posted", 6 ))
      return;

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         == NULL )
      return;

   item = EZ_TreeNodeGetItem( selected );
   j = ( unsigned int)EZ_GetItemIntData( item );

   if (( edit->message.header = strdup( message->message.header )) == NULL )
      fatal_error();

   snprintf( body, LN_BUFFER_SIZE,
             "article %s\ncancelled by News Peruser 3.0\r\n.\r\n",
             ln_get_line( "Message-ID: ", &message->message ));

   email = edit->get_email( edit );

   if ( ln_create_header( NULL, tree->group_list[ i ].server, email, 
                          LN_CANCEL_MESSAGE, &edit->message ))
      lib_error();

   free( email );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-FOLLOW-UPS",
             getenv( "HOME" ), tree->group_list[ i ].server );
   if (( file = fopen( buffer, "a" )) == NULL )
      fatal_error();

   fputs( edit->message.header, file );
   fputs( "\r\n", file );
   fputs( body, file );
   fclose( file );

   free( edit->message.header );

   tree->update_lists( tree );
   tree->set_tree( tree );

   EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ i ], NULL );
   EZ_ListTreeWidgetSelectNode( summary->thread_tree, summary->node_list[ j ],
                                NULL );

   return;
}

/*
 * Generate supersede message for currently-selected article in 
 * Posted group.
 */

void edit_supersede_callback( EZ_Widget *widget, void *data )
{
  np_newsreader_object *newsreader;
  np_edit_object *edit;
  np_tree_object *tree;
  np_summary_object *summary;
  np_message_object *message;

  EZ_TreeNode *selected;
  EZ_Item *item;

  unsigned int i, j;
  char *email;


  edit = ( np_edit_object *)data;
  newsreader = ( np_newsreader_object *)
     (( np_buttons_object *)edit->parent )->parent;
  tree = ( np_tree_object *)newsreader->tree_object;
  summary = ( np_summary_object *)newsreader->summary_object;
  message = ( np_message_object *)newsreader->message_object;

  if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
     return;

  if ( selected == tree->root_node )
     return;

  /*
   * Close the currently-selected group's spoolfile, if it's open.
   */

  item = EZ_TreeNodeGetItem( selected );
  if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
     return;

  i = ( unsigned int)EZ_GetItemIntData( item );
  if ( strncmp( tree->group_list[ i ].group, "Posted", 6 ))
     return;

  if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
        == NULL )
     return;

  item = EZ_TreeNodeGetItem( selected );
  j = ( unsigned int)EZ_GetItemIntData( item );

  if (( edit->message.header = strdup( message->message.header )) == NULL )
     fatal_error();

  email = edit->get_email( edit );
  edit->server = tree->group_list[ i ].server;
  edit->group = tree->group_list[ i ].group;
  
  if ( ln_create_header( NULL, edit->server, email, LN_SUPERSEDE, 
                         &edit->message ))
     lib_error();

  free( email );

  edit->message.body = NULL;
  edit->get_text( edit, LN_SUPERSEDE, NULL );

  return;
}

/*
 * Create message with external mailer MUA.
 */

void edit_reply_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;

   edit = ( np_edit_object *)data;
   
   return;
}

void edit_forward_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;

   edit = ( np_edit_object *)data;
   
   return;
}

void edit_split_message_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_newsrc_object *newsrc;
   np_message_object *message;
   np_update_object *update;
   
   char buffer[ LN_BUFFER_SIZE ], header_path[ LN_BUFFER_SIZE ],
      second_buffer[ LN_BUFFER_SIZE ], body_path[ LN_BUFFER_SIZE ], 
      spool_path[ LN_BUFFER_SIZE ],
      *home, *newsgroups, *from, *subject, *date, *path, toggle;

   int partno, result;
   unsigned int position;

   FILE *header, *body, *spool;

   EZ_TreeNode *selected;
   EZ_Item *item;


   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   tree = ( np_tree_object *)newsreader->tree_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   message = ( np_message_object *)newsreader->message_object;
   update = ( np_update_object *)buttons->update_object;

   if ( !newsreader->split )
   {
      toggle = 1;
      newsrc->answer = -1;

      newsreader->split_button_callback( widget, newsreader );

      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      if ( !newsreader->split )
         return;
   }
   else
      toggle = 0;

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL ||
         selected == tree->root_node )
      return;

   item = EZ_TreeNodeGetItem( selected );
   if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      return;

   position = ( unsigned int)EZ_GetItemIntData( item );

   if ( strncmp( tree->group_list[ position ].group,
            "Follow-ups", 10 ))
      return;

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         == NULL )
   {
      newsrc->answer = -1;
      newsrc->confirm( newsrc, "Select an article.", NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
      return;
   }

   update->interrupt = 0;

   position 
      = ( unsigned int)EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

   /* 
    * Dump messsage to disk.
    */

   snprintf( header_path, LN_BUFFER_SIZE, "%s/.peruser-text",
             home = getenv( "HOME" ));
   EZ_TextSaveText( message->header_text, header_path );

   snprintf( body_path, LN_BUFFER_SIZE, "%s-2", header_path );
   EZ_TextSaveText( message->body_text, body_path );

   if (( body = fopen( body_path, "r" )) == NULL )
      fatal_error();

   if (( header = fopen( header_path, "a" )) == NULL )
      fatal_error();

   fputs( "\r\n", header );
   while( fgets( buffer, LN_BUFFER_SIZE, body ) != NULL )
      fputs( buffer, header );

   fclose( body );
   fclose( header );

   if (( body = fopen( body_path, "w" )) == NULL )
      fatal_error();

   /*
    * Split message.
    */

   UUInitialize();

   newsgroups = edit->get_header( edit, 0, "Newsgroups: ", 12 );
   from       = edit->get_header( edit, 0, "From: ", 6 );
   subject    = edit->get_header( edit, 0, "Subject: ", 9 );
   date       = edit->get_header( edit, 0, "Date: ", 6 );
   path       = edit->get_header( edit, 0, "Path: ", 6 );

   partno = 1;
   do
   {
      fprintf( body, "Path: %s\r\nDate: %s\r\n", path, date );
      fprintf( body, "Message-ID: <NewsPeruser-3.0-%lu-%lu@%s>\r\n", 
               ( long unsigned int)( 100 * rand()), time( 0 ), 
               tree->group_list[ summary->group ].server );

      result = UUE_PrepPartial( body, NULL,
                                header_path, B64ENCODED, 
                                "meta-article.txt", 0, 
                                partno, newsreader->split,
                                0, newsgroups, 
                                from, subject, 0 ); 
      fputs( ".\r\n", body );
      ++partno;
   }
   while( result == UURET_CONT );

   if ( result != UURET_OK )
   {
      strcpy( buffer, (( result == UURET_IOERR ) ?
              strerror( UUGetOption( UUOPT_ERRNO, NULL, NULL, 0 )) :
              UUstrerror( result )));
      newsrc->answer = -1;
      newsrc->confirm( newsrc, buffer, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
      UUCleanUp();

      fclose( body );
      remove( header_path );
      remove( body_path );

      free( from );
      free( subject );
      free( date );
      free( newsgroups );
      free( path );

      return;
   }

   /*
    * Replace original.
    */

   ln_get_message_text( NULL, 0, 0, 0, NULL );
   snprintf( spool_path, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-FOLLOW-UPS",
             home, tree->group_list[ summary->group ].server );

   if (( spool = fopen( spool_path, "r" )) == NULL )
      fatal_error();

   if (( header = fopen( header_path, "w" )) == NULL )
      fatal_error();

   while( position-- )
      do
      {
         fgets( buffer, LN_BUFFER_SIZE, spool );
         fputs( buffer, header );
      }
      while( strncmp( buffer, ".\r\n", 3 ));

   fflush( body );
   rewind( body );
   if (( body = fopen( body_path, "r" )) == NULL )
      fatal_error();

   while( fgets( buffer, LN_BUFFER_SIZE, body ) != NULL )
   {
      strcpy( second_buffer, buffer );
      if ( strtok( second_buffer, "\r\n" ) == NULL )
         fputs( "\r\n", header );
      else
         fprintf( header, "%s\r\n", second_buffer );
   }

   do
      fgets( buffer, LN_BUFFER_SIZE, spool );
   while( strncmp( buffer, ".\r\n", 3 ));

   while( fgets( buffer, LN_BUFFER_SIZE, spool ) != NULL )
      fputs( buffer, header );

   /*
    * Clean up.
    */

   fclose( header );
   fclose( body );
   fclose( spool );

   remove( body_path );
   rename( header_path, spool_path );

   UUCleanUp();

   if ( toggle )
      newsreader->split = 0;

   free( date );
   free( path );
   free( from );
   free( newsgroups );
   free( subject );

   selected = EZ_GetListTreeWidgetSelection( tree->tree );
   position = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

   tree->update_lists( tree );
   tree->set_tree( tree );
   EZ_ListTreeWidgetSelectNode( tree->tree, 
                                tree->group_nodes[ position ], NULL );
   
   newsreader->show_message( newsreader, NULL );

   return;
}

void edit_attachment_frame_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_message_object *message;
   np_update_object *update;

   int result, total, len;

   FILE *header;

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ], 
      third_buffer[ LN_BUFFER_SIZE ],
      infilename[ LN_BUFFER_SIZE ], outfilename[ LN_BUFFER_SIZE ], 
      *home, *pointer; 
      
   char *mime_headers = "MIME-Version: 1.0\r\n"
      "Content-Transfer-Encoding: base64\r\n";
   char *mixed_format = "Content-Type: multipart/mixed; boundary=\"%s\"\r\n";

   FILE *temp, *body;

   
   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   message = ( np_message_object *)newsreader->message_object;
   update = ( np_update_object *)buttons->update_object;

   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   update->interrupt = 0;

   if( widget == edit->cancel_attach_button )
   {
      EZ_DestroyWidget( edit->attach_frame );
      return;
   }
   
   snprintf( infilename, LN_BUFFER_SIZE, "%s", 
             EZ_GetFileSelectorSelection( widget ));

   if (( pointer = strrchr( infilename, '/' )) != NULL )
      strcpy( outfilename, ++pointer );
   else
      strcpy( outfilename, infilename );

   /*
    * Save headers to disk, and augment with MIME headers, if they haven't
    * already been added.
    */

   home = getenv( "HOME" );
   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-text", home );

   if ( !edit->attached )
   {
      EZ_TextSaveText( edit->header_text, buffer );
      if (( temp = fopen( buffer, "a" )) == NULL )
         fatal_error();

      fputs( mime_headers, temp );
      fprintf( temp, mixed_format, edit->boundary );
      fclose( temp );
      EZ_TextLoadFile( edit->header_text, buffer );
      EZ_TextBeginningOfBuffer( edit->header_text );
      remove( buffer );
   }

   /*
    * Put current message text in temp.
    */

   EZ_TextSaveText( edit->body_text, buffer );
   if (( body = fopen( buffer, "r" )) == NULL )
      fatal_error();

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", home );
   if (( temp = fopen( buffer, "w" )) == NULL )
      fatal_error();

   /* 
    * If adding encoded part to regular message.
    */

   if ( !edit->attached )
   {
      fprintf( temp, "--%s\n", edit->boundary );
      fputs( "Content-Type: text/plain; charset=us-ascii\n", temp );
      fputs( "Content-Transfer-Encoding: 7bit\n\n", temp );
      while( fgets( second_buffer, LN_BUFFER_SIZE, body ) != NULL )
         fputs( second_buffer, temp );
      fclose( body );

      fprintf( temp, "\n--%s\n", edit->boundary );
   }

   /*
    * If adding another encoded part to current message.
    */

   else
   {
      snprintf( second_buffer, LN_BUFFER_SIZE, "--%s--", edit->boundary );
      len = strlen( second_buffer );

      while( fgets( third_buffer, LN_BUFFER_SIZE, body ) != NULL )
         if ( !strncmp( second_buffer, third_buffer, len ))
            break;
         else
            fputs( third_buffer, temp );

      fclose( body );
      fprintf( temp, "--%s\n", edit->boundary );
   }

   /*
    * Add encoded file as second part.
    */

   EZ_WaitCursor( edit->attach_frame, EZ_GetCursor( XC_watch ));

   if ( UUInitialize() != UURET_OK )
      fatal_error();

   if (( result = UUEncodeMulti( temp, NULL, infilename, B64ENCODED, 
                                 outfilename, NULL, 0 )) != UURET_OK )
   {
      strcpy( buffer, (( result == UURET_IOERR ) ?
              strerror( UUGetOption( UUOPT_ERRNO, NULL, NULL, 0 )) :
              UUstrerror( result )));
      newsrc->answer = -1;
      newsrc->confirm( newsrc, buffer, NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
      UUCleanUp();
      return;
   }

   EZ_NormalCursor( edit->attach_frame );
   UUCleanUp();
   newsreader->show_message( newsreader, NULL );

   fprintf( temp, "\n--%s--\n", edit->boundary );
   fclose( temp );

   EZ_TextLoadFile( edit->body_text, buffer );
   EZ_TextBeginningOfBuffer( edit->body_text );
   remove( buffer );

   edit->attached = 1;
   total = 0;

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", 
             getenv( "HOME" ));
   EZ_TextSaveText( edit->header_text, second_buffer );
   if (( header = fopen( second_buffer, "r" )) == NULL )
      fatal_error();

   while( fgets( buffer, LN_BUFFER_SIZE, header ) != NULL )
      total += strlen( buffer );

   if ( edit->message.header != NULL )
      free( edit->message.header );
   if (( edit->message.header = malloc( total + 1 )) == NULL )
      fatal_error();

   edit->message.header[ 0 ] = '\0';
   rewind( header );

   while( fgets( buffer, LN_BUFFER_SIZE, header ) != NULL )
      strcat( edit->message.header, buffer );

   fclose( header );
   remove( second_buffer );

   EZ_DestroyWidget( edit->attach_frame );
   EZ_SetGrab( edit->edit_frame );

   return;
}

void edit_attach_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_buttons_object *buttons;
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;

   EZ_Widget *selection_entry, *dir_list, *filter_button, *file_list;

   char object;
   
   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   newsreader = ( np_newsreader_object *)buttons->parent;

   object = (( edit->message.header == NULL ) ? 0 : 1 );

   if ( edit->get_header( edit, object, "MIME-Version: ", 14 ) != NULL )
      edit->attached = 1;

   edit->attach_frame = EZ_CreateFrame( NULL, "Attach File" );
   
   EZ_ConfigureWidget( edit->attach_frame,
                       EZ_HEIGHT, 450,
                       EZ_WIDTH, 500,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_PADY, 5,
                       0 );

   buttons->file_selector 
      = EZ_CreateFileSelector( edit->attach_frame, "*" );

   EZ_ConfigureWidget( buttons->file_selector,
                       EZ_CALLBACK, edit->attachment_frame_callback, edit,
                       0 );

   EZ_GetFileSelectorWidgetComponents( buttons->file_selector,
                                       &buttons->filter_entry,
                                       &selection_entry,
                                       &dir_list,
                                       &file_list,
                                       &edit->ok_button,
                                       &filter_button,
                                       &edit->cancel_attach_button );

   EZ_ConfigureWidget( buttons->filter_entry,
                       EZ_HEIGHT, 50,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   EZ_ConfigureWidget( selection_entry,
                       EZ_HEIGHT, 50,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   EZ_ConfigureWidget( edit->ok_button,
                       EZ_HEIGHT, 30,
                       EZ_UNDERLINE, -1,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_LABEL_STRING, "done",
                       0 );

   EZ_ConfigureWidget( filter_button,
                       EZ_HEIGHT, 30,
                       EZ_UNDERLINE, -1,
                       EZ_LABEL_STRING, "filter",
                       0 );

   EZ_ConfigureWidget( edit->cancel_attach_button,
                       EZ_LABEL_STRING, "cancel",
                       EZ_FOREGROUND, "DarkRed",
                       EZ_UNDERLINE, -1,
                       EZ_HEIGHT, 30,
                       0 ); 

   EZ_AddWidgetCallBack( edit->cancel_attach_button,
                         EZ_CALLBACK, edit->attachment_frame_callback, edit,
                         1 );

   EZ_DisplayWidget( edit->attach_frame );
   EZ_SetGrab( edit->attach_frame );

   return;
}

void edit_crosspost_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_tree_object *tree;
   np_summary_object *summary;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;

   EZ_Widget *top_frame, *list_frame, *button_frame, *cancel_button;
   EZ_TextProperty *property;
   EZ_Item **items, *item;

   np_newsgroup_list *group_pointer;
   
   unsigned int i, j, server, count;
   char newsgroup[ LN_BUFFER_SIZE ], *pointer;
   

   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   tree = ( np_tree_object *)newsreader->tree_object;

   if ( !strncmp( edit->group, "::Outbox", 8 ))
      return;
   
   top_frame = EZ_CreateFrame( NULL, "Crosspost" );

   EZ_ConfigureWidget( top_frame, 
                       EZ_WIDTH, 500,
                       EZ_HEIGHT, 500,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   list_frame = EZ_CreateFrame( top_frame, NULL );
   
   EZ_ConfigureWidget( list_frame,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );
         
   edit->crosspost_list = EZ_CreateFancyListBox( list_frame, 1, 1, 1, 1 );

   property = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font,
                                  0 );

   if (( items = malloc( sizeof *items )) == NULL )
      fatal_error();

   items[ 0 ] = EZ_CreateLabelItem( "Post to:", property );

   EZ_SetFancyListBoxHeader( edit->crosspost_list, items, 1 );
   
   EZ_ConfigureWidget( edit->crosspost_list,
                       EZ_CALLBACK, edit->crosspost_lists_callback, edit,
                       EZ_CLIENT_INT_DATA, 0,
                       EZ_CLIENT_PTR_DATA, top_frame,
                       0 );

   edit->source_list = EZ_CreateFancyListBox( list_frame, 1, 1, 1, 1 );

   items[ 0 ] = EZ_CreateLabelItem( "Choose From:", property );
   EZ_SetFancyListBoxHeader( edit->source_list, items, 1 );
   free( items );

   EZ_ConfigureWidget( edit->source_list,
                       EZ_CALLBACK, edit->crosspost_lists_callback, edit,
                       EZ_CLIENT_INT_DATA, 1,
                       0 );
   
   button_frame = EZ_CreateFrame( top_frame, NULL );
   
   EZ_ConfigureWidget( button_frame,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );
   
   edit->done_button = EZ_CreateButton( button_frame, "done", 0 );
   
   EZ_ConfigureWidget( edit->done_button,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_CLIENT_PTR_DATA, edit->crosspost_list,
                       EZ_CALLBACK, edit->crosspost_frame_callback, edit,
                       0 );

   cancel_button = EZ_CreateButton( button_frame, "cancel", 0 );
   
   EZ_ConfigureWidget( cancel_button,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_CLIENT_PTR_DATA, top_frame,
                       EZ_CALLBACK, edit->crosspost_frame_callback, edit,
                       0 );

   /*
    * If the current server is the Folders or the Virtual group node,
    * get the server index of the actual server this particular article
    * was downloaded from. Since we don't allow original articles to be
    * created for those phoney servers, we will always be creating a
    * follow-up.
    */

   if ( !strncmp( tree->group_list[ summary->group ].server, "Folders", 7 ) ||
        !strncmp( tree->group_list[ summary->group ].server, 
                  "Mailboxes", 9 ) ||
        !strncmp( tree->group_list[ summary->group ].server, "Virtual", 7 ))
   {
      char newsgroup[ LN_BUFFER_SIZE ], *pointer;

      if (( edit->group = edit->get_header( edit, 0, "Newsgroups: ", 12 ))
            == NULL || !( *edit->group ))
         return;
      else
         strcpy( newsgroup, edit->group );

      for( pointer = strtok( newsgroup, " ,\r\n" );
           pointer != NULL;
           pointer = strtok( NULL, " ,\t\n" ))
         for( i = 0; i < tree->groups; ++i )                          
            if ( !strcmp( tree->group_list[ i ].group, pointer ))   
               break;                                                 
      
      server = tree->group_list[ i ].server_idx;
   }
   else
      server = tree->group_list[ summary->group ].server_idx;

   i = 0;
   while( strcmp( tree->group_list[ i ].server,
                  tree->server_list[ server ].server ))
      ++i;
   
   /*
    * Create display items for newsgroups subscribed from same server, as
    * source groups.
    */

   if (( items = calloc( tree->server_list[ server ].groups, sizeof *items ))
       == NULL )
      fatal_error();

   for( j = 0; j < tree->server_list[ server ].groups - 2; ++j )
   {
      items[ j ] = EZ_CreateLabelItem( tree->group_list[ i++ ].group,
                                       tree->read_prop );
      EZ_ConfigureItem( items[ j ],
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );
   }
   
   EZ_SetFancyListBoxData( edit->source_list, items,
                           tree->server_list[ server ].groups, 1 );

   /*
    * Create initial entries in linked list of groups.
    */

   count = 0;
   strcpy( newsgroup, edit->get_header( edit, 
                                        (( edit->editing ) ? 0 : 1 ),
                                        "Newsgroups: ", 12 ));

   for( pointer = strtok( newsgroup, " ,\r\n" );
        pointer != NULL;
        pointer = strtok( NULL, " ,\r\n" ))
   {
      EZ_ConfigureItem( item = EZ_CreateLabelItem( pointer, tree->read_prop ),
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );

      EZ_FancyListBoxInsertRow( edit->crosspost_list, &item, 1, ++count );

      if ( edit->newsgroups == NULL )
      {
         if (( edit->newsgroups = malloc( sizeof *edit->newsgroups ))
               == NULL )
            fatal_error();
         group_pointer = edit->newsgroups;
      }
      else
      {
         if (( group_pointer->next = malloc( sizeof *edit->newsgroups ))
               == NULL )
            fatal_error();
         group_pointer = ( np_newsgroup_list *)group_pointer->next;
      }

      if (( group_pointer->group = strdup( pointer )) == NULL )
         fatal_error();
      group_pointer->next = NULL;
   }
   
   EZ_DisplayWidget( top_frame );
   EZ_SetGrab( top_frame );
   
   return;
}

void edit_crosspost_lists_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_tree_object *tree;
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;

   EZ_Item *item;

   np_newsgroup_list *group_pointer, *prev_pointer;
   
   char *string;
   int r;
   

   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;

   /* 
    * It seems the widget passed to this callback is the internal list box and
    * not the list box widget tied to the callback, so  I use client data to
    * determine which listbox is calling this callback. 
    */

   if ( EZ_GetWidgetIntData( widget ))
   {
      /* 
       * If we're adding a group, get group name.
       */

      item = *( EZ_GetFancyListBoxSelection( widget ));
      EZ_GetLabelItemStringInfo( item, &string, NULL );
         
      /* 
       * Check to see if we already have it.
       */

      group_pointer = edit->newsgroups;
      while( group_pointer != NULL )
      {
         if ( !strcmp( group_pointer->group, string ))
            return;
         prev_pointer = group_pointer;
         group_pointer = ( np_newsgroup_list *)group_pointer->next;
      }
      
      /*
       * If we don't, create display item and add it to crosspost->list.
       */

      EZ_ConfigureItem( item = EZ_CreateLabelItem( string, tree->read_prop ),
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );
      EZ_FancyListBoxInsertRow( edit->crosspost_list, &item, 1, 1 );

      /*
       * Add group name to our linked list of already added groups.
       */

      if ( edit->newsgroups == NULL )
      {
         if (( edit->newsgroups = malloc( sizeof *edit->newsgroups ))
             == NULL )
            fatal_error();
         group_pointer = edit->newsgroups;
      }
      else
      {
         if (( prev_pointer->next = malloc( sizeof *edit->newsgroups ))
             == NULL )
            fatal_error();
         group_pointer = ( np_newsgroup_list *)prev_pointer->next;
      }

      if (( group_pointer->group = strdup( string )) == NULL )
         fatal_error();
      group_pointer->next = NULL;
   }
   else
   {
      /*
       * If we're deleting a group, get the group name, and remove the
       * corresponding line from edit->crosspost_list.
       */

      EZ_GetFancyListBoxSelectionIdx( edit->crosspost_list, &r, NULL );
      item = *( EZ_GetFancyListBoxSelection( edit->crosspost_list ));
      EZ_GetLabelItemStringInfo( item, &string, NULL );

      /* 
       * Find the node in our linked list corresponding to this newsgroup,
       * and remove it.
       */

      prev_pointer = NULL;
      group_pointer = edit->newsgroups;

      while( group_pointer != NULL )
      {
         if ( !strcmp( group_pointer->group, string ))
         {
            if ( prev_pointer == NULL )
               edit->newsgroups = ( np_newsgroup_list *)group_pointer->next;
            else
               prev_pointer->next = group_pointer->next;

            free( group_pointer->group );
            free( group_pointer );
            break;
         }
         
         prev_pointer = group_pointer;
         group_pointer = ( np_newsgroup_list *)group_pointer->next;
      }

      EZ_FancyListBoxDeleteRow( edit->crosspost_list, r );
   }
   
   return;
}

void edit_destroy_newsgroup_list( np_newsgroup_list *list )
{
   if ( list == NULL )
      return;

   if ( list->next != NULL )
      edit_destroy_newsgroup_list( ( np_newsgroup_list *)list->next );
   
   free( list->group );
   free( list );

   return;
}

   
void edit_crosspost_frame_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_newsrc_object *newsrc;
   np_buttons_object *buttons;
   np_message_object *message;

   EZ_Widget *list;
   EZ_Item *item;
   
   unsigned int i, limit, total = 0;
   char *string, *newsgroups, buffer[ 1001 ], path[ LN_BUFFER_SIZE ];
   FILE *header;


   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   message = ( np_message_object *)
      (( np_newsreader_object *)buttons->parent )->message_object;
   
   if ( widget == edit->done_button )
      list = EZ_GetWidgetPtrData( EZ_GetWidgetPtrData( widget ));
   else
   {
      edit->destroy_newsgroup_list( edit->newsgroups );
      edit->newsgroups = NULL;
      EZ_DestroyWidget( EZ_GetWidgetPtrData( widget ));
      return;
   }

   if ( !(( limit = EZ_GetFancyListBoxNumberOfRows( edit->crosspost_list ))
         - 1 ))
   {
      newsrc->answer = -1;
      newsrc->confirm( newsrc,
                       "You must choose at least one\nnewsgroup to post"
                       " article to.", NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      return;
   }
   
   strcpy( buffer, "Newsgroups: " );

   i = 1;
   while( i < limit )
   {
      item = EZ_GetFancyListBoxItemUsingIdx( edit->crosspost_list, i++, 0 );
      EZ_GetLabelItemStringInfo( item, &string, NULL );

      if (( strlen( buffer ) + strlen( string )) > 998 )
      {
         newsrc->answer = -1;
         newsrc->confirm( newsrc, "Newsgroups header would be too long.\n"
                          "Truncating list of groups to fit inside\n"
                          "1000 characters.", NP_DONE );
         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();

         break;
      }

      strcat( buffer, string );
      strcat( buffer, "," );
   }
   
   buffer[ strlen( buffer ) - 1 ] = '\0';
   strcat( buffer, "\r\n" );
   if (( newsgroups = strdup( buffer )) == NULL )
      fatal_error();
   
   snprintf( path, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", 
             getenv( "HOME" ));
   EZ_TextSaveText( edit->header_text, path );
   if (( header = fopen( path, "r" )) == NULL )
      fatal_error();

   while( fgets( buffer, sizeof buffer, header ) != NULL )
      if ( !strncmp( buffer, "Newsgroups: ", 12 ))
         continue;
      else
         total += strlen( buffer );

   if ( edit->message.header != NULL )
      free( edit->message.header );
   if (( edit->message.header = malloc( total + strlen( newsgroups ) + 1 )) 
         == NULL )
      fatal_error();

   edit->message.header[ 0 ] = '\0';
   rewind( header );

   while( fgets( buffer, sizeof buffer, header ) != NULL )
      if ( !strncmp( buffer, "Newsgroups: ", 12 ))
         strcat( edit->message.header, newsgroups );
      else
         strcat( edit->message.header, buffer );

   if ( edit->editing )
   {
      if ( message->message.header != NULL )
         free( message->message.header );

      if (( message->message.header = strdup( edit->message.header )) == NULL )
         fatal_error();
   }

   fclose( header );
   remove( path );

   EZ_TextClear( edit->header_text );
   EZ_TextInsertString( edit->header_text, edit->message.header );
   EZ_TextBeginningOfBuffer( edit->header_text );

   edit->destroy_newsgroup_list( edit->newsgroups );
   edit->newsgroups = NULL;
   
   free( newsgroups );

   EZ_DestroyWidget( list );
   EZ_SetGrab( edit->edit_frame );
   
   return;
}

void edit_forward_message_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;


   edit = ( np_edit_object *)data;


   return;
}

void edit_addresses_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_tree_object *tree;

   EZ_Widget *left_frame, *top_button_frame, *bottom_button_frame, 
      *right_frame, *contents_frame, *list;

   EZ_Item *items[ 2 ], *item;
   EZ_TextProperty *prop;

   int h, w, count, l, i;
   char *address, *pointer, *keyword;
   

   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;

   edit->address_frame = EZ_CreateFrame( NULL, "Addresses" );

   if ( widget == buttons->addresses_button )
   {
      h = 500;
      w = 525;
   }
   else
   {
      h = 600;
      w = 800;
   }
      
   EZ_ConfigureWidget( edit->address_frame,
                       EZ_HEIGHT, h,
                       EZ_WIDTH, w,
                       EZ_IPADY, 5,
                       EZ_ORIENTATION, (( widget == edit->crosspost_button ) ?
                                        EZ_HORIZONTAL : EZ_VERTICAL ),
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   if ( widget == edit->crosspost_button )
   {
      left_frame = EZ_CreateFrame( edit->address_frame, NULL );

      EZ_ConfigureWidget( left_frame,
                          EZ_WIDTH, 525,
                          EZ_FILL_MODE, EZ_FILL_BOTH,
                          EZ_ORIENTATION, EZ_VERTICAL,
                          0 );

      contents_frame = left_frame;
   }
   else
      contents_frame = edit->address_frame;
   
   EZ_ConfigureWidget( EZ_CreateLabel( contents_frame, "email address" ),
                       EZ_LABEL_POSITION, EZ_LEFT,
                       EZ_HEIGHT, 30,
                       0 );

   edit->address_entry = EZ_CreateEntry( contents_frame, NULL );

   EZ_ConfigureWidget( edit->address_entry,
                       EZ_WIDTH, (( widget == edit->crosspost_button ) ? 500 :
                                  475 ),
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_HEIGHT, 30,
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( contents_frame, "comment" ),
                       EZ_LABEL_POSITION, EZ_LEFT,
                       EZ_HEIGHT, 30,
                       0 );

   edit->comment_entry = EZ_CreateEntry( contents_frame, NULL );

   EZ_ConfigureWidget( edit->comment_entry,
                       EZ_WIDTH, (( widget == edit->crosspost_button ) ? 500 :
                                  475 ),
                       EZ_HEIGHT, 30,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   top_button_frame = EZ_CreateFrame( contents_frame, NULL );

   EZ_ConfigureWidget( top_button_frame,
                       EZ_IPADX, 10,
                       EZ_HEIGHT, 40,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( top_button_frame, "add", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, edit->add_address_callback, edit,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( top_button_frame, "grab", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, edit->grab_address_callback, edit,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( top_button_frame, "replace", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, edit->replace_address_callback, edit,
                       0 );

   edit->address_list = EZ_CreateFancyListBox( contents_frame, 1, 1, 2, 1 );

   EZ_SetHScrollbarDiscreteSpeed( edit->address_list, 10 );
   EZ_SetVScrollbarDiscreteSpeed( edit->address_list, 10 );

   EZ_ConfigureWidget( edit->address_list,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_CALLBACK, edit->remove_address_callback, edit,
                       EZ_MOTION_CALLBACK, edit->address_list_motion_callback,
                       edit,
                       EZ_IPADX, 10,
                       0 );

   prop = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font,
                              0 );

   items[ 0 ] = EZ_CreateLabelItem( "Address", prop );
   items[ 1 ] = EZ_CreateLabelItem( "Comment", prop );

   EZ_SetFancyListBoxHeader( edit->address_list, items, 2 );

   bottom_button_frame = EZ_CreateFrame( contents_frame, NULL );

   EZ_ConfigureWidget( bottom_button_frame,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "done", 0 ),
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CLIENT_INT_DATA,
                       (( widget == edit->crosspost_button ) ?
                       1 : 0 ),
                       EZ_CALLBACK, edit->addresses_done_callback, edit,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "sort", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, edit->sort_addresses_callback, edit,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "help", 0 ),
                       EZ_CLIENT_INT_DATA, 7,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, buttons->help_callback, buttons,
                       0 );

   if ( widget == edit->crosspost_button )
   {
      EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "cancel", 0),
                          EZ_FOREGROUND, "DarkRed",
                          EZ_HEIGHT, 30,
                          EZ_WIDTH, 75,
                          EZ_EXPAND, True,
                          EZ_CALLBACK, edit->addresses_cancel_callback,
                          edit,
                          0 );
   
      right_frame = EZ_CreateFrame( edit->address_frame, NULL );

      EZ_ConfigureWidget( right_frame,
                          EZ_ORIENTATION, EZ_VERTICAL,
                          EZ_FILL_MODE, EZ_FILL_BOTH,
                          EZ_IPADY, 5,
                          0 );

      EZ_ConfigureWidget( EZ_CreateLabel( right_frame, "To:" ),
                          EZ_HEIGHT, 30,
                          EZ_FONT_NAME, newsreader->bold_font,
                          EZ_POSITION, EZ_LEFT,
                          0 );
   
      edit->to_list = EZ_CreateFancyListBox( right_frame, 1, 1, 1, 1 );

      EZ_SetHScrollbarDiscreteSpeed( edit->to_list, 10 );
      EZ_SetVScrollbarDiscreteSpeed( edit->to_list, 10 );

      EZ_ConfigureWidget( edit->to_list,
                          EZ_FONT_NAME, newsreader->medium_font,
                          EZ_CALLBACK, edit->address_list_callback, edit,
                          EZ_IPADX, 10,
                          0 );

      EZ_WidgetAddDnDDataDecoder( edit->to_list,
                                  NP_DND_ADDRESS_ATOM, 0,
                                  edit->address_dnd_add_decoder, edit,
                                  NULL, NULL );

      EZ_ConfigureWidget( EZ_CreateLabel( right_frame, "Cc:" ),
                          EZ_HEIGHT, 30,
                          EZ_FONT_NAME, newsreader->bold_font,
                          EZ_POSITION, EZ_LEFT,
                          0 );
   
      edit->cc_list = EZ_CreateFancyListBox( right_frame, 1, 1, 1, 1 );

      EZ_SetHScrollbarDiscreteSpeed( edit->cc_list, 10 );
      EZ_SetVScrollbarDiscreteSpeed( edit->cc_list, 10 );

      EZ_ConfigureWidget( edit->cc_list,
                          EZ_FONT_NAME, newsreader->medium_font,
                          EZ_CALLBACK, edit->address_list_callback, edit,
                          EZ_IPADX, 10,
                          0 );

      EZ_WidgetAddDnDDataDecoder( edit->cc_list, NP_DND_ADDRESS_ATOM, 0,
                                  edit->address_dnd_add_decoder, edit,
                                  NULL, NULL );

      EZ_ConfigureWidget( EZ_CreateLabel( right_frame, "Bcc:" ),
                          EZ_HEIGHT, 30,
                          EZ_FONT_NAME, newsreader->bold_font,
                          EZ_POSITION, EZ_LEFT,
                          0 );
   
      edit->bcc_list = EZ_CreateFancyListBox( right_frame, 1, 1, 1, 1 );

      EZ_SetHScrollbarDiscreteSpeed( edit->bcc_list, 10 );
      EZ_SetVScrollbarDiscreteSpeed( edit->bcc_list, 10 );

      EZ_ConfigureWidget( edit->bcc_list,
                          EZ_FONT_NAME, newsreader->medium_font,
                          EZ_CALLBACK, edit->address_list_callback, edit,
                          EZ_IPADX, 10,
                          0 );

      EZ_WidgetAddDnDDataDecoder( edit->bcc_list, NP_DND_ADDRESS_ATOM, 0,
                                  edit->address_dnd_add_decoder, edit,
                                  NULL, NULL );

      count = 0;

      for( i = 0; i < 3; ++i )
      {
         switch( i )
         {
         case 0:
            list = edit->to_list;
            keyword = "To:";
            break;

         case 1:
            list = edit->cc_list;
            keyword = "Cc:";
            break;

         case 2:
            list = edit->bcc_list;
            keyword = "Bcc:";
            break;
         }

         l = strlen( keyword );
         
         if (( address = edit->get_header( edit, 1, keyword, l )) != NULL )
         {
            if ( strncmp( address, "(replace", 8 ))
               for( pointer = address;
                    pointer != NULL;
                    pointer = strtok( NULL, ",\r\n" ))
               {
                  item = EZ_CreateLabelItem( pointer, tree->read_prop );
                  
                  EZ_ConfigureItem( item,
                                    EZ_TEXT_LINE_LENGTH, 120,
                                    0 );

                  EZ_FancyListBoxInsertRow( list, &item, 1, ++count );
               }

            free( address );
         }
      }
      
   }
   
   edit->dnd = -1;
   edit->update_addresses( edit );

   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));
   EZ_DisplayWidget( edit->address_frame );
   EZ_SetGrab( edit->address_frame );

   for( ; ; )
   {
      while( edit->dnd == -1 )
         EZ_WaitAndServiceNextEvent();

      if ( edit->dnd == -2 )
         break;

      edit->update_addresses( edit );
      edit->dnd = -1;
   }

   return;
}

void edit_addresses_cancel_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;


   edit = ( np_edit_object *)data;

   EZ_DestroyWidget( edit->address_frame );
   EZ_SetGrab( edit->edit_frame );
   
   return;
}

void edit_add_address_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ];
   

   edit = ( np_edit_object *)data;
   
   strcpy( buffer, EZ_GetEntryString( edit->address_entry ));
   if ( !strlen( buffer ))
      return;

   strcpy( second_buffer, EZ_GetEntryString( edit->comment_entry ));

   strcat( buffer, "\t");
   strcat( buffer, second_buffer );
   if ( ln_add_address( buffer ) == -1 )
      lib_error();

   edit->update_addresses( edit );
   
   return;
}

void edit_replace_address_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_newsrc_object *newsrc;

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
      *string;
   
   int r;
   EZ_Item **selected;


   edit = ( np_edit_object *)data;

   EZ_GetFancyListBoxSelectionIdx( edit->address_list, &r, NULL );

   if ( r == -1 )
   {
      newsrc->confirm( newsrc,
                       "Select an address in the list\nto replace, first.",
                       NP_DONE );
      return;
   }

   strcpy( buffer, EZ_GetEntryString( edit->address_entry ));
   if ( !strlen( buffer ))
      return;

   strcpy( second_buffer, EZ_GetEntryString( edit->comment_entry ));
   
   strcat( buffer, "\t" );
   strcat( buffer, second_buffer );

   selected = EZ_GetFancyListBoxSelection( edit->address_list );
   EZ_GetLabelItemStringInfo( selected[ 0 ], &string, NULL );
   strcpy( second_buffer, string );

   if ( ln_replace_address( second_buffer, buffer ) == -1 )
      lib_error();

   edit->update_addresses( edit );
   
   return;
}

void edit_sort_addresses_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;


   edit = ( np_edit_object *)data;

   if ( ln_sort_addresses() == -1 )
      lib_error();
   
   edit->update_addresses( edit );
   
   return;
}

void edit_remove_address_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;

   char buffer[ LN_BUFFER_SIZE ], *string;

   EZ_Item **item;


   edit = ( np_edit_object *)data;

   item = EZ_GetFancyListBoxSelection( edit->address_list );

   EZ_GetLabelItemStringInfo( item[ 0 ], &string, NULL );
   strcpy( buffer, string );

   EZ_GetLabelItemStringInfo( item[ 1 ], &string, NULL );
   strcat( buffer, "\t" );
   strcat( buffer, string );

   if ( ln_remove_address( buffer ) == -1 )
      lib_error();
   
   edit->update_addresses( edit );
              
   return;
}

int edit_get_recipients( void *this, EZ_Widget *list, char *keyword )
{
   np_edit_object *edit;
   np_newsrc_object *newsrc;
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_message_object *message;

   int limit, i, total, l, found;
   char buffer[ LN_BUFFER_SIZE ], path[ LN_BUFFER_SIZE ], *string,
      *addresses;
   FILE *header;

   EZ_Item *item;
   

   edit = ( np_edit_object *)this;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   message = ( np_message_object *)newsreader->message_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   
   if ( !(( limit = EZ_GetFancyListBoxNumberOfRows( list )) - 1 ))
   {
      if ( strcmp( keyword, "To:" ))
         return 0;
      
      newsrc->answer = -1;
      newsrc->confirm( newsrc,
                       "You must have at least one\naddress in the To: "
                       "header.", NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      return -1;
   }

   strcpy( buffer, keyword );
   strcat( buffer, " " );
   
   i = 1;
   while( i < limit )
   {
      item = EZ_GetFancyListBoxItemUsingIdx( list, i++, 0 );
      EZ_GetLabelItemStringInfo( item, &string, NULL );

      if (( strlen( buffer ) + strlen( string )) > 998 )
      {
         newsrc->answer = -1;
         newsrc->confirm( newsrc, "Header would be too long.\n"
                          "Truncating list of addresses to fit\n"
                          "inside 1000 characters.", NP_DONE );
         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();
         break;
      }

      strcat( buffer, string );
      strcat( buffer, "," );
   }

   buffer[ strlen( buffer ) - 1 ] = '\0';
   strcat( buffer, "\r\n" );
   if (( addresses = strdup( buffer )) == NULL )
      fatal_error();

   snprintf( path, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp",
             getenv( "HOME" ));
   EZ_TextSaveText( edit->header_text, path );
   if (( header = fopen( path, "r" )) == NULL )
      fatal_error();

   l = strlen( keyword );
   total = 0;

   while( fgets( buffer, LN_BUFFER_SIZE, header ) != NULL )
      if ( !strncmp( buffer, keyword, l ))
         continue;
      else
         total += strlen( buffer );

   if ( edit->message.header != NULL )
      free( edit->message.header );
   if (( edit->message.header = malloc( total + strlen( addresses ) + 1 ))
       == NULL )
      fatal_error();

   edit->message.header[ 0 ] = '\0';
   rewind( header );
   found = 0;
   
   while( fgets( buffer, LN_BUFFER_SIZE, header ) != NULL )
      if ( !strncmp( buffer, keyword, l ))
      {
         found = 1;
         strcat( edit->message.header, addresses );
      }
      else
         strcat( edit->message.header, buffer );

   if ( !found )
      strcat( edit->message.header, addresses );
   
   if ( edit->editing )
   {
      if ( message->message.header != NULL )
         free( message->message.header );

      if (( message->message.header = strdup( edit->message.header ))
          == NULL )
         fatal_error();
   }

   fclose( header );
   remove( path );

   EZ_TextClear( edit->header_text );
   EZ_TextInsertString( edit->header_text, edit->message.header );
   EZ_TextBeginningOfBuffer( edit->header_text );

   return 0;
}

void edit_addresses_done_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_tree_object *tree;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_newsrc_object *newsrc;
   np_message_object *message;

   EZ_TreeNode *selected;
   EZ_Item *item;

   char group;
   long int i, j;


   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;
   message = ( np_message_object *)newsreader->message_object;

   edit->dnd = -2;

   if ( EZ_GetWidgetIntData( widget ))
   {
      if ( edit->get_recipients( edit, edit->to_list, "To:" ))
         return;
      
      edit->get_recipients( edit, edit->cc_list, "Cc:" );
      edit->get_recipients( edit, edit->bcc_list, "Bcc:" );
      
      EZ_DestroyWidget( edit->address_frame );
      EZ_SetGrab( edit->edit_frame );
      return;
   }
   
   EZ_DestroyWidget( edit->address_frame );

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) != NULL &&
         selected != tree->root_node )
   {
      group
         = *( char *)EZ_GetItemPtrData( item = EZ_TreeNodeGetItem( selected ));
      i = EZ_GetItemIntData( item );
   }
   else
      i = -1;

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
       != NULL )
      j = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));
   else
      j = -1;
         
   tree->update_lists( tree );
   tree->set_tree( tree );

   if ( -1 < i )
   {
      if ( group == 's' && i < tree->servers )
         EZ_ListTreeWidgetSelectNode( tree->tree, tree->server_nodes[ i ],
                                      NULL );
      else
      {
         if ( i < tree->groups )
            EZ_ListTreeWidgetSelectNode( tree->tree,
                                         tree->group_nodes[ i ], NULL );
         if ( -1 < j && j < summary->stats.total )
            EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                         summary->node_list[ j ], NULL );
      }
   }

   EZ_NormalCursor( newsreader->app_frame );
   
   return;
}

void edit_address_list_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;

   int r;
   

   edit = ( np_edit_object *)data;

   EZ_GetFancyListBoxSelectionIdx( widget, &r, NULL );
   EZ_FancyListBoxDeleteRow( widget, r );
   
   return;
}

void edit_update_addresses( void *this )
{
   np_edit_object *edit;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ];
   unsigned int i;
   FILE *file;

   EZ_Item *items[ 2 ];
   EZ_TextProperty *prop[ 2 ];


   edit = ( np_edit_object *)this;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)edit->parent )->parent;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-addresses",
             getenv( "HOME" ));

   if (( file = fopen( buffer, "r" )) == NULL )
      if ( errno != ENOENT )
         fatal_error();
      else
         return;

   EZ_FreezeWidget( edit->address_list );
   EZ_FancyListBoxClear( edit->address_list );

   prop[ 0 ] = EZ_GetTextProperty( EZ_FOREGROUND, "DarkBlue",
                                   EZ_FONT_NAME, newsreader->medium_font,
                                   0 );

   prop[ 1 ] = EZ_GetTextProperty( EZ_FOREGROUND, "DarkRed",
                                   EZ_FONT_NAME, newsreader->medium_font,
                                   0 );

   i = 0;
   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
   {
      items[ 0 ] = EZ_CreateLabelItem( strtok( buffer, "\t" ), prop[ 0 ] );

      EZ_ItemAddDnDDataEncoder( items[ 0 ], NP_DND_ADDRESS_ATOM, 0,
                                edit->address_dnd_reorder_encoder, edit,
                                NULL, NULL );

      EZ_ItemAddDnDDataDecoder( items[ 0 ], NP_DND_ADDRESS_ATOM, 0,
                                edit->address_dnd_reorder_decoder, edit,
                                NULL, NULL );

      items[ 1 ] = EZ_CreateLabelItem( strtok( NULL, "\n" ), prop[ 1 ] );

      EZ_ConfigureItem( items[ 0 ],
                        EZ_CLIENT_INT_DATA, i,
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );

      EZ_ConfigureItem( items[ 1 ],
                        EZ_CLIENT_INT_DATA, i,
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );

      EZ_FancyListBoxInsertRow( edit->address_list, items, 2, ++i );
   }

   fclose( file );

   EZ_UnFreezeWidget( edit->address_list );

   if ( edit->dnd >= 0 )
      EZ_FancyListBoxSelectItemUsingIdx( edit->address_list,
                                         ++edit->dnd, 0, NULL );
   
   return;
}

void edit_address_list_motion_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;

   EZ_Item **item;
   
   char *string;
   

   edit = ( np_edit_object *)data;
   
   item = EZ_GetFancyListBoxSelection( edit->address_list );
   EZ_GetLabelItemStringInfo( item[ 0 ], &string, NULL );
   EZ_SetEntryString( edit->address_entry, string );

   EZ_GetLabelItemStringInfo( item[ 1 ], &string, NULL );
   EZ_SetEntryString( edit->comment_entry, string );
   
   return;
}

int edit_address_dnd_reorder_encoder( EZ_Item *item, void *data,
                                      char **message, int *length,
                                      int *needfree )
{
   unsigned int follower;

   char buffer[ LN_BUFFER_SIZE ];


   follower = EZ_GetItemIntData( item );
   snprintf( buffer, LN_BUFFER_SIZE, "%d", follower );

   *length = strlen( buffer);

   if (( *message = malloc( *length )) == NULL )
      fatal_error();

   strcpy( *message, buffer );
   *needfree = 1;

   return EZ_DND_SUCCESS;
}

int edit_address_dnd_reorder_decoder( EZ_Item *item, void *data, char *message,
                                      int length )
{
   np_edit_object *edit;

   unsigned int source, target;


   edit = ( np_edit_object *)data;

   target = EZ_GetItemIntData( item );
   source = atoi( message );

   if ( target == source || ( target == source - 1 ))
      return EZ_DND_FAILURE;

   if ( ln_move_address( target, source ) == -1 )
      lib_error();

   edit->dnd = (( source < target ) ? target : target + 1 );

   return EZ_DND_SUCCESS;
}

int edit_address_dnd_add_decoder( EZ_Widget *widget, void *data, char *message,
                                  int length )
{
   np_edit_object *edit;
   np_newsreader_object *newsreader;

   EZ_Item **items, *item;
   EZ_TextProperty *prop;

   int r;
   char *string;


   edit = ( np_edit_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)edit->parent )->parent;

   items = EZ_GetFancyListBoxSelection( edit->address_list );
   EZ_GetLabelItemStringInfo( items[ 0 ], &string, NULL );

   prop = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->medium_font,
                              0 );

   EZ_ConfigureItem( item = EZ_CreateLabelItem( string, prop ),
                     EZ_TEXT_LINE_LENGTH, 120,
                     0 );

   r = EZ_GetFancyListBoxNumberOfRows( widget );
   EZ_FancyListBoxInsertRow( widget, &item, 1, r );
   
   return EZ_DND_SUCCESS;
}

void edit_grab_address_callback( EZ_Widget *widget, void *data )
{
   np_edit_object *edit;
   np_message_object *message;
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_newsrc_object *newsrc;
   np_summary_object *summary;
   
   char *pointer, found = 0;

   
   edit = ( np_edit_object *)data;
   buttons = ( np_buttons_object *)edit->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   message = ( np_message_object *)newsreader->message_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   summary = ( np_summary_object *)newsreader->summary_object;
   
   if ( EZ_GetListTreeWidgetSelection( summary->thread_tree ) == NULL ||
        ( pointer = message->message.header - 1 ) == NULL )
   {
      newsrc->answer = -1;
      newsrc->confirm( newsrc, "No message is currently-selected.", NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
      return;
   }

   while( *( ++pointer ))
   {
      if ( !strncasecmp( pointer, "Reply-To:", 9 ))
      {
         found = 1;
         break;
      }
      else
         if ( !strncasecmp( pointer, "From:", 5 ))
         {
            found = 1;
            break;
         }

      pointer = strchr( pointer, '\n' );
   }
   
   if ( !found )
   {
      newsrc->answer = -1;
      newsrc->confirm( newsrc, "Message has no Reply-To, nor\n"
                       "From header to take address from.", NP_DONE );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();
      return;
   }
   
   strtok( pointer = strchr( pointer, ':' ) + 1, "\r\n" );
   EZ_SetEntryString( edit->address_entry, pointer );
   
   return;
}
