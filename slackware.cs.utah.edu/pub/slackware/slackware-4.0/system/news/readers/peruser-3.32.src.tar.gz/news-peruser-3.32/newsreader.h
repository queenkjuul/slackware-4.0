/*
 * Prototypes.
 */

void newsreader_init( void *this, int argc, char **argv );
void newsreader_run();
void newsreader_destroy( void *parent );
void newsreader_show_message( void *this, char *message );
void newsreader_set_fonts( EZ_Widget *widget, void *data );
void newsreader_decode_callback( EZ_Widget *widget, void *data );
void newsreader_fixed_callback( EZ_Widget *widget, void *data );
void newsreader_hide_seen_callback( EZ_Widget *widget, void *data );
void newsreader_hide_headers_callback( EZ_Widget *widget, void *data );
void newsreader_auto_expire_callback( EZ_Widget *widget, void *data );
void newsreader_hide_callback( EZ_Widget *widget, void *data );
void newsreader_long_headers_callback( EZ_Widget *widget, void *data );
void newsreader_split_button_callback( EZ_Widget *widget, void *data );
void newsreader_split_frame_callback( EZ_Widget *widget, void *data );
