/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "libnews.h"

/*
 * Adds a newsgroup entry under the specified server in ~/.perser3-newsrc.
 */

int ln_add_group( char *server, char *group )
{
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ], 
   *home;
   int length;
   FILE *newsrc, *temp;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", 
             home = getenv( "HOME" ));
   if (( newsrc = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_add_group: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ".tmp" );
   strcpy( second_buffer, buffer );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( newsrc );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_add_group: could not open file %s.",
                buffer );
      return -1;
   }

   length = strlen( server );

   while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
   {
      if ( isspace( buffer[ 0 ] ))
      {
         fputs( buffer, temp );
         continue;
      }

      if ( !strncmp( buffer, server, length ))
      {
         fputs( buffer, temp );
         fprintf( temp, "\t%s:\n", group );

         while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
            fputs( buffer, temp );

         break;
      }

      fputs( buffer, temp );
   }

   fclose( newsrc );
   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", home );
   snprintf( second_buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc.tmp", home );

   rename( second_buffer, buffer );

   return 0;
}

/*
 * Adds the specified server to ~/.peruser3-newsrc.
 */

int ln_add_server( char *server )
{
   FILE *newsrc;
   char buffer[ LN_BUFFER_SIZE ];


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", getenv( "HOME" ));
   if (( newsrc = fopen( buffer, "a" )) == NULL )
   {
      if ( errno == ENOENT )
         if (( newsrc = fopen( buffer, "w" )) == NULL )
         {
            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_add_server: could not open file %s.",
                      buffer );
            return -1;
         }
   }

   fprintf( newsrc, "%s\n", server );

   fclose( newsrc );

   return 0;
}

/*
 * Removes the specified group entry from the specified server list in
 * ~/.peruser3-newsrc.
 */

int ln_remove_group( char *server, char *group )
{
   char *home, buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
   third_buffer[ LN_BUFFER_SIZE ];
   char *pointer;
   FILE *newsrc, *temp;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", 
             home = getenv( "HOME" ));
   if (( newsrc = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_remove_group: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ".tmp" );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( newsrc );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_remove_group: could not open file %s.",
                buffer );
      return -1;
   }

   while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
   {
      if ( !isspace( buffer[ 0 ] ))
      {
         fputs( buffer, temp );
         strcpy( second_buffer, buffer );
         strtok( second_buffer, "\n" );
         continue;
      }

      strcpy( third_buffer, buffer );

      pointer = strtok( third_buffer + strspn( third_buffer, " \t" ),
                        ":" );

      if ( !strcmp( server, second_buffer ))
         if ( !strcmp( pointer, group ))
            continue;

      fputs( buffer, temp );
   }

   fclose( newsrc );
   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", home );
   strcpy( second_buffer, buffer );
   strcat( second_buffer, ".tmp" );
   rename( second_buffer, buffer );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home, group );
   remove( buffer );

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s:read", buffer );
   remove( second_buffer );

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s:requests", buffer );
   remove( second_buffer );

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s:threading", buffer );
   remove( second_buffer );

   return 0;
}

/*
 * Removes the specified server entry from ~/.peruser3-newsrc.
 */

int ln_remove_server( char *server )
{
   FILE *newsrc, *temp;
   int length;
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ], 
   *home;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", 
             home = getenv( "HOME" ));
   if (( newsrc = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_remove_server: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ".tmp" );
   strcpy( second_buffer, buffer );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( newsrc );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_remove_server: could not open file %s.",
                buffer );
      return -1;
   }

   length = strlen( server );

   while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
   {
      if ( isspace( buffer[ 0 ] ))
      {
         fputs( buffer, temp );
         continue;
      }

      if ( !strncmp( buffer, server, length ))
         continue;

      fputs( buffer, temp );
   }

   fclose( newsrc );
   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", home );
   snprintf( second_buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc.tmp", home );
   rename( second_buffer, buffer );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-LIST", 
             home, server );
   remove( buffer );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-TIMESTAMP", 
             home, server );
   remove( buffer );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-FOLLOW-UPS",
             home, server );
   remove( buffer );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-POSTED", home, 
             server );
   remove( buffer );

   return 0;
}

/*
 * Moves a specified line in specified file, to sit directly after another
 * line in the file.
 */

int ln_move_line( unsigned int leader, unsigned int follower, char *filename )
{
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
   third_buffer[ LN_BUFFER_SIZE ], *home;
   FILE *file, *temp;
   unsigned int l, f;
   enum{ no, yes }newsrc;


   l = leader;
   f = follower;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", home = getenv( "HOME" ), 
         filename );
   if (( file = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_move_line: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ".tmp" );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( file );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_move_line: could not open file %s.", buffer );
      return -1;
   }

   if ( !strcmp( filename, ".peruser3-newsrc" ))
      newsrc = yes;
   else
      newsrc = no;

   do
   {
      if ( fgets( buffer, LN_BUFFER_SIZE, file ) == NULL )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_move_line: premature end of %s", filename );
         fclose( file );
         fclose( temp );
         return -1;
      }

      if ( newsrc )
         if ( !isspace( buffer[ 0 ] ))
            l++;
   }
   while( l-- );

   rewind( file );

   do 
   {
      if ( fgets( second_buffer, LN_BUFFER_SIZE, file ) == NULL )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_move_line: premature end of %s.", filename );
         fclose( file );
         fclose( temp );
         return -1;
      }

      if ( newsrc )
         if ( !isspace( second_buffer[ 0 ] ))
            f++;
   }
   while( f-- );

   rewind( file );

   while( fgets( third_buffer, LN_BUFFER_SIZE, file ) != NULL )
   {
      if ( !strcmp( third_buffer, second_buffer ))
         continue;

      fputs( third_buffer, temp );

      if ( !strcmp( third_buffer, buffer ))
         fputs( second_buffer, temp );
   }

   fclose( file );
   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/%s", home, filename );
   strcpy( second_buffer, buffer );
   strcat( second_buffer, ".tmp" );

   rename( second_buffer, buffer );

   return 0;
}

/*
 * Adds a line of specified text behind another in ~/.peruser3-newsrc.
 * Used to add a group from the information gained from a drag-and-drop
 * transaction.
 */

int ln_add_group_behind( char *leader, char *follower )
{
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ], *home;
   FILE *newsrc, *temp;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", 
             home = getenv( "HOME" ));
   if (( newsrc = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_add_group_behind: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ".tmp" );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( newsrc );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_add_group_behind: could not open file %s.",
                buffer );
      return -1;
   }


   while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
   {
      fputs( buffer, temp );

      strcpy( second_buffer, strtok( buffer + strspn( buffer, " \t" ), ":" ));
      if ( !strcmp( second_buffer, leader  ))
         fprintf( temp, "\t%s:\n", follower );
   }

   fclose( newsrc );
   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", home );
   strcpy( second_buffer, buffer );
   strcat( second_buffer, ".tmp" );

   rename( second_buffer, buffer );

   return 0;
}

/*
 * Wrapper function. Moves a line in ~/.peruser3-newsrc, to sit directly after
 * another line in the file.
 */

int ln_move_group( unsigned int leader, unsigned int follower )
{ 
   return ln_move_line( leader, follower, ".peruser3-newsrc" );
}
