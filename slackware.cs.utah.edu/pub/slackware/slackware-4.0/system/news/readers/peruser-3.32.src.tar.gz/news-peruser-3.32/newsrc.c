/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "peruser.h"

#include "confirm.xpm"
#include "query.xpm"
#include "animate_0.xpm"
#include "animate_1.xpm"
#include "animate_2.xpm"
#include "animate_3.xpm"
#include "animate_4.xpm"
#include "animate_5.xpm"
#include "animate_6.xpm"

#include<unistd.h>
#include<sys/types.h>
#include<signal.h>
#include<sys/wait.h>
#include<regex.h>

#include "newsrc.h"
#include "tree.h"

/*
 * Constructor.
 */

void newsrc_init( void *this )
{
   np_buttons_object *buttons;
   np_newsrc_object *newsrc;


   buttons = ( np_buttons_object *)this;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   newsrc->parent = buttons;

   newsrc->confirm_pixmap = EZ_CreateLabelPixmapFromXpmData( confirm_xpm );
   newsrc->query_pixmap = EZ_CreateLabelPixmapFromXpmData( query_xpm );

   newsrc->animate_pixmap_0 = EZ_CreateLabelPixmapFromXpmData( animate_0_xpm );
   newsrc->animate_pixmap_1 = EZ_CreateLabelPixmapFromXpmData( animate_1_xpm );
   newsrc->animate_pixmap_2 = EZ_CreateLabelPixmapFromXpmData( animate_2_xpm );
   newsrc->animate_pixmap_3 = EZ_CreateLabelPixmapFromXpmData( animate_3_xpm );
   newsrc->animate_pixmap_4 = EZ_CreateLabelPixmapFromXpmData( animate_4_xpm );
   newsrc->animate_pixmap_5 = EZ_CreateLabelPixmapFromXpmData( animate_5_xpm );
   newsrc->animate_pixmap_6 = EZ_CreateLabelPixmapFromXpmData( animate_6_xpm );

   newsrc->groups = 0;
   newsrc->answer = -1;
   newsrc->server = -1;
   newsrc->groups = 0;
   newsrc->pid = -1;

   newsrc->pos[ 0 ] = 10;
   newsrc->pos[ 1 ] = 10;

   newsrc->callback = newsrc_callback;
   newsrc->done_callback = newsrc_done_callback;

   newsrc->tree_normal_callback = newsrc_tree_normal_callback;
   newsrc->tree_motion_callback = newsrc_tree_motion_callback;

   newsrc->list_normal_callback = newsrc_list_normal_callback;
   newsrc->list_button_callback = newsrc_list_button_callback;

   newsrc->sort_callback = newsrc_sort_callback;
   newsrc->search_callback = newsrc_search_callback;

   newsrc->new_group_callback = newsrc_new_group_callback;
   newsrc->new_server_callback = newsrc_new_server_callback;
   newsrc->remove_server_config = newsrc_remove_server_config;

   newsrc->confirm = newsrc_confirm;
   newsrc->confirm_callback = newsrc_confirm_callback;

   newsrc->animate = newsrc_animate;
   newsrc->kill_callback = newsrc_kill_callback;

   newsrc->select_node = newsrc_select_node;
   newsrc->authinfo_callback = newsrc_authinfo_callback;
   
   return;
}

/*
 * Callback of servers/groups button on configure menu.
 * Displays newsrc frame.
 */

void newsrc_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_buttons_object *buttons;

   EZ_Widget *buttons_frame, *left_frame, *right_frame, *searchlist_frame,
   *sort_button, *sort_menu;

   EZ_Item *item;
   EZ_TextProperty *property;


   newsrc = ( np_newsrc_object *)data;
   buttons = ( np_buttons_object *)newsrc->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;

   newsrc->server = -1;

   /* newsrc_frame */

   newsrc->newsrc_frame = EZ_CreateFrame( NULL, "Servers/Groups" );

   EZ_ConfigureWidget( newsrc->newsrc_frame,
                       EZ_HEIGHT, 550,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   /* left_frame */

   left_frame = EZ_CreateFrame( newsrc->newsrc_frame, NULL );

   EZ_ConfigureWidget( left_frame,
                       EZ_WIDTH, 325,
                       EZ_IPADY, 10,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   /* right_frame */
   right_frame = EZ_CreateFrame( newsrc->newsrc_frame, NULL );

   EZ_ConfigureWidget( right_frame,
                       EZ_IPADY, 10,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   /* tree */

   if (( newsrc->tree_object = malloc( sizeof *newsrc->tree_object ))
         == NULL )
      fatal_error();

   tree = newsrc->tree_object;

   newsrc->tree_object->init = tree_init;
   newsrc->tree_object->init( newsrc->tree_object, newsrc, left_frame,
                              newsreader );

   /* server_entry */

   EZ_ConfigureWidget( EZ_CreateLabel( left_frame, "new server:" ),
                                       EZ_LABEL_POSITION, EZ_LEFT,
                                       EZ_HEIGHT, 20,
                                       0 );

   newsrc->server_entry = EZ_CreateEntry( left_frame, NULL );

   EZ_ConfigureWidget( newsrc->server_entry,
                       EZ_WIDTH, 300,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_CALLBACK, newsrc->new_server_callback,
                       newsrc,
                       0 );

   /* group_entry */
   EZ_ConfigureWidget( EZ_CreateLabel( left_frame, "new group:" ),
                       EZ_LABEL_POSITION, EZ_LEFT,
                       EZ_HEIGHT, 20,
                       0 );

   newsrc->group_entry = EZ_CreateEntry( left_frame, NULL );

   EZ_ConfigureWidget( newsrc->group_entry,
                       EZ_WIDTH, 300,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_CALLBACK, newsrc->new_group_callback,
                       newsrc,
                       0 );

   /* list */

   newsrc->list = EZ_CreateFancyListBox( right_frame, 1, 1, 1, 1 );

   EZ_ConfigureWidget( newsrc->list, 
                       EZ_CALLBACK, newsrc->list_normal_callback, newsrc,
                       0 );

   EZ_SetHScrollbarDiscreteSpeed( newsrc->list, 10 );
   EZ_SetVScrollbarDiscreteSpeed( newsrc->list, 10 );

   property = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font, 0 );
   item = EZ_CreateLabelItem( "Active Groups", property );
   EZ_SetFancyListBoxHeader( newsrc->list, &item, 1 );

   EZ_ConfigureWidget( EZ_CreateLabel( right_frame, "search list:" ),
                       EZ_LABEL_POSITION, EZ_LEFT,
                       EZ_HEIGHT, 20,
                       0 );

   /* searchlist stuff */

   searchlist_frame = EZ_CreateFrame( right_frame, NULL );

   EZ_ConfigureWidget( searchlist_frame,
                       EZ_HEIGHT, 30,
                       EZ_PADX, 10,
                       0 );

   newsrc->searchlist_entry = EZ_CreateEntry( searchlist_frame, NULL );

   EZ_ConfigureWidget( newsrc->searchlist_entry,
                       EZ_WIDTH, 275,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_CALLBACK, newsrc->search_callback, newsrc,
                       0 );

   newsrc->search_button = EZ_CreateButton( searchlist_frame, "search", 1 );

   EZ_ConfigureWidget( newsrc->search_button,
                       EZ_WIDTH, 75,
                       EZ_HEIGHT, 30,
                       EZ_CALLBACK, newsrc->search_callback, newsrc,
                       0 );

   /* placeholder label */

   newsrc->searchlist_label = EZ_CreateLabel( right_frame, " " );

   EZ_ConfigureWidget( newsrc->searchlist_label,
                       EZ_FONT_NAME, newsreader->bold_font,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_TEXT_LINE_LENGTH, 80,
                       EZ_LABEL_POSITION, EZ_CENTER,
                       EZ_HEIGHT, 22,
                       0 );

   /* buttons_frame */

   buttons_frame = EZ_CreateFrame( right_frame, NULL );

   EZ_ConfigureWidget( buttons_frame,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       EZ_IPADX, 10,
                       EZ_HEIGHT, 30,
                       0 );

   /* done */

   EZ_ConfigureWidget( EZ_CreateButton( buttons_frame, "done", 0 ),
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, newsrc->done_callback, newsrc,
                       0 );

   /* sort button */

   sort_button = EZ_CreateMenuButton( buttons_frame, "sort", 0 );

   EZ_ConfigureWidget( sort_button,
                       EZ_HEIGHT, 30,
                       EZ_BORDER_TYPE, EZ_BORDER_RAISED,
                       0 );

   sort_menu = EZ_CreateMenu( NULL );

   EZ_ConfigureWidget( sort_menu,
                       EZ_IPADY, 5,
                       EZ_MENU_TEAR_OFF, False,
                       0 );

   EZ_SetMenuButtonMenu( sort_button, sort_menu );

   newsrc->server_button
      = EZ_CreateMenuNormalButton( sort_menu, "server's group tree", 0, 1 );

   EZ_ConfigureWidget( newsrc->server_button,
                       EZ_CALLBACK, newsrc->sort_callback, newsrc,
                       0 );

   EZ_ConfigureWidget( EZ_CreateMenuNormalButton( sort_menu,
                                                  "server's active groups", 0,
                                                  1 ),
                       EZ_CALLBACK, newsrc->sort_callback, newsrc,
                       0 );

   /* update button */

   EZ_ConfigureWidget( EZ_CreateButton( buttons_frame, "update list", 0 ),
                       EZ_CALLBACK, newsrc->list_button_callback, newsrc,
                       EZ_EXPAND, True,
                       EZ_HEIGHT, 30,
                       0 );

   /* list button */

   newsrc->list_button = EZ_CreateButton( buttons_frame, "get list", 0 );

   EZ_ConfigureWidget( newsrc->list_button,
                       EZ_CALLBACK, newsrc->list_button_callback,
                       newsrc,
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       0 );

   /* help */

   EZ_ConfigureWidget( EZ_CreateButton( buttons_frame, "help", 0 ),
                       EZ_CLIENT_INT_DATA, 2,
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, buttons->help_callback, buttons,
                       0 );

   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));
   EZ_DisplayWidget( newsrc->newsrc_frame );
   EZ_SetGrab( newsrc->newsrc_frame );

   /* 
    * This hack prevents corruption of EZWGL's DnD system by preventing 
    * calls to the DnD system from being made from within DnD decoders 
    * or callbacks. M. Zhou suspects a bug in his library is making the 
    * code non-reentrant. He asked me to send him some example code. 
    * I must get around to doing so.
    */

   tree->dnd = -1;
   for( ; ; )
   {
      while( tree->dnd == -1 )
         EZ_WaitAndServiceNextEvent();

      if ( tree->dnd == -2 )
         break;

      tree->update_lists( tree );
      tree->set_tree( tree );
      newsrc->select_node( tree );
      tree->dnd = -1;
   }

   tree->destroy( tree );
   free( tree );

   return;
}

/*
 * Selects node in tree corresponding to a drag source node's new position,
 * after a drag-and-drop transaction.
 */

void newsrc_select_node( void *tree_object )
{
   np_tree_object *tree;
   np_buttons_object *buttons;


   tree = ( np_tree_object *)tree_object;
   buttons = ( np_buttons_object *)
      (( np_newsrc_object *)tree->parent )->parent;

   if ( tree->add )
      tree->dnd++;

   EZ_ListTreeWidgetSelectNode( tree->tree, 
                                tree->group_nodes[ tree->dnd ], NULL );

   return;
}

/*
 * Callback of sort button. Sorts either the groups in the currently-selected
 * server's subtree, or the currently-selected server's list of active
 * newsgroups.
 */

void newsrc_sort_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;
   np_tree_object *tree;

   EZ_TreeNode *selected;
   EZ_Item *item;

   enum{ SERVER, GROUP }what;
   char *server, buffer[ LN_BUFFER_SIZE ];
   unsigned int i;


   newsrc = ( np_newsrc_object *)data;
   tree = ( np_tree_object *)newsrc->tree_object;

   if ( newsrc->server < 0 )
   {
      newsrc_confirm( newsrc, "Select a server in the tree, first.", NP_DONE );
      return;
   }

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      return;

   if (( item = EZ_TreeNodeGetItem( selected )) == NULL )
         return;

   i = ( unsigned int )EZ_GetItemIntData( item );

   if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      what = SERVER;
   else
      what = GROUP;

   server = tree->server_list[ newsrc->server ].server;

   EZ_ConfigureWidget( newsrc->searchlist_label,
         EZ_LABEL_STRING, "Sorting...",
         0 );
   EZ_WaitCursor( newsrc->newsrc_frame, EZ_GetCursor( XC_watch ));
   XFlush( EZ_GetDisplay() );

   if ( widget == newsrc->server_button )
   {
      if ( ln_sort_server( server ) == -1 )
         lib_error();

      tree->update_lists( tree );
      tree->set_tree( tree );

      EZ_ListTreeWidgetSelectNode( tree->tree, tree->server_nodes[ i ], NULL );
   }
   else 
   {
      if ( ln_sort_list( server ) == -1 )
         lib_error();

      newsrc->server = -1;

      newsrc->tree_motion_callback( newsrc->tree_object->tree, 
                                    newsrc->tree_object );
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%d groups in list", newsrc->groups );
   EZ_ConfigureWidget( newsrc->searchlist_label, 
                       EZ_LABEL_STRING, buffer,
                       0 );
   EZ_NormalCursor( newsrc->newsrc_frame );

   return;
}

/*
 * Callback of done button on newsrc frame. Destroys newsrc frame.
 */

void newsrc_done_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_summary_object *summary;
   np_newsreader_object *newsreader;

   EZ_TreeNode *selected;
   EZ_Item *item;

   char buffer[ 80 ], group;
   long int i, j;
   

   newsrc = ( np_newsrc_object *)data;
   buttons = ( np_buttons_object *)newsrc->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   /* regfree */

   newsrc->search_callback( NULL, newsrc );

   newsrc->tree_object->dnd = -2;

   EZ_WaitCursor( newsrc->newsrc_frame, EZ_GetCursor( XC_watch ));

   if ( newsrc->groups )
   {
      snprintf( buffer, LN_BUFFER_SIZE, "Destroying %d display items...",
                newsrc->groups );
      EZ_ConfigureWidget( newsrc->searchlist_label, 
                          EZ_LABEL_STRING, buffer, 
                          0 );
   }

   EZ_FancyListBoxClear( newsrc->list );
   EZ_DestroyWidget( newsrc->newsrc_frame );

   /* update newsreader->tree_object lists */

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) != NULL &&
         selected != tree->root_node )
     {
        item = EZ_TreeNodeGetItem( selected );
       group
         = *( char *)EZ_GetItemPtrData( item );
       i = EZ_GetItemIntData( item );
     }
   else
     i = -1;

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
         != NULL )
     j = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));
   else
     j = -1;

   tree->update_lists( tree );
   tree->set_tree( tree );

   if ( -1 < i )
     {
       if ( group == 's' && i < tree->servers )
         EZ_ListTreeWidgetSelectNode( tree->tree, tree->server_nodes[ i ],
                                      NULL );
       else
       {
           if ( i < tree->groups )
               EZ_ListTreeWidgetSelectNode( tree->tree, 
                                            tree->group_nodes[ i ], NULL );

           if ( -1 < j && j < summary->stats.total )
               EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                            summary->node_list[ j ],
                                            NULL );
       }
     }

   EZ_NormalCursor( newsreader->app_frame );

   return;
}

/*
 * Removes entries for a deleted server from ~/.peruser3-config.
 */

void newsrc_remove_server_config( void *this, unsigned int i )
{
   np_newsrc_object *newsrc;

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
   *home;

   FILE *config, *temp;


   newsrc = ( np_newsrc_object *)this;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config", 
             home = getenv( "HOME" ));
   if (( config = fopen( buffer, "r" )) == NULL )
      if ( errno == ENOENT )
         return;
      else
         fatal_error();

   strcpy( second_buffer, buffer );
   strcat( second_buffer, "_temp" );

   if (( temp = fopen( second_buffer, "w" )) == NULL )
      fatal_error();

   fgets( buffer, LN_BUFFER_SIZE, config );
   fputs( buffer, temp );
   fgets( buffer, LN_BUFFER_SIZE, config );
   fputs( buffer, temp );
   fgets( buffer, LN_BUFFER_SIZE, config );
   fputs( buffer, temp );
   fgets( buffer, LN_BUFFER_SIZE, config );
   fputs( buffer, temp );

   while( i-- )
   {
      fgets( buffer, LN_BUFFER_SIZE, config );
      fputs( buffer, temp );
      fgets( buffer, LN_BUFFER_SIZE, config );
      fputs( buffer, temp );
      fgets( buffer, LN_BUFFER_SIZE, config );
      fputs( buffer, temp );
   }

   fgets( buffer, LN_BUFFER_SIZE, config );
   fgets( buffer, LN_BUFFER_SIZE, config );
   fgets( buffer, LN_BUFFER_SIZE, config );

   while( fgets( buffer, LN_BUFFER_SIZE, config ) != NULL )
      fputs( buffer, temp );

   fclose( temp );
   fclose( config );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config", home );
   snprintf( second_buffer, LN_BUFFER_SIZE, "%s/.peruser3-config_temp", home );
   rename( second_buffer, buffer );

   return;
}

/*
 * Normal callback of newsrc->tree. Removes servers and/or groups that have
 * been double-clicked.
 */

void newsrc_tree_normal_callback( EZ_Widget *widget, void *data )
{
   np_tree_object *tree;
   np_newsreader_object *newsreader;
   np_newsrc_object *newsrc;

   EZ_TreeNode *selected;
   EZ_Item *item;

   char buffer[ LN_BUFFER_SIZE ];
   unsigned int i, j;
   enum{ ROOT, SERVER, GROUP }what;


   tree = ( np_tree_object *)data;
   newsreader = ( np_newsreader_object *)tree->newsreader;
   newsrc = ( np_newsrc_object *)tree->parent;

   selected = EZ_GetListTreeWidgetSelection( tree->tree );

   if ( selected == tree->root_node )
   {
      what = ROOT;

      newsrc->confirm( newsrc, "Remove all servers and all groups?", 
                       NP_YESNO );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      if ( !newsrc->answer )
         return;

      newsrc->confirm( newsrc, "Are you really sure about this?", NP_YESNO );
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      if ( newsrc->answer )
      {
         for( j = 0; j < tree->servers; ++j )
            for( i = 0; i < tree->groups; ++i )
               if ( ln_remove_group( tree->server_list[ j ].server,
                     tree->group_list[ i ].group ))
                  lib_error();

         for( i = 0; i < tree->servers; ++i )
            if ( ln_remove_server( tree->server_list[ i ].server ))
               lib_error();

         newsrc->remove_server_config( newsrc, i );
      }
      else 
         return;
   }
   else
   {
      item = EZ_TreeNodeGetItem( selected );
      i = ( unsigned int)EZ_GetItemIntData( item );

      if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      {
         what = SERVER;

         snprintf( buffer, LN_BUFFER_SIZE,
                   "Remove news server:\n%s\nand all its groups?", 
                   tree->server_list[ i ].server );

         newsrc->confirm( newsrc, buffer, NP_YESNO );

         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();

         if ( !newsrc->answer )
            return;

         for( j = 0; j < tree->groups; ++j )
            if ( tree->group_list[ j ].server_idx == i )
               if ( ln_remove_group( tree->server_list[ i ].server,
                     tree->group_list[ j ].group ))
                  lib_error();

         if ( ln_remove_server( tree->server_list[ i ].server ))
            lib_error();

         newsrc->remove_server_config( newsrc, i );
      }
      else
      {
         what = GROUP;

         snprintf( buffer, LN_BUFFER_SIZE, "Remove:\n%s\nfrom %s?", 
                   tree->group_list[ i ].group,
                   tree->group_list[ i ].server );

         newsrc->confirm( newsrc, buffer, NP_YESNO );
         while( newsrc->answer == -1 )
            EZ_WaitAndServiceNextEvent();

         if ( newsrc->answer )
         {
            j = tree->group_list[ i ].server_idx;
            if ( ln_remove_group( tree->group_list[ i ].server,
                  tree->group_list[ i ].group ))
               lib_error();
         }
         else
            return;
      }
   }

   tree->update_lists( tree );
   tree->set_tree( tree );

   switch( what )
   {
      case ROOT:
      case SERVER:
         EZ_ListTreeWidgetSelectNode( tree->tree, tree->root_node,
                                      newsrc->pos );
         EZ_FancyListBoxClear( newsrc->list );
         break;

      case GROUP:
         if ( tree->server_list[ newsrc->server ].groups )
         {
            if ( i > 0 )
               if ( !strcmp( tree->group_list[ --i ].server, 
                     tree->server_list[ newsrc->server ].server ))
               {
                  EZ_ListTreeWidgetSelectNode( tree->tree, 
                                               tree->group_nodes[ i ],
                                               newsrc->pos );
                  return;
               }
         }

         EZ_ListTreeWidgetSelectNode( tree->tree, tree->server_nodes[ j ],
                                      newsrc->pos );
         break;
   }

   return;
}

/*
 * Generic confirmation/information dialog. Used throughout Peruser.
 */

void newsrc_confirm( void *this, char *message, np_button_type show_buttons )
{
   np_newsrc_object *newsrc;
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;

   EZ_Widget *button_frame;


   newsrc = ( np_newsrc_object *)this;
   buttons = ( np_buttons_object *)newsrc->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;

   newsrc->confirm_frame = EZ_CreateFrame( NULL, NULL );

   EZ_ConfigureWidget( newsrc->confirm_frame,
                       EZ_WIDTH, 400,
                       EZ_HEIGHT, 200,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   newsrc->confirm_label = EZ_CreateLabel( newsrc->confirm_frame, NULL );
   
   EZ_ConfigureWidget( newsrc->confirm_label,
                       EZ_LABEL_PIXMAP,
                       (( show_buttons == NP_YESNO ) ?
                        newsrc->query_pixmap : newsrc->confirm_pixmap ),      
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( newsrc->confirm_frame, message ),
                       EZ_TEXT_LINE_LENGTH, 50,
                       EZ_LABEL_POSITION, EZ_CENTER,
                       EZ_FONT_NAME, newsreader->bold_font,
                       0 );

   button_frame = EZ_CreateFrame( newsrc->confirm_frame, NULL );

   EZ_ConfigureWidget( button_frame,
                       EZ_HEIGHT, 40,
                       EZ_IPADX, 25,
                       0 );

   switch( show_buttons )
   {
      case NP_YESNO:
         newsrc->yes_button = EZ_CreateButton( button_frame, "yes", 0 );

         EZ_ConfigureWidget( newsrc->yes_button,
                             EZ_CALLBACK, newsrc->confirm_callback, newsrc,
                             EZ_FONT_NAME, newsreader->bold_font,
                             EZ_FOREGROUND, "ForestGreen",
                             EZ_HEIGHT, 35,
                             0 );

         EZ_ConfigureWidget( EZ_CreateButton( button_frame, "no", 0 ),
                             EZ_CALLBACK, newsrc->confirm_callback, newsrc,
                             EZ_FONT_NAME, newsreader->bold_font,
                             EZ_FOREGROUND, "DarkRed",
                             EZ_HEIGHT, 35,
                             0 );

         newsrc->answer = -1;
         break;

      case NP_DONE:
         newsrc->yes_button = EZ_CreateButton( button_frame, "done", 0 );

         EZ_ConfigureWidget( newsrc->yes_button,
                             EZ_HEIGHT, 35,
                             EZ_FONT_NAME, newsreader->bold_font,
                             EZ_CALLBACK, newsrc->confirm_callback, newsrc,
                             0 );
         break;

      case NP_KILL:
         newsrc->yes_button = EZ_CreateButton( button_frame, "stop", 0 );

         EZ_ConfigureWidget( newsrc->yes_button,
                             EZ_FOREGROUND, "DarkRed",
                             EZ_HEIGHT, 35,
                             EZ_FONT_NAME, newsreader->bold_font,
                             EZ_CALLBACK, newsrc->kill_callback, newsrc,
                             0 );
      case NP_NONE:
         break;
   }

   EZ_DisplayWidget( newsrc->confirm_frame );
   EZ_SetGrab( newsrc->confirm_frame );

   return;
}

/*
 * Callback of the yes or the done button on newsrc->confirm_frame, depending
 * upon which button was created in newsrc->confirm.
 */

void newsrc_confirm_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;

   newsrc = ( np_newsrc_object *)data;
   newsreader = ( np_newsreader_object *)
       (( np_buttons_object *)newsrc->parent )->parent;

   if ( widget == newsrc->yes_button )
      newsrc->answer = 1;
   else
      newsrc->answer = 0;

   EZ_DestroyWidget( newsrc->confirm_frame );

   return;
}

/*
 * Callback of new group input widget.
 */

void newsrc_new_group_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;
   np_tree_object *tree;

   char buffer[ LN_BUFFER_SIZE ];
   unsigned int i, k;
   char j;

   EZ_TreeNode *selected;
   EZ_Item *item;


   newsrc = ( np_newsrc_object *)data;
   tree = ( np_tree_object *)newsrc->tree_object;

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL ||
         selected == tree->root_node )
   {
      newsrc->confirm( newsrc, "Select a news server in the tree, first.",
                       NP_DONE );
      return;
   }

   item = EZ_TreeNodeGetItem( selected );
   i = ( unsigned int)EZ_GetItemIntData( item );

   if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      j = 1;
   else
      j = 0;

   strcpy( buffer, EZ_GetEntryString( newsrc->group_entry ));

   if ( !strlen( buffer ))
      return;

   for( k = 0; k < tree->groups; ++k )
      if ( !strcmp( buffer, tree->group_list[ k ].group ))
      {
         snprintf( buffer, LN_BUFFER_SIZE, "Duplicate group:\n%s", 
                   tree->group_list[ k ].group );
         newsrc->confirm( newsrc, buffer, NP_DONE );
         return;
      }

   if ( !strncmp( buffer, "Follow-ups", 10 ) )
      return;

   if ( j )
   {
      if ( ln_add_group( tree->server_list[ newsrc->server ].server, 
            strtok( buffer, "\r\n" ) ))
         lib_error();
   }
   else
      if ( ln_add_group_behind( tree->group_list[ i ].group, 
            strtok( buffer, "\r\n" ) ) )
         lib_error();

   tree->update_lists( tree );
   tree->set_tree( tree );

   if ( j )
      for( k = 0; k < tree->groups; ++k )
      {
         if ( tree->group_list[ k ].server_idx != i )
            continue;

         EZ_ListTreeWidgetSelectNode( tree->tree, 
                                      tree->group_nodes[ k ], newsrc->pos );
         break;
      }
   else
      EZ_ListTreeWidgetSelectNode( tree->tree,
                                   tree->group_nodes[ i + 1 ], newsrc->pos );


   return;
}

/*
 * callback of new server input.
 */

void newsrc_new_server_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;
   np_tree_object *tree;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ];
   static char second_buffer[ LN_BUFFER_SIZE ] = "\0";
   FILE *config;
   unsigned int i;


   newsrc = ( np_newsrc_object *)data;
   tree = ( np_tree_object *)newsrc->tree_object;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)newsrc->parent )->parent;

   strcpy( buffer, EZ_GetEntryString( newsrc->server_entry ));

   if ( !strcmp( buffer, second_buffer ))
       for( i = 0; i < tree->servers; ++i )
           if ( !strcmp( tree->server_list[ i ].server, buffer ))
               return;
       
   strcpy( second_buffer, buffer );

   if ( !strncmp( buffer, "Virtual", 7 ) ||
        !strncmp( buffer, "Folders", 7 ) ||
        !strncmp( buffer, "Mailboxes", 9 ))
      return;

   if ( ln_add_server( strtok( buffer, "\r\n" ) ))
      lib_error();

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config", getenv( "HOME" ));
   if (( config = fopen( buffer, "r+" )) == NULL )
       if ( errno == ENOENT )
       {
           if (( config = fopen( buffer, "a" )) == NULL )
               fatal_error();
           fputs( "nobody@nowhere\n\n1\n", config );
       }
   fseek( config, 0, SEEK_END );

   newsrc->answer = -1;
   newsrc->confirm( newsrc,
                    "Does this server require\na login name and password?",
                    NP_YESNO );
   while( newsrc->answer == -1 )
      EZ_WaitAndServiceNextEvent();

   if ( newsrc->answer )
   {
      EZ_Widget *frame, *login, *passwd;

      frame = EZ_CreateFrame( NULL, "Authinfo" );

      EZ_ConfigureWidget( frame,
                          EZ_HEIGHT, 300,
                          EZ_WIDTH, 300,
                          EZ_ORIENTATION, EZ_VERTICAL,
                          EZ_FILL_MODE, EZ_FILL_BOTH,
                          0 );

      EZ_ConfigureWidget( EZ_CreateLabel( frame, "Login Name" ),
                          EZ_FONT_NAME, newsreader->medium_font,
                          EZ_HEIGHT, 30,
                          0 );
      
      login = EZ_CreateEntry( frame, NULL );

      EZ_ConfigureWidget( login,
                          EZ_HEIGHT, 30,
                          0 );
      
      EZ_ConfigureWidget( EZ_CreateLabel( frame, "Password" ),
                          EZ_FONT_NAME, newsreader->medium_font,
                          EZ_HEIGHT, 30,
                          0 );
      
      passwd = EZ_CreateEntry( frame, NULL );

      EZ_ConfigureWidget( passwd,
                          EZ_HEIGHT, 30,
                          0 );

      EZ_ConfigureWidget( EZ_CreateButton( frame, "done", 0 ),
                          EZ_FOREGROUND, "ForestGreen",
                          EZ_CALLBACK, newsrc->authinfo_callback, newsrc,
                          EZ_HEIGHT, 30,
                          EZ_WIDTH, 75,
                          0 );

      EZ_DisplayWidget( frame );
      EZ_SetGrab( frame );

   AGAIN:
      newsrc->answer = -1;
      while( newsrc->answer == -1 )
         EZ_WaitAndServiceNextEvent();

      strcpy( buffer, EZ_GetEntryString( login ));
      if ( strtok( buffer, "\r\n" ) == NULL )
         goto AGAIN;

      fprintf( config, "1\n%s\n", buffer );
      
      strcpy( buffer, EZ_GetEntryString( passwd ));
      if ( strtok( buffer, "\r\n" ) == NULL )
         goto AGAIN;

      fprintf( config, "%s\n", buffer );

      EZ_DestroyWidget( frame );
      EZ_SetGrab( newsrc->newsrc_frame );
   }
   else
      fputs( "0\n\n\n", config );
   
   fclose( config );

   tree->update_lists( tree );
   tree->set_tree( tree );

   EZ_ListTreeWidgetSelectNode( tree->tree, 
                                tree->server_nodes[ tree->servers - 1 ],
                                newsrc->pos );

   return;
}

void newsrc_authinfo_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;


   newsrc = ( np_newsrc_object *)data;
   newsrc->answer = 0;
   
   return;
}

void newsrc_animate( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;

   EZ_LabelPixmap *pixmap;

   static int i = 0;


   newsrc = ( np_newsrc_object *)data;
   
   switch( i )
     {
        case 0:
           pixmap = newsrc->animate_pixmap_0;
           break;

        case 1:
           pixmap = newsrc->animate_pixmap_1;
           break;

        case 2:
           pixmap = newsrc->animate_pixmap_2;
           break;

        case 3:
           pixmap = newsrc->animate_pixmap_3;
           break;

        case 4:
           pixmap = newsrc->animate_pixmap_4;
           break;

        case 5:
           pixmap = newsrc->animate_pixmap_5;
           break;

        case 6:
           pixmap = newsrc->animate_pixmap_6;
           break;

        case 7:
           pixmap = newsrc->confirm_pixmap;
           break;
     }

   if ( ++i > 7 )
      i = 0;

   EZ_ConfigureWidget( newsrc->confirm_label,
                       EZ_LABEL_PIXMAP, pixmap,
                       0 );

   return;
}

/*
 * Callback of newsrc->list_button. Forks nplister to retrieve or update
 * list of active groups for currently-selected news server.
 */

void newsrc_list_button_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;
   np_tree_object *tree;

   char *toget, buffer[ LN_BUFFER_SIZE ], auth_index[ 25 ];
   unsigned int i, j;
   int status, result;
   enum{ SERVER, GROUP }what;

   EZ_TreeNode *selected;
   EZ_Item *item;
   EZ_Timer *timer;


   newsrc = ( np_newsrc_object *)data;
   tree = ( np_tree_object *)newsrc->tree_object;

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL ||
         selected == tree->root_node )
   {
      newsrc->confirm( newsrc, "Select a news server in the tree, first.",
                       NP_DONE );
      return;
   }

   item = EZ_TreeNodeGetItem( selected );
   i = ( unsigned int)EZ_GetItemIntData( item );

   if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
      what = SERVER;
   else
   {
      what = GROUP;
      j = i;
      i = tree->group_list[ i ].server_idx;
   }

   EZ_WaitCursor( newsrc->newsrc_frame, EZ_GetCursor( XC_watch ));

   if ( widget == newsrc->list_button )
      snprintf( buffer, LN_BUFFER_SIZE,
                "Retrieving list of active groups from:"
                "\n%s\nThis may take a long time...",
                tree->server_list[ i ].server );
   else
      snprintf( buffer, LN_BUFFER_SIZE,
                "Updating list of active groups from:\n%s...", 
                tree->server_list[ i ].server );

   newsrc->confirm( newsrc, buffer, NP_KILL );

   switch( newsrc->pid = fork() )
   {
      case 0:
         close( ConnectionNumber( EZ_GetDisplay() ));

         if ( widget == newsrc->list_button )
            toget = "list";
         else
            toget = "update";

         snprintf( buffer, LN_BUFFER_SIZE, "%s/nplister", LIBEXEC_PATH );
         snprintf( auth_index, LN_BUFFER_SIZE, "%d", i );
         
         execl( buffer, buffer, tree->server_list[ i ].server, auth_index,
                toget, NULL );

         exit( 16 );
         break;

      case -1:
         fatal_error();
         break;

      default:
         timer = EZ_CreateTimer( 0, 125000, -1, newsrc->animate, newsrc, 0 );

         while( !( result = waitpid( newsrc->pid, &status, WNOHANG )) )
            EZ_ServiceEvents();

         EZ_CancelTimer( timer );

         newsrc->confirm_callback( newsrc->yes_button, newsrc );

         if ( result == -1 )
            perror( "peruser" );

         if ( WIFEXITED( status ))
            result = WEXITSTATUS( status );
         else
            result = 0;

         switch( result )
         {
         case 0:
             selected = (( what == SERVER ) ? tree->server_nodes[ i ] :
                         tree->group_nodes[ j ] );

             newsrc->server = -1;
             EZ_ListTreeWidgetSelectNode( tree->tree, NULL, NULL );
             EZ_ListTreeWidgetSelectNode( tree->tree, selected, 
                                          newsrc->pos );
             break;

         case 1:
             strcpy( buffer, "command-line arguments incorrect." );
             break;

         case 2:
             snprintf( buffer, LN_BUFFER_SIZE, "Could not connect to:\n%s.",
                       tree->server_list[ i ].server );
             break;

         case 3:
             snprintf( buffer, LN_BUFFER_SIZE, "%s \nresponded with a "
                       "non-welcoming message.",
                       tree->server_list[ i ].server );
             break;

         case 4:
             strcpy( buffer, "ln_get_list() failed." );
             break;

         case 5:
             strcpy( buffer, "No new groups on server." );
             break;

         case 6:
             snprintf( buffer, LN_BUFFER_SIZE, "No TIMESTAMP on file for:\n"
                       "%s.\nRetrieve a fresh list to create one.", 
                       tree->server_list[ i ].server );
             break;

         case 7:
             strcpy( buffer, "ln_get_newgroups() failed." );
             break;

         case 8:
             strcpy( buffer, "bad server index." );
             break;

         case 9:
             strcpy( buffer, "~/.peruser3-config not found." );
             break;
             
         case 10:
             strcpy( buffer, "ln_fgets() timed-out." );
             break;
             
         case 11:
             strcpy( buffer, "server did not recognize user name." );
             break;
             
         case 12:
             strcpy( buffer, "server did not recognize password." );
             break;
             
         case 13:
             strcpy( buffer, "ln_fgets() failed." );
             break;
             
         case 14:
             strcpy( buffer, "premature end of ~/.peruser3-config." );
             break;
             
         case 15:
             strcpy( buffer, "You have not configured this server." );
             break;
             
         case 16:
             snprintf( buffer, LN_BUFFER_SIZE, 
                       "execl() failed. Is nplister in:\n%s?", LIBEXEC_PATH );
             break;

         default:
             strcpy( buffer, "unknown error." );
             break;
         }

         if ( result )
         {
            newsrc->answer = -1;
            newsrc->confirm( newsrc, buffer, NP_DONE );
            while( newsrc->answer == -1 )
               EZ_WaitAndServiceNextEvent();
         }

         break;
   }

   EZ_NormalCursor( newsrc->newsrc_frame );
   EZ_SetGrab( newsrc->newsrc_frame );

   return;
}

/*
 * Callback of stop button on newsrc->newsrc_frame. Kills nplister.
 */

void newsrc_kill_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;


   newsrc = ( np_newsrc_object *)data;

   newsrc->confirm_callback( newsrc->yes_button, newsrc );

   if ( kill( newsrc->pid, SIGKILL ))
      perror( "peruser" );

   return;
}

/*
 * Callback of newsrc->tree. Changes currently-selected server to that which
 * has just been clicked.
 */

void newsrc_tree_motion_callback( EZ_Widget *widget, void *data )
{
   np_tree_object *tree;
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;

   unsigned int i, server;
   FILE *list;
   char buffer[ LN_BUFFER_SIZE ];
   enum{ no, yes } found;

   EZ_TreeNode *selected;
   EZ_Item *item, **items;


   tree = ( np_tree_object *)data;
   newsrc = ( np_newsrc_object *)tree->parent;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)newsrc->parent )->parent;

   selected = EZ_GetListTreeWidgetSelection( tree->tree );

   if ( selected == tree->root_node )
      return;

   found = no;

   item = EZ_TreeNodeGetItem( selected );
   i = ( unsigned int)EZ_GetItemIntData( item );

   if( *( char *)EZ_GetItemPtrData( item ) == 's' )
   {
      if ( i == newsrc->server )
         return;
      else
         server = i;
   }
   else
      if ( tree->group_list[ i ].server_idx == newsrc->server )
         return;
      else
         server = tree->group_list[ i ].server_idx;

   EZ_FreezeWidget( tree->tree );
   EZ_TreeSetFGColorName( tree->root_node, tree->empty_colour );
   EZ_TreeSetFGColorName( tree->server_nodes[ server ], tree->unread_colour );
   EZ_UnFreezeWidget( tree->tree );

   /* drag and drop */

   for( i = 0; i < tree->servers; ++i )
   {
      item = EZ_TreeNodeGetItem( tree->server_nodes[ i ] );

      if ( i == server )
      {
         EZ_ItemAddDnDDataDecoder( item, NP_DND_GROUP_ADD_ATOM, 0,
                                   tree->dnd_add_decoder, tree,
                                   NULL, NULL );
      }
      else
         EZ_ItemDeleteAllDnDDataDecoders( item );
   }

   for( i = 0; i < tree->groups; ++i )
   {
      item = EZ_TreeNodeGetItem( tree->group_nodes[ i ] );

      if ( tree->group_list[ i ].server_idx == server )
      {
         EZ_ItemAddDnDDataEncoder( item, NP_DND_GROUP_REORDER_ATOM, 0,
                                   tree->dnd_encoder, tree,
                                   NULL, NULL );

         EZ_ItemAddDnDDataDecoder( item, NP_DND_GROUP_REORDER_ATOM, 0,
                                   tree->dnd_reorder_decoder, tree,
                                   NULL, NULL );

         EZ_ItemAddDnDDataDecoder( item, NP_DND_GROUP_ADD_ATOM, 0,
                                   tree->dnd_add_decoder, tree,
                                   NULL, NULL );
      }
      else
      {
         EZ_ItemDeleteAllDnDDataEncoders( item );
         EZ_ItemDeleteAllDnDDataDecoders( item );
      }
   }

   if ( newsrc->server <= 0 )
   {
      EZ_WaitCursor( newsrc->newsrc_frame, EZ_GetCursor( XC_watch ));
      XFlush( EZ_GetDisplay() );

      if ( newsrc->groups )
      {
         snprintf( buffer, LN_BUFFER_SIZE, "Destroying %d display items...",
                   newsrc->groups );
         EZ_ConfigureWidget( newsrc->searchlist_label, 
                             EZ_LABEL_STRING, buffer,
                             0 );
      }

      EZ_FancyListBoxClear( newsrc->list );

      EZ_ConfigureWidget( newsrc->searchlist_label,
                          EZ_LABEL_STRING, " ",
                          0 );

      EZ_NormalCursor( newsrc->newsrc_frame );
      XFlush( EZ_GetDisplay() );
   }

   newsrc->server = server;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-LIST", 
             getenv( "HOME" ), tree->server_list[ server ].server );
   if (( list = fopen( buffer, "r" )) == NULL )
      if ( errno != ENOENT )
         fatal_error();
      else
      {
         if ( newsrc->groups )
         {
            snprintf( buffer, LN_BUFFER_SIZE, "Destroying %d display items...",
                      newsrc->groups );
            EZ_ConfigureWidget( newsrc->searchlist_label, 
                                EZ_LABEL_STRING, buffer,
                                0 );
         }

         EZ_FancyListBoxClear( newsrc->list );
         snprintf( buffer, LN_BUFFER_SIZE,"(No list on-file for %s)", 
                   tree->server_list[ server ].server );
         EZ_ConfigureItem( item = EZ_CreateLabelItem( buffer, NULL ),
                           EZ_TEXT_LINE_LENGTH, 120,
                           0 );

         EZ_ConfigureWidget( newsrc->searchlist_label,
                             EZ_LABEL_STRING, " ",
                             0 );

         EZ_FancyListBoxInsertRow( newsrc->list, &item, 1, 1 );
         EZ_FancyListBoxSelectItem( newsrc->list, item, NULL );
         EZ_FancyListBoxSelectItemUsingIdx( newsrc->list, -1, 0, NULL );

         newsrc->groups = 0;
         return;
      }

   snprintf( buffer, LN_BUFFER_SIZE, "Loading list for: %s...", 
             tree->server_list[ server ].server );

   EZ_ConfigureWidget( newsrc->searchlist_label,
                       EZ_LABEL_STRING, buffer,
                       0 );

   EZ_WaitCursor( newsrc->newsrc_frame, EZ_GetCursor( XC_watch ));

   XFlush( EZ_GetDisplay() );
   EZ_FreezeWidget( newsrc->list );

   newsrc->groups = 0;
   EZ_FancyListBoxClear( newsrc->list );

   while( fgets( buffer, LN_BUFFER_SIZE, list ) != NULL )
   {
      if ( !strncmp( buffer, "junk", 4 ) || !strncmp( buffer, "control", 7 ) ||
           !strncmp( buffer, "Suggest", 7 ))
         continue;

      newsrc->groups++;
   }
   
   if (( items = calloc( newsrc->groups, sizeof *items )) == NULL )
      fatal_error();
   
   rewind( list );
   i = 0;
   
   while( fgets( buffer, LN_BUFFER_SIZE, list ) != NULL )
   {
      if ( !strncmp( buffer, "junk", 4 ) || !strncmp( buffer, "control", 7 ) ||
           !strncmp( buffer, "Suggest", 7 ))
         continue;

      EZ_ConfigureItem( items[ i ] = EZ_CreateLabelItem( buffer, NULL ),
                        EZ_CLIENT_INT_DATA, i,
                        EZ_CLIENT_PTR_DATA, NULL, 
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );

      EZ_ItemAddDnDDataEncoder( items[ i++ ], NP_DND_GROUP_ADD_ATOM, 0,
                                tree->dnd_encoder, tree,
                                NULL, NULL );
   }
   fclose( list );

   EZ_SetFancyListBoxData( newsrc->list, items, i, 1 );
      
   snprintf( buffer, LN_BUFFER_SIZE, "%d groups in list", newsrc->groups );
   EZ_ConfigureWidget( newsrc->searchlist_label,
                       EZ_LABEL_STRING, buffer,
                       0 );

   EZ_NormalCursor( newsrc->newsrc_frame );
   XFlush( EZ_GetDisplay() );


   EZ_UnFreezeWidget( newsrc->list );

   return;
}

/*
 * Normal callback of newsrc->list. Adds newsgroup just double-clicked to tree.
 */

void newsrc_list_normal_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;
   np_tree_object *tree;

   char buffer[ LN_BUFFER_SIZE ], *string;
   unsigned int i;

   EZ_Item **item;


   newsrc = ( np_newsrc_object *)data;
   tree = ( np_tree_object *)newsrc->tree_object;

   item = EZ_GetFancyListBoxSelection( newsrc->list );
   EZ_GetLabelItemStringInfo( *item, &string, NULL );
   strcpy( buffer, string );

   if ( ln_add_group( tree->server_list[ newsrc->server ].server, 
         strtok( buffer, "\n" )))
      lib_error();

   tree->update_lists( tree );
   tree->set_tree( tree );

   for( i = 0; i < tree->groups; ++i )
      if ( tree->group_list[ i ].server_idx == newsrc->server )
      {
         EZ_ListTreeWidgetSelectNode( tree->tree, tree->group_nodes[ i ], 
               newsrc->pos );
         break;
      }

   return;
}

/*
 * Callback of newsrc->searchlist_entry. Does regular expression searches on
 * the list of active newsgroups for the currently-selected news server.
 */

void newsrc_search_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;

   static regex_t regex;
   static int last_match = 0;
   static char buffer[ LN_BUFFER_SIZE ] = "\0";
   static enum{ no, yes }last_fail = no, first_time = yes;

   int result;
   unsigned int i;
   char *string, second_buffer[ LN_BUFFER_SIZE ];

   EZ_Item **item;


   newsrc = ( np_newsrc_object *)data;

   if ( widget == NULL )
   {
      regfree( &regex );
      return;
   }

   if ( !newsrc->groups )
      return;

   if ( strcmp( buffer, EZ_GetEntryString( newsrc->searchlist_entry )))
   {
      strcpy( buffer, EZ_GetEntryString( newsrc->searchlist_entry ));
      last_match = 0;
   }

   if ( !strlen( buffer ))
      return;

   if ( last_match == 0 )
   {
      if ( !first_time )
      {
         regfree( &regex );
         first_time = no;
      }

      if ( ( result = regcomp( &regex, buffer, REG_EXTENDED | REG_NOSUB )))
      {
         regerror( result, &regex, buffer, LN_BUFFER_SIZE );
         newsrc->confirm( newsrc, buffer, NP_DONE );
         return;
      }
   }

   EZ_WaitCursor( newsrc->newsrc_frame, EZ_GetCursor( XC_watch ));

   XFlush( EZ_GetDisplay() );

   if ( last_fail )
      last_match = 0;

   EZ_FreezeWidget( newsrc->list );

   for( i = last_match + 1; i <= newsrc->groups; ++i )
   {
      EZ_FancyListBoxSelectItemUsingIdx( newsrc->list, i, 0, NULL );
      item = EZ_GetFancyListBoxSelection( newsrc->list );
      EZ_GetLabelItemStringInfo( *item, &string, NULL );
      strcpy( second_buffer, string );
      strtok( second_buffer, "\n" );

      if ( ( result = regexec( &regex, second_buffer, 0, NULL, 0 )) )
         if ( result == REG_NOMATCH )
            continue;
         else
         {
            regerror( result, &regex, buffer, LN_BUFFER_SIZE );
            newsrc->confirm( newsrc, buffer, NP_DONE );

            EZ_FancyListBoxSelectItemUsingIdx( newsrc->list, -1, 0, NULL );

            EZ_UnFreezeWidget( newsrc->list );
            return;
         }

      last_match = i;
      break;
   }

   EZ_UnFreezeWidget( newsrc->list );

   EZ_NormalCursor( newsrc->newsrc_frame );
   XFlush( EZ_GetDisplay() );

   if ( i > newsrc->groups )
   {
      last_fail = yes;
      EZ_FancyListBoxSelectItemUsingIdx( newsrc->list, 1, 0, NULL );
      EZ_FancyListBoxSelectItemUsingIdx( newsrc->list, -1, 0, NULL );
   }
   else
   {
      last_fail = no;
      EZ_FancyListBoxSelectItemUsingIdx( newsrc->list, -1, 0, NULL );
      EZ_FancyListBoxSelectItemUsingIdx( newsrc->list, i, 0, NULL );
   }

   return;
}
