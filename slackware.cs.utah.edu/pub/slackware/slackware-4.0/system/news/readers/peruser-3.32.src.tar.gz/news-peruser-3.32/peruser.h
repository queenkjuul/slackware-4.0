/*   News Peruser Copyright (c) 1996, 1997 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#define _GNU_SOURCE
#include<errno.h>
#include "EZ.h"
#include "uudeview.h"
#include "libnews.h"

Atom NP_DND_GROUP_REORDER_ATOM, NP_DND_GROUP_ADD_ATOM,
   NP_DND_FOLDERS_ATOM, NP_DND_ADDRESS_ATOM;

typedef enum{ NP_EMPTY, NP_READ, NP_UNREAD }np_group_state;
typedef enum{ NP_NOT_SHOWN, NP_SHOWN }np_server_state;
typedef enum{ NP_INACTIVE, NP_ACTIVE }np_node_state;
typedef enum{ NP_SUBJECT, NP_POSTER, NP_DATE }np_order;
typedef enum{ NP_PUSH, NP_POP, NP_CLEAN } np_stack_op;
typedef enum{ NP_YESNO, NP_DONE, NP_KILL, NP_NONE } np_button_type;
typedef enum{ NP_EXPIRE, NP_PACK, NP_UPDATE }np_action;

typedef struct {

   unsigned int groups, servers;
   ln_group_list *group_list;
   ln_server_list *server_list;

   EZ_TreeNode *root_node, **server_nodes, **group_nodes;

   np_server_state shown;

   np_node_state *group_state;
   np_server_state *server_state;

   EZ_TextProperty *server_prop, *read_prop, *unread_prop, *none_prop,
      *follow_up_read_prop, *follow_up_none_prop;

   EZ_TextProperty *back_prop, *highlight_prop, *server_back_prop,
      *server_highlight_prop;

   EZ_Widget *tree;

   EZ_LabelPixmap *news_icon, *virtual_icon, *folder_icon, *inbox_icon;

   int dnd, add;

   void *parent;
   void *newsreader;

   char s;
   char g;
   
   char *empty_colour, *read_colour, *unread_colour;

   void( *init )( void *this, void *parent, EZ_Widget *frame,
         void *newsreader );
   void( *set_tree )( void *this );
   void( *normal_callback )( EZ_Widget *list_tree, void *this );
   void( *motion_callback )( EZ_Widget *list_tree, void *this );
   void( *collapse_server )( void *this, unsigned int server );
   void( *update_node )( void *this, EZ_Widget *list, np_group_state state );
   void( *destroy )( void *parent );
   void( *destroy_lists )( unsigned int groups, ln_group_list *list,
                           unsigned int servers, ln_server_list *server_list );
   void( *update_lists )( void *tree_object );
   int( *dnd_encoder )( EZ_Item *item, void *data, char **message,
                        int *length, int *needfree );
   int( *dnd_reorder_decoder )( EZ_Item *item, void *data, char *message, 
                                int length );
   int( *dnd_add_decoder )( EZ_Item *item, void *data, char *message, 
                            int length );
   int( *dnd_folders_decoder )( EZ_Item *item, void *data, char *message,
                                int length );

} np_tree_object;

typedef struct {
   EZ_TreeNode *node;
   unsigned int threading;
} np_toplevel;

typedef struct {

   void *parent;

   EZ_Widget *thread_tree, *summary_list, *summary_frame, *subject_button,
   *group_label, *message_label;

   EZ_TreeNode *root, **node_list;
   np_node_state *node_state;


   char **local_times;
   char summary_onscreen;
   unsigned int *positions;

   char *group_name, *header_colour, *requested_colour, *article_colour;

   ln_group_stats stats;
   unsigned int old_total, group;
   ln_group_summary *contents;

   void ( *init )( void *this, void *parent );
   void ( *update_summary )( void *this );
   void ( *create_local_times )( void *this );
   void ( *show_stats )( void *this );

   void ( *set_tree )( void *this, EZ_Widget *tree, 
                       char *group_name, unsigned int total, 
                       unsigned int group );
   void ( *clear_tree )( void *this );
   void ( *tree_motion_callback )( EZ_Widget *tree, void *data );
   void ( *tree_normal_callback )( EZ_Widget *tree, void *data );
   void ( *update_tree )( void *this, EZ_Widget *tree );
   unsigned int( *dive_for_the_count )( void *this, unsigned int i );
   unsigned int( *dive_and_alter_threading )( void *this, unsigned int i, 
                                              char top );
   unsigned int( *dive_and_change_state )( void *this, unsigned int i,
                                           np_node_state state );
   unsigned int ( *dive_for_the_unseen )( void *this, unsigned int i, 
                                          unsigned int *unread );
   void ( *hide_headers )( void *this );

   void ( *contents_destroy )( ln_group_summary *contents, unsigned int total );
   void ( *recursively_descend_thread )( void *this,
                                         unsigned int depth,
                                         np_toplevel *toplevel,
                                         EZ_Item *item,
                                         EZ_TreeNode **tree_node );
   void ( *toplevel_stack )( np_toplevel *toplevel, np_stack_op what );
   EZ_Item *( *create_missing_item ) ();

   void ( *destroy )( void *this );
   void( *callback )( EZ_Widget *widget, void *data );
   void( *done_callback )( EZ_Widget *widget, void *data );

   void( *subject_callback )( EZ_Widget *widget, void *data );
   void( *poster_callback )( EZ_Widget *widget, void *data );
   void( *date_callback )( EZ_Widget *widget, void *data );
   void( *list_callback )( EZ_Widget *widget, void *data );
   void( *reorder )( np_order order, void *data );
   int( *dnd_encoder )( EZ_Item *item, void *data, char **message, int *length,
                        int *needfree );

} np_summary_object;

typedef struct {

   char *name;
   void *prev;
   void *next;

} np_pix_list;

typedef struct {

   EZ_Widget *header_text;
   EZ_Widget *body_text;

   ln_message message;

   void *parent;

   np_pix_list *pix_list, *pix_end;

   void ( *init )( void *this, void *parent );
   void ( *set_message )( void *this, char *group_name, ln_type type,
                          long int offset, long int size );
   void ( *decode )( void *this );
   int ( *uu_busy_callback )( void *this, uuprogress *progress );
   void ( *picture_frame_button_destroy_callback )( EZ_Widget *widget, 
                                                   void *data );
   void ( *picture_frame_callback )( EZ_Widget *widget, void *data );
   void ( *clear_message )( void *this );
   void ( *destroy_pix_list )( np_pix_list *pix );
   void ( *destroy )( void *this );

} np_message_object;

typedef struct {

   void *parent;

   EZ_Widget *frame, *headers_button, *cancel_button, *quantity_slider,
      *slider_frame;

   ln_what what;
   int xover, quantity, interrupt, connect;
   unsigned int requests, server_idx;
   FILE *stream;
   char *group, *server;

   void( *init )( void *parent );
   void( *callback )( EZ_Widget *widget, void *data );
   void( *show_message )( void *newsreader_object, np_action action,
                          char *server );
   void( *do_group )( void *this, void *summary_object, void *tree_object,
                      np_action action,
                      unsigned int i, char *elapsed_time,
                      char *server, char *group );
   void( *expire_group )( np_tree_object *tree, np_summary_object *summary,
                          unsigned int i, char folder, char *elapsed_time );

   void( *ask_what )( void *this, char *server );
   void( *ask_for_folder )( void *this );
   void( *radio_callback )( EZ_Widget *widget, void *data );
   void( *update_newsgroup )( void *this );
   void( *update_folder )( void *this );
   void( *update_inbox )( char *inbox, void *newsrc_object );
   void( *retrieve_folder_requests )( void *this, unsigned int i );
   void( *iterate )( void *this, void *summary_object, void *tree_object,
                     np_action action, int i, unsigned int j,
                     char *elapsed_time );
   int( *do_virtual )( void *this );
   void( *send_mail )( void *this, unsigned int i );
   void( *virtual_frame_callback )( EZ_Widget *widget, void *data );

   int( *authenticating )( void *this, unsigned int j, char *user, 
                           char *pass );
   int( *open_server )( void *this, char *server, unsigned int j );
   void( *grey_slider )( EZ_Widget *widget, void *data );
   void( *ungrey_slider )( EZ_Widget *widget, void *data );

   int( *progress_callback )( void *data, char *group, unsigned int lines,
                              unsigned int begin,
                              unsigned int current,
                              unsigned int end );
   int( *filter_progress_callback )( void *data, unsigned int i, char *filter,
                                     char *group );
   void( *interrupt_callback )( EZ_Widget *widget, void *data );
   int( *connect_callback )( void *data, int expired );
   void( *disable_interface )( void *newsreader_object, char i );

} np_update_object;

typedef struct {

   void *parent;

   EZ_Widget *frame, *list, *folder_entry, *filter_entry;

   int dnd, persistent;

   void( *init )( void *parent );
   void( *callback )( EZ_Widget *widget, void *data );
   int( *verify )( void *this, char *string );
   void( *persistent_callback )( EZ_Widget *widget, void *data );
   void( *persistent_add_callback )( EZ_Widget *widget, void *data );
   void( *persistent_replace_callback )( EZ_Widget *widget, void *data );
   void( *persistent_remove_callback )( EZ_Widget *widget, void *data );
   void( *persistent_motion_callback )( EZ_Widget *widget, void *data );
   void( *persistent_sort_callback )( EZ_Widget *widget, void *data );
   void( *update_persistent )( void *this );
   void( *add_callback )( EZ_Widget *widget, void *data );
   void( *remove_callback )( EZ_Widget *widget, void *data );
   void( *replace_callback )( EZ_Widget *widget, void *data );
   int( *dnd_reorder_encoder )( EZ_Item *item, void *data, char **message,
                                int *length, int *needfree );
   int( *dnd_reorder_decoder )( EZ_Item *item, void *data, char *message,
                                int length );
   void( *done_callback )( EZ_Widget *widget, void *data );
   void( *update_list )( void *this );
   void( *list_motion_callback )( EZ_Widget *widget, void *data );
   void( *sort_callback )( EZ_Widget *widget, void *data );

} np_folders_object;

typedef struct 
{
   char *group;
   void *next;
} np_newsgroup_list;

typedef struct {

   void *parent;

   ln_message message;

   enum{ FOLLOW_UPS, FOLDERS, POSTED }follow_ups;
   char *server, *group, *boundary, attached, editing;
   unsigned int position;
   int dnd;
   
   np_newsgroup_list *newsgroups;

   EZ_Widget *edit_frame, *cancel_button, *body_text, *header_text,
      *address_entry, *comment_entry, *address_list, *to_list,
      *cc_list, *bcc_list, *address_frame,
      *done_button, *edit_button, *attach_button, *crosspost_button,
      *crosspost_list, *source_list, *ok_button, *attach_frame,
      *cancel_attach_button, *help_button;

   void( *init )( void *parent );
   void( *whine )( void *this, char what );
   void( *compose_callback )( EZ_Widget *widget, void *data );
   void( *compose_mail_callback )( EZ_Widget *widget, void *data );
   void( *create_message )( void *this, ln_origin origin, char *from );
   void( *edit_callback )( EZ_Widget *widget, void *data );
   void( *replace_message )( void *this );
   void( *get_text )( void *this, ln_origin origin, char *from  );
   void( *text_callback )( EZ_Widget *widget, void *data );
   void( *delete_callback )( EZ_Widget *widget, void *data );
   void( *expunge_callback )( EZ_Widget *widget, void *data );
   
   char *( *get_email )( void *this );
   void( *attach_callback )( EZ_Widget *widget, void *data );
   void( *attachment_frame_callback )( EZ_Widget *widget, void *data );
   void( *forward_message_callback )( EZ_Widget *widget, void *data );
   void( *cancel_message_callback )( EZ_Widget *widget, void *data );
   void( *supersede_callback )( EZ_Widget *widget, void *data );
   void( *split_message_callback )( EZ_Widget *widget, void *data );
   char *( *get_header )( void *this, char object, char *header, int size );

   void( *crosspost_callback )( EZ_Widget *widget, void *data );
   void( *crosspost_frame_callback )( EZ_Widget *widget, void *data );
   void( *crosspost_lists_callback )( EZ_Widget *widget, void *data );
   void( *destroy_newsgroup_list )( np_newsgroup_list *list );

   void( *addresses_callback )( EZ_Widget *widget, void *data );
   void( *add_address_callback )( EZ_Widget *widget, void *data );
   void( *address_list_motion_callback )( EZ_Widget *widget, void *data );
   void( *replace_address_callback )( EZ_Widget *widget, void *data );
   void( *sort_addresses_callback )( EZ_Widget *widget, void *data );
   void( *remove_address_callback )( EZ_Widget *widget, void *data );
   void( *addresses_done_callback )( EZ_Widget *widget, void *data );
   void( *address_list_callback )( EZ_Widget *widget, void *data );
   void( *update_addresses )( void *this );
   int( *address_dnd_reorder_encoder )( EZ_Item *item, void *data,
                                       char **message, int *length,
                                        int *needfree );
   int( *address_dnd_reorder_decoder )( EZ_Item *item, void *data,
                                        char *message, int length );
   int( *address_dnd_add_decoder )( EZ_Widget *widget, void *data,
                                    char *message, int length );

   int( *get_recipients )( void *this, EZ_Widget *list, char *keyword );
   void( *addresses_cancel_callback )( EZ_Widget *widget, void *data );
   void( *grab_address_callback )( EZ_Widget *widget, void *data );

} np_edit_object;

typedef struct {

   void *parent;

   EZ_Widget *search_frame, *search_entry, *search_list,
   *search_label;

   char changed_headers;
   int search_onscreen;

   struct {
      unsigned int group;
      unsigned int article;
      unsigned int line;
   } *indices;

   void( *init )( void *parent );
   void( *callback )( EZ_Widget *widget, void *data );
   void( *done_callback )( EZ_Widget *widget, void *data );
   void( *entry_callback )( EZ_Widget *widget, void *data );
   void( *list_motion_callback )( EZ_Widget *widget, void *data );

} np_search_object;

typedef struct {

   void *parent;

   EZ_Widget *newsrc_frame, *server_entry, *server_button, *group_entry,
      *list, *list_button, *searchlist_entry, *search_button;

   EZ_Widget *confirm_frame, *confirm_label, *yes_button, *searchlist_label;

   EZ_LabelPixmap *confirm_pixmap, *query_pixmap, *animate_pixmap_0,
      *animate_pixmap_1, *animate_pixmap_2, *animate_pixmap_3, 
      *animate_pixmap_4, *animate_pixmap_5, *animate_pixmap_6;

   EZ_Widget *account_frame, *account_entry;

   int answer, pos[ 2 ];
   int server, groups;
   pid_t pid;

   np_tree_object *tree_object;

   void( *init )( void *parent );
   void( *callback )( EZ_Widget *widget, void *data );
   void( *done_callback )( EZ_Widget *widget, void *data );
   void( *tree_normal_callback )( EZ_Widget *widget, void *data );
   void( *tree_motion_callback )( EZ_Widget *widget, void *data );
   void( *list_normal_callback )( EZ_Widget *widget, void *data );
   void( *confirm )( void *this, char *message, 
                     np_button_type button );
   void( *confirm_callback )( EZ_Widget *widget, void *data );
   void( *animate )( EZ_Widget *widget, void *data );
   void( *new_group_callback )( EZ_Widget *widget, void *data );
   void( *new_server_callback )( EZ_Widget *widget, void *data );
   void( *remove_server_config )( void *this, unsigned int i );
   void( *list_button_callback )( EZ_Widget *widget, void *data );
   void( *sort_callback )( EZ_Widget *widget, void *data );
   void( *kill_callback )( EZ_Widget *widget, void *data );
   void( *search_callback )( EZ_Widget *widget, void *data );
   void( *select_node )( void *tree_object );
   void( *authinfo_callback )( EZ_Widget *widget, void *data );
   
} np_newsrc_object;

typedef struct {

   EZ_Widget *email_entry, *mua_entry, *editor_entry, *expiry_slider, 
   *configure_frame, **check_buttons, **entries_frames,
   **user_entries, **secret_entries, **configure_labels;

   void *parent;

   void( *init )( void *parent );
   void( *callback )( EZ_Widget *widget, void *data );
   void( *done_callback )( EZ_Widget *widget, void *data );
   void( *check_buttons_callback )( EZ_Widget *widget, void *data );

} np_configure_object;

typedef struct {

   void *parent;

   void( *init )( void *this );
   void( *destroy )( void *this );

   void( *toggle_callback )( EZ_Widget *widget, void *data );
   void( *navigation_callback )( EZ_Widget *widget, void *data );
   void( *request_callback )( EZ_Widget *widget, void *data ); 
   void( *toggle_request )( void *this, void *summary_object, char folder,
                            unsigned int i, unsigned int j );
   void( *mark_callback )( EZ_Widget *widget, void *data );
   void( *mark_group )( void *this, unsigned int i, EZ_Widget *widget );
   void( *update_node )( void *this, unsigned int i );

   void( *folder_requests_callback )( EZ_Widget *widget, void *data );
   char *( *extract_newsgroup )( void *this, unsigned int i );
   void( *update_folder )( void *this, char *folder );
   int( *compare_subjects )( char *one, char *two );
   void( *request_references )( void *this, void *summary_object, char folder,
                                unsigned int i, unsigned int j );

   void( *pattern_callback )( EZ_Widget *widget, void *data );
   void( *launch_pattern )( void *this, unsigned int i, EZ_Widget *button );
   void( *mark_pattern )( void *this, void *tree, void *summary, 
                          unsigned int i, unsigned int j, char seen );
   void( *mark_thread )( void *this, EZ_Widget *button, unsigned int i );

   void( *export_callback )( EZ_Widget *widget, void *data );
   void( *file_selector_callback )( EZ_Widget *widget, void *data );
   void( *cancel_callback )( EZ_Widget *widget, void *data );
   void( *decode_callback )( EZ_Widget *widget, void *data );

   void( *help_callback )( EZ_Widget *widget, void *data );
   void( *help_done_callback )( EZ_Widget *widget, void *data );
   void( *about_callback )( EZ_Widget *widget, void *data );
   void( *about_done_button_callback )( EZ_Widget *widget, void *data );

   int ( *get_missing_parts )( void *this, uulist *item, char *newsgroup );
   void( *message_decode_wrapper )( EZ_Widget *widget, void *data );
    void( *decode_selector_callback )( EZ_Widget *widget, void *data );

    void( *animate )( EZ_Widget *widget, void *data );
    void( *go_home_callback )( EZ_Widget *widget, void *data );
    int( *check_for_running_netscape )();

   void( *selectively_disable_interface )( void *this );
         
   char missing, okay, is_article, pattern_onscreen, decoded;
   uulist *item;

   /* newsreader buttons */

    EZ_Widget *quit_button, *help_button, *configure_button, 
        *newsrc_button, *virtual_button, *folders_button,
        *compose_button, *edit_menu_button, *edit_button,
        *delete_button, *show_button, *edit_menu, *reply_button,
        *follow_up_button, *request_button, *folder_requests_button,
        *summary_button, *supersede_button, *about_button,
        *search_button, *expire_button, *update_button,
        *pack_button, *setup_button, *setup_menu, *mail_button,
        *original_button, *compose_menu, *request_menu, 
        *current_button, *request_thread_button, *request_pattern_button,
        *all_messages_button, *references_button, *clear_button, *mark_button,
        *export_button, *cancel_button, *delete_all_button,
        *mark_menu, *read_button, *unread_button, *toggle_button,
        *toggle_menu, *hide_seen_button, *hide_headers_button,
        *expunge_button, *large_fonts_button, *split_button,
        *decode_button, *fixed_button, *auto_decode_button, *view_button,
        *decode_menu, *decode_current_button, *split_message_button,
        *mark_pattern_seen_button, *mark_thread_seen_button, 
        *auto_expire_button, *mark_pattern_unseen_button, 
      *mark_thread_unseen_button, *forward_button, *addresses_button,
      *inboxes_button, *long_headers_button;

   EZ_Widget *navigation_frame, *export_frame, *file_selector, *filter_entry,
      *prev_article_button, *next_article_button, *prev_group_button,
      *next_group_button, *prev_unread_button, *next_unread_button,
      *next_server_button, *prev_server_button, *prev_non_empty_group_button,
      *next_non_empty_group_button;

   char main_help_onscreen, config_help_onscreen, newsrc_help_onscreen,
      virtual_help_onscreen, folders_help_onscreen, create_help_onscreen,
      inboxes_help_onscreen, addresses_help_onscreen;

   EZ_Widget *main_help_frame, *config_help_frame, *newsrc_help_frame,
      *virtual_help_frame, *folders_help_frame, *create_help_frame, *frame,
      *inboxes_help_frame, *addresses_help_frame;

   EZ_LabelPixmap *next_group_pixmap, *prev_group_pixmap, 
      *next_article_pixmap, *prev_article_pixmap, *prev_unread_pixmap,
      *next_unread_pixmap, *next_server_pixmap, *prev_server_pixmap,
      *prev_non_empty_group_pixmap, *next_non_empty_group_pixmap;

   EZ_Widget *picture;

   EZ_LabelPixmap *jimmy_fish0, *jimmy_fish1, *jimmy_fish2, *jimmy_fish3,
      *jimmy_fish4, *jimmy_fish5, *jimmy_fish6, *jimmy_fish7, *jimmy_fish8,
      *jimmy_fish9, *jimmy_fish10, *jimmy_fish11, *title, *pixmap;
     
   int position;

   EZ_Timer *timer;

   np_newsrc_object *newsrc_object;
   np_search_object *search_object;
   np_update_object *update_object;
   np_configure_object *configure_object;
   np_folders_object *folders_object;
   np_edit_object *edit_object;

} np_buttons_object;

typedef struct {

   EZ_LabelPixmap *title;

   EZ_Widget *app_frame, *message_label, *grid, *main_frame,
   *top_frame, *bottom_frame, *button_frame, *message_frame;

   np_tree_object *tree_object;
   np_summary_object *summary_object;
   np_message_object *message_object;
   np_buttons_object *buttons_object;

   int argc;
   char **argv;

   char *bold_font, *fixed_font, *small_fixed_font, *medium_font,
      *header_font, *italic_font, *bold_italic_font, *small_font;

   char auto_decode, fixed_width, auto_expire, large_fonts, 
      hide_seen, hide_headers, long_headers;

   long int split;
   EZ_Widget *frame;
   EZ_LabelPixmap *icon;

   void ( *init )( void *this, int argc, char **argv );
   void ( *run )();
   void ( *show_message )( void *this, char *message );
   void ( *set_fonts )( EZ_Widget *widget, void *data );
   void ( *destroy )( void *this );

   void( *fixed_callback )( EZ_Widget *widget, void *data );
   void( *decode_callback )( EZ_Widget *widget, void *data );
   void( *auto_expire_callback )( EZ_Widget *widget, void *data );
   void( *hide_callback )( EZ_Widget *widget, void *data );
   void( *long_headers_callback )( EZ_Widget *widget, void *data );
   void( *split_button_callback )( EZ_Widget *widget, void *data );
   void( *split_frame_callback )( EZ_Widget *widget, void *data );

} np_newsreader_object;

void escape_hatch( EZ_Widget *widget, void *data );
void fatal_error();
void lib_error();
