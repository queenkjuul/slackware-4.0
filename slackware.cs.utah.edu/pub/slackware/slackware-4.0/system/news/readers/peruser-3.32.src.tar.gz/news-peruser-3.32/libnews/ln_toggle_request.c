/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "libnews.h"

/*
 * Adds an article number to the :requests file for the specified newsgroup,
 * or virtual group, or if the article number or Message-ID is already
 * present, removes it.
 */

int ln_toggle_request( char *group_name, long int offset, char folder,
                       char *actual_group )
{
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ], *home;
   char *pointer;
   FILE *spool, *temp;
   enum{ no, yes }found;
   int length;


   home = getenv( "HOME" );
   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", home,
             group_name );
   if (( spool = fopen( buffer, "a+" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_toggle_request: could not open file %s.",
                buffer );
      return -1;
   }

   if ( fseek( spool, offset, SEEK_SET ))
   {
      fclose( spool );

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_toggle_request: "
                "error seeking offset %ld in group %s.", offset, group_name );
      return -1;
   }

   if ( fgets( buffer, LN_BUFFER_SIZE, spool ) == NULL )
   {
      fclose( spool );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_toggle_request: error reading data from %s.",
                group_name );
      return -1;
   }

   if ( buffer[ 0 ] != '@' )
   {
      fclose( spool );
      sprintf ( ln_error_message, "libnews: ln_toggle_request: "
                "message at offset %ld is not a header.", offset );
      return -2;
   }

   fclose( spool );

   strcpy( second_buffer, buffer );
   pointer = strtok( strrchr( second_buffer, ' ' ) + 1, ":" );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests", 
             home, group_name );
   if (( spool = fopen( buffer, "a+" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_toggle_request: could not open file %s.",
                buffer );
      return -1;
   }

   rewind( spool );

   strcat( buffer, ".tmp" );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( spool );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_toggle_request: could not open file %s.",
                buffer );
      return -1;
   }

   length = strlen( pointer );
   found = no;
   while( fgets( buffer, LN_BUFFER_SIZE, spool ) != NULL )
   {
      if ( !strncmp( pointer, buffer, length ))
      {
         found = yes;

         while( fgets( buffer, LN_BUFFER_SIZE, spool ) != NULL )
            fputs( buffer, temp );

         break;
      }

      fputs( buffer, temp );
   }

   fclose( spool );

   if ( !found )
      if ( folder )
         fprintf( temp, "%s:%s\n", pointer, actual_group );
      else
         fprintf( temp, "%s\n", pointer );

   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests", 
             home, group_name );
   snprintf( second_buffer, LN_BUFFER_SIZE, "%s.tmp", buffer );
   rename( second_buffer, buffer );

   return 0;
}

/*
 * Adds a Message-ID to the specified group's :requests file, or if it is
 * already present in the file, removes it.
 */

int ln_toggle_reference( char *group, char folder, char *message_id, 
                         char *reference, char *actual_group )
{
   char *home, *pointer, buffer[ LN_BUFFER_SIZE ], 
   second_buffer[ LN_BUFFER_SIZE ];
   FILE *requests, *temp;
   enum{ NO, YES }found;
   int l, k;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests", 
             home = getenv( "HOME" ), group );
   if (( requests = fopen( buffer, "r" )) == NULL )
   {
      if ( errno == ENOENT )
         if (( requests = fopen( buffer, "w" )) != NULL )
         {
            if ( folder )
               fprintf( requests, "%s:%s:%s\n", reference, message_id, 
                        actual_group );
            else
               fprintf( requests, "%s:%s\n", reference, message_id );

            fclose( requests );
            return 0;
         }

      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "libnews: ln_toggle_reference: could not open file %s.", 
                buffer );

      return -1;
   }

   strcat( buffer, ".tmp" );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "libnews: ln_toggle_reference: could not open file %s.", 
                buffer );
      fclose( requests );
      return -1;
   }

   l = strlen( message_id );
   k = strlen( reference );
   found = NO;

   while( fgets( buffer, LN_BUFFER_SIZE, requests ) != NULL )
   {
      if ( buffer[ 0 ] != '<' )
      {
         fputs( buffer, temp );
         continue;
      }

      if ( !strncmp( buffer, reference, k ))
      {
         found = YES;

         pointer = strchr( buffer, ':' ) + 1;
         if ( !strncmp( pointer, message_id, l ))
         {
            while( fgets( buffer, LN_BUFFER_SIZE, requests ) != NULL )
               fputs( buffer, temp );
            break;
         }
      }

      fputs( buffer, temp );
   }

   if ( !found )
      if ( folder )
         fprintf( temp, "%s:%s:%s\n", reference, message_id, actual_group );
      else
         fprintf( temp, "%s:%s\n", reference, message_id );

   fclose( requests );
   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:requests", home,
             group );
   strcpy( second_buffer, buffer );
   strcat( second_buffer, ".tmp" );

   rename( second_buffer, buffer );

   return 0;
}
