/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *  ==================================================================
 *
 *  News Peruser is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2, or (at
 *  your option) any later version.
 *
 *  News Peruser is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  Although News Peruser is licensed under the Free Software
 *  Foundation's GNU General Public License, Peruser is not produced
 *  by, nor is it endorsed by the Free Software Foundation. The Free
 *  Software Foundation is not responsible for developing,
 *  distributing, or supporting Peruser in any way. Anyone may place
 *  software they own the copyright to, under the GNU General Public
 *  License.
 *
 *  The GNU General Public License is included in the News Peruser 
 *  distribution archive in a file called COPYING. If you do
 *  not have a copy of the license, you can download one from
 *  ftp://prep.ai.mit.edu, or you can write to the Free Software
 *  Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *  =====================================================================
 */

#include "peruser.h"
#include "peruser.xpm"
#include "peruser_icon.xpm"
#include<unistd.h>
#include<sys/stat.h>
#include "tree.h"
#include "summary.h"
#include "message.h"
#include "buttons.h"
#include "newsreader.h"

/*
 * The following three functions are the only functions not referenced
 * via objects' function pointers. They are not member functions of any
 * object.
 */

/*
 * Normal exit.
 */

void escape_hatch( EZ_Widget *widget, void *data )
{
   (( np_newsreader_object *)data )->destroy( data );

   EZ_Shutdown();

   exit( EXIT_SUCCESS );
}

/*
 * Abnormal exit.
 */

void fatal_error()
{
   EZ_Shutdown();

   if ( errno )
      perror( "peruser" );
   exit( EXIT_FAILURE );
}

/*
 * Abnormal exit due to unexpected error from libnews.
 */

void lib_error() 
{
   EZ_Shutdown();

   fprintf( stderr, "peruser: %s\n", ln_error_message );

   if ( errno )
      perror( "peruser" );

   exit( EXIT_FAILURE );
}

/*
 *  Each object's init function marries the object's other function pointers
 *  to their intended functions, and initializes the object's other data,
 *  constructing any child objects, and passing control to their init
 *  functions. Member function pointers' names resemble the names of the
 *  functions they point to. For example, the function pointed to by
 *  newsreader->run() is called newsreader_run().  
 */

void newsreader_init( void *this, int argc, char **argv ) 
{
   np_newsreader_object *newsreader;

   int i;
   char buffer[ LN_BUFFER_SIZE ];
   FILE *toggle;

   
   newsreader = ( np_newsreader_object *)this;
   newsreader->app_frame = NULL;
   newsreader->argc = argc;

   if (( newsreader->argv = calloc( argc + 1, sizeof *argv )) == NULL )
      fatal_error();

   for( i = 0; i < argc; ++i )
      if (( newsreader->argv[ i ] = strdup( argv[ i ] )) == NULL )
         fatal_error();

   newsreader->argv[ i ] = NULL;

   newsreader->run = newsreader_run;
   newsreader->destroy = newsreader_destroy;
   newsreader->show_message = newsreader_show_message;
   newsreader->set_fonts = newsreader_set_fonts;

   newsreader->decode_callback = newsreader_decode_callback;
   newsreader->fixed_callback = newsreader_fixed_callback;
   newsreader->auto_expire_callback = newsreader_auto_expire_callback;
   newsreader->hide_callback = newsreader_hide_callback;
   newsreader->split_frame_callback = newsreader_split_frame_callback;
   newsreader->long_headers_callback = newsreader_long_headers_callback;
   newsreader->split_button_callback = newsreader_split_button_callback;

   /* create the spool directory if it does not exist. */
   
   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool", getenv( "HOME" ));
   if ( mkdir( buffer, ( S_IRUSR | S_IWUSR | S_IXUSR )))
      if ( errno != EEXIST )
         fatal_error();

   EZ_Initialize( argc, argv, 0 );
   EZ_DisableSliderDepression();
   EZ_SetGlobalBackground( "LightGray" );
   EZ_SetApplicationName( "News Peruser" );

   NP_DND_GROUP_REORDER_ATOM = EZ_GetAtom( "NP_DND_GROUP_REORDER_ATOM" );
   NP_DND_GROUP_ADD_ATOM = EZ_GetAtom( "NP_DND_GROUP_ADD_ATOM" );
   NP_DND_FOLDERS_ATOM = EZ_GetAtom( "NP_DND_FOLDERS_ATOM" );
   NP_DND_ADDRESS_ATOM = EZ_GetAtom( "NP_DND_ADDRESS_ATOM" );

   /* Get toggle menu settings. */

   newsreader->auto_decode  = 0;
   newsreader->auto_expire  = 0;
   newsreader->fixed_width  = 0;
   newsreader->large_fonts  = 0;
   newsreader->hide_seen    = 0;
   newsreader->hide_headers = 0;
   newsreader->long_headers = 0;
   newsreader->split        = 0;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-toggle", getenv( "HOME" ));
   if (( toggle = fopen( buffer, "r" )) == NULL )
   {
      if ( errno != ENOENT )
         fatal_error();
   }
   else
   {
      if ( fgets( buffer, LN_BUFFER_SIZE, toggle ) != NULL )
         newsreader->auto_decode = atoi( buffer );
      if ( fgets( buffer, LN_BUFFER_SIZE, toggle ) != NULL )
         newsreader->fixed_width = atoi( buffer );
      if ( fgets( buffer, LN_BUFFER_SIZE, toggle ) != NULL )
         newsreader->auto_expire = atoi( buffer );
      if ( fgets( buffer, LN_BUFFER_SIZE, toggle ) != NULL )
         newsreader->large_fonts = atoi( buffer );
      if ( fgets( buffer, LN_BUFFER_SIZE, toggle ) != NULL )
         newsreader->hide_seen = atoi( buffer );
      if ( fgets( buffer, LN_BUFFER_SIZE, toggle ) != NULL )
         newsreader->hide_headers = atoi( buffer );
      if ( fgets( buffer, LN_BUFFER_SIZE, toggle ) != NULL )
         newsreader->long_headers = atoi( buffer );
      if ( fgets( buffer, LN_BUFFER_SIZE, toggle ) != NULL )
         newsreader->split = atoi( buffer );
      fclose( toggle );
   }

   newsreader->set_fonts( NULL, newsreader );

   /* title */

   newsreader->title = EZ_CreateLabelPixmapFromXpmData( peruser_xpm );

   /* app frame */

   newsreader->icon = EZ_CreateLabelPixmapFromXpmData( peruser_icon_xpm );

   newsreader->app_frame = EZ_CreateFrame( NULL, NULL );

   EZ_ConfigureWidget( newsreader->app_frame,
                       EZ_WM_ICON_PIXMAP, newsreader->icon,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_LABEL_PIXMAP, newsreader->title,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_PADX, 3,
                       EZ_PADY, 0,
                       0 );

   /* message label at the top, under the logo pixmap. */

   newsreader->message_label = EZ_CreateLabel( newsreader->app_frame, 
                                               "News Peruser is free software."
                                               " See the file COPYING for "
                                               "license details." );

   EZ_ConfigureWidget( newsreader->message_label,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_HEIGHT, 25,
                       EZ_TEXT_LINE_LENGTH, 120,
                       EZ_LABEL_POSITION, EZ_LEFT,
                       0 );

   /* gridbag */

   newsreader->grid = EZ_CreateGridBag( newsreader->app_frame );

   EZ_ConfigureWidget( newsreader->grid,
                       EZ_GRID_CONSTRAINS, EZ_ROW, 0, 0, 1, 0,
                       EZ_GRID_CONSTRAINS, EZ_COLUMN, 0, 0, 1, 0,
                       EZ_GRID_CONSTRAINS, EZ_COLUMN, 1, 0, 0, 10,
                       0 );

   /* main frame, contains top and bottom frames */

   newsreader->main_frame = EZ_CreateFrame( newsreader->grid, NULL );

   EZ_ConfigureWidget( newsreader->main_frame,
                       EZ_GRID_CELL_GEOMETRY, 0, 0, 1, 1,
                       EZ_GRID_CELL_PLACEMENT, EZ_FILL_BOTH, EZ_CENTER,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_PADX, 0, 
                       EZ_PADY, 0,
                       0 );

   /* top frame, contains group and thread trees. */

   newsreader->top_frame = EZ_CreateFrame( newsreader->main_frame, NULL );

   EZ_ConfigureWidget( newsreader->top_frame,
                       EZ_HEIGHT, 150,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_PADX, 0,
                       EZ_PADY, 0,
                       0 );

   /* tree object */

   if (( newsreader->tree_object = malloc( sizeof *newsreader->tree_object )) 
         == NULL )
      fatal_error();

   newsreader->tree_object->init = tree_init;
   newsreader->tree_object->init( newsreader->tree_object,
                                  newsreader, newsreader->top_frame,
                                  newsreader );

   /* top frame pane handle */

   EZ_CreatePaneHandle( newsreader->top_frame );

   /* summary object */

   if (( newsreader->summary_object 
         = malloc( sizeof *newsreader->summary_object )) == NULL )
      fatal_error();

   newsreader->summary_object->init = summary_init;
   newsreader->summary_object->init( newsreader->summary_object,
                                     newsreader );

   /* main frame pane handle */

   EZ_CreatePaneHandle( newsreader->main_frame );


   /* bottom frame, contains message text widget */

   newsreader->bottom_frame = EZ_CreateFrame( newsreader->main_frame, NULL );

   EZ_ConfigureWidget( newsreader->bottom_frame,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_PADX, 0,
                       EZ_PADY, 0,
                       0 );

   /* message object */

   if (( newsreader->message_object = 
         malloc( sizeof *newsreader->message_object )) == NULL )
      fatal_error();

   newsreader->message_object->init = message_init;
   newsreader->message_object->init( newsreader->message_object,
                                     newsreader );

   /* buttons */

   newsreader->button_frame = EZ_CreateFrame( newsreader->grid, NULL );

   EZ_ConfigureWidget( newsreader->button_frame,
                       EZ_GRID_CELL_GEOMETRY, 1, 0, 1, 2,
                       EZ_GRID_CELL_PLACEMENT, EZ_FILL_VERTICALLY, EZ_RIGHT,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_PADX, 0,
                       EZ_PADY, 0,
                       0 );

   if (( newsreader->buttons_object = 
         malloc( sizeof *newsreader->buttons_object )) == NULL )
      fatal_error();

   newsreader->buttons_object->init = buttons_init;
   newsreader->buttons_object->init( newsreader );

   EZ_DisplayWidget( newsreader->app_frame );

   newsreader->buttons_object->selectively_disable_interface(
      newsreader->buttons_object );
   
   return;
}

void newsreader_set_fonts( EZ_Widget *widget, void *data )
{
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ];
   FILE *toggle;

   newsreader = ( np_newsreader_object *)data;

   if ( newsreader->app_frame == NULL )
   {
      if ( newsreader->large_fonts )
      {
         EZ_SetDefaultLabelFont( "-*-helvetica-bold-r-*-*-14-*-*-*-*-*-*-*" );
         newsreader->small_font = "-*-helvetica-bold-r-*-*-12-*-*-*-*-*-*-*";
         newsreader->bold_font = "-*-helvetica-bold-r-*-*-14-*-*-*-*-*-*-*";
         newsreader->fixed_font = "-*-courier-bold-r-*-*-14-*-*-*-*-*-*-*";
         newsreader->small_fixed_font
            = "-*-courier-bold-r-*-*-12-*-*-*-*-*-*-*";
         newsreader->medium_font
            = "-*-helvetica-medium-r-*-*-14-*-*-*-*-*-*-*";
         newsreader->italic_font
            = "-*-helvetica-medium-o-*-*-14-*-*-*-*-*-*-*";
         newsreader->bold_italic_font 
            = "-*-helvetica-bold-o-*-*-14-*-*-*-*-*-*-*";
         newsreader->header_font
            = "-*-helvetica-medium-r-*-*-18-*-*-*-*-*-*-*";
      }
      else
      {
         EZ_SetDefaultLabelFont( "-*-helvetica-bold-r-*-*-12-*-*-*-*-*-*-*" );
         newsreader->small_font = "-*-helvetica-bold-r-*-*-10-*-*-*-*-*-*-*";
         newsreader->bold_font = "-*-helvetica-bold-r-*-*-12-*-*-*-*-*-*-*";
         newsreader->fixed_font = "-*-courier-bold-r-*-*-12-*-*-*-*-*-*-*";
         newsreader->medium_font
            = "-*-helvetica-medium-r-*-*-12-*-*-*-*-*-*-*";
         newsreader->italic_font
            = "-*-helvetica-medium-o-*-*-12-*-*-*-*-*-*-*";
         newsreader->bold_italic_font 
            = "-*-helvetica-bold-o-*-*-12-*-*-*-*-*-*-*";
         newsreader->header_font
            = "-*-helvetica-medium-r-*-*-14-*-*-*-*-*-*-*";
      }

      return;
   }
   
   newsreader->large_fonts ^= 1;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-toggle", getenv( "HOME" ));
   if (( toggle = fopen( buffer, "w" )) == NULL )
      fatal_error();

   fprintf( toggle, "%d\n%d\n%d\n%d\n%d\n%d\n%ld\n", newsreader->auto_decode,
            newsreader->fixed_width, newsreader->auto_expire, 
            newsreader->large_fonts, newsreader->hide_seen,
            newsreader->hide_headers, newsreader->split  ); 
   fclose( toggle );

   XFlush( EZ_GetDisplay() );
   close( ConnectionNumber( EZ_GetDisplay() ));
   execvp( newsreader->argv[ 0 ], newsreader->argv );

   return;
}

/* 
 * The main loop.
 */

void newsreader_run()
{
   EZ_EventMainLoop();
}

/*
 * Destructor.
 */

void newsreader_destroy( void *this )
{
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_buttons_object *buttons;
   np_edit_object *edit;

   int i;
   char buffer[ LN_BUFFER_SIZE ], *home;
   FILE *toggle;


   newsreader = ( np_newsreader_object *)this;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   edit = ( np_edit_object *)buttons->edit_object;
   tree = ( np_tree_object *)newsreader->tree_object;
   
   if ( newsreader->auto_expire )
   {
      EZ_ListTreeWidgetSelectNode( newsreader->tree_object->tree, 
                                   newsreader->tree_object->root_node, 
                                   NULL );

      buttons->update_object->callback( buttons->expire_button, 
                                        buttons->update_object );
   }

   for( i = 0; i < newsreader->argc; ++i )
      free( newsreader->argv[ i ] );

   free( newsreader->argv );

   EZ_FreeLabelPixmap( newsreader->title );
   EZ_FreeLabelPixmap( newsreader->icon );
   
   newsreader->tree_object->destroy( newsreader->tree_object );
   newsreader->summary_object->destroy( newsreader->summary_object );
   newsreader->message_object->destroy( newsreader->message_object );
   newsreader->buttons_object->destroy( newsreader->buttons_object );

   free( newsreader->tree_object );
   free( newsreader->summary_object );
   free( newsreader->message_object );
   free( newsreader->buttons_object );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/peruser-quotes", 
             home = getenv( "HOME" ));
   remove( buffer );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-toggle", home );
   if (( toggle = fopen( buffer, "w" )) == NULL )
      fatal_error();

   fprintf( toggle, "%d\n%d\n%d\n%d\n%d\n%d\n%d\n%ld\n",
            newsreader->auto_decode,
            newsreader->fixed_width, newsreader->auto_expire, 
            newsreader->large_fonts, newsreader->hide_seen,
            newsreader->hide_headers, newsreader->long_headers,
            newsreader->split ); 
   fclose( toggle );

   return;
}

/*
 * Displays copyright/vanity notice.
 */

void newsreader_show_message( void *this, char *message )
{
   np_newsreader_object *newsreader;

   newsreader = ( np_newsreader_object *)this;

   if ( message == NULL )
      EZ_ConfigureWidget( newsreader->message_label, 
                          EZ_FONT_NAME, newsreader->medium_font,
                          EZ_LABEL_STRING, 
                          "News Peruser is free software. See"
                          " the file COPYING for "
                          "license details.", 
                          0 );
   else
      EZ_ConfigureWidget( newsreader->message_label,
                          EZ_LABEL_STRING, message,
                          0 );

   return;
}

/* 
 * Toggles flag newsreader->message_object uses to determine whether it should
 * attempt to decode messages with MIME headers.
 */

void newsreader_decode_callback( EZ_Widget *widget, void *data )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_summary_object *summary;

   EZ_TreeNode *selected;


   newsreader = ( np_newsreader_object *)data;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   EZ_ConfigureWidget( buttons->auto_decode_button,
                       EZ_LABEL_STRING, (( newsreader->auto_decode ^= 1 ) ?
                                          "+ auto display images" : 
                                          "  auto display images" ),
                       0 );

   if ( newsreader->auto_decode )
      if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
            != NULL )
         summary->tree_motion_callback( summary->thread_tree, summary );

   newsreader->show_message( newsreader, NULL );

   return;
}

/* 
 * Toggles flag newsreader->message_object uses to determine if it should
 * display article text in a fixed-pitch or a proportional typeface.
 */

void newsreader_fixed_callback( EZ_Widget *widget, void *data )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_message_object *message;


   newsreader = ( np_newsreader_object *)data;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   message = ( np_message_object *)newsreader->message_object;

   EZ_ConfigureWidget( buttons->fixed_button,
                       EZ_LABEL_STRING, (( newsreader->fixed_width ^= 1 ) ?
                                         "+ fixed width font" : 
                                         "  fixed width font" ),
                       0 );

   if ( newsreader->fixed_width )
   {
      EZ_ConfigureWidget( message->header_text,
                          EZ_FONT_NAME, newsreader->small_fixed_font,
                          0 );

      EZ_ConfigureWidget( message->body_text,
                          EZ_FONT_NAME, newsreader->fixed_font,
                          0 );
   }
   else
   {
      EZ_ConfigureWidget( message->header_text,
                          EZ_FONT_NAME, newsreader->small_font,
                          0 );

      EZ_ConfigureWidget( message->body_text,
                          EZ_FONT_NAME, newsreader->bold_font,
                          0 );
   }

   return;
}

void newsreader_auto_expire_callback( EZ_Widget *widget, void *data )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;


   newsreader = ( np_newsreader_object *)data;
   buttons = ( np_buttons_object *)newsreader->buttons_object;

   EZ_ConfigureWidget( buttons->auto_expire_button,
                       EZ_LABEL_STRING, (( newsreader->auto_expire ^= 1 ) ?
                                         "+ auto expire on exit" :
                                         "  auto expire on exit" ),
                       0 );

   return;
}

void newsreader_hide_callback( EZ_Widget *widget, void *data )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_tree_object *tree;
   np_summary_object *summary;

   unsigned int i;

   newsreader = ( np_newsreader_object *)data;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   if ( widget == buttons->hide_seen_button )
      EZ_ConfigureWidget( widget,
                          EZ_LABEL_STRING,
                          (( newsreader->hide_seen ^= 1 ) ?
                           "+ hide seen" : "  hide seen" ),
                          0 );
   else
      EZ_ConfigureWidget( widget,
                          EZ_LABEL_STRING,
                          (( newsreader->hide_headers ^= 1 ) ?
                           "+ hide headers" : "  hide headers" ),
                          0 );

   i = EZ_GetItemIntData( EZ_TreeNodeGetItem( EZ_GetListTreeWidgetSelection(
                                                   tree->tree )));

   summary->set_tree( summary, summary->thread_tree,
                      tree->group_list[ i ].group,
                      tree->group_list[ i ].total, i );

   return;
}

void newsreader_long_headers_callback( EZ_Widget *widget, void *data )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_summary_object *summary;
   np_tree_object *tree;
   np_message_object *message;
   

   EZ_TreeNode *selected;
   
   newsreader = ( np_newsreader_object *)data;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   summary = ( np_summary_object *)newsreader->summary_object;
   tree = ( np_tree_object *)newsreader->tree_object;
   message = ( np_message_object *)newsreader->message_object;

   EZ_ConfigureWidget( widget,
                       EZ_LABEL_STRING,
                       (( newsreader->long_headers ^= 1 ) ?
                        "  minimal headers" : "+ minimal headers" ),
                       0 );


   EZ_ConfigureWidget( message->header_text,
                       EZ_OPTIONAL_VSCROLLBAR, (( newsreader->long_headers ) ?
                                                EZ_YES : EZ_NO ),
                       EZ_OPTIONAL_HSCROLLBAR, (( newsreader->long_headers ) ?
                                                EZ_YES : EZ_NO ),
                       EZ_HEIGHT, (( newsreader->long_headers ) ?
                                   150 : 65 ),
                       0 );
   
   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      return;

   if ( selected == tree->root_node ||
        *(char *)EZ_GetItemPtrData( EZ_TreeNodeGetItem( selected )) == 's' )
      return;
   
   summary->tree_motion_callback( summary->thread_tree, summary );

   return;
}

void newsreader_split_button_callback( EZ_Widget *widget, void *data )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;

   char where;

   EZ_Widget *slider, *done_button, *cancel_button, *button_frame;


   newsreader = ( np_newsreader_object *)data;
   buttons = ( np_buttons_object *)newsreader->buttons_object;

   if ( !( where = EZ_GetWidgetIntData( widget )))
      if ( newsreader->split )
      {
         newsreader->split = 0;

         EZ_ConfigureWidget( buttons->split_button,
                             EZ_LABEL_STRING, "  fragment long messages",
                             0 );
         return;
      }

   newsreader->frame 
      = EZ_CreateFrame( NULL, "Split messages longer than N lines:" );

   EZ_ConfigureWidget( newsreader->frame,
                       EZ_HEIGHT, 200,
                       EZ_WIDTH, 500,
                       EZ_TEXT_LINE_LENGTH, 100,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       0 );

   slider = EZ_CreateSlider( newsreader->frame, "N =", 100.0, 10000.0, 100.0,
                             EZ_WIDGET_HORIZONTAL_SLIDER );

   EZ_ConfigureWidget( slider,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_SLIDER_RESOLUTION, 100.0,
                       EZ_CLIENT_INT_DATA, (( where ) ? 1 : 0 ),
                       0 );

   button_frame = EZ_CreateFrame( newsreader->frame, NULL );

   EZ_ConfigureWidget( button_frame,
                       EZ_ORIENTATION, EZ_HORIZONTAL,
                       0 );

   done_button = EZ_CreateButton( button_frame, "done", 0 );

   EZ_ConfigureWidget( done_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_CLIENT_INT_DATA, 0,
                       EZ_CLIENT_PTR_DATA, slider,
                       EZ_CALLBACK, newsreader->split_frame_callback, 
                       newsreader,
                       0 );

   cancel_button = EZ_CreateButton( button_frame, "cancel", 0 );

   EZ_ConfigureWidget( cancel_button,
                       EZ_FOREGROUND, "DarkRed",
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_CLIENT_INT_DATA, 1, 
                       EZ_CALLBACK, newsreader->split_frame_callback,
                       newsreader, 
                       0 );
   
   EZ_DisplayWidget( newsreader->frame );
   EZ_SetGrab( newsreader->frame );

   return;
}

void newsreader_split_frame_callback( EZ_Widget *widget, void *data )
{
   np_newsreader_object *newsreader;
   np_buttons_object *buttons;
   np_edit_object *edit;
   np_newsrc_object *newsrc;

   EZ_Widget *slider;

   char buffer[ LN_BUFFER_SIZE ];


   newsreader = ( np_newsreader_object *)data;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   edit = ( np_edit_object *)buttons->edit_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;

   if ( EZ_GetWidgetIntData( widget ))
   {
      EZ_DestroyWidget( newsreader->frame );
      newsrc->answer = 0;
      return;
   }

   slider = EZ_GetWidgetPtrData( widget );

   newsreader->split =  EZ_GetSliderValue( slider );

   if ( newsreader->split )
      snprintf( buffer, LN_BUFFER_SIZE, "+ fragment long messages (> %d lines)",
                newsreader->split );

   if ( !(  EZ_GetWidgetIntData( slider )))
         EZ_ConfigureWidget( buttons->split_button,
                             EZ_LABEL_STRING, 
                             (( newsreader->split ) ? 
                              buffer :
                              "  fragment long messages" ),
                             0 );

   newsrc->answer = 1;

   EZ_DestroyWidget( newsreader->frame );

   return;
}
