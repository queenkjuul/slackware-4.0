/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   ====================================================================
 */

#define _GNU_SOURCE
#include<stdlib.h>
#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<errno.h>

#define LN_BUFFER_SIZE 2048
#define LN_SECONDS 120

/* types */

/*
 * Use for to represent address book in memory.
 */

typedef struct {

  char *address;
  char *comment;

} ln_address;

/*
 * Used to build linked list of Message-IDs from an article's References
 * header.
 */

typedef struct
{
   char *current_ref;

   void *next_ref;
   void *prev_ref;
}
ln_reference;

/*
 * Node definition for nodes in threading tree. After the list has been
 * created, the next_node and prev_node pointers traverse a doubly-linked list
 * of all nodes in spoolfile order. After threading, queue_head points to a
 * doubly-linked list of follow-up child nodes. queue_next and queue_prev
 * traverse child list, inside the list. Which is to say, a node may be both
 * part of another node's queue of children, and therefore have non-NULL
 * values for queue_next and/or queue_prev, and also have a queue of children
 * of its own, starting at the node pointed to by queue_head and ending at the
 * node pointed to by queue_tail.
 */

typedef struct { 
   
   unsigned int position, gap, queue_count;

   long int offset, size;

   char *message_id;
   char *subject;
   char *converted_date;
   ln_reference *references;

   enum{ no, yes }queued;

   void *queue_head;
   void *queue_tail;
   void *queue_next;
   void *queue_prev;

   void *next_node;
   void *prev_node;

} ln_node;

typedef struct {

   char *group;
   char *server;
   char delete;
   
   unsigned int server_idx;
   unsigned int unread;
   unsigned int total;
   unsigned int requests;

} ln_group_list;

typedef enum{ LN_FOLDERS, LN_NNTP }ln_server_type;

typedef struct {

   char *server;
   unsigned int first;
   unsigned int groups;
   unsigned int follow_ups;

} ln_server_list;

typedef struct {

   unsigned int total;
   unsigned int unread;
   unsigned int requests;
   unsigned int headers;
   unsigned int articles;

} ln_group_stats; 

typedef struct {

   unsigned int ordinal;
   unsigned int threading;
   unsigned int queue;
   long int offset;
   long int size;
   long int h_lines;
   long int b_lines;
   
   char *subject;
   char *date;
   char *from;
   char *message_id;
   unsigned is_unread:  1;
   unsigned is_article: 1;
   unsigned is_requested: 1;
   unsigned has_ref_requests: 1;

   /* 
    * Possible conflict with C++ keyword
    */

   unsigned delete: 1;
   unsigned is_sibling: 1;

} ln_group_summary; 

typedef struct {

   char *header;
   char *body;

} ln_message;

typedef struct
{
   char *request;
   enum{ not, found }found;
} ln_requests_list;


typedef enum{ LN_HEADER, LN_MESSAGE }ln_type;
typedef enum{ LN_ORIGINAL, LN_FOLLOW_UP, LN_MAIL, LN_REPLY, LN_FORWARD,
                 LN_CANCEL_MESSAGE, LN_SUPERSEDE, LN_EDIT }ln_origin;
typedef enum{ LN_HEADERS, LN_ARTICLES, LN_REQUESTS, LN_CATCHUP, 
                 LN_NOTHING, LN_CANCEL }ln_what;
typedef enum{ LN_NO, LN_YES }ln_xover;

   /* Global */

char ln_error_message[ LN_BUFFER_SIZE ];

/* Functions */

void ln_allocation_error();

int ln_signal( int signo, void( *handler )( int signo ));

void ln_sigalrm_handler( int signo );

char *ln_fgets( char *buffer, int size, FILE *stream );

int ln_compare( const void *a, const void *b );

int ln_get_groups( unsigned int *count, ln_group_list **list, 
                   unsigned int *servers, ln_server_list **server_list );

int ln_get_folders( unsigned int *groups, ln_group_list **group_list,
                    unsigned int *servers, ln_server_list **server_list );

int ln_get_inboxes( unsigned int *groups, ln_group_list **group_list,
                    unsigned int *servers, ln_server_list **server_list );

int ln_get_virtual( unsigned int *groups, ln_group_list **group_list,
                    unsigned int *servers, ln_server_list **server_list );

int ln_get_group_summary( char *group_name, char *server,
                          ln_group_stats *stats,
                          ln_group_summary **summary );

int ln_get_message_text( char *group_name, 
                         ln_type type,
                         long int offset, long int size,
                         ln_message *message );

char *ln_get_line( char *line, ln_message *message );

int ln_create_header( char *group_name,
                      char *NNTP_addr,
                      char *email_addr,
                      ln_origin origin,
                      ln_message *message );

int ln_mark_read( char *group_name, unsigned int ordinal );

int ln_mark_unread( char *group_name, unsigned int ordinal );

int ln_toggle_request( char *group_name, long int offset, char folder,
                       char *actual_group );

int ln_open_server( char *server_addr, FILE **stream, 
                    int ( *callback )( void *data, int expired ), 
                    void *data );

int ln_has_xover( FILE *server );

void ln_destroy_requests_list( ln_requests_list *list, unsigned int total );

int ln_retrieve_requests( char *group_name, FILE *server, 
                          ln_requests_list *list, unsigned int total,
                          char folder, 
                          int ( *callback )( void *data, char *group,
                                             unsigned int lines,
                                             unsigned int begin,
                                             unsigned int current,
                                             unsigned int end ),
                          void *data );

int ln_update_group( char *group_name, FILE *server, ln_what what,
                     ln_xover xover, unsigned int requests, int quantity,
                     int ( *callback )( void *data, char *group,
                                        unsigned int lines,
                                        unsigned int begin,
                                        unsigned int current, 
                                        unsigned int end ), 
                     void *data );

int ln_update_inbox( char *inbox );

int ln_sort_spool( char *group_name );

void ln_init_node( ln_node *node, unsigned int position,
                   long int offset, long int size, char *my_id,
                   char *my_subject, char *my_date, char *my_refs );

void ln_thread_list( ln_node *list );

int ln_thread_spool( char *group_name );

int ln_post_messages( FILE *stream, char *server, unsigned int *count );

int ln_convert_date( char *date, char **converted );

int ln_convert_printable( char **date );

int ln_pack_spool( char *group_name, char folder );

int ln_expire_spool( char *group_name, char folder, char *elapsed, 
                     unsigned int total, char **local_times,
                     unsigned int *expired );

int ln_add_group( char *server, char *group );

int ln_add_server( char *server );

int ln_remove_group( char *server, char *group );

int ln_remove_server( char *server );

int ln_get_list( FILE *server, char *name );

int ln_get_newgroups( FILE *server, char *name );

int ln_write_timestamp( char *server );

int ln_sort_server( char *server );

int ln_sort_list( char *server );

int ln_move_group( unsigned int leader, unsigned int follower );

int ln_move_line( unsigned int leader, unsigned int follower, char *filename );

int ln_add_group_behind( char *leader, char *follower );

int ln_add_line( char *filename, char *news );

int ln_remove_line( char *filename, char *old );

int ln_sort_file( char *filename );

int ln_replace_line( char *filename, char *old, char *new );

int ln_move_folder( unsigned int leader, unsigned int follower );

int ln_move_inbox( unsigned int leader, unsigned int follower );

int ln_move_persistent( unsigned int leader, unsigned int follower );

int ln_add_folder( char *new );

int ln_add_persistent( char *new );

int ln_add_address( char *new );

int ln_add_inbox( char *new );

int ln_remove_folder( char *old );

int ln_remove_address( char *old );

int ln_remove_persistent( char *old );

int ln_remove_inbox( char *old );

int ln_sort_folders();

int ln_sort_addresses();

int ln_sort_persistent();

int ln_sort_inboxes();

int ln_get_folder_list( char *group, char *folder, ln_requests_list **list,
                        unsigned int *count );

int ln_replace_folder( char *old, char *new );

int ln_replace_address( char *old, char *new );

int ln_replace_persistent( char *old, char *new );

int ln_replace_inbox( char *old, char *new );

int ln_move_folder( unsigned int leader, unsigned int follower );

int ln_move_address( unsigned int leader, unsigned int follower );

int ln_move_persistent( unsigned int leader, unsigned int follower );

int ln_update_folder( char *folder, char *group,
                      int ( *callback )( void *data, unsigned int i,
                                         char *filter, char *group ), 
                      void *data );

int ln_toggle_reference( char *group, char folder, char *message_id, 
                         char *reference, char *actual_group );

int ln_delete_articles( char *server, char *group, 
                        ln_group_summary *contents, unsigned int total, 
                        char follow_up );
 
int ln_file_article( char *group_name, char *server, unsigned int i, 
                     char *folder_name );

int ln_truncate_spool( char *server, char *group, char what );
