/*
 * Prototypes.
 */

void message_init( void *this, void *parent );
void message_set_message( void *this, char *group_name, ln_type type, 
                          long int offset, long int size );
void message_decode( void *this );
int message_uu_busy_callback( void *this, uuprogress *progress );
void message_picture_frame_callback( EZ_Widget *widget, void *data );
void message_picture_frame_button_destroy_callback( EZ_Widget *widget,
                                                    void *data );
void message_clear_message( void *this );
void message_destroy_pix_list( np_pix_list *pix );
void message_destroy( void *parent );
