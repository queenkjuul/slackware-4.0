/*
   News Peruser Copyright (c) 1996-1998 James Bailie
   ==================================================================

   News Peruser is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2, or (at
   your option) any later version.

   News Peruser is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   Although News Peruser is licensed under the Free Software
   Foundation's GNU General Public License, Peruser is not produced
   by, nor is it endorsed by the Free Software Foundation. The Free
   Software Foundation is not responsible for developing,
   distributing, or supporting Peruser in any way. Anyone may place
   software they own the copyright to, under the GNU General Public
   License.

   The GNU General Public License is included in the News Peruser 
   distribution archive in a file called COPYING. If you do
   not have a copy of the license, you can download one from
   ftp://prep.ai.mit.edu, or you can write to the Free Software
   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.

   =====================================================================
*/

#include "libnews.h"

/*
 * Checks to see if there are references requests generated from the
 * References header of the article with Message-ID pointed to by variable
 * message_id.
 */

int ln_has_ref_requests( char *group_path, char *message_id )
{
   char buffer[ LN_BUFFER_SIZE ], *pointer;
   enum{ NO, YES }found;
   FILE *requests;


   snprintf( buffer, LN_BUFFER_SIZE, "%s:requests", group_path );
   if (( requests = fopen( buffer, "r" )) == NULL )
   {
      if ( errno == ENOENT )
         return 0;

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_has_ref_requests: "
                "could not open file %s.", buffer );
      return -1;
   }

   found = NO;
   while( fgets( buffer, LN_BUFFER_SIZE, requests ) != NULL )
      if ( buffer[ 0 ] == '<' )
      {
         pointer = strchr( buffer, ':' );
         if ( !strncmp( strtok( ++pointer, "\n" ), message_id, 
              strlen( message_id )))
         {
            found = YES;
            break;
         }
      }

   fclose( requests );

   if ( found )
      return 1;
   else 
      return 0;
}

/*
 * Returns a pointer to a colon-delimited string of article numbers
 * corresponding to articles whose full text has been requested.
 */

char *ln_get_requests( char *group_path, unsigned int *count )
{
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ];
   char *value;

   FILE *requests;


   *count = 0;

   snprintf( buffer, LN_BUFFER_SIZE, "%s:requests", group_path );
   if (( requests = fopen( buffer, "r" )) == NULL )
      return NULL;

   second_buffer[ 0 ] = '\0';
   while( fgets( buffer, LN_BUFFER_SIZE, requests ) != NULL )
   {
      if ( strlen( second_buffer ) >= ( LN_BUFFER_SIZE - 10 ))
         break;

      ( *count )++;

      if ( isdigit( buffer[ 0 ] ))
      {
         strcat( second_buffer, strtok( buffer, ":\n" ));
         strcat( second_buffer, ":" );
      }
   }
   fclose( requests );

   if ( second_buffer[ 0 ] == '\0' )
      return NULL;
   else
   {
      if (( value = strdup( second_buffer )) == NULL )
         ln_allocation_error();

      return value;
   }
}

/*
 * Returns an array of ln_group_Summary structures, recording 
 * information about each article in a spool file.
 */

int ln_get_group_summary( char *group_name, char *server,
                          ln_group_stats *stats,
                          ln_group_summary **summary ) 
{

   ln_group_summary *summary_pointer;

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ];

   char *home, *list, *list_pointer, *subject, *date, *from, *message_id;

   unsigned int total, ordinal, unread, headers, requests, articles;
   long int offset, temp, h_lines, b_lines;
   short int found, test, tab;

   enum{ no, yes }header, content;

   FILE *spool_stream, *read_stream, *thread_stream;


   if (( summary_pointer = summary[ 0 ] ) == NULL )
   {
      stats->total = 0;
      stats->unread = 0;
      stats->requests = 0;
      stats->headers = 0;
      stats->articles = 0;
      return -2;
   }
   
   total = ordinal = unread = headers = requests = articles = 0;

   home = getenv( "HOME" );

   if ( !strncmp( group_name, "Follow-ups", 10 )) 
      snprintf( second_buffer, LN_BUFFER_SIZE,
                "%s/.peruser_spool/%s-FOLLOW-UPS", home, server );
   else
      if ( !strncmp( group_name, "Posted", 6 ))
         snprintf( second_buffer, LN_BUFFER_SIZE, 
                   "%s/.peruser_spool/%s-POSTED", home, server );
      else
         snprintf( second_buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s", 
                   home, group_name );

   if (( spool_stream = fopen( second_buffer, "r" )) == NULL ) 
   {
      if ( errno == ENOENT )
         if (( spool_stream = fopen( second_buffer, "w+" )) == NULL )
         {
            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_get_group_summary: "
                      "could not open file: %s.", 
                      second_buffer );
            return -1;
         }
   }

   list = ln_get_requests( second_buffer, &requests );

   strcat( second_buffer, ":read" );
   if (( read_stream = fopen( second_buffer, "r" )) == NULL )
      if ( errno != 2 ) 
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_get_group_summary: could not open file: %s.", 
                   second_buffer );
         return -1;
      }

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:threading", 
             home, group_name );
   if (( thread_stream = fopen( second_buffer, "r" )) == NULL )
      if ( errno != 2 )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_get_group_summary: could not open file: %s.",
                   second_buffer );
         return -1;
      }

   found = 0;
   header = content = no;
   offset = 0;
   h_lines = b_lines = 0;

   subject = date = from = message_id = NULL;

   while( fgets( buffer, LN_BUFFER_SIZE, spool_stream ) != NULL )
   {
      if ( !strncmp( buffer, ".\r\n", 3 ) || !strncmp( buffer, "\r\n", 3 ))
         if ( found < 4 )
         {
            if ( subject == NULL )
               if (( subject = strdup( "Subject: (none)\r\n" )) == NULL )
                  ln_allocation_error();

            if ( date == NULL )
               if (( date = strdup( "Date: (none)\r\n" )) == NULL )
                  ln_allocation_error();

            if ( from == NULL )
               if (( from = strdup( "From: (none)\r\n" )) == NULL )
                  ln_allocation_error();

            if ( message_id == NULL )
               if (( message_id = strdup( "Message-ID: (none)\r\n" )) == NULL )
                  ln_allocation_error();

            found = 4;
         }
         else
            break;

      content = yes;

      if ( buffer[ 0 ] == '@' ) 
      {
         header = yes;
         strcpy( second_buffer, buffer );
         continue;
      }

      h_lines++;

      if ( !strncasecmp( buffer, "Subject:", 8 )) 
      {
         tab = strspn( buffer + 8, " \t" );
         if (( subject = malloc( strlen( buffer + 8 + tab ) - 1 ))
               == NULL )
            ln_allocation_error();

         strcpy( subject, strtok( buffer + 8 + tab, "\r\n" ));
         found++;
      }
      else
         if ( !strncasecmp( buffer, "Date:", 5 )) 
         {
            tab = strspn( buffer + 5, " \t" );
            if (( date = malloc( strlen( buffer + 5 + tab ) - 1 ))
                  == NULL )
               ln_allocation_error();

            strcpy( date, strtok( buffer + 5 + tab, "\r\n" ));
            found++;
         }
         else
            if ( !strncasecmp( buffer, "From:", 5 )) 
            {
               tab = strspn( buffer + 5, " \t" );
               if (( from = malloc( strlen( buffer + 5 + tab ) - 1 ))
                     == NULL )
                  ln_allocation_error();

               strcpy( from, strtok( buffer + 5 + tab, "\r\n" ));
               found++;
            }
            else
               if ( !strncasecmp( buffer, "Message-ID:", 11 ))
               {
                  tab = strspn( buffer + 11, " \t" );
                  if (( message_id = malloc( strlen( buffer + 11 + tab ) - 1 ))
                        == NULL )
                     ln_allocation_error();

                  strcpy( message_id, strtok( buffer + 11 + tab, "\r\n" ));
                  found++;
               }

      if ( found == 4 ) 
      {
         if (( summary_pointer->subject = strdup( subject )) == NULL )
            ln_allocation_error();

         if ( subject != NULL )
            free( subject );
         subject = NULL;

         if (( summary_pointer->date = strdup( date )) == NULL )
            ln_allocation_error();

         if ( date != NULL )
            free( date );
         date = NULL;

         if (( summary_pointer->from = strdup( from )) == NULL )
            ln_allocation_error();

         if ( from != NULL )
            free( from );
         from = NULL;

         if (( summary_pointer->message_id = strdup( message_id )) == NULL )
            ln_allocation_error();

         if ( message_id != NULL )
            free( message_id );
         message_id = NULL;

         total++;
         summary_pointer->ordinal = total;
         summary_pointer->offset = offset;

         if ( thread_stream == NULL )
         {
            summary_pointer->threading = 0;
            summary_pointer->queue = 0;
         }
         else
            if ( fgets( buffer, LN_BUFFER_SIZE, thread_stream ) == NULL )
            {
               fclose( thread_stream );
               thread_stream = NULL;
               summary_pointer->threading = 0;
               summary_pointer->queue = 0;
            }
            else
            {
               summary_pointer->threading = atoi( strtok( buffer, ":") );
               summary_pointer->queue = atoi( strtok( NULL, "\n" ));
            }

         if ( read_stream == NULL ) 
            summary_pointer->is_unread = 0;
         else 
            if ( fgets( buffer, LN_BUFFER_SIZE, read_stream ) == NULL ) 
            {
               fclose( read_stream );
               read_stream = NULL;
               summary_pointer->is_unread = 0;
            }
            else
               summary_pointer->is_unread = ( buffer[ 0 ] == 'u' ) ? 1 : 0;

         if ( summary_pointer->is_unread )
            unread++;

         summary_pointer->is_article = header ? 0 : 1;

         if ( header ) 
         {
            headers++;

            strcpy( buffer, strtok( strrchr( second_buffer, ' ' ),
                  ":" ) + 1 );

            summary_pointer->is_requested = 0;
            if ( list != NULL ) 
            {
               strcpy( second_buffer, list );
               for( list_pointer = strtok( second_buffer, ":" );
                    list_pointer != NULL;
                    list_pointer = strtok( NULL, ":" ))
                  if ( !strcmp( list_pointer, buffer ) )
                  {
                     summary_pointer->is_requested = 1;
                     break;
                  }
            }

            header = no;
         }

         snprintf( second_buffer, LN_BUFFER_SIZE,                  
                   "%s/.peruser_spool/%s", home, group_name );             
         if (( test = ln_has_ref_requests( second_buffer,
               summary_pointer->message_id )) == -1 )
         {                                                         
            fclose( spool_stream );                                
            if ( read_stream != NULL )                             
               fclose( read_stream );                              
            return -1;                                             
         }                                                         
         summary_pointer->has_ref_requests = test;              

         found = 0;
         do
         {
            if ( ferror( spool_stream ))
            {
               perror( "spool_stream" );
               exit( 1 );
            }

            if ( fgets( buffer, LN_BUFFER_SIZE, spool_stream ) == NULL )
            {
               snprintf( ln_error_message, LN_BUFFER_SIZE, 
                         "libnews: ln_get_group_summary: %s: "
                         "premature end of spool.\n", 
                         group_name );

               if ( list != NULL )
               {
                  free( list );
                  list = NULL;
               }

               fclose( spool_stream );
               if ( read_stream != NULL )
                  fclose( read_stream ); 
               return -1;
            }

            if ( !found && !strncmp( buffer, "\r\n", 2 ))
            {
               found = 1;
               continue;
            }

            if ( found )
               b_lines++;
            else
               h_lines++;
         }
         while( strncmp( buffer, ".\r\n", 3 ));

         found = 0;
         temp = offset;
         offset = ftell( spool_stream );

         summary_pointer->size = offset - temp;
         summary_pointer->h_lines = h_lines;
         summary_pointer->b_lines = b_lines;

         summary_pointer->delete = 0;
         summary_pointer->is_sibling = 0;
         
         b_lines = h_lines = 0;

         summary_pointer++;
      }
   }

   fclose( spool_stream );

   if ( thread_stream != NULL )
      fclose( thread_stream );

   if ( read_stream != NULL )
      fclose( read_stream );

   if ( list != NULL )
      free( list );

   if ( found > 0 && found < 4 )
   {
      if ( subject != NULL )
         free( subject );
      if ( date != NULL )
         free( date );
      if ( from != NULL )
         free( from );
      if ( message_id != NULL )
         free( message_id );

      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "libnews: ln_get_group_summary: %s: premature end of spool: "
                "or malformed message header.",
                group_name );
      return -1;
   }

   stats->total = total;
   stats->unread = unread;
   stats->requests = requests;
   stats->headers = headers;
   stats->articles = total - headers;

   if ( content )
      return 0;
   else
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE, 
                "libnews: ln_get_group_summary: %s: empty spool.",
                group_name );
      return -2;
   }
}
