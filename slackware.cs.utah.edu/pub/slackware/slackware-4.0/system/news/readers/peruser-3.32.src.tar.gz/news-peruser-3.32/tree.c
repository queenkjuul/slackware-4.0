/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "peruser.h"
#include "folder.xpm"
#include "virtual.xpm"
#include "news.xpm"
#include "inbox.xpm"
#include "tree.h"

/*
 * Although there is no generic mechanism to implement inheritance in News
 * Peruser, there are two different tree objects, both derived from the same
 * typdef-ed "class," newsreader->tree_object, and newsrc->tree_object. The
 * constructor tree_init function sets some function pointers in each tree
 * object to point to different functions based on what parent object is
 * passed as an argument, and to implement other derived class behaviour, I've
 * inserted conditionals in the functions the tree objects share in common to
 * determine the calling tree object's parent.
 */

void tree_init( void *this, void *parent, EZ_Widget *frame,   
                void *newsreader_object )
{
  np_tree_object *tree;
  np_newsreader_object *newsreader;
  np_newsrc_object *newsrc;


  tree = ( np_tree_object *)this;
  newsreader = ( np_newsreader_object *)newsreader_object;

  /*
   * This conditional prevents us from accessing the buttons object if we are
   * newsreader->tree_object, because the buttons object will not have been
   * created yet, otherwise, we are the newsrc->tree_object, so this is okay.
   */

  if (( tree->parent = parent ) != newsreader )
     newsrc = ( np_newsrc_object *)
        (( np_buttons_object *)newsreader->buttons_object )->newsrc_object;
  else
     newsrc = NULL;

  tree->newsreader = newsreader;

  tree->virtual_icon = EZ_CreateLabelPixmapFromXpmData( virtual_xpm );
  tree->news_icon = EZ_CreateLabelPixmapFromXpmData( news_xpm );
  tree->folder_icon = EZ_CreateLabelPixmapFromXpmData( folder_xpm );
  tree->inbox_icon = EZ_CreateLabelPixmapFromXpmData( inbox_xpm );

  tree->empty_colour = "Gray60";
  tree->read_colour = "Black";
  tree->unread_colour = "Black";

  tree->root_node = NULL;
  tree->groups = 0;
  tree->servers = 0;

  tree->g = 'g';
  tree->s = 's';

  tree->group_list = NULL;
  tree->server_list = NULL;
  tree->group_state = NULL;
  tree->server_state = NULL;

  tree->group_nodes = NULL;
  tree->server_nodes = NULL;

  tree->set_tree = tree_set_tree;
  tree->normal_callback = tree_normal_callback;
  tree->motion_callback = tree_motion_callback;
  tree->collapse_server = tree_collapse_server;
  tree->update_node = tree_update_node;
  tree->destroy = tree_destroy;
  tree->destroy_lists = tree_destroy_lists;
  tree->update_lists = tree_update_lists;

  tree->dnd_encoder = tree_dnd_encoder;
  tree->dnd_reorder_decoder = tree_dnd_reorder_decoder;
  tree->dnd_add_decoder = tree_dnd_add_decoder;
  tree->dnd_folders_decoder = tree_dnd_folders_decoder;

  /*
   * properties
   */

  tree->server_prop 
    = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font,
                          0 );

  tree->read_prop 
    = EZ_GetTextProperty( EZ_FOREGROUND, tree->read_colour,
                          EZ_FONT_NAME,newsreader->medium_font,
                          0 );

  tree->unread_prop
    = EZ_GetTextProperty( EZ_FOREGROUND, tree->unread_colour,
                          EZ_FONT_NAME, newsreader->bold_font,
                          0 );

  tree->none_prop = 
    EZ_GetTextProperty( EZ_FOREGROUND, tree->empty_colour,
                        EZ_FONT_NAME, newsreader->medium_font,
                        0 );

  tree->follow_up_none_prop
    = EZ_GetTextProperty( EZ_FOREGROUND, tree->empty_colour,
                          EZ_FONT_NAME, newsreader->medium_font,
                          0 );

  tree->back_prop = EZ_GetTextProperty( EZ_FOREGROUND, tree->empty_colour,
                                        0 );

  tree->highlight_prop = EZ_GetTextProperty( EZ_FOREGROUND, 
                                             tree->unread_colour,
                                             0 );

  tree->server_back_prop = EZ_GetTextProperty( EZ_FONT_NAME,
                                               newsreader->header_font,
                                               EZ_FOREGROUND,
                                               tree->empty_colour,
                                               0 );

  tree->server_highlight_prop = EZ_GetTextProperty( EZ_FONT_NAME,
                                                    newsreader->header_font,
                                                    EZ_FOREGROUND,
                                                    tree->unread_colour,
                                                    0 );

  /*
   * list tree 
   */

  tree->tree = EZ_CreateListTree( frame, 1, 1 );

  
  EZ_SetHScrollbarDiscreteSpeed( tree->tree, 10 );
  EZ_SetVScrollbarDiscreteSpeed( tree->tree, 10 );

  if ( tree->parent == newsreader )
    EZ_ConfigureWidget( tree->tree,
                        EZ_WIDTH, 250,
                        EZ_CALLBACK, 
                        tree->normal_callback, this,
                        EZ_MOTION_CALLBACK, tree->motion_callback, this,
                        0 );
  else
    EZ_ConfigureWidget( tree->tree,
                        EZ_CALLBACK, newsrc->tree_normal_callback,
                        this, 
                        EZ_MOTION_CALLBACK, 
                        newsrc->tree_motion_callback, this,
                        0 );

  tree->update_lists( tree );
  tree->set_tree( tree );

  return;
}

/*
 * The ln_group_list and ln_server_list structures are defined in libnews.h
 * These two lists contain data decribing each group in ~/.peruser-newsrc, and
 * the currently-selected newsgroup in detail.
 */

void tree_destroy_lists( unsigned int groups, ln_group_list *list,
                         unsigned int servers, ln_server_list *server_list )
{
   unsigned int i;

   if ( list != NULL )
   {
      for( i = 0; i < groups; ++i )
      {
         free( list[ i ].group );
         free( list[ i ].server ); 
      }

      free( list );
      list = NULL;
   }

   if ( server_list != NULL )
   {
      for( i = 0; i < servers; ++i )
         free( server_list[ i ].server );

      free( server_list );
      server_list = NULL;
   }

   return;
}

/*
 * Destructor.
 */

void tree_destroy( void *this )
{
   np_tree_object *tree;


   tree = ( np_tree_object *)this;

   if ( tree->server_nodes != NULL )
      free( tree->server_nodes );

   if ( tree->group_state != NULL )
      free( tree->group_state );

   if ( tree->server_state != NULL )
      free( tree->server_state );

   tree->destroy_lists( tree->groups, tree->group_list,
                        tree->servers, tree->server_list );

   EZ_FreeLabelPixmap( tree->news_icon );
   EZ_FreeLabelPixmap( tree->folder_icon );
   EZ_FreeLabelPixmap( tree->virtual_icon );
   EZ_FreeLabelPixmap( tree->inbox_icon );

   return;
}

/*
 * Creates the group tree.
 */

void tree_set_tree( void *this )
{
   np_tree_object *tree_object;
   np_newsrc_object *newsrc;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ], *pointer; 
   unsigned int j, k, z;
   long int i;

   EZ_TreeNode *root_node, *server_node, *group_node;
   EZ_Item *item;
   EZ_TextProperty *property;


   tree_object = ( np_tree_object *)this;
   newsreader = ( np_newsreader_object *)tree_object->newsreader;

   if ( tree_object->parent != newsreader )
      newsrc = newsreader->buttons_object->newsrc_object;
   else
      newsrc = NULL;

   /*
    * root node 
    */

   if ( tree_object->parent == newsreader )
      property = tree_object->server_prop;
   else
      property = tree_object->server_back_prop;

   tree_object->root_node = root_node
      = EZ_CreateTreeNode( NULL, EZ_CreateLabelItem( "Collections",
                                                     property ));

   /*
    * tree
    */  

   i = -1;
   for( j = 0; j < tree_object->servers; ++j )
   {
      /*
       * determine server item text 
       */

      if ( tree_object->parent != newsreader ||
            !tree_object->server_list[ j ].groups )
         strcpy( buffer, tree_object->server_list[ j ].server );
      else
         if ( tree_object->server_state[ j ] == NP_NOT_SHOWN )
            snprintf( buffer, LN_BUFFER_SIZE, "+ %s", 
                      tree_object->server_list[ j ].server );
         else
            snprintf( buffer, LN_BUFFER_SIZE, "- %s", 
                      tree_object->server_list[ j ].server );

      /*
       * determine server item colour 
       */

      if ( tree_object->parent != newsreader )
      {
         if ( j == newsrc->server )
            property = tree_object->server_highlight_prop;
         else
            property = tree_object->server_back_prop;
      }
      else
         property = tree_object->server_prop;

      /*
       * create server item 
       */

      item = EZ_CreateLabelItem( buffer, property );

      EZ_ConfigureItem( item,
                        EZ_CLIENT_INT_DATA, j,
                        EZ_CLIENT_PTR_DATA, &tree_object->s,
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );

      if ( !strncmp( tree_object->server_list[ j ].server, "Virtual", 7 ))
         EZ_ConfigureItem( item,
                           EZ_LABEL_PIXMAP, tree_object->virtual_icon,
                           0 );
      else
         if ( !strncmp( tree_object->server_list[ j ].server, "Folders", 7 ))
            EZ_ConfigureItem( item,
                              EZ_LABEL_PIXMAP, tree_object->folder_icon,
                              0 );
         else
            if ( !strncmp( tree_object->server_list[ j ].server, 
                           "Mailboxes", 9 ))
               EZ_ConfigureItem( item,
                                 EZ_LABEL_PIXMAP, tree_object->inbox_icon,
                                 0 );
            else
               EZ_ConfigureItem( item,
                                 EZ_LABEL_PIXMAP, tree_object->news_icon,
                                 0 );

      if ( tree_object->parent != newsreader )
         EZ_ItemAddDnDDataDecoder( item, 
                                   NP_DND_GROUP_ADD_ATOM, 0,
                                   tree_object->dnd_add_decoder, tree_object,
                                   NULL, NULL );
      else
         EZ_ItemDeleteAllDnDDataDecoders( item );

      tree_object->server_nodes[ j ] = server_node
         = EZ_CreateTreeNode( root_node, item );

      k = tree_object->server_list[ j ].groups;
      while( k-- )
      {
         ++i;

         /*
          * skip Follow-ups groups if newsrc->tree_object 
          */

         if ( ( k == 0 || k == 1 ) && tree_object->parent != newsreader )
            continue;

         if ( tree_object->group_state[ i ] != NP_ACTIVE )
            continue;

         /*
          * determine group item colour 
          */

         if ( tree_object->parent != newsreader )
         {
            if ( j == newsrc->server )
               property = tree_object->highlight_prop;
            else
               property = tree_object->back_prop;
         }
         else
            if ( k == 1 && strncmp( tree_object->server_list[ j ].server,
                 "Virtual", 7 ))
            {
               if ( tree_object->group_list[ i ].total )
                  property = tree_object->read_prop;
               else
                  property = tree_object->none_prop;
            }
            else
               if ( tree_object->group_list[ i ].total )
                  property = (( tree_object->group_list[ i ].unread ) ? 
                                tree_object->unread_prop :
                                tree_object->read_prop );
               else
                  property = tree_object->none_prop;

         /*
          * Virtual and Folder groups have there names prepended by a colon
          * (:) to prevent namespace collisions with newsgroup spool files,
          * which use the newsgroup names as filenames. Colons are not
          * permitted in Usenet newsgroup names. Mailboxes have their
          * names prepended by two colons (::).
          */

         z = 0;
         pointer = tree_object->group_list[ i ].group;
         while( pointer[ z ] == ':' )
            ++pointer; 

         item = EZ_CreateLabelItem( pointer, property );

         /*
          * Client data used by various callbacks to determine which entry in
          * tree->group_list or tree->server_list corresponds to this display
          * item.
          */

         EZ_ConfigureItem( item,
                           EZ_TEXT_LINE_LENGTH, 120,
                           EZ_CLIENT_INT_DATA, i,
                           EZ_CLIENT_PTR_DATA, &tree_object->g,
                           0 );

         /*
          * If this tree object is newsrc->tree_object, then we can add groups
          * from the list of active groups by dragging and dropping them, and
          * we can reorder groups in the tree by dragging and dropping them.
          */

         if ( tree_object->parent != newsreader )
         {
            if ( j == newsrc->server )
            {
               EZ_ItemAddDnDDataEncoder( item, 
                                         NP_DND_GROUP_REORDER_ATOM, 0,
                                         tree_object->dnd_encoder, 
                                         tree_object,
                                         NULL, NULL );

               EZ_ItemAddDnDDataDecoder( item, 
                                         NP_DND_GROUP_REORDER_ATOM, 0,
                                         tree_object->dnd_reorder_decoder,
                                         tree_object,
                                         NULL, NULL );

               EZ_ItemAddDnDDataDecoder( item, 
                                         NP_DND_GROUP_ADD_ATOM, 0,
                                         tree_object->dnd_add_decoder,
                                         tree_object,
                                         NULL, NULL );
            }
         }

         /*
          * If this tree object is newsreader->tree_object, any folders in the
          * group tree can have articles copied to them via drag and drop.
          */
 
         else
            if ( !strncmp( tree_object->group_list[ i ].server, "Folders", 7 ))
               EZ_ItemAddDnDDataDecoder( item,
                                         NP_DND_FOLDERS_ATOM, 0,
                                         tree_object->dnd_folders_decoder,
                                         tree_object, NULL, NULL );

         /*
          * Keep a pointer to the group node for later use.
          */

         tree_object->group_nodes[ i ] = 
            group_node = EZ_CreateTreeNode( server_node, item );
      }
   }

   EZ_SetListTreeWidgetTree( tree_object->tree, root_node );

   return;
}

/*
 * If a newsgroup is clicked in the group tree, tell the summary object
 * to create a thread tree for the group.
 */

void tree_motion_callback( EZ_Widget *list_tree, void *tree_object )
{
   unsigned int i;

   np_tree_object *tree;
   np_newsreader_object *newsreader;
   np_summary_object *summary;
   np_buttons_object *buttons;
   np_message_object *message;

   EZ_TreeNode *selected;
   EZ_Item *item;


   tree = ( np_tree_object *)tree_object;
   newsreader = ( np_newsreader_object *)tree->newsreader;
   summary = ( np_summary_object *)newsreader->summary_object;
   message = ( np_message_object *)newsreader->message_object;
   buttons = ( np_buttons_object *)newsreader->buttons_object;

   buttons->selectively_disable_interface( buttons );

   if (( selected = EZ_GetListTreeWidgetSelection( list_tree )) == NULL )
      return;
   
   if ( selected == tree->root_node )
   {
      message->clear_message( message );
      EZ_SetListTreeWidgetTree( summary->thread_tree, NULL );

      if ( summary->summary_onscreen )
         EZ_FancyListBoxClear( summary->summary_list );

      return;
   }

   /*
    * servers 
    */

   item = EZ_TreeNodeGetItem( selected );
   if ( *( char *)EZ_GetItemPtrData( item ) == 's' )
   {
      EZ_SetListTreeWidgetTree( summary->thread_tree, NULL );
      message->clear_message( message );

      if ( summary->summary_onscreen )
         EZ_FancyListBoxClear( summary->summary_list );
      return;
   }

   i = EZ_GetItemIntData( item );

   summary->set_tree( summary, summary->thread_tree,
                      tree->group_list[ i ].group,
                      tree->group_list[ i ].total,
                      i );

   return;
}

/*
 * Collapses a server nodes subtree.
 */

void tree_collapse_server( void *this, unsigned int j )
{
   np_newsreader_object *newsreader;
   np_tree_object *tree;

   char *string, buffer[ LN_BUFFER_SIZE ];
   unsigned int i;
   int pos[ 2 ];

   EZ_Item *item;


   tree = ( np_tree_object *)this;
   newsreader = ( np_newsreader_object *)tree->newsreader;

   for( i = 0; i < tree->groups; ++i )
      if ( tree->group_list[ i ].server_idx == j )
         tree->group_state[ i ] ^= NP_ACTIVE;

   tree->server_state[ j ] ^= NP_SHOWN;

   if ( tree->server_state[ j ] == NP_NOT_SHOWN )
   {
      EZ_TreeDestroyNodeDescendants( tree->server_nodes[ j ] );
      if ( tree->server_list[ j ].groups )
      {
         item = EZ_TreeNodeGetItem( tree->server_nodes[ j ] );
         EZ_GetLabelItemStringInfo( item, &string, NULL );
         snprintf( buffer, LN_BUFFER_SIZE, "+ %s", string + 2 );
         EZ_ConfigureItem( item,
                           EZ_LABEL_STRING, buffer,
                           0 );
      }
   }
   else
   {
      tree->set_tree( tree );

      pos[ 0 ] = 25;
      pos[ 1 ] = 10;
      EZ_ListTreeWidgetSelectNode( tree->tree, tree->server_nodes[ j ], 
                                   pos );
   }

   return;
}

/*
 * Empty newsgroups have their tree nodes displayed in a medium grey type.
 * Newsgroups with unseen articles on file have their tree nodes displayed in
 * boldface black type. Newsgroups with articles on file, but with none
 * unseen, have their group nodes displayed in medium weight black type.
 */

void tree_update_node( void *this, EZ_Widget *list, np_group_state state )
{
   np_newsreader_object *newsreader;
   np_tree_object *tree;

   char *foreground, *font_name;


   tree = ( np_tree_object *)this;
   newsreader = ( np_newsreader_object *)tree->newsreader;

   switch( state )
   {
      case NP_EMPTY:
         foreground = tree->empty_colour;
         font_name = newsreader->medium_font;
         break;

      case NP_READ:
         foreground = tree->read_colour;
         font_name = newsreader->medium_font;
         break;

      case NP_UNREAD:
         foreground = tree->unread_colour;
         font_name = newsreader->bold_font;
         break;
   }

   EZ_ConfigureItem( EZ_TreeNodeGetItem( 
      EZ_GetListTreeWidgetSelection( list )),
                     EZ_FOREGROUND, foreground,
                     EZ_FONT_NAME, font_name,
                     0 );

   return;
}

/* 
 * If the user has double-clicked on a server node in the group tree, toggle
 * the server's subtree from the collapsed to the displayed state, or vice
 * versa.
 */

void tree_normal_callback( EZ_Widget *tree, void *this )
{
   np_tree_object *tree_object;
   np_newsreader_object *newsreader;
   np_summary_object *summary;
   np_message_object *message;

   EZ_TreeNode *node;
   unsigned int i, test;

   tree_object = ( np_tree_object *)this;
   newsreader = ( np_newsreader_object *)tree_object->newsreader;
   summary = ( np_summary_object *)newsreader->summary_object;
   message = ( np_message_object *)newsreader->message_object;

   node = EZ_GetListTreeWidgetSelection( tree );

   if ( node == tree_object->root_node )
   {
      test = 0;
      for( i = 0; i < tree_object->servers; ++i )
         if ( tree_object->server_list[ i ].groups )
            if ( tree_object->server_state[ i ] == tree_object->shown )
            {
               tree_object->collapse_server( tree_object, i );
               ++test;
            }

      if ( !test )
      {
         for( i = 0; i < tree_object->servers; ++ i )
            if ( tree_object->server_list[ i ].groups )
               tree_object->collapse_server( tree_object, i );
      }
      else
         if ( ( tree_object->shown ^= NP_SHOWN ) == NP_SHOWN )
         {
            int pos[ 2 ];
            pos[ 0 ] = 4;
            pos[ 1 ] = 4;
            EZ_ListTreeWidgetSelectNode( tree_object->tree, 
                                         tree_object->root_node, pos );
         }
   }
   else
   {
      for( i = 0; i < tree_object->servers; ++i )
         if ( tree_object->server_list[ i ].groups )
            if ( node == tree_object->server_nodes[ i ] )
            {
               tree_object->collapse_server( tree_object, i );
               EZ_SetListTreeWidgetTree( summary->thread_tree, NULL );
               break;
            }

      if ( i == tree_object->servers )
         return;
   }

   EZ_DisplayWidget( tree_object->tree );
   message->clear_message( message );

   return;
}

/*
 * Update tree data from configuration files.
 */

void tree_update_lists( void *tree_object )
{
   np_tree_object *tree;

   unsigned int i;
   

   tree = ( np_tree_object *)tree_object;

   /*
    * update tree_object 
    */

   tree->destroy_lists( tree->groups, tree->group_list,
                        tree->servers, tree->server_list );

   tree->groups = 0;
   tree->servers = 0;
   
   if ( ln_get_groups( &tree->groups, &tree->group_list,
                       &tree->servers, &tree->server_list ) == -1 ) 
      lib_error();

   if ( tree->parent == tree->newsreader )
   {
      if ( ln_get_virtual( &tree->groups, &tree->group_list,
                           &tree->servers, &tree->server_list ) == -1 )
         lib_error();

      if ( ln_get_inboxes( &tree->groups, &tree->group_list,
                           &tree->servers, &tree->server_list ) == -1 )
         lib_error();
      
      if ( ln_get_folders( &tree->groups, &tree->group_list,
                           &tree->servers, &tree->server_list ) == -1 )
         lib_error();
   }

   /*
    * server_nodes 
    */

   if ( tree->server_nodes != NULL )
   {
      free( tree->server_nodes );
      tree->server_nodes = NULL;
   }

   if ( tree->servers )
      if (( tree->server_nodes
            = calloc( tree->servers, sizeof *tree->server_nodes )) == NULL )
         fatal_error();

   /*
    * group_nodes 
    */

   if ( tree->group_nodes != NULL )
   {
      free( tree->group_nodes );
      tree->group_nodes = NULL;
   }

   if ( tree->groups )
      if (( tree->group_nodes 
            = calloc( tree->groups, sizeof *tree->group_nodes )) == NULL )
         fatal_error();

   /* 
    * server_state 
    */

   if ( tree->server_state != NULL )
   {
      free( tree->server_state );
      tree->server_state = NULL;
   }

   if ( tree->servers )
   {
      if (( tree->server_state
            = calloc( tree->servers, sizeof *tree->server_state )) == NULL )
         fatal_error();

      for( i = 0; i < tree->servers; ++ i )
         tree->server_state[ i ] = NP_SHOWN;
   }

   tree->shown = NP_SHOWN;

   /* 
    * node state 
    */

   if ( tree->group_state != NULL )
   {
      free( tree->group_state );
      tree->group_state = NULL;
   }

   if ( tree->groups )
   {
      if (( tree->group_state
            = calloc( tree->groups, sizeof *tree->group_state )) == NULL )
         fatal_error();

      for( i = 0; i < tree->groups; ++i )
         tree->group_state[ i ] = NP_ACTIVE;
   }

   return;
}

/*
 * Pass the client data for a tree node as a dnd message.
 */

int tree_dnd_encoder( EZ_Item *item, void *data, char **message,
                      int *length, int *needfree )
{
   np_tree_object *tree;

   char buffer[ 256 ], type[ 2 ], *temp;
   unsigned int position;


   tree = ( np_tree_object *)data;

   if (( temp = ( char *)EZ_GetItemPtrData( item )) != NULL )
      type[ 0 ] = *temp;
   else
      type[ 0 ] = '0';

   type[ 1 ] = '\0';

   position = EZ_GetItemIntData( item );
   if ( temp != NULL )
      position -= tree->group_list[ position ].server_idx * 2;
   else
      ++position;

   snprintf( buffer, LN_BUFFER_SIZE, "%s%d", type, position );

   *length = strlen( buffer ) + 1;

   if (( *message = strdup( buffer )) == NULL )
      fatal_error();

   *needfree = 1;

   return EZ_DND_SUCCESS;
}

/* 
 * Executed if the drop source was an item in the thread tree, and the drop
 * target was a folder node in the group tree.
 */

int tree_dnd_folders_decoder( EZ_Item *item, void *data, char *message,
                              int length )
{
   np_tree_object *tree;
   np_summary_object *summary;

   unsigned int i, t;
   char *string, buffer[ LN_BUFFER_SIZE ];


   tree = ( np_tree_object *)data;
   summary = ( np_summary_object *)
      (( np_newsreader_object *)tree->parent )->summary_object;

   i = ( unsigned int)atoi( message );
   EZ_GetLabelItemStringInfo( item, &string, NULL );
   snprintf( buffer, LN_BUFFER_SIZE, ":%s", string );

   if ( ln_file_article( summary->group_name, 
                         tree->group_list[ summary->group ].server,
                         i, buffer ) == -1 )
      lib_error();

   if ( ln_sort_spool( buffer ) == -1 )
      lib_error();
   if ( ln_thread_spool( buffer ) == -1 )
      lib_error();

   i = ( unsigned int)EZ_GetItemIntData( item );
   t = tree->group_list[ i ].total;

   tree->update_lists( tree );

   if ( !t )
      EZ_ConfigureItem( item,
                        EZ_FOREGROUND, tree->read_colour,
                        0 );

   return EZ_DND_SUCCESS;
}

/*
 * Executed if the drop source and targets were tree nodes in the group tree
 * in the newsrc object.
 */

int tree_dnd_reorder_decoder( EZ_Item *item, void *data, 
      char *message, int length )
{
   np_tree_object *tree;

   unsigned int target, old_target, source;


   tree = ( np_tree_object *)data;

   old_target = target = ( unsigned int)EZ_GetItemIntData( item );
   target -= tree->group_list[ target ].server_idx * 2;
   source = ( unsigned int)atoi( message + 1 );

   if ( target == source || target == source - 1 )
      return EZ_DND_FAILURE;

   if ( ln_move_group( target, source ) )
      lib_error();

   tree->dnd = (( source < old_target ) ? old_target : old_target + 1 );
   tree->add = 0;

   return EZ_DND_SUCCESS;
}

/* 
 * Executed if the drop source was an item in the fancy list box containing
 * the list of active groups for a server, in the newsrc object, and the drop
 * target is an item in the group tree of the newsrc object.
 */

int tree_dnd_add_decoder( EZ_Item *item, void *data, char *message, 
                          int length )
{
   np_tree_object *tree;
   np_newsrc_object *newsrc;

   char *string, buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ];
   unsigned int i;

   EZ_Item **selected;


   tree = ( np_tree_object *)data;
   newsrc = ( np_newsrc_object *)tree->parent;

   i = atoi( message + 1 );
   EZ_FancyListBoxSelectItemUsingIdx( newsrc->list, i, 0, NULL );
   if (( selected = EZ_GetFancyListBoxSelection( newsrc->list )) == NULL )
      return EZ_DND_FAILURE;

   EZ_GetLabelItemStringInfo( *selected, &string, NULL );
   strcpy( buffer, string );
   strtok( buffer, "\n" );

   if ( *( char *)EZ_GetItemPtrData( item ) == 'g' )
   {
      EZ_GetLabelItemStringInfo( item, &string, NULL );
      strcpy( second_buffer, string );

      if ( !strcmp( second_buffer, buffer ))
         return EZ_DND_FAILURE;

      if ( ln_add_group_behind( second_buffer, buffer ) )
         lib_error();
   }
   else
      if ( ln_add_group( tree->server_list[ newsrc->server ].server, buffer ) )
         lib_error();

   tree->dnd = EZ_GetItemIntData( item );
   tree->add = 1;

   return EZ_DND_SUCCESS;
}
