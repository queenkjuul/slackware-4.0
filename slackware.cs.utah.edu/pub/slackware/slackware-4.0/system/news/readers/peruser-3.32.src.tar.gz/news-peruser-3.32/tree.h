/*
 * Prototypes.
 */

void tree_init( void *this, void *parent, EZ_Widget *frame,
      void *newsreader );
void tree_set_tree( void *this );
void tree_destroy( void *this );
void tree_destroy_lists( unsigned int groups, ln_group_list *list,
                         unsigned int servers, ln_server_list *server_list );
void tree_update_lists( void *tree_object );
void tree_collapse_server( void *this, unsigned int server );
void tree_update_node( void *this, EZ_Widget *list, np_group_state state );
void tree_normal_callback( EZ_Widget *list_tree, void *this );
void tree_motion_callback( EZ_Widget *list_tree, void *this );
int tree_dnd_encoder( EZ_Item *item, void *data, char **message,
                      int *length, int *needfree );
int tree_dnd_reorder_decoder( EZ_Item *item, void *data, char *message, 
                              int length );
int tree_dnd_add_decoder( EZ_Item *item, void *data, char *message,
                          int length );
int tree_dnd_folders_decoder( EZ_Item *item, void *data, char *message,
                              int length );
