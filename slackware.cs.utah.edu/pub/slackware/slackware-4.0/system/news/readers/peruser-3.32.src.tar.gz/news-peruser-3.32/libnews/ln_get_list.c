/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "libnews.h"
#include<time.h>

/*
 * Write the current time to file.
 */

int ln_write_timestamp( char *server )
{
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ];

   FILE *file;

   time_t unix_time;
   struct tm *gmt;


   unix_time = time( NULL );
   gmt = gmtime( &unix_time );

   snprintf( buffer, LN_BUFFER_SIZE, "%2.2u%2.2u%2.2u %2.2u%2.2u%2.2u\n",
             gmt->tm_year, gmt->tm_mon + 1, gmt->tm_mday,
             gmt->tm_hour, gmt->tm_min, gmt->tm_sec );

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-TIMESTAMP", 
             getenv( "HOME" ), server );
   if (( file = fopen( second_buffer, "w" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_write_timestamp: could not open file %s.",
                buffer );
      return -1;
   }

   fputs( buffer, file );
   fclose( file );

   return 0;
}

/*
 * Retrieves a list of active newsgroups from a news server.
 */

int ln_get_list( FILE *server, char *name )
{
   char buffer[ LN_BUFFER_SIZE ], *home;
   FILE *list;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-LIST", 
             home = getenv( "HOME" ), name );
   if (( list = fopen( buffer, "w" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_get_list: could not open file: %s.",
                buffer );
      return -1;
   }

   fputs( "list\r\n", server );

   if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
   {
      fclose( list );
      if ( errno == ETIMEDOUT )
         return -1;

      strcpy( ln_error_message,
              "libnews: ln_get_list: connection terminated prematurely." );
      return -1;
   }

   if ( strncmp( buffer, "215", 3 ))
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_get_list: server response: %s.",
                buffer );
      fclose( list );
      return -1;
   }

   for( ; ; )
   {
      if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
      {
         fclose( list );
         if ( errno == ETIMEDOUT )
            return -1;

         strcpy( ln_error_message,
                 "libnews: ln_get_list: connected terminated prematurely." );
         return -1;
      }

      if ( buffer[ 0 ] == '.' && buffer[ 1 ] != '.' )
         break;

      fprintf( list, "%s\n", strtok( buffer, " " ));
   }

   fclose( list );

   if ( ln_write_timestamp( name ) )
      return -1;

   return 0;
}

/* 
 * Retrieves a list of active groups created after a specified time.
 */

int ln_get_newgroups( FILE *server, char *name )
{
   FILE *stamp_file, *list;
   char *home, buffer[ LN_BUFFER_SIZE ], timestamp[ 64 ];
   unsigned int count;


   count = 0;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-LIST", 
             home = getenv( "HOME" ), name );
   if (( list = fopen( buffer, "a" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_get_newgroups: could not open file: %s.",
                buffer );
      return -1;
   }

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s-TIMESTAMP", 
             home, name );
   if (( stamp_file = fopen( buffer, "r" )) == NULL )
      if ( errno != ENOENT )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_get_newgroups: could not open file %s.",
                   buffer );
         fclose( list );
         return -1;
      }
      else
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_get_newgroups: no timestamp file for %s.",
                   name );
         fclose( list );
         return -2;
      }

   if ( fgets( timestamp, 64, stamp_file ) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_get_newgroups: empty timestamp file for %s.",
                name );
      fclose( list );
      return -2;
   }

   fprintf( server, "newgroups %s GMT\r\n", strtok( timestamp, "\n" ));

   if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
   {
      fclose( list );
      if ( errno == ETIMEDOUT )
         return -1;

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_get_newgroups: "
                "connection terminated prematurely." );
      return -1;
   }

   if ( strncmp( buffer, "231", 3 ))
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_get_newgroups: server response: %s.",
                buffer );
      fclose( list );
      return -1;
   }

   for( ; ; )
   {
      if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
      {
         fclose( list );
         if ( errno == ETIMEDOUT )
            return -1;

         strcpy( ln_error_message,
                 "libnews: ln_get_list: connected terminated prematurely." );
         return -1;
      }

      if ( buffer[ 0 ] == '.' && buffer[ 1 ] != '.' )
         break;

      count++;

      fprintf( list, "%s\n", strtok( buffer, " " ));
   }

   fclose( list );

   if ( ln_write_timestamp( name ))
      return -1;

   if ( !count )
      return -3;

   return 0;
}

/*
 * Wrapper function. Sorts list of active newsgroups.
 */

int ln_sort_list( char *server )
{
   char buffer[ LN_BUFFER_SIZE ];


   snprintf( buffer, LN_BUFFER_SIZE, ".peruser_spool/%s-LIST", server );
   if ( ln_sort_file( buffer ))
      return -1;

   return 0;
}

/*
 * Sorts the newsgroups under a specified server in ~/.peruser3-newsrc.
 */

int ln_sort_server( char *server )
{
   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
   **array, *test, *home;
   FILE *newsrc, *temp;
   int length;
   unsigned int count, i;


   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", 
             home = getenv( "HOME" ));
   if (( newsrc = fopen( buffer, "r" )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_sort_server: could not open file %s.",
                buffer );
      return -1;
   }

   strcat( buffer, ".tmp" );
   if (( temp = fopen( buffer, "w" )) == NULL )
   {
      fclose( newsrc );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_sort_server: could not open file %s.",
                buffer );
      return -1;
   }

   length = strlen( server );

   while( ( test = fgets( buffer, LN_BUFFER_SIZE, newsrc )) != NULL )
      if ( !strncmp( buffer, server, length ))
         break;

   if ( test == NULL )
   {
      fclose( newsrc );
      fclose( temp );
      strcpy( ln_error_message,
              "libnews: ln_sort_server: "
              "no such server in ~/.peruser3-newsrc" );
      return -1;
   }

   count = 0;
   while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
   {
      if ( !isspace( buffer[ 0 ] ))
         break;

      ++count;
   }

   if (( array = calloc( count, sizeof *array )) == NULL )
      ln_allocation_error();

   rewind( newsrc );

   while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
      if ( !strncmp( buffer, server, length ))
         break;

   for( i = 0; i < count; ++i )
   {
      fgets( buffer, LN_BUFFER_SIZE, newsrc );

      if (( array[ i ]
               = malloc( strlen( buffer + ( length =
                                            strspn( buffer, " \t" )))))
            == NULL )
         ln_allocation_error();

      strcpy( array[ i ], strtok( buffer + length, "\n" ));
   }

   qsort( array, count, sizeof *array, ln_compare );

   rewind( newsrc );

   length = strlen( server );
   while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
   {
      fputs( buffer, temp );

      if ( !strncmp( buffer, server, length ))
         break;
   }

   for( i = 0; i < count; ++i )
   {
      fprintf( temp, "\t%s\n", array[ i ] );
      free( array[ i ] );
   }

   free( array );

   for( i = 0; i < count; ++i )
      fgets( buffer, LN_BUFFER_SIZE, newsrc );

   while( fgets( buffer, LN_BUFFER_SIZE, newsrc ) != NULL )
      fputs( buffer, temp );

   fclose( newsrc );
   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-newsrc", home );
   strcpy( second_buffer, buffer );
   strcat( second_buffer, ".tmp" );

   rename( second_buffer, buffer );

   return 0;
}
