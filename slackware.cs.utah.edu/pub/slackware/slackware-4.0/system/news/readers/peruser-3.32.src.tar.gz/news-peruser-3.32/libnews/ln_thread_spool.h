/*
 * Used to build linked list of Message-IDs from an article's References
 * header.
 */

typedef struct
{
   char *current_ref;

   void *next_ref;
   void *prev_ref;
}
ln_reference;

/*
 * Node definition for nodes in threading tree. After the list has been
 * created, the next_node and prev_node pointers traverse a doubly-linked list
 * of all nodes in spoolfile order. After threading, queue_head points to a
 * doubly-linked list of follow-up child nodes. queue_next and queue_prev
 * traverse child list, inside the list. Which is to say, a node may be both
 * part of another node's queue of children, and therefore have non-NULL
 * values for queue_next and/or queue_prev, and also have a queue of children
 * of its own, starting at the node pointed to by queue_head and ending at the
 * node pointed to by queue_tail.
 */

typedef struct { unsigned int position, gap, queue_count;

   char *message_id;
   ln_reference *references;

   enum{ no, yes }queued;

   void *queue_head;
   void *queue_tail;
   void *queue_next;
   void *queue_prev;

   void *next_node;
   void *prev_node;

} ln_node;

