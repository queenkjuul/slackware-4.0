/*
 *  News Peruser Copyright (c) 1996-1998 James Bailie
 *  ==================================================================
 *
 *  News Peruser is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as
 *  published by the Free Software Foundation; either version 2, or (at
 *  your option) any later version.
 *
 *  News Peruser is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  Although News Peruser is licensed under the Free Software
 *  Foundation's GNU General Public License, Peruser is not produced
 *  by, nor is it endorsed by the Free Software Foundation. The Free
 *  Software Foundation is not responsible for developing,
 *  distributing, or supporting Peruser in any way. Anyone may place
 *  software they own the copyright to, under the GNU General Public
 *  License.
 *
 *  The GNU General Public License is included in the News Peruser 
 *  distribution archive in a file called COPYING. If you do
 *  not have a copy of the license, you can download one from
 *  ftp://prep.ai.mit.edu, or you can write to the Free Software
 *  Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *  =====================================================================
 */

#include "libnews.h"

/*
 * Possible return values.
 */

#define UNCONFIGURED 15
#define PREMATURE_END 14
#define LN_GETS_FAILED 13
#define BAD_PASS 12
#define BAD_USER 11
#define TIMED_OUT 10
#define NO_CONFIG_FILE 9
#define BAD_INDEX 8
#define LN_GET_NEWGROUPS_FAILED 7
#define NO_TIMESTAMP 6
#define NO_NEW_GROUPS 5
#define LN_GET_LIST_FAILED 4
#define UNWELCOME 3
#define CONNECT_FAILED 2
#define INSUFFICIENT_ARGS 1

int main( int argc, char **argv )
{
   FILE *server, *config;
   char buffer[ LN_BUFFER_SIZE ], user[ LN_BUFFER_SIZE ], 
       pass[ LN_BUFFER_SIZE ], *tailptr = NULL;
   long int i;
   unsigned authenticate = 0;
   

   if ( argc < 4 )
      exit( INSUFFICIENT_ARGS );

   /* index of authentication info in ~/.peruser3-config */

   i = strtol( argv[ 2 ], &tailptr, 0 );
   if ( tailptr != NULL && !strcmp( tailptr, argv[ 2 ] ))
       exit( BAD_INDEX );

   /* open config */
   
   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config", getenv( "HOME" ));
   if (( config = fopen( buffer, "r" )) == NULL )
       exit( NO_CONFIG_FILE );

   /* advance past other info */
   
   if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
       exit( PREMATURE_END );
   
   if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
       exit ( PREMATURE_END );
   
   if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
       exit( PREMATURE_END );

   /* advance to server we want. */
   
   while( i-- )
   {
       if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
           exit( PREMATURE_END );
       
       if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
           exit( PREMATURE_END );
       
       if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
           exit( PREMATURE_END );
   }

   user[ 0 ] = '\0';
   pass[ 0 ] = '\0';
   
   /* authenticating? */
   
   if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
       exit( PREMATURE_END );
   
   if ( buffer[ 0 ] == '1' )
   {
       authenticate = 1;

       if ( fgets( user, LN_BUFFER_SIZE, config ) == NULL )
           exit( PREMATURE_END );

       if ( strtok( user, "\n" ) == NULL )
           exit( UNCONFIGURED );
       
       if ( fgets( pass, LN_BUFFER_SIZE, config ) == NULL )
           exit( PREMATURE_END );

       if ( strtok( pass, "\n" ) == NULL )
           exit( UNCONFIGURED );
   }

   fclose( config );

   /* connect */
   
   if ( ln_open_server( argv[ 1 ], &server, NULL, NULL ))
      exit( CONNECT_FAILED );

   if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
       if ( errno == ETIMEDOUT )
           exit( TIMED_OUT );
       else
           exit( LN_GETS_FAILED );
      
   if ( strncmp( buffer, "20", 2 ))
       exit( UNWELCOME );

   /* authenticate if necessary. */

   if ( authenticate )
   {
       snprintf( buffer, LN_BUFFER_SIZE, "authinfo user %s\r\n", user );
       fputs( buffer, server );
       if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
           if ( errno == ETIMEDOUT )
               exit( TIMED_OUT );
           else
               exit( LN_GETS_FAILED );

       if ( strncmp( buffer, "381", 3 ))
           exit( BAD_USER );
   
       snprintf( buffer, LN_BUFFER_SIZE, "authinfo pass %s\r\n", pass );
       fputs( buffer, server );
       if ( ln_fgets( buffer, LN_BUFFER_SIZE, server ) == NULL )
           if ( errno == ETIMEDOUT )
               exit( TIMED_OUT );
           else
               exit( LN_GETS_FAILED );
   
       if ( strncmp( buffer, "281", 3 ))
           exit( BAD_PASS );
   }

   /* request list */
   
   if ( !strncmp( argv[ 3 ], "list", 4 ))
   {
      if ( ln_get_list( server, argv[ 1 ] ))
          exit( LN_GET_LIST_FAILED );
   }
   else
      switch( ln_get_newgroups( server, argv[ 1 ] ))
      {
         case -3:
            exit( NO_NEW_GROUPS );
            break;

         case -2:
            exit( NO_TIMESTAMP );
            break;

         case -1:
            exit( LN_GET_NEWGROUPS_FAILED );
            break;

         default:
            break;
      }

   fclose( server );

   return 0;
}

