/*
 * Prototypes.
 */

void folders_init( void *parent );
void folders_list_motion_callback( EZ_Widget *widget, void *data );
void folders_update_list( void *this );
void folders_callback( EZ_Widget *widget, void *data );
int folders_verify( void *this, char *string );
void folders_persistent_callback( EZ_Widget *widget, void *data );
void folders_persistent_add_callback( EZ_Widget *widget, void *data );
void folders_persistent_replace_callback( EZ_Widget *widget, void *data );
void folders_persistent_remove_callback( EZ_Widget *widget, void *data );
void folders_persistent_motion_callback( EZ_Widget *widget, void *data );
void folders_persistent_sort_callback( EZ_Widget *widget, void *data );
void folders_update_persistent( void *this );
void folders_done_callback( EZ_Widget *widget, void *data );
void folders_sort_callback( EZ_Widget *widget, void *data );
void folders_add_callback( EZ_Widget *widget, void *data );
void folders_remove_callback( EZ_Widget *widget, void *data );
void folders_replace_callback( EZ_Widget *widget, void *data );
int folders_dnd_reorder_encoder( EZ_Item *item, void *data, char **message,
                                 int *length, int *needfree );
int folders_dnd_reorder_decoder( EZ_Item *item, void *data, char *message,
                                 int length );
