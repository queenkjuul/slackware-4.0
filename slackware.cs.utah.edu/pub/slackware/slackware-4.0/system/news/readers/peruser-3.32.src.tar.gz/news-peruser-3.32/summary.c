/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "peruser.h"
#include "summary.h"
#include<ctype.h>

/*
 * Constructor.
 */

void summary_init( void *this, void *parent )
{
   np_summary_object *summary;
   np_newsreader_object *newsreader;

   summary = ( np_summary_object *)this;
   newsreader = ( np_newsreader_object *)parent;

   summary->parent = parent;

   summary->update_summary = summary_update_summary;
   summary->create_local_times = summary_create_local_times;
   summary->contents_destroy = summary_contents_destroy;
   summary->show_stats = summary_show_stats;

   summary->clear_tree = summary_clear_tree;
   summary->set_tree = summary_set_tree;
   summary->tree_motion_callback = summary_tree_motion_callback;
   summary->tree_normal_callback = summary_tree_normal_callback;
   summary->update_tree = summary_update_tree;
   summary->dive_for_the_unseen = summary_dive_for_the_unseen;
   summary->dive_and_change_state = summary_dive_and_change_state;
   summary->dive_and_alter_threading = summary_dive_and_alter_threading;
   summary->dive_for_the_count = summary_dive_for_the_count;
   summary->hide_headers = summary_hide_headers;

   summary->recursively_descend_thread = summary_recursively_descend_thread;
   summary->toplevel_stack = summary_toplevel_stack;
   summary->create_missing_item = summary_create_missing_item;

   summary->destroy = summary_destroy;
   summary->callback  = summary_callback;

   summary->subject_callback = summary_subject_callback;
   summary->poster_callback = summary_poster_callback;
   summary->date_callback = summary_date_callback;
   summary->list_callback = summary_list_callback;
   summary->reorder = summary_reorder;
   summary->dnd_encoder = summary_dnd_encoder;
   summary->done_callback = summary_done_callback;

   summary->group_name = NULL;
   summary->group = 0;
   summary->contents = NULL;
   summary->root = NULL;
   summary->node_list = NULL;
   summary->node_state = NULL;

   summary->article_colour = "Black";
   summary->header_colour = "DarkRed";
   summary->requested_colour = "ForestGreen";

   summary->local_times = NULL;
   summary->positions = NULL;
   summary->summary_onscreen = 0;

   /*
    * stats 
    */

   summary->stats.total = 0;
   summary->stats.unread = 0;
   summary->stats.requests = 0;
   summary->stats.headers = 0;
   summary->stats.articles = 0;

   /*
    * thread tree 
    */

   summary->thread_tree 
      = EZ_CreateListTree( newsreader->top_frame, 1, 1 );

   EZ_SetHScrollbarDiscreteSpeed( summary->thread_tree, 10 );
   EZ_SetVScrollbarDiscreteSpeed( summary->thread_tree, 10 );

   EZ_ConfigureWidget( summary->thread_tree,
                       EZ_MOTION_CALLBACK, summary->tree_motion_callback,
                       summary,
                       EZ_CALLBACK, summary->tree_normal_callback, 
                       summary,
                       0 );

   return;
}

/*
 * Called when the summary panel is displayed.
 */

void summary_show_stats( void *this )
{
   np_summary_object *summary;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ], *pointer;
   

   summary = ( np_summary_object *)this;
   newsreader = ( np_newsreader_object *)summary->parent;

   pointer = summary->group_name;
   while( *pointer == ':' )
      ++pointer;
   
   snprintf( buffer, LN_BUFFER_SIZE, "%s:", 
             (( summary->group_name[ 0 ] == ':' ) ? summary->group_name + 1 :
              summary->group_name ),
             0 );

   EZ_ConfigureWidget( summary->group_label,
                       EZ_LABEL_STRING, buffer,
                       0 );

   snprintf( buffer, LN_BUFFER_SIZE, "total: %d    unseen: %d    "
             "articles: %d    headers: %d    requested: %d", 
             summary->stats.total, summary->stats.unread, 
             summary->stats.articles, summary->stats.headers, 
             summary->stats.requests );

   EZ_ConfigureWidget( summary->message_label,
                       EZ_LABEL_STRING, buffer, 
                       0 );

   return;
}

void summary_clear_tree( void *this )
{
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_summary_object *summary;

   EZ_Item *item;


   summary = ( np_summary_object *)this;
   newsreader = ( np_newsreader_object *)summary->parent;
   tree = ( np_tree_object *)newsreader->tree_object;

   item = EZ_CreateLabelItem( "Empty", tree->server_prop );
   summary->root = EZ_CreateTreeNode( NULL, item );

   EZ_SetListTreeWidgetTree( summary->thread_tree, summary->root );
   EZ_DisplayWidget( summary->thread_tree );

   return;
}

void summary_contents_destroy( ln_group_summary *contents, 
                               unsigned int total )
{
   unsigned int i;

   if ( !total || contents == NULL )
      return;

   for( i = 0; i < total; ++i )
   {
      if ( contents[ i ].subject != NULL )
         free( contents[ i ].subject );

      if ( contents[ i ].from != NULL )
         free( contents[ i ].from );

      if ( contents[ i ].date != NULL )
         free( contents[ i ].date );

      if ( contents[ i ].message_id != NULL )
         free( contents[ i ].message_id );
   }

   free( contents );
   
   return;
}

void summary_hide_headers( void *this )
{
   np_summary_object *summary;
   np_newsreader_object *newsreader;

   ln_group_summary *new_contents;
   unsigned int i, j, k;


   summary = ( np_summary_object *)this;
   newsreader = ( np_newsreader_object *)summary->parent;

   j = summary->stats.total;

   /*
    * hide the appropriate nodes.
    */

   for( i = 0; i < summary->stats.total; ++i )
      if ( !summary->contents[ i ].is_article && newsreader->hide_headers )
      {
         --j;
         summary->node_state[ i ] = NP_INACTIVE;
         summary->stats.headers--;
      }
      else
         if ( !summary->contents[ i ].is_unread && newsreader->hide_seen )
         {
            --j;
            summary->node_state[ i ] = NP_INACTIVE;
            summary->stats.unread--;
         }
         else
            summary->node_state[ i ] = NP_ACTIVE;

   /*
    * Modify the threading information.
    */

   for( i = 0; i < summary->stats.total; ++i )
      if ( summary->node_state[ i ] == NP_INACTIVE )
         if ( !summary->contents[ i ].threading )
            summary->dive_and_alter_threading( summary, i, 1 );

   /*
    * Create a replacement contents list.
    */

   if (( new_contents = calloc( j, sizeof *new_contents )) == NULL )
      fatal_error();

   if ( summary->node_list != NULL )
      free( summary->node_list );

   if (( summary->node_list = calloc( j, sizeof *summary->node_list )) == NULL )
      fatal_error();

   k = 0;
   for( i = 0; i < j; ++i )
   {
      while( summary->node_state[ k ] == NP_INACTIVE )
         ++k;

      /*
       * Structure assignment.
       */

      new_contents[ i ] = summary->contents[ k ];

      /*
       * Must duplicate the dynamically allocated parts of structure as the
       * upcoming call to summary->contents_destroy will free the
       * originals.
       */

      if (( new_contents[ i ].subject 
               = strdup( summary->contents[ k ].subject )) == NULL )
         fatal_error();

      if (( new_contents[ i ].date
               = strdup( summary->contents[ k ].date )) == NULL )
         fatal_error();

      if (( new_contents[ i ].from
               = strdup( summary->contents[ k ].from )) == NULL )
         fatal_error();

      if (( new_contents[ i ].message_id 
               = strdup( summary->contents[ k ].message_id )) == NULL )
         fatal_error();

      ++k;
   }

   summary->contents_destroy( summary->contents, summary->stats.total );
   summary->contents = NULL;
   
   summary->stats.total = j;
   summary->contents = new_contents;

   if ( summary->node_state != NULL )
      free( summary->node_state );

   if (( summary->node_state = calloc( j, sizeof *summary->node_state )) 
         == NULL )
      fatal_error();

   return;
}

void summary_set_tree( void *this, EZ_Widget *tree, char *group_name, 
                       unsigned int total, unsigned int group )
{
   EZ_Item *item;
   EZ_TextProperty *property;

   np_summary_object *summary;
   np_newsreader_object *newsreader;
   np_message_object *message;
   np_tree_object *tree_object;
   np_buttons_object *buttons;
   np_edit_object *edit;

   unsigned int i, j, z;
   char *pointer;


   summary = ( np_summary_object *)this;
   newsreader = ( np_newsreader_object *)summary->parent;
   message = ( np_message_object *)newsreader->message_object;
   tree_object = ( np_tree_object *)newsreader->tree_object;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   edit = ( np_edit_object *)buttons->edit_object;

   /*
    * Destroy the previously-selected group's data.
    */

   summary->group = group;

   if ( summary->group_name != NULL )
      free( summary->group_name );

   if (( summary->group_name = strdup( group_name )) == NULL )
      fatal_error();

   if ( summary->contents != NULL )
   {
      summary->contents_destroy( summary->contents, summary->stats.total );
      summary->contents = NULL;
   }
   
   if ( total )
      if (( summary->contents = calloc( total, sizeof *summary->contents ))
          == NULL )
         fatal_error();

   if ( summary->node_list != NULL )
   {
      free( summary->node_list );
      summary->node_list = NULL;
   }

   if ( summary->node_state != NULL )
   {
      free( summary->node_state );
      summary->node_state = NULL;
   }

   summary->old_total = summary->stats.total;

   /*
    * Get the currently-selected group's data.
    */

   switch( ln_get_group_summary( group_name, 
            tree_object->group_list[ summary->group ].server,
                                 &summary->stats, 
                                 &summary->contents ))
   {
      case -2:
         message->clear_message( message );
         summary->clear_tree( summary  );
         if ( summary->summary_onscreen )
            summary->update_summary( summary );
         return;
         break;

      case -1:
         lib_error();
         break;

      default:
         /*
          * Update summary list if it's onscreen, else remove the 
          * local_times list, as it is no longer current.
          */

         if ( summary->summary_onscreen )
         {
            summary->update_summary( summary );
            summary->show_stats( summary );
         }
         else
            if ( summary->local_times != NULL )
            {
               if ( summary->positions != NULL )
               {
                  free( summary->positions );
                  summary->positions = NULL;
               }

               for( i = 0; i < summary->old_total; ++i )
                  if ( summary->local_times[ i ] != NULL )
                     free( summary->local_times[ i ] );

               free( summary->local_times );
               summary->local_times = NULL;
            }
         break;
   }

   /*
    * Create the root node.
    */

   property = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font,
                                  EZ_FOREGROUND, summary->article_colour,
                                  0 );

   pointer = summary->group_name;

   z = 0;
   while( pointer[ z ] == ':' )
      ++pointer;

   item = EZ_CreateLabelItem( pointer, property );

   EZ_ConfigureItem( item,
                     EZ_TEXT_LINE_LENGTH, 120,
                     0 );

   summary->root = EZ_CreateTreeNode( NULL, item );

   /*
    * Create the state list.
    */

   if (( summary->node_state = calloc( summary->stats.total,
                                       sizeof *summary->node_state )) 
         == NULL )
      fatal_error();

   /*
    * Hide headers, hide seen, if toggled.
    */

   if ( strncmp( tree_object->group_list[ summary->group ].group, 
                 "Follow-ups", 10 ))
   {
      if ( newsreader->hide_seen || newsreader->hide_headers )
         summary->hide_headers( summary );

      if ( !summary->stats.total )
      {
         EZ_SetListTreeWidgetTree( summary->thread_tree, summary->root );
         EZ_DisplayWidget( tree );
         message->clear_message( message );
         return;
      }
   }

   /*
    * Create the node list.
    */

   if (( summary->node_list = calloc( summary->stats.total, 
         sizeof *summary->node_list )) == NULL )
      fatal_error();

   /*
    * Collapse threads.
    */

   if ( strncmp( tree_object->group_list[ summary->group ].group, 
                 "Follow-ups", 10 ))
   {
      for( i = 0; i < summary->stats.total; ++i )
      {
         if ( summary->contents[ i ].threading )
         {
            summary->node_state[ i ] = NP_INACTIVE;
            continue;
         }

         summary->node_state[ i ] = NP_ACTIVE;

         if ( summary->contents[ i ].queue )
         {
            j = i;
            while( j < summary->stats.total - 1 &&
                  summary->contents[ ++j ].threading )
               summary->node_state[ j ] = NP_INACTIVE;
            i = --j;
         }
      }

      /*
       * Hide siblings.
       */

      for( i = 0; i < summary->stats.total - 1; ++i )
      {
         if ( summary->contents[ i ].threading )
            continue;

         j = i;

         while( ++j < summary->stats.total &&
               summary->contents[ j ].threading );

         if ( j < summary->stats.total &&
               !strcmp( summary->contents[ i ].subject,
                  summary->contents[ j ].subject ))
         {
            summary->contents[ j ].is_sibling = 1;
            summary->node_state[ j ] = NP_INACTIVE;
            i = --j;
         }
      }
   }
   else
      for( i = 0; i < summary->stats.total; ++i )
         summary->node_state[ i ] = NP_ACTIVE;

   /* Create the nodes */

   summary->update_tree( summary, tree );

   /* Clear the text widgets */

   message->clear_message( message );

   return;
}

/*
 * Used to keep track of current higher-level node in thread tree, as
 * summary_recursively_descend_thread works its way downward.
 */

void summary_toplevel_stack( np_toplevel *toplevel, np_stack_op what )
{
   static np_toplevel *base = NULL;
   static unsigned int count = 0;

   if ( what == NP_CLEAN )
   {
      if ( base != NULL )
         free( base );

      count = 0;
      base = NULL;
      return;
   }

   if ( what == NP_PUSH )
   {
      if ( base == NULL )
      {
         if (( base = malloc( sizeof *base )) == NULL )
            fatal_error();

         ++count;
      }
      else
      {
         ++count;

         if (( base = realloc( base, count * ( sizeof *base ))) == NULL )
            fatal_error();
      }

      base[ count - 1 ].threading = toplevel->threading;
      base[ count - 1 ].node = toplevel->node;
   }
   else
   {
      if ( !count )
         return;

      toplevel->threading = base[ --count ].threading;
      toplevel->node = base[ count ].node;

      if (( base = realloc( base, count * ( sizeof *base ))) == NULL )
         fatal_error();

      if ( !count )
         base = NULL;
   }

   return;
}

/*
 * Creates nodes for missing articles in the thread tree.
 */

void summary_recursively_descend_thread( void *this, unsigned int depth,
                                         np_toplevel *toplevel, EZ_Item *item,
                                         EZ_TreeNode **node_list )
{
   np_summary_object *summary;
   np_newsreader_object *newsreader;


   summary = ( np_summary_object *)this;
   newsreader = ( np_newsreader_object *)summary->parent;

   if ( depth )
   {
      summary->toplevel_stack( toplevel, NP_PUSH );

      toplevel->node
         = EZ_CreateTreeNode( toplevel->node,
                              summary->create_missing_item( newsreader ));
      toplevel->threading += 1;

      summary->recursively_descend_thread( summary, depth - 1, toplevel, item,
                                           node_list );
   }
   else
      *node_list = EZ_CreateTreeNode( toplevel->node, item );

   return;
}

EZ_Item *summary_create_missing_item( np_newsreader_object *newsreader )
{
   return EZ_CreateLabelItem( "(missing article)", 
                              EZ_GetTextProperty( EZ_FONT_NAME,
                                                  newsreader->medium_font,
                                                  0 ));
}

/*
 * Destructor.
 */

void summary_destroy( void *this )
{
    unsigned int i;
    np_summary_object *summary;


    summary = ( np_summary_object *)this;

    if ( summary->group_name != NULL )
        free( summary->group_name );

    if ( summary->contents != NULL )
    {
       summary->contents_destroy( summary->contents, summary->stats.total );
       summary->contents = NULL;
    }
    
    if ( summary->local_times != NULL )
    {
        for( i = 0; i < summary->stats.total; ++i )
            if ( summary->local_times[ i ] != NULL )
                free( summary->local_times[ i ] );

        free( summary->local_times );
    }

    if ( summary->positions != NULL )
        free( summary->positions );

    if ( summary->node_list != NULL )
        free( summary->node_list );

    if ( summary->node_state != NULL )
        free( summary->node_state );

    if ( ln_convert_date( NULL, NULL ))
        lib_error();

    return;
}

/*
 * If a node in the thread tree is clicked, tells the message object
 * to load the corresponding article text.
 */

void summary_tree_motion_callback( EZ_Widget *tree, void *data )
{
   np_summary_object *summary;
   np_newsreader_object *newsreader;
   np_message_object *message;
   np_tree_object *tree_object;

   EZ_TreeNode *selected;
   ln_group_summary *pointer;

   unsigned int i, j, k;
   char *group, buffer[ LN_BUFFER_SIZE ];

   summary = ( np_summary_object *)data;
   newsreader = ( np_newsreader_object *)summary->parent;
   message = ( np_message_object *)newsreader->message_object;
   tree_object = ( np_tree_object *)newsreader->tree_object;

   if (( selected = EZ_GetListTreeWidgetSelection( tree )) == summary->root )
      return;

   for( i = 0; i < summary->stats.total; ++i )
      if ( selected == summary->node_list[ i ] )
         break;

   if ( i == summary->stats.total )
   {
      message->clear_message( message );
      return;
   }

   if ( summary->summary_onscreen )
   {
      j = i + 1;

      for( k = 0; k < summary->stats.total; ++k )
         if ( summary->positions[ k ] == j )
            break;

      EZ_FancyListBoxSelectItemUsingIdx( summary->summary_list, ++k, 0, NULL );
   }

   pointer = summary->contents;

   /*
    * If node is unseen, mark it seen and redisplay it.
    */

   if ( pointer[ i ].is_unread )
   {
      if ( pointer[ i ].has_ref_requests )
         EZ_ConfigureItem( EZ_TreeNodeGetItem( selected ),
                           EZ_FONT_NAME, newsreader->italic_font,
                           0 );
      else
         EZ_ConfigureItem( EZ_TreeNodeGetItem( selected ),
                           EZ_FONT_NAME, newsreader->medium_font,
                           0 );

      if ( ln_mark_read( summary->group_name, pointer[ i ].ordinal ))
         lib_error();

      pointer[ i ].is_unread = 0;
      summary->stats.unread--;

      if ( !summary->stats.unread )
         newsreader->tree_object->update_node( newsreader->tree_object,
                                               newsreader->tree_object->tree,
                                               NP_READ );

      tree_object->group_list[ summary->group ].unread--;
   }

   /* 
    * Expand the group name of Follow-ups or Posted folders into their
    * corresponding spool filenames.
    */

   if ( !strncmp( summary->group_name, "Follow-ups", 10 ))
   {
      snprintf( buffer, LN_BUFFER_SIZE, "%s-FOLLOW-UPS", 
                tree_object->group_list[ summary->group ].server );
      group = buffer;
   }
   else
      if ( !strncmp( summary->group_name, "Posted", 6 ))
      {
         snprintf( buffer, LN_BUFFER_SIZE, "%s-POSTED",
                   tree_object->group_list[ summary->group ].server );
         group = buffer;
      }
      else  
         group = summary->group_name;

   message->set_message( message, group, pointer[ i ].is_article,
                         pointer[ i ].offset, pointer[ i ].size );

   if ( summary->summary_onscreen )
      summary->show_stats( summary );

   return;
}

/*
 * Updates info presented in the fancy listbox on the summary panel.
 */

void summary_update_summary( void *this )
{
   np_summary_object *summary;

   unsigned int i;


   summary = ( np_summary_object *)this;

   EZ_FancyListBoxClear( summary->summary_list );

   if ( summary->positions != NULL )
   {
      free( summary->positions );
      summary->positions = NULL;
   }

   if ( summary->local_times != NULL )
   {
      for( i = 0; i < summary->old_total; ++i )
         if ( summary->local_times[ i ] != NULL )
             free( summary->local_times[ i ] );

      free( summary->local_times );
      summary->local_times = NULL;
   }

   if ( summary->stats.total )
   {
      summary->create_local_times( summary );

      switch( EZ_GetRadioButtonGroupVariableValue( summary->subject_button ))
      {
         case NP_SUBJECT:
            summary->reorder( NP_SUBJECT, summary );
            break;

         case NP_POSTER:
            summary->reorder( NP_POSTER, summary );
            break;

         case NP_DATE:
            summary->reorder( NP_DATE, summary );
            break;
      }
   }

   return;
}

/* 
 * Converts Date headers into local time for the summary panel fancy
 * list box.
 */

void summary_create_local_times( void *this )
{
    np_summary_object *summary;
    np_newsreader_object *newsreader;
    np_newsrc_object *newsrc;
    np_search_object *search;

    ln_group_summary *pointer;

    EZ_Item *items[ 3 ];
    EZ_TextProperty *property;

    unsigned int i;


    summary = ( np_summary_object *)this;
    newsreader = ( np_newsreader_object *)summary->parent;
    search = ( np_search_object *)newsreader->buttons_object->search_object;
    newsrc = ( np_newsrc_object *)newsreader->buttons_object->newsrc_object;

    if ( summary->local_times != NULL )
    {
        for( i = 0; i < summary->old_total; ++i )
            if ( summary->local_times[ i ] != NULL )
                free( summary->local_times[ i ] );

        free( summary->local_times );
    }

    if (( summary->local_times = calloc( summary->stats.total, 
                                         sizeof *summary->local_times )) 
            == NULL )
        fatal_error();

    property = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font,
                                   0 );

    items[ 0 ] = EZ_CreateLabelItem( "Converting date", property );
    items[ 1 ] = EZ_CreateLabelItem( "headers to local", property );
    items[ 2 ] = EZ_CreateLabelItem( "time...", property );

    EZ_SetFancyListBoxHeader( summary->summary_list, items, 3 );
    EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));
    if ( search->search_onscreen )
        EZ_WaitCursor( search->search_frame, EZ_GetCursor( XC_watch ));
    XFlush( EZ_GetDisplay() );

    pointer = summary->contents;
    for( i = 0; i < summary->stats.total; ++i )
        if ( ln_convert_date( pointer[ i ].date, &summary->local_times[ i ] ))
            lib_error();

    EZ_NormalCursor( newsreader->app_frame );
    if ( search->search_onscreen )
        EZ_NormalCursor( search->search_frame );
    XFlush( EZ_GetDisplay() );

    return;
}

/*
 * Descend thread queues to determine if a node has any unseen (grand)children
 * in any successive generation.
 */

unsigned int summary_dive_for_the_unseen( void *this, unsigned int i, 
                                          unsigned int *unread )
{
   np_summary_object *summary;

   unsigned int j, k, l, m, count;


   summary = ( np_summary_object *)this;

   if ( !( j = summary->contents[ i ].queue ))
      return ( unsigned int )0;

   l = count = 0;
   for( k = 1; k <= j; ++k )
   {
      ++l;

      if ( summary->contents[ i + l ].is_unread )
         ++( *unread );

      m = summary_dive_for_the_unseen( this, i + l, unread );
      l += m;
      count += m;
   }

   return j + count;
}

/*
 * Descend thread trees to decrease node threading info of all (grand)children
 * in every successive generation by specified amount. Used to alter threading
 * information when hide_seen or hide_headers is active.
 */

unsigned int summary_dive_and_alter_threading( void *this, 
                                               unsigned int i, char top )
{
   np_summary_object *summary;

   unsigned int j, k, l, m, count, gap;


   summary = ( np_summary_object *)this;

   if ( !( j = summary->contents[ i ].queue ))
      return ( unsigned int)0;

   l = count = 0;
   for( k = 0; k < j; ++k )
   {
      ++l;

      if ( top && ( gap = summary->contents[ i + l ].threading - 1 ))
         summary->contents[ i + l ].threading -= gap;
      else
         summary->contents[ i + l ].threading--;

      m = summary_dive_and_alter_threading( this, i + l, 0 );
      l += m;
      count += m;
   }

   return j + count;
}

/*
 * Descend thread trees recursively toggling the state of all (grand)child
 * nodes in every successive generation.
 */

unsigned int summary_dive_and_change_state( void *this, unsigned int i,
                                            np_node_state state )
{
   np_summary_object *summary;

   unsigned int j, k, l, m, count;


   summary = ( np_summary_object *)this;

   if ( !( j = summary->contents[ i ].queue ))
      return ( unsigned int)0;

   l = count = 0;
   for( k = 0; k < j; ++k )
   {
      ++l;
      summary->node_state[ i + l ] = state;
      if ( summary->node_state[ i + l ] == NP_INACTIVE )
         summary->node_list[ i + l ] = NULL;

      m = summary_dive_and_change_state( this, i + l, state );
      l += m;
      count += m;
   }

   return j + count;
}

/*
 * Descend thread trees to count all nodes descended from the passed node.
 */

unsigned int summary_dive_for_the_count( void *this, unsigned int i )
{
   np_summary_object *summary;

   unsigned int j, k, l, m, count;
   
   summary = ( np_summary_object *)this;

   if ( !( j = summary->contents[ i ].queue ))
      return ( unsigned int)0;

   l = count = 0;
   for( k = 0; k < j; ++k )
   {
      ++l;

      m = summary_dive_for_the_count( summary, i + l );
      l += m;
      count += m;
   }

   return count + j;
}


/*
 * If the root node of a thread subtree was double-clicked in the thread tree,
 * then toggle it from the collapsed to the shown state, or vice versa.
 */

void summary_tree_normal_callback( EZ_Widget *tree, void *data )
{
   np_summary_object *summary;
   np_message_object *message;

   np_node_state what;
   int pos[ 2 ];
   unsigned int i, j, total, test;

   EZ_TreeNode *selected;

   summary = ( np_summary_object *)data;
   message = (( np_newsreader_object *)summary->parent )->message_object;

   if (( selected = EZ_GetListTreeWidgetSelection( tree )) == summary->root )
      return;

   i = ( unsigned int )EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));

   /*
    * Toggle any sibling nodes on/off.
    */

   total = summary->stats.total;

   if ( i < total && 
        !summary->contents[ i ].threading &&
        !summary->contents[ i ].is_sibling )
   {
      j = i;
      do
      {
         while( ++j < total && summary->contents[ j ].threading );

         while( j < total && summary->contents[ j ].is_sibling )
         {
           summary->node_state[ j ] ^= 1;
           if ( summary->node_state[ j ] == NP_INACTIVE )
              summary->node_list[ j ] = NULL;

           summary->dive_and_change_state( summary, j,
                                           summary->node_state[ j ] );
           ++j;
         }
      }
      while( j < total && summary->contents[ j ].threading );
   }

   /*
    * Toggle any child nodes on/off.
    */

   if (( test = summary->contents[ i ].queue ))
   {
      what = (( summary->node_state[ i + 1 ] ) ? NP_INACTIVE : NP_ACTIVE ); 
      summary->dive_and_change_state( summary, i, what );
   }

   summary->update_tree( summary, tree );

   EZ_GetWidgetDimension( tree, &pos[ 0 ], &pos[ 1 ] );
   pos[ 0 ] = 25;
   pos[ 1 ] /= 4;

   EZ_ListTreeWidgetSelectNode( tree, summary->node_list[ i ], pos );

   return;
}

/*
 * Called by summary_set_tree to create the thread tree nodes.
 */

void summary_update_tree( void *this, EZ_Widget *tree )
{
   np_summary_object *summary;
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;
   np_tree_object *tree_object;

   ln_group_summary *pointer;

   long int test;
   unsigned int i, j, total, count, unread;
   char *foreground, *font, buffer[ LN_BUFFER_SIZE ], little_buffer[ 25 ];

   EZ_TextProperty *property;
   EZ_Item *item;
   np_toplevel toplevel;


   summary = ( np_summary_object *)this;
   newsreader = ( np_newsreader_object *)summary->parent;
   tree_object = ( np_tree_object *)newsreader->tree_object;
   buttons = ( np_buttons_object *)newsreader->buttons_object;

   toplevel.node = summary->root;
   toplevel.threading = 0;

   EZ_TreeDestroyNodeDescendants( summary->root );

   pointer = summary->contents;

   /*
    * Create nodes.
    */

   for( i = 0; i < summary->stats.total; ++i )
   {
      if ( summary->node_state[ i ] == NP_INACTIVE )
         continue;

      /*
       * Determine node colour.
       */

      if ( pointer[ i ].is_article )
         foreground = summary->article_colour;
      else
         foreground
            = (( pointer[ i ].is_requested ) ? summary->requested_colour :
                 summary->header_colour );

      /* 
       * Determine node font.
       */

      if ( pointer[ i ].has_ref_requests )
         font = (( pointer[ i ].is_unread ) ?
                 newsreader->bold_italic_font : newsreader->italic_font );
      else
         font = (( pointer[ i ].is_unread ) ? 
                 newsreader->bold_font : newsreader->medium_font );

      property = EZ_GetTextProperty( EZ_FONT_NAME, font,
                                     EZ_FOREGROUND, foreground,
                                     0 );

      /*
       * Determine if node has children.
       */

      if ( pointer[ i ].queue )
      {
         int count;

         if ( summary->node_state[ i + 1 ] == NP_INACTIVE )
         {
            snprintf( buffer, LN_BUFFER_SIZE, "+%d ", 
                      summary->dive_for_the_count( summary, i ));

            count = 0;
            summary->dive_for_the_unseen( summary, i, &count );
            if ( count )
            {
               snprintf( little_buffer, 25, "%dU ", count );
               strcat( buffer, little_buffer );
            }
         }
         else
            strcpy( buffer, "- " );
      }
      else
         buffer[ 0 ] = '\0';

      /*
       * Indicate if node has been marked for deletion.
       */

      if ( pointer[ i ].delete )
         strcat( buffer, "D " );

      /*
       * Indicate if node has hidden toplevel siblings.
       */

      unread = 0;
      total = summary->stats.total;
      if ( i < total - 1 && 
           !pointer[ i ].is_sibling &&
           !pointer[ i ].threading )
      {
         count = 0;
         j = i;

         do
         {
            while( ++j < total && pointer[ j ].threading );
                        
            if ( summary->node_state[ j ] == NP_ACTIVE )
               break;

            while( j < total && pointer[ j ].is_sibling )
            {
               if ( pointer[ j ].is_unread )
                  ++unread;

               ++count;
               ++j;
            }
         }
         while( j < total && pointer[ j ].threading );

         if ( count )
         {
            snprintf( little_buffer, 25, "(%d", count );
            strcat( buffer, little_buffer );
            if ( unread )
            {
               snprintf( little_buffer, 25, " %dU) ", unread );
               strcat( buffer, little_buffer );
            }
            else
               strcat( buffer, ") " );
         }
      }

      /*
       * Add Subject header.
       */

      strcat( buffer, pointer[ i ].subject );

      item = EZ_CreateLabelItem( buffer, property );

      EZ_ConfigureItem( item,
                        EZ_TEXT_LINE_LENGTH, 120,
                        EZ_CLIENT_INT_DATA, i,
                        0 );

      /*
       * Articles may be added to a user-defined folder by dragging and
       * dropping their thread tree nodes onto the folder node in the group
       * tree.
       */

      EZ_ItemAddDnDDataEncoder( item, NP_DND_FOLDERS_ATOM, 0,
                                summary->dnd_encoder, summary, NULL, NULL );

      /* 
       * If the current article has no follow-ups, make it a child of the root
       * node.
       */

      if ( !pointer[ i ].threading )
      {
         summary->node_list[ i ] = EZ_CreateTreeNode( summary->root, item );

         toplevel.node = summary->node_list[ i ];
         toplevel.threading = pointer[ i ].threading;
      }

      /*
       * Otherwise, compare how many levels deep we are in the current thread
       * with the last toplevel node. If the result is negative, we need to 
       * pop up out of this subtree and attatch ourselves to higher level
       * node.
       */

      else
      {
         if ( ( test = pointer[ i ].threading - toplevel.threading ) < 0 )
         {
            while( test++ )
               summary->toplevel_stack( &toplevel, NP_POP );

            if ( pointer[ i ].threading == toplevel.threading )
               summary->toplevel_stack( &toplevel, NP_POP );

            summary->node_list[ i ] = EZ_CreateTreeNode( toplevel.node, item );
         }

         /*
          * If the test was positive, create nodes for any missing articles,
          * and attatch ourselves.
          */

         else
            if ( test > 1 )
               summary->recursively_descend_thread( summary, test - 1,
                                                    &toplevel, item,
                                                    &summary->node_list[ i ] );
            else
            {
               if ( !test )
                  summary->toplevel_stack( &toplevel, NP_POP );

               summary->node_list[ i ] = EZ_CreateTreeNode( toplevel.node, 
                                                            item );
            }

         /*
          * If we have follow-ups, make us the new toplevel node for this
          * thread subtree.
          */

         if ( pointer[ i ].queue )
         {
            summary->toplevel_stack( &toplevel, NP_PUSH );

            toplevel.node = summary->node_list[ i ];
            toplevel.threading = pointer[ i ].threading;
         }
      }
   }

   /*
    * Destroy the stack.
    */

   summary->toplevel_stack( NULL, NP_CLEAN );

   EZ_SetListTreeWidgetTree( tree, summary->root );
   EZ_DisplayWidget( tree );

   return;
}

/*
 * Destroy and clean up after the summary panel.
 */

void summary_done_callback( EZ_Widget *widget, void *data )
{
   np_summary_object *summary;

   summary = ( np_summary_object *)data;

   EZ_DestroyWidget( summary->summary_frame );

   if ( summary->positions != NULL )
   {
      free( summary->positions );
      summary->positions = NULL;
   }

   summary->summary_onscreen = 0;

   return;
}

/*
 * Re-sort the data in the Fancy list box of the summary panel, and
 * re-display.
 */

void summary_reorder( np_order order, void *data )
{
   char *buffer, *foreground, *font;
   np_summary_object *summary;
   np_newsreader_object *newsreader;

   ln_group_summary *pointer;

   EZ_TextProperty *property[ 4 ];
   EZ_Item **items;

   struct {
      char *first;
      char *second;
      char *third;
      unsigned int position;
      unsigned is_article;
      unsigned is_requested;
      unsigned is_unread;
   } *array;

   unsigned int i, j, k, items_size;


   summary = ( np_summary_object *)data;
   newsreader = ( np_newsreader_object *)summary->parent;

   if ( !summary->stats.total )
      return;

   if ( order != NP_SUBJECT )
   {
      if (( array = calloc( summary->stats.total, sizeof *array )) == NULL )
         fatal_error();

      pointer = summary->contents;
      for( i = 0; i < summary->stats.total; ++i )
      {
         array[ i ].position = pointer[ i ].ordinal;
         array[ i ].is_article = pointer[ i ].is_article;
         array[ i ].is_unread = pointer[ i ].is_unread;
         array[ i ].is_requested = pointer[ i ].is_requested;

         switch( order )
         {
            case NP_DATE:
               if (( array[ i ].first = strdup( summary->local_times[ i ] ))
                     == NULL )
                  fatal_error();

               if (( array[ i ].second = strdup( pointer[ i ].subject ))
                     == NULL )
                  fatal_error();

               if (( array[ i ].third = strdup( pointer[ i ].from ))
                     == NULL )
                  fatal_error();

               break;

            case NP_POSTER:

               if (( array[ i ].first = strdup( pointer[ i ].from )) == NULL )
                  fatal_error();

               if (( array[ i ].second = strdup( summary->local_times[ i ] ))
                     == NULL )
                  fatal_error();

               if (( array[ i ].third = strdup( pointer[ i ].subject )) 
                     == NULL )
                  fatal_error();

               break;

            case NP_SUBJECT:
               break;
         }
      }

      qsort( array, summary->stats.total, sizeof *array, ln_compare );
   }

   items_size = summary->stats.total * 3;

   if (( items = calloc( items_size, sizeof *items )) == NULL )
      fatal_error();

   property[ 1 ] = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->medium_font,
                                       EZ_FOREGROUND, "Darkblue",
                                       0 );

   property[ 2 ] = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->medium_font,
                                       EZ_FOREGROUND, "ForestGreen",
                                       0 );

   property[ 3 ] = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font,
                                       0 );

   switch( order )
   {
      case NP_DATE:
         items[ 0 ] = EZ_CreateLabelItem( "Local Time", property[ 3 ] );
         items[ 1 ] = EZ_CreateLabelItem( "Subject", property[ 3 ] );
         items[ 2 ] = EZ_CreateLabelItem( "Poster", property[ 3 ] );
         break;

      case NP_POSTER:
         items[ 0 ] = EZ_CreateLabelItem( "Poster", property[ 3 ] );
         items[ 1 ] = EZ_CreateLabelItem( "Local Time", property[ 3 ] );
         items[ 2 ] = EZ_CreateLabelItem( "Subject", property[ 3 ] );
         break;

      case NP_SUBJECT:
         items[ 0 ] = EZ_CreateLabelItem( "Subject", property[ 3 ] );
         items[ 1 ] = EZ_CreateLabelItem( "Poster", property[ 3 ] );
         items[ 2 ] = EZ_CreateLabelItem( "Local Time", property[ 3 ] );
         break;
   }

   EZ_SetFancyListBoxHeader( summary->summary_list, items, 3 );

   if( order != NP_SUBJECT )
   {
      char **element;

      for( i = 0; i < summary->stats.total; ++i )
      {
         element = (( order == NP_DATE ) ? &array[ i ].first
                    : &array[ i ].second );

         ln_convert_printable( element );
      }
   }

   if ( summary->positions != NULL )
      free( summary->positions );

   if (( summary->positions = calloc( summary->stats.total, 
         sizeof *summary->positions ))
         == NULL )
      fatal_error();

   pointer = summary->contents;
   j = 0;
   for( i = 0; i < summary->stats.total; ++i )
   {
      if ( order == NP_SUBJECT )
      {
         if ( pointer[ i ].is_article )
            foreground = summary->article_colour;
         else
            foreground
               = (( pointer[ i ].is_requested ) ? summary->requested_colour :
                     summary->header_colour );
      }
      else
         if ( array[ i ].is_article )
            foreground = summary->article_colour;
         else
            foreground 
               = (( array[ i ].is_requested ) ? summary->requested_colour :
                     summary->header_colour );

      if ( order != NP_SUBJECT )
         font = (( array[ i ].is_unread ) ? 
               newsreader->bold_font : newsreader->medium_font );

      else
         font = (( pointer[ i ].is_unread ) ? 
               newsreader->bold_font : newsreader->medium_font );

      property[ 0 ] = EZ_GetTextProperty( EZ_FONT_NAME, font,
                                          EZ_FOREGROUND, foreground,
                                          0 );

      switch( order )
      {
         case NP_DATE:
            items[ j++ ]
               = EZ_CreateLabelItem( array[ i ].first, property[ 2 ] );
            items[ j++ ]
               = EZ_CreateLabelItem( array[ i ].second, property[ 0 ] );
            items[ j++ ] 
               = EZ_CreateLabelItem( array[ i ].third, property[ 1 ] );

            break;

         case NP_POSTER:
            items[ j++ ] = EZ_CreateLabelItem( array[ i ].first,
                                               property[ 1 ] );
            items[ j++ ]
               = EZ_CreateLabelItem( array[ i ].second, property[ 2 ] );
            items[ j++ ] 
               = EZ_CreateLabelItem( array[ i ].third, property[ 0 ] );
            break;

         case NP_SUBJECT:
            items[ j++ ] = EZ_CreateLabelItem( pointer[ i ].subject,
                                               property[ 0 ] );
            items[ j++ ] = EZ_CreateLabelItem( pointer[ i ].from,
                                               property[ 1 ] );

            if (( buffer = strdup( summary->local_times[ i ] )) == NULL )
               fatal_error();

            ln_convert_printable( &buffer );

            items[ j++ ] = EZ_CreateLabelItem( buffer, property[ 2 ] );

            free( buffer );

            summary->positions[ i ] = pointer[ i ].ordinal;

            break;
      }

      for( k = j - 3; k < j; ++k )
         EZ_ConfigureItem( items[ k ],
                           EZ_TEXT_LINE_LENGTH, 60,
                           0 );

      if ( order != NP_SUBJECT )
         summary->positions[ i ] = array[ i ].position;
   }

   EZ_FreezeWidget( summary->summary_list );
   EZ_SetFancyListBoxData( summary->summary_list, items, 
                           summary->stats.total, 3 );
   EZ_UnFreezeWidget( summary->summary_list );

   free( items );

   if ( order != NP_SUBJECT )
   {
      for( i = 0; i < summary->stats.total; ++i )
      {
         free( array[ i ].first );
         free( array[ i ].second );
         free( array[ i ].third );
      }

      free( array );
   }

   return;
}

void summary_subject_callback( EZ_Widget *widget, void *data )
{
   (( np_summary_object *)data )->reorder( NP_SUBJECT, data );

   return;
}

void summary_poster_callback( EZ_Widget *widget, void *data )
{
   (( np_summary_object *)data )->reorder( NP_POSTER, data );

   return;
}

void summary_date_callback( EZ_Widget *widget, void *data )
{
   (( np_summary_object *)data )->reorder( NP_DATE, data );

   return;
}

/*
 * If a line in the fancy list box of the summary panel is clicked,
 * then trigger the callback for the corresponding node in the thread tree.
 */

void summary_list_callback( EZ_Widget *widget, void *data )
{
   np_summary_object *summary;
   np_newsreader_object *newsreader;

   EZ_Item **items;

   ln_group_summary *pointer;

   int r, c, radio_value;

   summary = ( np_summary_object *)data;
   newsreader = ( np_newsreader_object *)summary->parent;

   EZ_GetFancyListBoxSelectionIdx( summary->summary_list, &r, &c );

   radio_value
      = EZ_GetRadioButtonGroupVariableValue( summary->subject_button );

   --r;
   if ( radio_value != NP_SUBJECT )
      r = summary->positions[ r ] - 1;

   pointer = summary->contents;

   if ( pointer[ r ].is_unread )
   {
      items = EZ_GetFancyListBoxSelection( summary->summary_list );

      switch( radio_value )
      {
         case NP_SUBJECT:
            c = 0;
            break;

         case NP_POSTER:
            c = 2;
            break;

         case NP_DATE:
            c = 1;
            break;
      }

      EZ_ConfigureItem( items[ c ],
                        EZ_FONT_NAME, newsreader->medium_font, 
                        0 );
      EZ_DisplayWidget( summary->summary_list );
   }

   /*
    * If the corresponding node in the thread tree is currently part of a
    * collapsed thread subtree, expand the subtree to show the node.
    */

   if ( summary->node_state[ r ] == NP_NOT_SHOWN )
   {
      unsigned int i = r;

      while( summary->node_state[ i ] == NP_NOT_SHOWN )
         summary->node_state[ i-- ] = NP_SHOWN;

      summary->update_tree( summary, summary->thread_tree );
   }

   EZ_ListTreeWidgetSelectNode( summary->thread_tree, 
                                summary->node_list[ r ], NULL );
   EZ_DisplayWidget( summary->thread_tree );

   return;
}

/* 
 * Creates the summary panel when the summary button is pressed.
 */

void summary_callback( EZ_Widget *widget, void *data )
{
   static char group[ LN_BUFFER_SIZE ] = "\0";

   np_newsreader_object *newsreader;
   np_summary_object *summary;
   np_tree_object *tree;

   EZ_Widget *button_frame, *poster_button, *date_button, *done_button;
   EZ_TreeNode *selected;


   summary = ( np_summary_object *)data;
   newsreader = ( np_newsreader_object *)summary->parent;
   tree = ( np_tree_object *)newsreader->tree_object;

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) == NULL )
      return;

   if ( selected == tree->root_node ||
        *( char *)EZ_GetItemPtrData( EZ_TreeNodeGetItem( selected )) == 's' )
      return;

   if ( summary->summary_onscreen || !summary->stats.total )
      return;

   summary->summary_frame = EZ_CreateFrame( NULL, "Group Summary" );

   EZ_ConfigureWidget( summary->summary_frame,
                       EZ_IPADY, 10,
                       EZ_HEIGHT, 600,
                       EZ_WIDTH, 600,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   summary->group_label = EZ_CreateLabel( summary->summary_frame, NULL );

   EZ_ConfigureWidget( summary->group_label,
                       EZ_HEIGHT, 20,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_LABEL_POSITION, EZ_CENTER,
                       EZ_TEXT_LINE_LENGTH, 80,
                       0 );

   summary->message_label = EZ_CreateLabel( summary->summary_frame, NULL );

   EZ_ConfigureWidget( summary->message_label,
                       EZ_HEIGHT, 20,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_LABEL_POSITION, EZ_CENTER,
                       EZ_TEXT_LINE_LENGTH, 80,
                       0 );

   button_frame = EZ_CreateFrame( summary->summary_frame, "sort by:" );

   EZ_ConfigureWidget( button_frame,
                       EZ_HEIGHT, 75,
                       0 );

   summary->subject_button
      = EZ_CreateRadioButton( button_frame, "subject", 0, 0, 0 );

   EZ_ConfigureWidget( summary->subject_button,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_CALLBACK, summary->subject_callback, summary,
                       0 );

   poster_button = EZ_CreateRadioButton( button_frame, "poster", 0, 0, 1 );

   EZ_ConfigureWidget( poster_button,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_CALLBACK, summary->poster_callback, summary,
                       0 );

   date_button = EZ_CreateRadioButton( button_frame, "local time", 0, 0, 2 );

   EZ_ConfigureWidget( date_button,
                       EZ_CALLBACK, summary->date_callback, summary,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   summary->summary_list = EZ_CreateFancyListBox( summary->summary_frame,
         1, 1, 3, 1 );

   EZ_SetHScrollbarDiscreteSpeed( summary->summary_list, 10 );
   EZ_SetVScrollbarDiscreteSpeed( summary->summary_list, 10 );

   EZ_ConfigureWidget( summary->summary_list,
                       EZ_IPADY, 10,
                       EZ_IPADX, 5,
                       EZ_MOTION_CALLBACK, summary->list_callback, 
                       summary,
                       0 );

   done_button = EZ_CreateButton( summary->summary_frame, "done", 0 );

   EZ_ConfigureWidget( done_button,
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_HEIGHT, 35,
                       EZ_WIDTH, 100,
                       EZ_EXPAND, False,
                       EZ_CALLBACK, summary->done_callback, summary,
                       0 );

   summary->show_stats( summary );
   EZ_DisplayWidget( summary->summary_frame );
   summary->summary_onscreen = 1;

   if ( strcmp( group, summary->group_name ) || summary->local_times == NULL )
   {
      strcpy( group, summary->group_name );

      summary->create_local_times( summary );
   }

   summary->subject_callback( summary->subject_button, summary );
   EZ_SetRadioButtonGroupVariableValue( summary->subject_button, 0 );

   return;
}

/*
 * pass the index of the selected thread tree node as a drag-and-drop
 * message.
 */

int summary_dnd_encoder( EZ_Item *item, void *data, char **message,
                         int *length, int *needfree )
{
   char buffer[ 256 ];


   snprintf( buffer, 256, "%u", (unsigned int)EZ_GetItemIntData( item ));
   *length = strlen( buffer ) + 1;

   if (( *message = strdup( buffer )) == NULL )
      fatal_error();

   *needfree = 1;

   return EZ_DND_SUCCESS;
}
