/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "peruser.h"
#include "message.h"

/*
 * Constructor.
 */

void message_init( void *this, void *parent )
{
   np_message_object *message;
   np_newsreader_object *newsreader;

   message = ( np_message_object *)this;
   newsreader = ( np_newsreader_object *)parent;

   message->parent = newsreader;
   message->message.header = message->message.body = NULL;

   message->set_message = message_set_message;
   message->clear_message = message_clear_message;
   message->destroy_pix_list = message_destroy_pix_list;
   message->destroy = message_destroy;

   message->decode = message_decode;
   message->uu_busy_callback = message_uu_busy_callback;
   message->picture_frame_callback = message_picture_frame_callback;
   message->picture_frame_button_destroy_callback = 
      message_picture_frame_button_destroy_callback;

   message->pix_list = message->pix_end = NULL;

   /* 
    * UUDeview Library callback. Print status message every quarter-second. 
    */

   UUSetBusyCallback( message, message->uu_busy_callback, 500 );

   /* header list */

   message->header_text = EZ_CreateTextWidget( newsreader->bottom_frame, 0,
                                               1, 1 );

   EZ_SetHScrollbarDiscreteSpeed( message->header_text, 10 );
   EZ_SetVScrollbarDiscreteSpeed( message->header_text, 10 );

   EZ_ConfigureWidget( message->header_text,
                       EZ_FONT_NAME, (( newsreader->fixed_width ) ?
                                      newsreader->fixed_font :
                                      newsreader->bold_font ),
                       EZ_HEIGHT, (( newsreader->long_headers ) ?
                                   150 : 65 ),
                       EZ_OPTIONAL_VSCROLLBAR, (( newsreader->long_headers ) ?
                                                EZ_YES : EZ_NO ),
                       EZ_OPTIONAL_HSCROLLBAR, (( newsreader->long_headers ) ?
                                                EZ_YES : EZ_NO ),
                       0 );

   /* pane handle */

   EZ_CreatePaneHandle( newsreader->bottom_frame );

   /* message list */

   message->body_text = EZ_CreateTextWidget( newsreader->bottom_frame, 0, 
                                             1, 1 );

   EZ_SetHScrollbarDiscreteSpeed( message->body_text, 10 );
   EZ_SetVScrollbarDiscreteSpeed( message->body_text, 10 );

   EZ_ConfigureWidget( message->body_text,
                       EZ_FONT_NAME, (( newsreader->fixed_width ) ?
                                      newsreader->fixed_font :
                                      newsreader->bold_font ),
                       0 );

   return;
}

void message_destroy_pix_list( np_pix_list *pix )
{
   if ( pix->next != NULL )
      message_destroy_pix_list( pix->next );

   free( pix->name );
   free( pix );

   return;
}

/*
 * Destructor.
 */

void message_destroy( void *this )
{
   np_message_object *message;

   message = ( np_message_object *)this;

   if (  message->message.header != NULL )
      free( message->message.header );

   if ( message->message.body != NULL )
      free( message->message.body );

   if ( message->pix_list != NULL )
      message->destroy_pix_list( message->pix_list );

   return;
}

/*
 * Loads article header and body text into the text widgets in the main frame,
 * displaying certain header lines in colour.
 */

void message_set_message( void *this, char *group_name, ln_type type,
                          long int offset, long int size )
{
   np_message_object *message;
   np_buttons_object *buttons;
   np_update_object *update;
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_summary_object *summary;

   EZ_TextProperty *props[ 5 ];

   char *pointer, buffer[ LN_BUFFER_SIZE ];
   int count, i;  



   message = ( np_message_object *)this;
   newsreader = ( np_newsreader_object *)message->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   update = ( np_update_object *)buttons->update_object;

   if ( message->message.header != NULL )
      free( message->message.header );

   if ( message->message.body != NULL )
      free( message->message.body );

   message->clear_message( message );

   if ( ln_get_message_text( group_name, type, offset, size, 
                             &message->message ))
      lib_error();

   props[ 0 ] = EZ_GetTextProperty( EZ_FOREGROUND, "DarkRed",
                                    0 );

   props[ 1 ] = EZ_GetTextProperty( EZ_FOREGROUND, "DarkBlue",
                                                 0 );

   props[ 2 ] = EZ_GetTextProperty( EZ_FOREGROUND, "ForestGreen",
                                    0 );

   props[ 3 ] = NULL;

   props[ 4 ] = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->bold_italic_font,
                                    0 );
   
   EZ_FreezeWidget( message->header_text );
   EZ_FreezeWidget( message->body_text );

   if ( type )
      pointer = message->message.header - 1;
   else
      pointer = strchr( message->message.header, '\n');

   while( *( ++pointer ) )
   {
      if ( !strncmp( pointer, "Subject: ", 9 ))
         i = 0;
      else
         if ( !strncmp( pointer, "From: ", 6 ))
            i = 1;
         else
            if ( !strncmp( pointer, "Date: ", 6 ))
               i = 2;
            else
               i = 3;

      count = strcspn( pointer, "\n" );

      if ( pointer[ count + 1 ] )
         ++count;

      strncpy( buffer, pointer, count );
      buffer[ count ] = '\0';

      pointer = strchr( pointer, '\n' );

      if ( !newsreader->long_headers && i >= 3 )
         continue;
      
      EZ_TextInsertStringWithProperty( message->header_text, buffer,
                                       props[ i ] );
   }

   if ( message->message.body != NULL )
   {
      pointer = message->message.body - 1;

      while( *( ++pointer ) )
      {
         if ( ( pointer + strspn( pointer, " \t" ))[ 0 ] == '>' )
            i = 4;
         else
            i = 3;

         count = strcspn( pointer, "\n" );

         if ( pointer[ count + 1 ] )
            ++count;

         strncpy( buffer, pointer, count );
         buffer[ count ] = '\0';
         
         EZ_TextInsertStringWithProperty( message->body_text, buffer,
                                          props[ i ] );

         pointer = strchr( pointer, '\n' );
      }

      if ( newsreader->auto_decode )
         message->decode( message );
   }

   EZ_TextBeginningOfBuffer( message->header_text );
   EZ_TextBeginningOfBuffer( message->body_text );

   EZ_UnFreezeWidget( message->header_text );
   EZ_UnFreezeWidget( message->body_text );

   return;
}

/*
 * Clears the text widgets on the main frame.
 */

void message_clear_message( void *this )
{
   np_message_object *message;

   message = ( np_message_object *)this;

   EZ_TextClear( message->header_text );

   if ( message->message.header != NULL )
      EZ_TextClear( message->body_text );

   return;
}

/*
 * Callback for all displayed picture frames. Destroys the calling frame.
 */

void message_picture_frame_callback( EZ_Widget *widget, void *data )
{
   np_message_object *message;
   np_pix_list *pix;

   EZ_Widget *frame;


   message = ( np_message_object *)data;

   /* Button is widget, parent frame is client data. */

   frame = EZ_GetWidgetPtrData( widget );
   pix = ( np_pix_list *)EZ_GetWidgetPtrData( frame );
   EZ_DestroyWidget( frame );

   /* Remove entry in picture list */

   free( pix->name );

   if ( pix->prev != NULL )
      (( np_pix_list *)pix->prev )->next = pix->next;

   if ( pix->next != NULL )
      (( np_pix_list *)pix->next )->prev = pix->prev;

   if ( pix == message->pix_list )
      if ( pix->prev == NULL && pix->next == NULL )
         message->pix_list = NULL;
      else
         message->pix_list = pix->next;

   free( pix );

   return;
}

/*
 * Destroy callback for the button on all picture frames. Frees the pixmap for
 * the button in the X server. It will be called automatically when the widget
 * is destroyed, or if the user exits Peruser without closing the displayed
 * picture frame. 
 */

void message_picture_frame_button_destroy_callback( EZ_Widget *widget, 
                                                    void *data )
{
   EZ_FreeLabelPixmap( data );
   return;
}

/*
 * Callback from UUDeview library. Displays informational message.
 */

int message_uu_busy_callback( void *this, uuprogress *progress )
{
   np_update_object *update;
   np_message_object *message;
   np_newsreader_object *newsreader;
   
   char buffer[ LN_BUFFER_SIZE ], *pointer;


   message = ( np_message_object *)this;
   newsreader = ( np_newsreader_object *)message->parent;
   update = ( np_update_object *)
      (( np_buttons_object *)newsreader->buttons_object )->update_object;

   switch( progress->action )
   {
      case UUACT_SCANNING:
         pointer = "Scanning ";
         break;

      case UUACT_DECODING:
         pointer = "Decoding ";
         break;

      case UUACT_COPYING:
         pointer = "Copying ";
         break;

      case UUACT_ENCODING:
         pointer = "Encoding ";
         break;

      default:
         pointer = "";
   }

   if ( progress->fsize != -1 )
   {
      snprintf( buffer, LN_BUFFER_SIZE, "%s %d%%", pointer, 
                progress->percent / progress->numparts );

      newsreader->show_message( newsreader, buffer );
   }

   if ( update->interrupt )
      return 1;

   return 0;
}

/*
 * Check for an encoded binary. If found, decode. If image, display it.
 */

void message_decode( void *this )
{
   np_message_object *message;
   np_newsreader_object *newsreader;
   np_newsrc_object *newsrc;
   np_summary_object *summary;
   np_buttons_object *buttons;
   np_update_object *update;

   np_pix_list *pix_pointer;
   enum{ NO, YES }found;

   EZ_Widget *frame;
   EZ_LabelPixmap *pixmap;

   char buffer[ LN_BUFFER_SIZE ], *pointer; 
   char *image_types[] = { "GIF", "Gif", "gif", "jpeg", "jpg", "JPG", 
                           "xpm", "Xpm", "XPM", "ppm", "" };
   
   int result, i, j;
   FILE *file;

   uulist *item;


   message = ( np_message_object *)this;
   newsreader = ( np_newsreader_object *)message->parent;
   summary = ( np_summary_object *)newsreader->summary_object;
   buttons = ( np_buttons_object *)newsreader->buttons_object;
   newsrc = ( np_newsrc_object *)buttons->newsrc_object;
   update = ( np_update_object *)buttons->update_object;

   i = j = -1;

   /* Save article to file */

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/.temp", 
             getenv( "HOME" ));
   if (( file = fopen( buffer, "w" )) == NULL )
      fatal_error();

   fputs( message->message.header, file );
   if ( message->message.body != NULL )
      fprintf( file, "\r\n%s", message->message.body );
   fflush( file );
   fclose( file );

   /* Initialize library. */

   update->interrupt = 0;
   update->connect = 2;
   update->disable_interface( newsreader, 1 );
   if ( UUInitialize() != UURET_OK )
      fatal_error();

   /*
    * Scan for encoded data. The 1 argument of UULoadFile tells the library
    * to remove the file in UUCleanUp(); 
    */

   if (( result = UULoadFile( buffer, NULL, 1 )) != UURET_OK )
   {
      strcpy( buffer, (( result == UURET_IOERR ) ?
                       strerror( UUGetOption( UUOPT_ERRNO, NULL, NULL, 0 )) :
                       UUstrerror( result )));
      newsreader->show_message( newsreader, buffer );
      
      UUCleanUp();
      return;
   }

   /* 
    * decode each file found in article. 
    */

   while(( item = UUGetFileListItem( ++i )) != NULL )
   {
      if ( !( item->state & UUFILE_OK )) 
         continue;

      /* 
       * Check against list of displayed images.
       */

      found = NO;
      if ( message->pix_list != NULL )
         for ( pix_pointer = message->pix_list; 
               pix_pointer != NULL; 
               pix_pointer = pix_pointer->next )
         {
            message->pix_end = pix_pointer;
            if ( !strcmp( pix_pointer->name, item->filename ))
            {
               found = YES;
               break;
            }
         }

      if ( found )
      {
         snprintf( buffer, LN_BUFFER_SIZE, "%s already displayed", 
                   item->filename );
         newsreader->show_message( newsreader, buffer ); 
         continue;
      }

      /*
       * Decode the article to temporary file, which the library will remove
       * in UUCleanUp().
       */

      if (( result = UUDecodeToTemp( item )) != UURET_OK )
      {
         strcpy( buffer, (( result == UURET_IOERR ) ?
                 strerror( UUGetOption( UUOPT_ERRNO, NULL, NULL, 0 )) :
                 UUstrerror( result )));
         newsreader->show_message( newsreader, buffer );
         continue;
      }

      if ( item->binfile == NULL || item->filename == NULL )
         continue;

      if (( pointer = strrchr( item->filename, '.' )) == NULL )
         continue;

      /*
       * If recognized image file, display it in a frame.
       */

      ++pointer;
      while( *( image_types[ ++j ] ))
         if ( !strcmp( pointer, image_types[ j ] ))
         {
            /*
             * Make new entry in message->pix_list.
             */

            if ( message->pix_list == NULL )
            {
               if (( message->pix_list
                        = malloc( sizeof *message->pix_list )) == NULL )
                  fatal_error();

               message->pix_end = message->pix_list;
               message->pix_end->prev = NULL;
            }
            else
            {
               if (( message->pix_end->next 
                        = malloc( sizeof *message->pix_list )) == NULL )
                  fatal_error();

               (( np_pix_list *)message->pix_end->next )->prev 
                  = message->pix_end;
               message->pix_end = message->pix_end->next;
            }

            if (( message->pix_end->name = strdup( item->filename )) == NULL )
               fatal_error();
            message->pix_end->next = NULL;
            
            /*
             * Create picture frame.
             */

            frame = EZ_CreateFrame( NULL, item->filename );

            EZ_ConfigureWidget( frame,
                                EZ_TEXT_LINE_LENGTH, 80,
                                EZ_CLIENT_PTR_DATA, message->pix_end,
                                EZ_FILL_MODE, EZ_FILL_BOTH,
                                EZ_ORIENTATION, EZ_VERTICAL,
                                0 );

            pixmap = EZ_CreateLabelPixmapFromImageFile( item->binfile );

            EZ_ConfigureWidget( EZ_CreateButton( frame, NULL, 0 ),
                                EZ_LABEL_PIXMAP, pixmap,
                                EZ_BORDER_TYPE, EZ_BORDER_NONE,
                                EZ_EXPAND, True,
                                EZ_CLIENT_PTR_DATA, frame,
                                EZ_DESTROY_CALLBACK, 
                                message->picture_frame_button_destroy_callback,
                                pixmap,
                                EZ_CALLBACK, message->picture_frame_callback, 
                                message,
                                0 );

            EZ_DisplayWidget( frame );
            j = -1;
            break;
         }
   }
   
   UUCleanUp();
   update->disable_interface( newsreader, 0 );
   return;
}
