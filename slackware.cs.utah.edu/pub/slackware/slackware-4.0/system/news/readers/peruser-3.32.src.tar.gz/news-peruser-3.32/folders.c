/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "peruser.h"
#include<sys/types.h>
#include<regex.h>
#include "folders.h"

/* 
 * Constructor.
 */

void folders_init( void *parent )
{
   np_folders_object *folders;
   np_buttons_object *buttons;


   buttons = ( np_buttons_object *)parent;
   folders = buttons->folders_object;

   folders->parent = buttons;

   folders->callback = folders_callback;
   folders->add_callback = folders_add_callback;
   folders->remove_callback = folders_remove_callback;
   folders->replace_callback = folders_replace_callback;
   folders->dnd_reorder_encoder = folders_dnd_reorder_encoder;
   folders->dnd_reorder_decoder = folders_dnd_reorder_decoder;
   folders->done_callback = folders_done_callback;
   folders->update_list = folders_update_list;
   folders->list_motion_callback = folders_list_motion_callback;
   folders->sort_callback = folders_sort_callback;

   folders->verify = folders_verify;
   folders->persistent_callback = folders_persistent_callback;
   folders->persistent_add_callback = folders_persistent_add_callback;
   folders->persistent_replace_callback = folders_persistent_replace_callback;
   folders->persistent_remove_callback = folders_persistent_remove_callback;
   folders->persistent_motion_callback = folders_persistent_motion_callback;
   folders->persistent_sort_callback = folders_persistent_sort_callback;
   folders->update_persistent = folders_update_persistent;

   return;
}

/*
 * Displays virtual group frame. In the early stages of the development of
 * News Peruser, virtual newsgroups were referred to as folders. When I added
 * the ability to create user-defined folders, I chose to use the name
 * persistent folders to refer to them, and kept the name folders to refer to
 * virtual groups, instead of changing the existing code.
 */

void folders_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;

   EZ_Widget *top_button_frame, *bottom_button_frame;
   EZ_Item *items[ 2 ];
   EZ_TextProperty *prop;


   folders = ( np_folders_object *)data;
   buttons = ( np_buttons_object *)folders->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;

   if ( widget == buttons->virtual_button )
      folders->persistent = 0;
   else
      folders->persistent = 2;

   /* frame */

   folders->frame = EZ_CreateFrame( NULL, (( folders->persistent ) ?
                                           "Inboxes" : "Virtual Groups" ));

   EZ_ConfigureWidget( folders->frame,
                       EZ_HEIGHT, 500,
                       EZ_WIDTH, 525,
                       EZ_IPADY, 5, 
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( folders->frame,
                                       (( folders->persistent ) ? 
                                        "inbox name" : "group name:" )),
                       EZ_LABEL_POSITION, EZ_LEFT,
                       EZ_HEIGHT, 30,
                       0 );

   /* folder entry */

   folders->folder_entry = EZ_CreateEntry( folders->frame, NULL );

   EZ_ConfigureWidget( folders->folder_entry,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_WIDTH, 475,
                       EZ_HEIGHT, 30,
                       0 );

   /* filter entry */

   EZ_ConfigureWidget( EZ_CreateLabel( folders->frame,
                                       (( folders->persistent ) ?
                                        "corresponding maildrop" :
                                        "regular expression filter:" )),
                       EZ_LABEL_POSITION, EZ_LEFT,
                       EZ_HEIGHT, 30,
                       0 );

   folders->filter_entry = EZ_CreateEntry( folders->frame, NULL );

   EZ_ConfigureWidget( folders->filter_entry,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 475,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   /* top button frame */

   top_button_frame = EZ_CreateFrame( folders->frame, NULL );

   EZ_ConfigureWidget( top_button_frame,
                       EZ_IPADX, 10,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( top_button_frame, "add", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, folders->add_callback, folders,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( top_button_frame, "replace", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, folders->replace_callback, folders,
                       0 );

   /* list */

   folders->list = EZ_CreateFancyListBox( folders->frame, 1, 1, 2, 1 );

   EZ_SetHScrollbarDiscreteSpeed( folders->list, 10 );
   EZ_SetVScrollbarDiscreteSpeed( folders->list, 10 );

   EZ_ConfigureWidget( folders->list,
                       EZ_FONT_NAME, newsreader->medium_font,          
                       EZ_CALLBACK, folders->remove_callback, folders,
                       EZ_MOTION_CALLBACK, folders->list_motion_callback, 
                       folders,
                       EZ_IPADX, 10,
                       0 );

   prop = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font,
                              0 );

   items[ 0 ] = EZ_CreateLabelItem( (( folders->persistent ) ? 
                                     "Inbox" : "Group" ), prop );
   items[ 1 ] = EZ_CreateLabelItem( (( folders->persistent ) ?
                                     "Maildrop" : "Filter" ), prop );

   EZ_SetFancyListBoxHeader( folders->list, items, 2 );

   /* bottom button frame */

   bottom_button_frame = EZ_CreateFrame( folders->frame, NULL );

   EZ_ConfigureWidget( bottom_button_frame,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   /* bottom buttons */

   EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "done", 0 ),
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, folders->done_callback, folders, 
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "sort", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, folders->sort_callback, folders,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "help", 0 ),
                       EZ_CLIENT_INT_DATA, (( folders->persistent ) ?
                                            6 : 3 ),
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, buttons->help_callback, buttons,
                       0 );

   folders->dnd = -1;
   folders->update_list( folders );

   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));
   EZ_DisplayWidget( folders->frame );
   EZ_SetGrab( folders->frame );

   /* 
    * This hack prevents corruption of EZWGL's DnD system by
    * preventing calls to the DnD system from being made from within DnD
    * decoders or callbacks. 
    */

   for( ; ; )
   {
      while( folders->dnd == -1 )
         EZ_WaitAndServiceNextEvent();

      if ( folders->dnd == -2 )
         break;

      folders->update_list( folders );
      folders->dnd = -1;
   }

   return;
}

/*
 * Rereads ~/.peruser3-folders.
 */

void folders_update_list( void *this )
{
   np_folders_object *folders;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ], *format;
   unsigned int i, quantity;
   FILE *file;

   EZ_Item *items[ 2 ];
   EZ_TextProperty *prop[ 2 ];


   folders = ( np_folders_object *)this;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)folders->parent )->parent;

   if ( folders->persistent )
   {
      quantity = 2;
      format = "%s/.peruser3-inboxes";
   }
   else
   {
      quantity = 1;
      format = "%s/.peruser3-folders";
   }
   
   snprintf( buffer, LN_BUFFER_SIZE, format, getenv( "HOME" ));

   if (( file = fopen( buffer, "r" )) == NULL )
      if ( errno != ENOENT )
         fatal_error();
      else
         return;

   EZ_FreezeWidget( folders->list );
   EZ_FancyListBoxClear( folders->list );

   prop[ 0 ] = EZ_GetTextProperty( EZ_FOREGROUND, "DarkBlue",
                                   EZ_FONT_NAME, newsreader->medium_font,
                                   0 );

   prop[ 1 ] = EZ_GetTextProperty( EZ_FOREGROUND, "DarkRed",
                                   EZ_FONT_NAME, newsreader->medium_font,
                                   0 );

   i = 0;
   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
   {
      items[ 0 ] = EZ_CreateLabelItem( strtok( buffer + quantity, "\t" ), 
                                       prop[ 0 ] );

      EZ_ItemAddDnDDataEncoder( items[ 0 ], NP_DND_FOLDERS_ATOM, 0,
                                folders->dnd_reorder_encoder, folders,
                                NULL, NULL );

      EZ_ItemAddDnDDataDecoder( items[ 0 ], NP_DND_FOLDERS_ATOM, 0,
                                folders->dnd_reorder_decoder, folders,
                                NULL, NULL );

      items[ 1 ] = EZ_CreateLabelItem( strtok( NULL, "\n" ), prop[ 1 ] );

      EZ_ConfigureItem( items[ 0 ],
                        EZ_CLIENT_INT_DATA, i,
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );

      EZ_ConfigureItem( items[ 1 ],
                        EZ_CLIENT_INT_DATA, i,
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );

      EZ_FancyListBoxInsertRow( folders->list, items, 2, ++i );
   }

   fclose( file );

   EZ_UnFreezeWidget( folders->list );

   if ( folders->dnd >= 0 )
      EZ_FancyListBoxSelectItemUsingIdx( folders->list, ++folders->dnd,
                                         0, NULL );

   return;
}

/*
 * Destroys virtual groups frame.
 */

void folders_done_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;
   np_newsreader_object *newsreader;
   np_summary_object *summary;
   np_tree_object *tree;

   EZ_TreeNode *selected;
   EZ_Item *item;
   char group;
   long int i, j;


   folders = ( np_folders_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)folders->parent )->parent;
   tree = ( np_tree_object *)newsreader->tree_object;
   summary = ( np_summary_object *)newsreader->summary_object;

   folders->dnd = -2;

   EZ_DestroyWidget( folders->frame );

   if (( selected = EZ_GetListTreeWidgetSelection( tree->tree )) != NULL &&
         selected != tree->root_node )
   {
       group 
         = *( char *)EZ_GetItemPtrData( item = EZ_TreeNodeGetItem( selected ));
       i = EZ_GetItemIntData( item );
   }
   else
       i = -1;

   if (( selected = EZ_GetListTreeWidgetSelection( summary->thread_tree ))
           != NULL )
       j = EZ_GetItemIntData( EZ_TreeNodeGetItem( selected ));
   else
       j = -1;

   tree->update_lists( tree );
   tree->set_tree( tree );

   if ( -1 < i )
   {
       if ( group == 's' && i < tree->servers )
           EZ_ListTreeWidgetSelectNode( tree->tree, tree->server_nodes[ i ],
                                        NULL );
       else
       {
           if ( i < tree->groups )
               EZ_ListTreeWidgetSelectNode( tree->tree,
                                            tree->group_nodes[ i ], NULL );
           if ( -1 < j && j < summary->stats.total )
               EZ_ListTreeWidgetSelectNode( summary->thread_tree,
                                            summary->node_list[ j ], NULL );
       }
   }

   EZ_NormalCursor( newsreader->app_frame );

   return;
}

int folders_verify( void *this, char *string )
{
   np_folders_object *folders;
   np_newsrc_object *newsrc;

   char buffer[ LN_BUFFER_SIZE ];
   int i, l;
   
   folders = ( np_folders_object *)this;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)folders->parent )->newsrc_object;

   l = strlen( string );
   for( i = 0; i < l; ++i )
      if ( !isalnum( string[ i ] ))
         if ( string[ i ] != '_' && string[ i ] != '+' && 
              string[ i ] != '-' && string[ i ] != '.' )
         {
            snprintf( buffer, LN_BUFFER_SIZE, "Illegal character: %c\n"
                      "Virtual and Folder group names can contain\n"
                      "only alphnumeric characters "
                      "and `_', '+', or '-'",
                      string[ i ] );
            newsrc->confirm( newsrc, buffer, NP_DONE );
            return -1;
         }
            
   return 0;
}

/*
 * Callback of add button on virtual groups frame.
 */

void folders_add_callback( EZ_Widget *widget, void *data )
{
   np_newsrc_object *newsrc;
   np_folders_object *folders;

   int result;

   regex_t regex;

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
      third_buffer[ LN_BUFFER_SIZE ], *format;
   

   folders = ( np_folders_object *)data;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)folders->parent )->newsrc_object;

   strcpy( buffer, EZ_GetEntryString( folders->folder_entry ));
   if ( !strlen( buffer ))
      return;

   strcpy( second_buffer, EZ_GetEntryString( folders->filter_entry ));

   if ( !strlen( second_buffer ))
      return;

   if ( !folders->persistent )
   {
      if (( result = regcomp( &regex, second_buffer, 
                              REG_EXTENDED | REG_NOSUB )))
      {
         regerror( result, &regex, second_buffer, LN_BUFFER_SIZE );
         newsrc->confirm( newsrc, second_buffer, NP_DONE );
         return;
      }
      regfree( &regex );
   }

   if( folders->persistent == 2 )
      format = "::%s\t";
   else
      format = ":%s\t";
   
   snprintf( third_buffer, LN_BUFFER_SIZE, format, buffer );
   strcat( third_buffer, second_buffer );

   if ( folders->persistent )
   {
      if ( ln_add_inbox( third_buffer ) == -1 )
         lib_error();
   }
   else
      if ( ln_add_folder( third_buffer ) == -1 )
         lib_error();

   folders->update_list( folders );

   return;
}

/*
 * Normal callback of the listbox on the virtual groups frame
 */

void folders_remove_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;

   char buffer[ LN_BUFFER_SIZE ], *string, *format;

   EZ_Item **item;


   folders = ( np_folders_object *)data;

   item = EZ_GetFancyListBoxSelection( folders->list );

   if ( folders->persistent )
      format = "::%s";
   else 
      format = ":%s";
   
   EZ_GetLabelItemStringInfo( item[ 0 ], &string, NULL );
   snprintf( buffer, LN_BUFFER_SIZE, format, string );

   EZ_GetLabelItemStringInfo( item[ 1 ], &string, NULL );
   if ( strlen( string ))
   {
      strcat( buffer, "\t" );
      strcat( buffer, string );
   }

   if ( folders->persistent )
   {
      if ( ln_remove_inbox( buffer ) == -1 )
         lib_error();
   }
   else
      if ( ln_remove_folder( buffer ) == -1 )
         lib_error();

   folders->update_list( folders );

   return;
}

/*
 * Callback of sort button on virtual groups frame.
 */

void folders_sort_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;


   folders = ( np_folders_object *)data;

   if ( folders->persistent )
   {
      if ( ln_sort_inboxes() )
         lib_error();
   }
   else
      if ( ln_sort_folders() )
         lib_error();

   folders->update_list( folders );

   return;
}

/*
 * Callback of replace button on virtual groups frame.
 */

void folders_replace_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;
   np_newsreader_object *newsreader;
   np_newsrc_object *newsrc;

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
      third_buffer[ LN_BUFFER_SIZE ], *string, *format;

   int r;

   EZ_Item **selected;


   folders = ( np_folders_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)folders->parent )->parent;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)folders->parent )->newsrc_object;

   EZ_GetFancyListBoxSelectionIdx( folders->list, &r, NULL );

   if ( r == -1 )
   {
      newsrc->confirm( newsrc,
                       (( folders->persistent ) ?
                        "Select an inbox in the list\nto replace, first." :
                        "Select a group in the list\nto replace, first." ),
                       NP_DONE );
      return;
   }

   strcpy( buffer, EZ_GetEntryString( folders->folder_entry ));
   if ( !strlen( buffer ))
      return;

   if ( folders->verify( folders, buffer ))
      return;

   if ( folders->persistent )
      format = "::%s";
   else
      format =":%s";
   
   snprintf( third_buffer, LN_BUFFER_SIZE, format, buffer );

   strcpy( second_buffer, EZ_GetEntryString( folders->filter_entry ));
   if ( !strlen( second_buffer ))
      return;

   strcat( third_buffer, "\t" );
   strcat( third_buffer, second_buffer );

   selected = EZ_GetFancyListBoxSelection( folders->list );
   EZ_GetLabelItemStringInfo( selected[ 0 ], &string, NULL );
   snprintf( second_buffer, LN_BUFFER_SIZE, format, string );

   if ( folders->persistent )
   {
      if ( ln_replace_inbox( second_buffer, third_buffer ))
         lib_error();
   }
   else
      if ( ln_replace_folder( second_buffer, third_buffer ))
         lib_error();

   folders->update_list( folders );

   return;
}

/*
 * Sets the input widgets to the currently-selected folder's data.
 */

void folders_list_motion_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;

   EZ_Item **item;

   char buffer[ LN_BUFFER_SIZE ], *string;


   folders = ( np_folders_object *)data;

   item = EZ_GetFancyListBoxSelection( folders->list );

   EZ_GetLabelItemStringInfo( item[ 0 ], &string, NULL );
   strcpy( buffer, string );

   EZ_SetEntryString( folders->folder_entry, buffer );

   EZ_GetLabelItemStringInfo( item[ 1 ], &string, NULL );
   strcpy( buffer, string );

   EZ_SetEntryString( folders->filter_entry, buffer );

   return;
}

/*
 * Passes the ordinal position of the drop source as drag-and-drop message to
 * drop target.
 */

int folders_dnd_reorder_encoder( EZ_Item *item, void *data, char **message,
                                 int *length, int *needfree )
{
   unsigned int follower;

   char buffer[ LN_BUFFER_SIZE ];


   follower = EZ_GetItemIntData( item );
   snprintf( buffer, LN_BUFFER_SIZE, "%d", follower );

   /*
    * EZ_DndMsg.c does not want me to count the terminator, but the
    * string must be zero-terminated 
    */

   *length = strlen( buffer );

   if (( *message = malloc( *length )) == NULL )
      fatal_error();

   strcpy( *message, buffer );

   *needfree = 1;

   return EZ_DND_SUCCESS;
}

/*
 * Changes order of virtual groups in ~/.peruser3-folders.
 */

int folders_dnd_reorder_decoder( EZ_Item *item, void *data, char *message,
                                 int length )
{
   np_folders_object *folders;

   unsigned int source, target;


   folders = ( np_folders_object *)data;

   target = EZ_GetItemIntData( item );
   source = atoi( message );

   if ( target == source || ( target == source - 1 ))
      return EZ_DND_FAILURE;

   switch( folders->persistent )
   {
   case 0:
      if ( ln_move_folder( target, source ) )
         lib_error();
      break;
      
   case 1:
      if ( ln_move_persistent( target, source ))
         lib_error();
      break;
      
   case 2:
      if ( ln_move_inbox( target, source ))
         lib_error();
      break;
   }

   folders->dnd = (( source < target ) ? target : target + 1 );

   return EZ_DND_SUCCESS;
}

/*
 * Displays persistent folders frame.
 */

void folders_persistent_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;
   np_buttons_object *buttons;
   np_newsreader_object *newsreader;

   EZ_Widget *top_button_frame, *bottom_button_frame;
   EZ_TextProperty *prop;
   EZ_Item *item;


   folders = ( np_folders_object *)data;
   buttons = ( np_buttons_object *)folders->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;

   folders->persistent = 1;

   folders->frame = EZ_CreateFrame( NULL, "Folders" );

   EZ_ConfigureWidget( folders->frame,
                       EZ_HEIGHT, 500,
                       EZ_WIDTH, 525,
                       EZ_IPADY, 5,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( folders->frame, "folder name:" ),
                       EZ_LABEL_POSITION, EZ_LEFT,
                       EZ_HEIGHT, 30,
                       0 );

   folders->folder_entry = EZ_CreateEntry( folders->frame, NULL );

   EZ_ConfigureWidget( folders->folder_entry,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_WIDTH, 475,
                       EZ_HEIGHT, 30,
                       0 );

   top_button_frame = EZ_CreateFrame( folders->frame, NULL );

   EZ_ConfigureWidget( top_button_frame,
                       EZ_IPADX, 10,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( top_button_frame, "add", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, folders->persistent_add_callback,
                       folders,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( top_button_frame, "replace", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, folders->persistent_replace_callback,
                       folders,
                       0 );

   folders->list = EZ_CreateFancyListBox( folders->frame, 1, 1, 1, 1 );

   EZ_SetHScrollbarDiscreteSpeed( folders->list, 10 );
   EZ_SetVScrollbarDiscreteSpeed( folders->list, 10 );

   EZ_ConfigureWidget( folders->list,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_CALLBACK, folders->persistent_remove_callback,
                       folders,
                       EZ_MOTION_CALLBACK, folders->persistent_motion_callback,
                       folders,
                       EZ_IPADX, 10,
                       0 );

   prop = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->header_font,
                              0 );

   item = EZ_CreateLabelItem( "Folders", prop );

   EZ_SetFancyListBoxHeader( folders->list, &item, 1 );

   bottom_button_frame = EZ_CreateFrame( folders->frame, NULL );

   EZ_ConfigureWidget( bottom_button_frame,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "done", 0 ),
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, folders->done_callback, folders,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "sort", 0 ),
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, folders->persistent_sort_callback, folders,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( bottom_button_frame, "help", 0 ),
                       EZ_CLIENT_INT_DATA, 4,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, buttons->help_callback, buttons,
                       0 );

   folders->dnd = -1;
   folders->update_persistent( folders );

   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));
   EZ_DisplayWidget( folders->frame );
   EZ_SetGrab( folders->frame );

   for( ; ; )
   {
      while( folders->dnd == -1 )
         EZ_WaitAndServiceNextEvent();

      if ( folders->dnd == -2 )
         break;

      folders->update_persistent( folders );
      folders->dnd = -1;
   }

   return;
}

/*
 * Callback of add button on persistent folders frame.
 */

void folders_persistent_add_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ];

   folders = ( np_folders_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)folders->parent )->parent;

   strcpy( buffer, EZ_GetEntryString( folders->folder_entry ));
   if ( !strlen( buffer ))
      return;

   if ( folders->verify( folders, buffer ))
      return;

   snprintf( second_buffer, LN_BUFFER_SIZE, ":%s", buffer );
   if ( ln_add_persistent( second_buffer ))
      lib_error();

   folders->update_persistent( folders );

   return;
}

/*
 * Callback of replace button on persistent folders frame.
 */

void folders_persistent_replace_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;
   np_newsreader_object *newsreader;
   np_newsrc_object *newsrc;

   char *string, buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ],
      third_buffer[ LN_BUFFER_SIZE ];

   int r;

   EZ_Item **selected;


   folders = ( np_folders_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)folders->parent )->parent;
   newsrc = ( np_newsrc_object *)
      (( np_buttons_object *)folders->parent )->newsrc_object;

   EZ_GetFancyListBoxSelectionIdx( folders->list, &r, NULL );

   if ( r == -1 )
   {
      newsrc->confirm( newsrc,
                       "Select a folder in the list\n to replace, first.",
                       NP_DONE );
      return;
   }

   strcpy( buffer, EZ_GetEntryString( folders->folder_entry ));
   if ( !strlen( buffer ))
      return;

   if ( folders->verify( newsrc, buffer ))
      return;
   snprintf( third_buffer, LN_BUFFER_SIZE, ":%s", buffer );

   selected = EZ_GetFancyListBoxSelection( folders->list );
   EZ_GetLabelItemStringInfo( selected[ 0 ], &string, NULL );
   snprintf( second_buffer, LN_BUFFER_SIZE, ":%s", string );

   if ( ln_replace_persistent( second_buffer, third_buffer ))
      lib_error();

   folders->update_persistent( folders );

   return;
}

/*
 * Normal callback of the list box on the persistent folders frame.
 */

void folders_persistent_remove_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;

   char buffer[ LN_BUFFER_SIZE ], *string;

   EZ_Item **item;


   folders = ( np_folders_object *)data;

   item = EZ_GetFancyListBoxSelection( folders->list );

   EZ_GetLabelItemStringInfo( item[ 0 ], &string, NULL );
   snprintf( buffer, LN_BUFFER_SIZE, ":%s", string );

   if ( ln_remove_persistent( buffer ) == -1 )
      lib_error();

   folders->update_persistent( folders );

   return;
}

/*
 * Loads the currently-selected persistent folder's name into the input
 * widget.
 */

void folders_persistent_motion_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;

   EZ_Item **item;

   char buffer[ LN_BUFFER_SIZE ], *string;


   folders = ( np_folders_object *)data;

   item = EZ_GetFancyListBoxSelection( folders->list );
   EZ_GetLabelItemStringInfo( item[ 0 ], &string, NULL );
   strcpy( buffer, string );

   EZ_SetEntryString( folders->folder_entry, buffer );

   return;
}

/*
 * Callback of sort button on persistent folders frame.
 */

void folders_persistent_sort_callback( EZ_Widget *widget, void *data )
{
   np_folders_object *folders;


   folders = ( np_folders_object *)data;

   if ( ln_sort_persistent() )
      lib_error();

   folders->update_persistent( folders );

   return;
}

/*
 * Rereads ~/.peruser3-persistent.
 */

void folders_update_persistent( void *this )
{
   np_folders_object *folders;
   np_newsreader_object *newsreader;

   char buffer[ LN_BUFFER_SIZE ];
   unsigned int i;
   FILE *file;

   EZ_Item *item;
   EZ_TextProperty *prop;

   folders = ( np_folders_object *)this;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)folders->parent )->parent;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-persistent", 
         getenv( "HOME" ));
   if (( file = fopen( buffer, "r" )) == NULL )
      if ( errno != ENOENT )
         fatal_error();
      else
         return;

   EZ_FreezeWidget( folders->list );
   EZ_FancyListBoxClear( folders->list );

   prop = EZ_GetTextProperty( EZ_FONT_NAME, newsreader->medium_font,
                              0 );

   i = 0;
   while( fgets( buffer, LN_BUFFER_SIZE, file ) != NULL )
   {
      item = EZ_CreateLabelItem( strtok( buffer + 1, "\n" ), prop );

      EZ_ItemAddDnDDataEncoder( item, NP_DND_FOLDERS_ATOM, 0,
                                folders->dnd_reorder_encoder, folders,
                                NULL, NULL );
      EZ_ItemAddDnDDataDecoder( item, NP_DND_FOLDERS_ATOM, 0,
                                folders->dnd_reorder_decoder, folders,
                                NULL, NULL );

      EZ_ConfigureItem( item,
                        EZ_CLIENT_INT_DATA, i,
                        EZ_FOREGROUND, "DarkBlue",
                        EZ_TEXT_LINE_LENGTH, 120,
                        0 );

      EZ_FancyListBoxInsertRow( folders->list, &item, 1, ++i );
   }
   fclose( file );

   EZ_UnFreezeWidget( folders->list );

   if ( folders->dnd >= 0 )
      EZ_FancyListBoxSelectItemUsingIdx( folders->list, ++( folders->dnd ),
            0, NULL );

   return;
}
