/*
 *   News Peruser Copyright (c) 1996-1998 James Bailie
 *   ==================================================================
 *
 *   News Peruser is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 2, or (at
 *   your option) any later version.
 *
 *   News Peruser is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *   General Public License for more details.
 *
 *   Although News Peruser is licensed under the Free Software
 *   Foundation's GNU General Public License, Peruser is not produced
 *   by, nor is it endorsed by the Free Software Foundation. The Free
 *   Software Foundation is not responsible for developing,
 *   distributing, or supporting Peruser in any way. Anyone may place
 *   software they own the copyright to, under the GNU General Public
 *   License.
 *
 *   The GNU General Public License is included in the News Peruser 
 *   distribution archive in a file called COPYING. If you do
 *   not have a copy of the license, you can download one from
 *   ftp://prep.ai.mit.edu, or you can write to the Free Software
 *   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 *
 *   =====================================================================
 */

#include "peruser.h"
#include "configure.h"

/* 
 * Constructor.
 */

void configure_init( void *this )
{
   np_buttons_object *buttons;
   np_configure_object *configure;


   buttons = ( np_buttons_object *)this;
   configure = buttons->configure_object;

   configure->parent = buttons;

   configure->callback = configure_callback;
   configure->done_callback = configure_done_callback;
   configure->check_buttons_callback = configure_check_buttons_callback;

   return;
}

/*
 * displays the configure frame.
 */

void configure_callback( EZ_Widget *widget, void *data )
{
   np_configure_object *configure;
   np_newsreader_object *newsreader;
   np_tree_object *tree;
   np_buttons_object *buttons;

   char buffer[ LN_BUFFER_SIZE ];

   unsigned int i, j, on;

   FILE *config;

   EZ_Widget *work_area, *work_frame, *button_frame, 
      *inner_frame, *left_frame, *right_frame;


   configure = ( np_configure_object *)data;
   buttons = ( np_buttons_object *)configure->parent;
   newsreader = ( np_newsreader_object *)buttons->parent;
   tree = ( np_tree_object *)newsreader->tree_object;

   EZ_WaitCursor( newsreader->app_frame, EZ_GetCursor( XC_watch ));
   XFlush( EZ_GetDisplay() );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config", getenv( "HOME" ));
   if (( config = fopen( buffer, "r" )) == NULL )
      if ( errno != 2 )
         fatal_error();

   configure->configure_frame = EZ_CreateFrame( NULL, "General Settings" );

   EZ_ConfigureWidget( configure->configure_frame,
                       EZ_HEIGHT, 600,
                       EZ_WIDTH, 750,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   inner_frame = EZ_CreateFrame( configure->configure_frame, NULL );

   EZ_ConfigureWidget( inner_frame,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   left_frame = EZ_CreateFrame( inner_frame, NULL ); 

   EZ_ConfigureWidget( left_frame,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       EZ_WIDTH, 300,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( left_frame,
                                       "Email address to use in \"From:\""
                                       " header\nof outgoing messages:" ),
                       EZ_HEIGHT, 50,
                       EZ_FONT_NAME, newsreader->bold_font,
                       EZ_LABEL_POSITION, EZ_CENTER,
                       EZ_TEXT_LINE_LENGTH, 40,
                       0 );

   if ( config != NULL )
      fgets( buffer, LN_BUFFER_SIZE, config );
   else
      buffer[ 0 ] = 0;

   configure->email_entry = EZ_CreateEntry( left_frame,
                                            strtok( buffer, "\n" ));

   EZ_ConfigureWidget( configure->email_entry,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 275,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( left_frame,
                                       "Command to launch external "
                                       " text editor:" ),
                       EZ_LABEL_POSITION, EZ_CENTER,
                       EZ_FONT_NAME, newsreader->bold_font,
                       EZ_HEIGHT, 50,
                       EZ_TEXT_LINE_LENGTH, 40,
                       0 );

   if ( config != NULL )
      fgets( buffer, LN_BUFFER_SIZE, config );
   else
      buffer[ 0 ] = 0;

   configure->editor_entry = EZ_CreateEntry( left_frame,
                                             strtok( buffer, "\n" ));

   EZ_ConfigureWidget( configure->editor_entry,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 275,
                       EZ_FONT_NAME, newsreader->medium_font,
                       0 );

   EZ_ConfigureWidget( EZ_CreateLabel( left_frame,
                                       "Numbers of days after which "
                                       "messages\nexpire:" ),
                       EZ_FONT_NAME, newsreader->bold_font,
                       EZ_HEIGHT, 30,
                       EZ_TEXT_LINE_LENGTH, 40,
                       0 );

   configure->expiry_slider = EZ_CreateSlider( left_frame,
                                               NULL, 1.0, 28.0, 1.0, 
                                               EZ_WIDGET_HORIZONTAL_SLIDER );

   EZ_ConfigureWidget( configure->expiry_slider,
                       EZ_FONT_NAME, newsreader->medium_font,
                       EZ_SLIDER_RESOLUTION, 1.0,
                       0 );

   if ( config != NULL )
      fgets( buffer, LN_BUFFER_SIZE, config );
   else
   {
      buffer[ 0 ] = '5';
      buffer[ 1 ] = '\0';
   }

   EZ_SetSliderValue( configure->expiry_slider, atof( buffer ));

   if (( configure->user_entries
         = calloc( tree->servers, sizeof *configure->user_entries )) == NULL )
      fatal_error();

   if (( configure->secret_entries
         = calloc( tree->servers, sizeof *configure->secret_entries ))
         == NULL )
      fatal_error();

   if (( configure->check_buttons
         = calloc( tree->servers, sizeof *configure->check_buttons )) == NULL )
      fatal_error();

   if (( configure->entries_frames
         = calloc( tree->servers, sizeof *configure->entries_frames ))
         == NULL )
      fatal_error();

   if (( configure->configure_labels
         = calloc( tree->servers * 2, sizeof *configure->configure_labels ))
         == NULL )
      fatal_error();

   right_frame = EZ_CreateFrame( inner_frame, NULL );

   EZ_ConfigureWidget( right_frame,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       EZ_WIDTH, 375,
                       EZ_FILL_MODE, EZ_FILL_BOTH,
                       0 );

   work_area = EZ_CreateWorkArea( right_frame, 1, 1 );

   EZ_SetHScrollbarDiscreteSpeed( work_area, 10 );
   EZ_SetVScrollbarDiscreteSpeed( work_area, 10 );

   EZ_ConfigureWidget( work_area,
                       EZ_ITEM_MOVABLE /* sic */, False,
                       0 );

   work_frame = EZ_CreateFrame( NULL, "Authenticating Servers" );

   EZ_ConfigureWidget( work_frame,
                       EZ_ORIENTATION, EZ_VERTICAL,
                       0 );

   EZ_WorkAreaInsertItem( work_area, EZ_CreateWidgetItem( work_frame ));

   j = 0;
   for( i = 0; i < tree->servers; ++i )
   {
      if ( !strncmp( tree->server_list[ i ].server, "Virtual", 7 ) ||
           !strncmp( tree->server_list[ i ].server, "Folders", 7 ) ||
           !strncmp( tree->server_list[ i ].server, "Mailboxes", 9 ))
      {
         configure->entries_frames[ i ] = NULL;
         configure->check_buttons[ i ] = NULL;
         configure->configure_labels[ j ] = NULL;
         configure->configure_labels[ j + 1 ] = NULL;
         configure->user_entries[ i ] = NULL;
         configure->secret_entries[ i ] = NULL;

         continue;
      }

      EZ_ConfigureWidget( EZ_CreateLabel( work_frame, 
                                          tree->server_list[ i ].server ),
                          EZ_FONT_NAME, newsreader->header_font,
                          0 );

      configure->entries_frames[ i ] = EZ_CreateFrame( work_frame, NULL );

      EZ_ConfigureWidget( configure->entries_frames[ i ],
                          EZ_ORIENTATION, EZ_VERTICAL,
                          EZ_WIDTH, 275,
                          EZ_HEIGHT, 160,
                          0 );

      configure->check_buttons[ i ] 
         = EZ_CreateCheckButton( configure->entries_frames[ i ], 
                                 "Authenticating", 50, 1, 0, 0 );

      EZ_ConfigureWidget( configure->check_buttons[ i ],
                          EZ_FONT_NAME, newsreader->bold_font,
                          EZ_FOREGROUND, tree->empty_colour,
                          EZ_CLIENT_INT_DATA, i,
                          EZ_CALLBACK, 
                          configure->check_buttons_callback, configure,
                          0 );

      if ( config == NULL || fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
      {
         buffer[ 0 ] = '0';
         buffer[ 1 ] = '\0';
      }

      EZ_SetCheckButtonState( configure->check_buttons[ i ], 
                              on = atoi( buffer ));

      configure->configure_labels[ j ]
         = EZ_CreateLabel( configure->entries_frames[ i ], "user name:" );

      EZ_ConfigureWidget( configure->configure_labels[ j ],
                          EZ_FONT_NAME, newsreader->medium_font,
                          0 );

      buffer[ 0 ] = '\0';

      if ( config != NULL )
          if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
              buffer[ 0 ] = '\0';

      configure->user_entries[ i ]
         = EZ_CreateEntry( configure->entries_frames[ i ], 
                           strtok( buffer, "\n" ));

      EZ_ConfigureWidget( configure->user_entries[ i ],
                          EZ_WIDTH, 250,
                          EZ_FONT_NAME, newsreader->medium_font,
                          0 );

      configure->configure_labels[ j + 1 ]
         = EZ_CreateLabel( configure->entries_frames[ i ], "password:" );

      EZ_ConfigureWidget( configure->configure_labels[ j + 1 ],
                          EZ_FONT_NAME, newsreader->medium_font,
                          0 );

      if ( config != NULL )
          if ( fgets( buffer, LN_BUFFER_SIZE, config ) == NULL )
              buffer[ 0 ] = '\0';

      configure->secret_entries[ i ]
         = EZ_CreateEntry( configure->entries_frames[ i ], 
                           strtok( buffer, "\n" ));

      EZ_OnOffSecretEntry( configure->secret_entries[ i ], 1 );

      EZ_ConfigureWidget( configure->secret_entries[ i ],
                          EZ_WIDTH, 250,
                          EZ_FONT_NAME, newsreader->medium_font,
                          0 );

      EZ_CreateLabel( work_frame, " _____________ " );

      if ( !on )
      {
         EZ_DeActivateWidget( configure->user_entries[ i ] );
         EZ_DeActivateWidget( configure->secret_entries[ i ] );

         EZ_ConfigureWidget( configure->configure_labels[ j ],
                             EZ_FOREGROUND, tree->empty_colour,
                             0 );
         EZ_ConfigureWidget( configure->configure_labels[ j + 1 ],
                             EZ_FOREGROUND, tree->empty_colour,
                             0 );
      }

      j += 2;
   }

   if ( config != NULL )
      fclose( config );

   button_frame = EZ_CreateFrame( configure->configure_frame, NULL );

   EZ_ConfigureWidget( button_frame,
                       EZ_HEIGHT, 30,
                       EZ_FILL_MODE, EZ_FILL_HORIZONTALLY,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( button_frame, "done", 0 ),
                       EZ_FOREGROUND, "ForestGreen",
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, configure->done_callback, 
                       configure,
                       0 );

   EZ_ConfigureWidget( EZ_CreateButton( button_frame, "help", 0 ),
                       EZ_CLIENT_INT_DATA, 1,
                       EZ_HEIGHT, 30,
                       EZ_WIDTH, 75,
                       EZ_EXPAND, True,
                       EZ_CALLBACK, buttons->help_callback, 
                       buttons,
                       0 );

   EZ_DisplayWidget( configure->configure_frame );
   EZ_SetGrab( configure->configure_frame );

   return;
}

/*
 * Unhides the input widgets for configuring authenticating news servers on
 * the configure frame.
 */

void configure_check_buttons_callback( EZ_Widget *widget, void *data )
{
   unsigned int i, j;
   int state;
   np_configure_object *configure;
   np_newsreader_object *newsreader;


   configure = ( np_configure_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)configure->parent )->parent;

   i = EZ_GetWidgetIntData( widget );
   j = i * 2;

   if ( EZ_GetCheckButtonState( widget, &state ))
   {
      EZ_ConfigureWidget( configure->check_buttons[ i ],
                          EZ_FOREGROUND,
                          newsreader->tree_object->unread_colour,
                          0 );

      EZ_ActivateWidget( configure->user_entries[ i ] );
      EZ_ActivateWidget( configure->secret_entries[ i ] );

      EZ_ConfigureWidget( configure->configure_labels[ j ],
                          EZ_FOREGROUND, 
                          newsreader->tree_object->read_colour,
                          0 );
      EZ_ConfigureWidget( configure->configure_labels[ j + 1 ],
                          EZ_FOREGROUND,
                          newsreader->tree_object->read_colour,
                          0 );
   }
   else
   {
      EZ_ConfigureWidget( configure->check_buttons[ i ],
                          EZ_FOREGROUND, newsreader->tree_object->empty_colour,
                          0 );

      EZ_DeActivateWidget( configure->user_entries[ i ] );
      EZ_DeActivateWidget( configure->secret_entries[ i ] );

      EZ_ConfigureWidget( configure->configure_labels[ j ],
                          EZ_FOREGROUND, 
                          newsreader->tree_object->empty_colour,
                          0 );
      EZ_ConfigureWidget( configure->configure_labels[ j + 1 ],
                          EZ_FOREGROUND,
                          newsreader->tree_object->empty_colour,
                          0 );
   }

   return;
}

/*
 * Rewrites configuration information to ~/.peruser3-config, and destroys
 * configure frame.
 */

void configure_done_callback( EZ_Widget *widget, void *data )
{
   np_configure_object *configure;
   np_newsreader_object *newsreader;
   np_tree_object *tree;

   unsigned int i;
   int state;

   char buffer[ LN_BUFFER_SIZE ];
   FILE *config;


   configure = ( np_configure_object *)data;
   newsreader = ( np_newsreader_object *)
      (( np_buttons_object *)configure->parent )->parent;
   tree = ( np_tree_object *)newsreader->tree_object;

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser3-config", getenv( "HOME" ));
   if (( config = fopen( buffer, "w" )) == NULL )
      fatal_error();

   strcpy( buffer, EZ_GetEntryString( configure->email_entry ));
   if ( strtok( buffer, "\r\n" ) == NULL )
      fputs( "\n", config );
   else
   fprintf( config, "%s\n", buffer );

   strcpy( buffer, EZ_GetEntryString( configure->editor_entry ));
   if ( strtok( buffer, "\r\n" ) == NULL )
      fputs( "\n", config );
   else
   fprintf( config, "%s\n", buffer );

   fprintf( config, "%d\n",
            ( int )EZ_GetSliderValue( configure->expiry_slider ));

   for( i = 0 ; i < tree->servers; ++i )
   {
      if ( configure->check_buttons[ i ] == NULL )
         continue;

      if ( EZ_GetCheckButtonState( configure->check_buttons[ i ],
           &state ))
      {
         strcpy( buffer, EZ_GetEntryString( configure->user_entries[ i ] ));
         fprintf( config, "1\n%s\n", strtok( buffer, "\r\n" ));

         strcpy( buffer, EZ_GetEntryString( configure->secret_entries[ i ] ));
         fprintf( config, "%s\n", strtok( buffer, "\r\n" ));
      }
      else
         fputs( "0\n\n\n", config );
   }

   fclose( config );

   EZ_DestroyWidget( configure->configure_frame );

   free( configure->check_buttons );
   free( configure->user_entries );
   free( configure->secret_entries );
   free( configure->entries_frames );
   free( configure->configure_labels );

   EZ_NormalCursor( newsreader->app_frame );
   XFlush( EZ_GetDisplay() );

   return;
}
