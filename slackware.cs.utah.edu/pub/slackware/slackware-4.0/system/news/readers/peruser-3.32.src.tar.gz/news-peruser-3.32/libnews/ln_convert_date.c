/*
   News Peruser Copyright (c) 1996-1998 James Bailie
   ==================================================================

   News Peruser is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2, or (at
   your option) any later version.

   News Peruser is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   Although News Peruser is licensed under the Free Software
   Foundation's GNU General Public License, Peruser is not produced
   by, nor is it endorsed by the Free Software Foundation. The Free
   Software Foundation is not responsible for developing,
   distributing, or supporting Peruser in any way. Anyone may place
   software they own the copyright to, under the GNU General Public
   License.

   The GNU General Public License is included in the News Peruser 
   distribution archive in a file called COPYING. If you do
   not have a copy of the license, you can download one from
   ftp://prep.ai.mit.edu, or you can write to the Free Software
   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.

   =====================================================================
*/

#include "libnews.h"
#include<sys/types.h>
#include<regex.h>
#include<time.h>

/*
 * Converts a three-letter abbreviation for the name of a month into it's
 * ordinal position in the calendar.
 */

int ln_convert_month( char *buffer )
{
   int month;

   switch( buffer[ 0 ] )
   {
      case 'A':
         switch( buffer[ 1 ] )
         {
            case 'p':
               month = 4;
               break;

            default:
               month = 8;
               break;
         }
         break;

      case 'D':
         month = 12;
         break;

      case 'F':
         month = 2;
         break;

      case 'J':
         switch( buffer[ 1 ] )
         {
            case 'a':
               month = 1;
               break;

            default:
               switch( buffer[ 2 ] )
               {
                  case 'l':
                     month = 7;
                     break;

                  default:
                     month = 6;
                     break;
               }
         }
         break;

      case 'M':
         switch( buffer[ 2 ] )
         {
            case 'r':
               month = 3;
               break;

            default:
               month = 5;
               break;
         }
         break;

      case 'N':
         month = 11;
         break;

      case 'O':
         month = 10;
         break;

      default:
         month = 9;
         break;
   }

   return month;
}

/*
 * Converts common timezone abbreviations into corresponding offset form.
 */

void ln_convert_zone( char *buffer )
{
   /* 
      handles GMT EST EDT CST CDT MST MDT PST PDT, and [-+]hhmm, as per
      rfc 1036
    */

   char *zone;

   if ( buffer[ 0 ] == '+' || buffer[ 0 ] == '-' )
   {
      buffer[ 5 ] = buffer[ 4 ];
      buffer[ 4 ] = buffer[ 3 ];
      buffer[ 3 ] = buffer[ 0 ] = (( buffer[ 0 ] == '+' ) ? '-' : '+' );
      buffer[ 6 ] = '\0';
      return;
   }
   else
      switch( buffer[ 0 ] )
      {
         case 'C':
            switch( buffer[ 1 ] )
            {
               case 'D':
                  zone = "-06-00";
                  break;

               default:
                  zone = "-07-00";
                  break;
            }
            break;

         case 'E':
            switch( buffer[ 1 ] )
            {
               case 'D':
                  zone = "-00-00";

               default:
                  zone = "-06-00";
                  break;
            }
            break;

         case 'G':
            zone = "+00+00";
            break;

         case 'M':
            switch( buffer[ 1 ] )
            {
               case 'D':
                  zone = "-07-00";
                  break;

               default:
                  zone = "-08-00";
                  break;
            }
            break;

         case 'P':
            switch( buffer[ 1 ] )
            {
               case 'D':
                  zone = "-08-00";
                  break;

               default:
                  zone = "-09-00";
                  break;
            }
            break;

         default:
            zone = "unknown";
            break;
      }

   strcpy( buffer, zone );

   return;
}

/*
 * Adjusts any discrete time values out of range.
 */

void ln_adjust_time( int *hours, int *minutes, int *seconds,
                     int *day, int *month, int *year )
{
   if ( *minutes < 0 )
   {
      *minutes += 60;
      ( *hours )--;
   }
   else
      if ( *minutes > 59 )
      {
         *minutes -= 60;
         ( *hours )++;
      }

   if ( *hours < 0 )
   {
      *hours += 24;
      ( *day )--;
   }
   else
      if ( *hours > 23 )
      {
         *hours -= 24;
         ( *day )++;
      }

   if ( *day < 1 )
   {
      switch( *month )
      {
         case 3:
            /* 
               Determine leap year.
               Don't use this program after a hundred years :)
             */

            if ( ( div( *year, 4 )).rem )
               *day = 28;
            else
               *day = 29;

            break;

         case 5:
         case 7:
         case 10:
         case 12:
            *day = 30;
            break;

         default:
            *day = 31;
            break;
      }

      ( *month )--;
   }
   else
      if ( *day > 28 )
      {
         switch( *month )
         {
            case 2:
               if ( ( div( *year, 4 )).rem )
                  *day = 1;
               else
                  *day = 29;

               ( *month )++;
               break;

            case 4:
            case 6:
            case 9:
            case 11:
               if ( *day > 30 )
               {
                  *day -= 30;
                  ( *month )++;
               }
               break;

            default:
               if ( *day > 31 )
               {
                  *day -= 31;
                  ( *month )++;
               }
               break;
         }
      }

   if ( *month < 1 )
   {
      *month += 12;
      ( *year )--;
   }
   else
      if ( *month > 12 )
      {
         *month -= 12;
         ( *year )++;
      }


   return;
}

/*
 * Converts discrete time values to local time.
 */

void ln_convert_localtime( int *hours, int *minutes, int *seconds,
                           int *day, int *month, int *year )
{
   time_t t;
   div_t d;

   time( &t );
   localtime( &t );

   d = div( timezone, 3600 );

   *hours -= d.quot;
   *minutes -= d.rem / 60;

   ln_adjust_time( hours, minutes, seconds, day, month, year );

   return;
}

/*
 * Accepts a Usenet Date header and returns a string of numbers representing
 * the equivalent date in the local timezone, of the form: yyyymmddhhmmss.
 */

int ln_convert_date( char *date, char **converted )
{
   static int compiled = 0;
   static regex_t regex;
   regmatch_t *matches;
   int result;

   char buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ];
   char *wdy, *dd, *mon, *yyyy, *hh, *mm, *ss, *tzn;
   int day, month, year, hours, minutes, seconds;

   /* 
      matches: (Wdy, )?D?D Mon (YY)?YY HH:?MM(:SS)? (TZN|[+-][hhmm])?
    */

   if ( date == NULL )
   {
      if ( compiled ) 
         regfree( &regex );
      compiled = 0;
      return 0;
   }

   if ( !compiled )
   {
      wdy    = "([A-Z][a-z][a-z], +)?";
      dd     = "([0-3]?[0-9]) +";
      mon    = "([A-Z][a-z][a-z]) +";
      yyyy   = "([0-9][0-9])?([0-9][0-9]) +";
      hh     = "([0-2][0-9])";
      mm     = ":?([0-5][0-9])";
      ss     = "(:([0-5][0-9]))?";
      tzn    = "( +[A-Z][A-Z][A-Z]| +[+-][0-2][0-9][0-5][0-9])?";

      strcpy( buffer, wdy );
      strcat( buffer, dd );
      strcat( buffer, mon );
      strcat( buffer, yyyy );
      strcat( buffer, hh );
      strcat( buffer, mm );
      strcat( buffer, ss );
      strcat( buffer, tzn );

      if ( ( result = regcomp( &regex, buffer, REG_EXTENDED )))
      {
         strcpy( ln_error_message, "libnews: ln_convert_date: " );
         regerror( result, &regex, buffer, LN_BUFFER_SIZE );
         strcat( ln_error_message, buffer );
         return 0;
      }

      compiled = 1;
   }

   if (( matches = calloc( regex.re_nsub + 1, sizeof *matches )) == NULL )
      ln_allocation_error();

   if ( ( result = regexec( &regex, date, regex.re_nsub + 1, matches, 0 )))
   {
      strcpy( ln_error_message, "libnews: ln_convert_date: " );
      regerror( result, &regex, buffer, LN_BUFFER_SIZE );
      strcat( ln_error_message, buffer );
         
      if ( result == REG_NOMATCH )
      {
         if (( *converted = strdup( "(unrecognized \"Date:\" header)" )) 
               == NULL )
            ln_allocation_error();

         return -2;
      }
      
      return -1;
   }

   /* discard Wdy */

   strncpy( buffer, date + matches[ 2 ].rm_so, 
            ( result = matches[ 2 ].rm_eo - matches[ 2 ].rm_so ));
   buffer[ result ] = '\0';
   day = atoi( buffer );

   /* month */

   strncpy( buffer, date + matches[ 3 ].rm_so,
         ( result = matches[ 3 ].rm_eo - matches[ 3 ].rm_so ));
   buffer[ result ] = '\0';
   month = ln_convert_month( buffer );

   /* year */

   result = 0;
   buffer[ 0 ] = '\0';
   if ( matches[ 4 ].rm_so > 0 )
   {
      strncpy( buffer, date + matches[ 4 ].rm_so,
               ( result = matches[ 4 ].rm_eo - matches[ 4 ].rm_so ));
      buffer[ result ] = '\0';
   }

   strncat( buffer, date + matches[ 5 ].rm_so,
            ( result += matches[ 5 ].rm_eo - matches[ 5 ].rm_so ));
   buffer[ result ] = '\0';

   if ( ( year = atoi( buffer )) < 100 )
      if ( buffer[ 0 ] == '9' )
         year += 1900;
      else
         year += 2000;

   /* hours */

   strncpy( buffer, date + matches[ 6 ].rm_so,
            ( result = matches[ 6 ].rm_eo - matches[ 6 ].rm_so ));
   buffer[ result ] = '\0';
   hours = atoi( buffer );

   /* minutes */

   strncpy( buffer, date + matches[ 7 ].rm_so,
            ( result = matches[ 7 ].rm_eo - matches[ 7 ].rm_so ));
   buffer[ result ] = '\0';
   minutes = atoi( buffer );

   /* seconds */

   strncpy( buffer, date + matches[ 9 ].rm_so,
            ( result = matches[ 9 ].rm_eo - matches[ 9 ].rm_so ));
   buffer[ result ] = '\0';
   seconds = atoi( buffer );

   /* timezone */

   if ( matches[ 10 ].rm_so > 0 )
   {
      strncpy( buffer, date + matches[ 10 ].rm_so + 1,
               ( result = matches[ 10 ].rm_eo - matches[ 10 ].rm_so - 1 ));
      buffer[ result ] = '\0';
   }
   else
      strcpy( buffer, "GMT" );

   free( matches );

   /* convert to GMT */

   ln_convert_zone( buffer );

   if ( strncmp( buffer, "unknown", 7 ))
   {
      strcpy( second_buffer, buffer );

      strncpy( buffer, second_buffer, 3 );
      buffer[ 3 ] = '\0';

      hours += atoi( buffer );

      strncpy( buffer, second_buffer + 3 , 3 );
      buffer[ 3 ] = '\0';

      minutes += atoi( buffer );

      /* convert to locale time */

      ln_convert_localtime( &hours, &minutes, &seconds, 
                            &day, &month, &year );

      snprintf( buffer, LN_BUFFER_SIZE, "%4d%02d%02d%02d%02d%02d", 
                year, month, day, hours, minutes, seconds );
   }
   else
      strcpy( buffer, " (unknown timezone)" );

   if (( *converted = strdup( buffer )) == NULL )
      ln_allocation_error();

   return 0;
}

/* 
 * Converts a numerical representation of a month into its three-letter
 * abbreviation.
 */

void ln_convert_back_month( int number, char *month )
{
   switch( number )
   {
      case 1:
         strcpy( month, "Jan" );
         break;

      case 2:
         strcpy( month, "Feb" );
         break;

      case 3:
         strcpy( month, "Mar" );
         break;

      case 4:
         strcpy( month, "Apr" );
         break;

      case 5:
         strcpy( month, "May" );
         break;

      case 6:
         strcpy( month, "Jun" );
         break;

      case 7:
         strcpy( month, "Jul" );
         break;

      case 8:
         strcpy( month, "Aug" );
         break;

      case 9:
         strcpy( month, "Sep" );
         break;

      case 10:
         strcpy( month, "Oct" );
         break;

      case 11:
         strcpy( month, "Nov" );
         break;

      case 12:
         strcpy( month, "Dec" );
         break;
   }

   return;
}

/*
 * Renders converted date string into a proper Usenet date header.
 */

int ln_convert_printable( char **date )
{
   char *temp, month[ 4 ], buffer[ 25 ];
   time_t t;
   struct tm *btime;


   if ( !strcmp( *date, " (unknown timezone)" ))
      return -1;

   if (( temp = strdup( *date )) == NULL )
      ln_allocation_error();

   free( *date );

   time( &t );
   btime = localtime( &t );

   buffer[ 0 ] = temp[ 4 ];
   buffer[ 1 ] = temp[ 5 ];
   buffer[ 2 ] = '\0';

   ln_convert_back_month( atoi( buffer ), month );

   /* day */

   buffer[ 0 ] = temp[ 6 ];
   buffer[ 1 ] = temp[ 7 ];
   buffer[ 2 ] = ' ';

   /* month */

   buffer[ 3 ] = month[ 0 ];
   buffer[ 4 ] = month[ 1 ];
   buffer[ 5 ] = month[ 2 ];
   buffer[ 6 ] = ' ';

   /* year */

   buffer[ 7 ] = temp[ 0 ];
   buffer[ 8 ] = temp[ 1 ];
   buffer[ 9 ] = temp[ 2 ];
   buffer[ 10 ] = temp[ 3 ];
   buffer[ 11 ] = ' ';

   /* HH:MM:SS */

   buffer[ 12 ] = temp[ 8 ];
   buffer[ 13 ] = temp[ 9 ];
   buffer[ 14 ] = ':';
   buffer[ 15 ] = temp[ 10 ];
   buffer[ 16 ] = temp[ 11 ];
   buffer[ 17 ] = ':';
   buffer[ 18 ] = temp[ 12 ];
   buffer[ 19 ] = temp[ 13 ];
   buffer[ 20 ] = ' ';
   buffer[ 21 ] = '\0';

   free( temp );

   /* TZN */

   if ( tzname[ btime->tm_isdst ] != NULL )
      strcat( buffer, tzname[ btime->tm_isdst ] );
   else
      strcat( buffer, "(local time)" );

   if (( *date = strdup( buffer )) == NULL )
      ln_allocation_error();

   return 0;
}
