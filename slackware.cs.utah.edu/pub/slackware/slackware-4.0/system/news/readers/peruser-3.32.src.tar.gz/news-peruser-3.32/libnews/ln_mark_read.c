/*
   News Peruser Copyright (c) 1996-1998 James Bailie
   ==================================================================

   News Peruser is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2, or (at
   your option) any later version.

   News Peruser is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   Although News Peruser is licensed under the Free Software
   Foundation's GNU General Public License, Peruser is not produced
   by, nor is it endorsed by the Free Software Foundation. The Free
   Software Foundation is not responsible for developing,
   distributing, or supporting Peruser in any way. Anyone may place
   software they own the copyright to, under the GNU General Public
   License.

   The GNU General Public License is included in the News Peruser 
   distribution archive in a file called COPYING. If you do
   not have a copy of the license, you can download one from
   ftp://prep.ai.mit.edu, or you can write to the Free Software
   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.

   =====================================================================
*/

#include "libnews.h"

/* 
 * Replace the 'u' in the specified group's :read file at the specified line,
 * with a 'r', marking the article seen.
 */

int ln_mark_read( char *group_name, unsigned int ordinal )
{
   char buffer[ LN_BUFFER_SIZE ],
   read_path[ LN_BUFFER_SIZE ],
   temp_path[ LN_BUFFER_SIZE ];

   FILE *read, *temp;


   if ( ordinal < 0 )
   {
      strcpy( ln_error_message,
              "libnews: ln_mark_read: negative message ordinal position." );
      return -1;
   }

   snprintf( read_path, LN_BUFFER_SIZE, 
             "%s/.peruser_spool/%s:read", getenv( "HOME" ), group_name );
   if (( read = fopen( read_path, "r" )) == NULL )
   {
      if ( errno == ENOENT )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_mark_read: read file %s does not exist.",
                   buffer );
         return -2;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_mark_read: could not open file: %s.",
                read_path );
      return -1;
   }

   snprintf( temp_path, LN_BUFFER_SIZE, "%s:temp", read_path );
   if (( temp = fopen( temp_path, "w" )) == NULL )
   {
      fclose( read );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_mark_read: could not open file: %s.",
                temp_path );
      return -1;
   }

   if( !ordinal )
      while( fgets( buffer, LN_BUFFER_SIZE, read ) != NULL )
         fputs( "r\n", temp );
   else
   {
      while( --ordinal )
      {
         if ( fgets( buffer, LN_BUFFER_SIZE, read ) == NULL )
         {
            fclose( read );
            fclose( temp );
            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_mark_read: %s: "
                      "premature end of read file.",
                      group_name );
            return -1;
         }

         fputs( buffer, temp );
      }      

      if ( fgets( buffer, LN_BUFFER_SIZE, read ) == NULL )
      { 
         fclose( read );
         fclose( temp );
         snprintf( ln_error_message, LN_BUFFER_SIZE, 
                   "libnews: ln_mark_read: %s:read: "
                   "premature end of read file.",
                   group_name );
         return -1;
      }
      fputs( "r\n", temp );

      while( fgets( buffer, LN_BUFFER_SIZE, read ) != NULL )
         fputs( buffer, temp );
   }

   fclose( read );
   fclose( temp );

   rename( temp_path, read_path );

   return 0;
}

/*
 * Replace the 'r' in the specified group's :read file at the specified line,
 * with a 'u', marking the article as unseen.
 */

int ln_mark_unread( char *group_name, unsigned int ordinal )
{
   char *home, buffer[ LN_BUFFER_SIZE ], second_buffer[ LN_BUFFER_SIZE ];
   FILE *read, *temp;


   if ( ordinal < 0 )
   {
      strcpy( ln_error_message,
              "libnews: ln_mark_unread: negative message ordinal position." );
      return -1;
   }

   snprintf( buffer, LN_BUFFER_SIZE,
             "%s/.peruser_spool/%s:read", home = getenv( "HOME" ), group_name );
   if (( read = fopen( buffer, "r" )) == NULL )
   {
      if ( errno == ENOENT )
      {
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_mark_unread: read file %s does not exist.",
                   buffer );
         return -2;
      }

      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_mark_read: could not open file %s.",
                buffer );
      return -1;
   }

   snprintf( second_buffer, LN_BUFFER_SIZE, "%s:temp", buffer );
   if (( temp = fopen( second_buffer, "w" )) == NULL )
   {
      fclose( read );
      snprintf( ln_error_message, LN_BUFFER_SIZE,
                "libnews: ln_mark_read: could not open file %s.", 
                second_buffer );
      return -1;
   }

   if ( !ordinal )
      while( fgets( buffer, LN_BUFFER_SIZE, read ) != NULL )
         fputs( "u\n", temp );
   else
   {
      while( --ordinal )
      {
         if ( fgets( buffer, LN_BUFFER_SIZE, read ) == NULL )
         {
            fclose( read );
            fclose( temp );
            snprintf( ln_error_message, LN_BUFFER_SIZE,
                      "libnews: ln_mark_unread: %s:"
                      "premature end of read file.", group_name );
            return -1;
         }

         fputs( buffer, temp );
      }

      if ( fgets( buffer, LN_BUFFER_SIZE, read ) == NULL )
      {
         fclose( read );
         fclose( temp );
         snprintf( ln_error_message, LN_BUFFER_SIZE,
                   "libnews: ln_mark_unread: %s:read:"
                   "premature end of read file.", group_name );
         return -1;
      }

      fputs( "u\n", temp );

      while( fgets( buffer, LN_BUFFER_SIZE, read ) != NULL )
         fputs( buffer, temp );
   }

   fclose( read );
   fclose( temp );

   snprintf( buffer, LN_BUFFER_SIZE, "%s/.peruser_spool/%s:read", home,
             group_name );
   snprintf( second_buffer, LN_BUFFER_SIZE, "%s:temp", buffer );
   rename( second_buffer, buffer );

   return -0;
}




