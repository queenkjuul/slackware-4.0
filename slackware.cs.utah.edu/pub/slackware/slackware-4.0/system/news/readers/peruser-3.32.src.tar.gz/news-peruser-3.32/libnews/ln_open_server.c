/*
   News Peruser Copyright (c) 1996-1998 James Bailie
   ==================================================================

   News Peruser is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2, or (at
   your option) any later version.

   News Peruser is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   Although News Peruser is licensed under the Free Software
   Foundation's GNU General Public License, Peruser is not produced
   by, nor is it endorsed by the Free Software Foundation. The Free
   Software Foundation is not responsible for developing,
   distributing, or supporting Peruser in any way. Anyone may place
   software they own the copyright to, under the GNU General Public
   License.

   The GNU General Public License is included in the News Peruser 
   distribution archive in a file called COPYING. If you do
   not have a copy of the license, you can download one from
   ftp://prep.ai.mit.edu, or you can write to the Free Software
   Foundation, 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.

   =====================================================================
*/

#include "libnews.h"

#include<signal.h>
#include<netinet/in.h>
#include<netdb.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/time.h>
#include<fcntl.h>

/* 
 * Replacement for signal() system call. Tells kernel not to restart system
 * calls interrupted by SIGALRM, and installs a do-nothing handler for
 * SIGALRM.
 */

int ln_signal( int signo, void( *handler )( int signo ))
{
   struct sigaction action;


   action.sa_handler = handler;
   sigemptyset( &action.sa_mask );

   /* 
    * Prevent system calls interrupted by signo from being restarted by the
    * kernel upon return of the signal handler.
    */

   action.sa_flags |= SA_INTERRUPT;

   if ( sigaction( signo, &action, NULL ) == -1 )
   {
      strcpy( ln_error_message, "ln_signal: sigaction failed." );
      return -1;
   }

   return 0;
}

/*
 * Handler for SIGALRM.
 */

void ln_sigalrm_handler( int signo )
{
   /* just interrupt the blocked system call. */

   strcpy( ln_error_message, "SIGLARM!" );
   return;
}

/*
 * Opens TCP connection to specified server address on port 119. Returns
 * a stream pointer associated with the socket in server_stream.
 */

int ln_open_server( char *server, FILE **server_stream, 
                    int ( *callback )( void *data, int expired ), 
                    void *data )
{
   struct hostent *host;
   struct servent *service;
   struct sockaddr_in server_addr;

   int socket_fd, flags, result, seconds, error;
   struct timeval tval;
   fd_set rset, wset;
   

   if ( ( service = getservbyname( "nntp", "tcp" )) == NULL )
   {
      strcpy( ln_error_message, "libnews: ln_open_server: "
              "could not find service entry for \"nntp\" over \"tcp\"." );
      return -1;
   }

   if ( ( host = gethostbyname( server )) == NULL )
   {
      snprintf( ln_error_message, LN_BUFFER_SIZE,
              "libnews: ln_open_server: "
              "could not resolve news server address: %s", server ); 
      return -2;
   }

   if (( socket_fd = socket( PF_INET, SOCK_STREAM, 0 )) == -1 )
   {
      strcpy( ln_error_message,
              "libnews: ln_open_server: socket() call failed." );
      return -1;
   }

   memset( &server_addr, 0, sizeof server_addr );
   server_addr.sin_family = AF_INET;

   /* 
    * Both gethostbyname() and getservbyname() return data in network
    * byte-order.
    */ 

   memcpy( &server_addr.sin_addr, host->h_addr, host->h_length );
   server_addr.sin_port = service->s_port;

   /*
    * Get the current flags settings for the socket file descriptor,
    */

   if (( flags = fcntl( socket_fd, F_GETFL, 0 )) < 0 )
   {
      close( socket_fd );
      strcpy( ln_error_message,
              "libnews: ln_open_server: fcntl F_GETFL failied." );
      return -1;
   }
   
   /*
    * Set the socket non-blocking.
    */

   if ( fcntl( socket_fd, F_SETFL, flags | O_NONBLOCK ) < 0 )
   {
      close( socket_fd );
      strcpy( ln_error_message,
              "libnews: ln_open_server: fcntl F_SETFL failed." );
      return -1;
   }
   
   /*
    * Non-blocking connect.
    */

   if (( result = connect( socket_fd, ( struct sockaddr *)&server_addr,
                           sizeof server_addr )) < 0 )
      if ( errno != EINPROGRESS )
      {
         close( socket_fd );
         strcpy( ln_error_message,
                 "libnews: ln_open_server: connect() failed." );
         return -1;
      }

   /* 
    * if result is zero, connection has completed immediately.
    */

   if ( result )
   {
      /*
       * Wait for connection to complete until LN_SECONDS has expired, 
       * executing callback every second.
       */

      FD_ZERO( &rset );
      FD_SET( socket_fd, &rset );
      wset = rset;
      tval.tv_sec = 0;
      tval.tv_usec = 250000;
      seconds = LN_SECONDS;
      
      while( !( result = select( socket_fd + 1, &rset, &wset, NULL, &tval )))
      {
         FD_ZERO( &rset );
         FD_SET( socket_fd, &rset );
         wset = rset;
         tval.tv_sec = 1;
         tval.tv_usec = 0;

         if ( callback != NULL )
            if ( callback( data, --seconds ))
            {
               close( socket_fd );
               return -10;
            }

         if ( !seconds )
         {
            close( socket_fd );
            strcpy( ln_error_message, "libnews: ln_open_server: timed-out in"
                    " connect()." );
            errno = ETIMEDOUT;
            return -1;
         }
      }

      /*
       * Was there a problem?
       */

      if ( result < 0 )
      {
         strcpy( ln_error_message, 
                 "libnews: ln_open_server: error returned by select()." );
         close( socket_fd );
         return -1;
      }

      /*
       * Are there any errors pending on the socket itself?
       */

      if ( FD_ISSET( socket_fd, &rset ) || FD_ISSET( socket_fd, &wset ))
      {
         unsigned int len = sizeof error;

         if ( getsockopt( socket_fd, SOL_SOCKET, SO_ERROR, &error, &len ) < 0 )
         {
            close( socket_fd );
            strcpy( ln_error_message, 
                    "libnews: ln_open_server: "
                    "an error exists for the socket" );
            return -1;
         }
      }
   }

   /* 
    * Reset the socket_fd status flags.
    */

   if ( fcntl( socket_fd, F_SETFL, flags ) < 0 )
   {
      close( socket_fd );
      strcpy( ln_error_message,
              "libnews: ln_open_server: fcntl F_SETFL failed." );
      return -1;
   }

   /* 
    * Associate a stream with the socket.
    */
   
   if(( *server_stream = fdopen( socket_fd, "r+" )) == NULL )
   {
      strcpy( ln_error_message,
              "libnews: ln_open_server: fdopen() call failed." );
      close( socket_fd );
      return -1;
   }

   /*
    * Rely on the socket send and receive buffers for all our buffering.
    */

   setvbuf( *server_stream, NULL, _IONBF, 0 );

   return 0;
}
