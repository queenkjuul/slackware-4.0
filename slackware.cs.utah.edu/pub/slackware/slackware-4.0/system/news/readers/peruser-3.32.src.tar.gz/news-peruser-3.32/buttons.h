/*
 * Prototypes.
 */

void buttons_init( void *this );
void buttons_destroy( void *this );
void buttons_request_callback( EZ_Widget *widget, void *data );
void buttons_mark_pattern( void *this, void *tree, void *summary, 
                           unsigned int i, unsigned int j, char seen );
void buttons_launch_pattern( void *this, unsigned int i, EZ_Widget *button );
void buttons_pattern_callback( EZ_Widget *widget, void *data );
void buttons_toggle_request( void *this, void *summary_object, char folder,
                             unsigned int i, unsigned int j );
void buttons_navigation_callback( EZ_Widget *widget, void *data );
void buttons_mark_callback( EZ_Widget *widget, void *data );
void buttons_mark_group( void *this, unsigned int i, EZ_Widget *widget );
void buttons_update_node( void *this, unsigned int i );
void buttons_folder_requests_callback( EZ_Widget *widget, void *data );
char *buttons_extract_newsgroup( void *this, unsigned int i );
void buttons_update_folder( void *this, char *folder );
int buttons_compare_subjects( char *one, char *two );
void buttons_request_references( void *this, void *summary_object, char folder,
                                 unsigned int i, unsigned int j );
void buttons_export_callback( EZ_Widget *widget, void *data );
void buttons_file_selector_callback( EZ_Widget *widget, void *data );
void buttons_cancel_callback( EZ_Widget *widget, void *data );
void buttons_decode_callback( EZ_Widget *widget, void *data );
void buttons_decode_selector_callback( EZ_Widget *widget, void *data );

void buttons_unmark_callback( EZ_Widget *widget, void *data );
void buttons_mark_thread( void *this, EZ_Widget *button, unsigned int i );
void buttons_help_callback( EZ_Widget *widget, void *data );
void buttons_help_done_callback( EZ_Widget *widget, void *data );
void buttons_about_callback( EZ_Widget *widget, void *data );
void buttons_about_done_button_callback( EZ_Widget *widget, void *data );

int buttons_get_missing_parts( void *this, uulist *item, char *newsgroup );
void buttons_message_decode_wrapper( EZ_Widget *widget, void *data );
void buttons_go_home_callback( EZ_Widget *widget, void *data );
int buttons_check_for_running_netscape();
void buttons_animate( EZ_Widget *widget, void *data );
void buttons_selectively_disable_interface( void *this );
