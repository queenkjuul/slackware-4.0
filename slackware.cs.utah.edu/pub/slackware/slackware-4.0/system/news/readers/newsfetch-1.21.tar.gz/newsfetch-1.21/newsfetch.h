
#define NEWSFETCHRC ".newsfetchrc"
#define NEWSFETCHLOCK ".newsfetchlock"
#define NEWSFETCH_HEADER_INCL "Newsfetch"
#define COMMAND_GROUP_REPLACE "%s"
#define PROCMAIL_COMMAND "procmail " /*space is important*/
#define PROCMAIL_TMPL ".newsfetchfilter"
#define PROCMAIL_RC ".newsfetchproc"
#define READ_TIMEOUT 600

void defaultRcFile(char *, char *, char *);
void createFd(int, FILE **);
void exit_handler(int );
void pipe_handler(int );
FILE * getNewsFileFd();
FILE * getMailFd();
