#ifndef _SUCK_CHKHISTORY_H
#define _SUCK_CHKHISTORY_H 1

void chkhistory(PMaster);

#endif /* _SUCK_CHKHISTORY_H */
