#ifndef _SUCK_SSORT_H

/* function prototypes */
void ssort(PList *, int, int);
PList my_bsearch(PList *, char *, int);

#endif /* SUCK_SSORT.H */
