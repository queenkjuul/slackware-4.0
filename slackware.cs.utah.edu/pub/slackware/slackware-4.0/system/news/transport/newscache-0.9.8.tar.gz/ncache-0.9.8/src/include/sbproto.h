//#ifndef _sbproto_h_
//#define _sbproto_h_

//extern 
int _IO_putc(...);
//extern 
int _IO_getc(...);
//extern 
int _IO_peekc(...);
//extern 
extern int _IO_seekoff(void*, streamoff o, _seek_dir d, int mode);
//extern 
int _IO_seekpos(...);

//#endif
