#include"Text.h"

void Text::txalloc(int slen) {
  char *ntx;
  int ntxsz;
  
  if(slen>=txsz) {
    ntxsz=(slen+4097)&(~0xfff);
    if(tx) {	  
      if((ntx=(char*)realloc(tx,ntxsz))==NULL) {
	DEBUG(cdbg << "Realloc failed: " << strerror(errno) << endl);
	exit(20);
      }
    } else {
      if((ntx=(char*)malloc(ntxsz))==NULL) {
	DEBUG(cdbg << "Malloc failed: " << strerror(errno) << endl);
	exit(20);
      }
    }
    tx=ntx;
    txsz=ntxsz;
  }
}

int Text::read(istream &is, const char *delim=".") {
  char buf[4096];
  int buflen;
  
  for(;!is.eof();) {
    is.getline(buf,sizeof(buf));
    buflen=strlen(buf);
    if(buflen && buf[buflen-1]=='\r') {
      buf[buflen-1]='\0';
      buflen--;
    }
    
    if(is.eof()||strcmp(buf,delim)==0) break;
    append(buf,buflen);
    while(is.fail() && !is.eof()) {
      // Long line
      is.clear();
      is.getline(buf,sizeof(buf));
      buflen=strlen(buf);
      if(buf[buflen-1]=='\r') buf[buflen-1]='\0';
      append(buf,buflen);
    }
    append("\r\n");
  }
  return txlen;
}
