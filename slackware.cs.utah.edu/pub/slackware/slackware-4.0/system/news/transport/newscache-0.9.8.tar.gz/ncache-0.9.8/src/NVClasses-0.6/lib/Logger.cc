#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#include"Logger.h"

// private:
int Logger::bufresize(int sz) 
{
  int nsz;
  
  /* Round up to the next 4k boundary */
  nsz=(sz+0x1000)&~0xfff;
  if(nsz!=bufsz) {
    /* Add Space */
    if(buf) buf=(char*)realloc(buf,nsz);
    else buf=(char*)malloc(nsz);
    if(!buf) {
      bufsz=0;
      return 0;
    }
    bufsz=nsz;
  }
  return bufsz;
}
  
void Logger::append(const char *s) 
{
  int slen=strlen(s);
  if(bufresize(buflen+slen+1)==0) exit(26);
  strcat(buf,s);
  buflen+=slen;
}

void Logger::print() 
{
  char *nl,*p;
  
  while((nl=strchr(buf,'\n'))!=NULL) {
    // Print first line
    *nl='\0';
    log << buf << endl;
    
    // Move remaining string to the beginning
    nl++;
    p=buf;
    while((*p++=*nl++)!='\0');
  }
  buflen=strlen(buf);
}
  
// public:
Logger::Logger(char *fn=NULL) 
{ 
  buf=NULL; bufsz=0; 
  if(bufresize(1)==0) exit(26);
  buf[0]='\0';
  buflen=0; 
  _priority=Debug;
  _type='?';
  open(fn); 
}

Logger::~Logger() 
{ 
  close(); 
}

void Logger::attach(int fd)
{
  log.attach(fd);
  log.setf(ios::unitbuf);
}

void Logger::open(char *fn) 
{ 
  if(fn) log.open(fn,ios::app); 
  log.setf(ios::unitbuf);
}

void Logger::close() 
{ 
  log.close(); 
}

Logger &Logger::priority(int p) 
{
  _priority=p;
  if(buflen && buf[buflen-1]!='\n') write("\n");
  return *this;
}

Logger &Logger::type(char ch) 
{
  _type=ch;
  if(buflen && buf[buflen-1]!='\n') write("\n");
  return *this;
}

Logger &Logger::write(const char *s) 
{ 
  if(buflen==0 || buf[buflen-1]=='\n') {
    char buf[256];
    sprintf(buf,"%c%d: ",_type,_priority);
    append(buf);
  }
  
  append(s);
  print();
  return *this;
}

// friends:
Logger &operator<<(Logger &l, const char *s)
{
  return l.write(s);
}

Logger &operator<<(Logger &l, String &s)
{
  return l.write((const char*)s);
}

Logger &operator<<(Logger &l, char ch)
{
  return l.write(ch);
}

Logger &operator<<(Logger &l, unsigned int i)
{
  char s[256];
  sprintf(s,"%u",i);
  return l.write(s);
}

Logger &operator<<(Logger &l, int i)
{
  char s[256];
  sprintf(s,"%d",i);
  return l.write(s);
}

