#include"CNewsgroup.h"

Article *CNewsgroup::retrievearticle(unsigned int nbr) 
{
  Article *a;
  try {
    a=_RServer->article(_NewsgroupName,nbr);
  }
  catch (...) {
    return NULL;
  }
  return a;
}

void CNewsgroup::updateoverview(void)
{
  GroupInfo *info;
  unsigned int f,l,i,infof,infol;
  char *lstgrp;
  char fn[MAXPATHLEN];

  if(_mtime+_TTLGroup>=nvtime(NULL)) return;

  NVArray::lock(NVcontainer::ExclLock);
  info=_RServer->groupinfo(_NewsgroupName);
  getsize(&f,&l);
  if((infof=info->first())!=f || (infol=info->last())!=l) {
    if(info->first()<f) {
      // Oops news server's first article number is smaller than our
      // clear database
      NVArray::clear();
    }
    // Set to the new size
    setsize(infof,infol);
  }

  lstgrp=(char*)malloc((infol-infof+1)*sizeof(char));
  memset(lstgrp,0,infol-infof+1);
  if(_RServer->listgroup(_NewsgroupName,lstgrp,infof,infol)<0) {
    VERB(log.p(Logger::Notice) << "RServer::listgroup returned an error - ignored\n"); 
  }
  f=infof;
  while(f<=infol) {
    if((NVArray::shas_element(f) && lstgrp[f-infof]) ||
       (!NVArray::shas_element(f) && !lstgrp[f-infof])) {
      f++;
      continue;
    }
    if(lstgrp[f-infof]) {
      // We do not have this article
      l=f+1;
      for(i=l;i<l+8 && i<=infol;i++) {
	if(!NVArray::shas_element(i) && lstgrp[f-infof]) l=i;
      }
      _RServer->overviewdb(this,f,l);
      f=i;
    } else {
      i=f-infof;
      // We do have this article, but it has been deleted
      if(*(mem_p+arrtab[i]+sizeof(long))==bigarticle) {
	// Remove article from disk
	sprintf(fn,"%s/.art%ud",_SpoolDirectory,i);
	unlink(fn);
      }
      nvfree(arrtab[i]);
      arrtab[i]=0;
      f++;
    }
  }
  _mtime=nvtime(NULL);
  NVArray::lock(NVcontainer::UnLock);
}
