#include<sys/stat.h>
#include<unsitd.h>

int mkpdir(const char *name)
{
  struct stat st;

  if(stat(buf,&st)<0) {
    if(errno!=ENOENT) return -1;
    if(mkpdir(buf,0777)<0) return -1;
  } else {
    if(!S_ISDIR(st.st_mode)) {
      errno=ENOTDIR;
      return -1;
    }
  }
}
