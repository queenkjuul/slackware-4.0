#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<unistd.h>

#include<iostream.h>

#include"Configure.h"
#include"Config.h"
#include"NServer.h"

const char *prop="-\\|/-\\|/";

Config Cfg;
CServer *rs;

TRACE(ofstream ctrace("trace"));
DEBUG(ofstream cdbg("debug"));

int readgroup(GroupDesc *gd, int cfst, int clst)
{
  char ofn[256];
  ofstream ofs;

  XOverDB *xodb;
  Article *a;
  XOverDBIter xodbit;
  int firstnbr, lastnbr,n=0;
  
  cout << gd->name() << ": Xover\r";
  sprintf(ofn,"%s/.xodb",(const char*)gd->name());
  ofs.open(ofn);
  xodb=myserv->xoverdb(gd->first(),gd->last());
  ofs << *xodb;
  ofs.close();
  
  // Set first and last article number to retrieve;
  firstnbr=clst+1;
  if(gd->first()>firstnbr) firstnbr=gd->first();
  if(gd->first()<cfst) {
    cerr << gd->name() << ": Server's first index smaller than read index\n";
    firstnbr=gd->first();
  }
  lastnbr=gd->last();

  if(lastnbr<firstnbr) return n;

  for(xodbit.attach(*xodb);xodbit.valid();xodbit.next()) {
    String nbr;  
    int i;
    
    nbr=xodbit().before(RXwhite);
    i=atoi((const char*)nbr);
    if(firstnbr<=i && i<=lastnbr) {
      cout << "  Article " << i << "\r";
      try {
	a=myserv->article(i);
	sprintf(ofn,"%s/a%d",(const char*)gd->name(),i);
	ofs.open(ofn);
	ofs << *a;
	ofs.close();
	n++;
      }
      catch (ResponseErr &r) {
	cerr << "Caught!\n";
	// If bad article number, just skip
	if(r._got.before(3)!="423") throw;
      }
      catch (...) {
	TRACE(ctrace << "Ooops, Skipping\n");
	DEBUG(cdbg << "Ooops, Skipping\n");
	cout << "Ooops, Skipping\n";
      }
    }
  } /* for */

  return n;
}

main(int argc, char **argv)
{
TRACE(ctrace.setf(ios::unitbuf));
DEBUG(cdbg.setf(ios::unitbuf));
  GroupList *gl;
  GroupDesc *gd;
  XOverDB *xodb;

  char ofn[256];
  ofstream ofs;
  ifstream ifs;
  ofstream gfs;

  String line;

  if(argc>2) {
    cerr << "Usage: " << argv[0] << " [Config-File]\n";
    exit(1);
  }
  if(argc==1) Cfg.read("etc/newscache.conf");
  else Cfg.read(argv[1]);

  if ((rs=new RServer(Cfg.SpoolDir,Cfg.NewsServer,Cfg.NNTPPort))==NULL) {
    cerr << "Failed to create RServer\n";
    exit(1);
  }
  chdir(Cfg.SpoolDir);
  
  // Retrieve Active File
  cout << "Retrieving .active \n";
  ofs.open(".active");
  gl=myserv->list();
  ofs << *gl;
  ofs.close();

  // Retrieve requested newsgroups
  rename(".newsrc",".oldnewsrc");
  gfs.open(".newsrc",ios::out);
  ifs.open(".oldnewsrc",ios::in);
  //  ifs.unsetf(ios::skipws);

  while(readline(ifs,line) && ifs.good()) {
    String grp,s;
    int i,j,cfst,clst;

    if(line[0]=='#') continue;

    cfst=clst=0;
    i=line.index(':');
    if(i!=-1) {
      grp=line.before(i);
      if((j=line.index('-'))!=-1) {
	cfst=atoi(s=line.after(i));
	clst=atoi(s=line.after(j));
      }
    } else {
      grp=line;
    }

    cout << grp << ": Select\r";
    sprintf(ofn,"%s",(const char*)grp);
    mkdir(ofn,0777);
    gd=myserv->group((const char*)grp);
    gfs << grp << ": " << gd->first() << "-" << gd->last() << endl;
    cout << grp << ": " << gd->first() << "-" << gd->last() << "\t\n";

    if(gd->n) {
      // New articles arrived
      int n;

      n=readgroup(gd,cfst,clst);
      cout << grp << ": Read " << n << " Articles\n";
    } else {
      cout << grp << ": " << gd->first() << "-" << gd->last() << "\t\n";
    } // if(gd->n)
  }
  ifs.close();
  gfs.close();
}
