#ifndef __XOverDB_h__
#define __XOverDB_h__

#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/file.h>
#include<unistd.h>
#include<utime.h>
#include<errno.h>
#include<time.h>
#include<fcntl.h>
#include<stdlib.h>

#include<iostream.h>
#include<fstream.h>

#include"Configure.h"
#include"NVList.h"
#include"OverviewFmt.h"

class NVOverviewDB : NVList {
//  friend class NVOverviewDBIter;
public:
  OverviewFmt xoverfmt;

  NVOverviewDB() : NVList() {}
  NVOverviewDB(const char *dbname) : NVList(dbname) {}

  int lock(int command, int block=Block) { 
    return NVList::lock(command,block); 
  }
  int get_lock(void) { 
    return NVList::get_lock(); 
  }
  
  void open(const char *dbname) { 
    NVList::open(dbname); 
  }
  int is_open(void) { 
    return NVList::is_open(); 
  }
  void close(void) {
    NVList::close();
  }

  void setmtime(unsigned long tm, int force=0) {
    NVList::setmtime(tm,force);
  }
  void getmtime(unsigned long *tm) {
    NVList::getmtime(tm);
  }

  void clear(void) {
    NVList::clear();
  }
  int is_empty(void) {
    return NVList::is_empty();
  }

  void select(const char *dbname) { open(dbname); }

  void read(istream &is, OverviewFmt *rxo=NULL);
  void xhdr(ostream &os, const char *hdr, unsigned int fst=1, unsigned int lst=0);
  void write(ostream &os, unsigned int fst=1, unsigned int lst=0);

  void expire(unsigned int fst, unsigned int lst);

  unsigned int firstid();
  unsigned int lastid();

  friend ostream& operator<<(ostream& os, NVOverviewDB &odb) { 
    odb.write(os); return os; 
  }
};

/*
class NVOverviewDBIter {
  NVListIter nvli;
public:
  XOverDBIter() {}
  XOverDBIter(XOverDB &xodb) : nvli(xodb.nvl) {}
  void attach(XOverDB &xodb) { nvli.attach(xodb.nvl); }
  void first() { nvli.first(); }
  void next() { nvli.next(); }
};
*/

#endif
