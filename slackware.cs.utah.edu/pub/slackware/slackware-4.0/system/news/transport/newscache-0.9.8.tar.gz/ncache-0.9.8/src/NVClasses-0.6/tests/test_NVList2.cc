#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "NVList.h"

int main(int argc, char *argv[])
{
  const char *txt;
  char buf[1024];
  int i,j;

  if(argc!=3) {
    cerr << "Usage: " << argv[0] << " Text Count\n";
    exit(1);
  }

  txt=argv[1];
  j=atoi(argv[2]);

  NVList nvl("/tmp/nvl");
  for(i=0;i<j;i++) {
    sprintf(buf,"%s(%d/%d)",txt,i,j);
    nvl.append(buf,strlen(buf)+1);
  }
  nvl.close();
  return 0;
}
