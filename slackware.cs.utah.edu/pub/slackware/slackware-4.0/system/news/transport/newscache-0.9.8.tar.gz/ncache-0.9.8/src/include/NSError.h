#ifndef _NSError_h_
#define _NSError_h_

#include"Debug.h"
#include"Logger.h"

#include<stdlib.h>
#include<string.h>
#include<errno.h>

#include<String.h>
#include<Error.h>

/* Error-classes 
 */

/* NSError: ErrorCodes 
 * 423 No such article
 * 411 No such newsgroup
 */
class NSError: public Error {
public:
  int _errnbr;
  NSError(const char *txt, int errnbr=-1)
    : Error(txt)
  {
    _errnbr=errnbr; print();
  }
  void print() {
    if(_errnbr!=-1) {
      VERB(log.p(Logger::Critical)
	   << "  Type: NServer\n" 
	   << "  Error: " << _errnbr << "\n");
    } else {
      VERB(log.p(Logger::Critical)
	   << "  Type: NServer\n" 
	   << "  Error: ???\n");
    }
  }    
};

class ResponseErr: public Error {
public:
  String _command;
  String _got;
  String _expected;
  ResponseErr() {}
  ResponseErr(const char *command, const char *exp, const char *got) {
    _command=command;
    _got=got;
    _expected=exp;
    VERB(log.p(Logger::Critical)
	 << "  Type: Response\n"
	 << "  Command: " << command << "\n"
	 << "  Answer: " << got << "\n"
	 << "  Exp: " << exp << "\n");
  }
};

class UsageErr: public Error {
public:
  int _errnbr;
  UsageErr(const char *errtext, int errnbr=0)
    : Error(errtext)
  {
    if(errnbr) _errnbr=errnbr;
    else _errnbr=atoi(_errtext);
    VERB(log.p(Logger::Critical)
	 << "  Type: Usage\n"
	 << "  Code: " << _errnbr << "\n");
  }
};

#endif
