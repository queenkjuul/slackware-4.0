/* lserver.cc (c) 1996 by Thomas GSCHWIND 
 * -- implements a news server in combination with the provided library.
 * -- the following kinds of news servers are provided:
 * -- remote, local, caching news server
 *
 * This software may be freely redistributed as long as this copyright
 * issue is included without any modifications. Any commercial use
 * without the author's prior consent is prohibited.
 *
 * This software is provided as is without warranty of any kind, either
 * expressed or implied, including, but not limited to, the implied
 * warranties of merchantibility and fitness for a particular purpose.
 *
 * As soon as I release the version 1.0, I will put it under the 
 * GNU General Public License.
 */
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <iostream.h>

#include "Configure.h"
#include "Config.h"
#include "NServer.h"
#include "Logger.h"

//Notes {
// Config �berarbeiten. Bei Syntaxfehler beenden. 
// Switch ?-d? der nur Config einliest und ausgibt.
//} Notes

VERB(Logger log);
const char *cmnd;
Config Cfg;
char ServerRoot[MAXPATHLEN];
int Xsignal;

/* nnrpd(fd)
 */
void sendq(void)
{
  CServer cs(Cfg.SpoolDir);
  MPList *mpl=&(Cfg.srvrs);
  int i;

  cs.setttl(Cfg.ttl_list,Cfg.ttl_desc,Cfg.ttl_group);
  for(i=0;i<mpl->e_used;i++) {
    GroupInfo *gi;
    MPListEntry *mpe;
    NVActiveDB *active;
    char fn[MAXPATHLEN],group[1024];
    int fst,lst;
    ifstream ifs;
    ofstream ofs;

    // Ignore NoServer statements
    if(mpl->entries[i].nserver[0]=='\0') continue;
    cs.setserver(mpl->entries[i].nserver,
		 mpl->entries[i].nport);
    // Active Database
//     active=rs.active(mpl->entries[i].nserver,mpl);
    active=cs.active();

    // Send article queue
    cs.postq();

    // Open the newsgroups-file and retrieve all the unread articles
    ifs.open(Cfg.PrefetchFile);
    sprintf(fn,"%s.new",Cfg.PrefetchFile);
    ofs.open(fn);
    for(;;) {
      ifs >> group >> fst >> lst;
      if(ifs.eof()) break;
      if(group[0]=='!') continue;
      if(ifs.bad()) {
	VERB(log.p(Logger::Error) << "Error reading from " 
                                  << Cfg.PrefetchFile);
	break;
      }
      mpe=Cfg.server(group);
      if(strcmp(mpe->nserver,mpl->entries[i].nserver)==0 &&
	 strcmp(mpe->nport,mpl->entries[i].nport)==0) {
	try {
	  gi=cs.prefetch(group,fst,lst);
	}
	catch(...) {
	  VERB(log.p(Logger::Error) << "Cannot prefetch " 
	                            << group << "\n");
	}
      }
      ofs << group << " " << 1 << " " << gi->last() << endl;
    }
    ofs.close();
    ifs.close();
  }
  return;
}

void catchsignal(int num)
{
  Xsignal=num;
}

main(int argc, char **argv)
{
  char buf[256];
  time_t t;
  pid_t p;
  int ai=1;
  int use_inetd=0;

  strcpy(ServerRoot,CONF_ServerRoot);
  chdir(ServerRoot);

  time(&t);
  p=getpid();
  VERB(sprintf(buf,"Trace-%ld-%d-sendq",t,p);
       log.attach(2);
       log.p(Logger::Info) << "sendq started\n");

  cmnd=argv[0];
  if(argc>2) {
    cerr << "Usage: " << cmnd << " [Config-File]\n";
    exit(1);
  }
    
  if(argc<=ai) Cfg.read("etc/newscache.conf");
  else Cfg.read(argv[ai]);

  // signal
  Xsignal=-1;
  signal(SIGHUP,catchsignal);
  signal(SIGTERM,catchsignal);

  // Check the queue in each server-directory and send it off to the 
  // news server
  sendq();
  cout << "Ready.\n";
}
