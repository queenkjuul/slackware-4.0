//#include "sbproto.h"
#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "NVList.h"

const char *h="Hello World!";

int main(int argc, char *argv[])
{
  char buf[256];
  char c;

  cout << argv[0] << "/" << argc << ":\n";

  NVList nvl("/tmp/nvl");
  do {
    cin >> c;
    switch(c) {
    case 'a':
    case 'A':
      int i,j;
      
      if(c=='A') cin >> j;
      else j=64;
      
      if(j>0) {
	nvl.append(h,strlen(h)+1);
	for(i=1;i<j;i++) {
	  sprintf(buf,"This is the %dth piece of junk!",i);
	  nvl.append(buf,strlen(buf)+1);
	}
      }
      break;
    case 'p':
      nvl.print(cout);
      break;
    case 'r':
      nvl.remove();
      break;
    case 'q':
      break;
    case 'h':
    default:
      cout << "a ...... add some items\n" 
	   << "A #n ... add n items\n"
	   << "h ...... help\n"
	   << "p ...... print\n"
	   << "r ...... remove an item\n"
	   << "q ...... quit\n";
    }
    if(cout.bad()) {
      cout.clear();
    }
  } while(c!='q');
  nvl.close();
  return 0;
}
