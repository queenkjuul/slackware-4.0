#ifndef _MPList_h_
#define _MPList_h_
#include <ctype.h>
#include <malloc.h>
#include <stdio.h>

#include <iostream.h>
#include <fstream.h>

#include "Debug.h"
#include "Error.h"

#define MPListBIGBUFF 10240
#define MPListCHKBIGBUFF(x) if((x)==MPListBIGBUFF) { cerr << "Increase MPListBIGBUFF\r\n"; exit(1); }


struct MPListEntry {
public:
  enum { 
    F_READ=0x01, 
    F_POST=0x02 
  };
  char hostname[1024];
  char servicename[256];
  char groups[2048];
  int flags;

  void init(const char *ns, 
	    const char *np, 
	    const char *g, 
	    int f=F_READ|F_POST) {
    if(ns) strcpy(hostname,ns);
    else hostname[0]='\0';
    if(np) strcpy(servicename,np);
    else servicename[0]='\0';
    strcpy(groups,g);
    flags=f;
  }
  void clear() { 
    init(NULL,NULL,NULL); 
  }
};

class MPList {
public:
  char _AllNewsgroups[MPListBIGBUFF];
  struct MPListEntry *entries;
  int e_used;

private:
  int e_alloc;
  void myrealloc(int sz) {
    int nsz=(sz+0x10)&(~0xf);
    if(entries) {
      entries=(MPListEntry*)realloc(entries,nsz*sizeof(struct MPListEntry));
    } else {
      entries=(MPListEntry*)malloc(nsz*sizeof(struct MPListEntry));
    }
    if(entries==NULL) {
      throw SystemError("malloc or realloc failed",errno);
    }
    e_alloc=nsz;
  }

public:
  MPList() { entries=NULL; e_alloc=0; e_used=0; _AllNewsgroups[0]='\0'; }
  
  void addserver(const char *ns,const char *p,const char *g) {
    int i,j;
    if(e_used==e_alloc) myrealloc(e_used+1);
    entries[e_used].init(ns,p,g);
    e_used++;
    i=strlen(_AllNewsgroups); j=0;
    MPListCHKBIGBUFF(i);
    _AllNewsgroups[i++]=',';
    MPListCHKBIGBUFF(i);
    while((_AllNewsgroups[i++]=g[j++])!='\0') MPListCHKBIGBUFF(i);
  }

  MPListEntry *server(const char *group);
  void read(ifstream &ifs);    

  void dump(ostream &ofs) {
    int i;
    ofs << "  MPList {\n";
    for(i=0;i<e_used;i++) {
      if(entries[i].hostname[0]) {
	ofs << "    Server   \t"
	    << entries[i].hostname << '\t'
	    << entries[i].servicename << '\t'
	    << entries[i].groups << endl;
      } else {
	ofs << "    NoServer \t" << entries[i].groups << endl;
      }
    }
    ofs << "  }\n";
  }
    
};

#endif
