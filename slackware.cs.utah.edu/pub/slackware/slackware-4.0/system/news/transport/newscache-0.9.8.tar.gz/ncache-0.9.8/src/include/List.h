#ifndef __List_h__
#define __List_h__

#include<iostream.h>
#include<String.h>

struct ListElement_base {
  ListElement_base *next;
  ListElement_base(ListElement_base *n=NULL): next(n) {}
  virtual ~ListElement_base() {}
};

class List_base {
protected:
  ListElement_base *_last;

  ListElement_base *sget() {
    ListElement_base *entry=_last->next;
    if(_last==_last->next) {
      _last=NULL;
      return entry;
    } else {
      _last->next=entry->next;
      return entry;
    }
  }
public:
  List_base() { _last=NULL; }
  ~List_base() { clear(); }
  void clear() { while(_last) delete sget(); }
  int empty() {
    return _last==NULL;
  }
  void append(ListElement_base *entry) {
    if(_last) {
      entry->next=_last->next;
      _last->next=entry;
      _last=_last->next;
    } else {
      _last=entry;
      _last->next=_last;
    }
  }
  void insert(ListElement_base *entry) {
    if(_last) {
      entry->next=_last->next;
      _last->next=entry;
    } else {
      _last=entry;
      _last->next=_last;
    }
  }
  ListElement_base *get() {
    if(_last==NULL) exit(1);
    // throw ListUnderflow();
    return sget();
  }
  friend class ListIter_base;
};

class ListIter_base {
  List_base *lst;
  ListElement_base *el;
public:
  ListIter_base() { lst=NULL; el=NULL; }
  ListIter_base(List_base &lb) { attach(lb); }
  void attach(List_base &lb) { lst=&lb; first(); }
  void first() {
    if(lst->_last) el=lst->_last->next;
    else el=NULL;
  }
  void next() {
    if(el) if(el->next!=lst->_last->next) el=el->next;
    else el=NULL; 
  }
  int valid() { return el!=NULL; }
  ListElement_base *operator() () { return el; }  
};

template<class Tdata> struct ListElement: ListElement_base {
  Tdata data;
  ListElement(Tdata d): data(d) {}
};

template<class Tdata>class List: public List_base {
protected:
public:
  void append(Tdata &data) {
    List_base::append(new ListElement<Tdata>(data));
  }
  void insert(Tdata &data) {
    List_base::insert(new ListElement<Tdata>(data));
  }
  Tdata get() {
    ListElement<Tdata> *el=(ListElement<Tdata>*)List_base::get();
    Tdata data=el->data;
    delete el;
    return data;
  }
  Tdata &first() {
    return ((ListElement<Tdata>*)(_last->next))->data;
  }
  Tdata &last() {
    return ((ListElement<Tdata>*)(_last))->data;
  }

  friend ostream& operator<<(ostream& os, List &list) {
    ListElement<Tdata> *p=(ListElement<Tdata>*)list._last;
    
    if(!p) return os;
    do {
      p=(ListElement<Tdata>*)p->next;
      os << p->data;
    } while(p!=(ListElement<Tdata>*)(list._last));

    return os;
  }

  friend class ListIter<Tdata>;
};

template<class Tdata> class ListIter: public ListIter_base {
public:
  ListIter(): ListIter_base() {}
  ListIter(List<Tdata> &lb): ListIter_base(lb) {}
  Tdata &operator() () { 
    return ((ListElement<Tdata>*)ListIter_base::operator()())->data;
  }
};

int nlreadline(istream &is,             // Input-Stream
	       String &strg,            // String to store line
	       int keepnl=1             // Keep newline
	       );

int readtext(istream &is,               // Input-Stream
	     List<String> &SList,       // List to store the text
	     int keepnl=1,              // Keep newlines in text
	     char *eot=".\n"            // EndOfText Marker
	     );

int readtext(istream &is,               // Input-Stream
	     String &Strg,              // String to store the text
	     int keepnl=1,              // Keep newlines in text
	     char *eot=".\n"            // EndOfText Marker
	     );

#endif
