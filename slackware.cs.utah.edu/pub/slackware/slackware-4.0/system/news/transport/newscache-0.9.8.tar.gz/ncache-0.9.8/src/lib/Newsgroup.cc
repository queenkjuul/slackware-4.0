#include"Newsgroup.h"

Newsgroup::~Newsgroup() 
{
}
