#include <iostream.h>

#include "Debug.h"
#include "Config.h"

Config mycfg;

int main(int argc, char *argv[])
{
  if(argc!=2) {
    cerr << "Usage: " << argv[0] << " ConfigFile\n";
  }

  mycfg.read(argv[1]);
  mycfg.dump(cout);
  
  return 0;
}
