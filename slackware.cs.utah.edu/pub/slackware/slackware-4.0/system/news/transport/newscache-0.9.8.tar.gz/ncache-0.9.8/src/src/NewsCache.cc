/* lserver.cc (c) 1996 by Thomas GSCHWIND 
 * -- implements a news server in combination with the provided library.
 * -- the following kinds of news servers are provided:
 * -- remote, local, caching news server
 *
 * This software may be freely redistributed as long as this copyright
 * issue is included without any modifications. Any commercial use
 * without the author's prior consent is prohibited.
 *
 * This software is provided as is without warranty of any kind, either
 * expressed or implied, including, but not limited to, the implied
 * warranties of merchantibility and fitness for a particular purpose.
 *
 * As soon as I release the version 1.0 will put it under the 
 * GNU General Public License.
 */
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <time.h>
#include <limits.h>

#include <iostream.h>

#include "NServer.h"
#include "Newsgroup.h"

#include "setugid.h"
#include "Configure.h"
#include "Config.h"
#include "Logger.h"

//Notes {
// Config �berarbeiten. Bei Syntaxfehler beenden. 
// Switch ?-d? der nur Config einliest und ausgibt.
//} Notes

VERB(Logger log);
const char *cmnd;
Config Cfg;
char ServerRoot[MAXPATHLEN];
int Xsignal;

typedef struct ClientData {
  istream *ci;
  ostream *co;

  CServer *srvr;
  char groupname[MAXGROUPNAMELEN];
  Newsgroup *grp;
  int nbr;
};

int selectgroup(ClientData *clt) 
{
  if(!clt->grp) {
    if((clt->grp=clt->srvr->getgroup(clt->groupname))==NULL) return -1;
  }
  return 0;
}

// Article 
int ns_article(ClientData *clt,int argc,char *argv[])
{
  if(clt->groupname[0]=='\0') {
    (*clt->co) << "412 no newsgroup has been selected\r\n";
    return -1;
  }
  //FIX! Retrieving an article by msg-id is currently not 
  //FIX! implemented
  //FIX! We do not check the 2nd argument correctly
  if(argc>2) {
    switch(argv[0][0]) {
    case 'a':
      (*clt->co) << "501 Syntax: article [nbr]\r\n";
      return -1;
    case 's':
      (*clt->co) << "501 Syntax: stat [nbr]\r\n";
      return -1;
    }
  }
  if(selectgroup(clt)<0) {
    (*clt->co) << "411 no such news group\r\n";
    return -1;
  }

  if(argc==1 && clt->nbr<0) {
    (*clt->co) << "420 no current article has been selected\r\n";
    return -1;
  }

  int nbr=(argc==2)?atoi(argv[1]):clt->nbr;
  Article *a;
  const char *aid;

  ASSERT(clt->grp->testdb());
  if((a=clt->grp->getarticle(nbr))==NULL) {
    (*clt->co) << "423 no such article number in this group\r\n";
    return -1;
  }

  aid=a->getfield("Message-ID:");
  clt->nbr=nbr;
  
  switch(argv[0][0]) {
  case 'a':
    (*clt->co) << "220 " << nbr << " " << aid 
	       << " article retrieved - head and body follow\r\n";
    (*clt->co) << *a << ".\r\n";
    //FIX! CosmeticFix: provide an <<-operator for unsigned int
    VERB(log.p(Logger::Info) << nbr << ": " << a->length() << "Bytes\n");
    break;
  case 's':
    (*clt->co) << "223 " << nbr << " " << aid 
	       << " article retrieved - request text separately\r\n";
    break;
  }
  clt->grp->freearticle(a);
  return 0;
}

/*
 */
int ns_date(ClientData *clt,int argc,char *argv[])
{
  struct timeval tv;
  struct timezone tz;
  struct tm *ltm;
  time_t conv;
  char buf[256];

  if(argc!=1) {
    (*clt->co) << "501 Syntax: group Newsgroup\r\n";
    return -1;
  }

//   if(gettimeofday(&tv,&tz)<0) {
//     (*clt->co) << "500 gettimeofday failed\r\n";
//     return -1;
//   }
  time(&conv);
  if((ltm=localtime(&conv))==NULL) {
    (*clt->co) << "500 localtime failed\r\n";
    return -1;
  }
  sprintf(buf,"111 %04d%02d%02d%02d%02d%02d\r\n",
	  1900+ltm->tm_year,ltm->tm_mon,ltm->tm_mday,
	  ltm->tm_hour,ltm->tm_min,ltm->tm_sec);
  (*clt->co) << buf;

  return 0;
}

/* Group name
 * Find the news server responsible for this newsgroup.
 * Connect to it and select the newsgroup.
 */
int ns_group(ClientData *clt,int argc,char *argv[])
{
  if(argc!=2) {
    (*clt->co) << "501 Syntax: group Newsgroup\r\n";
    return -1;
  }

  GroupInfo *gi;
  if((gi=clt->srvr->groupinfo(argv[1]))==NULL) {
    (*clt->co) << "411 no such news group\r\n";
    return -1;
  }
  clt->nbr=(gi->first()<=gi->last())?gi->first():-1;
  if(strcmp(clt->groupname,argv[1])!=0) {
    if(clt->grp) clt->srvr->freegroup(clt->grp);
    clt->grp=NULL;
    strcpy(clt->groupname,argv[1]);
  }
  (*clt->co) << "211 " 
	     << gi->n() << " " 
	     << gi->first() << " " 
	     << gi->last() << " "
	     << gi->name() << " group selected\r\n";
  VERB(log.p(Logger::Info) << (const char*)gi->name() << " "
                           << gi->n() << " " 
                           << gi->first() << " " 
                           << gi->last() 
                           << "\n");
  return 0;
}

/* help
 * lists the available commands
 */
int ns_help(ClientData *clt,int argc,char *argv[])
{
  
  argc=0;
  argv=NULL;

  (*clt->co) << "100 Legal commands\r\n"
	     << "  article [Number]\r\n"
	     << "  body [Number]\r\n"
	     << "  group newsgroup\r\n"
	     << "  head [Number]\r\n"
	     << "  help\r\n"
	     << "  list [active|overview.fmt]\r\n"
	     << "  listgroup [newsgroup]\r\n"
	     << "  mode reader\r\n"
	     << "  stat [Number]\r\n"
	     << "  xover [range]\r\n"
	     << "Report problems to <gschwind@complang.tuwien.ac.at>\r\n"
	     << ".\r\n";
  return 0;
}

/* List [active|newsgroups|overview.fmt]
 * List the specified data
 */
int ns_list(ClientData *clt,int argc,char *argv[])
{
  //FIX! list active [WILDMAT] not supported
  //FIX! list newsgroups currently returns an empty list
  if(argc<3) {
    if(argc==1 || strcasecmp(argv[1],"active")==0) {
      ActiveDB *active=clt->srvr->active();
      (*clt->co) << "215 List of newsgroups (Group High Low Flags) follows\r\n";
      active->write((*clt->co));
      (*clt->co) << ".\r\n";
      return 0;
    } else if(strcasecmp(argv[1],"active.times")==0) {
      ActiveDB *active=clt->srvr->active();
      active->write((*clt->co),0,NVActiveDB::m_times);
      (*clt->co) << ".\r\n";
      return 0;
    } else if(strcasecmp(argv[1],"newsgroups")==0) {
      (*clt->co) << "215 Don't have any data.\r\n.\r\n";
      return 0;
    } else if(strcasecmp(argv[1],"overview.fmt")==0) {
      (*clt->co) << "215 Order of fields in overview database\r\n"
	         << *(clt->srvr->overviewfmt()) << ".\r\n";
      return 0;
    }
  }

  (*clt->co) << "501 Syntax: list [active|active.times|newsgroups|overview.fmt]\r\n";
  return -1;
}

/* listgroup
 * Listgroup only works for groups, where the overview
 * database has already been cached!
 */
int ns_listgroup(ClientData *clt,int argc,char *argv[])
{
  if(argc>2) {
    (*clt->co) << "501 Syntax: listgroup [Newsgroup]\r\n";
    return -1;
  }
  if(argc==1 && clt->groupname[0]=='\0') {
    (*clt->co) << "412 Not currently in a newsgroup\r\n";
    return -1;
  }

  if(argc==2) {
    GroupInfo *gi;
    if((gi=clt->srvr->groupinfo(argv[1]))==NULL) {
      (*clt->co) << "411 no such news group\r\n";
      return -1;
    }
    // Reset Article Pointer
    clt->nbr=(gi->first()<=gi->last())?gi->first():-1;
    if(strcmp(clt->groupname,argv[1])!=0) {
      if(clt->grp) clt->srvr->freegroup(clt->grp);
      clt->grp=NULL;
      strcpy(clt->groupname,argv[1]);
    }
    VERB(log.p(Logger::Info) << (const char*)gi->name() << " "
	                     << gi->n() << " " 
                             << gi->first() << " " 
                             << gi->last() 
                             << "\n");
  }
  if(selectgroup(clt)<0) {
    (*clt->co) << "411 no such news group\r\n";
    return -1;
  }
  
  (*clt->co) << "211 list of article numbers follow\r\n";
  clt->grp->printlistgroup(*clt->co);
  (*clt->co) << ".\r\n";
  return 0;
}

int ns_mode(ClientData *clt,int argc,char *argv[])
{
  if(argc!=2 || 
     (strcasecmp(argv[1],"reader")!=0 && 
      strcasecmp(argv[1],"query")!=0)) {
    (*clt->co) << "501 Syntax: mode (reader|query)\r\n";
    return -1;
  }
  (*clt->co) << "200 Hello! NNRP OK!\r\n";
  return 0;
}

int ns_newgroups(ClientData *clt,int argc,char *argv[]) 
{
  int err=0;

  if(argc<3 || argc>5) {
    err=1;
  } else {
    int i;
    struct tm rtm;

    for(i=0;isdigit(argv[1][i]);i++);
    if((i!=8 && i!=6) || argv[1][i]) err=1;
    for(i=0;isdigit(argv[2][i]);i++);
    if(i!=6 || argv[2][i]) err=1;
    //FIX! 3rd and 4th argument are ignored currently
  }
  if(err) {
    (*clt->co) << "501 Syntax:  NEWGROUPS date time [GMT] [<wildmat>]\r\n";
    return -1;
  }
  
  (*clt->co) << "231 list of new newsgroups follows\r\n.\r\n";
  return 0;
}

int ns_post(ClientData *clt,int argc,char *argv[])
{
  if(argc!=1) {
    (*clt->co) << "501 Syntax: post\r\n";
    return -1;
  }

  Article art;
  (*clt->co) << "340 send article to be posted.\r\n";
  art.read(*clt->ci);

  try {
    clt->srvr->post(&art);
    (*clt->co) << "240 Article posted.\r\n";
  }
  catch (ResponseErr &r) {
    VERB(log.p(Logger::Notice) << "post failed!\n" 
	                       << (const char*)r._got << "\n");
    (*clt->co) << r._got;
    return -1;
  }
  return 0;
}

int ns_quit(ClientData *clt,int argc,char *argv[])
{
  (*clt->co) << "205 Good bye\r\n";
  return 1;
}

/*
 * 221 Header follows
 * 412 No news group current selected
 * 420 No current article selected
 * 430 no such article
 * 502 no permission
 */
int ns_xover(ClientData *clt,int argc,char *argv[])
{
  int i=1,fst,lst;
  char buf[513];
  char *p;
  int err=0;

  if(clt->groupname[0]=='\0') {
    (*clt->co) << "412 No newsgroup currently selected\r\n";
    return -1;
  }
  if(strcmp(argv[0],"xhdr")==0) { i=2; }
  switch(argc-i) {
  case 0:
    fst=lst=clt->nbr;
    break;
  case 1:
    p=argv[i];
    if(isdigit(*p)) fst=lst=strtol(argv[i],&p,10);
    if((*p)=='\0') break;
    if((*p)=='-') {
      lst=UINT_MAX;
      p++;
      if(isdigit(*p)) lst=strtol(p,&p,10);
      if((*p)=='\0') break;
    }
  default:
    err=1;
  } 
  if(err) {
    (*clt->co) << "501 Syntax: xover [range]\r\n";
    return -1;
  }
  if(selectgroup(clt)<0) {
    (*clt->co) << "411 no such news group\r\n";
    return -1;
  }

  ASSERT(clt->grp->testdb());
  switch(i) {
  case 1:
    (*clt->co) << "224 Overview information follows\r\n";
    clt->grp->printoverdb(*clt->co,fst,lst);
    break;
  case 2:
    (*clt->co) << "221 " << p << "[" << fst << "-" << lst << "]\r\n";
    clt->grp->printheaderdb(*clt->co,argv[1],fst,lst);
    break;
  }
  (*clt->co) << ".\r\n";
  return 0;
}

int ns_xttl(ClientData *clt,int argc,char *argv[])
{
  if(argc>4) {
    (*clt->co) << "501 Syntax: xttl list desc group\r\n";
    return -1;
  }

  clt->srvr->setttl(atoi(argv[1]),atoi(argv[2]),atoi(argv[3]));
  (*clt->co) << "280 New timeouts have been set\r\n";
  return 0;
}

typedef struct _nnrp_command_t {
  const char *name;
  int (*func)(ClientData*,int,char*[]);
} nnrp_command_t;

static nnrp_command_t nnrp_commands[]=
{
  {"article",ns_article},
  {"date",ns_date},
  {"group",ns_group},
  {"help",ns_help},
  {"list",ns_list},
  {"listgroup",ns_listgroup},
  {"mode",ns_mode},
  {"newgroups",ns_newgroups},
  {"post",ns_post},
  // stat: 
  //   Necessary for tin to detect, whether the connection timed out
  // last,next should we implement these commands?
  {"stat",ns_article},
  {"quit",ns_quit},
  {"xhdr",ns_xover},
  {"xover",ns_xover},
  {"xttl",ns_xttl},
  {NULL,NULL}
};

/* nnrpd(fd)
 */
void nnrpd(int fd)
{
  ClientData clt;
  char req[1024],oreq[1024];
  char *argv[256];
  int i,argc;
  const char *com;
  nnrp_command_t *p;
  int errc;
  fstream fs;

  if(fd>=0) {
    fs.attach(fd);
    fs.unsetf(ios::skipws);
    clt.ci=&fs;
    clt.co=&fs;
  } else {
    cin.unsetf(ios::skipws);
    clt.ci=&cin;
    clt.co=&cout;
  }
  
  clt.srvr=new CServer(Cfg.SpoolDir,&(Cfg.srvrs));
  clt.srvr->setttl(Cfg.ttl_list,Cfg.ttl_desc,Cfg.ttl_group);
  clt.grp=NULL;
  clt.groupname[0]='\0';

  (*clt.co) << "200 Hello World!\r\n";
  do {
    flush(*clt.co);
    // Read command
    clt.ci->getline(req,sizeof(req),'\n');
    if(!clt.ci->good()) break;
    strcpy(oreq,req);
    VERB(log.p(Logger::Info) << "> " << oreq << "\n");

    // Split command into arguments
    for(i=0, argc=0;req[i] && argc<256;i++) {
      if(isspace(req[i])) {
	req[i]='\0';
      } else {
	if(i==0 || req[i-1]=='\0') argv[argc++]=req+i;
	if(argc==1) req[i]=tolower(req[i]);
      }
    }
    if(argc==256) {
      (*clt.co) << "500 Line too long\r\n";
      continue;
    }
    if(argc) {
      com=argv[0];
      // Execute command
      p=nnrp_commands;
      while(p->name) {
	if (strcasecmp(p->name,com)==0) {
	  errc=p->func(&clt,argc,argv);
	  VERB(if(errc<0) {
	    log.p(Logger::Notice) << "> " << oreq << " failed!\n";
	  });
	  break; 
	}
	p++;
      }
    }
    if(argc==0 || p->name==NULL) {
      VERB(log.p(Logger::Notice) << "> " << oreq << " not recognized!\n");
      (*clt.co) << "500 Sorry\r\n";
    }
  } while(errc<=0);
  VERB(log.p(Logger::Notice) << "Connection closed\n");
  /*clt.co->close();*/
  delete clt.srvr;
}


void nntpd()
{
  int sock;
  struct sockaddr_in nproxy;
  const char *cp;
  struct servent *cport;

  struct sockaddr_in clt_sa;
  sasize_t clt_salen;
  int clt_fd;
  int clt_pid;
    
  if ((sock=socket(AF_INET, SOCK_STREAM, 0))<0) {
    cerr << "Can't create socket: " << strerror(errno);
    exit(1);
  }

  nproxy.sin_family=AF_INET;
  nproxy.sin_addr.s_addr=INADDR_ANY; 
  
  cp=Cfg.CachePort;
  if(cp[0]!='#') {
    if ((cport=getservbyname(cp,"tcp"))==NULL) {
      cerr << cmnd << ": Can't resolve service " << cp << "/tcp\n";
      exit(1);
    }
    nproxy.sin_port=cport->s_port;
  } else {
    nproxy.sin_port=htons(atoi(cp+1));
  }
  cerr << cmnd << ": Binding to port " << ntohs(nproxy.sin_port) 
       << " (" << cp << ")\n";

  if (bind(sock, (struct sockaddr *)&nproxy, sizeof(nproxy))<0) {
    fprintf(stderr,"Can't bind socket: %s\n",strerror(errno));
    exit(1);
  }

  setugid(Cfg.uname,Cfg.gname);
  listen(sock,4);
  for(;;) {
    /* Accept connection */
    clt_salen=sizeof(clt_sa);
    clt_fd=accept(sock,(struct sockaddr *)&clt_sa,&clt_salen);
    if(Xsignal>=0) exit(0);
    if(clt_fd<0) {
      fprintf(stderr,"Can't accept connection: %s",strerror(errno));
      exit(1);
    }
    fprintf(stderr,"Connection from %s:%d\n",  
	    inet_ntoa(clt_sa.sin_addr),
	    ntohs(clt_sa.sin_port));
    
    //#define CONF_MultiClient
#ifdef CONF_MultiClient
    if((clt_pid=fork())<0) {
      cerr << "Fork failed: " << strerror(errno) << "\n";
      write(clt_fd,"503 Cannot create process\r\n",28);
      close(clt_fd);
      continue;
    }
    //Success
    if(clt_pid==0) {
      //Child
      close(sock);
      nnrpd(clt_fd);
      close(clt_fd);
      exit(0);
    }
    //Parent
    close(clt_fd);
#else
    nnrpd(clt_fd);
    close(clt_fd);
#endif
  }
  
  close(sock);
}

void catchsignal(int num)
{
  Xsignal=num;
}

main(int argc, char **argv)
{
  char buf[256];
  time_t t;
  pid_t p;
  int ai=1;
  int use_inetd=0;

  strcpy(ServerRoot,CONF_ServerRoot);
  if(chdir(ServerRoot)<0) {
    cerr << "Cannot change to " << ServerRoot << endl;
    exit(1);
  }

  time(&t);
  p=getpid();
  VERB(sprintf(buf,"Trace-%ld-%d",t,p);
       log.open(buf);
       log.p(Logger::Info) << "> " << " \n");

  cmnd=argv[0];
  if(argc>3) {
    cerr << "Usage: " << cmnd << " [-i] [Config-File]\n";
    exit(1);
  }
  if(argc>1 && strcmp(argv[1],"-i")==0) {
    ai++;
    use_inetd=1;
  }
    
  if(argc<=ai) Cfg.read("etc/newscache.conf");
  else Cfg.read(argv[ai]);

  // signal
  Xsignal=-1;
  signal(SIGHUP,catchsignal);
  signal(SIGTERM,catchsignal);

  //FIX! We have to create a directory for each NewsServer here!
 
  if(Cfg.ServerType==Config::inetd) use_inetd=1;

  if(!use_inetd) {
    VERB(Cfg.dump(cerr));
    nntpd();
  } else {
    struct sockaddr_in sock;
    int socklen=sizeof(sock);
    if(getuid()==CONF_UIDROOT) setugid(Cfg.uname,Cfg.gname);
    if(getpeername(0,(struct sockaddr*)&sock,&socklen)>=0) {
      VERB(log.p(Logger::Info) << "Connection from "
	   << inet_ntoa(sock.sin_addr) << ":"
	   << ntohs(sock.sin_port) << "\n");
    }
    nnrpd(-1);
  }
}
