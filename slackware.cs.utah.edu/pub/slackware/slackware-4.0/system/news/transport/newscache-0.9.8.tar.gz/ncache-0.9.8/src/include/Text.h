#ifndef __Text_h__
#define __Text_h__

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>

#include<iostream.h>

#include"Debug.h"
// Add an allocation mode to text
// internal ... Text uses its own memory
// external ... Text uses memory provided by the user
//              => The class's contents must not be changed
class Text {
  char *tx;
  int txlen;
  int txsz;

  void txalloc(int slen);

public:
  Text() {
    tx=NULL;
    txsz=0;
    txlen=0;
    txalloc(0);
    *tx='\0';
  }
  Text(const char *txt) {
    txlen=strlen(txt);
    txalloc(txlen+1);
    strcpy(tx,txt);
  }

  setdata(const char *txt,int txtlen=0) {
    if(txtlen) {
      // check whether the trailing \0 was counted as character
      if(txt[txtlen-1]=='\0') txlen=txtlen-1;
      else txlen=txtlen;
      txalloc(txtlen);
    } else {
      txlen=strlen(txt);
      txalloc(txlen+1);
    }
    strcpy(tx,txt);
  }

  void append(const char *strg, int slen) {
    if(strg[slen]=='\0') {
      txalloc(txlen+slen);
      strcpy(tx+txlen,strg);
      txlen+=slen;
    } else {
      txalloc(txlen+slen+1);
      strncpy(tx+txlen,strg,slen);
      txlen+=slen+1;
      tx[txlen]='\0';
    }
  }
  
  void append(const char *strg) {
    append(strg,strlen(strg));
  }

  void clear() { *tx='\0'; txlen=0; }
  char *data() { return tx; }
  int length() { return txlen; }

  int read(istream &is, const char *delim=".");
};

#endif
