#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include<errno.h>

#include<iostream.h>
#include<fstream.h>
#include<String.h>

#include"NServer.h"

//********************
//***   NServer
//********************
// protected:

/* NServer::NServer()
 * Description:
 *   Initialize the a new NServer class.
 * Parameters:
 *   none
 * Exceptions:
 *   none
 */
NServer::NServer()
{
  VERB(log.p(Logger::Debug) << "NServer::NServer()\n"); 
  _OverviewFormat=NULL;
  _ActiveDB=NULL;
}

/* NServer::~NServer()
 * Description:
 *   Free allocated data. Virtual because it is possible, that
 *   a news server instance is destructed via the abstract 
 *   parent class.
 * Parameters:
 *   none
 * Exceptions:
 *   none
 */
NServer::~NServer()
{
  if(_OverviewFormat) delete _OverviewFormat;
  if(_ActiveDB) delete _ActiveDB;
}

//********************
//***   LServer
//********************

// protected:
void LServer::init(const char *spooldir) 
{
  VERB(log.p(Logger::Debug) << "LServer::init(" << spooldir << ")\n"); 
  char buf[1024];

  // -16:
  // 4c .art
  // 11c number of article
  // 1c Trailing \0
  ASSERT(if(strlen(spooldir)>sizeof(_SpoolDirectory)-MAXGROUPNAMELEN-16) {
    log.p(Logger::Critical) << "Spool-directory too long!\n";
    sprintf(buf,"Spooldir too long (len(Spooldir)+len(Hostname)+len(Servicename)<=%dc)",sizeof(_SpoolDirectory)-MAXGROUPNAMELEN-16);
    throw Error(buf);
  });
  strcpy(_SpoolDirectory,spooldir);

  if(!_OverviewFormat) _OverviewFormat=new OverviewFmt();
  if(!_ActiveDB) _ActiveDB=NULL;
}

// public:

/* LServer::LServer
 * Description:
 *   Construct an LServer class
 * Parameters:
 *   spooldir ... Name of spool-directory
 * Exceptions:
 *   none
 */
LServer::LServer(const char *spooldir) 
{
  VERB(log.p(Logger::Debug) << "LServer::LServer(" << spooldir << ")\n"); 
  init(spooldir);
}

/* LServer::~LServer()
 * Description:
 *   Free allocated data.
 * Parameters:
 *   none
 * Exceptions:
 *   none
 */
LServer::~LServer()
{
}

/* LServer::active
 * Description:
 *   Return a pointer to the active database.
 * Parameters:
 *   none
 * Return:
 *   Pointer to the active database. The database pointed to by
 *   the return vlue is maintained by the LServer class. Hence,
 *   it should not be modified by the user and must not be
 *   deleted!
 * Exceptions:
 *   none
 */
ActiveDB *LServer::active()
{
  return _ActiveDB;
}

/* LServer::groupinfo
 * Description:
 *   Returns information onto the newsgroup >name< from the
 *   active database.
 * Misfeatures:
 *   This method possibly should be moved to the NServer-class?
 * Parameters:
 *   name ... name of the newsgroup
 * Return:
 *   Returns informations of the newsgroup in a statically
 *   allocated GroupInfo structure.
 * Exceptions:
 *   none
 */
GroupInfo *LServer::groupinfo(const char *name)
{
  VERB(log.p(Logger::Debug) <<"LServer::groupinfo(" << name << ")\n");
  static GroupInfo agroup;

  ASSERT(if(strlen(name)>500) {
    log.p(Logger::Critical) << "LServer::groupinfo: Name of newsgroup exceeds 500 chars\n";
    throw Error("NServer(678): Name of Newsgroup too long");
  });
  
  if(_ActiveDB->get(name,&agroup)<0) return NULL;
  return &agroup;
}

/* LServer::getgroup
 * Description:
 *   Return the newsgroup with name >name<.
 *   If the newsgroup does not exist, NULL will be returned.
 * Misfeatures:
 *   Does not use the USE_EXCEPTION-define
 * Parameters:
 *   name ... name of the newsgroup
 * Return:
 *   Pointer to a Newsgroup structure. Free it by calling 
 *   the freegroup method. The newsgroup must destructed by 
 *   the same Server-instance it was constructed from.
 * Exceptions:
 *   System,ResponseErr,Error from selectgroup-method will not be catched
 */
Newsgroup *LServer::getgroup(const char *name)
{
  VERB(log.p(Logger::Debug) <<"LServer::getgroup(" << name << ")\n");
  if(!_ActiveDB->hasgroup(name)) return NULL;
  return new NVNewsgroup(_OverviewFormat,_SpoolDirectory,name);
}

/* LServer::freegroup
 * Description:
 *   Free the newsgroup instance allocated by getgroup.
 * Parameters:
 *   group ... the newsgroup to be deleted
 * Return:
 *   void
 * Exceptions:
 *   none
 */
void LServer::freegroup(Newsgroup *group)
{
  VERB(log.p(Logger::Debug) <<"LServer::freegroup(*group)\n");
  delete group;
}

/* LServer::post
 * Description:
 *   Post an article to the news server.
 * Misfeatures:
 *   Not yet supported.
 * Parameters:
 *   article ... The article to be posted
 * Return:
 *   0 on success, otherwise <0
 * Exceptions:
 *   ResponseErr ... If posting fails
 */
int LServer::post(Article *article)
{
//   TRACE(ctrace << "LServer::post(Article*)\n");
//   char fn[1024];
//   fstream fs;
//   int qnbr;
  
//   sprintf(fn,".outgoing/.qnbr");
//   fs.open(fn,ios::in|ios::out);
//   fs >> qnbr;
//   if(!fs.good()) {
//     qnbr=0;
//     fs.clear();
//   }
//   fs.seekp(0,ios::beg);
//   fs << qnbr+1 << endl;
//   if(!fs.good()) {
//     DEBUG(cdbg << "Failure on .outgoing/.qnbr\n");
//   }
//   fs.close();

//   DEBUG(cdbg << "LServer: qnbr=" << qnbr << endl << article << endl);

//   sprintf(fn,".outgoing/a%d",qnbr);
//   fs.open(fn,ios::out);
//   fs.unsetf(ios::skipws);
//   fs << article;
//   fs.close();
}

//********************
//***   RServer
//********************
// protected:

void RServer::init(MPList *serverlist)
{ 
  VERB(log.p(Logger::Debug) << "RServer::init/1\n"); 
  
  _ServerList=serverlist;
  _CurrentServer=NULL;
  _Retries=3;

  if(!_OverviewFormat) _OverviewFormat=new OverviewFmt();
  if(!_ActiveDB) _ActiveDB=NULL;
}

/* RServer::issue
 * Description:
 *   Send a command to the remote news server and return its
 *   response.
 * Misfeatures:
 *   Does not use the USE_EXCEPTIONS define. However, this is
 *   only a problem for people with broken c++ compilers. (Sure,
 *   being exactly most c++ compilers are broken, but ...)
 *   Uses String class.
 * Parameters:
 *   command ... Command that should be sent to the news server
 *   expresp ... Expected response code. If omitted, any response
 *               code will do. Should be checked by the caller in
 *               this case.
 * Return:
 *   Static character buffer holding the news server's response.
 * Exceptions:
 *   Error ... If the command fails for _Retries times.
 *   ResponseErr ... Thrown, if the news server returns a response
 *                   code different to the expected one.
 */
const char *RServer::issue(const char *command, const char *expresp=NULL) {
  VERB(log.p(Logger::Debug) << "RServer::issue(" << command << ","
                            << (expresp?expresp:"") << ")\n"); 
  String resp;
  static char respbuf[1024];
  int rs;
  int i=_Retries;

  // Send command
  _ServerStream << command;
  rs=readline(_ServerStream,resp,'\n',0);

  // If we have lost the connection to the news server, we try
  // to reconnect to the server and reissue the command. A loop 
  // is needed at this point, because it is possible that the 
  // news server accepts new connections, but closes it after issueing
  // this command.
  while(!_ServerStream.good()) {
    VERB(log.p(Logger::Debug) << "Lost connection to news server\n"); 
    if(i==0) throw Error("Maximum number of retries reached");
    connect();
    _ServerStream << command;
    rs=readline(_ServerStream,resp,'\n',0);
    i--;
  }

  // Check the response code
  if((rs<3) || (expresp && resp.before((int)strlen(expresp))!=expresp)) {
    throw ResponseErr(command,expresp,resp);
  }

  strncpy(respbuf,(const char*)resp,1023);
  respbuf[1023]='\0';
  return respbuf;
}

/* RServer::setserver
 * Description:
 *   Disconnect from the current news server and set a new news 
 *   server as the current one, if the new one is different to
 *   the current.
 * Parameters:
 *   server ... A multiplexinglist entry pointing to the new news 
 *              server. This parameter must not be freed as long as 
 *              RServer uses this news server, since only the pointer 
 *              is stored.
 *              As soon as RServer connects to this news server,
 *              it will store whether posting is allowed in 
 *              server->flags.
 * Return:
 *   void
 * Exceptions:
 *   none
 */
void RServer::setserver(MPListEntry *server)
{
  VERB(log.p(Logger::Debug) << "RServer::setserver({"
                            << server->hostname << "," 
                            << server->servicename << "})\n");
  char buf[MAXPATHLEN];

  if(_CurrentServer &&
     strcmp(server->hostname,_CurrentServer->hostname)==0 && 
     strcmp(server->servicename,_CurrentServer->servicename)==0) return;

  if(_CurrentServer) disconnect();
  _CurrentServer=server;
}

/* RServer::connect
 * Description:
 *   Connect to the news server. Stores whether posting
 *   is allowed in _CurrentServer->flags.
 * Misfeatures:
 *   Does not use the USE_EXCEPTIONS define.
 *   Uses String class.
 * Parameters:
 *   none
 * Return:
 *   void
 * Exceptions:
 *   SystemError ... Thrown, if a system error (eg. cannot connect)
 *                   occurs after _Retries successive 
 *                   connection-failures.
 *   ResponseErr ... Thrown, if the news server returns a response
 *                   code different to the allowed connection
 *                   setup return codes.
 *                   200 ... reading and posting allowed
 *                   201 ... reading allowed
 *   System,ResponseErr ... from issue call will not be catched
 */
void RServer::connect()
{
  VERB(log.p(Logger::Debug) << "RServer::connect()\n"); 
  if(is_connected()) return;

  String resp;
  char buf[1024];
  const char *p;
  int i=_Retries;

  do {
    // Open connection
    _ServerStream.connect(_CurrentServer->hostname,
			  _CurrentServer->servicename);
    _ServerStream.unsetf(ios::skipws);
    readline(_ServerStream,resp,'\n',0);
    VERB(log.p(Logger::Debug) << resp << "\r\n"); 

    if(!_ServerStream.is_connected() || !_ServerStream.good()) {
      if(i) {
	i--;
	continue;
      }
      sprintf(buf,"Connection to %s:%s failed",
	      _CurrentServer->hostname,_CurrentServer->servicename);
      throw SystemError(buf,errno);
    }
    if(resp.before(3)!="200" && resp.before(3)!="201") {
      throw ResponseErr("Illegal answer at connection setup (!=200 && !=201)","200",resp);
    }
    // mode reader
    p=issue("mode reader\r\n","20");
    if(!_ServerStream.good()) {
      if(i) {
	i--;
	continue;
      }
      sprintf(buf,"Cannot read data from %s:%s",
	      _CurrentServer->hostname,_CurrentServer->servicename);
      throw SystemError(buf,errno);
    }
    
    if(p[2]!='0' && p[2]!='1') {
      throw ResponseErr("Illegal answer at connection setup (!=200 && !=201)","200",p);
    }
    if(p[2]=='0') {
      _CurrentServer->flags=MPListEntry::F_READ|MPListEntry::F_POST;
    } else {
      _CurrentServer->flags=MPListEntry::F_READ;
    }

    issue("list overview.fmt\r\n","215");
    _OverviewFormat->readxoin(_ServerStream);
    
    if(_CurrentGroup.name()[0]!='\0') {
      selectgroup(_CurrentGroup.name());
    }
  } while(!_ServerStream.is_connected() || !_ServerStream.good());
}

/* RServer::selectgroup
 * Description:
 *   Select a newsgroup on the remote news server.
 * Misfeatures:
 *   Does not use the USE_EXCEPTION-define
 * Parameters:
 *   name ... name of the newsgroup
 * Return:
 *   0 on success and -1 if the newsgroup does not exist
 * Exceptions:
 *   System,ResponseErr from issue-method will not be catched
 *   Error ... If the name of the newsgroup exceeds 500 chars
 */
int RServer::selectgroup(const char *name)
{
  VERB(log.p(Logger::Debug) <<"RServer::selectgroup(" << name << ")\n");
  if(strcmp(_CurrentGroup.name(),name)==0) return 0;

  char buf[MAXPATHLEN];
  const char *resp,*ep;
  int nbr, fst, lst;
  MPListEntry *mpe;
  String rsp;

  ASSERT(if(strlen(name)>500) {
    log.p(Logger::Critical) << "RServer::groupinfo: Name of newsgroup exceeds 500 chars\n";
    throw Error("NServer(16727): Name of Newsgroup too long");
  });
  
  // Find the server responsible for this newsgroup
  if((mpe=_ServerList->server(name))==NULL) {
    // No server configured for this group
    VERB(log.p(Logger::Notice) << "No news server configured for " << name << "\n");
    return -1;
  }

  setserver(mpe);
  sprintf(buf,"group %s\r\n",name);
  rsp=issue(buf,NULL);
  resp=(const char*)rsp;

  if(resp[0]!='2' || resp[1]!='1' || resp[2]!='1') {
    if(resp[0]=='4' && resp[1]=='1' && resp[2]=='1') return -1;
    else throw ResponseErr(buf,"211",resp);
  }
  resp=resp+3;

  nbr=strtol(resp,(char**)&resp,10);
  fst=strtol(resp,(char**)&resp,10);
  lst=strtol(resp,(char**)&ep,10);
  
  if(ep==resp) { 
    //THROW!?! _Response_should_be_
    // 211 $n $f $l $g selected
    // $n Nbr. of articles in group
    // $f Nbr. of first article
    // $l Nbr. of last article
    // $g Name of newsgroup
    VERB(log.p(Logger::Error) << "RServer::group: Response to group [ggg] not in form >>211 n f l g ...<<!\n");
    // If we cannot parse the response code, use the first/last number 
    // and number of articles from the active database
    if(_ActiveDB->get(name,&_CurrentGroup)<0)
      _CurrentGroup.set(name,0,0,0);
  } else {
    _CurrentGroup.set(name,fst,lst,nbr);
  }
  _ActiveDB->set(_CurrentGroup);
  return 0;
}

// public:

/* RServer::RServer
 * Description:
 *   Initialize the new RServer class. Sets up the server list
 *   and the default number of retries.
 * Misfeatures:
 *   ActiveDB for RServer not yet implemented.
 * Parameters:
 *   serverlist ... list of news servers and their newsgroups
 * Exceptions:
 *   none
 */
RServer::RServer(MPList *serverlist)
{ 
  VERB(log.p(Logger::Debug) << "RServer::RServer/1\n"); 
  init(serverlist);
}

/* RServer::~RServer()
 * Description:
 *   Free allocated data.
 * Parameters:
 *   none
 * Exceptions:
 *   none
 */
RServer::~RServer()
{
  setserverlist(NULL);
}

/* RServer::setserverlist
 * Description:
 *   Delete all previously allocated data and install a new list of 
 *   news servers and newsgroups. 
 * Parameters:
 *   serverlist ... The list of news servers. This parameter must not 
 *                  be freed as long as RServer uses this server-list, 
 *                  since only the pointer is stored.
 * Return:
 *   void
 * Exceptions:
 *   none
 */
void RServer::setserverlist(MPList *serverlist)
{
  // Disconnect
  disconnect();
  
  // Clean up
  _CurrentGroup.clear();
  if(_ActiveDB) {
    delete _ActiveDB;
    _ActiveDB=NULL;
  }
  _CurrentServer=NULL;
  _ServerList=serverlist;
}

/* RServer::active
 * Description:
 *   Retrieves the active database from the news servers and
 *   returns a pointer to it.
 * Misfeatures:
 *   Setting up all of this filter expressions can be done
 *   at the server-list's creation time. However, at the
 *   moment this is neglectable. The active database is
 *   retrieved rather seldom and takes a long time nevertheless.
 * Parameters:
 *   none
 * Return:
 *   Pointer to the active database.
 * Exceptions:
 *   System,ResponseErr from issue-method will not be catched
 */
ActiveDB *RServer::active()
{
  VERB(log.p(Logger::Debug) <<"RServer::active()\n");
  int i,flags;
  char buf[513],cgroup[513],filter[MPListBIGBUFF];
  char *gp,*fp,*sp,*q,*r;
  char c,d;
    
  ASSERT(if(!_ServerList) {
    log.p(Logger::Critical) << "RServer::active: _ServerList is a null-pointer\n";
    throw Error("NServer(16728): _ServerList is a null-pointer");
  });
  
  for(i=0;i<_ServerList->e_used;i++) {
    // Connect to ith news server
    setserver(_ServerList->entries+i);
    sp=_ServerList->entries[i].groups;
    do {
      // Extract a newsgroup-expression
      gp=cgroup;
      while((c=*sp++)!=',' && c) *gp++=c;
      *gp='\0';
      // Create filter expression
      gp=cgroup;
      fp=filter;
      *fp++='*';
      q=_ServerList->_AllNewsgroups;
      do {
	r=q;
	while(*gp && *gp==*r) { gp++; r++; }
	if(*gp=='*' && *r!='*') {
	  // q matches current group decsription
	  // => copy to filter
	  *fp++=',';
	  *fp++='!';
	  while((d=*q++)!=',' && d) *fp++=d;
	} else {
	  // q does not match group description 
	  // => group will not occur in active listing and can be skipped
	  q=r;
	  while((d=*q++)!=',' && d);
	}
      } while(d);
      *fp='\0';
      sprintf(buf,"list active %s\r\n",cgroup);
      issue(buf,"215");
      if(!(_ServerList->entries[i].flags&MPListEntry::F_POST)) {
	flags=ActiveDB::F_STORE_READONLY;
      }
      _ActiveDB->read(_ServerStream,filter,flags);
    } while(c);
  }
  return _ActiveDB;
}

/* RServer::groupinfo
 * Description:
 *   Returns information onto the newsgroup >name< from the
 *   active database.
 * Parameters:
 *   name ... name of the newsgroup
 * Return:
 *   Returns informations of the newsgroup in a statically
 *   allocated GroupInfo structure.
 * Exceptions:
 *   System,ResponseErr from active-method will not be catched
 */
GroupInfo *RServer::groupinfo(const char *name)
{
  VERB(log.p(Logger::Debug) <<"RServer::groupinfo(" << name << ")\n");
  static GroupInfo agroup;

  ASSERT(if(strlen(name)>500) {
    log.p(Logger::Critical) << "RServer::groupinfo: Name of newsgroup exceeds 500 chars\n";
    throw Error("NServer(16727): Name of Newsgroup too long");
  });
  
  // If the newsgroup cannot be found within the active database
  // reload the database from the news server and try again.
  if(_ActiveDB->get(name,&agroup)<0) {
    active();
    if(_ActiveDB->get(name,&agroup)<0) return NULL;
  }
  return &agroup;
}

/* RServer::getgroup
 * Description:
 *   Return the newsgroup with name >name<.
 *   If the newsgroup does not exist, NULL will be returned.
 * Misfeatures:
 *   Does not use the USE_EXCEPTION-define
 *   Always returns a CNewsgroup, since RNewsgroup is not implemented yet.
 * Parameters:
 *   name ... name of the newsgroup
 * Return:
 *   Pointer to a Newsgroup structure. Free it by calling 
 *   the freegroup method. The newsgroup must destructed by 
 *   the same Server-instance it was constructed from.
 * Exceptions:
 *   System,ResponseErr,Error from selectgroup-method will not 
 *     be catched
 */
Newsgroup *RServer::getgroup(const char *name)
{
  VERB(log.p(Logger::Debug) <<"RServer::getgroup(" << name << ")\n");
  if(selectgroup(name)<0) return NULL;
  return new CNewsgroup(this,_OverviewFormat,"/tmp",_CurrentGroup.name());
}

/* RServer::freegroup
 * Description:
 *   Free the newsgroup instance allocated by getgroup.
 * Parameters:
 *   group ... the newsgroup to be deleted
 * Return:
 *   void
 * Exceptions:
 *   none
 */
void RServer::freegroup(Newsgroup *group)
{
  VERB(log.p(Logger::Debug) <<"RServer::freegroup(*group)\n");
  delete group;
}

/* RServer::overviewdb
 * Description:
 *   Return the overviewdatabase of the newsgroup >ng<.
 *   This function should not be called by the user. Instead it
 *   should be called via a Newsgroup object.
 * Parameters:
 *   name ... name of the newsgroup
 * Return:
 *   void
 * Exceptions:
 *   System,ResponseErr,Error from selectgroup-method will not be catched
 *   System,ResponseErr from issue-method will not be catched
 */
void RServer::overviewdb(Newsgroup *ng, unsigned int fst, unsigned int lst)
{
  VERB(log.p(Logger::Debug) << "RServer::overviewdb(*ng," 
                            << fst << "-" << lst << ")\n");    
  ASSERT(if(!ng) {
    log.p(Logger::Critical) << "ERROR! ng==NULL\n";
    throw Error("RServer::overviewdb called with NULL pointer!!!");
  });

  selectgroup(ng->name());
  char buf[513];

  sprintf(buf,"xover %d-%d\r\n",fst,lst);
  issue(buf,"224");
  ng->readoverdb(_ServerStream);
}

/* RServer::listgroup
 * Description:
 *   Return a list of article available in a newsgroup
 * Parameters:
 *   gname ... Name of the newsgroup
 *   lstgrp ... Pointer to a preallocated array, where the list is stored
 *   lstgrpsz ... Size of the array above
 * Return:
 *   0 ... on success
 *   -1 ... illegal response
 *   -2 ... connection to server died
 * Exceptions:
 *   System,ResponseErr,Error from selectgroup-method will not be catched
 *   System,ResponseErr from issue-method will not be catched
 */
int RServer::listgroup(const char *gname, char *lstgrp, 
			    unsigned int f, unsigned int l)
{
  VERB(log.p(Logger::Debug) << "RServer::listgroup("  << gname << ",...)\n");    
  char buf[513];
  unsigned int i;
  const char *resp;
  String Strg;

  selectgroup(gname);

  sprintf(buf,"listgroup\r\n");
  resp=issue(buf,NULL);
  if(strncmp(resp,"211",3)!=0) {
    return -1;
  }

  for(;;) {
    readline(_ServerStream,Strg,'\n',0);
    if(Strg==".\r\n" || Strg==".\n") break;
    if(!_ServerStream.good()) return -2;
    i=atoi(Strg);
    if(f<=i && i<=l) lstgrp[i-f]=1;
  }

  return 0;
}

/* RServer::article
 * Description:
 *   Return a given article of a given newsgroup
 * Parameters:
 *   gname ... Name of the newsgroup
 *   nbr ... Number of the article
 * Return:
 *   Pointer to a statically preallocated article
 * Exceptions:
 *   System,ResponseErr,Error from selectgroup-method will not be catched
 *   System,ResponseErr from issue-method will not be catched
 */
Article *RServer::article(const char *gname, unsigned int nbr)
{
  VERB(log.p(Logger::Debug) << "RServer::article("  << nbr << ")\n");    
  char buf[513];
  const char *resp;
  static Article art;

  selectgroup(gname);

  sprintf(buf,"article %u\r\n",nbr);
  resp=issue(buf,NULL);
  if(strncmp(resp,"220",3)!=0) {
    if(strncmp(resp,"423",3)==0) return NULL;
    if(resp[0]=='4') throw UsageErr(resp);
    throw ResponseErr(buf,"220",resp);
  }
  art.read(_ServerStream);
  art.setnbr(nbr);
  return &art;
}

/* RServer::post
 * Description:
 *   Post an article to the primary news server. The primary news server
 *   is the news server being listed first in the MPList.
 * Misfeatures:
 *   The news server, where the article should be posted, should
 *   be taken from the article's newsgroup field. An article posted
 *   to comp.os.linux should be posted to the news server from where
 *   we receive this newsgroup.
 * Parameters:
 *   article ... The article to be posted
 * Return:
 *   <0 on failure
 *   0 if the article has been posted successfully
 *   1 if the article has been spooled for later submission
 * Exceptions:
 *   ResponseErr ... If posting fails
 */
int RServer::post(Article *article)
{
  VERB(log.p(Logger::Debug) << "RServer::post(Article &article)\n");    

  String resp;
  issue("post\r\n","340");
  _ServerStream << *article << ".\r\n";
  readline(_ServerStream,resp,'\n',0);
  if(!_ServerStream.good()) {
    disconnect();
    connect();
    return -1;
  }
  if(resp.before(3)!="240") throw ResponseErr("post\r\n","240",resp);
  return 0;
}

//********************
//***   CServer
//********************
// protected:

/* RSGroup(name)
 * If name==NULL then select current group on remote server, 
 * if not already selected. After the group has been selected, 
 * the new group data will be stored within the local active 
 * database.
 * In all other cases select group name on remote server and 
 * store the new newsgroup-data within the active database.
 * Return-Codes:
 *    0 OK
 *   -1 Cannot connect to news server
 * Exceptions:
 *   UsageErr
 *   ResponseErr
 */
// int CServer::RSGroup(const char *name)
// {
//   if(!_RSGroup || name) {
//     if(!name) name=_gd.name();
//     try {
//       RServer::group(name);
//     }
//     catch(SystemError &r) {
//       // If we cannot retrieve the newsgroup from the news server
//       // use the old one.
//       VERB(log.p(Logger::Notice) << "Retrieval of newsgroup failed\n");
//       return -1;
//     }
//     _RSGroup=1;
//     // Patch the active database with the new newsgroup informations
//     // Adds the newsgroup if it does not already exist
//     _ActiveDB->set(_gd);
//   }
//   return 0;
// }

// public:

/* CServer::CServer
 * Description:
 *   Construct an CServer class
 * Parameters:
 *   spooldir ... Name of spool-directory
 *   serverlist ... list of news servers and their newsgroups
 * Exceptions:
 *   none
 */
CServer::CServer(const char *spooldir, MPList *serverlist) 
{
  TRACE(ctrace<<"CServer::CServer("<< spooldir <<",*serverlist)\n");
  char buf[MAXPATHLEN];

  ASSERT(if(!serverlist) {
    log.p(Logger::Notice) << "CServer::CServer: serverlist is a null-pointer\n";
  });
  if(!LServer::_OverviewFormat) {
    LServer::_OverviewFormat=RServer::_OverviewFormat=new OverviewFmt;
  }
  if(!LServer::_ActiveDB) {
    sprintf(buf,"%s/.active",spooldir);
    LServer::_ActiveDB=RServer::_ActiveDB=_NVActiveDB=new NVActiveDB(buf);
  }

  ASSERT(if(!serverlist) {
    log.p(Logger::Notice) << "RServer::RServer: serverlist is a null-pointer\n";
  });
  // other constructors
  LServer::init(spooldir);
  RServer::init(serverlist);

  ASSERT(if(!_ServerList) {
    log.p(Logger::Notice) << "RServer::RServer: serverlist is a null-pointer\n";
    exit(9);
  });
  _Flags=OnLine;
  _TTLActive=300;
  _TTLDesc=500;
  _TTLGroup=120;
}
  
/* CServer::~CServer()
 * Description:
 *   Free allocated data.
 * Parameters:
 *   none
 * Exceptions:
 *   none
 */
CServer::~CServer()
{
  OverviewFmt *o=LServer::_OverviewFormat;
  if(o) {
    delete o;
    LServer::_OverviewFormat=RServer::_OverviewFormat=NULL;
  }
  if(_NVActiveDB) {
    delete _NVActiveDB;
    LServer::_ActiveDB=RServer::_ActiveDB=_NVActiveDB=NULL;
  }
}

/* CServer::active
 * Description:
 *   Retrieves the active database (list of newsgroup and the number 
 *   of their first and last article) from the news servers, if the
 *   local copy is older than _TTLActive seconds.
 * Parameters:
 *   none
 * Return:
 *   void
 * Exceptions:
 *   System,ResponseErr from issue-method will not be catched
 */
/* active()
 * Get the .
 */
ActiveDB *CServer::active()
{
  if((_Flags&XLineMask)==OnLine && !active_valid()) {
    // The validity of the active database has to be tested twice,
    // because it is possible that several processes can reach
    // this point and in this case all these processes would
    // transfer the active database
    // Locking the database before the first active_valid call
    // is no good idea, since this requires to set a lock
    // even in cases where this is not necessary at all
    VERB(log.p(Logger::Notice) << "active database timed out\n");
    _NVActiveDB->lock(NVcontainer::ExclLock);
    if(!active_valid()) {
      try {
	RServer::active();
      }
      catch(...) {
	// If we cannot retrieve the ActiveDB from the news server
	// use the old one.
	VERB(log.p(Logger::Notice) << "Retrieval of ActiveDB failed\n");
	_NVActiveDB->lock(NVcontainer::UnLock);
	return _NVActiveDB;
      }
    }
    _NVActiveDB->lock(NVcontainer::UnLock);
  }
  return _NVActiveDB;
}

/* CServer::groupinfo
 * Description:
 *   Returns information onto the newsgroup >name< from the
 *   active database. If the last information obtained for 
 *   the newsgroup is older than _TTLGroup a group request
 *   is issued to the news server.
 * Misfeatures:
 *   Does not use the USE_EXCEPTIONS-define
 * Parameters:
 *   name ... name of the newsgroup
 * Return:
 *   Returns informations of the newsgroup in a statically
 *   allocated GroupInfo structure.
 * Exceptions:
 *   System,ResponseErr,Error from RServer::selectgroup-method 
 *     will not be catched
 */
GroupInfo *CServer::groupinfo(const char *name)
{
  VERB(log.p(Logger::Debug) <<"CServer::groupinfo(" << name << ")\n");
  static GroupInfo agroup;

  ASSERT(if(strlen(name)>500) {
    log.p(Logger::Critical) << "CServer::groupinfo: Name of newsgroup exceeds 500 chars\n";
    throw Error("CServer(678): Name of Newsgroup too long");
  });
  
  if((_Flags&XLineMask)==OffLine) return LServer::groupinfo(name);
  if(_NVActiveDB->get(name,&agroup)<0 || 
     agroup.mtime()+_TTLGroup<nvtime(NULL)) {
    if(RServer::selectgroup(name)<0) return NULL;
    if(_NVActiveDB->get(name,&agroup)<0) {
      log.p(Logger::Notice) << "CServer::selectgroup: Newsgroup disappeared!?!\n";
      return NULL;
    }
  }
  return &agroup;
}

/* CServer::getgroup
 * Description:
 *   Return the newsgroup with name >name<.
 *   If the newsgroup does not exist, NULL will be returned.
 * Misfeatures:
 *   Does not use the USE_EXCEPTION-define
 * Parameters:
 *   name ... name of the newsgroup
 * Return:
 *   Pointer to a Newsgroup structure. Free it by calling 
 *   the freegroup method. The newsgroup must destructed by 
 *   the same Server-instance it was constructed from.
 * Exceptions:
 *   none
 */
Newsgroup *CServer::getgroup(const char *name)
{
  VERB(log.p(Logger::Debug) <<"CServer::getgroup(" << name << ")\n");
  CNewsgroup *grp;
  GroupInfo grpinfo;

  if(_NVActiveDB->get(name,&grpinfo)<0) {
    if((_Flags&XLineMask)==OffLine) return NULL;
    if(RServer::selectgroup(name)<0) return NULL;    
    if(_NVActiveDB->get(name,&grpinfo)<0) {
      VERB(log.p(Logger::Error) <<"CServer::getgroup: Newsgroup disappeared. Unprobable hazard (should be like winning in the lottery).\n");
      return NULL;
    }
  }

  grp=new CNewsgroup(this,
		     RServer::_OverviewFormat,
		     _SpoolDirectory,name);
  grp->setsize(grpinfo.first(),grpinfo.last());
  grp->setttl(_TTLGroup);
  return grp;
}

/* CServer::freegroup
 * Description:
 *   Free the newsgroup instance allocated by getgroup.
 * Parameters:
 *   group ... the newsgroup to be deleted
 * Return:
 *   void
 * Exceptions:
 *   none
 */
void CServer::freegroup(Newsgroup *group)
{
  VERB(log.p(Logger::Debug) <<"CServer::freegroup(*group)\n");
  delete group;
}

/* CServer::post
 * Description:
 *   Post an article to the primary news server. The primary news server
 *   is the news server being listed first in the MPList. If the
 *   article cannot be submitted immediately, it is kept for later 
 *   transmission.
 * Misfeatures:
 *   The news server, where the article should be posted, should
 *   be taken from the article's newsgroup field. An article posted
 *   to comp.os.linux should be posted to the news server from where
 *   we receive this newsgroup.
 * Parameters:
 *   article ... The article to be posted
 * Return:
 *   <0 on failure
 *   0 if the article has been posted successfully
 *   1 if the article has been spooled for later submission
 * Exceptions:
 *   ResponseErr ... If posting fails
 */
int CServer::post(Article *article)
{
  TRACE(ctrace << "CServer::post(Article*)\n");
  int r;

  if((_Flags&XLineMask)==OffLine)
    return (spoolarticle(article)<0)?-1:1;

  try {
    if(RServer::post(article)<0) 
      r=(spoolarticle(article)<0)?-1:1;
    else 
      r=0;
  }
  catch(SystemError &r) {
    return (spoolarticle(article)<0)?-1:1;
  }
  return r;
}

/* CServer::spoolarticle
 * Description:
 *   Spool a news article for later transmission
 * Misfeatures:
 *   Lousy error handling...
 * Parameters:
 *   article ... The article to be spooled
 * Return:
 *   0 on success
 * Exceptions:
 *   SystemError
 */
int CServer::spoolarticle(Article *article)
{
  char fn[MAXPATHLEN];
  char buf[MAXPATHLEN+256];
  fstream fs;
  int fd,err=0,seqf,seqt;
  struct flock l;
  struct stat s;

  l.l_type=F_WRLCK;
  l.l_whence=SEEK_SET;
  l.l_start=l.l_len=0;
  sprintf(fn,"%s/.outgoing/status",_SpoolDirectory);
  if((fd=open(fn,O_RDWR))<0) {
    if(errno==ENOENT) {
      sprintf(buf,"%s/.outgoing",_SpoolDirectory);
      mkpdir(buf,0755);
      if((fd=open(fn,O_RDWR|O_CREAT))<0) err=1;
    } else err=1;
  }
  if(err) {
    sprintf(buf,"cannot open %s\n",fn);
    throw SystemError(buf,errno);
  }
  
  if(fcntl(fd,F_SETLKW,&l)<0) {
    sprintf(buf,"cannot lock %s\n",fn);
    throw SystemError(buf,errno);
  }
  if(fstat(fd,&s)<0) {
    sprintf(buf,"cannot fstat %s\n",fn);
    throw SystemError(buf,errno);
  }
  fs.attach(fd);
  if(s.st_size) {
    fs >> seqf >> seqt;
    if(fs.bad()) {
      sprintf(buf,"cannot read from %s\n",fn);
      throw SystemError(buf,errno);
    }
    fs.seekg(0,ios::beg);
  }
  fs << seqf << " " << seqt+1 << "\n";
  if(!fs.good()) {
    sprintf(buf,"cannot write to %s\n",fn);
    throw SystemError(buf,errno);
  }
  l.l_type=F_UNLCK;
  l.l_whence=SEEK_SET;
  l.l_start=l.l_len=0;
  if(fcntl(fd,F_SETLKW,&l)<0) {
    sprintf(buf,"cannot unlock %s\n",fn);
    throw SystemError(buf,errno);
  }
  fs.close();
  
  sprintf(fn,"%s/.outgoing/art%d",_SpoolDirectory,seqt);
  fs.open(fn,ios::out);
  fs << *article;
  if(!fs.good()) {
    sprintf(buf,"cannot write to %s\n",fn);
    throw SystemError(buf,errno);
  }
  fs.close();
  return 0;
}

/* CServer::postspooled
 * Description:
 *   Post all those articles that have been queued for later
 *   transmission.
 * Misfeatures:
 *   Lousy error handling...
 * Parameters:
 *   none
 * Return:
 *   void
 * Exceptions:
 *   ???
 */
void CServer::postspooled(void)
{
  VERB(log.p(Logger::Debug) << "CServer::postq()\n");
  if((_Flags&XLineMask)==OffLine) {
    VERB(log.p(Logger::Notice) << "CServer::postspooled() called in offline-mode\n");
    return;
  }
  char fn[MAXPATHLEN];
  char buf[MAXPATHLEN+256];
  fstream fs;
  int fd;
  int i,seqf,seqt;
  struct flock l;

  l.l_type=F_WRLCK;
  l.l_whence=SEEK_SET;
  l.l_start=l.l_len=0;
  sprintf(fn,"%s/.outgoing/status",_SpoolDirectory);
  if((fd=open(fn,O_RDWR))<0) {
    sprintf(buf,"cannot open %s\n",fn);
    throw SystemError(buf,errno);
  }
  VERB(log.p(Logger::Debug) << "Waiting for lock\n");
  if(fcntl(fd,F_SETLKW,&l)<0) {
    sprintf(buf,"cannot lock %s\n",fn);
    throw SystemError(buf,errno);
  }
  VERB(log.p(Logger::Debug) << "Locked\n");
  fs.attach(fd);
  fs >> seqf >> seqt;
  if(fs.bad()) {
    if(!fs.eof()) {
      sprintf(buf,"cannot read from %s\n",fn);
      throw SystemError(buf,errno);
    }    
    seqf=seqt=0;
    fs.clear();
  }
  
  try {
    for(i=seqf;i<seqt;i++) {
      ifstream ifs;
      Article a;
      sprintf(fn,"%s/.outgoing/art%d",_SpoolDirectory,i);
      ifs.open(fn);
      a.read(ifs);
      if(fs.bad() && !fs.eof()) {
	sprintf(buf,"cannot read from %s\n",fn);
	throw SystemError(buf,errno);
      }
      ifs.close();
      RServer::post(&a);
      if(unlink(fn)<0) {
	VERB(log.p(Logger::Error) << "Cannot unlink " << fn 
	                          << ". Please remove it manually.\n");
      }
    }
  }
  catch(Error &r) {
    fs.seekg(0,ios::beg);
    fs << i << " " << seqt;
    if(!fs.good()) {
      sprintf(buf,"cannot write to %s\n",fn);
      throw SystemError(buf,errno);
    }
    l.l_type=F_UNLCK;
    l.l_whence=SEEK_SET;
    l.l_start=l.l_len=0;
    if(fcntl(fd,F_SETLKW,&l)<0) {
      sprintf(buf,"cannot unlock %s\n",fn);
      throw SystemError(buf,errno);
    }
    fs.close();
    throw Error(&r);
  }
  fs.seekg(0);
  fs << i << " " << seqt << "\n";
  if(!fs.good()) {
    sprintf(buf,"cannot write to %s\n",fn);
    throw SystemError(buf,errno);
  }
  l.l_type=F_UNLCK;
  l.l_whence=SEEK_SET;
  l.l_start=l.l_len=0;
  if(fcntl(fd,F_SETLKW,&l)<0) {
    sprintf(buf,"cannot unlock %s\n",fn);
    throw SystemError(buf,errno);
  }
  fs.close();
}

/* CServer::overviewdb
 * Description:
 *   Return the overviewdatabase of the newsgroup >ng<.
 *   This function should not be called by the user. Instead it
 *   should be called via a Newsgroup object.
 * Parameters:
 *   name ... name of the newsgroup
 * Return:
 *   void
 * Exceptions:
 *   System,ResponseErr,Error from selectgroup-method will not be catched
 *   System,ResponseErr from issue-method will not be catched
 */
void CServer::overviewdb(Newsgroup *ng, unsigned int fst, unsigned int lst)
{
  VERB(log.p(Logger::Debug) << "RServer::xoverdb(*ng," 
                            << fst << "-" << lst << ")\n");    
  ASSERT(if(!ng) {
    log.p(Logger::Critical) << "ERROR! ng==NULL\n";
    throw Error("RServer::overviewdb called with NULL pointer!!!");
  });

  if((_Flags&XLineMask)==OffLine) return;
  RServer::overviewdb(ng,fst,lst);
}

/* CServer::article
 * Description:
 *   Return a given article of a given newsgroup
 * Parameters:
 *   gname ... Name of the newsgroup
 *   nbr ... Number of the article
 * Return:
 *   Pointer to a statically preallocated article
 * Exceptions:
 *   System,ResponseErr,Error from selectgroup-method will not be catched
 *   System,ResponseErr from issue-method will not be catched
 */
Article *CServer::article(const char *gname, unsigned int nbr)
{
  VERB(log.p(Logger::Info) << "CServer::article(" << nbr << ")\n");    

  if((_Flags&XLineMask)==OffLine) return NULL;
  return RServer::article(gname,nbr);
}

#ifdef USE_OLD_STUFF
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/// OLD STUFF //////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/* xoverdb(fst,lst)
 * Retrieve the Overview Database from LServer if it is valid.
 * Otherwise request it from RServer.
 * The fst and lst parameter will be ignored, since we always
 * store the whole overview database in NVOverviewDB. This
 * simplifies its handling and serves as useful prefetching, since
 * most newsreaders request the whole overview database.
 * Eg. gnus emacs, netscape news, tin, ...
 */
void CServer::xoverdb(unsigned int fst, unsigned int lst)
{
  VERB(log.p(Logger::Debug) << "RServer::xoverdb(*ng," 
                            << fst << "-" << lst << ")\n");    
  char buf[MAXPATHLEN];
  int myfst, mylst;
  int gdfst, gdlst;

  myfst=_OverviewDB->firstid();
  mylst=_OverviewDB->lastid();

  if(_gd.mtime()+_ttl_group<nvtime(NULL)) {
    // If we cannot connect to the news server, use the old overview 
    // database
    if(RSGroup(NULL)<0) return _OverviewDB;
    //if(RSGroup(NULL)<0) return NULL;
  }
  gdfst=_gd.first();
  gdlst=_gd.last();
  
  if(myfst!=gdfst || mylst!=gdlst) {
    _OverviewDB->lock(NVcontainer::ExclLock);
    myfst=_OverviewDB->firstid();
    mylst=_OverviewDB->lastid();
    RSGroup(NULL);
    gdfst=_gd.first();
    gdlst=_gd.last();

    // The expiry checks have to be done twice for the same
    // reasons as for the active database
    if(gdfst<myfst) {
      // Server's first article number smaller than mine
      // => Something's wrong => Retrieve whole OverviewDB
      VERB(log.p(Logger::Warning) << "Newsserver's fst article number < mine\n");    
      _OverviewDB->clear();
      expire_article(myfst,mylst);
      RServer::xoverdb(_gd.first(),_gd.last());
    } else {
      // Remove XOverDB for expired articles, if it is
      // not empty (mylst>myfst)
      if(myfst<gdfst && mylst>myfst) {
	_OverviewDB->expire(1,gdfst-1);
	expire_article(myfst,_gd.first()-1);
      }

      // Retrieve XOverDB for newly arrived articles
      if(mylst<gdlst) RServer::xoverdb(gdfst>mylst?gdfst:(mylst+1),gdlst);
    }
    _OverviewDB->lock(NVcontainer::UnLock);
  }
  return _OverviewDB;
}

/* group(name)
 * Select newsgroup with name and return informations 
 * about it
 * If the newsgroup does not exist, NULL will be returned.
 */
GroupInfo *CServer::group(const char *name)
{
  int fnd=0;
  VERB(log.p(Logger::Debug) <<"CServer::group(" << name << ")\n");
  
  if(strcmp(name,_gd.name())==0) {
    // Client reselects same group
    if(_gd.mtime()+_ttl_group<nvtime(NULL)) {
      // Try to retrieve informations on the newsgroup
      // If this fails we use the old informations
      RSGroup(name);
    }
  } else {  
    char buf[MAXPATHLEN], err[MAXPATHLEN+256];
    // Client selects different group
    fnd=_ActiveDB->get(name,&_gd);
    _RSGroup=0;
    if(fnd<0 || _gd.mtime()+_ttl_group<nvtime(NULL)) {
      // Group has not been found in the local active database
      // or it has timed out
      if(RSGroup(name)<0) {
	// Cannot connect to remote server or group neither
	// has been found locally nor on the remote server 
	if(fnd<0) throw UsageErr("411 no such news group");
      }
    }
    // Create directory if necessary
    sprintf(buf,"%s/%s",_rspooldir,group2dir(name));
    if(mkpdir(buf,0755)<0) {
      sprintf(err,"CServer::group: Cannot mkpdir %s\n",buf);
      throw SystemError(err,errno);  
    }
    sprintf(buf,"%s/%s/.xodb",_rspooldir,group2dir(_gd.name()));
    _OverviewDB->select(buf);
  }
  _Article.clear();
  return &_gd;
}

/* expire_article(fst,lst)
 * Removes all the articles with numbers fst to lst 
 * in the current newsgroup
 */
void CServer::expire_article(unsigned int fst, unsigned int lst)
{
  char artfn[MAXPATHLEN],*anbr;
  unsigned int i;

  anbr=artfn+sprintf(artfn,"%s/%s/a",_rspooldir,group2dir(_gd.name()));
  for(i=fst;i<=lst;i++) {
    sprintf(anbr,"%d",i);
    unlink(artfn);
  }
}

/* prefetch(name)
 * fetch all the articles of newsgroup name
 * This is cut&waste-code till I know, where to use
 * exceptions and where to use return-codes. :(
 * On the other hand, I didn't want to fiddle with
 * the timeouts in all the other routines...
 */
GroupInfo *CServer::prefetch(const char *name, unsigned int fst, unsigned int lst)
{
  VERB(log.p(Logger::Debug) <<"CServer::group(" << name << ")\n");
  if(!name) throw Error("Got NULL-pointer as name for newsgroup");

  char buf[MAXPATHLEN], err[MAXPATHLEN+256];
  unsigned int myfst, mylst;
  unsigned int gdfst, gdlst;
  unsigned int i;

  // Create directory if necessary
  sprintf(buf,"%s/%s",_rspooldir,group2dir(name));
  if(mkpdir(buf,0755)<0) {
    sprintf(err,"CServer::group: Cannot mkpdir %s\n",buf);
    throw SystemError(err,errno);  
  }

  // Select newsgroup and patch the active database with the new 
  // newsgroup informations
  RServer::group(name);
  _RSGroup=1;
  _ActiveDB->set(_gd);

  // Retrieve Overview-Database
  gdfst=_gd.first();
  gdlst=_gd.last();

  sprintf(buf,"%s/%s/.xodb",_rspooldir,group2dir(_gd.name()));
  _OverviewDB->select(buf);
  myfst=_OverviewDB->firstid();
  mylst=_OverviewDB->lastid();

  if(myfst!=gdfst || mylst!=gdlst) {
    _OverviewDB->lock(NVcontainer::ExclLock);
    myfst=_OverviewDB->firstid();
    mylst=_OverviewDB->lastid();

    // The expiry checks have to be done twice for the same
    // reasons as for the active database
    if(gdfst<myfst) {
      // Server's first article number smaller than mine
      // => Something's wrong => Retrieve whole OverviewDB
      VERB(log.p(Logger::Warning) << "Newsserver's fst article number < mine\n");    
      _OverviewDB->clear();
      expire_article(myfst,mylst);
      RServer::xoverdb(_gd.first(),_gd.last());
    } else {
      // Remove XOverDB for expired articles, if it is
      // not empty (mylst>myfst)
      if(myfst<gdfst && mylst>myfst) {
	_OverviewDB->expire(1,gdfst-1);
	expire_article(myfst,_gd.first()-1);
      }

      // Retrieve XOverDB for newly arrived articles
      if(mylst<gdlst) RServer::xoverdb(mylst+1,gdlst);
    }
    _OverviewDB->lock(NVcontainer::UnLock);
  }

  // Retrieve articles of this newsgroup
  gdfst=_gd.first();
  gdlst=_gd.last();
  for(i=gdfst>lst?gdfst:lst+1;i<=gdlst;i++) {
    article(i);
  }

  _Article.clear();
  return &_gd;
}

#endif
