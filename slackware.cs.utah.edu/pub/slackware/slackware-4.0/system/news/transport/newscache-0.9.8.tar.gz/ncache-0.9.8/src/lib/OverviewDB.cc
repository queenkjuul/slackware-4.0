#include<ctype.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<stdio.h>
#include<utime.h>
#include<unistd.h>

#include"Configure.h"
#include"Logger.h"
#include"Error.h"
#include"OverviewDB.h"

void NVOverviewDB::read(istream &is, XOverFmt *rxo)
{
  TRACE(ctrace << "XOverDB::readDB(&is)\n");
  Regex r("[\r\n]+");
  String line1,line2;
  time_t now;
  int i;

  lock(ExclLock);
  for(;;) {
    readline(is,line1,'\n',0);
    if(line1==".\r\n" || line1==".\n") break;
    if(is.eof()) break;
    line1.at(r,-1)="";
    if(xoverfmt.dotrans) {
      // Convert Record
      xoverfmt.convert(line1,line2);
      append((const char*)line2,line2.length()+1);
    } else {
      append((const char*)line1,line1.length()+1);
    }
  }

  time(&now);
  setmtime(now);
  lock(UnLock);
}

void NVOverviewDB::xhdr(ostream &os, const char *hdr, unsigned int fst, unsigned int lst) 
{
  lock(ShrdLock);
  unsigned int id;
  int hp,hf,i;
  char *buf, *err, *p,*q, out[256];
  Record *head=o2r(getdata());
  Record *r=head;
  
  if(hdr) {
    xoverfmt.hdrpos(hdr,&hp,&hf);
    if(hp<0) return;
    hp++;
  } else {
    hp=-1; hf=0; out[0]='\0';
  }
  while(r) {
    r=o2r(r->next);
    
    buf=r->datap();
    id=strtol(buf,(char**)&err,10);
    ASSERT(if(err==buf) {
      log.p(Logger::Critical) << "Illegal record in xoverdb\n";
      throw Error("Illegal record in xoverdb! OVERVIEW DATABASE CORRUPTED?!?");
      id=0;
    });
    if(id>=fst && (id<=lst || lst==0)) {
      if(hp>=0) {
	i=0; p=buf;
	while(*p && i<hp) if(*p++=='\t') i++;
	if(hf) p+=strlen(hdr)+1;
	while(isspace(*p)) p++;
	out[0]=' ';
	q=out+1;
	while(*p && *p!='\t') *q++=*p++;
	*q='\0';
      }
      os << id << out << "\r\n";
    }
    if(r==head) r=NULL;
  }
  
  lock(UnLock);
}

void NVOverviewDB::write(ostream &os, unsigned int fst, unsigned int lst) 
{
  lock(ShrdLock);
  unsigned int id;
  char *buf, *err;
  Record *head=o2r(getdata());
  Record *r=head;
  
  while(r) {
    r=o2r(r->next);
    
    buf=r->datap();
    id=strtol(buf,(char**)&err,10);
    ASSERT(if(err==buf) {
      log.p(Logger::Error) << "Illegal record in xoverdb\n";
      id=0;
    });
    if(id>=fst && (id<=lst || lst==0)) {
      os << buf << "\r\n";
    }
    if(r==head) r=NULL;
  }
  
  lock(UnLock);
}

void NVOverviewDB::expire(unsigned int fst, unsigned int lst) 
{
  VERB(log.p(Logger::Debug) << "NVOverviewDB::expire(" 
                            << fst << "-" << lst << ")\n");    
  lock(ExclLock);

  unsigned int id=0;
  Record *r;

  while((r=o2r(getdata()))!=NULL && id<=lst) {
    r=o2r(r->next);
    id=atoi(r->datap());
    if(id>=fst && id<=lst) sremove(getdatap());
  }
  lock(UnLock);
}

unsigned int NVOverviewDB::firstid() 
{
  lock(ShrdLock);

  unsigned int id=0;
  Record *r=o2r(getdata());

  if(r) {
    r=o2r(r->next);
    id=atoi(r->datap());
  }
  lock(UnLock);

  return id;
}

unsigned int NVOverviewDB::lastid() 
{
  lock(ShrdLock);

  unsigned int id=0;
  Record *r=o2r(getdata());

  if(r) id=atoi(r->datap());
  lock(UnLock);

  return id;
}
