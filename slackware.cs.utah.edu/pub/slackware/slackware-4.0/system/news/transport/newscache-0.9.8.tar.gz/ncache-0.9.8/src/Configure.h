#ifndef __Configue_h__
#define __Configue_h__
//##############################################################
//Begin User Configuration

//##############
//## Machine Dependant Configurations
//##############

/* sasize_t:
 * alpha-linux:	size_t
 * The gcc for alpha-linux has a broken exception handling.
 * Thus, NewsCache will not run under alpha-linux
 * i386-linux:	int
 */
typedef int sasize_t;

//##############
//## Server Configuration
//##############

/* CONF_ServerRoot
 * ServerRoot of the newscache. This is the location, where
 * all the configuration-files reside
 */
//#define CONF_ServerRoot "/home/studs/gschwind/lib/newscache"
#define CONF_ServerRoot "/home/tom/lib/newscache"

/* CONF_OverviewFmt
 * This defines the format of your overview-database. The overview
 * database stores the most important data for each article
 * (subject, date, lines, ...). Set this to the format of the
 * news server being most heavily used. You may find out this
 * format using the following commands
 * telnet news.server nntp
 * mode reader
 * list overview.fmt
 * quit
 * The optional full keyword must be written in small letters!!!
 */
#define CONF_OverviewFmt {"Subject:","From:","Date:",\
       "Message-ID:","References:","Bytes:","Lines:",\
       "Xref:full",NULL}

/* CONF_UseExceptions
 * Define this if you want to enable the exception-handling.
 * Disabling exceptionhandling does not work currently.
 */
#define CONF_UseExceptions

/* System Dependent Data
 * Hashsize of the active database. Use number of groups/(3..10)
 * _Should_ be a prime
 * Eg 211, 503, 1009, 1709, 2903, 4099, 4801, 6007, 7901, 9001, 15013
 */
#define CONF_NVActiveDB_HASHSIZE 15013

/* CONF_MultiClient
 * Allow several simultaneous clients in standalone mode.
 * This switch is turned off for debug purposes mainly.
 */
#define CONF_MultiClient

/* CONF_UIDROOT
 * The userid of your superuser (usually root). 
 * Usually, this is 0.
 */
#define CONF_UIDROOT 0

//End User Configuration
//##############################################################

/* Do not touch anything outside the user configuration section
 * unless you _know_ what you are doing.
 */

#include"Debug.h"

#ifdef CONF_UseExceptions
#define EXCEPTION(x) throw x
#else
#define EXCEPTION(x)
#endif

/* This does not work currently... How can we identify whcih system 
 * lacks which options?
 * Define this if some prototypes have not been defined in your
 * header files. Among these are socket, bcopy, connect and others.
 */

#ifdef BROKEN_SUN
#define NEED_PT_SOCKET
#define NEED_PT_BCOPY
#define NEED_PT_CONNECT
#define NEED_PT_ACCEPT
#define NEED_PT_BIND
#define NEED_PT_LISTEN
#endif

#ifdef NEED_PT_SOCKET
//int socket(/*int domain, int type, int protocol*/);
#endif

#ifdef NEED_PT_BCOPY
//void bcopy(/*char *b1, char *b2, int length*/);
#endif

#ifdef NEED_PT_CONNECT
//int connect(/*int s, struct sockaddr *name, int namelen*/);
#endif

#ifdef NEED_PT_ACCEPT
     int accept(s, addr, addrlen)
     int s;
     struct sockaddr *addr;
     int *addrlen;
#endif

#endif
