#include<iostream.h>

#include"XOverFmt.h"

main(int argc, char *argv[])
{
  Regex r("[\r\n]+");
  String s1,s2;
  XOverFmt xofmt;

  cout << "Format of my overview database\n";
  cout << xofmt;
  cout << "Format of your overview database?\n";
  xofmt.readxoin(cin);
  while(cin) {
    readline(cin,s1,'\n',0);
    s1.at(r,-1)="";
    cout << "in:" << s1 << "\r\n";
    xofmt.convert(s1,s2);
    cout << "out:" << s2 << "\r\n";
  }
}
