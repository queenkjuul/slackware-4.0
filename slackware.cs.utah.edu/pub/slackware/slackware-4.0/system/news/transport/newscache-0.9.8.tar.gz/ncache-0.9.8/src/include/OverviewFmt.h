#ifndef __OverviewFmt_h__
#define __OverviewFmt_h__
#include<stdlib.h>
#include<string.h>

#include<String.h>

#include"Article.h"
#include"Configure.h"
// readtext:
#include"List.h" 

class OverviewFmt {
  /* xoout ... Output format of overview-database
   * xohdrs ... Headers of overview-database --- same as xoout, except
   *            the full suffix
   * trans[i] ... Position of i-th overview record field (in my format) 
   *              in incoming records
   * transflg ... Indicates, whether the header has to be prepended
   *              or stripped.
   * dotrans ... Indicates, whether incoming database records have
   *             to be translated
   */
  const char *xoout[256];
  String xohdrs[256];
  int trans[256];
  int transflg[256];
  enum { hdr_keep=0x0, hdr_strip=0x1, hdr_prepend=0x2 };
  int xosz;
public:
  int dotrans;
  OverviewFmt() {
    const char *tmp[]=CONF_OverviewFmt;
    for(xosz=0;tmp[xosz];xosz++) {
      xoout[xosz]=tmp[xosz];
      xohdrs[xosz]=tmp[xosz];
      xohdrs[xosz]=xohdrs[xosz].before(':')+':';
    }
    dotrans=0;
  }

  const char *getfield(const char *over, const char *fld, int Full=0) {
    static String _field;
    int i;

    for(i=0;i<xosz;i++) {
      if(strcasecmp(fld,xohdrs[i])==0) {
	int j=i+1;
	const char *p=over,*q;
	
	while(*p && j) {
	  if(*p++=='\t') j--;
	}
	q=p;
	while(*q && *q!='\t') q++;
	_field=p;
	_field=_field.before(q-p);
	return (const char*)_field;
      }
    }
    return NULL;
  }

  /*
   */
  void hdrpos(const char *hdr, int *hdrpos, int *full) {
    int i,hdrlen=strlen(hdr);

    for(i=0;i<xosz;i++) {
      if(strncasecmp(hdr,xoout[i],hdrlen)==0 && xoout[i][hdrlen]==':') {
	*hdrpos=i;
	*full=xoout[i][hdrlen+1];
	return;
      }
    }
    *hdrpos=-1;
    *full=0;
  }    

  /* readxoin
   * reads the format of input-overview database
   * set up translation for input/output conversion
   */
  void readxoin(istream &is) { 
    String xo;
    char buf[256],c;
    const char *p;
    int i,j,k,l;
    int xol,xil,xml;
    dotrans=0;
    readtext(is,xo);
    trans[0]=0;
    transflg[0]=hdr_keep;
    for(i=0;i<xosz;i++) { 
      trans[i+1]=-1; 
      if(strstr(xoout[i],":full")) transflg[i+1]=hdr_prepend;
      else transflg[i+1]=hdr_keep;
    }
    j=0; k=0;
    p=(const char*)xo;
    while((c=*p++)!='\0') {
      if(c=='\n' || c=='\r') {
	if(c=='\r' && *p=='\n') p++;
	buf[j]='\0';
	// find buf within xoout
	for(l=0;l<xosz;l++) {
	  xol=strlen(xoout[l]);
	  xil=j;
	  xml=xil<xol?xil:xol;
	  if(strncmp(xoout[l],buf,xml)==0) {
	    trans[l+1]=k;
	    if(xil==xol) {
	      transflg[l+1]=hdr_keep;
	    } else if(strcmp("full",xoout[l]+xml)==0) {
	      transflg[l+1]=hdr_prepend;
	    } else if(strcmp("full",buf+xml)==0) {
	      transflg[l+1]=hdr_strip;
	    } else {
	      VERB(log.p(Logger::Error) << "XOverFmt: Cannot setup conversion table\n"); 
	      transflg[l+1]=hdr_keep;
	    }
	    break;
	  }
	}
	j=0;
	k++;
      } else {
	buf[j]=c;
	j++;
      }
    }
    if(xosz!=k) {
      dotrans=1;
    } else {
      for(i=0;i<xosz;i++) {
	if(trans[i+1]!=i || transflg[i]!=hdr_keep) {
	  dotrans=1;
	  //break;
	}
      }
    }
  }

  /* convert
   * convert overview-record from input-format to output-formta
   */
  void convert(String &recin, String &recout) {
    String tmp;
    int tabpos[256];
    int i,j,k;
    if(!dotrans) {
      recout=recin;
      return;
    }
    tabpos[0]=0;
    j=0; i=1;
    do {
      tabpos[i]=j=recin.index("\t",j)+1;
      i++;
    } while(j>0);
    tabpos[i-1]=recin.length()+1;
    // construct new string
    if((j=trans[i=0])>=0) {
      k=tabpos[j];
      switch(transflg[i]) {
      case hdr_keep:
	recout=recin.at(k,tabpos[j+1]-k-1);
	break;
      case hdr_strip:
	k+=xohdrs[i].length();
	tmp=recin.at(k,tabpos[j+1]-k-1);
	recout=tmp.after(RXwhite);
	break;
      case hdr_prepend:
	recout=xohdrs[i]+' '+recin.at(k,tabpos[j+1]-k-1);
	break;
      }
    } else {
      if(transflg[i]==hdr_keep) recout="";
      else recout=xohdrs[i];
    }
    for(i=1;i<xosz+1;i++) {
      recout+='\t';
      if((j=trans[i]+1)>=0) {
	k=tabpos[j];
	switch(transflg[i]) {
	case hdr_keep:
	  recout+=recin.at(k,tabpos[j+1]-k-1);
	  break;
	case hdr_strip:
	  k+=xohdrs[i].length();
	  tmp=recin.at(k,tabpos[j+1]-k-1);
	  recout+=tmp.after(RXwhite);
	case hdr_prepend:
	  recout+=xohdrs[i];
	  recout+=' ';
	  recout+=recin.at(k,tabpos[j+1]-k-1);
	  break;
	}
      } else {
	if(transflg[i]==hdr_prepend) recout+=xohdrs[i];
      }
    }
  }

  void convert(Article *article, String &recout) {
    char buf[256];
    const char *fld;
    int f,i;

    sprintf(buf,"%d",article->getnbr());
    recout=buf;
    for(i=0;i<xosz;i++) {
      recout+='\t';
      if(strncasecmp(xoout[i]+xohdrs[i].length(),"full",4)==0) f=1;
      else f=0;
      if((fld=article->getfield(xohdrs[i],f))!=NULL) recout+=fld;
    }
  }

  friend ostream &operator <<(ostream &os, OverviewFmt &o) { 
    int i;
    for(i=0;i<o.xosz;i++) {
      os << o.xoout[i] << "\r\n";
    }
    return os;
  }
};

#endif
