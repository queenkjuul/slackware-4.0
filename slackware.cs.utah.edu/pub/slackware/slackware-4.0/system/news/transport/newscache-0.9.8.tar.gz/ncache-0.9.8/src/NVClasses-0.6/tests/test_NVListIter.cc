#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "NVList.h"

const char *h="Hello World!";

int main(int argc, char *argv[])
{
  cout << argv << "/" << argc << ":\n";

  NVList nvl("/tmp/nvl");
  NVListIter nvli(nvl);

  if(!nvli.is_empty()) {
    const char *data;
    unsigned int szdata;

    nvli.first();
    do {
      nvli.data(&data,&szdata);
      cout << szdata << ": " << data << "\n";
      nvli.next();
    } while(!nvli.is_first());
  }

  nvli.detach();
  nvl.close();
  return 0;
}
