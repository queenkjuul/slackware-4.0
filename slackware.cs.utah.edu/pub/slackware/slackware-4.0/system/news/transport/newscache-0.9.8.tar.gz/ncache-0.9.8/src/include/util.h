#ifndef _NSutil_h_
#define _NSutil_h_

extern int mkpdir(char *dirname, int mode);
extern const char *group2dir(const char *name);
extern int matchgroup(const char *pattern, const char *group);

#endif
