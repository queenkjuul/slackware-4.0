#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<unistd.h>
#include<getopt.h>

#include<iostream.h>

#include"Configure.h"
#include"Config.h"
#include"NServer.h"

TRACE(ofstream ctrace("trace"));
DEBUG(ofstream cdbg("debug"));

const char *cmnd;
const char *Version="0.85";

Config Cfg;

int readgroup(NServer *myserv, GroupInfo *gd, int cfst, int clst)
{
  char ofn[256];
  ofstream ofs;

  XOverDB *xodb;
  Article *a;
  XOverDBIter xodbit;
  int firstnbr, lastnbr,n=0;
  
  cout << gd->name() << ": Xover\r";
  xodb=myserv->xoverdb(gd->first(),gd->last());

  sprintf(ofn,"%s/.xodb",(const char*)gd->name());
  ofs.open(ofn);
  ofs << *xodb;
  ofs.close();
  
  // Set first and last article number to retrieve;
  firstnbr=clst+1;
  if(gd->first()>firstnbr) firstnbr=gd->first();
  if(gd->first()<cfst) {
    cerr << gd->name() << ": Server's first index smaller than read index\n";
    firstnbr=gd->first();
  }
  lastnbr=gd->last();

  if(lastnbr<firstnbr) return n;

  for(xodbit.attach(*xodb);xodbit.valid();xodbit.next()) {
    String nbr;  
    int i;
    
    nbr=xodbit().before(RXwhite);
    i=atoi((const char*)nbr);
    if(firstnbr<=i && i<=lastnbr) {
      cout << "  Article " << i << "\r";
      try {
	a=myserv->article(i);
	sprintf(ofn,"%s/a%d",(const char*)gd->name(),i);
	ofs.open(ofn);
	ofs << *a;
	ofs.close();
	n++;
      }
      catch (ResponseErr &r) {
	cerr << "Caught!\n";
	// If bad article number, just skip
	if(r._got.before(3)!="423") throw;
      }
      catch (...) {
	TRACE(ctrace << "Ooops, Skipping\n");
	DEBUG(cdbg << "Ooops, Skipping\n");
	cerr << "Ooops, Skipping\n";
      }
    }
  } /* for */

  return n;
}

void readnews(NServer *myserv)
{
  GroupList *gl;
  GroupDesc *gd;
  XOverDB *xodb;

  char ofn[256];
  ofstream ofs;
  ifstream ifs;
  ofstream gfs;

  String line;

  // Retrieve Active File
  cout << "Retrieving .active\n";
  gl=myserv->list();
  ofs.open(".active");
  ofs << *gl;
  ofs.close();

  // Retrieve requested newsgroups
  rename(".newsrc",".oldnewsrc");
  gfs.open(".newsrc",ios::out);
  ifs.open(".oldnewsrc",ios::in);

  while(readline(ifs,line) && ifs.good()) {
    String grp,s;
    int i,j,cfst,clst;

    if(line[0]=='#') {
      gfs << line << "\n";
      continue;
    }

    cfst=clst=0;
    i=line.index(':');
    if(i!=-1) {
      grp=line.before(i);
      if((j=line.index('-'))!=-1) {
	cfst=atoi(s=line.after(i));
	clst=atoi(s=line.after(j));
      }
    } else {
      grp=line;
    }

    cout << grp << ": select\r";
    gd=myserv->group((const char*)grp);
    gfs << grp << ": " << gd->first() << "-" << gd->last() << endl;
    cout << grp << ": " << gd->first() << "-" << gd->last() << "   \n";

    if(gd->n) {
      // New articles arrived
      int n;

      sprintf(ofn,"%s",(const char*)grp);
      mkdir(ofn,0777);

      n=readgroup(myserv,gd,cfst,clst);
      cout << grp << ": Read " << n << " Articles\t\n";
    } else {
      cout << grp << ": Empty\t\n";
    }
  }
  ifs.close();
  gfs.close();
}

void postnews(NServer *myserv)
{
  char ifn[256];
  int ifd;
  ifstream ifs;
  int i,qnbr;
  int retry,errs=0,slptm=1;
  Article art;

  if((ifd=open(".outgoing/.qnbr",O_RDONLY))<0) {
    if(errno==ENOENT) {
      cout << "No article to post\n";
      return;
    }
    cerr << "Cannot open .outgoing/.qnbr: " << strerror(errno) << endl;
    exit(11);;
  }
  ifs.attach(ifd);
  ifs >> qnbr;
  if(!ifs.good()) {
    cerr << "Cannot read .outgoing/.qnbr\n";
    exit(11);
  }
  ifs.close();

  for(i=0;i<qnbr;i++) {
    cout << "Article " << i << "\r";
    cout.flush();
    sprintf(ifn,".outgoing/a%d",i);
    ifs.open(ifn);
    ifs.unsetf(ios::skipws);
    if(!ifs.good()) {
      cerr << "Article " << i << "(" << ifn 
	   << "): Cannot open: " << strerror(errno) << endl;
      continue;
    }
    art.setnbr(i);
    art.read(ifs);
    ifs.close();

    // Try to post article
    retry=0;
    while(retry>=0 && retry<=Cfg.Retries) {
      try {
	sleep(slptm<<retry);
	myserv->post(art);
	retry=-1;
      } 
      catch (ResponseErr &r) {
	cerr << "Caught ResponseErr:\n" 
	     << " " << r._got 
	     << " Retrying article " << i << endl;
	retry++;
      }
    }
    if(retry>Cfg.Retries) {
      // Posting failed
      errs++;
    } else {
      // Posted article successfully
      if(unlink(ifn)<0) {
	cerr << "Article " << i << "(" << ifn 
	     << "): Cannot unlink: " << strerror(errno) << endl;
      }
    }
  } /* for */

  if(errs) {
    cout << errs << " postings failed\n";
  } else {
    if(unlink(".outgoing/.qnbr")<0) {
      cerr << "Cannot unlink .outgoing/.qnbr: " << strerror(errno) << endl;
    }
  }
}

#define RF_USAGE 0x01
#define RF_POST 0x02
#define RF_READ 0x04
#define RF_PARALLEL 0x08
int main(int argc, char *argv[])
{
  const char *config_file="etc/newscache.conf";
  RServer *myserv;

  int option_index=0;
  int runflags=RF_POST|RF_READ;
  int c;

  TRACE(ctrace.setf(ios::unitbuf));
  DEBUG(cdbg.setf(ios::unitbuf));
  cmnd=argv[0];

  for(;;) {
    static struct option long_options[] = {
      {"read-only", 0, 0, 'R'},
      {"post-only", 0, 0, 'P'},
      {"version", 0, 0, 'V'},
      {"config-file", 1, 0, 'c'},
      {"help", 0, 0, 'h'},
      {"parallel", 0, 0, 'p'},
      {"verbose", 0, 0, 'v'},
      {0, 0, 0, 0}
    };

    c=getopt_long(argc, argv, "c:rphV", long_options, &option_index);
    if(c==-1) break;

    switch(c) {
    case 'P':
      runflags=RF_READ;
      break;
    case 'R':
      runflags=RF_POST;
      break;
    case 'V':
      printf("%s version %s\n",cmnd,Version);
      exit(0);
    case 'c':
      config_file=optarg;
      break;
    case 'h':
      runflags=RF_USAGE;
      break;
    case 'p':
      runflags|=RF_PARALLEL;
      break;
    case 'v':
#ifdef VERBOSE      
      verbose++;
#else
      cerr << cmnd << ": Verbose mode not compiled in. Ignored.\n";
#endif
      break;
    default:
      cerr << cmnd << ": Illegal option: " 
	   << (char)c << " (" << (int)c << ")\n";
      runflags=RF_USAGE;
    }
  }

  if(runflags==RF_USAGE) {
    cerr << "Usage: " << cmnd << " [-PRVhpv] [-c config-file]\n";
    cerr << "Posts articles in outgoing spool-directory and\n";
    cerr << "reads newly arrived articles.\n";
    exit(1);
  }

  Cfg.read(config_file);
  chdir(Cfg.SpoolDir);

  if ((myserv=new RServer(Cfg.NewsServer,Cfg.NNTPPort))==NULL) {
    cerr << "Failed to create RServer\n";
    exit(1);
  }
  
  if(runflags&RF_PARALLEL) {
    int pid;

    cout << "Forking...\n";
    pid=fork();
    if(pid<0) {
      cerr << cmnd << ": cannot fork: " << strerror(errno) << endl;
      exit(11);
    }
    if(pid==0) {
      cout << "Posting...\n";
      postnews(myserv);
      delete myserv;
    } else {
      cout << "Reading...\n";
      readnews(myserv);
      delete myserv;
    }
  } else {
    cout << "Posting...\n";
    postnews(myserv);
    cout << "Reading...\n";
    readnews(myserv);
    delete myserv;
  }

}
