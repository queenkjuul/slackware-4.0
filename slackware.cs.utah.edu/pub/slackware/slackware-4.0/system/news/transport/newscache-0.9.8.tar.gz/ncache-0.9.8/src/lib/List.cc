#include"List.h"
#include<String.h>

int nlreadline(istream &is,             // Input-Stream
	       String &strg,            // String to store line
	       int keepnl=1             // Keep newline
	       ) 
{
  int pos,ch;
  ch=readline(is,strg,'\n',!keepnl);
  pos=strg.length();
  if(keepnl) {
    if(strg.after(pos=pos-3)=="\r\n") {
      strg.after(pos)="\n";
      ch--;
    }
    return ch;
  } else {
    if(strg.after(pos=pos-2)=="\r") {
      strg.after(pos)="";
      ch--;
    }
    return ch;
  }
}

int readtext(istream &is,               // Input-Stream
	     List<String> &SList,       // List to store the text
	     int keepnl=1,              // Keep newlines in text
	     char *eot=".\n"            // EndOfText Marker
	     ) 
{
  int lines=0;
  String line;
  int eotlen=strlen(eot);

  while(!is.eof()) {
    if (nlreadline(is,line,keepnl)==eotlen && line==eot) break;
    if(is.eof()) break;
    SList.append(line);
    lines++;
  }

  return lines;
}

int readtext(istream &is,               // Input-Stream
	     String &Strg,              // String to store the text
	     int keepnl=1,              // Keep newlines in text
	     char *eot=".\n"            // EndOfText Marker
	     ) 
{
  int lines=0;
  String line;
  int eotlen=strlen(eot),i;

  while(!is.eof()) {
    if ((i=nlreadline(is,line,keepnl))==eotlen && line==eot) break;
    if(is.eof()) break;
    Strg+=line;
    lines++;
  }

  return lines;
}
