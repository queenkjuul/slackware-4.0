#ifndef __Config_h__
#define __Config_h__

/* Copyright Th Gschwind 1996, 1997 */
#include <sys/param.h>
#include <time.h>

#include <iostream.h>

#include "MPList.h"

class Config {
public:
  char uname[256];
  char gname[256];

  char SpoolDir[MAXPATHLEN];
  char PrefetchFile[MAXPATHLEN];

  enum { inetd, standalone };
  int ServerType;
  char CachePort[256];

  MPList srvrs;

  time_t ttl_list;
  time_t ttl_desc;
  time_t ttl_group;

  int Retries;

  Config() { 
    ttl_list=4*3600; /* 4hr */
    ttl_group=600;    /* 10mn */
    Retries=3;
  }
  
  Config(const char *fn) { read(fn); }
  
  void read(const char *fn);
  MPListEntry *server(const char *group) {
    return srvrs.server(group);
  }
  void dump(ostream &ofs);
};

#endif
