#ifndef _Debug_h_
#define _Debug_h_
#include<fstream.h>

#include"Logger.h"
// Insert the following lines into your main app
//TRACE(ofstream ctrace("trace"));
//DEBUG(ofstream cdbg("debug"));
//int verbose=0
//int verbose_what=0

// Verbosity levels
// See logger.h
#ifdef VERB_ON
//extern int verbose;
//extern int verbose_what;
extern Logger log;
#ifndef VERB
#define VERB(x) x
#endif
#ifndef VERBLV
#define VERBLV(lv,x) if(lv<verbose) { x; }
#endif
#ifndef VERBTY
#define VERBTY(w,x) if(verbose_what==w) { x; }
#endif
#else
#define VERB(x)
#define VERBLV(lv,x)
#define VERBTY(w,x)
#endif

#ifdef TRACE_ON
extern ofstream ctrace;
#define TRACE(x) x
#else
#define TRACE(x)
#endif

#ifdef DEBUG_ON
extern ofstream cdbg;
#define DEBUG(x) x
#else
#define DEBUG(x)
#endif

#ifdef ASSERT_ON
#define ASSERT(x) x
#else
#define ASSERT(x)
#endif

#endif
