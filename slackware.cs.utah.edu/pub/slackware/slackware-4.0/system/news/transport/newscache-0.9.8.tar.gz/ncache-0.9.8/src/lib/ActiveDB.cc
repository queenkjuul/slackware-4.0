#include"ActiveDB.h"

ActiveDB::ActiveDB() 
{
}

ActiveDB::~ActiveDB()
{
}
