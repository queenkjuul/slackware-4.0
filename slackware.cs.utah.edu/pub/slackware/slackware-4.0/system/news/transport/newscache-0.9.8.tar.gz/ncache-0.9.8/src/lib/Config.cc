#include<iostream.h>
#include<fstream.h>
#include<String.h>

#include<ctype.h>
#include<string.h>
#include<stdlib.h>

#include"Configure.h"
#include"Config.h"

/****************************************************************
 * CONFIG
 ****************************************************************/
#define STRNZCPY(dest,source,n) { strncpy(dest,source,n); dest[n-1]='\0'; }

void Config::read(const char *fn)
{
  ifstream ifs(fn);
  char line[10240];
  char *argv[256];
  int i,argc;
  // THROW!
  if(ifs.bad()) exit(9);

  for(;;) {
    ifs.getline(line,sizeof(line),'\n');
    if(!ifs.good()) {
      if(ifs.fail() && !ifs.eof()) {
	cerr << "Config: line in config exceeds limit of 10240 chars\n";
      }
      break;
    }
    if(line[0]=='#') continue;
    
    for(i=0,argc=0 ; line[i] && argc<256 ; i++) {
      if(isspace(line[i])) line[i]='\0';
      if(line[i] && (i==0 || line[i-1]=='\0')) argv[argc++]=line+i;
    }
    if(argc==0) continue;

    DEBUG(cdbg << "Var " << argv[0] << '/' << argc << endl);
    if(strcmp(argv[0],"SpoolDirectory")==0) {
      STRNZCPY(SpoolDir,argv[1],sizeof(SpoolDir));
    } else if(strcmp(argv[0],"PrefetchFile")==0) {
      STRNZCPY(PrefetchFile,argv[1],sizeof(PrefetchFile));
    } else if(strcmp(argv[0],"Username")==0) {
      STRNZCPY(uname,argv[1],sizeof(uname));
    } else if(strcmp(argv[0],"Groupname")==0) {
      STRNZCPY(gname,argv[1],sizeof(gname));
    } else if(strcmp(argv[0],"CachePort")==0) {
      STRNZCPY(CachePort,argv[1],sizeof(CachePort));
    } else if(strcmp(argv[0],"ServerType")==0) {
      if(strcmp(argv[1],"inetd")==0) ServerType=inetd;
      else if(strcmp(argv[1],"standalone")==0) ServerType=standalone;
      else { 
	cerr << "Illegal ServerType\n";
	exit(1);
      }
    } else if(strcmp(argv[0],"ConfigVersion")==0) {
      if(atoi(argv[1])<1) {
	cerr << "Warning, config file for older version\n";
      }
    } else if(argc==2 && strcmp(argv[0],"NewsServers")==0) {
      srvrs.read(ifs);
    } else if(argc==4 && strcmp(argv[0],"TimeOuts")==0) {
      ttl_list=atoi(argv[1]);
      ttl_desc=atoi(argv[2]);
      ttl_group=atoi(argv[3]);
    } else if(strcmp(argv[0],"Retries")==0) {
      Retries=atoi(argv[1]);
    } else {
      cerr << "Illegal command: " << argv[0] << '/' << argc << endl;
    }
  }
}

void Config::dump(ostream &ofs)
{
  ofs << "Config {\n";
  ofs << "  SpoolDirectory \t" << SpoolDir << endl;
  srvrs.dump(ofs);
  ofs << "  TimeOuts \t" 
      << ttl_list << " " << ttl_desc << " " << ttl_group << endl;
  ofs << "  CachePort \t" << CachePort << endl;
  ofs << "  Retries \t" << Retries << endl;
  ofs << "}\n";
}
