#include <ctype.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include "sstream.h"

sstream con;

int main(int argc, char *argv[])
{
  int res;
  char buf[256];

  if(argc!=XXXXX) {
    fprintf(stderr,"Usage: %s USAGE\n",argv[0]);
    exit(1);
  }

  /* Setup */

  while(fgets(buf,sizeof(buf),stdin)) {
    errno=0;
    switch(tolower(buf[0])) {
    case 'c':
      char *name,*port;
      port=name=buf+1;
      while(!isspace(*port)) port++;
      *port='\0'; port++;
      con.connect(name,port);
      cout << "Good: " << con.good() << endl;
      break;
    case 'd':
      con.disconnect();
      break;
    case 'r':
      break;
    case 'w':
      break;
    default:
      printf("(C)onnect    (D)isconnect    (R)ead    (W)rite\n");
    }
    printf("Result: %d   ErrStr(%d): %s\n",res,errno,strerror(errno));    
  }

  return 0;
}
