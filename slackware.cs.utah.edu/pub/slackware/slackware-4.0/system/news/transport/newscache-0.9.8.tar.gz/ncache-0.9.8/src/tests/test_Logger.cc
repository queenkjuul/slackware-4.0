/* lserver.cc (c) 1996 by Thomas GSCHWIND 
 * -- implements a news server in combination with the provided library.
 * -- the following kinds of news servers are provided:
 * -- remote, local, caching news server
 *
 * This software may be freely redistributed as long as this copyright
 * issue is included without any modifications. Any commercial use
 * without the author's prior consent is prohibited.
 *
 * This software is provided as is without warranty of any kind, either
 * expressed or implied, including, but not limited to, the implied
 * warranties of merchantibility and fitness for a particular purpose.
 *
 * As soon as I release the version 1.0 will put it under the 
 * GNU General Public License.
 */
#include <iostream.h>

#include "Logger.h"

//Notes {
// Config �berarbeiten. Bei Syntaxfehler beenden. 
// Switch ?-d? der nur Config einliest und ausgibt.
//} Notes

Logger log;

void nnrpd(int fd)
{
  if(fd>=0) {
  }
  do {
    // Read command
    clt.ci->getline(req,sizeof(req),'\n');
    if(!clt.ci->good()) break;
    strcpy(oreq,req);
    VERB(log.p(Logger::Info) 
	 << "> \n"); 
    //	 << oreq 
    //	 << "\n");

    // Split command into arguments
    for(i=0, argc=0;req[i] && argc<256;i++) {
      if(isspace(req[i])) req[i]='\0';
      else req[i]=tolower(req[i]);
      if(req[i] && (i==0 || req[i-1]=='\0')) argv[argc++]=req+i;
    }
    if(argc==256) {
      (*clt.co) << "500 Line too long\r\n";
      continue;
    }
    com=argv[0];

    // Execute command
    p=nnrp_commands;
    while(p->name) {
      if (strcmp(p->name,com)==0) { 
	VERB(if((errc=p->func(&clt,argc,argv))<0) {
	  log.p(Logger::Notice) << "> " << oreq << " failed!\n";
	});
	break; 
      }
      p++;
    }
    if(p->name==NULL) {
      VERB(log.p(Logger::Notice) << "> " << oreq << " not recognized!\n");
      (*clt.co) << "500 Sorry\r\n";
    }
  } while(errc<=0);
  VERB(log.p(Logger::Notice) << "Connection closed\n");
  /*clt.co->close();*/
  delete clt.srvr;
}


void nntpd()
{
  int sock;
  struct sockaddr_in nproxy;
  const char *cp;
  struct servent *cport;

  struct sockaddr_in clt_sa;
  sasize_t clt_salen;
  int clt_fd;
  int clt_pid;
    
  if ((sock=socket(AF_INET, SOCK_STREAM, 0))<0) {
    cerr << "Can't create socket: " << strerror(errno);
    exit(1);
  }

  nproxy.sin_family=AF_INET;
  nproxy.sin_addr.s_addr=INADDR_ANY; 
  
  cp=Cfg.CachePort;
  if(cp[0]!='#') {
    if ((cport=getservbyname(cp,"tcp"))==NULL) {
      cerr << cmnd << ": Can't resolve service " << cp << "/tcp\n";
      exit(1);
    }
    nproxy.sin_port=cport->s_port;
  } else {
    nproxy.sin_port=htons(atoi(cp+1));
  }
  cerr << cmnd << ": Binding to port " << ntohs(nproxy.sin_port) 
       << " (" << cp << ")\n";

  if (bind(sock, (struct sockaddr *)&nproxy, sizeof(nproxy))<0) {
    fprintf(stderr,"Can't bind socket: %s\n",strerror(errno));
    exit(1);
  }

  listen(sock,4);
  for(;;) {
    /* Accept connection */
    clt_salen=sizeof(clt_sa);
    clt_fd=accept(sock,(struct sockaddr *)&clt_sa,&clt_salen);
    if (clt_fd<0) {
      fprintf(stderr,"Can't accept connection: %s",strerror(errno));
      exit(1);
    }
    fprintf(stderr,"Connection from %s:%d\n",  
	    inet_ntoa(clt_sa.sin_addr),
	    ntohs(clt_sa.sin_port));
    
    //#define CONF_MultiClient
#ifdef CONF_MultiClient
    if((clt_pid=fork())<0) {
      cerr << "Fork failed: " << strerror(errno) << "\n";
      write(clt_fd,"503 Cannot create process\r\n",28);
      close(clt_fd);
      continue;
    }
    //Success
    if(clt_pid==0) {
      //Child
      close(sock);
      nnrpd(clt_fd);
      exit(0);
    }
    //Parent
    close(clt_fd);
#else
    nnrpd(clt_fd);
#endif
  }
  
  close(sock);
}

main(int argc, char **argv)
{
  char buf[256];
  time_t t;
  pid_t p;
  int ai=1;
  int use_inetd=0;

  strcpy(ServerRoot,CONF_ServerRoot);
  chdir(ServerRoot);

  time(&t);
  p=getpid();
  VERB(sprintf(buf,"Trace-%ld-%d",t,p);
       log.open(buf);
       log.p(Logger::Info) << "> " << ServerRoot << " \n");

  cmnd=argv[0];
  if(argc>3) {
    cerr << "Usage: " << cmnd << " [-i] [Config-File]\n";
    exit(1);
  }
  if(argc>1 && strcmp(argv[1],"-i")==0) {
    ai++;
    use_inetd=1;
  }
    
  if(argc<=ai) Cfg.read("etc/newscache.conf");
  else Cfg.read(argv[ai]);
 
  if(Cfg.ServerType==Config::inetd) use_inetd=1;

  if(!use_inetd) {
    VERB(Cfg.dump(cerr));
    nntpd();
  } else {
    nnrpd(-1);
  }
}
