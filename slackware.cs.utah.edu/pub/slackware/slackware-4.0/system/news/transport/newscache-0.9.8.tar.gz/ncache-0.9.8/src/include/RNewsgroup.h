#ifndef __RNewsgroup_h__
#define __RNewsgroup_h__

#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/file.h>
#include<unistd.h>
#include<utime.h>
#include<errno.h>
#include<time.h>
#include<fcntl.h>
#include<stdlib.h>
#include<limits.h>

#include<iostream.h>
#include<fstream.h>

#include"Configure.h"
#include"OverviewFmt.h"
#include"Newsgroup.h"

// DONT USE THIS CLASS!!!

class RNewsgroup: public Newsgroup {
  // Implementation stuff
  // Sure this implementation can be further improved by
  // the exploitation of templates. We provide already
  // ADT that operate on non-volatile memory. Why should
  // we reimplement an ADT that implements all this on
  // volatile memory.
  // A better solution would be something like
  // Hastable<Allocator> where the allocator specifies
  // where to place the data.
//   typedef struct {
//     String over;
//     Article *article;
//   } ngentry;

//   ngentry *_ArticleTable;
//   unsigned int first,last;
  
//   // News stuff
//   RServer *_RemoteServer;
//   virtual Article *retrievearticle(unsigned int nbr) {
//     return rs->getarticle(nbr);
//   }
public:
  RNewsgroup() : Newsgroup(NULL,NULL) {}
//   RNewsgroup(RServer *srvr,OverviewFmt *fmt, const char *name)
//     : Newsgroup(fmt,name) {
//     _RemoteServer=srvr;
//     first=1; last=0;
//   }

//   virtual void getsize(unsigned int *f, unsigned int *l) {
//     *f=first; *l=last;
//   }

//   virtual void setsize(unsigned int f, unsigned int l) {
//     char fn[MAXPATHLEN];
//     unsigned int i,n;
//     ngentry *ntab;

//     n=f-first;
//     for(i=0;i<n;i++) {
//       if(_ArticleTable[i].article) {
// 	delete _ArticleTable[i].article;
//       }
//     }
    
//     n=arrlst-arrfst+1;
//     for(i=l-arrfst+1;i<n;i++) {
//       if(_ArticleTable[i].article) {
// 	delete _ArticleTable[i].article;
//       }
//     }
//     if(f<l) {
//       ngentry *tmp;
      
//     } else {
//       ntab=_ArticleTable;
//       _articleTable=NULL;
//     }
//     delete ntab;
//   }

//   virtual unsigned int firstnbr() {}
//   virtual unsigned int lastnbr() {}
//   virtual int hasrecord(unsigned int i) {}
//   virtual void hasrecords(unsigned int *rlist) {}

//   virtual Article *getarticle(unsigned int nbr) {}
//   virtual void freearticle(Article *artp) {}
//   virtual void setarticle(Article *art) {}
//   virtual void printarticle(ostream &os,unsigned int nbr) {}

//   virtual const char *getover(unsigned int nbr) {}
//   virtual void setover(String over) {}
//   virtual void readoverdb(istream &is) {}
};
#endif
