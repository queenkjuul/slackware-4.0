#ifndef __sstream_h__
#define __sstream_h__

#include<fstream.h>
#include<Error.h>

class sstream: public fstream {
  char _name[256];
  char _service[256];
public:
  sstream() { 
    _name[0]='\0'; 
    _service[0]='\0'; 
  }
  sstream(char *name, char *service) { connect(name,service); }
  ~sstream() { disconnect(); }

  const char *hostname() { return _name; }
  const char *servicename() { return _service; }
  int is_connected() { return is_open(); }
  void connect(char *name, char *service);
  void disconnect();
};

#endif
