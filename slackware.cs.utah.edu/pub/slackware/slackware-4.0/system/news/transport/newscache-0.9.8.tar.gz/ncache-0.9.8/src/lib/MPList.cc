#include"MPList.h"

MPListEntry *MPList::server(const char *group) {
  int i,j;
  // bm=Best Match
  int bm=-1,bmlen=-1,clen;
  
  for(i=0;i<e_used;i++) {
    char c;
    
    j=0;
    do {
      clen=0;
      while(group[clen] && (c=entries[i].groups[j])==group[clen]) {
	clen++;
	j++;
      }
      
      switch(c) {
      case ',':
      case '\0':
	if(group[clen]!='\0') {
	  clen=-1;
	}
	break;
      case '*': 
	break;
      default: 
	clen=-1;
	break;
      }
      
      if(clen>bmlen) {
	bm=i; bmlen=clen;
      }
      
      while(c && c!=',') {
	j++;
	c=entries[i].groups[j];
      }
      j++;
    } while(c);
  }
  if(bm>=0 && entries[bm].hostname[0]!='\0') return entries+bm;
  return NULL;
} 

void MPList::read(ifstream &ifs) {
  char line[10240];
  char *argv[256];
  int i,argc;
  
  for(;;) {
    ifs.getline(line,sizeof(line),'\n');
    if(!ifs.good()) {
      if(ifs.fail() && !ifs.eof()) {
	DEBUG(cdbg << "MPList: line in config exceeds limit of 10240 chars\n");
      }
      DEBUG(cdbg << "MPList: unexpected eof in mplist-file?\n");
      break;
    }
    if(line[0]=='#') continue;
    
    for(i=0,argc=0 ; line[i] && argc<256 ; i++) {
      if(isspace(line[i])) line[i]='\0';
      //else line[i]=tolower(line[i]);
      if(line[i] && (i==0 || line[i-1]=='\0')) argv[argc++]=line+i;
    }
    if(argc==0) continue;
    
    if(strcmp(argv[0],"}")==0) break;
    if(argc==4 && strcmp(argv[0],"Server")==0) {
      addserver(argv[1],argv[2],argv[3]);
    } else if(argc==2 && strcmp(argv[0],"NoServer")==0) {
      addserver(NULL,NULL,argv[1]);
    } else {
      DEBUG(cdbg << "Syntax Error: " << argv[0] << '/' << argc << endl);
    }
  }
}
