#ifndef __CNewsgroup_h__
#define __CNewsgroup_h__

#include "NServer.h"
#include "NVNewsgroup.h"

class CNewsgroup: public NVNewsgroup {
protected:
  nvtime_t _mtime;
  nvtime_t _TTLGroup;
  RServer *_RServer;
  virtual Article *retrievearticle(unsigned int nbr);
  void updateoverview(void);
public:
  CNewsgroup(RServer *nsrvr, OverviewFmt *fmt, const char *spooldir, const char *name) : NVNewsgroup(fmt,spooldir,name) {
    _RServer=nsrvr;
    _mtime=0;
  }

  virtual void setttl(nvtime_t grp) {
    _TTLGroup=grp;
  }

  virtual String getover(unsigned int nbr) {
    updateoverview();
    NVNewsgroup::getover(nbr);
  }
  virtual void printover(ostream &os,unsigned int nbr) {
    updateoverview();
    NVNewsgroup::printover(os,nbr);
  }
  virtual void printoverdb(ostream &os, unsigned int f=0, unsigned int l=UINT_MAX) {
    updateoverview();
    NVNewsgroup::printoverdb(os,f,l);
  }
  virtual void printheaderdb(ostream &os, 
			     const char *header, 
			     unsigned int f=0, unsigned int l=UINT_MAX) {
    updateoverview();
    NVNewsgroup::printheaderdb(os,header,f,l);
  }
  virtual void printlistgroup(ostream &os) {
    updateoverview();
    NVNewsgroup::printlistgroup(os);
  }
};

#endif
