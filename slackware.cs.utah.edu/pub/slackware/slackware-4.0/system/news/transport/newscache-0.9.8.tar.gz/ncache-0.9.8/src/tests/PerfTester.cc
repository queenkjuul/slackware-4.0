#include <iostream.h>
#include <fstream.h>
#include <String.h>

#include "Debug.h"
#include "sstream.h"

int readtext(fstream &fs)
{
  String strg;
  do {
    readline(fs,strg,'\n',0);
    if(fs.bad()) {
      cerr << "Connection broken\n";
      return -1;
    }
  } while(strg!=".\r\n");
  cerr << "\r\n";
  return 0;
}

int do_list(fstream &fs, const char *cmd)
{
  String resp;
  fs << cmd << "\r\n";
  readline(fs,resp,'\n',0);
  cerr << resp;
  if(resp.before(3)!="215") return -1;
  return readtext(fs);
}

int do_over(fstream &fs, const char *cmd)
{
  String resp;
  fs << cmd << "\r\n";
  readline(fs,resp,'\n',0);
  cerr << resp;
  if(resp.before(3)!="224") return -1;
  return readtext(fs);
}

int do_group(fstream &fs, const char *cmd)
{
  String resp;
  fs << cmd << "\r\n";
  readline(fs,resp,'\n',0);
  cerr << resp;
  if(resp.before(3)!="211") return -1;
}

int do_article(fstream &fs, const char *cmd)
{
  String resp;
  fs << cmd << "\r\n";
  readline(fs,resp,'\n',0);
  cerr << resp;
  if(resp.before(3)!="220") return -1;
  return readtext(fs);
}

int do_quit(fstream &fs, const char *cmd)
{
  String resp;
  cerr << "rl\n";
  fs << cmd << "\r\n";
  cerr << "rl\n";
  readline(fs,resp,'\n',0);
  cerr << resp;
  if(resp.before(3)!="205") return -1;
  return 0;
}

main(int argc, char *argv[])
{
  if(argc!=3) {
    cerr << "Usage: " << argv[0] << " host port\n";
  }

  //  ifstream ifs("commands");
  sstream sfs(argv[1],argv[2]);
  String command;
  String comtok;

  cin.unsetf(ios::skipws);
  sfs.unsetf(ios::skipws);

  readline(sfs,command,'\n',0);
  cerr << command;

  for(;;) {
    int r;
    readline(cin,command,'\n',1);
    cerr << command << "\r\n";
    if(cin.eof()) break;
    if(cin.bad()) {
      cerr << "Cannot read from command-file\n";
      break;
    }
    comtok=command.before(RXwhite);
    if(comtok=="") comtok=command;
    if(strcmp(comtok,"list")==0) {
      r=do_list(sfs,command);
    } else if(strcmp(comtok,"xover")==0) {
      r=do_over(sfs,command);
    } else if(strcmp(comtok,"group")==0) {
      r=do_group(sfs,command);
    } else if(strcmp(comtok,"article")==0) {
      r=do_article(sfs,command);
    } else if(strcmp(comtok,"quit")==0) {
      r=do_quit(sfs,command);
    } else {
      cerr << command << " ignored\n";
    }
    if(sfs.bad()) {
      cerr << "Connection to news server closed or broken\n";
    }
    if(r<0) {
      cerr << "Bad return code\n";
    }
  }
}
