#ifndef _Logger_h_
#define _Logger_h_

#include<fstream.h>
#include<String.h>

#include<syslog.h>

class Logger {
  ofstream log;

  char _type;
  int _priority;
  
  char *buf;
  int buflen,bufsz;
  
  int bufresize(int sz);
  void append(const char *s);
  void print();
  
public:
  // Warning Levels:
  // Debug ...... Debugging Only
  // Info ....... Informations, eg to trace the program
  // Notice ..... More improtant notices
  // Warning .... Something strange
  // Error ...... Something unexpected
  // Critical ... Something did not succeed, critical
  // Alert ...... Action must be taken immediately
  // Emergency .. System is unusable
  enum { Emergency=LOG_EMERG, 
	 Alert=LOG_ALERT, 
	 Critical=LOG_CRIT, 
	 Error=LOG_ERR, 
	 Warning=LOG_WARNING, 
	 Notice=LOG_NOTICE, 
	 Info=LOG_INFO, 
	 Debug=LOG_DEBUG 
  };

  Logger(char *fn=NULL);
  ~Logger();

  void attach(int fd);
  void open(char *fn);
  void close();

  Logger &priority(int p);
  Logger &p(int p) { 
    return priority(p); 
  }
  Logger &type(char ch);
  Logger &t(char ch) { 
    return type(ch); 
  }

  Logger &write(const char *s);
  Logger &write(char ch) { 
    char buf[2]; 
    buf[0]=ch; buf[1]='\0'; 
    return write(buf); 
  }

  friend Logger &operator<<(Logger &l, const char *s);
  friend Logger &operator<<(Logger &l, String &s);
  friend Logger &operator<<(Logger &l, char ch);
  friend Logger &operator<<(Logger &l, unsigned int i);
  friend Logger &operator<<(Logger &l, int i);
};

#endif
