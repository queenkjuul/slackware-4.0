#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<unistd.h>

#include<iostream.h>

#include"Config.h"
#include"NServer.h"

const char *prop="-\\|/-\\|/";

Config Cfg;
RServer *myserv;

TRACE(ofstream ctrace("trace"));
DEBUG(ofstream cdbg("debug"));

main(int argc, char **argv)
{
TRACE(ctrace.setf(ios::unitbuf));
DEBUG(cdbg.setf(ios::unitbuf));
  char ifn[256];
  ifstream ifs;
  int i,qnbr;
  Article art;

  if(argc>2) {
    cerr << "Usage: " << argv[0] << " [Config-File]\n";
    exit(1);
  }
  if(argc==1) Cfg.read("etc/newscache.conf");
  else Cfg.read(argv[1]);

  if ((myserv=new RServer(Cfg.NewsServer,Cfg.NNTPPort))==NULL) {
    cerr << "Failed to create RServer\n";
    exit(1);
  }
  chdir(Cfg.SpoolDir);
  
  ifs.open(".outgoing/.qnbr");
  ifs >> qnbr;
  if(!ifs.good()) {
    cerr << "Nothing to post or cannot read .outgoing/.qnbr\n";
    exit(1);
  }
  ifs.close();

  for(i=0;i<qnbr;i++) {
    cout << "Article " << i << "\r";
    cout.flush();
    sprintf(ifn,".outgoing/a%d",i);
    ifs.open(ifn);
    ifs.unsetf(ios::skipws);
    if(!ifs.good()) {
      cerr << "Article " << i << " not found in outgoing spool\n";
      continue;
    }
    art.setnbr(i);
    art.read(ifs);
    ifs.close();
    if(unlink(ifn)<0) {
      cerr << "Cannot unlink " << ifn << ": " << strerror(errno) << endl;
    }
    // Add retry 
    // Possibly add some delay between two postings
    // Make this user-configureable
    sleep(3);
    myserv->post(art);
  }

  if(unlink(".outgoing/.qnbr")<0) {
    cerr << "Cannot unlink .outgoing/.qnbr: " << strerror(errno) << endl;
  }

  delete myserv;
}
