#ifndef _Article_h_
#define _Article_h_

#include <ctype.h>

#include "Text.h"

/* class Article
 */
struct Article {
  int _nbr;

  Text _text;
  Text _field;
  
public:
  Article() {}
  Article(int artnbr) { _nbr=artnbr; }
  Article(int artnbr, const char *text, int textlen=0) { 
    _nbr=artnbr; 
    _text.setdata(text,textlen);
  }
  ~Article() {}
  
  void clear() { _nbr=0; _text.clear(); }
  void read(istream &is) {
    TRACE(ctrace << "Article::read(&is)\n");
    _text.clear();
    _text.read(is);
  }
  int length() { return _text.length(); }
  void setnbr(int nbr) { _nbr=nbr; }
  int getnbr() { return _nbr; }
  const char *gettext() {
    return _text.data();
  }
  const char *getfield(const char *ifld, int Full=0) {
    char hdrbuf[513],*p;
    const char *q,*fld;
    unsigned int i;
    
    i=1; p=hdrbuf; q=ifld;
    while(i<sizeof(hdrbuf) && (*p=tolower(*q))) { i++; p++; q++; }
    *p='\0';

    q=_text.data();
    for(;;) {
      p=hdrbuf;
      fld=q;
      while(*p && *p==tolower(*q)) { p++; q++; }
      if(*p=='\0') {
	// We have found the header
	while(isspace(*q)) q++;
	if(!Full) fld=q;
	while(*q!='\r' && *q!='\n') q++;
	_field.clear();
	_field.append(fld,q-fld);
	while(*q=='\r' || *q=='\n') q++;
	// Multiline header?
	while(isspace(*q)) {
	  while(isspace(*q)) q++;
	  fld=q;
	  while(*q!='\r' && *q!='\n') q++;
	  _field.append(fld,q-fld);
	  while(*q=='\r' || *q=='\n') q++;
	}
	return _field.data();
      }
      // OK, bad luck find the next line
      while(*q!='\r' && *q!='\n') q++;
      
      // Skip first CRLF
      if(*q=='\r') q++;
      if(*q=='\n') q++;
      if(*q=='\r' || *q=='\n') {
	// OK, here the message body starts.
	// Bad luck, return NULL
	return NULL;
      }
    }
  }

  friend ostream& operator<<(ostream& os, Article &art) {
    os << art._text.data();
    return os;
  }
};

#endif
