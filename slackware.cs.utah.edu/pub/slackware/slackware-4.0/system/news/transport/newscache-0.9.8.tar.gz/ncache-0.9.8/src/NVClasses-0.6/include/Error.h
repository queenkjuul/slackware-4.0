#ifndef _Error_h_
#define _Error_h_

#include <String.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <Logger.h>
/* Error-classes 
 */

extern Logger log;

#define Error_h_ERRTEXTSIZE 4000
class Error {
public:
  char _errtext[Error_h_ERRTEXTSIZE];
  Error() { 
    strcpy(_errtext,"Unknown"); print(); 
  }
  Error(Error *r) { 
    strcpy(_errtext,r->_errtext); print(); 
  }
  Error(const char *txt) { 
    strncpy(_errtext,txt,Error_h_ERRTEXTSIZE); 
    _errtext[Error_h_ERRTEXTSIZE-1]='\0';
    print(); 
  }
  void print() {
    VERB(log.p(Logger::Critical) << "Exception!\n" 
	 << "  Desc: " << _errtext << "\n");
  }
};

class SystemError: public Error {
public:
  int _errno;
  SystemError(SystemError *r)
    : Error(r)
  {
    _errno=r->_errno; print();
  }
  SystemError(const char *txt, int errno=-1)
    : Error(txt)
  {
    _errno=errno; print();
  }
  void print() {
    if(errno!=-1) {
      VERB(log.p(Logger::Critical)
	   << "  Type: System\n" 
	   << "  ErrStr(" << _errno << "): "
	   << strerror(errno) << "\n");
    } else {
      VERB(log.p(Logger::Critical)
	   << "  Type: System\n" 
	   << "  ErrStr: ?\n");
    }
  }    
};

#endif
