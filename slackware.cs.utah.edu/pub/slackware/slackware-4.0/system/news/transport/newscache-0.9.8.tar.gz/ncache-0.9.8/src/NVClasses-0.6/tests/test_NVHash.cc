//#include "sbproto.h"
#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "NVHash.h"

#define HASHSZ 257

const char *h="Hello World!";

unsigned long hs(const char *strg)
{
  unsigned long h=1;
  const char *p=strg;
  while(*p) {
    h=(h*(*p))%HASHSZ;
    p++;
  }
  return h;
}

int main(int argc, char *argv[])
{
  char buf[256];
  char c;

  cout << argv[0] << "/" << argc << ":\n";

  NVHash nvh("/tmp/nvh",HASHSZ);
  do {
    cin >> c;
    switch(c) {
    case 'a':
    case 'A':
      int i,j;
      
      if(c=='A') cin >> j;
      else j=64;
      
      if(j>0) {
	nvh.add(hs(h),h,strlen(h)+1);
	for(i=1;i<j;i++) {
	  sprintf(buf,"This is the %dth piece of junk!",i);
	  nvh.add(hs(buf),buf,strlen(buf)+1);
	}
      }
      break;
    case 'c':
      nvh.clear();
      break;
    case 'p':
      nvh.print(cout);
      break;
    case 'q':
      break;
    case 'h':
    default:
      cout << "a ...... add some items\n" 
	   << "A #n ... add n items\n"
	   << "c ...... clear\n"
	   << "h ...... help\n"
	   << "p ...... print\n"
	   << "q ...... quit\n";
    }
    if(cout.bad()) {
      cout.clear();
    }
  } while(c!='q');
  nvh.close();
  return 0;
}
