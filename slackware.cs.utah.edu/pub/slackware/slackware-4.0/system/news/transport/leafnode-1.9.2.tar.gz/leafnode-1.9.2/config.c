const char * bindir = BINDIR ;
const char * spooldir = SPOOLDIR ;
const char * libdir = LIBDIR ;
const char * lockfile = LOCKFILE ;
const char * version = VERSION ;


