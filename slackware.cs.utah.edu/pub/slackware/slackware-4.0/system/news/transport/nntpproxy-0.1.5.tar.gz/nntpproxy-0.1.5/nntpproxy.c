#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <stdlib.h>
#include "config.h"

#ifdef hpux
#define setreuid(x,y) setresuid(x,y,-1)
#endif

static char line[LINESIZE];
static char connect_line[LINESIZE];
static int print_error=0;
static int no_errors=0;

static void alarm_sig(
	int sig_typ
) {
	fprintf(stderr,"Connection time out\n");
	exit(0);
}

inline int responce(char *line) {
	return (line&&isdigit(line[0])&&isdigit(line[1])&&isdigit(line[2]))
		?((line[0]*10+line[1])*10+line[2])-(('0'*10+'0')*10+'0'):-1;
}

static int OpenNNTP(
	struct sockaddr *serv_addr,
	int addr_len,
	char *user,
	char *pass
) {
	static int FirstTime=1;
	FILE *chatfd;
	char *lower;
	int on=1;
	int i, j, s;
	if(FirstTime) {
		signal(SIGPIPE,SIG_IGN);
		signal(SIGALRM,alarm_sig);
		FirstTime=0;
	}
	if((s=socket(AF_INET,SOCK_STREAM,0)) < 0) {
		perror("socket");
		return s;
	}
	setsockopt(s,SOL_SOCKET,SO_KEEPALIVE,&on,sizeof(on));
	setsockopt(s,SOL_SOCKET,SO_LINGER,&on,sizeof(on));
	if(!(chatfd=fdopen(s,"r+"))) {
		perror("fdopen");
		close(s);
		return -1;
	}
	alarm(TIMEOUT);
	if(connect(s,serv_addr,addr_len) < 0) {
		perror("connect");
		goto error;
	}
	alarm(TIMEOUT);
	do {
		if(! fgets(connect_line,sizeof(connect_line),chatfd)) {
			goto error;
		}
		i=responce(connect_line);
	} while ( i != 200 && i != 201 );
	switch(i) {
	case 200:
		if((!user || !user[0])&&(!pass || !pass[0])) {
			alarm(0);
			return s;
		}
		break;
	case 201:
		/* Changing 201 to 200 is neccissary to inform news readers
		 * it is OK to post...
		 */
		connect_line[2]='0';
		/* The following is unneccissary, but changing the string 
		 * 'no post' to 'ok post' may avoid unneccissary confusion.
		 */
		if((lower=strdup(connect_line))) {
			int ii,k=strlen(lower);
			for(ii=3;ii<9;ii++) {
				if(isupper(lower[ii])) 
					lower[ii] += 'a'-'A';
			}
			for(ii=9;ii<k;ii++) {
				if(isupper(lower[ii])) 
					lower[ii] += 'a'-'A';
				if(!strncmp(&lower[ii-6],"no post",7)) {
					connect_line[ii-6]+='o'-'n';
					connect_line[ii-5]+='k'-'o';
					ii += 6;
				}
			}
			free(lower);
		}
	}
	if(user && user[0]) { 
		fprintf(chatfd,"authinfo user %s\n",user);
		fflush(chatfd);
		do {
			if(! fgets(line,sizeof(line),chatfd)) {
				j=502;
			}else {
				j=responce(line);
			}
		} while (j != 381 && j != 281 && j != 201 && j != 502);
	}else {
		j=381;
	}
	if(j == 381 && pass && pass[0]) {
		fprintf(chatfd,"authinfo pass %s\n",pass);
		fflush(chatfd);
		do {
			if(! fgets(line,sizeof(line),chatfd)) {
				j=502;
			}else {
				j=responce(line);
			}
		} while(j != 201 && j != 281 && j != 502);
	}
	if(j == 201 || j == 281) {
		alarm(0);
		return s;
	}
error:
	alarm(0);
	fclose(chatfd);
	return -1;
}

static struct ConfigFile OpenConfig(
	uid_t uid
) {
	static struct ConfigFile nntp;
	static int first=1;
	int i, s;
	static char *basedirs[]={NULL,BASEDIRS,NULL};
	char **base=basedirs;
	struct passwd *passe;

	if(! (passe=getpwuid(uid))) {
		base++;
	}else {
		base[0]=passe->pw_dir;
	}
	if(first) {
		nntp.name=NULL;
		first=0;
		for(s=i=0;base[i];i++) {
			int j;
			if((j=strlen(base[i]))>s) {
				s = j;
			}
		}
		s += ((sizeof(NNTPFILE)>sizeof(POPFILE))
			?sizeof(NNTPFILE)
			:sizeof(POPFILE))+sizeof(EXT)+3;
		if(! (nntp.name=(char *)malloc(s))
		) {
			perror("malloc");
			fprintf(stderr,"Tried to allocate %d bytes\n",s);
			exit(1);
		}
	}
	for(nntp.IsPopFile=0;nntp.IsPopFile < 2;nntp.IsPopFile++) {
		for(i=0;base[i];i++) {
			if(sprintf(nntp.name,"%s/%s%s",base[i],
				(nntp.IsPopFile?POPFILE:NNTPFILE),EXT) < 0) {
				perror("sprintf");
				exit(1);
			}
			if(!(nntp.file=fopen(nntp.name,"r"))) {
				if(sprintf(nntp.name,"%s/.%s",base[i],
					(nntp.IsPopFile?POPFILE:NNTPFILE)) < 0) {
					perror("sprintf");
					exit(1);
				}
				nntp.file=fopen(nntp.name,"r");
			}
			if(nntp.file) {
				struct stat FileStatus;
				if(fstat(fileno(nntp.file),&FileStatus) < 0) {
					if(no_errors)
						perror("fstat");
				}else if(FileStatus.st_mode&(S_IRWXG|S_IRWXO)) {
					if(no_errors) {
						fprintf(stderr,
							"Illegal permissions on %s\n",
							nntp.name);
					}
					fclose(nntp.file);
					nntp.file=NULL;
				}else {
					return nntp;
				}
			}
		}
	}
	fclose(nntp.file);
	nntp.file=NULL;
	return nntp;
}

/* The format of the config file is simply:
 *
 *    hostname service username password
 *
 * A # character indicate the rest of the line is comments.
 */
static int ReadConfig(
	struct ConfigFile nntp,
	char *host,
	char *serv,
	char *user,
	char *pass
) {
	int j;

	if(!nntp.file)
		return -1;

	/* Find a non-comment line and scan it.
	 */
	do {
		host[0]=serv[0]=user[0]=pass[0]=0;
		if(fgets(line,sizeof(line),nntp.file)) {
			char *c=strchr(line,'#');
			if(c) *c='\0';
			j=strlen(line)
				?sscanf(line,"%s %s %s %s",host,serv,user,pass)
				:0;
		}else {
			return -1;
		}
	}while(!j);

	/* Check if we read enough arguments.
	 */
	if(j < 1) {
		if(no_errors) {
			fprintf(stderr,
				"%s is not formated 'host [service] [user pass]'\n",
				nntp.name);
		}
		return -1;
	}else if(j < 2 || nntp.IsPopFile) {
		strcpy(serv,SERVICE);
	}else if(j < 4  && (!isdigit(serv[0]) || atoi(serv) <= 0)) {
		strcpy(pass,user);
		strcpy(user,serv);
		strcpy(serv,SERVICE);
	}
	return 0;
}

/* This routine looks up the port and returns it in network order.
 */

static int GetPort(
	char *service
) {
	struct servent *serv;
	if((serv=getservbyname(service,PROTO))) {
		return serv->s_port;
	}
	else if((serv=getservbyport(atoi(service),PROTO))) {
		return serv->s_port;
	}
	return htons(atoi(service));
}

/* This routine tries modifications of the hostname provided.  This is
 * sometimes neccissary if the hostname was read from a .pop file...
 * First we try prefixing 'news.' and 'nntp.'.  Then we try that with
 * the base host name.
 */
static char *NextHost(
	char *host
) {
	static int attempt=0;
	static char *OriginalHost=NULL;
	static char *dot=NULL;

	print_error=0;
	switch(++attempt) {
	case 1:
		OriginalHost=strdup(host);
		sprintf(host,"news.%s",OriginalHost);
		return host;
	case 2:
		sprintf(host,"nntp.%s",OriginalHost);
		return host;
	case 3:
		strcpy(host,OriginalHost);
		print_error=no_errors;
		return host;
	case 4:
		if(!(dot=strchr(OriginalHost,'.'))) {
			attempt=0;
			strcpy(host,OriginalHost);
			free(OriginalHost);
			OriginalHost=NULL;
			return NULL;
		}
		sprintf(host,"news.%s",++dot);
		return host;
	case 5:
		sprintf(host,"nntp.%s",dot);
		return host;
	case 6:
		strcpy(host,dot);
		return host;
	default:
		strcpy(host,OriginalHost);
		free(OriginalHost);
		OriginalHost=NULL;
		attempt=0;
		return NULL;
	}
}
	
static int DoLoop(
	int s,
	struct sockaddr *serv_addr,
	int addr_len,
	char *user,
	char *pass
) {
	struct timeval timeout;
	close(1);close(2);
	if(s>=0) close(0);
	dup(open("/dev/null",O_RDWR,0777));
	if(s>=0) dup(1);
	fflush(stdin);fflush(stdout);fflush(stderr);
	for(;;) {
		int r,t=(-1);
		struct sockaddr_in loc_sockaddr_in;
		int loc_addr_len=sizeof(struct sockaddr_in);

		if(s<0) {
			r=0;
		}
		else if((r=accept(s,(struct sockaddr *)&loc_sockaddr_in,&loc_addr_len)) < 0) {
			exit(1);
		}else {
			int on=1;
			setsockopt(r,SOL_SOCKET,SO_KEEPALIVE,&on,sizeof(on));
			setsockopt(r,SOL_SOCKET,SO_LINGER,&on,sizeof(on));
		}
		if(s < 0 || ! fork()) {
			int off=2;
			if(s>=0) {
				if((t=OpenNNTP(serv_addr,addr_len,user,pass))<0) {
					exit(1);
				}
				if(!t) t=dup(t);
				dup2(r,0);
				if(r>1) close(r);
				dup2(t,1);
				if(t>1) close(t);
			}
			write(0,connect_line,strlen(connect_line));
			for(;;) {
				fd_set rin, win, ein;
				FD_ZERO(&rin);
				FD_ZERO(&win);
				FD_ZERO(&ein);
				if(off!=0) {
					FD_SET(0,&rin);
					FD_SET(0,&ein);
				}
				if(off!=1) {
					FD_SET(1,&rin);
					FD_SET(1,&ein);
				}
				timeout.tv_sec=0;
				timeout.tv_usec=20;
				select(0,NULL,NULL,NULL,&timeout);
				select(2,&rin,&win,&ein,NULL);
				if(FD_ISSET(1,&rin)||FD_ISSET(1,&ein)) {
					int a;
					if((a=read(1,line,sizeof(line)))<=0) {
						if(off == 2 && !a) {
							off=1;
							shutdown(1,0);
							shutdown(0,1);
						}else {
							exit(0);
						}
					}else if(write(0,line,a) < 0) {
						if(off == 2 && errno == EPIPE) {
							off=0;
							shutdown(0,0);
							shutdown(1,1);
						}else {
							exit(0);
						}
					}
				}
				if(FD_ISSET(0,&rin)||FD_ISSET(0,&ein)) {
					int a;
					if((a=read(0,line,sizeof(line)))<=0) {
						if(off == 2 && !a) {
							off=0;
							shutdown(0,0);
							shutdown(1,1);
						}else {
							exit(0);
						}
					}else if(write(1,line,a)<0) {
						if(off == 2 && errno == EPIPE) {
							off=1;
							shutdown(0,1);
							shutdown(1,0);
						}else {
							exit(0);
						}
					}
				}
				
			}
		}
		close(r);
		close(t);
	}
}

int main(
	int argc,
	char **argv,
	char **env
) {
	int s;
	struct hostent *remote;
	struct sockaddr_in BindAddr,ConnectAddr;
	int AddrSize = sizeof(BindAddr);
	char host[LINESIZE], serv[10], user[256],pass[14];
	uid_t uid=getuid(), euid=geteuid();
	struct ConfigFile nntp;

/* I assume if device 0 is a socket, then this is a inetd daemon.
 */
	if(!getsockname(0,(struct sockaddr *)&BindAddr,&AddrSize)
		&& AddrSize
	) {
		setsockopt(0,SOL_SOCKET,SO_KEEPALIVE,&no_errors,sizeof(no_errors));
		setsockopt(0,SOL_SOCKET,SO_LINGER,&no_errors,sizeof(no_errors));
		dup2(0,1);
		dup2(0,2);
		no_errors=1;
	}else {
		AddrSize=0;
	}
/* We first try opening a config file as the real user...
 */
	if(uid != euid) {
		nntp=OpenConfig(uid);
		setreuid(euid,-1);
	}else {
		nntp.file=NULL;
	}
/* If that fails, try opening as root (euid).
 */
	if(!nntp.file && !(nntp=OpenConfig(uid)).file < 0) {
		fprintf(stderr,"Can't find a configuration file.\n");
		exit(1);
	}
/* Now we will loop over all the lines in the config file until we find one
 * that works.
 */
	for(s = -1; s < 0 && !ReadConfig(nntp,host,serv,user,pass); ) {
		/* Setup the address port...  Purhaps some of this could
		 * be done outside this loop.  But hopefully there won't be
		 * too many configuration lines.
		 */
		memset(&ConnectAddr,0,sizeof(struct sockaddr_in));
		ConnectAddr.sin_addr.s_addr = INADDR_ANY;
		ConnectAddr.sin_family = AF_INET;
		ConnectAddr.sin_port = GetPort(serv);
		if(! AddrSize) {
			memset(&BindAddr,0,sizeof(struct sockaddr_in));
#ifdef SECURE_BIND
			BindAddr.sin_addr.s_addr = inet_addr(SECURE_BIND);
#else
				BindAddr.sin_addr.s_addr = INADDR_ANY;
#endif
			BindAddr.sin_family = AF_INET;
			if( !strcmp(serv,SERVICE) && (s=GetPort(SERVICE))) {
				BindAddr.sin_port = s;
			}else {
				BindAddr.sin_port = ConnectAddr.sin_port;
			}
		}else if(!ConnectAddr.sin_port) {
			if( !strcmp(serv,SERVICE) && (s=GetPort(SERVICE))) {
				ConnectAddr.sin_port = s;
			}else {
				ConnectAddr.sin_port = BindAddr.sin_port;
			}
		}
		/* Now we'll try all reasonable variations of the host name
		 * from the configuration file, as specified in the NextHost
		 * routine.
		 */
		for(s= -1; s < 0 && NextHost(host);) {
			char **addr_list=NULL;
			do {
				if(!addr_list) {
					if(!(remote=gethostbyname(host))) {
						if (isdigit(*host)) {
							ConnectAddr.sin_addr.s_addr = inet_addr(host);
						}else {
							if(print_error) {
								fprintf(stderr,"Host: %s ; ",host);
								herror("Can't lookup host\n");
							}
							continue;
						}
					}else if(
						remote->h_addrtype!=AF_INET
						||!remote->h_addr_list
						||(remote->h_length<sizeof(unsigned long))
					) {
						if(print_error) 
							fprintf(stderr,"Unrecognized address format for %s\n",host);
						continue;
					}else {
						addr_list=remote->h_addr_list;
						ConnectAddr.sin_addr.s_addr=*((unsigned long *)*addr_list);
					}
				}else {
					ConnectAddr.sin_addr.s_addr=*((unsigned long *)*addr_list);
				}
				/* Try connecting.  If we can connect, use this address.
				 */
				if((s=OpenNNTP((struct sockaddr *)&ConnectAddr,sizeof(struct sockaddr_in),user,pass)) < 0) {
					if((!user[0] && !pass[0]) || (s=OpenNNTP((struct sockaddr *)&ConnectAddr,sizeof(struct sockaddr_in),NULL,NULL)) < 0) {
						if(print_error)
							fprintf(stderr,
								"Test connection to %s:%s failed\n",
								host,serv);
						continue;
					}
					user[0]=0;
					pass[0]=0;
				}
			}while ( s < 0 && addr_list++ && *addr_list );
		}
	}
	if(nntp.file)
		fclose(nntp.file);
	if(s < 0) {
		fprintf(stderr,"Test connection to %s failed\n",host);
		exit(1);
	}
	if(! AddrSize) {
		close(s);
		if( (s=socket(AF_INET,SOCK_STREAM,0))<0) {
			perror("socket");
			exit(1);
		}
#ifdef SECURE_BIND
		if( bind(s,(struct sockaddr *)&BindAddr,sizeof(struct sockaddr_in)) < 0 ) {
			if(BindAddr.sin_addr.s_addr != INADDR_ANY) {
				BindAddr.sin_addr.s_addr = INADDR_ANY;
#endif
				if( bind(s,(struct sockaddr *)&BindAddr,sizeof(struct sockaddr_in)) < 0 ) {
					perror("bind");
					exit(1);
				}
#ifdef SECURE_BIND
			}
		}
#endif
		if(listen(s,10) < 0) {
			perror("listen");
			exit(1);
		}
		printf("Forking as a daemon\n");
	}else if(s!=1) {
		dup2(s,1);
		close(s);
	}
	if(uid != euid)
		setreuid(uid,uid);
	signal(SIGCHLD,SIG_IGN);
	switch(AddrSize?0:fork()) {
		case -1:
			perror("fork");
			exit(1);
		case 0:
			setsid();
			DoLoop(
				AddrSize?(-1):s,
				(struct sockaddr *)&ConnectAddr,
				sizeof(struct sockaddr_in),
				user,
				pass
			);
			exit(1); /* This should never return. */
	}
	exit(0);
}

