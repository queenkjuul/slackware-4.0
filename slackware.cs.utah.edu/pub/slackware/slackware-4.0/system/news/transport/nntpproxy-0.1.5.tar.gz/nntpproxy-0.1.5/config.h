#define NNTPFILE "nntp"
#define POPFILE  "pop"
#define SERVICE  "nntp"
#define EXT      ".login"
#define PROTO    "tcp"

/* How long do we wait for connects?
 */
#define TIMEOUT  120

/* These are the directories which will be searched for a configuration file.
 */
#define BASEDIRS "/var/local/etc","/var/etc","/usr/local/etc","/usr/etc","/etc"

/* This is the maximum line size, and buffer size for reads.
 */
#define LINESIZE 1024

/* Use SECURE BIND if you want to be sure only local host connected are allowed.
 * If this is undefined, all hosts will be allowed to connect to your nntp
 * port...
 */
#define SECURE_BIND "127.0.0.1"

struct ConfigFile {
	FILE * file;
	char * name;
	int IsPopFile;
};

