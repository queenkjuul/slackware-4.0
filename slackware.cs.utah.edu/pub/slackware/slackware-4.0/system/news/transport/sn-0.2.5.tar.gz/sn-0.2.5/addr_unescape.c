/*
 * This file (addr_unescape.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */

int
addr_unescape(char * from, char * to, int len)
{
  char * dst;
  int bs, dq;

  bs = dq = 0;
  dst = to;
  for( ; len > 0; from++, len--){
    if( ! bs )
      switch( *from ){
      case '"': dq = (! dq); continue;
      case '\\': bs = 1; continue;
      default: ;
      }
    else
      bs = 0;
    if( dst != from )*dst = *from;
    dst++;
  }
  *dst = '\0';
  return(dst - to);
}
