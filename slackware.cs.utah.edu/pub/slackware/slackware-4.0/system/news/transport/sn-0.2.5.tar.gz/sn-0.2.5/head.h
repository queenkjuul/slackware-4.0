struct readln;
struct b;
extern int read_unfold_head(struct b *head,
                            struct readln *rp,
                            int (*sw)(char *),
                            char *endline);
