#ifndef WILDMAT_H
#define WILDMAT_H
/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
/*
 * Case-insensitive globbing.  Returns 1 if pattern matches the
 * candidate string entirely, else 0.  Supported glob features are *,
 * ? [] including - as a range.  Leading . is not special.  Newlines
 * are not special.  Please don't send bad glob patterns!
 */
extern int wildmat(char *candidate, char *pattern);
#endif
