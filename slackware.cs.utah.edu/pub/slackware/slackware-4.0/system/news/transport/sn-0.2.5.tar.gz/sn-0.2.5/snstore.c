/*
 * This file (snstore.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Store articles.  Option to check if article already exists.
 *
 * 2 input formats: native; and batch.  In native format,
 * each line read must be terminated by "\r\n"
 * and each article read is terminated by a lone
 * '.' on a line.  Each article is stored under those groups
 * mentioned in the Newsgroups: line.
 * The file ".times" is appended to with the serial number and time
 * in each group.  The file is created if it does not exist.
 *
 * Each time an article is stored, the articles id etc. are entered
 * in the database too.
 *
 * snstore will create a message-ID if none exists.  It will
 * delete any "Bytes:", "Lines:", or "Xref:" fields and recreate
 * them.  It will append the local hosts name to the Path: line.
 * It requires a "Newsgroups:" field to figure out where to store
 * the article; The first newsgroup mentioned becomes the home of
 * the article.  Subsequent newsgroups get an alias to the home.
 *
 * The "Xref:" line is not stored.  It is created on-the-fly
 * by the programs that will display it.
 *
 * If '-1' is option, expects only one article to a private group.  If
 * that single article could not be stored, exits 9.
 */

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <signal.h>
#include "config.h"
#include "store.h"
#include "art.h"
#include "group.h"
#include "times.h"
#include "art.h"
#include "subscribed.h"
#include "dhash.h"
#include "hostname.h"
#include "parameters.h"
#include "head.h"
#include <b.h>
#include <out.h>
#include <readln.h>
#include <format.h>
#include <tokensep.h>
#include <opt.h>
#include <statf.h>

int debug = 0;

static const char rcsid[] = "$Id: snstore.c,v 1.39 1999/03/27 05:27:24 harold Exp $";

static char * me = NULL;
static int melen;
static char * newsgroups = NULL;
static char * messageid = NULL;
static char * pathline = NULL;
static struct b references = {0,};
static struct readln input;

/* we want this so sto_*() will reorder the file */
static void memerr(void) { sto_fin(); fail(2, "No memory"); }
static void append(struct b * bp, char * buf, int len)
{ if( -1 == b_appendl(bp, buf, len) )memerr(); }
#define appends(bp,lit) append(bp, lit, sizeof(lit))

static int
switchline(char * line)
{
  char * p;
  int len;

  switch( *line ){
  case 'x': case 'X':
    if( 0 == strncasecmp(line, "Xref:", 5) )return(1);
    break;
  case 'b': case 'B':
    if( 0 == strncasecmp(line, "Bytes:", 6) )return(1);
    break;
  case 'l': case 'L':
    if( 0 == strncasecmp(line, "Lines:", 6) )return(1);
    break;
  case 'm': case 'M':
    if( ! messageid && 0 == strncasecmp(line, "Message-Id:", 11) ){
      if( ! (line = strchr(line + 11, '<')) )break;
      if( ! (p = strchr(++line, '>')) )break;
      if( ! (messageid = malloc(1 + p - line)) )memerr();
      memcpy(messageid, line, p - line);
      messageid[p-line] = '\0';
    }
    break;
  case 'n': case 'N':
    if( ! newsgroups && 0 == strncasecmp(line, "Newsgroups:", 11) ){
      if( ! (newsgroups = malloc(strlen(line) - 10)) )memerr();
      strcpy(newsgroups, line + 11);
    }
    break;
  case 'p': case 'P':
    if( 0 == strncasecmp(line, "Path:", 5) ){
      if( ! pathline ){
        for(line += 5; ' ' == *line; line++);
        len = strlen(line) + 4 + melen + sizeof("Path: ");
        for( ; 0 == strncmp(line, me, melen); line += melen + 1)
          if( ! line[melen] )return(1);
          else if( '!' == line[melen] )break;
        if( ! (pathline = malloc(len)) )memerr();
        len = formats(pathline, len-1, "Path: %s!%s", me, line);
        if( len > 1000 ){
          for(p = pathline + 950; p > pathline && '!' != *p; p--);
          strcpy(p, "!path.too.long.truncated\r\n");
        }
      }
      return(1);
    }
    break;
  case 'r': case 'R':
    if( references.used )return(1);  /* gave at the office */
    if( 0 == strncasecmp(line, "References:", 11) ){
      if( (len = strlen(line)) < 600 )return(0); /* accept */
      line += 11;
      while( (p = tokensep(&line, " ,\r\n")) && references.used < 600 ){
        append(&references, p, strlen(p));
        append(&references, ",", 1);
      }
      return(1);
    }
  }
  return(0);
}

/*
  One way to read an input article
 */
int body_lines;

static int
readrnews(struct b * head, struct b * body)
{
  int len;
  char * line;
  int bytes;

  len = readln(&input, &line, '\n');
  if( 0 == len )return(1);
  line[--len] = '\0';
  if( '\r' == line[len-1] )line[--len] = '\0';
  if( '#' != *line++ || '!' != *line++ )
    fail(3, "readrnews:input format error");
  while( ' ' == *line )line++;
  if( strncmp(line, "rnews ", 6) )
    fail(3, "readrnews:bad #!rnews line");
  line += 6;
  bytes = atoi(line);
  if( bytes < 0 )fail(3, "readrnews:bad article size \"%s\"", line);

  len = read_unfold_head(head, &input, switchline, "\r\n");
  switch( len ){
  case 1: case 2: case -2: fail(3, "readrnews:input format error");
  case -1: fail(2, "readrnews:read error:%m");
  case 0: return(0);
  default: bytes -= len;
  }

  while( bytes > 0 )
    if( (len = readln(&input, &line, '\n')) > 0 ){
      bytes -= len;
      line[--len] = '\0';
      if( len )if( '\r' == line[len-1] )line[--len] = '\0';
      if( '.' == *line )append(body, ".", 1);
      append(body, line, len);
      append(body, "\r\n", 2);
      body_lines++;
    }else if( 0 == len )
      return(-1);
    else if( -1 == len )
      fail(2, "readrnews:read error:%m");

  if( bytes < 0 )fail(3, "readrnews:input overshot size");
  return(0);
}

/*
  Another way to read an input article
 */

static int
readarticle(struct b * head, struct b * body)
{
  int len;
  char * line;

  len = read_unfold_head(head, &input, switchline, "\r\n");
  switch( len ){
  case 1: case 2: case -2: return(-1);
  case -1: fail(2, "Read error:%m");
  case 0: return(1);
  }

  if( -1 == (len = readln(&input, &line, '\n')) )
    fail(2, "readarticle:read error:%m");
  if( 0 == len )return(1);

  do{
    line[--len] = '\0';
    if( '\r' == line[len-1] )line[--len] = '\0';
    if( 1 == len && '.' == *line )return(0);
    append(body, line, len);
    append(body, "\r\n", 2);
    body_lines++;
  }while( (len = readln(&input, &line, '\n')) > 0 );

  if( -1 == len )fail(2, "readarticle:read error:%m");
  fail(3, "readarticle:short article");
  /* Not Reached */
  return(-1);
}

static void handler(int signum) {
  sto_fin(); fail(3, "exiting on signal %d", signum); }

char ** allgroups = NULL;
int nrgroups = 0;

static void usage(void) { fail(1, "Usage:%s [-nrc]", progname); }

static int
islocal(char * group)
{
  struct stat st;

  if( -1 == statf(&st, "%s/.outgoing", group) )
    return((ENOENT==errno)?1:0);
  if( S_ISREG(st.st_mode) )return(1);
  return(0);
}

/*
  Will destroy char * newsgroups.
 */
static char **
parsenewsgroups(char * buf)
{
  static char ** grouplist = 0;
  static int size = 0;
  int n;
  char * cp;

  for(n = 0; (cp = tokensep(&buf, " ,\t\r\n")); ){
    if( n >= size ){
      char ** tmp;
      int newsize;
      newsize = (size?(size*2):10);
      tmp = malloc(newsize * sizeof(char *));
      if( ! tmp )return(0);
      if( grouplist ){
        memcpy(tmp, grouplist, size * sizeof(char *));
        free(grouplist);
      }
      grouplist = tmp;
      size = newsize;
    }
    for(grouplist[n] = cp; *cp; cp++)
      if( '/' == *cp || ('.' == *cp && '.' == cp[1]) )break;
      else if( *cp <= 'Z' && *cp >= 'A' )*cp += 'a' - 'A';
    if( ! *cp && cp - grouplist[n] < GROUPNAMELEN )n++;
  }
  grouplist[n] = 0;
  return(grouplist);
}

static int
store_forreal(char * group, struct article * ap)
{
  struct data d;
  if( (d.serial = sto_add(group, ap)) > 0 ){
    LOG3("stored \"<%s>\" under %s:%d", messageid, group, d.serial);
    if( ap->body ){
      /* not an alias */
      d.newsgroup = group;
      d.messageid = messageid;
      if( -1 == dh_insert(&d) ){
        if( EEXIST == errno ){
          LOG1("Oops, \"<%s>\" already exists", messageid);
        }else
          log("Couldn't insert \"<%s>\" into database:%m?", messageid);
      }else
        LOG3("ID \"<%s>\" inserted", messageid);
    }
    (void)times_append(group, d.serial);
  }else
    log("store_forreal:couldn't store \"<%s>\" in %s:%m?", messageid, group);
  return(d.serial);
}

static int
store_pretendto(char * notused1, struct article * ap)
{
  writef(2, "%s\r\n%s.\r\n", ap->head, ap->body?ap->body:"");
  return(1);
}

static void
cleanup(void)
{
  if( messageid ){ free(messageid); messageid = 0; }
  if( newsgroups ){ free(newsgroups); newsgroups = 0; }
  if( pathline ){ free(pathline); pathline = 0; }
}

int
main(int argc, char ** argv)
{
  struct stat st;
  struct b head = {0,};
  struct b body = {0,};
  char * cp;
  enum{ NO, YES, DONE, NOTDONE }single;
  int checkexist = 0;
  int i;
  int (*reader)(struct b *, struct b *);
  int (*storer)(char *, struct article *);

  progname = ((cp = strrchr(argv[0], '/'))?cp + 1:argv[0]);

  parameters(1);
  reader = readarticle;
  storer = store_forreal;

  single = NO;
  while( (i = opt_get(argc, argv, "")) > -1 )
    switch( i ){
    case 'd': debug++; break;
    case 'n': storer = store_pretendto; break;
    case 'c': checkexist = 1; break;
    case 'V': version(); exit(0);
    case '1': single = YES; break;
    case 'r': reader = readrnews; break;
    case 'P': log_with_pid(); break;
    default: usage();
    }
  if( opt_ind != argc )usage();

  if( -1 == chdir(snroot) )FAIL(2, "chdir(%s):%m", snroot);

  if( 0 == stat(".nopost", &st) )
    FAIL(1, "Can't store articles, %s/.nopost exists", snroot);
  if( -1 == readln_ready(0, 0, &input) )
    FAIL(2, "readln_ready:%m");

  do{
    if( sto_init() > -1 ){
      if( dh_open(0, 0) > -1 ){
        if( times_init() > -1 )break;
      }dh_close();
    }sto_fin();
    exit(2);
  }while( 0 );

  signal(SIGPIPE, handler);
  /* Keyboard signals should cause clean exit. */
  signal(SIGINT, handler);
  signal(SIGQUIT, handler);

  me = myname();
  melen = strlen(me);

  allgroups = group_all(&nrgroups);
  if( NULL == allgroups || 0 == nrgroups )
    FAIL(1, "We have no newsgroups");

  if( YES == single )
    for(i = 0; i < nrgroups; i++)
      if( 0 == statf(&st, "%s/.nopost", allgroups[i]) ){
        free(allgroups[i]);
        allgroups[i] = NULL;
      }

  if( -1 == subscribed_init(allgroups, nrgroups) )fail(2, "No memory");


  for( ; ; cleanup()){

    char ** groups;
    struct article a;
    struct data d;
#define NOTATTEMPTED -2
#define FAILED -1
    int serial;
    int len;

    if( head.size < 2000 ){
      if( head.buf )free(head.buf);
      if( ! (head.buf = malloc(head.size = 2000)) )memerr();
    }
    head.used = 1000; /* space for Path: */

    body_lines = references.used = body.used = 0;

    i = (*reader)(&head, &body);
    if( -1 == i )fail(3, "Bad article format");
    if( 1 == i )break;
    if( 1000 == head.used ){ log("Empty article"); continue; }

    /*
      Checking
     */

    if( ! newsgroups ){
      LOG("Article \"%s\" not addressed to any group",
        messageid?messageid:"<?>");
      goto skip_article;
    }

    if( ! (groups = parsenewsgroups(newsgroups)) )memerr();
    if( ! groups[0] ){
      log("No valid newsgroups found in \"%s\"", messageid);
      goto skip_article;
    }

    if( ! messageid ){
      static int pid = 0;
      struct timeval tv;
      if( ! (messageid = malloc(len = strlen(me) + 40)) )memerr();
      gettimeofday(&tv, 0);
      len = formats(messageid, len-1, "%u.%u.%u@%s",
        tv.tv_sec, tv.tv_usec, pid?pid:(pid=getpid()), me);
      append(&head, "Message-ID: <", 13);
      append(&head, messageid, len);
      append(&head, ">\r\n", 3);
      log("created message ID for article");
    }else if( checkexist ){
      LOG3("checking \"%s\"", messageid);
      d.messageid = messageid;
      if( messageid && 0 == dh_find(&d) ){
        LOG1("article \"<%s>\" is already in the spool", messageid);
        goto skip_article;
      }
    }

    /*
      Complete the header.
     */

    {
      char tmp[80];
      append(&head, tmp,
        formats(tmp, sizeof(tmp)-1, "Lines: %u\r\nBytes: %u\r\n",
          body_lines, body.used));
    }

    if( ! pathline ){
      static int plen = 0;
      if( ! plen )plen = sizeof("Path: \r\n") + strlen(me) + 1;
      if( ! (pathline = malloc(plen)) )memerr();
      len = formats(pathline, plen-1, "Path: %s\r\n", me);
    }else
      len = strlen(pathline);

    a.head = head.buf + 1000 - len;
    a.hlen = head.used - 1000 + len;
    memcpy(a.head, pathline, len);
    a.body = body.buf; a.blen = body.used;

    if( references.used ){
      append(&head, "References: ", 12);
      append(&head, references.buf, references.used);
    }


    /*
      Actually store it
     */

    serial = NOTATTEMPTED;

    for( ; *groups; groups++)
      if( subscribed(*groups) )
        if( NO == single || islocal(*groups) )
          if( (serial = (*storer)(*groups, &a)) > -1 ){
            if( a.body ){
              a.body = 0; a.blen = 0;
              a.hlen = formats(a.head, a.hlen-1,"Message-ID: %s:%d<%s>\r\n",
                *groups, serial, messageid);
            }
            if( NO != single )single = DONE;
          }else{
            if( NO != single )single = NOTDONE;
            if( 0 == serial )break;  /* we just inserted a duplicate */
          }

    if( FAILED == serial || NOTATTEMPTED == serial ){
      log((FAILED==serial)?"Had to ditch article \"%s\"":
        "Article \"%s\" not for any of our newsgroups", messageid);
skip_article:
      if( debug >= 1 ){
        log("Article not stored:>>>>>");
        writef(2, "%s\r\n%s", a.head, body.buf?body.buf:"");
        log("<<<<<");
      }
    }

    if( single != NO )break;
  }

  times_fin();
  sto_fin();
  subscribed_fin();
  if( checkexist )dh_close();
  if( NO == single || DONE == single )exit(0);
  exit(9);
}
