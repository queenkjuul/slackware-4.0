#ifndef TOKENSEP_H
#define TOKENSEP_H
/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
/*
 * Like strtok(3), but reentrant.  Returns the next token, as
 * delimited by any of the characters in delim, or NULL if no more
 * tokens.  *p is altered on each call, and is the start of the
 * buffer to read tokens from.
 */
extern char *tokensep(char **p, char *delim);
#endif
