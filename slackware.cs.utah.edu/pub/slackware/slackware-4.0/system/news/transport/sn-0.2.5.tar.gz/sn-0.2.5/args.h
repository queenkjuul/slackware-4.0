/*
 * This file (args.h) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#ifndef ARGS_H
#define ARGS_H
#include "lib/readln.h"
extern char *args[20];
extern char args_outbuf[1024];
extern char args_inbuf[1024];
extern int args_write(int fd, char *fmt, ...);
extern int args_read(struct readln *rp);
extern void args_report(char * tag);
extern void args_flushtodot(struct readln *rp);
#endif
