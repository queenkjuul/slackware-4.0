/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
/*
 * Simple logging function using varargs.
 */

#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include "format.h"

static const char rcsid[] = "$Id: out.c,v 1.4 1998/10/08 02:50:11 harold Exp $";

static char outbuf[1024];
int log_withpid = 0;
int log_withtime = 0;

int
writefv(int fd, char * fmt, va_list ap)
{
  int wrote;
  int used;
  char * p;
  int len;
  char tmp[40];
  int er;

  for(used = wrote = 0; *fmt; fmt++)
    if( '%' == *fmt ){
      fmt++;
      if( ! *fmt )break;
      p = vachar(*fmt, &ap, tmp, &len);
      for(; len; len--){
        if( used >= sizeof(outbuf) ){
          er = write(fd, outbuf, used);
          if( -1 == er )return(-1);
          wrote += er;
          used = 0;
        }
        outbuf[used++] = *p++;
      }
    }else{
      if( used >= sizeof(outbuf) ){
        er = write(fd, outbuf, used);
        if( -1 == er )return(-1);
        wrote += er;
        used = 0;
      }
      outbuf[used++] = *fmt;
    }
  er = write(fd, outbuf, used);
  if( -1 == er )return(-1);
  return(wrote + er);
}

int
writef(int fd, char * fmt, ...)
{
  va_list ap;
  int er;
  va_start(ap, fmt);
  er = writefv(fd, fmt, ap);
  va_end(ap);
  return(er);
}

void exit(int code) { _exit(code); }
