/*
 * This file (sngetd.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>
#include "config.h"
#include "get.h"
#include "parameters.h"
#include "path.h"
#include "addr.h"
#include <out.h>
#include <opt.h>
#include <format.h>

static const char rcsid[] = "$Id: sngetd.c,v 1.3 1999/03/27 05:24:52 harold Exp $";

int debug = 0;
static int fifofd;
static int age = (10 * 60); /* don't fetch group within 10 min. of last fetch */

struct get{
  struct get * next;
  time_t t;
  char group[1];
};
static struct get * recently = 0;

static void
readgroup(void)
{
  static char inbuf[GROUPNAMELEN + 1];
  static int start = 0;
  static int used = 0;
  time_t t;
  int c;

  if( used == start )used = start = 0;
  if( (c = read(fifofd, inbuf + used, (sizeof(inbuf)-1)-used)) <= 0 )
    return;
  used += c;

  time(&t);

  for( ; ; ){
    char * p;
    int len, end;

    for(end = start; end < used && '\n' != inbuf[end]; end++);
    if( used == end ){
      /* partial */
      if( start > 0 ){
        memmove(inbuf, inbuf + start, used - start);
        used -= start;
      }else
        used = 0;
      start = 0;
      return;
    }

    /* got a group name */
    inbuf[end] = '\0';
    p = inbuf + start;

    if( end - start < GROUPNAMELEN && '[' != *p )
      if( (len = addr_domain(p)) > 0 && ! p[len] ){
        int i;
        for(i = len-1; i > -1 && (p[i] > 'Z' || p[i] < 'A'); i--);
        if( -1 == i ){
          struct get * gp;
          struct get * tmp;
          tmp = 0;
          for(gp = recently; gp; tmp = gp, gp = gp->next)
            if( (unsigned long)gp->t + age < (unsigned long)t ){
              if( tmp )tmp->next = 0; else recently = 0;
              do{ tmp = gp->next; free(gp); }while( (gp = tmp) );
              gp = recently;
              break;
            }else if( 0 == strcmp(gp->group, p) )
              break;

          if( ! gp ){
            if( 0 == add(p) ){
              LOG1("Will fetch \"%s\"", p);
              if( (gp = malloc(sizeof(struct get) + len)) ){
                strcpy(gp->group, p);
                gp->t = t;
                gp->next = recently; recently = gp;
              }else
                log("Oops, no memory to remember I'm fetching %s", p);
            }
          }else
            LOG1("Already fetched/fetching for %s", p);
        }
      }

    start = end + 1;
  }
}

void usage(void) { fail(1, "Usage:%s [-a age] [-h Bps] [-t timeout] "
"[-p concurrency] [-c pipelinedepth]", progname); }

int
main(int argc, char ** argv)
{
  char optdebugbuf[7];
  int n, mark;
  char * cp;
  fd_set rset;

  progname = ((cp = strrchr(argv[0], '/'))?cp+1:argv[0]);

  close(0); close(1);
  concurrency = 2;
  while( (n = opt_get(argc, argv, "apthcmo")) > -1 )
    switch( n ){
    case 'a':
      if( ! opt_arg )usage();
      if( (age = atoi(opt_arg)) <= 0 )
        fail(1, "Refetch age must be positive");
      break;
    case 'd':
      if( ++debug < 5 )
        if( ! optdebug )strcpy(optdebug = optdebugbuf, "-d");
        else strcat(optdebug, "d");
      break;
    case 'V': version(); exit(0);
    case 't':
      if( ! (opttimeout = opt_arg) )usage();
      if( atoi(opttimeout) <= 0 )fail(1, "Timeout must be positive");
      break;
    case 'p':
      if( ! opt_arg )usage(); concurrency = atoi(opt_arg);
      if( concurrency > 4 || concurrency <= 0 )
        fail(1, "Bad value for concurrency option -p");
      break;
    case 'h':
      if( ! opt_arg )usage(); throttlerate = atoi(opt_arg);
      if( throttlerate < 0 )fail(1, "Bad value for throttle option -h");
      break;
    case 'c':
      if( ! (optpipelining = opt_arg) )usage();
      if( optpipelining && atoi(optpipelining) < 0 )
        fail(1, "Bad value for pipeline option -c");
      break;
    case 'm':
      if( ! (optmax = opt_arg) )usage();
      if( optmax && atoi(optmax) <= 0 )
        fail(1, "Bad value for max-prime-articles option -m");
      break;
    case 'P': optlogpid = 1; log_with_pid(); break;
    default: usage();
    }

  if( -1 == dup2(2, 6) || -1 == dup2(2, 7) )
    fail(2, "Can't dup standard error:%m");
  parameters(1);
  if( -1 == chdir(snroot) )fail(2, "chdir(%s):%m", snroot);
  fifofd = open(".fifo", O_RDWR);
  if( -1 == fifofd )
    if( ENOENT == errno )fail(1, "%s/.fifo doesn't exist", snroot);
    else fail(2, "Can't open %s/.fifo:%m", snroot);
  fcntl(fifofd, F_SETFD, 1);
  init();
  if( -1 == set_path_var() )fail(2, "No memory");

  /*
    Alternative: leave sockets open, let server time us out.
    Not very neighbourly...
   */
  optnosockcache = 1;

  for(mark = 0; ; mark++){
    struct timeval tv;
    int max;

    if( jobs_not_done() )
      while( 0 == sow() );

    if( sigchld || 1 == mark % 20 ){  /* Can't avoid signal loss */
      sigchld = 0;
      while( 0 == reap() );
    }

    FD_ZERO(&rset);
    FD_SET(fifofd, &rset);

    if( throttlerate ){
      max = throttle_setfds(&rset);
      if( max < fifofd )max = fifofd;
      if( sigusr ){
        sigusr = 0; log("throttling at %d bytes/sec", throttlerate); }
    }else
      max = fifofd;

    tv.tv_sec = 5; tv.tv_usec = 0;
    if( select(max + 1, &rset, 0, 0, &tv) > -1 ){
      if( throttlerate )
        throttle(&rset);
      if( FD_ISSET(fifofd, &rset) )
        readgroup();
    }
  }
  exit(0);
}
