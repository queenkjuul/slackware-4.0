/*
 * This file (addr_domain.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */

int
addr_domain(char * buf)
{
  char * p;
  int lb;

  p = buf;
  if( (lb = ('[' == *p)) )p++;

  for( ; ; p++)
#define C(x) case x:
    switch( *p ){
    C('-') if( lb )return(0); /* fall through */
    C('.') if( '.' == p[-1] )return(0); /* safe */
    C('a') C('b') C('c') C('d') C('e') C('f') C('g') C('h') C('i')
    C('j') C('k') C('l') C('m') C('n') C('o') C('p') C('q') C('r')
    C('s') C('t') C('u') C('v') C('w') C('x') C('y') C('z')
    C('A') C('B') C('C') C('D') C('E') C('F') C('G') C('H') C('I')
    C('J') C('K') C('L') C('M') C('N') C('O') C('P') C('Q') C('R')
    C('S') C('T') C('U') C('V') C('W') C('X') C('Y') C('Z')
      if( lb )return(0);
    C('0') C('1') C('2') C('3') C('4') C('5') C('6') C('7') C('8') C('9')
      continue;
    case ']': if( lb )
    default:    if( buf != p )return(p - buf);
              return(0);
    }
}
