/*
 * This file (addr_addrspec.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#include "addr.h"

int
addr_addrspec(char * buf)
{
  char * p;
  int len;
  p = buf;
  len = addr_localpart(p);
  if( ! len )return(0);
  p += len;
  if( '@' != *p )return(0);
  p++;
  len = addr_domain(p);
  if( ! len )return(0);
  p += len;
  return(p - buf);
}
