/*
 * This file (snfetch.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Fetch articles with a degree of pipelining.
 */

#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys/uio.h>
#include <time.h>
#include "config.h"
#include "args.h"
#include "dhash.h"
#include "parameters.h"
#include <readln.h>
#include <b.h>
#include <out.h>
#include <format.h>
#include <opt.h>

struct readln input = {0,};
int newsbatch = 0;
int pipelining = 0;
int debug = 0;
int bytesin = 0;
int nrhave;
int nrnothave;

static const char rcsid[] = "$Id: snfetch.c,v 1.31 1999/02/21 10:35:45 harold Exp $";

static struct b s = {0,};
static struct data d;
static void toolong(void) { fail(3, "server reply too long:%S...", 20, args_inbuf); }

int *
sendstat(int from, int to, int * nr)
{
  int i, n, p;

  if( debug )log("sendstat:trying");
  if( (p = to - from) > pipelining )p = pipelining;

  for(n = from; n <= to + p; n++){
    if( n <= to )
      if( -1 == args_write(7, "STAT %d\r\n", n) )
        fail(2, "sendstat:args_write:%m");
    if( n > p || n >= to ){
      char * cp;
      i = args_read(&input);
      if( 0 == i )toolong();
      if( i < 3 )
        if( i <= 0 )fail(4, "sendstat:Error reading response, got \"%s\"", args_inbuf);
        else fail(3, "sendstat:Bad response to STAT, got \"%s\"", args_inbuf);
      i = atoi(args[0]);
      if( 423 == i || 430 == i )
        continue;
      else if( 223 != i )
        fail(3, "sendstat:Bad response to STAT, got \"%s\"", args_inbuf);
      d.messageid = args[2] + 1;
      if( ! (cp = strchr(args[2] + 1, '>')) )continue;
      *cp = '\0';
      if( -1 == dh_find(&d) ){
        nrnothave++;
        if( -1 == b_appendl(&s, (char *)&i, sizeof(i)) )
          fail(2, "b_appendl:%m");
      }else
        nrhave++;
    }
  }
  *nr = s.used/sizeof(int);
  return((int *)s.buf);
}

int *
sendxhdr(int from, int to, int * nr)
{
  int i;

  if( -1 == to )
    i = args_write(7, "XHDR Message-Id %d-\r\n", from);
  else
    i = args_write(7, "XHDR Message-Id %d-%d\r\n", from, to);

  if( -1 == i )fail(2, "args_write:%m");

  if( -1 == (i = args_read(&input)) )
    fail(3, "Error reading response to XHDR, got \"%s\"", args_inbuf);
  if( 0 == i )toolong();
  i = atoi(args[0]);
  if( 221 != i )return(sendstat(from, to, nr));

  for(i = 0; ; ){
    char * line;
    int len;
    char * cp;

    len = readln(&input, &line, '\n');
    if( 3 == len && '.' == line[0] && '\r' == line[1] )break;
    if( len <= 0 )fail(2, "readln:%m");

    i = strtoul(line, &cp, 10);
    if( ! *cp || (*cp != ' ' && *cp != '\t') )goto oops;
    if( cp == line )goto oops;
    if( ! (cp = strchr(cp, '<')) )goto oops;
    d.messageid = cp + 1;
    if( ! (cp = strchr(cp, '>')) )goto oops;
    *cp = '\0';

    if( -1 == dh_find(&d) ){
      nrnothave++;
      if( -1 == b_appendl(&s, (char *)&i, sizeof(i)) )
        fail(2, "b_appendl:%m");
    }else
      nrhave++;

    i = 0;
    continue;

oops:
    log("Bad response:%s", args_inbuf);
    if( ++i > 4 )fail(3, "Giving up");
  }
  *nr = s.used/sizeof(int);
  return((int *)s.buf);
}

void
readprint(void)
{
  int len;
  char * line;
  static struct b b = {0,};
  int inhead = 1;

  b.used = 0;
  while( (len = readln(&input, &line, '\n')) > 0 ){
    if( 3 == len &&  '.' == *line && '\r' == line[1] )
      break;
    bytesin += len;
    if( newsbatch ){
      int er;
      if( len > 1 && '\r' == line[len-2] ){
        if( inhead ){ if( 2 == len )inhead = 0; }
        else if( '.' == *line && '.' == line[1] ){ line++; len--; }
        b_appendl(&b, line, len - 2);
        er = b_appendl(&b, "\n", 1);
      }else /* fake EOL */
        er = b_appendl(&b, line, len);
      if( er )fail(2, "readprint:no memory");
    }else{
      if( -1 == b_appendl(&b, line, len) )
        fail(2, "readprint:no memory");
    }
  }

  if( len <= 0 )fail(4, "readprint:readln:%m");
  if( newsbatch ){
    char buf[64];
    struct iovec v[2];
    v[0].iov_len = formats(buf, sizeof(buf)-1, "#! rnews %d\n", b.used);
    v[0].iov_base = buf;
    v[1].iov_base = b.buf; v[1].iov_len = b.used;
    len = writev(1, v, 2);
  }else{
    b_appendl(&b, ".\r\n", 3);
    len = write(1, b.buf, b.used);
  }
  if( -1 == len )fail(2, "readprint:write:%m");
}

int
fetch(int * serials, int * nr)
{
  int last, n, collected, p;
  int nfail;
  int max;

  max = *nr;
  p = ((pipelining<max)?pipelining:max);
  nfail = last = collected = 0;

  for(n = 0; n < max + p; n++){
    if( n < max )
      if( -1 == args_write(7, "ARTICLE %d\r\n", serials[n]) )
        fail(2, "fetch:args_write:%m");
    if( n >= max || n >= p ){
      int i;
      i = args_read(&input);
      if( 0 == i )toolong();
      if( i < 3 )
        if( i <= 0 )fail(4, "fetch:args_read:%m");
      switch( atoi(args[0]) ){
      default:
        if( (++nfail) > 5 )fail(3, "Giving up");
        log("fetch:Bad response to ARTICLE, got \"%s\"", args_inbuf);
      case 430: case 423: continue;
      case 220: ;
      }
      last = atoi(args[1]);
      readprint();
      collected++;
    }
  }
  *nr = collected;
  return(last);
}

static int
cat(char * fn, int * val)
{
  char buf[64];
  int i;
  int fd = open(fn, O_RDONLY);
  if( -1 == fd )return(-1);
  i = read(fd, buf, sizeof(buf)-1);
  close(fd);
  if( -1 == i )return(-1);
  buf[i] = '\0';
  *val = atoi(buf);
  return(0);
}

void
usage(void)
{
  fail(1, "Usage:%s [-r] [-c depth] [-t timeout] newsgroup [serial [max]]", progname);
}

int
main(int argc, char ** argv)
{
  time_t t;
  char * newsgroup;
  int i;
  char * cp;
  int serial = -1;
  int max = -1;
  int timeout = 60;
  int * serials;
  int from, to, last, nr;
  int logpid = 0;

  progname = ((cp = strrchr(argv[0], '/'))?cp + 1:argv[0]);

  while( (i = opt_get(argc, argv, "tc")) > -1 )
    switch( i ){
    case 'r': newsbatch = 1; break;
    case 'd': debug++; break;
    case 'V': version(); exit(0);
    case 't': if( ! opt_arg )usage(); timeout = atoi(opt_arg); break;
    case 'c': if( ! opt_arg )usage(); pipelining = atoi(opt_arg); break;
    case 'P': logpid = 1; break;
    default: usage();
    }
  if( opt_ind >= argc )usage();
  newsgroup = argv[opt_ind++];
  if( opt_ind < argc ){
    if( (serial = atoi(argv[opt_ind++])) < 0 )
      fail(1, "serial must be positive");
    if( opt_ind < argc )
      if( (max = atoi(argv[opt_ind++])) < 0 )
        fail(1, "max must be positive");
  }

  if( (cp = malloc(i = strlen(progname) + strlen(newsgroup) + 32)) ){
    if( ! logpid )formats(cp, i-1, "%s:%s", progname, newsgroup);
    else formats(cp, i-1, "%s[%u]:%s", progname, getpid(), newsgroup);
    progname = cp;
  }

  parameters(1);

  if( -1 == chdir(snroot) || -1 == chdir(newsgroup) )
    fail(2, "chdir(%s/%s):%m", snroot, newsgroup);

  if( -1 == serial )
    if( cat(".serial", &serial) < 0 ){
      log("open(.serial):%m"); serial = 0;
    }else if( serial < 0 ){
      log("Bad serial %d changed to 0", serial); serial = 0; }
  if( -1 == max )
    if( cat(".max", &max) < 0 )
      max = -1;
    else if( max < 0 ){
      log("Bad max %d changed to -1", max); max = -1; }
  if( pipelining < 0 ){
    log("Bad pipelining %d changed to 0", pipelining); pipelining = 0; }

  if( -1 == readln_ready(6, timeout, &input) )
    fail(2, "readln_ready:%m");

  time(&t);

  if( -1 == args_write(7, "GROUP %s\r\n", newsgroup) )
    fail(2, "args_write:%m");

  if( -1 == (i = args_read(&input)) )
    fail(2, "Network read error:%m");
  if( 0 == i )toolong();
  if( i < 5 || atoi(args[0]) != 211 )
    fail(3, "Bad response to GROUP, got \"%s\"", args_inbuf);

  from = atoi(args[2]);
  to = atoi(args[3]);

  if( 0 == from && 0 == to )
    fail(0, "Empty newsgroup:%s", args_inbuf);
  if( serial == to )fail(0, "No new articles");
  last = 0;
  to += 2;  /* look ahead a bit */
  if( -1 == dh_open("../", 0) )fail(2, "dh_open:%m");
  if( serial > to || serial < from )
    log("out of sync, %d not between %d-%d", serial, last = from, to);
  else
    from = serial; /* normally taken */

  if( max > 0 )if( to - from > max )from = to - max;

  nrhave = nrnothave = 0;
  serials = sendxhdr(from, to, &nr);
  dh_close();

  if( ! serials || (last = fetch(serials, &nr)) <= 0 )
    fail(0, "Nothing to fetch");

  log("%d articles (%d bytes) in %d seconds", nr, bytesin, time(0) - t);
  if( debug )
    log("%d scanned were new, %d were already present", nrnothave, nrhave);

  if( last > 0 ){
    char buf[64];
    int len;
    int fd = open(".serial.tmp", O_WRONLY|O_CREAT, 0644);
    if( -1 == fd ){
      log("open(.serial.tmp):%m");
      fail(2, "Last article fetched was number %d", last);
    }else{
      len = formats(buf, sizeof(buf)-1, "%d\n", last);
      if( -1 == write(fd, buf, strlen(buf)) )
        fail(2, "write(.serial.tmp):%m");
      ftruncate(fd, len);
      close(fd);
    }
  }
  exit(0);
}
