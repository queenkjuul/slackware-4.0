/*
 * This file (group.h) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#ifndef GROUP_H
#define GROUP_H

/* This doesn't do much */

struct group{
  int nr_articles;
  int first;
  int last;
  int nopost;
};

extern int group_init(void);
extern void group_fin(void);
extern int group_info(char * groupname, struct group * gp);

/* returns the group names available.  All buffers
   returned are malloc()ed. */

extern char ** group_all(int * nr);

#endif
