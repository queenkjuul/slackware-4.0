#ifndef OUT_H
#define OUT_H
/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
#include <stdarg.h>
/*
 * General functions for output.
 * progname, if set, is prepended to each message written with log()
 * or fail().  All calls end in a write, so no buffer flushing problems.
 * writef() works like fprintf(3), writefv() like vfprintf(3); not
 * all conversion specs are supported.  %m is supported, and is the
 * string obtained from strerror(errno).
 * writes() writes a null terminated string.
 * exit() just calls _exit(2).
 */
extern char *progname;
extern void logv(char *fmt, va_list ap);
extern void log(char *fmt, ...);
extern void fail(int ex, char *fmt, ...);
extern int writefv(int fd, char *fmt, va_list ap);
extern int writef(int fd, char *fmt, ...);
#define writes(fd,str) \
  write(fd, str, (sizeof(str)!=sizeof(char*))?sizeof(str)-1:strlen(str))

/* NOTE! If using gprof, MUST use exit(3) from stdio! */
extern void exit(int code);

#endif
