/*
 * This file (snlogin.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Get the server's greeting, try and log in if necessary.
 */

#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include "config.h"
#include "parameters.h"
#include "args.h"
#include <out.h>
#include <readln.h>
#include <openf.h>
#include <format.h>
#include <opt.h>

int debug = 0;

static const char rcsid[] = "$Id: snlogin.c,v 1.9 1999/02/22 14:59:48 harold Exp $";

char * newsgroup = NULL;
struct readln input;

static void
clean(char * buf)
{
  char * cp;
  if( (cp = strchr(buf, '\r')) )*cp = '\0';
  if( (cp = strchr(buf, '\n')) )*cp = '\0';
}

static void
getstr(char * fmt, char * buf, int size)
{
  struct stat st;
  int fd;
  int i;
  fd = openf(0, O_RDONLY, fmt, newsgroup);
  if( -1 == fd )FAIL(2, "open(%s/%s):%m", newsgroup, fmt + 2);
  if( -1 == fstat(fd, &st) )FAIL(2, "stat(%s):%m", newsgroup, fmt + 2);
  if( st.st_mode & 002 )FAIL(1, "%s/%s is writeable", newsgroup, fmt + 2);
  if( st.st_mode & 004 )LOG("%s/%s is readable", newsgroup, fmt + 2);
  i = read(fd, buf, size-1);
  switch( i ){
  case 0: FAIL(1, "Empty file %s/%s", newsgroup, fmt + 2);
  case -1: FAIL(2, "Can't read %s/%s:%m", newsgroup, fmt + 2);
  default: buf[i] = '\0'; close(fd); clean(buf);
  }
}

void
trylogin(void)
{
  char user[256];
  char pass[256];
  int i;

  getstr("%s/.outgoing/username", user, sizeof(user));
  args_write(7, "AUTHINFO USER %s\r\n", user);
  i = args_read(&input);
  if( i < 1 )
    if( i < 0 )FAIL(3, "Couldn't read response to AUTHINFO USER");
    else{ args_report("trylogin:"); exit(3); }
  switch( atoi(args[0]) ){
  case 201: exit(9);
  case 281: case 200: exit(0);
  case 381: break;
  default: args_report("trylogin:"); exit(3);
  }

  getstr("%s/.outgoing/password", pass, sizeof(pass));
  args_write(7, "AUTHINFO PASS %s\r\n", pass);
  i = args_read(&input);
  if( i < 1 )
    if( i < 0 )FAIL(3, "Couldn't read response to AUTHINFO PASS");
    else{ args_report("trylogin:"); exit(3); }
  switch( atoi(args[0]) ){
  case 201: exit(9);
  case 281: case 200: exit(0);
  default: args_report("trylogin:"); exit(3);
  }
}

static void usage(void) { fail(1, "Usage:%s [-t timeout] newsgroup", progname); }

int
main(int argc, char ** argv)
{
  struct stat st;
  char * cp;
  char buf[1024];
  int tmo = 120;
  int i;

  progname = ((cp = strrchr(argv[0], '/'))?cp + 1:argv[0]);

  parameters(0);

  while( (i = opt_get(argc, argv, "t")) > -1 )
    switch( i ){
    case 'P': log_with_pid(); break;
    case 'd': debug++; break;
    case 'V': version(); exit(0);
    case 't': if( ! opt_arg )usage(); tmo = atoi(opt_arg); break;
    default: usage();
    }

  if( opt_ind >= argc )usage();
  newsgroup = argv[opt_ind++];
  if( opt_ind < argc )usage();

  if( -1 == chdir(snroot) )
    FAIL(2, "chdir(%s):%m", snroot);
  if( -1 == stat(newsgroup, &st) )
    FAIL(2, "stat(%s):%m", newsgroup);
  formats(buf, sizeof(buf) - 1, "%s/.outgoing", newsgroup);
  if( -1 == stat(buf, &st) )
    if( ENOENT == errno )FAIL(1, "%s is not a global newsgroup", newsgroup);
    else FAIL(2, "stat(%s):%m", buf);

  if( -1 == readln_ready(6, tmo, &input) )
    FAIL(2, "readln_ready:%m");
  i = args_read(&input);
  if( i < 1 )
    if( i < 0 )FAIL(3, "No greeting:%m?");
    else FAIL(3, "Got no response");

  switch( atoi(args[0]) ){
  case 201: exit(9);
  case 200: exit(0);
  case 480: trylogin(); /* Does not return */
  default: args_report(0); exit(3);
  }
  /* Not Reached */
  exit(0);
}
