#ifndef B_H
#define B_H
/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
/*
 * Append strings to a dynamically allocated buffer.  Returns -1 on
 * failure.  Calls malloc(3) implicitly.
 */

struct b{
  char * buf;
  int size;
  int used;
};

#define b_append(bp,str) b_appendl(bp,str,strlen(str))
extern int b_appendl(struct b * bp, char * str, int len);

#endif
