#ifndef OPENF_H
#define OPENF_H
/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
/*
 * Open the file specified by the format, with mode mode and open
 * flags specified by flags.
 */
extern int openf(int mode, int flags, char *fmt, ...);
#endif
