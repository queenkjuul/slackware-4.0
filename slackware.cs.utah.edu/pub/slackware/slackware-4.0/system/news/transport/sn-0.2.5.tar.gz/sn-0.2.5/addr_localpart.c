/*
 * This file (addr_localpart.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */

int
addr_localpart(char * buf)
{
  char * p;
  int dq, bs;

  p = buf;
  dq = bs = 0;

  for(p = buf; *p; p++)
    if( ! bs )
      switch( *p ){
      case '"':  dq = (! dq); break;
      case '\\': bs = 1; break;
      case '@':  if( dq )return(0); return(p - buf);
      case '(': case ')': case '<': case '>': case ',': case ';':
      case ':': case '[': case ']':
        if( ! dq )return(0);
        break;
      default: if( ! dq && *p <= ' ' )return(0);
      }
    else
      bs = 0;
  /* end of string */
  return(0);
}
