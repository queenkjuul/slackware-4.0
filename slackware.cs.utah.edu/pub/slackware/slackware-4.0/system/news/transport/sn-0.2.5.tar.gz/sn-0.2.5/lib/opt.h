#ifndef OPT_GET_H
#define OPT_GET_H
/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
/*
 * Alternative to getopt(3) for command line parsing.
 * opts is a string consisting of option characters WHICH TAKE AN
 * ARGUMENT.  Returns an option character which caller will have to
 * test if it is recognized, or -1 on end of options.  opt_ind and
 * opt_arg are as for getopt(3).
 * "--" is supported, meaning end of options.  Catted options are
 * ok; if a catted option takes an arg, the arg is assumed to begin
 * immediately after the end of that option character, or is the next
 * argument otherwise.
 */
extern int opt_ind;
extern char *opt_arg;
extern int opt_get(int c, char **v, char *opts);
#endif
