/*
 * This file (commands.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * NNTP commands here.  Each command is a function of
 * type void foo(void).
 */

#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <limits.h>
#include "config.h"
#include "times.h"
#include "dhash.h"
#include "art.h"
#include "group.h"
#include "args.h"
#include "body.h"
#include <b.h>
#include <wildmat.h>
#include <out.h>
#include <tokensep.h>
#include <format.h>

extern char * me;
extern int fifo;        /* If reader is "interested" in currentgroup,
                           write the group's name in this fd */
char * currentgroup = NULL;
int currentserial = -1;

extern void alltolower(char * buf);  /* in snntpd.c */
extern char ** allgroups;            /* in snntpd.c */
extern int nrgroups;                 /* in snntpd.c */

static const char rcsid[] = "$Id: commands.c,v 1.30 1999/03/27 05:20:42 harold Exp $";

#define putdot() args_write(1, ".\r\n")

void do_ihave(void) { args_write(1, "435 I'm happy for you\r\n"); }
void do_sendme(void) { args_write(1, "500 No thanks\r\n"); }
void do_slave(void) { args_write(1, "202 whatever\r\n"); }
void do_help(void) { args_write(1, "100 Help yourself\r\n.\r\n"); }

void
do_mode(void)
{
  extern int posting_ok;
  if( posting_ok )args_write(1, "200 Hi, you can post\r\n");
  else args_write(1, "201 Hi, you can't post\r\n");
}

/* Several ways to specify an article...  */
static char * specgroup;
static int speclo, spechi;
/* ...but with just one of two results */
static struct article article;
static char * specerror;

static int
readspec(char * spec)
{
  char * p;

  if( ! spec ){
    if( ! (specgroup = currentgroup) ){
      specerror = "412 No group selected\r\n"; return(-1); }
    if( -1 == (speclo = spechi = currentserial) ){
      specerror = "420 No article selected\r\n"; return(-1); }
  }else if( '<' == *spec ){
    struct data d;
    d.messageid = spec + 1;
    if( ! (p = strchr(d.messageid, '>')) ){
      specerror = "430 Invalid message ID\r\n"; return(-1); }
    *p = '\0';
    if( -1 == dh_find(&d) ){
      specerror = "430 No such article\r\n"; return(-1); }
    spechi = speclo = d.serial;
    specgroup = d.newsgroup;
  }else{
    if( ! (specgroup = currentgroup) ){
      specerror = "412 No group selected\r\n"; return(-1); }
    speclo = atoi(spec);
    if( ! (p = strchr(spec, '-')) )
      spechi = speclo;
    else if( p[1] ){
      if( (spechi = atoi(p + 1)) < speclo ){
        specerror = "501 Invalid range\r\n"; return(-1); }
    }else
      spechi = INT_MAX;
  }
  return(0);
}

static char *
findid(void)
{
  char * id;
  if( (id = art_findfield(article.head, "Message-ID")) )
    return(id);
  return("<0>");
}

/*
 * Each time writefifo is called, the degree of interest in this
 * group increases until the fifo is written.
 */

static void
writefifo(void)
{
  static char * oldgroup = 0;
  static int interested = 0;

  if( NULL == currentgroup )return;
  if( -1 == fifo )return;
  if( oldgroup == currentgroup ){
    interested++;
    if( 3 == interested % 20 ){
      int len;
      len = strlen(currentgroup);
      currentgroup[len] = '\n';
      if( -1 == write(fifo, currentgroup, len + 1) ){
        LOG1("writefifo:%m"); }
      currentgroup[len] = '\0';
    }
  }else{
    interested = 0;
    oldgroup = currentgroup;
  }
}

#define PUTHEAD 0x1
#define PUTBODY 0x2

static void
putarticle(int flag, int code, char * msg)
{
  char * p;

  if( -1 == readspec(args[1]) ){ args_write(1, specerror); return; }
  if( -1 == art_gimme(specgroup, speclo, &article) ){
    if( errno )
      if( ENOENT != errno )
        log("putarticle:art_gimme(%s,%d):%m", specgroup, speclo);
    args_write(1, "430 No such article\r\n");
    return;
  }
  if( speclo != spechi ){ args_write(1, "512 Invalid argument\r\n"); return; }

  if( flag & PUTBODY )do{
    /*
     * Bit dangerous.  To test the validity of the body we are about
     * to display, check these 2 things: the bytes -before- and
     * -after- the body buffer must be '\0'.  This is not normally
     * checked for in art_gimme() because it will fault in the page,
     * but now we know we will be accessing it.
     */

    if( ! art_bodyiscorrupt(article.body, article.blen) )
      if( 0 == body(&article.body, &article.blen) )
        if( ! article.body[article.blen] )
          break;
        else p = "Internal error, uncompressed to corrupt body";
      else p = "Internal error, can't uncompress body";
    else p = "Article is corrupt";
    args_write(1, "423 %s\r\n", p);
    return;
  }while( 0 );

  if( ! args[1] || '<' != *args[1] ){
    args_write(1, "%d %d %s %s\r\n", code, speclo, findid(), msg);
    currentserial = speclo;
    writefifo();
  }else
    args_write(1, "%d %d <%s> %s\r\n", code, speclo, args[1] + 1, msg);

  switch( flag ){
  case 0: return;
  case PUTHEAD:
  case PUTBODY|PUTHEAD:
    /* should never have let Xref into header, now have to remove it */
    p = strstr(article.head, "Xref:");
    if( p && (p == article.head || '\n' == p[-1]) )
      writef(1, "%SXref: %s %s:%d%s",
        p - article.head, article.head, me, specgroup, speclo, p + 5);
    else
      writef(1, "%sXref: %s %s:%d\r\n",
        article.head, me, specgroup, speclo);
    if( PUTHEAD == flag )break;
    write(1, "\r\n", 2);
  case PUTBODY:
    write(1, article.body, article.blen);
    if( '\n' != article.body[article.blen-1] ){
      LOG("putarticle:%s:%d does not end in newline", specgroup, speclo);
      write(1, "\r\n", 2);
    }
  }
  putdot();
}

void do_article(void) { putarticle(PUTHEAD|PUTBODY, 220, "Article follows"); }
void do_body(void) { putarticle(PUTBODY, 222, "Body follows"); }
void do_head(void) { putarticle(PUTHEAD, 221, "Head follows"); }
void do_stat(void) { putarticle(0, 223, "Request text separately"); }

void
do_group(void)
{
  struct group g;
  alltolower(args[1]);
  if( -1 == group_info(args[1], &g) ){
    args_write(1, "411 No such group here as %s\r\n", args[1]);
  }else{
    args_write(1, "211 %d %d %d %s\r\n",
      g.nr_articles, g.first, g.last, args[1]);
    if( currentgroup ){ free(currentgroup); specgroup = 0; }
    currentgroup = strdup(args[1]);
    currentserial = -1;
  }
  writefifo();
}

static void
nextlast(int inc, char * ermsg)
{
  int serial;
  int count = 2 * ARTSPERFILE;

  for(serial = currentserial + inc; serial && count; serial += inc, count--)
    if( 0 == art_gimme(currentgroup, serial, &article) ){
      args_write(1, "223 %d %s request text separately\r\n",
        serial, findid());
      currentserial = serial;
      return;
    }
  args_write(1, ermsg);
}

void do_last(void) { nextlast(-1, "422 No previous article\r\n"); }
void do_next(void) { nextlast(+1, "421 No next article\r\n"); }

/* date: YYMMDD; clock: HHMMSS */

static time_t
converttime(char * date, char * clock, char * gmt)
{
  struct tm tm = {0,};
  time_t t;
  int thiscentury;
  int difference = 0;
  struct tm * tmp;

  if( 6 != strspn(date, "0123456789") ||
    6 != strspn(clock, "0123456789") )return((time_t)-1);

  t = time(NULL);
  tmp = localtime(&t);
  thiscentury = (tmp->tm_year / 100) * 100;

#define DIG(c) (c-'0')
  tm.tm_year = DIG(*date)*10 + DIG(date[1]); date += 2;
  if( tm.tm_year < 50 )tm.tm_year += (thiscentury + 100);
  else tm.tm_year += thiscentury;
  tm.tm_mon = DIG(*date)*10 + DIG(date[1]); date += 2;
  tm.tm_mon -= 1;
  tm.tm_mday = DIG(*date)*10 + DIG(date[1]);

  tm.tm_hour = DIG(*clock) + DIG(clock[1]); clock += 2;
  tm.tm_min = DIG(*clock) + DIG(clock[1]); clock += 2;
  tm.tm_sec = DIG(*clock) + DIG(clock[1]);

  if( gmt && 0 == strcasecmp(gmt, "GMT") )
    /* Convert to local time, all our stuff is in local time. */
    difference = t - mktime(gmtime(&t));

  t = mktime(&tm);
  if( (time_t)-1 == t )return((time_t)-1);
  return(t - difference);
}

void
do_newgroups(void)
{
  time_t cutoff;
  extern char ** allgroups;
  extern int nrgroups;

  cutoff = converttime(args[1], args[2], args[3]);
  if( (long)cutoff > 0 ){
    /* XXX Do we -have- to always reply 231? */
    args_write(1, "231 new newsgroups follows\r\n");
    if( allgroups ){
      int i;
      for(i = 0; i < nrgroups; i++){
        char buf[GROUPNAMELEN + sizeof("/.created")];
        struct stat st;
        formats(buf, sizeof(buf) - 1, "%s/.created", allgroups[i]);
        if( -1 == stat(buf, &st) ){
          LOG("do_newgroups:stat(%s):%m", buf); continue; }
        if( st.st_ctime >= cutoff ){
          struct group g;
          if( -1 == group_info(allgroups[i], &g) )continue;
          args_write(1, "%s %d %d y\r\n", allgroups[i], g.first, g.last);
        }
      }
    }else
      LOG2("do_newgroups:we have no groups");
  }else
    args_write(1, "231 Bad date or time\r\n");
  putdot();
}

char **
globgroups(char * pattern)
{
  static char ** matched = 0;
  char * pat;
  int i, last, nogo;

  last = nrgroups;
  if( ! matched )
    if( ! (matched = malloc((last + 1) * sizeof(char *))) ){
      log("globgroups:no memory");
      return(0);
    }

  for(i = 0; i < last; i++)matched[i] = allgroups[i];
  while( last && (pat = tokensep(&pattern, ",")) ){
    if( '!' == *pat ){ nogo = 1; pat++; }else nogo = 0;
    for(i = 0; i < last; )
      if( nogo == !!wildmat(matched[i], pat) )
        matched[i] = matched[--last];
      else
        i++;
  }
  if( 0 == last )return(0);
  matched[last] = 0;
  return(matched);
}

static void
putnewnews(char * group, time_t cutoff)
{
  int serial;

  serial = times_since(group, cutoff);
  if( serial <= 0 )return;
  for( ; ;serial++)
    if( 0 == art_gimmenoderef(group, serial, &article) )
      args_write(1, "%s\r\n", findid());
    else if( ENOENT == errno )return;
}

void
do_newnews(void)
{
  time_t cutoff;
  extern char ** allgroups;
  extern int nrgroups;

  cutoff = converttime(args[2], args[3], args[4]);

  if( cutoff > 0 ){
    args_write(1, "230 list of new articles follows\r\n");
    if( allgroups ){
      char ** groups;
      alltolower(args[1]);
      if( (groups = globgroups(args[1])) )
        while( *groups )
          putnewnews(*groups++, cutoff);
    }else
      LOG2("do_newnews: we have no groups");
    writefifo();
  }else
    args_write(1, "230 Bad date or time\r\n");
  args_write(1, ".\r\n");
}

static void
xlooper(char * spec, void (*f)(void), char * msg)
{
  if( -1 == readspec(spec) ){ args_write(1, specerror); return; }
  args_write(1, msg);
  for( ; speclo <= spechi; speclo++)
    if( -1 == art_gimme(specgroup, speclo, &article) ){
      if( errno )
        if( ENOENT == errno )break;
        else log("xlooper:art_gimme(%s,%d):%m", specgroup, speclo);
    }else
      f();
  putdot();
  if( spec && '<' != *spec )writefifo();
}

static void
putxover(void)
{
  struct xover x;

  art_makexover(&article, &x);
  writef(1, "%d\t%S\t%S\t%S\t%S\t%S\t%S\t%S\tXref:%s %s:%d\r\n",
    speclo,
    x.subject.len, x.subject.pointer,
    x.from.len, x.from.pointer,
    x.date.len, x.date.pointer,
    x.messageid.len, x.messageid.pointer,
    x.references.len, x.references.pointer,
    x.bytes.len, x.bytes.pointer,
    x.lines.len, x.lines.pointer,
    me, specgroup, speclo);
}

void
do_xover(void)
{
  xlooper(args[1], putxover, "224 XOVER follows\r\n");
}

static void
putxhdr(void)
{
  args_write(1, "%d %s\r\n", speclo,
    art_findfield(article.head, args[1]));
}

void
do_xhdr(void)
{
  xlooper(args[2], putxhdr, "221 XHDR follows\r\n");
}

static int flen;
static char * field;
static void
putxpat(void)
{
  char * head;
  char ** globs;
  head = article.head;
  globs = args + 3;
  for( ; ; ){
    if( *head == *field && 0 == strncasecmp(head, field, flen) )
      if( ':' == head[flen] ){
        head += flen + 1;
        while( *globs && wildmat(head, *globs) )globs++;
        if( *globs )return;
        args_write(1, "%s %S\r\n", speclo, strcspn(head, "\r\n"), head);
      }
    while( '\n' != *head )if( ! *head++ )return;
    head++;
  }
}

void
do_xpat(void)
{
  field = args[1];
  flen = strlen(field);
  xlooper(args[2], putxpat, "221 Headers follows\r\n");
}
