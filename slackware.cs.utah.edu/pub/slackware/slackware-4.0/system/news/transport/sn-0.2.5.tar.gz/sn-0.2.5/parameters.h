/*
 * This file (parameters.h) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#ifndef PARAMETERS_H
#define PARAMETERS_H

extern char *snroot;
extern unsigned snuid;
extern unsigned sngid;
extern void parameters(int wantwriteperms);

#endif
