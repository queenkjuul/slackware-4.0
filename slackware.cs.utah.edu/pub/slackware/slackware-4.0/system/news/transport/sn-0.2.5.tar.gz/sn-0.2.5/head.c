/*
  Read a message header, return number of bytes consumed.  This
  includes the separator header, if there was one.
  Input may contain lines ending in \r\n or bare \n, either ok.
  The resulting buffer contains only unfolded lines.
  The buffer does not end with a blank line.
  endline must be either "\n" or "\r\n".
  Returns:
  -2 input format error
  -1 read error or no memory
  >0 all ok.  This is also possible if the header is empty; caller
  should check.
  (*sw)() is passed each line in turn.  If it returns 0 that line is
  retained, otherwise it is discarded.
 */

#include <stdlib.h>
#include <b.h>
#include <readln.h>
#include <out.h>

#define ASSERT(cond) /* nothing */

int
read_unfold_head(struct b * head,
                 struct readln * rp,
                 int (*sw)(char *),
                 char * endline)
{
  int len, start;
  char * line;
  int endlinelen;
  int bytes;

  len = readln(rp, &line, '\n');
  if( len <= 2 )
    return((len>0)?-1:len);
  if( ' ' == *line || '\t' == *line )return(-2);
  line[--len] = '\0';
  if( '\r' == line[len-1] )line[--len] = '\0';

  start = head->used;
  if( ! head->size )
    if( ! (head->buf = malloc(head->size = 240)) )return(-1);
  endlinelen = strlen(endline);
  bytes = 0;

  /* Just can't get a decent rotation */
  for( ; ; ){
    if( -1 == b_appendl(head, line, len) )return(-1);
    if( -1 == b_appendl(head, endline, endlinelen) )return(-1);

    switch( (len = readln(rp, &line, '\n')) ){
    case 2: if( '\r' == *line++ )
    case 1:   if( '\n' == *line ){
                if( (*sw)(head->buf + start) )
                  head->buf[head->used = start] = '\0';
                return(bytes + len);
              }
              /* Fall Through */
    case 0: return(-2);
    case -1: return(-1);
    }

    bytes += len;
    line[--len] = '\0';
    if( '\r' == line[len-1] )line[--len] = '\0';
    if( ' ' == *line || '\t' == *line ){
      do{
        line++; len--;
      }while( *line && (' ' == *line || '\t' == *line) );
      ASSERT( head->used > endlinelen )
      head->used -= endlinelen;
      if( *line ) /* else, line containing only spaces */
        if( -1 == b_appendl(head, " ", 1) )return(-1);
    }else
      /* test the previously appended line */
      if( 0 == (*sw)(head->buf + start) )
        start = head->used;
      else
        head->used = start;  /* skip */
  }
}
