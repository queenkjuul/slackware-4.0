/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>

static const char rcsid[] = "$Id: nap.c,v 1.1 1998/08/31 17:22:29 harold Exp $";

void
nap(int sec, int msec)
{
  struct timeval tv; /* Counting on Linux to update tv */
  tv.tv_sec = sec; tv.tv_usec = msec * 1000;
  while( -1 == select(0, 0, 0, 0, &tv) && EINTR == errno );
}
