#ifndef NAP_H
#define NAP_H
/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
/*
 * Like sleep(2), but immune to signals.
 */
extern void nap(int sec, int msec);
#endif
