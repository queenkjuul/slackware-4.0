/*
 * This file (store.h) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#ifndef STORE_H
#define STORE_H
#include "art.h"

extern int sto_init(void);
extern int sto_add(char * newsgroup, struct article * ap);
extern void sto_fin(void);
#endif
