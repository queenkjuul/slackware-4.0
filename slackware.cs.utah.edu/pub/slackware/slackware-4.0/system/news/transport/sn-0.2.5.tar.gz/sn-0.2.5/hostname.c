/*
 * This file (hostname.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <netdb.h>
#include "config.h"

static const char rcsid[] = "$Id: hostname.c,v 1.6 1998/08/17 11:05:13 harold Exp $";

char *
myname(void)
{
  int fd;
  char * host = NULL;
  char buf[256];
  int count;

  if( (fd = open(".me", O_RDONLY)) > -1 ){
    if( (count = read(fd, buf, sizeof(buf)-1)) > 0 ){
      char * cp;
      buf[count] = '\0';
      if( (cp = strchr(buf, '\n')) )*cp = '\0';
      if( (cp = strchr(buf, '\r')) )*cp = '\0';
      host = strdup(buf);
    }
    close(fd);
  }

  if( ! host ){
    struct hostent * hp;
    if( 0 == gethostname(buf, sizeof(buf)) ){
      hp = gethostbyname(buf);
      if( hp )host = (char *)hp->h_name; /* silence cc, sometimes */
    }
  }
  if( NULL == host )host = strdup("localhost");
  return(host);
}
