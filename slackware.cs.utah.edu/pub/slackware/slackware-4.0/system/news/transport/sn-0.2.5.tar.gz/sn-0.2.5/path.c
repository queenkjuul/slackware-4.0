/*
  Make sure our BINDIR exists in $PATH
 */
#include <stdlib.h>
#include <string.h>

int
set_path_var(void)
{
  char * p;
  char * path;

  if( ! (p = getenv("PATH")) )
    return(putenv("PATH=" BINDIR));
  if( (path = strstr(p, BINDIR)) )
    if( path == p || ':' == path[-1] )
      if( ! path[sizeof(BINDIR)-1] || ':' == path[sizeof(BINDIR)-1] )
        return(0);
  path = malloc(strlen(p) + sizeof("PATH=:" BINDIR) + 2);
  if( ! path )return(-1);
  strcpy(path, "PATH=");
  strcat(path, p);
  strcat(path, ":" BINDIR);
  return(putenv(path));
}
