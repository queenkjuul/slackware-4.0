/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
static const char rcsid[] = "$Id: tokensep.c,v 1.2 1998/08/31 17:22:30 harold Exp $";

char *
tokensep(char ** p, char * delim)
{
  char map[256] = {0,};
  char * start;
  char * end;
  while( *delim ){ map[(unsigned)*delim] = 1; delim++; }
  for(start = *p; *start && map[(unsigned)*start]; start++);
  if( ! *start )return(0);
  for(end = start; *end && ! map[(unsigned)*end]; end++);
  if( *end ){ *p = end + 1; *end = '\0'; }
  else *p = end;
  return(start);
}
