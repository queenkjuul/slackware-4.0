/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
#include <sys/param.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include "format.h"

static const char rcsid[] = "$Id: openf.c,v 1.2 1998/10/08 02:50:11 harold Exp $";
static char buf[MAXPATHLEN + 1];

int
openf(int mode, int flags, char * fmt, ...)
{
  va_list ap;
  va_start(ap, fmt);
  if( formatv(buf, sizeof(buf)-1, fmt, ap) >= sizeof(buf) ){
    errno = ENAMETOOLONG; return(-1); }
  return(open(buf, flags, mode));
}
