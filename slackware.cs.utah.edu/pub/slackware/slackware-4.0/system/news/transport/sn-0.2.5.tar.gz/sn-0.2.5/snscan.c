/*
 * This file (snscan.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * If called as snscan:
 * Display the newsgroup, serial, and message id of all newsgroups
 * specified on command line.
 * If called as sncat:
 * Displays all articles mentioned.
 * See usage().
 */

#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdarg.h>
#include <netdb.h>
#include <time.h>  /* for time_t */
#include <sys/uio.h>
#include "config.h"
#include "art.h"
#include "group.h"
#include "dhash.h"
#include "hostname.h"
#include "parameters.h"
#include "times.h"
#include "body.h"
#include <out.h>
#include <tokensep.h>
#include <opt.h>
#include <b.h>
#include <format.h>

int debug = 0;

static const char rcsid[] = "$Id: snscan.c,v 1.27 1999/02/22 14:59:48 harold Exp $";

char * host;
time_t since = 0;
int outfd = 1;
int errors = 0;

int (*print)(int, struct article *, char *, char *, int);
int (*gimme)(char *, int, struct article *);

static void usage(void) { fail(1, "Usage: %s [-rn] [-o file] [-s since] articlespec ...\n"
  "where articlespec is [-n] news.group.name[:from#[-to#][,andalso#]...\n" 
  "OR: %s [-n] [-o file] [-s since] -i id ...\n"
  "where id is a message ID", progname, progname); }

char *
findid(char * head)
{
  char * cp = head;
  static char id[1024];
  char * dp = id;

  goto start;

  for(; *cp; cp++){
    if( '\n' == *cp ){
      cp++;
start:
      if( strncasecmp(cp, "message-id:", 11) )continue;
      cp += 11;
      while( *cp && isspace(*cp) )cp++;
      if( '<' != *cp )return(NULL);
      while( *cp ){
        *dp++ = *cp;
        if( '>' == *cp )break;
        cp++;
      }
      *dp = '\0';
      return(id);
    }
  }
  return(NULL);
}

void
doid(char * newsgroup, int serial)
{
  struct article a;
  char * id;
  char * e;
  int er;

  if( since > 0 ){
    int sserial;
    sserial = times_since(newsgroup, since);
    if( sserial <= 0 )return;
    if( serial < sserial )return;
  }

  if( 1 == (er = gimme(newsgroup, serial, &a)) )return;
  if( 0 == er ){
    if( *a.head && ! art_bodyiscorrupt(a.body, a.blen) )
      if( (id = findid(a.head)) )
        if( writef(outfd, "%s %d %s\n", newsgroup, serial, id) > 0 )
          return;
        else e = "write error:%m?";
      else e = "Can't find %s:%d:%m?";
    else e = "Corrupt article %s:%d";
  }else e = "Can't find %s:%d:%m?";
  LOG(e, newsgroup, serial);
  errors++;
}

static int
print_native(int outfd, struct article * ap, char * host, char * newsgroup, int serial)
{
  struct iovec v[10] = {{0,},};
  int i = 0;
  char buf[256];

  v[i].iov_base = ap->head; v[i].iov_len = ap->hlen;
  i++;

  if( host && newsgroup && serial ){
    formats(buf, sizeof(buf)-1, "Xref: %s %s:%d\r\n",
      host, newsgroup, serial);
    v[i].iov_base = buf; v[i].iov_len = strlen(buf);
    i++;
  }

  v[i].iov_base = "\r\n"; v[i].iov_len = 2;
  i++;

  v[i].iov_base = ap->body; v[i].iov_len = ap->blen;
  i++;
  v[i].iov_base = ".\r\n"; v[i].iov_len = 3;
  i++;

  return(writev(outfd, v, i));
}

static int
print_batch(int outfd, struct article * ap, char * host, char * newsgroup, int serial)
{
  struct b b = {0,};
  struct iovec v[2];
  char * cp;
  char * p;
  char buf[256];
  int e;

  for(cp = ap->head; (p = strchr(cp, '\r')); cp = p + 2){
    b_appendl(&b, cp, p - cp);
    if( -1 == b_appendl(&b, "\n", 1) )goto fail;
  }

  if( host && newsgroup && serial ){
    formats(buf, sizeof(buf)-1, "Xref: %s %s:%d\n\n",
      host, newsgroup, serial);
    b_append(&b, buf);
  }else
    b_appendl(&b, "\n", 1);

  for(cp = ap->body; (p = strchr(cp, '\r')); cp = p + 2){
    if( '.' == *cp )b_appendl(&b, ".", 1);
    b_appendl(&b, cp, p - cp);
    if( -1 == b_appendl(&b, "\n", 1) )goto fail;
  }

  formats(buf, sizeof(buf)-1, "#! rnews %d\n", b.used);

  v[0].iov_base = buf; v[0].iov_len = strlen(buf);
  v[1].iov_base = b.buf; v[1].iov_len = b.used;
  e = writev(outfd, v, 2);
  free(b.buf);
  return(e);

fail:
  if( b.buf )free(b.buf);
  return(-1);
}

void
doarticle(char * newsgroup, int serial)
{
  struct article a;
  char * e;
  int er;

  if( since > 0 ){
    int sserial;
    sserial = times_since(newsgroup, since);
    if( sserial <= 0 )return;
    if( serial < sserial )return;
  }

  if( 1 == (er = gimme(newsgroup, serial, &a)) )return;
  if( 0 == er ){
    if( ! art_bodyiscorrupt(a.body, a.blen) )
      if( 0 == body(&a.body, &a.blen) )
        if( print(outfd, &a, host, newsgroup, serial) )
          return;
        else e = "write error:%m?";
      else e = "Can't decompress? %s:%d:%m?";
    else e = "Corrupt body in %s:%d";
  }else e = "Can't find %s:%d:%m?";
  LOG(e, newsgroup, serial);
  errors++;
}

static void
range(char * spec, int * hi, int * lo)
{
  char * cp;
  *lo = atoi(spec);
  cp = strchr(spec, '-');
  if( cp )*hi = atoi(cp + 1);
  else *hi = -1;
}

static time_t
timefmt(char * str)
{
  struct tm tm = {0,};
  char * p = str;

  tm.tm_year = strtoul(p, &str, 10);
  if( ! str || ! *str )return(-1);
  if( tm.tm_year > 1900 )tm.tm_year -= 1900;
  p = ++str;
  tm.tm_mon = strtoul(p, &str, 10);
  if( ! str || ! *str )return(-1);
  tm.tm_mon--;
  p = ++str;
  tm.tm_mday = strtoul(p, &str, 10);
  if( str && *str ){
    p = ++str;
    tm.tm_hour = strtoul(p, &str, 10);
    if( str && *str ){
      p = ++str;
      tm.tm_min = strtoul(p, &str, 10);
      if( str && *str ){
        p = ++str;
        tm.tm_sec = strtoul(p, &str, 10);
      }
    }
  }
  return(mktime(&tm));
}

int
getnoaliases(char * group, int serial, struct article * ap)
{
  if( -1 == art_gimmenoderef(group, serial, ap) )return(1);
  if( ap->blen > 0 )return(0);
  if( 0 == strncasecmp(ap->head, "Message-ID:", 11) )return(1);
  return(0);
}

int
main(int argc, char ** argv)
{
  void (*fn)(char *, int);
  int i;
  char * cp;
  int useid = 0;

  progname = ((cp = strrchr(argv[0], '/'))?cp + 1:argv[0]);

  if( 0 == strcmp(progname, "snscan") )fn = doid;
  else fn = doarticle;

  parameters(0);

  if( -1 == chdir(snroot) )FAIL(2, "chdir(%s):%m", snroot);
  host = myname();

  gimme = art_gimme;
  print = print_native;
  while( (i = opt_get(argc, argv, "so")) > -1 )
    switch( i ){
    case 'P': log_with_pid(); break;
    case 'd': debug++; break;
    case 'n': gimme = getnoaliases; break;
    case 'V': version(); exit(0);
    case 'i': useid = 1; break;
    case 'r': print = print_batch; break;
    case 'o':
      if( ! opt_arg )usage();
      outfd = open(opt_arg, O_WRONLY|O_CREAT, 0644);
      if( -1 == outfd )fail(2, "open(%s):%m", opt_arg);
      break;
    case 's':
      if( ! opt_arg )usage();
      if( (time_t)-1 == (since = timefmt(opt_arg)) )
        fail(1, "Bad time format");
      break;
    default: usage();
    }
  if( opt_ind >= argc )usage();
  if( useid ){
    if( -1 == dh_open(0, 1) )fail(2, "Can't open database");
    for(; opt_ind < argc; opt_ind++){
      struct data d = {0,};
      if( '<' == *argv[opt_ind] ){
        d.messageid = argv[opt_ind] + 1;
        if( (cp = strchr(d.messageid, '>')) )*cp = '\0';
      }else
        d.messageid = argv[opt_ind];
      if( -1 == dh_find(&d) )continue;
      (*fn)(d.newsgroup, d.serial);
    }
    dh_close();
    exit(0);
  }
  if( since )
    if( (time_t)-1 == since )fail(1, "Bad time format");
    else times_init();

  if( opt_ind == argc )usage();

  if( -1 == group_init() )exit(2);

  for(; opt_ind < argc; opt_ind++){
    int hi;
    int lo;
    int j;
    char * cp;
    char * comma;
    char * newsgroup;

    newsgroup = argv[opt_ind];

    cp = strchr(argv[opt_ind], ':');
    if( cp ){
      *cp++ = '\0';
      if( (comma = tokensep(&cp, ",")) )
        do{
          range(comma, &hi, &lo);
          if( hi > lo )
            for(j = lo; j <= hi; j++)(*fn)(newsgroup, j);
          else
            (*fn)(newsgroup, lo);
        }while( (comma = tokensep(&cp, ",")) );
      else{
        range(cp, &hi, &lo);
        if( hi > lo )
          for(j = lo; j <= hi; j++)(*fn)(newsgroup, j);
        else
          (*fn)(newsgroup, lo);
      }
    }else{
      struct group g;
      if( -1 == group_info(argv[opt_ind], &g) ){
        errors++; continue; }
      for(j = g.first; j <= g.last; j++)
        (*fn)(newsgroup, j);
    }
  }
  if( since > 0 )times_fin();
  group_fin();
  exit(errors?3:0);
}

