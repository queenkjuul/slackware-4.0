/*
 * This file (snexpire.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Expire old news articles in a newsgroup.  Expiration is per file,
 * so ARTSPERFILE articles are deleted at a time.
 *
 * snexpire [-exp] newsgroup [[-exp] newsgroup] ...
 * If exp is not provided, uses the expiration time in that groups
 * .expire file.
 * The format is: #[hdwm] where h is hours, d is days, w is weeks,
 * and m is months (of 28 days).
 * so 1w is 1 week.  1 week is the default if nothing is mentioned.
 */

#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/stat.h>
#include "config.h"
#include "art.h"
#include "group.h"
#include "dhash.h"
#include "times.h"
#include "parameters.h"
#include <out.h>
#include <openf.h>
#include <format.h>
#include <opt.h>

static const char rcsid[] = "$Id: snexpire.c,v 1.22 1999/02/22 14:59:47 harold Exp $";

int debug = 0;

time_t
parseexp(char * buf)
{
  time_t exp;
  char * cp;

  if( NULL == buf )return(-1);
  exp = atoi(buf);
  if( exp < 0 )return(-1);

  cp = buf;
  while( *cp && isdigit(*cp) )cp++;
  switch( *cp ){
  case '\0': default: return(-1);
  case 'm': exp *= 4; 
  case 'w': exp *= 7;
  case 'd': exp *= 24;
  case 'h': exp *= 60;
            exp *= 60;
  }
  return(exp);
}

static time_t
readexp(char * newsgroup)
{
  char buf[32];
  int fd;
  int count;
  time_t t;

  if( (fd = openf(0, O_RDONLY, "%s/.expire", newsgroup)) > -1 ){
    if( (count = read(fd, buf, sizeof(buf)-1)) > -1 ){
      buf[count] = '\0';
      if( (t = parseexp(buf)) > -1 ){ close(fd); return(t); }
      LOG("bad format in %s/.expire", newsgroup);
    }
    close(fd);
  }
  return(DEFAULT_EXP);
}

/*
 * Always leave at least one file behind, so we know where the
 * article numbers start/end.
 */

static int
expire(char * newsgroup, time_t age)
{
  char buf[1024];
  int maxfile;
  int file;
  int serial;
  int i;

  if( age != 0 ){
    serial = times_since(newsgroup, time(NULL) - age);
    if( serial <= 1 )return(-1);
    maxfile = serial / ARTSPERFILE;
  }else
    maxfile = -1;

  {
    DIR * dir;
    struct dirent * dp;
    int tmp;
    int lastfile = -1;
    if( NULL == (dir = opendir(newsgroup)) ){
      LOG("expire:opendir(%s):%m", newsgroup); return(0); }
    while( (dp = readdir(dir)) )
      if( isdigit(*dp->d_name) )
        if( (tmp = atoi(dp->d_name)) > lastfile )
          lastfile = tmp;
    closedir(dir);
    if( -1 == lastfile ){
      LOG1("expire:group \"%s\" is empty", newsgroup); return(0); }

    if( maxfile == lastfile )return(0);

    if( -1 == maxfile )file = maxfile = lastfile;
    else file = maxfile;
  }

  for( ; file > -1; file--){
    struct article a;
    for(i = ARTSPERFILE; i > -1; i--){
      char * id;
      serial = (file * ARTSPERFILE) + i;
      if( -1 == art_gimmenoderef(newsgroup, serial, &a) )continue;
      id = art_findfield(a.head, "message-id");
      if( '<' == *id )id++;
      if( id && *id ){
        char buf[256];
        struct data d;
        char * cp;
        strcpy(buf, id);
        if( (cp = strchr(buf, '>')) )*cp = '\0';
        d.messageid = buf;
        if( -1 == dh_delete(&d) )
          LOG2("expire:id %s for %s:%d not found",
            id, newsgroup, serial);
      }else
        LOG2("expire:Can't find id for %s:%d", newsgroup, serial);
    }
    /* Delete the file */
    formats(buf, sizeof(buf) - 1, "%s/%d", newsgroup, file);
    if( -1 == unlink(buf) )
      if( ENOENT == errno )break;
      else{ LOG("expire:unlink(%s):%m", buf); }
  }
  times_expire(newsgroup, (maxfile * ARTSPERFILE) + 1);
  return(0);
}

static void usage(void) { fail(1, "Usage:%s [[-exp] newsgroup]...", progname); }

int
main(int argc, char ** argv)
{
  char * cp;
  int i;

  progname = ((cp = strrchr(argv[0], '/'))?cp + 1:argv[0]);

  while( (i = opt_get(argc, argv, "")) > -1 )
    switch( i ){
    case 'P': log_with_pid(); break;
    case 'd': debug++; break;
    case 'V': version(); exit(0);
    case '0': case '1': case '2': case '3': case '4':
    case '5': case '6': case '7': case '8': case '9':
      goto out;
    default: usage();
    }
out:

  parameters(1);

  if( -1 == chdir(snroot) )
    FAIL(2, "Can't chdir(%s):%m", snroot);

  do{
    if( 0 == times_init() ){
      if( 0 == dh_open(0, 0) ){
        if( 0 == group_init() )break;
        dh_close();
      }times_fin();
    }exit(2);
  }while( 0 );

  for(i = opt_ind; i < argc; i++){
    time_t exp;
    if( '-' == *argv[i] ){
      exp = parseexp(argv[i] + 1);
      if( -1 == exp )usage();
      i++;
    }else
      if( -1 == (exp = readexp(argv[i])) )
        exp = DEFAULT_EXP;

    expire(argv[i], exp);
  }
  group_fin();
  times_fin();
  dh_close();
  exit(0);
}
