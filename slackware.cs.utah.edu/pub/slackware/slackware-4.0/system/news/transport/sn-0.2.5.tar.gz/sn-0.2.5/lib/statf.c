/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
#include <sys/param.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include "format.h"

static const char rcsid[] = "$Id$";
static char buf[MAXPATHLEN + 1];

int
statf(struct stat * stp, char * fmt, ...)
{
  va_list ap;
  va_start(ap, fmt);
  if( formatv(buf, sizeof(buf)-1, fmt, ap) >= sizeof(buf) ){
    errno = ENAMETOOLONG; return(-1); }
  return(stat(buf, stp));
}
