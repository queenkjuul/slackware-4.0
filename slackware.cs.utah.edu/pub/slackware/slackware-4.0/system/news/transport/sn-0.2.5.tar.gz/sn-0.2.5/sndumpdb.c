/*
 * This file (sndumpdb.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Dump database.
 */

#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include "config.h"
#include "allocate.h"
#include "newsgroup.h"
#include "dhash.h"
#include "parameters.h"
#include <format.h>
#include <out.h>
#include <opt.h>

static const char rcsid[] = "$Id: sndumpdb.c,v 1.17 1999/03/27 05:25:24 harold Exp $";

int debug = 0;
int outfd = 1;

int
dh_dump(int next)
{
  int i;
  int nr = 0;
  unsigned index;
  struct chain * chp;
  int empties = 0;
  int total = 0;
  int maxlen = 0;
  int bytes = 0;

  for(i = 0; i < DH_SIZE; i++){
    unsigned char * x = dh_table->next + i*3;
    index = char3toint(x);
    if( ! index )
      empties++;
    else{
      int len = 0;
      for(; index; index = chp->next){
        char * group;
        int ident;
  
        chp = allo_deref(index);
        if( NULL == chp ){
          LOG("dh_dump:allo_deref returned bad ref"); return(0 - nr); }
        ident = char2toint(chp->newsgroup);
        group = ng_newsgroup(ident);
        if( NULL == group ){
          LOG("dh_dump:bad newsgroup for ident %d", ident); return(0 - nr); }
        if( ! next )
          writef(outfd, "%s %d <%s>\n", group, chp->serial, chp->messageid);
        else
          writef(outfd, "[%d,%d]%s %d <%s>\n",
            index, chp->next, group, chp->serial, chp->messageid);
        nr++;
        len++;
        bytes += strlen(chp->messageid);
      }
      total += len;
      if( len > maxlen )maxlen = len;
    }
  }

  log("%d chains of %d empty", empties, DH_SIZE);
  log("Total %d entries", total);
  if( empties < DH_SIZE )
    log("for average chain length of %d/100", (total*100) / (DH_SIZE - empties));
  log("with max chain length of %d", maxlen);
  if( total )
    log("Average length of ID is %d/100", (bytes*100)/total);
  return(nr);
}

int
main(int argc, char ** argv)
{
  int nr;
  char * cp;
  int withnext = 0;
  int i;

  progname = ((cp = strrchr(argv[0], '/'))?cp + 1:argv[0]);

  parameters(0);

  if( -1 == chdir(snroot) )FAIL(2, "chdir(%s):%m", snroot);

#define usage() fail(1, "Usage: %s [-i] [-o file]", progname)

  while( (i = opt_get(argc, argv, "o")) > -1 )
    switch( i ){
    case 'P': log_with_pid(); break;
    case 'd': debug++; break;
    case 'V': version(); exit(0);
    case 'i': withnext = 1; break;
    case 'o':
      if( ! opt_arg )usage();
      outfd = open(opt_arg, O_WRONLY|O_CREAT, 0644);
      if( -1 == outfd )fail(2, "open(%s):%m", opt_arg);
      break;
    default: usage();
    }
  if( opt_ind < argc )usage();

  if( -1 == dh_open(0, 1) )
    FAIL(2, "dh_open:%m?");

  nr = dh_dump(withnext);
  if( nr < 0 ){
    LOG("Error (%m?) while reading record number %d", 0 - nr);
    dh_close();
    exit(2);
  }
  dh_close();
  exit(0);
}

