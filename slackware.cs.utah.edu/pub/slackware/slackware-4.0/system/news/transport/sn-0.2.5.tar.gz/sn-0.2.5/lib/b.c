/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
/*
 * Dynamic buffer routines.
 */
#include <stdlib.h>
#include <string.h>
#include "b.h"

static const char rcsid[] = "$Id: b.c,v 1.2 1998/08/31 17:22:28 harold Exp $";

int
b_appendl(register struct b * bp, char * str, int len)
{
  if( NULL == bp->buf )
    if( NULL == (bp->buf = malloc(bp->size = 248)) )return(-1);
    else bp->used = 0;

  if( len + bp->used >= bp->size ){
    int newsize;
    char * tmp;
    if( len > bp->size )newsize = bp->size + len;
    else newsize = bp->size * 2;
    newsize += 16;
    tmp = malloc(newsize);
    if( NULL == tmp )return(-1);
    memcpy(tmp, bp->buf, bp->used + 1);
    bp->buf = tmp;
    bp->size = newsize;
  }
  memcpy(bp->buf + bp->used, str, len);
  bp->used += len;
  bp->buf[bp->used] = '\0';
  return(0);
}

