/*
 * This file (snget.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <dirent.h>
#include <string.h>
#include "config.h"
#include "get.h"
#include "parameters.h"
#include "path.h"
#include <out.h>
#include <opt.h>
#include <statf.h>
#include <format.h>

static const char rcsid[] = "$Id: snget.c,v 1.6 1999/03/27 05:24:52 harold Exp $";

int debug = 0;

void usage(void) { fail(1, "Usage:%s [-h Bps] [-t timeout] "
"[-p concurrency] [-c pipelinedepth] [[-r] -o file]", progname); }

int
main(int argc, char ** argv)
{
  char optdebugbuf[7];
  int n, mark;
  char * cp;

  progname = ((cp = strrchr(argv[0], '/'))?cp+1:argv[0]);

  while( (n = opt_get(argc, argv, "pthcmo")) > -1 )
    switch( n ){
    case 'd':
      if( ++debug < 6 )
        if( ! optdebug )strcpy(optdebug = optdebugbuf, "-d");
        else strcat(optdebug, "d");
      break;
    case 'V': version(); exit(0);
    case 't':
      if( ! (opttimeout = opt_arg) )usage();
      if( atoi(opttimeout) <= 0 )fail(1, "Timeout must be positive");
      break;
    case 'p':
      if( ! opt_arg )usage(); concurrency = atoi(opt_arg);
      if( concurrency > MAX_CONCURRENCY || concurrency <= 0 )
        fail(1, "Bab value for concurrency option -p");
      break;
    case 'h':
      if( ! opt_arg )usage(); throttlerate = atoi(opt_arg);
      if( throttlerate < 0 )fail(1, "Bad value for throttle option -h");
      break;
    case 'c':
      if( ! (optpipelining = opt_arg) )usage();
      if( optpipelining && atoi(optpipelining) < 0 )
        fail(1, "Bad value for pipeline option -c");
      break;
    case 'm':
      if( ! (optmax = opt_arg) )usage();
      if( optmax && atoi(optmax) <= 0 )
        fail(1, "Bad value for max-prime-articles option -m");
      break;
    case 'r': optrnews = 1; break;
    case 'o':
      if( ! (optoutfile = opt_arg) )usage(); break;
    case 'P': optlogpid = 1; log_with_pid(); break;
    default: usage();
    }
  if( optrnews )
    if( ! optoutfile )fail(1, "Option -r requires -o file");
  if( optoutfile ){
    int fd;
    fd = open(optoutfile, O_WRONLY|O_APPEND|O_TRUNC|O_CREAT, 0644);
    if( -1 == fd )
      fail(2, "Can't open %s for output:%m", optoutfile);
    if( fd != 1 )dup2(fd, 1); /* CLEX not set */
  }else
    if( -1 == dup2(2, 1) )
      fail(2, "Unable to dup:%m");
  close(0);
  /* snag 6 and 7 so we can dup onto them */
  if( -1 == dup2(2, 6) || -1 == dup2(2, 7) )
    fail(2, "Unable to dup standard error:%m");

  parameters(1);
  if( -1 == chdir(snroot) )fail(2, "chdir(%s):%m", snroot);
  init();
  if( -1 == set_path_var() )fail(2, "No memory");

  n = 0;
  if( opt_ind == argc ){
    DIR * dir;
    struct dirent * dp;
    struct stat st;
    if( ! (dir = opendir(".")) )
      fail(2, "opendir(%s):%m", snroot);
    while( (dp = readdir(dir)) )
      if( '.' != *dp->d_name )
        if( strlen(dp->d_name) < GROUPNAMELEN )
          if( 0 == statf(&st, "%s/.outgoing", dp->d_name) )
            if( S_ISDIR(st.st_mode) )
              if( add(dp->d_name) > -1 )n++;
    closedir(dir);
  }else{
    debug++;
    for( ; opt_ind < argc; opt_ind++)
      if( add(argv[opt_ind]) > -1 )n++;
    debug--;
  }

  if( 0 == n )fail(0, "No groups to fetch");

  for(mark = 0; jobs_not_done(); mark++){
    struct timeval tv;
    fd_set rset;
    int max;

    while( 0 == sow() );
    FD_ZERO(&rset);
    if( throttlerate ){
      max = throttle_setfds(&rset);
      if( sigusr ){
        sigusr = 0; log("throttling at %d bytes/sec", throttlerate); }
    }else
      max = -1;

    tv.tv_sec = 1; tv.tv_usec = 0;
    if( select(max + 1, &rset, 0, 0, &tv) > 0 )
      if( throttlerate )
        throttle(&rset);

    if( sigchld || 1 == mark % 10 ){
      sigchld = 0;
      while( 0 == reap() );
    }
  }
  quit();
  exit(0);
}
