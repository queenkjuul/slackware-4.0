/*
 * This file (list.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Functions for the NNTP LIST command and its variants.
 * Assumes args[0] is "LIST", and args[1] is not null.
 */

#include <fnmatch.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include "config.h"
#include "art.h"
#include "group.h"
#include "args.h"
#include <out.h>

extern struct readln input;
extern void alltolower(char * buf);  /* in snntpd.c */
extern int topline(char * group, char * fn, char * buf, int size);
extern char ** globgroups(char * pat);

static const char rcsid[] = "$Id: list.c,v 1.17 1999/03/27 05:24:21 harold Exp $";

extern char ** allgroups;
extern int nrgroups;

/* Same as LIST but may have an optional wildmat */

static void
listactive(void)
{
  char ** groups;
  struct group g;

  args_write(1, "215 list follows\r\n");

  groups = (args[2]?globgroups(args[2]):allgroups);
  if( groups )
    for( ; *groups; groups++)
      if( 0 == group_info(*groups, &g) )
        args_write(1, "%s %d %d %s\r\n",
          *groups, g.last, g.first, g.nopost?"n":"y");
  args_write(1, ".\r\n");
}

/* Display format of overview database */

static void
listoverviewfmt(void)
{
  args_write(1, "215 ok\r\n");
  args_write(1, "Subject:\r\n"
             "From:\r\n"
             "Date:\r\n"
             "Message-ID:\r\n"
             "References:\r\n"
             "Bytes:\r\n"
             "Lines:\r\n"
             "Xref:Full\r\n.\r\n");
}

static void
showinfo(char * group)
{
  char buf[128];

  if( topline(group, ".info", buf, sizeof(buf)) <= 0 )
    *buf = '\0';
  args_write(1, "%s %s\r\n", group, *buf?buf:"");
}

static void
listnewsgroups(void)
{
  char ** groups;

  args_write(1, "215 Here you go\r\n");
  
  groups = (args[2]?globgroups(args[2]):allgroups);
  if( groups )
    for( ; *groups; groups++)
      showinfo(*groups);
  args_write(1, ".\r\n");
}

/* ZB was here */

static void
listdistribpats(void)
{
  args_write(1, "215 ok\r\n");
  args_write(1, ".\r\n");
}

void
do_list(void)
{
  if( args[1] ){
    if( 0 == strcasecmp(args[1], "active") )
      listactive();
    else if( 0 == strcasecmp(args[1], "newsgroups") )
      listnewsgroups();
    else if( 0 == strcasecmp(args[1], "overview.fmt") )
      listoverviewfmt();
    else if( 0 == strcasecmp(args[1], "distrib.pats") )
      listdistribpats();
    else
      args_write(1, "503 \"LIST %s\" command not implemented\r\n", args[1]);
  }else
    listactive();
}

extern char * currentgroup;  /* in commands.c */
extern int currentserial;

/* Alters currentgroup and currentserial */

static void
listgroup(char * group)
{
  struct group g;
  struct article unused;
  int last = -1;
  int i;

  if( -1 == group_info(group, &g) ){
    LOG("listgroup:can't get group info for %s", group); return; }
  if( currentgroup != group ){
    free(currentgroup); currentgroup = strdup(group); }
  currentserial = -1;
  for(i = g.first; i <= g.last; i++)
    if( 0 == art_gimme(group, i, &unused) ){
      last = i;
      writef(1, "%d\r\n", i);
      if( -1 == currentserial )
        currentserial = i;
    }
}

void
do_listgroup(void)
{
  char * mygroup;
  if( args[1] ){
    int i;
    alltolower(args[1]);
    for(i = nrgroups; i--; )
      if( 0 == strcasecmp(args[1], allgroups[i]) )break;
    if( -1 == i ){ args_write(1, "412 No such group\r\n"); return; }
    if( currentgroup )free(currentgroup);
    currentgroup = strdup(mygroup = allgroups[i]);
  }else if( ! (mygroup = currentgroup) ){
    args_write(1, "412 No group selected\r\n");
    return;
  }

  args_write(1, "211 Article numbers follow\r\n");
  listgroup(mygroup);
  args_write(1, ".\r\n");
}
