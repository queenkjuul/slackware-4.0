/*
 * This file (throttle.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Throttle io.  Each time we read or write, record the time it
 * happened and the number of bytes transferred.  The next io,
 * calculate if we need to pay (sleep) for the last io.
 */

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "config.h"
#include <out.h>

int debug = 0;

static const char rcsid[] = "$Id: throttle.c,v 1.3 1998/09/14 04:46:53 harold Exp $";

static int throttle_rate = 0;  /* in bytes per second */

static int
throttlewrite(int fd, char * buf, int size)
{
  static int bytes = 0;
  static struct timeval lastio = {0,};
  int x;
  struct timeval now = {0,};

  if( throttle_rate <= 0 )
    return(write(fd, buf, size));

  /* Do we need to block? */
  if( lastio.tv_sec && lastio.tv_usec ){
    struct timeval mustelapse;
    int msec;
    gettimeofday(&now, NULL);
    msec = (bytes * 1000) / throttle_rate;
    if( msec > 0 ){
      mustelapse.tv_sec = msec / 1000;
      mustelapse.tv_usec = (msec % 1000) * 1000;
      select(0, NULL, NULL, NULL, &mustelapse);
    }
  }

  x = write(fd, buf, size);
  if( x <= 0 )return(x);

  bytes = x;
  if( ! now.tv_usec )gettimeofday(&lastio, NULL);
  else lastio = now;
  return(x);
}

int pid = 0;

static void
handler(int signum)
{
  if( SIGUSR1 == signum ){
    if( throttle_rate > 0 ){
      throttle_rate /= 2;
      if( 0 == throttle_rate )throttle_rate = 1;
      LOG1("throttle rate now %d bytes/sec", throttle_rate);
    }
  }else if( SIGUSR2 == signum ){
    if( throttle_rate > 0 ){
      throttle_rate *= 2;
      LOG1("throttle rate now %d bytes/sec", throttle_rate);
    }
  }else
    if( pid > 0 )kill(pid, signum);
}

static int
errnocontinue(void)
{
  switch( errno ){
  case EAGAIN: case EINTR: return(1);
  default: LOG("%m"); return(0);
  }
}

static int
transfer(int in, int out)
{
  char buf[1024];
  int count;
  int written;
  int size;

  if( throttle_rate > 0 ){
    /* choose 1/2 second bursts, approx */
    size = (throttle_rate / 2) + 1;
    if( size > sizeof(buf) )size = sizeof(buf);
  }else
    size = sizeof(buf);

  while( 1 ){
    count = read(in, buf, size);
    if( 0 == count ){ close(out); return(-1); }
    if( -1 == count )
      if( errnocontinue() )continue;
      else{ close(out); close(in); return(-1); }
    break;
  }
  written = 0;
  while( written < count ){
    int i;
    i = throttlewrite(out, buf + written, count - written);
    if( -1 == i )
      if( errnocontinue() )continue;
      else{ close(in); close(out); return(-1); }
    written += i;
  }
  return(0);
}

static void
childhandler(int notused)
{
  int s;
  if( -1 == waitpid(pid, &s, 0) )exit(0);
  if( WIFEXITED(s) )exit(WEXITSTATUS(s));
  if( WIFSIGNALED(s) )exit(128 + WTERMSIG(s));
  fail(29, "Eh?");
  /* Not Reached */
}

#define usage() fail(1, "Usage: %s fd[r|w]rate program ...", progname)

int
main(int argc, char ** argv)
{
  char * cp;
  int moderead;
  int fd;
  int p[2];
  int er;

  progname = ((cp = strrchr(argv[0], '/'))?cp + 1:argv[0]);

  argv++;
  if( ! *argv )usage();
  {
    char * cp = *argv;
    if( ! isdigit(*cp) )usage();
    fd = atoi(cp);
    while( isdigit(*cp) )cp++;
    if( 'r' == *cp )moderead = 1;
    else if( 'w' == *cp )moderead = 0;
    else{ usage(); /* not reached */ _exit(99999); }
    cp++;
    throttle_rate = atoi(cp);
    if( throttle_rate < 0 )fail(1, "Bad rate");
  }
  argv++;
  if( ! *argv )fail(1, "Need a program to execute");

  {
    struct sigaction sa;
    int i;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);
    sa.sa_restorer = 0;
    sa.sa_handler = handler;
    for(i = 1; i < 32; i++)
      if( i != SIGCHLD )sigaction(i, &sa, NULL);
    sa.sa_handler = childhandler;
    sigaction(SIGCHLD, &sa, NULL);
  }

  if( -1 == pipe(p) )fail(2, "pipe:%m");

  pid = fork();
  if( -1 == pid )fail(2, "fork:%m");
  if( 0 == pid ){
    if( moderead ){
      close(p[1]);
      if( -1 == dup2(p[0], fd) )fail(9, "dup2:%m");
    }else{
      close(p[0]);
      if( -1 == dup2(p[1], fd) )fail(9, "dup2:%m");
    }
    execvp(*argv, argv);
    fail(19, "execvp(%s...):%m", *argv);
  }

  if( moderead )close(p[0]);
  else close(p[1]);

  do{
    if( moderead )er = transfer(fd, p[1]);
    else er = transfer(p[0], fd);
  }while( 0 == er );

  close(p[0]); close(p[1]);
  pause();
  exit(29);
}
