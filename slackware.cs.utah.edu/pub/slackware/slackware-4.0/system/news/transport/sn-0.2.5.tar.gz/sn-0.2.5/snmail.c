/*
 * This file (snmail.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Rewrite an rfc822 mail message into one suitable for news:
 *   Replace all Received: lines by a single Path: line.
 *   Construct a Newsgroups: line, using either a given newsgroup
 *   name, or from the From: header.
 *   Unfold all folded header lines.
 *   Convert In-Reply-To: and add to References: (Thanks ZB).
 *
 * Usenet message ID's are more restrictive than mail ID's.  I don't
 * care.
 *
 * Exec snstore and pass the altered message to it.
 * The message is read on fd 0.
 *
 * End-of-line expected is normal Unix style '\n', which gets
 * converted to '\r\n'.
 */

#include <unistd.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "config.h"
#include "dhash.h"
#include "parameters.h"
#include "hostname.h"
#include "head.h"
#include "path.h"
#include "addr.h"
#include <b.h>
#include <readln.h>
#include <out.h>
#include <opt.h>
#include <cmdopen.h>
#include <format.h>

int debug = 0;

const char rcsid[] = "$Id: snmail.c,v 1.23 1999/02/22 14:59:48 harold Exp $";

char * suffix = NULL;
char * messageid = NULL;
char * prefix = "local.";
struct b path = {0,};
struct b references = {0,};
struct readln input = {0,};

void memerr(void) { fail(2, "No memory"); }

char *
mkid(void)
{
  char * buf;
  char * me;
  int i;
  i = strlen(me = myname());
  if( ! (buf = malloc(i + 64)) )memerr();
  for(buf += i + 64; i > -1; i--)*buf-- = me[i];
  *buf-- = '@';
  i = (int)time(0);
  do *buf-- = "0123456789"[i%10]; while( (i/=10) );
  *buf-- = '.';
  i = getpid();
  do *buf-- = "0123456789"[i%10]; while( (i/=10) );
  return(buf + 1);
}

/*
  Construct a References: line
 */

void
appendtoreferences(char * buf)
{
  char * dst;
  char * p;

  dst = p = buf;
  while( (p = addr_qstrchr(p, '<')) ){
    int len;
    if( (len = addr_addrspec(++p)) <= 0 || '>' != p[len] )continue;
    if( -1 == b_appendl(&references, " <", 2) )memerr();
    if( -1 == b_appendl(&references, buf, addr_unescape(p, buf, len)) )memerr();
    if( -1 == b_appendl(&references, ">", 1) )memerr();
    p += len + 1;
  }
}

/*
  Construct a Path: line from Received: lines
 */

void
appendtopath(char * rcvd)
{
  for( ; ; rcvd++){
    int len;
    if( ! (rcvd = addr_qstrchr(rcvd, ' ')) )return;
    if( strncasecmp(rcvd, " by ", 4) )continue;
    for(rcvd += 4; ' ' == *rcvd || '\t' == *rcvd; rcvd++)
      if( ! *rcvd )return;
    if( (len = addr_domain(rcvd)) > 0 ){
      if( -1 == b_appendl(&path, "!", 1) )memerr();
      if( -1 == b_appendl(&path, rcvd, len) )memerr();
    }
  }
}

/*
  To construct the tail part of a Newsgroups: line
 */

void
savelocal(char * frm)
{
  int len;

  if( (frm = addr_qstrchr(frm, '<')) )
    if( (len = addr_localpart(++frm)) > 0 ){
      if( ! (suffix = malloc(len + 1)) )memerr();
      addr_unescape(frm, suffix, len);
    }
}

/*
  Decide what to do with each header line.
 */

int
switchline(char * line)
{
  char * p;
  int len;

  switch( *line ){
  case 'f': case 'F':
    if( 0 == strncmp(line, "From ", 5) )return(1); /* skip */
    if( ! suffix )
      if( 0 == strncasecmp(line, "From:", 5) )
        savelocal(line + 5);
    break;
  case 'r': case 'R':
    if( 0 == strncasecmp(line, "Received:", 9) ){
      appendtopath(line + 9);
      return(1);
    }
    if( 0 == strncasecmp(line, "References:", 11) ){
      appendtoreferences(line + 11);
      return(1);
    }
    if( 0 == strncasecmp(line, "Return-Path:", 12) )
      savelocal(line + 12);    /* overrides From: line */
    break;
  case 'i': case 'I':
    if( 0 == strncasecmp(line, "In-Reply-To:", 12) ){
      appendtoreferences(line + 12);
      return(1);
    }
    break;
  case 'm': case 'M':
    if( ! messageid )
      if( 0 == strncasecmp(line, "Message-ID:", 11) )
        if( (p = addr_qstrchr(line + 11, '<')) )
          if( (len = addr_addrspec(++p)) > 0 && '>' == p[len] )
            if( ! (messageid = malloc(len + 1)) )memerr();
            else addr_unescape(p, messageid, len);
    break;
  case 'n': case 'N':
    if( 0 == strncasecmp(line, "Newsgroups:", 11) )return(1);
    break;
  }
  return(0);
}

void usage(void) { fail(1, "Usage:%s [-s1n] [listname [prefix]]", progname); }

int
main(int argc, char ** argv)
{
  struct b head = {0,};
  struct data d = {0,};
  char * fullnewsgroup;
  char * newsgroup;
  struct stat st;
  char * cp;
  int i;
  int storepid, store_P, store_1, store_n;
  int fd;

  progname = ((cp = strrchr(argv[0], '/'))?cp + 1:argv[0]);

  parameters(0);

  if( -1 == chdir(snroot) )
    FAIL(2, "Can't chdir(%s):%m", snroot);

  newsgroup = 0;
  store_P = store_1 = store_n = storepid = 0;
  if( argc > 1 ){
    while( (i = opt_get(argc, argv, "")) > -1 )
      switch( i ){
      case 'd': debug++; break;
      case 'V': version(); exit(0);
      case 's': storepid = -1; break;
      case 'n': store_n = 1; break;
      case '1': store_1 = 1; break;
      case 'P': store_P = 1; log_with_pid(); break;
      default: usage();
      }
    if( opt_ind < argc )
      newsgroup = argv[opt_ind++];
    if( opt_ind < argc )
      prefix = argv[opt_ind++];
    if( opt_ind != argc )usage();
  }

  if( -1 == readln_ready(0, 0, &input) )FAIL(2, "readln_ready:%m");

  if( storepid != 0 ){
    char options[10];
    char * args[3];

    cp = options; *cp++ = '-';  if( store_1 )*cp++ = '1';
    if( store_n )*cp++ = 'n';   if( store_P )*cp++ = 'P';
    for(i = 0; i < debug && i < 4; i++)*cp++ = 'd';
    *cp = '\0';
    args[0] = "snstore";
    if( options[1] ){ args[1] = options; args[2] = 0; }
    else args[1] = 0;
    set_path_var();
    if( (storepid = cmdopen(args, 0, &fd)) <= 0 )
      fail(2, "Can't exec snstore:%m?");
  }else{
    if( store_n || store_1 )
      fail(1, "Options -1 or -n not valid without -s");
    fd = 1;
  }

  switch( read_unfold_head(&head, &input, switchline, "\r\n") ){
  case 0: case 1: case 2: case -2: fail(3, "Bad message format");
  case -1: fail(2, "Can't read message:%m");
  }
  if( ! newsgroup )
    if( ! (newsgroup = suffix) )
      FAIL(1, "No newsgroup specified");

  i = strlen(prefix) + strlen(newsgroup);
  if( i >= GROUPNAMELEN )fail(1, "Target newsgroup name too long");
  if( ! (fullnewsgroup = malloc(i + 1)) )memerr();
  strcat(strcpy(fullnewsgroup, prefix), newsgroup);

  if( strstr(fullnewsgroup, "..") || strchr(fullnewsgroup, '/') )
    FAIL(2, "Bad newsgroup name \"%s\"", fullnewsgroup);
  for(cp = fullnewsgroup; *cp; cp++)
    if( *cp <= 'Z' && *cp >= 'A' )*cp += 'a' - 'A';
  if( -1 == stat(fullnewsgroup, &st) || ! S_ISDIR(st.st_mode) )
    FAIL(2, "No such group as \"%s\"", fullnewsgroup);

  if( messageid ){
    if( -1 == dh_open(0, 1) )exit(2);
    d.messageid = messageid;
    if( 0 == dh_find(&d) ){
      LOG("id \"<%s>\" already exists in group %s",
        messageid, d.newsgroup);
      /* in case an old version of preline is used (what for?) */
      while( (i = readln(&input, &cp, '\n')) > 0 );
      exit(0);
    }
    dh_close();
  }

  if( path.buf ){
    if( -1 == writef(fd, "Path: %s\r\n", path.buf + 1) )goto writeerr;
    free(path.buf);
  }
  if( -1 == write(fd, head.buf, head.used) )goto writeerr;
  free(head.buf);
  if( references.buf ){
    if( -1 == writef(fd, "References: %s\r\n", references.buf + 1) )
      goto writeerr;
    free(references.buf);
  }
  if( ! messageid )
    if( -1 == writef(fd, "Message-Id: <%s>\r\n", mkid()) )goto writeerr;
  if( -1 == writef(fd, "Newsgroups: %s\r\n\r\n", fullnewsgroup) )
    goto writeerr;

  while( (i = readln(&input, &cp, '\n')) > 0 ){
    cp[--i] = '\0';
    if( i && '\r' == cp[i-1] )cp[--i] = '\0';
    if( '.' == *cp )write(fd, ".", 1);
    if( -1 == writef(fd, "%s\r\n", cp) )goto writeerr;
  }
  if( -1 == write(fd, ".\r\n", 3) )goto writeerr;

  if( ! storepid )exit(0);
  i = close(fd);
  if( -1 == (i = cmdwait(storepid)) )
    fail(2, "error in waitpid:%m");
  exit(i);

writeerr:
  fail(2, "output write error:%m");
  exit(1);
}
