/*
 * This file (group_all.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#include <sys/param.h>
#include <dirent.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <string.h>
#include "config.h"
#include "addr.h"
#include <out.h>

static const char rcsid[] = "$Id: group_all.c,v 1.3 1999/02/21 10:21:16 harold Exp $";

char **
group_all(int * nr)
{
  DIR * dir;
  struct dirent * dp;
  char ** ary = NULL;
  int sz;
  int nr_ary = 0;

  dir = opendir(".");
  if( NULL == dir ){
    LOG("group_all:opendir:%m"); return(NULL); }

  ary = malloc((sz = 32)*sizeof(char *));
  if( NULL == ary ){
    LOG("group_all:malloc:%m");
    return(NULL);
  }

  while( (dp = readdir(dir)) ){
    struct stat st;
    int len;
    char * p;

    if( '.' == *dp->d_name )continue;
    if( '[' == *dp->d_name )goto skip;
    len = addr_domain(dp->d_name);
    if( 0 == len )continue;
    if( len > GROUPNAMELEN )goto skip;
    if( dp->d_name[len] )goto skip;
    for(p = dp->d_name; *p; p++)
      if( *p <= 'Z' && *p >= 'A' )break;
    if( *p )goto skip;
    len = p - dp->d_name;
    if( -1 == lstat(dp->d_name, &st) )goto skip;
    if( ! S_ISDIR(st.st_mode) )goto skip;
    if( ! (ary[nr_ary] = malloc(len + 1)) ){
      LOG("group_all:malloc:%m"); goto fail; }
    strcpy(ary[nr_ary++], dp->d_name);
    if( nr_ary >= sz ){
      char ** tmp = realloc(ary, (sz*=2)*sizeof(char *));
      if( ! tmp ){ LOG("group_all:realloc:%m"); goto fail; }
      ary = tmp;
    }
    if( 0 )skip: LOG1("group_all:ignoring \"%s\"", dp->d_name);
  }
  closedir(dir);
  ary[nr_ary] = NULL;
  if( nr )*nr = nr_ary;
  return(ary);

fail:
  closedir(dir);
  if( ary && nr_ary > 0 ){
    int i;
    for(i = 0; i < nr_ary; i++)if( ary[i] )free(ary[i]);
    free(ary);
  }
  return(NULL);
}

