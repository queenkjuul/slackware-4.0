/*
 * This file (post.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Accept a posting from a user.
 * We can only be run from snntpd, so our permissions are ok.
 * When we accept a post, check to see what groups they are to.
 * For all groups specified:
 * If a global group is specified, write it to the outgoing spool
 * of the first group we have.
 * If its to a private group, add it to the first group we have, then
 * for any other private groups, merely add a alias ("symlink").
 *
 * For private groups, we save the article to a temporary file, and
 * feed that to snstore, for the first article only.
 * For subsequent articles we just feed an alias to snstore.  The
 * alias has a stub header, and no body.
 *
 * For global groups, we give it to the upstream server and do
 * nothing else.
 */

#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include "config.h"
#include "dhash.h"  /* for struct data */
#include "art.h"
#include "args.h"
#include "parameters.h"
#include <b.h>
#include <out.h>
#include <readln.h>
#include <openf.h>
#include <format.h>
#include <tokensep.h>
#include <cmdopen.h>

static const char rcsid[] = "$Id: post.c,v 1.22 1999/02/21 10:27:06 harold Exp $";

extern int posting_ok;   /* snntpd.c */
extern char * client_ip; /* snntpd.c */
extern struct readln input;

static int
createfile(char * name)
{
  static int pid = 0;
  int fd;
  int i;

  if( 0 == pid )pid = getpid();
  for(i = 0; i < 5; i++){
    fd = openf(0644, O_WRONLY|O_CREAT|O_EXCL,
      "%s/.outgoing/$%u.%d", name, (int)time(NULL), pid);
    if( fd > -1 )return(fd);
  }
  LOG("createfile:open(%s/.outgoing/*)/wr/cr/ex:%m", name);
  return(-1);
}

static int
writeglobal(char * group, struct b * bp)
{
  int fd;
  int er;

  if( -1 == (fd = createfile(group)) )return(-1);
  er = write(fd, bp->buf, bp->used);
  close(fd);
  if( er != bp->used ){
    LOG("writeglobal(%s):short write:%m", group);
    return(-1);
  }
  return(0);
}

static int
writespecial(char * group, struct b * bp)
{
  char buf[GROUPNAMELEN + sizeof("/.outgoing")];
  int wp = -1;
  int pid;
  int er;

  formats(buf, sizeof(buf)-1, "%s/.outgoing", group);
  { char * c[] = { "sh", buf, 0 }; pid = cmdopen(c, 0, &wp); }
  if( pid <= 0 ){
    LOG("writespecial:child failure in %s:%m?", buf); return(-1); }
  while( -1 == (er = write(wp, bp->buf, bp->used)) && EINTR == errno );
  if( -1 == er )LOG("writespecial: pipe write error:%m");
  close(wp);
  er = cmdwait(pid);
  if( er < 0 )LOG("writespecial:wait error:%m?");
  else if( er > 0 )LOG("writespecial: child exited with %d", er);
  else return(0);

  if( wp > -1 )close(wp);
  return(-1);
}

static int
writeprivate(struct b * bp)
{
  int wp = -1;
  int pid;
  int er;
  static struct data d = {0,};
  char * cp;

  /*
    We probably needn't be worried about multiple private posts, but
    since NNTP has no authentication we could stand to be a bit
    paranoid.  Hence if the article is present, we ignore it.
   */

  d.messageid = art_findfield(bp->buf, "message-id");
  if( d.messageid && *d.messageid ){
    if( '<' == *d.messageid )d.messageid++;
    if( (cp = strchr(d.messageid, '>')) )*cp = '\0';
    if( d.messageid && 0 == dh_find(&d) ){
      LOG3("writeprivate:Found private x-post:<%s>", d.messageid);
      return(-1);
    }
  }

  { char * c[] = { "snstore", "-1", 0 }; pid = cmdopen(c, 0, &wp); }
  if( pid <= 0 ){
    LOG("writeprivate: couldn't exec snstore:%m?"); return(-1); }

  while( -1 == (er = write(wp, bp->buf, bp->used)) && EINTR == errno );
  if( -1 == er )LOG("writeprivate: pipe write error:%m");
  close(wp);
  er = cmdwait(pid);
  if( er < 0 )LOG("writeprivate: wait error:%m?");
  else if( er > 0 )LOG("writeprivate: child exited with %d", er);
  else return(0);

  return(-1);
}

static unsigned int
stat_(char * group, char * fn)
{
  char buf[GROUPNAMELEN + 33];
  struct stat st;
  formats(buf, sizeof(buf) - 1, "%s/%s", group, fn);
  if( -1 == stat(buf, &st) )return(0);
  return((unsigned int)st.st_mode);
}

static int
isspecial(char * group)
{
  char buf[GROUPNAMELEN + sizeof("/.outgoing")];
  struct stat st;
  formats(buf, sizeof(buf) - 1, "%s/.outgoing", group);
  if( -1 == stat(buf, &st) )return(0);
  if( ! S_ISREG(st.st_mode) )return(0);
  if( ! st.st_size ){
    LOG("isspecial:%s is empty", buf); return(0); }
  if( st.st_uid != 0 && st.st_uid != snuid ){
    LOG("isspecial:%s has wrong owner", buf); return(0); }
  if( S_IWGRP & S_IWOTH & st.st_mode ){
    LOG("isspecial:%s is group/world writable", buf); return(0); }
  return(1);
}

#define groupexists(grp) (S_ISDIR(stat_(grp, "")))
#define isglobal(grp) (S_ISDIR(stat_(grp, ".outgoing")))
#define isprivate(grp) (!(isglobal(grp)))
#define postok(grp) (!stat_(grp, ".nopost"))

void
do_post(void)
{
  struct b b = {0,};
  char * line;
  int len;
  int inheader = 1;
  char * newsgroups = NULL;

  if( ! posting_ok ){
    args_write(1, "440 Posting not allowed\r\n"); return; }
  
  args_write(1, "340 Send it\r\n");

  /*
   * Skip leading blank lines, which Netscape News seems to emit.
   * Thanks Marko.
   */

  while( (len = readln(&input, &line, '\n')) > 0 )
    if( 2 != len || '\r' != line[1] )break;

  if( len <= 0 )goto failed;

  do{
    line[len-1] = '\0';
    if( len >= 2 && '\r' == line[len-2] )line[len-2] = '\0';
    if( inheader ){
      if( ! *line ){
        inheader = 0;
        if( client_ip && *client_ip ){
          b_append(&b, "NNTP-Posting-Host: ");
          b_append(&b, client_ip);
          b_appendl(&b, "\r\n", 2);
        }
      }else if( NULL == newsgroups &&
        0 == strncasecmp(line, "Newsgroups:", 11) ){
        newsgroups = strdup(line + 11);
      }else if( 0 == strncasecmp(line, "NNTP-Posting-Host:", 18) )
        continue;
    }
    b_append(&b, line);
    b_appendl(&b, "\r\n", 2);
    if( '.' == *line && ! line[1] )break;
  }while( (len = readln(&input, &line, '\n')) > 0 );

  if( len <= 0 )goto failed;

  if( inheader ){
failed:
    switch( len ){
    case 0: LOG("do_post:end of file"); break;
    case -1: LOG("do_post:readln:%m"); break;
    }
    args_write(1, "441 Bad article\r\n");
    free(b.buf);
    if( newsgroups )free(newsgroups);
    return;
  }
  if( NULL == newsgroups ){
    args_write(1, "441 You don't have a \"Newsgroups:\" line\r\n");
    free(b.buf);
    return;
  }

  {
    int wroteglobal, wroteprivate, wrotespecial;
    char * grp; char * ng = newsgroups;

    wroteglobal = wroteprivate = wrotespecial = 0;

    while( (grp = tokensep(&ng, " \t\r\n,")) )
      if( groupexists(grp) && postok(grp) )
        if( isglobal(grp) ){
          if( ! wroteglobal )
            wroteglobal += 1 + writeglobal(grp, &b);
        }else if( isspecial(grp) )
          wrotespecial += 1 + writespecial(grp, &b);
        else if( ! wroteprivate )
          wroteprivate = 1 + writeprivate(&b);

    if( wroteglobal || wroteprivate || wrotespecial )
      args_write(1, "240 Yummy\r\n");
    else
      args_write(1, "441 We don't carry any of those "
        "newsgroups, or they are marked read-only\r\n");
  }
  free(newsgroups);
}
