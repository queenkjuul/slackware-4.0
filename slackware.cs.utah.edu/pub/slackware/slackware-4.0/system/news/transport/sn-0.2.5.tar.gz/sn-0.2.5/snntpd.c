/*
 * This file (snntpd.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * News reader daemon, NNTP protocol driver.
 */

#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "config.h"
#include "art.h"
#include "dhash.h"
#include "group.h"
#include "hostname.h"
#include "parameters.h"
#include "args.h"
#include <readln.h>
#include <out.h>
#include <openf.h>
#include <opt.h>
#include <format.h>

int debug = 0;

static const char rcsid[] = "$Id: snntpd.c,v 1.20 1999/03/27 05:29:49 harold Exp $";

int posting_ok = 1;
char * client_ip;
char * me;
struct readln input;

int fifo = -1;

extern char * currentgroup;
extern int currentserial;

extern void do_article(void);
extern void do_body(void);
extern void do_group(void);
extern void do_head(void);
extern void do_help(void);
extern void do_ihave(void);
extern void do_last(void);
extern void do_list(void);
extern void do_listgroup(void);
extern void do_mode(void);
extern void do_newgroups(void);
extern void do_newnews(void);
extern void do_next(void);
extern void do_post(void);
extern void do_quit(void);
extern void do_sendme(void);
extern void do_slave(void);
extern void do_stat(void);
extern void do_xhdr(void);
extern void do_xover(void);
extern void do_xpat(void);

struct cmd{
  char * name;
  void (*function)(void);
  char needs_args;            /* Min. number of args required */
  char needs_group;           /* Needs a current group set */
  char needs_article;         /* Needs a current article set */
  char needs_grouplist;
};

#define S(func) #func
#define DEF(func,args,group,art,gl) \
  { S(func), do_ ## func, args, group, art, gl},

static struct cmd cmds[] = {
  DEF(article,   1, 0, 0, 0)
  DEF(body,      1, 0, 0, 0)
  DEF(group,     2, 0, 0, 0)
  DEF(head,      1, 0, 0, 0)
  DEF(help,      0, 0, 0, 0)
  DEF(ihave,     1, 0, 0, 0)
  DEF(last,      1, 1, 1, 0)
  DEF(list,      1, 0, 0, 1)
  DEF(listgroup, 1, 0, 0, 1)
  DEF(mode,      2, 0, 0, 0)
  DEF(newgroups, 3, 0, 0, 1)
  DEF(newnews,   4, 0, 0, 1)
  DEF(next,      1, 1, 1, 0)
  DEF(post,      1, 0, 0, 0)
  DEF(quit,      1, 0, 0, 0)
  DEF(sendme,    0, 0, 0, 0)
  DEF(slave,     0, 0, 0, 0)
  DEF(stat,      1, 0, 0, 0)
  DEF(xhdr,      2, 1, 0, 0)
  DEF(xover,     1, 1, 0, 0)
  DEF(xpat,      4, 1, 0, 0)
};
#undef S
#undef DEF


void
alltolower(char * buf)
{
  char * cp;
  for(cp = buf; *cp; cp++)
    if( isupper(*cp) )*cp = tolower(*cp);
}

int
topline(char * group, char * fn, char * buf, int size)
{
  int fd, i;
  char * cp;
  if( NULL == group )fd = open(fn, O_RDONLY);
  else fd = openf(0, O_RDONLY, "%s/%s", group, fn);
  if( -1 == fd )return(-1);
  i = read(fd, buf, size-1);
  close(fd);
  if( i <= 0 )return(i);
  buf[i] = '\0';
  if( (cp = strchr(buf, '\n')) ){
    *cp = '\0'; return(cp - buf); }
  return(i);
}

char ** allgroups = NULL;
int nrgroups = 0;

static void
cleanup(void)
{
  if( debug >= 3 ){
    int hit, miss;
    art_filecachestat(&hit, &miss);
    LOG("do_quit:cache requests:%dT=%dH+%dM", hit + miss, hit, miss);
  }
  dh_close();
  group_fin();
  if( allgroups ){
    int i;
    for(i = 0; i < nrgroups; i++)
      if( allgroups[i] )free(allgroups[i]);
    free(allgroups);
  }
}

void do_quit(void) { args_write(1, "205 bye\r\n"); cleanup(); exit(0); }

/* Not quite safe to do this... */

static int checkservice = 0;

static void
handler(int signum)
{
  if( SIGHUP == signum ){ checkservice = 1; return; }
  dh_close();
  group_fin();
  LOG("Caught signal %d, exiting", signum);
  exit(3);
}

static void
openfifo(void)
{
  struct stat st;

  if( fifo > -1 )return;
  fifo = open(".fifo", O_RDWR|O_NONBLOCK);
  if( -1 == fifo ){
    LOG("open(fifo):%m(ok)"); return; }
  if( -1 == fstat(fifo, &st) )
    FAIL(2, "openfifo:stat(.fifo):%m");
  if( ! S_ISFIFO(st.st_mode) ){
    close(fifo); fifo = -1;
    LOG1(".fifo is not a fifo, ok");
  }
}

static void
docheckservice(void)
{
  struct stat st;
  char * reason = "maintenance";
  char buf[256];

  if( 0 == stat(".noservice", &st) ){
    if( st.st_size )
      if( -1 != topline(NULL, ".noservice", buf, sizeof(buf)) )
        reason = buf;
    args_write(1, "400 Service going down: %s\r\n", reason);
    cleanup();
    exit(0);
  }
  if( 0 == stat(".nopost", &st) )posting_ok = 0;
  else if( getenv("POSTING_OK") )posting_ok = 1;
  else posting_ok = 0;
  openfifo();
  checkservice = 0;
}

static void
init(void)
{
  struct sigaction sa;

  if( -1 == chdir(snroot) )
    FAIL(2, "chdir(%s):%m", snroot);
  dh_open(0, 0);
  if( -1 == group_init() ){ dh_close(); exit(2); }
  client_ip = getenv("TCPREMOTEIP");
  me = myname();
  sa.sa_handler = handler;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_RESTART;
  sa.sa_restorer = 0;
  sigaction(SIGHUP, &sa, NULL);
  sa.sa_handler = SIG_IGN;
  sigaction(SIGPIPE, &sa, NULL);

  docheckservice();
}

static int
alphabetically(const void * a, const void * b)
{
  return(strcmp(*(char **)a, *(char **)b));
}

static int
getallgroups(void)
{
  if( ! (allgroups = group_all(&nrgroups)) )return(-1);
  if( nrgroups > 1 )
    qsort(allgroups, nrgroups, sizeof(char *), alphabetically);
  return(0);
}

static void usage(void) { fail(1, "Usage:%s [-t timeout]", progname); }

int
main(int argc, char ** argv)
{
  int i;
  char * cp;
  int tmo = 600;

  progname = ((cp = strrchr(argv[0], '/'))?cp + 1:argv[0]);

  parameters(1);

  while( (i = opt_get(argc, argv, "t")) > -1 )
    switch( i ){
    case 'P': log_with_pid(); break;
    case 'd': debug++; break;
    case 'V': version(); exit(0);
    case 't':
      if( ! opt_arg )fail(1, "Need value for \"t\"");
      if( (tmo = atoi(opt_arg)) < 0 )fail(1, "Timeout must be positive");
      break;
    default: usage();
    }

  if( opt_ind < argc )usage();

  if( -1 == readln_ready(0, tmo, &input) )FAIL(2, "readln_ready:%m");

  init();

  args[1] = "READER"; do_mode();

  /* Main loop */

  while( 1 ){
    int nr;
    switch( (nr = args_read(&input)) ){
    case 0: args_write(1, "501 Bad command\r\n"); continue;
    case -1: do_quit();  /* Does not return */
    }
    if( checkservice )
      docheckservice();  /* May not return */
    for(i = 0; i < sizeof(cmds)/sizeof(struct cmd); i++){
      if( strcasecmp(args[0], cmds[i].name) )continue;
      if( nr < cmds[i].needs_args )
        args_write(1, "501 Bad syntax\r\n");
      else if( cmds[i].needs_group && ! currentgroup )
        args_write(1, "412 No group selected\r\n");
      else if( cmds[i].needs_article && -1 == currentserial )
        args_write(1, "420 No article selected\r\n");
      else if( ! allgroups && cmds[i].needs_grouplist && -1 == getallgroups() )
        args_write(1, "503 No memory\r\n");
      else
        (*cmds[i].function)();
      break;
    }
    if( i >= sizeof(cmds)/sizeof(struct cmd) )
      args_write(1, "500 unimplemented\r\n");
  }
  /* Not Reached */
}
