#ifndef STATF_H
#define STATF_H
/*
 * This file is copyright Harold Tay (c) 1998 and is released under
 * the GNU General Public License version 2.  See file COPYING or
 * write to Free Software Foundation, Inc, 675 Mass Ave, Cambridge
 * MA, 02139, USA.
 */
struct stat;
extern int statf(struct stat * stp, char * fmt, ...);
#endif
