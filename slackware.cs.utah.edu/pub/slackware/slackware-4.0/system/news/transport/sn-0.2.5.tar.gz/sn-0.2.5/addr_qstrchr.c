/*
 * This file (addr_qstrchr.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */

char *
addr_qstrchr(char * str, int find)
{
  int bs, dq, cm;

  for(bs = dq = cm = 0; *str; str++)
    if( ! bs )
      if( ! cm )
        switch( *str ){
        case '"': dq = (! dq); break;
        case '\\': bs = 1; break;
        case '(': if( ! dq )cm = 1; break;
        default:
          if( dq || cm || (char)find != *str )break;
          return(str);
        }
      else{
        if( ! dq && ')' == *str )cm = 0; }
    else
      bs = 0;
  return(0);
}

