/*
 * This file (subscribed.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * When storing an article, check to see if that article is meant
 * for any newsgroups we have.
 */

#include <stdlib.h>
#include <string.h>
#include "config.h"

static const char rcsid[] = "$Id: subscribed.c,v 1.8 1999/03/06 10:09:52 harold Exp $";

struct bucket{
  struct bucket * next;
  char groupname[1];
};

static struct bucket * table[256];

static struct arena{
  struct arena * next;
  int avail;
  char * buf;
} * arenap = 0;

static struct bucket *
newbucket(char * group)
{
  struct arena * tmp;
  int len;
  struct bucket * b;

  len = sizeof(struct bucket) + strlen(group);
  len += (sizeof(b) - (len % sizeof(b)));
  if( ! arenap || len > arenap->avail ){
    int size;
    size = ((len>440)?len:440);
    if( ! (tmp = malloc(size + sizeof(struct arena))) )return(0);
    tmp->avail = size; tmp->buf = (char *)tmp + sizeof(struct arena);
    tmp->next = arenap; arenap = tmp;
  }
  b = (struct bucket *)arenap->buf;
  strcpy(b->groupname, group);
  arenap->buf += len; arenap->avail -= len;
  return(b);
}

static unsigned int
hash(char * buf)
{
  unsigned int h;
  int len = strlen(buf);

  h = 5381;
  while (len) {
    --len;
    h += (h << 5);
    h ^= (unsigned int) *buf++;
  }
  return(h%256);
}

int
subscribed_init(char ** groups, int nrgroups)
{
  int i;

  for(i = 0; i < 256; i++)table[i] = 0;
  for(i = 0; i < nrgroups; i++){
    unsigned h;
    struct bucket * b;
    if( ! groups[i] )continue;
    if( ! (b = newbucket(groups[i])) )return(-1);
    h = hash(groups[i]);
    b->next = table[h];
    table[h] = b;
  }
  return(0);
}

int
subscribed(char * group)
{
  unsigned h;
  struct bucket * b;
  h = hash(group);
  for(b = table[h]; b; b = b->next)
    if( 0 == strcmp(group, b->groupname) )
      return(1);
  return(0);
}

void
subscribed_fin(void)
{
  struct arena * tmp;
  while( arenap ){ tmp = arenap->next; free(arenap); arenap = tmp; }
}
