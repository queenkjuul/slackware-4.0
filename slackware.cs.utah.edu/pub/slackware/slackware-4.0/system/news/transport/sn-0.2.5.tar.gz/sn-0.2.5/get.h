#ifndef GET_H
#define GET_H
/*
 * This file (get.h) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#define MAX_CONCURRENCY 8

extern char *optdebug;
extern char *optpipelining;
extern char *opttimeout;
extern char *optoutfile;
extern char *optmax;
extern int optrnews;
extern int optlogpid;
extern int optnosockcache;
extern int throttlerate;
extern int concurrency;
#include <sys/types.h>
extern int throttle_setfds(fd_set *rs);
extern void throttle(fd_set *rs);
extern int reap(void);
extern int sow(void);
extern int sigchld;
extern int sigusr;
extern void init(void);
extern int add(char *group);
extern int jobs_not_done(void);
extern void quit(void);

#endif
