/*
 * This file (subscribed.h) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
extern int subscribed_init(char **groups, int nrgroups);
extern int subscribed(char *group);
extern void subscribed_fin(void);
