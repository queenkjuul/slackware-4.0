/*
 * This file (paramters.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <out.h>

static const char rcsid[] = "$Id: parameters.c,v 1.2 1999/02/21 10:25:12 harold Exp $";

char * snroot = SNROOT;
unsigned snuid;
unsigned sngid;

void
parameters(int wantwriteperms)
{
  struct stat st;

  if( ! (snroot = getenv("SN_NEWS_SPOOL")) )
    if( ! (snroot = getenv("SNROOT")) )
      snroot = SNROOT;

  if( -1 == stat(snroot, &st) )
    fail(2, "Can't find \"%s\":%m");
  if( ! S_ISDIR(st.st_mode) )
    fail(2, "%s is not a directory");
  snuid = st.st_uid;
  sngid = st.st_gid;
  if( 0 == geteuid() ){
    setgid(sngid);
    setuid(snuid);
  }

  if( wantwriteperms )
    if( snuid != getuid() || sngid != getgid() )
      fail(2, "Can't write in %s", snroot);
}
