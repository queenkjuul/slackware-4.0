/*
  Parse email addresses, or fragments thereof.  addr_domain() also
  used to verify legal newsgroup names.  addr_qstrchr() like
  strchr() but ignores comments and quoted strings.
 */
extern int addr_addrspec(char *buf);
extern int addr_domain(char *buf);
extern int addr_localpart(char *buf);
extern char *addr_qstrchr(char *str, int find);
extern int addr_unescape(char *from, char *to, int len);
