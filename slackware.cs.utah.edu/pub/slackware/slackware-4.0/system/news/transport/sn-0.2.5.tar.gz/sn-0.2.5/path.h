/*
  Ensure PATH environment variable contains BINDIR.
 */
extern int set_path_var(void);
