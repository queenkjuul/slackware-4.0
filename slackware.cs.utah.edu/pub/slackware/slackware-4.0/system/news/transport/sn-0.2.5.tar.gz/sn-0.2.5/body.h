/*
 * This file (body.h) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
#ifndef BODY_H
#define BODY_H

#ifndef USE_ZLIB
static const char body_[] = "Not compiled with ZLIB";
#define body(foo,bar) 0
#else
#include <zconf.h>
#include <zlib.h>
static const char body_[] = "Compiled with ZLIB_VERSION=" ZLIB_VERSION ;
extern int body(char **artbod, int *len);
#endif /* USE_ZLIB */
#endif
