/*
 * This file (store.c) is part of the sn package.
 * Distribution of sn is covered by the GPL. See file COPYING.
 * sn is copyright (c) 1998 Harold Tay.
 */
/*
 * Back end of snstore.
 * How it works: Every time an article is to be stored, we find the
 * next available slot to use, lock the fd, write the head and
 * the body, update the info, and
 * unlock.  If the file is full, we reorder the file by writing a
 * new file and copying the heads, then the bodies.  Reordering is
 * done from a call to cache_invalidate() which calls sto_free().
 * This way, we are almost always guaranteed a valid article file,
 * even if the arrangement is sub-optimal.
 */

#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <dirent.h>
#include <ctype.h>
#include <limits.h>
#include <time.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/file.h>
#include "config.h"
#include "times.h"
#include "art.h"
/* Shut up compiler messages about discarding volatile */
#undef VOLATILE
#define VOLATILE /* nothing */
#include "artfile.h"
#include "cache.h"
#include "group.h"
#include <out.h>
#include <format.h>
#include <openf.h>
#include <nap.h>

static const char rcsid[] = "$Id: store.c,v 1.29 1999/03/27 05:27:24 harold Exp $";
#ifdef USE_ZLIB
#include "body.h"
#endif

extern int rename(const char * old, const char * new);

struct storeobj{
  char * newsgroup;
  int filename;
  int compressok;
  int fd;
  struct file * file;
};

static int
sto_cmp(void * a, void * b)
{
  register struct storeobj * x = (struct storeobj *)a;
  register struct storeobj * y = (struct storeobj *)b;

  return(strcmp(x->newsgroup, y->newsgroup));
}

static int
nosigio(int (*op)(), int fd, char * buf, int len)
{
  int er;
  while( -1 == (er = (*op)(fd, buf, len)) )
    if( EINTR != errno ){ LOG1("nosigio:%m"); break; }
  return(er);
}

static int
copyart(int tofd, int fromfd, int fromseek, int len)
{
  char buf[1024];

  if( -1 == lseek(fromfd, fromseek, SEEK_SET) ){
    LOG("copyart:lseek:%m"); return(-1); }

  for(; len > 1024; len -= 1024)
    if( -1 == nosigio(read, fromfd, buf, 1024) ||
      -1 == nosigio(write, tofd, buf, 1024) )return(-1);
  if( -1 == nosigio(read, fromfd, buf, len) ||
    -1 == nosigio(write, tofd, buf, len) )return(-1);

  return(0);
}

/*
 * Convention: First one to create the file has it "locked".  It's
 * ok if we fail here, we can't do more damage than is already done.
 */

static void
reorder(struct storeobj * sp)
{
  char tmpname[GROUPNAMELEN + 32];
  char name[GROUPNAMELEN + 32];
  int fd;
  struct file f = {0,};
  int er;
  int i;

  formats(tmpname, sizeof(tmpname)-1, "%s/+%d",
    sp->newsgroup, sp->filename);
  fd = open(tmpname, O_RDWR|O_CREAT|O_EXCL, 0644);
  if( -1 == fd ){
    if( EEXIST != errno )LOG("reorder:open(%s):%m", tmpname);
    return;
  }

  f.magic = FILE_MAGIC;
  if( -1 == nosigio(write, fd, (char *)&f, sizeof(f)) )goto fail;

  for(i = 0; i < ARTSPERFILE; i++){
    if( sp->file->info[i].hoffset <= 0 ){
      LOG("reorder:bad hoffset(%d)", sp->file->info[i].hoffset); goto fail; }
    if( -1 == (f.info[i].hoffset = lseek(fd, 0, SEEK_END)) ){
      LOG("reorder:lseek:%m"); goto fail; }
    f.info[i].hlen = sp->file->info[i].hlen;
    er = copyart(fd, sp->fd, sp->file->info[i].hoffset, f.info[i].hlen);
    if( -1 == er )goto fail;
  }

  for(i = 0; i < ARTSPERFILE; i++){
    if( sp->file->info[i].boffset <= 0 ){
      LOG("reorder:bad boffset(%d)", sp->file->info[i].hoffset); goto fail; }
    if( -1 == (f.info[i].boffset = lseek(fd, 0, SEEK_END)) )goto fail;
    f.info[i].blen = sp->file->info[i].blen;
    er = copyart(fd, sp->fd, sp->file->info[i].boffset, f.info[i].blen);
    if( -1 == er )goto fail;
  }

  if( -1 == lseek(fd, 0, SEEK_SET) ){
    LOG("reorder:lseek:%m"); goto fail; }
  if( -1 == nosigio(write, fd, (char *)&f, sizeof(f)) )goto fail;
  formats(name, sizeof(name)-1, "%s/%d", sp->newsgroup, sp->filename);
  if( -1 == rename(tmpname, name) ){
    LOG("reorder:rename:%m"); goto fail; }
  close(fd);
  return;

fail:
  LOG("reorder:failed for %s/%d", sp->newsgroup, sp->filename);
  if( -1 == unlink(tmpname) )LOG("reorder:unlink(%s):%m");
  close(fd);
}

static void
sto_free(void * p)
{
  struct storeobj * sp = (struct storeobj *)p;

  /*
   * reorder only if all slots are filled, otherwise someone else
   * might try to write to it.
   */
  if( sp->file->info[ARTSPERFILE-1].hoffset > 0 )reorder(sp);
  close(sp->fd);

  if( -1 == munmap((caddr_t)sp->file, sizeof(struct file)) )
    LOG("sto_free:munmap:%m");
  free(sp);
}

static int
initializefile(int fd)
{
  struct stat st;
  struct file f = {0,};
  int er, i;

  if( -1 == fstat(fd, &st) )return(-1);
  if( st.st_size >= sizeof(f) )return(0);
  er = -1;
  for(i = 0; i < 10 && -1 == er; nap(0, 200), i++)
    if( (er = flock(fd, LOCK_EX|LOCK_NB)) > -1 ){
      if( (er = fstat(fd, &st)) > -1 )
        if( 0 == st.st_size ){
          f.magic = FILE_MAGIC;
          lseek(fd, 0, SEEK_SET);
          er = nosigio(write, fd, (char *)&f, sizeof(f));
        }else
          er = 0;
      flock(fd, LOCK_UN);
    }
  if( -1 == er )return(-1);
  return(0);
}

/*
 * Start at file 1 (article 10), not 0.  Thanks Marko.
 */

static int
findlast(char * newsgroup)
{
  DIR * dir;
  struct dirent * dp;
  int tmp;
  int last = 0;

  if( NULL == (dir = opendir(newsgroup)) ){
    LOG("findlast:opendir(%s):%m", newsgroup); return(-1); }
  while( (dp = readdir(dir)) )
    if( isdigit(*dp->d_name) )
      if( (tmp = atoi(dp->d_name)) > last )last = tmp;
  closedir(dir);
  return((0==last)?1:last);
}

/*
 * Return a storeobj (an article file structure) with at least one
 * free slot, creating and initializing the file if necessary.
 */

static struct storeobj *
sto_make(char * newsgroup)
{
  register struct storeobj * sp;
  int failures, len;

  len = strlen(newsgroup);
  sp = malloc(sizeof(struct storeobj) + len + 1);
  if( NULL == sp ){
    LOG("sto_make:malloc:%m"); return(NULL); }

  if( (sp->filename = findlast(newsgroup)) <= 0 ){
    free(sp); return(NULL); }
  sp->newsgroup = strcpy((char *)sp + sizeof(*sp), newsgroup);

  sp->compressok = 0;
#ifdef USE_ZLIB
  do{
    int fd;
    char buf[32];
    int i;
    fd = openf(0, O_RDONLY, "%s/.compress", newsgroup);
    if( -1 == fd )break;
    i = nosigio(read, fd, buf, sizeof(buf)-1); close(fd);
    if( -1 == i )break;
    if( i > 0 ){ buf[i] = '\0'; sp->compressok = atoi(buf); }
    if( sp->compressok < 1024 )sp->compressok = 1024;
  }while( 0 );
#endif

  for(failures = 0; ; failures++){
    int i;

    sp->fd = openf(0644, O_RDWR|O_CREAT, "%s/%d",
      newsgroup, sp->filename);
    if( sp->fd > -1 ){
      if( 0 == initializefile(sp->fd) ){
        sp->file = (struct file *)mmap(0, sizeof(struct file),
          PROT_READ|PROT_WRITE, MAP_FILE|MAP_SHARED, sp->fd, 0);
        if( sp->file && (int)sp->file != -1 ){
          for(i = 0; i < ARTSPERFILE; i++)
            if( sp->file->info[i].hoffset <= 0 )
              return(sp);
          LOG3("sto_make:all slots filled in file %s/%d",
            newsgroup, sp->filename);
          sp->filename++;
          nap(0, 300);
          continue;
        }else
          log("sto_make:mmap(%s/%d):%m", newsgroup, sp->filename);
      }else
        log("sto_make:can't initialize new article file %s/%d:%m",
          newsgroup, sp->filename);
      close(sp->fd);
    }else
      log("sto_make:open(%s):%m", newsgroup);
    if( 10 == failures )
      LOG("sto_make:failed 10 times for %s", newsgroup);
    free(sp);
    return(NULL);
  }
}

static int desc;

/* We want a large cache, so we don't end up flushing it often. */

int
sto_init(void)
{
  desc = cache_init(8, sto_cmp, sto_free, NULL);
  if( -1 == desc )return(-1);
  return(0);
}

void
sto_fin(void)
{
  if( debug >= 3 ){
    int hit, miss;
    cache_stat(desc, &hit, &miss);
    LOG("sto_fin:cache requests:%dT=%dH+%dM", hit + miss, hit, miss);
  }
  cache_fin(desc);
}

/*
 * Only provides a -hint-.
 */

static struct storeobj *
findfreeslot(char * newsgroup, int * slotp)
{
  struct storeobj * sp;
  int slot;

  {
    struct storeobj s;
    s.newsgroup = newsgroup;
    sp = cache_find(desc, &s);
  }

  while( 1 ){
    if( NULL == sp ){
      sp = sto_make(newsgroup);
      if( NULL == sp )return(NULL);
      cache_insert(desc, sp);
    }

    for(slot = 0; slot < ARTSPERFILE; slot++)
      if( 0 == sp->file->info[slot].hoffset ){
        *slotp = slot; return(sp); }

    if( ARTSPERFILE == slot ){
      cache_invalidate(desc, sp); sp = NULL; }
  }
}

/*
 * New algorithm: Write the article immediately, never mind the
 * order.  When the last slot is filled in this file, sto_free()
 * will reorder them.  Then at all times we have a valid article
 * file that is readable, even if less than optimum.
 */

int
sto_add(char * newsgroup, struct article * ap)
{
  struct storeobj * sp;
  int slot;
  int failures;
  int er;
  struct info info;

  /* sp->file->info[] is volatile; we spin */

  for(failures = 0; failures < 10; nap(0, 400), failures++)
    if( (sp = findfreeslot(newsgroup, &slot)) )
      if( sp->file->info[slot].hoffset <= 0 )
        if( 0 == flock(sp->fd, LOCK_EX|LOCK_NB) )
          if( sp->file->info[slot].hoffset <= 0 )
            break;
          else
            flock(sp->fd, LOCK_UN);
        else{
          LOG3("sto_add:flock(%d):%m", sp->filename); }
      else{
        LOG3("sto_add:slot got filled!"); }
    else{
      LOG3("sto_add:no free slot"); }

  if( failures >= 10 ){
    LOG("sto_add:failed to add article to %s 10 times", newsgroup);
    return(-1);
  }

  /* Replace tabs, so art_makexover won't have to */
  {
    char * cp = ap->head;
    while( (cp = strchr(cp, '\t')) )*cp = ' ';
  }

  er = (int)(info.hoffset = lseek(sp->fd, 0, SEEK_END));
  if( er > -1 ){
    struct iovec iov[4];
    char * zbuf;

    info.hlen = ap->hlen + 2;
    info.boffset = info.hoffset + ap->hlen + 2;
    info.blen = ap->blen + 2;
    iov[0].iov_base = "";           iov[0].iov_len = 1;
    iov[1].iov_base = ap->head;     iov[1].iov_len = ap->hlen + 1;
    iov[2].iov_base = "";           iov[2].iov_len = 1;

    zbuf = 0;
    if( ap->body && ap->blen > 0 ){
#ifdef USE_ZLIB
      unsigned long zlen;
      if( sp->compressok && ap->blen > sp->compressok ){
        zlen = ap->blen + ap->blen/1000 + 13;
        if( (zbuf = malloc(zlen + COMPRESS_MAGIC_LEN)) ){
          memcpy(zbuf, COMPRESS_MAGIC, COMPRESS_MAGIC_LEN);
          er = compress((unsigned char *)zbuf + COMPRESS_MAGIC_LEN,
            &zlen, (unsigned char *)ap->body, (unsigned)ap->blen);
          if( Z_OK != er ){
            LOG1("sto_add:compression failed on %s:%d, \"Z_%s_ERROR\"",
              newsgroup, (sp->filename * ARTSPERFILE) + slot,
                (Z_BUF_ERROR==er)?"BUF"
                  :((Z_MEM_ERROR==er)?"MEM":"[unknown]"));
            free(zbuf);
            zbuf = 0;
          }else
            zbuf[zlen + COMPRESS_MAGIC_LEN] = '\0';
        }else
          log("sto_add:No memory to compress");
      }
      if( zbuf ){
        iov[3].iov_base = zbuf;
        iov[3].iov_len = zlen + 1 + COMPRESS_MAGIC_LEN;
      }else
#endif
      {
        iov[3].iov_base = ap->body;
        iov[3].iov_len = ap->blen + 1;
      }
    }else{
      iov[3].iov_base = "";
      iov[3].iov_len = 1;
    }
    info.blen = iov[3].iov_len + 1;

    if( (er = nosigio(writev, sp->fd, (char *)iov, 4)) > -1 ){
      sp->file->info[slot] = info;
      er = (sp->filename * ARTSPERFILE) + slot;
    }else
      log("sto_add:writev(%s/%d):%m", newsgroup, sp->filename);
    if( zbuf )free(zbuf);
  }else
    log("sto_add:lseek(%s/%d):%m", newsgroup, sp->filename);

  flock(sp->fd, LOCK_UN);
  if( slot == ARTSPERFILE-1 )cache_invalidate(desc, sp);
  return(er);
}
