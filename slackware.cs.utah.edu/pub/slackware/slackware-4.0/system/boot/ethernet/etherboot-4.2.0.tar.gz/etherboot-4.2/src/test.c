/**************************************************************************
ETHERBOOT -  BOOTP/TFTP Bootstrap Test Program

Prints a prompt, gets a reply and searches for adapter

Author: Ken Yap
  Date: June 96

**************************************************************************/

#include "etherboot.h"

/**************************************************************************
MAIN - Kick off routine
**************************************************************************/
int main()
{
	char *p;
	for (p=_edata; p<_end; p++) *p = 0;	/* Zero BSS */
	while (1) {
		int c;
		printf("Boot from Network (Y/N)? ");
		c = getchar();
		if ((c >= 'a') && (c <= 'z')) c &= 0x5F;
		if (c == '\r') break;
		putchar(c);
		if (c == 'N')
			exit(0);
		if (c == 'Y')
			break;
		printf(" - bad response\r\n");
	}
	gateA20();
#ifdef	ETHERBOOT32
	printf("Etherboot test version " VERSION "\r\nSearching for adapter...");
#endif
#ifdef	ETHERBOOT16
/* bcc still doesn't do ANSI string concatenation so this is hardwired */
	printf("Etherboot test version 3.2\r\nSearching for adapter...");
#endif
	if (!eth_probe())
		printf("No adapter found\r\n");
	return (0);
}

/**************************************************************************
CONVERT_IPADDR - Convert IP address from net to machine order
**************************************************************************/
void convert_ipaddr(d, s)
	register char *d,*s;
{
	*(d+3) = *s;
	*(d+2) = *(s+1);
	*(d+1) = *(s+2);
	*d     = *(s+3);
}
/*
 * Local variables:
 *  c-basic-offset: 8
 * End:
 */

