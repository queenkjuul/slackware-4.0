/**************************************************************************
Etherboot -  BOOTP/TFTP Bootstrap Program
Skeleton NIC driver for Etherboot
***************************************************************************/

/* to get some global routines like printf */
#include "etherboot.h"
/* to get the interface to the body of the program */
#include "nic.h"

/* NIC specific static variables go here */

/**************************************************************************
RESET - Reset adapter
***************************************************************************/
static void skel_reset(struct nic *nic)
{
	/* put the card in its initial state */
}

/**************************************************************************
POLL - Wait for a frame
***************************************************************************/
static int skel_poll(struct nic *nic)
{
	/* return true if there's an ethernet packet ready to read */
}

/**************************************************************************
TRANSMIT - Transmit a frame
***************************************************************************/
static void skel_transmit(
struct nic *nic,
char *d,			/* Destination */
unsigned int t,			/* Type */
unsigned int s,			/* size */
char *p)			/* Packet */
{
	/* send the packet to destination */
}

/**************************************************************************
DISABLE - Turn off ethernet interface
***************************************************************************/
static void skel_disable(struct nic *nic)
{
}

/**************************************************************************
PROBE - Look for an adapter, this routine's visible to the outside
***************************************************************************/
struct nic *skel_probe(struct nic *nic, unsigned short *probe_addrs)
{
	/* if probe_addrs is 0, then routine can use a hardwired default */
	/* if board found */
	{
		/* point to NIC specific routines */
		nic->reset = skel_reset;
		nic->poll = skel_poll;
		nic->transmit = skel_transmit;
		nic->disable = skel_disable;
		return nic;
	}
	/* else */
	{
		return 0;
	}
}
