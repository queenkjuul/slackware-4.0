#ifndef __LINUXDEF_H__
#define __LINUXDEF_H__

#ifdef	__linux
#define	ETHERBOOT32
#include <asm/byteorder.h>
#include <asm/io.h>
#define	_edata	edata			/* ELF does not prepend a _ */
#define	_end	end
#endif

#ifdef	__BCC__
#define	ETHERBOOT16
#define	inline
#define	const
#define	volatile
#define	setjmp	_setjmp		/* they are that way in libc.a */
#define	longjmp	_longjmp

/* BCC include files are missing these. */
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;
#endif

#define	OUTB(p,v)	outb(v,p)
#define	OUTB_P(p,v)	outb_p(v,p)
#define	OUTW(p,v)	outw(v,p)

typedef	unsigned long Address;

/* ANSI prototyping macro */
#ifdef	__STDC__
#define	P(x)	x
#else
#define	P(x)	()
#endif

#endif

/*
 * Local variables:
 *  c-basic-offset: 8
 * End:
 */
