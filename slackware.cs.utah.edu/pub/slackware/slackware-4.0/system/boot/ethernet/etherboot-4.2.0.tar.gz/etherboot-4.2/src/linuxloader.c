/**************************************************************************
Linux loader

Author: Markus Gutschke (gutschk@math.uni-muenster.de)
  Date: Sep/95

**************************************************************************/

#include "etherboot.h"
#include "config.h"

/* Define some structures used by tftp loader */

union infoblock
{
	unsigned short s[256];
	unsigned long l[128];
	struct imgheader
	{
		unsigned long magic;
		unsigned char length;
		unsigned char r[3];
		struct { unsigned short bx, ds; } location;
		struct { unsigned short ip, cs; } execaddr;
	} i;
};

struct segheader
{
	unsigned char length;
	unsigned char vendortag;
	unsigned char reserved;
	unsigned char flags;
	unsigned long loadaddr;
	unsigned long imglength;
	unsigned long memlength;
};

/* The following are static because linux_tftp is called for each block
   and we need to retain info across calls */

static unsigned char	segflags;
static unsigned long	seglen;
static Address		curaddr, last0, last1, execaddr, hdraddr, segaddr;

int linux_tftp(unsigned int block, unsigned char *data, int len)
{
	int		i,j;

	if (block == 1)
	{
		union infoblock	*ibp = (union infoblock *)data;

		/* the apparently unnecessary cast is to avoid a
		   bcc bug where the short is not promoted as it should be */
		segaddr = (((Address)ibp->i.location.ds) << 4) + ibp->i.location.bx;
#ifdef	ETHERBOOT32
		bcopy(data, (void *)segaddr, 512);
#endif
#ifdef	ETHERBOOT16
		bcopyf(data, segaddr, 512);
#endif
		execaddr = ibp->l[3];
		hdraddr = ibp->l[2];
		last1 = last0 = segaddr + 512;
		segaddr += ((ibp->i.length & 0x0F) << 2)
			+ ((ibp->i.length & 0xF0) >> 2);
		segflags = 0;
		seglen = 0;
		if (len > 512) {
			len -= 512;
			data += 512;
			/* and fall through to deal with rest of block */
		} else
			return (1);
	}
	do {
		while (seglen == 0) {
			struct segheader	sh;
			if (segflags & 0x04) {
				/* reset card, so that the kernel can
				   probe for it */

#ifdef SIZEINDICATOR
				putchar('K');
#endif
#ifdef DELIMITERLINES
				putchar('\r');
				putchar('\n');
				for (j=0; j<80; j++) putchar('=');
				putchar('\r');
				putchar('\n');
#else
				printf("\r\n");
#endif
				
				eth_disable();
#ifdef ANSIESC
				ansi_reset();
#endif
#ifdef	ETHERBOOT32
				xstart(execaddr, hdraddr,
				       (Address)&bootp_data);
#endif
#ifdef	ETHERBOOT16
				xstart(execaddr, hdraddr,
				       &bootp_data, RELOC>>4);
#endif
				longjmp(jmp_bootmenu, 2);
			}
#ifdef	ETHERBOOT32
			sh = *((struct segheader *)segaddr);
#endif
#ifdef	ETHERBOOT16
			fbcopy(segaddr, &sh, sizeof(struct segheader));
#endif
			seglen = sh.imglength;
			if ((segflags = sh.flags & 0x03) == 0)
				curaddr = sh.loadaddr;
			else if (segflags == 0x01)
				curaddr = last1 + sh.loadaddr;
			else if (segflags == 0x02)
				curaddr = (Address)(memsize() * 1024L
						    + 0x100000L)
					- sh.loadaddr;
			else
				curaddr = last0 - sh.loadaddr;
			last1 = (last0 = curaddr) + sh.memlength;
			segflags = sh.flags;
			segaddr += ((sh.length & 0x0F) << 2)
				+ ((sh.length & 0xF0) >> 2);
		}
		i = (seglen > len) ? len : seglen;
#ifdef	ETHERBOOT32
		bcopy(data, (void *)curaddr, i);
#endif
#ifdef	ETHERBOOT16
		bcopyf(data, curaddr, i);
#endif
		seglen -= i;
		curaddr += i;
		len -= i;
		data += i;
	} while (len > 0);
	return (1);
}
/*
 * Local variables:
 *  c-basic-offset: 8
 * End:
 */
