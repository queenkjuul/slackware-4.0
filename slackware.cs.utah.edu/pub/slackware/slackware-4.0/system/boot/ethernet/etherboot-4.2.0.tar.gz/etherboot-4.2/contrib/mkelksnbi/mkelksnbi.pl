#!/usr/bin/perl

require 'bootsect.ph';

require 'config.ph';

# A program to create the netboot images for ELKS from the Image file

# These are defined by the bootrom layout
$headerseg = 0x9200;
$headersize = 512;

# This will probably never change
$bootsize = 512;

# These may need to be altered
$bootseg = 0x0200;
$setupseg = defined(DEF_SETUPSEG) ? &DEF_SETUPSEG : 0x0120;
$setupsize = 2048;	# 4x512 byte blocks
$setupmsize = 40448;	# maximum size of setup segment

$kernelseg = defined(DEF_SYSSEG) ? &DEF_SYSSEG : 0x1000;
$kernelmsize = defined(DEF_SYSSIZE) ? &DEF_SYSSIZE * 16 : 0x2F00 * 16;
# maximum size of kernel segment
# current length is computed by measuring the file size

# This is fixed for the current version of the netboot specs
# Note: reverse of the way it's in the specs because of Intel byte order
$magic = "\x36\x13\x03\x1B";

# This is needed at the end of the boot block, again byte reversed
$magic2 = "\x55\xAA";

# Don't change this
$tftpblocksize = 512;

$#ARGV >= 0 or die "Usage: $0 elksimage\n";
$imagesize = -s $ARGV[0];
defined($imagesize) or die "$ARGV[0]: $!\n";
$imagesize > $setupsize or die "$ARGV[0]: too short\n";
# Get the kernel size by subtracting the bootsize and the setupsize
$kernelsize = $imagesize - $bootsize - $setupsize;
$kernelsize <= $kernelmsize or die "$ARGV[0]: too large\n";
# Now open the image file
open(K, "$ARGV[0]") or die "$ARGV[0]: $!\n";

$header_string = &header("ELKS-mknbi");
$boot_string = &boot;
$setup_string = &setup;
$kernel_string = &kernel;
$used_length = length($header_string) + length($boot_string)
	+ length($setup_string) + length($kernel_string);
print $header_string, $boot_string, $setup_string, $kernel_string,
	"\0" x ($headersize - 2 - $used_length), $magic2;
# Copy the floppy boot block
$nread = read(K, $buffer, $bootsize);
defined($nread) or die "$ARGV[0]: cannot read bootblock portion\n";
# replace first N bytes with our bootsect
substr($buffer, 0, length($bootsect)) = $bootsect;
print $buffer;
# Now copy the setup portion
$nread = read(K, $buffer, $setupsize);
defined($nread) or die "$ARGV[0]: cannot read setup portion\n";
print $buffer;
# Now copy the kernel portion
# read whole file for now, we know it won't be very large for ELKS
$nread = read(K, $buffer, $kernelsize);
defined($nread) or die "$ARGV[0]: cannot read kernel portion\n";
print $buffer;
# Pad with nulls to next block boundary
$nread %= $tftpblocksize;
if ($nread != 0) { $nread = $tftpblocksize - $nread; }
print "\0" x $nread;

sub header {
	my ($vendor_info) = @_;

	$vi_len = length($vendor_info);
	$vi_len += 4;		# three plus one for null byte
	$vi_len &= ~0x3;	# round to multiple of 4
	# print "$vi_len\n";
	return pack("A4V3a$vi_len",
		$magic, ($vi_len << 2) + 4, $headerseg << 16, $bootseg << 16,
		$vendor_info);
}

sub boot {
# the 16 is added by mknbi and uses the vendor tag area
# it doesn't affect the boot process but we put it in
# so we can compare the images built with this program with those by mknbi
	return pack("V4",
		# not end, absolute address, no vendor info
		4 + (16 << 8),
		$bootseg << 4,
		$bootsize,
		$bootsize);
}

sub setup {
# the 17 is added by mknbi and uses the vendor tag area
# it doesn't affect the boot process but we put it in
# so we can compare the images built with this program with those by mknbi
	return pack("V4",
		# not end, absolute address, no vendor info
		4 + (17 << 8),
		$setupseg << 4,
		$setupsize,
		$setupmsize);
}

sub kernel {
# the 18 is added by mknbi and uses the vendor tag area
# it doesn't affect the boot process but we put it in
# so we can compare the images built with this program with those by mknbi
	return pack("V4",
		# end, absolute address, no vendor info
		4 + (18 << 8) + (1 << 26),
		$kernelseg << 4,
		&roundup($kernelsize),
		$kernelmsize);
}

sub roundup {
# Round up to next multiple of $tftpblocksize, assumes that it's a power of 2
	my ($size) = @_;
	return ($size + $tftpblocksize - 1) & ~($tftpblocksize - 1);
}
