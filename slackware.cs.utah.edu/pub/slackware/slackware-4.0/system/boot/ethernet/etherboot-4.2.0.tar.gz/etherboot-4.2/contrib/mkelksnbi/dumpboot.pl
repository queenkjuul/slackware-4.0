#!/usr/bin/perl

$#ARGV >= 0 or die "Usage: $0 bootsect\n";
$imagesize = -s $ARGV[0];
defined($imagesize) or die "$ARGV[0]: $!\n";
$imagesize > 32 or die "$ARGV[0]: too short\n";
# Now open the boot file
open(B, "$ARGV[0]") or die "$ARGV[0]: $!\n";

$nread = read(B, $bootsect, 497);
defined($nread) or die "$ARGV[0]: cannot read bootsect code\n";

# now write it out in hex
$hexstring = unpack("H*", $bootsect);
$hexstring =~ s/(..)/\\x$1/g;
print "\$bootsect = \"$hexstring\";\n";
