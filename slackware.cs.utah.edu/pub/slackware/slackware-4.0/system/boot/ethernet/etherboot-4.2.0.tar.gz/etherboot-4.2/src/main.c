/**************************************************************************
ETHERBOOT -  BOOTP/TFTP Bootstrap Program

Author: Martin Renters
  Date: Dec/93

**************************************************************************/

/* #define MDEBUG */

#include "etherboot.h"
#include "nic.h"

#include "config.h"

int	jmp_bootmenu[10];

struct arptable_t arptable[MAX_ARP];

char	*kernel;
char	kernel_buf[128];
struct rom_info rom;

#ifdef	IMAGE_MENU
char	*imagelist[RFC1533_VENDOR_NUMOFIMG];
int	useimagemenu;
int	menutmo,menudefault;
#endif
#ifdef	MOTD
char	*motd[RFC1533_VENDOR_NUMOFMOTD];
#endif
int     vendorext_isvalid;
char	config_buffer[TFTP_MAX_PACKET+1];	/* +1 for null byte */
unsigned long	netmask;
struct bootpd_t bootp_data;
unsigned long xid;
unsigned char   *end_of_rfc1533 = NULL;
#ifdef DHCP_SUPPORT
int dhcp_reply;
char dhcp_server[4]={0,0,0,0};
char dhcp_addr[4]={0,0,0,0};
#endif /* DHCP_SUPPORT */

unsigned char vendorext_magic[] = {0xE4,0x45,0x74,0x68}; /* �Eth */
#ifndef DHCP_SUPPORT
char    rfc1533_cookie[5] = { RFC1533_COOKIE, RFC1533_END };
#else
char    rfc1533_cookie[] = { RFC1533_COOKIE};
char    rfc1533_end[]={RFC1533_END };
char    dhcpdiscover[]={RFC2132_MSG_TYPE,1,DHCPDISCOVER,
			RFC2132_MAX_SIZE,2,2,64,
			RFC2132_PARAM_LIST,4,RFC1533_NETMASK,RFC1533_GATEWAY,
					    RFC1533_HOSTNAME,RFC1533_EXTENSIONPATH};
char    dhcprequest []={RFC2132_MSG_TYPE,1,DHCPREQUEST,
			RFC2132_SRV_ID,4,0,0,0,0,
			RFC2132_REQ_ADDR,4,0,0,0,0,
			RFC2132_MAX_SIZE,2,2,64,
			RFC2132_PARAM_LIST,4,RFC1533_NETMASK,RFC1533_GATEWAY,
					    RFC1533_HOSTNAME,RFC1533_EXTENSIONPATH};

#endif /* DHCP_SUPPORT */
char	broadcast[] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };

void sleep (int secs);

/**************************************************************************
MAIN - Kick off routine
**************************************************************************/
int main()
{
	char *p;
	static int card_retries = 0;
	int i;
#ifdef  DELIMITERLINES

	for (i=0; i<80; i++) putchar('=');
#endif
#ifdef	ETHERBOOT32
	for (p=_edata; p<_end ; p++)
		*p = 0;	/* Zero BSS */
	*(unsigned short *)0x472 = 0x1234;      /* signal warm boot */
	rom = *(struct rom_info *)ROM_INFO_LOCATION;
#endif
#ifdef	ETHERBOOT16
	for (p=_edata; p<_end; p++)
		*p = 0;	/* Zero BSS */
	fbcopy((Address)ROM_INFO_LOCATION, &rom, sizeof(rom));
#endif
	printf("ROM segment 0x%x length 0x%x\r\n", rom.rom_segment,
		rom.rom_length);
#ifdef ASK_BOOT
	while (1) {
		int c;
		unsigned long time;
		printf(ASK_PROMPT);
#if	ASK_BOOT > 0
		for (time = currticks() + ASK_BOOT*18; !iskey(); )
			if (currticks() > time) {
				c = ANS_DEFAULT;
				goto done;
			}	
#endif
		c = getchar();
		if ((c >= 'a') && (c <= 'z')) c &= 0x5F;
		if (c == '\r') c = ANS_DEFAULT;
done:
		if ((c >= ' ') && (c <= '~')) putchar(c);
		printf("\r\n");
		if (c == ANS_LOCAL)
			exit(0);
		if (c == ANS_NETWORK)
			break;
	}
#endif
	gateA20();
	print_config();
#ifdef EMERGENCYDISKBOOT
	if (!eth_probe()) {
		printf("No adapter found\r\n");
		exit(0);
	}
#else
	while (!eth_probe()) {
		printf("No adapter found");
		if (!setjmp(jmp_bootmenu))
			rfc951_sleep(++card_retries);
		printf("\r\n");	}
#endif
	kernel = DEFAULT_BOOTFILE;
	while (1) {
		if ((i = setjmp(jmp_bootmenu)) != 0) {
#ifdef ANSIESC
			ansi_reset();
#endif
			bootmenu(--i); }
		else
			load();
#ifdef ANSIESC
		ansi_reset();
#endif
	}
}

/**************************************************************************
LOADKERNEL - Try to load kernel image
**************************************************************************/
#ifndef FLOPPY
#define loadkernel(s)	tftp((s),tftpkernel)
#else
int loadkernel(char *fname)
{
	if (!bcmp(fname,"/dev/",5) && fname[6] == 'd') {
		int dev, part = 0;
		if (fname[5] == 'f') {
			if ((dev = fname[7] - '0') < 0 || dev > 3)
				goto nodisk; }
		else if (fname[5] == 'h') {
			if ((dev = 0x80 + fname[7] - 'a') < 0x80 || dev > 0x83)
				goto nodisk;
			if (fname[8]) {
				part = fname[8] - '0';
				if (fname[9])
					part = 10*part + fname[9] - '0'; }
			/* bootdisk cannot cope with more than eight partitions */
			if (part < 0 || part > 8)
				goto nodisk; }
		else
			goto nodisk;
		return(bootdisk(dev,part)); }
nodisk:
	return(tftp(fname,tftpkernel));
}
#endif

/**************************************************************************
LOAD - Try to get booted
**************************************************************************/
void load()
{
	static int bootp_completed = 0;
	char	*p,*q;
	char	cfg[64];
	int	root_nfs_port;
	int	root_mount_port;
	int	swap_nfs_port;
	int	swap_mount_port;
	char	kernel_handle[32];
	char	cmd_line[80];
	int	err, offset, read_size;
	long	addr, broadcast;
	/* Initialize this early on */

	/* Find a server to get BOOTP reply from */
	if (!bootp_completed ||
	    !arptable[ARP_CLIENT].ipaddr || !arptable[ARP_SERVER].ipaddr) {
		printf("Searching for server...\r\n");
#ifdef RARP_NOT_BOOTP
		if (!rarp()) {
#else
		if (!bootp()) {
#endif
			printf("No Server found\r\n");
#ifdef EMERGENCYDISKBOOT
			exit(0);
#endif
		}
		bootp_completed++;
	}
	printf("My IP %I, Server IP %I, GW IP %I\r\n",
		arptable[ARP_CLIENT].ipaddr,
		arptable[ARP_SERVER].ipaddr,
		arptable[ARP_GATEWAY].ipaddr);

#ifdef MDEBUG
	printf("\n=>>"); getchar();
#endif

#ifdef MOTD
	if (vendorext_isvalid)
		show_motd();
#endif
	/* Now use TFTP to load file */
#ifdef IMAGE_MENU
	if (vendorext_isvalid && useimagemenu) {
		selectImage(imagelist);
		bootp_completed = 0;
	}
#endif
	for (;;) {
#ifdef SIZEINDICATOR
		printf("Loading %s... XXXX",kernel);
#else
		printf("Loading %s... ",kernel);
#endif
		while (!loadkernel(kernel))
			printf("Unable to load file.\r\n");
	}
}

/**************************************************************************
DEFAULT_NETMASK - Set a default netmask for IP address
**************************************************************************/
void default_netmask()
{
	int net = arptable[ARP_CLIENT].ipaddr >> 24;
	if (net <= 127)
		netmask = htonl(0xff000000);
	else if (net < 192)
		netmask = htonl(0xffff0000);
	else
		netmask = htonl(0xffffff00);
}

/**************************************************************************
UDP_TRANSMIT - Send a UDP datagram
**************************************************************************/
int udp_transmit(destip, srcsock, destsock, len, buf)
	unsigned long destip;
	unsigned int srcsock, destsock;
	int len;
	char *buf;
{
	struct iphdr *ip;
	struct udphdr *udp;
	struct arprequest arpreq;
	int arpentry, i;
	int retry;

	ip = (struct iphdr *)buf;
	udp = (struct udphdr *)(buf + sizeof(struct iphdr));
	ip->verhdrlen = 0x45;
	ip->service = 0;
	ip->len = htons(len);
	ip->ident = 0;
	ip->frags = 0;
	ip->ttl = 60;
	ip->protocol = IP_UDP;
	ip->chksum = 0;
	convert_ipaddr(ip->src, (char *)&arptable[ARP_CLIENT].ipaddr);
	convert_ipaddr(ip->dest, (char *)&destip);
	ip->chksum = ipchksum((unsigned short *)buf, sizeof(struct iphdr));
	udp->src = htons(srcsock);
	udp->dest = htons(destsock);
	udp->len = htons(len - sizeof(struct iphdr));
	udp->chksum = 0;
	if (destip == IP_BROADCAST) {
		eth_transmit(broadcast, IP, len, buf);
	} else {
		long h_netmask = ntohl(netmask);
				/* Check to see if we need gateway */
		if (((destip & h_netmask) !=
			(arptable[ARP_CLIENT].ipaddr & h_netmask)) &&
			arptable[ARP_GATEWAY].ipaddr)
				destip = arptable[ARP_GATEWAY].ipaddr;
		for(arpentry = 0; arpentry<MAX_ARP; arpentry++)
			if (arptable[arpentry].ipaddr == destip) break;
		if (arpentry == MAX_ARP) {
			printf("%I is not in my arp table!\r\n", destip);
			return(0);
		}
		for (i = 0; i<ETHER_ADDR_SIZE; i++)
			if (arptable[arpentry].node[i]) break;
		if (i == ETHER_ADDR_SIZE) {	/* Need to do arp request */
			arpreq.hwtype = htons(1);
			arpreq.protocol = htons(IP);
			arpreq.hwlen = ETHER_ADDR_SIZE;
			arpreq.protolen = 4;
			arpreq.opcode = htons(ARP_REQUEST);
			bcopy(arptable[ARP_CLIENT].node, arpreq.shwaddr,
				ETHER_ADDR_SIZE);
			convert_ipaddr(arpreq.sipaddr,
				(char *)&arptable[ARP_CLIENT].ipaddr);
			bzero(arpreq.thwaddr, ETHER_ADDR_SIZE);
			convert_ipaddr(arpreq.tipaddr, (char *)&destip);
			for (retry = 0; retry < MAX_ARP_RETRIES;
			     rfc951_sleep(++retry)) {
				eth_transmit(broadcast, ARP, sizeof(arpreq),
					(char *)&arpreq);
				if (await_reply(AWAIT_ARP, arpentry,
					arpreq.tipaddr, 0)) goto xmit;
			}
			return(0);
		}
xmit:		eth_transmit(arptable[arpentry].node, IP, len, buf);
	}
	return(1);
}

/**************************************************************************
TFTPKERNEL - Try to load file
**************************************************************************/
int tftpkernel(data, block, len, eof)
	unsigned char	*data;
	int		block, len, eof;
{
#ifdef SIZEINDICATOR
	static int rlen = 0;

	if (!(block % 4) || eof) {
		int size;
		size = ((block-1) * rlen + len) / 1024;

		putchar('\b');
		putchar('\b');
		putchar('\b');
		putchar('\b');
			
		putchar('0' + (size/1000)%10);
		putchar('0' + (size/100)%10);
		putchar('0' + (size/10)%10);
		putchar('0' + (size/1)%10);
	}
#endif
	if (block == 1)
	{
#ifdef SIZEINDICATOR
		rlen=len;
#endif
		if (!eof &&
		    (((unsigned short *)data)[255] == 0xAA55 ||
		     *((unsigned long *)data) == 0x1B031336l))
		{
			;
		}
		else if (eof)
		{
			bcopy(data, config_buffer, len);
			config_buffer[len] = 0;
			return (1); /* done */
		}
		else
		{
			printf("error: not a tagged image\r\n");
			return(0); /* error */
		}
	}
	if (!linux_tftp(block, data, len))
		return(0); /* error */
	if (eof) {
		linux_tftp(block+1, data, 0); /* does not return */
		return(0); /* error */ }
	return(-1); /* there is more data */
}

/**************************************************************************
TFTP - Download extended BOOTP data, or kernel image
**************************************************************************/
int tftp(name,fnc)
	char           *name;
	int	       (*fnc)(unsigned char *, int, int, int);
{
	int             retry = 0;
	static unsigned short isocket = 2000;
	unsigned short  osocket;
	unsigned short  len, block = 0, prevblock = 0;
	struct tftp_t  *tr;
	struct tftp_t   tp;
	int		rc;
	int		packetsize = TFTP_DEFAULTSIZE_PACKET;

	tp.opcode = htons(TFTP_RRQ);
	len = (sprintf((char *)tp.u.rrq, "%s%coctet%cblksize%c%d",
		       name, 0, 0, 0, TFTP_MAX_PACKET) - ((char *)&tp)) + 1;
	if (!udp_transmit(arptable[ARP_SERVER].ipaddr, ++isocket, TFTP,
		len, (char *)&tp))
		return (0);
	for (;;)
	{
#ifdef	TFTP_TIMEOUT
		if (!await_reply(AWAIT_TFTP, isocket, NULL, (block ? TFTP_REXMT : 0)))
#else
		if (!await_reply(AWAIT_TFTP, isocket, NULL, 0))
#endif
		{
			if (!block && retry++ < MAX_TFTP_RETRIES)
			{	/* maybe initial request was lost */
				rfc951_sleep(retry);
				if (!udp_transmit(arptable[ARP_SERVER].ipaddr,
					++isocket, TFTP, len, (char *)&tp))
					return (0);
				continue;
			}
#ifdef	TFTP_TIMEOUT
			if (block && ((retry += TFTP_REXMT) < TFTP_TIMEOUT))
			{	/* we resend our last ack */
#ifdef MDEBUG
				printf("<REXMT>\r\n");
#endif
				udp_transmit(arptable[ARP_SERVER].ipaddr,
					isocket, osocket,
					TFTP_MIN_PACKET, (char *)&tp);
				continue;
			}
#endif
			break;	/* timeout */
		}
		tr = (struct tftp_t *)&nic.packet[ETHER_HDR_SIZE];
		if (tr->opcode == ntohs(TFTP_ERROR))
		{
			printf("TFTP error %d (%s)\r\n",
			       ntohs(tr->u.err.errcode),
			       tr->u.err.errmsg);
			break;
		}

		if (tr->opcode == ntohs(TFTP_OACK)) {
			char *p = tr->u.oack.data, *e;

			if (prevblock)		/* shouldn't happen */
				continue;	/* ignore it */
			len = ntohs(tr->udp.len) - sizeof(struct udphdr) - 2;
			if (len > TFTP_MAX_PACKET)
				goto noak;
			e = p + len;
			while (*p != '\000' && p < e) {
				if (!strcasecmp("blksize", p)) {
					p += 8;
					if ((packetsize = getdec(&p)) <
					    TFTP_DEFAULTSIZE_PACKET)
						goto noak;
					while (p < e && *p) p++;
					if (p < e)
						p++;
				}
				else {
				noak:
					tp.opcode = htons(TFTP_ERROR);
					tp.u.err.errcode = 8;
					len = (sprintf((char *)tp.u.err.errmsg,
						       "RFC1782 error")
					       - ((char *)&tp)) + 1;
					udp_transmit(arptable[ARP_SERVER].
						     ipaddr, isocket,
						     ntohs(tr->udp.src),
						     len, (char *)&tp);
					return (0);
				}
			}
			if (p > e)
				goto noak;
			block = tp.u.ack.block = 0; /* this ensures, that */
						/* the packet does not get */
						/* processed as data! */
		}
		else if (tr->opcode == ntohs(TFTP_DATA)) {
			len = ntohs(tr->udp.len) - sizeof(struct udphdr) - 4;
			if (len > packetsize)	/* shouldn't happen */
				continue;	/* ignore it */
			block = ntohs(tp.u.ack.block = tr->u.data.block); }
		else /* neither TFTP_OACK nor TFTP_DATA */
			break;
		
		if (block && (block != prevblock+1))	/*  Block order */
			tp.u.ack.block = htons(block = prevblock);
						/* should be continuous */
		tp.opcode = htons(TFTP_ACK);
		osocket = ntohs(tr->udp.src);
		udp_transmit(arptable[ARP_SERVER].ipaddr, isocket,
			osocket, TFTP_MIN_PACKET, (char *)&tp);	/* ack */
		if (block <= prevblock)		/* retransmission or OACK */
			continue;		/* don't process */
		prevblock = block;
		retry = 0;	/* It's the right place to zero the timer? */
		if ((rc = fnc(tr->u.data.download,
			      block, len, len < packetsize)) >= 0)
			return(rc);
		if (len < packetsize)		/* End of data */
			return (1);
	}
	return (0);
}

#ifdef RARP_NOT_BOOTP
/**************************************************************************
RARP - Get my IP address and load information
**************************************************************************/
int rarp()
{
   int retry;

   /* arp and rarp requests share the same packet structure. */
   struct arprequest rarpreq;

   printf("Using RARP\r\n");

	bzero(&rarpreq, sizeof(rarpreq));

   rarpreq.hwtype = htons(1);
	rarpreq.protocol = htons(IP);
	rarpreq.hwlen = ETHER_ADDR_SIZE;
	rarpreq.protolen = 4;
	rarpreq.opcode = htons(RARP_REQUEST);
   bcopy(arptable[ARP_CLIENT].node, &rarpreq.shwaddr, ETHER_ADDR_SIZE);
   /* sipaddr is already zeroed out */
   bcopy(arptable[ARP_CLIENT].node, &rarpreq.thwaddr, ETHER_ADDR_SIZE);
   /* tipaddr is already zeroed out */

	for (retry = 0; retry < MAX_ARP_RETRIES; rfc951_sleep(++retry))
   {
	  eth_transmit(broadcast, RARP, sizeof(rarpreq), (char *)&rarpreq);

	  if (await_reply(AWAIT_RARP, 0, rarpreq.shwaddr, 0))
        break;
   }

   if (retry < MAX_ARP_RETRIES)
   {
	   arptable[ARP_CLIENT].ipaddr = ntohl(arptable[ARP_CLIENT].ipaddr);
	   arptable[ARP_SERVER].ipaddr = ntohl(arptable[ARP_SERVER].ipaddr);
    	arptable[ARP_GATEWAY].ipaddr = ntohl(arptable[ARP_GATEWAY].ipaddr);

      sprintf(kernel = kernel_buf, "/tftpboot/kernel.%I", arptable[ARP_CLIENT].ipaddr);

      return (1);
   }
      return (0);
}

#else

/**************************************************************************
BOOTP - Get my IP address and load information
**************************************************************************/
int bootp()
{
	int retry;
#ifdef DHCP_SUPPORT
	int retry1;
#endif /* DHCP_SUPPORT */
	struct bootp_t bp;
	unsigned long  starttime;
#ifdef T509HACK
	int flag;

	flag = 1;
#endif
	bzero(&bp, sizeof(struct bootp_t));
	bp.bp_op = BOOTP_REQUEST;
	bp.bp_htype = 1;
	bp.bp_hlen = ETHER_ADDR_SIZE;
	bp.bp_xid = xid = starttime = currticks();
	bcopy(arptable[ARP_CLIENT].node, bp.bp_hwaddr, ETHER_ADDR_SIZE);
#ifndef DHCP_SUPPORT
	bcopy(rfc1533_cookie, bp.bp_vend, 5); /* request RFC-style options */
#else
	bcopy(rfc1533_cookie, bp.bp_vend, sizeof rfc1533_cookie); /* request RFC-style options */
	bcopy(dhcpdiscover, bp.bp_vend+sizeof rfc1533_cookie,sizeof dhcpdiscover); 
	bcopy(rfc1533_end, bp.bp_vend+sizeof rfc1533_cookie +sizeof dhcpdiscover,sizeof rfc1533_end); 
#endif /* DHCP_SUPPORT */
	
	for (retry = 0; retry < MAX_BOOTP_RETRIES; ) {
		udp_transmit(IP_BROADCAST, 0, BOOTP_SERVER,
			sizeof(struct bootp_t), (char *)&bp);
#ifdef T509HACK
		if (flag) { 
			flag--;
		} else {
			if (await_reply(AWAIT_BOOTP, 0, NULL, 0))
				return(1);
			rfc951_sleep(++retry);

		}
#else
#ifndef DHCP_SUPPORT
		if (await_reply(AWAIT_BOOTP, 0, NULL, 0))
#else
		if (await_reply(AWAIT_BOOTP, 0, NULL, 0)){
			if (dhcp_reply==DHCPOFFER){
	dhcp_reply=0;		
	bcopy(rfc1533_cookie, bp.bp_vend, sizeof rfc1533_cookie); 
	bcopy(dhcprequest, bp.bp_vend+sizeof rfc1533_cookie,sizeof dhcprequest); 
	bcopy(rfc1533_end, bp.bp_vend+sizeof rfc1533_cookie +sizeof dhcprequest,sizeof rfc1533_end); 
	bcopy(dhcp_server,bp.bp_vend+9,4);
	bcopy(dhcp_addr,bp.bp_vend+15,4);
        	for (retry1 = 0; retry < MAX_BOOTP_RETRIES;) {
		udp_transmit(IP_BROADCAST, 0, BOOTP_SERVER,
			sizeof(struct bootp_t), (char *)&bp);
			dhcp_reply=0;
			if (await_reply(AWAIT_BOOTP, 0, NULL, 0))
			  if (dhcp_reply==DHCPACK) return(1);
			 rfc951_sleep(++retry1); 
			}
			} else
#endif /* DHCP_SUPPORT */
			return(1);
#ifdef DHCP_SUPPORT
		}
		rfc951_sleep(++retry);		
	
#endif /* DHCP_SUPPORT */
#endif
		bp.bp_secs = htons((currticks()-starttime)/20);
	}
	return(0);
}
#endif	/* RARP_NOT_BOOTP */

/**************************************************************************
AWAIT_REPLY - Wait until we get a response for our request
**************************************************************************/
int await_reply(type, ival, ptr, timeout)
	int type, ival, timeout;
	char *ptr;
{
	unsigned long time;
	struct	iphdr *ip;
	struct	udphdr *udp;
	struct	arprequest *arpreply;
	struct	bootp_t *bootpreply;
	struct	rpc_t *rpc;
	unsigned short ptype;

	int	protohdrlen = ETHER_HDR_SIZE + sizeof(struct iphdr) +
				sizeof(struct udphdr);
#ifdef	TFTP_TIMEOUT
	time = currticks() + (timeout ? timeout : TIMEOUT);
#else
	time = currticks() + TIMEOUT;
#endif
	while(time > currticks()) {
		if (iskey() && (getchar() == ESC)) longjmp(jmp_bootmenu,1);
		if (eth_poll()) {	/* We have something! */
					/* Check for ARP - No IP hdr */
			if (nic.packetlen >= ETHER_HDR_SIZE) {
				ptype = ((unsigned short) nic.packet[12]) << 8
					| ((unsigned short) nic.packet[13]);
			} else continue; /* what else could we do with it? */
			if ((nic.packetlen >= ETHER_HDR_SIZE +
				sizeof(struct arprequest)) &&
			   (ptype == ARP) ) {
				unsigned long tmp;

				arpreply = (struct arprequest *)
					&nic.packet[ETHER_HDR_SIZE];
				if ((arpreply->opcode == ntohs(ARP_REPLY)) &&
				   !bcmp(arpreply->sipaddr, ptr, 4) &&
				   (type == AWAIT_ARP)) {
					bcopy(arpreply->shwaddr,
						arptable[ival].node,
						ETHER_ADDR_SIZE);
					return(1);
				}
				convert_ipaddr((char *)&tmp,arpreply->tipaddr);
				if ((arpreply->opcode == ntohs(ARP_REQUEST)) &&
					(tmp == arptable[ARP_CLIENT].ipaddr)) {
					arpreply->opcode = htons(ARP_REPLY);
					bcopy(arpreply->sipaddr,
						arpreply->tipaddr, 4);
					bcopy(arpreply->shwaddr,
						arpreply->thwaddr,
						ETHER_ADDR_SIZE);
					convert_ipaddr(arpreply->sipaddr,
						(char *)&arptable[ARP_CLIENT].ipaddr);
					bcopy(arptable[ARP_CLIENT].node,
						arpreply->shwaddr,
						ETHER_ADDR_SIZE);
					eth_transmit(arpreply->thwaddr, ARP,
						sizeof(struct  arprequest),
						(char *)arpreply);
#ifdef MDEBUG
					convert_ipaddr((char *)&tmp,
						arpreply->tipaddr);
					printf("Sent ARP reply to: %I\r\n",tmp);
#endif MDEBUG
				}
				continue;
			}

					/* Check for RARP - No IP hdr */
			if ((type == AWAIT_RARP) &&
			   (nic.packetlen >= ETHER_HDR_SIZE +
				sizeof(struct arprequest)) &&
			   (ptype == RARP)) {
				arpreply = (struct arprequest *)
					&nic.packet[ETHER_HDR_SIZE];
				if ((arpreply->opcode == ntohs(RARP_REPLY)) &&
				   !bcmp(arpreply->thwaddr, ptr, ETHER_ADDR_SIZE)) {
					bcopy(arpreply->shwaddr,
						arptable[ARP_SERVER].node,
						ETHER_ADDR_SIZE);
					bcopy(arpreply->sipaddr,
						& arptable[ARP_SERVER].ipaddr,
						4);
					bcopy(arpreply->tipaddr,
						& arptable[ARP_CLIENT].ipaddr,
						4);
					return(1);
				}
				continue;
			}

					/* Anything else has IP header */
			if ((nic.packetlen < protohdrlen) ||
			   (ptype != IP) ) continue;
			ip = (struct iphdr *)&nic.packet[ETHER_HDR_SIZE];
			if ((ip->verhdrlen != 0x45) ||
				ipchksum((unsigned short *)ip, sizeof(struct iphdr)) ||
				(ip->protocol != IP_UDP)) continue;
			udp = (struct udphdr *)&nic.packet[ETHER_HDR_SIZE +
				sizeof(struct iphdr)];

					/* BOOTP ? */
			bootpreply = (struct bootp_t *)&nic.packet[ETHER_HDR_SIZE];
			if ((type == AWAIT_BOOTP) &&
			   (nic.packetlen >= (ETHER_HDR_SIZE +
#ifndef DHCP_SUPPORT
			     sizeof(struct bootp_t))) &&
#else
			     sizeof(struct bootp_t))-DHCP_OPT_LEN) &&
#endif /* DHCP_SUPPORT */
			   (ntohs(udp->dest) == BOOTP_CLIENT) &&
			   (bootpreply->bp_op == BOOTP_REPLY) &&
			   (bootpreply->bp_xid == xid)) {
				convert_ipaddr((char *)&arptable[ARP_CLIENT].ipaddr,
					bootpreply->bp_yiaddr);
#ifdef DHCP_SUPPORT
				bcopy(bootpreply->bp_yiaddr,dhcp_addr,4);
#endif /* DHCP_SUPPORT */
				default_netmask();
				convert_ipaddr((char *)&arptable[ARP_SERVER].ipaddr,
					bootpreply->bp_siaddr);
				bzero(arptable[ARP_SERVER].node,
					ETHER_ADDR_SIZE);  /* Kill arp */
				convert_ipaddr((char *)&arptable[ARP_GATEWAY].ipaddr,
					bootpreply->bp_giaddr);
				bzero(arptable[ARP_GATEWAY].node,
					ETHER_ADDR_SIZE);  /* Kill arp */
				if (bootpreply->bp_file[0]) {
					bcopy(bootpreply->bp_file,
						kernel_buf, 128);
					kernel = kernel_buf;
				}
				bcopy((char *)bootpreply,
				      (char *)&bootp_data,
				      sizeof(struct bootpd_t));
				decode_rfc1533(bootp_data.bootp_reply.bp_vend,
#ifndef DHCP_SUPPORT
					       0, BOOTP_VENDOR_LEN +
					       MAX_BOOTP_EXTLEN, 1);
#else
					       0, DHCP_OPT_LEN, 1);
#endif /* DHCP_SUPPORT */
				return(1);
			}

					/* TFTP ? */
			if ((type == AWAIT_TFTP) &&
				(ntohs(udp->dest) == ival)) return(1);

					/* RPC */
			rpc = (struct rpc_t *)&nic.packet[ETHER_HDR_SIZE];

		}
	}
	return(0);
}

/**************************************************************************
DECODE_RFC1533 - Decodes RFC1533 header
**************************************************************************/
int decode_rfc1533(p, block, len, eof)
	register unsigned char *p;
	int block, len, eof;
{
	static unsigned char *extdata = NULL, *extend = NULL;
	unsigned char        *extpath = NULL;
	unsigned char        *end, *q;

	if (block == 0) {
#ifdef IMAGE_MENU
		bzero(imagelist, sizeof(imagelist));
		menudefault = useimagemenu = 0;
		menutmo = -1;
#endif
#ifdef MOTD
		bzero(motd, sizeof(motd));
#endif
		end_of_rfc1533 = NULL;
		vendorext_isvalid = 0;
		if (bcmp(p, rfc1533_cookie, 4))
			return(0); /* no RFC 1533 header found */
		p += 4;
		end = p + len; }
	else {
		if (block == 1) {
			if (bcmp(p, rfc1533_cookie, 4))
				return(0); /* no RFC 1533 header found */
			p += 4;
			len -= 4; }
		if (extend + len <= (unsigned char *)(&bootp_data+1)) {
			bcopy(p, extend, len);
			extend += len;
		} else {
			printf("Overflow in vendor data buffer! Aborting...\r\n");
			*extdata = RFC1533_END;
			return(0);
		}
		p = extdata; end = extend;
	}
	if (eof) {
		while(p < end) {
			unsigned char c = *p;
			if (c == RFC1533_PAD) {p++; continue;}
			else if (c == RFC1533_END) {
				end_of_rfc1533 = end = p; continue; }
			else if (c == RFC1533_NETMASK) {bcopy(p+2,&netmask,4);}

			else if (c == RFC1533_GATEWAY) {
				/* This is a little simplistic, but it will
				   usually be sufficient; look into the gate-
				   way list, only if there has been no BOOTP
				   gateway. Take only the first entry */
				if (TAG_LEN(p) >= 4 &&
				    arptable[ARP_GATEWAY].ipaddr == 0)
					convert_ipaddr((char *)&arptable[ARP_GATEWAY].ipaddr,
					               p+2);
			}
			else if (c == RFC1533_EXTENSIONPATH)
				extpath = p;
#ifdef DHCP_SUPPORT
			else if (c == RFC2132_MSG_TYPE)
				{ dhcp_reply=*(p+2);
				}
			else if (c == RFC2132_SRV_ID)
				{
				bcopy(p+2,dhcp_server,4); 
				}
#endif /* DHCP_SUPPORT */
			else if (c == RFC1533_VENDOR_MAGIC
#ifndef	BROKEN_DHCPD_TAG128
				&& TAG_LEN(p) >= 6 &&
				 !bcmp(p+2,vendorext_magic,4) &&
				 p[6] == RFC1533_VENDOR_MAJOR
#endif
				)
				vendorext_isvalid++;
#ifdef IMAGE_MENU
			else if (c == RFC1533_VENDOR_MNUOPTS) {
				parse_menuopts(p+2, TAG_LEN(p));
			}
			else if (c >= RFC1533_VENDOR_IMG &&
				 c<RFC1533_VENDOR_IMG+RFC1533_VENDOR_NUMOFIMG){
				imagelist[c - RFC1533_VENDOR_IMG] = p;
				useimagemenu++;
			}
#endif
#ifdef MOTD
			else if (c >= RFC1533_VENDOR_MOTD &&
				 c < RFC1533_VENDOR_MOTD +
				 RFC1533_VENDOR_NUMOFMOTD)
				motd[c - RFC1533_VENDOR_MOTD] = p;
#endif
			else {
				/* printf("Unknown RFC1533-tag ");
				for(q=p;q<p+2+TAG_LEN(p);q++)
					printf("%x ",*q);
				printf("\n\r"); */ }
			p += TAG_LEN(p) + 2;
		}
		extdata = extend = end;
		if (block == 0 && extpath != NULL) {
			char fname[64];
			bcopy(extpath+2,fname,TAG_LEN(extpath));
			fname[(int)TAG_LEN(extpath)] = '\000';
			printf("Loading BOOTP-extension file: %s\r\n",fname);
			tftp(fname,decode_rfc1533);
		}
	}
	return(-1); /* proceed with next block */
}

/**************************************************************************
IPCHKSUM - Checksum IP Header
**************************************************************************/
unsigned short ipchksum(ip, len)
	register unsigned short *ip;
	register int len;
{
	unsigned long sum = 0;
	len >>= 1;
	while (len--) {
		sum += *(ip++);
		if (sum > 0xFFFF)
			sum -= 0xFFFF;
	}
	return((~sum) & 0x0000FFFF);
}

/**************************************************************************
CONVERT_IPADDR - Convert IP address from net to machine order
**************************************************************************/
void convert_ipaddr(d, s)
	register char *d,*s;
{
	d[3] = s[0];
	d[2] = s[1];
	d[1] = s[2];
	d[0] = s[3];
}

void sleep (int secs)
{
	long tmo;

	for (tmo = currticks()+secs*18; currticks() < tmo; )
		/* Nothing */;
}

/**************************************************************************
RFC951_SLEEP - sleep for expotentially longer times
**************************************************************************/
void rfc951_sleep(exp)
	int exp;
{
	static long seed = 0;
	long q,z,tmo;

	if (!seed) /* Initialize linear congruential generator */
		seed = currticks() + *(long *)&arptable[ARP_CLIENT].node
		       + ((short *)arptable[ARP_CLIENT].node)[2];
	/* simplified version of the LCG given in Bruce Scheier's
	   "Applied Cryptography" */
	q = seed/53668;
	if ((seed = 40014*(seed-53668*q) - 12211*q) < 0) seed += 2147483563l;
	/* compute mask */
	for (tmo = 63; tmo <= 60*18 && --exp > 0; tmo = 2*tmo+1);
	/* sleep */
	printf("<sleep>\r\n");
	for (tmo = (tmo&seed)+currticks(); currticks() < tmo; )
	  if (iskey() && (getchar() == ESC)) longjmp(jmp_bootmenu,1);
	return;
}

/*
 * Local variables:
 *  c-basic-offset: 8
 * End:
 */
