/**************************************************************************
ETHERBOOT -  BOOTP/TFTP Bootstrap Program

Author: Martin Renters
  Date: Dec/93

**************************************************************************/

#include "etherboot.h"
#include "config.h"

/**************************************************************************
BOOTMENU - Present boot options
**************************************************************************/
void bootmenu(passive)
	int passive;
{

	static int retrycount = 0;

	if (passive)
		rfc951_sleep(++retrycount);
	printf("<abort>\r\n");
	eth_reset();

}

#ifdef MOTD
/**************************************************************************
SHOW_MOTD - display the message of the day
**************************************************************************/
void show_motd(void)
{
	char *ptr;
	int  i,j,k = 0;

	for (i = 0; i < RFC1533_VENDOR_NUMOFMOTD; i++) if (motd[i]) {
		if (!k++)
			printf("\r\n");
		for (j = TAG_LEN(motd[i]), ptr = motd[i]+2; j-- && *ptr; )
			putchar(*ptr++);
		printf("\r\n"); }
	return;
}
#endif

#ifdef IMAGE_MENU
#if !defined(ANSIESC) || defined(SERIAL_CONSOLE)
static const char *clrline = "                                                                               ";
#endif

/**************************************************************************
PARSE_MENUOPTS - parse menu options and set control variables
**************************************************************************/
void parse_menuopts(opt, len)
	char *opt;
	int  len;
{
	/* This code assumes that "bootpd" terminates the control string
	   with a '\000' character */
	while (len > 0 && *opt) {
		if (!bcmp(opt,"timeout=",8)) {
			if (!getoptvalue(&opt, &len, &menutmo))
				return; }
		else if (!bcmp(opt,"default=",8)) {
			if (!getoptvalue(&opt, &len, &menudefault))
				return; }
		while (len > 0 && *opt != ':') { opt++; len--; }
		while (len > 0 && *opt == ':') { opt++; len--; }
	}
	return;
}

int getoptvalue(ptr, len, rc)
	char	**ptr;
	int	*len, *rc;
{
	char *tmp,*old;
	int  i,l;
	
	for (tmp = *ptr, l = *len; *tmp != '='; tmp++, l--);
	old = ++tmp; l--;
	if (!*tmp || *tmp == ':' || l <= 0)
		return(0);
	i = getdec(&tmp);
	if (i < 0 || (l -= tmp - old) < 0)
		return(0);
	*rc = i;
	*len = l;
	*ptr = tmp;
	return(1);
}

/**************************************************************************
GETPARMS - get user provided parameters
**************************************************************************/

#ifdef USRPARMS
static int getparms(void)
{
	char *ptr = end_of_rfc1533+2;
	int  ch,i = 0,max = (char *)(&bootp_data+1) - ptr - 1;

	if (!end_of_rfc1533 || max < 0)
		return(0);
	else if (max > 255)
		max = 255;
restart:
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
	printf("\rParams: [K");
#else
	printf("%s%s%s","\rParams: ",clrline+8,"\rParams: ");
#endif
	for (ch = i; ch; )
		putchar(ptr[-(ch--)]);
	for (;;) {
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
		enable_cursor(1);
		ch = getchar();
		enable_cursor(0);
#else
		ch = getchar();
#endif
		if (ch == '\r' || ch == '\n')
			break;
		if (ch == ('U'&0x1F)) {
			ptr -= i;
			i = 0;
			goto restart; }
		if (ch == ('H'&0x1F)) {
			if (i) {
				i--; ptr--;
				printf("\010 \010"); }
			continue; }
		if (ch == ('L'&0x1F))
			goto restart;
		if (i == max || (signed char)ch < (signed char)' ')
			continue;
		putchar(*ptr++ = ch);
		i++; }
	if (i) {
		end_of_rfc1533[0] = RFC1533_VENDOR_ADDPARM;
		end_of_rfc1533[1] = i;
		*ptr++ = '\000';
		*ptr   = RFC1533_END;
	        i += 3; }
	printf("\r\n");
	return(i);
}
#endif

/**************************************************************************
GETHEX - compute one hex byte
**************************************************************************/
#ifdef PASSWD
static int gethex(char *dat)
{
	int  i,j;

	i = (j = *dat) > '9' ? (j+9) & 0xF : j - '0';
	dat++;
	return(16*i + ((j = *dat) > '9' ? (j+9) & 0xF : j - '0'));
}
#endif

/**************************************************************************
SELECTIMAGE - interactively ask the user for the boot image
**************************************************************************/

/* Warning! GCC 2.7.2 has difficulties with analyzing the data flow in
   the following function; it will sometimes clobber some of the local
   variables. If you encounter strange behavior, try to introduce more
   temporary variables for storing intermediate results. This might
   help GCC... */

void selectImage(imagelist)
	char *imagelist[];
{
#ifdef USRPARMS
	int flag_parms = 1;
	int modifier_keys = 0;
#endif
#ifdef PASSWD
	int flag_image = 1;
#endif
	char *e,*s,*d,*p;
	int  i,j,k,m,len;
	unsigned long ip,tmo;

	printf(" \r\nList of available boot images:\r\n\n");
	for (i = j = 0; i < RFC1533_VENDOR_NUMOFIMG; i++) {
		if ((e = imagelist[i]) != NULL) {
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
			printf("[4C%c) ",'A'+j++);
#else
			printf("    %c) ",'A'+j++);
#endif
			for (s = e+2, len = TAG_LEN(e)+2;
			     (s - e) < len && *s != ':';
			     putchar(*s++));
			printf("\r\n");
		}
	}
	m = j;
	putchar('\n');
reselect:
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
	printf("Select: [K");
#else
	printf("%s%s%s","\rSelect: ",clrline+8,"\rSelect: ");
#endif
	tmo = currticks()/18 + menutmo;
	for (;;) {
		if (menutmo >= 0) { for (i = -1; !iskey(); ) {
			if ((k = tmo - currticks()/18) <= 0) {
selectdefault:
				if (menudefault >= 0 && menudefault <
				    RFC1533_VENDOR_NUMOFIMG) {
					i = menudefault;
					goto findimg;
				} else if (menudefault >= RFC1533_VENDOR_IMG &&
					 menudefault < RFC1533_VENDOR_IMG +
					 RFC1533_VENDOR_NUMOFIMG &&
					 imagelist[menudefault -
						  RFC1533_VENDOR_IMG]) {
					j = menudefault-RFC1533_VENDOR_IMG;
					goto img;
				}
				i = ESC;
				goto key;
			} else if (i != k) {
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
				printf("[s(%d seconds)[K[u",i = k);
#else
				printf("%s%s%s(%d seconds)",
				       "\rSelect: ",clrline+8,
				       "\rSelect: ",i = k);
#endif
			}
		} }
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
		enable_cursor(1);
		i = getchar();
		enable_cursor(0);
#else
		i = getchar();
#endif
	key:
#ifdef USRPARAMS
		modifier_keys = 0;
#endif
#if defined(USRPARMS) && !defined(SERIAL_CONSOLE)
		modifier_keys |= getshift();
#endif
		if (i == ESC) longjmp(jmp_bootmenu,1);
		if ((i == '\r') || (i == '\n')) {
			goto selectdefault;
		}
		if (i == '\t') {
			menutmo = -1;
			printf("\r");
			goto reselect;
		}
		if ((i >= 'A') && (i < 'A'+m)) {
			i -= 'A';
#ifdef USRPARAMS
			modifier_keys |= 3; /* ShiftL + ShiftR */
#endif
			break;
		} else if ((i >= 'a') && (i < 'a'+m)) {
			i -= 'a';
			break;
		}
	}
findimg:
	j = 0;
	while (i >= 0) {
		if (imagelist[j] != NULL) i--;
		j++;
	}
	j--;
img:
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
	printf("[K");
#else
	printf("%s%s%s","\rSelect: ",clrline+8,"\rSelect: ");
#endif
	for (len = TAG_LEN(e = imagelist[j]) + 2, s = e + 2;
	     (s - e) < len && *s != ':';
	     putchar(*s++));
	printf("\r\n");
	for (i = ARP_SERVER; i <= ARP_GATEWAY; i++) {
		if ((++s - e) >= len) goto local_disk;
		if (setip(s,&ip)) {
			arptable[i].ipaddr = ip;
			bzero(arptable[i].node,
			      ETHER_ADDR_SIZE);
			while ((s - e) < len && *s != ':') s++;
		}
	}
	if ((++s - e) >= len) goto local_disk;
	for (d = s; (d - e) < len && *d != ':'; d++);
	for (p = d + 1, j = 0; (p - e) < len && *p && *p != ':'; p++, j++);
	for (p++, i = 0; (p - e) < len && *p != ':'; p++) {
#if defined(USRPARMS) || defined(PASSWD)
		if (*p >= '0' && *p <= '9')
			i = 10*i + *p - '0';
		else {
			k = *p & ~0x20;
#ifdef USRPARMS
			if (k == 'P') {
				flag_parms = i;
				/* 0 - never interactively accept parameters
				 * 1 - require password before accepting parms.
				 * 2 - always ask for passwd and parameters
				 * 3 - always ask for parameters
				 */
			}
#endif
#ifdef PASSWD
			if (k == 'I') {
				flag_image = i;
				/* 0 - do not require a password for this image
				 * 1 - require a password for this image
				 */
			}
#endif
			i = 0;
		}
#endif
	}
#ifdef USRPARMS
	if (flag_parms == 1 && modifier_keys)
		flag_parms++;
#endif
#ifdef PASSWD
	if ((flag_image > 0
#ifdef USRPARMS
	     || flag_parms == 2
#endif
	    ) && j == 32) {
		unsigned char md5[16];
		printf("Passwd: ");
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
		enable_cursor(1);
#endif
		while ((i = getchar()) != '\r' && i != '\n') {
			if (i == ('U'&0x1F)) md5_done(md5);
			else                 md5_put(i);
		}
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
		enable_cursor(0);
#endif
		md5_done(md5);
		for (i = 16, p = d+31; i--; p -= 2) {
			if (gethex(p) != md5[i]) {
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
				printf("\r[K[1A");
#else
				printf("\r");
#endif
				goto reselect;
			}
		}
		printf("\r\n");
	}
#endif
#ifdef USRPARMS
	if (flag_parms > 1)
		i = getparms();
	else
		i = 0;
#endif
	if ((len = d - s) <= 0 || len > sizeof(kernel_buf)-1 || !*s) {
	local_disk:
#if defined(ANSIESC) && !defined(SERIAL_CONSOLE)
		ansi_reset();
#endif
		exit(0);
	}
	if (end_of_rfc1533 != NULL &&
	    (end_of_rfc1533+4) < (unsigned char *)(&bootp_data+1)) {
#ifdef USRPARMS
		d    = end_of_rfc1533 + i;
#else
		d    = end_of_rfc1533;
#endif
		i    = e-d;
		*d++ = RFC1533_VENDOR_SELECTION;
		*d++ = 1;
		*d++ = *e;
		*d   = RFC1533_END;
	}
	bcopy(s,kernel = kernel_buf,len);
	kernel_buf[len] = '\000';
	return;
}
#endif

/*
 * Local variables:
 *  c-basic-offset: 8
 * End:
 */
