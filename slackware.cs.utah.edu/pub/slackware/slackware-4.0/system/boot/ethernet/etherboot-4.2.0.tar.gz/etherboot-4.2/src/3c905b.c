/*  
 * 3c905b.c -- This file implements the 3c905B driver for etherboot.  Written
 * by Greg Beeley, Greg.Beeley@LightSys.org.  
 *
 * This program Copyright (C) 1999 LightSys Technology Services, Inc.
 *
 * This program may be re-distributed in source or binary form, modified, 
 * sold, or copied for any purpose, provided that the above copyright message
 * and this text are included with all source copies or derivative works, and
 * provided that the above copyright message and this text are included in the
 * documentation of any binary-only distributions.  This program is distributed
 * WITHOUT ANY WARRANTY, without even the warranty of FITNESS FOR A PARTICULAR
 * PURPOSE or MERCHANTABILITY.  Please read the associated documentation 
 * "3c905b.txt" before compiling and using this driver.
 *
 * --------
 *
 * Program written with the assistance of the 3com documentation for
 * the 3c905B-TX card, as well as with some assistance from the 3c59x
 * driver Donald Becker wrote for the Linux kernel, and with some assistance
 * from the remainder of the Etherboot distribution.
 *
 * REVISION HISTORY:
 *
 * v0.10	1-26-1998	GRB	Initial implementation.
 * v0.90	1-27-1998	GRB	System works.
 * v1.00pre1	2-11-1998	GRB	Got prom boot issue fixed.
 *
 */


#include "etherboot.h"
#include "nic.h"
#include <linux/pci.h>

#define TIME_OUT 	100
#define	XCVR_MAGIC	(0x5A00)

#undef	virt_to_bus
#define	virt_to_bus(x)	((unsigned long)x)

/*** Register definitions for the 3c905B ***/
enum Registers
    {
    regPowerMgmtCtrl_w = 0x7c,
    regUpMaxBurst_w = 0x7a,
    regDnMaxBurst_w = 0x78,
    regDebugControl_w = 0x74,
    regDebugData_l = 0x70,
    regRealTimeCnt_l = 0x40,
    regUpBurstThresh_b = 0x3e,
    regUpPoll_b = 0x3d,
    regUpPriorityThresh_b = 0x3c,
    regUpListPtr_l = 0x38,
    regCountdown_w = 0x36,
    regFreeTimer_w = 0x34,
    regUpPktStatus_l = 0x30,
    regDnPoll_b = 0x2d,
    regDnPriorityThresh_b = 0x2c,
    regDnBurstThresh_b = 0x2a,
    regDnListPtr_l = 0x24,
    regDmaCtrl_l = 0x20,
    regIntStatusAuto_w = 0x1e,
    regTxStatus_b = 0x1b,
    regTimer_b = 0x1a,
    regTxPktId_b = 0x18,
    regCommandIntStatus_w = 0x0e,
    };

/** following are windowed registers **/
enum Registers7
    {
    regPowerMgmtEvent_7_w = 0x0c,
    regVlanEtherType_7_w = 0x04,
    regVlanMask_7_w = 0x00,
    };

enum Registers6
    {
    regBytesXmittedOk_6_w = 0x0c,
    regBytesRcvdOk_6_w = 0x0a,
    regUpperFramesOk_6_b = 0x09,
    regFramesDeferred_6_b = 0x08,
    regFramesRecdOk_6_b = 0x07,
    regFramesXmittedOk_6_b = 0x06,
    regRxOverruns_6_b = 0x05,
    regLateCollisions_6_b = 0x04,
    regSingleCollisions_6_b = 0x03,
    regMultipleCollisions_6_b = 0x02,
    regSqeErrors_6_b = 0x01,
    regCarrierLost_6_b = 0x00,
    };

enum Registers5
    {
    regIndicationEnable_5_w = 0x0c,
    regInterruptEnable_5_w = 0x0a,
    regTxReclaimThresh_5_b = 0x09,
    regRxFilter_5_b = 0x08,
    regRxEarlyThresh_5_w = 0x06,
    regTxStartThresh_5_w = 0x00,
    };

enum Registers4
    {
    regUpperBytesOk_4_b = 0x0d,
    regBadSSD_4_b = 0x0c,
    regMediaStatus_4_w = 0x0a,
    regPhysicalMgmt_4_w = 0x08,
    regNetworkDiagnostic_4_w = 0x06,
    regFifoDiagnostic_4_w = 0x04,
    regVcoDiagnostic_4_w = 0x02,
    };

enum Registers3
    {
    regTxFree_3_w = 0x0c,
    regRxFree_3_w = 0x0a,
    regMediaOptions_3_w = 0x08,
    regMacControl_3_w = 0x06,
    regMaxPktSize_3_w = 0x04,
    regInternalConfig_3_l = 0x00,
    };

enum Registers2
    {
    regResetOptions_2_w = 0x0c,
    regStationMask_2_3w = 0x06,
    regStationAddress_2_3w = 0x00,
    };

enum Registers0
    {
    regEepromData_0_w = 0x0c,
    regEepromCommand_0_w = 0x0a,
    regBiosRomData_0_b = 0x08,
    regBiosRomAddr_0_l = 0x04,
    };


/*** The names for the eight register windows ***/
enum Windows
    {
    winPowerVlan7 = 0x07,
    winStatistics6 = 0x06,
    winTxRxControl5 = 0x05,
    winDiagnostics4 = 0x04,
    winTxRxOptions3 = 0x03,
    winAddressing2 = 0x02,
    winUnused1 = 0x01,
    winEepromBios0 = 0x00,
    };


/*** Command definitions for the 3c905B ***/
enum Commands
    {
    cmdGlobalReset = 0x00,
    cmdSelectRegisterWindow = 0x01,
    cmdEnableDcConverter = 0x02,
    cmdRxDisable = 0x03,
    cmdRxEnable = 0x04,
    cmdRxReset = 0x05,
    cmdStallCtl = 0x06,
    cmdTxEnable = 0x09,
    cmdTxDisable = 0x0A,
    cmdTxReset = 0x0B,
    cmdRequestInterrupt = 0x0C,
    cmdAcknowledgeInterrupt = 0x0D,
    cmdSetInterruptEnable = 0x0E,
    cmdSetIndicationEnable = 0x0F,
    cmdSetRxFilter = 0x10,
    cmdSetRxEarlyThresh = 0x11,
    cmdSetTxStartThresh = 0x13,
    cmdStatisticsEnable = 0x15,
    cmdStatisticsDisable = 0x16,
    cmdDisableDcConverter = 0x17,
    cmdSetTxReclaimThresh = 0x18,
    cmdSetHashFilterBit = 0x19,
    };


/*** Values for int status register bitmask **/
#define	INT_INTERRUPTLATCH	(1<<0)
#define INT_HOSTERROR		(1<<1)
#define INT_TXCOMPLETE		(1<<2)
#define INT_RXCOMPLETE		(1<<4)
#define INT_RXEARLY		(1<<5)
#define INT_INTREQUESTED	(1<<6)
#define INT_UPDATESTATS		(1<<7)
#define INT_LINKEVENT		(1<<8)
#define INT_DNCOMPLETE		(1<<9)
#define INT_UPCOMPLETE		(1<<10)
#define INT_CMDINPROGRESS	(1<<12)
#define INT_WINDOWNUMBER	(7<<13)


/*** TX descriptor ***/
typedef struct
    {
    unsigned int	DnNextPtr;
    unsigned int	FrameStartHeader;
    unsigned int	HdrAddr;
    unsigned int	HdrLength;
    unsigned int	DataAddr;
    unsigned int	DataLength;
    }
    TXD;

/*** RX descriptor ***/
typedef struct
    {
    unsigned int	UpNextPtr;
    unsigned int	UpPktStatus;
    unsigned int	DataAddr;
    unsigned int	DataLength;
    }
    RXD;

/*** Global variables ***/
static struct
    {
    unsigned char	CurrentWindow;
    unsigned int	IOAddr;
    unsigned char	HWAddr[6];
    TXD			TransmitDPD;
    RXD			ReceiveUPD;
    }
    INF_3C905B;



/*** a3c905b_internal_IssueCommand: sends a command to the 3c905b card
 ***/
static int
a3c905b_internal_IssueCommand(int ioaddr, int cmd, int param)
    {
    unsigned int val;

    	/** Build the cmd. **/
	val = cmd;
	val <<= 11;
	val |= param;

	/** Send the cmd to the cmd register **/
	outw(val, ioaddr + regCommandIntStatus_w);

	/** Wait for the cmd to complete, if necessary **/
	do val = inw(ioaddr + regCommandIntStatus_w); while (val & INT_CMDINPROGRESS);

    return 0;
    }


/*** a3c905b_internal_SetWindow: selects a register window set.
 ***/
static int
a3c905b_internal_SetWindow(int ioaddr, int window)
    {

    	/** Window already as set? **/
	if (INF_3C905B.CurrentWindow == window) return 0;

	/** Issue the window command. **/
	a3c905b_internal_IssueCommand(ioaddr, cmdSelectRegisterWindow, window);
	INF_3C905B.CurrentWindow = window;

    return 0;
    }


/*** a3c905b_internal_ReadEeprom - read data from the serial eeprom.
 ***/
static unsigned short
a3c905b_internal_ReadEeprom(int ioaddr, int address)
    {
    unsigned short val;

	/** Select correct window **/
        a3c905b_internal_SetWindow(INF_3C905B.IOAddr, winEepromBios0);

    	/** Make sure the eeprom isn't busy **/
	while((1<<15) & inw(ioaddr + regEepromCommand_0_w));

	/** Read the value. **/
	outw(address + ((0x02)<<6), ioaddr + regEepromCommand_0_w);
	while((1<<15) & inw(ioaddr + regEepromCommand_0_w));
	val = inw(ioaddr + regEepromData_0_w);

    return val;
    }


/*** a3c905b_internal_WriteEepromWord - write a physical word of 
 *** data to the onboard serial eeprom (not the BIOS prom, but the
 *** nvram in the card that stores, among other things, the MAC
 *** address).
 ***/
static int
a3c905b_internal_WriteEepromWord(int ioaddr, int address, unsigned short value)
    {

    	/** MAKE ABSOLUTELY SURE THIS IS A 3C905B!!!! **/
	if (a3c905b_internal_ReadEeprom(ioaddr, 0x03) != 0x9055)
	    {
	    printf("*** FAILURE TO WRITE EEPROM.  NOT A 3C905B!!!\r\n");
	    return -1;
	    }

    	/** Select register window **/
        a3c905b_internal_SetWindow(ioaddr, winEepromBios0);

	/** Verify Eeprom not busy **/
	while((1<<15) & inw(ioaddr + regEepromCommand_0_w));

	/** Issue WriteEnable, and wait for completion. **/
	outw(0x30, ioaddr + regEepromCommand_0_w);
	while((1<<15) & inw(ioaddr + regEepromCommand_0_w));

	/** Issue EraseRegister, and wait for completion. **/
	outw(address + ((0x03)<<6), ioaddr + regEepromCommand_0_w);
	while((1<<15) & inw(ioaddr + regEepromCommand_0_w));

	/** Send the new data to the eeprom, and wait for completion. **/
	outw(value, ioaddr + regEepromData_0_w);
	outw(0x30, ioaddr + regEepromCommand_0_w);
	while((1<<15) & inw(ioaddr + regEepromCommand_0_w));

	/** Burn the new data into the eeprom, and wait for completion. **/
	outw(address + ((0x01)<<6), ioaddr + regEepromCommand_0_w);
	while((1<<15) & inw(ioaddr + regEepromCommand_0_w));

    return 0;
    }


/*** a3c905b_internal_WriteEeprom - write data to the serial eeprom,
 *** and re-compute the eeprom checksum.
 ***/
static int
a3c905b_internal_WriteEeprom(int ioaddr, int address, unsigned short value)
    {
    int cksum = 0,v;
    int i;

    	/** Write the value. **/
	if (a3c905b_internal_WriteEepromWord(ioaddr, address, value) == -1)
	    return -1;

	/** Recompute the checksum. **/
	for(i=0;i<=0x19;i++)
	    {
	    v = a3c905b_internal_ReadEeprom(ioaddr, i);
	    cksum ^= (v & 0xFF);
	    cksum ^= ((v>>8) & 0xFF);
	    }

	/** Write the checksum to the location 0x20 in the eeprom **/
	if (a3c905b_internal_WriteEepromWord(ioaddr, 0x20, cksum) == -1)
	    return -1;

    return 0;
    }



/*** a3c905b_reset: exported function that resets the card to its default
 *** state.  This is so the Linux driver can re-set the card up the way
 *** it wants to.  If CFG_3C905B_PRESERVE_XCVR is defined, then the reset will
 *** not alter the selected transceiver that we used to download the boot
 *** image.
 ***/
static void 
a3c905b_reset(struct nic *nic)
    {
    int cfg;

#ifdef CFG_3C905B_PRESERVE_XCVR
	/** Read the current InternalConfig value. **/
        a3c905b_internal_SetWindow(INF_3C905B.IOAddr, winTxRxOptions3);
        cfg = inl(INF_3C905B.IOAddr + regInternalConfig_3_l);
#endif

    	/** Send the reset command to the card **/
	printf("Issuing RESET:\r\n");
	a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdGlobalReset, 0);

#ifdef CFG_3C905B_PRESERVE_XCVR
	/** Re-set the original InternalConfig value from before reset **/
        a3c905b_internal_SetWindow(INF_3C905B.IOAddr, winTxRxOptions3);
        outl(cfg, INF_3C905B.IOAddr + regInternalConfig_3_l);
        a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdTxReset, 0);
        a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdRxReset, 0);
#endif

    return;
    }



/*** a3c905b_transmit: exported function that transmits a packet.  Does not return
 *** any particular status.  Parameters are:  d[6] - destination address, ethernet;
 *** t - protocol type (ARP, IP, etc); s - size of the non-header part of the packet
 *** that needs to be transmitted; and p - the pointer to the packet data itself.
 ***/
static void 
a3c905b_transmit(struct nic *nic, char *d, unsigned int t, unsigned int s, char *p)
    {
    struct eth_hdr 
        {
        unsigned char dst_addr[6];
        unsigned char src_addr[6];
        unsigned short type;
        } hdr;
    unsigned short tmp;

  	/** Try un-stalling the dl engine **/
	a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdStallCtl, 3);

  	/** Make sure the card is not waiting on us **/
	tmp = inw(INF_3C905B.IOAddr + regIntStatusAuto_w);

  	/** Set the ethernet packet type **/
	hdr.type = htons(t);

	/** Copy the destination address **/
	memcpy(hdr.dst_addr, d, 6);

	/** Copy our MAC address **/
	memcpy(hdr.src_addr, INF_3C905B.HWAddr, 6);

	/** Setup the DPD (download descriptor) **/
	INF_3C905B.TransmitDPD.DnNextPtr = 0;
	INF_3C905B.TransmitDPD.FrameStartHeader = s + sizeof(hdr);
	INF_3C905B.TransmitDPD.HdrAddr = virt_to_bus(&hdr);
	INF_3C905B.TransmitDPD.HdrLength = sizeof(hdr);
	INF_3C905B.TransmitDPD.DataAddr = virt_to_bus(p);
	INF_3C905B.TransmitDPD.DataLength = s + (1<<31);

	/** Send the packet **/
	outl(virt_to_bus(&(INF_3C905B.TransmitDPD)), INF_3C905B.IOAddr + regDnListPtr_l);

	/** Wait for send to complete. **/
	while(inl(INF_3C905B.IOAddr + regDnListPtr_l) != 0);

    return;
    }



/*** a3c905b_poll: exported routine that waits for a certain length of time
 *** for a packet, and if it sees none, returns 0.  This routine should
 *** copy the packet to nic->packet if it gets a packet and set the size
 *** in nic->packetlen.  Return 1 if a packet was found.
 ***/
static int 
a3c905b_poll(struct nic *nic)
    {
    int to = TIME_OUT;
    int i,errcode;

	/** Loop waiting for a packet, using timeouts **/
	while(1)
	    {
	    /** Set the timeout **/
	    to = TIME_OUT;

    	    /** Build the up-load descriptor **/
	    INF_3C905B.ReceiveUPD.UpNextPtr = 0;
	    INF_3C905B.ReceiveUPD.UpPktStatus = 0;
	    INF_3C905B.ReceiveUPD.DataAddr = virt_to_bus(nic->packet);
	    INF_3C905B.ReceiveUPD.DataLength = 1536 + (1<<31);

	    /** Submit the upload descriptor to the NIC **/
	    outl(virt_to_bus(&(INF_3C905B.ReceiveUPD)), INF_3C905B.IOAddr + regUpListPtr_l);

	    /** Wait for the packet **/
	    while(inl(INF_3C905B.IOAddr + regUpListPtr_l) != 0 && --to)
	        for(i=0;i<40000;i++);

	    /** Timed out?  No packet? **/
	    if (to == 0) 
	        {
		/** Stall the upload engine, clear the upd, and unstall **/
		a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdStallCtl, 0);
	        outl(0, INF_3C905B.IOAddr + regUpListPtr_l);
		a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdStallCtl, 1);
		return 0;
		}

	    /** Wait for completion. **/
	    for(i=0;i<40000;i++);
	    while((INF_3C905B.ReceiveUPD.UpPktStatus & ((1<<14) | (1<<15))) == 0)
	        for(i=0;i<40000;i++);

	    /** Packet, but with error? **/
	    if (INF_3C905B.ReceiveUPD.UpPktStatus & (1<<14)) 
	        {
		errcode = INF_3C905B.ReceiveUPD.UpPktStatus;
		if (errcode & (1<<16))
		    printf("\r3C905B: Receiver Overrun (%x)\r\n",errcode>>16);
		else if (errcode & (1<<17))
		    printf("\r3C905B: Runt Frame (%x)\r\n",errcode>>16);
		else if (errcode & (1<<18))
		    printf("\r3C905B: Alignment Error (%x)\r\n",errcode>>16);
		else if (errcode & (1<<19))
		    printf("\r3C905B: CRC Error (%x)\r\n",errcode>>16);
		else if (errcode & (1<<20))
		    printf("\r3C905B: Oversized Frame (%x)\r\n",errcode>>16);
		else
		    printf("\r3C905B: Packet error (%x)\r\n",errcode>>16);
		continue;
		}

	    /** Ok, got packet.  Set length in nic->packetlen. **/
	    nic->packetlen = (INF_3C905B.ReceiveUPD.UpPktStatus & 0x1FFF);
	    break;
	    }

    return 1;
    }



/*** a3c905b_disable: exported routine to disable the card.  What's this for?
 *** the eepro100.c driver didn't have one, so I just left this one empty too.
 *** Ideas anyone?
 ***/
static void 
a3c905b_disable(struct nic *nic)
    {
    }



/*** a3c905b_probe: exported routine to probe for the 3c905 card and perform
 *** initialization.  If this routine is called, the pci functions did find the
 *** card.  We just have to init it here.
 ***/
struct nic*
a3c905b_probe(struct nic *nic, unsigned short *probeaddrs)
    {
    int i, j, to, v, c;
    unsigned short eeprom[0x40];
    unsigned int cfg;
    unsigned int mopt;
    unsigned short linktype;

    if (probeaddrs == 0 || probeaddrs[0] == 0)
          return 0;

    INF_3C905B.IOAddr = probeaddrs[0] & ~3;
    INF_3C905B.CurrentWindow = 0;

    /** Load the EEPROM contents **/
    for(i=0;i<0x40;i++)
        {
        eeprom[i] = a3c905b_internal_ReadEeprom(INF_3C905B.IOAddr, i);
        }

    /** Set xcvrSelect in InternalConfig in eeprom. **/
    a3c905b_internal_WriteEeprom(INF_3C905B.IOAddr, 0x13, 0x0160);

#ifdef CFG_3C905B_XCVR
    if (CFG_3C905B_XCVR == 255)
        {
        /** Clear the LanWorks register **/
        a3c905b_internal_WriteEeprom(INF_3C905B.IOAddr, 0x16, 0);
	}
    else
        {
        /** Set the selected permanent-xcvrSelect in the LanWorks register **/
        a3c905b_internal_WriteEeprom(INF_3C905B.IOAddr, 0x16, XCVR_MAGIC + ((CFG_3C905B_XCVR) & 0x000F));
	}
#endif

    /** Print identification message **/
    printf("\r\n\r\n3C905B-TX Driver 1.00pre1 Copyright 1999 LightSys Technology Services, Inc.\r\n");
    printf("Provided with ABSOLUTELY NO WARRANTY.\r\n");
    printf("-------------------------------------------------------------------------------\r\n");

    /** Retrieve the Hardware address and print it on the screen. **/
    INF_3C905B.HWAddr[0] = eeprom[0]>>8;
    INF_3C905B.HWAddr[1] = eeprom[0]&0xFF;
    INF_3C905B.HWAddr[2] = eeprom[1]>>8;
    INF_3C905B.HWAddr[3] = eeprom[1]&0xFF;
    INF_3C905B.HWAddr[4] = eeprom[2]>>8;
    INF_3C905B.HWAddr[5] = eeprom[2]&0xFF;
    printf("MAC Address = %b:%b:%b:%b:%b:%b\r\n",
        INF_3C905B.HWAddr[0],INF_3C905B.HWAddr[1],INF_3C905B.HWAddr[2],
	INF_3C905B.HWAddr[3],INF_3C905B.HWAddr[4],INF_3C905B.HWAddr[5]);

    /** Program the MAC address into the station address registers **/
    a3c905b_internal_SetWindow(INF_3C905B.IOAddr, winAddressing2);
    outw(htons(eeprom[0]), INF_3C905B.IOAddr + regStationAddress_2_3w);
    outw(htons(eeprom[1]), INF_3C905B.IOAddr + regStationAddress_2_3w+2);
    outw(htons(eeprom[2]), INF_3C905B.IOAddr + regStationAddress_2_3w+4);
    outw(0, INF_3C905B.IOAddr + regStationMask_2_3w+0);
    outw(0, INF_3C905B.IOAddr + regStationMask_2_3w+2);
    outw(0, INF_3C905B.IOAddr + regStationMask_2_3w+4);

    /** Fill in our entry in the etherboot arp table **/
    for(i=0;i<6;i++) nic->node_addr[i] = (eeprom[i/2] >> (8*((i&1)^1))) & 0xff;

    /** Read the media options register, print a message and set default xcvr. **/
    a3c905b_internal_SetWindow(INF_3C905B.IOAddr, winTxRxOptions3);
    mopt = inw(INF_3C905B.IOAddr + regMediaOptions_3_w);
    printf("Connectors present: ");
    c = 0;
    linktype = 0x0008;
    if (mopt & 0x01) 
        {
	printf("%s100Base-T4",(c++)?", ":"");
	linktype = 0x0006;
	}
    if (mopt & 0x04) 
        {
	printf("%s100Base-FX",(c++)?", ":"");
	linktype = 0x0007;
	}
    if (mopt & 0x10) 
        {
	printf("%s10Base-2",(c++)?", ":"");
	linktype = 0x0003;
	}
    if (mopt & 0x20) 
        {
	printf("%sAUI",(c++)?", ":"");
	linktype = 0x0001;
	}
    if (mopt & 0x40) 
        {
	printf("%sMII",(c++)?", ":"");
	linktype = 0x0006;
	}
    if ((mopt & 0xA) == 0xA)
        {
        printf("10Base-T / 100Base-TX"),c++;
	linktype = 0x0008;
	}
    else if ((mopt & 0xA) == 0x2)
        {
        printf("100Base-TX"),c++;
	linktype = 0x0008;
	}
    else if ((mopt & 0xA) == 0x8)
        {
        printf("10Base-T"),c++;
	linktype = 0x0008;
	}
    printf(".\r\n");

    /** Determine transceiver type to use, depending on value stored in eeprom 0x16 **/
    if ((eeprom[0x16] & 0xFF00) == XCVR_MAGIC)
        {
	/** User-defined **/
	linktype = eeprom[0x16] & 0x000F;
	}

    /** Set the link to the type we just determined. **/
    a3c905b_internal_SetWindow(INF_3C905B.IOAddr, winTxRxOptions3);
    cfg = inl(INF_3C905B.IOAddr + regInternalConfig_3_l);
    cfg &= ~(0xF<<20);
    cfg |= (linktype<<20);
    outl(cfg, INF_3C905B.IOAddr + regInternalConfig_3_l);

    /** Now that we set the xcvr type, reset the Tx and Rx. **/
    a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdTxReset, 0);
    a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdRxReset, 0);

    /** Set the RX filter = receive only individual pkts & bcast. **/
    a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdSetRxFilter, 0x01 + 0x04);

    /** Enable the transmitter **/
    a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdTxEnable, 0);
    a3c905b_internal_IssueCommand(INF_3C905B.IOAddr, cmdRxEnable, 0);

    /** Set our exported functions **/
    nic->reset = a3c905b_reset;
    nic->poll = a3c905b_poll;
    nic->transmit = a3c905b_transmit;
    nic->disable = a3c905b_disable;
    return nic;
    }


