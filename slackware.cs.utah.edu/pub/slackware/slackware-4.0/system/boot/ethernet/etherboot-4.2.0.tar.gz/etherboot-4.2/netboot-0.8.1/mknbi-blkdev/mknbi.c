/*
 * mknbi.c  -  MaKe NetBoot Image
 *
 * Version 1.0 <Sun Jan 19 17:00:00 1997>
 *
 * Copyright (C) 1997    Gero Kuhlmann   <gero@gkminix.han.de>
 *                   and Markus Gutschke <gutschk@math.uni-muenster.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "common.h"
#include "mknbi.h"

#ifndef _MKNBI_H_BLKDEV_
#error Included wrong header file
#endif


static char outname[MAXPATHLEN];/* Name of output file */
static char *progname;
static int outfile;		/* File handle for output file */
static int verbose = 0;		/* Verbosity level; currently just 0, 1 or 2 */

static int cur_rec_num = -1;	/* Number of current load record */
static struct load_header header;  /* Load header */
static struct load_record *cur_rec;/* Pointer to current load record */


/*
 * Write a buffer into the output file and update the load record
 */
static void putrec(int recnum, char *src, int size)
{
  unsigned long l;
  long isize;
  char *buf;

  if (cur_rec_num != recnum) {
    fprintf(stderr, "%s: Internal error; image chunks mis-ordered!\n",
	    progname);
    exit(EXIT_FAILURE);
  }
  isize = ((size / (SECTSIZE + 1)) + 1) * SECTSIZE;
  if ((buf = malloc(isize)) == NULL) {
	perror(progname);
	exit(EXIT_FAILURE);
  }
  memset(buf, isize, 0);
  memcpy(buf, src, size);
  if (write(outfile, buf, isize) != isize) {
	perror(outname);
	exit(EXIT_FAILURE);
  }
  free(buf);
  l = get_long(cur_rec->ilength) + isize;
  cur_rec->ilength.low  = htot(low_word(l));
  cur_rec->ilength.high = htot(high_word(l));
  l = get_long(cur_rec->mlength) + isize;
  cur_rec->mlength.low  = htot(low_word(l));
  cur_rec->mlength.high = htot(high_word(l));
}


/*
 * Initialize a load record
 */
static void initrec(int recnum, int segment, int flags, int vendor_size)
{
  if (++cur_rec_num != recnum) {
	fprintf(stderr, "%s: Internal error; image chunks mis-ordered!\n",
		progname);
	exit(EXIT_FAILURE);
  }

  if (cur_rec_num > 0)
	(unsigned char *)cur_rec += ((cur_rec->rlength << 2) & 0x3c) +
					((cur_rec->rlength >> 2) & 0x3c);
  cur_rec->rlength      = (sizeof(struct load_record) -
		           sizeof(union vendor_data)) >> 2;
  cur_rec->rlength     |= ((vendor_size + 3) & 0x3c) << 2;
  cur_rec->rtag1        = recnum + VENDOR_OFF;
  cur_rec->rflags       = flags;
  cur_rec->address.low  = htot(low_word((unsigned long) segment << 4));
  cur_rec->address.high = htot(high_word((unsigned long) segment << 4));
}


/*
 * Dump the load record information to stderr
 */
static void dump_header(struct load_header *lh)
{
  static char *s_tags[] = { [BOOTLNUM]  "primary boot loader"};
  static char *s_flags[]= { "absolute address", "after previous segment",
			    "at end of memory", "before previos segment"};
  struct load_record *lr;
  int    i, num = 0;

  fprintf(stderr,"\n"
	  "Load record information:\n"
	  "  Magic number:     0x%08lX\n"
	  "  Length of header: %d bytes (standard) + %d bytes (vendor)\n"
	  "  Flags:            0x%08lX\n"
	  "  Location address: %04X:%04X\n"
	  "  Execute address:  %04X:%04X\n"
	  "  Vendor data:      %s\n"
	  "\n",
	  get_long(lh->magic),
	  (lh->hlength << 2) & 0x3c,
	  (lh->hlength >> 2) & 0x3c,
	  (unsigned long)lh->hflags1 +
		((unsigned long)lh->hflags2 << 8) +
		((unsigned long)lh->hflags3 << 16),
	  ttoh(lh->locn.segment), ttoh(lh->locn.offset),
	  ttoh(lh->execute.segment), ttoh(lh->execute.offset),
	  lh->dummy);

  i  = ((lh->hlength >> 2) & 0x3c) + ((lh->hlength << 2) & 0x3c);
  lr = (struct load_record *)&(((__u8 *)lh)[i]);

  for (;;) {
    fprintf(stderr,
	    "Record #%d:\n"
	    "  Length of header: %d bytes (standard) + %d bytes (vendor)\n"
	    "  Vendor tag:       0x%02X (%s)\n"
	    "  Reserved flags:   0x%02X\n"
	    "  Flags:            0x%02X (%s%s)\n"
	    "  Load address:     0x%08lX%s\n"
	    "  Image length:     0x%08lX bytes\n"
	    "  Memory length:    0x%08lX bytes\n"
	    "  Vendor data:      %s\n"
	    "\n",
	    ++num,
	    (lr->rlength << 2) & 0x3c,
	    (lr->rlength >> 2) & 0x3c,
	    (int)lr->rtag1,
	    lr->rtag1 < 16 || lr->rtag1-16 >= NUM_RECORDS ? "unknown" : s_tags[lr->rtag1-16],
	    (int)lr->rtag2,
	    (int)lr->rflags, s_flags[lr->rflags & 0x03],
	    lr->rflags & FLAG_EOF ? ", last record" : "",
	    get_long(lr->address),
	    get_long(lr->address) >= 0x100000L ? " (high memory)" : "",
	    get_long(lr->ilength),
	    get_long(lr->mlength),
	    lr->rlength & 0xf0 ? "unknown" : "none");

    if (lr->rflags & FLAG_EOF)
      break;

    i  = ((lr->rlength >> 2) & 0x3c) + ((lr->rlength << 2) & 0x3c);
    lr = (struct load_record *)&(((__u8 *)lr)[i]);
  }
}


/*
 * Print the usage
 */
static void usage(void)
{
  fprintf(stderr,
	"Usage: %s [-x] [[-o] <outfile>]\n"
	"       %s [-h]\n"
	"       %s [-v]\n",
	  progname, progname, progname);
  exit(EXIT_FAILURE);
}


/*
 * Main program
 */
void main(int argc, char **argv)
{
  char *addrs = NULL;		/* String containing various addresses */
  char *cp, *ip;
  int vendor_size;
  int i, len;

  /* Determine my own name for error output */
  if ((cp = strrchr(argv[0], '/')) == NULL)
	progname = argv[0];
  else
	progname = ++cp;

  /* Initialize option argments */
  strcpy(outname, "");

  /* Parse options */
  opterr = 0;
  while ((i = getopt(argc, argv, "o:vxh")) != EOF)
	switch (i) {
		case 'o': strncpy(outname, optarg, MAXPATHLEN-1);
		          outname[MAXPATHLEN-1] = '\0';
		          break;
		case 'v': fprintf(stderr, VERSION"\n");
		          exit(EXIT_SUCCESS);
		case 'x': verbose++;
		          break;
		case 'h': /* fall thru */
		default:  usage();
	}

  /* Parse additional arguments */
  if (optind < argc) {
	strncpy(outname, argv[optind++], MAXPATHLEN-1);
	outname[MAXPATHLEN-1] = '\0';
  }
  if (optind != argc)
	usage();

  /* Open the output file */
  if (strlen(outname) == 0 || !strcmp(outname, "-")) {
	outfile = STDOUT_FILENO;
	strcpy(outname, "stdout");
  } else if ((outfile = creat(outname, 0664)) < 0) {
	perror(outname);
	exit(EXIT_FAILURE);
  }

  if (verbose > 0) {
	fprintf(stderr, "Output file name        = %s\n", outname);
  }

  /* Initialize the boot header */
  vendor_size = (sizeof(VENDOR_ID) / sizeof(__u32) + 1) * sizeof(__u32);
  memset(&header, sizeof(header), 0);
  header.magic.low       = htot(low_word(HEADER_MAGIC));
  header.magic.high      = htot(high_word(HEADER_MAGIC));
  header.hlength         = (__u8)(((int)&header.dummy - (int)&header)
                           / sizeof(__u32)) & 0x0f;
  header.hlength        |= (__u8)((vendor_size/sizeof(__u32)) << 4) & 0xf0;
  header.locn.segment    = htot(DEF_HEADERSEG);
  header.locn.offset     = 0;
  header.execute.segment = htot(DEF_BOOTLSEG);
  header.execute.offset  = 0;
  header.bootsig         = htot(BOOT_SIGNATURE);
  memcpy(&header.dummy, VENDOR_ID, sizeof(VENDOR_ID));
  if (write(outfile, &header, sizeof(header)) < 0) {
	perror(outname);
	exit(EXIT_FAILURE);
  }

  /* Initialize pointer to first load record */
  cur_rec = (struct load_record *)&(header.dummy[vendor_size]);

  /* Process the boot loader record */
  if (first_data_size > BOOTLLSIZE) {
	fprintf(stderr, "%s: Boot loader too large\n", progname);
	exit(EXIT_FAILURE);
  }
  initrec(BOOTLNUM, DEF_BOOTLSEG, FLAG_EOF, 0);
  putrec(BOOTLNUM, (char *) &first_data, first_data_size);
  cur_rec->mlength.low  = htot(low_word(BOOTLMSIZE));
  cur_rec->mlength.high = htot(high_word(BOOTLMSIZE));

  /* After writing out all this stuff, finally update the boot header */
  if (lseek(outfile, 0, 0) != 0) {
	perror(outname);
	exit(EXIT_FAILURE);
  }
  if (write(outfile, &header, sizeof(header)) < 0) {
	perror(outname);
	exit(EXIT_FAILURE);
  }

  /* If user asked for detailed output, parse the header and output all of */
  /* the load record information */
  if (verbose > 1)
	dump_header(&header);

  exit(EXIT_SUCCESS);
}
