#!/usr/bin/perl

# edit this to the printer hostname
$them = 'ken';
$port = 9101;

open(STDIN, "$ARGV[0]") if $#ARGV >= 0;

use Socket;

$sockaddr = 'S n a4 x8';
chop($hostname = `hostname`);

($name, $aliases, $proto) = getprotobyname('tcp');
($name, $aliases, $port) = getservbyname($port, 'tcp')
	unless $port =~ /^\d+$/;
($name, $aliases, $type, $len, $thisaddr) = gethostbyname($hostname);
($name, $aliases, $type, $len, $thataddr) = gethostbyname($them);

socket(S, &PF_INET, &SOCK_STREAM, $proto) || &errexit("socket: $!\n");

$this = pack($sockaddr, &AF_INET, 0, $thisaddr);
bind(S, $this) || &errexit("bind: $!\n");

$that = pack($sockaddr, &AF_INET, $port, $thataddr);
connect(S, $that) || &errexit("connect: $!\n");

select(S); $| = 1; select(STDOUT);

$buffer = '';
while (1)
{
	$rin = '';
	vec($rin, fileno(S), 1) = 1;
	$nfound = select($rout=$rin, $wout=$rin, undef, undef);
	if (vec($rout, fileno(S), 1)) {
		print STDERR "$buffer\n" if
			defined($nread = sysread(S, $buffer, 8192));
	}
	if (vec($wout, fileno(S), 1)) {
		$nread = read(STDIN, $buffer, 8192);
		last if $nread == 0;
		&errexit("write: $!\n") unless
			defined($written = syswrite(S,$buffer,$nread));
	}
}
close(S);
exit 0;

sub errexit
{
	print STDERR @_;
	exit 2;
}
