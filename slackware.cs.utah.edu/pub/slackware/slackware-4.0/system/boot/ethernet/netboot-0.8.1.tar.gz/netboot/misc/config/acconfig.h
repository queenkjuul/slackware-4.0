/* acconfig.h */

/* Define if compiler can use __atribute__((packed)) */
#undef USE_PACKED

/* Define if compiler can use pragma pack(1) */
#undef USE_PRAGMA_PACK

/* Define if compiler can use pragma options align=packed */
#undef USE_PRAGMA_ALIGN

/* Define if system has u_int8_t, u_int16_t and u_int32_t defined */
#undef USE_U_INT

/* Define if system has __u8, __u16 and __u32 defined */
#undef USE__UXX

/* Define if system cannot access misaligned data and has to use memcpy */
#undef USE_COPY

/* Define if system has getopt_long */
#undef HAVE_GETOPT_LONG

