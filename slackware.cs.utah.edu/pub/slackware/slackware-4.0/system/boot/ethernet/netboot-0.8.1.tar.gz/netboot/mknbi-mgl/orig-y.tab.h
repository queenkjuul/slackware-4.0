typedef union {
	struct symlist  *symlist;	/* List of symbols in variable decl */
	struct typelist *typelist;	/* List of types in array decl */
	struct typesdef *type;		/* Expression type */
	struct sym      *symbol;	/* Pointer to symbol */
	struct expr     *expr;		/* expression tree */
	char            *inaddr;	/* IP address */
	char            *string;	/* string buffer */
	char             chrarg;	/* character argument */
	int              intarg;	/* integer argument */
	int              op;		/* arithmetic operation */
} YYSTYPE;
#define	QSTRING	258
#define	NUM	259
#define	INADDR	260
#define	ID	261
#define	CHR	262
#define	ADDOP	263
#define	MULOP	264
#define	COMPARISON	265
#define	OROP	266
#define	XOROP	267
#define	ANDOP	268
#define	NOTOP	269
#define	VAR	270
#define	CONST	271
#define	TYPE	272
#define	SCREEN	273
#define	PROCEDURE	274
#define	FUNCTION	275
#define	ARRAY	276
#define	RECORD	277
#define	RETURN	278
#define	RESTART	279
#define	PRINT	280
#define	SELECT	281
#define	ITEM	282
#define	IF	283
#define	ELSE	284
#define	GOTOXY	285
#define	TIMEOUT	286
#define	LOAD	287
#define	FROM	288
#define	GATEWAY	289
#define	GET	290
#define	MENU	291
#define	REPEAT	292
#define	UNTIL	293
#define	AT	294
#define	WITH	295
#define	THEN	296
#define	WHILE	297
#define	DO	298
#define	BREAK	299
#define	DEFAULT	300
#define	ASSIGN	301
#define	OF	302
#define	CBEGIN	303
#define	END	304
#define	DOTS	305
#define	THEN_PREC	306
#define	UMINUS	307


extern YYSTYPE yylval;
