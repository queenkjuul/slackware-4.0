/* 
   Line, part of the Lilo-colors package.
   Copyright : GNU General Public License see file COPYING
   Ron Bessems <R.E.M.W.Bessems@stud.tue.nl>
   
   Usage : line <number of chars> <ascii code of char> 
*/



#include <stdio.h>
#include <stdlib.h>

int main(int argc,char **argv)
{
	int aantal;
	int karak;
	int loops;
	int loop;	
	int teller;
	char ch;
	char buffer[2];

 	aantal=0;
	karak=0;
	loops=0;
	
	if ( ((argc-1)%2) != 0)
	{
		printf("Usage: line <number of chars> <ascii code if char>"\
                       " ( repeat this as many times as you like ) \n");
		return 1;
	}
	loops=(argc-1)/2;
	for (loop=0;loop<loops;loop++)
	{	
		
		aantal = atoi(argv[1+loop*2]);
		karak  = atoi(argv[2+loop*2]);
		buffer[0] = karak;
		buffer[1] = 0;
		for (teller=0; teller < aantal;teller++)
		{
			printf(buffer);
		}
	}
}

			

	
