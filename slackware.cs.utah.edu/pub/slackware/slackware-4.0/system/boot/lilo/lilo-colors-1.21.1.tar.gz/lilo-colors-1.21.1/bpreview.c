/* Bootmessage Previewer
   Contributed to Lilo-Colors 1.21.0 by Egmont Koblinger 
   29-3-1999

   To display the bootmessage correctly you need to
   set the consolefonts unimap to none :
      setfont default8x16 -u empty 
   To reset the console font to normal type 
      setfont 
  
   Usage: bpreview <filename>
   
*/
#include <stdio.h>

int i;
int first_byte=1;
int column=0;
int trans[8]={0,4,2,6,1,5,3,7};


void color (int i)
{
    int fore, back, bright, blink;
    back=trans[(i>>4)%8];
    fore=trans[i%8];
    bright=(i>>3)%2;
    blink=(i>>7)%2;
    printf("\e[0;%s%s%d;%dm",
        bright?"1;":"", blink?"5;":"", 30+fore, 40+back);
    return;
}

void help()
{
    printf("Lilo bootmessage previewer\n");
    printf("bpreview comes with ABSOLUTELY NO WARRANTY.\n");
    printf("\nUsage: bpreview filename\n\n");
    printf("If the message isn't displayed correctly e.g. the \n");
    printf("extended characters are mapped into letters with accents\n");
    printf("you need to type setfont default8x16 -u empty.\n\n");

}  
    

int main (int argc, char *argv[])
{
    FILE *in;

    if (argc==2)
    {
	if (strcmp(argv[1],"--help")!=0)
	{
    		in=fopen(argv[1],"r");
        }
	else
	{
		help();
		return 0;
	}
    }
    else
    {
		help();
		return 0;
    }
    if (in==NULL)
    {
	printf("Error opening bootmessage file.\n");
	return -1;
    }	

    while ((i=getc(in)) != EOF) {
        switch (i) {
            case 253:
                if (first_byte) getc(in);
                else { putchar(i); column++; }
                break;
            case 250:
                color(getc(in));
                printf("\e[H\e[J");
                column=0;
                break;
            case 251:
                color(getc(in));
                break;
            case '\n':
                putchar(i);
                column=0;
                break;
            default:
                putchar(i);
                column++;
                break;
        }
        first_byte=0;
        if (column==80) { putchar('\n'); column=0; }
    }
    printf("boot: ");
    fclose(in);
    getchar();
   
    return 0;
}

