/*
 * about.h
 *
 * rebooter about dialog.
 *
 * Copyright (c) Tuomo Valkonen 1997-1998.
 *
 * See the documentation for more information.
 */
 
#ifndef _ABOUT_H
#define _ABOUT_H

#include <qt/qdialog.h>
#include <qt/qpushbt.h>
#include <qt/qpixmap.h>

class AboutDialog:public QDialog{
	Q_OBJECT
private:
	QPushButton*ok;
	QPixmap*bg;
public:
public:
	AboutDialog(QWidget *parent=0,const char *name=0);
	~AboutDialog();
protected:

public slots:
signals:
};

#endif /* _ABOUT_H */
