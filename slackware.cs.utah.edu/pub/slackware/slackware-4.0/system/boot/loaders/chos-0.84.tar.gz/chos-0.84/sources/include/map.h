/*
 * include/map.h
 *
 * Copyright (c) Tuomo Valkonen 1996-1998.
 */
  
#ifndef _MAP_H
#define _MAP_H

#include "mapfile.h"

extern GEOMETRY		mapgeo;
extern int		finish_map();
extern void		map_initialize();
extern int		map_get_sector(MF_KernelSector**);
extern int		resize(int,int);

extern MF_KernelSector**map;
extern MF_HeaderSector* mh; // =*map
extern MF_ImageSector*	im;

#endif