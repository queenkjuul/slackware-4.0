/****************************************************************************
** Rebooter meta object code from reading C++ file 'rebooter.h'
**
** Created: Wed Oct 14 22:46:21 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.18 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include "rebooter.h"
#include <qmetaobj.h>


const char *Rebooter::className() const
{
    return "Rebooter";
}

QMetaObject *Rebooter::metaObj = 0;

void Rebooter::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("Rebooter","QWidget");
    if ( !QWidget::metaObject() )
	QWidget::initMetaObject();
    typedef void(Rebooter::*m1_t0)();
    typedef void(Rebooter::*m1_t1)();
    typedef void(Rebooter::*m1_t2)(BootItem*);
    m1_t0 v1_0 = &Rebooter::about_clicked;
    m1_t1 v1_1 = &Rebooter::ok_clicked;
    m1_t2 v1_2 = &Rebooter::toggled;
    QMetaData *slot_tbl = new QMetaData[3];
    slot_tbl[0].name = "about_clicked()";
    slot_tbl[1].name = "ok_clicked()";
    slot_tbl[2].name = "toggled(BootItem*)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    metaObj = new QMetaObject( "Rebooter", "QWidget",
	slot_tbl, 3,
	0, 0 );
}


const char *BootItem::className() const
{
    return "BootItem";
}

QMetaObject *BootItem::metaObj = 0;

void BootItem::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QRadioButton::className(), "QRadioButton") != 0 )
	badSuperclassWarning("BootItem","QRadioButton");
    if ( !QRadioButton::metaObject() )
	QRadioButton::initMetaObject();
    typedef void(BootItem::*m1_t0)();
    m1_t0 v1_0 = &BootItem::item_clicked;
    QMetaData *slot_tbl = new QMetaData[1];
    slot_tbl[0].name = "item_clicked()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    typedef void(BootItem::*m2_t0)(BootItem*);
    m2_t0 v2_0 = &BootItem::toggled;
    QMetaData *signal_tbl = new QMetaData[1];
    signal_tbl[0].name = "toggled(BootItem*)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    metaObj = new QMetaObject( "BootItem", "QRadioButton",
	slot_tbl, 1,
	signal_tbl, 1 );
}

#if !defined(Q_MOC_CONNECTIONLIST_DECLARED)
#define Q_MOC_CONNECTIONLIST_DECLARED
#include <qlist.h>
#if defined(Q_DECLARE)
Q_DECLARE(QListM,QConnection);
Q_DECLARE(QListIteratorM,QConnection);
#else
// for compatibility with old header files
declare(QListM,QConnection);
declare(QListIteratorM,QConnection);
#endif
#endif

// SIGNAL toggled
void BootItem::toggled( BootItem* t0 )
{
    QConnectionList *clist = receivers("toggled(BootItem*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(BootItem*);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}
