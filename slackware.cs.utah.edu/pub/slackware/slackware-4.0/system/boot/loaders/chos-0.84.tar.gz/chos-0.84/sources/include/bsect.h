/*
 * include/bsect.h
 *
 * structure of the bootsector.
 *
 * Copyright (c) Tuomo Valkonen 1996-1998.
 */

#ifndef _CHOS_BSECT_H
#define _CHOS_BSECT_H

typedef struct{
	char	code[2];
	char	id[3];
	char	type;
	char	major,minor;
	char	stage2_drive;
	char	map_drive;
	char	emerg_drive;
	char	pad;
	ulong	stage2_sects[STAGE2SECTS];
	ulong	map_sects[2];
	ulong	emerg_sect;
}ChosBsect;

#endif