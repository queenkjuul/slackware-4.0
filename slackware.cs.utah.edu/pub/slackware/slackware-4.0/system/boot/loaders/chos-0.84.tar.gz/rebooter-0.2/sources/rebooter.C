/*
 * rebooter.C
 *
 * Rebooter main file
 *
 * Copyright (c) Tuomo Valkonen 1997-1998.
 *
 * See the documentation for more information.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <unistd.h>
#include <sys/time.h>
#include <assert.h>
#include <pwd.h>
#include <sys/types.h>
#include <fstream.h>

#include "rebooter.h"

#ifdef KDE_VERSION
 #include <kapp.h>
 #define APPLICATION KApplication
#else
 #include <qt/qapp.h>
 #define APPLICATION QApplication
#endif

bool Rebooter::verify_action=0;
bool Rebooter::no_gui=1;

void Rebooter::addItem(BootItem*i)
{
	if(nitems==0){
		items=last=checked=i;
		i->prev=i->next=NULL;
		i->setChecked(TRUE);
		iconview->setPixmap(i->icon());
	}else{
		i->setChecked(FALSE);
		i->next=NULL;
		last->next=i;
		i->prev=last;
		last=i;
	}
	i->par=this;
	nitems++;
	
	connect(i,SIGNAL(toggled(BootItem*)),SLOT(toggled(BootItem*)));
}

void Rebooter::removeItem(BootItem*i)
{
	if(i->prev)
		i->prev->next=i->next;
	else
		items=i->next;
		
	if(i->next)
		i->next->prev=i->prev;
	else
		last=i->prev;
		
	i->par=NULL;
	i->prev=i->next=NULL;
	nitems--;
}

void Rebooter::addChosItem(Mapfile*mf,int imgnr,const char*name,int type)
{
	if(no_gui){
		cerr<<"  "<<imgnr<<". "<<name<<"\n";
		return;
	}
	QPixmap*icon;
	
	switch(type){
	case BIT_LINUX:
		icon=BootItem::icon_linux;break;
	case BIT_BOOTSECT:
	default:
		icon=BootItem::icon_dos;break;
	};
	Boot_ChosReboot*item=new Boot_ChosReboot(mf,name,imgnr,icon,this);
	
	if(!first_chos_image)
		first_chos_image=item;
		
	addItem(item);
}


static int find_user(const char*filename,const char*username)
{
	class	ifstream	file(filename);
	char	tmp[256];
	
	if(!file.good())
		return -1;
	
	while(!file.eof()){
		file.getline(tmp,256);
		if(!strcmp(tmp,username))
			return 1;
	}
	return 0;
}
		
static void validate_user(void)
{
	uid_t	uid=getuid();
	
	if(uid==0)
		return;
		
	struct passwd*pwd=getpwuid(uid);
	
	if(!pwd)
		FATAL(TR("Couldn't get password file entry"));
	
	int	allow=find_user("/etc/rebooter.allow",pwd->pw_name);
	int	deny=find_user("/etc/rebooter.deny",pwd->pw_name);
	
	if(allow==-1){	// File doesn't exist
		if(deny==1)
			FATAL(TR("You're not permitted to use rebooter"));
		return;
	}
	if(allow==0)
		FATAL(TR("You're not permitted to use rebooter"));
		
	if(deny==1)
		FATAL(TR("You're not permitted to use rebooter"));
		
	return;
}


static char*chos_map="/boot/chos.map";
static char*chos_config="/etc/chos.conf";
static char*boot_image_name=NULL;
static int	command=0;

static bool parse_config=
#ifdef PARSE_CONFIG
 TRUE
#else
 FALSE
#endif
;

static void usage()
{
	cerr<<TR("\nRebooter 0.2, Copyright (c) Tuomo Valkonen 1997-1998.\n\n"
			"Usage: rebooter [command] [options]\n\n"
			"Commands:\n"
			"\t-boot -b <imgname>\tBoot an image\n"
			"\t-reboot -r\t\tReboot the system\n"
			"\t-shutdown -halt -s\tShutdown the system\n"
			"\t-list -l\t\tList images\n"
			"Options:\n"
			"\t-c <file>\t\tSet chos config file\n"
			"\t-m <file>\t\tSet chos mapfile\n"
			"\t-noconfig\t\tDon't read config file\n"
			"\t-verify\n"
			"\t-noverify\t\tVerify/don't verify action\n\n");
	exit(0);
}

int process_args(int argc,char*argv[])
{
	int	i=1;
	
	if(argc<2)
		return 0;
	
	if(command==2)
		i+=2;
	else if(command)
		i++;

	for(;i<argc;i++){
		if(!strcmp(argv[i],"-m")){		
			if(++i>=argc)return 1;
			chos_map=argv[i];
		}else if(!strcmp(argv[i],"-c")){
			if(++i>=argc)return 1;
			chos_config=argv[i];
			parse_config=TRUE;
		}else if(!strcmp(argv[i],"-noconfig"))
			parse_config=FALSE;
		else if(!strcmp(argv[i],"-verify"))
			Rebooter::verify_action=1;
		else if(!strcmp(argv[i],"-noverify"))
			Rebooter::verify_action=0;
		else
			return 1;
	}
	return 0;
}		

bool check_command(int argc,char**argv)
{
	command=0;
	
	if(argc<2)
		return FALSE;
	
	if(!strcmp(argv[1],"-help"))
		usage();
		
	if(!strcmp(argv[1],"-list") || !strcmp(argv[1],"-l"))
		command=1;
	
	if(!strcmp(argv[1],"-boot") || !strcmp(argv[1],"-b")){
		if(argc<3)
			usage();
		boot_image_name=argv[2];
		command=2;
	}
	
	if(!strcmp(argv[1],"-reboot") || !strcmp(argv[1],"-r"))
		command=3;
		
	if(!strcmp(argv[1],"-shutdown") || !strcmp(argv[1],"-halt") || !strcmp(argv[1],"-s"))
	    command=4;
	    
	if(command){
		Rebooter::no_gui=TRUE;
	   	return TRUE;
	}
	   	
	return FALSE;
}
	
int search_environ()
{
	char*value;
	if(value=getenv("REBOOTER_VERIFY")){
		if(!strcmp(value,"1") || !strcasecmp(value,"true"))
			Rebooter::verify_action=1;
		else
			Rebooter::verify_action=0;
	}
	if(value=getenv("REBOOTER_CONFIG")){
		parse_config=TRUE;
		chos_config=value;
	}
	if(value=getenv("REBOOTER_MAP"))
		chos_map=value;
}

QString pixmap_path(PIXMAP_PATH);

int main(int argc,char** argv)
{
	APPLICATION*	a;

//#ifndef KDE_VERSION
	textdomain("rebooter");
//#endif
	if(!check_command(argc,argv)){
		a=new APPLICATION(argc,argv); 
#ifdef KDE_VERSION
		pixmap_path=KApplication::kdedir()+PIXMAP_PATH;
#endif
		Rebooter::no_gui=FALSE;
	}
	
	validate_user();
	
	search_environ();
	
	if(process_args(argc,argv))
		usage();

	if(Rebooter::no_gui){
		switch(command){
		case 1:
		 {
			Mapfile mf(chos_map);
			if(!mf.isOpen())break;
			mf.list();mf.close();
			break;
		 }
		case 2:
		 {
			Mapfile mf(chos_map);
			if(!mf.isOpen())break;
			if(!mf.setSingleShot(boot_image_name))break;
			mf.close();
		 }
		case 3:
			BootItem::doReboot();break; // should never return...
		case 4:
			BootItem::doShutdown();break;
		default:
			usage(); // Should never get here...
		}
		return 0;
	}

	Mapfile		mf(chos_map);
	
	if(!mf.isOpen())
		return 0;

	BootItem::initIcons();

	Rebooter		r;

	r.addItem(new Boot_Shutdown		(TR("Shutdown the system"),&r));
	r.addItem(new Boot_Reboot		(TR("Reboot the system"),&r));

	if(!mf.parse(r))
		return 0;
		
	if(parse_config)
		r.parseConfig(chos_config);
	
	r.fit();
	a->setMainWidget(&r);
	r.show();
	return a->exec();
}
