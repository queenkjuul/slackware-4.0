/*
 * about.C
 *
 * rebooter about dialog
 *
 * Copyright (c) Tuomo Valkonen 1997-1998.
 *
 * See the documentation for more information
 */
 

#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <unistd.h>
#include <sys/time.h>

#include "rebooter.h"
#include "about.h"

#include <qt/qpixmap.h>
#include <qt/qmsgbox.h>

#define AW 470
#define AH 260

AboutDialog::AboutDialog(QWidget *parent, const char *name)
:QDialog(parent, name,TRUE)
{
	QString bgpixmap=pixmap_path+"/rebooter.xpm";
	
	bg=new QPixmap(bgpixmap);

	if(bg->isNull())
		ERROR(TR("Couldn't load pixmap %s"),(const char*)bgpixmap);

	setCaption(TR("About rebooter..."));
	setFixedSize(AW,AH);
	setBackgroundColor(QColor("black"));
	setBackgroundPixmap(*bg);
	
	ok=new QPushButton(TR("Ok"),this);
	
	ok->setGeometry(AW-80-5,AH-25-5,80,25);
	
	connect(ok,SIGNAL(clicked()),SLOT(accept()));
	
	exec();
}


AboutDialog::~AboutDialog()
{
	delete bg;
}
