/*
 * boot.C
 *
 * Rebooter booting functions
 *
 * Copyright (c) Tuomo Valkonen 1997-1998.
 *
 * See the documentation for more information
 */
 

#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <unistd.h>
#include <sys/time.h>
#include <assert.h>
#include "rebooter.h"

#define PROGRAM_SHUTDOWN	"/sbin/halt"
#define PROGRAM_REBOOT		"/sbin/reboot"

QPixmap* BootItem::icon_shutdown;
QPixmap* BootItem::icon_reboot;
QPixmap* BootItem::icon_linux;
QPixmap* BootItem::icon_dos;
QPixmap* BootItem::icon_windoze;

void BootItem::initIcons()
{
#define INIT_ICON(x)	({									\
	QString tmp(pixmap_path + QString("/" #x ".xpm"));		\
	icon_##x=new QPixmap(tmp);								\
	if(icon_##x->isNull())									\
		ERROR(TR("Couldn't load pixmap %s"),(const char*)tmp);	\
	})
	
	INIT_ICON(shutdown);
	INIT_ICON(reboot);
	INIT_ICON(linux);
	INIT_ICON(dos);
	INIT_ICON(windoze);
	
#undef INIT_ICON
}

void BootItem::doShutdown()
{
	execl(PROGRAM_SHUTDOWN,PROGRAM_SHUTDOWN,NULL);
}

void BootItem::doReboot()
{
	execl(PROGRAM_REBOOT,PROGRAM_REBOOT,NULL);
}

void Boot_Shutdown::doit()
{
	doShutdown();
}

void Boot_Reboot::doit()
{
	doReboot();
}

void Boot_ChosReboot::doit()
{
	if(mapfile){
		mapfile->setSingleShot(os_nr);
		mapfile->close();
	}

	doReboot();
}

char* Boot_ChosReboot::start_str(const char*osname)
{
	const char*str=TR("Start ");
	int len=strlen(str);
	
	char*	n=new char[len+strlen(osname)+1];
	
	memcpy(n,str,len);
	strcpy(n+len,osname);
	
	return n;
}

BootItem::BootItem(const char*text,Rebooter*parent,const char*name)
:QRadioButton(text,parent,name)
{
	resize(fontMetrics().width(text)+30,fontMetrics().height()+4);
	
	connect(this,SIGNAL(clicked()),SLOT(item_clicked()));
}

void BootItem::item_clicked()
{
	emit toggled(this);
}

const char* Boot_ChosReboot::verifyString()
{
	static char str[256];
	
	sprintf(str,TR("Are you sure you want to start %s?"),os_name);
	
	return str;
}

const char* Boot_Shutdown::verifyString()
{
	return TR("Are you sure you want to shutdown the system?");
}

const char* Boot_Reboot::verifyString()
{
	return TR("Are you sure you want to reboot the system?");
}
