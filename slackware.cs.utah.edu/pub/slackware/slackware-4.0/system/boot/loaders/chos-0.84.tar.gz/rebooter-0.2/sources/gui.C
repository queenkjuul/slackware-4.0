/*
 * gui.C
 *
 * Rebooter GUI
 *
 * Copyright (c) Tuomo Valkonen 1997-1998.
 *
 * See the documentation for more information.
 */
 

#include <fstream.h>
#include <assert.h>
#include <stdio.h>

#include "rebooter.h"
#include "about.h"

#ifdef KDE_VERSION
 #include <kmsgbox.h>
 #include <kapp.h>
#else
 #include <qt/qmsgbox.h>
 #include <qt/qapp.h>
#endif

#include <qt/qkeycode.h>

#define BW	80
#define BH	25
#define PAD	5

#define ICON_WIDTH	48
#define ICON_HEIGHT	48
#define ICON_X		PAD
#define ICON_Y		(PAD+10)

static inline void set_button_size(QPushButton*b)
{
	int	w=b->fontMetrics().width(b->text())+2*PAD;
	
	if(w+2*PAD<BW)
		w=BW;
		
	int h=b->fontMetrics().height()+2*PAD;
	
	if(h+2*PAD<BH)
		h=BH;

	b->resize(w,h);
}

Rebooter::Rebooter(QWidget*parent,const char*name)
:QWidget(parent,name,WStyle_DialogBorder|WStyle_Customize)
{
	items=last=checked=NULL;
	nitems=0;
	first_chos_image=NULL;
	
	setCaption("Rebooter");
	
	ok=new QPushButton(TR("Ok"),this);
	cancel=new QPushButton(TR("Cancel"),this);
	about=new QPushButton(TR("About"),this);
	hline=new QFrame(this);
	iconview=new QLabel(this);
	
	set_button_size(ok);
	set_button_size(about);
	set_button_size(cancel);
	
	hline->setLineWidth(2);
	hline->setFrameStyle(QFrame::HLine | QFrame::Sunken);

	setMinimumSize(	ok->width()+cancel->width()+about->width()+5*PAD+100,
					BH+6*PAD);
	
	connect(ok,SIGNAL(clicked()),SLOT(ok_clicked()));
	connect(cancel,SIGNAL(clicked()),qApp,SLOT(quit()));
	connect(about,SIGNAL(clicked()),SLOT(about_clicked()));
}
#undef BH

#define BH ok->height()

void Rebooter::fit()
{
	int iw=0;
	int w=0,h=BH+4*PAD+2*10;
	int	y,x;
	BootItem*i;
	
	for(i=items;i;i=i->next){
		if(i->width()>iw)
			iw=i->width();
		h+=i->height()+PAD;
	}
	w=iw+2*PAD+ICON_WIDTH+ICON_X;
	if(w<minimumSize().width())
		w=minimumSize().width();
		
	if(h<minimumSize().height())
		h=minimumSize().height();
		
	setFixedSize(w,h);
	
	x=w/2-iw/2;
	if(x<PAD+ICON_X+ICON_WIDTH)
		x=(w-PAD-ICON_X-ICON_WIDTH)/2-iw/2+PAD+ICON_X+ICON_WIDTH;
		
	for(i=items,y=PAD+10;i;i=i->next){
		i->move(x,y);
		y+=i->height()+PAD;
	}

	hline->setGeometry(PAD,h-BH-3*PAD,w-2*PAD,2);
	
	about->move(PAD,h-BH-PAD);
	cancel->move(w-PAD-cancel->width(),h-BH-PAD);
	ok->move(cancel->x()-ok->width()-PAD,h-BH-PAD);
	
	iconview->setGeometry(ICON_X,ICON_Y,ICON_WIDTH,ICON_HEIGHT);
}

void Rebooter::ok_clicked()
{
	assert(checked);
	
	if(verify_action && !yesNo("%s",checked->verifyString()))
		return;
		
	hide();
	checked->doit();
	exit(0); // doit should never return...
}

void Rebooter::about_clicked()
{
	AboutDialog	a(this);
}

void Rebooter::toggled(BootItem*item)
{
	BootItem*i;
	
	if(checked)
		checked->setChecked(FALSE);
	checked=item;

	iconview->setPixmap(item->icon());
}

void Rebooter::keyPressEvent(QKeyEvent*e)
{
	BootItem*	item;
	
	switch(e->key()){
	case Key_Escape:
		exit(0);
	case Key_Enter:
	case Key_Return:
		ok_clicked();
	case Key_Down:
		if(checked->next)
			item=checked->next;
		else
			item=items;
		item->setChecked(TRUE);
		toggled(item);
		break;
	case Key_Up:
		if(checked->prev)
			item=checked->prev;
		else
			item=last;
		item->setChecked(TRUE);
		toggled(item);
		break;
	default:
		e->ignore();
	}
}

// Misc
/////////
static char tmpstr[512];

void Rebooter::error(const char*fmt,...)
{
	va_list args;
	va_start(args,fmt);
	
	if(no_gui){
		vfprintf(stderr,fmt,args);
		fputc('\n',stderr);
	}else{
		vsprintf(tmpstr,fmt,args);

#ifdef KDE_VERSION
		KMsgBox::message(NULL,"Rebooter",tmpstr,KMsgBox::EXCLAMATION);
#else
		QMessageBox::warning(NULL,"Rebooter",tmpstr);
#endif
	}
	
	va_end(args);
}

void Rebooter::fatal(const char*fmt,...)
{
	va_list args;
	va_start(args,fmt);
	
	if(no_gui){
		vfprintf(stderr,fmt,args);
		fputc('\n',stderr);
	}else{
		vsprintf(tmpstr,fmt,args);
	
#ifdef KDE_VERSION
		KMsgBox::message(NULL,"Rebooter",tmpstr,KMsgBox::STOP);
#else
		QMessageBox::critical(NULL,"Rebooter",tmpstr);
#endif
	}
	
	va_end(args);
	
	exit(0);
}


bool Rebooter::yesNo(const char*fmt,...)
{
	va_list args;
	va_start(args,fmt);
	int button;
	
	if(no_gui){
		vfprintf(stderr,fmt,args);
		fputc('\n',stderr);
		button=getchar();
		if(button=='y' || button=='Y' || button=='\n')
			button=0;
		else
			button=1;
	}else{
		vsprintf(tmpstr,fmt,args);
	
#ifdef KDE_VERSION
		button=KMsgBox::yesNo(NULL,"Rebooter",tmpstr,KMsgBox::QUESTION,TR("Yes"),TR("No"))-1;
#else	
		button=QMessageBox::information(NULL,"Rebooter",tmpstr,TR("Yes"),TR("No"));
#endif		
	}
	va_end(args);
	
	return (button==0);
}