/*
 * rebooter.h
 *
 * Rebooter main header file.
 *
 * Copyright (c) Tuomo Valkonen 1997-1998.
 *
 * See the documentation for more information.
 */
 
#ifndef _REBOOTER_H
#define _REBOOTER_H

#include <iostream.h>

#include <qt/qwidget.h>
#include <qt/qpushbt.h>
#include <qt/qradiobt.h>
#include <qt/qframe.h>
#include <qt/qpixmap.h>
#include <qt/qlabel.h>
#include <qt/qmsgbox.h>

#include <stdarg.h>
#include <libintl.h>

#ifdef KDE_VERSION
 #include<kapp.h>
 #define TR(x) (kapp?klocale->translate(x):gettext(x))
#else
 #define TR(x) gettext(x)
#endif

#define ERROR		Rebooter::error
#define FATAL		Rebooter::fatal
#define YESNO		Rebooter::yesno

class BootItem;
class Boot_Shutdown;
class Boot_Reboot;
class Boot_ChosReboot;
class Rebooter;

#include "chosfile.h"

extern QString	pixmap_path;

// The rebooter main class
////////////////////////////
class Rebooter:public QWidget{
	Q_OBJECT
private:
	QPushButton	*ok,*cancel,*about;
	QFrame		*hline;
	QLabel		*iconview;
	BootItem*	items,*last,*checked;
	int			nitems;
	Boot_ChosReboot*first_chos_image;
	
public:
	static bool	verify_action;
	static bool	no_gui;
public:
	Rebooter(QWidget *parent=0,const char *name=0);

	void	addItem(BootItem*i);
	void	removeItem(BootItem*i);
	void	addChosItem(Mapfile*mf,int,const char*,int);
	
	void	fit();

	void	parseConfig(const char*cfgfile);

	static void error(const char*,...);
	static void fatal(const char*,...);
	static bool	yesNo(const char*,...);
	
protected:
	void	keyPressEvent(QKeyEvent*);
	
public slots:
	void about_clicked();
	void ok_clicked();
	void toggled(BootItem*i);
signals:

};

// BootItem - base class for Boot_Shutdown, Boot_Reboot and Boot_ChosReboot
/////////////////////////////////////////////////////////////////////////////
class BootItem:public QRadioButton{
	Q_OBJECT
protected:
	Rebooter*	par;
	BootItem*	next;
	BootItem*	prev;
	QPixmap*	item_icon;
public:
	BootItem(const char*text,Rebooter*parent,const char*name=0);
	
	~BootItem(){if(par)par->removeItem(this);};

	virtual void doit()=0;
	
	virtual QPixmap& icon()=0;
	
	virtual const char* verifyString()=0;
	
public:
	static QPixmap*	icon_shutdown;
	static QPixmap*	icon_reboot;
	static QPixmap*	icon_linux;
	static QPixmap*	icon_dos;
	static QPixmap*	icon_windoze;

	static void		initIcons();
	static void		doShutdown();
	static void		doReboot();
	
public slots:
	void item_clicked();
	
signals:
	void toggled(BootItem*i);
public:
	friend class Rebooter;
};

// Boot_Shutdown - this item shuts down the system
////////////////////////////////////////////////////
class Boot_Shutdown:public BootItem{
public:
	virtual void doit();
	virtual QPixmap& icon(){return *icon_shutdown;};
	virtual const char* verifyString();
	
	Boot_Shutdown(const char*text,Rebooter*parent,const char*name=0)
		:BootItem(text,parent,name){};	
};

// Boot_Reboot - this item reboots the system
///////////////////////////////////////////////
class Boot_Reboot:public BootItem{
public:
	virtual void doit();
	virtual QPixmap& icon(){return *icon_reboot;};
	virtual const char* verifyString();
	
	Boot_Reboot(const char*text,Rebooter*parent,const char*name=0)
		:BootItem(text,parent,name){};	
};

// Boot_ChosReboot - this type of items boot an os found in chos mapfile
//////////////////////////////////////////////////////////////////////////
class Boot_ChosReboot:public BootItem{
private:
	QPixmap*	os_icon;
	const char*	os_name;
	int			os_nr;
	Mapfile*	mapfile;
public:
	virtual void doit();
	virtual QPixmap& icon(){return *os_icon;};
	virtual const char* verifyString();
	
	Boot_ChosReboot(Mapfile*mf,const char*osname,Rebooter*parent,const char*name=0)
		:BootItem(start_str(osname),parent,name),
		 mapfile(mf),
		 os_icon(icon_linux),
		 os_name(osname){};

	Boot_ChosReboot(Mapfile*mf,const char*osname,int nr,QPixmap*i,Rebooter*parent,const char*name=0)
		:BootItem(start_str(osname),parent,name),
		 mapfile(mf),
		 os_icon(i),
		 os_name(osname),
		 os_nr(nr){};

private:
	static char* start_str(const char*);
	
	friend class Rebooter;
};

#endif /* _REBOOTER_H */
