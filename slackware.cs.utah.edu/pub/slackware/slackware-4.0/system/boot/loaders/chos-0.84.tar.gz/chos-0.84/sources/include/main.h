/*
 * include/main.h
 *
 * Copyright (c) Tuomo Valkonen 1996-1998.
 */
  

#ifndef _MAIN_H
#define _MAIN_H

#include"mapfile.h"
#include"install.h"

#define MAXLINELEN	512		/* max len of line in cfg file	*/

#define D(x) fprintf(stderr,(x))

extern int 	line_no;
extern char 	*cfgfname;
extern int 	noboot;
extern char 	(*background)[25][80][2];
extern int	testing,view;
extern char	latin2ibm[256];

int  main(int argc, char *argv[]);
void die(int err, char *parm,...);
void process_file( FILE *cfgf);
int  read_line( FILE *file, char * line );
void cfgsyntax(char *moremsg,...);
void verbose(char*,...);
void warn(char*,...);
#define cfgerror cfgsyntax
void continue_yn(void);
void clear_bg();
void finish_bg();
void view_it(void);
char*next_ent(char*);
char*strip_whitespace(char*);

extern char* color_list[];

struct cfgstr_struct{
	char*	str;
	void	(*doit)(char *);
};

struct icfgstr_struct{
	char*	str;
	void	(*doit)(MF_ImageDes*,char*);
};

struct imagestr_struct{
	char*			str;
	char*			name;
	int			type;
	struct icfgstr_struct*	cfg;
	void			(*init)(MF_ImageDes*);
	void			(*end)(MF_ImageDes*);
};

#endif
