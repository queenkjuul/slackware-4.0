/*
 * chos_configfile.C
 *
 * Reads choose-OS configuration file.
 *
 * This expects that the file has no syntax errors or stuff.
 *
 * Copyright (c) Tuomo Valkonen 1997-1998.
 *
 * See the documentation for more information.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <assert.h>

#include "rebooter.h"

char* itypes[4]={
	"linux",
	"big_linux",
	"bootsect",
	"bootfile"
};

#define NITYPES	(sizeof(itypes)/sizeof(char*))

static inline char* strip_whitespace(char*str)
{
	while(*str==' ' || *str=='\t'){
		if(*str=='\0')
			break;
		str++;
	}
	return str;
}

#define MAXLINELEN	512

static int read_line(FILE*f,char*line);

static int line_no;

void Rebooter::parseConfig(const char*file)
{
	char 	tmps[MAXLINELEN];
	char*	a;
	int  	read=1,loop,i;
	bool 	in_image=0;
	FILE*	filp;
	QPixmap*new_icon=NULL;
	bool	disabled=FALSE;
	
	line_no=0;
	
	Boot_ChosReboot*img=first_chos_image;
	
	if(!img)
		return;
		
	if(!(filp=fopen(file,"r"))){
		ERROR(TR("Couldn't open chos configuration file %s"),file);
		return;
	}
	
	while(read!=0){
		read=read_line(filp,tmps);
		line_no++;
		
		if( tmps[0]=='\0' )continue;
		
		if(in_image){
			if(*tmps=='}' && *(tmps+1)=='\0'){
				in_image=0;
				if(new_icon && !disabled)
					img->os_icon=new_icon;
				if(disabled){
					Boot_ChosReboot*tmp=(Boot_ChosReboot*)img->next;
					delete img;
					img=tmp;
				}else
					img=(Boot_ChosReboot*)img->next;
					
				if(!img){
					fclose(filp);
					return;
				}
				new_icon=NULL;
				disabled=FALSE;
				continue;
			}
			char*line=tmps;
			if(strncmp(line,"rebooter.",9))
				continue;
			line+=9;
			if(!strncmp(line,"disable",7))
				disabled=TRUE;
				
			else if(!strncmp(line,"icon=",5) && !new_icon){
				line=strip_whitespace(line+5);				
				if(!strcmp(line,"builtin_shutdown"))
					new_icon=BootItem::icon_shutdown;
				else if(!strcmp(line,"builtin_reboot"))
					new_icon=BootItem::icon_reboot;
				else if(!strcmp(line,"builtin_linux"))
					new_icon=BootItem::icon_linux;
				else if(!strcmp(line,"builtin_dos"))
					new_icon=BootItem::icon_dos;
				else if(!strcmp(line,"builtin_windoze"))
					new_icon=BootItem::icon_windoze;
				else{
					QString tmp;
					if(*line!='/')
						tmp=pixmap_path+"/"+line;
					else
						tmp=line;
						
					QPixmap*pm=new QPixmap(tmp);
					if(pm->isNull())
						ERROR(TR("Couldn't load pixmap %s"),(const char*)tmp);
					else
						new_icon=pm;
				}
			}
			continue;
		}
		
		loop=0;
		while(loop<NITYPES){
			i=strlen(itypes[loop]);
			if(strncasecmp(itypes[loop],tmps,i)){
				loop++;
				continue;
			}
			in_image=1;
			break;
		}
	}
	if(in_image)
		FATAL(TR("%s: Unexpected end of file"),file);
	fclose(filp);
}

static int read_line( FILE *file, char *line)
{
	int read=0;
	int a;
	int last_non_wspc=-1;
	
	while(1){
		a=fgetc(file);
		
		if(read==0 && (a==' ' || a=='\t'))
			continue;
		else if( a==EOF ){
			line[last_non_wspc+1]='\0';
			return 0;
		}else if( a=='\n' ){
			line[last_non_wspc+1]='\0';
			return read+1;
		}else if( a=='#' ){
			if(read!=0 && line[read-1]=='\\')
				read--;
			else{
				line[last_non_wspc+1]='\0';
				while(1){
					a=fgetc(file);
					if(a=='\n')return read+1;
					if(a==EOF)return 0;
				}
			}
		}
			
		line[read]=a;
		if( a!='\t' && a!=32 )last_non_wspc=read;
		read++;
		if(read==MAXLINELEN-1){
			line[last_non_wspc+1]='\0';
			while(1){
				a=fgetc(file);
				if(a=='\n')return read;
				if(a==EOF)return 0;
			}
		}
	}
}			
