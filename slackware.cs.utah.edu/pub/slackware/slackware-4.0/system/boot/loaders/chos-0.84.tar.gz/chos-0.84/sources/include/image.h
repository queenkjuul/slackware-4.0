/*
 * include/image.h
 * 
 * header file for image.c
 *
 * Copyright (c) Tuomo Valkonen 1996-1998.
 */
 
#ifndef _IMAGE_H
#define _IMAGE_H

extern char instdest[];		/* Where we install the boot sector     */
extern char show_infoline;	/* show infoline ?			*/

void do_delay(char*);
void do_install(char*);
void do_bootsect(char*);
void do_linux(char*);
void do_banner(char*);
void do_infoline(char*);
void do_color(char*);
void do_selection(char*);
void do_background(char*);
void do_menupos(char*);
void do_timerpos(char*);
void do_emergency(char*);
void do_chos_map(char*);
void do_chos_background(char*);
void do_image_color(MF_ImageDes*,char*);
void end_image();
void do_imagecfg(char*);
void new_image(char*,struct imagestr_struct*);
void do_autoboot(char*);
void do_password(char*);
void do_default(char*);

char*strip_whitespace(char*);

char get_color(char*str,char**endstr);
void get_coord(char*str,signed char*x,signed char*y);

extern int map_set,background_set;

#endif