/*
 * chosfile.h
 *
 * Chos mapfile/config file stuff.
 *
 * Copyright (c) Tuomo Valkonen 1997-1998.
 *
 * See the documentation for more information.
 */
 
#ifndef _REBOOTER_CHOSFILE_H
#define _REBOOTER_CHOSFILE_H

#include "chos/mapfile.h"

class Mapfile;

#include "rebooter.h"

class Mapfile{
	int		mapfd;
	char*	mapfilename;
public:
	bool	open(char*name);
	bool	seekto(int pos);
	bool	read(void*,int);
	bool	write(void*,int);
	void	close();
	
	bool	parse(Rebooter&);
	bool	list();
	bool	setSingleShot(int img);
	bool	setSingleShot(char*img);
	
	bool	isOpen(){return (mapfd>=0);};
	int		error()	{if(!isOpen())return -mapfd;return 0;};
	
	Mapfile();
	Mapfile(char*name);
	~Mapfile();
private:
	bool	validateHeader(MF_HeaderSector&);
};
	
class ChosConfigFile{
public:
	void	parse(char*file);
};

#endif /* _REBOOTER_CHOSFILE_H */
