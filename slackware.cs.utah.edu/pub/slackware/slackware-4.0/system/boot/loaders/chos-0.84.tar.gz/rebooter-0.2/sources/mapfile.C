/*
 * mapfile.C
 *
 * Chos mapfile class implementation for rebooter.
 *
 * Copyright (c) Tuomo Valkonen 1997-1998.
 *
 * See the documentation for more information.
 */

 
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/file.h>
#include <errno.h>
#include <assert.h>

#include "rebooter.h"
#include "chosfile.h"

/*
 * Generic file routines
 */
 
Mapfile::Mapfile()
 :mapfilename(NULL),
  mapfd(-1)
{};

Mapfile::Mapfile(char*filename)
 :mapfilename(NULL),
  mapfd(-1)
{
	open(filename);
}

Mapfile::~Mapfile()
{
	close();
}

bool Mapfile::open(char*name)
{
	close();
	
	mapfd=::open(name,O_RDWR);
	
	if(mapfd<=0){
		ERROR(TR("Couldn't open map file %s:\n%s"),name,strerror(errno));
		return FALSE;
	}
	mapfilename=name;
	
#if 0
	// This doesn't work - the file is not locked!
	if(flock(mapfd,LOCK_EX)<0){
		::close(mapfd);
		mapfd=-1;
		ERROR("couldn't lock %s",file);
	}
#endif
}

void Mapfile::close()
{
	if(mapfd>=0){
		::fsync(mapfd);
		::close(mapfd);
		mapfd=-1;mapfilename=NULL;
	}
}

bool Mapfile::seekto(int pos)
{
	if(!isOpen())
		return FALSE;
		
	int ret=::lseek(mapfd,pos,SEEK_SET);
	
	if(ret!=pos){
		ERROR(TR("Error seeking %s:\n%s"),mapfilename,strerror(errno));
		return FALSE;
	}
	return TRUE;
}

bool Mapfile::read(void*addr,int n)
{
	if(!isOpen())
		return FALSE;
		
	int ret=::read(mapfd,addr,n);
	
	if(ret!=n){
		ERROR(TR("Error reading %s:\n%s"),mapfilename,strerror(errno));
		return FALSE;
	}
	return TRUE;
}

bool Mapfile::write(void*addr,int n)
{
	if(!isOpen())
		return FALSE;
		
	int ret=::write(mapfd,addr,n);
	
	if(ret!=n){
		ERROR(TR("Error writing %s:%s\n"),mapfilename,strerror(errno));
		return FALSE;
	}
	return TRUE;
}


/*
 * Mapfile routines
 */
#define FAIL()	({close();return FALSE;})

bool Mapfile::validateHeader(MF_HeaderSector&header)
{
	if(header.major!=CHOS_MAJOR || header.minor!=CHOS_MINOR ||
	   memcmp(header.id,"CHO",3) || header.type!=CHOS_MAPFILE){
	   	ERROR(TR("%s: invalid Choose-OS version or incorrect file type"),mapfilename);
	   	return FALSE;
	}
	return TRUE;
}

bool Mapfile::parse(Rebooter&r)
{
	static char tmp[SECTORSIZE*2];
	MF_HeaderSector&header=	*(MF_HeaderSector*)tmp;
	MF_ImageSector&images=	*(MF_ImageSector*)&tmp[SECTORSIZE];
	
	assert(isOpen());
	
	if(!read(tmp,SECTORSIZE*2))
		FAIL();

	if(!validateHeader(header))
		FAIL();

	int	i;
	
	for(i=0;i<header.nimages;i++){
		r.addChosItem(
			this,
			i,
			(char*)images.images[i].name,
			images.images[i].type
		);
	}
	
	return TRUE;
}

bool Mapfile::list()
{
	static char tmp[SECTORSIZE*2];
	MF_HeaderSector&header=	*(MF_HeaderSector*)tmp;
	MF_ImageSector&images=	*(MF_ImageSector*)&tmp[SECTORSIZE];
	
	assert(isOpen());
	
	if(!read(tmp,SECTORSIZE*2))
		FAIL();

	if(!validateHeader(header))
		FAIL();

	int	i;
	
	for(i=0;i<header.nimages;i++)
		cerr<<"  "<<(i+1)<<". "<<images.images[i].name<<"\n";
	
	return TRUE;
}

bool Mapfile::setSingleShot(int img)
{
	MF_HeaderSector header;
	
	assert(isOpen());
		
	if(!seekto(0))
		FAIL();
		
	if(!read(&header,sizeof(header)))
		FAIL();

	if(!validateHeader(header))
		FAIL();
		
	if(img>=header.nimages){
		ERROR(TR("Internal error or corrupt mapfile (%s)"),mapfilename);
		FAIL();
	}

	header.singleshot=img+1;

	if(!seekto(0))
		FAIL();
		
	if(!write(&header,sizeof(header)))
		FAIL();
		
	return TRUE;
}

bool Mapfile::setSingleShot(char*img)
{
	static char tmp[SECTORSIZE*2];
	MF_HeaderSector&header=	*(MF_HeaderSector*)tmp;
	MF_ImageSector&images=	*(MF_ImageSector*)&tmp[SECTORSIZE];
	int	ci=-1;
	
	assert(isOpen());
	
	if(!read(tmp,SECTORSIZE*2))
		FAIL();

	if(!validateHeader(header))
		FAIL();

	int	i;
	
	for(i=0;i<header.nimages;i++){
		if(!strcmp((char*)images.images[i].name,img))
			break;
		if(!strcasecmp((char*)images.images[i].name,img))
			ci=i;
	}
	if(i>=header.nimages){
		if(ci>=0)
			i=ci;
		else{
			ERROR(TR("%s: No such image"),img);
			FAIL();
		}
	}
	
	header.singleshot=i+1;
	
	if(!seekto(0))
		FAIL();
		
	if(!write(&header,sizeof(header)))
		FAIL();
		
	return TRUE;
}
