/*
 * include/linux.h
 *
 * Linux stuff
 * 
 * Copyright (c) Tuomo Valkonen 1996-1998.
 */

#ifndef __CHOS_LINUX_H
#define __CHOS_LINUX_H

#define CL_MAGIC		0xa33f
#define CL_MAGIC_ADDR		0x20
#define CL_MAX_LEN		492
#define CL_OFFSET		0x22
#define CMDLINE_OFF		0xdc00		// in INITSEG
#define DEF_CL_OFF		MAP_OFF+0x10	// in STAGE2_SEG
#define LINUX_CMDLINE_LEN	CL_MAX_LEN
#define LINUX_SETUPSECT_OFF	497

#define MAX_LINUX_SIZE		1024

#define LI_LOADER_TYPE_OFF      16
#define LI_LOAD_FLAGS_OFF       17
#define LI_LOAD_ADDRESS_OFF     20
#define LI_INITRD_ADDR_OFF      24
#define LI_INITRD_SIZE_OFF      28

#define SYSSEG			0x1000
#define INITSEG			0x9000
#define SETUPSEG		0x9020
#define SYSSIZE			0x7f00

#define LI_LOADER_TYPE_CHOS    	0x70    	// assigned this myself ;)
#define LI_BIG_LOAD_ADDRESS    	0x100000 	// 1M
#define LI_LOAD_FLAG_HIGH      	0x1

// Stuff in first linux map sector...
#define LI_FBSECT_OFF	0+MAP_OFF
#define LI_DRIVE_OFF	4+MAP_OFF
#define LI_RD_DEV_OFF	5+MAP_OFF
#define LI_RD_SIZE_OFF	6+MAP_OFF
#define LI_RD_ADDR_OFF	8+MAP_OFF
#define LI_RD_MAP_OFF	12+MAP_OFF
#define LI_CMDLINE_OFF	16+MAP_OFF

// MF_ImageDes::flags
#define LINF_BIG	0x01	
#define LINF_INITRD	0x02
#define LINF_NEW	0x04		// set if 2.x
   
#endif