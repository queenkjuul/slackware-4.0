/*
 * include/bin.h
 *
 * Copyright (c) Tuomo Valkonen 1996-1998.
 */
   
#ifndef _BIN_H
#define _BIN_H

extern char*bindir;
extern int bindir_set;

extern void do_chos_bindir(char*);
extern int get_binary(char*name,int wanted_type,char*typename,int*size_return);
extern int get_loader(char*name,int wanted_type,char*typename);

#endif