/* nc100em, a VGA NC100 emulator for Linux.
 * Copyright (C) 1994 Ian Collier. nc100em changes (C) 1996,1999 Russell Marks.
 *
 * common.h
 */

extern unsigned char mem[];
extern unsigned char *cardmem;
extern unsigned char *dfile;
extern unsigned char *memptr[];
extern unsigned long tstates,tsmax;
extern int memattr[];
extern volatile int signal_int_flag;
extern int scrn_freq;

extern int card_size;
extern int card_status;
extern int irq_status;
extern int irq_mask;
extern int scrnaddr;
extern int do_nmi;
extern int force_full_redraw;

extern unsigned char keyports[];


extern void writeram(unsigned char *x);
extern void writecard(unsigned char *x);
extern unsigned int in(int h,int l);
extern unsigned int out(int h,int l,int a);
extern void serial_init(void);
extern void serial_uninit(void);
extern int serial_input_pending(void);
extern int serial_output_allowed(void);
extern int get_serial_byte(void);
extern void put_serial_byte(int n);
extern void serout_flush(void);
extern void common_init(void);
extern void startsigsandtimer(void);
extern void parseoptions(int argc,char *argv[]);
