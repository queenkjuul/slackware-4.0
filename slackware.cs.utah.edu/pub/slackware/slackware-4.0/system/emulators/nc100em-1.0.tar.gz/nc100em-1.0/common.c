/* nc100em, a VGA NC100 emulator for Linux.
 * Copyright (C) 1994 Ian Collier. nc100em changes (C) 1996,1999 Russell Marks.
 *
 * common.c - bits common to nc100em/tnc100em/xnc100em.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

#include "common.h"
#include "z80.h"
#include "libdir.h"
#include "pdrom.h"


/* the memory is 256k ROM and 64k RAM */
unsigned char mem[(256+64)*1024];
unsigned char *cardmem=NULL;	/* malloc'd or mmap'd PCMCIA card mem */
unsigned char *dfile;
/* boots with all ROM0 */
unsigned char *memptr[4]={mem,mem,mem,mem};
unsigned char lastpageout[4]={0,0,0,0};	/* last out to paging ports */
unsigned long tstates=0,tsmax=46060;

int memattr[4]={0,0,0,0};	/* all ROM at boot */

volatile int signal_int_flag=0;
int scrn_freq=10;

int card_size=0;		/* size of pcmcia card, or 0 if none */
int card_status=0;		/* as read from port 0xA0 */
int irq_status=0xff;		/* as read from port 0x90 */
int irq_mask=0;			/* as set via port 0x60 */
int scrnaddr=0;
int do_nmi=0;
int force_full_redraw=1;
int force_pd_rom=0;
int using_pd_rom=0;

struct tm *rtc_tm;

unsigned char keyports[10]={0,0,0,0,0, 0,0,0,0,0};

#ifdef TTY_SERIAL
int tty_fd;
unsigned char seroutbuf[16384];		/* won't need this many - defensive */
int seroutpos=0;
#endif

static char binfile_name[256]={0};
static int do_munmap=1;



/* the card_status flag never changes after this */
void set_card_status(void)
{
card_status=0x33; /* no batteries low, and parallel always ACK and !BUSY */
if(card_size==0) card_status|=0x80;	/* is card present? */
}


void loadrom(unsigned char *x)
{
static unsigned char rom100timechk[]={0xc6,7,1,1,0,0,0};
FILE *in;

if(!force_pd_rom && (in=fopen(libdir("nc100.rom"),"rb"))!=NULL)
  {
  fread(x,1024,256,in);
  fclose(in);
  }
else
  {
  if(!force_pd_rom)
    fprintf(stderr,"%s: no ROM found, using builtin PD `ROM'.\n",cmd_name);
  memcpy(x,pd_rom,sizeof(pd_rom));
  using_pd_rom=1;
  return;
  }

/* if it's ROM v1.00, patch it so it doesn't do an is-time-set check
 * which would be a pain to emulate.
 */
if(memcmp(x+0x9c0,rom100timechk,7)==0)
  {
  x[0xaa2]=0x37;	/* scf */
  x[0xaa3]=0xc9;	/* ret */
  }
}


void loadram(unsigned char *x)
{
FILE *in;
char *ram_file=libdir("nc100.ram");

if((in=fopen(ram_file,"rb"))!=NULL)
  {
  fread(x,1024,64,in);
  fclose(in);
  }
else
  {
  fprintf(stderr,"%s: couldn't load RAM file `%s', using blank.\n",
  	cmd_name,ram_file);
  /* not fatal - blank it and carry on */
  memset(x,0,64*1024);
  }
}


unsigned char *loadcard(void)
{
FILE *in;
unsigned char *cardmem;
char *card_file=libdir("nc100.card");

/* we open read/write so mmap will work properly */
if((in=fopen(card_file,"r+"))!=NULL)
  {
  fseek(in,0,SEEK_END);
  card_size=ftell(in)/1024;
#ifndef USE_MMAP_FOR_CARD
  rewind(in);
  if((cardmem=malloc(card_size*1024))==NULL)
    fprintf(stderr,"%s: out of memory.\n",cmd_name),exit(1);
  fread(cardmem,1024,card_size,in);
  fclose(in);
#else
  if((cardmem=mmap(0,card_size*1024,PROT_READ|PROT_WRITE,
  	MAP_SHARED,fileno(in),0))==MAP_FAILED)
    {
    fprintf(stderr,"%s: couldn't mmap() mem card file `%s'.\n",
    	cmd_name,card_file);
    exit(1);
    }
#endif /* USE_MMAP_FOR_CARD */
  }
else /* if fopen failed */
  {
  fprintf(stderr,"%s: couldn't open mem card file `%s'.\n",
  	cmd_name,card_file);
  /* not fatal, get a blanked 1024k */
  do_munmap=0;	/* don't try to munmap this! */
  if((cardmem=calloc(card_size*1024,1))==NULL)
    fprintf(stderr,"%s: out of memory.\n",cmd_name),exit(1);
  }

return(cardmem);
}


void writeram(unsigned char *x)
{
FILE *out;
char *ram_file=libdir("nc100.ram");

if((out=fopen(ram_file,"wb"))==NULL)
  fprintf(stderr,"%s: couldn't write RAM to `%s'.\n",cmd_name,ram_file);
else
  {
  fwrite(x,1024,64,out);
  fclose(out);
  }
}


void writecard(unsigned char *x)
{
char *card_file=libdir("nc100.card");

#ifdef USE_MMAP_FOR_CARD

if(do_munmap && munmap(x,card_size*1024)==-1)
  fprintf(stderr,"%s: couldn't munmap() mem card file `%s'.\n",
  	cmd_name,card_file);

#else
FILE *out;

if(card_size>0)
  {
  if((out=fopen(card_file,"wb"))==NULL)
    fprintf(stderr,"%s: couldn't write mem card to `%s'.\n",
    	cmd_name,card_file);
  else
    {
    fwrite(x,1024,card_size,out);
    fclose(out);
    }
  }
#endif /* !USE_MMAP_FOR_CARD */
}


/* I/O, quoting from nciospec.doc:
[we ignore some]
D0-DF                   RTC (TC8521)            R/W	(ignore for now)
C0-C1                   UART (uPD71051)         R/W	(ignore for now)
B0-B9                   Key data in             R
A0                      Card Status etc.        R
90                      IRQ request status      R/W
70                      Power on/off control    W
60                      IRQ Mask                W
50-53                   Speaker frequency       W	(ignore)
40                      Parallel port data      W	(ignore)
30                      Baud rate etc.          W	(ignore)
20                      Card wait control       W	(ignore)
10-13                   Memory management       R/W
00                      Display memory start    W
*/


void do_paging(int page,int n)
{
lastpageout[page]=n;

switch(n&0xc0)
  {
  case 0x00:	/* ROM */
    memptr[page]=mem+16384*n;
    memattr[page]=0;
    break;
  case 0x40:	/* RAM */
    memptr[page]=mem+RAM_START+16384*(n&0x0f);
    memattr[page]=1;
    break;
  case 0x80:	/* card ram */
    memptr[page]=cardmem+16384*(n&0x3f);
    memattr[page]=1;
    /* one way of detecting the size of a card requires
     * that writes which are off-card must fail, so...
     */
    if(16*(n&0x3f)>=card_size) memattr[page]=0;
    break;
  }
}


unsigned int in(int h,int l)
{
static int ts=(13<<8);	/* num. t-states for this out, times 256 */

/* h is ignored by the NC100 */
switch(l)
  {
  /* RTC */
  case 0xd0: case 0xd1: case 0xd2: case 0xd3:
  case 0xd4: case 0xd5: case 0xd6: case 0xd7:
  case 0xd8: case 0xd9: case 0xda: case 0xdb:
  case 0xdc: case 0xdd: case 0xde: case 0xdf:
    switch(l-0xd0)
      {
      case 0:	return(ts|('0'+rtc_tm->tm_sec%10));
      case 1:	return(ts|('0'+rtc_tm->tm_sec/10));
      case 2:	return(ts|('0'+rtc_tm->tm_min%10));
      case 3:	return(ts|('0'+rtc_tm->tm_min/10));
      case 4:	return(ts|('0'+rtc_tm->tm_hour%10));
      case 5:	return(ts|('0'+rtc_tm->tm_hour/10));
      
      case 6:	return(ts);
      
      case 7:	return(ts|('0'+rtc_tm->tm_mday%10));
      case 8:	return(ts|('0'+rtc_tm->tm_mday/10));
      case 9:	return(ts|('0'+(rtc_tm->tm_mon+1)%10));
      case 10:	return(ts|('0'+(rtc_tm->tm_mon+1)/10));
      case 11:	return(ts|('0'+(rtc_tm->tm_year-90)%10));
      case 12:	return(ts|('0'+(rtc_tm->tm_year-90)/10));
      
      case 13:
      case 14:
      case 15:
        return(ts);
      
      default:
        fprintf(stderr,"bad RTC port in in() - can't happen!\n");
      }
    return(ts|0);
  
  
#ifndef TTY_SERIAL
  case 0xc0: case 0xc1: return(ts|0);
#else
  /* UART */
  case 0xc0:	/* this reads from the serial port */
    return(ts|get_serial_byte());
  
  case 0xc1:    /* returns bit 0=1 if can send a byte */
    /* we assume it's always possible */
    return(ts|1);
#endif
    
  /* keyboard */
  case 0xb0: case 0xb1: case 0xb2: case 0xb3: case 0xb4:
  case 0xb5: case 0xb6: case 0xb7: case 0xb8: case 0xb9:
    /* reading 0xb9 also sets bit 3 of irq_status */
    if(l==0xb9) irq_status|=8;
    return(ts|keyports[l-0xb0]);
  
  case 0xa0:	/* card etc. status */
    return(ts|card_status);
  
  case 0x90:	/* IRQ status */
    return(ts|irq_status);
  
  /* memory paging */
  case 0x10: return(ts|lastpageout[0]);
  case 0x11: return(ts|lastpageout[1]);
  case 0x12: return(ts|lastpageout[2]);
  case 0x13: return(ts|lastpageout[3]);
  }

/* otherwise... */
return(ts|255);
}


unsigned int out(int h,int l,int a)
{
static int ts=13;	/* num. t-states for this out */
time_t timet;

/* h is ignored by the NC100 */
switch(l)
  {
  /* RTC */
  case 0xdd:
    /* this one locks output (I think) when bit 3 is 1 */
    /* get time */
    timet=time(NULL);
    rtc_tm=localtime(&timet);
    return(ts);
      
  case 0xd0: case 0xd1: case 0xd2: case 0xd3:
  case 0xd4: case 0xd5: case 0xd6: case 0xd7:
  case 0xd8: case 0xd9: case 0xda: case 0xdb:
  case 0xdc:            case 0xde: case 0xdf:
    /* ignored, don't want to let them set the time!
     * (would need to be root anyway)
     */
    return(ts);
  
#ifndef TTY_SERIAL
  case 0xc0: case 0xc1: return(ts);
#else
  /* UART */
  case 0xc0:	/* this writes to the serial port */
    put_serial_byte(a);
    return(ts);
  
  case 0xc1:    /* sets up various serial parms which we ignore */
    return(ts);
#endif
  
  case 0x90:	/* IRQ status */
    /* when a zero is written to a bit, it should re-enable that IRQ line */
    irq_status|=(a^255);
    return(ts);
  
  case 0x70:	/* power on/off */
    /* if bit 0 is 0, turn off */
    if((a&1)==0) dontpanic_nmi();
    return(ts);
  
  case 0x60:	/* set irq mask */
    irq_mask=a;
    return(ts);
  
  case 0x50: case 0x51: case 0x52: case 0x53:
    /* speaker frequency, ignored */
    return(ts);
  
  case 0x40:	/* parallel port data, ignored */
    return(ts);
  
  case 0x30:	/* baud rate etc., ignored */
    return(ts);
  
  case 0x20:	/* card wait control, ignored */
    return(ts);
  
  /* memory paging */
  case 0x10: do_paging(0,a); return(ts);
  case 0x11: do_paging(1,a); return(ts);
  case 0x12: do_paging(2,a); return(ts);
  case 0x13: do_paging(3,a); return(ts);
  
  case 0:	/* set screen addr */
    scrnaddr=(a&0xf0)*256;
    force_full_redraw=1;	/* override differential updating in VGA ver */
    return(ts);
  }

/* otherwise... */
return(ts);
}



#ifdef TTY_SERIAL

void serial_init(void)
{
/* XXX should do this properly... */
/* mind you this is probably more portable than termios :-) */
static char buf[1024];

/* the -echo is really for tnc100em, but doesn't hurt anyway */
sprintf(buf,"stty raw -echo <%s",tty_name);
system(buf);

if((tty_fd=open(tty_name,O_RDWR|O_NONBLOCK))<0)
  {
  fprintf(stderr,"%s: couldn't open tty!\n",cmd_name);
  exit(1);
  }
}


void serial_uninit(void)
{
static char buf[1024];

close(tty_fd);
/* XXX also crap */
sprintf(buf,"stty -raw echo <%s",tty_name);
system(buf);
}


int serial_input_pending(void)
{
struct timeval tv;
fd_set fds;

tv.tv_sec=0; tv.tv_usec=0;
FD_ZERO(&fds); FD_SET(tty_fd,&fds);
if(select(tty_fd+1,&fds,NULL,NULL,&tv)<=0)
  return(0);

return(FD_ISSET(tty_fd,&fds));
}


int serial_output_allowed(void)
{
#if 1
/* assume it always is. select() takes yonks in our terms. */
return(1);
#else
struct timeval tv;
fd_set fds;

tv.tv_sec=0; tv.tv_usec=0;
FD_ZERO(&fds); FD_SET(tty_fd,&fds);
select(tty_fd+1,NULL,&fds,NULL,&tv);

return(FD_ISSET(tty_fd,&fds));
#endif
}


int get_serial_byte(void)
{
unsigned char c=0;

if(read(tty_fd,&c,1)<=0)
  return(0);

return((int)c);
}


void put_serial_byte(int n)
{
unsigned char c=n;

#if 0
if(serial_output_allowed())
#endif
  seroutbuf[seroutpos++]=c;
}


void serout_flush(void)
{
if(seroutpos>0)
  write(tty_fd,seroutbuf,seroutpos);
seroutpos=0;
}

#endif /* TTY_SERIAL */



void sighandler(int a)
{
signal_int_flag=1;
}


/* init memory etc. */
void common_init(void)
{
loadrom(mem);
loadram(mem+RAM_START);
cardmem=loadcard();
set_card_status();

/* load file at 100h if they specified one. */
if(*binfile_name)
  {
  FILE *in;
  
  /* only if it's the PD ROM */
  if(!using_pd_rom)
    fprintf(stderr,
    	"%s: can only load a file to boot with PD ROM (try `-p').\n",
    	cmd_name);
  else
    {
    /* blast the context-save magic so it jumps to 100h */
    memset(mem+RAM_START+0xb200,0,4);
    
    if((in=fopen(binfile_name,"rb"))==NULL)
      fprintf(stderr,"%s: couldn't open file `%s'.\n",cmd_name,binfile_name);
    else
      fread(mem+RAM_START+0x100,1,49152,in),fclose(in);
    }
  }

#ifdef TTY_SERIAL
serial_init();
#endif
}


void startsigsandtimer(void)
{
struct sigaction sa;
struct itimerval itv;
int tmp=1000/100;	/* 100 ints/sec */

sigemptyset(&sa.sa_mask);
sa.sa_handler=dontpanic;
sa.sa_flags=SA_ONESHOT;

sigaction(SIGINT, &sa,NULL);
sigaction(SIGHUP, &sa,NULL);
sigaction(SIGILL, &sa,NULL);
sigaction(SIGTERM,&sa,NULL);
sigaction(SIGQUIT,&sa,NULL);
sigaction(SIGSEGV,&sa,NULL);

sigemptyset(&sa.sa_mask);
sa.sa_handler=sighandler;
sa.sa_flags=SA_RESTART;

sigaction(SIGALRM,&sa,NULL);

itv.it_value.tv_sec=  0;
itv.it_value.tv_usec= 100000;
itv.it_interval.tv_sec=  tmp/1000;
itv.it_interval.tv_usec=(tmp%1000)*1000;
setitimer(ITIMER_REAL,&itv,NULL);
}


void usage_help(void)
{
printf("%s v" NC100EM_VER " - "
	"(c) 1995-1996,1999 Russell Marks for improbabledesigns.\n\n",
	cmd_name);
printf("usage: %s [-hp] [-r refresh_rate] [file_to_boot.bin]\n",cmd_name);
printf("\

	-h	this usage help.
	-p	use the builtin PD `ROM' even if `nc100.rom' is present.
        	Useful if you want to boot a file.
	-r	set how often the screen is redrawn in 1/100ths of a second.

  file_to_boot.bin	load file into RAM at 100h and run it. The file must
			start with F3h (`di'). (This is generallly used to
			boot ZCN (zcn.bin) when using the builtin `ROM'.)
");
}


void parseoptions(int argc,char *argv[])
{
int done=0;

opterr=0;

do
  switch(getopt(argc,argv,"hpr:"))
    {
    case 'h':
      usage_help();
      exit(1);
    case 'p':	/* force PD ROM even if nc100.rom is present */
      force_pd_rom=1;
      break;
    case 'r':	/* refresh rate */
      scrn_freq=atoi(optarg);
      if(scrn_freq<2) scrn_freq=2;
      if(scrn_freq>100) scrn_freq=100;
      break;
    case '?':
      switch(optopt)
        {
        case 'r':
          fprintf(stderr,"%s: "
          	"the -r option needs a refresh rate as argument.\n",
                cmd_name);
          break;
        default:
          fprintf(stderr,"%s: "
          	"option `%c' not recognised.\n",
                cmd_name,optopt);
        }
      exit(1);
    case -1:
      done=1;
    }
while(!done);

if(optind==argc-1)	/* if a filename given... */
  strcpy(binfile_name,argv[optind]);
}
