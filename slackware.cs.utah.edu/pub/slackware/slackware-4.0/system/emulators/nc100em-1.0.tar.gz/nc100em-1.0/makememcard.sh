#!/bin/sh
#
# make a 1 meg pcmcia card image in ~/nc100
if [ "$HOME" = "" ]; then 
  HOME=.
fi
if [ ! -d $HOME/nc100 ]; then
  mkdir $HOME/nc100
fi
if [ -f $HOME/nc100/nc100.card ]; then
  echo 'makecard: card already exists in ~/nc100, aborting!'
  exit 1
else
  echo 'makecard: making 1024k nc100.card...'
  dd if=/dev/zero of=$HOME/nc100/nc100.card bs=1k count=1024
  echo 'done.'
fi
