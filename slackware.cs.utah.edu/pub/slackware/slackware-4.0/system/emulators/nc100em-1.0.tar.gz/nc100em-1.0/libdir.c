/* nc100em, a VGA NC100 emulator for Linux.
 * Copyright (C) 1994 Ian Collier. nc100em changes (C) 1996,1999 Russell Marks.
 *
 * libdir.c - libdir() routine. Separated out from common.c as
 *		both the emulators and zcntools need it.
 */

#include <stdio.h>
#include <stdlib.h>

#include "libdir.h"


char *libdir(char *file)
{
static char buf[1024];
char *home=getenv("HOME");

if(!home) home=".";
sprintf(buf,"%s/nc100/%s",home,file);
return(buf);
}
