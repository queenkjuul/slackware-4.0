/* nc100em, a VGA NC100 emulator for Linux.
 * Copyright (C) 1994 Ian Collier. nc100em changes (C) 1996,1999 Russell Marks.
 *
 * libdir.h
 */

extern char *libdir(char *file);
