#define NC100EM_VER "1.0"
