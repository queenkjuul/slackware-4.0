/*
 *	The C64 emulator
 *
 *	Copyright 1992 by ALE.
 *	written by Lutz Sammer.
 *
 *	Freezer, memory snapshot.
 *------------------------------------------------------------------------------
 *	$Id: freeze.c,v 1.1 1992/07/20 04:15:46 johns Stab $
 *	$Log: freeze.c,v $
 * Revision 1.1  1992/07/20  04:15:46  johns
 * Initial revision
 *
 *------------------------------------------------------------------------------
 */

#include "c64.h"

/*
 *	Snapshot file format
 *
 *	64K Ram
 */

/*
 *	Save Snapshot.
 */
int SaveSnapShot(name)
char* name;
{
    /* FIXME: Some day */
    return 0;
}

/*
 *	Load Snapshot.
 */
int LoadSnapShot(name)
char* name;
{
    /* FIXME: Some day */
    return 0;
}
