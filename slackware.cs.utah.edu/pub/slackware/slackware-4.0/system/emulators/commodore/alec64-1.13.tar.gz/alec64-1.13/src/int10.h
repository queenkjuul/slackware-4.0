/*
**	The C64 emulator
**
**	Copyright 1994,1996 by ALE.
**	written by Andreas Arens.
**
**	Register structure definition for int10.
**
**-----------------------------------------------------------------------------
** $Id: int10.h,v 1.1 1996/05/12 20:53:34 ari Exp root $
** $Log: int10.h,v $
** Revision 1.1  1996/05/12 20:53:34  ari
** Initial revision
**
**
**-----------------------------------------------------------------------------
*/

typedef struct {
    unsigned ax, bx, cx, dx, si, di, bp;
    unsigned es;
} REGISTERS;
