 /*
  * UAE - The Un*x Amiga Emulator
  *
  * DOS debug only interface.
  *
  * (c) 1995 Bernd Schmidt
  * (c) 1996 Gustavo Goedert
  */

#include "sysconfig.h"
#include "sysdeps.h"

#include "xwin.h"

xcolnr xcolors[4096];

struct vidbuf_description gfxvidinfo;

void flush_line(int y)
{
}

void flush_block(int a, int b)
{
    abort();
}

void flush_screen(int a, int b)
{
}

static void init_colors(void)
{
}

int buttonstate[3] = { 0, 0, 0 };
int lastmx, lastmy;
int newmousecounters = 0;

int graphics_init(void)
{
}

void graphics_leave(void)
{
}

void handle_events(void)
{
}

int debuggable(void)
{
    return 0;
}

int needmousehack(void)
{
    return 0;
}

void LED(int on)
{
}
