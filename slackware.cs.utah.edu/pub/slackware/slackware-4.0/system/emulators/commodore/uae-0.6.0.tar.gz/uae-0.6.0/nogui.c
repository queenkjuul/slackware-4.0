 /*
  * UAE - The Un*x Amiga Emulator
  *
  * Interface to the Tcl/Tk GUI
  *
  * Copyright 1996 Bernd Schmidt
  */

#include "sysconfig.h"
#include "sysdeps.h"

#include "config.h"
#include "options.h"
#include "gui.h"

int quit_program;

static void sigchldhandler(int foo)
{
}

int gui_init(void)
{
    quit_program = 0;
    return 0;
}

void gui_exit(void)
{
}

void gui_led(int led, int on)
{
}

void gui_filename(int num, char *name)
{
}

static void getline(char *p)
{
}

void gui_handle_events(void)
{
}
