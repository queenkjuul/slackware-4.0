
#include <stdio.h>

int main(int argc, char **argv)
{
    fwrite((char *)0xF80000,sizeof(char),0x80000,stdout);
}
