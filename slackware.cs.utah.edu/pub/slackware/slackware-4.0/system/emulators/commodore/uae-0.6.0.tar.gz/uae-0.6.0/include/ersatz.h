 /* 
  * UAE - The Un*x Amiga Emulator
  * 
  * A "replacement" for a missing Kickstart
  *
  * (c) 1995 Bernd Schmidt
  */

extern void init_ersatz_rom (UWORD *data);
extern void ersatz_perform (UWORD);
extern void DISK_ersatz_read (int,int, CPTR);
