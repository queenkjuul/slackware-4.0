 /* 
  * UAE - The Un*x Amiga Emulator
  * 
  * UNIX filesystem support
  *
  * (c) 1996 Ed Hanway
  */

extern void add_filesys_unit(char *volname, char *rootdir, int readonly);
extern void filesys_install(void);
