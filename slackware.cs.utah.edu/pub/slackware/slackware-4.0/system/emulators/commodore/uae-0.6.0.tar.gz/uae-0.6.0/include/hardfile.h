 /* 
  * UAE - The Un*x Amiga Emulator
  * 
  * Hard file support
  *
  * (c) 1995 Bernd Schmidt
  * (c) 1996 Ed Hanway
  */

extern void hardfile_install(void);
