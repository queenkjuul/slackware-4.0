extern void gfxlib_install(void);
