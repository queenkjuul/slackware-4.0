
/* Define this if you have Svgalib earlier than 1.2.10 */
#undef BROKEN_VGAKEYBOARD

/* Define this to the default size of the X window (1 or 2) */
#undef SCRMUL

/* Define this on i386 architectures if the C compiler generates symbols
   beginning with underscores, eg. on old aout versions of Linux */
#undef AOUT_FORMAT

/* Define this to enable running in background on the Linux console.
   Works only with SVGALIB 1.2.11 or newer */
#undef RUN_IN_BACKGROUND

/* Define this if Xlib has the MITSHM extension */
#undef HAVE_MITSHM

/* Define this if program can query MITSHM extension */
#undef HAVE_SHMQUERY

/* Define this to use the C version of the program insead of the 
   i386 assembly. Define this on non intel machines */
#undef Z80C

/* Always define this for the spectrum emulator. */
#undef SPECT_MEM

/* Define if sound driver is available. */
#undef HAVE_SOUND

/* Define if sound driver is Open Sound System (OSS) */
#undef OSS_SOUND

/* Define if sound driver is SUN */
#undef SUN_SOUND

/* Define this to use the inline intel assembly sections */
#undef I386_ASM

/* Define this to use an alternative way of passing the z80 processor
   data to the z80 instruction emulation functions. May make emulation
   faster on some machines, but not on intel, and sparc. */
#undef PROCP

/* Define this to disable the SNDCTL_DSP_SETFRAGMENT ioctl when opening
   the sound device (e.g if you use the PCSND sound driver) */
#undef SPSOUND_NO_SETFRAG

/* Define if compiling for DOS */
#undef DJGPP_GRAPHICS

/* Misc define. */
#undef DIFFMODE

/* Misc define. */
#undef CRT_COLOR_DEBUG

@TOP@
