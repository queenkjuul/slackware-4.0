/* 
 * Copyright (C) 1996-1998 Szeredi Miklos
 * Email: mszeredi@inf.bme.hu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the file COPYING. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include "spperif.h"
#include "z80.h"

#include "spmain.h"
#include "spscr.h"
#include "spkey.h"
#include "sptape.h"
#include "spsound.h"
#include "snapshot.h"
#include "spver.h"

#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>

int endofsingle;

int sp_nosync = 0;

int sound_delay = 3;
int showframe = 2;

qbyte sp_int_ctr = 0;


static void add_tv(long usec, struct timeval *tv)
{
  long us1 = tv->tv_usec + usec;
  tv->tv_sec += us1 / 1000000;
  tv->tv_usec = us1 % 1000000;
}

static long sub_tv(struct timeval *tv1, struct timeval *tv2)
{
  return ((tv1->tv_sec - tv2->tv_sec) * 1000000 + 
	  (tv1->tv_usec - tv2->tv_usec));
}

#define SKIPTIME 20000
#define SHOW_OFFS 1

static void update()
{
  update_screen();
  sp_border_update >>= 1;
  sp_imag_vert = sp_imag_horiz = 0;
}

void run_singlemode()
{
  long t = 0;

  int onesec, evenframe, halfsec, updateframe;

  int uctr = 0;

  struct timeval shouldbetv;
  struct timeval nowtv;
  struct timeval waittv;

  long rem;

  sp_int_ctr = 0;

#if 0
  update();
#endif

  endofsingle = 0;

  gettimeofday(&shouldbetv, NULL);

  while(!endofsingle) {

    if(sp_paused) {
      autoclose_sound();
      while(sp_paused) {
	spkb_release_ud();
	spkb_process_events();
	spkb_press_ud();

	waittv.tv_sec = 0;
	waittv.tv_usec = SKIPTIME;
	select(0, NULL, NULL, NULL, &waittv);

	translate_screen();
	update();
      }
      gettimeofday(&shouldbetv, NULL);
    }

    onesec = !(sp_int_ctr % 50);
    halfsec = !(sp_int_ctr % 25);
    evenframe = !(sp_int_ctr & 1);
    
    if(screen_visible) updateframe = sp_nosync ? halfsec : 
      !((sp_int_ctr+SHOW_OFFS) % showframe);
    else updateframe = 0;


/*
    if(onesec) {
      printf("update skip: %4.1f\n", uctr ? (50.0 / uctr) : 99.9);
      uctr = 0;
    }
*/

    if(halfsec) {
      sp_flash_state = ~sp_flash_state;
      flash_change();
    }

    if(evenframe) {
      play_tape();

      spkb_release_ud();
      spkb_process_events();
      spkb_press_ud();
      spkb_refresh();

      sp_scline = 0;
    }

    sp_updating = updateframe;
    
    t += CHKTICK;
    t = sp_halfframe(t, evenframe ? EVENHF : ODDHF);
    if(SPNM(load_trapped)) {
      SPNM(load_trapped) = 0;
      DANM(haltstate) = 0;
      qload();
    }

    z80_interrupt();
    sp_int_ctr++;

    if(!evenframe) rec_tape();

    if(!sp_nosync) {
#ifndef DJGPP_GRAPHICS

      if(!sound_avail) {
	add_tv(SKIPTIME, &shouldbetv);
	
	gettimeofday(&nowtv, NULL);
	rem = sub_tv(&shouldbetv, &nowtv);
	if(rem > 0) {
	  if(rem > SKIPTIME) rem = SKIPTIME;
	  waittv.tv_sec = 0;
	  waittv.tv_usec = rem;
	  select(0, NULL, NULL, NULL, &waittv);
	}
	
	if(rem == SKIPTIME || rem < -10 * SKIPTIME) 
	  gettimeofday(&shouldbetv, NULL);
      }

#endif

      if(updateframe) uctr++, update();

      play_sound(evenframe);
    }
    else if(updateframe) uctr++, update();
  }
}

void check_params(int argc, char *argv[])
{
  if(argc > 1 && argv[1] != NULL && argv[1][0] != '-')
    load_snapshot_file(argv[1]);
}

void print_copyright()
{
  printf("Welcome to SPECTEMU version %s/%s (C) Szeredi Miklos 1996-1998\n", 
	 SPECTEMU_VERSION, SPECTEMU_TYPE);
  printf("This program comes with NO WARRANTY, see the file COPYING "
	 "for details\n");
  printf("Press Ctrl-h for help\n");
}
