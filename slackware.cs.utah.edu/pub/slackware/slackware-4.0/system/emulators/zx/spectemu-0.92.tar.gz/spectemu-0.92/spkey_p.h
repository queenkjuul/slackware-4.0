/* 
 * Copyright (C) 1996-1998 Szeredi Miklos
 * Email: mszeredi@inf.bme.hu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the file COPYING. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifndef SPKEY_P_H
#define SPKEY_P_H

#include "z80_type.h"

typedef byte spkeyboard[8];

#define SPIP(spk, h) (((qbyte *) (spk))[h])

#define SP_COMBINE(spk1, spk2) \
  SPIP(spk1, 0) |= SPIP(spk2, 0), \
  SPIP(spk1, 1) |= SPIP(spk2, 1) 


#define SP_SUBSTRACT(spk1, spk2) \
  SPIP(spk1, 0) &= ~SPIP(spk2, 0), \
  SPIP(spk1, 1) &= ~SPIP(spk2, 1) 


#define SP_NONEMPTY(spk) (SPIP(spk, 0) || SPIP(spk, 1))

#define SP_CONTAINS(spk1, spk2) \
  ((SPIP(spk1, 0) & SPIP(spk2, 0)) || (SPIP(spk1, 1) & SPIP(spk2, 1))) 

#define SP_SETEMPTY(spk) \
  SPIP(spk, 0) = 0, \
  SPIP(spk, 1) = 0 

#define SKE {0, 0, 0, 0, 0, 0, 0, 0}

#define SKP(x) (1 << x)

#define SKN0(x) {SKP(x), 0, 0, 0, 0, 0, 0, 0} 
#define SKN1(x) {0, SKP(x), 0, 0, 0, 0, 0, 0} 
#define SKN2(x) {0, 0, SKP(x), 0, 0, 0, 0, 0} 
#define SKN3(x) {0, 0, 0, SKP(x), 0, 0, 0, 0} 
#define SKN4(x) {0, 0, 0, 0, SKP(x), 0, 0, 0} 
#define SKN5(x) {0, 0, 0, 0, 0, SKP(x), 0, 0} 
#define SKN6(x) {0, 0, 0, 0, 0, 0, SKP(x), 0} 
#define SKN7(x) {0, 0, 0, 0, 0, 0, 0, SKP(x)} 

#define SKCS0(x) {SKP(0) | SKP(x), 0, 0, 0, 0, 0, 0, 0} 
#define SKCS1(x) {SKP(0), SKP(x), 0, 0, 0, 0, 0, 0} 
#define SKCS2(x) {SKP(0), 0, SKP(x), 0, 0, 0, 0, 0} 
#define SKCS3(x) {SKP(0), 0, 0, SKP(x), 0, 0, 0, 0} 
#define SKCS4(x) {SKP(0), 0, 0, 0, SKP(x), 0, 0, 0} 
#define SKCS5(x) {SKP(0), 0, 0, 0, 0, SKP(x), 0, 0} 
#define SKCS6(x) {SKP(0), 0, 0, 0, 0, 0, SKP(x), 0} 
#define SKCS7(x) {SKP(0), 0, 0, 0, 0, 0, 0, SKP(x)} 


#define SKSS0(x) {SKP(x), 0, 0, 0, 0, 0, 0, SKP(1)} 
#define SKSS1(x) {0, SKP(x), 0, 0, 0, 0, 0, SKP(1)} 
#define SKSS2(x) {0, 0, SKP(x), 0, 0, 0, 0, SKP(1)} 
#define SKSS3(x) {0, 0, 0, SKP(x), 0, 0, 0, SKP(1)} 
#define SKSS4(x) {0, 0, 0, 0, SKP(x), 0, 0, SKP(1)} 
#define SKSS5(x) {0, 0, 0, 0, 0, SKP(x), 0, SKP(1)} 
#define SKSS6(x) {0, 0, 0, 0, 0, 0, SKP(x), SKP(1)} 
#define SKSS7(x) {0, 0, 0, 0, 0, 0, 0, SKP(x) | SKP(1)} 

struct spkeydef {
  int type;
  spkeyboard kb;
};

#define T_MAIN 0
#define T_CMPX 1
#define T_EXTR 2

#define SPK_SPACE SKN7(0)

#define SPK_0 SKN4(0)
#define SPK_1 SKN3(0)
#define SPK_2 SKN3(1)
#define SPK_3 SKN3(2)
#define SPK_4 SKN3(3)
#define SPK_5 SKN3(4)
#define SPK_6 SKN4(4)
#define SPK_7 SKN4(3)
#define SPK_8 SKN4(2)
#define SPK_9 SKN4(1)

#define SPK_A SKN1(0)
#define SPK_B SKN7(4)
#define SPK_C SKN0(3)
#define SPK_D SKN1(2)
#define SPK_E SKN2(2)
#define SPK_F SKN1(3)
#define SPK_G SKN1(4)
#define SPK_H SKN6(4)
#define SPK_I SKN5(2)
#define SPK_J SKN6(3)
#define SPK_K SKN6(2)
#define SPK_L SKN6(1)
#define SPK_M SKN7(2)
#define SPK_N SKN7(3)
#define SPK_O SKN5(1)
#define SPK_P SKN5(0)
#define SPK_Q SKN2(0)
#define SPK_R SKN2(3)
#define SPK_S SKN1(1)
#define SPK_T SKN2(4)
#define SPK_U SKN5(3)
#define SPK_V SKN0(4)
#define SPK_W SKN2(1)
#define SPK_X SKN0(2)
#define SPK_Y SKN5(4)
#define SPK_Z SKN0(1)

#define SPK_ENTER       SKN6(0)
#define SPK_CAPSSHIFT   SKN0(0)
#define SPK_SYMBOLSHIFT SKN7(1)

#define SPK_BS          SKCS4(0)
#define SPK_UP          SKCS4(3)
#define SPK_DOWN        SKCS4(4)
#define SPK_LEFT        SKCS3(4)
#define SPK_RIGHT       SKCS4(2)
#define SPK_CAPSLOCK    SKCS3(1)


#define SP_ENTER       0
#define SP_CAPSSHIFT   1
#define SP_SYMBOLSHIFT 2
#define CX_BACKSPACE   3
#define CX_UP          4
#define CX_DOWN        5
#define CX_LEFT        6
#define CX_RIGHT       7
#define CX_CAPSLOCK    8

extern spkeyboard spkey_state;

extern struct spkeydef spkey_ascii[];
extern struct spkeydef spkey_aux[];

extern void spkey_textmode(void);
extern void spkey_screenmode(void);

extern const int need_switch_mode;

extern void spkey_keyfuncs(int k);

#endif /* SPKEY_P_H */


