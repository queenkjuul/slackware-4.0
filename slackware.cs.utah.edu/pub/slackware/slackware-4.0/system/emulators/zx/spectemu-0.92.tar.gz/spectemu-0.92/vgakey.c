/* 
 * Copyright (C) 1996-1998 Szeredi Miklos
 * Email: mszeredi@inf.bme.hu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the file COPYING. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
#include "config.h"

#include "spkey.h"
#include "spkey_p.h"
#include "spscr_p.h"
#include "spperif.h"

#include "vgascr.h"

#include "akey.h"

#include <stdlib.h>

const int need_switch_mode = 1;

static int shiftstate;
static int ctrlstate;
static int altstate;

#define KC_F1 59

#define KC_L_SHIFT 42
#define KC_R_SHIFT 54

#define KC_L_CTRL 29
#define KC_R_CTRL 97

#define KC_L_ALT 56
#define KC_R_ALT 100

#ifndef DJGPP_GRAPHICS
#ifdef BROKEN_VGAKEYBOARD

#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

#include <signal.h>
#include <sys/ioctl.h>
#include <fcntl.h>

#include <linux/kd.h>
#include <linux/keyboard.h>
#include <sys/vt.h>

extern int __svgalib_console_fd;
extern int __svgalib_tty_fd;

static struct termios oldkbdtermios, newkbdtermios;
static int oldkbmode;
static int oldflags;

extern int kbd_fd;

static int kbfd;
static char kbstate[NR_KEYS];

static int sig2catch[] =
{
  SIGHUP,     SIGINT,     SIGQUIT,    SIGILL,
  SIGTRAP,    SIGIOT,     SIGBUS,     SIGFPE,
  SIGSEGV,    SIGPIPE,    SIGALRM,    SIGTERM,
  SIGXCPU,    SIGXFSZ,    SIGVTALRM,  SIGPROF, 
  SIGPWR
};

#define STCNUM 17

static struct sigaction old_signal_handler[STCNUM];

static void spkb_clearstate(void)
{
  int i;
  for(i = 0; i < NR_KEYS; i++) kbstate[i] = 0;
  
  shiftstate = 0;
  ctrlstate = 0;
  altstate = 0;
}

static void spkb_raw(void)
{
  
  tcsetattr(kbfd, TCSAFLUSH, &newkbdtermios);
  ioctl(kbfd, KDSKBMODE, K_MEDIUMRAW);

  /* We don't want to wait, set NDELAY mode. */

  fcntl(kbfd, F_SETFL, oldflags | O_NDELAY);

  spkb_clearstate();

  kbd_fd = kbfd;
}

static void spkb_normal(void)
{
  kbd_fd = -1;

  fcntl(kbfd, F_SETFL, oldflags);

  ioctl(kbfd, KDSKBMODE, oldkbmode);
  tcsetattr(kbfd, 0, &oldkbdtermios);
}

static void signal_handler(int v)
{
    int i;

    spkb_normal();
    kbd_fd = -1;

    for (i = 0; i < STCNUM; i++)
      if (sig2catch[i] == v) {
	sigaction(v, old_signal_handler + i, NULL);
	raise(v);
	break;
      }

    if (i >= STCNUM) {
	fprintf(stderr, 
		"Aieeee! Illegal call to signal_handler, raising segfault.\n");
	raise(SIGSEGV);
    }
}


static void spkb_init(void)
{
  struct sigaction siga;
  int i;

  kbfd = __svgalib_console_fd;
  
  if (ioctl(kbfd, KDGKBMODE, &oldkbmode)) {
    fprintf(stderr, "vgakey: cannot get keyboard mode.\n");
    exit(1);
  }
  tcgetattr(kbfd, &oldkbdtermios);
  newkbdtermios = oldkbdtermios;
  
  newkbdtermios.c_lflag = newkbdtermios.c_lflag & ~(ICANON | ECHO | ISIG);
    
  /* Needed because input translations like ICRNL, INLCR, ... can have */
  /* nasty effects on keycodes ( eg. pressing the '=' key (scancode 13) */
  /* has the effect of pressing the '9' key (scancode 10) if ICRNL is on */
  newkbdtermios.c_iflag = 0;

  newkbdtermios.c_cc[VMIN] = 0;	/* Making these 0 seems to have the */
  newkbdtermios.c_cc[VTIME] = 0;	/* desired effect. */

  /* do our own interrupt handling */
  for (i = 0; i < STCNUM; i++) {
    siga.sa_handler = signal_handler;
    siga.sa_flags = 0;
    siga.sa_mask = 0;
    sigaction((int) sig2catch[i], &siga, old_signal_handler + i);
  }

  spkb_raw();
}

static void spkb_close(void)
{
  spkb_normal();
}

#define RDBUFSIZE 32
static char buf[RDBUFSIZE];


static void spkb_update(void)
{
  int nr, i;

  do {
    nr = read(kbfd, buf, RDBUFSIZE);
    for(i = 0; i < nr; i++) 
      kbstate[buf[i] & 0x7f] = (buf[i] & 0x80) ? 0 : 1;

  } while(nr > 0);

  if(kbstate[KC_L_SHIFT] || kbstate[KC_R_SHIFT]) shiftstate = 1;
  else shiftstate = 0;
  
  if(kbstate[KC_L_CTRL] || kbstate[KC_R_CTRL]) ctrlstate = 1;
  else ctrlstate = 0;
  
  if(kbstate[KC_L_ALT] || kbstate[KC_R_ALT]) altstate = 1;
  else altstate = 0;

  if(altstate) for(i = 0; i < 10; i++) 
    if(kbstate[i + KC_F1]) {
      spkb_clearstate();
      ioctl(__svgalib_tty_fd, VT_ACTIVATE, i+1);
      break;
    }

}


#else  /* BROKEN_VGAKEYBOARD */

#include <vgakeyboard.h>

static char *kbstate;

static void spkb_init(void)
{
  keyboard_init();
  keyboard_translatekeys(DONT_CATCH_CTRLC);
  kbstate = keyboard_getstate();
}

static void spkb_close(void)
{
  keyboard_close();
}

static void spkb_raw(void)
{
  keyboard_init();
}

static void spkb_normal(void)
{
  keyboard_close();
}

static void spkb_update(void)
{
  keyboard_update();

  if(kbstate[KC_L_SHIFT] || kbstate[KC_R_SHIFT]) shiftstate = 1;
  else shiftstate = 0;
  
  if(kbstate[KC_L_CTRL] || kbstate[KC_R_CTRL]) ctrlstate = 1;
  else ctrlstate = 0;
  
  if(kbstate[KC_L_ALT] || kbstate[KC_R_ALT]) altstate = 1;
  else altstate = 0;

}

#endif /* BROKEN_VGAKEYBOARD */

#define kbst(i) kbstate[i]

#else /* !DJGPP_GRAPHICS */


#include <kb.h>

static void spkb_init(void)
{
  kb_install(0);
}

static void spkb_close(void)
{
  kb_remove();
}

static void spkb_raw(void)
{
  kb_install(0);
}

static void spkb_normal(void)
{
  kb_remove();
}

static void spkb_update(void)
{
  kb_update();

  if(kb_key(KC_L_SHIFT) || kb_key(KC_R_SHIFT)) shiftstate = 1;
  else shiftstate = 0;
  
  if(kb_key(KC_L_CTRL) || kb_key(KC_R_CTRL)) ctrlstate = 1;
  else ctrlstate = 0;
  
  if(kb_key(KC_L_ALT) || kb_key(KC_R_ALT)) altstate = 1;
  else altstate = 0;

}

#define kbst(i) kb_key(i)

#endif /* !DJGPP_GRAPHICS */

#define T_NONE 0
#define T_SIMP 1
#define T_TRAN 2

#define SDEMPTY {T_NONE, SKE, NOKEY, NOKEY}


struct spscan_keydef {
  int type;
  spkeyboard kb;
  int norm;
  int shifted;
};

static struct spscan_keydef sp_cp_keycode[] = {
  SDEMPTY,
  {T_TRAN, SKE,  ESCKEY,  ESCKEY},
  {T_SIMP, SPK_1, '1', '!'},
  {T_SIMP, SPK_2, '2', '@'},
  {T_SIMP, SPK_3, '3', '#'},
  {T_SIMP, SPK_4, '4', '$'},
  {T_SIMP, SPK_5, '5', '%'},
  {T_SIMP, SPK_6, '6', '^'},
  {T_SIMP, SPK_7, '7', '&'},
  {T_SIMP, SPK_8, '8', '*'},
  {T_SIMP, SPK_9, '9', '('},
  {T_SIMP, SPK_0, '0', ')'},
  {T_TRAN, SKE, '-', '_'},
  {T_TRAN, SKE, '=', '+'},
  {T_SIMP, SPK_BS, BSKEY, BSKEY},
  
  {T_TRAN, SKE,   TABKEY,   BKTABKEY},
  {T_SIMP, SPK_Q, 'q', 'Q'},
  {T_SIMP, SPK_W, 'w', 'W'},
  {T_SIMP, SPK_E, 'e', 'E'},
  {T_SIMP, SPK_R, 'r', 'R'},
  {T_SIMP, SPK_T, 't', 'T'},
  {T_SIMP, SPK_Y, 'y', 'Y'},
  {T_SIMP, SPK_U, 'u', 'U'},
  {T_SIMP, SPK_I, 'i', 'I'},
  {T_SIMP, SPK_O, 'o', 'O'},
  {T_SIMP, SPK_P, 'p', 'P'},
  {T_TRAN, SKE, '[', '{'},
  {T_TRAN, SKE, ']', '}'},
  {T_SIMP, SPK_ENTER, ENTERKEY, ENTERKEY},

  SDEMPTY,                  /* L_CTRL */
  {T_SIMP, SPK_A, 'a', 'A'},
  {T_SIMP, SPK_S, 's', 'S'},
  {T_SIMP, SPK_D, 'd', 'D'},
  {T_SIMP, SPK_F, 'f', 'F'},
  {T_SIMP, SPK_G, 'g', 'G'},
  {T_SIMP, SPK_H, 'h', 'H'},
  {T_SIMP, SPK_J, 'j', 'J'},
  {T_SIMP, SPK_K, 'k', 'K'},
  {T_SIMP, SPK_L, 'l', 'L'},
  {T_TRAN, SKE, ';', ':'},
  {T_TRAN, SKE, '\'', '"'}, 
  {T_TRAN, SKE, '`', '~'},

  {T_SIMP, SPK_CAPSSHIFT, NOKEY, NOKEY},
  {T_TRAN, SKE, '\\', '|'},
  {T_SIMP, SPK_Z, 'z', 'Z'},
  {T_SIMP, SPK_X, 'x', 'X'},
  {T_SIMP, SPK_C, 'c', 'C'},
  {T_SIMP, SPK_V, 'v', 'V'},
  {T_SIMP, SPK_B, 'b', 'B'},
  {T_SIMP, SPK_N, 'n', 'N'},
  {T_SIMP, SPK_M, 'm', 'M'},
  {T_TRAN, SKE, ',', '<'},
  {T_TRAN, SKE, '.', '>'},
  {T_TRAN, SKE, '/', '?'},
  {T_SIMP, SPK_SYMBOLSHIFT, NOKEY, NOKEY}, 
  SDEMPTY,                 /* KP_TIMES */
  SDEMPTY,                 /* L_ALT */
  
  {T_SIMP, SPK_SPACE, ' ', ' '},
  SDEMPTY,                 /* CAPS_LOCK */
  {T_TRAN, SKE, FKEY(1), FKEY(1) },
  {T_TRAN, SKE, FKEY(2), FKEY(2) },
  {T_TRAN, SKE, FKEY(3), FKEY(3) },
  {T_TRAN, SKE, FKEY(4), FKEY(4) },
  {T_TRAN, SKE, FKEY(5), FKEY(5) },
  {T_TRAN, SKE, FKEY(6), FKEY(6) },
  {T_TRAN, SKE, FKEY(7), FKEY(7) },
  {T_TRAN, SKE, FKEY(8), FKEY(8) },
  {T_TRAN, SKE, FKEY(9), FKEY(9) },
  {T_TRAN, SKE, FKEY(10), FKEY(10) },
  SDEMPTY,                 /* NUM_LOCK */
  SDEMPTY,                 /* SCROLL_LOCK */
  {T_TRAN, SKE,        HOMEKEY,   HOMEKEY  },    /* KP_7 */
  {T_SIMP, SPK_UP,     UPKEY,     UPKEY    },    /* KP_8 */
  {T_TRAN, SKE,        PUKEY,     PUKEY    },    /* KP_9 */
  SDEMPTY,                 /* KP_MINUS */
  {T_SIMP, SPK_LEFT,   LEFTKEY,   LEFTKEY  },    /* KP_4 */
  SDEMPTY,                 /* KP_5 */
  {T_SIMP, SPK_RIGHT,  RIGHTKEY,  RIGHTKEY },    /* KP_6 */
  SDEMPTY,                 /* KP_PLUS */
  {T_TRAN, SKE,        ENDKEY,    ENDKEY   },    /* KP_1 */
  {T_SIMP, SPK_DOWN,   DOWNKEY,   DOWNKEY  },    /* KP_2 */
  {T_TRAN, SKE,        PDKEY,     PDKEY    },    /* KP_3 */
  {T_TRAN, SKE,        INSKEY,    INSKEY   },    /* KP_0 */
  {T_TRAN, SPK_BS,     DELKEY,    DELKEY   },    /* KP_DOT */
  SDEMPTY,
  SDEMPTY,
  SDEMPTY,
  {T_TRAN, SKE, FKEY(11), FKEY(11) },
  {T_TRAN, SKE, FKEY(12), FKEY(12) },
  SDEMPTY,
  SDEMPTY,
  SDEMPTY,
  SDEMPTY,
  SDEMPTY,
  SDEMPTY,
  SDEMPTY,
  SDEMPTY,                 /* KP_ENTER */
  SDEMPTY,                 /* R_CTRL */
  SDEMPTY,                 /* KP_DIV */
  SDEMPTY,                 /* PRINT_SCREEN */
  SDEMPTY,                 /* R_ALT */
  SDEMPTY,
  {T_TRAN, SKE,        HOMEKEY,   HOMEKEY  },
  {T_SIMP, SPK_UP,     UPKEY,     UPKEY    },
  {T_TRAN, SKE,        PUKEY,     PUKEY    },
  {T_SIMP, SPK_LEFT,   LEFTKEY,   LEFTKEY  },
  {T_SIMP, SPK_RIGHT,  RIGHTKEY,  RIGHTKEY },
  {T_TRAN, SKE,        ENDKEY,    ENDKEY   },
  {T_SIMP, SPK_DOWN,   DOWNKEY,   DOWNKEY  },
  {T_TRAN, SKE,        PDKEY,     PDKEY    },
  {T_TRAN, SKE,        INSKEY,    INSKEY   },
  {T_TRAN, SPK_BS,     DELKEY,    DELKEY   }
};

#define LASTKEYCODE 111


void spkey_textmode()
{
  spkb_normal();
  restore_sptextmode();
}

void spkey_screenmode()
{
  set_vga_spmode();
  spkb_raw();
  
  sp_init_screen_mark();
}

void spkb_process_events()
{
  struct spkeydef *spk = 0;
  struct spscan_keydef *sps;

  static int last_ctr_key = -1;

  int i;
  int clear_capsshift = 0;

  spkb_update();

  SP_SETEMPTY(spkey_state);

  if(ctrlstate) {
    int keyc = -1;

    for(i = 0; i <= LASTKEYCODE; i++) {
      if(i != KC_L_CTRL && i != KC_R_CTRL && kbst(i)) {
	if(keyc == -1) keyc = i;
	else keyc = -2;
      }
    }
    if(keyc >= 0 && keyc != last_ctr_key) {
      int k;
      k = sp_cp_keycode[keyc].norm;

      spkey_keyfuncs(k);
    }
    last_ctr_key = keyc;
  }
  else {
    last_ctr_key = -1;
    for(i = 0; i <= LASTKEYCODE; i++) {
      if(kbst(i)) {
	
	sps = sp_cp_keycode+i;
	
	if(sps->type == T_TRAN || altstate) {
	  int key;
	  
	  if(kbst(KC_L_SHIFT)) clear_capsshift = 1;
	  if(shiftstate || altstate) 
	    key = sps->shifted;
	  else 
	    key = sps->norm;
	  
	  if(key < 127 && key >= 32) {
	    spk = spkey_ascii + (key - 32);
	    if(spk->type == T_MAIN || spk->type == T_CMPX)
	      SP_COMBINE(spkey_state, spk->kb);
	  }
	  
	}
	else SP_COMBINE(spkey_state, sps->kb);
	
      }
    }
    if(clear_capsshift) SP_SUBSTRACT(spkey_state, spkey_aux[SP_CAPSSHIFT].kb);
  }

}

void spkb_press_ud()
{
}
  

void spkb_release_ud()
{
}

static void close_spect_key(void)
{
  spkb_close();
}

void init_spect_key()
{
  spkb_init();
  
  atexit(close_spect_key);
  
}
