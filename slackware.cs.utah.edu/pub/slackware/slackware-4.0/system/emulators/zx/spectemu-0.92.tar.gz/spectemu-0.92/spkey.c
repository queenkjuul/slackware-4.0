/* 
 * Copyright (C) 1996-1998 Szeredi Miklos
 * Email: mszeredi@inf.bme.hu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the file COPYING. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include "spkey.h"
#include "spkey_p.h"

#include "spperif.h"
#include "z80.h"

#include "sptape.h"
#include "snapshot.h"
#include "spsound.h"
#include "spscr.h"

#include <stdlib.h>
#include <stdio.h>

extern int endofsingle;
extern int sp_nosync;
extern int sound_delay;
extern int showframe;

spkeyboard spkey_state;
static spkeyboard oldstate = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

static void print_help(int lev)
{
  switch(lev) {
  case 0:
    printf("   = ZX Spectrum Emulation (C) Szeredi Miklos 1996-98 =  \n"
	   " --------------------------------------------------------\n"
	   "  Left Shift             Spectrum - CAPS SHIFT           \n"
	   "  Right Shift            Spectrum - SYMBOL SHIFT         \n"
	   "  Alt                    \"True\" Shift                    \n"
	   "  Ctrl                   Commands                        \n"
	   " --------------------------------------------------------\n"
	   "  Ctrl-c                 Quit                            \n"
	   "  Ctrl-l                 Load snapshot                   \n"
	   "  Ctrl-t                 Save snapshot                   \n"
	   "  Ctrl-q                 Reset                           \n"
	   "  Ctrl-f                 Fast                            \n"
	   "  Ctrl-n                 Normal speed                    \n"
	   "  Ctrl-b                 Pause/Unpause emulator          \n"
	   "  Ctrl-m                 Toggle sound                    \n"
	   "  Ctrl-p                 Play tape                       \n"
	   "  Ctrl-s                 Stop tape                       \n"
           "  Ctrl-y                 Toggle quick loading of tapes   \n"
	   "  Ctrl-o                 Pause/unpause tape              \n"
	   "  Ctrl-\\                 Refresh screen / reset keyboard \n"
	   "  Ctrl-j                 More help                       \n"
	   " ========================================================\n");
    break;
    
  case 1:
    printf("   = ZX Spectrum Emulation (C) Szeredi Miklos 1996-98 =  \n"
	   " --------------------------------------------------------\n"
           "  More help:                                             \n"
	   " --------------------------------------------------------\n"
	   "  Ctrl-h                 Normal help                     \n"
	   "  Ctrl-k                 Display keyboard                \n"
	   "  Ctrl-w                 Save temporary snapshot         \n"
           "  Ctrl-e                 Load temporary snapshot         \n"
           "  Ctrl-r                 Save to tapefile                \n"
	   "  Ctrl-,                 Reduce screen size   (X only)   \n"
	   "  Ctrl-.                 Increase screen size (X only)   \n"
	   "  Ctrl-=                 Decrease frame frequency        \n"
	   "  Ctrl--                 Increase frame frequency        \n"
	   "  Ctrl-]                 Increase sound buffer size      \n"
	   "  Ctrl-[                 Decrease sound buffer size      \n"
	   " ========================================================\n");
    break;

  case 2:
    printf(
" ---------------------------------------------------------------------       \n"
"|BLUE  |RED   |MAGENT|GREEN |CYAN  |YELLOW|WHITE |      |      |BLACK |      \n"
"| 1 !  | 2 @  | 3 #  | 4 $  | 5 %%  | 6 &  | 7 '  | 8 (  | 9 )  | 0 _  |      \n"
"|EDIT  |CAPS  |TRU VD|INV VD|  <-  |  v   |  ^   |  ->  |GRAPH |DELETE|      \n"
"|DEF FN|FN    |LINE  |OPEN# |CLOSE#|MOVE  |ERASE |POINT |CAT   |FORMAT|      \n"
" ------------------------------------------------------------------------    \n"
"   |SIN   |COS   |TAN   |INT   |RND   |STR$  |CHR$  |CODE  |PEEK  |TAB   |   \n"
"   | Q <= | W <> | E >= | R <  | T >  | Y AND| U OR | I AT | O ;  | P \"  |   \n"
"   |PLOT  |DRAW  |REM   |RUN   |RAND  |RETURN|IF    |INPUT |POKE  |PRINT |   \n"
"   |ASN   |ACS   |ATN   |VERIFY|MERGE |  [   |  ]   |IN    |OUT   |(C)   |   \n"
"    ------------------------------------------------------------------------ \n"
"       |READ  |RESTOR|DATA  |SGN   |ABS   |SQR   |VAL   |LEN   |USR   |     |\n"
"       |A STOP| S NOT|D STEP| F TO |G THEN| H ^  | J -  | K +  | L =  |     |\n"
"       |NEW   |SAVE  |DIM   |FOR   |GO TO |GO SUB|LOAD  |LIST  |LET   |ENTER|\n"
"       | ~    | |    | \\    | {    | }    |CIRCLE|VAL$  |SCRN$ |ATTR  |     |\n"
"  -------------------------------------------------------------------------- \n"
" |       |LN    |EXP   |LPRINT|LLIST |BIN   |INKEY$| PI   |      |       |   \n"
" |  CAPS | Z :  | X GBP| C ?  | V /  | B *  | N ,  | M .  |SYMBOL| BREAK |   \n"
" | SHIFT |COPY  |CLEAR |CONT  |CLS   |BORDER|NEXT  |PAUSE |SHIFT | SPACE |   \n"
" |       |BEEP  |INK   |PAPER |FLASH |BRIGHT|OVER  |INVERS|      |       |   \n"
"  -----------------------------------------------------------------------    \n"
	   );
    break;

  }
  if(need_switch_mode) {
    printf("  Press ENTER to continue!                           \n");
    while(getchar() != '\n');
  }
}

#ifdef DEBUG_Z80
extern int deb_steps;
#endif

void spkey_keyfuncs(int k)
{
  switch(k) {
  case 'c':
    exit(0);
  case 'p':
    spkey_textmode();
    start_play();
    spkey_screenmode();
    break;
  case 'r':
    spkey_textmode();
    start_rec();
    spkey_screenmode();
    break;
  case 'o':
    pause_play();
    break;
  case 's':
    stop_play();
    break;
  case 'f':
    sp_nosync = 1;
    sp_paused = 0;
    autoclose_sound();
    break;
  case 'n':
    sp_nosync = 0;
    sp_paused = 0;
    break;
  case 'b':
    sp_paused = !sp_paused;
    if(sp_paused) {
      SP_SETEMPTY(spkey_state);
      spkb_refresh();
    }
    printf("%s emulator\n", sp_paused ? "Paused" : "Unpaused");
    break;
  case 'q':
    z80_reset();
    break;
  case 't':
    spkey_textmode();
    save_snapshot();
    spkey_screenmode();
    break;
  case 'l':
    spkey_textmode();
    load_snapshot();
    spkey_screenmode();
    break;
#ifdef DEBUG_Z80
  case 'v':
    deb_steps = 0;
    break;
#endif
  case '=':
    if(showframe < 10) showframe++;
    printf("showframe: %i\n", showframe);
    break;
  case '-':
    if(showframe > 1) showframe--;
    printf("showframe: %i\n", showframe);
    break;
  case ']':
    if(bufframes < 25) bufframes++;
    printf("bufframes: %i\n", bufframes);
    setbufsize();
    break;
  case '[':
    if(bufframes > 1) bufframes--;
    printf("bufframes: %i\n", bufframes);
    setbufsize();
    break;
  case 'm':
    sound_on = !sound_on;
    printf("sound %s\n", sound_on ? "on" : "off");
    break;
  case 'h':
    spkey_textmode();
    print_help(0);
    spkey_screenmode();
    break;
  case 'j':
    spkey_textmode();
    print_help(1);
    spkey_screenmode();
    break;
  case 'k':
    spkey_textmode();
    print_help(2);
    spkey_screenmode();
    break;
  case '\\':
    sp_init_screen_mark();
    SP_SETEMPTY(spkey_state);
    spkb_refresh();
    break;
  case '.':
    resize_spect_scr(scrmul+1);
    break;
  case ',':
    resize_spect_scr(scrmul-1);
    break;
  case 'y':
    sp_quick_load = !sp_quick_load;
    printf("Quick load %s\n", sp_quick_load ? "on" : "off");
    break;
  case 'w':
    save_quick_snapshot();
    break;
  case 'e':
    load_quick_snapshot();
    break;
  }
}


struct spkeydef spkey_ascii[] = {
  {T_MAIN, SPK_SPACE},  /* space */
  {T_CMPX, SKSS3(0)}, /* ! */
  {T_CMPX, SKSS5(0)}, /* " */
  {T_CMPX, SKSS3(2)}, /* # */
  {T_CMPX, SKSS3(3)}, /* $ */
  {T_CMPX, SKSS3(4)}, /* % */
  {T_CMPX, SKSS4(4)}, /* & */
  {T_CMPX, SKSS4(3)}, /* ' */
  {T_CMPX, SKSS4(2)}, /* ( */
  {T_CMPX, SKSS4(1)}, /* ) */
  {T_CMPX, SKSS7(4)}, /* * */
  {T_CMPX, SKSS6(2)}, /* + */
  {T_CMPX, SKSS7(3)}, /* , */
  {T_CMPX, SKSS6(3)}, /* - */
  {T_CMPX, SKSS7(2)}, /* . */
  {T_CMPX, SKSS0(4)}, /* / */

  {T_MAIN, SPK_0},  /* 0 */
  {T_MAIN, SPK_1},  /* 1 */
  {T_MAIN, SPK_2},  /* 2 */
  {T_MAIN, SPK_3},  /* 3 */
  {T_MAIN, SPK_4},  /* 4 */
  {T_MAIN, SPK_5},  /* 5 */
  {T_MAIN, SPK_6},  /* 6 */
  {T_MAIN, SPK_7},  /* 7 */
  {T_MAIN, SPK_8},  /* 8 */
  {T_MAIN, SPK_9},  /* 9 */

  {T_CMPX, SKSS0(1)}, /* : */
  {T_CMPX, SKSS5(1)}, /* ; */
  {T_CMPX, SKSS2(3)}, /* < */
  {T_CMPX, SKSS6(1)}, /* = */
  {T_CMPX, SKSS2(4)}, /* > */
  {T_CMPX, SKSS0(3)}, /* ? */
  {T_CMPX, SKSS3(1)}, /* @ */

  {T_CMPX, SKCS1(0)}, /* A */
  {T_CMPX, SKCS7(4)}, /* B */
  {T_CMPX, SKCS0(3)}, /* C */
  {T_CMPX, SKCS1(2)}, /* D */
  {T_CMPX, SKCS2(2)}, /* E */
  {T_CMPX, SKCS1(3)}, /* F */
  {T_CMPX, SKCS1(4)}, /* G */
  {T_CMPX, SKCS6(4)}, /* H */
  {T_CMPX, SKCS5(2)}, /* I */
  {T_CMPX, SKCS6(3)}, /* J */
  {T_CMPX, SKCS6(2)}, /* K */
  {T_CMPX, SKCS6(1)}, /* L */
  {T_CMPX, SKCS7(2)}, /* M */
  {T_CMPX, SKCS7(3)}, /* N */
  {T_CMPX, SKCS5(1)}, /* O */
  {T_CMPX, SKCS5(0)}, /* P */
  {T_CMPX, SKCS2(0)}, /* Q */
  {T_CMPX, SKCS2(3)}, /* R */
  {T_CMPX, SKCS1(1)}, /* S */
  {T_CMPX, SKCS2(4)}, /* T */
  {T_CMPX, SKCS5(3)}, /* U */
  {T_CMPX, SKCS0(4)}, /* V */
  {T_CMPX, SKCS2(1)}, /* W */
  {T_CMPX, SKCS0(2)}, /* X */
  {T_CMPX, SKCS5(4)}, /* Y */
  {T_CMPX, SKCS0(1)}, /* Z */

  {T_EXTR, SKCS5(4)}, /* [ */
  {T_EXTR, SKCS1(2)}, /* backslash */
  {T_EXTR, SKCS5(3)}, /* ] */
  {T_CMPX, SKSS6(4)}, /* ^ */
  {T_CMPX, SKSS4(0)}, /* _ */
  {T_CMPX, SKSS0(2)}, /* ` */

  {T_MAIN, SPK_A},  /* a */
  {T_MAIN, SPK_B},  /* b */
  {T_MAIN, SPK_C},  /* c */
  {T_MAIN, SPK_D},  /* d */
  {T_MAIN, SPK_E},  /* e */
  {T_MAIN, SPK_F},  /* f */
  {T_MAIN, SPK_G},  /* g */
  {T_MAIN, SPK_H},  /* h */
  {T_MAIN, SPK_I},  /* i */
  {T_MAIN, SPK_J},  /* j */
  {T_MAIN, SPK_K},  /* k */
  {T_MAIN, SPK_L},  /* l */
  {T_MAIN, SPK_M},  /* m */
  {T_MAIN, SPK_N},  /* n */
  {T_MAIN, SPK_O},  /* o */
  {T_MAIN, SPK_P},  /* p */
  {T_MAIN, SPK_Q},  /* q */
  {T_MAIN, SPK_R},  /* r */
  {T_MAIN, SPK_S},  /* s */
  {T_MAIN, SPK_T},  /* t */
  {T_MAIN, SPK_U},  /* u */
  {T_MAIN, SPK_V},  /* v */
  {T_MAIN, SPK_W},  /* w */
  {T_MAIN, SPK_X},  /* x */
  {T_MAIN, SPK_Y},  /* y */
  {T_MAIN, SPK_Z},  /* z */

  {T_EXTR, SKCS1(3)}, /* { */
  {T_EXTR, SKCS1(1)}, /* | */
  {T_EXTR, SKCS1(4)}, /* } */
  {T_EXTR, SKCS1(0)}, /* ~ */
};


struct spkeydef spkey_aux[] = {
  {T_MAIN, SPK_ENTER       }, /* enter */
  {T_MAIN, SPK_CAPSSHIFT   }, /* caps shift */
  {T_MAIN, SPK_SYMBOLSHIFT }, /* symbol shift */
  {T_CMPX, SPK_BS          }, /* backspace */
  {T_CMPX, SPK_UP          }, /* up */
  {T_CMPX, SPK_DOWN        }, /* down */
  {T_CMPX, SPK_LEFT        }, /* left */
  {T_CMPX, SPK_RIGHT       }, /* right */
  {T_CMPX, SPK_CAPSLOCK    }, /* caps lock */
};


void spkb_refresh()
{
  int port, pb;
  int i, changed;
  byte *km, *kmo;
  byte pv;

  km = spkey_state;
  kmo = oldstate;
  changed = 0;
  for(i = 8; i; i--) {
    if(*km != *kmo) *kmo = *km, changed = 1;
    km++, kmo++;
  }

  if(changed) {
    for(port = 0; port < 256; port++) {
      km = spkey_state;
      pv = 0;
      pb = port;
      for(i = 8; i; i--) {
	if(!(pb & 1)) pv |= *km;
	pb >>= 1;
	km++;
      }
      sp_fe_inport_high[port] = 
	(sp_fe_inport_high[port] | 0x1F) & ~(pv & 0x1F); 
    }
  }
}
