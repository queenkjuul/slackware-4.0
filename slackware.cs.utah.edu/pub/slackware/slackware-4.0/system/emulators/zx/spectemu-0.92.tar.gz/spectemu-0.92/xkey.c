/* 
 * Copyright (C) 1996-1998 Szeredi Miklos
 * Email: mszeredi@inf.bme.hu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the file COPYING. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/* #define DEBUG_FOCUS */

#define FOCUS_OUT_BUG_FIX

#include "xkey.h"
#include "spkey.h"
#include "spkey_p.h"
#include "spscr.h"

#include "ax.h"

#include <X11/Xlib.h>
#include <X11/keysym.h>

#include <stdio.h>
#include <stdlib.h>

const int need_switch_mode = 0;

extern Window xsp_win;
extern Display *xsp_disp;

void (*spkb_event_processor)(void);

static spkeyboard sp_press;
static spkeyboard sp_release;
static int got_focus = 0;

static struct spkeydef *get_keydef(KeySym ks)
{
  if(ks >= XK_space && ks <= XK_space + 126) 
    return spkey_ascii + (ks - XK_space);
  
  switch((int) ks) {
  case XK_Return:
    return  spkey_aux + SP_ENTER;
  case XK_Shift_L:
    return spkey_aux + SP_CAPSSHIFT;
  case XK_Shift_R:
    return spkey_aux + SP_SYMBOLSHIFT;
  case XK_BackSpace:
    return spkey_aux + CX_BACKSPACE;
  case XK_Delete:
    return spkey_aux + CX_BACKSPACE;
  case XK_Up:
    return spkey_aux + CX_UP;
  case XK_Down:
    return spkey_aux + CX_DOWN;
  case XK_Left:
    return spkey_aux + CX_LEFT;
  case XK_Right:
    return spkey_aux + CX_RIGHT;
/*  case XK_Caps_Lock: */
/*    return spkey_aux + CX_CAPSLOCK; */
  }
  return 0;
}


void spkey_textmode()
{
  XAutoRepeatOn(xsp_disp);
  XSync(xsp_disp, False);
}

void spkey_screenmode()
{
  XAutoRepeatOff(xsp_disp);
  XSync(xsp_disp, False);
}

/* Keyboard bug: BS+, Alt+, BS-, Alt- : no release of BS */

static void key_call(XEvent *ev) 
{
  KeySym keysym;
  struct spkeydef *spk;
  static int cleared_capsshift = 0;
  int clear_capsshift = 0;

  if(!accept_keys) return;

#ifdef FOCUS_OUT_BUG_FIX
  if(!got_focus) {
#ifdef DEBUG_FOCUS
    fprintf(stderr, "Got keypress in unfocused mode\n");
#endif

    XAutoRepeatOff(xsp_disp);
    got_focus = 1;
    XSync(xsp_disp, False);    
  }
#endif

  if((*ev).xkey.state & Mod1Mask) {
    keysym = XLookupKeysym((XKeyEvent *)ev, 1);
    spk = get_keydef(keysym);
  }
  else {
    keysym = XLookupKeysym((XKeyEvent *)ev, 0);
    
    if(((*ev).xkey.state & ControlMask)) {
      if(ev->type == KeyPress) spkey_keyfuncs((int) keysym);
      return;
    }
    spk = get_keydef(keysym);
    if(spk == NULL) return;
    
    if(spk->type != T_MAIN && ((*ev).xkey.state & ShiftMask)) {
      keysym = XLookupKeysym((XKeyEvent *)ev, 1);
      spk = get_keydef(keysym);
      clear_capsshift = 1;
    }
  }
  if(spk == NULL) return;

  if(spk->type != T_EXTR) {
    if(clear_capsshift && 
       SP_CONTAINS(spkey_state, spkey_aux[SP_CAPSSHIFT].kb)) {

      cleared_capsshift = 1;
      SP_SUBSTRACT(spkey_state, spkey_aux[SP_CAPSSHIFT].kb);
    }
    if(ev->type == KeyPress)
      SP_COMBINE(sp_press, spk->kb);
    else 
      SP_COMBINE(sp_release, spk->kb);
  }
  if(!clear_capsshift && cleared_capsshift) {
    SP_COMBINE(spkey_state, spkey_aux[SP_CAPSSHIFT].kb);
    cleared_capsshift = 0;
  }
}
 

void spkb_process_events()
{
  aX_look_events();
  if(spkb_event_processor) (*spkb_event_processor)();
}

void spkb_press_ud()
{
  if(SP_NONEMPTY(sp_press)) {
    SP_COMBINE(spkey_state, sp_press);
    SP_SETEMPTY(sp_press);
  }
}


void spkb_release_ud()
{
  if(SP_NONEMPTY(sp_release)) {
    SP_SUBSTRACT(spkey_state, sp_release);
    SP_SETEMPTY(sp_release);
  }
}


void xkey_focus_change_call(XEvent *ev)
{
  if(ev->type == FocusIn) {
    XAutoRepeatOff(xsp_disp);
    got_focus = 1;
#ifdef DEBUG_FOCUS
    fprintf(stderr, "Focus In (%i)\n", (*ev).xfocus.detail);
#endif
  }
  else {
    SP_SETEMPTY(spkey_state);
    spkb_refresh();
    XAutoRepeatOn(xsp_disp);
    got_focus = 0;
#ifdef DEBUG_FOCUS
    fprintf(stderr, "Focus Out (%i)\n", (*ev).xfocus.detail);
#endif
  }

  XSync(xsp_disp, False);
}



static void  close_spect_key(void)
{
  XAutoRepeatOn(xsp_disp);
  XSync(xsp_disp, False);
}


void init_spect_key()
{
  SP_SETEMPTY(spkey_state);
  SP_SETEMPTY(sp_press);
  SP_SETEMPTY(sp_release);

  aX_add_event_proc(xsp_win, KeyPress, key_call, KeyPressMask);
  aX_add_event_proc(xsp_win, KeyRelease, key_call, KeyReleaseMask);
  
  atexit(close_spect_key);

  spkb_event_processor = 0;
}
